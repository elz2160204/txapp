// lib: , url: package:flutter/src/material/text_field.dart

// class id: 1049323, size: 0x8
class :: {

  static _ _m3InputStyle(/* No info */) {
    // ** addr: 0x8720f4, size: 0x54
    // 0x8720f4: EnterFrame
    //     0x8720f4: stp             fp, lr, [SP, #-0x10]!
    //     0x8720f8: mov             fp, SP
    // 0x8720fc: CheckStackOverflow
    //     0x8720fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872100: cmp             SP, x16
    //     0x872104: b.ls            #0x87213c
    // 0x872108: ldr             x16, [fp, #0x10]
    // 0x87210c: SaveReg r16
    //     0x87210c: str             x16, [SP, #-8]!
    // 0x872110: r0 = of()
    //     0x872110: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x872114: add             SP, SP, #8
    // 0x872118: LoadField: r1 = r0->field_93
    //     0x872118: ldur            w1, [x0, #0x93]
    // 0x87211c: DecompressPointer r1
    //     0x87211c: add             x1, x1, HEAP, lsl #32
    // 0x872120: LoadField: r0 = r1->field_2b
    //     0x872120: ldur            w0, [x1, #0x2b]
    // 0x872124: DecompressPointer r0
    //     0x872124: add             x0, x0, HEAP, lsl #32
    // 0x872128: cmp             w0, NULL
    // 0x87212c: b.eq            #0x872144
    // 0x872130: LeaveFrame
    //     0x872130: mov             SP, fp
    //     0x872134: ldp             fp, lr, [SP], #0x10
    // 0x872138: ret
    //     0x872138: ret             
    // 0x87213c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87213c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872140: b               #0x872108
    // 0x872144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872144: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _m2CounterErrorStyle(/* No info */) {
    // ** addr: 0x872a28, size: 0x94
    // 0x872a28: EnterFrame
    //     0x872a28: stp             fp, lr, [SP, #-0x10]!
    //     0x872a2c: mov             fp, SP
    // 0x872a30: AllocStack(0x8)
    //     0x872a30: sub             SP, SP, #8
    // 0x872a34: CheckStackOverflow
    //     0x872a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872a38: cmp             SP, x16
    //     0x872a3c: b.ls            #0x872ab0
    // 0x872a40: ldr             x16, [fp, #0x10]
    // 0x872a44: SaveReg r16
    //     0x872a44: str             x16, [SP, #-8]!
    // 0x872a48: r0 = of()
    //     0x872a48: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x872a4c: add             SP, SP, #8
    // 0x872a50: LoadField: r1 = r0->field_93
    //     0x872a50: ldur            w1, [x0, #0x93]
    // 0x872a54: DecompressPointer r1
    //     0x872a54: add             x1, x1, HEAP, lsl #32
    // 0x872a58: LoadField: r0 = r1->field_33
    //     0x872a58: ldur            w0, [x1, #0x33]
    // 0x872a5c: DecompressPointer r0
    //     0x872a5c: add             x0, x0, HEAP, lsl #32
    // 0x872a60: stur            x0, [fp, #-8]
    // 0x872a64: cmp             w0, NULL
    // 0x872a68: b.eq            #0x872ab8
    // 0x872a6c: ldr             x16, [fp, #0x10]
    // 0x872a70: SaveReg r16
    //     0x872a70: str             x16, [SP, #-8]!
    // 0x872a74: r0 = of()
    //     0x872a74: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x872a78: add             SP, SP, #8
    // 0x872a7c: LoadField: r1 = r0->field_3f
    //     0x872a7c: ldur            w1, [x0, #0x3f]
    // 0x872a80: DecompressPointer r1
    //     0x872a80: add             x1, x1, HEAP, lsl #32
    // 0x872a84: LoadField: r0 = r1->field_3b
    //     0x872a84: ldur            w0, [x1, #0x3b]
    // 0x872a88: DecompressPointer r0
    //     0x872a88: add             x0, x0, HEAP, lsl #32
    // 0x872a8c: ldur            x16, [fp, #-8]
    // 0x872a90: stp             x0, x16, [SP, #-0x10]!
    // 0x872a94: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x872a94: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x872a98: ldr             x4, [x4, #0x168]
    // 0x872a9c: r0 = copyWith()
    //     0x872a9c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x872aa0: add             SP, SP, #0x10
    // 0x872aa4: LeaveFrame
    //     0x872aa4: mov             SP, fp
    //     0x872aa8: ldp             fp, lr, [SP], #0x10
    // 0x872aac: ret
    //     0x872aac: ret             
    // 0x872ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872ab0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872ab4: b               #0x872a40
    // 0x872ab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872ab8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2146, size: 0x2c, field offset: 0x28
class _TextFieldSelectionGestureDetectorBuilder extends TextSelectionGestureDetectorBuilder {

  [closure] void onSingleLongTapStart(dynamic, LongPressStartDetails) {
    // ** addr: 0x8700f0, size: 0x4c
    // 0x8700f0: EnterFrame
    //     0x8700f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8700f4: mov             fp, SP
    // 0x8700f8: ldr             x0, [fp, #0x18]
    // 0x8700fc: LoadField: r1 = r0->field_17
    //     0x8700fc: ldur            w1, [x0, #0x17]
    // 0x870100: DecompressPointer r1
    //     0x870100: add             x1, x1, HEAP, lsl #32
    // 0x870104: CheckStackOverflow
    //     0x870104: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870108: cmp             SP, x16
    //     0x87010c: b.ls            #0x870134
    // 0x870110: LoadField: r0 = r1->field_f
    //     0x870110: ldur            w0, [x1, #0xf]
    // 0x870114: DecompressPointer r0
    //     0x870114: add             x0, x0, HEAP, lsl #32
    // 0x870118: ldr             x16, [fp, #0x10]
    // 0x87011c: stp             x16, x0, [SP, #-0x10]!
    // 0x870120: r0 = onSingleLongTapStart()
    //     0x870120: bl              #0x87013c  ; [package:flutter/src/material/text_field.dart] _TextFieldSelectionGestureDetectorBuilder::onSingleLongTapStart
    // 0x870124: add             SP, SP, #0x10
    // 0x870128: LeaveFrame
    //     0x870128: mov             SP, fp
    //     0x87012c: ldp             fp, lr, [SP], #0x10
    // 0x870130: ret
    //     0x870130: ret             
    // 0x870134: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870134: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870138: b               #0x870110
  }
  _ onSingleLongTapStart(/* No info */) {
    // ** addr: 0x87013c, size: 0xf8
    // 0x87013c: EnterFrame
    //     0x87013c: stp             fp, lr, [SP, #-0x10]!
    //     0x870140: mov             fp, SP
    // 0x870144: AllocStack(0x8)
    //     0x870144: sub             SP, SP, #8
    // 0x870148: CheckStackOverflow
    //     0x870148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87014c: cmp             SP, x16
    //     0x870150: b.ls            #0x870224
    // 0x870154: ldr             x16, [fp, #0x18]
    // 0x870158: ldr             lr, [fp, #0x10]
    // 0x87015c: stp             lr, x16, [SP, #-0x10]!
    // 0x870160: r0 = onSingleLongTapStart()
    //     0x870160: bl              #0x870234  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::onSingleLongTapStart
    // 0x870164: add             SP, SP, #0x10
    // 0x870168: ldr             x1, [fp, #0x18]
    // 0x87016c: LoadField: r0 = r1->field_7
    //     0x87016c: ldur            w0, [x1, #7]
    // 0x870170: DecompressPointer r0
    //     0x870170: add             x0, x0, HEAP, lsl #32
    // 0x870174: r2 = LoadClassIdInstr(r0)
    //     0x870174: ldur            x2, [x0, #-1]
    //     0x870178: ubfx            x2, x2, #0xc, #0x14
    // 0x87017c: SaveReg r0
    //     0x87017c: str             x0, [SP, #-8]!
    // 0x870180: mov             x0, x2
    // 0x870184: r0 = GDT[cid_x0 + -0x1000]()
    //     0x870184: sub             lr, x0, #1, lsl #12
    //     0x870188: ldr             lr, [x21, lr, lsl #3]
    //     0x87018c: blr             lr
    // 0x870190: add             SP, SP, #8
    // 0x870194: tbnz            w0, #4, #0x870214
    // 0x870198: ldr             x0, [fp, #0x18]
    // 0x87019c: LoadField: r1 = r0->field_27
    //     0x87019c: ldur            w1, [x0, #0x27]
    // 0x8701a0: DecompressPointer r1
    //     0x8701a0: add             x1, x1, HEAP, lsl #32
    // 0x8701a4: stur            x1, [fp, #-8]
    // 0x8701a8: LoadField: r0 = r1->field_f
    //     0x8701a8: ldur            w0, [x1, #0xf]
    // 0x8701ac: DecompressPointer r0
    //     0x8701ac: add             x0, x0, HEAP, lsl #32
    // 0x8701b0: cmp             w0, NULL
    // 0x8701b4: b.eq            #0x87022c
    // 0x8701b8: SaveReg r0
    //     0x8701b8: str             x0, [SP, #-8]!
    // 0x8701bc: r0 = of()
    //     0x8701bc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8701c0: add             SP, SP, #8
    // 0x8701c4: LoadField: r1 = r0->field_1f
    //     0x8701c4: ldur            w1, [x0, #0x1f]
    // 0x8701c8: DecompressPointer r1
    //     0x8701c8: add             x1, x1, HEAP, lsl #32
    // 0x8701cc: LoadField: r0 = r1->field_7
    //     0x8701cc: ldur            x0, [x1, #7]
    // 0x8701d0: cmp             x0, #2
    // 0x8701d4: b.gt            #0x8701e4
    // 0x8701d8: cmp             x0, #1
    // 0x8701dc: b.gt            #0x870214
    // 0x8701e0: b               #0x8701f4
    // 0x8701e4: cmp             x0, #4
    // 0x8701e8: b.gt            #0x8701f4
    // 0x8701ec: cmp             x0, #3
    // 0x8701f0: b.gt            #0x870214
    // 0x8701f4: ldur            x0, [fp, #-8]
    // 0x8701f8: LoadField: r1 = r0->field_f
    //     0x8701f8: ldur            w1, [x0, #0xf]
    // 0x8701fc: DecompressPointer r1
    //     0x8701fc: add             x1, x1, HEAP, lsl #32
    // 0x870200: cmp             w1, NULL
    // 0x870204: b.eq            #0x870230
    // 0x870208: SaveReg r1
    //     0x870208: str             x1, [SP, #-8]!
    // 0x87020c: r0 = forLongPress()
    //     0x87020c: bl              #0x83bf00  ; [package:flutter/src/material/feedback.dart] Feedback::forLongPress
    // 0x870210: add             SP, SP, #8
    // 0x870214: r0 = Null
    //     0x870214: mov             x0, NULL
    // 0x870218: LeaveFrame
    //     0x870218: mov             SP, fp
    //     0x87021c: ldp             fp, lr, [SP], #0x10
    // 0x870220: ret
    //     0x870220: ret             
    // 0x870224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870224: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870228: b               #0x870154
    // 0x87022c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87022c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x870230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x870230: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onSingleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0x870700, size: 0x4c
    // 0x870700: EnterFrame
    //     0x870700: stp             fp, lr, [SP, #-0x10]!
    //     0x870704: mov             fp, SP
    // 0x870708: ldr             x0, [fp, #0x18]
    // 0x87070c: LoadField: r1 = r0->field_17
    //     0x87070c: ldur            w1, [x0, #0x17]
    // 0x870710: DecompressPointer r1
    //     0x870710: add             x1, x1, HEAP, lsl #32
    // 0x870714: CheckStackOverflow
    //     0x870714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870718: cmp             SP, x16
    //     0x87071c: b.ls            #0x870744
    // 0x870720: LoadField: r0 = r1->field_f
    //     0x870720: ldur            w0, [x1, #0xf]
    // 0x870724: DecompressPointer r0
    //     0x870724: add             x0, x0, HEAP, lsl #32
    // 0x870728: ldr             x16, [fp, #0x10]
    // 0x87072c: stp             x16, x0, [SP, #-0x10]!
    // 0x870730: r0 = onSingleTapUp()
    //     0x870730: bl              #0x87074c  ; [package:flutter/src/material/text_field.dart] _TextFieldSelectionGestureDetectorBuilder::onSingleTapUp
    // 0x870734: add             SP, SP, #0x10
    // 0x870738: LeaveFrame
    //     0x870738: mov             SP, fp
    //     0x87073c: ldp             fp, lr, [SP], #0x10
    // 0x870740: ret
    //     0x870740: ret             
    // 0x870744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870748: b               #0x870720
  }
  _ onSingleTapUp(/* No info */) {
    // ** addr: 0x87074c, size: 0x78
    // 0x87074c: EnterFrame
    //     0x87074c: stp             fp, lr, [SP, #-0x10]!
    //     0x870750: mov             fp, SP
    // 0x870754: AllocStack(0x8)
    //     0x870754: sub             SP, SP, #8
    // 0x870758: CheckStackOverflow
    //     0x870758: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87075c: cmp             SP, x16
    //     0x870760: b.ls            #0x8707b8
    // 0x870764: ldr             x16, [fp, #0x18]
    // 0x870768: ldr             lr, [fp, #0x10]
    // 0x87076c: stp             lr, x16, [SP, #-0x10]!
    // 0x870770: r0 = onSingleTapUp()
    //     0x870770: bl              #0x870814  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::onSingleTapUp
    // 0x870774: add             SP, SP, #0x10
    // 0x870778: ldr             x0, [fp, #0x18]
    // 0x87077c: LoadField: r1 = r0->field_27
    //     0x87077c: ldur            w1, [x0, #0x27]
    // 0x870780: DecompressPointer r1
    //     0x870780: add             x1, x1, HEAP, lsl #32
    // 0x870784: stur            x1, [fp, #-8]
    // 0x870788: SaveReg r1
    //     0x870788: str             x1, [SP, #-8]!
    // 0x87078c: r0 = _requestKeyboard()
    //     0x87078c: bl              #0x8707c4  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_requestKeyboard
    // 0x870790: add             SP, SP, #8
    // 0x870794: ldur            x1, [fp, #-8]
    // 0x870798: LoadField: r2 = r1->field_b
    //     0x870798: ldur            w2, [x1, #0xb]
    // 0x87079c: DecompressPointer r2
    //     0x87079c: add             x2, x2, HEAP, lsl #32
    // 0x8707a0: cmp             w2, NULL
    // 0x8707a4: b.eq            #0x8707c0
    // 0x8707a8: r0 = Null
    //     0x8707a8: mov             x0, NULL
    // 0x8707ac: LeaveFrame
    //     0x8707ac: mov             SP, fp
    //     0x8707b0: ldp             fp, lr, [SP], #0x10
    // 0x8707b4: ret
    //     0x8707b4: ret             
    // 0x8707b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8707b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8707bc: b               #0x870764
    // 0x8707c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8707c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onForcePressStart(dynamic, ForcePressDetails) {
    // ** addr: 0x871018, size: 0x4c
    // 0x871018: EnterFrame
    //     0x871018: stp             fp, lr, [SP, #-0x10]!
    //     0x87101c: mov             fp, SP
    // 0x871020: ldr             x0, [fp, #0x18]
    // 0x871024: LoadField: r1 = r0->field_17
    //     0x871024: ldur            w1, [x0, #0x17]
    // 0x871028: DecompressPointer r1
    //     0x871028: add             x1, x1, HEAP, lsl #32
    // 0x87102c: CheckStackOverflow
    //     0x87102c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x871030: cmp             SP, x16
    //     0x871034: b.ls            #0x87105c
    // 0x871038: LoadField: r0 = r1->field_f
    //     0x871038: ldur            w0, [x1, #0xf]
    // 0x87103c: DecompressPointer r0
    //     0x87103c: add             x0, x0, HEAP, lsl #32
    // 0x871040: ldr             x16, [fp, #0x10]
    // 0x871044: stp             x16, x0, [SP, #-0x10]!
    // 0x871048: r0 = onForcePressStart()
    //     0x871048: bl              #0x870ea8  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextSelectionGestureDetectorBuilder::onForcePressStart
    // 0x87104c: add             SP, SP, #0x10
    // 0x871050: LeaveFrame
    //     0x871050: mov             SP, fp
    //     0x871054: ldp             fp, lr, [SP], #0x10
    // 0x871058: ret
    //     0x871058: ret             
    // 0x87105c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87105c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x871060: b               #0x871038
  }
}

// class id: 3269, size: 0x24, field offset: 0x14
//   transformed mixin,
abstract class __TextFieldState&State&RestorationMixin extends State<TextField>
     with RestorationMixin<X0 bound StatefulWidget> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bef40, size: 0x78
    // 0x7bef40: EnterFrame
    //     0x7bef40: stp             fp, lr, [SP, #-0x10]!
    //     0x7bef44: mov             fp, SP
    // 0x7bef48: CheckStackOverflow
    //     0x7bef48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bef4c: cmp             SP, x16
    //     0x7bef50: b.ls            #0x7befb0
    // 0x7bef54: ldr             x3, [fp, #0x18]
    // 0x7bef58: LoadField: r2 = r3->field_7
    //     0x7bef58: ldur            w2, [x3, #7]
    // 0x7bef5c: DecompressPointer r2
    //     0x7bef5c: add             x2, x2, HEAP, lsl #32
    // 0x7bef60: ldr             x0, [fp, #0x10]
    // 0x7bef64: r1 = Null
    //     0x7bef64: mov             x1, NULL
    // 0x7bef68: cmp             w2, NULL
    // 0x7bef6c: b.eq            #0x7bef90
    // 0x7bef70: LoadField: r4 = r2->field_17
    //     0x7bef70: ldur            w4, [x2, #0x17]
    // 0x7bef74: DecompressPointer r4
    //     0x7bef74: add             x4, x4, HEAP, lsl #32
    // 0x7bef78: r8 = X0 bound StatefulWidget
    //     0x7bef78: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bef7c: ldr             x8, [x8, #0x858]
    // 0x7bef80: LoadField: r9 = r4->field_7
    //     0x7bef80: ldur            x9, [x4, #7]
    // 0x7bef84: r3 = Null
    //     0x7bef84: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dc40] Null
    //     0x7bef88: ldr             x3, [x3, #0xc40]
    // 0x7bef8c: blr             x9
    // 0x7bef90: ldr             x16, [fp, #0x18]
    // 0x7bef94: SaveReg r16
    //     0x7bef94: str             x16, [SP, #-8]!
    // 0x7bef98: r0 = didUpdateRestorationId()
    //     0x7bef98: bl              #0x7ae62c  ; [package:extended_text_field/src/extended_text_field.dart] _ExtendedTextFieldState&State&RestorationMixin::didUpdateRestorationId
    // 0x7bef9c: add             SP, SP, #8
    // 0x7befa0: r0 = Null
    //     0x7befa0: mov             x0, NULL
    // 0x7befa4: LeaveFrame
    //     0x7befa4: mov             SP, fp
    //     0x7befa8: ldp             fp, lr, [SP], #0x10
    // 0x7befac: ret
    //     0x7befac: ret             
    // 0x7befb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7befb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7befb4: b               #0x7bef54
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52fc8, size: 0x68
    // 0xa52fc8: EnterFrame
    //     0xa52fc8: stp             fp, lr, [SP, #-0x10]!
    //     0xa52fcc: mov             fp, SP
    // 0xa52fd0: AllocStack(0x8)
    //     0xa52fd0: sub             SP, SP, #8
    // 0xa52fd4: CheckStackOverflow
    //     0xa52fd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52fd8: cmp             SP, x16
    //     0xa52fdc: b.ls            #0xa53028
    // 0xa52fe0: ldr             x0, [fp, #0x10]
    // 0xa52fe4: LoadField: r3 = r0->field_17
    //     0xa52fe4: ldur            w3, [x0, #0x17]
    // 0xa52fe8: DecompressPointer r3
    //     0xa52fe8: add             x3, x3, HEAP, lsl #32
    // 0xa52fec: stur            x3, [fp, #-8]
    // 0xa52ff0: r1 = Function '<anonymous closure>':.
    //     0xa52ff0: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc38] AnonymousClosure: (0xa4f4b4), in [package:flutter/src/material/scaffold.dart] _ScaffoldState&State&TickerProviderStateMixin&RestorationMixin::dispose (0xa4f500)
    //     0xa52ff4: ldr             x1, [x1, #0xc38]
    // 0xa52ff8: r2 = Null
    //     0xa52ff8: mov             x2, NULL
    // 0xa52ffc: r0 = AllocateClosure()
    //     0xa52ffc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa53000: ldur            x16, [fp, #-8]
    // 0xa53004: stp             x0, x16, [SP, #-0x10]!
    // 0xa53008: r0 = forEach()
    //     0xa53008: bl              #0xca3d28  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::forEach
    // 0xa5300c: add             SP, SP, #0x10
    // 0xa53010: ldr             x1, [fp, #0x10]
    // 0xa53014: StoreField: r1->field_13 = rNULL
    //     0xa53014: stur            NULL, [x1, #0x13]
    // 0xa53018: r0 = Null
    //     0xa53018: mov             x0, NULL
    // 0xa5301c: LeaveFrame
    //     0xa5301c: mov             SP, fp
    //     0xa53020: ldp             fp, lr, [SP], #0x10
    // 0xa53024: ret
    //     0xa53024: ret             
    // 0xa53028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53028: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5302c: b               #0xa52fe0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa53030, size: 0x48
    // 0xa53030: EnterFrame
    //     0xa53030: stp             fp, lr, [SP, #-0x10]!
    //     0xa53034: mov             fp, SP
    // 0xa53038: ldr             x0, [fp, #0x10]
    // 0xa5303c: LoadField: r1 = r0->field_17
    //     0xa5303c: ldur            w1, [x0, #0x17]
    // 0xa53040: DecompressPointer r1
    //     0xa53040: add             x1, x1, HEAP, lsl #32
    // 0xa53044: CheckStackOverflow
    //     0xa53044: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa53048: cmp             SP, x16
    //     0xa5304c: b.ls            #0xa53070
    // 0xa53050: LoadField: r0 = r1->field_f
    //     0xa53050: ldur            w0, [x1, #0xf]
    // 0xa53054: DecompressPointer r0
    //     0xa53054: add             x0, x0, HEAP, lsl #32
    // 0xa53058: SaveReg r0
    //     0xa53058: str             x0, [SP, #-8]!
    // 0xa5305c: r0 = dispose()
    //     0xa5305c: bl              #0xa52fc8  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::dispose
    // 0xa53060: add             SP, SP, #8
    // 0xa53064: LeaveFrame
    //     0xa53064: mov             SP, fp
    //     0xa53068: ldp             fp, lr, [SP], #0x10
    // 0xa5306c: ret
    //     0xa5306c: ret             
    // 0xa53070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53070: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa53074: b               #0xa53050
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa61f5c, size: 0xd4
    // 0xa61f5c: EnterFrame
    //     0xa61f5c: stp             fp, lr, [SP, #-0x10]!
    //     0xa61f60: mov             fp, SP
    // 0xa61f64: AllocStack(0x8)
    //     0xa61f64: sub             SP, SP, #8
    // 0xa61f68: CheckStackOverflow
    //     0xa61f68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61f6c: cmp             SP, x16
    //     0xa61f70: b.ls            #0xa62020
    // 0xa61f74: ldr             x0, [fp, #0x10]
    // 0xa61f78: LoadField: r1 = r0->field_1b
    //     0xa61f78: ldur            w1, [x0, #0x1b]
    // 0xa61f7c: DecompressPointer r1
    //     0xa61f7c: add             x1, x1, HEAP, lsl #32
    // 0xa61f80: tbnz            w1, #4, #0xa61f8c
    // 0xa61f84: r1 = true
    //     0xa61f84: add             x1, NULL, #0x20  ; true
    // 0xa61f88: b               #0xa61fa0
    // 0xa61f8c: LoadField: r1 = r0->field_b
    //     0xa61f8c: ldur            w1, [x0, #0xb]
    // 0xa61f90: DecompressPointer r1
    //     0xa61f90: add             x1, x1, HEAP, lsl #32
    // 0xa61f94: cmp             w1, NULL
    // 0xa61f98: b.eq            #0xa62028
    // 0xa61f9c: r1 = false
    //     0xa61f9c: add             x1, NULL, #0x30  ; false
    // 0xa61fa0: stur            x1, [fp, #-8]
    // 0xa61fa4: LoadField: r2 = r0->field_f
    //     0xa61fa4: ldur            w2, [x0, #0xf]
    // 0xa61fa8: DecompressPointer r2
    //     0xa61fa8: add             x2, x2, HEAP, lsl #32
    // 0xa61fac: cmp             w2, NULL
    // 0xa61fb0: b.eq            #0xa6202c
    // 0xa61fb4: SaveReg r2
    //     0xa61fb4: str             x2, [SP, #-8]!
    // 0xa61fb8: r0 = maybeOf()
    //     0xa61fb8: bl              #0x79e9e4  ; [package:flutter/src/widgets/restoration.dart] RestorationScope::maybeOf
    // 0xa61fbc: add             SP, SP, #8
    // 0xa61fc0: mov             x2, x0
    // 0xa61fc4: ldr             x1, [fp, #0x10]
    // 0xa61fc8: StoreField: r1->field_1f = r0
    //     0xa61fc8: stur            w0, [x1, #0x1f]
    //     0xa61fcc: ldurb           w16, [x1, #-1]
    //     0xa61fd0: ldurb           w17, [x0, #-1]
    //     0xa61fd4: and             x16, x17, x16, lsr #2
    //     0xa61fd8: tst             x16, HEAP, lsr #32
    //     0xa61fdc: b.eq            #0xa61fe4
    //     0xa61fe0: bl              #0xd6826c
    // 0xa61fe4: stp             x2, x1, [SP, #-0x10]!
    // 0xa61fe8: ldur            x16, [fp, #-8]
    // 0xa61fec: SaveReg r16
    //     0xa61fec: str             x16, [SP, #-8]!
    // 0xa61ff0: r0 = _updateBucketIfNecessary()
    //     0xa61ff0: bl              #0xa6222c  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::_updateBucketIfNecessary
    // 0xa61ff4: add             SP, SP, #0x18
    // 0xa61ff8: ldur            x0, [fp, #-8]
    // 0xa61ffc: tbnz            w0, #4, #0xa62010
    // 0xa62000: ldr             x16, [fp, #0x10]
    // 0xa62004: SaveReg r16
    //     0xa62004: str             x16, [SP, #-8]!
    // 0xa62008: r0 = _doRestore()
    //     0xa62008: bl              #0xa62030  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::_doRestore
    // 0xa6200c: add             SP, SP, #8
    // 0xa62010: r0 = Null
    //     0xa62010: mov             x0, NULL
    // 0xa62014: LeaveFrame
    //     0xa62014: mov             SP, fp
    //     0xa62018: ldp             fp, lr, [SP], #0x10
    // 0xa6201c: ret
    //     0xa6201c: ret             
    // 0xa62020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62020: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62024: b               #0xa61f74
    // 0xa62028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa62028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6202c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6202c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _doRestore(/* No info */) {
    // ** addr: 0xa62030, size: 0x50
    // 0xa62030: EnterFrame
    //     0xa62030: stp             fp, lr, [SP, #-0x10]!
    //     0xa62034: mov             fp, SP
    // 0xa62038: CheckStackOverflow
    //     0xa62038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6203c: cmp             SP, x16
    //     0xa62040: b.ls            #0xa62078
    // 0xa62044: ldr             x0, [fp, #0x10]
    // 0xa62048: LoadField: r1 = r0->field_1b
    //     0xa62048: ldur            w1, [x0, #0x1b]
    // 0xa6204c: DecompressPointer r1
    //     0xa6204c: add             x1, x1, HEAP, lsl #32
    // 0xa62050: stp             x1, x0, [SP, #-0x10]!
    // 0xa62054: r0 = restoreState()
    //     0xa62054: bl              #0xa62080  ; [package:flutter/src/material/text_field.dart] _TextFieldState::restoreState
    // 0xa62058: add             SP, SP, #0x10
    // 0xa6205c: ldr             x2, [fp, #0x10]
    // 0xa62060: r1 = false
    //     0xa62060: add             x1, NULL, #0x30  ; false
    // 0xa62064: StoreField: r2->field_1b = r1
    //     0xa62064: stur            w1, [x2, #0x1b]
    // 0xa62068: r0 = Null
    //     0xa62068: mov             x0, NULL
    // 0xa6206c: LeaveFrame
    //     0xa6206c: mov             SP, fp
    //     0xa62070: ldp             fp, lr, [SP], #0x10
    // 0xa62074: ret
    //     0xa62074: ret             
    // 0xa62078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6207c: b               #0xa62044
  }
  _ registerForRestoration(/* No info */) {
    // ** addr: 0xa6211c, size: 0x110
    // 0xa6211c: EnterFrame
    //     0xa6211c: stp             fp, lr, [SP, #-0x10]!
    //     0xa62120: mov             fp, SP
    // 0xa62124: AllocStack(0x20)
    //     0xa62124: sub             SP, SP, #0x20
    // 0xa62128: CheckStackOverflow
    //     0xa62128: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6212c: cmp             SP, x16
    //     0xa62130: b.ls            #0xa62224
    // 0xa62134: r1 = 2
    //     0xa62134: mov             x1, #2
    // 0xa62138: r0 = AllocateContext()
    //     0xa62138: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6213c: mov             x1, x0
    // 0xa62140: ldr             x0, [fp, #0x18]
    // 0xa62144: stur            x1, [fp, #-8]
    // 0xa62148: StoreField: r1->field_f = r0
    //     0xa62148: stur            w0, [x1, #0xf]
    // 0xa6214c: ldr             x2, [fp, #0x10]
    // 0xa62150: StoreField: r1->field_13 = r2
    //     0xa62150: stur            w2, [x1, #0x13]
    // 0xa62154: SaveReg r2
    //     0xa62154: str             x2, [SP, #-8]!
    // 0xa62158: r0 = createDefaultValue()
    //     0xa62158: bl              #0xc3bcb8  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableTextEditingController::createDefaultValue
    // 0xa6215c: add             SP, SP, #8
    // 0xa62160: ldur            x2, [fp, #-8]
    // 0xa62164: stur            x0, [fp, #-0x10]
    // 0xa62168: LoadField: r1 = r2->field_13
    //     0xa62168: ldur            w1, [x2, #0x13]
    // 0xa6216c: DecompressPointer r1
    //     0xa6216c: add             x1, x1, HEAP, lsl #32
    // 0xa62170: LoadField: r3 = r1->field_2b
    //     0xa62170: ldur            w3, [x1, #0x2b]
    // 0xa62174: DecompressPointer r3
    //     0xa62174: add             x3, x3, HEAP, lsl #32
    // 0xa62178: cmp             w3, NULL
    // 0xa6217c: b.ne            #0xa621f8
    // 0xa62180: ldr             x3, [fp, #0x18]
    // 0xa62184: r16 = "controller"
    //     0xa62184: ldr             x16, [PP, #0x5018]  ; [pp+0x5018] "controller"
    // 0xa62188: stp             x16, x1, [SP, #-0x10]!
    // 0xa6218c: SaveReg r3
    //     0xa6218c: str             x3, [SP, #-8]!
    // 0xa62190: r0 = _register()
    //     0xa62190: bl              #0xa600bc  ; [package:flutter/src/widgets/restoration.dart] RestorableProperty::_register
    // 0xa62194: add             SP, SP, #0x18
    // 0xa62198: ldur            x0, [fp, #-8]
    // 0xa6219c: LoadField: r3 = r0->field_13
    //     0xa6219c: ldur            w3, [x0, #0x13]
    // 0xa621a0: DecompressPointer r3
    //     0xa621a0: add             x3, x3, HEAP, lsl #32
    // 0xa621a4: mov             x2, x0
    // 0xa621a8: stur            x3, [fp, #-0x18]
    // 0xa621ac: r1 = Function 'listener':.
    //     0xa621ac: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc50] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa621b0: ldr             x1, [x1, #0xc50]
    // 0xa621b4: r0 = AllocateClosure()
    //     0xa621b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa621b8: stur            x0, [fp, #-0x20]
    // 0xa621bc: ldur            x16, [fp, #-0x18]
    // 0xa621c0: stp             x0, x16, [SP, #-0x10]!
    // 0xa621c4: r0 = addListener()
    //     0xa621c4: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0xa621c8: add             SP, SP, #0x10
    // 0xa621cc: ldr             x0, [fp, #0x18]
    // 0xa621d0: LoadField: r1 = r0->field_17
    //     0xa621d0: ldur            w1, [x0, #0x17]
    // 0xa621d4: DecompressPointer r1
    //     0xa621d4: add             x1, x1, HEAP, lsl #32
    // 0xa621d8: ldur            x0, [fp, #-8]
    // 0xa621dc: LoadField: r2 = r0->field_13
    //     0xa621dc: ldur            w2, [x0, #0x13]
    // 0xa621e0: DecompressPointer r2
    //     0xa621e0: add             x2, x2, HEAP, lsl #32
    // 0xa621e4: stp             x2, x1, [SP, #-0x10]!
    // 0xa621e8: ldur            x16, [fp, #-0x20]
    // 0xa621ec: SaveReg r16
    //     0xa621ec: str             x16, [SP, #-8]!
    // 0xa621f0: r0 = []=()
    //     0xa621f0: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0xa621f4: add             SP, SP, #0x18
    // 0xa621f8: ldur            x0, [fp, #-8]
    // 0xa621fc: LoadField: r1 = r0->field_13
    //     0xa621fc: ldur            w1, [x0, #0x13]
    // 0xa62200: DecompressPointer r1
    //     0xa62200: add             x1, x1, HEAP, lsl #32
    // 0xa62204: ldur            x16, [fp, #-0x10]
    // 0xa62208: stp             x16, x1, [SP, #-0x10]!
    // 0xa6220c: r0 = initWithValue()
    //     0xa6220c: bl              #0xc3ba4c  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::initWithValue
    // 0xa62210: add             SP, SP, #0x10
    // 0xa62214: r0 = Null
    //     0xa62214: mov             x0, NULL
    // 0xa62218: LeaveFrame
    //     0xa62218: mov             SP, fp
    //     0xa6221c: ldp             fp, lr, [SP], #0x10
    // 0xa62220: ret
    //     0xa62220: ret             
    // 0xa62224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62224: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62228: b               #0xa62134
  }
  _ _updateBucketIfNecessary(/* No info */) {
    // ** addr: 0xa6222c, size: 0x54
    // 0xa6222c: EnterFrame
    //     0xa6222c: stp             fp, lr, [SP, #-0x10]!
    //     0xa62230: mov             fp, SP
    // 0xa62234: CheckStackOverflow
    //     0xa62234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa62238: cmp             SP, x16
    //     0xa6223c: b.ls            #0xa62274
    // 0xa62240: ldr             x0, [fp, #0x20]
    // 0xa62244: LoadField: r1 = r0->field_b
    //     0xa62244: ldur            w1, [x0, #0xb]
    // 0xa62248: DecompressPointer r1
    //     0xa62248: add             x1, x1, HEAP, lsl #32
    // 0xa6224c: cmp             w1, NULL
    // 0xa62250: b.eq            #0xa6227c
    // 0xa62254: stp             NULL, x0, [SP, #-0x10]!
    // 0xa62258: ldr             x16, [fp, #0x10]
    // 0xa6225c: SaveReg r16
    //     0xa6225c: str             x16, [SP, #-8]!
    // 0xa62260: r0 = _simpleInstanceOfFalse()
    //     0xa62260: bl              #0xd67368  ; [dart:core] Object::_simpleInstanceOfFalse
    // 0xa62264: add             SP, SP, #0x18
    // 0xa62268: LeaveFrame
    //     0xa62268: mov             SP, fp
    //     0xa6226c: ldp             fp, lr, [SP], #0x10
    // 0xa62270: ret
    //     0xa62270: ret             
    // 0xa62274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62278: b               #0xa62240
    // 0xa6227c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6227c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3270, size: 0x40, field offset: 0x24
class _TextFieldState extends __TextFieldState&State&RestorationMixin
    implements TextSelectionGestureDetectorBuilderDelegate, AutofillClient {

  late _TextFieldSelectionGestureDetectorBuilder _selectionGestureDetectorBuilder; // offset: 0x34
  late bool forcePressEnabled; // offset: 0x38

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bed14, size: 0x100
    // 0x7bed14: EnterFrame
    //     0x7bed14: stp             fp, lr, [SP, #-0x10]!
    //     0x7bed18: mov             fp, SP
    // 0x7bed1c: AllocStack(0x8)
    //     0x7bed1c: sub             SP, SP, #8
    // 0x7bed20: CheckStackOverflow
    //     0x7bed20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bed24: cmp             SP, x16
    //     0x7bed28: b.ls            #0x7bee04
    // 0x7bed2c: ldr             x0, [fp, #0x10]
    // 0x7bed30: r2 = Null
    //     0x7bed30: mov             x2, NULL
    // 0x7bed34: r1 = Null
    //     0x7bed34: mov             x1, NULL
    // 0x7bed38: r4 = 59
    //     0x7bed38: mov             x4, #0x3b
    // 0x7bed3c: branchIfSmi(r0, 0x7bed48)
    //     0x7bed3c: tbz             w0, #0, #0x7bed48
    // 0x7bed40: r4 = LoadClassIdInstr(r0)
    //     0x7bed40: ldur            x4, [x0, #-1]
    //     0x7bed44: ubfx            x4, x4, #0xc, #0x14
    // 0x7bed48: r17 = 4115
    //     0x7bed48: mov             x17, #0x1013
    // 0x7bed4c: cmp             x4, x17
    // 0x7bed50: b.eq            #0x7bed68
    // 0x7bed54: r8 = TextField
    //     0x7bed54: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2dfc8] Type: TextField
    //     0x7bed58: ldr             x8, [x8, #0xfc8]
    // 0x7bed5c: r3 = Null
    //     0x7bed5c: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dfd0] Null
    //     0x7bed60: ldr             x3, [x3, #0xfd0]
    // 0x7bed64: r0 = TextField()
    //     0x7bed64: bl              #0x7befb8  ; IsType_TextField_Stub
    // 0x7bed68: ldr             x16, [fp, #0x18]
    // 0x7bed6c: ldr             lr, [fp, #0x10]
    // 0x7bed70: stp             lr, x16, [SP, #-0x10]!
    // 0x7bed74: r0 = didUpdateWidget()
    //     0x7bed74: bl              #0x7bef40  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::didUpdateWidget
    // 0x7bed78: add             SP, SP, #0x10
    // 0x7bed7c: ldr             x0, [fp, #0x18]
    // 0x7bed80: LoadField: r1 = r0->field_b
    //     0x7bed80: ldur            w1, [x0, #0xb]
    // 0x7bed84: DecompressPointer r1
    //     0x7bed84: add             x1, x1, HEAP, lsl #32
    // 0x7bed88: cmp             w1, NULL
    // 0x7bed8c: b.eq            #0x7bee0c
    // 0x7bed90: SaveReg r0
    //     0x7bed90: str             x0, [SP, #-8]!
    // 0x7bed94: r0 = _effectiveFocusNode()
    //     0x7bed94: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x7bed98: add             SP, SP, #8
    // 0x7bed9c: stur            x0, [fp, #-8]
    // 0x7beda0: ldr             x16, [fp, #0x18]
    // 0x7beda4: SaveReg r16
    //     0x7beda4: str             x16, [SP, #-8]!
    // 0x7beda8: r0 = _canRequestFocus()
    //     0x7beda8: bl              #0x7bee14  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_canRequestFocus
    // 0x7bedac: add             SP, SP, #8
    // 0x7bedb0: ldur            x16, [fp, #-8]
    // 0x7bedb4: stp             x0, x16, [SP, #-0x10]!
    // 0x7bedb8: r0 = canRequestFocus=()
    //     0x7bedb8: bl              #0x7acbf0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0x7bedbc: add             SP, SP, #0x10
    // 0x7bedc0: ldr             x16, [fp, #0x18]
    // 0x7bedc4: SaveReg r16
    //     0x7bedc4: str             x16, [SP, #-8]!
    // 0x7bedc8: r0 = _effectiveFocusNode()
    //     0x7bedc8: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x7bedcc: add             SP, SP, #8
    // 0x7bedd0: SaveReg r0
    //     0x7bedd0: str             x0, [SP, #-8]!
    // 0x7bedd4: r0 = hasFocus()
    //     0x7bedd4: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x7bedd8: add             SP, SP, #8
    // 0x7beddc: tbnz            w0, #4, #0x7bedf4
    // 0x7bede0: ldr             x1, [fp, #0x18]
    // 0x7bede4: LoadField: r2 = r1->field_b
    //     0x7bede4: ldur            w2, [x1, #0xb]
    // 0x7bede8: DecompressPointer r2
    //     0x7bede8: add             x2, x2, HEAP, lsl #32
    // 0x7bedec: cmp             w2, NULL
    // 0x7bedf0: b.eq            #0x7bee10
    // 0x7bedf4: r0 = Null
    //     0x7bedf4: mov             x0, NULL
    // 0x7bedf8: LeaveFrame
    //     0x7bedf8: mov             SP, fp
    //     0x7bedfc: ldp             fp, lr, [SP], #0x10
    // 0x7bee00: ret
    //     0x7bee00: ret             
    // 0x7bee04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bee04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bee08: b               #0x7bed2c
    // 0x7bee0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bee0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bee10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bee10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canRequestFocus(/* No info */) {
    // ** addr: 0x7bee14, size: 0xd4
    // 0x7bee14: EnterFrame
    //     0x7bee14: stp             fp, lr, [SP, #-0x10]!
    //     0x7bee18: mov             fp, SP
    // 0x7bee1c: CheckStackOverflow
    //     0x7bee1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bee20: cmp             SP, x16
    //     0x7bee24: b.ls            #0x7beed8
    // 0x7bee28: ldr             x0, [fp, #0x10]
    // 0x7bee2c: LoadField: r1 = r0->field_f
    //     0x7bee2c: ldur            w1, [x0, #0xf]
    // 0x7bee30: DecompressPointer r1
    //     0x7bee30: add             x1, x1, HEAP, lsl #32
    // 0x7bee34: cmp             w1, NULL
    // 0x7bee38: b.eq            #0x7beee0
    // 0x7bee3c: SaveReg r1
    //     0x7bee3c: str             x1, [SP, #-8]!
    // 0x7bee40: r0 = maybeOf()
    //     0x7bee40: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x7bee44: add             SP, SP, #8
    // 0x7bee48: cmp             w0, NULL
    // 0x7bee4c: b.ne            #0x7bee58
    // 0x7bee50: r1 = Null
    //     0x7bee50: mov             x1, NULL
    // 0x7bee54: b               #0x7bee60
    // 0x7bee58: r1 = Instance_NavigationMode
    //     0x7bee58: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x7bee5c: ldr             x1, [x1, #0x4f0]
    // 0x7bee60: cmp             w1, NULL
    // 0x7bee64: b.ne            #0x7bee70
    // 0x7bee68: r1 = Instance_NavigationMode
    //     0x7bee68: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x7bee6c: ldr             x1, [x1, #0x4f0]
    // 0x7bee70: LoadField: r2 = r1->field_7
    //     0x7bee70: ldur            x2, [x1, #7]
    // 0x7bee74: cmp             x2, #0
    // 0x7bee78: b.gt            #0x7beec8
    // 0x7bee7c: ldr             x1, [fp, #0x10]
    // 0x7bee80: LoadField: r2 = r1->field_b
    //     0x7bee80: ldur            w2, [x1, #0xb]
    // 0x7bee84: DecompressPointer r2
    //     0x7bee84: add             x2, x2, HEAP, lsl #32
    // 0x7bee88: cmp             w2, NULL
    // 0x7bee8c: b.eq            #0x7beee4
    // 0x7bee90: LoadField: r1 = r2->field_8b
    //     0x7bee90: ldur            w1, [x2, #0x8b]
    // 0x7bee94: DecompressPointer r1
    //     0x7bee94: add             x1, x1, HEAP, lsl #32
    // 0x7bee98: cmp             w1, NULL
    // 0x7bee9c: b.ne            #0x7beeb8
    // 0x7beea0: LoadField: r3 = r2->field_17
    //     0x7beea0: ldur            w3, [x2, #0x17]
    // 0x7beea4: DecompressPointer r3
    //     0x7beea4: add             x3, x3, HEAP, lsl #32
    // 0x7beea8: LoadField: r2 = r3->field_bf
    //     0x7beea8: ldur            w2, [x3, #0xbf]
    // 0x7beeac: DecompressPointer r2
    //     0x7beeac: add             x2, x2, HEAP, lsl #32
    // 0x7beeb0: mov             x0, x2
    // 0x7beeb4: b               #0x7beebc
    // 0x7beeb8: mov             x0, x1
    // 0x7beebc: LeaveFrame
    //     0x7beebc: mov             SP, fp
    //     0x7beec0: ldp             fp, lr, [SP], #0x10
    // 0x7beec4: ret
    //     0x7beec4: ret             
    // 0x7beec8: r0 = true
    //     0x7beec8: add             x0, NULL, #0x20  ; true
    // 0x7beecc: LeaveFrame
    //     0x7beecc: mov             SP, fp
    //     0x7beed0: ldp             fp, lr, [SP], #0x10
    // 0x7beed4: ret
    //     0x7beed4: ret             
    // 0x7beed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7beed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7beedc: b               #0x7bee28
    // 0x7beee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7beee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7beee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7beee4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _isEnabled(/* No info */) {
    // ** addr: 0x7beee8, size: 0x58
    // 0x7beee8: EnterFrame
    //     0x7beee8: stp             fp, lr, [SP, #-0x10]!
    //     0x7beeec: mov             fp, SP
    // 0x7beef0: ldr             x1, [fp, #0x10]
    // 0x7beef4: LoadField: r2 = r1->field_b
    //     0x7beef4: ldur            w2, [x1, #0xb]
    // 0x7beef8: DecompressPointer r2
    //     0x7beef8: add             x2, x2, HEAP, lsl #32
    // 0x7beefc: cmp             w2, NULL
    // 0x7bef00: b.eq            #0x7bef3c
    // 0x7bef04: LoadField: r1 = r2->field_8b
    //     0x7bef04: ldur            w1, [x2, #0x8b]
    // 0x7bef08: DecompressPointer r1
    //     0x7bef08: add             x1, x1, HEAP, lsl #32
    // 0x7bef0c: cmp             w1, NULL
    // 0x7bef10: b.ne            #0x7bef2c
    // 0x7bef14: LoadField: r3 = r2->field_17
    //     0x7bef14: ldur            w3, [x2, #0x17]
    // 0x7bef18: DecompressPointer r3
    //     0x7bef18: add             x3, x3, HEAP, lsl #32
    // 0x7bef1c: LoadField: r2 = r3->field_bf
    //     0x7bef1c: ldur            w2, [x3, #0xbf]
    // 0x7bef20: DecompressPointer r2
    //     0x7bef20: add             x2, x2, HEAP, lsl #32
    // 0x7bef24: mov             x0, x2
    // 0x7bef28: b               #0x7bef30
    // 0x7bef2c: mov             x0, x1
    // 0x7bef30: LeaveFrame
    //     0x7bef30: mov             SP, fp
    //     0x7bef34: ldp             fp, lr, [SP], #0x10
    // 0x7bef38: ret
    //     0x7bef38: ret             
    // 0x7bef3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bef3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83d684, size: 0x48
    // 0x83d684: ldr             x1, [SP]
    // 0x83d688: LoadField: r2 = r1->field_17
    //     0x83d688: ldur            w2, [x1, #0x17]
    // 0x83d68c: DecompressPointer r2
    //     0x83d68c: add             x2, x2, HEAP, lsl #32
    // 0x83d690: LoadField: r1 = r2->field_f
    //     0x83d690: ldur            w1, [x2, #0xf]
    // 0x83d694: DecompressPointer r1
    //     0x83d694: add             x1, x1, HEAP, lsl #32
    // 0x83d698: LoadField: r0 = r2->field_13
    //     0x83d698: ldur            w0, [x2, #0x13]
    // 0x83d69c: DecompressPointer r0
    //     0x83d69c: add             x0, x0, HEAP, lsl #32
    // 0x83d6a0: StoreField: r1->field_2b = r0
    //     0x83d6a0: stur            w0, [x1, #0x2b]
    //     0x83d6a4: ldurb           w16, [x1, #-1]
    //     0x83d6a8: ldurb           w17, [x0, #-1]
    //     0x83d6ac: and             x16, x17, x16, lsr #2
    //     0x83d6b0: tst             x16, HEAP, lsr #32
    //     0x83d6b4: b.eq            #0x83d6c4
    //     0x83d6b8: str             lr, [SP, #-8]!
    //     0x83d6bc: bl              #0xd6826c
    //     0x83d6c0: ldr             lr, [SP], #8
    // 0x83d6c4: r0 = Null
    //     0x83d6c4: mov             x0, NULL
    // 0x83d6c8: ret
    //     0x83d6c8: ret             
  }
  _ _handleHover(/* No info */) {
    // ** addr: 0x83d6cc, size: 0x78
    // 0x83d6cc: EnterFrame
    //     0x83d6cc: stp             fp, lr, [SP, #-0x10]!
    //     0x83d6d0: mov             fp, SP
    // 0x83d6d4: CheckStackOverflow
    //     0x83d6d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d6d8: cmp             SP, x16
    //     0x83d6dc: b.ls            #0x83d73c
    // 0x83d6e0: r1 = 2
    //     0x83d6e0: mov             x1, #2
    // 0x83d6e4: r0 = AllocateContext()
    //     0x83d6e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83d6e8: mov             x1, x0
    // 0x83d6ec: ldr             x0, [fp, #0x18]
    // 0x83d6f0: StoreField: r1->field_f = r0
    //     0x83d6f0: stur            w0, [x1, #0xf]
    // 0x83d6f4: ldr             x2, [fp, #0x10]
    // 0x83d6f8: StoreField: r1->field_13 = r2
    //     0x83d6f8: stur            w2, [x1, #0x13]
    // 0x83d6fc: LoadField: r3 = r0->field_2b
    //     0x83d6fc: ldur            w3, [x0, #0x2b]
    // 0x83d700: DecompressPointer r3
    //     0x83d700: add             x3, x3, HEAP, lsl #32
    // 0x83d704: cmp             w2, w3
    // 0x83d708: b.eq            #0x83d72c
    // 0x83d70c: mov             x2, x1
    // 0x83d710: r1 = Function '<anonymous closure>':.
    //     0x83d710: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dd28] AnonymousClosure: (0x83d684), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover (0x83d6cc)
    //     0x83d714: ldr             x1, [x1, #0xd28]
    // 0x83d718: r0 = AllocateClosure()
    //     0x83d718: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83d71c: ldr             x16, [fp, #0x18]
    // 0x83d720: stp             x0, x16, [SP, #-0x10]!
    // 0x83d724: r0 = setState()
    //     0x83d724: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83d728: add             SP, SP, #0x10
    // 0x83d72c: r0 = Null
    //     0x83d72c: mov             x0, NULL
    // 0x83d730: LeaveFrame
    //     0x83d730: mov             SP, fp
    //     0x83d734: ldp             fp, lr, [SP], #0x10
    // 0x83d738: ret
    //     0x83d738: ret             
    // 0x83d73c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d73c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d740: b               #0x83d6e0
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x83e594, size: 0x48
    // 0x83e594: ldr             x1, [SP]
    // 0x83e598: LoadField: r2 = r1->field_17
    //     0x83e598: ldur            w2, [x1, #0x17]
    // 0x83e59c: DecompressPointer r2
    //     0x83e59c: add             x2, x2, HEAP, lsl #32
    // 0x83e5a0: LoadField: r1 = r2->field_f
    //     0x83e5a0: ldur            w1, [x2, #0xf]
    // 0x83e5a4: DecompressPointer r1
    //     0x83e5a4: add             x1, x1, HEAP, lsl #32
    // 0x83e5a8: LoadField: r0 = r2->field_13
    //     0x83e5a8: ldur            w0, [x2, #0x13]
    // 0x83e5ac: DecompressPointer r0
    //     0x83e5ac: add             x0, x0, HEAP, lsl #32
    // 0x83e5b0: StoreField: r1->field_2f = r0
    //     0x83e5b0: stur            w0, [x1, #0x2f]
    //     0x83e5b4: ldurb           w16, [x1, #-1]
    //     0x83e5b8: ldurb           w17, [x0, #-1]
    //     0x83e5bc: and             x16, x17, x16, lsr #2
    //     0x83e5c0: tst             x16, HEAP, lsr #32
    //     0x83e5c4: b.eq            #0x83e5d4
    //     0x83e5c8: str             lr, [SP, #-8]!
    //     0x83e5cc: bl              #0xd6826c
    //     0x83e5d0: ldr             lr, [SP], #8
    // 0x83e5d4: r0 = Null
    //     0x83e5d4: mov             x0, NULL
    // 0x83e5d8: ret
    //     0x83e5d8: ret             
  }
  _ _handleSelectionChanged(/* No info */) {
    // ** addr: 0x83e5dc, size: 0x19c
    // 0x83e5dc: EnterFrame
    //     0x83e5dc: stp             fp, lr, [SP, #-0x10]!
    //     0x83e5e0: mov             fp, SP
    // 0x83e5e4: AllocStack(0x8)
    //     0x83e5e4: sub             SP, SP, #8
    // 0x83e5e8: CheckStackOverflow
    //     0x83e5e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e5ec: cmp             SP, x16
    //     0x83e5f0: b.ls            #0x83e768
    // 0x83e5f4: r1 = 2
    //     0x83e5f4: mov             x1, #2
    // 0x83e5f8: r0 = AllocateContext()
    //     0x83e5f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83e5fc: mov             x1, x0
    // 0x83e600: ldr             x0, [fp, #0x20]
    // 0x83e604: stur            x1, [fp, #-8]
    // 0x83e608: StoreField: r1->field_f = r0
    //     0x83e608: stur            w0, [x1, #0xf]
    // 0x83e60c: ldr             x16, [fp, #0x10]
    // 0x83e610: stp             x16, x0, [SP, #-0x10]!
    // 0x83e614: r0 = _shouldShowSelectionHandles()
    //     0x83e614: bl              #0x83e9dc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_shouldShowSelectionHandles
    // 0x83e618: add             SP, SP, #0x10
    // 0x83e61c: ldur            x2, [fp, #-8]
    // 0x83e620: StoreField: r2->field_13 = r0
    //     0x83e620: stur            w0, [x2, #0x13]
    // 0x83e624: ldr             x3, [fp, #0x20]
    // 0x83e628: LoadField: r1 = r3->field_2f
    //     0x83e628: ldur            w1, [x3, #0x2f]
    // 0x83e62c: DecompressPointer r1
    //     0x83e62c: add             x1, x1, HEAP, lsl #32
    // 0x83e630: cmp             w0, w1
    // 0x83e634: b.eq            #0x83e654
    // 0x83e638: r1 = Function '<anonymous closure>':.
    //     0x83e638: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dd70] AnonymousClosure: (0x83e594), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged (0x83e5dc)
    //     0x83e63c: ldr             x1, [x1, #0xd70]
    // 0x83e640: r0 = AllocateClosure()
    //     0x83e640: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83e644: ldr             x16, [fp, #0x20]
    // 0x83e648: stp             x0, x16, [SP, #-0x10]!
    // 0x83e64c: r0 = setState()
    //     0x83e64c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x83e650: add             SP, SP, #0x10
    // 0x83e654: ldr             x0, [fp, #0x20]
    // 0x83e658: ldr             x1, [fp, #0x10]
    // 0x83e65c: LoadField: r2 = r0->field_f
    //     0x83e65c: ldur            w2, [x0, #0xf]
    // 0x83e660: DecompressPointer r2
    //     0x83e660: add             x2, x2, HEAP, lsl #32
    // 0x83e664: cmp             w2, NULL
    // 0x83e668: b.eq            #0x83e770
    // 0x83e66c: SaveReg r2
    //     0x83e66c: str             x2, [SP, #-8]!
    // 0x83e670: r0 = of()
    //     0x83e670: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83e674: add             SP, SP, #8
    // 0x83e678: ldr             x0, [fp, #0x10]
    // 0x83e67c: r16 = Instance_SelectionChangedCause
    //     0x83e67c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83e680: ldr             x16, [x16, #0x6b0]
    // 0x83e684: cmp             w0, w16
    // 0x83e688: b.eq            #0x83e69c
    // 0x83e68c: r16 = Instance_SelectionChangedCause
    //     0x83e68c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x83e690: ldr             x16, [x16, #0x6d0]
    // 0x83e694: cmp             w0, w16
    // 0x83e698: b.ne            #0x83e6e0
    // 0x83e69c: ldr             x1, [fp, #0x20]
    // 0x83e6a0: LoadField: r2 = r1->field_3b
    //     0x83e6a0: ldur            w2, [x1, #0x3b]
    // 0x83e6a4: DecompressPointer r2
    //     0x83e6a4: add             x2, x2, HEAP, lsl #32
    // 0x83e6a8: SaveReg r2
    //     0x83e6a8: str             x2, [SP, #-8]!
    // 0x83e6ac: r0 = currentState()
    //     0x83e6ac: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83e6b0: add             SP, SP, #8
    // 0x83e6b4: stur            x0, [fp, #-8]
    // 0x83e6b8: cmp             w0, NULL
    // 0x83e6bc: b.eq            #0x83e6e0
    // 0x83e6c0: ldr             x16, [fp, #0x18]
    // 0x83e6c4: SaveReg r16
    //     0x83e6c4: str             x16, [SP, #-8]!
    // 0x83e6c8: r0 = extent()
    //     0x83e6c8: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83e6cc: add             SP, SP, #8
    // 0x83e6d0: ldur            x16, [fp, #-8]
    // 0x83e6d4: stp             x0, x16, [SP, #-0x10]!
    // 0x83e6d8: r0 = bringIntoView()
    //     0x83e6d8: bl              #0x7c92ac  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::bringIntoView
    // 0x83e6dc: add             SP, SP, #0x10
    // 0x83e6e0: ldr             x0, [fp, #0x20]
    // 0x83e6e4: LoadField: r1 = r0->field_f
    //     0x83e6e4: ldur            w1, [x0, #0xf]
    // 0x83e6e8: DecompressPointer r1
    //     0x83e6e8: add             x1, x1, HEAP, lsl #32
    // 0x83e6ec: cmp             w1, NULL
    // 0x83e6f0: b.eq            #0x83e774
    // 0x83e6f4: SaveReg r1
    //     0x83e6f4: str             x1, [SP, #-8]!
    // 0x83e6f8: r0 = of()
    //     0x83e6f8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83e6fc: add             SP, SP, #8
    // 0x83e700: LoadField: r1 = r0->field_1f
    //     0x83e700: ldur            w1, [x0, #0x1f]
    // 0x83e704: DecompressPointer r1
    //     0x83e704: add             x1, x1, HEAP, lsl #32
    // 0x83e708: LoadField: r0 = r1->field_7
    //     0x83e708: ldur            x0, [x1, #7]
    // 0x83e70c: cmp             x0, #2
    // 0x83e710: b.le            #0x83e758
    // 0x83e714: ldr             x0, [fp, #0x10]
    // 0x83e718: r16 = Instance_SelectionChangedCause
    //     0x83e718: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x83e71c: ldr             x16, [x16, #0x6d0]
    // 0x83e720: cmp             w0, w16
    // 0x83e724: b.ne            #0x83e758
    // 0x83e728: ldr             x0, [fp, #0x20]
    // 0x83e72c: LoadField: r1 = r0->field_3b
    //     0x83e72c: ldur            w1, [x0, #0x3b]
    // 0x83e730: DecompressPointer r1
    //     0x83e730: add             x1, x1, HEAP, lsl #32
    // 0x83e734: SaveReg r1
    //     0x83e734: str             x1, [SP, #-8]!
    // 0x83e738: r0 = currentState()
    //     0x83e738: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x83e73c: add             SP, SP, #8
    // 0x83e740: cmp             w0, NULL
    // 0x83e744: b.eq            #0x83e758
    // 0x83e748: SaveReg r0
    //     0x83e748: str             x0, [SP, #-8]!
    // 0x83e74c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x83e74c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x83e750: r0 = hideToolbar()
    //     0x83e750: bl              #0x83e778  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::hideToolbar
    // 0x83e754: add             SP, SP, #8
    // 0x83e758: r0 = Null
    //     0x83e758: mov             x0, NULL
    // 0x83e75c: LeaveFrame
    //     0x83e75c: mov             SP, fp
    //     0x83e760: ldp             fp, lr, [SP], #0x10
    // 0x83e764: ret
    //     0x83e764: ret             
    // 0x83e768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83e768: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83e76c: b               #0x83e5f4
    // 0x83e770: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e770: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83e774: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83e774: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _shouldShowSelectionHandles(/* No info */) {
    // ** addr: 0x83e9dc, size: 0x144
    // 0x83e9dc: EnterFrame
    //     0x83e9dc: stp             fp, lr, [SP, #-0x10]!
    //     0x83e9e0: mov             fp, SP
    // 0x83e9e4: CheckStackOverflow
    //     0x83e9e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e9e8: cmp             SP, x16
    //     0x83e9ec: b.ls            #0x83eb04
    // 0x83e9f0: ldr             x0, [fp, #0x18]
    // 0x83e9f4: LoadField: r1 = r0->field_33
    //     0x83e9f4: ldur            w1, [x0, #0x33]
    // 0x83e9f8: DecompressPointer r1
    //     0x83e9f8: add             x1, x1, HEAP, lsl #32
    // 0x83e9fc: r16 = Sentinel
    //     0x83e9fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x83ea00: cmp             w1, w16
    // 0x83ea04: b.eq            #0x83eb0c
    // 0x83ea08: LoadField: r2 = r1->field_b
    //     0x83ea08: ldur            w2, [x1, #0xb]
    // 0x83ea0c: DecompressPointer r2
    //     0x83ea0c: add             x2, x2, HEAP, lsl #32
    // 0x83ea10: tbz             w2, #4, #0x83ea24
    // 0x83ea14: r0 = false
    //     0x83ea14: add             x0, NULL, #0x30  ; false
    // 0x83ea18: LeaveFrame
    //     0x83ea18: mov             SP, fp
    //     0x83ea1c: ldp             fp, lr, [SP], #0x10
    // 0x83ea20: ret
    //     0x83ea20: ret             
    // 0x83ea24: ldr             x1, [fp, #0x10]
    // 0x83ea28: r16 = Instance_SelectionChangedCause
    //     0x83ea28: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0x83ea2c: ldr             x16, [x16, #0x6b8]
    // 0x83ea30: cmp             w1, w16
    // 0x83ea34: b.ne            #0x83ea48
    // 0x83ea38: r0 = false
    //     0x83ea38: add             x0, NULL, #0x30  ; false
    // 0x83ea3c: LeaveFrame
    //     0x83ea3c: mov             SP, fp
    //     0x83ea40: ldp             fp, lr, [SP], #0x10
    // 0x83ea44: ret
    //     0x83ea44: ret             
    // 0x83ea48: LoadField: r2 = r0->field_b
    //     0x83ea48: ldur            w2, [x0, #0xb]
    // 0x83ea4c: DecompressPointer r2
    //     0x83ea4c: add             x2, x2, HEAP, lsl #32
    // 0x83ea50: cmp             w2, NULL
    // 0x83ea54: b.eq            #0x83eb18
    // 0x83ea58: SaveReg r0
    //     0x83ea58: str             x0, [SP, #-8]!
    // 0x83ea5c: r0 = _isEnabled()
    //     0x83ea5c: bl              #0x7beee8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0x83ea60: add             SP, SP, #8
    // 0x83ea64: tbz             w0, #4, #0x83ea78
    // 0x83ea68: r0 = false
    //     0x83ea68: add             x0, NULL, #0x30  ; false
    // 0x83ea6c: LeaveFrame
    //     0x83ea6c: mov             SP, fp
    //     0x83ea70: ldp             fp, lr, [SP], #0x10
    // 0x83ea74: ret
    //     0x83ea74: ret             
    // 0x83ea78: ldr             x1, [fp, #0x10]
    // 0x83ea7c: r16 = Instance_SelectionChangedCause
    //     0x83ea7c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83ea80: ldr             x16, [x16, #0x6b0]
    // 0x83ea84: cmp             w1, w16
    // 0x83ea88: b.eq            #0x83ea9c
    // 0x83ea8c: r16 = Instance_SelectionChangedCause
    //     0x83ea8c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6e0] Obj!SelectionChangedCause@b63ef1
    //     0x83ea90: ldr             x16, [x16, #0x6e0]
    // 0x83ea94: cmp             w1, w16
    // 0x83ea98: b.ne            #0x83eaac
    // 0x83ea9c: r0 = true
    //     0x83ea9c: add             x0, NULL, #0x20  ; true
    // 0x83eaa0: LeaveFrame
    //     0x83eaa0: mov             SP, fp
    //     0x83eaa4: ldp             fp, lr, [SP], #0x10
    // 0x83eaa8: ret
    //     0x83eaa8: ret             
    // 0x83eaac: ldr             x1, [fp, #0x18]
    // 0x83eab0: LoadField: r2 = r1->field_b
    //     0x83eab0: ldur            w2, [x1, #0xb]
    // 0x83eab4: DecompressPointer r2
    //     0x83eab4: add             x2, x2, HEAP, lsl #32
    // 0x83eab8: cmp             w2, NULL
    // 0x83eabc: b.eq            #0x83eb1c
    // 0x83eac0: LoadField: r1 = r2->field_f
    //     0x83eac0: ldur            w1, [x2, #0xf]
    // 0x83eac4: DecompressPointer r1
    //     0x83eac4: add             x1, x1, HEAP, lsl #32
    // 0x83eac8: LoadField: r2 = r1->field_27
    //     0x83eac8: ldur            w2, [x1, #0x27]
    // 0x83eacc: DecompressPointer r2
    //     0x83eacc: add             x2, x2, HEAP, lsl #32
    // 0x83ead0: LoadField: r1 = r2->field_7
    //     0x83ead0: ldur            w1, [x2, #7]
    // 0x83ead4: DecompressPointer r1
    //     0x83ead4: add             x1, x1, HEAP, lsl #32
    // 0x83ead8: LoadField: r2 = r1->field_7
    //     0x83ead8: ldur            w2, [x1, #7]
    // 0x83eadc: DecompressPointer r2
    //     0x83eadc: add             x2, x2, HEAP, lsl #32
    // 0x83eae0: cbz             w2, #0x83eaf4
    // 0x83eae4: r0 = true
    //     0x83eae4: add             x0, NULL, #0x20  ; true
    // 0x83eae8: LeaveFrame
    //     0x83eae8: mov             SP, fp
    //     0x83eaec: ldp             fp, lr, [SP], #0x10
    // 0x83eaf0: ret
    //     0x83eaf0: ret             
    // 0x83eaf4: r0 = false
    //     0x83eaf4: add             x0, NULL, #0x30  ; false
    // 0x83eaf8: LeaveFrame
    //     0x83eaf8: mov             SP, fp
    //     0x83eafc: ldp             fp, lr, [SP], #0x10
    // 0x83eb00: ret
    //     0x83eb00: ret             
    // 0x83eb04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83eb04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83eb08: b               #0x83e9f0
    // 0x83eb0c: r9 = _selectionGestureDetectorBuilder
    //     0x83eb0c: add             x9, PP, #0x2d, lsl #12  ; [pp+0x2dd20] Field <_TextFieldState@823181401._selectionGestureDetectorBuilder@823181401>: late (offset: 0x34)
    //     0x83eb10: ldr             x9, [x9, #0xd20]
    // 0x83eb14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83eb14: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x83eb18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83eb18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83eb1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83eb1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionChanged(dynamic, TextSelection, SelectionChangedCause?) {
    // ** addr: 0x83eb20, size: 0x54
    // 0x83eb20: EnterFrame
    //     0x83eb20: stp             fp, lr, [SP, #-0x10]!
    //     0x83eb24: mov             fp, SP
    // 0x83eb28: ldr             x0, [fp, #0x20]
    // 0x83eb2c: LoadField: r1 = r0->field_17
    //     0x83eb2c: ldur            w1, [x0, #0x17]
    // 0x83eb30: DecompressPointer r1
    //     0x83eb30: add             x1, x1, HEAP, lsl #32
    // 0x83eb34: CheckStackOverflow
    //     0x83eb34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83eb38: cmp             SP, x16
    //     0x83eb3c: b.ls            #0x83eb6c
    // 0x83eb40: LoadField: r0 = r1->field_f
    //     0x83eb40: ldur            w0, [x1, #0xf]
    // 0x83eb44: DecompressPointer r0
    //     0x83eb44: add             x0, x0, HEAP, lsl #32
    // 0x83eb48: ldr             x16, [fp, #0x18]
    // 0x83eb4c: stp             x16, x0, [SP, #-0x10]!
    // 0x83eb50: ldr             x16, [fp, #0x10]
    // 0x83eb54: SaveReg r16
    //     0x83eb54: str             x16, [SP, #-8]!
    // 0x83eb58: r0 = _handleSelectionChanged()
    //     0x83eb58: bl              #0x83e5dc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged
    // 0x83eb5c: add             SP, SP, #0x18
    // 0x83eb60: LeaveFrame
    //     0x83eb60: mov             SP, fp
    //     0x83eb64: ldp             fp, lr, [SP], #0x10
    // 0x83eb68: ret
    //     0x83eb68: ret             
    // 0x83eb6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83eb6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83eb70: b               #0x83eb40
  }
  _ build(/* No info */) {
    // ** addr: 0x86b00c, size: 0x1178
    // 0x86b00c: EnterFrame
    //     0x86b00c: stp             fp, lr, [SP, #-0x10]!
    //     0x86b010: mov             fp, SP
    // 0x86b014: AllocStack(0x110)
    //     0x86b014: sub             SP, SP, #0x110
    // 0x86b018: CheckStackOverflow
    //     0x86b018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86b01c: cmp             SP, x16
    //     0x86b020: b.ls            #0x86c130
    // 0x86b024: r1 = 5
    //     0x86b024: mov             x1, #5
    // 0x86b028: r0 = AllocateContext()
    //     0x86b028: bl              #0xd68aa4  ; AllocateContextStub
    // 0x86b02c: mov             x1, x0
    // 0x86b030: ldr             x0, [fp, #0x18]
    // 0x86b034: stur            x1, [fp, #-8]
    // 0x86b038: StoreField: r1->field_f = r0
    //     0x86b038: stur            w0, [x1, #0xf]
    // 0x86b03c: ldr             x16, [fp, #0x10]
    // 0x86b040: SaveReg r16
    //     0x86b040: str             x16, [SP, #-8]!
    // 0x86b044: r0 = of()
    //     0x86b044: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x86b048: add             SP, SP, #8
    // 0x86b04c: stur            x0, [fp, #-0x10]
    // 0x86b050: ldr             x16, [fp, #0x10]
    // 0x86b054: SaveReg r16
    //     0x86b054: str             x16, [SP, #-8]!
    // 0x86b058: r0 = of()
    //     0x86b058: bl              #0x872148  ; [package:flutter/src/widgets/default_selection_style.dart] DefaultSelectionStyle::of
    // 0x86b05c: add             SP, SP, #8
    // 0x86b060: mov             x1, x0
    // 0x86b064: ldur            x0, [fp, #-0x10]
    // 0x86b068: stur            x1, [fp, #-0x18]
    // 0x86b06c: LoadField: r2 = r0->field_2b
    //     0x86b06c: ldur            w2, [x0, #0x2b]
    // 0x86b070: DecompressPointer r2
    //     0x86b070: add             x2, x2, HEAP, lsl #32
    // 0x86b074: tbnz            w2, #4, #0x86b094
    // 0x86b078: ldr             x16, [fp, #0x10]
    // 0x86b07c: SaveReg r16
    //     0x86b07c: str             x16, [SP, #-8]!
    // 0x86b080: r0 = _m3InputStyle()
    //     0x86b080: bl              #0x8720f4  ; [package:flutter/src/material/text_field.dart] ::_m3InputStyle
    // 0x86b084: add             SP, SP, #8
    // 0x86b088: mov             x3, x0
    // 0x86b08c: ldur            x0, [fp, #-0x10]
    // 0x86b090: b               #0x86b0b0
    // 0x86b094: LoadField: r1 = r0->field_93
    //     0x86b094: ldur            w1, [x0, #0x93]
    // 0x86b098: DecompressPointer r1
    //     0x86b098: add             x1, x1, HEAP, lsl #32
    // 0x86b09c: LoadField: r2 = r1->field_23
    //     0x86b09c: ldur            w2, [x1, #0x23]
    // 0x86b0a0: DecompressPointer r2
    //     0x86b0a0: add             x2, x2, HEAP, lsl #32
    // 0x86b0a4: cmp             w2, NULL
    // 0x86b0a8: b.eq            #0x86c138
    // 0x86b0ac: mov             x3, x2
    // 0x86b0b0: ldr             x1, [fp, #0x18]
    // 0x86b0b4: ldur            x2, [fp, #-8]
    // 0x86b0b8: LoadField: r4 = r1->field_b
    //     0x86b0b8: ldur            w4, [x1, #0xb]
    // 0x86b0bc: DecompressPointer r4
    //     0x86b0bc: add             x4, x4, HEAP, lsl #32
    // 0x86b0c0: cmp             w4, NULL
    // 0x86b0c4: b.eq            #0x86c13c
    // 0x86b0c8: LoadField: r5 = r4->field_27
    //     0x86b0c8: ldur            w5, [x4, #0x27]
    // 0x86b0cc: DecompressPointer r5
    //     0x86b0cc: add             x5, x5, HEAP, lsl #32
    // 0x86b0d0: stp             x5, x3, [SP, #-0x10]!
    // 0x86b0d4: r0 = merge()
    //     0x86b0d4: bl              #0x6cdfe0  ; [package:flutter/src/painting/text_style.dart] TextStyle::merge
    // 0x86b0d8: add             SP, SP, #0x10
    // 0x86b0dc: mov             x1, x0
    // 0x86b0e0: ldr             x0, [fp, #0x18]
    // 0x86b0e4: stur            x1, [fp, #-0x30]
    // 0x86b0e8: LoadField: r2 = r0->field_b
    //     0x86b0e8: ldur            w2, [x0, #0xb]
    // 0x86b0ec: DecompressPointer r2
    //     0x86b0ec: add             x2, x2, HEAP, lsl #32
    // 0x86b0f0: cmp             w2, NULL
    // 0x86b0f4: b.eq            #0x86c140
    // 0x86b0f8: ldur            x2, [fp, #-0x10]
    // 0x86b0fc: LoadField: r3 = r2->field_3f
    //     0x86b0fc: ldur            w3, [x2, #0x3f]
    // 0x86b100: DecompressPointer r3
    //     0x86b100: add             x3, x3, HEAP, lsl #32
    // 0x86b104: stur            x3, [fp, #-0x28]
    // 0x86b108: LoadField: r4 = r3->field_7
    //     0x86b108: ldur            w4, [x3, #7]
    // 0x86b10c: DecompressPointer r4
    //     0x86b10c: add             x4, x4, HEAP, lsl #32
    // 0x86b110: stur            x4, [fp, #-0x20]
    // 0x86b114: SaveReg r0
    //     0x86b114: str             x0, [SP, #-8]!
    // 0x86b118: r0 = restorationId()
    //     0x86b118: bl              #0x7d453c  ; [package:flutter/src/widgets/restoration.dart] _RestorationScopeState::restorationId
    // 0x86b11c: add             SP, SP, #8
    // 0x86b120: mov             x1, x0
    // 0x86b124: ldur            x2, [fp, #-8]
    // 0x86b128: stur            x1, [fp, #-0x38]
    // 0x86b12c: StoreField: r2->field_13 = r0
    //     0x86b12c: stur            w0, [x2, #0x13]
    //     0x86b130: ldurb           w16, [x2, #-1]
    //     0x86b134: ldurb           w17, [x0, #-1]
    //     0x86b138: and             x16, x17, x16, lsr #2
    //     0x86b13c: tst             x16, HEAP, lsr #32
    //     0x86b140: b.eq            #0x86b148
    //     0x86b144: bl              #0xd6828c
    // 0x86b148: ldr             x16, [fp, #0x18]
    // 0x86b14c: SaveReg r16
    //     0x86b14c: str             x16, [SP, #-8]!
    // 0x86b150: r0 = _effectiveFocusNode()
    //     0x86b150: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x86b154: add             SP, SP, #8
    // 0x86b158: mov             x1, x0
    // 0x86b15c: ldur            x2, [fp, #-8]
    // 0x86b160: stur            x1, [fp, #-0x40]
    // 0x86b164: StoreField: r2->field_17 = r0
    //     0x86b164: stur            w0, [x2, #0x17]
    //     0x86b168: ldurb           w16, [x2, #-1]
    //     0x86b16c: ldurb           w17, [x0, #-1]
    //     0x86b170: and             x16, x17, x16, lsr #2
    //     0x86b174: tst             x16, HEAP, lsr #32
    //     0x86b178: b.eq            #0x86b180
    //     0x86b17c: bl              #0xd6828c
    // 0x86b180: r16 = <TextInputFormatter>
    //     0x86b180: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dc78] TypeArguments: <TextInputFormatter>
    //     0x86b184: ldr             x16, [x16, #0xc78]
    // 0x86b188: stp             xzr, x16, [SP, #-0x10]!
    // 0x86b18c: r0 = _GrowableList()
    //     0x86b18c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x86b190: add             SP, SP, #0x10
    // 0x86b194: mov             x1, x0
    // 0x86b198: ldr             x0, [fp, #0x18]
    // 0x86b19c: stur            x1, [fp, #-0x50]
    // 0x86b1a0: LoadField: r2 = r0->field_b
    //     0x86b1a0: ldur            w2, [x0, #0xb]
    // 0x86b1a4: DecompressPointer r2
    //     0x86b1a4: add             x2, x2, HEAP, lsl #32
    // 0x86b1a8: cmp             w2, NULL
    // 0x86b1ac: b.eq            #0x86c144
    // 0x86b1b0: LoadField: r3 = r2->field_6f
    //     0x86b1b0: ldur            w3, [x2, #0x6f]
    // 0x86b1b4: DecompressPointer r3
    //     0x86b1b4: add             x3, x3, HEAP, lsl #32
    // 0x86b1b8: stur            x3, [fp, #-0x48]
    // 0x86b1bc: cmp             w3, NULL
    // 0x86b1c0: b.eq            #0x86b280
    // 0x86b1c4: SaveReg r0
    //     0x86b1c4: str             x0, [SP, #-8]!
    // 0x86b1c8: r0 = _effectiveMaxLengthEnforcement()
    //     0x86b1c8: bl              #0x83d4b8  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveMaxLengthEnforcement
    // 0x86b1cc: add             SP, SP, #8
    // 0x86b1d0: stur            x0, [fp, #-0x58]
    // 0x86b1d4: r0 = LengthLimitingTextInputFormatter()
    //     0x86b1d4: bl              #0x83d4ac  ; AllocateLengthLimitingTextInputFormatterStub -> LengthLimitingTextInputFormatter (size=0x10)
    // 0x86b1d8: mov             x1, x0
    // 0x86b1dc: ldur            x0, [fp, #-0x48]
    // 0x86b1e0: stur            x1, [fp, #-0x60]
    // 0x86b1e4: StoreField: r1->field_7 = r0
    //     0x86b1e4: stur            w0, [x1, #7]
    // 0x86b1e8: ldur            x0, [fp, #-0x58]
    // 0x86b1ec: StoreField: r1->field_b = r0
    //     0x86b1ec: stur            w0, [x1, #0xb]
    // 0x86b1f0: ldur            x0, [fp, #-0x50]
    // 0x86b1f4: LoadField: r2 = r0->field_b
    //     0x86b1f4: ldur            w2, [x0, #0xb]
    // 0x86b1f8: DecompressPointer r2
    //     0x86b1f8: add             x2, x2, HEAP, lsl #32
    // 0x86b1fc: stur            x2, [fp, #-0x48]
    // 0x86b200: LoadField: r3 = r0->field_f
    //     0x86b200: ldur            w3, [x0, #0xf]
    // 0x86b204: DecompressPointer r3
    //     0x86b204: add             x3, x3, HEAP, lsl #32
    // 0x86b208: LoadField: r4 = r3->field_b
    //     0x86b208: ldur            w4, [x3, #0xb]
    // 0x86b20c: DecompressPointer r4
    //     0x86b20c: add             x4, x4, HEAP, lsl #32
    // 0x86b210: cmp             w2, w4
    // 0x86b214: b.ne            #0x86b224
    // 0x86b218: SaveReg r0
    //     0x86b218: str             x0, [SP, #-8]!
    // 0x86b21c: r0 = _growToNextCapacity()
    //     0x86b21c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x86b220: add             SP, SP, #8
    // 0x86b224: ldur            x2, [fp, #-0x50]
    // 0x86b228: ldur            x0, [fp, #-0x48]
    // 0x86b22c: r3 = LoadInt32Instr(r0)
    //     0x86b22c: sbfx            x3, x0, #1, #0x1f
    // 0x86b230: add             x0, x3, #1
    // 0x86b234: lsl             x1, x0, #1
    // 0x86b238: StoreField: r2->field_b = r1
    //     0x86b238: stur            w1, [x2, #0xb]
    // 0x86b23c: mov             x1, x3
    // 0x86b240: cmp             x1, x0
    // 0x86b244: b.hs            #0x86c148
    // 0x86b248: LoadField: r1 = r2->field_f
    //     0x86b248: ldur            w1, [x2, #0xf]
    // 0x86b24c: DecompressPointer r1
    //     0x86b24c: add             x1, x1, HEAP, lsl #32
    // 0x86b250: ldur            x0, [fp, #-0x60]
    // 0x86b254: ArrayStore: r1[r3] = r0  ; List_4
    //     0x86b254: add             x25, x1, x3, lsl #2
    //     0x86b258: add             x25, x25, #0xf
    //     0x86b25c: str             w0, [x25]
    //     0x86b260: tbz             w0, #0, #0x86b27c
    //     0x86b264: ldurb           w16, [x1, #-1]
    //     0x86b268: ldurb           w17, [x0, #-1]
    //     0x86b26c: and             x16, x17, x16, lsr #2
    //     0x86b270: tst             x16, HEAP, lsr #32
    //     0x86b274: b.eq            #0x86b27c
    //     0x86b278: bl              #0xd67e5c
    // 0x86b27c: b               #0x86b284
    // 0x86b280: mov             x2, x1
    // 0x86b284: ldr             x0, [fp, #0x18]
    // 0x86b288: ldur            x1, [fp, #-8]
    // 0x86b28c: ldur            x3, [fp, #-0x10]
    // 0x86b290: LoadField: r4 = r0->field_b
    //     0x86b290: ldur            w4, [x0, #0xb]
    // 0x86b294: DecompressPointer r4
    //     0x86b294: add             x4, x4, HEAP, lsl #32
    // 0x86b298: cmp             w4, NULL
    // 0x86b29c: b.eq            #0x86c14c
    // 0x86b2a0: StoreField: r1->field_1b = rNULL
    //     0x86b2a0: stur            NULL, [x1, #0x1b]
    // 0x86b2a4: LoadField: r4 = r3->field_1f
    //     0x86b2a4: ldur            w4, [x3, #0x1f]
    // 0x86b2a8: DecompressPointer r4
    //     0x86b2a8: add             x4, x4, HEAP, lsl #32
    // 0x86b2ac: LoadField: r3 = r4->field_7
    //     0x86b2ac: ldur            x3, [x4, #7]
    // 0x86b2b0: cmp             x3, #2
    // 0x86b2b4: b.gt            #0x86b5dc
    // 0x86b2b8: cmp             x3, #1
    // 0x86b2bc: b.gt            #0x86b3a8
    // 0x86b2c0: r4 = false
    //     0x86b2c0: add             x4, NULL, #0x30  ; false
    // 0x86b2c4: StoreField: r0->field_37 = r4
    //     0x86b2c4: stur            w4, [x0, #0x37]
    // 0x86b2c8: r0 = InitLateStaticField(0xe34) // [package:flutter/src/material/text_selection.dart] ::materialTextSelectionHandleControls
    //     0x86b2c8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86b2cc: ldr             x0, [x0, #0x1c68]
    //     0x86b2d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86b2d4: cmp             w0, w16
    //     0x86b2d8: b.ne            #0x86b2e8
    //     0x86b2dc: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2dc80] Field <::.materialTextSelectionHandleControls>: static late final (offset: 0xe34)
    //     0x86b2e0: ldr             x2, [x2, #0xc80]
    //     0x86b2e4: bl              #0xd67cdc
    // 0x86b2e8: mov             x1, x0
    // 0x86b2ec: ldr             x0, [fp, #0x18]
    // 0x86b2f0: stur            x1, [fp, #-0x48]
    // 0x86b2f4: LoadField: r2 = r0->field_b
    //     0x86b2f4: ldur            w2, [x0, #0xb]
    // 0x86b2f8: DecompressPointer r2
    //     0x86b2f8: add             x2, x2, HEAP, lsl #32
    // 0x86b2fc: cmp             w2, NULL
    // 0x86b300: b.eq            #0x86c150
    // 0x86b304: LoadField: r3 = r2->field_9f
    //     0x86b304: ldur            w3, [x2, #0x9f]
    // 0x86b308: DecompressPointer r3
    //     0x86b308: add             x3, x3, HEAP, lsl #32
    // 0x86b30c: cmp             w3, NULL
    // 0x86b310: b.ne            #0x86b324
    // 0x86b314: ldur            x2, [fp, #-0x18]
    // 0x86b318: LoadField: r3 = r2->field_f
    //     0x86b318: ldur            w3, [x2, #0xf]
    // 0x86b31c: DecompressPointer r3
    //     0x86b31c: add             x3, x3, HEAP, lsl #32
    // 0x86b320: b               #0x86b328
    // 0x86b324: ldur            x2, [fp, #-0x18]
    // 0x86b328: cmp             w3, NULL
    // 0x86b32c: b.ne            #0x86b340
    // 0x86b330: ldur            x5, [fp, #-0x28]
    // 0x86b334: LoadField: r3 = r5->field_b
    //     0x86b334: ldur            w3, [x5, #0xb]
    // 0x86b338: DecompressPointer r3
    //     0x86b338: add             x3, x3, HEAP, lsl #32
    // 0x86b33c: b               #0x86b344
    // 0x86b340: ldur            x5, [fp, #-0x28]
    // 0x86b344: stur            x3, [fp, #-0x10]
    // 0x86b348: LoadField: r4 = r2->field_13
    //     0x86b348: ldur            w4, [x2, #0x13]
    // 0x86b34c: DecompressPointer r4
    //     0x86b34c: add             x4, x4, HEAP, lsl #32
    // 0x86b350: cmp             w4, NULL
    // 0x86b354: b.ne            #0x86b37c
    // 0x86b358: d0 = 0.400000
    //     0x86b358: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b35c: ldr             d0, [x17, #0x148]
    // 0x86b360: LoadField: r2 = r5->field_b
    //     0x86b360: ldur            w2, [x5, #0xb]
    // 0x86b364: DecompressPointer r2
    //     0x86b364: add             x2, x2, HEAP, lsl #32
    // 0x86b368: SaveReg r2
    //     0x86b368: str             x2, [SP, #-8]!
    // 0x86b36c: SaveReg d0
    //     0x86b36c: str             d0, [SP, #-8]!
    // 0x86b370: r0 = withOpacity()
    //     0x86b370: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86b374: add             SP, SP, #0x10
    // 0x86b378: b               #0x86b380
    // 0x86b37c: mov             x0, x4
    // 0x86b380: ldur            x9, [fp, #-0x48]
    // 0x86b384: ldur            x5, [fp, #-0x10]
    // 0x86b388: mov             x4, x0
    // 0x86b38c: ldur            x2, [fp, #-8]
    // 0x86b390: r8 = false
    //     0x86b390: add             x8, NULL, #0x30  ; false
    // 0x86b394: r7 = false
    //     0x86b394: add             x7, NULL, #0x30  ; false
    // 0x86b398: r6 = Null
    //     0x86b398: mov             x6, NULL
    // 0x86b39c: r3 = Null
    //     0x86b39c: mov             x3, NULL
    // 0x86b3a0: r1 = Null
    //     0x86b3a0: mov             x1, NULL
    // 0x86b3a4: b               #0x86ba7c
    // 0x86b3a8: ldur            x2, [fp, #-0x18]
    // 0x86b3ac: d0 = 0.400000
    //     0x86b3ac: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b3b0: ldr             d0, [x17, #0x148]
    // 0x86b3b4: ldr             x16, [fp, #0x10]
    // 0x86b3b8: SaveReg r16
    //     0x86b3b8: str             x16, [SP, #-8]!
    // 0x86b3bc: r0 = of()
    //     0x86b3bc: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x86b3c0: add             SP, SP, #8
    // 0x86b3c4: mov             x2, x0
    // 0x86b3c8: ldr             x0, [fp, #0x18]
    // 0x86b3cc: r1 = true
    //     0x86b3cc: add             x1, NULL, #0x20  ; true
    // 0x86b3d0: stur            x2, [fp, #-0x10]
    // 0x86b3d4: StoreField: r0->field_37 = r1
    //     0x86b3d4: stur            w1, [x0, #0x37]
    // 0x86b3d8: r0 = InitLateStaticField(0xce4) // [package:flutter/src/cupertino/text_selection.dart] ::cupertinoTextSelectionHandleControls
    //     0x86b3d8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86b3dc: ldr             x0, [x0, #0x19c8]
    //     0x86b3e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86b3e4: cmp             w0, w16
    //     0x86b3e8: b.ne            #0x86b3f8
    //     0x86b3ec: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2dc88] Field <::.cupertinoTextSelectionHandleControls>: static late final (offset: 0xce4)
    //     0x86b3f0: ldr             x2, [x2, #0xc88]
    //     0x86b3f4: bl              #0xd67cdc
    // 0x86b3f8: mov             x1, x0
    // 0x86b3fc: ldr             x0, [fp, #0x18]
    // 0x86b400: stur            x1, [fp, #-0x58]
    // 0x86b404: LoadField: r2 = r0->field_b
    //     0x86b404: ldur            w2, [x0, #0xb]
    // 0x86b408: DecompressPointer r2
    //     0x86b408: add             x2, x2, HEAP, lsl #32
    // 0x86b40c: cmp             w2, NULL
    // 0x86b410: b.eq            #0x86c154
    // 0x86b414: LoadField: r3 = r2->field_9f
    //     0x86b414: ldur            w3, [x2, #0x9f]
    // 0x86b418: DecompressPointer r3
    //     0x86b418: add             x3, x3, HEAP, lsl #32
    // 0x86b41c: cmp             w3, NULL
    // 0x86b420: b.ne            #0x86b434
    // 0x86b424: ldur            x2, [fp, #-0x18]
    // 0x86b428: LoadField: r3 = r2->field_f
    //     0x86b428: ldur            w3, [x2, #0xf]
    // 0x86b42c: DecompressPointer r3
    //     0x86b42c: add             x3, x3, HEAP, lsl #32
    // 0x86b430: b               #0x86b438
    // 0x86b434: ldur            x2, [fp, #-0x18]
    // 0x86b438: cmp             w3, NULL
    // 0x86b43c: b.ne            #0x86b4c0
    // 0x86b440: ldur            x4, [fp, #-0x10]
    // 0x86b444: r3 = LoadClassIdInstr(r4)
    //     0x86b444: ldur            x3, [x4, #-1]
    //     0x86b448: ubfx            x3, x3, #0xc, #0x14
    // 0x86b44c: lsl             x3, x3, #1
    // 0x86b450: r17 = 5322
    //     0x86b450: mov             x17, #0x14ca
    // 0x86b454: cmp             w3, w17
    // 0x86b458: b.ne            #0x86b484
    // 0x86b45c: LoadField: r3 = r4->field_b
    //     0x86b45c: ldur            w3, [x4, #0xb]
    // 0x86b460: DecompressPointer r3
    //     0x86b460: add             x3, x3, HEAP, lsl #32
    // 0x86b464: cmp             w3, NULL
    // 0x86b468: b.ne            #0x86b4c4
    // 0x86b46c: LoadField: r3 = r4->field_1f
    //     0x86b46c: ldur            w3, [x4, #0x1f]
    // 0x86b470: DecompressPointer r3
    //     0x86b470: add             x3, x3, HEAP, lsl #32
    // 0x86b474: LoadField: r5 = r3->field_b
    //     0x86b474: ldur            w5, [x3, #0xb]
    // 0x86b478: DecompressPointer r5
    //     0x86b478: add             x5, x5, HEAP, lsl #32
    // 0x86b47c: mov             x3, x5
    // 0x86b480: b               #0x86b4c4
    // 0x86b484: LoadField: r3 = r4->field_27
    //     0x86b484: ldur            w3, [x4, #0x27]
    // 0x86b488: DecompressPointer r3
    //     0x86b488: add             x3, x3, HEAP, lsl #32
    // 0x86b48c: LoadField: r5 = r3->field_b
    //     0x86b48c: ldur            w5, [x3, #0xb]
    // 0x86b490: DecompressPointer r5
    //     0x86b490: add             x5, x5, HEAP, lsl #32
    // 0x86b494: cmp             w5, NULL
    // 0x86b498: b.ne            #0x86b4b8
    // 0x86b49c: LoadField: r3 = r4->field_23
    //     0x86b49c: ldur            w3, [x4, #0x23]
    // 0x86b4a0: DecompressPointer r3
    //     0x86b4a0: add             x3, x3, HEAP, lsl #32
    // 0x86b4a4: LoadField: r5 = r3->field_3f
    //     0x86b4a4: ldur            w5, [x3, #0x3f]
    // 0x86b4a8: DecompressPointer r5
    //     0x86b4a8: add             x5, x5, HEAP, lsl #32
    // 0x86b4ac: LoadField: r3 = r5->field_b
    //     0x86b4ac: ldur            w3, [x5, #0xb]
    // 0x86b4b0: DecompressPointer r3
    //     0x86b4b0: add             x3, x3, HEAP, lsl #32
    // 0x86b4b4: b               #0x86b4c4
    // 0x86b4b8: mov             x3, x5
    // 0x86b4bc: b               #0x86b4c4
    // 0x86b4c0: ldur            x4, [fp, #-0x10]
    // 0x86b4c4: stur            x3, [fp, #-0x48]
    // 0x86b4c8: LoadField: r5 = r2->field_13
    //     0x86b4c8: ldur            w5, [x2, #0x13]
    // 0x86b4cc: DecompressPointer r5
    //     0x86b4cc: add             x5, x5, HEAP, lsl #32
    // 0x86b4d0: cmp             w5, NULL
    // 0x86b4d4: b.ne            #0x86b56c
    // 0x86b4d8: r2 = LoadClassIdInstr(r4)
    //     0x86b4d8: ldur            x2, [x4, #-1]
    //     0x86b4dc: ubfx            x2, x2, #0xc, #0x14
    // 0x86b4e0: lsl             x2, x2, #1
    // 0x86b4e4: r17 = 5322
    //     0x86b4e4: mov             x17, #0x14ca
    // 0x86b4e8: cmp             w2, w17
    // 0x86b4ec: b.ne            #0x86b518
    // 0x86b4f0: LoadField: r2 = r4->field_b
    //     0x86b4f0: ldur            w2, [x4, #0xb]
    // 0x86b4f4: DecompressPointer r2
    //     0x86b4f4: add             x2, x2, HEAP, lsl #32
    // 0x86b4f8: cmp             w2, NULL
    // 0x86b4fc: b.ne            #0x86b550
    // 0x86b500: LoadField: r2 = r4->field_1f
    //     0x86b500: ldur            w2, [x4, #0x1f]
    // 0x86b504: DecompressPointer r2
    //     0x86b504: add             x2, x2, HEAP, lsl #32
    // 0x86b508: LoadField: r4 = r2->field_b
    //     0x86b508: ldur            w4, [x2, #0xb]
    // 0x86b50c: DecompressPointer r4
    //     0x86b50c: add             x4, x4, HEAP, lsl #32
    // 0x86b510: mov             x2, x4
    // 0x86b514: b               #0x86b550
    // 0x86b518: LoadField: r2 = r4->field_27
    //     0x86b518: ldur            w2, [x4, #0x27]
    // 0x86b51c: DecompressPointer r2
    //     0x86b51c: add             x2, x2, HEAP, lsl #32
    // 0x86b520: LoadField: r5 = r2->field_b
    //     0x86b520: ldur            w5, [x2, #0xb]
    // 0x86b524: DecompressPointer r5
    //     0x86b524: add             x5, x5, HEAP, lsl #32
    // 0x86b528: cmp             w5, NULL
    // 0x86b52c: b.ne            #0x86b54c
    // 0x86b530: LoadField: r2 = r4->field_23
    //     0x86b530: ldur            w2, [x4, #0x23]
    // 0x86b534: DecompressPointer r2
    //     0x86b534: add             x2, x2, HEAP, lsl #32
    // 0x86b538: LoadField: r4 = r2->field_3f
    //     0x86b538: ldur            w4, [x2, #0x3f]
    // 0x86b53c: DecompressPointer r4
    //     0x86b53c: add             x4, x4, HEAP, lsl #32
    // 0x86b540: LoadField: r2 = r4->field_b
    //     0x86b540: ldur            w2, [x4, #0xb]
    // 0x86b544: DecompressPointer r2
    //     0x86b544: add             x2, x2, HEAP, lsl #32
    // 0x86b548: b               #0x86b550
    // 0x86b54c: mov             x2, x5
    // 0x86b550: d0 = 0.400000
    //     0x86b550: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b554: ldr             d0, [x17, #0x148]
    // 0x86b558: SaveReg r2
    //     0x86b558: str             x2, [SP, #-8]!
    // 0x86b55c: SaveReg d0
    //     0x86b55c: str             d0, [SP, #-8]!
    // 0x86b560: r0 = withOpacity()
    //     0x86b560: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86b564: add             SP, SP, #0x10
    // 0x86b568: b               #0x86b570
    // 0x86b56c: mov             x0, x5
    // 0x86b570: stur            x0, [fp, #-0x10]
    // 0x86b574: ldr             x16, [fp, #0x10]
    // 0x86b578: SaveReg r16
    //     0x86b578: str             x16, [SP, #-8]!
    // 0x86b57c: r0 = of()
    //     0x86b57c: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x86b580: add             SP, SP, #8
    // 0x86b584: LoadField: d0 = r0->field_b
    //     0x86b584: ldur            d0, [x0, #0xb]
    // 0x86b588: d1 = -2.000000
    //     0x86b588: fmov            d1, #-2.00000000
    // 0x86b58c: fdiv            d2, d1, d0
    // 0x86b590: r17 = -272
    //     0x86b590: mov             x17, #-0x110
    // 0x86b594: str             d2, [fp, x17]
    // 0x86b598: r0 = Offset()
    //     0x86b598: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x86b59c: r17 = -272
    //     0x86b59c: mov             x17, #-0x110
    // 0x86b5a0: ldr             d0, [fp, x17]
    // 0x86b5a4: StoreField: r0->field_7 = d0
    //     0x86b5a4: stur            d0, [x0, #7]
    // 0x86b5a8: d2 = 0.000000
    //     0x86b5a8: eor             v2.16b, v2.16b, v2.16b
    // 0x86b5ac: StoreField: r0->field_f = d2
    //     0x86b5ac: stur            d2, [x0, #0xf]
    // 0x86b5b0: ldur            x9, [fp, #-0x58]
    // 0x86b5b4: mov             x6, x0
    // 0x86b5b8: ldur            x5, [fp, #-0x48]
    // 0x86b5bc: ldur            x4, [fp, #-0x10]
    // 0x86b5c0: ldur            x3, [fp, #-0x10]
    // 0x86b5c4: ldur            x2, [fp, #-8]
    // 0x86b5c8: r8 = true
    //     0x86b5c8: add             x8, NULL, #0x20  ; true
    // 0x86b5cc: r7 = true
    //     0x86b5cc: add             x7, NULL, #0x20  ; true
    // 0x86b5d0: r1 = Instance_Radius
    //     0x86b5d0: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc90] Obj!Radius@b5e8a1
    //     0x86b5d4: ldr             x1, [x1, #0xc90]
    // 0x86b5d8: b               #0x86ba7c
    // 0x86b5dc: ldur            x2, [fp, #-0x18]
    // 0x86b5e0: ldur            x5, [fp, #-0x28]
    // 0x86b5e4: r4 = false
    //     0x86b5e4: add             x4, NULL, #0x30  ; false
    // 0x86b5e8: d1 = -2.000000
    //     0x86b5e8: fmov            d1, #-2.00000000
    // 0x86b5ec: d0 = 0.400000
    //     0x86b5ec: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b5f0: ldr             d0, [x17, #0x148]
    // 0x86b5f4: d2 = 0.000000
    //     0x86b5f4: eor             v2.16b, v2.16b, v2.16b
    // 0x86b5f8: cmp             x3, #4
    // 0x86b5fc: b.gt            #0x86b954
    // 0x86b600: cmp             x3, #3
    // 0x86b604: b.gt            #0x86b6f0
    // 0x86b608: ldr             x0, [fp, #0x18]
    // 0x86b60c: StoreField: r0->field_37 = r4
    //     0x86b60c: stur            w4, [x0, #0x37]
    // 0x86b610: r0 = InitLateStaticField(0xd74) // [package:flutter/src/material/desktop_text_selection.dart] ::desktopTextSelectionHandleControls
    //     0x86b610: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86b614: ldr             x0, [x0, #0x1ae8]
    //     0x86b618: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86b61c: cmp             w0, w16
    //     0x86b620: b.ne            #0x86b630
    //     0x86b624: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2dc98] Field <::.desktopTextSelectionHandleControls>: static late final (offset: 0xd74)
    //     0x86b628: ldr             x2, [x2, #0xc98]
    //     0x86b62c: bl              #0xd67cdc
    // 0x86b630: mov             x1, x0
    // 0x86b634: ldr             x0, [fp, #0x18]
    // 0x86b638: stur            x1, [fp, #-0x48]
    // 0x86b63c: LoadField: r2 = r0->field_b
    //     0x86b63c: ldur            w2, [x0, #0xb]
    // 0x86b640: DecompressPointer r2
    //     0x86b640: add             x2, x2, HEAP, lsl #32
    // 0x86b644: cmp             w2, NULL
    // 0x86b648: b.eq            #0x86c158
    // 0x86b64c: LoadField: r3 = r2->field_9f
    //     0x86b64c: ldur            w3, [x2, #0x9f]
    // 0x86b650: DecompressPointer r3
    //     0x86b650: add             x3, x3, HEAP, lsl #32
    // 0x86b654: cmp             w3, NULL
    // 0x86b658: b.ne            #0x86b66c
    // 0x86b65c: ldur            x2, [fp, #-0x18]
    // 0x86b660: LoadField: r3 = r2->field_f
    //     0x86b660: ldur            w3, [x2, #0xf]
    // 0x86b664: DecompressPointer r3
    //     0x86b664: add             x3, x3, HEAP, lsl #32
    // 0x86b668: b               #0x86b670
    // 0x86b66c: ldur            x2, [fp, #-0x18]
    // 0x86b670: cmp             w3, NULL
    // 0x86b674: b.ne            #0x86b688
    // 0x86b678: ldur            x4, [fp, #-0x28]
    // 0x86b67c: LoadField: r3 = r4->field_b
    //     0x86b67c: ldur            w3, [x4, #0xb]
    // 0x86b680: DecompressPointer r3
    //     0x86b680: add             x3, x3, HEAP, lsl #32
    // 0x86b684: b               #0x86b68c
    // 0x86b688: ldur            x4, [fp, #-0x28]
    // 0x86b68c: stur            x3, [fp, #-0x10]
    // 0x86b690: LoadField: r5 = r2->field_13
    //     0x86b690: ldur            w5, [x2, #0x13]
    // 0x86b694: DecompressPointer r5
    //     0x86b694: add             x5, x5, HEAP, lsl #32
    // 0x86b698: cmp             w5, NULL
    // 0x86b69c: b.ne            #0x86b6c4
    // 0x86b6a0: d0 = 0.400000
    //     0x86b6a0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b6a4: ldr             d0, [x17, #0x148]
    // 0x86b6a8: LoadField: r2 = r4->field_b
    //     0x86b6a8: ldur            w2, [x4, #0xb]
    // 0x86b6ac: DecompressPointer r2
    //     0x86b6ac: add             x2, x2, HEAP, lsl #32
    // 0x86b6b0: SaveReg r2
    //     0x86b6b0: str             x2, [SP, #-8]!
    // 0x86b6b4: SaveReg d0
    //     0x86b6b4: str             d0, [SP, #-8]!
    // 0x86b6b8: r0 = withOpacity()
    //     0x86b6b8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86b6bc: add             SP, SP, #0x10
    // 0x86b6c0: b               #0x86b6c8
    // 0x86b6c4: mov             x0, x5
    // 0x86b6c8: ldur            x9, [fp, #-0x48]
    // 0x86b6cc: ldur            x5, [fp, #-0x10]
    // 0x86b6d0: mov             x4, x0
    // 0x86b6d4: ldur            x2, [fp, #-8]
    // 0x86b6d8: r8 = false
    //     0x86b6d8: add             x8, NULL, #0x30  ; false
    // 0x86b6dc: r7 = false
    //     0x86b6dc: add             x7, NULL, #0x30  ; false
    // 0x86b6e0: r6 = Null
    //     0x86b6e0: mov             x6, NULL
    // 0x86b6e4: r3 = Null
    //     0x86b6e4: mov             x3, NULL
    // 0x86b6e8: r1 = Null
    //     0x86b6e8: mov             x1, NULL
    // 0x86b6ec: b               #0x86ba7c
    // 0x86b6f0: ldr             x0, [fp, #0x18]
    // 0x86b6f4: ldr             x16, [fp, #0x10]
    // 0x86b6f8: SaveReg r16
    //     0x86b6f8: str             x16, [SP, #-8]!
    // 0x86b6fc: r0 = of()
    //     0x86b6fc: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x86b700: add             SP, SP, #8
    // 0x86b704: mov             x2, x0
    // 0x86b708: ldr             x1, [fp, #0x18]
    // 0x86b70c: r0 = false
    //     0x86b70c: add             x0, NULL, #0x30  ; false
    // 0x86b710: stur            x2, [fp, #-0x10]
    // 0x86b714: StoreField: r1->field_37 = r0
    //     0x86b714: stur            w0, [x1, #0x37]
    // 0x86b718: r0 = InitLateStaticField(0xcc8) // [package:flutter/src/cupertino/desktop_text_selection.dart] ::cupertinoDesktopTextSelectionHandleControls
    //     0x86b718: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86b71c: ldr             x0, [x0, #0x1990]
    //     0x86b720: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86b724: cmp             w0, w16
    //     0x86b728: b.ne            #0x86b738
    //     0x86b72c: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2dca0] Field <::.cupertinoDesktopTextSelectionHandleControls>: static late final (offset: 0xcc8)
    //     0x86b730: ldr             x2, [x2, #0xca0]
    //     0x86b734: bl              #0xd67cdc
    // 0x86b738: mov             x1, x0
    // 0x86b73c: ldr             x0, [fp, #0x18]
    // 0x86b740: stur            x1, [fp, #-0x58]
    // 0x86b744: LoadField: r2 = r0->field_b
    //     0x86b744: ldur            w2, [x0, #0xb]
    // 0x86b748: DecompressPointer r2
    //     0x86b748: add             x2, x2, HEAP, lsl #32
    // 0x86b74c: cmp             w2, NULL
    // 0x86b750: b.eq            #0x86c15c
    // 0x86b754: LoadField: r3 = r2->field_9f
    //     0x86b754: ldur            w3, [x2, #0x9f]
    // 0x86b758: DecompressPointer r3
    //     0x86b758: add             x3, x3, HEAP, lsl #32
    // 0x86b75c: cmp             w3, NULL
    // 0x86b760: b.ne            #0x86b774
    // 0x86b764: ldur            x2, [fp, #-0x18]
    // 0x86b768: LoadField: r3 = r2->field_f
    //     0x86b768: ldur            w3, [x2, #0xf]
    // 0x86b76c: DecompressPointer r3
    //     0x86b76c: add             x3, x3, HEAP, lsl #32
    // 0x86b770: b               #0x86b778
    // 0x86b774: ldur            x2, [fp, #-0x18]
    // 0x86b778: cmp             w3, NULL
    // 0x86b77c: b.ne            #0x86b800
    // 0x86b780: ldur            x4, [fp, #-0x10]
    // 0x86b784: r3 = LoadClassIdInstr(r4)
    //     0x86b784: ldur            x3, [x4, #-1]
    //     0x86b788: ubfx            x3, x3, #0xc, #0x14
    // 0x86b78c: lsl             x3, x3, #1
    // 0x86b790: r17 = 5322
    //     0x86b790: mov             x17, #0x14ca
    // 0x86b794: cmp             w3, w17
    // 0x86b798: b.ne            #0x86b7c4
    // 0x86b79c: LoadField: r3 = r4->field_b
    //     0x86b79c: ldur            w3, [x4, #0xb]
    // 0x86b7a0: DecompressPointer r3
    //     0x86b7a0: add             x3, x3, HEAP, lsl #32
    // 0x86b7a4: cmp             w3, NULL
    // 0x86b7a8: b.ne            #0x86b804
    // 0x86b7ac: LoadField: r3 = r4->field_1f
    //     0x86b7ac: ldur            w3, [x4, #0x1f]
    // 0x86b7b0: DecompressPointer r3
    //     0x86b7b0: add             x3, x3, HEAP, lsl #32
    // 0x86b7b4: LoadField: r5 = r3->field_b
    //     0x86b7b4: ldur            w5, [x3, #0xb]
    // 0x86b7b8: DecompressPointer r5
    //     0x86b7b8: add             x5, x5, HEAP, lsl #32
    // 0x86b7bc: mov             x3, x5
    // 0x86b7c0: b               #0x86b804
    // 0x86b7c4: LoadField: r3 = r4->field_27
    //     0x86b7c4: ldur            w3, [x4, #0x27]
    // 0x86b7c8: DecompressPointer r3
    //     0x86b7c8: add             x3, x3, HEAP, lsl #32
    // 0x86b7cc: LoadField: r5 = r3->field_b
    //     0x86b7cc: ldur            w5, [x3, #0xb]
    // 0x86b7d0: DecompressPointer r5
    //     0x86b7d0: add             x5, x5, HEAP, lsl #32
    // 0x86b7d4: cmp             w5, NULL
    // 0x86b7d8: b.ne            #0x86b7f8
    // 0x86b7dc: LoadField: r3 = r4->field_23
    //     0x86b7dc: ldur            w3, [x4, #0x23]
    // 0x86b7e0: DecompressPointer r3
    //     0x86b7e0: add             x3, x3, HEAP, lsl #32
    // 0x86b7e4: LoadField: r5 = r3->field_3f
    //     0x86b7e4: ldur            w5, [x3, #0x3f]
    // 0x86b7e8: DecompressPointer r5
    //     0x86b7e8: add             x5, x5, HEAP, lsl #32
    // 0x86b7ec: LoadField: r3 = r5->field_b
    //     0x86b7ec: ldur            w3, [x5, #0xb]
    // 0x86b7f0: DecompressPointer r3
    //     0x86b7f0: add             x3, x3, HEAP, lsl #32
    // 0x86b7f4: b               #0x86b804
    // 0x86b7f8: mov             x3, x5
    // 0x86b7fc: b               #0x86b804
    // 0x86b800: ldur            x4, [fp, #-0x10]
    // 0x86b804: stur            x3, [fp, #-0x48]
    // 0x86b808: LoadField: r5 = r2->field_13
    //     0x86b808: ldur            w5, [x2, #0x13]
    // 0x86b80c: DecompressPointer r5
    //     0x86b80c: add             x5, x5, HEAP, lsl #32
    // 0x86b810: cmp             w5, NULL
    // 0x86b814: b.ne            #0x86b8ac
    // 0x86b818: r2 = LoadClassIdInstr(r4)
    //     0x86b818: ldur            x2, [x4, #-1]
    //     0x86b81c: ubfx            x2, x2, #0xc, #0x14
    // 0x86b820: lsl             x2, x2, #1
    // 0x86b824: r17 = 5322
    //     0x86b824: mov             x17, #0x14ca
    // 0x86b828: cmp             w2, w17
    // 0x86b82c: b.ne            #0x86b858
    // 0x86b830: LoadField: r2 = r4->field_b
    //     0x86b830: ldur            w2, [x4, #0xb]
    // 0x86b834: DecompressPointer r2
    //     0x86b834: add             x2, x2, HEAP, lsl #32
    // 0x86b838: cmp             w2, NULL
    // 0x86b83c: b.ne            #0x86b890
    // 0x86b840: LoadField: r2 = r4->field_1f
    //     0x86b840: ldur            w2, [x4, #0x1f]
    // 0x86b844: DecompressPointer r2
    //     0x86b844: add             x2, x2, HEAP, lsl #32
    // 0x86b848: LoadField: r4 = r2->field_b
    //     0x86b848: ldur            w4, [x2, #0xb]
    // 0x86b84c: DecompressPointer r4
    //     0x86b84c: add             x4, x4, HEAP, lsl #32
    // 0x86b850: mov             x2, x4
    // 0x86b854: b               #0x86b890
    // 0x86b858: LoadField: r2 = r4->field_27
    //     0x86b858: ldur            w2, [x4, #0x27]
    // 0x86b85c: DecompressPointer r2
    //     0x86b85c: add             x2, x2, HEAP, lsl #32
    // 0x86b860: LoadField: r5 = r2->field_b
    //     0x86b860: ldur            w5, [x2, #0xb]
    // 0x86b864: DecompressPointer r5
    //     0x86b864: add             x5, x5, HEAP, lsl #32
    // 0x86b868: cmp             w5, NULL
    // 0x86b86c: b.ne            #0x86b88c
    // 0x86b870: LoadField: r2 = r4->field_23
    //     0x86b870: ldur            w2, [x4, #0x23]
    // 0x86b874: DecompressPointer r2
    //     0x86b874: add             x2, x2, HEAP, lsl #32
    // 0x86b878: LoadField: r4 = r2->field_3f
    //     0x86b878: ldur            w4, [x2, #0x3f]
    // 0x86b87c: DecompressPointer r4
    //     0x86b87c: add             x4, x4, HEAP, lsl #32
    // 0x86b880: LoadField: r2 = r4->field_b
    //     0x86b880: ldur            w2, [x4, #0xb]
    // 0x86b884: DecompressPointer r2
    //     0x86b884: add             x2, x2, HEAP, lsl #32
    // 0x86b888: b               #0x86b890
    // 0x86b88c: mov             x2, x5
    // 0x86b890: d0 = 0.400000
    //     0x86b890: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b894: ldr             d0, [x17, #0x148]
    // 0x86b898: SaveReg r2
    //     0x86b898: str             x2, [SP, #-8]!
    // 0x86b89c: SaveReg d0
    //     0x86b89c: str             d0, [SP, #-8]!
    // 0x86b8a0: r0 = withOpacity()
    //     0x86b8a0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86b8a4: add             SP, SP, #0x10
    // 0x86b8a8: b               #0x86b8b0
    // 0x86b8ac: mov             x0, x5
    // 0x86b8b0: ldur            x2, [fp, #-8]
    // 0x86b8b4: stur            x0, [fp, #-0x10]
    // 0x86b8b8: ldr             x16, [fp, #0x10]
    // 0x86b8bc: SaveReg r16
    //     0x86b8bc: str             x16, [SP, #-8]!
    // 0x86b8c0: r0 = of()
    //     0x86b8c0: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x86b8c4: add             SP, SP, #8
    // 0x86b8c8: LoadField: d0 = r0->field_b
    //     0x86b8c8: ldur            d0, [x0, #0xb]
    // 0x86b8cc: d1 = -2.000000
    //     0x86b8cc: fmov            d1, #-2.00000000
    // 0x86b8d0: fdiv            d2, d1, d0
    // 0x86b8d4: r17 = -272
    //     0x86b8d4: mov             x17, #-0x110
    // 0x86b8d8: str             d2, [fp, x17]
    // 0x86b8dc: r0 = Offset()
    //     0x86b8dc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x86b8e0: r17 = -272
    //     0x86b8e0: mov             x17, #-0x110
    // 0x86b8e4: ldr             d0, [fp, x17]
    // 0x86b8e8: stur            x0, [fp, #-0x60]
    // 0x86b8ec: StoreField: r0->field_7 = d0
    //     0x86b8ec: stur            d0, [x0, #7]
    // 0x86b8f0: d0 = 0.000000
    //     0x86b8f0: eor             v0.16b, v0.16b, v0.16b
    // 0x86b8f4: StoreField: r0->field_f = d0
    //     0x86b8f4: stur            d0, [x0, #0xf]
    // 0x86b8f8: ldur            x2, [fp, #-8]
    // 0x86b8fc: r1 = Function '<anonymous closure>':.
    //     0x86b8fc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dca8] AnonymousClosure: (0x872cf8), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x86b900: ldr             x1, [x1, #0xca8]
    // 0x86b904: r0 = AllocateClosure()
    //     0x86b904: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86b908: ldur            x1, [fp, #-8]
    // 0x86b90c: StoreField: r1->field_1b = r0
    //     0x86b90c: stur            w0, [x1, #0x1b]
    //     0x86b910: ldurb           w16, [x1, #-1]
    //     0x86b914: ldurb           w17, [x0, #-1]
    //     0x86b918: and             x16, x17, x16, lsr #2
    //     0x86b91c: tst             x16, HEAP, lsr #32
    //     0x86b920: b.eq            #0x86b928
    //     0x86b924: bl              #0xd6826c
    // 0x86b928: ldur            x9, [fp, #-0x58]
    // 0x86b92c: ldur            x6, [fp, #-0x60]
    // 0x86b930: ldur            x5, [fp, #-0x48]
    // 0x86b934: ldur            x4, [fp, #-0x10]
    // 0x86b938: mov             x2, x1
    // 0x86b93c: r8 = true
    //     0x86b93c: add             x8, NULL, #0x20  ; true
    // 0x86b940: r7 = false
    //     0x86b940: add             x7, NULL, #0x30  ; false
    // 0x86b944: r3 = Null
    //     0x86b944: mov             x3, NULL
    // 0x86b948: r1 = Instance_Radius
    //     0x86b948: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc90] Obj!Radius@b5e8a1
    //     0x86b94c: ldr             x1, [x1, #0xc90]
    // 0x86b950: b               #0x86ba7c
    // 0x86b954: ldr             x3, [fp, #0x18]
    // 0x86b958: ldur            x1, [fp, #-8]
    // 0x86b95c: mov             x0, x4
    // 0x86b960: mov             x4, x5
    // 0x86b964: StoreField: r3->field_37 = r0
    //     0x86b964: stur            w0, [x3, #0x37]
    // 0x86b968: r0 = InitLateStaticField(0xd74) // [package:flutter/src/material/desktop_text_selection.dart] ::desktopTextSelectionHandleControls
    //     0x86b968: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86b96c: ldr             x0, [x0, #0x1ae8]
    //     0x86b970: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86b974: cmp             w0, w16
    //     0x86b978: b.ne            #0x86b988
    //     0x86b97c: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2dc98] Field <::.desktopTextSelectionHandleControls>: static late final (offset: 0xd74)
    //     0x86b980: ldr             x2, [x2, #0xc98]
    //     0x86b984: bl              #0xd67cdc
    // 0x86b988: mov             x1, x0
    // 0x86b98c: ldr             x0, [fp, #0x18]
    // 0x86b990: stur            x1, [fp, #-0x48]
    // 0x86b994: LoadField: r2 = r0->field_b
    //     0x86b994: ldur            w2, [x0, #0xb]
    // 0x86b998: DecompressPointer r2
    //     0x86b998: add             x2, x2, HEAP, lsl #32
    // 0x86b99c: cmp             w2, NULL
    // 0x86b9a0: b.eq            #0x86c160
    // 0x86b9a4: LoadField: r3 = r2->field_9f
    //     0x86b9a4: ldur            w3, [x2, #0x9f]
    // 0x86b9a8: DecompressPointer r3
    //     0x86b9a8: add             x3, x3, HEAP, lsl #32
    // 0x86b9ac: cmp             w3, NULL
    // 0x86b9b0: b.ne            #0x86b9c4
    // 0x86b9b4: ldur            x2, [fp, #-0x18]
    // 0x86b9b8: LoadField: r3 = r2->field_f
    //     0x86b9b8: ldur            w3, [x2, #0xf]
    // 0x86b9bc: DecompressPointer r3
    //     0x86b9bc: add             x3, x3, HEAP, lsl #32
    // 0x86b9c0: b               #0x86b9c8
    // 0x86b9c4: ldur            x2, [fp, #-0x18]
    // 0x86b9c8: cmp             w3, NULL
    // 0x86b9cc: b.ne            #0x86b9e0
    // 0x86b9d0: ldur            x4, [fp, #-0x28]
    // 0x86b9d4: LoadField: r3 = r4->field_b
    //     0x86b9d4: ldur            w3, [x4, #0xb]
    // 0x86b9d8: DecompressPointer r3
    //     0x86b9d8: add             x3, x3, HEAP, lsl #32
    // 0x86b9dc: b               #0x86b9e4
    // 0x86b9e0: ldur            x4, [fp, #-0x28]
    // 0x86b9e4: stur            x3, [fp, #-0x10]
    // 0x86b9e8: LoadField: r5 = r2->field_13
    //     0x86b9e8: ldur            w5, [x2, #0x13]
    // 0x86b9ec: DecompressPointer r5
    //     0x86b9ec: add             x5, x5, HEAP, lsl #32
    // 0x86b9f0: cmp             w5, NULL
    // 0x86b9f4: b.ne            #0x86ba20
    // 0x86b9f8: d0 = 0.400000
    //     0x86b9f8: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d148] IMM: double(0.4) from 0x3fd999999999999a
    //     0x86b9fc: ldr             d0, [x17, #0x148]
    // 0x86ba00: LoadField: r2 = r4->field_b
    //     0x86ba00: ldur            w2, [x4, #0xb]
    // 0x86ba04: DecompressPointer r2
    //     0x86ba04: add             x2, x2, HEAP, lsl #32
    // 0x86ba08: SaveReg r2
    //     0x86ba08: str             x2, [SP, #-8]!
    // 0x86ba0c: SaveReg d0
    //     0x86ba0c: str             d0, [SP, #-8]!
    // 0x86ba10: r0 = withOpacity()
    //     0x86ba10: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86ba14: add             SP, SP, #0x10
    // 0x86ba18: mov             x3, x0
    // 0x86ba1c: b               #0x86ba24
    // 0x86ba20: mov             x3, x5
    // 0x86ba24: ldur            x0, [fp, #-8]
    // 0x86ba28: mov             x2, x0
    // 0x86ba2c: stur            x3, [fp, #-0x18]
    // 0x86ba30: r1 = Function '<anonymous closure>':.
    //     0x86ba30: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcb0] AnonymousClosure: (0x872cf8), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x86ba34: ldr             x1, [x1, #0xcb0]
    // 0x86ba38: r0 = AllocateClosure()
    //     0x86ba38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86ba3c: ldur            x2, [fp, #-8]
    // 0x86ba40: StoreField: r2->field_1b = r0
    //     0x86ba40: stur            w0, [x2, #0x1b]
    //     0x86ba44: ldurb           w16, [x2, #-1]
    //     0x86ba48: ldurb           w17, [x0, #-1]
    //     0x86ba4c: and             x16, x17, x16, lsr #2
    //     0x86ba50: tst             x16, HEAP, lsr #32
    //     0x86ba54: b.eq            #0x86ba5c
    //     0x86ba58: bl              #0xd6828c
    // 0x86ba5c: ldur            x9, [fp, #-0x48]
    // 0x86ba60: ldur            x5, [fp, #-0x10]
    // 0x86ba64: ldur            x4, [fp, #-0x18]
    // 0x86ba68: r8 = false
    //     0x86ba68: add             x8, NULL, #0x30  ; false
    // 0x86ba6c: r7 = false
    //     0x86ba6c: add             x7, NULL, #0x30  ; false
    // 0x86ba70: r6 = Null
    //     0x86ba70: mov             x6, NULL
    // 0x86ba74: r3 = Null
    //     0x86ba74: mov             x3, NULL
    // 0x86ba78: r1 = Null
    //     0x86ba78: mov             x1, NULL
    // 0x86ba7c: ldr             x0, [fp, #0x18]
    // 0x86ba80: stur            x9, [fp, #-0x18]
    // 0x86ba84: stur            x8, [fp, #-0x28]
    // 0x86ba88: stur            x7, [fp, #-0x48]
    // 0x86ba8c: stur            x6, [fp, #-0x58]
    // 0x86ba90: stur            x5, [fp, #-0x60]
    // 0x86ba94: stur            x4, [fp, #-0x68]
    // 0x86ba98: stur            x3, [fp, #-0x70]
    // 0x86ba9c: stur            x1, [fp, #-0x78]
    // 0x86baa0: LoadField: r10 = r0->field_3b
    //     0x86baa0: ldur            w10, [x0, #0x3b]
    // 0x86baa4: DecompressPointer r10
    //     0x86baa4: add             x10, x10, HEAP, lsl #32
    // 0x86baa8: stur            x10, [fp, #-0x10]
    // 0x86baac: LoadField: r11 = r0->field_b
    //     0x86baac: ldur            w11, [x0, #0xb]
    // 0x86bab0: DecompressPointer r11
    //     0x86bab0: add             x11, x11, HEAP, lsl #32
    // 0x86bab4: cmp             w11, NULL
    // 0x86bab8: b.eq            #0x86c164
    // 0x86babc: SaveReg r0
    //     0x86babc: str             x0, [SP, #-8]!
    // 0x86bac0: r0 = _isEnabled()
    //     0x86bac0: bl              #0x7beee8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0x86bac4: add             SP, SP, #8
    // 0x86bac8: eor             x1, x0, #0x10
    // 0x86bacc: ldr             x0, [fp, #0x18]
    // 0x86bad0: stur            x1, [fp, #-0xc8]
    // 0x86bad4: LoadField: r2 = r0->field_b
    //     0x86bad4: ldur            w2, [x0, #0xb]
    // 0x86bad8: DecompressPointer r2
    //     0x86bad8: add             x2, x2, HEAP, lsl #32
    // 0x86badc: cmp             w2, NULL
    // 0x86bae0: b.eq            #0x86c168
    // 0x86bae4: LoadField: r3 = r0->field_2f
    //     0x86bae4: ldur            w3, [x0, #0x2f]
    // 0x86bae8: DecompressPointer r3
    //     0x86bae8: add             x3, x3, HEAP, lsl #32
    // 0x86baec: stur            x3, [fp, #-0xc0]
    // 0x86baf0: LoadField: r4 = r2->field_1b
    //     0x86baf0: ldur            w4, [x2, #0x1b]
    // 0x86baf4: DecompressPointer r4
    //     0x86baf4: add             x4, x4, HEAP, lsl #32
    // 0x86baf8: stur            x4, [fp, #-0xb8]
    // 0x86bafc: LoadField: r5 = r2->field_1f
    //     0x86bafc: ldur            w5, [x2, #0x1f]
    // 0x86bb00: DecompressPointer r5
    //     0x86bb00: add             x5, x5, HEAP, lsl #32
    // 0x86bb04: stur            x5, [fp, #-0xb0]
    // 0x86bb08: LoadField: r6 = r2->field_2f
    //     0x86bb08: ldur            w6, [x2, #0x2f]
    // 0x86bb0c: DecompressPointer r6
    //     0x86bb0c: add             x6, x6, HEAP, lsl #32
    // 0x86bb10: stur            x6, [fp, #-0xa8]
    // 0x86bb14: LoadField: r7 = r2->field_43
    //     0x86bb14: ldur            w7, [x2, #0x43]
    // 0x86bb18: DecompressPointer r7
    //     0x86bb18: add             x7, x7, HEAP, lsl #32
    // 0x86bb1c: stur            x7, [fp, #-0xa0]
    // 0x86bb20: LoadField: r8 = r2->field_4b
    //     0x86bb20: ldur            w8, [x2, #0x4b]
    // 0x86bb24: DecompressPointer r8
    //     0x86bb24: add             x8, x8, HEAP, lsl #32
    // 0x86bb28: stur            x8, [fp, #-0x98]
    // 0x86bb2c: LoadField: r9 = r2->field_4f
    //     0x86bb2c: ldur            w9, [x2, #0x4f]
    // 0x86bb30: DecompressPointer r9
    //     0x86bb30: add             x9, x9, HEAP, lsl #32
    // 0x86bb34: stur            x9, [fp, #-0x90]
    // 0x86bb38: LoadField: r10 = r2->field_57
    //     0x86bb38: ldur            w10, [x2, #0x57]
    // 0x86bb3c: DecompressPointer r10
    //     0x86bb3c: add             x10, x10, HEAP, lsl #32
    // 0x86bb40: stur            x10, [fp, #-0x88]
    // 0x86bb44: LoadField: r11 = r2->field_5b
    //     0x86bb44: ldur            w11, [x2, #0x5b]
    // 0x86bb48: DecompressPointer r11
    //     0x86bb48: add             x11, x11, HEAP, lsl #32
    // 0x86bb4c: stur            x11, [fp, #-0x80]
    // 0x86bb50: ldur            x16, [fp, #-0x40]
    // 0x86bb54: SaveReg r16
    //     0x86bb54: str             x16, [SP, #-8]!
    // 0x86bb58: r0 = hasFocus()
    //     0x86bb58: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x86bb5c: add             SP, SP, #8
    // 0x86bb60: tbnz            w0, #4, #0x86bb6c
    // 0x86bb64: ldur            x1, [fp, #-0x68]
    // 0x86bb68: b               #0x86bb70
    // 0x86bb6c: r1 = Null
    //     0x86bb6c: mov             x1, NULL
    // 0x86bb70: ldr             x0, [fp, #0x18]
    // 0x86bb74: stur            x1, [fp, #-0xe0]
    // 0x86bb78: LoadField: r2 = r0->field_b
    //     0x86bb78: ldur            w2, [x0, #0xb]
    // 0x86bb7c: DecompressPointer r2
    //     0x86bb7c: add             x2, x2, HEAP, lsl #32
    // 0x86bb80: stur            x2, [fp, #-0xd8]
    // 0x86bb84: cmp             w2, NULL
    // 0x86bb88: b.eq            #0x86c16c
    // 0x86bb8c: LoadField: r3 = r2->field_b3
    //     0x86bb8c: ldur            w3, [x2, #0xb3]
    // 0x86bb90: DecompressPointer r3
    //     0x86bb90: add             x3, x3, HEAP, lsl #32
    // 0x86bb94: stur            x3, [fp, #-0xd0]
    // 0x86bb98: tbnz            w3, #4, #0x86bba4
    // 0x86bb9c: ldur            x6, [fp, #-0x18]
    // 0x86bba0: b               #0x86bba8
    // 0x86bba4: r6 = Null
    //     0x86bba4: mov             x6, NULL
    // 0x86bba8: ldur            x5, [fp, #-0x38]
    // 0x86bbac: ldur            x4, [fp, #-0x40]
    // 0x86bbb0: stur            x6, [fp, #-0x68]
    // 0x86bbb4: LoadField: r7 = r2->field_77
    //     0x86bbb4: ldur            w7, [x2, #0x77]
    // 0x86bbb8: DecompressPointer r7
    //     0x86bbb8: add             x7, x7, HEAP, lsl #32
    // 0x86bbbc: stur            x7, [fp, #-0x18]
    // 0x86bbc0: r1 = 1
    //     0x86bbc0: mov             x1, #1
    // 0x86bbc4: r0 = AllocateContext()
    //     0x86bbc4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x86bbc8: mov             x1, x0
    // 0x86bbcc: ldr             x0, [fp, #0x18]
    // 0x86bbd0: stur            x1, [fp, #-0xf0]
    // 0x86bbd4: StoreField: r1->field_f = r0
    //     0x86bbd4: stur            w0, [x1, #0xf]
    // 0x86bbd8: ldur            x2, [fp, #-0xd8]
    // 0x86bbdc: LoadField: r3 = r2->field_7f
    //     0x86bbdc: ldur            w3, [x2, #0x7f]
    // 0x86bbe0: DecompressPointer r3
    //     0x86bbe0: add             x3, x3, HEAP, lsl #32
    // 0x86bbe4: stur            x3, [fp, #-0xe8]
    // 0x86bbe8: r1 = 1
    //     0x86bbe8: mov             x1, #1
    // 0x86bbec: r0 = AllocateContext()
    //     0x86bbec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x86bbf0: mov             x1, x0
    // 0x86bbf4: ldr             x0, [fp, #0x18]
    // 0x86bbf8: stur            x1, [fp, #-0x100]
    // 0x86bbfc: StoreField: r1->field_f = r0
    //     0x86bbfc: stur            w0, [x1, #0xf]
    // 0x86bc00: ldur            x2, [fp, #-0xd8]
    // 0x86bc04: LoadField: r3 = r2->field_eb
    //     0x86bc04: ldur            w3, [x2, #0xeb]
    // 0x86bc08: DecompressPointer r3
    //     0x86bc08: add             x3, x3, HEAP, lsl #32
    // 0x86bc0c: stur            x3, [fp, #-0xf8]
    // 0x86bc10: r0 = InitLateStaticField(0xdc8) // [package:flutter/src/material/magnifier.dart] TextMagnifier::adaptiveMagnifierConfiguration
    //     0x86bc10: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86bc14: ldr             x0, [x0, #0x1b90]
    //     0x86bc18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86bc1c: cmp             w0, w16
    //     0x86bc20: b.ne            #0x86bc30
    //     0x86bc24: add             x2, PP, #0x2d, lsl #12  ; [pp+0x2dcb8] Field <TextMagnifier.adaptiveMagnifierConfiguration>: static late (offset: 0xdc8)
    //     0x86bc28: ldr             x2, [x2, #0xcb8]
    //     0x86bc2c: bl              #0xd67d44
    // 0x86bc30: ldur            x2, [fp, #-0xf0]
    // 0x86bc34: r1 = Function '_handleSelectionChanged@823181401':.
    //     0x86bc34: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcc0] AnonymousClosure: (0x83eb20), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionChanged (0x83e5dc)
    //     0x86bc38: ldr             x1, [x1, #0xcc0]
    // 0x86bc3c: stur            x0, [fp, #-0xd8]
    // 0x86bc40: r0 = AllocateClosure()
    //     0x86bc40: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86bc44: ldur            x2, [fp, #-0x100]
    // 0x86bc48: r1 = Function '_handleSelectionHandleTapped@823181401':.
    //     0x86bc48: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcc8] AnonymousClosure: (0x872abc), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionHandleTapped (0x872b04)
    //     0x86bc4c: ldr             x1, [x1, #0xcc8]
    // 0x86bc50: stur            x0, [fp, #-0xf0]
    // 0x86bc54: r0 = AllocateClosure()
    //     0x86bc54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86bc58: stur            x0, [fp, #-0x100]
    // 0x86bc5c: r0 = EditableText()
    //     0x86bc5c: bl              #0x8720e0  ; AllocateEditableTextStub -> EditableText (size=0x11c)
    // 0x86bc60: r17 = -264
    //     0x86bc60: mov             x17, #-0x108
    // 0x86bc64: str             x0, [fp, x17]
    // 0x86bc68: ldur            x16, [fp, #-0xf8]
    // 0x86bc6c: stp             x16, x0, [SP, #-0x10]!
    // 0x86bc70: ldur            x16, [fp, #-0x38]
    // 0x86bc74: ldur            lr, [fp, #-0x60]
    // 0x86bc78: stp             lr, x16, [SP, #-0x10]!
    // 0x86bc7c: ldur            x16, [fp, #-0x58]
    // 0x86bc80: ldur            lr, [fp, #-0x48]
    // 0x86bc84: stp             lr, x16, [SP, #-0x10]!
    // 0x86bc88: ldur            x16, [fp, #-0x78]
    // 0x86bc8c: ldur            lr, [fp, #-0xd0]
    // 0x86bc90: stp             lr, x16, [SP, #-0x10]!
    // 0x86bc94: ldur            x16, [fp, #-0x40]
    // 0x86bc98: ldur            lr, [fp, #-0x10]
    // 0x86bc9c: stp             lr, x16, [SP, #-0x10]!
    // 0x86bca0: ldur            x16, [fp, #-0xd8]
    // 0x86bca4: ldur            lr, [fp, #-0x88]
    // 0x86bca8: stp             lr, x16, [SP, #-0x10]!
    // 0x86bcac: ldur            x16, [fp, #-0x80]
    // 0x86bcb0: ldur            lr, [fp, #-0xf0]
    // 0x86bcb4: stp             lr, x16, [SP, #-0x10]!
    // 0x86bcb8: ldur            x16, [fp, #-0x100]
    // 0x86bcbc: ldur            lr, [fp, #-0x28]
    // 0x86bcc0: stp             lr, x16, [SP, #-0x10]!
    // 0x86bcc4: ldur            x16, [fp, #-0xc8]
    // 0x86bcc8: ldur            lr, [fp, #-0xe0]
    // 0x86bccc: stp             lr, x16, [SP, #-0x10]!
    // 0x86bcd0: ldur            x16, [fp, #-0x68]
    // 0x86bcd4: stp             NULL, x16, [SP, #-0x10]!
    // 0x86bcd8: ldur            x16, [fp, #-0xc0]
    // 0x86bcdc: stp             NULL, x16, [SP, #-0x10]!
    // 0x86bce0: ldur            x16, [fp, #-0x30]
    // 0x86bce4: ldur            lr, [fp, #-0xa8]
    // 0x86bce8: stp             lr, x16, [SP, #-0x10]!
    // 0x86bcec: ldur            x16, [fp, #-0xb8]
    // 0x86bcf0: stp             x16, NULL, [SP, #-0x10]!
    // 0x86bcf4: ldur            x16, [fp, #-0xb0]
    // 0x86bcf8: ldur            lr, [fp, #-0xa0]
    // 0x86bcfc: stp             lr, x16, [SP, #-0x10]!
    // 0x86bd00: ldur            x16, [fp, #-0x98]
    // 0x86bd04: ldur            lr, [fp, #-0x90]
    // 0x86bd08: stp             lr, x16, [SP, #-0x10]!
    // 0x86bd0c: ldur            x16, [fp, #-0x18]
    // 0x86bd10: ldur            lr, [fp, #-0xe8]
    // 0x86bd14: stp             lr, x16, [SP, #-0x10]!
    // 0x86bd18: ldur            x16, [fp, #-0x50]
    // 0x86bd1c: r30 = Instance__DeferringMouseCursor
    //     0x86bd1c: ldr             lr, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x86bd20: stp             lr, x16, [SP, #-0x10]!
    // 0x86bd24: ldur            x16, [fp, #-0x20]
    // 0x86bd28: ldr             lr, [fp, #0x18]
    // 0x86bd2c: stp             lr, x16, [SP, #-0x10]!
    // 0x86bd30: ldur            x16, [fp, #-0x70]
    // 0x86bd34: r30 = "editable"
    //     0x86bd34: add             lr, PP, #0x2d, lsl #12  ; [pp+0x2dcd0] "editable"
    //     0x86bd38: ldr             lr, [lr, #0xcd0]
    // 0x86bd3c: stp             lr, x16, [SP, #-0x10]!
    // 0x86bd40: r16 = Instance_SpellCheckConfiguration
    //     0x86bd40: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dcd8] Obj!SpellCheckConfiguration@b33a81
    //     0x86bd44: ldr             x16, [x16, #0xcd8]
    // 0x86bd48: SaveReg r16
    //     0x86bd48: str             x16, [SP, #-8]!
    // 0x86bd4c: r4 = const [0, 0x27, 0x27, 0x19, autocorrectionTextRectColor, 0x24, autofillClient, 0x23, inputFormatters, 0x20, keyboardAppearance, 0x22, keyboardType, 0x19, mouseCursor, 0x21, obscureText, 0x1b, onChanged, 0x1e, onSubmitted, 0x1f, restorationId, 0x25, smartDashesType, 0x1c, smartQuotesType, 0x1d, spellCheckConfiguration, 0x26, textInputAction, 0x1a, null]
    //     0x86bd4c: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dce0] List(33) [0, 0x27, 0x27, 0x19, "autocorrectionTextRectColor", 0x24, "autofillClient", 0x23, "inputFormatters", 0x20, "keyboardAppearance", 0x22, "keyboardType", 0x19, "mouseCursor", 0x21, "obscureText", 0x1b, "onChanged", 0x1e, "onSubmitted", 0x1f, "restorationId", 0x25, "smartDashesType", 0x1c, "smartQuotesType", 0x1d, "spellCheckConfiguration", 0x26, "textInputAction", 0x1a, Null]
    //     0x86bd50: ldr             x4, [x4, #0xce0]
    // 0x86bd54: r0 = EditableText()
    //     0x86bd54: bl              #0x8711b4  ; [package:flutter/src/widgets/editable_text.dart] EditableText::EditableText
    // 0x86bd58: add             SP, SP, #0x138
    // 0x86bd5c: r0 = UnmanagedRestorationScope()
    //     0x86bd5c: bl              #0x83cd7c  ; AllocateUnmanagedRestorationScopeStub -> UnmanagedRestorationScope (size=0x14)
    // 0x86bd60: mov             x1, x0
    // 0x86bd64: r17 = -264
    //     0x86bd64: mov             x17, #-0x108
    // 0x86bd68: ldr             x0, [fp, x17]
    // 0x86bd6c: stur            x1, [fp, #-0x10]
    // 0x86bd70: StoreField: r1->field_b = r0
    //     0x86bd70: stur            w0, [x1, #0xb]
    // 0x86bd74: r0 = RepaintBoundary()
    //     0x86bd74: bl              #0x83cd70  ; AllocateRepaintBoundaryStub -> RepaintBoundary (size=0x10)
    // 0x86bd78: mov             x3, x0
    // 0x86bd7c: ldur            x0, [fp, #-0x10]
    // 0x86bd80: stur            x3, [fp, #-0x18]
    // 0x86bd84: StoreField: r3->field_b = r0
    //     0x86bd84: stur            w0, [x3, #0xb]
    // 0x86bd88: ldr             x0, [fp, #0x18]
    // 0x86bd8c: LoadField: r1 = r0->field_b
    //     0x86bd8c: ldur            w1, [x0, #0xb]
    // 0x86bd90: DecompressPointer r1
    //     0x86bd90: add             x1, x1, HEAP, lsl #32
    // 0x86bd94: cmp             w1, NULL
    // 0x86bd98: b.eq            #0x86c170
    // 0x86bd9c: r1 = Null
    //     0x86bd9c: mov             x1, NULL
    // 0x86bda0: r2 = 4
    //     0x86bda0: mov             x2, #4
    // 0x86bda4: r0 = AllocateArray()
    //     0x86bda4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x86bda8: mov             x2, x0
    // 0x86bdac: ldur            x0, [fp, #-0x40]
    // 0x86bdb0: stur            x2, [fp, #-0x10]
    // 0x86bdb4: StoreField: r2->field_f = r0
    //     0x86bdb4: stur            w0, [x2, #0xf]
    // 0x86bdb8: ldur            x3, [fp, #-0x38]
    // 0x86bdbc: StoreField: r2->field_13 = r3
    //     0x86bdbc: stur            w3, [x2, #0x13]
    // 0x86bdc0: r1 = <Listenable>
    //     0x86bdc0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28488] TypeArguments: <Listenable>
    //     0x86bdc4: ldr             x1, [x1, #0x488]
    // 0x86bdc8: r0 = AllocateGrowableArray()
    //     0x86bdc8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x86bdcc: mov             x1, x0
    // 0x86bdd0: ldur            x0, [fp, #-0x10]
    // 0x86bdd4: stur            x1, [fp, #-0x20]
    // 0x86bdd8: StoreField: r1->field_f = r0
    //     0x86bdd8: stur            w0, [x1, #0xf]
    // 0x86bddc: r0 = 4
    //     0x86bddc: mov             x0, #4
    // 0x86bde0: StoreField: r1->field_b = r0
    //     0x86bde0: stur            w0, [x1, #0xb]
    // 0x86bde4: r0 = _MergingListenable()
    //     0x86bde4: bl              #0x83cd64  ; Allocate_MergingListenableStub -> _MergingListenable (size=0xc)
    // 0x86bde8: mov             x3, x0
    // 0x86bdec: ldur            x0, [fp, #-0x20]
    // 0x86bdf0: stur            x3, [fp, #-0x10]
    // 0x86bdf4: StoreField: r3->field_7 = r0
    //     0x86bdf4: stur            w0, [x3, #7]
    // 0x86bdf8: ldur            x2, [fp, #-8]
    // 0x86bdfc: r1 = Function '<anonymous closure>':.
    //     0x86bdfc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dce8] AnonymousClosure: (0x8724a0), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x86be00: ldr             x1, [x1, #0xce8]
    // 0x86be04: r0 = AllocateClosure()
    //     0x86be04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86be08: stur            x0, [fp, #-0x20]
    // 0x86be0c: r0 = AnimatedBuilder()
    //     0x86be0c: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x86be10: mov             x1, x0
    // 0x86be14: ldur            x0, [fp, #-0x20]
    // 0x86be18: stur            x1, [fp, #-0x28]
    // 0x86be1c: StoreField: r1->field_f = r0
    //     0x86be1c: stur            w0, [x1, #0xf]
    // 0x86be20: ldur            x0, [fp, #-0x18]
    // 0x86be24: StoreField: r1->field_13 = r0
    //     0x86be24: stur            w0, [x1, #0x13]
    // 0x86be28: ldur            x0, [fp, #-0x10]
    // 0x86be2c: StoreField: r1->field_b = r0
    //     0x86be2c: stur            w0, [x1, #0xb]
    // 0x86be30: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x86be30: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86be34: ldr             x0, [x0, #0x598]
    //     0x86be38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86be3c: cmp             w0, w16
    //     0x86be40: b.ne            #0x86be4c
    //     0x86be44: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x86be48: bl              #0xd67cdc
    // 0x86be4c: r1 = <MaterialState>
    //     0x86be4c: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x86be50: ldr             x1, [x1, #0xcf0]
    // 0x86be54: stur            x0, [fp, #-0x10]
    // 0x86be58: r0 = _Set()
    //     0x86be58: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x86be5c: mov             x1, x0
    // 0x86be60: ldur            x0, [fp, #-0x10]
    // 0x86be64: stur            x1, [fp, #-0x18]
    // 0x86be68: StoreField: r1->field_1b = r0
    //     0x86be68: stur            w0, [x1, #0x1b]
    // 0x86be6c: StoreField: r1->field_b = rZR
    //     0x86be6c: stur            wzr, [x1, #0xb]
    // 0x86be70: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x86be70: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86be74: ldr             x0, [x0, #0x5a0]
    //     0x86be78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86be7c: cmp             w0, w16
    //     0x86be80: b.ne            #0x86be8c
    //     0x86be84: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x86be88: bl              #0xd67cdc
    // 0x86be8c: mov             x1, x0
    // 0x86be90: ldur            x0, [fp, #-0x18]
    // 0x86be94: StoreField: r0->field_f = r1
    //     0x86be94: stur            w1, [x0, #0xf]
    // 0x86be98: StoreField: r0->field_13 = rZR
    //     0x86be98: stur            wzr, [x0, #0x13]
    // 0x86be9c: StoreField: r0->field_17 = rZR
    //     0x86be9c: stur            wzr, [x0, #0x17]
    // 0x86bea0: ldr             x16, [fp, #0x18]
    // 0x86bea4: SaveReg r16
    //     0x86bea4: str             x16, [SP, #-8]!
    // 0x86bea8: r0 = _isEnabled()
    //     0x86bea8: bl              #0x7beee8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0x86beac: add             SP, SP, #8
    // 0x86beb0: tbz             w0, #4, #0x86becc
    // 0x86beb4: ldur            x16, [fp, #-0x18]
    // 0x86beb8: r30 = Instance_MaterialState
    //     0x86beb8: add             lr, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x86bebc: ldr             lr, [lr, #0x2a0]
    // 0x86bec0: stp             lr, x16, [SP, #-0x10]!
    // 0x86bec4: r0 = add()
    //     0x86bec4: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x86bec8: add             SP, SP, #0x10
    // 0x86becc: ldr             x0, [fp, #0x18]
    // 0x86bed0: LoadField: r1 = r0->field_2b
    //     0x86bed0: ldur            w1, [x0, #0x2b]
    // 0x86bed4: DecompressPointer r1
    //     0x86bed4: add             x1, x1, HEAP, lsl #32
    // 0x86bed8: tbnz            w1, #4, #0x86bef4
    // 0x86bedc: ldur            x16, [fp, #-0x18]
    // 0x86bee0: r30 = Instance_MaterialState
    //     0x86bee0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x86bee4: ldr             lr, [lr, #0xf78]
    // 0x86bee8: stp             lr, x16, [SP, #-0x10]!
    // 0x86beec: r0 = add()
    //     0x86beec: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x86bef0: add             SP, SP, #0x10
    // 0x86bef4: ldur            x16, [fp, #-0x40]
    // 0x86bef8: SaveReg r16
    //     0x86bef8: str             x16, [SP, #-8]!
    // 0x86befc: r0 = hasFocus()
    //     0x86befc: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x86bf00: add             SP, SP, #8
    // 0x86bf04: tbnz            w0, #4, #0x86bf20
    // 0x86bf08: ldur            x16, [fp, #-0x18]
    // 0x86bf0c: r30 = Instance_MaterialState
    //     0x86bf0c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x86bf10: ldr             lr, [lr, #0xf88]
    // 0x86bf14: stp             lr, x16, [SP, #-0x10]!
    // 0x86bf18: r0 = add()
    //     0x86bf18: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x86bf1c: add             SP, SP, #0x10
    // 0x86bf20: ldr             x16, [fp, #0x18]
    // 0x86bf24: SaveReg r16
    //     0x86bf24: str             x16, [SP, #-8]!
    // 0x86bf28: r0 = _hasError()
    //     0x86bf28: bl              #0x871064  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasError
    // 0x86bf2c: add             SP, SP, #8
    // 0x86bf30: tbnz            w0, #4, #0x86bf4c
    // 0x86bf34: ldur            x16, [fp, #-0x18]
    // 0x86bf38: r30 = Instance_MaterialState
    //     0x86bf38: add             lr, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!MaterialState@b654b1
    //     0x86bf3c: ldr             lr, [lr, #0x298]
    // 0x86bf40: stp             lr, x16, [SP, #-0x10]!
    // 0x86bf44: r0 = add()
    //     0x86bf44: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x86bf48: add             SP, SP, #0x10
    // 0x86bf4c: ldur            x2, [fp, #-8]
    // 0x86bf50: r16 = <MouseCursor>
    //     0x86bf50: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x86bf54: r30 = Instance__EnabledAndDisabledMouseCursor
    //     0x86bf54: add             lr, PP, #0x2d, lsl #12  ; [pp+0x2dcf8] Obj!_EnabledAndDisabledMouseCursor@b48a11
    //     0x86bf58: ldr             lr, [lr, #0xcf8]
    // 0x86bf5c: stp             lr, x16, [SP, #-0x10]!
    // 0x86bf60: ldur            x16, [fp, #-0x18]
    // 0x86bf64: SaveReg r16
    //     0x86bf64: str             x16, [SP, #-8]!
    // 0x86bf68: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x86bf68: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x86bf6c: r0 = resolveAs()
    //     0x86bf6c: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x86bf70: add             SP, SP, #0x18
    // 0x86bf74: ldur            x2, [fp, #-8]
    // 0x86bf78: stur            x0, [fp, #-0x10]
    // 0x86bf7c: StoreField: r2->field_1f = rNULL
    //     0x86bf7c: stur            NULL, [x2, #0x1f]
    // 0x86bf80: ldr             x16, [fp, #0x18]
    // 0x86bf84: SaveReg r16
    //     0x86bf84: str             x16, [SP, #-8]!
    // 0x86bf88: r0 = _effectiveMaxLengthEnforcement()
    //     0x86bf88: bl              #0x83d4b8  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveMaxLengthEnforcement
    // 0x86bf8c: add             SP, SP, #8
    // 0x86bf90: r16 = Instance_MaxLengthEnforcement
    //     0x86bf90: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dd00] Obj!MaxLengthEnforcement@b64251
    //     0x86bf94: ldr             x16, [x16, #0xd00]
    // 0x86bf98: cmp             w0, w16
    // 0x86bf9c: b.eq            #0x86bfec
    // 0x86bfa0: ldr             x0, [fp, #0x18]
    // 0x86bfa4: LoadField: r1 = r0->field_b
    //     0x86bfa4: ldur            w1, [x0, #0xb]
    // 0x86bfa8: DecompressPointer r1
    //     0x86bfa8: add             x1, x1, HEAP, lsl #32
    // 0x86bfac: cmp             w1, NULL
    // 0x86bfb0: b.eq            #0x86c174
    // 0x86bfb4: LoadField: r2 = r1->field_6f
    //     0x86bfb4: ldur            w2, [x1, #0x6f]
    // 0x86bfb8: DecompressPointer r2
    //     0x86bfb8: add             x2, x2, HEAP, lsl #32
    // 0x86bfbc: cmp             w2, NULL
    // 0x86bfc0: b.eq            #0x86bfe4
    // 0x86bfc4: r1 = LoadInt32Instr(r2)
    //     0x86bfc4: sbfx            x1, x2, #1, #0x1f
    // 0x86bfc8: cmp             x1, #0
    // 0x86bfcc: b.le            #0x86bfdc
    // 0x86bfd0: ldur            x1, [fp, #-8]
    // 0x86bfd4: StoreField: r1->field_1f = r2
    //     0x86bfd4: stur            w2, [x1, #0x1f]
    // 0x86bfd8: b               #0x86bff8
    // 0x86bfdc: ldur            x1, [fp, #-8]
    // 0x86bfe0: b               #0x86bff4
    // 0x86bfe4: ldur            x1, [fp, #-8]
    // 0x86bfe8: b               #0x86bff4
    // 0x86bfec: ldr             x0, [fp, #0x18]
    // 0x86bff0: ldur            x1, [fp, #-8]
    // 0x86bff4: StoreField: r1->field_1f = rNULL
    //     0x86bff4: stur            NULL, [x1, #0x1f]
    // 0x86bff8: ldur            x3, [fp, #-0x38]
    // 0x86bffc: ldur            x2, [fp, #-0x10]
    // 0x86c000: SaveReg r0
    //     0x86c000: str             x0, [SP, #-8]!
    // 0x86c004: r0 = _isEnabled()
    //     0x86c004: bl              #0x7beee8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0x86c008: add             SP, SP, #8
    // 0x86c00c: eor             x1, x0, #0x10
    // 0x86c010: ldr             x0, [fp, #0x18]
    // 0x86c014: stur            x1, [fp, #-0x18]
    // 0x86c018: LoadField: r2 = r0->field_33
    //     0x86c018: ldur            w2, [x0, #0x33]
    // 0x86c01c: DecompressPointer r2
    //     0x86c01c: add             x2, x2, HEAP, lsl #32
    // 0x86c020: r16 = Sentinel
    //     0x86c020: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86c024: cmp             w2, w16
    // 0x86c028: b.eq            #0x86c178
    // 0x86c02c: ldur            x16, [fp, #-0x28]
    // 0x86c030: stp             x16, x2, [SP, #-0x10]!
    // 0x86c034: r0 = buildGestureDetector()
    //     0x86c034: bl              #0x86c184  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::buildGestureDetector
    // 0x86c038: add             SP, SP, #0x10
    // 0x86c03c: ldur            x2, [fp, #-8]
    // 0x86c040: r1 = Function '<anonymous closure>':.
    //     0x86c040: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dd08] AnonymousClosure: (0x872234), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x86c044: ldr             x1, [x1, #0xd08]
    // 0x86c048: stur            x0, [fp, #-0x20]
    // 0x86c04c: r0 = AllocateClosure()
    //     0x86c04c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86c050: stur            x0, [fp, #-0x28]
    // 0x86c054: r0 = AnimatedBuilder()
    //     0x86c054: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x86c058: mov             x1, x0
    // 0x86c05c: ldur            x0, [fp, #-0x28]
    // 0x86c060: stur            x1, [fp, #-0x30]
    // 0x86c064: StoreField: r1->field_f = r0
    //     0x86c064: stur            w0, [x1, #0xf]
    // 0x86c068: ldur            x0, [fp, #-0x20]
    // 0x86c06c: StoreField: r1->field_13 = r0
    //     0x86c06c: stur            w0, [x1, #0x13]
    // 0x86c070: ldur            x0, [fp, #-0x38]
    // 0x86c074: StoreField: r1->field_b = r0
    //     0x86c074: stur            w0, [x1, #0xb]
    // 0x86c078: r0 = IgnorePointer()
    //     0x86c078: bl              #0x8303bc  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0x86c07c: mov             x1, x0
    // 0x86c080: ldur            x0, [fp, #-0x18]
    // 0x86c084: stur            x1, [fp, #-0x20]
    // 0x86c088: StoreField: r1->field_f = r0
    //     0x86c088: stur            w0, [x1, #0xf]
    // 0x86c08c: ldur            x0, [fp, #-0x30]
    // 0x86c090: StoreField: r1->field_b = r0
    //     0x86c090: stur            w0, [x1, #0xb]
    // 0x86c094: r0 = TextFieldTapRegion()
    //     0x86c094: bl              #0x7c7de8  ; AllocateTextFieldTapRegionStub -> TextFieldTapRegion (size=0x28)
    // 0x86c098: mov             x3, x0
    // 0x86c09c: r0 = true
    //     0x86c09c: add             x0, NULL, #0x20  ; true
    // 0x86c0a0: stur            x3, [fp, #-0x18]
    // 0x86c0a4: StoreField: r3->field_f = r0
    //     0x86c0a4: stur            w0, [x3, #0xf]
    // 0x86c0a8: r1 = Instance_HitTestBehavior
    //     0x86c0a8: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f780] Obj!HitTestBehavior@b64931
    //     0x86c0ac: ldr             x1, [x1, #0x780]
    // 0x86c0b0: StoreField: r3->field_13 = r1
    //     0x86c0b0: stur            w1, [x3, #0x13]
    // 0x86c0b4: r1 = EditableText
    //     0x86c0b4: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f788] Type: EditableText
    //     0x86c0b8: ldr             x1, [x1, #0x788]
    // 0x86c0bc: StoreField: r3->field_1f = r1
    //     0x86c0bc: stur            w1, [x3, #0x1f]
    // 0x86c0c0: ldur            x1, [fp, #-0x20]
    // 0x86c0c4: StoreField: r3->field_b = r1
    //     0x86c0c4: stur            w1, [x3, #0xb]
    // 0x86c0c8: ldur            x2, [fp, #-8]
    // 0x86c0cc: r1 = Function '<anonymous closure>':.
    //     0x86c0cc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dd10] AnonymousClosure: (0x8721e8), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x86c0d0: ldr             x1, [x1, #0xd10]
    // 0x86c0d4: r0 = AllocateClosure()
    //     0x86c0d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86c0d8: stur            x0, [fp, #-0x20]
    // 0x86c0dc: r0 = MouseRegion()
    //     0x86c0dc: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0x86c0e0: mov             x3, x0
    // 0x86c0e4: ldur            x0, [fp, #-0x20]
    // 0x86c0e8: stur            x3, [fp, #-0x28]
    // 0x86c0ec: StoreField: r3->field_f = r0
    //     0x86c0ec: stur            w0, [x3, #0xf]
    // 0x86c0f0: ldur            x2, [fp, #-8]
    // 0x86c0f4: r1 = Function '<anonymous closure>':.
    //     0x86c0f4: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dd18] AnonymousClosure: (0x87219c), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x86c0f8: ldr             x1, [x1, #0xd18]
    // 0x86c0fc: r0 = AllocateClosure()
    //     0x86c0fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86c100: mov             x1, x0
    // 0x86c104: ldur            x0, [fp, #-0x28]
    // 0x86c108: StoreField: r0->field_17 = r1
    //     0x86c108: stur            w1, [x0, #0x17]
    // 0x86c10c: ldur            x1, [fp, #-0x10]
    // 0x86c110: StoreField: r0->field_1b = r1
    //     0x86c110: stur            w1, [x0, #0x1b]
    // 0x86c114: r1 = true
    //     0x86c114: add             x1, NULL, #0x20  ; true
    // 0x86c118: StoreField: r0->field_1f = r1
    //     0x86c118: stur            w1, [x0, #0x1f]
    // 0x86c11c: ldur            x1, [fp, #-0x18]
    // 0x86c120: StoreField: r0->field_b = r1
    //     0x86c120: stur            w1, [x0, #0xb]
    // 0x86c124: LeaveFrame
    //     0x86c124: mov             SP, fp
    //     0x86c128: ldp             fp, lr, [SP], #0x10
    // 0x86c12c: ret
    //     0x86c12c: ret             
    // 0x86c130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86c130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86c134: b               #0x86b024
    // 0x86c138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c138: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c13c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c13c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c140: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c144: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c144: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c148: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x86c148: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x86c14c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c14c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c150: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c150: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c154: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c154: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c158: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c15c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c15c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c160: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c160: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c164: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c164: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c168: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c16c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c16c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c170: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c170: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c174: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86c174: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86c178: r9 = _selectionGestureDetectorBuilder
    //     0x86c178: add             x9, PP, #0x2d, lsl #12  ; [pp+0x2dd20] Field <_TextFieldState@823181401._selectionGestureDetectorBuilder@823181401>: late (offset: 0x34)
    //     0x86c17c: ldr             x9, [x9, #0xd20]
    // 0x86c180: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86c180: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _requestKeyboard(/* No info */) {
    // ** addr: 0x8707c4, size: 0x50
    // 0x8707c4: EnterFrame
    //     0x8707c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8707c8: mov             fp, SP
    // 0x8707cc: CheckStackOverflow
    //     0x8707cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8707d0: cmp             SP, x16
    //     0x8707d4: b.ls            #0x87080c
    // 0x8707d8: ldr             x16, [fp, #0x10]
    // 0x8707dc: SaveReg r16
    //     0x8707dc: str             x16, [SP, #-8]!
    // 0x8707e0: r0 = _editableText()
    //     0x8707e0: bl              #0x83da94  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_editableText
    // 0x8707e4: add             SP, SP, #8
    // 0x8707e8: cmp             w0, NULL
    // 0x8707ec: b.eq            #0x8707fc
    // 0x8707f0: SaveReg r0
    //     0x8707f0: str             x0, [SP, #-8]!
    // 0x8707f4: r0 = requestKeyboard()
    //     0x8707f4: bl              #0x7cdc78  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::requestKeyboard
    // 0x8707f8: add             SP, SP, #8
    // 0x8707fc: r0 = Null
    //     0x8707fc: mov             x0, NULL
    // 0x870800: LeaveFrame
    //     0x870800: mov             SP, fp
    //     0x870804: ldp             fp, lr, [SP], #0x10
    // 0x870808: ret
    //     0x870808: ret             
    // 0x87080c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87080c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870810: b               #0x8707d8
  }
  get _ _hasError(/* No info */) {
    // ** addr: 0x871064, size: 0x6c
    // 0x871064: EnterFrame
    //     0x871064: stp             fp, lr, [SP, #-0x10]!
    //     0x871068: mov             fp, SP
    // 0x87106c: CheckStackOverflow
    //     0x87106c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x871070: cmp             SP, x16
    //     0x871074: b.ls            #0x8710c4
    // 0x871078: ldr             x0, [fp, #0x10]
    // 0x87107c: LoadField: r1 = r0->field_b
    //     0x87107c: ldur            w1, [x0, #0xb]
    // 0x871080: DecompressPointer r1
    //     0x871080: add             x1, x1, HEAP, lsl #32
    // 0x871084: cmp             w1, NULL
    // 0x871088: b.eq            #0x8710cc
    // 0x87108c: LoadField: r2 = r1->field_17
    //     0x87108c: ldur            w2, [x1, #0x17]
    // 0x871090: DecompressPointer r2
    //     0x871090: add             x2, x2, HEAP, lsl #32
    // 0x871094: LoadField: r1 = r2->field_3b
    //     0x871094: ldur            w1, [x2, #0x3b]
    // 0x871098: DecompressPointer r1
    //     0x871098: add             x1, x1, HEAP, lsl #32
    // 0x87109c: cmp             w1, NULL
    // 0x8710a0: b.eq            #0x8710ac
    // 0x8710a4: r0 = true
    //     0x8710a4: add             x0, NULL, #0x20  ; true
    // 0x8710a8: b               #0x8710b8
    // 0x8710ac: SaveReg r0
    //     0x8710ac: str             x0, [SP, #-8]!
    // 0x8710b0: r0 = _hasIntrinsicError()
    //     0x8710b0: bl              #0x8710d0  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasIntrinsicError
    // 0x8710b4: add             SP, SP, #8
    // 0x8710b8: LeaveFrame
    //     0x8710b8: mov             SP, fp
    //     0x8710bc: ldp             fp, lr, [SP], #0x10
    // 0x8710c0: ret
    //     0x8710c0: ret             
    // 0x8710c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8710c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8710c8: b               #0x871078
    // 0x8710cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8710cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _hasIntrinsicError(/* No info */) {
    // ** addr: 0x8710d0, size: 0xe4
    // 0x8710d0: EnterFrame
    //     0x8710d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8710d4: mov             fp, SP
    // 0x8710d8: CheckStackOverflow
    //     0x8710d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8710dc: cmp             SP, x16
    //     0x8710e0: b.ls            #0x8711a0
    // 0x8710e4: ldr             x0, [fp, #0x10]
    // 0x8710e8: LoadField: r1 = r0->field_b
    //     0x8710e8: ldur            w1, [x0, #0xb]
    // 0x8710ec: DecompressPointer r1
    //     0x8710ec: add             x1, x1, HEAP, lsl #32
    // 0x8710f0: cmp             w1, NULL
    // 0x8710f4: b.eq            #0x8711a8
    // 0x8710f8: LoadField: r2 = r1->field_6f
    //     0x8710f8: ldur            w2, [x1, #0x6f]
    // 0x8710fc: DecompressPointer r2
    //     0x8710fc: add             x2, x2, HEAP, lsl #32
    // 0x871100: cmp             w2, NULL
    // 0x871104: b.eq            #0x871190
    // 0x871108: r3 = LoadInt32Instr(r2)
    //     0x871108: sbfx            x3, x2, #1, #0x1f
    // 0x87110c: cmp             x3, #0
    // 0x871110: b.le            #0x871190
    // 0x871114: LoadField: r2 = r1->field_f
    //     0x871114: ldur            w2, [x1, #0xf]
    // 0x871118: DecompressPointer r2
    //     0x871118: add             x2, x2, HEAP, lsl #32
    // 0x87111c: LoadField: r1 = r2->field_27
    //     0x87111c: ldur            w1, [x2, #0x27]
    // 0x871120: DecompressPointer r1
    //     0x871120: add             x1, x1, HEAP, lsl #32
    // 0x871124: LoadField: r2 = r1->field_7
    //     0x871124: ldur            w2, [x1, #7]
    // 0x871128: DecompressPointer r2
    //     0x871128: add             x2, x2, HEAP, lsl #32
    // 0x87112c: SaveReg r2
    //     0x87112c: str             x2, [SP, #-8]!
    // 0x871130: r0 = StringCharacters.characters()
    //     0x871130: bl              #0x5254a4  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x871134: add             SP, SP, #8
    // 0x871138: SaveReg r0
    //     0x871138: str             x0, [SP, #-8]!
    // 0x87113c: r0 = length()
    //     0x87113c: bl              #0x6fd6e8  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x871140: add             SP, SP, #8
    // 0x871144: ldr             x1, [fp, #0x10]
    // 0x871148: LoadField: r2 = r1->field_b
    //     0x871148: ldur            w2, [x1, #0xb]
    // 0x87114c: DecompressPointer r2
    //     0x87114c: add             x2, x2, HEAP, lsl #32
    // 0x871150: cmp             w2, NULL
    // 0x871154: b.eq            #0x8711ac
    // 0x871158: LoadField: r1 = r2->field_6f
    //     0x871158: ldur            w1, [x2, #0x6f]
    // 0x87115c: DecompressPointer r1
    //     0x87115c: add             x1, x1, HEAP, lsl #32
    // 0x871160: cmp             w1, NULL
    // 0x871164: b.eq            #0x8711b0
    // 0x871168: r2 = LoadInt32Instr(r0)
    //     0x871168: sbfx            x2, x0, #1, #0x1f
    //     0x87116c: tbz             w0, #0, #0x871174
    //     0x871170: ldur            x2, [x0, #7]
    // 0x871174: r3 = LoadInt32Instr(r1)
    //     0x871174: sbfx            x3, x1, #1, #0x1f
    // 0x871178: cmp             x2, x3
    // 0x87117c: r16 = true
    //     0x87117c: add             x16, NULL, #0x20  ; true
    // 0x871180: r17 = false
    //     0x871180: add             x17, NULL, #0x30  ; false
    // 0x871184: csel            x1, x16, x17, gt
    // 0x871188: mov             x0, x1
    // 0x87118c: b               #0x871194
    // 0x871190: r0 = false
    //     0x871190: add             x0, NULL, #0x30  ; false
    // 0x871194: LeaveFrame
    //     0x871194: mov             SP, fp
    //     0x871198: ldp             fp, lr, [SP], #0x10
    // 0x87119c: ret
    //     0x87119c: ret             
    // 0x8711a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8711a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8711a4: b               #0x8710e4
    // 0x8711a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8711a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8711ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8711ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8711b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8711b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PointerExitEvent) {
    // ** addr: 0x87219c, size: 0x4c
    // 0x87219c: EnterFrame
    //     0x87219c: stp             fp, lr, [SP, #-0x10]!
    //     0x8721a0: mov             fp, SP
    // 0x8721a4: ldr             x0, [fp, #0x18]
    // 0x8721a8: LoadField: r1 = r0->field_17
    //     0x8721a8: ldur            w1, [x0, #0x17]
    // 0x8721ac: DecompressPointer r1
    //     0x8721ac: add             x1, x1, HEAP, lsl #32
    // 0x8721b0: CheckStackOverflow
    //     0x8721b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8721b4: cmp             SP, x16
    //     0x8721b8: b.ls            #0x8721e0
    // 0x8721bc: LoadField: r0 = r1->field_f
    //     0x8721bc: ldur            w0, [x1, #0xf]
    // 0x8721c0: DecompressPointer r0
    //     0x8721c0: add             x0, x0, HEAP, lsl #32
    // 0x8721c4: r16 = false
    //     0x8721c4: add             x16, NULL, #0x30  ; false
    // 0x8721c8: stp             x16, x0, [SP, #-0x10]!
    // 0x8721cc: r0 = _handleHover()
    //     0x8721cc: bl              #0x83d6cc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover
    // 0x8721d0: add             SP, SP, #0x10
    // 0x8721d4: LeaveFrame
    //     0x8721d4: mov             SP, fp
    //     0x8721d8: ldp             fp, lr, [SP], #0x10
    // 0x8721dc: ret
    //     0x8721dc: ret             
    // 0x8721e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8721e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8721e4: b               #0x8721bc
  }
  [closure] void <anonymous closure>(dynamic, PointerEnterEvent) {
    // ** addr: 0x8721e8, size: 0x4c
    // 0x8721e8: EnterFrame
    //     0x8721e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8721ec: mov             fp, SP
    // 0x8721f0: ldr             x0, [fp, #0x18]
    // 0x8721f4: LoadField: r1 = r0->field_17
    //     0x8721f4: ldur            w1, [x0, #0x17]
    // 0x8721f8: DecompressPointer r1
    //     0x8721f8: add             x1, x1, HEAP, lsl #32
    // 0x8721fc: CheckStackOverflow
    //     0x8721fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872200: cmp             SP, x16
    //     0x872204: b.ls            #0x87222c
    // 0x872208: LoadField: r0 = r1->field_f
    //     0x872208: ldur            w0, [x1, #0xf]
    // 0x87220c: DecompressPointer r0
    //     0x87220c: add             x0, x0, HEAP, lsl #32
    // 0x872210: r16 = true
    //     0x872210: add             x16, NULL, #0x20  ; true
    // 0x872214: stp             x16, x0, [SP, #-0x10]!
    // 0x872218: r0 = _handleHover()
    //     0x872218: bl              #0x83d6cc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleHover
    // 0x87221c: add             SP, SP, #0x10
    // 0x872220: LeaveFrame
    //     0x872220: mov             SP, fp
    //     0x872224: ldp             fp, lr, [SP], #0x10
    // 0x872228: ret
    //     0x872228: ret             
    // 0x87222c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87222c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872230: b               #0x872208
  }
  [closure] Semantics <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x872234, size: 0xf0
    // 0x872234: EnterFrame
    //     0x872234: stp             fp, lr, [SP, #-0x10]!
    //     0x872238: mov             fp, SP
    // 0x87223c: AllocStack(0x20)
    //     0x87223c: sub             SP, SP, #0x20
    // 0x872240: SetupParameters()
    //     0x872240: ldr             x0, [fp, #0x20]
    //     0x872244: ldur            w2, [x0, #0x17]
    //     0x872248: add             x2, x2, HEAP, lsl #32
    //     0x87224c: stur            x2, [fp, #-0x10]
    // 0x872250: CheckStackOverflow
    //     0x872250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872254: cmp             SP, x16
    //     0x872258: b.ls            #0x872318
    // 0x87225c: LoadField: r0 = r2->field_1f
    //     0x87225c: ldur            w0, [x2, #0x1f]
    // 0x872260: DecompressPointer r0
    //     0x872260: add             x0, x0, HEAP, lsl #32
    // 0x872264: stur            x0, [fp, #-8]
    // 0x872268: LoadField: r1 = r2->field_f
    //     0x872268: ldur            w1, [x2, #0xf]
    // 0x87226c: DecompressPointer r1
    //     0x87226c: add             x1, x1, HEAP, lsl #32
    // 0x872270: SaveReg r1
    //     0x872270: str             x1, [SP, #-8]!
    // 0x872274: r0 = _currentLength()
    //     0x872274: bl              #0x872324  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_currentLength
    // 0x872278: add             SP, SP, #8
    // 0x87227c: mov             x3, x0
    // 0x872280: ldur            x2, [fp, #-0x10]
    // 0x872284: LoadField: r0 = r2->field_f
    //     0x872284: ldur            w0, [x2, #0xf]
    // 0x872288: DecompressPointer r0
    //     0x872288: add             x0, x0, HEAP, lsl #32
    // 0x87228c: LoadField: r1 = r0->field_b
    //     0x87228c: ldur            w1, [x0, #0xb]
    // 0x872290: DecompressPointer r1
    //     0x872290: add             x1, x1, HEAP, lsl #32
    // 0x872294: cmp             w1, NULL
    // 0x872298: b.eq            #0x872320
    // 0x87229c: LoadField: r4 = r2->field_1b
    //     0x87229c: ldur            w4, [x2, #0x1b]
    // 0x8722a0: DecompressPointer r4
    //     0x8722a0: add             x4, x4, HEAP, lsl #32
    // 0x8722a4: stur            x4, [fp, #-0x20]
    // 0x8722a8: r0 = BoxInt64Instr(r3)
    //     0x8722a8: sbfiz           x0, x3, #1, #0x1f
    //     0x8722ac: cmp             x3, x0, asr #1
    //     0x8722b0: b.eq            #0x8722bc
    //     0x8722b4: bl              #0xd69bb8
    //     0x8722b8: stur            x3, [x0, #7]
    // 0x8722bc: stur            x0, [fp, #-0x18]
    // 0x8722c0: r0 = Semantics()
    //     0x8722c0: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x8722c4: ldur            x2, [fp, #-0x10]
    // 0x8722c8: r1 = Function '<anonymous closure>':.
    //     0x8722c8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dd30] AnonymousClosure: (0x8723a4), in [package:flutter/src/material/text_field.dart] _TextFieldState::build (0x86b00c)
    //     0x8722cc: ldr             x1, [x1, #0xd30]
    // 0x8722d0: stur            x0, [fp, #-0x10]
    // 0x8722d4: r0 = AllocateClosure()
    //     0x8722d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8722d8: ldur            x16, [fp, #-0x10]
    // 0x8722dc: ldur            lr, [fp, #-8]
    // 0x8722e0: stp             lr, x16, [SP, #-0x10]!
    // 0x8722e4: ldur            x16, [fp, #-0x18]
    // 0x8722e8: stp             x0, x16, [SP, #-0x10]!
    // 0x8722ec: ldur            x16, [fp, #-0x20]
    // 0x8722f0: ldr             lr, [fp, #0x10]
    // 0x8722f4: stp             lr, x16, [SP, #-0x10]!
    // 0x8722f8: r4 = const [0, 0x6, 0x6, 0x1, child, 0x5, currentValueLength, 0x2, maxValueLength, 0x1, onDidGainAccessibilityFocus, 0x4, onTap, 0x3, null]
    //     0x8722f8: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd38] List(15) [0, 0x6, 0x6, 0x1, "child", 0x5, "currentValueLength", 0x2, "maxValueLength", 0x1, "onDidGainAccessibilityFocus", 0x4, "onTap", 0x3, Null]
    //     0x8722fc: ldr             x4, [x4, #0xd38]
    // 0x872300: r0 = Semantics()
    //     0x872300: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x872304: add             SP, SP, #0x30
    // 0x872308: ldur            x0, [fp, #-0x10]
    // 0x87230c: LeaveFrame
    //     0x87230c: mov             SP, fp
    //     0x872310: ldp             fp, lr, [SP], #0x10
    // 0x872314: ret
    //     0x872314: ret             
    // 0x872318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87231c: b               #0x87225c
    // 0x872320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872320: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _currentLength(/* No info */) {
    // ** addr: 0x872324, size: 0x80
    // 0x872324: EnterFrame
    //     0x872324: stp             fp, lr, [SP, #-0x10]!
    //     0x872328: mov             fp, SP
    // 0x87232c: CheckStackOverflow
    //     0x87232c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872330: cmp             SP, x16
    //     0x872334: b.ls            #0x872398
    // 0x872338: ldr             x0, [fp, #0x10]
    // 0x87233c: LoadField: r1 = r0->field_b
    //     0x87233c: ldur            w1, [x0, #0xb]
    // 0x872340: DecompressPointer r1
    //     0x872340: add             x1, x1, HEAP, lsl #32
    // 0x872344: cmp             w1, NULL
    // 0x872348: b.eq            #0x8723a0
    // 0x87234c: LoadField: r0 = r1->field_f
    //     0x87234c: ldur            w0, [x1, #0xf]
    // 0x872350: DecompressPointer r0
    //     0x872350: add             x0, x0, HEAP, lsl #32
    // 0x872354: LoadField: r1 = r0->field_27
    //     0x872354: ldur            w1, [x0, #0x27]
    // 0x872358: DecompressPointer r1
    //     0x872358: add             x1, x1, HEAP, lsl #32
    // 0x87235c: LoadField: r0 = r1->field_7
    //     0x87235c: ldur            w0, [x1, #7]
    // 0x872360: DecompressPointer r0
    //     0x872360: add             x0, x0, HEAP, lsl #32
    // 0x872364: SaveReg r0
    //     0x872364: str             x0, [SP, #-8]!
    // 0x872368: r0 = StringCharacters.characters()
    //     0x872368: bl              #0x5254a4  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x87236c: add             SP, SP, #8
    // 0x872370: SaveReg r0
    //     0x872370: str             x0, [SP, #-8]!
    // 0x872374: r0 = length()
    //     0x872374: bl              #0x6fd6e8  ; [package:characters/src/characters_impl.dart] StringCharacters::length
    // 0x872378: add             SP, SP, #8
    // 0x87237c: r1 = LoadInt32Instr(r0)
    //     0x87237c: sbfx            x1, x0, #1, #0x1f
    //     0x872380: tbz             w0, #0, #0x872388
    //     0x872384: ldur            x1, [x0, #7]
    // 0x872388: mov             x0, x1
    // 0x87238c: LeaveFrame
    //     0x87238c: mov             SP, fp
    //     0x872390: ldp             fp, lr, [SP], #0x10
    // 0x872394: ret
    //     0x872394: ret             
    // 0x872398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87239c: b               #0x872338
    // 0x8723a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8723a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8723a4, size: 0xfc
    // 0x8723a4: EnterFrame
    //     0x8723a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8723a8: mov             fp, SP
    // 0x8723ac: AllocStack(0x18)
    //     0x8723ac: sub             SP, SP, #0x18
    // 0x8723b0: SetupParameters()
    //     0x8723b0: ldr             x0, [fp, #0x10]
    //     0x8723b4: ldur            w1, [x0, #0x17]
    //     0x8723b8: add             x1, x1, HEAP, lsl #32
    //     0x8723bc: stur            x1, [fp, #-0x18]
    // 0x8723c0: CheckStackOverflow
    //     0x8723c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8723c4: cmp             SP, x16
    //     0x8723c8: b.ls            #0x872494
    // 0x8723cc: LoadField: r0 = r1->field_f
    //     0x8723cc: ldur            w0, [x1, #0xf]
    // 0x8723d0: DecompressPointer r0
    //     0x8723d0: add             x0, x0, HEAP, lsl #32
    // 0x8723d4: LoadField: r2 = r0->field_b
    //     0x8723d4: ldur            w2, [x0, #0xb]
    // 0x8723d8: DecompressPointer r2
    //     0x8723d8: add             x2, x2, HEAP, lsl #32
    // 0x8723dc: cmp             w2, NULL
    // 0x8723e0: b.eq            #0x87249c
    // 0x8723e4: LoadField: r0 = r2->field_f
    //     0x8723e4: ldur            w0, [x2, #0xf]
    // 0x8723e8: DecompressPointer r0
    //     0x8723e8: add             x0, x0, HEAP, lsl #32
    // 0x8723ec: stur            x0, [fp, #-0x10]
    // 0x8723f0: LoadField: r2 = r0->field_27
    //     0x8723f0: ldur            w2, [x0, #0x27]
    // 0x8723f4: DecompressPointer r2
    //     0x8723f4: add             x2, x2, HEAP, lsl #32
    // 0x8723f8: LoadField: r3 = r2->field_b
    //     0x8723f8: ldur            w3, [x2, #0xb]
    // 0x8723fc: DecompressPointer r3
    //     0x8723fc: add             x3, x3, HEAP, lsl #32
    // 0x872400: LoadField: r4 = r3->field_7
    //     0x872400: ldur            x4, [x3, #7]
    // 0x872404: tbnz            x4, #0x3f, #0x872418
    // 0x872408: LoadField: r4 = r3->field_f
    //     0x872408: ldur            x4, [x3, #0xf]
    // 0x87240c: tbnz            x4, #0x3f, #0x872418
    // 0x872410: mov             x0, x1
    // 0x872414: b               #0x872470
    // 0x872418: LoadField: r3 = r2->field_7
    //     0x872418: ldur            w3, [x2, #7]
    // 0x87241c: DecompressPointer r3
    //     0x87241c: add             x3, x3, HEAP, lsl #32
    // 0x872420: LoadField: r2 = r3->field_7
    //     0x872420: ldur            w2, [x3, #7]
    // 0x872424: DecompressPointer r2
    //     0x872424: add             x2, x2, HEAP, lsl #32
    // 0x872428: stur            x2, [fp, #-8]
    // 0x87242c: r0 = TextSelection()
    //     0x87242c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x872430: mov             x1, x0
    // 0x872434: r0 = Instance_TextAffinity
    //     0x872434: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x872438: StoreField: r1->field_27 = r0
    //     0x872438: stur            w0, [x1, #0x27]
    // 0x87243c: ldur            x0, [fp, #-8]
    // 0x872440: r2 = LoadInt32Instr(r0)
    //     0x872440: sbfx            x2, x0, #1, #0x1f
    // 0x872444: StoreField: r1->field_17 = r2
    //     0x872444: stur            x2, [x1, #0x17]
    // 0x872448: StoreField: r1->field_1f = r2
    //     0x872448: stur            x2, [x1, #0x1f]
    // 0x87244c: r0 = false
    //     0x87244c: add             x0, NULL, #0x30  ; false
    // 0x872450: StoreField: r1->field_2b = r0
    //     0x872450: stur            w0, [x1, #0x2b]
    // 0x872454: StoreField: r1->field_7 = r2
    //     0x872454: stur            x2, [x1, #7]
    // 0x872458: StoreField: r1->field_f = r2
    //     0x872458: stur            x2, [x1, #0xf]
    // 0x87245c: ldur            x16, [fp, #-0x10]
    // 0x872460: stp             x1, x16, [SP, #-0x10]!
    // 0x872464: r0 = selection=()
    //     0x872464: bl              #0x79a43c  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::selection=
    // 0x872468: add             SP, SP, #0x10
    // 0x87246c: ldur            x0, [fp, #-0x18]
    // 0x872470: LoadField: r1 = r0->field_f
    //     0x872470: ldur            w1, [x0, #0xf]
    // 0x872474: DecompressPointer r1
    //     0x872474: add             x1, x1, HEAP, lsl #32
    // 0x872478: SaveReg r1
    //     0x872478: str             x1, [SP, #-8]!
    // 0x87247c: r0 = _requestKeyboard()
    //     0x87247c: bl              #0x8707c4  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_requestKeyboard
    // 0x872480: add             SP, SP, #8
    // 0x872484: r0 = Null
    //     0x872484: mov             x0, NULL
    // 0x872488: LeaveFrame
    //     0x872488: mov             SP, fp
    //     0x87248c: ldp             fp, lr, [SP], #0x10
    // 0x872490: ret
    //     0x872490: ret             
    // 0x872494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872498: b               #0x8723cc
    // 0x87249c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87249c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] InputDecorator <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x8724a0, size: 0x164
    // 0x8724a0: EnterFrame
    //     0x8724a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8724a4: mov             fp, SP
    // 0x8724a8: AllocStack(0x40)
    //     0x8724a8: sub             SP, SP, #0x40
    // 0x8724ac: SetupParameters()
    //     0x8724ac: ldr             x0, [fp, #0x20]
    //     0x8724b0: ldur            w1, [x0, #0x17]
    //     0x8724b4: add             x1, x1, HEAP, lsl #32
    //     0x8724b8: stur            x1, [fp, #-8]
    // 0x8724bc: CheckStackOverflow
    //     0x8724bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8724c0: cmp             SP, x16
    //     0x8724c4: b.ls            #0x8725f4
    // 0x8724c8: LoadField: r0 = r1->field_f
    //     0x8724c8: ldur            w0, [x1, #0xf]
    // 0x8724cc: DecompressPointer r0
    //     0x8724cc: add             x0, x0, HEAP, lsl #32
    // 0x8724d0: SaveReg r0
    //     0x8724d0: str             x0, [SP, #-8]!
    // 0x8724d4: r0 = _getEffectiveDecoration()
    //     0x8724d4: bl              #0x872604  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_getEffectiveDecoration
    // 0x8724d8: add             SP, SP, #8
    // 0x8724dc: mov             x1, x0
    // 0x8724e0: ldur            x0, [fp, #-8]
    // 0x8724e4: stur            x1, [fp, #-0x30]
    // 0x8724e8: LoadField: r2 = r0->field_f
    //     0x8724e8: ldur            w2, [x0, #0xf]
    // 0x8724ec: DecompressPointer r2
    //     0x8724ec: add             x2, x2, HEAP, lsl #32
    // 0x8724f0: LoadField: r3 = r2->field_b
    //     0x8724f0: ldur            w3, [x2, #0xb]
    // 0x8724f4: DecompressPointer r3
    //     0x8724f4: add             x3, x3, HEAP, lsl #32
    // 0x8724f8: cmp             w3, NULL
    // 0x8724fc: b.eq            #0x8725fc
    // 0x872500: LoadField: r4 = r3->field_27
    //     0x872500: ldur            w4, [x3, #0x27]
    // 0x872504: DecompressPointer r4
    //     0x872504: add             x4, x4, HEAP, lsl #32
    // 0x872508: stur            x4, [fp, #-0x28]
    // 0x87250c: LoadField: r5 = r3->field_2f
    //     0x87250c: ldur            w5, [x3, #0x2f]
    // 0x872510: DecompressPointer r5
    //     0x872510: add             x5, x5, HEAP, lsl #32
    // 0x872514: stur            x5, [fp, #-0x20]
    // 0x872518: LoadField: r6 = r3->field_33
    //     0x872518: ldur            w6, [x3, #0x33]
    // 0x87251c: DecompressPointer r6
    //     0x87251c: add             x6, x6, HEAP, lsl #32
    // 0x872520: stur            x6, [fp, #-0x18]
    // 0x872524: LoadField: r3 = r2->field_2b
    //     0x872524: ldur            w3, [x2, #0x2b]
    // 0x872528: DecompressPointer r3
    //     0x872528: add             x3, x3, HEAP, lsl #32
    // 0x87252c: stur            x3, [fp, #-0x10]
    // 0x872530: LoadField: r2 = r0->field_17
    //     0x872530: ldur            w2, [x0, #0x17]
    // 0x872534: DecompressPointer r2
    //     0x872534: add             x2, x2, HEAP, lsl #32
    // 0x872538: SaveReg r2
    //     0x872538: str             x2, [SP, #-8]!
    // 0x87253c: r0 = hasFocus()
    //     0x87253c: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x872540: add             SP, SP, #8
    // 0x872544: mov             x1, x0
    // 0x872548: ldur            x0, [fp, #-8]
    // 0x87254c: stur            x1, [fp, #-0x40]
    // 0x872550: LoadField: r2 = r0->field_13
    //     0x872550: ldur            w2, [x0, #0x13]
    // 0x872554: DecompressPointer r2
    //     0x872554: add             x2, x2, HEAP, lsl #32
    // 0x872558: LoadField: r3 = r2->field_27
    //     0x872558: ldur            w3, [x2, #0x27]
    // 0x87255c: DecompressPointer r3
    //     0x87255c: add             x3, x3, HEAP, lsl #32
    // 0x872560: LoadField: r2 = r3->field_7
    //     0x872560: ldur            w2, [x3, #7]
    // 0x872564: DecompressPointer r2
    //     0x872564: add             x2, x2, HEAP, lsl #32
    // 0x872568: LoadField: r3 = r2->field_7
    //     0x872568: ldur            w3, [x2, #7]
    // 0x87256c: DecompressPointer r3
    //     0x87256c: add             x3, x3, HEAP, lsl #32
    // 0x872570: cbz             w3, #0x87257c
    // 0x872574: r2 = false
    //     0x872574: add             x2, NULL, #0x30  ; false
    // 0x872578: b               #0x872580
    // 0x87257c: r2 = true
    //     0x87257c: add             x2, NULL, #0x20  ; true
    // 0x872580: stur            x2, [fp, #-0x38]
    // 0x872584: LoadField: r3 = r0->field_f
    //     0x872584: ldur            w3, [x0, #0xf]
    // 0x872588: DecompressPointer r3
    //     0x872588: add             x3, x3, HEAP, lsl #32
    // 0x87258c: LoadField: r0 = r3->field_b
    //     0x87258c: ldur            w0, [x3, #0xb]
    // 0x872590: DecompressPointer r0
    //     0x872590: add             x0, x0, HEAP, lsl #32
    // 0x872594: cmp             w0, NULL
    // 0x872598: b.eq            #0x872600
    // 0x87259c: r0 = InputDecorator()
    //     0x87259c: bl              #0x83dc1c  ; AllocateInputDecoratorStub -> InputDecorator (size=0x30)
    // 0x8725a0: ldur            x1, [fp, #-0x30]
    // 0x8725a4: StoreField: r0->field_b = r1
    //     0x8725a4: stur            w1, [x0, #0xb]
    // 0x8725a8: ldur            x1, [fp, #-0x28]
    // 0x8725ac: StoreField: r0->field_f = r1
    //     0x8725ac: stur            w1, [x0, #0xf]
    // 0x8725b0: ldur            x1, [fp, #-0x20]
    // 0x8725b4: StoreField: r0->field_13 = r1
    //     0x8725b4: stur            w1, [x0, #0x13]
    // 0x8725b8: ldur            x1, [fp, #-0x18]
    // 0x8725bc: StoreField: r0->field_17 = r1
    //     0x8725bc: stur            w1, [x0, #0x17]
    // 0x8725c0: ldur            x1, [fp, #-0x40]
    // 0x8725c4: StoreField: r0->field_1b = r1
    //     0x8725c4: stur            w1, [x0, #0x1b]
    // 0x8725c8: ldur            x1, [fp, #-0x10]
    // 0x8725cc: StoreField: r0->field_1f = r1
    //     0x8725cc: stur            w1, [x0, #0x1f]
    // 0x8725d0: r1 = false
    //     0x8725d0: add             x1, NULL, #0x30  ; false
    // 0x8725d4: StoreField: r0->field_23 = r1
    //     0x8725d4: stur            w1, [x0, #0x23]
    // 0x8725d8: ldur            x1, [fp, #-0x38]
    // 0x8725dc: StoreField: r0->field_27 = r1
    //     0x8725dc: stur            w1, [x0, #0x27]
    // 0x8725e0: ldr             x1, [fp, #0x10]
    // 0x8725e4: StoreField: r0->field_2b = r1
    //     0x8725e4: stur            w1, [x0, #0x2b]
    // 0x8725e8: LeaveFrame
    //     0x8725e8: mov             SP, fp
    //     0x8725ec: ldp             fp, lr, [SP], #0x10
    // 0x8725f0: ret
    //     0x8725f0: ret             
    // 0x8725f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8725f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8725f8: b               #0x8724c8
    // 0x8725fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8725fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872600: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872600: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getEffectiveDecoration(/* No info */) {
    // ** addr: 0x872604, size: 0x424
    // 0x872604: EnterFrame
    //     0x872604: stp             fp, lr, [SP, #-0x10]!
    //     0x872608: mov             fp, SP
    // 0x87260c: AllocStack(0x30)
    //     0x87260c: sub             SP, SP, #0x30
    // 0x872610: CheckStackOverflow
    //     0x872610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872614: cmp             SP, x16
    //     0x872618: b.ls            #0x8729f0
    // 0x87261c: ldr             x0, [fp, #0x10]
    // 0x872620: LoadField: r1 = r0->field_f
    //     0x872620: ldur            w1, [x0, #0xf]
    // 0x872624: DecompressPointer r1
    //     0x872624: add             x1, x1, HEAP, lsl #32
    // 0x872628: cmp             w1, NULL
    // 0x87262c: b.eq            #0x8729f8
    // 0x872630: SaveReg r1
    //     0x872630: str             x1, [SP, #-8]!
    // 0x872634: r0 = of()
    //     0x872634: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x872638: add             SP, SP, #8
    // 0x87263c: mov             x1, x0
    // 0x872640: ldr             x0, [fp, #0x10]
    // 0x872644: stur            x1, [fp, #-8]
    // 0x872648: LoadField: r2 = r0->field_f
    //     0x872648: ldur            w2, [x0, #0xf]
    // 0x87264c: DecompressPointer r2
    //     0x87264c: add             x2, x2, HEAP, lsl #32
    // 0x872650: cmp             w2, NULL
    // 0x872654: b.eq            #0x8729fc
    // 0x872658: SaveReg r2
    //     0x872658: str             x2, [SP, #-8]!
    // 0x87265c: r0 = of()
    //     0x87265c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x872660: add             SP, SP, #8
    // 0x872664: mov             x1, x0
    // 0x872668: ldr             x0, [fp, #0x10]
    // 0x87266c: stur            x1, [fp, #-0x10]
    // 0x872670: LoadField: r2 = r0->field_b
    //     0x872670: ldur            w2, [x0, #0xb]
    // 0x872674: DecompressPointer r2
    //     0x872674: add             x2, x2, HEAP, lsl #32
    // 0x872678: cmp             w2, NULL
    // 0x87267c: b.eq            #0x872a00
    // 0x872680: LoadField: r3 = r2->field_17
    //     0x872680: ldur            w3, [x2, #0x17]
    // 0x872684: DecompressPointer r3
    //     0x872684: add             x3, x3, HEAP, lsl #32
    // 0x872688: SaveReg r3
    //     0x872688: str             x3, [SP, #-8]!
    // 0x87268c: r0 = applyDefaults()
    //     0x87268c: bl              #0x7b4a68  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0x872690: add             SP, SP, #8
    // 0x872694: stur            x0, [fp, #-0x18]
    // 0x872698: ldr             x16, [fp, #0x10]
    // 0x87269c: SaveReg r16
    //     0x87269c: str             x16, [SP, #-8]!
    // 0x8726a0: r0 = _isEnabled()
    //     0x8726a0: bl              #0x7beee8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_isEnabled
    // 0x8726a4: add             SP, SP, #8
    // 0x8726a8: mov             x1, x0
    // 0x8726ac: ldr             x0, [fp, #0x10]
    // 0x8726b0: LoadField: r2 = r0->field_b
    //     0x8726b0: ldur            w2, [x0, #0xb]
    // 0x8726b4: DecompressPointer r2
    //     0x8726b4: add             x2, x2, HEAP, lsl #32
    // 0x8726b8: cmp             w2, NULL
    // 0x8726bc: b.eq            #0x872a04
    // 0x8726c0: LoadField: r3 = r2->field_17
    //     0x8726c0: ldur            w3, [x2, #0x17]
    // 0x8726c4: DecompressPointer r3
    //     0x8726c4: add             x3, x3, HEAP, lsl #32
    // 0x8726c8: LoadField: r4 = r3->field_37
    //     0x8726c8: ldur            w4, [x3, #0x37]
    // 0x8726cc: DecompressPointer r4
    //     0x8726cc: add             x4, x4, HEAP, lsl #32
    // 0x8726d0: cmp             w4, NULL
    // 0x8726d4: b.ne            #0x8726e8
    // 0x8726d8: LoadField: r3 = r2->field_57
    //     0x8726d8: ldur            w3, [x2, #0x57]
    // 0x8726dc: DecompressPointer r3
    //     0x8726dc: add             x3, x3, HEAP, lsl #32
    // 0x8726e0: mov             x2, x3
    // 0x8726e4: b               #0x8726ec
    // 0x8726e8: mov             x2, x4
    // 0x8726ec: ldur            x16, [fp, #-0x18]
    // 0x8726f0: stp             x1, x16, [SP, #-0x10]!
    // 0x8726f4: SaveReg r2
    //     0x8726f4: str             x2, [SP, #-8]!
    // 0x8726f8: r4 = const [0, 0x3, 0x3, 0x1, enabled, 0x1, hintMaxLines, 0x2, null]
    //     0x8726f8: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd40] List(9) [0, 0x3, 0x3, 0x1, "enabled", 0x1, "hintMaxLines", 0x2, Null]
    //     0x8726fc: ldr             x4, [x4, #0xd40]
    // 0x872700: r0 = copyWith()
    //     0x872700: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x872704: add             SP, SP, #0x18
    // 0x872708: stur            x0, [fp, #-0x28]
    // 0x87270c: LoadField: r1 = r0->field_8f
    //     0x87270c: ldur            w1, [x0, #0x8f]
    // 0x872710: DecompressPointer r1
    //     0x872710: add             x1, x1, HEAP, lsl #32
    // 0x872714: stur            x1, [fp, #-0x20]
    // 0x872718: cmp             w1, NULL
    // 0x87271c: b.ne            #0x872734
    // 0x872720: LoadField: r2 = r0->field_8b
    //     0x872720: ldur            w2, [x0, #0x8b]
    // 0x872724: DecompressPointer r2
    //     0x872724: add             x2, x2, HEAP, lsl #32
    // 0x872728: stur            x2, [fp, #-0x18]
    // 0x87272c: cmp             w2, NULL
    // 0x872730: b.eq            #0x872740
    // 0x872734: LeaveFrame
    //     0x872734: mov             SP, fp
    //     0x872738: ldp             fp, lr, [SP], #0x10
    // 0x87273c: ret
    //     0x87273c: ret             
    // 0x872740: ldr             x16, [fp, #0x10]
    // 0x872744: SaveReg r16
    //     0x872744: str             x16, [SP, #-8]!
    // 0x872748: r0 = _currentLength()
    //     0x872748: bl              #0x872324  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_currentLength
    // 0x87274c: add             SP, SP, #8
    // 0x872750: mov             x2, x0
    // 0x872754: ldur            x0, [fp, #-0x20]
    // 0x872758: stur            x2, [fp, #-0x30]
    // 0x87275c: cmp             w0, NULL
    // 0x872760: b.ne            #0x872790
    // 0x872764: ldur            x0, [fp, #-0x18]
    // 0x872768: cmp             w0, NULL
    // 0x87276c: b.ne            #0x872788
    // 0x872770: ldr             x3, [fp, #0x10]
    // 0x872774: LoadField: r0 = r3->field_b
    //     0x872774: ldur            w0, [x3, #0xb]
    // 0x872778: DecompressPointer r0
    //     0x872778: add             x0, x0, HEAP, lsl #32
    // 0x87277c: cmp             w0, NULL
    // 0x872780: b.eq            #0x872a08
    // 0x872784: b               #0x872794
    // 0x872788: ldr             x3, [fp, #0x10]
    // 0x87278c: b               #0x872794
    // 0x872790: ldr             x3, [fp, #0x10]
    // 0x872794: LoadField: r0 = r3->field_b
    //     0x872794: ldur            w0, [x3, #0xb]
    // 0x872798: DecompressPointer r0
    //     0x872798: add             x0, x0, HEAP, lsl #32
    // 0x87279c: cmp             w0, NULL
    // 0x8727a0: b.eq            #0x872a0c
    // 0x8727a4: LoadField: r1 = r0->field_6f
    //     0x8727a4: ldur            w1, [x0, #0x6f]
    // 0x8727a8: DecompressPointer r1
    //     0x8727a8: add             x1, x1, HEAP, lsl #32
    // 0x8727ac: cmp             w1, NULL
    // 0x8727b0: b.ne            #0x8727c4
    // 0x8727b4: ldur            x0, [fp, #-0x28]
    // 0x8727b8: LeaveFrame
    //     0x8727b8: mov             SP, fp
    //     0x8727bc: ldp             fp, lr, [SP], #0x10
    // 0x8727c0: ret
    //     0x8727c0: ret             
    // 0x8727c4: r0 = BoxInt64Instr(r2)
    //     0x8727c4: sbfiz           x0, x2, #1, #0x1f
    //     0x8727c8: cmp             x2, x0, asr #1
    //     0x8727cc: b.eq            #0x8727d8
    //     0x8727d0: bl              #0xd69bb8
    //     0x8727d4: stur            x2, [x0, #7]
    // 0x8727d8: SaveReg r0
    //     0x8727d8: str             x0, [SP, #-8]!
    // 0x8727dc: r0 = _interpolateSingle()
    //     0x8727dc: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x8727e0: add             SP, SP, #8
    // 0x8727e4: mov             x3, x0
    // 0x8727e8: ldr             x0, [fp, #0x10]
    // 0x8727ec: stur            x3, [fp, #-0x20]
    // 0x8727f0: LoadField: r1 = r0->field_b
    //     0x8727f0: ldur            w1, [x0, #0xb]
    // 0x8727f4: DecompressPointer r1
    //     0x8727f4: add             x1, x1, HEAP, lsl #32
    // 0x8727f8: cmp             w1, NULL
    // 0x8727fc: b.eq            #0x872a10
    // 0x872800: LoadField: r4 = r1->field_6f
    //     0x872800: ldur            w4, [x1, #0x6f]
    // 0x872804: DecompressPointer r4
    //     0x872804: add             x4, x4, HEAP, lsl #32
    // 0x872808: stur            x4, [fp, #-0x18]
    // 0x87280c: cmp             w4, NULL
    // 0x872810: b.eq            #0x872a14
    // 0x872814: r1 = LoadInt32Instr(r4)
    //     0x872814: sbfx            x1, x4, #1, #0x1f
    // 0x872818: cmp             x1, #0
    // 0x87281c: b.le            #0x8728dc
    // 0x872820: ldur            x5, [fp, #-0x30]
    // 0x872824: r1 = Null
    //     0x872824: mov             x1, NULL
    // 0x872828: r2 = 4
    //     0x872828: mov             x2, #4
    // 0x87282c: r0 = AllocateArray()
    //     0x87282c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x872830: r17 = "/"
    //     0x872830: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x872834: StoreField: r0->field_f = r17
    //     0x872834: stur            w17, [x0, #0xf]
    // 0x872838: ldur            x1, [fp, #-0x18]
    // 0x87283c: StoreField: r0->field_13 = r1
    //     0x87283c: stur            w1, [x0, #0x13]
    // 0x872840: SaveReg r0
    //     0x872840: str             x0, [SP, #-8]!
    // 0x872844: r0 = _interpolate()
    //     0x872844: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x872848: add             SP, SP, #8
    // 0x87284c: ldur            x16, [fp, #-0x20]
    // 0x872850: stp             x0, x16, [SP, #-0x10]!
    // 0x872854: r0 = +()
    //     0x872854: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x872858: add             SP, SP, #0x10
    // 0x87285c: mov             x3, x0
    // 0x872860: ldr             x2, [fp, #0x10]
    // 0x872864: stur            x3, [fp, #-0x18]
    // 0x872868: LoadField: r0 = r2->field_b
    //     0x872868: ldur            w0, [x2, #0xb]
    // 0x87286c: DecompressPointer r0
    //     0x87286c: add             x0, x0, HEAP, lsl #32
    // 0x872870: cmp             w0, NULL
    // 0x872874: b.eq            #0x872a18
    // 0x872878: LoadField: r4 = r0->field_6f
    //     0x872878: ldur            w4, [x0, #0x6f]
    // 0x87287c: DecompressPointer r4
    //     0x87287c: add             x4, x4, HEAP, lsl #32
    // 0x872880: cmp             w4, NULL
    // 0x872884: b.eq            #0x872a1c
    // 0x872888: r0 = LoadInt32Instr(r4)
    //     0x872888: sbfx            x0, x4, #1, #0x1f
    // 0x87288c: ldur            x1, [fp, #-0x30]
    // 0x872890: sub             x5, x0, x1
    // 0x872894: r0 = BoxInt64Instr(r5)
    //     0x872894: sbfiz           x0, x5, #1, #0x1f
    //     0x872898: cmp             x5, x0, asr #1
    //     0x87289c: b.eq            #0x8728a8
    //     0x8728a0: bl              #0xd69bb8
    //     0x8728a4: stur            x5, [x0, #7]
    // 0x8728a8: stp             xzr, x0, [SP, #-0x10]!
    // 0x8728ac: SaveReg r4
    //     0x8728ac: str             x4, [SP, #-8]!
    // 0x8728b0: r0 = clamp()
    //     0x8728b0: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0x8728b4: add             SP, SP, #0x18
    // 0x8728b8: r1 = LoadInt32Instr(r0)
    //     0x8728b8: sbfx            x1, x0, #1, #0x1f
    //     0x8728bc: tbz             w0, #0, #0x8728c4
    //     0x8728c0: ldur            x1, [x0, #7]
    // 0x8728c4: ldur            x16, [fp, #-8]
    // 0x8728c8: stp             x1, x16, [SP, #-0x10]!
    // 0x8728cc: r0 = remainingTextFieldCharacterCount()
    //     0x8728cc: bl              #0x83e02c  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::remainingTextFieldCharacterCount
    // 0x8728d0: add             SP, SP, #0x10
    // 0x8728d4: ldur            x1, [fp, #-0x18]
    // 0x8728d8: b               #0x8728e4
    // 0x8728dc: ldur            x1, [fp, #-0x20]
    // 0x8728e0: r0 = ""
    //     0x8728e0: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x8728e4: stur            x1, [fp, #-8]
    // 0x8728e8: stur            x0, [fp, #-0x18]
    // 0x8728ec: ldr             x16, [fp, #0x10]
    // 0x8728f0: SaveReg r16
    //     0x8728f0: str             x16, [SP, #-8]!
    // 0x8728f4: r0 = _hasIntrinsicError()
    //     0x8728f4: bl              #0x8710d0  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_hasIntrinsicError
    // 0x8728f8: add             SP, SP, #8
    // 0x8728fc: tbnz            w0, #4, #0x8729c0
    // 0x872900: ldur            x0, [fp, #-0x28]
    // 0x872904: LoadField: r1 = r0->field_3b
    //     0x872904: ldur            w1, [x0, #0x3b]
    // 0x872908: DecompressPointer r1
    //     0x872908: add             x1, x1, HEAP, lsl #32
    // 0x87290c: cmp             w1, NULL
    // 0x872910: b.ne            #0x872918
    // 0x872914: r1 = ""
    //     0x872914: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x872918: stur            x1, [fp, #-0x20]
    // 0x87291c: LoadField: r2 = r0->field_3f
    //     0x87291c: ldur            w2, [x0, #0x3f]
    // 0x872920: DecompressPointer r2
    //     0x872920: add             x2, x2, HEAP, lsl #32
    // 0x872924: cmp             w2, NULL
    // 0x872928: b.ne            #0x872984
    // 0x87292c: ldur            x2, [fp, #-0x10]
    // 0x872930: LoadField: r3 = r2->field_2b
    //     0x872930: ldur            w3, [x2, #0x2b]
    // 0x872934: DecompressPointer r3
    //     0x872934: add             x3, x3, HEAP, lsl #32
    // 0x872938: tbnz            w3, #4, #0x872960
    // 0x87293c: ldr             x2, [fp, #0x10]
    // 0x872940: LoadField: r3 = r2->field_f
    //     0x872940: ldur            w3, [x2, #0xf]
    // 0x872944: DecompressPointer r3
    //     0x872944: add             x3, x3, HEAP, lsl #32
    // 0x872948: cmp             w3, NULL
    // 0x87294c: b.eq            #0x872a20
    // 0x872950: SaveReg r3
    //     0x872950: str             x3, [SP, #-8]!
    // 0x872954: r0 = _m2CounterErrorStyle()
    //     0x872954: bl              #0x872a28  ; [package:flutter/src/material/text_field.dart] ::_m2CounterErrorStyle
    // 0x872958: add             SP, SP, #8
    // 0x87295c: b               #0x872988
    // 0x872960: ldr             x2, [fp, #0x10]
    // 0x872964: LoadField: r0 = r2->field_f
    //     0x872964: ldur            w0, [x2, #0xf]
    // 0x872968: DecompressPointer r0
    //     0x872968: add             x0, x0, HEAP, lsl #32
    // 0x87296c: cmp             w0, NULL
    // 0x872970: b.eq            #0x872a24
    // 0x872974: SaveReg r0
    //     0x872974: str             x0, [SP, #-8]!
    // 0x872978: r0 = _m2CounterErrorStyle()
    //     0x872978: bl              #0x872a28  ; [package:flutter/src/material/text_field.dart] ::_m2CounterErrorStyle
    // 0x87297c: add             SP, SP, #8
    // 0x872980: b               #0x872988
    // 0x872984: mov             x0, x2
    // 0x872988: ldur            x16, [fp, #-0x28]
    // 0x87298c: ldur            lr, [fp, #-0x20]
    // 0x872990: stp             lr, x16, [SP, #-0x10]!
    // 0x872994: ldur            x16, [fp, #-8]
    // 0x872998: stp             x16, x0, [SP, #-0x10]!
    // 0x87299c: ldur            x16, [fp, #-0x18]
    // 0x8729a0: SaveReg r16
    //     0x8729a0: str             x16, [SP, #-8]!
    // 0x8729a4: r4 = const [0, 0x5, 0x5, 0x1, counterStyle, 0x2, counterText, 0x3, errorText, 0x1, semanticCounterText, 0x4, null]
    //     0x8729a4: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd48] List(13) [0, 0x5, 0x5, 0x1, "counterStyle", 0x2, "counterText", 0x3, "errorText", 0x1, "semanticCounterText", 0x4, Null]
    //     0x8729a8: ldr             x4, [x4, #0xd48]
    // 0x8729ac: r0 = copyWith()
    //     0x8729ac: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x8729b0: add             SP, SP, #0x28
    // 0x8729b4: LeaveFrame
    //     0x8729b4: mov             SP, fp
    //     0x8729b8: ldp             fp, lr, [SP], #0x10
    // 0x8729bc: ret
    //     0x8729bc: ret             
    // 0x8729c0: ldur            x16, [fp, #-0x28]
    // 0x8729c4: ldur            lr, [fp, #-8]
    // 0x8729c8: stp             lr, x16, [SP, #-0x10]!
    // 0x8729cc: ldur            x16, [fp, #-0x18]
    // 0x8729d0: SaveReg r16
    //     0x8729d0: str             x16, [SP, #-8]!
    // 0x8729d4: r4 = const [0, 0x3, 0x3, 0x1, counterText, 0x1, semanticCounterText, 0x2, null]
    //     0x8729d4: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2dd50] List(9) [0, 0x3, 0x3, 0x1, "counterText", 0x1, "semanticCounterText", 0x2, Null]
    //     0x8729d8: ldr             x4, [x4, #0xd50]
    // 0x8729dc: r0 = copyWith()
    //     0x8729dc: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x8729e0: add             SP, SP, #0x18
    // 0x8729e4: LeaveFrame
    //     0x8729e4: mov             SP, fp
    //     0x8729e8: ldp             fp, lr, [SP], #0x10
    // 0x8729ec: ret
    //     0x8729ec: ret             
    // 0x8729f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8729f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8729f4: b               #0x87261c
    // 0x8729f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8729f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8729fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8729fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872a24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872a24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionHandleTapped(dynamic) {
    // ** addr: 0x872abc, size: 0x48
    // 0x872abc: EnterFrame
    //     0x872abc: stp             fp, lr, [SP, #-0x10]!
    //     0x872ac0: mov             fp, SP
    // 0x872ac4: ldr             x0, [fp, #0x10]
    // 0x872ac8: LoadField: r1 = r0->field_17
    //     0x872ac8: ldur            w1, [x0, #0x17]
    // 0x872acc: DecompressPointer r1
    //     0x872acc: add             x1, x1, HEAP, lsl #32
    // 0x872ad0: CheckStackOverflow
    //     0x872ad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872ad4: cmp             SP, x16
    //     0x872ad8: b.ls            #0x872afc
    // 0x872adc: LoadField: r0 = r1->field_f
    //     0x872adc: ldur            w0, [x1, #0xf]
    // 0x872ae0: DecompressPointer r0
    //     0x872ae0: add             x0, x0, HEAP, lsl #32
    // 0x872ae4: SaveReg r0
    //     0x872ae4: str             x0, [SP, #-8]!
    // 0x872ae8: r0 = _handleSelectionHandleTapped()
    //     0x872ae8: bl              #0x872b04  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleSelectionHandleTapped
    // 0x872aec: add             SP, SP, #8
    // 0x872af0: LeaveFrame
    //     0x872af0: mov             SP, fp
    //     0x872af4: ldp             fp, lr, [SP], #0x10
    // 0x872af8: ret
    //     0x872af8: ret             
    // 0x872afc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872afc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872b00: b               #0x872adc
  }
  _ _handleSelectionHandleTapped(/* No info */) {
    // ** addr: 0x872b04, size: 0x9c
    // 0x872b04: EnterFrame
    //     0x872b04: stp             fp, lr, [SP, #-0x10]!
    //     0x872b08: mov             fp, SP
    // 0x872b0c: CheckStackOverflow
    //     0x872b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872b10: cmp             SP, x16
    //     0x872b14: b.ls            #0x872b90
    // 0x872b18: ldr             x0, [fp, #0x10]
    // 0x872b1c: LoadField: r1 = r0->field_b
    //     0x872b1c: ldur            w1, [x0, #0xb]
    // 0x872b20: DecompressPointer r1
    //     0x872b20: add             x1, x1, HEAP, lsl #32
    // 0x872b24: cmp             w1, NULL
    // 0x872b28: b.eq            #0x872b98
    // 0x872b2c: LoadField: r2 = r1->field_f
    //     0x872b2c: ldur            w2, [x1, #0xf]
    // 0x872b30: DecompressPointer r2
    //     0x872b30: add             x2, x2, HEAP, lsl #32
    // 0x872b34: LoadField: r1 = r2->field_27
    //     0x872b34: ldur            w1, [x2, #0x27]
    // 0x872b38: DecompressPointer r1
    //     0x872b38: add             x1, x1, HEAP, lsl #32
    // 0x872b3c: LoadField: r2 = r1->field_b
    //     0x872b3c: ldur            w2, [x1, #0xb]
    // 0x872b40: DecompressPointer r2
    //     0x872b40: add             x2, x2, HEAP, lsl #32
    // 0x872b44: LoadField: r1 = r2->field_7
    //     0x872b44: ldur            x1, [x2, #7]
    // 0x872b48: LoadField: r3 = r2->field_f
    //     0x872b48: ldur            x3, [x2, #0xf]
    // 0x872b4c: cmp             x1, x3
    // 0x872b50: b.ne            #0x872b80
    // 0x872b54: LoadField: r1 = r0->field_3b
    //     0x872b54: ldur            w1, [x0, #0x3b]
    // 0x872b58: DecompressPointer r1
    //     0x872b58: add             x1, x1, HEAP, lsl #32
    // 0x872b5c: SaveReg r1
    //     0x872b5c: str             x1, [SP, #-8]!
    // 0x872b60: r0 = currentState()
    //     0x872b60: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x872b64: add             SP, SP, #8
    // 0x872b68: cmp             w0, NULL
    // 0x872b6c: b.eq            #0x872b9c
    // 0x872b70: SaveReg r0
    //     0x872b70: str             x0, [SP, #-8]!
    // 0x872b74: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x872b74: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x872b78: r0 = toggleToolbar()
    //     0x872b78: bl              #0x86f424  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::toggleToolbar
    // 0x872b7c: add             SP, SP, #8
    // 0x872b80: r0 = Null
    //     0x872b80: mov             x0, NULL
    // 0x872b84: LeaveFrame
    //     0x872b84: mov             SP, fp
    //     0x872b88: ldp             fp, lr, [SP], #0x10
    // 0x872b8c: ret
    //     0x872b8c: ret             
    // 0x872b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872b90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872b94: b               #0x872b18
    // 0x872b98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872b98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x872b9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x872b9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x872cf8, size: 0xb4
    // 0x872cf8: EnterFrame
    //     0x872cf8: stp             fp, lr, [SP, #-0x10]!
    //     0x872cfc: mov             fp, SP
    // 0x872d00: AllocStack(0x8)
    //     0x872d00: sub             SP, SP, #8
    // 0x872d04: SetupParameters()
    //     0x872d04: ldr             x0, [fp, #0x10]
    //     0x872d08: ldur            w1, [x0, #0x17]
    //     0x872d0c: add             x1, x1, HEAP, lsl #32
    //     0x872d10: stur            x1, [fp, #-8]
    // 0x872d14: CheckStackOverflow
    //     0x872d14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x872d18: cmp             SP, x16
    //     0x872d1c: b.ls            #0x872da4
    // 0x872d20: LoadField: r0 = r1->field_f
    //     0x872d20: ldur            w0, [x1, #0xf]
    // 0x872d24: DecompressPointer r0
    //     0x872d24: add             x0, x0, HEAP, lsl #32
    // 0x872d28: SaveReg r0
    //     0x872d28: str             x0, [SP, #-8]!
    // 0x872d2c: r0 = _effectiveFocusNode()
    //     0x872d2c: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x872d30: add             SP, SP, #8
    // 0x872d34: SaveReg r0
    //     0x872d34: str             x0, [SP, #-8]!
    // 0x872d38: r0 = hasFocus()
    //     0x872d38: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x872d3c: add             SP, SP, #8
    // 0x872d40: tbz             w0, #4, #0x872d94
    // 0x872d44: ldur            x0, [fp, #-8]
    // 0x872d48: LoadField: r1 = r0->field_f
    //     0x872d48: ldur            w1, [x0, #0xf]
    // 0x872d4c: DecompressPointer r1
    //     0x872d4c: add             x1, x1, HEAP, lsl #32
    // 0x872d50: SaveReg r1
    //     0x872d50: str             x1, [SP, #-8]!
    // 0x872d54: r0 = _effectiveFocusNode()
    //     0x872d54: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x872d58: add             SP, SP, #8
    // 0x872d5c: SaveReg r0
    //     0x872d5c: str             x0, [SP, #-8]!
    // 0x872d60: r0 = canRequestFocus()
    //     0x872d60: bl              #0x7ae250  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus
    // 0x872d64: add             SP, SP, #8
    // 0x872d68: tbnz            w0, #4, #0x872d94
    // 0x872d6c: ldur            x0, [fp, #-8]
    // 0x872d70: LoadField: r1 = r0->field_f
    //     0x872d70: ldur            w1, [x0, #0xf]
    // 0x872d74: DecompressPointer r1
    //     0x872d74: add             x1, x1, HEAP, lsl #32
    // 0x872d78: SaveReg r1
    //     0x872d78: str             x1, [SP, #-8]!
    // 0x872d7c: r0 = _effectiveFocusNode()
    //     0x872d7c: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x872d80: add             SP, SP, #8
    // 0x872d84: SaveReg r0
    //     0x872d84: str             x0, [SP, #-8]!
    // 0x872d88: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x872d88: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x872d8c: r0 = requestFocus()
    //     0x872d8c: bl              #0x6fed6c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0x872d90: add             SP, SP, #8
    // 0x872d94: r0 = Null
    //     0x872d94: mov             x0, NULL
    // 0x872d98: LeaveFrame
    //     0x872d98: mov             SP, fp
    //     0x872d9c: ldp             fp, lr, [SP], #0x10
    // 0x872da0: ret
    //     0x872da0: ret             
    // 0x872da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x872da4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x872da8: b               #0x872d20
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dbe24, size: 0x130
    // 0x9dbe24: EnterFrame
    //     0x9dbe24: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbe28: mov             fp, SP
    // 0x9dbe2c: AllocStack(0x8)
    //     0x9dbe2c: sub             SP, SP, #8
    // 0x9dbe30: CheckStackOverflow
    //     0x9dbe30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbe34: cmp             SP, x16
    //     0x9dbe38: b.ls            #0x9dbf44
    // 0x9dbe3c: r0 = _TextFieldSelectionGestureDetectorBuilder()
    //     0x9dbe3c: bl              #0x9dbf54  ; Allocate_TextFieldSelectionGestureDetectorBuilderStub -> _TextFieldSelectionGestureDetectorBuilder (size=0x2c)
    // 0x9dbe40: ldr             x1, [fp, #0x10]
    // 0x9dbe44: StoreField: r0->field_27 = r1
    //     0x9dbe44: stur            w1, [x0, #0x27]
    // 0x9dbe48: r2 = true
    //     0x9dbe48: add             x2, NULL, #0x20  ; true
    // 0x9dbe4c: StoreField: r0->field_b = r2
    //     0x9dbe4c: stur            w2, [x0, #0xb]
    // 0x9dbe50: d0 = 0.000000
    //     0x9dbe50: eor             v0.16b, v0.16b, v0.16b
    // 0x9dbe54: StoreField: r0->field_f = d0
    //     0x9dbe54: stur            d0, [x0, #0xf]
    // 0x9dbe58: StoreField: r0->field_17 = d0
    //     0x9dbe58: stur            d0, [x0, #0x17]
    // 0x9dbe5c: r2 = false
    //     0x9dbe5c: add             x2, NULL, #0x30  ; false
    // 0x9dbe60: StoreField: r0->field_1f = r2
    //     0x9dbe60: stur            w2, [x0, #0x1f]
    // 0x9dbe64: StoreField: r0->field_7 = r1
    //     0x9dbe64: stur            w1, [x0, #7]
    // 0x9dbe68: StoreField: r1->field_33 = r0
    //     0x9dbe68: stur            w0, [x1, #0x33]
    //     0x9dbe6c: ldurb           w16, [x1, #-1]
    //     0x9dbe70: ldurb           w17, [x0, #-1]
    //     0x9dbe74: and             x16, x17, x16, lsr #2
    //     0x9dbe78: tst             x16, HEAP, lsr #32
    //     0x9dbe7c: b.eq            #0x9dbe84
    //     0x9dbe80: bl              #0xd6826c
    // 0x9dbe84: LoadField: r0 = r1->field_b
    //     0x9dbe84: ldur            w0, [x1, #0xb]
    // 0x9dbe88: DecompressPointer r0
    //     0x9dbe88: add             x0, x0, HEAP, lsl #32
    // 0x9dbe8c: cmp             w0, NULL
    // 0x9dbe90: b.eq            #0x9dbf4c
    // 0x9dbe94: SaveReg r1
    //     0x9dbe94: str             x1, [SP, #-8]!
    // 0x9dbe98: r0 = _effectiveFocusNode()
    //     0x9dbe98: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x9dbe9c: add             SP, SP, #8
    // 0x9dbea0: mov             x1, x0
    // 0x9dbea4: ldr             x0, [fp, #0x10]
    // 0x9dbea8: LoadField: r2 = r0->field_b
    //     0x9dbea8: ldur            w2, [x0, #0xb]
    // 0x9dbeac: DecompressPointer r2
    //     0x9dbeac: add             x2, x2, HEAP, lsl #32
    // 0x9dbeb0: cmp             w2, NULL
    // 0x9dbeb4: b.eq            #0x9dbf50
    // 0x9dbeb8: LoadField: r3 = r2->field_8b
    //     0x9dbeb8: ldur            w3, [x2, #0x8b]
    // 0x9dbebc: DecompressPointer r3
    //     0x9dbebc: add             x3, x3, HEAP, lsl #32
    // 0x9dbec0: cmp             w3, NULL
    // 0x9dbec4: b.ne            #0x9dbedc
    // 0x9dbec8: LoadField: r3 = r2->field_17
    //     0x9dbec8: ldur            w3, [x2, #0x17]
    // 0x9dbecc: DecompressPointer r3
    //     0x9dbecc: add             x3, x3, HEAP, lsl #32
    // 0x9dbed0: LoadField: r2 = r3->field_bf
    //     0x9dbed0: ldur            w2, [x3, #0xbf]
    // 0x9dbed4: DecompressPointer r2
    //     0x9dbed4: add             x2, x2, HEAP, lsl #32
    // 0x9dbed8: b               #0x9dbee0
    // 0x9dbedc: mov             x2, x3
    // 0x9dbee0: stp             x2, x1, [SP, #-0x10]!
    // 0x9dbee4: r0 = canRequestFocus=()
    //     0x9dbee4: bl              #0x7acbf0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0x9dbee8: add             SP, SP, #0x10
    // 0x9dbeec: ldr             x16, [fp, #0x10]
    // 0x9dbef0: SaveReg r16
    //     0x9dbef0: str             x16, [SP, #-8]!
    // 0x9dbef4: r0 = _effectiveFocusNode()
    //     0x9dbef4: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0x9dbef8: add             SP, SP, #8
    // 0x9dbefc: stur            x0, [fp, #-8]
    // 0x9dbf00: r1 = 1
    //     0x9dbf00: mov             x1, #1
    // 0x9dbf04: r0 = AllocateContext()
    //     0x9dbf04: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dbf08: mov             x1, x0
    // 0x9dbf0c: ldr             x0, [fp, #0x10]
    // 0x9dbf10: StoreField: r1->field_f = r0
    //     0x9dbf10: stur            w0, [x1, #0xf]
    // 0x9dbf14: mov             x2, x1
    // 0x9dbf18: r1 = Function '_handleFocusChanged@823181401':.
    //     0x9dbf18: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dfb8] AnonymousClosure: (0x9dbf60), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged (0x9dbfa8)
    //     0x9dbf1c: ldr             x1, [x1, #0xfb8]
    // 0x9dbf20: r0 = AllocateClosure()
    //     0x9dbf20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dbf24: ldur            x16, [fp, #-8]
    // 0x9dbf28: stp             x0, x16, [SP, #-0x10]!
    // 0x9dbf2c: r0 = addListener()
    //     0x9dbf2c: bl              #0x71a4c4  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::addListener
    // 0x9dbf30: add             SP, SP, #0x10
    // 0x9dbf34: r0 = Null
    //     0x9dbf34: mov             x0, NULL
    // 0x9dbf38: LeaveFrame
    //     0x9dbf38: mov             SP, fp
    //     0x9dbf3c: ldp             fp, lr, [SP], #0x10
    // 0x9dbf40: ret
    //     0x9dbf40: ret             
    // 0x9dbf44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbf44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbf48: b               #0x9dbe3c
    // 0x9dbf4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbf4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dbf50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbf50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusChanged(dynamic) {
    // ** addr: 0x9dbf60, size: 0x48
    // 0x9dbf60: EnterFrame
    //     0x9dbf60: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbf64: mov             fp, SP
    // 0x9dbf68: ldr             x0, [fp, #0x10]
    // 0x9dbf6c: LoadField: r1 = r0->field_17
    //     0x9dbf6c: ldur            w1, [x0, #0x17]
    // 0x9dbf70: DecompressPointer r1
    //     0x9dbf70: add             x1, x1, HEAP, lsl #32
    // 0x9dbf74: CheckStackOverflow
    //     0x9dbf74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbf78: cmp             SP, x16
    //     0x9dbf7c: b.ls            #0x9dbfa0
    // 0x9dbf80: LoadField: r0 = r1->field_f
    //     0x9dbf80: ldur            w0, [x1, #0xf]
    // 0x9dbf84: DecompressPointer r0
    //     0x9dbf84: add             x0, x0, HEAP, lsl #32
    // 0x9dbf88: SaveReg r0
    //     0x9dbf88: str             x0, [SP, #-8]!
    // 0x9dbf8c: r0 = _handleFocusChanged()
    //     0x9dbf8c: bl              #0x9dbfa8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged
    // 0x9dbf90: add             SP, SP, #8
    // 0x9dbf94: LeaveFrame
    //     0x9dbf94: mov             SP, fp
    //     0x9dbf98: ldp             fp, lr, [SP], #0x10
    // 0x9dbf9c: ret
    //     0x9dbf9c: ret             
    // 0x9dbfa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbfa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbfa4: b               #0x9dbf80
  }
  _ _handleFocusChanged(/* No info */) {
    // ** addr: 0x9dbfa8, size: 0x4c
    // 0x9dbfa8: EnterFrame
    //     0x9dbfa8: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbfac: mov             fp, SP
    // 0x9dbfb0: CheckStackOverflow
    //     0x9dbfb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbfb4: cmp             SP, x16
    //     0x9dbfb8: b.ls            #0x9dbfec
    // 0x9dbfbc: r1 = Function '<anonymous closure>':.
    //     0x9dbfbc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dfc0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x9dbfc0: ldr             x1, [x1, #0xfc0]
    // 0x9dbfc4: r2 = Null
    //     0x9dbfc4: mov             x2, NULL
    // 0x9dbfc8: r0 = AllocateClosure()
    //     0x9dbfc8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dbfcc: ldr             x16, [fp, #0x10]
    // 0x9dbfd0: stp             x0, x16, [SP, #-0x10]!
    // 0x9dbfd4: r0 = setState()
    //     0x9dbfd4: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9dbfd8: add             SP, SP, #0x10
    // 0x9dbfdc: r0 = Null
    //     0x9dbfdc: mov             x0, NULL
    // 0x9dbfe0: LeaveFrame
    //     0x9dbfe0: mov             SP, fp
    //     0x9dbfe4: ldp             fp, lr, [SP], #0x10
    // 0x9dbfe8: ret
    //     0x9dbfe8: ret             
    // 0x9dbfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbfec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbff0: b               #0x9dbfbc
  }
  _ _TextFieldState(/* No info */) {
    // ** addr: 0xa417c8, size: 0xb8
    // 0xa417c8: EnterFrame
    //     0xa417c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa417cc: mov             fp, SP
    // 0xa417d0: r1 = false
    //     0xa417d0: add             x1, NULL, #0x30  ; false
    // 0xa417d4: r0 = Sentinel
    //     0xa417d4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa417d8: CheckStackOverflow
    //     0xa417d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa417dc: cmp             SP, x16
    //     0xa417e0: b.ls            #0xa41878
    // 0xa417e4: ldr             x2, [fp, #0x10]
    // 0xa417e8: StoreField: r2->field_2b = r1
    //     0xa417e8: stur            w1, [x2, #0x2b]
    // 0xa417ec: StoreField: r2->field_2f = r1
    //     0xa417ec: stur            w1, [x2, #0x2f]
    // 0xa417f0: StoreField: r2->field_33 = r0
    //     0xa417f0: stur            w0, [x2, #0x33]
    // 0xa417f4: StoreField: r2->field_37 = r0
    //     0xa417f4: stur            w0, [x2, #0x37]
    // 0xa417f8: r1 = <EditableTextState<EditableText>>
    //     0xa417f8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28948] TypeArguments: <EditableTextState<EditableText>>
    //     0xa417fc: ldr             x1, [x1, #0x948]
    // 0xa41800: r0 = LabeledGlobalKey()
    //     0xa41800: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa41804: ldr             x1, [fp, #0x10]
    // 0xa41808: StoreField: r1->field_3b = r0
    //     0xa41808: stur            w0, [x1, #0x3b]
    //     0xa4180c: ldurb           w16, [x1, #-1]
    //     0xa41810: ldurb           w17, [x0, #-1]
    //     0xa41814: and             x16, x17, x16, lsr #2
    //     0xa41818: tst             x16, HEAP, lsr #32
    //     0xa4181c: b.eq            #0xa41824
    //     0xa41820: bl              #0xd6826c
    // 0xa41824: r0 = true
    //     0xa41824: add             x0, NULL, #0x20  ; true
    // 0xa41828: StoreField: r1->field_1b = r0
    //     0xa41828: stur            w0, [x1, #0x1b]
    // 0xa4182c: r16 = <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xa4182c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cfb8] TypeArguments: <RestorableProperty<Object?>, (dynamic this) => void?>
    //     0xa41830: ldr             x16, [x16, #0xfb8]
    // 0xa41834: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa41838: stp             lr, x16, [SP, #-0x10]!
    // 0xa4183c: r0 = Map._fromLiteral()
    //     0xa4183c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa41840: add             SP, SP, #0x10
    // 0xa41844: ldr             x1, [fp, #0x10]
    // 0xa41848: StoreField: r1->field_17 = r0
    //     0xa41848: stur            w0, [x1, #0x17]
    //     0xa4184c: tbz             w0, #0, #0xa41868
    //     0xa41850: ldurb           w16, [x1, #-1]
    //     0xa41854: ldurb           w17, [x0, #-1]
    //     0xa41858: and             x16, x17, x16, lsr #2
    //     0xa4185c: tst             x16, HEAP, lsr #32
    //     0xa41860: b.eq            #0xa41868
    //     0xa41864: bl              #0xd6826c
    // 0xa41868: r0 = Null
    //     0xa41868: mov             x0, NULL
    // 0xa4186c: LeaveFrame
    //     0xa4186c: mov             SP, fp
    //     0xa41870: ldp             fp, lr, [SP], #0x10
    // 0xa41874: ret
    //     0xa41874: ret             
    // 0xa41878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa41878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4187c: b               #0xa417e4
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b308, size: 0x18
    // 0xa4b308: r4 = 7
    //     0xa4b308: mov             x4, #7
    // 0xa4b30c: r1 = Function 'dispose':.
    //     0xa4b30c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b568] AnonymousClosure: (0xa4b320), in [package:flutter/src/material/text_field.dart] _TextFieldState::dispose (0xa52f00)
    //     0xa4b310: ldr             x1, [x17, #0x568]
    // 0xa4b314: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b314: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b318: LoadField: r0 = r24->field_17
    //     0xa4b318: ldur            x0, [x24, #0x17]
    // 0xa4b31c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b320, size: 0x48
    // 0xa4b320: EnterFrame
    //     0xa4b320: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b324: mov             fp, SP
    // 0xa4b328: ldr             x0, [fp, #0x10]
    // 0xa4b32c: LoadField: r1 = r0->field_17
    //     0xa4b32c: ldur            w1, [x0, #0x17]
    // 0xa4b330: DecompressPointer r1
    //     0xa4b330: add             x1, x1, HEAP, lsl #32
    // 0xa4b334: CheckStackOverflow
    //     0xa4b334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b338: cmp             SP, x16
    //     0xa4b33c: b.ls            #0xa4b360
    // 0xa4b340: LoadField: r0 = r1->field_f
    //     0xa4b340: ldur            w0, [x1, #0xf]
    // 0xa4b344: DecompressPointer r0
    //     0xa4b344: add             x0, x0, HEAP, lsl #32
    // 0xa4b348: SaveReg r0
    //     0xa4b348: str             x0, [SP, #-8]!
    // 0xa4b34c: r0 = dispose()
    //     0xa4b34c: bl              #0xa52f00  ; [package:flutter/src/material/text_field.dart] _TextFieldState::dispose
    // 0xa4b350: add             SP, SP, #8
    // 0xa4b354: LeaveFrame
    //     0xa4b354: mov             SP, fp
    //     0xa4b358: ldp             fp, lr, [SP], #0x10
    // 0xa4b35c: ret
    //     0xa4b35c: ret             
    // 0xa4b360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b360: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b364: b               #0xa4b340
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52f00, size: 0xc8
    // 0xa52f00: EnterFrame
    //     0xa52f00: stp             fp, lr, [SP, #-0x10]!
    //     0xa52f04: mov             fp, SP
    // 0xa52f08: AllocStack(0x8)
    //     0xa52f08: sub             SP, SP, #8
    // 0xa52f0c: CheckStackOverflow
    //     0xa52f0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52f10: cmp             SP, x16
    //     0xa52f14: b.ls            #0xa52fc0
    // 0xa52f18: ldr             x16, [fp, #0x10]
    // 0xa52f1c: SaveReg r16
    //     0xa52f1c: str             x16, [SP, #-8]!
    // 0xa52f20: r0 = _effectiveFocusNode()
    //     0xa52f20: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0xa52f24: add             SP, SP, #8
    // 0xa52f28: stur            x0, [fp, #-8]
    // 0xa52f2c: r1 = 1
    //     0xa52f2c: mov             x1, #1
    // 0xa52f30: r0 = AllocateContext()
    //     0xa52f30: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52f34: mov             x1, x0
    // 0xa52f38: ldr             x0, [fp, #0x10]
    // 0xa52f3c: StoreField: r1->field_f = r0
    //     0xa52f3c: stur            w0, [x1, #0xf]
    // 0xa52f40: mov             x2, x1
    // 0xa52f44: r1 = Function '_handleFocusChanged@823181401':.
    //     0xa52f44: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dfb8] AnonymousClosure: (0x9dbf60), in [package:flutter/src/material/text_field.dart] _TextFieldState::_handleFocusChanged (0x9dbfa8)
    //     0xa52f48: ldr             x1, [x1, #0xfb8]
    // 0xa52f4c: r0 = AllocateClosure()
    //     0xa52f4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52f50: ldur            x16, [fp, #-8]
    // 0xa52f54: stp             x0, x16, [SP, #-0x10]!
    // 0xa52f58: r0 = removeListener()
    //     0xa52f58: bl              #0x786230  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::removeListener
    // 0xa52f5c: add             SP, SP, #0x10
    // 0xa52f60: ldr             x0, [fp, #0x10]
    // 0xa52f64: LoadField: r1 = r0->field_27
    //     0xa52f64: ldur            w1, [x0, #0x27]
    // 0xa52f68: DecompressPointer r1
    //     0xa52f68: add             x1, x1, HEAP, lsl #32
    // 0xa52f6c: cmp             w1, NULL
    // 0xa52f70: b.eq            #0xa52f84
    // 0xa52f74: SaveReg r1
    //     0xa52f74: str             x1, [SP, #-8]!
    // 0xa52f78: r0 = dispose()
    //     0xa52f78: bl              #0xa6b1e4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0xa52f7c: add             SP, SP, #8
    // 0xa52f80: ldr             x0, [fp, #0x10]
    // 0xa52f84: LoadField: r1 = r0->field_23
    //     0xa52f84: ldur            w1, [x0, #0x23]
    // 0xa52f88: DecompressPointer r1
    //     0xa52f88: add             x1, x1, HEAP, lsl #32
    // 0xa52f8c: cmp             w1, NULL
    // 0xa52f90: b.eq            #0xa52fa0
    // 0xa52f94: SaveReg r1
    //     0xa52f94: str             x1, [SP, #-8]!
    // 0xa52f98: r0 = dispose()
    //     0xa52f98: bl              #0x9c29bc  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::dispose
    // 0xa52f9c: add             SP, SP, #8
    // 0xa52fa0: ldr             x16, [fp, #0x10]
    // 0xa52fa4: SaveReg r16
    //     0xa52fa4: str             x16, [SP, #-8]!
    // 0xa52fa8: r0 = dispose()
    //     0xa52fa8: bl              #0xa52fc8  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::dispose
    // 0xa52fac: add             SP, SP, #8
    // 0xa52fb0: r0 = Null
    //     0xa52fb0: mov             x0, NULL
    // 0xa52fb4: LeaveFrame
    //     0xa52fb4: mov             SP, fp
    //     0xa52fb8: ldp             fp, lr, [SP], #0x10
    // 0xa52fbc: ret
    //     0xa52fbc: ret             
    // 0xa52fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52fc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52fc4: b               #0xa52f18
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa61ee8, size: 0x74
    // 0xa61ee8: EnterFrame
    //     0xa61ee8: stp             fp, lr, [SP, #-0x10]!
    //     0xa61eec: mov             fp, SP
    // 0xa61ef0: AllocStack(0x8)
    //     0xa61ef0: sub             SP, SP, #8
    // 0xa61ef4: CheckStackOverflow
    //     0xa61ef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61ef8: cmp             SP, x16
    //     0xa61efc: b.ls            #0xa61f54
    // 0xa61f00: ldr             x16, [fp, #0x10]
    // 0xa61f04: SaveReg r16
    //     0xa61f04: str             x16, [SP, #-8]!
    // 0xa61f08: r0 = didChangeDependencies()
    //     0xa61f08: bl              #0xa61f5c  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::didChangeDependencies
    // 0xa61f0c: add             SP, SP, #8
    // 0xa61f10: ldr             x16, [fp, #0x10]
    // 0xa61f14: SaveReg r16
    //     0xa61f14: str             x16, [SP, #-8]!
    // 0xa61f18: r0 = _effectiveFocusNode()
    //     0xa61f18: bl              #0x7ae50c  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::_effectiveFocusNode
    // 0xa61f1c: add             SP, SP, #8
    // 0xa61f20: stur            x0, [fp, #-8]
    // 0xa61f24: ldr             x16, [fp, #0x10]
    // 0xa61f28: SaveReg r16
    //     0xa61f28: str             x16, [SP, #-8]!
    // 0xa61f2c: r0 = _canRequestFocus()
    //     0xa61f2c: bl              #0x7bee14  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_canRequestFocus
    // 0xa61f30: add             SP, SP, #8
    // 0xa61f34: ldur            x16, [fp, #-8]
    // 0xa61f38: stp             x0, x16, [SP, #-0x10]!
    // 0xa61f3c: r0 = canRequestFocus=()
    //     0xa61f3c: bl              #0x7acbf0  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus=
    // 0xa61f40: add             SP, SP, #0x10
    // 0xa61f44: r0 = Null
    //     0xa61f44: mov             x0, NULL
    // 0xa61f48: LeaveFrame
    //     0xa61f48: mov             SP, fp
    //     0xa61f4c: ldp             fp, lr, [SP], #0x10
    // 0xa61f50: ret
    //     0xa61f50: ret             
    // 0xa61f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61f54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61f58: b               #0xa61f00
  }
  _ restoreState(/* No info */) {
    // ** addr: 0xa62080, size: 0x4c
    // 0xa62080: EnterFrame
    //     0xa62080: stp             fp, lr, [SP, #-0x10]!
    //     0xa62084: mov             fp, SP
    // 0xa62088: CheckStackOverflow
    //     0xa62088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6208c: cmp             SP, x16
    //     0xa62090: b.ls            #0xa620c4
    // 0xa62094: ldr             x0, [fp, #0x18]
    // 0xa62098: LoadField: r1 = r0->field_23
    //     0xa62098: ldur            w1, [x0, #0x23]
    // 0xa6209c: DecompressPointer r1
    //     0xa6209c: add             x1, x1, HEAP, lsl #32
    // 0xa620a0: cmp             w1, NULL
    // 0xa620a4: b.eq            #0xa620b4
    // 0xa620a8: SaveReg r0
    //     0xa620a8: str             x0, [SP, #-8]!
    // 0xa620ac: r0 = _registerController()
    //     0xa620ac: bl              #0xa620cc  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_registerController
    // 0xa620b0: add             SP, SP, #8
    // 0xa620b4: r0 = Null
    //     0xa620b4: mov             x0, NULL
    // 0xa620b8: LeaveFrame
    //     0xa620b8: mov             SP, fp
    //     0xa620bc: ldp             fp, lr, [SP], #0x10
    // 0xa620c0: ret
    //     0xa620c0: ret             
    // 0xa620c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa620c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa620c8: b               #0xa62094
  }
  _ _registerController(/* No info */) {
    // ** addr: 0xa620cc, size: 0x50
    // 0xa620cc: EnterFrame
    //     0xa620cc: stp             fp, lr, [SP, #-0x10]!
    //     0xa620d0: mov             fp, SP
    // 0xa620d4: CheckStackOverflow
    //     0xa620d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa620d8: cmp             SP, x16
    //     0xa620dc: b.ls            #0xa62110
    // 0xa620e0: ldr             x0, [fp, #0x10]
    // 0xa620e4: LoadField: r1 = r0->field_23
    //     0xa620e4: ldur            w1, [x0, #0x23]
    // 0xa620e8: DecompressPointer r1
    //     0xa620e8: add             x1, x1, HEAP, lsl #32
    // 0xa620ec: cmp             w1, NULL
    // 0xa620f0: b.eq            #0xa62118
    // 0xa620f4: stp             x1, x0, [SP, #-0x10]!
    // 0xa620f8: r0 = registerForRestoration()
    //     0xa620f8: bl              #0xa6211c  ; [package:flutter/src/material/text_field.dart] __TextFieldState&State&RestorationMixin::registerForRestoration
    // 0xa620fc: add             SP, SP, #0x10
    // 0xa62100: r0 = Null
    //     0xa62100: mov             x0, NULL
    // 0xa62104: LeaveFrame
    //     0xa62104: mov             SP, fp
    //     0xa62108: ldp             fp, lr, [SP], #0x10
    // 0xa6210c: ret
    //     0xa6210c: ret             
    // 0xa62110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62114: b               #0xa620e0
    // 0xa62118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa62118: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ textInputConfiguration(/* No info */) {
    // ** addr: 0xce3eb4, size: 0x264
    // 0xce3eb4: EnterFrame
    //     0xce3eb4: stp             fp, lr, [SP, #-0x10]!
    //     0xce3eb8: mov             fp, SP
    // 0xce3ebc: AllocStack(0x30)
    //     0xce3ebc: sub             SP, SP, #0x30
    // 0xce3ec0: CheckStackOverflow
    //     0xce3ec0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce3ec4: cmp             SP, x16
    //     0xce3ec8: b.ls            #0xce40fc
    // 0xce3ecc: ldr             x0, [fp, #0x10]
    // 0xce3ed0: LoadField: r1 = r0->field_b
    //     0xce3ed0: ldur            w1, [x0, #0xb]
    // 0xce3ed4: DecompressPointer r1
    //     0xce3ed4: add             x1, x1, HEAP, lsl #32
    // 0xce3ed8: cmp             w1, NULL
    // 0xce3edc: b.eq            #0xce4104
    // 0xce3ee0: LoadField: r3 = r1->field_d7
    //     0xce3ee0: ldur            w3, [x1, #0xd7]
    // 0xce3ee4: DecompressPointer r3
    //     0xce3ee4: add             x3, x3, HEAP, lsl #32
    // 0xce3ee8: stur            x3, [fp, #-0x18]
    // 0xce3eec: cmp             w3, NULL
    // 0xce3ef0: b.ne            #0xce3efc
    // 0xce3ef4: r0 = Null
    //     0xce3ef4: mov             x0, NULL
    // 0xce3ef8: b               #0xce4014
    // 0xce3efc: LoadField: r2 = r3->field_b
    //     0xce3efc: ldur            w2, [x3, #0xb]
    // 0xce3f00: DecompressPointer r2
    //     0xce3f00: add             x2, x2, HEAP, lsl #32
    // 0xce3f04: r4 = LoadInt32Instr(r2)
    //     0xce3f04: sbfx            x4, x2, #1, #0x1f
    // 0xce3f08: stur            x4, [fp, #-0x10]
    // 0xce3f0c: cmp             x4, #0
    // 0xce3f10: b.le            #0xce4000
    // 0xce3f14: cmp             x4, #0x40
    // 0xce3f18: b.gt            #0xce3fe4
    // 0xce3f1c: LoadField: r5 = r3->field_7
    //     0xce3f1c: ldur            w5, [x3, #7]
    // 0xce3f20: DecompressPointer r5
    //     0xce3f20: add             x5, x5, HEAP, lsl #32
    // 0xce3f24: mov             x1, x5
    // 0xce3f28: stur            x5, [fp, #-8]
    // 0xce3f2c: r0 = AllocateArray()
    //     0xce3f2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xce3f30: mov             x3, x0
    // 0xce3f34: stur            x3, [fp, #-0x30]
    // 0xce3f38: r6 = 0
    //     0xce3f38: mov             x6, #0
    // 0xce3f3c: ldur            x4, [fp, #-0x18]
    // 0xce3f40: ldur            x5, [fp, #-0x10]
    // 0xce3f44: stur            x6, [fp, #-0x28]
    // 0xce3f48: CheckStackOverflow
    //     0xce3f48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce3f4c: cmp             SP, x16
    //     0xce3f50: b.ls            #0xce4108
    // 0xce3f54: cmp             x6, x5
    // 0xce3f58: b.ge            #0xce3fdc
    // 0xce3f5c: ArrayLoad: r7 = r4[r6]  ; Unknown_4
    //     0xce3f5c: add             x16, x4, x6, lsl #2
    //     0xce3f60: ldur            w7, [x16, #0xf]
    // 0xce3f64: DecompressPointer r7
    //     0xce3f64: add             x7, x7, HEAP, lsl #32
    // 0xce3f68: mov             x0, x7
    // 0xce3f6c: ldur            x2, [fp, #-8]
    // 0xce3f70: stur            x7, [fp, #-0x20]
    // 0xce3f74: r1 = Null
    //     0xce3f74: mov             x1, NULL
    // 0xce3f78: cmp             w2, NULL
    // 0xce3f7c: b.eq            #0xce3f9c
    // 0xce3f80: LoadField: r4 = r2->field_17
    //     0xce3f80: ldur            w4, [x2, #0x17]
    // 0xce3f84: DecompressPointer r4
    //     0xce3f84: add             x4, x4, HEAP, lsl #32
    // 0xce3f88: r8 = X0
    //     0xce3f88: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xce3f8c: LoadField: r9 = r4->field_7
    //     0xce3f8c: ldur            x9, [x4, #7]
    // 0xce3f90: r3 = Null
    //     0xce3f90: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2df88] Null
    //     0xce3f94: ldr             x3, [x3, #0xf88]
    // 0xce3f98: blr             x9
    // 0xce3f9c: ldur            x1, [fp, #-0x30]
    // 0xce3fa0: ldur            x0, [fp, #-0x20]
    // 0xce3fa4: ldur            x2, [fp, #-0x28]
    // 0xce3fa8: ArrayStore: r1[r2] = r0  ; List_4
    //     0xce3fa8: add             x25, x1, x2, lsl #2
    //     0xce3fac: add             x25, x25, #0xf
    //     0xce3fb0: str             w0, [x25]
    //     0xce3fb4: tbz             w0, #0, #0xce3fd0
    //     0xce3fb8: ldurb           w16, [x1, #-1]
    //     0xce3fbc: ldurb           w17, [x0, #-1]
    //     0xce3fc0: and             x16, x17, x16, lsr #2
    //     0xce3fc4: tst             x16, HEAP, lsr #32
    //     0xce3fc8: b.eq            #0xce3fd0
    //     0xce3fcc: bl              #0xd67e5c
    // 0xce3fd0: add             x6, x2, #1
    // 0xce3fd4: ldur            x3, [fp, #-0x30]
    // 0xce3fd8: b               #0xce3f3c
    // 0xce3fdc: ldur            x0, [fp, #-0x30]
    // 0xce3fe0: b               #0xce4014
    // 0xce3fe4: ldur            x16, [fp, #-0x18]
    // 0xce3fe8: stp             xzr, x16, [SP, #-0x10]!
    // 0xce3fec: r16 = true
    //     0xce3fec: add             x16, NULL, #0x20  ; true
    // 0xce3ff0: stp             x16, x2, [SP, #-0x10]!
    // 0xce3ff4: r0 = _sliceInternal()
    //     0xce3ff4: bl              #0x60bb10  ; [dart:core] _Array::_sliceInternal
    // 0xce3ff8: add             SP, SP, #0x20
    // 0xce3ffc: b               #0xce4014
    // 0xce4000: mov             x0, x3
    // 0xce4004: LoadField: r1 = r0->field_7
    //     0xce4004: ldur            w1, [x0, #7]
    // 0xce4008: DecompressPointer r1
    //     0xce4008: add             x1, x1, HEAP, lsl #32
    // 0xce400c: r2 = 0
    //     0xce400c: mov             x2, #0
    // 0xce4010: r0 = AllocateArray()
    //     0xce4010: bl              #0xd6987c  ; AllocateArrayStub
    // 0xce4014: stur            x0, [fp, #-8]
    // 0xce4018: cmp             w0, NULL
    // 0xce401c: b.eq            #0xce40a8
    // 0xce4020: ldr             x1, [fp, #0x10]
    // 0xce4024: SaveReg r1
    //     0xce4024: str             x1, [SP, #-8]!
    // 0xce4028: r0 = autofillId()
    //     0xce4028: bl              #0xce1c50  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::autofillId
    // 0xce402c: add             SP, SP, #8
    // 0xce4030: mov             x1, x0
    // 0xce4034: ldr             x0, [fp, #0x10]
    // 0xce4038: stur            x1, [fp, #-0x30]
    // 0xce403c: LoadField: r2 = r0->field_b
    //     0xce403c: ldur            w2, [x0, #0xb]
    // 0xce4040: DecompressPointer r2
    //     0xce4040: add             x2, x2, HEAP, lsl #32
    // 0xce4044: cmp             w2, NULL
    // 0xce4048: b.eq            #0xce4110
    // 0xce404c: LoadField: r3 = r2->field_f
    //     0xce404c: ldur            w3, [x2, #0xf]
    // 0xce4050: DecompressPointer r3
    //     0xce4050: add             x3, x3, HEAP, lsl #32
    // 0xce4054: LoadField: r4 = r3->field_27
    //     0xce4054: ldur            w4, [x3, #0x27]
    // 0xce4058: DecompressPointer r4
    //     0xce4058: add             x4, x4, HEAP, lsl #32
    // 0xce405c: stur            x4, [fp, #-0x20]
    // 0xce4060: LoadField: r3 = r2->field_17
    //     0xce4060: ldur            w3, [x2, #0x17]
    // 0xce4064: DecompressPointer r3
    //     0xce4064: add             x3, x3, HEAP, lsl #32
    // 0xce4068: LoadField: r2 = r3->field_2b
    //     0xce4068: ldur            w2, [x3, #0x2b]
    // 0xce406c: DecompressPointer r2
    //     0xce406c: add             x2, x2, HEAP, lsl #32
    // 0xce4070: stur            x2, [fp, #-0x18]
    // 0xce4074: r0 = AutofillConfiguration()
    //     0xce4074: bl              #0xce19bc  ; AllocateAutofillConfigurationStub -> AutofillConfiguration (size=0x1c)
    // 0xce4078: mov             x1, x0
    // 0xce407c: r0 = true
    //     0xce407c: add             x0, NULL, #0x20  ; true
    // 0xce4080: StoreField: r1->field_7 = r0
    //     0xce4080: stur            w0, [x1, #7]
    // 0xce4084: ldur            x0, [fp, #-0x30]
    // 0xce4088: StoreField: r1->field_b = r0
    //     0xce4088: stur            w0, [x1, #0xb]
    // 0xce408c: ldur            x0, [fp, #-8]
    // 0xce4090: StoreField: r1->field_f = r0
    //     0xce4090: stur            w0, [x1, #0xf]
    // 0xce4094: ldur            x0, [fp, #-0x18]
    // 0xce4098: StoreField: r1->field_17 = r0
    //     0xce4098: stur            w0, [x1, #0x17]
    // 0xce409c: ldur            x0, [fp, #-0x20]
    // 0xce40a0: StoreField: r1->field_13 = r0
    //     0xce40a0: stur            w0, [x1, #0x13]
    // 0xce40a4: b               #0xce40b0
    // 0xce40a8: r1 = Instance_AutofillConfiguration
    //     0xce40a8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2df98] Obj!AutofillConfiguration@b351c1
    //     0xce40ac: ldr             x1, [x1, #0xf98]
    // 0xce40b0: ldr             x0, [fp, #0x10]
    // 0xce40b4: stur            x1, [fp, #-8]
    // 0xce40b8: LoadField: r2 = r0->field_3b
    //     0xce40b8: ldur            w2, [x0, #0x3b]
    // 0xce40bc: DecompressPointer r2
    //     0xce40bc: add             x2, x2, HEAP, lsl #32
    // 0xce40c0: SaveReg r2
    //     0xce40c0: str             x2, [SP, #-8]!
    // 0xce40c4: r0 = currentState()
    //     0xce40c4: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0xce40c8: add             SP, SP, #8
    // 0xce40cc: cmp             w0, NULL
    // 0xce40d0: b.eq            #0xce4114
    // 0xce40d4: SaveReg r0
    //     0xce40d4: str             x0, [SP, #-8]!
    // 0xce40d8: r0 = textInputConfiguration()
    //     0xce40d8: bl              #0xce4118  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::textInputConfiguration
    // 0xce40dc: add             SP, SP, #8
    // 0xce40e0: ldur            x16, [fp, #-8]
    // 0xce40e4: stp             x16, x0, [SP, #-0x10]!
    // 0xce40e8: r0 = copyWith()
    //     0xce40e8: bl              #0xce1b64  ; [package:flutter/src/services/text_input.dart] TextInputConfiguration::copyWith
    // 0xce40ec: add             SP, SP, #0x10
    // 0xce40f0: LeaveFrame
    //     0xce40f0: mov             SP, fp
    //     0xce40f4: ldp             fp, lr, [SP], #0x10
    // 0xce40f8: ret
    //     0xce40f8: ret             
    // 0xce40fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce40fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4100: b               #0xce3ecc
    // 0xce4104: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce4104: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xce4108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce410c: b               #0xce3f54
    // 0xce4110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce4110: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xce4114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce4114: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ forcePressEnabled(/* No info */) {
    // ** addr: 0xce4470, size: 0x38
    // 0xce4470: EnterFrame
    //     0xce4470: stp             fp, lr, [SP, #-0x10]!
    //     0xce4474: mov             fp, SP
    // 0xce4478: ldr             x1, [fp, #0x10]
    // 0xce447c: LoadField: r0 = r1->field_37
    //     0xce447c: ldur            w0, [x1, #0x37]
    // 0xce4480: DecompressPointer r0
    //     0xce4480: add             x0, x0, HEAP, lsl #32
    // 0xce4484: r16 = Sentinel
    //     0xce4484: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce4488: cmp             w0, w16
    // 0xce448c: b.eq            #0xce449c
    // 0xce4490: LeaveFrame
    //     0xce4490: mov             SP, fp
    //     0xce4494: ldp             fp, lr, [SP], #0x10
    // 0xce4498: ret
    //     0xce4498: ret             
    // 0xce449c: r9 = forcePressEnabled
    //     0xce449c: add             x9, PP, #0x37, lsl #12  ; [pp+0x376c8] Field <_TextFieldState@823181401.forcePressEnabled>: late (offset: 0x38)
    //     0xce44a0: ldr             x9, [x9, #0x6c8]
    // 0xce44a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce44a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ selectionEnabled(/* No info */) {
    // ** addr: 0xce44a8, size: 0x34
    // 0xce44a8: EnterFrame
    //     0xce44a8: stp             fp, lr, [SP, #-0x10]!
    //     0xce44ac: mov             fp, SP
    // 0xce44b0: ldr             x1, [fp, #0x10]
    // 0xce44b4: LoadField: r2 = r1->field_b
    //     0xce44b4: ldur            w2, [x1, #0xb]
    // 0xce44b8: DecompressPointer r2
    //     0xce44b8: add             x2, x2, HEAP, lsl #32
    // 0xce44bc: cmp             w2, NULL
    // 0xce44c0: b.eq            #0xce44d8
    // 0xce44c4: LoadField: r0 = r2->field_b3
    //     0xce44c4: ldur            w0, [x2, #0xb3]
    // 0xce44c8: DecompressPointer r0
    //     0xce44c8: add             x0, x0, HEAP, lsl #32
    // 0xce44cc: LeaveFrame
    //     0xce44cc: mov             SP, fp
    //     0xce44d0: ldp             fp, lr, [SP], #0x10
    // 0xce44d4: ret
    //     0xce44d4: ret             
    // 0xce44d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce44d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4115, size: 0xf4, field offset: 0xc
//   const constructor, 
class TextField extends StatefulWidget {

  static _ _defaultContextMenuBuilder(/* No info */) {
    // ** addr: 0x8b09b0, size: 0x88
    // 0x8b09b0: EnterFrame
    //     0x8b09b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8b09b4: mov             fp, SP
    // 0x8b09b8: AllocStack(0x10)
    //     0x8b09b8: sub             SP, SP, #0x10
    // 0x8b09bc: CheckStackOverflow
    //     0x8b09bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8b09c0: cmp             SP, x16
    //     0x8b09c4: b.ls            #0x8b0a30
    // 0x8b09c8: ldr             x16, [fp, #0x10]
    // 0x8b09cc: SaveReg r16
    //     0x8b09cc: str             x16, [SP, #-8]!
    // 0x8b09d0: r0 = contextMenuButtonItems()
    //     0x8b09d0: bl              #0x8b1430  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::contextMenuButtonItems
    // 0x8b09d4: add             SP, SP, #8
    // 0x8b09d8: stur            x0, [fp, #-8]
    // 0x8b09dc: r0 = AdaptiveTextSelectionToolbar()
    //     0x8b09dc: bl              #0x8b1424  ; AllocateAdaptiveTextSelectionToolbarStub -> AdaptiveTextSelectionToolbar (size=0x18)
    // 0x8b09e0: mov             x1, x0
    // 0x8b09e4: ldur            x0, [fp, #-8]
    // 0x8b09e8: stur            x1, [fp, #-0x10]
    // 0x8b09ec: StoreField: r1->field_b = r0
    //     0x8b09ec: stur            w0, [x1, #0xb]
    // 0x8b09f0: ldr             x16, [fp, #0x10]
    // 0x8b09f4: SaveReg r16
    //     0x8b09f4: str             x16, [SP, #-8]!
    // 0x8b09f8: r0 = contextMenuAnchors()
    //     0x8b09f8: bl              #0x8b0a74  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::contextMenuAnchors
    // 0x8b09fc: add             SP, SP, #8
    // 0x8b0a00: ldur            x1, [fp, #-0x10]
    // 0x8b0a04: StoreField: r1->field_13 = r0
    //     0x8b0a04: stur            w0, [x1, #0x13]
    //     0x8b0a08: ldurb           w16, [x1, #-1]
    //     0x8b0a0c: ldurb           w17, [x0, #-1]
    //     0x8b0a10: and             x16, x17, x16, lsr #2
    //     0x8b0a14: tst             x16, HEAP, lsr #32
    //     0x8b0a18: b.eq            #0x8b0a20
    //     0x8b0a1c: bl              #0xd6826c
    // 0x8b0a20: mov             x0, x1
    // 0x8b0a24: LeaveFrame
    //     0x8b0a24: mov             SP, fp
    //     0x8b0a28: ldp             fp, lr, [SP], #0x10
    // 0x8b0a2c: ret
    //     0x8b0a2c: ret             
    // 0x8b0a30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b0a30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b0a34: b               #0x8b09c8
  }
  [closure] static Widget _defaultContextMenuBuilder(dynamic, BuildContext, EditableTextState) {
    // ** addr: 0x8b0a38, size: 0x3c
    // 0x8b0a38: EnterFrame
    //     0x8b0a38: stp             fp, lr, [SP, #-0x10]!
    //     0x8b0a3c: mov             fp, SP
    // 0x8b0a40: CheckStackOverflow
    //     0x8b0a40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8b0a44: cmp             SP, x16
    //     0x8b0a48: b.ls            #0x8b0a6c
    // 0x8b0a4c: ldr             x16, [fp, #0x18]
    // 0x8b0a50: ldr             lr, [fp, #0x10]
    // 0x8b0a54: stp             lr, x16, [SP, #-0x10]!
    // 0x8b0a58: r0 = _defaultContextMenuBuilder()
    //     0x8b0a58: bl              #0x8b09b0  ; [package:flutter/src/material/text_field.dart] TextField::_defaultContextMenuBuilder
    // 0x8b0a5c: add             SP, SP, #0x10
    // 0x8b0a60: LeaveFrame
    //     0x8b0a60: mov             SP, fp
    //     0x8b0a64: ldp             fp, lr, [SP], #0x10
    // 0x8b0a68: ret
    //     0x8b0a68: ret             
    // 0x8b0a6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b0a6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b0a70: b               #0x8b0a4c
  }
  _ createState(/* No info */) {
    // ** addr: 0xa4177c, size: 0x4c
    // 0xa4177c: EnterFrame
    //     0xa4177c: stp             fp, lr, [SP, #-0x10]!
    //     0xa41780: mov             fp, SP
    // 0xa41784: AllocStack(0x8)
    //     0xa41784: sub             SP, SP, #8
    // 0xa41788: CheckStackOverflow
    //     0xa41788: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4178c: cmp             SP, x16
    //     0xa41790: b.ls            #0xa417c0
    // 0xa41794: r1 = <TextField>
    //     0xa41794: add             x1, PP, #0x28, lsl #12  ; [pp+0x28940] TypeArguments: <TextField>
    //     0xa41798: ldr             x1, [x1, #0x940]
    // 0xa4179c: r0 = _TextFieldState()
    //     0xa4179c: bl              #0xa41880  ; Allocate_TextFieldStateStub -> _TextFieldState (size=0x40)
    // 0xa417a0: stur            x0, [fp, #-8]
    // 0xa417a4: SaveReg r0
    //     0xa417a4: str             x0, [SP, #-8]!
    // 0xa417a8: r0 = _TextFieldState()
    //     0xa417a8: bl              #0xa417c8  ; [package:flutter/src/material/text_field.dart] _TextFieldState::_TextFieldState
    // 0xa417ac: add             SP, SP, #8
    // 0xa417b0: ldur            x0, [fp, #-8]
    // 0xa417b4: LeaveFrame
    //     0xa417b4: mov             SP, fp
    //     0xa417b8: ldp             fp, lr, [SP], #0x10
    // 0xa417bc: ret
    //     0xa417bc: ret             
    // 0xa417c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa417c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa417c4: b               #0xa41794
  }
}

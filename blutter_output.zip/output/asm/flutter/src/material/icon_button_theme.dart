// lib: , url: package:flutter/src/material/icon_button_theme.dart

// class id: 1049252, size: 0x8
class :: {
}

// class id: 2797, size: 0xc, field offset: 0x8
//   const constructor, 
class IconButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf452c, size: 0x68
    // 0xbf452c: EnterFrame
    //     0xbf452c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4530: mov             fp, SP
    // 0xbf4534: AllocStack(0x8)
    //     0xbf4534: sub             SP, SP, #8
    // 0xbf4538: CheckStackOverflow
    //     0xbf4538: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf453c: cmp             SP, x16
    //     0xbf4540: b.ls            #0xbf458c
    // 0xbf4544: ldr             x0, [fp, #0x20]
    // 0xbf4548: LoadField: r1 = r0->field_7
    //     0xbf4548: ldur            w1, [x0, #7]
    // 0xbf454c: DecompressPointer r1
    //     0xbf454c: add             x1, x1, HEAP, lsl #32
    // 0xbf4550: ldr             x0, [fp, #0x18]
    // 0xbf4554: LoadField: r2 = r0->field_7
    //     0xbf4554: ldur            w2, [x0, #7]
    // 0xbf4558: DecompressPointer r2
    //     0xbf4558: add             x2, x2, HEAP, lsl #32
    // 0xbf455c: stp             x2, x1, [SP, #-0x10]!
    // 0xbf4560: ldr             d0, [fp, #0x10]
    // 0xbf4564: SaveReg d0
    //     0xbf4564: str             d0, [SP, #-8]!
    // 0xbf4568: r0 = lerp()
    //     0xbf4568: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbf456c: add             SP, SP, #0x18
    // 0xbf4570: stur            x0, [fp, #-8]
    // 0xbf4574: r0 = IconButtonThemeData()
    //     0xbf4574: bl              #0xbf4594  ; AllocateIconButtonThemeDataStub -> IconButtonThemeData (size=0xc)
    // 0xbf4578: ldur            x1, [fp, #-8]
    // 0xbf457c: StoreField: r0->field_7 = r1
    //     0xbf457c: stur            w1, [x0, #7]
    // 0xbf4580: LeaveFrame
    //     0xbf4580: mov             SP, fp
    //     0xbf4584: ldp             fp, lr, [SP], #0x10
    // 0xbf4588: ret
    //     0xbf4588: ret             
    // 0xbf458c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf458c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4590: b               #0xbf4544
  }
  _ ==(/* No info */) {
    // ** addr: 0xc89f40, size: 0x124
    // 0xc89f40: EnterFrame
    //     0xc89f40: stp             fp, lr, [SP, #-0x10]!
    //     0xc89f44: mov             fp, SP
    // 0xc89f48: CheckStackOverflow
    //     0xc89f48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc89f4c: cmp             SP, x16
    //     0xc89f50: b.ls            #0xc8a05c
    // 0xc89f54: ldr             x1, [fp, #0x10]
    // 0xc89f58: cmp             w1, NULL
    // 0xc89f5c: b.ne            #0xc89f70
    // 0xc89f60: r0 = false
    //     0xc89f60: add             x0, NULL, #0x30  ; false
    // 0xc89f64: LeaveFrame
    //     0xc89f64: mov             SP, fp
    //     0xc89f68: ldp             fp, lr, [SP], #0x10
    // 0xc89f6c: ret
    //     0xc89f6c: ret             
    // 0xc89f70: ldr             x2, [fp, #0x18]
    // 0xc89f74: cmp             w2, w1
    // 0xc89f78: b.ne            #0xc89f8c
    // 0xc89f7c: r0 = true
    //     0xc89f7c: add             x0, NULL, #0x20  ; true
    // 0xc89f80: LeaveFrame
    //     0xc89f80: mov             SP, fp
    //     0xc89f84: ldp             fp, lr, [SP], #0x10
    // 0xc89f88: ret
    //     0xc89f88: ret             
    // 0xc89f8c: r0 = 59
    //     0xc89f8c: mov             x0, #0x3b
    // 0xc89f90: branchIfSmi(r1, 0xc89f9c)
    //     0xc89f90: tbz             w1, #0, #0xc89f9c
    // 0xc89f94: r0 = LoadClassIdInstr(r1)
    //     0xc89f94: ldur            x0, [x1, #-1]
    //     0xc89f98: ubfx            x0, x0, #0xc, #0x14
    // 0xc89f9c: SaveReg r1
    //     0xc89f9c: str             x1, [SP, #-8]!
    // 0xc89fa0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc89fa0: mov             x17, #0x57c5
    //     0xc89fa4: add             lr, x0, x17
    //     0xc89fa8: ldr             lr, [x21, lr, lsl #3]
    //     0xc89fac: blr             lr
    // 0xc89fb0: add             SP, SP, #8
    // 0xc89fb4: r1 = LoadClassIdInstr(r0)
    //     0xc89fb4: ldur            x1, [x0, #-1]
    //     0xc89fb8: ubfx            x1, x1, #0xc, #0x14
    // 0xc89fbc: r16 = IconButtonThemeData
    //     0xc89fbc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe320] Type: IconButtonThemeData
    //     0xc89fc0: ldr             x16, [x16, #0x320]
    // 0xc89fc4: stp             x16, x0, [SP, #-0x10]!
    // 0xc89fc8: mov             x0, x1
    // 0xc89fcc: mov             lr, x0
    // 0xc89fd0: ldr             lr, [x21, lr, lsl #3]
    // 0xc89fd4: blr             lr
    // 0xc89fd8: add             SP, SP, #0x10
    // 0xc89fdc: tbz             w0, #4, #0xc89ff0
    // 0xc89fe0: r0 = false
    //     0xc89fe0: add             x0, NULL, #0x30  ; false
    // 0xc89fe4: LeaveFrame
    //     0xc89fe4: mov             SP, fp
    //     0xc89fe8: ldp             fp, lr, [SP], #0x10
    // 0xc89fec: ret
    //     0xc89fec: ret             
    // 0xc89ff0: ldr             x0, [fp, #0x10]
    // 0xc89ff4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc89ff4: mov             x1, #0x76
    //     0xc89ff8: tbz             w0, #0, #0xc8a008
    //     0xc89ffc: ldur            x1, [x0, #-1]
    //     0xc8a000: ubfx            x1, x1, #0xc, #0x14
    //     0xc8a004: lsl             x1, x1, #1
    // 0xc8a008: r17 = 5594
    //     0xc8a008: mov             x17, #0x15da
    // 0xc8a00c: cmp             w1, w17
    // 0xc8a010: b.ne            #0xc8a04c
    // 0xc8a014: ldr             x1, [fp, #0x18]
    // 0xc8a018: LoadField: r2 = r0->field_7
    //     0xc8a018: ldur            w2, [x0, #7]
    // 0xc8a01c: DecompressPointer r2
    //     0xc8a01c: add             x2, x2, HEAP, lsl #32
    // 0xc8a020: LoadField: r0 = r1->field_7
    //     0xc8a020: ldur            w0, [x1, #7]
    // 0xc8a024: DecompressPointer r0
    //     0xc8a024: add             x0, x0, HEAP, lsl #32
    // 0xc8a028: r1 = LoadClassIdInstr(r2)
    //     0xc8a028: ldur            x1, [x2, #-1]
    //     0xc8a02c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8a030: stp             x0, x2, [SP, #-0x10]!
    // 0xc8a034: mov             x0, x1
    // 0xc8a038: mov             lr, x0
    // 0xc8a03c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8a040: blr             lr
    // 0xc8a044: add             SP, SP, #0x10
    // 0xc8a048: b               #0xc8a050
    // 0xc8a04c: r0 = false
    //     0xc8a04c: add             x0, NULL, #0x30  ; false
    // 0xc8a050: LeaveFrame
    //     0xc8a050: mov             SP, fp
    //     0xc8a054: ldp             fp, lr, [SP], #0x10
    // 0xc8a058: ret
    //     0xc8a058: ret             
    // 0xc8a05c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8a05c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8a060: b               #0xc89f54
  }
}

// class id: 3544, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class IconButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xc133e0, size: 0x60
    // 0xc133e0: EnterFrame
    //     0xc133e0: stp             fp, lr, [SP, #-0x10]!
    //     0xc133e4: mov             fp, SP
    // 0xc133e8: CheckStackOverflow
    //     0xc133e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc133ec: cmp             SP, x16
    //     0xc133f0: b.ls            #0xc13438
    // 0xc133f4: r16 = <IconButtonTheme>
    //     0xc133f4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53158] TypeArguments: <IconButtonTheme>
    //     0xc133f8: ldr             x16, [x16, #0x158]
    // 0xc133fc: ldr             lr, [fp, #0x10]
    // 0xc13400: stp             lr, x16, [SP, #-0x10]!
    // 0xc13404: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc13404: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc13408: r0 = dependOnInheritedWidgetOfExactType()
    //     0xc13408: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xc1340c: add             SP, SP, #0x10
    // 0xc13410: ldr             x16, [fp, #0x10]
    // 0xc13414: SaveReg r16
    //     0xc13414: str             x16, [SP, #-8]!
    // 0xc13418: r0 = of()
    //     0xc13418: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc1341c: add             SP, SP, #8
    // 0xc13420: LoadField: r1 = r0->field_eb
    //     0xc13420: ldur            w1, [x0, #0xeb]
    // 0xc13424: DecompressPointer r1
    //     0xc13424: add             x1, x1, HEAP, lsl #32
    // 0xc13428: mov             x0, x1
    // 0xc1342c: LeaveFrame
    //     0xc1342c: mov             SP, fp
    //     0xc13430: ldp             fp, lr, [SP], #0x10
    // 0xc13434: ret
    //     0xc13434: ret             
    // 0xc13438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc13438: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc1343c: b               #0xc133f4
  }
}

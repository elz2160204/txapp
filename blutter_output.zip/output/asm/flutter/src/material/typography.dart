// lib: , url: package:flutter/src/material/typography.dart

// class id: 1049341, size: 0x8
class :: {
}

// class id: 2713, size: 0x1c, field offset: 0x8
//   const constructor, 
class Typography extends _DiagnosticableTree&Object&Diagnosticable {

  factory _ Typography.material2014(/* No info */) {
    // ** addr: 0x6d17d4, size: 0x5c
    // 0x6d17d4: EnterFrame
    //     0x6d17d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6d17d8: mov             fp, SP
    // 0x6d17dc: CheckStackOverflow
    //     0x6d17dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d17e0: cmp             SP, x16
    //     0x6d17e4: b.ls            #0x6d1828
    // 0x6d17e8: ldr             x16, [fp, #0x10]
    // 0x6d17ec: stp             x16, NULL, [SP, #-0x10]!
    // 0x6d17f0: stp             NULL, NULL, [SP, #-0x10]!
    // 0x6d17f4: r16 = Instance_TextTheme
    //     0x6d17f4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd178] Obj!TextTheme@b3c511
    //     0x6d17f8: ldr             x16, [x16, #0x178]
    // 0x6d17fc: r30 = Instance_TextTheme
    //     0x6d17fc: add             lr, PP, #0xd, lsl #12  ; [pp+0xd180] Obj!TextTheme@b3c4c1
    //     0x6d1800: ldr             lr, [lr, #0x180]
    // 0x6d1804: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1808: r16 = Instance_TextTheme
    //     0x6d1808: add             x16, PP, #0xd, lsl #12  ; [pp+0xd188] Obj!TextTheme@b3c471
    //     0x6d180c: ldr             x16, [x16, #0x188]
    // 0x6d1810: SaveReg r16
    //     0x6d1810: str             x16, [SP, #-8]!
    // 0x6d1814: r0 = Typography._withPlatform()
    //     0x6d1814: bl              #0x6d1830  ; [package:flutter/src/material/typography.dart] Typography::Typography._withPlatform
    // 0x6d1818: add             SP, SP, #0x38
    // 0x6d181c: LeaveFrame
    //     0x6d181c: mov             SP, fp
    //     0x6d1820: ldp             fp, lr, [SP], #0x10
    // 0x6d1824: ret
    //     0x6d1824: ret             
    // 0x6d1828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d1828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d182c: b               #0x6d17e8
  }
  factory _ Typography._withPlatform(/* No info */) {
    // ** addr: 0x6d1830, size: 0x128
    // 0x6d1830: EnterFrame
    //     0x6d1830: stp             fp, lr, [SP, #-0x10]!
    //     0x6d1834: mov             fp, SP
    // 0x6d1838: AllocStack(0x10)
    //     0x6d1838: sub             SP, SP, #0x10
    // 0x6d183c: ldr             x0, [fp, #0x38]
    // 0x6d1840: r16 = Instance_TargetPlatform
    //     0x6d1840: ldr             x16, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0x6d1844: cmp             w0, w16
    // 0x6d1848: b.ne            #0x6d1860
    // 0x6d184c: r4 = Instance_TextTheme
    //     0x6d184c: add             x4, PP, #0xd, lsl #12  ; [pp+0xd190] Obj!TextTheme@b3c421
    //     0x6d1850: ldr             x4, [x4, #0x190]
    // 0x6d1854: r3 = Instance_TextTheme
    //     0x6d1854: add             x3, PP, #0xd, lsl #12  ; [pp+0xd198] Obj!TextTheme@b3c3d1
    //     0x6d1858: ldr             x3, [x3, #0x198]
    // 0x6d185c: b               #0x6d18f4
    // 0x6d1860: r16 = Instance_TargetPlatform
    //     0x6d1860: ldr             x16, [PP, #0x43a8]  ; [pp+0x43a8] Obj!TargetPlatform@b65d71
    // 0x6d1864: cmp             w0, w16
    // 0x6d1868: b.eq            #0x6d1878
    // 0x6d186c: r16 = Instance_TargetPlatform
    //     0x6d186c: ldr             x16, [PP, #0x43c0]  ; [pp+0x43c0] Obj!TargetPlatform@b65d31
    // 0x6d1870: cmp             w0, w16
    // 0x6d1874: b.ne            #0x6d188c
    // 0x6d1878: r4 = Instance_TextTheme
    //     0x6d1878: add             x4, PP, #0xd, lsl #12  ; [pp+0xd1a0] Obj!TextTheme@b3c381
    //     0x6d187c: ldr             x4, [x4, #0x1a0]
    // 0x6d1880: r3 = Instance_TextTheme
    //     0x6d1880: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1a8] Obj!TextTheme@b3c331
    //     0x6d1884: ldr             x3, [x3, #0x1a8]
    // 0x6d1888: b               #0x6d18f4
    // 0x6d188c: r16 = Instance_TargetPlatform
    //     0x6d188c: ldr             x16, [PP, #0x43d8]  ; [pp+0x43d8] Obj!TargetPlatform@b65cd1
    // 0x6d1890: cmp             w0, w16
    // 0x6d1894: b.ne            #0x6d18ac
    // 0x6d1898: r4 = Instance_TextTheme
    //     0x6d1898: add             x4, PP, #0xd, lsl #12  ; [pp+0xd1b0] Obj!TextTheme@b3c2e1
    //     0x6d189c: ldr             x4, [x4, #0x1b0]
    // 0x6d18a0: r3 = Instance_TextTheme
    //     0x6d18a0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1b8] Obj!TextTheme@b3c291
    //     0x6d18a4: ldr             x3, [x3, #0x1b8]
    // 0x6d18a8: b               #0x6d18f4
    // 0x6d18ac: r16 = Instance_TargetPlatform
    //     0x6d18ac: ldr             x16, [PP, #0x43d0]  ; [pp+0x43d0] Obj!TargetPlatform@b65cf1
    // 0x6d18b0: cmp             w0, w16
    // 0x6d18b4: b.ne            #0x6d18cc
    // 0x6d18b8: r4 = Instance_TextTheme
    //     0x6d18b8: add             x4, PP, #0xd, lsl #12  ; [pp+0xd1c0] Obj!TextTheme@b3c241
    //     0x6d18bc: ldr             x4, [x4, #0x1c0]
    // 0x6d18c0: r3 = Instance_TextTheme
    //     0x6d18c0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1c8] Obj!TextTheme@b3c1f1
    //     0x6d18c4: ldr             x3, [x3, #0x1c8]
    // 0x6d18c8: b               #0x6d18f4
    // 0x6d18cc: r16 = Instance_TargetPlatform
    //     0x6d18cc: ldr             x16, [PP, #0x43c8]  ; [pp+0x43c8] Obj!TargetPlatform@b65d11
    // 0x6d18d0: cmp             w0, w16
    // 0x6d18d4: b.ne            #0x6d18ec
    // 0x6d18d8: r4 = Instance_TextTheme
    //     0x6d18d8: add             x4, PP, #0xd, lsl #12  ; [pp+0xd1d0] Obj!TextTheme@b3c1a1
    //     0x6d18dc: ldr             x4, [x4, #0x1d0]
    // 0x6d18e0: r3 = Instance_TextTheme
    //     0x6d18e0: add             x3, PP, #0xd, lsl #12  ; [pp+0xd1d8] Obj!TextTheme@b3c151
    //     0x6d18e4: ldr             x3, [x3, #0x1d8]
    // 0x6d18e8: b               #0x6d18f4
    // 0x6d18ec: r4 = Null
    //     0x6d18ec: mov             x4, NULL
    // 0x6d18f0: r3 = Null
    //     0x6d18f0: mov             x3, NULL
    // 0x6d18f4: ldr             x2, [fp, #0x20]
    // 0x6d18f8: ldr             x1, [fp, #0x18]
    // 0x6d18fc: ldr             x0, [fp, #0x10]
    // 0x6d1900: stur            x4, [fp, #-8]
    // 0x6d1904: stur            x3, [fp, #-0x10]
    // 0x6d1908: cmp             w4, NULL
    // 0x6d190c: b.eq            #0x6d1950
    // 0x6d1910: cmp             w3, NULL
    // 0x6d1914: b.eq            #0x6d1954
    // 0x6d1918: r0 = Typography()
    //     0x6d1918: bl              #0x6d1958  ; AllocateTypographyStub -> Typography (size=0x1c)
    // 0x6d191c: ldur            x1, [fp, #-8]
    // 0x6d1920: StoreField: r0->field_7 = r1
    //     0x6d1920: stur            w1, [x0, #7]
    // 0x6d1924: ldur            x1, [fp, #-0x10]
    // 0x6d1928: StoreField: r0->field_b = r1
    //     0x6d1928: stur            w1, [x0, #0xb]
    // 0x6d192c: ldr             x1, [fp, #0x20]
    // 0x6d1930: StoreField: r0->field_f = r1
    //     0x6d1930: stur            w1, [x0, #0xf]
    // 0x6d1934: ldr             x1, [fp, #0x18]
    // 0x6d1938: StoreField: r0->field_13 = r1
    //     0x6d1938: stur            w1, [x0, #0x13]
    // 0x6d193c: ldr             x1, [fp, #0x10]
    // 0x6d1940: StoreField: r0->field_17 = r1
    //     0x6d1940: stur            w1, [x0, #0x17]
    // 0x6d1944: LeaveFrame
    //     0x6d1944: mov             SP, fp
    //     0x6d1948: ldp             fp, lr, [SP], #0x10
    // 0x6d194c: ret
    //     0x6d194c: ret             
    // 0x6d1950: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d1950: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d1954: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d1954: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  factory _ Typography.material2021(/* No info */) {
    // ** addr: 0x6d1988, size: 0x120
    // 0x6d1988: EnterFrame
    //     0x6d1988: stp             fp, lr, [SP, #-0x10]!
    //     0x6d198c: mov             fp, SP
    // 0x6d1990: AllocStack(0x18)
    //     0x6d1990: sub             SP, SP, #0x18
    // 0x6d1994: CheckStackOverflow
    //     0x6d1994: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d1998: cmp             SP, x16
    //     0x6d199c: b.ls            #0x6d1aa0
    // 0x6d19a0: ldr             x16, [fp, #0x10]
    // 0x6d19a4: stp             x16, NULL, [SP, #-0x10]!
    // 0x6d19a8: stp             NULL, NULL, [SP, #-0x10]!
    // 0x6d19ac: r16 = Instance_TextTheme
    //     0x6d19ac: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1e0] Obj!TextTheme@b3c601
    //     0x6d19b0: ldr             x16, [x16, #0x1e0]
    // 0x6d19b4: r30 = Instance_TextTheme
    //     0x6d19b4: add             lr, PP, #0xd, lsl #12  ; [pp+0xd1e8] Obj!TextTheme@b3c5b1
    //     0x6d19b8: ldr             lr, [lr, #0x1e8]
    // 0x6d19bc: stp             lr, x16, [SP, #-0x10]!
    // 0x6d19c0: r16 = Instance_TextTheme
    //     0x6d19c0: add             x16, PP, #0xd, lsl #12  ; [pp+0xd1f0] Obj!TextTheme@b3c561
    //     0x6d19c4: ldr             x16, [x16, #0x1f0]
    // 0x6d19c8: SaveReg r16
    //     0x6d19c8: str             x16, [SP, #-8]!
    // 0x6d19cc: r0 = Typography._withPlatform()
    //     0x6d19cc: bl              #0x6d1830  ; [package:flutter/src/material/typography.dart] Typography::Typography._withPlatform
    // 0x6d19d0: add             SP, SP, #0x38
    // 0x6d19d4: mov             x1, x0
    // 0x6d19d8: ldr             x0, [fp, #0x18]
    // 0x6d19dc: stur            x1, [fp, #-0x10]
    // 0x6d19e0: LoadField: r2 = r0->field_7
    //     0x6d19e0: ldur            w2, [x0, #7]
    // 0x6d19e4: DecompressPointer r2
    //     0x6d19e4: add             x2, x2, HEAP, lsl #32
    // 0x6d19e8: r16 = Instance_Brightness
    //     0x6d19e8: ldr             x16, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6d19ec: cmp             w2, w16
    // 0x6d19f0: b.ne            #0x6d1a00
    // 0x6d19f4: LoadField: r3 = r0->field_57
    //     0x6d19f4: ldur            w3, [x0, #0x57]
    // 0x6d19f8: DecompressPointer r3
    //     0x6d19f8: add             x3, x3, HEAP, lsl #32
    // 0x6d19fc: b               #0x6d1a08
    // 0x6d1a00: LoadField: r3 = r0->field_53
    //     0x6d1a00: ldur            w3, [x0, #0x53]
    // 0x6d1a04: DecompressPointer r3
    //     0x6d1a04: add             x3, x3, HEAP, lsl #32
    // 0x6d1a08: r16 = Instance_Brightness
    //     0x6d1a08: ldr             x16, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6d1a0c: cmp             w2, w16
    // 0x6d1a10: b.ne            #0x6d1a24
    // 0x6d1a14: LoadField: r2 = r0->field_53
    //     0x6d1a14: ldur            w2, [x0, #0x53]
    // 0x6d1a18: DecompressPointer r2
    //     0x6d1a18: add             x2, x2, HEAP, lsl #32
    // 0x6d1a1c: mov             x0, x2
    // 0x6d1a20: b               #0x6d1a30
    // 0x6d1a24: LoadField: r2 = r0->field_57
    //     0x6d1a24: ldur            w2, [x0, #0x57]
    // 0x6d1a28: DecompressPointer r2
    //     0x6d1a28: add             x2, x2, HEAP, lsl #32
    // 0x6d1a2c: mov             x0, x2
    // 0x6d1a30: stur            x0, [fp, #-8]
    // 0x6d1a34: LoadField: r2 = r1->field_7
    //     0x6d1a34: ldur            w2, [x1, #7]
    // 0x6d1a38: DecompressPointer r2
    //     0x6d1a38: add             x2, x2, HEAP, lsl #32
    // 0x6d1a3c: stp             x3, x2, [SP, #-0x10]!
    // 0x6d1a40: stp             x3, x3, [SP, #-0x10]!
    // 0x6d1a44: r0 = apply()
    //     0x6d1a44: bl              #0x6d1b14  ; [package:flutter/src/material/text_theme.dart] TextTheme::apply
    // 0x6d1a48: add             SP, SP, #0x20
    // 0x6d1a4c: mov             x1, x0
    // 0x6d1a50: ldur            x0, [fp, #-0x10]
    // 0x6d1a54: stur            x1, [fp, #-0x18]
    // 0x6d1a58: LoadField: r2 = r0->field_b
    //     0x6d1a58: ldur            w2, [x0, #0xb]
    // 0x6d1a5c: DecompressPointer r2
    //     0x6d1a5c: add             x2, x2, HEAP, lsl #32
    // 0x6d1a60: ldur            x16, [fp, #-8]
    // 0x6d1a64: stp             x16, x2, [SP, #-0x10]!
    // 0x6d1a68: ldur            x16, [fp, #-8]
    // 0x6d1a6c: ldur            lr, [fp, #-8]
    // 0x6d1a70: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1a74: r0 = apply()
    //     0x6d1a74: bl              #0x6d1b14  ; [package:flutter/src/material/text_theme.dart] TextTheme::apply
    // 0x6d1a78: add             SP, SP, #0x20
    // 0x6d1a7c: ldur            x16, [fp, #-0x10]
    // 0x6d1a80: ldur            lr, [fp, #-0x18]
    // 0x6d1a84: stp             lr, x16, [SP, #-0x10]!
    // 0x6d1a88: SaveReg r0
    //     0x6d1a88: str             x0, [SP, #-8]!
    // 0x6d1a8c: r0 = copyWith()
    //     0x6d1a8c: bl              #0x6d1aa8  ; [package:flutter/src/material/typography.dart] Typography::copyWith
    // 0x6d1a90: add             SP, SP, #0x18
    // 0x6d1a94: LeaveFrame
    //     0x6d1a94: mov             SP, fp
    //     0x6d1a98: ldp             fp, lr, [SP], #0x10
    // 0x6d1a9c: ret
    //     0x6d1a9c: ret             
    // 0x6d1aa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d1aa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d1aa4: b               #0x6d19a0
  }
  _ copyWith(/* No info */) {
    // ** addr: 0x6d1aa8, size: 0x6c
    // 0x6d1aa8: EnterFrame
    //     0x6d1aa8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d1aac: mov             fp, SP
    // 0x6d1ab0: AllocStack(0x18)
    //     0x6d1ab0: sub             SP, SP, #0x18
    // 0x6d1ab4: ldr             x0, [fp, #0x20]
    // 0x6d1ab8: LoadField: r1 = r0->field_f
    //     0x6d1ab8: ldur            w1, [x0, #0xf]
    // 0x6d1abc: DecompressPointer r1
    //     0x6d1abc: add             x1, x1, HEAP, lsl #32
    // 0x6d1ac0: stur            x1, [fp, #-0x18]
    // 0x6d1ac4: LoadField: r2 = r0->field_13
    //     0x6d1ac4: ldur            w2, [x0, #0x13]
    // 0x6d1ac8: DecompressPointer r2
    //     0x6d1ac8: add             x2, x2, HEAP, lsl #32
    // 0x6d1acc: stur            x2, [fp, #-0x10]
    // 0x6d1ad0: LoadField: r3 = r0->field_17
    //     0x6d1ad0: ldur            w3, [x0, #0x17]
    // 0x6d1ad4: DecompressPointer r3
    //     0x6d1ad4: add             x3, x3, HEAP, lsl #32
    // 0x6d1ad8: stur            x3, [fp, #-8]
    // 0x6d1adc: r0 = Typography()
    //     0x6d1adc: bl              #0x6d1958  ; AllocateTypographyStub -> Typography (size=0x1c)
    // 0x6d1ae0: ldr             x1, [fp, #0x18]
    // 0x6d1ae4: StoreField: r0->field_7 = r1
    //     0x6d1ae4: stur            w1, [x0, #7]
    // 0x6d1ae8: ldr             x1, [fp, #0x10]
    // 0x6d1aec: StoreField: r0->field_b = r1
    //     0x6d1aec: stur            w1, [x0, #0xb]
    // 0x6d1af0: ldur            x1, [fp, #-0x18]
    // 0x6d1af4: StoreField: r0->field_f = r1
    //     0x6d1af4: stur            w1, [x0, #0xf]
    // 0x6d1af8: ldur            x1, [fp, #-0x10]
    // 0x6d1afc: StoreField: r0->field_13 = r1
    //     0x6d1afc: stur            w1, [x0, #0x13]
    // 0x6d1b00: ldur            x1, [fp, #-8]
    // 0x6d1b04: StoreField: r0->field_17 = r1
    //     0x6d1b04: stur            w1, [x0, #0x17]
    // 0x6d1b08: LeaveFrame
    //     0x6d1b08: mov             SP, fp
    //     0x6d1b0c: ldp             fp, lr, [SP], #0x10
    // 0x6d1b10: ret
    //     0x6d1b10: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb059b8, size: 0x84
    // 0xb059b8: EnterFrame
    //     0xb059b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb059bc: mov             fp, SP
    // 0xb059c0: CheckStackOverflow
    //     0xb059c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb059c4: cmp             SP, x16
    //     0xb059c8: b.ls            #0xb05a34
    // 0xb059cc: ldr             x0, [fp, #0x10]
    // 0xb059d0: LoadField: r1 = r0->field_7
    //     0xb059d0: ldur            w1, [x0, #7]
    // 0xb059d4: DecompressPointer r1
    //     0xb059d4: add             x1, x1, HEAP, lsl #32
    // 0xb059d8: LoadField: r2 = r0->field_b
    //     0xb059d8: ldur            w2, [x0, #0xb]
    // 0xb059dc: DecompressPointer r2
    //     0xb059dc: add             x2, x2, HEAP, lsl #32
    // 0xb059e0: LoadField: r3 = r0->field_f
    //     0xb059e0: ldur            w3, [x0, #0xf]
    // 0xb059e4: DecompressPointer r3
    //     0xb059e4: add             x3, x3, HEAP, lsl #32
    // 0xb059e8: LoadField: r4 = r0->field_13
    //     0xb059e8: ldur            w4, [x0, #0x13]
    // 0xb059ec: DecompressPointer r4
    //     0xb059ec: add             x4, x4, HEAP, lsl #32
    // 0xb059f0: LoadField: r5 = r0->field_17
    //     0xb059f0: ldur            w5, [x0, #0x17]
    // 0xb059f4: DecompressPointer r5
    //     0xb059f4: add             x5, x5, HEAP, lsl #32
    // 0xb059f8: stp             x2, x1, [SP, #-0x10]!
    // 0xb059fc: stp             x4, x3, [SP, #-0x10]!
    // 0xb05a00: SaveReg r5
    //     0xb05a00: str             x5, [SP, #-8]!
    // 0xb05a04: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xb05a04: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xb05a08: r0 = hash()
    //     0xb05a08: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb05a0c: add             SP, SP, #0x28
    // 0xb05a10: mov             x2, x0
    // 0xb05a14: r0 = BoxInt64Instr(r2)
    //     0xb05a14: sbfiz           x0, x2, #1, #0x1f
    //     0xb05a18: cmp             x2, x0, asr #1
    //     0xb05a1c: b.eq            #0xb05a28
    //     0xb05a20: bl              #0xd69bb8
    //     0xb05a24: stur            x2, [x0, #7]
    // 0xb05a28: LeaveFrame
    //     0xb05a28: mov             SP, fp
    //     0xb05a2c: ldp             fp, lr, [SP], #0x10
    // 0xb05a30: ret
    //     0xb05a30: ret             
    // 0xb05a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb05a34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb05a38: b               #0xb059cc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf643c, size: 0x158
    // 0xbf643c: EnterFrame
    //     0xbf643c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf6440: mov             fp, SP
    // 0xbf6444: AllocStack(0x28)
    //     0xbf6444: sub             SP, SP, #0x28
    // 0xbf6448: CheckStackOverflow
    //     0xbf6448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf644c: cmp             SP, x16
    //     0xbf6450: b.ls            #0xbf658c
    // 0xbf6454: ldr             x0, [fp, #0x20]
    // 0xbf6458: LoadField: r1 = r0->field_7
    //     0xbf6458: ldur            w1, [x0, #7]
    // 0xbf645c: DecompressPointer r1
    //     0xbf645c: add             x1, x1, HEAP, lsl #32
    // 0xbf6460: ldr             x2, [fp, #0x18]
    // 0xbf6464: LoadField: r3 = r2->field_7
    //     0xbf6464: ldur            w3, [x2, #7]
    // 0xbf6468: DecompressPointer r3
    //     0xbf6468: add             x3, x3, HEAP, lsl #32
    // 0xbf646c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf6470: ldr             d0, [fp, #0x10]
    // 0xbf6474: SaveReg d0
    //     0xbf6474: str             d0, [SP, #-8]!
    // 0xbf6478: r0 = lerp()
    //     0xbf6478: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbf647c: add             SP, SP, #0x18
    // 0xbf6480: mov             x1, x0
    // 0xbf6484: ldr             x0, [fp, #0x20]
    // 0xbf6488: stur            x1, [fp, #-8]
    // 0xbf648c: LoadField: r2 = r0->field_b
    //     0xbf648c: ldur            w2, [x0, #0xb]
    // 0xbf6490: DecompressPointer r2
    //     0xbf6490: add             x2, x2, HEAP, lsl #32
    // 0xbf6494: ldr             x3, [fp, #0x18]
    // 0xbf6498: LoadField: r4 = r3->field_b
    //     0xbf6498: ldur            w4, [x3, #0xb]
    // 0xbf649c: DecompressPointer r4
    //     0xbf649c: add             x4, x4, HEAP, lsl #32
    // 0xbf64a0: stp             x4, x2, [SP, #-0x10]!
    // 0xbf64a4: ldr             d0, [fp, #0x10]
    // 0xbf64a8: SaveReg d0
    //     0xbf64a8: str             d0, [SP, #-8]!
    // 0xbf64ac: r0 = lerp()
    //     0xbf64ac: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbf64b0: add             SP, SP, #0x18
    // 0xbf64b4: mov             x1, x0
    // 0xbf64b8: ldr             x0, [fp, #0x20]
    // 0xbf64bc: stur            x1, [fp, #-0x10]
    // 0xbf64c0: LoadField: r2 = r0->field_f
    //     0xbf64c0: ldur            w2, [x0, #0xf]
    // 0xbf64c4: DecompressPointer r2
    //     0xbf64c4: add             x2, x2, HEAP, lsl #32
    // 0xbf64c8: ldr             x3, [fp, #0x18]
    // 0xbf64cc: LoadField: r4 = r3->field_f
    //     0xbf64cc: ldur            w4, [x3, #0xf]
    // 0xbf64d0: DecompressPointer r4
    //     0xbf64d0: add             x4, x4, HEAP, lsl #32
    // 0xbf64d4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf64d8: ldr             d0, [fp, #0x10]
    // 0xbf64dc: SaveReg d0
    //     0xbf64dc: str             d0, [SP, #-8]!
    // 0xbf64e0: r0 = lerp()
    //     0xbf64e0: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbf64e4: add             SP, SP, #0x18
    // 0xbf64e8: mov             x1, x0
    // 0xbf64ec: ldr             x0, [fp, #0x20]
    // 0xbf64f0: stur            x1, [fp, #-0x18]
    // 0xbf64f4: LoadField: r2 = r0->field_13
    //     0xbf64f4: ldur            w2, [x0, #0x13]
    // 0xbf64f8: DecompressPointer r2
    //     0xbf64f8: add             x2, x2, HEAP, lsl #32
    // 0xbf64fc: ldr             x3, [fp, #0x18]
    // 0xbf6500: LoadField: r4 = r3->field_13
    //     0xbf6500: ldur            w4, [x3, #0x13]
    // 0xbf6504: DecompressPointer r4
    //     0xbf6504: add             x4, x4, HEAP, lsl #32
    // 0xbf6508: stp             x4, x2, [SP, #-0x10]!
    // 0xbf650c: ldr             d0, [fp, #0x10]
    // 0xbf6510: SaveReg d0
    //     0xbf6510: str             d0, [SP, #-8]!
    // 0xbf6514: r0 = lerp()
    //     0xbf6514: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbf6518: add             SP, SP, #0x18
    // 0xbf651c: mov             x1, x0
    // 0xbf6520: ldr             x0, [fp, #0x20]
    // 0xbf6524: stur            x1, [fp, #-0x20]
    // 0xbf6528: LoadField: r2 = r0->field_17
    //     0xbf6528: ldur            w2, [x0, #0x17]
    // 0xbf652c: DecompressPointer r2
    //     0xbf652c: add             x2, x2, HEAP, lsl #32
    // 0xbf6530: ldr             x0, [fp, #0x18]
    // 0xbf6534: LoadField: r3 = r0->field_17
    //     0xbf6534: ldur            w3, [x0, #0x17]
    // 0xbf6538: DecompressPointer r3
    //     0xbf6538: add             x3, x3, HEAP, lsl #32
    // 0xbf653c: stp             x3, x2, [SP, #-0x10]!
    // 0xbf6540: ldr             d0, [fp, #0x10]
    // 0xbf6544: SaveReg d0
    //     0xbf6544: str             d0, [SP, #-8]!
    // 0xbf6548: r0 = lerp()
    //     0xbf6548: bl              #0xbf6594  ; [package:flutter/src/material/text_theme.dart] TextTheme::lerp
    // 0xbf654c: add             SP, SP, #0x18
    // 0xbf6550: stur            x0, [fp, #-0x28]
    // 0xbf6554: r0 = Typography()
    //     0xbf6554: bl              #0x6d1958  ; AllocateTypographyStub -> Typography (size=0x1c)
    // 0xbf6558: ldur            x1, [fp, #-8]
    // 0xbf655c: StoreField: r0->field_7 = r1
    //     0xbf655c: stur            w1, [x0, #7]
    // 0xbf6560: ldur            x1, [fp, #-0x10]
    // 0xbf6564: StoreField: r0->field_b = r1
    //     0xbf6564: stur            w1, [x0, #0xb]
    // 0xbf6568: ldur            x1, [fp, #-0x18]
    // 0xbf656c: StoreField: r0->field_f = r1
    //     0xbf656c: stur            w1, [x0, #0xf]
    // 0xbf6570: ldur            x1, [fp, #-0x20]
    // 0xbf6574: StoreField: r0->field_13 = r1
    //     0xbf6574: stur            w1, [x0, #0x13]
    // 0xbf6578: ldur            x1, [fp, #-0x28]
    // 0xbf657c: StoreField: r0->field_17 = r1
    //     0xbf657c: stur            w1, [x0, #0x17]
    // 0xbf6580: LeaveFrame
    //     0xbf6580: mov             SP, fp
    //     0xbf6584: ldp             fp, lr, [SP], #0x10
    // 0xbf6588: ret
    //     0xbf6588: ret             
    // 0xbf658c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf658c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf6590: b               #0xbf6454
  }
  _ ==(/* No info */) {
    // ** addr: 0xc92da0, size: 0x1b0
    // 0xc92da0: EnterFrame
    //     0xc92da0: stp             fp, lr, [SP, #-0x10]!
    //     0xc92da4: mov             fp, SP
    // 0xc92da8: CheckStackOverflow
    //     0xc92da8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc92dac: cmp             SP, x16
    //     0xc92db0: b.ls            #0xc92f48
    // 0xc92db4: ldr             x1, [fp, #0x10]
    // 0xc92db8: cmp             w1, NULL
    // 0xc92dbc: b.ne            #0xc92dd0
    // 0xc92dc0: r0 = false
    //     0xc92dc0: add             x0, NULL, #0x30  ; false
    // 0xc92dc4: LeaveFrame
    //     0xc92dc4: mov             SP, fp
    //     0xc92dc8: ldp             fp, lr, [SP], #0x10
    // 0xc92dcc: ret
    //     0xc92dcc: ret             
    // 0xc92dd0: ldr             x2, [fp, #0x18]
    // 0xc92dd4: cmp             w2, w1
    // 0xc92dd8: b.ne            #0xc92dec
    // 0xc92ddc: r0 = true
    //     0xc92ddc: add             x0, NULL, #0x20  ; true
    // 0xc92de0: LeaveFrame
    //     0xc92de0: mov             SP, fp
    //     0xc92de4: ldp             fp, lr, [SP], #0x10
    // 0xc92de8: ret
    //     0xc92de8: ret             
    // 0xc92dec: r0 = 59
    //     0xc92dec: mov             x0, #0x3b
    // 0xc92df0: branchIfSmi(r1, 0xc92dfc)
    //     0xc92df0: tbz             w1, #0, #0xc92dfc
    // 0xc92df4: r0 = LoadClassIdInstr(r1)
    //     0xc92df4: ldur            x0, [x1, #-1]
    //     0xc92df8: ubfx            x0, x0, #0xc, #0x14
    // 0xc92dfc: SaveReg r1
    //     0xc92dfc: str             x1, [SP, #-8]!
    // 0xc92e00: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc92e00: mov             x17, #0x57c5
    //     0xc92e04: add             lr, x0, x17
    //     0xc92e08: ldr             lr, [x21, lr, lsl #3]
    //     0xc92e0c: blr             lr
    // 0xc92e10: add             SP, SP, #8
    // 0xc92e14: r1 = LoadClassIdInstr(r0)
    //     0xc92e14: ldur            x1, [x0, #-1]
    //     0xc92e18: ubfx            x1, x1, #0xc, #0x14
    // 0xc92e1c: r16 = Typography
    //     0xc92e1c: add             x16, PP, #0xd, lsl #12  ; [pp+0xded0] Type: Typography
    //     0xc92e20: ldr             x16, [x16, #0xed0]
    // 0xc92e24: stp             x16, x0, [SP, #-0x10]!
    // 0xc92e28: mov             x0, x1
    // 0xc92e2c: mov             lr, x0
    // 0xc92e30: ldr             lr, [x21, lr, lsl #3]
    // 0xc92e34: blr             lr
    // 0xc92e38: add             SP, SP, #0x10
    // 0xc92e3c: tbz             w0, #4, #0xc92e50
    // 0xc92e40: r0 = false
    //     0xc92e40: add             x0, NULL, #0x30  ; false
    // 0xc92e44: LeaveFrame
    //     0xc92e44: mov             SP, fp
    //     0xc92e48: ldp             fp, lr, [SP], #0x10
    // 0xc92e4c: ret
    //     0xc92e4c: ret             
    // 0xc92e50: ldr             x0, [fp, #0x10]
    // 0xc92e54: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc92e54: mov             x1, #0x76
    //     0xc92e58: tbz             w0, #0, #0xc92e68
    //     0xc92e5c: ldur            x1, [x0, #-1]
    //     0xc92e60: ubfx            x1, x1, #0xc, #0x14
    //     0xc92e64: lsl             x1, x1, #1
    // 0xc92e68: r17 = 5426
    //     0xc92e68: mov             x17, #0x1532
    // 0xc92e6c: cmp             w1, w17
    // 0xc92e70: b.ne            #0xc92f38
    // 0xc92e74: ldr             x1, [fp, #0x18]
    // 0xc92e78: LoadField: r2 = r0->field_7
    //     0xc92e78: ldur            w2, [x0, #7]
    // 0xc92e7c: DecompressPointer r2
    //     0xc92e7c: add             x2, x2, HEAP, lsl #32
    // 0xc92e80: LoadField: r3 = r1->field_7
    //     0xc92e80: ldur            w3, [x1, #7]
    // 0xc92e84: DecompressPointer r3
    //     0xc92e84: add             x3, x3, HEAP, lsl #32
    // 0xc92e88: stp             x3, x2, [SP, #-0x10]!
    // 0xc92e8c: r0 = ==()
    //     0xc92e8c: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc92e90: add             SP, SP, #0x10
    // 0xc92e94: tbnz            w0, #4, #0xc92f38
    // 0xc92e98: ldr             x1, [fp, #0x18]
    // 0xc92e9c: ldr             x0, [fp, #0x10]
    // 0xc92ea0: LoadField: r2 = r0->field_b
    //     0xc92ea0: ldur            w2, [x0, #0xb]
    // 0xc92ea4: DecompressPointer r2
    //     0xc92ea4: add             x2, x2, HEAP, lsl #32
    // 0xc92ea8: LoadField: r3 = r1->field_b
    //     0xc92ea8: ldur            w3, [x1, #0xb]
    // 0xc92eac: DecompressPointer r3
    //     0xc92eac: add             x3, x3, HEAP, lsl #32
    // 0xc92eb0: stp             x3, x2, [SP, #-0x10]!
    // 0xc92eb4: r0 = ==()
    //     0xc92eb4: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc92eb8: add             SP, SP, #0x10
    // 0xc92ebc: tbnz            w0, #4, #0xc92f38
    // 0xc92ec0: ldr             x1, [fp, #0x18]
    // 0xc92ec4: ldr             x0, [fp, #0x10]
    // 0xc92ec8: LoadField: r2 = r0->field_f
    //     0xc92ec8: ldur            w2, [x0, #0xf]
    // 0xc92ecc: DecompressPointer r2
    //     0xc92ecc: add             x2, x2, HEAP, lsl #32
    // 0xc92ed0: LoadField: r3 = r1->field_f
    //     0xc92ed0: ldur            w3, [x1, #0xf]
    // 0xc92ed4: DecompressPointer r3
    //     0xc92ed4: add             x3, x3, HEAP, lsl #32
    // 0xc92ed8: stp             x3, x2, [SP, #-0x10]!
    // 0xc92edc: r0 = ==()
    //     0xc92edc: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc92ee0: add             SP, SP, #0x10
    // 0xc92ee4: tbnz            w0, #4, #0xc92f38
    // 0xc92ee8: ldr             x1, [fp, #0x18]
    // 0xc92eec: ldr             x0, [fp, #0x10]
    // 0xc92ef0: LoadField: r2 = r0->field_13
    //     0xc92ef0: ldur            w2, [x0, #0x13]
    // 0xc92ef4: DecompressPointer r2
    //     0xc92ef4: add             x2, x2, HEAP, lsl #32
    // 0xc92ef8: LoadField: r3 = r1->field_13
    //     0xc92ef8: ldur            w3, [x1, #0x13]
    // 0xc92efc: DecompressPointer r3
    //     0xc92efc: add             x3, x3, HEAP, lsl #32
    // 0xc92f00: stp             x3, x2, [SP, #-0x10]!
    // 0xc92f04: r0 = ==()
    //     0xc92f04: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc92f08: add             SP, SP, #0x10
    // 0xc92f0c: tbnz            w0, #4, #0xc92f38
    // 0xc92f10: ldr             x1, [fp, #0x18]
    // 0xc92f14: ldr             x0, [fp, #0x10]
    // 0xc92f18: LoadField: r2 = r0->field_17
    //     0xc92f18: ldur            w2, [x0, #0x17]
    // 0xc92f1c: DecompressPointer r2
    //     0xc92f1c: add             x2, x2, HEAP, lsl #32
    // 0xc92f20: LoadField: r0 = r1->field_17
    //     0xc92f20: ldur            w0, [x1, #0x17]
    // 0xc92f24: DecompressPointer r0
    //     0xc92f24: add             x0, x0, HEAP, lsl #32
    // 0xc92f28: stp             x0, x2, [SP, #-0x10]!
    // 0xc92f2c: r0 = ==()
    //     0xc92f2c: bl              #0xc900e8  ; [package:flutter/src/material/text_theme.dart] TextTheme::==
    // 0xc92f30: add             SP, SP, #0x10
    // 0xc92f34: b               #0xc92f3c
    // 0xc92f38: r0 = false
    //     0xc92f38: add             x0, NULL, #0x30  ; false
    // 0xc92f3c: LeaveFrame
    //     0xc92f3c: mov             SP, fp
    //     0xc92f40: ldp             fp, lr, [SP], #0x10
    // 0xc92f44: ret
    //     0xc92f44: ret             
    // 0xc92f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc92f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc92f4c: b               #0xc92db4
  }
}

// lib: , url: package:flutter/src/material/ink_well.dart

// class id: 1049259, size: 0x8
class :: {
}

// class id: 2189, size: 0x8, field offset: 0x8
abstract class _ParentInkResponseState extends Object {
}

// class id: 2190, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class InteractiveInkFeatureFactory extends Object {
}

// class id: 2195, size: 0x18, field offset: 0x14
abstract class InteractiveInkFeature extends InkFeature {

  set _ color=(/* No info */) {
    // ** addr: 0x85511c, size: 0x1ac
    // 0x85511c: EnterFrame
    //     0x85511c: stp             fp, lr, [SP, #-0x10]!
    //     0x855120: mov             fp, SP
    // 0x855124: AllocStack(0x10)
    //     0x855124: sub             SP, SP, #0x10
    // 0x855128: CheckStackOverflow
    //     0x855128: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85512c: cmp             SP, x16
    //     0x855130: b.ls            #0x8552c0
    // 0x855134: ldr             x0, [fp, #0x18]
    // 0x855138: LoadField: r1 = r0->field_13
    //     0x855138: ldur            w1, [x0, #0x13]
    // 0x85513c: DecompressPointer r1
    //     0x85513c: add             x1, x1, HEAP, lsl #32
    // 0x855140: ldr             x2, [fp, #0x10]
    // 0x855144: stur            x1, [fp, #-0x10]
    // 0x855148: r3 = LoadClassIdInstr(r2)
    //     0x855148: ldur            x3, [x2, #-1]
    //     0x85514c: ubfx            x3, x3, #0xc, #0x14
    // 0x855150: lsl             x3, x3, #1
    // 0x855154: stur            x3, [fp, #-8]
    // 0x855158: r17 = 10114
    //     0x855158: mov             x17, #0x2782
    // 0x85515c: cmp             w3, w17
    // 0x855160: b.eq            #0x855170
    // 0x855164: r17 = 10118
    //     0x855164: mov             x17, #0x2786
    // 0x855168: cmp             w3, w17
    // 0x85516c: b.ne            #0x855240
    // 0x855170: cmp             w2, w1
    // 0x855174: b.eq            #0x855268
    // 0x855178: stp             x2, x1, [SP, #-0x10]!
    // 0x85517c: r0 = _haveSameRuntimeType()
    //     0x85517c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x855180: add             SP, SP, #0x10
    // 0x855184: tbnz            w0, #4, #0x855278
    // 0x855188: ldur            x0, [fp, #-0x10]
    // 0x85518c: r1 = LoadClassIdInstr(r0)
    //     0x85518c: ldur            x1, [x0, #-1]
    //     0x855190: ubfx            x1, x1, #0xc, #0x14
    // 0x855194: lsl             x1, x1, #1
    // 0x855198: r17 = 10124
    //     0x855198: mov             x17, #0x278c
    // 0x85519c: cmp             w1, w17
    // 0x8551a0: b.gt            #0x8551b0
    // 0x8551a4: r17 = 10122
    //     0x8551a4: mov             x17, #0x278a
    // 0x8551a8: cmp             w1, w17
    // 0x8551ac: b.ge            #0x8551c8
    // 0x8551b0: r17 = 10114
    //     0x8551b0: mov             x17, #0x2782
    // 0x8551b4: cmp             w1, w17
    // 0x8551b8: b.eq            #0x8551c8
    // 0x8551bc: r17 = 10118
    //     0x8551bc: mov             x17, #0x2786
    // 0x8551c0: cmp             w1, w17
    // 0x8551c4: b.ne            #0x8551d0
    // 0x8551c8: LoadField: r1 = r0->field_7
    //     0x8551c8: ldur            x1, [x0, #7]
    // 0x8551cc: b               #0x8551e0
    // 0x8551d0: LoadField: r1 = r0->field_f
    //     0x8551d0: ldur            w1, [x0, #0xf]
    // 0x8551d4: DecompressPointer r1
    //     0x8551d4: add             x1, x1, HEAP, lsl #32
    // 0x8551d8: LoadField: r0 = r1->field_7
    //     0x8551d8: ldur            x0, [x1, #7]
    // 0x8551dc: mov             x1, x0
    // 0x8551e0: ldur            x0, [fp, #-8]
    // 0x8551e4: r17 = 10124
    //     0x8551e4: mov             x17, #0x278c
    // 0x8551e8: cmp             w0, w17
    // 0x8551ec: b.gt            #0x8551fc
    // 0x8551f0: r17 = 10122
    //     0x8551f0: mov             x17, #0x278a
    // 0x8551f4: cmp             w0, w17
    // 0x8551f8: b.ge            #0x855214
    // 0x8551fc: r17 = 10114
    //     0x8551fc: mov             x17, #0x2782
    // 0x855200: cmp             w0, w17
    // 0x855204: b.eq            #0x855214
    // 0x855208: r17 = 10118
    //     0x855208: mov             x17, #0x2786
    // 0x85520c: cmp             w0, w17
    // 0x855210: b.ne            #0x855220
    // 0x855214: ldr             x2, [fp, #0x10]
    // 0x855218: LoadField: r0 = r2->field_7
    //     0x855218: ldur            x0, [x2, #7]
    // 0x85521c: b               #0x855234
    // 0x855220: ldr             x2, [fp, #0x10]
    // 0x855224: LoadField: r0 = r2->field_f
    //     0x855224: ldur            w0, [x2, #0xf]
    // 0x855228: DecompressPointer r0
    //     0x855228: add             x0, x0, HEAP, lsl #32
    // 0x85522c: LoadField: r3 = r0->field_7
    //     0x85522c: ldur            x3, [x0, #7]
    // 0x855230: mov             x0, x3
    // 0x855234: cmp             x1, x0
    // 0x855238: b.ne            #0x855278
    // 0x85523c: b               #0x855268
    // 0x855240: mov             x0, x1
    // 0x855244: r1 = LoadClassIdInstr(r2)
    //     0x855244: ldur            x1, [x2, #-1]
    //     0x855248: ubfx            x1, x1, #0xc, #0x14
    // 0x85524c: stp             x0, x2, [SP, #-0x10]!
    // 0x855250: mov             x0, x1
    // 0x855254: mov             lr, x0
    // 0x855258: ldr             lr, [x21, lr, lsl #3]
    // 0x85525c: blr             lr
    // 0x855260: add             SP, SP, #0x10
    // 0x855264: tbnz            w0, #4, #0x855278
    // 0x855268: r0 = Null
    //     0x855268: mov             x0, NULL
    // 0x85526c: LeaveFrame
    //     0x85526c: mov             SP, fp
    //     0x855270: ldp             fp, lr, [SP], #0x10
    // 0x855274: ret
    //     0x855274: ret             
    // 0x855278: ldr             x1, [fp, #0x18]
    // 0x85527c: ldr             x0, [fp, #0x10]
    // 0x855280: StoreField: r1->field_13 = r0
    //     0x855280: stur            w0, [x1, #0x13]
    //     0x855284: ldurb           w16, [x1, #-1]
    //     0x855288: ldurb           w17, [x0, #-1]
    //     0x85528c: and             x16, x17, x16, lsr #2
    //     0x855290: tst             x16, HEAP, lsr #32
    //     0x855294: b.eq            #0x85529c
    //     0x855298: bl              #0xd6826c
    // 0x85529c: LoadField: r0 = r1->field_7
    //     0x85529c: ldur            w0, [x1, #7]
    // 0x8552a0: DecompressPointer r0
    //     0x8552a0: add             x0, x0, HEAP, lsl #32
    // 0x8552a4: SaveReg r0
    //     0x8552a4: str             x0, [SP, #-8]!
    // 0x8552a8: r0 = markNeedsPaint()
    //     0x8552a8: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x8552ac: add             SP, SP, #8
    // 0x8552b0: r0 = Null
    //     0x8552b0: mov             x0, NULL
    // 0x8552b4: LeaveFrame
    //     0x8552b4: mov             SP, fp
    //     0x8552b8: ldp             fp, lr, [SP], #0x10
    // 0x8552bc: ret
    //     0x8552bc: ret             
    // 0x8552c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8552c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8552c4: b               #0x855134
  }
  _ paintInkCircle(/* No info */) {
    // ** addr: 0xbe4ad0, size: 0x244
    // 0xbe4ad0: EnterFrame
    //     0xbe4ad0: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4ad4: mov             fp, SP
    // 0xbe4ad8: AllocStack(0x30)
    //     0xbe4ad8: sub             SP, SP, #0x30
    // 0xbe4adc: CheckStackOverflow
    //     0xbe4adc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe4ae0: cmp             SP, x16
    //     0xbe4ae4: b.ls            #0xbe4cfc
    // 0xbe4ae8: ldr             x16, [fp, #0x10]
    // 0xbe4aec: SaveReg r16
    //     0xbe4aec: str             x16, [SP, #-8]!
    // 0xbe4af0: r0 = getAsTranslation()
    //     0xbe4af0: bl              #0x665a04  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xbe4af4: add             SP, SP, #8
    // 0xbe4af8: stur            x0, [fp, #-8]
    // 0xbe4afc: ldr             x16, [fp, #0x48]
    // 0xbe4b00: SaveReg r16
    //     0xbe4b00: str             x16, [SP, #-8]!
    // 0xbe4b04: r0 = save()
    //     0xbe4b04: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xbe4b08: add             SP, SP, #8
    // 0xbe4b0c: ldur            x0, [fp, #-8]
    // 0xbe4b10: cmp             w0, NULL
    // 0xbe4b14: b.ne            #0xbe4b38
    // 0xbe4b18: ldr             x0, [fp, #0x10]
    // 0xbe4b1c: LoadField: r1 = r0->field_7
    //     0xbe4b1c: ldur            w1, [x0, #7]
    // 0xbe4b20: DecompressPointer r1
    //     0xbe4b20: add             x1, x1, HEAP, lsl #32
    // 0xbe4b24: ldr             x16, [fp, #0x48]
    // 0xbe4b28: stp             x1, x16, [SP, #-0x10]!
    // 0xbe4b2c: r0 = transform()
    //     0xbe4b2c: bl              #0x656f48  ; [dart:ui] Canvas::transform
    // 0xbe4b30: add             SP, SP, #0x10
    // 0xbe4b34: b               #0xbe4b7c
    // 0xbe4b38: LoadField: d0 = r0->field_7
    //     0xbe4b38: ldur            d0, [x0, #7]
    // 0xbe4b3c: LoadField: d1 = r0->field_f
    //     0xbe4b3c: ldur            d1, [x0, #0xf]
    // 0xbe4b40: r0 = inline_Allocate_Double()
    //     0xbe4b40: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe4b44: add             x0, x0, #0x10
    //     0xbe4b48: cmp             x1, x0
    //     0xbe4b4c: b.ls            #0xbe4d04
    //     0xbe4b50: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe4b54: sub             x0, x0, #0xf
    //     0xbe4b58: mov             x1, #0xd108
    //     0xbe4b5c: movk            x1, #3, lsl #16
    //     0xbe4b60: stur            x1, [x0, #-1]
    // 0xbe4b64: StoreField: r0->field_7 = d0
    //     0xbe4b64: stur            d0, [x0, #7]
    // 0xbe4b68: ldr             x16, [fp, #0x48]
    // 0xbe4b6c: stp             x0, x16, [SP, #-0x10]!
    // 0xbe4b70: SaveReg d1
    //     0xbe4b70: str             d1, [SP, #-8]!
    // 0xbe4b74: r0 = translate()
    //     0xbe4b74: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0xbe4b78: add             SP, SP, #0x18
    // 0xbe4b7c: ldr             x0, [fp, #0x38]
    // 0xbe4b80: cmp             w0, NULL
    // 0xbe4b84: b.eq            #0xbe4cb8
    // 0xbe4b88: ldr             x1, [fp, #0x30]
    // 0xbe4b8c: SaveReg r0
    //     0xbe4b8c: str             x0, [SP, #-8]!
    // 0xbe4b90: ClosureCall
    //     0xbe4b90: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe4b94: ldur            x2, [x0, #0x1f]
    //     0xbe4b98: blr             x2
    // 0xbe4b9c: add             SP, SP, #8
    // 0xbe4ba0: mov             x1, x0
    // 0xbe4ba4: ldr             x0, [fp, #0x30]
    // 0xbe4ba8: stur            x1, [fp, #-8]
    // 0xbe4bac: cmp             w0, NULL
    // 0xbe4bb0: b.eq            #0xbe4bfc
    // 0xbe4bb4: r2 = LoadClassIdInstr(r0)
    //     0xbe4bb4: ldur            x2, [x0, #-1]
    //     0xbe4bb8: ubfx            x2, x2, #0xc, #0x14
    // 0xbe4bbc: stp             x1, x0, [SP, #-0x10]!
    // 0xbe4bc0: ldr             x16, [fp, #0x18]
    // 0xbe4bc4: SaveReg r16
    //     0xbe4bc4: str             x16, [SP, #-8]!
    // 0xbe4bc8: mov             x0, x2
    // 0xbe4bcc: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xbe4bcc: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xbe4bd0: ldr             x4, [x4, #0x5b8]
    // 0xbe4bd4: r0 = GDT[cid_x0 + -0xfde]()
    //     0xbe4bd4: sub             lr, x0, #0xfde
    //     0xbe4bd8: ldr             lr, [x21, lr, lsl #3]
    //     0xbe4bdc: blr             lr
    // 0xbe4be0: add             SP, SP, #0x18
    // 0xbe4be4: ldr             x16, [fp, #0x48]
    // 0xbe4be8: stp             x0, x16, [SP, #-0x10]!
    // 0xbe4bec: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe4bec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe4bf0: r0 = clipPath()
    //     0xbe4bf0: bl              #0x6629f4  ; [dart:ui] Canvas::clipPath
    // 0xbe4bf4: add             SP, SP, #0x10
    // 0xbe4bf8: b               #0xbe4cb8
    // 0xbe4bfc: ldr             x16, [fp, #0x50]
    // 0xbe4c00: r30 = Instance_BorderRadius
    //     0xbe4c00: add             lr, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xbe4c04: ldr             lr, [lr, #0x2c0]
    // 0xbe4c08: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4c0c: r0 = ==()
    //     0xbe4c0c: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xbe4c10: add             SP, SP, #0x10
    // 0xbe4c14: tbz             w0, #4, #0xbe4ca0
    // 0xbe4c18: ldr             x0, [fp, #0x50]
    // 0xbe4c1c: LoadField: r1 = r0->field_7
    //     0xbe4c1c: ldur            w1, [x0, #7]
    // 0xbe4c20: DecompressPointer r1
    //     0xbe4c20: add             x1, x1, HEAP, lsl #32
    // 0xbe4c24: stur            x1, [fp, #-0x28]
    // 0xbe4c28: LoadField: r2 = r0->field_b
    //     0xbe4c28: ldur            w2, [x0, #0xb]
    // 0xbe4c2c: DecompressPointer r2
    //     0xbe4c2c: add             x2, x2, HEAP, lsl #32
    // 0xbe4c30: stur            x2, [fp, #-0x20]
    // 0xbe4c34: LoadField: r3 = r0->field_f
    //     0xbe4c34: ldur            w3, [x0, #0xf]
    // 0xbe4c38: DecompressPointer r3
    //     0xbe4c38: add             x3, x3, HEAP, lsl #32
    // 0xbe4c3c: stur            x3, [fp, #-0x18]
    // 0xbe4c40: LoadField: r4 = r0->field_13
    //     0xbe4c40: ldur            w4, [x0, #0x13]
    // 0xbe4c44: DecompressPointer r4
    //     0xbe4c44: add             x4, x4, HEAP, lsl #32
    // 0xbe4c48: stur            x4, [fp, #-0x10]
    // 0xbe4c4c: r0 = RRect()
    //     0xbe4c4c: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xbe4c50: stur            x0, [fp, #-0x30]
    // 0xbe4c54: ldur            x16, [fp, #-8]
    // 0xbe4c58: stp             x16, x0, [SP, #-0x10]!
    // 0xbe4c5c: ldur            x16, [fp, #-0x28]
    // 0xbe4c60: ldur            lr, [fp, #-0x20]
    // 0xbe4c64: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4c68: ldur            x16, [fp, #-0x18]
    // 0xbe4c6c: ldur            lr, [fp, #-0x10]
    // 0xbe4c70: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4c74: r4 = const [0, 0x6, 0x6, 0x2, bottomLeft, 0x4, bottomRight, 0x5, topLeft, 0x2, topRight, 0x3, null]
    //     0xbe4c74: add             x4, PP, #0x21, lsl #12  ; [pp+0x21d00] List(13) [0, 0x6, 0x6, 0x2, "bottomLeft", 0x4, "bottomRight", 0x5, "topLeft", 0x2, "topRight", 0x3, Null]
    //     0xbe4c78: ldr             x4, [x4, #0xd00]
    // 0xbe4c7c: r0 = RRect.fromRectAndCorners()
    //     0xbe4c7c: bl              #0x6706f4  ; [dart:ui] RRect::RRect.fromRectAndCorners
    // 0xbe4c80: add             SP, SP, #0x30
    // 0xbe4c84: ldr             x16, [fp, #0x48]
    // 0xbe4c88: ldur            lr, [fp, #-0x30]
    // 0xbe4c8c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4c90: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe4c90: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe4c94: r0 = clipRRect()
    //     0xbe4c94: bl              #0x662040  ; [dart:ui] Canvas::clipRRect
    // 0xbe4c98: add             SP, SP, #0x10
    // 0xbe4c9c: b               #0xbe4cb8
    // 0xbe4ca0: ldr             x16, [fp, #0x48]
    // 0xbe4ca4: ldur            lr, [fp, #-8]
    // 0xbe4ca8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4cac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe4cac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe4cb0: r0 = clipRect()
    //     0xbe4cb0: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0xbe4cb4: add             SP, SP, #0x10
    // 0xbe4cb8: ldr             d0, [fp, #0x20]
    // 0xbe4cbc: ldr             x16, [fp, #0x48]
    // 0xbe4cc0: ldr             lr, [fp, #0x40]
    // 0xbe4cc4: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4cc8: SaveReg d0
    //     0xbe4cc8: str             d0, [SP, #-8]!
    // 0xbe4ccc: ldr             x16, [fp, #0x28]
    // 0xbe4cd0: SaveReg r16
    //     0xbe4cd0: str             x16, [SP, #-8]!
    // 0xbe4cd4: r0 = drawCircle()
    //     0xbe4cd4: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xbe4cd8: add             SP, SP, #0x20
    // 0xbe4cdc: ldr             x16, [fp, #0x48]
    // 0xbe4ce0: SaveReg r16
    //     0xbe4ce0: str             x16, [SP, #-8]!
    // 0xbe4ce4: r0 = restore()
    //     0xbe4ce4: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xbe4ce8: add             SP, SP, #8
    // 0xbe4cec: r0 = Null
    //     0xbe4cec: mov             x0, NULL
    // 0xbe4cf0: LeaveFrame
    //     0xbe4cf0: mov             SP, fp
    //     0xbe4cf4: ldp             fp, lr, [SP], #0x10
    // 0xbe4cf8: ret
    //     0xbe4cf8: ret             
    // 0xbe4cfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4cfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4d00: b               #0xbe4ae8
    // 0xbe4d04: stp             q0, q1, [SP, #-0x20]!
    // 0xbe4d08: r0 = AllocateDouble()
    //     0xbe4d08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbe4d0c: ldp             q0, q1, [SP], #0x20
    // 0xbe4d10: b               #0xbe4b64
  }
}

// class id: 3320, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class __InkResponseState&State&AutomaticKeepAliveClientMixin extends State<_InkResponseStateWidget>
     with AutomaticKeepAliveClientMixin<X0 bound StatefulWidget> {

  _ deactivate(/* No info */) {
    // ** addr: 0x7959b0, size: 0x4c
    // 0x7959b0: EnterFrame
    //     0x7959b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7959b4: mov             fp, SP
    // 0x7959b8: CheckStackOverflow
    //     0x7959b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7959bc: cmp             SP, x16
    //     0x7959c0: b.ls            #0x7959f4
    // 0x7959c4: ldr             x0, [fp, #0x10]
    // 0x7959c8: LoadField: r1 = r0->field_13
    //     0x7959c8: ldur            w1, [x0, #0x13]
    // 0x7959cc: DecompressPointer r1
    //     0x7959cc: add             x1, x1, HEAP, lsl #32
    // 0x7959d0: cmp             w1, NULL
    // 0x7959d4: b.eq            #0x7959e4
    // 0x7959d8: SaveReg r0
    //     0x7959d8: str             x0, [SP, #-8]!
    // 0x7959dc: r0 = _releaseKeepAlive()
    //     0x7959dc: bl              #0x7955e0  ; [package:flutter/src/widgets/sliver.dart] __SelectionKeepAliveState&State&AutomaticKeepAliveClientMixin::_releaseKeepAlive
    // 0x7959e0: add             SP, SP, #8
    // 0x7959e4: r0 = Null
    //     0x7959e4: mov             x0, NULL
    // 0x7959e8: LeaveFrame
    //     0x7959e8: mov             SP, fp
    //     0x7959ec: ldp             fp, lr, [SP], #0x10
    // 0x7959f0: ret
    //     0x7959f0: ret             
    // 0x7959f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7959f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7959f8: b               #0x7959c4
  }
  _ updateKeepAlive(/* No info */) {
    // ** addr: 0x7b2150, size: 0x84
    // 0x7b2150: EnterFrame
    //     0x7b2150: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2154: mov             fp, SP
    // 0x7b2158: CheckStackOverflow
    //     0x7b2158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b215c: cmp             SP, x16
    //     0x7b2160: b.ls            #0x7b21cc
    // 0x7b2164: ldr             x16, [fp, #0x10]
    // 0x7b2168: SaveReg r16
    //     0x7b2168: str             x16, [SP, #-8]!
    // 0x7b216c: r0 = wantKeepAlive()
    //     0x7b216c: bl              #0x7b21d4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::wantKeepAlive
    // 0x7b2170: add             SP, SP, #8
    // 0x7b2174: tbnz            w0, #4, #0x7b219c
    // 0x7b2178: ldr             x0, [fp, #0x10]
    // 0x7b217c: LoadField: r1 = r0->field_13
    //     0x7b217c: ldur            w1, [x0, #0x13]
    // 0x7b2180: DecompressPointer r1
    //     0x7b2180: add             x1, x1, HEAP, lsl #32
    // 0x7b2184: cmp             w1, NULL
    // 0x7b2188: b.ne            #0x7b21bc
    // 0x7b218c: SaveReg r0
    //     0x7b218c: str             x0, [SP, #-8]!
    // 0x7b2190: r0 = _ensureKeepAlive()
    //     0x7b2190: bl              #0x7a7088  ; [package:flutter/src/widgets/sliver.dart] __SelectionKeepAliveState&State&AutomaticKeepAliveClientMixin::_ensureKeepAlive
    // 0x7b2194: add             SP, SP, #8
    // 0x7b2198: b               #0x7b21bc
    // 0x7b219c: ldr             x0, [fp, #0x10]
    // 0x7b21a0: LoadField: r1 = r0->field_13
    //     0x7b21a0: ldur            w1, [x0, #0x13]
    // 0x7b21a4: DecompressPointer r1
    //     0x7b21a4: add             x1, x1, HEAP, lsl #32
    // 0x7b21a8: cmp             w1, NULL
    // 0x7b21ac: b.eq            #0x7b21bc
    // 0x7b21b0: SaveReg r0
    //     0x7b21b0: str             x0, [SP, #-8]!
    // 0x7b21b4: r0 = _releaseKeepAlive()
    //     0x7b21b4: bl              #0x7955e0  ; [package:flutter/src/widgets/sliver.dart] __SelectionKeepAliveState&State&AutomaticKeepAliveClientMixin::_releaseKeepAlive
    // 0x7b21b8: add             SP, SP, #8
    // 0x7b21bc: r0 = Null
    //     0x7b21bc: mov             x0, NULL
    // 0x7b21c0: LeaveFrame
    //     0x7b21c0: mov             SP, fp
    //     0x7b21c4: ldp             fp, lr, [SP], #0x10
    // 0x7b21c8: ret
    //     0x7b21c8: ret             
    // 0x7b21cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b21cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b21d0: b               #0x7b2164
  }
  _ build(/* No info */) {
    // ** addr: 0x8552c8, size: 0x64
    // 0x8552c8: EnterFrame
    //     0x8552c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8552cc: mov             fp, SP
    // 0x8552d0: CheckStackOverflow
    //     0x8552d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8552d4: cmp             SP, x16
    //     0x8552d8: b.ls            #0x855324
    // 0x8552dc: ldr             x16, [fp, #0x18]
    // 0x8552e0: SaveReg r16
    //     0x8552e0: str             x16, [SP, #-8]!
    // 0x8552e4: r0 = wantKeepAlive()
    //     0x8552e4: bl              #0x7b21d4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::wantKeepAlive
    // 0x8552e8: add             SP, SP, #8
    // 0x8552ec: tbnz            w0, #4, #0x855310
    // 0x8552f0: ldr             x0, [fp, #0x18]
    // 0x8552f4: LoadField: r1 = r0->field_13
    //     0x8552f4: ldur            w1, [x0, #0x13]
    // 0x8552f8: DecompressPointer r1
    //     0x8552f8: add             x1, x1, HEAP, lsl #32
    // 0x8552fc: cmp             w1, NULL
    // 0x855300: b.ne            #0x855310
    // 0x855304: SaveReg r0
    //     0x855304: str             x0, [SP, #-8]!
    // 0x855308: r0 = _ensureKeepAlive()
    //     0x855308: bl              #0x7a7088  ; [package:flutter/src/widgets/sliver.dart] __SelectionKeepAliveState&State&AutomaticKeepAliveClientMixin::_ensureKeepAlive
    // 0x85530c: add             SP, SP, #8
    // 0x855310: r0 = Instance__NullWidget
    //     0x855310: add             x0, PP, #0x27, lsl #12  ; [pp+0x272b0] Obj!_NullWidget@b4ede1
    //     0x855314: ldr             x0, [x0, #0x2b0]
    // 0x855318: LeaveFrame
    //     0x855318: mov             SP, fp
    //     0x85531c: ldp             fp, lr, [SP], #0x10
    // 0x855320: ret
    //     0x855320: ret             
    // 0x855324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855328: b               #0x8552dc
  }
  _ initState(/* No info */) {
    // ** addr: 0x9da194, size: 0x50
    // 0x9da194: EnterFrame
    //     0x9da194: stp             fp, lr, [SP, #-0x10]!
    //     0x9da198: mov             fp, SP
    // 0x9da19c: CheckStackOverflow
    //     0x9da19c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9da1a0: cmp             SP, x16
    //     0x9da1a4: b.ls            #0x9da1dc
    // 0x9da1a8: ldr             x16, [fp, #0x10]
    // 0x9da1ac: SaveReg r16
    //     0x9da1ac: str             x16, [SP, #-8]!
    // 0x9da1b0: r0 = wantKeepAlive()
    //     0x9da1b0: bl              #0x7b21d4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::wantKeepAlive
    // 0x9da1b4: add             SP, SP, #8
    // 0x9da1b8: tbnz            w0, #4, #0x9da1cc
    // 0x9da1bc: ldr             x16, [fp, #0x10]
    // 0x9da1c0: SaveReg r16
    //     0x9da1c0: str             x16, [SP, #-8]!
    // 0x9da1c4: r0 = _ensureKeepAlive()
    //     0x9da1c4: bl              #0x7a7088  ; [package:flutter/src/widgets/sliver.dart] __SelectionKeepAliveState&State&AutomaticKeepAliveClientMixin::_ensureKeepAlive
    // 0x9da1c8: add             SP, SP, #8
    // 0x9da1cc: r0 = Null
    //     0x9da1cc: mov             x0, NULL
    // 0x9da1d0: LeaveFrame
    //     0x9da1d0: mov             SP, fp
    //     0x9da1d4: ldp             fp, lr, [SP], #0x10
    // 0x9da1d8: ret
    //     0x9da1d8: ret             
    // 0x9da1dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9da1dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9da1e0: b               #0x9da1a8
  }
}

// class id: 3321, size: 0x38, field offset: 0x18
class _InkResponseState extends __InkResponseState&State&AutomaticKeepAliveClientMixin
    implements _ParentInkResponseState {

  late final Map<Type, Action<Intent>> _actionMap; // offset: 0x28

  [closure] void handleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0x5a6a48, size: 0x40
    // 0x5a6a48: EnterFrame
    //     0x5a6a48: stp             fp, lr, [SP, #-0x10]!
    //     0x5a6a4c: mov             fp, SP
    // 0x5a6a50: ldr             x1, [fp, #0x18]
    // 0x5a6a54: LoadField: r2 = r1->field_17
    //     0x5a6a54: ldur            w2, [x1, #0x17]
    // 0x5a6a58: DecompressPointer r2
    //     0x5a6a58: add             x2, x2, HEAP, lsl #32
    // 0x5a6a5c: LoadField: r1 = r2->field_f
    //     0x5a6a5c: ldur            w1, [x2, #0xf]
    // 0x5a6a60: DecompressPointer r1
    //     0x5a6a60: add             x1, x1, HEAP, lsl #32
    // 0x5a6a64: LoadField: r2 = r1->field_b
    //     0x5a6a64: ldur            w2, [x1, #0xb]
    // 0x5a6a68: DecompressPointer r2
    //     0x5a6a68: add             x2, x2, HEAP, lsl #32
    // 0x5a6a6c: cmp             w2, NULL
    // 0x5a6a70: b.eq            #0x5a6a84
    // 0x5a6a74: r0 = Null
    //     0x5a6a74: mov             x0, NULL
    // 0x5a6a78: LeaveFrame
    //     0x5a6a78: mov             SP, fp
    //     0x5a6a7c: ldp             fp, lr, [SP], #0x10
    // 0x5a6a80: ret
    //     0x5a6a80: ret             
    // 0x5a6a84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a6a84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ deactivate(/* No info */) {
    // ** addr: 0x7956c8, size: 0x2c4
    // 0x7956c8: EnterFrame
    //     0x7956c8: stp             fp, lr, [SP, #-0x10]!
    //     0x7956cc: mov             fp, SP
    // 0x7956d0: AllocStack(0x28)
    //     0x7956d0: sub             SP, SP, #0x28
    // 0x7956d4: CheckStackOverflow
    //     0x7956d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7956d8: cmp             SP, x16
    //     0x7956dc: b.ls            #0x795964
    // 0x7956e0: ldr             x0, [fp, #0x10]
    // 0x7956e4: LoadField: r2 = r0->field_17
    //     0x7956e4: ldur            w2, [x0, #0x17]
    // 0x7956e8: DecompressPointer r2
    //     0x7956e8: add             x2, x2, HEAP, lsl #32
    // 0x7956ec: stur            x2, [fp, #-0x10]
    // 0x7956f0: cmp             w2, NULL
    // 0x7956f4: b.eq            #0x7957cc
    // 0x7956f8: StoreField: r0->field_17 = rNULL
    //     0x7956f8: stur            NULL, [x0, #0x17]
    // 0x7956fc: LoadField: r3 = r2->field_7
    //     0x7956fc: ldur            w3, [x2, #7]
    // 0x795700: DecompressPointer r3
    //     0x795700: add             x3, x3, HEAP, lsl #32
    // 0x795704: mov             x1, x3
    // 0x795708: stur            x3, [fp, #-8]
    // 0x79570c: r0 = _HashSetIterator()
    //     0x79570c: bl              #0x554e80  ; Allocate_HashSetIteratorStub -> _HashSetIterator<X0> (size=0x28)
    // 0x795710: mov             x1, x0
    // 0x795714: r0 = 0
    //     0x795714: mov             x0, #0
    // 0x795718: stur            x1, [fp, #-0x18]
    // 0x79571c: StoreField: r1->field_17 = r0
    //     0x79571c: stur            x0, [x1, #0x17]
    // 0x795720: ldur            x0, [fp, #-0x10]
    // 0x795724: StoreField: r1->field_b = r0
    //     0x795724: stur            w0, [x1, #0xb]
    // 0x795728: LoadField: r2 = r0->field_17
    //     0x795728: ldur            x2, [x0, #0x17]
    // 0x79572c: StoreField: r1->field_f = r2
    //     0x79572c: stur            x2, [x1, #0xf]
    // 0x795730: CheckStackOverflow
    //     0x795730: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795734: cmp             SP, x16
    //     0x795738: b.ls            #0x79596c
    // 0x79573c: SaveReg r1
    //     0x79573c: str             x1, [SP, #-8]!
    // 0x795740: r0 = moveNext()
    //     0x795740: bl              #0xc3c604  ; [dart:collection] _HashSetIterator::moveNext
    // 0x795744: add             SP, SP, #8
    // 0x795748: tbnz            w0, #4, #0x7957c4
    // 0x79574c: ldur            x3, [fp, #-0x18]
    // 0x795750: LoadField: r4 = r3->field_23
    //     0x795750: ldur            w4, [x3, #0x23]
    // 0x795754: DecompressPointer r4
    //     0x795754: add             x4, x4, HEAP, lsl #32
    // 0x795758: stur            x4, [fp, #-0x10]
    // 0x79575c: cmp             w4, NULL
    // 0x795760: b.ne            #0x795794
    // 0x795764: mov             x0, x4
    // 0x795768: ldur            x2, [fp, #-8]
    // 0x79576c: r1 = Null
    //     0x79576c: mov             x1, NULL
    // 0x795770: cmp             w2, NULL
    // 0x795774: b.eq            #0x795794
    // 0x795778: LoadField: r4 = r2->field_17
    //     0x795778: ldur            w4, [x2, #0x17]
    // 0x79577c: DecompressPointer r4
    //     0x79577c: add             x4, x4, HEAP, lsl #32
    // 0x795780: r8 = X0
    //     0x795780: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x795784: LoadField: r9 = r4->field_7
    //     0x795784: ldur            x9, [x4, #7]
    // 0x795788: r3 = Null
    //     0x795788: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e498] Null
    //     0x79578c: ldr             x3, [x3, #0x498]
    // 0x795790: blr             x9
    // 0x795794: ldur            x0, [fp, #-0x10]
    // 0x795798: r1 = LoadClassIdInstr(r0)
    //     0x795798: ldur            x1, [x0, #-1]
    //     0x79579c: ubfx            x1, x1, #0xc, #0x14
    // 0x7957a0: SaveReg r0
    //     0x7957a0: str             x0, [SP, #-8]!
    // 0x7957a4: mov             x0, x1
    // 0x7957a8: r0 = GDT[cid_x0 + 0x16da]()
    //     0x7957a8: mov             x17, #0x16da
    //     0x7957ac: add             lr, x0, x17
    //     0x7957b0: ldr             lr, [x21, lr, lsl #3]
    //     0x7957b4: blr             lr
    // 0x7957b8: add             SP, SP, #8
    // 0x7957bc: ldur            x1, [fp, #-0x18]
    // 0x7957c0: b               #0x795730
    // 0x7957c4: ldr             x0, [fp, #0x10]
    // 0x7957c8: StoreField: r0->field_1b = rNULL
    //     0x7957c8: stur            NULL, [x0, #0x1b]
    // 0x7957cc: LoadField: r1 = r0->field_23
    //     0x7957cc: ldur            w1, [x0, #0x23]
    // 0x7957d0: DecompressPointer r1
    //     0x7957d0: add             x1, x1, HEAP, lsl #32
    // 0x7957d4: stur            x1, [fp, #-8]
    // 0x7957d8: SaveReg r1
    //     0x7957d8: str             x1, [SP, #-8]!
    // 0x7957dc: r0 = keys()
    //     0x7957dc: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x7957e0: add             SP, SP, #8
    // 0x7957e4: SaveReg r0
    //     0x7957e4: str             x0, [SP, #-8]!
    // 0x7957e8: r0 = iterator()
    //     0x7957e8: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x7957ec: add             SP, SP, #8
    // 0x7957f0: stur            x0, [fp, #-0x18]
    // 0x7957f4: LoadField: r2 = r0->field_7
    //     0x7957f4: ldur            w2, [x0, #7]
    // 0x7957f8: DecompressPointer r2
    //     0x7957f8: add             x2, x2, HEAP, lsl #32
    // 0x7957fc: stur            x2, [fp, #-0x10]
    // 0x795800: ldur            x1, [fp, #-8]
    // 0x795804: CheckStackOverflow
    //     0x795804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795808: cmp             SP, x16
    //     0x79580c: b.ls            #0x795974
    // 0x795810: SaveReg r0
    //     0x795810: str             x0, [SP, #-8]!
    // 0x795814: r0 = moveNext()
    //     0x795814: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x795818: add             SP, SP, #8
    // 0x79581c: tbnz            w0, #4, #0x79590c
    // 0x795820: ldur            x3, [fp, #-0x18]
    // 0x795824: LoadField: r4 = r3->field_33
    //     0x795824: ldur            w4, [x3, #0x33]
    // 0x795828: DecompressPointer r4
    //     0x795828: add             x4, x4, HEAP, lsl #32
    // 0x79582c: stur            x4, [fp, #-0x20]
    // 0x795830: cmp             w4, NULL
    // 0x795834: b.ne            #0x795868
    // 0x795838: mov             x0, x4
    // 0x79583c: ldur            x2, [fp, #-0x10]
    // 0x795840: r1 = Null
    //     0x795840: mov             x1, NULL
    // 0x795844: cmp             w2, NULL
    // 0x795848: b.eq            #0x795868
    // 0x79584c: LoadField: r4 = r2->field_17
    //     0x79584c: ldur            w4, [x2, #0x17]
    // 0x795850: DecompressPointer r4
    //     0x795850: add             x4, x4, HEAP, lsl #32
    // 0x795854: r8 = X0
    //     0x795854: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x795858: LoadField: r9 = r4->field_7
    //     0x795858: ldur            x9, [x4, #7]
    // 0x79585c: r3 = Null
    //     0x79585c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e4a8] Null
    //     0x795860: ldr             x3, [x3, #0x4a8]
    // 0x795864: blr             x9
    // 0x795868: ldur            x0, [fp, #-8]
    // 0x79586c: ldur            x16, [fp, #-0x20]
    // 0x795870: stp             x16, x0, [SP, #-0x10]!
    // 0x795874: r0 = _getValueOrData()
    //     0x795874: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x795878: add             SP, SP, #0x10
    // 0x79587c: mov             x1, x0
    // 0x795880: ldur            x0, [fp, #-8]
    // 0x795884: LoadField: r2 = r0->field_f
    //     0x795884: ldur            w2, [x0, #0xf]
    // 0x795888: DecompressPointer r2
    //     0x795888: add             x2, x2, HEAP, lsl #32
    // 0x79588c: cmp             w2, w1
    // 0x795890: b.ne            #0x795898
    // 0x795894: r1 = Null
    //     0x795894: mov             x1, NULL
    // 0x795898: stur            x1, [fp, #-0x28]
    // 0x79589c: cmp             w1, NULL
    // 0x7958a0: b.eq            #0x7958d4
    // 0x7958a4: LoadField: r2 = r1->field_33
    //     0x7958a4: ldur            w2, [x1, #0x33]
    // 0x7958a8: DecompressPointer r2
    //     0x7958a8: add             x2, x2, HEAP, lsl #32
    // 0x7958ac: r16 = Sentinel
    //     0x7958ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7958b0: cmp             w2, w16
    // 0x7958b4: b.eq            #0x79597c
    // 0x7958b8: SaveReg r2
    //     0x7958b8: str             x2, [SP, #-8]!
    // 0x7958bc: r0 = dispose()
    //     0x7958bc: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x7958c0: add             SP, SP, #8
    // 0x7958c4: ldur            x16, [fp, #-0x28]
    // 0x7958c8: SaveReg r16
    //     0x7958c8: str             x16, [SP, #-8]!
    // 0x7958cc: r0 = dispose()
    //     0x7958cc: bl              #0x795b14  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0x7958d0: add             SP, SP, #8
    // 0x7958d4: ldur            x16, [fp, #-0x20]
    // 0x7958d8: SaveReg r16
    //     0x7958d8: str             x16, [SP, #-8]!
    // 0x7958dc: r0 = _getHash()
    //     0x7958dc: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0x7958e0: add             SP, SP, #8
    // 0x7958e4: r1 = LoadInt32Instr(r0)
    //     0x7958e4: sbfx            x1, x0, #1, #0x1f
    // 0x7958e8: ldur            x16, [fp, #-8]
    // 0x7958ec: ldur            lr, [fp, #-0x20]
    // 0x7958f0: stp             lr, x16, [SP, #-0x10]!
    // 0x7958f4: stp             x1, NULL, [SP, #-0x10]!
    // 0x7958f8: r0 = _set()
    //     0x7958f8: bl              #0x4b3fe8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_set
    // 0x7958fc: add             SP, SP, #0x20
    // 0x795900: ldur            x0, [fp, #-0x18]
    // 0x795904: ldur            x2, [fp, #-0x10]
    // 0x795908: b               #0x795800
    // 0x79590c: ldr             x0, [fp, #0x10]
    // 0x795910: LoadField: r1 = r0->field_b
    //     0x795910: ldur            w1, [x0, #0xb]
    // 0x795914: DecompressPointer r1
    //     0x795914: add             x1, x1, HEAP, lsl #32
    // 0x795918: cmp             w1, NULL
    // 0x79591c: b.eq            #0x795988
    // 0x795920: LoadField: r2 = r1->field_77
    //     0x795920: ldur            w2, [x1, #0x77]
    // 0x795924: DecompressPointer r2
    //     0x795924: add             x2, x2, HEAP, lsl #32
    // 0x795928: cmp             w2, NULL
    // 0x79592c: b.eq            #0x795944
    // 0x795930: stp             x0, x2, [SP, #-0x10]!
    // 0x795934: r16 = false
    //     0x795934: add             x16, NULL, #0x30  ; false
    // 0x795938: SaveReg r16
    //     0x795938: str             x16, [SP, #-8]!
    // 0x79593c: r0 = markChildInkResponsePressed()
    //     0x79593c: bl              #0x7959fc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::markChildInkResponsePressed
    // 0x795940: add             SP, SP, #0x18
    // 0x795944: ldr             x16, [fp, #0x10]
    // 0x795948: SaveReg r16
    //     0x795948: str             x16, [SP, #-8]!
    // 0x79594c: r0 = deactivate()
    //     0x79594c: bl              #0x7959b0  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::deactivate
    // 0x795950: add             SP, SP, #8
    // 0x795954: r0 = Null
    //     0x795954: mov             x0, NULL
    // 0x795958: LeaveFrame
    //     0x795958: mov             SP, fp
    //     0x79595c: ldp             fp, lr, [SP], #0x10
    // 0x795960: ret
    //     0x795960: ret             
    // 0x795964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795968: b               #0x7956e0
    // 0x79596c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79596c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795970: b               #0x79573c
    // 0x795974: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795974: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795978: b               #0x795810
    // 0x79597c: r9 = _alphaController
    //     0x79597c: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2a8] Field <InkHighlight._alphaController@756209331>: late (offset: 0x34)
    //     0x795980: ldr             x9, [x9, #0x2a8]
    // 0x795984: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x795984: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x795988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x795988: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markChildInkResponsePressed(/* No info */) {
    // ** addr: 0x7959fc, size: 0xe8
    // 0x7959fc: EnterFrame
    //     0x7959fc: stp             fp, lr, [SP, #-0x10]!
    //     0x795a00: mov             fp, SP
    // 0x795a04: AllocStack(0x8)
    //     0x795a04: sub             SP, SP, #8
    // 0x795a08: CheckStackOverflow
    //     0x795a08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795a0c: cmp             SP, x16
    //     0x795a10: b.ls            #0x795ad8
    // 0x795a14: ldr             x0, [fp, #0x20]
    // 0x795a18: LoadField: r1 = r0->field_2f
    //     0x795a18: ldur            w1, [x0, #0x2f]
    // 0x795a1c: DecompressPointer r1
    //     0x795a1c: add             x1, x1, HEAP, lsl #32
    // 0x795a20: LoadField: r2 = r1->field_b
    //     0x795a20: ldur            w2, [x1, #0xb]
    // 0x795a24: DecompressPointer r2
    //     0x795a24: add             x2, x2, HEAP, lsl #32
    // 0x795a28: LoadField: r3 = r2->field_b
    //     0x795a28: ldur            w3, [x2, #0xb]
    // 0x795a2c: DecompressPointer r3
    //     0x795a2c: add             x3, x3, HEAP, lsl #32
    // 0x795a30: cbnz            w3, #0x795a3c
    // 0x795a34: r2 = false
    //     0x795a34: add             x2, NULL, #0x30  ; false
    // 0x795a38: b               #0x795a40
    // 0x795a3c: r2 = true
    //     0x795a3c: add             x2, NULL, #0x20  ; true
    // 0x795a40: ldr             x3, [fp, #0x10]
    // 0x795a44: stur            x2, [fp, #-8]
    // 0x795a48: tbnz            w3, #4, #0x795a60
    // 0x795a4c: ldr             x16, [fp, #0x18]
    // 0x795a50: stp             x16, x1, [SP, #-0x10]!
    // 0x795a54: r0 = add()
    //     0x795a54: bl              #0x6e93b4  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::add
    // 0x795a58: add             SP, SP, #0x10
    // 0x795a5c: b               #0x795a70
    // 0x795a60: ldr             x16, [fp, #0x18]
    // 0x795a64: stp             x16, x1, [SP, #-0x10]!
    // 0x795a68: r0 = remove()
    //     0x795a68: bl              #0x6f5e78  ; [package:flutter/src/foundation/observer_list.dart] ObserverList::remove
    // 0x795a6c: add             SP, SP, #0x10
    // 0x795a70: ldur            x0, [fp, #-8]
    // 0x795a74: ldr             x16, [fp, #0x20]
    // 0x795a78: SaveReg r16
    //     0x795a78: str             x16, [SP, #-8]!
    // 0x795a7c: r0 = _anyChildInkResponsePressed()
    //     0x795a7c: bl              #0x795ae4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_anyChildInkResponsePressed
    // 0x795a80: add             SP, SP, #8
    // 0x795a84: mov             x1, x0
    // 0x795a88: ldur            x0, [fp, #-8]
    // 0x795a8c: cmp             w1, w0
    // 0x795a90: b.eq            #0x795ac8
    // 0x795a94: ldr             x0, [fp, #0x20]
    // 0x795a98: LoadField: r2 = r0->field_b
    //     0x795a98: ldur            w2, [x0, #0xb]
    // 0x795a9c: DecompressPointer r2
    //     0x795a9c: add             x2, x2, HEAP, lsl #32
    // 0x795aa0: cmp             w2, NULL
    // 0x795aa4: b.eq            #0x795ae0
    // 0x795aa8: LoadField: r3 = r2->field_77
    //     0x795aa8: ldur            w3, [x2, #0x77]
    // 0x795aac: DecompressPointer r3
    //     0x795aac: add             x3, x3, HEAP, lsl #32
    // 0x795ab0: cmp             w3, NULL
    // 0x795ab4: b.eq            #0x795ac8
    // 0x795ab8: stp             x0, x3, [SP, #-0x10]!
    // 0x795abc: SaveReg r1
    //     0x795abc: str             x1, [SP, #-8]!
    // 0x795ac0: r0 = markChildInkResponsePressed()
    //     0x795ac0: bl              #0x7959fc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::markChildInkResponsePressed
    // 0x795ac4: add             SP, SP, #0x18
    // 0x795ac8: r0 = Null
    //     0x795ac8: mov             x0, NULL
    // 0x795acc: LeaveFrame
    //     0x795acc: mov             SP, fp
    //     0x795ad0: ldp             fp, lr, [SP], #0x10
    // 0x795ad4: ret
    //     0x795ad4: ret             
    // 0x795ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795ad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795adc: b               #0x795a14
    // 0x795ae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x795ae0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _anyChildInkResponsePressed(/* No info */) {
    // ** addr: 0x795ae4, size: 0x30
    // 0x795ae4: ldr             x1, [SP]
    // 0x795ae8: LoadField: r2 = r1->field_2f
    //     0x795ae8: ldur            w2, [x1, #0x2f]
    // 0x795aec: DecompressPointer r2
    //     0x795aec: add             x2, x2, HEAP, lsl #32
    // 0x795af0: LoadField: r1 = r2->field_b
    //     0x795af0: ldur            w1, [x2, #0xb]
    // 0x795af4: DecompressPointer r1
    //     0x795af4: add             x1, x1, HEAP, lsl #32
    // 0x795af8: LoadField: r2 = r1->field_b
    //     0x795af8: ldur            w2, [x1, #0xb]
    // 0x795afc: DecompressPointer r2
    //     0x795afc: add             x2, x2, HEAP, lsl #32
    // 0x795b00: cbnz            w2, #0x795b0c
    // 0x795b04: r0 = false
    //     0x795b04: add             x0, NULL, #0x30  ; false
    // 0x795b08: b               #0x795b10
    // 0x795b0c: r0 = true
    //     0x795b0c: add             x0, NULL, #0x20  ; true
    // 0x795b10: ret
    //     0x795b10: ret             
  }
  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b11b4, size: 0x508
    // 0x7b11b4: EnterFrame
    //     0x7b11b4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b11b8: mov             fp, SP
    // 0x7b11bc: AllocStack(0x8)
    //     0x7b11bc: sub             SP, SP, #8
    // 0x7b11c0: CheckStackOverflow
    //     0x7b11c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b11c4: cmp             SP, x16
    //     0x7b11c8: b.ls            #0x7b168c
    // 0x7b11cc: ldr             x0, [fp, #0x10]
    // 0x7b11d0: r2 = Null
    //     0x7b11d0: mov             x2, NULL
    // 0x7b11d4: r1 = Null
    //     0x7b11d4: mov             x1, NULL
    // 0x7b11d8: r4 = 59
    //     0x7b11d8: mov             x4, #0x3b
    // 0x7b11dc: branchIfSmi(r0, 0x7b11e8)
    //     0x7b11dc: tbz             w0, #0, #0x7b11e8
    // 0x7b11e0: r4 = LoadClassIdInstr(r0)
    //     0x7b11e0: ldur            x4, [x0, #-1]
    //     0x7b11e4: ubfx            x4, x4, #0xc, #0x14
    // 0x7b11e8: r17 = 4152
    //     0x7b11e8: mov             x17, #0x1038
    // 0x7b11ec: cmp             x4, x17
    // 0x7b11f0: b.eq            #0x7b1208
    // 0x7b11f4: r8 = _InkResponseStateWidget
    //     0x7b11f4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e4e8] Type: _InkResponseStateWidget
    //     0x7b11f8: ldr             x8, [x8, #0x4e8]
    // 0x7b11fc: r3 = Null
    //     0x7b11fc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e4f0] Null
    //     0x7b1200: ldr             x3, [x3, #0x4f0]
    // 0x7b1204: r0 = _InkResponseStateWidget()
    //     0x7b1204: bl              #0x5a6a88  ; IsType__InkResponseStateWidget_Stub
    // 0x7b1208: ldr             x3, [fp, #0x18]
    // 0x7b120c: LoadField: r2 = r3->field_7
    //     0x7b120c: ldur            w2, [x3, #7]
    // 0x7b1210: DecompressPointer r2
    //     0x7b1210: add             x2, x2, HEAP, lsl #32
    // 0x7b1214: ldr             x0, [fp, #0x10]
    // 0x7b1218: r1 = Null
    //     0x7b1218: mov             x1, NULL
    // 0x7b121c: cmp             w2, NULL
    // 0x7b1220: b.eq            #0x7b1244
    // 0x7b1224: LoadField: r4 = r2->field_17
    //     0x7b1224: ldur            w4, [x2, #0x17]
    // 0x7b1228: DecompressPointer r4
    //     0x7b1228: add             x4, x4, HEAP, lsl #32
    // 0x7b122c: r8 = X0 bound StatefulWidget
    //     0x7b122c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b1230: ldr             x8, [x8, #0x858]
    // 0x7b1234: LoadField: r9 = r4->field_7
    //     0x7b1234: ldur            x9, [x4, #7]
    // 0x7b1238: r3 = Null
    //     0x7b1238: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e500] Null
    //     0x7b123c: ldr             x3, [x3, #0x500]
    // 0x7b1240: blr             x9
    // 0x7b1244: ldr             x0, [fp, #0x18]
    // 0x7b1248: LoadField: r1 = r0->field_b
    //     0x7b1248: ldur            w1, [x0, #0xb]
    // 0x7b124c: DecompressPointer r1
    //     0x7b124c: add             x1, x1, HEAP, lsl #32
    // 0x7b1250: cmp             w1, NULL
    // 0x7b1254: b.eq            #0x7b1694
    // 0x7b1258: LoadField: r2 = r1->field_7f
    //     0x7b1258: ldur            w2, [x1, #0x7f]
    // 0x7b125c: DecompressPointer r2
    //     0x7b125c: add             x2, x2, HEAP, lsl #32
    // 0x7b1260: ldr             x1, [fp, #0x10]
    // 0x7b1264: LoadField: r3 = r1->field_7f
    //     0x7b1264: ldur            w3, [x1, #0x7f]
    // 0x7b1268: DecompressPointer r3
    //     0x7b1268: add             x3, x3, HEAP, lsl #32
    // 0x7b126c: stur            x3, [fp, #-8]
    // 0x7b1270: cmp             w2, w3
    // 0x7b1274: b.eq            #0x7b1308
    // 0x7b1278: cmp             w3, NULL
    // 0x7b127c: b.eq            #0x7b12b8
    // 0x7b1280: r1 = 1
    //     0x7b1280: mov             x1, #1
    // 0x7b1284: r0 = AllocateContext()
    //     0x7b1284: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b1288: mov             x1, x0
    // 0x7b128c: ldr             x0, [fp, #0x18]
    // 0x7b1290: StoreField: r1->field_f = r0
    //     0x7b1290: stur            w0, [x1, #0xf]
    // 0x7b1294: mov             x2, x1
    // 0x7b1298: r1 = Function 'handleStatesControllerChange':.
    //     0x7b1298: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4c0] AnonymousClosure: (0x7b2b14), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange (0x7b2b5c)
    //     0x7b129c: ldr             x1, [x1, #0x4c0]
    // 0x7b12a0: r0 = AllocateClosure()
    //     0x7b12a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b12a4: ldur            x16, [fp, #-8]
    // 0x7b12a8: stp             x0, x16, [SP, #-0x10]!
    // 0x7b12ac: r0 = removeListener()
    //     0x7b12ac: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7b12b0: add             SP, SP, #0x10
    // 0x7b12b4: ldr             x0, [fp, #0x18]
    // 0x7b12b8: LoadField: r1 = r0->field_b
    //     0x7b12b8: ldur            w1, [x0, #0xb]
    // 0x7b12bc: DecompressPointer r1
    //     0x7b12bc: add             x1, x1, HEAP, lsl #32
    // 0x7b12c0: cmp             w1, NULL
    // 0x7b12c4: b.eq            #0x7b1698
    // 0x7b12c8: LoadField: r2 = r1->field_7f
    //     0x7b12c8: ldur            w2, [x1, #0x7f]
    // 0x7b12cc: DecompressPointer r2
    //     0x7b12cc: add             x2, x2, HEAP, lsl #32
    // 0x7b12d0: cmp             w2, NULL
    // 0x7b12d4: b.eq            #0x7b12fc
    // 0x7b12d8: LoadField: r1 = r0->field_2b
    //     0x7b12d8: ldur            w1, [x0, #0x2b]
    // 0x7b12dc: DecompressPointer r1
    //     0x7b12dc: add             x1, x1, HEAP, lsl #32
    // 0x7b12e0: cmp             w1, NULL
    // 0x7b12e4: b.eq            #0x7b12f8
    // 0x7b12e8: SaveReg r1
    //     0x7b12e8: str             x1, [SP, #-8]!
    // 0x7b12ec: r0 = dispose()
    //     0x7b12ec: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x7b12f0: add             SP, SP, #8
    // 0x7b12f4: ldr             x0, [fp, #0x18]
    // 0x7b12f8: StoreField: r0->field_2b = rNULL
    //     0x7b12f8: stur            NULL, [x0, #0x2b]
    // 0x7b12fc: SaveReg r0
    //     0x7b12fc: str             x0, [SP, #-8]!
    // 0x7b1300: r0 = initStatesController()
    //     0x7b1300: bl              #0x7b2984  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::initStatesController
    // 0x7b1304: add             SP, SP, #8
    // 0x7b1308: ldr             x1, [fp, #0x18]
    // 0x7b130c: ldr             x2, [fp, #0x10]
    // 0x7b1310: LoadField: r0 = r1->field_b
    //     0x7b1310: ldur            w0, [x1, #0xb]
    // 0x7b1314: DecompressPointer r0
    //     0x7b1314: add             x0, x0, HEAP, lsl #32
    // 0x7b1318: cmp             w0, NULL
    // 0x7b131c: b.eq            #0x7b169c
    // 0x7b1320: LoadField: r3 = r0->field_43
    //     0x7b1320: ldur            w3, [x0, #0x43]
    // 0x7b1324: DecompressPointer r3
    //     0x7b1324: add             x3, x3, HEAP, lsl #32
    // 0x7b1328: LoadField: r0 = r2->field_43
    //     0x7b1328: ldur            w0, [x2, #0x43]
    // 0x7b132c: DecompressPointer r0
    //     0x7b132c: add             x0, x0, HEAP, lsl #32
    // 0x7b1330: r4 = LoadClassIdInstr(r3)
    //     0x7b1330: ldur            x4, [x3, #-1]
    //     0x7b1334: ubfx            x4, x4, #0xc, #0x14
    // 0x7b1338: stp             x0, x3, [SP, #-0x10]!
    // 0x7b133c: mov             x0, x4
    // 0x7b1340: mov             lr, x0
    // 0x7b1344: ldr             lr, [x21, lr, lsl #3]
    // 0x7b1348: blr             lr
    // 0x7b134c: add             SP, SP, #0x10
    // 0x7b1350: tbz             w0, #4, #0x7b1360
    // 0x7b1354: ldr             x0, [fp, #0x18]
    // 0x7b1358: ldr             x1, [fp, #0x10]
    // 0x7b135c: b               #0x7b1440
    // 0x7b1360: ldr             x1, [fp, #0x18]
    // 0x7b1364: ldr             x2, [fp, #0x10]
    // 0x7b1368: LoadField: r0 = r1->field_b
    //     0x7b1368: ldur            w0, [x1, #0xb]
    // 0x7b136c: DecompressPointer r0
    //     0x7b136c: add             x0, x0, HEAP, lsl #32
    // 0x7b1370: cmp             w0, NULL
    // 0x7b1374: b.eq            #0x7b16a0
    // 0x7b1378: LoadField: r3 = r0->field_3b
    //     0x7b1378: ldur            w3, [x0, #0x3b]
    // 0x7b137c: DecompressPointer r3
    //     0x7b137c: add             x3, x3, HEAP, lsl #32
    // 0x7b1380: LoadField: r0 = r2->field_3b
    //     0x7b1380: ldur            w0, [x2, #0x3b]
    // 0x7b1384: DecompressPointer r0
    //     0x7b1384: add             x0, x0, HEAP, lsl #32
    // 0x7b1388: r4 = LoadClassIdInstr(r3)
    //     0x7b1388: ldur            x4, [x3, #-1]
    //     0x7b138c: ubfx            x4, x4, #0xc, #0x14
    // 0x7b1390: stp             x0, x3, [SP, #-0x10]!
    // 0x7b1394: mov             x0, x4
    // 0x7b1398: mov             lr, x0
    // 0x7b139c: ldr             lr, [x21, lr, lsl #3]
    // 0x7b13a0: blr             lr
    // 0x7b13a4: add             SP, SP, #0x10
    // 0x7b13a8: tbz             w0, #4, #0x7b13b8
    // 0x7b13ac: ldr             x0, [fp, #0x18]
    // 0x7b13b0: ldr             x1, [fp, #0x10]
    // 0x7b13b4: b               #0x7b1440
    // 0x7b13b8: ldr             x1, [fp, #0x18]
    // 0x7b13bc: ldr             x2, [fp, #0x10]
    // 0x7b13c0: LoadField: r0 = r1->field_b
    //     0x7b13c0: ldur            w0, [x1, #0xb]
    // 0x7b13c4: DecompressPointer r0
    //     0x7b13c4: add             x0, x0, HEAP, lsl #32
    // 0x7b13c8: cmp             w0, NULL
    // 0x7b13cc: b.eq            #0x7b16a4
    // 0x7b13d0: LoadField: r3 = r0->field_3f
    //     0x7b13d0: ldur            w3, [x0, #0x3f]
    // 0x7b13d4: DecompressPointer r3
    //     0x7b13d4: add             x3, x3, HEAP, lsl #32
    // 0x7b13d8: LoadField: r0 = r2->field_3f
    //     0x7b13d8: ldur            w0, [x2, #0x3f]
    // 0x7b13dc: DecompressPointer r0
    //     0x7b13dc: add             x0, x0, HEAP, lsl #32
    // 0x7b13e0: r4 = LoadClassIdInstr(r3)
    //     0x7b13e0: ldur            x4, [x3, #-1]
    //     0x7b13e4: ubfx            x4, x4, #0xc, #0x14
    // 0x7b13e8: stp             x0, x3, [SP, #-0x10]!
    // 0x7b13ec: mov             x0, x4
    // 0x7b13f0: mov             lr, x0
    // 0x7b13f4: ldr             lr, [x21, lr, lsl #3]
    // 0x7b13f8: blr             lr
    // 0x7b13fc: add             SP, SP, #0x10
    // 0x7b1400: tbz             w0, #4, #0x7b1410
    // 0x7b1404: ldr             x0, [fp, #0x18]
    // 0x7b1408: ldr             x1, [fp, #0x10]
    // 0x7b140c: b               #0x7b1440
    // 0x7b1410: ldr             x0, [fp, #0x18]
    // 0x7b1414: ldr             x1, [fp, #0x10]
    // 0x7b1418: LoadField: r2 = r0->field_b
    //     0x7b1418: ldur            w2, [x0, #0xb]
    // 0x7b141c: DecompressPointer r2
    //     0x7b141c: add             x2, x2, HEAP, lsl #32
    // 0x7b1420: cmp             w2, NULL
    // 0x7b1424: b.eq            #0x7b16a8
    // 0x7b1428: LoadField: r3 = r2->field_37
    //     0x7b1428: ldur            w3, [x2, #0x37]
    // 0x7b142c: DecompressPointer r3
    //     0x7b142c: add             x3, x3, HEAP, lsl #32
    // 0x7b1430: LoadField: r2 = r1->field_37
    //     0x7b1430: ldur            w2, [x1, #0x37]
    // 0x7b1434: DecompressPointer r2
    //     0x7b1434: add             x2, x2, HEAP, lsl #32
    // 0x7b1438: cmp             w3, w2
    // 0x7b143c: b.eq            #0x7b1514
    // 0x7b1440: LoadField: r2 = r0->field_23
    //     0x7b1440: ldur            w2, [x0, #0x23]
    // 0x7b1444: DecompressPointer r2
    //     0x7b1444: add             x2, x2, HEAP, lsl #32
    // 0x7b1448: stur            x2, [fp, #-8]
    // 0x7b144c: r16 = Instance__HighlightType
    //     0x7b144c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2c8] Obj!_HighlightType@b65851
    //     0x7b1450: ldr             x16, [x16, #0x2c8]
    // 0x7b1454: stp             x16, x2, [SP, #-0x10]!
    // 0x7b1458: r0 = _getValueOrData()
    //     0x7b1458: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7b145c: add             SP, SP, #0x10
    // 0x7b1460: mov             x1, x0
    // 0x7b1464: ldur            x0, [fp, #-8]
    // 0x7b1468: LoadField: r2 = r0->field_f
    //     0x7b1468: ldur            w2, [x0, #0xf]
    // 0x7b146c: DecompressPointer r2
    //     0x7b146c: add             x2, x2, HEAP, lsl #32
    // 0x7b1470: cmp             w2, w1
    // 0x7b1474: b.ne            #0x7b147c
    // 0x7b1478: r1 = Null
    //     0x7b1478: mov             x1, NULL
    // 0x7b147c: cmp             w1, NULL
    // 0x7b1480: b.eq            #0x7b14c4
    // 0x7b1484: ldr             x2, [fp, #0x18]
    // 0x7b1488: SaveReg r1
    //     0x7b1488: str             x1, [SP, #-8]!
    // 0x7b148c: r0 = dispose()
    //     0x7b148c: bl              #0xbfea64  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0x7b1490: add             SP, SP, #8
    // 0x7b1494: ldr             x0, [fp, #0x18]
    // 0x7b1498: LoadField: r1 = r0->field_1f
    //     0x7b1498: ldur            w1, [x0, #0x1f]
    // 0x7b149c: DecompressPointer r1
    //     0x7b149c: add             x1, x1, HEAP, lsl #32
    // 0x7b14a0: r16 = Instance__HighlightType
    //     0x7b14a0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2c8] Obj!_HighlightType@b65851
    //     0x7b14a4: ldr             x16, [x16, #0x2c8]
    // 0x7b14a8: stp             x16, x0, [SP, #-0x10]!
    // 0x7b14ac: r16 = false
    //     0x7b14ac: add             x16, NULL, #0x30  ; false
    // 0x7b14b0: stp             x16, x1, [SP, #-0x10]!
    // 0x7b14b4: r4 = const [0, 0x4, 0x4, 0x3, callOnHover, 0x3, null]
    //     0x7b14b4: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e510] List(7) [0, 0x4, 0x4, 0x3, "callOnHover", 0x3, Null]
    //     0x7b14b8: ldr             x4, [x4, #0x510]
    // 0x7b14bc: r0 = updateHighlight()
    //     0x7b14bc: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x7b14c0: add             SP, SP, #0x20
    // 0x7b14c4: ldur            x0, [fp, #-8]
    // 0x7b14c8: r16 = Instance__HighlightType
    //     0x7b14c8: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e278] Obj!_HighlightType@b65831
    //     0x7b14cc: ldr             x16, [x16, #0x278]
    // 0x7b14d0: stp             x16, x0, [SP, #-0x10]!
    // 0x7b14d4: r0 = _getValueOrData()
    //     0x7b14d4: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7b14d8: add             SP, SP, #0x10
    // 0x7b14dc: mov             x1, x0
    // 0x7b14e0: ldur            x0, [fp, #-8]
    // 0x7b14e4: LoadField: r2 = r0->field_f
    //     0x7b14e4: ldur            w2, [x0, #0xf]
    // 0x7b14e8: DecompressPointer r2
    //     0x7b14e8: add             x2, x2, HEAP, lsl #32
    // 0x7b14ec: cmp             w2, w1
    // 0x7b14f0: b.ne            #0x7b14fc
    // 0x7b14f4: r0 = Null
    //     0x7b14f4: mov             x0, NULL
    // 0x7b14f8: b               #0x7b1500
    // 0x7b14fc: mov             x0, x1
    // 0x7b1500: cmp             w0, NULL
    // 0x7b1504: b.eq            #0x7b1514
    // 0x7b1508: SaveReg r0
    //     0x7b1508: str             x0, [SP, #-8]!
    // 0x7b150c: r0 = dispose()
    //     0x7b150c: bl              #0xbfea64  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0x7b1510: add             SP, SP, #8
    // 0x7b1514: ldr             x0, [fp, #0x10]
    // 0x7b1518: ldr             x16, [fp, #0x18]
    // 0x7b151c: SaveReg r16
    //     0x7b151c: str             x16, [SP, #-8]!
    // 0x7b1520: r0 = enabled()
    //     0x7b1520: bl              #0x7b18d0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0x7b1524: add             SP, SP, #8
    // 0x7b1528: mov             x1, x0
    // 0x7b152c: ldr             x0, [fp, #0x10]
    // 0x7b1530: LoadField: r2 = r0->field_f
    //     0x7b1530: ldur            w2, [x0, #0xf]
    // 0x7b1534: DecompressPointer r2
    //     0x7b1534: add             x2, x2, HEAP, lsl #32
    // 0x7b1538: cmp             w2, NULL
    // 0x7b153c: b.ne            #0x7b1550
    // 0x7b1540: LoadField: r2 = r0->field_23
    //     0x7b1540: ldur            w2, [x0, #0x23]
    // 0x7b1544: DecompressPointer r2
    //     0x7b1544: add             x2, x2, HEAP, lsl #32
    // 0x7b1548: cmp             w2, NULL
    // 0x7b154c: b.eq            #0x7b1558
    // 0x7b1550: r0 = true
    //     0x7b1550: add             x0, NULL, #0x20  ; true
    // 0x7b1554: b               #0x7b155c
    // 0x7b1558: r0 = false
    //     0x7b1558: add             x0, NULL, #0x30  ; false
    // 0x7b155c: cmp             w1, w0
    // 0x7b1560: b.eq            #0x7b166c
    // 0x7b1564: ldr             x0, [fp, #0x18]
    // 0x7b1568: LoadField: r1 = r0->field_b
    //     0x7b1568: ldur            w1, [x0, #0xb]
    // 0x7b156c: DecompressPointer r1
    //     0x7b156c: add             x1, x1, HEAP, lsl #32
    // 0x7b1570: cmp             w1, NULL
    // 0x7b1574: b.eq            #0x7b16ac
    // 0x7b1578: LoadField: r2 = r1->field_7f
    //     0x7b1578: ldur            w2, [x1, #0x7f]
    // 0x7b157c: DecompressPointer r2
    //     0x7b157c: add             x2, x2, HEAP, lsl #32
    // 0x7b1580: cmp             w2, NULL
    // 0x7b1584: b.ne            #0x7b159c
    // 0x7b1588: LoadField: r1 = r0->field_2b
    //     0x7b1588: ldur            w1, [x0, #0x2b]
    // 0x7b158c: DecompressPointer r1
    //     0x7b158c: add             x1, x1, HEAP, lsl #32
    // 0x7b1590: cmp             w1, NULL
    // 0x7b1594: b.eq            #0x7b16b0
    // 0x7b1598: b               #0x7b15a0
    // 0x7b159c: mov             x1, x2
    // 0x7b15a0: stur            x1, [fp, #-8]
    // 0x7b15a4: SaveReg r0
    //     0x7b15a4: str             x0, [SP, #-8]!
    // 0x7b15a8: r0 = enabled()
    //     0x7b15a8: bl              #0x7b18d0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0x7b15ac: add             SP, SP, #8
    // 0x7b15b0: eor             x1, x0, #0x10
    // 0x7b15b4: ldur            x16, [fp, #-8]
    // 0x7b15b8: r30 = Instance_MaterialState
    //     0x7b15b8: add             lr, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b15bc: ldr             lr, [lr, #0x2a0]
    // 0x7b15c0: stp             lr, x16, [SP, #-0x10]!
    // 0x7b15c4: SaveReg r1
    //     0x7b15c4: str             x1, [SP, #-8]!
    // 0x7b15c8: r0 = update()
    //     0x7b15c8: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b15cc: add             SP, SP, #0x18
    // 0x7b15d0: ldr             x16, [fp, #0x18]
    // 0x7b15d4: SaveReg r16
    //     0x7b15d4: str             x16, [SP, #-8]!
    // 0x7b15d8: r0 = enabled()
    //     0x7b15d8: bl              #0x7b18d0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0x7b15dc: add             SP, SP, #8
    // 0x7b15e0: tbz             w0, #4, #0x7b163c
    // 0x7b15e4: ldr             x0, [fp, #0x18]
    // 0x7b15e8: LoadField: r1 = r0->field_b
    //     0x7b15e8: ldur            w1, [x0, #0xb]
    // 0x7b15ec: DecompressPointer r1
    //     0x7b15ec: add             x1, x1, HEAP, lsl #32
    // 0x7b15f0: cmp             w1, NULL
    // 0x7b15f4: b.eq            #0x7b16b4
    // 0x7b15f8: LoadField: r2 = r1->field_7f
    //     0x7b15f8: ldur            w2, [x1, #0x7f]
    // 0x7b15fc: DecompressPointer r2
    //     0x7b15fc: add             x2, x2, HEAP, lsl #32
    // 0x7b1600: cmp             w2, NULL
    // 0x7b1604: b.ne            #0x7b161c
    // 0x7b1608: LoadField: r1 = r0->field_2b
    //     0x7b1608: ldur            w1, [x0, #0x2b]
    // 0x7b160c: DecompressPointer r1
    //     0x7b160c: add             x1, x1, HEAP, lsl #32
    // 0x7b1610: cmp             w1, NULL
    // 0x7b1614: b.eq            #0x7b16b8
    // 0x7b1618: b               #0x7b1620
    // 0x7b161c: mov             x1, x2
    // 0x7b1620: r16 = Instance_MaterialState
    //     0x7b1620: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x7b1624: ldr             x16, [x16, #0xf90]
    // 0x7b1628: stp             x16, x1, [SP, #-0x10]!
    // 0x7b162c: r16 = false
    //     0x7b162c: add             x16, NULL, #0x30  ; false
    // 0x7b1630: SaveReg r16
    //     0x7b1630: str             x16, [SP, #-8]!
    // 0x7b1634: r0 = update()
    //     0x7b1634: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b1638: add             SP, SP, #0x18
    // 0x7b163c: ldr             x0, [fp, #0x18]
    // 0x7b1640: LoadField: r1 = r0->field_1f
    //     0x7b1640: ldur            w1, [x0, #0x1f]
    // 0x7b1644: DecompressPointer r1
    //     0x7b1644: add             x1, x1, HEAP, lsl #32
    // 0x7b1648: r16 = Instance__HighlightType
    //     0x7b1648: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2c8] Obj!_HighlightType@b65851
    //     0x7b164c: ldr             x16, [x16, #0x2c8]
    // 0x7b1650: stp             x16, x0, [SP, #-0x10]!
    // 0x7b1654: r16 = false
    //     0x7b1654: add             x16, NULL, #0x30  ; false
    // 0x7b1658: stp             x16, x1, [SP, #-0x10]!
    // 0x7b165c: r4 = const [0, 0x4, 0x4, 0x3, callOnHover, 0x3, null]
    //     0x7b165c: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e510] List(7) [0, 0x4, 0x4, 0x3, "callOnHover", 0x3, Null]
    //     0x7b1660: ldr             x4, [x4, #0x510]
    // 0x7b1664: r0 = updateHighlight()
    //     0x7b1664: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x7b1668: add             SP, SP, #0x20
    // 0x7b166c: ldr             x16, [fp, #0x18]
    // 0x7b1670: SaveReg r16
    //     0x7b1670: str             x16, [SP, #-8]!
    // 0x7b1674: r0 = updateFocusHighlights()
    //     0x7b1674: bl              #0x7b1718  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateFocusHighlights
    // 0x7b1678: add             SP, SP, #8
    // 0x7b167c: r0 = Null
    //     0x7b167c: mov             x0, NULL
    // 0x7b1680: LeaveFrame
    //     0x7b1680: mov             SP, fp
    //     0x7b1684: ldp             fp, lr, [SP], #0x10
    // 0x7b1688: ret
    //     0x7b1688: ret             
    // 0x7b168c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b168c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b1690: b               #0x7b11cc
    // 0x7b1694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b1698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1698: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b169c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b169c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b16b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b16b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ statesController(/* No info */) {
    // ** addr: 0x7b16bc, size: 0x5c
    // 0x7b16bc: EnterFrame
    //     0x7b16bc: stp             fp, lr, [SP, #-0x10]!
    //     0x7b16c0: mov             fp, SP
    // 0x7b16c4: ldr             x1, [fp, #0x10]
    // 0x7b16c8: LoadField: r2 = r1->field_b
    //     0x7b16c8: ldur            w2, [x1, #0xb]
    // 0x7b16cc: DecompressPointer r2
    //     0x7b16cc: add             x2, x2, HEAP, lsl #32
    // 0x7b16d0: cmp             w2, NULL
    // 0x7b16d4: b.eq            #0x7b1710
    // 0x7b16d8: LoadField: r3 = r2->field_7f
    //     0x7b16d8: ldur            w3, [x2, #0x7f]
    // 0x7b16dc: DecompressPointer r3
    //     0x7b16dc: add             x3, x3, HEAP, lsl #32
    // 0x7b16e0: cmp             w3, NULL
    // 0x7b16e4: b.ne            #0x7b1700
    // 0x7b16e8: LoadField: r2 = r1->field_2b
    //     0x7b16e8: ldur            w2, [x1, #0x2b]
    // 0x7b16ec: DecompressPointer r2
    //     0x7b16ec: add             x2, x2, HEAP, lsl #32
    // 0x7b16f0: cmp             w2, NULL
    // 0x7b16f4: b.eq            #0x7b1714
    // 0x7b16f8: mov             x0, x2
    // 0x7b16fc: b               #0x7b1704
    // 0x7b1700: mov             x0, x3
    // 0x7b1704: LeaveFrame
    //     0x7b1704: mov             SP, fp
    //     0x7b1708: ldp             fp, lr, [SP], #0x10
    // 0x7b170c: ret
    //     0x7b170c: ret             
    // 0x7b1710: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1710: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b1714: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1714: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateFocusHighlights(/* No info */) {
    // ** addr: 0x7b1718, size: 0x90
    // 0x7b1718: EnterFrame
    //     0x7b1718: stp             fp, lr, [SP, #-0x10]!
    //     0x7b171c: mov             fp, SP
    // 0x7b1720: CheckStackOverflow
    //     0x7b1720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b1724: cmp             SP, x16
    //     0x7b1728: b.ls            #0x7b17a0
    // 0x7b172c: r0 = instance()
    //     0x7b172c: bl              #0x7b188c  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::instance
    // 0x7b1730: LoadField: r1 = r0->field_27
    //     0x7b1730: ldur            w1, [x0, #0x27]
    // 0x7b1734: DecompressPointer r1
    //     0x7b1734: add             x1, x1, HEAP, lsl #32
    // 0x7b1738: cmp             w1, NULL
    // 0x7b173c: b.ne            #0x7b1748
    // 0x7b1740: r0 = _defaultModeForPlatform()
    //     0x7b1740: bl              #0x5ba090  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::_defaultModeForPlatform
    // 0x7b1744: b               #0x7b174c
    // 0x7b1748: mov             x0, x1
    // 0x7b174c: LoadField: r1 = r0->field_7
    //     0x7b174c: ldur            x1, [x0, #7]
    // 0x7b1750: cmp             x1, #0
    // 0x7b1754: b.gt            #0x7b1760
    // 0x7b1758: r0 = false
    //     0x7b1758: add             x0, NULL, #0x30  ; false
    // 0x7b175c: b               #0x7b1770
    // 0x7b1760: ldr             x16, [fp, #0x10]
    // 0x7b1764: SaveReg r16
    //     0x7b1764: str             x16, [SP, #-8]!
    // 0x7b1768: r0 = _shouldShowFocus()
    //     0x7b1768: bl              #0x7b17a8  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_shouldShowFocus
    // 0x7b176c: add             SP, SP, #8
    // 0x7b1770: ldr             x16, [fp, #0x10]
    // 0x7b1774: r30 = Instance__HighlightType
    //     0x7b1774: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e278] Obj!_HighlightType@b65831
    //     0x7b1778: ldr             lr, [lr, #0x278]
    // 0x7b177c: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1780: SaveReg r0
    //     0x7b1780: str             x0, [SP, #-8]!
    // 0x7b1784: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7b1784: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7b1788: r0 = updateHighlight()
    //     0x7b1788: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x7b178c: add             SP, SP, #0x18
    // 0x7b1790: r0 = Null
    //     0x7b1790: mov             x0, NULL
    // 0x7b1794: LeaveFrame
    //     0x7b1794: mov             SP, fp
    //     0x7b1798: ldp             fp, lr, [SP], #0x10
    // 0x7b179c: ret
    //     0x7b179c: ret             
    // 0x7b17a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b17a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b17a4: b               #0x7b172c
  }
  get _ _shouldShowFocus(/* No info */) {
    // ** addr: 0x7b17a8, size: 0xe4
    // 0x7b17a8: EnterFrame
    //     0x7b17a8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b17ac: mov             fp, SP
    // 0x7b17b0: CheckStackOverflow
    //     0x7b17b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b17b4: cmp             SP, x16
    //     0x7b17b8: b.ls            #0x7b187c
    // 0x7b17bc: ldr             x0, [fp, #0x10]
    // 0x7b17c0: LoadField: r1 = r0->field_f
    //     0x7b17c0: ldur            w1, [x0, #0xf]
    // 0x7b17c4: DecompressPointer r1
    //     0x7b17c4: add             x1, x1, HEAP, lsl #32
    // 0x7b17c8: cmp             w1, NULL
    // 0x7b17cc: b.eq            #0x7b1884
    // 0x7b17d0: SaveReg r1
    //     0x7b17d0: str             x1, [SP, #-8]!
    // 0x7b17d4: r0 = maybeOf()
    //     0x7b17d4: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x7b17d8: add             SP, SP, #8
    // 0x7b17dc: cmp             w0, NULL
    // 0x7b17e0: b.ne            #0x7b17ec
    // 0x7b17e4: r1 = Null
    //     0x7b17e4: mov             x1, NULL
    // 0x7b17e8: b               #0x7b17f4
    // 0x7b17ec: r1 = Instance_NavigationMode
    //     0x7b17ec: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x7b17f0: ldr             x1, [x1, #0x4f0]
    // 0x7b17f4: cmp             w1, NULL
    // 0x7b17f8: b.ne            #0x7b1804
    // 0x7b17fc: r1 = Instance_NavigationMode
    //     0x7b17fc: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x7b1800: ldr             x1, [x1, #0x4f0]
    // 0x7b1804: LoadField: r2 = r1->field_7
    //     0x7b1804: ldur            x2, [x1, #7]
    // 0x7b1808: cmp             x2, #0
    // 0x7b180c: b.gt            #0x7b1864
    // 0x7b1810: ldr             x1, [fp, #0x10]
    // 0x7b1814: LoadField: r2 = r1->field_b
    //     0x7b1814: ldur            w2, [x1, #0xb]
    // 0x7b1818: DecompressPointer r2
    //     0x7b1818: add             x2, x2, HEAP, lsl #32
    // 0x7b181c: cmp             w2, NULL
    // 0x7b1820: b.eq            #0x7b1888
    // 0x7b1824: LoadField: r3 = r2->field_f
    //     0x7b1824: ldur            w3, [x2, #0xf]
    // 0x7b1828: DecompressPointer r3
    //     0x7b1828: add             x3, x3, HEAP, lsl #32
    // 0x7b182c: cmp             w3, NULL
    // 0x7b1830: b.ne            #0x7b1844
    // 0x7b1834: LoadField: r3 = r2->field_23
    //     0x7b1834: ldur            w3, [x2, #0x23]
    // 0x7b1838: DecompressPointer r3
    //     0x7b1838: add             x3, x3, HEAP, lsl #32
    // 0x7b183c: cmp             w3, NULL
    // 0x7b1840: b.eq            #0x7b1854
    // 0x7b1844: LoadField: r2 = r1->field_33
    //     0x7b1844: ldur            w2, [x1, #0x33]
    // 0x7b1848: DecompressPointer r2
    //     0x7b1848: add             x2, x2, HEAP, lsl #32
    // 0x7b184c: mov             x0, x2
    // 0x7b1850: b               #0x7b1858
    // 0x7b1854: r0 = false
    //     0x7b1854: add             x0, NULL, #0x30  ; false
    // 0x7b1858: LeaveFrame
    //     0x7b1858: mov             SP, fp
    //     0x7b185c: ldp             fp, lr, [SP], #0x10
    // 0x7b1860: ret
    //     0x7b1860: ret             
    // 0x7b1864: ldr             x1, [fp, #0x10]
    // 0x7b1868: LoadField: r0 = r1->field_33
    //     0x7b1868: ldur            w0, [x1, #0x33]
    // 0x7b186c: DecompressPointer r0
    //     0x7b186c: add             x0, x0, HEAP, lsl #32
    // 0x7b1870: LeaveFrame
    //     0x7b1870: mov             SP, fp
    //     0x7b1874: ldp             fp, lr, [SP], #0x10
    // 0x7b1878: ret
    //     0x7b1878: ret             
    // 0x7b187c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b187c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b1880: b               #0x7b17bc
    // 0x7b1884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1884: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b1888: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1888: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ enabled(/* No info */) {
    // ** addr: 0x7b18d0, size: 0x58
    // 0x7b18d0: EnterFrame
    //     0x7b18d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7b18d4: mov             fp, SP
    // 0x7b18d8: ldr             x1, [fp, #0x10]
    // 0x7b18dc: LoadField: r2 = r1->field_b
    //     0x7b18dc: ldur            w2, [x1, #0xb]
    // 0x7b18e0: DecompressPointer r2
    //     0x7b18e0: add             x2, x2, HEAP, lsl #32
    // 0x7b18e4: cmp             w2, NULL
    // 0x7b18e8: b.eq            #0x7b1924
    // 0x7b18ec: LoadField: r1 = r2->field_f
    //     0x7b18ec: ldur            w1, [x2, #0xf]
    // 0x7b18f0: DecompressPointer r1
    //     0x7b18f0: add             x1, x1, HEAP, lsl #32
    // 0x7b18f4: cmp             w1, NULL
    // 0x7b18f8: b.ne            #0x7b190c
    // 0x7b18fc: LoadField: r1 = r2->field_23
    //     0x7b18fc: ldur            w1, [x2, #0x23]
    // 0x7b1900: DecompressPointer r1
    //     0x7b1900: add             x1, x1, HEAP, lsl #32
    // 0x7b1904: cmp             w1, NULL
    // 0x7b1908: b.eq            #0x7b1914
    // 0x7b190c: r0 = true
    //     0x7b190c: add             x0, NULL, #0x20  ; true
    // 0x7b1910: b               #0x7b1918
    // 0x7b1914: r0 = false
    //     0x7b1914: add             x0, NULL, #0x30  ; false
    // 0x7b1918: LeaveFrame
    //     0x7b1918: mov             SP, fp
    //     0x7b191c: ldp             fp, lr, [SP], #0x10
    // 0x7b1920: ret
    //     0x7b1920: ret             
    // 0x7b1924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1924: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ updateHighlight(/* No info */) {
    // ** addr: 0x7b1928, size: 0x758
    // 0x7b1928: EnterFrame
    //     0x7b1928: stp             fp, lr, [SP, #-0x10]!
    //     0x7b192c: mov             fp, SP
    // 0x7b1930: AllocStack(0x98)
    //     0x7b1930: sub             SP, SP, #0x98
    // 0x7b1934: SetupParameters(_InkResponseState<_InkResponseStateWidget> this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5, fp-0x10 */, {dynamic callOnHover = true /* r0, fp-0x8 */})
    //     0x7b1934: mov             x0, x4
    //     0x7b1938: ldur            w1, [x0, #0x13]
    //     0x7b193c: add             x1, x1, HEAP, lsl #32
    //     0x7b1940: sub             x2, x1, #6
    //     0x7b1944: add             x3, fp, w2, sxtw #2
    //     0x7b1948: ldr             x3, [x3, #0x20]
    //     0x7b194c: stur            x3, [fp, #-0x20]
    //     0x7b1950: add             x4, fp, w2, sxtw #2
    //     0x7b1954: ldr             x4, [x4, #0x18]
    //     0x7b1958: stur            x4, [fp, #-0x18]
    //     0x7b195c: add             x5, fp, w2, sxtw #2
    //     0x7b1960: ldr             x5, [x5, #0x10]
    //     0x7b1964: stur            x5, [fp, #-0x10]
    //     0x7b1968: ldur            w2, [x0, #0x1f]
    //     0x7b196c: add             x2, x2, HEAP, lsl #32
    //     0x7b1970: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e280] "callOnHover"
    //     0x7b1974: ldr             x16, [x16, #0x280]
    //     0x7b1978: cmp             w2, w16
    //     0x7b197c: b.ne            #0x7b199c
    //     0x7b1980: ldur            w2, [x0, #0x23]
    //     0x7b1984: add             x2, x2, HEAP, lsl #32
    //     0x7b1988: sub             w0, w1, w2
    //     0x7b198c: add             x1, fp, w0, sxtw #2
    //     0x7b1990: ldr             x1, [x1, #8]
    //     0x7b1994: mov             x0, x1
    //     0x7b1998: b               #0x7b19a0
    //     0x7b199c: add             x0, NULL, #0x20  ; true
    //     0x7b19a0: stur            x0, [fp, #-8]
    // 0x7b19a4: CheckStackOverflow
    //     0x7b19a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b19a8: cmp             SP, x16
    //     0x7b19ac: b.ls            #0x7b2028
    // 0x7b19b0: r1 = 2
    //     0x7b19b0: mov             x1, #2
    // 0x7b19b4: r0 = AllocateContext()
    //     0x7b19b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b19b8: mov             x1, x0
    // 0x7b19bc: ldur            x0, [fp, #-0x20]
    // 0x7b19c0: stur            x1, [fp, #-0x30]
    // 0x7b19c4: StoreField: r1->field_f = r0
    //     0x7b19c4: stur            w0, [x1, #0xf]
    // 0x7b19c8: ldur            x2, [fp, #-0x18]
    // 0x7b19cc: StoreField: r1->field_13 = r2
    //     0x7b19cc: stur            w2, [x1, #0x13]
    // 0x7b19d0: LoadField: r3 = r0->field_23
    //     0x7b19d0: ldur            w3, [x0, #0x23]
    // 0x7b19d4: DecompressPointer r3
    //     0x7b19d4: add             x3, x3, HEAP, lsl #32
    // 0x7b19d8: stur            x3, [fp, #-0x28]
    // 0x7b19dc: stp             x2, x3, [SP, #-0x10]!
    // 0x7b19e0: r0 = _getValueOrData()
    //     0x7b19e0: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x7b19e4: add             SP, SP, #0x10
    // 0x7b19e8: mov             x1, x0
    // 0x7b19ec: ldur            x0, [fp, #-0x28]
    // 0x7b19f0: LoadField: r2 = r0->field_f
    //     0x7b19f0: ldur            w2, [x0, #0xf]
    // 0x7b19f4: DecompressPointer r2
    //     0x7b19f4: add             x2, x2, HEAP, lsl #32
    // 0x7b19f8: cmp             w2, w1
    // 0x7b19fc: b.ne            #0x7b1a04
    // 0x7b1a00: r1 = Null
    //     0x7b1a00: mov             x1, NULL
    // 0x7b1a04: ldur            x2, [fp, #-0x30]
    // 0x7b1a08: stur            x1, [fp, #-0x18]
    // 0x7b1a0c: LoadField: r3 = r2->field_13
    //     0x7b1a0c: ldur            w3, [x2, #0x13]
    // 0x7b1a10: DecompressPointer r3
    //     0x7b1a10: add             x3, x3, HEAP, lsl #32
    // 0x7b1a14: cmp             w3, NULL
    // 0x7b1a18: b.eq            #0x7b1aec
    // 0x7b1a1c: LoadField: r4 = r3->field_7
    //     0x7b1a1c: ldur            x4, [x3, #7]
    // 0x7b1a20: cmp             x4, #1
    // 0x7b1a24: b.gt            #0x7b1aec
    // 0x7b1a28: cmp             x4, #0
    // 0x7b1a2c: b.gt            #0x7b1a8c
    // 0x7b1a30: ldur            x3, [fp, #-0x20]
    // 0x7b1a34: LoadField: r4 = r3->field_b
    //     0x7b1a34: ldur            w4, [x3, #0xb]
    // 0x7b1a38: DecompressPointer r4
    //     0x7b1a38: add             x4, x4, HEAP, lsl #32
    // 0x7b1a3c: cmp             w4, NULL
    // 0x7b1a40: b.eq            #0x7b2030
    // 0x7b1a44: LoadField: r5 = r4->field_7f
    //     0x7b1a44: ldur            w5, [x4, #0x7f]
    // 0x7b1a48: DecompressPointer r5
    //     0x7b1a48: add             x5, x5, HEAP, lsl #32
    // 0x7b1a4c: cmp             w5, NULL
    // 0x7b1a50: b.ne            #0x7b1a68
    // 0x7b1a54: LoadField: r4 = r3->field_2b
    //     0x7b1a54: ldur            w4, [x3, #0x2b]
    // 0x7b1a58: DecompressPointer r4
    //     0x7b1a58: add             x4, x4, HEAP, lsl #32
    // 0x7b1a5c: cmp             w4, NULL
    // 0x7b1a60: b.eq            #0x7b2034
    // 0x7b1a64: b               #0x7b1a6c
    // 0x7b1a68: mov             x4, x5
    // 0x7b1a6c: r16 = Instance_MaterialState
    //     0x7b1a6c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x7b1a70: ldr             x16, [x16, #0xf90]
    // 0x7b1a74: stp             x16, x4, [SP, #-0x10]!
    // 0x7b1a78: ldur            x16, [fp, #-0x10]
    // 0x7b1a7c: SaveReg r16
    //     0x7b1a7c: str             x16, [SP, #-8]!
    // 0x7b1a80: r0 = update()
    //     0x7b1a80: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b1a84: add             SP, SP, #0x18
    // 0x7b1a88: b               #0x7b1aec
    // 0x7b1a8c: ldur            x0, [fp, #-8]
    // 0x7b1a90: tbnz            w0, #4, #0x7b1aec
    // 0x7b1a94: ldur            x1, [fp, #-0x20]
    // 0x7b1a98: LoadField: r2 = r1->field_b
    //     0x7b1a98: ldur            w2, [x1, #0xb]
    // 0x7b1a9c: DecompressPointer r2
    //     0x7b1a9c: add             x2, x2, HEAP, lsl #32
    // 0x7b1aa0: cmp             w2, NULL
    // 0x7b1aa4: b.eq            #0x7b2038
    // 0x7b1aa8: LoadField: r3 = r2->field_7f
    //     0x7b1aa8: ldur            w3, [x2, #0x7f]
    // 0x7b1aac: DecompressPointer r3
    //     0x7b1aac: add             x3, x3, HEAP, lsl #32
    // 0x7b1ab0: cmp             w3, NULL
    // 0x7b1ab4: b.ne            #0x7b1acc
    // 0x7b1ab8: LoadField: r2 = r1->field_2b
    //     0x7b1ab8: ldur            w2, [x1, #0x2b]
    // 0x7b1abc: DecompressPointer r2
    //     0x7b1abc: add             x2, x2, HEAP, lsl #32
    // 0x7b1ac0: cmp             w2, NULL
    // 0x7b1ac4: b.eq            #0x7b203c
    // 0x7b1ac8: b               #0x7b1ad0
    // 0x7b1acc: mov             x2, x3
    // 0x7b1ad0: r16 = Instance_MaterialState
    //     0x7b1ad0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x7b1ad4: ldr             x16, [x16, #0xf78]
    // 0x7b1ad8: stp             x16, x2, [SP, #-0x10]!
    // 0x7b1adc: ldur            x16, [fp, #-0x10]
    // 0x7b1ae0: SaveReg r16
    //     0x7b1ae0: str             x16, [SP, #-8]!
    // 0x7b1ae4: r0 = update()
    //     0x7b1ae4: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b1ae8: add             SP, SP, #0x18
    // 0x7b1aec: ldur            x2, [fp, #-0x30]
    // 0x7b1af0: LoadField: r0 = r2->field_13
    //     0x7b1af0: ldur            w0, [x2, #0x13]
    // 0x7b1af4: DecompressPointer r0
    //     0x7b1af4: add             x0, x0, HEAP, lsl #32
    // 0x7b1af8: r16 = Instance__HighlightType
    //     0x7b1af8: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e288] Obj!_HighlightType@b65811
    //     0x7b1afc: ldr             x16, [x16, #0x288]
    // 0x7b1b00: cmp             w0, w16
    // 0x7b1b04: b.ne            #0x7b1b40
    // 0x7b1b08: ldur            x0, [fp, #-0x20]
    // 0x7b1b0c: LoadField: r1 = r0->field_b
    //     0x7b1b0c: ldur            w1, [x0, #0xb]
    // 0x7b1b10: DecompressPointer r1
    //     0x7b1b10: add             x1, x1, HEAP, lsl #32
    // 0x7b1b14: cmp             w1, NULL
    // 0x7b1b18: b.eq            #0x7b2040
    // 0x7b1b1c: LoadField: r3 = r1->field_77
    //     0x7b1b1c: ldur            w3, [x1, #0x77]
    // 0x7b1b20: DecompressPointer r3
    //     0x7b1b20: add             x3, x3, HEAP, lsl #32
    // 0x7b1b24: cmp             w3, NULL
    // 0x7b1b28: b.eq            #0x7b1b40
    // 0x7b1b2c: stp             x0, x3, [SP, #-0x10]!
    // 0x7b1b30: ldur            x16, [fp, #-0x10]
    // 0x7b1b34: SaveReg r16
    //     0x7b1b34: str             x16, [SP, #-8]!
    // 0x7b1b38: r0 = markChildInkResponsePressed()
    //     0x7b1b38: bl              #0x7959fc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::markChildInkResponsePressed
    // 0x7b1b3c: add             SP, SP, #0x18
    // 0x7b1b40: ldur            x0, [fp, #-0x18]
    // 0x7b1b44: cmp             w0, NULL
    // 0x7b1b48: b.eq            #0x7b1b5c
    // 0x7b1b4c: LoadField: r1 = r0->field_37
    //     0x7b1b4c: ldur            w1, [x0, #0x37]
    // 0x7b1b50: DecompressPointer r1
    //     0x7b1b50: add             x1, x1, HEAP, lsl #32
    // 0x7b1b54: mov             x2, x1
    // 0x7b1b58: b               #0x7b1b60
    // 0x7b1b5c: r2 = false
    //     0x7b1b5c: add             x2, NULL, #0x30  ; false
    // 0x7b1b60: ldur            x1, [fp, #-0x10]
    // 0x7b1b64: cmp             w1, w2
    // 0x7b1b68: b.ne            #0x7b1b7c
    // 0x7b1b6c: r0 = Null
    //     0x7b1b6c: mov             x0, NULL
    // 0x7b1b70: LeaveFrame
    //     0x7b1b70: mov             SP, fp
    //     0x7b1b74: ldp             fp, lr, [SP], #0x10
    // 0x7b1b78: ret
    //     0x7b1b78: ret             
    // 0x7b1b7c: tbnz            w1, #4, #0x7b1f58
    // 0x7b1b80: cmp             w0, NULL
    // 0x7b1b84: b.ne            #0x7b1f48
    // 0x7b1b88: ldur            x2, [fp, #-0x20]
    // 0x7b1b8c: LoadField: r0 = r2->field_b
    //     0x7b1b8c: ldur            w0, [x2, #0xb]
    // 0x7b1b90: DecompressPointer r0
    //     0x7b1b90: add             x0, x0, HEAP, lsl #32
    // 0x7b1b94: cmp             w0, NULL
    // 0x7b1b98: b.eq            #0x7b2044
    // 0x7b1b9c: LoadField: r3 = r0->field_53
    //     0x7b1b9c: ldur            w3, [x0, #0x53]
    // 0x7b1ba0: DecompressPointer r3
    //     0x7b1ba0: add             x3, x3, HEAP, lsl #32
    // 0x7b1ba4: cmp             w3, NULL
    // 0x7b1ba8: b.ne            #0x7b1bb4
    // 0x7b1bac: r0 = Null
    //     0x7b1bac: mov             x0, NULL
    // 0x7b1bb0: b               #0x7b1c08
    // 0x7b1bb4: LoadField: r4 = r0->field_7f
    //     0x7b1bb4: ldur            w4, [x0, #0x7f]
    // 0x7b1bb8: DecompressPointer r4
    //     0x7b1bb8: add             x4, x4, HEAP, lsl #32
    // 0x7b1bbc: cmp             w4, NULL
    // 0x7b1bc0: b.ne            #0x7b1bd8
    // 0x7b1bc4: LoadField: r0 = r2->field_2b
    //     0x7b1bc4: ldur            w0, [x2, #0x2b]
    // 0x7b1bc8: DecompressPointer r0
    //     0x7b1bc8: add             x0, x0, HEAP, lsl #32
    // 0x7b1bcc: cmp             w0, NULL
    // 0x7b1bd0: b.eq            #0x7b2048
    // 0x7b1bd4: b               #0x7b1bdc
    // 0x7b1bd8: mov             x0, x4
    // 0x7b1bdc: LoadField: r4 = r0->field_27
    //     0x7b1bdc: ldur            w4, [x0, #0x27]
    // 0x7b1be0: DecompressPointer r4
    //     0x7b1be0: add             x4, x4, HEAP, lsl #32
    // 0x7b1be4: r0 = LoadClassIdInstr(r3)
    //     0x7b1be4: ldur            x0, [x3, #-1]
    //     0x7b1be8: ubfx            x0, x0, #0xc, #0x14
    // 0x7b1bec: stp             x4, x3, [SP, #-0x10]!
    // 0x7b1bf0: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x7b1bf0: mov             x17, #0x5e7
    //     0x7b1bf4: movk            x17, #1, lsl #16
    //     0x7b1bf8: add             lr, x0, x17
    //     0x7b1bfc: ldr             lr, [x21, lr, lsl #3]
    //     0x7b1c00: blr             lr
    // 0x7b1c04: add             SP, SP, #0x10
    // 0x7b1c08: stur            x0, [fp, #-0x38]
    // 0x7b1c0c: cmp             w0, NULL
    // 0x7b1c10: b.ne            #0x7b1d20
    // 0x7b1c14: ldur            x1, [fp, #-0x20]
    // 0x7b1c18: ldur            x2, [fp, #-0x30]
    // 0x7b1c1c: LoadField: r3 = r1->field_f
    //     0x7b1c1c: ldur            w3, [x1, #0xf]
    // 0x7b1c20: DecompressPointer r3
    //     0x7b1c20: add             x3, x3, HEAP, lsl #32
    // 0x7b1c24: cmp             w3, NULL
    // 0x7b1c28: b.eq            #0x7b204c
    // 0x7b1c2c: SaveReg r3
    //     0x7b1c2c: str             x3, [SP, #-8]!
    // 0x7b1c30: r0 = of()
    //     0x7b1c30: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x7b1c34: add             SP, SP, #8
    // 0x7b1c38: ldur            x2, [fp, #-0x30]
    // 0x7b1c3c: LoadField: r1 = r2->field_13
    //     0x7b1c3c: ldur            w1, [x2, #0x13]
    // 0x7b1c40: DecompressPointer r1
    //     0x7b1c40: add             x1, x1, HEAP, lsl #32
    // 0x7b1c44: cmp             w1, NULL
    // 0x7b1c48: b.eq            #0x7b1d14
    // 0x7b1c4c: LoadField: r3 = r1->field_7
    //     0x7b1c4c: ldur            x3, [x1, #7]
    // 0x7b1c50: cmp             x3, #1
    // 0x7b1c54: b.gt            #0x7b1cd8
    // 0x7b1c58: cmp             x3, #0
    // 0x7b1c5c: b.gt            #0x7b1c9c
    // 0x7b1c60: ldur            x1, [fp, #-0x20]
    // 0x7b1c64: LoadField: r3 = r1->field_b
    //     0x7b1c64: ldur            w3, [x1, #0xb]
    // 0x7b1c68: DecompressPointer r3
    //     0x7b1c68: add             x3, x3, HEAP, lsl #32
    // 0x7b1c6c: cmp             w3, NULL
    // 0x7b1c70: b.eq            #0x7b2050
    // 0x7b1c74: LoadField: r4 = r3->field_4f
    //     0x7b1c74: ldur            w4, [x3, #0x4f]
    // 0x7b1c78: DecompressPointer r4
    //     0x7b1c78: add             x4, x4, HEAP, lsl #32
    // 0x7b1c7c: cmp             w4, NULL
    // 0x7b1c80: b.ne            #0x7b1c94
    // 0x7b1c84: LoadField: r3 = r0->field_53
    //     0x7b1c84: ldur            w3, [x0, #0x53]
    // 0x7b1c88: DecompressPointer r3
    //     0x7b1c88: add             x3, x3, HEAP, lsl #32
    // 0x7b1c8c: mov             x0, x3
    // 0x7b1c90: b               #0x7b1d2c
    // 0x7b1c94: mov             x0, x4
    // 0x7b1c98: b               #0x7b1d2c
    // 0x7b1c9c: ldur            x1, [fp, #-0x20]
    // 0x7b1ca0: LoadField: r3 = r1->field_b
    //     0x7b1ca0: ldur            w3, [x1, #0xb]
    // 0x7b1ca4: DecompressPointer r3
    //     0x7b1ca4: add             x3, x3, HEAP, lsl #32
    // 0x7b1ca8: cmp             w3, NULL
    // 0x7b1cac: b.eq            #0x7b2054
    // 0x7b1cb0: LoadField: r4 = r3->field_4b
    //     0x7b1cb0: ldur            w4, [x3, #0x4b]
    // 0x7b1cb4: DecompressPointer r4
    //     0x7b1cb4: add             x4, x4, HEAP, lsl #32
    // 0x7b1cb8: cmp             w4, NULL
    // 0x7b1cbc: b.ne            #0x7b1cd0
    // 0x7b1cc0: LoadField: r3 = r0->field_5b
    //     0x7b1cc0: ldur            w3, [x0, #0x5b]
    // 0x7b1cc4: DecompressPointer r3
    //     0x7b1cc4: add             x3, x3, HEAP, lsl #32
    // 0x7b1cc8: mov             x0, x3
    // 0x7b1ccc: b               #0x7b1d2c
    // 0x7b1cd0: mov             x0, x4
    // 0x7b1cd4: b               #0x7b1d2c
    // 0x7b1cd8: ldur            x1, [fp, #-0x20]
    // 0x7b1cdc: LoadField: r3 = r1->field_b
    //     0x7b1cdc: ldur            w3, [x1, #0xb]
    // 0x7b1ce0: DecompressPointer r3
    //     0x7b1ce0: add             x3, x3, HEAP, lsl #32
    // 0x7b1ce4: cmp             w3, NULL
    // 0x7b1ce8: b.eq            #0x7b2058
    // 0x7b1cec: LoadField: r4 = r3->field_47
    //     0x7b1cec: ldur            w4, [x3, #0x47]
    // 0x7b1cf0: DecompressPointer r4
    //     0x7b1cf0: add             x4, x4, HEAP, lsl #32
    // 0x7b1cf4: cmp             w4, NULL
    // 0x7b1cf8: b.ne            #0x7b1d0c
    // 0x7b1cfc: LoadField: r3 = r0->field_4f
    //     0x7b1cfc: ldur            w3, [x0, #0x4f]
    // 0x7b1d00: DecompressPointer r3
    //     0x7b1d00: add             x3, x3, HEAP, lsl #32
    // 0x7b1d04: mov             x0, x3
    // 0x7b1d08: b               #0x7b1d2c
    // 0x7b1d0c: mov             x0, x4
    // 0x7b1d10: b               #0x7b1d2c
    // 0x7b1d14: ldur            x1, [fp, #-0x20]
    // 0x7b1d18: ldur            x0, [fp, #-0x38]
    // 0x7b1d1c: b               #0x7b1d2c
    // 0x7b1d20: ldur            x1, [fp, #-0x20]
    // 0x7b1d24: ldur            x2, [fp, #-0x30]
    // 0x7b1d28: ldur            x0, [fp, #-0x38]
    // 0x7b1d2c: stur            x0, [fp, #-0x38]
    // 0x7b1d30: LoadField: r3 = r1->field_f
    //     0x7b1d30: ldur            w3, [x1, #0xf]
    // 0x7b1d34: DecompressPointer r3
    //     0x7b1d34: add             x3, x3, HEAP, lsl #32
    // 0x7b1d38: cmp             w3, NULL
    // 0x7b1d3c: b.eq            #0x7b205c
    // 0x7b1d40: SaveReg r3
    //     0x7b1d40: str             x3, [SP, #-8]!
    // 0x7b1d44: r0 = findRenderObject()
    //     0x7b1d44: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x7b1d48: add             SP, SP, #8
    // 0x7b1d4c: mov             x3, x0
    // 0x7b1d50: stur            x3, [fp, #-0x40]
    // 0x7b1d54: cmp             w3, NULL
    // 0x7b1d58: b.eq            #0x7b2060
    // 0x7b1d5c: mov             x0, x3
    // 0x7b1d60: r2 = Null
    //     0x7b1d60: mov             x2, NULL
    // 0x7b1d64: r1 = Null
    //     0x7b1d64: mov             x1, NULL
    // 0x7b1d68: r4 = LoadClassIdInstr(r0)
    //     0x7b1d68: ldur            x4, [x0, #-1]
    //     0x7b1d6c: ubfx            x4, x4, #0xc, #0x14
    // 0x7b1d70: sub             x4, x4, #0x965
    // 0x7b1d74: cmp             x4, #0x8b
    // 0x7b1d78: b.ls            #0x7b1d90
    // 0x7b1d7c: r8 = RenderBox
    //     0x7b1d7c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x7b1d80: ldr             x8, [x8, #0xfa0]
    // 0x7b1d84: r3 = Null
    //     0x7b1d84: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e290] Null
    //     0x7b1d88: ldr             x3, [x3, #0x290]
    // 0x7b1d8c: r0 = RenderBox()
    //     0x7b1d8c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x7b1d90: ldur            x2, [fp, #-0x30]
    // 0x7b1d94: LoadField: r0 = r2->field_13
    //     0x7b1d94: ldur            w0, [x2, #0x13]
    // 0x7b1d98: DecompressPointer r0
    //     0x7b1d98: add             x0, x0, HEAP, lsl #32
    // 0x7b1d9c: ldur            x1, [fp, #-0x20]
    // 0x7b1da0: stur            x0, [fp, #-0x48]
    // 0x7b1da4: LoadField: r3 = r1->field_f
    //     0x7b1da4: ldur            w3, [x1, #0xf]
    // 0x7b1da8: DecompressPointer r3
    //     0x7b1da8: add             x3, x3, HEAP, lsl #32
    // 0x7b1dac: cmp             w3, NULL
    // 0x7b1db0: b.eq            #0x7b2064
    // 0x7b1db4: SaveReg r3
    //     0x7b1db4: str             x3, [SP, #-8]!
    // 0x7b1db8: r0 = of()
    //     0x7b1db8: bl              #0x7b2858  ; [package:flutter/src/material/material.dart] Material::of
    // 0x7b1dbc: add             SP, SP, #8
    // 0x7b1dc0: mov             x2, x0
    // 0x7b1dc4: ldur            x1, [fp, #-0x20]
    // 0x7b1dc8: stur            x2, [fp, #-0x70]
    // 0x7b1dcc: LoadField: r0 = r1->field_b
    //     0x7b1dcc: ldur            w0, [x1, #0xb]
    // 0x7b1dd0: DecompressPointer r0
    //     0x7b1dd0: add             x0, x0, HEAP, lsl #32
    // 0x7b1dd4: cmp             w0, NULL
    // 0x7b1dd8: b.eq            #0x7b2068
    // 0x7b1ddc: LoadField: r3 = r0->field_37
    //     0x7b1ddc: ldur            w3, [x0, #0x37]
    // 0x7b1de0: DecompressPointer r3
    //     0x7b1de0: add             x3, x3, HEAP, lsl #32
    // 0x7b1de4: stur            x3, [fp, #-0x68]
    // 0x7b1de8: LoadField: r4 = r0->field_3b
    //     0x7b1de8: ldur            w4, [x0, #0x3b]
    // 0x7b1dec: DecompressPointer r4
    //     0x7b1dec: add             x4, x4, HEAP, lsl #32
    // 0x7b1df0: stur            x4, [fp, #-0x60]
    // 0x7b1df4: LoadField: r5 = r0->field_3f
    //     0x7b1df4: ldur            w5, [x0, #0x3f]
    // 0x7b1df8: DecompressPointer r5
    //     0x7b1df8: add             x5, x5, HEAP, lsl #32
    // 0x7b1dfc: stur            x5, [fp, #-0x58]
    // 0x7b1e00: LoadField: r6 = r0->field_43
    //     0x7b1e00: ldur            w6, [x0, #0x43]
    // 0x7b1e04: DecompressPointer r6
    //     0x7b1e04: add             x6, x6, HEAP, lsl #32
    // 0x7b1e08: stur            x6, [fp, #-0x50]
    // 0x7b1e0c: LoadField: r7 = r0->field_7b
    //     0x7b1e0c: ldur            w7, [x0, #0x7b]
    // 0x7b1e10: DecompressPointer r7
    //     0x7b1e10: add             x7, x7, HEAP, lsl #32
    // 0x7b1e14: cmp             w7, NULL
    // 0x7b1e18: b.eq            #0x7b206c
    // 0x7b1e1c: ldur            x16, [fp, #-0x40]
    // 0x7b1e20: stp             x16, x7, [SP, #-0x10]!
    // 0x7b1e24: mov             x0, x7
    // 0x7b1e28: ClosureCall
    //     0x7b1e28: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7b1e2c: ldur            x2, [x0, #0x1f]
    //     0x7b1e30: blr             x2
    // 0x7b1e34: add             SP, SP, #0x10
    // 0x7b1e38: mov             x1, x0
    // 0x7b1e3c: ldur            x0, [fp, #-0x20]
    // 0x7b1e40: stur            x1, [fp, #-0x78]
    // 0x7b1e44: LoadField: r2 = r0->field_f
    //     0x7b1e44: ldur            w2, [x0, #0xf]
    // 0x7b1e48: DecompressPointer r2
    //     0x7b1e48: add             x2, x2, HEAP, lsl #32
    // 0x7b1e4c: cmp             w2, NULL
    // 0x7b1e50: b.eq            #0x7b2070
    // 0x7b1e54: SaveReg r2
    //     0x7b1e54: str             x2, [SP, #-8]!
    // 0x7b1e58: r0 = of()
    //     0x7b1e58: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x7b1e5c: add             SP, SP, #8
    // 0x7b1e60: mov             x3, x0
    // 0x7b1e64: ldur            x0, [fp, #-0x30]
    // 0x7b1e68: stur            x3, [fp, #-0x88]
    // 0x7b1e6c: LoadField: r1 = r0->field_13
    //     0x7b1e6c: ldur            w1, [x0, #0x13]
    // 0x7b1e70: DecompressPointer r1
    //     0x7b1e70: add             x1, x1, HEAP, lsl #32
    // 0x7b1e74: cmp             w1, NULL
    // 0x7b1e78: b.eq            #0x7b1ea8
    // 0x7b1e7c: LoadField: r2 = r1->field_7
    //     0x7b1e7c: ldur            x2, [x1, #7]
    // 0x7b1e80: cmp             x2, #1
    // 0x7b1e84: b.gt            #0x7b1e9c
    // 0x7b1e88: cmp             x2, #0
    // 0x7b1e8c: b.gt            #0x7b1e9c
    // 0x7b1e90: r4 = Instance_Duration
    //     0x7b1e90: add             x4, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x7b1e94: ldr             x4, [x4, #0x9e0]
    // 0x7b1e98: b               #0x7b1eac
    // 0x7b1e9c: r4 = Instance_Duration
    //     0x7b1e9c: add             x4, PP, #0xd, lsl #12  ; [pp+0xd9e8] Obj!Duration@b67b01
    //     0x7b1ea0: ldr             x4, [x4, #0x9e8]
    // 0x7b1ea4: b               #0x7b1eac
    // 0x7b1ea8: r4 = Null
    //     0x7b1ea8: mov             x4, NULL
    // 0x7b1eac: mov             x2, x0
    // 0x7b1eb0: stur            x4, [fp, #-0x80]
    // 0x7b1eb4: r1 = Function 'handleInkRemoval':.
    //     0x7b1eb4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e2a0] AnonymousClosure: (0x7b28e0), in [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight (0x7b1928)
    //     0x7b1eb8: ldr             x1, [x1, #0x2a0]
    // 0x7b1ebc: r0 = AllocateClosure()
    //     0x7b1ebc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b1ec0: stur            x0, [fp, #-0x90]
    // 0x7b1ec4: r0 = InkHighlight()
    //     0x7b1ec4: bl              #0x7b284c  ; AllocateInkHighlightStub -> InkHighlight (size=0x3c)
    // 0x7b1ec8: stur            x0, [fp, #-0x98]
    // 0x7b1ecc: ldur            x16, [fp, #-0x58]
    // 0x7b1ed0: stp             x16, x0, [SP, #-0x10]!
    // 0x7b1ed4: ldur            x16, [fp, #-0x38]
    // 0x7b1ed8: ldur            lr, [fp, #-0x70]
    // 0x7b1edc: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1ee0: ldur            x16, [fp, #-0x50]
    // 0x7b1ee4: ldur            lr, [fp, #-0x80]
    // 0x7b1ee8: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1eec: ldur            x16, [fp, #-0x90]
    // 0x7b1ef0: ldur            lr, [fp, #-0x60]
    // 0x7b1ef4: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1ef8: ldur            x16, [fp, #-0x78]
    // 0x7b1efc: ldur            lr, [fp, #-0x40]
    // 0x7b1f00: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1f04: ldur            x16, [fp, #-0x68]
    // 0x7b1f08: ldur            lr, [fp, #-0x88]
    // 0x7b1f0c: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1f10: r0 = InkHighlight()
    //     0x7b1f10: bl              #0x7b232c  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::InkHighlight
    // 0x7b1f14: add             SP, SP, #0x60
    // 0x7b1f18: ldur            x16, [fp, #-0x28]
    // 0x7b1f1c: ldur            lr, [fp, #-0x48]
    // 0x7b1f20: stp             lr, x16, [SP, #-0x10]!
    // 0x7b1f24: ldur            x16, [fp, #-0x98]
    // 0x7b1f28: SaveReg r16
    //     0x7b1f28: str             x16, [SP, #-8]!
    // 0x7b1f2c: r0 = []=()
    //     0x7b1f2c: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x7b1f30: add             SP, SP, #0x18
    // 0x7b1f34: ldur            x16, [fp, #-0x20]
    // 0x7b1f38: SaveReg r16
    //     0x7b1f38: str             x16, [SP, #-8]!
    // 0x7b1f3c: r0 = updateKeepAlive()
    //     0x7b1f3c: bl              #0x7b2150  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0x7b1f40: add             SP, SP, #8
    // 0x7b1f44: b               #0x7b1f6c
    // 0x7b1f48: SaveReg r0
    //     0x7b1f48: str             x0, [SP, #-8]!
    // 0x7b1f4c: r0 = activate()
    //     0x7b1f4c: bl              #0x7b20e8  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::activate
    // 0x7b1f50: add             SP, SP, #8
    // 0x7b1f54: b               #0x7b1f6c
    // 0x7b1f58: cmp             w0, NULL
    // 0x7b1f5c: b.eq            #0x7b2074
    // 0x7b1f60: SaveReg r0
    //     0x7b1f60: str             x0, [SP, #-8]!
    // 0x7b1f64: r0 = deactivate()
    //     0x7b1f64: bl              #0x7b2080  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::deactivate
    // 0x7b1f68: add             SP, SP, #8
    // 0x7b1f6c: ldur            x0, [fp, #-0x30]
    // 0x7b1f70: LoadField: r1 = r0->field_13
    //     0x7b1f70: ldur            w1, [x0, #0x13]
    // 0x7b1f74: DecompressPointer r1
    //     0x7b1f74: add             x1, x1, HEAP, lsl #32
    // 0x7b1f78: cmp             w1, NULL
    // 0x7b1f7c: b.eq            #0x7b2018
    // 0x7b1f80: LoadField: r0 = r1->field_7
    //     0x7b1f80: ldur            x0, [x1, #7]
    // 0x7b1f84: cmp             x0, #1
    // 0x7b1f88: b.gt            #0x7b2018
    // 0x7b1f8c: cmp             x0, #0
    // 0x7b1f90: b.gt            #0x7b1fd4
    // 0x7b1f94: ldur            x0, [fp, #-0x20]
    // 0x7b1f98: LoadField: r1 = r0->field_b
    //     0x7b1f98: ldur            w1, [x0, #0xb]
    // 0x7b1f9c: DecompressPointer r1
    //     0x7b1f9c: add             x1, x1, HEAP, lsl #32
    // 0x7b1fa0: cmp             w1, NULL
    // 0x7b1fa4: b.eq            #0x7b2078
    // 0x7b1fa8: LoadField: r0 = r1->field_27
    //     0x7b1fa8: ldur            w0, [x1, #0x27]
    // 0x7b1fac: DecompressPointer r0
    //     0x7b1fac: add             x0, x0, HEAP, lsl #32
    // 0x7b1fb0: cmp             w0, NULL
    // 0x7b1fb4: b.eq            #0x7b2018
    // 0x7b1fb8: ldur            x16, [fp, #-0x10]
    // 0x7b1fbc: stp             x16, x0, [SP, #-0x10]!
    // 0x7b1fc0: ClosureCall
    //     0x7b1fc0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7b1fc4: ldur            x2, [x0, #0x1f]
    //     0x7b1fc8: blr             x2
    // 0x7b1fcc: add             SP, SP, #0x10
    // 0x7b1fd0: b               #0x7b2018
    // 0x7b1fd4: ldur            x0, [fp, #-0x20]
    // 0x7b1fd8: ldur            x1, [fp, #-8]
    // 0x7b1fdc: tbnz            w1, #4, #0x7b2018
    // 0x7b1fe0: LoadField: r1 = r0->field_b
    //     0x7b1fe0: ldur            w1, [x0, #0xb]
    // 0x7b1fe4: DecompressPointer r1
    //     0x7b1fe4: add             x1, x1, HEAP, lsl #32
    // 0x7b1fe8: cmp             w1, NULL
    // 0x7b1fec: b.eq            #0x7b207c
    // 0x7b1ff0: LoadField: r0 = r1->field_2b
    //     0x7b1ff0: ldur            w0, [x1, #0x2b]
    // 0x7b1ff4: DecompressPointer r0
    //     0x7b1ff4: add             x0, x0, HEAP, lsl #32
    // 0x7b1ff8: cmp             w0, NULL
    // 0x7b1ffc: b.eq            #0x7b2018
    // 0x7b2000: ldur            x16, [fp, #-0x10]
    // 0x7b2004: stp             x16, x0, [SP, #-0x10]!
    // 0x7b2008: ClosureCall
    //     0x7b2008: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7b200c: ldur            x2, [x0, #0x1f]
    //     0x7b2010: blr             x2
    // 0x7b2014: add             SP, SP, #0x10
    // 0x7b2018: r0 = Null
    //     0x7b2018: mov             x0, NULL
    // 0x7b201c: LeaveFrame
    //     0x7b201c: mov             SP, fp
    //     0x7b2020: ldp             fp, lr, [SP], #0x10
    // 0x7b2024: ret
    //     0x7b2024: ret             
    // 0x7b2028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2028: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b202c: b               #0x7b19b0
    // 0x7b2030: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2030: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2034: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2034: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2038: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b203c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b203c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2040: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2040: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2044: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2044: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2048: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2048: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b204c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b204c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2050: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2054: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2054: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2058: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b205c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b205c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2060: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2064: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2064: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2068: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2068: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b206c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b206c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2074: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2078: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b207c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b207c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ wantKeepAlive(/* No info */) {
    // ** addr: 0x7b21d4, size: 0x78
    // 0x7b21d4: EnterFrame
    //     0x7b21d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b21d8: mov             fp, SP
    // 0x7b21dc: CheckStackOverflow
    //     0x7b21dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b21e0: cmp             SP, x16
    //     0x7b21e4: b.ls            #0x7b2244
    // 0x7b21e8: ldr             x16, [fp, #0x10]
    // 0x7b21ec: SaveReg r16
    //     0x7b21ec: str             x16, [SP, #-8]!
    // 0x7b21f0: r0 = highlightsExist()
    //     0x7b21f0: bl              #0x7b224c  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::highlightsExist
    // 0x7b21f4: add             SP, SP, #8
    // 0x7b21f8: tbnz            w0, #4, #0x7b2204
    // 0x7b21fc: r0 = true
    //     0x7b21fc: add             x0, NULL, #0x20  ; true
    // 0x7b2200: b               #0x7b2238
    // 0x7b2204: ldr             x1, [fp, #0x10]
    // 0x7b2208: LoadField: r2 = r1->field_17
    //     0x7b2208: ldur            w2, [x1, #0x17]
    // 0x7b220c: DecompressPointer r2
    //     0x7b220c: add             x2, x2, HEAP, lsl #32
    // 0x7b2210: cmp             w2, NULL
    // 0x7b2214: b.eq            #0x7b2234
    // 0x7b2218: LoadField: r1 = r2->field_f
    //     0x7b2218: ldur            x1, [x2, #0xf]
    // 0x7b221c: cbnz            x1, #0x7b2228
    // 0x7b2220: r2 = false
    //     0x7b2220: add             x2, NULL, #0x30  ; false
    // 0x7b2224: b               #0x7b222c
    // 0x7b2228: r2 = true
    //     0x7b2228: add             x2, NULL, #0x20  ; true
    // 0x7b222c: mov             x0, x2
    // 0x7b2230: b               #0x7b2238
    // 0x7b2234: r0 = false
    //     0x7b2234: add             x0, NULL, #0x30  ; false
    // 0x7b2238: LeaveFrame
    //     0x7b2238: mov             SP, fp
    //     0x7b223c: ldp             fp, lr, [SP], #0x10
    // 0x7b2240: ret
    //     0x7b2240: ret             
    // 0x7b2244: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2244: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2248: b               #0x7b21e8
  }
  get _ highlightsExist(/* No info */) {
    // ** addr: 0x7b224c, size: 0x9c
    // 0x7b224c: EnterFrame
    //     0x7b224c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2250: mov             fp, SP
    // 0x7b2254: AllocStack(0x8)
    //     0x7b2254: sub             SP, SP, #8
    // 0x7b2258: CheckStackOverflow
    //     0x7b2258: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b225c: cmp             SP, x16
    //     0x7b2260: b.ls            #0x7b22e0
    // 0x7b2264: ldr             x0, [fp, #0x10]
    // 0x7b2268: LoadField: r1 = r0->field_23
    //     0x7b2268: ldur            w1, [x0, #0x23]
    // 0x7b226c: DecompressPointer r1
    //     0x7b226c: add             x1, x1, HEAP, lsl #32
    // 0x7b2270: SaveReg r1
    //     0x7b2270: str             x1, [SP, #-8]!
    // 0x7b2274: r0 = values()
    //     0x7b2274: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x7b2278: add             SP, SP, #8
    // 0x7b227c: r1 = Function '<anonymous closure>':.
    //     0x7b227c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e1e8] AnonymousClosure: (0x7b22e8), in [package:flutter/src/material/ink_well.dart] _InkResponseState::highlightsExist (0x7b224c)
    //     0x7b2280: ldr             x1, [x1, #0x1e8]
    // 0x7b2284: r2 = Null
    //     0x7b2284: mov             x2, NULL
    // 0x7b2288: stur            x0, [fp, #-8]
    // 0x7b228c: r0 = AllocateClosure()
    //     0x7b228c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b2290: ldur            x16, [fp, #-8]
    // 0x7b2294: stp             x0, x16, [SP, #-0x10]!
    // 0x7b2298: r0 = where()
    //     0x7b2298: bl              #0x6fa13c  ; [dart:collection] __Set&_HashVMBase&SetMixin::where
    // 0x7b229c: add             SP, SP, #0x10
    // 0x7b22a0: SaveReg r0
    //     0x7b22a0: str             x0, [SP, #-8]!
    // 0x7b22a4: r0 = iterator()
    //     0x7b22a4: bl              #0x6fca1c  ; [dart:_internal] WhereIterable::iterator
    // 0x7b22a8: add             SP, SP, #8
    // 0x7b22ac: r1 = LoadClassIdInstr(r0)
    //     0x7b22ac: ldur            x1, [x0, #-1]
    //     0x7b22b0: ubfx            x1, x1, #0xc, #0x14
    // 0x7b22b4: SaveReg r0
    //     0x7b22b4: str             x0, [SP, #-8]!
    // 0x7b22b8: mov             x0, x1
    // 0x7b22bc: r0 = GDT[cid_x0 + 0x541]()
    //     0x7b22bc: add             lr, x0, #0x541
    //     0x7b22c0: ldr             lr, [x21, lr, lsl #3]
    //     0x7b22c4: blr             lr
    // 0x7b22c8: add             SP, SP, #8
    // 0x7b22cc: eor             x1, x0, #0x10
    // 0x7b22d0: eor             x0, x1, #0x10
    // 0x7b22d4: LeaveFrame
    //     0x7b22d4: mov             SP, fp
    //     0x7b22d8: ldp             fp, lr, [SP], #0x10
    // 0x7b22dc: ret
    //     0x7b22dc: ret             
    // 0x7b22e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b22e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b22e4: b               #0x7b2264
  }
  [closure] bool <anonymous closure>(dynamic, InkHighlight?) {
    // ** addr: 0x7b22e8, size: 0x18
    // 0x7b22e8: ldr             x1, [SP]
    // 0x7b22ec: cmp             w1, NULL
    // 0x7b22f0: r16 = true
    //     0x7b22f0: add             x16, NULL, #0x20  ; true
    // 0x7b22f4: r17 = false
    //     0x7b22f4: add             x17, NULL, #0x30  ; false
    // 0x7b22f8: csel            x0, x16, x17, ne
    // 0x7b22fc: ret
    //     0x7b22fc: ret             
  }
  [closure] void handleInkRemoval(dynamic) {
    // ** addr: 0x7b28e0, size: 0x80
    // 0x7b28e0: EnterFrame
    //     0x7b28e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7b28e4: mov             fp, SP
    // 0x7b28e8: AllocStack(0x8)
    //     0x7b28e8: sub             SP, SP, #8
    // 0x7b28ec: SetupParameters()
    //     0x7b28ec: ldr             x0, [fp, #0x10]
    //     0x7b28f0: ldur            w1, [x0, #0x17]
    //     0x7b28f4: add             x1, x1, HEAP, lsl #32
    //     0x7b28f8: stur            x1, [fp, #-8]
    // 0x7b28fc: CheckStackOverflow
    //     0x7b28fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2900: cmp             SP, x16
    //     0x7b2904: b.ls            #0x7b2958
    // 0x7b2908: LoadField: r0 = r1->field_f
    //     0x7b2908: ldur            w0, [x1, #0xf]
    // 0x7b290c: DecompressPointer r0
    //     0x7b290c: add             x0, x0, HEAP, lsl #32
    // 0x7b2910: LoadField: r2 = r0->field_23
    //     0x7b2910: ldur            w2, [x0, #0x23]
    // 0x7b2914: DecompressPointer r2
    //     0x7b2914: add             x2, x2, HEAP, lsl #32
    // 0x7b2918: LoadField: r0 = r1->field_13
    //     0x7b2918: ldur            w0, [x1, #0x13]
    // 0x7b291c: DecompressPointer r0
    //     0x7b291c: add             x0, x0, HEAP, lsl #32
    // 0x7b2920: stp             x0, x2, [SP, #-0x10]!
    // 0x7b2924: SaveReg rNULL
    //     0x7b2924: str             NULL, [SP, #-8]!
    // 0x7b2928: r0 = []=()
    //     0x7b2928: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x7b292c: add             SP, SP, #0x18
    // 0x7b2930: ldur            x0, [fp, #-8]
    // 0x7b2934: LoadField: r1 = r0->field_f
    //     0x7b2934: ldur            w1, [x0, #0xf]
    // 0x7b2938: DecompressPointer r1
    //     0x7b2938: add             x1, x1, HEAP, lsl #32
    // 0x7b293c: SaveReg r1
    //     0x7b293c: str             x1, [SP, #-8]!
    // 0x7b2940: r0 = updateKeepAlive()
    //     0x7b2940: bl              #0x7b2150  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0x7b2944: add             SP, SP, #8
    // 0x7b2948: r0 = Null
    //     0x7b2948: mov             x0, NULL
    // 0x7b294c: LeaveFrame
    //     0x7b294c: mov             SP, fp
    //     0x7b2950: ldp             fp, lr, [SP], #0x10
    // 0x7b2954: ret
    //     0x7b2954: ret             
    // 0x7b2958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b295c: b               #0x7b2908
  }
  _ initStatesController(/* No info */) {
    // ** addr: 0x7b2984, size: 0x190
    // 0x7b2984: EnterFrame
    //     0x7b2984: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2988: mov             fp, SP
    // 0x7b298c: AllocStack(0x8)
    //     0x7b298c: sub             SP, SP, #8
    // 0x7b2990: CheckStackOverflow
    //     0x7b2990: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2994: cmp             SP, x16
    //     0x7b2998: b.ls            #0x7b2af8
    // 0x7b299c: ldr             x0, [fp, #0x10]
    // 0x7b29a0: LoadField: r1 = r0->field_b
    //     0x7b29a0: ldur            w1, [x0, #0xb]
    // 0x7b29a4: DecompressPointer r1
    //     0x7b29a4: add             x1, x1, HEAP, lsl #32
    // 0x7b29a8: cmp             w1, NULL
    // 0x7b29ac: b.eq            #0x7b2b00
    // 0x7b29b0: LoadField: r2 = r1->field_7f
    //     0x7b29b0: ldur            w2, [x1, #0x7f]
    // 0x7b29b4: DecompressPointer r2
    //     0x7b29b4: add             x2, x2, HEAP, lsl #32
    // 0x7b29b8: cmp             w2, NULL
    // 0x7b29bc: b.ne            #0x7b2a08
    // 0x7b29c0: r1 = <Set<MaterialState>>
    //     0x7b29c0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e518] TypeArguments: <Set<MaterialState>>
    //     0x7b29c4: ldr             x1, [x1, #0x518]
    // 0x7b29c8: r0 = MaterialStatesController()
    //     0x7b29c8: bl              #0x7b0bfc  ; AllocateMaterialStatesControllerStub -> MaterialStatesController (size=0x2c)
    // 0x7b29cc: stur            x0, [fp, #-8]
    // 0x7b29d0: SaveReg r0
    //     0x7b29d0: str             x0, [SP, #-8]!
    // 0x7b29d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b29d4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b29d8: r0 = MaterialStatesController()
    //     0x7b29d8: bl              #0x7b0a98  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::MaterialStatesController
    // 0x7b29dc: add             SP, SP, #8
    // 0x7b29e0: ldur            x0, [fp, #-8]
    // 0x7b29e4: ldr             x1, [fp, #0x10]
    // 0x7b29e8: StoreField: r1->field_2b = r0
    //     0x7b29e8: stur            w0, [x1, #0x2b]
    //     0x7b29ec: ldurb           w16, [x1, #-1]
    //     0x7b29f0: ldurb           w17, [x0, #-1]
    //     0x7b29f4: and             x16, x17, x16, lsr #2
    //     0x7b29f8: tst             x16, HEAP, lsr #32
    //     0x7b29fc: b.eq            #0x7b2a04
    //     0x7b2a00: bl              #0xd6826c
    // 0x7b2a04: b               #0x7b2a0c
    // 0x7b2a08: mov             x1, x0
    // 0x7b2a0c: LoadField: r0 = r1->field_b
    //     0x7b2a0c: ldur            w0, [x1, #0xb]
    // 0x7b2a10: DecompressPointer r0
    //     0x7b2a10: add             x0, x0, HEAP, lsl #32
    // 0x7b2a14: cmp             w0, NULL
    // 0x7b2a18: b.eq            #0x7b2b04
    // 0x7b2a1c: LoadField: r2 = r0->field_7f
    //     0x7b2a1c: ldur            w2, [x0, #0x7f]
    // 0x7b2a20: DecompressPointer r2
    //     0x7b2a20: add             x2, x2, HEAP, lsl #32
    // 0x7b2a24: cmp             w2, NULL
    // 0x7b2a28: b.ne            #0x7b2a40
    // 0x7b2a2c: LoadField: r0 = r1->field_2b
    //     0x7b2a2c: ldur            w0, [x1, #0x2b]
    // 0x7b2a30: DecompressPointer r0
    //     0x7b2a30: add             x0, x0, HEAP, lsl #32
    // 0x7b2a34: cmp             w0, NULL
    // 0x7b2a38: b.eq            #0x7b2b08
    // 0x7b2a3c: b               #0x7b2a44
    // 0x7b2a40: mov             x0, x2
    // 0x7b2a44: stur            x0, [fp, #-8]
    // 0x7b2a48: SaveReg r1
    //     0x7b2a48: str             x1, [SP, #-8]!
    // 0x7b2a4c: r0 = enabled()
    //     0x7b2a4c: bl              #0x7b18d0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0x7b2a50: add             SP, SP, #8
    // 0x7b2a54: eor             x1, x0, #0x10
    // 0x7b2a58: ldur            x16, [fp, #-8]
    // 0x7b2a5c: r30 = Instance_MaterialState
    //     0x7b2a5c: add             lr, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b2a60: ldr             lr, [lr, #0x2a0]
    // 0x7b2a64: stp             lr, x16, [SP, #-0x10]!
    // 0x7b2a68: SaveReg r1
    //     0x7b2a68: str             x1, [SP, #-8]!
    // 0x7b2a6c: r0 = update()
    //     0x7b2a6c: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b2a70: add             SP, SP, #0x18
    // 0x7b2a74: ldr             x0, [fp, #0x10]
    // 0x7b2a78: LoadField: r1 = r0->field_b
    //     0x7b2a78: ldur            w1, [x0, #0xb]
    // 0x7b2a7c: DecompressPointer r1
    //     0x7b2a7c: add             x1, x1, HEAP, lsl #32
    // 0x7b2a80: cmp             w1, NULL
    // 0x7b2a84: b.eq            #0x7b2b0c
    // 0x7b2a88: LoadField: r2 = r1->field_7f
    //     0x7b2a88: ldur            w2, [x1, #0x7f]
    // 0x7b2a8c: DecompressPointer r2
    //     0x7b2a8c: add             x2, x2, HEAP, lsl #32
    // 0x7b2a90: cmp             w2, NULL
    // 0x7b2a94: b.ne            #0x7b2aac
    // 0x7b2a98: LoadField: r1 = r0->field_2b
    //     0x7b2a98: ldur            w1, [x0, #0x2b]
    // 0x7b2a9c: DecompressPointer r1
    //     0x7b2a9c: add             x1, x1, HEAP, lsl #32
    // 0x7b2aa0: cmp             w1, NULL
    // 0x7b2aa4: b.eq            #0x7b2b10
    // 0x7b2aa8: b               #0x7b2ab0
    // 0x7b2aac: mov             x1, x2
    // 0x7b2ab0: stur            x1, [fp, #-8]
    // 0x7b2ab4: r1 = 1
    //     0x7b2ab4: mov             x1, #1
    // 0x7b2ab8: r0 = AllocateContext()
    //     0x7b2ab8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b2abc: mov             x1, x0
    // 0x7b2ac0: ldr             x0, [fp, #0x10]
    // 0x7b2ac4: StoreField: r1->field_f = r0
    //     0x7b2ac4: stur            w0, [x1, #0xf]
    // 0x7b2ac8: mov             x2, x1
    // 0x7b2acc: r1 = Function 'handleStatesControllerChange':.
    //     0x7b2acc: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4c0] AnonymousClosure: (0x7b2b14), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange (0x7b2b5c)
    //     0x7b2ad0: ldr             x1, [x1, #0x4c0]
    // 0x7b2ad4: r0 = AllocateClosure()
    //     0x7b2ad4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b2ad8: ldur            x16, [fp, #-8]
    // 0x7b2adc: stp             x0, x16, [SP, #-0x10]!
    // 0x7b2ae0: r0 = addListener()
    //     0x7b2ae0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7b2ae4: add             SP, SP, #0x10
    // 0x7b2ae8: r0 = Null
    //     0x7b2ae8: mov             x0, NULL
    // 0x7b2aec: LeaveFrame
    //     0x7b2aec: mov             SP, fp
    //     0x7b2af0: ldp             fp, lr, [SP], #0x10
    // 0x7b2af4: ret
    //     0x7b2af4: ret             
    // 0x7b2af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2af8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2afc: b               #0x7b299c
    // 0x7b2b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2b00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2b04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2b08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2b08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2b0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2b0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b2b10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2b10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleStatesControllerChange(dynamic) {
    // ** addr: 0x7b2b14, size: 0x48
    // 0x7b2b14: EnterFrame
    //     0x7b2b14: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2b18: mov             fp, SP
    // 0x7b2b1c: ldr             x0, [fp, #0x10]
    // 0x7b2b20: LoadField: r1 = r0->field_17
    //     0x7b2b20: ldur            w1, [x0, #0x17]
    // 0x7b2b24: DecompressPointer r1
    //     0x7b2b24: add             x1, x1, HEAP, lsl #32
    // 0x7b2b28: CheckStackOverflow
    //     0x7b2b28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2b2c: cmp             SP, x16
    //     0x7b2b30: b.ls            #0x7b2b54
    // 0x7b2b34: LoadField: r0 = r1->field_f
    //     0x7b2b34: ldur            w0, [x1, #0xf]
    // 0x7b2b38: DecompressPointer r0
    //     0x7b2b38: add             x0, x0, HEAP, lsl #32
    // 0x7b2b3c: SaveReg r0
    //     0x7b2b3c: str             x0, [SP, #-8]!
    // 0x7b2b40: r0 = handleStatesControllerChange()
    //     0x7b2b40: bl              #0x7b2b5c  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange
    // 0x7b2b44: add             SP, SP, #8
    // 0x7b2b48: LeaveFrame
    //     0x7b2b48: mov             SP, fp
    //     0x7b2b4c: ldp             fp, lr, [SP], #0x10
    // 0x7b2b50: ret
    //     0x7b2b50: ret             
    // 0x7b2b54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2b54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2b58: b               #0x7b2b34
  }
  _ handleStatesControllerChange(/* No info */) {
    // ** addr: 0x7b2b5c, size: 0x4c
    // 0x7b2b5c: EnterFrame
    //     0x7b2b5c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2b60: mov             fp, SP
    // 0x7b2b64: CheckStackOverflow
    //     0x7b2b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2b68: cmp             SP, x16
    //     0x7b2b6c: b.ls            #0x7b2ba0
    // 0x7b2b70: r1 = Function '<anonymous closure>':.
    //     0x7b2b70: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4c8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7b2b74: ldr             x1, [x1, #0x4c8]
    // 0x7b2b78: r2 = Null
    //     0x7b2b78: mov             x2, NULL
    // 0x7b2b7c: r0 = AllocateClosure()
    //     0x7b2b7c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b2b80: ldr             x16, [fp, #0x10]
    // 0x7b2b84: stp             x0, x16, [SP, #-0x10]!
    // 0x7b2b88: r0 = setState()
    //     0x7b2b88: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b2b8c: add             SP, SP, #0x10
    // 0x7b2b90: r0 = Null
    //     0x7b2b90: mov             x0, NULL
    // 0x7b2b94: LeaveFrame
    //     0x7b2b94: mov             SP, fp
    //     0x7b2b98: ldp             fp, lr, [SP], #0x10
    // 0x7b2b9c: ret
    //     0x7b2b9c: ret             
    // 0x7b2ba0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2ba0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2ba4: b               #0x7b2b70
  }
  _ build(/* No info */) {
    // ** addr: 0x854868, size: 0x7d8
    // 0x854868: EnterFrame
    //     0x854868: stp             fp, lr, [SP, #-0x10]!
    //     0x85486c: mov             fp, SP
    // 0x854870: AllocStack(0x78)
    //     0x854870: sub             SP, SP, #0x78
    // 0x854874: CheckStackOverflow
    //     0x854874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x854878: cmp             SP, x16
    //     0x85487c: b.ls            #0x855014
    // 0x854880: r1 = 2
    //     0x854880: mov             x1, #2
    // 0x854884: r0 = AllocateContext()
    //     0x854884: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854888: ldr             x1, [fp, #0x18]
    // 0x85488c: stur            x0, [fp, #-8]
    // 0x854890: StoreField: r0->field_f = r1
    //     0x854890: stur            w1, [x0, #0xf]
    // 0x854894: ldr             x2, [fp, #0x10]
    // 0x854898: StoreField: r0->field_13 = r2
    //     0x854898: stur            w2, [x0, #0x13]
    // 0x85489c: stp             x2, x1, [SP, #-0x10]!
    // 0x8548a0: r0 = build()
    //     0x8548a0: bl              #0x8552c8  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::build
    // 0x8548a4: add             SP, SP, #0x10
    // 0x8548a8: ldur            x2, [fp, #-8]
    // 0x8548ac: r1 = Function 'getHighlightColorForType':.
    //     0x8548ac: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e1f0] AnonymousClosure: (0x859b70), in [package:flutter/src/material/ink_well.dart] _InkResponseState::build (0x854868)
    //     0x8548b0: ldr             x1, [x1, #0x1f0]
    // 0x8548b4: r0 = AllocateClosure()
    //     0x8548b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8548b8: ldr             x1, [fp, #0x18]
    // 0x8548bc: stur            x0, [fp, #-0x18]
    // 0x8548c0: LoadField: r2 = r1->field_23
    //     0x8548c0: ldur            w2, [x1, #0x23]
    // 0x8548c4: DecompressPointer r2
    //     0x8548c4: add             x2, x2, HEAP, lsl #32
    // 0x8548c8: stur            x2, [fp, #-0x10]
    // 0x8548cc: SaveReg r2
    //     0x8548cc: str             x2, [SP, #-8]!
    // 0x8548d0: r0 = keys()
    //     0x8548d0: bl              #0xca1b9c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::keys
    // 0x8548d4: add             SP, SP, #8
    // 0x8548d8: SaveReg r0
    //     0x8548d8: str             x0, [SP, #-8]!
    // 0x8548dc: r0 = iterator()
    //     0x8548dc: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x8548e0: add             SP, SP, #8
    // 0x8548e4: stur            x0, [fp, #-0x28]
    // 0x8548e8: LoadField: r2 = r0->field_7
    //     0x8548e8: ldur            w2, [x0, #7]
    // 0x8548ec: DecompressPointer r2
    //     0x8548ec: add             x2, x2, HEAP, lsl #32
    // 0x8548f0: stur            x2, [fp, #-0x20]
    // 0x8548f4: ldur            x1, [fp, #-0x10]
    // 0x8548f8: CheckStackOverflow
    //     0x8548f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8548fc: cmp             SP, x16
    //     0x854900: b.ls            #0x85501c
    // 0x854904: SaveReg r0
    //     0x854904: str             x0, [SP, #-8]!
    // 0x854908: r0 = moveNext()
    //     0x854908: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x85490c: add             SP, SP, #8
    // 0x854910: tbnz            w0, #4, #0x854a3c
    // 0x854914: ldur            x3, [fp, #-0x28]
    // 0x854918: LoadField: r4 = r3->field_33
    //     0x854918: ldur            w4, [x3, #0x33]
    // 0x85491c: DecompressPointer r4
    //     0x85491c: add             x4, x4, HEAP, lsl #32
    // 0x854920: stur            x4, [fp, #-0x30]
    // 0x854924: cmp             w4, NULL
    // 0x854928: b.ne            #0x85495c
    // 0x85492c: mov             x0, x4
    // 0x854930: ldur            x2, [fp, #-0x20]
    // 0x854934: r1 = Null
    //     0x854934: mov             x1, NULL
    // 0x854938: cmp             w2, NULL
    // 0x85493c: b.eq            #0x85495c
    // 0x854940: LoadField: r4 = r2->field_17
    //     0x854940: ldur            w4, [x2, #0x17]
    // 0x854944: DecompressPointer r4
    //     0x854944: add             x4, x4, HEAP, lsl #32
    // 0x854948: r8 = X0
    //     0x854948: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x85494c: LoadField: r9 = r4->field_7
    //     0x85494c: ldur            x9, [x4, #7]
    // 0x854950: r3 = Null
    //     0x854950: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e1f8] Null
    //     0x854954: ldr             x3, [x3, #0x1f8]
    // 0x854958: blr             x9
    // 0x85495c: ldur            x0, [fp, #-0x10]
    // 0x854960: ldur            x16, [fp, #-0x30]
    // 0x854964: stp             x16, x0, [SP, #-0x10]!
    // 0x854968: r0 = _getValueOrData()
    //     0x854968: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x85496c: add             SP, SP, #0x10
    // 0x854970: ldur            x1, [fp, #-0x10]
    // 0x854974: LoadField: r2 = r1->field_f
    //     0x854974: ldur            w2, [x1, #0xf]
    // 0x854978: DecompressPointer r2
    //     0x854978: add             x2, x2, HEAP, lsl #32
    // 0x85497c: cmp             w2, w0
    // 0x854980: b.ne            #0x85498c
    // 0x854984: r2 = Null
    //     0x854984: mov             x2, NULL
    // 0x854988: b               #0x854990
    // 0x85498c: mov             x2, x0
    // 0x854990: stur            x2, [fp, #-0x38]
    // 0x854994: cmp             w2, NULL
    // 0x854998: b.eq            #0x854a30
    // 0x85499c: ldur            x16, [fp, #-0x18]
    // 0x8549a0: ldur            lr, [fp, #-0x30]
    // 0x8549a4: stp             lr, x16, [SP, #-0x10]!
    // 0x8549a8: ldur            x0, [fp, #-0x18]
    // 0x8549ac: ClosureCall
    //     0x8549ac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8549b0: ldur            x2, [x0, #0x1f]
    //     0x8549b4: blr             x2
    // 0x8549b8: add             SP, SP, #0x10
    // 0x8549bc: mov             x2, x0
    // 0x8549c0: ldur            x1, [fp, #-0x38]
    // 0x8549c4: stur            x2, [fp, #-0x30]
    // 0x8549c8: LoadField: r0 = r1->field_13
    //     0x8549c8: ldur            w0, [x1, #0x13]
    // 0x8549cc: DecompressPointer r0
    //     0x8549cc: add             x0, x0, HEAP, lsl #32
    // 0x8549d0: r3 = LoadClassIdInstr(r2)
    //     0x8549d0: ldur            x3, [x2, #-1]
    //     0x8549d4: ubfx            x3, x3, #0xc, #0x14
    // 0x8549d8: stp             x0, x2, [SP, #-0x10]!
    // 0x8549dc: mov             x0, x3
    // 0x8549e0: mov             lr, x0
    // 0x8549e4: ldr             lr, [x21, lr, lsl #3]
    // 0x8549e8: blr             lr
    // 0x8549ec: add             SP, SP, #0x10
    // 0x8549f0: tbz             w0, #4, #0x854a30
    // 0x8549f4: ldur            x1, [fp, #-0x38]
    // 0x8549f8: ldur            x0, [fp, #-0x30]
    // 0x8549fc: StoreField: r1->field_13 = r0
    //     0x8549fc: stur            w0, [x1, #0x13]
    //     0x854a00: tbz             w0, #0, #0x854a1c
    //     0x854a04: ldurb           w16, [x1, #-1]
    //     0x854a08: ldurb           w17, [x0, #-1]
    //     0x854a0c: and             x16, x17, x16, lsr #2
    //     0x854a10: tst             x16, HEAP, lsr #32
    //     0x854a14: b.eq            #0x854a1c
    //     0x854a18: bl              #0xd6826c
    // 0x854a1c: LoadField: r0 = r1->field_7
    //     0x854a1c: ldur            w0, [x1, #7]
    // 0x854a20: DecompressPointer r0
    //     0x854a20: add             x0, x0, HEAP, lsl #32
    // 0x854a24: SaveReg r0
    //     0x854a24: str             x0, [SP, #-8]!
    // 0x854a28: r0 = markNeedsPaint()
    //     0x854a28: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x854a2c: add             SP, SP, #8
    // 0x854a30: ldur            x0, [fp, #-0x28]
    // 0x854a34: ldur            x2, [fp, #-0x20]
    // 0x854a38: b               #0x8548f4
    // 0x854a3c: ldr             x1, [fp, #0x18]
    // 0x854a40: LoadField: r2 = r1->field_1b
    //     0x854a40: ldur            w2, [x1, #0x1b]
    // 0x854a44: DecompressPointer r2
    //     0x854a44: add             x2, x2, HEAP, lsl #32
    // 0x854a48: stur            x2, [fp, #-0x10]
    // 0x854a4c: cmp             w2, NULL
    // 0x854a50: b.eq            #0x854b40
    // 0x854a54: LoadField: r0 = r1->field_b
    //     0x854a54: ldur            w0, [x1, #0xb]
    // 0x854a58: DecompressPointer r0
    //     0x854a58: add             x0, x0, HEAP, lsl #32
    // 0x854a5c: cmp             w0, NULL
    // 0x854a60: b.eq            #0x855024
    // 0x854a64: LoadField: r3 = r0->field_53
    //     0x854a64: ldur            w3, [x0, #0x53]
    // 0x854a68: DecompressPointer r3
    //     0x854a68: add             x3, x3, HEAP, lsl #32
    // 0x854a6c: cmp             w3, NULL
    // 0x854a70: b.ne            #0x854a7c
    // 0x854a74: r0 = Null
    //     0x854a74: mov             x0, NULL
    // 0x854a78: b               #0x854ad0
    // 0x854a7c: LoadField: r4 = r0->field_7f
    //     0x854a7c: ldur            w4, [x0, #0x7f]
    // 0x854a80: DecompressPointer r4
    //     0x854a80: add             x4, x4, HEAP, lsl #32
    // 0x854a84: cmp             w4, NULL
    // 0x854a88: b.ne            #0x854aa0
    // 0x854a8c: LoadField: r0 = r1->field_2b
    //     0x854a8c: ldur            w0, [x1, #0x2b]
    // 0x854a90: DecompressPointer r0
    //     0x854a90: add             x0, x0, HEAP, lsl #32
    // 0x854a94: cmp             w0, NULL
    // 0x854a98: b.eq            #0x855028
    // 0x854a9c: b               #0x854aa4
    // 0x854aa0: mov             x0, x4
    // 0x854aa4: LoadField: r4 = r0->field_27
    //     0x854aa4: ldur            w4, [x0, #0x27]
    // 0x854aa8: DecompressPointer r4
    //     0x854aa8: add             x4, x4, HEAP, lsl #32
    // 0x854aac: r0 = LoadClassIdInstr(r3)
    //     0x854aac: ldur            x0, [x3, #-1]
    //     0x854ab0: ubfx            x0, x0, #0xc, #0x14
    // 0x854ab4: stp             x4, x3, [SP, #-0x10]!
    // 0x854ab8: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x854ab8: mov             x17, #0x5e7
    //     0x854abc: movk            x17, #1, lsl #16
    //     0x854ac0: add             lr, x0, x17
    //     0x854ac4: ldr             lr, [x21, lr, lsl #3]
    //     0x854ac8: blr             lr
    // 0x854acc: add             SP, SP, #0x10
    // 0x854ad0: cmp             w0, NULL
    // 0x854ad4: b.ne            #0x854afc
    // 0x854ad8: ldr             x1, [fp, #0x18]
    // 0x854adc: LoadField: r0 = r1->field_b
    //     0x854adc: ldur            w0, [x1, #0xb]
    // 0x854ae0: DecompressPointer r0
    //     0x854ae0: add             x0, x0, HEAP, lsl #32
    // 0x854ae4: cmp             w0, NULL
    // 0x854ae8: b.eq            #0x85502c
    // 0x854aec: LoadField: r2 = r0->field_57
    //     0x854aec: ldur            w2, [x0, #0x57]
    // 0x854af0: DecompressPointer r2
    //     0x854af0: add             x2, x2, HEAP, lsl #32
    // 0x854af4: mov             x0, x2
    // 0x854af8: b               #0x854b00
    // 0x854afc: ldr             x1, [fp, #0x18]
    // 0x854b00: cmp             w0, NULL
    // 0x854b04: b.ne            #0x854b2c
    // 0x854b08: ldur            x0, [fp, #-8]
    // 0x854b0c: LoadField: r2 = r0->field_13
    //     0x854b0c: ldur            w2, [x0, #0x13]
    // 0x854b10: DecompressPointer r2
    //     0x854b10: add             x2, x2, HEAP, lsl #32
    // 0x854b14: SaveReg r2
    //     0x854b14: str             x2, [SP, #-8]!
    // 0x854b18: r0 = of()
    //     0x854b18: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x854b1c: add             SP, SP, #8
    // 0x854b20: LoadField: r1 = r0->field_7f
    //     0x854b20: ldur            w1, [x0, #0x7f]
    // 0x854b24: DecompressPointer r1
    //     0x854b24: add             x1, x1, HEAP, lsl #32
    // 0x854b28: mov             x0, x1
    // 0x854b2c: ldur            x16, [fp, #-0x10]
    // 0x854b30: stp             x0, x16, [SP, #-0x10]!
    // 0x854b34: r0 = color=()
    //     0x854b34: bl              #0x85511c  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::color=
    // 0x854b38: add             SP, SP, #0x10
    // 0x854b3c: ldr             x1, [fp, #0x18]
    // 0x854b40: LoadField: r0 = r1->field_b
    //     0x854b40: ldur            w0, [x1, #0xb]
    // 0x854b44: DecompressPointer r0
    //     0x854b44: add             x0, x0, HEAP, lsl #32
    // 0x854b48: cmp             w0, NULL
    // 0x854b4c: b.eq            #0x855030
    // 0x854b50: LoadField: r2 = r0->field_2f
    //     0x854b50: ldur            w2, [x0, #0x2f]
    // 0x854b54: DecompressPointer r2
    //     0x854b54: add             x2, x2, HEAP, lsl #32
    // 0x854b58: cmp             w2, NULL
    // 0x854b5c: b.ne            #0x854b6c
    // 0x854b60: r0 = Instance__EnabledAndDisabledMouseCursor
    //     0x854b60: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0x854b64: ldr             x0, [x0, #0x208]
    // 0x854b68: b               #0x854b70
    // 0x854b6c: mov             x0, x2
    // 0x854b70: stur            x0, [fp, #-8]
    // 0x854b74: SaveReg r1
    //     0x854b74: str             x1, [SP, #-8]!
    // 0x854b78: r0 = statesController()
    //     0x854b78: bl              #0x7b16bc  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::statesController
    // 0x854b7c: add             SP, SP, #8
    // 0x854b80: LoadField: r1 = r0->field_27
    //     0x854b80: ldur            w1, [x0, #0x27]
    // 0x854b84: DecompressPointer r1
    //     0x854b84: add             x1, x1, HEAP, lsl #32
    // 0x854b88: r16 = <MouseCursor>
    //     0x854b88: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x854b8c: ldur            lr, [fp, #-8]
    // 0x854b90: stp             lr, x16, [SP, #-0x10]!
    // 0x854b94: SaveReg r1
    //     0x854b94: str             x1, [SP, #-8]!
    // 0x854b98: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x854b98: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x854b9c: r0 = resolveAs()
    //     0x854b9c: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x854ba0: add             SP, SP, #0x18
    // 0x854ba4: ldr             x1, [fp, #0x18]
    // 0x854ba8: stur            x0, [fp, #-8]
    // 0x854bac: LoadField: r0 = r1->field_27
    //     0x854bac: ldur            w0, [x1, #0x27]
    // 0x854bb0: DecompressPointer r0
    //     0x854bb0: add             x0, x0, HEAP, lsl #32
    // 0x854bb4: r16 = Sentinel
    //     0x854bb4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x854bb8: cmp             w0, w16
    // 0x854bbc: b.ne            #0x854bcc
    // 0x854bc0: r2 = _actionMap
    //     0x854bc0: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e210] Field <_InkResponseState@760059085._actionMap@760059085>: late final (offset: 0x28)
    //     0x854bc4: ldr             x2, [x2, #0x210]
    // 0x854bc8: r0 = InitLateFinalInstanceField()
    //     0x854bc8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x854bcc: mov             x1, x0
    // 0x854bd0: ldr             x0, [fp, #0x18]
    // 0x854bd4: stur            x1, [fp, #-0x10]
    // 0x854bd8: LoadField: r2 = r0->field_b
    //     0x854bd8: ldur            w2, [x0, #0xb]
    // 0x854bdc: DecompressPointer r2
    //     0x854bdc: add             x2, x2, HEAP, lsl #32
    // 0x854be0: cmp             w2, NULL
    // 0x854be4: b.eq            #0x855034
    // 0x854be8: SaveReg r0
    //     0x854be8: str             x0, [SP, #-8]!
    // 0x854bec: r0 = _canRequestFocus()
    //     0x854bec: bl              #0x85504c  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_canRequestFocus
    // 0x854bf0: add             SP, SP, #8
    // 0x854bf4: stur            x0, [fp, #-0x18]
    // 0x854bf8: r1 = 1
    //     0x854bf8: mov             x1, #1
    // 0x854bfc: r0 = AllocateContext()
    //     0x854bfc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854c00: mov             x1, x0
    // 0x854c04: ldr             x0, [fp, #0x18]
    // 0x854c08: stur            x1, [fp, #-0x28]
    // 0x854c0c: StoreField: r1->field_f = r0
    //     0x854c0c: stur            w0, [x1, #0xf]
    // 0x854c10: LoadField: r2 = r0->field_b
    //     0x854c10: ldur            w2, [x0, #0xb]
    // 0x854c14: DecompressPointer r2
    //     0x854c14: add             x2, x2, HEAP, lsl #32
    // 0x854c18: stur            x2, [fp, #-0x20]
    // 0x854c1c: cmp             w2, NULL
    // 0x854c20: b.eq            #0x855038
    // 0x854c24: r1 = 1
    //     0x854c24: mov             x1, #1
    // 0x854c28: r0 = AllocateContext()
    //     0x854c28: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854c2c: mov             x1, x0
    // 0x854c30: ldr             x0, [fp, #0x18]
    // 0x854c34: stur            x1, [fp, #-0x30]
    // 0x854c38: StoreField: r1->field_f = r0
    //     0x854c38: stur            w0, [x1, #0xf]
    // 0x854c3c: r1 = 1
    //     0x854c3c: mov             x1, #1
    // 0x854c40: r0 = AllocateContext()
    //     0x854c40: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854c44: mov             x1, x0
    // 0x854c48: ldr             x0, [fp, #0x18]
    // 0x854c4c: stur            x1, [fp, #-0x40]
    // 0x854c50: StoreField: r1->field_f = r0
    //     0x854c50: stur            w0, [x1, #0xf]
    // 0x854c54: ldur            x2, [fp, #-0x20]
    // 0x854c58: LoadField: r3 = r2->field_f
    //     0x854c58: ldur            w3, [x2, #0xf]
    // 0x854c5c: DecompressPointer r3
    //     0x854c5c: add             x3, x3, HEAP, lsl #32
    // 0x854c60: stur            x3, [fp, #-0x38]
    // 0x854c64: cmp             w3, NULL
    // 0x854c68: b.ne            #0x854c78
    // 0x854c6c: mov             x0, x2
    // 0x854c70: r1 = Null
    //     0x854c70: mov             x1, NULL
    // 0x854c74: b               #0x854ca4
    // 0x854c78: r1 = 1
    //     0x854c78: mov             x1, #1
    // 0x854c7c: r0 = AllocateContext()
    //     0x854c7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854c80: mov             x1, x0
    // 0x854c84: ldr             x0, [fp, #0x18]
    // 0x854c88: StoreField: r1->field_f = r0
    //     0x854c88: stur            w0, [x1, #0xf]
    // 0x854c8c: mov             x2, x1
    // 0x854c90: r1 = Function 'simulateTap':.
    //     0x854c90: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e218] AnonymousClosure: (0x8597fc), in [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateTap (0x859878)
    //     0x854c94: ldr             x1, [x1, #0x218]
    // 0x854c98: r0 = AllocateClosure()
    //     0x854c98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854c9c: mov             x1, x0
    // 0x854ca0: ldur            x0, [fp, #-0x20]
    // 0x854ca4: stur            x1, [fp, #-0x50]
    // 0x854ca8: LoadField: r2 = r0->field_23
    //     0x854ca8: ldur            w2, [x0, #0x23]
    // 0x854cac: DecompressPointer r2
    //     0x854cac: add             x2, x2, HEAP, lsl #32
    // 0x854cb0: stur            x2, [fp, #-0x48]
    // 0x854cb4: cmp             w2, NULL
    // 0x854cb8: b.ne            #0x854cc4
    // 0x854cbc: r1 = Null
    //     0x854cbc: mov             x1, NULL
    // 0x854cc0: b               #0x854cf0
    // 0x854cc4: ldr             x0, [fp, #0x18]
    // 0x854cc8: r1 = 1
    //     0x854cc8: mov             x1, #1
    // 0x854ccc: r0 = AllocateContext()
    //     0x854ccc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854cd0: mov             x1, x0
    // 0x854cd4: ldr             x0, [fp, #0x18]
    // 0x854cd8: StoreField: r1->field_f = r0
    //     0x854cd8: stur            w0, [x1, #0xf]
    // 0x854cdc: mov             x2, x1
    // 0x854ce0: r1 = Function 'simulateLongPress':.
    //     0x854ce0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e220] AnonymousClosure: (0x85974c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateLongPress (0x859794)
    //     0x854ce4: ldr             x1, [x1, #0x220]
    // 0x854ce8: r0 = AllocateClosure()
    //     0x854ce8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854cec: mov             x1, x0
    // 0x854cf0: ldur            x0, [fp, #-0x38]
    // 0x854cf4: stur            x1, [fp, #-0x20]
    // 0x854cf8: cmp             w0, NULL
    // 0x854cfc: b.eq            #0x854d08
    // 0x854d00: ldur            x2, [fp, #-0x48]
    // 0x854d04: b               #0x854d14
    // 0x854d08: ldur            x2, [fp, #-0x48]
    // 0x854d0c: cmp             w2, NULL
    // 0x854d10: b.eq            #0x854d44
    // 0x854d14: ldr             x3, [fp, #0x18]
    // 0x854d18: r1 = 1
    //     0x854d18: mov             x1, #1
    // 0x854d1c: r0 = AllocateContext()
    //     0x854d1c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854d20: mov             x1, x0
    // 0x854d24: ldr             x0, [fp, #0x18]
    // 0x854d28: StoreField: r1->field_f = r0
    //     0x854d28: stur            w0, [x1, #0xf]
    // 0x854d2c: mov             x2, x1
    // 0x854d30: r1 = Function 'handleTapDown':.
    //     0x854d30: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e228] AnonymousClosure: (0x855fd8), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapDown (0x856024)
    //     0x854d34: ldr             x1, [x1, #0x228]
    // 0x854d38: r0 = AllocateClosure()
    //     0x854d38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854d3c: mov             x1, x0
    // 0x854d40: b               #0x854d48
    // 0x854d44: r1 = Null
    //     0x854d44: mov             x1, NULL
    // 0x854d48: ldur            x0, [fp, #-0x38]
    // 0x854d4c: stur            x1, [fp, #-0x58]
    // 0x854d50: cmp             w0, NULL
    // 0x854d54: b.eq            #0x854d60
    // 0x854d58: ldur            x2, [fp, #-0x48]
    // 0x854d5c: b               #0x854d6c
    // 0x854d60: ldur            x2, [fp, #-0x48]
    // 0x854d64: cmp             w2, NULL
    // 0x854d68: b.eq            #0x854d9c
    // 0x854d6c: ldr             x3, [fp, #0x18]
    // 0x854d70: r1 = 1
    //     0x854d70: mov             x1, #1
    // 0x854d74: r0 = AllocateContext()
    //     0x854d74: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854d78: mov             x1, x0
    // 0x854d7c: ldr             x0, [fp, #0x18]
    // 0x854d80: StoreField: r1->field_f = r0
    //     0x854d80: stur            w0, [x1, #0xf]
    // 0x854d84: mov             x2, x1
    // 0x854d88: r1 = Function 'handleTapUp':.
    //     0x854d88: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e230] AnonymousClosure: (0x5a6a48), of [package:flutter/src/material/ink_well.dart] _InkResponseState
    //     0x854d8c: ldr             x1, [x1, #0x230]
    // 0x854d90: r0 = AllocateClosure()
    //     0x854d90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854d94: mov             x1, x0
    // 0x854d98: b               #0x854da0
    // 0x854d9c: r1 = Null
    //     0x854d9c: mov             x1, NULL
    // 0x854da0: ldur            x0, [fp, #-0x38]
    // 0x854da4: stur            x1, [fp, #-0x60]
    // 0x854da8: cmp             w0, NULL
    // 0x854dac: b.ne            #0x854dbc
    // 0x854db0: ldur            x0, [fp, #-0x48]
    // 0x854db4: cmp             w0, NULL
    // 0x854db8: b.eq            #0x854de8
    // 0x854dbc: ldr             x0, [fp, #0x18]
    // 0x854dc0: r1 = 1
    //     0x854dc0: mov             x1, #1
    // 0x854dc4: r0 = AllocateContext()
    //     0x854dc4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854dc8: mov             x1, x0
    // 0x854dcc: ldr             x0, [fp, #0x18]
    // 0x854dd0: StoreField: r1->field_f = r0
    //     0x854dd0: stur            w0, [x1, #0xf]
    // 0x854dd4: mov             x2, x1
    // 0x854dd8: r1 = Function 'handleTap':.
    //     0x854dd8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e238] AnonymousClosure: (0x855b1c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTap (0x855b64)
    //     0x854ddc: ldr             x1, [x1, #0x238]
    // 0x854de0: r0 = AllocateClosure()
    //     0x854de0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854de4: b               #0x854dec
    // 0x854de8: r0 = Null
    //     0x854de8: mov             x0, NULL
    // 0x854dec: stur            x0, [fp, #-0x38]
    // 0x854df0: ldr             x16, [fp, #0x18]
    // 0x854df4: SaveReg r16
    //     0x854df4: str             x16, [SP, #-8]!
    // 0x854df8: r0 = enabled()
    //     0x854df8: bl              #0x7b18d0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0x854dfc: add             SP, SP, #8
    // 0x854e00: tbnz            w0, #4, #0x854e34
    // 0x854e04: ldr             x0, [fp, #0x18]
    // 0x854e08: r1 = 1
    //     0x854e08: mov             x1, #1
    // 0x854e0c: r0 = AllocateContext()
    //     0x854e0c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854e10: mov             x1, x0
    // 0x854e14: ldr             x0, [fp, #0x18]
    // 0x854e18: StoreField: r1->field_f = r0
    //     0x854e18: stur            w0, [x1, #0xf]
    // 0x854e1c: mov             x2, x1
    // 0x854e20: r1 = Function 'handleTapCancel':.
    //     0x854e20: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e240] AnonymousClosure: (0x85591c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapCancel (0x855964)
    //     0x854e24: ldr             x1, [x1, #0x240]
    // 0x854e28: r0 = AllocateClosure()
    //     0x854e28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854e2c: mov             x1, x0
    // 0x854e30: b               #0x854e38
    // 0x854e34: r1 = Null
    //     0x854e34: mov             x1, NULL
    // 0x854e38: ldr             x0, [fp, #0x18]
    // 0x854e3c: stur            x1, [fp, #-0x68]
    // 0x854e40: LoadField: r2 = r0->field_b
    //     0x854e40: ldur            w2, [x0, #0xb]
    // 0x854e44: DecompressPointer r2
    //     0x854e44: add             x2, x2, HEAP, lsl #32
    // 0x854e48: stur            x2, [fp, #-0x48]
    // 0x854e4c: cmp             w2, NULL
    // 0x854e50: b.eq            #0x85503c
    // 0x854e54: LoadField: r3 = r2->field_23
    //     0x854e54: ldur            w3, [x2, #0x23]
    // 0x854e58: DecompressPointer r3
    //     0x854e58: add             x3, x3, HEAP, lsl #32
    // 0x854e5c: cmp             w3, NULL
    // 0x854e60: b.eq            #0x854e90
    // 0x854e64: r1 = 1
    //     0x854e64: mov             x1, #1
    // 0x854e68: r0 = AllocateContext()
    //     0x854e68: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854e6c: mov             x1, x0
    // 0x854e70: ldr             x0, [fp, #0x18]
    // 0x854e74: StoreField: r1->field_f = r0
    //     0x854e74: stur            w0, [x1, #0xf]
    // 0x854e78: mov             x2, x1
    // 0x854e7c: r1 = Function 'handleLongPress':.
    //     0x854e7c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e248] AnonymousClosure: (0x855600), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleLongPress (0x855648)
    //     0x854e80: ldr             x1, [x1, #0x248]
    // 0x854e84: r0 = AllocateClosure()
    //     0x854e84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854e88: mov             x5, x0
    // 0x854e8c: b               #0x854e94
    // 0x854e90: r5 = Null
    //     0x854e90: mov             x5, NULL
    // 0x854e94: ldr             x0, [fp, #0x18]
    // 0x854e98: ldur            x4, [fp, #-8]
    // 0x854e9c: ldur            x2, [fp, #-0x18]
    // 0x854ea0: ldur            x1, [fp, #-0x48]
    // 0x854ea4: ldur            x3, [fp, #-0x10]
    // 0x854ea8: stur            x5, [fp, #-0x78]
    // 0x854eac: LoadField: r6 = r1->field_b
    //     0x854eac: ldur            w6, [x1, #0xb]
    // 0x854eb0: DecompressPointer r6
    //     0x854eb0: add             x6, x6, HEAP, lsl #32
    // 0x854eb4: stur            x6, [fp, #-0x70]
    // 0x854eb8: r0 = GestureDetector()
    //     0x854eb8: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x854ebc: stur            x0, [fp, #-0x48]
    // 0x854ec0: ldur            x16, [fp, #-0x58]
    // 0x854ec4: stp             x16, x0, [SP, #-0x10]!
    // 0x854ec8: ldur            x16, [fp, #-0x60]
    // 0x854ecc: ldur            lr, [fp, #-0x38]
    // 0x854ed0: stp             lr, x16, [SP, #-0x10]!
    // 0x854ed4: ldur            x16, [fp, #-0x68]
    // 0x854ed8: stp             NULL, x16, [SP, #-0x10]!
    // 0x854edc: ldur            x16, [fp, #-0x78]
    // 0x854ee0: r30 = Instance_HitTestBehavior
    //     0x854ee0: add             lr, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x854ee4: ldr             lr, [lr, #0x408]
    // 0x854ee8: stp             lr, x16, [SP, #-0x10]!
    // 0x854eec: r16 = true
    //     0x854eec: add             x16, NULL, #0x20  ; true
    // 0x854ef0: ldur            lr, [fp, #-0x70]
    // 0x854ef4: stp             lr, x16, [SP, #-0x10]!
    // 0x854ef8: r4 = const [0, 0xa, 0xa, 0x1, behavior, 0x7, child, 0x9, excludeFromSemantics, 0x8, onDoubleTap, 0x5, onLongPress, 0x6, onTap, 0x3, onTapCancel, 0x4, onTapDown, 0x1, onTapUp, 0x2, null]
    //     0x854ef8: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e250] List(23) [0, 0xa, 0xa, 0x1, "behavior", 0x7, "child", 0x9, "excludeFromSemantics", 0x8, "onDoubleTap", 0x5, "onLongPress", 0x6, "onTap", 0x3, "onTapCancel", 0x4, "onTapDown", 0x1, "onTapUp", 0x2, Null]
    //     0x854efc: ldr             x4, [x4, #0x250]
    // 0x854f00: r0 = GestureDetector()
    //     0x854f00: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x854f04: add             SP, SP, #0x50
    // 0x854f08: r0 = Semantics()
    //     0x854f08: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x854f0c: stur            x0, [fp, #-0x38]
    // 0x854f10: ldur            x16, [fp, #-0x50]
    // 0x854f14: stp             x16, x0, [SP, #-0x10]!
    // 0x854f18: ldur            x16, [fp, #-0x20]
    // 0x854f1c: ldur            lr, [fp, #-0x48]
    // 0x854f20: stp             lr, x16, [SP, #-0x10]!
    // 0x854f24: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, onLongPress, 0x2, onTap, 0x1, null]
    //     0x854f24: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e258] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "onLongPress", 0x2, "onTap", 0x1, Null]
    //     0x854f28: ldr             x4, [x4, #0x258]
    // 0x854f2c: r0 = Semantics()
    //     0x854f2c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x854f30: add             SP, SP, #0x20
    // 0x854f34: ldur            x2, [fp, #-0x30]
    // 0x854f38: r1 = Function 'handleMouseEnter':.
    //     0x854f38: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e260] AnonymousClosure: (0x85553c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseEnter (0x855588)
    //     0x854f3c: ldr             x1, [x1, #0x260]
    // 0x854f40: r0 = AllocateClosure()
    //     0x854f40: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854f44: stur            x0, [fp, #-0x20]
    // 0x854f48: r0 = MouseRegion()
    //     0x854f48: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0x854f4c: mov             x3, x0
    // 0x854f50: ldur            x0, [fp, #-0x20]
    // 0x854f54: stur            x3, [fp, #-0x30]
    // 0x854f58: StoreField: r3->field_f = r0
    //     0x854f58: stur            w0, [x3, #0xf]
    // 0x854f5c: ldur            x2, [fp, #-0x40]
    // 0x854f60: r1 = Function 'handleMouseExit':.
    //     0x854f60: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e268] AnonymousClosure: (0x855458), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseExit (0x8554a4)
    //     0x854f64: ldr             x1, [x1, #0x268]
    // 0x854f68: r0 = AllocateClosure()
    //     0x854f68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854f6c: mov             x1, x0
    // 0x854f70: ldur            x0, [fp, #-0x30]
    // 0x854f74: StoreField: r0->field_17 = r1
    //     0x854f74: stur            w1, [x0, #0x17]
    // 0x854f78: ldur            x1, [fp, #-8]
    // 0x854f7c: StoreField: r0->field_1b = r1
    //     0x854f7c: stur            w1, [x0, #0x1b]
    // 0x854f80: r1 = true
    //     0x854f80: add             x1, NULL, #0x20  ; true
    // 0x854f84: StoreField: r0->field_1f = r1
    //     0x854f84: stur            w1, [x0, #0x1f]
    // 0x854f88: ldur            x2, [fp, #-0x38]
    // 0x854f8c: StoreField: r0->field_b = r2
    //     0x854f8c: stur            w2, [x0, #0xb]
    // 0x854f90: r0 = Focus()
    //     0x854f90: bl              #0x834690  ; AllocateFocusStub -> Focus (size=0x40)
    // 0x854f94: mov             x3, x0
    // 0x854f98: ldur            x0, [fp, #-0x30]
    // 0x854f9c: stur            x3, [fp, #-8]
    // 0x854fa0: StoreField: r3->field_f = r0
    //     0x854fa0: stur            w0, [x3, #0xf]
    // 0x854fa4: r0 = false
    //     0x854fa4: add             x0, NULL, #0x30  ; false
    // 0x854fa8: StoreField: r3->field_17 = r0
    //     0x854fa8: stur            w0, [x3, #0x17]
    // 0x854fac: ldur            x2, [fp, #-0x28]
    // 0x854fb0: r1 = Function 'handleFocusUpdate':.
    //     0x854fb0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e270] AnonymousClosure: (0x85532c), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusUpdate (0x855378)
    //     0x854fb4: ldr             x1, [x1, #0x270]
    // 0x854fb8: r0 = AllocateClosure()
    //     0x854fb8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854fbc: mov             x1, x0
    // 0x854fc0: ldur            x0, [fp, #-8]
    // 0x854fc4: StoreField: r0->field_1b = r1
    //     0x854fc4: stur            w1, [x0, #0x1b]
    // 0x854fc8: r1 = true
    //     0x854fc8: add             x1, NULL, #0x20  ; true
    // 0x854fcc: StoreField: r0->field_37 = r1
    //     0x854fcc: stur            w1, [x0, #0x37]
    // 0x854fd0: ldur            x1, [fp, #-0x18]
    // 0x854fd4: StoreField: r0->field_27 = r1
    //     0x854fd4: stur            w1, [x0, #0x27]
    // 0x854fd8: r0 = Actions()
    //     0x854fd8: bl              #0x834684  ; AllocateActionsStub -> Actions (size=0x18)
    // 0x854fdc: mov             x1, x0
    // 0x854fe0: ldur            x0, [fp, #-0x10]
    // 0x854fe4: stur            x1, [fp, #-0x18]
    // 0x854fe8: StoreField: r1->field_f = r0
    //     0x854fe8: stur            w0, [x1, #0xf]
    // 0x854fec: ldur            x0, [fp, #-8]
    // 0x854ff0: StoreField: r1->field_13 = r0
    //     0x854ff0: stur            w0, [x1, #0x13]
    // 0x854ff4: r0 = _ParentInkResponseProvider()
    //     0x854ff4: bl              #0x855040  ; Allocate_ParentInkResponseProviderStub -> _ParentInkResponseProvider (size=0x14)
    // 0x854ff8: ldr             x1, [fp, #0x18]
    // 0x854ffc: StoreField: r0->field_f = r1
    //     0x854ffc: stur            w1, [x0, #0xf]
    // 0x855000: ldur            x1, [fp, #-0x18]
    // 0x855004: StoreField: r0->field_b = r1
    //     0x855004: stur            w1, [x0, #0xb]
    // 0x855008: LeaveFrame
    //     0x855008: mov             SP, fp
    //     0x85500c: ldp             fp, lr, [SP], #0x10
    // 0x855010: ret
    //     0x855010: ret             
    // 0x855014: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855014: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855018: b               #0x854880
    // 0x85501c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85501c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855020: b               #0x854904
    // 0x855024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855024: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85502c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85502c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855030: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855030: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855034: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855034: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855038: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855038: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85503c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85503c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _canRequestFocus(/* No info */) {
    // ** addr: 0x85504c, size: 0xd0
    // 0x85504c: EnterFrame
    //     0x85504c: stp             fp, lr, [SP, #-0x10]!
    //     0x855050: mov             fp, SP
    // 0x855054: CheckStackOverflow
    //     0x855054: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855058: cmp             SP, x16
    //     0x85505c: b.ls            #0x85510c
    // 0x855060: ldr             x0, [fp, #0x10]
    // 0x855064: LoadField: r1 = r0->field_f
    //     0x855064: ldur            w1, [x0, #0xf]
    // 0x855068: DecompressPointer r1
    //     0x855068: add             x1, x1, HEAP, lsl #32
    // 0x85506c: cmp             w1, NULL
    // 0x855070: b.eq            #0x855114
    // 0x855074: SaveReg r1
    //     0x855074: str             x1, [SP, #-8]!
    // 0x855078: r0 = maybeOf()
    //     0x855078: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x85507c: add             SP, SP, #8
    // 0x855080: cmp             w0, NULL
    // 0x855084: b.ne            #0x855090
    // 0x855088: r0 = Null
    //     0x855088: mov             x0, NULL
    // 0x85508c: b               #0x855098
    // 0x855090: r0 = Instance_NavigationMode
    //     0x855090: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x855094: ldr             x0, [x0, #0x4f0]
    // 0x855098: cmp             w0, NULL
    // 0x85509c: b.ne            #0x8550a8
    // 0x8550a0: r0 = Instance_NavigationMode
    //     0x8550a0: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c4f0] Obj!NavigationMode@b63ab1
    //     0x8550a4: ldr             x0, [x0, #0x4f0]
    // 0x8550a8: LoadField: r1 = r0->field_7
    //     0x8550a8: ldur            x1, [x0, #7]
    // 0x8550ac: cmp             x1, #0
    // 0x8550b0: b.gt            #0x8550fc
    // 0x8550b4: ldr             x16, [fp, #0x10]
    // 0x8550b8: SaveReg r16
    //     0x8550b8: str             x16, [SP, #-8]!
    // 0x8550bc: r0 = enabled()
    //     0x8550bc: bl              #0x7b18d0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::enabled
    // 0x8550c0: add             SP, SP, #8
    // 0x8550c4: tbnz            w0, #4, #0x8550ec
    // 0x8550c8: ldr             x1, [fp, #0x10]
    // 0x8550cc: LoadField: r2 = r1->field_b
    //     0x8550cc: ldur            w2, [x1, #0xb]
    // 0x8550d0: DecompressPointer r2
    //     0x8550d0: add             x2, x2, HEAP, lsl #32
    // 0x8550d4: cmp             w2, NULL
    // 0x8550d8: b.eq            #0x855118
    // 0x8550dc: LoadField: r1 = r2->field_73
    //     0x8550dc: ldur            w1, [x2, #0x73]
    // 0x8550e0: DecompressPointer r1
    //     0x8550e0: add             x1, x1, HEAP, lsl #32
    // 0x8550e4: mov             x0, x1
    // 0x8550e8: b               #0x8550f0
    // 0x8550ec: r0 = false
    //     0x8550ec: add             x0, NULL, #0x30  ; false
    // 0x8550f0: LeaveFrame
    //     0x8550f0: mov             SP, fp
    //     0x8550f4: ldp             fp, lr, [SP], #0x10
    // 0x8550f8: ret
    //     0x8550f8: ret             
    // 0x8550fc: r0 = true
    //     0x8550fc: add             x0, NULL, #0x20  ; true
    // 0x855100: LeaveFrame
    //     0x855100: mov             SP, fp
    //     0x855104: ldp             fp, lr, [SP], #0x10
    // 0x855108: ret
    //     0x855108: ret             
    // 0x85510c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85510c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855110: b               #0x855060
    // 0x855114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855114: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855118: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleFocusUpdate(dynamic, bool) {
    // ** addr: 0x85532c, size: 0x4c
    // 0x85532c: EnterFrame
    //     0x85532c: stp             fp, lr, [SP, #-0x10]!
    //     0x855330: mov             fp, SP
    // 0x855334: ldr             x0, [fp, #0x18]
    // 0x855338: LoadField: r1 = r0->field_17
    //     0x855338: ldur            w1, [x0, #0x17]
    // 0x85533c: DecompressPointer r1
    //     0x85533c: add             x1, x1, HEAP, lsl #32
    // 0x855340: CheckStackOverflow
    //     0x855340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855344: cmp             SP, x16
    //     0x855348: b.ls            #0x855370
    // 0x85534c: LoadField: r0 = r1->field_f
    //     0x85534c: ldur            w0, [x1, #0xf]
    // 0x855350: DecompressPointer r0
    //     0x855350: add             x0, x0, HEAP, lsl #32
    // 0x855354: ldr             x16, [fp, #0x10]
    // 0x855358: stp             x16, x0, [SP, #-0x10]!
    // 0x85535c: r0 = handleFocusUpdate()
    //     0x85535c: bl              #0x855378  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusUpdate
    // 0x855360: add             SP, SP, #0x10
    // 0x855364: LeaveFrame
    //     0x855364: mov             SP, fp
    //     0x855368: ldp             fp, lr, [SP], #0x10
    // 0x85536c: ret
    //     0x85536c: ret             
    // 0x855370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855370: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855374: b               #0x85534c
  }
  _ handleFocusUpdate(/* No info */) {
    // ** addr: 0x855378, size: 0xe0
    // 0x855378: EnterFrame
    //     0x855378: stp             fp, lr, [SP, #-0x10]!
    //     0x85537c: mov             fp, SP
    // 0x855380: CheckStackOverflow
    //     0x855380: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855384: cmp             SP, x16
    //     0x855388: b.ls            #0x855444
    // 0x85538c: ldr             x1, [fp, #0x18]
    // 0x855390: ldr             x0, [fp, #0x10]
    // 0x855394: StoreField: r1->field_33 = r0
    //     0x855394: stur            w0, [x1, #0x33]
    // 0x855398: LoadField: r2 = r1->field_b
    //     0x855398: ldur            w2, [x1, #0xb]
    // 0x85539c: DecompressPointer r2
    //     0x85539c: add             x2, x2, HEAP, lsl #32
    // 0x8553a0: cmp             w2, NULL
    // 0x8553a4: b.eq            #0x85544c
    // 0x8553a8: LoadField: r3 = r2->field_7f
    //     0x8553a8: ldur            w3, [x2, #0x7f]
    // 0x8553ac: DecompressPointer r3
    //     0x8553ac: add             x3, x3, HEAP, lsl #32
    // 0x8553b0: cmp             w3, NULL
    // 0x8553b4: b.ne            #0x8553cc
    // 0x8553b8: LoadField: r2 = r1->field_2b
    //     0x8553b8: ldur            w2, [x1, #0x2b]
    // 0x8553bc: DecompressPointer r2
    //     0x8553bc: add             x2, x2, HEAP, lsl #32
    // 0x8553c0: cmp             w2, NULL
    // 0x8553c4: b.eq            #0x855450
    // 0x8553c8: b               #0x8553d0
    // 0x8553cc: mov             x2, x3
    // 0x8553d0: r16 = Instance_MaterialState
    //     0x8553d0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x8553d4: ldr             x16, [x16, #0xf88]
    // 0x8553d8: stp             x16, x2, [SP, #-0x10]!
    // 0x8553dc: SaveReg r0
    //     0x8553dc: str             x0, [SP, #-8]!
    // 0x8553e0: r0 = update()
    //     0x8553e0: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x8553e4: add             SP, SP, #0x18
    // 0x8553e8: ldr             x16, [fp, #0x18]
    // 0x8553ec: SaveReg r16
    //     0x8553ec: str             x16, [SP, #-8]!
    // 0x8553f0: r0 = updateFocusHighlights()
    //     0x8553f0: bl              #0x7b1718  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateFocusHighlights
    // 0x8553f4: add             SP, SP, #8
    // 0x8553f8: ldr             x0, [fp, #0x18]
    // 0x8553fc: LoadField: r1 = r0->field_b
    //     0x8553fc: ldur            w1, [x0, #0xb]
    // 0x855400: DecompressPointer r1
    //     0x855400: add             x1, x1, HEAP, lsl #32
    // 0x855404: cmp             w1, NULL
    // 0x855408: b.eq            #0x855454
    // 0x85540c: LoadField: r0 = r1->field_67
    //     0x85540c: ldur            w0, [x1, #0x67]
    // 0x855410: DecompressPointer r0
    //     0x855410: add             x0, x0, HEAP, lsl #32
    // 0x855414: cmp             w0, NULL
    // 0x855418: b.eq            #0x855434
    // 0x85541c: ldr             x16, [fp, #0x10]
    // 0x855420: stp             x16, x0, [SP, #-0x10]!
    // 0x855424: ClosureCall
    //     0x855424: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x855428: ldur            x2, [x0, #0x1f]
    //     0x85542c: blr             x2
    // 0x855430: add             SP, SP, #0x10
    // 0x855434: r0 = Null
    //     0x855434: mov             x0, NULL
    // 0x855438: LeaveFrame
    //     0x855438: mov             SP, fp
    //     0x85543c: ldp             fp, lr, [SP], #0x10
    // 0x855440: ret
    //     0x855440: ret             
    // 0x855444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855444: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855448: b               #0x85538c
    // 0x85544c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85544c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855450: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855454: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855454: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleMouseExit(dynamic, PointerExitEvent) {
    // ** addr: 0x855458, size: 0x4c
    // 0x855458: EnterFrame
    //     0x855458: stp             fp, lr, [SP, #-0x10]!
    //     0x85545c: mov             fp, SP
    // 0x855460: ldr             x0, [fp, #0x18]
    // 0x855464: LoadField: r1 = r0->field_17
    //     0x855464: ldur            w1, [x0, #0x17]
    // 0x855468: DecompressPointer r1
    //     0x855468: add             x1, x1, HEAP, lsl #32
    // 0x85546c: CheckStackOverflow
    //     0x85546c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855470: cmp             SP, x16
    //     0x855474: b.ls            #0x85549c
    // 0x855478: LoadField: r0 = r1->field_f
    //     0x855478: ldur            w0, [x1, #0xf]
    // 0x85547c: DecompressPointer r0
    //     0x85547c: add             x0, x0, HEAP, lsl #32
    // 0x855480: ldr             x16, [fp, #0x10]
    // 0x855484: stp             x16, x0, [SP, #-0x10]!
    // 0x855488: r0 = handleMouseExit()
    //     0x855488: bl              #0x8554a4  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseExit
    // 0x85548c: add             SP, SP, #0x10
    // 0x855490: LeaveFrame
    //     0x855490: mov             SP, fp
    //     0x855494: ldp             fp, lr, [SP], #0x10
    // 0x855498: ret
    //     0x855498: ret             
    // 0x85549c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85549c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8554a0: b               #0x855478
  }
  _ handleMouseExit(/* No info */) {
    // ** addr: 0x8554a4, size: 0x44
    // 0x8554a4: EnterFrame
    //     0x8554a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8554a8: mov             fp, SP
    // 0x8554ac: r0 = false
    //     0x8554ac: add             x0, NULL, #0x30  ; false
    // 0x8554b0: CheckStackOverflow
    //     0x8554b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8554b4: cmp             SP, x16
    //     0x8554b8: b.ls            #0x8554e0
    // 0x8554bc: ldr             x1, [fp, #0x18]
    // 0x8554c0: StoreField: r1->field_1f = r0
    //     0x8554c0: stur            w0, [x1, #0x1f]
    // 0x8554c4: SaveReg r1
    //     0x8554c4: str             x1, [SP, #-8]!
    // 0x8554c8: r0 = handleHoverChange()
    //     0x8554c8: bl              #0x8554e8  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleHoverChange
    // 0x8554cc: add             SP, SP, #8
    // 0x8554d0: r0 = Null
    //     0x8554d0: mov             x0, NULL
    // 0x8554d4: LeaveFrame
    //     0x8554d4: mov             SP, fp
    //     0x8554d8: ldp             fp, lr, [SP], #0x10
    // 0x8554dc: ret
    //     0x8554dc: ret             
    // 0x8554e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8554e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8554e4: b               #0x8554bc
  }
  _ handleHoverChange(/* No info */) {
    // ** addr: 0x8554e8, size: 0x54
    // 0x8554e8: EnterFrame
    //     0x8554e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8554ec: mov             fp, SP
    // 0x8554f0: CheckStackOverflow
    //     0x8554f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8554f4: cmp             SP, x16
    //     0x8554f8: b.ls            #0x855534
    // 0x8554fc: ldr             x0, [fp, #0x10]
    // 0x855500: LoadField: r1 = r0->field_1f
    //     0x855500: ldur            w1, [x0, #0x1f]
    // 0x855504: DecompressPointer r1
    //     0x855504: add             x1, x1, HEAP, lsl #32
    // 0x855508: r16 = Instance__HighlightType
    //     0x855508: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2c8] Obj!_HighlightType@b65851
    //     0x85550c: ldr             x16, [x16, #0x2c8]
    // 0x855510: stp             x16, x0, [SP, #-0x10]!
    // 0x855514: SaveReg r1
    //     0x855514: str             x1, [SP, #-8]!
    // 0x855518: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x855518: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x85551c: r0 = updateHighlight()
    //     0x85551c: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x855520: add             SP, SP, #0x18
    // 0x855524: r0 = Null
    //     0x855524: mov             x0, NULL
    // 0x855528: LeaveFrame
    //     0x855528: mov             SP, fp
    //     0x85552c: ldp             fp, lr, [SP], #0x10
    // 0x855530: ret
    //     0x855530: ret             
    // 0x855534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855538: b               #0x8554fc
  }
  [closure] void handleMouseEnter(dynamic, PointerEnterEvent) {
    // ** addr: 0x85553c, size: 0x4c
    // 0x85553c: EnterFrame
    //     0x85553c: stp             fp, lr, [SP, #-0x10]!
    //     0x855540: mov             fp, SP
    // 0x855544: ldr             x0, [fp, #0x18]
    // 0x855548: LoadField: r1 = r0->field_17
    //     0x855548: ldur            w1, [x0, #0x17]
    // 0x85554c: DecompressPointer r1
    //     0x85554c: add             x1, x1, HEAP, lsl #32
    // 0x855550: CheckStackOverflow
    //     0x855550: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855554: cmp             SP, x16
    //     0x855558: b.ls            #0x855580
    // 0x85555c: LoadField: r0 = r1->field_f
    //     0x85555c: ldur            w0, [x1, #0xf]
    // 0x855560: DecompressPointer r0
    //     0x855560: add             x0, x0, HEAP, lsl #32
    // 0x855564: ldr             x16, [fp, #0x10]
    // 0x855568: stp             x16, x0, [SP, #-0x10]!
    // 0x85556c: r0 = handleMouseEnter()
    //     0x85556c: bl              #0x855588  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleMouseEnter
    // 0x855570: add             SP, SP, #0x10
    // 0x855574: LeaveFrame
    //     0x855574: mov             SP, fp
    //     0x855578: ldp             fp, lr, [SP], #0x10
    // 0x85557c: ret
    //     0x85557c: ret             
    // 0x855580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855584: b               #0x85555c
  }
  _ handleMouseEnter(/* No info */) {
    // ** addr: 0x855588, size: 0x78
    // 0x855588: EnterFrame
    //     0x855588: stp             fp, lr, [SP, #-0x10]!
    //     0x85558c: mov             fp, SP
    // 0x855590: r0 = true
    //     0x855590: add             x0, NULL, #0x20  ; true
    // 0x855594: CheckStackOverflow
    //     0x855594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855598: cmp             SP, x16
    //     0x85559c: b.ls            #0x8555f4
    // 0x8555a0: ldr             x1, [fp, #0x18]
    // 0x8555a4: StoreField: r1->field_1f = r0
    //     0x8555a4: stur            w0, [x1, #0x1f]
    // 0x8555a8: LoadField: r0 = r1->field_b
    //     0x8555a8: ldur            w0, [x1, #0xb]
    // 0x8555ac: DecompressPointer r0
    //     0x8555ac: add             x0, x0, HEAP, lsl #32
    // 0x8555b0: cmp             w0, NULL
    // 0x8555b4: b.eq            #0x8555fc
    // 0x8555b8: LoadField: r2 = r0->field_f
    //     0x8555b8: ldur            w2, [x0, #0xf]
    // 0x8555bc: DecompressPointer r2
    //     0x8555bc: add             x2, x2, HEAP, lsl #32
    // 0x8555c0: cmp             w2, NULL
    // 0x8555c4: b.ne            #0x8555d8
    // 0x8555c8: LoadField: r2 = r0->field_23
    //     0x8555c8: ldur            w2, [x0, #0x23]
    // 0x8555cc: DecompressPointer r2
    //     0x8555cc: add             x2, x2, HEAP, lsl #32
    // 0x8555d0: cmp             w2, NULL
    // 0x8555d4: b.eq            #0x8555e4
    // 0x8555d8: SaveReg r1
    //     0x8555d8: str             x1, [SP, #-8]!
    // 0x8555dc: r0 = handleHoverChange()
    //     0x8555dc: bl              #0x8554e8  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleHoverChange
    // 0x8555e0: add             SP, SP, #8
    // 0x8555e4: r0 = Null
    //     0x8555e4: mov             x0, NULL
    // 0x8555e8: LeaveFrame
    //     0x8555e8: mov             SP, fp
    //     0x8555ec: ldp             fp, lr, [SP], #0x10
    // 0x8555f0: ret
    //     0x8555f0: ret             
    // 0x8555f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8555f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8555f8: b               #0x8555a0
    // 0x8555fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8555fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleLongPress(dynamic) {
    // ** addr: 0x855600, size: 0x48
    // 0x855600: EnterFrame
    //     0x855600: stp             fp, lr, [SP, #-0x10]!
    //     0x855604: mov             fp, SP
    // 0x855608: ldr             x0, [fp, #0x10]
    // 0x85560c: LoadField: r1 = r0->field_17
    //     0x85560c: ldur            w1, [x0, #0x17]
    // 0x855610: DecompressPointer r1
    //     0x855610: add             x1, x1, HEAP, lsl #32
    // 0x855614: CheckStackOverflow
    //     0x855614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855618: cmp             SP, x16
    //     0x85561c: b.ls            #0x855640
    // 0x855620: LoadField: r0 = r1->field_f
    //     0x855620: ldur            w0, [x1, #0xf]
    // 0x855624: DecompressPointer r0
    //     0x855624: add             x0, x0, HEAP, lsl #32
    // 0x855628: SaveReg r0
    //     0x855628: str             x0, [SP, #-8]!
    // 0x85562c: r0 = handleLongPress()
    //     0x85562c: bl              #0x855648  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleLongPress
    // 0x855630: add             SP, SP, #8
    // 0x855634: LeaveFrame
    //     0x855634: mov             SP, fp
    //     0x855638: ldp             fp, lr, [SP], #0x10
    // 0x85563c: ret
    //     0x85563c: ret             
    // 0x855640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855640: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855644: b               #0x855620
  }
  _ handleLongPress(/* No info */) {
    // ** addr: 0x855648, size: 0x2d4
    // 0x855648: EnterFrame
    //     0x855648: stp             fp, lr, [SP, #-0x10]!
    //     0x85564c: mov             fp, SP
    // 0x855650: AllocStack(0x18)
    //     0x855650: sub             SP, SP, #0x18
    // 0x855654: CheckStackOverflow
    //     0x855654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855658: cmp             SP, x16
    //     0x85565c: b.ls            #0x8558a4
    // 0x855660: ldr             x0, [fp, #0x10]
    // 0x855664: LoadField: r1 = r0->field_1b
    //     0x855664: ldur            w1, [x0, #0x1b]
    // 0x855668: DecompressPointer r1
    //     0x855668: add             x1, x1, HEAP, lsl #32
    // 0x85566c: stur            x1, [fp, #-0x18]
    // 0x855670: cmp             w1, NULL
    // 0x855674: b.eq            #0x855810
    // 0x855678: r2 = LoadClassIdInstr(r1)
    //     0x855678: ldur            x2, [x1, #-1]
    //     0x85567c: ubfx            x2, x2, #0xc, #0x14
    // 0x855680: lsl             x2, x2, #1
    // 0x855684: r17 = 4392
    //     0x855684: mov             x17, #0x1128
    // 0x855688: cmp             w2, w17
    // 0x85568c: b.ne            #0x855754
    // 0x855690: d0 = 1.000000
    //     0x855690: fmov            d0, #1.00000000
    // 0x855694: LoadField: d1 = r1->field_23
    //     0x855694: ldur            d1, [x1, #0x23]
    // 0x855698: fdiv            d2, d1, d0
    // 0x85569c: fcmp            d2, d2
    // 0x8556a0: b.vs            #0x8558ac
    // 0x8556a4: fcvtms          x2, d2
    // 0x8556a8: asr             x16, x2, #0x1e
    // 0x8556ac: cmp             x16, x2, asr #63
    // 0x8556b0: b.ne            #0x8558ac
    // 0x8556b4: lsl             x2, x2, #1
    // 0x8556b8: LoadField: r3 = r1->field_3b
    //     0x8556b8: ldur            w3, [x1, #0x3b]
    // 0x8556bc: DecompressPointer r3
    //     0x8556bc: add             x3, x3, HEAP, lsl #32
    // 0x8556c0: r16 = Sentinel
    //     0x8556c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8556c4: cmp             w3, w16
    // 0x8556c8: b.eq            #0x8558d8
    // 0x8556cc: stur            x3, [fp, #-0x10]
    // 0x8556d0: r4 = LoadInt32Instr(r2)
    //     0x8556d0: sbfx            x4, x2, #1, #0x1f
    //     0x8556d4: tbz             w2, #0, #0x8556dc
    //     0x8556d8: ldur            x4, [x2, #7]
    // 0x8556dc: r16 = 1000
    //     0x8556dc: mov             x16, #0x3e8
    // 0x8556e0: mul             x2, x4, x16
    // 0x8556e4: stur            x2, [fp, #-8]
    // 0x8556e8: r0 = Duration()
    //     0x8556e8: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x8556ec: mov             x1, x0
    // 0x8556f0: ldur            x0, [fp, #-8]
    // 0x8556f4: StoreField: r1->field_7 = r0
    //     0x8556f4: stur            x0, [x1, #7]
    // 0x8556f8: mov             x0, x1
    // 0x8556fc: ldur            x1, [fp, #-0x10]
    // 0x855700: StoreField: r1->field_27 = r0
    //     0x855700: stur            w0, [x1, #0x27]
    //     0x855704: ldurb           w16, [x1, #-1]
    //     0x855708: ldurb           w17, [x0, #-1]
    //     0x85570c: and             x16, x17, x16, lsr #2
    //     0x855710: tst             x16, HEAP, lsr #32
    //     0x855714: b.eq            #0x85571c
    //     0x855718: bl              #0xd6826c
    // 0x85571c: SaveReg r1
    //     0x85571c: str             x1, [SP, #-8]!
    // 0x855720: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855720: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855724: r0 = forward()
    //     0x855724: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x855728: add             SP, SP, #8
    // 0x85572c: ldur            x0, [fp, #-0x18]
    // 0x855730: LoadField: r1 = r0->field_43
    //     0x855730: ldur            w1, [x0, #0x43]
    // 0x855734: DecompressPointer r1
    //     0x855734: add             x1, x1, HEAP, lsl #32
    // 0x855738: cmp             w1, NULL
    // 0x85573c: b.eq            #0x8558e4
    // 0x855740: SaveReg r1
    //     0x855740: str             x1, [SP, #-8]!
    // 0x855744: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855744: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855748: r0 = forward()
    //     0x855748: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x85574c: add             SP, SP, #8
    // 0x855750: b               #0x85580c
    // 0x855754: mov             x0, x1
    // 0x855758: d0 = 1.000000
    //     0x855758: fmov            d0, #1.00000000
    // 0x85575c: r17 = 4394
    //     0x85575c: mov             x17, #0x112a
    // 0x855760: cmp             w2, w17
    // 0x855764: b.eq            #0x85580c
    // 0x855768: r17 = 4396
    //     0x855768: mov             x17, #0x112c
    // 0x85576c: cmp             w2, w17
    // 0x855770: b.ne            #0x85580c
    // 0x855774: r1 = Instance_Duration
    //     0x855774: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e2d0] Obj!Duration@b67bb1
    //     0x855778: ldr             x1, [x1, #0x2d0]
    // 0x85577c: LoadField: r2 = r0->field_37
    //     0x85577c: ldur            w2, [x0, #0x37]
    // 0x855780: DecompressPointer r2
    //     0x855780: add             x2, x2, HEAP, lsl #32
    // 0x855784: r16 = Sentinel
    //     0x855784: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855788: cmp             w2, w16
    // 0x85578c: b.eq            #0x8558e8
    // 0x855790: StoreField: r2->field_27 = r1
    //     0x855790: stur            w1, [x2, #0x27]
    // 0x855794: SaveReg r2
    //     0x855794: str             x2, [SP, #-8]!
    // 0x855798: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855798: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x85579c: r0 = forward()
    //     0x85579c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x8557a0: add             SP, SP, #8
    // 0x8557a4: ldur            x0, [fp, #-0x18]
    // 0x8557a8: LoadField: r1 = r0->field_3f
    //     0x8557a8: ldur            w1, [x0, #0x3f]
    // 0x8557ac: DecompressPointer r1
    //     0x8557ac: add             x1, x1, HEAP, lsl #32
    // 0x8557b0: r16 = Sentinel
    //     0x8557b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8557b4: cmp             w1, w16
    // 0x8557b8: b.eq            #0x8558f4
    // 0x8557bc: SaveReg r1
    //     0x8557bc: str             x1, [SP, #-8]!
    // 0x8557c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8557c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8557c4: r0 = forward()
    //     0x8557c4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x8557c8: add             SP, SP, #8
    // 0x8557cc: ldur            x0, [fp, #-0x18]
    // 0x8557d0: LoadField: r1 = r0->field_47
    //     0x8557d0: ldur            w1, [x0, #0x47]
    // 0x8557d4: DecompressPointer r1
    //     0x8557d4: add             x1, x1, HEAP, lsl #32
    // 0x8557d8: r16 = Sentinel
    //     0x8557d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8557dc: cmp             w1, w16
    // 0x8557e0: b.eq            #0x855900
    // 0x8557e4: SaveReg r1
    //     0x8557e4: str             x1, [SP, #-8]!
    // 0x8557e8: d0 = 1.000000
    //     0x8557e8: fmov            d0, #1.00000000
    // 0x8557ec: SaveReg d0
    //     0x8557ec: str             d0, [SP, #-8]!
    // 0x8557f0: r16 = Instance_Duration
    //     0x8557f0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2d8] Obj!Duration@b67ba1
    //     0x8557f4: ldr             x16, [x16, #0x2d8]
    // 0x8557f8: SaveReg r16
    //     0x8557f8: str             x16, [SP, #-8]!
    // 0x8557fc: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x8557fc: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x855800: ldr             x4, [x4, #0xa0]
    // 0x855804: r0 = animateTo()
    //     0x855804: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x855808: add             SP, SP, #0x18
    // 0x85580c: ldr             x0, [fp, #0x10]
    // 0x855810: StoreField: r0->field_1b = rNULL
    //     0x855810: stur            NULL, [x0, #0x1b]
    // 0x855814: LoadField: r1 = r0->field_b
    //     0x855814: ldur            w1, [x0, #0xb]
    // 0x855818: DecompressPointer r1
    //     0x855818: add             x1, x1, HEAP, lsl #32
    // 0x85581c: cmp             w1, NULL
    // 0x855820: b.eq            #0x85590c
    // 0x855824: LoadField: r2 = r1->field_23
    //     0x855824: ldur            w2, [x1, #0x23]
    // 0x855828: DecompressPointer r2
    //     0x855828: add             x2, x2, HEAP, lsl #32
    // 0x85582c: cmp             w2, NULL
    // 0x855830: b.eq            #0x855894
    // 0x855834: LoadField: r2 = r1->field_5f
    //     0x855834: ldur            w2, [x1, #0x5f]
    // 0x855838: DecompressPointer r2
    //     0x855838: add             x2, x2, HEAP, lsl #32
    // 0x85583c: tbnz            w2, #4, #0x85585c
    // 0x855840: LoadField: r1 = r0->field_f
    //     0x855840: ldur            w1, [x0, #0xf]
    // 0x855844: DecompressPointer r1
    //     0x855844: add             x1, x1, HEAP, lsl #32
    // 0x855848: cmp             w1, NULL
    // 0x85584c: b.eq            #0x855910
    // 0x855850: SaveReg r1
    //     0x855850: str             x1, [SP, #-8]!
    // 0x855854: r0 = forLongPress()
    //     0x855854: bl              #0x83bf00  ; [package:flutter/src/material/feedback.dart] Feedback::forLongPress
    // 0x855858: add             SP, SP, #8
    // 0x85585c: ldr             x0, [fp, #0x10]
    // 0x855860: LoadField: r1 = r0->field_b
    //     0x855860: ldur            w1, [x0, #0xb]
    // 0x855864: DecompressPointer r1
    //     0x855864: add             x1, x1, HEAP, lsl #32
    // 0x855868: cmp             w1, NULL
    // 0x85586c: b.eq            #0x855914
    // 0x855870: LoadField: r0 = r1->field_23
    //     0x855870: ldur            w0, [x1, #0x23]
    // 0x855874: DecompressPointer r0
    //     0x855874: add             x0, x0, HEAP, lsl #32
    // 0x855878: cmp             w0, NULL
    // 0x85587c: b.eq            #0x855918
    // 0x855880: SaveReg r0
    //     0x855880: str             x0, [SP, #-8]!
    // 0x855884: ClosureCall
    //     0x855884: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x855888: ldur            x2, [x0, #0x1f]
    //     0x85588c: blr             x2
    // 0x855890: add             SP, SP, #8
    // 0x855894: r0 = Null
    //     0x855894: mov             x0, NULL
    // 0x855898: LeaveFrame
    //     0x855898: mov             SP, fp
    //     0x85589c: ldp             fp, lr, [SP], #0x10
    // 0x8558a0: ret
    //     0x8558a0: ret             
    // 0x8558a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8558a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8558a8: b               #0x855660
    // 0x8558ac: SaveReg d2
    //     0x8558ac: str             q2, [SP, #-0x10]!
    // 0x8558b0: stp             x0, x1, [SP, #-0x10]!
    // 0x8558b4: d0 = 0.000000
    //     0x8558b4: fmov            d0, d2
    // 0x8558b8: r0 = 212
    //     0x8558b8: mov             x0, #0xd4
    // 0x8558bc: r24 = DoubleToIntegerStub
    //     0x8558bc: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x8558c0: LoadField: r30 = r24->field_7
    //     0x8558c0: ldur            lr, [x24, #7]
    // 0x8558c4: blr             lr
    // 0x8558c8: mov             x2, x0
    // 0x8558cc: ldp             x0, x1, [SP], #0x10
    // 0x8558d0: RestoreReg d2
    //     0x8558d0: ldr             q2, [SP], #0x10
    // 0x8558d4: b               #0x8556b8
    // 0x8558d8: r9 = _radiusController
    //     0x8558d8: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e0] Field <InkSplash._radiusController@759036029>: late (offset: 0x3c)
    //     0x8558dc: ldr             x9, [x9, #0x2e0]
    // 0x8558e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8558e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8558e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8558e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8558e8: r9 = _radiusController
    //     0x8558e8: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e8] Field <InkRipple._radiusController@757110234>: late (offset: 0x38)
    //     0x8558ec: ldr             x9, [x9, #0x2e8]
    // 0x8558f0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8558f0: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8558f4: r9 = _fadeInController
    //     0x8558f4: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f0] Field <InkRipple._fadeInController@757110234>: late (offset: 0x40)
    //     0x8558f8: ldr             x9, [x9, #0x2f0]
    // 0x8558fc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8558fc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x855900: r9 = _fadeOutController
    //     0x855900: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f8] Field <InkRipple._fadeOutController@757110234>: late (offset: 0x48)
    //     0x855904: ldr             x9, [x9, #0x2f8]
    // 0x855908: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855908: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x85590c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85590c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855910: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855910: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855914: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855914: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855918: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855918: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTapCancel(dynamic) {
    // ** addr: 0x85591c, size: 0x48
    // 0x85591c: EnterFrame
    //     0x85591c: stp             fp, lr, [SP, #-0x10]!
    //     0x855920: mov             fp, SP
    // 0x855924: ldr             x0, [fp, #0x10]
    // 0x855928: LoadField: r1 = r0->field_17
    //     0x855928: ldur            w1, [x0, #0x17]
    // 0x85592c: DecompressPointer r1
    //     0x85592c: add             x1, x1, HEAP, lsl #32
    // 0x855930: CheckStackOverflow
    //     0x855930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855934: cmp             SP, x16
    //     0x855938: b.ls            #0x85595c
    // 0x85593c: LoadField: r0 = r1->field_f
    //     0x85593c: ldur            w0, [x1, #0xf]
    // 0x855940: DecompressPointer r0
    //     0x855940: add             x0, x0, HEAP, lsl #32
    // 0x855944: SaveReg r0
    //     0x855944: str             x0, [SP, #-8]!
    // 0x855948: r0 = handleTapCancel()
    //     0x855948: bl              #0x855964  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapCancel
    // 0x85594c: add             SP, SP, #8
    // 0x855950: LeaveFrame
    //     0x855950: mov             SP, fp
    //     0x855954: ldp             fp, lr, [SP], #0x10
    // 0x855958: ret
    //     0x855958: ret             
    // 0x85595c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85595c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855960: b               #0x85593c
  }
  _ handleTapCancel(/* No info */) {
    // ** addr: 0x855964, size: 0x1b8
    // 0x855964: EnterFrame
    //     0x855964: stp             fp, lr, [SP, #-0x10]!
    //     0x855968: mov             fp, SP
    // 0x85596c: AllocStack(0x10)
    //     0x85596c: sub             SP, SP, #0x10
    // 0x855970: CheckStackOverflow
    //     0x855970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855974: cmp             SP, x16
    //     0x855978: b.ls            #0x855aec
    // 0x85597c: ldr             x0, [fp, #0x10]
    // 0x855980: LoadField: r1 = r0->field_1b
    //     0x855980: ldur            w1, [x0, #0x1b]
    // 0x855984: DecompressPointer r1
    //     0x855984: add             x1, x1, HEAP, lsl #32
    // 0x855988: stur            x1, [fp, #-8]
    // 0x85598c: cmp             w1, NULL
    // 0x855990: b.eq            #0x855aa8
    // 0x855994: r2 = LoadClassIdInstr(r1)
    //     0x855994: ldur            x2, [x1, #-1]
    //     0x855998: ubfx            x2, x2, #0xc, #0x14
    // 0x85599c: lsl             x2, x2, #1
    // 0x8559a0: r17 = 4392
    //     0x8559a0: mov             x17, #0x1128
    // 0x8559a4: cmp             w2, w17
    // 0x8559a8: b.ne            #0x8559d0
    // 0x8559ac: LoadField: r2 = r1->field_43
    //     0x8559ac: ldur            w2, [x1, #0x43]
    // 0x8559b0: DecompressPointer r2
    //     0x8559b0: add             x2, x2, HEAP, lsl #32
    // 0x8559b4: cmp             w2, NULL
    // 0x8559b8: b.eq            #0x855aa4
    // 0x8559bc: SaveReg r2
    //     0x8559bc: str             x2, [SP, #-8]!
    // 0x8559c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8559c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8559c4: r0 = forward()
    //     0x8559c4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x8559c8: add             SP, SP, #8
    // 0x8559cc: b               #0x855aa4
    // 0x8559d0: r17 = 4394
    //     0x8559d0: mov             x17, #0x112a
    // 0x8559d4: cmp             w2, w17
    // 0x8559d8: b.eq            #0x855aa4
    // 0x8559dc: r17 = 4396
    //     0x8559dc: mov             x17, #0x112c
    // 0x8559e0: cmp             w2, w17
    // 0x8559e4: b.ne            #0x855aa4
    // 0x8559e8: LoadField: r0 = r1->field_3f
    //     0x8559e8: ldur            w0, [x1, #0x3f]
    // 0x8559ec: DecompressPointer r0
    //     0x8559ec: add             x0, x0, HEAP, lsl #32
    // 0x8559f0: r16 = Sentinel
    //     0x8559f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8559f4: cmp             w0, w16
    // 0x8559f8: b.eq            #0x855af4
    // 0x8559fc: SaveReg r0
    //     0x8559fc: str             x0, [SP, #-8]!
    // 0x855a00: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855a00: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855a04: r0 = stop()
    //     0x855a04: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x855a08: add             SP, SP, #8
    // 0x855a0c: ldur            x0, [fp, #-8]
    // 0x855a10: LoadField: r1 = r0->field_3f
    //     0x855a10: ldur            w1, [x0, #0x3f]
    // 0x855a14: DecompressPointer r1
    //     0x855a14: add             x1, x1, HEAP, lsl #32
    // 0x855a18: LoadField: r2 = r1->field_37
    //     0x855a18: ldur            w2, [x1, #0x37]
    // 0x855a1c: DecompressPointer r2
    //     0x855a1c: add             x2, x2, HEAP, lsl #32
    // 0x855a20: r16 = Sentinel
    //     0x855a20: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855a24: cmp             w2, w16
    // 0x855a28: b.eq            #0x855b00
    // 0x855a2c: LoadField: d0 = r2->field_7
    //     0x855a2c: ldur            d0, [x2, #7]
    // 0x855a30: d1 = 1.000000
    //     0x855a30: fmov            d1, #1.00000000
    // 0x855a34: fsub            d2, d1, d0
    // 0x855a38: stur            d2, [fp, #-0x10]
    // 0x855a3c: LoadField: r1 = r0->field_47
    //     0x855a3c: ldur            w1, [x0, #0x47]
    // 0x855a40: DecompressPointer r1
    //     0x855a40: add             x1, x1, HEAP, lsl #32
    // 0x855a44: r16 = Sentinel
    //     0x855a44: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855a48: cmp             w1, w16
    // 0x855a4c: b.eq            #0x855b0c
    // 0x855a50: SaveReg r1
    //     0x855a50: str             x1, [SP, #-8]!
    // 0x855a54: SaveReg d2
    //     0x855a54: str             d2, [SP, #-8]!
    // 0x855a58: r0 = value=()
    //     0x855a58: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x855a5c: add             SP, SP, #0x10
    // 0x855a60: ldur            d1, [fp, #-0x10]
    // 0x855a64: d0 = 1.000000
    //     0x855a64: fmov            d0, #1.00000000
    // 0x855a68: fcmp            d1, d0
    // 0x855a6c: b.vs            #0x855aa4
    // 0x855a70: b.ge            #0x855aa4
    // 0x855a74: ldur            x0, [fp, #-8]
    // 0x855a78: LoadField: r1 = r0->field_47
    //     0x855a78: ldur            w1, [x0, #0x47]
    // 0x855a7c: DecompressPointer r1
    //     0x855a7c: add             x1, x1, HEAP, lsl #32
    // 0x855a80: SaveReg r1
    //     0x855a80: str             x1, [SP, #-8]!
    // 0x855a84: SaveReg d0
    //     0x855a84: str             d0, [SP, #-8]!
    // 0x855a88: r16 = Instance_Duration
    //     0x855a88: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e300] Obj!Duration@b67bc1
    //     0x855a8c: ldr             x16, [x16, #0x300]
    // 0x855a90: SaveReg r16
    //     0x855a90: str             x16, [SP, #-8]!
    // 0x855a94: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x855a94: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x855a98: ldr             x4, [x4, #0xa0]
    // 0x855a9c: r0 = animateTo()
    //     0x855a9c: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x855aa0: add             SP, SP, #0x18
    // 0x855aa4: ldr             x0, [fp, #0x10]
    // 0x855aa8: StoreField: r0->field_1b = rNULL
    //     0x855aa8: stur            NULL, [x0, #0x1b]
    // 0x855aac: LoadField: r1 = r0->field_b
    //     0x855aac: ldur            w1, [x0, #0xb]
    // 0x855ab0: DecompressPointer r1
    //     0x855ab0: add             x1, x1, HEAP, lsl #32
    // 0x855ab4: cmp             w1, NULL
    // 0x855ab8: b.eq            #0x855b18
    // 0x855abc: r16 = Instance__HighlightType
    //     0x855abc: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e288] Obj!_HighlightType@b65811
    //     0x855ac0: ldr             x16, [x16, #0x288]
    // 0x855ac4: stp             x16, x0, [SP, #-0x10]!
    // 0x855ac8: r16 = false
    //     0x855ac8: add             x16, NULL, #0x30  ; false
    // 0x855acc: SaveReg r16
    //     0x855acc: str             x16, [SP, #-8]!
    // 0x855ad0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x855ad0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x855ad4: r0 = updateHighlight()
    //     0x855ad4: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x855ad8: add             SP, SP, #0x18
    // 0x855adc: r0 = Null
    //     0x855adc: mov             x0, NULL
    // 0x855ae0: LeaveFrame
    //     0x855ae0: mov             SP, fp
    //     0x855ae4: ldp             fp, lr, [SP], #0x10
    // 0x855ae8: ret
    //     0x855ae8: ret             
    // 0x855aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855aec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855af0: b               #0x85597c
    // 0x855af4: r9 = _fadeInController
    //     0x855af4: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f0] Field <InkRipple._fadeInController@757110234>: late (offset: 0x40)
    //     0x855af8: ldr             x9, [x9, #0x2f0]
    // 0x855afc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855afc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x855b00: r9 = _value
    //     0x855b00: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x855b04: ldr             x9, [x9, #0xbb0]
    // 0x855b08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855b08: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x855b0c: r9 = _fadeOutController
    //     0x855b0c: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f8] Field <InkRipple._fadeOutController@757110234>: late (offset: 0x48)
    //     0x855b10: ldr             x9, [x9, #0x2f8]
    // 0x855b14: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x855b14: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x855b18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855b18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTap(dynamic) {
    // ** addr: 0x855b1c, size: 0x48
    // 0x855b1c: EnterFrame
    //     0x855b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x855b20: mov             fp, SP
    // 0x855b24: ldr             x0, [fp, #0x10]
    // 0x855b28: LoadField: r1 = r0->field_17
    //     0x855b28: ldur            w1, [x0, #0x17]
    // 0x855b2c: DecompressPointer r1
    //     0x855b2c: add             x1, x1, HEAP, lsl #32
    // 0x855b30: CheckStackOverflow
    //     0x855b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855b34: cmp             SP, x16
    //     0x855b38: b.ls            #0x855b5c
    // 0x855b3c: LoadField: r0 = r1->field_f
    //     0x855b3c: ldur            w0, [x1, #0xf]
    // 0x855b40: DecompressPointer r0
    //     0x855b40: add             x0, x0, HEAP, lsl #32
    // 0x855b44: SaveReg r0
    //     0x855b44: str             x0, [SP, #-8]!
    // 0x855b48: r0 = handleTap()
    //     0x855b48: bl              #0x855b64  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTap
    // 0x855b4c: add             SP, SP, #8
    // 0x855b50: LeaveFrame
    //     0x855b50: mov             SP, fp
    //     0x855b54: ldp             fp, lr, [SP], #0x10
    // 0x855b58: ret
    //     0x855b58: ret             
    // 0x855b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855b5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855b60: b               #0x855b3c
  }
  _ handleTap(/* No info */) {
    // ** addr: 0x855b64, size: 0x2f4
    // 0x855b64: EnterFrame
    //     0x855b64: stp             fp, lr, [SP, #-0x10]!
    //     0x855b68: mov             fp, SP
    // 0x855b6c: AllocStack(0x18)
    //     0x855b6c: sub             SP, SP, #0x18
    // 0x855b70: CheckStackOverflow
    //     0x855b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855b74: cmp             SP, x16
    //     0x855b78: b.ls            #0x855de4
    // 0x855b7c: ldr             x0, [fp, #0x10]
    // 0x855b80: LoadField: r1 = r0->field_1b
    //     0x855b80: ldur            w1, [x0, #0x1b]
    // 0x855b84: DecompressPointer r1
    //     0x855b84: add             x1, x1, HEAP, lsl #32
    // 0x855b88: stur            x1, [fp, #-0x18]
    // 0x855b8c: cmp             w1, NULL
    // 0x855b90: b.eq            #0x855d2c
    // 0x855b94: r2 = LoadClassIdInstr(r1)
    //     0x855b94: ldur            x2, [x1, #-1]
    //     0x855b98: ubfx            x2, x2, #0xc, #0x14
    // 0x855b9c: lsl             x2, x2, #1
    // 0x855ba0: r17 = 4392
    //     0x855ba0: mov             x17, #0x1128
    // 0x855ba4: cmp             w2, w17
    // 0x855ba8: b.ne            #0x855c70
    // 0x855bac: d0 = 1.000000
    //     0x855bac: fmov            d0, #1.00000000
    // 0x855bb0: LoadField: d1 = r1->field_23
    //     0x855bb0: ldur            d1, [x1, #0x23]
    // 0x855bb4: fdiv            d2, d1, d0
    // 0x855bb8: fcmp            d2, d2
    // 0x855bbc: b.vs            #0x855dec
    // 0x855bc0: fcvtms          x2, d2
    // 0x855bc4: asr             x16, x2, #0x1e
    // 0x855bc8: cmp             x16, x2, asr #63
    // 0x855bcc: b.ne            #0x855dec
    // 0x855bd0: lsl             x2, x2, #1
    // 0x855bd4: LoadField: r3 = r1->field_3b
    //     0x855bd4: ldur            w3, [x1, #0x3b]
    // 0x855bd8: DecompressPointer r3
    //     0x855bd8: add             x3, x3, HEAP, lsl #32
    // 0x855bdc: r16 = Sentinel
    //     0x855bdc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855be0: cmp             w3, w16
    // 0x855be4: b.eq            #0x855e18
    // 0x855be8: stur            x3, [fp, #-0x10]
    // 0x855bec: r4 = LoadInt32Instr(r2)
    //     0x855bec: sbfx            x4, x2, #1, #0x1f
    //     0x855bf0: tbz             w2, #0, #0x855bf8
    //     0x855bf4: ldur            x4, [x2, #7]
    // 0x855bf8: r16 = 1000
    //     0x855bf8: mov             x16, #0x3e8
    // 0x855bfc: mul             x2, x4, x16
    // 0x855c00: stur            x2, [fp, #-8]
    // 0x855c04: r0 = Duration()
    //     0x855c04: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x855c08: mov             x1, x0
    // 0x855c0c: ldur            x0, [fp, #-8]
    // 0x855c10: StoreField: r1->field_7 = r0
    //     0x855c10: stur            x0, [x1, #7]
    // 0x855c14: mov             x0, x1
    // 0x855c18: ldur            x1, [fp, #-0x10]
    // 0x855c1c: StoreField: r1->field_27 = r0
    //     0x855c1c: stur            w0, [x1, #0x27]
    //     0x855c20: ldurb           w16, [x1, #-1]
    //     0x855c24: ldurb           w17, [x0, #-1]
    //     0x855c28: and             x16, x17, x16, lsr #2
    //     0x855c2c: tst             x16, HEAP, lsr #32
    //     0x855c30: b.eq            #0x855c38
    //     0x855c34: bl              #0xd6826c
    // 0x855c38: SaveReg r1
    //     0x855c38: str             x1, [SP, #-8]!
    // 0x855c3c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855c3c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855c40: r0 = forward()
    //     0x855c40: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x855c44: add             SP, SP, #8
    // 0x855c48: ldur            x0, [fp, #-0x18]
    // 0x855c4c: LoadField: r1 = r0->field_43
    //     0x855c4c: ldur            w1, [x0, #0x43]
    // 0x855c50: DecompressPointer r1
    //     0x855c50: add             x1, x1, HEAP, lsl #32
    // 0x855c54: cmp             w1, NULL
    // 0x855c58: b.eq            #0x855e24
    // 0x855c5c: SaveReg r1
    //     0x855c5c: str             x1, [SP, #-8]!
    // 0x855c60: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855c60: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855c64: r0 = forward()
    //     0x855c64: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x855c68: add             SP, SP, #8
    // 0x855c6c: b               #0x855d28
    // 0x855c70: mov             x0, x1
    // 0x855c74: d0 = 1.000000
    //     0x855c74: fmov            d0, #1.00000000
    // 0x855c78: r17 = 4394
    //     0x855c78: mov             x17, #0x112a
    // 0x855c7c: cmp             w2, w17
    // 0x855c80: b.eq            #0x855d28
    // 0x855c84: r17 = 4396
    //     0x855c84: mov             x17, #0x112c
    // 0x855c88: cmp             w2, w17
    // 0x855c8c: b.ne            #0x855d28
    // 0x855c90: r1 = Instance_Duration
    //     0x855c90: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e2d0] Obj!Duration@b67bb1
    //     0x855c94: ldr             x1, [x1, #0x2d0]
    // 0x855c98: LoadField: r2 = r0->field_37
    //     0x855c98: ldur            w2, [x0, #0x37]
    // 0x855c9c: DecompressPointer r2
    //     0x855c9c: add             x2, x2, HEAP, lsl #32
    // 0x855ca0: r16 = Sentinel
    //     0x855ca0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855ca4: cmp             w2, w16
    // 0x855ca8: b.eq            #0x855e28
    // 0x855cac: StoreField: r2->field_27 = r1
    //     0x855cac: stur            w1, [x2, #0x27]
    // 0x855cb0: SaveReg r2
    //     0x855cb0: str             x2, [SP, #-8]!
    // 0x855cb4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855cb4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855cb8: r0 = forward()
    //     0x855cb8: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x855cbc: add             SP, SP, #8
    // 0x855cc0: ldur            x0, [fp, #-0x18]
    // 0x855cc4: LoadField: r1 = r0->field_3f
    //     0x855cc4: ldur            w1, [x0, #0x3f]
    // 0x855cc8: DecompressPointer r1
    //     0x855cc8: add             x1, x1, HEAP, lsl #32
    // 0x855ccc: r16 = Sentinel
    //     0x855ccc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855cd0: cmp             w1, w16
    // 0x855cd4: b.eq            #0x855e34
    // 0x855cd8: SaveReg r1
    //     0x855cd8: str             x1, [SP, #-8]!
    // 0x855cdc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x855cdc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x855ce0: r0 = forward()
    //     0x855ce0: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x855ce4: add             SP, SP, #8
    // 0x855ce8: ldur            x0, [fp, #-0x18]
    // 0x855cec: LoadField: r1 = r0->field_47
    //     0x855cec: ldur            w1, [x0, #0x47]
    // 0x855cf0: DecompressPointer r1
    //     0x855cf0: add             x1, x1, HEAP, lsl #32
    // 0x855cf4: r16 = Sentinel
    //     0x855cf4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x855cf8: cmp             w1, w16
    // 0x855cfc: b.eq            #0x855e40
    // 0x855d00: SaveReg r1
    //     0x855d00: str             x1, [SP, #-8]!
    // 0x855d04: d0 = 1.000000
    //     0x855d04: fmov            d0, #1.00000000
    // 0x855d08: SaveReg d0
    //     0x855d08: str             d0, [SP, #-8]!
    // 0x855d0c: r16 = Instance_Duration
    //     0x855d0c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2d8] Obj!Duration@b67ba1
    //     0x855d10: ldr             x16, [x16, #0x2d8]
    // 0x855d14: SaveReg r16
    //     0x855d14: str             x16, [SP, #-8]!
    // 0x855d18: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x855d18: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x855d1c: ldr             x4, [x4, #0xa0]
    // 0x855d20: r0 = animateTo()
    //     0x855d20: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x855d24: add             SP, SP, #0x18
    // 0x855d28: ldr             x0, [fp, #0x10]
    // 0x855d2c: StoreField: r0->field_1b = rNULL
    //     0x855d2c: stur            NULL, [x0, #0x1b]
    // 0x855d30: r16 = Instance__HighlightType
    //     0x855d30: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e288] Obj!_HighlightType@b65811
    //     0x855d34: ldr             x16, [x16, #0x288]
    // 0x855d38: stp             x16, x0, [SP, #-0x10]!
    // 0x855d3c: r16 = false
    //     0x855d3c: add             x16, NULL, #0x30  ; false
    // 0x855d40: SaveReg r16
    //     0x855d40: str             x16, [SP, #-8]!
    // 0x855d44: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x855d44: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x855d48: r0 = updateHighlight()
    //     0x855d48: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x855d4c: add             SP, SP, #0x18
    // 0x855d50: ldr             x0, [fp, #0x10]
    // 0x855d54: LoadField: r1 = r0->field_b
    //     0x855d54: ldur            w1, [x0, #0xb]
    // 0x855d58: DecompressPointer r1
    //     0x855d58: add             x1, x1, HEAP, lsl #32
    // 0x855d5c: cmp             w1, NULL
    // 0x855d60: b.eq            #0x855e4c
    // 0x855d64: LoadField: r2 = r1->field_f
    //     0x855d64: ldur            w2, [x1, #0xf]
    // 0x855d68: DecompressPointer r2
    //     0x855d68: add             x2, x2, HEAP, lsl #32
    // 0x855d6c: cmp             w2, NULL
    // 0x855d70: b.eq            #0x855dd4
    // 0x855d74: LoadField: r2 = r1->field_5f
    //     0x855d74: ldur            w2, [x1, #0x5f]
    // 0x855d78: DecompressPointer r2
    //     0x855d78: add             x2, x2, HEAP, lsl #32
    // 0x855d7c: tbnz            w2, #4, #0x855d9c
    // 0x855d80: LoadField: r1 = r0->field_f
    //     0x855d80: ldur            w1, [x0, #0xf]
    // 0x855d84: DecompressPointer r1
    //     0x855d84: add             x1, x1, HEAP, lsl #32
    // 0x855d88: cmp             w1, NULL
    // 0x855d8c: b.eq            #0x855e50
    // 0x855d90: SaveReg r1
    //     0x855d90: str             x1, [SP, #-8]!
    // 0x855d94: r0 = forTap()
    //     0x855d94: bl              #0x855e58  ; [package:flutter/src/material/feedback.dart] Feedback::forTap
    // 0x855d98: add             SP, SP, #8
    // 0x855d9c: ldr             x0, [fp, #0x10]
    // 0x855da0: LoadField: r1 = r0->field_b
    //     0x855da0: ldur            w1, [x0, #0xb]
    // 0x855da4: DecompressPointer r1
    //     0x855da4: add             x1, x1, HEAP, lsl #32
    // 0x855da8: cmp             w1, NULL
    // 0x855dac: b.eq            #0x855e54
    // 0x855db0: LoadField: r0 = r1->field_f
    //     0x855db0: ldur            w0, [x1, #0xf]
    // 0x855db4: DecompressPointer r0
    //     0x855db4: add             x0, x0, HEAP, lsl #32
    // 0x855db8: cmp             w0, NULL
    // 0x855dbc: b.eq            #0x855dd4
    // 0x855dc0: SaveReg r0
    //     0x855dc0: str             x0, [SP, #-8]!
    // 0x855dc4: ClosureCall
    //     0x855dc4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x855dc8: ldur            x2, [x0, #0x1f]
    //     0x855dcc: blr             x2
    // 0x855dd0: add             SP, SP, #8
    // 0x855dd4: r0 = Null
    //     0x855dd4: mov             x0, NULL
    // 0x855dd8: LeaveFrame
    //     0x855dd8: mov             SP, fp
    //     0x855ddc: ldp             fp, lr, [SP], #0x10
    // 0x855de0: ret
    //     0x855de0: ret             
    // 0x855de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855de4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855de8: b               #0x855b7c
    // 0x855dec: SaveReg d2
    //     0x855dec: str             q2, [SP, #-0x10]!
    // 0x855df0: stp             x0, x1, [SP, #-0x10]!
    // 0x855df4: d0 = 0.000000
    //     0x855df4: fmov            d0, d2
    // 0x855df8: r0 = 212
    //     0x855df8: mov             x0, #0xd4
    // 0x855dfc: r24 = DoubleToIntegerStub
    //     0x855dfc: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x855e00: LoadField: r30 = r24->field_7
    //     0x855e00: ldur            lr, [x24, #7]
    // 0x855e04: blr             lr
    // 0x855e08: mov             x2, x0
    // 0x855e0c: ldp             x0, x1, [SP], #0x10
    // 0x855e10: RestoreReg d2
    //     0x855e10: ldr             q2, [SP], #0x10
    // 0x855e14: b               #0x855bd4
    // 0x855e18: r9 = _radiusController
    //     0x855e18: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e0] Field <InkSplash._radiusController@759036029>: late (offset: 0x3c)
    //     0x855e1c: ldr             x9, [x9, #0x2e0]
    // 0x855e20: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855e20: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x855e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855e24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855e28: r9 = _radiusController
    //     0x855e28: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e8] Field <InkRipple._radiusController@757110234>: late (offset: 0x38)
    //     0x855e2c: ldr             x9, [x9, #0x2e8]
    // 0x855e30: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x855e30: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x855e34: r9 = _fadeInController
    //     0x855e34: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f0] Field <InkRipple._fadeInController@757110234>: late (offset: 0x40)
    //     0x855e38: ldr             x9, [x9, #0x2f0]
    // 0x855e3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855e3c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x855e40: r9 = _fadeOutController
    //     0x855e40: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f8] Field <InkRipple._fadeOutController@757110234>: late (offset: 0x48)
    //     0x855e44: ldr             x9, [x9, #0x2f8]
    // 0x855e48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x855e48: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x855e4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855e4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855e50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855e50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x855e54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855e54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x855fd8, size: 0x4c
    // 0x855fd8: EnterFrame
    //     0x855fd8: stp             fp, lr, [SP, #-0x10]!
    //     0x855fdc: mov             fp, SP
    // 0x855fe0: ldr             x0, [fp, #0x18]
    // 0x855fe4: LoadField: r1 = r0->field_17
    //     0x855fe4: ldur            w1, [x0, #0x17]
    // 0x855fe8: DecompressPointer r1
    //     0x855fe8: add             x1, x1, HEAP, lsl #32
    // 0x855fec: CheckStackOverflow
    //     0x855fec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855ff0: cmp             SP, x16
    //     0x855ff4: b.ls            #0x85601c
    // 0x855ff8: LoadField: r0 = r1->field_f
    //     0x855ff8: ldur            w0, [x1, #0xf]
    // 0x855ffc: DecompressPointer r0
    //     0x855ffc: add             x0, x0, HEAP, lsl #32
    // 0x856000: ldr             x16, [fp, #0x10]
    // 0x856004: stp             x16, x0, [SP, #-0x10]!
    // 0x856008: r0 = handleTapDown()
    //     0x856008: bl              #0x856024  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTapDown
    // 0x85600c: add             SP, SP, #0x10
    // 0x856010: LeaveFrame
    //     0x856010: mov             SP, fp
    //     0x856014: ldp             fp, lr, [SP], #0x10
    // 0x856018: ret
    //     0x856018: ret             
    // 0x85601c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85601c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856020: b               #0x855ff8
  }
  _ handleTapDown(/* No info */) {
    // ** addr: 0x856024, size: 0x8c
    // 0x856024: EnterFrame
    //     0x856024: stp             fp, lr, [SP, #-0x10]!
    //     0x856028: mov             fp, SP
    // 0x85602c: CheckStackOverflow
    //     0x85602c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x856030: cmp             SP, x16
    //     0x856034: b.ls            #0x8560a4
    // 0x856038: ldr             x0, [fp, #0x18]
    // 0x85603c: LoadField: r1 = r0->field_2f
    //     0x85603c: ldur            w1, [x0, #0x2f]
    // 0x856040: DecompressPointer r1
    //     0x856040: add             x1, x1, HEAP, lsl #32
    // 0x856044: LoadField: r2 = r1->field_b
    //     0x856044: ldur            w2, [x1, #0xb]
    // 0x856048: DecompressPointer r2
    //     0x856048: add             x2, x2, HEAP, lsl #32
    // 0x85604c: LoadField: r1 = r2->field_b
    //     0x85604c: ldur            w1, [x2, #0xb]
    // 0x856050: DecompressPointer r1
    //     0x856050: add             x1, x1, HEAP, lsl #32
    // 0x856054: cbz             w1, #0x856068
    // 0x856058: r0 = Null
    //     0x856058: mov             x0, NULL
    // 0x85605c: LeaveFrame
    //     0x85605c: mov             SP, fp
    //     0x856060: ldp             fp, lr, [SP], #0x10
    // 0x856064: ret
    //     0x856064: ret             
    // 0x856068: ldr             x16, [fp, #0x10]
    // 0x85606c: stp             x16, x0, [SP, #-0x10]!
    // 0x856070: r4 = const [0, 0x2, 0x2, 0x1, details, 0x1, null]
    //     0x856070: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e318] List(7) [0, 0x2, 0x2, 0x1, "details", 0x1, Null]
    //     0x856074: ldr             x4, [x4, #0x318]
    // 0x856078: r0 = _startNewSplash()
    //     0x856078: bl              #0x8560b0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_startNewSplash
    // 0x85607c: add             SP, SP, #0x10
    // 0x856080: ldr             x1, [fp, #0x18]
    // 0x856084: LoadField: r2 = r1->field_b
    //     0x856084: ldur            w2, [x1, #0xb]
    // 0x856088: DecompressPointer r2
    //     0x856088: add             x2, x2, HEAP, lsl #32
    // 0x85608c: cmp             w2, NULL
    // 0x856090: b.eq            #0x8560ac
    // 0x856094: r0 = Null
    //     0x856094: mov             x0, NULL
    // 0x856098: LeaveFrame
    //     0x856098: mov             SP, fp
    //     0x85609c: ldp             fp, lr, [SP], #0x10
    // 0x8560a0: ret
    //     0x8560a0: ret             
    // 0x8560a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8560a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8560a8: b               #0x856038
    // 0x8560ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8560ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _startNewSplash(/* No info */) {
    // ** addr: 0x8560b0, size: 0x440
    // 0x8560b0: EnterFrame
    //     0x8560b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8560b4: mov             fp, SP
    // 0x8560b8: AllocStack(0x20)
    //     0x8560b8: sub             SP, SP, #0x20
    // 0x8560bc: SetupParameters(_InkResponseState<_InkResponseStateWidget> this /* r3, fp-0x8 */, {dynamic context = Null /* r4 */, dynamic details = Null /* r0 */})
    //     0x8560bc: mov             x0, x4
    //     0x8560c0: ldur            w1, [x0, #0x13]
    //     0x8560c4: add             x1, x1, HEAP, lsl #32
    //     0x8560c8: sub             x2, x1, #2
    //     0x8560cc: add             x3, fp, w2, sxtw #2
    //     0x8560d0: ldr             x3, [x3, #0x10]
    //     0x8560d4: stur            x3, [fp, #-8]
    //     0x8560d8: ldur            w2, [x0, #0x1f]
    //     0x8560dc: add             x2, x2, HEAP, lsl #32
    //     0x8560e0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fb60] "context"
    //     0x8560e4: ldr             x16, [x16, #0xb60]
    //     0x8560e8: cmp             w2, w16
    //     0x8560ec: b.ne            #0x856110
    //     0x8560f0: ldur            w2, [x0, #0x23]
    //     0x8560f4: add             x2, x2, HEAP, lsl #32
    //     0x8560f8: sub             w4, w1, w2
    //     0x8560fc: add             x2, fp, w4, sxtw #2
    //     0x856100: ldr             x2, [x2, #8]
    //     0x856104: mov             x4, x2
    //     0x856108: mov             x2, #1
    //     0x85610c: b               #0x856118
    //     0x856110: mov             x4, NULL
    //     0x856114: mov             x2, #0
    //     0x856118: lsl             x5, x2, #1
    //     0x85611c: lsl             w2, w5, #1
    //     0x856120: add             w5, w2, #8
    //     0x856124: add             x16, x0, w5, sxtw #1
    //     0x856128: ldur            w6, [x16, #0xf]
    //     0x85612c: add             x6, x6, HEAP, lsl #32
    //     0x856130: ldr             x16, [PP, #0x62e0]  ; [pp+0x62e0] "details"
    //     0x856134: cmp             w6, w16
    //     0x856138: b.ne            #0x856160
    //     0x85613c: add             w5, w2, #0xa
    //     0x856140: add             x16, x0, w5, sxtw #1
    //     0x856144: ldur            w2, [x16, #0xf]
    //     0x856148: add             x2, x2, HEAP, lsl #32
    //     0x85614c: sub             w0, w1, w2
    //     0x856150: add             x1, fp, w0, sxtw #2
    //     0x856154: ldr             x1, [x1, #8]
    //     0x856158: mov             x0, x1
    //     0x85615c: b               #0x856164
    //     0x856160: mov             x0, NULL
    // 0x856164: CheckStackOverflow
    //     0x856164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x856168: cmp             SP, x16
    //     0x85616c: b.ls            #0x8564ac
    // 0x856170: cmp             w4, NULL
    // 0x856174: b.eq            #0x856214
    // 0x856178: SaveReg r4
    //     0x856178: str             x4, [SP, #-8]!
    // 0x85617c: r0 = findRenderObject()
    //     0x85617c: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x856180: add             SP, SP, #8
    // 0x856184: mov             x3, x0
    // 0x856188: stur            x3, [fp, #-0x10]
    // 0x85618c: cmp             w3, NULL
    // 0x856190: b.eq            #0x8564b4
    // 0x856194: mov             x0, x3
    // 0x856198: r2 = Null
    //     0x856198: mov             x2, NULL
    // 0x85619c: r1 = Null
    //     0x85619c: mov             x1, NULL
    // 0x8561a0: r4 = LoadClassIdInstr(r0)
    //     0x8561a0: ldur            x4, [x0, #-1]
    //     0x8561a4: ubfx            x4, x4, #0xc, #0x14
    // 0x8561a8: sub             x4, x4, #0x965
    // 0x8561ac: cmp             x4, #0x8b
    // 0x8561b0: b.ls            #0x8561c8
    // 0x8561b4: r8 = RenderBox
    //     0x8561b4: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x8561b8: ldr             x8, [x8, #0xfa0]
    // 0x8561bc: r3 = Null
    //     0x8561bc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e320] Null
    //     0x8561c0: ldr             x3, [x3, #0x320]
    // 0x8561c4: r0 = RenderBox()
    //     0x8561c4: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x8561c8: ldur            x0, [fp, #-0x10]
    // 0x8561cc: LoadField: r1 = r0->field_57
    //     0x8561cc: ldur            w1, [x0, #0x57]
    // 0x8561d0: DecompressPointer r1
    //     0x8561d0: add             x1, x1, HEAP, lsl #32
    // 0x8561d4: cmp             w1, NULL
    // 0x8561d8: b.eq            #0x8564b8
    // 0x8561dc: r16 = Instance_Offset
    //     0x8561dc: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x8561e0: stp             x1, x16, [SP, #-0x10]!
    // 0x8561e4: r0 = &()
    //     0x8561e4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x8561e8: add             SP, SP, #0x10
    // 0x8561ec: SaveReg r0
    //     0x8561ec: str             x0, [SP, #-8]!
    // 0x8561f0: r0 = center()
    //     0x8561f0: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x8561f4: add             SP, SP, #8
    // 0x8561f8: ldur            x16, [fp, #-0x10]
    // 0x8561fc: stp             x0, x16, [SP, #-0x10]!
    // 0x856200: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x856200: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x856204: r0 = localToGlobal()
    //     0x856204: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x856208: add             SP, SP, #0x10
    // 0x85620c: mov             x1, x0
    // 0x856210: b               #0x856224
    // 0x856214: cmp             w0, NULL
    // 0x856218: b.eq            #0x8564bc
    // 0x85621c: LoadField: r1 = r0->field_7
    //     0x85621c: ldur            w1, [x0, #7]
    // 0x856220: DecompressPointer r1
    //     0x856220: add             x1, x1, HEAP, lsl #32
    // 0x856224: ldur            x0, [fp, #-8]
    // 0x856228: stur            x1, [fp, #-0x10]
    // 0x85622c: LoadField: r2 = r0->field_b
    //     0x85622c: ldur            w2, [x0, #0xb]
    // 0x856230: DecompressPointer r2
    //     0x856230: add             x2, x2, HEAP, lsl #32
    // 0x856234: cmp             w2, NULL
    // 0x856238: b.eq            #0x8564c0
    // 0x85623c: LoadField: r3 = r2->field_7f
    //     0x85623c: ldur            w3, [x2, #0x7f]
    // 0x856240: DecompressPointer r3
    //     0x856240: add             x3, x3, HEAP, lsl #32
    // 0x856244: cmp             w3, NULL
    // 0x856248: b.ne            #0x856260
    // 0x85624c: LoadField: r2 = r0->field_2b
    //     0x85624c: ldur            w2, [x0, #0x2b]
    // 0x856250: DecompressPointer r2
    //     0x856250: add             x2, x2, HEAP, lsl #32
    // 0x856254: cmp             w2, NULL
    // 0x856258: b.eq            #0x8564c4
    // 0x85625c: b               #0x856264
    // 0x856260: mov             x2, x3
    // 0x856264: r16 = Instance_MaterialState
    //     0x856264: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x856268: ldr             x16, [x16, #0xf90]
    // 0x85626c: stp             x16, x2, [SP, #-0x10]!
    // 0x856270: r16 = true
    //     0x856270: add             x16, NULL, #0x20  ; true
    // 0x856274: SaveReg r16
    //     0x856274: str             x16, [SP, #-8]!
    // 0x856278: r0 = update()
    //     0x856278: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x85627c: add             SP, SP, #0x18
    // 0x856280: ldur            x16, [fp, #-8]
    // 0x856284: ldur            lr, [fp, #-0x10]
    // 0x856288: stp             lr, x16, [SP, #-0x10]!
    // 0x85628c: r0 = _createInkFeature()
    //     0x85628c: bl              #0x8564f0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_createInkFeature
    // 0x856290: add             SP, SP, #0x10
    // 0x856294: mov             x1, x0
    // 0x856298: ldur            x0, [fp, #-8]
    // 0x85629c: stur            x1, [fp, #-0x10]
    // 0x8562a0: LoadField: r2 = r0->field_17
    //     0x8562a0: ldur            w2, [x0, #0x17]
    // 0x8562a4: DecompressPointer r2
    //     0x8562a4: add             x2, x2, HEAP, lsl #32
    // 0x8562a8: cmp             w2, NULL
    // 0x8562ac: b.ne            #0x8562f8
    // 0x8562b0: r16 = <InteractiveInkFeature>
    //     0x8562b0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e330] TypeArguments: <InteractiveInkFeature>
    //     0x8562b4: ldr             x16, [x16, #0x330]
    // 0x8562b8: SaveReg r16
    //     0x8562b8: str             x16, [SP, #-8]!
    // 0x8562bc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8562bc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8562c0: r0 = HashSet()
    //     0x8562c0: bl              #0x5519d0  ; [dart:collection] HashSet::HashSet
    // 0x8562c4: add             SP, SP, #8
    // 0x8562c8: mov             x2, x0
    // 0x8562cc: ldur            x1, [fp, #-8]
    // 0x8562d0: StoreField: r1->field_17 = r0
    //     0x8562d0: stur            w0, [x1, #0x17]
    //     0x8562d4: tbz             w0, #0, #0x8562f0
    //     0x8562d8: ldurb           w16, [x1, #-1]
    //     0x8562dc: ldurb           w17, [x0, #-1]
    //     0x8562e0: and             x16, x17, x16, lsr #2
    //     0x8562e4: tst             x16, HEAP, lsr #32
    //     0x8562e8: b.eq            #0x8562f0
    //     0x8562ec: bl              #0xd6826c
    // 0x8562f0: mov             x0, x2
    // 0x8562f4: b               #0x856300
    // 0x8562f8: mov             x1, x0
    // 0x8562fc: mov             x0, x2
    // 0x856300: cmp             w0, NULL
    // 0x856304: b.eq            #0x8564c8
    // 0x856308: ldur            x16, [fp, #-0x10]
    // 0x85630c: stp             x16, x0, [SP, #-0x10]!
    // 0x856310: r0 = add()
    //     0x856310: bl              #0xc4af80  ; [dart:collection] _HashSet::add
    // 0x856314: add             SP, SP, #0x10
    // 0x856318: ldur            x0, [fp, #-8]
    // 0x85631c: LoadField: r1 = r0->field_1b
    //     0x85631c: ldur            w1, [x0, #0x1b]
    // 0x856320: DecompressPointer r1
    //     0x856320: add             x1, x1, HEAP, lsl #32
    // 0x856324: stur            x1, [fp, #-0x18]
    // 0x856328: cmp             w1, NULL
    // 0x85632c: b.ne            #0x856338
    // 0x856330: mov             x1, x0
    // 0x856334: b               #0x85644c
    // 0x856338: r2 = LoadClassIdInstr(r1)
    //     0x856338: ldur            x2, [x1, #-1]
    //     0x85633c: ubfx            x2, x2, #0xc, #0x14
    // 0x856340: lsl             x2, x2, #1
    // 0x856344: r17 = 4392
    //     0x856344: mov             x17, #0x1128
    // 0x856348: cmp             w2, w17
    // 0x85634c: b.ne            #0x856374
    // 0x856350: LoadField: r2 = r1->field_43
    //     0x856350: ldur            w2, [x1, #0x43]
    // 0x856354: DecompressPointer r2
    //     0x856354: add             x2, x2, HEAP, lsl #32
    // 0x856358: cmp             w2, NULL
    // 0x85635c: b.eq            #0x856448
    // 0x856360: SaveReg r2
    //     0x856360: str             x2, [SP, #-8]!
    // 0x856364: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x856364: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x856368: r0 = forward()
    //     0x856368: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x85636c: add             SP, SP, #8
    // 0x856370: b               #0x856448
    // 0x856374: r17 = 4394
    //     0x856374: mov             x17, #0x112a
    // 0x856378: cmp             w2, w17
    // 0x85637c: b.eq            #0x856448
    // 0x856380: r17 = 4396
    //     0x856380: mov             x17, #0x112c
    // 0x856384: cmp             w2, w17
    // 0x856388: b.ne            #0x856448
    // 0x85638c: LoadField: r0 = r1->field_3f
    //     0x85638c: ldur            w0, [x1, #0x3f]
    // 0x856390: DecompressPointer r0
    //     0x856390: add             x0, x0, HEAP, lsl #32
    // 0x856394: r16 = Sentinel
    //     0x856394: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x856398: cmp             w0, w16
    // 0x85639c: b.eq            #0x8564cc
    // 0x8563a0: SaveReg r0
    //     0x8563a0: str             x0, [SP, #-8]!
    // 0x8563a4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8563a4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8563a8: r0 = stop()
    //     0x8563a8: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x8563ac: add             SP, SP, #8
    // 0x8563b0: ldur            x0, [fp, #-0x18]
    // 0x8563b4: LoadField: r1 = r0->field_3f
    //     0x8563b4: ldur            w1, [x0, #0x3f]
    // 0x8563b8: DecompressPointer r1
    //     0x8563b8: add             x1, x1, HEAP, lsl #32
    // 0x8563bc: LoadField: r2 = r1->field_37
    //     0x8563bc: ldur            w2, [x1, #0x37]
    // 0x8563c0: DecompressPointer r2
    //     0x8563c0: add             x2, x2, HEAP, lsl #32
    // 0x8563c4: r16 = Sentinel
    //     0x8563c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8563c8: cmp             w2, w16
    // 0x8563cc: b.eq            #0x8564d8
    // 0x8563d0: LoadField: d0 = r2->field_7
    //     0x8563d0: ldur            d0, [x2, #7]
    // 0x8563d4: d1 = 1.000000
    //     0x8563d4: fmov            d1, #1.00000000
    // 0x8563d8: fsub            d2, d1, d0
    // 0x8563dc: stur            d2, [fp, #-0x20]
    // 0x8563e0: LoadField: r1 = r0->field_47
    //     0x8563e0: ldur            w1, [x0, #0x47]
    // 0x8563e4: DecompressPointer r1
    //     0x8563e4: add             x1, x1, HEAP, lsl #32
    // 0x8563e8: r16 = Sentinel
    //     0x8563e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8563ec: cmp             w1, w16
    // 0x8563f0: b.eq            #0x8564e4
    // 0x8563f4: SaveReg r1
    //     0x8563f4: str             x1, [SP, #-8]!
    // 0x8563f8: SaveReg d2
    //     0x8563f8: str             d2, [SP, #-8]!
    // 0x8563fc: r0 = value=()
    //     0x8563fc: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x856400: add             SP, SP, #0x10
    // 0x856404: ldur            d1, [fp, #-0x20]
    // 0x856408: d0 = 1.000000
    //     0x856408: fmov            d0, #1.00000000
    // 0x85640c: fcmp            d1, d0
    // 0x856410: b.vs            #0x856448
    // 0x856414: b.ge            #0x856448
    // 0x856418: ldur            x0, [fp, #-0x18]
    // 0x85641c: LoadField: r1 = r0->field_47
    //     0x85641c: ldur            w1, [x0, #0x47]
    // 0x856420: DecompressPointer r1
    //     0x856420: add             x1, x1, HEAP, lsl #32
    // 0x856424: SaveReg r1
    //     0x856424: str             x1, [SP, #-8]!
    // 0x856428: SaveReg d0
    //     0x856428: str             d0, [SP, #-8]!
    // 0x85642c: r16 = Instance_Duration
    //     0x85642c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e300] Obj!Duration@b67bc1
    //     0x856430: ldr             x16, [x16, #0x300]
    // 0x856434: SaveReg r16
    //     0x856434: str             x16, [SP, #-8]!
    // 0x856438: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x856438: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x85643c: ldr             x4, [x4, #0xa0]
    // 0x856440: r0 = animateTo()
    //     0x856440: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x856444: add             SP, SP, #0x18
    // 0x856448: ldur            x1, [fp, #-8]
    // 0x85644c: ldur            x0, [fp, #-0x10]
    // 0x856450: StoreField: r1->field_1b = r0
    //     0x856450: stur            w0, [x1, #0x1b]
    //     0x856454: ldurb           w16, [x1, #-1]
    //     0x856458: ldurb           w17, [x0, #-1]
    //     0x85645c: and             x16, x17, x16, lsr #2
    //     0x856460: tst             x16, HEAP, lsr #32
    //     0x856464: b.eq            #0x85646c
    //     0x856468: bl              #0xd6826c
    // 0x85646c: SaveReg r1
    //     0x85646c: str             x1, [SP, #-8]!
    // 0x856470: r0 = updateKeepAlive()
    //     0x856470: bl              #0x7b2150  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0x856474: add             SP, SP, #8
    // 0x856478: ldur            x16, [fp, #-8]
    // 0x85647c: r30 = Instance__HighlightType
    //     0x85647c: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e288] Obj!_HighlightType@b65811
    //     0x856480: ldr             lr, [lr, #0x288]
    // 0x856484: stp             lr, x16, [SP, #-0x10]!
    // 0x856488: r16 = true
    //     0x856488: add             x16, NULL, #0x20  ; true
    // 0x85648c: SaveReg r16
    //     0x85648c: str             x16, [SP, #-8]!
    // 0x856490: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x856490: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x856494: r0 = updateHighlight()
    //     0x856494: bl              #0x7b1928  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateHighlight
    // 0x856498: add             SP, SP, #0x18
    // 0x85649c: r0 = Null
    //     0x85649c: mov             x0, NULL
    // 0x8564a0: LeaveFrame
    //     0x8564a0: mov             SP, fp
    //     0x8564a4: ldp             fp, lr, [SP], #0x10
    // 0x8564a8: ret
    //     0x8564a8: ret             
    // 0x8564ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8564ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8564b0: b               #0x856170
    // 0x8564b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8564b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8564b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8564b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8564bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8564bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8564c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8564c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8564c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8564c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8564c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8564c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8564cc: r9 = _fadeInController
    //     0x8564cc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f0] Field <InkRipple._fadeInController@757110234>: late (offset: 0x40)
    //     0x8564d0: ldr             x9, [x9, #0x2f0]
    // 0x8564d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8564d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8564d8: r9 = _value
    //     0x8564d8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x8564dc: ldr             x9, [x9, #0xbb0]
    // 0x8564e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8564e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8564e4: r9 = _fadeOutController
    //     0x8564e4: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f8] Field <InkRipple._fadeOutController@757110234>: late (offset: 0x48)
    //     0x8564e8: ldr             x9, [x9, #0x2f8]
    // 0x8564ec: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8564ec: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _createInkFeature(/* No info */) {
    // ** addr: 0x8564f0, size: 0x4ac
    // 0x8564f0: EnterFrame
    //     0x8564f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8564f4: mov             fp, SP
    // 0x8564f8: AllocStack(0x68)
    //     0x8564f8: sub             SP, SP, #0x68
    // 0x8564fc: CheckStackOverflow
    //     0x8564fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x856500: cmp             SP, x16
    //     0x856504: b.ls            #0x856960
    // 0x856508: r1 = 2
    //     0x856508: mov             x1, #2
    // 0x85650c: r0 = AllocateContext()
    //     0x85650c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x856510: mov             x1, x0
    // 0x856514: ldr             x0, [fp, #0x18]
    // 0x856518: stur            x1, [fp, #-8]
    // 0x85651c: StoreField: r1->field_f = r0
    //     0x85651c: stur            w0, [x1, #0xf]
    // 0x856520: LoadField: r2 = r0->field_f
    //     0x856520: ldur            w2, [x0, #0xf]
    // 0x856524: DecompressPointer r2
    //     0x856524: add             x2, x2, HEAP, lsl #32
    // 0x856528: cmp             w2, NULL
    // 0x85652c: b.eq            #0x856968
    // 0x856530: SaveReg r2
    //     0x856530: str             x2, [SP, #-8]!
    // 0x856534: r0 = of()
    //     0x856534: bl              #0x7b2858  ; [package:flutter/src/material/material.dart] Material::of
    // 0x856538: add             SP, SP, #8
    // 0x85653c: mov             x1, x0
    // 0x856540: ldr             x0, [fp, #0x18]
    // 0x856544: stur            x1, [fp, #-0x10]
    // 0x856548: LoadField: r2 = r0->field_f
    //     0x856548: ldur            w2, [x0, #0xf]
    // 0x85654c: DecompressPointer r2
    //     0x85654c: add             x2, x2, HEAP, lsl #32
    // 0x856550: cmp             w2, NULL
    // 0x856554: b.eq            #0x85696c
    // 0x856558: SaveReg r2
    //     0x856558: str             x2, [SP, #-8]!
    // 0x85655c: r0 = findRenderObject()
    //     0x85655c: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x856560: add             SP, SP, #8
    // 0x856564: mov             x3, x0
    // 0x856568: stur            x3, [fp, #-0x18]
    // 0x85656c: cmp             w3, NULL
    // 0x856570: b.eq            #0x856970
    // 0x856574: mov             x0, x3
    // 0x856578: r2 = Null
    //     0x856578: mov             x2, NULL
    // 0x85657c: r1 = Null
    //     0x85657c: mov             x1, NULL
    // 0x856580: r4 = LoadClassIdInstr(r0)
    //     0x856580: ldur            x4, [x0, #-1]
    //     0x856584: ubfx            x4, x4, #0xc, #0x14
    // 0x856588: sub             x4, x4, #0x965
    // 0x85658c: cmp             x4, #0x8b
    // 0x856590: b.ls            #0x8565a8
    // 0x856594: r8 = RenderBox
    //     0x856594: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x856598: ldr             x8, [x8, #0xfa0]
    // 0x85659c: r3 = Null
    //     0x85659c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e338] Null
    //     0x8565a0: ldr             x3, [x3, #0x338]
    // 0x8565a4: r0 = RenderBox()
    //     0x8565a4: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x8565a8: ldur            x16, [fp, #-0x18]
    // 0x8565ac: ldr             lr, [fp, #0x10]
    // 0x8565b0: stp             lr, x16, [SP, #-0x10]!
    // 0x8565b4: r0 = globalToLocal()
    //     0x8565b4: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x8565b8: add             SP, SP, #0x10
    // 0x8565bc: mov             x2, x0
    // 0x8565c0: ldr             x1, [fp, #0x18]
    // 0x8565c4: stur            x2, [fp, #-0x20]
    // 0x8565c8: LoadField: r0 = r1->field_b
    //     0x8565c8: ldur            w0, [x1, #0xb]
    // 0x8565cc: DecompressPointer r0
    //     0x8565cc: add             x0, x0, HEAP, lsl #32
    // 0x8565d0: cmp             w0, NULL
    // 0x8565d4: b.eq            #0x856974
    // 0x8565d8: LoadField: r3 = r0->field_53
    //     0x8565d8: ldur            w3, [x0, #0x53]
    // 0x8565dc: DecompressPointer r3
    //     0x8565dc: add             x3, x3, HEAP, lsl #32
    // 0x8565e0: cmp             w3, NULL
    // 0x8565e4: b.ne            #0x8565f0
    // 0x8565e8: r0 = Null
    //     0x8565e8: mov             x0, NULL
    // 0x8565ec: b               #0x856644
    // 0x8565f0: LoadField: r4 = r0->field_7f
    //     0x8565f0: ldur            w4, [x0, #0x7f]
    // 0x8565f4: DecompressPointer r4
    //     0x8565f4: add             x4, x4, HEAP, lsl #32
    // 0x8565f8: cmp             w4, NULL
    // 0x8565fc: b.ne            #0x856614
    // 0x856600: LoadField: r0 = r1->field_2b
    //     0x856600: ldur            w0, [x1, #0x2b]
    // 0x856604: DecompressPointer r0
    //     0x856604: add             x0, x0, HEAP, lsl #32
    // 0x856608: cmp             w0, NULL
    // 0x85660c: b.eq            #0x856978
    // 0x856610: b               #0x856618
    // 0x856614: mov             x0, x4
    // 0x856618: LoadField: r4 = r0->field_27
    //     0x856618: ldur            w4, [x0, #0x27]
    // 0x85661c: DecompressPointer r4
    //     0x85661c: add             x4, x4, HEAP, lsl #32
    // 0x856620: r0 = LoadClassIdInstr(r3)
    //     0x856620: ldur            x0, [x3, #-1]
    //     0x856624: ubfx            x0, x0, #0xc, #0x14
    // 0x856628: stp             x4, x3, [SP, #-0x10]!
    // 0x85662c: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x85662c: mov             x17, #0x5e7
    //     0x856630: movk            x17, #1, lsl #16
    //     0x856634: add             lr, x0, x17
    //     0x856638: ldr             lr, [x21, lr, lsl #3]
    //     0x85663c: blr             lr
    // 0x856640: add             SP, SP, #0x10
    // 0x856644: cmp             w0, NULL
    // 0x856648: b.ne            #0x856670
    // 0x85664c: ldr             x1, [fp, #0x18]
    // 0x856650: LoadField: r0 = r1->field_b
    //     0x856650: ldur            w0, [x1, #0xb]
    // 0x856654: DecompressPointer r0
    //     0x856654: add             x0, x0, HEAP, lsl #32
    // 0x856658: cmp             w0, NULL
    // 0x85665c: b.eq            #0x85697c
    // 0x856660: LoadField: r2 = r0->field_57
    //     0x856660: ldur            w2, [x0, #0x57]
    // 0x856664: DecompressPointer r2
    //     0x856664: add             x2, x2, HEAP, lsl #32
    // 0x856668: mov             x0, x2
    // 0x85666c: b               #0x856674
    // 0x856670: ldr             x1, [fp, #0x18]
    // 0x856674: cmp             w0, NULL
    // 0x856678: b.ne            #0x8566a8
    // 0x85667c: LoadField: r0 = r1->field_f
    //     0x85667c: ldur            w0, [x1, #0xf]
    // 0x856680: DecompressPointer r0
    //     0x856680: add             x0, x0, HEAP, lsl #32
    // 0x856684: cmp             w0, NULL
    // 0x856688: b.eq            #0x856980
    // 0x85668c: SaveReg r0
    //     0x85668c: str             x0, [SP, #-8]!
    // 0x856690: r0 = of()
    //     0x856690: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x856694: add             SP, SP, #8
    // 0x856698: LoadField: r1 = r0->field_7f
    //     0x856698: ldur            w1, [x0, #0x7f]
    // 0x85669c: DecompressPointer r1
    //     0x85669c: add             x1, x1, HEAP, lsl #32
    // 0x8566a0: mov             x2, x1
    // 0x8566a4: b               #0x8566ac
    // 0x8566a8: mov             x2, x0
    // 0x8566ac: ldr             x1, [fp, #0x18]
    // 0x8566b0: stur            x2, [fp, #-0x28]
    // 0x8566b4: LoadField: r0 = r1->field_b
    //     0x8566b4: ldur            w0, [x1, #0xb]
    // 0x8566b8: DecompressPointer r0
    //     0x8566b8: add             x0, x0, HEAP, lsl #32
    // 0x8566bc: cmp             w0, NULL
    // 0x8566c0: b.eq            #0x856984
    // 0x8566c4: LoadField: r3 = r0->field_33
    //     0x8566c4: ldur            w3, [x0, #0x33]
    // 0x8566c8: DecompressPointer r3
    //     0x8566c8: add             x3, x3, HEAP, lsl #32
    // 0x8566cc: tbnz            w3, #4, #0x856704
    // 0x8566d0: LoadField: r3 = r0->field_7b
    //     0x8566d0: ldur            w3, [x0, #0x7b]
    // 0x8566d4: DecompressPointer r3
    //     0x8566d4: add             x3, x3, HEAP, lsl #32
    // 0x8566d8: cmp             w3, NULL
    // 0x8566dc: b.eq            #0x856988
    // 0x8566e0: ldur            x16, [fp, #-0x18]
    // 0x8566e4: stp             x16, x3, [SP, #-0x10]!
    // 0x8566e8: mov             x0, x3
    // 0x8566ec: ClosureCall
    //     0x8566ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8566f0: ldur            x2, [x0, #0x1f]
    //     0x8566f4: blr             x2
    // 0x8566f8: add             SP, SP, #0x10
    // 0x8566fc: mov             x4, x0
    // 0x856700: b               #0x856708
    // 0x856704: r4 = Null
    //     0x856704: mov             x4, NULL
    // 0x856708: ldr             x0, [fp, #0x18]
    // 0x85670c: ldur            x3, [fp, #-8]
    // 0x856710: stur            x4, [fp, #-0x48]
    // 0x856714: LoadField: r5 = r0->field_b
    //     0x856714: ldur            w5, [x0, #0xb]
    // 0x856718: DecompressPointer r5
    //     0x856718: add             x5, x5, HEAP, lsl #32
    // 0x85671c: stur            x5, [fp, #-0x40]
    // 0x856720: cmp             w5, NULL
    // 0x856724: b.eq            #0x85698c
    // 0x856728: LoadField: r6 = r5->field_3f
    //     0x856728: ldur            w6, [x5, #0x3f]
    // 0x85672c: DecompressPointer r6
    //     0x85672c: add             x6, x6, HEAP, lsl #32
    // 0x856730: stur            x6, [fp, #-0x38]
    // 0x856734: LoadField: r7 = r5->field_43
    //     0x856734: ldur            w7, [x5, #0x43]
    // 0x856738: DecompressPointer r7
    //     0x856738: add             x7, x7, HEAP, lsl #32
    // 0x85673c: stur            x7, [fp, #-0x30]
    // 0x856740: StoreField: r3->field_13 = rNULL
    //     0x856740: stur            NULL, [x3, #0x13]
    // 0x856744: mov             x2, x3
    // 0x856748: r1 = Function 'onRemoved':.
    //     0x856748: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e348] AnonymousClosure: (0x859660), in [package:flutter/src/material/ink_well.dart] _InkResponseState::_createInkFeature (0x8564f0)
    //     0x85674c: ldr             x1, [x1, #0x348]
    // 0x856750: r0 = AllocateClosure()
    //     0x856750: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x856754: mov             x1, x0
    // 0x856758: ldur            x0, [fp, #-0x40]
    // 0x85675c: stur            x1, [fp, #-0x50]
    // 0x856760: LoadField: r2 = r0->field_5b
    //     0x856760: ldur            w2, [x0, #0x5b]
    // 0x856764: DecompressPointer r2
    //     0x856764: add             x2, x2, HEAP, lsl #32
    // 0x856768: cmp             w2, NULL
    // 0x85676c: b.ne            #0x85679c
    // 0x856770: ldr             x0, [fp, #0x18]
    // 0x856774: LoadField: r2 = r0->field_f
    //     0x856774: ldur            w2, [x0, #0xf]
    // 0x856778: DecompressPointer r2
    //     0x856778: add             x2, x2, HEAP, lsl #32
    // 0x85677c: cmp             w2, NULL
    // 0x856780: b.eq            #0x856990
    // 0x856784: SaveReg r2
    //     0x856784: str             x2, [SP, #-8]!
    // 0x856788: r0 = of()
    //     0x856788: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x85678c: add             SP, SP, #8
    // 0x856790: LoadField: r1 = r0->field_27
    //     0x856790: ldur            w1, [x0, #0x27]
    // 0x856794: DecompressPointer r1
    //     0x856794: add             x1, x1, HEAP, lsl #32
    // 0x856798: b               #0x8567a0
    // 0x85679c: mov             x1, x2
    // 0x8567a0: ldr             x0, [fp, #0x18]
    // 0x8567a4: stur            x1, [fp, #-0x60]
    // 0x8567a8: LoadField: r2 = r0->field_b
    //     0x8567a8: ldur            w2, [x0, #0xb]
    // 0x8567ac: DecompressPointer r2
    //     0x8567ac: add             x2, x2, HEAP, lsl #32
    // 0x8567b0: cmp             w2, NULL
    // 0x8567b4: b.eq            #0x856994
    // 0x8567b8: LoadField: r3 = r2->field_33
    //     0x8567b8: ldur            w3, [x2, #0x33]
    // 0x8567bc: DecompressPointer r3
    //     0x8567bc: add             x3, x3, HEAP, lsl #32
    // 0x8567c0: stur            x3, [fp, #-0x58]
    // 0x8567c4: LoadField: r4 = r2->field_3b
    //     0x8567c4: ldur            w4, [x2, #0x3b]
    // 0x8567c8: DecompressPointer r4
    //     0x8567c8: add             x4, x4, HEAP, lsl #32
    // 0x8567cc: stur            x4, [fp, #-0x40]
    // 0x8567d0: LoadField: r2 = r0->field_f
    //     0x8567d0: ldur            w2, [x0, #0xf]
    // 0x8567d4: DecompressPointer r2
    //     0x8567d4: add             x2, x2, HEAP, lsl #32
    // 0x8567d8: cmp             w2, NULL
    // 0x8567dc: b.eq            #0x856998
    // 0x8567e0: SaveReg r2
    //     0x8567e0: str             x2, [SP, #-8]!
    // 0x8567e4: r0 = of()
    //     0x8567e4: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x8567e8: add             SP, SP, #8
    // 0x8567ec: mov             x1, x0
    // 0x8567f0: ldur            x0, [fp, #-0x60]
    // 0x8567f4: stur            x1, [fp, #-0x68]
    // 0x8567f8: r2 = LoadClassIdInstr(r0)
    //     0x8567f8: ldur            x2, [x0, #-1]
    //     0x8567fc: ubfx            x2, x2, #0xc, #0x14
    // 0x856800: lsl             x2, x2, #1
    // 0x856804: r17 = 4382
    //     0x856804: mov             x17, #0x111e
    // 0x856808: cmp             w2, w17
    // 0x85680c: b.ne            #0x85686c
    // 0x856810: r0 = InkSplash()
    //     0x856810: bl              #0x859654  ; AllocateInkSplashStub -> InkSplash (size=0x48)
    // 0x856814: stur            x0, [fp, #-0x60]
    // 0x856818: ldur            x16, [fp, #-0x38]
    // 0x85681c: stp             x16, x0, [SP, #-0x10]!
    // 0x856820: ldur            x16, [fp, #-0x28]
    // 0x856824: ldur            lr, [fp, #-0x58]
    // 0x856828: stp             lr, x16, [SP, #-0x10]!
    // 0x85682c: ldur            x16, [fp, #-0x10]
    // 0x856830: ldur            lr, [fp, #-0x30]
    // 0x856834: stp             lr, x16, [SP, #-0x10]!
    // 0x856838: ldur            x16, [fp, #-0x50]
    // 0x85683c: ldur            lr, [fp, #-0x20]
    // 0x856840: stp             lr, x16, [SP, #-0x10]!
    // 0x856844: ldur            x16, [fp, #-0x40]
    // 0x856848: ldur            lr, [fp, #-0x48]
    // 0x85684c: stp             lr, x16, [SP, #-0x10]!
    // 0x856850: ldur            x16, [fp, #-0x18]
    // 0x856854: ldur            lr, [fp, #-0x68]
    // 0x856858: stp             lr, x16, [SP, #-0x10]!
    // 0x85685c: r0 = InkSplash()
    //     0x85685c: bl              #0x858e18  ; [package:flutter/src/material/ink_splash.dart] InkSplash::InkSplash
    // 0x856860: add             SP, SP, #0x60
    // 0x856864: ldur            x2, [fp, #-0x60]
    // 0x856868: b               #0x85692c
    // 0x85686c: r17 = 4384
    //     0x85686c: mov             x17, #0x1120
    // 0x856870: cmp             w2, w17
    // 0x856874: b.ne            #0x8568d4
    // 0x856878: r0 = InkSparkle()
    //     0x856878: bl              #0x858e0c  ; AllocateInkSparkleStub -> InkSparkle (size=0x58)
    // 0x85687c: stur            x0, [fp, #-0x60]
    // 0x856880: ldur            x16, [fp, #-0x38]
    // 0x856884: stp             x16, x0, [SP, #-0x10]!
    // 0x856888: ldur            x16, [fp, #-0x28]
    // 0x85688c: ldur            lr, [fp, #-0x58]
    // 0x856890: stp             lr, x16, [SP, #-0x10]!
    // 0x856894: ldur            x16, [fp, #-0x10]
    // 0x856898: ldur            lr, [fp, #-0x30]
    // 0x85689c: stp             lr, x16, [SP, #-0x10]!
    // 0x8568a0: ldur            x16, [fp, #-0x50]
    // 0x8568a4: ldur            lr, [fp, #-0x20]
    // 0x8568a8: stp             lr, x16, [SP, #-0x10]!
    // 0x8568ac: ldur            x16, [fp, #-0x40]
    // 0x8568b0: ldur            lr, [fp, #-0x48]
    // 0x8568b4: stp             lr, x16, [SP, #-0x10]!
    // 0x8568b8: ldur            x16, [fp, #-0x18]
    // 0x8568bc: ldur            lr, [fp, #-0x68]
    // 0x8568c0: stp             lr, x16, [SP, #-0x10]!
    // 0x8568c4: r0 = InkSparkle()
    //     0x8568c4: bl              #0x857410  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::InkSparkle
    // 0x8568c8: add             SP, SP, #0x60
    // 0x8568cc: ldur            x2, [fp, #-0x60]
    // 0x8568d0: b               #0x85692c
    // 0x8568d4: r0 = InkRipple()
    //     0x8568d4: bl              #0x857404  ; AllocateInkRippleStub -> InkRipple (size=0x4c)
    // 0x8568d8: stur            x0, [fp, #-0x60]
    // 0x8568dc: ldur            x16, [fp, #-0x38]
    // 0x8568e0: stp             x16, x0, [SP, #-0x10]!
    // 0x8568e4: ldur            x16, [fp, #-0x28]
    // 0x8568e8: ldur            lr, [fp, #-0x58]
    // 0x8568ec: stp             lr, x16, [SP, #-0x10]!
    // 0x8568f0: ldur            x16, [fp, #-0x10]
    // 0x8568f4: ldur            lr, [fp, #-0x30]
    // 0x8568f8: stp             lr, x16, [SP, #-0x10]!
    // 0x8568fc: ldur            x16, [fp, #-0x50]
    // 0x856900: ldur            lr, [fp, #-0x20]
    // 0x856904: stp             lr, x16, [SP, #-0x10]!
    // 0x856908: ldur            x16, [fp, #-0x40]
    // 0x85690c: ldur            lr, [fp, #-0x48]
    // 0x856910: stp             lr, x16, [SP, #-0x10]!
    // 0x856914: ldur            x16, [fp, #-0x18]
    // 0x856918: ldur            lr, [fp, #-0x68]
    // 0x85691c: stp             lr, x16, [SP, #-0x10]!
    // 0x856920: r0 = InkRipple()
    //     0x856920: bl              #0x85699c  ; [package:flutter/src/material/ink_ripple.dart] InkRipple::InkRipple
    // 0x856924: add             SP, SP, #0x60
    // 0x856928: ldur            x2, [fp, #-0x60]
    // 0x85692c: ldur            x1, [fp, #-8]
    // 0x856930: mov             x0, x2
    // 0x856934: StoreField: r1->field_13 = r0
    //     0x856934: stur            w0, [x1, #0x13]
    //     0x856938: ldurb           w16, [x1, #-1]
    //     0x85693c: ldurb           w17, [x0, #-1]
    //     0x856940: and             x16, x17, x16, lsr #2
    //     0x856944: tst             x16, HEAP, lsr #32
    //     0x856948: b.eq            #0x856950
    //     0x85694c: bl              #0xd6826c
    // 0x856950: mov             x0, x2
    // 0x856954: LeaveFrame
    //     0x856954: mov             SP, fp
    //     0x856958: ldp             fp, lr, [SP], #0x10
    // 0x85695c: ret
    //     0x85695c: ret             
    // 0x856960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x856960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x856964: b               #0x856508
    // 0x856968: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856968: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85696c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85696c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856970: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856974: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856974: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856978: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856978: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85697c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85697c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856980: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856980: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856984: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856988: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85698c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85698c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856990: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856994: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856994: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x856998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x856998: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onRemoved(dynamic) {
    // ** addr: 0x859660, size: 0xec
    // 0x859660: EnterFrame
    //     0x859660: stp             fp, lr, [SP, #-0x10]!
    //     0x859664: mov             fp, SP
    // 0x859668: AllocStack(0x8)
    //     0x859668: sub             SP, SP, #8
    // 0x85966c: SetupParameters()
    //     0x85966c: ldr             x0, [fp, #0x10]
    //     0x859670: ldur            w1, [x0, #0x17]
    //     0x859674: add             x1, x1, HEAP, lsl #32
    //     0x859678: stur            x1, [fp, #-8]
    // 0x85967c: CheckStackOverflow
    //     0x85967c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x859680: cmp             SP, x16
    //     0x859684: b.ls            #0x859744
    // 0x859688: LoadField: r0 = r1->field_f
    //     0x859688: ldur            w0, [x1, #0xf]
    // 0x85968c: DecompressPointer r0
    //     0x85968c: add             x0, x0, HEAP, lsl #32
    // 0x859690: LoadField: r2 = r0->field_17
    //     0x859690: ldur            w2, [x0, #0x17]
    // 0x859694: DecompressPointer r2
    //     0x859694: add             x2, x2, HEAP, lsl #32
    // 0x859698: cmp             w2, NULL
    // 0x85969c: b.eq            #0x859734
    // 0x8596a0: LoadField: r0 = r1->field_13
    //     0x8596a0: ldur            w0, [x1, #0x13]
    // 0x8596a4: DecompressPointer r0
    //     0x8596a4: add             x0, x0, HEAP, lsl #32
    // 0x8596a8: r3 = LoadClassIdInstr(r2)
    //     0x8596a8: ldur            x3, [x2, #-1]
    //     0x8596ac: ubfx            x3, x3, #0xc, #0x14
    // 0x8596b0: stp             x0, x2, [SP, #-0x10]!
    // 0x8596b4: mov             x0, x3
    // 0x8596b8: r0 = GDT[cid_x0 + 0x56]()
    //     0x8596b8: add             lr, x0, #0x56
    //     0x8596bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8596c0: blr             lr
    // 0x8596c4: add             SP, SP, #0x10
    // 0x8596c8: ldur            x1, [fp, #-8]
    // 0x8596cc: LoadField: r0 = r1->field_f
    //     0x8596cc: ldur            w0, [x1, #0xf]
    // 0x8596d0: DecompressPointer r0
    //     0x8596d0: add             x0, x0, HEAP, lsl #32
    // 0x8596d4: LoadField: r2 = r0->field_1b
    //     0x8596d4: ldur            w2, [x0, #0x1b]
    // 0x8596d8: DecompressPointer r2
    //     0x8596d8: add             x2, x2, HEAP, lsl #32
    // 0x8596dc: LoadField: r0 = r1->field_13
    //     0x8596dc: ldur            w0, [x1, #0x13]
    // 0x8596e0: DecompressPointer r0
    //     0x8596e0: add             x0, x0, HEAP, lsl #32
    // 0x8596e4: r3 = LoadClassIdInstr(r2)
    //     0x8596e4: ldur            x3, [x2, #-1]
    //     0x8596e8: ubfx            x3, x3, #0xc, #0x14
    // 0x8596ec: stp             x0, x2, [SP, #-0x10]!
    // 0x8596f0: mov             x0, x3
    // 0x8596f4: mov             lr, x0
    // 0x8596f8: ldr             lr, [x21, lr, lsl #3]
    // 0x8596fc: blr             lr
    // 0x859700: add             SP, SP, #0x10
    // 0x859704: tbnz            w0, #4, #0x85971c
    // 0x859708: ldur            x0, [fp, #-8]
    // 0x85970c: LoadField: r1 = r0->field_f
    //     0x85970c: ldur            w1, [x0, #0xf]
    // 0x859710: DecompressPointer r1
    //     0x859710: add             x1, x1, HEAP, lsl #32
    // 0x859714: StoreField: r1->field_1b = rNULL
    //     0x859714: stur            NULL, [x1, #0x1b]
    // 0x859718: b               #0x859720
    // 0x85971c: ldur            x0, [fp, #-8]
    // 0x859720: LoadField: r1 = r0->field_f
    //     0x859720: ldur            w1, [x0, #0xf]
    // 0x859724: DecompressPointer r1
    //     0x859724: add             x1, x1, HEAP, lsl #32
    // 0x859728: SaveReg r1
    //     0x859728: str             x1, [SP, #-8]!
    // 0x85972c: r0 = updateKeepAlive()
    //     0x85972c: bl              #0x7b2150  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::updateKeepAlive
    // 0x859730: add             SP, SP, #8
    // 0x859734: r0 = Null
    //     0x859734: mov             x0, NULL
    // 0x859738: LeaveFrame
    //     0x859738: mov             SP, fp
    //     0x85973c: ldp             fp, lr, [SP], #0x10
    // 0x859740: ret
    //     0x859740: ret             
    // 0x859744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859748: b               #0x859688
  }
  [closure] void simulateLongPress(dynamic) {
    // ** addr: 0x85974c, size: 0x48
    // 0x85974c: EnterFrame
    //     0x85974c: stp             fp, lr, [SP, #-0x10]!
    //     0x859750: mov             fp, SP
    // 0x859754: ldr             x0, [fp, #0x10]
    // 0x859758: LoadField: r1 = r0->field_17
    //     0x859758: ldur            w1, [x0, #0x17]
    // 0x85975c: DecompressPointer r1
    //     0x85975c: add             x1, x1, HEAP, lsl #32
    // 0x859760: CheckStackOverflow
    //     0x859760: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x859764: cmp             SP, x16
    //     0x859768: b.ls            #0x85978c
    // 0x85976c: LoadField: r0 = r1->field_f
    //     0x85976c: ldur            w0, [x1, #0xf]
    // 0x859770: DecompressPointer r0
    //     0x859770: add             x0, x0, HEAP, lsl #32
    // 0x859774: SaveReg r0
    //     0x859774: str             x0, [SP, #-8]!
    // 0x859778: r0 = simulateLongPress()
    //     0x859778: bl              #0x859794  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateLongPress
    // 0x85977c: add             SP, SP, #8
    // 0x859780: LeaveFrame
    //     0x859780: mov             SP, fp
    //     0x859784: ldp             fp, lr, [SP], #0x10
    // 0x859788: ret
    //     0x859788: ret             
    // 0x85978c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85978c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859790: b               #0x85976c
  }
  _ simulateLongPress(/* No info */) {
    // ** addr: 0x859794, size: 0x68
    // 0x859794: EnterFrame
    //     0x859794: stp             fp, lr, [SP, #-0x10]!
    //     0x859798: mov             fp, SP
    // 0x85979c: CheckStackOverflow
    //     0x85979c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8597a0: cmp             SP, x16
    //     0x8597a4: b.ls            #0x8597f0
    // 0x8597a8: ldr             x0, [fp, #0x10]
    // 0x8597ac: LoadField: r1 = r0->field_f
    //     0x8597ac: ldur            w1, [x0, #0xf]
    // 0x8597b0: DecompressPointer r1
    //     0x8597b0: add             x1, x1, HEAP, lsl #32
    // 0x8597b4: cmp             w1, NULL
    // 0x8597b8: b.eq            #0x8597f8
    // 0x8597bc: stp             x1, x0, [SP, #-0x10]!
    // 0x8597c0: r4 = const [0, 0x2, 0x2, 0x1, context, 0x1, null]
    //     0x8597c0: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e458] List(7) [0, 0x2, 0x2, 0x1, "context", 0x1, Null]
    //     0x8597c4: ldr             x4, [x4, #0x458]
    // 0x8597c8: r0 = _startNewSplash()
    //     0x8597c8: bl              #0x8560b0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_startNewSplash
    // 0x8597cc: add             SP, SP, #0x10
    // 0x8597d0: ldr             x16, [fp, #0x10]
    // 0x8597d4: SaveReg r16
    //     0x8597d4: str             x16, [SP, #-8]!
    // 0x8597d8: r0 = handleLongPress()
    //     0x8597d8: bl              #0x855648  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleLongPress
    // 0x8597dc: add             SP, SP, #8
    // 0x8597e0: r0 = Null
    //     0x8597e0: mov             x0, NULL
    // 0x8597e4: LeaveFrame
    //     0x8597e4: mov             SP, fp
    //     0x8597e8: ldp             fp, lr, [SP], #0x10
    // 0x8597ec: ret
    //     0x8597ec: ret             
    // 0x8597f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8597f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8597f4: b               #0x8597a8
    // 0x8597f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8597f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void simulateTap(dynamic, [Intent?]) {
    // ** addr: 0x8597fc, size: 0x7c
    // 0x8597fc: EnterFrame
    //     0x8597fc: stp             fp, lr, [SP, #-0x10]!
    //     0x859800: mov             fp, SP
    // 0x859804: mov             x0, x4
    // 0x859808: LoadField: r1 = r0->field_13
    //     0x859808: ldur            w1, [x0, #0x13]
    // 0x85980c: DecompressPointer r1
    //     0x85980c: add             x1, x1, HEAP, lsl #32
    // 0x859810: sub             x0, x1, #2
    // 0x859814: add             x1, fp, w0, sxtw #2
    // 0x859818: ldr             x1, [x1, #0x10]
    // 0x85981c: cmp             w0, #2
    // 0x859820: b.lt            #0x859834
    // 0x859824: add             x2, fp, w0, sxtw #2
    // 0x859828: ldr             x2, [x2, #8]
    // 0x85982c: mov             x0, x2
    // 0x859830: b               #0x859838
    // 0x859834: r0 = Null
    //     0x859834: mov             x0, NULL
    // 0x859838: LoadField: r2 = r1->field_17
    //     0x859838: ldur            w2, [x1, #0x17]
    // 0x85983c: DecompressPointer r2
    //     0x85983c: add             x2, x2, HEAP, lsl #32
    // 0x859840: CheckStackOverflow
    //     0x859840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x859844: cmp             SP, x16
    //     0x859848: b.ls            #0x859870
    // 0x85984c: LoadField: r1 = r2->field_f
    //     0x85984c: ldur            w1, [x2, #0xf]
    // 0x859850: DecompressPointer r1
    //     0x859850: add             x1, x1, HEAP, lsl #32
    // 0x859854: stp             x0, x1, [SP, #-0x10]!
    // 0x859858: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x859858: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x85985c: r0 = simulateTap()
    //     0x85985c: bl              #0x859878  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateTap
    // 0x859860: add             SP, SP, #0x10
    // 0x859864: LeaveFrame
    //     0x859864: mov             SP, fp
    //     0x859868: ldp             fp, lr, [SP], #0x10
    // 0x85986c: ret
    //     0x85986c: ret             
    // 0x859870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859874: b               #0x85984c
  }
  _ simulateTap(/* No info */) {
    // ** addr: 0x859878, size: 0x84
    // 0x859878: EnterFrame
    //     0x859878: stp             fp, lr, [SP, #-0x10]!
    //     0x85987c: mov             fp, SP
    // 0x859880: AllocStack(0x8)
    //     0x859880: sub             SP, SP, #8
    // 0x859884: SetupParameters(_InkResponseState<_InkResponseStateWidget> this /* r1, fp-0x8 */)
    //     0x859884: mov             x0, x4
    //     0x859888: ldur            w1, [x0, #0x13]
    //     0x85988c: add             x1, x1, HEAP, lsl #32
    //     0x859890: sub             x0, x1, #2
    //     0x859894: add             x1, fp, w0, sxtw #2
    //     0x859898: ldr             x1, [x1, #0x10]
    //     0x85989c: stur            x1, [fp, #-8]
    // 0x8598a0: CheckStackOverflow
    //     0x8598a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8598a4: cmp             SP, x16
    //     0x8598a8: b.ls            #0x8598f0
    // 0x8598ac: LoadField: r0 = r1->field_f
    //     0x8598ac: ldur            w0, [x1, #0xf]
    // 0x8598b0: DecompressPointer r0
    //     0x8598b0: add             x0, x0, HEAP, lsl #32
    // 0x8598b4: cmp             w0, NULL
    // 0x8598b8: b.eq            #0x8598f8
    // 0x8598bc: stp             x0, x1, [SP, #-0x10]!
    // 0x8598c0: r4 = const [0, 0x2, 0x2, 0x1, context, 0x1, null]
    //     0x8598c0: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e458] List(7) [0, 0x2, 0x2, 0x1, "context", 0x1, Null]
    //     0x8598c4: ldr             x4, [x4, #0x458]
    // 0x8598c8: r0 = _startNewSplash()
    //     0x8598c8: bl              #0x8560b0  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_startNewSplash
    // 0x8598cc: add             SP, SP, #0x10
    // 0x8598d0: ldur            x16, [fp, #-8]
    // 0x8598d4: SaveReg r16
    //     0x8598d4: str             x16, [SP, #-8]!
    // 0x8598d8: r0 = handleTap()
    //     0x8598d8: bl              #0x855b64  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleTap
    // 0x8598dc: add             SP, SP, #8
    // 0x8598e0: r0 = Null
    //     0x8598e0: mov             x0, NULL
    // 0x8598e4: LeaveFrame
    //     0x8598e4: mov             SP, fp
    //     0x8598e8: ldp             fp, lr, [SP], #0x10
    // 0x8598ec: ret
    //     0x8598ec: ret             
    // 0x8598f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8598f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8598f4: b               #0x8598ac
    // 0x8598f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8598f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  Map<Type, Action<Intent>> _actionMap(_InkResponseState) {
    // ** addr: 0x8598fc, size: 0x258
    // 0x8598fc: EnterFrame
    //     0x8598fc: stp             fp, lr, [SP, #-0x10]!
    //     0x859900: mov             fp, SP
    // 0x859904: AllocStack(0x18)
    //     0x859904: sub             SP, SP, #0x18
    // 0x859908: CheckStackOverflow
    //     0x859908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85990c: cmp             SP, x16
    //     0x859910: b.ls            #0x859b4c
    // 0x859914: r1 = Null
    //     0x859914: mov             x1, NULL
    // 0x859918: r2 = 8
    //     0x859918: mov             x2, #8
    // 0x85991c: r0 = AllocateArray()
    //     0x85991c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x859920: mov             x1, x0
    // 0x859924: stur            x1, [fp, #-8]
    // 0x859928: r17 = ActivateIntent
    //     0x859928: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e460] Type: ActivateIntent
    //     0x85992c: ldr             x17, [x17, #0x460]
    // 0x859930: StoreField: r1->field_f = r17
    //     0x859930: stur            w17, [x1, #0xf]
    // 0x859934: ldr             x2, [fp, #0x10]
    // 0x859938: r0 = 59
    //     0x859938: mov             x0, #0x3b
    // 0x85993c: branchIfSmi(r2, 0x859948)
    //     0x85993c: tbz             w2, #0, #0x859948
    // 0x859940: r0 = LoadClassIdInstr(r2)
    //     0x859940: ldur            x0, [x2, #-1]
    //     0x859944: ubfx            x0, x0, #0xc, #0x14
    // 0x859948: SaveReg r2
    //     0x859948: str             x2, [SP, #-8]!
    // 0x85994c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x85994c: sub             lr, x0, #1, lsl #12
    //     0x859950: ldr             lr, [x21, lr, lsl #3]
    //     0x859954: blr             lr
    // 0x859958: add             SP, SP, #8
    // 0x85995c: r1 = <ActivateIntent>
    //     0x85995c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e468] TypeArguments: <ActivateIntent>
    //     0x859960: ldr             x1, [x1, #0x468]
    // 0x859964: stur            x0, [fp, #-0x10]
    // 0x859968: r0 = CallbackAction()
    //     0x859968: bl              #0x837e0c  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0x85996c: mov             x2, x0
    // 0x859970: ldur            x0, [fp, #-0x10]
    // 0x859974: stur            x2, [fp, #-0x18]
    // 0x859978: StoreField: r2->field_13 = r0
    //     0x859978: stur            w0, [x2, #0x13]
    // 0x85997c: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0x85997c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x859980: ldr             x1, [x1, #0xcc0]
    // 0x859984: r0 = ObserverList()
    //     0x859984: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x859988: mov             x1, x0
    // 0x85998c: r0 = false
    //     0x85998c: add             x0, NULL, #0x30  ; false
    // 0x859990: stur            x1, [fp, #-0x10]
    // 0x859994: StoreField: r1->field_f = r0
    //     0x859994: stur            w0, [x1, #0xf]
    // 0x859998: r2 = Sentinel
    //     0x859998: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x85999c: StoreField: r1->field_13 = r2
    //     0x85999c: stur            w2, [x1, #0x13]
    // 0x8599a0: r16 = <(dynamic this, Action<Intent>) => void?>
    //     0x8599a0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x8599a4: ldr             x16, [x16, #0xcc0]
    // 0x8599a8: stp             xzr, x16, [SP, #-0x10]!
    // 0x8599ac: r0 = _GrowableList()
    //     0x8599ac: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8599b0: add             SP, SP, #0x10
    // 0x8599b4: ldur            x1, [fp, #-0x10]
    // 0x8599b8: StoreField: r1->field_b = r0
    //     0x8599b8: stur            w0, [x1, #0xb]
    //     0x8599bc: ldurb           w16, [x1, #-1]
    //     0x8599c0: ldurb           w17, [x0, #-1]
    //     0x8599c4: and             x16, x17, x16, lsr #2
    //     0x8599c8: tst             x16, HEAP, lsr #32
    //     0x8599cc: b.eq            #0x8599d4
    //     0x8599d0: bl              #0xd6826c
    // 0x8599d4: mov             x0, x1
    // 0x8599d8: ldur            x1, [fp, #-0x18]
    // 0x8599dc: StoreField: r1->field_b = r0
    //     0x8599dc: stur            w0, [x1, #0xb]
    //     0x8599e0: ldurb           w16, [x1, #-1]
    //     0x8599e4: ldurb           w17, [x0, #-1]
    //     0x8599e8: and             x16, x17, x16, lsr #2
    //     0x8599ec: tst             x16, HEAP, lsr #32
    //     0x8599f0: b.eq            #0x8599f8
    //     0x8599f4: bl              #0xd6826c
    // 0x8599f8: mov             x0, x1
    // 0x8599fc: ldur            x1, [fp, #-8]
    // 0x859a00: ArrayStore: r1[1] = r0  ; List_4
    //     0x859a00: add             x25, x1, #0x13
    //     0x859a04: str             w0, [x25]
    //     0x859a08: tbz             w0, #0, #0x859a24
    //     0x859a0c: ldurb           w16, [x1, #-1]
    //     0x859a10: ldurb           w17, [x0, #-1]
    //     0x859a14: and             x16, x17, x16, lsr #2
    //     0x859a18: tst             x16, HEAP, lsr #32
    //     0x859a1c: b.eq            #0x859a24
    //     0x859a20: bl              #0xd67e5c
    // 0x859a24: ldur            x1, [fp, #-8]
    // 0x859a28: r17 = ButtonActivateIntent
    //     0x859a28: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e470] Type: ButtonActivateIntent
    //     0x859a2c: ldr             x17, [x17, #0x470]
    // 0x859a30: StoreField: r1->field_17 = r17
    //     0x859a30: stur            w17, [x1, #0x17]
    // 0x859a34: ldr             x0, [fp, #0x10]
    // 0x859a38: r2 = 59
    //     0x859a38: mov             x2, #0x3b
    // 0x859a3c: branchIfSmi(r0, 0x859a48)
    //     0x859a3c: tbz             w0, #0, #0x859a48
    // 0x859a40: r2 = LoadClassIdInstr(r0)
    //     0x859a40: ldur            x2, [x0, #-1]
    //     0x859a44: ubfx            x2, x2, #0xc, #0x14
    // 0x859a48: SaveReg r0
    //     0x859a48: str             x0, [SP, #-8]!
    // 0x859a4c: mov             x0, x2
    // 0x859a50: r0 = GDT[cid_x0 + -0x1000]()
    //     0x859a50: sub             lr, x0, #1, lsl #12
    //     0x859a54: ldr             lr, [x21, lr, lsl #3]
    //     0x859a58: blr             lr
    // 0x859a5c: add             SP, SP, #8
    // 0x859a60: r1 = <ButtonActivateIntent>
    //     0x859a60: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e478] TypeArguments: <ButtonActivateIntent>
    //     0x859a64: ldr             x1, [x1, #0x478]
    // 0x859a68: stur            x0, [fp, #-0x10]
    // 0x859a6c: r0 = CallbackAction()
    //     0x859a6c: bl              #0x837e0c  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0x859a70: mov             x2, x0
    // 0x859a74: ldur            x0, [fp, #-0x10]
    // 0x859a78: stur            x2, [fp, #-0x18]
    // 0x859a7c: StoreField: r2->field_13 = r0
    //     0x859a7c: stur            w0, [x2, #0x13]
    // 0x859a80: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0x859a80: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x859a84: ldr             x1, [x1, #0xcc0]
    // 0x859a88: r0 = ObserverList()
    //     0x859a88: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x859a8c: mov             x1, x0
    // 0x859a90: r0 = false
    //     0x859a90: add             x0, NULL, #0x30  ; false
    // 0x859a94: stur            x1, [fp, #-0x10]
    // 0x859a98: StoreField: r1->field_f = r0
    //     0x859a98: stur            w0, [x1, #0xf]
    // 0x859a9c: r0 = Sentinel
    //     0x859a9c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x859aa0: StoreField: r1->field_13 = r0
    //     0x859aa0: stur            w0, [x1, #0x13]
    // 0x859aa4: r16 = <(dynamic this, Action<Intent>) => void?>
    //     0x859aa4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x859aa8: ldr             x16, [x16, #0xcc0]
    // 0x859aac: stp             xzr, x16, [SP, #-0x10]!
    // 0x859ab0: r0 = _GrowableList()
    //     0x859ab0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x859ab4: add             SP, SP, #0x10
    // 0x859ab8: ldur            x1, [fp, #-0x10]
    // 0x859abc: StoreField: r1->field_b = r0
    //     0x859abc: stur            w0, [x1, #0xb]
    //     0x859ac0: ldurb           w16, [x1, #-1]
    //     0x859ac4: ldurb           w17, [x0, #-1]
    //     0x859ac8: and             x16, x17, x16, lsr #2
    //     0x859acc: tst             x16, HEAP, lsr #32
    //     0x859ad0: b.eq            #0x859ad8
    //     0x859ad4: bl              #0xd6826c
    // 0x859ad8: mov             x0, x1
    // 0x859adc: ldur            x1, [fp, #-0x18]
    // 0x859ae0: StoreField: r1->field_b = r0
    //     0x859ae0: stur            w0, [x1, #0xb]
    //     0x859ae4: ldurb           w16, [x1, #-1]
    //     0x859ae8: ldurb           w17, [x0, #-1]
    //     0x859aec: and             x16, x17, x16, lsr #2
    //     0x859af0: tst             x16, HEAP, lsr #32
    //     0x859af4: b.eq            #0x859afc
    //     0x859af8: bl              #0xd6826c
    // 0x859afc: mov             x0, x1
    // 0x859b00: ldur            x1, [fp, #-8]
    // 0x859b04: ArrayStore: r1[3] = r0  ; List_4
    //     0x859b04: add             x25, x1, #0x1b
    //     0x859b08: str             w0, [x25]
    //     0x859b0c: tbz             w0, #0, #0x859b28
    //     0x859b10: ldurb           w16, [x1, #-1]
    //     0x859b14: ldurb           w17, [x0, #-1]
    //     0x859b18: and             x16, x17, x16, lsr #2
    //     0x859b1c: tst             x16, HEAP, lsr #32
    //     0x859b20: b.eq            #0x859b28
    //     0x859b24: bl              #0xd67e5c
    // 0x859b28: r16 = <Type, Action<Intent>>
    //     0x859b28: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e40] TypeArguments: <Type, Action<Intent>>
    //     0x859b2c: ldr             x16, [x16, #0xe40]
    // 0x859b30: ldur            lr, [fp, #-8]
    // 0x859b34: stp             lr, x16, [SP, #-0x10]!
    // 0x859b38: r0 = Map._fromLiteral()
    //     0x859b38: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x859b3c: add             SP, SP, #0x10
    // 0x859b40: LeaveFrame
    //     0x859b40: mov             SP, fp
    //     0x859b44: ldp             fp, lr, [SP], #0x10
    // 0x859b48: ret
    //     0x859b48: ret             
    // 0x859b4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859b4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859b50: b               #0x859914
  }
  [closure] Color getHighlightColorForType(dynamic, _HighlightType) {
    // ** addr: 0x859b70, size: 0x2a8
    // 0x859b70: EnterFrame
    //     0x859b70: stp             fp, lr, [SP, #-0x10]!
    //     0x859b74: mov             fp, SP
    // 0x859b78: AllocStack(0x10)
    //     0x859b78: sub             SP, SP, #0x10
    // 0x859b7c: SetupParameters()
    //     0x859b7c: ldr             x0, [fp, #0x18]
    //     0x859b80: ldur            w1, [x0, #0x17]
    //     0x859b84: add             x1, x1, HEAP, lsl #32
    //     0x859b88: stur            x1, [fp, #-8]
    // 0x859b8c: CheckStackOverflow
    //     0x859b8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x859b90: cmp             SP, x16
    //     0x859b94: b.ls            #0x859df8
    // 0x859b98: LoadField: r0 = r1->field_13
    //     0x859b98: ldur            w0, [x1, #0x13]
    // 0x859b9c: DecompressPointer r0
    //     0x859b9c: add             x0, x0, HEAP, lsl #32
    // 0x859ba0: SaveReg r0
    //     0x859ba0: str             x0, [SP, #-8]!
    // 0x859ba4: r0 = of()
    //     0x859ba4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x859ba8: add             SP, SP, #8
    // 0x859bac: mov             x1, x0
    // 0x859bb0: ldr             x0, [fp, #0x10]
    // 0x859bb4: stur            x1, [fp, #-0x10]
    // 0x859bb8: LoadField: r2 = r0->field_7
    //     0x859bb8: ldur            x2, [x0, #7]
    // 0x859bbc: cmp             x2, #1
    // 0x859bc0: b.gt            #0x859d30
    // 0x859bc4: cmp             x2, #0
    // 0x859bc8: b.gt            #0x859c7c
    // 0x859bcc: ldur            x2, [fp, #-8]
    // 0x859bd0: LoadField: r0 = r2->field_f
    //     0x859bd0: ldur            w0, [x2, #0xf]
    // 0x859bd4: DecompressPointer r0
    //     0x859bd4: add             x0, x0, HEAP, lsl #32
    // 0x859bd8: LoadField: r3 = r0->field_b
    //     0x859bd8: ldur            w3, [x0, #0xb]
    // 0x859bdc: DecompressPointer r3
    //     0x859bdc: add             x3, x3, HEAP, lsl #32
    // 0x859be0: cmp             w3, NULL
    // 0x859be4: b.eq            #0x859e00
    // 0x859be8: LoadField: r0 = r3->field_53
    //     0x859be8: ldur            w0, [x3, #0x53]
    // 0x859bec: DecompressPointer r0
    //     0x859bec: add             x0, x0, HEAP, lsl #32
    // 0x859bf0: cmp             w0, NULL
    // 0x859bf4: b.ne            #0x859c00
    // 0x859bf8: r0 = Null
    //     0x859bf8: mov             x0, NULL
    // 0x859bfc: b               #0x859c30
    // 0x859c00: r3 = LoadClassIdInstr(r0)
    //     0x859c00: ldur            x3, [x0, #-1]
    //     0x859c04: ubfx            x3, x3, #0xc, #0x14
    // 0x859c08: r16 = _ConstSet len:1
    //     0x859c08: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e480] Set<MaterialState>(1)
    //     0x859c0c: ldr             x16, [x16, #0x480]
    // 0x859c10: stp             x16, x0, [SP, #-0x10]!
    // 0x859c14: mov             x0, x3
    // 0x859c18: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x859c18: mov             x17, #0x5e7
    //     0x859c1c: movk            x17, #1, lsl #16
    //     0x859c20: add             lr, x0, x17
    //     0x859c24: ldr             lr, [x21, lr, lsl #3]
    //     0x859c28: blr             lr
    // 0x859c2c: add             SP, SP, #0x10
    // 0x859c30: cmp             w0, NULL
    // 0x859c34: b.ne            #0x859c5c
    // 0x859c38: ldur            x1, [fp, #-8]
    // 0x859c3c: LoadField: r0 = r1->field_f
    //     0x859c3c: ldur            w0, [x1, #0xf]
    // 0x859c40: DecompressPointer r0
    //     0x859c40: add             x0, x0, HEAP, lsl #32
    // 0x859c44: LoadField: r1 = r0->field_b
    //     0x859c44: ldur            w1, [x0, #0xb]
    // 0x859c48: DecompressPointer r1
    //     0x859c48: add             x1, x1, HEAP, lsl #32
    // 0x859c4c: cmp             w1, NULL
    // 0x859c50: b.eq            #0x859e04
    // 0x859c54: LoadField: r0 = r1->field_4f
    //     0x859c54: ldur            w0, [x1, #0x4f]
    // 0x859c58: DecompressPointer r0
    //     0x859c58: add             x0, x0, HEAP, lsl #32
    // 0x859c5c: cmp             w0, NULL
    // 0x859c60: b.ne            #0x859c70
    // 0x859c64: ldur            x2, [fp, #-0x10]
    // 0x859c68: LoadField: r0 = r2->field_53
    //     0x859c68: ldur            w0, [x2, #0x53]
    // 0x859c6c: DecompressPointer r0
    //     0x859c6c: add             x0, x0, HEAP, lsl #32
    // 0x859c70: LeaveFrame
    //     0x859c70: mov             SP, fp
    //     0x859c74: ldp             fp, lr, [SP], #0x10
    // 0x859c78: ret
    //     0x859c78: ret             
    // 0x859c7c: mov             x2, x1
    // 0x859c80: ldur            x1, [fp, #-8]
    // 0x859c84: LoadField: r0 = r1->field_f
    //     0x859c84: ldur            w0, [x1, #0xf]
    // 0x859c88: DecompressPointer r0
    //     0x859c88: add             x0, x0, HEAP, lsl #32
    // 0x859c8c: LoadField: r3 = r0->field_b
    //     0x859c8c: ldur            w3, [x0, #0xb]
    // 0x859c90: DecompressPointer r3
    //     0x859c90: add             x3, x3, HEAP, lsl #32
    // 0x859c94: cmp             w3, NULL
    // 0x859c98: b.eq            #0x859e08
    // 0x859c9c: LoadField: r0 = r3->field_53
    //     0x859c9c: ldur            w0, [x3, #0x53]
    // 0x859ca0: DecompressPointer r0
    //     0x859ca0: add             x0, x0, HEAP, lsl #32
    // 0x859ca4: cmp             w0, NULL
    // 0x859ca8: b.ne            #0x859cb4
    // 0x859cac: r0 = Null
    //     0x859cac: mov             x0, NULL
    // 0x859cb0: b               #0x859ce4
    // 0x859cb4: r3 = LoadClassIdInstr(r0)
    //     0x859cb4: ldur            x3, [x0, #-1]
    //     0x859cb8: ubfx            x3, x3, #0xc, #0x14
    // 0x859cbc: r16 = _ConstSet len:1
    //     0x859cbc: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e488] Set<MaterialState>(1)
    //     0x859cc0: ldr             x16, [x16, #0x488]
    // 0x859cc4: stp             x16, x0, [SP, #-0x10]!
    // 0x859cc8: mov             x0, x3
    // 0x859ccc: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x859ccc: mov             x17, #0x5e7
    //     0x859cd0: movk            x17, #1, lsl #16
    //     0x859cd4: add             lr, x0, x17
    //     0x859cd8: ldr             lr, [x21, lr, lsl #3]
    //     0x859cdc: blr             lr
    // 0x859ce0: add             SP, SP, #0x10
    // 0x859ce4: cmp             w0, NULL
    // 0x859ce8: b.ne            #0x859d10
    // 0x859cec: ldur            x1, [fp, #-8]
    // 0x859cf0: LoadField: r0 = r1->field_f
    //     0x859cf0: ldur            w0, [x1, #0xf]
    // 0x859cf4: DecompressPointer r0
    //     0x859cf4: add             x0, x0, HEAP, lsl #32
    // 0x859cf8: LoadField: r1 = r0->field_b
    //     0x859cf8: ldur            w1, [x0, #0xb]
    // 0x859cfc: DecompressPointer r1
    //     0x859cfc: add             x1, x1, HEAP, lsl #32
    // 0x859d00: cmp             w1, NULL
    // 0x859d04: b.eq            #0x859e0c
    // 0x859d08: LoadField: r0 = r1->field_4b
    //     0x859d08: ldur            w0, [x1, #0x4b]
    // 0x859d0c: DecompressPointer r0
    //     0x859d0c: add             x0, x0, HEAP, lsl #32
    // 0x859d10: cmp             w0, NULL
    // 0x859d14: b.ne            #0x859d24
    // 0x859d18: ldur            x2, [fp, #-0x10]
    // 0x859d1c: LoadField: r0 = r2->field_5b
    //     0x859d1c: ldur            w0, [x2, #0x5b]
    // 0x859d20: DecompressPointer r0
    //     0x859d20: add             x0, x0, HEAP, lsl #32
    // 0x859d24: LeaveFrame
    //     0x859d24: mov             SP, fp
    //     0x859d28: ldp             fp, lr, [SP], #0x10
    // 0x859d2c: ret
    //     0x859d2c: ret             
    // 0x859d30: mov             x2, x1
    // 0x859d34: ldur            x1, [fp, #-8]
    // 0x859d38: LoadField: r0 = r1->field_f
    //     0x859d38: ldur            w0, [x1, #0xf]
    // 0x859d3c: DecompressPointer r0
    //     0x859d3c: add             x0, x0, HEAP, lsl #32
    // 0x859d40: LoadField: r3 = r0->field_b
    //     0x859d40: ldur            w3, [x0, #0xb]
    // 0x859d44: DecompressPointer r3
    //     0x859d44: add             x3, x3, HEAP, lsl #32
    // 0x859d48: cmp             w3, NULL
    // 0x859d4c: b.eq            #0x859e10
    // 0x859d50: LoadField: r0 = r3->field_53
    //     0x859d50: ldur            w0, [x3, #0x53]
    // 0x859d54: DecompressPointer r0
    //     0x859d54: add             x0, x0, HEAP, lsl #32
    // 0x859d58: cmp             w0, NULL
    // 0x859d5c: b.ne            #0x859d68
    // 0x859d60: r1 = Null
    //     0x859d60: mov             x1, NULL
    // 0x859d64: b               #0x859d9c
    // 0x859d68: r3 = LoadClassIdInstr(r0)
    //     0x859d68: ldur            x3, [x0, #-1]
    //     0x859d6c: ubfx            x3, x3, #0xc, #0x14
    // 0x859d70: r16 = _ConstSet len:1
    //     0x859d70: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e490] Set<MaterialState>(1)
    //     0x859d74: ldr             x16, [x16, #0x490]
    // 0x859d78: stp             x16, x0, [SP, #-0x10]!
    // 0x859d7c: mov             x0, x3
    // 0x859d80: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x859d80: mov             x17, #0x5e7
    //     0x859d84: movk            x17, #1, lsl #16
    //     0x859d88: add             lr, x0, x17
    //     0x859d8c: ldr             lr, [x21, lr, lsl #3]
    //     0x859d90: blr             lr
    // 0x859d94: add             SP, SP, #0x10
    // 0x859d98: mov             x1, x0
    // 0x859d9c: cmp             w1, NULL
    // 0x859da0: b.ne            #0x859dcc
    // 0x859da4: ldur            x2, [fp, #-8]
    // 0x859da8: LoadField: r3 = r2->field_f
    //     0x859da8: ldur            w3, [x2, #0xf]
    // 0x859dac: DecompressPointer r3
    //     0x859dac: add             x3, x3, HEAP, lsl #32
    // 0x859db0: LoadField: r2 = r3->field_b
    //     0x859db0: ldur            w2, [x3, #0xb]
    // 0x859db4: DecompressPointer r2
    //     0x859db4: add             x2, x2, HEAP, lsl #32
    // 0x859db8: cmp             w2, NULL
    // 0x859dbc: b.eq            #0x859e14
    // 0x859dc0: LoadField: r3 = r2->field_47
    //     0x859dc0: ldur            w3, [x2, #0x47]
    // 0x859dc4: DecompressPointer r3
    //     0x859dc4: add             x3, x3, HEAP, lsl #32
    // 0x859dc8: mov             x1, x3
    // 0x859dcc: cmp             w1, NULL
    // 0x859dd0: b.ne            #0x859de8
    // 0x859dd4: ldur            x2, [fp, #-0x10]
    // 0x859dd8: LoadField: r3 = r2->field_4f
    //     0x859dd8: ldur            w3, [x2, #0x4f]
    // 0x859ddc: DecompressPointer r3
    //     0x859ddc: add             x3, x3, HEAP, lsl #32
    // 0x859de0: mov             x0, x3
    // 0x859de4: b               #0x859dec
    // 0x859de8: mov             x0, x1
    // 0x859dec: LeaveFrame
    //     0x859dec: mov             SP, fp
    //     0x859df0: ldp             fp, lr, [SP], #0x10
    // 0x859df4: ret
    //     0x859df4: ret             
    // 0x859df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859dfc: b               #0x859b98
    // 0x859e00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859e00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x859e04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859e04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x859e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859e08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x859e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859e0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x859e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859e10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x859e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x859e14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9fa8, size: 0xb8
    // 0x9d9fa8: EnterFrame
    //     0x9d9fa8: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9fac: mov             fp, SP
    // 0x9d9fb0: AllocStack(0x8)
    //     0x9d9fb0: sub             SP, SP, #8
    // 0x9d9fb4: CheckStackOverflow
    //     0x9d9fb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9fb8: cmp             SP, x16
    //     0x9d9fbc: b.ls            #0x9da050
    // 0x9d9fc0: ldr             x16, [fp, #0x10]
    // 0x9d9fc4: SaveReg r16
    //     0x9d9fc4: str             x16, [SP, #-8]!
    // 0x9d9fc8: r0 = initState()
    //     0x9d9fc8: bl              #0x9da194  ; [package:flutter/src/material/ink_well.dart] __InkResponseState&State&AutomaticKeepAliveClientMixin::initState
    // 0x9d9fcc: add             SP, SP, #8
    // 0x9d9fd0: ldr             x16, [fp, #0x10]
    // 0x9d9fd4: SaveReg r16
    //     0x9d9fd4: str             x16, [SP, #-8]!
    // 0x9d9fd8: r0 = initStatesController()
    //     0x9d9fd8: bl              #0x7b2984  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::initStatesController
    // 0x9d9fdc: add             SP, SP, #8
    // 0x9d9fe0: r0 = LoadStaticField(0xbb8)
    //     0x9d9fe0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9d9fe4: ldr             x0, [x0, #0x1770]
    // 0x9d9fe8: cmp             w0, NULL
    // 0x9d9fec: b.eq            #0x9da058
    // 0x9d9ff0: LoadField: r1 = r0->field_cb
    //     0x9d9ff0: ldur            w1, [x0, #0xcb]
    // 0x9d9ff4: DecompressPointer r1
    //     0x9d9ff4: add             x1, x1, HEAP, lsl #32
    // 0x9d9ff8: cmp             w1, NULL
    // 0x9d9ffc: b.eq            #0x9da05c
    // 0x9da000: LoadField: r0 = r1->field_1b
    //     0x9da000: ldur            w0, [x1, #0x1b]
    // 0x9da004: DecompressPointer r0
    //     0x9da004: add             x0, x0, HEAP, lsl #32
    // 0x9da008: stur            x0, [fp, #-8]
    // 0x9da00c: r1 = 1
    //     0x9da00c: mov             x1, #1
    // 0x9da010: r0 = AllocateContext()
    //     0x9da010: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9da014: mov             x1, x0
    // 0x9da018: ldr             x0, [fp, #0x10]
    // 0x9da01c: StoreField: r1->field_f = r0
    //     0x9da01c: stur            w0, [x1, #0xf]
    // 0x9da020: mov             x2, x1
    // 0x9da024: r1 = Function 'handleFocusHighlightModeChange':.
    //     0x9da024: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4b8] AnonymousClosure: (0x9da1e4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange (0x9da230)
    //     0x9da028: ldr             x1, [x1, #0x4b8]
    // 0x9da02c: r0 = AllocateClosure()
    //     0x9da02c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9da030: ldur            x16, [fp, #-8]
    // 0x9da034: stp             x0, x16, [SP, #-0x10]!
    // 0x9da038: r0 = addHighlightModeListener()
    //     0x9da038: bl              #0x9da060  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::addHighlightModeListener
    // 0x9da03c: add             SP, SP, #0x10
    // 0x9da040: r0 = Null
    //     0x9da040: mov             x0, NULL
    // 0x9da044: LeaveFrame
    //     0x9da044: mov             SP, fp
    //     0x9da048: ldp             fp, lr, [SP], #0x10
    // 0x9da04c: ret
    //     0x9da04c: ret             
    // 0x9da050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9da050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9da054: b               #0x9d9fc0
    // 0x9da058: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9da058: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9da05c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9da05c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleFocusHighlightModeChange(dynamic, FocusHighlightMode) {
    // ** addr: 0x9da1e4, size: 0x4c
    // 0x9da1e4: EnterFrame
    //     0x9da1e4: stp             fp, lr, [SP, #-0x10]!
    //     0x9da1e8: mov             fp, SP
    // 0x9da1ec: ldr             x0, [fp, #0x18]
    // 0x9da1f0: LoadField: r1 = r0->field_17
    //     0x9da1f0: ldur            w1, [x0, #0x17]
    // 0x9da1f4: DecompressPointer r1
    //     0x9da1f4: add             x1, x1, HEAP, lsl #32
    // 0x9da1f8: CheckStackOverflow
    //     0x9da1f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9da1fc: cmp             SP, x16
    //     0x9da200: b.ls            #0x9da228
    // 0x9da204: LoadField: r0 = r1->field_f
    //     0x9da204: ldur            w0, [x1, #0xf]
    // 0x9da208: DecompressPointer r0
    //     0x9da208: add             x0, x0, HEAP, lsl #32
    // 0x9da20c: ldr             x16, [fp, #0x10]
    // 0x9da210: stp             x16, x0, [SP, #-0x10]!
    // 0x9da214: r0 = handleFocusHighlightModeChange()
    //     0x9da214: bl              #0x9da230  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange
    // 0x9da218: add             SP, SP, #0x10
    // 0x9da21c: LeaveFrame
    //     0x9da21c: mov             SP, fp
    //     0x9da220: ldp             fp, lr, [SP], #0x10
    // 0x9da224: ret
    //     0x9da224: ret             
    // 0x9da228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9da228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9da22c: b               #0x9da204
  }
  _ handleFocusHighlightModeChange(/* No info */) {
    // ** addr: 0x9da230, size: 0x80
    // 0x9da230: EnterFrame
    //     0x9da230: stp             fp, lr, [SP, #-0x10]!
    //     0x9da234: mov             fp, SP
    // 0x9da238: CheckStackOverflow
    //     0x9da238: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9da23c: cmp             SP, x16
    //     0x9da240: b.ls            #0x9da2a8
    // 0x9da244: r1 = 1
    //     0x9da244: mov             x1, #1
    // 0x9da248: r0 = AllocateContext()
    //     0x9da248: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9da24c: mov             x1, x0
    // 0x9da250: ldr             x0, [fp, #0x18]
    // 0x9da254: StoreField: r1->field_f = r0
    //     0x9da254: stur            w0, [x1, #0xf]
    // 0x9da258: LoadField: r2 = r0->field_f
    //     0x9da258: ldur            w2, [x0, #0xf]
    // 0x9da25c: DecompressPointer r2
    //     0x9da25c: add             x2, x2, HEAP, lsl #32
    // 0x9da260: cmp             w2, NULL
    // 0x9da264: b.ne            #0x9da278
    // 0x9da268: r0 = Null
    //     0x9da268: mov             x0, NULL
    // 0x9da26c: LeaveFrame
    //     0x9da26c: mov             SP, fp
    //     0x9da270: ldp             fp, lr, [SP], #0x10
    // 0x9da274: ret
    //     0x9da274: ret             
    // 0x9da278: mov             x2, x1
    // 0x9da27c: r1 = Function '<anonymous closure>':.
    //     0x9da27c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4d0] AnonymousClosure: (0x9da2b0), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange (0x9da230)
    //     0x9da280: ldr             x1, [x1, #0x4d0]
    // 0x9da284: r0 = AllocateClosure()
    //     0x9da284: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9da288: ldr             x16, [fp, #0x18]
    // 0x9da28c: stp             x0, x16, [SP, #-0x10]!
    // 0x9da290: r0 = setState()
    //     0x9da290: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9da294: add             SP, SP, #0x10
    // 0x9da298: r0 = Null
    //     0x9da298: mov             x0, NULL
    // 0x9da29c: LeaveFrame
    //     0x9da29c: mov             SP, fp
    //     0x9da2a0: ldp             fp, lr, [SP], #0x10
    // 0x9da2a4: ret
    //     0x9da2a4: ret             
    // 0x9da2a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9da2a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9da2ac: b               #0x9da244
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9da2b0, size: 0x4c
    // 0x9da2b0: EnterFrame
    //     0x9da2b0: stp             fp, lr, [SP, #-0x10]!
    //     0x9da2b4: mov             fp, SP
    // 0x9da2b8: ldr             x0, [fp, #0x10]
    // 0x9da2bc: LoadField: r1 = r0->field_17
    //     0x9da2bc: ldur            w1, [x0, #0x17]
    // 0x9da2c0: DecompressPointer r1
    //     0x9da2c0: add             x1, x1, HEAP, lsl #32
    // 0x9da2c4: CheckStackOverflow
    //     0x9da2c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9da2c8: cmp             SP, x16
    //     0x9da2cc: b.ls            #0x9da2f4
    // 0x9da2d0: LoadField: r0 = r1->field_f
    //     0x9da2d0: ldur            w0, [x1, #0xf]
    // 0x9da2d4: DecompressPointer r0
    //     0x9da2d4: add             x0, x0, HEAP, lsl #32
    // 0x9da2d8: SaveReg r0
    //     0x9da2d8: str             x0, [SP, #-8]!
    // 0x9da2dc: r0 = updateFocusHighlights()
    //     0x9da2dc: bl              #0x7b1718  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::updateFocusHighlights
    // 0x9da2e0: add             SP, SP, #8
    // 0x9da2e4: r0 = Null
    //     0x9da2e4: mov             x0, NULL
    // 0x9da2e8: LeaveFrame
    //     0x9da2e8: mov             SP, fp
    //     0x9da2ec: ldp             fp, lr, [SP], #0x10
    // 0x9da2f0: ret
    //     0x9da2f0: ret             
    // 0x9da2f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9da2f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9da2f8: b               #0x9da2d0
  }
  _ _InkResponseState(/* No info */) {
    // ** addr: 0xa40714, size: 0x100
    // 0xa40714: EnterFrame
    //     0xa40714: stp             fp, lr, [SP, #-0x10]!
    //     0xa40718: mov             fp, SP
    // 0xa4071c: AllocStack(0x8)
    //     0xa4071c: sub             SP, SP, #8
    // 0xa40720: r1 = false
    //     0xa40720: add             x1, NULL, #0x30  ; false
    // 0xa40724: r0 = Sentinel
    //     0xa40724: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40728: CheckStackOverflow
    //     0xa40728: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4072c: cmp             SP, x16
    //     0xa40730: b.ls            #0xa4080c
    // 0xa40734: ldr             x2, [fp, #0x10]
    // 0xa40738: StoreField: r2->field_1f = r1
    //     0xa40738: stur            w1, [x2, #0x1f]
    // 0xa4073c: StoreField: r2->field_27 = r0
    //     0xa4073c: stur            w0, [x2, #0x27]
    // 0xa40740: StoreField: r2->field_33 = r1
    //     0xa40740: stur            w1, [x2, #0x33]
    // 0xa40744: r16 = <_HighlightType, InkHighlight?>
    //     0xa40744: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c00] TypeArguments: <_HighlightType, InkHighlight?>
    //     0xa40748: ldr             x16, [x16, #0xc00]
    // 0xa4074c: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa40750: stp             lr, x16, [SP, #-0x10]!
    // 0xa40754: r0 = Map._fromLiteral()
    //     0xa40754: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa40758: add             SP, SP, #0x10
    // 0xa4075c: ldr             x2, [fp, #0x10]
    // 0xa40760: StoreField: r2->field_23 = r0
    //     0xa40760: stur            w0, [x2, #0x23]
    //     0xa40764: tbz             w0, #0, #0xa40780
    //     0xa40768: ldurb           w16, [x2, #-1]
    //     0xa4076c: ldurb           w17, [x0, #-1]
    //     0xa40770: and             x16, x17, x16, lsr #2
    //     0xa40774: tst             x16, HEAP, lsr #32
    //     0xa40778: b.eq            #0xa40780
    //     0xa4077c: bl              #0xd6828c
    // 0xa40780: r1 = <_ParentInkResponseState>
    //     0xa40780: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c08] TypeArguments: <_ParentInkResponseState>
    //     0xa40784: ldr             x1, [x1, #0xc08]
    // 0xa40788: r0 = ObserverList()
    //     0xa40788: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xa4078c: mov             x1, x0
    // 0xa40790: r0 = false
    //     0xa40790: add             x0, NULL, #0x30  ; false
    // 0xa40794: stur            x1, [fp, #-8]
    // 0xa40798: StoreField: r1->field_f = r0
    //     0xa40798: stur            w0, [x1, #0xf]
    // 0xa4079c: r0 = Sentinel
    //     0xa4079c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa407a0: StoreField: r1->field_13 = r0
    //     0xa407a0: stur            w0, [x1, #0x13]
    // 0xa407a4: r16 = <_ParentInkResponseState>
    //     0xa407a4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28c08] TypeArguments: <_ParentInkResponseState>
    //     0xa407a8: ldr             x16, [x16, #0xc08]
    // 0xa407ac: stp             xzr, x16, [SP, #-0x10]!
    // 0xa407b0: r0 = _GrowableList()
    //     0xa407b0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xa407b4: add             SP, SP, #0x10
    // 0xa407b8: ldur            x1, [fp, #-8]
    // 0xa407bc: StoreField: r1->field_b = r0
    //     0xa407bc: stur            w0, [x1, #0xb]
    //     0xa407c0: ldurb           w16, [x1, #-1]
    //     0xa407c4: ldurb           w17, [x0, #-1]
    //     0xa407c8: and             x16, x17, x16, lsr #2
    //     0xa407cc: tst             x16, HEAP, lsr #32
    //     0xa407d0: b.eq            #0xa407d8
    //     0xa407d4: bl              #0xd6826c
    // 0xa407d8: mov             x0, x1
    // 0xa407dc: ldr             x1, [fp, #0x10]
    // 0xa407e0: StoreField: r1->field_2f = r0
    //     0xa407e0: stur            w0, [x1, #0x2f]
    //     0xa407e4: ldurb           w16, [x1, #-1]
    //     0xa407e8: ldurb           w17, [x0, #-1]
    //     0xa407ec: and             x16, x17, x16, lsr #2
    //     0xa407f0: tst             x16, HEAP, lsr #32
    //     0xa407f4: b.eq            #0xa407fc
    //     0xa407f8: bl              #0xd6826c
    // 0xa407fc: r0 = Null
    //     0xa407fc: mov             x0, NULL
    // 0xa40800: LeaveFrame
    //     0xa40800: mov             SP, fp
    //     0xa40804: ldp             fp, lr, [SP], #0x10
    // 0xa40808: ret
    //     0xa40808: ret             
    // 0xa4080c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4080c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40810: b               #0xa40734
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4abe8, size: 0x18
    // 0xa4abe8: r4 = 7
    //     0xa4abe8: mov             x4, #7
    // 0xa4abec: r1 = Function 'dispose':.
    //     0xa4abec: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b880] AnonymousClosure: (0xa4ac00), in [package:flutter/src/material/ink_well.dart] _InkResponseState::dispose (0xa51700)
    //     0xa4abf0: ldr             x1, [x17, #0x880]
    // 0xa4abf4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4abf4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4abf8: LoadField: r0 = r24->field_17
    //     0xa4abf8: ldur            x0, [x24, #0x17]
    // 0xa4abfc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4ac00, size: 0x48
    // 0xa4ac00: EnterFrame
    //     0xa4ac00: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ac04: mov             fp, SP
    // 0xa4ac08: ldr             x0, [fp, #0x10]
    // 0xa4ac0c: LoadField: r1 = r0->field_17
    //     0xa4ac0c: ldur            w1, [x0, #0x17]
    // 0xa4ac10: DecompressPointer r1
    //     0xa4ac10: add             x1, x1, HEAP, lsl #32
    // 0xa4ac14: CheckStackOverflow
    //     0xa4ac14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ac18: cmp             SP, x16
    //     0xa4ac1c: b.ls            #0xa4ac40
    // 0xa4ac20: LoadField: r0 = r1->field_f
    //     0xa4ac20: ldur            w0, [x1, #0xf]
    // 0xa4ac24: DecompressPointer r0
    //     0xa4ac24: add             x0, x0, HEAP, lsl #32
    // 0xa4ac28: SaveReg r0
    //     0xa4ac28: str             x0, [SP, #-8]!
    // 0xa4ac2c: r0 = dispose()
    //     0xa4ac2c: bl              #0xa51700  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::dispose
    // 0xa4ac30: add             SP, SP, #8
    // 0xa4ac34: LeaveFrame
    //     0xa4ac34: mov             SP, fp
    //     0xa4ac38: ldp             fp, lr, [SP], #0x10
    // 0xa4ac3c: ret
    //     0xa4ac3c: ret             
    // 0xa4ac40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ac40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ac44: b               #0xa4ac20
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa51700, size: 0x134
    // 0xa51700: EnterFrame
    //     0xa51700: stp             fp, lr, [SP, #-0x10]!
    //     0xa51704: mov             fp, SP
    // 0xa51708: AllocStack(0x8)
    //     0xa51708: sub             SP, SP, #8
    // 0xa5170c: CheckStackOverflow
    //     0xa5170c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51710: cmp             SP, x16
    //     0xa51714: b.ls            #0xa5181c
    // 0xa51718: r0 = LoadStaticField(0xbb8)
    //     0xa51718: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa5171c: ldr             x0, [x0, #0x1770]
    // 0xa51720: cmp             w0, NULL
    // 0xa51724: b.eq            #0xa51824
    // 0xa51728: LoadField: r1 = r0->field_cb
    //     0xa51728: ldur            w1, [x0, #0xcb]
    // 0xa5172c: DecompressPointer r1
    //     0xa5172c: add             x1, x1, HEAP, lsl #32
    // 0xa51730: cmp             w1, NULL
    // 0xa51734: b.eq            #0xa51828
    // 0xa51738: LoadField: r0 = r1->field_1b
    //     0xa51738: ldur            w0, [x1, #0x1b]
    // 0xa5173c: DecompressPointer r0
    //     0xa5173c: add             x0, x0, HEAP, lsl #32
    // 0xa51740: stur            x0, [fp, #-8]
    // 0xa51744: r1 = 1
    //     0xa51744: mov             x1, #1
    // 0xa51748: r0 = AllocateContext()
    //     0xa51748: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5174c: mov             x1, x0
    // 0xa51750: ldr             x0, [fp, #0x10]
    // 0xa51754: StoreField: r1->field_f = r0
    //     0xa51754: stur            w0, [x1, #0xf]
    // 0xa51758: mov             x2, x1
    // 0xa5175c: r1 = Function 'handleFocusHighlightModeChange':.
    //     0xa5175c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4b8] AnonymousClosure: (0x9da1e4), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleFocusHighlightModeChange (0x9da230)
    //     0xa51760: ldr             x1, [x1, #0x4b8]
    // 0xa51764: r0 = AllocateClosure()
    //     0xa51764: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa51768: ldur            x16, [fp, #-8]
    // 0xa5176c: stp             x0, x16, [SP, #-0x10]!
    // 0xa51770: r0 = removeHighlightModeListener()
    //     0xa51770: bl              #0xa51834  ; [package:flutter/src/widgets/focus_manager.dart] FocusManager::removeHighlightModeListener
    // 0xa51774: add             SP, SP, #0x10
    // 0xa51778: ldr             x0, [fp, #0x10]
    // 0xa5177c: LoadField: r1 = r0->field_b
    //     0xa5177c: ldur            w1, [x0, #0xb]
    // 0xa51780: DecompressPointer r1
    //     0xa51780: add             x1, x1, HEAP, lsl #32
    // 0xa51784: cmp             w1, NULL
    // 0xa51788: b.eq            #0xa5182c
    // 0xa5178c: LoadField: r2 = r1->field_7f
    //     0xa5178c: ldur            w2, [x1, #0x7f]
    // 0xa51790: DecompressPointer r2
    //     0xa51790: add             x2, x2, HEAP, lsl #32
    // 0xa51794: cmp             w2, NULL
    // 0xa51798: b.ne            #0xa517b0
    // 0xa5179c: LoadField: r1 = r0->field_2b
    //     0xa5179c: ldur            w1, [x0, #0x2b]
    // 0xa517a0: DecompressPointer r1
    //     0xa517a0: add             x1, x1, HEAP, lsl #32
    // 0xa517a4: cmp             w1, NULL
    // 0xa517a8: b.eq            #0xa51830
    // 0xa517ac: b               #0xa517b4
    // 0xa517b0: mov             x1, x2
    // 0xa517b4: stur            x1, [fp, #-8]
    // 0xa517b8: r1 = 1
    //     0xa517b8: mov             x1, #1
    // 0xa517bc: r0 = AllocateContext()
    //     0xa517bc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa517c0: mov             x1, x0
    // 0xa517c4: ldr             x0, [fp, #0x10]
    // 0xa517c8: StoreField: r1->field_f = r0
    //     0xa517c8: stur            w0, [x1, #0xf]
    // 0xa517cc: mov             x2, x1
    // 0xa517d0: r1 = Function 'handleStatesControllerChange':.
    //     0xa517d0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e4c0] AnonymousClosure: (0x7b2b14), in [package:flutter/src/material/ink_well.dart] _InkResponseState::handleStatesControllerChange (0x7b2b5c)
    //     0xa517d4: ldr             x1, [x1, #0x4c0]
    // 0xa517d8: r0 = AllocateClosure()
    //     0xa517d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa517dc: ldur            x16, [fp, #-8]
    // 0xa517e0: stp             x0, x16, [SP, #-0x10]!
    // 0xa517e4: r0 = removeListener()
    //     0xa517e4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa517e8: add             SP, SP, #0x10
    // 0xa517ec: ldr             x0, [fp, #0x10]
    // 0xa517f0: LoadField: r1 = r0->field_2b
    //     0xa517f0: ldur            w1, [x0, #0x2b]
    // 0xa517f4: DecompressPointer r1
    //     0xa517f4: add             x1, x1, HEAP, lsl #32
    // 0xa517f8: cmp             w1, NULL
    // 0xa517fc: b.eq            #0xa5180c
    // 0xa51800: SaveReg r1
    //     0xa51800: str             x1, [SP, #-8]!
    // 0xa51804: r0 = dispose()
    //     0xa51804: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0xa51808: add             SP, SP, #8
    // 0xa5180c: r0 = Null
    //     0xa5180c: mov             x0, NULL
    // 0xa51810: LeaveFrame
    //     0xa51810: mov             SP, fp
    //     0xa51814: ldp             fp, lr, [SP], #0x10
    // 0xa51818: ret
    //     0xa51818: ret             
    // 0xa5181c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5181c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51820: b               #0xa51718
    // 0xa51824: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa51824: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa51828: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa51828: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5182c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5182c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa51830: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa51830: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic simulateTap(dynamic) {
    // ** addr: 0xce3e9c, size: 0x18
    // 0xce3e9c: r4 = 7
    //     0xce3e9c: mov             x4, #7
    // 0xce3ea0: r1 = Function 'simulateTap':.
    //     0xce3ea0: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e218] AnonymousClosure: (0x8597fc), in [package:flutter/src/material/ink_well.dart] _InkResponseState::simulateTap (0x859878)
    //     0xce3ea4: ldr             x1, [x17, #0x218]
    // 0xce3ea8: r24 = BuildNonGenericMethodExtractorStub
    //     0xce3ea8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce3eac: LoadField: r0 = r24->field_17
    //     0xce3eac: ldur            x0, [x24, #0x17]
    // 0xce3eb0: br              x0
  }
}

// class id: 3527, size: 0x14, field offset: 0x10
//   const constructor, 
class _ParentInkResponseProvider extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87be0, size: 0x74
    // 0xa87be0: EnterFrame
    //     0xa87be0: stp             fp, lr, [SP, #-0x10]!
    //     0xa87be4: mov             fp, SP
    // 0xa87be8: ldr             x0, [fp, #0x10]
    // 0xa87bec: r2 = Null
    //     0xa87bec: mov             x2, NULL
    // 0xa87bf0: r1 = Null
    //     0xa87bf0: mov             x1, NULL
    // 0xa87bf4: r4 = 59
    //     0xa87bf4: mov             x4, #0x3b
    // 0xa87bf8: branchIfSmi(r0, 0xa87c04)
    //     0xa87bf8: tbz             w0, #0, #0xa87c04
    // 0xa87bfc: r4 = LoadClassIdInstr(r0)
    //     0xa87bfc: ldur            x4, [x0, #-1]
    //     0xa87c00: ubfx            x4, x4, #0xc, #0x14
    // 0xa87c04: cmp             x4, #0xdc7
    // 0xa87c08: b.eq            #0xa87c20
    // 0xa87c0c: r8 = _ParentInkResponseProvider
    //     0xa87c0c: add             x8, PP, #0x37, lsl #12  ; [pp+0x377f8] Type: _ParentInkResponseProvider
    //     0xa87c10: ldr             x8, [x8, #0x7f8]
    // 0xa87c14: r3 = Null
    //     0xa87c14: add             x3, PP, #0x37, lsl #12  ; [pp+0x37800] Null
    //     0xa87c18: ldr             x3, [x3, #0x800]
    // 0xa87c1c: r0 = DefaultTypeTest()
    //     0xa87c1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87c20: ldr             x1, [fp, #0x18]
    // 0xa87c24: LoadField: r2 = r1->field_f
    //     0xa87c24: ldur            w2, [x1, #0xf]
    // 0xa87c28: DecompressPointer r2
    //     0xa87c28: add             x2, x2, HEAP, lsl #32
    // 0xa87c2c: ldr             x1, [fp, #0x10]
    // 0xa87c30: LoadField: r3 = r1->field_f
    //     0xa87c30: ldur            w3, [x1, #0xf]
    // 0xa87c34: DecompressPointer r3
    //     0xa87c34: add             x3, x3, HEAP, lsl #32
    // 0xa87c38: cmp             w2, w3
    // 0xa87c3c: r16 = true
    //     0xa87c3c: add             x16, NULL, #0x20  ; true
    // 0xa87c40: r17 = false
    //     0xa87c40: add             x17, NULL, #0x30  ; false
    // 0xa87c44: csel            x0, x16, x17, ne
    // 0xa87c48: LeaveFrame
    //     0xa87c48: mov             SP, fp
    //     0xa87c4c: ldp             fp, lr, [SP], #0x10
    // 0xa87c50: ret
    //     0xa87c50: ret             
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0xb2243c, size: 0x60
    // 0xb2243c: EnterFrame
    //     0xb2243c: stp             fp, lr, [SP, #-0x10]!
    //     0xb22440: mov             fp, SP
    // 0xb22444: CheckStackOverflow
    //     0xb22444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb22448: cmp             SP, x16
    //     0xb2244c: b.ls            #0xb22494
    // 0xb22450: r16 = <_ParentInkResponseProvider>
    //     0xb22450: add             x16, PP, #0x22, lsl #12  ; [pp+0x220b8] TypeArguments: <_ParentInkResponseProvider>
    //     0xb22454: ldr             x16, [x16, #0xb8]
    // 0xb22458: ldr             lr, [fp, #0x10]
    // 0xb2245c: stp             lr, x16, [SP, #-0x10]!
    // 0xb22460: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb22460: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb22464: r0 = dependOnInheritedWidgetOfExactType()
    //     0xb22464: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xb22468: add             SP, SP, #0x10
    // 0xb2246c: cmp             w0, NULL
    // 0xb22470: b.ne            #0xb2247c
    // 0xb22474: r0 = Null
    //     0xb22474: mov             x0, NULL
    // 0xb22478: b               #0xb22488
    // 0xb2247c: LoadField: r1 = r0->field_f
    //     0xb2247c: ldur            w1, [x0, #0xf]
    // 0xb22480: DecompressPointer r1
    //     0xb22480: add             x1, x1, HEAP, lsl #32
    // 0xb22484: mov             x0, x1
    // 0xb22488: LeaveFrame
    //     0xb22488: mov             SP, fp
    //     0xb2248c: ldp             fp, lr, [SP], #0x10
    // 0xb22490: ret
    //     0xb22490: ret             
    // 0xb22494: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22494: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb22498: b               #0xb22450
  }
}

// class id: 3853, size: 0x7c, field offset: 0xc
//   const constructor, 
class InkResponse extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb221f0, size: 0x240
    // 0xb221f0: EnterFrame
    //     0xb221f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb221f4: mov             fp, SP
    // 0xb221f8: AllocStack(0xc0)
    //     0xb221f8: sub             SP, SP, #0xc0
    // 0xb221fc: CheckStackOverflow
    //     0xb221fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb22200: cmp             SP, x16
    //     0xb22204: b.ls            #0xb22428
    // 0xb22208: ldr             x16, [fp, #0x10]
    // 0xb2220c: SaveReg r16
    //     0xb2220c: str             x16, [SP, #-8]!
    // 0xb22210: r0 = maybeOf()
    //     0xb22210: bl              #0xb2243c  ; [package:flutter/src/material/ink_well.dart] _ParentInkResponseProvider::maybeOf
    // 0xb22214: add             SP, SP, #8
    // 0xb22218: mov             x1, x0
    // 0xb2221c: ldr             x0, [fp, #0x18]
    // 0xb22220: stur            x1, [fp, #-8]
    // 0xb22224: LoadField: r2 = r0->field_f
    //     0xb22224: ldur            w2, [x0, #0xf]
    // 0xb22228: DecompressPointer r2
    //     0xb22228: add             x2, x2, HEAP, lsl #32
    // 0xb2222c: stur            x2, [fp, #-0xa0]
    // 0xb22230: LoadField: r3 = r0->field_23
    //     0xb22230: ldur            w3, [x0, #0x23]
    // 0xb22234: DecompressPointer r3
    //     0xb22234: add             x3, x3, HEAP, lsl #32
    // 0xb22238: stur            x3, [fp, #-0x98]
    // 0xb2223c: LoadField: r4 = r0->field_27
    //     0xb2223c: ldur            w4, [x0, #0x27]
    // 0xb22240: DecompressPointer r4
    //     0xb22240: add             x4, x4, HEAP, lsl #32
    // 0xb22244: stur            x4, [fp, #-0x90]
    // 0xb22248: LoadField: r5 = r0->field_2b
    //     0xb22248: ldur            w5, [x0, #0x2b]
    // 0xb2224c: DecompressPointer r5
    //     0xb2224c: add             x5, x5, HEAP, lsl #32
    // 0xb22250: stur            x5, [fp, #-0x88]
    // 0xb22254: LoadField: r6 = r0->field_2f
    //     0xb22254: ldur            w6, [x0, #0x2f]
    // 0xb22258: DecompressPointer r6
    //     0xb22258: add             x6, x6, HEAP, lsl #32
    // 0xb2225c: stur            x6, [fp, #-0x80]
    // 0xb22260: LoadField: r7 = r0->field_33
    //     0xb22260: ldur            w7, [x0, #0x33]
    // 0xb22264: DecompressPointer r7
    //     0xb22264: add             x7, x7, HEAP, lsl #32
    // 0xb22268: stur            x7, [fp, #-0x78]
    // 0xb2226c: LoadField: r8 = r0->field_37
    //     0xb2226c: ldur            w8, [x0, #0x37]
    // 0xb22270: DecompressPointer r8
    //     0xb22270: add             x8, x8, HEAP, lsl #32
    // 0xb22274: stur            x8, [fp, #-0x70]
    // 0xb22278: LoadField: r9 = r0->field_3b
    //     0xb22278: ldur            w9, [x0, #0x3b]
    // 0xb2227c: DecompressPointer r9
    //     0xb2227c: add             x9, x9, HEAP, lsl #32
    // 0xb22280: stur            x9, [fp, #-0x68]
    // 0xb22284: LoadField: r10 = r0->field_3f
    //     0xb22284: ldur            w10, [x0, #0x3f]
    // 0xb22288: DecompressPointer r10
    //     0xb22288: add             x10, x10, HEAP, lsl #32
    // 0xb2228c: stur            x10, [fp, #-0x60]
    // 0xb22290: LoadField: r11 = r0->field_43
    //     0xb22290: ldur            w11, [x0, #0x43]
    // 0xb22294: DecompressPointer r11
    //     0xb22294: add             x11, x11, HEAP, lsl #32
    // 0xb22298: stur            x11, [fp, #-0x58]
    // 0xb2229c: LoadField: r12 = r0->field_47
    //     0xb2229c: ldur            w12, [x0, #0x47]
    // 0xb222a0: DecompressPointer r12
    //     0xb222a0: add             x12, x12, HEAP, lsl #32
    // 0xb222a4: stur            x12, [fp, #-0x50]
    // 0xb222a8: LoadField: r13 = r0->field_4b
    //     0xb222a8: ldur            w13, [x0, #0x4b]
    // 0xb222ac: DecompressPointer r13
    //     0xb222ac: add             x13, x13, HEAP, lsl #32
    // 0xb222b0: stur            x13, [fp, #-0x48]
    // 0xb222b4: LoadField: r14 = r0->field_4f
    //     0xb222b4: ldur            w14, [x0, #0x4f]
    // 0xb222b8: DecompressPointer r14
    //     0xb222b8: add             x14, x14, HEAP, lsl #32
    // 0xb222bc: stur            x14, [fp, #-0x40]
    // 0xb222c0: LoadField: r19 = r0->field_53
    //     0xb222c0: ldur            w19, [x0, #0x53]
    // 0xb222c4: DecompressPointer r19
    //     0xb222c4: add             x19, x19, HEAP, lsl #32
    // 0xb222c8: stur            x19, [fp, #-0x38]
    // 0xb222cc: LoadField: r20 = r0->field_57
    //     0xb222cc: ldur            w20, [x0, #0x57]
    // 0xb222d0: DecompressPointer r20
    //     0xb222d0: add             x20, x20, HEAP, lsl #32
    // 0xb222d4: stur            x20, [fp, #-0x30]
    // 0xb222d8: LoadField: r23 = r0->field_5b
    //     0xb222d8: ldur            w23, [x0, #0x5b]
    // 0xb222dc: DecompressPointer r23
    //     0xb222dc: add             x23, x23, HEAP, lsl #32
    // 0xb222e0: stur            x23, [fp, #-0x28]
    // 0xb222e4: LoadField: r24 = r0->field_5f
    //     0xb222e4: ldur            w24, [x0, #0x5f]
    // 0xb222e8: DecompressPointer r24
    //     0xb222e8: add             x24, x24, HEAP, lsl #32
    // 0xb222ec: stur            x24, [fp, #-0x20]
    // 0xb222f0: LoadField: r25 = r0->field_73
    //     0xb222f0: ldur            w25, [x0, #0x73]
    // 0xb222f4: DecompressPointer r25
    //     0xb222f4: add             x25, x25, HEAP, lsl #32
    // 0xb222f8: stur            x25, [fp, #-0x18]
    // 0xb222fc: LoadField: r1 = r0->field_67
    //     0xb222fc: ldur            w1, [x0, #0x67]
    // 0xb22300: DecompressPointer r1
    //     0xb22300: add             x1, x1, HEAP, lsl #32
    // 0xb22304: stur            x1, [fp, #-0x10]
    // 0xb22308: r1 = 1
    //     0xb22308: mov             x1, #1
    // 0xb2230c: r0 = AllocateContext()
    //     0xb2230c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb22310: mov             x1, x0
    // 0xb22314: ldr             x0, [fp, #0x18]
    // 0xb22318: stur            x1, [fp, #-0xb8]
    // 0xb2231c: StoreField: r1->field_f = r0
    //     0xb2231c: stur            w0, [x1, #0xf]
    // 0xb22320: LoadField: r2 = r0->field_77
    //     0xb22320: ldur            w2, [x0, #0x77]
    // 0xb22324: DecompressPointer r2
    //     0xb22324: add             x2, x2, HEAP, lsl #32
    // 0xb22328: stur            x2, [fp, #-0xb0]
    // 0xb2232c: LoadField: r3 = r0->field_b
    //     0xb2232c: ldur            w3, [x0, #0xb]
    // 0xb22330: DecompressPointer r3
    //     0xb22330: add             x3, x3, HEAP, lsl #32
    // 0xb22334: stur            x3, [fp, #-0xa8]
    // 0xb22338: r0 = _InkResponseStateWidget()
    //     0xb22338: bl              #0xb22430  ; Allocate_InkResponseStateWidgetStub -> _InkResponseStateWidget (size=0x84)
    // 0xb2233c: mov             x3, x0
    // 0xb22340: ldur            x0, [fp, #-0xa8]
    // 0xb22344: stur            x3, [fp, #-0xc0]
    // 0xb22348: StoreField: r3->field_b = r0
    //     0xb22348: stur            w0, [x3, #0xb]
    // 0xb2234c: ldur            x0, [fp, #-0xa0]
    // 0xb22350: StoreField: r3->field_f = r0
    //     0xb22350: stur            w0, [x3, #0xf]
    // 0xb22354: ldur            x0, [fp, #-0x98]
    // 0xb22358: StoreField: r3->field_23 = r0
    //     0xb22358: stur            w0, [x3, #0x23]
    // 0xb2235c: ldur            x0, [fp, #-0x90]
    // 0xb22360: StoreField: r3->field_27 = r0
    //     0xb22360: stur            w0, [x3, #0x27]
    // 0xb22364: ldur            x0, [fp, #-0x88]
    // 0xb22368: StoreField: r3->field_2b = r0
    //     0xb22368: stur            w0, [x3, #0x2b]
    // 0xb2236c: ldur            x0, [fp, #-0x80]
    // 0xb22370: StoreField: r3->field_2f = r0
    //     0xb22370: stur            w0, [x3, #0x2f]
    // 0xb22374: ldur            x0, [fp, #-0x78]
    // 0xb22378: StoreField: r3->field_33 = r0
    //     0xb22378: stur            w0, [x3, #0x33]
    // 0xb2237c: ldur            x0, [fp, #-0x70]
    // 0xb22380: StoreField: r3->field_37 = r0
    //     0xb22380: stur            w0, [x3, #0x37]
    // 0xb22384: ldur            x0, [fp, #-0x68]
    // 0xb22388: StoreField: r3->field_3b = r0
    //     0xb22388: stur            w0, [x3, #0x3b]
    // 0xb2238c: ldur            x0, [fp, #-0x60]
    // 0xb22390: StoreField: r3->field_3f = r0
    //     0xb22390: stur            w0, [x3, #0x3f]
    // 0xb22394: ldur            x0, [fp, #-0x58]
    // 0xb22398: StoreField: r3->field_43 = r0
    //     0xb22398: stur            w0, [x3, #0x43]
    // 0xb2239c: ldur            x0, [fp, #-0x50]
    // 0xb223a0: StoreField: r3->field_47 = r0
    //     0xb223a0: stur            w0, [x3, #0x47]
    // 0xb223a4: ldur            x0, [fp, #-0x48]
    // 0xb223a8: StoreField: r3->field_4b = r0
    //     0xb223a8: stur            w0, [x3, #0x4b]
    // 0xb223ac: ldur            x0, [fp, #-0x40]
    // 0xb223b0: StoreField: r3->field_4f = r0
    //     0xb223b0: stur            w0, [x3, #0x4f]
    // 0xb223b4: ldur            x0, [fp, #-0x38]
    // 0xb223b8: StoreField: r3->field_53 = r0
    //     0xb223b8: stur            w0, [x3, #0x53]
    // 0xb223bc: ldur            x0, [fp, #-0x30]
    // 0xb223c0: StoreField: r3->field_57 = r0
    //     0xb223c0: stur            w0, [x3, #0x57]
    // 0xb223c4: ldur            x0, [fp, #-0x28]
    // 0xb223c8: StoreField: r3->field_5b = r0
    //     0xb223c8: stur            w0, [x3, #0x5b]
    // 0xb223cc: ldur            x0, [fp, #-0x20]
    // 0xb223d0: StoreField: r3->field_5f = r0
    //     0xb223d0: stur            w0, [x3, #0x5f]
    // 0xb223d4: r0 = false
    //     0xb223d4: add             x0, NULL, #0x30  ; false
    // 0xb223d8: StoreField: r3->field_63 = r0
    //     0xb223d8: stur            w0, [x3, #0x63]
    // 0xb223dc: ldur            x1, [fp, #-0x18]
    // 0xb223e0: StoreField: r3->field_73 = r1
    //     0xb223e0: stur            w1, [x3, #0x73]
    // 0xb223e4: ldur            x1, [fp, #-0x10]
    // 0xb223e8: StoreField: r3->field_67 = r1
    //     0xb223e8: stur            w1, [x3, #0x67]
    // 0xb223ec: StoreField: r3->field_6b = r0
    //     0xb223ec: stur            w0, [x3, #0x6b]
    // 0xb223f0: ldur            x0, [fp, #-8]
    // 0xb223f4: StoreField: r3->field_77 = r0
    //     0xb223f4: stur            w0, [x3, #0x77]
    // 0xb223f8: ldur            x2, [fp, #-0xb8]
    // 0xb223fc: r1 = Function 'getRectCallback':.
    //     0xb223fc: add             x1, PP, #0x22, lsl #12  ; [pp+0x220b0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xb22400: ldr             x1, [x1, #0xb0]
    // 0xb22404: r0 = AllocateClosure()
    //     0xb22404: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb22408: mov             x1, x0
    // 0xb2240c: ldur            x0, [fp, #-0xc0]
    // 0xb22410: StoreField: r0->field_7b = r1
    //     0xb22410: stur            w1, [x0, #0x7b]
    // 0xb22414: ldur            x1, [fp, #-0xb0]
    // 0xb22418: StoreField: r0->field_7f = r1
    //     0xb22418: stur            w1, [x0, #0x7f]
    // 0xb2241c: LeaveFrame
    //     0xb2241c: mov             SP, fp
    //     0xb22420: ldp             fp, lr, [SP], #0x10
    // 0xb22424: ret
    //     0xb22424: ret             
    // 0xb22428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb22428: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb2242c: b               #0xb22208
  }
}

// class id: 3854, size: 0x7c, field offset: 0x7c
//   const constructor, 
class InkWell extends InkResponse {
}

// class id: 4152, size: 0x84, field offset: 0xc
//   const constructor, 
class _InkResponseStateWidget extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa406c8, size: 0x4c
    // 0xa406c8: EnterFrame
    //     0xa406c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa406cc: mov             fp, SP
    // 0xa406d0: AllocStack(0x8)
    //     0xa406d0: sub             SP, SP, #8
    // 0xa406d4: CheckStackOverflow
    //     0xa406d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa406d8: cmp             SP, x16
    //     0xa406dc: b.ls            #0xa4070c
    // 0xa406e0: r1 = <_InkResponseStateWidget>
    //     0xa406e0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28bf8] TypeArguments: <_InkResponseStateWidget>
    //     0xa406e4: ldr             x1, [x1, #0xbf8]
    // 0xa406e8: r0 = _InkResponseState()
    //     0xa406e8: bl              #0xa40814  ; Allocate_InkResponseStateStub -> _InkResponseState (size=0x38)
    // 0xa406ec: stur            x0, [fp, #-8]
    // 0xa406f0: SaveReg r0
    //     0xa406f0: str             x0, [SP, #-8]!
    // 0xa406f4: r0 = _InkResponseState()
    //     0xa406f4: bl              #0xa40714  ; [package:flutter/src/material/ink_well.dart] _InkResponseState::_InkResponseState
    // 0xa406f8: add             SP, SP, #8
    // 0xa406fc: ldur            x0, [fp, #-8]
    // 0xa40700: LeaveFrame
    //     0xa40700: mov             SP, fp
    //     0xa40704: ldp             fp, lr, [SP], #0x10
    // 0xa40708: ret
    //     0xa40708: ret             
    // 0xa4070c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4070c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40710: b               #0xa406e0
  }
}

// class id: 5964, size: 0x14, field offset: 0x14
enum _HighlightType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16194, size: 0x5c
    // 0xb16194: EnterFrame
    //     0xb16194: stp             fp, lr, [SP, #-0x10]!
    //     0xb16198: mov             fp, SP
    // 0xb1619c: CheckStackOverflow
    //     0xb1619c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb161a0: cmp             SP, x16
    //     0xb161a4: b.ls            #0xb161e8
    // 0xb161a8: r1 = Null
    //     0xb161a8: mov             x1, NULL
    // 0xb161ac: r2 = 4
    //     0xb161ac: mov             x2, #4
    // 0xb161b0: r0 = AllocateArray()
    //     0xb161b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb161b4: r17 = "_HighlightType."
    //     0xb161b4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37810] "_HighlightType."
    //     0xb161b8: ldr             x17, [x17, #0x810]
    // 0xb161bc: StoreField: r0->field_f = r17
    //     0xb161bc: stur            w17, [x0, #0xf]
    // 0xb161c0: ldr             x1, [fp, #0x10]
    // 0xb161c4: LoadField: r2 = r1->field_f
    //     0xb161c4: ldur            w2, [x1, #0xf]
    // 0xb161c8: DecompressPointer r2
    //     0xb161c8: add             x2, x2, HEAP, lsl #32
    // 0xb161cc: StoreField: r0->field_13 = r2
    //     0xb161cc: stur            w2, [x0, #0x13]
    // 0xb161d0: SaveReg r0
    //     0xb161d0: str             x0, [SP, #-8]!
    // 0xb161d4: r0 = _interpolate()
    //     0xb161d4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb161d8: add             SP, SP, #8
    // 0xb161dc: LeaveFrame
    //     0xb161dc: mov             SP, fp
    //     0xb161e0: ldp             fp, lr, [SP], #0x10
    // 0xb161e4: ret
    //     0xb161e4: ret             
    // 0xb161e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb161e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb161ec: b               #0xb161a8
  }
}

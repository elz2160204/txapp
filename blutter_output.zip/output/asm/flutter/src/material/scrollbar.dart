// lib: , url: package:flutter/src/material/scrollbar.dart

// class id: 1049301, size: 0x8
class :: {
}

// class id: 3351, size: 0x60, field offset: 0x48
class _MaterialScrollbarState extends RawScrollbarState<_MaterialScrollbar> {

  late ScrollbarThemeData _scrollbarTheme; // offset: 0x58
  late bool _useAndroidScrollbar; // offset: 0x5c
  late AnimationController _hoverAnimationController; // offset: 0x48
  late ColorScheme _colorScheme; // offset: 0x54

  _ initState(/* No info */) {
    // ** addr: 0x9d8b9c, size: 0xc8
    // 0x9d8b9c: EnterFrame
    //     0x9d8b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8ba0: mov             fp, SP
    // 0x9d8ba4: AllocStack(0x10)
    //     0x9d8ba4: sub             SP, SP, #0x10
    // 0x9d8ba8: CheckStackOverflow
    //     0x9d8ba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8bac: cmp             SP, x16
    //     0x9d8bb0: b.ls            #0x9d8c5c
    // 0x9d8bb4: r1 = 1
    //     0x9d8bb4: mov             x1, #1
    // 0x9d8bb8: r0 = AllocateContext()
    //     0x9d8bb8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d8bbc: mov             x1, x0
    // 0x9d8bc0: ldr             x0, [fp, #0x10]
    // 0x9d8bc4: stur            x1, [fp, #-8]
    // 0x9d8bc8: StoreField: r1->field_f = r0
    //     0x9d8bc8: stur            w0, [x1, #0xf]
    // 0x9d8bcc: SaveReg r0
    //     0x9d8bcc: str             x0, [SP, #-8]!
    // 0x9d8bd0: r0 = initState()
    //     0x9d8bd0: bl              #0x9d8cb0  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::initState
    // 0x9d8bd4: add             SP, SP, #8
    // 0x9d8bd8: r1 = <double>
    //     0x9d8bd8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d8bdc: r0 = AnimationController()
    //     0x9d8bdc: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d8be0: stur            x0, [fp, #-0x10]
    // 0x9d8be4: ldr             x16, [fp, #0x10]
    // 0x9d8be8: stp             x16, x0, [SP, #-0x10]!
    // 0x9d8bec: r16 = Instance_Duration
    //     0x9d8bec: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d8bf0: ldr             x16, [x16, #0x9e0]
    // 0x9d8bf4: SaveReg r16
    //     0x9d8bf4: str             x16, [SP, #-8]!
    // 0x9d8bf8: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d8bf8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d8bfc: ldr             x4, [x4, #0xa0]
    // 0x9d8c00: r0 = AnimationController()
    //     0x9d8c00: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d8c04: add             SP, SP, #0x18
    // 0x9d8c08: ldur            x0, [fp, #-0x10]
    // 0x9d8c0c: ldr             x1, [fp, #0x10]
    // 0x9d8c10: StoreField: r1->field_47 = r0
    //     0x9d8c10: stur            w0, [x1, #0x47]
    //     0x9d8c14: ldurb           w16, [x1, #-1]
    //     0x9d8c18: ldurb           w17, [x0, #-1]
    //     0x9d8c1c: and             x16, x17, x16, lsr #2
    //     0x9d8c20: tst             x16, HEAP, lsr #32
    //     0x9d8c24: b.eq            #0x9d8c2c
    //     0x9d8c28: bl              #0xd6826c
    // 0x9d8c2c: ldur            x2, [fp, #-8]
    // 0x9d8c30: r1 = Function '<anonymous closure>':.
    //     0x9d8c30: add             x1, PP, #0x50, lsl #12  ; [pp+0x50848] AnonymousClosure: (0x9d8c64), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::initState (0x9d8b9c)
    //     0x9d8c34: ldr             x1, [x1, #0x848]
    // 0x9d8c38: r0 = AllocateClosure()
    //     0x9d8c38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d8c3c: ldur            x16, [fp, #-0x10]
    // 0x9d8c40: stp             x0, x16, [SP, #-0x10]!
    // 0x9d8c44: r0 = addActionListener()
    //     0x9d8c44: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9d8c48: add             SP, SP, #0x10
    // 0x9d8c4c: r0 = Null
    //     0x9d8c4c: mov             x0, NULL
    // 0x9d8c50: LeaveFrame
    //     0x9d8c50: mov             SP, fp
    //     0x9d8c54: ldp             fp, lr, [SP], #0x10
    // 0x9d8c58: ret
    //     0x9d8c58: ret             
    // 0x9d8c5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8c5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8c60: b               #0x9d8bb4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9d8c64, size: 0x4c
    // 0x9d8c64: EnterFrame
    //     0x9d8c64: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8c68: mov             fp, SP
    // 0x9d8c6c: ldr             x0, [fp, #0x10]
    // 0x9d8c70: LoadField: r1 = r0->field_17
    //     0x9d8c70: ldur            w1, [x0, #0x17]
    // 0x9d8c74: DecompressPointer r1
    //     0x9d8c74: add             x1, x1, HEAP, lsl #32
    // 0x9d8c78: CheckStackOverflow
    //     0x9d8c78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8c7c: cmp             SP, x16
    //     0x9d8c80: b.ls            #0x9d8ca8
    // 0x9d8c84: LoadField: r0 = r1->field_f
    //     0x9d8c84: ldur            w0, [x1, #0xf]
    // 0x9d8c88: DecompressPointer r0
    //     0x9d8c88: add             x0, x0, HEAP, lsl #32
    // 0x9d8c8c: SaveReg r0
    //     0x9d8c8c: str             x0, [SP, #-8]!
    // 0x9d8c90: r0 = updateScrollbarPainter()
    //     0x9d8c90: bl              #0xcd2f7c  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::updateScrollbarPainter
    // 0x9d8c94: add             SP, SP, #8
    // 0x9d8c98: r0 = Null
    //     0x9d8c98: mov             x0, NULL
    // 0x9d8c9c: LeaveFrame
    //     0x9d8c9c: mov             SP, fp
    //     0x9d8ca0: ldp             fp, lr, [SP], #0x10
    // 0x9d8ca4: ret
    //     0x9d8ca4: ret             
    // 0x9d8ca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8ca8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8cac: b               #0x9d8c84
  }
  _ _MaterialScrollbarState(/* No info */) {
    // ** addr: 0xa3ff64, size: 0x78
    // 0xa3ff64: EnterFrame
    //     0xa3ff64: stp             fp, lr, [SP, #-0x10]!
    //     0xa3ff68: mov             fp, SP
    // 0xa3ff6c: r1 = Sentinel
    //     0xa3ff6c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3ff70: r0 = false
    //     0xa3ff70: add             x0, NULL, #0x30  ; false
    // 0xa3ff74: ldr             x2, [fp, #0x10]
    // 0xa3ff78: StoreField: r2->field_47 = r1
    //     0xa3ff78: stur            w1, [x2, #0x47]
    // 0xa3ff7c: StoreField: r2->field_4b = r0
    //     0xa3ff7c: stur            w0, [x2, #0x4b]
    // 0xa3ff80: StoreField: r2->field_4f = r0
    //     0xa3ff80: stur            w0, [x2, #0x4f]
    // 0xa3ff84: StoreField: r2->field_53 = r1
    //     0xa3ff84: stur            w1, [x2, #0x53]
    // 0xa3ff88: StoreField: r2->field_57 = r1
    //     0xa3ff88: stur            w1, [x2, #0x57]
    // 0xa3ff8c: StoreField: r2->field_5b = r1
    //     0xa3ff8c: stur            w1, [x2, #0x5b]
    // 0xa3ff90: StoreField: r2->field_2f = r1
    //     0xa3ff90: stur            w1, [x2, #0x2f]
    // 0xa3ff94: StoreField: r2->field_33 = r1
    //     0xa3ff94: stur            w1, [x2, #0x33]
    // 0xa3ff98: StoreField: r2->field_3b = r0
    //     0xa3ff98: stur            w0, [x2, #0x3b]
    // 0xa3ff9c: StoreField: r2->field_3f = r0
    //     0xa3ff9c: stur            w0, [x2, #0x3f]
    // 0xa3ffa0: StoreField: r2->field_43 = r1
    //     0xa3ffa0: stur            w1, [x2, #0x43]
    // 0xa3ffa4: r1 = <State<StatefulWidget>>
    //     0xa3ffa4: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa3ffa8: r0 = LabeledGlobalKey()
    //     0xa3ffa8: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa3ffac: ldr             x1, [fp, #0x10]
    // 0xa3ffb0: StoreField: r1->field_37 = r0
    //     0xa3ffb0: stur            w0, [x1, #0x37]
    //     0xa3ffb4: ldurb           w16, [x1, #-1]
    //     0xa3ffb8: ldurb           w17, [x0, #-1]
    //     0xa3ffbc: and             x16, x17, x16, lsr #2
    //     0xa3ffc0: tst             x16, HEAP, lsr #32
    //     0xa3ffc4: b.eq            #0xa3ffcc
    //     0xa3ffc8: bl              #0xd6826c
    // 0xa3ffcc: r0 = Null
    //     0xa3ffcc: mov             x0, NULL
    // 0xa3ffd0: LeaveFrame
    //     0xa3ffd0: mov             SP, fp
    //     0xa3ffd4: ldp             fp, lr, [SP], #0x10
    // 0xa3ffd8: ret
    //     0xa3ffd8: ret             
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a7c8, size: 0x18
    // 0xa4a7c8: r4 = 7
    //     0xa4a7c8: mov             x4, #7
    // 0xa4a7cc: r1 = Function 'dispose':.
    //     0xa4a7cc: add             x17, PP, #0x50, lsl #12  ; [pp+0x50830] AnonymousClosure: (0xa4a7e0), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::dispose (0xa507a4)
    //     0xa4a7d0: ldr             x1, [x17, #0x830]
    // 0xa4a7d4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a7d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a7d8: LoadField: r0 = r24->field_17
    //     0xa4a7d8: ldur            x0, [x24, #0x17]
    // 0xa4a7dc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a7e0, size: 0x48
    // 0xa4a7e0: EnterFrame
    //     0xa4a7e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a7e4: mov             fp, SP
    // 0xa4a7e8: ldr             x0, [fp, #0x10]
    // 0xa4a7ec: LoadField: r1 = r0->field_17
    //     0xa4a7ec: ldur            w1, [x0, #0x17]
    // 0xa4a7f0: DecompressPointer r1
    //     0xa4a7f0: add             x1, x1, HEAP, lsl #32
    // 0xa4a7f4: CheckStackOverflow
    //     0xa4a7f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a7f8: cmp             SP, x16
    //     0xa4a7fc: b.ls            #0xa4a820
    // 0xa4a800: LoadField: r0 = r1->field_f
    //     0xa4a800: ldur            w0, [x1, #0xf]
    // 0xa4a804: DecompressPointer r0
    //     0xa4a804: add             x0, x0, HEAP, lsl #32
    // 0xa4a808: SaveReg r0
    //     0xa4a808: str             x0, [SP, #-8]!
    // 0xa4a80c: r0 = dispose()
    //     0xa4a80c: bl              #0xa507a4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::dispose
    // 0xa4a810: add             SP, SP, #8
    // 0xa4a814: LeaveFrame
    //     0xa4a814: mov             SP, fp
    //     0xa4a818: ldp             fp, lr, [SP], #0x10
    // 0xa4a81c: ret
    //     0xa4a81c: ret             
    // 0xa4a820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a824: b               #0xa4a800
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa507a4, size: 0x6c
    // 0xa507a4: EnterFrame
    //     0xa507a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa507a8: mov             fp, SP
    // 0xa507ac: CheckStackOverflow
    //     0xa507ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa507b0: cmp             SP, x16
    //     0xa507b4: b.ls            #0xa507fc
    // 0xa507b8: ldr             x0, [fp, #0x10]
    // 0xa507bc: LoadField: r1 = r0->field_47
    //     0xa507bc: ldur            w1, [x0, #0x47]
    // 0xa507c0: DecompressPointer r1
    //     0xa507c0: add             x1, x1, HEAP, lsl #32
    // 0xa507c4: r16 = Sentinel
    //     0xa507c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa507c8: cmp             w1, w16
    // 0xa507cc: b.eq            #0xa50804
    // 0xa507d0: SaveReg r1
    //     0xa507d0: str             x1, [SP, #-8]!
    // 0xa507d4: r0 = dispose()
    //     0xa507d4: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa507d8: add             SP, SP, #8
    // 0xa507dc: ldr             x16, [fp, #0x10]
    // 0xa507e0: SaveReg r16
    //     0xa507e0: str             x16, [SP, #-8]!
    // 0xa507e4: r0 = dispose()
    //     0xa507e4: bl              #0xa50810  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::dispose
    // 0xa507e8: add             SP, SP, #8
    // 0xa507ec: r0 = Null
    //     0xa507ec: mov             x0, NULL
    // 0xa507f0: LeaveFrame
    //     0xa507f0: mov             SP, fp
    //     0xa507f4: ldp             fp, lr, [SP], #0x10
    // 0xa507f8: ret
    //     0xa507f8: ret             
    // 0xa507fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa507fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50800: b               #0xa507b8
    // 0xa50804: r9 = _hoverAnimationController
    //     0xa50804: add             x9, PP, #0x50, lsl #12  ; [pp+0x50838] Field <_MaterialScrollbarState@802083257._hoverAnimationController@802083257>: late (offset: 0x48)
    //     0xa50808: ldr             x9, [x9, #0x838]
    // 0xa5080c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5080c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa60e2c, size: 0x100
    // 0xa60e2c: EnterFrame
    //     0xa60e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60e30: mov             fp, SP
    // 0xa60e34: AllocStack(0x8)
    //     0xa60e34: sub             SP, SP, #8
    // 0xa60e38: CheckStackOverflow
    //     0xa60e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60e3c: cmp             SP, x16
    //     0xa60e40: b.ls            #0xa60f1c
    // 0xa60e44: ldr             x0, [fp, #0x10]
    // 0xa60e48: LoadField: r1 = r0->field_f
    //     0xa60e48: ldur            w1, [x0, #0xf]
    // 0xa60e4c: DecompressPointer r1
    //     0xa60e4c: add             x1, x1, HEAP, lsl #32
    // 0xa60e50: cmp             w1, NULL
    // 0xa60e54: b.eq            #0xa60f24
    // 0xa60e58: SaveReg r1
    //     0xa60e58: str             x1, [SP, #-8]!
    // 0xa60e5c: r0 = of()
    //     0xa60e5c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xa60e60: add             SP, SP, #8
    // 0xa60e64: mov             x1, x0
    // 0xa60e68: stur            x1, [fp, #-8]
    // 0xa60e6c: LoadField: r0 = r1->field_3f
    //     0xa60e6c: ldur            w0, [x1, #0x3f]
    // 0xa60e70: DecompressPointer r0
    //     0xa60e70: add             x0, x0, HEAP, lsl #32
    // 0xa60e74: ldr             x2, [fp, #0x10]
    // 0xa60e78: StoreField: r2->field_53 = r0
    //     0xa60e78: stur            w0, [x2, #0x53]
    //     0xa60e7c: ldurb           w16, [x2, #-1]
    //     0xa60e80: ldurb           w17, [x0, #-1]
    //     0xa60e84: and             x16, x17, x16, lsr #2
    //     0xa60e88: tst             x16, HEAP, lsr #32
    //     0xa60e8c: b.eq            #0xa60e94
    //     0xa60e90: bl              #0xd6828c
    // 0xa60e94: LoadField: r0 = r2->field_f
    //     0xa60e94: ldur            w0, [x2, #0xf]
    // 0xa60e98: DecompressPointer r0
    //     0xa60e98: add             x0, x0, HEAP, lsl #32
    // 0xa60e9c: cmp             w0, NULL
    // 0xa60ea0: b.eq            #0xa60f28
    // 0xa60ea4: SaveReg r0
    //     0xa60ea4: str             x0, [SP, #-8]!
    // 0xa60ea8: r0 = of()
    //     0xa60ea8: bl              #0xa60f2c  ; [package:flutter/src/material/scrollbar_theme.dart] ScrollbarTheme::of
    // 0xa60eac: add             SP, SP, #8
    // 0xa60eb0: ldr             x1, [fp, #0x10]
    // 0xa60eb4: StoreField: r1->field_57 = r0
    //     0xa60eb4: stur            w0, [x1, #0x57]
    //     0xa60eb8: ldurb           w16, [x1, #-1]
    //     0xa60ebc: ldurb           w17, [x0, #-1]
    //     0xa60ec0: and             x16, x17, x16, lsr #2
    //     0xa60ec4: tst             x16, HEAP, lsr #32
    //     0xa60ec8: b.eq            #0xa60ed0
    //     0xa60ecc: bl              #0xd6826c
    // 0xa60ed0: ldur            x2, [fp, #-8]
    // 0xa60ed4: LoadField: r3 = r2->field_1f
    //     0xa60ed4: ldur            w3, [x2, #0x1f]
    // 0xa60ed8: DecompressPointer r3
    //     0xa60ed8: add             x3, x3, HEAP, lsl #32
    // 0xa60edc: LoadField: r2 = r3->field_7
    //     0xa60edc: ldur            x2, [x3, #7]
    // 0xa60ee0: cmp             x2, #2
    // 0xa60ee4: b.gt            #0xa60f04
    // 0xa60ee8: cmp             x2, #1
    // 0xa60eec: b.gt            #0xa60f04
    // 0xa60ef0: cmp             x2, #0
    // 0xa60ef4: b.gt            #0xa60f04
    // 0xa60ef8: r2 = true
    //     0xa60ef8: add             x2, NULL, #0x20  ; true
    // 0xa60efc: StoreField: r1->field_5b = r2
    //     0xa60efc: stur            w2, [x1, #0x5b]
    // 0xa60f00: b               #0xa60f0c
    // 0xa60f04: r2 = false
    //     0xa60f04: add             x2, NULL, #0x30  ; false
    // 0xa60f08: StoreField: r1->field_5b = r2
    //     0xa60f08: stur            w2, [x1, #0x5b]
    // 0xa60f0c: r0 = Null
    //     0xa60f0c: mov             x0, NULL
    // 0xa60f10: LeaveFrame
    //     0xa60f10: mov             SP, fp
    //     0xa60f14: ldp             fp, lr, [SP], #0x10
    // 0xa60f18: ret
    //     0xa60f18: ret             
    // 0xa60f1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60f1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60f20: b               #0xa60e44
    // 0xa60f24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60f24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa60f28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa60f28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleHoverExit(/* No info */) {
    // ** addr: 0xcccd68, size: 0xa8
    // 0xcccd68: EnterFrame
    //     0xcccd68: stp             fp, lr, [SP, #-0x10]!
    //     0xcccd6c: mov             fp, SP
    // 0xcccd70: AllocStack(0x8)
    //     0xcccd70: sub             SP, SP, #8
    // 0xcccd74: CheckStackOverflow
    //     0xcccd74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcccd78: cmp             SP, x16
    //     0xcccd7c: b.ls            #0xcccdfc
    // 0xcccd80: r1 = 1
    //     0xcccd80: mov             x1, #1
    // 0xcccd84: r0 = AllocateContext()
    //     0xcccd84: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcccd88: mov             x1, x0
    // 0xcccd8c: ldr             x0, [fp, #0x10]
    // 0xcccd90: stur            x1, [fp, #-8]
    // 0xcccd94: StoreField: r1->field_f = r0
    //     0xcccd94: stur            w0, [x1, #0xf]
    // 0xcccd98: SaveReg r0
    //     0xcccd98: str             x0, [SP, #-8]!
    // 0xcccd9c: r0 = handleHoverExit()
    //     0xcccd9c: bl              #0xccce34  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleHoverExit
    // 0xcccda0: add             SP, SP, #8
    // 0xcccda4: ldur            x2, [fp, #-8]
    // 0xcccda8: r1 = Function '<anonymous closure>':.
    //     0xcccda8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53048] AnonymousClosure: (0xccce10), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleHoverExit (0xcccd68)
    //     0xcccdac: ldr             x1, [x1, #0x48]
    // 0xcccdb0: r0 = AllocateClosure()
    //     0xcccdb0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcccdb4: ldr             x16, [fp, #0x10]
    // 0xcccdb8: stp             x0, x16, [SP, #-0x10]!
    // 0xcccdbc: r0 = setState()
    //     0xcccdbc: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xcccdc0: add             SP, SP, #0x10
    // 0xcccdc4: ldr             x0, [fp, #0x10]
    // 0xcccdc8: LoadField: r1 = r0->field_47
    //     0xcccdc8: ldur            w1, [x0, #0x47]
    // 0xcccdcc: DecompressPointer r1
    //     0xcccdcc: add             x1, x1, HEAP, lsl #32
    // 0xcccdd0: r16 = Sentinel
    //     0xcccdd0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcccdd4: cmp             w1, w16
    // 0xcccdd8: b.eq            #0xccce04
    // 0xcccddc: SaveReg r1
    //     0xcccddc: str             x1, [SP, #-8]!
    // 0xcccde0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcccde0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcccde4: r0 = reverse()
    //     0xcccde4: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xcccde8: add             SP, SP, #8
    // 0xcccdec: r0 = Null
    //     0xcccdec: mov             x0, NULL
    // 0xcccdf0: LeaveFrame
    //     0xcccdf0: mov             SP, fp
    //     0xcccdf4: ldp             fp, lr, [SP], #0x10
    // 0xcccdf8: ret
    //     0xcccdf8: ret             
    // 0xcccdfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcccdfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccce00: b               #0xcccd80
    // 0xccce04: r9 = _hoverAnimationController
    //     0xccce04: add             x9, PP, #0x50, lsl #12  ; [pp+0x50838] Field <_MaterialScrollbarState@802083257._hoverAnimationController@802083257>: late (offset: 0x48)
    //     0xccce08: ldr             x9, [x9, #0x838]
    // 0xccce0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xccce0c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xccce10, size: 0x24
    // 0xccce10: r1 = false
    //     0xccce10: add             x1, NULL, #0x30  ; false
    // 0xccce14: ldr             x2, [SP]
    // 0xccce18: LoadField: r3 = r2->field_17
    //     0xccce18: ldur            w3, [x2, #0x17]
    // 0xccce1c: DecompressPointer r3
    //     0xccce1c: add             x3, x3, HEAP, lsl #32
    // 0xccce20: LoadField: r2 = r3->field_f
    //     0xccce20: ldur            w2, [x3, #0xf]
    // 0xccce24: DecompressPointer r2
    //     0xccce24: add             x2, x2, HEAP, lsl #32
    // 0xccce28: StoreField: r2->field_4f = r1
    //     0xccce28: stur            w1, [x2, #0x4f]
    // 0xccce2c: r0 = Null
    //     0xccce2c: mov             x0, NULL
    // 0xccce30: ret
    //     0xccce30: ret             
  }
  _ handleHover(/* No info */) {
    // ** addr: 0xccce78, size: 0x194
    // 0xccce78: EnterFrame
    //     0xccce78: stp             fp, lr, [SP, #-0x10]!
    //     0xccce7c: mov             fp, SP
    // 0xccce80: AllocStack(0x10)
    //     0xccce80: sub             SP, SP, #0x10
    // 0xccce84: CheckStackOverflow
    //     0xccce84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccce88: cmp             SP, x16
    //     0xccce8c: b.ls            #0xcccfec
    // 0xccce90: r1 = 1
    //     0xccce90: mov             x1, #1
    // 0xccce94: r0 = AllocateContext()
    //     0xccce94: bl              #0xd68aa4  ; AllocateContextStub
    // 0xccce98: mov             x1, x0
    // 0xccce9c: ldr             x0, [fp, #0x18]
    // 0xcccea0: stur            x1, [fp, #-8]
    // 0xcccea4: StoreField: r1->field_f = r0
    //     0xcccea4: stur            w0, [x1, #0xf]
    // 0xcccea8: ldr             x16, [fp, #0x10]
    // 0xccceac: stp             x16, x0, [SP, #-0x10]!
    // 0xccceb0: r0 = handleHover()
    //     0xccceb0: bl              #0xccd0f0  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleHover
    // 0xccceb4: add             SP, SP, #0x10
    // 0xccceb8: ldr             x1, [fp, #0x10]
    // 0xcccebc: r0 = LoadClassIdInstr(r1)
    //     0xcccebc: ldur            x0, [x1, #-1]
    //     0xcccec0: ubfx            x0, x0, #0xc, #0x14
    // 0xcccec4: SaveReg r1
    //     0xcccec4: str             x1, [SP, #-8]!
    // 0xcccec8: r0 = GDT[cid_x0 + -0xfd9]()
    //     0xcccec8: sub             lr, x0, #0xfd9
    //     0xcccecc: ldr             lr, [x21, lr, lsl #3]
    //     0xccced0: blr             lr
    // 0xccced4: add             SP, SP, #8
    // 0xccced8: mov             x1, x0
    // 0xcccedc: ldr             x0, [fp, #0x10]
    // 0xcccee0: stur            x1, [fp, #-0x10]
    // 0xcccee4: r2 = LoadClassIdInstr(r0)
    //     0xcccee4: ldur            x2, [x0, #-1]
    //     0xcccee8: ubfx            x2, x2, #0xc, #0x14
    // 0xccceec: SaveReg r0
    //     0xccceec: str             x0, [SP, #-8]!
    // 0xcccef0: mov             x0, x2
    // 0xcccef4: r0 = GDT[cid_x0 + -0xf60]()
    //     0xcccef4: sub             lr, x0, #0xf60
    //     0xcccef8: ldr             lr, [x21, lr, lsl #3]
    //     0xcccefc: blr             lr
    // 0xcccf00: add             SP, SP, #8
    // 0xcccf04: ldr             x16, [fp, #0x18]
    // 0xcccf08: ldur            lr, [fp, #-0x10]
    // 0xcccf0c: stp             lr, x16, [SP, #-0x10]!
    // 0xcccf10: SaveReg r0
    //     0xcccf10: str             x0, [SP, #-8]!
    // 0xcccf14: r0 = isPointerOverScrollbar()
    //     0xcccf14: bl              #0xccd00c  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::isPointerOverScrollbar
    // 0xcccf18: add             SP, SP, #0x18
    // 0xcccf1c: mov             x1, x0
    // 0xcccf20: stur            x1, [fp, #-0x10]
    // 0xcccf24: tbnz            w0, #5, #0xcccf2c
    // 0xcccf28: r0 = AssertBoolean()
    //     0xcccf28: bl              #0xd67df0  ; AssertBooleanStub
    // 0xcccf2c: ldur            x0, [fp, #-0x10]
    // 0xcccf30: tbnz            w0, #4, #0xcccf84
    // 0xcccf34: ldr             x0, [fp, #0x18]
    // 0xcccf38: ldur            x2, [fp, #-8]
    // 0xcccf3c: r1 = Function '<anonymous closure>':.
    //     0xcccf3c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53050] AnonymousClosure: (0xccd0cc), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleHover (0xccce78)
    //     0xcccf40: ldr             x1, [x1, #0x50]
    // 0xcccf44: r0 = AllocateClosure()
    //     0xcccf44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcccf48: ldr             x16, [fp, #0x18]
    // 0xcccf4c: stp             x0, x16, [SP, #-0x10]!
    // 0xcccf50: r0 = setState()
    //     0xcccf50: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xcccf54: add             SP, SP, #0x10
    // 0xcccf58: ldr             x0, [fp, #0x18]
    // 0xcccf5c: LoadField: r1 = r0->field_47
    //     0xcccf5c: ldur            w1, [x0, #0x47]
    // 0xcccf60: DecompressPointer r1
    //     0xcccf60: add             x1, x1, HEAP, lsl #32
    // 0xcccf64: r16 = Sentinel
    //     0xcccf64: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcccf68: cmp             w1, w16
    // 0xcccf6c: b.eq            #0xcccff4
    // 0xcccf70: SaveReg r1
    //     0xcccf70: str             x1, [SP, #-8]!
    // 0xcccf74: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcccf74: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcccf78: r0 = forward()
    //     0xcccf78: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xcccf7c: add             SP, SP, #8
    // 0xcccf80: b               #0xcccfdc
    // 0xcccf84: ldr             x0, [fp, #0x18]
    // 0xcccf88: LoadField: r1 = r0->field_4f
    //     0xcccf88: ldur            w1, [x0, #0x4f]
    // 0xcccf8c: DecompressPointer r1
    //     0xcccf8c: add             x1, x1, HEAP, lsl #32
    // 0xcccf90: tbnz            w1, #4, #0xcccfdc
    // 0xcccf94: ldur            x2, [fp, #-8]
    // 0xcccf98: r1 = Function '<anonymous closure>':.
    //     0xcccf98: add             x1, PP, #0x53, lsl #12  ; [pp+0x53058] AnonymousClosure: (0xccce10), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleHoverExit (0xcccd68)
    //     0xcccf9c: ldr             x1, [x1, #0x58]
    // 0xcccfa0: r0 = AllocateClosure()
    //     0xcccfa0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcccfa4: ldr             x16, [fp, #0x18]
    // 0xcccfa8: stp             x0, x16, [SP, #-0x10]!
    // 0xcccfac: r0 = setState()
    //     0xcccfac: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xcccfb0: add             SP, SP, #0x10
    // 0xcccfb4: ldr             x0, [fp, #0x18]
    // 0xcccfb8: LoadField: r1 = r0->field_47
    //     0xcccfb8: ldur            w1, [x0, #0x47]
    // 0xcccfbc: DecompressPointer r1
    //     0xcccfbc: add             x1, x1, HEAP, lsl #32
    // 0xcccfc0: r16 = Sentinel
    //     0xcccfc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcccfc4: cmp             w1, w16
    // 0xcccfc8: b.eq            #0xccd000
    // 0xcccfcc: SaveReg r1
    //     0xcccfcc: str             x1, [SP, #-8]!
    // 0xcccfd0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcccfd0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcccfd4: r0 = reverse()
    //     0xcccfd4: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xcccfd8: add             SP, SP, #8
    // 0xcccfdc: r0 = Null
    //     0xcccfdc: mov             x0, NULL
    // 0xcccfe0: LeaveFrame
    //     0xcccfe0: mov             SP, fp
    //     0xcccfe4: ldp             fp, lr, [SP], #0x10
    // 0xcccfe8: ret
    //     0xcccfe8: ret             
    // 0xcccfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcccfec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcccff0: b               #0xccce90
    // 0xcccff4: r9 = _hoverAnimationController
    //     0xcccff4: add             x9, PP, #0x50, lsl #12  ; [pp+0x50838] Field <_MaterialScrollbarState@802083257._hoverAnimationController@802083257>: late (offset: 0x48)
    //     0xcccff8: ldr             x9, [x9, #0x838]
    // 0xcccffc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcccffc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xccd000: r9 = _hoverAnimationController
    //     0xccd000: add             x9, PP, #0x50, lsl #12  ; [pp+0x50838] Field <_MaterialScrollbarState@802083257._hoverAnimationController@802083257>: late (offset: 0x48)
    //     0xccd004: ldr             x9, [x9, #0x838]
    // 0xccd008: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xccd008: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xccd0cc, size: 0x24
    // 0xccd0cc: r1 = true
    //     0xccd0cc: add             x1, NULL, #0x20  ; true
    // 0xccd0d0: ldr             x2, [SP]
    // 0xccd0d4: LoadField: r3 = r2->field_17
    //     0xccd0d4: ldur            w3, [x2, #0x17]
    // 0xccd0d8: DecompressPointer r3
    //     0xccd0d8: add             x3, x3, HEAP, lsl #32
    // 0xccd0dc: LoadField: r2 = r3->field_f
    //     0xccd0dc: ldur            w2, [x3, #0xf]
    // 0xccd0e0: DecompressPointer r2
    //     0xccd0e0: add             x2, x2, HEAP, lsl #32
    // 0xccd0e4: StoreField: r2->field_4f = r1
    //     0xccd0e4: stur            w1, [x2, #0x4f]
    // 0xccd0e8: r0 = Null
    //     0xccd0e8: mov             x0, NULL
    // 0xccd0ec: ret
    //     0xccd0ec: ret             
  }
  _ handleThumbPressEnd(/* No info */) {
    // ** addr: 0xccd610, size: 0x80
    // 0xccd610: EnterFrame
    //     0xccd610: stp             fp, lr, [SP, #-0x10]!
    //     0xccd614: mov             fp, SP
    // 0xccd618: AllocStack(0x8)
    //     0xccd618: sub             SP, SP, #8
    // 0xccd61c: CheckStackOverflow
    //     0xccd61c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccd620: cmp             SP, x16
    //     0xccd624: b.ls            #0xccd688
    // 0xccd628: r1 = 1
    //     0xccd628: mov             x1, #1
    // 0xccd62c: r0 = AllocateContext()
    //     0xccd62c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xccd630: mov             x1, x0
    // 0xccd634: ldr             x0, [fp, #0x20]
    // 0xccd638: stur            x1, [fp, #-8]
    // 0xccd63c: StoreField: r1->field_f = r0
    //     0xccd63c: stur            w0, [x1, #0xf]
    // 0xccd640: ldr             x16, [fp, #0x18]
    // 0xccd644: stp             x16, x0, [SP, #-0x10]!
    // 0xccd648: ldr             x16, [fp, #0x10]
    // 0xccd64c: SaveReg r16
    //     0xccd64c: str             x16, [SP, #-8]!
    // 0xccd650: r0 = handleThumbPressEnd()
    //     0xccd650: bl              #0xccd6b4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressEnd
    // 0xccd654: add             SP, SP, #0x18
    // 0xccd658: ldur            x2, [fp, #-8]
    // 0xccd65c: r1 = Function '<anonymous closure>':.
    //     0xccd65c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53060] AnonymousClosure: (0xccd690), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleThumbPressEnd (0xccd610)
    //     0xccd660: ldr             x1, [x1, #0x60]
    // 0xccd664: r0 = AllocateClosure()
    //     0xccd664: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xccd668: ldr             x16, [fp, #0x20]
    // 0xccd66c: stp             x0, x16, [SP, #-0x10]!
    // 0xccd670: r0 = setState()
    //     0xccd670: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xccd674: add             SP, SP, #0x10
    // 0xccd678: r0 = Null
    //     0xccd678: mov             x0, NULL
    // 0xccd67c: LeaveFrame
    //     0xccd67c: mov             SP, fp
    //     0xccd680: ldp             fp, lr, [SP], #0x10
    // 0xccd684: ret
    //     0xccd684: ret             
    // 0xccd688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccd688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccd68c: b               #0xccd628
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xccd690, size: 0x24
    // 0xccd690: r1 = false
    //     0xccd690: add             x1, NULL, #0x30  ; false
    // 0xccd694: ldr             x2, [SP]
    // 0xccd698: LoadField: r3 = r2->field_17
    //     0xccd698: ldur            w3, [x2, #0x17]
    // 0xccd69c: DecompressPointer r3
    //     0xccd69c: add             x3, x3, HEAP, lsl #32
    // 0xccd6a0: LoadField: r2 = r3->field_f
    //     0xccd6a0: ldur            w2, [x3, #0xf]
    // 0xccd6a4: DecompressPointer r2
    //     0xccd6a4: add             x2, x2, HEAP, lsl #32
    // 0xccd6a8: StoreField: r2->field_4b = r1
    //     0xccd6a8: stur            w1, [x2, #0x4b]
    // 0xccd6ac: r0 = Null
    //     0xccd6ac: mov             x0, NULL
    // 0xccd6b0: ret
    //     0xccd6b0: ret             
  }
  _ handleThumbPressStart(/* No info */) {
    // ** addr: 0xccd8f0, size: 0x78
    // 0xccd8f0: EnterFrame
    //     0xccd8f0: stp             fp, lr, [SP, #-0x10]!
    //     0xccd8f4: mov             fp, SP
    // 0xccd8f8: AllocStack(0x8)
    //     0xccd8f8: sub             SP, SP, #8
    // 0xccd8fc: CheckStackOverflow
    //     0xccd8fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccd900: cmp             SP, x16
    //     0xccd904: b.ls            #0xccd960
    // 0xccd908: r1 = 1
    //     0xccd908: mov             x1, #1
    // 0xccd90c: r0 = AllocateContext()
    //     0xccd90c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xccd910: mov             x1, x0
    // 0xccd914: ldr             x0, [fp, #0x18]
    // 0xccd918: stur            x1, [fp, #-8]
    // 0xccd91c: StoreField: r1->field_f = r0
    //     0xccd91c: stur            w0, [x1, #0xf]
    // 0xccd920: ldr             x16, [fp, #0x10]
    // 0xccd924: stp             x16, x0, [SP, #-0x10]!
    // 0xccd928: r0 = handleThumbPressStart()
    //     0xccd928: bl              #0xccd98c  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressStart
    // 0xccd92c: add             SP, SP, #0x10
    // 0xccd930: ldur            x2, [fp, #-8]
    // 0xccd934: r1 = Function '<anonymous closure>':.
    //     0xccd934: add             x1, PP, #0x53, lsl #12  ; [pp+0x53068] AnonymousClosure: (0xccd968), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::handleThumbPressStart (0xccd8f0)
    //     0xccd938: ldr             x1, [x1, #0x68]
    // 0xccd93c: r0 = AllocateClosure()
    //     0xccd93c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xccd940: ldr             x16, [fp, #0x18]
    // 0xccd944: stp             x0, x16, [SP, #-0x10]!
    // 0xccd948: r0 = setState()
    //     0xccd948: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0xccd94c: add             SP, SP, #0x10
    // 0xccd950: r0 = Null
    //     0xccd950: mov             x0, NULL
    // 0xccd954: LeaveFrame
    //     0xccd954: mov             SP, fp
    //     0xccd958: ldp             fp, lr, [SP], #0x10
    // 0xccd95c: ret
    //     0xccd95c: ret             
    // 0xccd960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccd960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccd964: b               #0xccd908
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xccd968, size: 0x24
    // 0xccd968: r1 = true
    //     0xccd968: add             x1, NULL, #0x20  ; true
    // 0xccd96c: ldr             x2, [SP]
    // 0xccd970: LoadField: r3 = r2->field_17
    //     0xccd970: ldur            w3, [x2, #0x17]
    // 0xccd974: DecompressPointer r3
    //     0xccd974: add             x3, x3, HEAP, lsl #32
    // 0xccd978: LoadField: r2 = r3->field_f
    //     0xccd978: ldur            w2, [x3, #0xf]
    // 0xccd97c: DecompressPointer r2
    //     0xccd97c: add             x2, x2, HEAP, lsl #32
    // 0xccd980: StoreField: r2->field_4b = r1
    //     0xccd980: stur            w1, [x2, #0x4b]
    // 0xccd984: r0 = Null
    //     0xccd984: mov             x0, NULL
    // 0xccd988: ret
    //     0xccd988: ret             
  }
  _ updateScrollbarPainter(/* No info */) {
    // ** addr: 0xcd2f7c, size: 0x3f0
    // 0xcd2f7c: EnterFrame
    //     0xcd2f7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd2f80: mov             fp, SP
    // 0xcd2f84: AllocStack(0x10)
    //     0xcd2f84: sub             SP, SP, #0x10
    // 0xcd2f88: CheckStackOverflow
    //     0xcd2f88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd2f8c: cmp             SP, x16
    //     0xcd2f90: b.ls            #0xcd3308
    // 0xcd2f94: ldr             x0, [fp, #0x10]
    // 0xcd2f98: LoadField: r1 = r0->field_43
    //     0xcd2f98: ldur            w1, [x0, #0x43]
    // 0xcd2f9c: DecompressPointer r1
    //     0xcd2f9c: add             x1, x1, HEAP, lsl #32
    // 0xcd2fa0: r16 = Sentinel
    //     0xcd2fa0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd2fa4: cmp             w1, w16
    // 0xcd2fa8: b.eq            #0xcd3310
    // 0xcd2fac: stur            x1, [fp, #-8]
    // 0xcd2fb0: SaveReg r0
    //     0xcd2fb0: str             x0, [SP, #-8]!
    // 0xcd2fb4: r0 = _thumbColor()
    //     0xcd2fb4: bl              #0xcd40e0  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thumbColor
    // 0xcd2fb8: add             SP, SP, #8
    // 0xcd2fbc: stur            x0, [fp, #-0x10]
    // 0xcd2fc0: ldr             x16, [fp, #0x10]
    // 0xcd2fc4: SaveReg r16
    //     0xcd2fc4: str             x16, [SP, #-8]!
    // 0xcd2fc8: r0 = _states()
    //     0xcd2fc8: bl              #0xcd3ff4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0xcd2fcc: add             SP, SP, #8
    // 0xcd2fd0: ldur            x16, [fp, #-0x10]
    // 0xcd2fd4: stp             x0, x16, [SP, #-0x10]!
    // 0xcd2fd8: r0 = build()
    //     0xcd2fd8: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd2fdc: add             SP, SP, #0x10
    // 0xcd2fe0: ldur            x16, [fp, #-8]
    // 0xcd2fe4: stp             x0, x16, [SP, #-0x10]!
    // 0xcd2fe8: r0 = color=()
    //     0xcd2fe8: bl              #0xcd2dd4  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::color=
    // 0xcd2fec: add             SP, SP, #0x10
    // 0xcd2ff0: ldr             x16, [fp, #0x10]
    // 0xcd2ff4: SaveReg r16
    //     0xcd2ff4: str             x16, [SP, #-8]!
    // 0xcd2ff8: r0 = _trackColor()
    //     0xcd2ff8: bl              #0xcd3dd0  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackColor
    // 0xcd2ffc: add             SP, SP, #8
    // 0xcd3000: stur            x0, [fp, #-0x10]
    // 0xcd3004: ldr             x16, [fp, #0x10]
    // 0xcd3008: SaveReg r16
    //     0xcd3008: str             x16, [SP, #-8]!
    // 0xcd300c: r0 = _states()
    //     0xcd300c: bl              #0xcd3ff4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0xcd3010: add             SP, SP, #8
    // 0xcd3014: ldur            x16, [fp, #-0x10]
    // 0xcd3018: stp             x0, x16, [SP, #-0x10]!
    // 0xcd301c: r0 = build()
    //     0xcd301c: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd3020: add             SP, SP, #0x10
    // 0xcd3024: ldur            x16, [fp, #-8]
    // 0xcd3028: stp             x0, x16, [SP, #-0x10]!
    // 0xcd302c: r0 = trackColor=()
    //     0xcd302c: bl              #0xcd3c28  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::trackColor=
    // 0xcd3030: add             SP, SP, #0x10
    // 0xcd3034: ldr             x16, [fp, #0x10]
    // 0xcd3038: SaveReg r16
    //     0xcd3038: str             x16, [SP, #-8]!
    // 0xcd303c: r0 = _trackBorderColor()
    //     0xcd303c: bl              #0xcd3a0c  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackBorderColor
    // 0xcd3040: add             SP, SP, #8
    // 0xcd3044: stur            x0, [fp, #-0x10]
    // 0xcd3048: ldr             x16, [fp, #0x10]
    // 0xcd304c: SaveReg r16
    //     0xcd304c: str             x16, [SP, #-8]!
    // 0xcd3050: r0 = _states()
    //     0xcd3050: bl              #0xcd3ff4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0xcd3054: add             SP, SP, #8
    // 0xcd3058: ldur            x16, [fp, #-0x10]
    // 0xcd305c: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3060: r0 = build()
    //     0xcd3060: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd3064: add             SP, SP, #0x10
    // 0xcd3068: ldur            x16, [fp, #-8]
    // 0xcd306c: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3070: r0 = trackBorderColor=()
    //     0xcd3070: bl              #0xcd3864  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::trackBorderColor=
    // 0xcd3074: add             SP, SP, #0x10
    // 0xcd3078: ldr             x0, [fp, #0x10]
    // 0xcd307c: LoadField: r1 = r0->field_f
    //     0xcd307c: ldur            w1, [x0, #0xf]
    // 0xcd3080: DecompressPointer r1
    //     0xcd3080: add             x1, x1, HEAP, lsl #32
    // 0xcd3084: cmp             w1, NULL
    // 0xcd3088: b.eq            #0xcd331c
    // 0xcd308c: SaveReg r1
    //     0xcd308c: str             x1, [SP, #-8]!
    // 0xcd3090: r0 = of()
    //     0xcd3090: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcd3094: add             SP, SP, #8
    // 0xcd3098: ldur            x16, [fp, #-8]
    // 0xcd309c: stp             x0, x16, [SP, #-0x10]!
    // 0xcd30a0: r0 = textDirection=()
    //     0xcd30a0: bl              #0xcd2a7c  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::textDirection=
    // 0xcd30a4: add             SP, SP, #0x10
    // 0xcd30a8: ldr             x16, [fp, #0x10]
    // 0xcd30ac: SaveReg r16
    //     0xcd30ac: str             x16, [SP, #-8]!
    // 0xcd30b0: r0 = _thickness()
    //     0xcd30b0: bl              #0xcd33d0  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thickness
    // 0xcd30b4: add             SP, SP, #8
    // 0xcd30b8: stur            x0, [fp, #-0x10]
    // 0xcd30bc: ldr             x16, [fp, #0x10]
    // 0xcd30c0: SaveReg r16
    //     0xcd30c0: str             x16, [SP, #-8]!
    // 0xcd30c4: r0 = _states()
    //     0xcd30c4: bl              #0xcd3ff4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0xcd30c8: add             SP, SP, #8
    // 0xcd30cc: ldur            x16, [fp, #-0x10]
    // 0xcd30d0: stp             x0, x16, [SP, #-0x10]!
    // 0xcd30d4: r0 = build()
    //     0xcd30d4: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd30d8: add             SP, SP, #0x10
    // 0xcd30dc: LoadField: d0 = r0->field_7
    //     0xcd30dc: ldur            d0, [x0, #7]
    // 0xcd30e0: ldur            x16, [fp, #-8]
    // 0xcd30e4: SaveReg r16
    //     0xcd30e4: str             x16, [SP, #-8]!
    // 0xcd30e8: SaveReg d0
    //     0xcd30e8: str             d0, [SP, #-8]!
    // 0xcd30ec: r0 = thickness=()
    //     0xcd30ec: bl              #0xcd2a18  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::thickness=
    // 0xcd30f0: add             SP, SP, #0x10
    // 0xcd30f4: ldr             x0, [fp, #0x10]
    // 0xcd30f8: LoadField: r1 = r0->field_b
    //     0xcd30f8: ldur            w1, [x0, #0xb]
    // 0xcd30fc: DecompressPointer r1
    //     0xcd30fc: add             x1, x1, HEAP, lsl #32
    // 0xcd3100: cmp             w1, NULL
    // 0xcd3104: b.eq            #0xcd3320
    // 0xcd3108: LoadField: r2 = r1->field_1f
    //     0xcd3108: ldur            w2, [x1, #0x1f]
    // 0xcd310c: DecompressPointer r2
    //     0xcd310c: add             x2, x2, HEAP, lsl #32
    // 0xcd3110: cmp             w2, NULL
    // 0xcd3114: b.ne            #0xcd3134
    // 0xcd3118: LoadField: r1 = r0->field_57
    //     0xcd3118: ldur            w1, [x0, #0x57]
    // 0xcd311c: DecompressPointer r1
    //     0xcd311c: add             x1, x1, HEAP, lsl #32
    // 0xcd3120: r16 = Sentinel
    //     0xcd3120: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3124: cmp             w1, w16
    // 0xcd3128: b.eq            #0xcd3324
    // 0xcd312c: r1 = Null
    //     0xcd312c: mov             x1, NULL
    // 0xcd3130: b               #0xcd3138
    // 0xcd3134: mov             x1, x2
    // 0xcd3138: cmp             w1, NULL
    // 0xcd313c: b.ne            #0xcd3168
    // 0xcd3140: LoadField: r1 = r0->field_5b
    //     0xcd3140: ldur            w1, [x0, #0x5b]
    // 0xcd3144: DecompressPointer r1
    //     0xcd3144: add             x1, x1, HEAP, lsl #32
    // 0xcd3148: r16 = Sentinel
    //     0xcd3148: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd314c: cmp             w1, w16
    // 0xcd3150: b.eq            #0xcd3330
    // 0xcd3154: tbnz            w1, #4, #0xcd3160
    // 0xcd3158: r1 = Null
    //     0xcd3158: mov             x1, NULL
    // 0xcd315c: b               #0xcd3168
    // 0xcd3160: r1 = Instance_Radius
    //     0xcd3160: add             x1, PP, #0x37, lsl #12  ; [pp+0x37c28] Obj!Radius@b5e801
    //     0xcd3164: ldr             x1, [x1, #0xc28]
    // 0xcd3168: ldur            x16, [fp, #-8]
    // 0xcd316c: stp             x1, x16, [SP, #-0x10]!
    // 0xcd3170: r0 = radius=()
    //     0xcd3170: bl              #0xcd2bec  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::radius=
    // 0xcd3174: add             SP, SP, #0x10
    // 0xcd3178: ldr             x0, [fp, #0x10]
    // 0xcd317c: LoadField: r1 = r0->field_57
    //     0xcd317c: ldur            w1, [x0, #0x57]
    // 0xcd3180: DecompressPointer r1
    //     0xcd3180: add             x1, x1, HEAP, lsl #32
    // 0xcd3184: r16 = Sentinel
    //     0xcd3184: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3188: cmp             w1, w16
    // 0xcd318c: b.eq            #0xcd333c
    // 0xcd3190: LoadField: r2 = r1->field_2f
    //     0xcd3190: ldur            w2, [x1, #0x2f]
    // 0xcd3194: DecompressPointer r2
    //     0xcd3194: add             x2, x2, HEAP, lsl #32
    // 0xcd3198: cmp             w2, NULL
    // 0xcd319c: b.ne            #0xcd31c8
    // 0xcd31a0: LoadField: r1 = r0->field_5b
    //     0xcd31a0: ldur            w1, [x0, #0x5b]
    // 0xcd31a4: DecompressPointer r1
    //     0xcd31a4: add             x1, x1, HEAP, lsl #32
    // 0xcd31a8: r16 = Sentinel
    //     0xcd31a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd31ac: cmp             w1, w16
    // 0xcd31b0: b.eq            #0xcd3348
    // 0xcd31b4: tbnz            w1, #4, #0xcd31c0
    // 0xcd31b8: d0 = 0.000000
    //     0xcd31b8: eor             v0.16b, v0.16b, v0.16b
    // 0xcd31bc: b               #0xcd31cc
    // 0xcd31c0: d0 = 2.000000
    //     0xcd31c0: fmov            d0, #2.00000000
    // 0xcd31c4: b               #0xcd31cc
    // 0xcd31c8: LoadField: d0 = r2->field_7
    //     0xcd31c8: ldur            d0, [x2, #7]
    // 0xcd31cc: ldur            x16, [fp, #-8]
    // 0xcd31d0: SaveReg r16
    //     0xcd31d0: str             x16, [SP, #-8]!
    // 0xcd31d4: SaveReg d0
    //     0xcd31d4: str             d0, [SP, #-8]!
    // 0xcd31d8: r0 = crossAxisMargin=()
    //     0xcd31d8: bl              #0xcd2950  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::crossAxisMargin=
    // 0xcd31dc: add             SP, SP, #0x10
    // 0xcd31e0: ldr             x0, [fp, #0x10]
    // 0xcd31e4: LoadField: r1 = r0->field_57
    //     0xcd31e4: ldur            w1, [x0, #0x57]
    // 0xcd31e8: DecompressPointer r1
    //     0xcd31e8: add             x1, x1, HEAP, lsl #32
    // 0xcd31ec: LoadField: r2 = r1->field_33
    //     0xcd31ec: ldur            w2, [x1, #0x33]
    // 0xcd31f0: DecompressPointer r2
    //     0xcd31f0: add             x2, x2, HEAP, lsl #32
    // 0xcd31f4: cmp             w2, NULL
    // 0xcd31f8: b.ne            #0xcd3204
    // 0xcd31fc: d0 = 0.000000
    //     0xcd31fc: eor             v0.16b, v0.16b, v0.16b
    // 0xcd3200: b               #0xcd3208
    // 0xcd3204: LoadField: d0 = r2->field_7
    //     0xcd3204: ldur            d0, [x2, #7]
    // 0xcd3208: ldur            x16, [fp, #-8]
    // 0xcd320c: SaveReg r16
    //     0xcd320c: str             x16, [SP, #-8]!
    // 0xcd3210: SaveReg d0
    //     0xcd3210: str             d0, [SP, #-8]!
    // 0xcd3214: r0 = mainAxisMargin=()
    //     0xcd3214: bl              #0xcd29b4  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::mainAxisMargin=
    // 0xcd3218: add             SP, SP, #0x10
    // 0xcd321c: ldr             x0, [fp, #0x10]
    // 0xcd3220: LoadField: r1 = r0->field_57
    //     0xcd3220: ldur            w1, [x0, #0x57]
    // 0xcd3224: DecompressPointer r1
    //     0xcd3224: add             x1, x1, HEAP, lsl #32
    // 0xcd3228: LoadField: r2 = r1->field_37
    //     0xcd3228: ldur            w2, [x1, #0x37]
    // 0xcd322c: DecompressPointer r2
    //     0xcd322c: add             x2, x2, HEAP, lsl #32
    // 0xcd3230: cmp             w2, NULL
    // 0xcd3234: b.ne            #0xcd3244
    // 0xcd3238: d0 = 48.000000
    //     0xcd3238: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0xcd323c: ldr             d0, [x17, #0xbd0]
    // 0xcd3240: b               #0xcd3248
    // 0xcd3244: LoadField: d0 = r2->field_7
    //     0xcd3244: ldur            d0, [x2, #7]
    // 0xcd3248: ldur            x16, [fp, #-8]
    // 0xcd324c: SaveReg r16
    //     0xcd324c: str             x16, [SP, #-8]!
    // 0xcd3250: SaveReg d0
    //     0xcd3250: str             d0, [SP, #-8]!
    // 0xcd3254: r0 = minLength=()
    //     0xcd3254: bl              #0xcd28ec  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::minLength=
    // 0xcd3258: add             SP, SP, #0x10
    // 0xcd325c: ldr             x0, [fp, #0x10]
    // 0xcd3260: LoadField: r1 = r0->field_f
    //     0xcd3260: ldur            w1, [x0, #0xf]
    // 0xcd3264: DecompressPointer r1
    //     0xcd3264: add             x1, x1, HEAP, lsl #32
    // 0xcd3268: cmp             w1, NULL
    // 0xcd326c: b.eq            #0xcd3354
    // 0xcd3270: SaveReg r1
    //     0xcd3270: str             x1, [SP, #-8]!
    // 0xcd3274: r0 = of()
    //     0xcd3274: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xcd3278: add             SP, SP, #8
    // 0xcd327c: LoadField: r1 = r0->field_23
    //     0xcd327c: ldur            w1, [x0, #0x23]
    // 0xcd3280: DecompressPointer r1
    //     0xcd3280: add             x1, x1, HEAP, lsl #32
    // 0xcd3284: ldur            x16, [fp, #-8]
    // 0xcd3288: stp             x1, x16, [SP, #-0x10]!
    // 0xcd328c: r0 = padding=()
    //     0xcd328c: bl              #0xcd2b60  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::padding=
    // 0xcd3290: add             SP, SP, #0x10
    // 0xcd3294: ldr             x0, [fp, #0x10]
    // 0xcd3298: LoadField: r1 = r0->field_b
    //     0xcd3298: ldur            w1, [x0, #0xb]
    // 0xcd329c: DecompressPointer r1
    //     0xcd329c: add             x1, x1, HEAP, lsl #32
    // 0xcd32a0: cmp             w1, NULL
    // 0xcd32a4: b.eq            #0xcd3358
    // 0xcd32a8: ldur            x16, [fp, #-8]
    // 0xcd32ac: stp             NULL, x16, [SP, #-0x10]!
    // 0xcd32b0: r0 = Shader._()
    //     0xcd32b0: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xcd32b4: add             SP, SP, #0x10
    // 0xcd32b8: ldr             x0, [fp, #0x10]
    // 0xcd32bc: LoadField: r1 = r0->field_b
    //     0xcd32bc: ldur            w1, [x0, #0xb]
    // 0xcd32c0: DecompressPointer r1
    //     0xcd32c0: add             x1, x1, HEAP, lsl #32
    // 0xcd32c4: cmp             w1, NULL
    // 0xcd32c8: b.eq            #0xcd335c
    // 0xcd32cc: LoadField: r1 = r0->field_5b
    //     0xcd32cc: ldur            w1, [x0, #0x5b]
    // 0xcd32d0: DecompressPointer r1
    //     0xcd32d0: add             x1, x1, HEAP, lsl #32
    // 0xcd32d4: r16 = Sentinel
    //     0xcd32d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd32d8: cmp             w1, w16
    // 0xcd32dc: b.eq            #0xcd3360
    // 0xcd32e0: eor             x0, x1, #0x10
    // 0xcd32e4: eor             x1, x0, #0x10
    // 0xcd32e8: ldur            x16, [fp, #-8]
    // 0xcd32ec: stp             x1, x16, [SP, #-0x10]!
    // 0xcd32f0: r0 = ignorePointer=()
    //     0xcd32f0: bl              #0xcd336c  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::ignorePointer=
    // 0xcd32f4: add             SP, SP, #0x10
    // 0xcd32f8: r0 = Null
    //     0xcd32f8: mov             x0, NULL
    // 0xcd32fc: LeaveFrame
    //     0xcd32fc: mov             SP, fp
    //     0xcd3300: ldp             fp, lr, [SP], #0x10
    // 0xcd3304: ret
    //     0xcd3304: ret             
    // 0xcd3308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3308: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd330c: b               #0xcd2f94
    // 0xcd3310: r9 = scrollbarPainter
    //     0xcd3310: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f748] Field <RawScrollbarState.scrollbarPainter>: late final (offset: 0x44)
    //     0xcd3314: ldr             x9, [x9, #0x748]
    // 0xcd3318: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3318: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd331c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd331c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3320: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3324: r9 = _scrollbarTheme
    //     0xcd3324: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd3328: ldr             x9, [x9, #0x7b8]
    // 0xcd332c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd332c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd3330: r9 = _useAndroidScrollbar
    //     0xcd3330: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xcd3334: ldr             x9, [x9, #0x7c0]
    // 0xcd3338: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3338: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd333c: r9 = _scrollbarTheme
    //     0xcd333c: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd3340: ldr             x9, [x9, #0x7b8]
    // 0xcd3344: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3344: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd3348: r9 = _useAndroidScrollbar
    //     0xcd3348: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xcd334c: ldr             x9, [x9, #0x7c0]
    // 0xcd3350: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3350: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd3354: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3354: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3358: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3358: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd335c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd335c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3360: r9 = _useAndroidScrollbar
    //     0xcd3360: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xcd3364: ldr             x9, [x9, #0x7c0]
    // 0xcd3368: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3368: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _thickness(/* No info */) {
    // ** addr: 0xcd33d0, size: 0x60
    // 0xcd33d0: EnterFrame
    //     0xcd33d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd33d4: mov             fp, SP
    // 0xcd33d8: CheckStackOverflow
    //     0xcd33d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd33dc: cmp             SP, x16
    //     0xcd33e0: b.ls            #0xcd3428
    // 0xcd33e4: r1 = 1
    //     0xcd33e4: mov             x1, #1
    // 0xcd33e8: r0 = AllocateContext()
    //     0xcd33e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd33ec: mov             x1, x0
    // 0xcd33f0: ldr             x0, [fp, #0x10]
    // 0xcd33f4: StoreField: r1->field_f = r0
    //     0xcd33f4: stur            w0, [x1, #0xf]
    // 0xcd33f8: mov             x2, x1
    // 0xcd33fc: r1 = Function '<anonymous closure>':.
    //     0xcd33fc: add             x1, PP, #0x50, lsl #12  ; [pp+0x50850] AnonymousClosure: (0xcd3430), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thickness (0xcd33d0)
    //     0xcd3400: ldr             x1, [x1, #0x850]
    // 0xcd3404: r0 = AllocateClosure()
    //     0xcd3404: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd3408: r16 = <double>
    //     0xcd3408: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcd340c: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3410: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd3410: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd3414: r0 = resolveWith()
    //     0xcd3414: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd3418: add             SP, SP, #0x10
    // 0xcd341c: LeaveFrame
    //     0xcd341c: mov             SP, fp
    //     0xcd3420: ldp             fp, lr, [SP], #0x10
    // 0xcd3424: ret
    //     0xcd3424: ret             
    // 0xcd3428: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3428: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd342c: b               #0xcd33e4
  }
  [closure] double <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xcd3430, size: 0x280
    // 0xcd3430: EnterFrame
    //     0xcd3430: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3434: mov             fp, SP
    // 0xcd3438: AllocStack(0x8)
    //     0xcd3438: sub             SP, SP, #8
    // 0xcd343c: SetupParameters()
    //     0xcd343c: ldr             x0, [fp, #0x18]
    //     0xcd3440: ldur            w1, [x0, #0x17]
    //     0xcd3444: add             x1, x1, HEAP, lsl #32
    //     0xcd3448: stur            x1, [fp, #-8]
    // 0xcd344c: CheckStackOverflow
    //     0xcd344c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd3450: cmp             SP, x16
    //     0xcd3454: b.ls            #0xcd365c
    // 0xcd3458: ldr             x2, [fp, #0x10]
    // 0xcd345c: r0 = LoadClassIdInstr(r2)
    //     0xcd345c: ldur            x0, [x2, #-1]
    //     0xcd3460: ubfx            x0, x0, #0xc, #0x14
    // 0xcd3464: r16 = Instance_MaterialState
    //     0xcd3464: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xcd3468: ldr             x16, [x16, #0xf78]
    // 0xcd346c: stp             x16, x2, [SP, #-0x10]!
    // 0xcd3470: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xcd3470: mov             x17, #0xc98a
    //     0xcd3474: add             lr, x0, x17
    //     0xcd3478: ldr             lr, [x21, lr, lsl #3]
    //     0xcd347c: blr             lr
    // 0xcd3480: add             SP, SP, #0x10
    // 0xcd3484: tbnz            w0, #4, #0xcd355c
    // 0xcd3488: ldur            x0, [fp, #-8]
    // 0xcd348c: LoadField: r1 = r0->field_f
    //     0xcd348c: ldur            w1, [x0, #0xf]
    // 0xcd3490: DecompressPointer r1
    //     0xcd3490: add             x1, x1, HEAP, lsl #32
    // 0xcd3494: SaveReg r1
    //     0xcd3494: str             x1, [SP, #-8]!
    // 0xcd3498: r0 = _trackVisibility()
    //     0xcd3498: bl              #0xcd36b0  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility
    // 0xcd349c: add             SP, SP, #8
    // 0xcd34a0: ldr             x16, [fp, #0x10]
    // 0xcd34a4: stp             x16, x0, [SP, #-0x10]!
    // 0xcd34a8: r0 = build()
    //     0xcd34a8: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd34ac: add             SP, SP, #0x10
    // 0xcd34b0: tbnz            w0, #4, #0xcd3554
    // 0xcd34b4: ldur            x0, [fp, #-8]
    // 0xcd34b8: LoadField: r1 = r0->field_f
    //     0xcd34b8: ldur            w1, [x0, #0xf]
    // 0xcd34bc: DecompressPointer r1
    //     0xcd34bc: add             x1, x1, HEAP, lsl #32
    // 0xcd34c0: LoadField: r0 = r1->field_b
    //     0xcd34c0: ldur            w0, [x1, #0xb]
    // 0xcd34c4: DecompressPointer r0
    //     0xcd34c4: add             x0, x0, HEAP, lsl #32
    // 0xcd34c8: cmp             w0, NULL
    // 0xcd34cc: b.eq            #0xcd3664
    // 0xcd34d0: LoadField: r0 = r1->field_57
    //     0xcd34d0: ldur            w0, [x1, #0x57]
    // 0xcd34d4: DecompressPointer r0
    //     0xcd34d4: add             x0, x0, HEAP, lsl #32
    // 0xcd34d8: r16 = Sentinel
    //     0xcd34d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd34dc: cmp             w0, w16
    // 0xcd34e0: b.eq            #0xcd3668
    // 0xcd34e4: LoadField: r1 = r0->field_b
    //     0xcd34e4: ldur            w1, [x0, #0xb]
    // 0xcd34e8: DecompressPointer r1
    //     0xcd34e8: add             x1, x1, HEAP, lsl #32
    // 0xcd34ec: cmp             w1, NULL
    // 0xcd34f0: b.ne            #0xcd34fc
    // 0xcd34f4: r0 = Null
    //     0xcd34f4: mov             x0, NULL
    // 0xcd34f8: b               #0xcd350c
    // 0xcd34fc: ldr             x16, [fp, #0x10]
    // 0xcd3500: stp             x16, x1, [SP, #-0x10]!
    // 0xcd3504: r0 = resolve()
    //     0xcd3504: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd3508: add             SP, SP, #0x10
    // 0xcd350c: cmp             w0, NULL
    // 0xcd3510: b.ne            #0xcd351c
    // 0xcd3514: d0 = 12.000000
    //     0xcd3514: fmov            d0, #12.00000000
    // 0xcd3518: b               #0xcd3520
    // 0xcd351c: LoadField: d0 = r0->field_7
    //     0xcd351c: ldur            d0, [x0, #7]
    // 0xcd3520: r0 = inline_Allocate_Double()
    //     0xcd3520: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd3524: add             x0, x0, #0x10
    //     0xcd3528: cmp             x1, x0
    //     0xcd352c: b.ls            #0xcd3674
    //     0xcd3530: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd3534: sub             x0, x0, #0xf
    //     0xcd3538: mov             x1, #0xd108
    //     0xcd353c: movk            x1, #3, lsl #16
    //     0xcd3540: stur            x1, [x0, #-1]
    // 0xcd3544: StoreField: r0->field_7 = d0
    //     0xcd3544: stur            d0, [x0, #7]
    // 0xcd3548: LeaveFrame
    //     0xcd3548: mov             SP, fp
    //     0xcd354c: ldp             fp, lr, [SP], #0x10
    // 0xcd3550: ret
    //     0xcd3550: ret             
    // 0xcd3554: ldur            x0, [fp, #-8]
    // 0xcd3558: b               #0xcd3560
    // 0xcd355c: ldur            x0, [fp, #-8]
    // 0xcd3560: LoadField: r1 = r0->field_f
    //     0xcd3560: ldur            w1, [x0, #0xf]
    // 0xcd3564: DecompressPointer r1
    //     0xcd3564: add             x1, x1, HEAP, lsl #32
    // 0xcd3568: LoadField: r2 = r1->field_b
    //     0xcd3568: ldur            w2, [x1, #0xb]
    // 0xcd356c: DecompressPointer r2
    //     0xcd356c: add             x2, x2, HEAP, lsl #32
    // 0xcd3570: cmp             w2, NULL
    // 0xcd3574: b.eq            #0xcd3684
    // 0xcd3578: LoadField: r3 = r2->field_23
    //     0xcd3578: ldur            w3, [x2, #0x23]
    // 0xcd357c: DecompressPointer r3
    //     0xcd357c: add             x3, x3, HEAP, lsl #32
    // 0xcd3580: cmp             w3, NULL
    // 0xcd3584: b.ne            #0xcd35cc
    // 0xcd3588: LoadField: r2 = r1->field_57
    //     0xcd3588: ldur            w2, [x1, #0x57]
    // 0xcd358c: DecompressPointer r2
    //     0xcd358c: add             x2, x2, HEAP, lsl #32
    // 0xcd3590: r16 = Sentinel
    //     0xcd3590: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3594: cmp             w2, w16
    // 0xcd3598: b.eq            #0xcd3688
    // 0xcd359c: LoadField: r1 = r2->field_b
    //     0xcd359c: ldur            w1, [x2, #0xb]
    // 0xcd35a0: DecompressPointer r1
    //     0xcd35a0: add             x1, x1, HEAP, lsl #32
    // 0xcd35a4: cmp             w1, NULL
    // 0xcd35a8: b.ne            #0xcd35b4
    // 0xcd35ac: r1 = Null
    //     0xcd35ac: mov             x1, NULL
    // 0xcd35b0: b               #0xcd35d0
    // 0xcd35b4: ldr             x16, [fp, #0x10]
    // 0xcd35b8: stp             x16, x1, [SP, #-0x10]!
    // 0xcd35bc: r0 = resolve()
    //     0xcd35bc: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd35c0: add             SP, SP, #0x10
    // 0xcd35c4: mov             x1, x0
    // 0xcd35c8: b               #0xcd35d0
    // 0xcd35cc: mov             x1, x3
    // 0xcd35d0: cmp             w1, NULL
    // 0xcd35d4: b.ne            #0xcd3624
    // 0xcd35d8: ldur            x2, [fp, #-8]
    // 0xcd35dc: d0 = 8.000000
    //     0xcd35dc: fmov            d0, #8.00000000
    // 0xcd35e0: LoadField: r3 = r2->field_f
    //     0xcd35e0: ldur            w3, [x2, #0xf]
    // 0xcd35e4: DecompressPointer r3
    //     0xcd35e4: add             x3, x3, HEAP, lsl #32
    // 0xcd35e8: LoadField: r2 = r3->field_5b
    //     0xcd35e8: ldur            w2, [x3, #0x5b]
    // 0xcd35ec: DecompressPointer r2
    //     0xcd35ec: add             x2, x2, HEAP, lsl #32
    // 0xcd35f0: r16 = Sentinel
    //     0xcd35f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd35f4: cmp             w2, w16
    // 0xcd35f8: b.eq            #0xcd3694
    // 0xcd35fc: tst             x2, #0x10
    // 0xcd3600: cset            x3, ne
    // 0xcd3604: sub             x3, x3, #1
    // 0xcd3608: and             x3, x3, #2
    // 0xcd360c: add             x3, x3, #2
    // 0xcd3610: r16 = LoadInt32Instr(r3)
    //     0xcd3610: sbfx            x16, x3, #1, #0x1f
    // 0xcd3614: scvtf           d1, w16
    // 0xcd3618: fdiv            d2, d0, d1
    // 0xcd361c: mov             v0.16b, v2.16b
    // 0xcd3620: b               #0xcd3628
    // 0xcd3624: LoadField: d0 = r1->field_7
    //     0xcd3624: ldur            d0, [x1, #7]
    // 0xcd3628: r0 = inline_Allocate_Double()
    //     0xcd3628: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd362c: add             x0, x0, #0x10
    //     0xcd3630: cmp             x1, x0
    //     0xcd3634: b.ls            #0xcd36a0
    //     0xcd3638: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd363c: sub             x0, x0, #0xf
    //     0xcd3640: mov             x1, #0xd108
    //     0xcd3644: movk            x1, #3, lsl #16
    //     0xcd3648: stur            x1, [x0, #-1]
    // 0xcd364c: StoreField: r0->field_7 = d0
    //     0xcd364c: stur            d0, [x0, #7]
    // 0xcd3650: LeaveFrame
    //     0xcd3650: mov             SP, fp
    //     0xcd3654: ldp             fp, lr, [SP], #0x10
    // 0xcd3658: ret
    //     0xcd3658: ret             
    // 0xcd365c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd365c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd3660: b               #0xcd3458
    // 0xcd3664: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3664: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3668: r9 = _scrollbarTheme
    //     0xcd3668: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd366c: ldr             x9, [x9, #0x7b8]
    // 0xcd3670: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3670: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd3674: SaveReg d0
    //     0xcd3674: str             q0, [SP, #-0x10]!
    // 0xcd3678: r0 = AllocateDouble()
    //     0xcd3678: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd367c: RestoreReg d0
    //     0xcd367c: ldr             q0, [SP], #0x10
    // 0xcd3680: b               #0xcd3544
    // 0xcd3684: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3684: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3688: r9 = _scrollbarTheme
    //     0xcd3688: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd368c: ldr             x9, [x9, #0x7b8]
    // 0xcd3690: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3690: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd3694: r9 = _useAndroidScrollbar
    //     0xcd3694: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xcd3698: ldr             x9, [x9, #0x7c0]
    // 0xcd369c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xcd369c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xcd36a0: SaveReg d0
    //     0xcd36a0: str             q0, [SP, #-0x10]!
    // 0xcd36a4: r0 = AllocateDouble()
    //     0xcd36a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd36a8: RestoreReg d0
    //     0xcd36a8: ldr             q0, [SP], #0x10
    // 0xcd36ac: b               #0xcd364c
  }
  get _ _trackVisibility(/* No info */) {
    // ** addr: 0xcd36b0, size: 0x60
    // 0xcd36b0: EnterFrame
    //     0xcd36b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd36b4: mov             fp, SP
    // 0xcd36b8: CheckStackOverflow
    //     0xcd36b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd36bc: cmp             SP, x16
    //     0xcd36c0: b.ls            #0xcd3708
    // 0xcd36c4: r1 = 1
    //     0xcd36c4: mov             x1, #1
    // 0xcd36c8: r0 = AllocateContext()
    //     0xcd36c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd36cc: mov             x1, x0
    // 0xcd36d0: ldr             x0, [fp, #0x10]
    // 0xcd36d4: StoreField: r1->field_f = r0
    //     0xcd36d4: stur            w0, [x1, #0xf]
    // 0xcd36d8: mov             x2, x1
    // 0xcd36dc: r1 = Function '<anonymous closure>':.
    //     0xcd36dc: add             x1, PP, #0x50, lsl #12  ; [pp+0x50858] AnonymousClosure: (0xcd3710), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0xcd36b0)
    //     0xcd36e0: ldr             x1, [x1, #0x858]
    // 0xcd36e4: r0 = AllocateClosure()
    //     0xcd36e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd36e8: r16 = <bool>
    //     0xcd36e8: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xcd36ec: stp             x0, x16, [SP, #-0x10]!
    // 0xcd36f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd36f0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd36f4: r0 = resolveWith()
    //     0xcd36f4: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd36f8: add             SP, SP, #0x10
    // 0xcd36fc: LeaveFrame
    //     0xcd36fc: mov             SP, fp
    //     0xcd3700: ldp             fp, lr, [SP], #0x10
    // 0xcd3704: ret
    //     0xcd3704: ret             
    // 0xcd3708: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3708: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd370c: b               #0xcd36c4
  }
  [closure] bool <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xcd3710, size: 0x104
    // 0xcd3710: EnterFrame
    //     0xcd3710: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3714: mov             fp, SP
    // 0xcd3718: AllocStack(0x8)
    //     0xcd3718: sub             SP, SP, #8
    // 0xcd371c: SetupParameters()
    //     0xcd371c: ldr             x0, [fp, #0x18]
    //     0xcd3720: ldur            w1, [x0, #0x17]
    //     0xcd3724: add             x1, x1, HEAP, lsl #32
    //     0xcd3728: stur            x1, [fp, #-8]
    // 0xcd372c: CheckStackOverflow
    //     0xcd372c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd3730: cmp             SP, x16
    //     0xcd3734: b.ls            #0xcd37fc
    // 0xcd3738: ldr             x2, [fp, #0x10]
    // 0xcd373c: r0 = LoadClassIdInstr(r2)
    //     0xcd373c: ldur            x0, [x2, #-1]
    //     0xcd3740: ubfx            x0, x0, #0xc, #0x14
    // 0xcd3744: r16 = Instance_MaterialState
    //     0xcd3744: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xcd3748: ldr             x16, [x16, #0xf78]
    // 0xcd374c: stp             x16, x2, [SP, #-0x10]!
    // 0xcd3750: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xcd3750: mov             x17, #0xc98a
    //     0xcd3754: add             lr, x0, x17
    //     0xcd3758: ldr             lr, [x21, lr, lsl #3]
    //     0xcd375c: blr             lr
    // 0xcd3760: add             SP, SP, #0x10
    // 0xcd3764: tbnz            w0, #4, #0xcd3780
    // 0xcd3768: ldur            x0, [fp, #-8]
    // 0xcd376c: LoadField: r1 = r0->field_f
    //     0xcd376c: ldur            w1, [x0, #0xf]
    // 0xcd3770: DecompressPointer r1
    //     0xcd3770: add             x1, x1, HEAP, lsl #32
    // 0xcd3774: SaveReg r1
    //     0xcd3774: str             x1, [SP, #-8]!
    // 0xcd3778: r0 = _showTrackOnHover()
    //     0xcd3778: bl              #0xcd3814  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_showTrackOnHover
    // 0xcd377c: add             SP, SP, #8
    // 0xcd3780: ldur            x0, [fp, #-8]
    // 0xcd3784: LoadField: r1 = r0->field_f
    //     0xcd3784: ldur            w1, [x0, #0xf]
    // 0xcd3788: DecompressPointer r1
    //     0xcd3788: add             x1, x1, HEAP, lsl #32
    // 0xcd378c: LoadField: r0 = r1->field_b
    //     0xcd378c: ldur            w0, [x1, #0xb]
    // 0xcd3790: DecompressPointer r0
    //     0xcd3790: add             x0, x0, HEAP, lsl #32
    // 0xcd3794: cmp             w0, NULL
    // 0xcd3798: b.eq            #0xcd3804
    // 0xcd379c: LoadField: r0 = r1->field_57
    //     0xcd379c: ldur            w0, [x1, #0x57]
    // 0xcd37a0: DecompressPointer r0
    //     0xcd37a0: add             x0, x0, HEAP, lsl #32
    // 0xcd37a4: r16 = Sentinel
    //     0xcd37a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd37a8: cmp             w0, w16
    // 0xcd37ac: b.eq            #0xcd3808
    // 0xcd37b0: LoadField: r1 = r0->field_f
    //     0xcd37b0: ldur            w1, [x0, #0xf]
    // 0xcd37b4: DecompressPointer r1
    //     0xcd37b4: add             x1, x1, HEAP, lsl #32
    // 0xcd37b8: cmp             w1, NULL
    // 0xcd37bc: b.ne            #0xcd37c8
    // 0xcd37c0: r1 = Null
    //     0xcd37c0: mov             x1, NULL
    // 0xcd37c4: b               #0xcd37dc
    // 0xcd37c8: ldr             x16, [fp, #0x10]
    // 0xcd37cc: stp             x16, x1, [SP, #-0x10]!
    // 0xcd37d0: r0 = resolve()
    //     0xcd37d0: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd37d4: add             SP, SP, #0x10
    // 0xcd37d8: mov             x1, x0
    // 0xcd37dc: cmp             w1, NULL
    // 0xcd37e0: b.ne            #0xcd37ec
    // 0xcd37e4: r0 = false
    //     0xcd37e4: add             x0, NULL, #0x30  ; false
    // 0xcd37e8: b               #0xcd37f0
    // 0xcd37ec: mov             x0, x1
    // 0xcd37f0: LeaveFrame
    //     0xcd37f0: mov             SP, fp
    //     0xcd37f4: ldp             fp, lr, [SP], #0x10
    // 0xcd37f8: ret
    //     0xcd37f8: ret             
    // 0xcd37fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd37fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd3800: b               #0xcd3738
    // 0xcd3804: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3804: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3808: r9 = _scrollbarTheme
    //     0xcd3808: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd380c: ldr             x9, [x9, #0x7b8]
    // 0xcd3810: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3810: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _showTrackOnHover(/* No info */) {
    // ** addr: 0xcd3814, size: 0x50
    // 0xcd3814: EnterFrame
    //     0xcd3814: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3818: mov             fp, SP
    // 0xcd381c: ldr             x1, [fp, #0x10]
    // 0xcd3820: LoadField: r2 = r1->field_b
    //     0xcd3820: ldur            w2, [x1, #0xb]
    // 0xcd3824: DecompressPointer r2
    //     0xcd3824: add             x2, x2, HEAP, lsl #32
    // 0xcd3828: cmp             w2, NULL
    // 0xcd382c: b.eq            #0xcd3854
    // 0xcd3830: LoadField: r2 = r1->field_57
    //     0xcd3830: ldur            w2, [x1, #0x57]
    // 0xcd3834: DecompressPointer r2
    //     0xcd3834: add             x2, x2, HEAP, lsl #32
    // 0xcd3838: r16 = Sentinel
    //     0xcd3838: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd383c: cmp             w2, w16
    // 0xcd3840: b.eq            #0xcd3858
    // 0xcd3844: r0 = false
    //     0xcd3844: add             x0, NULL, #0x30  ; false
    // 0xcd3848: LeaveFrame
    //     0xcd3848: mov             SP, fp
    //     0xcd384c: ldp             fp, lr, [SP], #0x10
    // 0xcd3850: ret
    //     0xcd3850: ret             
    // 0xcd3854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd3854: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd3858: r9 = _scrollbarTheme
    //     0xcd3858: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd385c: ldr             x9, [x9, #0x7b8]
    // 0xcd3860: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3860: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _trackBorderColor(/* No info */) {
    // ** addr: 0xcd3a0c, size: 0x9c
    // 0xcd3a0c: EnterFrame
    //     0xcd3a0c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3a10: mov             fp, SP
    // 0xcd3a14: CheckStackOverflow
    //     0xcd3a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd3a18: cmp             SP, x16
    //     0xcd3a1c: b.ls            #0xcd3a94
    // 0xcd3a20: r1 = 3
    //     0xcd3a20: mov             x1, #3
    // 0xcd3a24: r0 = AllocateContext()
    //     0xcd3a24: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd3a28: mov             x1, x0
    // 0xcd3a2c: ldr             x0, [fp, #0x10]
    // 0xcd3a30: StoreField: r1->field_f = r0
    //     0xcd3a30: stur            w0, [x1, #0xf]
    // 0xcd3a34: LoadField: r2 = r0->field_53
    //     0xcd3a34: ldur            w2, [x0, #0x53]
    // 0xcd3a38: DecompressPointer r2
    //     0xcd3a38: add             x2, x2, HEAP, lsl #32
    // 0xcd3a3c: r16 = Sentinel
    //     0xcd3a3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3a40: cmp             w2, w16
    // 0xcd3a44: b.eq            #0xcd3a9c
    // 0xcd3a48: LoadField: r0 = r2->field_57
    //     0xcd3a48: ldur            w0, [x2, #0x57]
    // 0xcd3a4c: DecompressPointer r0
    //     0xcd3a4c: add             x0, x0, HEAP, lsl #32
    // 0xcd3a50: StoreField: r1->field_13 = r0
    //     0xcd3a50: stur            w0, [x1, #0x13]
    // 0xcd3a54: LoadField: r0 = r2->field_7
    //     0xcd3a54: ldur            w0, [x2, #7]
    // 0xcd3a58: DecompressPointer r0
    //     0xcd3a58: add             x0, x0, HEAP, lsl #32
    // 0xcd3a5c: StoreField: r1->field_17 = r0
    //     0xcd3a5c: stur            w0, [x1, #0x17]
    // 0xcd3a60: mov             x2, x1
    // 0xcd3a64: r1 = Function '<anonymous closure>':.
    //     0xcd3a64: add             x1, PP, #0x50, lsl #12  ; [pp+0x50860] AnonymousClosure: (0xcd3aa8), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackBorderColor (0xcd3a0c)
    //     0xcd3a68: ldr             x1, [x1, #0x860]
    // 0xcd3a6c: r0 = AllocateClosure()
    //     0xcd3a6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd3a70: r16 = <Color>
    //     0xcd3a70: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd3a74: ldr             x16, [x16, #0x3f8]
    // 0xcd3a78: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3a7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd3a7c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd3a80: r0 = resolveWith()
    //     0xcd3a80: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd3a84: add             SP, SP, #0x10
    // 0xcd3a88: LeaveFrame
    //     0xcd3a88: mov             SP, fp
    //     0xcd3a8c: ldp             fp, lr, [SP], #0x10
    // 0xcd3a90: ret
    //     0xcd3a90: ret             
    // 0xcd3a94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3a94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd3a98: b               #0xcd3a20
    // 0xcd3a9c: r9 = _colorScheme
    //     0xcd3a9c: add             x9, PP, #0x50, lsl #12  ; [pp+0x50868] Field <_MaterialScrollbarState@802083257._colorScheme@802083257>: late (offset: 0x54)
    //     0xcd3aa0: ldr             x9, [x9, #0x868]
    // 0xcd3aa4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3aa4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xcd3aa8, size: 0x180
    // 0xcd3aa8: EnterFrame
    //     0xcd3aa8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3aac: mov             fp, SP
    // 0xcd3ab0: AllocStack(0x10)
    //     0xcd3ab0: sub             SP, SP, #0x10
    // 0xcd3ab4: SetupParameters()
    //     0xcd3ab4: ldr             x0, [fp, #0x18]
    //     0xcd3ab8: ldur            w1, [x0, #0x17]
    //     0xcd3abc: add             x1, x1, HEAP, lsl #32
    //     0xcd3ac0: stur            x1, [fp, #-8]
    // 0xcd3ac4: CheckStackOverflow
    //     0xcd3ac4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd3ac8: cmp             SP, x16
    //     0xcd3acc: b.ls            #0xcd3c14
    // 0xcd3ad0: LoadField: r0 = r1->field_f
    //     0xcd3ad0: ldur            w0, [x1, #0xf]
    // 0xcd3ad4: DecompressPointer r0
    //     0xcd3ad4: add             x0, x0, HEAP, lsl #32
    // 0xcd3ad8: SaveReg r0
    //     0xcd3ad8: str             x0, [SP, #-8]!
    // 0xcd3adc: r0 = showScrollbar()
    //     0xcd3adc: bl              #0xcde6f0  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::showScrollbar
    // 0xcd3ae0: add             SP, SP, #8
    // 0xcd3ae4: tbnz            w0, #4, #0xcd3c00
    // 0xcd3ae8: ldur            x0, [fp, #-8]
    // 0xcd3aec: LoadField: r1 = r0->field_f
    //     0xcd3aec: ldur            w1, [x0, #0xf]
    // 0xcd3af0: DecompressPointer r1
    //     0xcd3af0: add             x1, x1, HEAP, lsl #32
    // 0xcd3af4: stur            x1, [fp, #-0x10]
    // 0xcd3af8: r1 = 1
    //     0xcd3af8: mov             x1, #1
    // 0xcd3afc: r0 = AllocateContext()
    //     0xcd3afc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd3b00: mov             x1, x0
    // 0xcd3b04: ldur            x0, [fp, #-0x10]
    // 0xcd3b08: StoreField: r1->field_f = r0
    //     0xcd3b08: stur            w0, [x1, #0xf]
    // 0xcd3b0c: mov             x2, x1
    // 0xcd3b10: r1 = Function '<anonymous closure>':.
    //     0xcd3b10: add             x1, PP, #0x50, lsl #12  ; [pp+0x50858] AnonymousClosure: (0xcd3710), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0xcd36b0)
    //     0xcd3b14: ldr             x1, [x1, #0x858]
    // 0xcd3b18: r0 = AllocateClosure()
    //     0xcd3b18: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd3b1c: r16 = <bool>
    //     0xcd3b1c: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xcd3b20: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3b24: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd3b24: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd3b28: r0 = resolveWith()
    //     0xcd3b28: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd3b2c: add             SP, SP, #0x10
    // 0xcd3b30: ldr             x16, [fp, #0x10]
    // 0xcd3b34: stp             x16, x0, [SP, #-0x10]!
    // 0xcd3b38: r0 = build()
    //     0xcd3b38: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd3b3c: add             SP, SP, #0x10
    // 0xcd3b40: tbnz            w0, #4, #0xcd3c00
    // 0xcd3b44: ldur            x0, [fp, #-8]
    // 0xcd3b48: LoadField: r1 = r0->field_f
    //     0xcd3b48: ldur            w1, [x0, #0xf]
    // 0xcd3b4c: DecompressPointer r1
    //     0xcd3b4c: add             x1, x1, HEAP, lsl #32
    // 0xcd3b50: LoadField: r2 = r1->field_57
    //     0xcd3b50: ldur            w2, [x1, #0x57]
    // 0xcd3b54: DecompressPointer r2
    //     0xcd3b54: add             x2, x2, HEAP, lsl #32
    // 0xcd3b58: r16 = Sentinel
    //     0xcd3b58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3b5c: cmp             w2, w16
    // 0xcd3b60: b.eq            #0xcd3c1c
    // 0xcd3b64: LoadField: r1 = r2->field_2b
    //     0xcd3b64: ldur            w1, [x2, #0x2b]
    // 0xcd3b68: DecompressPointer r1
    //     0xcd3b68: add             x1, x1, HEAP, lsl #32
    // 0xcd3b6c: cmp             w1, NULL
    // 0xcd3b70: b.ne            #0xcd3b7c
    // 0xcd3b74: r0 = Null
    //     0xcd3b74: mov             x0, NULL
    // 0xcd3b78: b               #0xcd3b8c
    // 0xcd3b7c: ldr             x16, [fp, #0x10]
    // 0xcd3b80: stp             x16, x1, [SP, #-0x10]!
    // 0xcd3b84: r0 = resolve()
    //     0xcd3b84: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd3b88: add             SP, SP, #0x10
    // 0xcd3b8c: cmp             w0, NULL
    // 0xcd3b90: b.ne            #0xcd3bf4
    // 0xcd3b94: ldur            x0, [fp, #-8]
    // 0xcd3b98: LoadField: r1 = r0->field_17
    //     0xcd3b98: ldur            w1, [x0, #0x17]
    // 0xcd3b9c: DecompressPointer r1
    //     0xcd3b9c: add             x1, x1, HEAP, lsl #32
    // 0xcd3ba0: r16 = Instance_Brightness
    //     0xcd3ba0: ldr             x16, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0xcd3ba4: cmp             w1, w16
    // 0xcd3ba8: b.ne            #0xcd3bd0
    // 0xcd3bac: d0 = 0.100000
    //     0xcd3bac: ldr             d0, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0xcd3bb0: LoadField: r1 = r0->field_13
    //     0xcd3bb0: ldur            w1, [x0, #0x13]
    // 0xcd3bb4: DecompressPointer r1
    //     0xcd3bb4: add             x1, x1, HEAP, lsl #32
    // 0xcd3bb8: SaveReg r1
    //     0xcd3bb8: str             x1, [SP, #-8]!
    // 0xcd3bbc: SaveReg d0
    //     0xcd3bbc: str             d0, [SP, #-8]!
    // 0xcd3bc0: r0 = withOpacity()
    //     0xcd3bc0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd3bc4: add             SP, SP, #0x10
    // 0xcd3bc8: mov             x1, x0
    // 0xcd3bcc: b               #0xcd3bf0
    // 0xcd3bd0: d0 = 0.250000
    //     0xcd3bd0: fmov            d0, #0.25000000
    // 0xcd3bd4: LoadField: r1 = r0->field_13
    //     0xcd3bd4: ldur            w1, [x0, #0x13]
    // 0xcd3bd8: DecompressPointer r1
    //     0xcd3bd8: add             x1, x1, HEAP, lsl #32
    // 0xcd3bdc: SaveReg r1
    //     0xcd3bdc: str             x1, [SP, #-8]!
    // 0xcd3be0: SaveReg d0
    //     0xcd3be0: str             d0, [SP, #-8]!
    // 0xcd3be4: r0 = withOpacity()
    //     0xcd3be4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd3be8: add             SP, SP, #0x10
    // 0xcd3bec: mov             x1, x0
    // 0xcd3bf0: mov             x0, x1
    // 0xcd3bf4: LeaveFrame
    //     0xcd3bf4: mov             SP, fp
    //     0xcd3bf8: ldp             fp, lr, [SP], #0x10
    // 0xcd3bfc: ret
    //     0xcd3bfc: ret             
    // 0xcd3c00: r0 = Instance_Color
    //     0xcd3c00: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xcd3c04: ldr             x0, [x0, #0xc08]
    // 0xcd3c08: LeaveFrame
    //     0xcd3c08: mov             SP, fp
    //     0xcd3c0c: ldp             fp, lr, [SP], #0x10
    // 0xcd3c10: ret
    //     0xcd3c10: ret             
    // 0xcd3c14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3c14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd3c18: b               #0xcd3ad0
    // 0xcd3c1c: r9 = _scrollbarTheme
    //     0xcd3c1c: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd3c20: ldr             x9, [x9, #0x7b8]
    // 0xcd3c24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3c24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _trackColor(/* No info */) {
    // ** addr: 0xcd3dd0, size: 0x9c
    // 0xcd3dd0: EnterFrame
    //     0xcd3dd0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3dd4: mov             fp, SP
    // 0xcd3dd8: CheckStackOverflow
    //     0xcd3dd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd3ddc: cmp             SP, x16
    //     0xcd3de0: b.ls            #0xcd3e58
    // 0xcd3de4: r1 = 3
    //     0xcd3de4: mov             x1, #3
    // 0xcd3de8: r0 = AllocateContext()
    //     0xcd3de8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd3dec: mov             x1, x0
    // 0xcd3df0: ldr             x0, [fp, #0x10]
    // 0xcd3df4: StoreField: r1->field_f = r0
    //     0xcd3df4: stur            w0, [x1, #0xf]
    // 0xcd3df8: LoadField: r2 = r0->field_53
    //     0xcd3df8: ldur            w2, [x0, #0x53]
    // 0xcd3dfc: DecompressPointer r2
    //     0xcd3dfc: add             x2, x2, HEAP, lsl #32
    // 0xcd3e00: r16 = Sentinel
    //     0xcd3e00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3e04: cmp             w2, w16
    // 0xcd3e08: b.eq            #0xcd3e60
    // 0xcd3e0c: LoadField: r0 = r2->field_57
    //     0xcd3e0c: ldur            w0, [x2, #0x57]
    // 0xcd3e10: DecompressPointer r0
    //     0xcd3e10: add             x0, x0, HEAP, lsl #32
    // 0xcd3e14: StoreField: r1->field_13 = r0
    //     0xcd3e14: stur            w0, [x1, #0x13]
    // 0xcd3e18: LoadField: r0 = r2->field_7
    //     0xcd3e18: ldur            w0, [x2, #7]
    // 0xcd3e1c: DecompressPointer r0
    //     0xcd3e1c: add             x0, x0, HEAP, lsl #32
    // 0xcd3e20: StoreField: r1->field_17 = r0
    //     0xcd3e20: stur            w0, [x1, #0x17]
    // 0xcd3e24: mov             x2, x1
    // 0xcd3e28: r1 = Function '<anonymous closure>':.
    //     0xcd3e28: add             x1, PP, #0x50, lsl #12  ; [pp+0x50870] AnonymousClosure: (0xcd3e6c), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackColor (0xcd3dd0)
    //     0xcd3e2c: ldr             x1, [x1, #0x870]
    // 0xcd3e30: r0 = AllocateClosure()
    //     0xcd3e30: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd3e34: r16 = <Color>
    //     0xcd3e34: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd3e38: ldr             x16, [x16, #0x3f8]
    // 0xcd3e3c: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3e40: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd3e40: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd3e44: r0 = resolveWith()
    //     0xcd3e44: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd3e48: add             SP, SP, #0x10
    // 0xcd3e4c: LeaveFrame
    //     0xcd3e4c: mov             SP, fp
    //     0xcd3e50: ldp             fp, lr, [SP], #0x10
    // 0xcd3e54: ret
    //     0xcd3e54: ret             
    // 0xcd3e58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3e58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd3e5c: b               #0xcd3de4
    // 0xcd3e60: r9 = _colorScheme
    //     0xcd3e60: add             x9, PP, #0x50, lsl #12  ; [pp+0x50868] Field <_MaterialScrollbarState@802083257._colorScheme@802083257>: late (offset: 0x54)
    //     0xcd3e64: ldr             x9, [x9, #0x868]
    // 0xcd3e68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3e68: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xcd3e6c, size: 0x188
    // 0xcd3e6c: EnterFrame
    //     0xcd3e6c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3e70: mov             fp, SP
    // 0xcd3e74: AllocStack(0x10)
    //     0xcd3e74: sub             SP, SP, #0x10
    // 0xcd3e78: SetupParameters()
    //     0xcd3e78: ldr             x0, [fp, #0x18]
    //     0xcd3e7c: ldur            w1, [x0, #0x17]
    //     0xcd3e80: add             x1, x1, HEAP, lsl #32
    //     0xcd3e84: stur            x1, [fp, #-8]
    // 0xcd3e88: CheckStackOverflow
    //     0xcd3e88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd3e8c: cmp             SP, x16
    //     0xcd3e90: b.ls            #0xcd3fe0
    // 0xcd3e94: LoadField: r0 = r1->field_f
    //     0xcd3e94: ldur            w0, [x1, #0xf]
    // 0xcd3e98: DecompressPointer r0
    //     0xcd3e98: add             x0, x0, HEAP, lsl #32
    // 0xcd3e9c: SaveReg r0
    //     0xcd3e9c: str             x0, [SP, #-8]!
    // 0xcd3ea0: r0 = showScrollbar()
    //     0xcd3ea0: bl              #0xcde6f0  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::showScrollbar
    // 0xcd3ea4: add             SP, SP, #8
    // 0xcd3ea8: tbnz            w0, #4, #0xcd3fcc
    // 0xcd3eac: ldur            x0, [fp, #-8]
    // 0xcd3eb0: LoadField: r1 = r0->field_f
    //     0xcd3eb0: ldur            w1, [x0, #0xf]
    // 0xcd3eb4: DecompressPointer r1
    //     0xcd3eb4: add             x1, x1, HEAP, lsl #32
    // 0xcd3eb8: stur            x1, [fp, #-0x10]
    // 0xcd3ebc: r1 = 1
    //     0xcd3ebc: mov             x1, #1
    // 0xcd3ec0: r0 = AllocateContext()
    //     0xcd3ec0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd3ec4: mov             x1, x0
    // 0xcd3ec8: ldur            x0, [fp, #-0x10]
    // 0xcd3ecc: StoreField: r1->field_f = r0
    //     0xcd3ecc: stur            w0, [x1, #0xf]
    // 0xcd3ed0: mov             x2, x1
    // 0xcd3ed4: r1 = Function '<anonymous closure>':.
    //     0xcd3ed4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50858] AnonymousClosure: (0xcd3710), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0xcd36b0)
    //     0xcd3ed8: ldr             x1, [x1, #0x858]
    // 0xcd3edc: r0 = AllocateClosure()
    //     0xcd3edc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd3ee0: r16 = <bool>
    //     0xcd3ee0: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xcd3ee4: stp             x0, x16, [SP, #-0x10]!
    // 0xcd3ee8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd3ee8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd3eec: r0 = resolveWith()
    //     0xcd3eec: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd3ef0: add             SP, SP, #0x10
    // 0xcd3ef4: ldr             x16, [fp, #0x10]
    // 0xcd3ef8: stp             x16, x0, [SP, #-0x10]!
    // 0xcd3efc: r0 = build()
    //     0xcd3efc: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd3f00: add             SP, SP, #0x10
    // 0xcd3f04: tbnz            w0, #4, #0xcd3fcc
    // 0xcd3f08: ldur            x0, [fp, #-8]
    // 0xcd3f0c: LoadField: r1 = r0->field_f
    //     0xcd3f0c: ldur            w1, [x0, #0xf]
    // 0xcd3f10: DecompressPointer r1
    //     0xcd3f10: add             x1, x1, HEAP, lsl #32
    // 0xcd3f14: LoadField: r2 = r1->field_57
    //     0xcd3f14: ldur            w2, [x1, #0x57]
    // 0xcd3f18: DecompressPointer r2
    //     0xcd3f18: add             x2, x2, HEAP, lsl #32
    // 0xcd3f1c: r16 = Sentinel
    //     0xcd3f1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd3f20: cmp             w2, w16
    // 0xcd3f24: b.eq            #0xcd3fe8
    // 0xcd3f28: LoadField: r1 = r2->field_27
    //     0xcd3f28: ldur            w1, [x2, #0x27]
    // 0xcd3f2c: DecompressPointer r1
    //     0xcd3f2c: add             x1, x1, HEAP, lsl #32
    // 0xcd3f30: cmp             w1, NULL
    // 0xcd3f34: b.ne            #0xcd3f40
    // 0xcd3f38: r0 = Null
    //     0xcd3f38: mov             x0, NULL
    // 0xcd3f3c: b               #0xcd3f50
    // 0xcd3f40: ldr             x16, [fp, #0x10]
    // 0xcd3f44: stp             x16, x1, [SP, #-0x10]!
    // 0xcd3f48: r0 = resolve()
    //     0xcd3f48: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd3f4c: add             SP, SP, #0x10
    // 0xcd3f50: cmp             w0, NULL
    // 0xcd3f54: b.ne            #0xcd3fc0
    // 0xcd3f58: ldur            x0, [fp, #-8]
    // 0xcd3f5c: LoadField: r1 = r0->field_17
    //     0xcd3f5c: ldur            w1, [x0, #0x17]
    // 0xcd3f60: DecompressPointer r1
    //     0xcd3f60: add             x1, x1, HEAP, lsl #32
    // 0xcd3f64: r16 = Instance_Brightness
    //     0xcd3f64: ldr             x16, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0xcd3f68: cmp             w1, w16
    // 0xcd3f6c: b.ne            #0xcd3f98
    // 0xcd3f70: d0 = 0.030000
    //     0xcd3f70: add             x17, PP, #0x50, lsl #12  ; [pp+0x50878] IMM: double(0.03) from 0x3f9eb851eb851eb8
    //     0xcd3f74: ldr             d0, [x17, #0x878]
    // 0xcd3f78: LoadField: r1 = r0->field_13
    //     0xcd3f78: ldur            w1, [x0, #0x13]
    // 0xcd3f7c: DecompressPointer r1
    //     0xcd3f7c: add             x1, x1, HEAP, lsl #32
    // 0xcd3f80: SaveReg r1
    //     0xcd3f80: str             x1, [SP, #-8]!
    // 0xcd3f84: SaveReg d0
    //     0xcd3f84: str             d0, [SP, #-8]!
    // 0xcd3f88: r0 = withOpacity()
    //     0xcd3f88: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd3f8c: add             SP, SP, #0x10
    // 0xcd3f90: mov             x1, x0
    // 0xcd3f94: b               #0xcd3fbc
    // 0xcd3f98: d0 = 0.050000
    //     0xcd3f98: add             x17, PP, #0xd, lsl #12  ; [pp+0xd208] IMM: double(0.05) from 0x3fa999999999999a
    //     0xcd3f9c: ldr             d0, [x17, #0x208]
    // 0xcd3fa0: LoadField: r1 = r0->field_13
    //     0xcd3fa0: ldur            w1, [x0, #0x13]
    // 0xcd3fa4: DecompressPointer r1
    //     0xcd3fa4: add             x1, x1, HEAP, lsl #32
    // 0xcd3fa8: SaveReg r1
    //     0xcd3fa8: str             x1, [SP, #-8]!
    // 0xcd3fac: SaveReg d0
    //     0xcd3fac: str             d0, [SP, #-8]!
    // 0xcd3fb0: r0 = withOpacity()
    //     0xcd3fb0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd3fb4: add             SP, SP, #0x10
    // 0xcd3fb8: mov             x1, x0
    // 0xcd3fbc: mov             x0, x1
    // 0xcd3fc0: LeaveFrame
    //     0xcd3fc0: mov             SP, fp
    //     0xcd3fc4: ldp             fp, lr, [SP], #0x10
    // 0xcd3fc8: ret
    //     0xcd3fc8: ret             
    // 0xcd3fcc: r0 = Instance_Color
    //     0xcd3fcc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xcd3fd0: ldr             x0, [x0, #0xc08]
    // 0xcd3fd4: LeaveFrame
    //     0xcd3fd4: mov             SP, fp
    //     0xcd3fd8: ldp             fp, lr, [SP], #0x10
    // 0xcd3fdc: ret
    //     0xcd3fdc: ret             
    // 0xcd3fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd3fe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd3fe4: b               #0xcd3e94
    // 0xcd3fe8: r9 = _scrollbarTheme
    //     0xcd3fe8: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd3fec: ldr             x9, [x9, #0x7b8]
    // 0xcd3ff0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd3ff0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _states(/* No info */) {
    // ** addr: 0xcd3ff4, size: 0xec
    // 0xcd3ff4: EnterFrame
    //     0xcd3ff4: stp             fp, lr, [SP, #-0x10]!
    //     0xcd3ff8: mov             fp, SP
    // 0xcd3ffc: AllocStack(0x10)
    //     0xcd3ffc: sub             SP, SP, #0x10
    // 0xcd4000: CheckStackOverflow
    //     0xcd4000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd4004: cmp             SP, x16
    //     0xcd4008: b.ls            #0xcd40d8
    // 0xcd400c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcd400c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcd4010: ldr             x0, [x0, #0x598]
    //     0xcd4014: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcd4018: cmp             w0, w16
    //     0xcd401c: b.ne            #0xcd4028
    //     0xcd4020: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcd4024: bl              #0xd67cdc
    // 0xcd4028: r1 = <MaterialState>
    //     0xcd4028: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0xcd402c: ldr             x1, [x1, #0xcf0]
    // 0xcd4030: stur            x0, [fp, #-8]
    // 0xcd4034: r0 = _Set()
    //     0xcd4034: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xcd4038: mov             x1, x0
    // 0xcd403c: ldur            x0, [fp, #-8]
    // 0xcd4040: stur            x1, [fp, #-0x10]
    // 0xcd4044: StoreField: r1->field_1b = r0
    //     0xcd4044: stur            w0, [x1, #0x1b]
    // 0xcd4048: StoreField: r1->field_b = rZR
    //     0xcd4048: stur            wzr, [x1, #0xb]
    // 0xcd404c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcd404c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcd4050: ldr             x0, [x0, #0x5a0]
    //     0xcd4054: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcd4058: cmp             w0, w16
    //     0xcd405c: b.ne            #0xcd4068
    //     0xcd4060: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcd4064: bl              #0xd67cdc
    // 0xcd4068: mov             x1, x0
    // 0xcd406c: ldur            x0, [fp, #-0x10]
    // 0xcd4070: StoreField: r0->field_f = r1
    //     0xcd4070: stur            w1, [x0, #0xf]
    // 0xcd4074: StoreField: r0->field_13 = rZR
    //     0xcd4074: stur            wzr, [x0, #0x13]
    // 0xcd4078: StoreField: r0->field_17 = rZR
    //     0xcd4078: stur            wzr, [x0, #0x17]
    // 0xcd407c: ldr             x1, [fp, #0x10]
    // 0xcd4080: LoadField: r2 = r1->field_4b
    //     0xcd4080: ldur            w2, [x1, #0x4b]
    // 0xcd4084: DecompressPointer r2
    //     0xcd4084: add             x2, x2, HEAP, lsl #32
    // 0xcd4088: tbnz            w2, #4, #0xcd40a0
    // 0xcd408c: r16 = Instance_MaterialState
    //     0xcd408c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe170] Obj!MaterialState@b654f1
    //     0xcd4090: ldr             x16, [x16, #0x170]
    // 0xcd4094: stp             x16, x0, [SP, #-0x10]!
    // 0xcd4098: r0 = add()
    //     0xcd4098: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xcd409c: add             SP, SP, #0x10
    // 0xcd40a0: ldr             x0, [fp, #0x10]
    // 0xcd40a4: LoadField: r1 = r0->field_4f
    //     0xcd40a4: ldur            w1, [x0, #0x4f]
    // 0xcd40a8: DecompressPointer r1
    //     0xcd40a8: add             x1, x1, HEAP, lsl #32
    // 0xcd40ac: tbnz            w1, #4, #0xcd40c8
    // 0xcd40b0: ldur            x16, [fp, #-0x10]
    // 0xcd40b4: r30 = Instance_MaterialState
    //     0xcd40b4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xcd40b8: ldr             lr, [lr, #0xf78]
    // 0xcd40bc: stp             lr, x16, [SP, #-0x10]!
    // 0xcd40c0: r0 = add()
    //     0xcd40c0: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0xcd40c4: add             SP, SP, #0x10
    // 0xcd40c8: ldur            x0, [fp, #-0x10]
    // 0xcd40cc: LeaveFrame
    //     0xcd40cc: mov             SP, fp
    //     0xcd40d0: ldp             fp, lr, [SP], #0x10
    // 0xcd40d4: ret
    //     0xcd40d4: ret             
    // 0xcd40d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd40d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd40dc: b               #0xcd400c
  }
  get _ _thumbColor(/* No info */) {
    // ** addr: 0xcd40e0, size: 0x2ec
    // 0xcd40e0: EnterFrame
    //     0xcd40e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd40e4: mov             fp, SP
    // 0xcd40e8: AllocStack(0x10)
    //     0xcd40e8: sub             SP, SP, #0x10
    // 0xcd40ec: CheckStackOverflow
    //     0xcd40ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd40f0: cmp             SP, x16
    //     0xcd40f4: b.ls            #0xcd4398
    // 0xcd40f8: r1 = 4
    //     0xcd40f8: mov             x1, #4
    // 0xcd40fc: r0 = AllocateContext()
    //     0xcd40fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd4100: mov             x1, x0
    // 0xcd4104: ldr             x0, [fp, #0x10]
    // 0xcd4108: stur            x1, [fp, #-0x10]
    // 0xcd410c: StoreField: r1->field_f = r0
    //     0xcd410c: stur            w0, [x1, #0xf]
    // 0xcd4110: LoadField: r2 = r0->field_53
    //     0xcd4110: ldur            w2, [x0, #0x53]
    // 0xcd4114: DecompressPointer r2
    //     0xcd4114: add             x2, x2, HEAP, lsl #32
    // 0xcd4118: r16 = Sentinel
    //     0xcd4118: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd411c: cmp             w2, w16
    // 0xcd4120: b.eq            #0xcd43a0
    // 0xcd4124: LoadField: r3 = r2->field_57
    //     0xcd4124: ldur            w3, [x2, #0x57]
    // 0xcd4128: DecompressPointer r3
    //     0xcd4128: add             x3, x3, HEAP, lsl #32
    // 0xcd412c: stur            x3, [fp, #-8]
    // 0xcd4130: LoadField: r4 = r2->field_7
    //     0xcd4130: ldur            w4, [x2, #7]
    // 0xcd4134: DecompressPointer r4
    //     0xcd4134: add             x4, x4, HEAP, lsl #32
    // 0xcd4138: r2 = Sentinel
    //     0xcd4138: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd413c: StoreField: r1->field_13 = r2
    //     0xcd413c: stur            w2, [x1, #0x13]
    // 0xcd4140: StoreField: r1->field_17 = r2
    //     0xcd4140: stur            w2, [x1, #0x17]
    // 0xcd4144: StoreField: r1->field_1b = r2
    //     0xcd4144: stur            w2, [x1, #0x1b]
    // 0xcd4148: LoadField: r2 = r4->field_7
    //     0xcd4148: ldur            x2, [x4, #7]
    // 0xcd414c: cmp             x2, #0
    // 0xcd4150: b.gt            #0xcd425c
    // 0xcd4154: d0 = 0.750000
    //     0xcd4154: fmov            d0, #0.75000000
    // 0xcd4158: SaveReg r3
    //     0xcd4158: str             x3, [SP, #-8]!
    // 0xcd415c: SaveReg d0
    //     0xcd415c: str             d0, [SP, #-8]!
    // 0xcd4160: r0 = withOpacity()
    //     0xcd4160: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd4164: add             SP, SP, #0x10
    // 0xcd4168: ldur            x2, [fp, #-0x10]
    // 0xcd416c: StoreField: r2->field_13 = r0
    //     0xcd416c: stur            w0, [x2, #0x13]
    //     0xcd4170: ldurb           w16, [x2, #-1]
    //     0xcd4174: ldurb           w17, [x0, #-1]
    //     0xcd4178: and             x16, x17, x16, lsr #2
    //     0xcd417c: tst             x16, HEAP, lsr #32
    //     0xcd4180: b.eq            #0xcd4188
    //     0xcd4184: bl              #0xd6828c
    // 0xcd4188: ldur            x16, [fp, #-8]
    // 0xcd418c: SaveReg r16
    //     0xcd418c: str             x16, [SP, #-8]!
    // 0xcd4190: d0 = 0.650000
    //     0xcd4190: add             x17, PP, #0x50, lsl #12  ; [pp+0x50880] IMM: double(0.65) from 0x3fe4cccccccccccd
    //     0xcd4194: ldr             d0, [x17, #0x880]
    // 0xcd4198: SaveReg d0
    //     0xcd4198: str             d0, [SP, #-8]!
    // 0xcd419c: r0 = withOpacity()
    //     0xcd419c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd41a0: add             SP, SP, #0x10
    // 0xcd41a4: ldur            x2, [fp, #-0x10]
    // 0xcd41a8: StoreField: r2->field_17 = r0
    //     0xcd41a8: stur            w0, [x2, #0x17]
    //     0xcd41ac: ldurb           w16, [x2, #-1]
    //     0xcd41b0: ldurb           w17, [x0, #-1]
    //     0xcd41b4: and             x16, x17, x16, lsr #2
    //     0xcd41b8: tst             x16, HEAP, lsr #32
    //     0xcd41bc: b.eq            #0xcd41c4
    //     0xcd41c0: bl              #0xd6828c
    // 0xcd41c4: ldr             x0, [fp, #0x10]
    // 0xcd41c8: LoadField: r1 = r0->field_5b
    //     0xcd41c8: ldur            w1, [x0, #0x5b]
    // 0xcd41cc: DecompressPointer r1
    //     0xcd41cc: add             x1, x1, HEAP, lsl #32
    // 0xcd41d0: r16 = Sentinel
    //     0xcd41d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd41d4: cmp             w1, w16
    // 0xcd41d8: b.eq            #0xcd43ac
    // 0xcd41dc: tbnz            w1, #4, #0xcd421c
    // 0xcd41e0: LoadField: r1 = r0->field_f
    //     0xcd41e0: ldur            w1, [x0, #0xf]
    // 0xcd41e4: DecompressPointer r1
    //     0xcd41e4: add             x1, x1, HEAP, lsl #32
    // 0xcd41e8: cmp             w1, NULL
    // 0xcd41ec: b.eq            #0xcd43b8
    // 0xcd41f0: SaveReg r1
    //     0xcd41f0: str             x1, [SP, #-8]!
    // 0xcd41f4: r0 = of()
    //     0xcd41f4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcd41f8: add             SP, SP, #8
    // 0xcd41fc: LoadField: r1 = r0->field_53
    //     0xcd41fc: ldur            w1, [x0, #0x53]
    // 0xcd4200: DecompressPointer r1
    //     0xcd4200: add             x1, x1, HEAP, lsl #32
    // 0xcd4204: SaveReg r1
    //     0xcd4204: str             x1, [SP, #-8]!
    // 0xcd4208: d0 = 1.000000
    //     0xcd4208: fmov            d0, #1.00000000
    // 0xcd420c: SaveReg d0
    //     0xcd420c: str             d0, [SP, #-8]!
    // 0xcd4210: r0 = withOpacity()
    //     0xcd4210: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd4214: add             SP, SP, #0x10
    // 0xcd4218: b               #0xcd4238
    // 0xcd421c: d0 = 0.300000
    //     0xcd421c: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c4f8] IMM: double(0.3) from 0x3fd3333333333333
    //     0xcd4220: ldr             d0, [x17, #0x4f8]
    // 0xcd4224: ldur            x16, [fp, #-8]
    // 0xcd4228: SaveReg r16
    //     0xcd4228: str             x16, [SP, #-8]!
    // 0xcd422c: SaveReg d0
    //     0xcd422c: str             d0, [SP, #-8]!
    // 0xcd4230: r0 = withOpacity()
    //     0xcd4230: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd4234: add             SP, SP, #0x10
    // 0xcd4238: ldur            x2, [fp, #-0x10]
    // 0xcd423c: StoreField: r2->field_1b = r0
    //     0xcd423c: stur            w0, [x2, #0x1b]
    //     0xcd4240: ldurb           w16, [x2, #-1]
    //     0xcd4244: ldurb           w17, [x0, #-1]
    //     0xcd4248: and             x16, x17, x16, lsr #2
    //     0xcd424c: tst             x16, HEAP, lsr #32
    //     0xcd4250: b.eq            #0xcd4258
    //     0xcd4254: bl              #0xd6828c
    // 0xcd4258: b               #0xcd4368
    // 0xcd425c: mov             x2, x1
    // 0xcd4260: d0 = 1.000000
    //     0xcd4260: fmov            d0, #1.00000000
    // 0xcd4264: d1 = 0.600000
    //     0xcd4264: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0xcd4268: ldr             d1, [x17, #0xf90]
    // 0xcd426c: ldur            x16, [fp, #-8]
    // 0xcd4270: SaveReg r16
    //     0xcd4270: str             x16, [SP, #-8]!
    // 0xcd4274: SaveReg d1
    //     0xcd4274: str             d1, [SP, #-8]!
    // 0xcd4278: r0 = withOpacity()
    //     0xcd4278: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd427c: add             SP, SP, #0x10
    // 0xcd4280: ldur            x2, [fp, #-0x10]
    // 0xcd4284: StoreField: r2->field_13 = r0
    //     0xcd4284: stur            w0, [x2, #0x13]
    //     0xcd4288: ldurb           w16, [x2, #-1]
    //     0xcd428c: ldurb           w17, [x0, #-1]
    //     0xcd4290: and             x16, x17, x16, lsr #2
    //     0xcd4294: tst             x16, HEAP, lsr #32
    //     0xcd4298: b.eq            #0xcd42a0
    //     0xcd429c: bl              #0xd6828c
    // 0xcd42a0: ldur            x16, [fp, #-8]
    // 0xcd42a4: SaveReg r16
    //     0xcd42a4: str             x16, [SP, #-8]!
    // 0xcd42a8: d0 = 0.500000
    //     0xcd42a8: fmov            d0, #0.50000000
    // 0xcd42ac: SaveReg d0
    //     0xcd42ac: str             d0, [SP, #-8]!
    // 0xcd42b0: r0 = withOpacity()
    //     0xcd42b0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd42b4: add             SP, SP, #0x10
    // 0xcd42b8: ldur            x2, [fp, #-0x10]
    // 0xcd42bc: StoreField: r2->field_17 = r0
    //     0xcd42bc: stur            w0, [x2, #0x17]
    //     0xcd42c0: ldurb           w16, [x2, #-1]
    //     0xcd42c4: ldurb           w17, [x0, #-1]
    //     0xcd42c8: and             x16, x17, x16, lsr #2
    //     0xcd42cc: tst             x16, HEAP, lsr #32
    //     0xcd42d0: b.eq            #0xcd42d8
    //     0xcd42d4: bl              #0xd6828c
    // 0xcd42d8: ldr             x0, [fp, #0x10]
    // 0xcd42dc: LoadField: r1 = r0->field_5b
    //     0xcd42dc: ldur            w1, [x0, #0x5b]
    // 0xcd42e0: DecompressPointer r1
    //     0xcd42e0: add             x1, x1, HEAP, lsl #32
    // 0xcd42e4: r16 = Sentinel
    //     0xcd42e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd42e8: cmp             w1, w16
    // 0xcd42ec: b.eq            #0xcd43bc
    // 0xcd42f0: tbnz            w1, #4, #0xcd4330
    // 0xcd42f4: LoadField: r1 = r0->field_f
    //     0xcd42f4: ldur            w1, [x0, #0xf]
    // 0xcd42f8: DecompressPointer r1
    //     0xcd42f8: add             x1, x1, HEAP, lsl #32
    // 0xcd42fc: cmp             w1, NULL
    // 0xcd4300: b.eq            #0xcd43c8
    // 0xcd4304: SaveReg r1
    //     0xcd4304: str             x1, [SP, #-8]!
    // 0xcd4308: r0 = of()
    //     0xcd4308: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcd430c: add             SP, SP, #8
    // 0xcd4310: LoadField: r1 = r0->field_53
    //     0xcd4310: ldur            w1, [x0, #0x53]
    // 0xcd4314: DecompressPointer r1
    //     0xcd4314: add             x1, x1, HEAP, lsl #32
    // 0xcd4318: SaveReg r1
    //     0xcd4318: str             x1, [SP, #-8]!
    // 0xcd431c: d0 = 1.000000
    //     0xcd431c: fmov            d0, #1.00000000
    // 0xcd4320: SaveReg d0
    //     0xcd4320: str             d0, [SP, #-8]!
    // 0xcd4324: r0 = withOpacity()
    //     0xcd4324: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd4328: add             SP, SP, #0x10
    // 0xcd432c: b               #0xcd4348
    // 0xcd4330: d0 = 0.100000
    //     0xcd4330: ldr             d0, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0xcd4334: ldur            x16, [fp, #-8]
    // 0xcd4338: SaveReg r16
    //     0xcd4338: str             x16, [SP, #-8]!
    // 0xcd433c: SaveReg d0
    //     0xcd433c: str             d0, [SP, #-8]!
    // 0xcd4340: r0 = withOpacity()
    //     0xcd4340: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcd4344: add             SP, SP, #0x10
    // 0xcd4348: ldur            x2, [fp, #-0x10]
    // 0xcd434c: StoreField: r2->field_1b = r0
    //     0xcd434c: stur            w0, [x2, #0x1b]
    //     0xcd4350: ldurb           w16, [x2, #-1]
    //     0xcd4354: ldurb           w17, [x0, #-1]
    //     0xcd4358: and             x16, x17, x16, lsr #2
    //     0xcd435c: tst             x16, HEAP, lsr #32
    //     0xcd4360: b.eq            #0xcd4368
    //     0xcd4364: bl              #0xd6828c
    // 0xcd4368: r1 = Function '<anonymous closure>':.
    //     0xcd4368: add             x1, PP, #0x50, lsl #12  ; [pp+0x50888] AnonymousClosure: (0xcd43cc), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_thumbColor (0xcd40e0)
    //     0xcd436c: ldr             x1, [x1, #0x888]
    // 0xcd4370: r0 = AllocateClosure()
    //     0xcd4370: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd4374: r16 = <Color>
    //     0xcd4374: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd4378: ldr             x16, [x16, #0x3f8]
    // 0xcd437c: stp             x0, x16, [SP, #-0x10]!
    // 0xcd4380: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd4380: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd4384: r0 = resolveWith()
    //     0xcd4384: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd4388: add             SP, SP, #0x10
    // 0xcd438c: LeaveFrame
    //     0xcd438c: mov             SP, fp
    //     0xcd4390: ldp             fp, lr, [SP], #0x10
    // 0xcd4394: ret
    //     0xcd4394: ret             
    // 0xcd4398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd4398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd439c: b               #0xcd40f8
    // 0xcd43a0: r9 = _colorScheme
    //     0xcd43a0: add             x9, PP, #0x50, lsl #12  ; [pp+0x50868] Field <_MaterialScrollbarState@802083257._colorScheme@802083257>: late (offset: 0x54)
    //     0xcd43a4: ldr             x9, [x9, #0x868]
    // 0xcd43a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd43a8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd43ac: r9 = _useAndroidScrollbar
    //     0xcd43ac: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xcd43b0: ldr             x9, [x9, #0x7c0]
    // 0xcd43b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd43b4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd43b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd43b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd43bc: r9 = _useAndroidScrollbar
    //     0xcd43bc: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xcd43c0: ldr             x9, [x9, #0x7c0]
    // 0xcd43c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd43c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd43c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd43c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xcd43cc, size: 0x3b0
    // 0xcd43cc: EnterFrame
    //     0xcd43cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcd43d0: mov             fp, SP
    // 0xcd43d4: AllocStack(0x10)
    //     0xcd43d4: sub             SP, SP, #0x10
    // 0xcd43d8: SetupParameters()
    //     0xcd43d8: ldr             x0, [fp, #0x18]
    //     0xcd43dc: ldur            w1, [x0, #0x17]
    //     0xcd43e0: add             x1, x1, HEAP, lsl #32
    //     0xcd43e4: stur            x1, [fp, #-8]
    // 0xcd43e8: CheckStackOverflow
    //     0xcd43e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd43ec: cmp             SP, x16
    //     0xcd43f0: b.ls            #0xcd4728
    // 0xcd43f4: ldr             x2, [fp, #0x10]
    // 0xcd43f8: r0 = LoadClassIdInstr(r2)
    //     0xcd43f8: ldur            x0, [x2, #-1]
    //     0xcd43fc: ubfx            x0, x0, #0xc, #0x14
    // 0xcd4400: r16 = Instance_MaterialState
    //     0xcd4400: add             x16, PP, #0xe, lsl #12  ; [pp+0xe170] Obj!MaterialState@b654f1
    //     0xcd4404: ldr             x16, [x16, #0x170]
    // 0xcd4408: stp             x16, x2, [SP, #-0x10]!
    // 0xcd440c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xcd440c: mov             x17, #0xc98a
    //     0xcd4410: add             lr, x0, x17
    //     0xcd4414: ldr             lr, [x21, lr, lsl #3]
    //     0xcd4418: blr             lr
    // 0xcd441c: add             SP, SP, #0x10
    // 0xcd4420: tbnz            w0, #4, #0xcd44bc
    // 0xcd4424: ldur            x0, [fp, #-8]
    // 0xcd4428: LoadField: r1 = r0->field_f
    //     0xcd4428: ldur            w1, [x0, #0xf]
    // 0xcd442c: DecompressPointer r1
    //     0xcd442c: add             x1, x1, HEAP, lsl #32
    // 0xcd4430: LoadField: r2 = r1->field_57
    //     0xcd4430: ldur            w2, [x1, #0x57]
    // 0xcd4434: DecompressPointer r2
    //     0xcd4434: add             x2, x2, HEAP, lsl #32
    // 0xcd4438: r16 = Sentinel
    //     0xcd4438: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd443c: cmp             w2, w16
    // 0xcd4440: b.eq            #0xcd4730
    // 0xcd4444: LoadField: r1 = r2->field_23
    //     0xcd4444: ldur            w1, [x2, #0x23]
    // 0xcd4448: DecompressPointer r1
    //     0xcd4448: add             x1, x1, HEAP, lsl #32
    // 0xcd444c: cmp             w1, NULL
    // 0xcd4450: b.ne            #0xcd445c
    // 0xcd4454: r0 = Null
    //     0xcd4454: mov             x0, NULL
    // 0xcd4458: b               #0xcd446c
    // 0xcd445c: ldr             x16, [fp, #0x10]
    // 0xcd4460: stp             x16, x1, [SP, #-0x10]!
    // 0xcd4464: r0 = resolve()
    //     0xcd4464: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd4468: add             SP, SP, #0x10
    // 0xcd446c: cmp             w0, NULL
    // 0xcd4470: b.ne            #0xcd44b0
    // 0xcd4474: ldur            x0, [fp, #-8]
    // 0xcd4478: LoadField: r1 = r0->field_13
    //     0xcd4478: ldur            w1, [x0, #0x13]
    // 0xcd447c: DecompressPointer r1
    //     0xcd447c: add             x1, x1, HEAP, lsl #32
    // 0xcd4480: r16 = Sentinel
    //     0xcd4480: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd4484: cmp             w1, w16
    // 0xcd4488: b.ne            #0xcd44a0
    // 0xcd448c: r16 = "dragColor"
    //     0xcd448c: add             x16, PP, #0x50, lsl #12  ; [pp+0x50890] "dragColor"
    //     0xcd4490: ldr             x16, [x16, #0x890]
    // 0xcd4494: SaveReg r16
    //     0xcd4494: str             x16, [SP, #-8]!
    // 0xcd4498: r0 = _throwLocalNotInitialized()
    //     0xcd4498: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcd449c: add             SP, SP, #8
    // 0xcd44a0: ldur            x0, [fp, #-8]
    // 0xcd44a4: LoadField: r1 = r0->field_13
    //     0xcd44a4: ldur            w1, [x0, #0x13]
    // 0xcd44a8: DecompressPointer r1
    //     0xcd44a8: add             x1, x1, HEAP, lsl #32
    // 0xcd44ac: mov             x0, x1
    // 0xcd44b0: LeaveFrame
    //     0xcd44b0: mov             SP, fp
    //     0xcd44b4: ldp             fp, lr, [SP], #0x10
    // 0xcd44b8: ret
    //     0xcd44b8: ret             
    // 0xcd44bc: ldur            x0, [fp, #-8]
    // 0xcd44c0: LoadField: r1 = r0->field_f
    //     0xcd44c0: ldur            w1, [x0, #0xf]
    // 0xcd44c4: DecompressPointer r1
    //     0xcd44c4: add             x1, x1, HEAP, lsl #32
    // 0xcd44c8: stur            x1, [fp, #-0x10]
    // 0xcd44cc: r1 = 1
    //     0xcd44cc: mov             x1, #1
    // 0xcd44d0: r0 = AllocateContext()
    //     0xcd44d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd44d4: mov             x1, x0
    // 0xcd44d8: ldur            x0, [fp, #-0x10]
    // 0xcd44dc: StoreField: r1->field_f = r0
    //     0xcd44dc: stur            w0, [x1, #0xf]
    // 0xcd44e0: mov             x2, x1
    // 0xcd44e4: r1 = Function '<anonymous closure>':.
    //     0xcd44e4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50858] AnonymousClosure: (0xcd3710), in [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_trackVisibility (0xcd36b0)
    //     0xcd44e8: ldr             x1, [x1, #0x858]
    // 0xcd44ec: r0 = AllocateClosure()
    //     0xcd44ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd44f0: r16 = <bool>
    //     0xcd44f0: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0xcd44f4: stp             x0, x16, [SP, #-0x10]!
    // 0xcd44f8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcd44f8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcd44fc: r0 = resolveWith()
    //     0xcd44fc: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcd4500: add             SP, SP, #0x10
    // 0xcd4504: ldr             x16, [fp, #0x10]
    // 0xcd4508: stp             x16, x0, [SP, #-0x10]!
    // 0xcd450c: r0 = build()
    //     0xcd450c: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0xcd4510: add             SP, SP, #0x10
    // 0xcd4514: tbnz            w0, #4, #0xcd45b0
    // 0xcd4518: ldur            x0, [fp, #-8]
    // 0xcd451c: LoadField: r1 = r0->field_f
    //     0xcd451c: ldur            w1, [x0, #0xf]
    // 0xcd4520: DecompressPointer r1
    //     0xcd4520: add             x1, x1, HEAP, lsl #32
    // 0xcd4524: LoadField: r2 = r1->field_57
    //     0xcd4524: ldur            w2, [x1, #0x57]
    // 0xcd4528: DecompressPointer r2
    //     0xcd4528: add             x2, x2, HEAP, lsl #32
    // 0xcd452c: r16 = Sentinel
    //     0xcd452c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd4530: cmp             w2, w16
    // 0xcd4534: b.eq            #0xcd473c
    // 0xcd4538: LoadField: r1 = r2->field_23
    //     0xcd4538: ldur            w1, [x2, #0x23]
    // 0xcd453c: DecompressPointer r1
    //     0xcd453c: add             x1, x1, HEAP, lsl #32
    // 0xcd4540: cmp             w1, NULL
    // 0xcd4544: b.ne            #0xcd4550
    // 0xcd4548: r0 = Null
    //     0xcd4548: mov             x0, NULL
    // 0xcd454c: b               #0xcd4560
    // 0xcd4550: ldr             x16, [fp, #0x10]
    // 0xcd4554: stp             x16, x1, [SP, #-0x10]!
    // 0xcd4558: r0 = resolve()
    //     0xcd4558: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd455c: add             SP, SP, #0x10
    // 0xcd4560: cmp             w0, NULL
    // 0xcd4564: b.ne            #0xcd45a4
    // 0xcd4568: ldur            x0, [fp, #-8]
    // 0xcd456c: LoadField: r1 = r0->field_17
    //     0xcd456c: ldur            w1, [x0, #0x17]
    // 0xcd4570: DecompressPointer r1
    //     0xcd4570: add             x1, x1, HEAP, lsl #32
    // 0xcd4574: r16 = Sentinel
    //     0xcd4574: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd4578: cmp             w1, w16
    // 0xcd457c: b.ne            #0xcd4594
    // 0xcd4580: r16 = "hoverColor"
    //     0xcd4580: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd68] "hoverColor"
    //     0xcd4584: ldr             x16, [x16, #0xd68]
    // 0xcd4588: SaveReg r16
    //     0xcd4588: str             x16, [SP, #-8]!
    // 0xcd458c: r0 = _throwLocalNotInitialized()
    //     0xcd458c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcd4590: add             SP, SP, #8
    // 0xcd4594: ldur            x0, [fp, #-8]
    // 0xcd4598: LoadField: r1 = r0->field_17
    //     0xcd4598: ldur            w1, [x0, #0x17]
    // 0xcd459c: DecompressPointer r1
    //     0xcd459c: add             x1, x1, HEAP, lsl #32
    // 0xcd45a0: mov             x0, x1
    // 0xcd45a4: LeaveFrame
    //     0xcd45a4: mov             SP, fp
    //     0xcd45a8: ldp             fp, lr, [SP], #0x10
    // 0xcd45ac: ret
    //     0xcd45ac: ret             
    // 0xcd45b0: ldur            x0, [fp, #-8]
    // 0xcd45b4: LoadField: r1 = r0->field_f
    //     0xcd45b4: ldur            w1, [x0, #0xf]
    // 0xcd45b8: DecompressPointer r1
    //     0xcd45b8: add             x1, x1, HEAP, lsl #32
    // 0xcd45bc: LoadField: r2 = r1->field_57
    //     0xcd45bc: ldur            w2, [x1, #0x57]
    // 0xcd45c0: DecompressPointer r2
    //     0xcd45c0: add             x2, x2, HEAP, lsl #32
    // 0xcd45c4: r16 = Sentinel
    //     0xcd45c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd45c8: cmp             w2, w16
    // 0xcd45cc: b.eq            #0xcd4748
    // 0xcd45d0: LoadField: r1 = r2->field_23
    //     0xcd45d0: ldur            w1, [x2, #0x23]
    // 0xcd45d4: DecompressPointer r1
    //     0xcd45d4: add             x1, x1, HEAP, lsl #32
    // 0xcd45d8: cmp             w1, NULL
    // 0xcd45dc: b.ne            #0xcd45e8
    // 0xcd45e0: r0 = Null
    //     0xcd45e0: mov             x0, NULL
    // 0xcd45e4: b               #0xcd45f8
    // 0xcd45e8: ldr             x16, [fp, #0x10]
    // 0xcd45ec: stp             x16, x1, [SP, #-0x10]!
    // 0xcd45f0: r0 = resolve()
    //     0xcd45f0: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd45f4: add             SP, SP, #0x10
    // 0xcd45f8: cmp             w0, NULL
    // 0xcd45fc: b.ne            #0xcd463c
    // 0xcd4600: ldur            x0, [fp, #-8]
    // 0xcd4604: LoadField: r1 = r0->field_1b
    //     0xcd4604: ldur            w1, [x0, #0x1b]
    // 0xcd4608: DecompressPointer r1
    //     0xcd4608: add             x1, x1, HEAP, lsl #32
    // 0xcd460c: r16 = Sentinel
    //     0xcd460c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd4610: cmp             w1, w16
    // 0xcd4614: b.ne            #0xcd462c
    // 0xcd4618: r16 = "idleColor"
    //     0xcd4618: add             x16, PP, #0x50, lsl #12  ; [pp+0x50898] "idleColor"
    //     0xcd461c: ldr             x16, [x16, #0x898]
    // 0xcd4620: SaveReg r16
    //     0xcd4620: str             x16, [SP, #-8]!
    // 0xcd4624: r0 = _throwLocalNotInitialized()
    //     0xcd4624: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcd4628: add             SP, SP, #8
    // 0xcd462c: ldur            x1, [fp, #-8]
    // 0xcd4630: LoadField: r0 = r1->field_1b
    //     0xcd4630: ldur            w0, [x1, #0x1b]
    // 0xcd4634: DecompressPointer r0
    //     0xcd4634: add             x0, x0, HEAP, lsl #32
    // 0xcd4638: b               #0xcd4640
    // 0xcd463c: ldur            x1, [fp, #-8]
    // 0xcd4640: stur            x0, [fp, #-0x10]
    // 0xcd4644: LoadField: r2 = r1->field_f
    //     0xcd4644: ldur            w2, [x1, #0xf]
    // 0xcd4648: DecompressPointer r2
    //     0xcd4648: add             x2, x2, HEAP, lsl #32
    // 0xcd464c: LoadField: r3 = r2->field_57
    //     0xcd464c: ldur            w3, [x2, #0x57]
    // 0xcd4650: DecompressPointer r3
    //     0xcd4650: add             x3, x3, HEAP, lsl #32
    // 0xcd4654: r16 = Sentinel
    //     0xcd4654: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd4658: cmp             w3, w16
    // 0xcd465c: b.eq            #0xcd4754
    // 0xcd4660: LoadField: r2 = r3->field_23
    //     0xcd4660: ldur            w2, [x3, #0x23]
    // 0xcd4664: DecompressPointer r2
    //     0xcd4664: add             x2, x2, HEAP, lsl #32
    // 0xcd4668: cmp             w2, NULL
    // 0xcd466c: b.ne            #0xcd4678
    // 0xcd4670: r0 = Null
    //     0xcd4670: mov             x0, NULL
    // 0xcd4674: b               #0xcd4688
    // 0xcd4678: ldr             x16, [fp, #0x10]
    // 0xcd467c: stp             x16, x2, [SP, #-0x10]!
    // 0xcd4680: r0 = resolve()
    //     0xcd4680: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcd4684: add             SP, SP, #0x10
    // 0xcd4688: cmp             w0, NULL
    // 0xcd468c: b.ne            #0xcd46cc
    // 0xcd4690: ldur            x0, [fp, #-8]
    // 0xcd4694: LoadField: r1 = r0->field_17
    //     0xcd4694: ldur            w1, [x0, #0x17]
    // 0xcd4698: DecompressPointer r1
    //     0xcd4698: add             x1, x1, HEAP, lsl #32
    // 0xcd469c: r16 = Sentinel
    //     0xcd469c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd46a0: cmp             w1, w16
    // 0xcd46a4: b.ne            #0xcd46bc
    // 0xcd46a8: r16 = "hoverColor"
    //     0xcd46a8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd68] "hoverColor"
    //     0xcd46ac: ldr             x16, [x16, #0xd68]
    // 0xcd46b0: SaveReg r16
    //     0xcd46b0: str             x16, [SP, #-8]!
    // 0xcd46b4: r0 = _throwLocalNotInitialized()
    //     0xcd46b4: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xcd46b8: add             SP, SP, #8
    // 0xcd46bc: ldur            x1, [fp, #-8]
    // 0xcd46c0: LoadField: r0 = r1->field_17
    //     0xcd46c0: ldur            w0, [x1, #0x17]
    // 0xcd46c4: DecompressPointer r0
    //     0xcd46c4: add             x0, x0, HEAP, lsl #32
    // 0xcd46c8: b               #0xcd46d0
    // 0xcd46cc: ldur            x1, [fp, #-8]
    // 0xcd46d0: LoadField: r2 = r1->field_f
    //     0xcd46d0: ldur            w2, [x1, #0xf]
    // 0xcd46d4: DecompressPointer r2
    //     0xcd46d4: add             x2, x2, HEAP, lsl #32
    // 0xcd46d8: LoadField: r1 = r2->field_47
    //     0xcd46d8: ldur            w1, [x2, #0x47]
    // 0xcd46dc: DecompressPointer r1
    //     0xcd46dc: add             x1, x1, HEAP, lsl #32
    // 0xcd46e0: r16 = Sentinel
    //     0xcd46e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd46e4: cmp             w1, w16
    // 0xcd46e8: b.eq            #0xcd4760
    // 0xcd46ec: LoadField: r2 = r1->field_37
    //     0xcd46ec: ldur            w2, [x1, #0x37]
    // 0xcd46f0: DecompressPointer r2
    //     0xcd46f0: add             x2, x2, HEAP, lsl #32
    // 0xcd46f4: r16 = Sentinel
    //     0xcd46f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd46f8: cmp             w2, w16
    // 0xcd46fc: b.eq            #0xcd476c
    // 0xcd4700: ldur            x16, [fp, #-0x10]
    // 0xcd4704: stp             x0, x16, [SP, #-0x10]!
    // 0xcd4708: SaveReg r2
    //     0xcd4708: str             x2, [SP, #-8]!
    // 0xcd470c: r0 = lerp()
    //     0xcd470c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd4710: add             SP, SP, #0x18
    // 0xcd4714: cmp             w0, NULL
    // 0xcd4718: b.eq            #0xcd4778
    // 0xcd471c: LeaveFrame
    //     0xcd471c: mov             SP, fp
    //     0xcd4720: ldp             fp, lr, [SP], #0x10
    // 0xcd4724: ret
    //     0xcd4724: ret             
    // 0xcd4728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd4728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd472c: b               #0xcd43f4
    // 0xcd4730: r9 = _scrollbarTheme
    //     0xcd4730: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd4734: ldr             x9, [x9, #0x7b8]
    // 0xcd4738: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd4738: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd473c: r9 = _scrollbarTheme
    //     0xcd473c: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd4740: ldr             x9, [x9, #0x7b8]
    // 0xcd4744: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd4744: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd4748: r9 = _scrollbarTheme
    //     0xcd4748: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd474c: ldr             x9, [x9, #0x7b8]
    // 0xcd4750: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd4750: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd4754: r9 = _scrollbarTheme
    //     0xcd4754: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcd4758: ldr             x9, [x9, #0x7b8]
    // 0xcd475c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd475c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd4760: r9 = _hoverAnimationController
    //     0xcd4760: add             x9, PP, #0x50, lsl #12  ; [pp+0x50838] Field <_MaterialScrollbarState@802083257._hoverAnimationController@802083257>: late (offset: 0x48)
    //     0xcd4764: ldr             x9, [x9, #0x838]
    // 0xcd4768: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd4768: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd476c: r9 = _value
    //     0xcd476c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xcd4770: ldr             x9, [x9, #0xbb0]
    // 0xcd4774: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd4774: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd4778: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd4778: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ showScrollbar(/* No info */) {
    // ** addr: 0xcde6f0, size: 0xfc
    // 0xcde6f0: EnterFrame
    //     0xcde6f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcde6f4: mov             fp, SP
    // 0xcde6f8: AllocStack(0x8)
    //     0xcde6f8: sub             SP, SP, #8
    // 0xcde6fc: CheckStackOverflow
    //     0xcde6fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcde700: cmp             SP, x16
    //     0xcde704: b.ls            #0xcde7c8
    // 0xcde708: ldr             x0, [fp, #0x10]
    // 0xcde70c: LoadField: r1 = r0->field_b
    //     0xcde70c: ldur            w1, [x0, #0xb]
    // 0xcde710: DecompressPointer r1
    //     0xcde710: add             x1, x1, HEAP, lsl #32
    // 0xcde714: cmp             w1, NULL
    // 0xcde718: b.eq            #0xcde7d0
    // 0xcde71c: LoadField: r2 = r1->field_13
    //     0xcde71c: ldur            w2, [x1, #0x13]
    // 0xcde720: DecompressPointer r2
    //     0xcde720: add             x2, x2, HEAP, lsl #32
    // 0xcde724: cmp             w2, NULL
    // 0xcde728: b.ne            #0xcde780
    // 0xcde72c: LoadField: r1 = r0->field_57
    //     0xcde72c: ldur            w1, [x0, #0x57]
    // 0xcde730: DecompressPointer r1
    //     0xcde730: add             x1, x1, HEAP, lsl #32
    // 0xcde734: r16 = Sentinel
    //     0xcde734: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcde738: cmp             w1, w16
    // 0xcde73c: b.eq            #0xcde7d4
    // 0xcde740: LoadField: r2 = r1->field_7
    //     0xcde740: ldur            w2, [x1, #7]
    // 0xcde744: DecompressPointer r2
    //     0xcde744: add             x2, x2, HEAP, lsl #32
    // 0xcde748: stur            x2, [fp, #-8]
    // 0xcde74c: cmp             w2, NULL
    // 0xcde750: b.ne            #0xcde75c
    // 0xcde754: r1 = Null
    //     0xcde754: mov             x1, NULL
    // 0xcde758: b               #0xcde784
    // 0xcde75c: SaveReg r0
    //     0xcde75c: str             x0, [SP, #-8]!
    // 0xcde760: r0 = _states()
    //     0xcde760: bl              #0xcd3ff4  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_states
    // 0xcde764: add             SP, SP, #8
    // 0xcde768: ldur            x16, [fp, #-8]
    // 0xcde76c: stp             x0, x16, [SP, #-0x10]!
    // 0xcde770: r0 = resolve()
    //     0xcde770: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0xcde774: add             SP, SP, #0x10
    // 0xcde778: mov             x1, x0
    // 0xcde77c: b               #0xcde784
    // 0xcde780: mov             x1, x2
    // 0xcde784: cmp             w1, NULL
    // 0xcde788: b.ne            #0xcde7a8
    // 0xcde78c: ldr             x2, [fp, #0x10]
    // 0xcde790: LoadField: r3 = r2->field_57
    //     0xcde790: ldur            w3, [x2, #0x57]
    // 0xcde794: DecompressPointer r3
    //     0xcde794: add             x3, x3, HEAP, lsl #32
    // 0xcde798: r16 = Sentinel
    //     0xcde798: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcde79c: cmp             w3, w16
    // 0xcde7a0: b.eq            #0xcde7e0
    // 0xcde7a4: r1 = Null
    //     0xcde7a4: mov             x1, NULL
    // 0xcde7a8: cmp             w1, NULL
    // 0xcde7ac: b.ne            #0xcde7b8
    // 0xcde7b0: r0 = false
    //     0xcde7b0: add             x0, NULL, #0x30  ; false
    // 0xcde7b4: b               #0xcde7bc
    // 0xcde7b8: mov             x0, x1
    // 0xcde7bc: LeaveFrame
    //     0xcde7bc: mov             SP, fp
    //     0xcde7c0: ldp             fp, lr, [SP], #0x10
    // 0xcde7c4: ret
    //     0xcde7c4: ret             
    // 0xcde7c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcde7c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcde7cc: b               #0xcde708
    // 0xcde7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcde7d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcde7d4: r9 = _scrollbarTheme
    //     0xcde7d4: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcde7d8: ldr             x9, [x9, #0x7b8]
    // 0xcde7dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcde7dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcde7e0: r9 = _scrollbarTheme
    //     0xcde7e0: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xcde7e4: ldr             x9, [x9, #0x7b8]
    // 0xcde7e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcde7e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ enableGestures(/* No info */) {
    // ** addr: 0xce3de4, size: 0x70
    // 0xce3de4: EnterFrame
    //     0xce3de4: stp             fp, lr, [SP, #-0x10]!
    //     0xce3de8: mov             fp, SP
    // 0xce3dec: ldr             x1, [fp, #0x10]
    // 0xce3df0: LoadField: r2 = r1->field_b
    //     0xce3df0: ldur            w2, [x1, #0xb]
    // 0xce3df4: DecompressPointer r2
    //     0xce3df4: add             x2, x2, HEAP, lsl #32
    // 0xce3df8: cmp             w2, NULL
    // 0xce3dfc: b.eq            #0xce3e38
    // 0xce3e00: LoadField: r2 = r1->field_57
    //     0xce3e00: ldur            w2, [x1, #0x57]
    // 0xce3e04: DecompressPointer r2
    //     0xce3e04: add             x2, x2, HEAP, lsl #32
    // 0xce3e08: r16 = Sentinel
    //     0xce3e08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce3e0c: cmp             w2, w16
    // 0xce3e10: b.eq            #0xce3e3c
    // 0xce3e14: LoadField: r2 = r1->field_5b
    //     0xce3e14: ldur            w2, [x1, #0x5b]
    // 0xce3e18: DecompressPointer r2
    //     0xce3e18: add             x2, x2, HEAP, lsl #32
    // 0xce3e1c: r16 = Sentinel
    //     0xce3e1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce3e20: cmp             w2, w16
    // 0xce3e24: b.eq            #0xce3e48
    // 0xce3e28: eor             x0, x2, #0x10
    // 0xce3e2c: LeaveFrame
    //     0xce3e2c: mov             SP, fp
    //     0xce3e30: ldp             fp, lr, [SP], #0x10
    // 0xce3e34: ret
    //     0xce3e34: ret             
    // 0xce3e38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce3e38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xce3e3c: r9 = _scrollbarTheme
    //     0xce3e3c: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7b8] Field <_MaterialScrollbarState@802083257._scrollbarTheme@802083257>: late (offset: 0x58)
    //     0xce3e40: ldr             x9, [x9, #0x7b8]
    // 0xce3e44: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce3e44: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xce3e48: r9 = _useAndroidScrollbar
    //     0xce3e48: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f7c0] Field <_MaterialScrollbarState@802083257._useAndroidScrollbar@802083257>: late (offset: 0x5c)
    //     0xce3e4c: ldr             x9, [x9, #0x7c0]
    // 0xce3e50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xce3e50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3844, size: 0x3c, field offset: 0xc
//   const constructor, 
class Scrollbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb23dd4, size: 0x184
    // 0xb23dd4: EnterFrame
    //     0xb23dd4: stp             fp, lr, [SP, #-0x10]!
    //     0xb23dd8: mov             fp, SP
    // 0xb23ddc: AllocStack(0x10)
    //     0xb23ddc: sub             SP, SP, #0x10
    // 0xb23de0: CheckStackOverflow
    //     0xb23de0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23de4: cmp             SP, x16
    //     0xb23de8: b.ls            #0xb23f50
    // 0xb23dec: ldr             x16, [fp, #0x10]
    // 0xb23df0: SaveReg r16
    //     0xb23df0: str             x16, [SP, #-8]!
    // 0xb23df4: r0 = of()
    //     0xb23df4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb23df8: add             SP, SP, #8
    // 0xb23dfc: LoadField: r1 = r0->field_1f
    //     0xb23dfc: ldur            w1, [x0, #0x1f]
    // 0xb23e00: DecompressPointer r1
    //     0xb23e00: add             x1, x1, HEAP, lsl #32
    // 0xb23e04: r16 = Instance_TargetPlatform
    //     0xb23e04: ldr             x16, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0xb23e08: cmp             w1, w16
    // 0xb23e0c: b.ne            #0xb23ec4
    // 0xb23e10: ldr             x0, [fp, #0x18]
    // 0xb23e14: LoadField: r1 = r0->field_f
    //     0xb23e14: ldur            w1, [x0, #0xf]
    // 0xb23e18: DecompressPointer r1
    //     0xb23e18: add             x1, x1, HEAP, lsl #32
    // 0xb23e1c: stur            x1, [fp, #-0x10]
    // 0xb23e20: LoadField: r2 = r0->field_b
    //     0xb23e20: ldur            w2, [x0, #0xb]
    // 0xb23e24: DecompressPointer r2
    //     0xb23e24: add             x2, x2, HEAP, lsl #32
    // 0xb23e28: stur            x2, [fp, #-8]
    // 0xb23e2c: r0 = CupertinoScrollbar()
    //     0xb23e2c: bl              #0xb23f64  ; AllocateCupertinoScrollbarStub -> CupertinoScrollbar (size=0x80)
    // 0xb23e30: d0 = 8.000000
    //     0xb23e30: fmov            d0, #8.00000000
    // 0xb23e34: StoreField: r0->field_73 = d0
    //     0xb23e34: stur            d0, [x0, #0x73]
    // 0xb23e38: r1 = Instance_Radius
    //     0xb23e38: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ffa0] Obj!Radius@b5e861
    //     0xb23e3c: ldr             x1, [x1, #0xfa0]
    // 0xb23e40: StoreField: r0->field_7b = r1
    //     0xb23e40: stur            w1, [x0, #0x7b]
    // 0xb23e44: ldur            x1, [fp, #-8]
    // 0xb23e48: StoreField: r0->field_b = r1
    //     0xb23e48: stur            w1, [x0, #0xb]
    // 0xb23e4c: ldur            x1, [fp, #-0x10]
    // 0xb23e50: StoreField: r0->field_f = r1
    //     0xb23e50: stur            w1, [x0, #0xf]
    // 0xb23e54: r1 = false
    //     0xb23e54: add             x1, NULL, #0x30  ; false
    // 0xb23e58: StoreField: r0->field_13 = r1
    //     0xb23e58: stur            w1, [x0, #0x13]
    // 0xb23e5c: r1 = Instance_Radius
    //     0xb23e5c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ffa8] Obj!Radius@b5eb61
    //     0xb23e60: ldr             x1, [x1, #0xfa8]
    // 0xb23e64: StoreField: r0->field_1f = r1
    //     0xb23e64: stur            w1, [x0, #0x1f]
    // 0xb23e68: r1 = 3.000000
    //     0xb23e68: add             x1, PP, #0xc, lsl #12  ; [pp+0xcaf0] 3
    //     0xb23e6c: ldr             x1, [x1, #0xaf0]
    // 0xb23e70: StoreField: r0->field_23 = r1
    //     0xb23e70: stur            w1, [x0, #0x23]
    // 0xb23e74: d0 = 18.000000
    //     0xb23e74: fmov            d0, #18.00000000
    // 0xb23e78: StoreField: r0->field_2b = d0
    //     0xb23e78: stur            d0, [x0, #0x2b]
    // 0xb23e7c: r1 = Instance_Duration
    //     0xb23e7c: add             x1, PP, #8, lsl #12  ; [pp+0x85d8] Obj!Duration@b67a61
    //     0xb23e80: ldr             x1, [x1, #0x5d8]
    // 0xb23e84: StoreField: r0->field_47 = r1
    //     0xb23e84: stur            w1, [x0, #0x47]
    // 0xb23e88: r1 = Instance_Duration
    //     0xb23e88: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3ffb0] Obj!Duration@b67cc1
    //     0xb23e8c: ldr             x1, [x1, #0xfb0]
    // 0xb23e90: StoreField: r0->field_4b = r1
    //     0xb23e90: stur            w1, [x0, #0x4b]
    // 0xb23e94: r1 = Instance_Duration
    //     0xb23e94: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0xb23e98: ldr             x1, [x1, #0x9f0]
    // 0xb23e9c: StoreField: r0->field_4f = r1
    //     0xb23e9c: stur            w1, [x0, #0x4f]
    // 0xb23ea0: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xb23ea0: add             x1, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xb23ea4: ldr             x1, [x1, #0x358]
    // 0xb23ea8: StoreField: r0->field_53 = r1
    //     0xb23ea8: stur            w1, [x0, #0x53]
    // 0xb23eac: d1 = 0.000000
    //     0xb23eac: eor             v1.16b, v1.16b, v1.16b
    // 0xb23eb0: StoreField: r0->field_5f = d1
    //     0xb23eb0: stur            d1, [x0, #0x5f]
    // 0xb23eb4: StoreField: r0->field_67 = d1
    //     0xb23eb4: stur            d1, [x0, #0x67]
    // 0xb23eb8: LeaveFrame
    //     0xb23eb8: mov             SP, fp
    //     0xb23ebc: ldp             fp, lr, [SP], #0x10
    // 0xb23ec0: ret
    //     0xb23ec0: ret             
    // 0xb23ec4: ldr             x0, [fp, #0x18]
    // 0xb23ec8: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xb23ec8: add             x1, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xb23ecc: ldr             x1, [x1, #0x358]
    // 0xb23ed0: d0 = 18.000000
    //     0xb23ed0: fmov            d0, #18.00000000
    // 0xb23ed4: d1 = 0.000000
    //     0xb23ed4: eor             v1.16b, v1.16b, v1.16b
    // 0xb23ed8: LoadField: r2 = r0->field_f
    //     0xb23ed8: ldur            w2, [x0, #0xf]
    // 0xb23edc: DecompressPointer r2
    //     0xb23edc: add             x2, x2, HEAP, lsl #32
    // 0xb23ee0: stur            x2, [fp, #-0x10]
    // 0xb23ee4: LoadField: r3 = r0->field_b
    //     0xb23ee4: ldur            w3, [x0, #0xb]
    // 0xb23ee8: DecompressPointer r3
    //     0xb23ee8: add             x3, x3, HEAP, lsl #32
    // 0xb23eec: stur            x3, [fp, #-8]
    // 0xb23ef0: r0 = _MaterialScrollbar()
    //     0xb23ef0: bl              #0xb23f58  ; Allocate_MaterialScrollbarStub -> _MaterialScrollbar (size=0x7c)
    // 0xb23ef4: ldur            x1, [fp, #-8]
    // 0xb23ef8: StoreField: r0->field_b = r1
    //     0xb23ef8: stur            w1, [x0, #0xb]
    // 0xb23efc: ldur            x1, [fp, #-0x10]
    // 0xb23f00: StoreField: r0->field_f = r1
    //     0xb23f00: stur            w1, [x0, #0xf]
    // 0xb23f04: d0 = 18.000000
    //     0xb23f04: fmov            d0, #18.00000000
    // 0xb23f08: StoreField: r0->field_2b = d0
    //     0xb23f08: stur            d0, [x0, #0x2b]
    // 0xb23f0c: r1 = Instance_Duration
    //     0xb23f0c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0xb23f10: ldr             x1, [x1, #0xc88]
    // 0xb23f14: StoreField: r0->field_47 = r1
    //     0xb23f14: stur            w1, [x0, #0x47]
    // 0xb23f18: r1 = Instance_Duration
    //     0xb23f18: add             x1, PP, #0x20, lsl #12  ; [pp+0x20848] Obj!Duration@b67c01
    //     0xb23f1c: ldr             x1, [x1, #0x848]
    // 0xb23f20: StoreField: r0->field_4b = r1
    //     0xb23f20: stur            w1, [x0, #0x4b]
    // 0xb23f24: r1 = Instance_Duration
    //     0xb23f24: ldr             x1, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0xb23f28: StoreField: r0->field_4f = r1
    //     0xb23f28: stur            w1, [x0, #0x4f]
    // 0xb23f2c: r1 = Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static.
    //     0xb23f2c: add             x1, PP, #0x27, lsl #12  ; [pp+0x27358] Closure: (ScrollNotification) => bool from Function 'defaultScrollNotificationPredicate': static. (0x7fe6e20b793c)
    //     0xb23f30: ldr             x1, [x1, #0x358]
    // 0xb23f34: StoreField: r0->field_53 = r1
    //     0xb23f34: stur            w1, [x0, #0x53]
    // 0xb23f38: d0 = 0.000000
    //     0xb23f38: eor             v0.16b, v0.16b, v0.16b
    // 0xb23f3c: StoreField: r0->field_5f = d0
    //     0xb23f3c: stur            d0, [x0, #0x5f]
    // 0xb23f40: StoreField: r0->field_67 = d0
    //     0xb23f40: stur            d0, [x0, #0x67]
    // 0xb23f44: LeaveFrame
    //     0xb23f44: mov             SP, fp
    //     0xb23f48: ldp             fp, lr, [SP], #0x10
    // 0xb23f4c: ret
    //     0xb23f4c: ret             
    // 0xb23f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23f50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23f54: b               #0xb23dec
  }
}

// class id: 4177, size: 0x7c, field offset: 0x74
//   const constructor, 
class _MaterialScrollbar extends RawScrollbar {

  _ createState(/* No info */) {
    // ** addr: 0xa3ff18, size: 0x4c
    // 0xa3ff18: EnterFrame
    //     0xa3ff18: stp             fp, lr, [SP, #-0x10]!
    //     0xa3ff1c: mov             fp, SP
    // 0xa3ff20: AllocStack(0x8)
    //     0xa3ff20: sub             SP, SP, #8
    // 0xa3ff24: CheckStackOverflow
    //     0xa3ff24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3ff28: cmp             SP, x16
    //     0xa3ff2c: b.ls            #0xa3ff5c
    // 0xa3ff30: r1 = <_MaterialScrollbar>
    //     0xa3ff30: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b588] TypeArguments: <_MaterialScrollbar>
    //     0xa3ff34: ldr             x1, [x1, #0x588]
    // 0xa3ff38: r0 = _MaterialScrollbarState()
    //     0xa3ff38: bl              #0xa3ffdc  ; Allocate_MaterialScrollbarStateStub -> _MaterialScrollbarState (size=0x60)
    // 0xa3ff3c: stur            x0, [fp, #-8]
    // 0xa3ff40: SaveReg r0
    //     0xa3ff40: str             x0, [SP, #-8]!
    // 0xa3ff44: r0 = _MaterialScrollbarState()
    //     0xa3ff44: bl              #0xa3ff64  ; [package:flutter/src/material/scrollbar.dart] _MaterialScrollbarState::_MaterialScrollbarState
    // 0xa3ff48: add             SP, SP, #8
    // 0xa3ff4c: ldur            x0, [fp, #-8]
    // 0xa3ff50: LeaveFrame
    //     0xa3ff50: mov             SP, fp
    //     0xa3ff54: ldp             fp, lr, [SP], #0x10
    // 0xa3ff58: ret
    //     0xa3ff58: ret             
    // 0xa3ff5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3ff5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3ff60: b               #0xa3ff30
  }
}

// lib: , url: package:flutter/src/material/data_table_theme.dart

// class id: 1049216, size: 0x8
class :: {
}

// class id: 2813, size: 0x34, field offset: 0x8
//   const constructor, 
class DataTableThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff0c0, size: 0xac
    // 0xaff0c0: EnterFrame
    //     0xaff0c0: stp             fp, lr, [SP, #-0x10]!
    //     0xaff0c4: mov             fp, SP
    // 0xaff0c8: CheckStackOverflow
    //     0xaff0c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff0cc: cmp             SP, x16
    //     0xaff0d0: b.ls            #0xaff164
    // 0xaff0d4: ldr             x0, [fp, #0x10]
    // 0xaff0d8: LoadField: r1 = r0->field_b
    //     0xaff0d8: ldur            w1, [x0, #0xb]
    // 0xaff0dc: DecompressPointer r1
    //     0xaff0dc: add             x1, x1, HEAP, lsl #32
    // 0xaff0e0: LoadField: r2 = r0->field_f
    //     0xaff0e0: ldur            w2, [x0, #0xf]
    // 0xaff0e4: DecompressPointer r2
    //     0xaff0e4: add             x2, x2, HEAP, lsl #32
    // 0xaff0e8: LoadField: r3 = r0->field_17
    //     0xaff0e8: ldur            w3, [x0, #0x17]
    // 0xaff0ec: DecompressPointer r3
    //     0xaff0ec: add             x3, x3, HEAP, lsl #32
    // 0xaff0f0: LoadField: r4 = r0->field_1b
    //     0xaff0f0: ldur            w4, [x0, #0x1b]
    // 0xaff0f4: DecompressPointer r4
    //     0xaff0f4: add             x4, x4, HEAP, lsl #32
    // 0xaff0f8: LoadField: r5 = r0->field_23
    //     0xaff0f8: ldur            w5, [x0, #0x23]
    // 0xaff0fc: DecompressPointer r5
    //     0xaff0fc: add             x5, x5, HEAP, lsl #32
    // 0xaff100: LoadField: r6 = r0->field_27
    //     0xaff100: ldur            w6, [x0, #0x27]
    // 0xaff104: DecompressPointer r6
    //     0xaff104: add             x6, x6, HEAP, lsl #32
    // 0xaff108: LoadField: r7 = r0->field_2b
    //     0xaff108: ldur            w7, [x0, #0x2b]
    // 0xaff10c: DecompressPointer r7
    //     0xaff10c: add             x7, x7, HEAP, lsl #32
    // 0xaff110: LoadField: r8 = r0->field_2f
    //     0xaff110: ldur            w8, [x0, #0x2f]
    // 0xaff114: DecompressPointer r8
    //     0xaff114: add             x8, x8, HEAP, lsl #32
    // 0xaff118: stp             x1, NULL, [SP, #-0x10]!
    // 0xaff11c: stp             NULL, x2, [SP, #-0x10]!
    // 0xaff120: stp             x4, x3, [SP, #-0x10]!
    // 0xaff124: stp             x5, NULL, [SP, #-0x10]!
    // 0xaff128: stp             x7, x6, [SP, #-0x10]!
    // 0xaff12c: SaveReg r8
    //     0xaff12c: str             x8, [SP, #-8]!
    // 0xaff130: r4 = const [0, 0xb, 0xb, 0xb, null]
    //     0xaff130: add             x4, PP, #0xe, lsl #12  ; [pp+0xe128] List(5) [0, 0xb, 0xb, 0xb, Null]
    //     0xaff134: ldr             x4, [x4, #0x128]
    // 0xaff138: r0 = hash()
    //     0xaff138: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaff13c: add             SP, SP, #0x58
    // 0xaff140: mov             x2, x0
    // 0xaff144: r0 = BoxInt64Instr(r2)
    //     0xaff144: sbfiz           x0, x2, #1, #0x1f
    //     0xaff148: cmp             x2, x0, asr #1
    //     0xaff14c: b.eq            #0xaff158
    //     0xaff150: bl              #0xd69bb8
    //     0xaff154: stur            x2, [x0, #7]
    // 0xaff158: LeaveFrame
    //     0xaff158: mov             SP, fp
    //     0xaff15c: ldp             fp, lr, [SP], #0x10
    // 0xaff160: ret
    //     0xaff160: ret             
    // 0xaff164: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff164: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff168: b               #0xaff0d4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf50b8, size: 0x2d0
    // 0xbf50b8: EnterFrame
    //     0xbf50b8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf50bc: mov             fp, SP
    // 0xbf50c0: AllocStack(0x40)
    //     0xbf50c0: sub             SP, SP, #0x40
    // 0xbf50c4: CheckStackOverflow
    //     0xbf50c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf50c8: cmp             SP, x16
    //     0xbf50cc: b.ls            #0xbf5354
    // 0xbf50d0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf50d4: ldr             d0, [fp, #0x10]
    // 0xbf50d8: SaveReg d0
    //     0xbf50d8: str             d0, [SP, #-8]!
    // 0xbf50dc: r0 = lerp()
    //     0xbf50dc: bl              #0xbf2618  ; [package:flutter/src/painting/decoration.dart] Decoration::lerp
    // 0xbf50e0: add             SP, SP, #0x18
    // 0xbf50e4: ldr             x0, [fp, #0x20]
    // 0xbf50e8: LoadField: r1 = r0->field_b
    //     0xbf50e8: ldur            w1, [x0, #0xb]
    // 0xbf50ec: DecompressPointer r1
    //     0xbf50ec: add             x1, x1, HEAP, lsl #32
    // 0xbf50f0: ldr             x2, [fp, #0x18]
    // 0xbf50f4: LoadField: r3 = r2->field_b
    //     0xbf50f4: ldur            w3, [x2, #0xb]
    // 0xbf50f8: DecompressPointer r3
    //     0xbf50f8: add             x3, x3, HEAP, lsl #32
    // 0xbf50fc: r16 = <Color?>
    //     0xbf50fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf5100: ldr             x16, [x16, #0xf68]
    // 0xbf5104: stp             x1, x16, [SP, #-0x10]!
    // 0xbf5108: SaveReg r3
    //     0xbf5108: str             x3, [SP, #-8]!
    // 0xbf510c: ldr             d0, [fp, #0x10]
    // 0xbf5110: SaveReg d0
    //     0xbf5110: str             d0, [SP, #-8]!
    // 0xbf5114: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf5114: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf5118: ldr             x16, [x16, #0xb80]
    // 0xbf511c: SaveReg r16
    //     0xbf511c: str             x16, [SP, #-8]!
    // 0xbf5120: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf5120: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf5124: r0 = lerp()
    //     0xbf5124: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf5128: add             SP, SP, #0x28
    // 0xbf512c: mov             x1, x0
    // 0xbf5130: ldr             x0, [fp, #0x20]
    // 0xbf5134: stur            x1, [fp, #-0x10]
    // 0xbf5138: LoadField: r2 = r0->field_f
    //     0xbf5138: ldur            w2, [x0, #0xf]
    // 0xbf513c: DecompressPointer r2
    //     0xbf513c: add             x2, x2, HEAP, lsl #32
    // 0xbf5140: ldr             x3, [fp, #0x18]
    // 0xbf5144: LoadField: r4 = r3->field_f
    //     0xbf5144: ldur            w4, [x3, #0xf]
    // 0xbf5148: DecompressPointer r4
    //     0xbf5148: add             x4, x4, HEAP, lsl #32
    // 0xbf514c: ldr             d0, [fp, #0x10]
    // 0xbf5150: r5 = inline_Allocate_Double()
    //     0xbf5150: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf5154: add             x5, x5, #0x10
    //     0xbf5158: cmp             x6, x5
    //     0xbf515c: b.ls            #0xbf535c
    //     0xbf5160: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf5164: sub             x5, x5, #0xf
    //     0xbf5168: mov             x6, #0xd108
    //     0xbf516c: movk            x6, #3, lsl #16
    //     0xbf5170: stur            x6, [x5, #-1]
    // 0xbf5174: StoreField: r5->field_7 = d0
    //     0xbf5174: stur            d0, [x5, #7]
    // 0xbf5178: stur            x5, [fp, #-8]
    // 0xbf517c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf5180: SaveReg r5
    //     0xbf5180: str             x5, [SP, #-8]!
    // 0xbf5184: r0 = lerpDouble()
    //     0xbf5184: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5188: add             SP, SP, #0x18
    // 0xbf518c: stur            x0, [fp, #-0x18]
    // 0xbf5190: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5194: ldur            x16, [fp, #-8]
    // 0xbf5198: SaveReg r16
    //     0xbf5198: str             x16, [SP, #-8]!
    // 0xbf519c: r0 = lerp()
    //     0xbf519c: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf51a0: add             SP, SP, #0x18
    // 0xbf51a4: ldr             x0, [fp, #0x20]
    // 0xbf51a8: LoadField: r1 = r0->field_17
    //     0xbf51a8: ldur            w1, [x0, #0x17]
    // 0xbf51ac: DecompressPointer r1
    //     0xbf51ac: add             x1, x1, HEAP, lsl #32
    // 0xbf51b0: ldr             x2, [fp, #0x18]
    // 0xbf51b4: LoadField: r3 = r2->field_17
    //     0xbf51b4: ldur            w3, [x2, #0x17]
    // 0xbf51b8: DecompressPointer r3
    //     0xbf51b8: add             x3, x3, HEAP, lsl #32
    // 0xbf51bc: r16 = <Color?>
    //     0xbf51bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf51c0: ldr             x16, [x16, #0xf68]
    // 0xbf51c4: stp             x1, x16, [SP, #-0x10]!
    // 0xbf51c8: SaveReg r3
    //     0xbf51c8: str             x3, [SP, #-8]!
    // 0xbf51cc: ldr             d0, [fp, #0x10]
    // 0xbf51d0: SaveReg d0
    //     0xbf51d0: str             d0, [SP, #-8]!
    // 0xbf51d4: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf51d4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf51d8: ldr             x16, [x16, #0xb80]
    // 0xbf51dc: SaveReg r16
    //     0xbf51dc: str             x16, [SP, #-8]!
    // 0xbf51e0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf51e0: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf51e4: r0 = lerp()
    //     0xbf51e4: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf51e8: add             SP, SP, #0x28
    // 0xbf51ec: mov             x1, x0
    // 0xbf51f0: ldr             x0, [fp, #0x20]
    // 0xbf51f4: stur            x1, [fp, #-0x20]
    // 0xbf51f8: LoadField: r2 = r0->field_1b
    //     0xbf51f8: ldur            w2, [x0, #0x1b]
    // 0xbf51fc: DecompressPointer r2
    //     0xbf51fc: add             x2, x2, HEAP, lsl #32
    // 0xbf5200: ldr             x3, [fp, #0x18]
    // 0xbf5204: LoadField: r4 = r3->field_1b
    //     0xbf5204: ldur            w4, [x3, #0x1b]
    // 0xbf5208: DecompressPointer r4
    //     0xbf5208: add             x4, x4, HEAP, lsl #32
    // 0xbf520c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf5210: ldur            x16, [fp, #-8]
    // 0xbf5214: SaveReg r16
    //     0xbf5214: str             x16, [SP, #-8]!
    // 0xbf5218: r0 = lerpDouble()
    //     0xbf5218: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf521c: add             SP, SP, #0x18
    // 0xbf5220: stur            x0, [fp, #-0x28]
    // 0xbf5224: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5228: ldur            x16, [fp, #-8]
    // 0xbf522c: SaveReg r16
    //     0xbf522c: str             x16, [SP, #-8]!
    // 0xbf5230: r0 = lerp()
    //     0xbf5230: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5234: add             SP, SP, #0x18
    // 0xbf5238: ldr             x0, [fp, #0x20]
    // 0xbf523c: LoadField: r1 = r0->field_23
    //     0xbf523c: ldur            w1, [x0, #0x23]
    // 0xbf5240: DecompressPointer r1
    //     0xbf5240: add             x1, x1, HEAP, lsl #32
    // 0xbf5244: ldr             x2, [fp, #0x18]
    // 0xbf5248: LoadField: r3 = r2->field_23
    //     0xbf5248: ldur            w3, [x2, #0x23]
    // 0xbf524c: DecompressPointer r3
    //     0xbf524c: add             x3, x3, HEAP, lsl #32
    // 0xbf5250: stp             x3, x1, [SP, #-0x10]!
    // 0xbf5254: ldur            x16, [fp, #-8]
    // 0xbf5258: SaveReg r16
    //     0xbf5258: str             x16, [SP, #-8]!
    // 0xbf525c: r0 = lerpDouble()
    //     0xbf525c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5260: add             SP, SP, #0x18
    // 0xbf5264: mov             x1, x0
    // 0xbf5268: ldr             x0, [fp, #0x20]
    // 0xbf526c: stur            x1, [fp, #-0x30]
    // 0xbf5270: LoadField: r2 = r0->field_27
    //     0xbf5270: ldur            w2, [x0, #0x27]
    // 0xbf5274: DecompressPointer r2
    //     0xbf5274: add             x2, x2, HEAP, lsl #32
    // 0xbf5278: ldr             x3, [fp, #0x18]
    // 0xbf527c: LoadField: r4 = r3->field_27
    //     0xbf527c: ldur            w4, [x3, #0x27]
    // 0xbf5280: DecompressPointer r4
    //     0xbf5280: add             x4, x4, HEAP, lsl #32
    // 0xbf5284: stp             x4, x2, [SP, #-0x10]!
    // 0xbf5288: ldur            x16, [fp, #-8]
    // 0xbf528c: SaveReg r16
    //     0xbf528c: str             x16, [SP, #-8]!
    // 0xbf5290: r0 = lerpDouble()
    //     0xbf5290: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5294: add             SP, SP, #0x18
    // 0xbf5298: mov             x1, x0
    // 0xbf529c: ldr             x0, [fp, #0x20]
    // 0xbf52a0: stur            x1, [fp, #-0x38]
    // 0xbf52a4: LoadField: r2 = r0->field_2b
    //     0xbf52a4: ldur            w2, [x0, #0x2b]
    // 0xbf52a8: DecompressPointer r2
    //     0xbf52a8: add             x2, x2, HEAP, lsl #32
    // 0xbf52ac: ldr             x3, [fp, #0x18]
    // 0xbf52b0: LoadField: r4 = r3->field_2b
    //     0xbf52b0: ldur            w4, [x3, #0x2b]
    // 0xbf52b4: DecompressPointer r4
    //     0xbf52b4: add             x4, x4, HEAP, lsl #32
    // 0xbf52b8: stp             x4, x2, [SP, #-0x10]!
    // 0xbf52bc: ldur            x16, [fp, #-8]
    // 0xbf52c0: SaveReg r16
    //     0xbf52c0: str             x16, [SP, #-8]!
    // 0xbf52c4: r0 = lerpDouble()
    //     0xbf52c4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf52c8: add             SP, SP, #0x18
    // 0xbf52cc: mov             x1, x0
    // 0xbf52d0: ldr             x0, [fp, #0x20]
    // 0xbf52d4: stur            x1, [fp, #-0x40]
    // 0xbf52d8: LoadField: r2 = r0->field_2f
    //     0xbf52d8: ldur            w2, [x0, #0x2f]
    // 0xbf52dc: DecompressPointer r2
    //     0xbf52dc: add             x2, x2, HEAP, lsl #32
    // 0xbf52e0: ldr             x0, [fp, #0x18]
    // 0xbf52e4: LoadField: r3 = r0->field_2f
    //     0xbf52e4: ldur            w3, [x0, #0x2f]
    // 0xbf52e8: DecompressPointer r3
    //     0xbf52e8: add             x3, x3, HEAP, lsl #32
    // 0xbf52ec: stp             x3, x2, [SP, #-0x10]!
    // 0xbf52f0: ldur            x16, [fp, #-8]
    // 0xbf52f4: SaveReg r16
    //     0xbf52f4: str             x16, [SP, #-8]!
    // 0xbf52f8: r0 = lerpDouble()
    //     0xbf52f8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf52fc: add             SP, SP, #0x18
    // 0xbf5300: stur            x0, [fp, #-8]
    // 0xbf5304: r0 = DataTableThemeData()
    //     0xbf5304: bl              #0xbf5388  ; AllocateDataTableThemeDataStub -> DataTableThemeData (size=0x34)
    // 0xbf5308: ldur            x1, [fp, #-0x10]
    // 0xbf530c: StoreField: r0->field_b = r1
    //     0xbf530c: stur            w1, [x0, #0xb]
    // 0xbf5310: ldur            x1, [fp, #-0x18]
    // 0xbf5314: StoreField: r0->field_f = r1
    //     0xbf5314: stur            w1, [x0, #0xf]
    // 0xbf5318: ldur            x1, [fp, #-0x20]
    // 0xbf531c: StoreField: r0->field_17 = r1
    //     0xbf531c: stur            w1, [x0, #0x17]
    // 0xbf5320: ldur            x1, [fp, #-0x28]
    // 0xbf5324: StoreField: r0->field_1b = r1
    //     0xbf5324: stur            w1, [x0, #0x1b]
    // 0xbf5328: ldur            x1, [fp, #-0x30]
    // 0xbf532c: StoreField: r0->field_23 = r1
    //     0xbf532c: stur            w1, [x0, #0x23]
    // 0xbf5330: ldur            x1, [fp, #-0x38]
    // 0xbf5334: StoreField: r0->field_27 = r1
    //     0xbf5334: stur            w1, [x0, #0x27]
    // 0xbf5338: ldur            x1, [fp, #-0x40]
    // 0xbf533c: StoreField: r0->field_2b = r1
    //     0xbf533c: stur            w1, [x0, #0x2b]
    // 0xbf5340: ldur            x1, [fp, #-8]
    // 0xbf5344: StoreField: r0->field_2f = r1
    //     0xbf5344: stur            w1, [x0, #0x2f]
    // 0xbf5348: LeaveFrame
    //     0xbf5348: mov             SP, fp
    //     0xbf534c: ldp             fp, lr, [SP], #0x10
    // 0xbf5350: ret
    //     0xbf5350: ret             
    // 0xbf5354: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5354: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5358: b               #0xbf50d0
    // 0xbf535c: SaveReg d0
    //     0xbf535c: str             q0, [SP, #-0x10]!
    // 0xbf5360: stp             x3, x4, [SP, #-0x10]!
    // 0xbf5364: stp             x1, x2, [SP, #-0x10]!
    // 0xbf5368: SaveReg r0
    //     0xbf5368: str             x0, [SP, #-8]!
    // 0xbf536c: r0 = AllocateDouble()
    //     0xbf536c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf5370: mov             x5, x0
    // 0xbf5374: RestoreReg r0
    //     0xbf5374: ldr             x0, [SP], #8
    // 0xbf5378: ldp             x1, x2, [SP], #0x10
    // 0xbf537c: ldp             x3, x4, [SP], #0x10
    // 0xbf5380: RestoreReg d0
    //     0xbf5380: ldr             q0, [SP], #0x10
    // 0xbf5384: b               #0xbf5174
  }
  _ ==(/* No info */) {
    // ** addr: 0xc87670, size: 0x280
    // 0xc87670: EnterFrame
    //     0xc87670: stp             fp, lr, [SP, #-0x10]!
    //     0xc87674: mov             fp, SP
    // 0xc87678: CheckStackOverflow
    //     0xc87678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8767c: cmp             SP, x16
    //     0xc87680: b.ls            #0xc878e8
    // 0xc87684: ldr             x1, [fp, #0x10]
    // 0xc87688: cmp             w1, NULL
    // 0xc8768c: b.ne            #0xc876a0
    // 0xc87690: r0 = false
    //     0xc87690: add             x0, NULL, #0x30  ; false
    // 0xc87694: LeaveFrame
    //     0xc87694: mov             SP, fp
    //     0xc87698: ldp             fp, lr, [SP], #0x10
    // 0xc8769c: ret
    //     0xc8769c: ret             
    // 0xc876a0: ldr             x2, [fp, #0x18]
    // 0xc876a4: cmp             w2, w1
    // 0xc876a8: b.ne            #0xc876bc
    // 0xc876ac: r0 = true
    //     0xc876ac: add             x0, NULL, #0x20  ; true
    // 0xc876b0: LeaveFrame
    //     0xc876b0: mov             SP, fp
    //     0xc876b4: ldp             fp, lr, [SP], #0x10
    // 0xc876b8: ret
    //     0xc876b8: ret             
    // 0xc876bc: r0 = 59
    //     0xc876bc: mov             x0, #0x3b
    // 0xc876c0: branchIfSmi(r1, 0xc876cc)
    //     0xc876c0: tbz             w1, #0, #0xc876cc
    // 0xc876c4: r0 = LoadClassIdInstr(r1)
    //     0xc876c4: ldur            x0, [x1, #-1]
    //     0xc876c8: ubfx            x0, x0, #0xc, #0x14
    // 0xc876cc: SaveReg r1
    //     0xc876cc: str             x1, [SP, #-8]!
    // 0xc876d0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc876d0: mov             x17, #0x57c5
    //     0xc876d4: add             lr, x0, x17
    //     0xc876d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc876dc: blr             lr
    // 0xc876e0: add             SP, SP, #8
    // 0xc876e4: r1 = LoadClassIdInstr(r0)
    //     0xc876e4: ldur            x1, [x0, #-1]
    //     0xc876e8: ubfx            x1, x1, #0xc, #0x14
    // 0xc876ec: r16 = DataTableThemeData
    //     0xc876ec: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3d0] Type: DataTableThemeData
    //     0xc876f0: ldr             x16, [x16, #0x3d0]
    // 0xc876f4: stp             x16, x0, [SP, #-0x10]!
    // 0xc876f8: mov             x0, x1
    // 0xc876fc: mov             lr, x0
    // 0xc87700: ldr             lr, [x21, lr, lsl #3]
    // 0xc87704: blr             lr
    // 0xc87708: add             SP, SP, #0x10
    // 0xc8770c: tbz             w0, #4, #0xc87720
    // 0xc87710: r0 = false
    //     0xc87710: add             x0, NULL, #0x30  ; false
    // 0xc87714: LeaveFrame
    //     0xc87714: mov             SP, fp
    //     0xc87718: ldp             fp, lr, [SP], #0x10
    // 0xc8771c: ret
    //     0xc8771c: ret             
    // 0xc87720: ldr             x1, [fp, #0x10]
    // 0xc87724: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc87724: mov             x0, #0x76
    //     0xc87728: tbz             w1, #0, #0xc87738
    //     0xc8772c: ldur            x0, [x1, #-1]
    //     0xc87730: ubfx            x0, x0, #0xc, #0x14
    //     0xc87734: lsl             x0, x0, #1
    // 0xc87738: r17 = 5626
    //     0xc87738: mov             x17, #0x15fa
    // 0xc8773c: cmp             w0, w17
    // 0xc87740: b.ne            #0xc878d8
    // 0xc87744: ldr             x2, [fp, #0x18]
    // 0xc87748: LoadField: r0 = r1->field_b
    //     0xc87748: ldur            w0, [x1, #0xb]
    // 0xc8774c: DecompressPointer r0
    //     0xc8774c: add             x0, x0, HEAP, lsl #32
    // 0xc87750: LoadField: r3 = r2->field_b
    //     0xc87750: ldur            w3, [x2, #0xb]
    // 0xc87754: DecompressPointer r3
    //     0xc87754: add             x3, x3, HEAP, lsl #32
    // 0xc87758: cmp             w0, w3
    // 0xc8775c: b.ne            #0xc878d8
    // 0xc87760: LoadField: r0 = r1->field_f
    //     0xc87760: ldur            w0, [x1, #0xf]
    // 0xc87764: DecompressPointer r0
    //     0xc87764: add             x0, x0, HEAP, lsl #32
    // 0xc87768: LoadField: r3 = r2->field_f
    //     0xc87768: ldur            w3, [x2, #0xf]
    // 0xc8776c: DecompressPointer r3
    //     0xc8776c: add             x3, x3, HEAP, lsl #32
    // 0xc87770: r4 = LoadClassIdInstr(r0)
    //     0xc87770: ldur            x4, [x0, #-1]
    //     0xc87774: ubfx            x4, x4, #0xc, #0x14
    // 0xc87778: stp             x3, x0, [SP, #-0x10]!
    // 0xc8777c: mov             x0, x4
    // 0xc87780: mov             lr, x0
    // 0xc87784: ldr             lr, [x21, lr, lsl #3]
    // 0xc87788: blr             lr
    // 0xc8778c: add             SP, SP, #0x10
    // 0xc87790: tbnz            w0, #4, #0xc878d8
    // 0xc87794: ldr             x2, [fp, #0x18]
    // 0xc87798: ldr             x1, [fp, #0x10]
    // 0xc8779c: LoadField: r0 = r1->field_17
    //     0xc8779c: ldur            w0, [x1, #0x17]
    // 0xc877a0: DecompressPointer r0
    //     0xc877a0: add             x0, x0, HEAP, lsl #32
    // 0xc877a4: LoadField: r3 = r2->field_17
    //     0xc877a4: ldur            w3, [x2, #0x17]
    // 0xc877a8: DecompressPointer r3
    //     0xc877a8: add             x3, x3, HEAP, lsl #32
    // 0xc877ac: cmp             w0, w3
    // 0xc877b0: b.ne            #0xc878d8
    // 0xc877b4: LoadField: r0 = r1->field_1b
    //     0xc877b4: ldur            w0, [x1, #0x1b]
    // 0xc877b8: DecompressPointer r0
    //     0xc877b8: add             x0, x0, HEAP, lsl #32
    // 0xc877bc: LoadField: r3 = r2->field_1b
    //     0xc877bc: ldur            w3, [x2, #0x1b]
    // 0xc877c0: DecompressPointer r3
    //     0xc877c0: add             x3, x3, HEAP, lsl #32
    // 0xc877c4: r4 = LoadClassIdInstr(r0)
    //     0xc877c4: ldur            x4, [x0, #-1]
    //     0xc877c8: ubfx            x4, x4, #0xc, #0x14
    // 0xc877cc: stp             x3, x0, [SP, #-0x10]!
    // 0xc877d0: mov             x0, x4
    // 0xc877d4: mov             lr, x0
    // 0xc877d8: ldr             lr, [x21, lr, lsl #3]
    // 0xc877dc: blr             lr
    // 0xc877e0: add             SP, SP, #0x10
    // 0xc877e4: tbnz            w0, #4, #0xc878d8
    // 0xc877e8: ldr             x2, [fp, #0x18]
    // 0xc877ec: ldr             x1, [fp, #0x10]
    // 0xc877f0: LoadField: r0 = r1->field_23
    //     0xc877f0: ldur            w0, [x1, #0x23]
    // 0xc877f4: DecompressPointer r0
    //     0xc877f4: add             x0, x0, HEAP, lsl #32
    // 0xc877f8: LoadField: r3 = r2->field_23
    //     0xc877f8: ldur            w3, [x2, #0x23]
    // 0xc877fc: DecompressPointer r3
    //     0xc877fc: add             x3, x3, HEAP, lsl #32
    // 0xc87800: r4 = LoadClassIdInstr(r0)
    //     0xc87800: ldur            x4, [x0, #-1]
    //     0xc87804: ubfx            x4, x4, #0xc, #0x14
    // 0xc87808: stp             x3, x0, [SP, #-0x10]!
    // 0xc8780c: mov             x0, x4
    // 0xc87810: mov             lr, x0
    // 0xc87814: ldr             lr, [x21, lr, lsl #3]
    // 0xc87818: blr             lr
    // 0xc8781c: add             SP, SP, #0x10
    // 0xc87820: tbnz            w0, #4, #0xc878d8
    // 0xc87824: ldr             x2, [fp, #0x18]
    // 0xc87828: ldr             x1, [fp, #0x10]
    // 0xc8782c: LoadField: r0 = r1->field_27
    //     0xc8782c: ldur            w0, [x1, #0x27]
    // 0xc87830: DecompressPointer r0
    //     0xc87830: add             x0, x0, HEAP, lsl #32
    // 0xc87834: LoadField: r3 = r2->field_27
    //     0xc87834: ldur            w3, [x2, #0x27]
    // 0xc87838: DecompressPointer r3
    //     0xc87838: add             x3, x3, HEAP, lsl #32
    // 0xc8783c: r4 = LoadClassIdInstr(r0)
    //     0xc8783c: ldur            x4, [x0, #-1]
    //     0xc87840: ubfx            x4, x4, #0xc, #0x14
    // 0xc87844: stp             x3, x0, [SP, #-0x10]!
    // 0xc87848: mov             x0, x4
    // 0xc8784c: mov             lr, x0
    // 0xc87850: ldr             lr, [x21, lr, lsl #3]
    // 0xc87854: blr             lr
    // 0xc87858: add             SP, SP, #0x10
    // 0xc8785c: tbnz            w0, #4, #0xc878d8
    // 0xc87860: ldr             x2, [fp, #0x18]
    // 0xc87864: ldr             x1, [fp, #0x10]
    // 0xc87868: LoadField: r0 = r1->field_2b
    //     0xc87868: ldur            w0, [x1, #0x2b]
    // 0xc8786c: DecompressPointer r0
    //     0xc8786c: add             x0, x0, HEAP, lsl #32
    // 0xc87870: LoadField: r3 = r2->field_2b
    //     0xc87870: ldur            w3, [x2, #0x2b]
    // 0xc87874: DecompressPointer r3
    //     0xc87874: add             x3, x3, HEAP, lsl #32
    // 0xc87878: r4 = LoadClassIdInstr(r0)
    //     0xc87878: ldur            x4, [x0, #-1]
    //     0xc8787c: ubfx            x4, x4, #0xc, #0x14
    // 0xc87880: stp             x3, x0, [SP, #-0x10]!
    // 0xc87884: mov             x0, x4
    // 0xc87888: mov             lr, x0
    // 0xc8788c: ldr             lr, [x21, lr, lsl #3]
    // 0xc87890: blr             lr
    // 0xc87894: add             SP, SP, #0x10
    // 0xc87898: tbnz            w0, #4, #0xc878d8
    // 0xc8789c: ldr             x1, [fp, #0x18]
    // 0xc878a0: ldr             x0, [fp, #0x10]
    // 0xc878a4: LoadField: r2 = r0->field_2f
    //     0xc878a4: ldur            w2, [x0, #0x2f]
    // 0xc878a8: DecompressPointer r2
    //     0xc878a8: add             x2, x2, HEAP, lsl #32
    // 0xc878ac: LoadField: r0 = r1->field_2f
    //     0xc878ac: ldur            w0, [x1, #0x2f]
    // 0xc878b0: DecompressPointer r0
    //     0xc878b0: add             x0, x0, HEAP, lsl #32
    // 0xc878b4: r1 = LoadClassIdInstr(r2)
    //     0xc878b4: ldur            x1, [x2, #-1]
    //     0xc878b8: ubfx            x1, x1, #0xc, #0x14
    // 0xc878bc: stp             x0, x2, [SP, #-0x10]!
    // 0xc878c0: mov             x0, x1
    // 0xc878c4: mov             lr, x0
    // 0xc878c8: ldr             lr, [x21, lr, lsl #3]
    // 0xc878cc: blr             lr
    // 0xc878d0: add             SP, SP, #0x10
    // 0xc878d4: b               #0xc878dc
    // 0xc878d8: r0 = false
    //     0xc878d8: add             x0, NULL, #0x30  ; false
    // 0xc878dc: LeaveFrame
    //     0xc878dc: mov             SP, fp
    //     0xc878e0: ldp             fp, lr, [SP], #0x10
    // 0xc878e4: ret
    //     0xc878e4: ret             
    // 0xc878e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc878e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc878ec: b               #0xc87684
  }
}

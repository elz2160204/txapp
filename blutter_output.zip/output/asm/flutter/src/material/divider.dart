// lib: , url: package:flutter/src/material/divider.dart

// class id: 1049225, size: 0x8
class :: {
}

// class id: 2807, size: 0x20, field offset: 0x1c
//   const constructor, 
class _DividerDefaultsM3 extends DividerThemeData {
}

// class id: 2808, size: 0x20, field offset: 0x1c
//   const constructor, 
class _DividerDefaultsM2 extends DividerThemeData {
}

// class id: 3857, size: 0x30, field offset: 0xc
//   const constructor, 
class Divider extends StatelessWidget {

  _Double field_c;
  _Double field_14;
  _Double field_1c;
  _Double field_24;
  Color field_2c;

  _ build(/* No info */) {
    // ** addr: 0xb1ff28, size: 0x15c
    // 0xb1ff28: EnterFrame
    //     0xb1ff28: stp             fp, lr, [SP, #-0x10]!
    //     0xb1ff2c: mov             fp, SP
    // 0xb1ff30: AllocStack(0x18)
    //     0xb1ff30: sub             SP, SP, #0x18
    // 0xb1ff34: CheckStackOverflow
    //     0xb1ff34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1ff38: cmp             SP, x16
    //     0xb1ff3c: b.ls            #0xb2007c
    // 0xb1ff40: ldr             x16, [fp, #0x10]
    // 0xb1ff44: SaveReg r16
    //     0xb1ff44: str             x16, [SP, #-8]!
    // 0xb1ff48: r0 = of()
    //     0xb1ff48: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1ff4c: add             SP, SP, #8
    // 0xb1ff50: stur            x0, [fp, #-8]
    // 0xb1ff54: ldr             x16, [fp, #0x10]
    // 0xb1ff58: SaveReg r16
    //     0xb1ff58: str             x16, [SP, #-8]!
    // 0xb1ff5c: r0 = of()
    //     0xb1ff5c: bl              #0xb2031c  ; [package:flutter/src/material/divider_theme.dart] DividerTheme::of
    // 0xb1ff60: add             SP, SP, #8
    // 0xb1ff64: ldur            x0, [fp, #-8]
    // 0xb1ff68: LoadField: r1 = r0->field_2b
    //     0xb1ff68: ldur            w1, [x0, #0x2b]
    // 0xb1ff6c: DecompressPointer r1
    //     0xb1ff6c: add             x1, x1, HEAP, lsl #32
    // 0xb1ff70: tbz             w1, #4, #0xb1ff74
    // 0xb1ff74: r0 = EdgeInsetsDirectional()
    //     0xb1ff74: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xb1ff78: d0 = 16.000000
    //     0xb1ff78: fmov            d0, #16.00000000
    // 0xb1ff7c: stur            x0, [fp, #-8]
    // 0xb1ff80: StoreField: r0->field_7 = d0
    //     0xb1ff80: stur            d0, [x0, #7]
    // 0xb1ff84: d1 = 0.000000
    //     0xb1ff84: eor             v1.16b, v1.16b, v1.16b
    // 0xb1ff88: StoreField: r0->field_f = d1
    //     0xb1ff88: stur            d1, [x0, #0xf]
    // 0xb1ff8c: StoreField: r0->field_17 = d0
    //     0xb1ff8c: stur            d0, [x0, #0x17]
    // 0xb1ff90: StoreField: r0->field_1f = d1
    //     0xb1ff90: stur            d1, [x0, #0x1f]
    // 0xb1ff94: ldr             x16, [fp, #0x10]
    // 0xb1ff98: SaveReg r16
    //     0xb1ff98: str             x16, [SP, #-8]!
    // 0xb1ff9c: d0 = 0.500000
    //     0xb1ff9c: fmov            d0, #0.50000000
    // 0xb1ffa0: SaveReg d0
    //     0xb1ffa0: str             d0, [SP, #-8]!
    // 0xb1ffa4: r16 = Instance_Color
    //     0xb1ffa4: add             x16, PP, #0x26, lsl #12  ; [pp+0x268e0] Obj!Color@b5d401
    //     0xb1ffa8: ldr             x16, [x16, #0x8e0]
    // 0xb1ffac: SaveReg r16
    //     0xb1ffac: str             x16, [SP, #-8]!
    // 0xb1ffb0: r4 = const [0, 0x3, 0x3, 0x2, color, 0x2, null]
    //     0xb1ffb0: add             x4, PP, #0x26, lsl #12  ; [pp+0x26940] List(7) [0, 0x3, 0x3, 0x2, "color", 0x2, Null]
    //     0xb1ffb4: ldr             x4, [x4, #0x940]
    // 0xb1ffb8: r0 = createBorderSide()
    //     0xb1ffb8: bl              #0xb20084  ; [package:flutter/src/material/divider.dart] Divider::createBorderSide
    // 0xb1ffbc: add             SP, SP, #0x18
    // 0xb1ffc0: stur            x0, [fp, #-0x10]
    // 0xb1ffc4: r0 = Border()
    //     0xb1ffc4: bl              #0x70e0c8  ; AllocateBorderStub -> Border (size=0x18)
    // 0xb1ffc8: mov             x1, x0
    // 0xb1ffcc: r0 = Instance_BorderSide
    //     0xb1ffcc: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xb1ffd0: ldr             x0, [x0, #0x2f0]
    // 0xb1ffd4: stur            x1, [fp, #-0x18]
    // 0xb1ffd8: StoreField: r1->field_7 = r0
    //     0xb1ffd8: stur            w0, [x1, #7]
    // 0xb1ffdc: StoreField: r1->field_b = r0
    //     0xb1ffdc: stur            w0, [x1, #0xb]
    // 0xb1ffe0: ldur            x2, [fp, #-0x10]
    // 0xb1ffe4: StoreField: r1->field_f = r2
    //     0xb1ffe4: stur            w2, [x1, #0xf]
    // 0xb1ffe8: StoreField: r1->field_13 = r0
    //     0xb1ffe8: stur            w0, [x1, #0x13]
    // 0xb1ffec: r0 = BoxDecoration()
    //     0xb1ffec: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xb1fff0: mov             x1, x0
    // 0xb1fff4: ldur            x0, [fp, #-0x18]
    // 0xb1fff8: stur            x1, [fp, #-0x10]
    // 0xb1fffc: StoreField: r1->field_f = r0
    //     0xb1fffc: stur            w0, [x1, #0xf]
    // 0xb20000: r0 = Instance_BoxShape
    //     0xb20000: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0xb20004: ldr             x0, [x0, #0xe68]
    // 0xb20008: StoreField: r1->field_23 = r0
    //     0xb20008: stur            w0, [x1, #0x23]
    // 0xb2000c: r0 = Container()
    //     0xb2000c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb20010: stur            x0, [fp, #-0x18]
    // 0xb20014: r16 = 0.500000
    //     0xb20014: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c760] 0.5
    //     0xb20018: ldr             x16, [x16, #0x760]
    // 0xb2001c: stp             x16, x0, [SP, #-0x10]!
    // 0xb20020: ldur            x16, [fp, #-8]
    // 0xb20024: ldur            lr, [fp, #-0x10]
    // 0xb20028: stp             lr, x16, [SP, #-0x10]!
    // 0xb2002c: r4 = const [0, 0x4, 0x4, 0x1, decoration, 0x3, height, 0x1, margin, 0x2, null]
    //     0xb2002c: add             x4, PP, #0x37, lsl #12  ; [pp+0x37918] List(11) [0, 0x4, 0x4, 0x1, "decoration", 0x3, "height", 0x1, "margin", 0x2, Null]
    //     0xb20030: ldr             x4, [x4, #0x918]
    // 0xb20034: r0 = Container()
    //     0xb20034: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb20038: add             SP, SP, #0x20
    // 0xb2003c: r0 = Center()
    //     0xb2003c: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xb20040: mov             x1, x0
    // 0xb20044: r0 = Instance_Alignment
    //     0xb20044: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb20048: ldr             x0, [x0, #0xc70]
    // 0xb2004c: stur            x1, [fp, #-8]
    // 0xb20050: StoreField: r1->field_f = r0
    //     0xb20050: stur            w0, [x1, #0xf]
    // 0xb20054: ldur            x0, [fp, #-0x18]
    // 0xb20058: StoreField: r1->field_b = r0
    //     0xb20058: stur            w0, [x1, #0xb]
    // 0xb2005c: r0 = SizedBox()
    //     0xb2005c: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb20060: r1 = 1.000000
    //     0xb20060: ldr             x1, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb20064: StoreField: r0->field_13 = r1
    //     0xb20064: stur            w1, [x0, #0x13]
    // 0xb20068: ldur            x1, [fp, #-8]
    // 0xb2006c: StoreField: r0->field_b = r1
    //     0xb2006c: stur            w1, [x0, #0xb]
    // 0xb20070: LeaveFrame
    //     0xb20070: mov             SP, fp
    //     0xb20074: ldp             fp, lr, [SP], #0x10
    // 0xb20078: ret
    //     0xb20078: ret             
    // 0xb2007c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2007c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb20080: b               #0xb1ff40
  }
  static _ createBorderSide(/* No info */) {
    // ** addr: 0xb20084, size: 0x280
    // 0xb20084: EnterFrame
    //     0xb20084: stp             fp, lr, [SP, #-0x10]!
    //     0xb20088: mov             fp, SP
    // 0xb2008c: AllocStack(0x18)
    //     0xb2008c: sub             SP, SP, #0x18
    // 0xb20090: SetupParameters(dynamic _ /* r3, fp-0x10 */, dynamic _ /* d0, fp-0x18 */, {dynamic color = Null /* r0, fp-0x8 */})
    //     0xb20090: mov             x0, x4
    //     0xb20094: ldur            w1, [x0, #0x13]
    //     0xb20098: add             x1, x1, HEAP, lsl #32
    //     0xb2009c: sub             x2, x1, #4
    //     0xb200a0: add             x3, fp, w2, sxtw #2
    //     0xb200a4: ldr             x3, [x3, #0x18]
    //     0xb200a8: stur            x3, [fp, #-0x10]
    //     0xb200ac: add             x4, fp, w2, sxtw #2
    //     0xb200b0: ldr             d0, [x4, #0x10]
    //     0xb200b4: stur            d0, [fp, #-0x18]
    //     0xb200b8: ldur            w2, [x0, #0x1f]
    //     0xb200bc: add             x2, x2, HEAP, lsl #32
    //     0xb200c0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdae8] "color"
    //     0xb200c4: ldr             x16, [x16, #0xae8]
    //     0xb200c8: cmp             w2, w16
    //     0xb200cc: b.ne            #0xb200ec
    //     0xb200d0: ldur            w2, [x0, #0x23]
    //     0xb200d4: add             x2, x2, HEAP, lsl #32
    //     0xb200d8: sub             w0, w1, w2
    //     0xb200dc: add             x1, fp, w0, sxtw #2
    //     0xb200e0: ldr             x1, [x1, #8]
    //     0xb200e4: mov             x0, x1
    //     0xb200e8: b               #0xb200f0
    //     0xb200ec: mov             x0, NULL
    //     0xb200f0: stur            x0, [fp, #-8]
    // 0xb200f4: CheckStackOverflow
    //     0xb200f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb200f8: cmp             SP, x16
    //     0xb200fc: b.ls            #0xb202fc
    // 0xb20100: SaveReg r3
    //     0xb20100: str             x3, [SP, #-8]!
    // 0xb20104: r0 = of()
    //     0xb20104: bl              #0xb2031c  ; [package:flutter/src/material/divider_theme.dart] DividerTheme::of
    // 0xb20108: add             SP, SP, #8
    // 0xb2010c: ldur            x0, [fp, #-0x10]
    // 0xb20110: cmp             w0, NULL
    // 0xb20114: b.eq            #0xb201b4
    // 0xb20118: SaveReg r0
    //     0xb20118: str             x0, [SP, #-8]!
    // 0xb2011c: r0 = of()
    //     0xb2011c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb20120: add             SP, SP, #8
    // 0xb20124: LoadField: r1 = r0->field_2b
    //     0xb20124: ldur            w1, [x0, #0x2b]
    // 0xb20128: DecompressPointer r1
    //     0xb20128: add             x1, x1, HEAP, lsl #32
    // 0xb2012c: tbnz            w1, #4, #0xb2016c
    // 0xb20130: ldur            x0, [fp, #-0x10]
    // 0xb20134: r0 = _DividerDefaultsM3()
    //     0xb20134: bl              #0xb20310  ; Allocate_DividerDefaultsM3Stub -> _DividerDefaultsM3 (size=0x20)
    // 0xb20138: mov             x1, x0
    // 0xb2013c: ldur            x0, [fp, #-0x10]
    // 0xb20140: StoreField: r1->field_1b = r0
    //     0xb20140: stur            w0, [x1, #0x1b]
    // 0xb20144: r2 = 16.000000
    //     0xb20144: add             x2, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0xb20148: ldr             x2, [x2, #0xda8]
    // 0xb2014c: StoreField: r1->field_b = r2
    //     0xb2014c: stur            w2, [x1, #0xb]
    // 0xb20150: r0 = 1.000000
    //     0xb20150: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb20154: StoreField: r1->field_f = r0
    //     0xb20154: stur            w0, [x1, #0xf]
    // 0xb20158: r3 = 0.000000
    //     0xb20158: ldr             x3, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xb2015c: StoreField: r1->field_13 = r3
    //     0xb2015c: stur            w3, [x1, #0x13]
    // 0xb20160: StoreField: r1->field_17 = r3
    //     0xb20160: stur            w3, [x1, #0x17]
    // 0xb20164: mov             x0, x1
    // 0xb20168: b               #0xb201ac
    // 0xb2016c: ldur            x0, [fp, #-0x10]
    // 0xb20170: r3 = 0.000000
    //     0xb20170: ldr             x3, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xb20174: r2 = 16.000000
    //     0xb20174: add             x2, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0xb20178: ldr             x2, [x2, #0xda8]
    // 0xb2017c: r0 = _DividerDefaultsM2()
    //     0xb2017c: bl              #0xb20304  ; Allocate_DividerDefaultsM2Stub -> _DividerDefaultsM2 (size=0x20)
    // 0xb20180: mov             x1, x0
    // 0xb20184: ldur            x0, [fp, #-0x10]
    // 0xb20188: StoreField: r1->field_1b = r0
    //     0xb20188: stur            w0, [x1, #0x1b]
    // 0xb2018c: r0 = 16.000000
    //     0xb2018c: add             x0, PP, #0x25, lsl #12  ; [pp+0x25da8] 16
    //     0xb20190: ldr             x0, [x0, #0xda8]
    // 0xb20194: StoreField: r1->field_b = r0
    //     0xb20194: stur            w0, [x1, #0xb]
    // 0xb20198: r0 = 0.000000
    //     0xb20198: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xb2019c: StoreField: r1->field_f = r0
    //     0xb2019c: stur            w0, [x1, #0xf]
    // 0xb201a0: StoreField: r1->field_13 = r0
    //     0xb201a0: stur            w0, [x1, #0x13]
    // 0xb201a4: StoreField: r1->field_17 = r0
    //     0xb201a4: stur            w0, [x1, #0x17]
    // 0xb201a8: mov             x0, x1
    // 0xb201ac: mov             x1, x0
    // 0xb201b0: b               #0xb201b8
    // 0xb201b4: r1 = Null
    //     0xb201b4: mov             x1, NULL
    // 0xb201b8: ldur            x0, [fp, #-8]
    // 0xb201bc: cmp             w0, NULL
    // 0xb201c0: b.ne            #0xb201c8
    // 0xb201c4: r0 = Null
    //     0xb201c4: mov             x0, NULL
    // 0xb201c8: cmp             w0, NULL
    // 0xb201cc: b.ne            #0xb20268
    // 0xb201d0: cmp             w1, NULL
    // 0xb201d4: b.ne            #0xb201e0
    // 0xb201d8: r0 = Null
    //     0xb201d8: mov             x0, NULL
    // 0xb201dc: b               #0xb20268
    // 0xb201e0: r0 = LoadClassIdInstr(r1)
    //     0xb201e0: ldur            x0, [x1, #-1]
    //     0xb201e4: ubfx            x0, x0, #0xc, #0x14
    // 0xb201e8: lsl             x0, x0, #1
    // 0xb201ec: r17 = 5612
    //     0xb201ec: mov             x17, #0x15ec
    // 0xb201f0: cmp             w0, w17
    // 0xb201f4: b.ne            #0xb20204
    // 0xb201f8: LoadField: r0 = r1->field_7
    //     0xb201f8: ldur            w0, [x1, #7]
    // 0xb201fc: DecompressPointer r0
    //     0xb201fc: add             x0, x0, HEAP, lsl #32
    // 0xb20200: b               #0xb20268
    // 0xb20204: r17 = 5614
    //     0xb20204: mov             x17, #0x15ee
    // 0xb20208: cmp             w0, w17
    // 0xb2020c: b.ne            #0xb20248
    // 0xb20210: LoadField: r0 = r1->field_1b
    //     0xb20210: ldur            w0, [x1, #0x1b]
    // 0xb20214: DecompressPointer r0
    //     0xb20214: add             x0, x0, HEAP, lsl #32
    // 0xb20218: SaveReg r0
    //     0xb20218: str             x0, [SP, #-8]!
    // 0xb2021c: r0 = of()
    //     0xb2021c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb20220: add             SP, SP, #8
    // 0xb20224: LoadField: r1 = r0->field_3f
    //     0xb20224: ldur            w1, [x0, #0x3f]
    // 0xb20228: DecompressPointer r1
    //     0xb20228: add             x1, x1, HEAP, lsl #32
    // 0xb2022c: LoadField: r0 = r1->field_67
    //     0xb2022c: ldur            w0, [x1, #0x67]
    // 0xb20230: DecompressPointer r0
    //     0xb20230: add             x0, x0, HEAP, lsl #32
    // 0xb20234: cmp             w0, NULL
    // 0xb20238: b.ne            #0xb20268
    // 0xb2023c: LoadField: r0 = r1->field_4f
    //     0xb2023c: ldur            w0, [x1, #0x4f]
    // 0xb20240: DecompressPointer r0
    //     0xb20240: add             x0, x0, HEAP, lsl #32
    // 0xb20244: b               #0xb20268
    // 0xb20248: LoadField: r0 = r1->field_1b
    //     0xb20248: ldur            w0, [x1, #0x1b]
    // 0xb2024c: DecompressPointer r0
    //     0xb2024c: add             x0, x0, HEAP, lsl #32
    // 0xb20250: SaveReg r0
    //     0xb20250: str             x0, [SP, #-8]!
    // 0xb20254: r0 = of()
    //     0xb20254: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb20258: add             SP, SP, #8
    // 0xb2025c: LoadField: r1 = r0->field_4b
    //     0xb2025c: ldur            w1, [x0, #0x4b]
    // 0xb20260: DecompressPointer r1
    //     0xb20260: add             x1, x1, HEAP, lsl #32
    // 0xb20264: mov             x0, x1
    // 0xb20268: stur            x0, [fp, #-8]
    // 0xb2026c: cmp             w0, NULL
    // 0xb20270: b.ne            #0xb202b8
    // 0xb20274: ldur            d0, [fp, #-0x18]
    // 0xb20278: r0 = BorderSide()
    //     0xb20278: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xb2027c: mov             x1, x0
    // 0xb20280: r0 = Instance_Color
    //     0xb20280: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xb20284: ldr             x0, [x0, #0xf38]
    // 0xb20288: StoreField: r1->field_7 = r0
    //     0xb20288: stur            w0, [x1, #7]
    // 0xb2028c: ldur            d0, [fp, #-0x18]
    // 0xb20290: StoreField: r1->field_b = d0
    //     0xb20290: stur            d0, [x1, #0xb]
    // 0xb20294: r2 = Instance_BorderStyle
    //     0xb20294: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xb20298: ldr             x2, [x2, #0xbd0]
    // 0xb2029c: StoreField: r1->field_13 = r2
    //     0xb2029c: stur            w2, [x1, #0x13]
    // 0xb202a0: d1 = -1.000000
    //     0xb202a0: fmov            d1, #-1.00000000
    // 0xb202a4: StoreField: r1->field_17 = d1
    //     0xb202a4: stur            d1, [x1, #0x17]
    // 0xb202a8: mov             x0, x1
    // 0xb202ac: LeaveFrame
    //     0xb202ac: mov             SP, fp
    //     0xb202b0: ldp             fp, lr, [SP], #0x10
    // 0xb202b4: ret
    //     0xb202b4: ret             
    // 0xb202b8: ldur            d0, [fp, #-0x18]
    // 0xb202bc: r2 = Instance_BorderStyle
    //     0xb202bc: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xb202c0: ldr             x2, [x2, #0xbd0]
    // 0xb202c4: d1 = -1.000000
    //     0xb202c4: fmov            d1, #-1.00000000
    // 0xb202c8: r0 = BorderSide()
    //     0xb202c8: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xb202cc: ldur            x1, [fp, #-8]
    // 0xb202d0: StoreField: r0->field_7 = r1
    //     0xb202d0: stur            w1, [x0, #7]
    // 0xb202d4: ldur            d0, [fp, #-0x18]
    // 0xb202d8: StoreField: r0->field_b = d0
    //     0xb202d8: stur            d0, [x0, #0xb]
    // 0xb202dc: r1 = Instance_BorderStyle
    //     0xb202dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xb202e0: ldr             x1, [x1, #0xbd0]
    // 0xb202e4: StoreField: r0->field_13 = r1
    //     0xb202e4: stur            w1, [x0, #0x13]
    // 0xb202e8: d0 = -1.000000
    //     0xb202e8: fmov            d0, #-1.00000000
    // 0xb202ec: StoreField: r0->field_17 = d0
    //     0xb202ec: stur            d0, [x0, #0x17]
    // 0xb202f0: LeaveFrame
    //     0xb202f0: mov             SP, fp
    //     0xb202f4: ldp             fp, lr, [SP], #0x10
    // 0xb202f8: ret
    //     0xb202f8: ret             
    // 0xb202fc: r0 = StackOverflowSharedWithFPURegs()
    //     0xb202fc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xb20300: b               #0xb20100
  }
}

// lib: , url: package:flutter/src/material/outlined_button.dart

// class id: 1049285, size: 0x8
class :: {
}

// class id: 2222, size: 0x14, field offset: 0xc
class _OutlinedButtonDefaultMouseCursor extends __IconButtonDefaultMouseCursor&MaterialStateProperty&Diagnosticable {
}

// class id: 2232, size: 0x10, field offset: 0xc
class _OutlinedButtonDefaultOverlay extends __ElevatedButtonDefaultColor&MaterialStateProperty&Diagnosticable {
}

// class id: 2233, size: 0x14, field offset: 0xc
class _OutlinedButtonDefaultColor extends __ElevatedButtonDefaultColor&MaterialStateProperty&Diagnosticable {
}

// class id: 2831, size: 0x68, field offset: 0x60
class _OutlinedButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x64

  [closure] BorderSide <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x84d7a0, size: 0x188
    // 0x84d7a0: EnterFrame
    //     0x84d7a0: stp             fp, lr, [SP, #-0x10]!
    //     0x84d7a4: mov             fp, SP
    // 0x84d7a8: AllocStack(0x10)
    //     0x84d7a8: sub             SP, SP, #0x10
    // 0x84d7ac: SetupParameters()
    //     0x84d7ac: ldr             x0, [fp, #0x18]
    //     0x84d7b0: ldur            w1, [x0, #0x17]
    //     0x84d7b4: add             x1, x1, HEAP, lsl #32
    //     0x84d7b8: stur            x1, [fp, #-8]
    // 0x84d7bc: CheckStackOverflow
    //     0x84d7bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d7c0: cmp             SP, x16
    //     0x84d7c4: b.ls            #0x84d920
    // 0x84d7c8: ldr             x0, [fp, #0x10]
    // 0x84d7cc: r2 = LoadClassIdInstr(r0)
    //     0x84d7cc: ldur            x2, [x0, #-1]
    //     0x84d7d0: ubfx            x2, x2, #0xc, #0x14
    // 0x84d7d4: r16 = Instance_MaterialState
    //     0x84d7d4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x84d7d8: ldr             x16, [x16, #0x2a0]
    // 0x84d7dc: stp             x16, x0, [SP, #-0x10]!
    // 0x84d7e0: mov             x0, x2
    // 0x84d7e4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x84d7e4: mov             x17, #0xc98a
    //     0x84d7e8: add             lr, x0, x17
    //     0x84d7ec: ldr             lr, [x21, lr, lsl #3]
    //     0x84d7f0: blr             lr
    // 0x84d7f4: add             SP, SP, #0x10
    // 0x84d7f8: tbnz            w0, #4, #0x84d888
    // 0x84d7fc: ldur            x0, [fp, #-8]
    // 0x84d800: LoadField: r1 = r0->field_f
    //     0x84d800: ldur            w1, [x0, #0xf]
    // 0x84d804: DecompressPointer r1
    //     0x84d804: add             x1, x1, HEAP, lsl #32
    // 0x84d808: LoadField: r0 = r1->field_63
    //     0x84d808: ldur            w0, [x1, #0x63]
    // 0x84d80c: DecompressPointer r0
    //     0x84d80c: add             x0, x0, HEAP, lsl #32
    // 0x84d810: r16 = Sentinel
    //     0x84d810: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84d814: cmp             w0, w16
    // 0x84d818: b.ne            #0x84d828
    // 0x84d81c: r2 = _colors
    //     0x84d81c: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0x84d820: ldr             x2, [x2, #0x6e8]
    // 0x84d824: r0 = InitLateFinalInstanceField()
    //     0x84d824: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x84d828: LoadField: r1 = r0->field_57
    //     0x84d828: ldur            w1, [x0, #0x57]
    // 0x84d82c: DecompressPointer r1
    //     0x84d82c: add             x1, x1, HEAP, lsl #32
    // 0x84d830: SaveReg r1
    //     0x84d830: str             x1, [SP, #-8]!
    // 0x84d834: d0 = 0.120000
    //     0x84d834: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x84d838: ldr             d0, [x17, #0xf48]
    // 0x84d83c: SaveReg d0
    //     0x84d83c: str             d0, [SP, #-8]!
    // 0x84d840: r0 = withOpacity()
    //     0x84d840: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x84d844: add             SP, SP, #0x10
    // 0x84d848: stur            x0, [fp, #-0x10]
    // 0x84d84c: r0 = BorderSide()
    //     0x84d84c: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x84d850: mov             x1, x0
    // 0x84d854: ldur            x0, [fp, #-0x10]
    // 0x84d858: StoreField: r1->field_7 = r0
    //     0x84d858: stur            w0, [x1, #7]
    // 0x84d85c: d0 = 1.000000
    //     0x84d85c: fmov            d0, #1.00000000
    // 0x84d860: StoreField: r1->field_b = d0
    //     0x84d860: stur            d0, [x1, #0xb]
    // 0x84d864: r2 = Instance_BorderStyle
    //     0x84d864: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x84d868: ldr             x2, [x2, #0xbd0]
    // 0x84d86c: StoreField: r1->field_13 = r2
    //     0x84d86c: stur            w2, [x1, #0x13]
    // 0x84d870: d1 = -1.000000
    //     0x84d870: fmov            d1, #-1.00000000
    // 0x84d874: StoreField: r1->field_17 = d1
    //     0x84d874: stur            d1, [x1, #0x17]
    // 0x84d878: mov             x0, x1
    // 0x84d87c: LeaveFrame
    //     0x84d87c: mov             SP, fp
    //     0x84d880: ldp             fp, lr, [SP], #0x10
    // 0x84d884: ret
    //     0x84d884: ret             
    // 0x84d888: ldur            x0, [fp, #-8]
    // 0x84d88c: r2 = Instance_BorderStyle
    //     0x84d88c: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x84d890: ldr             x2, [x2, #0xbd0]
    // 0x84d894: d0 = 1.000000
    //     0x84d894: fmov            d0, #1.00000000
    // 0x84d898: d1 = -1.000000
    //     0x84d898: fmov            d1, #-1.00000000
    // 0x84d89c: LoadField: r1 = r0->field_f
    //     0x84d89c: ldur            w1, [x0, #0xf]
    // 0x84d8a0: DecompressPointer r1
    //     0x84d8a0: add             x1, x1, HEAP, lsl #32
    // 0x84d8a4: LoadField: r0 = r1->field_63
    //     0x84d8a4: ldur            w0, [x1, #0x63]
    // 0x84d8a8: DecompressPointer r0
    //     0x84d8a8: add             x0, x0, HEAP, lsl #32
    // 0x84d8ac: r16 = Sentinel
    //     0x84d8ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84d8b0: cmp             w0, w16
    // 0x84d8b4: b.ne            #0x84d8c4
    // 0x84d8b8: r2 = _colors
    //     0x84d8b8: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0x84d8bc: ldr             x2, [x2, #0x6e8]
    // 0x84d8c0: r0 = InitLateFinalInstanceField()
    //     0x84d8c0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x84d8c4: LoadField: r1 = r0->field_63
    //     0x84d8c4: ldur            w1, [x0, #0x63]
    // 0x84d8c8: DecompressPointer r1
    //     0x84d8c8: add             x1, x1, HEAP, lsl #32
    // 0x84d8cc: cmp             w1, NULL
    // 0x84d8d0: b.ne            #0x84d8e4
    // 0x84d8d4: LoadField: r1 = r0->field_4f
    //     0x84d8d4: ldur            w1, [x0, #0x4f]
    // 0x84d8d8: DecompressPointer r1
    //     0x84d8d8: add             x1, x1, HEAP, lsl #32
    // 0x84d8dc: mov             x0, x1
    // 0x84d8e0: b               #0x84d8e8
    // 0x84d8e4: mov             x0, x1
    // 0x84d8e8: stur            x0, [fp, #-8]
    // 0x84d8ec: r0 = BorderSide()
    //     0x84d8ec: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x84d8f0: ldur            x1, [fp, #-8]
    // 0x84d8f4: StoreField: r0->field_7 = r1
    //     0x84d8f4: stur            w1, [x0, #7]
    // 0x84d8f8: d0 = 1.000000
    //     0x84d8f8: fmov            d0, #1.00000000
    // 0x84d8fc: StoreField: r0->field_b = d0
    //     0x84d8fc: stur            d0, [x0, #0xb]
    // 0x84d900: r1 = Instance_BorderStyle
    //     0x84d900: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x84d904: ldr             x1, [x1, #0xbd0]
    // 0x84d908: StoreField: r0->field_13 = r1
    //     0x84d908: stur            w1, [x0, #0x13]
    // 0x84d90c: d0 = -1.000000
    //     0x84d90c: fmov            d0, #-1.00000000
    // 0x84d910: StoreField: r0->field_17 = d0
    //     0x84d910: stur            d0, [x0, #0x17]
    // 0x84d914: LeaveFrame
    //     0x84d914: mov             SP, fp
    //     0x84d918: ldp             fp, lr, [SP], #0x10
    // 0x84d91c: ret
    //     0x84d91c: ret             
    // 0x84d920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d924: b               #0x84d7c8
  }
  get _ mouseCursor(/* No info */) {
    // ** addr: 0xce5a34, size: 0x50
    // 0xce5a34: EnterFrame
    //     0xce5a34: stp             fp, lr, [SP, #-0x10]!
    //     0xce5a38: mov             fp, SP
    // 0xce5a3c: CheckStackOverflow
    //     0xce5a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5a40: cmp             SP, x16
    //     0xce5a44: b.ls            #0xce5a7c
    // 0xce5a48: r1 = Function '<anonymous closure>':.
    //     0xce5a48: add             x1, PP, #0x53, lsl #12  ; [pp+0x530a0] AnonymousClosure: (0x5b5d20), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::mouseCursor (0xce5a84)
    //     0xce5a4c: ldr             x1, [x1, #0xa0]
    // 0xce5a50: r2 = Null
    //     0xce5a50: mov             x2, NULL
    // 0xce5a54: r0 = AllocateClosure()
    //     0xce5a54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce5a58: r16 = <MouseCursor?>
    //     0xce5a58: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0xce5a5c: ldr             x16, [x16, #0x8b8]
    // 0xce5a60: stp             x0, x16, [SP, #-0x10]!
    // 0xce5a64: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce5a64: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce5a68: r0 = resolveWith()
    //     0xce5a68: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce5a6c: add             SP, SP, #0x10
    // 0xce5a70: LeaveFrame
    //     0xce5a70: mov             SP, fp
    //     0xce5a74: ldp             fp, lr, [SP], #0x10
    // 0xce5a78: ret
    //     0xce5a78: ret             
    // 0xce5a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5a7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5a80: b               #0xce5a48
  }
  get _ padding(/* No info */) {
    // ** addr: 0xce5b7c, size: 0x5c
    // 0xce5b7c: EnterFrame
    //     0xce5b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xce5b80: mov             fp, SP
    // 0xce5b84: AllocStack(0x8)
    //     0xce5b84: sub             SP, SP, #8
    // 0xce5b88: CheckStackOverflow
    //     0xce5b88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5b8c: cmp             SP, x16
    //     0xce5b90: b.ls            #0xce5bd0
    // 0xce5b94: ldr             x0, [fp, #0x10]
    // 0xce5b98: LoadField: r1 = r0->field_5f
    //     0xce5b98: ldur            w1, [x0, #0x5f]
    // 0xce5b9c: DecompressPointer r1
    //     0xce5b9c: add             x1, x1, HEAP, lsl #32
    // 0xce5ba0: SaveReg r1
    //     0xce5ba0: str             x1, [SP, #-8]!
    // 0xce5ba4: r0 = _scaledPadding()
    //     0xce5ba4: bl              #0xc14b4c  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0xce5ba8: add             SP, SP, #8
    // 0xce5bac: r1 = <EdgeInsetsGeometry>
    //     0xce5bac: add             x1, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xce5bb0: ldr             x1, [x1, #0x8c8]
    // 0xce5bb4: stur            x0, [fp, #-8]
    // 0xce5bb8: r0 = MaterialStatePropertyAll()
    //     0xce5bb8: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xce5bbc: ldur            x1, [fp, #-8]
    // 0xce5bc0: StoreField: r0->field_b = r1
    //     0xce5bc0: stur            w1, [x0, #0xb]
    // 0xce5bc4: LeaveFrame
    //     0xce5bc4: mov             SP, fp
    //     0xce5bc8: ldp             fp, lr, [SP], #0x10
    // 0xce5bcc: ret
    //     0xce5bcc: ret             
    // 0xce5bd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5bd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5bd4: b               #0xce5b94
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xce6c78, size: 0x64
    // 0xce6c78: EnterFrame
    //     0xce6c78: stp             fp, lr, [SP, #-0x10]!
    //     0xce6c7c: mov             fp, SP
    // 0xce6c80: CheckStackOverflow
    //     0xce6c80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce6c84: cmp             SP, x16
    //     0xce6c88: b.ls            #0xce6cd4
    // 0xce6c8c: r1 = 1
    //     0xce6c8c: mov             x1, #1
    // 0xce6c90: r0 = AllocateContext()
    //     0xce6c90: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce6c94: mov             x1, x0
    // 0xce6c98: ldr             x0, [fp, #0x10]
    // 0xce6c9c: StoreField: r1->field_f = r0
    //     0xce6c9c: stur            w0, [x1, #0xf]
    // 0xce6ca0: mov             x2, x1
    // 0xce6ca4: r1 = Function '<anonymous closure>':.
    //     0xce6ca4: add             x1, PP, #0x53, lsl #12  ; [pp+0x530a8] AnonymousClosure: (0xce6cdc), in [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3::overlayColor (0xce6c78)
    //     0xce6ca8: ldr             x1, [x1, #0xa8]
    // 0xce6cac: r0 = AllocateClosure()
    //     0xce6cac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce6cb0: r16 = <Color?>
    //     0xce6cb0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce6cb4: ldr             x16, [x16, #0xf68]
    // 0xce6cb8: stp             x0, x16, [SP, #-0x10]!
    // 0xce6cbc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce6cbc: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce6cc0: r0 = resolveWith()
    //     0xce6cc0: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce6cc4: add             SP, SP, #0x10
    // 0xce6cc8: LeaveFrame
    //     0xce6cc8: mov             SP, fp
    //     0xce6ccc: ldp             fp, lr, [SP], #0x10
    // 0xce6cd0: ret
    //     0xce6cd0: ret             
    // 0xce6cd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6cd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6cd8: b               #0xce6c8c
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce6cdc, size: 0x1f4
    // 0xce6cdc: EnterFrame
    //     0xce6cdc: stp             fp, lr, [SP, #-0x10]!
    //     0xce6ce0: mov             fp, SP
    // 0xce6ce4: AllocStack(0x8)
    //     0xce6ce4: sub             SP, SP, #8
    // 0xce6ce8: SetupParameters()
    //     0xce6ce8: ldr             x0, [fp, #0x18]
    //     0xce6cec: ldur            w1, [x0, #0x17]
    //     0xce6cf0: add             x1, x1, HEAP, lsl #32
    //     0xce6cf4: stur            x1, [fp, #-8]
    // 0xce6cf8: CheckStackOverflow
    //     0xce6cf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce6cfc: cmp             SP, x16
    //     0xce6d00: b.ls            #0xce6ec8
    // 0xce6d04: ldr             x2, [fp, #0x10]
    // 0xce6d08: r0 = LoadClassIdInstr(r2)
    //     0xce6d08: ldur            x0, [x2, #-1]
    //     0xce6d0c: ubfx            x0, x0, #0xc, #0x14
    // 0xce6d10: r16 = Instance_MaterialState
    //     0xce6d10: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xce6d14: ldr             x16, [x16, #0xf78]
    // 0xce6d18: stp             x16, x2, [SP, #-0x10]!
    // 0xce6d1c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6d1c: mov             x17, #0xc98a
    //     0xce6d20: add             lr, x0, x17
    //     0xce6d24: ldr             lr, [x21, lr, lsl #3]
    //     0xce6d28: blr             lr
    // 0xce6d2c: add             SP, SP, #0x10
    // 0xce6d30: tbnz            w0, #4, #0xce6d90
    // 0xce6d34: ldur            x1, [fp, #-8]
    // 0xce6d38: LoadField: r0 = r1->field_f
    //     0xce6d38: ldur            w0, [x1, #0xf]
    // 0xce6d3c: DecompressPointer r0
    //     0xce6d3c: add             x0, x0, HEAP, lsl #32
    // 0xce6d40: mov             x1, x0
    // 0xce6d44: LoadField: r0 = r1->field_63
    //     0xce6d44: ldur            w0, [x1, #0x63]
    // 0xce6d48: DecompressPointer r0
    //     0xce6d48: add             x0, x0, HEAP, lsl #32
    // 0xce6d4c: r16 = Sentinel
    //     0xce6d4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6d50: cmp             w0, w16
    // 0xce6d54: b.ne            #0xce6d64
    // 0xce6d58: r2 = _colors
    //     0xce6d58: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0xce6d5c: ldr             x2, [x2, #0x6e8]
    // 0xce6d60: r0 = InitLateFinalInstanceField()
    //     0xce6d60: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6d64: LoadField: r1 = r0->field_b
    //     0xce6d64: ldur            w1, [x0, #0xb]
    // 0xce6d68: DecompressPointer r1
    //     0xce6d68: add             x1, x1, HEAP, lsl #32
    // 0xce6d6c: SaveReg r1
    //     0xce6d6c: str             x1, [SP, #-8]!
    // 0xce6d70: d0 = 0.080000
    //     0xce6d70: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6d74: ldr             d0, [x17, #0xf80]
    // 0xce6d78: SaveReg d0
    //     0xce6d78: str             d0, [SP, #-8]!
    // 0xce6d7c: r0 = withOpacity()
    //     0xce6d7c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6d80: add             SP, SP, #0x10
    // 0xce6d84: LeaveFrame
    //     0xce6d84: mov             SP, fp
    //     0xce6d88: ldp             fp, lr, [SP], #0x10
    // 0xce6d8c: ret
    //     0xce6d8c: ret             
    // 0xce6d90: ldr             x2, [fp, #0x10]
    // 0xce6d94: ldur            x1, [fp, #-8]
    // 0xce6d98: r0 = LoadClassIdInstr(r2)
    //     0xce6d98: ldur            x0, [x2, #-1]
    //     0xce6d9c: ubfx            x0, x0, #0xc, #0x14
    // 0xce6da0: r16 = Instance_MaterialState
    //     0xce6da0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xce6da4: ldr             x16, [x16, #0xf88]
    // 0xce6da8: stp             x16, x2, [SP, #-0x10]!
    // 0xce6dac: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6dac: mov             x17, #0xc98a
    //     0xce6db0: add             lr, x0, x17
    //     0xce6db4: ldr             lr, [x21, lr, lsl #3]
    //     0xce6db8: blr             lr
    // 0xce6dbc: add             SP, SP, #0x10
    // 0xce6dc0: tbnz            w0, #4, #0xce6e20
    // 0xce6dc4: ldur            x1, [fp, #-8]
    // 0xce6dc8: LoadField: r0 = r1->field_f
    //     0xce6dc8: ldur            w0, [x1, #0xf]
    // 0xce6dcc: DecompressPointer r0
    //     0xce6dcc: add             x0, x0, HEAP, lsl #32
    // 0xce6dd0: mov             x1, x0
    // 0xce6dd4: LoadField: r0 = r1->field_63
    //     0xce6dd4: ldur            w0, [x1, #0x63]
    // 0xce6dd8: DecompressPointer r0
    //     0xce6dd8: add             x0, x0, HEAP, lsl #32
    // 0xce6ddc: r16 = Sentinel
    //     0xce6ddc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6de0: cmp             w0, w16
    // 0xce6de4: b.ne            #0xce6df4
    // 0xce6de8: r2 = _colors
    //     0xce6de8: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0xce6dec: ldr             x2, [x2, #0x6e8]
    // 0xce6df0: r0 = InitLateFinalInstanceField()
    //     0xce6df0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6df4: LoadField: r1 = r0->field_b
    //     0xce6df4: ldur            w1, [x0, #0xb]
    // 0xce6df8: DecompressPointer r1
    //     0xce6df8: add             x1, x1, HEAP, lsl #32
    // 0xce6dfc: SaveReg r1
    //     0xce6dfc: str             x1, [SP, #-8]!
    // 0xce6e00: d0 = 0.120000
    //     0xce6e00: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6e04: ldr             d0, [x17, #0xf48]
    // 0xce6e08: SaveReg d0
    //     0xce6e08: str             d0, [SP, #-8]!
    // 0xce6e0c: r0 = withOpacity()
    //     0xce6e0c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6e10: add             SP, SP, #0x10
    // 0xce6e14: LeaveFrame
    //     0xce6e14: mov             SP, fp
    //     0xce6e18: ldp             fp, lr, [SP], #0x10
    // 0xce6e1c: ret
    //     0xce6e1c: ret             
    // 0xce6e20: ldr             x0, [fp, #0x10]
    // 0xce6e24: ldur            x1, [fp, #-8]
    // 0xce6e28: d0 = 0.120000
    //     0xce6e28: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6e2c: ldr             d0, [x17, #0xf48]
    // 0xce6e30: r2 = LoadClassIdInstr(r0)
    //     0xce6e30: ldur            x2, [x0, #-1]
    //     0xce6e34: ubfx            x2, x2, #0xc, #0x14
    // 0xce6e38: r16 = Instance_MaterialState
    //     0xce6e38: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xce6e3c: ldr             x16, [x16, #0xf90]
    // 0xce6e40: stp             x16, x0, [SP, #-0x10]!
    // 0xce6e44: mov             x0, x2
    // 0xce6e48: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6e48: mov             x17, #0xc98a
    //     0xce6e4c: add             lr, x0, x17
    //     0xce6e50: ldr             lr, [x21, lr, lsl #3]
    //     0xce6e54: blr             lr
    // 0xce6e58: add             SP, SP, #0x10
    // 0xce6e5c: tbnz            w0, #4, #0xce6eb8
    // 0xce6e60: ldur            x0, [fp, #-8]
    // 0xce6e64: LoadField: r1 = r0->field_f
    //     0xce6e64: ldur            w1, [x0, #0xf]
    // 0xce6e68: DecompressPointer r1
    //     0xce6e68: add             x1, x1, HEAP, lsl #32
    // 0xce6e6c: LoadField: r0 = r1->field_63
    //     0xce6e6c: ldur            w0, [x1, #0x63]
    // 0xce6e70: DecompressPointer r0
    //     0xce6e70: add             x0, x0, HEAP, lsl #32
    // 0xce6e74: r16 = Sentinel
    //     0xce6e74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6e78: cmp             w0, w16
    // 0xce6e7c: b.ne            #0xce6e8c
    // 0xce6e80: r2 = _colors
    //     0xce6e80: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0xce6e84: ldr             x2, [x2, #0x6e8]
    // 0xce6e88: r0 = InitLateFinalInstanceField()
    //     0xce6e88: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6e8c: LoadField: r1 = r0->field_b
    //     0xce6e8c: ldur            w1, [x0, #0xb]
    // 0xce6e90: DecompressPointer r1
    //     0xce6e90: add             x1, x1, HEAP, lsl #32
    // 0xce6e94: SaveReg r1
    //     0xce6e94: str             x1, [SP, #-8]!
    // 0xce6e98: d0 = 0.120000
    //     0xce6e98: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6e9c: ldr             d0, [x17, #0xf48]
    // 0xce6ea0: SaveReg d0
    //     0xce6ea0: str             d0, [SP, #-8]!
    // 0xce6ea4: r0 = withOpacity()
    //     0xce6ea4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6ea8: add             SP, SP, #0x10
    // 0xce6eac: LeaveFrame
    //     0xce6eac: mov             SP, fp
    //     0xce6eb0: ldp             fp, lr, [SP], #0x10
    // 0xce6eb4: ret
    //     0xce6eb4: ret             
    // 0xce6eb8: r0 = Null
    //     0xce6eb8: mov             x0, NULL
    // 0xce6ebc: LeaveFrame
    //     0xce6ebc: mov             SP, fp
    //     0xce6ec0: ldp             fp, lr, [SP], #0x10
    // 0xce6ec4: ret
    //     0xce6ec4: ret             
    // 0xce6ec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6ec8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6ecc: b               #0xce6d04
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0xce7860, size: 0x64
    // 0xce7860: EnterFrame
    //     0xce7860: stp             fp, lr, [SP, #-0x10]!
    //     0xce7864: mov             fp, SP
    // 0xce7868: CheckStackOverflow
    //     0xce7868: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce786c: cmp             SP, x16
    //     0xce7870: b.ls            #0xce78bc
    // 0xce7874: r1 = 1
    //     0xce7874: mov             x1, #1
    // 0xce7878: r0 = AllocateContext()
    //     0xce7878: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce787c: mov             x1, x0
    // 0xce7880: ldr             x0, [fp, #0x10]
    // 0xce7884: StoreField: r1->field_f = r0
    //     0xce7884: stur            w0, [x1, #0xf]
    // 0xce7888: mov             x2, x1
    // 0xce788c: r1 = Function '<anonymous closure>':.
    //     0xce788c: add             x1, PP, #0x53, lsl #12  ; [pp+0x530b0] AnonymousClosure: (0xce78c4), in [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3::foregroundColor (0xce7860)
    //     0xce7890: ldr             x1, [x1, #0xb0]
    // 0xce7894: r0 = AllocateClosure()
    //     0xce7894: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce7898: r16 = <Color?>
    //     0xce7898: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce789c: ldr             x16, [x16, #0xf68]
    // 0xce78a0: stp             x0, x16, [SP, #-0x10]!
    // 0xce78a4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce78a4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce78a8: r0 = resolveWith()
    //     0xce78a8: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce78ac: add             SP, SP, #0x10
    // 0xce78b0: LeaveFrame
    //     0xce78b0: mov             SP, fp
    //     0xce78b4: ldp             fp, lr, [SP], #0x10
    // 0xce78b8: ret
    //     0xce78b8: ret             
    // 0xce78bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce78bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce78c0: b               #0xce7874
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce78c4, size: 0x100
    // 0xce78c4: EnterFrame
    //     0xce78c4: stp             fp, lr, [SP, #-0x10]!
    //     0xce78c8: mov             fp, SP
    // 0xce78cc: AllocStack(0x8)
    //     0xce78cc: sub             SP, SP, #8
    // 0xce78d0: SetupParameters()
    //     0xce78d0: ldr             x0, [fp, #0x18]
    //     0xce78d4: ldur            w1, [x0, #0x17]
    //     0xce78d8: add             x1, x1, HEAP, lsl #32
    //     0xce78dc: stur            x1, [fp, #-8]
    // 0xce78e0: CheckStackOverflow
    //     0xce78e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce78e4: cmp             SP, x16
    //     0xce78e8: b.ls            #0xce79bc
    // 0xce78ec: ldr             x0, [fp, #0x10]
    // 0xce78f0: r2 = LoadClassIdInstr(r0)
    //     0xce78f0: ldur            x2, [x0, #-1]
    //     0xce78f4: ubfx            x2, x2, #0xc, #0x14
    // 0xce78f8: r16 = Instance_MaterialState
    //     0xce78f8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xce78fc: ldr             x16, [x16, #0x2a0]
    // 0xce7900: stp             x16, x0, [SP, #-0x10]!
    // 0xce7904: mov             x0, x2
    // 0xce7908: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce7908: mov             x17, #0xc98a
    //     0xce790c: add             lr, x0, x17
    //     0xce7910: ldr             lr, [x21, lr, lsl #3]
    //     0xce7914: blr             lr
    // 0xce7918: add             SP, SP, #0x10
    // 0xce791c: tbnz            w0, #4, #0xce7978
    // 0xce7920: ldur            x0, [fp, #-8]
    // 0xce7924: LoadField: r1 = r0->field_f
    //     0xce7924: ldur            w1, [x0, #0xf]
    // 0xce7928: DecompressPointer r1
    //     0xce7928: add             x1, x1, HEAP, lsl #32
    // 0xce792c: LoadField: r0 = r1->field_63
    //     0xce792c: ldur            w0, [x1, #0x63]
    // 0xce7930: DecompressPointer r0
    //     0xce7930: add             x0, x0, HEAP, lsl #32
    // 0xce7934: r16 = Sentinel
    //     0xce7934: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7938: cmp             w0, w16
    // 0xce793c: b.ne            #0xce794c
    // 0xce7940: r2 = _colors
    //     0xce7940: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0xce7944: ldr             x2, [x2, #0x6e8]
    // 0xce7948: r0 = InitLateFinalInstanceField()
    //     0xce7948: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce794c: LoadField: r1 = r0->field_57
    //     0xce794c: ldur            w1, [x0, #0x57]
    // 0xce7950: DecompressPointer r1
    //     0xce7950: add             x1, x1, HEAP, lsl #32
    // 0xce7954: SaveReg r1
    //     0xce7954: str             x1, [SP, #-8]!
    // 0xce7958: d0 = 0.380000
    //     0xce7958: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xce795c: ldr             d0, [x17, #0x140]
    // 0xce7960: SaveReg d0
    //     0xce7960: str             d0, [SP, #-8]!
    // 0xce7964: r0 = withOpacity()
    //     0xce7964: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce7968: add             SP, SP, #0x10
    // 0xce796c: LeaveFrame
    //     0xce796c: mov             SP, fp
    //     0xce7970: ldp             fp, lr, [SP], #0x10
    // 0xce7974: ret
    //     0xce7974: ret             
    // 0xce7978: ldur            x0, [fp, #-8]
    // 0xce797c: LoadField: r1 = r0->field_f
    //     0xce797c: ldur            w1, [x0, #0xf]
    // 0xce7980: DecompressPointer r1
    //     0xce7980: add             x1, x1, HEAP, lsl #32
    // 0xce7984: LoadField: r0 = r1->field_63
    //     0xce7984: ldur            w0, [x1, #0x63]
    // 0xce7988: DecompressPointer r0
    //     0xce7988: add             x0, x0, HEAP, lsl #32
    // 0xce798c: r16 = Sentinel
    //     0xce798c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7990: cmp             w0, w16
    // 0xce7994: b.ne            #0xce79a4
    // 0xce7998: r2 = _colors
    //     0xce7998: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e6e8] Field <_OutlinedButtonDefaultsM3@786109675._colors@786109675>: late final (offset: 0x64)
    //     0xce799c: ldr             x2, [x2, #0x6e8]
    // 0xce79a0: r0 = InitLateFinalInstanceField()
    //     0xce79a0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce79a4: LoadField: r1 = r0->field_b
    //     0xce79a4: ldur            w1, [x0, #0xb]
    // 0xce79a8: DecompressPointer r1
    //     0xce79a8: add             x1, x1, HEAP, lsl #32
    // 0xce79ac: mov             x0, x1
    // 0xce79b0: LeaveFrame
    //     0xce79b0: mov             SP, fp
    //     0xce79b4: ldp             fp, lr, [SP], #0x10
    // 0xce79b8: ret
    //     0xce79b8: ret             
    // 0xce79bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce79bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce79c0: b               #0xce78ec
  }
}

// class id: 4163, size: 0x34, field offset: 0x34
//   const constructor, 
class OutlinedButton extends ButtonStyleButton {

  _ themeStyleOf(/* No info */) {
    // ** addr: 0xc13440, size: 0x44
    // 0xc13440: EnterFrame
    //     0xc13440: stp             fp, lr, [SP, #-0x10]!
    //     0xc13444: mov             fp, SP
    // 0xc13448: CheckStackOverflow
    //     0xc13448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1344c: cmp             SP, x16
    //     0xc13450: b.ls            #0xc1347c
    // 0xc13454: ldr             x16, [fp, #0x10]
    // 0xc13458: SaveReg r16
    //     0xc13458: str             x16, [SP, #-8]!
    // 0xc1345c: r0 = of()
    //     0xc1345c: bl              #0xc13484  ; [package:flutter/src/material/outlined_button_theme.dart] OutlinedButtonTheme::of
    // 0xc13460: add             SP, SP, #8
    // 0xc13464: LoadField: r1 = r0->field_7
    //     0xc13464: ldur            w1, [x0, #7]
    // 0xc13468: DecompressPointer r1
    //     0xc13468: add             x1, x1, HEAP, lsl #32
    // 0xc1346c: mov             x0, x1
    // 0xc13470: LeaveFrame
    //     0xc13470: mov             SP, fp
    //     0xc13474: ldp             fp, lr, [SP], #0x10
    // 0xc13478: ret
    //     0xc13478: ret             
    // 0xc1347c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc1347c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc13480: b               #0xc13454
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0xc14db4, size: 0x1cc
    // 0xc14db4: EnterFrame
    //     0xc14db4: stp             fp, lr, [SP, #-0x10]!
    //     0xc14db8: mov             fp, SP
    // 0xc14dbc: AllocStack(0x38)
    //     0xc14dbc: sub             SP, SP, #0x38
    // 0xc14dc0: CheckStackOverflow
    //     0xc14dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc14dc4: cmp             SP, x16
    //     0xc14dc8: b.ls            #0xc14f78
    // 0xc14dcc: ldr             x16, [fp, #0x10]
    // 0xc14dd0: SaveReg r16
    //     0xc14dd0: str             x16, [SP, #-8]!
    // 0xc14dd4: r0 = of()
    //     0xc14dd4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc14dd8: add             SP, SP, #8
    // 0xc14ddc: stur            x0, [fp, #-0x10]
    // 0xc14de0: LoadField: r1 = r0->field_3f
    //     0xc14de0: ldur            w1, [x0, #0x3f]
    // 0xc14de4: DecompressPointer r1
    //     0xc14de4: add             x1, x1, HEAP, lsl #32
    // 0xc14de8: stur            x1, [fp, #-8]
    // 0xc14dec: ldr             x16, [fp, #0x10]
    // 0xc14df0: SaveReg r16
    //     0xc14df0: str             x16, [SP, #-8]!
    // 0xc14df4: r0 = of()
    //     0xc14df4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc14df8: add             SP, SP, #8
    // 0xc14dfc: LoadField: r1 = r0->field_2b
    //     0xc14dfc: ldur            w1, [x0, #0x2b]
    // 0xc14e00: DecompressPointer r1
    //     0xc14e00: add             x1, x1, HEAP, lsl #32
    // 0xc14e04: tbnz            w1, #4, #0xc14e4c
    // 0xc14e08: ldr             x0, [fp, #0x10]
    // 0xc14e0c: r0 = _OutlinedButtonDefaultsM3()
    //     0xc14e0c: bl              #0xc15200  ; Allocate_OutlinedButtonDefaultsM3Stub -> _OutlinedButtonDefaultsM3 (size=0x68)
    // 0xc14e10: mov             x1, x0
    // 0xc14e14: r0 = Sentinel
    //     0xc14e14: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc14e18: StoreField: r1->field_63 = r0
    //     0xc14e18: stur            w0, [x1, #0x63]
    // 0xc14e1c: ldr             x0, [fp, #0x10]
    // 0xc14e20: StoreField: r1->field_5f = r0
    //     0xc14e20: stur            w0, [x1, #0x5f]
    // 0xc14e24: r0 = Instance_Duration
    //     0xc14e24: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc14e28: ldr             x0, [x0, #0x9e0]
    // 0xc14e2c: StoreField: r1->field_4f = r0
    //     0xc14e2c: stur            w0, [x1, #0x4f]
    // 0xc14e30: r0 = true
    //     0xc14e30: add             x0, NULL, #0x20  ; true
    // 0xc14e34: StoreField: r1->field_53 = r0
    //     0xc14e34: stur            w0, [x1, #0x53]
    // 0xc14e38: r0 = Instance_Alignment
    //     0xc14e38: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc14e3c: ldr             x0, [x0, #0xc70]
    // 0xc14e40: StoreField: r1->field_57 = r0
    //     0xc14e40: stur            w0, [x1, #0x57]
    // 0xc14e44: mov             x0, x1
    // 0xc14e48: b               #0xc14f6c
    // 0xc14e4c: ldr             x0, [fp, #0x10]
    // 0xc14e50: ldur            x1, [fp, #-0x10]
    // 0xc14e54: ldur            x2, [fp, #-8]
    // 0xc14e58: d0 = 0.380000
    //     0xc14e58: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc14e5c: ldr             d0, [x17, #0x140]
    // 0xc14e60: LoadField: r3 = r2->field_b
    //     0xc14e60: ldur            w3, [x2, #0xb]
    // 0xc14e64: DecompressPointer r3
    //     0xc14e64: add             x3, x3, HEAP, lsl #32
    // 0xc14e68: stur            x3, [fp, #-0x18]
    // 0xc14e6c: LoadField: r4 = r2->field_57
    //     0xc14e6c: ldur            w4, [x2, #0x57]
    // 0xc14e70: DecompressPointer r4
    //     0xc14e70: add             x4, x4, HEAP, lsl #32
    // 0xc14e74: SaveReg r4
    //     0xc14e74: str             x4, [SP, #-8]!
    // 0xc14e78: SaveReg d0
    //     0xc14e78: str             d0, [SP, #-8]!
    // 0xc14e7c: r0 = withOpacity()
    //     0xc14e7c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc14e80: add             SP, SP, #0x10
    // 0xc14e84: mov             x1, x0
    // 0xc14e88: ldur            x0, [fp, #-0x10]
    // 0xc14e8c: stur            x1, [fp, #-0x28]
    // 0xc14e90: LoadField: r2 = r0->field_7b
    //     0xc14e90: ldur            w2, [x0, #0x7b]
    // 0xc14e94: DecompressPointer r2
    //     0xc14e94: add             x2, x2, HEAP, lsl #32
    // 0xc14e98: stur            x2, [fp, #-0x20]
    // 0xc14e9c: LoadField: r3 = r0->field_93
    //     0xc14e9c: ldur            w3, [x0, #0x93]
    // 0xc14ea0: DecompressPointer r3
    //     0xc14ea0: add             x3, x3, HEAP, lsl #32
    // 0xc14ea4: LoadField: r4 = r3->field_37
    //     0xc14ea4: ldur            w4, [x3, #0x37]
    // 0xc14ea8: DecompressPointer r4
    //     0xc14ea8: add             x4, x4, HEAP, lsl #32
    // 0xc14eac: stur            x4, [fp, #-8]
    // 0xc14eb0: ldr             x16, [fp, #0x10]
    // 0xc14eb4: SaveReg r16
    //     0xc14eb4: str             x16, [SP, #-8]!
    // 0xc14eb8: r0 = _scaledPadding()
    //     0xc14eb8: bl              #0xc14b4c  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0xc14ebc: add             SP, SP, #8
    // 0xc14ec0: stur            x0, [fp, #-0x30]
    // 0xc14ec4: ldr             x16, [fp, #0x10]
    // 0xc14ec8: SaveReg r16
    //     0xc14ec8: str             x16, [SP, #-8]!
    // 0xc14ecc: r0 = of()
    //     0xc14ecc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc14ed0: add             SP, SP, #8
    // 0xc14ed4: LoadField: r1 = r0->field_3f
    //     0xc14ed4: ldur            w1, [x0, #0x3f]
    // 0xc14ed8: DecompressPointer r1
    //     0xc14ed8: add             x1, x1, HEAP, lsl #32
    // 0xc14edc: LoadField: r0 = r1->field_57
    //     0xc14edc: ldur            w0, [x1, #0x57]
    // 0xc14ee0: DecompressPointer r0
    //     0xc14ee0: add             x0, x0, HEAP, lsl #32
    // 0xc14ee4: SaveReg r0
    //     0xc14ee4: str             x0, [SP, #-8]!
    // 0xc14ee8: d0 = 0.120000
    //     0xc14ee8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc14eec: ldr             d0, [x17, #0xf48]
    // 0xc14ef0: SaveReg d0
    //     0xc14ef0: str             d0, [SP, #-8]!
    // 0xc14ef4: r0 = withOpacity()
    //     0xc14ef4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc14ef8: add             SP, SP, #0x10
    // 0xc14efc: stur            x0, [fp, #-0x38]
    // 0xc14f00: r0 = BorderSide()
    //     0xc14f00: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xc14f04: mov             x1, x0
    // 0xc14f08: ldur            x0, [fp, #-0x38]
    // 0xc14f0c: StoreField: r1->field_7 = r0
    //     0xc14f0c: stur            w0, [x1, #7]
    // 0xc14f10: d0 = 1.000000
    //     0xc14f10: fmov            d0, #1.00000000
    // 0xc14f14: StoreField: r1->field_b = d0
    //     0xc14f14: stur            d0, [x1, #0xb]
    // 0xc14f18: r0 = Instance_BorderStyle
    //     0xc14f18: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xc14f1c: ldr             x0, [x0, #0xbd0]
    // 0xc14f20: StoreField: r1->field_13 = r0
    //     0xc14f20: stur            w0, [x1, #0x13]
    // 0xc14f24: d0 = -1.000000
    //     0xc14f24: fmov            d0, #-1.00000000
    // 0xc14f28: StoreField: r1->field_17 = d0
    //     0xc14f28: stur            d0, [x1, #0x17]
    // 0xc14f2c: ldur            x0, [fp, #-0x10]
    // 0xc14f30: LoadField: r2 = r0->field_2f
    //     0xc14f30: ldur            w2, [x0, #0x2f]
    // 0xc14f34: DecompressPointer r2
    //     0xc14f34: add             x2, x2, HEAP, lsl #32
    // 0xc14f38: LoadField: r3 = r0->field_17
    //     0xc14f38: ldur            w3, [x0, #0x17]
    // 0xc14f3c: DecompressPointer r3
    //     0xc14f3c: add             x3, x3, HEAP, lsl #32
    // 0xc14f40: ldur            x16, [fp, #-0x28]
    // 0xc14f44: ldur            lr, [fp, #-0x18]
    // 0xc14f48: stp             lr, x16, [SP, #-0x10]!
    // 0xc14f4c: ldur            x16, [fp, #-0x30]
    // 0xc14f50: ldur            lr, [fp, #-0x20]
    // 0xc14f54: stp             lr, x16, [SP, #-0x10]!
    // 0xc14f58: stp             x3, x1, [SP, #-0x10]!
    // 0xc14f5c: ldur            x16, [fp, #-8]
    // 0xc14f60: stp             x2, x16, [SP, #-0x10]!
    // 0xc14f64: r0 = styleFrom()
    //     0xc14f64: bl              #0xc14f80  ; [package:flutter/src/material/outlined_button.dart] OutlinedButton::styleFrom
    // 0xc14f68: add             SP, SP, #0x40
    // 0xc14f6c: LeaveFrame
    //     0xc14f6c: mov             SP, fp
    //     0xc14f70: ldp             fp, lr, [SP], #0x10
    // 0xc14f74: ret
    //     0xc14f74: ret             
    // 0xc14f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc14f78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc14f7c: b               #0xc14dcc
  }
  static _ styleFrom(/* No info */) {
    // ** addr: 0xc14f80, size: 0x25c
    // 0xc14f80: EnterFrame
    //     0xc14f80: stp             fp, lr, [SP, #-0x10]!
    //     0xc14f84: mov             fp, SP
    // 0xc14f88: AllocStack(0x60)
    //     0xc14f88: sub             SP, SP, #0x60
    // 0xc14f8c: CheckStackOverflow
    //     0xc14f8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc14f90: cmp             SP, x16
    //     0xc14f94: b.ls            #0xc151d4
    // 0xc14f98: r1 = <Color?>
    //     0xc14f98: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc14f9c: ldr             x1, [x1, #0xf68]
    // 0xc14fa0: r0 = _OutlinedButtonDefaultColor()
    //     0xc14fa0: bl              #0xc151f4  ; Allocate_OutlinedButtonDefaultColorStub -> _OutlinedButtonDefaultColor (size=0x14)
    // 0xc14fa4: mov             x2, x0
    // 0xc14fa8: ldr             x0, [fp, #0x40]
    // 0xc14fac: stur            x2, [fp, #-8]
    // 0xc14fb0: StoreField: r2->field_b = r0
    //     0xc14fb0: stur            w0, [x2, #0xb]
    // 0xc14fb4: ldr             x1, [fp, #0x48]
    // 0xc14fb8: StoreField: r2->field_f = r1
    //     0xc14fb8: stur            w1, [x2, #0xf]
    // 0xc14fbc: r1 = <Color?>
    //     0xc14fbc: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc14fc0: ldr             x1, [x1, #0xf68]
    // 0xc14fc4: r0 = _OutlinedButtonDefaultColor()
    //     0xc14fc4: bl              #0xc151f4  ; Allocate_OutlinedButtonDefaultColorStub -> _OutlinedButtonDefaultColor (size=0x14)
    // 0xc14fc8: mov             x2, x0
    // 0xc14fcc: r0 = Instance_Color
    //     0xc14fcc: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc14fd0: ldr             x0, [x0, #0xc08]
    // 0xc14fd4: stur            x2, [fp, #-0x10]
    // 0xc14fd8: StoreField: r2->field_b = r0
    //     0xc14fd8: stur            w0, [x2, #0xb]
    // 0xc14fdc: StoreField: r2->field_f = r0
    //     0xc14fdc: stur            w0, [x2, #0xf]
    // 0xc14fe0: r1 = <Color?>
    //     0xc14fe0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xc14fe4: ldr             x1, [x1, #0xf68]
    // 0xc14fe8: r0 = _OutlinedButtonDefaultOverlay()
    //     0xc14fe8: bl              #0xc151e8  ; Allocate_OutlinedButtonDefaultOverlayStub -> _OutlinedButtonDefaultOverlay (size=0x10)
    // 0xc14fec: mov             x2, x0
    // 0xc14ff0: ldr             x0, [fp, #0x40]
    // 0xc14ff4: stur            x2, [fp, #-0x18]
    // 0xc14ff8: StoreField: r2->field_b = r0
    //     0xc14ff8: stur            w0, [x2, #0xb]
    // 0xc14ffc: r1 = <MouseCursor>
    //     0xc14ffc: ldr             x1, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0xc15000: r0 = _OutlinedButtonDefaultMouseCursor()
    //     0xc15000: bl              #0xc151dc  ; Allocate_OutlinedButtonDefaultMouseCursorStub -> _OutlinedButtonDefaultMouseCursor (size=0x14)
    // 0xc15004: mov             x1, x0
    // 0xc15008: r0 = Instance_SystemMouseCursor
    //     0xc15008: add             x0, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0xc1500c: ldr             x0, [x0, #0xea8]
    // 0xc15010: stur            x1, [fp, #-0x20]
    // 0xc15014: StoreField: r1->field_b = r0
    //     0xc15014: stur            w0, [x1, #0xb]
    // 0xc15018: r0 = Instance_SystemMouseCursor
    //     0xc15018: ldr             x0, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xc1501c: StoreField: r1->field_f = r0
    //     0xc1501c: stur            w0, [x1, #0xf]
    // 0xc15020: r16 = <TextStyle>
    //     0xc15020: add             x16, PP, #0x28, lsl #12  ; [pp+0x28410] TypeArguments: <TextStyle>
    //     0xc15024: ldr             x16, [x16, #0x410]
    // 0xc15028: ldr             lr, [fp, #0x18]
    // 0xc1502c: stp             lr, x16, [SP, #-0x10]!
    // 0xc15030: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc15030: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc15034: r0 = allOrNull()
    //     0xc15034: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc15038: add             SP, SP, #0x10
    // 0xc1503c: stur            x0, [fp, #-0x28]
    // 0xc15040: r16 = <Color>
    //     0xc15040: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xc15044: ldr             x16, [x16, #0x3f8]
    // 0xc15048: ldr             lr, [fp, #0x30]
    // 0xc1504c: stp             lr, x16, [SP, #-0x10]!
    // 0xc15050: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc15050: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc15054: r0 = allOrNull()
    //     0xc15054: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc15058: add             SP, SP, #0x10
    // 0xc1505c: stur            x0, [fp, #-0x30]
    // 0xc15060: r16 = <double>
    //     0xc15060: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc15064: r30 = 0.000000
    //     0xc15064: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xc15068: stp             lr, x16, [SP, #-0x10]!
    // 0xc1506c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc1506c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc15070: r0 = allOrNull()
    //     0xc15070: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc15074: add             SP, SP, #0x10
    // 0xc15078: stur            x0, [fp, #-0x38]
    // 0xc1507c: r16 = <EdgeInsetsGeometry>
    //     0xc1507c: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xc15080: ldr             x16, [x16, #0x8c8]
    // 0xc15084: ldr             lr, [fp, #0x38]
    // 0xc15088: stp             lr, x16, [SP, #-0x10]!
    // 0xc1508c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc1508c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc15090: r0 = allOrNull()
    //     0xc15090: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc15094: add             SP, SP, #0x10
    // 0xc15098: stur            x0, [fp, #-0x40]
    // 0xc1509c: r16 = <Size>
    //     0xc1509c: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0xc150a0: ldr             x16, [x16, #0x8d0]
    // 0xc150a4: r30 = Instance_Size
    //     0xc150a4: add             lr, PP, #0x37, lsl #12  ; [pp+0x376e8] Obj!Size@b5ee71
    //     0xc150a8: ldr             lr, [lr, #0x6e8]
    // 0xc150ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc150b0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc150b0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc150b4: r0 = allOrNull()
    //     0xc150b4: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc150b8: add             SP, SP, #0x10
    // 0xc150bc: stur            x0, [fp, #-0x48]
    // 0xc150c0: r16 = <Size>
    //     0xc150c0: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0xc150c4: ldr             x16, [x16, #0x8d0]
    // 0xc150c8: r30 = Instance_Size
    //     0xc150c8: add             lr, PP, #0x37, lsl #12  ; [pp+0x376f0] Obj!Size@b5ee51
    //     0xc150cc: ldr             lr, [lr, #0x6f0]
    // 0xc150d0: stp             lr, x16, [SP, #-0x10]!
    // 0xc150d4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc150d4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc150d8: r0 = allOrNull()
    //     0xc150d8: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc150dc: add             SP, SP, #0x10
    // 0xc150e0: stur            x0, [fp, #-0x50]
    // 0xc150e4: r16 = <BorderSide>
    //     0xc150e4: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6e0] TypeArguments: <BorderSide>
    //     0xc150e8: ldr             x16, [x16, #0x6e0]
    // 0xc150ec: ldr             lr, [fp, #0x28]
    // 0xc150f0: stp             lr, x16, [SP, #-0x10]!
    // 0xc150f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc150f4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc150f8: r0 = allOrNull()
    //     0xc150f8: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc150fc: add             SP, SP, #0x10
    // 0xc15100: stur            x0, [fp, #-0x58]
    // 0xc15104: r16 = <OutlinedBorder>
    //     0xc15104: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d8] TypeArguments: <OutlinedBorder>
    //     0xc15108: ldr             x16, [x16, #0x8d8]
    // 0xc1510c: r30 = Instance_RoundedRectangleBorder
    //     0xc1510c: add             lr, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xc15110: ldr             lr, [lr, #0x450]
    // 0xc15114: stp             lr, x16, [SP, #-0x10]!
    // 0xc15118: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc15118: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc1511c: r0 = allOrNull()
    //     0xc1511c: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xc15120: add             SP, SP, #0x10
    // 0xc15124: stur            x0, [fp, #-0x60]
    // 0xc15128: r0 = ButtonStyle()
    //     0xc15128: bl              #0x9173f0  ; AllocateButtonStyleStub -> ButtonStyle (size=0x60)
    // 0xc1512c: ldur            x1, [fp, #-0x28]
    // 0xc15130: StoreField: r0->field_7 = r1
    //     0xc15130: stur            w1, [x0, #7]
    // 0xc15134: ldur            x1, [fp, #-0x10]
    // 0xc15138: StoreField: r0->field_b = r1
    //     0xc15138: stur            w1, [x0, #0xb]
    // 0xc1513c: ldur            x1, [fp, #-8]
    // 0xc15140: StoreField: r0->field_f = r1
    //     0xc15140: stur            w1, [x0, #0xf]
    // 0xc15144: ldur            x1, [fp, #-0x18]
    // 0xc15148: StoreField: r0->field_13 = r1
    //     0xc15148: stur            w1, [x0, #0x13]
    // 0xc1514c: ldur            x1, [fp, #-0x30]
    // 0xc15150: StoreField: r0->field_17 = r1
    //     0xc15150: stur            w1, [x0, #0x17]
    // 0xc15154: ldur            x1, [fp, #-0x38]
    // 0xc15158: StoreField: r0->field_1f = r1
    //     0xc15158: stur            w1, [x0, #0x1f]
    // 0xc1515c: ldur            x1, [fp, #-0x40]
    // 0xc15160: StoreField: r0->field_23 = r1
    //     0xc15160: stur            w1, [x0, #0x23]
    // 0xc15164: ldur            x1, [fp, #-0x48]
    // 0xc15168: StoreField: r0->field_27 = r1
    //     0xc15168: stur            w1, [x0, #0x27]
    // 0xc1516c: ldur            x1, [fp, #-0x50]
    // 0xc15170: StoreField: r0->field_2f = r1
    //     0xc15170: stur            w1, [x0, #0x2f]
    // 0xc15174: ldur            x1, [fp, #-0x58]
    // 0xc15178: StoreField: r0->field_3b = r1
    //     0xc15178: stur            w1, [x0, #0x3b]
    // 0xc1517c: ldur            x1, [fp, #-0x60]
    // 0xc15180: StoreField: r0->field_3f = r1
    //     0xc15180: stur            w1, [x0, #0x3f]
    // 0xc15184: ldur            x1, [fp, #-0x20]
    // 0xc15188: StoreField: r0->field_43 = r1
    //     0xc15188: stur            w1, [x0, #0x43]
    // 0xc1518c: ldr             x1, [fp, #0x10]
    // 0xc15190: StoreField: r0->field_47 = r1
    //     0xc15190: stur            w1, [x0, #0x47]
    // 0xc15194: ldr             x1, [fp, #0x20]
    // 0xc15198: StoreField: r0->field_4b = r1
    //     0xc15198: stur            w1, [x0, #0x4b]
    // 0xc1519c: r1 = Instance_Duration
    //     0xc1519c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc151a0: ldr             x1, [x1, #0x9e0]
    // 0xc151a4: StoreField: r0->field_4f = r1
    //     0xc151a4: stur            w1, [x0, #0x4f]
    // 0xc151a8: r1 = true
    //     0xc151a8: add             x1, NULL, #0x20  ; true
    // 0xc151ac: StoreField: r0->field_53 = r1
    //     0xc151ac: stur            w1, [x0, #0x53]
    // 0xc151b0: r1 = Instance_Alignment
    //     0xc151b0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc151b4: ldr             x1, [x1, #0xc70]
    // 0xc151b8: StoreField: r0->field_57 = r1
    //     0xc151b8: stur            w1, [x0, #0x57]
    // 0xc151bc: r1 = Instance__InkRippleFactory
    //     0xc151bc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf00] Obj!_InkRippleFactory@b38571
    //     0xc151c0: ldr             x1, [x1, #0xf00]
    // 0xc151c4: StoreField: r0->field_5b = r1
    //     0xc151c4: stur            w1, [x0, #0x5b]
    // 0xc151c8: LeaveFrame
    //     0xc151c8: mov             SP, fp
    //     0xc151cc: ldp             fp, lr, [SP], #0x10
    // 0xc151d0: ret
    //     0xc151d0: ret             
    // 0xc151d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc151d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc151d8: b               #0xc14f98
  }
}

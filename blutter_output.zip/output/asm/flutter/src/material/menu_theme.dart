// lib: , url: package:flutter/src/material/menu_theme.dart

// class id: 1049276, size: 0x8
class :: {
}

// class id: 2785, size: 0xc, field offset: 0x8
//   const constructor, 
class MenuThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf3c34, size: 0x68
    // 0xbf3c34: EnterFrame
    //     0xbf3c34: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3c38: mov             fp, SP
    // 0xbf3c3c: AllocStack(0x8)
    //     0xbf3c3c: sub             SP, SP, #8
    // 0xbf3c40: CheckStackOverflow
    //     0xbf3c40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3c44: cmp             SP, x16
    //     0xbf3c48: b.ls            #0xbf3c94
    // 0xbf3c4c: ldr             x0, [fp, #0x20]
    // 0xbf3c50: LoadField: r1 = r0->field_7
    //     0xbf3c50: ldur            w1, [x0, #7]
    // 0xbf3c54: DecompressPointer r1
    //     0xbf3c54: add             x1, x1, HEAP, lsl #32
    // 0xbf3c58: ldr             x0, [fp, #0x18]
    // 0xbf3c5c: LoadField: r2 = r0->field_7
    //     0xbf3c5c: ldur            w2, [x0, #7]
    // 0xbf3c60: DecompressPointer r2
    //     0xbf3c60: add             x2, x2, HEAP, lsl #32
    // 0xbf3c64: stp             x2, x1, [SP, #-0x10]!
    // 0xbf3c68: ldr             d0, [fp, #0x10]
    // 0xbf3c6c: SaveReg d0
    //     0xbf3c6c: str             d0, [SP, #-8]!
    // 0xbf3c70: r0 = lerp()
    //     0xbf3c70: bl              #0xbf3ca8  ; [package:flutter/src/material/menu_style.dart] MenuStyle::lerp
    // 0xbf3c74: add             SP, SP, #0x18
    // 0xbf3c78: stur            x0, [fp, #-8]
    // 0xbf3c7c: r0 = MenuThemeData()
    //     0xbf3c7c: bl              #0xbf3c9c  ; AllocateMenuThemeDataStub -> MenuThemeData (size=0xc)
    // 0xbf3c80: ldur            x1, [fp, #-8]
    // 0xbf3c84: StoreField: r0->field_7 = r1
    //     0xbf3c84: stur            w1, [x0, #7]
    // 0xbf3c88: LeaveFrame
    //     0xbf3c88: mov             SP, fp
    //     0xbf3c8c: ldp             fp, lr, [SP], #0x10
    // 0xbf3c90: ret
    //     0xbf3c90: ret             
    // 0xbf3c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf3c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf3c98: b               #0xbf3c4c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8bafc, size: 0x144
    // 0xc8bafc: EnterFrame
    //     0xc8bafc: stp             fp, lr, [SP, #-0x10]!
    //     0xc8bb00: mov             fp, SP
    // 0xc8bb04: AllocStack(0x8)
    //     0xc8bb04: sub             SP, SP, #8
    // 0xc8bb08: CheckStackOverflow
    //     0xc8bb08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8bb0c: cmp             SP, x16
    //     0xc8bb10: b.ls            #0xc8bc38
    // 0xc8bb14: ldr             x1, [fp, #0x10]
    // 0xc8bb18: cmp             w1, NULL
    // 0xc8bb1c: b.ne            #0xc8bb30
    // 0xc8bb20: r0 = false
    //     0xc8bb20: add             x0, NULL, #0x30  ; false
    // 0xc8bb24: LeaveFrame
    //     0xc8bb24: mov             SP, fp
    //     0xc8bb28: ldp             fp, lr, [SP], #0x10
    // 0xc8bb2c: ret
    //     0xc8bb2c: ret             
    // 0xc8bb30: ldr             x2, [fp, #0x18]
    // 0xc8bb34: cmp             w2, w1
    // 0xc8bb38: b.ne            #0xc8bb4c
    // 0xc8bb3c: r0 = true
    //     0xc8bb3c: add             x0, NULL, #0x20  ; true
    // 0xc8bb40: LeaveFrame
    //     0xc8bb40: mov             SP, fp
    //     0xc8bb44: ldp             fp, lr, [SP], #0x10
    // 0xc8bb48: ret
    //     0xc8bb48: ret             
    // 0xc8bb4c: r0 = 59
    //     0xc8bb4c: mov             x0, #0x3b
    // 0xc8bb50: branchIfSmi(r1, 0xc8bb5c)
    //     0xc8bb50: tbz             w1, #0, #0xc8bb5c
    // 0xc8bb54: r0 = LoadClassIdInstr(r1)
    //     0xc8bb54: ldur            x0, [x1, #-1]
    //     0xc8bb58: ubfx            x0, x0, #0xc, #0x14
    // 0xc8bb5c: SaveReg r1
    //     0xc8bb5c: str             x1, [SP, #-8]!
    // 0xc8bb60: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8bb60: mov             x17, #0x57c5
    //     0xc8bb64: add             lr, x0, x17
    //     0xc8bb68: ldr             lr, [x21, lr, lsl #3]
    //     0xc8bb6c: blr             lr
    // 0xc8bb70: add             SP, SP, #8
    // 0xc8bb74: stur            x0, [fp, #-8]
    // 0xc8bb78: ldr             x16, [fp, #0x18]
    // 0xc8bb7c: SaveReg r16
    //     0xc8bb7c: str             x16, [SP, #-8]!
    // 0xc8bb80: r0 = runtimeType()
    //     0xc8bb80: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8bb84: add             SP, SP, #8
    // 0xc8bb88: mov             x1, x0
    // 0xc8bb8c: ldur            x0, [fp, #-8]
    // 0xc8bb90: r2 = LoadClassIdInstr(r0)
    //     0xc8bb90: ldur            x2, [x0, #-1]
    //     0xc8bb94: ubfx            x2, x2, #0xc, #0x14
    // 0xc8bb98: stp             x1, x0, [SP, #-0x10]!
    // 0xc8bb9c: mov             x0, x2
    // 0xc8bba0: mov             lr, x0
    // 0xc8bba4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8bba8: blr             lr
    // 0xc8bbac: add             SP, SP, #0x10
    // 0xc8bbb0: tbz             w0, #4, #0xc8bbc4
    // 0xc8bbb4: r0 = false
    //     0xc8bbb4: add             x0, NULL, #0x30  ; false
    // 0xc8bbb8: LeaveFrame
    //     0xc8bbb8: mov             SP, fp
    //     0xc8bbbc: ldp             fp, lr, [SP], #0x10
    // 0xc8bbc0: ret
    //     0xc8bbc0: ret             
    // 0xc8bbc4: ldr             x0, [fp, #0x10]
    // 0xc8bbc8: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8bbc8: mov             x1, #0x76
    //     0xc8bbcc: tbz             w0, #0, #0xc8bbdc
    //     0xc8bbd0: ldur            x1, [x0, #-1]
    //     0xc8bbd4: ubfx            x1, x1, #0xc, #0x14
    //     0xc8bbd8: lsl             x1, x1, #1
    // 0xc8bbdc: r2 = LoadInt32Instr(r1)
    //     0xc8bbdc: sbfx            x2, x1, #1, #0x1f
    // 0xc8bbe0: cmp             x2, #0xae1
    // 0xc8bbe4: b.lt            #0xc8bc28
    // 0xc8bbe8: cmp             x2, #0xae2
    // 0xc8bbec: b.gt            #0xc8bc28
    // 0xc8bbf0: ldr             x1, [fp, #0x18]
    // 0xc8bbf4: LoadField: r2 = r0->field_7
    //     0xc8bbf4: ldur            w2, [x0, #7]
    // 0xc8bbf8: DecompressPointer r2
    //     0xc8bbf8: add             x2, x2, HEAP, lsl #32
    // 0xc8bbfc: LoadField: r0 = r1->field_7
    //     0xc8bbfc: ldur            w0, [x1, #7]
    // 0xc8bc00: DecompressPointer r0
    //     0xc8bc00: add             x0, x0, HEAP, lsl #32
    // 0xc8bc04: r1 = LoadClassIdInstr(r2)
    //     0xc8bc04: ldur            x1, [x2, #-1]
    //     0xc8bc08: ubfx            x1, x1, #0xc, #0x14
    // 0xc8bc0c: stp             x0, x2, [SP, #-0x10]!
    // 0xc8bc10: mov             x0, x1
    // 0xc8bc14: mov             lr, x0
    // 0xc8bc18: ldr             lr, [x21, lr, lsl #3]
    // 0xc8bc1c: blr             lr
    // 0xc8bc20: add             SP, SP, #0x10
    // 0xc8bc24: b               #0xc8bc2c
    // 0xc8bc28: r0 = false
    //     0xc8bc28: add             x0, NULL, #0x30  ; false
    // 0xc8bc2c: LeaveFrame
    //     0xc8bc2c: mov             SP, fp
    //     0xc8bc30: ldp             fp, lr, [SP], #0x10
    // 0xc8bc34: ret
    //     0xc8bc34: ret             
    // 0xc8bc38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8bc38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8bc3c: b               #0xc8bb14
  }
}

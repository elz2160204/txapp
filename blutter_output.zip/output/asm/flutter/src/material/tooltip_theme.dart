// lib: , url: package:flutter/src/material/tooltip_theme.dart

// class id: 1049339, size: 0x8
class :: {
}

// class id: 2714, size: 0x3c, field offset: 0x8
//   const constructor, 
class TooltipThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb05938, size: 0x80
    // 0xb05938: EnterFrame
    //     0xb05938: stp             fp, lr, [SP, #-0x10]!
    //     0xb0593c: mov             fp, SP
    // 0xb05940: CheckStackOverflow
    //     0xb05940: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb05944: cmp             SP, x16
    //     0xb05948: b.ls            #0xb059b0
    // 0xb0594c: ldr             x0, [fp, #0x10]
    // 0xb05950: LoadField: r1 = r0->field_7
    //     0xb05950: ldur            w1, [x0, #7]
    // 0xb05954: DecompressPointer r1
    //     0xb05954: add             x1, x1, HEAP, lsl #32
    // 0xb05958: LoadField: r2 = r0->field_13
    //     0xb05958: ldur            w2, [x0, #0x13]
    // 0xb0595c: DecompressPointer r2
    //     0xb0595c: add             x2, x2, HEAP, lsl #32
    // 0xb05960: stp             NULL, x1, [SP, #-0x10]!
    // 0xb05964: stp             x2, NULL, [SP, #-0x10]!
    // 0xb05968: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb0596c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05970: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05974: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb05978: SaveReg rNULL
    //     0xb05978: str             NULL, [SP, #-8]!
    // 0xb0597c: r4 = const [0, 0xd, 0xd, 0xd, null]
    //     0xb0597c: add             x4, PP, #0xd, lsl #12  ; [pp+0xdee0] List(5) [0, 0xd, 0xd, 0xd, Null]
    //     0xb05980: ldr             x4, [x4, #0xee0]
    // 0xb05984: r0 = hash()
    //     0xb05984: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb05988: add             SP, SP, #0x68
    // 0xb0598c: mov             x2, x0
    // 0xb05990: r0 = BoxInt64Instr(r2)
    //     0xb05990: sbfiz           x0, x2, #1, #0x1f
    //     0xb05994: cmp             x2, x0, asr #1
    //     0xb05998: b.eq            #0xb059a4
    //     0xb0599c: bl              #0xd69bb8
    //     0xb059a0: stur            x2, [x0, #7]
    // 0xb059a4: LeaveFrame
    //     0xb059a4: mov             SP, fp
    //     0xb059a8: ldp             fp, lr, [SP], #0x10
    // 0xb059ac: ret
    //     0xb059ac: ret             
    // 0xb059b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb059b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb059b4: b               #0xb0594c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbee6cc, size: 0x108
    // 0xbee6cc: EnterFrame
    //     0xbee6cc: stp             fp, lr, [SP, #-0x10]!
    //     0xbee6d0: mov             fp, SP
    // 0xbee6d4: AllocStack(0x18)
    //     0xbee6d4: sub             SP, SP, #0x18
    // 0xbee6d8: CheckStackOverflow
    //     0xbee6d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbee6dc: cmp             SP, x16
    //     0xbee6e0: b.ls            #0xbee7a8
    // 0xbee6e4: ldr             x0, [fp, #0x20]
    // 0xbee6e8: LoadField: r1 = r0->field_7
    //     0xbee6e8: ldur            w1, [x0, #7]
    // 0xbee6ec: DecompressPointer r1
    //     0xbee6ec: add             x1, x1, HEAP, lsl #32
    // 0xbee6f0: ldr             x2, [fp, #0x18]
    // 0xbee6f4: LoadField: r3 = r2->field_7
    //     0xbee6f4: ldur            w3, [x2, #7]
    // 0xbee6f8: DecompressPointer r3
    //     0xbee6f8: add             x3, x3, HEAP, lsl #32
    // 0xbee6fc: ldr             d0, [fp, #0x10]
    // 0xbee700: r4 = inline_Allocate_Double()
    //     0xbee700: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbee704: add             x4, x4, #0x10
    //     0xbee708: cmp             x5, x4
    //     0xbee70c: b.ls            #0xbee7b0
    //     0xbee710: str             x4, [THR, #0x60]  ; THR::top
    //     0xbee714: sub             x4, x4, #0xf
    //     0xbee718: mov             x5, #0xd108
    //     0xbee71c: movk            x5, #3, lsl #16
    //     0xbee720: stur            x5, [x4, #-1]
    // 0xbee724: StoreField: r4->field_7 = d0
    //     0xbee724: stur            d0, [x4, #7]
    // 0xbee728: stur            x4, [fp, #-8]
    // 0xbee72c: stp             x3, x1, [SP, #-0x10]!
    // 0xbee730: SaveReg r4
    //     0xbee730: str             x4, [SP, #-8]!
    // 0xbee734: r0 = lerpDouble()
    //     0xbee734: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbee738: add             SP, SP, #0x18
    // 0xbee73c: mov             x1, x0
    // 0xbee740: ldr             x0, [fp, #0x20]
    // 0xbee744: stur            x1, [fp, #-0x10]
    // 0xbee748: LoadField: r2 = r0->field_13
    //     0xbee748: ldur            w2, [x0, #0x13]
    // 0xbee74c: DecompressPointer r2
    //     0xbee74c: add             x2, x2, HEAP, lsl #32
    // 0xbee750: ldr             x0, [fp, #0x18]
    // 0xbee754: LoadField: r3 = r0->field_13
    //     0xbee754: ldur            w3, [x0, #0x13]
    // 0xbee758: DecompressPointer r3
    //     0xbee758: add             x3, x3, HEAP, lsl #32
    // 0xbee75c: stp             x3, x2, [SP, #-0x10]!
    // 0xbee760: ldur            x16, [fp, #-8]
    // 0xbee764: SaveReg r16
    //     0xbee764: str             x16, [SP, #-8]!
    // 0xbee768: r0 = lerpDouble()
    //     0xbee768: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbee76c: add             SP, SP, #0x18
    // 0xbee770: stur            x0, [fp, #-0x18]
    // 0xbee774: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee778: ldur            x16, [fp, #-8]
    // 0xbee77c: SaveReg r16
    //     0xbee77c: str             x16, [SP, #-8]!
    // 0xbee780: r0 = lerp()
    //     0xbee780: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbee784: add             SP, SP, #0x18
    // 0xbee788: r0 = TooltipThemeData()
    //     0xbee788: bl              #0xbee7d4  ; AllocateTooltipThemeDataStub -> TooltipThemeData (size=0x3c)
    // 0xbee78c: ldur            x1, [fp, #-0x10]
    // 0xbee790: StoreField: r0->field_7 = r1
    //     0xbee790: stur            w1, [x0, #7]
    // 0xbee794: ldur            x1, [fp, #-0x18]
    // 0xbee798: StoreField: r0->field_13 = r1
    //     0xbee798: stur            w1, [x0, #0x13]
    // 0xbee79c: LeaveFrame
    //     0xbee79c: mov             SP, fp
    //     0xbee7a0: ldp             fp, lr, [SP], #0x10
    // 0xbee7a4: ret
    //     0xbee7a4: ret             
    // 0xbee7a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbee7a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbee7ac: b               #0xbee6e4
    // 0xbee7b0: SaveReg d0
    //     0xbee7b0: str             q0, [SP, #-0x10]!
    // 0xbee7b4: stp             x2, x3, [SP, #-0x10]!
    // 0xbee7b8: stp             x0, x1, [SP, #-0x10]!
    // 0xbee7bc: r0 = AllocateDouble()
    //     0xbee7bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbee7c0: mov             x4, x0
    // 0xbee7c4: ldp             x0, x1, [SP], #0x10
    // 0xbee7c8: ldp             x2, x3, [SP], #0x10
    // 0xbee7cc: RestoreReg d0
    //     0xbee7cc: ldr             q0, [SP], #0x10
    // 0xbee7d0: b               #0xbee724
  }
  _ ==(/* No info */) {
    // ** addr: 0xc92c38, size: 0x168
    // 0xc92c38: EnterFrame
    //     0xc92c38: stp             fp, lr, [SP, #-0x10]!
    //     0xc92c3c: mov             fp, SP
    // 0xc92c40: CheckStackOverflow
    //     0xc92c40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc92c44: cmp             SP, x16
    //     0xc92c48: b.ls            #0xc92d98
    // 0xc92c4c: ldr             x1, [fp, #0x10]
    // 0xc92c50: cmp             w1, NULL
    // 0xc92c54: b.ne            #0xc92c68
    // 0xc92c58: r0 = false
    //     0xc92c58: add             x0, NULL, #0x30  ; false
    // 0xc92c5c: LeaveFrame
    //     0xc92c5c: mov             SP, fp
    //     0xc92c60: ldp             fp, lr, [SP], #0x10
    // 0xc92c64: ret
    //     0xc92c64: ret             
    // 0xc92c68: ldr             x2, [fp, #0x18]
    // 0xc92c6c: cmp             w2, w1
    // 0xc92c70: b.ne            #0xc92c84
    // 0xc92c74: r0 = true
    //     0xc92c74: add             x0, NULL, #0x20  ; true
    // 0xc92c78: LeaveFrame
    //     0xc92c78: mov             SP, fp
    //     0xc92c7c: ldp             fp, lr, [SP], #0x10
    // 0xc92c80: ret
    //     0xc92c80: ret             
    // 0xc92c84: r0 = 59
    //     0xc92c84: mov             x0, #0x3b
    // 0xc92c88: branchIfSmi(r1, 0xc92c94)
    //     0xc92c88: tbz             w1, #0, #0xc92c94
    // 0xc92c8c: r0 = LoadClassIdInstr(r1)
    //     0xc92c8c: ldur            x0, [x1, #-1]
    //     0xc92c90: ubfx            x0, x0, #0xc, #0x14
    // 0xc92c94: SaveReg r1
    //     0xc92c94: str             x1, [SP, #-8]!
    // 0xc92c98: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc92c98: mov             x17, #0x57c5
    //     0xc92c9c: add             lr, x0, x17
    //     0xc92ca0: ldr             lr, [x21, lr, lsl #3]
    //     0xc92ca4: blr             lr
    // 0xc92ca8: add             SP, SP, #8
    // 0xc92cac: r1 = LoadClassIdInstr(r0)
    //     0xc92cac: ldur            x1, [x0, #-1]
    //     0xc92cb0: ubfx            x1, x1, #0xc, #0x14
    // 0xc92cb4: r16 = TooltipThemeData
    //     0xc92cb4: add             x16, PP, #0xd, lsl #12  ; [pp+0xded8] Type: TooltipThemeData
    //     0xc92cb8: ldr             x16, [x16, #0xed8]
    // 0xc92cbc: stp             x16, x0, [SP, #-0x10]!
    // 0xc92cc0: mov             x0, x1
    // 0xc92cc4: mov             lr, x0
    // 0xc92cc8: ldr             lr, [x21, lr, lsl #3]
    // 0xc92ccc: blr             lr
    // 0xc92cd0: add             SP, SP, #0x10
    // 0xc92cd4: tbz             w0, #4, #0xc92ce8
    // 0xc92cd8: r0 = false
    //     0xc92cd8: add             x0, NULL, #0x30  ; false
    // 0xc92cdc: LeaveFrame
    //     0xc92cdc: mov             SP, fp
    //     0xc92ce0: ldp             fp, lr, [SP], #0x10
    // 0xc92ce4: ret
    //     0xc92ce4: ret             
    // 0xc92ce8: ldr             x1, [fp, #0x10]
    // 0xc92cec: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc92cec: mov             x0, #0x76
    //     0xc92cf0: tbz             w1, #0, #0xc92d00
    //     0xc92cf4: ldur            x0, [x1, #-1]
    //     0xc92cf8: ubfx            x0, x0, #0xc, #0x14
    //     0xc92cfc: lsl             x0, x0, #1
    // 0xc92d00: r17 = 5428
    //     0xc92d00: mov             x17, #0x1534
    // 0xc92d04: cmp             w0, w17
    // 0xc92d08: b.ne            #0xc92d88
    // 0xc92d0c: ldr             x2, [fp, #0x18]
    // 0xc92d10: LoadField: r0 = r1->field_7
    //     0xc92d10: ldur            w0, [x1, #7]
    // 0xc92d14: DecompressPointer r0
    //     0xc92d14: add             x0, x0, HEAP, lsl #32
    // 0xc92d18: LoadField: r3 = r2->field_7
    //     0xc92d18: ldur            w3, [x2, #7]
    // 0xc92d1c: DecompressPointer r3
    //     0xc92d1c: add             x3, x3, HEAP, lsl #32
    // 0xc92d20: r4 = LoadClassIdInstr(r0)
    //     0xc92d20: ldur            x4, [x0, #-1]
    //     0xc92d24: ubfx            x4, x4, #0xc, #0x14
    // 0xc92d28: stp             x3, x0, [SP, #-0x10]!
    // 0xc92d2c: mov             x0, x4
    // 0xc92d30: mov             lr, x0
    // 0xc92d34: ldr             lr, [x21, lr, lsl #3]
    // 0xc92d38: blr             lr
    // 0xc92d3c: add             SP, SP, #0x10
    // 0xc92d40: tbnz            w0, #4, #0xc92d88
    // 0xc92d44: ldr             x1, [fp, #0x18]
    // 0xc92d48: ldr             x0, [fp, #0x10]
    // 0xc92d4c: LoadField: r2 = r0->field_13
    //     0xc92d4c: ldur            w2, [x0, #0x13]
    // 0xc92d50: DecompressPointer r2
    //     0xc92d50: add             x2, x2, HEAP, lsl #32
    // 0xc92d54: LoadField: r0 = r1->field_13
    //     0xc92d54: ldur            w0, [x1, #0x13]
    // 0xc92d58: DecompressPointer r0
    //     0xc92d58: add             x0, x0, HEAP, lsl #32
    // 0xc92d5c: r1 = LoadClassIdInstr(r2)
    //     0xc92d5c: ldur            x1, [x2, #-1]
    //     0xc92d60: ubfx            x1, x1, #0xc, #0x14
    // 0xc92d64: stp             x0, x2, [SP, #-0x10]!
    // 0xc92d68: mov             x0, x1
    // 0xc92d6c: mov             lr, x0
    // 0xc92d70: ldr             lr, [x21, lr, lsl #3]
    // 0xc92d74: blr             lr
    // 0xc92d78: add             SP, SP, #0x10
    // 0xc92d7c: tbnz            w0, #4, #0xc92d88
    // 0xc92d80: r0 = true
    //     0xc92d80: add             x0, NULL, #0x20  ; true
    // 0xc92d84: b               #0xc92d8c
    // 0xc92d88: r0 = false
    //     0xc92d88: add             x0, NULL, #0x30  ; false
    // 0xc92d8c: LeaveFrame
    //     0xc92d8c: mov             SP, fp
    //     0xc92d90: ldp             fp, lr, [SP], #0x10
    // 0xc92d94: ret
    //     0xc92d94: ret             
    // 0xc92d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc92d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc92d9c: b               #0xc92c4c
  }
}

// class id: 3536, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class TooltipTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0x874630, size: 0x64
    // 0x874630: EnterFrame
    //     0x874630: stp             fp, lr, [SP, #-0x10]!
    //     0x874634: mov             fp, SP
    // 0x874638: CheckStackOverflow
    //     0x874638: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87463c: cmp             SP, x16
    //     0x874640: b.ls            #0x87468c
    // 0x874644: r16 = <TooltipTheme>
    //     0x874644: add             x16, PP, #0x50, lsl #12  ; [pp+0x504d8] TypeArguments: <TooltipTheme>
    //     0x874648: ldr             x16, [x16, #0x4d8]
    // 0x87464c: ldr             lr, [fp, #0x10]
    // 0x874650: stp             lr, x16, [SP, #-0x10]!
    // 0x874654: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x874654: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x874658: r0 = dependOnInheritedWidgetOfExactType()
    //     0x874658: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x87465c: add             SP, SP, #0x10
    // 0x874660: ldr             x16, [fp, #0x10]
    // 0x874664: SaveReg r16
    //     0x874664: str             x16, [SP, #-8]!
    // 0x874668: r0 = of()
    //     0x874668: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x87466c: add             SP, SP, #8
    // 0x874670: r17 = 319
    //     0x874670: mov             x17, #0x13f
    // 0x874674: ldr             w1, [x0, x17]
    // 0x874678: DecompressPointer r1
    //     0x874678: add             x1, x1, HEAP, lsl #32
    // 0x87467c: mov             x0, x1
    // 0x874680: LeaveFrame
    //     0x874680: mov             SP, fp
    //     0x874684: ldp             fp, lr, [SP], #0x10
    // 0x874688: ret
    //     0x874688: ret             
    // 0x87468c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87468c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874690: b               #0x874644
  }
}

// class id: 5942, size: 0x14, field offset: 0x14
enum TooltipTriggerMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb166f8, size: 0x5c
    // 0xb166f8: EnterFrame
    //     0xb166f8: stp             fp, lr, [SP, #-0x10]!
    //     0xb166fc: mov             fp, SP
    // 0xb16700: CheckStackOverflow
    //     0xb16700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16704: cmp             SP, x16
    //     0xb16708: b.ls            #0xb1674c
    // 0xb1670c: r1 = Null
    //     0xb1670c: mov             x1, NULL
    // 0xb16710: r2 = 4
    //     0xb16710: mov             x2, #4
    // 0xb16714: r0 = AllocateArray()
    //     0xb16714: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16718: r17 = "TooltipTriggerMode."
    //     0xb16718: add             x17, PP, #0x53, lsl #12  ; [pp+0x53030] "TooltipTriggerMode."
    //     0xb1671c: ldr             x17, [x17, #0x30]
    // 0xb16720: StoreField: r0->field_f = r17
    //     0xb16720: stur            w17, [x0, #0xf]
    // 0xb16724: ldr             x1, [fp, #0x10]
    // 0xb16728: LoadField: r2 = r1->field_f
    //     0xb16728: ldur            w2, [x1, #0xf]
    // 0xb1672c: DecompressPointer r2
    //     0xb1672c: add             x2, x2, HEAP, lsl #32
    // 0xb16730: StoreField: r0->field_13 = r2
    //     0xb16730: stur            w2, [x0, #0x13]
    // 0xb16734: SaveReg r0
    //     0xb16734: str             x0, [SP, #-8]!
    // 0xb16738: r0 = _interpolate()
    //     0xb16738: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1673c: add             SP, SP, #8
    // 0xb16740: LeaveFrame
    //     0xb16740: mov             SP, fp
    //     0xb16744: ldp             fp, lr, [SP], #0x10
    // 0xb16748: ret
    //     0xb16748: ret             
    // 0xb1674c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1674c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16750: b               #0xb1670c
  }
}

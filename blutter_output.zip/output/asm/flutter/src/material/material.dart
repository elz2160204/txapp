// lib: , url: package:flutter/src/material/material.dart

// class id: 1049267, size: 0x8
class :: {
}

// class id: 2167, size: 0x8, field offset: 0x8
abstract class MaterialInkController extends Object {
}

// class id: 2194, size: 0x14, field offset: 0x8
abstract class InkFeature extends Object {

  _ _paint(/* No info */) {
    // ** addr: 0x660864, size: 0x320
    // 0x660864: EnterFrame
    //     0x660864: stp             fp, lr, [SP, #-0x10]!
    //     0x660868: mov             fp, SP
    // 0x66086c: AllocStack(0x28)
    //     0x66086c: sub             SP, SP, #0x28
    // 0x660870: r0 = 2
    //     0x660870: mov             x0, #2
    // 0x660874: CheckStackOverflow
    //     0x660874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x660878: cmp             SP, x16
    //     0x66087c: b.ls            #0x660b5c
    // 0x660880: ldr             x3, [fp, #0x18]
    // 0x660884: LoadField: r4 = r3->field_b
    //     0x660884: ldur            w4, [x3, #0xb]
    // 0x660888: DecompressPointer r4
    //     0x660888: add             x4, x4, HEAP, lsl #32
    // 0x66088c: mov             x2, x0
    // 0x660890: stur            x4, [fp, #-8]
    // 0x660894: r1 = Null
    //     0x660894: mov             x1, NULL
    // 0x660898: r0 = AllocateArray()
    //     0x660898: bl              #0xd6987c  ; AllocateArrayStub
    // 0x66089c: mov             x2, x0
    // 0x6608a0: ldur            x0, [fp, #-8]
    // 0x6608a4: stur            x2, [fp, #-0x10]
    // 0x6608a8: StoreField: r2->field_f = r0
    //     0x6608a8: stur            w0, [x2, #0xf]
    // 0x6608ac: r1 = <RenderObject>
    //     0x6608ac: ldr             x1, [PP, #0x4988]  ; [pp+0x4988] TypeArguments: <RenderObject>
    // 0x6608b0: r0 = AllocateGrowableArray()
    //     0x6608b0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x6608b4: mov             x1, x0
    // 0x6608b8: ldur            x0, [fp, #-0x10]
    // 0x6608bc: stur            x1, [fp, #-0x18]
    // 0x6608c0: StoreField: r1->field_f = r0
    //     0x6608c0: stur            w0, [x1, #0xf]
    // 0x6608c4: r0 = 2
    //     0x6608c4: mov             x0, #2
    // 0x6608c8: StoreField: r1->field_b = r0
    //     0x6608c8: stur            w0, [x1, #0xb]
    // 0x6608cc: ldr             x2, [fp, #0x18]
    // 0x6608d0: LoadField: r3 = r2->field_7
    //     0x6608d0: ldur            w3, [x2, #7]
    // 0x6608d4: DecompressPointer r3
    //     0x6608d4: add             x3, x3, HEAP, lsl #32
    // 0x6608d8: stur            x3, [fp, #-0x10]
    // 0x6608dc: ldur            x4, [fp, #-8]
    // 0x6608e0: stur            x4, [fp, #-8]
    // 0x6608e4: CheckStackOverflow
    //     0x6608e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6608e8: cmp             SP, x16
    //     0x6608ec: b.ls            #0x660b64
    // 0x6608f0: cmp             w4, w3
    // 0x6608f4: b.eq            #0x660a34
    // 0x6608f8: r0 = LoadClassIdInstr(r4)
    //     0x6608f8: ldur            x0, [x4, #-1]
    //     0x6608fc: ubfx            x0, x0, #0xc, #0x14
    // 0x660900: SaveReg r4
    //     0x660900: str             x4, [SP, #-8]!
    // 0x660904: r0 = GDT[cid_x0 + 0xa2f1]()
    //     0x660904: mov             x17, #0xa2f1
    //     0x660908: add             lr, x0, x17
    //     0x66090c: ldr             lr, [x21, lr, lsl #3]
    //     0x660910: blr             lr
    // 0x660914: add             SP, SP, #8
    // 0x660918: mov             x3, x0
    // 0x66091c: stur            x3, [fp, #-0x20]
    // 0x660920: cmp             w3, NULL
    // 0x660924: b.eq            #0x660b6c
    // 0x660928: mov             x0, x3
    // 0x66092c: r2 = Null
    //     0x66092c: mov             x2, NULL
    // 0x660930: r1 = Null
    //     0x660930: mov             x1, NULL
    // 0x660934: r4 = LoadClassIdInstr(r0)
    //     0x660934: ldur            x4, [x0, #-1]
    //     0x660938: ubfx            x4, x4, #0xc, #0x14
    // 0x66093c: sub             x4, x4, #0x961
    // 0x660940: cmp             x4, #0xbe
    // 0x660944: b.ls            #0x660958
    // 0x660948: r8 = RenderObject
    //     0x660948: ldr             x8, [PP, #0x4b68]  ; [pp+0x4b68] Type: RenderObject
    // 0x66094c: r3 = Null
    //     0x66094c: add             x3, PP, #0x22, lsl #12  ; [pp+0x22088] Null
    //     0x660950: ldr             x3, [x3, #0x88]
    // 0x660954: r0 = RenderObject()
    //     0x660954: bl              #0x5093b4  ; IsType_RenderObject_Stub
    // 0x660958: ldur            x1, [fp, #-0x20]
    // 0x66095c: r0 = LoadClassIdInstr(r1)
    //     0x66095c: ldur            x0, [x1, #-1]
    //     0x660960: ubfx            x0, x0, #0xc, #0x14
    // 0x660964: ldur            x16, [fp, #-8]
    // 0x660968: stp             x16, x1, [SP, #-0x10]!
    // 0x66096c: r0 = GDT[cid_x0 + 0xee2a]()
    //     0x66096c: mov             x17, #0xee2a
    //     0x660970: add             lr, x0, x17
    //     0x660974: ldr             lr, [x21, lr, lsl #3]
    //     0x660978: blr             lr
    // 0x66097c: add             SP, SP, #0x10
    // 0x660980: tbz             w0, #4, #0x660994
    // 0x660984: r0 = Null
    //     0x660984: mov             x0, NULL
    // 0x660988: LeaveFrame
    //     0x660988: mov             SP, fp
    //     0x66098c: ldp             fp, lr, [SP], #0x10
    // 0x660990: ret
    //     0x660990: ret             
    // 0x660994: ldur            x0, [fp, #-0x18]
    // 0x660998: LoadField: r1 = r0->field_b
    //     0x660998: ldur            w1, [x0, #0xb]
    // 0x66099c: DecompressPointer r1
    //     0x66099c: add             x1, x1, HEAP, lsl #32
    // 0x6609a0: stur            x1, [fp, #-8]
    // 0x6609a4: LoadField: r2 = r0->field_f
    //     0x6609a4: ldur            w2, [x0, #0xf]
    // 0x6609a8: DecompressPointer r2
    //     0x6609a8: add             x2, x2, HEAP, lsl #32
    // 0x6609ac: LoadField: r3 = r2->field_b
    //     0x6609ac: ldur            w3, [x2, #0xb]
    // 0x6609b0: DecompressPointer r3
    //     0x6609b0: add             x3, x3, HEAP, lsl #32
    // 0x6609b4: cmp             w1, w3
    // 0x6609b8: b.ne            #0x6609c8
    // 0x6609bc: SaveReg r0
    //     0x6609bc: str             x0, [SP, #-8]!
    // 0x6609c0: r0 = _growToNextCapacity()
    //     0x6609c0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6609c4: add             SP, SP, #8
    // 0x6609c8: ldur            x0, [fp, #-8]
    // 0x6609cc: ldur            x2, [fp, #-0x18]
    // 0x6609d0: r3 = LoadInt32Instr(r0)
    //     0x6609d0: sbfx            x3, x0, #1, #0x1f
    // 0x6609d4: add             x0, x3, #1
    // 0x6609d8: lsl             x1, x0, #1
    // 0x6609dc: StoreField: r2->field_b = r1
    //     0x6609dc: stur            w1, [x2, #0xb]
    // 0x6609e0: mov             x1, x3
    // 0x6609e4: cmp             x1, x0
    // 0x6609e8: b.hs            #0x660b70
    // 0x6609ec: LoadField: r1 = r2->field_f
    //     0x6609ec: ldur            w1, [x2, #0xf]
    // 0x6609f0: DecompressPointer r1
    //     0x6609f0: add             x1, x1, HEAP, lsl #32
    // 0x6609f4: ldur            x0, [fp, #-0x20]
    // 0x6609f8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x6609f8: add             x25, x1, x3, lsl #2
    //     0x6609fc: add             x25, x25, #0xf
    //     0x660a00: str             w0, [x25]
    //     0x660a04: tbz             w0, #0, #0x660a20
    //     0x660a08: ldurb           w16, [x1, #-1]
    //     0x660a0c: ldurb           w17, [x0, #-1]
    //     0x660a10: and             x16, x17, x16, lsr #2
    //     0x660a14: tst             x16, HEAP, lsr #32
    //     0x660a18: b.eq            #0x660a20
    //     0x660a1c: bl              #0xd67e5c
    // 0x660a20: ldur            x4, [fp, #-0x20]
    // 0x660a24: mov             x1, x2
    // 0x660a28: ldr             x2, [fp, #0x18]
    // 0x660a2c: ldur            x3, [fp, #-0x10]
    // 0x660a30: b               #0x6608e0
    // 0x660a34: mov             x2, x1
    // 0x660a38: r0 = Matrix4()
    //     0x660a38: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x660a3c: r4 = 32
    //     0x660a3c: mov             x4, #0x20
    // 0x660a40: stur            x0, [fp, #-8]
    // 0x660a44: r0 = AllocateFloat64Array()
    //     0x660a44: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x660a48: mov             x1, x0
    // 0x660a4c: ldur            x0, [fp, #-8]
    // 0x660a50: StoreField: r0->field_7 = r1
    //     0x660a50: stur            w1, [x0, #7]
    // 0x660a54: SaveReg r0
    //     0x660a54: str             x0, [SP, #-8]!
    // 0x660a58: r0 = setIdentity()
    //     0x660a58: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0x660a5c: add             SP, SP, #8
    // 0x660a60: ldur            x2, [fp, #-0x18]
    // 0x660a64: LoadField: r0 = r2->field_b
    //     0x660a64: ldur            w0, [x2, #0xb]
    // 0x660a68: DecompressPointer r0
    //     0x660a68: add             x0, x0, HEAP, lsl #32
    // 0x660a6c: r1 = LoadInt32Instr(r0)
    //     0x660a6c: sbfx            x1, x0, #1, #0x1f
    // 0x660a70: sub             x0, x1, #1
    // 0x660a74: mov             x3, x0
    // 0x660a78: CheckStackOverflow
    //     0x660a78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x660a7c: cmp             SP, x16
    //     0x660a80: b.ls            #0x660b74
    // 0x660a84: cmp             x3, #0
    // 0x660a88: b.le            #0x660b18
    // 0x660a8c: LoadField: r0 = r2->field_b
    //     0x660a8c: ldur            w0, [x2, #0xb]
    // 0x660a90: DecompressPointer r0
    //     0x660a90: add             x0, x0, HEAP, lsl #32
    // 0x660a94: r4 = LoadInt32Instr(r0)
    //     0x660a94: sbfx            x4, x0, #1, #0x1f
    // 0x660a98: mov             x0, x4
    // 0x660a9c: mov             x1, x3
    // 0x660aa0: cmp             x1, x0
    // 0x660aa4: b.hs            #0x660b7c
    // 0x660aa8: LoadField: r5 = r2->field_f
    //     0x660aa8: ldur            w5, [x2, #0xf]
    // 0x660aac: DecompressPointer r5
    //     0x660aac: add             x5, x5, HEAP, lsl #32
    // 0x660ab0: ArrayLoad: r6 = r5[r3]  ; Unknown_4
    //     0x660ab0: add             x16, x5, x3, lsl #2
    //     0x660ab4: ldur            w6, [x16, #0xf]
    // 0x660ab8: DecompressPointer r6
    //     0x660ab8: add             x6, x6, HEAP, lsl #32
    // 0x660abc: sub             x7, x3, #1
    // 0x660ac0: mov             x0, x4
    // 0x660ac4: mov             x1, x7
    // 0x660ac8: stur            x7, [fp, #-0x28]
    // 0x660acc: cmp             x1, x0
    // 0x660ad0: b.hs            #0x660b80
    // 0x660ad4: ArrayLoad: r0 = r5[r7]  ; Unknown_4
    //     0x660ad4: add             x16, x5, x7, lsl #2
    //     0x660ad8: ldur            w0, [x16, #0xf]
    // 0x660adc: DecompressPointer r0
    //     0x660adc: add             x0, x0, HEAP, lsl #32
    // 0x660ae0: r1 = LoadClassIdInstr(r6)
    //     0x660ae0: ldur            x1, [x6, #-1]
    //     0x660ae4: ubfx            x1, x1, #0xc, #0x14
    // 0x660ae8: stp             x0, x6, [SP, #-0x10]!
    // 0x660aec: ldur            x16, [fp, #-8]
    // 0x660af0: SaveReg r16
    //     0x660af0: str             x16, [SP, #-8]!
    // 0x660af4: mov             x0, x1
    // 0x660af8: r0 = GDT[cid_x0 + 0xd590]()
    //     0x660af8: mov             x17, #0xd590
    //     0x660afc: add             lr, x0, x17
    //     0x660b00: ldr             lr, [x21, lr, lsl #3]
    //     0x660b04: blr             lr
    // 0x660b08: add             SP, SP, #0x18
    // 0x660b0c: ldur            x3, [fp, #-0x28]
    // 0x660b10: ldur            x2, [fp, #-0x18]
    // 0x660b14: b               #0x660a78
    // 0x660b18: ldr             x0, [fp, #0x18]
    // 0x660b1c: r1 = LoadClassIdInstr(r0)
    //     0x660b1c: ldur            x1, [x0, #-1]
    //     0x660b20: ubfx            x1, x1, #0xc, #0x14
    // 0x660b24: ldr             x16, [fp, #0x10]
    // 0x660b28: stp             x16, x0, [SP, #-0x10]!
    // 0x660b2c: ldur            x16, [fp, #-8]
    // 0x660b30: SaveReg r16
    //     0x660b30: str             x16, [SP, #-8]!
    // 0x660b34: mov             x0, x1
    // 0x660b38: r0 = GDT[cid_x0 + 0x188c]()
    //     0x660b38: mov             x17, #0x188c
    //     0x660b3c: add             lr, x0, x17
    //     0x660b40: ldr             lr, [x21, lr, lsl #3]
    //     0x660b44: blr             lr
    // 0x660b48: add             SP, SP, #0x18
    // 0x660b4c: r0 = Null
    //     0x660b4c: mov             x0, NULL
    // 0x660b50: LeaveFrame
    //     0x660b50: mov             SP, fp
    //     0x660b54: ldp             fp, lr, [SP], #0x10
    // 0x660b58: ret
    //     0x660b58: ret             
    // 0x660b5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660b5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660b60: b               #0x660880
    // 0x660b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660b64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660b68: b               #0x6608f0
    // 0x660b6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660b6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x660b70: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x660b70: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x660b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660b74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660b78: b               #0x660a84
    // 0x660b7c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x660b7c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x660b80: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x660b80: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x795b14, size: 0x70
    // 0x795b14: EnterFrame
    //     0x795b14: stp             fp, lr, [SP, #-0x10]!
    //     0x795b18: mov             fp, SP
    // 0x795b1c: CheckStackOverflow
    //     0x795b1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795b20: cmp             SP, x16
    //     0x795b24: b.ls            #0x795b7c
    // 0x795b28: ldr             x0, [fp, #0x10]
    // 0x795b2c: LoadField: r1 = r0->field_7
    //     0x795b2c: ldur            w1, [x0, #7]
    // 0x795b30: DecompressPointer r1
    //     0x795b30: add             x1, x1, HEAP, lsl #32
    // 0x795b34: stp             x0, x1, [SP, #-0x10]!
    // 0x795b38: r0 = _removeFeature()
    //     0x795b38: bl              #0x795b84  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::_removeFeature
    // 0x795b3c: add             SP, SP, #0x10
    // 0x795b40: ldr             x0, [fp, #0x10]
    // 0x795b44: LoadField: r1 = r0->field_f
    //     0x795b44: ldur            w1, [x0, #0xf]
    // 0x795b48: DecompressPointer r1
    //     0x795b48: add             x1, x1, HEAP, lsl #32
    // 0x795b4c: cmp             w1, NULL
    // 0x795b50: b.eq            #0x795b6c
    // 0x795b54: SaveReg r1
    //     0x795b54: str             x1, [SP, #-8]!
    // 0x795b58: mov             x0, x1
    // 0x795b5c: ClosureCall
    //     0x795b5c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x795b60: ldur            x2, [x0, #0x1f]
    //     0x795b64: blr             x2
    // 0x795b68: add             SP, SP, #8
    // 0x795b6c: r0 = Null
    //     0x795b6c: mov             x0, NULL
    // 0x795b70: LeaveFrame
    //     0x795b70: mov             SP, fp
    //     0x795b74: ldp             fp, lr, [SP], #0x10
    // 0x795b78: ret
    //     0x795b78: ret             
    // 0x795b7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795b7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795b80: b               #0x795b28
  }
}

// class id: 2523, size: 0x74, field offset: 0x64
class _RenderInkFeatures extends RenderProxyBox
    implements MaterialInkController {

  _ hitTestSelf(/* No info */) {
    // ** addr: 0x62b5fc, size: 0x10
    // 0x62b5fc: ldr             x1, [SP, #8]
    // 0x62b600: LoadField: r0 = r1->field_6b
    //     0x62b600: ldur            w0, [x1, #0x6b]
    // 0x62b604: DecompressPointer r0
    //     0x62b604: add             x0, x0, HEAP, lsl #32
    // 0x62b608: ret
    //     0x62b608: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x6605bc, size: 0x2a8
    // 0x6605bc: EnterFrame
    //     0x6605bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6605c0: mov             fp, SP
    // 0x6605c4: AllocStack(0x38)
    //     0x6605c4: sub             SP, SP, #0x38
    // 0x6605c8: CheckStackOverflow
    //     0x6605c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6605cc: cmp             SP, x16
    //     0x6605d0: b.ls            #0x660830
    // 0x6605d4: ldr             x0, [fp, #0x20]
    // 0x6605d8: LoadField: r1 = r0->field_6f
    //     0x6605d8: ldur            w1, [x0, #0x6f]
    // 0x6605dc: DecompressPointer r1
    //     0x6605dc: add             x1, x1, HEAP, lsl #32
    // 0x6605e0: cmp             w1, NULL
    // 0x6605e4: b.eq            #0x6607ec
    // 0x6605e8: LoadField: r2 = r1->field_b
    //     0x6605e8: ldur            w2, [x1, #0xb]
    // 0x6605ec: DecompressPointer r2
    //     0x6605ec: add             x2, x2, HEAP, lsl #32
    // 0x6605f0: cbz             w2, #0x6607ec
    // 0x6605f4: ldr             x1, [fp, #0x10]
    // 0x6605f8: ldr             x16, [fp, #0x18]
    // 0x6605fc: SaveReg r16
    //     0x6605fc: str             x16, [SP, #-8]!
    // 0x660600: r0 = canvas()
    //     0x660600: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x660604: add             SP, SP, #8
    // 0x660608: stur            x0, [fp, #-8]
    // 0x66060c: SaveReg r0
    //     0x66060c: str             x0, [SP, #-8]!
    // 0x660610: r0 = save()
    //     0x660610: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0x660614: add             SP, SP, #8
    // 0x660618: ldr             x0, [fp, #0x10]
    // 0x66061c: LoadField: d0 = r0->field_7
    //     0x66061c: ldur            d0, [x0, #7]
    // 0x660620: LoadField: d1 = r0->field_f
    //     0x660620: ldur            d1, [x0, #0xf]
    // 0x660624: r1 = inline_Allocate_Double()
    //     0x660624: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x660628: add             x1, x1, #0x10
    //     0x66062c: cmp             x2, x1
    //     0x660630: b.ls            #0x660838
    //     0x660634: str             x1, [THR, #0x60]  ; THR::top
    //     0x660638: sub             x1, x1, #0xf
    //     0x66063c: mov             x2, #0xd108
    //     0x660640: movk            x2, #3, lsl #16
    //     0x660644: stur            x2, [x1, #-1]
    // 0x660648: StoreField: r1->field_7 = d0
    //     0x660648: stur            d0, [x1, #7]
    // 0x66064c: ldur            x16, [fp, #-8]
    // 0x660650: stp             x1, x16, [SP, #-0x10]!
    // 0x660654: SaveReg d1
    //     0x660654: str             d1, [SP, #-8]!
    // 0x660658: r0 = translate()
    //     0x660658: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0x66065c: add             SP, SP, #0x18
    // 0x660660: ldr             x0, [fp, #0x20]
    // 0x660664: LoadField: r1 = r0->field_57
    //     0x660664: ldur            w1, [x0, #0x57]
    // 0x660668: DecompressPointer r1
    //     0x660668: add             x1, x1, HEAP, lsl #32
    // 0x66066c: cmp             w1, NULL
    // 0x660670: b.eq            #0x660854
    // 0x660674: r16 = Instance_Offset
    //     0x660674: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x660678: stp             x1, x16, [SP, #-0x10]!
    // 0x66067c: r0 = &()
    //     0x66067c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x660680: add             SP, SP, #0x10
    // 0x660684: ldur            x16, [fp, #-8]
    // 0x660688: stp             x0, x16, [SP, #-0x10]!
    // 0x66068c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x66068c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x660690: r0 = clipRect()
    //     0x660690: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0x660694: add             SP, SP, #0x10
    // 0x660698: ldr             x1, [fp, #0x20]
    // 0x66069c: LoadField: r2 = r1->field_6f
    //     0x66069c: ldur            w2, [x1, #0x6f]
    // 0x6606a0: DecompressPointer r2
    //     0x6606a0: add             x2, x2, HEAP, lsl #32
    // 0x6606a4: stur            x2, [fp, #-0x28]
    // 0x6606a8: cmp             w2, NULL
    // 0x6606ac: b.eq            #0x660858
    // 0x6606b0: LoadField: r3 = r2->field_7
    //     0x6606b0: ldur            w3, [x2, #7]
    // 0x6606b4: DecompressPointer r3
    //     0x6606b4: add             x3, x3, HEAP, lsl #32
    // 0x6606b8: stur            x3, [fp, #-0x20]
    // 0x6606bc: LoadField: r0 = r2->field_b
    //     0x6606bc: ldur            w0, [x2, #0xb]
    // 0x6606c0: DecompressPointer r0
    //     0x6606c0: add             x0, x0, HEAP, lsl #32
    // 0x6606c4: r4 = LoadInt32Instr(r0)
    //     0x6606c4: sbfx            x4, x0, #1, #0x1f
    // 0x6606c8: stur            x4, [fp, #-0x18]
    // 0x6606cc: r5 = 0
    //     0x6606cc: mov             x5, #0
    // 0x6606d0: stur            x5, [fp, #-0x10]
    // 0x6606d4: CheckStackOverflow
    //     0x6606d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6606d8: cmp             SP, x16
    //     0x6606dc: b.ls            #0x66085c
    // 0x6606e0: r0 = LoadClassIdInstr(r2)
    //     0x6606e0: ldur            x0, [x2, #-1]
    //     0x6606e4: ubfx            x0, x0, #0xc, #0x14
    // 0x6606e8: SaveReg r2
    //     0x6606e8: str             x2, [SP, #-8]!
    // 0x6606ec: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x6606ec: mov             x17, #0xb8ea
    //     0x6606f0: add             lr, x0, x17
    //     0x6606f4: ldr             lr, [x21, lr, lsl #3]
    //     0x6606f8: blr             lr
    // 0x6606fc: add             SP, SP, #8
    // 0x660700: r1 = LoadInt32Instr(r0)
    //     0x660700: sbfx            x1, x0, #1, #0x1f
    //     0x660704: tbz             w0, #0, #0x66070c
    //     0x660708: ldur            x1, [x0, #7]
    // 0x66070c: ldur            x2, [fp, #-0x18]
    // 0x660710: cmp             x2, x1
    // 0x660714: b.ne            #0x660818
    // 0x660718: ldur            x3, [fp, #-0x28]
    // 0x66071c: ldur            x4, [fp, #-0x10]
    // 0x660720: cmp             x4, x1
    // 0x660724: b.lt            #0x66073c
    // 0x660728: ldur            x16, [fp, #-8]
    // 0x66072c: SaveReg r16
    //     0x66072c: str             x16, [SP, #-8]!
    // 0x660730: r0 = restore()
    //     0x660730: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0x660734: add             SP, SP, #8
    // 0x660738: b               #0x6607ec
    // 0x66073c: r0 = BoxInt64Instr(r4)
    //     0x66073c: sbfiz           x0, x4, #1, #0x1f
    //     0x660740: cmp             x4, x0, asr #1
    //     0x660744: b.eq            #0x660750
    //     0x660748: bl              #0xd69bb8
    //     0x66074c: stur            x4, [x0, #7]
    // 0x660750: r1 = LoadClassIdInstr(r3)
    //     0x660750: ldur            x1, [x3, #-1]
    //     0x660754: ubfx            x1, x1, #0xc, #0x14
    // 0x660758: stp             x0, x3, [SP, #-0x10]!
    // 0x66075c: mov             x0, x1
    // 0x660760: r0 = GDT[cid_x0 + 0xd175]()
    //     0x660760: mov             x17, #0xd175
    //     0x660764: add             lr, x0, x17
    //     0x660768: ldr             lr, [x21, lr, lsl #3]
    //     0x66076c: blr             lr
    // 0x660770: add             SP, SP, #0x10
    // 0x660774: mov             x3, x0
    // 0x660778: ldur            x0, [fp, #-0x10]
    // 0x66077c: stur            x3, [fp, #-0x38]
    // 0x660780: add             x5, x0, #1
    // 0x660784: stur            x5, [fp, #-0x30]
    // 0x660788: cmp             w3, NULL
    // 0x66078c: b.ne            #0x6607c0
    // 0x660790: mov             x0, x3
    // 0x660794: ldur            x2, [fp, #-0x20]
    // 0x660798: r1 = Null
    //     0x660798: mov             x1, NULL
    // 0x66079c: cmp             w2, NULL
    // 0x6607a0: b.eq            #0x6607c0
    // 0x6607a4: LoadField: r4 = r2->field_17
    //     0x6607a4: ldur            w4, [x2, #0x17]
    // 0x6607a8: DecompressPointer r4
    //     0x6607a8: add             x4, x4, HEAP, lsl #32
    // 0x6607ac: r8 = X0
    //     0x6607ac: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6607b0: LoadField: r9 = r4->field_7
    //     0x6607b0: ldur            x9, [x4, #7]
    // 0x6607b4: r3 = Null
    //     0x6607b4: add             x3, PP, #0x22, lsl #12  ; [pp+0x22078] Null
    //     0x6607b8: ldr             x3, [x3, #0x78]
    // 0x6607bc: blr             x9
    // 0x6607c0: ldur            x16, [fp, #-0x38]
    // 0x6607c4: ldur            lr, [fp, #-8]
    // 0x6607c8: stp             lr, x16, [SP, #-0x10]!
    // 0x6607cc: r0 = _paint()
    //     0x6607cc: bl              #0x660864  ; [package:flutter/src/material/material.dart] InkFeature::_paint
    // 0x6607d0: add             SP, SP, #0x10
    // 0x6607d4: ldur            x5, [fp, #-0x30]
    // 0x6607d8: ldr             x1, [fp, #0x20]
    // 0x6607dc: ldur            x2, [fp, #-0x28]
    // 0x6607e0: ldur            x3, [fp, #-0x20]
    // 0x6607e4: ldur            x4, [fp, #-0x18]
    // 0x6607e8: b               #0x6606d0
    // 0x6607ec: ldr             x16, [fp, #0x20]
    // 0x6607f0: ldr             lr, [fp, #0x18]
    // 0x6607f4: stp             lr, x16, [SP, #-0x10]!
    // 0x6607f8: ldr             x16, [fp, #0x10]
    // 0x6607fc: SaveReg r16
    //     0x6607fc: str             x16, [SP, #-8]!
    // 0x660800: r0 = paint()
    //     0x660800: bl              #0x669ddc  ; [package:flutter/src/widgets/layout_builder.dart] _RenderLayoutBuilder::paint
    // 0x660804: add             SP, SP, #0x18
    // 0x660808: r0 = Null
    //     0x660808: mov             x0, NULL
    // 0x66080c: LeaveFrame
    //     0x66080c: mov             SP, fp
    //     0x660810: ldp             fp, lr, [SP], #0x10
    // 0x660814: ret
    //     0x660814: ret             
    // 0x660818: ldur            x0, [fp, #-0x28]
    // 0x66081c: r0 = ConcurrentModificationError()
    //     0x66081c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x660820: ldur            x3, [fp, #-0x28]
    // 0x660824: StoreField: r0->field_b = r3
    //     0x660824: stur            w3, [x0, #0xb]
    // 0x660828: r0 = Throw()
    //     0x660828: bl              #0xd67e38  ; ThrowStub
    // 0x66082c: brk             #0
    // 0x660830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660834: b               #0x6605d4
    // 0x660838: stp             q0, q1, [SP, #-0x20]!
    // 0x66083c: SaveReg r0
    //     0x66083c: str             x0, [SP, #-8]!
    // 0x660840: r0 = AllocateDouble()
    //     0x660840: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x660844: mov             x1, x0
    // 0x660848: RestoreReg r0
    //     0x660848: ldr             x0, [SP], #8
    // 0x66084c: ldp             q0, q1, [SP], #0x20
    // 0x660850: b               #0x660648
    // 0x660854: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660854: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x660858: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660858: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66085c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66085c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660860: b               #0x6606e0
  }
  _ _removeFeature(/* No info */) {
    // ** addr: 0x795b84, size: 0x64
    // 0x795b84: EnterFrame
    //     0x795b84: stp             fp, lr, [SP, #-0x10]!
    //     0x795b88: mov             fp, SP
    // 0x795b8c: CheckStackOverflow
    //     0x795b8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795b90: cmp             SP, x16
    //     0x795b94: b.ls            #0x795bdc
    // 0x795b98: ldr             x0, [fp, #0x18]
    // 0x795b9c: LoadField: r1 = r0->field_6f
    //     0x795b9c: ldur            w1, [x0, #0x6f]
    // 0x795ba0: DecompressPointer r1
    //     0x795ba0: add             x1, x1, HEAP, lsl #32
    // 0x795ba4: cmp             w1, NULL
    // 0x795ba8: b.eq            #0x795be4
    // 0x795bac: ldr             x16, [fp, #0x10]
    // 0x795bb0: stp             x16, x1, [SP, #-0x10]!
    // 0x795bb4: r0 = remove()
    //     0x795bb4: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0x795bb8: add             SP, SP, #0x10
    // 0x795bbc: ldr             x16, [fp, #0x18]
    // 0x795bc0: SaveReg r16
    //     0x795bc0: str             x16, [SP, #-8]!
    // 0x795bc4: r0 = markNeedsPaint()
    //     0x795bc4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x795bc8: add             SP, SP, #8
    // 0x795bcc: r0 = Null
    //     0x795bcc: mov             x0, NULL
    // 0x795bd0: LeaveFrame
    //     0x795bd0: mov             SP, fp
    //     0x795bd4: ldp             fp, lr, [SP], #0x10
    // 0x795bd8: ret
    //     0x795bd8: ret             
    // 0x795bdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795bdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795be0: b               #0x795b98
    // 0x795be4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x795be4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ addInkFeature(/* No info */) {
    // ** addr: 0x7b266c, size: 0x12c
    // 0x7b266c: EnterFrame
    //     0x7b266c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2670: mov             fp, SP
    // 0x7b2674: AllocStack(0x10)
    //     0x7b2674: sub             SP, SP, #0x10
    // 0x7b2678: CheckStackOverflow
    //     0x7b2678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b267c: cmp             SP, x16
    //     0x7b2680: b.ls            #0x7b278c
    // 0x7b2684: ldr             x0, [fp, #0x18]
    // 0x7b2688: LoadField: r1 = r0->field_6f
    //     0x7b2688: ldur            w1, [x0, #0x6f]
    // 0x7b268c: DecompressPointer r1
    //     0x7b268c: add             x1, x1, HEAP, lsl #32
    // 0x7b2690: cmp             w1, NULL
    // 0x7b2694: b.ne            #0x7b26d8
    // 0x7b2698: r16 = <InkFeature>
    //     0x7b2698: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2b8] TypeArguments: <InkFeature>
    //     0x7b269c: ldr             x16, [x16, #0x2b8]
    // 0x7b26a0: stp             xzr, x16, [SP, #-0x10]!
    // 0x7b26a4: r0 = _GrowableList()
    //     0x7b26a4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7b26a8: add             SP, SP, #0x10
    // 0x7b26ac: mov             x1, x0
    // 0x7b26b0: ldr             x2, [fp, #0x18]
    // 0x7b26b4: StoreField: r2->field_6f = r0
    //     0x7b26b4: stur            w0, [x2, #0x6f]
    //     0x7b26b8: ldurb           w16, [x2, #-1]
    //     0x7b26bc: ldurb           w17, [x0, #-1]
    //     0x7b26c0: and             x16, x17, x16, lsr #2
    //     0x7b26c4: tst             x16, HEAP, lsr #32
    //     0x7b26c8: b.eq            #0x7b26d0
    //     0x7b26cc: bl              #0xd6828c
    // 0x7b26d0: mov             x0, x1
    // 0x7b26d4: b               #0x7b26e0
    // 0x7b26d8: mov             x2, x0
    // 0x7b26dc: mov             x0, x1
    // 0x7b26e0: stur            x0, [fp, #-0x10]
    // 0x7b26e4: LoadField: r1 = r0->field_b
    //     0x7b26e4: ldur            w1, [x0, #0xb]
    // 0x7b26e8: DecompressPointer r1
    //     0x7b26e8: add             x1, x1, HEAP, lsl #32
    // 0x7b26ec: stur            x1, [fp, #-8]
    // 0x7b26f0: LoadField: r3 = r0->field_f
    //     0x7b26f0: ldur            w3, [x0, #0xf]
    // 0x7b26f4: DecompressPointer r3
    //     0x7b26f4: add             x3, x3, HEAP, lsl #32
    // 0x7b26f8: LoadField: r4 = r3->field_b
    //     0x7b26f8: ldur            w4, [x3, #0xb]
    // 0x7b26fc: DecompressPointer r4
    //     0x7b26fc: add             x4, x4, HEAP, lsl #32
    // 0x7b2700: cmp             w1, w4
    // 0x7b2704: b.ne            #0x7b2714
    // 0x7b2708: SaveReg r0
    //     0x7b2708: str             x0, [SP, #-8]!
    // 0x7b270c: r0 = _growToNextCapacity()
    //     0x7b270c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7b2710: add             SP, SP, #8
    // 0x7b2714: ldur            x0, [fp, #-8]
    // 0x7b2718: ldur            x2, [fp, #-0x10]
    // 0x7b271c: r3 = LoadInt32Instr(r0)
    //     0x7b271c: sbfx            x3, x0, #1, #0x1f
    // 0x7b2720: add             x0, x3, #1
    // 0x7b2724: lsl             x1, x0, #1
    // 0x7b2728: StoreField: r2->field_b = r1
    //     0x7b2728: stur            w1, [x2, #0xb]
    // 0x7b272c: mov             x1, x3
    // 0x7b2730: cmp             x1, x0
    // 0x7b2734: b.hs            #0x7b2794
    // 0x7b2738: LoadField: r1 = r2->field_f
    //     0x7b2738: ldur            w1, [x2, #0xf]
    // 0x7b273c: DecompressPointer r1
    //     0x7b273c: add             x1, x1, HEAP, lsl #32
    // 0x7b2740: ldr             x0, [fp, #0x10]
    // 0x7b2744: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7b2744: add             x25, x1, x3, lsl #2
    //     0x7b2748: add             x25, x25, #0xf
    //     0x7b274c: str             w0, [x25]
    //     0x7b2750: tbz             w0, #0, #0x7b276c
    //     0x7b2754: ldurb           w16, [x1, #-1]
    //     0x7b2758: ldurb           w17, [x0, #-1]
    //     0x7b275c: and             x16, x17, x16, lsr #2
    //     0x7b2760: tst             x16, HEAP, lsr #32
    //     0x7b2764: b.eq            #0x7b276c
    //     0x7b2768: bl              #0xd67e5c
    // 0x7b276c: ldr             x16, [fp, #0x18]
    // 0x7b2770: SaveReg r16
    //     0x7b2770: str             x16, [SP, #-8]!
    // 0x7b2774: r0 = markNeedsPaint()
    //     0x7b2774: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x7b2778: add             SP, SP, #8
    // 0x7b277c: r0 = Null
    //     0x7b277c: mov             x0, NULL
    // 0x7b2780: LeaveFrame
    //     0x7b2780: mov             SP, fp
    //     0x7b2784: ldp             fp, lr, [SP], #0x10
    // 0x7b2788: ret
    //     0x7b2788: ret             
    // 0x7b278c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b278c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2790: b               #0x7b2684
    // 0x7b2794: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7b2794: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ _didChangeLayout(/* No info */) {
    // ** addr: 0x860c04, size: 0x58
    // 0x860c04: EnterFrame
    //     0x860c04: stp             fp, lr, [SP, #-0x10]!
    //     0x860c08: mov             fp, SP
    // 0x860c0c: CheckStackOverflow
    //     0x860c0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860c10: cmp             SP, x16
    //     0x860c14: b.ls            #0x860c54
    // 0x860c18: ldr             x0, [fp, #0x10]
    // 0x860c1c: LoadField: r1 = r0->field_6f
    //     0x860c1c: ldur            w1, [x0, #0x6f]
    // 0x860c20: DecompressPointer r1
    //     0x860c20: add             x1, x1, HEAP, lsl #32
    // 0x860c24: cmp             w1, NULL
    // 0x860c28: b.eq            #0x860c44
    // 0x860c2c: LoadField: r2 = r1->field_b
    //     0x860c2c: ldur            w2, [x1, #0xb]
    // 0x860c30: DecompressPointer r2
    //     0x860c30: add             x2, x2, HEAP, lsl #32
    // 0x860c34: cbz             w2, #0x860c44
    // 0x860c38: SaveReg r0
    //     0x860c38: str             x0, [SP, #-8]!
    // 0x860c3c: r0 = markNeedsPaint()
    //     0x860c3c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x860c40: add             SP, SP, #8
    // 0x860c44: r0 = Null
    //     0x860c44: mov             x0, NULL
    // 0x860c48: LeaveFrame
    //     0x860c48: mov             SP, fp
    //     0x860c4c: ldp             fp, lr, [SP], #0x10
    // 0x860c50: ret
    //     0x860c50: ret             
    // 0x860c54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860c54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x860c58: b               #0x860c18
  }
}

// class id: 3310, size: 0x34, field offset: 0x24
class _MaterialInteriorState extends AnimatedWidgetBaseState<_MaterialInterior> {

  _ build(/* No info */) {
    // ** addr: 0x860c5c, size: 0x2e8
    // 0x860c5c: EnterFrame
    //     0x860c5c: stp             fp, lr, [SP, #-0x10]!
    //     0x860c60: mov             fp, SP
    // 0x860c64: AllocStack(0x40)
    //     0x860c64: sub             SP, SP, #0x40
    // 0x860c68: CheckStackOverflow
    //     0x860c68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860c6c: cmp             SP, x16
    //     0x860c70: b.ls            #0x860f20
    // 0x860c74: ldr             x0, [fp, #0x18]
    // 0x860c78: LoadField: r2 = r0->field_2f
    //     0x860c78: ldur            w2, [x0, #0x2f]
    // 0x860c7c: DecompressPointer r2
    //     0x860c7c: add             x2, x2, HEAP, lsl #32
    // 0x860c80: stur            x2, [fp, #-8]
    // 0x860c84: cmp             w2, NULL
    // 0x860c88: b.eq            #0x860f28
    // 0x860c8c: mov             x1, x0
    // 0x860c90: LoadField: r0 = r1->field_1f
    //     0x860c90: ldur            w0, [x1, #0x1f]
    // 0x860c94: DecompressPointer r0
    //     0x860c94: add             x0, x0, HEAP, lsl #32
    // 0x860c98: r16 = Sentinel
    //     0x860c98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x860c9c: cmp             w0, w16
    // 0x860ca0: b.ne            #0x860cb0
    // 0x860ca4: r2 = _animation
    //     0x860ca4: add             x2, PP, #0x21, lsl #12  ; [pp+0x21838] Field <ImplicitlyAnimatedWidgetState._animation@988443363>: late (offset: 0x20)
    //     0x860ca8: ldr             x2, [x2, #0x838]
    // 0x860cac: r0 = InitLateInstanceField()
    //     0x860cac: bl              #0xd67c38  ; InitLateInstanceFieldStub
    // 0x860cb0: ldur            x16, [fp, #-8]
    // 0x860cb4: stp             x0, x16, [SP, #-0x10]!
    // 0x860cb8: r0 = evaluate()
    //     0x860cb8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x860cbc: add             SP, SP, #0x10
    // 0x860cc0: stur            x0, [fp, #-8]
    // 0x860cc4: cmp             w0, NULL
    // 0x860cc8: b.eq            #0x860f2c
    // 0x860ccc: ldr             x1, [fp, #0x18]
    // 0x860cd0: LoadField: r2 = r1->field_23
    //     0x860cd0: ldur            w2, [x1, #0x23]
    // 0x860cd4: DecompressPointer r2
    //     0x860cd4: add             x2, x2, HEAP, lsl #32
    // 0x860cd8: cmp             w2, NULL
    // 0x860cdc: b.eq            #0x860f30
    // 0x860ce0: LoadField: r3 = r1->field_1f
    //     0x860ce0: ldur            w3, [x1, #0x1f]
    // 0x860ce4: DecompressPointer r3
    //     0x860ce4: add             x3, x3, HEAP, lsl #32
    // 0x860ce8: stp             x3, x2, [SP, #-0x10]!
    // 0x860cec: r0 = evaluate()
    //     0x860cec: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x860cf0: add             SP, SP, #0x10
    // 0x860cf4: stur            x0, [fp, #-0x10]
    // 0x860cf8: ldr             x16, [fp, #0x10]
    // 0x860cfc: SaveReg r16
    //     0x860cfc: str             x16, [SP, #-8]!
    // 0x860d00: r0 = of()
    //     0x860d00: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x860d04: add             SP, SP, #8
    // 0x860d08: LoadField: r1 = r0->field_2b
    //     0x860d08: ldur            w1, [x0, #0x2b]
    // 0x860d0c: DecompressPointer r1
    //     0x860d0c: add             x1, x1, HEAP, lsl #32
    // 0x860d10: tbnz            w1, #4, #0x860d88
    // 0x860d14: ldr             x0, [fp, #0x18]
    // 0x860d18: LoadField: r1 = r0->field_b
    //     0x860d18: ldur            w1, [x0, #0xb]
    // 0x860d1c: DecompressPointer r1
    //     0x860d1c: add             x1, x1, HEAP, lsl #32
    // 0x860d20: cmp             w1, NULL
    // 0x860d24: b.eq            #0x860f34
    // 0x860d28: LoadField: r2 = r1->field_2f
    //     0x860d28: ldur            w2, [x1, #0x2f]
    // 0x860d2c: DecompressPointer r2
    //     0x860d2c: add             x2, x2, HEAP, lsl #32
    // 0x860d30: stur            x2, [fp, #-0x18]
    // 0x860d34: LoadField: r1 = r0->field_27
    //     0x860d34: ldur            w1, [x0, #0x27]
    // 0x860d38: DecompressPointer r1
    //     0x860d38: add             x1, x1, HEAP, lsl #32
    // 0x860d3c: cmp             w1, NULL
    // 0x860d40: b.ne            #0x860d4c
    // 0x860d44: r1 = Null
    //     0x860d44: mov             x1, NULL
    // 0x860d48: b               #0x860d64
    // 0x860d4c: LoadField: r3 = r0->field_1f
    //     0x860d4c: ldur            w3, [x0, #0x1f]
    // 0x860d50: DecompressPointer r3
    //     0x860d50: add             x3, x3, HEAP, lsl #32
    // 0x860d54: stp             x3, x1, [SP, #-0x10]!
    // 0x860d58: r0 = evaluate()
    //     0x860d58: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x860d5c: add             SP, SP, #0x10
    // 0x860d60: mov             x1, x0
    // 0x860d64: ldur            x0, [fp, #-0x10]
    // 0x860d68: LoadField: d0 = r0->field_7
    //     0x860d68: ldur            d0, [x0, #7]
    // 0x860d6c: ldur            x16, [fp, #-0x18]
    // 0x860d70: stp             x1, x16, [SP, #-0x10]!
    // 0x860d74: SaveReg d0
    //     0x860d74: str             d0, [SP, #-8]!
    // 0x860d78: r0 = applySurfaceTint()
    //     0x860d78: bl              #0x860850  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applySurfaceTint
    // 0x860d7c: add             SP, SP, #0x18
    // 0x860d80: mov             x1, x0
    // 0x860d84: b               #0x860dc4
    // 0x860d88: ldr             x1, [fp, #0x18]
    // 0x860d8c: ldur            x0, [fp, #-0x10]
    // 0x860d90: LoadField: r2 = r1->field_b
    //     0x860d90: ldur            w2, [x1, #0xb]
    // 0x860d94: DecompressPointer r2
    //     0x860d94: add             x2, x2, HEAP, lsl #32
    // 0x860d98: cmp             w2, NULL
    // 0x860d9c: b.eq            #0x860f38
    // 0x860da0: LoadField: r3 = r2->field_2f
    //     0x860da0: ldur            w3, [x2, #0x2f]
    // 0x860da4: DecompressPointer r3
    //     0x860da4: add             x3, x3, HEAP, lsl #32
    // 0x860da8: LoadField: d0 = r0->field_7
    //     0x860da8: ldur            d0, [x0, #7]
    // 0x860dac: ldr             x16, [fp, #0x10]
    // 0x860db0: stp             x3, x16, [SP, #-0x10]!
    // 0x860db4: SaveReg d0
    //     0x860db4: str             d0, [SP, #-8]!
    // 0x860db8: r0 = applyOverlay()
    //     0x860db8: bl              #0x860624  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applyOverlay
    // 0x860dbc: add             SP, SP, #0x18
    // 0x860dc0: mov             x1, x0
    // 0x860dc4: ldr             x0, [fp, #0x18]
    // 0x860dc8: stur            x1, [fp, #-0x18]
    // 0x860dcc: LoadField: r2 = r0->field_b
    //     0x860dcc: ldur            w2, [x0, #0xb]
    // 0x860dd0: DecompressPointer r2
    //     0x860dd0: add             x2, x2, HEAP, lsl #32
    // 0x860dd4: cmp             w2, NULL
    // 0x860dd8: b.eq            #0x860f3c
    // 0x860ddc: LoadField: r3 = r2->field_33
    //     0x860ddc: ldur            w3, [x2, #0x33]
    // 0x860de0: DecompressPointer r3
    //     0x860de0: add             x3, x3, HEAP, lsl #32
    // 0x860de4: cmp             w3, NULL
    // 0x860de8: b.eq            #0x860df8
    // 0x860dec: ldur            x2, [fp, #-0x10]
    // 0x860df0: LoadField: d0 = r2->field_7
    //     0x860df0: ldur            d0, [x2, #7]
    // 0x860df4: b               #0x860dfc
    // 0x860df8: d0 = 0.000000
    //     0x860df8: eor             v0.16b, v0.16b, v0.16b
    // 0x860dfc: stur            d0, [fp, #-0x40]
    // 0x860e00: LoadField: r2 = r0->field_2b
    //     0x860e00: ldur            w2, [x0, #0x2b]
    // 0x860e04: DecompressPointer r2
    //     0x860e04: add             x2, x2, HEAP, lsl #32
    // 0x860e08: cmp             w2, NULL
    // 0x860e0c: b.ne            #0x860e18
    // 0x860e10: r0 = Null
    //     0x860e10: mov             x0, NULL
    // 0x860e14: b               #0x860e2c
    // 0x860e18: LoadField: r3 = r0->field_1f
    //     0x860e18: ldur            w3, [x0, #0x1f]
    // 0x860e1c: DecompressPointer r3
    //     0x860e1c: add             x3, x3, HEAP, lsl #32
    // 0x860e20: stp             x3, x2, [SP, #-0x10]!
    // 0x860e24: r0 = evaluate()
    //     0x860e24: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x860e28: add             SP, SP, #0x10
    // 0x860e2c: cmp             w0, NULL
    // 0x860e30: b.ne            #0x860e40
    // 0x860e34: r3 = Instance_Color
    //     0x860e34: add             x3, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x860e38: ldr             x3, [x3, #0xc08]
    // 0x860e3c: b               #0x860e44
    // 0x860e40: mov             x3, x0
    // 0x860e44: ldr             x0, [fp, #0x18]
    // 0x860e48: ldur            x2, [fp, #-8]
    // 0x860e4c: ldur            x1, [fp, #-0x18]
    // 0x860e50: ldur            d0, [fp, #-0x40]
    // 0x860e54: stur            x3, [fp, #-0x10]
    // 0x860e58: ldr             x16, [fp, #0x10]
    // 0x860e5c: SaveReg r16
    //     0x860e5c: str             x16, [SP, #-8]!
    // 0x860e60: r0 = maybeOf()
    //     0x860e60: bl              #0x6c2c58  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x860e64: add             SP, SP, #8
    // 0x860e68: r1 = <Path>
    //     0x860e68: add             x1, PP, #0x15, lsl #12  ; [pp+0x152e8] TypeArguments: <Path>
    //     0x860e6c: ldr             x1, [x1, #0x2e8]
    // 0x860e70: stur            x0, [fp, #-0x20]
    // 0x860e74: r0 = ShapeBorderClipper()
    //     0x860e74: bl              #0x8603d4  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x860e78: mov             x1, x0
    // 0x860e7c: ldur            x0, [fp, #-8]
    // 0x860e80: stur            x1, [fp, #-0x30]
    // 0x860e84: StoreField: r1->field_f = r0
    //     0x860e84: stur            w0, [x1, #0xf]
    // 0x860e88: ldur            x2, [fp, #-0x20]
    // 0x860e8c: StoreField: r1->field_13 = r2
    //     0x860e8c: stur            w2, [x1, #0x13]
    // 0x860e90: ldr             x2, [fp, #0x18]
    // 0x860e94: LoadField: r3 = r2->field_b
    //     0x860e94: ldur            w3, [x2, #0xb]
    // 0x860e98: DecompressPointer r3
    //     0x860e98: add             x3, x3, HEAP, lsl #32
    // 0x860e9c: cmp             w3, NULL
    // 0x860ea0: b.eq            #0x860f40
    // 0x860ea4: LoadField: r2 = r3->field_23
    //     0x860ea4: ldur            w2, [x3, #0x23]
    // 0x860ea8: DecompressPointer r2
    //     0x860ea8: add             x2, x2, HEAP, lsl #32
    // 0x860eac: stur            x2, [fp, #-0x28]
    // 0x860eb0: LoadField: r4 = r3->field_17
    //     0x860eb0: ldur            w4, [x3, #0x17]
    // 0x860eb4: DecompressPointer r4
    //     0x860eb4: add             x4, x4, HEAP, lsl #32
    // 0x860eb8: stur            x4, [fp, #-0x20]
    // 0x860ebc: r0 = _ShapeBorderPaint()
    //     0x860ebc: bl              #0x860478  ; Allocate_ShapeBorderPaintStub -> _ShapeBorderPaint (size=0x18)
    // 0x860ec0: mov             x1, x0
    // 0x860ec4: ldur            x0, [fp, #-0x20]
    // 0x860ec8: stur            x1, [fp, #-0x38]
    // 0x860ecc: StoreField: r1->field_b = r0
    //     0x860ecc: stur            w0, [x1, #0xb]
    // 0x860ed0: ldur            x0, [fp, #-8]
    // 0x860ed4: StoreField: r1->field_f = r0
    //     0x860ed4: stur            w0, [x1, #0xf]
    // 0x860ed8: r0 = true
    //     0x860ed8: add             x0, NULL, #0x20  ; true
    // 0x860edc: StoreField: r1->field_13 = r0
    //     0x860edc: stur            w0, [x1, #0x13]
    // 0x860ee0: r0 = PhysicalShape()
    //     0x860ee0: bl              #0x860f44  ; AllocatePhysicalShapeStub -> PhysicalShape (size=0x28)
    // 0x860ee4: ldur            x1, [fp, #-0x30]
    // 0x860ee8: StoreField: r0->field_f = r1
    //     0x860ee8: stur            w1, [x0, #0xf]
    // 0x860eec: ldur            x1, [fp, #-0x28]
    // 0x860ef0: StoreField: r0->field_13 = r1
    //     0x860ef0: stur            w1, [x0, #0x13]
    // 0x860ef4: ldur            d0, [fp, #-0x40]
    // 0x860ef8: StoreField: r0->field_17 = d0
    //     0x860ef8: stur            d0, [x0, #0x17]
    // 0x860efc: ldur            x1, [fp, #-0x18]
    // 0x860f00: StoreField: r0->field_1f = r1
    //     0x860f00: stur            w1, [x0, #0x1f]
    // 0x860f04: ldur            x1, [fp, #-0x10]
    // 0x860f08: StoreField: r0->field_23 = r1
    //     0x860f08: stur            w1, [x0, #0x23]
    // 0x860f0c: ldur            x1, [fp, #-0x38]
    // 0x860f10: StoreField: r0->field_b = r1
    //     0x860f10: stur            w1, [x0, #0xb]
    // 0x860f14: LeaveFrame
    //     0x860f14: mov             SP, fp
    //     0x860f18: ldp             fp, lr, [SP], #0x10
    // 0x860f1c: ret
    //     0x860f1c: ret             
    // 0x860f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860f20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x860f24: b               #0x860c74
    // 0x860f28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860f2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860f30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860f34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860f3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860f40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860f40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ forEachTween(/* No info */) {
    // ** addr: 0xbe6eac, size: 0x398
    // 0xbe6eac: EnterFrame
    //     0xbe6eac: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6eb0: mov             fp, SP
    // 0xbe6eb4: AllocStack(0x10)
    //     0xbe6eb4: sub             SP, SP, #0x10
    // 0xbe6eb8: CheckStackOverflow
    //     0xbe6eb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe6ebc: cmp             SP, x16
    //     0xbe6ec0: b.ls            #0xbe7210
    // 0xbe6ec4: ldr             x0, [fp, #0x18]
    // 0xbe6ec8: LoadField: r3 = r0->field_23
    //     0xbe6ec8: ldur            w3, [x0, #0x23]
    // 0xbe6ecc: DecompressPointer r3
    //     0xbe6ecc: add             x3, x3, HEAP, lsl #32
    // 0xbe6ed0: stur            x3, [fp, #-0x10]
    // 0xbe6ed4: LoadField: r1 = r0->field_b
    //     0xbe6ed4: ldur            w1, [x0, #0xb]
    // 0xbe6ed8: DecompressPointer r1
    //     0xbe6ed8: add             x1, x1, HEAP, lsl #32
    // 0xbe6edc: cmp             w1, NULL
    // 0xbe6ee0: b.eq            #0xbe7218
    // 0xbe6ee4: LoadField: d0 = r1->field_27
    //     0xbe6ee4: ldur            d0, [x1, #0x27]
    // 0xbe6ee8: r4 = inline_Allocate_Double()
    //     0xbe6ee8: ldp             x4, x1, [THR, #0x60]  ; THR::top
    //     0xbe6eec: add             x4, x4, #0x10
    //     0xbe6ef0: cmp             x1, x4
    //     0xbe6ef4: b.ls            #0xbe721c
    //     0xbe6ef8: str             x4, [THR, #0x60]  ; THR::top
    //     0xbe6efc: sub             x4, x4, #0xf
    //     0xbe6f00: mov             x1, #0xd108
    //     0xbe6f04: movk            x1, #3, lsl #16
    //     0xbe6f08: stur            x1, [x4, #-1]
    // 0xbe6f0c: StoreField: r4->field_7 = d0
    //     0xbe6f0c: stur            d0, [x4, #7]
    // 0xbe6f10: stur            x4, [fp, #-8]
    // 0xbe6f14: r1 = Function '<anonymous closure>':.
    //     0xbe6f14: add             x1, PP, #0x28, lsl #12  ; [pp+0x289c8] AnonymousClosure: (0xbe7378), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0xbe6eac)
    //     0xbe6f18: ldr             x1, [x1, #0x9c8]
    // 0xbe6f1c: r2 = Null
    //     0xbe6f1c: mov             x2, NULL
    // 0xbe6f20: r0 = AllocateClosure()
    //     0xbe6f20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbe6f24: ldr             x16, [fp, #0x10]
    // 0xbe6f28: ldur            lr, [fp, #-0x10]
    // 0xbe6f2c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe6f30: ldur            x16, [fp, #-8]
    // 0xbe6f34: stp             x0, x16, [SP, #-0x10]!
    // 0xbe6f38: ldr             x0, [fp, #0x10]
    // 0xbe6f3c: ClosureCall
    //     0xbe6f3c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xbe6f40: ldur            x2, [x0, #0x1f]
    //     0xbe6f44: blr             x2
    // 0xbe6f48: add             SP, SP, #0x20
    // 0xbe6f4c: mov             x3, x0
    // 0xbe6f50: r2 = Null
    //     0xbe6f50: mov             x2, NULL
    // 0xbe6f54: r1 = Null
    //     0xbe6f54: mov             x1, NULL
    // 0xbe6f58: stur            x3, [fp, #-8]
    // 0xbe6f5c: r8 = Tween<double>?
    //     0xbe6f5c: add             x8, PP, #0x28, lsl #12  ; [pp+0x28338] Type: Tween<double>?
    //     0xbe6f60: ldr             x8, [x8, #0x338]
    // 0xbe6f64: r3 = Null
    //     0xbe6f64: add             x3, PP, #0x28, lsl #12  ; [pp+0x289d0] Null
    //     0xbe6f68: ldr             x3, [x3, #0x9d0]
    // 0xbe6f6c: r0 = Tween<double>?()
    //     0xbe6f6c: bl              #0xbe73d0  ; IsType_Tween<double>?_Stub
    // 0xbe6f70: ldur            x0, [fp, #-8]
    // 0xbe6f74: ldr             x3, [fp, #0x18]
    // 0xbe6f78: StoreField: r3->field_23 = r0
    //     0xbe6f78: stur            w0, [x3, #0x23]
    //     0xbe6f7c: ldurb           w16, [x3, #-1]
    //     0xbe6f80: ldurb           w17, [x0, #-1]
    //     0xbe6f84: and             x16, x17, x16, lsr #2
    //     0xbe6f88: tst             x16, HEAP, lsr #32
    //     0xbe6f8c: b.eq            #0xbe6f94
    //     0xbe6f90: bl              #0xd682ac
    // 0xbe6f94: LoadField: r0 = r3->field_b
    //     0xbe6f94: ldur            w0, [x3, #0xb]
    // 0xbe6f98: DecompressPointer r0
    //     0xbe6f98: add             x0, x0, HEAP, lsl #32
    // 0xbe6f9c: cmp             w0, NULL
    // 0xbe6fa0: b.eq            #0xbe7238
    // 0xbe6fa4: LoadField: r4 = r0->field_33
    //     0xbe6fa4: ldur            w4, [x0, #0x33]
    // 0xbe6fa8: DecompressPointer r4
    //     0xbe6fa8: add             x4, x4, HEAP, lsl #32
    // 0xbe6fac: stur            x4, [fp, #-0x10]
    // 0xbe6fb0: cmp             w4, NULL
    // 0xbe6fb4: b.eq            #0xbe7044
    // 0xbe6fb8: LoadField: r0 = r3->field_2b
    //     0xbe6fb8: ldur            w0, [x3, #0x2b]
    // 0xbe6fbc: DecompressPointer r0
    //     0xbe6fbc: add             x0, x0, HEAP, lsl #32
    // 0xbe6fc0: stur            x0, [fp, #-8]
    // 0xbe6fc4: r1 = Function '<anonymous closure>':.
    //     0xbe6fc4: add             x1, PP, #0x28, lsl #12  ; [pp+0x289e0] AnonymousClosure: (0xbe7310), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0xbe6eac)
    //     0xbe6fc8: ldr             x1, [x1, #0x9e0]
    // 0xbe6fcc: r2 = Null
    //     0xbe6fcc: mov             x2, NULL
    // 0xbe6fd0: r0 = AllocateClosure()
    //     0xbe6fd0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbe6fd4: ldr             x16, [fp, #0x10]
    // 0xbe6fd8: ldur            lr, [fp, #-8]
    // 0xbe6fdc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe6fe0: ldur            x16, [fp, #-0x10]
    // 0xbe6fe4: stp             x0, x16, [SP, #-0x10]!
    // 0xbe6fe8: ldr             x0, [fp, #0x10]
    // 0xbe6fec: ClosureCall
    //     0xbe6fec: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xbe6ff0: ldur            x2, [x0, #0x1f]
    //     0xbe6ff4: blr             x2
    // 0xbe6ff8: add             SP, SP, #0x20
    // 0xbe6ffc: mov             x3, x0
    // 0xbe7000: r2 = Null
    //     0xbe7000: mov             x2, NULL
    // 0xbe7004: r1 = Null
    //     0xbe7004: mov             x1, NULL
    // 0xbe7008: stur            x3, [fp, #-8]
    // 0xbe700c: r4 = 59
    //     0xbe700c: mov             x4, #0x3b
    // 0xbe7010: branchIfSmi(r0, 0xbe701c)
    //     0xbe7010: tbz             w0, #0, #0xbe701c
    // 0xbe7014: r4 = LoadClassIdInstr(r0)
    //     0xbe7014: ldur            x4, [x0, #-1]
    //     0xbe7018: ubfx            x4, x4, #0xc, #0x14
    // 0xbe701c: r17 = 4275
    //     0xbe701c: mov             x17, #0x10b3
    // 0xbe7020: cmp             x4, x17
    // 0xbe7024: b.eq            #0xbe703c
    // 0xbe7028: r8 = ColorTween<Color?>?
    //     0xbe7028: add             x8, PP, #0x28, lsl #12  ; [pp+0x28358] Type: ColorTween<Color?>?
    //     0xbe702c: ldr             x8, [x8, #0x358]
    // 0xbe7030: r3 = Null
    //     0xbe7030: add             x3, PP, #0x28, lsl #12  ; [pp+0x289e8] Null
    //     0xbe7034: ldr             x3, [x3, #0x9e8]
    // 0xbe7038: r0 = DefaultNullableTypeTest()
    //     0xbe7038: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xbe703c: ldur            x0, [fp, #-8]
    // 0xbe7040: b               #0xbe7048
    // 0xbe7044: r0 = Null
    //     0xbe7044: mov             x0, NULL
    // 0xbe7048: ldr             x3, [fp, #0x18]
    // 0xbe704c: StoreField: r3->field_2b = r0
    //     0xbe704c: stur            w0, [x3, #0x2b]
    //     0xbe7050: ldurb           w16, [x3, #-1]
    //     0xbe7054: ldurb           w17, [x0, #-1]
    //     0xbe7058: and             x16, x17, x16, lsr #2
    //     0xbe705c: tst             x16, HEAP, lsr #32
    //     0xbe7060: b.eq            #0xbe7068
    //     0xbe7064: bl              #0xd682ac
    // 0xbe7068: LoadField: r0 = r3->field_b
    //     0xbe7068: ldur            w0, [x3, #0xb]
    // 0xbe706c: DecompressPointer r0
    //     0xbe706c: add             x0, x0, HEAP, lsl #32
    // 0xbe7070: cmp             w0, NULL
    // 0xbe7074: b.eq            #0xbe723c
    // 0xbe7078: LoadField: r4 = r0->field_37
    //     0xbe7078: ldur            w4, [x0, #0x37]
    // 0xbe707c: DecompressPointer r4
    //     0xbe707c: add             x4, x4, HEAP, lsl #32
    // 0xbe7080: stur            x4, [fp, #-0x10]
    // 0xbe7084: cmp             w4, NULL
    // 0xbe7088: b.eq            #0xbe7118
    // 0xbe708c: LoadField: r0 = r3->field_27
    //     0xbe708c: ldur            w0, [x3, #0x27]
    // 0xbe7090: DecompressPointer r0
    //     0xbe7090: add             x0, x0, HEAP, lsl #32
    // 0xbe7094: stur            x0, [fp, #-8]
    // 0xbe7098: r1 = Function '<anonymous closure>':.
    //     0xbe7098: add             x1, PP, #0x28, lsl #12  ; [pp+0x289f8] AnonymousClosure: (0xbe72a8), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0xbe6eac)
    //     0xbe709c: ldr             x1, [x1, #0x9f8]
    // 0xbe70a0: r2 = Null
    //     0xbe70a0: mov             x2, NULL
    // 0xbe70a4: r0 = AllocateClosure()
    //     0xbe70a4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbe70a8: ldr             x16, [fp, #0x10]
    // 0xbe70ac: ldur            lr, [fp, #-8]
    // 0xbe70b0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe70b4: ldur            x16, [fp, #-0x10]
    // 0xbe70b8: stp             x0, x16, [SP, #-0x10]!
    // 0xbe70bc: ldr             x0, [fp, #0x10]
    // 0xbe70c0: ClosureCall
    //     0xbe70c0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xbe70c4: ldur            x2, [x0, #0x1f]
    //     0xbe70c8: blr             x2
    // 0xbe70cc: add             SP, SP, #0x20
    // 0xbe70d0: mov             x3, x0
    // 0xbe70d4: r2 = Null
    //     0xbe70d4: mov             x2, NULL
    // 0xbe70d8: r1 = Null
    //     0xbe70d8: mov             x1, NULL
    // 0xbe70dc: stur            x3, [fp, #-8]
    // 0xbe70e0: r4 = 59
    //     0xbe70e0: mov             x4, #0x3b
    // 0xbe70e4: branchIfSmi(r0, 0xbe70f0)
    //     0xbe70e4: tbz             w0, #0, #0xbe70f0
    // 0xbe70e8: r4 = LoadClassIdInstr(r0)
    //     0xbe70e8: ldur            x4, [x0, #-1]
    //     0xbe70ec: ubfx            x4, x4, #0xc, #0x14
    // 0xbe70f0: r17 = 4275
    //     0xbe70f0: mov             x17, #0x10b3
    // 0xbe70f4: cmp             x4, x17
    // 0xbe70f8: b.eq            #0xbe7110
    // 0xbe70fc: r8 = ColorTween<Color?>?
    //     0xbe70fc: add             x8, PP, #0x28, lsl #12  ; [pp+0x28358] Type: ColorTween<Color?>?
    //     0xbe7100: ldr             x8, [x8, #0x358]
    // 0xbe7104: r3 = Null
    //     0xbe7104: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a00] Null
    //     0xbe7108: ldr             x3, [x3, #0xa00]
    // 0xbe710c: r0 = DefaultNullableTypeTest()
    //     0xbe710c: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xbe7110: ldur            x0, [fp, #-8]
    // 0xbe7114: b               #0xbe711c
    // 0xbe7118: r0 = Null
    //     0xbe7118: mov             x0, NULL
    // 0xbe711c: ldr             x3, [fp, #0x18]
    // 0xbe7120: StoreField: r3->field_27 = r0
    //     0xbe7120: stur            w0, [x3, #0x27]
    //     0xbe7124: ldurb           w16, [x3, #-1]
    //     0xbe7128: ldurb           w17, [x0, #-1]
    //     0xbe712c: and             x16, x17, x16, lsr #2
    //     0xbe7130: tst             x16, HEAP, lsr #32
    //     0xbe7134: b.eq            #0xbe713c
    //     0xbe7138: bl              #0xd682ac
    // 0xbe713c: LoadField: r0 = r3->field_2f
    //     0xbe713c: ldur            w0, [x3, #0x2f]
    // 0xbe7140: DecompressPointer r0
    //     0xbe7140: add             x0, x0, HEAP, lsl #32
    // 0xbe7144: stur            x0, [fp, #-0x10]
    // 0xbe7148: LoadField: r1 = r3->field_b
    //     0xbe7148: ldur            w1, [x3, #0xb]
    // 0xbe714c: DecompressPointer r1
    //     0xbe714c: add             x1, x1, HEAP, lsl #32
    // 0xbe7150: cmp             w1, NULL
    // 0xbe7154: b.eq            #0xbe7240
    // 0xbe7158: LoadField: r4 = r1->field_1b
    //     0xbe7158: ldur            w4, [x1, #0x1b]
    // 0xbe715c: DecompressPointer r4
    //     0xbe715c: add             x4, x4, HEAP, lsl #32
    // 0xbe7160: stur            x4, [fp, #-8]
    // 0xbe7164: r1 = Function '<anonymous closure>':.
    //     0xbe7164: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a10] AnonymousClosure: (0xbe7244), in [package:flutter/src/material/material.dart] _MaterialInteriorState::forEachTween (0xbe6eac)
    //     0xbe7168: ldr             x1, [x1, #0xa10]
    // 0xbe716c: r2 = Null
    //     0xbe716c: mov             x2, NULL
    // 0xbe7170: r0 = AllocateClosure()
    //     0xbe7170: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xbe7174: ldr             x16, [fp, #0x10]
    // 0xbe7178: ldur            lr, [fp, #-0x10]
    // 0xbe717c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe7180: ldur            x16, [fp, #-8]
    // 0xbe7184: stp             x0, x16, [SP, #-0x10]!
    // 0xbe7188: ldr             x0, [fp, #0x10]
    // 0xbe718c: ClosureCall
    //     0xbe718c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0xbe7190: ldur            x2, [x0, #0x1f]
    //     0xbe7194: blr             x2
    // 0xbe7198: add             SP, SP, #0x20
    // 0xbe719c: mov             x3, x0
    // 0xbe71a0: r2 = Null
    //     0xbe71a0: mov             x2, NULL
    // 0xbe71a4: r1 = Null
    //     0xbe71a4: mov             x1, NULL
    // 0xbe71a8: stur            x3, [fp, #-8]
    // 0xbe71ac: r4 = 59
    //     0xbe71ac: mov             x4, #0x3b
    // 0xbe71b0: branchIfSmi(r0, 0xbe71bc)
    //     0xbe71b0: tbz             w0, #0, #0xbe71bc
    // 0xbe71b4: r4 = LoadClassIdInstr(r0)
    //     0xbe71b4: ldur            x4, [x0, #-1]
    //     0xbe71b8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe71bc: r17 = 4267
    //     0xbe71bc: mov             x17, #0x10ab
    // 0xbe71c0: cmp             x4, x17
    // 0xbe71c4: b.eq            #0xbe71dc
    // 0xbe71c8: r8 = ShapeBorderTween<ShapeBorder?>?
    //     0xbe71c8: add             x8, PP, #0x28, lsl #12  ; [pp+0x28a18] Type: ShapeBorderTween<ShapeBorder?>?
    //     0xbe71cc: ldr             x8, [x8, #0xa18]
    // 0xbe71d0: r3 = Null
    //     0xbe71d0: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a20] Null
    //     0xbe71d4: ldr             x3, [x3, #0xa20]
    // 0xbe71d8: r0 = DefaultNullableTypeTest()
    //     0xbe71d8: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xbe71dc: ldur            x0, [fp, #-8]
    // 0xbe71e0: ldr             x1, [fp, #0x18]
    // 0xbe71e4: StoreField: r1->field_2f = r0
    //     0xbe71e4: stur            w0, [x1, #0x2f]
    //     0xbe71e8: ldurb           w16, [x1, #-1]
    //     0xbe71ec: ldurb           w17, [x0, #-1]
    //     0xbe71f0: and             x16, x17, x16, lsr #2
    //     0xbe71f4: tst             x16, HEAP, lsr #32
    //     0xbe71f8: b.eq            #0xbe7200
    //     0xbe71fc: bl              #0xd6826c
    // 0xbe7200: r0 = Null
    //     0xbe7200: mov             x0, NULL
    // 0xbe7204: LeaveFrame
    //     0xbe7204: mov             SP, fp
    //     0xbe7208: ldp             fp, lr, [SP], #0x10
    // 0xbe720c: ret
    //     0xbe720c: ret             
    // 0xbe7210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe7210: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe7214: b               #0xbe6ec4
    // 0xbe7218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe7218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe721c: SaveReg d0
    //     0xbe721c: str             q0, [SP, #-0x10]!
    // 0xbe7220: stp             x0, x3, [SP, #-0x10]!
    // 0xbe7224: r0 = AllocateDouble()
    //     0xbe7224: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbe7228: mov             x4, x0
    // 0xbe722c: ldp             x0, x3, [SP], #0x10
    // 0xbe7230: RestoreReg d0
    //     0xbe7230: ldr             q0, [SP], #0x10
    // 0xbe7234: b               #0xbe6f0c
    // 0xbe7238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe7238: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe723c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe723c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe7240: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe7240: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] ShapeBorderTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xbe7244, size: 0x64
    // 0xbe7244: EnterFrame
    //     0xbe7244: stp             fp, lr, [SP, #-0x10]!
    //     0xbe7248: mov             fp, SP
    // 0xbe724c: ldr             x0, [fp, #0x10]
    // 0xbe7250: r2 = Null
    //     0xbe7250: mov             x2, NULL
    // 0xbe7254: r1 = Null
    //     0xbe7254: mov             x1, NULL
    // 0xbe7258: r4 = 59
    //     0xbe7258: mov             x4, #0x3b
    // 0xbe725c: branchIfSmi(r0, 0xbe7268)
    //     0xbe725c: tbz             w0, #0, #0xbe7268
    // 0xbe7260: r4 = LoadClassIdInstr(r0)
    //     0xbe7260: ldur            x4, [x0, #-1]
    //     0xbe7264: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7268: sub             x4, x4, #0x87d
    // 0xbe726c: cmp             x4, #0xf
    // 0xbe7270: b.ls            #0xbe7288
    // 0xbe7274: r8 = ShapeBorder
    //     0xbe7274: add             x8, PP, #0x28, lsl #12  ; [pp+0x288b0] Type: ShapeBorder
    //     0xbe7278: ldr             x8, [x8, #0x8b0]
    // 0xbe727c: r3 = Null
    //     0xbe727c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a30] Null
    //     0xbe7280: ldr             x3, [x3, #0xa30]
    // 0xbe7284: r0 = DefaultTypeTest()
    //     0xbe7284: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xbe7288: r1 = <ShapeBorder?>
    //     0xbe7288: add             x1, PP, #0x28, lsl #12  ; [pp+0x28a40] TypeArguments: <ShapeBorder?>
    //     0xbe728c: ldr             x1, [x1, #0xa40]
    // 0xbe7290: r0 = ShapeBorderTween()
    //     0xbe7290: bl              #0xa40608  ; AllocateShapeBorderTweenStub -> ShapeBorderTween (size=0x14)
    // 0xbe7294: ldr             x1, [fp, #0x10]
    // 0xbe7298: StoreField: r0->field_b = r1
    //     0xbe7298: stur            w1, [x0, #0xb]
    // 0xbe729c: LeaveFrame
    //     0xbe729c: mov             SP, fp
    //     0xbe72a0: ldp             fp, lr, [SP], #0x10
    // 0xbe72a4: ret
    //     0xbe72a4: ret             
  }
  [closure] ColorTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xbe72a8, size: 0x68
    // 0xbe72a8: EnterFrame
    //     0xbe72a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe72ac: mov             fp, SP
    // 0xbe72b0: ldr             x0, [fp, #0x10]
    // 0xbe72b4: r2 = Null
    //     0xbe72b4: mov             x2, NULL
    // 0xbe72b8: r1 = Null
    //     0xbe72b8: mov             x1, NULL
    // 0xbe72bc: r4 = 59
    //     0xbe72bc: mov             x4, #0x3b
    // 0xbe72c0: branchIfSmi(r0, 0xbe72cc)
    //     0xbe72c0: tbz             w0, #0, #0xbe72cc
    // 0xbe72c4: r4 = LoadClassIdInstr(r0)
    //     0xbe72c4: ldur            x4, [x0, #-1]
    //     0xbe72c8: ubfx            x4, x4, #0xc, #0x14
    // 0xbe72cc: r17 = -5057
    //     0xbe72cc: mov             x17, #-0x13c1
    // 0xbe72d0: add             x4, x4, x17
    // 0xbe72d4: cmp             x4, #7
    // 0xbe72d8: b.ls            #0xbe72f0
    // 0xbe72dc: r8 = Color
    //     0xbe72dc: add             x8, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xbe72e0: ldr             x8, [x8, #0xf18]
    // 0xbe72e4: r3 = Null
    //     0xbe72e4: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a48] Null
    //     0xbe72e8: ldr             x3, [x3, #0xa48]
    // 0xbe72ec: r0 = Color()
    //     0xbe72ec: bl              #0x4f7d7c  ; IsType_Color_Stub
    // 0xbe72f0: r1 = <Color?>
    //     0xbe72f0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbe72f4: ldr             x1, [x1, #0xf68]
    // 0xbe72f8: r0 = ColorTween()
    //     0xbe72f8: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xbe72fc: ldr             x1, [fp, #0x10]
    // 0xbe7300: StoreField: r0->field_b = r1
    //     0xbe7300: stur            w1, [x0, #0xb]
    // 0xbe7304: LeaveFrame
    //     0xbe7304: mov             SP, fp
    //     0xbe7308: ldp             fp, lr, [SP], #0x10
    // 0xbe730c: ret
    //     0xbe730c: ret             
  }
  [closure] ColorTween <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xbe7310, size: 0x68
    // 0xbe7310: EnterFrame
    //     0xbe7310: stp             fp, lr, [SP, #-0x10]!
    //     0xbe7314: mov             fp, SP
    // 0xbe7318: ldr             x0, [fp, #0x10]
    // 0xbe731c: r2 = Null
    //     0xbe731c: mov             x2, NULL
    // 0xbe7320: r1 = Null
    //     0xbe7320: mov             x1, NULL
    // 0xbe7324: r4 = 59
    //     0xbe7324: mov             x4, #0x3b
    // 0xbe7328: branchIfSmi(r0, 0xbe7334)
    //     0xbe7328: tbz             w0, #0, #0xbe7334
    // 0xbe732c: r4 = LoadClassIdInstr(r0)
    //     0xbe732c: ldur            x4, [x0, #-1]
    //     0xbe7330: ubfx            x4, x4, #0xc, #0x14
    // 0xbe7334: r17 = -5057
    //     0xbe7334: mov             x17, #-0x13c1
    // 0xbe7338: add             x4, x4, x17
    // 0xbe733c: cmp             x4, #7
    // 0xbe7340: b.ls            #0xbe7358
    // 0xbe7344: r8 = Color
    //     0xbe7344: add             x8, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xbe7348: ldr             x8, [x8, #0xf18]
    // 0xbe734c: r3 = Null
    //     0xbe734c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a58] Null
    //     0xbe7350: ldr             x3, [x3, #0xa58]
    // 0xbe7354: r0 = Color()
    //     0xbe7354: bl              #0x4f7d7c  ; IsType_Color_Stub
    // 0xbe7358: r1 = <Color?>
    //     0xbe7358: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbe735c: ldr             x1, [x1, #0xf68]
    // 0xbe7360: r0 = ColorTween()
    //     0xbe7360: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xbe7364: ldr             x1, [fp, #0x10]
    // 0xbe7368: StoreField: r0->field_b = r1
    //     0xbe7368: stur            w1, [x0, #0xb]
    // 0xbe736c: LeaveFrame
    //     0xbe736c: mov             SP, fp
    //     0xbe7370: ldp             fp, lr, [SP], #0x10
    // 0xbe7374: ret
    //     0xbe7374: ret             
  }
  [closure] Tween<double> <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xbe7378, size: 0x58
    // 0xbe7378: EnterFrame
    //     0xbe7378: stp             fp, lr, [SP, #-0x10]!
    //     0xbe737c: mov             fp, SP
    // 0xbe7380: ldr             x0, [fp, #0x10]
    // 0xbe7384: r2 = Null
    //     0xbe7384: mov             x2, NULL
    // 0xbe7388: r1 = Null
    //     0xbe7388: mov             x1, NULL
    // 0xbe738c: r4 = 59
    //     0xbe738c: mov             x4, #0x3b
    // 0xbe7390: branchIfSmi(r0, 0xbe739c)
    //     0xbe7390: tbz             w0, #0, #0xbe739c
    // 0xbe7394: r4 = LoadClassIdInstr(r0)
    //     0xbe7394: ldur            x4, [x0, #-1]
    //     0xbe7398: ubfx            x4, x4, #0xc, #0x14
    // 0xbe739c: cmp             x4, #0x3d
    // 0xbe73a0: b.eq            #0xbe73b4
    // 0xbe73a4: r8 = double
    //     0xbe73a4: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xbe73a8: r3 = Null
    //     0xbe73a8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28a68] Null
    //     0xbe73ac: ldr             x3, [x3, #0xa68]
    // 0xbe73b0: r0 = double()
    //     0xbe73b0: bl              #0xd72bac  ; IsType_double_Stub
    // 0xbe73b4: r1 = <double>
    //     0xbe73b4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xbe73b8: r0 = Tween()
    //     0xbe73b8: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xbe73bc: ldr             x1, [fp, #0x10]
    // 0xbe73c0: StoreField: r0->field_b = r1
    //     0xbe73c0: stur            w1, [x0, #0xb]
    // 0xbe73c4: LeaveFrame
    //     0xbe73c4: mov             SP, fp
    //     0xbe73c8: ldp             fp, lr, [SP], #0x10
    // 0xbe73cc: ret
    //     0xbe73cc: ret             
  }
}

// class id: 3311, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __MaterialState&State&TickerProviderStateMixin extends State<Material>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x617888, size: 0x178
    // 0x617888: EnterFrame
    //     0x617888: stp             fp, lr, [SP, #-0x10]!
    //     0x61788c: mov             fp, SP
    // 0x617890: AllocStack(0x10)
    //     0x617890: sub             SP, SP, #0x10
    // 0x617894: CheckStackOverflow
    //     0x617894: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617898: cmp             SP, x16
    //     0x61789c: b.ls            #0x6179f0
    // 0x6178a0: ldr             x0, [fp, #0x18]
    // 0x6178a4: LoadField: r1 = r0->field_17
    //     0x6178a4: ldur            w1, [x0, #0x17]
    // 0x6178a8: DecompressPointer r1
    //     0x6178a8: add             x1, x1, HEAP, lsl #32
    // 0x6178ac: cmp             w1, NULL
    // 0x6178b0: b.ne            #0x6178c0
    // 0x6178b4: SaveReg r0
    //     0x6178b4: str             x0, [SP, #-8]!
    // 0x6178b8: r0 = _updateTickerModeNotifier()
    //     0x6178b8: bl              #0x617a24  ; [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x6178bc: add             SP, SP, #8
    // 0x6178c0: ldr             x0, [fp, #0x18]
    // 0x6178c4: LoadField: r1 = r0->field_13
    //     0x6178c4: ldur            w1, [x0, #0x13]
    // 0x6178c8: DecompressPointer r1
    //     0x6178c8: add             x1, x1, HEAP, lsl #32
    // 0x6178cc: cmp             w1, NULL
    // 0x6178d0: b.ne            #0x617968
    // 0x6178d4: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x6178d4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6178d8: ldr             x0, [x0, #0x598]
    //     0x6178dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6178e0: cmp             w0, w16
    //     0x6178e4: b.ne            #0x6178f0
    //     0x6178e8: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x6178ec: bl              #0xd67cdc
    // 0x6178f0: r1 = <_WidgetTicker>
    //     0x6178f0: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x6178f4: ldr             x1, [x1, #0x210]
    // 0x6178f8: stur            x0, [fp, #-8]
    // 0x6178fc: r0 = _Set()
    //     0x6178fc: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x617900: mov             x1, x0
    // 0x617904: ldur            x0, [fp, #-8]
    // 0x617908: stur            x1, [fp, #-0x10]
    // 0x61790c: StoreField: r1->field_1b = r0
    //     0x61790c: stur            w0, [x1, #0x1b]
    // 0x617910: StoreField: r1->field_b = rZR
    //     0x617910: stur            wzr, [x1, #0xb]
    // 0x617914: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x617914: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x617918: ldr             x0, [x0, #0x5a0]
    //     0x61791c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x617920: cmp             w0, w16
    //     0x617924: b.ne            #0x617930
    //     0x617928: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x61792c: bl              #0xd67cdc
    // 0x617930: mov             x1, x0
    // 0x617934: ldur            x0, [fp, #-0x10]
    // 0x617938: StoreField: r0->field_f = r1
    //     0x617938: stur            w1, [x0, #0xf]
    // 0x61793c: StoreField: r0->field_13 = rZR
    //     0x61793c: stur            wzr, [x0, #0x13]
    // 0x617940: StoreField: r0->field_17 = rZR
    //     0x617940: stur            wzr, [x0, #0x17]
    // 0x617944: ldr             x1, [fp, #0x18]
    // 0x617948: StoreField: r1->field_13 = r0
    //     0x617948: stur            w0, [x1, #0x13]
    //     0x61794c: ldurb           w16, [x1, #-1]
    //     0x617950: ldurb           w17, [x0, #-1]
    //     0x617954: and             x16, x17, x16, lsr #2
    //     0x617958: tst             x16, HEAP, lsr #32
    //     0x61795c: b.eq            #0x617964
    //     0x617960: bl              #0xd6826c
    // 0x617964: b               #0x61796c
    // 0x617968: mov             x1, x0
    // 0x61796c: ldr             x0, [fp, #0x10]
    // 0x617970: r0 = _WidgetTicker()
    //     0x617970: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x617974: mov             x1, x0
    // 0x617978: ldr             x0, [fp, #0x18]
    // 0x61797c: stur            x1, [fp, #-8]
    // 0x617980: StoreField: r1->field_1b = r0
    //     0x617980: stur            w0, [x1, #0x1b]
    // 0x617984: r2 = false
    //     0x617984: add             x2, NULL, #0x30  ; false
    // 0x617988: StoreField: r1->field_b = r2
    //     0x617988: stur            w2, [x1, #0xb]
    // 0x61798c: ldr             x2, [fp, #0x10]
    // 0x617990: StoreField: r1->field_13 = r2
    //     0x617990: stur            w2, [x1, #0x13]
    // 0x617994: LoadField: r2 = r0->field_17
    //     0x617994: ldur            w2, [x0, #0x17]
    // 0x617998: DecompressPointer r2
    //     0x617998: add             x2, x2, HEAP, lsl #32
    // 0x61799c: cmp             w2, NULL
    // 0x6179a0: b.eq            #0x6179f8
    // 0x6179a4: LoadField: r3 = r2->field_27
    //     0x6179a4: ldur            w3, [x2, #0x27]
    // 0x6179a8: DecompressPointer r3
    //     0x6179a8: add             x3, x3, HEAP, lsl #32
    // 0x6179ac: eor             x2, x3, #0x10
    // 0x6179b0: stp             x2, x1, [SP, #-0x10]!
    // 0x6179b4: r0 = muted=()
    //     0x6179b4: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x6179b8: add             SP, SP, #0x10
    // 0x6179bc: ldr             x0, [fp, #0x18]
    // 0x6179c0: LoadField: r1 = r0->field_13
    //     0x6179c0: ldur            w1, [x0, #0x13]
    // 0x6179c4: DecompressPointer r1
    //     0x6179c4: add             x1, x1, HEAP, lsl #32
    // 0x6179c8: cmp             w1, NULL
    // 0x6179cc: b.eq            #0x6179fc
    // 0x6179d0: ldur            x16, [fp, #-8]
    // 0x6179d4: stp             x16, x1, [SP, #-0x10]!
    // 0x6179d8: r0 = add()
    //     0x6179d8: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x6179dc: add             SP, SP, #0x10
    // 0x6179e0: ldur            x0, [fp, #-8]
    // 0x6179e4: LeaveFrame
    //     0x6179e4: mov             SP, fp
    //     0x6179e8: ldp             fp, lr, [SP], #0x10
    // 0x6179ec: ret
    //     0x6179ec: ret             
    // 0x6179f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6179f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6179f4: b               #0x6178a0
    // 0x6179f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6179f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6179fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6179fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x617a24, size: 0x11c
    // 0x617a24: EnterFrame
    //     0x617a24: stp             fp, lr, [SP, #-0x10]!
    //     0x617a28: mov             fp, SP
    // 0x617a2c: AllocStack(0x10)
    //     0x617a2c: sub             SP, SP, #0x10
    // 0x617a30: CheckStackOverflow
    //     0x617a30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617a34: cmp             SP, x16
    //     0x617a38: b.ls            #0x617b34
    // 0x617a3c: ldr             x0, [fp, #0x10]
    // 0x617a40: LoadField: r1 = r0->field_f
    //     0x617a40: ldur            w1, [x0, #0xf]
    // 0x617a44: DecompressPointer r1
    //     0x617a44: add             x1, x1, HEAP, lsl #32
    // 0x617a48: cmp             w1, NULL
    // 0x617a4c: b.eq            #0x617b3c
    // 0x617a50: SaveReg r1
    //     0x617a50: str             x1, [SP, #-8]!
    // 0x617a54: r0 = getNotifier()
    //     0x617a54: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x617a58: add             SP, SP, #8
    // 0x617a5c: mov             x1, x0
    // 0x617a60: ldr             x0, [fp, #0x10]
    // 0x617a64: stur            x1, [fp, #-0x10]
    // 0x617a68: LoadField: r2 = r0->field_17
    //     0x617a68: ldur            w2, [x0, #0x17]
    // 0x617a6c: DecompressPointer r2
    //     0x617a6c: add             x2, x2, HEAP, lsl #32
    // 0x617a70: stur            x2, [fp, #-8]
    // 0x617a74: cmp             w1, w2
    // 0x617a78: b.ne            #0x617a8c
    // 0x617a7c: r0 = Null
    //     0x617a7c: mov             x0, NULL
    // 0x617a80: LeaveFrame
    //     0x617a80: mov             SP, fp
    //     0x617a84: ldp             fp, lr, [SP], #0x10
    // 0x617a88: ret
    //     0x617a88: ret             
    // 0x617a8c: cmp             w2, NULL
    // 0x617a90: b.eq            #0x617acc
    // 0x617a94: r1 = 1
    //     0x617a94: mov             x1, #1
    // 0x617a98: r0 = AllocateContext()
    //     0x617a98: bl              #0xd68aa4  ; AllocateContextStub
    // 0x617a9c: mov             x1, x0
    // 0x617aa0: ldr             x0, [fp, #0x10]
    // 0x617aa4: StoreField: r1->field_f = r0
    //     0x617aa4: stur            w0, [x1, #0xf]
    // 0x617aa8: mov             x2, x1
    // 0x617aac: r1 = Function '_updateTickers@156311458':.
    //     0x617aac: add             x1, PP, #0x15, lsl #12  ; [pp+0x15290] AnonymousClosure: (0x617b40), in [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickers (0x617b88)
    //     0x617ab0: ldr             x1, [x1, #0x290]
    // 0x617ab4: r0 = AllocateClosure()
    //     0x617ab4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x617ab8: ldur            x16, [fp, #-8]
    // 0x617abc: stp             x0, x16, [SP, #-0x10]!
    // 0x617ac0: r0 = removeListener()
    //     0x617ac0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x617ac4: add             SP, SP, #0x10
    // 0x617ac8: ldr             x0, [fp, #0x10]
    // 0x617acc: r1 = 1
    //     0x617acc: mov             x1, #1
    // 0x617ad0: r0 = AllocateContext()
    //     0x617ad0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x617ad4: mov             x1, x0
    // 0x617ad8: ldr             x0, [fp, #0x10]
    // 0x617adc: StoreField: r1->field_f = r0
    //     0x617adc: stur            w0, [x1, #0xf]
    // 0x617ae0: mov             x2, x1
    // 0x617ae4: r1 = Function '_updateTickers@156311458':.
    //     0x617ae4: add             x1, PP, #0x15, lsl #12  ; [pp+0x15290] AnonymousClosure: (0x617b40), in [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickers (0x617b88)
    //     0x617ae8: ldr             x1, [x1, #0x290]
    // 0x617aec: r0 = AllocateClosure()
    //     0x617aec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x617af0: ldur            x16, [fp, #-0x10]
    // 0x617af4: stp             x0, x16, [SP, #-0x10]!
    // 0x617af8: r0 = addListener()
    //     0x617af8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x617afc: add             SP, SP, #0x10
    // 0x617b00: ldur            x0, [fp, #-0x10]
    // 0x617b04: ldr             x1, [fp, #0x10]
    // 0x617b08: StoreField: r1->field_17 = r0
    //     0x617b08: stur            w0, [x1, #0x17]
    //     0x617b0c: ldurb           w16, [x1, #-1]
    //     0x617b10: ldurb           w17, [x0, #-1]
    //     0x617b14: and             x16, x17, x16, lsr #2
    //     0x617b18: tst             x16, HEAP, lsr #32
    //     0x617b1c: b.eq            #0x617b24
    //     0x617b20: bl              #0xd6826c
    // 0x617b24: r0 = Null
    //     0x617b24: mov             x0, NULL
    // 0x617b28: LeaveFrame
    //     0x617b28: mov             SP, fp
    //     0x617b2c: ldp             fp, lr, [SP], #0x10
    // 0x617b30: ret
    //     0x617b30: ret             
    // 0x617b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x617b34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x617b38: b               #0x617a3c
    // 0x617b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x617b3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x617b40, size: 0x48
    // 0x617b40: EnterFrame
    //     0x617b40: stp             fp, lr, [SP, #-0x10]!
    //     0x617b44: mov             fp, SP
    // 0x617b48: ldr             x0, [fp, #0x10]
    // 0x617b4c: LoadField: r1 = r0->field_17
    //     0x617b4c: ldur            w1, [x0, #0x17]
    // 0x617b50: DecompressPointer r1
    //     0x617b50: add             x1, x1, HEAP, lsl #32
    // 0x617b54: CheckStackOverflow
    //     0x617b54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617b58: cmp             SP, x16
    //     0x617b5c: b.ls            #0x617b80
    // 0x617b60: LoadField: r0 = r1->field_f
    //     0x617b60: ldur            w0, [x1, #0xf]
    // 0x617b64: DecompressPointer r0
    //     0x617b64: add             x0, x0, HEAP, lsl #32
    // 0x617b68: SaveReg r0
    //     0x617b68: str             x0, [SP, #-8]!
    // 0x617b6c: r0 = _updateTickers()
    //     0x617b6c: bl              #0x617b88  ; [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickers
    // 0x617b70: add             SP, SP, #8
    // 0x617b74: LeaveFrame
    //     0x617b74: mov             SP, fp
    //     0x617b78: ldp             fp, lr, [SP], #0x10
    // 0x617b7c: ret
    //     0x617b7c: ret             
    // 0x617b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x617b80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x617b84: b               #0x617b60
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x617b88, size: 0x150
    // 0x617b88: EnterFrame
    //     0x617b88: stp             fp, lr, [SP, #-0x10]!
    //     0x617b8c: mov             fp, SP
    // 0x617b90: AllocStack(0x20)
    //     0x617b90: sub             SP, SP, #0x20
    // 0x617b94: CheckStackOverflow
    //     0x617b94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617b98: cmp             SP, x16
    //     0x617b9c: b.ls            #0x617cc4
    // 0x617ba0: ldr             x0, [fp, #0x10]
    // 0x617ba4: LoadField: r1 = r0->field_13
    //     0x617ba4: ldur            w1, [x0, #0x13]
    // 0x617ba8: DecompressPointer r1
    //     0x617ba8: add             x1, x1, HEAP, lsl #32
    // 0x617bac: cmp             w1, NULL
    // 0x617bb0: b.eq            #0x617cb4
    // 0x617bb4: LoadField: r2 = r0->field_17
    //     0x617bb4: ldur            w2, [x0, #0x17]
    // 0x617bb8: DecompressPointer r2
    //     0x617bb8: add             x2, x2, HEAP, lsl #32
    // 0x617bbc: cmp             w2, NULL
    // 0x617bc0: b.eq            #0x617ccc
    // 0x617bc4: LoadField: r0 = r2->field_27
    //     0x617bc4: ldur            w0, [x2, #0x27]
    // 0x617bc8: DecompressPointer r0
    //     0x617bc8: add             x0, x0, HEAP, lsl #32
    // 0x617bcc: eor             x2, x0, #0x10
    // 0x617bd0: stur            x2, [fp, #-8]
    // 0x617bd4: SaveReg r1
    //     0x617bd4: str             x1, [SP, #-8]!
    // 0x617bd8: r0 = iterator()
    //     0x617bd8: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x617bdc: add             SP, SP, #8
    // 0x617be0: stur            x0, [fp, #-0x18]
    // 0x617be4: LoadField: r2 = r0->field_7
    //     0x617be4: ldur            w2, [x0, #7]
    // 0x617be8: DecompressPointer r2
    //     0x617be8: add             x2, x2, HEAP, lsl #32
    // 0x617bec: stur            x2, [fp, #-0x10]
    // 0x617bf0: ldur            x1, [fp, #-8]
    // 0x617bf4: CheckStackOverflow
    //     0x617bf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617bf8: cmp             SP, x16
    //     0x617bfc: b.ls            #0x617cd0
    // 0x617c00: SaveReg r0
    //     0x617c00: str             x0, [SP, #-8]!
    // 0x617c04: r0 = moveNext()
    //     0x617c04: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x617c08: add             SP, SP, #8
    // 0x617c0c: tbnz            w0, #4, #0x617cb4
    // 0x617c10: ldur            x3, [fp, #-0x18]
    // 0x617c14: LoadField: r4 = r3->field_33
    //     0x617c14: ldur            w4, [x3, #0x33]
    // 0x617c18: DecompressPointer r4
    //     0x617c18: add             x4, x4, HEAP, lsl #32
    // 0x617c1c: stur            x4, [fp, #-0x20]
    // 0x617c20: cmp             w4, NULL
    // 0x617c24: b.ne            #0x617c58
    // 0x617c28: mov             x0, x4
    // 0x617c2c: ldur            x2, [fp, #-0x10]
    // 0x617c30: r1 = Null
    //     0x617c30: mov             x1, NULL
    // 0x617c34: cmp             w2, NULL
    // 0x617c38: b.eq            #0x617c58
    // 0x617c3c: LoadField: r4 = r2->field_17
    //     0x617c3c: ldur            w4, [x2, #0x17]
    // 0x617c40: DecompressPointer r4
    //     0x617c40: add             x4, x4, HEAP, lsl #32
    // 0x617c44: r8 = X0
    //     0x617c44: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x617c48: LoadField: r9 = r4->field_7
    //     0x617c48: ldur            x9, [x4, #7]
    // 0x617c4c: r3 = Null
    //     0x617c4c: add             x3, PP, #0x15, lsl #12  ; [pp+0x15298] Null
    //     0x617c50: ldr             x3, [x3, #0x298]
    // 0x617c54: blr             x9
    // 0x617c58: ldur            x1, [fp, #-8]
    // 0x617c5c: ldur            x0, [fp, #-0x20]
    // 0x617c60: LoadField: r2 = r0->field_b
    //     0x617c60: ldur            w2, [x0, #0xb]
    // 0x617c64: DecompressPointer r2
    //     0x617c64: add             x2, x2, HEAP, lsl #32
    // 0x617c68: cmp             w1, w2
    // 0x617c6c: b.eq            #0x617ca8
    // 0x617c70: StoreField: r0->field_b = r1
    //     0x617c70: stur            w1, [x0, #0xb]
    // 0x617c74: tbnz            w1, #4, #0x617c88
    // 0x617c78: SaveReg r0
    //     0x617c78: str             x0, [SP, #-8]!
    // 0x617c7c: r0 = unscheduleTick()
    //     0x617c7c: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x617c80: add             SP, SP, #8
    // 0x617c84: b               #0x617ca8
    // 0x617c88: SaveReg r0
    //     0x617c88: str             x0, [SP, #-8]!
    // 0x617c8c: r0 = shouldScheduleTick()
    //     0x617c8c: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x617c90: add             SP, SP, #8
    // 0x617c94: tbnz            w0, #4, #0x617ca8
    // 0x617c98: ldur            x16, [fp, #-0x20]
    // 0x617c9c: SaveReg r16
    //     0x617c9c: str             x16, [SP, #-8]!
    // 0x617ca0: r0 = scheduleTick()
    //     0x617ca0: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x617ca4: add             SP, SP, #8
    // 0x617ca8: ldur            x0, [fp, #-0x18]
    // 0x617cac: ldur            x2, [fp, #-0x10]
    // 0x617cb0: b               #0x617bf0
    // 0x617cb4: r0 = Null
    //     0x617cb4: mov             x0, NULL
    // 0x617cb8: LeaveFrame
    //     0x617cb8: mov             SP, fp
    //     0x617cbc: ldp             fp, lr, [SP], #0x10
    // 0x617cc0: ret
    //     0x617cc0: ret             
    // 0x617cc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x617cc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x617cc8: b               #0x617ba0
    // 0x617ccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x617ccc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x617cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x617cd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x617cd4: b               #0x617c00
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f4a8, size: 0x4c
    // 0x81f4a8: EnterFrame
    //     0x81f4a8: stp             fp, lr, [SP, #-0x10]!
    //     0x81f4ac: mov             fp, SP
    // 0x81f4b0: CheckStackOverflow
    //     0x81f4b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f4b4: cmp             SP, x16
    //     0x81f4b8: b.ls            #0x81f4ec
    // 0x81f4bc: ldr             x16, [fp, #0x10]
    // 0x81f4c0: SaveReg r16
    //     0x81f4c0: str             x16, [SP, #-8]!
    // 0x81f4c4: r0 = _updateTickerModeNotifier()
    //     0x81f4c4: bl              #0x617a24  ; [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f4c8: add             SP, SP, #8
    // 0x81f4cc: ldr             x16, [fp, #0x10]
    // 0x81f4d0: SaveReg r16
    //     0x81f4d0: str             x16, [SP, #-8]!
    // 0x81f4d4: r0 = _updateTickers()
    //     0x81f4d4: bl              #0x617b88  ; [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f4d8: add             SP, SP, #8
    // 0x81f4dc: r0 = Null
    //     0x81f4dc: mov             x0, NULL
    // 0x81f4e0: LeaveFrame
    //     0x81f4e0: mov             SP, fp
    //     0x81f4e4: ldp             fp, lr, [SP], #0x10
    // 0x81f4e8: ret
    //     0x81f4e8: ret             
    // 0x81f4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f4ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f4f0: b               #0x81f4bc
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4adc8, size: 0x18
    // 0xa4adc8: r4 = 7
    //     0xa4adc8: mov             x4, #7
    // 0xa4adcc: r1 = Function 'dispose':.
    //     0xa4adcc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b7f0] AnonymousClosure: (0xa4ade0), in [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::dispose (0xa51e68)
    //     0xa4add0: ldr             x1, [x17, #0x7f0]
    // 0xa4add4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4add4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4add8: LoadField: r0 = r24->field_17
    //     0xa4add8: ldur            x0, [x24, #0x17]
    // 0xa4addc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4ade0, size: 0x48
    // 0xa4ade0: EnterFrame
    //     0xa4ade0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ade4: mov             fp, SP
    // 0xa4ade8: ldr             x0, [fp, #0x10]
    // 0xa4adec: LoadField: r1 = r0->field_17
    //     0xa4adec: ldur            w1, [x0, #0x17]
    // 0xa4adf0: DecompressPointer r1
    //     0xa4adf0: add             x1, x1, HEAP, lsl #32
    // 0xa4adf4: CheckStackOverflow
    //     0xa4adf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4adf8: cmp             SP, x16
    //     0xa4adfc: b.ls            #0xa4ae20
    // 0xa4ae00: LoadField: r0 = r1->field_f
    //     0xa4ae00: ldur            w0, [x1, #0xf]
    // 0xa4ae04: DecompressPointer r0
    //     0xa4ae04: add             x0, x0, HEAP, lsl #32
    // 0xa4ae08: SaveReg r0
    //     0xa4ae08: str             x0, [SP, #-8]!
    // 0xa4ae0c: r0 = dispose()
    //     0xa4ae0c: bl              #0xa51e68  ; [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::dispose
    // 0xa4ae10: add             SP, SP, #8
    // 0xa4ae14: LeaveFrame
    //     0xa4ae14: mov             SP, fp
    //     0xa4ae18: ldp             fp, lr, [SP], #0x10
    // 0xa4ae1c: ret
    //     0xa4ae1c: ret             
    // 0xa4ae20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ae20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ae24: b               #0xa4ae00
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa51e68, size: 0x8c
    // 0xa51e68: EnterFrame
    //     0xa51e68: stp             fp, lr, [SP, #-0x10]!
    //     0xa51e6c: mov             fp, SP
    // 0xa51e70: AllocStack(0x8)
    //     0xa51e70: sub             SP, SP, #8
    // 0xa51e74: CheckStackOverflow
    //     0xa51e74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51e78: cmp             SP, x16
    //     0xa51e7c: b.ls            #0xa51eec
    // 0xa51e80: ldr             x0, [fp, #0x10]
    // 0xa51e84: LoadField: r1 = r0->field_17
    //     0xa51e84: ldur            w1, [x0, #0x17]
    // 0xa51e88: DecompressPointer r1
    //     0xa51e88: add             x1, x1, HEAP, lsl #32
    // 0xa51e8c: stur            x1, [fp, #-8]
    // 0xa51e90: cmp             w1, NULL
    // 0xa51e94: b.ne            #0xa51ea0
    // 0xa51e98: mov             x1, x0
    // 0xa51e9c: b               #0xa51ed8
    // 0xa51ea0: r1 = 1
    //     0xa51ea0: mov             x1, #1
    // 0xa51ea4: r0 = AllocateContext()
    //     0xa51ea4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa51ea8: mov             x1, x0
    // 0xa51eac: ldr             x0, [fp, #0x10]
    // 0xa51eb0: StoreField: r1->field_f = r0
    //     0xa51eb0: stur            w0, [x1, #0xf]
    // 0xa51eb4: mov             x2, x1
    // 0xa51eb8: r1 = Function '_updateTickers@156311458':.
    //     0xa51eb8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15290] AnonymousClosure: (0x617b40), in [package:flutter/src/material/material.dart] __MaterialState&State&TickerProviderStateMixin::_updateTickers (0x617b88)
    //     0xa51ebc: ldr             x1, [x1, #0x290]
    // 0xa51ec0: r0 = AllocateClosure()
    //     0xa51ec0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa51ec4: ldur            x16, [fp, #-8]
    // 0xa51ec8: stp             x0, x16, [SP, #-0x10]!
    // 0xa51ecc: r0 = removeListener()
    //     0xa51ecc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa51ed0: add             SP, SP, #0x10
    // 0xa51ed4: ldr             x1, [fp, #0x10]
    // 0xa51ed8: StoreField: r1->field_17 = rNULL
    //     0xa51ed8: stur            NULL, [x1, #0x17]
    // 0xa51edc: r0 = Null
    //     0xa51edc: mov             x0, NULL
    // 0xa51ee0: LeaveFrame
    //     0xa51ee0: mov             SP, fp
    //     0xa51ee4: ldp             fp, lr, [SP], #0x10
    // 0xa51ee8: ret
    //     0xa51ee8: ret             
    // 0xa51eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51ef0: b               #0xa51e80
  }
}

// class id: 3312, size: 0x20, field offset: 0x1c
class _MaterialState extends __MaterialState&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0x85fd6c, size: 0x588
    // 0x85fd6c: EnterFrame
    //     0x85fd6c: stp             fp, lr, [SP, #-0x10]!
    //     0x85fd70: mov             fp, SP
    // 0x85fd74: AllocStack(0x50)
    //     0x85fd74: sub             SP, SP, #0x50
    // 0x85fd78: CheckStackOverflow
    //     0x85fd78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85fd7c: cmp             SP, x16
    //     0x85fd80: b.ls            #0x8602c4
    // 0x85fd84: r1 = 1
    //     0x85fd84: mov             x1, #1
    // 0x85fd88: r0 = AllocateContext()
    //     0x85fd88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x85fd8c: mov             x1, x0
    // 0x85fd90: ldr             x0, [fp, #0x18]
    // 0x85fd94: stur            x1, [fp, #-8]
    // 0x85fd98: StoreField: r1->field_f = r0
    //     0x85fd98: stur            w0, [x1, #0xf]
    // 0x85fd9c: ldr             x16, [fp, #0x10]
    // 0x85fda0: SaveReg r16
    //     0x85fda0: str             x16, [SP, #-8]!
    // 0x85fda4: r0 = of()
    //     0x85fda4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x85fda8: add             SP, SP, #8
    // 0x85fdac: stur            x0, [fp, #-0x10]
    // 0x85fdb0: ldr             x16, [fp, #0x18]
    // 0x85fdb4: ldr             lr, [fp, #0x10]
    // 0x85fdb8: stp             lr, x16, [SP, #-0x10]!
    // 0x85fdbc: r0 = _getBackgroundColor()
    //     0x85fdbc: bl              #0x860a94  ; [package:flutter/src/material/material.dart] _MaterialState::_getBackgroundColor
    // 0x85fdc0: add             SP, SP, #0x10
    // 0x85fdc4: mov             x1, x0
    // 0x85fdc8: ldr             x0, [fp, #0x18]
    // 0x85fdcc: stur            x1, [fp, #-0x20]
    // 0x85fdd0: LoadField: r2 = r0->field_b
    //     0x85fdd0: ldur            w2, [x0, #0xb]
    // 0x85fdd4: DecompressPointer r2
    //     0x85fdd4: add             x2, x2, HEAP, lsl #32
    // 0x85fdd8: cmp             w2, NULL
    // 0x85fddc: b.eq            #0x8602cc
    // 0x85fde0: LoadField: r3 = r2->field_1f
    //     0x85fde0: ldur            w3, [x2, #0x1f]
    // 0x85fde4: DecompressPointer r3
    //     0x85fde4: add             x3, x3, HEAP, lsl #32
    // 0x85fde8: cmp             w3, NULL
    // 0x85fdec: b.ne            #0x85fe30
    // 0x85fdf0: ldur            x3, [fp, #-0x10]
    // 0x85fdf4: LoadField: r4 = r3->field_2b
    //     0x85fdf4: ldur            w4, [x3, #0x2b]
    // 0x85fdf8: DecompressPointer r4
    //     0x85fdf8: add             x4, x4, HEAP, lsl #32
    // 0x85fdfc: tbnz            w4, #4, #0x85fe24
    // 0x85fe00: LoadField: r4 = r3->field_3f
    //     0x85fe00: ldur            w4, [x3, #0x3f]
    // 0x85fe04: DecompressPointer r4
    //     0x85fe04: add             x4, x4, HEAP, lsl #32
    // 0x85fe08: LoadField: r3 = r4->field_6b
    //     0x85fe08: ldur            w3, [x4, #0x6b]
    // 0x85fe0c: DecompressPointer r3
    //     0x85fe0c: add             x3, x3, HEAP, lsl #32
    // 0x85fe10: cmp             w3, NULL
    // 0x85fe14: b.ne            #0x85fe30
    // 0x85fe18: r3 = Instance_Color
    //     0x85fe18: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x85fe1c: ldr             x3, [x3, #0xf38]
    // 0x85fe20: b               #0x85fe30
    // 0x85fe24: LoadField: r4 = r3->field_7b
    //     0x85fe24: ldur            w4, [x3, #0x7b]
    // 0x85fe28: DecompressPointer r4
    //     0x85fe28: add             x4, x4, HEAP, lsl #32
    // 0x85fe2c: mov             x3, x4
    // 0x85fe30: stur            x3, [fp, #-0x18]
    // 0x85fe34: LoadField: d0 = r2->field_13
    //     0x85fe34: ldur            d0, [x2, #0x13]
    // 0x85fe38: stur            d0, [fp, #-0x50]
    // 0x85fe3c: LoadField: r4 = r2->field_b
    //     0x85fe3c: ldur            w4, [x2, #0xb]
    // 0x85fe40: DecompressPointer r4
    //     0x85fe40: add             x4, x4, HEAP, lsl #32
    // 0x85fe44: stur            x4, [fp, #-0x10]
    // 0x85fe48: cmp             w4, NULL
    // 0x85fe4c: b.eq            #0x85ff18
    // 0x85fe50: LoadField: r5 = r2->field_27
    //     0x85fe50: ldur            w5, [x2, #0x27]
    // 0x85fe54: DecompressPointer r5
    //     0x85fe54: add             x5, x5, HEAP, lsl #32
    // 0x85fe58: cmp             w5, NULL
    // 0x85fe5c: b.ne            #0x85fe90
    // 0x85fe60: ldr             x16, [fp, #0x10]
    // 0x85fe64: SaveReg r16
    //     0x85fe64: str             x16, [SP, #-8]!
    // 0x85fe68: r0 = of()
    //     0x85fe68: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x85fe6c: add             SP, SP, #8
    // 0x85fe70: LoadField: r1 = r0->field_93
    //     0x85fe70: ldur            w1, [x0, #0x93]
    // 0x85fe74: DecompressPointer r1
    //     0x85fe74: add             x1, x1, HEAP, lsl #32
    // 0x85fe78: LoadField: r0 = r1->field_2f
    //     0x85fe78: ldur            w0, [x1, #0x2f]
    // 0x85fe7c: DecompressPointer r0
    //     0x85fe7c: add             x0, x0, HEAP, lsl #32
    // 0x85fe80: cmp             w0, NULL
    // 0x85fe84: b.eq            #0x8602d0
    // 0x85fe88: mov             x2, x0
    // 0x85fe8c: b               #0x85fe94
    // 0x85fe90: mov             x2, x5
    // 0x85fe94: ldr             x0, [fp, #0x18]
    // 0x85fe98: ldur            x1, [fp, #-0x10]
    // 0x85fe9c: stur            x2, [fp, #-0x38]
    // 0x85fea0: LoadField: r3 = r0->field_b
    //     0x85fea0: ldur            w3, [x0, #0xb]
    // 0x85fea4: DecompressPointer r3
    //     0x85fea4: add             x3, x3, HEAP, lsl #32
    // 0x85fea8: stur            x3, [fp, #-0x30]
    // 0x85feac: cmp             w3, NULL
    // 0x85feb0: b.eq            #0x8602d4
    // 0x85feb4: LoadField: r4 = r3->field_37
    //     0x85feb4: ldur            w4, [x3, #0x37]
    // 0x85feb8: DecompressPointer r4
    //     0x85feb8: add             x4, x4, HEAP, lsl #32
    // 0x85febc: stur            x4, [fp, #-0x28]
    // 0x85fec0: r0 = AnimatedDefaultTextStyle()
    //     0x85fec0: bl              #0x85cffc  ; AllocateAnimatedDefaultTextStyleStub -> AnimatedDefaultTextStyle (size=0x38)
    // 0x85fec4: mov             x1, x0
    // 0x85fec8: ldur            x0, [fp, #-0x10]
    // 0x85fecc: StoreField: r1->field_17 = r0
    //     0x85fecc: stur            w0, [x1, #0x17]
    // 0x85fed0: ldur            x0, [fp, #-0x38]
    // 0x85fed4: StoreField: r1->field_1b = r0
    //     0x85fed4: stur            w0, [x1, #0x1b]
    // 0x85fed8: r3 = true
    //     0x85fed8: add             x3, NULL, #0x20  ; true
    // 0x85fedc: StoreField: r1->field_23 = r3
    //     0x85fedc: stur            w3, [x1, #0x23]
    // 0x85fee0: r0 = Instance_TextOverflow
    //     0x85fee0: add             x0, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0x85fee4: ldr             x0, [x0, #0x118]
    // 0x85fee8: StoreField: r1->field_27 = r0
    //     0x85fee8: stur            w0, [x1, #0x27]
    // 0x85feec: r0 = Instance_TextWidthBasis
    //     0x85feec: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x85fef0: ldr             x0, [x0, #0x148]
    // 0x85fef4: StoreField: r1->field_2f = r0
    //     0x85fef4: stur            w0, [x1, #0x2f]
    // 0x85fef8: r0 = Instance__Linear
    //     0x85fef8: add             x0, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x85fefc: ldr             x0, [x0, #0x300]
    // 0x85ff00: StoreField: r1->field_b = r0
    //     0x85ff00: stur            w0, [x1, #0xb]
    // 0x85ff04: ldur            x0, [fp, #-0x28]
    // 0x85ff08: StoreField: r1->field_f = r0
    //     0x85ff08: stur            w0, [x1, #0xf]
    // 0x85ff0c: mov             x4, x1
    // 0x85ff10: ldur            x2, [fp, #-0x30]
    // 0x85ff14: b               #0x85ff24
    // 0x85ff18: mov             x0, x4
    // 0x85ff1c: r3 = true
    //     0x85ff1c: add             x3, NULL, #0x20  ; true
    // 0x85ff20: mov             x4, x0
    // 0x85ff24: ldr             x0, [fp, #0x18]
    // 0x85ff28: ldur            x1, [fp, #-0x20]
    // 0x85ff2c: stur            x4, [fp, #-0x38]
    // 0x85ff30: stur            x2, [fp, #-0x40]
    // 0x85ff34: LoadField: r5 = r0->field_1b
    //     0x85ff34: ldur            w5, [x0, #0x1b]
    // 0x85ff38: DecompressPointer r5
    //     0x85ff38: add             x5, x5, HEAP, lsl #32
    // 0x85ff3c: stur            x5, [fp, #-0x30]
    // 0x85ff40: LoadField: r6 = r2->field_f
    //     0x85ff40: ldur            w6, [x2, #0xf]
    // 0x85ff44: DecompressPointer r6
    //     0x85ff44: add             x6, x6, HEAP, lsl #32
    // 0x85ff48: stur            x6, [fp, #-0x28]
    // 0x85ff4c: r16 = Instance_MaterialType
    //     0x85ff4c: add             x16, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x85ff50: ldr             x16, [x16, #0x2a8]
    // 0x85ff54: cmp             w6, w16
    // 0x85ff58: r16 = true
    //     0x85ff58: add             x16, NULL, #0x20  ; true
    // 0x85ff5c: r17 = false
    //     0x85ff5c: add             x17, NULL, #0x30  ; false
    // 0x85ff60: csel            x7, x16, x17, ne
    // 0x85ff64: stur            x7, [fp, #-0x10]
    // 0x85ff68: r0 = _InkFeatures()
    //     0x85ff68: bl              #0x860a88  ; Allocate_InkFeaturesStub -> _InkFeatures (size=0x1c)
    // 0x85ff6c: mov             x3, x0
    // 0x85ff70: ldur            x0, [fp, #-0x20]
    // 0x85ff74: stur            x3, [fp, #-0x48]
    // 0x85ff78: StoreField: r3->field_f = r0
    //     0x85ff78: stur            w0, [x3, #0xf]
    // 0x85ff7c: ldr             x4, [fp, #0x18]
    // 0x85ff80: StoreField: r3->field_13 = r4
    //     0x85ff80: stur            w4, [x3, #0x13]
    // 0x85ff84: ldur            x1, [fp, #-0x10]
    // 0x85ff88: StoreField: r3->field_17 = r1
    //     0x85ff88: stur            w1, [x3, #0x17]
    // 0x85ff8c: ldur            x1, [fp, #-0x38]
    // 0x85ff90: StoreField: r3->field_b = r1
    //     0x85ff90: stur            w1, [x3, #0xb]
    // 0x85ff94: ldur            x1, [fp, #-0x30]
    // 0x85ff98: StoreField: r3->field_7 = r1
    //     0x85ff98: stur            w1, [x3, #7]
    // 0x85ff9c: ldur            x2, [fp, #-8]
    // 0x85ffa0: r1 = Function '<anonymous closure>':.
    //     0x85ffa0: add             x1, PP, #0x15, lsl #12  ; [pp+0x152b0] AnonymousClosure: (0x860b40), in [package:flutter/src/material/material.dart] _MaterialState::build (0x85fd6c)
    //     0x85ffa4: ldr             x1, [x1, #0x2b0]
    // 0x85ffa8: r0 = AllocateClosure()
    //     0x85ffa8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x85ffac: r1 = <LayoutChangedNotification>
    //     0x85ffac: add             x1, PP, #0x15, lsl #12  ; [pp+0x152b8] TypeArguments: <LayoutChangedNotification>
    //     0x85ffb0: ldr             x1, [x1, #0x2b8]
    // 0x85ffb4: stur            x0, [fp, #-8]
    // 0x85ffb8: r0 = NotificationListener()
    //     0x85ffb8: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x85ffbc: mov             x1, x0
    // 0x85ffc0: ldur            x0, [fp, #-8]
    // 0x85ffc4: stur            x1, [fp, #-0x10]
    // 0x85ffc8: StoreField: r1->field_13 = r0
    //     0x85ffc8: stur            w0, [x1, #0x13]
    // 0x85ffcc: ldur            x0, [fp, #-0x48]
    // 0x85ffd0: StoreField: r1->field_b = r0
    //     0x85ffd0: stur            w0, [x1, #0xb]
    // 0x85ffd4: ldur            x0, [fp, #-0x28]
    // 0x85ffd8: r16 = Instance_MaterialType
    //     0x85ffd8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe6f8] Obj!MaterialType@b65531
    //     0x85ffdc: ldr             x16, [x16, #0x6f8]
    // 0x85ffe0: cmp             w0, w16
    // 0x85ffe4: b.ne            #0x860198
    // 0x85ffe8: ldur            x0, [fp, #-0x40]
    // 0x85ffec: LoadField: r2 = r0->field_2b
    //     0x85ffec: ldur            w2, [x0, #0x2b]
    // 0x85fff0: DecompressPointer r2
    //     0x85fff0: add             x2, x2, HEAP, lsl #32
    // 0x85fff4: cmp             w2, NULL
    // 0x85fff8: b.ne            #0x860178
    // 0x85fffc: LoadField: r2 = r0->field_3b
    //     0x85fffc: ldur            w2, [x0, #0x3b]
    // 0x860000: DecompressPointer r2
    //     0x860000: add             x2, x2, HEAP, lsl #32
    // 0x860004: cmp             w2, NULL
    // 0x860008: b.ne            #0x860158
    // 0x86000c: ldr             x16, [fp, #0x10]
    // 0x860010: SaveReg r16
    //     0x860010: str             x16, [SP, #-8]!
    // 0x860014: r0 = of()
    //     0x860014: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x860018: add             SP, SP, #8
    // 0x86001c: LoadField: r1 = r0->field_2b
    //     0x86001c: ldur            w1, [x0, #0x2b]
    // 0x860020: DecompressPointer r1
    //     0x860020: add             x1, x1, HEAP, lsl #32
    // 0x860024: tbnz            w1, #4, #0x86006c
    // 0x860028: ldr             x1, [fp, #0x18]
    // 0x86002c: ldur            x0, [fp, #-0x20]
    // 0x860030: cmp             w0, NULL
    // 0x860034: b.eq            #0x8602d8
    // 0x860038: LoadField: r2 = r1->field_b
    //     0x860038: ldur            w2, [x1, #0xb]
    // 0x86003c: DecompressPointer r2
    //     0x86003c: add             x2, x2, HEAP, lsl #32
    // 0x860040: cmp             w2, NULL
    // 0x860044: b.eq            #0x8602dc
    // 0x860048: LoadField: r3 = r2->field_23
    //     0x860048: ldur            w3, [x2, #0x23]
    // 0x86004c: DecompressPointer r3
    //     0x86004c: add             x3, x3, HEAP, lsl #32
    // 0x860050: LoadField: d0 = r2->field_13
    //     0x860050: ldur            d0, [x2, #0x13]
    // 0x860054: stp             x3, x0, [SP, #-0x10]!
    // 0x860058: SaveReg d0
    //     0x860058: str             d0, [SP, #-8]!
    // 0x86005c: r0 = applySurfaceTint()
    //     0x86005c: bl              #0x860850  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applySurfaceTint
    // 0x860060: add             SP, SP, #0x18
    // 0x860064: mov             x3, x0
    // 0x860068: b               #0x8600a8
    // 0x86006c: ldr             x1, [fp, #0x18]
    // 0x860070: ldur            x0, [fp, #-0x20]
    // 0x860074: cmp             w0, NULL
    // 0x860078: b.eq            #0x8602e0
    // 0x86007c: LoadField: r2 = r1->field_b
    //     0x86007c: ldur            w2, [x1, #0xb]
    // 0x860080: DecompressPointer r2
    //     0x860080: add             x2, x2, HEAP, lsl #32
    // 0x860084: cmp             w2, NULL
    // 0x860088: b.eq            #0x8602e4
    // 0x86008c: LoadField: d0 = r2->field_13
    //     0x86008c: ldur            d0, [x2, #0x13]
    // 0x860090: ldr             x16, [fp, #0x10]
    // 0x860094: stp             x0, x16, [SP, #-0x10]!
    // 0x860098: SaveReg d0
    //     0x860098: str             d0, [SP, #-8]!
    // 0x86009c: r0 = applyOverlay()
    //     0x86009c: bl              #0x860624  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::applyOverlay
    // 0x8600a0: add             SP, SP, #0x18
    // 0x8600a4: mov             x3, x0
    // 0x8600a8: ldr             x1, [fp, #0x18]
    // 0x8600ac: ldur            x2, [fp, #-0x18]
    // 0x8600b0: ldur            d0, [fp, #-0x50]
    // 0x8600b4: ldur            x0, [fp, #-0x10]
    // 0x8600b8: stur            x3, [fp, #-0x30]
    // 0x8600bc: LoadField: r4 = r1->field_b
    //     0x8600bc: ldur            w4, [x1, #0xb]
    // 0x8600c0: DecompressPointer r4
    //     0x8600c0: add             x4, x4, HEAP, lsl #32
    // 0x8600c4: cmp             w4, NULL
    // 0x8600c8: b.eq            #0x8602e8
    // 0x8600cc: LoadField: r1 = r4->field_37
    //     0x8600cc: ldur            w1, [x4, #0x37]
    // 0x8600d0: DecompressPointer r1
    //     0x8600d0: add             x1, x1, HEAP, lsl #32
    // 0x8600d4: stur            x1, [fp, #-0x28]
    // 0x8600d8: LoadField: r5 = r4->field_33
    //     0x8600d8: ldur            w5, [x4, #0x33]
    // 0x8600dc: DecompressPointer r5
    //     0x8600dc: add             x5, x5, HEAP, lsl #32
    // 0x8600e0: stur            x5, [fp, #-8]
    // 0x8600e4: r0 = AnimatedPhysicalModel()
    //     0x8600e4: bl              #0x8605f4  ; AllocateAnimatedPhysicalModelStub -> AnimatedPhysicalModel (size=0x40)
    // 0x8600e8: ldur            x2, [fp, #-0x10]
    // 0x8600ec: StoreField: r0->field_17 = r2
    //     0x8600ec: stur            w2, [x0, #0x17]
    // 0x8600f0: r1 = Instance_BoxShape
    //     0x8600f0: add             x1, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x8600f4: ldr             x1, [x1, #0xe68]
    // 0x8600f8: StoreField: r0->field_1b = r1
    //     0x8600f8: stur            w1, [x0, #0x1b]
    // 0x8600fc: ldur            x1, [fp, #-8]
    // 0x860100: StoreField: r0->field_1f = r1
    //     0x860100: stur            w1, [x0, #0x1f]
    // 0x860104: r1 = Instance_BorderRadius
    //     0x860104: add             x1, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x860108: ldr             x1, [x1, #0x2c0]
    // 0x86010c: StoreField: r0->field_23 = r1
    //     0x86010c: stur            w1, [x0, #0x23]
    // 0x860110: ldur            d0, [fp, #-0x50]
    // 0x860114: StoreField: r0->field_27 = d0
    //     0x860114: stur            d0, [x0, #0x27]
    // 0x860118: ldur            x1, [fp, #-0x30]
    // 0x86011c: StoreField: r0->field_2f = r1
    //     0x86011c: stur            w1, [x0, #0x2f]
    // 0x860120: r1 = false
    //     0x860120: add             x1, NULL, #0x30  ; false
    // 0x860124: StoreField: r0->field_33 = r1
    //     0x860124: stur            w1, [x0, #0x33]
    // 0x860128: ldur            x3, [fp, #-0x18]
    // 0x86012c: StoreField: r0->field_37 = r3
    //     0x86012c: stur            w3, [x0, #0x37]
    // 0x860130: r4 = true
    //     0x860130: add             x4, NULL, #0x20  ; true
    // 0x860134: StoreField: r0->field_3b = r4
    //     0x860134: stur            w4, [x0, #0x3b]
    // 0x860138: r5 = Instance_Cubic
    //     0x860138: add             x5, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x86013c: ldr             x5, [x5, #0x2c8]
    // 0x860140: StoreField: r0->field_b = r5
    //     0x860140: stur            w5, [x0, #0xb]
    // 0x860144: ldur            x1, [fp, #-0x28]
    // 0x860148: StoreField: r0->field_f = r1
    //     0x860148: stur            w1, [x0, #0xf]
    // 0x86014c: LeaveFrame
    //     0x86014c: mov             SP, fp
    //     0x860150: ldp             fp, lr, [SP], #0x10
    // 0x860154: ret
    //     0x860154: ret             
    // 0x860158: mov             x2, x1
    // 0x86015c: ldr             x1, [fp, #0x18]
    // 0x860160: ldur            x0, [fp, #-0x20]
    // 0x860164: ldur            x3, [fp, #-0x18]
    // 0x860168: r4 = true
    //     0x860168: add             x4, NULL, #0x20  ; true
    // 0x86016c: r5 = Instance_Cubic
    //     0x86016c: add             x5, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x860170: ldr             x5, [x5, #0x2c8]
    // 0x860174: b               #0x8601b4
    // 0x860178: mov             x2, x1
    // 0x86017c: ldr             x1, [fp, #0x18]
    // 0x860180: ldur            x0, [fp, #-0x20]
    // 0x860184: ldur            x3, [fp, #-0x18]
    // 0x860188: r4 = true
    //     0x860188: add             x4, NULL, #0x20  ; true
    // 0x86018c: r5 = Instance_Cubic
    //     0x86018c: add             x5, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x860190: ldr             x5, [x5, #0x2c8]
    // 0x860194: b               #0x8601b4
    // 0x860198: mov             x2, x1
    // 0x86019c: ldr             x1, [fp, #0x18]
    // 0x8601a0: ldur            x0, [fp, #-0x20]
    // 0x8601a4: ldur            x3, [fp, #-0x18]
    // 0x8601a8: r4 = true
    //     0x8601a8: add             x4, NULL, #0x20  ; true
    // 0x8601ac: r5 = Instance_Cubic
    //     0x8601ac: add             x5, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x8601b0: ldr             x5, [x5, #0x2c8]
    // 0x8601b4: SaveReg r1
    //     0x8601b4: str             x1, [SP, #-8]!
    // 0x8601b8: r0 = _getShape()
    //     0x8601b8: bl              #0x860484  ; [package:flutter/src/material/material.dart] _MaterialState::_getShape
    // 0x8601bc: add             SP, SP, #8
    // 0x8601c0: mov             x1, x0
    // 0x8601c4: ldr             x0, [fp, #0x18]
    // 0x8601c8: stur            x1, [fp, #-0x38]
    // 0x8601cc: LoadField: r2 = r0->field_b
    //     0x8601cc: ldur            w2, [x0, #0xb]
    // 0x8601d0: DecompressPointer r2
    //     0x8601d0: add             x2, x2, HEAP, lsl #32
    // 0x8601d4: cmp             w2, NULL
    // 0x8601d8: b.eq            #0x8602ec
    // 0x8601dc: LoadField: r0 = r2->field_f
    //     0x8601dc: ldur            w0, [x2, #0xf]
    // 0x8601e0: DecompressPointer r0
    //     0x8601e0: add             x0, x0, HEAP, lsl #32
    // 0x8601e4: r16 = Instance_MaterialType
    //     0x8601e4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x8601e8: ldr             x16, [x16, #0x2a8]
    // 0x8601ec: cmp             w0, w16
    // 0x8601f0: b.ne            #0x860220
    // 0x8601f4: LoadField: r0 = r2->field_33
    //     0x8601f4: ldur            w0, [x2, #0x33]
    // 0x8601f8: DecompressPointer r0
    //     0x8601f8: add             x0, x0, HEAP, lsl #32
    // 0x8601fc: ldur            x16, [fp, #-0x10]
    // 0x860200: stp             x16, x0, [SP, #-0x10]!
    // 0x860204: ldr             x16, [fp, #0x10]
    // 0x860208: stp             x1, x16, [SP, #-0x10]!
    // 0x86020c: r0 = _transparentInterior()
    //     0x86020c: bl              #0x860324  ; [package:flutter/src/material/material.dart] _MaterialState::_transparentInterior
    // 0x860210: add             SP, SP, #0x20
    // 0x860214: LeaveFrame
    //     0x860214: mov             SP, fp
    //     0x860218: ldp             fp, lr, [SP], #0x10
    // 0x86021c: ret
    //     0x86021c: ret             
    // 0x860220: ldur            x0, [fp, #-0x20]
    // 0x860224: ldur            x4, [fp, #-0x18]
    // 0x860228: ldur            x3, [fp, #-0x10]
    // 0x86022c: LoadField: r5 = r2->field_37
    //     0x86022c: ldur            w5, [x2, #0x37]
    // 0x860230: DecompressPointer r5
    //     0x860230: add             x5, x5, HEAP, lsl #32
    // 0x860234: stur            x5, [fp, #-0x30]
    // 0x860238: LoadField: r6 = r2->field_33
    //     0x860238: ldur            w6, [x2, #0x33]
    // 0x86023c: DecompressPointer r6
    //     0x86023c: add             x6, x6, HEAP, lsl #32
    // 0x860240: stur            x6, [fp, #-0x28]
    // 0x860244: LoadField: d0 = r2->field_13
    //     0x860244: ldur            d0, [x2, #0x13]
    // 0x860248: stur            d0, [fp, #-0x50]
    // 0x86024c: cmp             w0, NULL
    // 0x860250: b.eq            #0x8602f0
    // 0x860254: LoadField: r7 = r2->field_23
    //     0x860254: ldur            w7, [x2, #0x23]
    // 0x860258: DecompressPointer r7
    //     0x860258: add             x7, x7, HEAP, lsl #32
    // 0x86025c: stur            x7, [fp, #-8]
    // 0x860260: r0 = _MaterialInterior()
    //     0x860260: bl              #0x8602f4  ; Allocate_MaterialInteriorStub -> _MaterialInterior (size=0x3c)
    // 0x860264: ldur            x1, [fp, #-0x10]
    // 0x860268: StoreField: r0->field_17 = r1
    //     0x860268: stur            w1, [x0, #0x17]
    // 0x86026c: ldur            x1, [fp, #-0x38]
    // 0x860270: StoreField: r0->field_1b = r1
    //     0x860270: stur            w1, [x0, #0x1b]
    // 0x860274: r1 = true
    //     0x860274: add             x1, NULL, #0x20  ; true
    // 0x860278: StoreField: r0->field_1f = r1
    //     0x860278: stur            w1, [x0, #0x1f]
    // 0x86027c: ldur            x1, [fp, #-0x28]
    // 0x860280: StoreField: r0->field_23 = r1
    //     0x860280: stur            w1, [x0, #0x23]
    // 0x860284: ldur            d0, [fp, #-0x50]
    // 0x860288: StoreField: r0->field_27 = d0
    //     0x860288: stur            d0, [x0, #0x27]
    // 0x86028c: ldur            x1, [fp, #-0x20]
    // 0x860290: StoreField: r0->field_2f = r1
    //     0x860290: stur            w1, [x0, #0x2f]
    // 0x860294: ldur            x1, [fp, #-0x18]
    // 0x860298: StoreField: r0->field_33 = r1
    //     0x860298: stur            w1, [x0, #0x33]
    // 0x86029c: ldur            x1, [fp, #-8]
    // 0x8602a0: StoreField: r0->field_37 = r1
    //     0x8602a0: stur            w1, [x0, #0x37]
    // 0x8602a4: r1 = Instance_Cubic
    //     0x8602a4: add             x1, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x8602a8: ldr             x1, [x1, #0x2c8]
    // 0x8602ac: StoreField: r0->field_b = r1
    //     0x8602ac: stur            w1, [x0, #0xb]
    // 0x8602b0: ldur            x1, [fp, #-0x30]
    // 0x8602b4: StoreField: r0->field_f = r1
    //     0x8602b4: stur            w1, [x0, #0xf]
    // 0x8602b8: LeaveFrame
    //     0x8602b8: mov             SP, fp
    //     0x8602bc: ldp             fp, lr, [SP], #0x10
    // 0x8602c0: ret
    //     0x8602c0: ret             
    // 0x8602c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8602c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8602c8: b               #0x85fd84
    // 0x8602cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8602e8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8602ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8602ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8602f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8602f0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  static _ _transparentInterior(/* No info */) {
    // ** addr: 0x860324, size: 0xa4
    // 0x860324: EnterFrame
    //     0x860324: stp             fp, lr, [SP, #-0x10]!
    //     0x860328: mov             fp, SP
    // 0x86032c: AllocStack(0x18)
    //     0x86032c: sub             SP, SP, #0x18
    // 0x860330: CheckStackOverflow
    //     0x860330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860334: cmp             SP, x16
    //     0x860338: b.ls            #0x8603c0
    // 0x86033c: r0 = _ShapeBorderPaint()
    //     0x86033c: bl              #0x860478  ; Allocate_ShapeBorderPaintStub -> _ShapeBorderPaint (size=0x18)
    // 0x860340: mov             x1, x0
    // 0x860344: ldr             x0, [fp, #0x20]
    // 0x860348: stur            x1, [fp, #-8]
    // 0x86034c: StoreField: r1->field_b = r0
    //     0x86034c: stur            w0, [x1, #0xb]
    // 0x860350: ldr             x0, [fp, #0x10]
    // 0x860354: StoreField: r1->field_f = r0
    //     0x860354: stur            w0, [x1, #0xf]
    // 0x860358: r2 = true
    //     0x860358: add             x2, NULL, #0x20  ; true
    // 0x86035c: StoreField: r1->field_13 = r2
    //     0x86035c: stur            w2, [x1, #0x13]
    // 0x860360: ldr             x16, [fp, #0x18]
    // 0x860364: SaveReg r16
    //     0x860364: str             x16, [SP, #-8]!
    // 0x860368: r0 = maybeOf()
    //     0x860368: bl              #0x6c2c58  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0x86036c: add             SP, SP, #8
    // 0x860370: r1 = <Path>
    //     0x860370: add             x1, PP, #0x15, lsl #12  ; [pp+0x152e8] TypeArguments: <Path>
    //     0x860374: ldr             x1, [x1, #0x2e8]
    // 0x860378: stur            x0, [fp, #-0x10]
    // 0x86037c: r0 = ShapeBorderClipper()
    //     0x86037c: bl              #0x8603d4  ; AllocateShapeBorderClipperStub -> ShapeBorderClipper (size=0x18)
    // 0x860380: mov             x1, x0
    // 0x860384: ldr             x0, [fp, #0x10]
    // 0x860388: stur            x1, [fp, #-0x18]
    // 0x86038c: StoreField: r1->field_f = r0
    //     0x86038c: stur            w0, [x1, #0xf]
    // 0x860390: ldur            x0, [fp, #-0x10]
    // 0x860394: StoreField: r1->field_13 = r0
    //     0x860394: stur            w0, [x1, #0x13]
    // 0x860398: r0 = ClipPath()
    //     0x860398: bl              #0x8603c8  ; AllocateClipPathStub -> ClipPath (size=0x18)
    // 0x86039c: ldur            x1, [fp, #-0x18]
    // 0x8603a0: StoreField: r0->field_f = r1
    //     0x8603a0: stur            w1, [x0, #0xf]
    // 0x8603a4: ldr             x1, [fp, #0x28]
    // 0x8603a8: StoreField: r0->field_13 = r1
    //     0x8603a8: stur            w1, [x0, #0x13]
    // 0x8603ac: ldur            x1, [fp, #-8]
    // 0x8603b0: StoreField: r0->field_b = r1
    //     0x8603b0: stur            w1, [x0, #0xb]
    // 0x8603b4: LeaveFrame
    //     0x8603b4: mov             SP, fp
    //     0x8603b8: ldp             fp, lr, [SP], #0x10
    // 0x8603bc: ret
    //     0x8603bc: ret             
    // 0x8603c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8603c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8603c4: b               #0x86033c
  }
  _ _getShape(/* No info */) {
    // ** addr: 0x860484, size: 0x144
    // 0x860484: EnterFrame
    //     0x860484: stp             fp, lr, [SP, #-0x10]!
    //     0x860488: mov             fp, SP
    // 0x86048c: AllocStack(0x8)
    //     0x86048c: sub             SP, SP, #8
    // 0x860490: CheckStackOverflow
    //     0x860490: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860494: cmp             SP, x16
    //     0x860498: b.ls            #0x8605b8
    // 0x86049c: ldr             x0, [fp, #0x10]
    // 0x8604a0: LoadField: r1 = r0->field_b
    //     0x8604a0: ldur            w1, [x0, #0xb]
    // 0x8604a4: DecompressPointer r1
    //     0x8604a4: add             x1, x1, HEAP, lsl #32
    // 0x8604a8: cmp             w1, NULL
    // 0x8604ac: b.eq            #0x8605c0
    // 0x8604b0: LoadField: r0 = r1->field_2b
    //     0x8604b0: ldur            w0, [x1, #0x2b]
    // 0x8604b4: DecompressPointer r0
    //     0x8604b4: add             x0, x0, HEAP, lsl #32
    // 0x8604b8: cmp             w0, NULL
    // 0x8604bc: b.eq            #0x8604cc
    // 0x8604c0: LeaveFrame
    //     0x8604c0: mov             SP, fp
    //     0x8604c4: ldp             fp, lr, [SP], #0x10
    // 0x8604c8: ret
    //     0x8604c8: ret             
    // 0x8604cc: LoadField: r0 = r1->field_3b
    //     0x8604cc: ldur            w0, [x1, #0x3b]
    // 0x8604d0: DecompressPointer r0
    //     0x8604d0: add             x0, x0, HEAP, lsl #32
    // 0x8604d4: stur            x0, [fp, #-8]
    // 0x8604d8: cmp             w0, NULL
    // 0x8604dc: b.eq            #0x86050c
    // 0x8604e0: r0 = RoundedRectangleBorder()
    //     0x8604e0: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8604e4: mov             x1, x0
    // 0x8604e8: ldur            x0, [fp, #-8]
    // 0x8604ec: StoreField: r1->field_b = r0
    //     0x8604ec: stur            w0, [x1, #0xb]
    // 0x8604f0: r2 = Instance_BorderSide
    //     0x8604f0: add             x2, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x8604f4: ldr             x2, [x2, #0x2f0]
    // 0x8604f8: StoreField: r1->field_7 = r2
    //     0x8604f8: stur            w2, [x1, #7]
    // 0x8604fc: mov             x0, x1
    // 0x860500: LeaveFrame
    //     0x860500: mov             SP, fp
    //     0x860504: ldp             fp, lr, [SP], #0x10
    // 0x860508: ret
    //     0x860508: ret             
    // 0x86050c: r2 = Instance_BorderSide
    //     0x86050c: add             x2, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x860510: ldr             x2, [x2, #0x2f0]
    // 0x860514: LoadField: r3 = r1->field_f
    //     0x860514: ldur            w3, [x1, #0xf]
    // 0x860518: DecompressPointer r3
    //     0x860518: add             x3, x3, HEAP, lsl #32
    // 0x86051c: LoadField: r1 = r3->field_7
    //     0x86051c: ldur            x1, [x3, #7]
    // 0x860520: cmp             x1, #2
    // 0x860524: b.gt            #0x860550
    // 0x860528: cmp             x1, #1
    // 0x86052c: b.gt            #0x86053c
    // 0x860530: cmp             x1, #0
    // 0x860534: b.gt            #0x860558
    // 0x860538: b               #0x8605a4
    // 0x86053c: r0 = Instance_CircleBorder
    //     0x86053c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe358] Obj!CircleBorder@b38441
    //     0x860540: ldr             x0, [x0, #0x358]
    // 0x860544: LeaveFrame
    //     0x860544: mov             SP, fp
    //     0x860548: ldp             fp, lr, [SP], #0x10
    // 0x86054c: ret
    //     0x86054c: ret             
    // 0x860550: cmp             x1, #3
    // 0x860554: b.gt            #0x8605a4
    // 0x860558: cmp             w0, NULL
    // 0x86055c: b.ne            #0x86057c
    // 0x860560: r16 = _ConstMap len:5
    //     0x860560: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f8] Map<MaterialType, BorderRadius?>(5)
    //     0x860564: ldr             x16, [x16, #0x2f8]
    // 0x860568: stp             x3, x16, [SP, #-0x10]!
    // 0x86056c: r0 = []()
    //     0x86056c: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x860570: add             SP, SP, #0x10
    // 0x860574: cmp             w0, NULL
    // 0x860578: b.eq            #0x8605c4
    // 0x86057c: stur            x0, [fp, #-8]
    // 0x860580: r0 = RoundedRectangleBorder()
    //     0x860580: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x860584: ldur            x1, [fp, #-8]
    // 0x860588: StoreField: r0->field_b = r1
    //     0x860588: stur            w1, [x0, #0xb]
    // 0x86058c: r1 = Instance_BorderSide
    //     0x86058c: add             x1, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x860590: ldr             x1, [x1, #0x2f0]
    // 0x860594: StoreField: r0->field_7 = r1
    //     0x860594: stur            w1, [x0, #7]
    // 0x860598: LeaveFrame
    //     0x860598: mov             SP, fp
    //     0x86059c: ldp             fp, lr, [SP], #0x10
    // 0x8605a0: ret
    //     0x8605a0: ret             
    // 0x8605a4: r0 = Instance_RoundedRectangleBorder
    //     0x8605a4: add             x0, PP, #0x15, lsl #12  ; [pp+0x15300] Obj!RoundedRectangleBorder@b383d1
    //     0x8605a8: ldr             x0, [x0, #0x300]
    // 0x8605ac: LeaveFrame
    //     0x8605ac: mov             SP, fp
    //     0x8605b0: ldp             fp, lr, [SP], #0x10
    // 0x8605b4: ret
    //     0x8605b4: ret             
    // 0x8605b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8605b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8605bc: b               #0x86049c
    // 0x8605c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8605c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8605c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8605c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getBackgroundColor(/* No info */) {
    // ** addr: 0x860a94, size: 0xac
    // 0x860a94: EnterFrame
    //     0x860a94: stp             fp, lr, [SP, #-0x10]!
    //     0x860a98: mov             fp, SP
    // 0x860a9c: CheckStackOverflow
    //     0x860a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860aa0: cmp             SP, x16
    //     0x860aa4: b.ls            #0x860b34
    // 0x860aa8: ldr             x16, [fp, #0x10]
    // 0x860aac: SaveReg r16
    //     0x860aac: str             x16, [SP, #-8]!
    // 0x860ab0: r0 = of()
    //     0x860ab0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x860ab4: add             SP, SP, #8
    // 0x860ab8: ldr             x1, [fp, #0x18]
    // 0x860abc: LoadField: r2 = r1->field_b
    //     0x860abc: ldur            w2, [x1, #0xb]
    // 0x860ac0: DecompressPointer r2
    //     0x860ac0: add             x2, x2, HEAP, lsl #32
    // 0x860ac4: cmp             w2, NULL
    // 0x860ac8: b.eq            #0x860b3c
    // 0x860acc: LoadField: r1 = r2->field_1b
    //     0x860acc: ldur            w1, [x2, #0x1b]
    // 0x860ad0: DecompressPointer r1
    //     0x860ad0: add             x1, x1, HEAP, lsl #32
    // 0x860ad4: cmp             w1, NULL
    // 0x860ad8: b.ne            #0x860b24
    // 0x860adc: LoadField: r3 = r2->field_f
    //     0x860adc: ldur            w3, [x2, #0xf]
    // 0x860ae0: DecompressPointer r3
    //     0x860ae0: add             x3, x3, HEAP, lsl #32
    // 0x860ae4: LoadField: r2 = r3->field_7
    //     0x860ae4: ldur            x2, [x3, #7]
    // 0x860ae8: cmp             x2, #2
    // 0x860aec: b.gt            #0x860b18
    // 0x860af0: cmp             x2, #1
    // 0x860af4: b.gt            #0x860b18
    // 0x860af8: cmp             x2, #0
    // 0x860afc: b.gt            #0x860b0c
    // 0x860b00: LoadField: r2 = r0->field_37
    //     0x860b00: ldur            w2, [x0, #0x37]
    // 0x860b04: DecompressPointer r2
    //     0x860b04: add             x2, x2, HEAP, lsl #32
    // 0x860b08: b               #0x860b1c
    // 0x860b0c: LoadField: r2 = r0->field_3b
    //     0x860b0c: ldur            w2, [x0, #0x3b]
    // 0x860b10: DecompressPointer r2
    //     0x860b10: add             x2, x2, HEAP, lsl #32
    // 0x860b14: b               #0x860b1c
    // 0x860b18: mov             x2, x1
    // 0x860b1c: mov             x0, x2
    // 0x860b20: b               #0x860b28
    // 0x860b24: mov             x0, x1
    // 0x860b28: LeaveFrame
    //     0x860b28: mov             SP, fp
    //     0x860b2c: ldp             fp, lr, [SP], #0x10
    // 0x860b30: ret
    //     0x860b30: ret             
    // 0x860b34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860b34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x860b38: b               #0x860aa8
    // 0x860b3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860b3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, LayoutChangedNotification) {
    // ** addr: 0x860b40, size: 0xc4
    // 0x860b40: EnterFrame
    //     0x860b40: stp             fp, lr, [SP, #-0x10]!
    //     0x860b44: mov             fp, SP
    // 0x860b48: AllocStack(0x8)
    //     0x860b48: sub             SP, SP, #8
    // 0x860b4c: SetupParameters()
    //     0x860b4c: ldr             x0, [fp, #0x18]
    //     0x860b50: ldur            w1, [x0, #0x17]
    //     0x860b54: add             x1, x1, HEAP, lsl #32
    // 0x860b58: CheckStackOverflow
    //     0x860b58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860b5c: cmp             SP, x16
    //     0x860b60: b.ls            #0x860bf4
    // 0x860b64: LoadField: r0 = r1->field_f
    //     0x860b64: ldur            w0, [x1, #0xf]
    // 0x860b68: DecompressPointer r0
    //     0x860b68: add             x0, x0, HEAP, lsl #32
    // 0x860b6c: LoadField: r1 = r0->field_1b
    //     0x860b6c: ldur            w1, [x0, #0x1b]
    // 0x860b70: DecompressPointer r1
    //     0x860b70: add             x1, x1, HEAP, lsl #32
    // 0x860b74: SaveReg r1
    //     0x860b74: str             x1, [SP, #-8]!
    // 0x860b78: r0 = _currentElement()
    //     0x860b78: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x860b7c: add             SP, SP, #8
    // 0x860b80: cmp             w0, NULL
    // 0x860b84: b.eq            #0x860bfc
    // 0x860b88: SaveReg r0
    //     0x860b88: str             x0, [SP, #-8]!
    // 0x860b8c: r0 = findRenderObject()
    //     0x860b8c: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x860b90: add             SP, SP, #8
    // 0x860b94: mov             x3, x0
    // 0x860b98: stur            x3, [fp, #-8]
    // 0x860b9c: cmp             w3, NULL
    // 0x860ba0: b.eq            #0x860c00
    // 0x860ba4: mov             x0, x3
    // 0x860ba8: r2 = Null
    //     0x860ba8: mov             x2, NULL
    // 0x860bac: r1 = Null
    //     0x860bac: mov             x1, NULL
    // 0x860bb0: r4 = LoadClassIdInstr(r0)
    //     0x860bb0: ldur            x4, [x0, #-1]
    //     0x860bb4: ubfx            x4, x4, #0xc, #0x14
    // 0x860bb8: cmp             x4, #0x9db
    // 0x860bbc: b.eq            #0x860bd4
    // 0x860bc0: r8 = _RenderInkFeatures
    //     0x860bc0: add             x8, PP, #0x15, lsl #12  ; [pp+0x152d0] Type: _RenderInkFeatures
    //     0x860bc4: ldr             x8, [x8, #0x2d0]
    // 0x860bc8: r3 = Null
    //     0x860bc8: add             x3, PP, #0x15, lsl #12  ; [pp+0x152d8] Null
    //     0x860bcc: ldr             x3, [x3, #0x2d8]
    // 0x860bd0: r0 = DefaultTypeTest()
    //     0x860bd0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x860bd4: ldur            x16, [fp, #-8]
    // 0x860bd8: SaveReg r16
    //     0x860bd8: str             x16, [SP, #-8]!
    // 0x860bdc: r0 = _didChangeLayout()
    //     0x860bdc: bl              #0x860c04  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::_didChangeLayout
    // 0x860be0: add             SP, SP, #8
    // 0x860be4: r0 = false
    //     0x860be4: add             x0, NULL, #0x30  ; false
    // 0x860be8: LeaveFrame
    //     0x860be8: mov             SP, fp
    //     0x860bec: ldp             fp, lr, [SP], #0x10
    // 0x860bf0: ret
    //     0x860bf0: ret             
    // 0x860bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x860bf8: b               #0x860b64
    // 0x860bfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860bfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x860c00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x860c00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3672, size: 0x1c, field offset: 0x10
//   const constructor, 
class _InkFeatures extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c2908, size: 0x88
    // 0x6c2908: EnterFrame
    //     0x6c2908: stp             fp, lr, [SP, #-0x10]!
    //     0x6c290c: mov             fp, SP
    // 0x6c2910: ldr             x0, [fp, #0x10]
    // 0x6c2914: r2 = Null
    //     0x6c2914: mov             x2, NULL
    // 0x6c2918: r1 = Null
    //     0x6c2918: mov             x1, NULL
    // 0x6c291c: r4 = 59
    //     0x6c291c: mov             x4, #0x3b
    // 0x6c2920: branchIfSmi(r0, 0x6c292c)
    //     0x6c2920: tbz             w0, #0, #0x6c292c
    // 0x6c2924: r4 = LoadClassIdInstr(r0)
    //     0x6c2924: ldur            x4, [x0, #-1]
    //     0x6c2928: ubfx            x4, x4, #0xc, #0x14
    // 0x6c292c: cmp             x4, #0x9db
    // 0x6c2930: b.eq            #0x6c2948
    // 0x6c2934: r8 = _RenderInkFeatures
    //     0x6c2934: add             x8, PP, #0x15, lsl #12  ; [pp+0x152d0] Type: _RenderInkFeatures
    //     0x6c2938: ldr             x8, [x8, #0x2d0]
    // 0x6c293c: r3 = Null
    //     0x6c293c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d0c8] Null
    //     0x6c2940: ldr             x3, [x3, #0xc8]
    // 0x6c2944: r0 = DefaultTypeTest()
    //     0x6c2944: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c2948: ldr             x1, [fp, #0x20]
    // 0x6c294c: LoadField: r0 = r1->field_f
    //     0x6c294c: ldur            w0, [x1, #0xf]
    // 0x6c2950: DecompressPointer r0
    //     0x6c2950: add             x0, x0, HEAP, lsl #32
    // 0x6c2954: ldr             x2, [fp, #0x10]
    // 0x6c2958: StoreField: r2->field_67 = r0
    //     0x6c2958: stur            w0, [x2, #0x67]
    //     0x6c295c: ldurb           w16, [x2, #-1]
    //     0x6c2960: ldurb           w17, [x0, #-1]
    //     0x6c2964: and             x16, x17, x16, lsr #2
    //     0x6c2968: tst             x16, HEAP, lsr #32
    //     0x6c296c: b.eq            #0x6c2974
    //     0x6c2970: bl              #0xd6828c
    // 0x6c2974: LoadField: r3 = r1->field_17
    //     0x6c2974: ldur            w3, [x1, #0x17]
    // 0x6c2978: DecompressPointer r3
    //     0x6c2978: add             x3, x3, HEAP, lsl #32
    // 0x6c297c: StoreField: r2->field_6b = r3
    //     0x6c297c: stur            w3, [x2, #0x6b]
    // 0x6c2980: r0 = Null
    //     0x6c2980: mov             x0, NULL
    // 0x6c2984: LeaveFrame
    //     0x6c2984: mov             SP, fp
    //     0x6c2988: ldp             fp, lr, [SP], #0x10
    // 0x6c298c: ret
    //     0x6c298c: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ea328, size: 0x98
    // 0x6ea328: EnterFrame
    //     0x6ea328: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea32c: mov             fp, SP
    // 0x6ea330: AllocStack(0x20)
    //     0x6ea330: sub             SP, SP, #0x20
    // 0x6ea334: CheckStackOverflow
    //     0x6ea334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea338: cmp             SP, x16
    //     0x6ea33c: b.ls            #0x6ea3b8
    // 0x6ea340: ldr             x0, [fp, #0x18]
    // 0x6ea344: LoadField: r1 = r0->field_f
    //     0x6ea344: ldur            w1, [x0, #0xf]
    // 0x6ea348: DecompressPointer r1
    //     0x6ea348: add             x1, x1, HEAP, lsl #32
    // 0x6ea34c: stur            x1, [fp, #-0x18]
    // 0x6ea350: LoadField: r2 = r0->field_17
    //     0x6ea350: ldur            w2, [x0, #0x17]
    // 0x6ea354: DecompressPointer r2
    //     0x6ea354: add             x2, x2, HEAP, lsl #32
    // 0x6ea358: stur            x2, [fp, #-0x10]
    // 0x6ea35c: LoadField: r3 = r0->field_13
    //     0x6ea35c: ldur            w3, [x0, #0x13]
    // 0x6ea360: DecompressPointer r3
    //     0x6ea360: add             x3, x3, HEAP, lsl #32
    // 0x6ea364: stur            x3, [fp, #-8]
    // 0x6ea368: r0 = _RenderInkFeatures()
    //     0x6ea368: bl              #0x6ea3c0  ; Allocate_RenderInkFeaturesStub -> _RenderInkFeatures (size=0x74)
    // 0x6ea36c: mov             x1, x0
    // 0x6ea370: ldur            x0, [fp, #-8]
    // 0x6ea374: stur            x1, [fp, #-0x20]
    // 0x6ea378: StoreField: r1->field_63 = r0
    //     0x6ea378: stur            w0, [x1, #0x63]
    // 0x6ea37c: ldur            x0, [fp, #-0x10]
    // 0x6ea380: StoreField: r1->field_6b = r0
    //     0x6ea380: stur            w0, [x1, #0x6b]
    // 0x6ea384: ldur            x0, [fp, #-0x18]
    // 0x6ea388: StoreField: r1->field_67 = r0
    //     0x6ea388: stur            w0, [x1, #0x67]
    // 0x6ea38c: SaveReg r1
    //     0x6ea38c: str             x1, [SP, #-8]!
    // 0x6ea390: r0 = RenderObject()
    //     0x6ea390: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea394: add             SP, SP, #8
    // 0x6ea398: ldur            x16, [fp, #-0x20]
    // 0x6ea39c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea3a0: r0 = child=()
    //     0x6ea3a0: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea3a4: add             SP, SP, #0x10
    // 0x6ea3a8: ldur            x0, [fp, #-0x20]
    // 0x6ea3ac: LeaveFrame
    //     0x6ea3ac: mov             SP, fp
    //     0x6ea3b0: ldp             fp, lr, [SP], #0x10
    // 0x6ea3b4: ret
    //     0x6ea3b4: ret             
    // 0x6ea3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea3b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea3bc: b               #0x6ea340
  }
}

// class id: 3849, size: 0x18, field offset: 0xc
//   const constructor, 
class _ShapeBorderPaint extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb2310c, size: 0xa4
    // 0xb2310c: EnterFrame
    //     0xb2310c: stp             fp, lr, [SP, #-0x10]!
    //     0xb23110: mov             fp, SP
    // 0xb23114: AllocStack(0x18)
    //     0xb23114: sub             SP, SP, #0x18
    // 0xb23118: CheckStackOverflow
    //     0xb23118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2311c: cmp             SP, x16
    //     0xb23120: b.ls            #0xb231a8
    // 0xb23124: ldr             x0, [fp, #0x18]
    // 0xb23128: LoadField: r1 = r0->field_f
    //     0xb23128: ldur            w1, [x0, #0xf]
    // 0xb2312c: DecompressPointer r1
    //     0xb2312c: add             x1, x1, HEAP, lsl #32
    // 0xb23130: stur            x1, [fp, #-8]
    // 0xb23134: ldr             x16, [fp, #0x10]
    // 0xb23138: SaveReg r16
    //     0xb23138: str             x16, [SP, #-8]!
    // 0xb2313c: r0 = maybeOf()
    //     0xb2313c: bl              #0x6c2c58  ; [package:flutter/src/widgets/basic.dart] Directionality::maybeOf
    // 0xb23140: add             SP, SP, #8
    // 0xb23144: stur            x0, [fp, #-0x10]
    // 0xb23148: r0 = _ShapeBorderPainter()
    //     0xb23148: bl              #0xb231b0  ; Allocate_ShapeBorderPainterStub -> _ShapeBorderPainter (size=0x14)
    // 0xb2314c: mov             x1, x0
    // 0xb23150: ldur            x0, [fp, #-8]
    // 0xb23154: stur            x1, [fp, #-0x18]
    // 0xb23158: StoreField: r1->field_b = r0
    //     0xb23158: stur            w0, [x1, #0xb]
    // 0xb2315c: ldur            x0, [fp, #-0x10]
    // 0xb23160: StoreField: r1->field_f = r0
    //     0xb23160: stur            w0, [x1, #0xf]
    // 0xb23164: ldr             x0, [fp, #0x18]
    // 0xb23168: LoadField: r2 = r0->field_b
    //     0xb23168: ldur            w2, [x0, #0xb]
    // 0xb2316c: DecompressPointer r2
    //     0xb2316c: add             x2, x2, HEAP, lsl #32
    // 0xb23170: stur            x2, [fp, #-8]
    // 0xb23174: r0 = CustomPaint()
    //     0xb23174: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xb23178: ldur            x1, [fp, #-0x18]
    // 0xb2317c: StoreField: r0->field_13 = r1
    //     0xb2317c: stur            w1, [x0, #0x13]
    // 0xb23180: r1 = Instance_Size
    //     0xb23180: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xb23184: StoreField: r0->field_17 = r1
    //     0xb23184: stur            w1, [x0, #0x17]
    // 0xb23188: r1 = false
    //     0xb23188: add             x1, NULL, #0x30  ; false
    // 0xb2318c: StoreField: r0->field_1b = r1
    //     0xb2318c: stur            w1, [x0, #0x1b]
    // 0xb23190: StoreField: r0->field_1f = r1
    //     0xb23190: stur            w1, [x0, #0x1f]
    // 0xb23194: ldur            x1, [fp, #-8]
    // 0xb23198: StoreField: r0->field_b = r1
    //     0xb23198: stur            w1, [x0, #0xb]
    // 0xb2319c: LeaveFrame
    //     0xb2319c: mov             SP, fp
    //     0xb231a0: ldp             fp, lr, [SP], #0x10
    // 0xb231a4: ret
    //     0xb231a4: ret             
    // 0xb231a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb231a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb231ac: b               #0xb23124
  }
}

// class id: 4146, size: 0x3c, field offset: 0x18
//   const constructor, 
class _MaterialInterior extends ImplicitlyAnimatedWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa409d4, size: 0x2c
    // 0xa409d4: EnterFrame
    //     0xa409d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa409d8: mov             fp, SP
    // 0xa409dc: r1 = <_MaterialInterior>
    //     0xa409dc: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0c0] TypeArguments: <_MaterialInterior>
    //     0xa409e0: ldr             x1, [x1, #0xc0]
    // 0xa409e4: r0 = _MaterialInteriorState()
    //     0xa409e4: bl              #0xa40a00  ; Allocate_MaterialInteriorStateStub -> _MaterialInteriorState (size=0x34)
    // 0xa409e8: r1 = Sentinel
    //     0xa409e8: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa409ec: StoreField: r0->field_1b = r1
    //     0xa409ec: stur            w1, [x0, #0x1b]
    // 0xa409f0: StoreField: r0->field_1f = r1
    //     0xa409f0: stur            w1, [x0, #0x1f]
    // 0xa409f4: LeaveFrame
    //     0xa409f4: mov             SP, fp
    //     0xa409f8: ldp             fp, lr, [SP], #0x10
    // 0xa409fc: ret
    //     0xa409fc: ret             
  }
}

// class id: 4147, size: 0x40, field offset: 0xc
//   const constructor, 
class Material extends StatefulWidget {

  static _ of(/* No info */) {
    // ** addr: 0x7b2858, size: 0x44
    // 0x7b2858: EnterFrame
    //     0x7b2858: stp             fp, lr, [SP, #-0x10]!
    //     0x7b285c: mov             fp, SP
    // 0x7b2860: CheckStackOverflow
    //     0x7b2860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2864: cmp             SP, x16
    //     0x7b2868: b.ls            #0x7b2890
    // 0x7b286c: ldr             x16, [fp, #0x10]
    // 0x7b2870: SaveReg r16
    //     0x7b2870: str             x16, [SP, #-8]!
    // 0x7b2874: r0 = maybeOf()
    //     0x7b2874: bl              #0x7b289c  ; [package:flutter/src/material/material.dart] Material::maybeOf
    // 0x7b2878: add             SP, SP, #8
    // 0x7b287c: cmp             w0, NULL
    // 0x7b2880: b.eq            #0x7b2898
    // 0x7b2884: LeaveFrame
    //     0x7b2884: mov             SP, fp
    //     0x7b2888: ldp             fp, lr, [SP], #0x10
    // 0x7b288c: ret
    //     0x7b288c: ret             
    // 0x7b2890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2890: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2894: b               #0x7b286c
    // 0x7b2898: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b2898: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ maybeOf(/* No info */) {
    // ** addr: 0x7b289c, size: 0x44
    // 0x7b289c: EnterFrame
    //     0x7b289c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b28a0: mov             fp, SP
    // 0x7b28a4: CheckStackOverflow
    //     0x7b28a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b28a8: cmp             SP, x16
    //     0x7b28ac: b.ls            #0x7b28d8
    // 0x7b28b0: r16 = <_RenderInkFeatures>
    //     0x7b28b0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2c0] TypeArguments: <_RenderInkFeatures>
    //     0x7b28b4: ldr             x16, [x16, #0x2c0]
    // 0x7b28b8: ldr             lr, [fp, #0x10]
    // 0x7b28bc: stp             lr, x16, [SP, #-0x10]!
    // 0x7b28c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x7b28c0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x7b28c4: r0 = findAncestorRenderObjectOfType()
    //     0x7b28c4: bl              #0x50919c  ; [package:flutter/src/widgets/framework.dart] Element::findAncestorRenderObjectOfType
    // 0x7b28c8: add             SP, SP, #0x10
    // 0x7b28cc: LeaveFrame
    //     0x7b28cc: mov             SP, fp
    //     0x7b28d0: ldp             fp, lr, [SP], #0x10
    // 0x7b28d4: ret
    //     0x7b28d4: ret             
    // 0x7b28d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b28d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b28dc: b               #0x7b28b0
  }
  _ createState(/* No info */) {
    // ** addr: 0xa40980, size: 0x48
    // 0xa40980: EnterFrame
    //     0xa40980: stp             fp, lr, [SP, #-0x10]!
    //     0xa40984: mov             fp, SP
    // 0xa40988: AllocStack(0x8)
    //     0xa40988: sub             SP, SP, #8
    // 0xa4098c: r1 = <State<StatefulWidget>>
    //     0xa4098c: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa40990: r0 = LabeledGlobalKey()
    //     0xa40990: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa40994: mov             x2, x0
    // 0xa40998: r0 = "ink renderer"
    //     0xa40998: add             x0, PP, #0xf, lsl #12  ; [pp+0xf1d8] "ink renderer"
    //     0xa4099c: ldr             x0, [x0, #0x1d8]
    // 0xa409a0: stur            x2, [fp, #-8]
    // 0xa409a4: StoreField: r2->field_b = r0
    //     0xa409a4: stur            w0, [x2, #0xb]
    // 0xa409a8: r1 = <Material>
    //     0xa409a8: add             x1, PP, #0xf, lsl #12  ; [pp+0xf1e0] TypeArguments: <Material>
    //     0xa409ac: ldr             x1, [x1, #0x1e0]
    // 0xa409b0: r0 = _MaterialState()
    //     0xa409b0: bl              #0xa409c8  ; Allocate_MaterialStateStub -> _MaterialState (size=0x20)
    // 0xa409b4: ldur            x1, [fp, #-8]
    // 0xa409b8: StoreField: r0->field_1b = r1
    //     0xa409b8: stur            w1, [x0, #0x1b]
    // 0xa409bc: LeaveFrame
    //     0xa409bc: mov             SP, fp
    //     0xa409c0: ldp             fp, lr, [SP], #0x10
    // 0xa409c4: ret
    //     0xa409c4: ret             
  }
}

// class id: 4267, size: 0x14, field offset: 0x14
class ShapeBorderTween extends Tween<ShapeBorder?> {

  _ lerp(/* No info */) {
    // ** addr: 0xbecca4, size: 0x50
    // 0xbecca4: EnterFrame
    //     0xbecca4: stp             fp, lr, [SP, #-0x10]!
    //     0xbecca8: mov             fp, SP
    // 0xbeccac: CheckStackOverflow
    //     0xbeccac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbeccb0: cmp             SP, x16
    //     0xbeccb4: b.ls            #0xbeccec
    // 0xbeccb8: ldr             x0, [fp, #0x18]
    // 0xbeccbc: LoadField: r1 = r0->field_b
    //     0xbeccbc: ldur            w1, [x0, #0xb]
    // 0xbeccc0: DecompressPointer r1
    //     0xbeccc0: add             x1, x1, HEAP, lsl #32
    // 0xbeccc4: LoadField: r2 = r0->field_f
    //     0xbeccc4: ldur            w2, [x0, #0xf]
    // 0xbeccc8: DecompressPointer r2
    //     0xbeccc8: add             x2, x2, HEAP, lsl #32
    // 0xbecccc: stp             x2, x1, [SP, #-0x10]!
    // 0xbeccd0: ldr             d0, [fp, #0x10]
    // 0xbeccd4: SaveReg d0
    //     0xbeccd4: str             d0, [SP, #-8]!
    // 0xbeccd8: r0 = lerp()
    //     0xbeccd8: bl              #0xbecbbc  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0xbeccdc: add             SP, SP, #0x18
    // 0xbecce0: LeaveFrame
    //     0xbecce0: mov             SP, fp
    //     0xbecce4: ldp             fp, lr, [SP], #0x10
    // 0xbecce8: ret
    //     0xbecce8: ret             
    // 0xbeccec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbeccec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbeccf0: b               #0xbeccb8
  }
}

// class id: 4376, size: 0x14, field offset: 0xc
class _ShapeBorderPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa6f114, size: 0x9c
    // 0xa6f114: EnterFrame
    //     0xa6f114: stp             fp, lr, [SP, #-0x10]!
    //     0xa6f118: mov             fp, SP
    // 0xa6f11c: AllocStack(0x8)
    //     0xa6f11c: sub             SP, SP, #8
    // 0xa6f120: CheckStackOverflow
    //     0xa6f120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6f124: cmp             SP, x16
    //     0xa6f128: b.ls            #0xa6f1a8
    // 0xa6f12c: ldr             x0, [fp, #0x20]
    // 0xa6f130: LoadField: r1 = r0->field_b
    //     0xa6f130: ldur            w1, [x0, #0xb]
    // 0xa6f134: DecompressPointer r1
    //     0xa6f134: add             x1, x1, HEAP, lsl #32
    // 0xa6f138: stur            x1, [fp, #-8]
    // 0xa6f13c: r16 = Instance_Offset
    //     0xa6f13c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa6f140: ldr             lr, [fp, #0x10]
    // 0xa6f144: stp             lr, x16, [SP, #-0x10]!
    // 0xa6f148: r0 = &()
    //     0xa6f148: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa6f14c: add             SP, SP, #0x10
    // 0xa6f150: mov             x1, x0
    // 0xa6f154: ldr             x0, [fp, #0x20]
    // 0xa6f158: LoadField: r2 = r0->field_f
    //     0xa6f158: ldur            w2, [x0, #0xf]
    // 0xa6f15c: DecompressPointer r2
    //     0xa6f15c: add             x2, x2, HEAP, lsl #32
    // 0xa6f160: ldur            x0, [fp, #-8]
    // 0xa6f164: r3 = LoadClassIdInstr(r0)
    //     0xa6f164: ldur            x3, [x0, #-1]
    //     0xa6f168: ubfx            x3, x3, #0xc, #0x14
    // 0xa6f16c: ldr             x16, [fp, #0x18]
    // 0xa6f170: stp             x16, x0, [SP, #-0x10]!
    // 0xa6f174: stp             x2, x1, [SP, #-0x10]!
    // 0xa6f178: mov             x0, x3
    // 0xa6f17c: r4 = const [0, 0x4, 0x4, 0x3, textDirection, 0x3, null]
    //     0xa6f17c: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e1e0] List(7) [0, 0x4, 0x4, 0x3, "textDirection", 0x3, Null]
    //     0xa6f180: ldr             x4, [x4, #0x1e0]
    // 0xa6f184: r0 = GDT[cid_x0 + 0x1abc]()
    //     0xa6f184: mov             x17, #0x1abc
    //     0xa6f188: add             lr, x0, x17
    //     0xa6f18c: ldr             lr, [x21, lr, lsl #3]
    //     0xa6f190: blr             lr
    // 0xa6f194: add             SP, SP, #0x20
    // 0xa6f198: r0 = Null
    //     0xa6f198: mov             x0, NULL
    // 0xa6f19c: LeaveFrame
    //     0xa6f19c: mov             SP, fp
    //     0xa6f1a0: ldp             fp, lr, [SP], #0x10
    // 0xa6f1a4: ret
    //     0xa6f1a4: ret             
    // 0xa6f1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6f1a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6f1ac: b               #0xa6f12c
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa79cb4, size: 0xa0
    // 0xa79cb4: EnterFrame
    //     0xa79cb4: stp             fp, lr, [SP, #-0x10]!
    //     0xa79cb8: mov             fp, SP
    // 0xa79cbc: CheckStackOverflow
    //     0xa79cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa79cc0: cmp             SP, x16
    //     0xa79cc4: b.ls            #0xa79d4c
    // 0xa79cc8: ldr             x0, [fp, #0x10]
    // 0xa79ccc: r2 = Null
    //     0xa79ccc: mov             x2, NULL
    // 0xa79cd0: r1 = Null
    //     0xa79cd0: mov             x1, NULL
    // 0xa79cd4: r4 = 59
    //     0xa79cd4: mov             x4, #0x3b
    // 0xa79cd8: branchIfSmi(r0, 0xa79ce4)
    //     0xa79cd8: tbz             w0, #0, #0xa79ce4
    // 0xa79cdc: r4 = LoadClassIdInstr(r0)
    //     0xa79cdc: ldur            x4, [x0, #-1]
    //     0xa79ce0: ubfx            x4, x4, #0xc, #0x14
    // 0xa79ce4: r17 = 4376
    //     0xa79ce4: mov             x17, #0x1118
    // 0xa79ce8: cmp             x4, x17
    // 0xa79cec: b.eq            #0xa79d04
    // 0xa79cf0: r8 = _ShapeBorderPainter
    //     0xa79cf0: add             x8, PP, #0x28, lsl #12  ; [pp+0x289b0] Type: _ShapeBorderPainter
    //     0xa79cf4: ldr             x8, [x8, #0x9b0]
    // 0xa79cf8: r3 = Null
    //     0xa79cf8: add             x3, PP, #0x28, lsl #12  ; [pp+0x289b8] Null
    //     0xa79cfc: ldr             x3, [x3, #0x9b8]
    // 0xa79d00: r0 = DefaultTypeTest()
    //     0xa79d00: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa79d04: ldr             x0, [fp, #0x10]
    // 0xa79d08: LoadField: r1 = r0->field_b
    //     0xa79d08: ldur            w1, [x0, #0xb]
    // 0xa79d0c: DecompressPointer r1
    //     0xa79d0c: add             x1, x1, HEAP, lsl #32
    // 0xa79d10: ldr             x0, [fp, #0x18]
    // 0xa79d14: LoadField: r2 = r0->field_b
    //     0xa79d14: ldur            w2, [x0, #0xb]
    // 0xa79d18: DecompressPointer r2
    //     0xa79d18: add             x2, x2, HEAP, lsl #32
    // 0xa79d1c: r0 = LoadClassIdInstr(r1)
    //     0xa79d1c: ldur            x0, [x1, #-1]
    //     0xa79d20: ubfx            x0, x0, #0xc, #0x14
    // 0xa79d24: stp             x2, x1, [SP, #-0x10]!
    // 0xa79d28: mov             lr, x0
    // 0xa79d2c: ldr             lr, [x21, lr, lsl #3]
    // 0xa79d30: blr             lr
    // 0xa79d34: add             SP, SP, #0x10
    // 0xa79d38: eor             x1, x0, #0x10
    // 0xa79d3c: mov             x0, x1
    // 0xa79d40: LeaveFrame
    //     0xa79d40: mov             SP, fp
    //     0xa79d44: ldp             fp, lr, [SP], #0x10
    // 0xa79d48: ret
    //     0xa79d48: ret             
    // 0xa79d4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa79d4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa79d50: b               #0xa79cc8
  }
}

// class id: 5958, size: 0x14, field offset: 0x14
enum MaterialType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16360, size: 0x5c
    // 0xb16360: EnterFrame
    //     0xb16360: stp             fp, lr, [SP, #-0x10]!
    //     0xb16364: mov             fp, SP
    // 0xb16368: CheckStackOverflow
    //     0xb16368: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1636c: cmp             SP, x16
    //     0xb16370: b.ls            #0xb163b4
    // 0xb16374: r1 = Null
    //     0xb16374: mov             x1, NULL
    // 0xb16378: r2 = 4
    //     0xb16378: mov             x2, #4
    // 0xb1637c: r0 = AllocateArray()
    //     0xb1637c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16380: r17 = "MaterialType."
    //     0xb16380: add             x17, PP, #0xf, lsl #12  ; [pp+0xf1e8] "MaterialType."
    //     0xb16384: ldr             x17, [x17, #0x1e8]
    // 0xb16388: StoreField: r0->field_f = r17
    //     0xb16388: stur            w17, [x0, #0xf]
    // 0xb1638c: ldr             x1, [fp, #0x10]
    // 0xb16390: LoadField: r2 = r1->field_f
    //     0xb16390: ldur            w2, [x1, #0xf]
    // 0xb16394: DecompressPointer r2
    //     0xb16394: add             x2, x2, HEAP, lsl #32
    // 0xb16398: StoreField: r0->field_13 = r2
    //     0xb16398: stur            w2, [x0, #0x13]
    // 0xb1639c: SaveReg r0
    //     0xb1639c: str             x0, [SP, #-8]!
    // 0xb163a0: r0 = _interpolate()
    //     0xb163a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb163a4: add             SP, SP, #8
    // 0xb163a8: LeaveFrame
    //     0xb163a8: mov             SP, fp
    //     0xb163ac: ldp             fp, lr, [SP], #0x10
    // 0xb163b0: ret
    //     0xb163b0: ret             
    // 0xb163b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb163b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb163b8: b               #0xb16374
  }
}

// lib: , url: package:flutter/src/material/toggle_buttons_theme.dart

// class id: 1049336, size: 0x8
class :: {
}

// class id: 2715, size: 0x44, field offset: 0x8
//   const constructor, 
class ToggleButtonsThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb058b4, size: 0x84
    // 0xb058b4: EnterFrame
    //     0xb058b4: stp             fp, lr, [SP, #-0x10]!
    //     0xb058b8: mov             fp, SP
    // 0xb058bc: CheckStackOverflow
    //     0xb058bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb058c0: cmp             SP, x16
    //     0xb058c4: b.ls            #0xb05930
    // 0xb058c8: ldr             x0, [fp, #0x10]
    // 0xb058cc: LoadField: r1 = r0->field_b
    //     0xb058cc: ldur            w1, [x0, #0xb]
    // 0xb058d0: DecompressPointer r1
    //     0xb058d0: add             x1, x1, HEAP, lsl #32
    // 0xb058d4: LoadField: r2 = r0->field_3b
    //     0xb058d4: ldur            w2, [x0, #0x3b]
    // 0xb058d8: DecompressPointer r2
    //     0xb058d8: add             x2, x2, HEAP, lsl #32
    // 0xb058dc: stp             x1, NULL, [SP, #-0x10]!
    // 0xb058e0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb058e4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb058e8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb058ec: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb058f0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb058f4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb058f8: SaveReg r2
    //     0xb058f8: str             x2, [SP, #-8]!
    // 0xb058fc: r4 = const [0, 0xf, 0xf, 0xf, null]
    //     0xb058fc: add             x4, PP, #0xd, lsl #12  ; [pp+0xdef0] List(5) [0, 0xf, 0xf, 0xf, Null]
    //     0xb05900: ldr             x4, [x4, #0xef0]
    // 0xb05904: r0 = hash()
    //     0xb05904: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb05908: add             SP, SP, #0x78
    // 0xb0590c: mov             x2, x0
    // 0xb05910: r0 = BoxInt64Instr(r2)
    //     0xb05910: sbfiz           x0, x2, #1, #0x1f
    //     0xb05914: cmp             x2, x0, asr #1
    //     0xb05918: b.eq            #0xb05924
    //     0xb0591c: bl              #0xd69bb8
    //     0xb05920: stur            x2, [x0, #7]
    // 0xb05924: LeaveFrame
    //     0xb05924: mov             SP, fp
    //     0xb05928: ldp             fp, lr, [SP], #0x10
    // 0xb0592c: ret
    //     0xb0592c: ret             
    // 0xb05930: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb05930: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb05934: b               #0xb058c8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbee7e0, size: 0x1e0
    // 0xbee7e0: EnterFrame
    //     0xbee7e0: stp             fp, lr, [SP, #-0x10]!
    //     0xbee7e4: mov             fp, SP
    // 0xbee7e8: AllocStack(0x10)
    //     0xbee7e8: sub             SP, SP, #0x10
    // 0xbee7ec: CheckStackOverflow
    //     0xbee7ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbee7f0: cmp             SP, x16
    //     0xbee7f4: b.ls            #0xbee9a8
    // 0xbee7f8: ldr             d0, [fp, #0x10]
    // 0xbee7fc: r0 = inline_Allocate_Double()
    //     0xbee7fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbee800: add             x0, x0, #0x10
    //     0xbee804: cmp             x1, x0
    //     0xbee808: b.ls            #0xbee9b0
    //     0xbee80c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbee810: sub             x0, x0, #0xf
    //     0xbee814: mov             x1, #0xd108
    //     0xbee818: movk            x1, #3, lsl #16
    //     0xbee81c: stur            x1, [x0, #-1]
    // 0xbee820: StoreField: r0->field_7 = d0
    //     0xbee820: stur            d0, [x0, #7]
    // 0xbee824: stur            x0, [fp, #-8]
    // 0xbee828: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee82c: SaveReg r0
    //     0xbee82c: str             x0, [SP, #-8]!
    // 0xbee830: r0 = lerp()
    //     0xbee830: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbee834: add             SP, SP, #0x18
    // 0xbee838: ldr             x0, [fp, #0x20]
    // 0xbee83c: LoadField: r1 = r0->field_b
    //     0xbee83c: ldur            w1, [x0, #0xb]
    // 0xbee840: DecompressPointer r1
    //     0xbee840: add             x1, x1, HEAP, lsl #32
    // 0xbee844: ldr             x2, [fp, #0x18]
    // 0xbee848: LoadField: r3 = r2->field_b
    //     0xbee848: ldur            w3, [x2, #0xb]
    // 0xbee84c: DecompressPointer r3
    //     0xbee84c: add             x3, x3, HEAP, lsl #32
    // 0xbee850: stp             x3, x1, [SP, #-0x10]!
    // 0xbee854: ldr             d0, [fp, #0x10]
    // 0xbee858: SaveReg d0
    //     0xbee858: str             d0, [SP, #-8]!
    // 0xbee85c: r0 = lerp()
    //     0xbee85c: bl              #0xbee9cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0xbee860: add             SP, SP, #0x18
    // 0xbee864: stur            x0, [fp, #-0x10]
    // 0xbee868: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee86c: ldur            x16, [fp, #-8]
    // 0xbee870: SaveReg r16
    //     0xbee870: str             x16, [SP, #-8]!
    // 0xbee874: r0 = lerp()
    //     0xbee874: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee878: add             SP, SP, #0x18
    // 0xbee87c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee880: ldur            x16, [fp, #-8]
    // 0xbee884: SaveReg r16
    //     0xbee884: str             x16, [SP, #-8]!
    // 0xbee888: r0 = lerp()
    //     0xbee888: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee88c: add             SP, SP, #0x18
    // 0xbee890: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee894: ldur            x16, [fp, #-8]
    // 0xbee898: SaveReg r16
    //     0xbee898: str             x16, [SP, #-8]!
    // 0xbee89c: r0 = lerp()
    //     0xbee89c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee8a0: add             SP, SP, #0x18
    // 0xbee8a4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee8a8: ldur            x16, [fp, #-8]
    // 0xbee8ac: SaveReg r16
    //     0xbee8ac: str             x16, [SP, #-8]!
    // 0xbee8b0: r0 = lerp()
    //     0xbee8b0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee8b4: add             SP, SP, #0x18
    // 0xbee8b8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee8bc: ldur            x16, [fp, #-8]
    // 0xbee8c0: SaveReg r16
    //     0xbee8c0: str             x16, [SP, #-8]!
    // 0xbee8c4: r0 = lerp()
    //     0xbee8c4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee8c8: add             SP, SP, #0x18
    // 0xbee8cc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee8d0: ldur            x16, [fp, #-8]
    // 0xbee8d4: SaveReg r16
    //     0xbee8d4: str             x16, [SP, #-8]!
    // 0xbee8d8: r0 = lerp()
    //     0xbee8d8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee8dc: add             SP, SP, #0x18
    // 0xbee8e0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee8e4: ldur            x16, [fp, #-8]
    // 0xbee8e8: SaveReg r16
    //     0xbee8e8: str             x16, [SP, #-8]!
    // 0xbee8ec: r0 = lerp()
    //     0xbee8ec: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee8f0: add             SP, SP, #0x18
    // 0xbee8f4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee8f8: ldur            x16, [fp, #-8]
    // 0xbee8fc: SaveReg r16
    //     0xbee8fc: str             x16, [SP, #-8]!
    // 0xbee900: r0 = lerp()
    //     0xbee900: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee904: add             SP, SP, #0x18
    // 0xbee908: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee90c: ldur            x16, [fp, #-8]
    // 0xbee910: SaveReg r16
    //     0xbee910: str             x16, [SP, #-8]!
    // 0xbee914: r0 = lerp()
    //     0xbee914: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee918: add             SP, SP, #0x18
    // 0xbee91c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee920: ldur            x16, [fp, #-8]
    // 0xbee924: SaveReg r16
    //     0xbee924: str             x16, [SP, #-8]!
    // 0xbee928: r0 = lerp()
    //     0xbee928: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee92c: add             SP, SP, #0x18
    // 0xbee930: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee934: ldur            x16, [fp, #-8]
    // 0xbee938: SaveReg r16
    //     0xbee938: str             x16, [SP, #-8]!
    // 0xbee93c: r0 = lerp()
    //     0xbee93c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbee940: add             SP, SP, #0x18
    // 0xbee944: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbee948: ldr             d0, [fp, #0x10]
    // 0xbee94c: SaveReg d0
    //     0xbee94c: str             d0, [SP, #-8]!
    // 0xbee950: r0 = lerp()
    //     0xbee950: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0xbee954: add             SP, SP, #0x18
    // 0xbee958: ldr             x0, [fp, #0x20]
    // 0xbee95c: LoadField: r1 = r0->field_3b
    //     0xbee95c: ldur            w1, [x0, #0x3b]
    // 0xbee960: DecompressPointer r1
    //     0xbee960: add             x1, x1, HEAP, lsl #32
    // 0xbee964: ldr             x0, [fp, #0x18]
    // 0xbee968: LoadField: r2 = r0->field_3b
    //     0xbee968: ldur            w2, [x0, #0x3b]
    // 0xbee96c: DecompressPointer r2
    //     0xbee96c: add             x2, x2, HEAP, lsl #32
    // 0xbee970: stp             x2, x1, [SP, #-0x10]!
    // 0xbee974: ldur            x16, [fp, #-8]
    // 0xbee978: SaveReg r16
    //     0xbee978: str             x16, [SP, #-8]!
    // 0xbee97c: r0 = lerpDouble()
    //     0xbee97c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbee980: add             SP, SP, #0x18
    // 0xbee984: stur            x0, [fp, #-8]
    // 0xbee988: r0 = ToggleButtonsThemeData()
    //     0xbee988: bl              #0xbee9c0  ; AllocateToggleButtonsThemeDataStub -> ToggleButtonsThemeData (size=0x44)
    // 0xbee98c: ldur            x1, [fp, #-0x10]
    // 0xbee990: StoreField: r0->field_b = r1
    //     0xbee990: stur            w1, [x0, #0xb]
    // 0xbee994: ldur            x1, [fp, #-8]
    // 0xbee998: StoreField: r0->field_3b = r1
    //     0xbee998: stur            w1, [x0, #0x3b]
    // 0xbee99c: LeaveFrame
    //     0xbee99c: mov             SP, fp
    //     0xbee9a0: ldp             fp, lr, [SP], #0x10
    // 0xbee9a4: ret
    //     0xbee9a4: ret             
    // 0xbee9a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbee9a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbee9ac: b               #0xbee7f8
    // 0xbee9b0: SaveReg d0
    //     0xbee9b0: str             q0, [SP, #-0x10]!
    // 0xbee9b4: r0 = AllocateDouble()
    //     0xbee9b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbee9b8: RestoreReg d0
    //     0xbee9b8: ldr             q0, [SP], #0x10
    // 0xbee9bc: b               #0xbee820
  }
  _ ==(/* No info */) {
    // ** addr: 0xc92ad8, size: 0x160
    // 0xc92ad8: EnterFrame
    //     0xc92ad8: stp             fp, lr, [SP, #-0x10]!
    //     0xc92adc: mov             fp, SP
    // 0xc92ae0: CheckStackOverflow
    //     0xc92ae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc92ae4: cmp             SP, x16
    //     0xc92ae8: b.ls            #0xc92c30
    // 0xc92aec: ldr             x1, [fp, #0x10]
    // 0xc92af0: cmp             w1, NULL
    // 0xc92af4: b.ne            #0xc92b08
    // 0xc92af8: r0 = false
    //     0xc92af8: add             x0, NULL, #0x30  ; false
    // 0xc92afc: LeaveFrame
    //     0xc92afc: mov             SP, fp
    //     0xc92b00: ldp             fp, lr, [SP], #0x10
    // 0xc92b04: ret
    //     0xc92b04: ret             
    // 0xc92b08: ldr             x2, [fp, #0x18]
    // 0xc92b0c: cmp             w2, w1
    // 0xc92b10: b.ne            #0xc92b24
    // 0xc92b14: r0 = true
    //     0xc92b14: add             x0, NULL, #0x20  ; true
    // 0xc92b18: LeaveFrame
    //     0xc92b18: mov             SP, fp
    //     0xc92b1c: ldp             fp, lr, [SP], #0x10
    // 0xc92b20: ret
    //     0xc92b20: ret             
    // 0xc92b24: r0 = 59
    //     0xc92b24: mov             x0, #0x3b
    // 0xc92b28: branchIfSmi(r1, 0xc92b34)
    //     0xc92b28: tbz             w1, #0, #0xc92b34
    // 0xc92b2c: r0 = LoadClassIdInstr(r1)
    //     0xc92b2c: ldur            x0, [x1, #-1]
    //     0xc92b30: ubfx            x0, x0, #0xc, #0x14
    // 0xc92b34: SaveReg r1
    //     0xc92b34: str             x1, [SP, #-8]!
    // 0xc92b38: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc92b38: mov             x17, #0x57c5
    //     0xc92b3c: add             lr, x0, x17
    //     0xc92b40: ldr             lr, [x21, lr, lsl #3]
    //     0xc92b44: blr             lr
    // 0xc92b48: add             SP, SP, #8
    // 0xc92b4c: r1 = LoadClassIdInstr(r0)
    //     0xc92b4c: ldur            x1, [x0, #-1]
    //     0xc92b50: ubfx            x1, x1, #0xc, #0x14
    // 0xc92b54: r16 = ToggleButtonsThemeData
    //     0xc92b54: add             x16, PP, #0xd, lsl #12  ; [pp+0xdee8] Type: ToggleButtonsThemeData
    //     0xc92b58: ldr             x16, [x16, #0xee8]
    // 0xc92b5c: stp             x16, x0, [SP, #-0x10]!
    // 0xc92b60: mov             x0, x1
    // 0xc92b64: mov             lr, x0
    // 0xc92b68: ldr             lr, [x21, lr, lsl #3]
    // 0xc92b6c: blr             lr
    // 0xc92b70: add             SP, SP, #0x10
    // 0xc92b74: tbz             w0, #4, #0xc92b88
    // 0xc92b78: r0 = false
    //     0xc92b78: add             x0, NULL, #0x30  ; false
    // 0xc92b7c: LeaveFrame
    //     0xc92b7c: mov             SP, fp
    //     0xc92b80: ldp             fp, lr, [SP], #0x10
    // 0xc92b84: ret
    //     0xc92b84: ret             
    // 0xc92b88: ldr             x1, [fp, #0x10]
    // 0xc92b8c: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc92b8c: mov             x0, #0x76
    //     0xc92b90: tbz             w1, #0, #0xc92ba0
    //     0xc92b94: ldur            x0, [x1, #-1]
    //     0xc92b98: ubfx            x0, x0, #0xc, #0x14
    //     0xc92b9c: lsl             x0, x0, #1
    // 0xc92ba0: r17 = 5430
    //     0xc92ba0: mov             x17, #0x1536
    // 0xc92ba4: cmp             w0, w17
    // 0xc92ba8: b.ne            #0xc92c20
    // 0xc92bac: ldr             x2, [fp, #0x18]
    // 0xc92bb0: LoadField: r0 = r1->field_b
    //     0xc92bb0: ldur            w0, [x1, #0xb]
    // 0xc92bb4: DecompressPointer r0
    //     0xc92bb4: add             x0, x0, HEAP, lsl #32
    // 0xc92bb8: LoadField: r3 = r2->field_b
    //     0xc92bb8: ldur            w3, [x2, #0xb]
    // 0xc92bbc: DecompressPointer r3
    //     0xc92bbc: add             x3, x3, HEAP, lsl #32
    // 0xc92bc0: r4 = LoadClassIdInstr(r0)
    //     0xc92bc0: ldur            x4, [x0, #-1]
    //     0xc92bc4: ubfx            x4, x4, #0xc, #0x14
    // 0xc92bc8: stp             x3, x0, [SP, #-0x10]!
    // 0xc92bcc: mov             x0, x4
    // 0xc92bd0: mov             lr, x0
    // 0xc92bd4: ldr             lr, [x21, lr, lsl #3]
    // 0xc92bd8: blr             lr
    // 0xc92bdc: add             SP, SP, #0x10
    // 0xc92be0: tbnz            w0, #4, #0xc92c20
    // 0xc92be4: ldr             x1, [fp, #0x18]
    // 0xc92be8: ldr             x0, [fp, #0x10]
    // 0xc92bec: LoadField: r2 = r0->field_3b
    //     0xc92bec: ldur            w2, [x0, #0x3b]
    // 0xc92bf0: DecompressPointer r2
    //     0xc92bf0: add             x2, x2, HEAP, lsl #32
    // 0xc92bf4: LoadField: r0 = r1->field_3b
    //     0xc92bf4: ldur            w0, [x1, #0x3b]
    // 0xc92bf8: DecompressPointer r0
    //     0xc92bf8: add             x0, x0, HEAP, lsl #32
    // 0xc92bfc: r1 = LoadClassIdInstr(r2)
    //     0xc92bfc: ldur            x1, [x2, #-1]
    //     0xc92c00: ubfx            x1, x1, #0xc, #0x14
    // 0xc92c04: stp             x0, x2, [SP, #-0x10]!
    // 0xc92c08: mov             x0, x1
    // 0xc92c0c: mov             lr, x0
    // 0xc92c10: ldr             lr, [x21, lr, lsl #3]
    // 0xc92c14: blr             lr
    // 0xc92c18: add             SP, SP, #0x10
    // 0xc92c1c: b               #0xc92c24
    // 0xc92c20: r0 = false
    //     0xc92c20: add             x0, NULL, #0x30  ; false
    // 0xc92c24: LeaveFrame
    //     0xc92c24: mov             SP, fp
    //     0xc92c28: ldp             fp, lr, [SP], #0x10
    // 0xc92c2c: ret
    //     0xc92c2c: ret             
    // 0xc92c30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc92c30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc92c34: b               #0xc92aec
  }
}

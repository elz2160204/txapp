// lib: , url: package:flutter/src/material/tabs.dart

// class id: 1049320, size: 0x8
class :: {

  static _ _indexChangeProgress(/* No info */) {
    // ** addr: 0xc247d4, size: 0x1e0
    // 0xc247d4: EnterFrame
    //     0xc247d4: stp             fp, lr, [SP, #-0x10]!
    //     0xc247d8: mov             fp, SP
    // 0xc247dc: AllocStack(0x10)
    //     0xc247dc: sub             SP, SP, #0x10
    // 0xc247e0: CheckStackOverflow
    //     0xc247e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc247e4: cmp             SP, x16
    //     0xc247e8: b.ls            #0xc2499c
    // 0xc247ec: ldr             x2, [fp, #0x10]
    // 0xc247f0: LoadField: r0 = r2->field_23
    //     0xc247f0: ldur            w0, [x2, #0x23]
    // 0xc247f4: DecompressPointer r0
    //     0xc247f4: add             x0, x0, HEAP, lsl #32
    // 0xc247f8: cmp             w0, NULL
    // 0xc247fc: b.ne            #0xc24804
    // 0xc24800: r0 = Null
    //     0xc24800: mov             x0, NULL
    // 0xc24804: cmp             w0, NULL
    // 0xc24808: b.eq            #0xc249a4
    // 0xc2480c: LoadField: r3 = r0->field_37
    //     0xc2480c: ldur            w3, [x0, #0x37]
    // 0xc24810: DecompressPointer r3
    //     0xc24810: add             x3, x3, HEAP, lsl #32
    // 0xc24814: r16 = Sentinel
    //     0xc24814: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc24818: cmp             w3, w16
    // 0xc2481c: b.eq            #0xc249a8
    // 0xc24820: stur            x3, [fp, #-8]
    // 0xc24824: LoadField: r4 = r2->field_3b
    //     0xc24824: ldur            x4, [x2, #0x3b]
    // 0xc24828: r0 = BoxInt64Instr(r4)
    //     0xc24828: sbfiz           x0, x4, #1, #0x1f
    //     0xc2482c: cmp             x4, x0, asr #1
    //     0xc24830: b.eq            #0xc2483c
    //     0xc24834: bl              #0xd69bb8
    //     0xc24838: stur            x4, [x0, #7]
    // 0xc2483c: stp             x0, NULL, [SP, #-0x10]!
    // 0xc24840: r0 = _Double.fromInteger()
    //     0xc24840: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xc24844: add             SP, SP, #0x10
    // 0xc24848: mov             x3, x0
    // 0xc2484c: ldr             x2, [fp, #0x10]
    // 0xc24850: stur            x3, [fp, #-0x10]
    // 0xc24854: LoadField: r4 = r2->field_33
    //     0xc24854: ldur            x4, [x2, #0x33]
    // 0xc24858: r0 = BoxInt64Instr(r4)
    //     0xc24858: sbfiz           x0, x4, #1, #0x1f
    //     0xc2485c: cmp             x4, x0, asr #1
    //     0xc24860: b.eq            #0xc2486c
    //     0xc24864: bl              #0xd69bb8
    //     0xc24868: stur            x4, [x0, #7]
    // 0xc2486c: stp             x0, NULL, [SP, #-0x10]!
    // 0xc24870: r0 = _Double.fromInteger()
    //     0xc24870: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xc24874: add             SP, SP, #0x10
    // 0xc24878: mov             x1, x0
    // 0xc2487c: ldr             x0, [fp, #0x10]
    // 0xc24880: LoadField: r2 = r0->field_43
    //     0xc24880: ldur            x2, [x0, #0x43]
    // 0xc24884: cbnz            x2, #0xc24914
    // 0xc24888: ldur            x0, [fp, #-8]
    // 0xc2488c: d1 = 0.000000
    //     0xc2488c: eor             v1.16b, v1.16b, v1.16b
    // 0xc24890: LoadField: d2 = r0->field_7
    //     0xc24890: ldur            d2, [x0, #7]
    // 0xc24894: LoadField: d3 = r1->field_7
    //     0xc24894: ldur            d3, [x1, #7]
    // 0xc24898: fsub            d4, d3, d2
    // 0xc2489c: fcmp            d4, d1
    // 0xc248a0: b.vs            #0xc248b0
    // 0xc248a4: b.ne            #0xc248b0
    // 0xc248a8: d2 = 0.000000
    //     0xc248a8: eor             v2.16b, v2.16b, v2.16b
    // 0xc248ac: b               #0xc248c8
    // 0xc248b0: fcmp            d4, d1
    // 0xc248b4: b.vs            #0xc248c4
    // 0xc248b8: b.ge            #0xc248c4
    // 0xc248bc: fneg            d2, d4
    // 0xc248c0: b               #0xc248c8
    // 0xc248c4: mov             v2.16b, v4.16b
    // 0xc248c8: fcmp            d2, d1
    // 0xc248cc: b.vs            #0xc248dc
    // 0xc248d0: b.ge            #0xc248dc
    // 0xc248d4: d0 = 0.000000
    //     0xc248d4: eor             v0.16b, v0.16b, v0.16b
    // 0xc248d8: b               #0xc24908
    // 0xc248dc: d3 = 1.000000
    //     0xc248dc: fmov            d3, #1.00000000
    // 0xc248e0: fcmp            d2, d3
    // 0xc248e4: b.vs            #0xc248f4
    // 0xc248e8: b.le            #0xc248f4
    // 0xc248ec: d0 = 1.000000
    //     0xc248ec: fmov            d0, #1.00000000
    // 0xc248f0: b               #0xc24908
    // 0xc248f4: fcmp            d2, d2
    // 0xc248f8: b.vc            #0xc24904
    // 0xc248fc: d0 = 1.000000
    //     0xc248fc: fmov            d0, #1.00000000
    // 0xc24900: b               #0xc24908
    // 0xc24904: mov             v0.16b, v2.16b
    // 0xc24908: LeaveFrame
    //     0xc24908: mov             SP, fp
    //     0xc2490c: ldp             fp, lr, [SP], #0x10
    // 0xc24910: ret
    //     0xc24910: ret             
    // 0xc24914: ldur            x0, [fp, #-8]
    // 0xc24918: d1 = 0.000000
    //     0xc24918: eor             v1.16b, v1.16b, v1.16b
    // 0xc2491c: LoadField: d2 = r0->field_7
    //     0xc2491c: ldur            d2, [x0, #7]
    // 0xc24920: LoadField: d3 = r1->field_7
    //     0xc24920: ldur            d3, [x1, #7]
    // 0xc24924: fsub            d4, d2, d3
    // 0xc24928: fcmp            d4, d1
    // 0xc2492c: b.vs            #0xc2493c
    // 0xc24930: b.ne            #0xc2493c
    // 0xc24934: d2 = 0.000000
    //     0xc24934: eor             v2.16b, v2.16b, v2.16b
    // 0xc24938: b               #0xc24954
    // 0xc2493c: fcmp            d4, d1
    // 0xc24940: b.vs            #0xc24950
    // 0xc24944: b.ge            #0xc24950
    // 0xc24948: fneg            d2, d4
    // 0xc2494c: b               #0xc24954
    // 0xc24950: mov             v2.16b, v4.16b
    // 0xc24954: ldur            x0, [fp, #-0x10]
    // 0xc24958: LoadField: d4 = r0->field_7
    //     0xc24958: ldur            d4, [x0, #7]
    // 0xc2495c: fsub            d5, d3, d4
    // 0xc24960: fcmp            d5, d1
    // 0xc24964: b.vs            #0xc24974
    // 0xc24968: b.ne            #0xc24974
    // 0xc2496c: d1 = 0.000000
    //     0xc2496c: eor             v1.16b, v1.16b, v1.16b
    // 0xc24970: b               #0xc2498c
    // 0xc24974: fcmp            d5, d1
    // 0xc24978: b.vs            #0xc24988
    // 0xc2497c: b.ge            #0xc24988
    // 0xc24980: fneg            d1, d5
    // 0xc24984: b               #0xc2498c
    // 0xc24988: mov             v1.16b, v5.16b
    // 0xc2498c: fdiv            d0, d2, d1
    // 0xc24990: LeaveFrame
    //     0xc24990: mov             SP, fp
    //     0xc24994: ldp             fp, lr, [SP], #0x10
    // 0xc24998: ret
    //     0xc24998: ret             
    // 0xc2499c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc2499c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc249a0: b               #0xc247ec
    // 0xc249a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc249a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc249a8: r9 = _value
    //     0xc249a8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc249ac: ldr             x9, [x9, #0xbb0]
    // 0xc249b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xc249b0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 2542, size: 0xa4, field offset: 0xa0
class _TabLabelBarRenderer extends RenderFlex {

  _ performLayout(/* No info */) {
    // ** addr: 0x6895c8, size: 0x3f8
    // 0x6895c8: EnterFrame
    //     0x6895c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6895cc: mov             fp, SP
    // 0x6895d0: AllocStack(0x20)
    //     0x6895d0: sub             SP, SP, #0x20
    // 0x6895d4: CheckStackOverflow
    //     0x6895d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6895d8: cmp             SP, x16
    //     0x6895dc: b.ls            #0x689914
    // 0x6895e0: ldr             x16, [fp, #0x10]
    // 0x6895e4: SaveReg r16
    //     0x6895e4: str             x16, [SP, #-8]!
    // 0x6895e8: r0 = performLayout()
    //     0x6895e8: bl              #0x6899c0  ; [package:flutter/src/rendering/flex.dart] RenderFlex::performLayout
    // 0x6895ec: add             SP, SP, #8
    // 0x6895f0: ldr             x0, [fp, #0x10]
    // 0x6895f4: LoadField: r1 = r0->field_67
    //     0x6895f4: ldur            w1, [x0, #0x67]
    // 0x6895f8: DecompressPointer r1
    //     0x6895f8: add             x1, x1, HEAP, lsl #32
    // 0x6895fc: stur            x1, [fp, #-8]
    // 0x689600: r16 = <double>
    //     0x689600: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x689604: stp             xzr, x16, [SP, #-0x10]!
    // 0x689608: r0 = _GrowableList()
    //     0x689608: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x68960c: add             SP, SP, #0x10
    // 0x689610: mov             x3, x0
    // 0x689614: stur            x3, [fp, #-0x10]
    // 0x689618: ldur            x0, [fp, #-8]
    // 0x68961c: CheckStackOverflow
    //     0x68961c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x689620: cmp             SP, x16
    //     0x689624: b.ls            #0x68991c
    // 0x689628: cmp             w0, NULL
    // 0x68962c: b.eq            #0x68974c
    // 0x689630: LoadField: r4 = r0->field_17
    //     0x689630: ldur            w4, [x0, #0x17]
    // 0x689634: DecompressPointer r4
    //     0x689634: add             x4, x4, HEAP, lsl #32
    // 0x689638: stur            x4, [fp, #-8]
    // 0x68963c: cmp             w4, NULL
    // 0x689640: b.eq            #0x689924
    // 0x689644: mov             x0, x4
    // 0x689648: r2 = Null
    //     0x689648: mov             x2, NULL
    // 0x68964c: r1 = Null
    //     0x68964c: mov             x1, NULL
    // 0x689650: r4 = LoadClassIdInstr(r0)
    //     0x689650: ldur            x4, [x0, #-1]
    //     0x689654: ubfx            x4, x4, #0xc, #0x14
    // 0x689658: cmp             x4, #0x809
    // 0x68965c: b.eq            #0x689674
    // 0x689660: r8 = FlexParentData<RenderBox>
    //     0x689660: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d248] Type: FlexParentData<RenderBox>
    //     0x689664: ldr             x8, [x8, #0x248]
    // 0x689668: r3 = Null
    //     0x689668: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bf08] Null
    //     0x68966c: ldr             x3, [x3, #0xf08]
    // 0x689670: r0 = DefaultTypeTest()
    //     0x689670: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x689674: ldur            x0, [fp, #-8]
    // 0x689678: LoadField: r1 = r0->field_7
    //     0x689678: ldur            w1, [x0, #7]
    // 0x68967c: DecompressPointer r1
    //     0x68967c: add             x1, x1, HEAP, lsl #32
    // 0x689680: LoadField: d0 = r1->field_7
    //     0x689680: ldur            d0, [x1, #7]
    // 0x689684: ldur            x1, [fp, #-0x10]
    // 0x689688: stur            d0, [fp, #-0x20]
    // 0x68968c: LoadField: r2 = r1->field_b
    //     0x68968c: ldur            w2, [x1, #0xb]
    // 0x689690: DecompressPointer r2
    //     0x689690: add             x2, x2, HEAP, lsl #32
    // 0x689694: stur            x2, [fp, #-0x18]
    // 0x689698: LoadField: r3 = r1->field_f
    //     0x689698: ldur            w3, [x1, #0xf]
    // 0x68969c: DecompressPointer r3
    //     0x68969c: add             x3, x3, HEAP, lsl #32
    // 0x6896a0: LoadField: r4 = r3->field_b
    //     0x6896a0: ldur            w4, [x3, #0xb]
    // 0x6896a4: DecompressPointer r4
    //     0x6896a4: add             x4, x4, HEAP, lsl #32
    // 0x6896a8: cmp             w2, w4
    // 0x6896ac: b.ne            #0x6896bc
    // 0x6896b0: SaveReg r1
    //     0x6896b0: str             x1, [SP, #-8]!
    // 0x6896b4: r0 = _growToNextCapacity()
    //     0x6896b4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6896b8: add             SP, SP, #8
    // 0x6896bc: ldur            x3, [fp, #-0x10]
    // 0x6896c0: ldur            x2, [fp, #-8]
    // 0x6896c4: ldur            d0, [fp, #-0x20]
    // 0x6896c8: ldur            x0, [fp, #-0x18]
    // 0x6896cc: r4 = LoadInt32Instr(r0)
    //     0x6896cc: sbfx            x4, x0, #1, #0x1f
    // 0x6896d0: add             x0, x4, #1
    // 0x6896d4: lsl             x1, x0, #1
    // 0x6896d8: StoreField: r3->field_b = r1
    //     0x6896d8: stur            w1, [x3, #0xb]
    // 0x6896dc: mov             x1, x4
    // 0x6896e0: cmp             x1, x0
    // 0x6896e4: b.hs            #0x689928
    // 0x6896e8: LoadField: r1 = r3->field_f
    //     0x6896e8: ldur            w1, [x3, #0xf]
    // 0x6896ec: DecompressPointer r1
    //     0x6896ec: add             x1, x1, HEAP, lsl #32
    // 0x6896f0: r0 = inline_Allocate_Double()
    //     0x6896f0: ldp             x0, x5, [THR, #0x60]  ; THR::top
    //     0x6896f4: add             x0, x0, #0x10
    //     0x6896f8: cmp             x5, x0
    //     0x6896fc: b.ls            #0x68992c
    //     0x689700: str             x0, [THR, #0x60]  ; THR::top
    //     0x689704: sub             x0, x0, #0xf
    //     0x689708: mov             x5, #0xd108
    //     0x68970c: movk            x5, #3, lsl #16
    //     0x689710: stur            x5, [x0, #-1]
    // 0x689714: StoreField: r0->field_7 = d0
    //     0x689714: stur            d0, [x0, #7]
    // 0x689718: ArrayStore: r1[r4] = r0  ; List_4
    //     0x689718: add             x25, x1, x4, lsl #2
    //     0x68971c: add             x25, x25, #0xf
    //     0x689720: str             w0, [x25]
    //     0x689724: tbz             w0, #0, #0x689740
    //     0x689728: ldurb           w16, [x1, #-1]
    //     0x68972c: ldurb           w17, [x0, #-1]
    //     0x689730: and             x16, x17, x16, lsr #2
    //     0x689734: tst             x16, HEAP, lsr #32
    //     0x689738: b.eq            #0x689740
    //     0x68973c: bl              #0xd67e5c
    // 0x689740: LoadField: r0 = r2->field_13
    //     0x689740: ldur            w0, [x2, #0x13]
    // 0x689744: DecompressPointer r0
    //     0x689744: add             x0, x0, HEAP, lsl #32
    // 0x689748: b               #0x68961c
    // 0x68974c: ldr             x0, [fp, #0x10]
    // 0x689750: LoadField: r1 = r0->field_83
    //     0x689750: ldur            w1, [x0, #0x83]
    // 0x689754: DecompressPointer r1
    //     0x689754: add             x1, x1, HEAP, lsl #32
    // 0x689758: cmp             w1, NULL
    // 0x68975c: b.eq            #0x68994c
    // 0x689760: LoadField: r2 = r1->field_7
    //     0x689760: ldur            x2, [x1, #7]
    // 0x689764: cmp             x2, #0
    // 0x689768: b.gt            #0x6897c0
    // 0x68976c: LoadField: r1 = r0->field_57
    //     0x68976c: ldur            w1, [x0, #0x57]
    // 0x689770: DecompressPointer r1
    //     0x689770: add             x1, x1, HEAP, lsl #32
    // 0x689774: cmp             w1, NULL
    // 0x689778: b.eq            #0x689950
    // 0x68977c: LoadField: d0 = r1->field_7
    //     0x68977c: ldur            d0, [x1, #7]
    // 0x689780: r1 = inline_Allocate_Double()
    //     0x689780: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x689784: add             x1, x1, #0x10
    //     0x689788: cmp             x2, x1
    //     0x68978c: b.ls            #0x689954
    //     0x689790: str             x1, [THR, #0x60]  ; THR::top
    //     0x689794: sub             x1, x1, #0xf
    //     0x689798: mov             x2, #0xd108
    //     0x68979c: movk            x2, #3, lsl #16
    //     0x6897a0: stur            x2, [x1, #-1]
    // 0x6897a4: StoreField: r1->field_7 = d0
    //     0x6897a4: stur            d0, [x1, #7]
    // 0x6897a8: stp             xzr, x3, [SP, #-0x10]!
    // 0x6897ac: SaveReg r1
    //     0x6897ac: str             x1, [SP, #-8]!
    // 0x6897b0: r0 = insert()
    //     0x6897b0: bl              #0x5f0388  ; [dart:core] _GrowableList::insert
    // 0x6897b4: add             SP, SP, #0x18
    // 0x6897b8: ldur            x2, [fp, #-0x10]
    // 0x6897bc: b               #0x689890
    // 0x6897c0: mov             x1, x0
    // 0x6897c4: mov             x0, x3
    // 0x6897c8: LoadField: r2 = r1->field_57
    //     0x6897c8: ldur            w2, [x1, #0x57]
    // 0x6897cc: DecompressPointer r2
    //     0x6897cc: add             x2, x2, HEAP, lsl #32
    // 0x6897d0: cmp             w2, NULL
    // 0x6897d4: b.eq            #0x689970
    // 0x6897d8: LoadField: d0 = r2->field_7
    //     0x6897d8: ldur            d0, [x2, #7]
    // 0x6897dc: stur            d0, [fp, #-0x20]
    // 0x6897e0: LoadField: r2 = r0->field_b
    //     0x6897e0: ldur            w2, [x0, #0xb]
    // 0x6897e4: DecompressPointer r2
    //     0x6897e4: add             x2, x2, HEAP, lsl #32
    // 0x6897e8: stur            x2, [fp, #-8]
    // 0x6897ec: LoadField: r3 = r0->field_f
    //     0x6897ec: ldur            w3, [x0, #0xf]
    // 0x6897f0: DecompressPointer r3
    //     0x6897f0: add             x3, x3, HEAP, lsl #32
    // 0x6897f4: LoadField: r4 = r3->field_b
    //     0x6897f4: ldur            w4, [x3, #0xb]
    // 0x6897f8: DecompressPointer r4
    //     0x6897f8: add             x4, x4, HEAP, lsl #32
    // 0x6897fc: cmp             w2, w4
    // 0x689800: b.ne            #0x689810
    // 0x689804: SaveReg r0
    //     0x689804: str             x0, [SP, #-8]!
    // 0x689808: r0 = _growToNextCapacity()
    //     0x689808: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x68980c: add             SP, SP, #8
    // 0x689810: ldur            x2, [fp, #-0x10]
    // 0x689814: ldur            d0, [fp, #-0x20]
    // 0x689818: ldur            x0, [fp, #-8]
    // 0x68981c: r3 = LoadInt32Instr(r0)
    //     0x68981c: sbfx            x3, x0, #1, #0x1f
    // 0x689820: add             x0, x3, #1
    // 0x689824: lsl             x1, x0, #1
    // 0x689828: StoreField: r2->field_b = r1
    //     0x689828: stur            w1, [x2, #0xb]
    // 0x68982c: mov             x1, x3
    // 0x689830: cmp             x1, x0
    // 0x689834: b.hs            #0x689974
    // 0x689838: LoadField: r1 = r2->field_f
    //     0x689838: ldur            w1, [x2, #0xf]
    // 0x68983c: DecompressPointer r1
    //     0x68983c: add             x1, x1, HEAP, lsl #32
    // 0x689840: r0 = inline_Allocate_Double()
    //     0x689840: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x689844: add             x0, x0, #0x10
    //     0x689848: cmp             x4, x0
    //     0x68984c: b.ls            #0x689978
    //     0x689850: str             x0, [THR, #0x60]  ; THR::top
    //     0x689854: sub             x0, x0, #0xf
    //     0x689858: mov             x4, #0xd108
    //     0x68985c: movk            x4, #3, lsl #16
    //     0x689860: stur            x4, [x0, #-1]
    // 0x689864: StoreField: r0->field_7 = d0
    //     0x689864: stur            d0, [x0, #7]
    // 0x689868: ArrayStore: r1[r3] = r0  ; List_4
    //     0x689868: add             x25, x1, x3, lsl #2
    //     0x68986c: add             x25, x25, #0xf
    //     0x689870: str             w0, [x25]
    //     0x689874: tbz             w0, #0, #0x689890
    //     0x689878: ldurb           w16, [x1, #-1]
    //     0x68987c: ldurb           w17, [x0, #-1]
    //     0x689880: and             x16, x17, x16, lsr #2
    //     0x689884: tst             x16, HEAP, lsr #32
    //     0x689888: b.eq            #0x689890
    //     0x68988c: bl              #0xd67e5c
    // 0x689890: ldr             x0, [fp, #0x10]
    // 0x689894: LoadField: r1 = r0->field_83
    //     0x689894: ldur            w1, [x0, #0x83]
    // 0x689898: DecompressPointer r1
    //     0x689898: add             x1, x1, HEAP, lsl #32
    // 0x68989c: cmp             w1, NULL
    // 0x6898a0: b.eq            #0x689998
    // 0x6898a4: LoadField: r3 = r0->field_57
    //     0x6898a4: ldur            w3, [x0, #0x57]
    // 0x6898a8: DecompressPointer r3
    //     0x6898a8: add             x3, x3, HEAP, lsl #32
    // 0x6898ac: cmp             w3, NULL
    // 0x6898b0: b.eq            #0x68999c
    // 0x6898b4: LoadField: d0 = r3->field_7
    //     0x6898b4: ldur            d0, [x3, #7]
    // 0x6898b8: LoadField: r3 = r0->field_9f
    //     0x6898b8: ldur            w3, [x0, #0x9f]
    // 0x6898bc: DecompressPointer r3
    //     0x6898bc: add             x3, x3, HEAP, lsl #32
    // 0x6898c0: r0 = inline_Allocate_Double()
    //     0x6898c0: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x6898c4: add             x0, x0, #0x10
    //     0x6898c8: cmp             x4, x0
    //     0x6898cc: b.ls            #0x6899a0
    //     0x6898d0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6898d4: sub             x0, x0, #0xf
    //     0x6898d8: mov             x4, #0xd108
    //     0x6898dc: movk            x4, #3, lsl #16
    //     0x6898e0: stur            x4, [x0, #-1]
    // 0x6898e4: StoreField: r0->field_7 = d0
    //     0x6898e4: stur            d0, [x0, #7]
    // 0x6898e8: stp             x2, x3, [SP, #-0x10]!
    // 0x6898ec: stp             x0, x1, [SP, #-0x10]!
    // 0x6898f0: mov             x0, x3
    // 0x6898f4: ClosureCall
    //     0x6898f4: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x6898f8: ldur            x2, [x0, #0x1f]
    //     0x6898fc: blr             x2
    // 0x689900: add             SP, SP, #0x20
    // 0x689904: r0 = Null
    //     0x689904: mov             x0, NULL
    // 0x689908: LeaveFrame
    //     0x689908: mov             SP, fp
    //     0x68990c: ldp             fp, lr, [SP], #0x10
    // 0x689910: ret
    //     0x689910: ret             
    // 0x689914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x689914: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x689918: b               #0x6895e0
    // 0x68991c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68991c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x689920: b               #0x689628
    // 0x689924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689924: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689928: r0 = RangeErrorSharedWithFPURegs()
    //     0x689928: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x68992c: SaveReg d0
    //     0x68992c: str             q0, [SP, #-0x10]!
    // 0x689930: stp             x3, x4, [SP, #-0x10]!
    // 0x689934: stp             x1, x2, [SP, #-0x10]!
    // 0x689938: r0 = AllocateDouble()
    //     0x689938: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68993c: ldp             x1, x2, [SP], #0x10
    // 0x689940: ldp             x3, x4, [SP], #0x10
    // 0x689944: RestoreReg d0
    //     0x689944: ldr             q0, [SP], #0x10
    // 0x689948: b               #0x689714
    // 0x68994c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68994c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689950: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689950: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689954: SaveReg d0
    //     0x689954: str             q0, [SP, #-0x10]!
    // 0x689958: stp             x0, x3, [SP, #-0x10]!
    // 0x68995c: r0 = AllocateDouble()
    //     0x68995c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x689960: mov             x1, x0
    // 0x689964: ldp             x0, x3, [SP], #0x10
    // 0x689968: RestoreReg d0
    //     0x689968: ldr             q0, [SP], #0x10
    // 0x68996c: b               #0x6897a4
    // 0x689970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689970: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x689974: r0 = RangeErrorSharedWithFPURegs()
    //     0x689974: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x689978: SaveReg d0
    //     0x689978: str             q0, [SP, #-0x10]!
    // 0x68997c: stp             x2, x3, [SP, #-0x10]!
    // 0x689980: SaveReg r1
    //     0x689980: str             x1, [SP, #-8]!
    // 0x689984: r0 = AllocateDouble()
    //     0x689984: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x689988: RestoreReg r1
    //     0x689988: ldr             x1, [SP], #8
    // 0x68998c: ldp             x2, x3, [SP], #0x10
    // 0x689990: RestoreReg d0
    //     0x689990: ldr             q0, [SP], #0x10
    // 0x689994: b               #0x689864
    // 0x689998: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x689998: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68999c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68999c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6899a0: SaveReg d0
    //     0x6899a0: str             q0, [SP, #-0x10]!
    // 0x6899a4: stp             x2, x3, [SP, #-0x10]!
    // 0x6899a8: SaveReg r1
    //     0x6899a8: str             x1, [SP, #-8]!
    // 0x6899ac: r0 = AllocateDouble()
    //     0x6899ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6899b0: RestoreReg r1
    //     0x6899b0: ldr             x1, [SP], #8
    // 0x6899b4: ldp             x2, x3, [SP], #0x10
    // 0x6899b8: RestoreReg d0
    //     0x6899b8: ldr             q0, [SP], #0x10
    // 0x6899bc: b               #0x6898e4
  }
}

// class id: 2723, size: 0x44, field offset: 0x38
class _TabsDefaultsM3 extends TabBarTheme {

  late final ColorScheme _colors; // offset: 0x3c
  late final TextTheme _textTheme; // offset: 0x40

  ColorScheme _colors(_TabsDefaultsM3) {
    // ** addr: 0x7bcf44, size: 0x4c
    // 0x7bcf44: EnterFrame
    //     0x7bcf44: stp             fp, lr, [SP, #-0x10]!
    //     0x7bcf48: mov             fp, SP
    // 0x7bcf4c: CheckStackOverflow
    //     0x7bcf4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bcf50: cmp             SP, x16
    //     0x7bcf54: b.ls            #0x7bcf88
    // 0x7bcf58: ldr             x0, [fp, #0x10]
    // 0x7bcf5c: LoadField: r1 = r0->field_37
    //     0x7bcf5c: ldur            w1, [x0, #0x37]
    // 0x7bcf60: DecompressPointer r1
    //     0x7bcf60: add             x1, x1, HEAP, lsl #32
    // 0x7bcf64: SaveReg r1
    //     0x7bcf64: str             x1, [SP, #-8]!
    // 0x7bcf68: r0 = of()
    //     0x7bcf68: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x7bcf6c: add             SP, SP, #8
    // 0x7bcf70: LoadField: r1 = r0->field_3f
    //     0x7bcf70: ldur            w1, [x0, #0x3f]
    // 0x7bcf74: DecompressPointer r1
    //     0x7bcf74: add             x1, x1, HEAP, lsl #32
    // 0x7bcf78: mov             x0, x1
    // 0x7bcf7c: LeaveFrame
    //     0x7bcf7c: mov             SP, fp
    //     0x7bcf80: ldp             fp, lr, [SP], #0x10
    // 0x7bcf84: ret
    //     0x7bcf84: ret             
    // 0x7bcf88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bcf88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bcf8c: b               #0x7bcf58
  }
  TextTheme _textTheme(_TabsDefaultsM3) {
    // ** addr: 0xaecf48, size: 0x4c
    // 0xaecf48: EnterFrame
    //     0xaecf48: stp             fp, lr, [SP, #-0x10]!
    //     0xaecf4c: mov             fp, SP
    // 0xaecf50: CheckStackOverflow
    //     0xaecf50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaecf54: cmp             SP, x16
    //     0xaecf58: b.ls            #0xaecf8c
    // 0xaecf5c: ldr             x0, [fp, #0x10]
    // 0xaecf60: LoadField: r1 = r0->field_37
    //     0xaecf60: ldur            w1, [x0, #0x37]
    // 0xaecf64: DecompressPointer r1
    //     0xaecf64: add             x1, x1, HEAP, lsl #32
    // 0xaecf68: SaveReg r1
    //     0xaecf68: str             x1, [SP, #-8]!
    // 0xaecf6c: r0 = of()
    //     0xaecf6c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaecf70: add             SP, SP, #8
    // 0xaecf74: LoadField: r1 = r0->field_93
    //     0xaecf74: ldur            w1, [x0, #0x93]
    // 0xaecf78: DecompressPointer r1
    //     0xaecf78: add             x1, x1, HEAP, lsl #32
    // 0xaecf7c: mov             x0, x1
    // 0xaecf80: LeaveFrame
    //     0xaecf80: mov             SP, fp
    //     0xaecf84: ldp             fp, lr, [SP], #0x10
    // 0xaecf88: ret
    //     0xaecf88: ret             
    // 0xaecf8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaecf8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaecf90: b               #0xaecf5c
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xb020a4, size: 0x3fc
    // 0xb020a4: EnterFrame
    //     0xb020a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb020a8: mov             fp, SP
    // 0xb020ac: AllocStack(0x8)
    //     0xb020ac: sub             SP, SP, #8
    // 0xb020b0: SetupParameters()
    //     0xb020b0: ldr             x0, [fp, #0x18]
    //     0xb020b4: ldur            w1, [x0, #0x17]
    //     0xb020b8: add             x1, x1, HEAP, lsl #32
    //     0xb020bc: stur            x1, [fp, #-8]
    // 0xb020c0: CheckStackOverflow
    //     0xb020c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb020c4: cmp             SP, x16
    //     0xb020c8: b.ls            #0xb02498
    // 0xb020cc: ldr             x2, [fp, #0x10]
    // 0xb020d0: r0 = LoadClassIdInstr(r2)
    //     0xb020d0: ldur            x0, [x2, #-1]
    //     0xb020d4: ubfx            x0, x0, #0xc, #0x14
    // 0xb020d8: r16 = Instance_MaterialState
    //     0xb020d8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0xb020dc: ldr             x16, [x16, #0xf70]
    // 0xb020e0: stp             x16, x2, [SP, #-0x10]!
    // 0xb020e4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb020e4: mov             x17, #0xc98a
    //     0xb020e8: add             lr, x0, x17
    //     0xb020ec: ldr             lr, [x21, lr, lsl #3]
    //     0xb020f0: blr             lr
    // 0xb020f4: add             SP, SP, #0x10
    // 0xb020f8: tbnz            w0, #4, #0xb022c0
    // 0xb020fc: ldr             x1, [fp, #0x10]
    // 0xb02100: r0 = LoadClassIdInstr(r1)
    //     0xb02100: ldur            x0, [x1, #-1]
    //     0xb02104: ubfx            x0, x0, #0xc, #0x14
    // 0xb02108: r16 = Instance_MaterialState
    //     0xb02108: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xb0210c: ldr             x16, [x16, #0xf78]
    // 0xb02110: stp             x16, x1, [SP, #-0x10]!
    // 0xb02114: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb02114: mov             x17, #0xc98a
    //     0xb02118: add             lr, x0, x17
    //     0xb0211c: ldr             lr, [x21, lr, lsl #3]
    //     0xb02120: blr             lr
    // 0xb02124: add             SP, SP, #0x10
    // 0xb02128: tbnz            w0, #4, #0xb02188
    // 0xb0212c: ldur            x1, [fp, #-8]
    // 0xb02130: LoadField: r0 = r1->field_f
    //     0xb02130: ldur            w0, [x1, #0xf]
    // 0xb02134: DecompressPointer r0
    //     0xb02134: add             x0, x0, HEAP, lsl #32
    // 0xb02138: mov             x1, x0
    // 0xb0213c: LoadField: r0 = r1->field_3b
    //     0xb0213c: ldur            w0, [x1, #0x3b]
    // 0xb02140: DecompressPointer r0
    //     0xb02140: add             x0, x0, HEAP, lsl #32
    // 0xb02144: r16 = Sentinel
    //     0xb02144: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb02148: cmp             w0, w16
    // 0xb0214c: b.ne            #0xb0215c
    // 0xb02150: r2 = _colors
    //     0xb02150: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb02154: ldr             x2, [x2, #0xf50]
    // 0xb02158: r0 = InitLateFinalInstanceField()
    //     0xb02158: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb0215c: LoadField: r1 = r0->field_b
    //     0xb0215c: ldur            w1, [x0, #0xb]
    // 0xb02160: DecompressPointer r1
    //     0xb02160: add             x1, x1, HEAP, lsl #32
    // 0xb02164: SaveReg r1
    //     0xb02164: str             x1, [SP, #-8]!
    // 0xb02168: d0 = 0.080000
    //     0xb02168: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb0216c: ldr             d0, [x17, #0xf80]
    // 0xb02170: SaveReg d0
    //     0xb02170: str             d0, [SP, #-8]!
    // 0xb02174: r0 = withOpacity()
    //     0xb02174: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb02178: add             SP, SP, #0x10
    // 0xb0217c: LeaveFrame
    //     0xb0217c: mov             SP, fp
    //     0xb02180: ldp             fp, lr, [SP], #0x10
    // 0xb02184: ret
    //     0xb02184: ret             
    // 0xb02188: ldr             x2, [fp, #0x10]
    // 0xb0218c: ldur            x1, [fp, #-8]
    // 0xb02190: r0 = LoadClassIdInstr(r2)
    //     0xb02190: ldur            x0, [x2, #-1]
    //     0xb02194: ubfx            x0, x0, #0xc, #0x14
    // 0xb02198: r16 = Instance_MaterialState
    //     0xb02198: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xb0219c: ldr             x16, [x16, #0xf88]
    // 0xb021a0: stp             x16, x2, [SP, #-0x10]!
    // 0xb021a4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb021a4: mov             x17, #0xc98a
    //     0xb021a8: add             lr, x0, x17
    //     0xb021ac: ldr             lr, [x21, lr, lsl #3]
    //     0xb021b0: blr             lr
    // 0xb021b4: add             SP, SP, #0x10
    // 0xb021b8: tbnz            w0, #4, #0xb02218
    // 0xb021bc: ldur            x1, [fp, #-8]
    // 0xb021c0: LoadField: r0 = r1->field_f
    //     0xb021c0: ldur            w0, [x1, #0xf]
    // 0xb021c4: DecompressPointer r0
    //     0xb021c4: add             x0, x0, HEAP, lsl #32
    // 0xb021c8: mov             x1, x0
    // 0xb021cc: LoadField: r0 = r1->field_3b
    //     0xb021cc: ldur            w0, [x1, #0x3b]
    // 0xb021d0: DecompressPointer r0
    //     0xb021d0: add             x0, x0, HEAP, lsl #32
    // 0xb021d4: r16 = Sentinel
    //     0xb021d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb021d8: cmp             w0, w16
    // 0xb021dc: b.ne            #0xb021ec
    // 0xb021e0: r2 = _colors
    //     0xb021e0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb021e4: ldr             x2, [x2, #0xf50]
    // 0xb021e8: r0 = InitLateFinalInstanceField()
    //     0xb021e8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb021ec: LoadField: r1 = r0->field_b
    //     0xb021ec: ldur            w1, [x0, #0xb]
    // 0xb021f0: DecompressPointer r1
    //     0xb021f0: add             x1, x1, HEAP, lsl #32
    // 0xb021f4: SaveReg r1
    //     0xb021f4: str             x1, [SP, #-8]!
    // 0xb021f8: d0 = 0.120000
    //     0xb021f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb021fc: ldr             d0, [x17, #0xf48]
    // 0xb02200: SaveReg d0
    //     0xb02200: str             d0, [SP, #-8]!
    // 0xb02204: r0 = withOpacity()
    //     0xb02204: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb02208: add             SP, SP, #0x10
    // 0xb0220c: LeaveFrame
    //     0xb0220c: mov             SP, fp
    //     0xb02210: ldp             fp, lr, [SP], #0x10
    // 0xb02214: ret
    //     0xb02214: ret             
    // 0xb02218: ldr             x2, [fp, #0x10]
    // 0xb0221c: ldur            x1, [fp, #-8]
    // 0xb02220: d0 = 0.120000
    //     0xb02220: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb02224: ldr             d0, [x17, #0xf48]
    // 0xb02228: r0 = LoadClassIdInstr(r2)
    //     0xb02228: ldur            x0, [x2, #-1]
    //     0xb0222c: ubfx            x0, x0, #0xc, #0x14
    // 0xb02230: r16 = Instance_MaterialState
    //     0xb02230: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xb02234: ldr             x16, [x16, #0xf90]
    // 0xb02238: stp             x16, x2, [SP, #-0x10]!
    // 0xb0223c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb0223c: mov             x17, #0xc98a
    //     0xb02240: add             lr, x0, x17
    //     0xb02244: ldr             lr, [x21, lr, lsl #3]
    //     0xb02248: blr             lr
    // 0xb0224c: add             SP, SP, #0x10
    // 0xb02250: tbnz            w0, #4, #0xb022b0
    // 0xb02254: ldur            x1, [fp, #-8]
    // 0xb02258: LoadField: r0 = r1->field_f
    //     0xb02258: ldur            w0, [x1, #0xf]
    // 0xb0225c: DecompressPointer r0
    //     0xb0225c: add             x0, x0, HEAP, lsl #32
    // 0xb02260: mov             x1, x0
    // 0xb02264: LoadField: r0 = r1->field_3b
    //     0xb02264: ldur            w0, [x1, #0x3b]
    // 0xb02268: DecompressPointer r0
    //     0xb02268: add             x0, x0, HEAP, lsl #32
    // 0xb0226c: r16 = Sentinel
    //     0xb0226c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb02270: cmp             w0, w16
    // 0xb02274: b.ne            #0xb02284
    // 0xb02278: r2 = _colors
    //     0xb02278: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb0227c: ldr             x2, [x2, #0xf50]
    // 0xb02280: r0 = InitLateFinalInstanceField()
    //     0xb02280: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb02284: LoadField: r1 = r0->field_b
    //     0xb02284: ldur            w1, [x0, #0xb]
    // 0xb02288: DecompressPointer r1
    //     0xb02288: add             x1, x1, HEAP, lsl #32
    // 0xb0228c: SaveReg r1
    //     0xb0228c: str             x1, [SP, #-8]!
    // 0xb02290: d1 = 0.120000
    //     0xb02290: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb02294: ldr             d1, [x17, #0xf48]
    // 0xb02298: SaveReg d1
    //     0xb02298: str             d1, [SP, #-8]!
    // 0xb0229c: r0 = withOpacity()
    //     0xb0229c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb022a0: add             SP, SP, #0x10
    // 0xb022a4: LeaveFrame
    //     0xb022a4: mov             SP, fp
    //     0xb022a8: ldp             fp, lr, [SP], #0x10
    // 0xb022ac: ret
    //     0xb022ac: ret             
    // 0xb022b0: r0 = Null
    //     0xb022b0: mov             x0, NULL
    // 0xb022b4: LeaveFrame
    //     0xb022b4: mov             SP, fp
    //     0xb022b8: ldp             fp, lr, [SP], #0x10
    // 0xb022bc: ret
    //     0xb022bc: ret             
    // 0xb022c0: ldr             x2, [fp, #0x10]
    // 0xb022c4: ldur            x1, [fp, #-8]
    // 0xb022c8: d0 = 0.080000
    //     0xb022c8: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb022cc: ldr             d0, [x17, #0xf80]
    // 0xb022d0: d1 = 0.120000
    //     0xb022d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb022d4: ldr             d1, [x17, #0xf48]
    // 0xb022d8: r0 = LoadClassIdInstr(r2)
    //     0xb022d8: ldur            x0, [x2, #-1]
    //     0xb022dc: ubfx            x0, x0, #0xc, #0x14
    // 0xb022e0: r16 = Instance_MaterialState
    //     0xb022e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xb022e4: ldr             x16, [x16, #0xf78]
    // 0xb022e8: stp             x16, x2, [SP, #-0x10]!
    // 0xb022ec: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb022ec: mov             x17, #0xc98a
    //     0xb022f0: add             lr, x0, x17
    //     0xb022f4: ldr             lr, [x21, lr, lsl #3]
    //     0xb022f8: blr             lr
    // 0xb022fc: add             SP, SP, #0x10
    // 0xb02300: tbnz            w0, #4, #0xb02360
    // 0xb02304: ldur            x1, [fp, #-8]
    // 0xb02308: LoadField: r0 = r1->field_f
    //     0xb02308: ldur            w0, [x1, #0xf]
    // 0xb0230c: DecompressPointer r0
    //     0xb0230c: add             x0, x0, HEAP, lsl #32
    // 0xb02310: mov             x1, x0
    // 0xb02314: LoadField: r0 = r1->field_3b
    //     0xb02314: ldur            w0, [x1, #0x3b]
    // 0xb02318: DecompressPointer r0
    //     0xb02318: add             x0, x0, HEAP, lsl #32
    // 0xb0231c: r16 = Sentinel
    //     0xb0231c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb02320: cmp             w0, w16
    // 0xb02324: b.ne            #0xb02334
    // 0xb02328: r2 = _colors
    //     0xb02328: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb0232c: ldr             x2, [x2, #0xf50]
    // 0xb02330: r0 = InitLateFinalInstanceField()
    //     0xb02330: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb02334: LoadField: r1 = r0->field_57
    //     0xb02334: ldur            w1, [x0, #0x57]
    // 0xb02338: DecompressPointer r1
    //     0xb02338: add             x1, x1, HEAP, lsl #32
    // 0xb0233c: SaveReg r1
    //     0xb0233c: str             x1, [SP, #-8]!
    // 0xb02340: d0 = 0.080000
    //     0xb02340: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xb02344: ldr             d0, [x17, #0xf80]
    // 0xb02348: SaveReg d0
    //     0xb02348: str             d0, [SP, #-8]!
    // 0xb0234c: r0 = withOpacity()
    //     0xb0234c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb02350: add             SP, SP, #0x10
    // 0xb02354: LeaveFrame
    //     0xb02354: mov             SP, fp
    //     0xb02358: ldp             fp, lr, [SP], #0x10
    // 0xb0235c: ret
    //     0xb0235c: ret             
    // 0xb02360: ldr             x2, [fp, #0x10]
    // 0xb02364: ldur            x1, [fp, #-8]
    // 0xb02368: r0 = LoadClassIdInstr(r2)
    //     0xb02368: ldur            x0, [x2, #-1]
    //     0xb0236c: ubfx            x0, x0, #0xc, #0x14
    // 0xb02370: r16 = Instance_MaterialState
    //     0xb02370: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xb02374: ldr             x16, [x16, #0xf88]
    // 0xb02378: stp             x16, x2, [SP, #-0x10]!
    // 0xb0237c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb0237c: mov             x17, #0xc98a
    //     0xb02380: add             lr, x0, x17
    //     0xb02384: ldr             lr, [x21, lr, lsl #3]
    //     0xb02388: blr             lr
    // 0xb0238c: add             SP, SP, #0x10
    // 0xb02390: tbnz            w0, #4, #0xb023f0
    // 0xb02394: ldur            x1, [fp, #-8]
    // 0xb02398: LoadField: r0 = r1->field_f
    //     0xb02398: ldur            w0, [x1, #0xf]
    // 0xb0239c: DecompressPointer r0
    //     0xb0239c: add             x0, x0, HEAP, lsl #32
    // 0xb023a0: mov             x1, x0
    // 0xb023a4: LoadField: r0 = r1->field_3b
    //     0xb023a4: ldur            w0, [x1, #0x3b]
    // 0xb023a8: DecompressPointer r0
    //     0xb023a8: add             x0, x0, HEAP, lsl #32
    // 0xb023ac: r16 = Sentinel
    //     0xb023ac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb023b0: cmp             w0, w16
    // 0xb023b4: b.ne            #0xb023c4
    // 0xb023b8: r2 = _colors
    //     0xb023b8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb023bc: ldr             x2, [x2, #0xf50]
    // 0xb023c0: r0 = InitLateFinalInstanceField()
    //     0xb023c0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb023c4: LoadField: r1 = r0->field_57
    //     0xb023c4: ldur            w1, [x0, #0x57]
    // 0xb023c8: DecompressPointer r1
    //     0xb023c8: add             x1, x1, HEAP, lsl #32
    // 0xb023cc: SaveReg r1
    //     0xb023cc: str             x1, [SP, #-8]!
    // 0xb023d0: d0 = 0.120000
    //     0xb023d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb023d4: ldr             d0, [x17, #0xf48]
    // 0xb023d8: SaveReg d0
    //     0xb023d8: str             d0, [SP, #-8]!
    // 0xb023dc: r0 = withOpacity()
    //     0xb023dc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb023e0: add             SP, SP, #0x10
    // 0xb023e4: LeaveFrame
    //     0xb023e4: mov             SP, fp
    //     0xb023e8: ldp             fp, lr, [SP], #0x10
    // 0xb023ec: ret
    //     0xb023ec: ret             
    // 0xb023f0: ldr             x0, [fp, #0x10]
    // 0xb023f4: ldur            x1, [fp, #-8]
    // 0xb023f8: d0 = 0.120000
    //     0xb023f8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb023fc: ldr             d0, [x17, #0xf48]
    // 0xb02400: r2 = LoadClassIdInstr(r0)
    //     0xb02400: ldur            x2, [x0, #-1]
    //     0xb02404: ubfx            x2, x2, #0xc, #0x14
    // 0xb02408: r16 = Instance_MaterialState
    //     0xb02408: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xb0240c: ldr             x16, [x16, #0xf90]
    // 0xb02410: stp             x16, x0, [SP, #-0x10]!
    // 0xb02414: mov             x0, x2
    // 0xb02418: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xb02418: mov             x17, #0xc98a
    //     0xb0241c: add             lr, x0, x17
    //     0xb02420: ldr             lr, [x21, lr, lsl #3]
    //     0xb02424: blr             lr
    // 0xb02428: add             SP, SP, #0x10
    // 0xb0242c: tbnz            w0, #4, #0xb02488
    // 0xb02430: ldur            x0, [fp, #-8]
    // 0xb02434: LoadField: r1 = r0->field_f
    //     0xb02434: ldur            w1, [x0, #0xf]
    // 0xb02438: DecompressPointer r1
    //     0xb02438: add             x1, x1, HEAP, lsl #32
    // 0xb0243c: LoadField: r0 = r1->field_3b
    //     0xb0243c: ldur            w0, [x1, #0x3b]
    // 0xb02440: DecompressPointer r0
    //     0xb02440: add             x0, x0, HEAP, lsl #32
    // 0xb02444: r16 = Sentinel
    //     0xb02444: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb02448: cmp             w0, w16
    // 0xb0244c: b.ne            #0xb0245c
    // 0xb02450: r2 = _colors
    //     0xb02450: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xb02454: ldr             x2, [x2, #0xf50]
    // 0xb02458: r0 = InitLateFinalInstanceField()
    //     0xb02458: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xb0245c: LoadField: r1 = r0->field_b
    //     0xb0245c: ldur            w1, [x0, #0xb]
    // 0xb02460: DecompressPointer r1
    //     0xb02460: add             x1, x1, HEAP, lsl #32
    // 0xb02464: SaveReg r1
    //     0xb02464: str             x1, [SP, #-8]!
    // 0xb02468: d0 = 0.120000
    //     0xb02468: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb0246c: ldr             d0, [x17, #0xf48]
    // 0xb02470: SaveReg d0
    //     0xb02470: str             d0, [SP, #-8]!
    // 0xb02474: r0 = withOpacity()
    //     0xb02474: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb02478: add             SP, SP, #0x10
    // 0xb0247c: LeaveFrame
    //     0xb0247c: mov             SP, fp
    //     0xb02480: ldp             fp, lr, [SP], #0x10
    // 0xb02484: ret
    //     0xb02484: ret             
    // 0xb02488: r0 = Null
    //     0xb02488: mov             x0, NULL
    // 0xb0248c: LeaveFrame
    //     0xb0248c: mov             SP, fp
    //     0xb02490: ldp             fp, lr, [SP], #0x10
    // 0xb02494: ret
    //     0xb02494: ret             
    // 0xb02498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb02498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb0249c: b               #0xb020cc
  }
  get _ splashFactory(/* No info */) {
    // ** addr: 0xcebca0, size: 0x4c
    // 0xcebca0: EnterFrame
    //     0xcebca0: stp             fp, lr, [SP, #-0x10]!
    //     0xcebca4: mov             fp, SP
    // 0xcebca8: CheckStackOverflow
    //     0xcebca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebcac: cmp             SP, x16
    //     0xcebcb0: b.ls            #0xcebce4
    // 0xcebcb4: ldr             x0, [fp, #0x10]
    // 0xcebcb8: LoadField: r1 = r0->field_37
    //     0xcebcb8: ldur            w1, [x0, #0x37]
    // 0xcebcbc: DecompressPointer r1
    //     0xcebcbc: add             x1, x1, HEAP, lsl #32
    // 0xcebcc0: SaveReg r1
    //     0xcebcc0: str             x1, [SP, #-8]!
    // 0xcebcc4: r0 = of()
    //     0xcebcc4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcebcc8: add             SP, SP, #8
    // 0xcebccc: LoadField: r1 = r0->field_27
    //     0xcebccc: ldur            w1, [x0, #0x27]
    // 0xcebcd0: DecompressPointer r1
    //     0xcebcd0: add             x1, x1, HEAP, lsl #32
    // 0xcebcd4: mov             x0, x1
    // 0xcebcd8: LeaveFrame
    //     0xcebcd8: mov             SP, fp
    //     0xcebcdc: ldp             fp, lr, [SP], #0x10
    // 0xcebce0: ret
    //     0xcebce0: ret             
    // 0xcebce4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcebce4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcebce8: b               #0xcebcb4
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xcebcec, size: 0x64
    // 0xcebcec: EnterFrame
    //     0xcebcec: stp             fp, lr, [SP, #-0x10]!
    //     0xcebcf0: mov             fp, SP
    // 0xcebcf4: CheckStackOverflow
    //     0xcebcf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebcf8: cmp             SP, x16
    //     0xcebcfc: b.ls            #0xcebd48
    // 0xcebd00: r1 = 1
    //     0xcebd00: mov             x1, #1
    // 0xcebd04: r0 = AllocateContext()
    //     0xcebd04: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcebd08: mov             x1, x0
    // 0xcebd0c: ldr             x0, [fp, #0x10]
    // 0xcebd10: StoreField: r1->field_f = r0
    //     0xcebd10: stur            w0, [x1, #0xf]
    // 0xcebd14: mov             x2, x1
    // 0xcebd18: r1 = Function '<anonymous closure>':.
    //     0xcebd18: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf60] AnonymousClosure: (0xb020a4), in [package:flutter/src/material/tabs.dart] _TabsDefaultsM3::overlayColor (0xcebcec)
    //     0xcebd1c: ldr             x1, [x1, #0xf60]
    // 0xcebd20: r0 = AllocateClosure()
    //     0xcebd20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcebd24: r16 = <Color?>
    //     0xcebd24: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xcebd28: ldr             x16, [x16, #0xf68]
    // 0xcebd2c: stp             x0, x16, [SP, #-0x10]!
    // 0xcebd30: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcebd30: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcebd34: r0 = resolveWith()
    //     0xcebd34: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xcebd38: add             SP, SP, #0x10
    // 0xcebd3c: LeaveFrame
    //     0xcebd3c: mov             SP, fp
    //     0xcebd40: ldp             fp, lr, [SP], #0x10
    // 0xcebd44: ret
    //     0xcebd44: ret             
    // 0xcebd48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcebd48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcebd4c: b               #0xcebd00
  }
}

// class id: 2724, size: 0x3c, field offset: 0x38
//   const constructor, 
class _TabsDefaultsM2 extends TabBarTheme {
}

// class id: 3271, size: 0x30, field offset: 0x14
class _TabBarViewState extends State<TabBarView> {

  late PageController _pageController; // offset: 0x18
  late List<Widget> _childrenWithKey; // offset: 0x20
  late List<Widget> _children; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bde8c, size: 0x1e8
    // 0x7bde8c: EnterFrame
    //     0x7bde8c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bde90: mov             fp, SP
    // 0x7bde94: CheckStackOverflow
    //     0x7bde94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bde98: cmp             SP, x16
    //     0x7bde9c: b.ls            #0x7be054
    // 0x7bdea0: ldr             x0, [fp, #0x10]
    // 0x7bdea4: r2 = Null
    //     0x7bdea4: mov             x2, NULL
    // 0x7bdea8: r1 = Null
    //     0x7bdea8: mov             x1, NULL
    // 0x7bdeac: r4 = 59
    //     0x7bdeac: mov             x4, #0x3b
    // 0x7bdeb0: branchIfSmi(r0, 0x7bdebc)
    //     0x7bdeb0: tbz             w0, #0, #0x7bdebc
    // 0x7bdeb4: r4 = LoadClassIdInstr(r0)
    //     0x7bdeb4: ldur            x4, [x0, #-1]
    //     0x7bdeb8: ubfx            x4, x4, #0xc, #0x14
    // 0x7bdebc: r17 = 4116
    //     0x7bdebc: mov             x17, #0x1014
    // 0x7bdec0: cmp             x4, x17
    // 0x7bdec4: b.eq            #0x7bdedc
    // 0x7bdec8: r8 = TabBarView
    //     0x7bdec8: add             x8, PP, #0x38, lsl #12  ; [pp+0x380d8] Type: TabBarView
    //     0x7bdecc: ldr             x8, [x8, #0xd8]
    // 0x7bded0: r3 = Null
    //     0x7bded0: add             x3, PP, #0x38, lsl #12  ; [pp+0x380e0] Null
    //     0x7bded4: ldr             x3, [x3, #0xe0]
    // 0x7bded8: r0 = TabBarView()
    //     0x7bded8: bl              #0x7becf0  ; IsType_TabBarView_Stub
    // 0x7bdedc: ldr             x3, [fp, #0x18]
    // 0x7bdee0: LoadField: r2 = r3->field_7
    //     0x7bdee0: ldur            w2, [x3, #7]
    // 0x7bdee4: DecompressPointer r2
    //     0x7bdee4: add             x2, x2, HEAP, lsl #32
    // 0x7bdee8: ldr             x0, [fp, #0x10]
    // 0x7bdeec: r1 = Null
    //     0x7bdeec: mov             x1, NULL
    // 0x7bdef0: cmp             w2, NULL
    // 0x7bdef4: b.eq            #0x7bdf18
    // 0x7bdef8: LoadField: r4 = r2->field_17
    //     0x7bdef8: ldur            w4, [x2, #0x17]
    // 0x7bdefc: DecompressPointer r4
    //     0x7bdefc: add             x4, x4, HEAP, lsl #32
    // 0x7bdf00: r8 = X0 bound StatefulWidget
    //     0x7bdf00: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bdf04: ldr             x8, [x8, #0x858]
    // 0x7bdf08: LoadField: r9 = r4->field_7
    //     0x7bdf08: ldur            x9, [x4, #7]
    // 0x7bdf0c: r3 = Null
    //     0x7bdf0c: add             x3, PP, #0x38, lsl #12  ; [pp+0x380f0] Null
    //     0x7bdf10: ldr             x3, [x3, #0xf0]
    // 0x7bdf14: blr             x9
    // 0x7bdf18: ldr             x0, [fp, #0x18]
    // 0x7bdf1c: LoadField: r1 = r0->field_b
    //     0x7bdf1c: ldur            w1, [x0, #0xb]
    // 0x7bdf20: DecompressPointer r1
    //     0x7bdf20: add             x1, x1, HEAP, lsl #32
    // 0x7bdf24: cmp             w1, NULL
    // 0x7bdf28: b.eq            #0x7be05c
    // 0x7bdf2c: LoadField: r2 = r1->field_b
    //     0x7bdf2c: ldur            w2, [x1, #0xb]
    // 0x7bdf30: DecompressPointer r2
    //     0x7bdf30: add             x2, x2, HEAP, lsl #32
    // 0x7bdf34: ldr             x1, [fp, #0x10]
    // 0x7bdf38: LoadField: r3 = r1->field_b
    //     0x7bdf38: ldur            w3, [x1, #0xb]
    // 0x7bdf3c: DecompressPointer r3
    //     0x7bdf3c: add             x3, x3, HEAP, lsl #32
    // 0x7bdf40: cmp             w2, w3
    // 0x7bdf44: b.eq            #0x7bdfe4
    // 0x7bdf48: SaveReg r0
    //     0x7bdf48: str             x0, [SP, #-8]!
    // 0x7bdf4c: r0 = _updateTabController()
    //     0x7bdf4c: bl              #0x7be10c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateTabController
    // 0x7bdf50: add             SP, SP, #8
    // 0x7bdf54: ldr             x2, [fp, #0x18]
    // 0x7bdf58: LoadField: r0 = r2->field_13
    //     0x7bdf58: ldur            w0, [x2, #0x13]
    // 0x7bdf5c: DecompressPointer r0
    //     0x7bdf5c: add             x0, x0, HEAP, lsl #32
    // 0x7bdf60: cmp             w0, NULL
    // 0x7bdf64: b.eq            #0x7be060
    // 0x7bdf68: LoadField: r3 = r0->field_33
    //     0x7bdf68: ldur            x3, [x0, #0x33]
    // 0x7bdf6c: r0 = BoxInt64Instr(r3)
    //     0x7bdf6c: sbfiz           x0, x3, #1, #0x1f
    //     0x7bdf70: cmp             x3, x0, asr #1
    //     0x7bdf74: b.eq            #0x7bdf80
    //     0x7bdf78: bl              #0xd69bb8
    //     0x7bdf7c: stur            x3, [x0, #7]
    // 0x7bdf80: mov             x1, x0
    // 0x7bdf84: StoreField: r2->field_23 = r0
    //     0x7bdf84: stur            w0, [x2, #0x23]
    //     0x7bdf88: tbz             w0, #0, #0x7bdfa4
    //     0x7bdf8c: ldurb           w16, [x2, #-1]
    //     0x7bdf90: ldurb           w17, [x0, #-1]
    //     0x7bdf94: and             x16, x17, x16, lsr #2
    //     0x7bdf98: tst             x16, HEAP, lsr #32
    //     0x7bdf9c: b.eq            #0x7bdfa4
    //     0x7bdfa0: bl              #0xd6828c
    // 0x7bdfa4: LoadField: r0 = r2->field_27
    //     0x7bdfa4: ldur            x0, [x2, #0x27]
    // 0x7bdfa8: add             x3, x0, #1
    // 0x7bdfac: StoreField: r2->field_27 = r3
    //     0x7bdfac: stur            x3, [x2, #0x27]
    // 0x7bdfb0: LoadField: r0 = r2->field_17
    //     0x7bdfb0: ldur            w0, [x2, #0x17]
    // 0x7bdfb4: DecompressPointer r0
    //     0x7bdfb4: add             x0, x0, HEAP, lsl #32
    // 0x7bdfb8: r16 = Sentinel
    //     0x7bdfb8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bdfbc: cmp             w0, w16
    // 0x7bdfc0: b.eq            #0x7be064
    // 0x7bdfc4: stp             x1, x0, [SP, #-0x10]!
    // 0x7bdfc8: r0 = jumpToPage()
    //     0x7bdfc8: bl              #0x7a1e1c  ; [package:flutter/src/widgets/page_view.dart] PageController::jumpToPage
    // 0x7bdfcc: add             SP, SP, #0x10
    // 0x7bdfd0: ldr             x1, [fp, #0x18]
    // 0x7bdfd4: LoadField: r0 = r1->field_27
    //     0x7bdfd4: ldur            x0, [x1, #0x27]
    // 0x7bdfd8: sub             x2, x0, #1
    // 0x7bdfdc: StoreField: r1->field_27 = r2
    //     0x7bdfdc: stur            x2, [x1, #0x27]
    // 0x7bdfe0: b               #0x7bdfe8
    // 0x7bdfe4: mov             x1, x0
    // 0x7bdfe8: ldr             x0, [fp, #0x10]
    // 0x7bdfec: LoadField: r2 = r1->field_b
    //     0x7bdfec: ldur            w2, [x1, #0xb]
    // 0x7bdff0: DecompressPointer r2
    //     0x7bdff0: add             x2, x2, HEAP, lsl #32
    // 0x7bdff4: cmp             w2, NULL
    // 0x7bdff8: b.eq            #0x7be070
    // 0x7bdffc: LoadField: r3 = r2->field_f
    //     0x7bdffc: ldur            w3, [x2, #0xf]
    // 0x7be000: DecompressPointer r3
    //     0x7be000: add             x3, x3, HEAP, lsl #32
    // 0x7be004: LoadField: r2 = r0->field_f
    //     0x7be004: ldur            w2, [x0, #0xf]
    // 0x7be008: DecompressPointer r2
    //     0x7be008: add             x2, x2, HEAP, lsl #32
    // 0x7be00c: r0 = LoadClassIdInstr(r3)
    //     0x7be00c: ldur            x0, [x3, #-1]
    //     0x7be010: ubfx            x0, x0, #0xc, #0x14
    // 0x7be014: stp             x2, x3, [SP, #-0x10]!
    // 0x7be018: mov             lr, x0
    // 0x7be01c: ldr             lr, [x21, lr, lsl #3]
    // 0x7be020: blr             lr
    // 0x7be024: add             SP, SP, #0x10
    // 0x7be028: tbz             w0, #4, #0x7be044
    // 0x7be02c: ldr             x0, [fp, #0x18]
    // 0x7be030: LoadField: r1 = r0->field_27
    //     0x7be030: ldur            x1, [x0, #0x27]
    // 0x7be034: cbnz            x1, #0x7be044
    // 0x7be038: SaveReg r0
    //     0x7be038: str             x0, [SP, #-8]!
    // 0x7be03c: r0 = _updateChildren()
    //     0x7be03c: bl              #0x7be074  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0x7be040: add             SP, SP, #8
    // 0x7be044: r0 = Null
    //     0x7be044: mov             x0, NULL
    // 0x7be048: LeaveFrame
    //     0x7be048: mov             SP, fp
    //     0x7be04c: ldp             fp, lr, [SP], #0x10
    // 0x7be050: ret
    //     0x7be050: ret             
    // 0x7be054: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7be054: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7be058: b               #0x7bdea0
    // 0x7be05c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be05c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be060: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be064: r9 = _pageController
    //     0x7be064: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff0] Field <_TabBarViewState@472014024._pageController@472014024>: late (offset: 0x18)
    //     0x7be068: ldr             x9, [x9, #0xff0]
    // 0x7be06c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7be06c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7be070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateChildren(/* No info */) {
    // ** addr: 0x7be074, size: 0x98
    // 0x7be074: EnterFrame
    //     0x7be074: stp             fp, lr, [SP, #-0x10]!
    //     0x7be078: mov             fp, SP
    // 0x7be07c: CheckStackOverflow
    //     0x7be07c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7be080: cmp             SP, x16
    //     0x7be084: b.ls            #0x7be100
    // 0x7be088: ldr             x1, [fp, #0x10]
    // 0x7be08c: LoadField: r0 = r1->field_b
    //     0x7be08c: ldur            w0, [x1, #0xb]
    // 0x7be090: DecompressPointer r0
    //     0x7be090: add             x0, x0, HEAP, lsl #32
    // 0x7be094: cmp             w0, NULL
    // 0x7be098: b.eq            #0x7be108
    // 0x7be09c: LoadField: r2 = r0->field_f
    //     0x7be09c: ldur            w2, [x0, #0xf]
    // 0x7be0a0: DecompressPointer r2
    //     0x7be0a0: add             x2, x2, HEAP, lsl #32
    // 0x7be0a4: mov             x0, x2
    // 0x7be0a8: StoreField: r1->field_1b = r0
    //     0x7be0a8: stur            w0, [x1, #0x1b]
    //     0x7be0ac: ldurb           w16, [x1, #-1]
    //     0x7be0b0: ldurb           w17, [x0, #-1]
    //     0x7be0b4: and             x16, x17, x16, lsr #2
    //     0x7be0b8: tst             x16, HEAP, lsr #32
    //     0x7be0bc: b.eq            #0x7be0c4
    //     0x7be0c0: bl              #0xd6826c
    // 0x7be0c4: SaveReg r2
    //     0x7be0c4: str             x2, [SP, #-8]!
    // 0x7be0c8: r0 = ensureUniqueKeysForList()
    //     0x7be0c8: bl              #0x7a1268  ; [package:flutter/src/widgets/basic.dart] KeyedSubtree::ensureUniqueKeysForList
    // 0x7be0cc: add             SP, SP, #8
    // 0x7be0d0: ldr             x1, [fp, #0x10]
    // 0x7be0d4: StoreField: r1->field_1f = r0
    //     0x7be0d4: stur            w0, [x1, #0x1f]
    //     0x7be0d8: ldurb           w16, [x1, #-1]
    //     0x7be0dc: ldurb           w17, [x0, #-1]
    //     0x7be0e0: and             x16, x17, x16, lsr #2
    //     0x7be0e4: tst             x16, HEAP, lsr #32
    //     0x7be0e8: b.eq            #0x7be0f0
    //     0x7be0ec: bl              #0xd6826c
    // 0x7be0f0: r0 = Null
    //     0x7be0f0: mov             x0, NULL
    // 0x7be0f4: LeaveFrame
    //     0x7be0f4: mov             SP, fp
    //     0x7be0f8: ldp             fp, lr, [SP], #0x10
    // 0x7be0fc: ret
    //     0x7be0fc: ret             
    // 0x7be100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7be100: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7be104: b               #0x7be088
    // 0x7be108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be108: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTabController(/* No info */) {
    // ** addr: 0x7be10c, size: 0x1bc
    // 0x7be10c: EnterFrame
    //     0x7be10c: stp             fp, lr, [SP, #-0x10]!
    //     0x7be110: mov             fp, SP
    // 0x7be114: AllocStack(0x10)
    //     0x7be114: sub             SP, SP, #0x10
    // 0x7be118: CheckStackOverflow
    //     0x7be118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7be11c: cmp             SP, x16
    //     0x7be120: b.ls            #0x7be2ac
    // 0x7be124: ldr             x0, [fp, #0x10]
    // 0x7be128: LoadField: r1 = r0->field_b
    //     0x7be128: ldur            w1, [x0, #0xb]
    // 0x7be12c: DecompressPointer r1
    //     0x7be12c: add             x1, x1, HEAP, lsl #32
    // 0x7be130: cmp             w1, NULL
    // 0x7be134: b.eq            #0x7be2b4
    // 0x7be138: LoadField: r2 = r1->field_b
    //     0x7be138: ldur            w2, [x1, #0xb]
    // 0x7be13c: DecompressPointer r2
    //     0x7be13c: add             x2, x2, HEAP, lsl #32
    // 0x7be140: cmp             w2, NULL
    // 0x7be144: b.ne            #0x7be16c
    // 0x7be148: LoadField: r1 = r0->field_f
    //     0x7be148: ldur            w1, [x0, #0xf]
    // 0x7be14c: DecompressPointer r1
    //     0x7be14c: add             x1, x1, HEAP, lsl #32
    // 0x7be150: cmp             w1, NULL
    // 0x7be154: b.eq            #0x7be2b8
    // 0x7be158: SaveReg r1
    //     0x7be158: str             x1, [SP, #-8]!
    // 0x7be15c: r0 = maybeOf()
    //     0x7be15c: bl              #0x7bd23c  ; [package:flutter/src/material/tab_controller.dart] DefaultTabController::maybeOf
    // 0x7be160: add             SP, SP, #8
    // 0x7be164: mov             x1, x0
    // 0x7be168: b               #0x7be170
    // 0x7be16c: mov             x1, x2
    // 0x7be170: ldr             x0, [fp, #0x10]
    // 0x7be174: stur            x1, [fp, #-8]
    // 0x7be178: LoadField: r2 = r0->field_13
    //     0x7be178: ldur            w2, [x0, #0x13]
    // 0x7be17c: DecompressPointer r2
    //     0x7be17c: add             x2, x2, HEAP, lsl #32
    // 0x7be180: cmp             w1, w2
    // 0x7be184: b.ne            #0x7be198
    // 0x7be188: r0 = Null
    //     0x7be188: mov             x0, NULL
    // 0x7be18c: LeaveFrame
    //     0x7be18c: mov             SP, fp
    //     0x7be190: ldp             fp, lr, [SP], #0x10
    // 0x7be194: ret
    //     0x7be194: ret             
    // 0x7be198: SaveReg r0
    //     0x7be198: str             x0, [SP, #-8]!
    // 0x7be19c: r0 = _controllerIsValid()
    //     0x7be19c: bl              #0x7be2c8  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_controllerIsValid
    // 0x7be1a0: add             SP, SP, #8
    // 0x7be1a4: tbnz            w0, #4, #0x7be218
    // 0x7be1a8: ldr             x0, [fp, #0x10]
    // 0x7be1ac: LoadField: r1 = r0->field_13
    //     0x7be1ac: ldur            w1, [x0, #0x13]
    // 0x7be1b0: DecompressPointer r1
    //     0x7be1b0: add             x1, x1, HEAP, lsl #32
    // 0x7be1b4: cmp             w1, NULL
    // 0x7be1b8: b.eq            #0x7be2bc
    // 0x7be1bc: LoadField: r2 = r1->field_23
    //     0x7be1bc: ldur            w2, [x1, #0x23]
    // 0x7be1c0: DecompressPointer r2
    //     0x7be1c0: add             x2, x2, HEAP, lsl #32
    // 0x7be1c4: cmp             w2, NULL
    // 0x7be1c8: b.ne            #0x7be1d4
    // 0x7be1cc: r1 = Null
    //     0x7be1cc: mov             x1, NULL
    // 0x7be1d0: b               #0x7be1d8
    // 0x7be1d4: mov             x1, x2
    // 0x7be1d8: stur            x1, [fp, #-0x10]
    // 0x7be1dc: cmp             w1, NULL
    // 0x7be1e0: b.eq            #0x7be2c0
    // 0x7be1e4: r1 = 1
    //     0x7be1e4: mov             x1, #1
    // 0x7be1e8: r0 = AllocateContext()
    //     0x7be1e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7be1ec: mov             x1, x0
    // 0x7be1f0: ldr             x0, [fp, #0x10]
    // 0x7be1f4: StoreField: r1->field_f = r0
    //     0x7be1f4: stur            w0, [x1, #0xf]
    // 0x7be1f8: mov             x2, x1
    // 0x7be1fc: r1 = Function '_handleTabControllerAnimationTick@472014024':.
    //     0x7be1fc: add             x1, PP, #0x38, lsl #12  ; [pp+0x38050] AnonymousClosure: (0x7be30c), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick (0x7be354)
    //     0x7be200: ldr             x1, [x1, #0x50]
    // 0x7be204: r0 = AllocateClosure()
    //     0x7be204: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7be208: ldur            x16, [fp, #-0x10]
    // 0x7be20c: stp             x0, x16, [SP, #-0x10]!
    // 0x7be210: r0 = removeListener()
    //     0x7be210: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x7be214: add             SP, SP, #0x10
    // 0x7be218: ldr             x1, [fp, #0x10]
    // 0x7be21c: ldur            x2, [fp, #-8]
    // 0x7be220: mov             x0, x2
    // 0x7be224: StoreField: r1->field_13 = r0
    //     0x7be224: stur            w0, [x1, #0x13]
    //     0x7be228: ldurb           w16, [x1, #-1]
    //     0x7be22c: ldurb           w17, [x0, #-1]
    //     0x7be230: and             x16, x17, x16, lsr #2
    //     0x7be234: tst             x16, HEAP, lsr #32
    //     0x7be238: b.eq            #0x7be240
    //     0x7be23c: bl              #0xd6826c
    // 0x7be240: cmp             w2, NULL
    // 0x7be244: b.eq            #0x7be29c
    // 0x7be248: LoadField: r0 = r2->field_23
    //     0x7be248: ldur            w0, [x2, #0x23]
    // 0x7be24c: DecompressPointer r0
    //     0x7be24c: add             x0, x0, HEAP, lsl #32
    // 0x7be250: cmp             w0, NULL
    // 0x7be254: b.ne            #0x7be25c
    // 0x7be258: r0 = Null
    //     0x7be258: mov             x0, NULL
    // 0x7be25c: stur            x0, [fp, #-8]
    // 0x7be260: cmp             w0, NULL
    // 0x7be264: b.eq            #0x7be2c4
    // 0x7be268: r1 = 1
    //     0x7be268: mov             x1, #1
    // 0x7be26c: r0 = AllocateContext()
    //     0x7be26c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7be270: mov             x1, x0
    // 0x7be274: ldr             x0, [fp, #0x10]
    // 0x7be278: StoreField: r1->field_f = r0
    //     0x7be278: stur            w0, [x1, #0xf]
    // 0x7be27c: mov             x2, x1
    // 0x7be280: r1 = Function '_handleTabControllerAnimationTick@472014024':.
    //     0x7be280: add             x1, PP, #0x38, lsl #12  ; [pp+0x38050] AnonymousClosure: (0x7be30c), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick (0x7be354)
    //     0x7be284: ldr             x1, [x1, #0x50]
    // 0x7be288: r0 = AllocateClosure()
    //     0x7be288: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7be28c: ldur            x16, [fp, #-8]
    // 0x7be290: stp             x0, x16, [SP, #-0x10]!
    // 0x7be294: r0 = addActionListener()
    //     0x7be294: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x7be298: add             SP, SP, #0x10
    // 0x7be29c: r0 = Null
    //     0x7be29c: mov             x0, NULL
    // 0x7be2a0: LeaveFrame
    //     0x7be2a0: mov             SP, fp
    //     0x7be2a4: ldp             fp, lr, [SP], #0x10
    // 0x7be2a8: ret
    //     0x7be2a8: ret             
    // 0x7be2ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7be2ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7be2b0: b               #0x7be124
    // 0x7be2b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be2b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be2b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be2b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be2bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be2bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be2c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be2c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be2c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be2c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _controllerIsValid(/* No info */) {
    // ** addr: 0x7be2c8, size: 0x44
    // 0x7be2c8: ldr             x1, [SP]
    // 0x7be2cc: LoadField: r2 = r1->field_13
    //     0x7be2cc: ldur            w2, [x1, #0x13]
    // 0x7be2d0: DecompressPointer r2
    //     0x7be2d0: add             x2, x2, HEAP, lsl #32
    // 0x7be2d4: cmp             w2, NULL
    // 0x7be2d8: b.ne            #0x7be2e4
    // 0x7be2dc: r1 = Null
    //     0x7be2dc: mov             x1, NULL
    // 0x7be2e0: b               #0x7be2f8
    // 0x7be2e4: LoadField: r1 = r2->field_23
    //     0x7be2e4: ldur            w1, [x2, #0x23]
    // 0x7be2e8: DecompressPointer r1
    //     0x7be2e8: add             x1, x1, HEAP, lsl #32
    // 0x7be2ec: cmp             w1, NULL
    // 0x7be2f0: b.ne            #0x7be2f8
    // 0x7be2f4: r1 = Null
    //     0x7be2f4: mov             x1, NULL
    // 0x7be2f8: cmp             w1, NULL
    // 0x7be2fc: r16 = true
    //     0x7be2fc: add             x16, NULL, #0x20  ; true
    // 0x7be300: r17 = false
    //     0x7be300: add             x17, NULL, #0x30  ; false
    // 0x7be304: csel            x0, x16, x17, ne
    // 0x7be308: ret
    //     0x7be308: ret             
  }
  [closure] void _handleTabControllerAnimationTick(dynamic) {
    // ** addr: 0x7be30c, size: 0x48
    // 0x7be30c: EnterFrame
    //     0x7be30c: stp             fp, lr, [SP, #-0x10]!
    //     0x7be310: mov             fp, SP
    // 0x7be314: ldr             x0, [fp, #0x10]
    // 0x7be318: LoadField: r1 = r0->field_17
    //     0x7be318: ldur            w1, [x0, #0x17]
    // 0x7be31c: DecompressPointer r1
    //     0x7be31c: add             x1, x1, HEAP, lsl #32
    // 0x7be320: CheckStackOverflow
    //     0x7be320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7be324: cmp             SP, x16
    //     0x7be328: b.ls            #0x7be34c
    // 0x7be32c: LoadField: r0 = r1->field_f
    //     0x7be32c: ldur            w0, [x1, #0xf]
    // 0x7be330: DecompressPointer r0
    //     0x7be330: add             x0, x0, HEAP, lsl #32
    // 0x7be334: SaveReg r0
    //     0x7be334: str             x0, [SP, #-8]!
    // 0x7be338: r0 = _handleTabControllerAnimationTick()
    //     0x7be338: bl              #0x7be354  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick
    // 0x7be33c: add             SP, SP, #8
    // 0x7be340: LeaveFrame
    //     0x7be340: mov             SP, fp
    //     0x7be344: ldp             fp, lr, [SP], #0x10
    // 0x7be348: ret
    //     0x7be348: ret             
    // 0x7be34c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7be34c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7be350: b               #0x7be32c
  }
  _ _handleTabControllerAnimationTick(/* No info */) {
    // ** addr: 0x7be354, size: 0xf4
    // 0x7be354: EnterFrame
    //     0x7be354: stp             fp, lr, [SP, #-0x10]!
    //     0x7be358: mov             fp, SP
    // 0x7be35c: CheckStackOverflow
    //     0x7be35c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7be360: cmp             SP, x16
    //     0x7be364: b.ls            #0x7be43c
    // 0x7be368: ldr             x2, [fp, #0x10]
    // 0x7be36c: LoadField: r0 = r2->field_27
    //     0x7be36c: ldur            x0, [x2, #0x27]
    // 0x7be370: cmp             x0, #0
    // 0x7be374: b.gt            #0x7be390
    // 0x7be378: LoadField: r0 = r2->field_13
    //     0x7be378: ldur            w0, [x2, #0x13]
    // 0x7be37c: DecompressPointer r0
    //     0x7be37c: add             x0, x0, HEAP, lsl #32
    // 0x7be380: cmp             w0, NULL
    // 0x7be384: b.eq            #0x7be444
    // 0x7be388: LoadField: r1 = r0->field_43
    //     0x7be388: ldur            x1, [x0, #0x43]
    // 0x7be38c: cbnz            x1, #0x7be3a0
    // 0x7be390: r0 = Null
    //     0x7be390: mov             x0, NULL
    // 0x7be394: LeaveFrame
    //     0x7be394: mov             SP, fp
    //     0x7be398: ldp             fp, lr, [SP], #0x10
    // 0x7be39c: ret
    //     0x7be39c: ret             
    // 0x7be3a0: LoadField: r3 = r0->field_33
    //     0x7be3a0: ldur            x3, [x0, #0x33]
    // 0x7be3a4: LoadField: r4 = r2->field_23
    //     0x7be3a4: ldur            w4, [x2, #0x23]
    // 0x7be3a8: DecompressPointer r4
    //     0x7be3a8: add             x4, x4, HEAP, lsl #32
    // 0x7be3ac: r0 = BoxInt64Instr(r3)
    //     0x7be3ac: sbfiz           x0, x3, #1, #0x1f
    //     0x7be3b0: cmp             x3, x0, asr #1
    //     0x7be3b4: b.eq            #0x7be3c0
    //     0x7be3b8: bl              #0xd69bb8
    //     0x7be3bc: stur            x3, [x0, #7]
    // 0x7be3c0: cmp             w0, w4
    // 0x7be3c4: b.eq            #0x7be42c
    // 0x7be3c8: and             w16, w0, w4
    // 0x7be3cc: branchIfSmi(r16, 0x7be400)
    //     0x7be3cc: tbz             w16, #0, #0x7be400
    // 0x7be3d0: r16 = LoadClassIdInstr(r0)
    //     0x7be3d0: ldur            x16, [x0, #-1]
    //     0x7be3d4: ubfx            x16, x16, #0xc, #0x14
    // 0x7be3d8: cmp             x16, #0x3c
    // 0x7be3dc: b.ne            #0x7be400
    // 0x7be3e0: r16 = LoadClassIdInstr(r4)
    //     0x7be3e0: ldur            x16, [x4, #-1]
    //     0x7be3e4: ubfx            x16, x16, #0xc, #0x14
    // 0x7be3e8: cmp             x16, #0x3c
    // 0x7be3ec: b.ne            #0x7be400
    // 0x7be3f0: LoadField: r16 = r0->field_7
    //     0x7be3f0: ldur            x16, [x0, #7]
    // 0x7be3f4: LoadField: r17 = r4->field_7
    //     0x7be3f4: ldur            x17, [x4, #7]
    // 0x7be3f8: cmp             x16, x17
    // 0x7be3fc: b.eq            #0x7be42c
    // 0x7be400: StoreField: r2->field_23 = r0
    //     0x7be400: stur            w0, [x2, #0x23]
    //     0x7be404: tbz             w0, #0, #0x7be420
    //     0x7be408: ldurb           w16, [x2, #-1]
    //     0x7be40c: ldurb           w17, [x0, #-1]
    //     0x7be410: and             x16, x17, x16, lsr #2
    //     0x7be414: tst             x16, HEAP, lsr #32
    //     0x7be418: b.eq            #0x7be420
    //     0x7be41c: bl              #0xd6828c
    // 0x7be420: SaveReg r2
    //     0x7be420: str             x2, [SP, #-8]!
    // 0x7be424: r0 = _warpToCurrentIndex()
    //     0x7be424: bl              #0x7be448  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToCurrentIndex
    // 0x7be428: add             SP, SP, #8
    // 0x7be42c: r0 = Null
    //     0x7be42c: mov             x0, NULL
    // 0x7be430: LeaveFrame
    //     0x7be430: mov             SP, fp
    //     0x7be434: ldp             fp, lr, [SP], #0x10
    // 0x7be438: ret
    //     0x7be438: ret             
    // 0x7be43c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7be43c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7be440: b               #0x7be368
    // 0x7be444: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be444: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _warpToCurrentIndex(/* No info */) async {
    // ** addr: 0x7be448, size: 0x564
    // 0x7be448: EnterFrame
    //     0x7be448: stp             fp, lr, [SP, #-0x10]!
    //     0x7be44c: mov             fp, SP
    // 0x7be450: AllocStack(0x20)
    //     0x7be450: sub             SP, SP, #0x20
    // 0x7be454: SetupParameters(_TabBarViewState<TabBarView> this /* r1, fp-0x10 */)
    //     0x7be454: stur            NULL, [fp, #-8]
    //     0x7be458: mov             x0, #0
    //     0x7be45c: add             x1, fp, w0, sxtw #2
    //     0x7be460: ldr             x1, [x1, #0x10]
    //     0x7be464: stur            x1, [fp, #-0x10]
    // 0x7be468: CheckStackOverflow
    //     0x7be468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7be46c: cmp             SP, x16
    //     0x7be470: b.ls            #0x7be96c
    // 0x7be474: r1 = 4
    //     0x7be474: mov             x1, #4
    // 0x7be478: r0 = AllocateContext()
    //     0x7be478: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7be47c: mov             x2, x0
    // 0x7be480: ldur            x1, [fp, #-0x10]
    // 0x7be484: stur            x2, [fp, #-0x18]
    // 0x7be488: StoreField: r2->field_f = r1
    //     0x7be488: stur            w1, [x2, #0xf]
    // 0x7be48c: InitAsync() -> Future<void?>
    //     0x7be48c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x7be490: bl              #0x4b92e4
    // 0x7be494: ldur            x0, [fp, #-0x10]
    // 0x7be498: LoadField: r1 = r0->field_f
    //     0x7be498: ldur            w1, [x0, #0xf]
    // 0x7be49c: DecompressPointer r1
    //     0x7be49c: add             x1, x1, HEAP, lsl #32
    // 0x7be4a0: cmp             w1, NULL
    // 0x7be4a4: b.ne            #0x7be4f8
    // 0x7be4a8: r1 = <void?>
    //     0x7be4a8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7be4ac: r0 = _Future()
    //     0x7be4ac: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7be4b0: r1 = 0
    //     0x7be4b0: mov             x1, #0
    // 0x7be4b4: stur            x0, [fp, #-0x20]
    // 0x7be4b8: StoreField: r0->field_b = r1
    //     0x7be4b8: stur            x1, [x0, #0xb]
    // 0x7be4bc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7be4bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7be4c0: ldr             x0, [x0, #0xb58]
    //     0x7be4c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7be4c8: cmp             w0, w16
    //     0x7be4cc: b.ne            #0x7be4d8
    //     0x7be4d0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7be4d4: bl              #0xd67d44
    // 0x7be4d8: mov             x1, x0
    // 0x7be4dc: ldur            x0, [fp, #-0x20]
    // 0x7be4e0: StoreField: r0->field_13 = r1
    //     0x7be4e0: stur            w1, [x0, #0x13]
    // 0x7be4e4: stp             NULL, x0, [SP, #-0x10]!
    // 0x7be4e8: r0 = _asyncComplete()
    //     0x7be4e8: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7be4ec: add             SP, SP, #0x10
    // 0x7be4f0: ldur            x0, [fp, #-0x20]
    // 0x7be4f4: r0 = ReturnAsync()
    //     0x7be4f4: b               #0x501858  ; ReturnAsyncStub
    // 0x7be4f8: r1 = 0
    //     0x7be4f8: mov             x1, #0
    // 0x7be4fc: LoadField: r2 = r0->field_17
    //     0x7be4fc: ldur            w2, [x0, #0x17]
    // 0x7be500: DecompressPointer r2
    //     0x7be500: add             x2, x2, HEAP, lsl #32
    // 0x7be504: r16 = Sentinel
    //     0x7be504: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7be508: cmp             w2, w16
    // 0x7be50c: b.eq            #0x7be974
    // 0x7be510: LoadField: r3 = r2->field_33
    //     0x7be510: ldur            w3, [x2, #0x33]
    // 0x7be514: DecompressPointer r3
    //     0x7be514: add             x3, x3, HEAP, lsl #32
    // 0x7be518: SaveReg r3
    //     0x7be518: str             x3, [SP, #-8]!
    // 0x7be51c: r0 = single()
    //     0x7be51c: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x7be520: add             SP, SP, #8
    // 0x7be524: mov             x3, x0
    // 0x7be528: r2 = Null
    //     0x7be528: mov             x2, NULL
    // 0x7be52c: r1 = Null
    //     0x7be52c: mov             x1, NULL
    // 0x7be530: stur            x3, [fp, #-0x20]
    // 0x7be534: r4 = LoadClassIdInstr(r0)
    //     0x7be534: ldur            x4, [x0, #-1]
    //     0x7be538: ubfx            x4, x4, #0xc, #0x14
    // 0x7be53c: r17 = 4847
    //     0x7be53c: mov             x17, #0x12ef
    // 0x7be540: cmp             x4, x17
    // 0x7be544: b.eq            #0x7be55c
    // 0x7be548: r8 = _PagePosition
    //     0x7be548: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x7be54c: ldr             x8, [x8, #0xf98]
    // 0x7be550: r3 = Null
    //     0x7be550: add             x3, PP, #0x38, lsl #12  ; [pp+0x38058] Null
    //     0x7be554: ldr             x3, [x3, #0x58]
    // 0x7be558: r0 = DefaultTypeTest()
    //     0x7be558: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x7be55c: ldur            x16, [fp, #-0x20]
    // 0x7be560: SaveReg r16
    //     0x7be560: str             x16, [SP, #-8]!
    // 0x7be564: r0 = page()
    //     0x7be564: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x7be568: add             SP, SP, #8
    // 0x7be56c: mov             x1, x0
    // 0x7be570: ldur            x0, [fp, #-0x10]
    // 0x7be574: stur            x1, [fp, #-0x20]
    // 0x7be578: LoadField: r2 = r0->field_23
    //     0x7be578: ldur            w2, [x0, #0x23]
    // 0x7be57c: DecompressPointer r2
    //     0x7be57c: add             x2, x2, HEAP, lsl #32
    // 0x7be580: cmp             w2, NULL
    // 0x7be584: b.eq            #0x7be980
    // 0x7be588: stp             x2, NULL, [SP, #-0x10]!
    // 0x7be58c: r0 = _Double.fromInteger()
    //     0x7be58c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x7be590: add             SP, SP, #0x10
    // 0x7be594: mov             x1, x0
    // 0x7be598: ldur            x0, [fp, #-0x20]
    // 0x7be59c: r2 = LoadClassIdInstr(r0)
    //     0x7be59c: ldur            x2, [x0, #-1]
    //     0x7be5a0: ubfx            x2, x2, #0xc, #0x14
    // 0x7be5a4: stp             x1, x0, [SP, #-0x10]!
    // 0x7be5a8: mov             x0, x2
    // 0x7be5ac: mov             lr, x0
    // 0x7be5b0: ldr             lr, [x21, lr, lsl #3]
    // 0x7be5b4: blr             lr
    // 0x7be5b8: add             SP, SP, #0x10
    // 0x7be5bc: tbnz            w0, #4, #0x7be610
    // 0x7be5c0: r1 = <void?>
    //     0x7be5c0: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7be5c4: r0 = _Future()
    //     0x7be5c4: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7be5c8: r2 = 0
    //     0x7be5c8: mov             x2, #0
    // 0x7be5cc: stur            x0, [fp, #-0x20]
    // 0x7be5d0: StoreField: r0->field_b = r2
    //     0x7be5d0: stur            x2, [x0, #0xb]
    // 0x7be5d4: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7be5d4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7be5d8: ldr             x0, [x0, #0xb58]
    //     0x7be5dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7be5e0: cmp             w0, w16
    //     0x7be5e4: b.ne            #0x7be5f0
    //     0x7be5e8: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7be5ec: bl              #0xd67d44
    // 0x7be5f0: mov             x1, x0
    // 0x7be5f4: ldur            x0, [fp, #-0x20]
    // 0x7be5f8: StoreField: r0->field_13 = r1
    //     0x7be5f8: stur            w1, [x0, #0x13]
    // 0x7be5fc: stp             NULL, x0, [SP, #-0x10]!
    // 0x7be600: r0 = _asyncComplete()
    //     0x7be600: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7be604: add             SP, SP, #0x10
    // 0x7be608: ldur            x0, [fp, #-0x20]
    // 0x7be60c: r0 = ReturnAsync()
    //     0x7be60c: b               #0x501858  ; ReturnAsyncStub
    // 0x7be610: ldur            x3, [fp, #-0x10]
    // 0x7be614: ldur            x4, [fp, #-0x18]
    // 0x7be618: r2 = 0
    //     0x7be618: mov             x2, #0
    // 0x7be61c: LoadField: r0 = r3->field_13
    //     0x7be61c: ldur            w0, [x3, #0x13]
    // 0x7be620: DecompressPointer r0
    //     0x7be620: add             x0, x0, HEAP, lsl #32
    // 0x7be624: cmp             w0, NULL
    // 0x7be628: b.eq            #0x7be984
    // 0x7be62c: LoadField: r5 = r0->field_3b
    //     0x7be62c: ldur            x5, [x0, #0x3b]
    // 0x7be630: r0 = BoxInt64Instr(r5)
    //     0x7be630: sbfiz           x0, x5, #1, #0x1f
    //     0x7be634: cmp             x5, x0, asr #1
    //     0x7be638: b.eq            #0x7be644
    //     0x7be63c: bl              #0xd69bb8
    //     0x7be640: stur            x5, [x0, #7]
    // 0x7be644: StoreField: r4->field_13 = r0
    //     0x7be644: stur            w0, [x4, #0x13]
    //     0x7be648: tbz             w0, #0, #0x7be664
    //     0x7be64c: ldurb           w16, [x4, #-1]
    //     0x7be650: ldurb           w17, [x0, #-1]
    //     0x7be654: and             x16, x17, x16, lsr #2
    //     0x7be658: tst             x16, HEAP, lsr #32
    //     0x7be65c: b.eq            #0x7be664
    //     0x7be660: bl              #0xd682cc
    // 0x7be664: LoadField: r0 = r3->field_23
    //     0x7be664: ldur            w0, [x3, #0x23]
    // 0x7be668: DecompressPointer r0
    //     0x7be668: add             x0, x0, HEAP, lsl #32
    // 0x7be66c: cmp             w0, NULL
    // 0x7be670: b.eq            #0x7be988
    // 0x7be674: r1 = LoadInt32Instr(r0)
    //     0x7be674: sbfx            x1, x0, #1, #0x1f
    //     0x7be678: tbz             w0, #0, #0x7be680
    //     0x7be67c: ldur            x1, [x0, #7]
    // 0x7be680: sub             x0, x1, x5
    // 0x7be684: tbz             x0, #0x3f, #0x7be690
    // 0x7be688: neg             x6, x0
    // 0x7be68c: mov             x0, x6
    // 0x7be690: cmp             x0, #1
    // 0x7be694: b.ne            #0x7be7b8
    // 0x7be698: LoadField: r0 = r3->field_27
    //     0x7be698: ldur            x0, [x3, #0x27]
    // 0x7be69c: add             x5, x0, #1
    // 0x7be6a0: StoreField: r3->field_27 = r5
    //     0x7be6a0: stur            x5, [x3, #0x27]
    // 0x7be6a4: LoadField: r0 = r3->field_17
    //     0x7be6a4: ldur            w0, [x3, #0x17]
    // 0x7be6a8: DecompressPointer r0
    //     0x7be6a8: add             x0, x0, HEAP, lsl #32
    // 0x7be6ac: stp             x1, x0, [SP, #-0x10]!
    // 0x7be6b0: r16 = Instance_Cubic
    //     0x7be6b0: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x7be6b4: ldr             x16, [x16, #0xfc8]
    // 0x7be6b8: r30 = Instance_Duration
    //     0x7be6b8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7be6bc: ldr             lr, [lr, #0xc88]
    // 0x7be6c0: stp             lr, x16, [SP, #-0x10]!
    // 0x7be6c4: r0 = animateToPage()
    //     0x7be6c4: bl              #0x798030  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0x7be6c8: add             SP, SP, #0x20
    // 0x7be6cc: mov             x1, x0
    // 0x7be6d0: stur            x1, [fp, #-0x20]
    // 0x7be6d4: r0 = Await()
    //     0x7be6d4: bl              #0x4b8e6c  ; AwaitStub
    // 0x7be6d8: ldur            x1, [fp, #-0x10]
    // 0x7be6dc: LoadField: r0 = r1->field_27
    //     0x7be6dc: ldur            x0, [x1, #0x27]
    // 0x7be6e0: sub             x2, x0, #1
    // 0x7be6e4: StoreField: r1->field_27 = r2
    //     0x7be6e4: stur            x2, [x1, #0x27]
    // 0x7be6e8: LoadField: r0 = r1->field_f
    //     0x7be6e8: ldur            w0, [x1, #0xf]
    // 0x7be6ec: DecompressPointer r0
    //     0x7be6ec: add             x0, x0, HEAP, lsl #32
    // 0x7be6f0: cmp             w0, NULL
    // 0x7be6f4: b.eq            #0x7be768
    // 0x7be6f8: LoadField: r0 = r1->field_b
    //     0x7be6f8: ldur            w0, [x1, #0xb]
    // 0x7be6fc: DecompressPointer r0
    //     0x7be6fc: add             x0, x0, HEAP, lsl #32
    // 0x7be700: cmp             w0, NULL
    // 0x7be704: b.eq            #0x7be98c
    // 0x7be708: LoadField: r2 = r0->field_f
    //     0x7be708: ldur            w2, [x0, #0xf]
    // 0x7be70c: DecompressPointer r2
    //     0x7be70c: add             x2, x2, HEAP, lsl #32
    // 0x7be710: LoadField: r0 = r1->field_1b
    //     0x7be710: ldur            w0, [x1, #0x1b]
    // 0x7be714: DecompressPointer r0
    //     0x7be714: add             x0, x0, HEAP, lsl #32
    // 0x7be718: r16 = Sentinel
    //     0x7be718: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7be71c: cmp             w0, w16
    // 0x7be720: b.eq            #0x7be990
    // 0x7be724: r3 = LoadClassIdInstr(r2)
    //     0x7be724: ldur            x3, [x2, #-1]
    //     0x7be728: ubfx            x3, x3, #0xc, #0x14
    // 0x7be72c: stp             x0, x2, [SP, #-0x10]!
    // 0x7be730: mov             x0, x3
    // 0x7be734: mov             lr, x0
    // 0x7be738: ldr             lr, [x21, lr, lsl #3]
    // 0x7be73c: blr             lr
    // 0x7be740: add             SP, SP, #0x10
    // 0x7be744: tbz             w0, #4, #0x7be768
    // 0x7be748: ldur            x2, [fp, #-0x18]
    // 0x7be74c: r1 = Function '<anonymous closure>':.
    //     0x7be74c: add             x1, PP, #0x38, lsl #12  ; [pp+0x38068] AnonymousClosure: (0x7beca4), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToCurrentIndex (0x7be448)
    //     0x7be750: ldr             x1, [x1, #0x68]
    // 0x7be754: r0 = AllocateClosure()
    //     0x7be754: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7be758: ldur            x16, [fp, #-0x10]
    // 0x7be75c: stp             x0, x16, [SP, #-0x10]!
    // 0x7be760: r0 = setState()
    //     0x7be760: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7be764: add             SP, SP, #0x10
    // 0x7be768: r1 = <void?>
    //     0x7be768: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7be76c: r0 = _Future()
    //     0x7be76c: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7be770: r3 = 0
    //     0x7be770: mov             x3, #0
    // 0x7be774: stur            x0, [fp, #-0x20]
    // 0x7be778: StoreField: r0->field_b = r3
    //     0x7be778: stur            x3, [x0, #0xb]
    // 0x7be77c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7be77c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7be780: ldr             x0, [x0, #0xb58]
    //     0x7be784: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7be788: cmp             w0, w16
    //     0x7be78c: b.ne            #0x7be798
    //     0x7be790: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7be794: bl              #0xd67d44
    // 0x7be798: mov             x1, x0
    // 0x7be79c: ldur            x0, [fp, #-0x20]
    // 0x7be7a0: StoreField: r0->field_13 = r1
    //     0x7be7a0: stur            w1, [x0, #0x13]
    // 0x7be7a4: stp             NULL, x0, [SP, #-0x10]!
    // 0x7be7a8: r0 = _asyncComplete()
    //     0x7be7a8: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7be7ac: add             SP, SP, #0x10
    // 0x7be7b0: ldur            x0, [fp, #-0x20]
    // 0x7be7b4: r0 = ReturnAsync()
    //     0x7be7b4: b               #0x501858  ; ReturnAsyncStub
    // 0x7be7b8: mov             x3, x2
    // 0x7be7bc: cmp             x1, x5
    // 0x7be7c0: b.le            #0x7be7d0
    // 0x7be7c4: sub             x0, x1, #1
    // 0x7be7c8: mov             x2, x0
    // 0x7be7cc: b               #0x7be7d8
    // 0x7be7d0: add             x0, x1, #1
    // 0x7be7d4: mov             x2, x0
    // 0x7be7d8: ldur            x4, [fp, #-0x10]
    // 0x7be7dc: ldur            x5, [fp, #-0x18]
    // 0x7be7e0: r0 = BoxInt64Instr(r2)
    //     0x7be7e0: sbfiz           x0, x2, #1, #0x1f
    //     0x7be7e4: cmp             x2, x0, asr #1
    //     0x7be7e8: b.eq            #0x7be7f4
    //     0x7be7ec: bl              #0xd69bb8
    //     0x7be7f0: stur            x2, [x0, #7]
    // 0x7be7f4: mov             x6, x0
    // 0x7be7f8: stur            x6, [fp, #-0x20]
    // 0x7be7fc: StoreField: r5->field_17 = r0
    //     0x7be7fc: stur            w0, [x5, #0x17]
    //     0x7be800: tbz             w0, #0, #0x7be81c
    //     0x7be804: ldurb           w16, [x5, #-1]
    //     0x7be808: ldurb           w17, [x0, #-1]
    //     0x7be80c: and             x16, x17, x16, lsr #2
    //     0x7be810: tst             x16, HEAP, lsr #32
    //     0x7be814: b.eq            #0x7be81c
    //     0x7be818: bl              #0xd682ec
    // 0x7be81c: LoadField: r0 = r4->field_1f
    //     0x7be81c: ldur            w0, [x4, #0x1f]
    // 0x7be820: DecompressPointer r0
    //     0x7be820: add             x0, x0, HEAP, lsl #32
    // 0x7be824: r16 = Sentinel
    //     0x7be824: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7be828: cmp             w0, w16
    // 0x7be82c: b.eq            #0x7be99c
    // 0x7be830: StoreField: r5->field_1b = r0
    //     0x7be830: stur            w0, [x5, #0x1b]
    //     0x7be834: ldurb           w16, [x5, #-1]
    //     0x7be838: ldurb           w17, [x0, #-1]
    //     0x7be83c: and             x16, x17, x16, lsr #2
    //     0x7be840: tst             x16, HEAP, lsr #32
    //     0x7be844: b.eq            #0x7be84c
    //     0x7be848: bl              #0xd682ec
    // 0x7be84c: mov             x2, x5
    // 0x7be850: r1 = Function '<anonymous closure>':.
    //     0x7be850: add             x1, PP, #0x38, lsl #12  ; [pp+0x38070] AnonymousClosure: (0x7beaac), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToCurrentIndex (0x7be448)
    //     0x7be854: ldr             x1, [x1, #0x70]
    // 0x7be858: r0 = AllocateClosure()
    //     0x7be858: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7be85c: ldur            x16, [fp, #-0x10]
    // 0x7be860: stp             x0, x16, [SP, #-0x10]!
    // 0x7be864: r0 = setState()
    //     0x7be864: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7be868: add             SP, SP, #0x10
    // 0x7be86c: ldur            x0, [fp, #-0x10]
    // 0x7be870: LoadField: r1 = r0->field_17
    //     0x7be870: ldur            w1, [x0, #0x17]
    // 0x7be874: DecompressPointer r1
    //     0x7be874: add             x1, x1, HEAP, lsl #32
    // 0x7be878: ldur            x16, [fp, #-0x20]
    // 0x7be87c: stp             x16, x1, [SP, #-0x10]!
    // 0x7be880: r0 = jumpToPage()
    //     0x7be880: bl              #0x7a1e1c  ; [package:flutter/src/widgets/page_view.dart] PageController::jumpToPage
    // 0x7be884: add             SP, SP, #0x10
    // 0x7be888: ldur            x0, [fp, #-0x10]
    // 0x7be88c: LoadField: r1 = r0->field_17
    //     0x7be88c: ldur            w1, [x0, #0x17]
    // 0x7be890: DecompressPointer r1
    //     0x7be890: add             x1, x1, HEAP, lsl #32
    // 0x7be894: LoadField: r2 = r0->field_23
    //     0x7be894: ldur            w2, [x0, #0x23]
    // 0x7be898: DecompressPointer r2
    //     0x7be898: add             x2, x2, HEAP, lsl #32
    // 0x7be89c: cmp             w2, NULL
    // 0x7be8a0: b.eq            #0x7be9a8
    // 0x7be8a4: r3 = LoadInt32Instr(r2)
    //     0x7be8a4: sbfx            x3, x2, #1, #0x1f
    //     0x7be8a8: tbz             w2, #0, #0x7be8b0
    //     0x7be8ac: ldur            x3, [x2, #7]
    // 0x7be8b0: stp             x3, x1, [SP, #-0x10]!
    // 0x7be8b4: r16 = Instance_Cubic
    //     0x7be8b4: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x7be8b8: ldr             x16, [x16, #0xfc8]
    // 0x7be8bc: r30 = Instance_Duration
    //     0x7be8bc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7be8c0: ldr             lr, [lr, #0xc88]
    // 0x7be8c4: stp             lr, x16, [SP, #-0x10]!
    // 0x7be8c8: r0 = animateToPage()
    //     0x7be8c8: bl              #0x798030  ; [package:flutter/src/widgets/page_view.dart] PageController::animateToPage
    // 0x7be8cc: add             SP, SP, #0x20
    // 0x7be8d0: mov             x1, x0
    // 0x7be8d4: stur            x1, [fp, #-0x20]
    // 0x7be8d8: r0 = Await()
    //     0x7be8d8: bl              #0x4b8e6c  ; AwaitStub
    // 0x7be8dc: ldur            x0, [fp, #-0x10]
    // 0x7be8e0: LoadField: r1 = r0->field_f
    //     0x7be8e0: ldur            w1, [x0, #0xf]
    // 0x7be8e4: DecompressPointer r1
    //     0x7be8e4: add             x1, x1, HEAP, lsl #32
    // 0x7be8e8: cmp             w1, NULL
    // 0x7be8ec: b.ne            #0x7be944
    // 0x7be8f0: r1 = <void?>
    //     0x7be8f0: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x7be8f4: r0 = _Future()
    //     0x7be8f4: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x7be8f8: mov             x1, x0
    // 0x7be8fc: r0 = 0
    //     0x7be8fc: mov             x0, #0
    // 0x7be900: stur            x1, [fp, #-0x20]
    // 0x7be904: StoreField: r1->field_b = r0
    //     0x7be904: stur            x0, [x1, #0xb]
    // 0x7be908: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x7be908: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7be90c: ldr             x0, [x0, #0xb58]
    //     0x7be910: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7be914: cmp             w0, w16
    //     0x7be918: b.ne            #0x7be924
    //     0x7be91c: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x7be920: bl              #0xd67d44
    // 0x7be924: mov             x1, x0
    // 0x7be928: ldur            x0, [fp, #-0x20]
    // 0x7be92c: StoreField: r0->field_13 = r1
    //     0x7be92c: stur            w1, [x0, #0x13]
    // 0x7be930: stp             NULL, x0, [SP, #-0x10]!
    // 0x7be934: r0 = _asyncComplete()
    //     0x7be934: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x7be938: add             SP, SP, #0x10
    // 0x7be93c: ldur            x0, [fp, #-0x20]
    // 0x7be940: r0 = ReturnAsync()
    //     0x7be940: b               #0x501858  ; ReturnAsyncStub
    // 0x7be944: ldur            x2, [fp, #-0x18]
    // 0x7be948: r1 = Function '<anonymous closure>':.
    //     0x7be948: add             x1, PP, #0x38, lsl #12  ; [pp+0x38078] AnonymousClosure: (0x7be9ac), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_warpToCurrentIndex (0x7be448)
    //     0x7be94c: ldr             x1, [x1, #0x78]
    // 0x7be950: r0 = AllocateClosure()
    //     0x7be950: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7be954: ldur            x16, [fp, #-0x10]
    // 0x7be958: stp             x0, x16, [SP, #-0x10]!
    // 0x7be95c: r0 = setState()
    //     0x7be95c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7be960: add             SP, SP, #0x10
    // 0x7be964: r0 = Null
    //     0x7be964: mov             x0, NULL
    // 0x7be968: r0 = ReturnAsyncNotFuture()
    //     0x7be968: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x7be96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7be96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7be970: b               #0x7be474
    // 0x7be974: r9 = _pageController
    //     0x7be974: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff0] Field <_TabBarViewState@472014024._pageController@472014024>: late (offset: 0x18)
    //     0x7be978: ldr             x9, [x9, #0xff0]
    // 0x7be97c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7be97c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7be980: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be980: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be984: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be984: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be988: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be988: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be98c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be98c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7be990: r9 = _children
    //     0x7be990: add             x9, PP, #0x38, lsl #12  ; [pp+0x38080] Field <_TabBarViewState@472014024._children@472014024>: late (offset: 0x1c)
    //     0x7be994: ldr             x9, [x9, #0x80]
    // 0x7be998: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7be998: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7be99c: r9 = _childrenWithKey
    //     0x7be99c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff8] Field <_TabBarViewState@472014024._childrenWithKey@472014024>: late (offset: 0x20)
    //     0x7be9a0: ldr             x9, [x9, #0xff8]
    // 0x7be9a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7be9a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7be9a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7be9a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7be9ac, size: 0x100
    // 0x7be9ac: EnterFrame
    //     0x7be9ac: stp             fp, lr, [SP, #-0x10]!
    //     0x7be9b0: mov             fp, SP
    // 0x7be9b4: AllocStack(0x8)
    //     0x7be9b4: sub             SP, SP, #8
    // 0x7be9b8: SetupParameters()
    //     0x7be9b8: ldr             x0, [fp, #0x10]
    //     0x7be9bc: ldur            w1, [x0, #0x17]
    //     0x7be9c0: add             x1, x1, HEAP, lsl #32
    //     0x7be9c4: stur            x1, [fp, #-8]
    // 0x7be9c8: CheckStackOverflow
    //     0x7be9c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7be9cc: cmp             SP, x16
    //     0x7be9d0: b.ls            #0x7bea94
    // 0x7be9d4: LoadField: r0 = r1->field_f
    //     0x7be9d4: ldur            w0, [x1, #0xf]
    // 0x7be9d8: DecompressPointer r0
    //     0x7be9d8: add             x0, x0, HEAP, lsl #32
    // 0x7be9dc: LoadField: r2 = r0->field_27
    //     0x7be9dc: ldur            x2, [x0, #0x27]
    // 0x7be9e0: sub             x3, x2, #1
    // 0x7be9e4: StoreField: r0->field_27 = r3
    //     0x7be9e4: stur            x3, [x0, #0x27]
    // 0x7be9e8: LoadField: r2 = r0->field_b
    //     0x7be9e8: ldur            w2, [x0, #0xb]
    // 0x7be9ec: DecompressPointer r2
    //     0x7be9ec: add             x2, x2, HEAP, lsl #32
    // 0x7be9f0: cmp             w2, NULL
    // 0x7be9f4: b.eq            #0x7bea9c
    // 0x7be9f8: LoadField: r3 = r2->field_f
    //     0x7be9f8: ldur            w3, [x2, #0xf]
    // 0x7be9fc: DecompressPointer r3
    //     0x7be9fc: add             x3, x3, HEAP, lsl #32
    // 0x7bea00: LoadField: r2 = r0->field_1b
    //     0x7bea00: ldur            w2, [x0, #0x1b]
    // 0x7bea04: DecompressPointer r2
    //     0x7bea04: add             x2, x2, HEAP, lsl #32
    // 0x7bea08: r16 = Sentinel
    //     0x7bea08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bea0c: cmp             w2, w16
    // 0x7bea10: b.eq            #0x7beaa0
    // 0x7bea14: r0 = LoadClassIdInstr(r3)
    //     0x7bea14: ldur            x0, [x3, #-1]
    //     0x7bea18: ubfx            x0, x0, #0xc, #0x14
    // 0x7bea1c: stp             x2, x3, [SP, #-0x10]!
    // 0x7bea20: mov             lr, x0
    // 0x7bea24: ldr             lr, [x21, lr, lsl #3]
    // 0x7bea28: blr             lr
    // 0x7bea2c: add             SP, SP, #0x10
    // 0x7bea30: tbz             w0, #4, #0x7bea50
    // 0x7bea34: ldur            x0, [fp, #-8]
    // 0x7bea38: LoadField: r1 = r0->field_f
    //     0x7bea38: ldur            w1, [x0, #0xf]
    // 0x7bea3c: DecompressPointer r1
    //     0x7bea3c: add             x1, x1, HEAP, lsl #32
    // 0x7bea40: SaveReg r1
    //     0x7bea40: str             x1, [SP, #-8]!
    // 0x7bea44: r0 = _updateChildren()
    //     0x7bea44: bl              #0x7be074  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0x7bea48: add             SP, SP, #8
    // 0x7bea4c: b               #0x7bea84
    // 0x7bea50: ldur            x0, [fp, #-8]
    // 0x7bea54: LoadField: r1 = r0->field_f
    //     0x7bea54: ldur            w1, [x0, #0xf]
    // 0x7bea58: DecompressPointer r1
    //     0x7bea58: add             x1, x1, HEAP, lsl #32
    // 0x7bea5c: LoadField: r2 = r0->field_1b
    //     0x7bea5c: ldur            w2, [x0, #0x1b]
    // 0x7bea60: DecompressPointer r2
    //     0x7bea60: add             x2, x2, HEAP, lsl #32
    // 0x7bea64: mov             x0, x2
    // 0x7bea68: StoreField: r1->field_1f = r0
    //     0x7bea68: stur            w0, [x1, #0x1f]
    //     0x7bea6c: ldurb           w16, [x1, #-1]
    //     0x7bea70: ldurb           w17, [x0, #-1]
    //     0x7bea74: and             x16, x17, x16, lsr #2
    //     0x7bea78: tst             x16, HEAP, lsr #32
    //     0x7bea7c: b.eq            #0x7bea84
    //     0x7bea80: bl              #0xd6826c
    // 0x7bea84: r0 = Null
    //     0x7bea84: mov             x0, NULL
    // 0x7bea88: LeaveFrame
    //     0x7bea88: mov             SP, fp
    //     0x7bea8c: ldp             fp, lr, [SP], #0x10
    // 0x7bea90: ret
    //     0x7bea90: ret             
    // 0x7bea94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bea94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bea98: b               #0x7be9d4
    // 0x7bea9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bea9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7beaa0: r9 = _children
    //     0x7beaa0: add             x9, PP, #0x38, lsl #12  ; [pp+0x38080] Field <_TabBarViewState@472014024._children@472014024>: late (offset: 0x1c)
    //     0x7beaa4: ldr             x9, [x9, #0x80]
    // 0x7beaa8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7beaa8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7beaac, size: 0x1f8
    // 0x7beaac: EnterFrame
    //     0x7beaac: stp             fp, lr, [SP, #-0x10]!
    //     0x7beab0: mov             fp, SP
    // 0x7beab4: AllocStack(0x28)
    //     0x7beab4: sub             SP, SP, #0x28
    // 0x7beab8: SetupParameters()
    //     0x7beab8: ldr             x0, [fp, #0x10]
    //     0x7beabc: ldur            w1, [x0, #0x17]
    //     0x7beac0: add             x1, x1, HEAP, lsl #32
    //     0x7beac4: stur            x1, [fp, #-0x10]
    // 0x7beac8: CheckStackOverflow
    //     0x7beac8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7beacc: cmp             SP, x16
    //     0x7bead0: b.ls            #0x7bec6c
    // 0x7bead4: LoadField: r0 = r1->field_f
    //     0x7bead4: ldur            w0, [x1, #0xf]
    // 0x7bead8: DecompressPointer r0
    //     0x7bead8: add             x0, x0, HEAP, lsl #32
    // 0x7beadc: stur            x0, [fp, #-8]
    // 0x7beae0: LoadField: r2 = r0->field_27
    //     0x7beae0: ldur            x2, [x0, #0x27]
    // 0x7beae4: add             x3, x2, #1
    // 0x7beae8: StoreField: r0->field_27 = r3
    //     0x7beae8: stur            x3, [x0, #0x27]
    // 0x7beaec: LoadField: r2 = r0->field_1f
    //     0x7beaec: ldur            w2, [x0, #0x1f]
    // 0x7beaf0: DecompressPointer r2
    //     0x7beaf0: add             x2, x2, HEAP, lsl #32
    // 0x7beaf4: r16 = Sentinel
    //     0x7beaf4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7beaf8: cmp             w2, w16
    // 0x7beafc: b.eq            #0x7bec74
    // 0x7beb00: r16 = <Widget>
    //     0x7beb00: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x7beb04: ldr             x16, [x16, #0xea8]
    // 0x7beb08: stp             x2, x16, [SP, #-0x10]!
    // 0x7beb0c: r0 = _List.of()
    //     0x7beb0c: bl              #0x4bf238  ; [dart:core] _List::_List.of
    // 0x7beb10: add             SP, SP, #0x10
    // 0x7beb14: ldur            x1, [fp, #-8]
    // 0x7beb18: StoreField: r1->field_1f = r0
    //     0x7beb18: stur            w0, [x1, #0x1f]
    //     0x7beb1c: ldurb           w16, [x1, #-1]
    //     0x7beb20: ldurb           w17, [x0, #-1]
    //     0x7beb24: and             x16, x17, x16, lsr #2
    //     0x7beb28: tst             x16, HEAP, lsr #32
    //     0x7beb2c: b.eq            #0x7beb34
    //     0x7beb30: bl              #0xd6826c
    // 0x7beb34: ldur            x1, [fp, #-0x10]
    // 0x7beb38: LoadField: r0 = r1->field_f
    //     0x7beb38: ldur            w0, [x1, #0xf]
    // 0x7beb3c: DecompressPointer r0
    //     0x7beb3c: add             x0, x0, HEAP, lsl #32
    // 0x7beb40: LoadField: r2 = r0->field_1f
    //     0x7beb40: ldur            w2, [x0, #0x1f]
    // 0x7beb44: DecompressPointer r2
    //     0x7beb44: add             x2, x2, HEAP, lsl #32
    // 0x7beb48: r16 = Sentinel
    //     0x7beb48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7beb4c: cmp             w2, w16
    // 0x7beb50: b.eq            #0x7bec80
    // 0x7beb54: LoadField: r3 = r1->field_17
    //     0x7beb54: ldur            w3, [x1, #0x17]
    // 0x7beb58: DecompressPointer r3
    //     0x7beb58: add             x3, x3, HEAP, lsl #32
    // 0x7beb5c: stur            x3, [fp, #-8]
    // 0x7beb60: r0 = LoadClassIdInstr(r2)
    //     0x7beb60: ldur            x0, [x2, #-1]
    //     0x7beb64: ubfx            x0, x0, #0xc, #0x14
    // 0x7beb68: stp             x3, x2, [SP, #-0x10]!
    // 0x7beb6c: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7beb6c: sub             lr, x0, #0xd83
    //     0x7beb70: ldr             lr, [x21, lr, lsl #3]
    //     0x7beb74: blr             lr
    // 0x7beb78: add             SP, SP, #0x10
    // 0x7beb7c: mov             x2, x0
    // 0x7beb80: ldur            x1, [fp, #-0x10]
    // 0x7beb84: stur            x2, [fp, #-0x28]
    // 0x7beb88: LoadField: r0 = r1->field_f
    //     0x7beb88: ldur            w0, [x1, #0xf]
    // 0x7beb8c: DecompressPointer r0
    //     0x7beb8c: add             x0, x0, HEAP, lsl #32
    // 0x7beb90: LoadField: r3 = r0->field_1f
    //     0x7beb90: ldur            w3, [x0, #0x1f]
    // 0x7beb94: DecompressPointer r3
    //     0x7beb94: add             x3, x3, HEAP, lsl #32
    // 0x7beb98: r16 = Sentinel
    //     0x7beb98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7beb9c: cmp             w3, w16
    // 0x7beba0: b.eq            #0x7bec8c
    // 0x7beba4: stur            x3, [fp, #-0x20]
    // 0x7beba8: LoadField: r4 = r1->field_13
    //     0x7beba8: ldur            w4, [x1, #0x13]
    // 0x7bebac: DecompressPointer r4
    //     0x7bebac: add             x4, x4, HEAP, lsl #32
    // 0x7bebb0: stur            x4, [fp, #-0x18]
    // 0x7bebb4: r0 = LoadClassIdInstr(r3)
    //     0x7bebb4: ldur            x0, [x3, #-1]
    //     0x7bebb8: ubfx            x0, x0, #0xc, #0x14
    // 0x7bebbc: stp             x4, x3, [SP, #-0x10]!
    // 0x7bebc0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7bebc0: sub             lr, x0, #0xd83
    //     0x7bebc4: ldr             lr, [x21, lr, lsl #3]
    //     0x7bebc8: blr             lr
    // 0x7bebcc: add             SP, SP, #0x10
    // 0x7bebd0: mov             x1, x0
    // 0x7bebd4: ldur            x0, [fp, #-0x20]
    // 0x7bebd8: r2 = LoadClassIdInstr(r0)
    //     0x7bebd8: ldur            x2, [x0, #-1]
    //     0x7bebdc: ubfx            x2, x2, #0xc, #0x14
    // 0x7bebe0: ldur            x16, [fp, #-8]
    // 0x7bebe4: stp             x16, x0, [SP, #-0x10]!
    // 0x7bebe8: SaveReg r1
    //     0x7bebe8: str             x1, [SP, #-8]!
    // 0x7bebec: mov             x0, x2
    // 0x7bebf0: r0 = GDT[cid_x0 + 0x1015e]()
    //     0x7bebf0: mov             x17, #0x15e
    //     0x7bebf4: movk            x17, #1, lsl #16
    //     0x7bebf8: add             lr, x0, x17
    //     0x7bebfc: ldr             lr, [x21, lr, lsl #3]
    //     0x7bec00: blr             lr
    // 0x7bec04: add             SP, SP, #0x18
    // 0x7bec08: ldur            x0, [fp, #-0x10]
    // 0x7bec0c: LoadField: r1 = r0->field_f
    //     0x7bec0c: ldur            w1, [x0, #0xf]
    // 0x7bec10: DecompressPointer r1
    //     0x7bec10: add             x1, x1, HEAP, lsl #32
    // 0x7bec14: LoadField: r0 = r1->field_1f
    //     0x7bec14: ldur            w0, [x1, #0x1f]
    // 0x7bec18: DecompressPointer r0
    //     0x7bec18: add             x0, x0, HEAP, lsl #32
    // 0x7bec1c: r16 = Sentinel
    //     0x7bec1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bec20: cmp             w0, w16
    // 0x7bec24: b.eq            #0x7bec98
    // 0x7bec28: r1 = LoadClassIdInstr(r0)
    //     0x7bec28: ldur            x1, [x0, #-1]
    //     0x7bec2c: ubfx            x1, x1, #0xc, #0x14
    // 0x7bec30: ldur            x16, [fp, #-0x18]
    // 0x7bec34: stp             x16, x0, [SP, #-0x10]!
    // 0x7bec38: ldur            x16, [fp, #-0x28]
    // 0x7bec3c: SaveReg r16
    //     0x7bec3c: str             x16, [SP, #-8]!
    // 0x7bec40: mov             x0, x1
    // 0x7bec44: r0 = GDT[cid_x0 + 0x1015e]()
    //     0x7bec44: mov             x17, #0x15e
    //     0x7bec48: movk            x17, #1, lsl #16
    //     0x7bec4c: add             lr, x0, x17
    //     0x7bec50: ldr             lr, [x21, lr, lsl #3]
    //     0x7bec54: blr             lr
    // 0x7bec58: add             SP, SP, #0x18
    // 0x7bec5c: r0 = Null
    //     0x7bec5c: mov             x0, NULL
    // 0x7bec60: LeaveFrame
    //     0x7bec60: mov             SP, fp
    //     0x7bec64: ldp             fp, lr, [SP], #0x10
    // 0x7bec68: ret
    //     0x7bec68: ret             
    // 0x7bec6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bec6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bec70: b               #0x7bead4
    // 0x7bec74: r9 = _childrenWithKey
    //     0x7bec74: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff8] Field <_TabBarViewState@472014024._childrenWithKey@472014024>: late (offset: 0x20)
    //     0x7bec78: ldr             x9, [x9, #0xff8]
    // 0x7bec7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bec7c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7bec80: r9 = _childrenWithKey
    //     0x7bec80: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff8] Field <_TabBarViewState@472014024._childrenWithKey@472014024>: late (offset: 0x20)
    //     0x7bec84: ldr             x9, [x9, #0xff8]
    // 0x7bec88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bec88: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7bec8c: r9 = _childrenWithKey
    //     0x7bec8c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff8] Field <_TabBarViewState@472014024._childrenWithKey@472014024>: late (offset: 0x20)
    //     0x7bec90: ldr             x9, [x9, #0xff8]
    // 0x7bec94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bec94: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7bec98: r9 = _childrenWithKey
    //     0x7bec98: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff8] Field <_TabBarViewState@472014024._childrenWithKey@472014024>: late (offset: 0x20)
    //     0x7bec9c: ldr             x9, [x9, #0xff8]
    // 0x7beca0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7beca0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7beca4, size: 0x4c
    // 0x7beca4: EnterFrame
    //     0x7beca4: stp             fp, lr, [SP, #-0x10]!
    //     0x7beca8: mov             fp, SP
    // 0x7becac: ldr             x0, [fp, #0x10]
    // 0x7becb0: LoadField: r1 = r0->field_17
    //     0x7becb0: ldur            w1, [x0, #0x17]
    // 0x7becb4: DecompressPointer r1
    //     0x7becb4: add             x1, x1, HEAP, lsl #32
    // 0x7becb8: CheckStackOverflow
    //     0x7becb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7becbc: cmp             SP, x16
    //     0x7becc0: b.ls            #0x7bece8
    // 0x7becc4: LoadField: r0 = r1->field_f
    //     0x7becc4: ldur            w0, [x1, #0xf]
    // 0x7becc8: DecompressPointer r0
    //     0x7becc8: add             x0, x0, HEAP, lsl #32
    // 0x7beccc: SaveReg r0
    //     0x7beccc: str             x0, [SP, #-8]!
    // 0x7becd0: r0 = _updateChildren()
    //     0x7becd0: bl              #0x7be074  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0x7becd4: add             SP, SP, #8
    // 0x7becd8: r0 = Null
    //     0x7becd8: mov             x0, NULL
    // 0x7becdc: LeaveFrame
    //     0x7becdc: mov             SP, fp
    //     0x7bece0: ldp             fp, lr, [SP], #0x10
    // 0x7bece4: ret
    //     0x7bece4: ret             
    // 0x7bece8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bece8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7becec: b               #0x7becc4
  }
  _ build(/* No info */) {
    // ** addr: 0x86a6e0, size: 0x148
    // 0x86a6e0: EnterFrame
    //     0x86a6e0: stp             fp, lr, [SP, #-0x10]!
    //     0x86a6e4: mov             fp, SP
    // 0x86a6e8: AllocStack(0x28)
    //     0x86a6e8: sub             SP, SP, #0x28
    // 0x86a6ec: CheckStackOverflow
    //     0x86a6ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a6f0: cmp             SP, x16
    //     0x86a6f4: b.ls            #0x86a804
    // 0x86a6f8: r1 = 1
    //     0x86a6f8: mov             x1, #1
    // 0x86a6fc: r0 = AllocateContext()
    //     0x86a6fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x86a700: mov             x1, x0
    // 0x86a704: ldr             x0, [fp, #0x18]
    // 0x86a708: stur            x1, [fp, #-0x10]
    // 0x86a70c: StoreField: r1->field_f = r0
    //     0x86a70c: stur            w0, [x1, #0xf]
    // 0x86a710: LoadField: r2 = r0->field_b
    //     0x86a710: ldur            w2, [x0, #0xb]
    // 0x86a714: DecompressPointer r2
    //     0x86a714: add             x2, x2, HEAP, lsl #32
    // 0x86a718: cmp             w2, NULL
    // 0x86a71c: b.eq            #0x86a80c
    // 0x86a720: LoadField: r3 = r0->field_17
    //     0x86a720: ldur            w3, [x0, #0x17]
    // 0x86a724: DecompressPointer r3
    //     0x86a724: add             x3, x3, HEAP, lsl #32
    // 0x86a728: r16 = Sentinel
    //     0x86a728: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86a72c: cmp             w3, w16
    // 0x86a730: b.eq            #0x86a810
    // 0x86a734: stur            x3, [fp, #-8]
    // 0x86a738: LoadField: r4 = r2->field_13
    //     0x86a738: ldur            w4, [x2, #0x13]
    // 0x86a73c: DecompressPointer r4
    //     0x86a73c: add             x4, x4, HEAP, lsl #32
    // 0x86a740: cmp             w4, NULL
    // 0x86a744: b.ne            #0x86a76c
    // 0x86a748: r16 = Instance_PageScrollPhysics
    //     0x86a748: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f408] Obj!PageScrollPhysics@b4fdc1
    //     0x86a74c: ldr             x16, [x16, #0x408]
    // 0x86a750: r30 = Instance_ClampingScrollPhysics
    //     0x86a750: add             lr, PP, #0x20, lsl #12  ; [pp+0x20200] Obj!ClampingScrollPhysics@b4fd31
    //     0x86a754: ldr             lr, [lr, #0x200]
    // 0x86a758: stp             lr, x16, [SP, #-0x10]!
    // 0x86a75c: r0 = applyTo()
    //     0x86a75c: bl              #0xc3b304  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0x86a760: add             SP, SP, #0x10
    // 0x86a764: mov             x1, x0
    // 0x86a768: b               #0x86a784
    // 0x86a76c: r16 = Instance_PageScrollPhysics
    //     0x86a76c: add             x16, PP, #0x2f, lsl #12  ; [pp+0x2f408] Obj!PageScrollPhysics@b4fdc1
    //     0x86a770: ldr             x16, [x16, #0x408]
    // 0x86a774: stp             x4, x16, [SP, #-0x10]!
    // 0x86a778: r0 = applyTo()
    //     0x86a778: bl              #0xc3b304  ; [package:flutter/src/widgets/page_view.dart] PageScrollPhysics::applyTo
    // 0x86a77c: add             SP, SP, #0x10
    // 0x86a780: mov             x1, x0
    // 0x86a784: ldr             x0, [fp, #0x18]
    // 0x86a788: stur            x1, [fp, #-0x20]
    // 0x86a78c: LoadField: r2 = r0->field_1f
    //     0x86a78c: ldur            w2, [x0, #0x1f]
    // 0x86a790: DecompressPointer r2
    //     0x86a790: add             x2, x2, HEAP, lsl #32
    // 0x86a794: r16 = Sentinel
    //     0x86a794: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86a798: cmp             w2, w16
    // 0x86a79c: b.eq            #0x86a81c
    // 0x86a7a0: stur            x2, [fp, #-0x18]
    // 0x86a7a4: r0 = PageView()
    //     0x86a7a4: bl              #0x8243b8  ; AllocatePageViewStub -> PageView (size=0x40)
    // 0x86a7a8: stur            x0, [fp, #-0x28]
    // 0x86a7ac: ldur            x16, [fp, #-0x18]
    // 0x86a7b0: stp             x16, x0, [SP, #-0x10]!
    // 0x86a7b4: ldur            x16, [fp, #-8]
    // 0x86a7b8: ldur            lr, [fp, #-0x20]
    // 0x86a7bc: stp             lr, x16, [SP, #-0x10]!
    // 0x86a7c0: r0 = PageView()
    //     0x86a7c0: bl              #0x86a828  ; [package:flutter/src/widgets/page_view.dart] PageView::PageView
    // 0x86a7c4: add             SP, SP, #0x20
    // 0x86a7c8: ldur            x2, [fp, #-0x10]
    // 0x86a7cc: r1 = Function '_handleScrollNotification@472014024':.
    //     0x86a7cc: add             x1, PP, #0x37, lsl #12  ; [pp+0x37fe8] AnonymousClosure: (0x86a914), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleScrollNotification (0x86a960)
    //     0x86a7d0: ldr             x1, [x1, #0xfe8]
    // 0x86a7d4: r0 = AllocateClosure()
    //     0x86a7d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86a7d8: r1 = <ScrollNotification>
    //     0x86a7d8: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2ccf8] TypeArguments: <ScrollNotification>
    //     0x86a7dc: ldr             x1, [x1, #0xcf8]
    // 0x86a7e0: stur            x0, [fp, #-8]
    // 0x86a7e4: r0 = NotificationListener()
    //     0x86a7e4: bl              #0x7bb850  ; AllocateNotificationListenerStub -> NotificationListener<X0 bound Notification> (size=0x18)
    // 0x86a7e8: ldur            x1, [fp, #-8]
    // 0x86a7ec: StoreField: r0->field_13 = r1
    //     0x86a7ec: stur            w1, [x0, #0x13]
    // 0x86a7f0: ldur            x1, [fp, #-0x28]
    // 0x86a7f4: StoreField: r0->field_b = r1
    //     0x86a7f4: stur            w1, [x0, #0xb]
    // 0x86a7f8: LeaveFrame
    //     0x86a7f8: mov             SP, fp
    //     0x86a7fc: ldp             fp, lr, [SP], #0x10
    // 0x86a800: ret
    //     0x86a800: ret             
    // 0x86a804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86a804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86a808: b               #0x86a6f8
    // 0x86a80c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a80c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a810: r9 = _pageController
    //     0x86a810: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff0] Field <_TabBarViewState@472014024._pageController@472014024>: late (offset: 0x18)
    //     0x86a814: ldr             x9, [x9, #0xff0]
    // 0x86a818: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86a818: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86a81c: r9 = _childrenWithKey
    //     0x86a81c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff8] Field <_TabBarViewState@472014024._childrenWithKey@472014024>: late (offset: 0x20)
    //     0x86a820: ldr             x9, [x9, #0xff8]
    // 0x86a824: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86a824: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool _handleScrollNotification(dynamic, ScrollNotification) {
    // ** addr: 0x86a914, size: 0x4c
    // 0x86a914: EnterFrame
    //     0x86a914: stp             fp, lr, [SP, #-0x10]!
    //     0x86a918: mov             fp, SP
    // 0x86a91c: ldr             x0, [fp, #0x18]
    // 0x86a920: LoadField: r1 = r0->field_17
    //     0x86a920: ldur            w1, [x0, #0x17]
    // 0x86a924: DecompressPointer r1
    //     0x86a924: add             x1, x1, HEAP, lsl #32
    // 0x86a928: CheckStackOverflow
    //     0x86a928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a92c: cmp             SP, x16
    //     0x86a930: b.ls            #0x86a958
    // 0x86a934: LoadField: r0 = r1->field_f
    //     0x86a934: ldur            w0, [x1, #0xf]
    // 0x86a938: DecompressPointer r0
    //     0x86a938: add             x0, x0, HEAP, lsl #32
    // 0x86a93c: ldr             x16, [fp, #0x10]
    // 0x86a940: stp             x16, x0, [SP, #-0x10]!
    // 0x86a944: r0 = _handleScrollNotification()
    //     0x86a944: bl              #0x86a960  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleScrollNotification
    // 0x86a948: add             SP, SP, #0x10
    // 0x86a94c: LeaveFrame
    //     0x86a94c: mov             SP, fp
    //     0x86a950: ldp             fp, lr, [SP], #0x10
    // 0x86a954: ret
    //     0x86a954: ret             
    // 0x86a958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86a958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86a95c: b               #0x86a934
  }
  _ _handleScrollNotification(/* No info */) {
    // ** addr: 0x86a960, size: 0x6ac
    // 0x86a960: EnterFrame
    //     0x86a960: stp             fp, lr, [SP, #-0x10]!
    //     0x86a964: mov             fp, SP
    // 0x86a968: AllocStack(0x10)
    //     0x86a968: sub             SP, SP, #0x10
    // 0x86a96c: CheckStackOverflow
    //     0x86a96c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a970: cmp             SP, x16
    //     0x86a974: b.ls            #0x86af84
    // 0x86a978: ldr             x0, [fp, #0x18]
    // 0x86a97c: LoadField: r1 = r0->field_27
    //     0x86a97c: ldur            x1, [x0, #0x27]
    // 0x86a980: cmp             x1, #0
    // 0x86a984: b.le            #0x86a998
    // 0x86a988: r0 = false
    //     0x86a988: add             x0, NULL, #0x30  ; false
    // 0x86a98c: LeaveFrame
    //     0x86a98c: mov             SP, fp
    //     0x86a990: ldp             fp, lr, [SP], #0x10
    // 0x86a994: ret
    //     0x86a994: ret             
    // 0x86a998: ldr             x2, [fp, #0x10]
    // 0x86a99c: LoadField: r3 = r2->field_7
    //     0x86a99c: ldur            x3, [x2, #7]
    // 0x86a9a0: cbz             x3, #0x86a9b4
    // 0x86a9a4: r0 = false
    //     0x86a9a4: add             x0, NULL, #0x30  ; false
    // 0x86a9a8: LeaveFrame
    //     0x86a9a8: mov             SP, fp
    //     0x86a9ac: ldp             fp, lr, [SP], #0x10
    // 0x86a9b0: ret
    //     0x86a9b0: ret             
    // 0x86a9b4: add             x3, x1, #1
    // 0x86a9b8: StoreField: r0->field_27 = r3
    //     0x86a9b8: stur            x3, [x0, #0x27]
    // 0x86a9bc: r1 = LoadClassIdInstr(r2)
    //     0x86a9bc: ldur            x1, [x2, #-1]
    //     0x86a9c0: ubfx            x1, x1, #0xc, #0x14
    // 0x86a9c4: lsl             x1, x1, #1
    // 0x86a9c8: r2 = LoadInt32Instr(r1)
    //     0x86a9c8: sbfx            x2, x1, #1, #0x1f
    // 0x86a9cc: cmp             x2, #0x731
    // 0x86a9d0: b.lt            #0x86ad14
    // 0x86a9d4: cmp             x2, #0x732
    // 0x86a9d8: b.gt            #0x86ad0c
    // 0x86a9dc: LoadField: r2 = r0->field_13
    //     0x86a9dc: ldur            w2, [x0, #0x13]
    // 0x86a9e0: DecompressPointer r2
    //     0x86a9e0: add             x2, x2, HEAP, lsl #32
    // 0x86a9e4: cmp             w2, NULL
    // 0x86a9e8: b.eq            #0x86af8c
    // 0x86a9ec: LoadField: r3 = r2->field_43
    //     0x86a9ec: ldur            x3, [x2, #0x43]
    // 0x86a9f0: cbnz            x3, #0x86ad04
    // 0x86a9f4: LoadField: r1 = r0->field_17
    //     0x86a9f4: ldur            w1, [x0, #0x17]
    // 0x86a9f8: DecompressPointer r1
    //     0x86a9f8: add             x1, x1, HEAP, lsl #32
    // 0x86a9fc: r16 = Sentinel
    //     0x86a9fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86aa00: cmp             w1, w16
    // 0x86aa04: b.eq            #0x86af90
    // 0x86aa08: LoadField: r2 = r1->field_33
    //     0x86aa08: ldur            w2, [x1, #0x33]
    // 0x86aa0c: DecompressPointer r2
    //     0x86aa0c: add             x2, x2, HEAP, lsl #32
    // 0x86aa10: SaveReg r2
    //     0x86aa10: str             x2, [SP, #-8]!
    // 0x86aa14: r0 = single()
    //     0x86aa14: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x86aa18: add             SP, SP, #8
    // 0x86aa1c: mov             x3, x0
    // 0x86aa20: r2 = Null
    //     0x86aa20: mov             x2, NULL
    // 0x86aa24: r1 = Null
    //     0x86aa24: mov             x1, NULL
    // 0x86aa28: stur            x3, [fp, #-8]
    // 0x86aa2c: r4 = LoadClassIdInstr(r0)
    //     0x86aa2c: ldur            x4, [x0, #-1]
    //     0x86aa30: ubfx            x4, x4, #0xc, #0x14
    // 0x86aa34: r17 = 4847
    //     0x86aa34: mov             x17, #0x12ef
    // 0x86aa38: cmp             x4, x17
    // 0x86aa3c: b.eq            #0x86aa54
    // 0x86aa40: r8 = _PagePosition
    //     0x86aa40: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x86aa44: ldr             x8, [x8, #0xf98]
    // 0x86aa48: r3 = Null
    //     0x86aa48: add             x3, PP, #0x38, lsl #12  ; [pp+0x38000] Null
    //     0x86aa4c: ldr             x3, [x3]
    // 0x86aa50: r0 = DefaultTypeTest()
    //     0x86aa50: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x86aa54: ldur            x16, [fp, #-8]
    // 0x86aa58: SaveReg r16
    //     0x86aa58: str             x16, [SP, #-8]!
    // 0x86aa5c: r0 = page()
    //     0x86aa5c: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x86aa60: add             SP, SP, #8
    // 0x86aa64: cmp             w0, NULL
    // 0x86aa68: b.eq            #0x86af9c
    // 0x86aa6c: ldr             x1, [fp, #0x18]
    // 0x86aa70: LoadField: r2 = r1->field_13
    //     0x86aa70: ldur            w2, [x1, #0x13]
    // 0x86aa74: DecompressPointer r2
    //     0x86aa74: add             x2, x2, HEAP, lsl #32
    // 0x86aa78: stur            x2, [fp, #-8]
    // 0x86aa7c: cmp             w2, NULL
    // 0x86aa80: b.eq            #0x86afa0
    // 0x86aa84: LoadField: r3 = r2->field_33
    //     0x86aa84: ldur            x3, [x2, #0x33]
    // 0x86aa88: scvtf           d0, x3
    // 0x86aa8c: LoadField: d1 = r0->field_7
    //     0x86aa8c: ldur            d1, [x0, #7]
    // 0x86aa90: fsub            d2, d1, d0
    // 0x86aa94: d0 = 0.000000
    //     0x86aa94: eor             v0.16b, v0.16b, v0.16b
    // 0x86aa98: fcmp            d2, d0
    // 0x86aa9c: b.vs            #0x86aaac
    // 0x86aaa0: b.ne            #0x86aaac
    // 0x86aaa4: d1 = 0.000000
    //     0x86aaa4: eor             v1.16b, v1.16b, v1.16b
    // 0x86aaa8: b               #0x86aac8
    // 0x86aaac: fcmp            d2, d0
    // 0x86aab0: b.vs            #0x86aac0
    // 0x86aab4: b.ge            #0x86aac0
    // 0x86aab8: fneg            d0, d2
    // 0x86aabc: b               #0x86aac4
    // 0x86aac0: mov             v0.16b, v2.16b
    // 0x86aac4: mov             v1.16b, v0.16b
    // 0x86aac8: d0 = 1.000000
    //     0x86aac8: fmov            d0, #1.00000000
    // 0x86aacc: fcmp            d1, d0
    // 0x86aad0: b.vs            #0x86ac0c
    // 0x86aad4: b.le            #0x86ac0c
    // 0x86aad8: LoadField: r0 = r1->field_17
    //     0x86aad8: ldur            w0, [x1, #0x17]
    // 0x86aadc: DecompressPointer r0
    //     0x86aadc: add             x0, x0, HEAP, lsl #32
    // 0x86aae0: LoadField: r3 = r0->field_33
    //     0x86aae0: ldur            w3, [x0, #0x33]
    // 0x86aae4: DecompressPointer r3
    //     0x86aae4: add             x3, x3, HEAP, lsl #32
    // 0x86aae8: SaveReg r3
    //     0x86aae8: str             x3, [SP, #-8]!
    // 0x86aaec: r0 = single()
    //     0x86aaec: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x86aaf0: add             SP, SP, #8
    // 0x86aaf4: mov             x3, x0
    // 0x86aaf8: r2 = Null
    //     0x86aaf8: mov             x2, NULL
    // 0x86aafc: r1 = Null
    //     0x86aafc: mov             x1, NULL
    // 0x86ab00: stur            x3, [fp, #-0x10]
    // 0x86ab04: r4 = LoadClassIdInstr(r0)
    //     0x86ab04: ldur            x4, [x0, #-1]
    //     0x86ab08: ubfx            x4, x4, #0xc, #0x14
    // 0x86ab0c: r17 = 4847
    //     0x86ab0c: mov             x17, #0x12ef
    // 0x86ab10: cmp             x4, x17
    // 0x86ab14: b.eq            #0x86ab2c
    // 0x86ab18: r8 = _PagePosition
    //     0x86ab18: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x86ab1c: ldr             x8, [x8, #0xf98]
    // 0x86ab20: r3 = Null
    //     0x86ab20: add             x3, PP, #0x38, lsl #12  ; [pp+0x38010] Null
    //     0x86ab24: ldr             x3, [x3, #0x10]
    // 0x86ab28: r0 = DefaultTypeTest()
    //     0x86ab28: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x86ab2c: ldur            x16, [fp, #-0x10]
    // 0x86ab30: SaveReg r16
    //     0x86ab30: str             x16, [SP, #-8]!
    // 0x86ab34: r0 = page()
    //     0x86ab34: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x86ab38: add             SP, SP, #8
    // 0x86ab3c: cmp             w0, NULL
    // 0x86ab40: b.eq            #0x86afa4
    // 0x86ab44: LoadField: d0 = r0->field_7
    //     0x86ab44: ldur            d0, [x0, #7]
    // 0x86ab48: stp             fp, lr, [SP, #-0x10]!
    // 0x86ab4c: mov             fp, SP
    // 0x86ab50: CallRuntime_LibcRound(double) -> double
    //     0x86ab50: and             SP, SP, #0xfffffffffffffff0
    //     0x86ab54: mov             sp, SP
    //     0x86ab58: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x86ab5c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x86ab60: blr             x16
    //     0x86ab64: mov             x16, #8
    //     0x86ab68: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x86ab6c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x86ab70: sub             sp, x16, #1, lsl #12
    //     0x86ab74: mov             SP, fp
    //     0x86ab78: ldp             fp, lr, [SP], #0x10
    // 0x86ab7c: fcmp            d0, d0
    // 0x86ab80: b.vs            #0x86afa8
    // 0x86ab84: fcvtzs          x0, d0
    // 0x86ab88: asr             x16, x0, #0x1e
    // 0x86ab8c: cmp             x16, x0, asr #63
    // 0x86ab90: b.ne            #0x86afa8
    // 0x86ab94: lsl             x0, x0, #1
    // 0x86ab98: r1 = LoadInt32Instr(r0)
    //     0x86ab98: sbfx            x1, x0, #1, #0x1f
    //     0x86ab9c: tbz             w0, #0, #0x86aba4
    //     0x86aba0: ldur            x1, [x0, #7]
    // 0x86aba4: ldur            x16, [fp, #-8]
    // 0x86aba8: stp             x1, x16, [SP, #-0x10]!
    // 0x86abac: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x86abac: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x86abb0: r0 = _changeIndex()
    //     0x86abb0: bl              #0x82637c  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0x86abb4: add             SP, SP, #0x10
    // 0x86abb8: ldr             x2, [fp, #0x18]
    // 0x86abbc: LoadField: r3 = r2->field_13
    //     0x86abbc: ldur            w3, [x2, #0x13]
    // 0x86abc0: DecompressPointer r3
    //     0x86abc0: add             x3, x3, HEAP, lsl #32
    // 0x86abc4: cmp             w3, NULL
    // 0x86abc8: b.eq            #0x86afc4
    // 0x86abcc: LoadField: r4 = r3->field_33
    //     0x86abcc: ldur            x4, [x3, #0x33]
    // 0x86abd0: r0 = BoxInt64Instr(r4)
    //     0x86abd0: sbfiz           x0, x4, #1, #0x1f
    //     0x86abd4: cmp             x4, x0, asr #1
    //     0x86abd8: b.eq            #0x86abe4
    //     0x86abdc: bl              #0xd69bb8
    //     0x86abe0: stur            x4, [x0, #7]
    // 0x86abe4: StoreField: r2->field_23 = r0
    //     0x86abe4: stur            w0, [x2, #0x23]
    //     0x86abe8: tbz             w0, #0, #0x86ac04
    //     0x86abec: ldurb           w16, [x2, #-1]
    //     0x86abf0: ldurb           w17, [x0, #-1]
    //     0x86abf4: and             x16, x17, x16, lsr #2
    //     0x86abf8: tst             x16, HEAP, lsr #32
    //     0x86abfc: b.eq            #0x86ac04
    //     0x86ac00: bl              #0xd6828c
    // 0x86ac04: mov             x0, x3
    // 0x86ac08: b               #0x86ac14
    // 0x86ac0c: mov             x2, x1
    // 0x86ac10: ldur            x0, [fp, #-8]
    // 0x86ac14: stur            x0, [fp, #-8]
    // 0x86ac18: LoadField: r1 = r2->field_17
    //     0x86ac18: ldur            w1, [x2, #0x17]
    // 0x86ac1c: DecompressPointer r1
    //     0x86ac1c: add             x1, x1, HEAP, lsl #32
    // 0x86ac20: LoadField: r3 = r1->field_33
    //     0x86ac20: ldur            w3, [x1, #0x33]
    // 0x86ac24: DecompressPointer r3
    //     0x86ac24: add             x3, x3, HEAP, lsl #32
    // 0x86ac28: SaveReg r3
    //     0x86ac28: str             x3, [SP, #-8]!
    // 0x86ac2c: r0 = single()
    //     0x86ac2c: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x86ac30: add             SP, SP, #8
    // 0x86ac34: mov             x3, x0
    // 0x86ac38: r2 = Null
    //     0x86ac38: mov             x2, NULL
    // 0x86ac3c: r1 = Null
    //     0x86ac3c: mov             x1, NULL
    // 0x86ac40: stur            x3, [fp, #-0x10]
    // 0x86ac44: r4 = LoadClassIdInstr(r0)
    //     0x86ac44: ldur            x4, [x0, #-1]
    //     0x86ac48: ubfx            x4, x4, #0xc, #0x14
    // 0x86ac4c: r17 = 4847
    //     0x86ac4c: mov             x17, #0x12ef
    // 0x86ac50: cmp             x4, x17
    // 0x86ac54: b.eq            #0x86ac6c
    // 0x86ac58: r8 = _PagePosition
    //     0x86ac58: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x86ac5c: ldr             x8, [x8, #0xf98]
    // 0x86ac60: r3 = Null
    //     0x86ac60: add             x3, PP, #0x38, lsl #12  ; [pp+0x38020] Null
    //     0x86ac64: ldr             x3, [x3, #0x20]
    // 0x86ac68: r0 = DefaultTypeTest()
    //     0x86ac68: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x86ac6c: ldur            x16, [fp, #-0x10]
    // 0x86ac70: SaveReg r16
    //     0x86ac70: str             x16, [SP, #-8]!
    // 0x86ac74: r0 = page()
    //     0x86ac74: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x86ac78: add             SP, SP, #8
    // 0x86ac7c: cmp             w0, NULL
    // 0x86ac80: b.eq            #0x86afc8
    // 0x86ac84: ldr             x1, [fp, #0x18]
    // 0x86ac88: LoadField: r2 = r1->field_13
    //     0x86ac88: ldur            w2, [x1, #0x13]
    // 0x86ac8c: DecompressPointer r2
    //     0x86ac8c: add             x2, x2, HEAP, lsl #32
    // 0x86ac90: cmp             w2, NULL
    // 0x86ac94: b.eq            #0x86afcc
    // 0x86ac98: LoadField: r3 = r2->field_33
    //     0x86ac98: ldur            x3, [x2, #0x33]
    // 0x86ac9c: scvtf           d0, x3
    // 0x86aca0: LoadField: d1 = r0->field_7
    //     0x86aca0: ldur            d1, [x0, #7]
    // 0x86aca4: fsub            d2, d1, d0
    // 0x86aca8: d0 = 1.000000
    //     0x86aca8: fmov            d0, #1.00000000
    // 0x86acac: fneg            d1, d0
    // 0x86acb0: fcmp            d2, d1
    // 0x86acb4: b.vs            #0x86acc4
    // 0x86acb8: b.ge            #0x86acc4
    // 0x86acbc: mov             v0.16b, v1.16b
    // 0x86acc0: b               #0x86acec
    // 0x86acc4: fcmp            d2, d0
    // 0x86acc8: b.vs            #0x86acd8
    // 0x86accc: b.le            #0x86acd8
    // 0x86acd0: d0 = 1.000000
    //     0x86acd0: fmov            d0, #1.00000000
    // 0x86acd4: b               #0x86acec
    // 0x86acd8: fcmp            d2, d2
    // 0x86acdc: b.vc            #0x86ace8
    // 0x86ace0: d0 = 1.000000
    //     0x86ace0: fmov            d0, #1.00000000
    // 0x86ace4: b               #0x86acec
    // 0x86ace8: mov             v0.16b, v2.16b
    // 0x86acec: ldur            x16, [fp, #-8]
    // 0x86acf0: SaveReg r16
    //     0x86acf0: str             x16, [SP, #-8]!
    // 0x86acf4: SaveReg d0
    //     0x86acf4: str             d0, [SP, #-8]!
    // 0x86acf8: r0 = offset=()
    //     0x86acf8: bl              #0x8341b8  ; [package:flutter/src/material/tab_controller.dart] TabController::offset=
    // 0x86acfc: add             SP, SP, #0x10
    // 0x86ad00: b               #0x86af64
    // 0x86ad04: d0 = 1.000000
    //     0x86ad04: fmov            d0, #1.00000000
    // 0x86ad08: b               #0x86ad18
    // 0x86ad0c: d0 = 1.000000
    //     0x86ad0c: fmov            d0, #1.00000000
    // 0x86ad10: b               #0x86ad18
    // 0x86ad14: d0 = 1.000000
    //     0x86ad14: fmov            d0, #1.00000000
    // 0x86ad18: cmp             w1, #0xe5e
    // 0x86ad1c: b.ne            #0x86af64
    // 0x86ad20: ldr             x0, [fp, #0x18]
    // 0x86ad24: LoadField: r1 = r0->field_13
    //     0x86ad24: ldur            w1, [x0, #0x13]
    // 0x86ad28: DecompressPointer r1
    //     0x86ad28: add             x1, x1, HEAP, lsl #32
    // 0x86ad2c: stur            x1, [fp, #-8]
    // 0x86ad30: cmp             w1, NULL
    // 0x86ad34: b.eq            #0x86afd0
    // 0x86ad38: LoadField: r2 = r0->field_17
    //     0x86ad38: ldur            w2, [x0, #0x17]
    // 0x86ad3c: DecompressPointer r2
    //     0x86ad3c: add             x2, x2, HEAP, lsl #32
    // 0x86ad40: r16 = Sentinel
    //     0x86ad40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86ad44: cmp             w2, w16
    // 0x86ad48: b.eq            #0x86afd4
    // 0x86ad4c: LoadField: r3 = r2->field_33
    //     0x86ad4c: ldur            w3, [x2, #0x33]
    // 0x86ad50: DecompressPointer r3
    //     0x86ad50: add             x3, x3, HEAP, lsl #32
    // 0x86ad54: SaveReg r3
    //     0x86ad54: str             x3, [SP, #-8]!
    // 0x86ad58: r0 = single()
    //     0x86ad58: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x86ad5c: add             SP, SP, #8
    // 0x86ad60: mov             x3, x0
    // 0x86ad64: r2 = Null
    //     0x86ad64: mov             x2, NULL
    // 0x86ad68: r1 = Null
    //     0x86ad68: mov             x1, NULL
    // 0x86ad6c: stur            x3, [fp, #-0x10]
    // 0x86ad70: r4 = LoadClassIdInstr(r0)
    //     0x86ad70: ldur            x4, [x0, #-1]
    //     0x86ad74: ubfx            x4, x4, #0xc, #0x14
    // 0x86ad78: r17 = 4847
    //     0x86ad78: mov             x17, #0x12ef
    // 0x86ad7c: cmp             x4, x17
    // 0x86ad80: b.eq            #0x86ad98
    // 0x86ad84: r8 = _PagePosition
    //     0x86ad84: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x86ad88: ldr             x8, [x8, #0xf98]
    // 0x86ad8c: r3 = Null
    //     0x86ad8c: add             x3, PP, #0x38, lsl #12  ; [pp+0x38030] Null
    //     0x86ad90: ldr             x3, [x3, #0x30]
    // 0x86ad94: r0 = DefaultTypeTest()
    //     0x86ad94: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x86ad98: ldur            x16, [fp, #-0x10]
    // 0x86ad9c: SaveReg r16
    //     0x86ad9c: str             x16, [SP, #-8]!
    // 0x86ada0: r0 = page()
    //     0x86ada0: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x86ada4: add             SP, SP, #8
    // 0x86ada8: cmp             w0, NULL
    // 0x86adac: b.eq            #0x86afe0
    // 0x86adb0: LoadField: d0 = r0->field_7
    //     0x86adb0: ldur            d0, [x0, #7]
    // 0x86adb4: stp             fp, lr, [SP, #-0x10]!
    // 0x86adb8: mov             fp, SP
    // 0x86adbc: CallRuntime_LibcRound(double) -> double
    //     0x86adbc: and             SP, SP, #0xfffffffffffffff0
    //     0x86adc0: mov             sp, SP
    //     0x86adc4: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x86adc8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x86adcc: blr             x16
    //     0x86add0: mov             x16, #8
    //     0x86add4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x86add8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x86addc: sub             sp, x16, #1, lsl #12
    //     0x86ade0: mov             SP, fp
    //     0x86ade4: ldp             fp, lr, [SP], #0x10
    // 0x86ade8: fcmp            d0, d0
    // 0x86adec: b.vs            #0x86afe4
    // 0x86adf0: fcvtzs          x0, d0
    // 0x86adf4: asr             x16, x0, #0x1e
    // 0x86adf8: cmp             x16, x0, asr #63
    // 0x86adfc: b.ne            #0x86afe4
    // 0x86ae00: lsl             x0, x0, #1
    // 0x86ae04: r1 = LoadInt32Instr(r0)
    //     0x86ae04: sbfx            x1, x0, #1, #0x1f
    //     0x86ae08: tbz             w0, #0, #0x86ae10
    //     0x86ae0c: ldur            x1, [x0, #7]
    // 0x86ae10: ldur            x16, [fp, #-8]
    // 0x86ae14: stp             x1, x16, [SP, #-0x10]!
    // 0x86ae18: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x86ae18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x86ae1c: r0 = _changeIndex()
    //     0x86ae1c: bl              #0x82637c  ; [package:flutter/src/material/tab_controller.dart] TabController::_changeIndex
    // 0x86ae20: add             SP, SP, #0x10
    // 0x86ae24: ldr             x2, [fp, #0x18]
    // 0x86ae28: LoadField: r3 = r2->field_13
    //     0x86ae28: ldur            w3, [x2, #0x13]
    // 0x86ae2c: DecompressPointer r3
    //     0x86ae2c: add             x3, x3, HEAP, lsl #32
    // 0x86ae30: stur            x3, [fp, #-8]
    // 0x86ae34: cmp             w3, NULL
    // 0x86ae38: b.eq            #0x86b000
    // 0x86ae3c: LoadField: r4 = r3->field_33
    //     0x86ae3c: ldur            x4, [x3, #0x33]
    // 0x86ae40: r0 = BoxInt64Instr(r4)
    //     0x86ae40: sbfiz           x0, x4, #1, #0x1f
    //     0x86ae44: cmp             x4, x0, asr #1
    //     0x86ae48: b.eq            #0x86ae54
    //     0x86ae4c: bl              #0xd69bb8
    //     0x86ae50: stur            x4, [x0, #7]
    // 0x86ae54: StoreField: r2->field_23 = r0
    //     0x86ae54: stur            w0, [x2, #0x23]
    //     0x86ae58: tbz             w0, #0, #0x86ae74
    //     0x86ae5c: ldurb           w16, [x2, #-1]
    //     0x86ae60: ldurb           w17, [x0, #-1]
    //     0x86ae64: and             x16, x17, x16, lsr #2
    //     0x86ae68: tst             x16, HEAP, lsr #32
    //     0x86ae6c: b.eq            #0x86ae74
    //     0x86ae70: bl              #0xd6828c
    // 0x86ae74: LoadField: r0 = r3->field_43
    //     0x86ae74: ldur            x0, [x3, #0x43]
    // 0x86ae78: cbnz            x0, #0x86af64
    // 0x86ae7c: LoadField: r0 = r2->field_17
    //     0x86ae7c: ldur            w0, [x2, #0x17]
    // 0x86ae80: DecompressPointer r0
    //     0x86ae80: add             x0, x0, HEAP, lsl #32
    // 0x86ae84: LoadField: r1 = r0->field_33
    //     0x86ae84: ldur            w1, [x0, #0x33]
    // 0x86ae88: DecompressPointer r1
    //     0x86ae88: add             x1, x1, HEAP, lsl #32
    // 0x86ae8c: SaveReg r1
    //     0x86ae8c: str             x1, [SP, #-8]!
    // 0x86ae90: r0 = single()
    //     0x86ae90: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x86ae94: add             SP, SP, #8
    // 0x86ae98: mov             x3, x0
    // 0x86ae9c: r2 = Null
    //     0x86ae9c: mov             x2, NULL
    // 0x86aea0: r1 = Null
    //     0x86aea0: mov             x1, NULL
    // 0x86aea4: stur            x3, [fp, #-0x10]
    // 0x86aea8: r4 = LoadClassIdInstr(r0)
    //     0x86aea8: ldur            x4, [x0, #-1]
    //     0x86aeac: ubfx            x4, x4, #0xc, #0x14
    // 0x86aeb0: r17 = 4847
    //     0x86aeb0: mov             x17, #0x12ef
    // 0x86aeb4: cmp             x4, x17
    // 0x86aeb8: b.eq            #0x86aed0
    // 0x86aebc: r8 = _PagePosition
    //     0x86aebc: add             x8, PP, #0x32, lsl #12  ; [pp+0x32f98] Type: _PagePosition
    //     0x86aec0: ldr             x8, [x8, #0xf98]
    // 0x86aec4: r3 = Null
    //     0x86aec4: add             x3, PP, #0x38, lsl #12  ; [pp+0x38040] Null
    //     0x86aec8: ldr             x3, [x3, #0x40]
    // 0x86aecc: r0 = DefaultTypeTest()
    //     0x86aecc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x86aed0: ldur            x16, [fp, #-0x10]
    // 0x86aed4: SaveReg r16
    //     0x86aed4: str             x16, [SP, #-8]!
    // 0x86aed8: r0 = page()
    //     0x86aed8: bl              #0x7a1f64  ; [package:flutter/src/widgets/page_view.dart] _PagePosition::page
    // 0x86aedc: add             SP, SP, #8
    // 0x86aee0: cmp             w0, NULL
    // 0x86aee4: b.eq            #0x86b004
    // 0x86aee8: ldr             x1, [fp, #0x18]
    // 0x86aeec: LoadField: r2 = r1->field_13
    //     0x86aeec: ldur            w2, [x1, #0x13]
    // 0x86aef0: DecompressPointer r2
    //     0x86aef0: add             x2, x2, HEAP, lsl #32
    // 0x86aef4: cmp             w2, NULL
    // 0x86aef8: b.eq            #0x86b008
    // 0x86aefc: LoadField: r3 = r2->field_33
    //     0x86aefc: ldur            x3, [x2, #0x33]
    // 0x86af00: scvtf           d0, x3
    // 0x86af04: LoadField: d1 = r0->field_7
    //     0x86af04: ldur            d1, [x0, #7]
    // 0x86af08: fsub            d2, d1, d0
    // 0x86af0c: d0 = 1.000000
    //     0x86af0c: fmov            d0, #1.00000000
    // 0x86af10: fneg            d1, d0
    // 0x86af14: fcmp            d2, d1
    // 0x86af18: b.vs            #0x86af28
    // 0x86af1c: b.ge            #0x86af28
    // 0x86af20: mov             v0.16b, v1.16b
    // 0x86af24: b               #0x86af50
    // 0x86af28: fcmp            d2, d0
    // 0x86af2c: b.vs            #0x86af3c
    // 0x86af30: b.le            #0x86af3c
    // 0x86af34: d0 = 1.000000
    //     0x86af34: fmov            d0, #1.00000000
    // 0x86af38: b               #0x86af50
    // 0x86af3c: fcmp            d2, d2
    // 0x86af40: b.vc            #0x86af4c
    // 0x86af44: d0 = 1.000000
    //     0x86af44: fmov            d0, #1.00000000
    // 0x86af48: b               #0x86af50
    // 0x86af4c: mov             v0.16b, v2.16b
    // 0x86af50: ldur            x16, [fp, #-8]
    // 0x86af54: SaveReg r16
    //     0x86af54: str             x16, [SP, #-8]!
    // 0x86af58: SaveReg d0
    //     0x86af58: str             d0, [SP, #-8]!
    // 0x86af5c: r0 = offset=()
    //     0x86af5c: bl              #0x8341b8  ; [package:flutter/src/material/tab_controller.dart] TabController::offset=
    // 0x86af60: add             SP, SP, #0x10
    // 0x86af64: ldr             x1, [fp, #0x18]
    // 0x86af68: LoadField: r2 = r1->field_27
    //     0x86af68: ldur            x2, [x1, #0x27]
    // 0x86af6c: sub             x3, x2, #1
    // 0x86af70: StoreField: r1->field_27 = r3
    //     0x86af70: stur            x3, [x1, #0x27]
    // 0x86af74: r0 = false
    //     0x86af74: add             x0, NULL, #0x30  ; false
    // 0x86af78: LeaveFrame
    //     0x86af78: mov             SP, fp
    //     0x86af7c: ldp             fp, lr, [SP], #0x10
    // 0x86af80: ret
    //     0x86af80: ret             
    // 0x86af84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86af84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86af88: b               #0x86a978
    // 0x86af8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86af8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86af90: r9 = _pageController
    //     0x86af90: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff0] Field <_TabBarViewState@472014024._pageController@472014024>: late (offset: 0x18)
    //     0x86af94: ldr             x9, [x9, #0xff0]
    // 0x86af98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86af98: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86af9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86af9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86afa0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86afa4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afa8: SaveReg d0
    //     0x86afa8: str             q0, [SP, #-0x10]!
    // 0x86afac: r0 = 218
    //     0x86afac: mov             x0, #0xda
    // 0x86afb0: r24 = DoubleToIntegerStub
    //     0x86afb0: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x86afb4: LoadField: r30 = r24->field_7
    //     0x86afb4: ldur            lr, [x24, #7]
    // 0x86afb8: blr             lr
    // 0x86afbc: RestoreReg d0
    //     0x86afbc: ldr             q0, [SP], #0x10
    // 0x86afc0: b               #0x86ab98
    // 0x86afc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86afc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86afc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86afcc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afd0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x86afd0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x86afd4: r9 = _pageController
    //     0x86afd4: add             x9, PP, #0x37, lsl #12  ; [pp+0x37ff0] Field <_TabBarViewState@472014024._pageController@472014024>: late (offset: 0x18)
    //     0x86afd8: ldr             x9, [x9, #0xff0]
    // 0x86afdc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x86afdc: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x86afe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86afe0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86afe4: SaveReg d0
    //     0x86afe4: str             q0, [SP, #-0x10]!
    // 0x86afe8: r0 = 218
    //     0x86afe8: mov             x0, #0xda
    // 0x86afec: r24 = DoubleToIntegerStub
    //     0x86afec: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x86aff0: LoadField: r30 = r24->field_7
    //     0x86aff0: ldur            lr, [x24, #7]
    // 0x86aff4: blr             lr
    // 0x86aff8: RestoreReg d0
    //     0x86aff8: ldr             q0, [SP], #0x10
    // 0x86affc: b               #0x86ae04
    // 0x86b000: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86b000: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86b004: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86b004: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86b008: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86b008: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dbde8, size: 0x3c
    // 0x9dbde8: EnterFrame
    //     0x9dbde8: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbdec: mov             fp, SP
    // 0x9dbdf0: CheckStackOverflow
    //     0x9dbdf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbdf4: cmp             SP, x16
    //     0x9dbdf8: b.ls            #0x9dbe1c
    // 0x9dbdfc: ldr             x16, [fp, #0x10]
    // 0x9dbe00: SaveReg r16
    //     0x9dbe00: str             x16, [SP, #-8]!
    // 0x9dbe04: r0 = _updateChildren()
    //     0x9dbe04: bl              #0x7be074  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateChildren
    // 0x9dbe08: add             SP, SP, #8
    // 0x9dbe0c: r0 = Null
    //     0x9dbe0c: mov             x0, NULL
    // 0x9dbe10: LeaveFrame
    //     0x9dbe10: mov             SP, fp
    //     0x9dbe14: ldp             fp, lr, [SP], #0x10
    // 0x9dbe18: ret
    //     0x9dbe18: ret             
    // 0x9dbe1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbe1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbe20: b               #0x9dbdfc
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b2a8, size: 0x18
    // 0xa4b2a8: r4 = 7
    //     0xa4b2a8: mov             x4, #7
    // 0xa4b2ac: r1 = Function 'dispose':.
    //     0xa4b2ac: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bf00] AnonymousClosure: (0xa4b2c0), in [package:flutter/src/material/tabs.dart] _TabBarViewState::dispose (0xa52e3c)
    //     0xa4b2b0: ldr             x1, [x17, #0xf00]
    // 0xa4b2b4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b2b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b2b8: LoadField: r0 = r24->field_17
    //     0xa4b2b8: ldur            x0, [x24, #0x17]
    // 0xa4b2bc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b2c0, size: 0x48
    // 0xa4b2c0: EnterFrame
    //     0xa4b2c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b2c4: mov             fp, SP
    // 0xa4b2c8: ldr             x0, [fp, #0x10]
    // 0xa4b2cc: LoadField: r1 = r0->field_17
    //     0xa4b2cc: ldur            w1, [x0, #0x17]
    // 0xa4b2d0: DecompressPointer r1
    //     0xa4b2d0: add             x1, x1, HEAP, lsl #32
    // 0xa4b2d4: CheckStackOverflow
    //     0xa4b2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b2d8: cmp             SP, x16
    //     0xa4b2dc: b.ls            #0xa4b300
    // 0xa4b2e0: LoadField: r0 = r1->field_f
    //     0xa4b2e0: ldur            w0, [x1, #0xf]
    // 0xa4b2e4: DecompressPointer r0
    //     0xa4b2e4: add             x0, x0, HEAP, lsl #32
    // 0xa4b2e8: SaveReg r0
    //     0xa4b2e8: str             x0, [SP, #-8]!
    // 0xa4b2ec: r0 = dispose()
    //     0xa4b2ec: bl              #0xa52e3c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::dispose
    // 0xa4b2f0: add             SP, SP, #8
    // 0xa4b2f4: LeaveFrame
    //     0xa4b2f4: mov             SP, fp
    //     0xa4b2f8: ldp             fp, lr, [SP], #0x10
    // 0xa4b2fc: ret
    //     0xa4b2fc: ret             
    // 0xa4b300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b304: b               #0xa4b2e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52e3c, size: 0xc4
    // 0xa52e3c: EnterFrame
    //     0xa52e3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa52e40: mov             fp, SP
    // 0xa52e44: AllocStack(0x8)
    //     0xa52e44: sub             SP, SP, #8
    // 0xa52e48: CheckStackOverflow
    //     0xa52e48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52e4c: cmp             SP, x16
    //     0xa52e50: b.ls            #0xa52ef0
    // 0xa52e54: ldr             x16, [fp, #0x10]
    // 0xa52e58: SaveReg r16
    //     0xa52e58: str             x16, [SP, #-8]!
    // 0xa52e5c: r0 = _controllerIsValid()
    //     0xa52e5c: bl              #0x7be2c8  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_controllerIsValid
    // 0xa52e60: add             SP, SP, #8
    // 0xa52e64: tbnz            w0, #4, #0xa52ed8
    // 0xa52e68: ldr             x0, [fp, #0x10]
    // 0xa52e6c: LoadField: r1 = r0->field_13
    //     0xa52e6c: ldur            w1, [x0, #0x13]
    // 0xa52e70: DecompressPointer r1
    //     0xa52e70: add             x1, x1, HEAP, lsl #32
    // 0xa52e74: cmp             w1, NULL
    // 0xa52e78: b.eq            #0xa52ef8
    // 0xa52e7c: LoadField: r2 = r1->field_23
    //     0xa52e7c: ldur            w2, [x1, #0x23]
    // 0xa52e80: DecompressPointer r2
    //     0xa52e80: add             x2, x2, HEAP, lsl #32
    // 0xa52e84: cmp             w2, NULL
    // 0xa52e88: b.ne            #0xa52e94
    // 0xa52e8c: r1 = Null
    //     0xa52e8c: mov             x1, NULL
    // 0xa52e90: b               #0xa52e98
    // 0xa52e94: mov             x1, x2
    // 0xa52e98: stur            x1, [fp, #-8]
    // 0xa52e9c: cmp             w1, NULL
    // 0xa52ea0: b.eq            #0xa52efc
    // 0xa52ea4: r1 = 1
    //     0xa52ea4: mov             x1, #1
    // 0xa52ea8: r0 = AllocateContext()
    //     0xa52ea8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52eac: mov             x1, x0
    // 0xa52eb0: ldr             x0, [fp, #0x10]
    // 0xa52eb4: StoreField: r1->field_f = r0
    //     0xa52eb4: stur            w0, [x1, #0xf]
    // 0xa52eb8: mov             x2, x1
    // 0xa52ebc: r1 = Function '_handleTabControllerAnimationTick@472014024':.
    //     0xa52ebc: add             x1, PP, #0x38, lsl #12  ; [pp+0x38050] AnonymousClosure: (0x7be30c), in [package:flutter/src/material/tabs.dart] _TabBarViewState::_handleTabControllerAnimationTick (0x7be354)
    //     0xa52ec0: ldr             x1, [x1, #0x50]
    // 0xa52ec4: r0 = AllocateClosure()
    //     0xa52ec4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52ec8: ldur            x16, [fp, #-8]
    // 0xa52ecc: stp             x0, x16, [SP, #-0x10]!
    // 0xa52ed0: r0 = removeListener()
    //     0xa52ed0: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa52ed4: add             SP, SP, #0x10
    // 0xa52ed8: ldr             x1, [fp, #0x10]
    // 0xa52edc: StoreField: r1->field_13 = rNULL
    //     0xa52edc: stur            NULL, [x1, #0x13]
    // 0xa52ee0: r0 = Null
    //     0xa52ee0: mov             x0, NULL
    // 0xa52ee4: LeaveFrame
    //     0xa52ee4: mov             SP, fp
    //     0xa52ee8: ldp             fp, lr, [SP], #0x10
    // 0xa52eec: ret
    //     0xa52eec: ret             
    // 0xa52ef0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52ef0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52ef4: b               #0xa52e54
    // 0xa52ef8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52ef8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa52efc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52efc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa61de8, size: 0x100
    // 0xa61de8: EnterFrame
    //     0xa61de8: stp             fp, lr, [SP, #-0x10]!
    //     0xa61dec: mov             fp, SP
    // 0xa61df0: AllocStack(0x10)
    //     0xa61df0: sub             SP, SP, #0x10
    // 0xa61df4: CheckStackOverflow
    //     0xa61df4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61df8: cmp             SP, x16
    //     0xa61dfc: b.ls            #0xa61ed8
    // 0xa61e00: ldr             x16, [fp, #0x10]
    // 0xa61e04: SaveReg r16
    //     0xa61e04: str             x16, [SP, #-8]!
    // 0xa61e08: r0 = _updateTabController()
    //     0xa61e08: bl              #0x7be10c  ; [package:flutter/src/material/tabs.dart] _TabBarViewState::_updateTabController
    // 0xa61e0c: add             SP, SP, #8
    // 0xa61e10: ldr             x2, [fp, #0x10]
    // 0xa61e14: LoadField: r0 = r2->field_13
    //     0xa61e14: ldur            w0, [x2, #0x13]
    // 0xa61e18: DecompressPointer r0
    //     0xa61e18: add             x0, x0, HEAP, lsl #32
    // 0xa61e1c: cmp             w0, NULL
    // 0xa61e20: b.eq            #0xa61ee0
    // 0xa61e24: LoadField: r3 = r0->field_33
    //     0xa61e24: ldur            x3, [x0, #0x33]
    // 0xa61e28: stur            x3, [fp, #-8]
    // 0xa61e2c: r0 = BoxInt64Instr(r3)
    //     0xa61e2c: sbfiz           x0, x3, #1, #0x1f
    //     0xa61e30: cmp             x3, x0, asr #1
    //     0xa61e34: b.eq            #0xa61e40
    //     0xa61e38: bl              #0xd69bb8
    //     0xa61e3c: stur            x3, [x0, #7]
    // 0xa61e40: StoreField: r2->field_23 = r0
    //     0xa61e40: stur            w0, [x2, #0x23]
    //     0xa61e44: tbz             w0, #0, #0xa61e60
    //     0xa61e48: ldurb           w16, [x2, #-1]
    //     0xa61e4c: ldurb           w17, [x0, #-1]
    //     0xa61e50: and             x16, x17, x16, lsr #2
    //     0xa61e54: tst             x16, HEAP, lsr #32
    //     0xa61e58: b.eq            #0xa61e60
    //     0xa61e5c: bl              #0xd6828c
    // 0xa61e60: LoadField: r0 = r2->field_b
    //     0xa61e60: ldur            w0, [x2, #0xb]
    // 0xa61e64: DecompressPointer r0
    //     0xa61e64: add             x0, x0, HEAP, lsl #32
    // 0xa61e68: cmp             w0, NULL
    // 0xa61e6c: b.eq            #0xa61ee4
    // 0xa61e70: r0 = PageController()
    //     0xa61e70: bl              #0x8243ac  ; AllocatePageControllerStub -> PageController (size=0x4c)
    // 0xa61e74: mov             x1, x0
    // 0xa61e78: ldur            x0, [fp, #-8]
    // 0xa61e7c: stur            x1, [fp, #-0x10]
    // 0xa61e80: StoreField: r1->field_37 = r0
    //     0xa61e80: stur            x0, [x1, #0x37]
    // 0xa61e84: r0 = true
    //     0xa61e84: add             x0, NULL, #0x20  ; true
    // 0xa61e88: StoreField: r1->field_3f = r0
    //     0xa61e88: stur            w0, [x1, #0x3f]
    // 0xa61e8c: d0 = 1.000000
    //     0xa61e8c: fmov            d0, #1.00000000
    // 0xa61e90: StoreField: r1->field_43 = d0
    //     0xa61e90: stur            d0, [x1, #0x43]
    // 0xa61e94: SaveReg r1
    //     0xa61e94: str             x1, [SP, #-8]!
    // 0xa61e98: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa61e98: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa61e9c: r0 = ScrollController()
    //     0xa61e9c: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0xa61ea0: add             SP, SP, #8
    // 0xa61ea4: ldur            x0, [fp, #-0x10]
    // 0xa61ea8: ldr             x1, [fp, #0x10]
    // 0xa61eac: StoreField: r1->field_17 = r0
    //     0xa61eac: stur            w0, [x1, #0x17]
    //     0xa61eb0: ldurb           w16, [x1, #-1]
    //     0xa61eb4: ldurb           w17, [x0, #-1]
    //     0xa61eb8: and             x16, x17, x16, lsr #2
    //     0xa61ebc: tst             x16, HEAP, lsr #32
    //     0xa61ec0: b.eq            #0xa61ec8
    //     0xa61ec4: bl              #0xd6826c
    // 0xa61ec8: r0 = Null
    //     0xa61ec8: mov             x0, NULL
    // 0xa61ecc: LeaveFrame
    //     0xa61ecc: mov             SP, fp
    //     0xa61ed0: ldp             fp, lr, [SP], #0x10
    // 0xa61ed4: ret
    //     0xa61ed4: ret             
    // 0xa61ed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61ed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61edc: b               #0xa61e00
    // 0xa61ee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61ee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa61ee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa61ee4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3272, size: 0x2c, field offset: 0x14
class _TabBarState extends State<TabBar> {

  late List<GlobalKey<State<StatefulWidget>>> _tabKeys; // offset: 0x28
  late double _tabStripWidth; // offset: 0x24

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bc0b8, size: 0x57c
    // 0x7bc0b8: EnterFrame
    //     0x7bc0b8: stp             fp, lr, [SP, #-0x10]!
    //     0x7bc0bc: mov             fp, SP
    // 0x7bc0c0: AllocStack(0x30)
    //     0x7bc0c0: sub             SP, SP, #0x30
    // 0x7bc0c4: CheckStackOverflow
    //     0x7bc0c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bc0c8: cmp             SP, x16
    //     0x7bc0cc: b.ls            #0x7bc5fc
    // 0x7bc0d0: ldr             x0, [fp, #0x10]
    // 0x7bc0d4: r2 = Null
    //     0x7bc0d4: mov             x2, NULL
    // 0x7bc0d8: r1 = Null
    //     0x7bc0d8: mov             x1, NULL
    // 0x7bc0dc: r4 = 59
    //     0x7bc0dc: mov             x4, #0x3b
    // 0x7bc0e0: branchIfSmi(r0, 0x7bc0ec)
    //     0x7bc0e0: tbz             w0, #0, #0x7bc0ec
    // 0x7bc0e4: r4 = LoadClassIdInstr(r0)
    //     0x7bc0e4: ldur            x4, [x0, #-1]
    //     0x7bc0e8: ubfx            x4, x4, #0xc, #0x14
    // 0x7bc0ec: r17 = 4117
    //     0x7bc0ec: mov             x17, #0x1015
    // 0x7bc0f0: cmp             x4, x17
    // 0x7bc0f4: b.eq            #0x7bc10c
    // 0x7bc0f8: r8 = TabBar
    //     0x7bc0f8: add             x8, PP, #0x37, lsl #12  ; [pp+0x37f88] Type: TabBar
    //     0x7bc0fc: ldr             x8, [x8, #0xf88]
    // 0x7bc100: r3 = Null
    //     0x7bc100: add             x3, PP, #0x37, lsl #12  ; [pp+0x37f90] Null
    //     0x7bc104: ldr             x3, [x3, #0xf90]
    // 0x7bc108: r0 = TabBar()
    //     0x7bc108: bl              #0x7bde68  ; IsType_TabBar_Stub
    // 0x7bc10c: ldr             x3, [fp, #0x18]
    // 0x7bc110: LoadField: r2 = r3->field_7
    //     0x7bc110: ldur            w2, [x3, #7]
    // 0x7bc114: DecompressPointer r2
    //     0x7bc114: add             x2, x2, HEAP, lsl #32
    // 0x7bc118: ldr             x0, [fp, #0x10]
    // 0x7bc11c: r1 = Null
    //     0x7bc11c: mov             x1, NULL
    // 0x7bc120: cmp             w2, NULL
    // 0x7bc124: b.eq            #0x7bc148
    // 0x7bc128: LoadField: r4 = r2->field_17
    //     0x7bc128: ldur            w4, [x2, #0x17]
    // 0x7bc12c: DecompressPointer r4
    //     0x7bc12c: add             x4, x4, HEAP, lsl #32
    // 0x7bc130: r8 = X0 bound StatefulWidget
    //     0x7bc130: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bc134: ldr             x8, [x8, #0x858]
    // 0x7bc138: LoadField: r9 = r4->field_7
    //     0x7bc138: ldur            x9, [x4, #7]
    // 0x7bc13c: r3 = Null
    //     0x7bc13c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37fa0] Null
    //     0x7bc140: ldr             x3, [x3, #0xfa0]
    // 0x7bc144: blr             x9
    // 0x7bc148: ldr             x0, [fp, #0x18]
    // 0x7bc14c: LoadField: r1 = r0->field_b
    //     0x7bc14c: ldur            w1, [x0, #0xb]
    // 0x7bc150: DecompressPointer r1
    //     0x7bc150: add             x1, x1, HEAP, lsl #32
    // 0x7bc154: cmp             w1, NULL
    // 0x7bc158: b.eq            #0x7bc604
    // 0x7bc15c: LoadField: r2 = r1->field_f
    //     0x7bc15c: ldur            w2, [x1, #0xf]
    // 0x7bc160: DecompressPointer r2
    //     0x7bc160: add             x2, x2, HEAP, lsl #32
    // 0x7bc164: ldr             x3, [fp, #0x10]
    // 0x7bc168: LoadField: r4 = r3->field_f
    //     0x7bc168: ldur            w4, [x3, #0xf]
    // 0x7bc16c: DecompressPointer r4
    //     0x7bc16c: add             x4, x4, HEAP, lsl #32
    // 0x7bc170: cmp             w2, w4
    // 0x7bc174: b.eq            #0x7bc1e8
    // 0x7bc178: SaveReg r0
    //     0x7bc178: str             x0, [SP, #-8]!
    // 0x7bc17c: r0 = _updateTabController()
    //     0x7bc17c: bl              #0x7bcf90  ; [package:flutter/src/material/tabs.dart] _TabBarState::_updateTabController
    // 0x7bc180: add             SP, SP, #8
    // 0x7bc184: ldr             x16, [fp, #0x18]
    // 0x7bc188: SaveReg r16
    //     0x7bc188: str             x16, [SP, #-8]!
    // 0x7bc18c: r0 = _initIndicatorPainter()
    //     0x7bc18c: bl              #0x7bc648  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initIndicatorPainter
    // 0x7bc190: add             SP, SP, #8
    // 0x7bc194: ldr             x0, [fp, #0x18]
    // 0x7bc198: LoadField: r1 = r0->field_13
    //     0x7bc198: ldur            w1, [x0, #0x13]
    // 0x7bc19c: DecompressPointer r1
    //     0x7bc19c: add             x1, x1, HEAP, lsl #32
    // 0x7bc1a0: cmp             w1, NULL
    // 0x7bc1a4: b.eq            #0x7bc1e0
    // 0x7bc1a8: LoadField: r2 = r1->field_33
    //     0x7bc1a8: ldur            w2, [x1, #0x33]
    // 0x7bc1ac: DecompressPointer r2
    //     0x7bc1ac: add             x2, x2, HEAP, lsl #32
    // 0x7bc1b0: SaveReg r2
    //     0x7bc1b0: str             x2, [SP, #-8]!
    // 0x7bc1b4: r0 = single()
    //     0x7bc1b4: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x7bc1b8: add             SP, SP, #8
    // 0x7bc1bc: r1 = LoadClassIdInstr(r0)
    //     0x7bc1bc: ldur            x1, [x0, #-1]
    //     0x7bc1c0: ubfx            x1, x1, #0xc, #0x14
    // 0x7bc1c4: lsl             x1, x1, #1
    // 0x7bc1c8: r17 = 9696
    //     0x7bc1c8: mov             x17, #0x25e0
    // 0x7bc1cc: cmp             w1, w17
    // 0x7bc1d0: b.ne            #0x7bc1e0
    // 0x7bc1d4: SaveReg r0
    //     0x7bc1d4: str             x0, [SP, #-8]!
    // 0x7bc1d8: r0 = markNeedsPixelsCorrection()
    //     0x7bc1d8: bl              #0x7bc634  ; [package:flutter/src/material/tabs.dart] _TabBarScrollPosition::markNeedsPixelsCorrection
    // 0x7bc1dc: add             SP, SP, #8
    // 0x7bc1e0: ldr             x1, [fp, #0x18]
    // 0x7bc1e4: b               #0x7bc28c
    // 0x7bc1e8: LoadField: r0 = r1->field_1b
    //     0x7bc1e8: ldur            w0, [x1, #0x1b]
    // 0x7bc1ec: DecompressPointer r0
    //     0x7bc1ec: add             x0, x0, HEAP, lsl #32
    // 0x7bc1f0: LoadField: r1 = r3->field_1b
    //     0x7bc1f0: ldur            w1, [x3, #0x1b]
    // 0x7bc1f4: DecompressPointer r1
    //     0x7bc1f4: add             x1, x1, HEAP, lsl #32
    // 0x7bc1f8: r2 = LoadClassIdInstr(r0)
    //     0x7bc1f8: ldur            x2, [x0, #-1]
    //     0x7bc1fc: ubfx            x2, x2, #0xc, #0x14
    // 0x7bc200: stp             x1, x0, [SP, #-0x10]!
    // 0x7bc204: mov             x0, x2
    // 0x7bc208: mov             lr, x0
    // 0x7bc20c: ldr             lr, [x21, lr, lsl #3]
    // 0x7bc210: blr             lr
    // 0x7bc214: add             SP, SP, #0x10
    // 0x7bc218: tbnz            w0, #4, #0x7bc260
    // 0x7bc21c: ldr             x0, [fp, #0x18]
    // 0x7bc220: d0 = 2.000000
    //     0x7bc220: fmov            d0, #2.00000000
    // 0x7bc224: LoadField: r1 = r0->field_b
    //     0x7bc224: ldur            w1, [x0, #0xb]
    // 0x7bc228: DecompressPointer r1
    //     0x7bc228: add             x1, x1, HEAP, lsl #32
    // 0x7bc22c: cmp             w1, NULL
    // 0x7bc230: b.eq            #0x7bc608
    // 0x7bc234: fcmp            d0, d0
    // 0x7bc238: b.ne            #0x7bc260
    // 0x7bc23c: ldr             x2, [fp, #0x10]
    // 0x7bc240: LoadField: r3 = r1->field_27
    //     0x7bc240: ldur            w3, [x1, #0x27]
    // 0x7bc244: DecompressPointer r3
    //     0x7bc244: add             x3, x3, HEAP, lsl #32
    // 0x7bc248: LoadField: r1 = r2->field_27
    //     0x7bc248: ldur            w1, [x2, #0x27]
    // 0x7bc24c: DecompressPointer r1
    //     0x7bc24c: add             x1, x1, HEAP, lsl #32
    // 0x7bc250: stp             x1, x3, [SP, #-0x10]!
    // 0x7bc254: r0 = ==()
    //     0x7bc254: bl              #0xc9d2f4  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::==
    // 0x7bc258: add             SP, SP, #0x10
    // 0x7bc25c: tbz             w0, #4, #0x7bc278
    // 0x7bc260: ldr             x16, [fp, #0x18]
    // 0x7bc264: SaveReg r16
    //     0x7bc264: str             x16, [SP, #-8]!
    // 0x7bc268: r0 = _initIndicatorPainter()
    //     0x7bc268: bl              #0x7bc648  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initIndicatorPainter
    // 0x7bc26c: add             SP, SP, #8
    // 0x7bc270: ldr             x1, [fp, #0x18]
    // 0x7bc274: b               #0x7bc28c
    // 0x7bc278: ldr             x1, [fp, #0x18]
    // 0x7bc27c: LoadField: r0 = r1->field_b
    //     0x7bc27c: ldur            w0, [x1, #0xb]
    // 0x7bc280: DecompressPointer r0
    //     0x7bc280: add             x0, x0, HEAP, lsl #32
    // 0x7bc284: cmp             w0, NULL
    // 0x7bc288: b.eq            #0x7bc60c
    // 0x7bc28c: LoadField: r0 = r1->field_b
    //     0x7bc28c: ldur            w0, [x1, #0xb]
    // 0x7bc290: DecompressPointer r0
    //     0x7bc290: add             x0, x0, HEAP, lsl #32
    // 0x7bc294: cmp             w0, NULL
    // 0x7bc298: b.eq            #0x7bc610
    // 0x7bc29c: LoadField: r2 = r0->field_b
    //     0x7bc29c: ldur            w2, [x0, #0xb]
    // 0x7bc2a0: DecompressPointer r2
    //     0x7bc2a0: add             x2, x2, HEAP, lsl #32
    // 0x7bc2a4: r0 = LoadClassIdInstr(r2)
    //     0x7bc2a4: ldur            x0, [x2, #-1]
    //     0x7bc2a8: ubfx            x0, x0, #0xc, #0x14
    // 0x7bc2ac: SaveReg r2
    //     0x7bc2ac: str             x2, [SP, #-8]!
    // 0x7bc2b0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc2b0: mov             x17, #0xb8ea
    //     0x7bc2b4: add             lr, x0, x17
    //     0x7bc2b8: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc2bc: blr             lr
    // 0x7bc2c0: add             SP, SP, #8
    // 0x7bc2c4: mov             x2, x0
    // 0x7bc2c8: ldr             x1, [fp, #0x18]
    // 0x7bc2cc: stur            x2, [fp, #-8]
    // 0x7bc2d0: LoadField: r0 = r1->field_27
    //     0x7bc2d0: ldur            w0, [x1, #0x27]
    // 0x7bc2d4: DecompressPointer r0
    //     0x7bc2d4: add             x0, x0, HEAP, lsl #32
    // 0x7bc2d8: r16 = Sentinel
    //     0x7bc2d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bc2dc: cmp             w0, w16
    // 0x7bc2e0: b.eq            #0x7bc614
    // 0x7bc2e4: r3 = LoadClassIdInstr(r0)
    //     0x7bc2e4: ldur            x3, [x0, #-1]
    //     0x7bc2e8: ubfx            x3, x3, #0xc, #0x14
    // 0x7bc2ec: SaveReg r0
    //     0x7bc2ec: str             x0, [SP, #-8]!
    // 0x7bc2f0: mov             x0, x3
    // 0x7bc2f4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc2f4: mov             x17, #0xb8ea
    //     0x7bc2f8: add             lr, x0, x17
    //     0x7bc2fc: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc300: blr             lr
    // 0x7bc304: add             SP, SP, #8
    // 0x7bc308: mov             x1, x0
    // 0x7bc30c: ldur            x0, [fp, #-8]
    // 0x7bc310: r2 = LoadInt32Instr(r0)
    //     0x7bc310: sbfx            x2, x0, #1, #0x1f
    // 0x7bc314: r0 = LoadInt32Instr(r1)
    //     0x7bc314: sbfx            x0, x1, #1, #0x1f
    // 0x7bc318: cmp             x2, x0
    // 0x7bc31c: b.le            #0x7bc4b0
    // 0x7bc320: ldr             x1, [fp, #0x18]
    // 0x7bc324: LoadField: r0 = r1->field_b
    //     0x7bc324: ldur            w0, [x1, #0xb]
    // 0x7bc328: DecompressPointer r0
    //     0x7bc328: add             x0, x0, HEAP, lsl #32
    // 0x7bc32c: cmp             w0, NULL
    // 0x7bc330: b.eq            #0x7bc620
    // 0x7bc334: LoadField: r2 = r0->field_b
    //     0x7bc334: ldur            w2, [x0, #0xb]
    // 0x7bc338: DecompressPointer r2
    //     0x7bc338: add             x2, x2, HEAP, lsl #32
    // 0x7bc33c: r0 = LoadClassIdInstr(r2)
    //     0x7bc33c: ldur            x0, [x2, #-1]
    //     0x7bc340: ubfx            x0, x0, #0xc, #0x14
    // 0x7bc344: SaveReg r2
    //     0x7bc344: str             x2, [SP, #-8]!
    // 0x7bc348: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc348: mov             x17, #0xb8ea
    //     0x7bc34c: add             lr, x0, x17
    //     0x7bc350: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc354: blr             lr
    // 0x7bc358: add             SP, SP, #8
    // 0x7bc35c: mov             x2, x0
    // 0x7bc360: ldr             x1, [fp, #0x18]
    // 0x7bc364: stur            x2, [fp, #-8]
    // 0x7bc368: LoadField: r0 = r1->field_27
    //     0x7bc368: ldur            w0, [x1, #0x27]
    // 0x7bc36c: DecompressPointer r0
    //     0x7bc36c: add             x0, x0, HEAP, lsl #32
    // 0x7bc370: r3 = LoadClassIdInstr(r0)
    //     0x7bc370: ldur            x3, [x0, #-1]
    //     0x7bc374: ubfx            x3, x3, #0xc, #0x14
    // 0x7bc378: SaveReg r0
    //     0x7bc378: str             x0, [SP, #-8]!
    // 0x7bc37c: mov             x0, x3
    // 0x7bc380: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc380: mov             x17, #0xb8ea
    //     0x7bc384: add             lr, x0, x17
    //     0x7bc388: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc38c: blr             lr
    // 0x7bc390: add             SP, SP, #8
    // 0x7bc394: mov             x1, x0
    // 0x7bc398: ldur            x0, [fp, #-8]
    // 0x7bc39c: r2 = LoadInt32Instr(r0)
    //     0x7bc39c: sbfx            x2, x0, #1, #0x1f
    // 0x7bc3a0: r0 = LoadInt32Instr(r1)
    //     0x7bc3a0: sbfx            x0, x1, #1, #0x1f
    // 0x7bc3a4: sub             x1, x2, x0
    // 0x7bc3a8: ldr             x2, [fp, #0x18]
    // 0x7bc3ac: LoadField: r0 = r2->field_27
    //     0x7bc3ac: ldur            w0, [x2, #0x27]
    // 0x7bc3b0: DecompressPointer r0
    //     0x7bc3b0: add             x0, x0, HEAP, lsl #32
    // 0x7bc3b4: stur            x0, [fp, #-8]
    // 0x7bc3b8: r16 = <GlobalKey<State<StatefulWidget>>>
    //     0x7bc3b8: add             x16, PP, #0x37, lsl #12  ; [pp+0x37fb0] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0x7bc3bc: ldr             x16, [x16, #0xfb0]
    // 0x7bc3c0: stp             x1, x16, [SP, #-0x10]!
    // 0x7bc3c4: r0 = _GrowableList()
    //     0x7bc3c4: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7bc3c8: add             SP, SP, #0x10
    // 0x7bc3cc: stur            x0, [fp, #-0x28]
    // 0x7bc3d0: LoadField: r1 = r0->field_b
    //     0x7bc3d0: ldur            w1, [x0, #0xb]
    // 0x7bc3d4: DecompressPointer r1
    //     0x7bc3d4: add             x1, x1, HEAP, lsl #32
    // 0x7bc3d8: r2 = LoadInt32Instr(r1)
    //     0x7bc3d8: sbfx            x2, x1, #1, #0x1f
    // 0x7bc3dc: stur            x2, [fp, #-0x20]
    // 0x7bc3e0: LoadField: r3 = r0->field_f
    //     0x7bc3e0: ldur            w3, [x0, #0xf]
    // 0x7bc3e4: DecompressPointer r3
    //     0x7bc3e4: add             x3, x3, HEAP, lsl #32
    // 0x7bc3e8: stur            x3, [fp, #-0x18]
    // 0x7bc3ec: r4 = 0
    //     0x7bc3ec: mov             x4, #0
    // 0x7bc3f0: stur            x4, [fp, #-0x10]
    // 0x7bc3f4: CheckStackOverflow
    //     0x7bc3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bc3f8: cmp             SP, x16
    //     0x7bc3fc: b.ls            #0x7bc624
    // 0x7bc400: cmp             x4, x2
    // 0x7bc404: b.ge            #0x7bc47c
    // 0x7bc408: r1 = <State<StatefulWidget>>
    //     0x7bc408: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0x7bc40c: r0 = LabeledGlobalKey()
    //     0x7bc40c: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x7bc410: mov             x3, x0
    // 0x7bc414: r2 = Null
    //     0x7bc414: mov             x2, NULL
    // 0x7bc418: r1 = Null
    //     0x7bc418: mov             x1, NULL
    // 0x7bc41c: stur            x3, [fp, #-0x30]
    // 0x7bc420: r8 = GlobalKey<State<StatefulWidget>>
    //     0x7bc420: add             x8, PP, #0x37, lsl #12  ; [pp+0x37fb8] Type: GlobalKey<State<StatefulWidget>>
    //     0x7bc424: ldr             x8, [x8, #0xfb8]
    // 0x7bc428: r3 = Null
    //     0x7bc428: add             x3, PP, #0x37, lsl #12  ; [pp+0x37fc0] Null
    //     0x7bc42c: ldr             x3, [x3, #0xfc0]
    // 0x7bc430: r0 = DefaultTypeTest()
    //     0x7bc430: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x7bc434: ldur            x1, [fp, #-0x18]
    // 0x7bc438: ldur            x0, [fp, #-0x30]
    // 0x7bc43c: ldur            x2, [fp, #-0x10]
    // 0x7bc440: ArrayStore: r1[r2] = r0  ; List_4
    //     0x7bc440: add             x25, x1, x2, lsl #2
    //     0x7bc444: add             x25, x25, #0xf
    //     0x7bc448: str             w0, [x25]
    //     0x7bc44c: tbz             w0, #0, #0x7bc468
    //     0x7bc450: ldurb           w16, [x1, #-1]
    //     0x7bc454: ldurb           w17, [x0, #-1]
    //     0x7bc458: and             x16, x17, x16, lsr #2
    //     0x7bc45c: tst             x16, HEAP, lsr #32
    //     0x7bc460: b.eq            #0x7bc468
    //     0x7bc464: bl              #0xd67e5c
    // 0x7bc468: add             x4, x2, #1
    // 0x7bc46c: ldur            x0, [fp, #-0x28]
    // 0x7bc470: ldur            x3, [fp, #-0x18]
    // 0x7bc474: ldur            x2, [fp, #-0x20]
    // 0x7bc478: b               #0x7bc3f0
    // 0x7bc47c: ldur            x0, [fp, #-8]
    // 0x7bc480: r1 = LoadClassIdInstr(r0)
    //     0x7bc480: ldur            x1, [x0, #-1]
    //     0x7bc484: ubfx            x1, x1, #0xc, #0x14
    // 0x7bc488: ldur            x16, [fp, #-0x28]
    // 0x7bc48c: stp             x16, x0, [SP, #-0x10]!
    // 0x7bc490: mov             x0, x1
    // 0x7bc494: r0 = GDT[cid_x0 + 0x10267]()
    //     0x7bc494: mov             x17, #0x267
    //     0x7bc498: movk            x17, #1, lsl #16
    //     0x7bc49c: add             lr, x0, x17
    //     0x7bc4a0: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc4a4: blr             lr
    // 0x7bc4a8: add             SP, SP, #0x10
    // 0x7bc4ac: b               #0x7bc5ec
    // 0x7bc4b0: ldr             x2, [fp, #0x18]
    // 0x7bc4b4: LoadField: r0 = r2->field_b
    //     0x7bc4b4: ldur            w0, [x2, #0xb]
    // 0x7bc4b8: DecompressPointer r0
    //     0x7bc4b8: add             x0, x0, HEAP, lsl #32
    // 0x7bc4bc: cmp             w0, NULL
    // 0x7bc4c0: b.eq            #0x7bc62c
    // 0x7bc4c4: LoadField: r1 = r0->field_b
    //     0x7bc4c4: ldur            w1, [x0, #0xb]
    // 0x7bc4c8: DecompressPointer r1
    //     0x7bc4c8: add             x1, x1, HEAP, lsl #32
    // 0x7bc4cc: r0 = LoadClassIdInstr(r1)
    //     0x7bc4cc: ldur            x0, [x1, #-1]
    //     0x7bc4d0: ubfx            x0, x0, #0xc, #0x14
    // 0x7bc4d4: SaveReg r1
    //     0x7bc4d4: str             x1, [SP, #-8]!
    // 0x7bc4d8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc4d8: mov             x17, #0xb8ea
    //     0x7bc4dc: add             lr, x0, x17
    //     0x7bc4e0: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc4e4: blr             lr
    // 0x7bc4e8: add             SP, SP, #8
    // 0x7bc4ec: mov             x2, x0
    // 0x7bc4f0: ldr             x1, [fp, #0x18]
    // 0x7bc4f4: stur            x2, [fp, #-8]
    // 0x7bc4f8: LoadField: r0 = r1->field_27
    //     0x7bc4f8: ldur            w0, [x1, #0x27]
    // 0x7bc4fc: DecompressPointer r0
    //     0x7bc4fc: add             x0, x0, HEAP, lsl #32
    // 0x7bc500: r3 = LoadClassIdInstr(r0)
    //     0x7bc500: ldur            x3, [x0, #-1]
    //     0x7bc504: ubfx            x3, x3, #0xc, #0x14
    // 0x7bc508: SaveReg r0
    //     0x7bc508: str             x0, [SP, #-8]!
    // 0x7bc50c: mov             x0, x3
    // 0x7bc510: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc510: mov             x17, #0xb8ea
    //     0x7bc514: add             lr, x0, x17
    //     0x7bc518: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc51c: blr             lr
    // 0x7bc520: add             SP, SP, #8
    // 0x7bc524: mov             x1, x0
    // 0x7bc528: ldur            x0, [fp, #-8]
    // 0x7bc52c: r2 = LoadInt32Instr(r0)
    //     0x7bc52c: sbfx            x2, x0, #1, #0x1f
    // 0x7bc530: r0 = LoadInt32Instr(r1)
    //     0x7bc530: sbfx            x0, x1, #1, #0x1f
    // 0x7bc534: cmp             x2, x0
    // 0x7bc538: b.ge            #0x7bc5ec
    // 0x7bc53c: ldr             x1, [fp, #0x18]
    // 0x7bc540: LoadField: r2 = r1->field_27
    //     0x7bc540: ldur            w2, [x1, #0x27]
    // 0x7bc544: DecompressPointer r2
    //     0x7bc544: add             x2, x2, HEAP, lsl #32
    // 0x7bc548: stur            x2, [fp, #-8]
    // 0x7bc54c: LoadField: r0 = r1->field_b
    //     0x7bc54c: ldur            w0, [x1, #0xb]
    // 0x7bc550: DecompressPointer r0
    //     0x7bc550: add             x0, x0, HEAP, lsl #32
    // 0x7bc554: cmp             w0, NULL
    // 0x7bc558: b.eq            #0x7bc630
    // 0x7bc55c: LoadField: r3 = r0->field_b
    //     0x7bc55c: ldur            w3, [x0, #0xb]
    // 0x7bc560: DecompressPointer r3
    //     0x7bc560: add             x3, x3, HEAP, lsl #32
    // 0x7bc564: r0 = LoadClassIdInstr(r3)
    //     0x7bc564: ldur            x0, [x3, #-1]
    //     0x7bc568: ubfx            x0, x0, #0xc, #0x14
    // 0x7bc56c: SaveReg r3
    //     0x7bc56c: str             x3, [SP, #-8]!
    // 0x7bc570: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc570: mov             x17, #0xb8ea
    //     0x7bc574: add             lr, x0, x17
    //     0x7bc578: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc57c: blr             lr
    // 0x7bc580: add             SP, SP, #8
    // 0x7bc584: mov             x1, x0
    // 0x7bc588: ldr             x0, [fp, #0x18]
    // 0x7bc58c: stur            x1, [fp, #-0x18]
    // 0x7bc590: LoadField: r2 = r0->field_27
    //     0x7bc590: ldur            w2, [x0, #0x27]
    // 0x7bc594: DecompressPointer r2
    //     0x7bc594: add             x2, x2, HEAP, lsl #32
    // 0x7bc598: r0 = LoadClassIdInstr(r2)
    //     0x7bc598: ldur            x0, [x2, #-1]
    //     0x7bc59c: ubfx            x0, x0, #0xc, #0x14
    // 0x7bc5a0: SaveReg r2
    //     0x7bc5a0: str             x2, [SP, #-8]!
    // 0x7bc5a4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bc5a4: mov             x17, #0xb8ea
    //     0x7bc5a8: add             lr, x0, x17
    //     0x7bc5ac: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc5b0: blr             lr
    // 0x7bc5b4: add             SP, SP, #8
    // 0x7bc5b8: r1 = LoadInt32Instr(r0)
    //     0x7bc5b8: sbfx            x1, x0, #1, #0x1f
    // 0x7bc5bc: ldur            x0, [fp, #-8]
    // 0x7bc5c0: r2 = LoadClassIdInstr(r0)
    //     0x7bc5c0: ldur            x2, [x0, #-1]
    //     0x7bc5c4: ubfx            x2, x2, #0xc, #0x14
    // 0x7bc5c8: ldur            x16, [fp, #-0x18]
    // 0x7bc5cc: stp             x16, x0, [SP, #-0x10]!
    // 0x7bc5d0: SaveReg r1
    //     0x7bc5d0: str             x1, [SP, #-8]!
    // 0x7bc5d4: mov             x0, x2
    // 0x7bc5d8: r0 = GDT[cid_x0 + 0x37f1]()
    //     0x7bc5d8: mov             x17, #0x37f1
    //     0x7bc5dc: add             lr, x0, x17
    //     0x7bc5e0: ldr             lr, [x21, lr, lsl #3]
    //     0x7bc5e4: blr             lr
    // 0x7bc5e8: add             SP, SP, #0x18
    // 0x7bc5ec: r0 = Null
    //     0x7bc5ec: mov             x0, NULL
    // 0x7bc5f0: LeaveFrame
    //     0x7bc5f0: mov             SP, fp
    //     0x7bc5f4: ldp             fp, lr, [SP], #0x10
    // 0x7bc5f8: ret
    //     0x7bc5f8: ret             
    // 0x7bc5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bc5fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bc600: b               #0x7bc0d0
    // 0x7bc604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc608: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bc608: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bc60c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc60c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc610: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc610: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc614: r9 = _tabKeys
    //     0x7bc614: add             x9, PP, #0x37, lsl #12  ; [pp+0x37f48] Field <_TabBarState@472014024._tabKeys@472014024>: late (offset: 0x28)
    //     0x7bc618: ldr             x9, [x9, #0xf48]
    // 0x7bc61c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bc61c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7bc620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc620: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bc624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bc628: b               #0x7bc400
    // 0x7bc62c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc62c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc630: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _initIndicatorPainter(/* No info */) {
    // ** addr: 0x7bc648, size: 0x2f8
    // 0x7bc648: EnterFrame
    //     0x7bc648: stp             fp, lr, [SP, #-0x10]!
    //     0x7bc64c: mov             fp, SP
    // 0x7bc650: AllocStack(0x40)
    //     0x7bc650: sub             SP, SP, #0x40
    // 0x7bc654: CheckStackOverflow
    //     0x7bc654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bc658: cmp             SP, x16
    //     0x7bc65c: b.ls            #0x7bc914
    // 0x7bc660: ldr             x0, [fp, #0x10]
    // 0x7bc664: LoadField: r1 = r0->field_f
    //     0x7bc664: ldur            w1, [x0, #0xf]
    // 0x7bc668: DecompressPointer r1
    //     0x7bc668: add             x1, x1, HEAP, lsl #32
    // 0x7bc66c: cmp             w1, NULL
    // 0x7bc670: b.eq            #0x7bc91c
    // 0x7bc674: SaveReg r1
    //     0x7bc674: str             x1, [SP, #-8]!
    // 0x7bc678: r0 = of()
    //     0x7bc678: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x7bc67c: add             SP, SP, #8
    // 0x7bc680: mov             x1, x0
    // 0x7bc684: ldr             x0, [fp, #0x10]
    // 0x7bc688: stur            x1, [fp, #-8]
    // 0x7bc68c: LoadField: r2 = r0->field_f
    //     0x7bc68c: ldur            w2, [x0, #0xf]
    // 0x7bc690: DecompressPointer r2
    //     0x7bc690: add             x2, x2, HEAP, lsl #32
    // 0x7bc694: cmp             w2, NULL
    // 0x7bc698: b.eq            #0x7bc920
    // 0x7bc69c: SaveReg r2
    //     0x7bc69c: str             x2, [SP, #-8]!
    // 0x7bc6a0: r0 = of()
    //     0x7bc6a0: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x7bc6a4: add             SP, SP, #8
    // 0x7bc6a8: mov             x1, x0
    // 0x7bc6ac: ldur            x0, [fp, #-8]
    // 0x7bc6b0: stur            x1, [fp, #-0x18]
    // 0x7bc6b4: LoadField: r2 = r0->field_2b
    //     0x7bc6b4: ldur            w2, [x0, #0x2b]
    // 0x7bc6b8: DecompressPointer r2
    //     0x7bc6b8: add             x2, x2, HEAP, lsl #32
    // 0x7bc6bc: stur            x2, [fp, #-0x10]
    // 0x7bc6c0: tbnz            w2, #4, #0x7bc710
    // 0x7bc6c4: ldr             x0, [fp, #0x10]
    // 0x7bc6c8: LoadField: r3 = r0->field_f
    //     0x7bc6c8: ldur            w3, [x0, #0xf]
    // 0x7bc6cc: DecompressPointer r3
    //     0x7bc6cc: add             x3, x3, HEAP, lsl #32
    // 0x7bc6d0: stur            x3, [fp, #-8]
    // 0x7bc6d4: cmp             w3, NULL
    // 0x7bc6d8: b.eq            #0x7bc924
    // 0x7bc6dc: r0 = _TabsDefaultsM3()
    //     0x7bc6dc: bl              #0x7bcf38  ; Allocate_TabsDefaultsM3Stub -> _TabsDefaultsM3 (size=0x44)
    // 0x7bc6e0: mov             x1, x0
    // 0x7bc6e4: r0 = Sentinel
    //     0x7bc6e4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bc6e8: StoreField: r1->field_3b = r0
    //     0x7bc6e8: stur            w0, [x1, #0x3b]
    // 0x7bc6ec: StoreField: r1->field_3f = r0
    //     0x7bc6ec: stur            w0, [x1, #0x3f]
    // 0x7bc6f0: ldur            x0, [fp, #-8]
    // 0x7bc6f4: StoreField: r1->field_37 = r0
    //     0x7bc6f4: stur            w0, [x1, #0x37]
    // 0x7bc6f8: r0 = Instance_TabBarIndicatorSize
    //     0x7bc6f8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0x7bc6fc: ldr             x0, [x0, #0xbe0]
    // 0x7bc700: StoreField: r1->field_f = r0
    //     0x7bc700: stur            w0, [x1, #0xf]
    // 0x7bc704: r0 = Instance_TabBarIndicatorSize
    //     0x7bc704: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0x7bc708: ldr             x0, [x0, #0xbe0]
    // 0x7bc70c: b               #0x7bc74c
    // 0x7bc710: ldr             x0, [fp, #0x10]
    // 0x7bc714: LoadField: r1 = r0->field_f
    //     0x7bc714: ldur            w1, [x0, #0xf]
    // 0x7bc718: DecompressPointer r1
    //     0x7bc718: add             x1, x1, HEAP, lsl #32
    // 0x7bc71c: stur            x1, [fp, #-8]
    // 0x7bc720: cmp             w1, NULL
    // 0x7bc724: b.eq            #0x7bc928
    // 0x7bc728: r0 = _TabsDefaultsM2()
    //     0x7bc728: bl              #0x7bcf2c  ; Allocate_TabsDefaultsM2Stub -> _TabsDefaultsM2 (size=0x3c)
    // 0x7bc72c: mov             x1, x0
    // 0x7bc730: ldur            x0, [fp, #-8]
    // 0x7bc734: StoreField: r1->field_37 = r0
    //     0x7bc734: stur            w0, [x1, #0x37]
    // 0x7bc738: r0 = Instance_TabBarIndicatorSize
    //     0x7bc738: add             x0, PP, #0x37, lsl #12  ; [pp+0x37ea0] Obj!TabBarIndicatorSize@b65171
    //     0x7bc73c: ldr             x0, [x0, #0xea0]
    // 0x7bc740: StoreField: r1->field_f = r0
    //     0x7bc740: stur            w0, [x1, #0xf]
    // 0x7bc744: r0 = Instance_TabBarIndicatorSize
    //     0x7bc744: add             x0, PP, #0x37, lsl #12  ; [pp+0x37ea0] Obj!TabBarIndicatorSize@b65171
    //     0x7bc748: ldr             x0, [x0, #0xea0]
    // 0x7bc74c: stur            x1, [fp, #-8]
    // 0x7bc750: stur            x0, [fp, #-0x20]
    // 0x7bc754: ldr             x16, [fp, #0x10]
    // 0x7bc758: SaveReg r16
    //     0x7bc758: str             x16, [SP, #-8]!
    // 0x7bc75c: r0 = _controllerIsValid()
    //     0x7bc75c: bl              #0x79f3ec  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_controllerIsValid
    // 0x7bc760: add             SP, SP, #8
    // 0x7bc764: tbz             w0, #4, #0x7bc770
    // 0x7bc768: r0 = Null
    //     0x7bc768: mov             x0, NULL
    // 0x7bc76c: b               #0x7bc8e4
    // 0x7bc770: ldr             x0, [fp, #0x10]
    // 0x7bc774: ldur            x1, [fp, #-0x18]
    // 0x7bc778: LoadField: r2 = r0->field_17
    //     0x7bc778: ldur            w2, [x0, #0x17]
    // 0x7bc77c: DecompressPointer r2
    //     0x7bc77c: add             x2, x2, HEAP, lsl #32
    // 0x7bc780: stur            x2, [fp, #-0x28]
    // 0x7bc784: cmp             w2, NULL
    // 0x7bc788: b.eq            #0x7bc92c
    // 0x7bc78c: SaveReg r0
    //     0x7bc78c: str             x0, [SP, #-8]!
    // 0x7bc790: r0 = _getIndicator()
    //     0x7bc790: bl              #0x7bcb08  ; [package:flutter/src/material/tabs.dart] _TabBarState::_getIndicator
    // 0x7bc794: add             SP, SP, #8
    // 0x7bc798: mov             x2, x0
    // 0x7bc79c: ldr             x0, [fp, #0x10]
    // 0x7bc7a0: stur            x2, [fp, #-0x40]
    // 0x7bc7a4: LoadField: r1 = r0->field_b
    //     0x7bc7a4: ldur            w1, [x0, #0xb]
    // 0x7bc7a8: DecompressPointer r1
    //     0x7bc7a8: add             x1, x1, HEAP, lsl #32
    // 0x7bc7ac: cmp             w1, NULL
    // 0x7bc7b0: b.eq            #0x7bc930
    // 0x7bc7b4: ldur            x3, [fp, #-0x18]
    // 0x7bc7b8: LoadField: r4 = r3->field_f
    //     0x7bc7b8: ldur            w4, [x3, #0xf]
    // 0x7bc7bc: DecompressPointer r4
    //     0x7bc7bc: add             x4, x4, HEAP, lsl #32
    // 0x7bc7c0: cmp             w4, NULL
    // 0x7bc7c4: b.ne            #0x7bc7cc
    // 0x7bc7c8: ldur            x4, [fp, #-0x20]
    // 0x7bc7cc: ldur            x3, [fp, #-0x10]
    // 0x7bc7d0: stur            x4, [fp, #-0x38]
    // 0x7bc7d4: LoadField: r5 = r1->field_27
    //     0x7bc7d4: ldur            w5, [x1, #0x27]
    // 0x7bc7d8: DecompressPointer r5
    //     0x7bc7d8: add             x5, x5, HEAP, lsl #32
    // 0x7bc7dc: stur            x5, [fp, #-0x30]
    // 0x7bc7e0: LoadField: r6 = r0->field_27
    //     0x7bc7e0: ldur            w6, [x0, #0x27]
    // 0x7bc7e4: DecompressPointer r6
    //     0x7bc7e4: add             x6, x6, HEAP, lsl #32
    // 0x7bc7e8: r16 = Sentinel
    //     0x7bc7e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bc7ec: cmp             w6, w16
    // 0x7bc7f0: b.eq            #0x7bc934
    // 0x7bc7f4: stur            x6, [fp, #-0x20]
    // 0x7bc7f8: LoadField: r7 = r0->field_1b
    //     0x7bc7f8: ldur            w7, [x0, #0x1b]
    // 0x7bc7fc: DecompressPointer r7
    //     0x7bc7fc: add             x7, x7, HEAP, lsl #32
    // 0x7bc800: stur            x7, [fp, #-0x18]
    // 0x7bc804: tbnz            w3, #4, #0x7bc89c
    // 0x7bc808: LoadField: r3 = r1->field_37
    //     0x7bc808: ldur            w3, [x1, #0x37]
    // 0x7bc80c: DecompressPointer r3
    //     0x7bc80c: add             x3, x3, HEAP, lsl #32
    // 0x7bc810: cmp             w3, NULL
    // 0x7bc814: b.ne            #0x7bc894
    // 0x7bc818: ldur            x1, [fp, #-8]
    // 0x7bc81c: r3 = LoadClassIdInstr(r1)
    //     0x7bc81c: ldur            x3, [x1, #-1]
    //     0x7bc820: ubfx            x3, x3, #0xc, #0x14
    // 0x7bc824: lsl             x3, x3, #1
    // 0x7bc828: r17 = 5444
    //     0x7bc828: mov             x17, #0x1544
    // 0x7bc82c: cmp             w3, w17
    // 0x7bc830: b.eq            #0x7bc888
    // 0x7bc834: r17 = 5446
    //     0x7bc834: mov             x17, #0x1546
    // 0x7bc838: cmp             w3, w17
    // 0x7bc83c: b.ne            #0x7bc888
    // 0x7bc840: LoadField: r0 = r1->field_3b
    //     0x7bc840: ldur            w0, [x1, #0x3b]
    // 0x7bc844: DecompressPointer r0
    //     0x7bc844: add             x0, x0, HEAP, lsl #32
    // 0x7bc848: r16 = Sentinel
    //     0x7bc848: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bc84c: cmp             w0, w16
    // 0x7bc850: b.ne            #0x7bc860
    // 0x7bc854: r2 = _colors
    //     0x7bc854: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0x7bc858: ldr             x2, [x2, #0xf50]
    // 0x7bc85c: r0 = InitLateFinalInstanceField()
    //     0x7bc85c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x7bc860: LoadField: r1 = r0->field_5b
    //     0x7bc860: ldur            w1, [x0, #0x5b]
    // 0x7bc864: DecompressPointer r1
    //     0x7bc864: add             x1, x1, HEAP, lsl #32
    // 0x7bc868: cmp             w1, NULL
    // 0x7bc86c: b.ne            #0x7bc880
    // 0x7bc870: LoadField: r1 = r0->field_53
    //     0x7bc870: ldur            w1, [x0, #0x53]
    // 0x7bc874: DecompressPointer r1
    //     0x7bc874: add             x1, x1, HEAP, lsl #32
    // 0x7bc878: mov             x0, x1
    // 0x7bc87c: b               #0x7bc8a0
    // 0x7bc880: mov             x0, x1
    // 0x7bc884: b               #0x7bc8a0
    // 0x7bc888: LoadField: r0 = r1->field_13
    //     0x7bc888: ldur            w0, [x1, #0x13]
    // 0x7bc88c: DecompressPointer r0
    //     0x7bc88c: add             x0, x0, HEAP, lsl #32
    // 0x7bc890: b               #0x7bc8a0
    // 0x7bc894: mov             x0, x3
    // 0x7bc898: b               #0x7bc8a0
    // 0x7bc89c: r0 = Null
    //     0x7bc89c: mov             x0, NULL
    // 0x7bc8a0: stur            x0, [fp, #-8]
    // 0x7bc8a4: r0 = _IndicatorPainter()
    //     0x7bc8a4: bl              #0x7bcafc  ; Allocate_IndicatorPainterStub -> _IndicatorPainter (size=0x38)
    // 0x7bc8a8: stur            x0, [fp, #-0x10]
    // 0x7bc8ac: ldur            x16, [fp, #-0x28]
    // 0x7bc8b0: stp             x16, x0, [SP, #-0x10]!
    // 0x7bc8b4: ldur            x16, [fp, #-8]
    // 0x7bc8b8: ldur            lr, [fp, #-0x40]
    // 0x7bc8bc: stp             lr, x16, [SP, #-0x10]!
    // 0x7bc8c0: ldur            x16, [fp, #-0x30]
    // 0x7bc8c4: ldur            lr, [fp, #-0x38]
    // 0x7bc8c8: stp             lr, x16, [SP, #-0x10]!
    // 0x7bc8cc: ldur            x16, [fp, #-0x18]
    // 0x7bc8d0: ldur            lr, [fp, #-0x20]
    // 0x7bc8d4: stp             lr, x16, [SP, #-0x10]!
    // 0x7bc8d8: r0 = _IndicatorPainter()
    //     0x7bc8d8: bl              #0x7bc940  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::_IndicatorPainter
    // 0x7bc8dc: add             SP, SP, #0x40
    // 0x7bc8e0: ldur            x0, [fp, #-0x10]
    // 0x7bc8e4: ldr             x1, [fp, #0x10]
    // 0x7bc8e8: StoreField: r1->field_1b = r0
    //     0x7bc8e8: stur            w0, [x1, #0x1b]
    //     0x7bc8ec: ldurb           w16, [x1, #-1]
    //     0x7bc8f0: ldurb           w17, [x0, #-1]
    //     0x7bc8f4: and             x16, x17, x16, lsr #2
    //     0x7bc8f8: tst             x16, HEAP, lsr #32
    //     0x7bc8fc: b.eq            #0x7bc904
    //     0x7bc900: bl              #0xd6826c
    // 0x7bc904: r0 = Null
    //     0x7bc904: mov             x0, NULL
    // 0x7bc908: LeaveFrame
    //     0x7bc908: mov             SP, fp
    //     0x7bc90c: ldp             fp, lr, [SP], #0x10
    // 0x7bc910: ret
    //     0x7bc910: ret             
    // 0x7bc914: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bc914: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bc918: b               #0x7bc660
    // 0x7bc91c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc91c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc920: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc920: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc924: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc924: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc928: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc928: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc92c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc92c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc930: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bc930: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bc934: r9 = _tabKeys
    //     0x7bc934: add             x9, PP, #0x37, lsl #12  ; [pp+0x37f48] Field <_TabBarState@472014024._tabKeys@472014024>: late (offset: 0x28)
    //     0x7bc938: ldr             x9, [x9, #0xf48]
    // 0x7bc93c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7bc93c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _getIndicator(/* No info */) {
    // ** addr: 0x7bcb08, size: 0x418
    // 0x7bcb08: EnterFrame
    //     0x7bcb08: stp             fp, lr, [SP, #-0x10]!
    //     0x7bcb0c: mov             fp, SP
    // 0x7bcb10: AllocStack(0x20)
    //     0x7bcb10: sub             SP, SP, #0x20
    // 0x7bcb14: CheckStackOverflow
    //     0x7bcb14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bcb18: cmp             SP, x16
    //     0x7bcb1c: b.ls            #0x7bcef8
    // 0x7bcb20: ldr             x0, [fp, #0x10]
    // 0x7bcb24: LoadField: r1 = r0->field_f
    //     0x7bcb24: ldur            w1, [x0, #0xf]
    // 0x7bcb28: DecompressPointer r1
    //     0x7bcb28: add             x1, x1, HEAP, lsl #32
    // 0x7bcb2c: cmp             w1, NULL
    // 0x7bcb30: b.eq            #0x7bcf00
    // 0x7bcb34: SaveReg r1
    //     0x7bcb34: str             x1, [SP, #-8]!
    // 0x7bcb38: r0 = of()
    //     0x7bcb38: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x7bcb3c: add             SP, SP, #8
    // 0x7bcb40: mov             x1, x0
    // 0x7bcb44: ldr             x0, [fp, #0x10]
    // 0x7bcb48: stur            x1, [fp, #-8]
    // 0x7bcb4c: LoadField: r2 = r0->field_f
    //     0x7bcb4c: ldur            w2, [x0, #0xf]
    // 0x7bcb50: DecompressPointer r2
    //     0x7bcb50: add             x2, x2, HEAP, lsl #32
    // 0x7bcb54: cmp             w2, NULL
    // 0x7bcb58: b.eq            #0x7bcf04
    // 0x7bcb5c: SaveReg r2
    //     0x7bcb5c: str             x2, [SP, #-8]!
    // 0x7bcb60: r0 = of()
    //     0x7bcb60: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x7bcb64: add             SP, SP, #8
    // 0x7bcb68: mov             x1, x0
    // 0x7bcb6c: ldur            x0, [fp, #-8]
    // 0x7bcb70: stur            x1, [fp, #-0x18]
    // 0x7bcb74: LoadField: r2 = r0->field_2b
    //     0x7bcb74: ldur            w2, [x0, #0x2b]
    // 0x7bcb78: DecompressPointer r2
    //     0x7bcb78: add             x2, x2, HEAP, lsl #32
    // 0x7bcb7c: stur            x2, [fp, #-0x10]
    // 0x7bcb80: tbnz            w2, #4, #0x7bcbd0
    // 0x7bcb84: ldr             x0, [fp, #0x10]
    // 0x7bcb88: LoadField: r3 = r0->field_f
    //     0x7bcb88: ldur            w3, [x0, #0xf]
    // 0x7bcb8c: DecompressPointer r3
    //     0x7bcb8c: add             x3, x3, HEAP, lsl #32
    // 0x7bcb90: stur            x3, [fp, #-8]
    // 0x7bcb94: cmp             w3, NULL
    // 0x7bcb98: b.eq            #0x7bcf08
    // 0x7bcb9c: r0 = _TabsDefaultsM3()
    //     0x7bcb9c: bl              #0x7bcf38  ; Allocate_TabsDefaultsM3Stub -> _TabsDefaultsM3 (size=0x44)
    // 0x7bcba0: mov             x1, x0
    // 0x7bcba4: r0 = Sentinel
    //     0x7bcba4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bcba8: StoreField: r1->field_3b = r0
    //     0x7bcba8: stur            w0, [x1, #0x3b]
    // 0x7bcbac: StoreField: r1->field_3f = r0
    //     0x7bcbac: stur            w0, [x1, #0x3f]
    // 0x7bcbb0: ldur            x0, [fp, #-8]
    // 0x7bcbb4: StoreField: r1->field_37 = r0
    //     0x7bcbb4: stur            w0, [x1, #0x37]
    // 0x7bcbb8: r2 = Instance_TabBarIndicatorSize
    //     0x7bcbb8: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0x7bcbbc: ldr             x2, [x2, #0xbe0]
    // 0x7bcbc0: StoreField: r1->field_f = r2
    //     0x7bcbc0: stur            w2, [x1, #0xf]
    // 0x7bcbc4: mov             x3, x1
    // 0x7bcbc8: mov             x2, x0
    // 0x7bcbcc: b               #0x7bcc0c
    // 0x7bcbd0: ldr             x0, [fp, #0x10]
    // 0x7bcbd4: LoadField: r1 = r0->field_f
    //     0x7bcbd4: ldur            w1, [x0, #0xf]
    // 0x7bcbd8: DecompressPointer r1
    //     0x7bcbd8: add             x1, x1, HEAP, lsl #32
    // 0x7bcbdc: stur            x1, [fp, #-8]
    // 0x7bcbe0: cmp             w1, NULL
    // 0x7bcbe4: b.eq            #0x7bcf0c
    // 0x7bcbe8: r0 = _TabsDefaultsM2()
    //     0x7bcbe8: bl              #0x7bcf2c  ; Allocate_TabsDefaultsM2Stub -> _TabsDefaultsM2 (size=0x3c)
    // 0x7bcbec: mov             x1, x0
    // 0x7bcbf0: ldur            x0, [fp, #-8]
    // 0x7bcbf4: StoreField: r1->field_37 = r0
    //     0x7bcbf4: stur            w0, [x1, #0x37]
    // 0x7bcbf8: r2 = Instance_TabBarIndicatorSize
    //     0x7bcbf8: add             x2, PP, #0x37, lsl #12  ; [pp+0x37ea0] Obj!TabBarIndicatorSize@b65171
    //     0x7bcbfc: ldr             x2, [x2, #0xea0]
    // 0x7bcc00: StoreField: r1->field_f = r2
    //     0x7bcc00: stur            w2, [x1, #0xf]
    // 0x7bcc04: mov             x3, x1
    // 0x7bcc08: mov             x2, x0
    // 0x7bcc0c: ldr             x0, [fp, #0x10]
    // 0x7bcc10: ldur            x1, [fp, #-0x18]
    // 0x7bcc14: LoadField: r4 = r0->field_b
    //     0x7bcc14: ldur            w4, [x0, #0xb]
    // 0x7bcc18: DecompressPointer r4
    //     0x7bcc18: add             x4, x4, HEAP, lsl #32
    // 0x7bcc1c: cmp             w4, NULL
    // 0x7bcc20: b.eq            #0x7bcf10
    // 0x7bcc24: LoadField: r5 = r1->field_7
    //     0x7bcc24: ldur            w5, [x1, #7]
    // 0x7bcc28: DecompressPointer r5
    //     0x7bcc28: add             x5, x5, HEAP, lsl #32
    // 0x7bcc2c: cmp             w5, NULL
    // 0x7bcc30: b.eq            #0x7bcc44
    // 0x7bcc34: mov             x0, x5
    // 0x7bcc38: LeaveFrame
    //     0x7bcc38: mov             SP, fp
    //     0x7bcc3c: ldp             fp, lr, [SP], #0x10
    // 0x7bcc40: ret
    //     0x7bcc40: ret             
    // 0x7bcc44: LoadField: r1 = r4->field_1b
    //     0x7bcc44: ldur            w1, [x4, #0x1b]
    // 0x7bcc48: DecompressPointer r1
    //     0x7bcc48: add             x1, x1, HEAP, lsl #32
    // 0x7bcc4c: cmp             w1, NULL
    // 0x7bcc50: b.ne            #0x7bcd08
    // 0x7bcc54: ldur            x4, [fp, #-0x10]
    // 0x7bcc58: tbnz            w4, #4, #0x7bcce8
    // 0x7bcc5c: r1 = LoadClassIdInstr(r3)
    //     0x7bcc5c: ldur            x1, [x3, #-1]
    //     0x7bcc60: ubfx            x1, x1, #0xc, #0x14
    // 0x7bcc64: lsl             x1, x1, #1
    // 0x7bcc68: r17 = 5444
    //     0x7bcc68: mov             x17, #0x1544
    // 0x7bcc6c: cmp             w1, w17
    // 0x7bcc70: b.ne            #0x7bcc84
    // 0x7bcc74: LoadField: r1 = r3->field_b
    //     0x7bcc74: ldur            w1, [x3, #0xb]
    // 0x7bcc78: DecompressPointer r1
    //     0x7bcc78: add             x1, x1, HEAP, lsl #32
    // 0x7bcc7c: mov             x0, x1
    // 0x7bcc80: b               #0x7bcd00
    // 0x7bcc84: r17 = 5446
    //     0x7bcc84: mov             x17, #0x1546
    // 0x7bcc88: cmp             w1, w17
    // 0x7bcc8c: b.ne            #0x7bccc4
    // 0x7bcc90: mov             x1, x3
    // 0x7bcc94: LoadField: r0 = r1->field_3b
    //     0x7bcc94: ldur            w0, [x1, #0x3b]
    // 0x7bcc98: DecompressPointer r0
    //     0x7bcc98: add             x0, x0, HEAP, lsl #32
    // 0x7bcc9c: r16 = Sentinel
    //     0x7bcc9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bcca0: cmp             w0, w16
    // 0x7bcca4: b.ne            #0x7bccb4
    // 0x7bcca8: r2 = _colors
    //     0x7bcca8: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0x7bccac: ldr             x2, [x2, #0xf50]
    // 0x7bccb0: r0 = InitLateFinalInstanceField()
    //     0x7bccb0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x7bccb4: LoadField: r1 = r0->field_b
    //     0x7bccb4: ldur            w1, [x0, #0xb]
    // 0x7bccb8: DecompressPointer r1
    //     0x7bccb8: add             x1, x1, HEAP, lsl #32
    // 0x7bccbc: mov             x0, x1
    // 0x7bccc0: b               #0x7bcd00
    // 0x7bccc4: LoadField: r0 = r3->field_37
    //     0x7bccc4: ldur            w0, [x3, #0x37]
    // 0x7bccc8: DecompressPointer r0
    //     0x7bccc8: add             x0, x0, HEAP, lsl #32
    // 0x7bcccc: SaveReg r0
    //     0x7bcccc: str             x0, [SP, #-8]!
    // 0x7bccd0: r0 = of()
    //     0x7bccd0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x7bccd4: add             SP, SP, #8
    // 0x7bccd8: LoadField: r1 = r0->field_5f
    //     0x7bccd8: ldur            w1, [x0, #0x5f]
    // 0x7bccdc: DecompressPointer r1
    //     0x7bccdc: add             x1, x1, HEAP, lsl #32
    // 0x7bcce0: mov             x0, x1
    // 0x7bcce4: b               #0x7bcd00
    // 0x7bcce8: SaveReg r2
    //     0x7bcce8: str             x2, [SP, #-8]!
    // 0x7bccec: r0 = of()
    //     0x7bccec: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x7bccf0: add             SP, SP, #8
    // 0x7bccf4: LoadField: r1 = r0->field_5f
    //     0x7bccf4: ldur            w1, [x0, #0x5f]
    // 0x7bccf8: DecompressPointer r1
    //     0x7bccf8: add             x1, x1, HEAP, lsl #32
    // 0x7bccfc: mov             x0, x1
    // 0x7bcd00: mov             x2, x0
    // 0x7bcd04: b               #0x7bcd0c
    // 0x7bcd08: mov             x2, x1
    // 0x7bcd0c: ldr             x1, [fp, #0x10]
    // 0x7bcd10: stur            x2, [fp, #-8]
    // 0x7bcd14: LoadField: r0 = r1->field_b
    //     0x7bcd14: ldur            w0, [x1, #0xb]
    // 0x7bcd18: DecompressPointer r0
    //     0x7bcd18: add             x0, x0, HEAP, lsl #32
    // 0x7bcd1c: cmp             w0, NULL
    // 0x7bcd20: b.eq            #0x7bcf14
    // 0x7bcd24: r0 = LoadClassIdInstr(r2)
    //     0x7bcd24: ldur            x0, [x2, #-1]
    //     0x7bcd28: ubfx            x0, x0, #0xc, #0x14
    // 0x7bcd2c: SaveReg r2
    //     0x7bcd2c: str             x2, [SP, #-8]!
    // 0x7bcd30: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x7bcd30: sub             lr, x0, #0xf7e
    //     0x7bcd34: ldr             lr, [x21, lr, lsl #3]
    //     0x7bcd38: blr             lr
    // 0x7bcd3c: add             SP, SP, #8
    // 0x7bcd40: mov             x1, x0
    // 0x7bcd44: ldr             x0, [fp, #0x10]
    // 0x7bcd48: stur            x1, [fp, #-0x20]
    // 0x7bcd4c: LoadField: r2 = r0->field_f
    //     0x7bcd4c: ldur            w2, [x0, #0xf]
    // 0x7bcd50: DecompressPointer r2
    //     0x7bcd50: add             x2, x2, HEAP, lsl #32
    // 0x7bcd54: cmp             w2, NULL
    // 0x7bcd58: b.eq            #0x7bcf18
    // 0x7bcd5c: SaveReg r2
    //     0x7bcd5c: str             x2, [SP, #-8]!
    // 0x7bcd60: r0 = maybeOf()
    //     0x7bcd60: bl              #0x7b289c  ; [package:flutter/src/material/material.dart] Material::maybeOf
    // 0x7bcd64: add             SP, SP, #8
    // 0x7bcd68: cmp             w0, NULL
    // 0x7bcd6c: b.ne            #0x7bcd78
    // 0x7bcd70: r3 = Null
    //     0x7bcd70: mov             x3, NULL
    // 0x7bcd74: b               #0x7bce00
    // 0x7bcd78: LoadField: r1 = r0->field_67
    //     0x7bcd78: ldur            w1, [x0, #0x67]
    // 0x7bcd7c: DecompressPointer r1
    //     0x7bcd7c: add             x1, x1, HEAP, lsl #32
    // 0x7bcd80: cmp             w1, NULL
    // 0x7bcd84: b.ne            #0x7bcd90
    // 0x7bcd88: r0 = Null
    //     0x7bcd88: mov             x0, NULL
    // 0x7bcd8c: b               #0x7bcdfc
    // 0x7bcd90: r0 = LoadClassIdInstr(r1)
    //     0x7bcd90: ldur            x0, [x1, #-1]
    //     0x7bcd94: ubfx            x0, x0, #0xc, #0x14
    // 0x7bcd98: lsl             x0, x0, #1
    // 0x7bcd9c: r17 = 10124
    //     0x7bcd9c: mov             x17, #0x278c
    // 0x7bcda0: cmp             w0, w17
    // 0x7bcda4: b.gt            #0x7bcdb4
    // 0x7bcda8: r17 = 10122
    //     0x7bcda8: mov             x17, #0x278a
    // 0x7bcdac: cmp             w0, w17
    // 0x7bcdb0: b.ge            #0x7bcdcc
    // 0x7bcdb4: r17 = 10114
    //     0x7bcdb4: mov             x17, #0x2782
    // 0x7bcdb8: cmp             w0, w17
    // 0x7bcdbc: b.eq            #0x7bcdcc
    // 0x7bcdc0: r17 = 10118
    //     0x7bcdc0: mov             x17, #0x2786
    // 0x7bcdc4: cmp             w0, w17
    // 0x7bcdc8: b.ne            #0x7bcdd8
    // 0x7bcdcc: LoadField: r0 = r1->field_7
    //     0x7bcdcc: ldur            x0, [x1, #7]
    // 0x7bcdd0: mov             x2, x0
    // 0x7bcdd4: b               #0x7bcde8
    // 0x7bcdd8: LoadField: r0 = r1->field_f
    //     0x7bcdd8: ldur            w0, [x1, #0xf]
    // 0x7bcddc: DecompressPointer r0
    //     0x7bcddc: add             x0, x0, HEAP, lsl #32
    // 0x7bcde0: LoadField: r1 = r0->field_7
    //     0x7bcde0: ldur            x1, [x0, #7]
    // 0x7bcde4: mov             x2, x1
    // 0x7bcde8: r0 = BoxInt64Instr(r2)
    //     0x7bcde8: sbfiz           x0, x2, #1, #0x1f
    //     0x7bcdec: cmp             x2, x0, asr #1
    //     0x7bcdf0: b.eq            #0x7bcdfc
    //     0x7bcdf4: bl              #0xd69bb8
    //     0x7bcdf8: stur            x2, [x0, #7]
    // 0x7bcdfc: mov             x3, x0
    // 0x7bce00: ldur            x2, [fp, #-0x20]
    // 0x7bce04: r0 = BoxInt64Instr(r2)
    //     0x7bce04: sbfiz           x0, x2, #1, #0x1f
    //     0x7bce08: cmp             x2, x0, asr #1
    //     0x7bce0c: b.eq            #0x7bce18
    //     0x7bce10: bl              #0xd69bb8
    //     0x7bce14: stur            x2, [x0, #7]
    // 0x7bce18: cmp             w0, w3
    // 0x7bce1c: b.eq            #0x7bce58
    // 0x7bce20: and             w16, w0, w3
    // 0x7bce24: branchIfSmi(r16, 0x7bce64)
    //     0x7bce24: tbz             w16, #0, #0x7bce64
    // 0x7bce28: r16 = LoadClassIdInstr(r0)
    //     0x7bce28: ldur            x16, [x0, #-1]
    //     0x7bce2c: ubfx            x16, x16, #0xc, #0x14
    // 0x7bce30: cmp             x16, #0x3c
    // 0x7bce34: b.ne            #0x7bce64
    // 0x7bce38: r16 = LoadClassIdInstr(r3)
    //     0x7bce38: ldur            x16, [x3, #-1]
    //     0x7bce3c: ubfx            x16, x16, #0xc, #0x14
    // 0x7bce40: cmp             x16, #0x3c
    // 0x7bce44: b.ne            #0x7bce64
    // 0x7bce48: LoadField: r16 = r0->field_7
    //     0x7bce48: ldur            x16, [x0, #7]
    // 0x7bce4c: LoadField: r17 = r3->field_7
    //     0x7bce4c: ldur            x17, [x3, #7]
    // 0x7bce50: cmp             x16, x17
    // 0x7bce54: b.ne            #0x7bce64
    // 0x7bce58: r1 = Instance_Color
    //     0x7bce58: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x7bce5c: ldr             x1, [x1, #0xbe8]
    // 0x7bce60: b               #0x7bce68
    // 0x7bce64: ldur            x1, [fp, #-8]
    // 0x7bce68: ldur            x0, [fp, #-0x10]
    // 0x7bce6c: stur            x1, [fp, #-0x18]
    // 0x7bce70: tbnz            w0, #4, #0x7bce80
    // 0x7bce74: r2 = Instance_BorderRadius
    //     0x7bce74: add             x2, PP, #0x37, lsl #12  ; [pp+0x37fd0] Obj!BorderRadius@b37491
    //     0x7bce78: ldr             x2, [x2, #0xfd0]
    // 0x7bce7c: b               #0x7bce84
    // 0x7bce80: r2 = Null
    //     0x7bce80: mov             x2, NULL
    // 0x7bce84: ldr             x0, [fp, #0x10]
    // 0x7bce88: stur            x2, [fp, #-8]
    // 0x7bce8c: LoadField: r3 = r0->field_b
    //     0x7bce8c: ldur            w3, [x0, #0xb]
    // 0x7bce90: DecompressPointer r3
    //     0x7bce90: add             x3, x3, HEAP, lsl #32
    // 0x7bce94: cmp             w3, NULL
    // 0x7bce98: b.eq            #0x7bcf1c
    // 0x7bce9c: r0 = BorderSide()
    //     0x7bce9c: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0x7bcea0: mov             x1, x0
    // 0x7bcea4: ldur            x0, [fp, #-0x18]
    // 0x7bcea8: stur            x1, [fp, #-0x10]
    // 0x7bceac: StoreField: r1->field_7 = r0
    //     0x7bceac: stur            w0, [x1, #7]
    // 0x7bceb0: d0 = 2.000000
    //     0x7bceb0: fmov            d0, #2.00000000
    // 0x7bceb4: StoreField: r1->field_b = d0
    //     0x7bceb4: stur            d0, [x1, #0xb]
    // 0x7bceb8: r0 = Instance_BorderStyle
    //     0x7bceb8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x7bcebc: ldr             x0, [x0, #0xbd0]
    // 0x7bcec0: StoreField: r1->field_13 = r0
    //     0x7bcec0: stur            w0, [x1, #0x13]
    // 0x7bcec4: d0 = -1.000000
    //     0x7bcec4: fmov            d0, #-1.00000000
    // 0x7bcec8: StoreField: r1->field_17 = d0
    //     0x7bcec8: stur            d0, [x1, #0x17]
    // 0x7bcecc: r0 = UnderlineTabIndicator()
    //     0x7bcecc: bl              #0x7bcf20  ; AllocateUnderlineTabIndicatorStub -> UnderlineTabIndicator (size=0x14)
    // 0x7bced0: ldur            x1, [fp, #-8]
    // 0x7bced4: StoreField: r0->field_7 = r1
    //     0x7bced4: stur            w1, [x0, #7]
    // 0x7bced8: ldur            x1, [fp, #-0x10]
    // 0x7bcedc: StoreField: r0->field_b = r1
    //     0x7bcedc: stur            w1, [x0, #0xb]
    // 0x7bcee0: r1 = Instance_EdgeInsets
    //     0x7bcee0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x7bcee4: ldr             x1, [x1, #0xbd8]
    // 0x7bcee8: StoreField: r0->field_f = r1
    //     0x7bcee8: stur            w1, [x0, #0xf]
    // 0x7bceec: LeaveFrame
    //     0x7bceec: mov             SP, fp
    //     0x7bcef0: ldp             fp, lr, [SP], #0x10
    // 0x7bcef4: ret
    //     0x7bcef4: ret             
    // 0x7bcef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bcef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bcefc: b               #0x7bcb20
    // 0x7bcf00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bcf1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bcf1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTabController(/* No info */) {
    // ** addr: 0x7bcf90, size: 0x2ac
    // 0x7bcf90: EnterFrame
    //     0x7bcf90: stp             fp, lr, [SP, #-0x10]!
    //     0x7bcf94: mov             fp, SP
    // 0x7bcf98: AllocStack(0x10)
    //     0x7bcf98: sub             SP, SP, #0x10
    // 0x7bcf9c: CheckStackOverflow
    //     0x7bcf9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bcfa0: cmp             SP, x16
    //     0x7bcfa4: b.ls            #0x7bd214
    // 0x7bcfa8: ldr             x0, [fp, #0x10]
    // 0x7bcfac: LoadField: r1 = r0->field_b
    //     0x7bcfac: ldur            w1, [x0, #0xb]
    // 0x7bcfb0: DecompressPointer r1
    //     0x7bcfb0: add             x1, x1, HEAP, lsl #32
    // 0x7bcfb4: cmp             w1, NULL
    // 0x7bcfb8: b.eq            #0x7bd21c
    // 0x7bcfbc: LoadField: r2 = r1->field_f
    //     0x7bcfbc: ldur            w2, [x1, #0xf]
    // 0x7bcfc0: DecompressPointer r2
    //     0x7bcfc0: add             x2, x2, HEAP, lsl #32
    // 0x7bcfc4: cmp             w2, NULL
    // 0x7bcfc8: b.ne            #0x7bcff0
    // 0x7bcfcc: LoadField: r1 = r0->field_f
    //     0x7bcfcc: ldur            w1, [x0, #0xf]
    // 0x7bcfd0: DecompressPointer r1
    //     0x7bcfd0: add             x1, x1, HEAP, lsl #32
    // 0x7bcfd4: cmp             w1, NULL
    // 0x7bcfd8: b.eq            #0x7bd220
    // 0x7bcfdc: SaveReg r1
    //     0x7bcfdc: str             x1, [SP, #-8]!
    // 0x7bcfe0: r0 = maybeOf()
    //     0x7bcfe0: bl              #0x7bd23c  ; [package:flutter/src/material/tab_controller.dart] DefaultTabController::maybeOf
    // 0x7bcfe4: add             SP, SP, #8
    // 0x7bcfe8: mov             x1, x0
    // 0x7bcfec: b               #0x7bcff4
    // 0x7bcff0: mov             x1, x2
    // 0x7bcff4: ldr             x0, [fp, #0x10]
    // 0x7bcff8: stur            x1, [fp, #-8]
    // 0x7bcffc: LoadField: r2 = r0->field_17
    //     0x7bcffc: ldur            w2, [x0, #0x17]
    // 0x7bd000: DecompressPointer r2
    //     0x7bd000: add             x2, x2, HEAP, lsl #32
    // 0x7bd004: cmp             w1, w2
    // 0x7bd008: b.ne            #0x7bd01c
    // 0x7bd00c: r0 = Null
    //     0x7bd00c: mov             x0, NULL
    // 0x7bd010: LeaveFrame
    //     0x7bd010: mov             SP, fp
    //     0x7bd014: ldp             fp, lr, [SP], #0x10
    // 0x7bd018: ret
    //     0x7bd018: ret             
    // 0x7bd01c: SaveReg r0
    //     0x7bd01c: str             x0, [SP, #-8]!
    // 0x7bd020: r0 = _controllerIsValid()
    //     0x7bd020: bl              #0x79f3ec  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_controllerIsValid
    // 0x7bd024: add             SP, SP, #8
    // 0x7bd028: tbnz            w0, #4, #0x7bd0e8
    // 0x7bd02c: ldr             x0, [fp, #0x10]
    // 0x7bd030: LoadField: r1 = r0->field_17
    //     0x7bd030: ldur            w1, [x0, #0x17]
    // 0x7bd034: DecompressPointer r1
    //     0x7bd034: add             x1, x1, HEAP, lsl #32
    // 0x7bd038: cmp             w1, NULL
    // 0x7bd03c: b.eq            #0x7bd224
    // 0x7bd040: LoadField: r2 = r1->field_23
    //     0x7bd040: ldur            w2, [x1, #0x23]
    // 0x7bd044: DecompressPointer r2
    //     0x7bd044: add             x2, x2, HEAP, lsl #32
    // 0x7bd048: cmp             w2, NULL
    // 0x7bd04c: b.ne            #0x7bd058
    // 0x7bd050: r1 = Null
    //     0x7bd050: mov             x1, NULL
    // 0x7bd054: b               #0x7bd05c
    // 0x7bd058: mov             x1, x2
    // 0x7bd05c: stur            x1, [fp, #-0x10]
    // 0x7bd060: cmp             w1, NULL
    // 0x7bd064: b.eq            #0x7bd228
    // 0x7bd068: r1 = 1
    //     0x7bd068: mov             x1, #1
    // 0x7bd06c: r0 = AllocateContext()
    //     0x7bd06c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bd070: mov             x1, x0
    // 0x7bd074: ldr             x0, [fp, #0x10]
    // 0x7bd078: StoreField: r1->field_f = r0
    //     0x7bd078: stur            w0, [x1, #0xf]
    // 0x7bd07c: mov             x2, x1
    // 0x7bd080: r1 = Function '_handleTabControllerAnimationTick@472014024':.
    //     0x7bd080: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f68] AnonymousClosure: (0x7bd838), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick (0x7bd880)
    //     0x7bd084: ldr             x1, [x1, #0xf68]
    // 0x7bd088: r0 = AllocateClosure()
    //     0x7bd088: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bd08c: ldur            x16, [fp, #-0x10]
    // 0x7bd090: stp             x0, x16, [SP, #-0x10]!
    // 0x7bd094: r0 = removeListener()
    //     0x7bd094: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0x7bd098: add             SP, SP, #0x10
    // 0x7bd09c: ldr             x0, [fp, #0x10]
    // 0x7bd0a0: LoadField: r1 = r0->field_17
    //     0x7bd0a0: ldur            w1, [x0, #0x17]
    // 0x7bd0a4: DecompressPointer r1
    //     0x7bd0a4: add             x1, x1, HEAP, lsl #32
    // 0x7bd0a8: stur            x1, [fp, #-0x10]
    // 0x7bd0ac: cmp             w1, NULL
    // 0x7bd0b0: b.eq            #0x7bd22c
    // 0x7bd0b4: r1 = 1
    //     0x7bd0b4: mov             x1, #1
    // 0x7bd0b8: r0 = AllocateContext()
    //     0x7bd0b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bd0bc: mov             x1, x0
    // 0x7bd0c0: ldr             x0, [fp, #0x10]
    // 0x7bd0c4: StoreField: r1->field_f = r0
    //     0x7bd0c4: stur            w0, [x1, #0xf]
    // 0x7bd0c8: mov             x2, x1
    // 0x7bd0cc: r1 = Function '_handleTabControllerTick@472014024':.
    //     0x7bd0cc: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f70] AnonymousClosure: (0x7bd29c), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick (0x7bd2e4)
    //     0x7bd0d0: ldr             x1, [x1, #0xf70]
    // 0x7bd0d4: r0 = AllocateClosure()
    //     0x7bd0d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bd0d8: ldur            x16, [fp, #-0x10]
    // 0x7bd0dc: stp             x0, x16, [SP, #-0x10]!
    // 0x7bd0e0: r0 = removeListener()
    //     0x7bd0e0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7bd0e4: add             SP, SP, #0x10
    // 0x7bd0e8: ldr             x1, [fp, #0x10]
    // 0x7bd0ec: ldur            x2, [fp, #-8]
    // 0x7bd0f0: mov             x0, x2
    // 0x7bd0f4: StoreField: r1->field_17 = r0
    //     0x7bd0f4: stur            w0, [x1, #0x17]
    //     0x7bd0f8: ldurb           w16, [x1, #-1]
    //     0x7bd0fc: ldurb           w17, [x0, #-1]
    //     0x7bd100: and             x16, x17, x16, lsr #2
    //     0x7bd104: tst             x16, HEAP, lsr #32
    //     0x7bd108: b.eq            #0x7bd110
    //     0x7bd10c: bl              #0xd6826c
    // 0x7bd110: cmp             w2, NULL
    // 0x7bd114: b.eq            #0x7bd204
    // 0x7bd118: LoadField: r0 = r2->field_23
    //     0x7bd118: ldur            w0, [x2, #0x23]
    // 0x7bd11c: DecompressPointer r0
    //     0x7bd11c: add             x0, x0, HEAP, lsl #32
    // 0x7bd120: cmp             w0, NULL
    // 0x7bd124: b.ne            #0x7bd12c
    // 0x7bd128: r0 = Null
    //     0x7bd128: mov             x0, NULL
    // 0x7bd12c: stur            x0, [fp, #-8]
    // 0x7bd130: cmp             w0, NULL
    // 0x7bd134: b.eq            #0x7bd230
    // 0x7bd138: r1 = 1
    //     0x7bd138: mov             x1, #1
    // 0x7bd13c: r0 = AllocateContext()
    //     0x7bd13c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bd140: mov             x1, x0
    // 0x7bd144: ldr             x0, [fp, #0x10]
    // 0x7bd148: StoreField: r1->field_f = r0
    //     0x7bd148: stur            w0, [x1, #0xf]
    // 0x7bd14c: mov             x2, x1
    // 0x7bd150: r1 = Function '_handleTabControllerAnimationTick@472014024':.
    //     0x7bd150: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f68] AnonymousClosure: (0x7bd838), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick (0x7bd880)
    //     0x7bd154: ldr             x1, [x1, #0xf68]
    // 0x7bd158: r0 = AllocateClosure()
    //     0x7bd158: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bd15c: ldur            x16, [fp, #-8]
    // 0x7bd160: stp             x0, x16, [SP, #-0x10]!
    // 0x7bd164: r0 = addActionListener()
    //     0x7bd164: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x7bd168: add             SP, SP, #0x10
    // 0x7bd16c: ldr             x0, [fp, #0x10]
    // 0x7bd170: LoadField: r1 = r0->field_17
    //     0x7bd170: ldur            w1, [x0, #0x17]
    // 0x7bd174: DecompressPointer r1
    //     0x7bd174: add             x1, x1, HEAP, lsl #32
    // 0x7bd178: stur            x1, [fp, #-8]
    // 0x7bd17c: cmp             w1, NULL
    // 0x7bd180: b.eq            #0x7bd234
    // 0x7bd184: r1 = 1
    //     0x7bd184: mov             x1, #1
    // 0x7bd188: r0 = AllocateContext()
    //     0x7bd188: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bd18c: mov             x1, x0
    // 0x7bd190: ldr             x0, [fp, #0x10]
    // 0x7bd194: StoreField: r1->field_f = r0
    //     0x7bd194: stur            w0, [x1, #0xf]
    // 0x7bd198: mov             x2, x1
    // 0x7bd19c: r1 = Function '_handleTabControllerTick@472014024':.
    //     0x7bd19c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f70] AnonymousClosure: (0x7bd29c), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick (0x7bd2e4)
    //     0x7bd1a0: ldr             x1, [x1, #0xf70]
    // 0x7bd1a4: r0 = AllocateClosure()
    //     0x7bd1a4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bd1a8: ldur            x16, [fp, #-8]
    // 0x7bd1ac: stp             x0, x16, [SP, #-0x10]!
    // 0x7bd1b0: r0 = addListener()
    //     0x7bd1b0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7bd1b4: add             SP, SP, #0x10
    // 0x7bd1b8: ldr             x2, [fp, #0x10]
    // 0x7bd1bc: LoadField: r3 = r2->field_17
    //     0x7bd1bc: ldur            w3, [x2, #0x17]
    // 0x7bd1c0: DecompressPointer r3
    //     0x7bd1c0: add             x3, x3, HEAP, lsl #32
    // 0x7bd1c4: cmp             w3, NULL
    // 0x7bd1c8: b.eq            #0x7bd238
    // 0x7bd1cc: LoadField: r4 = r3->field_33
    //     0x7bd1cc: ldur            x4, [x3, #0x33]
    // 0x7bd1d0: r0 = BoxInt64Instr(r4)
    //     0x7bd1d0: sbfiz           x0, x4, #1, #0x1f
    //     0x7bd1d4: cmp             x4, x0, asr #1
    //     0x7bd1d8: b.eq            #0x7bd1e4
    //     0x7bd1dc: bl              #0xd69bb8
    //     0x7bd1e0: stur            x4, [x0, #7]
    // 0x7bd1e4: StoreField: r2->field_1f = r0
    //     0x7bd1e4: stur            w0, [x2, #0x1f]
    //     0x7bd1e8: tbz             w0, #0, #0x7bd204
    //     0x7bd1ec: ldurb           w16, [x2, #-1]
    //     0x7bd1f0: ldurb           w17, [x0, #-1]
    //     0x7bd1f4: and             x16, x17, x16, lsr #2
    //     0x7bd1f8: tst             x16, HEAP, lsr #32
    //     0x7bd1fc: b.eq            #0x7bd204
    //     0x7bd200: bl              #0xd6828c
    // 0x7bd204: r0 = Null
    //     0x7bd204: mov             x0, NULL
    // 0x7bd208: LeaveFrame
    //     0x7bd208: mov             SP, fp
    //     0x7bd20c: ldp             fp, lr, [SP], #0x10
    // 0x7bd210: ret
    //     0x7bd210: ret             
    // 0x7bd214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd218: b               #0x7bcfa8
    // 0x7bd21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd21c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd224: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd228: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd228: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd22c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd22c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd230: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd234: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd234: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd238: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTabControllerTick(dynamic) {
    // ** addr: 0x7bd29c, size: 0x48
    // 0x7bd29c: EnterFrame
    //     0x7bd29c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd2a0: mov             fp, SP
    // 0x7bd2a4: ldr             x0, [fp, #0x10]
    // 0x7bd2a8: LoadField: r1 = r0->field_17
    //     0x7bd2a8: ldur            w1, [x0, #0x17]
    // 0x7bd2ac: DecompressPointer r1
    //     0x7bd2ac: add             x1, x1, HEAP, lsl #32
    // 0x7bd2b0: CheckStackOverflow
    //     0x7bd2b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd2b4: cmp             SP, x16
    //     0x7bd2b8: b.ls            #0x7bd2dc
    // 0x7bd2bc: LoadField: r0 = r1->field_f
    //     0x7bd2bc: ldur            w0, [x1, #0xf]
    // 0x7bd2c0: DecompressPointer r0
    //     0x7bd2c0: add             x0, x0, HEAP, lsl #32
    // 0x7bd2c4: SaveReg r0
    //     0x7bd2c4: str             x0, [SP, #-8]!
    // 0x7bd2c8: r0 = _handleTabControllerTick()
    //     0x7bd2c8: bl              #0x7bd2e4  ; [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick
    // 0x7bd2cc: add             SP, SP, #8
    // 0x7bd2d0: LeaveFrame
    //     0x7bd2d0: mov             SP, fp
    //     0x7bd2d4: ldp             fp, lr, [SP], #0x10
    // 0x7bd2d8: ret
    //     0x7bd2d8: ret             
    // 0x7bd2dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd2dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd2e0: b               #0x7bd2bc
  }
  _ _handleTabControllerTick(/* No info */) {
    // ** addr: 0x7bd2e4, size: 0x110
    // 0x7bd2e4: EnterFrame
    //     0x7bd2e4: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd2e8: mov             fp, SP
    // 0x7bd2ec: CheckStackOverflow
    //     0x7bd2ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd2f0: cmp             SP, x16
    //     0x7bd2f4: b.ls            #0x7bd3e4
    // 0x7bd2f8: ldr             x2, [fp, #0x10]
    // 0x7bd2fc: LoadField: r0 = r2->field_17
    //     0x7bd2fc: ldur            w0, [x2, #0x17]
    // 0x7bd300: DecompressPointer r0
    //     0x7bd300: add             x0, x0, HEAP, lsl #32
    // 0x7bd304: cmp             w0, NULL
    // 0x7bd308: b.eq            #0x7bd3ec
    // 0x7bd30c: LoadField: r3 = r0->field_33
    //     0x7bd30c: ldur            x3, [x0, #0x33]
    // 0x7bd310: LoadField: r4 = r2->field_1f
    //     0x7bd310: ldur            w4, [x2, #0x1f]
    // 0x7bd314: DecompressPointer r4
    //     0x7bd314: add             x4, x4, HEAP, lsl #32
    // 0x7bd318: r0 = BoxInt64Instr(r3)
    //     0x7bd318: sbfiz           x0, x3, #1, #0x1f
    //     0x7bd31c: cmp             x3, x0, asr #1
    //     0x7bd320: b.eq            #0x7bd32c
    //     0x7bd324: bl              #0xd69bb8
    //     0x7bd328: stur            x3, [x0, #7]
    // 0x7bd32c: cmp             w0, w4
    // 0x7bd330: b.eq            #0x7bd3b4
    // 0x7bd334: and             w16, w0, w4
    // 0x7bd338: branchIfSmi(r16, 0x7bd36c)
    //     0x7bd338: tbz             w16, #0, #0x7bd36c
    // 0x7bd33c: r16 = LoadClassIdInstr(r0)
    //     0x7bd33c: ldur            x16, [x0, #-1]
    //     0x7bd340: ubfx            x16, x16, #0xc, #0x14
    // 0x7bd344: cmp             x16, #0x3c
    // 0x7bd348: b.ne            #0x7bd36c
    // 0x7bd34c: r16 = LoadClassIdInstr(r4)
    //     0x7bd34c: ldur            x16, [x4, #-1]
    //     0x7bd350: ubfx            x16, x16, #0xc, #0x14
    // 0x7bd354: cmp             x16, #0x3c
    // 0x7bd358: b.ne            #0x7bd36c
    // 0x7bd35c: LoadField: r16 = r0->field_7
    //     0x7bd35c: ldur            x16, [x0, #7]
    // 0x7bd360: LoadField: r17 = r4->field_7
    //     0x7bd360: ldur            x17, [x4, #7]
    // 0x7bd364: cmp             x16, x17
    // 0x7bd368: b.eq            #0x7bd3b4
    // 0x7bd36c: StoreField: r2->field_1f = r0
    //     0x7bd36c: stur            w0, [x2, #0x1f]
    //     0x7bd370: tbz             w0, #0, #0x7bd38c
    //     0x7bd374: ldurb           w16, [x2, #-1]
    //     0x7bd378: ldurb           w17, [x0, #-1]
    //     0x7bd37c: and             x16, x17, x16, lsr #2
    //     0x7bd380: tst             x16, HEAP, lsr #32
    //     0x7bd384: b.eq            #0x7bd38c
    //     0x7bd388: bl              #0xd6828c
    // 0x7bd38c: LoadField: r0 = r2->field_b
    //     0x7bd38c: ldur            w0, [x2, #0xb]
    // 0x7bd390: DecompressPointer r0
    //     0x7bd390: add             x0, x0, HEAP, lsl #32
    // 0x7bd394: cmp             w0, NULL
    // 0x7bd398: b.eq            #0x7bd3f0
    // 0x7bd39c: LoadField: r1 = r0->field_13
    //     0x7bd39c: ldur            w1, [x0, #0x13]
    // 0x7bd3a0: DecompressPointer r1
    //     0x7bd3a0: add             x1, x1, HEAP, lsl #32
    // 0x7bd3a4: tbnz            w1, #4, #0x7bd3b4
    // 0x7bd3a8: SaveReg r2
    //     0x7bd3a8: str             x2, [SP, #-8]!
    // 0x7bd3ac: r0 = _scrollToCurrentIndex()
    //     0x7bd3ac: bl              #0x7bd3f4  ; [package:flutter/src/material/tabs.dart] _TabBarState::_scrollToCurrentIndex
    // 0x7bd3b0: add             SP, SP, #8
    // 0x7bd3b4: r1 = Function '<anonymous closure>':.
    //     0x7bd3b4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f78] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7bd3b8: ldr             x1, [x1, #0xf78]
    // 0x7bd3bc: r2 = Null
    //     0x7bd3bc: mov             x2, NULL
    // 0x7bd3c0: r0 = AllocateClosure()
    //     0x7bd3c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bd3c4: ldr             x16, [fp, #0x10]
    // 0x7bd3c8: stp             x0, x16, [SP, #-0x10]!
    // 0x7bd3cc: r0 = setState()
    //     0x7bd3cc: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7bd3d0: add             SP, SP, #0x10
    // 0x7bd3d4: r0 = Null
    //     0x7bd3d4: mov             x0, NULL
    // 0x7bd3d8: LeaveFrame
    //     0x7bd3d8: mov             SP, fp
    //     0x7bd3dc: ldp             fp, lr, [SP], #0x10
    // 0x7bd3e0: ret
    //     0x7bd3e0: ret             
    // 0x7bd3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd3e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd3e8: b               #0x7bd2f8
    // 0x7bd3ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd3ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd3f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd3f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scrollToCurrentIndex(/* No info */) {
    // ** addr: 0x7bd3f4, size: 0x98
    // 0x7bd3f4: EnterFrame
    //     0x7bd3f4: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd3f8: mov             fp, SP
    // 0x7bd3fc: CheckStackOverflow
    //     0x7bd3fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd400: cmp             SP, x16
    //     0x7bd404: b.ls            #0x7bd47c
    // 0x7bd408: ldr             x0, [fp, #0x10]
    // 0x7bd40c: LoadField: r1 = r0->field_1f
    //     0x7bd40c: ldur            w1, [x0, #0x1f]
    // 0x7bd410: DecompressPointer r1
    //     0x7bd410: add             x1, x1, HEAP, lsl #32
    // 0x7bd414: cmp             w1, NULL
    // 0x7bd418: b.eq            #0x7bd484
    // 0x7bd41c: r2 = LoadInt32Instr(r1)
    //     0x7bd41c: sbfx            x2, x1, #1, #0x1f
    //     0x7bd420: tbz             w1, #0, #0x7bd428
    //     0x7bd424: ldur            x2, [x1, #7]
    // 0x7bd428: stp             x2, x0, [SP, #-0x10]!
    // 0x7bd42c: r0 = _tabCenteredScrollOffset()
    //     0x7bd42c: bl              #0x7bd48c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_tabCenteredScrollOffset
    // 0x7bd430: add             SP, SP, #0x10
    // 0x7bd434: ldr             x0, [fp, #0x10]
    // 0x7bd438: LoadField: r1 = r0->field_13
    //     0x7bd438: ldur            w1, [x0, #0x13]
    // 0x7bd43c: DecompressPointer r1
    //     0x7bd43c: add             x1, x1, HEAP, lsl #32
    // 0x7bd440: cmp             w1, NULL
    // 0x7bd444: b.eq            #0x7bd488
    // 0x7bd448: SaveReg r1
    //     0x7bd448: str             x1, [SP, #-8]!
    // 0x7bd44c: SaveReg d0
    //     0x7bd44c: str             d0, [SP, #-8]!
    // 0x7bd450: r16 = Instance_Cubic
    //     0x7bd450: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x7bd454: ldr             x16, [x16, #0xfc8]
    // 0x7bd458: r30 = Instance_Duration
    //     0x7bd458: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc88] Obj!Duration@b67ad1
    //     0x7bd45c: ldr             lr, [lr, #0xc88]
    // 0x7bd460: stp             lr, x16, [SP, #-0x10]!
    // 0x7bd464: r0 = animateTo()
    //     0x7bd464: bl              #0x518ce0  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::animateTo
    // 0x7bd468: add             SP, SP, #0x20
    // 0x7bd46c: r0 = Null
    //     0x7bd46c: mov             x0, NULL
    // 0x7bd470: LeaveFrame
    //     0x7bd470: mov             SP, fp
    //     0x7bd474: ldp             fp, lr, [SP], #0x10
    // 0x7bd478: ret
    //     0x7bd478: ret             
    // 0x7bd47c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd47c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd480: b               #0x7bd408
    // 0x7bd484: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd484: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd488: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bd488: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _tabCenteredScrollOffset(/* No info */) {
    // ** addr: 0x7bd48c, size: 0x128
    // 0x7bd48c: EnterFrame
    //     0x7bd48c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd490: mov             fp, SP
    // 0x7bd494: AllocStack(0x8)
    //     0x7bd494: sub             SP, SP, #8
    // 0x7bd498: CheckStackOverflow
    //     0x7bd498: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd49c: cmp             SP, x16
    //     0x7bd4a0: b.ls            #0x7bd57c
    // 0x7bd4a4: ldr             x0, [fp, #0x18]
    // 0x7bd4a8: LoadField: r1 = r0->field_13
    //     0x7bd4a8: ldur            w1, [x0, #0x13]
    // 0x7bd4ac: DecompressPointer r1
    //     0x7bd4ac: add             x1, x1, HEAP, lsl #32
    // 0x7bd4b0: cmp             w1, NULL
    // 0x7bd4b4: b.eq            #0x7bd584
    // 0x7bd4b8: LoadField: r2 = r1->field_33
    //     0x7bd4b8: ldur            w2, [x1, #0x33]
    // 0x7bd4bc: DecompressPointer r2
    //     0x7bd4bc: add             x2, x2, HEAP, lsl #32
    // 0x7bd4c0: SaveReg r2
    //     0x7bd4c0: str             x2, [SP, #-8]!
    // 0x7bd4c4: r0 = single()
    //     0x7bd4c4: bl              #0x6f851c  ; [dart:core] _GrowableList::single
    // 0x7bd4c8: add             SP, SP, #8
    // 0x7bd4cc: mov             x1, x0
    // 0x7bd4d0: stur            x1, [fp, #-8]
    // 0x7bd4d4: r0 = LoadClassIdInstr(r1)
    //     0x7bd4d4: ldur            x0, [x1, #-1]
    //     0x7bd4d8: ubfx            x0, x0, #0xc, #0x14
    // 0x7bd4dc: SaveReg r1
    //     0x7bd4dc: str             x1, [SP, #-8]!
    // 0x7bd4e0: r0 = GDT[cid_x0 + -0xfa2]()
    //     0x7bd4e0: sub             lr, x0, #0xfa2
    //     0x7bd4e4: ldr             lr, [x21, lr, lsl #3]
    //     0x7bd4e8: blr             lr
    // 0x7bd4ec: add             SP, SP, #8
    // 0x7bd4f0: ldur            x0, [fp, #-8]
    // 0x7bd4f4: LoadField: r2 = r0->field_33
    //     0x7bd4f4: ldur            w2, [x0, #0x33]
    // 0x7bd4f8: DecompressPointer r2
    //     0x7bd4f8: add             x2, x2, HEAP, lsl #32
    // 0x7bd4fc: cmp             w2, NULL
    // 0x7bd500: b.eq            #0x7bd588
    // 0x7bd504: LoadField: r3 = r0->field_37
    //     0x7bd504: ldur            w3, [x0, #0x37]
    // 0x7bd508: DecompressPointer r3
    //     0x7bd508: add             x3, x3, HEAP, lsl #32
    // 0x7bd50c: cmp             w3, NULL
    // 0x7bd510: b.eq            #0x7bd58c
    // 0x7bd514: ldr             x4, [fp, #0x10]
    // 0x7bd518: r0 = BoxInt64Instr(r4)
    //     0x7bd518: sbfiz           x0, x4, #1, #0x1f
    //     0x7bd51c: cmp             x4, x0, asr #1
    //     0x7bd520: b.eq            #0x7bd52c
    //     0x7bd524: bl              #0xd69c6c
    //     0x7bd528: stur            x4, [x0, #7]
    // 0x7bd52c: r1 = inline_Allocate_Double()
    //     0x7bd52c: ldp             x1, x4, [THR, #0x60]  ; THR::top
    //     0x7bd530: add             x1, x1, #0x10
    //     0x7bd534: cmp             x4, x1
    //     0x7bd538: b.ls            #0x7bd590
    //     0x7bd53c: str             x1, [THR, #0x60]  ; THR::top
    //     0x7bd540: sub             x1, x1, #0xf
    //     0x7bd544: mov             x4, #0xd108
    //     0x7bd548: movk            x4, #3, lsl #16
    //     0x7bd54c: stur            x4, [x1, #-1]
    // 0x7bd550: StoreField: r1->field_7 = d0
    //     0x7bd550: stur            d0, [x1, #7]
    // 0x7bd554: LoadField: d0 = r3->field_7
    //     0x7bd554: ldur            d0, [x3, #7]
    // 0x7bd558: ldr             x16, [fp, #0x18]
    // 0x7bd55c: stp             x0, x16, [SP, #-0x10]!
    // 0x7bd560: stp             x2, x1, [SP, #-0x10]!
    // 0x7bd564: SaveReg d0
    //     0x7bd564: str             d0, [SP, #-8]!
    // 0x7bd568: r0 = _tabScrollOffset()
    //     0x7bd568: bl              #0x7bd5b4  ; [package:flutter/src/material/tabs.dart] _TabBarState::_tabScrollOffset
    // 0x7bd56c: add             SP, SP, #0x28
    // 0x7bd570: LeaveFrame
    //     0x7bd570: mov             SP, fp
    //     0x7bd574: ldp             fp, lr, [SP], #0x10
    // 0x7bd578: ret
    //     0x7bd578: ret             
    // 0x7bd57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd57c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd580: b               #0x7bd4a4
    // 0x7bd584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd584: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd588: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bd588: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bd58c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bd58c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bd590: SaveReg d0
    //     0x7bd590: str             q0, [SP, #-0x10]!
    // 0x7bd594: stp             x2, x3, [SP, #-0x10]!
    // 0x7bd598: SaveReg r0
    //     0x7bd598: str             x0, [SP, #-8]!
    // 0x7bd59c: r0 = AllocateDouble()
    //     0x7bd59c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bd5a0: mov             x1, x0
    // 0x7bd5a4: RestoreReg r0
    //     0x7bd5a4: ldr             x0, [SP], #8
    // 0x7bd5a8: ldp             x2, x3, [SP], #0x10
    // 0x7bd5ac: RestoreReg d0
    //     0x7bd5ac: ldr             q0, [SP], #0x10
    // 0x7bd5b0: b               #0x7bd550
  }
  _ _tabScrollOffset(/* No info */) {
    // ** addr: 0x7bd5b4, size: 0x190
    // 0x7bd5b4: EnterFrame
    //     0x7bd5b4: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd5b8: mov             fp, SP
    // 0x7bd5bc: AllocStack(0x8)
    //     0x7bd5bc: sub             SP, SP, #8
    // 0x7bd5c0: CheckStackOverflow
    //     0x7bd5c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd5c4: cmp             SP, x16
    //     0x7bd5c8: b.ls            #0x7bd71c
    // 0x7bd5cc: ldr             x0, [fp, #0x30]
    // 0x7bd5d0: LoadField: r1 = r0->field_b
    //     0x7bd5d0: ldur            w1, [x0, #0xb]
    // 0x7bd5d4: DecompressPointer r1
    //     0x7bd5d4: add             x1, x1, HEAP, lsl #32
    // 0x7bd5d8: cmp             w1, NULL
    // 0x7bd5dc: b.eq            #0x7bd724
    // 0x7bd5e0: LoadField: r2 = r1->field_13
    //     0x7bd5e0: ldur            w2, [x1, #0x13]
    // 0x7bd5e4: DecompressPointer r2
    //     0x7bd5e4: add             x2, x2, HEAP, lsl #32
    // 0x7bd5e8: tbz             w2, #4, #0x7bd5fc
    // 0x7bd5ec: d0 = 0.000000
    //     0x7bd5ec: eor             v0.16b, v0.16b, v0.16b
    // 0x7bd5f0: LeaveFrame
    //     0x7bd5f0: mov             SP, fp
    //     0x7bd5f4: ldp             fp, lr, [SP], #0x10
    // 0x7bd5f8: ret
    //     0x7bd5f8: ret             
    // 0x7bd5fc: ldr             x1, [fp, #0x28]
    // 0x7bd600: LoadField: r2 = r0->field_1b
    //     0x7bd600: ldur            w2, [x0, #0x1b]
    // 0x7bd604: DecompressPointer r2
    //     0x7bd604: add             x2, x2, HEAP, lsl #32
    // 0x7bd608: cmp             w2, NULL
    // 0x7bd60c: b.eq            #0x7bd728
    // 0x7bd610: r3 = LoadInt32Instr(r1)
    //     0x7bd610: sbfx            x3, x1, #1, #0x1f
    //     0x7bd614: tbz             w1, #0, #0x7bd61c
    //     0x7bd618: ldur            x3, [x1, #7]
    // 0x7bd61c: stp             x3, x2, [SP, #-0x10]!
    // 0x7bd620: r0 = centerOf()
    //     0x7bd620: bl              #0x7bd744  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::centerOf
    // 0x7bd624: add             SP, SP, #0x10
    // 0x7bd628: ldr             x0, [fp, #0x30]
    // 0x7bd62c: stur            d0, [fp, #-8]
    // 0x7bd630: LoadField: r1 = r0->field_f
    //     0x7bd630: ldur            w1, [x0, #0xf]
    // 0x7bd634: DecompressPointer r1
    //     0x7bd634: add             x1, x1, HEAP, lsl #32
    // 0x7bd638: cmp             w1, NULL
    // 0x7bd63c: b.eq            #0x7bd72c
    // 0x7bd640: SaveReg r1
    //     0x7bd640: str             x1, [SP, #-8]!
    // 0x7bd644: r0 = of()
    //     0x7bd644: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x7bd648: add             SP, SP, #8
    // 0x7bd64c: LoadField: r1 = r0->field_7
    //     0x7bd64c: ldur            x1, [x0, #7]
    // 0x7bd650: cmp             x1, #0
    // 0x7bd654: b.gt            #0x7bd690
    // 0x7bd658: ldr             x0, [fp, #0x30]
    // 0x7bd65c: ldur            d1, [fp, #-8]
    // 0x7bd660: LoadField: r1 = r0->field_b
    //     0x7bd660: ldur            w1, [x0, #0xb]
    // 0x7bd664: DecompressPointer r1
    //     0x7bd664: add             x1, x1, HEAP, lsl #32
    // 0x7bd668: cmp             w1, NULL
    // 0x7bd66c: b.eq            #0x7bd730
    // 0x7bd670: LoadField: r1 = r0->field_23
    //     0x7bd670: ldur            w1, [x0, #0x23]
    // 0x7bd674: DecompressPointer r1
    //     0x7bd674: add             x1, x1, HEAP, lsl #32
    // 0x7bd678: r16 = Sentinel
    //     0x7bd678: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bd67c: cmp             w1, w16
    // 0x7bd680: b.eq            #0x7bd734
    // 0x7bd684: LoadField: d2 = r1->field_7
    //     0x7bd684: ldur            d2, [x1, #7]
    // 0x7bd688: fsub            d3, d2, d1
    // 0x7bd68c: b               #0x7bd6ac
    // 0x7bd690: ldr             x0, [fp, #0x30]
    // 0x7bd694: ldur            d1, [fp, #-8]
    // 0x7bd698: LoadField: r1 = r0->field_b
    //     0x7bd698: ldur            w1, [x0, #0xb]
    // 0x7bd69c: DecompressPointer r1
    //     0x7bd69c: add             x1, x1, HEAP, lsl #32
    // 0x7bd6a0: cmp             w1, NULL
    // 0x7bd6a4: b.eq            #0x7bd740
    // 0x7bd6a8: mov             v3.16b, v1.16b
    // 0x7bd6ac: ldr             x1, [fp, #0x20]
    // 0x7bd6b0: ldr             x0, [fp, #0x18]
    // 0x7bd6b4: d2 = 0.000000
    //     0x7bd6b4: eor             v2.16b, v2.16b, v2.16b
    // 0x7bd6b8: d1 = 2.000000
    //     0x7bd6b8: fmov            d1, #2.00000000
    // 0x7bd6bc: fadd            d4, d3, d2
    // 0x7bd6c0: LoadField: d2 = r1->field_7
    //     0x7bd6c0: ldur            d2, [x1, #7]
    // 0x7bd6c4: fdiv            d3, d2, d1
    // 0x7bd6c8: fsub            d1, d4, d3
    // 0x7bd6cc: LoadField: d2 = r0->field_7
    //     0x7bd6cc: ldur            d2, [x0, #7]
    // 0x7bd6d0: fcmp            d1, d2
    // 0x7bd6d4: b.vs            #0x7bd6e4
    // 0x7bd6d8: b.ge            #0x7bd6e4
    // 0x7bd6dc: mov             v0.16b, v2.16b
    // 0x7bd6e0: b               #0x7bd710
    // 0x7bd6e4: ldr             d2, [fp, #0x10]
    // 0x7bd6e8: fcmp            d1, d2
    // 0x7bd6ec: b.vs            #0x7bd6fc
    // 0x7bd6f0: b.le            #0x7bd6fc
    // 0x7bd6f4: mov             v0.16b, v2.16b
    // 0x7bd6f8: b               #0x7bd710
    // 0x7bd6fc: fcmp            d1, d1
    // 0x7bd700: b.vc            #0x7bd70c
    // 0x7bd704: mov             v0.16b, v2.16b
    // 0x7bd708: b               #0x7bd710
    // 0x7bd70c: mov             v0.16b, v1.16b
    // 0x7bd710: LeaveFrame
    //     0x7bd710: mov             SP, fp
    //     0x7bd714: ldp             fp, lr, [SP], #0x10
    // 0x7bd718: ret
    //     0x7bd718: ret             
    // 0x7bd71c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd71c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd720: b               #0x7bd5cc
    // 0x7bd724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd724: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd728: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd72c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bd72c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bd730: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bd730: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bd734: r9 = _tabStripWidth
    //     0x7bd734: add             x9, PP, #0x37, lsl #12  ; [pp+0x37f80] Field <_TabBarState@472014024._tabStripWidth@472014024>: late (offset: 0x24)
    //     0x7bd738: ldr             x9, [x9, #0xf80]
    // 0x7bd73c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7bd73c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7bd740: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bd740: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void _handleTabControllerAnimationTick(dynamic) {
    // ** addr: 0x7bd838, size: 0x48
    // 0x7bd838: EnterFrame
    //     0x7bd838: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd83c: mov             fp, SP
    // 0x7bd840: ldr             x0, [fp, #0x10]
    // 0x7bd844: LoadField: r1 = r0->field_17
    //     0x7bd844: ldur            w1, [x0, #0x17]
    // 0x7bd848: DecompressPointer r1
    //     0x7bd848: add             x1, x1, HEAP, lsl #32
    // 0x7bd84c: CheckStackOverflow
    //     0x7bd84c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd850: cmp             SP, x16
    //     0x7bd854: b.ls            #0x7bd878
    // 0x7bd858: LoadField: r0 = r1->field_f
    //     0x7bd858: ldur            w0, [x1, #0xf]
    // 0x7bd85c: DecompressPointer r0
    //     0x7bd85c: add             x0, x0, HEAP, lsl #32
    // 0x7bd860: SaveReg r0
    //     0x7bd860: str             x0, [SP, #-8]!
    // 0x7bd864: r0 = _handleTabControllerAnimationTick()
    //     0x7bd864: bl              #0x7bd880  ; [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick
    // 0x7bd868: add             SP, SP, #8
    // 0x7bd86c: LeaveFrame
    //     0x7bd86c: mov             SP, fp
    //     0x7bd870: ldp             fp, lr, [SP], #0x10
    // 0x7bd874: ret
    //     0x7bd874: ret             
    // 0x7bd878: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd878: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd87c: b               #0x7bd858
  }
  _ _handleTabControllerAnimationTick(/* No info */) {
    // ** addr: 0x7bd880, size: 0xb0
    // 0x7bd880: EnterFrame
    //     0x7bd880: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd884: mov             fp, SP
    // 0x7bd888: CheckStackOverflow
    //     0x7bd888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd88c: cmp             SP, x16
    //     0x7bd890: b.ls            #0x7bd920
    // 0x7bd894: ldr             x2, [fp, #0x10]
    // 0x7bd898: LoadField: r0 = r2->field_17
    //     0x7bd898: ldur            w0, [x2, #0x17]
    // 0x7bd89c: DecompressPointer r0
    //     0x7bd89c: add             x0, x0, HEAP, lsl #32
    // 0x7bd8a0: cmp             w0, NULL
    // 0x7bd8a4: b.eq            #0x7bd928
    // 0x7bd8a8: LoadField: r1 = r0->field_43
    //     0x7bd8a8: ldur            x1, [x0, #0x43]
    // 0x7bd8ac: cbnz            x1, #0x7bd910
    // 0x7bd8b0: LoadField: r1 = r2->field_b
    //     0x7bd8b0: ldur            w1, [x2, #0xb]
    // 0x7bd8b4: DecompressPointer r1
    //     0x7bd8b4: add             x1, x1, HEAP, lsl #32
    // 0x7bd8b8: cmp             w1, NULL
    // 0x7bd8bc: b.eq            #0x7bd92c
    // 0x7bd8c0: LoadField: r3 = r1->field_13
    //     0x7bd8c0: ldur            w3, [x1, #0x13]
    // 0x7bd8c4: DecompressPointer r3
    //     0x7bd8c4: add             x3, x3, HEAP, lsl #32
    // 0x7bd8c8: tbnz            w3, #4, #0x7bd910
    // 0x7bd8cc: LoadField: r3 = r0->field_33
    //     0x7bd8cc: ldur            x3, [x0, #0x33]
    // 0x7bd8d0: r0 = BoxInt64Instr(r3)
    //     0x7bd8d0: sbfiz           x0, x3, #1, #0x1f
    //     0x7bd8d4: cmp             x3, x0, asr #1
    //     0x7bd8d8: b.eq            #0x7bd8e4
    //     0x7bd8dc: bl              #0xd69bb8
    //     0x7bd8e0: stur            x3, [x0, #7]
    // 0x7bd8e4: StoreField: r2->field_1f = r0
    //     0x7bd8e4: stur            w0, [x2, #0x1f]
    //     0x7bd8e8: tbz             w0, #0, #0x7bd904
    //     0x7bd8ec: ldurb           w16, [x2, #-1]
    //     0x7bd8f0: ldurb           w17, [x0, #-1]
    //     0x7bd8f4: and             x16, x17, x16, lsr #2
    //     0x7bd8f8: tst             x16, HEAP, lsr #32
    //     0x7bd8fc: b.eq            #0x7bd904
    //     0x7bd900: bl              #0xd6828c
    // 0x7bd904: SaveReg r2
    //     0x7bd904: str             x2, [SP, #-8]!
    // 0x7bd908: r0 = _scrollToControllerValue()
    //     0x7bd908: bl              #0x7bd930  ; [package:flutter/src/material/tabs.dart] _TabBarState::_scrollToControllerValue
    // 0x7bd90c: add             SP, SP, #8
    // 0x7bd910: r0 = Null
    //     0x7bd910: mov             x0, NULL
    // 0x7bd914: LeaveFrame
    //     0x7bd914: mov             SP, fp
    //     0x7bd918: ldp             fp, lr, [SP], #0x10
    // 0x7bd91c: ret
    //     0x7bd91c: ret             
    // 0x7bd920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd924: b               #0x7bd894
    // 0x7bd928: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd928: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd92c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd92c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _scrollToControllerValue(/* No info */) {
    // ** addr: 0x7bd930, size: 0x47c
    // 0x7bd930: EnterFrame
    //     0x7bd930: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd934: mov             fp, SP
    // 0x7bd938: AllocStack(0x18)
    //     0x7bd938: sub             SP, SP, #0x18
    // 0x7bd93c: CheckStackOverflow
    //     0x7bd93c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd940: cmp             SP, x16
    //     0x7bd944: b.ls            #0x7bdcdc
    // 0x7bd948: ldr             x0, [fp, #0x10]
    // 0x7bd94c: LoadField: r1 = r0->field_1f
    //     0x7bd94c: ldur            w1, [x0, #0x1f]
    // 0x7bd950: DecompressPointer r1
    //     0x7bd950: add             x1, x1, HEAP, lsl #32
    // 0x7bd954: cmp             w1, NULL
    // 0x7bd958: b.eq            #0x7bdce4
    // 0x7bd95c: r2 = LoadInt32Instr(r1)
    //     0x7bd95c: sbfx            x2, x1, #1, #0x1f
    //     0x7bd960: tbz             w1, #0, #0x7bd968
    //     0x7bd964: ldur            x2, [x1, #7]
    // 0x7bd968: cmp             x2, #0
    // 0x7bd96c: b.le            #0x7bd9b0
    // 0x7bd970: sub             x1, x2, #1
    // 0x7bd974: stp             x1, x0, [SP, #-0x10]!
    // 0x7bd978: r0 = _tabCenteredScrollOffset()
    //     0x7bd978: bl              #0x7bd48c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_tabCenteredScrollOffset
    // 0x7bd97c: add             SP, SP, #0x10
    // 0x7bd980: r0 = inline_Allocate_Double()
    //     0x7bd980: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7bd984: add             x0, x0, #0x10
    //     0x7bd988: cmp             x1, x0
    //     0x7bd98c: b.ls            #0x7bdce8
    //     0x7bd990: str             x0, [THR, #0x60]  ; THR::top
    //     0x7bd994: sub             x0, x0, #0xf
    //     0x7bd998: mov             x1, #0xd108
    //     0x7bd99c: movk            x1, #3, lsl #16
    //     0x7bd9a0: stur            x1, [x0, #-1]
    // 0x7bd9a4: StoreField: r0->field_7 = d0
    //     0x7bd9a4: stur            d0, [x0, #7]
    // 0x7bd9a8: mov             x1, x0
    // 0x7bd9ac: b               #0x7bd9b4
    // 0x7bd9b0: r1 = Null
    //     0x7bd9b0: mov             x1, NULL
    // 0x7bd9b4: ldr             x0, [fp, #0x10]
    // 0x7bd9b8: stur            x1, [fp, #-8]
    // 0x7bd9bc: LoadField: r2 = r0->field_1f
    //     0x7bd9bc: ldur            w2, [x0, #0x1f]
    // 0x7bd9c0: DecompressPointer r2
    //     0x7bd9c0: add             x2, x2, HEAP, lsl #32
    // 0x7bd9c4: cmp             w2, NULL
    // 0x7bd9c8: b.eq            #0x7bdcf8
    // 0x7bd9cc: r3 = LoadInt32Instr(r2)
    //     0x7bd9cc: sbfx            x3, x2, #1, #0x1f
    //     0x7bd9d0: tbz             w2, #0, #0x7bd9d8
    //     0x7bd9d4: ldur            x3, [x2, #7]
    // 0x7bd9d8: stp             x3, x0, [SP, #-0x10]!
    // 0x7bd9dc: r0 = _tabCenteredScrollOffset()
    //     0x7bd9dc: bl              #0x7bd48c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_tabCenteredScrollOffset
    // 0x7bd9e0: add             SP, SP, #0x10
    // 0x7bd9e4: ldr             x0, [fp, #0x10]
    // 0x7bd9e8: stur            d0, [fp, #-0x18]
    // 0x7bd9ec: LoadField: r1 = r0->field_1f
    //     0x7bd9ec: ldur            w1, [x0, #0x1f]
    // 0x7bd9f0: DecompressPointer r1
    //     0x7bd9f0: add             x1, x1, HEAP, lsl #32
    // 0x7bd9f4: stur            x1, [fp, #-0x10]
    // 0x7bd9f8: cmp             w1, NULL
    // 0x7bd9fc: b.eq            #0x7bdcfc
    // 0x7bda00: SaveReg r0
    //     0x7bda00: str             x0, [SP, #-8]!
    // 0x7bda04: r0 = maxTabIndex()
    //     0x7bda04: bl              #0x7bddac  ; [package:flutter/src/material/tabs.dart] _TabBarState::maxTabIndex
    // 0x7bda08: add             SP, SP, #8
    // 0x7bda0c: mov             x1, x0
    // 0x7bda10: ldur            x0, [fp, #-0x10]
    // 0x7bda14: r2 = LoadInt32Instr(r0)
    //     0x7bda14: sbfx            x2, x0, #1, #0x1f
    //     0x7bda18: tbz             w0, #0, #0x7bda20
    //     0x7bda1c: ldur            x2, [x0, #7]
    // 0x7bda20: cmp             x2, x1
    // 0x7bda24: b.ge            #0x7bda88
    // 0x7bda28: ldr             x0, [fp, #0x10]
    // 0x7bda2c: LoadField: r1 = r0->field_1f
    //     0x7bda2c: ldur            w1, [x0, #0x1f]
    // 0x7bda30: DecompressPointer r1
    //     0x7bda30: add             x1, x1, HEAP, lsl #32
    // 0x7bda34: cmp             w1, NULL
    // 0x7bda38: b.eq            #0x7bdd00
    // 0x7bda3c: r2 = LoadInt32Instr(r1)
    //     0x7bda3c: sbfx            x2, x1, #1, #0x1f
    //     0x7bda40: tbz             w1, #0, #0x7bda48
    //     0x7bda44: ldur            x2, [x1, #7]
    // 0x7bda48: add             x1, x2, #1
    // 0x7bda4c: stp             x1, x0, [SP, #-0x10]!
    // 0x7bda50: r0 = _tabCenteredScrollOffset()
    //     0x7bda50: bl              #0x7bd48c  ; [package:flutter/src/material/tabs.dart] _TabBarState::_tabCenteredScrollOffset
    // 0x7bda54: add             SP, SP, #0x10
    // 0x7bda58: r0 = inline_Allocate_Double()
    //     0x7bda58: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7bda5c: add             x0, x0, #0x10
    //     0x7bda60: cmp             x1, x0
    //     0x7bda64: b.ls            #0x7bdd04
    //     0x7bda68: str             x0, [THR, #0x60]  ; THR::top
    //     0x7bda6c: sub             x0, x0, #0xf
    //     0x7bda70: mov             x1, #0xd108
    //     0x7bda74: movk            x1, #3, lsl #16
    //     0x7bda78: stur            x1, [x0, #-1]
    // 0x7bda7c: StoreField: r0->field_7 = d0
    //     0x7bda7c: stur            d0, [x0, #7]
    // 0x7bda80: mov             x3, x0
    // 0x7bda84: b               #0x7bda8c
    // 0x7bda88: r3 = Null
    //     0x7bda88: mov             x3, NULL
    // 0x7bda8c: ldr             x2, [fp, #0x10]
    // 0x7bda90: stur            x3, [fp, #-0x10]
    // 0x7bda94: LoadField: r0 = r2->field_17
    //     0x7bda94: ldur            w0, [x2, #0x17]
    // 0x7bda98: DecompressPointer r0
    //     0x7bda98: add             x0, x0, HEAP, lsl #32
    // 0x7bda9c: cmp             w0, NULL
    // 0x7bdaa0: b.eq            #0x7bdd14
    // 0x7bdaa4: LoadField: r4 = r0->field_33
    //     0x7bdaa4: ldur            x4, [x0, #0x33]
    // 0x7bdaa8: r0 = BoxInt64Instr(r4)
    //     0x7bdaa8: sbfiz           x0, x4, #1, #0x1f
    //     0x7bdaac: cmp             x4, x0, asr #1
    //     0x7bdab0: b.eq            #0x7bdabc
    //     0x7bdab4: bl              #0xd69bb8
    //     0x7bdab8: stur            x4, [x0, #7]
    // 0x7bdabc: stp             x0, NULL, [SP, #-0x10]!
    // 0x7bdac0: r0 = _Double.fromInteger()
    //     0x7bdac0: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0x7bdac4: add             SP, SP, #0x10
    // 0x7bdac8: mov             x1, x0
    // 0x7bdacc: ldr             x0, [fp, #0x10]
    // 0x7bdad0: LoadField: r2 = r0->field_17
    //     0x7bdad0: ldur            w2, [x0, #0x17]
    // 0x7bdad4: DecompressPointer r2
    //     0x7bdad4: add             x2, x2, HEAP, lsl #32
    // 0x7bdad8: cmp             w2, NULL
    // 0x7bdadc: b.eq            #0x7bdd18
    // 0x7bdae0: LoadField: r3 = r2->field_23
    //     0x7bdae0: ldur            w3, [x2, #0x23]
    // 0x7bdae4: DecompressPointer r3
    //     0x7bdae4: add             x3, x3, HEAP, lsl #32
    // 0x7bdae8: cmp             w3, NULL
    // 0x7bdaec: b.ne            #0x7bdaf8
    // 0x7bdaf0: r2 = Null
    //     0x7bdaf0: mov             x2, NULL
    // 0x7bdaf4: b               #0x7bdafc
    // 0x7bdaf8: mov             x2, x3
    // 0x7bdafc: d0 = 1.000000
    //     0x7bdafc: fmov            d0, #1.00000000
    // 0x7bdb00: cmp             w2, NULL
    // 0x7bdb04: b.eq            #0x7bdd1c
    // 0x7bdb08: LoadField: r3 = r2->field_37
    //     0x7bdb08: ldur            w3, [x2, #0x37]
    // 0x7bdb0c: DecompressPointer r3
    //     0x7bdb0c: add             x3, x3, HEAP, lsl #32
    // 0x7bdb10: r16 = Sentinel
    //     0x7bdb10: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bdb14: cmp             w3, w16
    // 0x7bdb18: b.eq            #0x7bdd20
    // 0x7bdb1c: LoadField: d1 = r1->field_7
    //     0x7bdb1c: ldur            d1, [x1, #7]
    // 0x7bdb20: fsub            d2, d1, d0
    // 0x7bdb24: LoadField: d3 = r3->field_7
    //     0x7bdb24: ldur            d3, [x3, #7]
    // 0x7bdb28: fcmp            d3, d2
    // 0x7bdb2c: b.vs            #0x7bdb50
    // 0x7bdb30: b.ne            #0x7bdb50
    // 0x7bdb34: ldur            x1, [fp, #-8]
    // 0x7bdb38: cmp             w1, NULL
    // 0x7bdb3c: b.ne            #0x7bdb48
    // 0x7bdb40: ldur            d0, [fp, #-0x18]
    // 0x7bdb44: b               #0x7bdcac
    // 0x7bdb48: LoadField: d0 = r1->field_7
    //     0x7bdb48: ldur            d0, [x1, #7]
    // 0x7bdb4c: b               #0x7bdcac
    // 0x7bdb50: ldur            x1, [fp, #-8]
    // 0x7bdb54: fadd            d2, d1, d0
    // 0x7bdb58: fcmp            d3, d2
    // 0x7bdb5c: b.vs            #0x7bdb80
    // 0x7bdb60: b.ne            #0x7bdb80
    // 0x7bdb64: ldur            x2, [fp, #-0x10]
    // 0x7bdb68: cmp             w2, NULL
    // 0x7bdb6c: b.ne            #0x7bdb78
    // 0x7bdb70: ldur            d0, [fp, #-0x18]
    // 0x7bdb74: b               #0x7bdca8
    // 0x7bdb78: LoadField: d0 = r2->field_7
    //     0x7bdb78: ldur            d0, [x2, #7]
    // 0x7bdb7c: b               #0x7bdca8
    // 0x7bdb80: ldur            x2, [fp, #-0x10]
    // 0x7bdb84: fcmp            d3, d1
    // 0x7bdb88: b.vs            #0x7bdb98
    // 0x7bdb8c: b.ne            #0x7bdb98
    // 0x7bdb90: ldur            d0, [fp, #-0x18]
    // 0x7bdb94: b               #0x7bdca8
    // 0x7bdb98: fcmp            d3, d1
    // 0x7bdb9c: b.vs            #0x7bdc2c
    // 0x7bdba0: b.ge            #0x7bdc2c
    // 0x7bdba4: cmp             w1, NULL
    // 0x7bdba8: b.ne            #0x7bdbb4
    // 0x7bdbac: ldur            d0, [fp, #-0x18]
    // 0x7bdbb0: b               #0x7bdca8
    // 0x7bdbb4: ldur            d0, [fp, #-0x18]
    // 0x7bdbb8: fsub            d2, d1, d3
    // 0x7bdbbc: r2 = inline_Allocate_Double()
    //     0x7bdbbc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x7bdbc0: add             x2, x2, #0x10
    //     0x7bdbc4: cmp             x3, x2
    //     0x7bdbc8: b.ls            #0x7bdd2c
    //     0x7bdbcc: str             x2, [THR, #0x60]  ; THR::top
    //     0x7bdbd0: sub             x2, x2, #0xf
    //     0x7bdbd4: mov             x3, #0xd108
    //     0x7bdbd8: movk            x3, #3, lsl #16
    //     0x7bdbdc: stur            x3, [x2, #-1]
    // 0x7bdbe0: StoreField: r2->field_7 = d0
    //     0x7bdbe0: stur            d0, [x2, #7]
    // 0x7bdbe4: r3 = inline_Allocate_Double()
    //     0x7bdbe4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x7bdbe8: add             x3, x3, #0x10
    //     0x7bdbec: cmp             x4, x3
    //     0x7bdbf0: b.ls            #0x7bdd48
    //     0x7bdbf4: str             x3, [THR, #0x60]  ; THR::top
    //     0x7bdbf8: sub             x3, x3, #0xf
    //     0x7bdbfc: mov             x4, #0xd108
    //     0x7bdc00: movk            x4, #3, lsl #16
    //     0x7bdc04: stur            x4, [x3, #-1]
    // 0x7bdc08: StoreField: r3->field_7 = d2
    //     0x7bdc08: stur            d2, [x3, #7]
    // 0x7bdc0c: stp             x1, x2, [SP, #-0x10]!
    // 0x7bdc10: SaveReg r3
    //     0x7bdc10: str             x3, [SP, #-8]!
    // 0x7bdc14: r0 = lerpDouble()
    //     0x7bdc14: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x7bdc18: add             SP, SP, #0x18
    // 0x7bdc1c: cmp             w0, NULL
    // 0x7bdc20: b.eq            #0x7bdd6c
    // 0x7bdc24: LoadField: d0 = r0->field_7
    //     0x7bdc24: ldur            d0, [x0, #7]
    // 0x7bdc28: b               #0x7bdca8
    // 0x7bdc2c: ldur            d0, [fp, #-0x18]
    // 0x7bdc30: cmp             w2, NULL
    // 0x7bdc34: b.eq            #0x7bdca8
    // 0x7bdc38: fsub            d2, d3, d1
    // 0x7bdc3c: r0 = inline_Allocate_Double()
    //     0x7bdc3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7bdc40: add             x0, x0, #0x10
    //     0x7bdc44: cmp             x1, x0
    //     0x7bdc48: b.ls            #0x7bdd70
    //     0x7bdc4c: str             x0, [THR, #0x60]  ; THR::top
    //     0x7bdc50: sub             x0, x0, #0xf
    //     0x7bdc54: mov             x1, #0xd108
    //     0x7bdc58: movk            x1, #3, lsl #16
    //     0x7bdc5c: stur            x1, [x0, #-1]
    // 0x7bdc60: StoreField: r0->field_7 = d0
    //     0x7bdc60: stur            d0, [x0, #7]
    // 0x7bdc64: r1 = inline_Allocate_Double()
    //     0x7bdc64: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x7bdc68: add             x1, x1, #0x10
    //     0x7bdc6c: cmp             x3, x1
    //     0x7bdc70: b.ls            #0x7bdd88
    //     0x7bdc74: str             x1, [THR, #0x60]  ; THR::top
    //     0x7bdc78: sub             x1, x1, #0xf
    //     0x7bdc7c: mov             x3, #0xd108
    //     0x7bdc80: movk            x3, #3, lsl #16
    //     0x7bdc84: stur            x3, [x1, #-1]
    // 0x7bdc88: StoreField: r1->field_7 = d2
    //     0x7bdc88: stur            d2, [x1, #7]
    // 0x7bdc8c: stp             x2, x0, [SP, #-0x10]!
    // 0x7bdc90: SaveReg r1
    //     0x7bdc90: str             x1, [SP, #-8]!
    // 0x7bdc94: r0 = lerpDouble()
    //     0x7bdc94: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x7bdc98: add             SP, SP, #0x18
    // 0x7bdc9c: cmp             w0, NULL
    // 0x7bdca0: b.eq            #0x7bdda4
    // 0x7bdca4: LoadField: d0 = r0->field_7
    //     0x7bdca4: ldur            d0, [x0, #7]
    // 0x7bdca8: ldr             x0, [fp, #0x10]
    // 0x7bdcac: LoadField: r1 = r0->field_13
    //     0x7bdcac: ldur            w1, [x0, #0x13]
    // 0x7bdcb0: DecompressPointer r1
    //     0x7bdcb0: add             x1, x1, HEAP, lsl #32
    // 0x7bdcb4: cmp             w1, NULL
    // 0x7bdcb8: b.eq            #0x7bdda8
    // 0x7bdcbc: SaveReg r1
    //     0x7bdcbc: str             x1, [SP, #-8]!
    // 0x7bdcc0: SaveReg d0
    //     0x7bdcc0: str             d0, [SP, #-8]!
    // 0x7bdcc4: r0 = jumpTo()
    //     0x7bdcc4: bl              #0x59dbf4  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::jumpTo
    // 0x7bdcc8: add             SP, SP, #0x10
    // 0x7bdccc: r0 = Null
    //     0x7bdccc: mov             x0, NULL
    // 0x7bdcd0: LeaveFrame
    //     0x7bdcd0: mov             SP, fp
    //     0x7bdcd4: ldp             fp, lr, [SP], #0x10
    // 0x7bdcd8: ret
    //     0x7bdcd8: ret             
    // 0x7bdcdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bdcdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bdce0: b               #0x7bd948
    // 0x7bdce4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdce4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdce8: SaveReg d0
    //     0x7bdce8: str             q0, [SP, #-0x10]!
    // 0x7bdcec: r0 = AllocateDouble()
    //     0x7bdcec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bdcf0: RestoreReg d0
    //     0x7bdcf0: ldr             q0, [SP], #0x10
    // 0x7bdcf4: b               #0x7bd9a4
    // 0x7bdcf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdcf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdcfc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bdcfc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bdd00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdd00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdd04: SaveReg d0
    //     0x7bdd04: str             q0, [SP, #-0x10]!
    // 0x7bdd08: r0 = AllocateDouble()
    //     0x7bdd08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bdd0c: RestoreReg d0
    //     0x7bdd0c: ldr             q0, [SP], #0x10
    // 0x7bdd10: b               #0x7bda7c
    // 0x7bdd14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdd14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdd18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdd18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdd1c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bdd1c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7bdd20: r9 = _value
    //     0x7bdd20: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x7bdd24: ldr             x9, [x9, #0xbb0]
    // 0x7bdd28: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7bdd28: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7bdd2c: stp             q0, q2, [SP, #-0x20]!
    // 0x7bdd30: stp             x0, x1, [SP, #-0x10]!
    // 0x7bdd34: r0 = AllocateDouble()
    //     0x7bdd34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bdd38: mov             x2, x0
    // 0x7bdd3c: ldp             x0, x1, [SP], #0x10
    // 0x7bdd40: ldp             q0, q2, [SP], #0x20
    // 0x7bdd44: b               #0x7bdbe0
    // 0x7bdd48: SaveReg d2
    //     0x7bdd48: str             q2, [SP, #-0x10]!
    // 0x7bdd4c: stp             x1, x2, [SP, #-0x10]!
    // 0x7bdd50: SaveReg r0
    //     0x7bdd50: str             x0, [SP, #-8]!
    // 0x7bdd54: r0 = AllocateDouble()
    //     0x7bdd54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bdd58: mov             x3, x0
    // 0x7bdd5c: RestoreReg r0
    //     0x7bdd5c: ldr             x0, [SP], #8
    // 0x7bdd60: ldp             x1, x2, [SP], #0x10
    // 0x7bdd64: RestoreReg d2
    //     0x7bdd64: ldr             q2, [SP], #0x10
    // 0x7bdd68: b               #0x7bdc08
    // 0x7bdd6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdd6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdd70: stp             q0, q2, [SP, #-0x20]!
    // 0x7bdd74: SaveReg r2
    //     0x7bdd74: str             x2, [SP, #-8]!
    // 0x7bdd78: r0 = AllocateDouble()
    //     0x7bdd78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bdd7c: RestoreReg r2
    //     0x7bdd7c: ldr             x2, [SP], #8
    // 0x7bdd80: ldp             q0, q2, [SP], #0x20
    // 0x7bdd84: b               #0x7bdc60
    // 0x7bdd88: SaveReg d2
    //     0x7bdd88: str             q2, [SP, #-0x10]!
    // 0x7bdd8c: stp             x0, x2, [SP, #-0x10]!
    // 0x7bdd90: r0 = AllocateDouble()
    //     0x7bdd90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7bdd94: mov             x1, x0
    // 0x7bdd98: ldp             x0, x2, [SP], #0x10
    // 0x7bdd9c: RestoreReg d2
    //     0x7bdd9c: ldr             q2, [SP], #0x10
    // 0x7bdda0: b               #0x7bdc88
    // 0x7bdda4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bdda4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bdda8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7bdda8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  get _ maxTabIndex(/* No info */) {
    // ** addr: 0x7bddac, size: 0x4c
    // 0x7bddac: EnterFrame
    //     0x7bddac: stp             fp, lr, [SP, #-0x10]!
    //     0x7bddb0: mov             fp, SP
    // 0x7bddb4: CheckStackOverflow
    //     0x7bddb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bddb8: cmp             SP, x16
    //     0x7bddbc: b.ls            #0x7bddec
    // 0x7bddc0: ldr             x0, [fp, #0x10]
    // 0x7bddc4: LoadField: r1 = r0->field_1b
    //     0x7bddc4: ldur            w1, [x0, #0x1b]
    // 0x7bddc8: DecompressPointer r1
    //     0x7bddc8: add             x1, x1, HEAP, lsl #32
    // 0x7bddcc: cmp             w1, NULL
    // 0x7bddd0: b.eq            #0x7bddf4
    // 0x7bddd4: SaveReg r1
    //     0x7bddd4: str             x1, [SP, #-8]!
    // 0x7bddd8: r0 = maxTabIndex()
    //     0x7bddd8: bl              #0x7bddf8  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::maxTabIndex
    // 0x7bdddc: add             SP, SP, #8
    // 0x7bdde0: LeaveFrame
    //     0x7bdde0: mov             SP, fp
    //     0x7bdde4: ldp             fp, lr, [SP], #0x10
    // 0x7bdde8: ret
    //     0x7bdde8: ret             
    // 0x7bddec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bddec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bddf0: b               #0x7bddc0
    // 0x7bddf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bddf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8689ec, size: 0x135c
    // 0x8689ec: EnterFrame
    //     0x8689ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8689f0: mov             fp, SP
    // 0x8689f4: AllocStack(0x78)
    //     0x8689f4: sub             SP, SP, #0x78
    // 0x8689f8: CheckStackOverflow
    //     0x8689f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8689fc: cmp             SP, x16
    //     0x868a00: b.ls            #0x869ca4
    // 0x868a04: r1 = 3
    //     0x868a04: mov             x1, #3
    // 0x868a08: r0 = AllocateContext()
    //     0x868a08: bl              #0xd68aa4  ; AllocateContextStub
    // 0x868a0c: mov             x1, x0
    // 0x868a10: ldr             x0, [fp, #0x18]
    // 0x868a14: stur            x1, [fp, #-8]
    // 0x868a18: StoreField: r1->field_f = r0
    //     0x868a18: stur            w0, [x1, #0xf]
    // 0x868a1c: ldr             x16, [fp, #0x10]
    // 0x868a20: SaveReg r16
    //     0x868a20: str             x16, [SP, #-8]!
    // 0x868a24: r0 = of()
    //     0x868a24: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x868a28: add             SP, SP, #8
    // 0x868a2c: ldr             x0, [fp, #0x18]
    // 0x868a30: LoadField: r1 = r0->field_17
    //     0x868a30: ldur            w1, [x0, #0x17]
    // 0x868a34: DecompressPointer r1
    //     0x868a34: add             x1, x1, HEAP, lsl #32
    // 0x868a38: cmp             w1, NULL
    // 0x868a3c: b.eq            #0x869cac
    // 0x868a40: LoadField: r2 = r1->field_2b
    //     0x868a40: ldur            x2, [x1, #0x2b]
    // 0x868a44: lsl             x1, x2, #1
    // 0x868a48: cbnz            w1, #0x868a90
    // 0x868a4c: LoadField: r1 = r0->field_b
    //     0x868a4c: ldur            w1, [x0, #0xb]
    // 0x868a50: DecompressPointer r1
    //     0x868a50: add             x1, x1, HEAP, lsl #32
    // 0x868a54: cmp             w1, NULL
    // 0x868a58: b.eq            #0x869cb0
    // 0x868a5c: r0 = Container()
    //     0x868a5c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x868a60: stur            x0, [fp, #-0x10]
    // 0x868a64: r16 = 48.000000
    //     0x868a64: add             x16, PP, #0x26, lsl #12  ; [pp+0x268e8] 48
    //     0x868a68: ldr             x16, [x16, #0x8e8]
    // 0x868a6c: stp             x16, x0, [SP, #-0x10]!
    // 0x868a70: r4 = const [0, 0x2, 0x2, 0x1, height, 0x1, null]
    //     0x868a70: add             x4, PP, #0x21, lsl #12  ; [pp+0x21620] List(7) [0, 0x2, 0x2, 0x1, "height", 0x1, Null]
    //     0x868a74: ldr             x4, [x4, #0x620]
    // 0x868a78: r0 = Container()
    //     0x868a78: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x868a7c: add             SP, SP, #0x10
    // 0x868a80: ldur            x0, [fp, #-0x10]
    // 0x868a84: LeaveFrame
    //     0x868a84: mov             SP, fp
    //     0x868a88: ldp             fp, lr, [SP], #0x10
    // 0x868a8c: ret
    //     0x868a8c: ret             
    // 0x868a90: ldur            x2, [fp, #-8]
    // 0x868a94: ldr             x16, [fp, #0x10]
    // 0x868a98: SaveReg r16
    //     0x868a98: str             x16, [SP, #-8]!
    // 0x868a9c: r0 = of()
    //     0x868a9c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x868aa0: add             SP, SP, #8
    // 0x868aa4: stur            x0, [fp, #-0x10]
    // 0x868aa8: ldr             x16, [fp, #0x10]
    // 0x868aac: SaveReg r16
    //     0x868aac: str             x16, [SP, #-8]!
    // 0x868ab0: r0 = of()
    //     0x868ab0: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0x868ab4: add             SP, SP, #8
    // 0x868ab8: ldur            x2, [fp, #-8]
    // 0x868abc: StoreField: r2->field_13 = r0
    //     0x868abc: stur            w0, [x2, #0x13]
    //     0x868ac0: ldurb           w16, [x2, #-1]
    //     0x868ac4: ldurb           w17, [x0, #-1]
    //     0x868ac8: and             x16, x17, x16, lsr #2
    //     0x868acc: tst             x16, HEAP, lsr #32
    //     0x868ad0: b.eq            #0x868ad8
    //     0x868ad4: bl              #0xd6828c
    // 0x868ad8: ldur            x0, [fp, #-0x10]
    // 0x868adc: LoadField: r1 = r0->field_2b
    //     0x868adc: ldur            w1, [x0, #0x2b]
    // 0x868ae0: DecompressPointer r1
    //     0x868ae0: add             x1, x1, HEAP, lsl #32
    // 0x868ae4: tbnz            w1, #4, #0x868b1c
    // 0x868ae8: ldr             x0, [fp, #0x10]
    // 0x868aec: r0 = _TabsDefaultsM3()
    //     0x868aec: bl              #0x7bcf38  ; Allocate_TabsDefaultsM3Stub -> _TabsDefaultsM3 (size=0x44)
    // 0x868af0: mov             x1, x0
    // 0x868af4: r0 = Sentinel
    //     0x868af4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x868af8: StoreField: r1->field_3b = r0
    //     0x868af8: stur            w0, [x1, #0x3b]
    // 0x868afc: StoreField: r1->field_3f = r0
    //     0x868afc: stur            w0, [x1, #0x3f]
    // 0x868b00: ldr             x2, [fp, #0x10]
    // 0x868b04: StoreField: r1->field_37 = r2
    //     0x868b04: stur            w2, [x1, #0x37]
    // 0x868b08: r2 = Instance_TabBarIndicatorSize
    //     0x868b08: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0x868b0c: ldr             x2, [x2, #0xbe0]
    // 0x868b10: StoreField: r1->field_f = r2
    //     0x868b10: stur            w2, [x1, #0xf]
    // 0x868b14: mov             x0, x1
    // 0x868b18: b               #0x868b44
    // 0x868b1c: ldr             x2, [fp, #0x10]
    // 0x868b20: r0 = Sentinel
    //     0x868b20: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x868b24: r0 = _TabsDefaultsM2()
    //     0x868b24: bl              #0x7bcf2c  ; Allocate_TabsDefaultsM2Stub -> _TabsDefaultsM2 (size=0x3c)
    // 0x868b28: mov             x1, x0
    // 0x868b2c: ldr             x0, [fp, #0x10]
    // 0x868b30: StoreField: r1->field_37 = r0
    //     0x868b30: stur            w0, [x1, #0x37]
    // 0x868b34: r0 = Instance_TabBarIndicatorSize
    //     0x868b34: add             x0, PP, #0x37, lsl #12  ; [pp+0x37ea0] Obj!TabBarIndicatorSize@b65171
    //     0x868b38: ldr             x0, [x0, #0xea0]
    // 0x868b3c: StoreField: r1->field_f = r0
    //     0x868b3c: stur            w0, [x1, #0xf]
    // 0x868b40: mov             x0, x1
    // 0x868b44: ldr             x1, [fp, #0x18]
    // 0x868b48: ldur            x2, [fp, #-8]
    // 0x868b4c: StoreField: r2->field_17 = r0
    //     0x868b4c: stur            w0, [x2, #0x17]
    //     0x868b50: ldurb           w16, [x2, #-1]
    //     0x868b54: ldurb           w17, [x0, #-1]
    //     0x868b58: and             x16, x17, x16, lsr #2
    //     0x868b5c: tst             x16, HEAP, lsr #32
    //     0x868b60: b.eq            #0x868b68
    //     0x868b64: bl              #0xd6828c
    // 0x868b68: LoadField: r0 = r1->field_b
    //     0x868b68: ldur            w0, [x1, #0xb]
    // 0x868b6c: DecompressPointer r0
    //     0x868b6c: add             x0, x0, HEAP, lsl #32
    // 0x868b70: cmp             w0, NULL
    // 0x868b74: b.eq            #0x869cb4
    // 0x868b78: LoadField: r3 = r0->field_b
    //     0x868b78: ldur            w3, [x0, #0xb]
    // 0x868b7c: DecompressPointer r3
    //     0x868b7c: add             x3, x3, HEAP, lsl #32
    // 0x868b80: r0 = LoadClassIdInstr(r3)
    //     0x868b80: ldur            x0, [x3, #-1]
    //     0x868b84: ubfx            x0, x0, #0xc, #0x14
    // 0x868b88: SaveReg r3
    //     0x868b88: str             x3, [SP, #-8]!
    // 0x868b8c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x868b8c: mov             x17, #0xb8ea
    //     0x868b90: add             lr, x0, x17
    //     0x868b94: ldr             lr, [x21, lr, lsl #3]
    //     0x868b98: blr             lr
    // 0x868b9c: add             SP, SP, #8
    // 0x868ba0: ldur            x2, [fp, #-8]
    // 0x868ba4: r1 = Function '<anonymous closure>':.
    //     0x868ba4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ea8] AnonymousClosure: (0x86a0ac), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0x8689ec)
    //     0x868ba8: ldr             x1, [x1, #0xea8]
    // 0x868bac: stur            x0, [fp, #-0x10]
    // 0x868bb0: r0 = AllocateClosure()
    //     0x868bb0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x868bb4: mov             x1, x0
    // 0x868bb8: ldur            x0, [fp, #-0x10]
    // 0x868bbc: stur            x1, [fp, #-0x18]
    // 0x868bc0: r2 = LoadInt32Instr(r0)
    //     0x868bc0: sbfx            x2, x0, #1, #0x1f
    // 0x868bc4: r16 = <Widget>
    //     0x868bc4: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x868bc8: ldr             x16, [x16, #0xea8]
    // 0x868bcc: stp             x2, x16, [SP, #-0x10]!
    // 0x868bd0: r0 = _GrowableList()
    //     0x868bd0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x868bd4: add             SP, SP, #0x10
    // 0x868bd8: mov             x2, x0
    // 0x868bdc: stur            x2, [fp, #-0x10]
    // 0x868be0: r3 = 0
    //     0x868be0: mov             x3, #0
    // 0x868be4: stur            x3, [fp, #-0x20]
    // 0x868be8: CheckStackOverflow
    //     0x868be8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x868bec: cmp             SP, x16
    //     0x868bf0: b.ls            #0x869cb8
    // 0x868bf4: LoadField: r0 = r2->field_b
    //     0x868bf4: ldur            w0, [x2, #0xb]
    // 0x868bf8: DecompressPointer r0
    //     0x868bf8: add             x0, x0, HEAP, lsl #32
    // 0x868bfc: r4 = LoadInt32Instr(r0)
    //     0x868bfc: sbfx            x4, x0, #1, #0x1f
    // 0x868c00: stur            x4, [fp, #-0x30]
    // 0x868c04: cmp             x3, x4
    // 0x868c08: b.ge            #0x868ce0
    // 0x868c0c: r0 = BoxInt64Instr(r3)
    //     0x868c0c: sbfiz           x0, x3, #1, #0x1f
    //     0x868c10: cmp             x3, x0, asr #1
    //     0x868c14: b.eq            #0x868c20
    //     0x868c18: bl              #0xd69bb8
    //     0x868c1c: stur            x3, [x0, #7]
    // 0x868c20: ldur            x16, [fp, #-0x18]
    // 0x868c24: stp             x0, x16, [SP, #-0x10]!
    // 0x868c28: ldur            x0, [fp, #-0x18]
    // 0x868c2c: ClosureCall
    //     0x868c2c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x868c30: ldur            x2, [x0, #0x1f]
    //     0x868c34: blr             x2
    // 0x868c38: add             SP, SP, #0x10
    // 0x868c3c: mov             x3, x0
    // 0x868c40: r2 = Null
    //     0x868c40: mov             x2, NULL
    // 0x868c44: r1 = Null
    //     0x868c44: mov             x1, NULL
    // 0x868c48: stur            x3, [fp, #-0x28]
    // 0x868c4c: r4 = 59
    //     0x868c4c: mov             x4, #0x3b
    // 0x868c50: branchIfSmi(r0, 0x868c5c)
    //     0x868c50: tbz             w0, #0, #0x868c5c
    // 0x868c54: r4 = LoadClassIdInstr(r0)
    //     0x868c54: ldur            x4, [x0, #-1]
    //     0x868c58: ubfx            x4, x4, #0xc, #0x14
    // 0x868c5c: sub             x4, x4, #0xd99
    // 0x868c60: cmp             x4, #0x2ea
    // 0x868c64: b.ls            #0x868c7c
    // 0x868c68: r8 = Widget
    //     0x868c68: add             x8, PP, #0x30, lsl #12  ; [pp+0x304e0] Type: Widget
    //     0x868c6c: ldr             x8, [x8, #0x4e0]
    // 0x868c70: r3 = Null
    //     0x868c70: add             x3, PP, #0x37, lsl #12  ; [pp+0x37eb0] Null
    //     0x868c74: ldr             x3, [x3, #0xeb0]
    // 0x868c78: r0 = Widget()
    //     0x868c78: bl              #0x507a18  ; IsType_Widget_Stub
    // 0x868c7c: ldur            x2, [fp, #-0x10]
    // 0x868c80: LoadField: r0 = r2->field_b
    //     0x868c80: ldur            w0, [x2, #0xb]
    // 0x868c84: DecompressPointer r0
    //     0x868c84: add             x0, x0, HEAP, lsl #32
    // 0x868c88: r1 = LoadInt32Instr(r0)
    //     0x868c88: sbfx            x1, x0, #1, #0x1f
    // 0x868c8c: mov             x0, x1
    // 0x868c90: ldur            x1, [fp, #-0x20]
    // 0x868c94: cmp             x1, x0
    // 0x868c98: b.hs            #0x869cc0
    // 0x868c9c: LoadField: r1 = r2->field_f
    //     0x868c9c: ldur            w1, [x2, #0xf]
    // 0x868ca0: DecompressPointer r1
    //     0x868ca0: add             x1, x1, HEAP, lsl #32
    // 0x868ca4: ldur            x0, [fp, #-0x28]
    // 0x868ca8: ldur            x3, [fp, #-0x20]
    // 0x868cac: ArrayStore: r1[r3] = r0  ; List_4
    //     0x868cac: add             x25, x1, x3, lsl #2
    //     0x868cb0: add             x25, x25, #0xf
    //     0x868cb4: str             w0, [x25]
    //     0x868cb8: tbz             w0, #0, #0x868cd4
    //     0x868cbc: ldurb           w16, [x1, #-1]
    //     0x868cc0: ldurb           w17, [x0, #-1]
    //     0x868cc4: and             x16, x17, x16, lsr #2
    //     0x868cc8: tst             x16, HEAP, lsr #32
    //     0x868ccc: b.eq            #0x868cd4
    //     0x868cd0: bl              #0xd67e5c
    // 0x868cd4: add             x0, x3, #1
    // 0x868cd8: mov             x3, x0
    // 0x868cdc: b               #0x868be4
    // 0x868ce0: ldr             x0, [fp, #0x18]
    // 0x868ce4: LoadField: r3 = r0->field_17
    //     0x868ce4: ldur            w3, [x0, #0x17]
    // 0x868ce8: DecompressPointer r3
    //     0x868ce8: add             x3, x3, HEAP, lsl #32
    // 0x868cec: stur            x3, [fp, #-0x18]
    // 0x868cf0: cmp             w3, NULL
    // 0x868cf4: b.eq            #0x869330
    // 0x868cf8: LoadField: r5 = r3->field_3b
    //     0x868cf8: ldur            x5, [x3, #0x3b]
    // 0x868cfc: stur            x5, [fp, #-0x20]
    // 0x868d00: LoadField: r1 = r3->field_43
    //     0x868d00: ldur            x1, [x3, #0x43]
    // 0x868d04: cbz             x1, #0x868e7c
    // 0x868d08: r1 = <double>
    //     0x868d08: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x868d0c: r0 = _ChangeAnimation()
    //     0x868d0c: bl              #0x869dec  ; Allocate_ChangeAnimationStub -> _ChangeAnimation (size=0x10)
    // 0x868d10: mov             x2, x0
    // 0x868d14: ldur            x0, [fp, #-0x18]
    // 0x868d18: stur            x2, [fp, #-0x28]
    // 0x868d1c: StoreField: r2->field_b = r0
    //     0x868d1c: stur            w0, [x2, #0xb]
    // 0x868d20: ldr             x3, [fp, #0x18]
    // 0x868d24: LoadField: r0 = r3->field_1f
    //     0x868d24: ldur            w0, [x3, #0x1f]
    // 0x868d28: DecompressPointer r0
    //     0x868d28: add             x0, x0, HEAP, lsl #32
    // 0x868d2c: cmp             w0, NULL
    // 0x868d30: b.eq            #0x869cc4
    // 0x868d34: r4 = LoadInt32Instr(r0)
    //     0x868d34: sbfx            x4, x0, #1, #0x1f
    //     0x868d38: tbz             w0, #0, #0x868d40
    //     0x868d3c: ldur            x4, [x0, #7]
    // 0x868d40: ldur            x0, [fp, #-0x30]
    // 0x868d44: mov             x1, x4
    // 0x868d48: stur            x4, [fp, #-0x38]
    // 0x868d4c: cmp             x1, x0
    // 0x868d50: b.hs            #0x869cc8
    // 0x868d54: ldur            x0, [fp, #-0x10]
    // 0x868d58: LoadField: r1 = r0->field_f
    //     0x868d58: ldur            w1, [x0, #0xf]
    // 0x868d5c: DecompressPointer r1
    //     0x868d5c: add             x1, x1, HEAP, lsl #32
    // 0x868d60: ArrayLoad: r5 = r1[r4]  ; Unknown_4
    //     0x868d60: add             x16, x1, x4, lsl #2
    //     0x868d64: ldur            w5, [x16, #0xf]
    // 0x868d68: DecompressPointer r5
    //     0x868d68: add             x5, x5, HEAP, lsl #32
    // 0x868d6c: stp             x5, x3, [SP, #-0x10]!
    // 0x868d70: r16 = true
    //     0x868d70: add             x16, NULL, #0x20  ; true
    // 0x868d74: stp             x2, x16, [SP, #-0x10]!
    // 0x868d78: r0 = _buildStyledTab()
    //     0x868d78: bl              #0x869d78  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0x868d7c: add             SP, SP, #0x20
    // 0x868d80: mov             x3, x0
    // 0x868d84: ldur            x2, [fp, #-0x10]
    // 0x868d88: LoadField: r0 = r2->field_b
    //     0x868d88: ldur            w0, [x2, #0xb]
    // 0x868d8c: DecompressPointer r0
    //     0x868d8c: add             x0, x0, HEAP, lsl #32
    // 0x868d90: r4 = LoadInt32Instr(r0)
    //     0x868d90: sbfx            x4, x0, #1, #0x1f
    // 0x868d94: mov             x0, x4
    // 0x868d98: ldur            x1, [fp, #-0x38]
    // 0x868d9c: cmp             x1, x0
    // 0x868da0: b.hs            #0x869ccc
    // 0x868da4: LoadField: r5 = r2->field_f
    //     0x868da4: ldur            w5, [x2, #0xf]
    // 0x868da8: DecompressPointer r5
    //     0x868da8: add             x5, x5, HEAP, lsl #32
    // 0x868dac: mov             x1, x5
    // 0x868db0: mov             x0, x3
    // 0x868db4: ldur            x3, [fp, #-0x38]
    // 0x868db8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x868db8: add             x25, x1, x3, lsl #2
    //     0x868dbc: add             x25, x25, #0xf
    //     0x868dc0: str             w0, [x25]
    //     0x868dc4: tbz             w0, #0, #0x868de0
    //     0x868dc8: ldurb           w16, [x1, #-1]
    //     0x868dcc: ldurb           w17, [x0, #-1]
    //     0x868dd0: and             x16, x17, x16, lsr #2
    //     0x868dd4: tst             x16, HEAP, lsr #32
    //     0x868dd8: b.eq            #0x868de0
    //     0x868ddc: bl              #0xd67e5c
    // 0x868de0: mov             x0, x4
    // 0x868de4: ldur            x1, [fp, #-0x20]
    // 0x868de8: cmp             x1, x0
    // 0x868dec: b.hs            #0x869cd0
    // 0x868df0: ldur            x1, [fp, #-0x20]
    // 0x868df4: ArrayLoad: r0 = r5[r1]  ; Unknown_4
    //     0x868df4: add             x16, x5, x1, lsl #2
    //     0x868df8: ldur            w0, [x16, #0xf]
    // 0x868dfc: DecompressPointer r0
    //     0x868dfc: add             x0, x0, HEAP, lsl #32
    // 0x868e00: ldr             x16, [fp, #0x18]
    // 0x868e04: stp             x0, x16, [SP, #-0x10]!
    // 0x868e08: r16 = false
    //     0x868e08: add             x16, NULL, #0x30  ; false
    // 0x868e0c: ldur            lr, [fp, #-0x28]
    // 0x868e10: stp             lr, x16, [SP, #-0x10]!
    // 0x868e14: r0 = _buildStyledTab()
    //     0x868e14: bl              #0x869d78  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0x868e18: add             SP, SP, #0x20
    // 0x868e1c: mov             x3, x0
    // 0x868e20: ldur            x2, [fp, #-0x10]
    // 0x868e24: LoadField: r0 = r2->field_b
    //     0x868e24: ldur            w0, [x2, #0xb]
    // 0x868e28: DecompressPointer r0
    //     0x868e28: add             x0, x0, HEAP, lsl #32
    // 0x868e2c: r1 = LoadInt32Instr(r0)
    //     0x868e2c: sbfx            x1, x0, #1, #0x1f
    // 0x868e30: mov             x0, x1
    // 0x868e34: ldur            x1, [fp, #-0x20]
    // 0x868e38: cmp             x1, x0
    // 0x868e3c: b.hs            #0x869cd4
    // 0x868e40: LoadField: r1 = r2->field_f
    //     0x868e40: ldur            w1, [x2, #0xf]
    // 0x868e44: DecompressPointer r1
    //     0x868e44: add             x1, x1, HEAP, lsl #32
    // 0x868e48: mov             x0, x3
    // 0x868e4c: ldur            x3, [fp, #-0x20]
    // 0x868e50: ArrayStore: r1[r3] = r0  ; List_4
    //     0x868e50: add             x25, x1, x3, lsl #2
    //     0x868e54: add             x25, x25, #0xf
    //     0x868e58: str             w0, [x25]
    //     0x868e5c: tbz             w0, #0, #0x868e78
    //     0x868e60: ldurb           w16, [x1, #-1]
    //     0x868e64: ldurb           w17, [x0, #-1]
    //     0x868e68: and             x16, x17, x16, lsr #2
    //     0x868e6c: tst             x16, HEAP, lsr #32
    //     0x868e70: b.eq            #0x868e78
    //     0x868e74: bl              #0xd67e5c
    // 0x868e78: b               #0x869330
    // 0x868e7c: mov             x16, x3
    // 0x868e80: mov             x3, x0
    // 0x868e84: mov             x0, x16
    // 0x868e88: LoadField: r4 = r3->field_1f
    //     0x868e88: ldur            w4, [x3, #0x1f]
    // 0x868e8c: DecompressPointer r4
    //     0x868e8c: add             x4, x4, HEAP, lsl #32
    // 0x868e90: stur            x4, [fp, #-0x28]
    // 0x868e94: cmp             w4, NULL
    // 0x868e98: b.eq            #0x869cd8
    // 0x868e9c: r1 = <double>
    //     0x868e9c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x868ea0: r0 = _DragAnimation()
    //     0x868ea0: bl              #0x869d6c  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0x868ea4: mov             x2, x0
    // 0x868ea8: ldur            x0, [fp, #-0x18]
    // 0x868eac: StoreField: r2->field_b = r0
    //     0x868eac: stur            w0, [x2, #0xb]
    // 0x868eb0: ldur            x0, [fp, #-0x28]
    // 0x868eb4: r3 = LoadInt32Instr(r0)
    //     0x868eb4: sbfx            x3, x0, #1, #0x1f
    //     0x868eb8: tbz             w0, #0, #0x868ec0
    //     0x868ebc: ldur            x3, [x0, #7]
    // 0x868ec0: stur            x3, [fp, #-0x20]
    // 0x868ec4: StoreField: r2->field_f = r3
    //     0x868ec4: stur            x3, [x2, #0xf]
    // 0x868ec8: ldur            x0, [fp, #-0x30]
    // 0x868ecc: mov             x1, x3
    // 0x868ed0: cmp             x1, x0
    // 0x868ed4: b.hs            #0x869cdc
    // 0x868ed8: ldur            x0, [fp, #-0x10]
    // 0x868edc: LoadField: r1 = r0->field_f
    //     0x868edc: ldur            w1, [x0, #0xf]
    // 0x868ee0: DecompressPointer r1
    //     0x868ee0: add             x1, x1, HEAP, lsl #32
    // 0x868ee4: ArrayLoad: r4 = r1[r3]  ; Unknown_4
    //     0x868ee4: add             x16, x1, x3, lsl #2
    //     0x868ee8: ldur            w4, [x16, #0xf]
    // 0x868eec: DecompressPointer r4
    //     0x868eec: add             x4, x4, HEAP, lsl #32
    // 0x868ef0: ldr             x16, [fp, #0x18]
    // 0x868ef4: stp             x4, x16, [SP, #-0x10]!
    // 0x868ef8: r16 = true
    //     0x868ef8: add             x16, NULL, #0x20  ; true
    // 0x868efc: stp             x2, x16, [SP, #-0x10]!
    // 0x868f00: r0 = _buildStyledTab()
    //     0x868f00: bl              #0x869d78  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0x868f04: add             SP, SP, #0x20
    // 0x868f08: mov             x3, x0
    // 0x868f0c: ldur            x2, [fp, #-0x10]
    // 0x868f10: LoadField: r0 = r2->field_b
    //     0x868f10: ldur            w0, [x2, #0xb]
    // 0x868f14: DecompressPointer r0
    //     0x868f14: add             x0, x0, HEAP, lsl #32
    // 0x868f18: r1 = LoadInt32Instr(r0)
    //     0x868f18: sbfx            x1, x0, #1, #0x1f
    // 0x868f1c: mov             x0, x1
    // 0x868f20: ldur            x1, [fp, #-0x20]
    // 0x868f24: cmp             x1, x0
    // 0x868f28: b.hs            #0x869ce0
    // 0x868f2c: LoadField: r1 = r2->field_f
    //     0x868f2c: ldur            w1, [x2, #0xf]
    // 0x868f30: DecompressPointer r1
    //     0x868f30: add             x1, x1, HEAP, lsl #32
    // 0x868f34: mov             x0, x3
    // 0x868f38: ldur            x3, [fp, #-0x20]
    // 0x868f3c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x868f3c: add             x25, x1, x3, lsl #2
    //     0x868f40: add             x25, x25, #0xf
    //     0x868f44: str             w0, [x25]
    //     0x868f48: tbz             w0, #0, #0x868f64
    //     0x868f4c: ldurb           w16, [x1, #-1]
    //     0x868f50: ldurb           w17, [x0, #-1]
    //     0x868f54: and             x16, x17, x16, lsr #2
    //     0x868f58: tst             x16, HEAP, lsr #32
    //     0x868f5c: b.eq            #0x868f64
    //     0x868f60: bl              #0xd67e5c
    // 0x868f64: ldr             x0, [fp, #0x18]
    // 0x868f68: LoadField: r1 = r0->field_1f
    //     0x868f68: ldur            w1, [x0, #0x1f]
    // 0x868f6c: DecompressPointer r1
    //     0x868f6c: add             x1, x1, HEAP, lsl #32
    // 0x868f70: cmp             w1, NULL
    // 0x868f74: b.eq            #0x869ce4
    // 0x868f78: r3 = LoadInt32Instr(r1)
    //     0x868f78: sbfx            x3, x1, #1, #0x1f
    //     0x868f7c: tbz             w1, #0, #0x868f84
    //     0x868f80: ldur            x3, [x1, #7]
    // 0x868f84: cmp             x3, #0
    // 0x868f88: b.le            #0x869110
    // 0x868f8c: sub             x4, x3, #1
    // 0x868f90: stur            x4, [fp, #-0x20]
    // 0x868f94: LoadField: r3 = r0->field_17
    //     0x868f94: ldur            w3, [x0, #0x17]
    // 0x868f98: DecompressPointer r3
    //     0x868f98: add             x3, x3, HEAP, lsl #32
    // 0x868f9c: stur            x3, [fp, #-0x18]
    // 0x868fa0: cmp             w3, NULL
    // 0x868fa4: b.eq            #0x869ce8
    // 0x868fa8: r1 = <double>
    //     0x868fa8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x868fac: r0 = _DragAnimation()
    //     0x868fac: bl              #0x869d6c  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0x868fb0: mov             x2, x0
    // 0x868fb4: ldur            x0, [fp, #-0x18]
    // 0x868fb8: stur            x2, [fp, #-0x28]
    // 0x868fbc: StoreField: r2->field_b = r0
    //     0x868fbc: stur            w0, [x2, #0xb]
    // 0x868fc0: ldur            x0, [fp, #-0x20]
    // 0x868fc4: StoreField: r2->field_f = r0
    //     0x868fc4: stur            x0, [x2, #0xf]
    // 0x868fc8: r1 = <double>
    //     0x868fc8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x868fcc: r0 = ReverseAnimation()
    //     0x868fcc: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0x868fd0: mov             x2, x0
    // 0x868fd4: ldur            x0, [fp, #-0x28]
    // 0x868fd8: stur            x2, [fp, #-0x18]
    // 0x868fdc: StoreField: r2->field_17 = r0
    //     0x868fdc: stur            w0, [x2, #0x17]
    // 0x868fe0: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x868fe0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x868fe4: ldr             x1, [x1, #0x3d8]
    // 0x868fe8: r0 = ObserverList()
    //     0x868fe8: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x868fec: mov             x1, x0
    // 0x868ff0: r0 = false
    //     0x868ff0: add             x0, NULL, #0x30  ; false
    // 0x868ff4: stur            x1, [fp, #-0x28]
    // 0x868ff8: StoreField: r1->field_f = r0
    //     0x868ff8: stur            w0, [x1, #0xf]
    // 0x868ffc: r2 = Sentinel
    //     0x868ffc: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x869000: StoreField: r1->field_13 = r2
    //     0x869000: stur            w2, [x1, #0x13]
    // 0x869004: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x869004: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x869008: ldr             x16, [x16, #0x3d8]
    // 0x86900c: stp             xzr, x16, [SP, #-0x10]!
    // 0x869010: r0 = _GrowableList()
    //     0x869010: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x869014: add             SP, SP, #0x10
    // 0x869018: ldur            x1, [fp, #-0x28]
    // 0x86901c: StoreField: r1->field_b = r0
    //     0x86901c: stur            w0, [x1, #0xb]
    //     0x869020: ldurb           w16, [x1, #-1]
    //     0x869024: ldurb           w17, [x0, #-1]
    //     0x869028: and             x16, x17, x16, lsr #2
    //     0x86902c: tst             x16, HEAP, lsr #32
    //     0x869030: b.eq            #0x869038
    //     0x869034: bl              #0xd6826c
    // 0x869038: mov             x0, x1
    // 0x86903c: ldur            x2, [fp, #-0x18]
    // 0x869040: StoreField: r2->field_13 = r0
    //     0x869040: stur            w0, [x2, #0x13]
    //     0x869044: ldurb           w16, [x2, #-1]
    //     0x869048: ldurb           w17, [x0, #-1]
    //     0x86904c: and             x16, x17, x16, lsr #2
    //     0x869050: tst             x16, HEAP, lsr #32
    //     0x869054: b.eq            #0x86905c
    //     0x869058: bl              #0xd6828c
    // 0x86905c: r3 = 0
    //     0x86905c: mov             x3, #0
    // 0x869060: StoreField: r2->field_b = r3
    //     0x869060: stur            x3, [x2, #0xb]
    // 0x869064: ldur            x4, [fp, #-0x10]
    // 0x869068: LoadField: r0 = r4->field_b
    //     0x869068: ldur            w0, [x4, #0xb]
    // 0x86906c: DecompressPointer r0
    //     0x86906c: add             x0, x0, HEAP, lsl #32
    // 0x869070: r1 = LoadInt32Instr(r0)
    //     0x869070: sbfx            x1, x0, #1, #0x1f
    // 0x869074: mov             x0, x1
    // 0x869078: ldur            x1, [fp, #-0x20]
    // 0x86907c: cmp             x1, x0
    // 0x869080: b.hs            #0x869cec
    // 0x869084: LoadField: r0 = r4->field_f
    //     0x869084: ldur            w0, [x4, #0xf]
    // 0x869088: DecompressPointer r0
    //     0x869088: add             x0, x0, HEAP, lsl #32
    // 0x86908c: ldur            x1, [fp, #-0x20]
    // 0x869090: ArrayLoad: r5 = r0[r1]  ; Unknown_4
    //     0x869090: add             x16, x0, x1, lsl #2
    //     0x869094: ldur            w5, [x16, #0xf]
    // 0x869098: DecompressPointer r5
    //     0x869098: add             x5, x5, HEAP, lsl #32
    // 0x86909c: ldr             x16, [fp, #0x18]
    // 0x8690a0: stp             x5, x16, [SP, #-0x10]!
    // 0x8690a4: r16 = false
    //     0x8690a4: add             x16, NULL, #0x30  ; false
    // 0x8690a8: stp             x2, x16, [SP, #-0x10]!
    // 0x8690ac: r0 = _buildStyledTab()
    //     0x8690ac: bl              #0x869d78  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0x8690b0: add             SP, SP, #0x20
    // 0x8690b4: mov             x3, x0
    // 0x8690b8: ldur            x2, [fp, #-0x10]
    // 0x8690bc: LoadField: r0 = r2->field_b
    //     0x8690bc: ldur            w0, [x2, #0xb]
    // 0x8690c0: DecompressPointer r0
    //     0x8690c0: add             x0, x0, HEAP, lsl #32
    // 0x8690c4: r1 = LoadInt32Instr(r0)
    //     0x8690c4: sbfx            x1, x0, #1, #0x1f
    // 0x8690c8: mov             x0, x1
    // 0x8690cc: ldur            x1, [fp, #-0x20]
    // 0x8690d0: cmp             x1, x0
    // 0x8690d4: b.hs            #0x869cf0
    // 0x8690d8: LoadField: r1 = r2->field_f
    //     0x8690d8: ldur            w1, [x2, #0xf]
    // 0x8690dc: DecompressPointer r1
    //     0x8690dc: add             x1, x1, HEAP, lsl #32
    // 0x8690e0: mov             x0, x3
    // 0x8690e4: ldur            x3, [fp, #-0x20]
    // 0x8690e8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8690e8: add             x25, x1, x3, lsl #2
    //     0x8690ec: add             x25, x25, #0xf
    //     0x8690f0: str             w0, [x25]
    //     0x8690f4: tbz             w0, #0, #0x869110
    //     0x8690f8: ldurb           w16, [x1, #-1]
    //     0x8690fc: ldurb           w17, [x0, #-1]
    //     0x869100: and             x16, x17, x16, lsr #2
    //     0x869104: tst             x16, HEAP, lsr #32
    //     0x869108: b.eq            #0x869110
    //     0x86910c: bl              #0xd67e5c
    // 0x869110: ldr             x1, [fp, #0x18]
    // 0x869114: LoadField: r3 = r1->field_1f
    //     0x869114: ldur            w3, [x1, #0x1f]
    // 0x869118: DecompressPointer r3
    //     0x869118: add             x3, x3, HEAP, lsl #32
    // 0x86911c: stur            x3, [fp, #-0x18]
    // 0x869120: cmp             w3, NULL
    // 0x869124: b.eq            #0x869cf4
    // 0x869128: LoadField: r0 = r1->field_b
    //     0x869128: ldur            w0, [x1, #0xb]
    // 0x86912c: DecompressPointer r0
    //     0x86912c: add             x0, x0, HEAP, lsl #32
    // 0x869130: cmp             w0, NULL
    // 0x869134: b.eq            #0x869cf8
    // 0x869138: LoadField: r4 = r0->field_b
    //     0x869138: ldur            w4, [x0, #0xb]
    // 0x86913c: DecompressPointer r4
    //     0x86913c: add             x4, x4, HEAP, lsl #32
    // 0x869140: r0 = LoadClassIdInstr(r4)
    //     0x869140: ldur            x0, [x4, #-1]
    //     0x869144: ubfx            x0, x0, #0xc, #0x14
    // 0x869148: SaveReg r4
    //     0x869148: str             x4, [SP, #-8]!
    // 0x86914c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x86914c: mov             x17, #0xb8ea
    //     0x869150: add             lr, x0, x17
    //     0x869154: ldr             lr, [x21, lr, lsl #3]
    //     0x869158: blr             lr
    // 0x86915c: add             SP, SP, #8
    // 0x869160: r1 = LoadInt32Instr(r0)
    //     0x869160: sbfx            x1, x0, #1, #0x1f
    // 0x869164: sub             x0, x1, #1
    // 0x869168: ldur            x1, [fp, #-0x18]
    // 0x86916c: r2 = LoadInt32Instr(r1)
    //     0x86916c: sbfx            x2, x1, #1, #0x1f
    //     0x869170: tbz             w1, #0, #0x869178
    //     0x869174: ldur            x2, [x1, #7]
    // 0x869178: cmp             x2, x0
    // 0x86917c: b.ge            #0x86932c
    // 0x869180: ldr             x2, [fp, #0x18]
    // 0x869184: ldur            x0, [fp, #-0x10]
    // 0x869188: LoadField: r1 = r2->field_1f
    //     0x869188: ldur            w1, [x2, #0x1f]
    // 0x86918c: DecompressPointer r1
    //     0x86918c: add             x1, x1, HEAP, lsl #32
    // 0x869190: cmp             w1, NULL
    // 0x869194: b.eq            #0x869cfc
    // 0x869198: r3 = LoadInt32Instr(r1)
    //     0x869198: sbfx            x3, x1, #1, #0x1f
    //     0x86919c: tbz             w1, #0, #0x8691a4
    //     0x8691a0: ldur            x3, [x1, #7]
    // 0x8691a4: add             x4, x3, #1
    // 0x8691a8: stur            x4, [fp, #-0x20]
    // 0x8691ac: LoadField: r3 = r2->field_17
    //     0x8691ac: ldur            w3, [x2, #0x17]
    // 0x8691b0: DecompressPointer r3
    //     0x8691b0: add             x3, x3, HEAP, lsl #32
    // 0x8691b4: stur            x3, [fp, #-0x18]
    // 0x8691b8: cmp             w3, NULL
    // 0x8691bc: b.eq            #0x869d00
    // 0x8691c0: r1 = <double>
    //     0x8691c0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8691c4: r0 = _DragAnimation()
    //     0x8691c4: bl              #0x869d6c  ; Allocate_DragAnimationStub -> _DragAnimation (size=0x18)
    // 0x8691c8: mov             x2, x0
    // 0x8691cc: ldur            x0, [fp, #-0x18]
    // 0x8691d0: stur            x2, [fp, #-0x28]
    // 0x8691d4: StoreField: r2->field_b = r0
    //     0x8691d4: stur            w0, [x2, #0xb]
    // 0x8691d8: ldur            x0, [fp, #-0x20]
    // 0x8691dc: StoreField: r2->field_f = r0
    //     0x8691dc: stur            x0, [x2, #0xf]
    // 0x8691e0: r1 = <double>
    //     0x8691e0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8691e4: r0 = ReverseAnimation()
    //     0x8691e4: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0x8691e8: mov             x2, x0
    // 0x8691ec: ldur            x0, [fp, #-0x28]
    // 0x8691f0: stur            x2, [fp, #-0x18]
    // 0x8691f4: StoreField: r2->field_17 = r0
    //     0x8691f4: stur            w0, [x2, #0x17]
    // 0x8691f8: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x8691f8: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x8691fc: ldr             x1, [x1, #0x3d8]
    // 0x869200: r0 = ObserverList()
    //     0x869200: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x869204: mov             x1, x0
    // 0x869208: r0 = false
    //     0x869208: add             x0, NULL, #0x30  ; false
    // 0x86920c: stur            x1, [fp, #-0x28]
    // 0x869210: StoreField: r1->field_f = r0
    //     0x869210: stur            w0, [x1, #0xf]
    // 0x869214: r2 = Sentinel
    //     0x869214: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x869218: StoreField: r1->field_13 = r2
    //     0x869218: stur            w2, [x1, #0x13]
    // 0x86921c: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x86921c: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x869220: ldr             x16, [x16, #0x3d8]
    // 0x869224: stp             xzr, x16, [SP, #-0x10]!
    // 0x869228: r0 = _GrowableList()
    //     0x869228: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x86922c: add             SP, SP, #0x10
    // 0x869230: ldur            x1, [fp, #-0x28]
    // 0x869234: StoreField: r1->field_b = r0
    //     0x869234: stur            w0, [x1, #0xb]
    //     0x869238: ldurb           w16, [x1, #-1]
    //     0x86923c: ldurb           w17, [x0, #-1]
    //     0x869240: and             x16, x17, x16, lsr #2
    //     0x869244: tst             x16, HEAP, lsr #32
    //     0x869248: b.eq            #0x869250
    //     0x86924c: bl              #0xd6826c
    // 0x869250: mov             x0, x1
    // 0x869254: ldur            x2, [fp, #-0x18]
    // 0x869258: StoreField: r2->field_13 = r0
    //     0x869258: stur            w0, [x2, #0x13]
    //     0x86925c: ldurb           w16, [x2, #-1]
    //     0x869260: ldurb           w17, [x0, #-1]
    //     0x869264: and             x16, x17, x16, lsr #2
    //     0x869268: tst             x16, HEAP, lsr #32
    //     0x86926c: b.eq            #0x869274
    //     0x869270: bl              #0xd6828c
    // 0x869274: r0 = 0
    //     0x869274: mov             x0, #0
    // 0x869278: StoreField: r2->field_b = r0
    //     0x869278: stur            x0, [x2, #0xb]
    // 0x86927c: ldur            x3, [fp, #-0x10]
    // 0x869280: LoadField: r0 = r3->field_b
    //     0x869280: ldur            w0, [x3, #0xb]
    // 0x869284: DecompressPointer r0
    //     0x869284: add             x0, x0, HEAP, lsl #32
    // 0x869288: r1 = LoadInt32Instr(r0)
    //     0x869288: sbfx            x1, x0, #1, #0x1f
    // 0x86928c: mov             x0, x1
    // 0x869290: ldur            x1, [fp, #-0x20]
    // 0x869294: cmp             x1, x0
    // 0x869298: b.hs            #0x869d04
    // 0x86929c: LoadField: r0 = r3->field_f
    //     0x86929c: ldur            w0, [x3, #0xf]
    // 0x8692a0: DecompressPointer r0
    //     0x8692a0: add             x0, x0, HEAP, lsl #32
    // 0x8692a4: ldur            x1, [fp, #-0x20]
    // 0x8692a8: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x8692a8: add             x16, x0, x1, lsl #2
    //     0x8692ac: ldur            w4, [x16, #0xf]
    // 0x8692b0: DecompressPointer r4
    //     0x8692b0: add             x4, x4, HEAP, lsl #32
    // 0x8692b4: ldr             x16, [fp, #0x18]
    // 0x8692b8: stp             x4, x16, [SP, #-0x10]!
    // 0x8692bc: r16 = false
    //     0x8692bc: add             x16, NULL, #0x30  ; false
    // 0x8692c0: stp             x2, x16, [SP, #-0x10]!
    // 0x8692c4: r0 = _buildStyledTab()
    //     0x8692c4: bl              #0x869d78  ; [package:flutter/src/material/tabs.dart] _TabBarState::_buildStyledTab
    // 0x8692c8: add             SP, SP, #0x20
    // 0x8692cc: mov             x3, x0
    // 0x8692d0: ldur            x2, [fp, #-0x10]
    // 0x8692d4: LoadField: r0 = r2->field_b
    //     0x8692d4: ldur            w0, [x2, #0xb]
    // 0x8692d8: DecompressPointer r0
    //     0x8692d8: add             x0, x0, HEAP, lsl #32
    // 0x8692dc: r1 = LoadInt32Instr(r0)
    //     0x8692dc: sbfx            x1, x0, #1, #0x1f
    // 0x8692e0: mov             x0, x1
    // 0x8692e4: ldur            x1, [fp, #-0x20]
    // 0x8692e8: cmp             x1, x0
    // 0x8692ec: b.hs            #0x869d08
    // 0x8692f0: LoadField: r1 = r2->field_f
    //     0x8692f0: ldur            w1, [x2, #0xf]
    // 0x8692f4: DecompressPointer r1
    //     0x8692f4: add             x1, x1, HEAP, lsl #32
    // 0x8692f8: mov             x0, x3
    // 0x8692fc: ldur            x3, [fp, #-0x20]
    // 0x869300: ArrayStore: r1[r3] = r0  ; List_4
    //     0x869300: add             x25, x1, x3, lsl #2
    //     0x869304: add             x25, x25, #0xf
    //     0x869308: str             w0, [x25]
    //     0x86930c: tbz             w0, #0, #0x869328
    //     0x869310: ldurb           w16, [x1, #-1]
    //     0x869314: ldurb           w17, [x0, #-1]
    //     0x869318: and             x16, x17, x16, lsr #2
    //     0x86931c: tst             x16, HEAP, lsr #32
    //     0x869320: b.eq            #0x869328
    //     0x869324: bl              #0xd67e5c
    // 0x869328: b               #0x869330
    // 0x86932c: ldur            x2, [fp, #-0x10]
    // 0x869330: ldr             x1, [fp, #0x18]
    // 0x869334: ldur            x3, [fp, #-8]
    // 0x869338: LoadField: r0 = r1->field_b
    //     0x869338: ldur            w0, [x1, #0xb]
    // 0x86933c: DecompressPointer r0
    //     0x86933c: add             x0, x0, HEAP, lsl #32
    // 0x869340: cmp             w0, NULL
    // 0x869344: b.eq            #0x869d0c
    // 0x869348: LoadField: r4 = r0->field_b
    //     0x869348: ldur            w4, [x0, #0xb]
    // 0x86934c: DecompressPointer r4
    //     0x86934c: add             x4, x4, HEAP, lsl #32
    // 0x869350: r0 = LoadClassIdInstr(r4)
    //     0x869350: ldur            x0, [x4, #-1]
    //     0x869354: ubfx            x0, x0, #0xc, #0x14
    // 0x869358: SaveReg r4
    //     0x869358: str             x4, [SP, #-8]!
    // 0x86935c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x86935c: mov             x17, #0xb8ea
    //     0x869360: add             lr, x0, x17
    //     0x869364: ldr             lr, [x21, lr, lsl #3]
    //     0x869368: blr             lr
    // 0x86936c: add             SP, SP, #8
    // 0x869370: stur            x0, [fp, #-0x18]
    // 0x869374: r1 = 2
    //     0x869374: mov             x1, #2
    // 0x869378: r0 = AllocateContext()
    //     0x869378: bl              #0xd68aa4  ; AllocateContextStub
    // 0x86937c: mov             x1, x0
    // 0x869380: ldur            x0, [fp, #-8]
    // 0x869384: StoreField: r1->field_b = r0
    //     0x869384: stur            w0, [x1, #0xb]
    // 0x869388: StoreField: r1->field_f = rZR
    //     0x869388: stur            wzr, [x1, #0xf]
    // 0x86938c: ldur            x0, [fp, #-0x18]
    // 0x869390: r2 = LoadInt32Instr(r0)
    //     0x869390: sbfx            x2, x0, #1, #0x1f
    // 0x869394: stur            x2, [fp, #-0x20]
    // 0x869398: mov             x5, x1
    // 0x86939c: r4 = 0
    //     0x86939c: mov             x4, #0
    // 0x8693a0: ldr             x3, [fp, #0x18]
    // 0x8693a4: ldur            x1, [fp, #-0x10]
    // 0x8693a8: stur            x5, [fp, #-8]
    // 0x8693ac: CheckStackOverflow
    //     0x8693ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8693b0: cmp             SP, x16
    //     0x8693b4: b.ls            #0x869d10
    // 0x8693b8: cmp             x4, x2
    // 0x8693bc: b.ge            #0x869abc
    // 0x8693c0: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x8693c0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8693c4: ldr             x0, [x0, #0x598]
    //     0x8693c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8693cc: cmp             w0, w16
    //     0x8693d0: b.ne            #0x8693dc
    //     0x8693d4: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x8693d8: bl              #0xd67cdc
    // 0x8693dc: r1 = <MaterialState>
    //     0x8693dc: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x8693e0: ldr             x1, [x1, #0xcf0]
    // 0x8693e4: stur            x0, [fp, #-0x28]
    // 0x8693e8: r0 = _Set()
    //     0x8693e8: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x8693ec: mov             x1, x0
    // 0x8693f0: ldur            x0, [fp, #-0x28]
    // 0x8693f4: stur            x1, [fp, #-0x40]
    // 0x8693f8: StoreField: r1->field_1b = r0
    //     0x8693f8: stur            w0, [x1, #0x1b]
    // 0x8693fc: StoreField: r1->field_b = rZR
    //     0x8693fc: stur            wzr, [x1, #0xb]
    // 0x869400: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x869400: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x869404: ldr             x0, [x0, #0x5a0]
    //     0x869408: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x86940c: cmp             w0, w16
    //     0x869410: b.ne            #0x86941c
    //     0x869414: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x869418: bl              #0xd67cdc
    // 0x86941c: mov             x1, x0
    // 0x869420: ldur            x0, [fp, #-0x40]
    // 0x869424: StoreField: r0->field_f = r1
    //     0x869424: stur            w1, [x0, #0xf]
    // 0x869428: StoreField: r0->field_13 = rZR
    //     0x869428: stur            wzr, [x0, #0x13]
    // 0x86942c: StoreField: r0->field_17 = rZR
    //     0x86942c: stur            wzr, [x0, #0x17]
    // 0x869430: ldur            x2, [fp, #-8]
    // 0x869434: LoadField: r1 = r2->field_f
    //     0x869434: ldur            w1, [x2, #0xf]
    // 0x869438: DecompressPointer r1
    //     0x869438: add             x1, x1, HEAP, lsl #32
    // 0x86943c: ldr             x3, [fp, #0x18]
    // 0x869440: LoadField: r4 = r3->field_1f
    //     0x869440: ldur            w4, [x3, #0x1f]
    // 0x869444: DecompressPointer r4
    //     0x869444: add             x4, x4, HEAP, lsl #32
    // 0x869448: cmp             w1, w4
    // 0x86944c: b.eq            #0x869488
    // 0x869450: and             w16, w1, w4
    // 0x869454: branchIfSmi(r16, 0x8694bc)
    //     0x869454: tbz             w16, #0, #0x8694bc
    // 0x869458: r16 = LoadClassIdInstr(r1)
    //     0x869458: ldur            x16, [x1, #-1]
    //     0x86945c: ubfx            x16, x16, #0xc, #0x14
    // 0x869460: cmp             x16, #0x3c
    // 0x869464: b.ne            #0x8694bc
    // 0x869468: r16 = LoadClassIdInstr(r4)
    //     0x869468: ldur            x16, [x4, #-1]
    //     0x86946c: ubfx            x16, x16, #0xc, #0x14
    // 0x869470: cmp             x16, #0x3c
    // 0x869474: b.ne            #0x8694bc
    // 0x869478: LoadField: r16 = r1->field_7
    //     0x869478: ldur            x16, [x1, #7]
    // 0x86947c: LoadField: r17 = r4->field_7
    //     0x86947c: ldur            x17, [x4, #7]
    // 0x869480: cmp             x16, x17
    // 0x869484: b.ne            #0x8694bc
    // 0x869488: r16 = Instance_MaterialState
    //     0x869488: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x86948c: ldr             x16, [x16, #0xf70]
    // 0x869490: SaveReg r16
    //     0x869490: str             x16, [SP, #-8]!
    // 0x869494: r0 = _getHash()
    //     0x869494: bl              #0x5c2424  ; [dart:core] ::_getHash
    // 0x869498: add             SP, SP, #8
    // 0x86949c: r1 = LoadInt32Instr(r0)
    //     0x86949c: sbfx            x1, x0, #1, #0x1f
    // 0x8694a0: ldur            x16, [fp, #-0x40]
    // 0x8694a4: r30 = Instance_MaterialState
    //     0x8694a4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x8694a8: ldr             lr, [lr, #0xf70]
    // 0x8694ac: stp             lr, x16, [SP, #-0x10]!
    // 0x8694b0: SaveReg r1
    //     0x8694b0: str             x1, [SP, #-8]!
    // 0x8694b4: r0 = _add()
    //     0x8694b4: bl              #0x5c1840  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::_add
    // 0x8694b8: add             SP, SP, #0x18
    // 0x8694bc: ldr             x4, [fp, #0x18]
    // 0x8694c0: ldur            x3, [fp, #-8]
    // 0x8694c4: ldur            x0, [fp, #-0x40]
    // 0x8694c8: StoreField: r3->field_13 = r0
    //     0x8694c8: stur            w0, [x3, #0x13]
    //     0x8694cc: ldurb           w16, [x3, #-1]
    //     0x8694d0: ldurb           w17, [x0, #-1]
    //     0x8694d4: and             x16, x17, x16, lsr #2
    //     0x8694d8: tst             x16, HEAP, lsr #32
    //     0x8694dc: b.eq            #0x8694e4
    //     0x8694e0: bl              #0xd682ac
    // 0x8694e4: LoadField: r0 = r4->field_b
    //     0x8694e4: ldur            w0, [x4, #0xb]
    // 0x8694e8: DecompressPointer r0
    //     0x8694e8: add             x0, x0, HEAP, lsl #32
    // 0x8694ec: cmp             w0, NULL
    // 0x8694f0: b.eq            #0x869d18
    // 0x8694f4: r0 = Null
    //     0x8694f4: mov             x0, NULL
    // 0x8694f8: r2 = Null
    //     0x8694f8: mov             x2, NULL
    // 0x8694fc: r1 = <MouseCursor?>
    //     0x8694fc: add             x1, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0x869500: ldr             x1, [x1, #0x8b8]
    // 0x869504: cmp             w0, NULL
    // 0x869508: b.eq            #0x86955c
    // 0x86950c: branchIfSmi(r0, 0x86955c)
    //     0x86950c: tbz             w0, #0, #0x86955c
    // 0x869510: r8 = MaterialStateProperty<Y0>
    //     0x869510: add             x8, PP, #0x37, lsl #12  ; [pp+0x37ec0] Type: MaterialStateProperty<Y0>
    //     0x869514: ldr             x8, [x8, #0xec0]
    // 0x869518: r3 = SubtypeTestCache
    //     0x869518: add             x3, PP, #0x37, lsl #12  ; [pp+0x37ec8] SubtypeTestCache
    //     0x86951c: ldr             x3, [x3, #0xec8]
    // 0x869520: r24 = Subtype5TestCacheStub
    //     0x869520: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0x869524: LoadField: r30 = r24->field_7
    //     0x869524: ldur            lr, [x24, #7]
    // 0x869528: blr             lr
    // 0x86952c: cmp             w7, NULL
    // 0x869530: b.eq            #0x86953c
    // 0x869534: tbnz            w7, #4, #0x86955c
    // 0x869538: b               #0x869564
    // 0x86953c: r8 = MaterialStateProperty<Y0>
    //     0x86953c: add             x8, PP, #0x37, lsl #12  ; [pp+0x37ed0] Type: MaterialStateProperty<Y0>
    //     0x869540: ldr             x8, [x8, #0xed0]
    // 0x869544: r3 = SubtypeTestCache
    //     0x869544: add             x3, PP, #0x37, lsl #12  ; [pp+0x37ed8] SubtypeTestCache
    //     0x869548: ldr             x3, [x3, #0xed8]
    // 0x86954c: r24 = InstanceOfStub
    //     0x86954c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x869550: LoadField: r30 = r24->field_7
    //     0x869550: ldur            lr, [x24, #7]
    // 0x869554: blr             lr
    // 0x869558: b               #0x869568
    // 0x86955c: r0 = false
    //     0x86955c: add             x0, NULL, #0x30  ; false
    // 0x869560: b               #0x869568
    // 0x869564: r0 = true
    //     0x869564: add             x0, NULL, #0x20  ; true
    // 0x869568: tbnz            w0, #4, #0x869598
    // 0x86956c: r1 = Null
    //     0x86956c: mov             x1, NULL
    // 0x869570: r0 = LoadClassIdInstr(r1)
    //     0x869570: ldur            x0, [x1, #-1]
    //     0x869574: ubfx            x0, x0, #0xc, #0x14
    // 0x869578: ldur            x16, [fp, #-0x40]
    // 0x86957c: stp             x16, NULL, [SP, #-0x10]!
    // 0x869580: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x869580: mov             x17, #0x5e7
    //     0x869584: movk            x17, #1, lsl #16
    //     0x869588: add             lr, x0, x17
    //     0x86958c: ldr             lr, [x21, lr, lsl #3]
    //     0x869590: blr             lr
    // 0x869594: add             SP, SP, #0x10
    // 0x869598: ldur            x0, [fp, #-0x40]
    // 0x86959c: r1 = LoadClassIdInstr(r0)
    //     0x86959c: ldur            x1, [x0, #-1]
    //     0x8695a0: ubfx            x1, x1, #0xc, #0x14
    // 0x8695a4: r16 = Instance_MaterialState
    //     0x8695a4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x8695a8: ldr             x16, [x16, #0x2a0]
    // 0x8695ac: stp             x16, x0, [SP, #-0x10]!
    // 0x8695b0: mov             x0, x1
    // 0x8695b4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8695b4: mov             x17, #0xc98a
    //     0x8695b8: add             lr, x0, x17
    //     0x8695bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8695c0: blr             lr
    // 0x8695c4: add             SP, SP, #0x10
    // 0x8695c8: tbnz            w0, #4, #0x8695d4
    // 0x8695cc: r4 = Instance_SystemMouseCursor
    //     0x8695cc: ldr             x4, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0x8695d0: b               #0x8695dc
    // 0x8695d4: r4 = Instance_SystemMouseCursor
    //     0x8695d4: add             x4, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0x8695d8: ldr             x4, [x4, #0xea8]
    // 0x8695dc: ldr             x3, [fp, #0x18]
    // 0x8695e0: ldur            x0, [fp, #-8]
    // 0x8695e4: mov             x2, x0
    // 0x8695e8: stur            x4, [fp, #-0x28]
    // 0x8695ec: r1 = Function '<anonymous closure>':.
    //     0x8695ec: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ee0] AnonymousClosure: (0x869fe4), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0x8689ec)
    //     0x8695f0: ldr             x1, [x1, #0xee0]
    // 0x8695f4: r0 = AllocateClosure()
    //     0x8695f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8695f8: r1 = <Color?>
    //     0x8695f8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x8695fc: ldr             x1, [x1, #0xf68]
    // 0x869600: stur            x0, [fp, #-0x40]
    // 0x869604: r0 = _MaterialStatePropertyWith()
    //     0x869604: bl              #0x84d18c  ; Allocate_MaterialStatePropertyWithStub -> _MaterialStatePropertyWith<X0> (size=0x10)
    // 0x869608: mov             x1, x0
    // 0x86960c: ldur            x0, [fp, #-0x40]
    // 0x869610: StoreField: r1->field_b = r0
    //     0x869610: stur            w0, [x1, #0xb]
    // 0x869614: ldur            x2, [fp, #-8]
    // 0x869618: LoadField: r3 = r2->field_f
    //     0x869618: ldur            w3, [x2, #0xf]
    // 0x86961c: DecompressPointer r3
    //     0x86961c: add             x3, x3, HEAP, lsl #32
    // 0x869620: ldr             x4, [fp, #0x18]
    // 0x869624: stur            x3, [fp, #-0x48]
    // 0x869628: LoadField: r0 = r4->field_b
    //     0x869628: ldur            w0, [x4, #0xb]
    // 0x86962c: DecompressPointer r0
    //     0x86962c: add             x0, x0, HEAP, lsl #32
    // 0x869630: cmp             w0, NULL
    // 0x869634: b.eq            #0x869d1c
    // 0x869638: LoadField: r0 = r2->field_b
    //     0x869638: ldur            w0, [x2, #0xb]
    // 0x86963c: DecompressPointer r0
    //     0x86963c: add             x0, x0, HEAP, lsl #32
    // 0x869640: LoadField: r5 = r0->field_13
    //     0x869640: ldur            w5, [x0, #0x13]
    // 0x869644: DecompressPointer r5
    //     0x869644: add             x5, x5, HEAP, lsl #32
    // 0x869648: LoadField: r6 = r5->field_2b
    //     0x869648: ldur            w6, [x5, #0x2b]
    // 0x86964c: DecompressPointer r6
    //     0x86964c: add             x6, x6, HEAP, lsl #32
    // 0x869650: cmp             w6, NULL
    // 0x869654: b.ne            #0x869660
    // 0x869658: mov             x7, x1
    // 0x86965c: b               #0x869664
    // 0x869660: mov             x7, x6
    // 0x869664: ldur            x5, [fp, #-0x18]
    // 0x869668: ldur            x1, [fp, #-0x28]
    // 0x86966c: ldur            x6, [fp, #-0x10]
    // 0x869670: stur            x7, [fp, #-0x40]
    // 0x869674: LoadField: r8 = r0->field_17
    //     0x869674: ldur            w8, [x0, #0x17]
    // 0x869678: DecompressPointer r8
    //     0x869678: add             x8, x8, HEAP, lsl #32
    // 0x86967c: r0 = LoadClassIdInstr(r8)
    //     0x86967c: ldur            x0, [x8, #-1]
    //     0x869680: ubfx            x0, x0, #0xc, #0x14
    // 0x869684: SaveReg r8
    //     0x869684: str             x8, [SP, #-8]!
    // 0x869688: r0 = GDT[cid_x0 + -0xfbc]()
    //     0x869688: sub             lr, x0, #0xfbc
    //     0x86968c: ldr             lr, [x21, lr, lsl #3]
    //     0x869690: blr             lr
    // 0x869694: add             SP, SP, #8
    // 0x869698: mov             x1, x0
    // 0x86969c: ldr             x0, [fp, #0x18]
    // 0x8696a0: stur            x1, [fp, #-0x50]
    // 0x8696a4: LoadField: r2 = r0->field_b
    //     0x8696a4: ldur            w2, [x0, #0xb]
    // 0x8696a8: DecompressPointer r2
    //     0x8696a8: add             x2, x2, HEAP, lsl #32
    // 0x8696ac: cmp             w2, NULL
    // 0x8696b0: b.eq            #0x869d20
    // 0x8696b4: r0 = EdgeInsets()
    //     0x8696b4: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x8696b8: mov             x3, x0
    // 0x8696bc: d0 = 0.000000
    //     0x8696bc: eor             v0.16b, v0.16b, v0.16b
    // 0x8696c0: stur            x3, [fp, #-0x68]
    // 0x8696c4: StoreField: r3->field_7 = d0
    //     0x8696c4: stur            d0, [x3, #7]
    // 0x8696c8: StoreField: r3->field_f = d0
    //     0x8696c8: stur            d0, [x3, #0xf]
    // 0x8696cc: StoreField: r3->field_17 = d0
    //     0x8696cc: stur            d0, [x3, #0x17]
    // 0x8696d0: d1 = 2.000000
    //     0x8696d0: fmov            d1, #2.00000000
    // 0x8696d4: StoreField: r3->field_1f = d1
    //     0x8696d4: stur            d1, [x3, #0x1f]
    // 0x8696d8: ldur            x4, [fp, #-8]
    // 0x8696dc: LoadField: r2 = r4->field_f
    //     0x8696dc: ldur            w2, [x4, #0xf]
    // 0x8696e0: DecompressPointer r2
    //     0x8696e0: add             x2, x2, HEAP, lsl #32
    // 0x8696e4: ldur            x5, [fp, #-0x10]
    // 0x8696e8: LoadField: r0 = r5->field_b
    //     0x8696e8: ldur            w0, [x5, #0xb]
    // 0x8696ec: DecompressPointer r0
    //     0x8696ec: add             x0, x0, HEAP, lsl #32
    // 0x8696f0: r6 = LoadInt32Instr(r2)
    //     0x8696f0: sbfx            x6, x2, #1, #0x1f
    //     0x8696f4: tbz             w2, #0, #0x8696fc
    //     0x8696f8: ldur            x6, [x2, #7]
    // 0x8696fc: r1 = LoadInt32Instr(r0)
    //     0x8696fc: sbfx            x1, x0, #1, #0x1f
    // 0x869700: mov             x0, x1
    // 0x869704: mov             x1, x6
    // 0x869708: cmp             x1, x0
    // 0x86970c: b.hs            #0x869d24
    // 0x869710: LoadField: r0 = r5->field_f
    //     0x869710: ldur            w0, [x5, #0xf]
    // 0x869714: DecompressPointer r0
    //     0x869714: add             x0, x0, HEAP, lsl #32
    // 0x869718: ArrayLoad: r7 = r0[r6]  ; Unknown_4
    //     0x869718: add             x16, x0, x6, lsl #2
    //     0x86971c: ldur            w7, [x16, #0xf]
    // 0x869720: DecompressPointer r7
    //     0x869720: add             x7, x7, HEAP, lsl #32
    // 0x869724: ldr             x0, [fp, #0x18]
    // 0x869728: stur            x7, [fp, #-0x60]
    // 0x86972c: LoadField: r1 = r0->field_1f
    //     0x86972c: ldur            w1, [x0, #0x1f]
    // 0x869730: DecompressPointer r1
    //     0x869730: add             x1, x1, HEAP, lsl #32
    // 0x869734: cmp             w2, w1
    // 0x869738: b.eq            #0x86977c
    // 0x86973c: and             w16, w2, w1
    // 0x869740: branchIfSmi(r16, 0x869774)
    //     0x869740: tbz             w16, #0, #0x869774
    // 0x869744: r16 = LoadClassIdInstr(r2)
    //     0x869744: ldur            x16, [x2, #-1]
    //     0x869748: ubfx            x16, x16, #0xc, #0x14
    // 0x86974c: cmp             x16, #0x3c
    // 0x869750: b.ne            #0x869774
    // 0x869754: r16 = LoadClassIdInstr(r1)
    //     0x869754: ldur            x16, [x1, #-1]
    //     0x869758: ubfx            x16, x16, #0xc, #0x14
    // 0x86975c: cmp             x16, #0x3c
    // 0x869760: b.ne            #0x869774
    // 0x869764: LoadField: r16 = r2->field_7
    //     0x869764: ldur            x16, [x2, #7]
    // 0x869768: LoadField: r17 = r1->field_7
    //     0x869768: ldur            x17, [x1, #7]
    // 0x86976c: cmp             x16, x17
    // 0x869770: b.eq            #0x86977c
    // 0x869774: r8 = false
    //     0x869774: add             x8, NULL, #0x30  ; false
    // 0x869778: b               #0x869780
    // 0x86977c: r8 = true
    //     0x86977c: add             x8, NULL, #0x20  ; true
    // 0x869780: stur            x8, [fp, #-0x58]
    // 0x869784: cmp             w2, NULL
    // 0x869788: b.eq            #0x869d28
    // 0x86978c: add             x9, x6, #1
    // 0x869790: stur            x9, [fp, #-0x30]
    // 0x869794: r1 = Null
    //     0x869794: mov             x1, NULL
    // 0x869798: r2 = 8
    //     0x869798: mov             x2, #8
    // 0x86979c: r0 = AllocateArray()
    //     0x86979c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8697a0: mov             x2, x0
    // 0x8697a4: r17 = "Tab "
    //     0x8697a4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37ee8] "Tab "
    //     0x8697a8: ldr             x17, [x17, #0xee8]
    // 0x8697ac: StoreField: r2->field_f = r17
    //     0x8697ac: stur            w17, [x2, #0xf]
    // 0x8697b0: ldur            x3, [fp, #-0x30]
    // 0x8697b4: r0 = BoxInt64Instr(r3)
    //     0x8697b4: sbfiz           x0, x3, #1, #0x1f
    //     0x8697b8: cmp             x3, x0, asr #1
    //     0x8697bc: b.eq            #0x8697c8
    //     0x8697c0: bl              #0xd69bb8
    //     0x8697c4: stur            x3, [x0, #7]
    // 0x8697c8: StoreField: r2->field_13 = r0
    //     0x8697c8: stur            w0, [x2, #0x13]
    // 0x8697cc: r17 = " of "
    //     0x8697cc: ldr             x17, [PP, #0x3d20]  ; [pp+0x3d20] " of "
    // 0x8697d0: StoreField: r2->field_17 = r17
    //     0x8697d0: stur            w17, [x2, #0x17]
    // 0x8697d4: ldur            x0, [fp, #-0x18]
    // 0x8697d8: StoreField: r2->field_1b = r0
    //     0x8697d8: stur            w0, [x2, #0x1b]
    // 0x8697dc: SaveReg r2
    //     0x8697dc: str             x2, [SP, #-8]!
    // 0x8697e0: r0 = _interpolate()
    //     0x8697e0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x8697e4: add             SP, SP, #8
    // 0x8697e8: stur            x0, [fp, #-0x70]
    // 0x8697ec: r0 = Semantics()
    //     0x8697ec: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x8697f0: stur            x0, [fp, #-0x78]
    // 0x8697f4: ldur            x16, [fp, #-0x58]
    // 0x8697f8: stp             x16, x0, [SP, #-0x10]!
    // 0x8697fc: ldur            x16, [fp, #-0x70]
    // 0x869800: SaveReg r16
    //     0x869800: str             x16, [SP, #-8]!
    // 0x869804: r4 = const [0, 0x3, 0x3, 0x1, label, 0x2, selected, 0x1, null]
    //     0x869804: add             x4, PP, #0x37, lsl #12  ; [pp+0x37ef0] List(9) [0, 0x3, 0x3, 0x1, "label", 0x2, "selected", 0x1, Null]
    //     0x869808: ldr             x4, [x4, #0xef0]
    // 0x86980c: r0 = Semantics()
    //     0x86980c: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x869810: add             SP, SP, #0x18
    // 0x869814: r1 = Null
    //     0x869814: mov             x1, NULL
    // 0x869818: r2 = 4
    //     0x869818: mov             x2, #4
    // 0x86981c: r0 = AllocateArray()
    //     0x86981c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x869820: mov             x2, x0
    // 0x869824: ldur            x0, [fp, #-0x60]
    // 0x869828: stur            x2, [fp, #-0x58]
    // 0x86982c: StoreField: r2->field_f = r0
    //     0x86982c: stur            w0, [x2, #0xf]
    // 0x869830: ldur            x0, [fp, #-0x78]
    // 0x869834: StoreField: r2->field_13 = r0
    //     0x869834: stur            w0, [x2, #0x13]
    // 0x869838: r1 = <Widget>
    //     0x869838: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x86983c: ldr             x1, [x1, #0xea8]
    // 0x869840: r0 = AllocateGrowableArray()
    //     0x869840: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x869844: mov             x1, x0
    // 0x869848: ldur            x0, [fp, #-0x58]
    // 0x86984c: stur            x1, [fp, #-0x60]
    // 0x869850: StoreField: r1->field_f = r0
    //     0x869850: stur            w0, [x1, #0xf]
    // 0x869854: r0 = 4
    //     0x869854: mov             x0, #4
    // 0x869858: StoreField: r1->field_b = r0
    //     0x869858: stur            w0, [x1, #0xb]
    // 0x86985c: r0 = Stack()
    //     0x86985c: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x869860: mov             x1, x0
    // 0x869864: r0 = Instance_AlignmentDirectional
    //     0x869864: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x869868: ldr             x0, [x0, #0xf70]
    // 0x86986c: stur            x1, [fp, #-0x58]
    // 0x869870: StoreField: r1->field_f = r0
    //     0x869870: stur            w0, [x1, #0xf]
    // 0x869874: r2 = Instance_StackFit
    //     0x869874: add             x2, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x869878: ldr             x2, [x2, #0xf78]
    // 0x86987c: StoreField: r1->field_17 = r2
    //     0x86987c: stur            w2, [x1, #0x17]
    // 0x869880: r3 = Instance_Clip
    //     0x869880: add             x3, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x869884: ldr             x3, [x3, #0x678]
    // 0x869888: StoreField: r1->field_1b = r3
    //     0x869888: stur            w3, [x1, #0x1b]
    // 0x86988c: ldur            x4, [fp, #-0x60]
    // 0x869890: StoreField: r1->field_b = r4
    //     0x869890: stur            w4, [x1, #0xb]
    // 0x869894: r0 = Padding()
    //     0x869894: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x869898: mov             x1, x0
    // 0x86989c: ldur            x0, [fp, #-0x68]
    // 0x8698a0: stur            x1, [fp, #-0x60]
    // 0x8698a4: StoreField: r1->field_f = r0
    //     0x8698a4: stur            w0, [x1, #0xf]
    // 0x8698a8: ldur            x0, [fp, #-0x58]
    // 0x8698ac: StoreField: r1->field_b = r0
    //     0x8698ac: stur            w0, [x1, #0xb]
    // 0x8698b0: r0 = InkWell()
    //     0x8698b0: bl              #0x832ed8  ; AllocateInkWellStub -> InkWell (size=0x7c)
    // 0x8698b4: mov             x3, x0
    // 0x8698b8: ldur            x0, [fp, #-0x60]
    // 0x8698bc: stur            x3, [fp, #-0x58]
    // 0x8698c0: StoreField: r3->field_b = r0
    //     0x8698c0: stur            w0, [x3, #0xb]
    // 0x8698c4: ldur            x2, [fp, #-8]
    // 0x8698c8: r1 = Function '<anonymous closure>':.
    //     0x8698c8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ef8] AnonymousClosure: (0x869ec8), in [package:flutter/src/material/tabs.dart] _TabBarState::build (0x8689ec)
    //     0x8698cc: ldr             x1, [x1, #0xef8]
    // 0x8698d0: r0 = AllocateClosure()
    //     0x8698d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8698d4: ldur            x2, [fp, #-0x58]
    // 0x8698d8: StoreField: r2->field_f = r0
    //     0x8698d8: stur            w0, [x2, #0xf]
    // 0x8698dc: ldur            x0, [fp, #-0x28]
    // 0x8698e0: StoreField: r2->field_2f = r0
    //     0x8698e0: stur            w0, [x2, #0x2f]
    // 0x8698e4: r3 = true
    //     0x8698e4: add             x3, NULL, #0x20  ; true
    // 0x8698e8: StoreField: r2->field_33 = r3
    //     0x8698e8: stur            w3, [x2, #0x33]
    // 0x8698ec: r4 = Instance_BoxShape
    //     0x8698ec: add             x4, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x8698f0: ldr             x4, [x4, #0xe68]
    // 0x8698f4: StoreField: r2->field_37 = r4
    //     0x8698f4: stur            w4, [x2, #0x37]
    // 0x8698f8: ldur            x0, [fp, #-0x40]
    // 0x8698fc: StoreField: r2->field_53 = r0
    //     0x8698fc: stur            w0, [x2, #0x53]
    // 0x869900: ldur            x0, [fp, #-0x50]
    // 0x869904: StoreField: r2->field_5b = r0
    //     0x869904: stur            w0, [x2, #0x5b]
    // 0x869908: StoreField: r2->field_5f = r3
    //     0x869908: stur            w3, [x2, #0x5f]
    // 0x86990c: r5 = false
    //     0x86990c: add             x5, NULL, #0x30  ; false
    // 0x869910: StoreField: r2->field_63 = r5
    //     0x869910: stur            w5, [x2, #0x63]
    // 0x869914: StoreField: r2->field_73 = r3
    //     0x869914: stur            w3, [x2, #0x73]
    // 0x869918: StoreField: r2->field_6b = r5
    //     0x869918: stur            w5, [x2, #0x6b]
    // 0x86991c: ldur            x6, [fp, #-0x10]
    // 0x869920: LoadField: r0 = r6->field_b
    //     0x869920: ldur            w0, [x6, #0xb]
    // 0x869924: DecompressPointer r0
    //     0x869924: add             x0, x0, HEAP, lsl #32
    // 0x869928: ldur            x1, [fp, #-0x48]
    // 0x86992c: r7 = LoadInt32Instr(r1)
    //     0x86992c: sbfx            x7, x1, #1, #0x1f
    //     0x869930: tbz             w1, #0, #0x869938
    //     0x869934: ldur            x7, [x1, #7]
    // 0x869938: r8 = LoadInt32Instr(r0)
    //     0x869938: sbfx            x8, x0, #1, #0x1f
    // 0x86993c: mov             x0, x8
    // 0x869940: mov             x1, x7
    // 0x869944: cmp             x1, x0
    // 0x869948: b.hs            #0x869d2c
    // 0x86994c: LoadField: r9 = r6->field_f
    //     0x86994c: ldur            w9, [x6, #0xf]
    // 0x869950: DecompressPointer r9
    //     0x869950: add             x9, x9, HEAP, lsl #32
    // 0x869954: mov             x1, x9
    // 0x869958: mov             x0, x2
    // 0x86995c: stur            x9, [fp, #-0x40]
    // 0x869960: ArrayStore: r1[r7] = r0  ; List_4
    //     0x869960: add             x25, x1, x7, lsl #2
    //     0x869964: add             x25, x25, #0xf
    //     0x869968: str             w0, [x25]
    //     0x86996c: tbz             w0, #0, #0x869988
    //     0x869970: ldurb           w16, [x1, #-1]
    //     0x869974: ldurb           w17, [x0, #-1]
    //     0x869978: and             x16, x17, x16, lsr #2
    //     0x86997c: tst             x16, HEAP, lsr #32
    //     0x869980: b.eq            #0x869988
    //     0x869984: bl              #0xd67e5c
    // 0x869988: ldr             x2, [fp, #0x18]
    // 0x86998c: LoadField: r0 = r2->field_b
    //     0x86998c: ldur            w0, [x2, #0xb]
    // 0x869990: DecompressPointer r0
    //     0x869990: add             x0, x0, HEAP, lsl #32
    // 0x869994: cmp             w0, NULL
    // 0x869998: b.eq            #0x869d30
    // 0x86999c: LoadField: r1 = r0->field_13
    //     0x86999c: ldur            w1, [x0, #0x13]
    // 0x8699a0: DecompressPointer r1
    //     0x8699a0: add             x1, x1, HEAP, lsl #32
    // 0x8699a4: tbz             w1, #4, #0x869a40
    // 0x8699a8: ldur            x7, [fp, #-8]
    // 0x8699ac: LoadField: r0 = r7->field_f
    //     0x8699ac: ldur            w0, [x7, #0xf]
    // 0x8699b0: DecompressPointer r0
    //     0x8699b0: add             x0, x0, HEAP, lsl #32
    // 0x8699b4: r10 = LoadInt32Instr(r0)
    //     0x8699b4: sbfx            x10, x0, #1, #0x1f
    //     0x8699b8: tbz             w0, #0, #0x8699c0
    //     0x8699bc: ldur            x10, [x0, #7]
    // 0x8699c0: mov             x0, x8
    // 0x8699c4: mov             x1, x10
    // 0x8699c8: stur            x10, [fp, #-0x30]
    // 0x8699cc: cmp             x1, x0
    // 0x8699d0: b.hs            #0x869d34
    // 0x8699d4: ArrayLoad: r0 = r9[r10]  ; Unknown_4
    //     0x8699d4: add             x16, x9, x10, lsl #2
    //     0x8699d8: ldur            w0, [x16, #0xf]
    // 0x8699dc: DecompressPointer r0
    //     0x8699dc: add             x0, x0, HEAP, lsl #32
    // 0x8699e0: stur            x0, [fp, #-0x28]
    // 0x8699e4: r1 = <FlexParentData<RenderBox>>
    //     0x8699e4: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f2f8] TypeArguments: <FlexParentData<RenderBox>>
    //     0x8699e8: ldr             x1, [x1, #0x2f8]
    // 0x8699ec: r0 = Expanded()
    //     0x8699ec: bl              #0x825404  ; AllocateExpandedStub -> Expanded (size=0x20)
    // 0x8699f0: r2 = 1
    //     0x8699f0: mov             x2, #1
    // 0x8699f4: StoreField: r0->field_13 = r2
    //     0x8699f4: stur            x2, [x0, #0x13]
    // 0x8699f8: r3 = Instance_FlexFit
    //     0x8699f8: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d2e8] Obj!FlexFit@b64b91
    //     0x8699fc: ldr             x3, [x3, #0x2e8]
    // 0x869a00: StoreField: r0->field_1b = r3
    //     0x869a00: stur            w3, [x0, #0x1b]
    // 0x869a04: ldur            x1, [fp, #-0x28]
    // 0x869a08: StoreField: r0->field_b = r1
    //     0x869a08: stur            w1, [x0, #0xb]
    // 0x869a0c: ldur            x1, [fp, #-0x40]
    // 0x869a10: ldur            x4, [fp, #-0x30]
    // 0x869a14: ArrayStore: r1[r4] = r0  ; List_4
    //     0x869a14: add             x25, x1, x4, lsl #2
    //     0x869a18: add             x25, x25, #0xf
    //     0x869a1c: str             w0, [x25]
    //     0x869a20: tbz             w0, #0, #0x869a3c
    //     0x869a24: ldurb           w16, [x1, #-1]
    //     0x869a28: ldurb           w17, [x0, #-1]
    //     0x869a2c: and             x16, x17, x16, lsr #2
    //     0x869a30: tst             x16, HEAP, lsr #32
    //     0x869a34: b.eq            #0x869a3c
    //     0x869a38: bl              #0xd67e5c
    // 0x869a3c: b               #0x869a4c
    // 0x869a40: r3 = Instance_FlexFit
    //     0x869a40: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d2e8] Obj!FlexFit@b64b91
    //     0x869a44: ldr             x3, [x3, #0x2e8]
    // 0x869a48: r2 = 1
    //     0x869a48: mov             x2, #1
    // 0x869a4c: ldur            x5, [fp, #-8]
    // 0x869a50: r0 = CloneContext()
    //     0x869a50: bl              #0xd684cc  ; CloneContextStub
    // 0x869a54: mov             x2, x0
    // 0x869a58: LoadField: r0 = r2->field_f
    //     0x869a58: ldur            w0, [x2, #0xf]
    // 0x869a5c: DecompressPointer r0
    //     0x869a5c: add             x0, x0, HEAP, lsl #32
    // 0x869a60: cmp             w0, NULL
    // 0x869a64: b.eq            #0x869d38
    // 0x869a68: r1 = LoadInt32Instr(r0)
    //     0x869a68: sbfx            x1, x0, #1, #0x1f
    //     0x869a6c: tbz             w0, #0, #0x869a74
    //     0x869a70: ldur            x1, [x0, #7]
    // 0x869a74: add             x4, x1, #1
    // 0x869a78: r0 = BoxInt64Instr(r4)
    //     0x869a78: sbfiz           x0, x4, #1, #0x1f
    //     0x869a7c: cmp             x4, x0, asr #1
    //     0x869a80: b.eq            #0x869a8c
    //     0x869a84: bl              #0xd69bb8
    //     0x869a88: stur            x4, [x0, #7]
    // 0x869a8c: StoreField: r2->field_f = r0
    //     0x869a8c: stur            w0, [x2, #0xf]
    //     0x869a90: tbz             w0, #0, #0x869aac
    //     0x869a94: ldurb           w16, [x2, #-1]
    //     0x869a98: ldurb           w17, [x0, #-1]
    //     0x869a9c: and             x16, x17, x16, lsr #2
    //     0x869aa0: tst             x16, HEAP, lsr #32
    //     0x869aa4: b.eq            #0x869aac
    //     0x869aa8: bl              #0xd6828c
    // 0x869aac: mov             x5, x2
    // 0x869ab0: ldur            x0, [fp, #-0x18]
    // 0x869ab4: ldur            x2, [fp, #-0x20]
    // 0x869ab8: b               #0x8693a0
    // 0x869abc: mov             x0, x3
    // 0x869ac0: LoadField: r1 = r0->field_1b
    //     0x869ac0: ldur            w1, [x0, #0x1b]
    // 0x869ac4: DecompressPointer r1
    //     0x869ac4: add             x1, x1, HEAP, lsl #32
    // 0x869ac8: stur            x1, [fp, #-0x28]
    // 0x869acc: LoadField: r2 = r0->field_b
    //     0x869acc: ldur            w2, [x0, #0xb]
    // 0x869ad0: DecompressPointer r2
    //     0x869ad0: add             x2, x2, HEAP, lsl #32
    // 0x869ad4: cmp             w2, NULL
    // 0x869ad8: b.eq            #0x869d3c
    // 0x869adc: LoadField: r3 = r2->field_3b
    //     0x869adc: ldur            w3, [x2, #0x3b]
    // 0x869ae0: DecompressPointer r3
    //     0x869ae0: add             x3, x3, HEAP, lsl #32
    // 0x869ae4: stur            x3, [fp, #-0x18]
    // 0x869ae8: LoadField: r4 = r2->field_3f
    //     0x869ae8: ldur            w4, [x2, #0x3f]
    // 0x869aec: DecompressPointer r4
    //     0x869aec: add             x4, x4, HEAP, lsl #32
    // 0x869af0: stur            x4, [fp, #-8]
    // 0x869af4: r1 = 1
    //     0x869af4: mov             x1, #1
    // 0x869af8: r0 = AllocateContext()
    //     0x869af8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x869afc: mov             x1, x0
    // 0x869b00: ldr             x0, [fp, #0x18]
    // 0x869b04: StoreField: r1->field_f = r0
    //     0x869b04: stur            w0, [x1, #0xf]
    // 0x869b08: mov             x2, x1
    // 0x869b0c: r1 = Function '_saveTabOffsets@472014024':.
    //     0x869b0c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f00] AnonymousClosure: (0x869df8), in [package:flutter/src/material/tabs.dart] _TabBarState::_saveTabOffsets (0x869e50)
    //     0x869b10: ldr             x1, [x1, #0xf00]
    // 0x869b14: r0 = AllocateClosure()
    //     0x869b14: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x869b18: stur            x0, [fp, #-0x40]
    // 0x869b1c: r0 = _TabLabelBar()
    //     0x869b1c: bl              #0x869d60  ; Allocate_TabLabelBarStub -> _TabLabelBar (size=0x34)
    // 0x869b20: stur            x0, [fp, #-0x48]
    // 0x869b24: ldur            x16, [fp, #-0x10]
    // 0x869b28: stp             x16, x0, [SP, #-0x10]!
    // 0x869b2c: ldur            x16, [fp, #-0x40]
    // 0x869b30: SaveReg r16
    //     0x869b30: str             x16, [SP, #-8]!
    // 0x869b34: r0 = _TabLabelBar()
    //     0x869b34: bl              #0x832e40  ; [package:extended_tabs/src/tab_bar.dart] _TabLabelBar::_TabLabelBar
    // 0x869b38: add             SP, SP, #0x18
    // 0x869b3c: r0 = _TabStyle()
    //     0x869b3c: bl              #0x869d54  ; Allocate_TabStyleStub -> _TabStyle (size=0x28)
    // 0x869b40: mov             x1, x0
    // 0x869b44: r0 = false
    //     0x869b44: add             x0, NULL, #0x30  ; false
    // 0x869b48: stur            x1, [fp, #-0x10]
    // 0x869b4c: StoreField: r1->field_17 = r0
    //     0x869b4c: stur            w0, [x1, #0x17]
    // 0x869b50: ldur            x2, [fp, #-0x18]
    // 0x869b54: StoreField: r1->field_1b = r2
    //     0x869b54: stur            w2, [x1, #0x1b]
    // 0x869b58: ldur            x2, [fp, #-8]
    // 0x869b5c: StoreField: r1->field_1f = r2
    //     0x869b5c: stur            w2, [x1, #0x1f]
    // 0x869b60: ldur            x2, [fp, #-0x48]
    // 0x869b64: StoreField: r1->field_23 = r2
    //     0x869b64: stur            w2, [x1, #0x23]
    // 0x869b68: r2 = Instance__AlwaysDismissedAnimation
    //     0x869b68: add             x2, PP, #0xf, lsl #12  ; [pp+0xf3b8] Obj!_AlwaysDismissedAnimation<double>@b4fcc1
    //     0x869b6c: ldr             x2, [x2, #0x3b8]
    // 0x869b70: StoreField: r1->field_b = r2
    //     0x869b70: stur            w2, [x1, #0xb]
    // 0x869b74: r0 = CustomPaint()
    //     0x869b74: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x869b78: mov             x1, x0
    // 0x869b7c: ldur            x0, [fp, #-0x28]
    // 0x869b80: stur            x1, [fp, #-8]
    // 0x869b84: StoreField: r1->field_f = r0
    //     0x869b84: stur            w0, [x1, #0xf]
    // 0x869b88: r0 = Instance_Size
    //     0x869b88: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x869b8c: StoreField: r1->field_17 = r0
    //     0x869b8c: stur            w0, [x1, #0x17]
    // 0x869b90: r0 = false
    //     0x869b90: add             x0, NULL, #0x30  ; false
    // 0x869b94: StoreField: r1->field_1b = r0
    //     0x869b94: stur            w0, [x1, #0x1b]
    // 0x869b98: StoreField: r1->field_1f = r0
    //     0x869b98: stur            w0, [x1, #0x1f]
    // 0x869b9c: ldur            x2, [fp, #-0x10]
    // 0x869ba0: StoreField: r1->field_b = r2
    //     0x869ba0: stur            w2, [x1, #0xb]
    // 0x869ba4: ldr             x2, [fp, #0x18]
    // 0x869ba8: LoadField: r3 = r2->field_b
    //     0x869ba8: ldur            w3, [x2, #0xb]
    // 0x869bac: DecompressPointer r3
    //     0x869bac: add             x3, x3, HEAP, lsl #32
    // 0x869bb0: cmp             w3, NULL
    // 0x869bb4: b.eq            #0x869d40
    // 0x869bb8: LoadField: r4 = r3->field_13
    //     0x869bb8: ldur            w4, [x3, #0x13]
    // 0x869bbc: DecompressPointer r4
    //     0x869bbc: add             x4, x4, HEAP, lsl #32
    // 0x869bc0: tbnz            w4, #4, #0x869c94
    // 0x869bc4: LoadField: r3 = r2->field_13
    //     0x869bc4: ldur            w3, [x2, #0x13]
    // 0x869bc8: DecompressPointer r3
    //     0x869bc8: add             x3, x3, HEAP, lsl #32
    // 0x869bcc: cmp             w3, NULL
    // 0x869bd0: b.ne            #0x869c24
    // 0x869bd4: r0 = _TabBarScrollController()
    //     0x869bd4: bl              #0x869d48  ; Allocate_TabBarScrollControllerStub -> _TabBarScrollController (size=0x3c)
    // 0x869bd8: mov             x1, x0
    // 0x869bdc: ldr             x0, [fp, #0x18]
    // 0x869be0: stur            x1, [fp, #-0x10]
    // 0x869be4: StoreField: r1->field_37 = r0
    //     0x869be4: stur            w0, [x1, #0x37]
    // 0x869be8: SaveReg r1
    //     0x869be8: str             x1, [SP, #-8]!
    // 0x869bec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x869bec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x869bf0: r0 = ScrollController()
    //     0x869bf0: bl              #0x51ee1c  ; [package:flutter/src/widgets/scroll_controller.dart] ScrollController::ScrollController
    // 0x869bf4: add             SP, SP, #8
    // 0x869bf8: ldur            x0, [fp, #-0x10]
    // 0x869bfc: ldr             x1, [fp, #0x18]
    // 0x869c00: StoreField: r1->field_13 = r0
    //     0x869c00: stur            w0, [x1, #0x13]
    //     0x869c04: ldurb           w16, [x1, #-1]
    //     0x869c08: ldurb           w17, [x0, #-1]
    //     0x869c0c: and             x16, x17, x16, lsr #2
    //     0x869c10: tst             x16, HEAP, lsr #32
    //     0x869c14: b.eq            #0x869c1c
    //     0x869c18: bl              #0xd6826c
    // 0x869c1c: ldur            x2, [fp, #-0x10]
    // 0x869c20: b               #0x869c2c
    // 0x869c24: mov             x1, x2
    // 0x869c28: mov             x2, x3
    // 0x869c2c: ldur            x0, [fp, #-8]
    // 0x869c30: stur            x2, [fp, #-0x10]
    // 0x869c34: LoadField: r3 = r1->field_b
    //     0x869c34: ldur            w3, [x1, #0xb]
    // 0x869c38: DecompressPointer r3
    //     0x869c38: add             x3, x3, HEAP, lsl #32
    // 0x869c3c: cmp             w3, NULL
    // 0x869c40: b.eq            #0x869d44
    // 0x869c44: r0 = SingleChildScrollView()
    //     0x869c44: bl              #0x832e1c  ; AllocateSingleChildScrollViewStub -> SingleChildScrollView (size=0x38)
    // 0x869c48: r1 = Instance_Axis
    //     0x869c48: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c440] Obj!Axis@b64fd1
    //     0x869c4c: ldr             x1, [x1, #0x440]
    // 0x869c50: StoreField: r0->field_b = r1
    //     0x869c50: stur            w1, [x0, #0xb]
    // 0x869c54: r1 = false
    //     0x869c54: add             x1, NULL, #0x30  ; false
    // 0x869c58: StoreField: r0->field_f = r1
    //     0x869c58: stur            w1, [x0, #0xf]
    // 0x869c5c: ldur            x1, [fp, #-0x10]
    // 0x869c60: StoreField: r0->field_17 = r1
    //     0x869c60: stur            w1, [x0, #0x17]
    // 0x869c64: ldur            x1, [fp, #-8]
    // 0x869c68: StoreField: r0->field_23 = r1
    //     0x869c68: stur            w1, [x0, #0x23]
    // 0x869c6c: r2 = Instance_DragStartBehavior
    //     0x869c6c: add             x2, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x869c70: ldr             x2, [x2, #0xf88]
    // 0x869c74: StoreField: r0->field_27 = r2
    //     0x869c74: stur            w2, [x0, #0x27]
    // 0x869c78: r2 = Instance_Clip
    //     0x869c78: add             x2, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x869c7c: ldr             x2, [x2, #0x678]
    // 0x869c80: StoreField: r0->field_2b = r2
    //     0x869c80: stur            w2, [x0, #0x2b]
    // 0x869c84: r2 = Instance_ScrollViewKeyboardDismissBehavior
    //     0x869c84: add             x2, PP, #0x20, lsl #12  ; [pp+0x20210] Obj!ScrollViewKeyboardDismissBehavior@b63571
    //     0x869c88: ldr             x2, [x2, #0x210]
    // 0x869c8c: StoreField: r0->field_33 = r2
    //     0x869c8c: stur            w2, [x0, #0x33]
    // 0x869c90: b               #0x869c98
    // 0x869c94: mov             x0, x1
    // 0x869c98: LeaveFrame
    //     0x869c98: mov             SP, fp
    //     0x869c9c: ldp             fp, lr, [SP], #0x10
    // 0x869ca0: ret
    //     0x869ca0: ret             
    // 0x869ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869ca4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869ca8: b               #0x868a04
    // 0x869cac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869cbc: b               #0x868bf4
    // 0x869cc0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cc0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cc8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cc8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869ccc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869ccc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869cd0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cd0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869cd4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cd4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869cd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cdc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cdc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869ce0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869ce0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869ce4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869ce4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869ce8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869ce8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869cf0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869cf0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869cf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869cfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869cfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d04: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869d04: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869d08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869d08: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869d10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869d14: b               #0x8693b8
    // 0x869d18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d24: r0 = RangeErrorSharedWithFPURegs()
    //     0x869d24: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x869d28: r0 = NullErrorSharedWithFPURegs()
    //     0x869d28: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x869d2c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869d2c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869d30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d34: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x869d34: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x869d38: r0 = NullErrorSharedWithoutFPURegs()
    //     0x869d38: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x869d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869d44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869d44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildStyledTab(/* No info */) {
    // ** addr: 0x869d78, size: 0x74
    // 0x869d78: EnterFrame
    //     0x869d78: stp             fp, lr, [SP, #-0x10]!
    //     0x869d7c: mov             fp, SP
    // 0x869d80: AllocStack(0x10)
    //     0x869d80: sub             SP, SP, #0x10
    // 0x869d84: ldr             x0, [fp, #0x28]
    // 0x869d88: LoadField: r1 = r0->field_b
    //     0x869d88: ldur            w1, [x0, #0xb]
    // 0x869d8c: DecompressPointer r1
    //     0x869d8c: add             x1, x1, HEAP, lsl #32
    // 0x869d90: cmp             w1, NULL
    // 0x869d94: b.eq            #0x869de8
    // 0x869d98: LoadField: r0 = r1->field_3b
    //     0x869d98: ldur            w0, [x1, #0x3b]
    // 0x869d9c: DecompressPointer r0
    //     0x869d9c: add             x0, x0, HEAP, lsl #32
    // 0x869da0: stur            x0, [fp, #-0x10]
    // 0x869da4: LoadField: r2 = r1->field_3f
    //     0x869da4: ldur            w2, [x1, #0x3f]
    // 0x869da8: DecompressPointer r2
    //     0x869da8: add             x2, x2, HEAP, lsl #32
    // 0x869dac: stur            x2, [fp, #-8]
    // 0x869db0: r0 = _TabStyle()
    //     0x869db0: bl              #0x869d54  ; Allocate_TabStyleStub -> _TabStyle (size=0x28)
    // 0x869db4: ldr             x1, [fp, #0x18]
    // 0x869db8: StoreField: r0->field_17 = r1
    //     0x869db8: stur            w1, [x0, #0x17]
    // 0x869dbc: ldur            x1, [fp, #-0x10]
    // 0x869dc0: StoreField: r0->field_1b = r1
    //     0x869dc0: stur            w1, [x0, #0x1b]
    // 0x869dc4: ldur            x1, [fp, #-8]
    // 0x869dc8: StoreField: r0->field_1f = r1
    //     0x869dc8: stur            w1, [x0, #0x1f]
    // 0x869dcc: ldr             x1, [fp, #0x20]
    // 0x869dd0: StoreField: r0->field_23 = r1
    //     0x869dd0: stur            w1, [x0, #0x23]
    // 0x869dd4: ldr             x1, [fp, #0x10]
    // 0x869dd8: StoreField: r0->field_b = r1
    //     0x869dd8: stur            w1, [x0, #0xb]
    // 0x869ddc: LeaveFrame
    //     0x869ddc: mov             SP, fp
    //     0x869de0: ldp             fp, lr, [SP], #0x10
    // 0x869de4: ret
    //     0x869de4: ret             
    // 0x869de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869de8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _saveTabOffsets(dynamic, List<double>, TextDirection, double) {
    // ** addr: 0x869df8, size: 0x58
    // 0x869df8: EnterFrame
    //     0x869df8: stp             fp, lr, [SP, #-0x10]!
    //     0x869dfc: mov             fp, SP
    // 0x869e00: ldr             x0, [fp, #0x28]
    // 0x869e04: LoadField: r1 = r0->field_17
    //     0x869e04: ldur            w1, [x0, #0x17]
    // 0x869e08: DecompressPointer r1
    //     0x869e08: add             x1, x1, HEAP, lsl #32
    // 0x869e0c: CheckStackOverflow
    //     0x869e0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x869e10: cmp             SP, x16
    //     0x869e14: b.ls            #0x869e48
    // 0x869e18: LoadField: r0 = r1->field_f
    //     0x869e18: ldur            w0, [x1, #0xf]
    // 0x869e1c: DecompressPointer r0
    //     0x869e1c: add             x0, x0, HEAP, lsl #32
    // 0x869e20: ldr             x16, [fp, #0x20]
    // 0x869e24: stp             x16, x0, [SP, #-0x10]!
    // 0x869e28: ldr             x16, [fp, #0x18]
    // 0x869e2c: ldr             lr, [fp, #0x10]
    // 0x869e30: stp             lr, x16, [SP, #-0x10]!
    // 0x869e34: r0 = _saveTabOffsets()
    //     0x869e34: bl              #0x869e50  ; [package:flutter/src/material/tabs.dart] _TabBarState::_saveTabOffsets
    // 0x869e38: add             SP, SP, #0x20
    // 0x869e3c: LeaveFrame
    //     0x869e3c: mov             SP, fp
    //     0x869e40: ldp             fp, lr, [SP], #0x10
    // 0x869e44: ret
    //     0x869e44: ret             
    // 0x869e48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869e48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869e4c: b               #0x869e18
  }
  _ _saveTabOffsets(/* No info */) {
    // ** addr: 0x869e50, size: 0x78
    // 0x869e50: EnterFrame
    //     0x869e50: stp             fp, lr, [SP, #-0x10]!
    //     0x869e54: mov             fp, SP
    // 0x869e58: CheckStackOverflow
    //     0x869e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x869e5c: cmp             SP, x16
    //     0x869e60: b.ls            #0x869ec0
    // 0x869e64: ldr             x0, [fp, #0x10]
    // 0x869e68: ldr             x1, [fp, #0x28]
    // 0x869e6c: StoreField: r1->field_23 = r0
    //     0x869e6c: stur            w0, [x1, #0x23]
    //     0x869e70: ldurb           w16, [x1, #-1]
    //     0x869e74: ldurb           w17, [x0, #-1]
    //     0x869e78: and             x16, x17, x16, lsr #2
    //     0x869e7c: tst             x16, HEAP, lsr #32
    //     0x869e80: b.eq            #0x869e88
    //     0x869e84: bl              #0xd6826c
    // 0x869e88: LoadField: r0 = r1->field_1b
    //     0x869e88: ldur            w0, [x1, #0x1b]
    // 0x869e8c: DecompressPointer r0
    //     0x869e8c: add             x0, x0, HEAP, lsl #32
    // 0x869e90: cmp             w0, NULL
    // 0x869e94: b.eq            #0x869eb0
    // 0x869e98: ldr             x16, [fp, #0x20]
    // 0x869e9c: stp             x16, x0, [SP, #-0x10]!
    // 0x869ea0: ldr             x16, [fp, #0x18]
    // 0x869ea4: SaveReg r16
    //     0x869ea4: str             x16, [SP, #-8]!
    // 0x869ea8: r0 = saveTabOffsets()
    //     0x869ea8: bl              #0x7bcaa0  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::saveTabOffsets
    // 0x869eac: add             SP, SP, #0x18
    // 0x869eb0: r0 = Null
    //     0x869eb0: mov             x0, NULL
    // 0x869eb4: LeaveFrame
    //     0x869eb4: mov             SP, fp
    //     0x869eb8: ldp             fp, lr, [SP], #0x10
    // 0x869ebc: ret
    //     0x869ebc: ret             
    // 0x869ec0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869ec0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869ec4: b               #0x869e64
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x869ec8, size: 0x68
    // 0x869ec8: EnterFrame
    //     0x869ec8: stp             fp, lr, [SP, #-0x10]!
    //     0x869ecc: mov             fp, SP
    // 0x869ed0: ldr             x0, [fp, #0x10]
    // 0x869ed4: LoadField: r1 = r0->field_17
    //     0x869ed4: ldur            w1, [x0, #0x17]
    // 0x869ed8: DecompressPointer r1
    //     0x869ed8: add             x1, x1, HEAP, lsl #32
    // 0x869edc: CheckStackOverflow
    //     0x869edc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x869ee0: cmp             SP, x16
    //     0x869ee4: b.ls            #0x869f28
    // 0x869ee8: LoadField: r0 = r1->field_b
    //     0x869ee8: ldur            w0, [x1, #0xb]
    // 0x869eec: DecompressPointer r0
    //     0x869eec: add             x0, x0, HEAP, lsl #32
    // 0x869ef0: LoadField: r2 = r0->field_f
    //     0x869ef0: ldur            w2, [x0, #0xf]
    // 0x869ef4: DecompressPointer r2
    //     0x869ef4: add             x2, x2, HEAP, lsl #32
    // 0x869ef8: LoadField: r0 = r1->field_f
    //     0x869ef8: ldur            w0, [x1, #0xf]
    // 0x869efc: DecompressPointer r0
    //     0x869efc: add             x0, x0, HEAP, lsl #32
    // 0x869f00: r1 = LoadInt32Instr(r0)
    //     0x869f00: sbfx            x1, x0, #1, #0x1f
    //     0x869f04: tbz             w0, #0, #0x869f0c
    //     0x869f08: ldur            x1, [x0, #7]
    // 0x869f0c: stp             x1, x2, [SP, #-0x10]!
    // 0x869f10: r0 = _handleTap()
    //     0x869f10: bl              #0x869f30  ; [package:flutter/src/material/tabs.dart] _TabBarState::_handleTap
    // 0x869f14: add             SP, SP, #0x10
    // 0x869f18: r0 = Null
    //     0x869f18: mov             x0, NULL
    // 0x869f1c: LeaveFrame
    //     0x869f1c: mov             SP, fp
    //     0x869f20: ldp             fp, lr, [SP], #0x10
    // 0x869f24: ret
    //     0x869f24: ret             
    // 0x869f28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869f28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869f2c: b               #0x869ee8
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0x869f30, size: 0xb4
    // 0x869f30: EnterFrame
    //     0x869f30: stp             fp, lr, [SP, #-0x10]!
    //     0x869f34: mov             fp, SP
    // 0x869f38: CheckStackOverflow
    //     0x869f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x869f3c: cmp             SP, x16
    //     0x869f40: b.ls            #0x869fd4
    // 0x869f44: ldr             x0, [fp, #0x18]
    // 0x869f48: LoadField: r1 = r0->field_17
    //     0x869f48: ldur            w1, [x0, #0x17]
    // 0x869f4c: DecompressPointer r1
    //     0x869f4c: add             x1, x1, HEAP, lsl #32
    // 0x869f50: cmp             w1, NULL
    // 0x869f54: b.eq            #0x869fdc
    // 0x869f58: SaveReg r1
    //     0x869f58: str             x1, [SP, #-8]!
    // 0x869f5c: ldr             x1, [fp, #0x10]
    // 0x869f60: SaveReg r1
    //     0x869f60: str             x1, [SP, #-8]!
    // 0x869f64: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x869f64: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x869f68: r0 = animateTo()
    //     0x869f68: bl              #0x8262c8  ; [package:flutter/src/material/tab_controller.dart] TabController::animateTo
    // 0x869f6c: add             SP, SP, #0x10
    // 0x869f70: ldr             x0, [fp, #0x18]
    // 0x869f74: LoadField: r1 = r0->field_b
    //     0x869f74: ldur            w1, [x0, #0xb]
    // 0x869f78: DecompressPointer r1
    //     0x869f78: add             x1, x1, HEAP, lsl #32
    // 0x869f7c: cmp             w1, NULL
    // 0x869f80: b.eq            #0x869fe0
    // 0x869f84: LoadField: r2 = r1->field_5f
    //     0x869f84: ldur            w2, [x1, #0x5f]
    // 0x869f88: DecompressPointer r2
    //     0x869f88: add             x2, x2, HEAP, lsl #32
    // 0x869f8c: cmp             w2, NULL
    // 0x869f90: b.eq            #0x869fc4
    // 0x869f94: ldr             x3, [fp, #0x10]
    // 0x869f98: r0 = BoxInt64Instr(r3)
    //     0x869f98: sbfiz           x0, x3, #1, #0x1f
    //     0x869f9c: cmp             x3, x0, asr #1
    //     0x869fa0: b.eq            #0x869fac
    //     0x869fa4: bl              #0xd69bb8
    //     0x869fa8: stur            x3, [x0, #7]
    // 0x869fac: stp             x0, x2, [SP, #-0x10]!
    // 0x869fb0: mov             x0, x2
    // 0x869fb4: ClosureCall
    //     0x869fb4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x869fb8: ldur            x2, [x0, #0x1f]
    //     0x869fbc: blr             x2
    // 0x869fc0: add             SP, SP, #0x10
    // 0x869fc4: r0 = Null
    //     0x869fc4: mov             x0, NULL
    // 0x869fc8: LeaveFrame
    //     0x869fc8: mov             SP, fp
    //     0x869fcc: ldp             fp, lr, [SP], #0x10
    // 0x869fd0: ret
    //     0x869fd0: ret             
    // 0x869fd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x869fd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x869fd8: b               #0x869f44
    // 0x869fdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869fdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x869fe0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x869fe0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x869fe4, size: 0xc8
    // 0x869fe4: EnterFrame
    //     0x869fe4: stp             fp, lr, [SP, #-0x10]!
    //     0x869fe8: mov             fp, SP
    // 0x869fec: AllocStack(0x10)
    //     0x869fec: sub             SP, SP, #0x10
    // 0x869ff0: SetupParameters()
    //     0x869ff0: ldr             x0, [fp, #0x18]
    //     0x869ff4: ldur            w1, [x0, #0x17]
    //     0x869ff8: add             x1, x1, HEAP, lsl #32
    //     0x869ffc: stur            x1, [fp, #-0x10]
    // 0x86a000: CheckStackOverflow
    //     0x86a000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a004: cmp             SP, x16
    //     0x86a008: b.ls            #0x86a0a4
    // 0x86a00c: LoadField: r0 = r1->field_13
    //     0x86a00c: ldur            w0, [x1, #0x13]
    // 0x86a010: DecompressPointer r0
    //     0x86a010: add             x0, x0, HEAP, lsl #32
    // 0x86a014: stur            x0, [fp, #-8]
    // 0x86a018: ldr             x16, [fp, #0x10]
    // 0x86a01c: stp             x16, x0, [SP, #-0x10]!
    // 0x86a020: r0 = addAll()
    //     0x86a020: bl              #0xc79cec  ; [dart:collection] _Set::addAll
    // 0x86a024: add             SP, SP, #0x10
    // 0x86a028: ldur            x0, [fp, #-0x10]
    // 0x86a02c: LoadField: r1 = r0->field_b
    //     0x86a02c: ldur            w1, [x0, #0xb]
    // 0x86a030: DecompressPointer r1
    //     0x86a030: add             x1, x1, HEAP, lsl #32
    // 0x86a034: LoadField: r0 = r1->field_17
    //     0x86a034: ldur            w0, [x1, #0x17]
    // 0x86a038: DecompressPointer r0
    //     0x86a038: add             x0, x0, HEAP, lsl #32
    // 0x86a03c: r1 = LoadClassIdInstr(r0)
    //     0x86a03c: ldur            x1, [x0, #-1]
    //     0x86a040: ubfx            x1, x1, #0xc, #0x14
    // 0x86a044: SaveReg r0
    //     0x86a044: str             x0, [SP, #-8]!
    // 0x86a048: mov             x0, x1
    // 0x86a04c: r0 = GDT[cid_x0 + -0xfbf]()
    //     0x86a04c: sub             lr, x0, #0xfbf
    //     0x86a050: ldr             lr, [x21, lr, lsl #3]
    //     0x86a054: blr             lr
    // 0x86a058: add             SP, SP, #8
    // 0x86a05c: cmp             w0, NULL
    // 0x86a060: b.ne            #0x86a06c
    // 0x86a064: r0 = Null
    //     0x86a064: mov             x0, NULL
    // 0x86a068: b               #0x86a098
    // 0x86a06c: r1 = LoadClassIdInstr(r0)
    //     0x86a06c: ldur            x1, [x0, #-1]
    //     0x86a070: ubfx            x1, x1, #0xc, #0x14
    // 0x86a074: ldur            x16, [fp, #-8]
    // 0x86a078: stp             x16, x0, [SP, #-0x10]!
    // 0x86a07c: mov             x0, x1
    // 0x86a080: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x86a080: mov             x17, #0x5e7
    //     0x86a084: movk            x17, #1, lsl #16
    //     0x86a088: add             lr, x0, x17
    //     0x86a08c: ldr             lr, [x21, lr, lsl #3]
    //     0x86a090: blr             lr
    // 0x86a094: add             SP, SP, #0x10
    // 0x86a098: LeaveFrame
    //     0x86a098: mov             SP, fp
    //     0x86a09c: ldp             fp, lr, [SP], #0x10
    // 0x86a0a0: ret
    //     0x86a0a0: ret             
    // 0x86a0a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86a0a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86a0a8: b               #0x86a00c
  }
  [closure] Center <anonymous closure>(dynamic, int) {
    // ** addr: 0x86a0ac, size: 0x470
    // 0x86a0ac: EnterFrame
    //     0x86a0ac: stp             fp, lr, [SP, #-0x10]!
    //     0x86a0b0: mov             fp, SP
    // 0x86a0b4: AllocStack(0x20)
    //     0x86a0b4: sub             SP, SP, #0x20
    // 0x86a0b8: SetupParameters()
    //     0x86a0b8: ldr             x0, [fp, #0x18]
    //     0x86a0bc: ldur            w1, [x0, #0x17]
    //     0x86a0c0: add             x1, x1, HEAP, lsl #32
    //     0x86a0c4: stur            x1, [fp, #-8]
    // 0x86a0c8: CheckStackOverflow
    //     0x86a0c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a0cc: cmp             SP, x16
    //     0x86a0d0: b.ls            #0x86a4ec
    // 0x86a0d4: LoadField: r0 = r1->field_f
    //     0x86a0d4: ldur            w0, [x1, #0xf]
    // 0x86a0d8: DecompressPointer r0
    //     0x86a0d8: add             x0, x0, HEAP, lsl #32
    // 0x86a0dc: LoadField: r2 = r0->field_b
    //     0x86a0dc: ldur            w2, [x0, #0xb]
    // 0x86a0e0: DecompressPointer r2
    //     0x86a0e0: add             x2, x2, HEAP, lsl #32
    // 0x86a0e4: cmp             w2, NULL
    // 0x86a0e8: b.eq            #0x86a4f4
    // 0x86a0ec: LoadField: r0 = r2->field_b
    //     0x86a0ec: ldur            w0, [x2, #0xb]
    // 0x86a0f0: DecompressPointer r0
    //     0x86a0f0: add             x0, x0, HEAP, lsl #32
    // 0x86a0f4: r2 = LoadClassIdInstr(r0)
    //     0x86a0f4: ldur            x2, [x0, #-1]
    //     0x86a0f8: ubfx            x2, x2, #0xc, #0x14
    // 0x86a0fc: ldr             x16, [fp, #0x10]
    // 0x86a100: stp             x16, x0, [SP, #-0x10]!
    // 0x86a104: mov             x0, x2
    // 0x86a108: r0 = GDT[cid_x0 + -0xd83]()
    //     0x86a108: sub             lr, x0, #0xd83
    //     0x86a10c: ldr             lr, [x21, lr, lsl #3]
    //     0x86a110: blr             lr
    // 0x86a114: add             SP, SP, #0x10
    // 0x86a118: r2 = Null
    //     0x86a118: mov             x2, NULL
    // 0x86a11c: r1 = Null
    //     0x86a11c: mov             x1, NULL
    // 0x86a120: cmp             w0, NULL
    // 0x86a124: b.eq            #0x86a1b0
    // 0x86a128: branchIfSmi(r0, 0x86a1b0)
    //     0x86a128: tbz             w0, #0, #0x86a1b0
    // 0x86a12c: r3 = LoadClassIdInstr(r0)
    //     0x86a12c: ldur            x3, [x0, #-1]
    //     0x86a130: ubfx            x3, x3, #0xc, #0x14
    // 0x86a134: r4 = LoadClassIdInstr(r0)
    //     0x86a134: ldur            x4, [x0, #-1]
    //     0x86a138: ubfx            x4, x4, #0xc, #0x14
    // 0x86a13c: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x86a140: ldr             x3, [x3, #0x18]
    // 0x86a144: ldr             x3, [x3, x4, lsl #3]
    // 0x86a148: LoadField: r3 = r3->field_2b
    //     0x86a148: ldur            w3, [x3, #0x2b]
    // 0x86a14c: DecompressPointer r3
    //     0x86a14c: add             x3, x3, HEAP, lsl #32
    // 0x86a150: cmp             w3, NULL
    // 0x86a154: b.eq            #0x86a1b0
    // 0x86a158: LoadField: r3 = r3->field_f
    //     0x86a158: ldur            w3, [x3, #0xf]
    // 0x86a15c: lsr             x3, x3, #4
    // 0x86a160: r17 = 4450
    //     0x86a160: mov             x17, #0x1162
    // 0x86a164: cmp             x3, x17
    // 0x86a168: b.eq            #0x86a1b8
    // 0x86a16c: r3 = SubtypeTestCache
    //     0x86a16c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37f08] SubtypeTestCache
    //     0x86a170: ldr             x3, [x3, #0xf08]
    // 0x86a174: r24 = Subtype1TestCacheStub
    //     0x86a174: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x86a178: LoadField: r30 = r24->field_7
    //     0x86a178: ldur            lr, [x24, #7]
    // 0x86a17c: blr             lr
    // 0x86a180: cmp             w7, NULL
    // 0x86a184: b.eq            #0x86a190
    // 0x86a188: tbnz            w7, #4, #0x86a1b0
    // 0x86a18c: b               #0x86a1b8
    // 0x86a190: r8 = PreferredSizeWidget
    //     0x86a190: add             x8, PP, #0x37, lsl #12  ; [pp+0x37f10] Type: PreferredSizeWidget
    //     0x86a194: ldr             x8, [x8, #0xf10]
    // 0x86a198: r3 = SubtypeTestCache
    //     0x86a198: add             x3, PP, #0x37, lsl #12  ; [pp+0x37f18] SubtypeTestCache
    //     0x86a19c: ldr             x3, [x3, #0xf18]
    // 0x86a1a0: r24 = InstanceOfStub
    //     0x86a1a0: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x86a1a4: LoadField: r30 = r24->field_7
    //     0x86a1a4: ldur            lr, [x24, #7]
    // 0x86a1a8: blr             lr
    // 0x86a1ac: b               #0x86a1bc
    // 0x86a1b0: r0 = false
    //     0x86a1b0: add             x0, NULL, #0x30  ; false
    // 0x86a1b4: b               #0x86a1bc
    // 0x86a1b8: r0 = true
    //     0x86a1b8: add             x0, NULL, #0x20  ; true
    // 0x86a1bc: tbnz            w0, #4, #0x86a38c
    // 0x86a1c0: ldur            x1, [fp, #-8]
    // 0x86a1c4: LoadField: r0 = r1->field_f
    //     0x86a1c4: ldur            w0, [x1, #0xf]
    // 0x86a1c8: DecompressPointer r0
    //     0x86a1c8: add             x0, x0, HEAP, lsl #32
    // 0x86a1cc: LoadField: r2 = r0->field_b
    //     0x86a1cc: ldur            w2, [x0, #0xb]
    // 0x86a1d0: DecompressPointer r2
    //     0x86a1d0: add             x2, x2, HEAP, lsl #32
    // 0x86a1d4: cmp             w2, NULL
    // 0x86a1d8: b.eq            #0x86a4f8
    // 0x86a1dc: LoadField: r0 = r2->field_b
    //     0x86a1dc: ldur            w0, [x2, #0xb]
    // 0x86a1e0: DecompressPointer r0
    //     0x86a1e0: add             x0, x0, HEAP, lsl #32
    // 0x86a1e4: r2 = LoadClassIdInstr(r0)
    //     0x86a1e4: ldur            x2, [x0, #-1]
    //     0x86a1e8: ubfx            x2, x2, #0xc, #0x14
    // 0x86a1ec: ldr             x16, [fp, #0x10]
    // 0x86a1f0: stp             x16, x0, [SP, #-0x10]!
    // 0x86a1f4: mov             x0, x2
    // 0x86a1f8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x86a1f8: sub             lr, x0, #0xd83
    //     0x86a1fc: ldr             lr, [x21, lr, lsl #3]
    //     0x86a200: blr             lr
    // 0x86a204: add             SP, SP, #0x10
    // 0x86a208: mov             x3, x0
    // 0x86a20c: r2 = Null
    //     0x86a20c: mov             x2, NULL
    // 0x86a210: r1 = Null
    //     0x86a210: mov             x1, NULL
    // 0x86a214: stur            x3, [fp, #-0x10]
    // 0x86a218: r8 = PreferredSizeWidget
    //     0x86a218: add             x8, PP, #0x37, lsl #12  ; [pp+0x37f20] Type: PreferredSizeWidget
    //     0x86a21c: ldr             x8, [x8, #0xf20]
    // 0x86a220: r3 = Null
    //     0x86a220: add             x3, PP, #0x37, lsl #12  ; [pp+0x37f28] Null
    //     0x86a224: ldr             x3, [x3, #0xf28]
    // 0x86a228: r0 = PreferredSizeWidget()
    //     0x86a228: bl              #0x7a03a0  ; IsType_PreferredSizeWidget_Stub
    // 0x86a22c: ldur            x0, [fp, #-8]
    // 0x86a230: LoadField: r1 = r0->field_f
    //     0x86a230: ldur            w1, [x0, #0xf]
    // 0x86a234: DecompressPointer r1
    //     0x86a234: add             x1, x1, HEAP, lsl #32
    // 0x86a238: LoadField: r2 = r1->field_b
    //     0x86a238: ldur            w2, [x1, #0xb]
    // 0x86a23c: DecompressPointer r2
    //     0x86a23c: add             x2, x2, HEAP, lsl #32
    // 0x86a240: cmp             w2, NULL
    // 0x86a244: b.eq            #0x86a4fc
    // 0x86a248: SaveReg r2
    //     0x86a248: str             x2, [SP, #-8]!
    // 0x86a24c: r0 = tabHasTextAndIcon()
    //     0x86a24c: bl              #0x86a51c  ; [package:flutter/src/material/tabs.dart] TabBar::tabHasTextAndIcon
    // 0x86a250: add             SP, SP, #8
    // 0x86a254: tbnz            w0, #4, #0x86a384
    // 0x86a258: ldur            x0, [fp, #-0x10]
    // 0x86a25c: r1 = LoadClassIdInstr(r0)
    //     0x86a25c: ldur            x1, [x0, #-1]
    //     0x86a260: ubfx            x1, x1, #0xc, #0x14
    // 0x86a264: SaveReg r0
    //     0x86a264: str             x0, [SP, #-8]!
    // 0x86a268: mov             x0, x1
    // 0x86a26c: r0 = GDT[cid_x0 + -0xf31]()
    //     0x86a26c: sub             lr, x0, #0xf31
    //     0x86a270: ldr             lr, [x21, lr, lsl #3]
    //     0x86a274: blr             lr
    // 0x86a278: add             SP, SP, #8
    // 0x86a27c: LoadField: d0 = r0->field_f
    //     0x86a27c: ldur            d0, [x0, #0xf]
    // 0x86a280: d1 = 46.000000
    //     0x86a280: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0x86a284: ldr             d1, [x17, #0x9f8]
    // 0x86a288: fcmp            d0, d1
    // 0x86a28c: b.vs            #0x86a384
    // 0x86a290: b.ne            #0x86a384
    // 0x86a294: ldur            x0, [fp, #-8]
    // 0x86a298: LoadField: r1 = r0->field_f
    //     0x86a298: ldur            w1, [x0, #0xf]
    // 0x86a29c: DecompressPointer r1
    //     0x86a29c: add             x1, x1, HEAP, lsl #32
    // 0x86a2a0: LoadField: r2 = r1->field_b
    //     0x86a2a0: ldur            w2, [x1, #0xb]
    // 0x86a2a4: DecompressPointer r2
    //     0x86a2a4: add             x2, x2, HEAP, lsl #32
    // 0x86a2a8: cmp             w2, NULL
    // 0x86a2ac: b.eq            #0x86a500
    // 0x86a2b0: LoadField: r1 = r2->field_47
    //     0x86a2b0: ldur            w1, [x2, #0x47]
    // 0x86a2b4: DecompressPointer r1
    //     0x86a2b4: add             x1, x1, HEAP, lsl #32
    // 0x86a2b8: cmp             w1, NULL
    // 0x86a2bc: b.ne            #0x86a2d8
    // 0x86a2c0: LoadField: r2 = r0->field_13
    //     0x86a2c0: ldur            w2, [x0, #0x13]
    // 0x86a2c4: DecompressPointer r2
    //     0x86a2c4: add             x2, x2, HEAP, lsl #32
    // 0x86a2c8: LoadField: r3 = r2->field_1b
    //     0x86a2c8: ldur            w3, [x2, #0x1b]
    // 0x86a2cc: DecompressPointer r3
    //     0x86a2cc: add             x3, x3, HEAP, lsl #32
    // 0x86a2d0: cmp             w3, NULL
    // 0x86a2d4: b.eq            #0x86a378
    // 0x86a2d8: cmp             w1, NULL
    // 0x86a2dc: b.ne            #0x86a2fc
    // 0x86a2e0: LoadField: r1 = r0->field_13
    //     0x86a2e0: ldur            w1, [x0, #0x13]
    // 0x86a2e4: DecompressPointer r1
    //     0x86a2e4: add             x1, x1, HEAP, lsl #32
    // 0x86a2e8: LoadField: r2 = r1->field_1b
    //     0x86a2e8: ldur            w2, [x1, #0x1b]
    // 0x86a2ec: DecompressPointer r2
    //     0x86a2ec: add             x2, x2, HEAP, lsl #32
    // 0x86a2f0: cmp             w2, NULL
    // 0x86a2f4: b.eq            #0x86a504
    // 0x86a2f8: mov             x1, x2
    // 0x86a2fc: r2 = LoadClassIdInstr(r1)
    //     0x86a2fc: ldur            x2, [x1, #-1]
    //     0x86a300: ubfx            x2, x2, #0xc, #0x14
    // 0x86a304: lsl             x2, x2, #1
    // 0x86a308: r17 = 4204
    //     0x86a308: mov             x17, #0x106c
    // 0x86a30c: cmp             w2, w17
    // 0x86a310: b.ne            #0x86a32c
    // 0x86a314: r16 = Instance_EdgeInsets
    //     0x86a314: add             x16, PP, #0x37, lsl #12  ; [pp+0x37f38] Obj!EdgeInsets@b35c61
    //     0x86a318: ldr             x16, [x16, #0xf38]
    // 0x86a31c: stp             x16, x1, [SP, #-0x10]!
    // 0x86a320: r0 = add()
    //     0x86a320: bl              #0xcfb938  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0x86a324: add             SP, SP, #0x10
    // 0x86a328: b               #0x86a390
    // 0x86a32c: r17 = 4206
    //     0x86a32c: mov             x17, #0x106e
    // 0x86a330: cmp             w2, w17
    // 0x86a334: b.ne            #0x86a350
    // 0x86a338: r16 = Instance_EdgeInsets
    //     0x86a338: add             x16, PP, #0x37, lsl #12  ; [pp+0x37f38] Obj!EdgeInsets@b35c61
    //     0x86a33c: ldr             x16, [x16, #0xf38]
    // 0x86a340: stp             x16, x1, [SP, #-0x10]!
    // 0x86a344: r0 = +()
    //     0x86a344: bl              #0x518b08  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0x86a348: add             SP, SP, #0x10
    // 0x86a34c: b               #0x86a390
    // 0x86a350: r0 = LoadClassIdInstr(r1)
    //     0x86a350: ldur            x0, [x1, #-1]
    //     0x86a354: ubfx            x0, x0, #0xc, #0x14
    // 0x86a358: r16 = Instance_EdgeInsets
    //     0x86a358: add             x16, PP, #0x37, lsl #12  ; [pp+0x37f38] Obj!EdgeInsets@b35c61
    //     0x86a35c: ldr             x16, [x16, #0xf38]
    // 0x86a360: stp             x16, x1, [SP, #-0x10]!
    // 0x86a364: r0 = GDT[cid_x0 + -0xfcc]()
    //     0x86a364: sub             lr, x0, #0xfcc
    //     0x86a368: ldr             lr, [x21, lr, lsl #3]
    //     0x86a36c: blr             lr
    // 0x86a370: add             SP, SP, #0x10
    // 0x86a374: b               #0x86a390
    // 0x86a378: r0 = Instance_EdgeInsets
    //     0x86a378: add             x0, PP, #0x37, lsl #12  ; [pp+0x37f40] Obj!EdgeInsets@b35c31
    //     0x86a37c: ldr             x0, [x0, #0xf40]
    // 0x86a380: b               #0x86a390
    // 0x86a384: r0 = Null
    //     0x86a384: mov             x0, NULL
    // 0x86a388: b               #0x86a390
    // 0x86a38c: r0 = Null
    //     0x86a38c: mov             x0, NULL
    // 0x86a390: cmp             w0, NULL
    // 0x86a394: b.ne            #0x86a3c0
    // 0x86a398: ldur            x1, [fp, #-8]
    // 0x86a39c: LoadField: r0 = r1->field_f
    //     0x86a39c: ldur            w0, [x1, #0xf]
    // 0x86a3a0: DecompressPointer r0
    //     0x86a3a0: add             x0, x0, HEAP, lsl #32
    // 0x86a3a4: LoadField: r2 = r0->field_b
    //     0x86a3a4: ldur            w2, [x0, #0xb]
    // 0x86a3a8: DecompressPointer r2
    //     0x86a3a8: add             x2, x2, HEAP, lsl #32
    // 0x86a3ac: cmp             w2, NULL
    // 0x86a3b0: b.eq            #0x86a508
    // 0x86a3b4: LoadField: r0 = r2->field_47
    //     0x86a3b4: ldur            w0, [x2, #0x47]
    // 0x86a3b8: DecompressPointer r0
    //     0x86a3b8: add             x0, x0, HEAP, lsl #32
    // 0x86a3bc: b               #0x86a3c4
    // 0x86a3c0: ldur            x1, [fp, #-8]
    // 0x86a3c4: cmp             w0, NULL
    // 0x86a3c8: b.ne            #0x86a3e0
    // 0x86a3cc: LoadField: r0 = r1->field_13
    //     0x86a3cc: ldur            w0, [x1, #0x13]
    // 0x86a3d0: DecompressPointer r0
    //     0x86a3d0: add             x0, x0, HEAP, lsl #32
    // 0x86a3d4: LoadField: r2 = r0->field_1b
    //     0x86a3d4: ldur            w2, [x0, #0x1b]
    // 0x86a3d8: DecompressPointer r2
    //     0x86a3d8: add             x2, x2, HEAP, lsl #32
    // 0x86a3dc: mov             x0, x2
    // 0x86a3e0: cmp             w0, NULL
    // 0x86a3e4: b.ne            #0x86a3f4
    // 0x86a3e8: r2 = Instance_EdgeInsets
    //     0x86a3e8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0x86a3ec: ldr             x2, [x2, #0x438]
    // 0x86a3f0: b               #0x86a3f8
    // 0x86a3f4: mov             x2, x0
    // 0x86a3f8: stur            x2, [fp, #-0x10]
    // 0x86a3fc: LoadField: r0 = r1->field_f
    //     0x86a3fc: ldur            w0, [x1, #0xf]
    // 0x86a400: DecompressPointer r0
    //     0x86a400: add             x0, x0, HEAP, lsl #32
    // 0x86a404: LoadField: r3 = r0->field_27
    //     0x86a404: ldur            w3, [x0, #0x27]
    // 0x86a408: DecompressPointer r3
    //     0x86a408: add             x3, x3, HEAP, lsl #32
    // 0x86a40c: r16 = Sentinel
    //     0x86a40c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86a410: cmp             w3, w16
    // 0x86a414: b.eq            #0x86a50c
    // 0x86a418: r0 = LoadClassIdInstr(r3)
    //     0x86a418: ldur            x0, [x3, #-1]
    //     0x86a41c: ubfx            x0, x0, #0xc, #0x14
    // 0x86a420: ldr             x16, [fp, #0x10]
    // 0x86a424: stp             x16, x3, [SP, #-0x10]!
    // 0x86a428: r0 = GDT[cid_x0 + -0xd83]()
    //     0x86a428: sub             lr, x0, #0xd83
    //     0x86a42c: ldr             lr, [x21, lr, lsl #3]
    //     0x86a430: blr             lr
    // 0x86a434: add             SP, SP, #0x10
    // 0x86a438: mov             x1, x0
    // 0x86a43c: ldur            x0, [fp, #-8]
    // 0x86a440: stur            x1, [fp, #-0x18]
    // 0x86a444: LoadField: r2 = r0->field_f
    //     0x86a444: ldur            w2, [x0, #0xf]
    // 0x86a448: DecompressPointer r2
    //     0x86a448: add             x2, x2, HEAP, lsl #32
    // 0x86a44c: LoadField: r0 = r2->field_b
    //     0x86a44c: ldur            w0, [x2, #0xb]
    // 0x86a450: DecompressPointer r0
    //     0x86a450: add             x0, x0, HEAP, lsl #32
    // 0x86a454: cmp             w0, NULL
    // 0x86a458: b.eq            #0x86a518
    // 0x86a45c: LoadField: r2 = r0->field_b
    //     0x86a45c: ldur            w2, [x0, #0xb]
    // 0x86a460: DecompressPointer r2
    //     0x86a460: add             x2, x2, HEAP, lsl #32
    // 0x86a464: r0 = LoadClassIdInstr(r2)
    //     0x86a464: ldur            x0, [x2, #-1]
    //     0x86a468: ubfx            x0, x0, #0xc, #0x14
    // 0x86a46c: ldr             x16, [fp, #0x10]
    // 0x86a470: stp             x16, x2, [SP, #-0x10]!
    // 0x86a474: r0 = GDT[cid_x0 + -0xd83]()
    //     0x86a474: sub             lr, x0, #0xd83
    //     0x86a478: ldr             lr, [x21, lr, lsl #3]
    //     0x86a47c: blr             lr
    // 0x86a480: add             SP, SP, #0x10
    // 0x86a484: stur            x0, [fp, #-8]
    // 0x86a488: r0 = KeyedSubtree()
    //     0x86a488: bl              #0x7a1550  ; AllocateKeyedSubtreeStub -> KeyedSubtree (size=0x10)
    // 0x86a48c: mov             x1, x0
    // 0x86a490: ldur            x0, [fp, #-8]
    // 0x86a494: stur            x1, [fp, #-0x20]
    // 0x86a498: StoreField: r1->field_b = r0
    //     0x86a498: stur            w0, [x1, #0xb]
    // 0x86a49c: ldur            x0, [fp, #-0x18]
    // 0x86a4a0: StoreField: r1->field_7 = r0
    //     0x86a4a0: stur            w0, [x1, #7]
    // 0x86a4a4: r0 = Padding()
    //     0x86a4a4: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x86a4a8: mov             x1, x0
    // 0x86a4ac: ldur            x0, [fp, #-0x10]
    // 0x86a4b0: stur            x1, [fp, #-8]
    // 0x86a4b4: StoreField: r1->field_f = r0
    //     0x86a4b4: stur            w0, [x1, #0xf]
    // 0x86a4b8: ldur            x0, [fp, #-0x20]
    // 0x86a4bc: StoreField: r1->field_b = r0
    //     0x86a4bc: stur            w0, [x1, #0xb]
    // 0x86a4c0: r0 = Center()
    //     0x86a4c0: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x86a4c4: r1 = Instance_Alignment
    //     0x86a4c4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x86a4c8: ldr             x1, [x1, #0xc70]
    // 0x86a4cc: StoreField: r0->field_f = r1
    //     0x86a4cc: stur            w1, [x0, #0xf]
    // 0x86a4d0: r1 = 1.000000
    //     0x86a4d0: ldr             x1, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x86a4d4: StoreField: r0->field_17 = r1
    //     0x86a4d4: stur            w1, [x0, #0x17]
    // 0x86a4d8: ldur            x1, [fp, #-8]
    // 0x86a4dc: StoreField: r0->field_b = r1
    //     0x86a4dc: stur            w1, [x0, #0xb]
    // 0x86a4e0: LeaveFrame
    //     0x86a4e0: mov             SP, fp
    //     0x86a4e4: ldp             fp, lr, [SP], #0x10
    // 0x86a4e8: ret
    //     0x86a4e8: ret             
    // 0x86a4ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86a4ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86a4f0: b               #0x86a0d4
    // 0x86a4f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a4f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a4f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a4f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a4fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a4fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a500: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a504: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a508: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a508: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x86a50c: r9 = _tabKeys
    //     0x86a50c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37f48] Field <_TabBarState@472014024._tabKeys@472014024>: late (offset: 0x28)
    //     0x86a510: ldr             x9, [x9, #0xf48]
    // 0x86a514: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86a514: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86a518: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86a518: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] GlobalKey<State<StatefulWidget>> <anonymous closure>(dynamic, Widget) {
    // ** addr: 0x9d6898, size: 0x1c
    // 0x9d6898: EnterFrame
    //     0x9d6898: stp             fp, lr, [SP, #-0x10]!
    //     0x9d689c: mov             fp, SP
    // 0x9d68a0: r1 = <State<StatefulWidget>>
    //     0x9d68a0: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0x9d68a4: r0 = LabeledGlobalKey()
    //     0x9d68a4: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0x9d68a8: LeaveFrame
    //     0x9d68a8: mov             SP, fp
    //     0x9d68ac: ldp             fp, lr, [SP], #0x10
    // 0x9d68b0: ret
    //     0x9d68b0: ret             
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dbd30, size: 0xb8
    // 0x9dbd30: EnterFrame
    //     0x9dbd30: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbd34: mov             fp, SP
    // 0x9dbd38: AllocStack(0x8)
    //     0x9dbd38: sub             SP, SP, #8
    // 0x9dbd3c: CheckStackOverflow
    //     0x9dbd3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbd40: cmp             SP, x16
    //     0x9dbd44: b.ls            #0x9dbddc
    // 0x9dbd48: ldr             x0, [fp, #0x10]
    // 0x9dbd4c: LoadField: r1 = r0->field_b
    //     0x9dbd4c: ldur            w1, [x0, #0xb]
    // 0x9dbd50: DecompressPointer r1
    //     0x9dbd50: add             x1, x1, HEAP, lsl #32
    // 0x9dbd54: cmp             w1, NULL
    // 0x9dbd58: b.eq            #0x9dbde4
    // 0x9dbd5c: LoadField: r3 = r1->field_b
    //     0x9dbd5c: ldur            w3, [x1, #0xb]
    // 0x9dbd60: DecompressPointer r3
    //     0x9dbd60: add             x3, x3, HEAP, lsl #32
    // 0x9dbd64: stur            x3, [fp, #-8]
    // 0x9dbd68: r1 = Function '<anonymous closure>':.
    //     0x9dbd68: add             x1, PP, #0x37, lsl #12  ; [pp+0x37fe0] AnonymousClosure: (0x9d6898), in [package:flutter/src/material/tabs.dart] _TabBarState::initState (0x9dbd30)
    //     0x9dbd6c: ldr             x1, [x1, #0xfe0]
    // 0x9dbd70: r2 = Null
    //     0x9dbd70: mov             x2, NULL
    // 0x9dbd74: r0 = AllocateClosure()
    //     0x9dbd74: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dbd78: r16 = <GlobalKey<State<StatefulWidget>>>
    //     0x9dbd78: add             x16, PP, #0x37, lsl #12  ; [pp+0x37fb0] TypeArguments: <GlobalKey<State<StatefulWidget>>>
    //     0x9dbd7c: ldr             x16, [x16, #0xfb0]
    // 0x9dbd80: ldur            lr, [fp, #-8]
    // 0x9dbd84: stp             lr, x16, [SP, #-0x10]!
    // 0x9dbd88: SaveReg r0
    //     0x9dbd88: str             x0, [SP, #-8]!
    // 0x9dbd8c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x9dbd8c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x9dbd90: r0 = map()
    //     0x9dbd90: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x9dbd94: add             SP, SP, #0x18
    // 0x9dbd98: SaveReg r0
    //     0x9dbd98: str             x0, [SP, #-8]!
    // 0x9dbd9c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9dbd9c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9dbda0: r0 = toList()
    //     0x9dbda0: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x9dbda4: add             SP, SP, #8
    // 0x9dbda8: ldr             x1, [fp, #0x10]
    // 0x9dbdac: StoreField: r1->field_27 = r0
    //     0x9dbdac: stur            w0, [x1, #0x27]
    //     0x9dbdb0: tbz             w0, #0, #0x9dbdcc
    //     0x9dbdb4: ldurb           w16, [x1, #-1]
    //     0x9dbdb8: ldurb           w17, [x0, #-1]
    //     0x9dbdbc: and             x16, x17, x16, lsr #2
    //     0x9dbdc0: tst             x16, HEAP, lsr #32
    //     0x9dbdc4: b.eq            #0x9dbdcc
    //     0x9dbdc8: bl              #0xd6826c
    // 0x9dbdcc: r0 = Null
    //     0x9dbdcc: mov             x0, NULL
    // 0x9dbdd0: LeaveFrame
    //     0x9dbdd0: mov             SP, fp
    //     0x9dbdd4: ldp             fp, lr, [SP], #0x10
    // 0x9dbdd8: ret
    //     0x9dbdd8: ret             
    // 0x9dbddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbddc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbde0: b               #0x9dbd48
    // 0x9dbde4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbde4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b248, size: 0x18
    // 0xa4b248: r4 = 7
    //     0xa4b248: mov             x4, #7
    // 0xa4b24c: r1 = Function 'dispose':.
    //     0xa4b24c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bef8] AnonymousClosure: (0xa4b260), in [package:flutter/src/material/tabs.dart] _TabBarState::dispose (0xa52d04)
    //     0xa4b250: ldr             x1, [x17, #0xef8]
    // 0xa4b254: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b254: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b258: LoadField: r0 = r24->field_17
    //     0xa4b258: ldur            x0, [x24, #0x17]
    // 0xa4b25c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b260, size: 0x48
    // 0xa4b260: EnterFrame
    //     0xa4b260: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b264: mov             fp, SP
    // 0xa4b268: ldr             x0, [fp, #0x10]
    // 0xa4b26c: LoadField: r1 = r0->field_17
    //     0xa4b26c: ldur            w1, [x0, #0x17]
    // 0xa4b270: DecompressPointer r1
    //     0xa4b270: add             x1, x1, HEAP, lsl #32
    // 0xa4b274: CheckStackOverflow
    //     0xa4b274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b278: cmp             SP, x16
    //     0xa4b27c: b.ls            #0xa4b2a0
    // 0xa4b280: LoadField: r0 = r1->field_f
    //     0xa4b280: ldur            w0, [x1, #0xf]
    // 0xa4b284: DecompressPointer r0
    //     0xa4b284: add             x0, x0, HEAP, lsl #32
    // 0xa4b288: SaveReg r0
    //     0xa4b288: str             x0, [SP, #-8]!
    // 0xa4b28c: r0 = dispose()
    //     0xa4b28c: bl              #0xa52d04  ; [package:flutter/src/material/tabs.dart] _TabBarState::dispose
    // 0xa4b290: add             SP, SP, #8
    // 0xa4b294: LeaveFrame
    //     0xa4b294: mov             SP, fp
    //     0xa4b298: ldp             fp, lr, [SP], #0x10
    // 0xa4b29c: ret
    //     0xa4b29c: ret             
    // 0xa4b2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b2a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b2a4: b               #0xa4b280
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52d04, size: 0x138
    // 0xa52d04: EnterFrame
    //     0xa52d04: stp             fp, lr, [SP, #-0x10]!
    //     0xa52d08: mov             fp, SP
    // 0xa52d0c: AllocStack(0x8)
    //     0xa52d0c: sub             SP, SP, #8
    // 0xa52d10: CheckStackOverflow
    //     0xa52d10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52d14: cmp             SP, x16
    //     0xa52d18: b.ls            #0xa52e24
    // 0xa52d1c: ldr             x0, [fp, #0x10]
    // 0xa52d20: LoadField: r1 = r0->field_1b
    //     0xa52d20: ldur            w1, [x0, #0x1b]
    // 0xa52d24: DecompressPointer r1
    //     0xa52d24: add             x1, x1, HEAP, lsl #32
    // 0xa52d28: cmp             w1, NULL
    // 0xa52d2c: b.eq            #0xa52e2c
    // 0xa52d30: SaveReg r1
    //     0xa52d30: str             x1, [SP, #-8]!
    // 0xa52d34: r0 = Shader._()
    //     0xa52d34: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0xa52d38: add             SP, SP, #8
    // 0xa52d3c: ldr             x16, [fp, #0x10]
    // 0xa52d40: SaveReg r16
    //     0xa52d40: str             x16, [SP, #-8]!
    // 0xa52d44: r0 = _controllerIsValid()
    //     0xa52d44: bl              #0x79f3ec  ; [package:extended_tabs/src/tab_bar.dart] _ExtendedTabBarState::_controllerIsValid
    // 0xa52d48: add             SP, SP, #8
    // 0xa52d4c: tbnz            w0, #4, #0xa52e0c
    // 0xa52d50: ldr             x0, [fp, #0x10]
    // 0xa52d54: LoadField: r1 = r0->field_17
    //     0xa52d54: ldur            w1, [x0, #0x17]
    // 0xa52d58: DecompressPointer r1
    //     0xa52d58: add             x1, x1, HEAP, lsl #32
    // 0xa52d5c: cmp             w1, NULL
    // 0xa52d60: b.eq            #0xa52e30
    // 0xa52d64: LoadField: r2 = r1->field_23
    //     0xa52d64: ldur            w2, [x1, #0x23]
    // 0xa52d68: DecompressPointer r2
    //     0xa52d68: add             x2, x2, HEAP, lsl #32
    // 0xa52d6c: cmp             w2, NULL
    // 0xa52d70: b.ne            #0xa52d7c
    // 0xa52d74: r1 = Null
    //     0xa52d74: mov             x1, NULL
    // 0xa52d78: b               #0xa52d80
    // 0xa52d7c: mov             x1, x2
    // 0xa52d80: stur            x1, [fp, #-8]
    // 0xa52d84: cmp             w1, NULL
    // 0xa52d88: b.eq            #0xa52e34
    // 0xa52d8c: r1 = 1
    //     0xa52d8c: mov             x1, #1
    // 0xa52d90: r0 = AllocateContext()
    //     0xa52d90: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52d94: mov             x1, x0
    // 0xa52d98: ldr             x0, [fp, #0x10]
    // 0xa52d9c: StoreField: r1->field_f = r0
    //     0xa52d9c: stur            w0, [x1, #0xf]
    // 0xa52da0: mov             x2, x1
    // 0xa52da4: r1 = Function '_handleTabControllerAnimationTick@472014024':.
    //     0xa52da4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f68] AnonymousClosure: (0x7bd838), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerAnimationTick (0x7bd880)
    //     0xa52da8: ldr             x1, [x1, #0xf68]
    // 0xa52dac: r0 = AllocateClosure()
    //     0xa52dac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52db0: ldur            x16, [fp, #-8]
    // 0xa52db4: stp             x0, x16, [SP, #-0x10]!
    // 0xa52db8: r0 = removeListener()
    //     0xa52db8: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa52dbc: add             SP, SP, #0x10
    // 0xa52dc0: ldr             x0, [fp, #0x10]
    // 0xa52dc4: LoadField: r1 = r0->field_17
    //     0xa52dc4: ldur            w1, [x0, #0x17]
    // 0xa52dc8: DecompressPointer r1
    //     0xa52dc8: add             x1, x1, HEAP, lsl #32
    // 0xa52dcc: stur            x1, [fp, #-8]
    // 0xa52dd0: cmp             w1, NULL
    // 0xa52dd4: b.eq            #0xa52e38
    // 0xa52dd8: r1 = 1
    //     0xa52dd8: mov             x1, #1
    // 0xa52ddc: r0 = AllocateContext()
    //     0xa52ddc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52de0: mov             x1, x0
    // 0xa52de4: ldr             x0, [fp, #0x10]
    // 0xa52de8: StoreField: r1->field_f = r0
    //     0xa52de8: stur            w0, [x1, #0xf]
    // 0xa52dec: mov             x2, x1
    // 0xa52df0: r1 = Function '_handleTabControllerTick@472014024':.
    //     0xa52df0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37f70] AnonymousClosure: (0x7bd29c), in [package:flutter/src/material/tabs.dart] _TabBarState::_handleTabControllerTick (0x7bd2e4)
    //     0xa52df4: ldr             x1, [x1, #0xf70]
    // 0xa52df8: r0 = AllocateClosure()
    //     0xa52df8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52dfc: ldur            x16, [fp, #-8]
    // 0xa52e00: stp             x0, x16, [SP, #-0x10]!
    // 0xa52e04: r0 = removeListener()
    //     0xa52e04: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa52e08: add             SP, SP, #0x10
    // 0xa52e0c: ldr             x1, [fp, #0x10]
    // 0xa52e10: StoreField: r1->field_17 = rNULL
    //     0xa52e10: stur            NULL, [x1, #0x17]
    // 0xa52e14: r0 = Null
    //     0xa52e14: mov             x0, NULL
    // 0xa52e18: LeaveFrame
    //     0xa52e18: mov             SP, fp
    //     0xa52e1c: ldp             fp, lr, [SP], #0x10
    // 0xa52e20: ret
    //     0xa52e20: ret             
    // 0xa52e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52e28: b               #0xa52d1c
    // 0xa52e2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52e2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa52e30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52e30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa52e34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52e34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa52e38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52e38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa61d9c, size: 0x4c
    // 0xa61d9c: EnterFrame
    //     0xa61d9c: stp             fp, lr, [SP, #-0x10]!
    //     0xa61da0: mov             fp, SP
    // 0xa61da4: CheckStackOverflow
    //     0xa61da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa61da8: cmp             SP, x16
    //     0xa61dac: b.ls            #0xa61de0
    // 0xa61db0: ldr             x16, [fp, #0x10]
    // 0xa61db4: SaveReg r16
    //     0xa61db4: str             x16, [SP, #-8]!
    // 0xa61db8: r0 = _updateTabController()
    //     0xa61db8: bl              #0x7bcf90  ; [package:flutter/src/material/tabs.dart] _TabBarState::_updateTabController
    // 0xa61dbc: add             SP, SP, #8
    // 0xa61dc0: ldr             x16, [fp, #0x10]
    // 0xa61dc4: SaveReg r16
    //     0xa61dc4: str             x16, [SP, #-8]!
    // 0xa61dc8: r0 = _initIndicatorPainter()
    //     0xa61dc8: bl              #0x7bc648  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initIndicatorPainter
    // 0xa61dcc: add             SP, SP, #8
    // 0xa61dd0: r0 = Null
    //     0xa61dd0: mov             x0, NULL
    // 0xa61dd4: LeaveFrame
    //     0xa61dd4: mov             SP, fp
    //     0xa61dd8: ldp             fp, lr, [SP], #0x10
    // 0xa61ddc: ret
    //     0xa61ddc: ret             
    // 0xa61de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa61de0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa61de4: b               #0xa61db0
  }
  _ _initialScrollOffset(/* No info */) {
    // ** addr: 0xc740dc, size: 0x60
    // 0xc740dc: EnterFrame
    //     0xc740dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc740e0: mov             fp, SP
    // 0xc740e4: CheckStackOverflow
    //     0xc740e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc740e8: cmp             SP, x16
    //     0xc740ec: b.ls            #0xc74130
    // 0xc740f0: ldr             x0, [fp, #0x28]
    // 0xc740f4: LoadField: r1 = r0->field_1f
    //     0xc740f4: ldur            w1, [x0, #0x1f]
    // 0xc740f8: DecompressPointer r1
    //     0xc740f8: add             x1, x1, HEAP, lsl #32
    // 0xc740fc: cmp             w1, NULL
    // 0xc74100: b.eq            #0xc74138
    // 0xc74104: stp             x1, x0, [SP, #-0x10]!
    // 0xc74108: ldr             x16, [fp, #0x20]
    // 0xc7410c: ldr             lr, [fp, #0x18]
    // 0xc74110: stp             lr, x16, [SP, #-0x10]!
    // 0xc74114: ldr             d0, [fp, #0x10]
    // 0xc74118: SaveReg d0
    //     0xc74118: str             d0, [SP, #-8]!
    // 0xc7411c: r0 = _tabScrollOffset()
    //     0xc7411c: bl              #0x7bd5b4  ; [package:flutter/src/material/tabs.dart] _TabBarState::_tabScrollOffset
    // 0xc74120: add             SP, SP, #0x28
    // 0xc74124: LeaveFrame
    //     0xc74124: mov             SP, fp
    //     0xc74128: ldp             fp, lr, [SP], #0x10
    // 0xc7412c: ret
    //     0xc7412c: ret             
    // 0xc74130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc74130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc74134: b               #0xc740f0
    // 0xc74138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc74138: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3588, size: 0x34, field offset: 0x30
class _TabLabelBar extends Flex {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6dd98c, size: 0xac
    // 0x6dd98c: EnterFrame
    //     0x6dd98c: stp             fp, lr, [SP, #-0x10]!
    //     0x6dd990: mov             fp, SP
    // 0x6dd994: CheckStackOverflow
    //     0x6dd994: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dd998: cmp             SP, x16
    //     0x6dd99c: b.ls            #0x6dda30
    // 0x6dd9a0: ldr             x0, [fp, #0x10]
    // 0x6dd9a4: r2 = Null
    //     0x6dd9a4: mov             x2, NULL
    // 0x6dd9a8: r1 = Null
    //     0x6dd9a8: mov             x1, NULL
    // 0x6dd9ac: r4 = 59
    //     0x6dd9ac: mov             x4, #0x3b
    // 0x6dd9b0: branchIfSmi(r0, 0x6dd9bc)
    //     0x6dd9b0: tbz             w0, #0, #0x6dd9bc
    // 0x6dd9b4: r4 = LoadClassIdInstr(r0)
    //     0x6dd9b4: ldur            x4, [x0, #-1]
    //     0x6dd9b8: ubfx            x4, x4, #0xc, #0x14
    // 0x6dd9bc: cmp             x4, #0x9ee
    // 0x6dd9c0: b.eq            #0x6dd9d8
    // 0x6dd9c4: r8 = _TabLabelBarRenderer
    //     0x6dd9c4: add             x8, PP, #0x40, lsl #12  ; [pp+0x40ce0] Type: _TabLabelBarRenderer
    //     0x6dd9c8: ldr             x8, [x8, #0xce0]
    // 0x6dd9cc: r3 = Null
    //     0x6dd9cc: add             x3, PP, #0x40, lsl #12  ; [pp+0x40ce8] Null
    //     0x6dd9d0: ldr             x3, [x3, #0xce8]
    // 0x6dd9d4: r0 = DefaultTypeTest()
    //     0x6dd9d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6dd9d8: ldr             x16, [fp, #0x20]
    // 0x6dd9dc: ldr             lr, [fp, #0x18]
    // 0x6dd9e0: stp             lr, x16, [SP, #-0x10]!
    // 0x6dd9e4: ldr             x16, [fp, #0x10]
    // 0x6dd9e8: SaveReg r16
    //     0x6dd9e8: str             x16, [SP, #-8]!
    // 0x6dd9ec: r0 = updateRenderObject()
    //     0x6dd9ec: bl              #0x6dda38  ; [package:flutter/src/widgets/basic.dart] Flex::updateRenderObject
    // 0x6dd9f0: add             SP, SP, #0x18
    // 0x6dd9f4: ldr             x1, [fp, #0x20]
    // 0x6dd9f8: LoadField: r0 = r1->field_2f
    //     0x6dd9f8: ldur            w0, [x1, #0x2f]
    // 0x6dd9fc: DecompressPointer r0
    //     0x6dd9fc: add             x0, x0, HEAP, lsl #32
    // 0x6dda00: ldr             x1, [fp, #0x10]
    // 0x6dda04: StoreField: r1->field_9f = r0
    //     0x6dda04: stur            w0, [x1, #0x9f]
    //     0x6dda08: ldurb           w16, [x1, #-1]
    //     0x6dda0c: ldurb           w17, [x0, #-1]
    //     0x6dda10: and             x16, x17, x16, lsr #2
    //     0x6dda14: tst             x16, HEAP, lsr #32
    //     0x6dda18: b.eq            #0x6dda20
    //     0x6dda1c: bl              #0xd6826c
    // 0x6dda20: r0 = Null
    //     0x6dda20: mov             x0, NULL
    // 0x6dda24: LeaveFrame
    //     0x6dda24: mov             SP, fp
    //     0x6dda28: ldp             fp, lr, [SP], #0x10
    // 0x6dda2c: ret
    //     0x6dda2c: ret             
    // 0x6dda30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dda30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dda34: b               #0x6dd9a0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6f2c54, size: 0xd4
    // 0x6f2c54: EnterFrame
    //     0x6f2c54: stp             fp, lr, [SP, #-0x10]!
    //     0x6f2c58: mov             fp, SP
    // 0x6f2c5c: AllocStack(0x38)
    //     0x6f2c5c: sub             SP, SP, #0x38
    // 0x6f2c60: CheckStackOverflow
    //     0x6f2c60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f2c64: cmp             SP, x16
    //     0x6f2c68: b.ls            #0x6f2d1c
    // 0x6f2c6c: ldr             x0, [fp, #0x18]
    // 0x6f2c70: LoadField: r1 = r0->field_f
    //     0x6f2c70: ldur            w1, [x0, #0xf]
    // 0x6f2c74: DecompressPointer r1
    //     0x6f2c74: add             x1, x1, HEAP, lsl #32
    // 0x6f2c78: stur            x1, [fp, #-0x20]
    // 0x6f2c7c: LoadField: r2 = r0->field_13
    //     0x6f2c7c: ldur            w2, [x0, #0x13]
    // 0x6f2c80: DecompressPointer r2
    //     0x6f2c80: add             x2, x2, HEAP, lsl #32
    // 0x6f2c84: stur            x2, [fp, #-0x18]
    // 0x6f2c88: LoadField: r3 = r0->field_17
    //     0x6f2c88: ldur            w3, [x0, #0x17]
    // 0x6f2c8c: DecompressPointer r3
    //     0x6f2c8c: add             x3, x3, HEAP, lsl #32
    // 0x6f2c90: stur            x3, [fp, #-0x10]
    // 0x6f2c94: LoadField: r4 = r0->field_1b
    //     0x6f2c94: ldur            w4, [x0, #0x1b]
    // 0x6f2c98: DecompressPointer r4
    //     0x6f2c98: add             x4, x4, HEAP, lsl #32
    // 0x6f2c9c: stur            x4, [fp, #-8]
    // 0x6f2ca0: ldr             x16, [fp, #0x10]
    // 0x6f2ca4: stp             x16, x0, [SP, #-0x10]!
    // 0x6f2ca8: r0 = getEffectiveTextDirection()
    //     0x6f2ca8: bl              #0x6ddc60  ; [package:flutter/src/widgets/basic.dart] Flex::getEffectiveTextDirection
    // 0x6f2cac: add             SP, SP, #0x10
    // 0x6f2cb0: stur            x0, [fp, #-0x30]
    // 0x6f2cb4: cmp             w0, NULL
    // 0x6f2cb8: b.eq            #0x6f2d24
    // 0x6f2cbc: ldr             x1, [fp, #0x18]
    // 0x6f2cc0: LoadField: r2 = r1->field_2f
    //     0x6f2cc0: ldur            w2, [x1, #0x2f]
    // 0x6f2cc4: DecompressPointer r2
    //     0x6f2cc4: add             x2, x2, HEAP, lsl #32
    // 0x6f2cc8: stur            x2, [fp, #-0x28]
    // 0x6f2ccc: r0 = _TabLabelBarRenderer()
    //     0x6f2ccc: bl              #0x6f2d28  ; Allocate_TabLabelBarRendererStub -> _TabLabelBarRenderer (size=0xa4)
    // 0x6f2cd0: mov             x1, x0
    // 0x6f2cd4: ldur            x0, [fp, #-0x28]
    // 0x6f2cd8: stur            x1, [fp, #-0x38]
    // 0x6f2cdc: StoreField: r1->field_9f = r0
    //     0x6f2cdc: stur            w0, [x1, #0x9f]
    // 0x6f2ce0: ldur            x16, [fp, #-8]
    // 0x6f2ce4: stp             x16, x1, [SP, #-0x10]!
    // 0x6f2ce8: ldur            x16, [fp, #-0x20]
    // 0x6f2cec: ldur            lr, [fp, #-0x18]
    // 0x6f2cf0: stp             lr, x16, [SP, #-0x10]!
    // 0x6f2cf4: ldur            x16, [fp, #-0x10]
    // 0x6f2cf8: ldur            lr, [fp, #-0x30]
    // 0x6f2cfc: stp             lr, x16, [SP, #-0x10]!
    // 0x6f2d00: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0x6f2d00: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0x6f2d04: r0 = RenderFlex()
    //     0x6f2d04: bl              #0x6f297c  ; [package:flutter/src/rendering/flex.dart] RenderFlex::RenderFlex
    // 0x6f2d08: add             SP, SP, #0x30
    // 0x6f2d0c: ldur            x0, [fp, #-0x38]
    // 0x6f2d10: LeaveFrame
    //     0x6f2d10: mov             SP, fp
    //     0x6f2d14: ldp             fp, lr, [SP], #0x10
    // 0x6f2d18: ret
    //     0x6f2d18: ret             
    // 0x6f2d1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f2d1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f2d20: b               #0x6f2c6c
    // 0x6f2d24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f2d24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3843, size: 0x20, field offset: 0xc
//   const constructor, 
class Tab extends StatelessWidget
    implements PreferredSizeWidget {

  _ build(/* No info */) {
    // ** addr: 0xb23f70, size: 0x1e0
    // 0xb23f70: EnterFrame
    //     0xb23f70: stp             fp, lr, [SP, #-0x10]!
    //     0xb23f74: mov             fp, SP
    // 0xb23f78: AllocStack(0x20)
    //     0xb23f78: sub             SP, SP, #0x20
    // 0xb23f7c: CheckStackOverflow
    //     0xb23f7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23f80: cmp             SP, x16
    //     0xb23f84: b.ls            #0xb2412c
    // 0xb23f88: ldr             x0, [fp, #0x18]
    // 0xb23f8c: LoadField: r1 = r0->field_13
    //     0xb23f8c: ldur            w1, [x0, #0x13]
    // 0xb23f90: DecompressPointer r1
    //     0xb23f90: add             x1, x1, HEAP, lsl #32
    // 0xb23f94: stur            x1, [fp, #-0x10]
    // 0xb23f98: cmp             w1, NULL
    // 0xb23f9c: b.ne            #0xb23fc0
    // 0xb23fa0: LoadField: r1 = r0->field_f
    //     0xb23fa0: ldur            w1, [x0, #0xf]
    // 0xb23fa4: DecompressPointer r1
    //     0xb23fa4: add             x1, x1, HEAP, lsl #32
    // 0xb23fa8: cmp             w1, NULL
    // 0xb23fac: b.eq            #0xb24114
    // 0xb23fb0: mov             x0, x1
    // 0xb23fb4: d0 = 46.000000
    //     0xb23fb4: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0xb23fb8: ldr             d0, [x17, #0x9f8]
    // 0xb23fbc: b               #0xb24094
    // 0xb23fc0: r2 = Null
    //     0xb23fc0: mov             x2, NULL
    // 0xb23fc4: LoadField: r3 = r0->field_f
    //     0xb23fc4: ldur            w3, [x0, #0xf]
    // 0xb23fc8: DecompressPointer r3
    //     0xb23fc8: add             x3, x3, HEAP, lsl #32
    // 0xb23fcc: stur            x3, [fp, #-8]
    // 0xb23fd0: cmp             w3, NULL
    // 0xb23fd4: b.ne            #0xb23fe8
    // 0xb23fd8: mov             x0, x1
    // 0xb23fdc: d0 = 46.000000
    //     0xb23fdc: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0xb23fe0: ldr             d0, [x17, #0x9f8]
    // 0xb23fe4: b               #0xb24094
    // 0xb23fe8: r0 = Container()
    //     0xb23fe8: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb23fec: stur            x0, [fp, #-0x18]
    // 0xb23ff0: r16 = Instance_EdgeInsets
    //     0xb23ff0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c500] Obj!EdgeInsets@b35bd1
    //     0xb23ff4: ldr             x16, [x16, #0x500]
    // 0xb23ff8: stp             x16, x0, [SP, #-0x10]!
    // 0xb23ffc: ldur            x16, [fp, #-0x10]
    // 0xb24000: SaveReg r16
    //     0xb24000: str             x16, [SP, #-8]!
    // 0xb24004: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, margin, 0x1, null]
    //     0xb24004: add             x4, PP, #0xe, lsl #12  ; [pp+0xee98] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "margin", 0x1, Null]
    //     0xb24008: ldr             x4, [x4, #0xe98]
    // 0xb2400c: r0 = Container()
    //     0xb2400c: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb24010: add             SP, SP, #0x18
    // 0xb24014: r1 = Null
    //     0xb24014: mov             x1, NULL
    // 0xb24018: r2 = 4
    //     0xb24018: mov             x2, #4
    // 0xb2401c: r0 = AllocateArray()
    //     0xb2401c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb24020: mov             x2, x0
    // 0xb24024: ldur            x0, [fp, #-0x18]
    // 0xb24028: stur            x2, [fp, #-0x10]
    // 0xb2402c: StoreField: r2->field_f = r0
    //     0xb2402c: stur            w0, [x2, #0xf]
    // 0xb24030: ldur            x0, [fp, #-8]
    // 0xb24034: StoreField: r2->field_13 = r0
    //     0xb24034: stur            w0, [x2, #0x13]
    // 0xb24038: r1 = <Widget>
    //     0xb24038: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb2403c: ldr             x1, [x1, #0xea8]
    // 0xb24040: r0 = AllocateGrowableArray()
    //     0xb24040: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xb24044: mov             x1, x0
    // 0xb24048: ldur            x0, [fp, #-0x10]
    // 0xb2404c: stur            x1, [fp, #-8]
    // 0xb24050: StoreField: r1->field_f = r0
    //     0xb24050: stur            w0, [x1, #0xf]
    // 0xb24054: r0 = 4
    //     0xb24054: mov             x0, #4
    // 0xb24058: StoreField: r1->field_b = r0
    //     0xb24058: stur            w0, [x1, #0xb]
    // 0xb2405c: r0 = Column()
    //     0xb2405c: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0xb24060: stur            x0, [fp, #-0x10]
    // 0xb24064: ldur            x16, [fp, #-8]
    // 0xb24068: stp             x16, x0, [SP, #-0x10]!
    // 0xb2406c: r16 = Instance_MainAxisAlignment
    //     0xb2406c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c518] Obj!MainAxisAlignment@b64b11
    //     0xb24070: ldr             x16, [x16, #0x518]
    // 0xb24074: SaveReg r16
    //     0xb24074: str             x16, [SP, #-8]!
    // 0xb24078: r4 = const [0, 0x3, 0x3, 0x2, mainAxisAlignment, 0x2, null]
    //     0xb24078: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c3c8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisAlignment", 0x2, Null]
    //     0xb2407c: ldr             x4, [x4, #0x3c8]
    // 0xb24080: r0 = Column()
    //     0xb24080: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0xb24084: add             SP, SP, #0x18
    // 0xb24088: ldur            x0, [fp, #-0x10]
    // 0xb2408c: d0 = 72.000000
    //     0xb2408c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0xb24090: ldr             d0, [x17, #0xdb0]
    // 0xb24094: stur            x0, [fp, #-8]
    // 0xb24098: stur            d0, [fp, #-0x20]
    // 0xb2409c: r0 = Center()
    //     0xb2409c: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xb240a0: mov             x1, x0
    // 0xb240a4: r0 = Instance_Alignment
    //     0xb240a4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb240a8: ldr             x0, [x0, #0xc70]
    // 0xb240ac: stur            x1, [fp, #-0x10]
    // 0xb240b0: StoreField: r1->field_f = r0
    //     0xb240b0: stur            w0, [x1, #0xf]
    // 0xb240b4: r0 = 1.000000
    //     0xb240b4: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb240b8: StoreField: r1->field_13 = r0
    //     0xb240b8: stur            w0, [x1, #0x13]
    // 0xb240bc: ldur            x0, [fp, #-8]
    // 0xb240c0: StoreField: r1->field_b = r0
    //     0xb240c0: stur            w0, [x1, #0xb]
    // 0xb240c4: ldur            d0, [fp, #-0x20]
    // 0xb240c8: r0 = inline_Allocate_Double()
    //     0xb240c8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xb240cc: add             x0, x0, #0x10
    //     0xb240d0: cmp             x2, x0
    //     0xb240d4: b.ls            #0xb24134
    //     0xb240d8: str             x0, [THR, #0x60]  ; THR::top
    //     0xb240dc: sub             x0, x0, #0xf
    //     0xb240e0: mov             x2, #0xd108
    //     0xb240e4: movk            x2, #3, lsl #16
    //     0xb240e8: stur            x2, [x0, #-1]
    // 0xb240ec: StoreField: r0->field_7 = d0
    //     0xb240ec: stur            d0, [x0, #7]
    // 0xb240f0: stur            x0, [fp, #-8]
    // 0xb240f4: r0 = SizedBox()
    //     0xb240f4: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb240f8: ldur            x1, [fp, #-8]
    // 0xb240fc: StoreField: r0->field_13 = r1
    //     0xb240fc: stur            w1, [x0, #0x13]
    // 0xb24100: ldur            x1, [fp, #-0x10]
    // 0xb24104: StoreField: r0->field_b = r1
    //     0xb24104: stur            w1, [x0, #0xb]
    // 0xb24108: LeaveFrame
    //     0xb24108: mov             SP, fp
    //     0xb2410c: ldp             fp, lr, [SP], #0x10
    // 0xb24110: ret
    //     0xb24110: ret             
    // 0xb24114: r2 = Null
    //     0xb24114: mov             x2, NULL
    // 0xb24118: cmp             w2, NULL
    // 0xb2411c: b.eq            #0xb2414c
    // 0xb24120: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0xb24120: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0xb24124: r0 = Throw()
    //     0xb24124: bl              #0xd67e38  ; ThrowStub
    // 0xb24128: brk             #0
    // 0xb2412c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb2412c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24130: b               #0xb23f88
    // 0xb24134: SaveReg d0
    //     0xb24134: str             q0, [SP, #-0x10]!
    // 0xb24138: SaveReg r1
    //     0xb24138: str             x1, [SP, #-8]!
    // 0xb2413c: r0 = AllocateDouble()
    //     0xb2413c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb24140: RestoreReg r1
    //     0xb24140: ldr             x1, [SP], #8
    // 0xb24144: RestoreReg d0
    //     0xb24144: ldr             q0, [SP], #0x10
    // 0xb24148: b               #0xb240ec
    // 0xb2414c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb2414c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ preferredSize(/* No info */) {
    // ** addr: 0xcc3b3c, size: 0x3c
    // 0xcc3b3c: ldr             x1, [SP]
    // 0xcc3b40: LoadField: r2 = r1->field_f
    //     0xcc3b40: ldur            w2, [x1, #0xf]
    // 0xcc3b44: DecompressPointer r2
    //     0xcc3b44: add             x2, x2, HEAP, lsl #32
    // 0xcc3b48: cmp             w2, NULL
    // 0xcc3b4c: b.eq            #0xcc3b6c
    // 0xcc3b50: LoadField: r2 = r1->field_13
    //     0xcc3b50: ldur            w2, [x1, #0x13]
    // 0xcc3b54: DecompressPointer r2
    //     0xcc3b54: add             x2, x2, HEAP, lsl #32
    // 0xcc3b58: cmp             w2, NULL
    // 0xcc3b5c: b.eq            #0xcc3b6c
    // 0xcc3b60: r0 = Instance_Size
    //     0xcc3b60: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2ede0] Obj!Size@b5eed1
    //     0xcc3b64: ldr             x0, [x0, #0xde0]
    // 0xcc3b68: ret
    //     0xcc3b68: ret             
    // 0xcc3b6c: r0 = Instance_Size
    //     0xcc3b6c: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2ede8] Obj!Size@b5eeb1
    //     0xcc3b70: ldr             x0, [x0, #0xde8]
    // 0xcc3b74: ret
    //     0xcc3b74: ret             
  }
}

// class id: 4116, size: 0x28, field offset: 0xc
//   const constructor, 
class TabBarView extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa41738, size: 0x38
    // 0xa41738: EnterFrame
    //     0xa41738: stp             fp, lr, [SP, #-0x10]!
    //     0xa4173c: mov             fp, SP
    // 0xa41740: r1 = <TabBarView>
    //     0xa41740: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2edd8] TypeArguments: <TabBarView>
    //     0xa41744: ldr             x1, [x1, #0xdd8]
    // 0xa41748: r0 = _TabBarViewState()
    //     0xa41748: bl              #0xa41770  ; Allocate_TabBarViewStateStub -> _TabBarViewState (size=0x30)
    // 0xa4174c: r1 = Sentinel
    //     0xa4174c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa41750: StoreField: r0->field_17 = r1
    //     0xa41750: stur            w1, [x0, #0x17]
    // 0xa41754: StoreField: r0->field_1b = r1
    //     0xa41754: stur            w1, [x0, #0x1b]
    // 0xa41758: StoreField: r0->field_1f = r1
    //     0xa41758: stur            w1, [x0, #0x1f]
    // 0xa4175c: r1 = 0
    //     0xa4175c: mov             x1, #0
    // 0xa41760: StoreField: r0->field_27 = r1
    //     0xa41760: stur            x1, [x0, #0x27]
    // 0xa41764: LeaveFrame
    //     0xa41764: mov             SP, fp
    //     0xa41768: ldp             fp, lr, [SP], #0x10
    // 0xa4176c: ret
    //     0xa4176c: ret             
  }
}

// class id: 4117, size: 0x70, field offset: 0xc
//   const constructor, 
class TabBar extends StatefulWidget
    implements PreferredSizeWidget {

  get _ tabHasTextAndIcon(/* No info */) {
    // ** addr: 0x86a51c, size: 0x1c4
    // 0x86a51c: EnterFrame
    //     0x86a51c: stp             fp, lr, [SP, #-0x10]!
    //     0x86a520: mov             fp, SP
    // 0x86a524: AllocStack(0x10)
    //     0x86a524: sub             SP, SP, #0x10
    // 0x86a528: CheckStackOverflow
    //     0x86a528: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a52c: cmp             SP, x16
    //     0x86a530: b.ls            #0x86a6d0
    // 0x86a534: ldr             x0, [fp, #0x10]
    // 0x86a538: LoadField: r1 = r0->field_b
    //     0x86a538: ldur            w1, [x0, #0xb]
    // 0x86a53c: DecompressPointer r1
    //     0x86a53c: add             x1, x1, HEAP, lsl #32
    // 0x86a540: r0 = LoadClassIdInstr(r1)
    //     0x86a540: ldur            x0, [x1, #-1]
    //     0x86a544: ubfx            x0, x0, #0xc, #0x14
    // 0x86a548: SaveReg r1
    //     0x86a548: str             x1, [SP, #-8]!
    // 0x86a54c: r0 = GDT[cid_x0 + 0xb940]()
    //     0x86a54c: mov             x17, #0xb940
    //     0x86a550: add             lr, x0, x17
    //     0x86a554: ldr             lr, [x21, lr, lsl #3]
    //     0x86a558: blr             lr
    // 0x86a55c: add             SP, SP, #8
    // 0x86a560: mov             x1, x0
    // 0x86a564: stur            x1, [fp, #-8]
    // 0x86a568: CheckStackOverflow
    //     0x86a568: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86a56c: cmp             SP, x16
    //     0x86a570: b.ls            #0x86a6d8
    // 0x86a574: r0 = LoadClassIdInstr(r1)
    //     0x86a574: ldur            x0, [x1, #-1]
    //     0x86a578: ubfx            x0, x0, #0xc, #0x14
    // 0x86a57c: SaveReg r1
    //     0x86a57c: str             x1, [SP, #-8]!
    // 0x86a580: r0 = GDT[cid_x0 + 0x541]()
    //     0x86a580: add             lr, x0, #0x541
    //     0x86a584: ldr             lr, [x21, lr, lsl #3]
    //     0x86a588: blr             lr
    // 0x86a58c: add             SP, SP, #8
    // 0x86a590: tbnz            w0, #4, #0x86a6c0
    // 0x86a594: ldur            x1, [fp, #-8]
    // 0x86a598: r0 = LoadClassIdInstr(r1)
    //     0x86a598: ldur            x0, [x1, #-1]
    //     0x86a59c: ubfx            x0, x0, #0xc, #0x14
    // 0x86a5a0: SaveReg r1
    //     0x86a5a0: str             x1, [SP, #-8]!
    // 0x86a5a4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x86a5a4: add             lr, x0, #0x5ca
    //     0x86a5a8: ldr             lr, [x21, lr, lsl #3]
    //     0x86a5ac: blr             lr
    // 0x86a5b0: add             SP, SP, #8
    // 0x86a5b4: mov             x3, x0
    // 0x86a5b8: r2 = Null
    //     0x86a5b8: mov             x2, NULL
    // 0x86a5bc: r1 = Null
    //     0x86a5bc: mov             x1, NULL
    // 0x86a5c0: stur            x3, [fp, #-0x10]
    // 0x86a5c4: cmp             w0, NULL
    // 0x86a5c8: b.eq            #0x86a654
    // 0x86a5cc: branchIfSmi(r0, 0x86a654)
    //     0x86a5cc: tbz             w0, #0, #0x86a654
    // 0x86a5d0: r3 = LoadClassIdInstr(r0)
    //     0x86a5d0: ldur            x3, [x0, #-1]
    //     0x86a5d4: ubfx            x3, x3, #0xc, #0x14
    // 0x86a5d8: r4 = LoadClassIdInstr(r0)
    //     0x86a5d8: ldur            x4, [x0, #-1]
    //     0x86a5dc: ubfx            x4, x4, #0xc, #0x14
    // 0x86a5e0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0x86a5e4: ldr             x3, [x3, #0x18]
    // 0x86a5e8: ldr             x3, [x3, x4, lsl #3]
    // 0x86a5ec: LoadField: r3 = r3->field_2b
    //     0x86a5ec: ldur            w3, [x3, #0x2b]
    // 0x86a5f0: DecompressPointer r3
    //     0x86a5f0: add             x3, x3, HEAP, lsl #32
    // 0x86a5f4: cmp             w3, NULL
    // 0x86a5f8: b.eq            #0x86a654
    // 0x86a5fc: LoadField: r3 = r3->field_f
    //     0x86a5fc: ldur            w3, [x3, #0xf]
    // 0x86a600: lsr             x3, x3, #4
    // 0x86a604: r17 = 4450
    //     0x86a604: mov             x17, #0x1162
    // 0x86a608: cmp             x3, x17
    // 0x86a60c: b.eq            #0x86a65c
    // 0x86a610: r3 = SubtypeTestCache
    //     0x86a610: add             x3, PP, #0x37, lsl #12  ; [pp+0x37f50] SubtypeTestCache
    //     0x86a614: ldr             x3, [x3, #0xf50]
    // 0x86a618: r24 = Subtype1TestCacheStub
    //     0x86a618: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0x86a61c: LoadField: r30 = r24->field_7
    //     0x86a61c: ldur            lr, [x24, #7]
    // 0x86a620: blr             lr
    // 0x86a624: cmp             w7, NULL
    // 0x86a628: b.eq            #0x86a634
    // 0x86a62c: tbnz            w7, #4, #0x86a654
    // 0x86a630: b               #0x86a65c
    // 0x86a634: r8 = PreferredSizeWidget
    //     0x86a634: add             x8, PP, #0x37, lsl #12  ; [pp+0x37f58] Type: PreferredSizeWidget
    //     0x86a638: ldr             x8, [x8, #0xf58]
    // 0x86a63c: r3 = SubtypeTestCache
    //     0x86a63c: add             x3, PP, #0x37, lsl #12  ; [pp+0x37f60] SubtypeTestCache
    //     0x86a640: ldr             x3, [x3, #0xf60]
    // 0x86a644: r24 = InstanceOfStub
    //     0x86a644: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x86a648: LoadField: r30 = r24->field_7
    //     0x86a648: ldur            lr, [x24, #7]
    // 0x86a64c: blr             lr
    // 0x86a650: b               #0x86a660
    // 0x86a654: r0 = false
    //     0x86a654: add             x0, NULL, #0x30  ; false
    // 0x86a658: b               #0x86a660
    // 0x86a65c: r0 = true
    //     0x86a65c: add             x0, NULL, #0x20  ; true
    // 0x86a660: tbnz            w0, #4, #0x86a6b0
    // 0x86a664: ldur            x0, [fp, #-0x10]
    // 0x86a668: r1 = LoadClassIdInstr(r0)
    //     0x86a668: ldur            x1, [x0, #-1]
    //     0x86a66c: ubfx            x1, x1, #0xc, #0x14
    // 0x86a670: SaveReg r0
    //     0x86a670: str             x0, [SP, #-8]!
    // 0x86a674: mov             x0, x1
    // 0x86a678: r0 = GDT[cid_x0 + -0xf31]()
    //     0x86a678: sub             lr, x0, #0xf31
    //     0x86a67c: ldr             lr, [x21, lr, lsl #3]
    //     0x86a680: blr             lr
    // 0x86a684: add             SP, SP, #8
    // 0x86a688: LoadField: d0 = r0->field_f
    //     0x86a688: ldur            d0, [x0, #0xf]
    // 0x86a68c: d1 = 72.000000
    //     0x86a68c: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0x86a690: ldr             d1, [x17, #0xdb0]
    // 0x86a694: fcmp            d0, d1
    // 0x86a698: b.vs            #0x86a6b8
    // 0x86a69c: b.ne            #0x86a6b8
    // 0x86a6a0: r0 = true
    //     0x86a6a0: add             x0, NULL, #0x20  ; true
    // 0x86a6a4: LeaveFrame
    //     0x86a6a4: mov             SP, fp
    //     0x86a6a8: ldp             fp, lr, [SP], #0x10
    // 0x86a6ac: ret
    //     0x86a6ac: ret             
    // 0x86a6b0: d1 = 72.000000
    //     0x86a6b0: add             x17, PP, #0x26, lsl #12  ; [pp+0x26db0] IMM: double(72) from 0x4052000000000000
    //     0x86a6b4: ldr             d1, [x17, #0xdb0]
    // 0x86a6b8: ldur            x1, [fp, #-8]
    // 0x86a6bc: b               #0x86a568
    // 0x86a6c0: r0 = false
    //     0x86a6c0: add             x0, NULL, #0x30  ; false
    // 0x86a6c4: LeaveFrame
    //     0x86a6c4: mov             SP, fp
    //     0x86a6c8: ldp             fp, lr, [SP], #0x10
    // 0x86a6cc: ret
    //     0x86a6cc: ret             
    // 0x86a6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86a6d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86a6d4: b               #0x86a534
    // 0x86a6d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86a6d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86a6dc: b               #0x86a574
  }
  _ createState(/* No info */) {
    // ** addr: 0xa41700, size: 0x2c
    // 0xa41700: EnterFrame
    //     0xa41700: stp             fp, lr, [SP, #-0x10]!
    //     0xa41704: mov             fp, SP
    // 0xa41708: r1 = <TabBar>
    //     0xa41708: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2edf0] TypeArguments: <TabBar>
    //     0xa4170c: ldr             x1, [x1, #0xdf0]
    // 0xa41710: r0 = _TabBarState()
    //     0xa41710: bl              #0xa4172c  ; Allocate_TabBarStateStub -> _TabBarState (size=0x2c)
    // 0xa41714: r1 = Sentinel
    //     0xa41714: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa41718: StoreField: r0->field_23 = r1
    //     0xa41718: stur            w1, [x0, #0x23]
    // 0xa4171c: StoreField: r0->field_27 = r1
    //     0xa4171c: stur            w1, [x0, #0x27]
    // 0xa41720: LeaveFrame
    //     0xa41720: mov             SP, fp
    //     0xa41724: ldp             fp, lr, [SP], #0x10
    // 0xa41728: ret
    //     0xa41728: ret             
  }
  get _ preferredSize(/* No info */) {
    // ** addr: 0xcb98f0, size: 0x230
    // 0xcb98f0: EnterFrame
    //     0xcb98f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcb98f4: mov             fp, SP
    // 0xcb98f8: AllocStack(0x20)
    //     0xcb98f8: sub             SP, SP, #0x20
    // 0xcb98fc: CheckStackOverflow
    //     0xcb98fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb9900: cmp             SP, x16
    //     0xcb9904: b.ls            #0xcb9b10
    // 0xcb9908: ldr             x0, [fp, #0x10]
    // 0xcb990c: LoadField: r1 = r0->field_b
    //     0xcb990c: ldur            w1, [x0, #0xb]
    // 0xcb9910: DecompressPointer r1
    //     0xcb9910: add             x1, x1, HEAP, lsl #32
    // 0xcb9914: r0 = LoadClassIdInstr(r1)
    //     0xcb9914: ldur            x0, [x1, #-1]
    //     0xcb9918: ubfx            x0, x0, #0xc, #0x14
    // 0xcb991c: SaveReg r1
    //     0xcb991c: str             x1, [SP, #-8]!
    // 0xcb9920: r0 = GDT[cid_x0 + 0xb940]()
    //     0xcb9920: mov             x17, #0xb940
    //     0xcb9924: add             lr, x0, x17
    //     0xcb9928: ldr             lr, [x21, lr, lsl #3]
    //     0xcb992c: blr             lr
    // 0xcb9930: add             SP, SP, #8
    // 0xcb9934: mov             x1, x0
    // 0xcb9938: stur            x1, [fp, #-8]
    // 0xcb993c: d0 = 46.000000
    //     0xcb993c: add             x17, PP, #0x23, lsl #12  ; [pp+0x239f8] IMM: double(46) from 0x4047000000000000
    //     0xcb9940: ldr             d0, [x17, #0x9f8]
    // 0xcb9944: stur            d0, [fp, #-0x18]
    // 0xcb9948: CheckStackOverflow
    //     0xcb9948: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb994c: cmp             SP, x16
    //     0xcb9950: b.ls            #0xcb9b18
    // 0xcb9954: r0 = LoadClassIdInstr(r1)
    //     0xcb9954: ldur            x0, [x1, #-1]
    //     0xcb9958: ubfx            x0, x0, #0xc, #0x14
    // 0xcb995c: SaveReg r1
    //     0xcb995c: str             x1, [SP, #-8]!
    // 0xcb9960: r0 = GDT[cid_x0 + 0x541]()
    //     0xcb9960: add             lr, x0, #0x541
    //     0xcb9964: ldr             lr, [x21, lr, lsl #3]
    //     0xcb9968: blr             lr
    // 0xcb996c: add             SP, SP, #8
    // 0xcb9970: tbnz            w0, #4, #0xcb9ae0
    // 0xcb9974: ldur            x1, [fp, #-8]
    // 0xcb9978: r0 = LoadClassIdInstr(r1)
    //     0xcb9978: ldur            x0, [x1, #-1]
    //     0xcb997c: ubfx            x0, x0, #0xc, #0x14
    // 0xcb9980: SaveReg r1
    //     0xcb9980: str             x1, [SP, #-8]!
    // 0xcb9984: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xcb9984: add             lr, x0, #0x5ca
    //     0xcb9988: ldr             lr, [x21, lr, lsl #3]
    //     0xcb998c: blr             lr
    // 0xcb9990: add             SP, SP, #8
    // 0xcb9994: mov             x3, x0
    // 0xcb9998: r2 = Null
    //     0xcb9998: mov             x2, NULL
    // 0xcb999c: r1 = Null
    //     0xcb999c: mov             x1, NULL
    // 0xcb99a0: stur            x3, [fp, #-0x10]
    // 0xcb99a4: cmp             w0, NULL
    // 0xcb99a8: b.eq            #0xcb9a34
    // 0xcb99ac: branchIfSmi(r0, 0xcb9a34)
    //     0xcb99ac: tbz             w0, #0, #0xcb9a34
    // 0xcb99b0: r3 = LoadClassIdInstr(r0)
    //     0xcb99b0: ldur            x3, [x0, #-1]
    //     0xcb99b4: ubfx            x3, x3, #0xc, #0x14
    // 0xcb99b8: r4 = LoadClassIdInstr(r0)
    //     0xcb99b8: ldur            x4, [x0, #-1]
    //     0xcb99bc: ubfx            x4, x4, #0xc, #0x14
    // 0xcb99c0: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xcb99c4: ldr             x3, [x3, #0x18]
    // 0xcb99c8: ldr             x3, [x3, x4, lsl #3]
    // 0xcb99cc: LoadField: r3 = r3->field_2b
    //     0xcb99cc: ldur            w3, [x3, #0x2b]
    // 0xcb99d0: DecompressPointer r3
    //     0xcb99d0: add             x3, x3, HEAP, lsl #32
    // 0xcb99d4: cmp             w3, NULL
    // 0xcb99d8: b.eq            #0xcb9a34
    // 0xcb99dc: LoadField: r3 = r3->field_f
    //     0xcb99dc: ldur            w3, [x3, #0xf]
    // 0xcb99e0: lsr             x3, x3, #4
    // 0xcb99e4: r17 = 4450
    //     0xcb99e4: mov             x17, #0x1162
    // 0xcb99e8: cmp             x3, x17
    // 0xcb99ec: b.eq            #0xcb9a3c
    // 0xcb99f0: r3 = SubtypeTestCache
    //     0xcb99f0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2edf8] SubtypeTestCache
    //     0xcb99f4: ldr             x3, [x3, #0xdf8]
    // 0xcb99f8: r24 = Subtype1TestCacheStub
    //     0xcb99f8: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xcb99fc: LoadField: r30 = r24->field_7
    //     0xcb99fc: ldur            lr, [x24, #7]
    // 0xcb9a00: blr             lr
    // 0xcb9a04: cmp             w7, NULL
    // 0xcb9a08: b.eq            #0xcb9a14
    // 0xcb9a0c: tbnz            w7, #4, #0xcb9a34
    // 0xcb9a10: b               #0xcb9a3c
    // 0xcb9a14: r8 = PreferredSizeWidget
    //     0xcb9a14: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ee00] Type: PreferredSizeWidget
    //     0xcb9a18: ldr             x8, [x8, #0xe00]
    // 0xcb9a1c: r3 = SubtypeTestCache
    //     0xcb9a1c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ee08] SubtypeTestCache
    //     0xcb9a20: ldr             x3, [x3, #0xe08]
    // 0xcb9a24: r24 = InstanceOfStub
    //     0xcb9a24: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xcb9a28: LoadField: r30 = r24->field_7
    //     0xcb9a28: ldur            lr, [x24, #7]
    // 0xcb9a2c: blr             lr
    // 0xcb9a30: b               #0xcb9a40
    // 0xcb9a34: r0 = false
    //     0xcb9a34: add             x0, NULL, #0x30  ; false
    // 0xcb9a38: b               #0xcb9a40
    // 0xcb9a3c: r0 = true
    //     0xcb9a3c: add             x0, NULL, #0x20  ; true
    // 0xcb9a40: tbnz            w0, #4, #0xcb9acc
    // 0xcb9a44: ldur            d0, [fp, #-0x18]
    // 0xcb9a48: ldur            x0, [fp, #-0x10]
    // 0xcb9a4c: r1 = LoadClassIdInstr(r0)
    //     0xcb9a4c: ldur            x1, [x0, #-1]
    //     0xcb9a50: ubfx            x1, x1, #0xc, #0x14
    // 0xcb9a54: SaveReg r0
    //     0xcb9a54: str             x0, [SP, #-8]!
    // 0xcb9a58: mov             x0, x1
    // 0xcb9a5c: r0 = GDT[cid_x0 + -0xf31]()
    //     0xcb9a5c: sub             lr, x0, #0xf31
    //     0xcb9a60: ldr             lr, [x21, lr, lsl #3]
    //     0xcb9a64: blr             lr
    // 0xcb9a68: add             SP, SP, #8
    // 0xcb9a6c: LoadField: d0 = r0->field_f
    //     0xcb9a6c: ldur            d0, [x0, #0xf]
    // 0xcb9a70: ldur            d1, [fp, #-0x18]
    // 0xcb9a74: fcmp            d0, d1
    // 0xcb9a78: b.vs            #0xcb9a88
    // 0xcb9a7c: b.le            #0xcb9a88
    // 0xcb9a80: d2 = 0.000000
    //     0xcb9a80: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9a84: b               #0xcb9ad8
    // 0xcb9a88: fcmp            d0, d1
    // 0xcb9a8c: b.vs            #0xcb9aa0
    // 0xcb9a90: b.ge            #0xcb9aa0
    // 0xcb9a94: mov             v0.16b, v1.16b
    // 0xcb9a98: d2 = 0.000000
    //     0xcb9a98: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9a9c: b               #0xcb9ad8
    // 0xcb9aa0: d2 = 0.000000
    //     0xcb9aa0: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9aa4: fcmp            d0, d2
    // 0xcb9aa8: b.vs            #0xcb9abc
    // 0xcb9aac: b.ne            #0xcb9abc
    // 0xcb9ab0: fadd            d3, d0, d1
    // 0xcb9ab4: mov             v0.16b, v3.16b
    // 0xcb9ab8: b               #0xcb9ad8
    // 0xcb9abc: fcmp            d1, d1
    // 0xcb9ac0: b.vc            #0xcb9ad8
    // 0xcb9ac4: mov             v0.16b, v1.16b
    // 0xcb9ac8: b               #0xcb9ad8
    // 0xcb9acc: ldur            d1, [fp, #-0x18]
    // 0xcb9ad0: d2 = 0.000000
    //     0xcb9ad0: eor             v2.16b, v2.16b, v2.16b
    // 0xcb9ad4: mov             v0.16b, v1.16b
    // 0xcb9ad8: ldur            x1, [fp, #-8]
    // 0xcb9adc: b               #0xcb9944
    // 0xcb9ae0: ldur            d1, [fp, #-0x18]
    // 0xcb9ae4: d0 = 2.000000
    //     0xcb9ae4: fmov            d0, #2.00000000
    // 0xcb9ae8: fadd            d2, d1, d0
    // 0xcb9aec: stur            d2, [fp, #-0x20]
    // 0xcb9af0: r0 = Size()
    //     0xcb9af0: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xcb9af4: d0 = inf
    //     0xcb9af4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xcb9af8: StoreField: r0->field_7 = d0
    //     0xcb9af8: stur            d0, [x0, #7]
    // 0xcb9afc: ldur            d0, [fp, #-0x20]
    // 0xcb9b00: StoreField: r0->field_f = d0
    //     0xcb9b00: stur            d0, [x0, #0xf]
    // 0xcb9b04: LeaveFrame
    //     0xcb9b04: mov             SP, fp
    //     0xcb9b08: ldp             fp, lr, [SP], #0x10
    // 0xcb9b0c: ret
    //     0xcb9b0c: ret             
    // 0xcb9b10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb9b10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb9b14: b               #0xcb9908
    // 0xcb9b18: r0 = StackOverflowSharedWithFPURegs()
    //     0xcb9b18: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcb9b1c: b               #0xcb9954
  }
}

// class id: 4200, size: 0x28, field offset: 0x10
//   const constructor, 
class _TabStyle extends AnimatedWidget {

  _ build(/* No info */) {
    // ** addr: 0xaec8d8, size: 0x670
    // 0xaec8d8: EnterFrame
    //     0xaec8d8: stp             fp, lr, [SP, #-0x10]!
    //     0xaec8dc: mov             fp, SP
    // 0xaec8e0: AllocStack(0x38)
    //     0xaec8e0: sub             SP, SP, #0x38
    // 0xaec8e4: CheckStackOverflow
    //     0xaec8e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaec8e8: cmp             SP, x16
    //     0xaec8ec: b.ls            #0xaecf1c
    // 0xaec8f0: ldr             x16, [fp, #0x10]
    // 0xaec8f4: SaveReg r16
    //     0xaec8f4: str             x16, [SP, #-8]!
    // 0xaec8f8: r0 = of()
    //     0xaec8f8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaec8fc: add             SP, SP, #8
    // 0xaec900: stur            x0, [fp, #-8]
    // 0xaec904: ldr             x16, [fp, #0x10]
    // 0xaec908: SaveReg r16
    //     0xaec908: str             x16, [SP, #-8]!
    // 0xaec90c: r0 = of()
    //     0xaec90c: bl              #0x79f3a4  ; [package:flutter/src/material/tab_bar_theme.dart] TabBarTheme::of
    // 0xaec910: add             SP, SP, #8
    // 0xaec914: mov             x1, x0
    // 0xaec918: ldur            x0, [fp, #-8]
    // 0xaec91c: stur            x1, [fp, #-0x18]
    // 0xaec920: LoadField: r2 = r0->field_2b
    //     0xaec920: ldur            w2, [x0, #0x2b]
    // 0xaec924: DecompressPointer r2
    //     0xaec924: add             x2, x2, HEAP, lsl #32
    // 0xaec928: stur            x2, [fp, #-0x10]
    // 0xaec92c: tbnz            w2, #4, #0xaec964
    // 0xaec930: ldr             x0, [fp, #0x10]
    // 0xaec934: r0 = _TabsDefaultsM3()
    //     0xaec934: bl              #0x7bcf38  ; Allocate_TabsDefaultsM3Stub -> _TabsDefaultsM3 (size=0x44)
    // 0xaec938: mov             x1, x0
    // 0xaec93c: r0 = Sentinel
    //     0xaec93c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaec940: StoreField: r1->field_3b = r0
    //     0xaec940: stur            w0, [x1, #0x3b]
    // 0xaec944: StoreField: r1->field_3f = r0
    //     0xaec944: stur            w0, [x1, #0x3f]
    // 0xaec948: ldr             x0, [fp, #0x10]
    // 0xaec94c: StoreField: r1->field_37 = r0
    //     0xaec94c: stur            w0, [x1, #0x37]
    // 0xaec950: r0 = Instance_TabBarIndicatorSize
    //     0xaec950: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0xaec954: ldr             x0, [x0, #0xbe0]
    // 0xaec958: StoreField: r1->field_f = r0
    //     0xaec958: stur            w0, [x1, #0xf]
    // 0xaec95c: mov             x5, x1
    // 0xaec960: b               #0xaec988
    // 0xaec964: ldr             x0, [fp, #0x10]
    // 0xaec968: r0 = _TabsDefaultsM2()
    //     0xaec968: bl              #0x7bcf2c  ; Allocate_TabsDefaultsM2Stub -> _TabsDefaultsM2 (size=0x3c)
    // 0xaec96c: mov             x1, x0
    // 0xaec970: ldr             x0, [fp, #0x10]
    // 0xaec974: StoreField: r1->field_37 = r0
    //     0xaec974: stur            w0, [x1, #0x37]
    // 0xaec978: r0 = Instance_TabBarIndicatorSize
    //     0xaec978: add             x0, PP, #0x37, lsl #12  ; [pp+0x37ea0] Obj!TabBarIndicatorSize@b65171
    //     0xaec97c: ldr             x0, [x0, #0xea0]
    // 0xaec980: StoreField: r1->field_f = r0
    //     0xaec980: stur            w0, [x1, #0xf]
    // 0xaec984: mov             x5, x1
    // 0xaec988: ldr             x4, [fp, #0x18]
    // 0xaec98c: ldur            x3, [fp, #-0x18]
    // 0xaec990: stur            x5, [fp, #-0x20]
    // 0xaec994: LoadField: r6 = r4->field_b
    //     0xaec994: ldur            w6, [x4, #0xb]
    // 0xaec998: DecompressPointer r6
    //     0xaec998: add             x6, x6, HEAP, lsl #32
    // 0xaec99c: mov             x0, x6
    // 0xaec9a0: stur            x6, [fp, #-8]
    // 0xaec9a4: r2 = Null
    //     0xaec9a4: mov             x2, NULL
    // 0xaec9a8: r1 = Null
    //     0xaec9a8: mov             x1, NULL
    // 0xaec9ac: r8 = Animation<double>
    //     0xaec9ac: add             x8, PP, #0x2a, lsl #12  ; [pp+0x2aab0] Type: Animation<double>
    //     0xaec9b0: ldr             x8, [x8, #0xab0]
    // 0xaec9b4: r3 = Null
    //     0xaec9b4: add             x3, PP, #0x40, lsl #12  ; [pp+0x40cc8] Null
    //     0xaec9b8: ldr             x3, [x3, #0xcc8]
    // 0xaec9bc: r0 = Animation<double>()
    //     0xaec9bc: bl              #0x5912f0  ; IsType_Animation<double>_Stub
    // 0xaec9c0: ldur            x0, [fp, #-0x18]
    // 0xaec9c4: LoadField: r1 = r0->field_1f
    //     0xaec9c4: ldur            w1, [x0, #0x1f]
    // 0xaec9c8: DecompressPointer r1
    //     0xaec9c8: add             x1, x1, HEAP, lsl #32
    // 0xaec9cc: cmp             w1, NULL
    // 0xaec9d0: b.ne            #0xaeca74
    // 0xaec9d4: ldur            x2, [fp, #-0x20]
    // 0xaec9d8: r1 = LoadClassIdInstr(r2)
    //     0xaec9d8: ldur            x1, [x2, #-1]
    //     0xaec9dc: ubfx            x1, x1, #0xc, #0x14
    // 0xaec9e0: lsl             x1, x1, #1
    // 0xaec9e4: r17 = 5444
    //     0xaec9e4: mov             x17, #0x1544
    // 0xaec9e8: cmp             w1, w17
    // 0xaec9ec: b.ne            #0xaeca00
    // 0xaec9f0: LoadField: r1 = r2->field_1f
    //     0xaec9f0: ldur            w1, [x2, #0x1f]
    // 0xaec9f4: DecompressPointer r1
    //     0xaec9f4: add             x1, x1, HEAP, lsl #32
    // 0xaec9f8: mov             x0, x1
    // 0xaec9fc: b               #0xaeca68
    // 0xaeca00: r17 = 5446
    //     0xaeca00: mov             x17, #0x1546
    // 0xaeca04: cmp             w1, w17
    // 0xaeca08: b.ne            #0xaeca40
    // 0xaeca0c: mov             x1, x2
    // 0xaeca10: LoadField: r0 = r1->field_3f
    //     0xaeca10: ldur            w0, [x1, #0x3f]
    // 0xaeca14: DecompressPointer r0
    //     0xaeca14: add             x0, x0, HEAP, lsl #32
    // 0xaeca18: r16 = Sentinel
    //     0xaeca18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaeca1c: cmp             w0, w16
    // 0xaeca20: b.ne            #0xaeca30
    // 0xaeca24: r2 = _textTheme
    //     0xaeca24: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xaeca28: ldr             x2, [x2, #0xf58]
    // 0xaeca2c: r0 = InitLateFinalInstanceField()
    //     0xaeca2c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaeca30: LoadField: r1 = r0->field_27
    //     0xaeca30: ldur            w1, [x0, #0x27]
    // 0xaeca34: DecompressPointer r1
    //     0xaeca34: add             x1, x1, HEAP, lsl #32
    // 0xaeca38: mov             x0, x1
    // 0xaeca3c: b               #0xaeca68
    // 0xaeca40: mov             x1, x2
    // 0xaeca44: LoadField: r0 = r1->field_37
    //     0xaeca44: ldur            w0, [x1, #0x37]
    // 0xaeca48: DecompressPointer r0
    //     0xaeca48: add             x0, x0, HEAP, lsl #32
    // 0xaeca4c: SaveReg r0
    //     0xaeca4c: str             x0, [SP, #-8]!
    // 0xaeca50: r0 = of()
    //     0xaeca50: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaeca54: add             SP, SP, #8
    // 0xaeca58: LoadField: r1 = r0->field_8f
    //     0xaeca58: ldur            w1, [x0, #0x8f]
    // 0xaeca5c: DecompressPointer r1
    //     0xaeca5c: add             x1, x1, HEAP, lsl #32
    // 0xaeca60: LoadField: r0 = r1->field_2b
    //     0xaeca60: ldur            w0, [x1, #0x2b]
    // 0xaeca64: DecompressPointer r0
    //     0xaeca64: add             x0, x0, HEAP, lsl #32
    // 0xaeca68: cmp             w0, NULL
    // 0xaeca6c: b.eq            #0xaecf24
    // 0xaeca70: mov             x1, x0
    // 0xaeca74: ldur            x0, [fp, #-0x18]
    // 0xaeca78: r16 = true
    //     0xaeca78: add             x16, NULL, #0x20  ; true
    // 0xaeca7c: stp             x16, x1, [SP, #-0x10]!
    // 0xaeca80: r4 = const [0, 0x2, 0x2, 0x1, inherit, 0x1, null]
    //     0xaeca80: add             x4, PP, #0x40, lsl #12  ; [pp+0x40cd8] List(7) [0, 0x2, 0x2, 0x1, "inherit", 0x1, Null]
    //     0xaeca84: ldr             x4, [x4, #0xcd8]
    // 0xaeca88: r0 = copyWith()
    //     0xaeca88: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaeca8c: add             SP, SP, #0x10
    // 0xaeca90: mov             x2, x0
    // 0xaeca94: ldur            x0, [fp, #-0x18]
    // 0xaeca98: stur            x2, [fp, #-0x28]
    // 0xaeca9c: LoadField: r1 = r0->field_27
    //     0xaeca9c: ldur            w1, [x0, #0x27]
    // 0xaecaa0: DecompressPointer r1
    //     0xaecaa0: add             x1, x1, HEAP, lsl #32
    // 0xaecaa4: cmp             w1, NULL
    // 0xaecaa8: b.ne            #0xaecab0
    // 0xaecaac: r1 = Null
    //     0xaecaac: mov             x1, NULL
    // 0xaecab0: cmp             w1, NULL
    // 0xaecab4: b.ne            #0xaecb58
    // 0xaecab8: ldur            x3, [fp, #-0x20]
    // 0xaecabc: r1 = LoadClassIdInstr(r3)
    //     0xaecabc: ldur            x1, [x3, #-1]
    //     0xaecac0: ubfx            x1, x1, #0xc, #0x14
    // 0xaecac4: lsl             x1, x1, #1
    // 0xaecac8: r17 = 5444
    //     0xaecac8: mov             x17, #0x1544
    // 0xaecacc: cmp             w1, w17
    // 0xaecad0: b.ne            #0xaecae4
    // 0xaecad4: LoadField: r1 = r3->field_27
    //     0xaecad4: ldur            w1, [x3, #0x27]
    // 0xaecad8: DecompressPointer r1
    //     0xaecad8: add             x1, x1, HEAP, lsl #32
    // 0xaecadc: mov             x0, x1
    // 0xaecae0: b               #0xaecb4c
    // 0xaecae4: r17 = 5446
    //     0xaecae4: mov             x17, #0x1546
    // 0xaecae8: cmp             w1, w17
    // 0xaecaec: b.ne            #0xaecb24
    // 0xaecaf0: mov             x1, x3
    // 0xaecaf4: LoadField: r0 = r1->field_3f
    //     0xaecaf4: ldur            w0, [x1, #0x3f]
    // 0xaecaf8: DecompressPointer r0
    //     0xaecaf8: add             x0, x0, HEAP, lsl #32
    // 0xaecafc: r16 = Sentinel
    //     0xaecafc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaecb00: cmp             w0, w16
    // 0xaecb04: b.ne            #0xaecb14
    // 0xaecb08: r2 = _textTheme
    //     0xaecb08: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf58] Field <_TabsDefaultsM3@472014024._textTheme@472014024>: late final (offset: 0x40)
    //     0xaecb0c: ldr             x2, [x2, #0xf58]
    // 0xaecb10: r0 = InitLateFinalInstanceField()
    //     0xaecb10: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaecb14: LoadField: r1 = r0->field_27
    //     0xaecb14: ldur            w1, [x0, #0x27]
    // 0xaecb18: DecompressPointer r1
    //     0xaecb18: add             x1, x1, HEAP, lsl #32
    // 0xaecb1c: mov             x0, x1
    // 0xaecb20: b               #0xaecb4c
    // 0xaecb24: mov             x1, x3
    // 0xaecb28: LoadField: r0 = r1->field_37
    //     0xaecb28: ldur            w0, [x1, #0x37]
    // 0xaecb2c: DecompressPointer r0
    //     0xaecb2c: add             x0, x0, HEAP, lsl #32
    // 0xaecb30: SaveReg r0
    //     0xaecb30: str             x0, [SP, #-8]!
    // 0xaecb34: r0 = of()
    //     0xaecb34: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaecb38: add             SP, SP, #8
    // 0xaecb3c: LoadField: r1 = r0->field_8f
    //     0xaecb3c: ldur            w1, [x0, #0x8f]
    // 0xaecb40: DecompressPointer r1
    //     0xaecb40: add             x1, x1, HEAP, lsl #32
    // 0xaecb44: LoadField: r0 = r1->field_2b
    //     0xaecb44: ldur            w0, [x1, #0x2b]
    // 0xaecb48: DecompressPointer r0
    //     0xaecb48: add             x0, x0, HEAP, lsl #32
    // 0xaecb4c: cmp             w0, NULL
    // 0xaecb50: b.eq            #0xaecf28
    // 0xaecb54: mov             x1, x0
    // 0xaecb58: ldr             x0, [fp, #0x18]
    // 0xaecb5c: r16 = true
    //     0xaecb5c: add             x16, NULL, #0x20  ; true
    // 0xaecb60: stp             x16, x1, [SP, #-0x10]!
    // 0xaecb64: r4 = const [0, 0x2, 0x2, 0x1, inherit, 0x1, null]
    //     0xaecb64: add             x4, PP, #0x40, lsl #12  ; [pp+0x40cd8] List(7) [0, 0x2, 0x2, 0x1, "inherit", 0x1, Null]
    //     0xaecb68: ldr             x4, [x4, #0xcd8]
    // 0xaecb6c: r0 = copyWith()
    //     0xaecb6c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaecb70: add             SP, SP, #0x10
    // 0xaecb74: mov             x2, x0
    // 0xaecb78: ldr             x1, [fp, #0x18]
    // 0xaecb7c: stur            x2, [fp, #-0x38]
    // 0xaecb80: LoadField: r3 = r1->field_17
    //     0xaecb80: ldur            w3, [x1, #0x17]
    // 0xaecb84: DecompressPointer r3
    //     0xaecb84: add             x3, x3, HEAP, lsl #32
    // 0xaecb88: stur            x3, [fp, #-0x30]
    // 0xaecb8c: tbnz            w3, #4, #0xaecbd8
    // 0xaecb90: ldur            x4, [fp, #-8]
    // 0xaecb94: r0 = LoadClassIdInstr(r4)
    //     0xaecb94: ldur            x0, [x4, #-1]
    //     0xaecb98: ubfx            x0, x0, #0xc, #0x14
    // 0xaecb9c: SaveReg r4
    //     0xaecb9c: str             x4, [SP, #-8]!
    // 0xaecba0: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaecba0: add             lr, x0, #0xb7c
    //     0xaecba4: ldr             lr, [x21, lr, lsl #3]
    //     0xaecba8: blr             lr
    // 0xaecbac: add             SP, SP, #8
    // 0xaecbb0: ldur            x16, [fp, #-0x28]
    // 0xaecbb4: ldur            lr, [fp, #-0x38]
    // 0xaecbb8: stp             lr, x16, [SP, #-0x10]!
    // 0xaecbbc: SaveReg r0
    //     0xaecbbc: str             x0, [SP, #-8]!
    // 0xaecbc0: r0 = lerp()
    //     0xaecbc0: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xaecbc4: add             SP, SP, #0x18
    // 0xaecbc8: cmp             w0, NULL
    // 0xaecbcc: b.eq            #0xaecf2c
    // 0xaecbd0: mov             x2, x0
    // 0xaecbd4: b               #0xaecc1c
    // 0xaecbd8: ldur            x1, [fp, #-8]
    // 0xaecbdc: r0 = LoadClassIdInstr(r1)
    //     0xaecbdc: ldur            x0, [x1, #-1]
    //     0xaecbe0: ubfx            x0, x0, #0xc, #0x14
    // 0xaecbe4: SaveReg r1
    //     0xaecbe4: str             x1, [SP, #-8]!
    // 0xaecbe8: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaecbe8: add             lr, x0, #0xb7c
    //     0xaecbec: ldr             lr, [x21, lr, lsl #3]
    //     0xaecbf0: blr             lr
    // 0xaecbf4: add             SP, SP, #8
    // 0xaecbf8: ldur            x16, [fp, #-0x38]
    // 0xaecbfc: ldur            lr, [fp, #-0x28]
    // 0xaecc00: stp             lr, x16, [SP, #-0x10]!
    // 0xaecc04: SaveReg r0
    //     0xaecc04: str             x0, [SP, #-8]!
    // 0xaecc08: r0 = lerp()
    //     0xaecc08: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xaecc0c: add             SP, SP, #0x18
    // 0xaecc10: cmp             w0, NULL
    // 0xaecc14: b.eq            #0xaecf30
    // 0xaecc18: mov             x2, x0
    // 0xaecc1c: ldr             x0, [fp, #0x18]
    // 0xaecc20: stur            x2, [fp, #-0x28]
    // 0xaecc24: LoadField: r1 = r0->field_1b
    //     0xaecc24: ldur            w1, [x0, #0x1b]
    // 0xaecc28: DecompressPointer r1
    //     0xaecc28: add             x1, x1, HEAP, lsl #32
    // 0xaecc2c: cmp             w1, NULL
    // 0xaecc30: b.ne            #0xaecc44
    // 0xaecc34: ldur            x3, [fp, #-0x18]
    // 0xaecc38: LoadField: r1 = r3->field_17
    //     0xaecc38: ldur            w1, [x3, #0x17]
    // 0xaecc3c: DecompressPointer r1
    //     0xaecc3c: add             x1, x1, HEAP, lsl #32
    // 0xaecc40: b               #0xaecc48
    // 0xaecc44: ldur            x3, [fp, #-0x18]
    // 0xaecc48: cmp             w1, NULL
    // 0xaecc4c: b.ne            #0xaecd08
    // 0xaecc50: ldur            x4, [fp, #-0x20]
    // 0xaecc54: r1 = LoadClassIdInstr(r4)
    //     0xaecc54: ldur            x1, [x4, #-1]
    //     0xaecc58: ubfx            x1, x1, #0xc, #0x14
    // 0xaecc5c: lsl             x1, x1, #1
    // 0xaecc60: r17 = 5444
    //     0xaecc60: mov             x17, #0x1544
    // 0xaecc64: cmp             w1, w17
    // 0xaecc68: b.ne            #0xaecc7c
    // 0xaecc6c: LoadField: r1 = r4->field_17
    //     0xaecc6c: ldur            w1, [x4, #0x17]
    // 0xaecc70: DecompressPointer r1
    //     0xaecc70: add             x1, x1, HEAP, lsl #32
    // 0xaecc74: mov             x0, x1
    // 0xaecc78: b               #0xaecd00
    // 0xaecc7c: r17 = 5446
    //     0xaecc7c: mov             x17, #0x1546
    // 0xaecc80: cmp             w1, w17
    // 0xaecc84: b.ne            #0xaeccbc
    // 0xaecc88: mov             x1, x4
    // 0xaecc8c: LoadField: r0 = r1->field_3b
    //     0xaecc8c: ldur            w0, [x1, #0x3b]
    // 0xaecc90: DecompressPointer r0
    //     0xaecc90: add             x0, x0, HEAP, lsl #32
    // 0xaecc94: r16 = Sentinel
    //     0xaecc94: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaecc98: cmp             w0, w16
    // 0xaecc9c: b.ne            #0xaeccac
    // 0xaecca0: r2 = _colors
    //     0xaecca0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xaecca4: ldr             x2, [x2, #0xf50]
    // 0xaecca8: r0 = InitLateFinalInstanceField()
    //     0xaecca8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaeccac: LoadField: r1 = r0->field_b
    //     0xaeccac: ldur            w1, [x0, #0xb]
    // 0xaeccb0: DecompressPointer r1
    //     0xaeccb0: add             x1, x1, HEAP, lsl #32
    // 0xaeccb4: mov             x0, x1
    // 0xaeccb8: b               #0xaecd00
    // 0xaeccbc: mov             x1, x4
    // 0xaeccc0: LoadField: r0 = r1->field_37
    //     0xaeccc0: ldur            w0, [x1, #0x37]
    // 0xaeccc4: DecompressPointer r0
    //     0xaeccc4: add             x0, x0, HEAP, lsl #32
    // 0xaeccc8: SaveReg r0
    //     0xaeccc8: str             x0, [SP, #-8]!
    // 0xaecccc: r0 = of()
    //     0xaecccc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xaeccd0: add             SP, SP, #8
    // 0xaeccd4: LoadField: r1 = r0->field_8f
    //     0xaeccd4: ldur            w1, [x0, #0x8f]
    // 0xaeccd8: DecompressPointer r1
    //     0xaeccd8: add             x1, x1, HEAP, lsl #32
    // 0xaeccdc: LoadField: r0 = r1->field_2b
    //     0xaeccdc: ldur            w0, [x1, #0x2b]
    // 0xaecce0: DecompressPointer r0
    //     0xaecce0: add             x0, x0, HEAP, lsl #32
    // 0xaecce4: cmp             w0, NULL
    // 0xaecce8: b.eq            #0xaecf34
    // 0xaeccec: LoadField: r1 = r0->field_b
    //     0xaeccec: ldur            w1, [x0, #0xb]
    // 0xaeccf0: DecompressPointer r1
    //     0xaeccf0: add             x1, x1, HEAP, lsl #32
    // 0xaeccf4: cmp             w1, NULL
    // 0xaeccf8: b.eq            #0xaecf38
    // 0xaeccfc: mov             x0, x1
    // 0xaecd00: mov             x2, x0
    // 0xaecd04: b               #0xaecd0c
    // 0xaecd08: mov             x2, x1
    // 0xaecd0c: ldr             x0, [fp, #0x18]
    // 0xaecd10: stur            x2, [fp, #-0x38]
    // 0xaecd14: LoadField: r1 = r0->field_1f
    //     0xaecd14: ldur            w1, [x0, #0x1f]
    // 0xaecd18: DecompressPointer r1
    //     0xaecd18: add             x1, x1, HEAP, lsl #32
    // 0xaecd1c: cmp             w1, NULL
    // 0xaecd20: b.ne            #0xaecd34
    // 0xaecd24: ldur            x1, [fp, #-0x18]
    // 0xaecd28: LoadField: r3 = r1->field_23
    //     0xaecd28: ldur            w3, [x1, #0x23]
    // 0xaecd2c: DecompressPointer r3
    //     0xaecd2c: add             x3, x3, HEAP, lsl #32
    // 0xaecd30: mov             x1, x3
    // 0xaecd34: cmp             w1, NULL
    // 0xaecd38: b.ne            #0xaecde0
    // 0xaecd3c: ldur            x1, [fp, #-0x10]
    // 0xaecd40: tbnz            w1, #4, #0xaecdc8
    // 0xaecd44: ldur            x1, [fp, #-0x20]
    // 0xaecd48: r3 = LoadClassIdInstr(r1)
    //     0xaecd48: ldur            x3, [x1, #-1]
    //     0xaecd4c: ubfx            x3, x3, #0xc, #0x14
    // 0xaecd50: lsl             x3, x3, #1
    // 0xaecd54: r17 = 5444
    //     0xaecd54: mov             x17, #0x1544
    // 0xaecd58: cmp             w3, w17
    // 0xaecd5c: b.eq            #0xaecdb4
    // 0xaecd60: r17 = 5446
    //     0xaecd60: mov             x17, #0x1546
    // 0xaecd64: cmp             w3, w17
    // 0xaecd68: b.ne            #0xaecdb4
    // 0xaecd6c: LoadField: r0 = r1->field_3b
    //     0xaecd6c: ldur            w0, [x1, #0x3b]
    // 0xaecd70: DecompressPointer r0
    //     0xaecd70: add             x0, x0, HEAP, lsl #32
    // 0xaecd74: r16 = Sentinel
    //     0xaecd74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaecd78: cmp             w0, w16
    // 0xaecd7c: b.ne            #0xaecd8c
    // 0xaecd80: r2 = _colors
    //     0xaecd80: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf50] Field <_TabsDefaultsM3@472014024._colors@472014024>: late final (offset: 0x3c)
    //     0xaecd84: ldr             x2, [x2, #0xf50]
    // 0xaecd88: r0 = InitLateFinalInstanceField()
    //     0xaecd88: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaecd8c: LoadField: r1 = r0->field_5f
    //     0xaecd8c: ldur            w1, [x0, #0x5f]
    // 0xaecd90: DecompressPointer r1
    //     0xaecd90: add             x1, x1, HEAP, lsl #32
    // 0xaecd94: cmp             w1, NULL
    // 0xaecd98: b.ne            #0xaecdac
    // 0xaecd9c: LoadField: r1 = r0->field_57
    //     0xaecd9c: ldur            w1, [x0, #0x57]
    // 0xaecda0: DecompressPointer r1
    //     0xaecda0: add             x1, x1, HEAP, lsl #32
    // 0xaecda4: mov             x0, x1
    // 0xaecda8: b               #0xaecdbc
    // 0xaecdac: mov             x0, x1
    // 0xaecdb0: b               #0xaecdbc
    // 0xaecdb4: LoadField: r0 = r1->field_23
    //     0xaecdb4: ldur            w0, [x1, #0x23]
    // 0xaecdb8: DecompressPointer r0
    //     0xaecdb8: add             x0, x0, HEAP, lsl #32
    // 0xaecdbc: cmp             w0, NULL
    // 0xaecdc0: b.eq            #0xaecf3c
    // 0xaecdc4: b               #0xaecddc
    // 0xaecdc8: r0 = 178
    //     0xaecdc8: mov             x0, #0xb2
    // 0xaecdcc: ldur            x16, [fp, #-0x38]
    // 0xaecdd0: stp             x0, x16, [SP, #-0x10]!
    // 0xaecdd4: r0 = withAlpha()
    //     0xaecdd4: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0xaecdd8: add             SP, SP, #0x10
    // 0xaecddc: mov             x1, x0
    // 0xaecde0: ldur            x0, [fp, #-0x30]
    // 0xaecde4: stur            x1, [fp, #-0x10]
    // 0xaecde8: tbnz            w0, #4, #0xaece38
    // 0xaecdec: ldur            x0, [fp, #-8]
    // 0xaecdf0: r2 = LoadClassIdInstr(r0)
    //     0xaecdf0: ldur            x2, [x0, #-1]
    //     0xaecdf4: ubfx            x2, x2, #0xc, #0x14
    // 0xaecdf8: SaveReg r0
    //     0xaecdf8: str             x0, [SP, #-8]!
    // 0xaecdfc: mov             x0, x2
    // 0xaece00: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaece00: add             lr, x0, #0xb7c
    //     0xaece04: ldr             lr, [x21, lr, lsl #3]
    //     0xaece08: blr             lr
    // 0xaece0c: add             SP, SP, #8
    // 0xaece10: ldur            x16, [fp, #-0x38]
    // 0xaece14: ldur            lr, [fp, #-0x10]
    // 0xaece18: stp             lr, x16, [SP, #-0x10]!
    // 0xaece1c: SaveReg r0
    //     0xaece1c: str             x0, [SP, #-8]!
    // 0xaece20: r0 = lerp()
    //     0xaece20: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaece24: add             SP, SP, #0x18
    // 0xaece28: cmp             w0, NULL
    // 0xaece2c: b.eq            #0xaecf40
    // 0xaece30: mov             x1, x0
    // 0xaece34: b               #0xaece80
    // 0xaece38: ldur            x0, [fp, #-8]
    // 0xaece3c: r1 = LoadClassIdInstr(r0)
    //     0xaece3c: ldur            x1, [x0, #-1]
    //     0xaece40: ubfx            x1, x1, #0xc, #0x14
    // 0xaece44: SaveReg r0
    //     0xaece44: str             x0, [SP, #-8]!
    // 0xaece48: mov             x0, x1
    // 0xaece4c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xaece4c: add             lr, x0, #0xb7c
    //     0xaece50: ldr             lr, [x21, lr, lsl #3]
    //     0xaece54: blr             lr
    // 0xaece58: add             SP, SP, #8
    // 0xaece5c: ldur            x16, [fp, #-0x10]
    // 0xaece60: ldur            lr, [fp, #-0x38]
    // 0xaece64: stp             lr, x16, [SP, #-0x10]!
    // 0xaece68: SaveReg r0
    //     0xaece68: str             x0, [SP, #-8]!
    // 0xaece6c: r0 = lerp()
    //     0xaece6c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xaece70: add             SP, SP, #0x18
    // 0xaece74: cmp             w0, NULL
    // 0xaece78: b.eq            #0xaecf44
    // 0xaece7c: mov             x1, x0
    // 0xaece80: ldr             x0, [fp, #0x18]
    // 0xaece84: stur            x1, [fp, #-8]
    // 0xaece88: ldur            x16, [fp, #-0x28]
    // 0xaece8c: stp             x1, x16, [SP, #-0x10]!
    // 0xaece90: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xaece90: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xaece94: ldr             x4, [x4, #0x168]
    // 0xaece98: r0 = copyWith()
    //     0xaece98: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaece9c: add             SP, SP, #0x10
    // 0xaecea0: stur            x0, [fp, #-0x10]
    // 0xaecea4: r0 = IconThemeData()
    //     0xaecea4: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xaecea8: mov             x1, x0
    // 0xaeceac: r0 = 24.000000
    //     0xaeceac: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xaeceb0: ldr             x0, [x0, #0x360]
    // 0xaeceb4: StoreField: r1->field_7 = r0
    //     0xaeceb4: stur            w0, [x1, #7]
    // 0xaeceb8: ldur            x0, [fp, #-8]
    // 0xaecebc: StoreField: r1->field_1b = r0
    //     0xaecebc: stur            w0, [x1, #0x1b]
    // 0xaecec0: ldr             x0, [fp, #0x18]
    // 0xaecec4: LoadField: r2 = r0->field_23
    //     0xaecec4: ldur            w2, [x0, #0x23]
    // 0xaecec8: DecompressPointer r2
    //     0xaecec8: add             x2, x2, HEAP, lsl #32
    // 0xaececc: stp             x1, x2, [SP, #-0x10]!
    // 0xaeced0: r0 = merge()
    //     0xaeced0: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xaeced4: add             SP, SP, #0x10
    // 0xaeced8: stur            x0, [fp, #-8]
    // 0xaecedc: r0 = DefaultTextStyle()
    //     0xaecedc: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xaecee0: ldur            x1, [fp, #-0x10]
    // 0xaecee4: StoreField: r0->field_f = r1
    //     0xaecee4: stur            w1, [x0, #0xf]
    // 0xaecee8: r1 = true
    //     0xaecee8: add             x1, NULL, #0x20  ; true
    // 0xaeceec: StoreField: r0->field_17 = r1
    //     0xaeceec: stur            w1, [x0, #0x17]
    // 0xaecef0: r1 = Instance_TextOverflow
    //     0xaecef0: add             x1, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xaecef4: ldr             x1, [x1, #0x118]
    // 0xaecef8: StoreField: r0->field_1b = r1
    //     0xaecef8: stur            w1, [x0, #0x1b]
    // 0xaecefc: r1 = Instance_TextWidthBasis
    //     0xaecefc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xaecf00: ldr             x1, [x1, #0x148]
    // 0xaecf04: StoreField: r0->field_23 = r1
    //     0xaecf04: stur            w1, [x0, #0x23]
    // 0xaecf08: ldur            x1, [fp, #-8]
    // 0xaecf0c: StoreField: r0->field_b = r1
    //     0xaecf0c: stur            w1, [x0, #0xb]
    // 0xaecf10: LeaveFrame
    //     0xaecf10: mov             SP, fp
    //     0xaecf14: ldp             fp, lr, [SP], #0x10
    // 0xaecf18: ret
    //     0xaecf18: ret             
    // 0xaecf1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaecf1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaecf20: b               #0xaec8f0
    // 0xaecf24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xaecf44: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaecf44: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4350, size: 0xc, field offset: 0xc
//   const constructor, transformed mixin,
abstract class __ChangeAnimation&Animation&AnimationWithParentMixin extends Animation<double>
     with AnimationWithParentMixin<X0> {

  _ addListener(/* No info */) {
    // ** addr: 0x6e88f0, size: 0x74
    // 0x6e88f0: EnterFrame
    //     0x6e88f0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e88f4: mov             fp, SP
    // 0x6e88f8: CheckStackOverflow
    //     0x6e88f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e88fc: cmp             SP, x16
    //     0x6e8900: b.ls            #0x6e895c
    // 0x6e8904: ldr             x0, [fp, #0x18]
    // 0x6e8908: r1 = LoadClassIdInstr(r0)
    //     0x6e8908: ldur            x1, [x0, #-1]
    //     0x6e890c: ubfx            x1, x1, #0xc, #0x14
    // 0x6e8910: SaveReg r0
    //     0x6e8910: str             x0, [SP, #-8]!
    // 0x6e8914: mov             x0, x1
    // 0x6e8918: r0 = GDT[cid_x0 + -0x3c6]()
    //     0x6e8918: sub             lr, x0, #0x3c6
    //     0x6e891c: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8920: blr             lr
    // 0x6e8924: add             SP, SP, #8
    // 0x6e8928: r1 = LoadClassIdInstr(r0)
    //     0x6e8928: ldur            x1, [x0, #-1]
    //     0x6e892c: ubfx            x1, x1, #0xc, #0x14
    // 0x6e8930: ldr             x16, [fp, #0x10]
    // 0x6e8934: stp             x16, x0, [SP, #-0x10]!
    // 0x6e8938: mov             x0, x1
    // 0x6e893c: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x6e893c: mov             x17, #0xc3ab
    //     0x6e8940: add             lr, x0, x17
    //     0x6e8944: ldr             lr, [x21, lr, lsl #3]
    //     0x6e8948: blr             lr
    // 0x6e894c: add             SP, SP, #0x10
    // 0x6e8950: LeaveFrame
    //     0x6e8950: mov             SP, fp
    //     0x6e8954: ldp             fp, lr, [SP], #0x10
    // 0x6e8958: ret
    //     0x6e8958: ret             
    // 0x6e895c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e895c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e8960: b               #0x6e8904
  }
  _ removeListener(/* No info */) {
    // ** addr: 0x6f5d64, size: 0x74
    // 0x6f5d64: EnterFrame
    //     0x6f5d64: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5d68: mov             fp, SP
    // 0x6f5d6c: CheckStackOverflow
    //     0x6f5d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5d70: cmp             SP, x16
    //     0x6f5d74: b.ls            #0x6f5dd0
    // 0x6f5d78: ldr             x0, [fp, #0x18]
    // 0x6f5d7c: r1 = LoadClassIdInstr(r0)
    //     0x6f5d7c: ldur            x1, [x0, #-1]
    //     0x6f5d80: ubfx            x1, x1, #0xc, #0x14
    // 0x6f5d84: SaveReg r0
    //     0x6f5d84: str             x0, [SP, #-8]!
    // 0x6f5d88: mov             x0, x1
    // 0x6f5d8c: r0 = GDT[cid_x0 + -0x3c6]()
    //     0x6f5d8c: sub             lr, x0, #0x3c6
    //     0x6f5d90: ldr             lr, [x21, lr, lsl #3]
    //     0x6f5d94: blr             lr
    // 0x6f5d98: add             SP, SP, #8
    // 0x6f5d9c: r1 = LoadClassIdInstr(r0)
    //     0x6f5d9c: ldur            x1, [x0, #-1]
    //     0x6f5da0: ubfx            x1, x1, #0xc, #0x14
    // 0x6f5da4: ldr             x16, [fp, #0x10]
    // 0x6f5da8: stp             x16, x0, [SP, #-0x10]!
    // 0x6f5dac: mov             x0, x1
    // 0x6f5db0: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x6f5db0: mov             x17, #0xc2d6
    //     0x6f5db4: add             lr, x0, x17
    //     0x6f5db8: ldr             lr, [x21, lr, lsl #3]
    //     0x6f5dbc: blr             lr
    // 0x6f5dc0: add             SP, SP, #0x10
    // 0x6f5dc4: LeaveFrame
    //     0x6f5dc4: mov             SP, fp
    //     0x6f5dc8: ldp             fp, lr, [SP], #0x10
    // 0x6f5dcc: ret
    //     0x6f5dcc: ret             
    // 0x6f5dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5dd4: b               #0x6f5d78
  }
  _ addStatusListener(/* No info */) {
    // ** addr: 0xc52944, size: 0x70
    // 0xc52944: EnterFrame
    //     0xc52944: stp             fp, lr, [SP, #-0x10]!
    //     0xc52948: mov             fp, SP
    // 0xc5294c: CheckStackOverflow
    //     0xc5294c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc52950: cmp             SP, x16
    //     0xc52954: b.ls            #0xc529ac
    // 0xc52958: ldr             x0, [fp, #0x18]
    // 0xc5295c: r1 = LoadClassIdInstr(r0)
    //     0xc5295c: ldur            x1, [x0, #-1]
    //     0xc52960: ubfx            x1, x1, #0xc, #0x14
    // 0xc52964: SaveReg r0
    //     0xc52964: str             x0, [SP, #-8]!
    // 0xc52968: mov             x0, x1
    // 0xc5296c: r0 = GDT[cid_x0 + -0x3c6]()
    //     0xc5296c: sub             lr, x0, #0x3c6
    //     0xc52970: ldr             lr, [x21, lr, lsl #3]
    //     0xc52974: blr             lr
    // 0xc52978: add             SP, SP, #8
    // 0xc5297c: r1 = LoadClassIdInstr(r0)
    //     0xc5297c: ldur            x1, [x0, #-1]
    //     0xc52980: ubfx            x1, x1, #0xc, #0x14
    // 0xc52984: ldr             x16, [fp, #0x10]
    // 0xc52988: stp             x16, x0, [SP, #-0x10]!
    // 0xc5298c: mov             x0, x1
    // 0xc52990: r0 = GDT[cid_x0 + 0x80c]()
    //     0xc52990: add             lr, x0, #0x80c
    //     0xc52994: ldr             lr, [x21, lr, lsl #3]
    //     0xc52998: blr             lr
    // 0xc5299c: add             SP, SP, #0x10
    // 0xc529a0: LeaveFrame
    //     0xc529a0: mov             SP, fp
    //     0xc529a4: ldp             fp, lr, [SP], #0x10
    // 0xc529a8: ret
    //     0xc529a8: ret             
    // 0xc529ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc529ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc529b0: b               #0xc52958
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5dd74, size: 0x70
    // 0xc5dd74: EnterFrame
    //     0xc5dd74: stp             fp, lr, [SP, #-0x10]!
    //     0xc5dd78: mov             fp, SP
    // 0xc5dd7c: CheckStackOverflow
    //     0xc5dd7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5dd80: cmp             SP, x16
    //     0xc5dd84: b.ls            #0xc5dddc
    // 0xc5dd88: ldr             x0, [fp, #0x18]
    // 0xc5dd8c: r1 = LoadClassIdInstr(r0)
    //     0xc5dd8c: ldur            x1, [x0, #-1]
    //     0xc5dd90: ubfx            x1, x1, #0xc, #0x14
    // 0xc5dd94: SaveReg r0
    //     0xc5dd94: str             x0, [SP, #-8]!
    // 0xc5dd98: mov             x0, x1
    // 0xc5dd9c: r0 = GDT[cid_x0 + -0x3c6]()
    //     0xc5dd9c: sub             lr, x0, #0x3c6
    //     0xc5dda0: ldr             lr, [x21, lr, lsl #3]
    //     0xc5dda4: blr             lr
    // 0xc5dda8: add             SP, SP, #8
    // 0xc5ddac: r1 = LoadClassIdInstr(r0)
    //     0xc5ddac: ldur            x1, [x0, #-1]
    //     0xc5ddb0: ubfx            x1, x1, #0xc, #0x14
    // 0xc5ddb4: ldr             x16, [fp, #0x10]
    // 0xc5ddb8: stp             x16, x0, [SP, #-0x10]!
    // 0xc5ddbc: mov             x0, x1
    // 0xc5ddc0: r0 = GDT[cid_x0 + 0x490]()
    //     0xc5ddc0: add             lr, x0, #0x490
    //     0xc5ddc4: ldr             lr, [x21, lr, lsl #3]
    //     0xc5ddc8: blr             lr
    // 0xc5ddcc: add             SP, SP, #0x10
    // 0xc5ddd0: LeaveFrame
    //     0xc5ddd0: mov             SP, fp
    //     0xc5ddd4: ldp             fp, lr, [SP], #0x10
    // 0xc5ddd8: ret
    //     0xc5ddd8: ret             
    // 0xc5dddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5dddc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5dde0: b               #0xc5dd88
  }
  get _ status(/* No info */) {
    // ** addr: 0xc643f0, size: 0x6c
    // 0xc643f0: EnterFrame
    //     0xc643f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc643f4: mov             fp, SP
    // 0xc643f8: CheckStackOverflow
    //     0xc643f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc643fc: cmp             SP, x16
    //     0xc64400: b.ls            #0xc64454
    // 0xc64404: ldr             x0, [fp, #0x10]
    // 0xc64408: r1 = LoadClassIdInstr(r0)
    //     0xc64408: ldur            x1, [x0, #-1]
    //     0xc6440c: ubfx            x1, x1, #0xc, #0x14
    // 0xc64410: SaveReg r0
    //     0xc64410: str             x0, [SP, #-8]!
    // 0xc64414: mov             x0, x1
    // 0xc64418: r0 = GDT[cid_x0 + -0x3c6]()
    //     0xc64418: sub             lr, x0, #0x3c6
    //     0xc6441c: ldr             lr, [x21, lr, lsl #3]
    //     0xc64420: blr             lr
    // 0xc64424: add             SP, SP, #8
    // 0xc64428: r1 = LoadClassIdInstr(r0)
    //     0xc64428: ldur            x1, [x0, #-1]
    //     0xc6442c: ubfx            x1, x1, #0xc, #0x14
    // 0xc64430: SaveReg r0
    //     0xc64430: str             x0, [SP, #-8]!
    // 0xc64434: mov             x0, x1
    // 0xc64438: r0 = GDT[cid_x0 + 0x376]()
    //     0xc64438: add             lr, x0, #0x376
    //     0xc6443c: ldr             lr, [x21, lr, lsl #3]
    //     0xc64440: blr             lr
    // 0xc64444: add             SP, SP, #8
    // 0xc64448: LeaveFrame
    //     0xc64448: mov             SP, fp
    //     0xc6444c: ldp             fp, lr, [SP], #0x10
    // 0xc64450: ret
    //     0xc64450: ret             
    // 0xc64454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64454: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64458: b               #0xc64404
  }
}

// class id: 4351, size: 0x18, field offset: 0xc
class _DragAnimation extends __ChangeAnimation&Animation&AnimationWithParentMixin {

  _ removeListener(/* No info */) {
    // ** addr: 0x6f5dd8, size: 0x58
    // 0x6f5dd8: EnterFrame
    //     0x6f5dd8: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5ddc: mov             fp, SP
    // 0x6f5de0: CheckStackOverflow
    //     0x6f5de0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5de4: cmp             SP, x16
    //     0x6f5de8: b.ls            #0x6f5e28
    // 0x6f5dec: ldr             x0, [fp, #0x18]
    // 0x6f5df0: LoadField: r1 = r0->field_b
    //     0x6f5df0: ldur            w1, [x0, #0xb]
    // 0x6f5df4: DecompressPointer r1
    //     0x6f5df4: add             x1, x1, HEAP, lsl #32
    // 0x6f5df8: LoadField: r2 = r1->field_23
    //     0x6f5df8: ldur            w2, [x1, #0x23]
    // 0x6f5dfc: DecompressPointer r2
    //     0x6f5dfc: add             x2, x2, HEAP, lsl #32
    // 0x6f5e00: cmp             w2, NULL
    // 0x6f5e04: b.eq            #0x6f5e18
    // 0x6f5e08: ldr             x16, [fp, #0x10]
    // 0x6f5e0c: stp             x16, x0, [SP, #-0x10]!
    // 0x6f5e10: r0 = removeListener()
    //     0x6f5e10: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x6f5e14: add             SP, SP, #0x10
    // 0x6f5e18: r0 = Null
    //     0x6f5e18: mov             x0, NULL
    // 0x6f5e1c: LeaveFrame
    //     0x6f5e1c: mov             SP, fp
    //     0x6f5e20: ldp             fp, lr, [SP], #0x10
    // 0x6f5e24: ret
    //     0x6f5e24: ret             
    // 0x6f5e28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f5e28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5e2c: b               #0x6f5dec
  }
  get _ value(/* No info */) {
    // ** addr: 0xc249b4, size: 0x1d8
    // 0xc249b4: EnterFrame
    //     0xc249b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc249b8: mov             fp, SP
    // 0xc249bc: AllocStack(0x10)
    //     0xc249bc: sub             SP, SP, #0x10
    // 0xc249c0: CheckStackOverflow
    //     0xc249c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc249c4: cmp             SP, x16
    //     0xc249c8: b.ls            #0xc24b64
    // 0xc249cc: ldr             x2, [fp, #0x10]
    // 0xc249d0: LoadField: r3 = r2->field_b
    //     0xc249d0: ldur            w3, [x2, #0xb]
    // 0xc249d4: DecompressPointer r3
    //     0xc249d4: add             x3, x3, HEAP, lsl #32
    // 0xc249d8: stur            x3, [fp, #-8]
    // 0xc249dc: LoadField: r0 = r3->field_2b
    //     0xc249dc: ldur            x0, [x3, #0x2b]
    // 0xc249e0: sub             x4, x0, #1
    // 0xc249e4: r0 = BoxInt64Instr(r4)
    //     0xc249e4: sbfiz           x0, x4, #1, #0x1f
    //     0xc249e8: cmp             x4, x0, asr #1
    //     0xc249ec: b.eq            #0xc249f8
    //     0xc249f0: bl              #0xd69bb8
    //     0xc249f4: stur            x4, [x0, #7]
    // 0xc249f8: stp             x0, NULL, [SP, #-0x10]!
    // 0xc249fc: r0 = _Double.fromInteger()
    //     0xc249fc: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xc24a00: add             SP, SP, #0x10
    // 0xc24a04: mov             x1, x0
    // 0xc24a08: ldur            x0, [fp, #-8]
    // 0xc24a0c: LoadField: r2 = r0->field_23
    //     0xc24a0c: ldur            w2, [x0, #0x23]
    // 0xc24a10: DecompressPointer r2
    //     0xc24a10: add             x2, x2, HEAP, lsl #32
    // 0xc24a14: cmp             w2, NULL
    // 0xc24a18: b.ne            #0xc24a24
    // 0xc24a1c: r0 = Null
    //     0xc24a1c: mov             x0, NULL
    // 0xc24a20: b               #0xc24a28
    // 0xc24a24: mov             x0, x2
    // 0xc24a28: d0 = 0.000000
    //     0xc24a28: eor             v0.16b, v0.16b, v0.16b
    // 0xc24a2c: cmp             w0, NULL
    // 0xc24a30: b.eq            #0xc24b6c
    // 0xc24a34: LoadField: r2 = r0->field_37
    //     0xc24a34: ldur            w2, [x0, #0x37]
    // 0xc24a38: DecompressPointer r2
    //     0xc24a38: add             x2, x2, HEAP, lsl #32
    // 0xc24a3c: r16 = Sentinel
    //     0xc24a3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc24a40: cmp             w2, w16
    // 0xc24a44: b.eq            #0xc24b70
    // 0xc24a48: LoadField: d1 = r2->field_7
    //     0xc24a48: ldur            d1, [x2, #7]
    // 0xc24a4c: fcmp            d1, d0
    // 0xc24a50: b.vs            #0xc24a60
    // 0xc24a54: b.ge            #0xc24a60
    // 0xc24a58: d1 = 0.000000
    //     0xc24a58: eor             v1.16b, v1.16b, v1.16b
    // 0xc24a5c: b               #0xc24a88
    // 0xc24a60: LoadField: d2 = r1->field_7
    //     0xc24a60: ldur            d2, [x1, #7]
    // 0xc24a64: fcmp            d1, d2
    // 0xc24a68: b.vs            #0xc24a78
    // 0xc24a6c: b.le            #0xc24a78
    // 0xc24a70: mov             v1.16b, v2.16b
    // 0xc24a74: b               #0xc24a88
    // 0xc24a78: LoadField: d3 = r2->field_7
    //     0xc24a78: ldur            d3, [x2, #7]
    // 0xc24a7c: fcmp            d3, d3
    // 0xc24a80: b.vc            #0xc24a88
    // 0xc24a84: mov             v1.16b, v2.16b
    // 0xc24a88: ldr             x0, [fp, #0x10]
    // 0xc24a8c: stur            d1, [fp, #-0x10]
    // 0xc24a90: LoadField: r2 = r0->field_f
    //     0xc24a90: ldur            x2, [x0, #0xf]
    // 0xc24a94: r0 = BoxInt64Instr(r2)
    //     0xc24a94: sbfiz           x0, x2, #1, #0x1f
    //     0xc24a98: cmp             x2, x0, asr #1
    //     0xc24a9c: b.eq            #0xc24aa8
    //     0xc24aa0: bl              #0xd69c6c
    //     0xc24aa4: stur            x2, [x0, #7]
    // 0xc24aa8: stp             x0, NULL, [SP, #-0x10]!
    // 0xc24aac: r0 = _Double.fromInteger()
    //     0xc24aac: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xc24ab0: add             SP, SP, #0x10
    // 0xc24ab4: LoadField: d0 = r0->field_7
    //     0xc24ab4: ldur            d0, [x0, #7]
    // 0xc24ab8: ldur            d1, [fp, #-0x10]
    // 0xc24abc: fsub            d2, d1, d0
    // 0xc24ac0: d0 = 0.000000
    //     0xc24ac0: eor             v0.16b, v0.16b, v0.16b
    // 0xc24ac4: fcmp            d2, d0
    // 0xc24ac8: b.vs            #0xc24ad8
    // 0xc24acc: b.ne            #0xc24ad8
    // 0xc24ad0: d1 = 0.000000
    //     0xc24ad0: eor             v1.16b, v1.16b, v1.16b
    // 0xc24ad4: b               #0xc24af0
    // 0xc24ad8: fcmp            d2, d0
    // 0xc24adc: b.vs            #0xc24aec
    // 0xc24ae0: b.ge            #0xc24aec
    // 0xc24ae4: fneg            d1, d2
    // 0xc24ae8: b               #0xc24af0
    // 0xc24aec: mov             v1.16b, v2.16b
    // 0xc24af0: fcmp            d1, d0
    // 0xc24af4: b.vs            #0xc24b04
    // 0xc24af8: b.ge            #0xc24b04
    // 0xc24afc: d0 = 0.000000
    //     0xc24afc: eor             v0.16b, v0.16b, v0.16b
    // 0xc24b00: b               #0xc24b30
    // 0xc24b04: d0 = 1.000000
    //     0xc24b04: fmov            d0, #1.00000000
    // 0xc24b08: fcmp            d1, d0
    // 0xc24b0c: b.vs            #0xc24b1c
    // 0xc24b10: b.le            #0xc24b1c
    // 0xc24b14: d0 = 1.000000
    //     0xc24b14: fmov            d0, #1.00000000
    // 0xc24b18: b               #0xc24b30
    // 0xc24b1c: fcmp            d1, d1
    // 0xc24b20: b.vc            #0xc24b2c
    // 0xc24b24: d0 = 1.000000
    //     0xc24b24: fmov            d0, #1.00000000
    // 0xc24b28: b               #0xc24b30
    // 0xc24b2c: mov             v0.16b, v1.16b
    // 0xc24b30: r0 = inline_Allocate_Double()
    //     0xc24b30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc24b34: add             x0, x0, #0x10
    //     0xc24b38: cmp             x1, x0
    //     0xc24b3c: b.ls            #0xc24b7c
    //     0xc24b40: str             x0, [THR, #0x60]  ; THR::top
    //     0xc24b44: sub             x0, x0, #0xf
    //     0xc24b48: mov             x1, #0xd108
    //     0xc24b4c: movk            x1, #3, lsl #16
    //     0xc24b50: stur            x1, [x0, #-1]
    // 0xc24b54: StoreField: r0->field_7 = d0
    //     0xc24b54: stur            d0, [x0, #7]
    // 0xc24b58: LeaveFrame
    //     0xc24b58: mov             SP, fp
    //     0xc24b5c: ldp             fp, lr, [SP], #0x10
    // 0xc24b60: ret
    //     0xc24b60: ret             
    // 0xc24b64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc24b64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc24b68: b               #0xc249cc
    // 0xc24b6c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc24b6c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc24b70: r9 = _value
    //     0xc24b70: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc24b74: ldr             x9, [x9, #0xbb0]
    // 0xc24b78: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc24b78: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xc24b7c: SaveReg d0
    //     0xc24b7c: str             q0, [SP, #-0x10]!
    // 0xc24b80: r0 = AllocateDouble()
    //     0xc24b80: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc24b84: RestoreReg d0
    //     0xc24b84: ldr             q0, [SP], #0x10
    // 0xc24b88: b               #0xc24b54
  }
  _ removeStatusListener(/* No info */) {
    // ** addr: 0xc5dde4, size: 0x58
    // 0xc5dde4: EnterFrame
    //     0xc5dde4: stp             fp, lr, [SP, #-0x10]!
    //     0xc5dde8: mov             fp, SP
    // 0xc5ddec: CheckStackOverflow
    //     0xc5ddec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5ddf0: cmp             SP, x16
    //     0xc5ddf4: b.ls            #0xc5de34
    // 0xc5ddf8: ldr             x0, [fp, #0x18]
    // 0xc5ddfc: LoadField: r1 = r0->field_b
    //     0xc5ddfc: ldur            w1, [x0, #0xb]
    // 0xc5de00: DecompressPointer r1
    //     0xc5de00: add             x1, x1, HEAP, lsl #32
    // 0xc5de04: LoadField: r2 = r1->field_23
    //     0xc5de04: ldur            w2, [x1, #0x23]
    // 0xc5de08: DecompressPointer r2
    //     0xc5de08: add             x2, x2, HEAP, lsl #32
    // 0xc5de0c: cmp             w2, NULL
    // 0xc5de10: b.eq            #0xc5de24
    // 0xc5de14: ldr             x16, [fp, #0x10]
    // 0xc5de18: stp             x16, x0, [SP, #-0x10]!
    // 0xc5de1c: r0 = removeStatusListener()
    //     0xc5de1c: bl              #0xc5dd74  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeStatusListener
    // 0xc5de20: add             SP, SP, #0x10
    // 0xc5de24: r0 = Null
    //     0xc5de24: mov             x0, NULL
    // 0xc5de28: LeaveFrame
    //     0xc5de28: mov             SP, fp
    //     0xc5de2c: ldp             fp, lr, [SP], #0x10
    // 0xc5de30: ret
    //     0xc5de30: ret             
    // 0xc5de34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5de34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5de38: b               #0xc5ddf8
  }
  get _ parent(/* No info */) {
    // ** addr: 0xc7a624, size: 0x48
    // 0xc7a624: EnterFrame
    //     0xc7a624: stp             fp, lr, [SP, #-0x10]!
    //     0xc7a628: mov             fp, SP
    // 0xc7a62c: ldr             x1, [fp, #0x10]
    // 0xc7a630: LoadField: r2 = r1->field_b
    //     0xc7a630: ldur            w2, [x1, #0xb]
    // 0xc7a634: DecompressPointer r2
    //     0xc7a634: add             x2, x2, HEAP, lsl #32
    // 0xc7a638: LoadField: r1 = r2->field_23
    //     0xc7a638: ldur            w1, [x2, #0x23]
    // 0xc7a63c: DecompressPointer r1
    //     0xc7a63c: add             x1, x1, HEAP, lsl #32
    // 0xc7a640: cmp             w1, NULL
    // 0xc7a644: b.ne            #0xc7a650
    // 0xc7a648: r0 = Null
    //     0xc7a648: mov             x0, NULL
    // 0xc7a64c: b               #0xc7a654
    // 0xc7a650: mov             x0, x1
    // 0xc7a654: cmp             w0, NULL
    // 0xc7a658: b.eq            #0xc7a668
    // 0xc7a65c: LeaveFrame
    //     0xc7a65c: mov             SP, fp
    //     0xc7a660: ldp             fp, lr, [SP], #0x10
    // 0xc7a664: ret
    //     0xc7a664: ret             
    // 0xc7a668: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a668: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4352, size: 0x10, field offset: 0xc
class _ChangeAnimation extends __ChangeAnimation&Animation&AnimationWithParentMixin {

  get _ value(/* No info */) {
    // ** addr: 0xc2475c, size: 0x78
    // 0xc2475c: EnterFrame
    //     0xc2475c: stp             fp, lr, [SP, #-0x10]!
    //     0xc24760: mov             fp, SP
    // 0xc24764: CheckStackOverflow
    //     0xc24764: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc24768: cmp             SP, x16
    //     0xc2476c: b.ls            #0xc247bc
    // 0xc24770: ldr             x0, [fp, #0x10]
    // 0xc24774: LoadField: r1 = r0->field_b
    //     0xc24774: ldur            w1, [x0, #0xb]
    // 0xc24778: DecompressPointer r1
    //     0xc24778: add             x1, x1, HEAP, lsl #32
    // 0xc2477c: SaveReg r1
    //     0xc2477c: str             x1, [SP, #-8]!
    // 0xc24780: r0 = _indexChangeProgress()
    //     0xc24780: bl              #0xc247d4  ; [package:flutter/src/material/tabs.dart] ::_indexChangeProgress
    // 0xc24784: add             SP, SP, #8
    // 0xc24788: r0 = inline_Allocate_Double()
    //     0xc24788: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc2478c: add             x0, x0, #0x10
    //     0xc24790: cmp             x1, x0
    //     0xc24794: b.ls            #0xc247c4
    //     0xc24798: str             x0, [THR, #0x60]  ; THR::top
    //     0xc2479c: sub             x0, x0, #0xf
    //     0xc247a0: mov             x1, #0xd108
    //     0xc247a4: movk            x1, #3, lsl #16
    //     0xc247a8: stur            x1, [x0, #-1]
    // 0xc247ac: StoreField: r0->field_7 = d0
    //     0xc247ac: stur            d0, [x0, #7]
    // 0xc247b0: LeaveFrame
    //     0xc247b0: mov             SP, fp
    //     0xc247b4: ldp             fp, lr, [SP], #0x10
    // 0xc247b8: ret
    //     0xc247b8: ret             
    // 0xc247bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc247bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc247c0: b               #0xc24770
    // 0xc247c4: SaveReg d0
    //     0xc247c4: str             q0, [SP, #-0x10]!
    // 0xc247c8: r0 = AllocateDouble()
    //     0xc247c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc247cc: RestoreReg d0
    //     0xc247cc: ldr             q0, [SP], #0x10
    // 0xc247d0: b               #0xc247ac
  }
}

// class id: 4372, size: 0x38, field offset: 0xc
class _IndicatorPainter extends CustomPainter {

  _ _IndicatorPainter(/* No info */) {
    // ** addr: 0x7bc940, size: 0x160
    // 0x7bc940: EnterFrame
    //     0x7bc940: stp             fp, lr, [SP, #-0x10]!
    //     0x7bc944: mov             fp, SP
    // 0x7bc948: r0 = false
    //     0x7bc948: add             x0, NULL, #0x30  ; false
    // 0x7bc94c: CheckStackOverflow
    //     0x7bc94c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bc950: cmp             SP, x16
    //     0x7bc954: b.ls            #0x7bca98
    // 0x7bc958: ldr             x1, [fp, #0x48]
    // 0x7bc95c: StoreField: r1->field_33 = r0
    //     0x7bc95c: stur            w0, [x1, #0x33]
    // 0x7bc960: ldr             x0, [fp, #0x40]
    // 0x7bc964: StoreField: r1->field_b = r0
    //     0x7bc964: stur            w0, [x1, #0xb]
    //     0x7bc968: ldurb           w16, [x1, #-1]
    //     0x7bc96c: ldurb           w17, [x0, #-1]
    //     0x7bc970: and             x16, x17, x16, lsr #2
    //     0x7bc974: tst             x16, HEAP, lsr #32
    //     0x7bc978: b.eq            #0x7bc980
    //     0x7bc97c: bl              #0xd6826c
    // 0x7bc980: ldr             x0, [fp, #0x30]
    // 0x7bc984: StoreField: r1->field_f = r0
    //     0x7bc984: stur            w0, [x1, #0xf]
    //     0x7bc988: ldurb           w16, [x1, #-1]
    //     0x7bc98c: ldurb           w17, [x0, #-1]
    //     0x7bc990: and             x16, x17, x16, lsr #2
    //     0x7bc994: tst             x16, HEAP, lsr #32
    //     0x7bc998: b.eq            #0x7bc9a0
    //     0x7bc99c: bl              #0xd6826c
    // 0x7bc9a0: ldr             x0, [fp, #0x20]
    // 0x7bc9a4: StoreField: r1->field_13 = r0
    //     0x7bc9a4: stur            w0, [x1, #0x13]
    //     0x7bc9a8: ldurb           w16, [x1, #-1]
    //     0x7bc9ac: ldurb           w17, [x0, #-1]
    //     0x7bc9b0: and             x16, x17, x16, lsr #2
    //     0x7bc9b4: tst             x16, HEAP, lsr #32
    //     0x7bc9b8: b.eq            #0x7bc9c0
    //     0x7bc9bc: bl              #0xd6826c
    // 0x7bc9c0: ldr             x0, [fp, #0x10]
    // 0x7bc9c4: StoreField: r1->field_1b = r0
    //     0x7bc9c4: stur            w0, [x1, #0x1b]
    //     0x7bc9c8: ldurb           w16, [x1, #-1]
    //     0x7bc9cc: ldurb           w17, [x0, #-1]
    //     0x7bc9d0: and             x16, x17, x16, lsr #2
    //     0x7bc9d4: tst             x16, HEAP, lsr #32
    //     0x7bc9d8: b.eq            #0x7bc9e0
    //     0x7bc9dc: bl              #0xd6826c
    // 0x7bc9e0: ldr             x0, [fp, #0x28]
    // 0x7bc9e4: StoreField: r1->field_17 = r0
    //     0x7bc9e4: stur            w0, [x1, #0x17]
    //     0x7bc9e8: ldurb           w16, [x1, #-1]
    //     0x7bc9ec: ldurb           w17, [x0, #-1]
    //     0x7bc9f0: and             x16, x17, x16, lsr #2
    //     0x7bc9f4: tst             x16, HEAP, lsr #32
    //     0x7bc9f8: b.eq            #0x7bca00
    //     0x7bc9fc: bl              #0xd6826c
    // 0x7bca00: ldr             x0, [fp, #0x38]
    // 0x7bca04: StoreField: r1->field_1f = r0
    //     0x7bca04: stur            w0, [x1, #0x1f]
    //     0x7bca08: ldurb           w16, [x1, #-1]
    //     0x7bca0c: ldurb           w17, [x0, #-1]
    //     0x7bca10: and             x16, x17, x16, lsr #2
    //     0x7bca14: tst             x16, HEAP, lsr #32
    //     0x7bca18: b.eq            #0x7bca20
    //     0x7bca1c: bl              #0xd6826c
    // 0x7bca20: ldr             x0, [fp, #0x40]
    // 0x7bca24: LoadField: r2 = r0->field_23
    //     0x7bca24: ldur            w2, [x0, #0x23]
    // 0x7bca28: DecompressPointer r2
    //     0x7bca28: add             x2, x2, HEAP, lsl #32
    // 0x7bca2c: cmp             w2, NULL
    // 0x7bca30: b.ne            #0x7bca3c
    // 0x7bca34: r0 = Null
    //     0x7bca34: mov             x0, NULL
    // 0x7bca38: b               #0x7bca40
    // 0x7bca3c: mov             x0, x2
    // 0x7bca40: ldr             x2, [fp, #0x18]
    // 0x7bca44: StoreField: r1->field_7 = r0
    //     0x7bca44: stur            w0, [x1, #7]
    //     0x7bca48: ldurb           w16, [x1, #-1]
    //     0x7bca4c: ldurb           w17, [x0, #-1]
    //     0x7bca50: and             x16, x17, x16, lsr #2
    //     0x7bca54: tst             x16, HEAP, lsr #32
    //     0x7bca58: b.eq            #0x7bca60
    //     0x7bca5c: bl              #0xd6826c
    // 0x7bca60: cmp             w2, NULL
    // 0x7bca64: b.eq            #0x7bca88
    // 0x7bca68: LoadField: r0 = r2->field_23
    //     0x7bca68: ldur            w0, [x2, #0x23]
    // 0x7bca6c: DecompressPointer r0
    //     0x7bca6c: add             x0, x0, HEAP, lsl #32
    // 0x7bca70: LoadField: r3 = r2->field_27
    //     0x7bca70: ldur            w3, [x2, #0x27]
    // 0x7bca74: DecompressPointer r3
    //     0x7bca74: add             x3, x3, HEAP, lsl #32
    // 0x7bca78: stp             x0, x1, [SP, #-0x10]!
    // 0x7bca7c: SaveReg r3
    //     0x7bca7c: str             x3, [SP, #-8]!
    // 0x7bca80: r0 = saveTabOffsets()
    //     0x7bca80: bl              #0x7bcaa0  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::saveTabOffsets
    // 0x7bca84: add             SP, SP, #0x18
    // 0x7bca88: r0 = Null
    //     0x7bca88: mov             x0, NULL
    // 0x7bca8c: LeaveFrame
    //     0x7bca8c: mov             SP, fp
    //     0x7bca90: ldp             fp, lr, [SP], #0x10
    // 0x7bca94: ret
    //     0x7bca94: ret             
    // 0x7bca98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bca98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bca9c: b               #0x7bc958
  }
  _ saveTabOffsets(/* No info */) {
    // ** addr: 0x7bcaa0, size: 0x5c
    // 0x7bcaa0: EnterFrame
    //     0x7bcaa0: stp             fp, lr, [SP, #-0x10]!
    //     0x7bcaa4: mov             fp, SP
    // 0x7bcaa8: ldr             x0, [fp, #0x18]
    // 0x7bcaac: ldr             x1, [fp, #0x20]
    // 0x7bcab0: StoreField: r1->field_23 = r0
    //     0x7bcab0: stur            w0, [x1, #0x23]
    //     0x7bcab4: ldurb           w16, [x1, #-1]
    //     0x7bcab8: ldurb           w17, [x0, #-1]
    //     0x7bcabc: and             x16, x17, x16, lsr #2
    //     0x7bcac0: tst             x16, HEAP, lsr #32
    //     0x7bcac4: b.eq            #0x7bcacc
    //     0x7bcac8: bl              #0xd6826c
    // 0x7bcacc: ldr             x0, [fp, #0x10]
    // 0x7bcad0: StoreField: r1->field_27 = r0
    //     0x7bcad0: stur            w0, [x1, #0x27]
    //     0x7bcad4: ldurb           w16, [x1, #-1]
    //     0x7bcad8: ldurb           w17, [x0, #-1]
    //     0x7bcadc: and             x16, x17, x16, lsr #2
    //     0x7bcae0: tst             x16, HEAP, lsr #32
    //     0x7bcae4: b.eq            #0x7bcaec
    //     0x7bcae8: bl              #0xd6826c
    // 0x7bcaec: r0 = Null
    //     0x7bcaec: mov             x0, NULL
    // 0x7bcaf0: LeaveFrame
    //     0x7bcaf0: mov             SP, fp
    //     0x7bcaf4: ldp             fp, lr, [SP], #0x10
    // 0x7bcaf8: ret
    //     0x7bcaf8: ret             
  }
  _ centerOf(/* No info */) {
    // ** addr: 0x7bd744, size: 0xf4
    // 0x7bd744: EnterFrame
    //     0x7bd744: stp             fp, lr, [SP, #-0x10]!
    //     0x7bd748: mov             fp, SP
    // 0x7bd74c: AllocStack(0x8)
    //     0x7bd74c: sub             SP, SP, #8
    // 0x7bd750: CheckStackOverflow
    //     0x7bd750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bd754: cmp             SP, x16
    //     0x7bd758: b.ls            #0x7bd828
    // 0x7bd75c: ldr             x2, [fp, #0x18]
    // 0x7bd760: LoadField: r3 = r2->field_23
    //     0x7bd760: ldur            w3, [x2, #0x23]
    // 0x7bd764: DecompressPointer r3
    //     0x7bd764: add             x3, x3, HEAP, lsl #32
    // 0x7bd768: cmp             w3, NULL
    // 0x7bd76c: b.eq            #0x7bd830
    // 0x7bd770: ldr             x4, [fp, #0x10]
    // 0x7bd774: r0 = BoxInt64Instr(r4)
    //     0x7bd774: sbfiz           x0, x4, #1, #0x1f
    //     0x7bd778: cmp             x4, x0, asr #1
    //     0x7bd77c: b.eq            #0x7bd788
    //     0x7bd780: bl              #0xd69bb8
    //     0x7bd784: stur            x4, [x0, #7]
    // 0x7bd788: r1 = LoadClassIdInstr(r3)
    //     0x7bd788: ldur            x1, [x3, #-1]
    //     0x7bd78c: ubfx            x1, x1, #0xc, #0x14
    // 0x7bd790: stp             x0, x3, [SP, #-0x10]!
    // 0x7bd794: mov             x0, x1
    // 0x7bd798: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7bd798: sub             lr, x0, #0xd83
    //     0x7bd79c: ldr             lr, [x21, lr, lsl #3]
    //     0x7bd7a0: blr             lr
    // 0x7bd7a4: add             SP, SP, #0x10
    // 0x7bd7a8: mov             x2, x0
    // 0x7bd7ac: ldr             x0, [fp, #0x18]
    // 0x7bd7b0: stur            x2, [fp, #-8]
    // 0x7bd7b4: LoadField: r3 = r0->field_23
    //     0x7bd7b4: ldur            w3, [x0, #0x23]
    // 0x7bd7b8: DecompressPointer r3
    //     0x7bd7b8: add             x3, x3, HEAP, lsl #32
    // 0x7bd7bc: cmp             w3, NULL
    // 0x7bd7c0: b.eq            #0x7bd834
    // 0x7bd7c4: ldr             x0, [fp, #0x10]
    // 0x7bd7c8: add             x4, x0, #1
    // 0x7bd7cc: r0 = BoxInt64Instr(r4)
    //     0x7bd7cc: sbfiz           x0, x4, #1, #0x1f
    //     0x7bd7d0: cmp             x4, x0, asr #1
    //     0x7bd7d4: b.eq            #0x7bd7e0
    //     0x7bd7d8: bl              #0xd69bb8
    //     0x7bd7dc: stur            x4, [x0, #7]
    // 0x7bd7e0: r1 = LoadClassIdInstr(r3)
    //     0x7bd7e0: ldur            x1, [x3, #-1]
    //     0x7bd7e4: ubfx            x1, x1, #0xc, #0x14
    // 0x7bd7e8: stp             x0, x3, [SP, #-0x10]!
    // 0x7bd7ec: mov             x0, x1
    // 0x7bd7f0: r0 = GDT[cid_x0 + -0xd83]()
    //     0x7bd7f0: sub             lr, x0, #0xd83
    //     0x7bd7f4: ldr             lr, [x21, lr, lsl #3]
    //     0x7bd7f8: blr             lr
    // 0x7bd7fc: add             SP, SP, #0x10
    // 0x7bd800: mov             x1, x0
    // 0x7bd804: ldur            x0, [fp, #-8]
    // 0x7bd808: LoadField: d1 = r0->field_7
    //     0x7bd808: ldur            d1, [x0, #7]
    // 0x7bd80c: LoadField: d2 = r1->field_7
    //     0x7bd80c: ldur            d2, [x1, #7]
    // 0x7bd810: fadd            d3, d1, d2
    // 0x7bd814: d1 = 2.000000
    //     0x7bd814: fmov            d1, #2.00000000
    // 0x7bd818: fdiv            d0, d3, d1
    // 0x7bd81c: LeaveFrame
    //     0x7bd81c: mov             SP, fp
    //     0x7bd820: ldp             fp, lr, [SP], #0x10
    // 0x7bd824: ret
    //     0x7bd824: ret             
    // 0x7bd828: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bd828: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bd82c: b               #0x7bd75c
    // 0x7bd830: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd830: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bd834: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bd834: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ maxTabIndex(/* No info */) {
    // ** addr: 0x7bddf8, size: 0x70
    // 0x7bddf8: EnterFrame
    //     0x7bddf8: stp             fp, lr, [SP, #-0x10]!
    //     0x7bddfc: mov             fp, SP
    // 0x7bde00: CheckStackOverflow
    //     0x7bde00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bde04: cmp             SP, x16
    //     0x7bde08: b.ls            #0x7bde5c
    // 0x7bde0c: ldr             x0, [fp, #0x10]
    // 0x7bde10: LoadField: r1 = r0->field_23
    //     0x7bde10: ldur            w1, [x0, #0x23]
    // 0x7bde14: DecompressPointer r1
    //     0x7bde14: add             x1, x1, HEAP, lsl #32
    // 0x7bde18: cmp             w1, NULL
    // 0x7bde1c: b.eq            #0x7bde64
    // 0x7bde20: r0 = LoadClassIdInstr(r1)
    //     0x7bde20: ldur            x0, [x1, #-1]
    //     0x7bde24: ubfx            x0, x0, #0xc, #0x14
    // 0x7bde28: SaveReg r1
    //     0x7bde28: str             x1, [SP, #-8]!
    // 0x7bde2c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x7bde2c: mov             x17, #0xb8ea
    //     0x7bde30: add             lr, x0, x17
    //     0x7bde34: ldr             lr, [x21, lr, lsl #3]
    //     0x7bde38: blr             lr
    // 0x7bde3c: add             SP, SP, #8
    // 0x7bde40: r1 = LoadInt32Instr(r0)
    //     0x7bde40: sbfx            x1, x0, #1, #0x1f
    //     0x7bde44: tbz             w0, #0, #0x7bde4c
    //     0x7bde48: ldur            x1, [x0, #7]
    // 0x7bde4c: sub             x0, x1, #2
    // 0x7bde50: LeaveFrame
    //     0x7bde50: mov             SP, fp
    //     0x7bde54: ldp             fp, lr, [SP], #0x10
    // 0x7bde58: ret
    //     0x7bde58: ret             
    // 0x7bde5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bde5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bde60: b               #0x7bde0c
    // 0x7bde64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bde64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xa704e4, size: 0x62c
    // 0xa704e4: EnterFrame
    //     0xa704e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa704e8: mov             fp, SP
    // 0xa704ec: AllocStack(0x38)
    //     0xa704ec: sub             SP, SP, #0x38
    // 0xa704f0: r0 = false
    //     0xa704f0: add             x0, NULL, #0x30  ; false
    // 0xa704f4: CheckStackOverflow
    //     0xa704f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa704f8: cmp             SP, x16
    //     0xa704fc: b.ls            #0xa70a94
    // 0xa70500: ldr             x1, [fp, #0x20]
    // 0xa70504: StoreField: r1->field_33 = r0
    //     0xa70504: stur            w0, [x1, #0x33]
    // 0xa70508: LoadField: r0 = r1->field_2f
    //     0xa70508: ldur            w0, [x1, #0x2f]
    // 0xa7050c: DecompressPointer r0
    //     0xa7050c: add             x0, x0, HEAP, lsl #32
    // 0xa70510: cmp             w0, NULL
    // 0xa70514: b.ne            #0xa7057c
    // 0xa70518: LoadField: r0 = r1->field_f
    //     0xa70518: ldur            w0, [x1, #0xf]
    // 0xa7051c: DecompressPointer r0
    //     0xa7051c: add             x0, x0, HEAP, lsl #32
    // 0xa70520: stur            x0, [fp, #-8]
    // 0xa70524: r1 = 1
    //     0xa70524: mov             x1, #1
    // 0xa70528: r0 = AllocateContext()
    //     0xa70528: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa7052c: mov             x1, x0
    // 0xa70530: ldr             x0, [fp, #0x20]
    // 0xa70534: StoreField: r1->field_f = r0
    //     0xa70534: stur            w0, [x1, #0xf]
    // 0xa70538: mov             x2, x1
    // 0xa7053c: r1 = Function 'markNeedsPaint':.
    //     0xa7053c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40d10] AnonymousClosure: (0xa70f38), in [package:flutter/src/material/tabs.dart] _IndicatorPainter::markNeedsPaint (0xa70f80)
    //     0xa70540: ldr             x1, [x1, #0xd10]
    // 0xa70544: r0 = AllocateClosure()
    //     0xa70544: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa70548: ldur            x16, [fp, #-8]
    // 0xa7054c: stp             x0, x16, [SP, #-0x10]!
    // 0xa70550: r0 = createBoxPainter()
    //     0xa70550: bl              #0xccf528  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::createBoxPainter
    // 0xa70554: add             SP, SP, #0x10
    // 0xa70558: ldr             x2, [fp, #0x20]
    // 0xa7055c: StoreField: r2->field_2f = r0
    //     0xa7055c: stur            w0, [x2, #0x2f]
    //     0xa70560: ldurb           w16, [x2, #-1]
    //     0xa70564: ldurb           w17, [x0, #-1]
    //     0xa70568: and             x16, x17, x16, lsr #2
    //     0xa7056c: tst             x16, HEAP, lsr #32
    //     0xa70570: b.eq            #0xa70578
    //     0xa70574: bl              #0xd6828c
    // 0xa70578: b               #0xa70580
    // 0xa7057c: mov             x2, x1
    // 0xa70580: LoadField: r3 = r2->field_b
    //     0xa70580: ldur            w3, [x2, #0xb]
    // 0xa70584: DecompressPointer r3
    //     0xa70584: add             x3, x3, HEAP, lsl #32
    // 0xa70588: stur            x3, [fp, #-8]
    // 0xa7058c: LoadField: r4 = r3->field_33
    //     0xa7058c: ldur            x4, [x3, #0x33]
    // 0xa70590: r0 = BoxInt64Instr(r4)
    //     0xa70590: sbfiz           x0, x4, #1, #0x1f
    //     0xa70594: cmp             x4, x0, asr #1
    //     0xa70598: b.eq            #0xa705a4
    //     0xa7059c: bl              #0xd69bb8
    //     0xa705a0: stur            x4, [x0, #7]
    // 0xa705a4: stp             x0, NULL, [SP, #-0x10]!
    // 0xa705a8: r0 = _Double.fromInteger()
    //     0xa705a8: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xa705ac: add             SP, SP, #0x10
    // 0xa705b0: mov             x1, x0
    // 0xa705b4: ldur            x0, [fp, #-8]
    // 0xa705b8: LoadField: r2 = r0->field_23
    //     0xa705b8: ldur            w2, [x0, #0x23]
    // 0xa705bc: DecompressPointer r2
    //     0xa705bc: add             x2, x2, HEAP, lsl #32
    // 0xa705c0: cmp             w2, NULL
    // 0xa705c4: b.ne            #0xa705d0
    // 0xa705c8: r0 = Null
    //     0xa705c8: mov             x0, NULL
    // 0xa705cc: b               #0xa705d4
    // 0xa705d0: mov             x0, x2
    // 0xa705d4: cmp             w0, NULL
    // 0xa705d8: b.eq            #0xa70a9c
    // 0xa705dc: LoadField: r2 = r0->field_37
    //     0xa705dc: ldur            w2, [x0, #0x37]
    // 0xa705e0: DecompressPointer r2
    //     0xa705e0: add             x2, x2, HEAP, lsl #32
    // 0xa705e4: r16 = Sentinel
    //     0xa705e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa705e8: cmp             w2, w16
    // 0xa705ec: b.eq            #0xa70aa0
    // 0xa705f0: LoadField: d0 = r1->field_7
    //     0xa705f0: ldur            d0, [x1, #7]
    // 0xa705f4: LoadField: d1 = r2->field_7
    //     0xa705f4: ldur            d1, [x2, #7]
    // 0xa705f8: stur            d1, [fp, #-0x30]
    // 0xa705fc: fcmp            d0, d1
    // 0xa70600: b.vs            #0xa70608
    // 0xa70604: b.gt            #0xa70610
    // 0xa70608: r1 = false
    //     0xa70608: add             x1, NULL, #0x30  ; false
    // 0xa7060c: b               #0xa70614
    // 0xa70610: r1 = true
    //     0xa70610: add             x1, NULL, #0x20  ; true
    // 0xa70614: stur            x1, [fp, #-8]
    // 0xa70618: tbnz            w1, #4, #0xa7064c
    // 0xa7061c: fcmp            d1, d1
    // 0xa70620: b.vs            #0xa70aac
    // 0xa70624: fcvtms          x0, d1
    // 0xa70628: asr             x16, x0, #0x1e
    // 0xa7062c: cmp             x16, x0, asr #63
    // 0xa70630: b.ne            #0xa70aac
    // 0xa70634: lsl             x0, x0, #1
    // 0xa70638: r2 = LoadInt32Instr(r0)
    //     0xa70638: sbfx            x2, x0, #1, #0x1f
    //     0xa7063c: tbz             w0, #0, #0xa70644
    //     0xa70640: ldur            x2, [x0, #7]
    // 0xa70644: mov             x3, x2
    // 0xa70648: b               #0xa70678
    // 0xa7064c: fcmp            d1, d1
    // 0xa70650: b.vs            #0xa70ad4
    // 0xa70654: fcvtps          x0, d1
    // 0xa70658: asr             x16, x0, #0x1e
    // 0xa7065c: cmp             x16, x0, asr #63
    // 0xa70660: b.ne            #0xa70ad4
    // 0xa70664: lsl             x0, x0, #1
    // 0xa70668: r2 = LoadInt32Instr(r0)
    //     0xa70668: sbfx            x2, x0, #1, #0x1f
    //     0xa7066c: tbz             w0, #0, #0xa70674
    //     0xa70670: ldur            x2, [x0, #7]
    // 0xa70674: mov             x3, x2
    // 0xa70678: ldr             x2, [fp, #0x20]
    // 0xa7067c: stur            x3, [fp, #-0x10]
    // 0xa70680: LoadField: r0 = r2->field_23
    //     0xa70680: ldur            w0, [x2, #0x23]
    // 0xa70684: DecompressPointer r0
    //     0xa70684: add             x0, x0, HEAP, lsl #32
    // 0xa70688: cmp             w0, NULL
    // 0xa7068c: b.eq            #0xa70afc
    // 0xa70690: r4 = LoadClassIdInstr(r0)
    //     0xa70690: ldur            x4, [x0, #-1]
    //     0xa70694: ubfx            x4, x4, #0xc, #0x14
    // 0xa70698: SaveReg r0
    //     0xa70698: str             x0, [SP, #-8]!
    // 0xa7069c: mov             x0, x4
    // 0xa706a0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa706a0: mov             x17, #0xb8ea
    //     0xa706a4: add             lr, x0, x17
    //     0xa706a8: ldr             lr, [x21, lr, lsl #3]
    //     0xa706ac: blr             lr
    // 0xa706b0: add             SP, SP, #8
    // 0xa706b4: r1 = LoadInt32Instr(r0)
    //     0xa706b4: sbfx            x1, x0, #1, #0x1f
    //     0xa706b8: tbz             w0, #0, #0xa706c0
    //     0xa706bc: ldur            x1, [x0, #7]
    // 0xa706c0: sub             x2, x1, #2
    // 0xa706c4: ldur            x3, [fp, #-0x10]
    // 0xa706c8: r0 = BoxInt64Instr(r3)
    //     0xa706c8: sbfiz           x0, x3, #1, #0x1f
    //     0xa706cc: cmp             x3, x0, asr #1
    //     0xa706d0: b.eq            #0xa706dc
    //     0xa706d4: bl              #0xd69bb8
    //     0xa706d8: stur            x3, [x0, #7]
    // 0xa706dc: mov             x3, x0
    // 0xa706e0: r0 = BoxInt64Instr(r2)
    //     0xa706e0: sbfiz           x0, x2, #1, #0x1f
    //     0xa706e4: cmp             x2, x0, asr #1
    //     0xa706e8: b.eq            #0xa706f4
    //     0xa706ec: bl              #0xd69bb8
    //     0xa706f0: stur            x2, [x0, #7]
    // 0xa706f4: stp             xzr, x3, [SP, #-0x10]!
    // 0xa706f8: SaveReg r0
    //     0xa706f8: str             x0, [SP, #-8]!
    // 0xa706fc: r0 = clamp()
    //     0xa706fc: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0xa70700: add             SP, SP, #0x18
    // 0xa70704: mov             x1, x0
    // 0xa70708: ldur            x0, [fp, #-8]
    // 0xa7070c: stur            x1, [fp, #-0x18]
    // 0xa70710: tbnz            w0, #4, #0xa7072c
    // 0xa70714: r0 = LoadInt32Instr(r1)
    //     0xa70714: sbfx            x0, x1, #1, #0x1f
    //     0xa70718: tbz             w1, #0, #0xa70720
    //     0xa7071c: ldur            x0, [x1, #7]
    // 0xa70720: add             x2, x0, #1
    // 0xa70724: mov             x3, x2
    // 0xa70728: b               #0xa70740
    // 0xa7072c: r0 = LoadInt32Instr(r1)
    //     0xa7072c: sbfx            x0, x1, #1, #0x1f
    //     0xa70730: tbz             w1, #0, #0xa70738
    //     0xa70734: ldur            x0, [x1, #7]
    // 0xa70738: sub             x2, x0, #1
    // 0xa7073c: mov             x3, x2
    // 0xa70740: ldr             x2, [fp, #0x20]
    // 0xa70744: ldur            d0, [fp, #-0x30]
    // 0xa70748: stur            x3, [fp, #-0x10]
    // 0xa7074c: LoadField: r0 = r2->field_23
    //     0xa7074c: ldur            w0, [x2, #0x23]
    // 0xa70750: DecompressPointer r0
    //     0xa70750: add             x0, x0, HEAP, lsl #32
    // 0xa70754: cmp             w0, NULL
    // 0xa70758: b.eq            #0xa70b00
    // 0xa7075c: r4 = LoadClassIdInstr(r0)
    //     0xa7075c: ldur            x4, [x0, #-1]
    //     0xa70760: ubfx            x4, x4, #0xc, #0x14
    // 0xa70764: SaveReg r0
    //     0xa70764: str             x0, [SP, #-8]!
    // 0xa70768: mov             x0, x4
    // 0xa7076c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa7076c: mov             x17, #0xb8ea
    //     0xa70770: add             lr, x0, x17
    //     0xa70774: ldr             lr, [x21, lr, lsl #3]
    //     0xa70778: blr             lr
    // 0xa7077c: add             SP, SP, #8
    // 0xa70780: r1 = LoadInt32Instr(r0)
    //     0xa70780: sbfx            x1, x0, #1, #0x1f
    //     0xa70784: tbz             w0, #0, #0xa7078c
    //     0xa70788: ldur            x1, [x0, #7]
    // 0xa7078c: sub             x2, x1, #2
    // 0xa70790: ldur            x3, [fp, #-0x10]
    // 0xa70794: r0 = BoxInt64Instr(r3)
    //     0xa70794: sbfiz           x0, x3, #1, #0x1f
    //     0xa70798: cmp             x3, x0, asr #1
    //     0xa7079c: b.eq            #0xa707a8
    //     0xa707a0: bl              #0xd69bb8
    //     0xa707a4: stur            x3, [x0, #7]
    // 0xa707a8: mov             x3, x0
    // 0xa707ac: r0 = BoxInt64Instr(r2)
    //     0xa707ac: sbfiz           x0, x2, #1, #0x1f
    //     0xa707b0: cmp             x2, x0, asr #1
    //     0xa707b4: b.eq            #0xa707c0
    //     0xa707b8: bl              #0xd69bb8
    //     0xa707bc: stur            x2, [x0, #7]
    // 0xa707c0: stp             xzr, x3, [SP, #-0x10]!
    // 0xa707c4: SaveReg r0
    //     0xa707c4: str             x0, [SP, #-8]!
    // 0xa707c8: r0 = clamp()
    //     0xa707c8: bl              #0xd66d18  ; [dart:core] _IntegerImplementation::clamp
    // 0xa707cc: add             SP, SP, #0x18
    // 0xa707d0: mov             x1, x0
    // 0xa707d4: ldur            x0, [fp, #-0x18]
    // 0xa707d8: stur            x1, [fp, #-8]
    // 0xa707dc: r2 = LoadInt32Instr(r0)
    //     0xa707dc: sbfx            x2, x0, #1, #0x1f
    //     0xa707e0: tbz             w0, #0, #0xa707e8
    //     0xa707e4: ldur            x2, [x0, #7]
    // 0xa707e8: stur            x2, [fp, #-0x10]
    // 0xa707ec: ldr             x16, [fp, #0x20]
    // 0xa707f0: ldr             lr, [fp, #0x10]
    // 0xa707f4: stp             lr, x16, [SP, #-0x10]!
    // 0xa707f8: SaveReg r2
    //     0xa707f8: str             x2, [SP, #-8]!
    // 0xa707fc: r0 = indicatorRect()
    //     0xa707fc: bl              #0xa70b10  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::indicatorRect
    // 0xa70800: add             SP, SP, #0x18
    // 0xa70804: mov             x1, x0
    // 0xa70808: ldur            x0, [fp, #-8]
    // 0xa7080c: stur            x1, [fp, #-0x18]
    // 0xa70810: r2 = LoadInt32Instr(r0)
    //     0xa70810: sbfx            x2, x0, #1, #0x1f
    //     0xa70814: tbz             w0, #0, #0xa7081c
    //     0xa70818: ldur            x2, [x0, #7]
    // 0xa7081c: ldr             x16, [fp, #0x20]
    // 0xa70820: ldr             lr, [fp, #0x10]
    // 0xa70824: stp             lr, x16, [SP, #-0x10]!
    // 0xa70828: SaveReg r2
    //     0xa70828: str             x2, [SP, #-8]!
    // 0xa7082c: r0 = indicatorRect()
    //     0xa7082c: bl              #0xa70b10  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::indicatorRect
    // 0xa70830: add             SP, SP, #0x18
    // 0xa70834: mov             x1, x0
    // 0xa70838: ldur            x0, [fp, #-0x10]
    // 0xa7083c: scvtf           d0, x0
    // 0xa70840: ldur            d1, [fp, #-0x30]
    // 0xa70844: fsub            d2, d1, d0
    // 0xa70848: d0 = 0.000000
    //     0xa70848: eor             v0.16b, v0.16b, v0.16b
    // 0xa7084c: fcmp            d2, d0
    // 0xa70850: b.vs            #0xa70860
    // 0xa70854: b.ne            #0xa70860
    // 0xa70858: d1 = 0.000000
    //     0xa70858: eor             v1.16b, v1.16b, v1.16b
    // 0xa7085c: b               #0xa70878
    // 0xa70860: fcmp            d2, d0
    // 0xa70864: b.vs            #0xa70874
    // 0xa70868: b.ge            #0xa70874
    // 0xa7086c: fneg            d1, d2
    // 0xa70870: b               #0xa70878
    // 0xa70874: mov             v1.16b, v2.16b
    // 0xa70878: ldr             x0, [fp, #0x20]
    // 0xa7087c: ldur            x16, [fp, #-0x18]
    // 0xa70880: stp             x1, x16, [SP, #-0x10]!
    // 0xa70884: SaveReg d1
    //     0xa70884: str             d1, [SP, #-8]!
    // 0xa70888: r0 = lerp()
    //     0xa70888: bl              #0xa6dd78  ; [dart:ui] Rect::lerp
    // 0xa7088c: add             SP, SP, #0x18
    // 0xa70890: mov             x2, x0
    // 0xa70894: ldr             x1, [fp, #0x20]
    // 0xa70898: StoreField: r1->field_2b = r0
    //     0xa70898: stur            w0, [x1, #0x2b]
    //     0xa7089c: ldurb           w16, [x1, #-1]
    //     0xa708a0: ldurb           w17, [x0, #-1]
    //     0xa708a4: and             x16, x17, x16, lsr #2
    //     0xa708a8: tst             x16, HEAP, lsr #32
    //     0xa708ac: b.eq            #0xa708b4
    //     0xa708b0: bl              #0xd6826c
    // 0xa708b4: cmp             w2, NULL
    // 0xa708b8: b.eq            #0xa70b04
    // 0xa708bc: SaveReg r2
    //     0xa708bc: str             x2, [SP, #-8]!
    // 0xa708c0: r0 = size()
    //     0xa708c0: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xa708c4: add             SP, SP, #8
    // 0xa708c8: mov             x1, x0
    // 0xa708cc: ldr             x0, [fp, #0x20]
    // 0xa708d0: stur            x1, [fp, #-0x18]
    // 0xa708d4: LoadField: r2 = r0->field_27
    //     0xa708d4: ldur            w2, [x0, #0x27]
    // 0xa708d8: DecompressPointer r2
    //     0xa708d8: add             x2, x2, HEAP, lsl #32
    // 0xa708dc: stur            x2, [fp, #-8]
    // 0xa708e0: r0 = ImageConfiguration()
    //     0xa708e0: bl              #0x665610  ; AllocateImageConfigurationStub -> ImageConfiguration (size=0x20)
    // 0xa708e4: mov             x1, x0
    // 0xa708e8: ldur            x0, [fp, #-8]
    // 0xa708ec: stur            x1, [fp, #-0x20]
    // 0xa708f0: StoreField: r1->field_13 = r0
    //     0xa708f0: stur            w0, [x1, #0x13]
    // 0xa708f4: ldur            x0, [fp, #-0x18]
    // 0xa708f8: StoreField: r1->field_17 = r0
    //     0xa708f8: stur            w0, [x1, #0x17]
    // 0xa708fc: ldr             x0, [fp, #0x20]
    // 0xa70900: LoadField: r2 = r0->field_1f
    //     0xa70900: ldur            w2, [x0, #0x1f]
    // 0xa70904: DecompressPointer r2
    //     0xa70904: add             x2, x2, HEAP, lsl #32
    // 0xa70908: stur            x2, [fp, #-8]
    // 0xa7090c: cmp             w2, NULL
    // 0xa70910: b.eq            #0xa70a1c
    // 0xa70914: r16 = 112
    //     0xa70914: mov             x16, #0x70
    // 0xa70918: stp             x16, NULL, [SP, #-0x10]!
    // 0xa7091c: r0 = ByteData()
    //     0xa7091c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa70920: add             SP, SP, #0x10
    // 0xa70924: stur            x0, [fp, #-0x18]
    // 0xa70928: r0 = Paint()
    //     0xa70928: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa7092c: mov             x1, x0
    // 0xa70930: ldur            x0, [fp, #-0x18]
    // 0xa70934: stur            x1, [fp, #-0x28]
    // 0xa70938: StoreField: r1->field_7 = r0
    //     0xa70938: stur            w0, [x1, #7]
    // 0xa7093c: ldur            x2, [fp, #-8]
    // 0xa70940: r3 = LoadClassIdInstr(r2)
    //     0xa70940: ldur            x3, [x2, #-1]
    //     0xa70944: ubfx            x3, x3, #0xc, #0x14
    // 0xa70948: lsl             x3, x3, #1
    // 0xa7094c: r17 = 10124
    //     0xa7094c: mov             x17, #0x278c
    // 0xa70950: cmp             w3, w17
    // 0xa70954: b.gt            #0xa70964
    // 0xa70958: r17 = 10122
    //     0xa70958: mov             x17, #0x278a
    // 0xa7095c: cmp             w3, w17
    // 0xa70960: b.ge            #0xa7097c
    // 0xa70964: r17 = 10114
    //     0xa70964: mov             x17, #0x2782
    // 0xa70968: cmp             w3, w17
    // 0xa7096c: b.eq            #0xa7097c
    // 0xa70970: r17 = 10118
    //     0xa70970: mov             x17, #0x2786
    // 0xa70974: cmp             w3, w17
    // 0xa70978: b.ne            #0xa70984
    // 0xa7097c: LoadField: r3 = r2->field_7
    //     0xa7097c: ldur            x3, [x2, #7]
    // 0xa70980: b               #0xa70994
    // 0xa70984: LoadField: r3 = r2->field_f
    //     0xa70984: ldur            w3, [x2, #0xf]
    // 0xa70988: DecompressPointer r3
    //     0xa70988: add             x3, x3, HEAP, lsl #32
    // 0xa7098c: LoadField: r2 = r3->field_7
    //     0xa7098c: ldur            x2, [x3, #7]
    // 0xa70990: mov             x3, x2
    // 0xa70994: ldr             x2, [fp, #0x10]
    // 0xa70998: d0 = 1.000000
    //     0xa70998: fmov            d0, #1.00000000
    // 0xa7099c: eor             x4, x3, #0xff000000
    // 0xa709a0: LoadField: r3 = r0->field_17
    //     0xa709a0: ldur            w3, [x0, #0x17]
    // 0xa709a4: DecompressPointer r3
    //     0xa709a4: add             x3, x3, HEAP, lsl #32
    // 0xa709a8: sxtw            x4, w4
    // 0xa709ac: LoadField: r0 = r3->field_7
    //     0xa709ac: ldur            x0, [x3, #7]
    // 0xa709b0: str             w4, [x0, #4]
    // 0xa709b4: fcvt            s1, d0
    // 0xa709b8: LoadField: r0 = r3->field_7
    //     0xa709b8: ldur            x0, [x3, #7]
    // 0xa709bc: str             s1, [x0, #0x10]
    // 0xa709c0: LoadField: d0 = r2->field_f
    //     0xa709c0: ldur            d0, [x2, #0xf]
    // 0xa709c4: stur            d0, [fp, #-0x30]
    // 0xa709c8: r0 = Offset()
    //     0xa709c8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa709cc: d0 = 0.000000
    //     0xa709cc: eor             v0.16b, v0.16b, v0.16b
    // 0xa709d0: stur            x0, [fp, #-8]
    // 0xa709d4: StoreField: r0->field_7 = d0
    //     0xa709d4: stur            d0, [x0, #7]
    // 0xa709d8: ldur            d0, [fp, #-0x30]
    // 0xa709dc: StoreField: r0->field_f = d0
    //     0xa709dc: stur            d0, [x0, #0xf]
    // 0xa709e0: ldr             x1, [fp, #0x10]
    // 0xa709e4: LoadField: d1 = r1->field_7
    //     0xa709e4: ldur            d1, [x1, #7]
    // 0xa709e8: stur            d1, [fp, #-0x38]
    // 0xa709ec: r0 = Offset()
    //     0xa709ec: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa709f0: ldur            d0, [fp, #-0x38]
    // 0xa709f4: StoreField: r0->field_7 = d0
    //     0xa709f4: stur            d0, [x0, #7]
    // 0xa709f8: ldur            d0, [fp, #-0x30]
    // 0xa709fc: StoreField: r0->field_f = d0
    //     0xa709fc: stur            d0, [x0, #0xf]
    // 0xa70a00: ldr             x16, [fp, #0x18]
    // 0xa70a04: ldur            lr, [fp, #-8]
    // 0xa70a08: stp             lr, x16, [SP, #-0x10]!
    // 0xa70a0c: ldur            x16, [fp, #-0x28]
    // 0xa70a10: stp             x16, x0, [SP, #-0x10]!
    // 0xa70a14: r0 = drawLine()
    //     0xa70a14: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xa70a18: add             SP, SP, #0x20
    // 0xa70a1c: ldr             x0, [fp, #0x20]
    // 0xa70a20: LoadField: r1 = r0->field_2f
    //     0xa70a20: ldur            w1, [x0, #0x2f]
    // 0xa70a24: DecompressPointer r1
    //     0xa70a24: add             x1, x1, HEAP, lsl #32
    // 0xa70a28: stur            x1, [fp, #-8]
    // 0xa70a2c: cmp             w1, NULL
    // 0xa70a30: b.eq            #0xa70b08
    // 0xa70a34: LoadField: r2 = r0->field_2b
    //     0xa70a34: ldur            w2, [x0, #0x2b]
    // 0xa70a38: DecompressPointer r2
    //     0xa70a38: add             x2, x2, HEAP, lsl #32
    // 0xa70a3c: cmp             w2, NULL
    // 0xa70a40: b.eq            #0xa70b0c
    // 0xa70a44: LoadField: d0 = r2->field_7
    //     0xa70a44: ldur            d0, [x2, #7]
    // 0xa70a48: stur            d0, [fp, #-0x38]
    // 0xa70a4c: LoadField: d1 = r2->field_f
    //     0xa70a4c: ldur            d1, [x2, #0xf]
    // 0xa70a50: stur            d1, [fp, #-0x30]
    // 0xa70a54: r0 = Offset()
    //     0xa70a54: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa70a58: ldur            d0, [fp, #-0x38]
    // 0xa70a5c: StoreField: r0->field_7 = d0
    //     0xa70a5c: stur            d0, [x0, #7]
    // 0xa70a60: ldur            d0, [fp, #-0x30]
    // 0xa70a64: StoreField: r0->field_f = d0
    //     0xa70a64: stur            d0, [x0, #0xf]
    // 0xa70a68: ldur            x16, [fp, #-8]
    // 0xa70a6c: ldr             lr, [fp, #0x18]
    // 0xa70a70: stp             lr, x16, [SP, #-0x10]!
    // 0xa70a74: ldur            x16, [fp, #-0x20]
    // 0xa70a78: stp             x16, x0, [SP, #-0x10]!
    // 0xa70a7c: r0 = paint()
    //     0xa70a7c: bl              #0xc70824  ; [package:flutter/src/material/tab_indicator.dart] _UnderlinePainter::paint
    // 0xa70a80: add             SP, SP, #0x20
    // 0xa70a84: r0 = Null
    //     0xa70a84: mov             x0, NULL
    // 0xa70a88: LeaveFrame
    //     0xa70a88: mov             SP, fp
    //     0xa70a8c: ldp             fp, lr, [SP], #0x10
    // 0xa70a90: ret
    //     0xa70a90: ret             
    // 0xa70a94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa70a94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa70a98: b               #0xa70500
    // 0xa70a9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70a9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70aa0: r9 = _value
    //     0xa70aa0: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xa70aa4: ldr             x9, [x9, #0xbb0]
    // 0xa70aa8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa70aa8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa70aac: SaveReg d1
    //     0xa70aac: str             q1, [SP, #-0x10]!
    // 0xa70ab0: SaveReg r1
    //     0xa70ab0: str             x1, [SP, #-8]!
    // 0xa70ab4: d0 = 0.000000
    //     0xa70ab4: fmov            d0, d1
    // 0xa70ab8: r0 = 212
    //     0xa70ab8: mov             x0, #0xd4
    // 0xa70abc: r24 = DoubleToIntegerStub
    //     0xa70abc: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xa70ac0: LoadField: r30 = r24->field_7
    //     0xa70ac0: ldur            lr, [x24, #7]
    // 0xa70ac4: blr             lr
    // 0xa70ac8: RestoreReg r1
    //     0xa70ac8: ldr             x1, [SP], #8
    // 0xa70acc: RestoreReg d1
    //     0xa70acc: ldr             q1, [SP], #0x10
    // 0xa70ad0: b               #0xa70638
    // 0xa70ad4: SaveReg d1
    //     0xa70ad4: str             q1, [SP, #-0x10]!
    // 0xa70ad8: SaveReg r1
    //     0xa70ad8: str             x1, [SP, #-8]!
    // 0xa70adc: d0 = 0.000000
    //     0xa70adc: fmov            d0, d1
    // 0xa70ae0: r0 = 208
    //     0xa70ae0: mov             x0, #0xd0
    // 0xa70ae4: r24 = DoubleToIntegerStub
    //     0xa70ae4: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xa70ae8: LoadField: r30 = r24->field_7
    //     0xa70ae8: ldur            lr, [x24, #7]
    // 0xa70aec: blr             lr
    // 0xa70af0: RestoreReg r1
    //     0xa70af0: ldr             x1, [SP], #8
    // 0xa70af4: RestoreReg d1
    //     0xa70af4: ldr             q1, [SP], #0x10
    // 0xa70af8: b               #0xa70668
    // 0xa70afc: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa70afc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa70b00: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa70b00: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa70b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70b04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70b08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70b08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70b0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70b0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ indicatorRect(/* No info */) {
    // ** addr: 0xa70b10, size: 0x428
    // 0xa70b10: EnterFrame
    //     0xa70b10: stp             fp, lr, [SP, #-0x10]!
    //     0xa70b14: mov             fp, SP
    // 0xa70b18: AllocStack(0x30)
    //     0xa70b18: sub             SP, SP, #0x30
    // 0xa70b1c: CheckStackOverflow
    //     0xa70b1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa70b20: cmp             SP, x16
    //     0xa70b24: b.ls            #0xa70f14
    // 0xa70b28: ldr             x2, [fp, #0x20]
    // 0xa70b2c: LoadField: r0 = r2->field_27
    //     0xa70b2c: ldur            w0, [x2, #0x27]
    // 0xa70b30: DecompressPointer r0
    //     0xa70b30: add             x0, x0, HEAP, lsl #32
    // 0xa70b34: cmp             w0, NULL
    // 0xa70b38: b.eq            #0xa70f1c
    // 0xa70b3c: LoadField: r1 = r0->field_7
    //     0xa70b3c: ldur            x1, [x0, #7]
    // 0xa70b40: cmp             x1, #0
    // 0xa70b44: b.gt            #0xa70c08
    // 0xa70b48: ldr             x3, [fp, #0x10]
    // 0xa70b4c: LoadField: r4 = r2->field_23
    //     0xa70b4c: ldur            w4, [x2, #0x23]
    // 0xa70b50: DecompressPointer r4
    //     0xa70b50: add             x4, x4, HEAP, lsl #32
    // 0xa70b54: cmp             w4, NULL
    // 0xa70b58: b.eq            #0xa70f20
    // 0xa70b5c: add             x5, x3, #1
    // 0xa70b60: r0 = BoxInt64Instr(r5)
    //     0xa70b60: sbfiz           x0, x5, #1, #0x1f
    //     0xa70b64: cmp             x5, x0, asr #1
    //     0xa70b68: b.eq            #0xa70b74
    //     0xa70b6c: bl              #0xd69bb8
    //     0xa70b70: stur            x5, [x0, #7]
    // 0xa70b74: r1 = LoadClassIdInstr(r4)
    //     0xa70b74: ldur            x1, [x4, #-1]
    //     0xa70b78: ubfx            x1, x1, #0xc, #0x14
    // 0xa70b7c: stp             x0, x4, [SP, #-0x10]!
    // 0xa70b80: mov             x0, x1
    // 0xa70b84: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa70b84: sub             lr, x0, #0xd83
    //     0xa70b88: ldr             lr, [x21, lr, lsl #3]
    //     0xa70b8c: blr             lr
    // 0xa70b90: add             SP, SP, #0x10
    // 0xa70b94: mov             x3, x0
    // 0xa70b98: ldr             x2, [fp, #0x20]
    // 0xa70b9c: stur            x3, [fp, #-8]
    // 0xa70ba0: LoadField: r4 = r2->field_23
    //     0xa70ba0: ldur            w4, [x2, #0x23]
    // 0xa70ba4: DecompressPointer r4
    //     0xa70ba4: add             x4, x4, HEAP, lsl #32
    // 0xa70ba8: cmp             w4, NULL
    // 0xa70bac: b.eq            #0xa70f24
    // 0xa70bb0: ldr             x5, [fp, #0x10]
    // 0xa70bb4: r0 = BoxInt64Instr(r5)
    //     0xa70bb4: sbfiz           x0, x5, #1, #0x1f
    //     0xa70bb8: cmp             x5, x0, asr #1
    //     0xa70bbc: b.eq            #0xa70bc8
    //     0xa70bc0: bl              #0xd69bb8
    //     0xa70bc4: stur            x5, [x0, #7]
    // 0xa70bc8: r1 = LoadClassIdInstr(r4)
    //     0xa70bc8: ldur            x1, [x4, #-1]
    //     0xa70bcc: ubfx            x1, x1, #0xc, #0x14
    // 0xa70bd0: stp             x0, x4, [SP, #-0x10]!
    // 0xa70bd4: mov             x0, x1
    // 0xa70bd8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa70bd8: sub             lr, x0, #0xd83
    //     0xa70bdc: ldr             lr, [x21, lr, lsl #3]
    //     0xa70be0: blr             lr
    // 0xa70be4: add             SP, SP, #0x10
    // 0xa70be8: mov             x1, x0
    // 0xa70bec: ldur            x0, [fp, #-8]
    // 0xa70bf0: LoadField: d0 = r0->field_7
    //     0xa70bf0: ldur            d0, [x0, #7]
    // 0xa70bf4: LoadField: d1 = r1->field_7
    //     0xa70bf4: ldur            d1, [x1, #7]
    // 0xa70bf8: mov             v31.16b, v1.16b
    // 0xa70bfc: mov             v1.16b, v0.16b
    // 0xa70c00: mov             v0.16b, v31.16b
    // 0xa70c04: b               #0xa70cc4
    // 0xa70c08: ldr             x3, [fp, #0x10]
    // 0xa70c0c: LoadField: r4 = r2->field_23
    //     0xa70c0c: ldur            w4, [x2, #0x23]
    // 0xa70c10: DecompressPointer r4
    //     0xa70c10: add             x4, x4, HEAP, lsl #32
    // 0xa70c14: cmp             w4, NULL
    // 0xa70c18: b.eq            #0xa70f28
    // 0xa70c1c: r0 = BoxInt64Instr(r3)
    //     0xa70c1c: sbfiz           x0, x3, #1, #0x1f
    //     0xa70c20: cmp             x3, x0, asr #1
    //     0xa70c24: b.eq            #0xa70c30
    //     0xa70c28: bl              #0xd69bb8
    //     0xa70c2c: stur            x3, [x0, #7]
    // 0xa70c30: r1 = LoadClassIdInstr(r4)
    //     0xa70c30: ldur            x1, [x4, #-1]
    //     0xa70c34: ubfx            x1, x1, #0xc, #0x14
    // 0xa70c38: stp             x0, x4, [SP, #-0x10]!
    // 0xa70c3c: mov             x0, x1
    // 0xa70c40: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa70c40: sub             lr, x0, #0xd83
    //     0xa70c44: ldr             lr, [x21, lr, lsl #3]
    //     0xa70c48: blr             lr
    // 0xa70c4c: add             SP, SP, #0x10
    // 0xa70c50: mov             x3, x0
    // 0xa70c54: ldr             x2, [fp, #0x20]
    // 0xa70c58: stur            x3, [fp, #-8]
    // 0xa70c5c: LoadField: r4 = r2->field_23
    //     0xa70c5c: ldur            w4, [x2, #0x23]
    // 0xa70c60: DecompressPointer r4
    //     0xa70c60: add             x4, x4, HEAP, lsl #32
    // 0xa70c64: cmp             w4, NULL
    // 0xa70c68: b.eq            #0xa70f2c
    // 0xa70c6c: ldr             x5, [fp, #0x10]
    // 0xa70c70: add             x6, x5, #1
    // 0xa70c74: r0 = BoxInt64Instr(r6)
    //     0xa70c74: sbfiz           x0, x6, #1, #0x1f
    //     0xa70c78: cmp             x6, x0, asr #1
    //     0xa70c7c: b.eq            #0xa70c88
    //     0xa70c80: bl              #0xd69bb8
    //     0xa70c84: stur            x6, [x0, #7]
    // 0xa70c88: r1 = LoadClassIdInstr(r4)
    //     0xa70c88: ldur            x1, [x4, #-1]
    //     0xa70c8c: ubfx            x1, x1, #0xc, #0x14
    // 0xa70c90: stp             x0, x4, [SP, #-0x10]!
    // 0xa70c94: mov             x0, x1
    // 0xa70c98: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa70c98: sub             lr, x0, #0xd83
    //     0xa70c9c: ldr             lr, [x21, lr, lsl #3]
    //     0xa70ca0: blr             lr
    // 0xa70ca4: add             SP, SP, #0x10
    // 0xa70ca8: mov             x1, x0
    // 0xa70cac: ldur            x0, [fp, #-8]
    // 0xa70cb0: LoadField: d0 = r0->field_7
    //     0xa70cb0: ldur            d0, [x0, #7]
    // 0xa70cb4: LoadField: d1 = r1->field_7
    //     0xa70cb4: ldur            d1, [x1, #7]
    // 0xa70cb8: mov             v31.16b, v1.16b
    // 0xa70cbc: mov             v1.16b, v0.16b
    // 0xa70cc0: mov             v0.16b, v31.16b
    // 0xa70cc4: ldr             x2, [fp, #0x20]
    // 0xa70cc8: stur            d1, [fp, #-0x20]
    // 0xa70ccc: stur            d0, [fp, #-0x28]
    // 0xa70cd0: LoadField: r0 = r2->field_13
    //     0xa70cd0: ldur            w0, [x2, #0x13]
    // 0xa70cd4: DecompressPointer r0
    //     0xa70cd4: add             x0, x0, HEAP, lsl #32
    // 0xa70cd8: r16 = Instance_TabBarIndicatorSize
    //     0xa70cd8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe0] Obj!TabBarIndicatorSize@b65191
    //     0xa70cdc: ldr             x16, [x16, #0xbe0]
    // 0xa70ce0: cmp             w0, w16
    // 0xa70ce4: b.ne            #0xa70d80
    // 0xa70ce8: ldr             x3, [fp, #0x10]
    // 0xa70cec: LoadField: r4 = r2->field_1b
    //     0xa70cec: ldur            w4, [x2, #0x1b]
    // 0xa70cf0: DecompressPointer r4
    //     0xa70cf0: add             x4, x4, HEAP, lsl #32
    // 0xa70cf4: r0 = BoxInt64Instr(r3)
    //     0xa70cf4: sbfiz           x0, x3, #1, #0x1f
    //     0xa70cf8: cmp             x3, x0, asr #1
    //     0xa70cfc: b.eq            #0xa70d08
    //     0xa70d00: bl              #0xd69c6c
    //     0xa70d04: stur            x3, [x0, #7]
    // 0xa70d08: r1 = LoadClassIdInstr(r4)
    //     0xa70d08: ldur            x1, [x4, #-1]
    //     0xa70d0c: ubfx            x1, x1, #0xc, #0x14
    // 0xa70d10: stp             x0, x4, [SP, #-0x10]!
    // 0xa70d14: mov             x0, x1
    // 0xa70d18: r0 = GDT[cid_x0 + -0xd83]()
    //     0xa70d18: sub             lr, x0, #0xd83
    //     0xa70d1c: ldr             lr, [x21, lr, lsl #3]
    //     0xa70d20: blr             lr
    // 0xa70d24: add             SP, SP, #0x10
    // 0xa70d28: SaveReg r0
    //     0xa70d28: str             x0, [SP, #-8]!
    // 0xa70d2c: r0 = _currentElement()
    //     0xa70d2c: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xa70d30: add             SP, SP, #8
    // 0xa70d34: cmp             w0, NULL
    // 0xa70d38: b.eq            #0xa70f30
    // 0xa70d3c: SaveReg r0
    //     0xa70d3c: str             x0, [SP, #-8]!
    // 0xa70d40: r0 = size()
    //     0xa70d40: bl              #0x9d8778  ; [package:flutter/src/widgets/framework.dart] Element::size
    // 0xa70d44: add             SP, SP, #8
    // 0xa70d48: cmp             w0, NULL
    // 0xa70d4c: b.eq            #0xa70f34
    // 0xa70d50: LoadField: d0 = r0->field_7
    //     0xa70d50: ldur            d0, [x0, #7]
    // 0xa70d54: ldur            d2, [fp, #-0x20]
    // 0xa70d58: ldur            d1, [fp, #-0x28]
    // 0xa70d5c: fsub            d3, d1, d2
    // 0xa70d60: fsub            d4, d3, d0
    // 0xa70d64: d0 = 2.000000
    //     0xa70d64: fmov            d0, #2.00000000
    // 0xa70d68: fdiv            d3, d4, d0
    // 0xa70d6c: fadd            d0, d2, d3
    // 0xa70d70: fsub            d2, d1, d3
    // 0xa70d74: mov             v1.16b, v2.16b
    // 0xa70d78: mov             v2.16b, v0.16b
    // 0xa70d7c: b               #0xa70d88
    // 0xa70d80: mov             v2.16b, v1.16b
    // 0xa70d84: mov             v1.16b, v0.16b
    // 0xa70d88: ldr             x0, [fp, #0x20]
    // 0xa70d8c: ldr             x1, [fp, #0x18]
    // 0xa70d90: d0 = 0.000000
    //     0xa70d90: eor             v0.16b, v0.16b, v0.16b
    // 0xa70d94: stur            d2, [fp, #-0x30]
    // 0xa70d98: LoadField: r2 = r0->field_17
    //     0xa70d98: ldur            w2, [x0, #0x17]
    // 0xa70d9c: DecompressPointer r2
    //     0xa70d9c: add             x2, x2, HEAP, lsl #32
    // 0xa70da0: stur            x2, [fp, #-8]
    // 0xa70da4: fsub            d3, d1, d2
    // 0xa70da8: LoadField: d1 = r1->field_f
    //     0xa70da8: ldur            d1, [x1, #0xf]
    // 0xa70dac: fadd            d4, d2, d3
    // 0xa70db0: stur            d4, [fp, #-0x28]
    // 0xa70db4: fadd            d3, d0, d1
    // 0xa70db8: stur            d3, [fp, #-0x20]
    // 0xa70dbc: r0 = Rect()
    //     0xa70dbc: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa70dc0: ldur            d0, [fp, #-0x30]
    // 0xa70dc4: stur            x0, [fp, #-0x10]
    // 0xa70dc8: StoreField: r0->field_7 = d0
    //     0xa70dc8: stur            d0, [x0, #7]
    // 0xa70dcc: d0 = 0.000000
    //     0xa70dcc: eor             v0.16b, v0.16b, v0.16b
    // 0xa70dd0: StoreField: r0->field_f = d0
    //     0xa70dd0: stur            d0, [x0, #0xf]
    // 0xa70dd4: ldur            d0, [fp, #-0x28]
    // 0xa70dd8: StoreField: r0->field_17 = d0
    //     0xa70dd8: stur            d0, [x0, #0x17]
    // 0xa70ddc: ldur            d0, [fp, #-0x20]
    // 0xa70de0: StoreField: r0->field_1f = d0
    //     0xa70de0: stur            d0, [x0, #0x1f]
    // 0xa70de4: SaveReg r0
    //     0xa70de4: str             x0, [SP, #-8]!
    // 0xa70de8: r0 = size()
    //     0xa70de8: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xa70dec: add             SP, SP, #8
    // 0xa70df0: stur            x0, [fp, #-0x18]
    // 0xa70df4: ldur            x16, [fp, #-8]
    // 0xa70df8: SaveReg r16
    //     0xa70df8: str             x16, [SP, #-8]!
    // 0xa70dfc: r0 = collapsedSize()
    //     0xa70dfc: bl              #0xa6e628  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::collapsedSize
    // 0xa70e00: add             SP, SP, #8
    // 0xa70e04: mov             x1, x0
    // 0xa70e08: ldur            x0, [fp, #-0x18]
    // 0xa70e0c: LoadField: d0 = r0->field_7
    //     0xa70e0c: ldur            d0, [x0, #7]
    // 0xa70e10: LoadField: d1 = r1->field_7
    //     0xa70e10: ldur            d1, [x1, #7]
    // 0xa70e14: fcmp            d0, d1
    // 0xa70e18: b.vs            #0xa70e64
    // 0xa70e1c: b.lt            #0xa70e64
    // 0xa70e20: LoadField: d0 = r0->field_f
    //     0xa70e20: ldur            d0, [x0, #0xf]
    // 0xa70e24: LoadField: d1 = r1->field_f
    //     0xa70e24: ldur            d1, [x1, #0xf]
    // 0xa70e28: fcmp            d0, d1
    // 0xa70e2c: b.vs            #0xa70e34
    // 0xa70e30: b.ge            #0xa70e3c
    // 0xa70e34: r0 = false
    //     0xa70e34: add             x0, NULL, #0x30  ; false
    // 0xa70e38: b               #0xa70e40
    // 0xa70e3c: r0 = true
    //     0xa70e3c: add             x0, NULL, #0x20  ; true
    // 0xa70e40: tbnz            w0, #4, #0xa70e64
    // 0xa70e44: ldur            x16, [fp, #-8]
    // 0xa70e48: ldur            lr, [fp, #-0x10]
    // 0xa70e4c: stp             lr, x16, [SP, #-0x10]!
    // 0xa70e50: r0 = deflateRect()
    //     0xa70e50: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0xa70e54: add             SP, SP, #0x10
    // 0xa70e58: LeaveFrame
    //     0xa70e58: mov             SP, fp
    //     0xa70e5c: ldp             fp, lr, [SP], #0x10
    // 0xa70e60: ret
    //     0xa70e60: ret             
    // 0xa70e64: r1 = Null
    //     0xa70e64: mov             x1, NULL
    // 0xa70e68: r2 = 8
    //     0xa70e68: mov             x2, #8
    // 0xa70e6c: r0 = AllocateArray()
    //     0xa70e6c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xa70e70: stur            x0, [fp, #-0x18]
    // 0xa70e74: r17 = "indicatorPadding insets should be less than Tab Size\nRect Size : "
    //     0xa70e74: add             x17, PP, #0x40, lsl #12  ; [pp+0x40d18] "indicatorPadding insets should be less than Tab Size\nRect Size : "
    //     0xa70e78: ldr             x17, [x17, #0xd18]
    // 0xa70e7c: StoreField: r0->field_f = r17
    //     0xa70e7c: stur            w17, [x0, #0xf]
    // 0xa70e80: ldur            x16, [fp, #-0x10]
    // 0xa70e84: SaveReg r16
    //     0xa70e84: str             x16, [SP, #-8]!
    // 0xa70e88: r0 = size()
    //     0xa70e88: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0xa70e8c: add             SP, SP, #8
    // 0xa70e90: ldur            x1, [fp, #-0x18]
    // 0xa70e94: ArrayStore: r1[1] = r0  ; List_4
    //     0xa70e94: add             x25, x1, #0x13
    //     0xa70e98: str             w0, [x25]
    //     0xa70e9c: tbz             w0, #0, #0xa70eb8
    //     0xa70ea0: ldurb           w16, [x1, #-1]
    //     0xa70ea4: ldurb           w17, [x0, #-1]
    //     0xa70ea8: and             x16, x17, x16, lsr #2
    //     0xa70eac: tst             x16, HEAP, lsr #32
    //     0xa70eb0: b.eq            #0xa70eb8
    //     0xa70eb4: bl              #0xd67e5c
    // 0xa70eb8: ldur            x2, [fp, #-0x18]
    // 0xa70ebc: r17 = ", Insets: "
    //     0xa70ebc: add             x17, PP, #0x40, lsl #12  ; [pp+0x40d20] ", Insets: "
    //     0xa70ec0: ldr             x17, [x17, #0xd20]
    // 0xa70ec4: StoreField: r2->field_17 = r17
    //     0xa70ec4: stur            w17, [x2, #0x17]
    // 0xa70ec8: mov             x1, x2
    // 0xa70ecc: ldur            x0, [fp, #-8]
    // 0xa70ed0: ArrayStore: r1[3] = r0  ; List_4
    //     0xa70ed0: add             x25, x1, #0x1b
    //     0xa70ed4: str             w0, [x25]
    //     0xa70ed8: tbz             w0, #0, #0xa70ef4
    //     0xa70edc: ldurb           w16, [x1, #-1]
    //     0xa70ee0: ldurb           w17, [x0, #-1]
    //     0xa70ee4: and             x16, x17, x16, lsr #2
    //     0xa70ee8: tst             x16, HEAP, lsr #32
    //     0xa70eec: b.eq            #0xa70ef4
    //     0xa70ef0: bl              #0xd67e5c
    // 0xa70ef4: SaveReg r2
    //     0xa70ef4: str             x2, [SP, #-8]!
    // 0xa70ef8: r0 = _interpolate()
    //     0xa70ef8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xa70efc: add             SP, SP, #8
    // 0xa70f00: stp             x0, NULL, [SP, #-0x10]!
    // 0xa70f04: r0 = FlutterError()
    //     0xa70f04: bl              #0x59ef18  ; [package:flutter/src/foundation/assertions.dart] FlutterError::FlutterError
    // 0xa70f08: add             SP, SP, #0x10
    // 0xa70f0c: r0 = Throw()
    //     0xa70f0c: bl              #0xd67e38  ; ThrowStub
    // 0xa70f10: brk             #0
    // 0xa70f14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa70f14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa70f18: b               #0xa70b28
    // 0xa70f1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70f20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70f24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70f28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70f2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70f30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa70f34: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa70f34: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void markNeedsPaint(dynamic) {
    // ** addr: 0xa70f38, size: 0x48
    // 0xa70f38: EnterFrame
    //     0xa70f38: stp             fp, lr, [SP, #-0x10]!
    //     0xa70f3c: mov             fp, SP
    // 0xa70f40: ldr             x0, [fp, #0x10]
    // 0xa70f44: LoadField: r1 = r0->field_17
    //     0xa70f44: ldur            w1, [x0, #0x17]
    // 0xa70f48: DecompressPointer r1
    //     0xa70f48: add             x1, x1, HEAP, lsl #32
    // 0xa70f4c: CheckStackOverflow
    //     0xa70f4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa70f50: cmp             SP, x16
    //     0xa70f54: b.ls            #0xa70f78
    // 0xa70f58: LoadField: r0 = r1->field_f
    //     0xa70f58: ldur            w0, [x1, #0xf]
    // 0xa70f5c: DecompressPointer r0
    //     0xa70f5c: add             x0, x0, HEAP, lsl #32
    // 0xa70f60: SaveReg r0
    //     0xa70f60: str             x0, [SP, #-8]!
    // 0xa70f64: r0 = markNeedsPaint()
    //     0xa70f64: bl              #0xa70f80  ; [package:flutter/src/material/tabs.dart] _IndicatorPainter::markNeedsPaint
    // 0xa70f68: add             SP, SP, #8
    // 0xa70f6c: LeaveFrame
    //     0xa70f6c: mov             SP, fp
    //     0xa70f70: ldp             fp, lr, [SP], #0x10
    // 0xa70f74: ret
    //     0xa70f74: ret             
    // 0xa70f78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa70f78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa70f7c: b               #0xa70f58
  }
  _ markNeedsPaint(/* No info */) {
    // ** addr: 0xa70f80, size: 0x14
    // 0xa70f80: r1 = true
    //     0xa70f80: add             x1, NULL, #0x20  ; true
    // 0xa70f84: ldr             x2, [SP]
    // 0xa70f88: StoreField: r2->field_33 = r1
    //     0xa70f88: stur            w1, [x2, #0x33]
    // 0xa70f8c: r0 = Null
    //     0xa70f8c: mov             x0, NULL
    // 0xa70f90: ret
    //     0xa70f90: ret             
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa7a388, size: 0x188
    // 0xa7a388: EnterFrame
    //     0xa7a388: stp             fp, lr, [SP, #-0x10]!
    //     0xa7a38c: mov             fp, SP
    // 0xa7a390: AllocStack(0x8)
    //     0xa7a390: sub             SP, SP, #8
    // 0xa7a394: CheckStackOverflow
    //     0xa7a394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa7a398: cmp             SP, x16
    //     0xa7a39c: b.ls            #0xa7a508
    // 0xa7a3a0: ldr             x0, [fp, #0x10]
    // 0xa7a3a4: r2 = Null
    //     0xa7a3a4: mov             x2, NULL
    // 0xa7a3a8: r1 = Null
    //     0xa7a3a8: mov             x1, NULL
    // 0xa7a3ac: r4 = 59
    //     0xa7a3ac: mov             x4, #0x3b
    // 0xa7a3b0: branchIfSmi(r0, 0xa7a3bc)
    //     0xa7a3b0: tbz             w0, #0, #0xa7a3bc
    // 0xa7a3b4: r4 = LoadClassIdInstr(r0)
    //     0xa7a3b4: ldur            x4, [x0, #-1]
    //     0xa7a3b8: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a3bc: r17 = 4372
    //     0xa7a3bc: mov             x17, #0x1114
    // 0xa7a3c0: cmp             x4, x17
    // 0xa7a3c4: b.eq            #0xa7a3dc
    // 0xa7a3c8: r8 = _IndicatorPainter
    //     0xa7a3c8: add             x8, PP, #0x40, lsl #12  ; [pp+0x40cf8] Type: _IndicatorPainter
    //     0xa7a3cc: ldr             x8, [x8, #0xcf8]
    // 0xa7a3d0: r3 = Null
    //     0xa7a3d0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40d00] Null
    //     0xa7a3d4: ldr             x3, [x3, #0xd00]
    // 0xa7a3d8: r0 = DefaultTypeTest()
    //     0xa7a3d8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa7a3dc: ldr             x1, [fp, #0x18]
    // 0xa7a3e0: LoadField: r0 = r1->field_33
    //     0xa7a3e0: ldur            w0, [x1, #0x33]
    // 0xa7a3e4: DecompressPointer r0
    //     0xa7a3e4: add             x0, x0, HEAP, lsl #32
    // 0xa7a3e8: tbz             w0, #4, #0xa7a4c8
    // 0xa7a3ec: ldr             x2, [fp, #0x10]
    // 0xa7a3f0: LoadField: r0 = r1->field_b
    //     0xa7a3f0: ldur            w0, [x1, #0xb]
    // 0xa7a3f4: DecompressPointer r0
    //     0xa7a3f4: add             x0, x0, HEAP, lsl #32
    // 0xa7a3f8: LoadField: r3 = r2->field_b
    //     0xa7a3f8: ldur            w3, [x2, #0xb]
    // 0xa7a3fc: DecompressPointer r3
    //     0xa7a3fc: add             x3, x3, HEAP, lsl #32
    // 0xa7a400: cmp             w0, w3
    // 0xa7a404: b.ne            #0xa7a4c8
    // 0xa7a408: LoadField: r0 = r1->field_f
    //     0xa7a408: ldur            w0, [x1, #0xf]
    // 0xa7a40c: DecompressPointer r0
    //     0xa7a40c: add             x0, x0, HEAP, lsl #32
    // 0xa7a410: LoadField: r3 = r2->field_f
    //     0xa7a410: ldur            w3, [x2, #0xf]
    // 0xa7a414: DecompressPointer r3
    //     0xa7a414: add             x3, x3, HEAP, lsl #32
    // 0xa7a418: cmp             w0, w3
    // 0xa7a41c: b.ne            #0xa7a4c8
    // 0xa7a420: LoadField: r0 = r1->field_1b
    //     0xa7a420: ldur            w0, [x1, #0x1b]
    // 0xa7a424: DecompressPointer r0
    //     0xa7a424: add             x0, x0, HEAP, lsl #32
    // 0xa7a428: r3 = LoadClassIdInstr(r0)
    //     0xa7a428: ldur            x3, [x0, #-1]
    //     0xa7a42c: ubfx            x3, x3, #0xc, #0x14
    // 0xa7a430: SaveReg r0
    //     0xa7a430: str             x0, [SP, #-8]!
    // 0xa7a434: mov             x0, x3
    // 0xa7a438: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa7a438: mov             x17, #0xb8ea
    //     0xa7a43c: add             lr, x0, x17
    //     0xa7a440: ldr             lr, [x21, lr, lsl #3]
    //     0xa7a444: blr             lr
    // 0xa7a448: add             SP, SP, #8
    // 0xa7a44c: mov             x2, x0
    // 0xa7a450: ldr             x1, [fp, #0x10]
    // 0xa7a454: stur            x2, [fp, #-8]
    // 0xa7a458: LoadField: r0 = r1->field_1b
    //     0xa7a458: ldur            w0, [x1, #0x1b]
    // 0xa7a45c: DecompressPointer r0
    //     0xa7a45c: add             x0, x0, HEAP, lsl #32
    // 0xa7a460: r3 = LoadClassIdInstr(r0)
    //     0xa7a460: ldur            x3, [x0, #-1]
    //     0xa7a464: ubfx            x3, x3, #0xc, #0x14
    // 0xa7a468: SaveReg r0
    //     0xa7a468: str             x0, [SP, #-8]!
    // 0xa7a46c: mov             x0, x3
    // 0xa7a470: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xa7a470: mov             x17, #0xb8ea
    //     0xa7a474: add             lr, x0, x17
    //     0xa7a478: ldr             lr, [x21, lr, lsl #3]
    //     0xa7a47c: blr             lr
    // 0xa7a480: add             SP, SP, #8
    // 0xa7a484: mov             x1, x0
    // 0xa7a488: ldur            x0, [fp, #-8]
    // 0xa7a48c: cmp             w0, w1
    // 0xa7a490: b.ne            #0xa7a4c8
    // 0xa7a494: ldr             x1, [fp, #0x18]
    // 0xa7a498: ldr             x0, [fp, #0x10]
    // 0xa7a49c: LoadField: r2 = r1->field_23
    //     0xa7a49c: ldur            w2, [x1, #0x23]
    // 0xa7a4a0: DecompressPointer r2
    //     0xa7a4a0: add             x2, x2, HEAP, lsl #32
    // 0xa7a4a4: LoadField: r3 = r0->field_23
    //     0xa7a4a4: ldur            w3, [x0, #0x23]
    // 0xa7a4a8: DecompressPointer r3
    //     0xa7a4a8: add             x3, x3, HEAP, lsl #32
    // 0xa7a4ac: r16 = <double>
    //     0xa7a4ac: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa7a4b0: stp             x2, x16, [SP, #-0x10]!
    // 0xa7a4b4: SaveReg r3
    //     0xa7a4b4: str             x3, [SP, #-8]!
    // 0xa7a4b8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xa7a4b8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xa7a4bc: r0 = listEquals()
    //     0xa7a4bc: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xa7a4c0: add             SP, SP, #0x18
    // 0xa7a4c4: tbz             w0, #4, #0xa7a4d0
    // 0xa7a4c8: r0 = true
    //     0xa7a4c8: add             x0, NULL, #0x20  ; true
    // 0xa7a4cc: b               #0xa7a4fc
    // 0xa7a4d0: ldr             x2, [fp, #0x18]
    // 0xa7a4d4: ldr             x1, [fp, #0x10]
    // 0xa7a4d8: LoadField: r3 = r2->field_27
    //     0xa7a4d8: ldur            w3, [x2, #0x27]
    // 0xa7a4dc: DecompressPointer r3
    //     0xa7a4dc: add             x3, x3, HEAP, lsl #32
    // 0xa7a4e0: LoadField: r2 = r1->field_27
    //     0xa7a4e0: ldur            w2, [x1, #0x27]
    // 0xa7a4e4: DecompressPointer r2
    //     0xa7a4e4: add             x2, x2, HEAP, lsl #32
    // 0xa7a4e8: cmp             w3, w2
    // 0xa7a4ec: r16 = true
    //     0xa7a4ec: add             x16, NULL, #0x20  ; true
    // 0xa7a4f0: r17 = false
    //     0xa7a4f0: add             x17, NULL, #0x30  ; false
    // 0xa7a4f4: csel            x1, x16, x17, ne
    // 0xa7a4f8: mov             x0, x1
    // 0xa7a4fc: LeaveFrame
    //     0xa7a4fc: mov             SP, fp
    //     0xa7a500: ldp             fp, lr, [SP], #0x10
    // 0xa7a504: ret
    //     0xa7a504: ret             
    // 0xa7a508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa7a508: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa7a50c: b               #0xa7a3a0
  }
}

// class id: 4848, size: 0x8c, field offset: 0x80
class _TabBarScrollPosition extends ScrollPositionWithSingleContext {

  _ markNeedsPixelsCorrection(/* No info */) {
    // ** addr: 0x7bc634, size: 0x14
    // 0x7bc634: r1 = true
    //     0x7bc634: add             x1, NULL, #0x20  ; true
    // 0x7bc638: ldr             x2, [SP]
    // 0x7bc63c: StoreField: r2->field_87 = r1
    //     0x7bc63c: stur            w1, [x2, #0x87]
    // 0x7bc640: r0 = Null
    //     0x7bc640: mov             x0, NULL
    // 0x7bc644: ret
    //     0x7bc644: ret             
  }
  _ _TabBarScrollPosition(/* No info */) {
    // ** addr: 0xbebfc4, size: 0x84
    // 0xbebfc4: EnterFrame
    //     0xbebfc4: stp             fp, lr, [SP, #-0x10]!
    //     0xbebfc8: mov             fp, SP
    // 0xbebfcc: r1 = false
    //     0xbebfcc: add             x1, NULL, #0x30  ; false
    // 0xbebfd0: r0 = true
    //     0xbebfd0: add             x0, NULL, #0x20  ; true
    // 0xbebfd4: CheckStackOverflow
    //     0xbebfd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebfd8: cmp             SP, x16
    //     0xbebfdc: b.ls            #0xbec040
    // 0xbebfe0: ldr             x2, [fp, #0x30]
    // 0xbebfe4: StoreField: r2->field_83 = r1
    //     0xbebfe4: stur            w1, [x2, #0x83]
    // 0xbebfe8: StoreField: r2->field_87 = r0
    //     0xbebfe8: stur            w0, [x2, #0x87]
    // 0xbebfec: ldr             x0, [fp, #0x10]
    // 0xbebff0: StoreField: r2->field_7f = r0
    //     0xbebff0: stur            w0, [x2, #0x7f]
    //     0xbebff4: ldurb           w16, [x2, #-1]
    //     0xbebff8: ldurb           w17, [x0, #-1]
    //     0xbebffc: and             x16, x17, x16, lsr #2
    //     0xbec000: tst             x16, HEAP, lsr #32
    //     0xbec004: b.eq            #0xbec00c
    //     0xbec008: bl              #0xd6828c
    // 0xbec00c: ldr             x16, [fp, #0x28]
    // 0xbec010: stp             x16, x2, [SP, #-0x10]!
    // 0xbec014: ldr             x16, [fp, #0x20]
    // 0xbec018: stp             x16, NULL, [SP, #-0x10]!
    // 0xbec01c: ldr             x16, [fp, #0x18]
    // 0xbec020: SaveReg r16
    //     0xbec020: str             x16, [SP, #-8]!
    // 0xbec024: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xbec024: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xbec028: r0 = ScrollPositionWithSingleContext()
    //     0xbec028: bl              #0xbeb8c8  ; [package:flutter/src/widgets/scroll_position_with_single_context.dart] ScrollPositionWithSingleContext::ScrollPositionWithSingleContext
    // 0xbec02c: add             SP, SP, #0x28
    // 0xbec030: r0 = Null
    //     0xbec030: mov             x0, NULL
    // 0xbec034: LeaveFrame
    //     0xbec034: mov             SP, fp
    //     0xbec038: ldp             fp, lr, [SP], #0x10
    // 0xbec03c: ret
    //     0xbec03c: ret             
    // 0xbec040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec044: b               #0xbebfe0
  }
  _ applyContentDimensions(/* No info */) {
    // ** addr: 0xc73f38, size: 0x1a4
    // 0xc73f38: EnterFrame
    //     0xc73f38: stp             fp, lr, [SP, #-0x10]!
    //     0xc73f3c: mov             fp, SP
    // 0xc73f40: AllocStack(0x8)
    //     0xc73f40: sub             SP, SP, #8
    // 0xc73f44: CheckStackOverflow
    //     0xc73f44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73f48: cmp             SP, x16
    //     0xc73f4c: b.ls            #0xc74098
    // 0xc73f50: ldr             x0, [fp, #0x20]
    // 0xc73f54: LoadField: r1 = r0->field_83
    //     0xc73f54: ldur            w1, [x0, #0x83]
    // 0xc73f58: DecompressPointer r1
    //     0xc73f58: add             x1, x1, HEAP, lsl #32
    // 0xc73f5c: tbz             w1, #4, #0xc73f8c
    // 0xc73f60: d0 = 0.000000
    //     0xc73f60: eor             v0.16b, v0.16b, v0.16b
    // 0xc73f64: LoadField: r1 = r0->field_47
    //     0xc73f64: ldur            w1, [x0, #0x47]
    // 0xc73f68: DecompressPointer r1
    //     0xc73f68: add             x1, x1, HEAP, lsl #32
    // 0xc73f6c: cmp             w1, NULL
    // 0xc73f70: b.eq            #0xc740a0
    // 0xc73f74: LoadField: d1 = r1->field_7
    //     0xc73f74: ldur            d1, [x1, #7]
    // 0xc73f78: fcmp            d1, d0
    // 0xc73f7c: r16 = true
    //     0xc73f7c: add             x16, NULL, #0x20  ; true
    // 0xc73f80: r17 = false
    //     0xc73f80: add             x17, NULL, #0x30  ; false
    // 0xc73f84: csel            x1, x16, x17, ne
    // 0xc73f88: StoreField: r0->field_83 = r1
    //     0xc73f88: stur            w1, [x0, #0x83]
    // 0xc73f8c: tbnz            w1, #4, #0xc73f9c
    // 0xc73f90: LoadField: r1 = r0->field_87
    //     0xc73f90: ldur            w1, [x0, #0x87]
    // 0xc73f94: DecompressPointer r1
    //     0xc73f94: add             x1, x1, HEAP, lsl #32
    // 0xc73f98: tbnz            w1, #4, #0xc74054
    // 0xc73f9c: ldr             d0, [fp, #0x18]
    // 0xc73fa0: ldr             x2, [fp, #0x10]
    // 0xc73fa4: r1 = false
    //     0xc73fa4: add             x1, NULL, #0x30  ; false
    // 0xc73fa8: StoreField: r0->field_87 = r1
    //     0xc73fa8: stur            w1, [x0, #0x87]
    // 0xc73fac: LoadField: r1 = r0->field_7f
    //     0xc73fac: ldur            w1, [x0, #0x7f]
    // 0xc73fb0: DecompressPointer r1
    //     0xc73fb0: add             x1, x1, HEAP, lsl #32
    // 0xc73fb4: LoadField: r3 = r0->field_47
    //     0xc73fb4: ldur            w3, [x0, #0x47]
    // 0xc73fb8: DecompressPointer r3
    //     0xc73fb8: add             x3, x3, HEAP, lsl #32
    // 0xc73fbc: cmp             w3, NULL
    // 0xc73fc0: b.eq            #0xc740a4
    // 0xc73fc4: r4 = inline_Allocate_Double()
    //     0xc73fc4: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xc73fc8: add             x4, x4, #0x10
    //     0xc73fcc: cmp             x5, x4
    //     0xc73fd0: b.ls            #0xc740a8
    //     0xc73fd4: str             x4, [THR, #0x60]  ; THR::top
    //     0xc73fd8: sub             x4, x4, #0xf
    //     0xc73fdc: mov             x5, #0xd108
    //     0xc73fe0: movk            x5, #3, lsl #16
    //     0xc73fe4: stur            x5, [x4, #-1]
    // 0xc73fe8: StoreField: r4->field_7 = d0
    //     0xc73fe8: stur            d0, [x4, #7]
    // 0xc73fec: LoadField: d1 = r2->field_7
    //     0xc73fec: ldur            d1, [x2, #7]
    // 0xc73ff0: stp             x3, x1, [SP, #-0x10]!
    // 0xc73ff4: SaveReg r4
    //     0xc73ff4: str             x4, [SP, #-8]!
    // 0xc73ff8: SaveReg d1
    //     0xc73ff8: str             d1, [SP, #-8]!
    // 0xc73ffc: r0 = _initialScrollOffset()
    //     0xc73ffc: bl              #0xc740dc  ; [package:flutter/src/material/tabs.dart] _TabBarState::_initialScrollOffset
    // 0xc74000: add             SP, SP, #0x20
    // 0xc74004: r0 = inline_Allocate_Double()
    //     0xc74004: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc74008: add             x0, x0, #0x10
    //     0xc7400c: cmp             x1, x0
    //     0xc74010: b.ls            #0xc740cc
    //     0xc74014: str             x0, [THR, #0x60]  ; THR::top
    //     0xc74018: sub             x0, x0, #0xf
    //     0xc7401c: mov             x1, #0xd108
    //     0xc74020: movk            x1, #3, lsl #16
    //     0xc74024: stur            x1, [x0, #-1]
    // 0xc74028: StoreField: r0->field_7 = d0
    //     0xc74028: stur            d0, [x0, #7]
    // 0xc7402c: ldr             x1, [fp, #0x20]
    // 0xc74030: StoreField: r1->field_43 = r0
    //     0xc74030: stur            w0, [x1, #0x43]
    //     0xc74034: ldurb           w16, [x1, #-1]
    //     0xc74038: ldurb           w17, [x0, #-1]
    //     0xc7403c: and             x16, x17, x16, lsr #2
    //     0xc74040: tst             x16, HEAP, lsr #32
    //     0xc74044: b.eq            #0xc7404c
    //     0xc74048: bl              #0xd6826c
    // 0xc7404c: r0 = false
    //     0xc7404c: add             x0, NULL, #0x30  ; false
    // 0xc74050: b               #0xc7405c
    // 0xc74054: mov             x1, x0
    // 0xc74058: r0 = true
    //     0xc74058: add             x0, NULL, #0x20  ; true
    // 0xc7405c: ldr             d0, [fp, #0x18]
    // 0xc74060: stur            x0, [fp, #-8]
    // 0xc74064: SaveReg r1
    //     0xc74064: str             x1, [SP, #-8]!
    // 0xc74068: SaveReg d0
    //     0xc74068: str             d0, [SP, #-8]!
    // 0xc7406c: ldr             x16, [fp, #0x10]
    // 0xc74070: SaveReg r16
    //     0xc74070: str             x16, [SP, #-8]!
    // 0xc74074: r0 = applyContentDimensions()
    //     0xc74074: bl              #0xc742d4  ; [package:flutter/src/widgets/scroll_position.dart] ScrollPosition::applyContentDimensions
    // 0xc74078: add             SP, SP, #0x18
    // 0xc7407c: tbnz            w0, #4, #0xc74088
    // 0xc74080: ldur            x0, [fp, #-8]
    // 0xc74084: b               #0xc7408c
    // 0xc74088: r0 = false
    //     0xc74088: add             x0, NULL, #0x30  ; false
    // 0xc7408c: LeaveFrame
    //     0xc7408c: mov             SP, fp
    //     0xc74090: ldp             fp, lr, [SP], #0x10
    // 0xc74094: ret
    //     0xc74094: ret             
    // 0xc74098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc74098: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7409c: b               #0xc73f50
    // 0xc740a0: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc740a0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc740a4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc740a4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc740a8: SaveReg d0
    //     0xc740a8: str             q0, [SP, #-0x10]!
    // 0xc740ac: stp             x2, x3, [SP, #-0x10]!
    // 0xc740b0: stp             x0, x1, [SP, #-0x10]!
    // 0xc740b4: r0 = AllocateDouble()
    //     0xc740b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc740b8: mov             x4, x0
    // 0xc740bc: ldp             x0, x1, [SP], #0x10
    // 0xc740c0: ldp             x2, x3, [SP], #0x10
    // 0xc740c4: RestoreReg d0
    //     0xc740c4: ldr             q0, [SP], #0x10
    // 0xc740c8: b               #0xc73fe8
    // 0xc740cc: SaveReg d0
    //     0xc740cc: str             q0, [SP, #-0x10]!
    // 0xc740d0: r0 = AllocateDouble()
    //     0xc740d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc740d4: RestoreReg d0
    //     0xc740d4: ldr             q0, [SP], #0x10
    // 0xc740d8: b               #0xc74028
  }
}

// class id: 4855, size: 0x3c, field offset: 0x38
class _TabBarScrollController extends ScrollController {

  _ createScrollPosition(/* No info */) {
    // ** addr: 0xbebf58, size: 0x6c
    // 0xbebf58: EnterFrame
    //     0xbebf58: stp             fp, lr, [SP, #-0x10]!
    //     0xbebf5c: mov             fp, SP
    // 0xbebf60: AllocStack(0x10)
    //     0xbebf60: sub             SP, SP, #0x10
    // 0xbebf64: CheckStackOverflow
    //     0xbebf64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbebf68: cmp             SP, x16
    //     0xbebf6c: b.ls            #0xbebfbc
    // 0xbebf70: ldr             x0, [fp, #0x28]
    // 0xbebf74: LoadField: r1 = r0->field_37
    //     0xbebf74: ldur            w1, [x0, #0x37]
    // 0xbebf78: DecompressPointer r1
    //     0xbebf78: add             x1, x1, HEAP, lsl #32
    // 0xbebf7c: stur            x1, [fp, #-8]
    // 0xbebf80: r0 = _TabBarScrollPosition()
    //     0xbebf80: bl              #0xbec048  ; Allocate_TabBarScrollPositionStub -> _TabBarScrollPosition (size=0x8c)
    // 0xbebf84: stur            x0, [fp, #-0x10]
    // 0xbebf88: ldr             x16, [fp, #0x18]
    // 0xbebf8c: stp             x16, x0, [SP, #-0x10]!
    // 0xbebf90: ldr             x16, [fp, #0x10]
    // 0xbebf94: ldr             lr, [fp, #0x20]
    // 0xbebf98: stp             lr, x16, [SP, #-0x10]!
    // 0xbebf9c: ldur            x16, [fp, #-8]
    // 0xbebfa0: SaveReg r16
    //     0xbebfa0: str             x16, [SP, #-8]!
    // 0xbebfa4: r0 = _TabBarScrollPosition()
    //     0xbebfa4: bl              #0xbebfc4  ; [package:flutter/src/material/tabs.dart] _TabBarScrollPosition::_TabBarScrollPosition
    // 0xbebfa8: add             SP, SP, #0x28
    // 0xbebfac: ldur            x0, [fp, #-0x10]
    // 0xbebfb0: LeaveFrame
    //     0xbebfb0: mov             SP, fp
    //     0xbebfb4: ldp             fp, lr, [SP], #0x10
    // 0xbebfb8: ret
    //     0xbebfb8: ret             
    // 0xbebfbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbebfbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbebfc0: b               #0xbebf70
  }
}

// class id: 5945, size: 0x14, field offset: 0x14
enum TabBarIndicatorSize extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb165e4, size: 0x5c
    // 0xb165e4: EnterFrame
    //     0xb165e4: stp             fp, lr, [SP, #-0x10]!
    //     0xb165e8: mov             fp, SP
    // 0xb165ec: CheckStackOverflow
    //     0xb165ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb165f0: cmp             SP, x16
    //     0xb165f4: b.ls            #0xb16638
    // 0xb165f8: r1 = Null
    //     0xb165f8: mov             x1, NULL
    // 0xb165fc: r2 = 4
    //     0xb165fc: mov             x2, #4
    // 0xb16600: r0 = AllocateArray()
    //     0xb16600: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16604: r17 = "TabBarIndicatorSize."
    //     0xb16604: add             x17, PP, #0xe, lsl #12  ; [pp+0xe528] "TabBarIndicatorSize."
    //     0xb16608: ldr             x17, [x17, #0x528]
    // 0xb1660c: StoreField: r0->field_f = r17
    //     0xb1660c: stur            w17, [x0, #0xf]
    // 0xb16610: ldr             x1, [fp, #0x10]
    // 0xb16614: LoadField: r2 = r1->field_f
    //     0xb16614: ldur            w2, [x1, #0xf]
    // 0xb16618: DecompressPointer r2
    //     0xb16618: add             x2, x2, HEAP, lsl #32
    // 0xb1661c: StoreField: r0->field_13 = r2
    //     0xb1661c: stur            w2, [x0, #0x13]
    // 0xb16620: SaveReg r0
    //     0xb16620: str             x0, [SP, #-8]!
    // 0xb16624: r0 = _interpolate()
    //     0xb16624: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16628: add             SP, SP, #8
    // 0xb1662c: LeaveFrame
    //     0xb1662c: mov             SP, fp
    //     0xb16630: ldp             fp, lr, [SP], #0x10
    // 0xb16634: ret
    //     0xb16634: ret             
    // 0xb16638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1663c: b               #0xb165f8
  }
}

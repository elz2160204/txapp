// lib: , url: package:flutter/src/material/material_localizations.dart

// class id: 1049269, size: 0x8
class :: {
}

// class id: 2165, size: 0x8, field offset: 0x8
//   const constructor, 
class DefaultMaterialLocalizations extends Object
    implements MaterialLocalizations {

  _ remainingTextFieldCharacterCount(/* No info */) {
    // ** addr: 0x83e02c, size: 0xd0
    // 0x83e02c: EnterFrame
    //     0x83e02c: stp             fp, lr, [SP, #-0x10]!
    //     0x83e030: mov             fp, SP
    // 0x83e034: AllocStack(0x8)
    //     0x83e034: sub             SP, SP, #8
    // 0x83e038: CheckStackOverflow
    //     0x83e038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83e03c: cmp             SP, x16
    //     0x83e040: b.ls            #0x83e0f4
    // 0x83e044: ldr             x2, [fp, #0x10]
    // 0x83e048: r0 = BoxInt64Instr(r2)
    //     0x83e048: sbfiz           x0, x2, #1, #0x1f
    //     0x83e04c: cmp             x2, x0, asr #1
    //     0x83e050: b.eq            #0x83e05c
    //     0x83e054: bl              #0xd69bb8
    //     0x83e058: stur            x2, [x0, #7]
    // 0x83e05c: stur            x0, [fp, #-8]
    // 0x83e060: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x83e060: mov             x1, #0x76
    //     0x83e064: tbz             w0, #0, #0x83e074
    //     0x83e068: ldur            x1, [x0, #-1]
    //     0x83e06c: ubfx            x1, x1, #0xc, #0x14
    //     0x83e070: lsl             x1, x1, #1
    // 0x83e074: cmp             w1, #0x76
    // 0x83e078: b.ne            #0x83e0b8
    // 0x83e07c: cmp             x2, #0
    // 0x83e080: b.gt            #0x83e09c
    // 0x83e084: cbnz            w0, #0x83e0b8
    // 0x83e088: r0 = "No characters remaining"
    //     0x83e088: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2dd58] "No characters remaining"
    //     0x83e08c: ldr             x0, [x0, #0xd58]
    // 0x83e090: LeaveFrame
    //     0x83e090: mov             SP, fp
    //     0x83e094: ldp             fp, lr, [SP], #0x10
    // 0x83e098: ret
    //     0x83e098: ret             
    // 0x83e09c: cmp             w0, #2
    // 0x83e0a0: b.ne            #0x83e0b8
    // 0x83e0a4: r0 = "1 character remaining"
    //     0x83e0a4: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2dd60] "1 character remaining"
    //     0x83e0a8: ldr             x0, [x0, #0xd60]
    // 0x83e0ac: LeaveFrame
    //     0x83e0ac: mov             SP, fp
    //     0x83e0b0: ldp             fp, lr, [SP], #0x10
    // 0x83e0b4: ret
    //     0x83e0b4: ret             
    // 0x83e0b8: r1 = Null
    //     0x83e0b8: mov             x1, NULL
    // 0x83e0bc: r2 = 4
    //     0x83e0bc: mov             x2, #4
    // 0x83e0c0: r0 = AllocateArray()
    //     0x83e0c0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x83e0c4: mov             x1, x0
    // 0x83e0c8: ldur            x0, [fp, #-8]
    // 0x83e0cc: StoreField: r1->field_f = r0
    //     0x83e0cc: stur            w0, [x1, #0xf]
    // 0x83e0d0: r17 = " characters remaining"
    //     0x83e0d0: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dd68] " characters remaining"
    //     0x83e0d4: ldr             x17, [x17, #0xd68]
    // 0x83e0d8: StoreField: r1->field_13 = r17
    //     0x83e0d8: stur            w17, [x1, #0x13]
    // 0x83e0dc: SaveReg r1
    //     0x83e0dc: str             x1, [SP, #-8]!
    // 0x83e0e0: r0 = _interpolate()
    //     0x83e0e0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x83e0e4: add             SP, SP, #8
    // 0x83e0e8: LeaveFrame
    //     0x83e0e8: mov             SP, fp
    //     0x83e0ec: ldp             fp, lr, [SP], #0x10
    // 0x83e0f0: ret
    //     0x83e0f0: ret             
    // 0x83e0f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83e0f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83e0f8: b               #0x83e044
  }
  static _ load(/* No info */) {
    // ** addr: 0xcbabf8, size: 0x2c
    // 0xcbabf8: EnterFrame
    //     0xcbabf8: stp             fp, lr, [SP, #-0x10]!
    //     0xcbabfc: mov             fp, SP
    // 0xcbac00: r1 = <MaterialLocalizations>
    //     0xcbac00: add             x1, PP, #0xd, lsl #12  ; [pp+0xdfa0] TypeArguments: <MaterialLocalizations>
    //     0xcbac04: ldr             x1, [x1, #0xfa0]
    // 0xcbac08: r0 = SynchronousFuture()
    //     0xcbac08: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xcbac0c: r1 = Instance_DefaultMaterialLocalizations
    //     0xcbac0c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40028] Obj!DefaultMaterialLocalizations@b37d11
    //     0xcbac10: ldr             x1, [x1, #0x28]
    // 0xcbac14: StoreField: r0->field_b = r1
    //     0xcbac14: stur            w1, [x0, #0xb]
    // 0xcbac18: LeaveFrame
    //     0xcbac18: mov             SP, fp
    //     0xcbac1c: ldp             fp, lr, [SP], #0x10
    // 0xcbac20: ret
    //     0xcbac20: ret             
  }
}

// class id: 2166, size: 0x8, field offset: 0x8
abstract class MaterialLocalizations extends Object {

  static _ of(/* No info */) {
    // ** addr: 0x832f90, size: 0x5c
    // 0x832f90: EnterFrame
    //     0x832f90: stp             fp, lr, [SP, #-0x10]!
    //     0x832f94: mov             fp, SP
    // 0x832f98: CheckStackOverflow
    //     0x832f98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x832f9c: cmp             SP, x16
    //     0x832fa0: b.ls            #0x832fe0
    // 0x832fa4: r16 = <MaterialLocalizations>
    //     0x832fa4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfa0] TypeArguments: <MaterialLocalizations>
    //     0x832fa8: ldr             x16, [x16, #0xfa0]
    // 0x832fac: ldr             lr, [fp, #0x10]
    // 0x832fb0: stp             lr, x16, [SP, #-0x10]!
    // 0x832fb4: r16 = MaterialLocalizations
    //     0x832fb4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdfa8] Type: MaterialLocalizations
    //     0x832fb8: ldr             x16, [x16, #0xfa8]
    // 0x832fbc: SaveReg r16
    //     0x832fbc: str             x16, [SP, #-8]!
    // 0x832fc0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x832fc0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x832fc4: r0 = of()
    //     0x832fc4: bl              #0x6ced68  ; [package:flutter/src/widgets/localizations.dart] Localizations::of
    // 0x832fc8: add             SP, SP, #0x18
    // 0x832fcc: cmp             w0, NULL
    // 0x832fd0: b.eq            #0x832fe8
    // 0x832fd4: LeaveFrame
    //     0x832fd4: mov             SP, fp
    //     0x832fd8: ldp             fp, lr, [SP], #0x10
    // 0x832fdc: ret
    //     0x832fdc: ret             
    // 0x832fe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x832fe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x832fe4: b               #0x832fa4
    // 0x832fe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x832fe8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4233, size: 0xc, field offset: 0xc
//   const constructor, 
class _MaterialLocalizationsDelegate extends LocalizationsDelegate<MaterialLocalizations> {

  _ toString(/* No info */) {
    // ** addr: 0xad7568, size: 0xc
    // 0xad7568: r0 = "DefaultMaterialLocalizations.delegate(en_US)"
    //     0xad7568: add             x0, PP, #0x22, lsl #12  ; [pp+0x22070] "DefaultMaterialLocalizations.delegate(en_US)"
    //     0xad756c: ldr             x0, [x0, #0x70]
    // 0xad7570: ret
    //     0xad7570: ret             
  }
  _ shouldReload(/* No info */) {
    // ** addr: 0xcb2e48, size: 0x54
    // 0xcb2e48: EnterFrame
    //     0xcb2e48: stp             fp, lr, [SP, #-0x10]!
    //     0xcb2e4c: mov             fp, SP
    // 0xcb2e50: ldr             x0, [fp, #0x10]
    // 0xcb2e54: r2 = Null
    //     0xcb2e54: mov             x2, NULL
    // 0xcb2e58: r1 = Null
    //     0xcb2e58: mov             x1, NULL
    // 0xcb2e5c: r4 = 59
    //     0xcb2e5c: mov             x4, #0x3b
    // 0xcb2e60: branchIfSmi(r0, 0xcb2e6c)
    //     0xcb2e60: tbz             w0, #0, #0xcb2e6c
    // 0xcb2e64: r4 = LoadClassIdInstr(r0)
    //     0xcb2e64: ldur            x4, [x0, #-1]
    //     0xcb2e68: ubfx            x4, x4, #0xc, #0x14
    // 0xcb2e6c: r17 = 4233
    //     0xcb2e6c: mov             x17, #0x1089
    // 0xcb2e70: cmp             x4, x17
    // 0xcb2e74: b.eq            #0xcb2e8c
    // 0xcb2e78: r8 = _MaterialLocalizationsDelegate<MaterialLocalizations>
    //     0xcb2e78: add             x8, PP, #0x40, lsl #12  ; [pp+0x40010] Type: _MaterialLocalizationsDelegate<MaterialLocalizations>
    //     0xcb2e7c: ldr             x8, [x8, #0x10]
    // 0xcb2e80: r3 = Null
    //     0xcb2e80: add             x3, PP, #0x40, lsl #12  ; [pp+0x40018] Null
    //     0xcb2e84: ldr             x3, [x3, #0x18]
    // 0xcb2e88: r0 = DefaultTypeTest()
    //     0xcb2e88: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcb2e8c: r0 = false
    //     0xcb2e8c: add             x0, NULL, #0x30  ; false
    // 0xcb2e90: LeaveFrame
    //     0xcb2e90: mov             SP, fp
    //     0xcb2e94: ldp             fp, lr, [SP], #0x10
    // 0xcb2e98: ret
    //     0xcb2e98: ret             
  }
  _ load(/* No info */) {
    // ** addr: 0xcbabcc, size: 0x2c
    // 0xcbabcc: EnterFrame
    //     0xcbabcc: stp             fp, lr, [SP, #-0x10]!
    //     0xcbabd0: mov             fp, SP
    // 0xcbabd4: CheckStackOverflow
    //     0xcbabd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcbabd8: cmp             SP, x16
    //     0xcbabdc: b.ls            #0xcbabf0
    // 0xcbabe0: r0 = load()
    //     0xcbabe0: bl              #0xcbabf8  ; [package:flutter/src/material/material_localizations.dart] DefaultMaterialLocalizations::load
    // 0xcbabe4: LeaveFrame
    //     0xcbabe4: mov             SP, fp
    //     0xcbabe8: ldp             fp, lr, [SP], #0x10
    // 0xcbabec: ret
    //     0xcbabec: ret             
    // 0xcbabf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcbabf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcbabf4: b               #0xcbabe0
  }
  _ isSupported(/* No info */) {
    // ** addr: 0xcbac7c, size: 0x80
    // 0xcbac7c: EnterFrame
    //     0xcbac7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcbac80: mov             fp, SP
    // 0xcbac84: AllocStack(0x8)
    //     0xcbac84: sub             SP, SP, #8
    // 0xcbac88: CheckStackOverflow
    //     0xcbac88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcbac8c: cmp             SP, x16
    //     0xcbac90: b.ls            #0xcbacf4
    // 0xcbac94: ldr             x0, [fp, #0x10]
    // 0xcbac98: LoadField: r1 = r0->field_7
    //     0xcbac98: ldur            w1, [x0, #7]
    // 0xcbac9c: DecompressPointer r1
    //     0xcbac9c: add             x1, x1, HEAP, lsl #32
    // 0xcbaca0: stur            x1, [fp, #-8]
    // 0xcbaca4: r16 = _ConstMap len:78
    //     0xcbaca4: ldr             x16, [PP, #0x23e8]  ; [pp+0x23e8] Map<String, String>(78)
    // 0xcbaca8: stp             x1, x16, [SP, #-0x10]!
    // 0xcbacac: r0 = []()
    //     0xcbacac: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xcbacb0: add             SP, SP, #0x10
    // 0xcbacb4: cmp             w0, NULL
    // 0xcbacb8: b.ne            #0xcbacc0
    // 0xcbacbc: ldur            x0, [fp, #-8]
    // 0xcbacc0: r1 = LoadClassIdInstr(r0)
    //     0xcbacc0: ldur            x1, [x0, #-1]
    //     0xcbacc4: ubfx            x1, x1, #0xc, #0x14
    // 0xcbacc8: r16 = "en"
    //     0xcbacc8: add             x16, PP, #0x38, lsl #12  ; [pp+0x38d38] "en"
    //     0xcbaccc: ldr             x16, [x16, #0xd38]
    // 0xcbacd0: stp             x16, x0, [SP, #-0x10]!
    // 0xcbacd4: mov             x0, x1
    // 0xcbacd8: mov             lr, x0
    // 0xcbacdc: ldr             lr, [x21, lr, lsl #3]
    // 0xcbace0: blr             lr
    // 0xcbace4: add             SP, SP, #0x10
    // 0xcbace8: LeaveFrame
    //     0xcbace8: mov             SP, fp
    //     0xcbacec: ldp             fp, lr, [SP], #0x10
    // 0xcbacf0: ret
    //     0xcbacf0: ret             
    // 0xcbacf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcbacf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcbacf8: b               #0xcbac94
  }
}

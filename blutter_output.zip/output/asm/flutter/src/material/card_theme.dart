// lib: , url: package:flutter/src/material/card_theme.dart

// class id: 1049202, size: 0x8
class :: {
}

// class id: 2819, size: 0x24, field offset: 0x8
//   const constructor, 
class CardTheme extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafe7e4, size: 0x68
    // 0xafe7e4: EnterFrame
    //     0xafe7e4: stp             fp, lr, [SP, #-0x10]!
    //     0xafe7e8: mov             fp, SP
    // 0xafe7ec: CheckStackOverflow
    //     0xafe7ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafe7f0: cmp             SP, x16
    //     0xafe7f4: b.ls            #0xafe844
    // 0xafe7f8: ldr             x0, [fp, #0x10]
    // 0xafe7fc: LoadField: r1 = r0->field_17
    //     0xafe7fc: ldur            w1, [x0, #0x17]
    // 0xafe800: DecompressPointer r1
    //     0xafe800: add             x1, x1, HEAP, lsl #32
    // 0xafe804: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafe808: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafe80c: stp             NULL, x1, [SP, #-0x10]!
    // 0xafe810: SaveReg rNULL
    //     0xafe810: str             NULL, [SP, #-8]!
    // 0xafe814: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xafe814: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xafe818: r0 = hash()
    //     0xafe818: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafe81c: add             SP, SP, #0x38
    // 0xafe820: mov             x2, x0
    // 0xafe824: r0 = BoxInt64Instr(r2)
    //     0xafe824: sbfiz           x0, x2, #1, #0x1f
    //     0xafe828: cmp             x2, x0, asr #1
    //     0xafe82c: b.eq            #0xafe838
    //     0xafe830: bl              #0xd69bb8
    //     0xafe834: stur            x2, [x0, #7]
    // 0xafe838: LeaveFrame
    //     0xafe838: mov             SP, fp
    //     0xafe83c: ldp             fp, lr, [SP], #0x10
    // 0xafe840: ret
    //     0xafe840: ret             
    // 0xafe844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafe844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafe848: b               #0xafe7f8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf57f8, size: 0xf4
    // 0xbf57f8: EnterFrame
    //     0xbf57f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf57fc: mov             fp, SP
    // 0xbf5800: AllocStack(0x10)
    //     0xbf5800: sub             SP, SP, #0x10
    // 0xbf5804: CheckStackOverflow
    //     0xbf5804: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5808: cmp             SP, x16
    //     0xbf580c: b.ls            #0xbf58d4
    // 0xbf5810: ldr             d0, [fp, #0x10]
    // 0xbf5814: r0 = inline_Allocate_Double()
    //     0xbf5814: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf5818: add             x0, x0, #0x10
    //     0xbf581c: cmp             x1, x0
    //     0xbf5820: b.ls            #0xbf58dc
    //     0xbf5824: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf5828: sub             x0, x0, #0xf
    //     0xbf582c: mov             x1, #0xd108
    //     0xbf5830: movk            x1, #3, lsl #16
    //     0xbf5834: stur            x1, [x0, #-1]
    // 0xbf5838: StoreField: r0->field_7 = d0
    //     0xbf5838: stur            d0, [x0, #7]
    // 0xbf583c: stur            x0, [fp, #-8]
    // 0xbf5840: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5844: SaveReg r0
    //     0xbf5844: str             x0, [SP, #-8]!
    // 0xbf5848: r0 = lerp()
    //     0xbf5848: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf584c: add             SP, SP, #0x18
    // 0xbf5850: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5854: ldur            x16, [fp, #-8]
    // 0xbf5858: SaveReg r16
    //     0xbf5858: str             x16, [SP, #-8]!
    // 0xbf585c: r0 = lerp()
    //     0xbf585c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5860: add             SP, SP, #0x18
    // 0xbf5864: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5868: ldur            x16, [fp, #-8]
    // 0xbf586c: SaveReg r16
    //     0xbf586c: str             x16, [SP, #-8]!
    // 0xbf5870: r0 = lerp()
    //     0xbf5870: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5874: add             SP, SP, #0x18
    // 0xbf5878: ldr             x0, [fp, #0x20]
    // 0xbf587c: LoadField: r1 = r0->field_17
    //     0xbf587c: ldur            w1, [x0, #0x17]
    // 0xbf5880: DecompressPointer r1
    //     0xbf5880: add             x1, x1, HEAP, lsl #32
    // 0xbf5884: ldr             x0, [fp, #0x18]
    // 0xbf5888: LoadField: r2 = r0->field_17
    //     0xbf5888: ldur            w2, [x0, #0x17]
    // 0xbf588c: DecompressPointer r2
    //     0xbf588c: add             x2, x2, HEAP, lsl #32
    // 0xbf5890: stp             x2, x1, [SP, #-0x10]!
    // 0xbf5894: ldur            x16, [fp, #-8]
    // 0xbf5898: SaveReg r16
    //     0xbf5898: str             x16, [SP, #-8]!
    // 0xbf589c: r0 = lerpDouble()
    //     0xbf589c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf58a0: add             SP, SP, #0x18
    // 0xbf58a4: stur            x0, [fp, #-0x10]
    // 0xbf58a8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf58ac: ldur            x16, [fp, #-8]
    // 0xbf58b0: SaveReg r16
    //     0xbf58b0: str             x16, [SP, #-8]!
    // 0xbf58b4: r0 = lerp()
    //     0xbf58b4: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf58b8: add             SP, SP, #0x18
    // 0xbf58bc: r0 = CardTheme()
    //     0xbf58bc: bl              #0xbf58ec  ; AllocateCardThemeStub -> CardTheme (size=0x24)
    // 0xbf58c0: ldur            x1, [fp, #-0x10]
    // 0xbf58c4: StoreField: r0->field_17 = r1
    //     0xbf58c4: stur            w1, [x0, #0x17]
    // 0xbf58c8: LeaveFrame
    //     0xbf58c8: mov             SP, fp
    //     0xbf58cc: ldp             fp, lr, [SP], #0x10
    // 0xbf58d0: ret
    //     0xbf58d0: ret             
    // 0xbf58d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf58d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf58d8: b               #0xbf5810
    // 0xbf58dc: SaveReg d0
    //     0xbf58dc: str             q0, [SP, #-0x10]!
    // 0xbf58e0: r0 = AllocateDouble()
    //     0xbf58e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf58e4: RestoreReg d0
    //     0xbf58e4: ldr             q0, [SP], #0x10
    // 0xbf58e8: b               #0xbf5838
  }
  _ ==(/* No info */) {
    // ** addr: 0xc84da0, size: 0x12c
    // 0xc84da0: EnterFrame
    //     0xc84da0: stp             fp, lr, [SP, #-0x10]!
    //     0xc84da4: mov             fp, SP
    // 0xc84da8: CheckStackOverflow
    //     0xc84da8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc84dac: cmp             SP, x16
    //     0xc84db0: b.ls            #0xc84ec4
    // 0xc84db4: ldr             x1, [fp, #0x10]
    // 0xc84db8: cmp             w1, NULL
    // 0xc84dbc: b.ne            #0xc84dd0
    // 0xc84dc0: r0 = false
    //     0xc84dc0: add             x0, NULL, #0x30  ; false
    // 0xc84dc4: LeaveFrame
    //     0xc84dc4: mov             SP, fp
    //     0xc84dc8: ldp             fp, lr, [SP], #0x10
    // 0xc84dcc: ret
    //     0xc84dcc: ret             
    // 0xc84dd0: ldr             x2, [fp, #0x18]
    // 0xc84dd4: cmp             w2, w1
    // 0xc84dd8: b.ne            #0xc84dec
    // 0xc84ddc: r0 = true
    //     0xc84ddc: add             x0, NULL, #0x20  ; true
    // 0xc84de0: LeaveFrame
    //     0xc84de0: mov             SP, fp
    //     0xc84de4: ldp             fp, lr, [SP], #0x10
    // 0xc84de8: ret
    //     0xc84de8: ret             
    // 0xc84dec: r0 = 59
    //     0xc84dec: mov             x0, #0x3b
    // 0xc84df0: branchIfSmi(r1, 0xc84dfc)
    //     0xc84df0: tbz             w1, #0, #0xc84dfc
    // 0xc84df4: r0 = LoadClassIdInstr(r1)
    //     0xc84df4: ldur            x0, [x1, #-1]
    //     0xc84df8: ubfx            x0, x0, #0xc, #0x14
    // 0xc84dfc: SaveReg r1
    //     0xc84dfc: str             x1, [SP, #-8]!
    // 0xc84e00: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc84e00: mov             x17, #0x57c5
    //     0xc84e04: add             lr, x0, x17
    //     0xc84e08: ldr             lr, [x21, lr, lsl #3]
    //     0xc84e0c: blr             lr
    // 0xc84e10: add             SP, SP, #8
    // 0xc84e14: r1 = LoadClassIdInstr(r0)
    //     0xc84e14: ldur            x1, [x0, #-1]
    //     0xc84e18: ubfx            x1, x1, #0xc, #0x14
    // 0xc84e1c: r16 = CardTheme
    //     0xc84e1c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe430] Type: CardTheme
    //     0xc84e20: ldr             x16, [x16, #0x430]
    // 0xc84e24: stp             x16, x0, [SP, #-0x10]!
    // 0xc84e28: mov             x0, x1
    // 0xc84e2c: mov             lr, x0
    // 0xc84e30: ldr             lr, [x21, lr, lsl #3]
    // 0xc84e34: blr             lr
    // 0xc84e38: add             SP, SP, #0x10
    // 0xc84e3c: tbz             w0, #4, #0xc84e50
    // 0xc84e40: r0 = false
    //     0xc84e40: add             x0, NULL, #0x30  ; false
    // 0xc84e44: LeaveFrame
    //     0xc84e44: mov             SP, fp
    //     0xc84e48: ldp             fp, lr, [SP], #0x10
    // 0xc84e4c: ret
    //     0xc84e4c: ret             
    // 0xc84e50: ldr             x0, [fp, #0x10]
    // 0xc84e54: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc84e54: mov             x1, #0x76
    //     0xc84e58: tbz             w0, #0, #0xc84e68
    //     0xc84e5c: ldur            x1, [x0, #-1]
    //     0xc84e60: ubfx            x1, x1, #0xc, #0x14
    //     0xc84e64: lsl             x1, x1, #1
    // 0xc84e68: r17 = 5638
    //     0xc84e68: mov             x17, #0x1606
    // 0xc84e6c: cmp             w1, w17
    // 0xc84e70: b.ne            #0xc84eb4
    // 0xc84e74: ldr             x1, [fp, #0x18]
    // 0xc84e78: LoadField: r2 = r0->field_17
    //     0xc84e78: ldur            w2, [x0, #0x17]
    // 0xc84e7c: DecompressPointer r2
    //     0xc84e7c: add             x2, x2, HEAP, lsl #32
    // 0xc84e80: LoadField: r0 = r1->field_17
    //     0xc84e80: ldur            w0, [x1, #0x17]
    // 0xc84e84: DecompressPointer r0
    //     0xc84e84: add             x0, x0, HEAP, lsl #32
    // 0xc84e88: r1 = LoadClassIdInstr(r2)
    //     0xc84e88: ldur            x1, [x2, #-1]
    //     0xc84e8c: ubfx            x1, x1, #0xc, #0x14
    // 0xc84e90: stp             x0, x2, [SP, #-0x10]!
    // 0xc84e94: mov             x0, x1
    // 0xc84e98: mov             lr, x0
    // 0xc84e9c: ldr             lr, [x21, lr, lsl #3]
    // 0xc84ea0: blr             lr
    // 0xc84ea4: add             SP, SP, #0x10
    // 0xc84ea8: tbnz            w0, #4, #0xc84eb4
    // 0xc84eac: r0 = true
    //     0xc84eac: add             x0, NULL, #0x20  ; true
    // 0xc84eb0: b               #0xc84eb8
    // 0xc84eb4: r0 = false
    //     0xc84eb4: add             x0, NULL, #0x30  ; false
    // 0xc84eb8: LeaveFrame
    //     0xc84eb8: mov             SP, fp
    //     0xc84ebc: ldp             fp, lr, [SP], #0x10
    // 0xc84ec0: ret
    //     0xc84ec0: ret             
    // 0xc84ec4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc84ec4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc84ec8: b               #0xc84db4
  }
}

// lib: , url: package:flutter/src/material/icon_button.dart

// class id: 1049251, size: 0x8
class :: {
}

// class id: 2220, size: 0xc, field offset: 0xc
//   transformed mixin,
abstract class __IconButtonDefaultMouseCursor&MaterialStateProperty&Diagnosticable extends MaterialStateProperty<MouseCursor>
     with Diagnosticable {

  _ toString(/* No info */) {
    // ** addr: 0xada3d4, size: 0x4c
    // 0xada3d4: EnterFrame
    //     0xada3d4: stp             fp, lr, [SP, #-0x10]!
    //     0xada3d8: mov             fp, SP
    // 0xada3dc: mov             x0, x4
    // 0xada3e0: LoadField: r1 = r0->field_13
    //     0xada3e0: ldur            w1, [x0, #0x13]
    // 0xada3e4: DecompressPointer r1
    //     0xada3e4: add             x1, x1, HEAP, lsl #32
    // 0xada3e8: sub             x0, x1, #2
    // 0xada3ec: add             x1, fp, w0, sxtw #2
    // 0xada3f0: ldr             x1, [x1, #0x10]
    // 0xada3f4: CheckStackOverflow
    //     0xada3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada3f8: cmp             SP, x16
    //     0xada3fc: b.ls            #0xada418
    // 0xada400: SaveReg r1
    //     0xada400: str             x1, [SP, #-8]!
    // 0xada404: r0 = describeIdentity()
    //     0xada404: bl              #0xa77c6c  ; [package:flutter/src/foundation/diagnostics.dart] ::describeIdentity
    // 0xada408: add             SP, SP, #8
    // 0xada40c: LeaveFrame
    //     0xada40c: mov             SP, fp
    //     0xada410: ldp             fp, lr, [SP], #0x10
    // 0xada414: ret
    //     0xada414: ret             
    // 0xada418: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada418: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada41c: b               #0xada400
  }
}

// class id: 2224, size: 0x1c, field offset: 0xc
class _IconButtonDefaultOverlay extends MaterialStateProperty<Color?> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b59bc, size: 0x364
    // 0x5b59bc: EnterFrame
    //     0x5b59bc: stp             fp, lr, [SP, #-0x10]!
    //     0x5b59c0: mov             fp, SP
    // 0x5b59c4: CheckStackOverflow
    //     0x5b59c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b59c8: cmp             SP, x16
    //     0x5b59cc: b.ls            #0x5b5d18
    // 0x5b59d0: ldr             x1, [fp, #0x10]
    // 0x5b59d4: r0 = LoadClassIdInstr(r1)
    //     0x5b59d4: ldur            x0, [x1, #-1]
    //     0x5b59d8: ubfx            x0, x0, #0xc, #0x14
    // 0x5b59dc: r16 = Instance_MaterialState
    //     0x5b59dc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x5b59e0: ldr             x16, [x16, #0xf70]
    // 0x5b59e4: stp             x16, x1, [SP, #-0x10]!
    // 0x5b59e8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b59e8: mov             x17, #0xc98a
    //     0x5b59ec: add             lr, x0, x17
    //     0x5b59f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5b59f4: blr             lr
    // 0x5b59f8: add             SP, SP, #0x10
    // 0x5b59fc: tbnz            w0, #4, #0x5b5b88
    // 0x5b5a00: ldr             x1, [fp, #0x10]
    // 0x5b5a04: r0 = LoadClassIdInstr(r1)
    //     0x5b5a04: ldur            x0, [x1, #-1]
    //     0x5b5a08: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5a0c: r16 = Instance_MaterialState
    //     0x5b5a0c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x5b5a10: ldr             x16, [x16, #0xf90]
    // 0x5b5a14: stp             x16, x1, [SP, #-0x10]!
    // 0x5b5a18: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5a18: mov             x17, #0xc98a
    //     0x5b5a1c: add             lr, x0, x17
    //     0x5b5a20: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5a24: blr             lr
    // 0x5b5a28: add             SP, SP, #0x10
    // 0x5b5a2c: tbnz            w0, #4, #0x5b5a80
    // 0x5b5a30: ldr             x1, [fp, #0x18]
    // 0x5b5a34: LoadField: r0 = r1->field_17
    //     0x5b5a34: ldur            w0, [x1, #0x17]
    // 0x5b5a38: DecompressPointer r0
    //     0x5b5a38: add             x0, x0, HEAP, lsl #32
    // 0x5b5a3c: cmp             w0, NULL
    // 0x5b5a40: b.ne            #0x5b5a74
    // 0x5b5a44: LoadField: r0 = r1->field_b
    //     0x5b5a44: ldur            w0, [x1, #0xb]
    // 0x5b5a48: DecompressPointer r0
    //     0x5b5a48: add             x0, x0, HEAP, lsl #32
    // 0x5b5a4c: cmp             w0, NULL
    // 0x5b5a50: b.ne            #0x5b5a5c
    // 0x5b5a54: r0 = Null
    //     0x5b5a54: mov             x0, NULL
    // 0x5b5a58: b               #0x5b5a74
    // 0x5b5a5c: d0 = 0.120000
    //     0x5b5a5c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b5a60: ldr             d0, [x17, #0xf48]
    // 0x5b5a64: SaveReg r0
    //     0x5b5a64: str             x0, [SP, #-8]!
    // 0x5b5a68: SaveReg d0
    //     0x5b5a68: str             d0, [SP, #-8]!
    // 0x5b5a6c: r0 = withOpacity()
    //     0x5b5a6c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5a70: add             SP, SP, #0x10
    // 0x5b5a74: LeaveFrame
    //     0x5b5a74: mov             SP, fp
    //     0x5b5a78: ldp             fp, lr, [SP], #0x10
    // 0x5b5a7c: ret
    //     0x5b5a7c: ret             
    // 0x5b5a80: ldr             x1, [fp, #0x18]
    // 0x5b5a84: ldr             x2, [fp, #0x10]
    // 0x5b5a88: d0 = 0.120000
    //     0x5b5a88: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b5a8c: ldr             d0, [x17, #0xf48]
    // 0x5b5a90: r0 = LoadClassIdInstr(r2)
    //     0x5b5a90: ldur            x0, [x2, #-1]
    //     0x5b5a94: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5a98: r16 = Instance_MaterialState
    //     0x5b5a98: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x5b5a9c: ldr             x16, [x16, #0xf78]
    // 0x5b5aa0: stp             x16, x2, [SP, #-0x10]!
    // 0x5b5aa4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5aa4: mov             x17, #0xc98a
    //     0x5b5aa8: add             lr, x0, x17
    //     0x5b5aac: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5ab0: blr             lr
    // 0x5b5ab4: add             SP, SP, #0x10
    // 0x5b5ab8: tbnz            w0, #4, #0x5b5afc
    // 0x5b5abc: ldr             x1, [fp, #0x18]
    // 0x5b5ac0: LoadField: r0 = r1->field_b
    //     0x5b5ac0: ldur            w0, [x1, #0xb]
    // 0x5b5ac4: DecompressPointer r0
    //     0x5b5ac4: add             x0, x0, HEAP, lsl #32
    // 0x5b5ac8: cmp             w0, NULL
    // 0x5b5acc: b.ne            #0x5b5ad8
    // 0x5b5ad0: r0 = Null
    //     0x5b5ad0: mov             x0, NULL
    // 0x5b5ad4: b               #0x5b5af0
    // 0x5b5ad8: d0 = 0.080000
    //     0x5b5ad8: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x5b5adc: ldr             d0, [x17, #0xf80]
    // 0x5b5ae0: SaveReg r0
    //     0x5b5ae0: str             x0, [SP, #-8]!
    // 0x5b5ae4: SaveReg d0
    //     0x5b5ae4: str             d0, [SP, #-8]!
    // 0x5b5ae8: r0 = withOpacity()
    //     0x5b5ae8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5aec: add             SP, SP, #0x10
    // 0x5b5af0: LeaveFrame
    //     0x5b5af0: mov             SP, fp
    //     0x5b5af4: ldp             fp, lr, [SP], #0x10
    // 0x5b5af8: ret
    //     0x5b5af8: ret             
    // 0x5b5afc: ldr             x1, [fp, #0x18]
    // 0x5b5b00: ldr             x2, [fp, #0x10]
    // 0x5b5b04: d0 = 0.080000
    //     0x5b5b04: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x5b5b08: ldr             d0, [x17, #0xf80]
    // 0x5b5b0c: r0 = LoadClassIdInstr(r2)
    //     0x5b5b0c: ldur            x0, [x2, #-1]
    //     0x5b5b10: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5b14: r16 = Instance_MaterialState
    //     0x5b5b14: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x5b5b18: ldr             x16, [x16, #0xf88]
    // 0x5b5b1c: stp             x16, x2, [SP, #-0x10]!
    // 0x5b5b20: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5b20: mov             x17, #0xc98a
    //     0x5b5b24: add             lr, x0, x17
    //     0x5b5b28: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5b2c: blr             lr
    // 0x5b5b30: add             SP, SP, #0x10
    // 0x5b5b34: tbnz            w0, #4, #0x5b5b78
    // 0x5b5b38: ldr             x1, [fp, #0x18]
    // 0x5b5b3c: LoadField: r0 = r1->field_b
    //     0x5b5b3c: ldur            w0, [x1, #0xb]
    // 0x5b5b40: DecompressPointer r0
    //     0x5b5b40: add             x0, x0, HEAP, lsl #32
    // 0x5b5b44: cmp             w0, NULL
    // 0x5b5b48: b.ne            #0x5b5b54
    // 0x5b5b4c: r0 = Null
    //     0x5b5b4c: mov             x0, NULL
    // 0x5b5b50: b               #0x5b5b6c
    // 0x5b5b54: d0 = 0.120000
    //     0x5b5b54: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b5b58: ldr             d0, [x17, #0xf48]
    // 0x5b5b5c: SaveReg r0
    //     0x5b5b5c: str             x0, [SP, #-8]!
    // 0x5b5b60: SaveReg d0
    //     0x5b5b60: str             d0, [SP, #-8]!
    // 0x5b5b64: r0 = withOpacity()
    //     0x5b5b64: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5b68: add             SP, SP, #0x10
    // 0x5b5b6c: LeaveFrame
    //     0x5b5b6c: mov             SP, fp
    //     0x5b5b70: ldp             fp, lr, [SP], #0x10
    // 0x5b5b74: ret
    //     0x5b5b74: ret             
    // 0x5b5b78: ldr             x1, [fp, #0x18]
    // 0x5b5b7c: d0 = 0.120000
    //     0x5b5b7c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b5b80: ldr             d0, [x17, #0xf48]
    // 0x5b5b84: b               #0x5b5b94
    // 0x5b5b88: ldr             x1, [fp, #0x18]
    // 0x5b5b8c: d0 = 0.120000
    //     0x5b5b8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b5b90: ldr             d0, [x17, #0xf48]
    // 0x5b5b94: ldr             x2, [fp, #0x10]
    // 0x5b5b98: r0 = LoadClassIdInstr(r2)
    //     0x5b5b98: ldur            x0, [x2, #-1]
    //     0x5b5b9c: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5ba0: r16 = Instance_MaterialState
    //     0x5b5ba0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x5b5ba4: ldr             x16, [x16, #0xf90]
    // 0x5b5ba8: stp             x16, x2, [SP, #-0x10]!
    // 0x5b5bac: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5bac: mov             x17, #0xc98a
    //     0x5b5bb0: add             lr, x0, x17
    //     0x5b5bb4: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5bb8: blr             lr
    // 0x5b5bbc: add             SP, SP, #0x10
    // 0x5b5bc0: tbnz            w0, #4, #0x5b5c14
    // 0x5b5bc4: ldr             x1, [fp, #0x18]
    // 0x5b5bc8: LoadField: r0 = r1->field_17
    //     0x5b5bc8: ldur            w0, [x1, #0x17]
    // 0x5b5bcc: DecompressPointer r0
    //     0x5b5bcc: add             x0, x0, HEAP, lsl #32
    // 0x5b5bd0: cmp             w0, NULL
    // 0x5b5bd4: b.ne            #0x5b5c08
    // 0x5b5bd8: LoadField: r0 = r1->field_b
    //     0x5b5bd8: ldur            w0, [x1, #0xb]
    // 0x5b5bdc: DecompressPointer r0
    //     0x5b5bdc: add             x0, x0, HEAP, lsl #32
    // 0x5b5be0: cmp             w0, NULL
    // 0x5b5be4: b.ne            #0x5b5bf0
    // 0x5b5be8: r0 = Null
    //     0x5b5be8: mov             x0, NULL
    // 0x5b5bec: b               #0x5b5c08
    // 0x5b5bf0: d0 = 0.120000
    //     0x5b5bf0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x5b5bf4: ldr             d0, [x17, #0xf48]
    // 0x5b5bf8: SaveReg r0
    //     0x5b5bf8: str             x0, [SP, #-8]!
    // 0x5b5bfc: SaveReg d0
    //     0x5b5bfc: str             d0, [SP, #-8]!
    // 0x5b5c00: r0 = withOpacity()
    //     0x5b5c00: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5c04: add             SP, SP, #0x10
    // 0x5b5c08: LeaveFrame
    //     0x5b5c08: mov             SP, fp
    //     0x5b5c0c: ldp             fp, lr, [SP], #0x10
    // 0x5b5c10: ret
    //     0x5b5c10: ret             
    // 0x5b5c14: ldr             x1, [fp, #0x18]
    // 0x5b5c18: ldr             x2, [fp, #0x10]
    // 0x5b5c1c: r0 = LoadClassIdInstr(r2)
    //     0x5b5c1c: ldur            x0, [x2, #-1]
    //     0x5b5c20: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5c24: r16 = Instance_MaterialState
    //     0x5b5c24: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x5b5c28: ldr             x16, [x16, #0xf78]
    // 0x5b5c2c: stp             x16, x2, [SP, #-0x10]!
    // 0x5b5c30: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5c30: mov             x17, #0xc98a
    //     0x5b5c34: add             lr, x0, x17
    //     0x5b5c38: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5c3c: blr             lr
    // 0x5b5c40: add             SP, SP, #0x10
    // 0x5b5c44: tbnz            w0, #4, #0x5b5c88
    // 0x5b5c48: ldr             x1, [fp, #0x18]
    // 0x5b5c4c: LoadField: r0 = r1->field_b
    //     0x5b5c4c: ldur            w0, [x1, #0xb]
    // 0x5b5c50: DecompressPointer r0
    //     0x5b5c50: add             x0, x0, HEAP, lsl #32
    // 0x5b5c54: cmp             w0, NULL
    // 0x5b5c58: b.ne            #0x5b5c64
    // 0x5b5c5c: r0 = Null
    //     0x5b5c5c: mov             x0, NULL
    // 0x5b5c60: b               #0x5b5c7c
    // 0x5b5c64: d0 = 0.080000
    //     0x5b5c64: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x5b5c68: ldr             d0, [x17, #0xf80]
    // 0x5b5c6c: SaveReg r0
    //     0x5b5c6c: str             x0, [SP, #-8]!
    // 0x5b5c70: SaveReg d0
    //     0x5b5c70: str             d0, [SP, #-8]!
    // 0x5b5c74: r0 = withOpacity()
    //     0x5b5c74: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5c78: add             SP, SP, #0x10
    // 0x5b5c7c: LeaveFrame
    //     0x5b5c7c: mov             SP, fp
    //     0x5b5c80: ldp             fp, lr, [SP], #0x10
    // 0x5b5c84: ret
    //     0x5b5c84: ret             
    // 0x5b5c88: ldr             x1, [fp, #0x18]
    // 0x5b5c8c: ldr             x0, [fp, #0x10]
    // 0x5b5c90: d0 = 0.080000
    //     0x5b5c90: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x5b5c94: ldr             d0, [x17, #0xf80]
    // 0x5b5c98: r2 = LoadClassIdInstr(r0)
    //     0x5b5c98: ldur            x2, [x0, #-1]
    //     0x5b5c9c: ubfx            x2, x2, #0xc, #0x14
    // 0x5b5ca0: r16 = Instance_MaterialState
    //     0x5b5ca0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x5b5ca4: ldr             x16, [x16, #0xf88]
    // 0x5b5ca8: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5cac: mov             x0, x2
    // 0x5b5cb0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5cb0: mov             x17, #0xc98a
    //     0x5b5cb4: add             lr, x0, x17
    //     0x5b5cb8: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5cbc: blr             lr
    // 0x5b5cc0: add             SP, SP, #0x10
    // 0x5b5cc4: tbnz            w0, #4, #0x5b5d08
    // 0x5b5cc8: ldr             x0, [fp, #0x18]
    // 0x5b5ccc: LoadField: r1 = r0->field_b
    //     0x5b5ccc: ldur            w1, [x0, #0xb]
    // 0x5b5cd0: DecompressPointer r1
    //     0x5b5cd0: add             x1, x1, HEAP, lsl #32
    // 0x5b5cd4: cmp             w1, NULL
    // 0x5b5cd8: b.ne            #0x5b5ce4
    // 0x5b5cdc: r0 = Null
    //     0x5b5cdc: mov             x0, NULL
    // 0x5b5ce0: b               #0x5b5cfc
    // 0x5b5ce4: d0 = 0.080000
    //     0x5b5ce4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x5b5ce8: ldr             d0, [x17, #0xf80]
    // 0x5b5cec: SaveReg r1
    //     0x5b5cec: str             x1, [SP, #-8]!
    // 0x5b5cf0: SaveReg d0
    //     0x5b5cf0: str             d0, [SP, #-8]!
    // 0x5b5cf4: r0 = withOpacity()
    //     0x5b5cf4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5cf8: add             SP, SP, #0x10
    // 0x5b5cfc: LeaveFrame
    //     0x5b5cfc: mov             SP, fp
    //     0x5b5d00: ldp             fp, lr, [SP], #0x10
    // 0x5b5d04: ret
    //     0x5b5d04: ret             
    // 0x5b5d08: r0 = Null
    //     0x5b5d08: mov             x0, NULL
    // 0x5b5d0c: LeaveFrame
    //     0x5b5d0c: mov             SP, fp
    //     0x5b5d10: ldp             fp, lr, [SP], #0x10
    // 0x5b5d14: ret
    //     0x5b5d14: ret             
    // 0x5b5d18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b5d18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b5d1c: b               #0x5b59d0
  }
  _ toString(/* No info */) {
    // ** addr: 0xada33c, size: 0x98
    // 0xada33c: EnterFrame
    //     0xada33c: stp             fp, lr, [SP, #-0x10]!
    //     0xada340: mov             fp, SP
    // 0xada344: CheckStackOverflow
    //     0xada344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xada348: cmp             SP, x16
    //     0xada34c: b.ls            #0xada3cc
    // 0xada350: r1 = Null
    //     0xada350: mov             x1, NULL
    // 0xada354: r2 = 14
    //     0xada354: mov             x2, #0xe
    // 0xada358: r0 = AllocateArray()
    //     0xada358: bl              #0xd6987c  ; AllocateArrayStub
    // 0xada35c: r17 = "{hovered: "
    //     0xada35c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37708] "{hovered: "
    //     0xada360: ldr             x17, [x17, #0x708]
    // 0xada364: StoreField: r0->field_f = r17
    //     0xada364: stur            w17, [x0, #0xf]
    // 0xada368: ldr             x1, [fp, #0x10]
    // 0xada36c: LoadField: r2 = r1->field_13
    //     0xada36c: ldur            w2, [x1, #0x13]
    // 0xada370: DecompressPointer r2
    //     0xada370: add             x2, x2, HEAP, lsl #32
    // 0xada374: StoreField: r0->field_13 = r2
    //     0xada374: stur            w2, [x0, #0x13]
    // 0xada378: r17 = ", focused: "
    //     0xada378: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b890] ", focused: "
    //     0xada37c: ldr             x17, [x17, #0x890]
    // 0xada380: StoreField: r0->field_17 = r17
    //     0xada380: stur            w17, [x0, #0x17]
    // 0xada384: LoadField: r2 = r1->field_f
    //     0xada384: ldur            w2, [x1, #0xf]
    // 0xada388: DecompressPointer r2
    //     0xada388: add             x2, x2, HEAP, lsl #32
    // 0xada38c: StoreField: r0->field_1b = r2
    //     0xada38c: stur            w2, [x0, #0x1b]
    // 0xada390: r17 = ", pressed: "
    //     0xada390: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b898] ", pressed: "
    //     0xada394: ldr             x17, [x17, #0x898]
    // 0xada398: StoreField: r0->field_1f = r17
    //     0xada398: stur            w17, [x0, #0x1f]
    // 0xada39c: LoadField: r2 = r1->field_17
    //     0xada39c: ldur            w2, [x1, #0x17]
    // 0xada3a0: DecompressPointer r2
    //     0xada3a0: add             x2, x2, HEAP, lsl #32
    // 0xada3a4: StoreField: r0->field_23 = r2
    //     0xada3a4: stur            w2, [x0, #0x23]
    // 0xada3a8: r17 = ", otherwise: null}"
    //     0xada3a8: add             x17, PP, #0x37, lsl #12  ; [pp+0x37718] ", otherwise: null}"
    //     0xada3ac: ldr             x17, [x17, #0x718]
    // 0xada3b0: StoreField: r0->field_27 = r17
    //     0xada3b0: stur            w17, [x0, #0x27]
    // 0xada3b4: SaveReg r0
    //     0xada3b4: str             x0, [SP, #-8]!
    // 0xada3b8: r0 = _interpolate()
    //     0xada3b8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xada3bc: add             SP, SP, #8
    // 0xada3c0: LeaveFrame
    //     0xada3c0: mov             SP, fp
    //     0xada3c4: ldp             fp, lr, [SP], #0x10
    // 0xada3c8: ret
    //     0xada3c8: ret             
    // 0xada3cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xada3cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xada3d0: b               #0xada350
  }
}

// class id: 2225, size: 0x14, field offset: 0xc
class _IconButtonDefaultForeground extends MaterialStateProperty<Color?> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b5944, size: 0x78
    // 0x5b5944: EnterFrame
    //     0x5b5944: stp             fp, lr, [SP, #-0x10]!
    //     0x5b5948: mov             fp, SP
    // 0x5b594c: CheckStackOverflow
    //     0x5b594c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b5950: cmp             SP, x16
    //     0x5b5954: b.ls            #0x5b59b4
    // 0x5b5958: ldr             x0, [fp, #0x10]
    // 0x5b595c: r1 = LoadClassIdInstr(r0)
    //     0x5b595c: ldur            x1, [x0, #-1]
    //     0x5b5960: ubfx            x1, x1, #0xc, #0x14
    // 0x5b5964: r16 = Instance_MaterialState
    //     0x5b5964: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x5b5968: ldr             x16, [x16, #0x2a0]
    // 0x5b596c: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5970: mov             x0, x1
    // 0x5b5974: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5974: mov             x17, #0xc98a
    //     0x5b5978: add             lr, x0, x17
    //     0x5b597c: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5980: blr             lr
    // 0x5b5984: add             SP, SP, #0x10
    // 0x5b5988: tbnz            w0, #4, #0x5b599c
    // 0x5b598c: r0 = Null
    //     0x5b598c: mov             x0, NULL
    // 0x5b5990: LeaveFrame
    //     0x5b5990: mov             SP, fp
    //     0x5b5994: ldp             fp, lr, [SP], #0x10
    // 0x5b5998: ret
    //     0x5b5998: ret             
    // 0x5b599c: ldr             x1, [fp, #0x18]
    // 0x5b59a0: LoadField: r0 = r1->field_b
    //     0x5b59a0: ldur            w0, [x1, #0xb]
    // 0x5b59a4: DecompressPointer r0
    //     0x5b59a4: add             x0, x0, HEAP, lsl #32
    // 0x5b59a8: LeaveFrame
    //     0x5b59a8: mov             SP, fp
    //     0x5b59ac: ldp             fp, lr, [SP], #0x10
    // 0x5b59b0: ret
    //     0x5b59b0: ret             
    // 0x5b59b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b59b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b59b8: b               #0x5b5958
  }
}

// class id: 2832, size: 0x68, field offset: 0x60
class _IconButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x64

  get _ visualDensity(/* No info */) {
    // ** addr: 0xce592c, size: 0xc
    // 0xce592c: r0 = Instance_VisualDensity
    //     0xce592c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd260] Obj!VisualDensity@b3c131
    //     0xce5930: ldr             x0, [x0, #0x260]
    // 0xce5934: ret
    //     0xce5934: ret             
  }
  get _ mouseCursor(/* No info */) {
    // ** addr: 0xce59e4, size: 0x50
    // 0xce59e4: EnterFrame
    //     0xce59e4: stp             fp, lr, [SP, #-0x10]!
    //     0xce59e8: mov             fp, SP
    // 0xce59ec: CheckStackOverflow
    //     0xce59ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce59f0: cmp             SP, x16
    //     0xce59f4: b.ls            #0xce5a2c
    // 0xce59f8: r1 = Function '<anonymous closure>':.
    //     0xce59f8: add             x1, PP, #0x55, lsl #12  ; [pp+0x558b8] AnonymousClosure: (0x5b5d20), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::mouseCursor (0xce5a84)
    //     0xce59fc: ldr             x1, [x1, #0x8b8]
    // 0xce5a00: r2 = Null
    //     0xce5a00: mov             x2, NULL
    // 0xce5a04: r0 = AllocateClosure()
    //     0xce5a04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce5a08: r16 = <MouseCursor?>
    //     0xce5a08: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0xce5a0c: ldr             x16, [x16, #0x8b8]
    // 0xce5a10: stp             x0, x16, [SP, #-0x10]!
    // 0xce5a14: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce5a14: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce5a18: r0 = resolveWith()
    //     0xce5a18: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce5a1c: add             SP, SP, #0x10
    // 0xce5a20: LeaveFrame
    //     0xce5a20: mov             SP, fp
    //     0xce5a24: ldp             fp, lr, [SP], #0x10
    // 0xce5a28: ret
    //     0xce5a28: ret             
    // 0xce5a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5a30: b               #0xce59f8
  }
  get _ minimumSize(/* No info */) {
    // ** addr: 0xce5afc, size: 0xc
    // 0xce5afc: r0 = Instance_MaterialStatePropertyAll
    //     0xce5afc: add             x0, PP, #0x55, lsl #12  ; [pp+0x558c0] Obj!MaterialStatePropertyAll<Size>@b37cb1
    //     0xce5b00: ldr             x0, [x0, #0x8c0]
    // 0xce5b04: ret
    //     0xce5b04: ret             
  }
  get _ padding(/* No info */) {
    // ** addr: 0xce5b70, size: 0xc
    // 0xce5b70: r0 = Instance_MaterialStatePropertyAll
    //     0xce5b70: add             x0, PP, #0x55, lsl #12  ; [pp+0x558c8] Obj!MaterialStatePropertyAll<EdgeInsetsGeometry>@b37cd1
    //     0xce5b74: ldr             x0, [x0, #0x8c8]
    // 0xce5b78: ret
    //     0xce5b78: ret             
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xce67c4, size: 0x64
    // 0xce67c4: EnterFrame
    //     0xce67c4: stp             fp, lr, [SP, #-0x10]!
    //     0xce67c8: mov             fp, SP
    // 0xce67cc: CheckStackOverflow
    //     0xce67cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce67d0: cmp             SP, x16
    //     0xce67d4: b.ls            #0xce6820
    // 0xce67d8: r1 = 1
    //     0xce67d8: mov             x1, #1
    // 0xce67dc: r0 = AllocateContext()
    //     0xce67dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce67e0: mov             x1, x0
    // 0xce67e4: ldr             x0, [fp, #0x10]
    // 0xce67e8: StoreField: r1->field_f = r0
    //     0xce67e8: stur            w0, [x1, #0xf]
    // 0xce67ec: mov             x2, x1
    // 0xce67f0: r1 = Function '<anonymous closure>':.
    //     0xce67f0: add             x1, PP, #0x55, lsl #12  ; [pp+0x558d0] AnonymousClosure: (0xce6828), in [package:flutter/src/material/icon_button.dart] _IconButtonDefaultsM3::overlayColor (0xce67c4)
    //     0xce67f4: ldr             x1, [x1, #0x8d0]
    // 0xce67f8: r0 = AllocateClosure()
    //     0xce67f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce67fc: r16 = <Color?>
    //     0xce67fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce6800: ldr             x16, [x16, #0xf68]
    // 0xce6804: stp             x0, x16, [SP, #-0x10]!
    // 0xce6808: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce6808: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce680c: r0 = resolveWith()
    //     0xce680c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce6810: add             SP, SP, #0x10
    // 0xce6814: LeaveFrame
    //     0xce6814: mov             SP, fp
    //     0xce6818: ldp             fp, lr, [SP], #0x10
    // 0xce681c: ret
    //     0xce681c: ret             
    // 0xce6820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6824: b               #0xce67d8
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce6828, size: 0x450
    // 0xce6828: EnterFrame
    //     0xce6828: stp             fp, lr, [SP, #-0x10]!
    //     0xce682c: mov             fp, SP
    // 0xce6830: AllocStack(0x8)
    //     0xce6830: sub             SP, SP, #8
    // 0xce6834: SetupParameters()
    //     0xce6834: ldr             x0, [fp, #0x18]
    //     0xce6838: ldur            w1, [x0, #0x17]
    //     0xce683c: add             x1, x1, HEAP, lsl #32
    //     0xce6840: stur            x1, [fp, #-8]
    // 0xce6844: CheckStackOverflow
    //     0xce6844: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce6848: cmp             SP, x16
    //     0xce684c: b.ls            #0xce6c70
    // 0xce6850: ldr             x2, [fp, #0x10]
    // 0xce6854: r0 = LoadClassIdInstr(r2)
    //     0xce6854: ldur            x0, [x2, #-1]
    //     0xce6858: ubfx            x0, x0, #0xc, #0x14
    // 0xce685c: r16 = Instance_MaterialState
    //     0xce685c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0xce6860: ldr             x16, [x16, #0xf70]
    // 0xce6864: stp             x16, x2, [SP, #-0x10]!
    // 0xce6868: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6868: mov             x17, #0xc98a
    //     0xce686c: add             lr, x0, x17
    //     0xce6870: ldr             lr, [x21, lr, lsl #3]
    //     0xce6874: blr             lr
    // 0xce6878: add             SP, SP, #0x10
    // 0xce687c: tbnz            w0, #4, #0xce6a4c
    // 0xce6880: ldr             x1, [fp, #0x10]
    // 0xce6884: r0 = LoadClassIdInstr(r1)
    //     0xce6884: ldur            x0, [x1, #-1]
    //     0xce6888: ubfx            x0, x0, #0xc, #0x14
    // 0xce688c: r16 = Instance_MaterialState
    //     0xce688c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xce6890: ldr             x16, [x16, #0xf78]
    // 0xce6894: stp             x16, x1, [SP, #-0x10]!
    // 0xce6898: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6898: mov             x17, #0xc98a
    //     0xce689c: add             lr, x0, x17
    //     0xce68a0: ldr             lr, [x21, lr, lsl #3]
    //     0xce68a4: blr             lr
    // 0xce68a8: add             SP, SP, #0x10
    // 0xce68ac: tbnz            w0, #4, #0xce690c
    // 0xce68b0: ldur            x1, [fp, #-8]
    // 0xce68b4: LoadField: r0 = r1->field_f
    //     0xce68b4: ldur            w0, [x1, #0xf]
    // 0xce68b8: DecompressPointer r0
    //     0xce68b8: add             x0, x0, HEAP, lsl #32
    // 0xce68bc: mov             x1, x0
    // 0xce68c0: LoadField: r0 = r1->field_63
    //     0xce68c0: ldur            w0, [x1, #0x63]
    // 0xce68c4: DecompressPointer r0
    //     0xce68c4: add             x0, x0, HEAP, lsl #32
    // 0xce68c8: r16 = Sentinel
    //     0xce68c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce68cc: cmp             w0, w16
    // 0xce68d0: b.ne            #0xce68e0
    // 0xce68d4: r2 = _colors
    //     0xce68d4: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce68d8: ldr             x2, [x2, #0x8d8]
    // 0xce68dc: r0 = InitLateFinalInstanceField()
    //     0xce68dc: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce68e0: LoadField: r1 = r0->field_b
    //     0xce68e0: ldur            w1, [x0, #0xb]
    // 0xce68e4: DecompressPointer r1
    //     0xce68e4: add             x1, x1, HEAP, lsl #32
    // 0xce68e8: SaveReg r1
    //     0xce68e8: str             x1, [SP, #-8]!
    // 0xce68ec: d0 = 0.080000
    //     0xce68ec: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce68f0: ldr             d0, [x17, #0xf80]
    // 0xce68f4: SaveReg d0
    //     0xce68f4: str             d0, [SP, #-8]!
    // 0xce68f8: r0 = withOpacity()
    //     0xce68f8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce68fc: add             SP, SP, #0x10
    // 0xce6900: LeaveFrame
    //     0xce6900: mov             SP, fp
    //     0xce6904: ldp             fp, lr, [SP], #0x10
    // 0xce6908: ret
    //     0xce6908: ret             
    // 0xce690c: ldr             x2, [fp, #0x10]
    // 0xce6910: ldur            x1, [fp, #-8]
    // 0xce6914: d0 = 0.080000
    //     0xce6914: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6918: ldr             d0, [x17, #0xf80]
    // 0xce691c: r0 = LoadClassIdInstr(r2)
    //     0xce691c: ldur            x0, [x2, #-1]
    //     0xce6920: ubfx            x0, x0, #0xc, #0x14
    // 0xce6924: r16 = Instance_MaterialState
    //     0xce6924: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xce6928: ldr             x16, [x16, #0xf88]
    // 0xce692c: stp             x16, x2, [SP, #-0x10]!
    // 0xce6930: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6930: mov             x17, #0xc98a
    //     0xce6934: add             lr, x0, x17
    //     0xce6938: ldr             lr, [x21, lr, lsl #3]
    //     0xce693c: blr             lr
    // 0xce6940: add             SP, SP, #0x10
    // 0xce6944: tbnz            w0, #4, #0xce69a4
    // 0xce6948: ldur            x1, [fp, #-8]
    // 0xce694c: LoadField: r0 = r1->field_f
    //     0xce694c: ldur            w0, [x1, #0xf]
    // 0xce6950: DecompressPointer r0
    //     0xce6950: add             x0, x0, HEAP, lsl #32
    // 0xce6954: mov             x1, x0
    // 0xce6958: LoadField: r0 = r1->field_63
    //     0xce6958: ldur            w0, [x1, #0x63]
    // 0xce695c: DecompressPointer r0
    //     0xce695c: add             x0, x0, HEAP, lsl #32
    // 0xce6960: r16 = Sentinel
    //     0xce6960: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6964: cmp             w0, w16
    // 0xce6968: b.ne            #0xce6978
    // 0xce696c: r2 = _colors
    //     0xce696c: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce6970: ldr             x2, [x2, #0x8d8]
    // 0xce6974: r0 = InitLateFinalInstanceField()
    //     0xce6974: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6978: LoadField: r1 = r0->field_b
    //     0xce6978: ldur            w1, [x0, #0xb]
    // 0xce697c: DecompressPointer r1
    //     0xce697c: add             x1, x1, HEAP, lsl #32
    // 0xce6980: SaveReg r1
    //     0xce6980: str             x1, [SP, #-8]!
    // 0xce6984: d0 = 0.120000
    //     0xce6984: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6988: ldr             d0, [x17, #0xf48]
    // 0xce698c: SaveReg d0
    //     0xce698c: str             d0, [SP, #-8]!
    // 0xce6990: r0 = withOpacity()
    //     0xce6990: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6994: add             SP, SP, #0x10
    // 0xce6998: LeaveFrame
    //     0xce6998: mov             SP, fp
    //     0xce699c: ldp             fp, lr, [SP], #0x10
    // 0xce69a0: ret
    //     0xce69a0: ret             
    // 0xce69a4: ldr             x2, [fp, #0x10]
    // 0xce69a8: ldur            x1, [fp, #-8]
    // 0xce69ac: d0 = 0.120000
    //     0xce69ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce69b0: ldr             d0, [x17, #0xf48]
    // 0xce69b4: r0 = LoadClassIdInstr(r2)
    //     0xce69b4: ldur            x0, [x2, #-1]
    //     0xce69b8: ubfx            x0, x0, #0xc, #0x14
    // 0xce69bc: r16 = Instance_MaterialState
    //     0xce69bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xce69c0: ldr             x16, [x16, #0xf90]
    // 0xce69c4: stp             x16, x2, [SP, #-0x10]!
    // 0xce69c8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce69c8: mov             x17, #0xc98a
    //     0xce69cc: add             lr, x0, x17
    //     0xce69d0: ldr             lr, [x21, lr, lsl #3]
    //     0xce69d4: blr             lr
    // 0xce69d8: add             SP, SP, #0x10
    // 0xce69dc: tbnz            w0, #4, #0xce6a3c
    // 0xce69e0: ldur            x1, [fp, #-8]
    // 0xce69e4: LoadField: r0 = r1->field_f
    //     0xce69e4: ldur            w0, [x1, #0xf]
    // 0xce69e8: DecompressPointer r0
    //     0xce69e8: add             x0, x0, HEAP, lsl #32
    // 0xce69ec: mov             x1, x0
    // 0xce69f0: LoadField: r0 = r1->field_63
    //     0xce69f0: ldur            w0, [x1, #0x63]
    // 0xce69f4: DecompressPointer r0
    //     0xce69f4: add             x0, x0, HEAP, lsl #32
    // 0xce69f8: r16 = Sentinel
    //     0xce69f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce69fc: cmp             w0, w16
    // 0xce6a00: b.ne            #0xce6a10
    // 0xce6a04: r2 = _colors
    //     0xce6a04: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce6a08: ldr             x2, [x2, #0x8d8]
    // 0xce6a0c: r0 = InitLateFinalInstanceField()
    //     0xce6a0c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6a10: LoadField: r1 = r0->field_b
    //     0xce6a10: ldur            w1, [x0, #0xb]
    // 0xce6a14: DecompressPointer r1
    //     0xce6a14: add             x1, x1, HEAP, lsl #32
    // 0xce6a18: SaveReg r1
    //     0xce6a18: str             x1, [SP, #-8]!
    // 0xce6a1c: d0 = 0.120000
    //     0xce6a1c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6a20: ldr             d0, [x17, #0xf48]
    // 0xce6a24: SaveReg d0
    //     0xce6a24: str             d0, [SP, #-8]!
    // 0xce6a28: r0 = withOpacity()
    //     0xce6a28: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6a2c: add             SP, SP, #0x10
    // 0xce6a30: LeaveFrame
    //     0xce6a30: mov             SP, fp
    //     0xce6a34: ldp             fp, lr, [SP], #0x10
    // 0xce6a38: ret
    //     0xce6a38: ret             
    // 0xce6a3c: ldur            x1, [fp, #-8]
    // 0xce6a40: d0 = 0.120000
    //     0xce6a40: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6a44: ldr             d0, [x17, #0xf48]
    // 0xce6a48: b               #0xce6a58
    // 0xce6a4c: ldur            x1, [fp, #-8]
    // 0xce6a50: d0 = 0.120000
    //     0xce6a50: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6a54: ldr             d0, [x17, #0xf48]
    // 0xce6a58: ldr             x2, [fp, #0x10]
    // 0xce6a5c: r0 = LoadClassIdInstr(r2)
    //     0xce6a5c: ldur            x0, [x2, #-1]
    //     0xce6a60: ubfx            x0, x0, #0xc, #0x14
    // 0xce6a64: r16 = Instance_MaterialState
    //     0xce6a64: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xce6a68: ldr             x16, [x16, #0xf78]
    // 0xce6a6c: stp             x16, x2, [SP, #-0x10]!
    // 0xce6a70: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6a70: mov             x17, #0xc98a
    //     0xce6a74: add             lr, x0, x17
    //     0xce6a78: ldr             lr, [x21, lr, lsl #3]
    //     0xce6a7c: blr             lr
    // 0xce6a80: add             SP, SP, #0x10
    // 0xce6a84: tbnz            w0, #4, #0xce6b00
    // 0xce6a88: ldur            x1, [fp, #-8]
    // 0xce6a8c: LoadField: r0 = r1->field_f
    //     0xce6a8c: ldur            w0, [x1, #0xf]
    // 0xce6a90: DecompressPointer r0
    //     0xce6a90: add             x0, x0, HEAP, lsl #32
    // 0xce6a94: mov             x1, x0
    // 0xce6a98: LoadField: r0 = r1->field_63
    //     0xce6a98: ldur            w0, [x1, #0x63]
    // 0xce6a9c: DecompressPointer r0
    //     0xce6a9c: add             x0, x0, HEAP, lsl #32
    // 0xce6aa0: r16 = Sentinel
    //     0xce6aa0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6aa4: cmp             w0, w16
    // 0xce6aa8: b.ne            #0xce6ab8
    // 0xce6aac: r2 = _colors
    //     0xce6aac: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce6ab0: ldr             x2, [x2, #0x8d8]
    // 0xce6ab4: r0 = InitLateFinalInstanceField()
    //     0xce6ab4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6ab8: LoadField: r1 = r0->field_5f
    //     0xce6ab8: ldur            w1, [x0, #0x5f]
    // 0xce6abc: DecompressPointer r1
    //     0xce6abc: add             x1, x1, HEAP, lsl #32
    // 0xce6ac0: cmp             w1, NULL
    // 0xce6ac4: b.ne            #0xce6ad8
    // 0xce6ac8: LoadField: r1 = r0->field_57
    //     0xce6ac8: ldur            w1, [x0, #0x57]
    // 0xce6acc: DecompressPointer r1
    //     0xce6acc: add             x1, x1, HEAP, lsl #32
    // 0xce6ad0: mov             x0, x1
    // 0xce6ad4: b               #0xce6adc
    // 0xce6ad8: mov             x0, x1
    // 0xce6adc: d0 = 0.080000
    //     0xce6adc: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6ae0: ldr             d0, [x17, #0xf80]
    // 0xce6ae4: SaveReg r0
    //     0xce6ae4: str             x0, [SP, #-8]!
    // 0xce6ae8: SaveReg d0
    //     0xce6ae8: str             d0, [SP, #-8]!
    // 0xce6aec: r0 = withOpacity()
    //     0xce6aec: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6af0: add             SP, SP, #0x10
    // 0xce6af4: LeaveFrame
    //     0xce6af4: mov             SP, fp
    //     0xce6af8: ldp             fp, lr, [SP], #0x10
    // 0xce6afc: ret
    //     0xce6afc: ret             
    // 0xce6b00: ldr             x2, [fp, #0x10]
    // 0xce6b04: ldur            x1, [fp, #-8]
    // 0xce6b08: d0 = 0.080000
    //     0xce6b08: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6b0c: ldr             d0, [x17, #0xf80]
    // 0xce6b10: r0 = LoadClassIdInstr(r2)
    //     0xce6b10: ldur            x0, [x2, #-1]
    //     0xce6b14: ubfx            x0, x0, #0xc, #0x14
    // 0xce6b18: r16 = Instance_MaterialState
    //     0xce6b18: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xce6b1c: ldr             x16, [x16, #0xf88]
    // 0xce6b20: stp             x16, x2, [SP, #-0x10]!
    // 0xce6b24: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6b24: mov             x17, #0xc98a
    //     0xce6b28: add             lr, x0, x17
    //     0xce6b2c: ldr             lr, [x21, lr, lsl #3]
    //     0xce6b30: blr             lr
    // 0xce6b34: add             SP, SP, #0x10
    // 0xce6b38: tbnz            w0, #4, #0xce6bb4
    // 0xce6b3c: ldur            x1, [fp, #-8]
    // 0xce6b40: LoadField: r0 = r1->field_f
    //     0xce6b40: ldur            w0, [x1, #0xf]
    // 0xce6b44: DecompressPointer r0
    //     0xce6b44: add             x0, x0, HEAP, lsl #32
    // 0xce6b48: mov             x1, x0
    // 0xce6b4c: LoadField: r0 = r1->field_63
    //     0xce6b4c: ldur            w0, [x1, #0x63]
    // 0xce6b50: DecompressPointer r0
    //     0xce6b50: add             x0, x0, HEAP, lsl #32
    // 0xce6b54: r16 = Sentinel
    //     0xce6b54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6b58: cmp             w0, w16
    // 0xce6b5c: b.ne            #0xce6b6c
    // 0xce6b60: r2 = _colors
    //     0xce6b60: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce6b64: ldr             x2, [x2, #0x8d8]
    // 0xce6b68: r0 = InitLateFinalInstanceField()
    //     0xce6b68: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6b6c: LoadField: r1 = r0->field_5f
    //     0xce6b6c: ldur            w1, [x0, #0x5f]
    // 0xce6b70: DecompressPointer r1
    //     0xce6b70: add             x1, x1, HEAP, lsl #32
    // 0xce6b74: cmp             w1, NULL
    // 0xce6b78: b.ne            #0xce6b8c
    // 0xce6b7c: LoadField: r1 = r0->field_57
    //     0xce6b7c: ldur            w1, [x0, #0x57]
    // 0xce6b80: DecompressPointer r1
    //     0xce6b80: add             x1, x1, HEAP, lsl #32
    // 0xce6b84: mov             x0, x1
    // 0xce6b88: b               #0xce6b90
    // 0xce6b8c: mov             x0, x1
    // 0xce6b90: d0 = 0.080000
    //     0xce6b90: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6b94: ldr             d0, [x17, #0xf80]
    // 0xce6b98: SaveReg r0
    //     0xce6b98: str             x0, [SP, #-8]!
    // 0xce6b9c: SaveReg d0
    //     0xce6b9c: str             d0, [SP, #-8]!
    // 0xce6ba0: r0 = withOpacity()
    //     0xce6ba0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6ba4: add             SP, SP, #0x10
    // 0xce6ba8: LeaveFrame
    //     0xce6ba8: mov             SP, fp
    //     0xce6bac: ldp             fp, lr, [SP], #0x10
    // 0xce6bb0: ret
    //     0xce6bb0: ret             
    // 0xce6bb4: ldr             x0, [fp, #0x10]
    // 0xce6bb8: ldur            x1, [fp, #-8]
    // 0xce6bbc: r2 = LoadClassIdInstr(r0)
    //     0xce6bbc: ldur            x2, [x0, #-1]
    //     0xce6bc0: ubfx            x2, x2, #0xc, #0x14
    // 0xce6bc4: r16 = Instance_MaterialState
    //     0xce6bc4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xce6bc8: ldr             x16, [x16, #0xf90]
    // 0xce6bcc: stp             x16, x0, [SP, #-0x10]!
    // 0xce6bd0: mov             x0, x2
    // 0xce6bd4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6bd4: mov             x17, #0xc98a
    //     0xce6bd8: add             lr, x0, x17
    //     0xce6bdc: ldr             lr, [x21, lr, lsl #3]
    //     0xce6be0: blr             lr
    // 0xce6be4: add             SP, SP, #0x10
    // 0xce6be8: tbnz            w0, #4, #0xce6c60
    // 0xce6bec: ldur            x0, [fp, #-8]
    // 0xce6bf0: LoadField: r1 = r0->field_f
    //     0xce6bf0: ldur            w1, [x0, #0xf]
    // 0xce6bf4: DecompressPointer r1
    //     0xce6bf4: add             x1, x1, HEAP, lsl #32
    // 0xce6bf8: LoadField: r0 = r1->field_63
    //     0xce6bf8: ldur            w0, [x1, #0x63]
    // 0xce6bfc: DecompressPointer r0
    //     0xce6bfc: add             x0, x0, HEAP, lsl #32
    // 0xce6c00: r16 = Sentinel
    //     0xce6c00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6c04: cmp             w0, w16
    // 0xce6c08: b.ne            #0xce6c18
    // 0xce6c0c: r2 = _colors
    //     0xce6c0c: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce6c10: ldr             x2, [x2, #0x8d8]
    // 0xce6c14: r0 = InitLateFinalInstanceField()
    //     0xce6c14: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6c18: LoadField: r1 = r0->field_5f
    //     0xce6c18: ldur            w1, [x0, #0x5f]
    // 0xce6c1c: DecompressPointer r1
    //     0xce6c1c: add             x1, x1, HEAP, lsl #32
    // 0xce6c20: cmp             w1, NULL
    // 0xce6c24: b.ne            #0xce6c38
    // 0xce6c28: LoadField: r1 = r0->field_57
    //     0xce6c28: ldur            w1, [x0, #0x57]
    // 0xce6c2c: DecompressPointer r1
    //     0xce6c2c: add             x1, x1, HEAP, lsl #32
    // 0xce6c30: mov             x0, x1
    // 0xce6c34: b               #0xce6c3c
    // 0xce6c38: mov             x0, x1
    // 0xce6c3c: d0 = 0.120000
    //     0xce6c3c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6c40: ldr             d0, [x17, #0xf48]
    // 0xce6c44: SaveReg r0
    //     0xce6c44: str             x0, [SP, #-8]!
    // 0xce6c48: SaveReg d0
    //     0xce6c48: str             d0, [SP, #-8]!
    // 0xce6c4c: r0 = withOpacity()
    //     0xce6c4c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6c50: add             SP, SP, #0x10
    // 0xce6c54: LeaveFrame
    //     0xce6c54: mov             SP, fp
    //     0xce6c58: ldp             fp, lr, [SP], #0x10
    // 0xce6c5c: ret
    //     0xce6c5c: ret             
    // 0xce6c60: r0 = Null
    //     0xce6c60: mov             x0, NULL
    // 0xce6c64: LeaveFrame
    //     0xce6c64: mov             SP, fp
    //     0xce6c68: ldp             fp, lr, [SP], #0x10
    // 0xce6c6c: ret
    //     0xce6c6c: ret             
    // 0xce6c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce6c70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce6c74: b               #0xce6850
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0xce7668, size: 0x64
    // 0xce7668: EnterFrame
    //     0xce7668: stp             fp, lr, [SP, #-0x10]!
    //     0xce766c: mov             fp, SP
    // 0xce7670: CheckStackOverflow
    //     0xce7670: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7674: cmp             SP, x16
    //     0xce7678: b.ls            #0xce76c4
    // 0xce767c: r1 = 1
    //     0xce767c: mov             x1, #1
    // 0xce7680: r0 = AllocateContext()
    //     0xce7680: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce7684: mov             x1, x0
    // 0xce7688: ldr             x0, [fp, #0x10]
    // 0xce768c: StoreField: r1->field_f = r0
    //     0xce768c: stur            w0, [x1, #0xf]
    // 0xce7690: mov             x2, x1
    // 0xce7694: r1 = Function '<anonymous closure>':.
    //     0xce7694: add             x1, PP, #0x55, lsl #12  ; [pp+0x558e0] AnonymousClosure: (0xce76cc), in [package:flutter/src/material/icon_button.dart] _IconButtonDefaultsM3::foregroundColor (0xce7668)
    //     0xce7698: ldr             x1, [x1, #0x8e0]
    // 0xce769c: r0 = AllocateClosure()
    //     0xce769c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce76a0: r16 = <Color?>
    //     0xce76a0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce76a4: ldr             x16, [x16, #0xf68]
    // 0xce76a8: stp             x0, x16, [SP, #-0x10]!
    // 0xce76ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce76ac: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce76b0: r0 = resolveWith()
    //     0xce76b0: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce76b4: add             SP, SP, #0x10
    // 0xce76b8: LeaveFrame
    //     0xce76b8: mov             SP, fp
    //     0xce76bc: ldp             fp, lr, [SP], #0x10
    // 0xce76c0: ret
    //     0xce76c0: ret             
    // 0xce76c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce76c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce76c8: b               #0xce767c
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce76cc, size: 0x194
    // 0xce76cc: EnterFrame
    //     0xce76cc: stp             fp, lr, [SP, #-0x10]!
    //     0xce76d0: mov             fp, SP
    // 0xce76d4: AllocStack(0x8)
    //     0xce76d4: sub             SP, SP, #8
    // 0xce76d8: SetupParameters()
    //     0xce76d8: ldr             x0, [fp, #0x18]
    //     0xce76dc: ldur            w1, [x0, #0x17]
    //     0xce76e0: add             x1, x1, HEAP, lsl #32
    //     0xce76e4: stur            x1, [fp, #-8]
    // 0xce76e8: CheckStackOverflow
    //     0xce76e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce76ec: cmp             SP, x16
    //     0xce76f0: b.ls            #0xce7858
    // 0xce76f4: ldr             x2, [fp, #0x10]
    // 0xce76f8: r0 = LoadClassIdInstr(r2)
    //     0xce76f8: ldur            x0, [x2, #-1]
    //     0xce76fc: ubfx            x0, x0, #0xc, #0x14
    // 0xce7700: r16 = Instance_MaterialState
    //     0xce7700: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xce7704: ldr             x16, [x16, #0x2a0]
    // 0xce7708: stp             x16, x2, [SP, #-0x10]!
    // 0xce770c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce770c: mov             x17, #0xc98a
    //     0xce7710: add             lr, x0, x17
    //     0xce7714: ldr             lr, [x21, lr, lsl #3]
    //     0xce7718: blr             lr
    // 0xce771c: add             SP, SP, #0x10
    // 0xce7720: tbnz            w0, #4, #0xce7780
    // 0xce7724: ldur            x1, [fp, #-8]
    // 0xce7728: LoadField: r0 = r1->field_f
    //     0xce7728: ldur            w0, [x1, #0xf]
    // 0xce772c: DecompressPointer r0
    //     0xce772c: add             x0, x0, HEAP, lsl #32
    // 0xce7730: mov             x1, x0
    // 0xce7734: LoadField: r0 = r1->field_63
    //     0xce7734: ldur            w0, [x1, #0x63]
    // 0xce7738: DecompressPointer r0
    //     0xce7738: add             x0, x0, HEAP, lsl #32
    // 0xce773c: r16 = Sentinel
    //     0xce773c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7740: cmp             w0, w16
    // 0xce7744: b.ne            #0xce7754
    // 0xce7748: r2 = _colors
    //     0xce7748: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce774c: ldr             x2, [x2, #0x8d8]
    // 0xce7750: r0 = InitLateFinalInstanceField()
    //     0xce7750: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7754: LoadField: r1 = r0->field_57
    //     0xce7754: ldur            w1, [x0, #0x57]
    // 0xce7758: DecompressPointer r1
    //     0xce7758: add             x1, x1, HEAP, lsl #32
    // 0xce775c: SaveReg r1
    //     0xce775c: str             x1, [SP, #-8]!
    // 0xce7760: d0 = 0.380000
    //     0xce7760: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xce7764: ldr             d0, [x17, #0x140]
    // 0xce7768: SaveReg d0
    //     0xce7768: str             d0, [SP, #-8]!
    // 0xce776c: r0 = withOpacity()
    //     0xce776c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce7770: add             SP, SP, #0x10
    // 0xce7774: LeaveFrame
    //     0xce7774: mov             SP, fp
    //     0xce7778: ldp             fp, lr, [SP], #0x10
    // 0xce777c: ret
    //     0xce777c: ret             
    // 0xce7780: ldr             x0, [fp, #0x10]
    // 0xce7784: ldur            x1, [fp, #-8]
    // 0xce7788: r2 = LoadClassIdInstr(r0)
    //     0xce7788: ldur            x2, [x0, #-1]
    //     0xce778c: ubfx            x2, x2, #0xc, #0x14
    // 0xce7790: r16 = Instance_MaterialState
    //     0xce7790: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0xce7794: ldr             x16, [x16, #0xf70]
    // 0xce7798: stp             x16, x0, [SP, #-0x10]!
    // 0xce779c: mov             x0, x2
    // 0xce77a0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce77a0: mov             x17, #0xc98a
    //     0xce77a4: add             lr, x0, x17
    //     0xce77a8: ldr             lr, [x21, lr, lsl #3]
    //     0xce77ac: blr             lr
    // 0xce77b0: add             SP, SP, #0x10
    // 0xce77b4: tbnz            w0, #4, #0xce77fc
    // 0xce77b8: ldur            x0, [fp, #-8]
    // 0xce77bc: LoadField: r1 = r0->field_f
    //     0xce77bc: ldur            w1, [x0, #0xf]
    // 0xce77c0: DecompressPointer r1
    //     0xce77c0: add             x1, x1, HEAP, lsl #32
    // 0xce77c4: LoadField: r0 = r1->field_63
    //     0xce77c4: ldur            w0, [x1, #0x63]
    // 0xce77c8: DecompressPointer r0
    //     0xce77c8: add             x0, x0, HEAP, lsl #32
    // 0xce77cc: r16 = Sentinel
    //     0xce77cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce77d0: cmp             w0, w16
    // 0xce77d4: b.ne            #0xce77e4
    // 0xce77d8: r2 = _colors
    //     0xce77d8: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce77dc: ldr             x2, [x2, #0x8d8]
    // 0xce77e0: r0 = InitLateFinalInstanceField()
    //     0xce77e0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce77e4: LoadField: r1 = r0->field_b
    //     0xce77e4: ldur            w1, [x0, #0xb]
    // 0xce77e8: DecompressPointer r1
    //     0xce77e8: add             x1, x1, HEAP, lsl #32
    // 0xce77ec: mov             x0, x1
    // 0xce77f0: LeaveFrame
    //     0xce77f0: mov             SP, fp
    //     0xce77f4: ldp             fp, lr, [SP], #0x10
    // 0xce77f8: ret
    //     0xce77f8: ret             
    // 0xce77fc: ldur            x0, [fp, #-8]
    // 0xce7800: LoadField: r1 = r0->field_f
    //     0xce7800: ldur            w1, [x0, #0xf]
    // 0xce7804: DecompressPointer r1
    //     0xce7804: add             x1, x1, HEAP, lsl #32
    // 0xce7808: LoadField: r0 = r1->field_63
    //     0xce7808: ldur            w0, [x1, #0x63]
    // 0xce780c: DecompressPointer r0
    //     0xce780c: add             x0, x0, HEAP, lsl #32
    // 0xce7810: r16 = Sentinel
    //     0xce7810: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7814: cmp             w0, w16
    // 0xce7818: b.ne            #0xce7828
    // 0xce781c: r2 = _colors
    //     0xce781c: add             x2, PP, #0x55, lsl #12  ; [pp+0x558d8] Field <_IconButtonDefaultsM3@752331726._colors@752331726>: late final (offset: 0x64)
    //     0xce7820: ldr             x2, [x2, #0x8d8]
    // 0xce7824: r0 = InitLateFinalInstanceField()
    //     0xce7824: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7828: LoadField: r1 = r0->field_5f
    //     0xce7828: ldur            w1, [x0, #0x5f]
    // 0xce782c: DecompressPointer r1
    //     0xce782c: add             x1, x1, HEAP, lsl #32
    // 0xce7830: cmp             w1, NULL
    // 0xce7834: b.ne            #0xce7848
    // 0xce7838: LoadField: r2 = r0->field_57
    //     0xce7838: ldur            w2, [x0, #0x57]
    // 0xce783c: DecompressPointer r2
    //     0xce783c: add             x2, x2, HEAP, lsl #32
    // 0xce7840: mov             x0, x2
    // 0xce7844: b               #0xce784c
    // 0xce7848: mov             x0, x1
    // 0xce784c: LeaveFrame
    //     0xce784c: mov             SP, fp
    //     0xce7850: ldp             fp, lr, [SP], #0x10
    // 0xce7854: ret
    //     0xce7854: ret             
    // 0xce7858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce785c: b               #0xce76f4
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0xce7c8c, size: 0xc
    // 0xce7c8c: r0 = Instance_MaterialStatePropertyAll
    //     0xce7c8c: add             x0, PP, #0x55, lsl #12  ; [pp+0x558e8] Obj!MaterialStatePropertyAll<Color?>@b37cf1
    //     0xce7c90: ldr             x0, [x0, #0x8e8]
    // 0xce7c94: ret
    //     0xce7c94: ret             
  }
}

// class id: 3323, size: 0x18, field offset: 0x14
class _SelectableIconButtonState extends State<_SelectableIconButton> {

  late final MaterialStatesController statesController; // offset: 0x14

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b106c, size: 0x124
    // 0x7b106c: EnterFrame
    //     0x7b106c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b1070: mov             fp, SP
    // 0x7b1074: CheckStackOverflow
    //     0x7b1074: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b1078: cmp             SP, x16
    //     0x7b107c: b.ls            #0x7b1178
    // 0x7b1080: ldr             x0, [fp, #0x10]
    // 0x7b1084: r2 = Null
    //     0x7b1084: mov             x2, NULL
    // 0x7b1088: r1 = Null
    //     0x7b1088: mov             x1, NULL
    // 0x7b108c: r4 = 59
    //     0x7b108c: mov             x4, #0x3b
    // 0x7b1090: branchIfSmi(r0, 0x7b109c)
    //     0x7b1090: tbz             w0, #0, #0x7b109c
    // 0x7b1094: r4 = LoadClassIdInstr(r0)
    //     0x7b1094: ldur            x4, [x0, #-1]
    //     0x7b1098: ubfx            x4, x4, #0xc, #0x14
    // 0x7b109c: r17 = 4154
    //     0x7b109c: mov             x17, #0x103a
    // 0x7b10a0: cmp             x4, x17
    // 0x7b10a4: b.eq            #0x7b10bc
    // 0x7b10a8: r8 = _SelectableIconButton
    //     0x7b10a8: add             x8, PP, #0x50, lsl #12  ; [pp+0x50c98] Type: _SelectableIconButton
    //     0x7b10ac: ldr             x8, [x8, #0xc98]
    // 0x7b10b0: r3 = Null
    //     0x7b10b0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50ca0] Null
    //     0x7b10b4: ldr             x3, [x3, #0xca0]
    // 0x7b10b8: r0 = _SelectableIconButton()
    //     0x7b10b8: bl              #0x7b1190  ; IsType__SelectableIconButton_Stub
    // 0x7b10bc: ldr             x3, [fp, #0x18]
    // 0x7b10c0: LoadField: r2 = r3->field_7
    //     0x7b10c0: ldur            w2, [x3, #7]
    // 0x7b10c4: DecompressPointer r2
    //     0x7b10c4: add             x2, x2, HEAP, lsl #32
    // 0x7b10c8: ldr             x0, [fp, #0x10]
    // 0x7b10cc: r1 = Null
    //     0x7b10cc: mov             x1, NULL
    // 0x7b10d0: cmp             w2, NULL
    // 0x7b10d4: b.eq            #0x7b10f8
    // 0x7b10d8: LoadField: r4 = r2->field_17
    //     0x7b10d8: ldur            w4, [x2, #0x17]
    // 0x7b10dc: DecompressPointer r4
    //     0x7b10dc: add             x4, x4, HEAP, lsl #32
    // 0x7b10e0: r8 = X0 bound StatefulWidget
    //     0x7b10e0: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b10e4: ldr             x8, [x8, #0x858]
    // 0x7b10e8: LoadField: r9 = r4->field_7
    //     0x7b10e8: ldur            x9, [x4, #7]
    // 0x7b10ec: r3 = Null
    //     0x7b10ec: add             x3, PP, #0x50, lsl #12  ; [pp+0x50cb0] Null
    //     0x7b10f0: ldr             x3, [x3, #0xcb0]
    // 0x7b10f4: blr             x9
    // 0x7b10f8: ldr             x0, [fp, #0x18]
    // 0x7b10fc: LoadField: r1 = r0->field_b
    //     0x7b10fc: ldur            w1, [x0, #0xb]
    // 0x7b1100: DecompressPointer r1
    //     0x7b1100: add             x1, x1, HEAP, lsl #32
    // 0x7b1104: cmp             w1, NULL
    // 0x7b1108: b.eq            #0x7b1180
    // 0x7b110c: LoadField: r1 = r0->field_13
    //     0x7b110c: ldur            w1, [x0, #0x13]
    // 0x7b1110: DecompressPointer r1
    //     0x7b1110: add             x1, x1, HEAP, lsl #32
    // 0x7b1114: r16 = Sentinel
    //     0x7b1114: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b1118: cmp             w1, w16
    // 0x7b111c: b.eq            #0x7b1184
    // 0x7b1120: LoadField: r2 = r1->field_27
    //     0x7b1120: ldur            w2, [x1, #0x27]
    // 0x7b1124: DecompressPointer r2
    //     0x7b1124: add             x2, x2, HEAP, lsl #32
    // 0x7b1128: r16 = Instance_MaterialState
    //     0x7b1128: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x7b112c: ldr             x16, [x16, #0xf70]
    // 0x7b1130: stp             x16, x2, [SP, #-0x10]!
    // 0x7b1134: r0 = contains()
    //     0x7b1134: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x7b1138: add             SP, SP, #0x10
    // 0x7b113c: tbnz            w0, #4, #0x7b1168
    // 0x7b1140: ldr             x0, [fp, #0x18]
    // 0x7b1144: LoadField: r1 = r0->field_13
    //     0x7b1144: ldur            w1, [x0, #0x13]
    // 0x7b1148: DecompressPointer r1
    //     0x7b1148: add             x1, x1, HEAP, lsl #32
    // 0x7b114c: r16 = Instance_MaterialState
    //     0x7b114c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x7b1150: ldr             x16, [x16, #0xf70]
    // 0x7b1154: stp             x16, x1, [SP, #-0x10]!
    // 0x7b1158: r16 = false
    //     0x7b1158: add             x16, NULL, #0x30  ; false
    // 0x7b115c: SaveReg r16
    //     0x7b115c: str             x16, [SP, #-8]!
    // 0x7b1160: r0 = update()
    //     0x7b1160: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b1164: add             SP, SP, #0x18
    // 0x7b1168: r0 = Null
    //     0x7b1168: mov             x0, NULL
    // 0x7b116c: LeaveFrame
    //     0x7b116c: mov             SP, fp
    //     0x7b1170: ldp             fp, lr, [SP], #0x10
    // 0x7b1174: ret
    //     0x7b1174: ret             
    // 0x7b1178: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b1178: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b117c: b               #0x7b1080
    // 0x7b1180: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b1180: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b1184: r9 = statesController
    //     0x7b1184: add             x9, PP, #0x50, lsl #12  ; [pp+0x50c90] Field <_SelectableIconButtonState@752331726.statesController>: late final (offset: 0x14)
    //     0x7b1188: ldr             x9, [x9, #0xc90]
    // 0x7b118c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b118c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x854048, size: 0xb0
    // 0x854048: EnterFrame
    //     0x854048: stp             fp, lr, [SP, #-0x10]!
    //     0x85404c: mov             fp, SP
    // 0x854050: AllocStack(0x20)
    //     0x854050: sub             SP, SP, #0x20
    // 0x854054: ldr             x0, [fp, #0x18]
    // 0x854058: LoadField: r1 = r0->field_13
    //     0x854058: ldur            w1, [x0, #0x13]
    // 0x85405c: DecompressPointer r1
    //     0x85405c: add             x1, x1, HEAP, lsl #32
    // 0x854060: r16 = Sentinel
    //     0x854060: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x854064: cmp             w1, w16
    // 0x854068: b.eq            #0x8540e8
    // 0x85406c: stur            x1, [fp, #-0x20]
    // 0x854070: LoadField: r2 = r0->field_b
    //     0x854070: ldur            w2, [x0, #0xb]
    // 0x854074: DecompressPointer r2
    //     0x854074: add             x2, x2, HEAP, lsl #32
    // 0x854078: cmp             w2, NULL
    // 0x85407c: b.eq            #0x8540f4
    // 0x854080: LoadField: r0 = r2->field_f
    //     0x854080: ldur            w0, [x2, #0xf]
    // 0x854084: DecompressPointer r0
    //     0x854084: add             x0, x0, HEAP, lsl #32
    // 0x854088: stur            x0, [fp, #-0x18]
    // 0x85408c: LoadField: r3 = r2->field_1b
    //     0x85408c: ldur            w3, [x2, #0x1b]
    // 0x854090: DecompressPointer r3
    //     0x854090: add             x3, x3, HEAP, lsl #32
    // 0x854094: stur            x3, [fp, #-0x10]
    // 0x854098: LoadField: r4 = r2->field_1f
    //     0x854098: ldur            w4, [x2, #0x1f]
    // 0x85409c: DecompressPointer r4
    //     0x85409c: add             x4, x4, HEAP, lsl #32
    // 0x8540a0: stur            x4, [fp, #-8]
    // 0x8540a4: r0 = _IconButtonM3()
    //     0x8540a4: bl              #0x8540f8  ; Allocate_IconButtonM3Stub -> _IconButtonM3 (size=0x34)
    // 0x8540a8: ldur            x1, [fp, #-0x10]
    // 0x8540ac: StoreField: r0->field_b = r1
    //     0x8540ac: stur            w1, [x0, #0xb]
    // 0x8540b0: ldur            x1, [fp, #-0x18]
    // 0x8540b4: StoreField: r0->field_1b = r1
    //     0x8540b4: stur            w1, [x0, #0x1b]
    // 0x8540b8: r1 = false
    //     0x8540b8: add             x1, NULL, #0x30  ; false
    // 0x8540bc: StoreField: r0->field_27 = r1
    //     0x8540bc: stur            w1, [x0, #0x27]
    // 0x8540c0: r1 = Instance_Clip
    //     0x8540c0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x8540c4: ldr             x1, [x1, #0xb38]
    // 0x8540c8: StoreField: r0->field_1f = r1
    //     0x8540c8: stur            w1, [x0, #0x1f]
    // 0x8540cc: ldur            x1, [fp, #-0x20]
    // 0x8540d0: StoreField: r0->field_2b = r1
    //     0x8540d0: stur            w1, [x0, #0x2b]
    // 0x8540d4: ldur            x1, [fp, #-8]
    // 0x8540d8: StoreField: r0->field_2f = r1
    //     0x8540d8: stur            w1, [x0, #0x2f]
    // 0x8540dc: LeaveFrame
    //     0x8540dc: mov             SP, fp
    //     0x8540e0: ldp             fp, lr, [SP], #0x10
    // 0x8540e4: ret
    //     0x8540e4: ret             
    // 0x8540e8: r9 = statesController
    //     0x8540e8: add             x9, PP, #0x50, lsl #12  ; [pp+0x50c90] Field <_SelectableIconButtonState@752331726.statesController>: late final (offset: 0x14)
    //     0x8540ec: ldr             x9, [x9, #0xc90]
    // 0x8540f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8540f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8540f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8540f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9ee8, size: 0xc0
    // 0x9d9ee8: EnterFrame
    //     0x9d9ee8: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9eec: mov             fp, SP
    // 0x9d9ef0: AllocStack(0x8)
    //     0x9d9ef0: sub             SP, SP, #8
    // 0x9d9ef4: CheckStackOverflow
    //     0x9d9ef4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9ef8: cmp             SP, x16
    //     0x9d9efc: b.ls            #0x9d9f9c
    // 0x9d9f00: ldr             x0, [fp, #0x10]
    // 0x9d9f04: LoadField: r1 = r0->field_b
    //     0x9d9f04: ldur            w1, [x0, #0xb]
    // 0x9d9f08: DecompressPointer r1
    //     0x9d9f08: add             x1, x1, HEAP, lsl #32
    // 0x9d9f0c: cmp             w1, NULL
    // 0x9d9f10: b.eq            #0x9d9fa4
    // 0x9d9f14: r1 = <Set<MaterialState>>
    //     0x9d9f14: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e518] TypeArguments: <Set<MaterialState>>
    //     0x9d9f18: ldr             x1, [x1, #0x518]
    // 0x9d9f1c: r0 = MaterialStatesController()
    //     0x9d9f1c: bl              #0x7b0bfc  ; AllocateMaterialStatesControllerStub -> MaterialStatesController (size=0x2c)
    // 0x9d9f20: stur            x0, [fp, #-8]
    // 0x9d9f24: SaveReg r0
    //     0x9d9f24: str             x0, [SP, #-8]!
    // 0x9d9f28: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d9f28: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d9f2c: r0 = MaterialStatesController()
    //     0x9d9f2c: bl              #0x7b0a98  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::MaterialStatesController
    // 0x9d9f30: add             SP, SP, #8
    // 0x9d9f34: ldr             x0, [fp, #0x10]
    // 0x9d9f38: LoadField: r1 = r0->field_13
    //     0x9d9f38: ldur            w1, [x0, #0x13]
    // 0x9d9f3c: DecompressPointer r1
    //     0x9d9f3c: add             x1, x1, HEAP, lsl #32
    // 0x9d9f40: r16 = Sentinel
    //     0x9d9f40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d9f44: cmp             w1, w16
    // 0x9d9f48: b.ne            #0x9d9f54
    // 0x9d9f4c: mov             x1, x0
    // 0x9d9f50: b               #0x9d9f6c
    // 0x9d9f54: r16 = "statesController"
    //     0x9d9f54: add             x16, PP, #0x50, lsl #12  ; [pp+0x50cc0] "statesController"
    //     0x9d9f58: ldr             x16, [x16, #0xcc0]
    // 0x9d9f5c: SaveReg r16
    //     0x9d9f5c: str             x16, [SP, #-8]!
    // 0x9d9f60: r0 = _throwFieldAlreadyInitialized()
    //     0x9d9f60: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x9d9f64: add             SP, SP, #8
    // 0x9d9f68: ldr             x1, [fp, #0x10]
    // 0x9d9f6c: ldur            x0, [fp, #-8]
    // 0x9d9f70: StoreField: r1->field_13 = r0
    //     0x9d9f70: stur            w0, [x1, #0x13]
    //     0x9d9f74: ldurb           w16, [x1, #-1]
    //     0x9d9f78: ldurb           w17, [x0, #-1]
    //     0x9d9f7c: and             x16, x17, x16, lsr #2
    //     0x9d9f80: tst             x16, HEAP, lsr #32
    //     0x9d9f84: b.eq            #0x9d9f8c
    //     0x9d9f88: bl              #0xd6826c
    // 0x9d9f8c: r0 = Null
    //     0x9d9f8c: mov             x0, NULL
    // 0x9d9f90: LeaveFrame
    //     0x9d9f90: mov             SP, fp
    //     0x9d9f94: ldp             fp, lr, [SP], #0x10
    // 0x9d9f98: ret
    //     0x9d9f98: ret             
    // 0x9d9f9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d9f9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d9fa0: b               #0x9d9f00
    // 0x9d9fa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9fa4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3855, size: 0x64, field offset: 0xc
//   const constructor, 
class IconButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb2130c, size: 0x718
    // 0xb2130c: EnterFrame
    //     0xb2130c: stp             fp, lr, [SP, #-0x10]!
    //     0xb21310: mov             fp, SP
    // 0xb21314: AllocStack(0x68)
    //     0xb21314: sub             SP, SP, #0x68
    // 0xb21318: CheckStackOverflow
    //     0xb21318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2131c: cmp             SP, x16
    //     0xb21320: b.ls            #0xb219a0
    // 0xb21324: ldr             x16, [fp, #0x10]
    // 0xb21328: SaveReg r16
    //     0xb21328: str             x16, [SP, #-8]!
    // 0xb2132c: r0 = of()
    //     0xb2132c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb21330: add             SP, SP, #8
    // 0xb21334: stur            x0, [fp, #-0x20]
    // 0xb21338: LoadField: r1 = r0->field_2b
    //     0xb21338: ldur            w1, [x0, #0x2b]
    // 0xb2133c: DecompressPointer r1
    //     0xb2133c: add             x1, x1, HEAP, lsl #32
    // 0xb21340: tbnz            w1, #4, #0xb214b8
    // 0xb21344: ldr             x0, [fp, #0x18]
    // 0xb21348: LoadField: r1 = r0->field_53
    //     0xb21348: ldur            w1, [x0, #0x53]
    // 0xb2134c: DecompressPointer r1
    //     0xb2134c: add             x1, x1, HEAP, lsl #32
    // 0xb21350: stur            x1, [fp, #-8]
    // 0xb21354: cmp             w1, NULL
    // 0xb21358: b.ne            #0xb21368
    // 0xb2135c: mov             x0, x1
    // 0xb21360: r1 = Null
    //     0xb21360: mov             x1, NULL
    // 0xb21364: b               #0xb21394
    // 0xb21368: LoadField: d0 = r1->field_7
    //     0xb21368: ldur            d0, [x1, #7]
    // 0xb2136c: stur            d0, [fp, #-0x60]
    // 0xb21370: LoadField: d1 = r1->field_17
    //     0xb21370: ldur            d1, [x1, #0x17]
    // 0xb21374: stur            d1, [fp, #-0x58]
    // 0xb21378: r0 = Size()
    //     0xb21378: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb2137c: ldur            d0, [fp, #-0x60]
    // 0xb21380: StoreField: r0->field_7 = d0
    //     0xb21380: stur            d0, [x0, #7]
    // 0xb21384: ldur            d0, [fp, #-0x58]
    // 0xb21388: StoreField: r0->field_f = d0
    //     0xb21388: stur            d0, [x0, #0xf]
    // 0xb2138c: mov             x1, x0
    // 0xb21390: ldur            x0, [fp, #-8]
    // 0xb21394: stur            x1, [fp, #-0x10]
    // 0xb21398: cmp             w0, NULL
    // 0xb2139c: b.ne            #0xb213a8
    // 0xb213a0: r1 = Null
    //     0xb213a0: mov             x1, NULL
    // 0xb213a4: b               #0xb213d0
    // 0xb213a8: LoadField: d0 = r0->field_f
    //     0xb213a8: ldur            d0, [x0, #0xf]
    // 0xb213ac: stur            d0, [fp, #-0x60]
    // 0xb213b0: LoadField: d1 = r0->field_1f
    //     0xb213b0: ldur            d1, [x0, #0x1f]
    // 0xb213b4: stur            d1, [fp, #-0x58]
    // 0xb213b8: r0 = Size()
    //     0xb213b8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xb213bc: ldur            d0, [fp, #-0x60]
    // 0xb213c0: StoreField: r0->field_7 = d0
    //     0xb213c0: stur            d0, [x0, #7]
    // 0xb213c4: ldur            d0, [fp, #-0x58]
    // 0xb213c8: StoreField: r0->field_f = d0
    //     0xb213c8: stur            d0, [x0, #0xf]
    // 0xb213cc: mov             x1, x0
    // 0xb213d0: ldr             x0, [fp, #0x18]
    // 0xb213d4: LoadField: r2 = r0->field_2b
    //     0xb213d4: ldur            w2, [x0, #0x2b]
    // 0xb213d8: DecompressPointer r2
    //     0xb213d8: add             x2, x2, HEAP, lsl #32
    // 0xb213dc: LoadField: r3 = r0->field_33
    //     0xb213dc: ldur            w3, [x0, #0x33]
    // 0xb213e0: DecompressPointer r3
    //     0xb213e0: add             x3, x3, HEAP, lsl #32
    // 0xb213e4: LoadField: r4 = r0->field_13
    //     0xb213e4: ldur            w4, [x0, #0x13]
    // 0xb213e8: DecompressPointer r4
    //     0xb213e8: add             x4, x4, HEAP, lsl #32
    // 0xb213ec: LoadField: r5 = r0->field_b
    //     0xb213ec: ldur            w5, [x0, #0xb]
    // 0xb213f0: DecompressPointer r5
    //     0xb213f0: add             x5, x5, HEAP, lsl #32
    // 0xb213f4: stp             x5, x2, [SP, #-0x10]!
    // 0xb213f8: stp             x4, x3, [SP, #-0x10]!
    // 0xb213fc: ldur            x16, [fp, #-0x10]
    // 0xb21400: stp             x1, x16, [SP, #-0x10]!
    // 0xb21404: r4 = const [0, 0x6, 0x6, 0x2, highlightColor, 0x2, maximumSize, 0x5, minimumSize, 0x4, padding, 0x3, null]
    //     0xb21404: add             x4, PP, #0x40, lsl #12  ; [pp+0x40180] List(13) [0, 0x6, 0x6, 0x2, "highlightColor", 0x2, "maximumSize", 0x5, "minimumSize", 0x4, "padding", 0x3, Null]
    //     0xb21408: ldr             x4, [x4, #0x180]
    // 0xb2140c: r0 = styleFrom()
    //     0xb2140c: bl              #0xb21efc  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xb21410: add             SP, SP, #0x30
    // 0xb21414: mov             x1, x0
    // 0xb21418: ldr             x0, [fp, #0x18]
    // 0xb2141c: stur            x1, [fp, #-0x18]
    // 0xb21420: LoadField: r2 = r0->field_1f
    //     0xb21420: ldur            w2, [x0, #0x1f]
    // 0xb21424: DecompressPointer r2
    //     0xb21424: add             x2, x2, HEAP, lsl #32
    // 0xb21428: stur            x2, [fp, #-0x10]
    // 0xb2142c: LoadField: r3 = r0->field_4b
    //     0xb2142c: ldur            w3, [x0, #0x4b]
    // 0xb21430: DecompressPointer r3
    //     0xb21430: add             x3, x3, HEAP, lsl #32
    // 0xb21434: stur            x3, [fp, #-8]
    // 0xb21438: cmp             w3, NULL
    // 0xb2143c: b.eq            #0xb21460
    // 0xb21440: r0 = Tooltip()
    //     0xb21440: bl              #0xb21ef0  ; AllocateTooltipStub -> Tooltip (size=0x50)
    // 0xb21444: mov             x1, x0
    // 0xb21448: ldur            x0, [fp, #-8]
    // 0xb2144c: StoreField: r1->field_b = r0
    //     0xb2144c: stur            w0, [x1, #0xb]
    // 0xb21450: ldur            x0, [fp, #-0x10]
    // 0xb21454: StoreField: r1->field_2b = r0
    //     0xb21454: stur            w0, [x1, #0x2b]
    // 0xb21458: mov             x2, x1
    // 0xb2145c: b               #0xb21468
    // 0xb21460: mov             x0, x2
    // 0xb21464: mov             x2, x0
    // 0xb21468: ldr             x1, [fp, #0x18]
    // 0xb2146c: ldur            x0, [fp, #-0x18]
    // 0xb21470: stur            x2, [fp, #-0x10]
    // 0xb21474: LoadField: r3 = r1->field_3b
    //     0xb21474: ldur            w3, [x1, #0x3b]
    // 0xb21478: DecompressPointer r3
    //     0xb21478: add             x3, x3, HEAP, lsl #32
    // 0xb2147c: stur            x3, [fp, #-8]
    // 0xb21480: r0 = _SelectableIconButton()
    //     0xb21480: bl              #0xb21ee4  ; Allocate_SelectableIconButtonStub -> _SelectableIconButton (size=0x24)
    // 0xb21484: mov             x1, x0
    // 0xb21488: ldur            x0, [fp, #-0x18]
    // 0xb2148c: StoreField: r1->field_f = r0
    //     0xb2148c: stur            w0, [x1, #0xf]
    // 0xb21490: r2 = false
    //     0xb21490: add             x2, NULL, #0x30  ; false
    // 0xb21494: StoreField: r1->field_17 = r2
    //     0xb21494: stur            w2, [x1, #0x17]
    // 0xb21498: ldur            x0, [fp, #-8]
    // 0xb2149c: StoreField: r1->field_1b = r0
    //     0xb2149c: stur            w0, [x1, #0x1b]
    // 0xb214a0: ldur            x0, [fp, #-0x10]
    // 0xb214a4: StoreField: r1->field_1f = r0
    //     0xb214a4: stur            w0, [x1, #0x1f]
    // 0xb214a8: mov             x0, x1
    // 0xb214ac: LeaveFrame
    //     0xb214ac: mov             SP, fp
    //     0xb214b0: ldp             fp, lr, [SP], #0x10
    // 0xb214b4: ret
    //     0xb214b4: ret             
    // 0xb214b8: ldr             x1, [fp, #0x18]
    // 0xb214bc: r2 = false
    //     0xb214bc: add             x2, NULL, #0x30  ; false
    // 0xb214c0: LoadField: r3 = r1->field_3b
    //     0xb214c0: ldur            w3, [x1, #0x3b]
    // 0xb214c4: DecompressPointer r3
    //     0xb214c4: add             x3, x3, HEAP, lsl #32
    // 0xb214c8: stur            x3, [fp, #-0x10]
    // 0xb214cc: cmp             w3, NULL
    // 0xb214d0: b.eq            #0xb214e0
    // 0xb214d4: LoadField: r4 = r1->field_2b
    //     0xb214d4: ldur            w4, [x1, #0x2b]
    // 0xb214d8: DecompressPointer r4
    //     0xb214d8: add             x4, x4, HEAP, lsl #32
    // 0xb214dc: b               #0xb214e8
    // 0xb214e0: LoadField: r4 = r0->field_47
    //     0xb214e0: ldur            w4, [x0, #0x47]
    // 0xb214e4: DecompressPointer r4
    //     0xb214e4: add             x4, x4, HEAP, lsl #32
    // 0xb214e8: stur            x4, [fp, #-8]
    // 0xb214ec: LoadField: r5 = r0->field_2f
    //     0xb214ec: ldur            w5, [x0, #0x2f]
    // 0xb214f0: DecompressPointer r5
    //     0xb214f0: add             x5, x5, HEAP, lsl #32
    // 0xb214f4: LoadField: r6 = r1->field_53
    //     0xb214f4: ldur            w6, [x1, #0x53]
    // 0xb214f8: DecompressPointer r6
    //     0xb214f8: add             x6, x6, HEAP, lsl #32
    // 0xb214fc: cmp             w6, NULL
    // 0xb21500: b.ne            #0xb2150c
    // 0xb21504: r6 = Instance_BoxConstraints
    //     0xb21504: add             x6, PP, #0x40, lsl #12  ; [pp+0x400e0] Obj!BoxConstraints@b353e1
    //     0xb21508: ldr             x6, [x6, #0xe0]
    // 0xb2150c: stp             x6, x5, [SP, #-0x10]!
    // 0xb21510: r0 = effectiveConstraints()
    //     0xb21510: bl              #0x84bb78  ; [package:flutter/src/material/theme_data.dart] VisualDensity::effectiveConstraints
    // 0xb21514: add             SP, SP, #0x10
    // 0xb21518: mov             x1, x0
    // 0xb2151c: ldr             x0, [fp, #0x18]
    // 0xb21520: stur            x1, [fp, #-0x18]
    // 0xb21524: LoadField: r2 = r0->field_b
    //     0xb21524: ldur            w2, [x0, #0xb]
    // 0xb21528: DecompressPointer r2
    //     0xb21528: add             x2, x2, HEAP, lsl #32
    // 0xb2152c: cmp             w2, NULL
    // 0xb21530: b.ne            #0xb21554
    // 0xb21534: ldr             x16, [fp, #0x10]
    // 0xb21538: SaveReg r16
    //     0xb21538: str             x16, [SP, #-8]!
    // 0xb2153c: r0 = of()
    //     0xb2153c: bl              #0xb21a30  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xb21540: add             SP, SP, #8
    // 0xb21544: LoadField: r1 = r0->field_7
    //     0xb21544: ldur            w1, [x0, #7]
    // 0xb21548: DecompressPointer r1
    //     0xb21548: add             x1, x1, HEAP, lsl #32
    // 0xb2154c: mov             x0, x1
    // 0xb21550: b               #0xb21558
    // 0xb21554: mov             x0, x2
    // 0xb21558: cmp             w0, NULL
    // 0xb2155c: b.ne            #0xb21568
    // 0xb21560: d0 = 24.000000
    //     0xb21560: fmov            d0, #24.00000000
    // 0xb21564: b               #0xb2156c
    // 0xb21568: LoadField: d0 = r0->field_7
    //     0xb21568: ldur            d0, [x0, #7]
    // 0xb2156c: ldr             x0, [fp, #0x18]
    // 0xb21570: stur            d0, [fp, #-0x58]
    // 0xb21574: LoadField: r1 = r0->field_13
    //     0xb21574: ldur            w1, [x0, #0x13]
    // 0xb21578: DecompressPointer r1
    //     0xb21578: add             x1, x1, HEAP, lsl #32
    // 0xb2157c: cmp             w1, NULL
    // 0xb21580: b.ne            #0xb21590
    // 0xb21584: r3 = Instance_EdgeInsets
    //     0xb21584: add             x3, PP, #0x33, lsl #12  ; [pp+0x33980] Obj!EdgeInsets@b35b11
    //     0xb21588: ldr             x3, [x3, #0x980]
    // 0xb2158c: b               #0xb21594
    // 0xb21590: mov             x3, x1
    // 0xb21594: ldur            x2, [fp, #-8]
    // 0xb21598: ldur            x1, [fp, #-0x18]
    // 0xb2159c: stur            x3, [fp, #-0x30]
    // 0xb215a0: r4 = inline_Allocate_Double()
    //     0xb215a0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xb215a4: add             x4, x4, #0x10
    //     0xb215a8: cmp             x5, x4
    //     0xb215ac: b.ls            #0xb219a8
    //     0xb215b0: str             x4, [THR, #0x60]  ; THR::top
    //     0xb215b4: sub             x4, x4, #0xf
    //     0xb215b8: mov             x5, #0xd108
    //     0xb215bc: movk            x5, #3, lsl #16
    //     0xb215c0: stur            x5, [x4, #-1]
    // 0xb215c4: StoreField: r4->field_7 = d0
    //     0xb215c4: stur            d0, [x4, #7]
    // 0xb215c8: stur            x4, [fp, #-0x28]
    // 0xb215cc: r0 = IconThemeData()
    //     0xb215cc: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0xb215d0: mov             x1, x0
    // 0xb215d4: ldur            x0, [fp, #-0x28]
    // 0xb215d8: StoreField: r1->field_7 = r0
    //     0xb215d8: stur            w0, [x1, #7]
    // 0xb215dc: ldur            x2, [fp, #-8]
    // 0xb215e0: StoreField: r1->field_1b = r2
    //     0xb215e0: stur            w2, [x1, #0x1b]
    // 0xb215e4: ldr             x2, [fp, #0x18]
    // 0xb215e8: LoadField: r3 = r2->field_1f
    //     0xb215e8: ldur            w3, [x2, #0x1f]
    // 0xb215ec: DecompressPointer r3
    //     0xb215ec: add             x3, x3, HEAP, lsl #32
    // 0xb215f0: stp             x1, x3, [SP, #-0x10]!
    // 0xb215f4: r0 = merge()
    //     0xb215f4: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0xb215f8: add             SP, SP, #0x10
    // 0xb215fc: stur            x0, [fp, #-8]
    // 0xb21600: r0 = Align()
    //     0xb21600: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0xb21604: mov             x1, x0
    // 0xb21608: r0 = Instance_Alignment
    //     0xb21608: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb2160c: ldr             x0, [x0, #0xc70]
    // 0xb21610: stur            x1, [fp, #-0x38]
    // 0xb21614: StoreField: r1->field_f = r0
    //     0xb21614: stur            w0, [x1, #0xf]
    // 0xb21618: ldur            x0, [fp, #-8]
    // 0xb2161c: StoreField: r1->field_b = r0
    //     0xb2161c: stur            w0, [x1, #0xb]
    // 0xb21620: r0 = SizedBox()
    //     0xb21620: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb21624: mov             x1, x0
    // 0xb21628: ldur            x0, [fp, #-0x28]
    // 0xb2162c: stur            x1, [fp, #-8]
    // 0xb21630: StoreField: r1->field_f = r0
    //     0xb21630: stur            w0, [x1, #0xf]
    // 0xb21634: StoreField: r1->field_13 = r0
    //     0xb21634: stur            w0, [x1, #0x13]
    // 0xb21638: ldur            x0, [fp, #-0x38]
    // 0xb2163c: StoreField: r1->field_b = r0
    //     0xb2163c: stur            w0, [x1, #0xb]
    // 0xb21640: r0 = Padding()
    //     0xb21640: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb21644: mov             x1, x0
    // 0xb21648: ldur            x0, [fp, #-0x30]
    // 0xb2164c: stur            x1, [fp, #-0x28]
    // 0xb21650: StoreField: r1->field_f = r0
    //     0xb21650: stur            w0, [x1, #0xf]
    // 0xb21654: ldur            x2, [fp, #-8]
    // 0xb21658: StoreField: r1->field_b = r2
    //     0xb21658: stur            w2, [x1, #0xb]
    // 0xb2165c: r0 = ConstrainedBox()
    //     0xb2165c: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xb21660: mov             x1, x0
    // 0xb21664: ldur            x0, [fp, #-0x18]
    // 0xb21668: stur            x1, [fp, #-0x38]
    // 0xb2166c: StoreField: r1->field_f = r0
    //     0xb2166c: stur            w0, [x1, #0xf]
    // 0xb21670: ldur            x0, [fp, #-0x28]
    // 0xb21674: StoreField: r1->field_b = r0
    //     0xb21674: stur            w0, [x1, #0xb]
    // 0xb21678: ldr             x0, [fp, #0x18]
    // 0xb2167c: LoadField: r2 = r0->field_4b
    //     0xb2167c: ldur            w2, [x0, #0x4b]
    // 0xb21680: DecompressPointer r2
    //     0xb21680: add             x2, x2, HEAP, lsl #32
    // 0xb21684: stur            x2, [fp, #-8]
    // 0xb21688: cmp             w2, NULL
    // 0xb2168c: b.eq            #0xb216ac
    // 0xb21690: r0 = Tooltip()
    //     0xb21690: bl              #0xb21ef0  ; AllocateTooltipStub -> Tooltip (size=0x50)
    // 0xb21694: mov             x1, x0
    // 0xb21698: ldur            x0, [fp, #-8]
    // 0xb2169c: StoreField: r1->field_b = r0
    //     0xb2169c: stur            w0, [x1, #0xb]
    // 0xb216a0: ldur            x0, [fp, #-0x38]
    // 0xb216a4: StoreField: r1->field_2b = r0
    //     0xb216a4: stur            w0, [x1, #0x2b]
    // 0xb216a8: b               #0xb216b4
    // 0xb216ac: mov             x0, x1
    // 0xb216b0: mov             x1, x0
    // 0xb216b4: ldur            x0, [fp, #-0x10]
    // 0xb216b8: stur            x1, [fp, #-0x50]
    // 0xb216bc: cmp             w0, NULL
    // 0xb216c0: r16 = true
    //     0xb216c0: add             x16, NULL, #0x20  ; true
    // 0xb216c4: r17 = false
    //     0xb216c4: add             x17, NULL, #0x30  ; false
    // 0xb216c8: csel            x2, x16, x17, ne
    // 0xb216cc: stur            x2, [fp, #-0x48]
    // 0xb216d0: cmp             w0, NULL
    // 0xb216d4: b.ne            #0xb216e0
    // 0xb216d8: r5 = Instance_SystemMouseCursor
    //     0xb216d8: ldr             x5, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xb216dc: b               #0xb216e8
    // 0xb216e0: r5 = Instance_SystemMouseCursor
    //     0xb216e0: add             x5, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0xb216e4: ldr             x5, [x5, #0xea8]
    // 0xb216e8: ldr             x3, [fp, #0x18]
    // 0xb216ec: ldur            x4, [fp, #-0x20]
    // 0xb216f0: stur            x5, [fp, #-0x40]
    // 0xb216f4: LoadField: r6 = r4->field_4f
    //     0xb216f4: ldur            w6, [x4, #0x4f]
    // 0xb216f8: DecompressPointer r6
    //     0xb216f8: add             x6, x6, HEAP, lsl #32
    // 0xb216fc: stur            x6, [fp, #-0x38]
    // 0xb21700: LoadField: r7 = r4->field_5b
    //     0xb21700: ldur            w7, [x4, #0x5b]
    // 0xb21704: DecompressPointer r7
    //     0xb21704: add             x7, x7, HEAP, lsl #32
    // 0xb21708: stur            x7, [fp, #-0x28]
    // 0xb2170c: LoadField: r8 = r3->field_33
    //     0xb2170c: ldur            w8, [x3, #0x33]
    // 0xb21710: DecompressPointer r8
    //     0xb21710: add             x8, x8, HEAP, lsl #32
    // 0xb21714: cmp             w8, NULL
    // 0xb21718: b.ne            #0xb21724
    // 0xb2171c: LoadField: r8 = r4->field_53
    //     0xb2171c: ldur            w8, [x4, #0x53]
    // 0xb21720: DecompressPointer r8
    //     0xb21720: add             x8, x8, HEAP, lsl #32
    // 0xb21724: stur            x8, [fp, #-0x18]
    // 0xb21728: LoadField: r9 = r3->field_2f
    //     0xb21728: ldur            w9, [x3, #0x2f]
    // 0xb2172c: DecompressPointer r9
    //     0xb2172c: add             x9, x9, HEAP, lsl #32
    // 0xb21730: cmp             w9, NULL
    // 0xb21734: b.ne            #0xb21748
    // 0xb21738: LoadField: r3 = r4->field_7f
    //     0xb21738: ldur            w3, [x4, #0x7f]
    // 0xb2173c: DecompressPointer r3
    //     0xb2173c: add             x3, x3, HEAP, lsl #32
    // 0xb21740: mov             x4, x3
    // 0xb21744: b               #0xb2174c
    // 0xb21748: mov             x4, x9
    // 0xb2174c: ldur            x3, [fp, #-0x30]
    // 0xb21750: d0 = 0.000000
    //     0xb21750: eor             v0.16b, v0.16b, v0.16b
    // 0xb21754: stur            x4, [fp, #-8]
    // 0xb21758: LoadField: d1 = r3->field_7
    //     0xb21758: ldur            d1, [x3, #7]
    // 0xb2175c: LoadField: d2 = r3->field_17
    //     0xb2175c: ldur            d2, [x3, #0x17]
    // 0xb21760: fadd            d3, d1, d2
    // 0xb21764: fadd            d1, d3, d0
    // 0xb21768: fadd            d2, d1, d0
    // 0xb2176c: stur            d2, [fp, #-0x68]
    // 0xb21770: LoadField: d1 = r3->field_f
    //     0xb21770: ldur            d1, [x3, #0xf]
    // 0xb21774: LoadField: d3 = r3->field_1f
    //     0xb21774: ldur            d3, [x3, #0x1f]
    // 0xb21778: fadd            d4, d1, d3
    // 0xb2177c: stur            d4, [fp, #-0x60]
    // 0xb21780: fcmp            d2, d4
    // 0xb21784: b.vs            #0xb21794
    // 0xb21788: b.le            #0xb21794
    // 0xb2178c: mov             v3.16b, v4.16b
    // 0xb21790: b               #0xb21834
    // 0xb21794: fcmp            d2, d4
    // 0xb21798: b.vs            #0xb217a8
    // 0xb2179c: b.ge            #0xb217a8
    // 0xb217a0: mov             v3.16b, v2.16b
    // 0xb217a4: b               #0xb21834
    // 0xb217a8: fcmp            d2, d0
    // 0xb217ac: b.vs            #0xb217b4
    // 0xb217b0: b.eq            #0xb217bc
    // 0xb217b4: r3 = false
    //     0xb217b4: add             x3, NULL, #0x30  ; false
    // 0xb217b8: b               #0xb217c0
    // 0xb217bc: r3 = true
    //     0xb217bc: add             x3, NULL, #0x20  ; true
    // 0xb217c0: tbnz            w3, #4, #0xb217d8
    // 0xb217c4: fadd            d1, d2, d4
    // 0xb217c8: fmul            d3, d1, d2
    // 0xb217cc: fmul            d1, d3, d4
    // 0xb217d0: mov             v3.16b, v1.16b
    // 0xb217d4: b               #0xb21834
    // 0xb217d8: tbnz            w3, #4, #0xb2181c
    // 0xb217dc: r3 = inline_Allocate_Double()
    //     0xb217dc: ldp             x3, x9, [THR, #0x60]  ; THR::top
    //     0xb217e0: add             x3, x3, #0x10
    //     0xb217e4: cmp             x9, x3
    //     0xb217e8: b.ls            #0xb219cc
    //     0xb217ec: str             x3, [THR, #0x60]  ; THR::top
    //     0xb217f0: sub             x3, x3, #0xf
    //     0xb217f4: mov             x9, #0xd108
    //     0xb217f8: movk            x9, #3, lsl #16
    //     0xb217fc: stur            x9, [x3, #-1]
    // 0xb21800: StoreField: r3->field_7 = d4
    //     0xb21800: stur            d4, [x3, #7]
    // 0xb21804: SaveReg r3
    //     0xb21804: str             x3, [SP, #-8]!
    // 0xb21808: r0 = isNegative()
    //     0xb21808: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xb2180c: add             SP, SP, #8
    // 0xb21810: tbnz            w0, #4, #0xb2181c
    // 0xb21814: ldur            d0, [fp, #-0x60]
    // 0xb21818: b               #0xb21828
    // 0xb2181c: ldur            d0, [fp, #-0x60]
    // 0xb21820: fcmp            d0, d0
    // 0xb21824: b.vc            #0xb21830
    // 0xb21828: mov             v3.16b, v0.16b
    // 0xb2182c: b               #0xb21834
    // 0xb21830: ldur            d3, [fp, #-0x68]
    // 0xb21834: ldur            d0, [fp, #-0x58]
    // 0xb21838: d2 = 0.700000
    //     0xb21838: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c2f0] IMM: double(0.7) from 0x3fe6666666666666
    //     0xb2183c: ldr             d2, [x17, #0x2f0]
    // 0xb21840: d1 = 35.000000
    //     0xb21840: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c3a8] IMM: double(35) from 0x4041800000000000
    //     0xb21844: ldr             d1, [x17, #0x3a8]
    // 0xb21848: fadd            d4, d0, d3
    // 0xb2184c: fmul            d0, d4, d2
    // 0xb21850: fcmp            d1, d0
    // 0xb21854: b.vs            #0xb21868
    // 0xb21858: b.le            #0xb21868
    // 0xb2185c: d0 = 35.000000
    //     0xb2185c: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c3a8] IMM: double(35) from 0x4041800000000000
    //     0xb21860: ldr             d0, [x17, #0x3a8]
    // 0xb21864: b               #0xb218a0
    // 0xb21868: fcmp            d1, d0
    // 0xb2186c: b.vs            #0xb21874
    // 0xb21870: b.lt            #0xb218a0
    // 0xb21874: d2 = 0.000000
    //     0xb21874: eor             v2.16b, v2.16b, v2.16b
    // 0xb21878: fcmp            d1, d2
    // 0xb2187c: b.vs            #0xb21890
    // 0xb21880: b.ne            #0xb21890
    // 0xb21884: fadd            d2, d1, d0
    // 0xb21888: mov             v0.16b, v2.16b
    // 0xb2188c: b               #0xb218a0
    // 0xb21890: fcmp            d0, d0
    // 0xb21894: b.vs            #0xb218a0
    // 0xb21898: d0 = 35.000000
    //     0xb21898: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c3a8] IMM: double(35) from 0x4041800000000000
    //     0xb2189c: ldr             d0, [x17, #0x3a8]
    // 0xb218a0: ldur            x0, [fp, #-0x10]
    // 0xb218a4: ldur            x1, [fp, #-0x50]
    // 0xb218a8: ldur            x2, [fp, #-0x48]
    // 0xb218ac: ldur            x6, [fp, #-0x18]
    // 0xb218b0: ldur            x7, [fp, #-8]
    // 0xb218b4: ldur            x5, [fp, #-0x28]
    // 0xb218b8: ldur            x4, [fp, #-0x38]
    // 0xb218bc: ldur            x3, [fp, #-0x40]
    // 0xb218c0: stur            d0, [fp, #-0x58]
    // 0xb218c4: r0 = InkResponse()
    //     0xb218c4: bl              #0xb21a24  ; AllocateInkResponseStub -> InkResponse (size=0x7c)
    // 0xb218c8: mov             x1, x0
    // 0xb218cc: ldur            x0, [fp, #-0x50]
    // 0xb218d0: stur            x1, [fp, #-0x20]
    // 0xb218d4: StoreField: r1->field_b = r0
    //     0xb218d4: stur            w0, [x1, #0xb]
    // 0xb218d8: ldur            x0, [fp, #-0x10]
    // 0xb218dc: StoreField: r1->field_f = r0
    //     0xb218dc: stur            w0, [x1, #0xf]
    // 0xb218e0: ldur            x0, [fp, #-0x40]
    // 0xb218e4: StoreField: r1->field_2f = r0
    //     0xb218e4: stur            w0, [x1, #0x2f]
    // 0xb218e8: r0 = false
    //     0xb218e8: add             x0, NULL, #0x30  ; false
    // 0xb218ec: StoreField: r1->field_33 = r0
    //     0xb218ec: stur            w0, [x1, #0x33]
    // 0xb218f0: r2 = Instance_BoxShape
    //     0xb218f0: add             x2, PP, #0x32, lsl #12  ; [pp+0x32f70] Obj!BoxShape@b64eb1
    //     0xb218f4: ldr             x2, [x2, #0xf70]
    // 0xb218f8: StoreField: r1->field_37 = r2
    //     0xb218f8: stur            w2, [x1, #0x37]
    // 0xb218fc: ldur            d0, [fp, #-0x58]
    // 0xb21900: r2 = inline_Allocate_Double()
    //     0xb21900: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xb21904: add             x2, x2, #0x10
    //     0xb21908: cmp             x3, x2
    //     0xb2190c: b.ls            #0xb21a08
    //     0xb21910: str             x2, [THR, #0x60]  ; THR::top
    //     0xb21914: sub             x2, x2, #0xf
    //     0xb21918: mov             x3, #0xd108
    //     0xb2191c: movk            x3, #3, lsl #16
    //     0xb21920: stur            x3, [x2, #-1]
    // 0xb21924: StoreField: r2->field_7 = d0
    //     0xb21924: stur            d0, [x2, #7]
    // 0xb21928: StoreField: r1->field_3b = r2
    //     0xb21928: stur            w2, [x1, #0x3b]
    // 0xb2192c: ldur            x2, [fp, #-0x38]
    // 0xb21930: StoreField: r1->field_47 = r2
    //     0xb21930: stur            w2, [x1, #0x47]
    // 0xb21934: ldur            x2, [fp, #-0x28]
    // 0xb21938: StoreField: r1->field_4b = r2
    //     0xb21938: stur            w2, [x1, #0x4b]
    // 0xb2193c: ldur            x2, [fp, #-0x18]
    // 0xb21940: StoreField: r1->field_4f = r2
    //     0xb21940: stur            w2, [x1, #0x4f]
    // 0xb21944: ldur            x2, [fp, #-8]
    // 0xb21948: StoreField: r1->field_57 = r2
    //     0xb21948: stur            w2, [x1, #0x57]
    // 0xb2194c: r2 = true
    //     0xb2194c: add             x2, NULL, #0x20  ; true
    // 0xb21950: StoreField: r1->field_5f = r2
    //     0xb21950: stur            w2, [x1, #0x5f]
    // 0xb21954: StoreField: r1->field_63 = r0
    //     0xb21954: stur            w0, [x1, #0x63]
    // 0xb21958: ldur            x2, [fp, #-0x48]
    // 0xb2195c: StoreField: r1->field_73 = r2
    //     0xb2195c: stur            w2, [x1, #0x73]
    // 0xb21960: StoreField: r1->field_6b = r0
    //     0xb21960: stur            w0, [x1, #0x6b]
    // 0xb21964: r0 = Semantics()
    //     0xb21964: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0xb21968: stur            x0, [fp, #-8]
    // 0xb2196c: r16 = true
    //     0xb2196c: add             x16, NULL, #0x20  ; true
    // 0xb21970: stp             x16, x0, [SP, #-0x10]!
    // 0xb21974: ldur            x16, [fp, #-0x48]
    // 0xb21978: ldur            lr, [fp, #-0x20]
    // 0xb2197c: stp             lr, x16, [SP, #-0x10]!
    // 0xb21980: r4 = const [0, 0x4, 0x4, 0x1, button, 0x1, child, 0x3, enabled, 0x2, null]
    //     0xb21980: add             x4, PP, #0x40, lsl #12  ; [pp+0x40188] List(11) [0, 0x4, 0x4, 0x1, "button", 0x1, "child", 0x3, "enabled", 0x2, Null]
    //     0xb21984: ldr             x4, [x4, #0x188]
    // 0xb21988: r0 = Semantics()
    //     0xb21988: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0xb2198c: add             SP, SP, #0x20
    // 0xb21990: ldur            x0, [fp, #-8]
    // 0xb21994: LeaveFrame
    //     0xb21994: mov             SP, fp
    //     0xb21998: ldp             fp, lr, [SP], #0x10
    // 0xb2199c: ret
    //     0xb2199c: ret             
    // 0xb219a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb219a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb219a4: b               #0xb21324
    // 0xb219a8: SaveReg d0
    //     0xb219a8: str             q0, [SP, #-0x10]!
    // 0xb219ac: stp             x2, x3, [SP, #-0x10]!
    // 0xb219b0: stp             x0, x1, [SP, #-0x10]!
    // 0xb219b4: r0 = AllocateDouble()
    //     0xb219b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb219b8: mov             x4, x0
    // 0xb219bc: ldp             x0, x1, [SP], #0x10
    // 0xb219c0: ldp             x2, x3, [SP], #0x10
    // 0xb219c4: RestoreReg d0
    //     0xb219c4: ldr             q0, [SP], #0x10
    // 0xb219c8: b               #0xb215c4
    // 0xb219cc: stp             q2, q4, [SP, #-0x20]!
    // 0xb219d0: SaveReg d0
    //     0xb219d0: str             q0, [SP, #-0x10]!
    // 0xb219d4: stp             x7, x8, [SP, #-0x10]!
    // 0xb219d8: stp             x5, x6, [SP, #-0x10]!
    // 0xb219dc: stp             x2, x4, [SP, #-0x10]!
    // 0xb219e0: stp             x0, x1, [SP, #-0x10]!
    // 0xb219e4: r0 = AllocateDouble()
    //     0xb219e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb219e8: mov             x3, x0
    // 0xb219ec: ldp             x0, x1, [SP], #0x10
    // 0xb219f0: ldp             x2, x4, [SP], #0x10
    // 0xb219f4: ldp             x5, x6, [SP], #0x10
    // 0xb219f8: ldp             x7, x8, [SP], #0x10
    // 0xb219fc: RestoreReg d0
    //     0xb219fc: ldr             q0, [SP], #0x10
    // 0xb21a00: ldp             q2, q4, [SP], #0x20
    // 0xb21a04: b               #0xb21800
    // 0xb21a08: SaveReg d0
    //     0xb21a08: str             q0, [SP, #-0x10]!
    // 0xb21a0c: stp             x0, x1, [SP, #-0x10]!
    // 0xb21a10: r0 = AllocateDouble()
    //     0xb21a10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb21a14: mov             x2, x0
    // 0xb21a18: ldp             x0, x1, [SP], #0x10
    // 0xb21a1c: RestoreReg d0
    //     0xb21a1c: ldr             q0, [SP], #0x10
    // 0xb21a20: b               #0xb21924
  }
  static _ styleFrom(/* No info */) {
    // ** addr: 0xb21efc, size: 0x2dc
    // 0xb21efc: EnterFrame
    //     0xb21efc: stp             fp, lr, [SP, #-0x10]!
    //     0xb21f00: mov             fp, SP
    // 0xb21f04: AllocStack(0x38)
    //     0xb21f04: sub             SP, SP, #0x38
    // 0xb21f08: SetupParameters(dynamic _ /* r3, fp-0x30 */, dynamic _ /* r4, fp-0x28 */, {dynamic highlightColor = Null /* r5, fp-0x20 */, dynamic maximumSize = Null /* r6, fp-0x18 */, dynamic minimumSize = Null /* r7, fp-0x10 */, dynamic padding = Null /* r0, fp-0x8 */})
    //     0xb21f08: mov             x0, x4
    //     0xb21f0c: ldur            w1, [x0, #0x13]
    //     0xb21f10: add             x1, x1, HEAP, lsl #32
    //     0xb21f14: sub             x2, x1, #4
    //     0xb21f18: add             x3, fp, w2, sxtw #2
    //     0xb21f1c: ldr             x3, [x3, #0x18]
    //     0xb21f20: stur            x3, [fp, #-0x30]
    //     0xb21f24: add             x4, fp, w2, sxtw #2
    //     0xb21f28: ldr             x4, [x4, #0x10]
    //     0xb21f2c: stur            x4, [fp, #-0x28]
    //     0xb21f30: ldur            w2, [x0, #0x1f]
    //     0xb21f34: add             x2, x2, HEAP, lsl #32
    //     0xb21f38: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd58] "highlightColor"
    //     0xb21f3c: ldr             x16, [x16, #0xd58]
    //     0xb21f40: cmp             w2, w16
    //     0xb21f44: b.ne            #0xb21f68
    //     0xb21f48: ldur            w2, [x0, #0x23]
    //     0xb21f4c: add             x2, x2, HEAP, lsl #32
    //     0xb21f50: sub             w5, w1, w2
    //     0xb21f54: add             x2, fp, w5, sxtw #2
    //     0xb21f58: ldr             x2, [x2, #8]
    //     0xb21f5c: mov             x5, x2
    //     0xb21f60: mov             x2, #1
    //     0xb21f64: b               #0xb21f70
    //     0xb21f68: mov             x5, NULL
    //     0xb21f6c: mov             x2, #0
    //     0xb21f70: stur            x5, [fp, #-0x20]
    //     0xb21f74: lsl             x6, x2, #1
    //     0xb21f78: lsl             w7, w6, #1
    //     0xb21f7c: add             w8, w7, #8
    //     0xb21f80: add             x16, x0, w8, sxtw #1
    //     0xb21f84: ldur            w9, [x16, #0xf]
    //     0xb21f88: add             x9, x9, HEAP, lsl #32
    //     0xb21f8c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26890] "maximumSize"
    //     0xb21f90: ldr             x16, [x16, #0x890]
    //     0xb21f94: cmp             w9, w16
    //     0xb21f98: b.ne            #0xb21fcc
    //     0xb21f9c: add             w2, w7, #0xa
    //     0xb21fa0: add             x16, x0, w2, sxtw #1
    //     0xb21fa4: ldur            w7, [x16, #0xf]
    //     0xb21fa8: add             x7, x7, HEAP, lsl #32
    //     0xb21fac: sub             w2, w1, w7
    //     0xb21fb0: add             x7, fp, w2, sxtw #2
    //     0xb21fb4: ldr             x7, [x7, #8]
    //     0xb21fb8: add             w2, w6, #2
    //     0xb21fbc: sbfx            x6, x2, #1, #0x1f
    //     0xb21fc0: mov             x2, x6
    //     0xb21fc4: mov             x6, x7
    //     0xb21fc8: b               #0xb21fd0
    //     0xb21fcc: mov             x6, NULL
    //     0xb21fd0: stur            x6, [fp, #-0x18]
    //     0xb21fd4: lsl             x7, x2, #1
    //     0xb21fd8: lsl             w8, w7, #1
    //     0xb21fdc: add             w9, w8, #8
    //     0xb21fe0: add             x16, x0, w9, sxtw #1
    //     0xb21fe4: ldur            w10, [x16, #0xf]
    //     0xb21fe8: add             x10, x10, HEAP, lsl #32
    //     0xb21fec: add             x16, PP, #0x26, lsl #12  ; [pp+0x26898] "minimumSize"
    //     0xb21ff0: ldr             x16, [x16, #0x898]
    //     0xb21ff4: cmp             w10, w16
    //     0xb21ff8: b.ne            #0xb2202c
    //     0xb21ffc: add             w2, w8, #0xa
    //     0xb22000: add             x16, x0, w2, sxtw #1
    //     0xb22004: ldur            w8, [x16, #0xf]
    //     0xb22008: add             x8, x8, HEAP, lsl #32
    //     0xb2200c: sub             w2, w1, w8
    //     0xb22010: add             x8, fp, w2, sxtw #2
    //     0xb22014: ldr             x8, [x8, #8]
    //     0xb22018: add             w2, w7, #2
    //     0xb2201c: sbfx            x7, x2, #1, #0x1f
    //     0xb22020: mov             x2, x7
    //     0xb22024: mov             x7, x8
    //     0xb22028: b               #0xb22030
    //     0xb2202c: mov             x7, NULL
    //     0xb22030: stur            x7, [fp, #-0x10]
    //     0xb22034: lsl             x8, x2, #1
    //     0xb22038: lsl             w2, w8, #1
    //     0xb2203c: add             w8, w2, #8
    //     0xb22040: add             x16, x0, w8, sxtw #1
    //     0xb22044: ldur            w9, [x16, #0xf]
    //     0xb22048: add             x9, x9, HEAP, lsl #32
    //     0xb2204c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb18] "padding"
    //     0xb22050: ldr             x16, [x16, #0xb18]
    //     0xb22054: cmp             w9, w16
    //     0xb22058: b.ne            #0xb22080
    //     0xb2205c: add             w8, w2, #0xa
    //     0xb22060: add             x16, x0, w8, sxtw #1
    //     0xb22064: ldur            w2, [x16, #0xf]
    //     0xb22068: add             x2, x2, HEAP, lsl #32
    //     0xb2206c: sub             w0, w1, w2
    //     0xb22070: add             x1, fp, w0, sxtw #2
    //     0xb22074: ldr             x1, [x1, #8]
    //     0xb22078: mov             x0, x1
    //     0xb2207c: b               #0xb22084
    //     0xb22080: mov             x0, NULL
    //     0xb22084: stur            x0, [fp, #-8]
    // 0xb22088: CheckStackOverflow
    //     0xb22088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb2208c: cmp             SP, x16
    //     0xb22090: b.ls            #0xb221d0
    // 0xb22094: cmp             w3, NULL
    // 0xb22098: b.ne            #0xb220a8
    // 0xb2209c: mov             x0, x3
    // 0xb220a0: r2 = Null
    //     0xb220a0: mov             x2, NULL
    // 0xb220a4: b               #0xb220c4
    // 0xb220a8: r1 = <Color?>
    //     0xb220a8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb220ac: ldr             x1, [x1, #0xf68]
    // 0xb220b0: r0 = _IconButtonDefaultForeground()
    //     0xb220b0: bl              #0xb221e4  ; Allocate_IconButtonDefaultForegroundStub -> _IconButtonDefaultForeground (size=0x14)
    // 0xb220b4: mov             x1, x0
    // 0xb220b8: ldur            x0, [fp, #-0x30]
    // 0xb220bc: StoreField: r1->field_b = r0
    //     0xb220bc: stur            w0, [x1, #0xb]
    // 0xb220c0: mov             x2, x1
    // 0xb220c4: stur            x2, [fp, #-0x38]
    // 0xb220c8: cmp             w0, NULL
    // 0xb220cc: b.ne            #0xb220e8
    // 0xb220d0: ldur            x3, [fp, #-0x20]
    // 0xb220d4: cmp             w3, NULL
    // 0xb220d8: b.ne            #0xb220ec
    // 0xb220dc: mov             x0, x2
    // 0xb220e0: r1 = Null
    //     0xb220e0: mov             x1, NULL
    // 0xb220e4: b               #0xb22110
    // 0xb220e8: ldur            x3, [fp, #-0x20]
    // 0xb220ec: r1 = <Color?>
    //     0xb220ec: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xb220f0: ldr             x1, [x1, #0xf68]
    // 0xb220f4: r0 = _IconButtonDefaultOverlay()
    //     0xb220f4: bl              #0xb221d8  ; Allocate_IconButtonDefaultOverlayStub -> _IconButtonDefaultOverlay (size=0x1c)
    // 0xb220f8: mov             x1, x0
    // 0xb220fc: ldur            x0, [fp, #-0x30]
    // 0xb22100: StoreField: r1->field_b = r0
    //     0xb22100: stur            w0, [x1, #0xb]
    // 0xb22104: ldur            x0, [fp, #-0x20]
    // 0xb22108: StoreField: r1->field_17 = r0
    //     0xb22108: stur            w0, [x1, #0x17]
    // 0xb2210c: ldur            x0, [fp, #-0x38]
    // 0xb22110: stur            x1, [fp, #-0x20]
    // 0xb22114: r16 = <EdgeInsetsGeometry>
    //     0xb22114: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xb22118: ldr             x16, [x16, #0x8c8]
    // 0xb2211c: ldur            lr, [fp, #-8]
    // 0xb22120: stp             lr, x16, [SP, #-0x10]!
    // 0xb22124: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb22124: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb22128: r0 = allOrNull()
    //     0xb22128: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb2212c: add             SP, SP, #0x10
    // 0xb22130: stur            x0, [fp, #-8]
    // 0xb22134: r16 = <Size>
    //     0xb22134: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0xb22138: ldr             x16, [x16, #0x8d0]
    // 0xb2213c: ldur            lr, [fp, #-0x10]
    // 0xb22140: stp             lr, x16, [SP, #-0x10]!
    // 0xb22144: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb22144: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb22148: r0 = allOrNull()
    //     0xb22148: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb2214c: add             SP, SP, #0x10
    // 0xb22150: stur            x0, [fp, #-0x10]
    // 0xb22154: r16 = <Size>
    //     0xb22154: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0xb22158: ldr             x16, [x16, #0x8d0]
    // 0xb2215c: ldur            lr, [fp, #-0x18]
    // 0xb22160: stp             lr, x16, [SP, #-0x10]!
    // 0xb22164: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb22164: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb22168: r0 = allOrNull()
    //     0xb22168: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb2216c: add             SP, SP, #0x10
    // 0xb22170: stur            x0, [fp, #-0x18]
    // 0xb22174: r16 = <double>
    //     0xb22174: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xb22178: ldur            lr, [fp, #-0x28]
    // 0xb2217c: stp             lr, x16, [SP, #-0x10]!
    // 0xb22180: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb22180: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb22184: r0 = allOrNull()
    //     0xb22184: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0xb22188: add             SP, SP, #0x10
    // 0xb2218c: stur            x0, [fp, #-0x28]
    // 0xb22190: r0 = ButtonStyle()
    //     0xb22190: bl              #0x9173f0  ; AllocateButtonStyleStub -> ButtonStyle (size=0x60)
    // 0xb22194: ldur            x1, [fp, #-0x38]
    // 0xb22198: StoreField: r0->field_f = r1
    //     0xb22198: stur            w1, [x0, #0xf]
    // 0xb2219c: ldur            x1, [fp, #-0x20]
    // 0xb221a0: StoreField: r0->field_13 = r1
    //     0xb221a0: stur            w1, [x0, #0x13]
    // 0xb221a4: ldur            x1, [fp, #-8]
    // 0xb221a8: StoreField: r0->field_23 = r1
    //     0xb221a8: stur            w1, [x0, #0x23]
    // 0xb221ac: ldur            x1, [fp, #-0x10]
    // 0xb221b0: StoreField: r0->field_27 = r1
    //     0xb221b0: stur            w1, [x0, #0x27]
    // 0xb221b4: ldur            x1, [fp, #-0x18]
    // 0xb221b8: StoreField: r0->field_2f = r1
    //     0xb221b8: stur            w1, [x0, #0x2f]
    // 0xb221bc: ldur            x1, [fp, #-0x28]
    // 0xb221c0: StoreField: r0->field_37 = r1
    //     0xb221c0: stur            w1, [x0, #0x37]
    // 0xb221c4: LeaveFrame
    //     0xb221c4: mov             SP, fp
    //     0xb221c8: ldp             fp, lr, [SP], #0x10
    // 0xb221cc: ret
    //     0xb221cc: ret             
    // 0xb221d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb221d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb221d4: b               #0xb22094
  }
}

// class id: 4154, size: 0x24, field offset: 0xc
//   const constructor, 
class _SelectableIconButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa4064c, size: 0x28
    // 0xa4064c: EnterFrame
    //     0xa4064c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40650: mov             fp, SP
    // 0xa40654: r1 = <_SelectableIconButton>
    //     0xa40654: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b888] TypeArguments: <_SelectableIconButton>
    //     0xa40658: ldr             x1, [x1, #0x888]
    // 0xa4065c: r0 = _SelectableIconButtonState()
    //     0xa4065c: bl              #0xa40674  ; Allocate_SelectableIconButtonStateStub -> _SelectableIconButtonState (size=0x18)
    // 0xa40660: r1 = Sentinel
    //     0xa40660: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40664: StoreField: r0->field_13 = r1
    //     0xa40664: stur            w1, [x0, #0x13]
    // 0xa40668: LeaveFrame
    //     0xa40668: mov             SP, fp
    //     0xa4066c: ldp             fp, lr, [SP], #0x10
    // 0xa40670: ret
    //     0xa40670: ret             
  }
}

// class id: 4164, size: 0x34, field offset: 0x34
//   const constructor, 
class _IconButtonM3 extends ButtonStyleButton {

  _ themeStyleOf(/* No info */) {
    // ** addr: 0xc12228, size: 0x198
    // 0xc12228: EnterFrame
    //     0xc12228: stp             fp, lr, [SP, #-0x10]!
    //     0xc1222c: mov             fp, SP
    // 0xc12230: AllocStack(0x20)
    //     0xc12230: sub             SP, SP, #0x20
    // 0xc12234: CheckStackOverflow
    //     0xc12234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12238: cmp             SP, x16
    //     0xc1223c: b.ls            #0xc123b8
    // 0xc12240: ldr             x16, [fp, #0x10]
    // 0xc12244: SaveReg r16
    //     0xc12244: str             x16, [SP, #-8]!
    // 0xc12248: r0 = of()
    //     0xc12248: bl              #0xb21a30  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::of
    // 0xc1224c: add             SP, SP, #8
    // 0xc12250: stur            x0, [fp, #-8]
    // 0xc12254: ldr             x16, [fp, #0x10]
    // 0xc12258: SaveReg r16
    //     0xc12258: str             x16, [SP, #-8]!
    // 0xc1225c: r0 = of()
    //     0xc1225c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc12260: add             SP, SP, #8
    // 0xc12264: LoadField: r1 = r0->field_3f
    //     0xc12264: ldur            w1, [x0, #0x3f]
    // 0xc12268: DecompressPointer r1
    //     0xc12268: add             x1, x1, HEAP, lsl #32
    // 0xc1226c: LoadField: r0 = r1->field_7
    //     0xc1226c: ldur            w0, [x1, #7]
    // 0xc12270: DecompressPointer r0
    //     0xc12270: add             x0, x0, HEAP, lsl #32
    // 0xc12274: ldur            x1, [fp, #-8]
    // 0xc12278: LoadField: r2 = r1->field_1b
    //     0xc12278: ldur            w2, [x1, #0x1b]
    // 0xc1227c: DecompressPointer r2
    //     0xc1227c: add             x2, x2, HEAP, lsl #32
    // 0xc12280: stur            x2, [fp, #-0x10]
    // 0xc12284: r16 = Instance_Brightness
    //     0xc12284: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xc12288: cmp             w0, w16
    // 0xc1228c: b.ne            #0xc122bc
    // 0xc12290: r0 = LoadClassIdInstr(r2)
    //     0xc12290: ldur            x0, [x2, #-1]
    //     0xc12294: ubfx            x0, x0, #0xc, #0x14
    // 0xc12298: r16 = Instance_Color
    //     0xc12298: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xc1229c: ldr             x16, [x16, #0xbe8]
    // 0xc122a0: stp             x16, x2, [SP, #-0x10]!
    // 0xc122a4: mov             lr, x0
    // 0xc122a8: ldr             lr, [x21, lr, lsl #3]
    // 0xc122ac: blr             lr
    // 0xc122b0: add             SP, SP, #0x10
    // 0xc122b4: mov             x1, x0
    // 0xc122b8: b               #0xc122e8
    // 0xc122bc: mov             x1, x2
    // 0xc122c0: r0 = LoadClassIdInstr(r1)
    //     0xc122c0: ldur            x0, [x1, #-1]
    //     0xc122c4: ubfx            x0, x0, #0xc, #0x14
    // 0xc122c8: r16 = Instance_Color
    //     0xc122c8: add             x16, PP, #0x28, lsl #12  ; [pp+0x28da0] Obj!Color@b5d1e1
    //     0xc122cc: ldr             x16, [x16, #0xda0]
    // 0xc122d0: stp             x16, x1, [SP, #-0x10]!
    // 0xc122d4: mov             lr, x0
    // 0xc122d8: ldr             lr, [x21, lr, lsl #3]
    // 0xc122dc: blr             lr
    // 0xc122e0: add             SP, SP, #0x10
    // 0xc122e4: mov             x1, x0
    // 0xc122e8: ldur            x0, [fp, #-8]
    // 0xc122ec: stur            x1, [fp, #-0x20]
    // 0xc122f0: LoadField: r2 = r0->field_7
    //     0xc122f0: ldur            w2, [x0, #7]
    // 0xc122f4: DecompressPointer r2
    //     0xc122f4: add             x2, x2, HEAP, lsl #32
    // 0xc122f8: stur            x2, [fp, #-0x18]
    // 0xc122fc: r0 = LoadClassIdInstr(r2)
    //     0xc122fc: ldur            x0, [x2, #-1]
    //     0xc12300: ubfx            x0, x0, #0xc, #0x14
    // 0xc12304: r16 = 24.000000
    //     0xc12304: add             x16, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc12308: ldr             x16, [x16, #0x360]
    // 0xc1230c: stp             x16, x2, [SP, #-0x10]!
    // 0xc12310: mov             lr, x0
    // 0xc12314: ldr             lr, [x21, lr, lsl #3]
    // 0xc12318: blr             lr
    // 0xc1231c: add             SP, SP, #0x10
    // 0xc12320: mov             x1, x0
    // 0xc12324: ldur            x0, [fp, #-0x20]
    // 0xc12328: tbnz            w0, #4, #0xc12334
    // 0xc1232c: r0 = Null
    //     0xc1232c: mov             x0, NULL
    // 0xc12330: b               #0xc12338
    // 0xc12334: ldur            x0, [fp, #-0x10]
    // 0xc12338: tbnz            w1, #4, #0xc12344
    // 0xc1233c: r1 = Null
    //     0xc1233c: mov             x1, NULL
    // 0xc12340: b               #0xc12348
    // 0xc12344: ldur            x1, [fp, #-0x18]
    // 0xc12348: stp             x1, x0, [SP, #-0x10]!
    // 0xc1234c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc1234c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc12350: r0 = styleFrom()
    //     0xc12350: bl              #0xb21efc  ; [package:flutter/src/material/icon_button.dart] IconButton::styleFrom
    // 0xc12354: add             SP, SP, #0x10
    // 0xc12358: stur            x0, [fp, #-8]
    // 0xc1235c: ldr             x16, [fp, #0x10]
    // 0xc12360: SaveReg r16
    //     0xc12360: str             x16, [SP, #-8]!
    // 0xc12364: r0 = of()
    //     0xc12364: bl              #0xc133e0  ; [package:flutter/src/material/icon_button_theme.dart] IconButtonTheme::of
    // 0xc12368: add             SP, SP, #8
    // 0xc1236c: LoadField: r1 = r0->field_7
    //     0xc1236c: ldur            w1, [x0, #7]
    // 0xc12370: DecompressPointer r1
    //     0xc12370: add             x1, x1, HEAP, lsl #32
    // 0xc12374: cmp             w1, NULL
    // 0xc12378: b.ne            #0xc12384
    // 0xc1237c: r1 = Null
    //     0xc1237c: mov             x1, NULL
    // 0xc12380: b               #0xc12398
    // 0xc12384: ldur            x16, [fp, #-8]
    // 0xc12388: stp             x16, x1, [SP, #-0x10]!
    // 0xc1238c: r0 = merge()
    //     0xc1238c: bl              #0xc123c0  ; [package:flutter/src/material/button_style.dart] ButtonStyle::merge
    // 0xc12390: add             SP, SP, #0x10
    // 0xc12394: mov             x1, x0
    // 0xc12398: cmp             w1, NULL
    // 0xc1239c: b.ne            #0xc123a8
    // 0xc123a0: ldur            x0, [fp, #-8]
    // 0xc123a4: b               #0xc123ac
    // 0xc123a8: mov             x0, x1
    // 0xc123ac: LeaveFrame
    //     0xc123ac: mov             SP, fp
    //     0xc123b0: ldp             fp, lr, [SP], #0x10
    // 0xc123b4: ret
    //     0xc123b4: ret             
    // 0xc123b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc123b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc123bc: b               #0xc12240
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0xc14d60, size: 0x48
    // 0xc14d60: EnterFrame
    //     0xc14d60: stp             fp, lr, [SP, #-0x10]!
    //     0xc14d64: mov             fp, SP
    // 0xc14d68: r0 = _IconButtonDefaultsM3()
    //     0xc14d68: bl              #0xc14da8  ; Allocate_IconButtonDefaultsM3Stub -> _IconButtonDefaultsM3 (size=0x68)
    // 0xc14d6c: r1 = Sentinel
    //     0xc14d6c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc14d70: StoreField: r0->field_63 = r1
    //     0xc14d70: stur            w1, [x0, #0x63]
    // 0xc14d74: ldr             x1, [fp, #0x10]
    // 0xc14d78: StoreField: r0->field_5f = r1
    //     0xc14d78: stur            w1, [x0, #0x5f]
    // 0xc14d7c: r1 = Instance_Duration
    //     0xc14d7c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc14d80: ldr             x1, [x1, #0x9e0]
    // 0xc14d84: StoreField: r0->field_4f = r1
    //     0xc14d84: stur            w1, [x0, #0x4f]
    // 0xc14d88: r1 = true
    //     0xc14d88: add             x1, NULL, #0x20  ; true
    // 0xc14d8c: StoreField: r0->field_53 = r1
    //     0xc14d8c: stur            w1, [x0, #0x53]
    // 0xc14d90: r1 = Instance_Alignment
    //     0xc14d90: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc14d94: ldr             x1, [x1, #0xc70]
    // 0xc14d98: StoreField: r0->field_57 = r1
    //     0xc14d98: stur            w1, [x0, #0x57]
    // 0xc14d9c: LeaveFrame
    //     0xc14d9c: mov             SP, fp
    //     0xc14da0: ldp             fp, lr, [SP], #0x10
    // 0xc14da4: ret
    //     0xc14da4: ret             
  }
}

// lib: , url: package:flutter/src/material/list_tile_theme.dart

// class id: 1049265, size: 0x8
class :: {
}

// class id: 2793, size: 0x44, field offset: 0x8
//   const constructor, 
class ListTileThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb004b8, size: 0xa4
    // 0xb004b8: EnterFrame
    //     0xb004b8: stp             fp, lr, [SP, #-0x10]!
    //     0xb004bc: mov             fp, SP
    // 0xb004c0: CheckStackOverflow
    //     0xb004c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb004c4: cmp             SP, x16
    //     0xb004c8: b.ls            #0xb00554
    // 0xb004cc: ldr             x0, [fp, #0x10]
    // 0xb004d0: LoadField: r1 = r0->field_f
    //     0xb004d0: ldur            w1, [x0, #0xf]
    // 0xb004d4: DecompressPointer r1
    //     0xb004d4: add             x1, x1, HEAP, lsl #32
    // 0xb004d8: LoadField: r2 = r0->field_17
    //     0xb004d8: ldur            w2, [x0, #0x17]
    // 0xb004dc: DecompressPointer r2
    //     0xb004dc: add             x2, x2, HEAP, lsl #32
    // 0xb004e0: LoadField: r3 = r0->field_1b
    //     0xb004e0: ldur            w3, [x0, #0x1b]
    // 0xb004e4: DecompressPointer r3
    //     0xb004e4: add             x3, x3, HEAP, lsl #32
    // 0xb004e8: LoadField: r4 = r0->field_2b
    //     0xb004e8: ldur            w4, [x0, #0x2b]
    // 0xb004ec: DecompressPointer r4
    //     0xb004ec: add             x4, x4, HEAP, lsl #32
    // 0xb004f0: LoadField: r5 = r0->field_2f
    //     0xb004f0: ldur            w5, [x0, #0x2f]
    // 0xb004f4: DecompressPointer r5
    //     0xb004f4: add             x5, x5, HEAP, lsl #32
    // 0xb004f8: LoadField: r6 = r0->field_33
    //     0xb004f8: ldur            w6, [x0, #0x33]
    // 0xb004fc: DecompressPointer r6
    //     0xb004fc: add             x6, x6, HEAP, lsl #32
    // 0xb00500: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00504: stp             NULL, x1, [SP, #-0x10]!
    // 0xb00508: stp             x3, x2, [SP, #-0x10]!
    // 0xb0050c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00510: stp             x4, NULL, [SP, #-0x10]!
    // 0xb00514: stp             x6, x5, [SP, #-0x10]!
    // 0xb00518: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb0051c: SaveReg rNULL
    //     0xb0051c: str             NULL, [SP, #-8]!
    // 0xb00520: r4 = const [0, 0xf, 0xf, 0xf, null]
    //     0xb00520: add             x4, PP, #0xd, lsl #12  ; [pp+0xdef0] List(5) [0, 0xf, 0xf, 0xf, Null]
    //     0xb00524: ldr             x4, [x4, #0xef0]
    // 0xb00528: r0 = hash()
    //     0xb00528: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb0052c: add             SP, SP, #0x78
    // 0xb00530: mov             x2, x0
    // 0xb00534: r0 = BoxInt64Instr(r2)
    //     0xb00534: sbfiz           x0, x2, #1, #0x1f
    //     0xb00538: cmp             x2, x0, asr #1
    //     0xb0053c: b.eq            #0xb00548
    //     0xb00540: bl              #0xd69bb8
    //     0xb00544: stur            x2, [x0, #7]
    // 0xb00548: LeaveFrame
    //     0xb00548: mov             SP, fp
    //     0xb0054c: ldp             fp, lr, [SP], #0x10
    // 0xb00550: ret
    //     0xb00550: ret             
    // 0xb00554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00554: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00558: b               #0xb004cc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf42f4, size: 0x238
    // 0xbf42f4: EnterFrame
    //     0xbf42f4: stp             fp, lr, [SP, #-0x10]!
    //     0xbf42f8: mov             fp, SP
    // 0xbf42fc: AllocStack(0x30)
    //     0xbf42fc: sub             SP, SP, #0x30
    // 0xbf4300: d0 = 0.500000
    //     0xbf4300: fmov            d0, #0.50000000
    // 0xbf4304: CheckStackOverflow
    //     0xbf4304: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4308: cmp             SP, x16
    //     0xbf430c: b.ls            #0xbf4500
    // 0xbf4310: ldr             d1, [fp, #0x10]
    // 0xbf4314: fcmp            d1, d0
    // 0xbf4318: b.vs            #0xbf4338
    // 0xbf431c: b.ge            #0xbf4338
    // 0xbf4320: ldr             x0, [fp, #0x20]
    // 0xbf4324: LoadField: r1 = r0->field_f
    //     0xbf4324: ldur            w1, [x0, #0xf]
    // 0xbf4328: DecompressPointer r1
    //     0xbf4328: add             x1, x1, HEAP, lsl #32
    // 0xbf432c: mov             x2, x1
    // 0xbf4330: ldr             x1, [fp, #0x18]
    // 0xbf4334: b               #0xbf4348
    // 0xbf4338: ldr             x0, [fp, #0x20]
    // 0xbf433c: ldr             x1, [fp, #0x18]
    // 0xbf4340: LoadField: r2 = r1->field_f
    //     0xbf4340: ldur            w2, [x1, #0xf]
    // 0xbf4344: DecompressPointer r2
    //     0xbf4344: add             x2, x2, HEAP, lsl #32
    // 0xbf4348: stur            x2, [fp, #-0x10]
    // 0xbf434c: r3 = inline_Allocate_Double()
    //     0xbf434c: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbf4350: add             x3, x3, #0x10
    //     0xbf4354: cmp             x4, x3
    //     0xbf4358: b.ls            #0xbf4508
    //     0xbf435c: str             x3, [THR, #0x60]  ; THR::top
    //     0xbf4360: sub             x3, x3, #0xf
    //     0xbf4364: mov             x4, #0xd108
    //     0xbf4368: movk            x4, #3, lsl #16
    //     0xbf436c: stur            x4, [x3, #-1]
    // 0xbf4370: StoreField: r3->field_7 = d1
    //     0xbf4370: stur            d1, [x3, #7]
    // 0xbf4374: stur            x3, [fp, #-8]
    // 0xbf4378: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf437c: SaveReg r3
    //     0xbf437c: str             x3, [SP, #-8]!
    // 0xbf4380: r0 = lerp()
    //     0xbf4380: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4384: add             SP, SP, #0x18
    // 0xbf4388: ldr             x0, [fp, #0x20]
    // 0xbf438c: LoadField: r1 = r0->field_17
    //     0xbf438c: ldur            w1, [x0, #0x17]
    // 0xbf4390: DecompressPointer r1
    //     0xbf4390: add             x1, x1, HEAP, lsl #32
    // 0xbf4394: ldr             x2, [fp, #0x18]
    // 0xbf4398: LoadField: r3 = r2->field_17
    //     0xbf4398: ldur            w3, [x2, #0x17]
    // 0xbf439c: DecompressPointer r3
    //     0xbf439c: add             x3, x3, HEAP, lsl #32
    // 0xbf43a0: stp             x3, x1, [SP, #-0x10]!
    // 0xbf43a4: ldur            x16, [fp, #-8]
    // 0xbf43a8: SaveReg r16
    //     0xbf43a8: str             x16, [SP, #-8]!
    // 0xbf43ac: r0 = lerp()
    //     0xbf43ac: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf43b0: add             SP, SP, #0x18
    // 0xbf43b4: mov             x1, x0
    // 0xbf43b8: ldr             x0, [fp, #0x20]
    // 0xbf43bc: stur            x1, [fp, #-0x18]
    // 0xbf43c0: LoadField: r2 = r0->field_1b
    //     0xbf43c0: ldur            w2, [x0, #0x1b]
    // 0xbf43c4: DecompressPointer r2
    //     0xbf43c4: add             x2, x2, HEAP, lsl #32
    // 0xbf43c8: ldr             x3, [fp, #0x18]
    // 0xbf43cc: LoadField: r4 = r3->field_1b
    //     0xbf43cc: ldur            w4, [x3, #0x1b]
    // 0xbf43d0: DecompressPointer r4
    //     0xbf43d0: add             x4, x4, HEAP, lsl #32
    // 0xbf43d4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf43d8: ldur            x16, [fp, #-8]
    // 0xbf43dc: SaveReg r16
    //     0xbf43dc: str             x16, [SP, #-8]!
    // 0xbf43e0: r0 = lerp()
    //     0xbf43e0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf43e4: add             SP, SP, #0x18
    // 0xbf43e8: stur            x0, [fp, #-0x20]
    // 0xbf43ec: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf43f0: ldur            x16, [fp, #-8]
    // 0xbf43f4: SaveReg r16
    //     0xbf43f4: str             x16, [SP, #-8]!
    // 0xbf43f8: r0 = lerp()
    //     0xbf43f8: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf43fc: add             SP, SP, #0x18
    // 0xbf4400: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4404: ldur            x16, [fp, #-8]
    // 0xbf4408: SaveReg r16
    //     0xbf4408: str             x16, [SP, #-8]!
    // 0xbf440c: r0 = lerp()
    //     0xbf440c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4410: add             SP, SP, #0x18
    // 0xbf4414: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4418: ldur            x16, [fp, #-8]
    // 0xbf441c: SaveReg r16
    //     0xbf441c: str             x16, [SP, #-8]!
    // 0xbf4420: r0 = lerp()
    //     0xbf4420: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4424: add             SP, SP, #0x18
    // 0xbf4428: ldr             x0, [fp, #0x20]
    // 0xbf442c: LoadField: r1 = r0->field_2b
    //     0xbf442c: ldur            w1, [x0, #0x2b]
    // 0xbf4430: DecompressPointer r1
    //     0xbf4430: add             x1, x1, HEAP, lsl #32
    // 0xbf4434: ldr             x2, [fp, #0x18]
    // 0xbf4438: LoadField: r3 = r2->field_2b
    //     0xbf4438: ldur            w3, [x2, #0x2b]
    // 0xbf443c: DecompressPointer r3
    //     0xbf443c: add             x3, x3, HEAP, lsl #32
    // 0xbf4440: stp             x3, x1, [SP, #-0x10]!
    // 0xbf4444: ldur            x16, [fp, #-8]
    // 0xbf4448: SaveReg r16
    //     0xbf4448: str             x16, [SP, #-8]!
    // 0xbf444c: r0 = lerpDouble()
    //     0xbf444c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4450: add             SP, SP, #0x18
    // 0xbf4454: mov             x1, x0
    // 0xbf4458: ldr             x0, [fp, #0x20]
    // 0xbf445c: stur            x1, [fp, #-0x28]
    // 0xbf4460: LoadField: r2 = r0->field_2f
    //     0xbf4460: ldur            w2, [x0, #0x2f]
    // 0xbf4464: DecompressPointer r2
    //     0xbf4464: add             x2, x2, HEAP, lsl #32
    // 0xbf4468: ldr             x3, [fp, #0x18]
    // 0xbf446c: LoadField: r4 = r3->field_2f
    //     0xbf446c: ldur            w4, [x3, #0x2f]
    // 0xbf4470: DecompressPointer r4
    //     0xbf4470: add             x4, x4, HEAP, lsl #32
    // 0xbf4474: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4478: ldur            x16, [fp, #-8]
    // 0xbf447c: SaveReg r16
    //     0xbf447c: str             x16, [SP, #-8]!
    // 0xbf4480: r0 = lerpDouble()
    //     0xbf4480: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4484: add             SP, SP, #0x18
    // 0xbf4488: mov             x1, x0
    // 0xbf448c: ldr             x0, [fp, #0x20]
    // 0xbf4490: stur            x1, [fp, #-0x30]
    // 0xbf4494: LoadField: r2 = r0->field_33
    //     0xbf4494: ldur            w2, [x0, #0x33]
    // 0xbf4498: DecompressPointer r2
    //     0xbf4498: add             x2, x2, HEAP, lsl #32
    // 0xbf449c: ldr             x0, [fp, #0x18]
    // 0xbf44a0: LoadField: r3 = r0->field_33
    //     0xbf44a0: ldur            w3, [x0, #0x33]
    // 0xbf44a4: DecompressPointer r3
    //     0xbf44a4: add             x3, x3, HEAP, lsl #32
    // 0xbf44a8: stp             x3, x2, [SP, #-0x10]!
    // 0xbf44ac: ldur            x16, [fp, #-8]
    // 0xbf44b0: SaveReg r16
    //     0xbf44b0: str             x16, [SP, #-8]!
    // 0xbf44b4: r0 = lerpDouble()
    //     0xbf44b4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf44b8: add             SP, SP, #0x18
    // 0xbf44bc: stur            x0, [fp, #-8]
    // 0xbf44c0: r0 = ListTileThemeData()
    //     0xbf44c0: bl              #0x853034  ; AllocateListTileThemeDataStub -> ListTileThemeData (size=0x44)
    // 0xbf44c4: ldur            x1, [fp, #-0x10]
    // 0xbf44c8: StoreField: r0->field_f = r1
    //     0xbf44c8: stur            w1, [x0, #0xf]
    // 0xbf44cc: ldur            x1, [fp, #-0x18]
    // 0xbf44d0: StoreField: r0->field_17 = r1
    //     0xbf44d0: stur            w1, [x0, #0x17]
    // 0xbf44d4: ldur            x1, [fp, #-0x20]
    // 0xbf44d8: StoreField: r0->field_1b = r1
    //     0xbf44d8: stur            w1, [x0, #0x1b]
    // 0xbf44dc: ldur            x1, [fp, #-0x28]
    // 0xbf44e0: StoreField: r0->field_2b = r1
    //     0xbf44e0: stur            w1, [x0, #0x2b]
    // 0xbf44e4: ldur            x1, [fp, #-0x30]
    // 0xbf44e8: StoreField: r0->field_2f = r1
    //     0xbf44e8: stur            w1, [x0, #0x2f]
    // 0xbf44ec: ldur            x1, [fp, #-8]
    // 0xbf44f0: StoreField: r0->field_33 = r1
    //     0xbf44f0: stur            w1, [x0, #0x33]
    // 0xbf44f4: LeaveFrame
    //     0xbf44f4: mov             SP, fp
    //     0xbf44f8: ldp             fp, lr, [SP], #0x10
    // 0xbf44fc: ret
    //     0xbf44fc: ret             
    // 0xbf4500: r0 = StackOverflowSharedWithFPURegs()
    //     0xbf4500: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbf4504: b               #0xbf4310
    // 0xbf4508: SaveReg d1
    //     0xbf4508: str             q1, [SP, #-0x10]!
    // 0xbf450c: stp             x1, x2, [SP, #-0x10]!
    // 0xbf4510: SaveReg r0
    //     0xbf4510: str             x0, [SP, #-8]!
    // 0xbf4514: r0 = AllocateDouble()
    //     0xbf4514: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf4518: mov             x3, x0
    // 0xbf451c: RestoreReg r0
    //     0xbf451c: ldr             x0, [SP], #8
    // 0xbf4520: ldp             x1, x2, [SP], #0x10
    // 0xbf4524: RestoreReg d1
    //     0xbf4524: ldr             q1, [SP], #0x10
    // 0xbf4528: b               #0xbf4370
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8b0e4, size: 0x234
    // 0xc8b0e4: EnterFrame
    //     0xc8b0e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc8b0e8: mov             fp, SP
    // 0xc8b0ec: CheckStackOverflow
    //     0xc8b0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8b0f0: cmp             SP, x16
    //     0xc8b0f4: b.ls            #0xc8b310
    // 0xc8b0f8: ldr             x1, [fp, #0x10]
    // 0xc8b0fc: cmp             w1, NULL
    // 0xc8b100: b.ne            #0xc8b114
    // 0xc8b104: r0 = false
    //     0xc8b104: add             x0, NULL, #0x30  ; false
    // 0xc8b108: LeaveFrame
    //     0xc8b108: mov             SP, fp
    //     0xc8b10c: ldp             fp, lr, [SP], #0x10
    // 0xc8b110: ret
    //     0xc8b110: ret             
    // 0xc8b114: ldr             x2, [fp, #0x18]
    // 0xc8b118: cmp             w2, w1
    // 0xc8b11c: b.ne            #0xc8b130
    // 0xc8b120: r0 = true
    //     0xc8b120: add             x0, NULL, #0x20  ; true
    // 0xc8b124: LeaveFrame
    //     0xc8b124: mov             SP, fp
    //     0xc8b128: ldp             fp, lr, [SP], #0x10
    // 0xc8b12c: ret
    //     0xc8b12c: ret             
    // 0xc8b130: r0 = 59
    //     0xc8b130: mov             x0, #0x3b
    // 0xc8b134: branchIfSmi(r1, 0xc8b140)
    //     0xc8b134: tbz             w1, #0, #0xc8b140
    // 0xc8b138: r0 = LoadClassIdInstr(r1)
    //     0xc8b138: ldur            x0, [x1, #-1]
    //     0xc8b13c: ubfx            x0, x0, #0xc, #0x14
    // 0xc8b140: SaveReg r1
    //     0xc8b140: str             x1, [SP, #-8]!
    // 0xc8b144: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8b144: mov             x17, #0x57c5
    //     0xc8b148: add             lr, x0, x17
    //     0xc8b14c: ldr             lr, [x21, lr, lsl #3]
    //     0xc8b150: blr             lr
    // 0xc8b154: add             SP, SP, #8
    // 0xc8b158: r1 = LoadClassIdInstr(r0)
    //     0xc8b158: ldur            x1, [x0, #-1]
    //     0xc8b15c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8b160: r16 = ListTileThemeData
    //     0xc8b160: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1f0] Type: ListTileThemeData
    //     0xc8b164: ldr             x16, [x16, #0x1f0]
    // 0xc8b168: stp             x16, x0, [SP, #-0x10]!
    // 0xc8b16c: mov             x0, x1
    // 0xc8b170: mov             lr, x0
    // 0xc8b174: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b178: blr             lr
    // 0xc8b17c: add             SP, SP, #0x10
    // 0xc8b180: tbz             w0, #4, #0xc8b194
    // 0xc8b184: r0 = false
    //     0xc8b184: add             x0, NULL, #0x30  ; false
    // 0xc8b188: LeaveFrame
    //     0xc8b188: mov             SP, fp
    //     0xc8b18c: ldp             fp, lr, [SP], #0x10
    // 0xc8b190: ret
    //     0xc8b190: ret             
    // 0xc8b194: ldr             x1, [fp, #0x10]
    // 0xc8b198: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8b198: mov             x0, #0x76
    //     0xc8b19c: tbz             w1, #0, #0xc8b1ac
    //     0xc8b1a0: ldur            x0, [x1, #-1]
    //     0xc8b1a4: ubfx            x0, x0, #0xc, #0x14
    //     0xc8b1a8: lsl             x0, x0, #1
    // 0xc8b1ac: r17 = 5586
    //     0xc8b1ac: mov             x17, #0x15d2
    // 0xc8b1b0: cmp             w0, w17
    // 0xc8b1b4: b.ne            #0xc8b300
    // 0xc8b1b8: ldr             x2, [fp, #0x18]
    // 0xc8b1bc: LoadField: r0 = r1->field_f
    //     0xc8b1bc: ldur            w0, [x1, #0xf]
    // 0xc8b1c0: DecompressPointer r0
    //     0xc8b1c0: add             x0, x0, HEAP, lsl #32
    // 0xc8b1c4: LoadField: r3 = r2->field_f
    //     0xc8b1c4: ldur            w3, [x2, #0xf]
    // 0xc8b1c8: DecompressPointer r3
    //     0xc8b1c8: add             x3, x3, HEAP, lsl #32
    // 0xc8b1cc: cmp             w0, w3
    // 0xc8b1d0: b.ne            #0xc8b300
    // 0xc8b1d4: LoadField: r0 = r1->field_17
    //     0xc8b1d4: ldur            w0, [x1, #0x17]
    // 0xc8b1d8: DecompressPointer r0
    //     0xc8b1d8: add             x0, x0, HEAP, lsl #32
    // 0xc8b1dc: LoadField: r3 = r2->field_17
    //     0xc8b1dc: ldur            w3, [x2, #0x17]
    // 0xc8b1e0: DecompressPointer r3
    //     0xc8b1e0: add             x3, x3, HEAP, lsl #32
    // 0xc8b1e4: r4 = LoadClassIdInstr(r0)
    //     0xc8b1e4: ldur            x4, [x0, #-1]
    //     0xc8b1e8: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b1ec: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b1f0: mov             x0, x4
    // 0xc8b1f4: mov             lr, x0
    // 0xc8b1f8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b1fc: blr             lr
    // 0xc8b200: add             SP, SP, #0x10
    // 0xc8b204: tbnz            w0, #4, #0xc8b300
    // 0xc8b208: ldr             x2, [fp, #0x18]
    // 0xc8b20c: ldr             x1, [fp, #0x10]
    // 0xc8b210: LoadField: r0 = r1->field_1b
    //     0xc8b210: ldur            w0, [x1, #0x1b]
    // 0xc8b214: DecompressPointer r0
    //     0xc8b214: add             x0, x0, HEAP, lsl #32
    // 0xc8b218: LoadField: r3 = r2->field_1b
    //     0xc8b218: ldur            w3, [x2, #0x1b]
    // 0xc8b21c: DecompressPointer r3
    //     0xc8b21c: add             x3, x3, HEAP, lsl #32
    // 0xc8b220: r4 = LoadClassIdInstr(r0)
    //     0xc8b220: ldur            x4, [x0, #-1]
    //     0xc8b224: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b228: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b22c: mov             x0, x4
    // 0xc8b230: mov             lr, x0
    // 0xc8b234: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b238: blr             lr
    // 0xc8b23c: add             SP, SP, #0x10
    // 0xc8b240: tbnz            w0, #4, #0xc8b300
    // 0xc8b244: ldr             x2, [fp, #0x18]
    // 0xc8b248: ldr             x1, [fp, #0x10]
    // 0xc8b24c: LoadField: r0 = r1->field_2b
    //     0xc8b24c: ldur            w0, [x1, #0x2b]
    // 0xc8b250: DecompressPointer r0
    //     0xc8b250: add             x0, x0, HEAP, lsl #32
    // 0xc8b254: LoadField: r3 = r2->field_2b
    //     0xc8b254: ldur            w3, [x2, #0x2b]
    // 0xc8b258: DecompressPointer r3
    //     0xc8b258: add             x3, x3, HEAP, lsl #32
    // 0xc8b25c: r4 = LoadClassIdInstr(r0)
    //     0xc8b25c: ldur            x4, [x0, #-1]
    //     0xc8b260: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b264: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b268: mov             x0, x4
    // 0xc8b26c: mov             lr, x0
    // 0xc8b270: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b274: blr             lr
    // 0xc8b278: add             SP, SP, #0x10
    // 0xc8b27c: tbnz            w0, #4, #0xc8b300
    // 0xc8b280: ldr             x2, [fp, #0x18]
    // 0xc8b284: ldr             x1, [fp, #0x10]
    // 0xc8b288: LoadField: r0 = r1->field_2f
    //     0xc8b288: ldur            w0, [x1, #0x2f]
    // 0xc8b28c: DecompressPointer r0
    //     0xc8b28c: add             x0, x0, HEAP, lsl #32
    // 0xc8b290: LoadField: r3 = r2->field_2f
    //     0xc8b290: ldur            w3, [x2, #0x2f]
    // 0xc8b294: DecompressPointer r3
    //     0xc8b294: add             x3, x3, HEAP, lsl #32
    // 0xc8b298: r4 = LoadClassIdInstr(r0)
    //     0xc8b298: ldur            x4, [x0, #-1]
    //     0xc8b29c: ubfx            x4, x4, #0xc, #0x14
    // 0xc8b2a0: stp             x3, x0, [SP, #-0x10]!
    // 0xc8b2a4: mov             x0, x4
    // 0xc8b2a8: mov             lr, x0
    // 0xc8b2ac: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b2b0: blr             lr
    // 0xc8b2b4: add             SP, SP, #0x10
    // 0xc8b2b8: tbnz            w0, #4, #0xc8b300
    // 0xc8b2bc: ldr             x1, [fp, #0x18]
    // 0xc8b2c0: ldr             x0, [fp, #0x10]
    // 0xc8b2c4: LoadField: r2 = r0->field_33
    //     0xc8b2c4: ldur            w2, [x0, #0x33]
    // 0xc8b2c8: DecompressPointer r2
    //     0xc8b2c8: add             x2, x2, HEAP, lsl #32
    // 0xc8b2cc: LoadField: r0 = r1->field_33
    //     0xc8b2cc: ldur            w0, [x1, #0x33]
    // 0xc8b2d0: DecompressPointer r0
    //     0xc8b2d0: add             x0, x0, HEAP, lsl #32
    // 0xc8b2d4: r1 = LoadClassIdInstr(r2)
    //     0xc8b2d4: ldur            x1, [x2, #-1]
    //     0xc8b2d8: ubfx            x1, x1, #0xc, #0x14
    // 0xc8b2dc: stp             x0, x2, [SP, #-0x10]!
    // 0xc8b2e0: mov             x0, x1
    // 0xc8b2e4: mov             lr, x0
    // 0xc8b2e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8b2ec: blr             lr
    // 0xc8b2f0: add             SP, SP, #0x10
    // 0xc8b2f4: tbnz            w0, #4, #0xc8b300
    // 0xc8b2f8: r0 = true
    //     0xc8b2f8: add             x0, NULL, #0x20  ; true
    // 0xc8b2fc: b               #0xc8b304
    // 0xc8b300: r0 = false
    //     0xc8b300: add             x0, NULL, #0x30  ; false
    // 0xc8b304: LeaveFrame
    //     0xc8b304: mov             SP, fp
    //     0xc8b308: ldp             fp, lr, [SP], #0x10
    // 0xc8b30c: ret
    //     0xc8b30c: ret             
    // 0xc8b310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8b310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8b314: b               #0xc8b0f8
  }
}

// class id: 3543, size: 0x4c, field offset: 0x10
//   const constructor, 
class ListTileTheme extends InheritedTheme {

  static _ merge(/* No info */) {
    // ** addr: 0x852d8c, size: 0x170
    // 0x852d8c: EnterFrame
    //     0x852d8c: stp             fp, lr, [SP, #-0x10]!
    //     0x852d90: mov             fp, SP
    // 0x852d94: AllocStack(0x20)
    //     0x852d94: sub             SP, SP, #0x20
    // 0x852d98: SetupParameters(dynamic _ /* r3, fp-0x20 */, {dynamic iconColor = Null /* r2, fp-0x18 */, dynamic style = Null /* r4, fp-0x10 */, dynamic textColor = Null /* r0, fp-0x8 */})
    //     0x852d98: mov             x0, x4
    //     0x852d9c: ldur            w1, [x0, #0x13]
    //     0x852da0: add             x1, x1, HEAP, lsl #32
    //     0x852da4: sub             x2, x1, #2
    //     0x852da8: add             x3, fp, w2, sxtw #2
    //     0x852dac: ldr             x3, [x3, #0x10]
    //     0x852db0: stur            x3, [fp, #-0x20]
    //     0x852db4: ldur            w2, [x0, #0x1f]
    //     0x852db8: add             x2, x2, HEAP, lsl #32
    //     0x852dbc: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ff60] "iconColor"
    //     0x852dc0: ldr             x16, [x16, #0xf60]
    //     0x852dc4: cmp             w2, w16
    //     0x852dc8: b.ne            #0x852de8
    //     0x852dcc: ldur            w2, [x0, #0x23]
    //     0x852dd0: add             x2, x2, HEAP, lsl #32
    //     0x852dd4: sub             w4, w1, w2
    //     0x852dd8: add             x2, fp, w4, sxtw #2
    //     0x852ddc: ldr             x2, [x2, #8]
    //     0x852de0: mov             x4, #1
    //     0x852de4: b               #0x852df0
    //     0x852de8: mov             x4, #0
    //     0x852dec: mov             x2, NULL
    //     0x852df0: stur            x2, [fp, #-0x18]
    //     0x852df4: lsl             x5, x4, #1
    //     0x852df8: lsl             w6, w5, #1
    //     0x852dfc: add             w7, w6, #8
    //     0x852e00: add             x16, x0, w7, sxtw #1
    //     0x852e04: ldur            w8, [x16, #0xf]
    //     0x852e08: add             x8, x8, HEAP, lsl #32
    //     0x852e0c: ldr             x16, [PP, #0x6c08]  ; [pp+0x6c08] "style"
    //     0x852e10: cmp             w8, w16
    //     0x852e14: b.ne            #0x852e44
    //     0x852e18: add             w4, w6, #0xa
    //     0x852e1c: add             x16, x0, w4, sxtw #1
    //     0x852e20: ldur            w6, [x16, #0xf]
    //     0x852e24: add             x6, x6, HEAP, lsl #32
    //     0x852e28: sub             w4, w1, w6
    //     0x852e2c: add             x6, fp, w4, sxtw #2
    //     0x852e30: ldr             x6, [x6, #8]
    //     0x852e34: add             w4, w5, #2
    //     0x852e38: sbfx            x5, x4, #1, #0x1f
    //     0x852e3c: mov             x4, x6
    //     0x852e40: b               #0x852e4c
    //     0x852e44: mov             x5, x4
    //     0x852e48: mov             x4, NULL
    //     0x852e4c: stur            x4, [fp, #-0x10]
    //     0x852e50: lsl             x6, x5, #1
    //     0x852e54: lsl             w5, w6, #1
    //     0x852e58: add             w6, w5, #8
    //     0x852e5c: add             x16, x0, w6, sxtw #1
    //     0x852e60: ldur            w7, [x16, #0xf]
    //     0x852e64: add             x7, x7, HEAP, lsl #32
    //     0x852e68: add             x16, PP, #0x53, lsl #12  ; [pp+0x531e8] "textColor"
    //     0x852e6c: ldr             x16, [x16, #0x1e8]
    //     0x852e70: cmp             w7, w16
    //     0x852e74: b.ne            #0x852e9c
    //     0x852e78: add             w6, w5, #0xa
    //     0x852e7c: add             x16, x0, w6, sxtw #1
    //     0x852e80: ldur            w5, [x16, #0xf]
    //     0x852e84: add             x5, x5, HEAP, lsl #32
    //     0x852e88: sub             w0, w1, w5
    //     0x852e8c: add             x1, fp, w0, sxtw #2
    //     0x852e90: ldr             x1, [x1, #8]
    //     0x852e94: mov             x0, x1
    //     0x852e98: b               #0x852ea0
    //     0x852e9c: mov             x0, NULL
    //     0x852ea0: stur            x0, [fp, #-8]
    // 0x852ea4: r1 = 4
    //     0x852ea4: mov             x1, #4
    // 0x852ea8: r0 = AllocateContext()
    //     0x852ea8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x852eac: mov             x1, x0
    // 0x852eb0: ldur            x0, [fp, #-0x20]
    // 0x852eb4: StoreField: r1->field_f = r0
    //     0x852eb4: stur            w0, [x1, #0xf]
    // 0x852eb8: ldur            x0, [fp, #-0x18]
    // 0x852ebc: StoreField: r1->field_13 = r0
    //     0x852ebc: stur            w0, [x1, #0x13]
    // 0x852ec0: ldur            x0, [fp, #-0x10]
    // 0x852ec4: StoreField: r1->field_17 = r0
    //     0x852ec4: stur            w0, [x1, #0x17]
    // 0x852ec8: ldur            x0, [fp, #-8]
    // 0x852ecc: StoreField: r1->field_1b = r0
    //     0x852ecc: stur            w0, [x1, #0x1b]
    // 0x852ed0: mov             x2, x1
    // 0x852ed4: r1 = Function '<anonymous closure>': static.
    //     0x852ed4: add             x1, PP, #0x53, lsl #12  ; [pp+0x531f0] AnonymousClosure: static (0x852efc), in [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::merge (0x852d8c)
    //     0x852ed8: ldr             x1, [x1, #0x1f0]
    // 0x852edc: r0 = AllocateClosure()
    //     0x852edc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x852ee0: stur            x0, [fp, #-8]
    // 0x852ee4: r0 = Builder()
    //     0x852ee4: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x852ee8: ldur            x1, [fp, #-8]
    // 0x852eec: StoreField: r0->field_b = r1
    //     0x852eec: stur            w1, [x0, #0xb]
    // 0x852ef0: LeaveFrame
    //     0x852ef0: mov             SP, fp
    //     0x852ef4: ldp             fp, lr, [SP], #0x10
    // 0x852ef8: ret
    //     0x852ef8: ret             
  }
  [closure] static ListTileTheme <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x852efc, size: 0x12c
    // 0x852efc: EnterFrame
    //     0x852efc: stp             fp, lr, [SP, #-0x10]!
    //     0x852f00: mov             fp, SP
    // 0x852f04: AllocStack(0x40)
    //     0x852f04: sub             SP, SP, #0x40
    // 0x852f08: SetupParameters()
    //     0x852f08: ldr             x0, [fp, #0x18]
    //     0x852f0c: ldur            w1, [x0, #0x17]
    //     0x852f10: add             x1, x1, HEAP, lsl #32
    //     0x852f14: stur            x1, [fp, #-8]
    // 0x852f18: CheckStackOverflow
    //     0x852f18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x852f1c: cmp             SP, x16
    //     0x852f20: b.ls            #0x853020
    // 0x852f24: ldr             x16, [fp, #0x10]
    // 0x852f28: SaveReg r16
    //     0x852f28: str             x16, [SP, #-8]!
    // 0x852f2c: r0 = of()
    //     0x852f2c: bl              #0x853040  ; [package:flutter/src/material/list_tile_theme.dart] ListTileTheme::of
    // 0x852f30: add             SP, SP, #8
    // 0x852f34: mov             x1, x0
    // 0x852f38: ldur            x0, [fp, #-8]
    // 0x852f3c: LoadField: r2 = r0->field_17
    //     0x852f3c: ldur            w2, [x0, #0x17]
    // 0x852f40: DecompressPointer r2
    //     0x852f40: add             x2, x2, HEAP, lsl #32
    // 0x852f44: cmp             w2, NULL
    // 0x852f48: b.ne            #0x852f54
    // 0x852f4c: LoadField: r2 = r1->field_f
    //     0x852f4c: ldur            w2, [x1, #0xf]
    // 0x852f50: DecompressPointer r2
    //     0x852f50: add             x2, x2, HEAP, lsl #32
    // 0x852f54: stur            x2, [fp, #-0x38]
    // 0x852f58: LoadField: r3 = r0->field_13
    //     0x852f58: ldur            w3, [x0, #0x13]
    // 0x852f5c: DecompressPointer r3
    //     0x852f5c: add             x3, x3, HEAP, lsl #32
    // 0x852f60: cmp             w3, NULL
    // 0x852f64: b.ne            #0x852f70
    // 0x852f68: LoadField: r3 = r1->field_17
    //     0x852f68: ldur            w3, [x1, #0x17]
    // 0x852f6c: DecompressPointer r3
    //     0x852f6c: add             x3, x3, HEAP, lsl #32
    // 0x852f70: stur            x3, [fp, #-0x30]
    // 0x852f74: LoadField: r4 = r0->field_1b
    //     0x852f74: ldur            w4, [x0, #0x1b]
    // 0x852f78: DecompressPointer r4
    //     0x852f78: add             x4, x4, HEAP, lsl #32
    // 0x852f7c: cmp             w4, NULL
    // 0x852f80: b.ne            #0x852f8c
    // 0x852f84: LoadField: r4 = r1->field_1b
    //     0x852f84: ldur            w4, [x1, #0x1b]
    // 0x852f88: DecompressPointer r4
    //     0x852f88: add             x4, x4, HEAP, lsl #32
    // 0x852f8c: stur            x4, [fp, #-0x28]
    // 0x852f90: LoadField: r5 = r1->field_2b
    //     0x852f90: ldur            w5, [x1, #0x2b]
    // 0x852f94: DecompressPointer r5
    //     0x852f94: add             x5, x5, HEAP, lsl #32
    // 0x852f98: stur            x5, [fp, #-0x20]
    // 0x852f9c: LoadField: r6 = r1->field_2f
    //     0x852f9c: ldur            w6, [x1, #0x2f]
    // 0x852fa0: DecompressPointer r6
    //     0x852fa0: add             x6, x6, HEAP, lsl #32
    // 0x852fa4: stur            x6, [fp, #-0x18]
    // 0x852fa8: LoadField: r7 = r1->field_33
    //     0x852fa8: ldur            w7, [x1, #0x33]
    // 0x852fac: DecompressPointer r7
    //     0x852fac: add             x7, x7, HEAP, lsl #32
    // 0x852fb0: stur            x7, [fp, #-0x10]
    // 0x852fb4: r0 = ListTileThemeData()
    //     0x852fb4: bl              #0x853034  ; AllocateListTileThemeDataStub -> ListTileThemeData (size=0x44)
    // 0x852fb8: mov             x1, x0
    // 0x852fbc: ldur            x0, [fp, #-0x38]
    // 0x852fc0: stur            x1, [fp, #-0x40]
    // 0x852fc4: StoreField: r1->field_f = r0
    //     0x852fc4: stur            w0, [x1, #0xf]
    // 0x852fc8: ldur            x0, [fp, #-0x30]
    // 0x852fcc: StoreField: r1->field_17 = r0
    //     0x852fcc: stur            w0, [x1, #0x17]
    // 0x852fd0: ldur            x0, [fp, #-0x28]
    // 0x852fd4: StoreField: r1->field_1b = r0
    //     0x852fd4: stur            w0, [x1, #0x1b]
    // 0x852fd8: ldur            x0, [fp, #-0x20]
    // 0x852fdc: StoreField: r1->field_2b = r0
    //     0x852fdc: stur            w0, [x1, #0x2b]
    // 0x852fe0: ldur            x0, [fp, #-0x18]
    // 0x852fe4: StoreField: r1->field_2f = r0
    //     0x852fe4: stur            w0, [x1, #0x2f]
    // 0x852fe8: ldur            x0, [fp, #-0x10]
    // 0x852fec: StoreField: r1->field_33 = r0
    //     0x852fec: stur            w0, [x1, #0x33]
    // 0x852ff0: ldur            x0, [fp, #-8]
    // 0x852ff4: LoadField: r2 = r0->field_f
    //     0x852ff4: ldur            w2, [x0, #0xf]
    // 0x852ff8: DecompressPointer r2
    //     0x852ff8: add             x2, x2, HEAP, lsl #32
    // 0x852ffc: stur            x2, [fp, #-0x10]
    // 0x853000: r0 = ListTileTheme()
    //     0x853000: bl              #0x853028  ; AllocateListTileThemeStub -> ListTileTheme (size=0x4c)
    // 0x853004: ldur            x1, [fp, #-0x40]
    // 0x853008: StoreField: r0->field_f = r1
    //     0x853008: stur            w1, [x0, #0xf]
    // 0x85300c: ldur            x1, [fp, #-0x10]
    // 0x853010: StoreField: r0->field_b = r1
    //     0x853010: stur            w1, [x0, #0xb]
    // 0x853014: LeaveFrame
    //     0x853014: mov             SP, fp
    //     0x853018: ldp             fp, lr, [SP], #0x10
    // 0x85301c: ret
    //     0x85301c: ret             
    // 0x853020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x853020: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x853024: b               #0x852f24
  }
  static _ of(/* No info */) {
    // ** addr: 0x853040, size: 0x84
    // 0x853040: EnterFrame
    //     0x853040: stp             fp, lr, [SP, #-0x10]!
    //     0x853044: mov             fp, SP
    // 0x853048: CheckStackOverflow
    //     0x853048: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85304c: cmp             SP, x16
    //     0x853050: b.ls            #0x8530bc
    // 0x853054: r16 = <ListTileTheme>
    //     0x853054: add             x16, PP, #0x53, lsl #12  ; [pp+0x531f8] TypeArguments: <ListTileTheme>
    //     0x853058: ldr             x16, [x16, #0x1f8]
    // 0x85305c: ldr             lr, [fp, #0x10]
    // 0x853060: stp             lr, x16, [SP, #-0x10]!
    // 0x853064: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x853064: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x853068: r0 = dependOnInheritedWidgetOfExactType()
    //     0x853068: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x85306c: add             SP, SP, #0x10
    // 0x853070: cmp             w0, NULL
    // 0x853074: b.ne            #0x853080
    // 0x853078: r0 = Null
    //     0x853078: mov             x0, NULL
    // 0x85307c: b               #0x85308c
    // 0x853080: LoadField: r1 = r0->field_f
    //     0x853080: ldur            w1, [x0, #0xf]
    // 0x853084: DecompressPointer r1
    //     0x853084: add             x1, x1, HEAP, lsl #32
    // 0x853088: mov             x0, x1
    // 0x85308c: cmp             w0, NULL
    // 0x853090: b.ne            #0x8530b0
    // 0x853094: ldr             x16, [fp, #0x10]
    // 0x853098: SaveReg r16
    //     0x853098: str             x16, [SP, #-8]!
    // 0x85309c: r0 = of()
    //     0x85309c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8530a0: add             SP, SP, #8
    // 0x8530a4: LoadField: r1 = r0->field_ef
    //     0x8530a4: ldur            w1, [x0, #0xef]
    // 0x8530a8: DecompressPointer r1
    //     0x8530a8: add             x1, x1, HEAP, lsl #32
    // 0x8530ac: mov             x0, x1
    // 0x8530b0: LeaveFrame
    //     0x8530b0: mov             SP, fp
    //     0x8530b4: ldp             fp, lr, [SP], #0x10
    // 0x8530b8: ret
    //     0x8530b8: ret             
    // 0x8530bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8530bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8530c0: b               #0x853054
  }
  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa8778c, size: 0x8c
    // 0xa8778c: EnterFrame
    //     0xa8778c: stp             fp, lr, [SP, #-0x10]!
    //     0xa87790: mov             fp, SP
    // 0xa87794: CheckStackOverflow
    //     0xa87794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa87798: cmp             SP, x16
    //     0xa8779c: b.ls            #0xa87810
    // 0xa877a0: ldr             x0, [fp, #0x10]
    // 0xa877a4: r2 = Null
    //     0xa877a4: mov             x2, NULL
    // 0xa877a8: r1 = Null
    //     0xa877a8: mov             x1, NULL
    // 0xa877ac: r4 = 59
    //     0xa877ac: mov             x4, #0x3b
    // 0xa877b0: branchIfSmi(r0, 0xa877bc)
    //     0xa877b0: tbz             w0, #0, #0xa877bc
    // 0xa877b4: r4 = LoadClassIdInstr(r0)
    //     0xa877b4: ldur            x4, [x0, #-1]
    //     0xa877b8: ubfx            x4, x4, #0xc, #0x14
    // 0xa877bc: cmp             x4, #0xdd7
    // 0xa877c0: b.eq            #0xa877d8
    // 0xa877c4: r8 = ListTileTheme
    //     0xa877c4: add             x8, PP, #0x55, lsl #12  ; [pp+0x55890] Type: ListTileTheme
    //     0xa877c8: ldr             x8, [x8, #0x890]
    // 0xa877cc: r3 = Null
    //     0xa877cc: add             x3, PP, #0x55, lsl #12  ; [pp+0x55898] Null
    //     0xa877d0: ldr             x3, [x3, #0x898]
    // 0xa877d4: r0 = DefaultTypeTest()
    //     0xa877d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa877d8: ldr             x0, [fp, #0x18]
    // 0xa877dc: LoadField: r1 = r0->field_f
    //     0xa877dc: ldur            w1, [x0, #0xf]
    // 0xa877e0: DecompressPointer r1
    //     0xa877e0: add             x1, x1, HEAP, lsl #32
    // 0xa877e4: ldr             x0, [fp, #0x10]
    // 0xa877e8: LoadField: r2 = r0->field_f
    //     0xa877e8: ldur            w2, [x0, #0xf]
    // 0xa877ec: DecompressPointer r2
    //     0xa877ec: add             x2, x2, HEAP, lsl #32
    // 0xa877f0: stp             x2, x1, [SP, #-0x10]!
    // 0xa877f4: r0 = ==()
    //     0xa877f4: bl              #0xc8b0e4  ; [package:flutter/src/material/list_tile_theme.dart] ListTileThemeData::==
    // 0xa877f8: add             SP, SP, #0x10
    // 0xa877fc: eor             x1, x0, #0x10
    // 0xa87800: mov             x0, x1
    // 0xa87804: LeaveFrame
    //     0xa87804: mov             SP, fp
    //     0xa87808: ldp             fp, lr, [SP], #0x10
    // 0xa8780c: ret
    //     0xa8780c: ret             
    // 0xa87810: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa87810: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa87814: b               #0xa877a0
  }
  _ wrap(/* No info */) {
    // ** addr: 0xc2f800, size: 0xbc
    // 0xc2f800: EnterFrame
    //     0xc2f800: stp             fp, lr, [SP, #-0x10]!
    //     0xc2f804: mov             fp, SP
    // 0xc2f808: AllocStack(0x38)
    //     0xc2f808: sub             SP, SP, #0x38
    // 0xc2f80c: ldr             x0, [fp, #0x18]
    // 0xc2f810: LoadField: r1 = r0->field_f
    //     0xc2f810: ldur            w1, [x0, #0xf]
    // 0xc2f814: DecompressPointer r1
    //     0xc2f814: add             x1, x1, HEAP, lsl #32
    // 0xc2f818: LoadField: r0 = r1->field_f
    //     0xc2f818: ldur            w0, [x1, #0xf]
    // 0xc2f81c: DecompressPointer r0
    //     0xc2f81c: add             x0, x0, HEAP, lsl #32
    // 0xc2f820: stur            x0, [fp, #-0x30]
    // 0xc2f824: LoadField: r2 = r1->field_17
    //     0xc2f824: ldur            w2, [x1, #0x17]
    // 0xc2f828: DecompressPointer r2
    //     0xc2f828: add             x2, x2, HEAP, lsl #32
    // 0xc2f82c: stur            x2, [fp, #-0x28]
    // 0xc2f830: LoadField: r3 = r1->field_1b
    //     0xc2f830: ldur            w3, [x1, #0x1b]
    // 0xc2f834: DecompressPointer r3
    //     0xc2f834: add             x3, x3, HEAP, lsl #32
    // 0xc2f838: stur            x3, [fp, #-0x20]
    // 0xc2f83c: LoadField: r4 = r1->field_2b
    //     0xc2f83c: ldur            w4, [x1, #0x2b]
    // 0xc2f840: DecompressPointer r4
    //     0xc2f840: add             x4, x4, HEAP, lsl #32
    // 0xc2f844: stur            x4, [fp, #-0x18]
    // 0xc2f848: LoadField: r5 = r1->field_2f
    //     0xc2f848: ldur            w5, [x1, #0x2f]
    // 0xc2f84c: DecompressPointer r5
    //     0xc2f84c: add             x5, x5, HEAP, lsl #32
    // 0xc2f850: stur            x5, [fp, #-0x10]
    // 0xc2f854: LoadField: r6 = r1->field_33
    //     0xc2f854: ldur            w6, [x1, #0x33]
    // 0xc2f858: DecompressPointer r6
    //     0xc2f858: add             x6, x6, HEAP, lsl #32
    // 0xc2f85c: stur            x6, [fp, #-8]
    // 0xc2f860: r0 = ListTileThemeData()
    //     0xc2f860: bl              #0x853034  ; AllocateListTileThemeDataStub -> ListTileThemeData (size=0x44)
    // 0xc2f864: mov             x1, x0
    // 0xc2f868: ldur            x0, [fp, #-0x30]
    // 0xc2f86c: stur            x1, [fp, #-0x38]
    // 0xc2f870: StoreField: r1->field_f = r0
    //     0xc2f870: stur            w0, [x1, #0xf]
    // 0xc2f874: ldur            x0, [fp, #-0x28]
    // 0xc2f878: StoreField: r1->field_17 = r0
    //     0xc2f878: stur            w0, [x1, #0x17]
    // 0xc2f87c: ldur            x0, [fp, #-0x20]
    // 0xc2f880: StoreField: r1->field_1b = r0
    //     0xc2f880: stur            w0, [x1, #0x1b]
    // 0xc2f884: ldur            x0, [fp, #-0x18]
    // 0xc2f888: StoreField: r1->field_2b = r0
    //     0xc2f888: stur            w0, [x1, #0x2b]
    // 0xc2f88c: ldur            x0, [fp, #-0x10]
    // 0xc2f890: StoreField: r1->field_2f = r0
    //     0xc2f890: stur            w0, [x1, #0x2f]
    // 0xc2f894: ldur            x0, [fp, #-8]
    // 0xc2f898: StoreField: r1->field_33 = r0
    //     0xc2f898: stur            w0, [x1, #0x33]
    // 0xc2f89c: r0 = ListTileTheme()
    //     0xc2f89c: bl              #0x853028  ; AllocateListTileThemeStub -> ListTileTheme (size=0x4c)
    // 0xc2f8a0: ldur            x1, [fp, #-0x38]
    // 0xc2f8a4: StoreField: r0->field_f = r1
    //     0xc2f8a4: stur            w1, [x0, #0xf]
    // 0xc2f8a8: ldr             x1, [fp, #0x10]
    // 0xc2f8ac: StoreField: r0->field_b = r1
    //     0xc2f8ac: stur            w1, [x0, #0xb]
    // 0xc2f8b0: LeaveFrame
    //     0xc2f8b0: mov             SP, fp
    //     0xc2f8b4: ldp             fp, lr, [SP], #0x10
    // 0xc2f8b8: ret
    //     0xc2f8b8: ret             
  }
}

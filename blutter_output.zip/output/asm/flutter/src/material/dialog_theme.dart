// lib: , url: package:flutter/src/material/dialog_theme.dart

// class id: 1049224, size: 0x8
class :: {
}

// class id: 2809, size: 0x30, field offset: 0x8
//   const constructor, 
class DialogTheme extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff16c, size: 0x54
    // 0xaff16c: EnterFrame
    //     0xaff16c: stp             fp, lr, [SP, #-0x10]!
    //     0xaff170: mov             fp, SP
    // 0xaff174: CheckStackOverflow
    //     0xaff174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff178: cmp             SP, x16
    //     0xaff17c: b.ls            #0xaff1b8
    // 0xaff180: ldr             x0, [fp, #0x10]
    // 0xaff184: LoadField: r1 = r0->field_17
    //     0xaff184: ldur            w1, [x0, #0x17]
    // 0xaff188: DecompressPointer r1
    //     0xaff188: add             x1, x1, HEAP, lsl #32
    // 0xaff18c: r0 = LoadClassIdInstr(r1)
    //     0xaff18c: ldur            x0, [x1, #-1]
    //     0xaff190: ubfx            x0, x0, #0xc, #0x14
    // 0xaff194: SaveReg r1
    //     0xaff194: str             x1, [SP, #-8]!
    // 0xaff198: r0 = GDT[cid_x0 + 0x2721]()
    //     0xaff198: mov             x17, #0x2721
    //     0xaff19c: add             lr, x0, x17
    //     0xaff1a0: ldr             lr, [x21, lr, lsl #3]
    //     0xaff1a4: blr             lr
    // 0xaff1a8: add             SP, SP, #8
    // 0xaff1ac: LeaveFrame
    //     0xaff1ac: mov             SP, fp
    //     0xaff1b0: ldp             fp, lr, [SP], #0x10
    // 0xaff1b4: ret
    //     0xaff1b4: ret             
    // 0xaff1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff1b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff1bc: b               #0xaff180
  }
  static _ of(/* No info */) {
    // ** addr: 0xb1f3b0, size: 0x44
    // 0xb1f3b0: EnterFrame
    //     0xb1f3b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1f3b4: mov             fp, SP
    // 0xb1f3b8: CheckStackOverflow
    //     0xb1f3b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1f3bc: cmp             SP, x16
    //     0xb1f3c0: b.ls            #0xb1f3ec
    // 0xb1f3c4: ldr             x16, [fp, #0x10]
    // 0xb1f3c8: SaveReg r16
    //     0xb1f3c8: str             x16, [SP, #-8]!
    // 0xb1f3cc: r0 = of()
    //     0xb1f3cc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1f3d0: add             SP, SP, #8
    // 0xb1f3d4: LoadField: r1 = r0->field_cb
    //     0xb1f3d4: ldur            w1, [x0, #0xcb]
    // 0xb1f3d8: DecompressPointer r1
    //     0xb1f3d8: add             x1, x1, HEAP, lsl #32
    // 0xb1f3dc: mov             x0, x1
    // 0xb1f3e0: LeaveFrame
    //     0xb1f3e0: mov             SP, fp
    //     0xb1f3e4: ldp             fp, lr, [SP], #0x10
    // 0xb1f3e8: ret
    //     0xb1f3e8: ret             
    // 0xb1f3ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1f3ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1f3f0: b               #0xb1f3c4
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf4f08, size: 0x1a4
    // 0xbf4f08: EnterFrame
    //     0xbf4f08: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4f0c: mov             fp, SP
    // 0xbf4f10: AllocStack(0x20)
    //     0xbf4f10: sub             SP, SP, #0x20
    // 0xbf4f14: CheckStackOverflow
    //     0xbf4f14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4f18: cmp             SP, x16
    //     0xbf4f1c: b.ls            #0xbf5094
    // 0xbf4f20: ldr             d0, [fp, #0x10]
    // 0xbf4f24: r0 = inline_Allocate_Double()
    //     0xbf4f24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf4f28: add             x0, x0, #0x10
    //     0xbf4f2c: cmp             x1, x0
    //     0xbf4f30: b.ls            #0xbf509c
    //     0xbf4f34: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf4f38: sub             x0, x0, #0xf
    //     0xbf4f3c: mov             x1, #0xd108
    //     0xbf4f40: movk            x1, #3, lsl #16
    //     0xbf4f44: stur            x1, [x0, #-1]
    // 0xbf4f48: StoreField: r0->field_7 = d0
    //     0xbf4f48: stur            d0, [x0, #7]
    // 0xbf4f4c: stur            x0, [fp, #-8]
    // 0xbf4f50: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4f54: SaveReg r0
    //     0xbf4f54: str             x0, [SP, #-8]!
    // 0xbf4f58: r0 = lerp()
    //     0xbf4f58: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4f5c: add             SP, SP, #0x18
    // 0xbf4f60: ldr             x0, [fp, #0x20]
    // 0xbf4f64: LoadField: r1 = r0->field_b
    //     0xbf4f64: ldur            w1, [x0, #0xb]
    // 0xbf4f68: DecompressPointer r1
    //     0xbf4f68: add             x1, x1, HEAP, lsl #32
    // 0xbf4f6c: ldr             x2, [fp, #0x18]
    // 0xbf4f70: LoadField: r3 = r2->field_b
    //     0xbf4f70: ldur            w3, [x2, #0xb]
    // 0xbf4f74: DecompressPointer r3
    //     0xbf4f74: add             x3, x3, HEAP, lsl #32
    // 0xbf4f78: stp             x3, x1, [SP, #-0x10]!
    // 0xbf4f7c: ldur            x16, [fp, #-8]
    // 0xbf4f80: SaveReg r16
    //     0xbf4f80: str             x16, [SP, #-8]!
    // 0xbf4f84: r0 = lerpDouble()
    //     0xbf4f84: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4f88: add             SP, SP, #0x18
    // 0xbf4f8c: stur            x0, [fp, #-0x10]
    // 0xbf4f90: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4f94: ldur            x16, [fp, #-8]
    // 0xbf4f98: SaveReg r16
    //     0xbf4f98: str             x16, [SP, #-8]!
    // 0xbf4f9c: r0 = lerp()
    //     0xbf4f9c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4fa0: add             SP, SP, #0x18
    // 0xbf4fa4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4fa8: ldur            x16, [fp, #-8]
    // 0xbf4fac: SaveReg r16
    //     0xbf4fac: str             x16, [SP, #-8]!
    // 0xbf4fb0: r0 = lerp()
    //     0xbf4fb0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4fb4: add             SP, SP, #0x18
    // 0xbf4fb8: ldr             x0, [fp, #0x20]
    // 0xbf4fbc: LoadField: r1 = r0->field_17
    //     0xbf4fbc: ldur            w1, [x0, #0x17]
    // 0xbf4fc0: DecompressPointer r1
    //     0xbf4fc0: add             x1, x1, HEAP, lsl #32
    // 0xbf4fc4: ldr             x2, [fp, #0x18]
    // 0xbf4fc8: LoadField: r3 = r2->field_17
    //     0xbf4fc8: ldur            w3, [x2, #0x17]
    // 0xbf4fcc: DecompressPointer r3
    //     0xbf4fcc: add             x3, x3, HEAP, lsl #32
    // 0xbf4fd0: stp             x3, x1, [SP, #-0x10]!
    // 0xbf4fd4: ldr             d0, [fp, #0x10]
    // 0xbf4fd8: SaveReg d0
    //     0xbf4fd8: str             d0, [SP, #-8]!
    // 0xbf4fdc: r0 = lerp()
    //     0xbf4fdc: bl              #0xbecbbc  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerp
    // 0xbf4fe0: add             SP, SP, #0x18
    // 0xbf4fe4: mov             x1, x0
    // 0xbf4fe8: ldr             x0, [fp, #0x20]
    // 0xbf4fec: stur            x1, [fp, #-0x18]
    // 0xbf4ff0: LoadField: r2 = r0->field_1b
    //     0xbf4ff0: ldur            w2, [x0, #0x1b]
    // 0xbf4ff4: DecompressPointer r2
    //     0xbf4ff4: add             x2, x2, HEAP, lsl #32
    // 0xbf4ff8: ldr             x0, [fp, #0x18]
    // 0xbf4ffc: LoadField: r3 = r0->field_1b
    //     0xbf4ffc: ldur            w3, [x0, #0x1b]
    // 0xbf5000: DecompressPointer r3
    //     0xbf5000: add             x3, x3, HEAP, lsl #32
    // 0xbf5004: stp             x3, x2, [SP, #-0x10]!
    // 0xbf5008: ldr             d0, [fp, #0x10]
    // 0xbf500c: SaveReg d0
    //     0xbf500c: str             d0, [SP, #-8]!
    // 0xbf5010: r0 = lerp()
    //     0xbf5010: bl              #0xbefd44  ; [package:flutter/src/painting/alignment.dart] AlignmentGeometry::lerp
    // 0xbf5014: add             SP, SP, #0x18
    // 0xbf5018: stur            x0, [fp, #-0x20]
    // 0xbf501c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5020: ldur            x16, [fp, #-8]
    // 0xbf5024: SaveReg r16
    //     0xbf5024: str             x16, [SP, #-8]!
    // 0xbf5028: r0 = lerp()
    //     0xbf5028: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf502c: add             SP, SP, #0x18
    // 0xbf5030: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5034: ldur            x16, [fp, #-8]
    // 0xbf5038: SaveReg r16
    //     0xbf5038: str             x16, [SP, #-8]!
    // 0xbf503c: r0 = lerp()
    //     0xbf503c: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5040: add             SP, SP, #0x18
    // 0xbf5044: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5048: ldur            x16, [fp, #-8]
    // 0xbf504c: SaveReg r16
    //     0xbf504c: str             x16, [SP, #-8]!
    // 0xbf5050: r0 = lerp()
    //     0xbf5050: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5054: add             SP, SP, #0x18
    // 0xbf5058: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf505c: ldur            x16, [fp, #-8]
    // 0xbf5060: SaveReg r16
    //     0xbf5060: str             x16, [SP, #-8]!
    // 0xbf5064: r0 = lerp()
    //     0xbf5064: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf5068: add             SP, SP, #0x18
    // 0xbf506c: r0 = DialogTheme()
    //     0xbf506c: bl              #0xbf50ac  ; AllocateDialogThemeStub -> DialogTheme (size=0x30)
    // 0xbf5070: ldur            x1, [fp, #-0x10]
    // 0xbf5074: StoreField: r0->field_b = r1
    //     0xbf5074: stur            w1, [x0, #0xb]
    // 0xbf5078: ldur            x1, [fp, #-0x18]
    // 0xbf507c: StoreField: r0->field_17 = r1
    //     0xbf507c: stur            w1, [x0, #0x17]
    // 0xbf5080: ldur            x1, [fp, #-0x20]
    // 0xbf5084: StoreField: r0->field_1b = r1
    //     0xbf5084: stur            w1, [x0, #0x1b]
    // 0xbf5088: LeaveFrame
    //     0xbf5088: mov             SP, fp
    //     0xbf508c: ldp             fp, lr, [SP], #0x10
    // 0xbf5090: ret
    //     0xbf5090: ret             
    // 0xbf5094: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5094: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5098: b               #0xbf4f20
    // 0xbf509c: SaveReg d0
    //     0xbf509c: str             q0, [SP, #-0x10]!
    // 0xbf50a0: r0 = AllocateDouble()
    //     0xbf50a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf50a4: RestoreReg d0
    //     0xbf50a4: ldr             q0, [SP], #0x10
    // 0xbf50a8: b               #0xbf4f48
  }
  _ ==(/* No info */) {
    // ** addr: 0xc878f0, size: 0xac4
    // 0xc878f0: EnterFrame
    //     0xc878f0: stp             fp, lr, [SP, #-0x10]!
    //     0xc878f4: mov             fp, SP
    // 0xc878f8: AllocStack(0x18)
    //     0xc878f8: sub             SP, SP, #0x18
    // 0xc878fc: CheckStackOverflow
    //     0xc878fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc87900: cmp             SP, x16
    //     0xc87904: b.ls            #0xc883ac
    // 0xc87908: ldr             x1, [fp, #0x10]
    // 0xc8790c: cmp             w1, NULL
    // 0xc87910: b.ne            #0xc87924
    // 0xc87914: r0 = false
    //     0xc87914: add             x0, NULL, #0x30  ; false
    // 0xc87918: LeaveFrame
    //     0xc87918: mov             SP, fp
    //     0xc8791c: ldp             fp, lr, [SP], #0x10
    // 0xc87920: ret
    //     0xc87920: ret             
    // 0xc87924: ldr             x2, [fp, #0x18]
    // 0xc87928: cmp             w2, w1
    // 0xc8792c: b.ne            #0xc87940
    // 0xc87930: r0 = true
    //     0xc87930: add             x0, NULL, #0x20  ; true
    // 0xc87934: LeaveFrame
    //     0xc87934: mov             SP, fp
    //     0xc87938: ldp             fp, lr, [SP], #0x10
    // 0xc8793c: ret
    //     0xc8793c: ret             
    // 0xc87940: r0 = 59
    //     0xc87940: mov             x0, #0x3b
    // 0xc87944: branchIfSmi(r1, 0xc87950)
    //     0xc87944: tbz             w1, #0, #0xc87950
    // 0xc87948: r0 = LoadClassIdInstr(r1)
    //     0xc87948: ldur            x0, [x1, #-1]
    //     0xc8794c: ubfx            x0, x0, #0xc, #0x14
    // 0xc87950: SaveReg r1
    //     0xc87950: str             x1, [SP, #-8]!
    // 0xc87954: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc87954: mov             x17, #0x57c5
    //     0xc87958: add             lr, x0, x17
    //     0xc8795c: ldr             lr, [x21, lr, lsl #3]
    //     0xc87960: blr             lr
    // 0xc87964: add             SP, SP, #8
    // 0xc87968: stur            x0, [fp, #-8]
    // 0xc8796c: ldr             x16, [fp, #0x18]
    // 0xc87970: SaveReg r16
    //     0xc87970: str             x16, [SP, #-8]!
    // 0xc87974: r0 = runtimeType()
    //     0xc87974: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc87978: add             SP, SP, #8
    // 0xc8797c: mov             x1, x0
    // 0xc87980: ldur            x0, [fp, #-8]
    // 0xc87984: r2 = LoadClassIdInstr(r0)
    //     0xc87984: ldur            x2, [x0, #-1]
    //     0xc87988: ubfx            x2, x2, #0xc, #0x14
    // 0xc8798c: stp             x1, x0, [SP, #-0x10]!
    // 0xc87990: mov             x0, x2
    // 0xc87994: mov             lr, x0
    // 0xc87998: ldr             lr, [x21, lr, lsl #3]
    // 0xc8799c: blr             lr
    // 0xc879a0: add             SP, SP, #0x10
    // 0xc879a4: tbz             w0, #4, #0xc879b8
    // 0xc879a8: r0 = false
    //     0xc879a8: add             x0, NULL, #0x30  ; false
    // 0xc879ac: LeaveFrame
    //     0xc879ac: mov             SP, fp
    //     0xc879b0: ldp             fp, lr, [SP], #0x10
    // 0xc879b4: ret
    //     0xc879b4: ret             
    // 0xc879b8: ldr             x1, [fp, #0x10]
    // 0xc879bc: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc879bc: mov             x0, #0x76
    //     0xc879c0: tbz             w1, #0, #0xc879d0
    //     0xc879c4: ldur            x0, [x1, #-1]
    //     0xc879c8: ubfx            x0, x0, #0xc, #0x14
    //     0xc879cc: lsl             x0, x0, #1
    // 0xc879d0: stur            x0, [fp, #-8]
    // 0xc879d4: r2 = LoadInt32Instr(r0)
    //     0xc879d4: sbfx            x2, x0, #1, #0x1f
    // 0xc879d8: cmp             x2, #0xaf9
    // 0xc879dc: b.lt            #0xc8839c
    // 0xc879e0: cmp             x2, #0xafc
    // 0xc879e4: b.gt            #0xc8839c
    // 0xc879e8: r17 = 5618
    //     0xc879e8: mov             x17, #0x15f2
    // 0xc879ec: cmp             w0, w17
    // 0xc879f0: b.ne            #0xc87a04
    // 0xc879f4: LoadField: r2 = r1->field_7
    //     0xc879f4: ldur            w2, [x1, #7]
    // 0xc879f8: DecompressPointer r2
    //     0xc879f8: add             x2, x2, HEAP, lsl #32
    // 0xc879fc: mov             x0, x2
    // 0xc87a00: b               #0xc87a9c
    // 0xc87a04: r17 = 5620
    //     0xc87a04: mov             x17, #0x15f4
    // 0xc87a08: cmp             w0, w17
    // 0xc87a0c: b.ne            #0xc87a38
    // 0xc87a10: LoadField: r2 = r1->field_2f
    //     0xc87a10: ldur            w2, [x1, #0x2f]
    // 0xc87a14: DecompressPointer r2
    //     0xc87a14: add             x2, x2, HEAP, lsl #32
    // 0xc87a18: SaveReg r2
    //     0xc87a18: str             x2, [SP, #-8]!
    // 0xc87a1c: r0 = of()
    //     0xc87a1c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc87a20: add             SP, SP, #8
    // 0xc87a24: LoadField: r1 = r0->field_3f
    //     0xc87a24: ldur            w1, [x0, #0x3f]
    // 0xc87a28: DecompressPointer r1
    //     0xc87a28: add             x1, x1, HEAP, lsl #32
    // 0xc87a2c: LoadField: r0 = r1->field_53
    //     0xc87a2c: ldur            w0, [x1, #0x53]
    // 0xc87a30: DecompressPointer r0
    //     0xc87a30: add             x0, x0, HEAP, lsl #32
    // 0xc87a34: b               #0xc87a9c
    // 0xc87a38: r17 = 5622
    //     0xc87a38: mov             x17, #0x15f6
    // 0xc87a3c: cmp             w0, w17
    // 0xc87a40: b.ne            #0xc87a78
    // 0xc87a44: ldr             x1, [fp, #0x10]
    // 0xc87a48: LoadField: r0 = r1->field_33
    //     0xc87a48: ldur            w0, [x1, #0x33]
    // 0xc87a4c: DecompressPointer r0
    //     0xc87a4c: add             x0, x0, HEAP, lsl #32
    // 0xc87a50: r16 = Sentinel
    //     0xc87a50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc87a54: cmp             w0, w16
    // 0xc87a58: b.ne            #0xc87a68
    // 0xc87a5c: r2 = _colors
    //     0xc87a5c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xc87a60: ldr             x2, [x2, #0x3b8]
    // 0xc87a64: r0 = InitLateFinalInstanceField()
    //     0xc87a64: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc87a68: LoadField: r1 = r0->field_53
    //     0xc87a68: ldur            w1, [x0, #0x53]
    // 0xc87a6c: DecompressPointer r1
    //     0xc87a6c: add             x1, x1, HEAP, lsl #32
    // 0xc87a70: mov             x0, x1
    // 0xc87a74: b               #0xc87a9c
    // 0xc87a78: ldr             x1, [fp, #0x10]
    // 0xc87a7c: LoadField: r0 = r1->field_2f
    //     0xc87a7c: ldur            w0, [x1, #0x2f]
    // 0xc87a80: DecompressPointer r0
    //     0xc87a80: add             x0, x0, HEAP, lsl #32
    // 0xc87a84: SaveReg r0
    //     0xc87a84: str             x0, [SP, #-8]!
    // 0xc87a88: r0 = of()
    //     0xc87a88: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc87a8c: add             SP, SP, #8
    // 0xc87a90: LoadField: r1 = r0->field_43
    //     0xc87a90: ldur            w1, [x0, #0x43]
    // 0xc87a94: DecompressPointer r1
    //     0xc87a94: add             x1, x1, HEAP, lsl #32
    // 0xc87a98: mov             x0, x1
    // 0xc87a9c: ldr             x1, [fp, #0x18]
    // 0xc87aa0: stur            x0, [fp, #-0x18]
    // 0xc87aa4: r2 = LoadClassIdInstr(r1)
    //     0xc87aa4: ldur            x2, [x1, #-1]
    //     0xc87aa8: ubfx            x2, x2, #0xc, #0x14
    // 0xc87aac: lsl             x2, x2, #1
    // 0xc87ab0: stur            x2, [fp, #-0x10]
    // 0xc87ab4: r17 = 5618
    //     0xc87ab4: mov             x17, #0x15f2
    // 0xc87ab8: cmp             w2, w17
    // 0xc87abc: b.ne            #0xc87ad0
    // 0xc87ac0: LoadField: r3 = r1->field_7
    //     0xc87ac0: ldur            w3, [x1, #7]
    // 0xc87ac4: DecompressPointer r3
    //     0xc87ac4: add             x3, x3, HEAP, lsl #32
    // 0xc87ac8: mov             x1, x3
    // 0xc87acc: b               #0xc87b74
    // 0xc87ad0: r17 = 5620
    //     0xc87ad0: mov             x17, #0x15f4
    // 0xc87ad4: cmp             w2, w17
    // 0xc87ad8: b.ne            #0xc87b0c
    // 0xc87adc: LoadField: r3 = r1->field_2f
    //     0xc87adc: ldur            w3, [x1, #0x2f]
    // 0xc87ae0: DecompressPointer r3
    //     0xc87ae0: add             x3, x3, HEAP, lsl #32
    // 0xc87ae4: SaveReg r3
    //     0xc87ae4: str             x3, [SP, #-8]!
    // 0xc87ae8: r0 = of()
    //     0xc87ae8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc87aec: add             SP, SP, #8
    // 0xc87af0: LoadField: r1 = r0->field_3f
    //     0xc87af0: ldur            w1, [x0, #0x3f]
    // 0xc87af4: DecompressPointer r1
    //     0xc87af4: add             x1, x1, HEAP, lsl #32
    // 0xc87af8: LoadField: r0 = r1->field_53
    //     0xc87af8: ldur            w0, [x1, #0x53]
    // 0xc87afc: DecompressPointer r0
    //     0xc87afc: add             x0, x0, HEAP, lsl #32
    // 0xc87b00: mov             x1, x0
    // 0xc87b04: ldur            x0, [fp, #-0x18]
    // 0xc87b08: b               #0xc87b74
    // 0xc87b0c: mov             x0, x2
    // 0xc87b10: r17 = 5622
    //     0xc87b10: mov             x17, #0x15f6
    // 0xc87b14: cmp             w0, w17
    // 0xc87b18: b.ne            #0xc87b50
    // 0xc87b1c: ldr             x1, [fp, #0x18]
    // 0xc87b20: LoadField: r0 = r1->field_33
    //     0xc87b20: ldur            w0, [x1, #0x33]
    // 0xc87b24: DecompressPointer r0
    //     0xc87b24: add             x0, x0, HEAP, lsl #32
    // 0xc87b28: r16 = Sentinel
    //     0xc87b28: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc87b2c: cmp             w0, w16
    // 0xc87b30: b.ne            #0xc87b40
    // 0xc87b34: r2 = _colors
    //     0xc87b34: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xc87b38: ldr             x2, [x2, #0x3b8]
    // 0xc87b3c: r0 = InitLateFinalInstanceField()
    //     0xc87b3c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc87b40: LoadField: r1 = r0->field_53
    //     0xc87b40: ldur            w1, [x0, #0x53]
    // 0xc87b44: DecompressPointer r1
    //     0xc87b44: add             x1, x1, HEAP, lsl #32
    // 0xc87b48: ldur            x0, [fp, #-0x18]
    // 0xc87b4c: b               #0xc87b74
    // 0xc87b50: ldr             x1, [fp, #0x18]
    // 0xc87b54: LoadField: r0 = r1->field_2f
    //     0xc87b54: ldur            w0, [x1, #0x2f]
    // 0xc87b58: DecompressPointer r0
    //     0xc87b58: add             x0, x0, HEAP, lsl #32
    // 0xc87b5c: SaveReg r0
    //     0xc87b5c: str             x0, [SP, #-8]!
    // 0xc87b60: r0 = of()
    //     0xc87b60: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc87b64: add             SP, SP, #8
    // 0xc87b68: LoadField: r1 = r0->field_43
    //     0xc87b68: ldur            w1, [x0, #0x43]
    // 0xc87b6c: DecompressPointer r1
    //     0xc87b6c: add             x1, x1, HEAP, lsl #32
    // 0xc87b70: ldur            x0, [fp, #-0x18]
    // 0xc87b74: r2 = LoadClassIdInstr(r0)
    //     0xc87b74: ldur            x2, [x0, #-1]
    //     0xc87b78: ubfx            x2, x2, #0xc, #0x14
    // 0xc87b7c: stp             x1, x0, [SP, #-0x10]!
    // 0xc87b80: mov             x0, x2
    // 0xc87b84: mov             lr, x0
    // 0xc87b88: ldr             lr, [x21, lr, lsl #3]
    // 0xc87b8c: blr             lr
    // 0xc87b90: add             SP, SP, #0x10
    // 0xc87b94: tbnz            w0, #4, #0xc8839c
    // 0xc87b98: ldr             x1, [fp, #0x18]
    // 0xc87b9c: ldr             x2, [fp, #0x10]
    // 0xc87ba0: LoadField: r0 = r2->field_b
    //     0xc87ba0: ldur            w0, [x2, #0xb]
    // 0xc87ba4: DecompressPointer r0
    //     0xc87ba4: add             x0, x0, HEAP, lsl #32
    // 0xc87ba8: LoadField: r3 = r1->field_b
    //     0xc87ba8: ldur            w3, [x1, #0xb]
    // 0xc87bac: DecompressPointer r3
    //     0xc87bac: add             x3, x3, HEAP, lsl #32
    // 0xc87bb0: r4 = LoadClassIdInstr(r0)
    //     0xc87bb0: ldur            x4, [x0, #-1]
    //     0xc87bb4: ubfx            x4, x4, #0xc, #0x14
    // 0xc87bb8: stp             x3, x0, [SP, #-0x10]!
    // 0xc87bbc: mov             x0, x4
    // 0xc87bc0: mov             lr, x0
    // 0xc87bc4: ldr             lr, [x21, lr, lsl #3]
    // 0xc87bc8: blr             lr
    // 0xc87bcc: add             SP, SP, #0x10
    // 0xc87bd0: tbnz            w0, #4, #0xc8839c
    // 0xc87bd4: ldur            x0, [fp, #-8]
    // 0xc87bd8: r17 = 5620
    //     0xc87bd8: mov             x17, #0x15f4
    // 0xc87bdc: cmp             w0, w17
    // 0xc87be0: b.gt            #0xc87c0c
    // 0xc87be4: r17 = 5618
    //     0xc87be4: mov             x17, #0x15f2
    // 0xc87be8: cmp             w0, w17
    // 0xc87bec: b.lt            #0xc87c04
    // 0xc87bf0: ldr             x1, [fp, #0x10]
    // 0xc87bf4: LoadField: r2 = r1->field_f
    //     0xc87bf4: ldur            w2, [x1, #0xf]
    // 0xc87bf8: DecompressPointer r2
    //     0xc87bf8: add             x2, x2, HEAP, lsl #32
    // 0xc87bfc: mov             x1, x2
    // 0xc87c00: b               #0xc87c44
    // 0xc87c04: ldr             x1, [fp, #0x10]
    // 0xc87c08: b               #0xc87c10
    // 0xc87c0c: ldr             x1, [fp, #0x10]
    // 0xc87c10: r17 = 5622
    //     0xc87c10: mov             x17, #0x15f6
    // 0xc87c14: cmp             w0, w17
    // 0xc87c18: b.ne            #0xc87c28
    // 0xc87c1c: r1 = Instance_Color
    //     0xc87c1c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc87c20: ldr             x1, [x1, #0xc08]
    // 0xc87c24: b               #0xc87c44
    // 0xc87c28: LoadField: r2 = r1->field_2f
    //     0xc87c28: ldur            w2, [x1, #0x2f]
    // 0xc87c2c: DecompressPointer r2
    //     0xc87c2c: add             x2, x2, HEAP, lsl #32
    // 0xc87c30: SaveReg r2
    //     0xc87c30: str             x2, [SP, #-8]!
    // 0xc87c34: r0 = of()
    //     0xc87c34: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc87c38: add             SP, SP, #8
    // 0xc87c3c: LoadField: r1 = r0->field_7b
    //     0xc87c3c: ldur            w1, [x0, #0x7b]
    // 0xc87c40: DecompressPointer r1
    //     0xc87c40: add             x1, x1, HEAP, lsl #32
    // 0xc87c44: ldur            x0, [fp, #-0x10]
    // 0xc87c48: stur            x1, [fp, #-0x18]
    // 0xc87c4c: r17 = 5620
    //     0xc87c4c: mov             x17, #0x15f4
    // 0xc87c50: cmp             w0, w17
    // 0xc87c54: b.gt            #0xc87c84
    // 0xc87c58: r17 = 5618
    //     0xc87c58: mov             x17, #0x15f2
    // 0xc87c5c: cmp             w0, w17
    // 0xc87c60: b.lt            #0xc87c7c
    // 0xc87c64: ldr             x2, [fp, #0x18]
    // 0xc87c68: LoadField: r3 = r2->field_f
    //     0xc87c68: ldur            w3, [x2, #0xf]
    // 0xc87c6c: DecompressPointer r3
    //     0xc87c6c: add             x3, x3, HEAP, lsl #32
    // 0xc87c70: mov             x0, x1
    // 0xc87c74: mov             x1, x3
    // 0xc87c78: b               #0xc87cc4
    // 0xc87c7c: ldr             x2, [fp, #0x18]
    // 0xc87c80: b               #0xc87c88
    // 0xc87c84: ldr             x2, [fp, #0x18]
    // 0xc87c88: r17 = 5622
    //     0xc87c88: mov             x17, #0x15f6
    // 0xc87c8c: cmp             w0, w17
    // 0xc87c90: b.ne            #0xc87ca4
    // 0xc87c94: mov             x0, x1
    // 0xc87c98: r1 = Instance_Color
    //     0xc87c98: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xc87c9c: ldr             x1, [x1, #0xc08]
    // 0xc87ca0: b               #0xc87cc4
    // 0xc87ca4: LoadField: r3 = r2->field_2f
    //     0xc87ca4: ldur            w3, [x2, #0x2f]
    // 0xc87ca8: DecompressPointer r3
    //     0xc87ca8: add             x3, x3, HEAP, lsl #32
    // 0xc87cac: SaveReg r3
    //     0xc87cac: str             x3, [SP, #-8]!
    // 0xc87cb0: r0 = of()
    //     0xc87cb0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc87cb4: add             SP, SP, #8
    // 0xc87cb8: LoadField: r1 = r0->field_7b
    //     0xc87cb8: ldur            w1, [x0, #0x7b]
    // 0xc87cbc: DecompressPointer r1
    //     0xc87cbc: add             x1, x1, HEAP, lsl #32
    // 0xc87cc0: ldur            x0, [fp, #-0x18]
    // 0xc87cc4: r2 = LoadClassIdInstr(r0)
    //     0xc87cc4: ldur            x2, [x0, #-1]
    //     0xc87cc8: ubfx            x2, x2, #0xc, #0x14
    // 0xc87ccc: stp             x1, x0, [SP, #-0x10]!
    // 0xc87cd0: mov             x0, x2
    // 0xc87cd4: mov             lr, x0
    // 0xc87cd8: ldr             lr, [x21, lr, lsl #3]
    // 0xc87cdc: blr             lr
    // 0xc87ce0: add             SP, SP, #0x10
    // 0xc87ce4: tbnz            w0, #4, #0xc8839c
    // 0xc87ce8: ldur            x0, [fp, #-8]
    // 0xc87cec: r17 = 5620
    //     0xc87cec: mov             x17, #0x15f4
    // 0xc87cf0: cmp             w0, w17
    // 0xc87cf4: b.gt            #0xc87d04
    // 0xc87cf8: r17 = 5618
    //     0xc87cf8: mov             x17, #0x15f2
    // 0xc87cfc: cmp             w0, w17
    // 0xc87d00: b.ge            #0xc87d64
    // 0xc87d04: r17 = 5622
    //     0xc87d04: mov             x17, #0x15f6
    // 0xc87d08: cmp             w0, w17
    // 0xc87d0c: b.ne            #0xc87d64
    // 0xc87d10: ldr             x1, [fp, #0x10]
    // 0xc87d14: LoadField: r0 = r1->field_33
    //     0xc87d14: ldur            w0, [x1, #0x33]
    // 0xc87d18: DecompressPointer r0
    //     0xc87d18: add             x0, x0, HEAP, lsl #32
    // 0xc87d1c: r16 = Sentinel
    //     0xc87d1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc87d20: cmp             w0, w16
    // 0xc87d24: b.ne            #0xc87d34
    // 0xc87d28: r2 = _colors
    //     0xc87d28: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xc87d2c: ldr             x2, [x2, #0x3b8]
    // 0xc87d30: r0 = InitLateFinalInstanceField()
    //     0xc87d30: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc87d34: LoadField: r1 = r0->field_7f
    //     0xc87d34: ldur            w1, [x0, #0x7f]
    // 0xc87d38: DecompressPointer r1
    //     0xc87d38: add             x1, x1, HEAP, lsl #32
    // 0xc87d3c: cmp             w1, NULL
    // 0xc87d40: b.ne            #0xc87d54
    // 0xc87d44: LoadField: r1 = r0->field_b
    //     0xc87d44: ldur            w1, [x0, #0xb]
    // 0xc87d48: DecompressPointer r1
    //     0xc87d48: add             x1, x1, HEAP, lsl #32
    // 0xc87d4c: mov             x0, x1
    // 0xc87d50: b               #0xc87d58
    // 0xc87d54: mov             x0, x1
    // 0xc87d58: mov             x3, x0
    // 0xc87d5c: ldr             x0, [fp, #0x10]
    // 0xc87d60: b               #0xc87d74
    // 0xc87d64: ldr             x0, [fp, #0x10]
    // 0xc87d68: LoadField: r1 = r0->field_13
    //     0xc87d68: ldur            w1, [x0, #0x13]
    // 0xc87d6c: DecompressPointer r1
    //     0xc87d6c: add             x1, x1, HEAP, lsl #32
    // 0xc87d70: mov             x3, x1
    // 0xc87d74: ldur            x2, [fp, #-0x10]
    // 0xc87d78: stur            x3, [fp, #-0x18]
    // 0xc87d7c: r17 = 5620
    //     0xc87d7c: mov             x17, #0x15f4
    // 0xc87d80: cmp             w2, w17
    // 0xc87d84: b.gt            #0xc87d94
    // 0xc87d88: r17 = 5618
    //     0xc87d88: mov             x17, #0x15f2
    // 0xc87d8c: cmp             w2, w17
    // 0xc87d90: b.ge            #0xc87df4
    // 0xc87d94: r17 = 5622
    //     0xc87d94: mov             x17, #0x15f6
    // 0xc87d98: cmp             w2, w17
    // 0xc87d9c: b.ne            #0xc87df4
    // 0xc87da0: ldr             x1, [fp, #0x18]
    // 0xc87da4: LoadField: r0 = r1->field_33
    //     0xc87da4: ldur            w0, [x1, #0x33]
    // 0xc87da8: DecompressPointer r0
    //     0xc87da8: add             x0, x0, HEAP, lsl #32
    // 0xc87dac: r16 = Sentinel
    //     0xc87dac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc87db0: cmp             w0, w16
    // 0xc87db4: b.ne            #0xc87dc4
    // 0xc87db8: r2 = _colors
    //     0xc87db8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xc87dbc: ldr             x2, [x2, #0x3b8]
    // 0xc87dc0: r0 = InitLateFinalInstanceField()
    //     0xc87dc0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc87dc4: LoadField: r1 = r0->field_7f
    //     0xc87dc4: ldur            w1, [x0, #0x7f]
    // 0xc87dc8: DecompressPointer r1
    //     0xc87dc8: add             x1, x1, HEAP, lsl #32
    // 0xc87dcc: cmp             w1, NULL
    // 0xc87dd0: b.ne            #0xc87de4
    // 0xc87dd4: LoadField: r1 = r0->field_b
    //     0xc87dd4: ldur            w1, [x0, #0xb]
    // 0xc87dd8: DecompressPointer r1
    //     0xc87dd8: add             x1, x1, HEAP, lsl #32
    // 0xc87ddc: mov             x0, x1
    // 0xc87de0: b               #0xc87de8
    // 0xc87de4: mov             x0, x1
    // 0xc87de8: mov             x2, x0
    // 0xc87dec: ldr             x1, [fp, #0x18]
    // 0xc87df0: b               #0xc87e04
    // 0xc87df4: ldr             x1, [fp, #0x18]
    // 0xc87df8: LoadField: r0 = r1->field_13
    //     0xc87df8: ldur            w0, [x1, #0x13]
    // 0xc87dfc: DecompressPointer r0
    //     0xc87dfc: add             x0, x0, HEAP, lsl #32
    // 0xc87e00: mov             x2, x0
    // 0xc87e04: ldur            x0, [fp, #-0x18]
    // 0xc87e08: r3 = LoadClassIdInstr(r0)
    //     0xc87e08: ldur            x3, [x0, #-1]
    //     0xc87e0c: ubfx            x3, x3, #0xc, #0x14
    // 0xc87e10: stp             x2, x0, [SP, #-0x10]!
    // 0xc87e14: mov             x0, x3
    // 0xc87e18: mov             lr, x0
    // 0xc87e1c: ldr             lr, [x21, lr, lsl #3]
    // 0xc87e20: blr             lr
    // 0xc87e24: add             SP, SP, #0x10
    // 0xc87e28: tbnz            w0, #4, #0xc8839c
    // 0xc87e2c: ldr             x1, [fp, #0x18]
    // 0xc87e30: ldr             x2, [fp, #0x10]
    // 0xc87e34: LoadField: r0 = r2->field_17
    //     0xc87e34: ldur            w0, [x2, #0x17]
    // 0xc87e38: DecompressPointer r0
    //     0xc87e38: add             x0, x0, HEAP, lsl #32
    // 0xc87e3c: LoadField: r3 = r1->field_17
    //     0xc87e3c: ldur            w3, [x1, #0x17]
    // 0xc87e40: DecompressPointer r3
    //     0xc87e40: add             x3, x3, HEAP, lsl #32
    // 0xc87e44: r4 = LoadClassIdInstr(r0)
    //     0xc87e44: ldur            x4, [x0, #-1]
    //     0xc87e48: ubfx            x4, x4, #0xc, #0x14
    // 0xc87e4c: stp             x3, x0, [SP, #-0x10]!
    // 0xc87e50: mov             x0, x4
    // 0xc87e54: mov             lr, x0
    // 0xc87e58: ldr             lr, [x21, lr, lsl #3]
    // 0xc87e5c: blr             lr
    // 0xc87e60: add             SP, SP, #0x10
    // 0xc87e64: tbnz            w0, #4, #0xc8839c
    // 0xc87e68: ldr             x1, [fp, #0x18]
    // 0xc87e6c: ldr             x2, [fp, #0x10]
    // 0xc87e70: LoadField: r0 = r2->field_1b
    //     0xc87e70: ldur            w0, [x2, #0x1b]
    // 0xc87e74: DecompressPointer r0
    //     0xc87e74: add             x0, x0, HEAP, lsl #32
    // 0xc87e78: LoadField: r3 = r1->field_1b
    //     0xc87e78: ldur            w3, [x1, #0x1b]
    // 0xc87e7c: DecompressPointer r3
    //     0xc87e7c: add             x3, x3, HEAP, lsl #32
    // 0xc87e80: r4 = LoadClassIdInstr(r0)
    //     0xc87e80: ldur            x4, [x0, #-1]
    //     0xc87e84: ubfx            x4, x4, #0xc, #0x14
    // 0xc87e88: stp             x3, x0, [SP, #-0x10]!
    // 0xc87e8c: mov             x0, x4
    // 0xc87e90: mov             lr, x0
    // 0xc87e94: ldr             lr, [x21, lr, lsl #3]
    // 0xc87e98: blr             lr
    // 0xc87e9c: add             SP, SP, #0x10
    // 0xc87ea0: tbnz            w0, #4, #0xc8839c
    // 0xc87ea4: ldur            x0, [fp, #-8]
    // 0xc87ea8: r17 = 5620
    //     0xc87ea8: mov             x17, #0x15f4
    // 0xc87eac: cmp             w0, w17
    // 0xc87eb0: b.gt            #0xc87ee0
    // 0xc87eb4: r17 = 5618
    //     0xc87eb4: mov             x17, #0x15f2
    // 0xc87eb8: cmp             w0, w17
    // 0xc87ebc: b.lt            #0xc87ed8
    // 0xc87ec0: ldr             x2, [fp, #0x10]
    // 0xc87ec4: LoadField: r1 = r2->field_2b
    //     0xc87ec4: ldur            w1, [x2, #0x2b]
    // 0xc87ec8: DecompressPointer r1
    //     0xc87ec8: add             x1, x1, HEAP, lsl #32
    // 0xc87ecc: mov             x3, x1
    // 0xc87ed0: mov             x0, x2
    // 0xc87ed4: b               #0xc87f40
    // 0xc87ed8: ldr             x2, [fp, #0x10]
    // 0xc87edc: b               #0xc87ee4
    // 0xc87ee0: ldr             x2, [fp, #0x10]
    // 0xc87ee4: r17 = 5622
    //     0xc87ee4: mov             x17, #0x15f6
    // 0xc87ee8: cmp             w0, w17
    // 0xc87eec: b.ne            #0xc87f28
    // 0xc87ef0: mov             x1, x2
    // 0xc87ef4: LoadField: r0 = r1->field_33
    //     0xc87ef4: ldur            w0, [x1, #0x33]
    // 0xc87ef8: DecompressPointer r0
    //     0xc87ef8: add             x0, x0, HEAP, lsl #32
    // 0xc87efc: r16 = Sentinel
    //     0xc87efc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc87f00: cmp             w0, w16
    // 0xc87f04: b.ne            #0xc87f14
    // 0xc87f08: r2 = _colors
    //     0xc87f08: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xc87f0c: ldr             x2, [x2, #0x3b8]
    // 0xc87f10: r0 = InitLateFinalInstanceField()
    //     0xc87f10: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc87f14: LoadField: r1 = r0->field_1b
    //     0xc87f14: ldur            w1, [x0, #0x1b]
    // 0xc87f18: DecompressPointer r1
    //     0xc87f18: add             x1, x1, HEAP, lsl #32
    // 0xc87f1c: mov             x3, x1
    // 0xc87f20: ldr             x0, [fp, #0x10]
    // 0xc87f24: b               #0xc87f40
    // 0xc87f28: mov             x0, x2
    // 0xc87f2c: LoadField: r1 = r0->field_37
    //     0xc87f2c: ldur            w1, [x0, #0x37]
    // 0xc87f30: DecompressPointer r1
    //     0xc87f30: add             x1, x1, HEAP, lsl #32
    // 0xc87f34: LoadField: r2 = r1->field_1b
    //     0xc87f34: ldur            w2, [x1, #0x1b]
    // 0xc87f38: DecompressPointer r2
    //     0xc87f38: add             x2, x2, HEAP, lsl #32
    // 0xc87f3c: mov             x3, x2
    // 0xc87f40: ldur            x2, [fp, #-0x10]
    // 0xc87f44: stur            x3, [fp, #-0x18]
    // 0xc87f48: r17 = 5620
    //     0xc87f48: mov             x17, #0x15f4
    // 0xc87f4c: cmp             w2, w17
    // 0xc87f50: b.gt            #0xc87f84
    // 0xc87f54: r17 = 5618
    //     0xc87f54: mov             x17, #0x15f2
    // 0xc87f58: cmp             w2, w17
    // 0xc87f5c: b.lt            #0xc87f7c
    // 0xc87f60: ldr             x4, [fp, #0x18]
    // 0xc87f64: LoadField: r1 = r4->field_2b
    //     0xc87f64: ldur            w1, [x4, #0x2b]
    // 0xc87f68: DecompressPointer r1
    //     0xc87f68: add             x1, x1, HEAP, lsl #32
    // 0xc87f6c: mov             x2, x1
    // 0xc87f70: mov             x1, x4
    // 0xc87f74: mov             x0, x3
    // 0xc87f78: b               #0xc87fe8
    // 0xc87f7c: ldr             x4, [fp, #0x18]
    // 0xc87f80: b               #0xc87f88
    // 0xc87f84: ldr             x4, [fp, #0x18]
    // 0xc87f88: r17 = 5622
    //     0xc87f88: mov             x17, #0x15f6
    // 0xc87f8c: cmp             w2, w17
    // 0xc87f90: b.ne            #0xc87fd0
    // 0xc87f94: mov             x1, x4
    // 0xc87f98: LoadField: r0 = r1->field_33
    //     0xc87f98: ldur            w0, [x1, #0x33]
    // 0xc87f9c: DecompressPointer r0
    //     0xc87f9c: add             x0, x0, HEAP, lsl #32
    // 0xc87fa0: r16 = Sentinel
    //     0xc87fa0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc87fa4: cmp             w0, w16
    // 0xc87fa8: b.ne            #0xc87fb8
    // 0xc87fac: r2 = _colors
    //     0xc87fac: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3b8] Field <_DialogDefaultsM3@724506021._colors@724506021>: late final (offset: 0x34)
    //     0xc87fb0: ldr             x2, [x2, #0x3b8]
    // 0xc87fb4: r0 = InitLateFinalInstanceField()
    //     0xc87fb4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc87fb8: LoadField: r1 = r0->field_1b
    //     0xc87fb8: ldur            w1, [x0, #0x1b]
    // 0xc87fbc: DecompressPointer r1
    //     0xc87fbc: add             x1, x1, HEAP, lsl #32
    // 0xc87fc0: mov             x2, x1
    // 0xc87fc4: ldr             x1, [fp, #0x18]
    // 0xc87fc8: ldur            x0, [fp, #-0x18]
    // 0xc87fcc: b               #0xc87fe8
    // 0xc87fd0: mov             x1, x4
    // 0xc87fd4: LoadField: r0 = r1->field_37
    //     0xc87fd4: ldur            w0, [x1, #0x37]
    // 0xc87fd8: DecompressPointer r0
    //     0xc87fd8: add             x0, x0, HEAP, lsl #32
    // 0xc87fdc: LoadField: r2 = r0->field_1b
    //     0xc87fdc: ldur            w2, [x0, #0x1b]
    // 0xc87fe0: DecompressPointer r2
    //     0xc87fe0: add             x2, x2, HEAP, lsl #32
    // 0xc87fe4: ldur            x0, [fp, #-0x18]
    // 0xc87fe8: r3 = LoadClassIdInstr(r0)
    //     0xc87fe8: ldur            x3, [x0, #-1]
    //     0xc87fec: ubfx            x3, x3, #0xc, #0x14
    // 0xc87ff0: stp             x2, x0, [SP, #-0x10]!
    // 0xc87ff4: mov             x0, x3
    // 0xc87ff8: mov             lr, x0
    // 0xc87ffc: ldr             lr, [x21, lr, lsl #3]
    // 0xc88000: blr             lr
    // 0xc88004: add             SP, SP, #0x10
    // 0xc88008: tbnz            w0, #4, #0xc8839c
    // 0xc8800c: ldur            x0, [fp, #-8]
    // 0xc88010: r17 = 5620
    //     0xc88010: mov             x17, #0x15f4
    // 0xc88014: cmp             w0, w17
    // 0xc88018: b.gt            #0xc88048
    // 0xc8801c: r17 = 5618
    //     0xc8801c: mov             x17, #0x15f2
    // 0xc88020: cmp             w0, w17
    // 0xc88024: b.lt            #0xc88040
    // 0xc88028: ldr             x2, [fp, #0x10]
    // 0xc8802c: LoadField: r1 = r2->field_1f
    //     0xc8802c: ldur            w1, [x2, #0x1f]
    // 0xc88030: DecompressPointer r1
    //     0xc88030: add             x1, x1, HEAP, lsl #32
    // 0xc88034: mov             x3, x1
    // 0xc88038: mov             x0, x2
    // 0xc8803c: b               #0xc880a8
    // 0xc88040: ldr             x2, [fp, #0x10]
    // 0xc88044: b               #0xc8804c
    // 0xc88048: ldr             x2, [fp, #0x10]
    // 0xc8804c: r17 = 5622
    //     0xc8804c: mov             x17, #0x15f6
    // 0xc88050: cmp             w0, w17
    // 0xc88054: b.ne            #0xc88090
    // 0xc88058: mov             x1, x2
    // 0xc8805c: LoadField: r0 = r1->field_37
    //     0xc8805c: ldur            w0, [x1, #0x37]
    // 0xc88060: DecompressPointer r0
    //     0xc88060: add             x0, x0, HEAP, lsl #32
    // 0xc88064: r16 = Sentinel
    //     0xc88064: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc88068: cmp             w0, w16
    // 0xc8806c: b.ne            #0xc8807c
    // 0xc88070: r2 = _textTheme
    //     0xc88070: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3c0] Field <_DialogDefaultsM3@724506021._textTheme@724506021>: late final (offset: 0x38)
    //     0xc88074: ldr             x2, [x2, #0x3c0]
    // 0xc88078: r0 = InitLateFinalInstanceField()
    //     0xc88078: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8807c: LoadField: r1 = r0->field_1b
    //     0xc8807c: ldur            w1, [x0, #0x1b]
    // 0xc88080: DecompressPointer r1
    //     0xc88080: add             x1, x1, HEAP, lsl #32
    // 0xc88084: mov             x3, x1
    // 0xc88088: ldr             x0, [fp, #0x10]
    // 0xc8808c: b               #0xc880a8
    // 0xc88090: mov             x0, x2
    // 0xc88094: LoadField: r1 = r0->field_33
    //     0xc88094: ldur            w1, [x0, #0x33]
    // 0xc88098: DecompressPointer r1
    //     0xc88098: add             x1, x1, HEAP, lsl #32
    // 0xc8809c: LoadField: r2 = r1->field_1f
    //     0xc8809c: ldur            w2, [x1, #0x1f]
    // 0xc880a0: DecompressPointer r2
    //     0xc880a0: add             x2, x2, HEAP, lsl #32
    // 0xc880a4: mov             x3, x2
    // 0xc880a8: ldur            x2, [fp, #-0x10]
    // 0xc880ac: stur            x3, [fp, #-0x18]
    // 0xc880b0: r17 = 5620
    //     0xc880b0: mov             x17, #0x15f4
    // 0xc880b4: cmp             w2, w17
    // 0xc880b8: b.gt            #0xc880ec
    // 0xc880bc: r17 = 5618
    //     0xc880bc: mov             x17, #0x15f2
    // 0xc880c0: cmp             w2, w17
    // 0xc880c4: b.lt            #0xc880e4
    // 0xc880c8: ldr             x4, [fp, #0x18]
    // 0xc880cc: LoadField: r1 = r4->field_1f
    //     0xc880cc: ldur            w1, [x4, #0x1f]
    // 0xc880d0: DecompressPointer r1
    //     0xc880d0: add             x1, x1, HEAP, lsl #32
    // 0xc880d4: mov             x2, x1
    // 0xc880d8: mov             x1, x4
    // 0xc880dc: mov             x0, x3
    // 0xc880e0: b               #0xc88150
    // 0xc880e4: ldr             x4, [fp, #0x18]
    // 0xc880e8: b               #0xc880f0
    // 0xc880ec: ldr             x4, [fp, #0x18]
    // 0xc880f0: r17 = 5622
    //     0xc880f0: mov             x17, #0x15f6
    // 0xc880f4: cmp             w2, w17
    // 0xc880f8: b.ne            #0xc88138
    // 0xc880fc: mov             x1, x4
    // 0xc88100: LoadField: r0 = r1->field_37
    //     0xc88100: ldur            w0, [x1, #0x37]
    // 0xc88104: DecompressPointer r0
    //     0xc88104: add             x0, x0, HEAP, lsl #32
    // 0xc88108: r16 = Sentinel
    //     0xc88108: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8810c: cmp             w0, w16
    // 0xc88110: b.ne            #0xc88120
    // 0xc88114: r2 = _textTheme
    //     0xc88114: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3c0] Field <_DialogDefaultsM3@724506021._textTheme@724506021>: late final (offset: 0x38)
    //     0xc88118: ldr             x2, [x2, #0x3c0]
    // 0xc8811c: r0 = InitLateFinalInstanceField()
    //     0xc8811c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc88120: LoadField: r1 = r0->field_1b
    //     0xc88120: ldur            w1, [x0, #0x1b]
    // 0xc88124: DecompressPointer r1
    //     0xc88124: add             x1, x1, HEAP, lsl #32
    // 0xc88128: mov             x2, x1
    // 0xc8812c: ldr             x1, [fp, #0x18]
    // 0xc88130: ldur            x0, [fp, #-0x18]
    // 0xc88134: b               #0xc88150
    // 0xc88138: mov             x1, x4
    // 0xc8813c: LoadField: r0 = r1->field_33
    //     0xc8813c: ldur            w0, [x1, #0x33]
    // 0xc88140: DecompressPointer r0
    //     0xc88140: add             x0, x0, HEAP, lsl #32
    // 0xc88144: LoadField: r2 = r0->field_1f
    //     0xc88144: ldur            w2, [x0, #0x1f]
    // 0xc88148: DecompressPointer r2
    //     0xc88148: add             x2, x2, HEAP, lsl #32
    // 0xc8814c: ldur            x0, [fp, #-0x18]
    // 0xc88150: r3 = LoadClassIdInstr(r0)
    //     0xc88150: ldur            x3, [x0, #-1]
    //     0xc88154: ubfx            x3, x3, #0xc, #0x14
    // 0xc88158: stp             x2, x0, [SP, #-0x10]!
    // 0xc8815c: mov             x0, x3
    // 0xc88160: mov             lr, x0
    // 0xc88164: ldr             lr, [x21, lr, lsl #3]
    // 0xc88168: blr             lr
    // 0xc8816c: add             SP, SP, #0x10
    // 0xc88170: tbnz            w0, #4, #0xc8839c
    // 0xc88174: ldur            x0, [fp, #-8]
    // 0xc88178: r17 = 5620
    //     0xc88178: mov             x17, #0x15f4
    // 0xc8817c: cmp             w0, w17
    // 0xc88180: b.gt            #0xc881b0
    // 0xc88184: r17 = 5618
    //     0xc88184: mov             x17, #0x15f2
    // 0xc88188: cmp             w0, w17
    // 0xc8818c: b.lt            #0xc881a8
    // 0xc88190: ldr             x2, [fp, #0x10]
    // 0xc88194: LoadField: r1 = r2->field_23
    //     0xc88194: ldur            w1, [x2, #0x23]
    // 0xc88198: DecompressPointer r1
    //     0xc88198: add             x1, x1, HEAP, lsl #32
    // 0xc8819c: mov             x3, x1
    // 0xc881a0: mov             x0, x2
    // 0xc881a4: b               #0xc88210
    // 0xc881a8: ldr             x2, [fp, #0x10]
    // 0xc881ac: b               #0xc881b4
    // 0xc881b0: ldr             x2, [fp, #0x10]
    // 0xc881b4: r17 = 5622
    //     0xc881b4: mov             x17, #0x15f6
    // 0xc881b8: cmp             w0, w17
    // 0xc881bc: b.ne            #0xc881f8
    // 0xc881c0: mov             x1, x2
    // 0xc881c4: LoadField: r0 = r1->field_37
    //     0xc881c4: ldur            w0, [x1, #0x37]
    // 0xc881c8: DecompressPointer r0
    //     0xc881c8: add             x0, x0, HEAP, lsl #32
    // 0xc881cc: r16 = Sentinel
    //     0xc881cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc881d0: cmp             w0, w16
    // 0xc881d4: b.ne            #0xc881e4
    // 0xc881d8: r2 = _textTheme
    //     0xc881d8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3c0] Field <_DialogDefaultsM3@724506021._textTheme@724506021>: late final (offset: 0x38)
    //     0xc881dc: ldr             x2, [x2, #0x3c0]
    // 0xc881e0: r0 = InitLateFinalInstanceField()
    //     0xc881e0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc881e4: LoadField: r1 = r0->field_2f
    //     0xc881e4: ldur            w1, [x0, #0x2f]
    // 0xc881e8: DecompressPointer r1
    //     0xc881e8: add             x1, x1, HEAP, lsl #32
    // 0xc881ec: mov             x3, x1
    // 0xc881f0: ldr             x0, [fp, #0x10]
    // 0xc881f4: b               #0xc88210
    // 0xc881f8: mov             x0, x2
    // 0xc881fc: LoadField: r1 = r0->field_33
    //     0xc881fc: ldur            w1, [x0, #0x33]
    // 0xc88200: DecompressPointer r1
    //     0xc88200: add             x1, x1, HEAP, lsl #32
    // 0xc88204: LoadField: r2 = r1->field_23
    //     0xc88204: ldur            w2, [x1, #0x23]
    // 0xc88208: DecompressPointer r2
    //     0xc88208: add             x2, x2, HEAP, lsl #32
    // 0xc8820c: mov             x3, x2
    // 0xc88210: ldur            x2, [fp, #-0x10]
    // 0xc88214: stur            x3, [fp, #-0x18]
    // 0xc88218: r17 = 5620
    //     0xc88218: mov             x17, #0x15f4
    // 0xc8821c: cmp             w2, w17
    // 0xc88220: b.gt            #0xc88254
    // 0xc88224: r17 = 5618
    //     0xc88224: mov             x17, #0x15f2
    // 0xc88228: cmp             w2, w17
    // 0xc8822c: b.lt            #0xc8824c
    // 0xc88230: ldr             x4, [fp, #0x18]
    // 0xc88234: LoadField: r1 = r4->field_23
    //     0xc88234: ldur            w1, [x4, #0x23]
    // 0xc88238: DecompressPointer r1
    //     0xc88238: add             x1, x1, HEAP, lsl #32
    // 0xc8823c: mov             x2, x1
    // 0xc88240: mov             x1, x4
    // 0xc88244: mov             x0, x3
    // 0xc88248: b               #0xc882b8
    // 0xc8824c: ldr             x4, [fp, #0x18]
    // 0xc88250: b               #0xc88258
    // 0xc88254: ldr             x4, [fp, #0x18]
    // 0xc88258: r17 = 5622
    //     0xc88258: mov             x17, #0x15f6
    // 0xc8825c: cmp             w2, w17
    // 0xc88260: b.ne            #0xc882a0
    // 0xc88264: mov             x1, x4
    // 0xc88268: LoadField: r0 = r1->field_37
    //     0xc88268: ldur            w0, [x1, #0x37]
    // 0xc8826c: DecompressPointer r0
    //     0xc8826c: add             x0, x0, HEAP, lsl #32
    // 0xc88270: r16 = Sentinel
    //     0xc88270: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc88274: cmp             w0, w16
    // 0xc88278: b.ne            #0xc88288
    // 0xc8827c: r2 = _textTheme
    //     0xc8827c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe3c0] Field <_DialogDefaultsM3@724506021._textTheme@724506021>: late final (offset: 0x38)
    //     0xc88280: ldr             x2, [x2, #0x3c0]
    // 0xc88284: r0 = InitLateFinalInstanceField()
    //     0xc88284: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc88288: LoadField: r1 = r0->field_2f
    //     0xc88288: ldur            w1, [x0, #0x2f]
    // 0xc8828c: DecompressPointer r1
    //     0xc8828c: add             x1, x1, HEAP, lsl #32
    // 0xc88290: mov             x2, x1
    // 0xc88294: ldr             x1, [fp, #0x18]
    // 0xc88298: ldur            x0, [fp, #-0x18]
    // 0xc8829c: b               #0xc882b8
    // 0xc882a0: mov             x1, x4
    // 0xc882a4: LoadField: r0 = r1->field_33
    //     0xc882a4: ldur            w0, [x1, #0x33]
    // 0xc882a8: DecompressPointer r0
    //     0xc882a8: add             x0, x0, HEAP, lsl #32
    // 0xc882ac: LoadField: r2 = r0->field_23
    //     0xc882ac: ldur            w2, [x0, #0x23]
    // 0xc882b0: DecompressPointer r2
    //     0xc882b0: add             x2, x2, HEAP, lsl #32
    // 0xc882b4: ldur            x0, [fp, #-0x18]
    // 0xc882b8: r3 = LoadClassIdInstr(r0)
    //     0xc882b8: ldur            x3, [x0, #-1]
    //     0xc882bc: ubfx            x3, x3, #0xc, #0x14
    // 0xc882c0: stp             x2, x0, [SP, #-0x10]!
    // 0xc882c4: mov             x0, x3
    // 0xc882c8: mov             lr, x0
    // 0xc882cc: ldr             lr, [x21, lr, lsl #3]
    // 0xc882d0: blr             lr
    // 0xc882d4: add             SP, SP, #0x10
    // 0xc882d8: tbnz            w0, #4, #0xc8839c
    // 0xc882dc: ldur            x0, [fp, #-8]
    // 0xc882e0: r17 = 5620
    //     0xc882e0: mov             x17, #0x15f4
    // 0xc882e4: cmp             w0, w17
    // 0xc882e8: b.gt            #0xc88308
    // 0xc882ec: r17 = 5618
    //     0xc882ec: mov             x17, #0x15f2
    // 0xc882f0: cmp             w0, w17
    // 0xc882f4: b.lt            #0xc88308
    // 0xc882f8: ldr             x0, [fp, #0x10]
    // 0xc882fc: LoadField: r1 = r0->field_27
    //     0xc882fc: ldur            w1, [x0, #0x27]
    // 0xc88300: DecompressPointer r1
    //     0xc88300: add             x1, x1, HEAP, lsl #32
    // 0xc88304: b               #0xc88328
    // 0xc88308: r17 = 5622
    //     0xc88308: mov             x17, #0x15f6
    // 0xc8830c: cmp             w0, w17
    // 0xc88310: b.ne            #0xc88320
    // 0xc88314: r1 = Instance_EdgeInsets
    //     0xc88314: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3c8] Obj!EdgeInsets@b370a1
    //     0xc88318: ldr             x1, [x1, #0x3c8]
    // 0xc8831c: b               #0xc88328
    // 0xc88320: r1 = Instance_EdgeInsets
    //     0xc88320: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xc88324: ldr             x1, [x1, #0xbd8]
    // 0xc88328: ldur            x0, [fp, #-0x10]
    // 0xc8832c: r17 = 5620
    //     0xc8832c: mov             x17, #0x15f4
    // 0xc88330: cmp             w0, w17
    // 0xc88334: b.gt            #0xc88358
    // 0xc88338: r17 = 5618
    //     0xc88338: mov             x17, #0x15f2
    // 0xc8833c: cmp             w0, w17
    // 0xc88340: b.lt            #0xc88358
    // 0xc88344: ldr             x0, [fp, #0x18]
    // 0xc88348: LoadField: r2 = r0->field_27
    //     0xc88348: ldur            w2, [x0, #0x27]
    // 0xc8834c: DecompressPointer r2
    //     0xc8834c: add             x2, x2, HEAP, lsl #32
    // 0xc88350: mov             x0, x2
    // 0xc88354: b               #0xc88378
    // 0xc88358: r17 = 5622
    //     0xc88358: mov             x17, #0x15f6
    // 0xc8835c: cmp             w0, w17
    // 0xc88360: b.ne            #0xc88370
    // 0xc88364: r0 = Instance_EdgeInsets
    //     0xc88364: add             x0, PP, #0xe, lsl #12  ; [pp+0xe3c8] Obj!EdgeInsets@b370a1
    //     0xc88368: ldr             x0, [x0, #0x3c8]
    // 0xc8836c: b               #0xc88378
    // 0xc88370: r0 = Instance_EdgeInsets
    //     0xc88370: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xc88374: ldr             x0, [x0, #0xbd8]
    // 0xc88378: r2 = LoadClassIdInstr(r1)
    //     0xc88378: ldur            x2, [x1, #-1]
    //     0xc8837c: ubfx            x2, x2, #0xc, #0x14
    // 0xc88380: stp             x0, x1, [SP, #-0x10]!
    // 0xc88384: mov             x0, x2
    // 0xc88388: mov             lr, x0
    // 0xc8838c: ldr             lr, [x21, lr, lsl #3]
    // 0xc88390: blr             lr
    // 0xc88394: add             SP, SP, #0x10
    // 0xc88398: b               #0xc883a0
    // 0xc8839c: r0 = false
    //     0xc8839c: add             x0, NULL, #0x30  ; false
    // 0xc883a0: LeaveFrame
    //     0xc883a0: mov             SP, fp
    //     0xc883a4: ldp             fp, lr, [SP], #0x10
    // 0xc883a8: ret
    //     0xc883a8: ret             
    // 0xc883ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc883ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc883b0: b               #0xc87908
  }
}

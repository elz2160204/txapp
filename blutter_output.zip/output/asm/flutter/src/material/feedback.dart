// lib: , url: package:flutter/src/material/feedback.dart

// class id: 1049240, size: 0x8
class :: {
}

// class id: 2212, size: 0x8, field offset: 0x8
abstract class Feedback extends Object {

  static _ forLongPress(/* No info */) {
    // ** addr: 0x83bf00, size: 0xe0
    // 0x83bf00: EnterFrame
    //     0x83bf00: stp             fp, lr, [SP, #-0x10]!
    //     0x83bf04: mov             fp, SP
    // 0x83bf08: AllocStack(0x8)
    //     0x83bf08: sub             SP, SP, #8
    // 0x83bf0c: CheckStackOverflow
    //     0x83bf0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bf10: cmp             SP, x16
    //     0x83bf14: b.ls            #0x83bfd4
    // 0x83bf18: ldr             x16, [fp, #0x10]
    // 0x83bf1c: SaveReg r16
    //     0x83bf1c: str             x16, [SP, #-8]!
    // 0x83bf20: r0 = findRenderObject()
    //     0x83bf20: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x83bf24: add             SP, SP, #8
    // 0x83bf28: cmp             w0, NULL
    // 0x83bf2c: b.eq            #0x83bfdc
    // 0x83bf30: r16 = Instance_LongPressSemanticsEvent
    //     0x83bf30: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2de88] Obj!LongPressSemanticsEvent@b351f1
    //     0x83bf34: ldr             x16, [x16, #0xe88]
    // 0x83bf38: stp             x16, x0, [SP, #-0x10]!
    // 0x83bf3c: r0 = sendSemanticsEvent()
    //     0x83bf3c: bl              #0x83c044  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0x83bf40: add             SP, SP, #0x10
    // 0x83bf44: ldr             x16, [fp, #0x10]
    // 0x83bf48: SaveReg r16
    //     0x83bf48: str             x16, [SP, #-8]!
    // 0x83bf4c: r0 = getPlatform()
    //     0x83bf4c: bl              #0xcf9c2c  ; [package:flutter/src/material/app.dart] MaterialScrollBehavior::getPlatform
    // 0x83bf50: add             SP, SP, #8
    // 0x83bf54: LoadField: r1 = r0->field_7
    //     0x83bf54: ldur            x1, [x0, #7]
    // 0x83bf58: cmp             x1, #2
    // 0x83bf5c: b.gt            #0x83bf78
    // 0x83bf60: cmp             x1, #1
    // 0x83bf64: b.gt            #0x83bf78
    // 0x83bf68: r0 = vibrate()
    //     0x83bf68: bl              #0x83bfe0  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::vibrate
    // 0x83bf6c: LeaveFrame
    //     0x83bf6c: mov             SP, fp
    //     0x83bf70: ldp             fp, lr, [SP], #0x10
    // 0x83bf74: ret
    //     0x83bf74: ret             
    // 0x83bf78: r1 = <void?>
    //     0x83bf78: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x83bf7c: r0 = _Future()
    //     0x83bf7c: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x83bf80: mov             x1, x0
    // 0x83bf84: r0 = 0
    //     0x83bf84: mov             x0, #0
    // 0x83bf88: stur            x1, [fp, #-8]
    // 0x83bf8c: StoreField: r1->field_b = r0
    //     0x83bf8c: stur            x0, [x1, #0xb]
    // 0x83bf90: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x83bf90: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x83bf94: ldr             x0, [x0, #0xb58]
    //     0x83bf98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x83bf9c: cmp             w0, w16
    //     0x83bfa0: b.ne            #0x83bfac
    //     0x83bfa4: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x83bfa8: bl              #0xd67d44
    // 0x83bfac: mov             x1, x0
    // 0x83bfb0: ldur            x0, [fp, #-8]
    // 0x83bfb4: StoreField: r0->field_13 = r1
    //     0x83bfb4: stur            w1, [x0, #0x13]
    // 0x83bfb8: stp             NULL, x0, [SP, #-0x10]!
    // 0x83bfbc: r0 = _asyncComplete()
    //     0x83bfbc: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x83bfc0: add             SP, SP, #0x10
    // 0x83bfc4: ldur            x0, [fp, #-8]
    // 0x83bfc8: LeaveFrame
    //     0x83bfc8: mov             SP, fp
    //     0x83bfcc: ldp             fp, lr, [SP], #0x10
    // 0x83bfd0: ret
    //     0x83bfd0: ret             
    // 0x83bfd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bfd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bfd8: b               #0x83bf18
    // 0x83bfdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83bfdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ forTap(/* No info */) async {
    // ** addr: 0x855e58, size: 0xfc
    // 0x855e58: EnterFrame
    //     0x855e58: stp             fp, lr, [SP, #-0x10]!
    //     0x855e5c: mov             fp, SP
    // 0x855e60: AllocStack(0x10)
    //     0x855e60: sub             SP, SP, #0x10
    // 0x855e64: SetupParameters(dynamic _ /* r1, fp-0x10 */)
    //     0x855e64: stur            NULL, [fp, #-8]
    //     0x855e68: mov             x0, #0
    //     0x855e6c: add             x1, fp, w0, sxtw #2
    //     0x855e70: ldr             x1, [x1, #0x10]
    //     0x855e74: stur            x1, [fp, #-0x10]
    // 0x855e78: CheckStackOverflow
    //     0x855e78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x855e7c: cmp             SP, x16
    //     0x855e80: b.ls            #0x855f48
    // 0x855e84: InitAsync() -> Future<void?>
    //     0x855e84: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0x855e88: bl              #0x4b92e4
    // 0x855e8c: ldur            x16, [fp, #-0x10]
    // 0x855e90: SaveReg r16
    //     0x855e90: str             x16, [SP, #-8]!
    // 0x855e94: r0 = findRenderObject()
    //     0x855e94: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x855e98: add             SP, SP, #8
    // 0x855e9c: cmp             w0, NULL
    // 0x855ea0: b.eq            #0x855f50
    // 0x855ea4: r16 = Instance_TapSemanticEvent
    //     0x855ea4: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e308] Obj!TapSemanticEvent@b351e1
    //     0x855ea8: ldr             x16, [x16, #0x308]
    // 0x855eac: stp             x16, x0, [SP, #-0x10]!
    // 0x855eb0: r0 = sendSemanticsEvent()
    //     0x855eb0: bl              #0x83c044  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0x855eb4: add             SP, SP, #0x10
    // 0x855eb8: ldur            x16, [fp, #-0x10]
    // 0x855ebc: SaveReg r16
    //     0x855ebc: str             x16, [SP, #-8]!
    // 0x855ec0: r0 = getPlatform()
    //     0x855ec0: bl              #0xcf9c2c  ; [package:flutter/src/material/app.dart] MaterialScrollBehavior::getPlatform
    // 0x855ec4: add             SP, SP, #8
    // 0x855ec8: LoadField: r1 = r0->field_7
    //     0x855ec8: ldur            x1, [x0, #7]
    // 0x855ecc: cmp             x1, #2
    // 0x855ed0: b.gt            #0x855ef4
    // 0x855ed4: cmp             x1, #1
    // 0x855ed8: b.gt            #0x855ef4
    // 0x855edc: r16 = Instance_SystemSoundType
    //     0x855edc: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e310] Obj!SystemSoundType@b64271
    //     0x855ee0: ldr             x16, [x16, #0x310]
    // 0x855ee4: SaveReg r16
    //     0x855ee4: str             x16, [SP, #-8]!
    // 0x855ee8: r0 = play()
    //     0x855ee8: bl              #0x855f54  ; [package:flutter/src/services/system_sound.dart] SystemSound::play
    // 0x855eec: add             SP, SP, #8
    // 0x855ef0: r0 = ReturnAsync()
    //     0x855ef0: b               #0x501858  ; ReturnAsyncStub
    // 0x855ef4: r1 = <void?>
    //     0x855ef4: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x855ef8: r0 = _Future()
    //     0x855ef8: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x855efc: mov             x1, x0
    // 0x855f00: r0 = 0
    //     0x855f00: mov             x0, #0
    // 0x855f04: stur            x1, [fp, #-0x10]
    // 0x855f08: StoreField: r1->field_b = r0
    //     0x855f08: stur            x0, [x1, #0xb]
    // 0x855f0c: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x855f0c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x855f10: ldr             x0, [x0, #0xb58]
    //     0x855f14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x855f18: cmp             w0, w16
    //     0x855f1c: b.ne            #0x855f28
    //     0x855f20: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x855f24: bl              #0xd67d44
    // 0x855f28: mov             x1, x0
    // 0x855f2c: ldur            x0, [fp, #-0x10]
    // 0x855f30: StoreField: r0->field_13 = r1
    //     0x855f30: stur            w1, [x0, #0x13]
    // 0x855f34: stp             NULL, x0, [SP, #-0x10]!
    // 0x855f38: r0 = _asyncComplete()
    //     0x855f38: bl              #0x4e2e60  ; [dart:async] _Future::_asyncComplete
    // 0x855f3c: add             SP, SP, #0x10
    // 0x855f40: ldur            x0, [fp, #-0x10]
    // 0x855f44: r0 = ReturnAsync()
    //     0x855f44: b               #0x501858  ; ReturnAsyncStub
    // 0x855f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x855f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x855f4c: b               #0x855e84
    // 0x855f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x855f50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

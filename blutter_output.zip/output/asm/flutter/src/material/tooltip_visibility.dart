// lib: , url: package:flutter/src/material/tooltip_visibility.dart

// class id: 1049340, size: 0x8
class :: {
}

// class id: 2121, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class TooltipVisibility extends Object {

  static _ of(/* No info */) {
    // ** addr: 0xa62734, size: 0x48
    // 0xa62734: EnterFrame
    //     0xa62734: stp             fp, lr, [SP, #-0x10]!
    //     0xa62738: mov             fp, SP
    // 0xa6273c: CheckStackOverflow
    //     0xa6273c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa62740: cmp             SP, x16
    //     0xa62744: b.ls            #0xa62774
    // 0xa62748: r16 = <_TooltipVisibilityScope>
    //     0xa62748: add             x16, PP, #0x50, lsl #12  ; [pp+0x50500] TypeArguments: <_TooltipVisibilityScope>
    //     0xa6274c: ldr             x16, [x16, #0x500]
    // 0xa62750: ldr             lr, [fp, #0x10]
    // 0xa62754: stp             lr, x16, [SP, #-0x10]!
    // 0xa62758: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa62758: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa6275c: r0 = dependOnInheritedWidgetOfExactType()
    //     0xa6275c: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xa62760: add             SP, SP, #0x10
    // 0xa62764: r0 = true
    //     0xa62764: add             x0, NULL, #0x20  ; true
    // 0xa62768: LeaveFrame
    //     0xa62768: mov             SP, fp
    //     0xa6276c: ldp             fp, lr, [SP], #0x10
    // 0xa62770: ret
    //     0xa62770: ret             
    // 0xa62774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62774: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62778: b               #0xa62748
  }
}

// class id: 3522, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class _TooltipVisibilityScope extends InheritedWidget {
}

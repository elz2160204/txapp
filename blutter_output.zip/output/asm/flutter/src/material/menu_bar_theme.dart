// lib: , url: package:flutter/src/material/menu_bar_theme.dart

// class id: 1049273, size: 0x8
class :: {
}

// class id: 2786, size: 0xc, field offset: 0xc
//   const constructor, 
class MenuBarThemeData extends MenuThemeData {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf4280, size: 0x68
    // 0xbf4280: EnterFrame
    //     0xbf4280: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4284: mov             fp, SP
    // 0xbf4288: AllocStack(0x8)
    //     0xbf4288: sub             SP, SP, #8
    // 0xbf428c: CheckStackOverflow
    //     0xbf428c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4290: cmp             SP, x16
    //     0xbf4294: b.ls            #0xbf42e0
    // 0xbf4298: ldr             x0, [fp, #0x20]
    // 0xbf429c: LoadField: r1 = r0->field_7
    //     0xbf429c: ldur            w1, [x0, #7]
    // 0xbf42a0: DecompressPointer r1
    //     0xbf42a0: add             x1, x1, HEAP, lsl #32
    // 0xbf42a4: ldr             x0, [fp, #0x18]
    // 0xbf42a8: LoadField: r2 = r0->field_7
    //     0xbf42a8: ldur            w2, [x0, #7]
    // 0xbf42ac: DecompressPointer r2
    //     0xbf42ac: add             x2, x2, HEAP, lsl #32
    // 0xbf42b0: stp             x2, x1, [SP, #-0x10]!
    // 0xbf42b4: ldr             d0, [fp, #0x10]
    // 0xbf42b8: SaveReg d0
    //     0xbf42b8: str             d0, [SP, #-8]!
    // 0xbf42bc: r0 = lerp()
    //     0xbf42bc: bl              #0xbf3ca8  ; [package:flutter/src/material/menu_style.dart] MenuStyle::lerp
    // 0xbf42c0: add             SP, SP, #0x18
    // 0xbf42c4: stur            x0, [fp, #-8]
    // 0xbf42c8: r0 = MenuBarThemeData()
    //     0xbf42c8: bl              #0xbf42e8  ; AllocateMenuBarThemeDataStub -> MenuBarThemeData (size=0xc)
    // 0xbf42cc: ldur            x1, [fp, #-8]
    // 0xbf42d0: StoreField: r0->field_7 = r1
    //     0xbf42d0: stur            w1, [x0, #7]
    // 0xbf42d4: LeaveFrame
    //     0xbf42d4: mov             SP, fp
    //     0xbf42d8: ldp             fp, lr, [SP], #0x10
    // 0xbf42dc: ret
    //     0xbf42dc: ret             
    // 0xbf42e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf42e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf42e4: b               #0xbf4298
  }
}

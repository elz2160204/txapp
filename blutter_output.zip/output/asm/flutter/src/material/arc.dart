// lib: , url: package:flutter/src/material/arc.dart

// class id: 1049181, size: 0x8
class :: {

  static _ _maxBy(/* No info */) {
    // ** addr: 0xad6308, size: 0x174
    // 0xad6308: EnterFrame
    //     0xad6308: stp             fp, lr, [SP, #-0x10]!
    //     0xad630c: mov             fp, SP
    // 0xad6310: AllocStack(0x28)
    //     0xad6310: sub             SP, SP, #0x28
    // 0xad6314: r3 = const [Instance of '_Diagonal', Instance of '_Diagonal', Instance of '_Diagonal', Instance of '_Diagonal']
    //     0xad6314: add             x3, PP, #0x22, lsl #12  ; [pp+0x220f8] List<_Diagonal>(4)
    //     0xad6318: ldr             x3, [x3, #0xf8]
    // 0xad631c: CheckStackOverflow
    //     0xad631c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad6320: cmp             SP, x16
    //     0xad6324: b.ls            #0xad6464
    // 0xad6328: LoadField: r4 = r3->field_7
    //     0xad6328: ldur            w4, [x3, #7]
    // 0xad632c: DecompressPointer r4
    //     0xad632c: add             x4, x4, HEAP, lsl #32
    // 0xad6330: stur            x4, [fp, #-0x28]
    // 0xad6334: r0 = Sentinel
    //     0xad6334: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xad6338: r5 = Null
    //     0xad6338: mov             x5, NULL
    // 0xad633c: r2 = 0
    //     0xad633c: mov             x2, #0
    // 0xad6340: stur            x0, [fp, #-8]
    // 0xad6344: stur            x5, [fp, #-0x20]
    // 0xad6348: CheckStackOverflow
    //     0xad6348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad634c: cmp             SP, x16
    //     0xad6350: b.ls            #0xad646c
    // 0xad6354: cmp             x2, #4
    // 0xad6358: b.lt            #0xad638c
    // 0xad635c: r16 = Sentinel
    //     0xad635c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xad6360: cmp             w0, w16
    // 0xad6364: b.ne            #0xad637c
    // 0xad6368: r16 = "maxValue"
    //     0xad6368: add             x16, PP, #0x22, lsl #12  ; [pp+0x22100] "maxValue"
    //     0xad636c: ldr             x16, [x16, #0x100]
    // 0xad6370: SaveReg r16
    //     0xad6370: str             x16, [SP, #-8]!
    // 0xad6374: r0 = _throwLocalNotInitialized()
    //     0xad6374: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0xad6378: add             SP, SP, #8
    // 0xad637c: ldur            x0, [fp, #-8]
    // 0xad6380: LeaveFrame
    //     0xad6380: mov             SP, fp
    //     0xad6384: ldp             fp, lr, [SP], #0x10
    // 0xad6388: ret
    //     0xad6388: ret             
    // 0xad638c: mov             x1, x2
    // 0xad6390: r0 = 4
    //     0xad6390: mov             x0, #4
    // 0xad6394: cmp             x1, x0
    // 0xad6398: b.hs            #0xad6474
    // 0xad639c: ArrayLoad: r6 = r3[r2]  ; Unknown_4
    //     0xad639c: add             x16, x3, x2, lsl #2
    //     0xad63a0: ldur            w6, [x16, #0xf]
    // 0xad63a4: DecompressPointer r6
    //     0xad63a4: add             x6, x6, HEAP, lsl #32
    // 0xad63a8: stur            x6, [fp, #-0x18]
    // 0xad63ac: add             x7, x2, #1
    // 0xad63b0: stur            x7, [fp, #-0x10]
    // 0xad63b4: cmp             w6, NULL
    // 0xad63b8: b.ne            #0xad63ec
    // 0xad63bc: mov             x0, x6
    // 0xad63c0: mov             x2, x4
    // 0xad63c4: r1 = Null
    //     0xad63c4: mov             x1, NULL
    // 0xad63c8: cmp             w2, NULL
    // 0xad63cc: b.eq            #0xad63ec
    // 0xad63d0: LoadField: r4 = r2->field_17
    //     0xad63d0: ldur            w4, [x2, #0x17]
    // 0xad63d4: DecompressPointer r4
    //     0xad63d4: add             x4, x4, HEAP, lsl #32
    // 0xad63d8: r8 = X0
    //     0xad63d8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xad63dc: LoadField: r9 = r4->field_7
    //     0xad63dc: ldur            x9, [x4, #7]
    // 0xad63e0: r3 = Null
    //     0xad63e0: add             x3, PP, #0x22, lsl #12  ; [pp+0x22108] Null
    //     0xad63e4: ldr             x3, [x3, #0x108]
    // 0xad63e8: blr             x9
    // 0xad63ec: ldur            x1, [fp, #-0x20]
    // 0xad63f0: ldr             x16, [fp, #0x10]
    // 0xad63f4: ldur            lr, [fp, #-0x18]
    // 0xad63f8: stp             lr, x16, [SP, #-0x10]!
    // 0xad63fc: ldr             x0, [fp, #0x10]
    // 0xad6400: ClosureCall
    //     0xad6400: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xad6404: ldur            x2, [x0, #0x1f]
    //     0xad6408: blr             x2
    // 0xad640c: add             SP, SP, #0x10
    // 0xad6410: mov             x3, x0
    // 0xad6414: ldur            x1, [fp, #-0x20]
    // 0xad6418: cmp             w1, NULL
    // 0xad641c: b.eq            #0xad643c
    // 0xad6420: cmp             w3, NULL
    // 0xad6424: b.eq            #0xad6478
    // 0xad6428: LoadField: d0 = r1->field_7
    //     0xad6428: ldur            d0, [x1, #7]
    // 0xad642c: LoadField: d1 = r3->field_7
    //     0xad642c: ldur            d1, [x3, #7]
    // 0xad6430: fcmp            d1, d0
    // 0xad6434: b.vs            #0xad6448
    // 0xad6438: b.le            #0xad6448
    // 0xad643c: ldur            x0, [fp, #-0x18]
    // 0xad6440: mov             x5, x3
    // 0xad6444: b               #0xad6450
    // 0xad6448: ldur            x0, [fp, #-8]
    // 0xad644c: mov             x5, x1
    // 0xad6450: ldur            x2, [fp, #-0x10]
    // 0xad6454: ldur            x4, [fp, #-0x28]
    // 0xad6458: r3 = const [Instance of '_Diagonal', Instance of '_Diagonal', Instance of '_Diagonal', Instance of '_Diagonal']
    //     0xad6458: add             x3, PP, #0x22, lsl #12  ; [pp+0x220f8] List<_Diagonal>(4)
    //     0xad645c: ldr             x3, [x3, #0xf8]
    // 0xad6460: b               #0xad6340
    // 0xad6464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad6464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad6468: b               #0xad6328
    // 0xad646c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad646c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad6470: b               #0xad6354
    // 0xad6474: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xad6474: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xad6478: r0 = NullErrorSharedWithoutFPURegs()
    //     0xad6478: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 2237, size: 0x10, field offset: 0x8
//   const constructor, 
class _Diagonal extends Object {

  _CornerId field_8;
  _CornerId field_c;
}

// class id: 4269, size: 0x28, field offset: 0x14
class MaterialPointArcTween extends Tween<Offset> {

  _ toString(/* No info */) {
    // ** addr: 0xad66f8, size: 0x1a8
    // 0xad66f8: EnterFrame
    //     0xad66f8: stp             fp, lr, [SP, #-0x10]!
    //     0xad66fc: mov             fp, SP
    // 0xad6700: AllocStack(0x8)
    //     0xad6700: sub             SP, SP, #8
    // 0xad6704: CheckStackOverflow
    //     0xad6704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad6708: cmp             SP, x16
    //     0xad670c: b.ls            #0xad6898
    // 0xad6710: r1 = Null
    //     0xad6710: mov             x1, NULL
    // 0xad6714: r2 = 28
    //     0xad6714: mov             x2, #0x1c
    // 0xad6718: r0 = AllocateArray()
    //     0xad6718: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad671c: stur            x0, [fp, #-8]
    // 0xad6720: r17 = "MaterialPointArcTween"
    //     0xad6720: add             x17, PP, #0x28, lsl #12  ; [pp+0x28cc8] "MaterialPointArcTween"
    //     0xad6724: ldr             x17, [x17, #0xcc8]
    // 0xad6728: StoreField: r0->field_f = r17
    //     0xad6728: stur            w17, [x0, #0xf]
    // 0xad672c: r17 = "("
    //     0xad672c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad6730: StoreField: r0->field_13 = r17
    //     0xad6730: stur            w17, [x0, #0x13]
    // 0xad6734: ldr             x1, [fp, #0x10]
    // 0xad6738: LoadField: r2 = r1->field_b
    //     0xad6738: ldur            w2, [x1, #0xb]
    // 0xad673c: DecompressPointer r2
    //     0xad673c: add             x2, x2, HEAP, lsl #32
    // 0xad6740: StoreField: r0->field_17 = r2
    //     0xad6740: stur            w2, [x0, #0x17]
    // 0xad6744: r17 = " → "
    //     0xad6744: add             x17, PP, #0x22, lsl #12  ; [pp+0x220c8] " → "
    //     0xad6748: ldr             x17, [x17, #0xc8]
    // 0xad674c: StoreField: r0->field_1b = r17
    //     0xad674c: stur            w17, [x0, #0x1b]
    // 0xad6750: LoadField: r2 = r1->field_f
    //     0xad6750: ldur            w2, [x1, #0xf]
    // 0xad6754: DecompressPointer r2
    //     0xad6754: add             x2, x2, HEAP, lsl #32
    // 0xad6758: StoreField: r0->field_1f = r2
    //     0xad6758: stur            w2, [x0, #0x1f]
    // 0xad675c: r17 = "; center="
    //     0xad675c: add             x17, PP, #0x28, lsl #12  ; [pp+0x28cd0] "; center="
    //     0xad6760: ldr             x17, [x17, #0xcd0]
    // 0xad6764: StoreField: r0->field_23 = r17
    //     0xad6764: stur            w17, [x0, #0x23]
    // 0xad6768: SaveReg r1
    //     0xad6768: str             x1, [SP, #-8]!
    // 0xad676c: r0 = center()
    //     0xad676c: bl              #0xad7284  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::center
    // 0xad6770: add             SP, SP, #8
    // 0xad6774: ldur            x1, [fp, #-8]
    // 0xad6778: ArrayStore: r1[6] = r0  ; List_4
    //     0xad6778: add             x25, x1, #0x27
    //     0xad677c: str             w0, [x25]
    //     0xad6780: tbz             w0, #0, #0xad679c
    //     0xad6784: ldurb           w16, [x1, #-1]
    //     0xad6788: ldurb           w17, [x0, #-1]
    //     0xad678c: and             x16, x17, x16, lsr #2
    //     0xad6790: tst             x16, HEAP, lsr #32
    //     0xad6794: b.eq            #0xad679c
    //     0xad6798: bl              #0xd67e5c
    // 0xad679c: ldur            x1, [fp, #-8]
    // 0xad67a0: r17 = ", radius="
    //     0xad67a0: add             x17, PP, #0x28, lsl #12  ; [pp+0x28cd8] ", radius="
    //     0xad67a4: ldr             x17, [x17, #0xcd8]
    // 0xad67a8: StoreField: r1->field_2b = r17
    //     0xad67a8: stur            w17, [x1, #0x2b]
    // 0xad67ac: ldr             x16, [fp, #0x10]
    // 0xad67b0: SaveReg r16
    //     0xad67b0: str             x16, [SP, #-8]!
    // 0xad67b4: r0 = radius()
    //     0xad67b4: bl              #0xad7204  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::radius
    // 0xad67b8: add             SP, SP, #8
    // 0xad67bc: ldur            x1, [fp, #-8]
    // 0xad67c0: ArrayStore: r1[8] = r0  ; List_4
    //     0xad67c0: add             x25, x1, #0x2f
    //     0xad67c4: str             w0, [x25]
    //     0xad67c8: tbz             w0, #0, #0xad67e4
    //     0xad67cc: ldurb           w16, [x1, #-1]
    //     0xad67d0: ldurb           w17, [x0, #-1]
    //     0xad67d4: and             x16, x17, x16, lsr #2
    //     0xad67d8: tst             x16, HEAP, lsr #32
    //     0xad67dc: b.eq            #0xad67e4
    //     0xad67e0: bl              #0xd67e5c
    // 0xad67e4: ldur            x1, [fp, #-8]
    // 0xad67e8: r17 = ", beginAngle="
    //     0xad67e8: add             x17, PP, #0x28, lsl #12  ; [pp+0x28ce0] ", beginAngle="
    //     0xad67ec: ldr             x17, [x17, #0xce0]
    // 0xad67f0: StoreField: r1->field_33 = r17
    //     0xad67f0: stur            w17, [x1, #0x33]
    // 0xad67f4: ldr             x16, [fp, #0x10]
    // 0xad67f8: SaveReg r16
    //     0xad67f8: str             x16, [SP, #-8]!
    // 0xad67fc: r0 = beginAngle()
    //     0xad67fc: bl              #0xad68a0  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::beginAngle
    // 0xad6800: add             SP, SP, #8
    // 0xad6804: ldur            x1, [fp, #-8]
    // 0xad6808: ArrayStore: r1[10] = r0  ; List_4
    //     0xad6808: add             x25, x1, #0x37
    //     0xad680c: str             w0, [x25]
    //     0xad6810: tbz             w0, #0, #0xad682c
    //     0xad6814: ldurb           w16, [x1, #-1]
    //     0xad6818: ldurb           w17, [x0, #-1]
    //     0xad681c: and             x16, x17, x16, lsr #2
    //     0xad6820: tst             x16, HEAP, lsr #32
    //     0xad6824: b.eq            #0xad682c
    //     0xad6828: bl              #0xd67e5c
    // 0xad682c: ldur            x1, [fp, #-8]
    // 0xad6830: r17 = ", endAngle="
    //     0xad6830: add             x17, PP, #0x28, lsl #12  ; [pp+0x28ce8] ", endAngle="
    //     0xad6834: ldr             x17, [x17, #0xce8]
    // 0xad6838: StoreField: r1->field_3b = r17
    //     0xad6838: stur            w17, [x1, #0x3b]
    // 0xad683c: ldr             x16, [fp, #0x10]
    // 0xad6840: SaveReg r16
    //     0xad6840: str             x16, [SP, #-8]!
    // 0xad6844: r0 = beginAngle()
    //     0xad6844: bl              #0xad68a0  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::beginAngle
    // 0xad6848: add             SP, SP, #8
    // 0xad684c: ldur            x1, [fp, #-8]
    // 0xad6850: ArrayStore: r1[12] = r0  ; List_4
    //     0xad6850: add             x25, x1, #0x3f
    //     0xad6854: str             w0, [x25]
    //     0xad6858: tbz             w0, #0, #0xad6874
    //     0xad685c: ldurb           w16, [x1, #-1]
    //     0xad6860: ldurb           w17, [x0, #-1]
    //     0xad6864: and             x16, x17, x16, lsr #2
    //     0xad6868: tst             x16, HEAP, lsr #32
    //     0xad686c: b.eq            #0xad6874
    //     0xad6870: bl              #0xd67e5c
    // 0xad6874: ldur            x0, [fp, #-8]
    // 0xad6878: r17 = ")"
    //     0xad6878: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad687c: StoreField: r0->field_43 = r17
    //     0xad687c: stur            w17, [x0, #0x43]
    // 0xad6880: SaveReg r0
    //     0xad6880: str             x0, [SP, #-8]!
    // 0xad6884: r0 = _interpolate()
    //     0xad6884: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad6888: add             SP, SP, #8
    // 0xad688c: LeaveFrame
    //     0xad688c: mov             SP, fp
    //     0xad6890: ldp             fp, lr, [SP], #0x10
    // 0xad6894: ret
    //     0xad6894: ret             
    // 0xad6898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad6898: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad689c: b               #0xad6710
  }
  get _ beginAngle(/* No info */) {
    // ** addr: 0xad68a0, size: 0x80
    // 0xad68a0: EnterFrame
    //     0xad68a0: stp             fp, lr, [SP, #-0x10]!
    //     0xad68a4: mov             fp, SP
    // 0xad68a8: CheckStackOverflow
    //     0xad68a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad68ac: cmp             SP, x16
    //     0xad68b0: b.ls            #0xad6918
    // 0xad68b4: ldr             x0, [fp, #0x10]
    // 0xad68b8: LoadField: r1 = r0->field_b
    //     0xad68b8: ldur            w1, [x0, #0xb]
    // 0xad68bc: DecompressPointer r1
    //     0xad68bc: add             x1, x1, HEAP, lsl #32
    // 0xad68c0: cmp             w1, NULL
    // 0xad68c4: b.eq            #0xad68d8
    // 0xad68c8: LoadField: r1 = r0->field_f
    //     0xad68c8: ldur            w1, [x0, #0xf]
    // 0xad68cc: DecompressPointer r1
    //     0xad68cc: add             x1, x1, HEAP, lsl #32
    // 0xad68d0: cmp             w1, NULL
    // 0xad68d4: b.ne            #0xad68e8
    // 0xad68d8: r0 = Null
    //     0xad68d8: mov             x0, NULL
    // 0xad68dc: LeaveFrame
    //     0xad68dc: mov             SP, fp
    //     0xad68e0: ldp             fp, lr, [SP], #0x10
    // 0xad68e4: ret
    //     0xad68e4: ret             
    // 0xad68e8: LoadField: r1 = r0->field_13
    //     0xad68e8: ldur            w1, [x0, #0x13]
    // 0xad68ec: DecompressPointer r1
    //     0xad68ec: add             x1, x1, HEAP, lsl #32
    // 0xad68f0: tbnz            w1, #4, #0xad6900
    // 0xad68f4: SaveReg r0
    //     0xad68f4: str             x0, [SP, #-8]!
    // 0xad68f8: r0 = _initialize()
    //     0xad68f8: bl              #0xad6920  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::_initialize
    // 0xad68fc: add             SP, SP, #8
    // 0xad6900: ldr             x1, [fp, #0x10]
    // 0xad6904: LoadField: r0 = r1->field_1f
    //     0xad6904: ldur            w0, [x1, #0x1f]
    // 0xad6908: DecompressPointer r0
    //     0xad6908: add             x0, x0, HEAP, lsl #32
    // 0xad690c: LeaveFrame
    //     0xad690c: mov             SP, fp
    //     0xad6910: ldp             fp, lr, [SP], #0x10
    // 0xad6914: ret
    //     0xad6914: ret             
    // 0xad6918: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad6918: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad691c: b               #0xad68b4
  }
  _ _initialize(/* No info */) {
    // ** addr: 0xad6920, size: 0x8e4
    // 0xad6920: EnterFrame
    //     0xad6920: stp             fp, lr, [SP, #-0x10]!
    //     0xad6924: mov             fp, SP
    // 0xad6928: AllocStack(0x48)
    //     0xad6928: sub             SP, SP, #0x48
    // 0xad692c: CheckStackOverflow
    //     0xad692c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad6930: cmp             SP, x16
    //     0xad6934: b.ls            #0xad714c
    // 0xad6938: ldr             x0, [fp, #0x10]
    // 0xad693c: LoadField: r1 = r0->field_b
    //     0xad693c: ldur            w1, [x0, #0xb]
    // 0xad6940: DecompressPointer r1
    //     0xad6940: add             x1, x1, HEAP, lsl #32
    // 0xad6944: stur            x1, [fp, #-0x10]
    // 0xad6948: cmp             w1, NULL
    // 0xad694c: b.eq            #0xad7154
    // 0xad6950: LoadField: r2 = r0->field_f
    //     0xad6950: ldur            w2, [x0, #0xf]
    // 0xad6954: DecompressPointer r2
    //     0xad6954: add             x2, x2, HEAP, lsl #32
    // 0xad6958: stur            x2, [fp, #-8]
    // 0xad695c: cmp             w2, NULL
    // 0xad6960: b.eq            #0xad7158
    // 0xad6964: stp             x1, x2, [SP, #-0x10]!
    // 0xad6968: r0 = -()
    //     0xad6968: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xad696c: add             SP, SP, #0x10
    // 0xad6970: LoadField: d0 = r0->field_7
    //     0xad6970: ldur            d0, [x0, #7]
    // 0xad6974: d1 = 0.000000
    //     0xad6974: eor             v1.16b, v1.16b, v1.16b
    // 0xad6978: fcmp            d0, d1
    // 0xad697c: b.vs            #0xad698c
    // 0xad6980: b.ne            #0xad698c
    // 0xad6984: d2 = 0.000000
    //     0xad6984: eor             v2.16b, v2.16b, v2.16b
    // 0xad6988: b               #0xad69a4
    // 0xad698c: fcmp            d0, d1
    // 0xad6990: b.vs            #0xad69a0
    // 0xad6994: b.ge            #0xad69a0
    // 0xad6998: fneg            d2, d0
    // 0xad699c: b               #0xad69a4
    // 0xad69a0: mov             v2.16b, v0.16b
    // 0xad69a4: stur            d2, [fp, #-0x38]
    // 0xad69a8: LoadField: d3 = r0->field_f
    //     0xad69a8: ldur            d3, [x0, #0xf]
    // 0xad69ac: fcmp            d3, d1
    // 0xad69b0: b.vs            #0xad69c0
    // 0xad69b4: b.ne            #0xad69c0
    // 0xad69b8: d4 = 0.000000
    //     0xad69b8: eor             v4.16b, v4.16b, v4.16b
    // 0xad69bc: b               #0xad69d8
    // 0xad69c0: fcmp            d3, d1
    // 0xad69c4: b.vs            #0xad69d4
    // 0xad69c8: b.ge            #0xad69d4
    // 0xad69cc: fneg            d4, d3
    // 0xad69d0: b               #0xad69d8
    // 0xad69d4: mov             v4.16b, v3.16b
    // 0xad69d8: ldur            x0, [fp, #-0x10]
    // 0xad69dc: ldur            x1, [fp, #-8]
    // 0xad69e0: stur            d4, [fp, #-0x30]
    // 0xad69e4: fmul            d5, d0, d0
    // 0xad69e8: fmul            d0, d3, d3
    // 0xad69ec: fadd            d3, d5, d0
    // 0xad69f0: fsqrt           d0, d3
    // 0xad69f4: stur            d0, [fp, #-0x28]
    // 0xad69f8: LoadField: d3 = r1->field_7
    //     0xad69f8: ldur            d3, [x1, #7]
    // 0xad69fc: stur            d3, [fp, #-0x20]
    // 0xad6a00: LoadField: d5 = r0->field_f
    //     0xad6a00: ldur            d5, [x0, #0xf]
    // 0xad6a04: stur            d5, [fp, #-0x18]
    // 0xad6a08: r0 = Offset()
    //     0xad6a08: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xad6a0c: ldur            d0, [fp, #-0x20]
    // 0xad6a10: StoreField: r0->field_7 = d0
    //     0xad6a10: stur            d0, [x0, #7]
    // 0xad6a14: ldur            d1, [fp, #-0x18]
    // 0xad6a18: StoreField: r0->field_f = d1
    //     0xad6a18: stur            d1, [x0, #0xf]
    // 0xad6a1c: ldur            d2, [fp, #-0x38]
    // 0xad6a20: d3 = 2.000000
    //     0xad6a20: fmov            d3, #2.00000000
    // 0xad6a24: fcmp            d2, d3
    // 0xad6a28: b.vs            #0xad7128
    // 0xad6a2c: b.le            #0xad7128
    // 0xad6a30: ldur            d4, [fp, #-0x30]
    // 0xad6a34: fcmp            d4, d3
    // 0xad6a38: b.vs            #0xad7120
    // 0xad6a3c: b.le            #0xad7120
    // 0xad6a40: fcmp            d2, d4
    // 0xad6a44: b.vs            #0xad6d78
    // 0xad6a48: b.ge            #0xad6d78
    // 0xad6a4c: ldr             x2, [fp, #0x10]
    // 0xad6a50: ldur            x1, [fp, #-0x10]
    // 0xad6a54: ldur            d2, [fp, #-0x28]
    // 0xad6a58: fmul            d4, d2, d2
    // 0xad6a5c: stur            d4, [fp, #-0x30]
    // 0xad6a60: stp             x1, x0, [SP, #-0x10]!
    // 0xad6a64: r0 = -()
    //     0xad6a64: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xad6a68: add             SP, SP, #0x10
    // 0xad6a6c: LoadField: d0 = r0->field_7
    //     0xad6a6c: ldur            d0, [x0, #7]
    // 0xad6a70: fmul            d1, d0, d0
    // 0xad6a74: LoadField: d0 = r0->field_f
    //     0xad6a74: ldur            d0, [x0, #0xf]
    // 0xad6a78: fmul            d2, d0, d0
    // 0xad6a7c: fadd            d0, d1, d2
    // 0xad6a80: fsqrt           d1, d0
    // 0xad6a84: ldur            d0, [fp, #-0x30]
    // 0xad6a88: fdiv            d2, d0, d1
    // 0xad6a8c: d0 = 2.000000
    //     0xad6a8c: fmov            d0, #2.00000000
    // 0xad6a90: fdiv            d1, d2, d0
    // 0xad6a94: stur            d1, [fp, #-0x48]
    // 0xad6a98: r0 = inline_Allocate_Double()
    //     0xad6a98: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad6a9c: add             x0, x0, #0x10
    //     0xad6aa0: cmp             x1, x0
    //     0xad6aa4: b.ls            #0xad715c
    //     0xad6aa8: str             x0, [THR, #0x60]  ; THR::top
    //     0xad6aac: sub             x0, x0, #0xf
    //     0xad6ab0: mov             x1, #0xd108
    //     0xad6ab4: movk            x1, #3, lsl #16
    //     0xad6ab8: stur            x1, [x0, #-1]
    // 0xad6abc: StoreField: r0->field_7 = d1
    //     0xad6abc: stur            d1, [x0, #7]
    // 0xad6ac0: ldr             x1, [fp, #0x10]
    // 0xad6ac4: StoreField: r1->field_1b = r0
    //     0xad6ac4: stur            w0, [x1, #0x1b]
    //     0xad6ac8: ldurb           w16, [x1, #-1]
    //     0xad6acc: ldurb           w17, [x0, #-1]
    //     0xad6ad0: and             x16, x17, x16, lsr #2
    //     0xad6ad4: tst             x16, HEAP, lsr #32
    //     0xad6ad8: b.eq            #0xad6ae0
    //     0xad6adc: bl              #0xd6826c
    // 0xad6ae0: ldur            x2, [fp, #-0x10]
    // 0xad6ae4: LoadField: d2 = r2->field_7
    //     0xad6ae4: ldur            d2, [x2, #7]
    // 0xad6ae8: ldur            d3, [fp, #-0x20]
    // 0xad6aec: stur            d2, [fp, #-0x40]
    // 0xad6af0: fsub            d4, d2, d3
    // 0xad6af4: d5 = 0.000000
    //     0xad6af4: eor             v5.16b, v5.16b, v5.16b
    // 0xad6af8: fcmp            d4, d5
    // 0xad6afc: b.vs            #0xad6b10
    // 0xad6b00: b.le            #0xad6b10
    // 0xad6b04: d4 = 1.000000
    //     0xad6b04: fmov            d4, #1.00000000
    // 0xad6b08: d6 = 1.000000
    //     0xad6b08: fmov            d6, #1.00000000
    // 0xad6b0c: b               #0xad6b2c
    // 0xad6b10: fcmp            d4, d5
    // 0xad6b14: b.vs            #0xad6b28
    // 0xad6b18: b.ge            #0xad6b28
    // 0xad6b1c: d6 = 1.000000
    //     0xad6b1c: fmov            d6, #1.00000000
    // 0xad6b20: fneg            d4, d6
    // 0xad6b24: b               #0xad6b2c
    // 0xad6b28: d6 = 1.000000
    //     0xad6b28: fmov            d6, #1.00000000
    // 0xad6b2c: ldur            x3, [fp, #-8]
    // 0xad6b30: fmul            d7, d1, d4
    // 0xad6b34: fadd            d4, d3, d7
    // 0xad6b38: stur            d4, [fp, #-0x38]
    // 0xad6b3c: LoadField: d7 = r3->field_f
    //     0xad6b3c: ldur            d7, [x3, #0xf]
    // 0xad6b40: stur            d7, [fp, #-0x30]
    // 0xad6b44: r0 = Offset()
    //     0xad6b44: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xad6b48: ldur            d0, [fp, #-0x38]
    // 0xad6b4c: StoreField: r0->field_7 = d0
    //     0xad6b4c: stur            d0, [x0, #7]
    // 0xad6b50: ldur            d1, [fp, #-0x30]
    // 0xad6b54: StoreField: r0->field_f = d1
    //     0xad6b54: stur            d1, [x0, #0xf]
    // 0xad6b58: ldr             x1, [fp, #0x10]
    // 0xad6b5c: StoreField: r1->field_17 = r0
    //     0xad6b5c: stur            w0, [x1, #0x17]
    //     0xad6b60: ldurb           w16, [x1, #-1]
    //     0xad6b64: ldurb           w17, [x0, #-1]
    //     0xad6b68: and             x16, x17, x16, lsr #2
    //     0xad6b6c: tst             x16, HEAP, lsr #32
    //     0xad6b70: b.eq            #0xad6b78
    //     0xad6b74: bl              #0xd6826c
    // 0xad6b78: ldur            d0, [fp, #-0x40]
    // 0xad6b7c: ldur            d2, [fp, #-0x20]
    // 0xad6b80: fcmp            d0, d2
    // 0xad6b84: b.vs            #0xad6c70
    // 0xad6b88: b.ge            #0xad6c70
    // 0xad6b8c: ldur            d0, [fp, #-0x48]
    // 0xad6b90: ldur            d3, [fp, #-0x18]
    // 0xad6b94: ldur            d4, [fp, #-0x28]
    // 0xad6b98: d2 = 2.000000
    //     0xad6b98: fmov            d2, #2.00000000
    // 0xad6b9c: fmul            d5, d2, d0
    // 0xad6ba0: fdiv            d0, d4, d5
    // 0xad6ba4: stp             fp, lr, [SP, #-0x10]!
    // 0xad6ba8: mov             fp, SP
    // 0xad6bac: CallRuntime_LibcAsin(double) -> double
    //     0xad6bac: and             SP, SP, #0xfffffffffffffff0
    //     0xad6bb0: mov             sp, SP
    //     0xad6bb4: ldr             x16, [THR, #0x5a0]  ; THR::LibcAsin
    //     0xad6bb8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad6bbc: blr             x16
    //     0xad6bc0: mov             x16, #8
    //     0xad6bc4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad6bc8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xad6bcc: sub             sp, x16, #1, lsl #12
    //     0xad6bd0: mov             SP, fp
    //     0xad6bd4: ldp             fp, lr, [SP], #0x10
    // 0xad6bd8: d1 = 2.000000
    //     0xad6bd8: fmov            d1, #2.00000000
    // 0xad6bdc: fmul            d2, d1, d0
    // 0xad6be0: ldur            d3, [fp, #-0x30]
    // 0xad6be4: ldur            d5, [fp, #-0x18]
    // 0xad6be8: fsub            d0, d5, d3
    // 0xad6bec: d6 = 0.000000
    //     0xad6bec: eor             v6.16b, v6.16b, v6.16b
    // 0xad6bf0: fcmp            d0, d6
    // 0xad6bf4: b.vs            #0xad6c04
    // 0xad6bf8: b.le            #0xad6c04
    // 0xad6bfc: d0 = 1.000000
    //     0xad6bfc: fmov            d0, #1.00000000
    // 0xad6c00: b               #0xad6c18
    // 0xad6c04: fcmp            d0, d6
    // 0xad6c08: b.vs            #0xad6c18
    // 0xad6c0c: b.ge            #0xad6c18
    // 0xad6c10: d7 = 1.000000
    //     0xad6c10: fmov            d7, #1.00000000
    // 0xad6c14: fneg            d0, d7
    // 0xad6c18: ldr             x1, [fp, #0x10]
    // 0xad6c1c: r2 = 0.000000
    //     0xad6c1c: ldr             x2, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xad6c20: fmul            d1, d2, d0
    // 0xad6c24: r0 = inline_Allocate_Double()
    //     0xad6c24: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xad6c28: add             x0, x0, #0x10
    //     0xad6c2c: cmp             x3, x0
    //     0xad6c30: b.ls            #0xad716c
    //     0xad6c34: str             x0, [THR, #0x60]  ; THR::top
    //     0xad6c38: sub             x0, x0, #0xf
    //     0xad6c3c: mov             x3, #0xd108
    //     0xad6c40: movk            x3, #3, lsl #16
    //     0xad6c44: stur            x3, [x0, #-1]
    // 0xad6c48: StoreField: r0->field_7 = d1
    //     0xad6c48: stur            d1, [x0, #7]
    // 0xad6c4c: StoreField: r1->field_1f = r0
    //     0xad6c4c: stur            w0, [x1, #0x1f]
    //     0xad6c50: ldurb           w16, [x1, #-1]
    //     0xad6c54: ldurb           w17, [x0, #-1]
    //     0xad6c58: and             x16, x17, x16, lsr #2
    //     0xad6c5c: tst             x16, HEAP, lsr #32
    //     0xad6c60: b.eq            #0xad6c68
    //     0xad6c64: bl              #0xd6826c
    // 0xad6c68: StoreField: r1->field_23 = r2
    //     0xad6c68: stur            w2, [x1, #0x23]
    // 0xad6c6c: b               #0xad7134
    // 0xad6c70: ldur            d0, [fp, #-0x48]
    // 0xad6c74: mov             v3.16b, v1.16b
    // 0xad6c78: ldur            d5, [fp, #-0x18]
    // 0xad6c7c: ldur            d4, [fp, #-0x28]
    // 0xad6c80: d6 = 0.000000
    //     0xad6c80: eor             v6.16b, v6.16b, v6.16b
    // 0xad6c84: d1 = 2.000000
    //     0xad6c84: fmov            d1, #2.00000000
    // 0xad6c88: d7 = 1.000000
    //     0xad6c88: fmov            d7, #1.00000000
    // 0xad6c8c: fmul            d2, d1, d0
    // 0xad6c90: fdiv            d0, d4, d2
    // 0xad6c94: stp             fp, lr, [SP, #-0x10]!
    // 0xad6c98: mov             fp, SP
    // 0xad6c9c: CallRuntime_LibcAsin(double) -> double
    //     0xad6c9c: and             SP, SP, #0xfffffffffffffff0
    //     0xad6ca0: mov             sp, SP
    //     0xad6ca4: ldr             x16, [THR, #0x5a0]  ; THR::LibcAsin
    //     0xad6ca8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad6cac: blr             x16
    //     0xad6cb0: mov             x16, #8
    //     0xad6cb4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad6cb8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xad6cbc: sub             sp, x16, #1, lsl #12
    //     0xad6cc0: mov             SP, fp
    //     0xad6cc4: ldp             fp, lr, [SP], #0x10
    // 0xad6cc8: mov             v1.16b, v0.16b
    // 0xad6ccc: d0 = 2.000000
    //     0xad6ccc: fmov            d0, #2.00000000
    // 0xad6cd0: fmul            d2, d0, d1
    // 0xad6cd4: ldur            d0, [fp, #-0x30]
    // 0xad6cd8: ldur            d1, [fp, #-0x18]
    // 0xad6cdc: fsub            d3, d0, d1
    // 0xad6ce0: d5 = 0.000000
    //     0xad6ce0: eor             v5.16b, v5.16b, v5.16b
    // 0xad6ce4: fcmp            d3, d5
    // 0xad6ce8: b.vs            #0xad6cf8
    // 0xad6cec: b.le            #0xad6cf8
    // 0xad6cf0: d0 = 1.000000
    //     0xad6cf0: fmov            d0, #1.00000000
    // 0xad6cf4: b               #0xad6d14
    // 0xad6cf8: fcmp            d3, d5
    // 0xad6cfc: b.vs            #0xad6d10
    // 0xad6d00: b.ge            #0xad6d10
    // 0xad6d04: d3 = 1.000000
    //     0xad6d04: fmov            d3, #1.00000000
    // 0xad6d08: fneg            d0, d3
    // 0xad6d0c: b               #0xad6d14
    // 0xad6d10: mov             v0.16b, v3.16b
    // 0xad6d14: ldr             x1, [fp, #0x10]
    // 0xad6d18: r2 = 3.141593
    //     0xad6d18: add             x2, PP, #0x28, lsl #12  ; [pp+0x28cf0] 3.141592653589793
    //     0xad6d1c: ldr             x2, [x2, #0xcf0]
    // 0xad6d20: d6 = 3.141593
    //     0xad6d20: ldr             d6, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0xad6d24: fmul            d1, d2, d0
    // 0xad6d28: fadd            d0, d6, d1
    // 0xad6d2c: r0 = inline_Allocate_Double()
    //     0xad6d2c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xad6d30: add             x0, x0, #0x10
    //     0xad6d34: cmp             x3, x0
    //     0xad6d38: b.ls            #0xad7184
    //     0xad6d3c: str             x0, [THR, #0x60]  ; THR::top
    //     0xad6d40: sub             x0, x0, #0xf
    //     0xad6d44: mov             x3, #0xd108
    //     0xad6d48: movk            x3, #3, lsl #16
    //     0xad6d4c: stur            x3, [x0, #-1]
    // 0xad6d50: StoreField: r0->field_7 = d0
    //     0xad6d50: stur            d0, [x0, #7]
    // 0xad6d54: StoreField: r1->field_1f = r0
    //     0xad6d54: stur            w0, [x1, #0x1f]
    //     0xad6d58: ldurb           w16, [x1, #-1]
    //     0xad6d5c: ldurb           w17, [x0, #-1]
    //     0xad6d60: and             x16, x17, x16, lsr #2
    //     0xad6d64: tst             x16, HEAP, lsr #32
    //     0xad6d68: b.eq            #0xad6d70
    //     0xad6d6c: bl              #0xd6826c
    // 0xad6d70: StoreField: r1->field_23 = r2
    //     0xad6d70: stur            w2, [x1, #0x23]
    // 0xad6d74: b               #0xad7134
    // 0xad6d78: ldr             x1, [fp, #0x10]
    // 0xad6d7c: ldur            x2, [fp, #-0x10]
    // 0xad6d80: ldur            x3, [fp, #-8]
    // 0xad6d84: mov             v2.16b, v0.16b
    // 0xad6d88: ldur            d4, [fp, #-0x28]
    // 0xad6d8c: mov             v0.16b, v3.16b
    // 0xad6d90: d5 = 0.000000
    //     0xad6d90: eor             v5.16b, v5.16b, v5.16b
    // 0xad6d94: d3 = 1.000000
    //     0xad6d94: fmov            d3, #1.00000000
    // 0xad6d98: d6 = 3.141593
    //     0xad6d98: ldr             d6, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0xad6d9c: fmul            d7, d4, d4
    // 0xad6da0: stur            d7, [fp, #-0x30]
    // 0xad6da4: stp             x3, x0, [SP, #-0x10]!
    // 0xad6da8: r0 = -()
    //     0xad6da8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xad6dac: add             SP, SP, #0x10
    // 0xad6db0: LoadField: d0 = r0->field_7
    //     0xad6db0: ldur            d0, [x0, #7]
    // 0xad6db4: fmul            d1, d0, d0
    // 0xad6db8: LoadField: d0 = r0->field_f
    //     0xad6db8: ldur            d0, [x0, #0xf]
    // 0xad6dbc: fmul            d2, d0, d0
    // 0xad6dc0: fadd            d0, d1, d2
    // 0xad6dc4: fsqrt           d1, d0
    // 0xad6dc8: ldur            d0, [fp, #-0x30]
    // 0xad6dcc: fdiv            d2, d0, d1
    // 0xad6dd0: d0 = 2.000000
    //     0xad6dd0: fmov            d0, #2.00000000
    // 0xad6dd4: fdiv            d1, d2, d0
    // 0xad6dd8: stur            d1, [fp, #-0x48]
    // 0xad6ddc: r0 = inline_Allocate_Double()
    //     0xad6ddc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad6de0: add             x0, x0, #0x10
    //     0xad6de4: cmp             x1, x0
    //     0xad6de8: b.ls            #0xad719c
    //     0xad6dec: str             x0, [THR, #0x60]  ; THR::top
    //     0xad6df0: sub             x0, x0, #0xf
    //     0xad6df4: mov             x1, #0xd108
    //     0xad6df8: movk            x1, #3, lsl #16
    //     0xad6dfc: stur            x1, [x0, #-1]
    // 0xad6e00: StoreField: r0->field_7 = d1
    //     0xad6e00: stur            d1, [x0, #7]
    // 0xad6e04: ldr             x1, [fp, #0x10]
    // 0xad6e08: StoreField: r1->field_1b = r0
    //     0xad6e08: stur            w0, [x1, #0x1b]
    //     0xad6e0c: ldurb           w16, [x1, #-1]
    //     0xad6e10: ldurb           w17, [x0, #-1]
    //     0xad6e14: and             x16, x17, x16, lsr #2
    //     0xad6e18: tst             x16, HEAP, lsr #32
    //     0xad6e1c: b.eq            #0xad6e24
    //     0xad6e20: bl              #0xd6826c
    // 0xad6e24: ldur            x0, [fp, #-0x10]
    // 0xad6e28: LoadField: d2 = r0->field_7
    //     0xad6e28: ldur            d2, [x0, #7]
    // 0xad6e2c: ldur            x0, [fp, #-8]
    // 0xad6e30: stur            d2, [fp, #-0x40]
    // 0xad6e34: LoadField: d3 = r0->field_f
    //     0xad6e34: ldur            d3, [x0, #0xf]
    // 0xad6e38: ldur            d4, [fp, #-0x18]
    // 0xad6e3c: stur            d3, [fp, #-0x38]
    // 0xad6e40: fsub            d5, d3, d4
    // 0xad6e44: d6 = 0.000000
    //     0xad6e44: eor             v6.16b, v6.16b, v6.16b
    // 0xad6e48: fcmp            d5, d6
    // 0xad6e4c: b.vs            #0xad6e60
    // 0xad6e50: b.le            #0xad6e60
    // 0xad6e54: d5 = 1.000000
    //     0xad6e54: fmov            d5, #1.00000000
    // 0xad6e58: d7 = 1.000000
    //     0xad6e58: fmov            d7, #1.00000000
    // 0xad6e5c: b               #0xad6e7c
    // 0xad6e60: fcmp            d5, d6
    // 0xad6e64: b.vs            #0xad6e78
    // 0xad6e68: b.ge            #0xad6e78
    // 0xad6e6c: d7 = 1.000000
    //     0xad6e6c: fmov            d7, #1.00000000
    // 0xad6e70: fneg            d5, d7
    // 0xad6e74: b               #0xad6e7c
    // 0xad6e78: d7 = 1.000000
    //     0xad6e78: fmov            d7, #1.00000000
    // 0xad6e7c: fmul            d8, d5, d1
    // 0xad6e80: fadd            d5, d4, d8
    // 0xad6e84: stur            d5, [fp, #-0x30]
    // 0xad6e88: r0 = Offset()
    //     0xad6e88: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xad6e8c: ldur            d1, [fp, #-0x40]
    // 0xad6e90: StoreField: r0->field_7 = d1
    //     0xad6e90: stur            d1, [x0, #7]
    // 0xad6e94: ldur            d0, [fp, #-0x30]
    // 0xad6e98: StoreField: r0->field_f = d0
    //     0xad6e98: stur            d0, [x0, #0xf]
    // 0xad6e9c: ldr             x1, [fp, #0x10]
    // 0xad6ea0: StoreField: r1->field_17 = r0
    //     0xad6ea0: stur            w0, [x1, #0x17]
    //     0xad6ea4: ldurb           w16, [x1, #-1]
    //     0xad6ea8: ldurb           w17, [x0, #-1]
    //     0xad6eac: and             x16, x17, x16, lsr #2
    //     0xad6eb0: tst             x16, HEAP, lsr #32
    //     0xad6eb4: b.eq            #0xad6ebc
    //     0xad6eb8: bl              #0xd6826c
    // 0xad6ebc: ldur            d0, [fp, #-0x38]
    // 0xad6ec0: ldur            d2, [fp, #-0x18]
    // 0xad6ec4: fcmp            d2, d0
    // 0xad6ec8: b.vs            #0xad7014
    // 0xad6ecc: b.ge            #0xad7014
    // 0xad6ed0: ldur            d0, [fp, #-0x48]
    // 0xad6ed4: ldur            d3, [fp, #-0x20]
    // 0xad6ed8: ldur            d4, [fp, #-0x28]
    // 0xad6edc: d2 = 2.000000
    //     0xad6edc: fmov            d2, #2.00000000
    // 0xad6ee0: d5 = 3.141593
    //     0xad6ee0: ldr             d5, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0xad6ee4: fneg            d6, d5
    // 0xad6ee8: fdiv            d5, d6, d2
    // 0xad6eec: stur            d5, [fp, #-0x18]
    // 0xad6ef0: r0 = inline_Allocate_Double()
    //     0xad6ef0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad6ef4: add             x0, x0, #0x10
    //     0xad6ef8: cmp             x2, x0
    //     0xad6efc: b.ls            #0xad71ac
    //     0xad6f00: str             x0, [THR, #0x60]  ; THR::top
    //     0xad6f04: sub             x0, x0, #0xf
    //     0xad6f08: mov             x2, #0xd108
    //     0xad6f0c: movk            x2, #3, lsl #16
    //     0xad6f10: stur            x2, [x0, #-1]
    // 0xad6f14: StoreField: r0->field_7 = d5
    //     0xad6f14: stur            d5, [x0, #7]
    // 0xad6f18: StoreField: r1->field_1f = r0
    //     0xad6f18: stur            w0, [x1, #0x1f]
    //     0xad6f1c: ldurb           w16, [x1, #-1]
    //     0xad6f20: ldurb           w17, [x0, #-1]
    //     0xad6f24: and             x16, x17, x16, lsr #2
    //     0xad6f28: tst             x16, HEAP, lsr #32
    //     0xad6f2c: b.eq            #0xad6f34
    //     0xad6f30: bl              #0xd6826c
    // 0xad6f34: fmul            d6, d2, d0
    // 0xad6f38: fdiv            d0, d4, d6
    // 0xad6f3c: stp             fp, lr, [SP, #-0x10]!
    // 0xad6f40: mov             fp, SP
    // 0xad6f44: CallRuntime_LibcAsin(double) -> double
    //     0xad6f44: and             SP, SP, #0xfffffffffffffff0
    //     0xad6f48: mov             sp, SP
    //     0xad6f4c: ldr             x16, [THR, #0x5a0]  ; THR::LibcAsin
    //     0xad6f50: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad6f54: blr             x16
    //     0xad6f58: mov             x16, #8
    //     0xad6f5c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad6f60: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xad6f64: sub             sp, x16, #1, lsl #12
    //     0xad6f68: mov             SP, fp
    //     0xad6f6c: ldp             fp, lr, [SP], #0x10
    // 0xad6f70: d1 = 2.000000
    //     0xad6f70: fmov            d1, #2.00000000
    // 0xad6f74: fmul            d2, d1, d0
    // 0xad6f78: ldur            d3, [fp, #-0x40]
    // 0xad6f7c: ldur            d5, [fp, #-0x20]
    // 0xad6f80: fsub            d0, d5, d3
    // 0xad6f84: d6 = 0.000000
    //     0xad6f84: eor             v6.16b, v6.16b, v6.16b
    // 0xad6f88: fcmp            d0, d6
    // 0xad6f8c: b.vs            #0xad6f9c
    // 0xad6f90: b.le            #0xad6f9c
    // 0xad6f94: d1 = 1.000000
    //     0xad6f94: fmov            d1, #1.00000000
    // 0xad6f98: b               #0xad6fbc
    // 0xad6f9c: fcmp            d0, d6
    // 0xad6fa0: b.vs            #0xad6fb8
    // 0xad6fa4: b.ge            #0xad6fb8
    // 0xad6fa8: d7 = 1.000000
    //     0xad6fa8: fmov            d7, #1.00000000
    // 0xad6fac: fneg            d0, d7
    // 0xad6fb0: mov             v1.16b, v0.16b
    // 0xad6fb4: b               #0xad6fbc
    // 0xad6fb8: mov             v1.16b, v0.16b
    // 0xad6fbc: ldr             x1, [fp, #0x10]
    // 0xad6fc0: ldur            d0, [fp, #-0x18]
    // 0xad6fc4: fmul            d3, d2, d1
    // 0xad6fc8: fadd            d1, d0, d3
    // 0xad6fcc: r0 = inline_Allocate_Double()
    //     0xad6fcc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad6fd0: add             x0, x0, #0x10
    //     0xad6fd4: cmp             x2, x0
    //     0xad6fd8: b.ls            #0xad71d4
    //     0xad6fdc: str             x0, [THR, #0x60]  ; THR::top
    //     0xad6fe0: sub             x0, x0, #0xf
    //     0xad6fe4: mov             x2, #0xd108
    //     0xad6fe8: movk            x2, #3, lsl #16
    //     0xad6fec: stur            x2, [x0, #-1]
    // 0xad6ff0: StoreField: r0->field_7 = d1
    //     0xad6ff0: stur            d1, [x0, #7]
    // 0xad6ff4: StoreField: r1->field_23 = r0
    //     0xad6ff4: stur            w0, [x1, #0x23]
    //     0xad6ff8: ldurb           w16, [x1, #-1]
    //     0xad6ffc: ldurb           w17, [x0, #-1]
    //     0xad7000: and             x16, x17, x16, lsr #2
    //     0xad7004: tst             x16, HEAP, lsr #32
    //     0xad7008: b.eq            #0xad7010
    //     0xad700c: bl              #0xd6826c
    // 0xad7010: b               #0xad7134
    // 0xad7014: ldur            d0, [fp, #-0x48]
    // 0xad7018: mov             v3.16b, v1.16b
    // 0xad701c: ldur            d5, [fp, #-0x20]
    // 0xad7020: ldur            d4, [fp, #-0x28]
    // 0xad7024: d6 = 0.000000
    //     0xad7024: eor             v6.16b, v6.16b, v6.16b
    // 0xad7028: d1 = 2.000000
    //     0xad7028: fmov            d1, #2.00000000
    // 0xad702c: d7 = 1.000000
    //     0xad702c: fmov            d7, #1.00000000
    // 0xad7030: r0 = 1.570796
    //     0xad7030: add             x0, PP, #0x28, lsl #12  ; [pp+0x28cf8] 1.5707963267948966
    //     0xad7034: ldr             x0, [x0, #0xcf8]
    // 0xad7038: StoreField: r1->field_1f = r0
    //     0xad7038: stur            w0, [x1, #0x1f]
    // 0xad703c: fmul            d2, d1, d0
    // 0xad7040: fdiv            d0, d4, d2
    // 0xad7044: stp             fp, lr, [SP, #-0x10]!
    // 0xad7048: mov             fp, SP
    // 0xad704c: CallRuntime_LibcAsin(double) -> double
    //     0xad704c: and             SP, SP, #0xfffffffffffffff0
    //     0xad7050: mov             sp, SP
    //     0xad7054: ldr             x16, [THR, #0x5a0]  ; THR::LibcAsin
    //     0xad7058: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad705c: blr             x16
    //     0xad7060: mov             x16, #8
    //     0xad7064: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xad7068: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xad706c: sub             sp, x16, #1, lsl #12
    //     0xad7070: mov             SP, fp
    //     0xad7074: ldp             fp, lr, [SP], #0x10
    // 0xad7078: mov             v1.16b, v0.16b
    // 0xad707c: d0 = 2.000000
    //     0xad707c: fmov            d0, #2.00000000
    // 0xad7080: fmul            d2, d0, d1
    // 0xad7084: ldur            d0, [fp, #-0x40]
    // 0xad7088: ldur            d1, [fp, #-0x20]
    // 0xad708c: fsub            d3, d0, d1
    // 0xad7090: d0 = 0.000000
    //     0xad7090: eor             v0.16b, v0.16b, v0.16b
    // 0xad7094: fcmp            d3, d0
    // 0xad7098: b.vs            #0xad70a8
    // 0xad709c: b.le            #0xad70a8
    // 0xad70a0: d1 = 1.000000
    //     0xad70a0: fmov            d1, #1.00000000
    // 0xad70a4: b               #0xad70c4
    // 0xad70a8: fcmp            d3, d0
    // 0xad70ac: b.vs            #0xad70c0
    // 0xad70b0: b.ge            #0xad70c0
    // 0xad70b4: d0 = 1.000000
    //     0xad70b4: fmov            d0, #1.00000000
    // 0xad70b8: fneg            d1, d0
    // 0xad70bc: b               #0xad70c4
    // 0xad70c0: mov             v1.16b, v3.16b
    // 0xad70c4: ldr             x1, [fp, #0x10]
    // 0xad70c8: d0 = 1.570796
    //     0xad70c8: add             x17, PP, #0x28, lsl #12  ; [pp+0x28d00] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xad70cc: ldr             d0, [x17, #0xd00]
    // 0xad70d0: fmul            d3, d2, d1
    // 0xad70d4: fadd            d1, d0, d3
    // 0xad70d8: r0 = inline_Allocate_Double()
    //     0xad70d8: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xad70dc: add             x0, x0, #0x10
    //     0xad70e0: cmp             x2, x0
    //     0xad70e4: b.ls            #0xad71ec
    //     0xad70e8: str             x0, [THR, #0x60]  ; THR::top
    //     0xad70ec: sub             x0, x0, #0xf
    //     0xad70f0: mov             x2, #0xd108
    //     0xad70f4: movk            x2, #3, lsl #16
    //     0xad70f8: stur            x2, [x0, #-1]
    // 0xad70fc: StoreField: r0->field_7 = d1
    //     0xad70fc: stur            d1, [x0, #7]
    // 0xad7100: StoreField: r1->field_23 = r0
    //     0xad7100: stur            w0, [x1, #0x23]
    //     0xad7104: ldurb           w16, [x1, #-1]
    //     0xad7108: ldurb           w17, [x0, #-1]
    //     0xad710c: and             x16, x17, x16, lsr #2
    //     0xad7110: tst             x16, HEAP, lsr #32
    //     0xad7114: b.eq            #0xad711c
    //     0xad7118: bl              #0xd6826c
    // 0xad711c: b               #0xad7134
    // 0xad7120: ldr             x1, [fp, #0x10]
    // 0xad7124: b               #0xad712c
    // 0xad7128: ldr             x1, [fp, #0x10]
    // 0xad712c: StoreField: r1->field_1f = rNULL
    //     0xad712c: stur            NULL, [x1, #0x1f]
    // 0xad7130: StoreField: r1->field_23 = rNULL
    //     0xad7130: stur            NULL, [x1, #0x23]
    // 0xad7134: r2 = false
    //     0xad7134: add             x2, NULL, #0x30  ; false
    // 0xad7138: StoreField: r1->field_13 = r2
    //     0xad7138: stur            w2, [x1, #0x13]
    // 0xad713c: r0 = Null
    //     0xad713c: mov             x0, NULL
    // 0xad7140: LeaveFrame
    //     0xad7140: mov             SP, fp
    //     0xad7144: ldp             fp, lr, [SP], #0x10
    // 0xad7148: ret
    //     0xad7148: ret             
    // 0xad714c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad714c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7150: b               #0xad6938
    // 0xad7154: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad7154: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad7158: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad7158: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad715c: stp             q0, q1, [SP, #-0x20]!
    // 0xad7160: r0 = AllocateDouble()
    //     0xad7160: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad7164: ldp             q0, q1, [SP], #0x20
    // 0xad7168: b               #0xad6abc
    // 0xad716c: SaveReg d1
    //     0xad716c: str             q1, [SP, #-0x10]!
    // 0xad7170: stp             x1, x2, [SP, #-0x10]!
    // 0xad7174: r0 = AllocateDouble()
    //     0xad7174: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad7178: ldp             x1, x2, [SP], #0x10
    // 0xad717c: RestoreReg d1
    //     0xad717c: ldr             q1, [SP], #0x10
    // 0xad7180: b               #0xad6c48
    // 0xad7184: SaveReg d0
    //     0xad7184: str             q0, [SP, #-0x10]!
    // 0xad7188: stp             x1, x2, [SP, #-0x10]!
    // 0xad718c: r0 = AllocateDouble()
    //     0xad718c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad7190: ldp             x1, x2, [SP], #0x10
    // 0xad7194: RestoreReg d0
    //     0xad7194: ldr             q0, [SP], #0x10
    // 0xad7198: b               #0xad6d50
    // 0xad719c: stp             q0, q1, [SP, #-0x20]!
    // 0xad71a0: r0 = AllocateDouble()
    //     0xad71a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad71a4: ldp             q0, q1, [SP], #0x20
    // 0xad71a8: b               #0xad6e00
    // 0xad71ac: stp             q4, q5, [SP, #-0x20]!
    // 0xad71b0: stp             q2, q3, [SP, #-0x20]!
    // 0xad71b4: stp             q0, q1, [SP, #-0x20]!
    // 0xad71b8: SaveReg r1
    //     0xad71b8: str             x1, [SP, #-8]!
    // 0xad71bc: r0 = AllocateDouble()
    //     0xad71bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad71c0: RestoreReg r1
    //     0xad71c0: ldr             x1, [SP], #8
    // 0xad71c4: ldp             q0, q1, [SP], #0x20
    // 0xad71c8: ldp             q2, q3, [SP], #0x20
    // 0xad71cc: ldp             q4, q5, [SP], #0x20
    // 0xad71d0: b               #0xad6f14
    // 0xad71d4: SaveReg d1
    //     0xad71d4: str             q1, [SP, #-0x10]!
    // 0xad71d8: SaveReg r1
    //     0xad71d8: str             x1, [SP, #-8]!
    // 0xad71dc: r0 = AllocateDouble()
    //     0xad71dc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad71e0: RestoreReg r1
    //     0xad71e0: ldr             x1, [SP], #8
    // 0xad71e4: RestoreReg d1
    //     0xad71e4: ldr             q1, [SP], #0x10
    // 0xad71e8: b               #0xad6ff0
    // 0xad71ec: SaveReg d1
    //     0xad71ec: str             q1, [SP, #-0x10]!
    // 0xad71f0: SaveReg r1
    //     0xad71f0: str             x1, [SP, #-8]!
    // 0xad71f4: r0 = AllocateDouble()
    //     0xad71f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad71f8: RestoreReg r1
    //     0xad71f8: ldr             x1, [SP], #8
    // 0xad71fc: RestoreReg d1
    //     0xad71fc: ldr             q1, [SP], #0x10
    // 0xad7200: b               #0xad70fc
  }
  get _ radius(/* No info */) {
    // ** addr: 0xad7204, size: 0x80
    // 0xad7204: EnterFrame
    //     0xad7204: stp             fp, lr, [SP, #-0x10]!
    //     0xad7208: mov             fp, SP
    // 0xad720c: CheckStackOverflow
    //     0xad720c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7210: cmp             SP, x16
    //     0xad7214: b.ls            #0xad727c
    // 0xad7218: ldr             x0, [fp, #0x10]
    // 0xad721c: LoadField: r1 = r0->field_b
    //     0xad721c: ldur            w1, [x0, #0xb]
    // 0xad7220: DecompressPointer r1
    //     0xad7220: add             x1, x1, HEAP, lsl #32
    // 0xad7224: cmp             w1, NULL
    // 0xad7228: b.eq            #0xad723c
    // 0xad722c: LoadField: r1 = r0->field_f
    //     0xad722c: ldur            w1, [x0, #0xf]
    // 0xad7230: DecompressPointer r1
    //     0xad7230: add             x1, x1, HEAP, lsl #32
    // 0xad7234: cmp             w1, NULL
    // 0xad7238: b.ne            #0xad724c
    // 0xad723c: r0 = Null
    //     0xad723c: mov             x0, NULL
    // 0xad7240: LeaveFrame
    //     0xad7240: mov             SP, fp
    //     0xad7244: ldp             fp, lr, [SP], #0x10
    // 0xad7248: ret
    //     0xad7248: ret             
    // 0xad724c: LoadField: r1 = r0->field_13
    //     0xad724c: ldur            w1, [x0, #0x13]
    // 0xad7250: DecompressPointer r1
    //     0xad7250: add             x1, x1, HEAP, lsl #32
    // 0xad7254: tbnz            w1, #4, #0xad7264
    // 0xad7258: SaveReg r0
    //     0xad7258: str             x0, [SP, #-8]!
    // 0xad725c: r0 = _initialize()
    //     0xad725c: bl              #0xad6920  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::_initialize
    // 0xad7260: add             SP, SP, #8
    // 0xad7264: ldr             x1, [fp, #0x10]
    // 0xad7268: LoadField: r0 = r1->field_1b
    //     0xad7268: ldur            w0, [x1, #0x1b]
    // 0xad726c: DecompressPointer r0
    //     0xad726c: add             x0, x0, HEAP, lsl #32
    // 0xad7270: LeaveFrame
    //     0xad7270: mov             SP, fp
    //     0xad7274: ldp             fp, lr, [SP], #0x10
    // 0xad7278: ret
    //     0xad7278: ret             
    // 0xad727c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad727c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7280: b               #0xad7218
  }
  get _ center(/* No info */) {
    // ** addr: 0xad7284, size: 0x80
    // 0xad7284: EnterFrame
    //     0xad7284: stp             fp, lr, [SP, #-0x10]!
    //     0xad7288: mov             fp, SP
    // 0xad728c: CheckStackOverflow
    //     0xad728c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad7290: cmp             SP, x16
    //     0xad7294: b.ls            #0xad72fc
    // 0xad7298: ldr             x0, [fp, #0x10]
    // 0xad729c: LoadField: r1 = r0->field_b
    //     0xad729c: ldur            w1, [x0, #0xb]
    // 0xad72a0: DecompressPointer r1
    //     0xad72a0: add             x1, x1, HEAP, lsl #32
    // 0xad72a4: cmp             w1, NULL
    // 0xad72a8: b.eq            #0xad72bc
    // 0xad72ac: LoadField: r1 = r0->field_f
    //     0xad72ac: ldur            w1, [x0, #0xf]
    // 0xad72b0: DecompressPointer r1
    //     0xad72b0: add             x1, x1, HEAP, lsl #32
    // 0xad72b4: cmp             w1, NULL
    // 0xad72b8: b.ne            #0xad72cc
    // 0xad72bc: r0 = Null
    //     0xad72bc: mov             x0, NULL
    // 0xad72c0: LeaveFrame
    //     0xad72c0: mov             SP, fp
    //     0xad72c4: ldp             fp, lr, [SP], #0x10
    // 0xad72c8: ret
    //     0xad72c8: ret             
    // 0xad72cc: LoadField: r1 = r0->field_13
    //     0xad72cc: ldur            w1, [x0, #0x13]
    // 0xad72d0: DecompressPointer r1
    //     0xad72d0: add             x1, x1, HEAP, lsl #32
    // 0xad72d4: tbnz            w1, #4, #0xad72e4
    // 0xad72d8: SaveReg r0
    //     0xad72d8: str             x0, [SP, #-8]!
    // 0xad72dc: r0 = _initialize()
    //     0xad72dc: bl              #0xad6920  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::_initialize
    // 0xad72e0: add             SP, SP, #8
    // 0xad72e4: ldr             x1, [fp, #0x10]
    // 0xad72e8: LoadField: r0 = r1->field_17
    //     0xad72e8: ldur            w0, [x1, #0x17]
    // 0xad72ec: DecompressPointer r0
    //     0xad72ec: add             x0, x0, HEAP, lsl #32
    // 0xad72f0: LeaveFrame
    //     0xad72f0: mov             SP, fp
    //     0xad72f4: ldp             fp, lr, [SP], #0x10
    // 0xad72f8: ret
    //     0xad72f8: ret             
    // 0xad72fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad72fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad7300: b               #0xad7298
  }
  _ lerp(/* No info */) {
    // ** addr: 0xbec8b0, size: 0x26c
    // 0xbec8b0: EnterFrame
    //     0xbec8b0: stp             fp, lr, [SP, #-0x10]!
    //     0xbec8b4: mov             fp, SP
    // 0xbec8b8: AllocStack(0x20)
    //     0xbec8b8: sub             SP, SP, #0x20
    // 0xbec8bc: CheckStackOverflow
    //     0xbec8bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec8c0: cmp             SP, x16
    //     0xbec8c4: b.ls            #0xbecad8
    // 0xbec8c8: ldr             x0, [fp, #0x18]
    // 0xbec8cc: LoadField: r1 = r0->field_13
    //     0xbec8cc: ldur            w1, [x0, #0x13]
    // 0xbec8d0: DecompressPointer r1
    //     0xbec8d0: add             x1, x1, HEAP, lsl #32
    // 0xbec8d4: tbnz            w1, #4, #0xbec8e4
    // 0xbec8d8: SaveReg r0
    //     0xbec8d8: str             x0, [SP, #-8]!
    // 0xbec8dc: r0 = _initialize()
    //     0xbec8dc: bl              #0xad6920  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::_initialize
    // 0xbec8e0: add             SP, SP, #8
    // 0xbec8e4: ldr             d1, [fp, #0x10]
    // 0xbec8e8: d0 = 0.000000
    //     0xbec8e8: eor             v0.16b, v0.16b, v0.16b
    // 0xbec8ec: fcmp            d1, d0
    // 0xbec8f0: b.vs            #0xbec91c
    // 0xbec8f4: b.ne            #0xbec91c
    // 0xbec8f8: ldr             x0, [fp, #0x18]
    // 0xbec8fc: LoadField: r1 = r0->field_b
    //     0xbec8fc: ldur            w1, [x0, #0xb]
    // 0xbec900: DecompressPointer r1
    //     0xbec900: add             x1, x1, HEAP, lsl #32
    // 0xbec904: cmp             w1, NULL
    // 0xbec908: b.eq            #0xbecae0
    // 0xbec90c: mov             x0, x1
    // 0xbec910: LeaveFrame
    //     0xbec910: mov             SP, fp
    //     0xbec914: ldp             fp, lr, [SP], #0x10
    // 0xbec918: ret
    //     0xbec918: ret             
    // 0xbec91c: ldr             x0, [fp, #0x18]
    // 0xbec920: d0 = 1.000000
    //     0xbec920: fmov            d0, #1.00000000
    // 0xbec924: fcmp            d1, d0
    // 0xbec928: b.vs            #0xbec950
    // 0xbec92c: b.ne            #0xbec950
    // 0xbec930: LoadField: r1 = r0->field_f
    //     0xbec930: ldur            w1, [x0, #0xf]
    // 0xbec934: DecompressPointer r1
    //     0xbec934: add             x1, x1, HEAP, lsl #32
    // 0xbec938: cmp             w1, NULL
    // 0xbec93c: b.eq            #0xbecae4
    // 0xbec940: mov             x0, x1
    // 0xbec944: LeaveFrame
    //     0xbec944: mov             SP, fp
    //     0xbec948: ldp             fp, lr, [SP], #0x10
    // 0xbec94c: ret
    //     0xbec94c: ret             
    // 0xbec950: LoadField: r1 = r0->field_1f
    //     0xbec950: ldur            w1, [x0, #0x1f]
    // 0xbec954: DecompressPointer r1
    //     0xbec954: add             x1, x1, HEAP, lsl #32
    // 0xbec958: cmp             w1, NULL
    // 0xbec95c: b.eq            #0xbec970
    // 0xbec960: LoadField: r2 = r0->field_23
    //     0xbec960: ldur            w2, [x0, #0x23]
    // 0xbec964: DecompressPointer r2
    //     0xbec964: add             x2, x2, HEAP, lsl #32
    // 0xbec968: cmp             w2, NULL
    // 0xbec96c: b.ne            #0xbec9a4
    // 0xbec970: LoadField: r1 = r0->field_b
    //     0xbec970: ldur            w1, [x0, #0xb]
    // 0xbec974: DecompressPointer r1
    //     0xbec974: add             x1, x1, HEAP, lsl #32
    // 0xbec978: LoadField: r2 = r0->field_f
    //     0xbec978: ldur            w2, [x0, #0xf]
    // 0xbec97c: DecompressPointer r2
    //     0xbec97c: add             x2, x2, HEAP, lsl #32
    // 0xbec980: stp             x2, x1, [SP, #-0x10]!
    // 0xbec984: SaveReg d1
    //     0xbec984: str             d1, [SP, #-8]!
    // 0xbec988: r0 = lerp()
    //     0xbec988: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xbec98c: add             SP, SP, #0x18
    // 0xbec990: cmp             w0, NULL
    // 0xbec994: b.eq            #0xbecae8
    // 0xbec998: LeaveFrame
    //     0xbec998: mov             SP, fp
    //     0xbec99c: ldp             fp, lr, [SP], #0x10
    // 0xbec9a0: ret
    //     0xbec9a0: ret             
    // 0xbec9a4: r3 = inline_Allocate_Double()
    //     0xbec9a4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xbec9a8: add             x3, x3, #0x10
    //     0xbec9ac: cmp             x4, x3
    //     0xbec9b0: b.ls            #0xbecaec
    //     0xbec9b4: str             x3, [THR, #0x60]  ; THR::top
    //     0xbec9b8: sub             x3, x3, #0xf
    //     0xbec9bc: mov             x4, #0xd108
    //     0xbec9c0: movk            x4, #3, lsl #16
    //     0xbec9c4: stur            x4, [x3, #-1]
    // 0xbec9c8: StoreField: r3->field_7 = d1
    //     0xbec9c8: stur            d1, [x3, #7]
    // 0xbec9cc: stp             x2, x1, [SP, #-0x10]!
    // 0xbec9d0: SaveReg r3
    //     0xbec9d0: str             x3, [SP, #-8]!
    // 0xbec9d4: r0 = lerpDouble()
    //     0xbec9d4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbec9d8: add             SP, SP, #0x18
    // 0xbec9dc: cmp             w0, NULL
    // 0xbec9e0: b.eq            #0xbecb10
    // 0xbec9e4: LoadField: d1 = r0->field_7
    //     0xbec9e4: ldur            d1, [x0, #7]
    // 0xbec9e8: mov             v0.16b, v1.16b
    // 0xbec9ec: stur            d1, [fp, #-0x10]
    // 0xbec9f0: stp             fp, lr, [SP, #-0x10]!
    // 0xbec9f4: mov             fp, SP
    // 0xbec9f8: CallRuntime_LibcCos(double) -> double
    //     0xbec9f8: and             SP, SP, #0xfffffffffffffff0
    //     0xbec9fc: mov             sp, SP
    //     0xbeca00: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbeca04: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeca08: blr             x16
    //     0xbeca0c: mov             x16, #8
    //     0xbeca10: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeca14: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbeca18: sub             sp, x16, #1, lsl #12
    //     0xbeca1c: mov             SP, fp
    //     0xbeca20: ldp             fp, lr, [SP], #0x10
    // 0xbeca24: ldr             x0, [fp, #0x18]
    // 0xbeca28: LoadField: r1 = r0->field_1b
    //     0xbeca28: ldur            w1, [x0, #0x1b]
    // 0xbeca2c: DecompressPointer r1
    //     0xbeca2c: add             x1, x1, HEAP, lsl #32
    // 0xbeca30: cmp             w1, NULL
    // 0xbeca34: b.eq            #0xbecb14
    // 0xbeca38: LoadField: d1 = r1->field_7
    //     0xbeca38: ldur            d1, [x1, #7]
    // 0xbeca3c: stur            d1, [fp, #-0x20]
    // 0xbeca40: fmul            d2, d0, d1
    // 0xbeca44: ldur            d0, [fp, #-0x10]
    // 0xbeca48: stur            d2, [fp, #-0x18]
    // 0xbeca4c: stp             fp, lr, [SP, #-0x10]!
    // 0xbeca50: mov             fp, SP
    // 0xbeca54: CallRuntime_LibcSin(double) -> double
    //     0xbeca54: and             SP, SP, #0xfffffffffffffff0
    //     0xbeca58: mov             sp, SP
    //     0xbeca5c: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbeca60: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeca64: blr             x16
    //     0xbeca68: mov             x16, #8
    //     0xbeca6c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbeca70: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbeca74: sub             sp, x16, #1, lsl #12
    //     0xbeca78: mov             SP, fp
    //     0xbeca7c: ldp             fp, lr, [SP], #0x10
    // 0xbeca80: mov             v1.16b, v0.16b
    // 0xbeca84: ldur            d0, [fp, #-0x20]
    // 0xbeca88: fmul            d2, d1, d0
    // 0xbeca8c: ldr             x0, [fp, #0x18]
    // 0xbeca90: stur            d2, [fp, #-0x10]
    // 0xbeca94: LoadField: r1 = r0->field_17
    //     0xbeca94: ldur            w1, [x0, #0x17]
    // 0xbeca98: DecompressPointer r1
    //     0xbeca98: add             x1, x1, HEAP, lsl #32
    // 0xbeca9c: stur            x1, [fp, #-8]
    // 0xbecaa0: cmp             w1, NULL
    // 0xbecaa4: b.eq            #0xbecb18
    // 0xbecaa8: r0 = Offset()
    //     0xbecaa8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbecaac: ldur            d0, [fp, #-0x18]
    // 0xbecab0: StoreField: r0->field_7 = d0
    //     0xbecab0: stur            d0, [x0, #7]
    // 0xbecab4: ldur            d0, [fp, #-0x10]
    // 0xbecab8: StoreField: r0->field_f = d0
    //     0xbecab8: stur            d0, [x0, #0xf]
    // 0xbecabc: ldur            x16, [fp, #-8]
    // 0xbecac0: stp             x0, x16, [SP, #-0x10]!
    // 0xbecac4: r0 = +()
    //     0xbecac4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xbecac8: add             SP, SP, #0x10
    // 0xbecacc: LeaveFrame
    //     0xbecacc: mov             SP, fp
    //     0xbecad0: ldp             fp, lr, [SP], #0x10
    // 0xbecad4: ret
    //     0xbecad4: ret             
    // 0xbecad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbecad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbecadc: b               #0xbec8c8
    // 0xbecae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecae0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbecae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecae4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbecae8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecae8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbecaec: SaveReg d1
    //     0xbecaec: str             q1, [SP, #-0x10]!
    // 0xbecaf0: stp             x1, x2, [SP, #-0x10]!
    // 0xbecaf4: SaveReg r0
    //     0xbecaf4: str             x0, [SP, #-8]!
    // 0xbecaf8: r0 = AllocateDouble()
    //     0xbecaf8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbecafc: mov             x3, x0
    // 0xbecb00: RestoreReg r0
    //     0xbecb00: ldr             x0, [SP], #8
    // 0xbecb04: ldp             x1, x2, [SP], #0x10
    // 0xbecb08: RestoreReg d1
    //     0xbecb08: ldr             q1, [SP], #0x10
    // 0xbecb0c: b               #0xbec9c8
    // 0xbecb10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbecb10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbecb14: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbecb14: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xbecb18: r0 = NullCastErrorSharedWithFPURegs()
    //     0xbecb18: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ end=(/* No info */) {
    // ** addr: 0xbfa3c0, size: 0x10c
    // 0xbfa3c0: EnterFrame
    //     0xbfa3c0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa3c4: mov             fp, SP
    // 0xbfa3c8: CheckStackOverflow
    //     0xbfa3c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa3cc: cmp             SP, x16
    //     0xbfa3d0: b.ls            #0xbfa4c4
    // 0xbfa3d4: ldr             x0, [fp, #0x10]
    // 0xbfa3d8: r2 = Null
    //     0xbfa3d8: mov             x2, NULL
    // 0xbfa3dc: r1 = Null
    //     0xbfa3dc: mov             x1, NULL
    // 0xbfa3e0: r4 = 59
    //     0xbfa3e0: mov             x4, #0x3b
    // 0xbfa3e4: branchIfSmi(r0, 0xbfa3f0)
    //     0xbfa3e4: tbz             w0, #0, #0xbfa3f0
    // 0xbfa3e8: r4 = LoadClassIdInstr(r0)
    //     0xbfa3e8: ldur            x4, [x0, #-1]
    //     0xbfa3ec: ubfx            x4, x4, #0xc, #0x14
    // 0xbfa3f0: r17 = 5075
    //     0xbfa3f0: mov             x17, #0x13d3
    // 0xbfa3f4: cmp             x4, x17
    // 0xbfa3f8: b.eq            #0xbfa410
    // 0xbfa3fc: r8 = Offset?
    //     0xbfa3fc: add             x8, PP, #0x28, lsl #12  ; [pp+0x28d08] Type: Offset?
    //     0xbfa400: ldr             x8, [x8, #0xd08]
    // 0xbfa404: r3 = Null
    //     0xbfa404: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d10] Null
    //     0xbfa408: ldr             x3, [x3, #0xd10]
    // 0xbfa40c: r0 = Offset?()
    //     0xbfa40c: bl              #0x9b5ff0  ; IsType_Offset?_Stub
    // 0xbfa410: ldr             x1, [fp, #0x18]
    // 0xbfa414: LoadField: r0 = r1->field_f
    //     0xbfa414: ldur            w0, [x1, #0xf]
    // 0xbfa418: DecompressPointer r0
    //     0xbfa418: add             x0, x0, HEAP, lsl #32
    // 0xbfa41c: ldr             x2, [fp, #0x10]
    // 0xbfa420: r3 = LoadClassIdInstr(r2)
    //     0xbfa420: ldur            x3, [x2, #-1]
    //     0xbfa424: ubfx            x3, x3, #0xc, #0x14
    // 0xbfa428: stp             x0, x2, [SP, #-0x10]!
    // 0xbfa42c: mov             x0, x3
    // 0xbfa430: mov             lr, x0
    // 0xbfa434: ldr             lr, [x21, lr, lsl #3]
    // 0xbfa438: blr             lr
    // 0xbfa43c: add             SP, SP, #0x10
    // 0xbfa440: tbz             w0, #4, #0xbfa4b4
    // 0xbfa444: ldr             x3, [fp, #0x18]
    // 0xbfa448: LoadField: r2 = r3->field_7
    //     0xbfa448: ldur            w2, [x3, #7]
    // 0xbfa44c: DecompressPointer r2
    //     0xbfa44c: add             x2, x2, HEAP, lsl #32
    // 0xbfa450: ldr             x0, [fp, #0x10]
    // 0xbfa454: r1 = Null
    //     0xbfa454: mov             x1, NULL
    // 0xbfa458: cmp             w0, NULL
    // 0xbfa45c: b.eq            #0xbfa484
    // 0xbfa460: cmp             w2, NULL
    // 0xbfa464: b.eq            #0xbfa484
    // 0xbfa468: LoadField: r4 = r2->field_17
    //     0xbfa468: ldur            w4, [x2, #0x17]
    // 0xbfa46c: DecompressPointer r4
    //     0xbfa46c: add             x4, x4, HEAP, lsl #32
    // 0xbfa470: r8 = X0?
    //     0xbfa470: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xbfa474: LoadField: r9 = r4->field_7
    //     0xbfa474: ldur            x9, [x4, #7]
    // 0xbfa478: r3 = Null
    //     0xbfa478: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d20] Null
    //     0xbfa47c: ldr             x3, [x3, #0xd20]
    // 0xbfa480: blr             x9
    // 0xbfa484: ldr             x0, [fp, #0x10]
    // 0xbfa488: ldr             x1, [fp, #0x18]
    // 0xbfa48c: StoreField: r1->field_f = r0
    //     0xbfa48c: stur            w0, [x1, #0xf]
    //     0xbfa490: tbz             w0, #0, #0xbfa4ac
    //     0xbfa494: ldurb           w16, [x1, #-1]
    //     0xbfa498: ldurb           w17, [x0, #-1]
    //     0xbfa49c: and             x16, x17, x16, lsr #2
    //     0xbfa4a0: tst             x16, HEAP, lsr #32
    //     0xbfa4a4: b.eq            #0xbfa4ac
    //     0xbfa4a8: bl              #0xd6826c
    // 0xbfa4ac: r2 = true
    //     0xbfa4ac: add             x2, NULL, #0x20  ; true
    // 0xbfa4b0: StoreField: r1->field_13 = r2
    //     0xbfa4b0: stur            w2, [x1, #0x13]
    // 0xbfa4b4: r0 = Null
    //     0xbfa4b4: mov             x0, NULL
    // 0xbfa4b8: LeaveFrame
    //     0xbfa4b8: mov             SP, fp
    //     0xbfa4bc: ldp             fp, lr, [SP], #0x10
    // 0xbfa4c0: ret
    //     0xbfa4c0: ret             
    // 0xbfa4c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa4c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa4c8: b               #0xbfa3d4
  }
  set _ begin=(/* No info */) {
    // ** addr: 0xbfa658, size: 0x10c
    // 0xbfa658: EnterFrame
    //     0xbfa658: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa65c: mov             fp, SP
    // 0xbfa660: CheckStackOverflow
    //     0xbfa660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa664: cmp             SP, x16
    //     0xbfa668: b.ls            #0xbfa75c
    // 0xbfa66c: ldr             x0, [fp, #0x10]
    // 0xbfa670: r2 = Null
    //     0xbfa670: mov             x2, NULL
    // 0xbfa674: r1 = Null
    //     0xbfa674: mov             x1, NULL
    // 0xbfa678: r4 = 59
    //     0xbfa678: mov             x4, #0x3b
    // 0xbfa67c: branchIfSmi(r0, 0xbfa688)
    //     0xbfa67c: tbz             w0, #0, #0xbfa688
    // 0xbfa680: r4 = LoadClassIdInstr(r0)
    //     0xbfa680: ldur            x4, [x0, #-1]
    //     0xbfa684: ubfx            x4, x4, #0xc, #0x14
    // 0xbfa688: r17 = 5075
    //     0xbfa688: mov             x17, #0x13d3
    // 0xbfa68c: cmp             x4, x17
    // 0xbfa690: b.eq            #0xbfa6a8
    // 0xbfa694: r8 = Offset?
    //     0xbfa694: add             x8, PP, #0x28, lsl #12  ; [pp+0x28d08] Type: Offset?
    //     0xbfa698: ldr             x8, [x8, #0xd08]
    // 0xbfa69c: r3 = Null
    //     0xbfa69c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d30] Null
    //     0xbfa6a0: ldr             x3, [x3, #0xd30]
    // 0xbfa6a4: r0 = Offset?()
    //     0xbfa6a4: bl              #0x9b5ff0  ; IsType_Offset?_Stub
    // 0xbfa6a8: ldr             x1, [fp, #0x18]
    // 0xbfa6ac: LoadField: r0 = r1->field_b
    //     0xbfa6ac: ldur            w0, [x1, #0xb]
    // 0xbfa6b0: DecompressPointer r0
    //     0xbfa6b0: add             x0, x0, HEAP, lsl #32
    // 0xbfa6b4: ldr             x2, [fp, #0x10]
    // 0xbfa6b8: r3 = LoadClassIdInstr(r2)
    //     0xbfa6b8: ldur            x3, [x2, #-1]
    //     0xbfa6bc: ubfx            x3, x3, #0xc, #0x14
    // 0xbfa6c0: stp             x0, x2, [SP, #-0x10]!
    // 0xbfa6c4: mov             x0, x3
    // 0xbfa6c8: mov             lr, x0
    // 0xbfa6cc: ldr             lr, [x21, lr, lsl #3]
    // 0xbfa6d0: blr             lr
    // 0xbfa6d4: add             SP, SP, #0x10
    // 0xbfa6d8: tbz             w0, #4, #0xbfa74c
    // 0xbfa6dc: ldr             x3, [fp, #0x18]
    // 0xbfa6e0: LoadField: r2 = r3->field_7
    //     0xbfa6e0: ldur            w2, [x3, #7]
    // 0xbfa6e4: DecompressPointer r2
    //     0xbfa6e4: add             x2, x2, HEAP, lsl #32
    // 0xbfa6e8: ldr             x0, [fp, #0x10]
    // 0xbfa6ec: r1 = Null
    //     0xbfa6ec: mov             x1, NULL
    // 0xbfa6f0: cmp             w0, NULL
    // 0xbfa6f4: b.eq            #0xbfa71c
    // 0xbfa6f8: cmp             w2, NULL
    // 0xbfa6fc: b.eq            #0xbfa71c
    // 0xbfa700: LoadField: r4 = r2->field_17
    //     0xbfa700: ldur            w4, [x2, #0x17]
    // 0xbfa704: DecompressPointer r4
    //     0xbfa704: add             x4, x4, HEAP, lsl #32
    // 0xbfa708: r8 = X0?
    //     0xbfa708: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xbfa70c: LoadField: r9 = r4->field_7
    //     0xbfa70c: ldur            x9, [x4, #7]
    // 0xbfa710: r3 = Null
    //     0xbfa710: add             x3, PP, #0x28, lsl #12  ; [pp+0x28d40] Null
    //     0xbfa714: ldr             x3, [x3, #0xd40]
    // 0xbfa718: blr             x9
    // 0xbfa71c: ldr             x0, [fp, #0x10]
    // 0xbfa720: ldr             x1, [fp, #0x18]
    // 0xbfa724: StoreField: r1->field_b = r0
    //     0xbfa724: stur            w0, [x1, #0xb]
    //     0xbfa728: tbz             w0, #0, #0xbfa744
    //     0xbfa72c: ldurb           w16, [x1, #-1]
    //     0xbfa730: ldurb           w17, [x0, #-1]
    //     0xbfa734: and             x16, x17, x16, lsr #2
    //     0xbfa738: tst             x16, HEAP, lsr #32
    //     0xbfa73c: b.eq            #0xbfa744
    //     0xbfa740: bl              #0xd6826c
    // 0xbfa744: r2 = true
    //     0xbfa744: add             x2, NULL, #0x20  ; true
    // 0xbfa748: StoreField: r1->field_13 = r2
    //     0xbfa748: stur            w2, [x1, #0x13]
    // 0xbfa74c: r0 = Null
    //     0xbfa74c: mov             x0, NULL
    // 0xbfa750: LeaveFrame
    //     0xbfa750: mov             SP, fp
    //     0xbfa754: ldp             fp, lr, [SP], #0x10
    // 0xbfa758: ret
    //     0xbfa758: ret             
    // 0xbfa75c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa75c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa760: b               #0xbfa66c
  }
}

// class id: 4273, size: 0x20, field offset: 0x14
class MaterialRectArcTween extends RectTween {

  late MaterialPointArcTween _endArc; // offset: 0x1c
  late MaterialPointArcTween _beginArc; // offset: 0x18

  _ toString(/* No info */) {
    // ** addr: 0xad5e28, size: 0x118
    // 0xad5e28: EnterFrame
    //     0xad5e28: stp             fp, lr, [SP, #-0x10]!
    //     0xad5e2c: mov             fp, SP
    // 0xad5e30: AllocStack(0x8)
    //     0xad5e30: sub             SP, SP, #8
    // 0xad5e34: CheckStackOverflow
    //     0xad5e34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5e38: cmp             SP, x16
    //     0xad5e3c: b.ls            #0xad5f38
    // 0xad5e40: r1 = Null
    //     0xad5e40: mov             x1, NULL
    // 0xad5e44: r2 = 20
    //     0xad5e44: mov             x2, #0x14
    // 0xad5e48: r0 = AllocateArray()
    //     0xad5e48: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad5e4c: stur            x0, [fp, #-8]
    // 0xad5e50: r17 = "MaterialRectArcTween"
    //     0xad5e50: add             x17, PP, #0x22, lsl #12  ; [pp+0x220c0] "MaterialRectArcTween"
    //     0xad5e54: ldr             x17, [x17, #0xc0]
    // 0xad5e58: StoreField: r0->field_f = r17
    //     0xad5e58: stur            w17, [x0, #0xf]
    // 0xad5e5c: r17 = "("
    //     0xad5e5c: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xad5e60: StoreField: r0->field_13 = r17
    //     0xad5e60: stur            w17, [x0, #0x13]
    // 0xad5e64: ldr             x1, [fp, #0x10]
    // 0xad5e68: LoadField: r2 = r1->field_b
    //     0xad5e68: ldur            w2, [x1, #0xb]
    // 0xad5e6c: DecompressPointer r2
    //     0xad5e6c: add             x2, x2, HEAP, lsl #32
    // 0xad5e70: StoreField: r0->field_17 = r2
    //     0xad5e70: stur            w2, [x0, #0x17]
    // 0xad5e74: r17 = " → "
    //     0xad5e74: add             x17, PP, #0x22, lsl #12  ; [pp+0x220c8] " → "
    //     0xad5e78: ldr             x17, [x17, #0xc8]
    // 0xad5e7c: StoreField: r0->field_1b = r17
    //     0xad5e7c: stur            w17, [x0, #0x1b]
    // 0xad5e80: LoadField: r2 = r1->field_f
    //     0xad5e80: ldur            w2, [x1, #0xf]
    // 0xad5e84: DecompressPointer r2
    //     0xad5e84: add             x2, x2, HEAP, lsl #32
    // 0xad5e88: StoreField: r0->field_1f = r2
    //     0xad5e88: stur            w2, [x0, #0x1f]
    // 0xad5e8c: r17 = "; beginArc="
    //     0xad5e8c: add             x17, PP, #0x22, lsl #12  ; [pp+0x220d0] "; beginArc="
    //     0xad5e90: ldr             x17, [x17, #0xd0]
    // 0xad5e94: StoreField: r0->field_23 = r17
    //     0xad5e94: stur            w17, [x0, #0x23]
    // 0xad5e98: SaveReg r1
    //     0xad5e98: str             x1, [SP, #-8]!
    // 0xad5e9c: r0 = beginArc()
    //     0xad5e9c: bl              #0xad6600  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::beginArc
    // 0xad5ea0: add             SP, SP, #8
    // 0xad5ea4: ldur            x1, [fp, #-8]
    // 0xad5ea8: ArrayStore: r1[6] = r0  ; List_4
    //     0xad5ea8: add             x25, x1, #0x27
    //     0xad5eac: str             w0, [x25]
    //     0xad5eb0: tbz             w0, #0, #0xad5ecc
    //     0xad5eb4: ldurb           w16, [x1, #-1]
    //     0xad5eb8: ldurb           w17, [x0, #-1]
    //     0xad5ebc: and             x16, x17, x16, lsr #2
    //     0xad5ec0: tst             x16, HEAP, lsr #32
    //     0xad5ec4: b.eq            #0xad5ecc
    //     0xad5ec8: bl              #0xd67e5c
    // 0xad5ecc: ldur            x1, [fp, #-8]
    // 0xad5ed0: r17 = ", endArc="
    //     0xad5ed0: add             x17, PP, #0x22, lsl #12  ; [pp+0x220d8] ", endArc="
    //     0xad5ed4: ldr             x17, [x17, #0xd8]
    // 0xad5ed8: StoreField: r1->field_2b = r17
    //     0xad5ed8: stur            w17, [x1, #0x2b]
    // 0xad5edc: ldr             x16, [fp, #0x10]
    // 0xad5ee0: SaveReg r16
    //     0xad5ee0: str             x16, [SP, #-8]!
    // 0xad5ee4: r0 = endArc()
    //     0xad5ee4: bl              #0xad5f40  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::endArc
    // 0xad5ee8: add             SP, SP, #8
    // 0xad5eec: ldur            x1, [fp, #-8]
    // 0xad5ef0: ArrayStore: r1[8] = r0  ; List_4
    //     0xad5ef0: add             x25, x1, #0x2f
    //     0xad5ef4: str             w0, [x25]
    //     0xad5ef8: tbz             w0, #0, #0xad5f14
    //     0xad5efc: ldurb           w16, [x1, #-1]
    //     0xad5f00: ldurb           w17, [x0, #-1]
    //     0xad5f04: and             x16, x17, x16, lsr #2
    //     0xad5f08: tst             x16, HEAP, lsr #32
    //     0xad5f0c: b.eq            #0xad5f14
    //     0xad5f10: bl              #0xd67e5c
    // 0xad5f14: ldur            x0, [fp, #-8]
    // 0xad5f18: r17 = ")"
    //     0xad5f18: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xad5f1c: StoreField: r0->field_33 = r17
    //     0xad5f1c: stur            w17, [x0, #0x33]
    // 0xad5f20: SaveReg r0
    //     0xad5f20: str             x0, [SP, #-8]!
    // 0xad5f24: r0 = _interpolate()
    //     0xad5f24: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad5f28: add             SP, SP, #8
    // 0xad5f2c: LeaveFrame
    //     0xad5f2c: mov             SP, fp
    //     0xad5f30: ldp             fp, lr, [SP], #0x10
    // 0xad5f34: ret
    //     0xad5f34: ret             
    // 0xad5f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5f38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5f3c: b               #0xad5e40
  }
  get _ endArc(/* No info */) {
    // ** addr: 0xad5f40, size: 0x88
    // 0xad5f40: EnterFrame
    //     0xad5f40: stp             fp, lr, [SP, #-0x10]!
    //     0xad5f44: mov             fp, SP
    // 0xad5f48: CheckStackOverflow
    //     0xad5f48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5f4c: cmp             SP, x16
    //     0xad5f50: b.ls            #0xad5fb4
    // 0xad5f54: ldr             x0, [fp, #0x10]
    // 0xad5f58: LoadField: r1 = r0->field_f
    //     0xad5f58: ldur            w1, [x0, #0xf]
    // 0xad5f5c: DecompressPointer r1
    //     0xad5f5c: add             x1, x1, HEAP, lsl #32
    // 0xad5f60: cmp             w1, NULL
    // 0xad5f64: b.ne            #0xad5f78
    // 0xad5f68: r0 = Null
    //     0xad5f68: mov             x0, NULL
    // 0xad5f6c: LeaveFrame
    //     0xad5f6c: mov             SP, fp
    //     0xad5f70: ldp             fp, lr, [SP], #0x10
    // 0xad5f74: ret
    //     0xad5f74: ret             
    // 0xad5f78: LoadField: r1 = r0->field_13
    //     0xad5f78: ldur            w1, [x0, #0x13]
    // 0xad5f7c: DecompressPointer r1
    //     0xad5f7c: add             x1, x1, HEAP, lsl #32
    // 0xad5f80: tbnz            w1, #4, #0xad5f90
    // 0xad5f84: SaveReg r0
    //     0xad5f84: str             x0, [SP, #-8]!
    // 0xad5f88: r0 = _initialize()
    //     0xad5f88: bl              #0xad5fc8  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_initialize
    // 0xad5f8c: add             SP, SP, #8
    // 0xad5f90: ldr             x1, [fp, #0x10]
    // 0xad5f94: LoadField: r0 = r1->field_1b
    //     0xad5f94: ldur            w0, [x1, #0x1b]
    // 0xad5f98: DecompressPointer r0
    //     0xad5f98: add             x0, x0, HEAP, lsl #32
    // 0xad5f9c: r16 = Sentinel
    //     0xad5f9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xad5fa0: cmp             w0, w16
    // 0xad5fa4: b.eq            #0xad5fbc
    // 0xad5fa8: LeaveFrame
    //     0xad5fa8: mov             SP, fp
    //     0xad5fac: ldp             fp, lr, [SP], #0x10
    // 0xad5fb0: ret
    //     0xad5fb0: ret             
    // 0xad5fb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad5fb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad5fb8: b               #0xad5f54
    // 0xad5fbc: r9 = _endArc
    //     0xad5fbc: add             x9, PP, #0x22, lsl #12  ; [pp+0x220e0] Field <MaterialRectArcTween._endArc@682458455>: late (offset: 0x1c)
    //     0xad5fc0: ldr             x9, [x9, #0xe0]
    // 0xad5fc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xad5fc4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _initialize(/* No info */) {
    // ** addr: 0xad5fc8, size: 0x258
    // 0xad5fc8: EnterFrame
    //     0xad5fc8: stp             fp, lr, [SP, #-0x10]!
    //     0xad5fcc: mov             fp, SP
    // 0xad5fd0: AllocStack(0x18)
    //     0xad5fd0: sub             SP, SP, #0x18
    // 0xad5fd4: CheckStackOverflow
    //     0xad5fd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad5fd8: cmp             SP, x16
    //     0xad5fdc: b.ls            #0xad6200
    // 0xad5fe0: r1 = 2
    //     0xad5fe0: mov             x1, #2
    // 0xad5fe4: r0 = AllocateContext()
    //     0xad5fe4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad5fe8: mov             x1, x0
    // 0xad5fec: ldr             x0, [fp, #0x10]
    // 0xad5ff0: stur            x1, [fp, #-8]
    // 0xad5ff4: StoreField: r1->field_f = r0
    //     0xad5ff4: stur            w0, [x1, #0xf]
    // 0xad5ff8: LoadField: r2 = r0->field_f
    //     0xad5ff8: ldur            w2, [x0, #0xf]
    // 0xad5ffc: DecompressPointer r2
    //     0xad5ffc: add             x2, x2, HEAP, lsl #32
    // 0xad6000: cmp             w2, NULL
    // 0xad6004: b.eq            #0xad6208
    // 0xad6008: SaveReg r2
    //     0xad6008: str             x2, [SP, #-8]!
    // 0xad600c: r0 = center()
    //     0xad600c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xad6010: add             SP, SP, #8
    // 0xad6014: mov             x1, x0
    // 0xad6018: ldr             x0, [fp, #0x10]
    // 0xad601c: stur            x1, [fp, #-0x10]
    // 0xad6020: LoadField: r2 = r0->field_b
    //     0xad6020: ldur            w2, [x0, #0xb]
    // 0xad6024: DecompressPointer r2
    //     0xad6024: add             x2, x2, HEAP, lsl #32
    // 0xad6028: cmp             w2, NULL
    // 0xad602c: b.eq            #0xad620c
    // 0xad6030: SaveReg r2
    //     0xad6030: str             x2, [SP, #-8]!
    // 0xad6034: r0 = center()
    //     0xad6034: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xad6038: add             SP, SP, #8
    // 0xad603c: ldur            x16, [fp, #-0x10]
    // 0xad6040: stp             x0, x16, [SP, #-0x10]!
    // 0xad6044: r0 = -()
    //     0xad6044: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xad6048: add             SP, SP, #0x10
    // 0xad604c: ldur            x2, [fp, #-8]
    // 0xad6050: StoreField: r2->field_13 = r0
    //     0xad6050: stur            w0, [x2, #0x13]
    //     0xad6054: ldurb           w16, [x2, #-1]
    //     0xad6058: ldurb           w17, [x0, #-1]
    //     0xad605c: and             x16, x17, x16, lsr #2
    //     0xad6060: tst             x16, HEAP, lsr #32
    //     0xad6064: b.eq            #0xad606c
    //     0xad6068: bl              #0xd6828c
    // 0xad606c: r1 = Function '<anonymous closure>':.
    //     0xad606c: add             x1, PP, #0x22, lsl #12  ; [pp+0x220e8] AnonymousClosure: (0xad647c), in [package:flutter/src/material/arc.dart] MaterialRectArcTween::_initialize (0xad5fc8)
    //     0xad6070: ldr             x1, [x1, #0xe8]
    // 0xad6074: r0 = AllocateClosure()
    //     0xad6074: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad6078: r16 = <_Diagonal>
    //     0xad6078: add             x16, PP, #0x22, lsl #12  ; [pp+0x220f0] TypeArguments: <_Diagonal>
    //     0xad607c: ldr             x16, [x16, #0xf0]
    // 0xad6080: stp             x0, x16, [SP, #-0x10]!
    // 0xad6084: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xad6084: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xad6088: r0 = _maxBy()
    //     0xad6088: bl              #0xad6308  ; [package:flutter/src/material/arc.dart] ::_maxBy
    // 0xad608c: add             SP, SP, #0x10
    // 0xad6090: mov             x1, x0
    // 0xad6094: ldr             x0, [fp, #0x10]
    // 0xad6098: stur            x1, [fp, #-0x10]
    // 0xad609c: LoadField: r2 = r0->field_b
    //     0xad609c: ldur            w2, [x0, #0xb]
    // 0xad60a0: DecompressPointer r2
    //     0xad60a0: add             x2, x2, HEAP, lsl #32
    // 0xad60a4: cmp             w2, NULL
    // 0xad60a8: b.eq            #0xad6210
    // 0xad60ac: LoadField: r3 = r1->field_7
    //     0xad60ac: ldur            w3, [x1, #7]
    // 0xad60b0: DecompressPointer r3
    //     0xad60b0: add             x3, x3, HEAP, lsl #32
    // 0xad60b4: stur            x3, [fp, #-8]
    // 0xad60b8: stp             x2, x0, [SP, #-0x10]!
    // 0xad60bc: SaveReg r3
    //     0xad60bc: str             x3, [SP, #-8]!
    // 0xad60c0: r0 = _cornerFor()
    //     0xad60c0: bl              #0xad622c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0xad60c4: add             SP, SP, #0x18
    // 0xad60c8: mov             x1, x0
    // 0xad60cc: ldr             x0, [fp, #0x10]
    // 0xad60d0: stur            x1, [fp, #-0x18]
    // 0xad60d4: LoadField: r2 = r0->field_f
    //     0xad60d4: ldur            w2, [x0, #0xf]
    // 0xad60d8: DecompressPointer r2
    //     0xad60d8: add             x2, x2, HEAP, lsl #32
    // 0xad60dc: cmp             w2, NULL
    // 0xad60e0: b.eq            #0xad6214
    // 0xad60e4: stp             x2, x0, [SP, #-0x10]!
    // 0xad60e8: ldur            x16, [fp, #-8]
    // 0xad60ec: SaveReg r16
    //     0xad60ec: str             x16, [SP, #-8]!
    // 0xad60f0: r0 = _cornerFor()
    //     0xad60f0: bl              #0xad622c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0xad60f4: add             SP, SP, #0x18
    // 0xad60f8: r1 = <Offset>
    //     0xad60f8: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0xad60fc: ldr             x1, [x1, #0x7f8]
    // 0xad6100: stur            x0, [fp, #-8]
    // 0xad6104: r0 = MaterialPointArcTween()
    //     0xad6104: bl              #0xad6220  ; AllocateMaterialPointArcTweenStub -> MaterialPointArcTween (size=0x28)
    // 0xad6108: r1 = true
    //     0xad6108: add             x1, NULL, #0x20  ; true
    // 0xad610c: StoreField: r0->field_13 = r1
    //     0xad610c: stur            w1, [x0, #0x13]
    // 0xad6110: ldur            x2, [fp, #-0x18]
    // 0xad6114: StoreField: r0->field_b = r2
    //     0xad6114: stur            w2, [x0, #0xb]
    // 0xad6118: ldur            x2, [fp, #-8]
    // 0xad611c: StoreField: r0->field_f = r2
    //     0xad611c: stur            w2, [x0, #0xf]
    // 0xad6120: ldr             x2, [fp, #0x10]
    // 0xad6124: StoreField: r2->field_17 = r0
    //     0xad6124: stur            w0, [x2, #0x17]
    //     0xad6128: ldurb           w16, [x2, #-1]
    //     0xad612c: ldurb           w17, [x0, #-1]
    //     0xad6130: and             x16, x17, x16, lsr #2
    //     0xad6134: tst             x16, HEAP, lsr #32
    //     0xad6138: b.eq            #0xad6140
    //     0xad613c: bl              #0xd6828c
    // 0xad6140: LoadField: r0 = r2->field_b
    //     0xad6140: ldur            w0, [x2, #0xb]
    // 0xad6144: DecompressPointer r0
    //     0xad6144: add             x0, x0, HEAP, lsl #32
    // 0xad6148: cmp             w0, NULL
    // 0xad614c: b.eq            #0xad6218
    // 0xad6150: ldur            x3, [fp, #-0x10]
    // 0xad6154: LoadField: r4 = r3->field_b
    //     0xad6154: ldur            w4, [x3, #0xb]
    // 0xad6158: DecompressPointer r4
    //     0xad6158: add             x4, x4, HEAP, lsl #32
    // 0xad615c: stur            x4, [fp, #-8]
    // 0xad6160: stp             x0, x2, [SP, #-0x10]!
    // 0xad6164: SaveReg r4
    //     0xad6164: str             x4, [SP, #-8]!
    // 0xad6168: r0 = _cornerFor()
    //     0xad6168: bl              #0xad622c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0xad616c: add             SP, SP, #0x18
    // 0xad6170: mov             x1, x0
    // 0xad6174: ldr             x0, [fp, #0x10]
    // 0xad6178: stur            x1, [fp, #-0x10]
    // 0xad617c: LoadField: r2 = r0->field_f
    //     0xad617c: ldur            w2, [x0, #0xf]
    // 0xad6180: DecompressPointer r2
    //     0xad6180: add             x2, x2, HEAP, lsl #32
    // 0xad6184: cmp             w2, NULL
    // 0xad6188: b.eq            #0xad621c
    // 0xad618c: stp             x2, x0, [SP, #-0x10]!
    // 0xad6190: ldur            x16, [fp, #-8]
    // 0xad6194: SaveReg r16
    //     0xad6194: str             x16, [SP, #-8]!
    // 0xad6198: r0 = _cornerFor()
    //     0xad6198: bl              #0xad622c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0xad619c: add             SP, SP, #0x18
    // 0xad61a0: r1 = <Offset>
    //     0xad61a0: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0xad61a4: ldr             x1, [x1, #0x7f8]
    // 0xad61a8: stur            x0, [fp, #-8]
    // 0xad61ac: r0 = MaterialPointArcTween()
    //     0xad61ac: bl              #0xad6220  ; AllocateMaterialPointArcTweenStub -> MaterialPointArcTween (size=0x28)
    // 0xad61b0: r1 = true
    //     0xad61b0: add             x1, NULL, #0x20  ; true
    // 0xad61b4: StoreField: r0->field_13 = r1
    //     0xad61b4: stur            w1, [x0, #0x13]
    // 0xad61b8: ldur            x1, [fp, #-0x10]
    // 0xad61bc: StoreField: r0->field_b = r1
    //     0xad61bc: stur            w1, [x0, #0xb]
    // 0xad61c0: ldur            x1, [fp, #-8]
    // 0xad61c4: StoreField: r0->field_f = r1
    //     0xad61c4: stur            w1, [x0, #0xf]
    // 0xad61c8: ldr             x1, [fp, #0x10]
    // 0xad61cc: StoreField: r1->field_1b = r0
    //     0xad61cc: stur            w0, [x1, #0x1b]
    //     0xad61d0: ldurb           w16, [x1, #-1]
    //     0xad61d4: ldurb           w17, [x0, #-1]
    //     0xad61d8: and             x16, x17, x16, lsr #2
    //     0xad61dc: tst             x16, HEAP, lsr #32
    //     0xad61e0: b.eq            #0xad61e8
    //     0xad61e4: bl              #0xd6826c
    // 0xad61e8: r2 = false
    //     0xad61e8: add             x2, NULL, #0x30  ; false
    // 0xad61ec: StoreField: r1->field_13 = r2
    //     0xad61ec: stur            w2, [x1, #0x13]
    // 0xad61f0: r0 = Null
    //     0xad61f0: mov             x0, NULL
    // 0xad61f4: LeaveFrame
    //     0xad61f4: mov             SP, fp
    //     0xad61f8: ldp             fp, lr, [SP], #0x10
    // 0xad61fc: ret
    //     0xad61fc: ret             
    // 0xad6200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad6200: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad6204: b               #0xad5fe0
    // 0xad6208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad6208: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad620c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad620c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad6210: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad6210: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad6214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad6214: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad6218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad6218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad621c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad621c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _cornerFor(/* No info */) {
    // ** addr: 0xad622c, size: 0xdc
    // 0xad622c: EnterFrame
    //     0xad622c: stp             fp, lr, [SP, #-0x10]!
    //     0xad6230: mov             fp, SP
    // 0xad6234: AllocStack(0x10)
    //     0xad6234: sub             SP, SP, #0x10
    // 0xad6238: CheckStackOverflow
    //     0xad6238: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad623c: cmp             SP, x16
    //     0xad6240: b.ls            #0xad6300
    // 0xad6244: ldr             x0, [fp, #0x10]
    // 0xad6248: LoadField: r1 = r0->field_7
    //     0xad6248: ldur            x1, [x0, #7]
    // 0xad624c: cmp             x1, #1
    // 0xad6250: b.gt            #0xad62ac
    // 0xad6254: cmp             x1, #0
    // 0xad6258: b.gt            #0xad6290
    // 0xad625c: ldr             x0, [fp, #0x18]
    // 0xad6260: LoadField: d0 = r0->field_7
    //     0xad6260: ldur            d0, [x0, #7]
    // 0xad6264: stur            d0, [fp, #-0x10]
    // 0xad6268: LoadField: d1 = r0->field_f
    //     0xad6268: ldur            d1, [x0, #0xf]
    // 0xad626c: stur            d1, [fp, #-8]
    // 0xad6270: r0 = Offset()
    //     0xad6270: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xad6274: ldur            d0, [fp, #-0x10]
    // 0xad6278: StoreField: r0->field_7 = d0
    //     0xad6278: stur            d0, [x0, #7]
    // 0xad627c: ldur            d0, [fp, #-8]
    // 0xad6280: StoreField: r0->field_f = d0
    //     0xad6280: stur            d0, [x0, #0xf]
    // 0xad6284: LeaveFrame
    //     0xad6284: mov             SP, fp
    //     0xad6288: ldp             fp, lr, [SP], #0x10
    // 0xad628c: ret
    //     0xad628c: ret             
    // 0xad6290: ldr             x0, [fp, #0x18]
    // 0xad6294: SaveReg r0
    //     0xad6294: str             x0, [SP, #-8]!
    // 0xad6298: r0 = topRight()
    //     0xad6298: bl              #0x5207c0  ; [dart:ui] Rect::topRight
    // 0xad629c: add             SP, SP, #8
    // 0xad62a0: LeaveFrame
    //     0xad62a0: mov             SP, fp
    //     0xad62a4: ldp             fp, lr, [SP], #0x10
    // 0xad62a8: ret
    //     0xad62a8: ret             
    // 0xad62ac: ldr             x0, [fp, #0x18]
    // 0xad62b0: cmp             x1, #2
    // 0xad62b4: b.gt            #0xad62d0
    // 0xad62b8: SaveReg r0
    //     0xad62b8: str             x0, [SP, #-8]!
    // 0xad62bc: r0 = bottomLeft()
    //     0xad62bc: bl              #0x65a15c  ; [dart:ui] Rect::bottomLeft
    // 0xad62c0: add             SP, SP, #8
    // 0xad62c4: LeaveFrame
    //     0xad62c4: mov             SP, fp
    //     0xad62c8: ldp             fp, lr, [SP], #0x10
    // 0xad62cc: ret
    //     0xad62cc: ret             
    // 0xad62d0: LoadField: d0 = r0->field_17
    //     0xad62d0: ldur            d0, [x0, #0x17]
    // 0xad62d4: stur            d0, [fp, #-0x10]
    // 0xad62d8: LoadField: d1 = r0->field_1f
    //     0xad62d8: ldur            d1, [x0, #0x1f]
    // 0xad62dc: stur            d1, [fp, #-8]
    // 0xad62e0: r0 = Offset()
    //     0xad62e0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xad62e4: ldur            d0, [fp, #-0x10]
    // 0xad62e8: StoreField: r0->field_7 = d0
    //     0xad62e8: stur            d0, [x0, #7]
    // 0xad62ec: ldur            d0, [fp, #-8]
    // 0xad62f0: StoreField: r0->field_f = d0
    //     0xad62f0: stur            d0, [x0, #0xf]
    // 0xad62f4: LeaveFrame
    //     0xad62f4: mov             SP, fp
    //     0xad62f8: ldp             fp, lr, [SP], #0x10
    // 0xad62fc: ret
    //     0xad62fc: ret             
    // 0xad6300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad6300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad6304: b               #0xad6244
  }
  [closure] double <anonymous closure>(dynamic, _Diagonal) {
    // ** addr: 0xad647c, size: 0x90
    // 0xad647c: EnterFrame
    //     0xad647c: stp             fp, lr, [SP, #-0x10]!
    //     0xad6480: mov             fp, SP
    // 0xad6484: ldr             x0, [fp, #0x18]
    // 0xad6488: LoadField: r1 = r0->field_17
    //     0xad6488: ldur            w1, [x0, #0x17]
    // 0xad648c: DecompressPointer r1
    //     0xad648c: add             x1, x1, HEAP, lsl #32
    // 0xad6490: CheckStackOverflow
    //     0xad6490: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad6494: cmp             SP, x16
    //     0xad6498: b.ls            #0xad64f4
    // 0xad649c: LoadField: r0 = r1->field_f
    //     0xad649c: ldur            w0, [x1, #0xf]
    // 0xad64a0: DecompressPointer r0
    //     0xad64a0: add             x0, x0, HEAP, lsl #32
    // 0xad64a4: LoadField: r2 = r1->field_13
    //     0xad64a4: ldur            w2, [x1, #0x13]
    // 0xad64a8: DecompressPointer r2
    //     0xad64a8: add             x2, x2, HEAP, lsl #32
    // 0xad64ac: stp             x2, x0, [SP, #-0x10]!
    // 0xad64b0: ldr             x16, [fp, #0x10]
    // 0xad64b4: SaveReg r16
    //     0xad64b4: str             x16, [SP, #-8]!
    // 0xad64b8: r0 = _diagonalSupport()
    //     0xad64b8: bl              #0xad650c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_diagonalSupport
    // 0xad64bc: add             SP, SP, #0x18
    // 0xad64c0: r0 = inline_Allocate_Double()
    //     0xad64c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xad64c4: add             x0, x0, #0x10
    //     0xad64c8: cmp             x1, x0
    //     0xad64cc: b.ls            #0xad64fc
    //     0xad64d0: str             x0, [THR, #0x60]  ; THR::top
    //     0xad64d4: sub             x0, x0, #0xf
    //     0xad64d8: mov             x1, #0xd108
    //     0xad64dc: movk            x1, #3, lsl #16
    //     0xad64e0: stur            x1, [x0, #-1]
    // 0xad64e4: StoreField: r0->field_7 = d0
    //     0xad64e4: stur            d0, [x0, #7]
    // 0xad64e8: LeaveFrame
    //     0xad64e8: mov             SP, fp
    //     0xad64ec: ldp             fp, lr, [SP], #0x10
    // 0xad64f0: ret
    //     0xad64f0: ret             
    // 0xad64f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad64f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad64f8: b               #0xad649c
    // 0xad64fc: SaveReg d0
    //     0xad64fc: str             q0, [SP, #-0x10]!
    // 0xad6500: r0 = AllocateDouble()
    //     0xad6500: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xad6504: RestoreReg d0
    //     0xad6504: ldr             q0, [SP], #0x10
    // 0xad6508: b               #0xad64e4
  }
  _ _diagonalSupport(/* No info */) {
    // ** addr: 0xad650c, size: 0xf4
    // 0xad650c: EnterFrame
    //     0xad650c: stp             fp, lr, [SP, #-0x10]!
    //     0xad6510: mov             fp, SP
    // 0xad6514: AllocStack(0x8)
    //     0xad6514: sub             SP, SP, #8
    // 0xad6518: CheckStackOverflow
    //     0xad6518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad651c: cmp             SP, x16
    //     0xad6520: b.ls            #0xad65ec
    // 0xad6524: ldr             x0, [fp, #0x20]
    // 0xad6528: LoadField: r1 = r0->field_b
    //     0xad6528: ldur            w1, [x0, #0xb]
    // 0xad652c: DecompressPointer r1
    //     0xad652c: add             x1, x1, HEAP, lsl #32
    // 0xad6530: cmp             w1, NULL
    // 0xad6534: b.eq            #0xad65f4
    // 0xad6538: ldr             x2, [fp, #0x10]
    // 0xad653c: LoadField: r3 = r2->field_b
    //     0xad653c: ldur            w3, [x2, #0xb]
    // 0xad6540: DecompressPointer r3
    //     0xad6540: add             x3, x3, HEAP, lsl #32
    // 0xad6544: stp             x1, x0, [SP, #-0x10]!
    // 0xad6548: SaveReg r3
    //     0xad6548: str             x3, [SP, #-8]!
    // 0xad654c: r0 = _cornerFor()
    //     0xad654c: bl              #0xad622c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0xad6550: add             SP, SP, #0x18
    // 0xad6554: mov             x1, x0
    // 0xad6558: ldr             x0, [fp, #0x20]
    // 0xad655c: stur            x1, [fp, #-8]
    // 0xad6560: LoadField: r2 = r0->field_b
    //     0xad6560: ldur            w2, [x0, #0xb]
    // 0xad6564: DecompressPointer r2
    //     0xad6564: add             x2, x2, HEAP, lsl #32
    // 0xad6568: cmp             w2, NULL
    // 0xad656c: b.eq            #0xad65f8
    // 0xad6570: ldr             x3, [fp, #0x10]
    // 0xad6574: LoadField: r4 = r3->field_7
    //     0xad6574: ldur            w4, [x3, #7]
    // 0xad6578: DecompressPointer r4
    //     0xad6578: add             x4, x4, HEAP, lsl #32
    // 0xad657c: stp             x2, x0, [SP, #-0x10]!
    // 0xad6580: SaveReg r4
    //     0xad6580: str             x4, [SP, #-8]!
    // 0xad6584: r0 = _cornerFor()
    //     0xad6584: bl              #0xad622c  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_cornerFor
    // 0xad6588: add             SP, SP, #0x18
    // 0xad658c: mov             x1, x0
    // 0xad6590: ldur            x0, [fp, #-8]
    // 0xad6594: cmp             w0, NULL
    // 0xad6598: b.eq            #0xad65fc
    // 0xad659c: stp             x1, x0, [SP, #-0x10]!
    // 0xad65a0: r0 = -()
    //     0xad65a0: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xad65a4: add             SP, SP, #0x10
    // 0xad65a8: LoadField: d1 = r0->field_7
    //     0xad65a8: ldur            d1, [x0, #7]
    // 0xad65ac: fmul            d2, d1, d1
    // 0xad65b0: LoadField: d3 = r0->field_f
    //     0xad65b0: ldur            d3, [x0, #0xf]
    // 0xad65b4: fmul            d4, d3, d3
    // 0xad65b8: fadd            d5, d2, d4
    // 0xad65bc: fsqrt           d2, d5
    // 0xad65c0: ldr             x0, [fp, #0x18]
    // 0xad65c4: LoadField: d4 = r0->field_7
    //     0xad65c4: ldur            d4, [x0, #7]
    // 0xad65c8: fmul            d5, d4, d1
    // 0xad65cc: fdiv            d1, d5, d2
    // 0xad65d0: LoadField: d4 = r0->field_f
    //     0xad65d0: ldur            d4, [x0, #0xf]
    // 0xad65d4: fmul            d5, d4, d3
    // 0xad65d8: fdiv            d3, d5, d2
    // 0xad65dc: fadd            d0, d1, d3
    // 0xad65e0: LeaveFrame
    //     0xad65e0: mov             SP, fp
    //     0xad65e4: ldp             fp, lr, [SP], #0x10
    // 0xad65e8: ret
    //     0xad65e8: ret             
    // 0xad65ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad65ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad65f0: b               #0xad6524
    // 0xad65f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad65f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad65f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xad65f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xad65fc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xad65fc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  get _ beginArc(/* No info */) {
    // ** addr: 0xad6600, size: 0x88
    // 0xad6600: EnterFrame
    //     0xad6600: stp             fp, lr, [SP, #-0x10]!
    //     0xad6604: mov             fp, SP
    // 0xad6608: CheckStackOverflow
    //     0xad6608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad660c: cmp             SP, x16
    //     0xad6610: b.ls            #0xad6674
    // 0xad6614: ldr             x0, [fp, #0x10]
    // 0xad6618: LoadField: r1 = r0->field_b
    //     0xad6618: ldur            w1, [x0, #0xb]
    // 0xad661c: DecompressPointer r1
    //     0xad661c: add             x1, x1, HEAP, lsl #32
    // 0xad6620: cmp             w1, NULL
    // 0xad6624: b.ne            #0xad6638
    // 0xad6628: r0 = Null
    //     0xad6628: mov             x0, NULL
    // 0xad662c: LeaveFrame
    //     0xad662c: mov             SP, fp
    //     0xad6630: ldp             fp, lr, [SP], #0x10
    // 0xad6634: ret
    //     0xad6634: ret             
    // 0xad6638: LoadField: r1 = r0->field_13
    //     0xad6638: ldur            w1, [x0, #0x13]
    // 0xad663c: DecompressPointer r1
    //     0xad663c: add             x1, x1, HEAP, lsl #32
    // 0xad6640: tbnz            w1, #4, #0xad6650
    // 0xad6644: SaveReg r0
    //     0xad6644: str             x0, [SP, #-8]!
    // 0xad6648: r0 = _initialize()
    //     0xad6648: bl              #0xad5fc8  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_initialize
    // 0xad664c: add             SP, SP, #8
    // 0xad6650: ldr             x1, [fp, #0x10]
    // 0xad6654: LoadField: r0 = r1->field_17
    //     0xad6654: ldur            w0, [x1, #0x17]
    // 0xad6658: DecompressPointer r0
    //     0xad6658: add             x0, x0, HEAP, lsl #32
    // 0xad665c: r16 = Sentinel
    //     0xad665c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xad6660: cmp             w0, w16
    // 0xad6664: b.eq            #0xad667c
    // 0xad6668: LeaveFrame
    //     0xad6668: mov             SP, fp
    //     0xad666c: ldp             fp, lr, [SP], #0x10
    // 0xad6670: ret
    //     0xad6670: ret             
    // 0xad6674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad6674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad6678: b               #0xad6614
    // 0xad667c: r9 = _beginArc
    //     0xad667c: add             x9, PP, #0x22, lsl #12  ; [pp+0x22118] Field <MaterialRectArcTween._beginArc@682458455>: late (offset: 0x18)
    //     0xad6680: ldr             x9, [x9, #0x118]
    // 0xad6684: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xad6684: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ lerp(/* No info */) {
    // ** addr: 0xbec514, size: 0x154
    // 0xbec514: EnterFrame
    //     0xbec514: stp             fp, lr, [SP, #-0x10]!
    //     0xbec518: mov             fp, SP
    // 0xbec51c: AllocStack(0x18)
    //     0xbec51c: sub             SP, SP, #0x18
    // 0xbec520: CheckStackOverflow
    //     0xbec520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbec524: cmp             SP, x16
    //     0xbec528: b.ls            #0xbec640
    // 0xbec52c: ldr             x0, [fp, #0x18]
    // 0xbec530: LoadField: r1 = r0->field_13
    //     0xbec530: ldur            w1, [x0, #0x13]
    // 0xbec534: DecompressPointer r1
    //     0xbec534: add             x1, x1, HEAP, lsl #32
    // 0xbec538: tbnz            w1, #4, #0xbec548
    // 0xbec53c: SaveReg r0
    //     0xbec53c: str             x0, [SP, #-8]!
    // 0xbec540: r0 = _initialize()
    //     0xbec540: bl              #0xad5fc8  ; [package:flutter/src/material/arc.dart] MaterialRectArcTween::_initialize
    // 0xbec544: add             SP, SP, #8
    // 0xbec548: ldr             d1, [fp, #0x10]
    // 0xbec54c: d0 = 0.000000
    //     0xbec54c: eor             v0.16b, v0.16b, v0.16b
    // 0xbec550: fcmp            d1, d0
    // 0xbec554: b.vs            #0xbec580
    // 0xbec558: b.ne            #0xbec580
    // 0xbec55c: ldr             x0, [fp, #0x18]
    // 0xbec560: LoadField: r1 = r0->field_b
    //     0xbec560: ldur            w1, [x0, #0xb]
    // 0xbec564: DecompressPointer r1
    //     0xbec564: add             x1, x1, HEAP, lsl #32
    // 0xbec568: cmp             w1, NULL
    // 0xbec56c: b.eq            #0xbec648
    // 0xbec570: mov             x0, x1
    // 0xbec574: LeaveFrame
    //     0xbec574: mov             SP, fp
    //     0xbec578: ldp             fp, lr, [SP], #0x10
    // 0xbec57c: ret
    //     0xbec57c: ret             
    // 0xbec580: ldr             x0, [fp, #0x18]
    // 0xbec584: d0 = 1.000000
    //     0xbec584: fmov            d0, #1.00000000
    // 0xbec588: fcmp            d1, d0
    // 0xbec58c: b.vs            #0xbec5b4
    // 0xbec590: b.ne            #0xbec5b4
    // 0xbec594: LoadField: r1 = r0->field_f
    //     0xbec594: ldur            w1, [x0, #0xf]
    // 0xbec598: DecompressPointer r1
    //     0xbec598: add             x1, x1, HEAP, lsl #32
    // 0xbec59c: cmp             w1, NULL
    // 0xbec5a0: b.eq            #0xbec64c
    // 0xbec5a4: mov             x0, x1
    // 0xbec5a8: LeaveFrame
    //     0xbec5a8: mov             SP, fp
    //     0xbec5ac: ldp             fp, lr, [SP], #0x10
    // 0xbec5b0: ret
    //     0xbec5b0: ret             
    // 0xbec5b4: LoadField: r1 = r0->field_17
    //     0xbec5b4: ldur            w1, [x0, #0x17]
    // 0xbec5b8: DecompressPointer r1
    //     0xbec5b8: add             x1, x1, HEAP, lsl #32
    // 0xbec5bc: r16 = Sentinel
    //     0xbec5bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbec5c0: cmp             w1, w16
    // 0xbec5c4: b.eq            #0xbec650
    // 0xbec5c8: SaveReg r1
    //     0xbec5c8: str             x1, [SP, #-8]!
    // 0xbec5cc: SaveReg d1
    //     0xbec5cc: str             d1, [SP, #-8]!
    // 0xbec5d0: r0 = lerp()
    //     0xbec5d0: bl              #0xbec8b0  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::lerp
    // 0xbec5d4: add             SP, SP, #0x10
    // 0xbec5d8: mov             x1, x0
    // 0xbec5dc: ldr             x0, [fp, #0x18]
    // 0xbec5e0: stur            x1, [fp, #-8]
    // 0xbec5e4: LoadField: r2 = r0->field_1b
    //     0xbec5e4: ldur            w2, [x0, #0x1b]
    // 0xbec5e8: DecompressPointer r2
    //     0xbec5e8: add             x2, x2, HEAP, lsl #32
    // 0xbec5ec: r16 = Sentinel
    //     0xbec5ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbec5f0: cmp             w2, w16
    // 0xbec5f4: b.eq            #0xbec65c
    // 0xbec5f8: SaveReg r2
    //     0xbec5f8: str             x2, [SP, #-8]!
    // 0xbec5fc: ldr             d0, [fp, #0x10]
    // 0xbec600: SaveReg d0
    //     0xbec600: str             d0, [SP, #-8]!
    // 0xbec604: r0 = lerp()
    //     0xbec604: bl              #0xbec8b0  ; [package:flutter/src/material/arc.dart] MaterialPointArcTween::lerp
    // 0xbec608: add             SP, SP, #0x10
    // 0xbec60c: stur            x0, [fp, #-0x10]
    // 0xbec610: r0 = Rect()
    //     0xbec610: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xbec614: stur            x0, [fp, #-0x18]
    // 0xbec618: ldur            x16, [fp, #-8]
    // 0xbec61c: stp             x16, x0, [SP, #-0x10]!
    // 0xbec620: ldur            x16, [fp, #-0x10]
    // 0xbec624: SaveReg r16
    //     0xbec624: str             x16, [SP, #-8]!
    // 0xbec628: r0 = Rect.fromPoints()
    //     0xbec628: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0xbec62c: add             SP, SP, #0x18
    // 0xbec630: ldur            x0, [fp, #-0x18]
    // 0xbec634: LeaveFrame
    //     0xbec634: mov             SP, fp
    //     0xbec638: ldp             fp, lr, [SP], #0x10
    // 0xbec63c: ret
    //     0xbec63c: ret             
    // 0xbec640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbec640: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbec644: b               #0xbec52c
    // 0xbec648: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec648: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbec64c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbec64c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbec650: r9 = _beginArc
    //     0xbec650: add             x9, PP, #0x22, lsl #12  ; [pp+0x22118] Field <MaterialRectArcTween._beginArc@682458455>: late (offset: 0x18)
    //     0xbec654: ldr             x9, [x9, #0x118]
    // 0xbec658: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbec658: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbec65c: r9 = _endArc
    //     0xbec65c: add             x9, PP, #0x22, lsl #12  ; [pp+0x220e0] Field <MaterialRectArcTween._endArc@682458455>: late (offset: 0x1c)
    //     0xbec660: ldr             x9, [x9, #0xe0]
    // 0xbec664: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbec664: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ end=(/* No info */) {
    // ** addr: 0xbfa2b4, size: 0x10c
    // 0xbfa2b4: EnterFrame
    //     0xbfa2b4: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa2b8: mov             fp, SP
    // 0xbfa2bc: CheckStackOverflow
    //     0xbfa2bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa2c0: cmp             SP, x16
    //     0xbfa2c4: b.ls            #0xbfa3b8
    // 0xbfa2c8: ldr             x0, [fp, #0x10]
    // 0xbfa2cc: r2 = Null
    //     0xbfa2cc: mov             x2, NULL
    // 0xbfa2d0: r1 = Null
    //     0xbfa2d0: mov             x1, NULL
    // 0xbfa2d4: r4 = 59
    //     0xbfa2d4: mov             x4, #0x3b
    // 0xbfa2d8: branchIfSmi(r0, 0xbfa2e4)
    //     0xbfa2d8: tbz             w0, #0, #0xbfa2e4
    // 0xbfa2dc: r4 = LoadClassIdInstr(r0)
    //     0xbfa2dc: ldur            x4, [x0, #-1]
    //     0xbfa2e0: ubfx            x4, x4, #0xc, #0x14
    // 0xbfa2e4: r17 = 5071
    //     0xbfa2e4: mov             x17, #0x13cf
    // 0xbfa2e8: cmp             x4, x17
    // 0xbfa2ec: b.eq            #0xbfa304
    // 0xbfa2f0: r8 = Rect?
    //     0xbfa2f0: add             x8, PP, #0x28, lsl #12  ; [pp+0x28c78] Type: Rect?
    //     0xbfa2f4: ldr             x8, [x8, #0xc78]
    // 0xbfa2f8: r3 = Null
    //     0xbfa2f8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28c80] Null
    //     0xbfa2fc: ldr             x3, [x3, #0xc80]
    // 0xbfa300: r0 = Rect?()
    //     0xbfa300: bl              #0x4f6064  ; IsType_Rect?_Stub
    // 0xbfa304: ldr             x1, [fp, #0x18]
    // 0xbfa308: LoadField: r0 = r1->field_f
    //     0xbfa308: ldur            w0, [x1, #0xf]
    // 0xbfa30c: DecompressPointer r0
    //     0xbfa30c: add             x0, x0, HEAP, lsl #32
    // 0xbfa310: ldr             x2, [fp, #0x10]
    // 0xbfa314: r3 = LoadClassIdInstr(r2)
    //     0xbfa314: ldur            x3, [x2, #-1]
    //     0xbfa318: ubfx            x3, x3, #0xc, #0x14
    // 0xbfa31c: stp             x0, x2, [SP, #-0x10]!
    // 0xbfa320: mov             x0, x3
    // 0xbfa324: mov             lr, x0
    // 0xbfa328: ldr             lr, [x21, lr, lsl #3]
    // 0xbfa32c: blr             lr
    // 0xbfa330: add             SP, SP, #0x10
    // 0xbfa334: tbz             w0, #4, #0xbfa3a8
    // 0xbfa338: ldr             x3, [fp, #0x18]
    // 0xbfa33c: LoadField: r2 = r3->field_7
    //     0xbfa33c: ldur            w2, [x3, #7]
    // 0xbfa340: DecompressPointer r2
    //     0xbfa340: add             x2, x2, HEAP, lsl #32
    // 0xbfa344: ldr             x0, [fp, #0x10]
    // 0xbfa348: r1 = Null
    //     0xbfa348: mov             x1, NULL
    // 0xbfa34c: cmp             w0, NULL
    // 0xbfa350: b.eq            #0xbfa378
    // 0xbfa354: cmp             w2, NULL
    // 0xbfa358: b.eq            #0xbfa378
    // 0xbfa35c: LoadField: r4 = r2->field_17
    //     0xbfa35c: ldur            w4, [x2, #0x17]
    // 0xbfa360: DecompressPointer r4
    //     0xbfa360: add             x4, x4, HEAP, lsl #32
    // 0xbfa364: r8 = X0?
    //     0xbfa364: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xbfa368: LoadField: r9 = r4->field_7
    //     0xbfa368: ldur            x9, [x4, #7]
    // 0xbfa36c: r3 = Null
    //     0xbfa36c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28c90] Null
    //     0xbfa370: ldr             x3, [x3, #0xc90]
    // 0xbfa374: blr             x9
    // 0xbfa378: ldr             x0, [fp, #0x10]
    // 0xbfa37c: ldr             x1, [fp, #0x18]
    // 0xbfa380: StoreField: r1->field_f = r0
    //     0xbfa380: stur            w0, [x1, #0xf]
    //     0xbfa384: tbz             w0, #0, #0xbfa3a0
    //     0xbfa388: ldurb           w16, [x1, #-1]
    //     0xbfa38c: ldurb           w17, [x0, #-1]
    //     0xbfa390: and             x16, x17, x16, lsr #2
    //     0xbfa394: tst             x16, HEAP, lsr #32
    //     0xbfa398: b.eq            #0xbfa3a0
    //     0xbfa39c: bl              #0xd6826c
    // 0xbfa3a0: r2 = true
    //     0xbfa3a0: add             x2, NULL, #0x20  ; true
    // 0xbfa3a4: StoreField: r1->field_13 = r2
    //     0xbfa3a4: stur            w2, [x1, #0x13]
    // 0xbfa3a8: r0 = Null
    //     0xbfa3a8: mov             x0, NULL
    // 0xbfa3ac: LeaveFrame
    //     0xbfa3ac: mov             SP, fp
    //     0xbfa3b0: ldp             fp, lr, [SP], #0x10
    // 0xbfa3b4: ret
    //     0xbfa3b4: ret             
    // 0xbfa3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa3b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa3bc: b               #0xbfa2c8
  }
  set _ begin=(/* No info */) {
    // ** addr: 0xbfa54c, size: 0x10c
    // 0xbfa54c: EnterFrame
    //     0xbfa54c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfa550: mov             fp, SP
    // 0xbfa554: CheckStackOverflow
    //     0xbfa554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfa558: cmp             SP, x16
    //     0xbfa55c: b.ls            #0xbfa650
    // 0xbfa560: ldr             x0, [fp, #0x10]
    // 0xbfa564: r2 = Null
    //     0xbfa564: mov             x2, NULL
    // 0xbfa568: r1 = Null
    //     0xbfa568: mov             x1, NULL
    // 0xbfa56c: r4 = 59
    //     0xbfa56c: mov             x4, #0x3b
    // 0xbfa570: branchIfSmi(r0, 0xbfa57c)
    //     0xbfa570: tbz             w0, #0, #0xbfa57c
    // 0xbfa574: r4 = LoadClassIdInstr(r0)
    //     0xbfa574: ldur            x4, [x0, #-1]
    //     0xbfa578: ubfx            x4, x4, #0xc, #0x14
    // 0xbfa57c: r17 = 5071
    //     0xbfa57c: mov             x17, #0x13cf
    // 0xbfa580: cmp             x4, x17
    // 0xbfa584: b.eq            #0xbfa59c
    // 0xbfa588: r8 = Rect?
    //     0xbfa588: add             x8, PP, #0x28, lsl #12  ; [pp+0x28c78] Type: Rect?
    //     0xbfa58c: ldr             x8, [x8, #0xc78]
    // 0xbfa590: r3 = Null
    //     0xbfa590: add             x3, PP, #0x28, lsl #12  ; [pp+0x28ca0] Null
    //     0xbfa594: ldr             x3, [x3, #0xca0]
    // 0xbfa598: r0 = Rect?()
    //     0xbfa598: bl              #0x4f6064  ; IsType_Rect?_Stub
    // 0xbfa59c: ldr             x1, [fp, #0x18]
    // 0xbfa5a0: LoadField: r0 = r1->field_b
    //     0xbfa5a0: ldur            w0, [x1, #0xb]
    // 0xbfa5a4: DecompressPointer r0
    //     0xbfa5a4: add             x0, x0, HEAP, lsl #32
    // 0xbfa5a8: ldr             x2, [fp, #0x10]
    // 0xbfa5ac: r3 = LoadClassIdInstr(r2)
    //     0xbfa5ac: ldur            x3, [x2, #-1]
    //     0xbfa5b0: ubfx            x3, x3, #0xc, #0x14
    // 0xbfa5b4: stp             x0, x2, [SP, #-0x10]!
    // 0xbfa5b8: mov             x0, x3
    // 0xbfa5bc: mov             lr, x0
    // 0xbfa5c0: ldr             lr, [x21, lr, lsl #3]
    // 0xbfa5c4: blr             lr
    // 0xbfa5c8: add             SP, SP, #0x10
    // 0xbfa5cc: tbz             w0, #4, #0xbfa640
    // 0xbfa5d0: ldr             x3, [fp, #0x18]
    // 0xbfa5d4: LoadField: r2 = r3->field_7
    //     0xbfa5d4: ldur            w2, [x3, #7]
    // 0xbfa5d8: DecompressPointer r2
    //     0xbfa5d8: add             x2, x2, HEAP, lsl #32
    // 0xbfa5dc: ldr             x0, [fp, #0x10]
    // 0xbfa5e0: r1 = Null
    //     0xbfa5e0: mov             x1, NULL
    // 0xbfa5e4: cmp             w0, NULL
    // 0xbfa5e8: b.eq            #0xbfa610
    // 0xbfa5ec: cmp             w2, NULL
    // 0xbfa5f0: b.eq            #0xbfa610
    // 0xbfa5f4: LoadField: r4 = r2->field_17
    //     0xbfa5f4: ldur            w4, [x2, #0x17]
    // 0xbfa5f8: DecompressPointer r4
    //     0xbfa5f8: add             x4, x4, HEAP, lsl #32
    // 0xbfa5fc: r8 = X0?
    //     0xbfa5fc: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0xbfa600: LoadField: r9 = r4->field_7
    //     0xbfa600: ldur            x9, [x4, #7]
    // 0xbfa604: r3 = Null
    //     0xbfa604: add             x3, PP, #0x28, lsl #12  ; [pp+0x28cb0] Null
    //     0xbfa608: ldr             x3, [x3, #0xcb0]
    // 0xbfa60c: blr             x9
    // 0xbfa610: ldr             x0, [fp, #0x10]
    // 0xbfa614: ldr             x1, [fp, #0x18]
    // 0xbfa618: StoreField: r1->field_b = r0
    //     0xbfa618: stur            w0, [x1, #0xb]
    //     0xbfa61c: tbz             w0, #0, #0xbfa638
    //     0xbfa620: ldurb           w16, [x1, #-1]
    //     0xbfa624: ldurb           w17, [x0, #-1]
    //     0xbfa628: and             x16, x17, x16, lsr #2
    //     0xbfa62c: tst             x16, HEAP, lsr #32
    //     0xbfa630: b.eq            #0xbfa638
    //     0xbfa634: bl              #0xd6826c
    // 0xbfa638: r2 = true
    //     0xbfa638: add             x2, NULL, #0x20  ; true
    // 0xbfa63c: StoreField: r1->field_13 = r2
    //     0xbfa63c: stur            w2, [x1, #0x13]
    // 0xbfa640: r0 = Null
    //     0xbfa640: mov             x0, NULL
    // 0xbfa644: LeaveFrame
    //     0xbfa644: mov             SP, fp
    //     0xbfa648: ldp             fp, lr, [SP], #0x10
    // 0xbfa64c: ret
    //     0xbfa64c: ret             
    // 0xbfa650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfa650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfa654: b               #0xbfa560
  }
}

// class id: 5974, size: 0x14, field offset: 0x14
enum _CornerId extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15f6c, size: 0x5c
    // 0xb15f6c: EnterFrame
    //     0xb15f6c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15f70: mov             fp, SP
    // 0xb15f74: CheckStackOverflow
    //     0xb15f74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15f78: cmp             SP, x16
    //     0xb15f7c: b.ls            #0xb15fc0
    // 0xb15f80: r1 = Null
    //     0xb15f80: mov             x1, NULL
    // 0xb15f84: r2 = 4
    //     0xb15f84: mov             x2, #4
    // 0xb15f88: r0 = AllocateArray()
    //     0xb15f88: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15f8c: r17 = "_CornerId."
    //     0xb15f8c: add             x17, PP, #0x28, lsl #12  ; [pp+0x28cc0] "_CornerId."
    //     0xb15f90: ldr             x17, [x17, #0xcc0]
    // 0xb15f94: StoreField: r0->field_f = r17
    //     0xb15f94: stur            w17, [x0, #0xf]
    // 0xb15f98: ldr             x1, [fp, #0x10]
    // 0xb15f9c: LoadField: r2 = r1->field_f
    //     0xb15f9c: ldur            w2, [x1, #0xf]
    // 0xb15fa0: DecompressPointer r2
    //     0xb15fa0: add             x2, x2, HEAP, lsl #32
    // 0xb15fa4: StoreField: r0->field_13 = r2
    //     0xb15fa4: stur            w2, [x0, #0x13]
    // 0xb15fa8: SaveReg r0
    //     0xb15fa8: str             x0, [SP, #-8]!
    // 0xb15fac: r0 = _interpolate()
    //     0xb15fac: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15fb0: add             SP, SP, #8
    // 0xb15fb4: LeaveFrame
    //     0xb15fb4: mov             SP, fp
    //     0xb15fb8: ldp             fp, lr, [SP], #0x10
    // 0xb15fbc: ret
    //     0xb15fbc: ret             
    // 0xb15fc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15fc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15fc4: b               #0xb15f80
  }
}

// lib: , url: package:flutter/src/material/color_scheme.dart

// class id: 1049210, size: 0x8
class :: {
}

// class id: 2814, size: 0x8c, field offset: 0x8
//   const constructor, 
class ColorScheme extends _DiagnosticableTree&Object&Diagnosticable {

  Brightness field_8;
  Color field_c;
  Color field_10;
  Color field_14;
  Color field_18;
  Color field_1c;
  Color field_20;
  Color field_24;
  Color field_28;
  Color field_2c;
  Color field_30;
  Color field_34;
  Color field_38;
  Color field_3c;
  Color field_40;
  Color field_44;
  Color field_48;
  Color field_4c;
  Color field_50;
  Color field_54;
  Color field_58;
  Color field_5c;
  Color field_60;
  Color field_64;
  Color field_68;
  Color field_6c;
  Color field_70;
  Color field_74;
  Color field_78;
  Color field_7c;
  Color field_80;

  _ copyWith(/* No info */) {
    // ** addr: 0x6cd13c, size: 0x3f4
    // 0x6cd13c: EnterFrame
    //     0x6cd13c: stp             fp, lr, [SP, #-0x10]!
    //     0x6cd140: mov             fp, SP
    // 0x6cd144: AllocStack(0x108)
    //     0x6cd144: sub             SP, SP, #0x108
    // 0x6cd148: CheckStackOverflow
    //     0x6cd148: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cd14c: cmp             SP, x16
    //     0x6cd150: b.ls            #0x6cd528
    // 0x6cd154: ldr             x0, [fp, #0x10]
    // 0x6cd158: LoadField: r1 = r0->field_7
    //     0x6cd158: ldur            w1, [x0, #7]
    // 0x6cd15c: DecompressPointer r1
    //     0x6cd15c: add             x1, x1, HEAP, lsl #32
    // 0x6cd160: stur            x1, [fp, #-0x58]
    // 0x6cd164: LoadField: r2 = r0->field_b
    //     0x6cd164: ldur            w2, [x0, #0xb]
    // 0x6cd168: DecompressPointer r2
    //     0x6cd168: add             x2, x2, HEAP, lsl #32
    // 0x6cd16c: stur            x2, [fp, #-0x50]
    // 0x6cd170: LoadField: r3 = r0->field_f
    //     0x6cd170: ldur            w3, [x0, #0xf]
    // 0x6cd174: DecompressPointer r3
    //     0x6cd174: add             x3, x3, HEAP, lsl #32
    // 0x6cd178: stur            x3, [fp, #-0x48]
    // 0x6cd17c: LoadField: r4 = r0->field_13
    //     0x6cd17c: ldur            w4, [x0, #0x13]
    // 0x6cd180: DecompressPointer r4
    //     0x6cd180: add             x4, x4, HEAP, lsl #32
    // 0x6cd184: cmp             w4, NULL
    // 0x6cd188: b.ne            #0x6cd190
    // 0x6cd18c: mov             x4, x2
    // 0x6cd190: stur            x4, [fp, #-0x40]
    // 0x6cd194: LoadField: r5 = r0->field_17
    //     0x6cd194: ldur            w5, [x0, #0x17]
    // 0x6cd198: DecompressPointer r5
    //     0x6cd198: add             x5, x5, HEAP, lsl #32
    // 0x6cd19c: cmp             w5, NULL
    // 0x6cd1a0: b.ne            #0x6cd1a8
    // 0x6cd1a4: mov             x5, x3
    // 0x6cd1a8: stur            x5, [fp, #-0x38]
    // 0x6cd1ac: LoadField: r6 = r0->field_1b
    //     0x6cd1ac: ldur            w6, [x0, #0x1b]
    // 0x6cd1b0: DecompressPointer r6
    //     0x6cd1b0: add             x6, x6, HEAP, lsl #32
    // 0x6cd1b4: stur            x6, [fp, #-0x30]
    // 0x6cd1b8: LoadField: r7 = r0->field_1f
    //     0x6cd1b8: ldur            w7, [x0, #0x1f]
    // 0x6cd1bc: DecompressPointer r7
    //     0x6cd1bc: add             x7, x7, HEAP, lsl #32
    // 0x6cd1c0: stur            x7, [fp, #-0x28]
    // 0x6cd1c4: LoadField: r8 = r0->field_23
    //     0x6cd1c4: ldur            w8, [x0, #0x23]
    // 0x6cd1c8: DecompressPointer r8
    //     0x6cd1c8: add             x8, x8, HEAP, lsl #32
    // 0x6cd1cc: cmp             w8, NULL
    // 0x6cd1d0: b.ne            #0x6cd1d8
    // 0x6cd1d4: mov             x8, x6
    // 0x6cd1d8: stur            x8, [fp, #-0x20]
    // 0x6cd1dc: LoadField: r9 = r0->field_27
    //     0x6cd1dc: ldur            w9, [x0, #0x27]
    // 0x6cd1e0: DecompressPointer r9
    //     0x6cd1e0: add             x9, x9, HEAP, lsl #32
    // 0x6cd1e4: cmp             w9, NULL
    // 0x6cd1e8: b.ne            #0x6cd1f0
    // 0x6cd1ec: mov             x9, x7
    // 0x6cd1f0: stur            x9, [fp, #-0x18]
    // 0x6cd1f4: LoadField: r10 = r0->field_2b
    //     0x6cd1f4: ldur            w10, [x0, #0x2b]
    // 0x6cd1f8: DecompressPointer r10
    //     0x6cd1f8: add             x10, x10, HEAP, lsl #32
    // 0x6cd1fc: cmp             w10, NULL
    // 0x6cd200: b.ne            #0x6cd208
    // 0x6cd204: mov             x10, x6
    // 0x6cd208: stur            x10, [fp, #-0x10]
    // 0x6cd20c: LoadField: r11 = r0->field_2f
    //     0x6cd20c: ldur            w11, [x0, #0x2f]
    // 0x6cd210: DecompressPointer r11
    //     0x6cd210: add             x11, x11, HEAP, lsl #32
    // 0x6cd214: cmp             w11, NULL
    // 0x6cd218: b.ne            #0x6cd220
    // 0x6cd21c: mov             x11, x7
    // 0x6cd220: stur            x11, [fp, #-8]
    // 0x6cd224: SaveReg r0
    //     0x6cd224: str             x0, [SP, #-8]!
    // 0x6cd228: r0 = tertiaryContainer()
    //     0x6cd228: bl              #0x6cd584  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0x6cd22c: add             SP, SP, #8
    // 0x6cd230: stur            x0, [fp, #-0x60]
    // 0x6cd234: ldr             x16, [fp, #0x10]
    // 0x6cd238: SaveReg r16
    //     0x6cd238: str             x16, [SP, #-8]!
    // 0x6cd23c: r0 = onTertiaryContainer()
    //     0x6cd23c: bl              #0x6cd53c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0x6cd240: add             SP, SP, #8
    // 0x6cd244: mov             x1, x0
    // 0x6cd248: ldr             x0, [fp, #0x10]
    // 0x6cd24c: stur            x1, [fp, #-0x68]
    // 0x6cd250: LoadField: r2 = r0->field_3b
    //     0x6cd250: ldur            w2, [x0, #0x3b]
    // 0x6cd254: DecompressPointer r2
    //     0x6cd254: add             x2, x2, HEAP, lsl #32
    // 0x6cd258: r17 = -264
    //     0x6cd258: mov             x17, #-0x108
    // 0x6cd25c: str             x2, [fp, x17]
    // 0x6cd260: LoadField: r3 = r0->field_3f
    //     0x6cd260: ldur            w3, [x0, #0x3f]
    // 0x6cd264: DecompressPointer r3
    //     0x6cd264: add             x3, x3, HEAP, lsl #32
    // 0x6cd268: stur            x3, [fp, #-0x100]
    // 0x6cd26c: LoadField: r4 = r0->field_43
    //     0x6cd26c: ldur            w4, [x0, #0x43]
    // 0x6cd270: DecompressPointer r4
    //     0x6cd270: add             x4, x4, HEAP, lsl #32
    // 0x6cd274: cmp             w4, NULL
    // 0x6cd278: b.ne            #0x6cd280
    // 0x6cd27c: mov             x4, x2
    // 0x6cd280: stur            x4, [fp, #-0xf8]
    // 0x6cd284: LoadField: r5 = r0->field_47
    //     0x6cd284: ldur            w5, [x0, #0x47]
    // 0x6cd288: DecompressPointer r5
    //     0x6cd288: add             x5, x5, HEAP, lsl #32
    // 0x6cd28c: cmp             w5, NULL
    // 0x6cd290: b.ne            #0x6cd298
    // 0x6cd294: mov             x5, x3
    // 0x6cd298: stur            x5, [fp, #-0xf0]
    // 0x6cd29c: LoadField: r6 = r0->field_4b
    //     0x6cd29c: ldur            w6, [x0, #0x4b]
    // 0x6cd2a0: DecompressPointer r6
    //     0x6cd2a0: add             x6, x6, HEAP, lsl #32
    // 0x6cd2a4: stur            x6, [fp, #-0xe8]
    // 0x6cd2a8: LoadField: r7 = r0->field_4f
    //     0x6cd2a8: ldur            w7, [x0, #0x4f]
    // 0x6cd2ac: DecompressPointer r7
    //     0x6cd2ac: add             x7, x7, HEAP, lsl #32
    // 0x6cd2b0: stur            x7, [fp, #-0xe0]
    // 0x6cd2b4: LoadField: r8 = r0->field_53
    //     0x6cd2b4: ldur            w8, [x0, #0x53]
    // 0x6cd2b8: DecompressPointer r8
    //     0x6cd2b8: add             x8, x8, HEAP, lsl #32
    // 0x6cd2bc: stur            x8, [fp, #-0xd8]
    // 0x6cd2c0: LoadField: r9 = r0->field_57
    //     0x6cd2c0: ldur            w9, [x0, #0x57]
    // 0x6cd2c4: DecompressPointer r9
    //     0x6cd2c4: add             x9, x9, HEAP, lsl #32
    // 0x6cd2c8: stur            x9, [fp, #-0xd0]
    // 0x6cd2cc: LoadField: r10 = r0->field_5b
    //     0x6cd2cc: ldur            w10, [x0, #0x5b]
    // 0x6cd2d0: DecompressPointer r10
    //     0x6cd2d0: add             x10, x10, HEAP, lsl #32
    // 0x6cd2d4: cmp             w10, NULL
    // 0x6cd2d8: b.ne            #0x6cd2e0
    // 0x6cd2dc: mov             x10, x8
    // 0x6cd2e0: stur            x10, [fp, #-0xc8]
    // 0x6cd2e4: LoadField: r11 = r0->field_5f
    //     0x6cd2e4: ldur            w11, [x0, #0x5f]
    // 0x6cd2e8: DecompressPointer r11
    //     0x6cd2e8: add             x11, x11, HEAP, lsl #32
    // 0x6cd2ec: cmp             w11, NULL
    // 0x6cd2f0: b.ne            #0x6cd2f8
    // 0x6cd2f4: mov             x11, x9
    // 0x6cd2f8: stur            x11, [fp, #-0xc0]
    // 0x6cd2fc: LoadField: r12 = r0->field_63
    //     0x6cd2fc: ldur            w12, [x0, #0x63]
    // 0x6cd300: DecompressPointer r12
    //     0x6cd300: add             x12, x12, HEAP, lsl #32
    // 0x6cd304: cmp             w12, NULL
    // 0x6cd308: b.ne            #0x6cd310
    // 0x6cd30c: mov             x12, x7
    // 0x6cd310: stur            x12, [fp, #-0xb8]
    // 0x6cd314: LoadField: r13 = r0->field_67
    //     0x6cd314: ldur            w13, [x0, #0x67]
    // 0x6cd318: DecompressPointer r13
    //     0x6cd318: add             x13, x13, HEAP, lsl #32
    // 0x6cd31c: cmp             w13, NULL
    // 0x6cd320: b.ne            #0x6cd328
    // 0x6cd324: mov             x13, x7
    // 0x6cd328: stur            x13, [fp, #-0xb0]
    // 0x6cd32c: LoadField: r14 = r0->field_6b
    //     0x6cd32c: ldur            w14, [x0, #0x6b]
    // 0x6cd330: DecompressPointer r14
    //     0x6cd330: add             x14, x14, HEAP, lsl #32
    // 0x6cd334: cmp             w14, NULL
    // 0x6cd338: b.ne            #0x6cd344
    // 0x6cd33c: r14 = Instance_Color
    //     0x6cd33c: add             x14, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6cd340: ldr             x14, [x14, #0xf38]
    // 0x6cd344: stur            x14, [fp, #-0xa8]
    // 0x6cd348: LoadField: r19 = r0->field_6f
    //     0x6cd348: ldur            w19, [x0, #0x6f]
    // 0x6cd34c: DecompressPointer r19
    //     0x6cd34c: add             x19, x19, HEAP, lsl #32
    // 0x6cd350: cmp             w19, NULL
    // 0x6cd354: b.ne            #0x6cd360
    // 0x6cd358: r19 = Instance_Color
    //     0x6cd358: add             x19, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6cd35c: ldr             x19, [x19, #0xf38]
    // 0x6cd360: stur            x19, [fp, #-0xa0]
    // 0x6cd364: LoadField: r20 = r0->field_73
    //     0x6cd364: ldur            w20, [x0, #0x73]
    // 0x6cd368: DecompressPointer r20
    //     0x6cd368: add             x20, x20, HEAP, lsl #32
    // 0x6cd36c: cmp             w20, NULL
    // 0x6cd370: b.ne            #0x6cd378
    // 0x6cd374: mov             x20, x9
    // 0x6cd378: stur            x20, [fp, #-0x98]
    // 0x6cd37c: LoadField: r23 = r0->field_77
    //     0x6cd37c: ldur            w23, [x0, #0x77]
    // 0x6cd380: DecompressPointer r23
    //     0x6cd380: add             x23, x23, HEAP, lsl #32
    // 0x6cd384: cmp             w23, NULL
    // 0x6cd388: b.ne            #0x6cd390
    // 0x6cd38c: mov             x23, x8
    // 0x6cd390: stur            x23, [fp, #-0x90]
    // 0x6cd394: LoadField: r24 = r0->field_7b
    //     0x6cd394: ldur            w24, [x0, #0x7b]
    // 0x6cd398: DecompressPointer r24
    //     0x6cd398: add             x24, x24, HEAP, lsl #32
    // 0x6cd39c: cmp             w24, NULL
    // 0x6cd3a0: b.ne            #0x6cd3a8
    // 0x6cd3a4: ldur            x24, [fp, #-0x48]
    // 0x6cd3a8: stur            x24, [fp, #-0x88]
    // 0x6cd3ac: LoadField: r25 = r0->field_83
    //     0x6cd3ac: ldur            w25, [x0, #0x83]
    // 0x6cd3b0: DecompressPointer r25
    //     0x6cd3b0: add             x25, x25, HEAP, lsl #32
    // 0x6cd3b4: cmp             w25, NULL
    // 0x6cd3b8: b.ne            #0x6cd3c0
    // 0x6cd3bc: ldur            x25, [fp, #-0x50]
    // 0x6cd3c0: stur            x25, [fp, #-0x80]
    // 0x6cd3c4: LoadField: r1 = r0->field_87
    //     0x6cd3c4: ldur            w1, [x0, #0x87]
    // 0x6cd3c8: DecompressPointer r1
    //     0x6cd3c8: add             x1, x1, HEAP, lsl #32
    // 0x6cd3cc: cmp             w1, NULL
    // 0x6cd3d0: b.ne            #0x6cd3d8
    // 0x6cd3d4: ldur            x1, [fp, #-0x30]
    // 0x6cd3d8: stur            x1, [fp, #-0x70]
    // 0x6cd3dc: LoadField: r1 = r0->field_7f
    //     0x6cd3dc: ldur            w1, [x0, #0x7f]
    // 0x6cd3e0: DecompressPointer r1
    //     0x6cd3e0: add             x1, x1, HEAP, lsl #32
    // 0x6cd3e4: cmp             w1, NULL
    // 0x6cd3e8: b.ne            #0x6cd400
    // 0x6cd3ec: SaveReg r0
    //     0x6cd3ec: str             x0, [SP, #-8]!
    // 0x6cd3f0: ldur            x0, [fp, #-0x50]
    // 0x6cd3f4: stur            x0, [fp, #-0x78]
    // 0x6cd3f8: RestoreReg r0
    //     0x6cd3f8: ldr             x0, [SP], #8
    // 0x6cd3fc: b               #0x6cd404
    // 0x6cd400: stur            x1, [fp, #-0x78]
    // 0x6cd404: ldur            x1, [fp, #-0x58]
    // 0x6cd408: ldur            x0, [fp, #-0x60]
    // 0x6cd40c: r0 = ColorScheme()
    //     0x6cd40c: bl              #0x6cd530  ; AllocateColorSchemeStub -> ColorScheme (size=0x8c)
    // 0x6cd410: ldur            x1, [fp, #-0x58]
    // 0x6cd414: StoreField: r0->field_7 = r1
    //     0x6cd414: stur            w1, [x0, #7]
    // 0x6cd418: ldur            x1, [fp, #-0x50]
    // 0x6cd41c: StoreField: r0->field_b = r1
    //     0x6cd41c: stur            w1, [x0, #0xb]
    // 0x6cd420: ldur            x1, [fp, #-0x48]
    // 0x6cd424: StoreField: r0->field_f = r1
    //     0x6cd424: stur            w1, [x0, #0xf]
    // 0x6cd428: ldur            x1, [fp, #-0x30]
    // 0x6cd42c: StoreField: r0->field_1b = r1
    //     0x6cd42c: stur            w1, [x0, #0x1b]
    // 0x6cd430: ldur            x1, [fp, #-0x28]
    // 0x6cd434: StoreField: r0->field_1f = r1
    //     0x6cd434: stur            w1, [x0, #0x1f]
    // 0x6cd438: r17 = -264
    //     0x6cd438: mov             x17, #-0x108
    // 0x6cd43c: ldr             x1, [fp, x17]
    // 0x6cd440: StoreField: r0->field_3b = r1
    //     0x6cd440: stur            w1, [x0, #0x3b]
    // 0x6cd444: ldur            x1, [fp, #-0x100]
    // 0x6cd448: StoreField: r0->field_3f = r1
    //     0x6cd448: stur            w1, [x0, #0x3f]
    // 0x6cd44c: ldur            x1, [fp, #-0xe8]
    // 0x6cd450: StoreField: r0->field_4b = r1
    //     0x6cd450: stur            w1, [x0, #0x4b]
    // 0x6cd454: ldur            x1, [fp, #-0xe0]
    // 0x6cd458: StoreField: r0->field_4f = r1
    //     0x6cd458: stur            w1, [x0, #0x4f]
    // 0x6cd45c: ldur            x1, [fp, #-0xd8]
    // 0x6cd460: StoreField: r0->field_53 = r1
    //     0x6cd460: stur            w1, [x0, #0x53]
    // 0x6cd464: ldur            x1, [fp, #-0xd0]
    // 0x6cd468: StoreField: r0->field_57 = r1
    //     0x6cd468: stur            w1, [x0, #0x57]
    // 0x6cd46c: ldur            x1, [fp, #-0x40]
    // 0x6cd470: StoreField: r0->field_13 = r1
    //     0x6cd470: stur            w1, [x0, #0x13]
    // 0x6cd474: ldur            x1, [fp, #-0x38]
    // 0x6cd478: StoreField: r0->field_17 = r1
    //     0x6cd478: stur            w1, [x0, #0x17]
    // 0x6cd47c: ldur            x1, [fp, #-0x20]
    // 0x6cd480: StoreField: r0->field_23 = r1
    //     0x6cd480: stur            w1, [x0, #0x23]
    // 0x6cd484: ldur            x1, [fp, #-0x18]
    // 0x6cd488: StoreField: r0->field_27 = r1
    //     0x6cd488: stur            w1, [x0, #0x27]
    // 0x6cd48c: ldur            x1, [fp, #-0x10]
    // 0x6cd490: StoreField: r0->field_2b = r1
    //     0x6cd490: stur            w1, [x0, #0x2b]
    // 0x6cd494: ldur            x1, [fp, #-8]
    // 0x6cd498: StoreField: r0->field_2f = r1
    //     0x6cd498: stur            w1, [x0, #0x2f]
    // 0x6cd49c: ldur            x1, [fp, #-0x60]
    // 0x6cd4a0: StoreField: r0->field_33 = r1
    //     0x6cd4a0: stur            w1, [x0, #0x33]
    // 0x6cd4a4: ldur            x1, [fp, #-0x68]
    // 0x6cd4a8: StoreField: r0->field_37 = r1
    //     0x6cd4a8: stur            w1, [x0, #0x37]
    // 0x6cd4ac: ldur            x1, [fp, #-0xf8]
    // 0x6cd4b0: StoreField: r0->field_43 = r1
    //     0x6cd4b0: stur            w1, [x0, #0x43]
    // 0x6cd4b4: ldur            x1, [fp, #-0xf0]
    // 0x6cd4b8: StoreField: r0->field_47 = r1
    //     0x6cd4b8: stur            w1, [x0, #0x47]
    // 0x6cd4bc: ldur            x1, [fp, #-0xc8]
    // 0x6cd4c0: StoreField: r0->field_5b = r1
    //     0x6cd4c0: stur            w1, [x0, #0x5b]
    // 0x6cd4c4: ldur            x1, [fp, #-0xc0]
    // 0x6cd4c8: StoreField: r0->field_5f = r1
    //     0x6cd4c8: stur            w1, [x0, #0x5f]
    // 0x6cd4cc: ldur            x1, [fp, #-0xb8]
    // 0x6cd4d0: StoreField: r0->field_63 = r1
    //     0x6cd4d0: stur            w1, [x0, #0x63]
    // 0x6cd4d4: ldur            x1, [fp, #-0xb0]
    // 0x6cd4d8: StoreField: r0->field_67 = r1
    //     0x6cd4d8: stur            w1, [x0, #0x67]
    // 0x6cd4dc: ldur            x1, [fp, #-0xa8]
    // 0x6cd4e0: StoreField: r0->field_6b = r1
    //     0x6cd4e0: stur            w1, [x0, #0x6b]
    // 0x6cd4e4: ldur            x1, [fp, #-0xa0]
    // 0x6cd4e8: StoreField: r0->field_6f = r1
    //     0x6cd4e8: stur            w1, [x0, #0x6f]
    // 0x6cd4ec: ldur            x1, [fp, #-0x98]
    // 0x6cd4f0: StoreField: r0->field_73 = r1
    //     0x6cd4f0: stur            w1, [x0, #0x73]
    // 0x6cd4f4: ldur            x1, [fp, #-0x90]
    // 0x6cd4f8: StoreField: r0->field_77 = r1
    //     0x6cd4f8: stur            w1, [x0, #0x77]
    // 0x6cd4fc: ldur            x1, [fp, #-0x88]
    // 0x6cd500: StoreField: r0->field_7b = r1
    //     0x6cd500: stur            w1, [x0, #0x7b]
    // 0x6cd504: ldur            x1, [fp, #-0x80]
    // 0x6cd508: StoreField: r0->field_83 = r1
    //     0x6cd508: stur            w1, [x0, #0x83]
    // 0x6cd50c: ldur            x1, [fp, #-0x70]
    // 0x6cd510: StoreField: r0->field_87 = r1
    //     0x6cd510: stur            w1, [x0, #0x87]
    // 0x6cd514: ldur            x1, [fp, #-0x78]
    // 0x6cd518: StoreField: r0->field_7f = r1
    //     0x6cd518: stur            w1, [x0, #0x7f]
    // 0x6cd51c: LeaveFrame
    //     0x6cd51c: mov             SP, fp
    //     0x6cd520: ldp             fp, lr, [SP], #0x10
    // 0x6cd524: ret
    //     0x6cd524: ret             
    // 0x6cd528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cd528: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cd52c: b               #0x6cd154
  }
  get _ onTertiaryContainer(/* No info */) {
    // ** addr: 0x6cd53c, size: 0x48
    // 0x6cd53c: ldr             x1, [SP]
    // 0x6cd540: LoadField: r2 = r1->field_37
    //     0x6cd540: ldur            w2, [x1, #0x37]
    // 0x6cd544: DecompressPointer r2
    //     0x6cd544: add             x2, x2, HEAP, lsl #32
    // 0x6cd548: cmp             w2, NULL
    // 0x6cd54c: b.ne            #0x6cd57c
    // 0x6cd550: LoadField: r3 = r1->field_2f
    //     0x6cd550: ldur            w3, [x1, #0x2f]
    // 0x6cd554: DecompressPointer r3
    //     0x6cd554: add             x3, x3, HEAP, lsl #32
    // 0x6cd558: cmp             w3, NULL
    // 0x6cd55c: b.ne            #0x6cd570
    // 0x6cd560: LoadField: r4 = r1->field_1f
    //     0x6cd560: ldur            w4, [x1, #0x1f]
    // 0x6cd564: DecompressPointer r4
    //     0x6cd564: add             x4, x4, HEAP, lsl #32
    // 0x6cd568: mov             x1, x4
    // 0x6cd56c: b               #0x6cd574
    // 0x6cd570: mov             x1, x3
    // 0x6cd574: mov             x0, x1
    // 0x6cd578: b               #0x6cd580
    // 0x6cd57c: mov             x0, x2
    // 0x6cd580: ret
    //     0x6cd580: ret             
  }
  get _ tertiaryContainer(/* No info */) {
    // ** addr: 0x6cd584, size: 0x48
    // 0x6cd584: ldr             x1, [SP]
    // 0x6cd588: LoadField: r2 = r1->field_33
    //     0x6cd588: ldur            w2, [x1, #0x33]
    // 0x6cd58c: DecompressPointer r2
    //     0x6cd58c: add             x2, x2, HEAP, lsl #32
    // 0x6cd590: cmp             w2, NULL
    // 0x6cd594: b.ne            #0x6cd5c4
    // 0x6cd598: LoadField: r3 = r1->field_2b
    //     0x6cd598: ldur            w3, [x1, #0x2b]
    // 0x6cd59c: DecompressPointer r3
    //     0x6cd59c: add             x3, x3, HEAP, lsl #32
    // 0x6cd5a0: cmp             w3, NULL
    // 0x6cd5a4: b.ne            #0x6cd5b8
    // 0x6cd5a8: LoadField: r4 = r1->field_1b
    //     0x6cd5a8: ldur            w4, [x1, #0x1b]
    // 0x6cd5ac: DecompressPointer r4
    //     0x6cd5ac: add             x4, x4, HEAP, lsl #32
    // 0x6cd5b0: mov             x1, x4
    // 0x6cd5b4: b               #0x6cd5bc
    // 0x6cd5b8: mov             x1, x3
    // 0x6cd5bc: mov             x0, x1
    // 0x6cd5c0: b               #0x6cd5c8
    // 0x6cd5c4: mov             x0, x2
    // 0x6cd5c8: ret
    //     0x6cd5c8: ret             
  }
  factory _ ColorScheme.fromSwatch(/* No info */) {
    // ** addr: 0x6d2538, size: 0x424
    // 0x6d2538: EnterFrame
    //     0x6d2538: stp             fp, lr, [SP, #-0x10]!
    //     0x6d253c: mov             fp, SP
    // 0x6d2540: AllocStack(0x68)
    //     0x6d2540: sub             SP, SP, #0x68
    // 0x6d2544: SetupParameters(dynamic _ /* r3, fp-0x38 */, dynamic _ /* r4, fp-0x30 */, dynamic _ /* r5, fp-0x28 */, {dynamic cardColor = Null /* r6, fp-0x20 */, dynamic errorColor = Null /* r7, fp-0x18 */, dynamic primaryColorDark = Null /* r0, fp-0x10 */})
    //     0x6d2544: mov             x0, x4
    //     0x6d2548: ldur            w1, [x0, #0x13]
    //     0x6d254c: add             x1, x1, HEAP, lsl #32
    //     0x6d2550: sub             x2, x1, #8
    //     0x6d2554: add             x3, fp, w2, sxtw #2
    //     0x6d2558: ldr             x3, [x3, #0x20]
    //     0x6d255c: stur            x3, [fp, #-0x38]
    //     0x6d2560: add             x4, fp, w2, sxtw #2
    //     0x6d2564: ldr             x4, [x4, #0x18]
    //     0x6d2568: stur            x4, [fp, #-0x30]
    //     0x6d256c: add             x5, fp, w2, sxtw #2
    //     0x6d2570: ldr             x5, [x5, #0x10]
    //     0x6d2574: stur            x5, [fp, #-0x28]
    //     0x6d2578: ldur            w2, [x0, #0x1f]
    //     0x6d257c: add             x2, x2, HEAP, lsl #32
    //     0x6d2580: add             x16, PP, #0xc, lsl #12  ; [pp+0xcca8] "cardColor"
    //     0x6d2584: ldr             x16, [x16, #0xca8]
    //     0x6d2588: cmp             w2, w16
    //     0x6d258c: b.ne            #0x6d25b0
    //     0x6d2590: ldur            w2, [x0, #0x23]
    //     0x6d2594: add             x2, x2, HEAP, lsl #32
    //     0x6d2598: sub             w6, w1, w2
    //     0x6d259c: add             x2, fp, w6, sxtw #2
    //     0x6d25a0: ldr             x2, [x2, #8]
    //     0x6d25a4: mov             x6, x2
    //     0x6d25a8: mov             x2, #1
    //     0x6d25ac: b               #0x6d25b8
    //     0x6d25b0: mov             x6, NULL
    //     0x6d25b4: mov             x2, #0
    //     0x6d25b8: stur            x6, [fp, #-0x20]
    //     0x6d25bc: lsl             x7, x2, #1
    //     0x6d25c0: lsl             w8, w7, #1
    //     0x6d25c4: add             w9, w8, #8
    //     0x6d25c8: add             x16, x0, w9, sxtw #1
    //     0x6d25cc: ldur            w10, [x16, #0xf]
    //     0x6d25d0: add             x10, x10, HEAP, lsl #32
    //     0x6d25d4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcd20] "errorColor"
    //     0x6d25d8: ldr             x16, [x16, #0xd20]
    //     0x6d25dc: cmp             w10, w16
    //     0x6d25e0: b.ne            #0x6d2614
    //     0x6d25e4: add             w2, w8, #0xa
    //     0x6d25e8: add             x16, x0, w2, sxtw #1
    //     0x6d25ec: ldur            w8, [x16, #0xf]
    //     0x6d25f0: add             x8, x8, HEAP, lsl #32
    //     0x6d25f4: sub             w2, w1, w8
    //     0x6d25f8: add             x8, fp, w2, sxtw #2
    //     0x6d25fc: ldr             x8, [x8, #8]
    //     0x6d2600: add             w2, w7, #2
    //     0x6d2604: sbfx            x7, x2, #1, #0x1f
    //     0x6d2608: mov             x2, x7
    //     0x6d260c: mov             x7, x8
    //     0x6d2610: b               #0x6d2618
    //     0x6d2614: mov             x7, NULL
    //     0x6d2618: stur            x7, [fp, #-0x18]
    //     0x6d261c: lsl             x8, x2, #1
    //     0x6d2620: lsl             w2, w8, #1
    //     0x6d2624: add             w8, w2, #8
    //     0x6d2628: add             x16, x0, w8, sxtw #1
    //     0x6d262c: ldur            w9, [x16, #0xf]
    //     0x6d2630: add             x9, x9, HEAP, lsl #32
    //     0x6d2634: add             x16, PP, #0xc, lsl #12  ; [pp+0xce00] "primaryColorDark"
    //     0x6d2638: ldr             x16, [x16, #0xe00]
    //     0x6d263c: cmp             w9, w16
    //     0x6d2640: b.ne            #0x6d2668
    //     0x6d2644: add             w8, w2, #0xa
    //     0x6d2648: add             x16, x0, w8, sxtw #1
    //     0x6d264c: ldur            w2, [x16, #0xf]
    //     0x6d2650: add             x2, x2, HEAP, lsl #32
    //     0x6d2654: sub             w0, w1, w2
    //     0x6d2658: add             x1, fp, w0, sxtw #2
    //     0x6d265c: ldr             x1, [x1, #8]
    //     0x6d2660: mov             x0, x1
    //     0x6d2664: b               #0x6d266c
    //     0x6d2668: mov             x0, NULL
    //     0x6d266c: stur            x0, [fp, #-0x10]
    // 0x6d2670: CheckStackOverflow
    //     0x6d2670: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d2674: cmp             SP, x16
    //     0x6d2678: b.ls            #0x6d2940
    // 0x6d267c: r16 = Instance_Brightness
    //     0x6d267c: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d2680: cmp             w5, w16
    // 0x6d2684: r16 = true
    //     0x6d2684: add             x16, NULL, #0x20  ; true
    // 0x6d2688: r17 = false
    //     0x6d2688: add             x17, NULL, #0x30  ; false
    // 0x6d268c: csel            x1, x16, x17, eq
    // 0x6d2690: stur            x1, [fp, #-8]
    // 0x6d2694: r16 = Instance_MaterialColor
    //     0x6d2694: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x6d2698: ldr             x16, [x16, #0xf28]
    // 0x6d269c: SaveReg r16
    //     0x6d269c: str             x16, [SP, #-8]!
    // 0x6d26a0: r0 = estimateBrightnessForColor()
    //     0x6d26a0: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x6d26a4: add             SP, SP, #8
    // 0x6d26a8: r16 = Instance_Brightness
    //     0x6d26a8: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d26ac: cmp             w0, w16
    // 0x6d26b0: r16 = true
    //     0x6d26b0: add             x16, NULL, #0x20  ; true
    // 0x6d26b4: r17 = false
    //     0x6d26b4: add             x17, NULL, #0x30  ; false
    // 0x6d26b8: csel            x1, x16, x17, eq
    // 0x6d26bc: stur            x1, [fp, #-0x40]
    // 0x6d26c0: ldur            x16, [fp, #-0x38]
    // 0x6d26c4: SaveReg r16
    //     0x6d26c4: str             x16, [SP, #-8]!
    // 0x6d26c8: r0 = estimateBrightnessForColor()
    //     0x6d26c8: bl              #0x6d295c  ; [package:flutter/src/material/theme_data.dart] ThemeData::estimateBrightnessForColor
    // 0x6d26cc: add             SP, SP, #8
    // 0x6d26d0: mov             x1, x0
    // 0x6d26d4: ldur            x0, [fp, #-0x10]
    // 0x6d26d8: stur            x1, [fp, #-0x48]
    // 0x6d26dc: cmp             w0, NULL
    // 0x6d26e0: b.ne            #0x6d2720
    // 0x6d26e4: ldur            x0, [fp, #-8]
    // 0x6d26e8: tbnz            w0, #4, #0x6d26f8
    // 0x6d26ec: r0 = Instance_Color
    //     0x6d26ec: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d26f0: ldr             x0, [x0, #0xf38]
    // 0x6d26f4: b               #0x6d2718
    // 0x6d26f8: r16 = Instance_MaterialColor
    //     0x6d26f8: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x6d26fc: ldr             x16, [x16, #0xf28]
    // 0x6d2700: r30 = 1400
    //     0x6d2700: mov             lr, #0x578
    // 0x6d2704: stp             lr, x16, [SP, #-0x10]!
    // 0x6d2708: r0 = []()
    //     0x6d2708: bl              #0x673b3c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::[]
    // 0x6d270c: add             SP, SP, #0x10
    // 0x6d2710: cmp             w0, NULL
    // 0x6d2714: b.eq            #0x6d2948
    // 0x6d2718: mov             x1, x0
    // 0x6d271c: b               #0x6d2724
    // 0x6d2720: mov             x1, x0
    // 0x6d2724: ldur            x0, [fp, #-8]
    // 0x6d2728: stur            x1, [fp, #-0x10]
    // 0x6d272c: tbnz            w0, #4, #0x6d2758
    // 0x6d2730: r16 = _ConstMap len:4
    //     0x6d2730: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf40] Map<int, Color>(4)
    //     0x6d2734: ldr             x16, [x16, #0xf40]
    // 0x6d2738: r30 = 1400
    //     0x6d2738: mov             lr, #0x578
    // 0x6d273c: stp             lr, x16, [SP, #-0x10]!
    // 0x6d2740: r0 = []()
    //     0x6d2740: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d2744: add             SP, SP, #0x10
    // 0x6d2748: cmp             w0, NULL
    // 0x6d274c: b.eq            #0x6d294c
    // 0x6d2750: mov             x1, x0
    // 0x6d2754: b               #0x6d277c
    // 0x6d2758: r16 = Instance_MaterialColor
    //     0x6d2758: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x6d275c: ldr             x16, [x16, #0xf28]
    // 0x6d2760: r30 = 1400
    //     0x6d2760: mov             lr, #0x578
    // 0x6d2764: stp             lr, x16, [SP, #-0x10]!
    // 0x6d2768: r0 = []()
    //     0x6d2768: bl              #0x673b3c  ; [package:flutter/src/painting/colors.dart] ColorSwatch::[]
    // 0x6d276c: add             SP, SP, #0x10
    // 0x6d2770: cmp             w0, NULL
    // 0x6d2774: b.eq            #0x6d2950
    // 0x6d2778: mov             x1, x0
    // 0x6d277c: ldur            x0, [fp, #-0x20]
    // 0x6d2780: stur            x1, [fp, #-0x50]
    // 0x6d2784: cmp             w0, NULL
    // 0x6d2788: b.ne            #0x6d27c8
    // 0x6d278c: ldur            x0, [fp, #-8]
    // 0x6d2790: tbnz            w0, #4, #0x6d27b8
    // 0x6d2794: r16 = _ConstMap len:12
    //     0x6d2794: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x6d2798: ldr             x16, [x16, #0xf20]
    // 0x6d279c: r30 = 1600
    //     0x6d279c: mov             lr, #0x640
    // 0x6d27a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6d27a4: r0 = []()
    //     0x6d27a4: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d27a8: add             SP, SP, #0x10
    // 0x6d27ac: cmp             w0, NULL
    // 0x6d27b0: b.eq            #0x6d2954
    // 0x6d27b4: b               #0x6d27c0
    // 0x6d27b8: r0 = Instance_Color
    //     0x6d27b8: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d27bc: ldr             x0, [x0, #0xbe8]
    // 0x6d27c0: mov             x1, x0
    // 0x6d27c4: b               #0x6d27cc
    // 0x6d27c8: mov             x1, x0
    // 0x6d27cc: ldur            x0, [fp, #-0x18]
    // 0x6d27d0: stur            x1, [fp, #-0x20]
    // 0x6d27d4: cmp             w0, NULL
    // 0x6d27d8: b.ne            #0x6d2804
    // 0x6d27dc: r16 = _ConstMap len:10
    //     0x6d27dc: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf68] Map<int, Color>(10)
    //     0x6d27e0: ldr             x16, [x16, #0xf68]
    // 0x6d27e4: r30 = 1400
    //     0x6d27e4: mov             lr, #0x578
    // 0x6d27e8: stp             lr, x16, [SP, #-0x10]!
    // 0x6d27ec: r0 = []()
    //     0x6d27ec: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x6d27f0: add             SP, SP, #0x10
    // 0x6d27f4: cmp             w0, NULL
    // 0x6d27f8: b.eq            #0x6d2958
    // 0x6d27fc: mov             x1, x0
    // 0x6d2800: b               #0x6d2808
    // 0x6d2804: mov             x1, x0
    // 0x6d2808: ldur            x0, [fp, #-0x40]
    // 0x6d280c: stur            x1, [fp, #-0x68]
    // 0x6d2810: tbnz            w0, #4, #0x6d2820
    // 0x6d2814: r3 = Instance_Color
    //     0x6d2814: add             x3, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d2818: ldr             x3, [x3, #0xbe8]
    // 0x6d281c: b               #0x6d2828
    // 0x6d2820: r3 = Instance_Color
    //     0x6d2820: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d2824: ldr             x3, [x3, #0xf38]
    // 0x6d2828: ldur            x2, [fp, #-0x48]
    // 0x6d282c: stur            x3, [fp, #-0x60]
    // 0x6d2830: r16 = Instance_Brightness
    //     0x6d2830: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x6d2834: cmp             w2, w16
    // 0x6d2838: b.ne            #0x6d2848
    // 0x6d283c: r4 = Instance_Color
    //     0x6d283c: add             x4, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d2840: ldr             x4, [x4, #0xbe8]
    // 0x6d2844: b               #0x6d2850
    // 0x6d2848: r4 = Instance_Color
    //     0x6d2848: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d284c: ldr             x4, [x4, #0xf38]
    // 0x6d2850: ldur            x2, [fp, #-8]
    // 0x6d2854: stur            x4, [fp, #-0x58]
    // 0x6d2858: tbnz            w2, #4, #0x6d2868
    // 0x6d285c: r5 = Instance_Color
    //     0x6d285c: add             x5, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d2860: ldr             x5, [x5, #0xbe8]
    // 0x6d2864: b               #0x6d2870
    // 0x6d2868: r5 = Instance_Color
    //     0x6d2868: add             x5, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d286c: ldr             x5, [x5, #0xf38]
    // 0x6d2870: stur            x5, [fp, #-0x48]
    // 0x6d2874: tbnz            w0, #4, #0x6d2884
    // 0x6d2878: r0 = Instance_Color
    //     0x6d2878: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d287c: ldr             x0, [x0, #0xbe8]
    // 0x6d2880: b               #0x6d288c
    // 0x6d2884: r0 = Instance_Color
    //     0x6d2884: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d2888: ldr             x0, [x0, #0xf38]
    // 0x6d288c: stur            x0, [fp, #-0x18]
    // 0x6d2890: tbnz            w2, #4, #0x6d28a0
    // 0x6d2894: r11 = Instance_Color
    //     0x6d2894: add             x11, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x6d2898: ldr             x11, [x11, #0xf38]
    // 0x6d289c: b               #0x6d28a8
    // 0x6d28a0: r11 = Instance_Color
    //     0x6d28a0: add             x11, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6d28a4: ldr             x11, [x11, #0xbe8]
    // 0x6d28a8: ldur            x8, [fp, #-0x38]
    // 0x6d28ac: ldur            x9, [fp, #-0x30]
    // 0x6d28b0: ldur            x10, [fp, #-0x28]
    // 0x6d28b4: ldur            x7, [fp, #-0x10]
    // 0x6d28b8: ldur            x6, [fp, #-0x50]
    // 0x6d28bc: ldur            x2, [fp, #-0x20]
    // 0x6d28c0: stur            x11, [fp, #-8]
    // 0x6d28c4: r0 = ColorScheme()
    //     0x6d28c4: bl              #0x6cd530  ; AllocateColorSchemeStub -> ColorScheme (size=0x8c)
    // 0x6d28c8: ldur            x1, [fp, #-0x28]
    // 0x6d28cc: StoreField: r0->field_7 = r1
    //     0x6d28cc: stur            w1, [x0, #7]
    // 0x6d28d0: r1 = Instance_MaterialColor
    //     0x6d28d0: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf28] Obj!MaterialColor<int>@b5e3d1
    //     0x6d28d4: ldr             x1, [x1, #0xf28]
    // 0x6d28d8: StoreField: r0->field_b = r1
    //     0x6d28d8: stur            w1, [x0, #0xb]
    // 0x6d28dc: ldur            x1, [fp, #-0x60]
    // 0x6d28e0: StoreField: r0->field_f = r1
    //     0x6d28e0: stur            w1, [x0, #0xf]
    // 0x6d28e4: ldur            x1, [fp, #-0x38]
    // 0x6d28e8: StoreField: r0->field_1b = r1
    //     0x6d28e8: stur            w1, [x0, #0x1b]
    // 0x6d28ec: ldur            x1, [fp, #-0x58]
    // 0x6d28f0: StoreField: r0->field_1f = r1
    //     0x6d28f0: stur            w1, [x0, #0x1f]
    // 0x6d28f4: ldur            x1, [fp, #-0x68]
    // 0x6d28f8: StoreField: r0->field_3b = r1
    //     0x6d28f8: stur            w1, [x0, #0x3b]
    // 0x6d28fc: ldur            x1, [fp, #-8]
    // 0x6d2900: StoreField: r0->field_3f = r1
    //     0x6d2900: stur            w1, [x0, #0x3f]
    // 0x6d2904: ldur            x1, [fp, #-0x30]
    // 0x6d2908: StoreField: r0->field_4b = r1
    //     0x6d2908: stur            w1, [x0, #0x4b]
    // 0x6d290c: ldur            x1, [fp, #-0x18]
    // 0x6d2910: StoreField: r0->field_4f = r1
    //     0x6d2910: stur            w1, [x0, #0x4f]
    // 0x6d2914: ldur            x1, [fp, #-0x20]
    // 0x6d2918: StoreField: r0->field_53 = r1
    //     0x6d2918: stur            w1, [x0, #0x53]
    // 0x6d291c: ldur            x1, [fp, #-0x48]
    // 0x6d2920: StoreField: r0->field_57 = r1
    //     0x6d2920: stur            w1, [x0, #0x57]
    // 0x6d2924: ldur            x1, [fp, #-0x10]
    // 0x6d2928: StoreField: r0->field_83 = r1
    //     0x6d2928: stur            w1, [x0, #0x83]
    // 0x6d292c: ldur            x1, [fp, #-0x50]
    // 0x6d2930: StoreField: r0->field_87 = r1
    //     0x6d2930: stur            w1, [x0, #0x87]
    // 0x6d2934: LeaveFrame
    //     0x6d2934: mov             SP, fp
    //     0x6d2938: ldp             fp, lr, [SP], #0x10
    // 0x6d293c: ret
    //     0x6d293c: ret             
    // 0x6d2940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d2940: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d2944: b               #0x6d267c
    // 0x6d2948: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d2948: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d294c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d294c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d2950: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d2950: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d2954: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d2954: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6d2958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6d2958: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafed4c, size: 0x374
    // 0xafed4c: EnterFrame
    //     0xafed4c: stp             fp, lr, [SP, #-0x10]!
    //     0xafed50: mov             fp, SP
    // 0xafed54: AllocStack(0x98)
    //     0xafed54: sub             SP, SP, #0x98
    // 0xafed58: CheckStackOverflow
    //     0xafed58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafed5c: cmp             SP, x16
    //     0xafed60: b.ls            #0xaff0b8
    // 0xafed64: ldr             x0, [fp, #0x10]
    // 0xafed68: LoadField: r1 = r0->field_7
    //     0xafed68: ldur            w1, [x0, #7]
    // 0xafed6c: DecompressPointer r1
    //     0xafed6c: add             x1, x1, HEAP, lsl #32
    // 0xafed70: stur            x1, [fp, #-0x58]
    // 0xafed74: LoadField: r2 = r0->field_b
    //     0xafed74: ldur            w2, [x0, #0xb]
    // 0xafed78: DecompressPointer r2
    //     0xafed78: add             x2, x2, HEAP, lsl #32
    // 0xafed7c: stur            x2, [fp, #-0x50]
    // 0xafed80: LoadField: r3 = r0->field_f
    //     0xafed80: ldur            w3, [x0, #0xf]
    // 0xafed84: DecompressPointer r3
    //     0xafed84: add             x3, x3, HEAP, lsl #32
    // 0xafed88: stur            x3, [fp, #-0x48]
    // 0xafed8c: LoadField: r4 = r0->field_13
    //     0xafed8c: ldur            w4, [x0, #0x13]
    // 0xafed90: DecompressPointer r4
    //     0xafed90: add             x4, x4, HEAP, lsl #32
    // 0xafed94: cmp             w4, NULL
    // 0xafed98: b.ne            #0xafeda0
    // 0xafed9c: mov             x4, x2
    // 0xafeda0: stur            x4, [fp, #-0x40]
    // 0xafeda4: LoadField: r5 = r0->field_17
    //     0xafeda4: ldur            w5, [x0, #0x17]
    // 0xafeda8: DecompressPointer r5
    //     0xafeda8: add             x5, x5, HEAP, lsl #32
    // 0xafedac: cmp             w5, NULL
    // 0xafedb0: b.ne            #0xafedb8
    // 0xafedb4: mov             x5, x3
    // 0xafedb8: stur            x5, [fp, #-0x38]
    // 0xafedbc: LoadField: r6 = r0->field_1b
    //     0xafedbc: ldur            w6, [x0, #0x1b]
    // 0xafedc0: DecompressPointer r6
    //     0xafedc0: add             x6, x6, HEAP, lsl #32
    // 0xafedc4: stur            x6, [fp, #-0x30]
    // 0xafedc8: LoadField: r7 = r0->field_1f
    //     0xafedc8: ldur            w7, [x0, #0x1f]
    // 0xafedcc: DecompressPointer r7
    //     0xafedcc: add             x7, x7, HEAP, lsl #32
    // 0xafedd0: stur            x7, [fp, #-0x28]
    // 0xafedd4: LoadField: r8 = r0->field_23
    //     0xafedd4: ldur            w8, [x0, #0x23]
    // 0xafedd8: DecompressPointer r8
    //     0xafedd8: add             x8, x8, HEAP, lsl #32
    // 0xafeddc: cmp             w8, NULL
    // 0xafede0: b.ne            #0xafede8
    // 0xafede4: mov             x8, x6
    // 0xafede8: stur            x8, [fp, #-0x20]
    // 0xafedec: LoadField: r9 = r0->field_27
    //     0xafedec: ldur            w9, [x0, #0x27]
    // 0xafedf0: DecompressPointer r9
    //     0xafedf0: add             x9, x9, HEAP, lsl #32
    // 0xafedf4: cmp             w9, NULL
    // 0xafedf8: b.ne            #0xafee00
    // 0xafedfc: mov             x9, x7
    // 0xafee00: stur            x9, [fp, #-0x18]
    // 0xafee04: LoadField: r10 = r0->field_2b
    //     0xafee04: ldur            w10, [x0, #0x2b]
    // 0xafee08: DecompressPointer r10
    //     0xafee08: add             x10, x10, HEAP, lsl #32
    // 0xafee0c: cmp             w10, NULL
    // 0xafee10: b.ne            #0xafee18
    // 0xafee14: mov             x10, x6
    // 0xafee18: stur            x10, [fp, #-0x10]
    // 0xafee1c: LoadField: r11 = r0->field_2f
    //     0xafee1c: ldur            w11, [x0, #0x2f]
    // 0xafee20: DecompressPointer r11
    //     0xafee20: add             x11, x11, HEAP, lsl #32
    // 0xafee24: cmp             w11, NULL
    // 0xafee28: b.ne            #0xafee30
    // 0xafee2c: mov             x11, x7
    // 0xafee30: stur            x11, [fp, #-8]
    // 0xafee34: SaveReg r0
    //     0xafee34: str             x0, [SP, #-8]!
    // 0xafee38: r0 = tertiaryContainer()
    //     0xafee38: bl              #0x6cd584  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0xafee3c: add             SP, SP, #8
    // 0xafee40: stur            x0, [fp, #-0x60]
    // 0xafee44: ldr             x16, [fp, #0x10]
    // 0xafee48: SaveReg r16
    //     0xafee48: str             x16, [SP, #-8]!
    // 0xafee4c: r0 = onTertiaryContainer()
    //     0xafee4c: bl              #0x6cd53c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0xafee50: add             SP, SP, #8
    // 0xafee54: mov             x1, x0
    // 0xafee58: ldr             x0, [fp, #0x10]
    // 0xafee5c: stur            x1, [fp, #-0x68]
    // 0xafee60: LoadField: r2 = r0->field_3b
    //     0xafee60: ldur            w2, [x0, #0x3b]
    // 0xafee64: DecompressPointer r2
    //     0xafee64: add             x2, x2, HEAP, lsl #32
    // 0xafee68: stur            x2, [fp, #-0x70]
    // 0xafee6c: LoadField: r3 = r0->field_3f
    //     0xafee6c: ldur            w3, [x0, #0x3f]
    // 0xafee70: DecompressPointer r3
    //     0xafee70: add             x3, x3, HEAP, lsl #32
    // 0xafee74: stur            x3, [fp, #-0x98]
    // 0xafee78: LoadField: r4 = r0->field_43
    //     0xafee78: ldur            w4, [x0, #0x43]
    // 0xafee7c: DecompressPointer r4
    //     0xafee7c: add             x4, x4, HEAP, lsl #32
    // 0xafee80: cmp             w4, NULL
    // 0xafee84: b.ne            #0xafee8c
    // 0xafee88: mov             x4, x2
    // 0xafee8c: stur            x4, [fp, #-0x90]
    // 0xafee90: LoadField: r5 = r0->field_47
    //     0xafee90: ldur            w5, [x0, #0x47]
    // 0xafee94: DecompressPointer r5
    //     0xafee94: add             x5, x5, HEAP, lsl #32
    // 0xafee98: cmp             w5, NULL
    // 0xafee9c: b.ne            #0xafeea4
    // 0xafeea0: mov             x5, x3
    // 0xafeea4: stur            x5, [fp, #-0x88]
    // 0xafeea8: LoadField: r6 = r0->field_4b
    //     0xafeea8: ldur            w6, [x0, #0x4b]
    // 0xafeeac: DecompressPointer r6
    //     0xafeeac: add             x6, x6, HEAP, lsl #32
    // 0xafeeb0: stur            x6, [fp, #-0x80]
    // 0xafeeb4: LoadField: r7 = r0->field_4f
    //     0xafeeb4: ldur            w7, [x0, #0x4f]
    // 0xafeeb8: DecompressPointer r7
    //     0xafeeb8: add             x7, x7, HEAP, lsl #32
    // 0xafeebc: stur            x7, [fp, #-0x78]
    // 0xafeec0: LoadField: r8 = r0->field_53
    //     0xafeec0: ldur            w8, [x0, #0x53]
    // 0xafeec4: DecompressPointer r8
    //     0xafeec4: add             x8, x8, HEAP, lsl #32
    // 0xafeec8: LoadField: r9 = r0->field_57
    //     0xafeec8: ldur            w9, [x0, #0x57]
    // 0xafeecc: DecompressPointer r9
    //     0xafeecc: add             x9, x9, HEAP, lsl #32
    // 0xafeed0: LoadField: r10 = r0->field_5b
    //     0xafeed0: ldur            w10, [x0, #0x5b]
    // 0xafeed4: DecompressPointer r10
    //     0xafeed4: add             x10, x10, HEAP, lsl #32
    // 0xafeed8: cmp             w10, NULL
    // 0xafeedc: b.ne            #0xafeee4
    // 0xafeee0: mov             x10, x8
    // 0xafeee4: LoadField: r11 = r0->field_5f
    //     0xafeee4: ldur            w11, [x0, #0x5f]
    // 0xafeee8: DecompressPointer r11
    //     0xafeee8: add             x11, x11, HEAP, lsl #32
    // 0xafeeec: cmp             w11, NULL
    // 0xafeef0: b.ne            #0xafeef8
    // 0xafeef4: mov             x11, x9
    // 0xafeef8: LoadField: r12 = r0->field_63
    //     0xafeef8: ldur            w12, [x0, #0x63]
    // 0xafeefc: DecompressPointer r12
    //     0xafeefc: add             x12, x12, HEAP, lsl #32
    // 0xafef00: cmp             w12, NULL
    // 0xafef04: b.ne            #0xafef0c
    // 0xafef08: mov             x12, x7
    // 0xafef0c: LoadField: r13 = r0->field_67
    //     0xafef0c: ldur            w13, [x0, #0x67]
    // 0xafef10: DecompressPointer r13
    //     0xafef10: add             x13, x13, HEAP, lsl #32
    // 0xafef14: cmp             w13, NULL
    // 0xafef18: b.ne            #0xafef20
    // 0xafef1c: mov             x13, x7
    // 0xafef20: LoadField: r14 = r0->field_6b
    //     0xafef20: ldur            w14, [x0, #0x6b]
    // 0xafef24: DecompressPointer r14
    //     0xafef24: add             x14, x14, HEAP, lsl #32
    // 0xafef28: cmp             w14, NULL
    // 0xafef2c: b.ne            #0xafef38
    // 0xafef30: r14 = Instance_Color
    //     0xafef30: add             x14, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xafef34: ldr             x14, [x14, #0xf38]
    // 0xafef38: LoadField: r19 = r0->field_6f
    //     0xafef38: ldur            w19, [x0, #0x6f]
    // 0xafef3c: DecompressPointer r19
    //     0xafef3c: add             x19, x19, HEAP, lsl #32
    // 0xafef40: cmp             w19, NULL
    // 0xafef44: b.ne            #0xafef50
    // 0xafef48: r19 = Instance_Color
    //     0xafef48: add             x19, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xafef4c: ldr             x19, [x19, #0xf38]
    // 0xafef50: LoadField: r20 = r0->field_73
    //     0xafef50: ldur            w20, [x0, #0x73]
    // 0xafef54: DecompressPointer r20
    //     0xafef54: add             x20, x20, HEAP, lsl #32
    // 0xafef58: cmp             w20, NULL
    // 0xafef5c: b.ne            #0xafef64
    // 0xafef60: mov             x20, x9
    // 0xafef64: LoadField: r23 = r0->field_77
    //     0xafef64: ldur            w23, [x0, #0x77]
    // 0xafef68: DecompressPointer r23
    //     0xafef68: add             x23, x23, HEAP, lsl #32
    // 0xafef6c: cmp             w23, NULL
    // 0xafef70: b.ne            #0xafef78
    // 0xafef74: mov             x23, x8
    // 0xafef78: LoadField: r24 = r0->field_7b
    //     0xafef78: ldur            w24, [x0, #0x7b]
    // 0xafef7c: DecompressPointer r24
    //     0xafef7c: add             x24, x24, HEAP, lsl #32
    // 0xafef80: cmp             w24, NULL
    // 0xafef84: b.ne            #0xafef8c
    // 0xafef88: ldur            x24, [fp, #-0x48]
    // 0xafef8c: LoadField: r25 = r0->field_83
    //     0xafef8c: ldur            w25, [x0, #0x83]
    // 0xafef90: DecompressPointer r25
    //     0xafef90: add             x25, x25, HEAP, lsl #32
    // 0xafef94: cmp             w25, NULL
    // 0xafef98: b.ne            #0xafefa0
    // 0xafef9c: ldur            x25, [fp, #-0x50]
    // 0xafefa0: LoadField: r1 = r0->field_87
    //     0xafefa0: ldur            w1, [x0, #0x87]
    // 0xafefa4: DecompressPointer r1
    //     0xafefa4: add             x1, x1, HEAP, lsl #32
    // 0xafefa8: cmp             w1, NULL
    // 0xafefac: b.ne            #0xafefb4
    // 0xafefb0: ldur            x1, [fp, #-0x30]
    // 0xafefb4: LoadField: r2 = r0->field_7f
    //     0xafefb4: ldur            w2, [x0, #0x7f]
    // 0xafefb8: DecompressPointer r2
    //     0xafefb8: add             x2, x2, HEAP, lsl #32
    // 0xafefbc: cmp             w2, NULL
    // 0xafefc0: b.ne            #0xafefcc
    // 0xafefc4: ldur            x0, [fp, #-0x50]
    // 0xafefc8: b               #0xafefd0
    // 0xafefcc: mov             x0, x2
    // 0xafefd0: stp             x9, x8, [SP, #-0x10]!
    // 0xafefd4: stp             x11, x10, [SP, #-0x10]!
    // 0xafefd8: stp             x13, x12, [SP, #-0x10]!
    // 0xafefdc: stp             x19, x14, [SP, #-0x10]!
    // 0xafefe0: stp             x23, x20, [SP, #-0x10]!
    // 0xafefe4: stp             x25, x24, [SP, #-0x10]!
    // 0xafefe8: stp             x0, x1, [SP, #-0x10]!
    // 0xafefec: r4 = const [0, 0xe, 0xe, 0xe, null]
    //     0xafefec: add             x4, PP, #0xe, lsl #12  ; [pp+0xe3d8] List(5) [0, 0xe, 0xe, 0xe, Null]
    //     0xafeff0: ldr             x4, [x4, #0x3d8]
    // 0xafeff4: r0 = hash()
    //     0xafeff4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafeff8: add             SP, SP, #0x70
    // 0xafeffc: mov             x2, x0
    // 0xaff000: r0 = BoxInt64Instr(r2)
    //     0xaff000: sbfiz           x0, x2, #1, #0x1f
    //     0xaff004: cmp             x2, x0, asr #1
    //     0xaff008: b.eq            #0xaff014
    //     0xaff00c: bl              #0xd69bb8
    //     0xaff010: stur            x2, [x0, #7]
    // 0xaff014: ldur            x16, [fp, #-0x58]
    // 0xaff018: ldur            lr, [fp, #-0x50]
    // 0xaff01c: stp             lr, x16, [SP, #-0x10]!
    // 0xaff020: ldur            x16, [fp, #-0x48]
    // 0xaff024: ldur            lr, [fp, #-0x40]
    // 0xaff028: stp             lr, x16, [SP, #-0x10]!
    // 0xaff02c: ldur            x16, [fp, #-0x38]
    // 0xaff030: ldur            lr, [fp, #-0x30]
    // 0xaff034: stp             lr, x16, [SP, #-0x10]!
    // 0xaff038: ldur            x16, [fp, #-0x28]
    // 0xaff03c: ldur            lr, [fp, #-0x20]
    // 0xaff040: stp             lr, x16, [SP, #-0x10]!
    // 0xaff044: ldur            x16, [fp, #-0x18]
    // 0xaff048: ldur            lr, [fp, #-0x10]
    // 0xaff04c: stp             lr, x16, [SP, #-0x10]!
    // 0xaff050: ldur            x16, [fp, #-8]
    // 0xaff054: ldur            lr, [fp, #-0x60]
    // 0xaff058: stp             lr, x16, [SP, #-0x10]!
    // 0xaff05c: ldur            x16, [fp, #-0x68]
    // 0xaff060: ldur            lr, [fp, #-0x70]
    // 0xaff064: stp             lr, x16, [SP, #-0x10]!
    // 0xaff068: ldur            x16, [fp, #-0x98]
    // 0xaff06c: ldur            lr, [fp, #-0x90]
    // 0xaff070: stp             lr, x16, [SP, #-0x10]!
    // 0xaff074: ldur            x16, [fp, #-0x88]
    // 0xaff078: ldur            lr, [fp, #-0x80]
    // 0xaff07c: stp             lr, x16, [SP, #-0x10]!
    // 0xaff080: ldur            x16, [fp, #-0x78]
    // 0xaff084: stp             x0, x16, [SP, #-0x10]!
    // 0xaff088: r4 = const [0, 0x14, 0x14, 0x14, null]
    //     0xaff088: ldr             x4, [PP, #0x70d8]  ; [pp+0x70d8] List(5) [0, 0x14, 0x14, 0x14, Null]
    // 0xaff08c: r0 = hash()
    //     0xaff08c: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaff090: add             SP, SP, #0xa0
    // 0xaff094: mov             x2, x0
    // 0xaff098: r0 = BoxInt64Instr(r2)
    //     0xaff098: sbfiz           x0, x2, #1, #0x1f
    //     0xaff09c: cmp             x2, x0, asr #1
    //     0xaff0a0: b.eq            #0xaff0ac
    //     0xaff0a4: bl              #0xd69bb8
    //     0xaff0a8: stur            x2, [x0, #7]
    // 0xaff0ac: LeaveFrame
    //     0xaff0ac: mov             SP, fp
    //     0xaff0b0: ldp             fp, lr, [SP], #0x10
    // 0xaff0b4: ret
    //     0xaff0b4: ret             
    // 0xaff0b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff0b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff0bc: b               #0xafed64
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf761c, size: 0xc0c
    // 0xbf761c: EnterFrame
    //     0xbf761c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf7620: mov             fp, SP
    // 0xbf7624: AllocStack(0x130)
    //     0xbf7624: sub             SP, SP, #0x130
    // 0xbf7628: d0 = 0.500000
    //     0xbf7628: fmov            d0, #0.50000000
    // 0xbf762c: CheckStackOverflow
    //     0xbf762c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf7630: cmp             SP, x16
    //     0xbf7634: b.ls            #0xbf81cc
    // 0xbf7638: ldr             d1, [fp, #0x10]
    // 0xbf763c: fcmp            d1, d0
    // 0xbf7640: b.vs            #0xbf7660
    // 0xbf7644: b.ge            #0xbf7660
    // 0xbf7648: ldr             x0, [fp, #0x20]
    // 0xbf764c: LoadField: r1 = r0->field_7
    //     0xbf764c: ldur            w1, [x0, #7]
    // 0xbf7650: DecompressPointer r1
    //     0xbf7650: add             x1, x1, HEAP, lsl #32
    // 0xbf7654: mov             x2, x1
    // 0xbf7658: ldr             x1, [fp, #0x18]
    // 0xbf765c: b               #0xbf7670
    // 0xbf7660: ldr             x0, [fp, #0x20]
    // 0xbf7664: ldr             x1, [fp, #0x18]
    // 0xbf7668: LoadField: r2 = r1->field_7
    //     0xbf7668: ldur            w2, [x1, #7]
    // 0xbf766c: DecompressPointer r2
    //     0xbf766c: add             x2, x2, HEAP, lsl #32
    // 0xbf7670: stur            x2, [fp, #-0x20]
    // 0xbf7674: LoadField: r3 = r0->field_b
    //     0xbf7674: ldur            w3, [x0, #0xb]
    // 0xbf7678: DecompressPointer r3
    //     0xbf7678: add             x3, x3, HEAP, lsl #32
    // 0xbf767c: stur            x3, [fp, #-0x18]
    // 0xbf7680: LoadField: r4 = r1->field_b
    //     0xbf7680: ldur            w4, [x1, #0xb]
    // 0xbf7684: DecompressPointer r4
    //     0xbf7684: add             x4, x4, HEAP, lsl #32
    // 0xbf7688: stur            x4, [fp, #-0x10]
    // 0xbf768c: r5 = inline_Allocate_Double()
    //     0xbf768c: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf7690: add             x5, x5, #0x10
    //     0xbf7694: cmp             x6, x5
    //     0xbf7698: b.ls            #0xbf81d4
    //     0xbf769c: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf76a0: sub             x5, x5, #0xf
    //     0xbf76a4: mov             x6, #0xd108
    //     0xbf76a8: movk            x6, #3, lsl #16
    //     0xbf76ac: stur            x6, [x5, #-1]
    // 0xbf76b0: StoreField: r5->field_7 = d1
    //     0xbf76b0: stur            d1, [x5, #7]
    // 0xbf76b4: stur            x5, [fp, #-8]
    // 0xbf76b8: stp             x4, x3, [SP, #-0x10]!
    // 0xbf76bc: SaveReg r5
    //     0xbf76bc: str             x5, [SP, #-8]!
    // 0xbf76c0: r0 = lerp()
    //     0xbf76c0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf76c4: add             SP, SP, #0x18
    // 0xbf76c8: stur            x0, [fp, #-0x38]
    // 0xbf76cc: cmp             w0, NULL
    // 0xbf76d0: b.eq            #0xbf8200
    // 0xbf76d4: ldr             x1, [fp, #0x20]
    // 0xbf76d8: LoadField: r2 = r1->field_f
    //     0xbf76d8: ldur            w2, [x1, #0xf]
    // 0xbf76dc: DecompressPointer r2
    //     0xbf76dc: add             x2, x2, HEAP, lsl #32
    // 0xbf76e0: ldr             x3, [fp, #0x18]
    // 0xbf76e4: stur            x2, [fp, #-0x30]
    // 0xbf76e8: LoadField: r4 = r3->field_f
    //     0xbf76e8: ldur            w4, [x3, #0xf]
    // 0xbf76ec: DecompressPointer r4
    //     0xbf76ec: add             x4, x4, HEAP, lsl #32
    // 0xbf76f0: stur            x4, [fp, #-0x28]
    // 0xbf76f4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf76f8: ldur            x16, [fp, #-8]
    // 0xbf76fc: SaveReg r16
    //     0xbf76fc: str             x16, [SP, #-8]!
    // 0xbf7700: r0 = lerp()
    //     0xbf7700: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7704: add             SP, SP, #0x18
    // 0xbf7708: stur            x0, [fp, #-0x40]
    // 0xbf770c: cmp             w0, NULL
    // 0xbf7710: b.eq            #0xbf8204
    // 0xbf7714: ldr             x1, [fp, #0x20]
    // 0xbf7718: LoadField: r2 = r1->field_13
    //     0xbf7718: ldur            w2, [x1, #0x13]
    // 0xbf771c: DecompressPointer r2
    //     0xbf771c: add             x2, x2, HEAP, lsl #32
    // 0xbf7720: cmp             w2, NULL
    // 0xbf7724: b.ne            #0xbf7730
    // 0xbf7728: ldur            x3, [fp, #-0x18]
    // 0xbf772c: b               #0xbf7734
    // 0xbf7730: mov             x3, x2
    // 0xbf7734: ldr             x2, [fp, #0x18]
    // 0xbf7738: LoadField: r4 = r2->field_13
    //     0xbf7738: ldur            w4, [x2, #0x13]
    // 0xbf773c: DecompressPointer r4
    //     0xbf773c: add             x4, x4, HEAP, lsl #32
    // 0xbf7740: cmp             w4, NULL
    // 0xbf7744: b.ne            #0xbf774c
    // 0xbf7748: ldur            x4, [fp, #-0x10]
    // 0xbf774c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7750: ldur            x16, [fp, #-8]
    // 0xbf7754: SaveReg r16
    //     0xbf7754: str             x16, [SP, #-8]!
    // 0xbf7758: r0 = lerp()
    //     0xbf7758: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf775c: add             SP, SP, #0x18
    // 0xbf7760: mov             x1, x0
    // 0xbf7764: ldr             x0, [fp, #0x20]
    // 0xbf7768: stur            x1, [fp, #-0x48]
    // 0xbf776c: LoadField: r2 = r0->field_17
    //     0xbf776c: ldur            w2, [x0, #0x17]
    // 0xbf7770: DecompressPointer r2
    //     0xbf7770: add             x2, x2, HEAP, lsl #32
    // 0xbf7774: cmp             w2, NULL
    // 0xbf7778: b.ne            #0xbf7784
    // 0xbf777c: ldur            x3, [fp, #-0x30]
    // 0xbf7780: b               #0xbf7788
    // 0xbf7784: mov             x3, x2
    // 0xbf7788: ldr             x2, [fp, #0x18]
    // 0xbf778c: LoadField: r4 = r2->field_17
    //     0xbf778c: ldur            w4, [x2, #0x17]
    // 0xbf7790: DecompressPointer r4
    //     0xbf7790: add             x4, x4, HEAP, lsl #32
    // 0xbf7794: cmp             w4, NULL
    // 0xbf7798: b.ne            #0xbf77a0
    // 0xbf779c: ldur            x4, [fp, #-0x28]
    // 0xbf77a0: stp             x4, x3, [SP, #-0x10]!
    // 0xbf77a4: ldur            x16, [fp, #-8]
    // 0xbf77a8: SaveReg r16
    //     0xbf77a8: str             x16, [SP, #-8]!
    // 0xbf77ac: r0 = lerp()
    //     0xbf77ac: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf77b0: add             SP, SP, #0x18
    // 0xbf77b4: mov             x1, x0
    // 0xbf77b8: ldr             x0, [fp, #0x20]
    // 0xbf77bc: stur            x1, [fp, #-0x60]
    // 0xbf77c0: LoadField: r2 = r0->field_1b
    //     0xbf77c0: ldur            w2, [x0, #0x1b]
    // 0xbf77c4: DecompressPointer r2
    //     0xbf77c4: add             x2, x2, HEAP, lsl #32
    // 0xbf77c8: ldr             x3, [fp, #0x18]
    // 0xbf77cc: stur            x2, [fp, #-0x58]
    // 0xbf77d0: LoadField: r4 = r3->field_1b
    //     0xbf77d0: ldur            w4, [x3, #0x1b]
    // 0xbf77d4: DecompressPointer r4
    //     0xbf77d4: add             x4, x4, HEAP, lsl #32
    // 0xbf77d8: stur            x4, [fp, #-0x50]
    // 0xbf77dc: stp             x4, x2, [SP, #-0x10]!
    // 0xbf77e0: ldur            x16, [fp, #-8]
    // 0xbf77e4: SaveReg r16
    //     0xbf77e4: str             x16, [SP, #-8]!
    // 0xbf77e8: r0 = lerp()
    //     0xbf77e8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf77ec: add             SP, SP, #0x18
    // 0xbf77f0: stur            x0, [fp, #-0x78]
    // 0xbf77f4: cmp             w0, NULL
    // 0xbf77f8: b.eq            #0xbf8208
    // 0xbf77fc: ldr             x1, [fp, #0x20]
    // 0xbf7800: LoadField: r2 = r1->field_1f
    //     0xbf7800: ldur            w2, [x1, #0x1f]
    // 0xbf7804: DecompressPointer r2
    //     0xbf7804: add             x2, x2, HEAP, lsl #32
    // 0xbf7808: ldr             x3, [fp, #0x18]
    // 0xbf780c: stur            x2, [fp, #-0x70]
    // 0xbf7810: LoadField: r4 = r3->field_1f
    //     0xbf7810: ldur            w4, [x3, #0x1f]
    // 0xbf7814: DecompressPointer r4
    //     0xbf7814: add             x4, x4, HEAP, lsl #32
    // 0xbf7818: stur            x4, [fp, #-0x68]
    // 0xbf781c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7820: ldur            x16, [fp, #-8]
    // 0xbf7824: SaveReg r16
    //     0xbf7824: str             x16, [SP, #-8]!
    // 0xbf7828: r0 = lerp()
    //     0xbf7828: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf782c: add             SP, SP, #0x18
    // 0xbf7830: stur            x0, [fp, #-0x80]
    // 0xbf7834: cmp             w0, NULL
    // 0xbf7838: b.eq            #0xbf820c
    // 0xbf783c: ldr             x1, [fp, #0x20]
    // 0xbf7840: LoadField: r2 = r1->field_23
    //     0xbf7840: ldur            w2, [x1, #0x23]
    // 0xbf7844: DecompressPointer r2
    //     0xbf7844: add             x2, x2, HEAP, lsl #32
    // 0xbf7848: cmp             w2, NULL
    // 0xbf784c: b.ne            #0xbf7858
    // 0xbf7850: ldur            x3, [fp, #-0x58]
    // 0xbf7854: b               #0xbf785c
    // 0xbf7858: mov             x3, x2
    // 0xbf785c: ldr             x2, [fp, #0x18]
    // 0xbf7860: LoadField: r4 = r2->field_23
    //     0xbf7860: ldur            w4, [x2, #0x23]
    // 0xbf7864: DecompressPointer r4
    //     0xbf7864: add             x4, x4, HEAP, lsl #32
    // 0xbf7868: cmp             w4, NULL
    // 0xbf786c: b.ne            #0xbf7874
    // 0xbf7870: ldur            x4, [fp, #-0x50]
    // 0xbf7874: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7878: ldur            x16, [fp, #-8]
    // 0xbf787c: SaveReg r16
    //     0xbf787c: str             x16, [SP, #-8]!
    // 0xbf7880: r0 = lerp()
    //     0xbf7880: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7884: add             SP, SP, #0x18
    // 0xbf7888: mov             x1, x0
    // 0xbf788c: ldr             x0, [fp, #0x20]
    // 0xbf7890: stur            x1, [fp, #-0x88]
    // 0xbf7894: LoadField: r2 = r0->field_27
    //     0xbf7894: ldur            w2, [x0, #0x27]
    // 0xbf7898: DecompressPointer r2
    //     0xbf7898: add             x2, x2, HEAP, lsl #32
    // 0xbf789c: cmp             w2, NULL
    // 0xbf78a0: b.ne            #0xbf78ac
    // 0xbf78a4: ldur            x3, [fp, #-0x70]
    // 0xbf78a8: b               #0xbf78b0
    // 0xbf78ac: mov             x3, x2
    // 0xbf78b0: ldr             x2, [fp, #0x18]
    // 0xbf78b4: LoadField: r4 = r2->field_27
    //     0xbf78b4: ldur            w4, [x2, #0x27]
    // 0xbf78b8: DecompressPointer r4
    //     0xbf78b8: add             x4, x4, HEAP, lsl #32
    // 0xbf78bc: cmp             w4, NULL
    // 0xbf78c0: b.ne            #0xbf78c8
    // 0xbf78c4: ldur            x4, [fp, #-0x68]
    // 0xbf78c8: stp             x4, x3, [SP, #-0x10]!
    // 0xbf78cc: ldur            x16, [fp, #-8]
    // 0xbf78d0: SaveReg r16
    //     0xbf78d0: str             x16, [SP, #-8]!
    // 0xbf78d4: r0 = lerp()
    //     0xbf78d4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf78d8: add             SP, SP, #0x18
    // 0xbf78dc: mov             x1, x0
    // 0xbf78e0: ldr             x0, [fp, #0x20]
    // 0xbf78e4: stur            x1, [fp, #-0x90]
    // 0xbf78e8: LoadField: r2 = r0->field_2b
    //     0xbf78e8: ldur            w2, [x0, #0x2b]
    // 0xbf78ec: DecompressPointer r2
    //     0xbf78ec: add             x2, x2, HEAP, lsl #32
    // 0xbf78f0: cmp             w2, NULL
    // 0xbf78f4: b.ne            #0xbf7900
    // 0xbf78f8: ldur            x3, [fp, #-0x58]
    // 0xbf78fc: b               #0xbf7904
    // 0xbf7900: mov             x3, x2
    // 0xbf7904: ldr             x2, [fp, #0x18]
    // 0xbf7908: LoadField: r4 = r2->field_2b
    //     0xbf7908: ldur            w4, [x2, #0x2b]
    // 0xbf790c: DecompressPointer r4
    //     0xbf790c: add             x4, x4, HEAP, lsl #32
    // 0xbf7910: cmp             w4, NULL
    // 0xbf7914: b.ne            #0xbf791c
    // 0xbf7918: ldur            x4, [fp, #-0x50]
    // 0xbf791c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7920: ldur            x16, [fp, #-8]
    // 0xbf7924: SaveReg r16
    //     0xbf7924: str             x16, [SP, #-8]!
    // 0xbf7928: r0 = lerp()
    //     0xbf7928: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf792c: add             SP, SP, #0x18
    // 0xbf7930: mov             x1, x0
    // 0xbf7934: ldr             x0, [fp, #0x20]
    // 0xbf7938: stur            x1, [fp, #-0x98]
    // 0xbf793c: LoadField: r2 = r0->field_2f
    //     0xbf793c: ldur            w2, [x0, #0x2f]
    // 0xbf7940: DecompressPointer r2
    //     0xbf7940: add             x2, x2, HEAP, lsl #32
    // 0xbf7944: cmp             w2, NULL
    // 0xbf7948: b.ne            #0xbf7954
    // 0xbf794c: ldur            x3, [fp, #-0x70]
    // 0xbf7950: b               #0xbf7958
    // 0xbf7954: mov             x3, x2
    // 0xbf7958: ldr             x2, [fp, #0x18]
    // 0xbf795c: LoadField: r4 = r2->field_2f
    //     0xbf795c: ldur            w4, [x2, #0x2f]
    // 0xbf7960: DecompressPointer r4
    //     0xbf7960: add             x4, x4, HEAP, lsl #32
    // 0xbf7964: cmp             w4, NULL
    // 0xbf7968: b.ne            #0xbf7970
    // 0xbf796c: ldur            x4, [fp, #-0x68]
    // 0xbf7970: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7974: ldur            x16, [fp, #-8]
    // 0xbf7978: SaveReg r16
    //     0xbf7978: str             x16, [SP, #-8]!
    // 0xbf797c: r0 = lerp()
    //     0xbf797c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7980: add             SP, SP, #0x18
    // 0xbf7984: stur            x0, [fp, #-0x68]
    // 0xbf7988: ldr             x16, [fp, #0x20]
    // 0xbf798c: SaveReg r16
    //     0xbf798c: str             x16, [SP, #-8]!
    // 0xbf7990: r0 = tertiaryContainer()
    //     0xbf7990: bl              #0x6cd584  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0xbf7994: add             SP, SP, #8
    // 0xbf7998: stur            x0, [fp, #-0x70]
    // 0xbf799c: ldr             x16, [fp, #0x18]
    // 0xbf79a0: SaveReg r16
    //     0xbf79a0: str             x16, [SP, #-8]!
    // 0xbf79a4: r0 = tertiaryContainer()
    //     0xbf79a4: bl              #0x6cd584  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0xbf79a8: add             SP, SP, #8
    // 0xbf79ac: ldur            x16, [fp, #-0x70]
    // 0xbf79b0: stp             x0, x16, [SP, #-0x10]!
    // 0xbf79b4: ldur            x16, [fp, #-8]
    // 0xbf79b8: SaveReg r16
    //     0xbf79b8: str             x16, [SP, #-8]!
    // 0xbf79bc: r0 = lerp()
    //     0xbf79bc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf79c0: add             SP, SP, #0x18
    // 0xbf79c4: stur            x0, [fp, #-0x70]
    // 0xbf79c8: ldr             x16, [fp, #0x20]
    // 0xbf79cc: SaveReg r16
    //     0xbf79cc: str             x16, [SP, #-8]!
    // 0xbf79d0: r0 = onTertiaryContainer()
    //     0xbf79d0: bl              #0x6cd53c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0xbf79d4: add             SP, SP, #8
    // 0xbf79d8: stur            x0, [fp, #-0xa0]
    // 0xbf79dc: ldr             x16, [fp, #0x18]
    // 0xbf79e0: SaveReg r16
    //     0xbf79e0: str             x16, [SP, #-8]!
    // 0xbf79e4: r0 = onTertiaryContainer()
    //     0xbf79e4: bl              #0x6cd53c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0xbf79e8: add             SP, SP, #8
    // 0xbf79ec: ldur            x16, [fp, #-0xa0]
    // 0xbf79f0: stp             x0, x16, [SP, #-0x10]!
    // 0xbf79f4: ldur            x16, [fp, #-8]
    // 0xbf79f8: SaveReg r16
    //     0xbf79f8: str             x16, [SP, #-8]!
    // 0xbf79fc: r0 = lerp()
    //     0xbf79fc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7a00: add             SP, SP, #0x18
    // 0xbf7a04: mov             x1, x0
    // 0xbf7a08: ldr             x0, [fp, #0x20]
    // 0xbf7a0c: stur            x1, [fp, #-0xb0]
    // 0xbf7a10: LoadField: r2 = r0->field_3b
    //     0xbf7a10: ldur            w2, [x0, #0x3b]
    // 0xbf7a14: DecompressPointer r2
    //     0xbf7a14: add             x2, x2, HEAP, lsl #32
    // 0xbf7a18: ldr             x3, [fp, #0x18]
    // 0xbf7a1c: stur            x2, [fp, #-0xa8]
    // 0xbf7a20: LoadField: r4 = r3->field_3b
    //     0xbf7a20: ldur            w4, [x3, #0x3b]
    // 0xbf7a24: DecompressPointer r4
    //     0xbf7a24: add             x4, x4, HEAP, lsl #32
    // 0xbf7a28: stur            x4, [fp, #-0xa0]
    // 0xbf7a2c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7a30: ldur            x16, [fp, #-8]
    // 0xbf7a34: SaveReg r16
    //     0xbf7a34: str             x16, [SP, #-8]!
    // 0xbf7a38: r0 = lerp()
    //     0xbf7a38: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7a3c: add             SP, SP, #0x18
    // 0xbf7a40: stur            x0, [fp, #-0xc8]
    // 0xbf7a44: cmp             w0, NULL
    // 0xbf7a48: b.eq            #0xbf8210
    // 0xbf7a4c: ldr             x1, [fp, #0x20]
    // 0xbf7a50: LoadField: r2 = r1->field_3f
    //     0xbf7a50: ldur            w2, [x1, #0x3f]
    // 0xbf7a54: DecompressPointer r2
    //     0xbf7a54: add             x2, x2, HEAP, lsl #32
    // 0xbf7a58: ldr             x3, [fp, #0x18]
    // 0xbf7a5c: stur            x2, [fp, #-0xc0]
    // 0xbf7a60: LoadField: r4 = r3->field_3f
    //     0xbf7a60: ldur            w4, [x3, #0x3f]
    // 0xbf7a64: DecompressPointer r4
    //     0xbf7a64: add             x4, x4, HEAP, lsl #32
    // 0xbf7a68: stur            x4, [fp, #-0xb8]
    // 0xbf7a6c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7a70: ldur            x16, [fp, #-8]
    // 0xbf7a74: SaveReg r16
    //     0xbf7a74: str             x16, [SP, #-8]!
    // 0xbf7a78: r0 = lerp()
    //     0xbf7a78: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7a7c: add             SP, SP, #0x18
    // 0xbf7a80: stur            x0, [fp, #-0xd0]
    // 0xbf7a84: cmp             w0, NULL
    // 0xbf7a88: b.eq            #0xbf8214
    // 0xbf7a8c: ldr             x1, [fp, #0x20]
    // 0xbf7a90: LoadField: r2 = r1->field_43
    //     0xbf7a90: ldur            w2, [x1, #0x43]
    // 0xbf7a94: DecompressPointer r2
    //     0xbf7a94: add             x2, x2, HEAP, lsl #32
    // 0xbf7a98: cmp             w2, NULL
    // 0xbf7a9c: b.ne            #0xbf7aa8
    // 0xbf7aa0: ldur            x3, [fp, #-0xa8]
    // 0xbf7aa4: b               #0xbf7aac
    // 0xbf7aa8: mov             x3, x2
    // 0xbf7aac: ldr             x2, [fp, #0x18]
    // 0xbf7ab0: LoadField: r4 = r2->field_43
    //     0xbf7ab0: ldur            w4, [x2, #0x43]
    // 0xbf7ab4: DecompressPointer r4
    //     0xbf7ab4: add             x4, x4, HEAP, lsl #32
    // 0xbf7ab8: cmp             w4, NULL
    // 0xbf7abc: b.ne            #0xbf7ac4
    // 0xbf7ac0: ldur            x4, [fp, #-0xa0]
    // 0xbf7ac4: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7ac8: ldur            x16, [fp, #-8]
    // 0xbf7acc: SaveReg r16
    //     0xbf7acc: str             x16, [SP, #-8]!
    // 0xbf7ad0: r0 = lerp()
    //     0xbf7ad0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7ad4: add             SP, SP, #0x18
    // 0xbf7ad8: mov             x1, x0
    // 0xbf7adc: ldr             x0, [fp, #0x20]
    // 0xbf7ae0: stur            x1, [fp, #-0xa0]
    // 0xbf7ae4: LoadField: r2 = r0->field_47
    //     0xbf7ae4: ldur            w2, [x0, #0x47]
    // 0xbf7ae8: DecompressPointer r2
    //     0xbf7ae8: add             x2, x2, HEAP, lsl #32
    // 0xbf7aec: cmp             w2, NULL
    // 0xbf7af0: b.ne            #0xbf7afc
    // 0xbf7af4: ldur            x3, [fp, #-0xc0]
    // 0xbf7af8: b               #0xbf7b00
    // 0xbf7afc: mov             x3, x2
    // 0xbf7b00: ldr             x2, [fp, #0x18]
    // 0xbf7b04: LoadField: r4 = r2->field_47
    //     0xbf7b04: ldur            w4, [x2, #0x47]
    // 0xbf7b08: DecompressPointer r4
    //     0xbf7b08: add             x4, x4, HEAP, lsl #32
    // 0xbf7b0c: cmp             w4, NULL
    // 0xbf7b10: b.ne            #0xbf7b18
    // 0xbf7b14: ldur            x4, [fp, #-0xb8]
    // 0xbf7b18: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7b1c: ldur            x16, [fp, #-8]
    // 0xbf7b20: SaveReg r16
    //     0xbf7b20: str             x16, [SP, #-8]!
    // 0xbf7b24: r0 = lerp()
    //     0xbf7b24: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7b28: add             SP, SP, #0x18
    // 0xbf7b2c: mov             x1, x0
    // 0xbf7b30: ldr             x0, [fp, #0x20]
    // 0xbf7b34: stur            x1, [fp, #-0xa8]
    // 0xbf7b38: LoadField: r2 = r0->field_4b
    //     0xbf7b38: ldur            w2, [x0, #0x4b]
    // 0xbf7b3c: DecompressPointer r2
    //     0xbf7b3c: add             x2, x2, HEAP, lsl #32
    // 0xbf7b40: ldr             x3, [fp, #0x18]
    // 0xbf7b44: LoadField: r4 = r3->field_4b
    //     0xbf7b44: ldur            w4, [x3, #0x4b]
    // 0xbf7b48: DecompressPointer r4
    //     0xbf7b48: add             x4, x4, HEAP, lsl #32
    // 0xbf7b4c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7b50: ldur            x16, [fp, #-8]
    // 0xbf7b54: SaveReg r16
    //     0xbf7b54: str             x16, [SP, #-8]!
    // 0xbf7b58: r0 = lerp()
    //     0xbf7b58: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7b5c: add             SP, SP, #0x18
    // 0xbf7b60: stur            x0, [fp, #-0xd8]
    // 0xbf7b64: cmp             w0, NULL
    // 0xbf7b68: b.eq            #0xbf8218
    // 0xbf7b6c: ldr             x1, [fp, #0x20]
    // 0xbf7b70: LoadField: r2 = r1->field_4f
    //     0xbf7b70: ldur            w2, [x1, #0x4f]
    // 0xbf7b74: DecompressPointer r2
    //     0xbf7b74: add             x2, x2, HEAP, lsl #32
    // 0xbf7b78: ldr             x3, [fp, #0x18]
    // 0xbf7b7c: stur            x2, [fp, #-0xc0]
    // 0xbf7b80: LoadField: r4 = r3->field_4f
    //     0xbf7b80: ldur            w4, [x3, #0x4f]
    // 0xbf7b84: DecompressPointer r4
    //     0xbf7b84: add             x4, x4, HEAP, lsl #32
    // 0xbf7b88: stur            x4, [fp, #-0xb8]
    // 0xbf7b8c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7b90: ldur            x16, [fp, #-8]
    // 0xbf7b94: SaveReg r16
    //     0xbf7b94: str             x16, [SP, #-8]!
    // 0xbf7b98: r0 = lerp()
    //     0xbf7b98: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7b9c: add             SP, SP, #0x18
    // 0xbf7ba0: stur            x0, [fp, #-0xf0]
    // 0xbf7ba4: cmp             w0, NULL
    // 0xbf7ba8: b.eq            #0xbf821c
    // 0xbf7bac: ldr             x1, [fp, #0x20]
    // 0xbf7bb0: LoadField: r2 = r1->field_53
    //     0xbf7bb0: ldur            w2, [x1, #0x53]
    // 0xbf7bb4: DecompressPointer r2
    //     0xbf7bb4: add             x2, x2, HEAP, lsl #32
    // 0xbf7bb8: ldr             x3, [fp, #0x18]
    // 0xbf7bbc: stur            x2, [fp, #-0xe8]
    // 0xbf7bc0: LoadField: r4 = r3->field_53
    //     0xbf7bc0: ldur            w4, [x3, #0x53]
    // 0xbf7bc4: DecompressPointer r4
    //     0xbf7bc4: add             x4, x4, HEAP, lsl #32
    // 0xbf7bc8: stur            x4, [fp, #-0xe0]
    // 0xbf7bcc: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7bd0: ldur            x16, [fp, #-8]
    // 0xbf7bd4: SaveReg r16
    //     0xbf7bd4: str             x16, [SP, #-8]!
    // 0xbf7bd8: r0 = lerp()
    //     0xbf7bd8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7bdc: add             SP, SP, #0x18
    // 0xbf7be0: r17 = -264
    //     0xbf7be0: mov             x17, #-0x108
    // 0xbf7be4: str             x0, [fp, x17]
    // 0xbf7be8: cmp             w0, NULL
    // 0xbf7bec: b.eq            #0xbf8220
    // 0xbf7bf0: ldr             x1, [fp, #0x20]
    // 0xbf7bf4: LoadField: r2 = r1->field_57
    //     0xbf7bf4: ldur            w2, [x1, #0x57]
    // 0xbf7bf8: DecompressPointer r2
    //     0xbf7bf8: add             x2, x2, HEAP, lsl #32
    // 0xbf7bfc: ldr             x3, [fp, #0x18]
    // 0xbf7c00: stur            x2, [fp, #-0x100]
    // 0xbf7c04: LoadField: r4 = r3->field_57
    //     0xbf7c04: ldur            w4, [x3, #0x57]
    // 0xbf7c08: DecompressPointer r4
    //     0xbf7c08: add             x4, x4, HEAP, lsl #32
    // 0xbf7c0c: stur            x4, [fp, #-0xf8]
    // 0xbf7c10: stp             x4, x2, [SP, #-0x10]!
    // 0xbf7c14: ldur            x16, [fp, #-8]
    // 0xbf7c18: SaveReg r16
    //     0xbf7c18: str             x16, [SP, #-8]!
    // 0xbf7c1c: r0 = lerp()
    //     0xbf7c1c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7c20: add             SP, SP, #0x18
    // 0xbf7c24: r17 = -272
    //     0xbf7c24: mov             x17, #-0x110
    // 0xbf7c28: str             x0, [fp, x17]
    // 0xbf7c2c: cmp             w0, NULL
    // 0xbf7c30: b.eq            #0xbf8224
    // 0xbf7c34: ldr             x1, [fp, #0x20]
    // 0xbf7c38: LoadField: r2 = r1->field_5b
    //     0xbf7c38: ldur            w2, [x1, #0x5b]
    // 0xbf7c3c: DecompressPointer r2
    //     0xbf7c3c: add             x2, x2, HEAP, lsl #32
    // 0xbf7c40: cmp             w2, NULL
    // 0xbf7c44: b.ne            #0xbf7c50
    // 0xbf7c48: ldur            x3, [fp, #-0xe8]
    // 0xbf7c4c: b               #0xbf7c54
    // 0xbf7c50: mov             x3, x2
    // 0xbf7c54: ldr             x2, [fp, #0x18]
    // 0xbf7c58: LoadField: r4 = r2->field_5b
    //     0xbf7c58: ldur            w4, [x2, #0x5b]
    // 0xbf7c5c: DecompressPointer r4
    //     0xbf7c5c: add             x4, x4, HEAP, lsl #32
    // 0xbf7c60: cmp             w4, NULL
    // 0xbf7c64: b.ne            #0xbf7c6c
    // 0xbf7c68: ldur            x4, [fp, #-0xe0]
    // 0xbf7c6c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7c70: ldur            x16, [fp, #-8]
    // 0xbf7c74: SaveReg r16
    //     0xbf7c74: str             x16, [SP, #-8]!
    // 0xbf7c78: r0 = lerp()
    //     0xbf7c78: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7c7c: add             SP, SP, #0x18
    // 0xbf7c80: mov             x1, x0
    // 0xbf7c84: ldr             x0, [fp, #0x20]
    // 0xbf7c88: r17 = -280
    //     0xbf7c88: mov             x17, #-0x118
    // 0xbf7c8c: str             x1, [fp, x17]
    // 0xbf7c90: LoadField: r2 = r0->field_5f
    //     0xbf7c90: ldur            w2, [x0, #0x5f]
    // 0xbf7c94: DecompressPointer r2
    //     0xbf7c94: add             x2, x2, HEAP, lsl #32
    // 0xbf7c98: cmp             w2, NULL
    // 0xbf7c9c: b.ne            #0xbf7ca8
    // 0xbf7ca0: ldur            x3, [fp, #-0x100]
    // 0xbf7ca4: b               #0xbf7cac
    // 0xbf7ca8: mov             x3, x2
    // 0xbf7cac: ldr             x2, [fp, #0x18]
    // 0xbf7cb0: LoadField: r4 = r2->field_5f
    //     0xbf7cb0: ldur            w4, [x2, #0x5f]
    // 0xbf7cb4: DecompressPointer r4
    //     0xbf7cb4: add             x4, x4, HEAP, lsl #32
    // 0xbf7cb8: cmp             w4, NULL
    // 0xbf7cbc: b.ne            #0xbf7cc4
    // 0xbf7cc0: ldur            x4, [fp, #-0xf8]
    // 0xbf7cc4: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7cc8: ldur            x16, [fp, #-8]
    // 0xbf7ccc: SaveReg r16
    //     0xbf7ccc: str             x16, [SP, #-8]!
    // 0xbf7cd0: r0 = lerp()
    //     0xbf7cd0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7cd4: add             SP, SP, #0x18
    // 0xbf7cd8: mov             x1, x0
    // 0xbf7cdc: ldr             x0, [fp, #0x20]
    // 0xbf7ce0: r17 = -288
    //     0xbf7ce0: mov             x17, #-0x120
    // 0xbf7ce4: str             x1, [fp, x17]
    // 0xbf7ce8: LoadField: r2 = r0->field_63
    //     0xbf7ce8: ldur            w2, [x0, #0x63]
    // 0xbf7cec: DecompressPointer r2
    //     0xbf7cec: add             x2, x2, HEAP, lsl #32
    // 0xbf7cf0: cmp             w2, NULL
    // 0xbf7cf4: b.ne            #0xbf7d00
    // 0xbf7cf8: ldur            x3, [fp, #-0xc0]
    // 0xbf7cfc: b               #0xbf7d04
    // 0xbf7d00: mov             x3, x2
    // 0xbf7d04: ldr             x2, [fp, #0x18]
    // 0xbf7d08: LoadField: r4 = r2->field_63
    //     0xbf7d08: ldur            w4, [x2, #0x63]
    // 0xbf7d0c: DecompressPointer r4
    //     0xbf7d0c: add             x4, x4, HEAP, lsl #32
    // 0xbf7d10: cmp             w4, NULL
    // 0xbf7d14: b.ne            #0xbf7d1c
    // 0xbf7d18: ldur            x4, [fp, #-0xb8]
    // 0xbf7d1c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7d20: ldur            x16, [fp, #-8]
    // 0xbf7d24: SaveReg r16
    //     0xbf7d24: str             x16, [SP, #-8]!
    // 0xbf7d28: r0 = lerp()
    //     0xbf7d28: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7d2c: add             SP, SP, #0x18
    // 0xbf7d30: mov             x1, x0
    // 0xbf7d34: ldr             x0, [fp, #0x20]
    // 0xbf7d38: r17 = -296
    //     0xbf7d38: mov             x17, #-0x128
    // 0xbf7d3c: str             x1, [fp, x17]
    // 0xbf7d40: LoadField: r2 = r0->field_67
    //     0xbf7d40: ldur            w2, [x0, #0x67]
    // 0xbf7d44: DecompressPointer r2
    //     0xbf7d44: add             x2, x2, HEAP, lsl #32
    // 0xbf7d48: cmp             w2, NULL
    // 0xbf7d4c: b.ne            #0xbf7d58
    // 0xbf7d50: ldur            x3, [fp, #-0xc0]
    // 0xbf7d54: b               #0xbf7d5c
    // 0xbf7d58: mov             x3, x2
    // 0xbf7d5c: ldr             x2, [fp, #0x18]
    // 0xbf7d60: LoadField: r4 = r2->field_67
    //     0xbf7d60: ldur            w4, [x2, #0x67]
    // 0xbf7d64: DecompressPointer r4
    //     0xbf7d64: add             x4, x4, HEAP, lsl #32
    // 0xbf7d68: cmp             w4, NULL
    // 0xbf7d6c: b.ne            #0xbf7d74
    // 0xbf7d70: ldur            x4, [fp, #-0xb8]
    // 0xbf7d74: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7d78: ldur            x16, [fp, #-8]
    // 0xbf7d7c: SaveReg r16
    //     0xbf7d7c: str             x16, [SP, #-8]!
    // 0xbf7d80: r0 = lerp()
    //     0xbf7d80: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7d84: add             SP, SP, #0x18
    // 0xbf7d88: mov             x1, x0
    // 0xbf7d8c: ldr             x0, [fp, #0x20]
    // 0xbf7d90: stur            x1, [fp, #-0xb8]
    // 0xbf7d94: LoadField: r2 = r0->field_6b
    //     0xbf7d94: ldur            w2, [x0, #0x6b]
    // 0xbf7d98: DecompressPointer r2
    //     0xbf7d98: add             x2, x2, HEAP, lsl #32
    // 0xbf7d9c: cmp             w2, NULL
    // 0xbf7da0: b.ne            #0xbf7db0
    // 0xbf7da4: r3 = Instance_Color
    //     0xbf7da4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xbf7da8: ldr             x3, [x3, #0xf38]
    // 0xbf7dac: b               #0xbf7db4
    // 0xbf7db0: mov             x3, x2
    // 0xbf7db4: ldr             x2, [fp, #0x18]
    // 0xbf7db8: LoadField: r4 = r2->field_6b
    //     0xbf7db8: ldur            w4, [x2, #0x6b]
    // 0xbf7dbc: DecompressPointer r4
    //     0xbf7dbc: add             x4, x4, HEAP, lsl #32
    // 0xbf7dc0: cmp             w4, NULL
    // 0xbf7dc4: b.ne            #0xbf7dd0
    // 0xbf7dc8: r4 = Instance_Color
    //     0xbf7dc8: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xbf7dcc: ldr             x4, [x4, #0xf38]
    // 0xbf7dd0: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7dd4: ldur            x16, [fp, #-8]
    // 0xbf7dd8: SaveReg r16
    //     0xbf7dd8: str             x16, [SP, #-8]!
    // 0xbf7ddc: r0 = lerp()
    //     0xbf7ddc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7de0: add             SP, SP, #0x18
    // 0xbf7de4: mov             x1, x0
    // 0xbf7de8: ldr             x0, [fp, #0x20]
    // 0xbf7dec: stur            x1, [fp, #-0xc0]
    // 0xbf7df0: LoadField: r2 = r0->field_6f
    //     0xbf7df0: ldur            w2, [x0, #0x6f]
    // 0xbf7df4: DecompressPointer r2
    //     0xbf7df4: add             x2, x2, HEAP, lsl #32
    // 0xbf7df8: cmp             w2, NULL
    // 0xbf7dfc: b.ne            #0xbf7e0c
    // 0xbf7e00: r3 = Instance_Color
    //     0xbf7e00: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xbf7e04: ldr             x3, [x3, #0xf38]
    // 0xbf7e08: b               #0xbf7e10
    // 0xbf7e0c: mov             x3, x2
    // 0xbf7e10: ldr             x2, [fp, #0x18]
    // 0xbf7e14: LoadField: r4 = r2->field_6f
    //     0xbf7e14: ldur            w4, [x2, #0x6f]
    // 0xbf7e18: DecompressPointer r4
    //     0xbf7e18: add             x4, x4, HEAP, lsl #32
    // 0xbf7e1c: cmp             w4, NULL
    // 0xbf7e20: b.ne            #0xbf7e2c
    // 0xbf7e24: r4 = Instance_Color
    //     0xbf7e24: add             x4, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xbf7e28: ldr             x4, [x4, #0xf38]
    // 0xbf7e2c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7e30: ldur            x16, [fp, #-8]
    // 0xbf7e34: SaveReg r16
    //     0xbf7e34: str             x16, [SP, #-8]!
    // 0xbf7e38: r0 = lerp()
    //     0xbf7e38: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7e3c: add             SP, SP, #0x18
    // 0xbf7e40: mov             x1, x0
    // 0xbf7e44: ldr             x0, [fp, #0x20]
    // 0xbf7e48: r17 = -304
    //     0xbf7e48: mov             x17, #-0x130
    // 0xbf7e4c: str             x1, [fp, x17]
    // 0xbf7e50: LoadField: r2 = r0->field_73
    //     0xbf7e50: ldur            w2, [x0, #0x73]
    // 0xbf7e54: DecompressPointer r2
    //     0xbf7e54: add             x2, x2, HEAP, lsl #32
    // 0xbf7e58: cmp             w2, NULL
    // 0xbf7e5c: b.ne            #0xbf7e68
    // 0xbf7e60: ldur            x3, [fp, #-0x100]
    // 0xbf7e64: b               #0xbf7e6c
    // 0xbf7e68: mov             x3, x2
    // 0xbf7e6c: ldr             x2, [fp, #0x18]
    // 0xbf7e70: LoadField: r4 = r2->field_73
    //     0xbf7e70: ldur            w4, [x2, #0x73]
    // 0xbf7e74: DecompressPointer r4
    //     0xbf7e74: add             x4, x4, HEAP, lsl #32
    // 0xbf7e78: cmp             w4, NULL
    // 0xbf7e7c: b.ne            #0xbf7e84
    // 0xbf7e80: ldur            x4, [fp, #-0xf8]
    // 0xbf7e84: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7e88: ldur            x16, [fp, #-8]
    // 0xbf7e8c: SaveReg r16
    //     0xbf7e8c: str             x16, [SP, #-8]!
    // 0xbf7e90: r0 = lerp()
    //     0xbf7e90: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7e94: add             SP, SP, #0x18
    // 0xbf7e98: mov             x1, x0
    // 0xbf7e9c: ldr             x0, [fp, #0x20]
    // 0xbf7ea0: stur            x1, [fp, #-0xf8]
    // 0xbf7ea4: LoadField: r2 = r0->field_77
    //     0xbf7ea4: ldur            w2, [x0, #0x77]
    // 0xbf7ea8: DecompressPointer r2
    //     0xbf7ea8: add             x2, x2, HEAP, lsl #32
    // 0xbf7eac: cmp             w2, NULL
    // 0xbf7eb0: b.ne            #0xbf7ebc
    // 0xbf7eb4: ldur            x3, [fp, #-0xe8]
    // 0xbf7eb8: b               #0xbf7ec0
    // 0xbf7ebc: mov             x3, x2
    // 0xbf7ec0: ldr             x2, [fp, #0x18]
    // 0xbf7ec4: LoadField: r4 = r2->field_77
    //     0xbf7ec4: ldur            w4, [x2, #0x77]
    // 0xbf7ec8: DecompressPointer r4
    //     0xbf7ec8: add             x4, x4, HEAP, lsl #32
    // 0xbf7ecc: cmp             w4, NULL
    // 0xbf7ed0: b.ne            #0xbf7ed8
    // 0xbf7ed4: ldur            x4, [fp, #-0xe0]
    // 0xbf7ed8: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7edc: ldur            x16, [fp, #-8]
    // 0xbf7ee0: SaveReg r16
    //     0xbf7ee0: str             x16, [SP, #-8]!
    // 0xbf7ee4: r0 = lerp()
    //     0xbf7ee4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7ee8: add             SP, SP, #0x18
    // 0xbf7eec: mov             x1, x0
    // 0xbf7ef0: ldr             x0, [fp, #0x20]
    // 0xbf7ef4: stur            x1, [fp, #-0xe0]
    // 0xbf7ef8: LoadField: r2 = r0->field_7b
    //     0xbf7ef8: ldur            w2, [x0, #0x7b]
    // 0xbf7efc: DecompressPointer r2
    //     0xbf7efc: add             x2, x2, HEAP, lsl #32
    // 0xbf7f00: cmp             w2, NULL
    // 0xbf7f04: b.ne            #0xbf7f10
    // 0xbf7f08: ldur            x3, [fp, #-0x30]
    // 0xbf7f0c: b               #0xbf7f14
    // 0xbf7f10: mov             x3, x2
    // 0xbf7f14: ldr             x2, [fp, #0x18]
    // 0xbf7f18: LoadField: r4 = r2->field_7b
    //     0xbf7f18: ldur            w4, [x2, #0x7b]
    // 0xbf7f1c: DecompressPointer r4
    //     0xbf7f1c: add             x4, x4, HEAP, lsl #32
    // 0xbf7f20: cmp             w4, NULL
    // 0xbf7f24: b.ne            #0xbf7f2c
    // 0xbf7f28: ldur            x4, [fp, #-0x28]
    // 0xbf7f2c: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7f30: ldur            x16, [fp, #-8]
    // 0xbf7f34: SaveReg r16
    //     0xbf7f34: str             x16, [SP, #-8]!
    // 0xbf7f38: r0 = lerp()
    //     0xbf7f38: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7f3c: add             SP, SP, #0x18
    // 0xbf7f40: mov             x1, x0
    // 0xbf7f44: ldr             x0, [fp, #0x20]
    // 0xbf7f48: stur            x1, [fp, #-0x28]
    // 0xbf7f4c: LoadField: r2 = r0->field_83
    //     0xbf7f4c: ldur            w2, [x0, #0x83]
    // 0xbf7f50: DecompressPointer r2
    //     0xbf7f50: add             x2, x2, HEAP, lsl #32
    // 0xbf7f54: cmp             w2, NULL
    // 0xbf7f58: b.ne            #0xbf7f64
    // 0xbf7f5c: ldur            x3, [fp, #-0x18]
    // 0xbf7f60: b               #0xbf7f68
    // 0xbf7f64: mov             x3, x2
    // 0xbf7f68: ldr             x2, [fp, #0x18]
    // 0xbf7f6c: LoadField: r4 = r2->field_83
    //     0xbf7f6c: ldur            w4, [x2, #0x83]
    // 0xbf7f70: DecompressPointer r4
    //     0xbf7f70: add             x4, x4, HEAP, lsl #32
    // 0xbf7f74: cmp             w4, NULL
    // 0xbf7f78: b.ne            #0xbf7f80
    // 0xbf7f7c: ldur            x4, [fp, #-0x10]
    // 0xbf7f80: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7f84: ldur            x16, [fp, #-8]
    // 0xbf7f88: SaveReg r16
    //     0xbf7f88: str             x16, [SP, #-8]!
    // 0xbf7f8c: r0 = lerp()
    //     0xbf7f8c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7f90: add             SP, SP, #0x18
    // 0xbf7f94: mov             x1, x0
    // 0xbf7f98: ldr             x0, [fp, #0x20]
    // 0xbf7f9c: stur            x1, [fp, #-0x30]
    // 0xbf7fa0: LoadField: r2 = r0->field_87
    //     0xbf7fa0: ldur            w2, [x0, #0x87]
    // 0xbf7fa4: DecompressPointer r2
    //     0xbf7fa4: add             x2, x2, HEAP, lsl #32
    // 0xbf7fa8: cmp             w2, NULL
    // 0xbf7fac: b.ne            #0xbf7fb8
    // 0xbf7fb0: ldur            x3, [fp, #-0x58]
    // 0xbf7fb4: b               #0xbf7fbc
    // 0xbf7fb8: mov             x3, x2
    // 0xbf7fbc: ldr             x2, [fp, #0x18]
    // 0xbf7fc0: LoadField: r4 = r2->field_87
    //     0xbf7fc0: ldur            w4, [x2, #0x87]
    // 0xbf7fc4: DecompressPointer r4
    //     0xbf7fc4: add             x4, x4, HEAP, lsl #32
    // 0xbf7fc8: cmp             w4, NULL
    // 0xbf7fcc: b.ne            #0xbf7fd4
    // 0xbf7fd0: ldur            x4, [fp, #-0x50]
    // 0xbf7fd4: stp             x4, x3, [SP, #-0x10]!
    // 0xbf7fd8: ldur            x16, [fp, #-8]
    // 0xbf7fdc: SaveReg r16
    //     0xbf7fdc: str             x16, [SP, #-8]!
    // 0xbf7fe0: r0 = lerp()
    //     0xbf7fe0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf7fe4: add             SP, SP, #0x18
    // 0xbf7fe8: mov             x1, x0
    // 0xbf7fec: ldr             x0, [fp, #0x20]
    // 0xbf7ff0: stur            x1, [fp, #-0x50]
    // 0xbf7ff4: LoadField: r2 = r0->field_7f
    //     0xbf7ff4: ldur            w2, [x0, #0x7f]
    // 0xbf7ff8: DecompressPointer r2
    //     0xbf7ff8: add             x2, x2, HEAP, lsl #32
    // 0xbf7ffc: cmp             w2, NULL
    // 0xbf8000: b.ne            #0xbf8008
    // 0xbf8004: ldur            x2, [fp, #-0x18]
    // 0xbf8008: ldr             x0, [fp, #0x18]
    // 0xbf800c: LoadField: r3 = r0->field_7f
    //     0xbf800c: ldur            w3, [x0, #0x7f]
    // 0xbf8010: DecompressPointer r3
    //     0xbf8010: add             x3, x3, HEAP, lsl #32
    // 0xbf8014: cmp             w3, NULL
    // 0xbf8018: b.eq            #0xbf8020
    // 0xbf801c: stur            x3, [fp, #-0x10]
    // 0xbf8020: ldur            x25, [fp, #-0xc8]
    // 0xbf8024: ldur            x24, [fp, #-0xd0]
    // 0xbf8028: ldur            x23, [fp, #-0xa0]
    // 0xbf802c: ldur            x20, [fp, #-0xa8]
    // 0xbf8030: ldur            x19, [fp, #-0xd8]
    // 0xbf8034: ldur            x14, [fp, #-0xf0]
    // 0xbf8038: r17 = -264
    //     0xbf8038: mov             x17, #-0x108
    // 0xbf803c: ldr             x13, [fp, x17]
    // 0xbf8040: r17 = -272
    //     0xbf8040: mov             x17, #-0x110
    // 0xbf8044: ldr             x12, [fp, x17]
    // 0xbf8048: r17 = -280
    //     0xbf8048: mov             x17, #-0x118
    // 0xbf804c: ldr             x11, [fp, x17]
    // 0xbf8050: r17 = -288
    //     0xbf8050: mov             x17, #-0x120
    // 0xbf8054: ldr             x10, [fp, x17]
    // 0xbf8058: r17 = -296
    //     0xbf8058: mov             x17, #-0x128
    // 0xbf805c: ldr             x9, [fp, x17]
    // 0xbf8060: ldur            x8, [fp, #-0xb8]
    // 0xbf8064: ldur            x7, [fp, #-0xc0]
    // 0xbf8068: r17 = -304
    //     0xbf8068: mov             x17, #-0x130
    // 0xbf806c: ldr             x6, [fp, x17]
    // 0xbf8070: ldur            x5, [fp, #-0xf8]
    // 0xbf8074: ldur            x4, [fp, #-0xe0]
    // 0xbf8078: ldur            x3, [fp, #-0x28]
    // 0xbf807c: ldur            x0, [fp, #-0x30]
    // 0xbf8080: ldur            x16, [fp, #-0x10]
    // 0xbf8084: stp             x16, x2, [SP, #-0x10]!
    // 0xbf8088: ldur            x16, [fp, #-8]
    // 0xbf808c: SaveReg r16
    //     0xbf808c: str             x16, [SP, #-8]!
    // 0xbf8090: r0 = lerp()
    //     0xbf8090: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf8094: add             SP, SP, #0x18
    // 0xbf8098: stur            x0, [fp, #-8]
    // 0xbf809c: r0 = ColorScheme()
    //     0xbf809c: bl              #0x6cd530  ; AllocateColorSchemeStub -> ColorScheme (size=0x8c)
    // 0xbf80a0: ldur            x1, [fp, #-0x20]
    // 0xbf80a4: StoreField: r0->field_7 = r1
    //     0xbf80a4: stur            w1, [x0, #7]
    // 0xbf80a8: ldur            x1, [fp, #-0x38]
    // 0xbf80ac: StoreField: r0->field_b = r1
    //     0xbf80ac: stur            w1, [x0, #0xb]
    // 0xbf80b0: ldur            x1, [fp, #-0x40]
    // 0xbf80b4: StoreField: r0->field_f = r1
    //     0xbf80b4: stur            w1, [x0, #0xf]
    // 0xbf80b8: ldur            x1, [fp, #-0x78]
    // 0xbf80bc: StoreField: r0->field_1b = r1
    //     0xbf80bc: stur            w1, [x0, #0x1b]
    // 0xbf80c0: ldur            x1, [fp, #-0x80]
    // 0xbf80c4: StoreField: r0->field_1f = r1
    //     0xbf80c4: stur            w1, [x0, #0x1f]
    // 0xbf80c8: ldur            x1, [fp, #-0xc8]
    // 0xbf80cc: StoreField: r0->field_3b = r1
    //     0xbf80cc: stur            w1, [x0, #0x3b]
    // 0xbf80d0: ldur            x1, [fp, #-0xd0]
    // 0xbf80d4: StoreField: r0->field_3f = r1
    //     0xbf80d4: stur            w1, [x0, #0x3f]
    // 0xbf80d8: ldur            x1, [fp, #-0xd8]
    // 0xbf80dc: StoreField: r0->field_4b = r1
    //     0xbf80dc: stur            w1, [x0, #0x4b]
    // 0xbf80e0: ldur            x1, [fp, #-0xf0]
    // 0xbf80e4: StoreField: r0->field_4f = r1
    //     0xbf80e4: stur            w1, [x0, #0x4f]
    // 0xbf80e8: r17 = -264
    //     0xbf80e8: mov             x17, #-0x108
    // 0xbf80ec: ldr             x1, [fp, x17]
    // 0xbf80f0: StoreField: r0->field_53 = r1
    //     0xbf80f0: stur            w1, [x0, #0x53]
    // 0xbf80f4: r17 = -272
    //     0xbf80f4: mov             x17, #-0x110
    // 0xbf80f8: ldr             x1, [fp, x17]
    // 0xbf80fc: StoreField: r0->field_57 = r1
    //     0xbf80fc: stur            w1, [x0, #0x57]
    // 0xbf8100: ldur            x1, [fp, #-0x48]
    // 0xbf8104: StoreField: r0->field_13 = r1
    //     0xbf8104: stur            w1, [x0, #0x13]
    // 0xbf8108: ldur            x1, [fp, #-0x60]
    // 0xbf810c: StoreField: r0->field_17 = r1
    //     0xbf810c: stur            w1, [x0, #0x17]
    // 0xbf8110: ldur            x1, [fp, #-0x88]
    // 0xbf8114: StoreField: r0->field_23 = r1
    //     0xbf8114: stur            w1, [x0, #0x23]
    // 0xbf8118: ldur            x1, [fp, #-0x90]
    // 0xbf811c: StoreField: r0->field_27 = r1
    //     0xbf811c: stur            w1, [x0, #0x27]
    // 0xbf8120: ldur            x1, [fp, #-0x98]
    // 0xbf8124: StoreField: r0->field_2b = r1
    //     0xbf8124: stur            w1, [x0, #0x2b]
    // 0xbf8128: ldur            x1, [fp, #-0x68]
    // 0xbf812c: StoreField: r0->field_2f = r1
    //     0xbf812c: stur            w1, [x0, #0x2f]
    // 0xbf8130: ldur            x1, [fp, #-0x70]
    // 0xbf8134: StoreField: r0->field_33 = r1
    //     0xbf8134: stur            w1, [x0, #0x33]
    // 0xbf8138: ldur            x1, [fp, #-0xb0]
    // 0xbf813c: StoreField: r0->field_37 = r1
    //     0xbf813c: stur            w1, [x0, #0x37]
    // 0xbf8140: ldur            x1, [fp, #-0xa0]
    // 0xbf8144: StoreField: r0->field_43 = r1
    //     0xbf8144: stur            w1, [x0, #0x43]
    // 0xbf8148: ldur            x1, [fp, #-0xa8]
    // 0xbf814c: StoreField: r0->field_47 = r1
    //     0xbf814c: stur            w1, [x0, #0x47]
    // 0xbf8150: r17 = -280
    //     0xbf8150: mov             x17, #-0x118
    // 0xbf8154: ldr             x1, [fp, x17]
    // 0xbf8158: StoreField: r0->field_5b = r1
    //     0xbf8158: stur            w1, [x0, #0x5b]
    // 0xbf815c: r17 = -288
    //     0xbf815c: mov             x17, #-0x120
    // 0xbf8160: ldr             x1, [fp, x17]
    // 0xbf8164: StoreField: r0->field_5f = r1
    //     0xbf8164: stur            w1, [x0, #0x5f]
    // 0xbf8168: r17 = -296
    //     0xbf8168: mov             x17, #-0x128
    // 0xbf816c: ldr             x1, [fp, x17]
    // 0xbf8170: StoreField: r0->field_63 = r1
    //     0xbf8170: stur            w1, [x0, #0x63]
    // 0xbf8174: ldur            x1, [fp, #-0xb8]
    // 0xbf8178: StoreField: r0->field_67 = r1
    //     0xbf8178: stur            w1, [x0, #0x67]
    // 0xbf817c: ldur            x1, [fp, #-0xc0]
    // 0xbf8180: StoreField: r0->field_6b = r1
    //     0xbf8180: stur            w1, [x0, #0x6b]
    // 0xbf8184: r17 = -304
    //     0xbf8184: mov             x17, #-0x130
    // 0xbf8188: ldr             x1, [fp, x17]
    // 0xbf818c: StoreField: r0->field_6f = r1
    //     0xbf818c: stur            w1, [x0, #0x6f]
    // 0xbf8190: ldur            x1, [fp, #-0xf8]
    // 0xbf8194: StoreField: r0->field_73 = r1
    //     0xbf8194: stur            w1, [x0, #0x73]
    // 0xbf8198: ldur            x1, [fp, #-0xe0]
    // 0xbf819c: StoreField: r0->field_77 = r1
    //     0xbf819c: stur            w1, [x0, #0x77]
    // 0xbf81a0: ldur            x1, [fp, #-0x28]
    // 0xbf81a4: StoreField: r0->field_7b = r1
    //     0xbf81a4: stur            w1, [x0, #0x7b]
    // 0xbf81a8: ldur            x1, [fp, #-0x30]
    // 0xbf81ac: StoreField: r0->field_83 = r1
    //     0xbf81ac: stur            w1, [x0, #0x83]
    // 0xbf81b0: ldur            x1, [fp, #-0x50]
    // 0xbf81b4: StoreField: r0->field_87 = r1
    //     0xbf81b4: stur            w1, [x0, #0x87]
    // 0xbf81b8: ldur            x1, [fp, #-8]
    // 0xbf81bc: StoreField: r0->field_7f = r1
    //     0xbf81bc: stur            w1, [x0, #0x7f]
    // 0xbf81c0: LeaveFrame
    //     0xbf81c0: mov             SP, fp
    //     0xbf81c4: ldp             fp, lr, [SP], #0x10
    // 0xbf81c8: ret
    //     0xbf81c8: ret             
    // 0xbf81cc: r0 = StackOverflowSharedWithFPURegs()
    //     0xbf81cc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xbf81d0: b               #0xbf7638
    // 0xbf81d4: SaveReg d1
    //     0xbf81d4: str             q1, [SP, #-0x10]!
    // 0xbf81d8: stp             x3, x4, [SP, #-0x10]!
    // 0xbf81dc: stp             x1, x2, [SP, #-0x10]!
    // 0xbf81e0: SaveReg r0
    //     0xbf81e0: str             x0, [SP, #-8]!
    // 0xbf81e4: r0 = AllocateDouble()
    //     0xbf81e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf81e8: mov             x5, x0
    // 0xbf81ec: RestoreReg r0
    //     0xbf81ec: ldr             x0, [SP], #8
    // 0xbf81f0: ldp             x1, x2, [SP], #0x10
    // 0xbf81f4: ldp             x3, x4, [SP], #0x10
    // 0xbf81f8: RestoreReg d1
    //     0xbf81f8: ldr             q1, [SP], #0x10
    // 0xbf81fc: b               #0xbf76b0
    // 0xbf8200: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8200: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8204: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8208: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8208: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf820c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf820c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8210: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8210: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8214: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8214: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf821c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf821c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbf8224: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbf8224: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ ==(/* No info */) {
    // ** addr: 0xc85884, size: 0x1dec
    // 0xc85884: EnterFrame
    //     0xc85884: stp             fp, lr, [SP, #-0x10]!
    //     0xc85888: mov             fp, SP
    // 0xc8588c: AllocStack(0x78)
    //     0xc8588c: sub             SP, SP, #0x78
    // 0xc85890: CheckStackOverflow
    //     0xc85890: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc85894: cmp             SP, x16
    //     0xc85898: b.ls            #0xc87668
    // 0xc8589c: ldr             x1, [fp, #0x10]
    // 0xc858a0: cmp             w1, NULL
    // 0xc858a4: b.ne            #0xc858b8
    // 0xc858a8: r0 = false
    //     0xc858a8: add             x0, NULL, #0x30  ; false
    // 0xc858ac: LeaveFrame
    //     0xc858ac: mov             SP, fp
    //     0xc858b0: ldp             fp, lr, [SP], #0x10
    // 0xc858b4: ret
    //     0xc858b4: ret             
    // 0xc858b8: ldr             x2, [fp, #0x18]
    // 0xc858bc: cmp             w2, w1
    // 0xc858c0: b.ne            #0xc858d4
    // 0xc858c4: r0 = true
    //     0xc858c4: add             x0, NULL, #0x20  ; true
    // 0xc858c8: LeaveFrame
    //     0xc858c8: mov             SP, fp
    //     0xc858cc: ldp             fp, lr, [SP], #0x10
    // 0xc858d0: ret
    //     0xc858d0: ret             
    // 0xc858d4: r0 = 59
    //     0xc858d4: mov             x0, #0x3b
    // 0xc858d8: branchIfSmi(r1, 0xc858e4)
    //     0xc858d8: tbz             w1, #0, #0xc858e4
    // 0xc858dc: r0 = LoadClassIdInstr(r1)
    //     0xc858dc: ldur            x0, [x1, #-1]
    //     0xc858e0: ubfx            x0, x0, #0xc, #0x14
    // 0xc858e4: SaveReg r1
    //     0xc858e4: str             x1, [SP, #-8]!
    // 0xc858e8: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc858e8: mov             x17, #0x57c5
    //     0xc858ec: add             lr, x0, x17
    //     0xc858f0: ldr             lr, [x21, lr, lsl #3]
    //     0xc858f4: blr             lr
    // 0xc858f8: add             SP, SP, #8
    // 0xc858fc: r1 = LoadClassIdInstr(r0)
    //     0xc858fc: ldur            x1, [x0, #-1]
    //     0xc85900: ubfx            x1, x1, #0xc, #0x14
    // 0xc85904: r16 = ColorScheme
    //     0xc85904: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3e0] Type: ColorScheme
    //     0xc85908: ldr             x16, [x16, #0x3e0]
    // 0xc8590c: stp             x16, x0, [SP, #-0x10]!
    // 0xc85910: mov             x0, x1
    // 0xc85914: mov             lr, x0
    // 0xc85918: ldr             lr, [x21, lr, lsl #3]
    // 0xc8591c: blr             lr
    // 0xc85920: add             SP, SP, #0x10
    // 0xc85924: tbz             w0, #4, #0xc85938
    // 0xc85928: r0 = false
    //     0xc85928: add             x0, NULL, #0x30  ; false
    // 0xc8592c: LeaveFrame
    //     0xc8592c: mov             SP, fp
    //     0xc85930: ldp             fp, lr, [SP], #0x10
    // 0xc85934: ret
    //     0xc85934: ret             
    // 0xc85938: ldr             x0, [fp, #0x10]
    // 0xc8593c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8593c: mov             x1, #0x76
    //     0xc85940: tbz             w0, #0, #0xc85950
    //     0xc85944: ldur            x1, [x0, #-1]
    //     0xc85948: ubfx            x1, x1, #0xc, #0x14
    //     0xc8594c: lsl             x1, x1, #1
    // 0xc85950: r17 = 5628
    //     0xc85950: mov             x17, #0x15fc
    // 0xc85954: cmp             w1, w17
    // 0xc85958: b.ne            #0xc87658
    // 0xc8595c: ldr             x1, [fp, #0x18]
    // 0xc85960: LoadField: r2 = r0->field_7
    //     0xc85960: ldur            w2, [x0, #7]
    // 0xc85964: DecompressPointer r2
    //     0xc85964: add             x2, x2, HEAP, lsl #32
    // 0xc85968: LoadField: r3 = r1->field_7
    //     0xc85968: ldur            w3, [x1, #7]
    // 0xc8596c: DecompressPointer r3
    //     0xc8596c: add             x3, x3, HEAP, lsl #32
    // 0xc85970: cmp             w2, w3
    // 0xc85974: b.ne            #0xc87658
    // 0xc85978: LoadField: r2 = r0->field_b
    //     0xc85978: ldur            w2, [x0, #0xb]
    // 0xc8597c: DecompressPointer r2
    //     0xc8597c: add             x2, x2, HEAP, lsl #32
    // 0xc85980: stur            x2, [fp, #-0x18]
    // 0xc85984: LoadField: r3 = r1->field_b
    //     0xc85984: ldur            w3, [x1, #0xb]
    // 0xc85988: DecompressPointer r3
    //     0xc85988: add             x3, x3, HEAP, lsl #32
    // 0xc8598c: stur            x3, [fp, #-0x10]
    // 0xc85990: r4 = LoadClassIdInstr(r2)
    //     0xc85990: ldur            x4, [x2, #-1]
    //     0xc85994: ubfx            x4, x4, #0xc, #0x14
    // 0xc85998: lsl             x4, x4, #1
    // 0xc8599c: stur            x4, [fp, #-8]
    // 0xc859a0: r17 = 10114
    //     0xc859a0: mov             x17, #0x2782
    // 0xc859a4: cmp             w4, w17
    // 0xc859a8: b.eq            #0xc859b8
    // 0xc859ac: r17 = 10118
    //     0xc859ac: mov             x17, #0x2786
    // 0xc859b0: cmp             w4, w17
    // 0xc859b4: b.ne            #0xc85a90
    // 0xc859b8: cmp             w2, w3
    // 0xc859bc: b.eq            #0xc85ac0
    // 0xc859c0: stp             x2, x3, [SP, #-0x10]!
    // 0xc859c4: r0 = _haveSameRuntimeType()
    //     0xc859c4: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc859c8: add             SP, SP, #0x10
    // 0xc859cc: tbnz            w0, #4, #0xc87658
    // 0xc859d0: ldur            x1, [fp, #-0x10]
    // 0xc859d4: r0 = LoadClassIdInstr(r1)
    //     0xc859d4: ldur            x0, [x1, #-1]
    //     0xc859d8: ubfx            x0, x0, #0xc, #0x14
    // 0xc859dc: lsl             x0, x0, #1
    // 0xc859e0: r17 = 10124
    //     0xc859e0: mov             x17, #0x278c
    // 0xc859e4: cmp             w0, w17
    // 0xc859e8: b.gt            #0xc859f8
    // 0xc859ec: r17 = 10122
    //     0xc859ec: mov             x17, #0x278a
    // 0xc859f0: cmp             w0, w17
    // 0xc859f4: b.ge            #0xc85a10
    // 0xc859f8: r17 = 10114
    //     0xc859f8: mov             x17, #0x2782
    // 0xc859fc: cmp             w0, w17
    // 0xc85a00: b.eq            #0xc85a10
    // 0xc85a04: r17 = 10118
    //     0xc85a04: mov             x17, #0x2786
    // 0xc85a08: cmp             w0, w17
    // 0xc85a0c: b.ne            #0xc85a1c
    // 0xc85a10: LoadField: r0 = r1->field_7
    //     0xc85a10: ldur            x0, [x1, #7]
    // 0xc85a14: mov             x2, x0
    // 0xc85a18: b               #0xc85a28
    // 0xc85a1c: LoadField: r0 = r1->field_f
    //     0xc85a1c: ldur            w0, [x1, #0xf]
    // 0xc85a20: DecompressPointer r0
    //     0xc85a20: add             x0, x0, HEAP, lsl #32
    // 0xc85a24: LoadField: r2 = r0->field_7
    //     0xc85a24: ldur            x2, [x0, #7]
    // 0xc85a28: ldur            x0, [fp, #-8]
    // 0xc85a2c: r17 = 10124
    //     0xc85a2c: mov             x17, #0x278c
    // 0xc85a30: cmp             w0, w17
    // 0xc85a34: b.gt            #0xc85a44
    // 0xc85a38: r17 = 10122
    //     0xc85a38: mov             x17, #0x278a
    // 0xc85a3c: cmp             w0, w17
    // 0xc85a40: b.ge            #0xc85a5c
    // 0xc85a44: r17 = 10114
    //     0xc85a44: mov             x17, #0x2782
    // 0xc85a48: cmp             w0, w17
    // 0xc85a4c: b.eq            #0xc85a5c
    // 0xc85a50: r17 = 10118
    //     0xc85a50: mov             x17, #0x2786
    // 0xc85a54: cmp             w0, w17
    // 0xc85a58: b.ne            #0xc85a68
    // 0xc85a5c: ldur            x3, [fp, #-0x18]
    // 0xc85a60: LoadField: r0 = r3->field_7
    //     0xc85a60: ldur            x0, [x3, #7]
    // 0xc85a64: b               #0xc85a7c
    // 0xc85a68: ldur            x3, [fp, #-0x18]
    // 0xc85a6c: LoadField: r0 = r3->field_f
    //     0xc85a6c: ldur            w0, [x3, #0xf]
    // 0xc85a70: DecompressPointer r0
    //     0xc85a70: add             x0, x0, HEAP, lsl #32
    // 0xc85a74: LoadField: r4 = r0->field_7
    //     0xc85a74: ldur            x4, [x0, #7]
    // 0xc85a78: mov             x0, x4
    // 0xc85a7c: cmp             x2, x0
    // 0xc85a80: b.ne            #0xc87658
    // 0xc85a84: ldr             x1, [fp, #0x18]
    // 0xc85a88: ldr             x0, [fp, #0x10]
    // 0xc85a8c: b               #0xc85ac0
    // 0xc85a90: mov             x1, x3
    // 0xc85a94: mov             x3, x2
    // 0xc85a98: r0 = LoadClassIdInstr(r3)
    //     0xc85a98: ldur            x0, [x3, #-1]
    //     0xc85a9c: ubfx            x0, x0, #0xc, #0x14
    // 0xc85aa0: stp             x1, x3, [SP, #-0x10]!
    // 0xc85aa4: mov             lr, x0
    // 0xc85aa8: ldr             lr, [x21, lr, lsl #3]
    // 0xc85aac: blr             lr
    // 0xc85ab0: add             SP, SP, #0x10
    // 0xc85ab4: tbnz            w0, #4, #0xc87658
    // 0xc85ab8: ldr             x1, [fp, #0x18]
    // 0xc85abc: ldr             x0, [fp, #0x10]
    // 0xc85ac0: LoadField: r2 = r0->field_f
    //     0xc85ac0: ldur            w2, [x0, #0xf]
    // 0xc85ac4: DecompressPointer r2
    //     0xc85ac4: add             x2, x2, HEAP, lsl #32
    // 0xc85ac8: stur            x2, [fp, #-0x20]
    // 0xc85acc: LoadField: r3 = r1->field_f
    //     0xc85acc: ldur            w3, [x1, #0xf]
    // 0xc85ad0: DecompressPointer r3
    //     0xc85ad0: add             x3, x3, HEAP, lsl #32
    // 0xc85ad4: stur            x3, [fp, #-8]
    // 0xc85ad8: cmp             w2, w3
    // 0xc85adc: b.ne            #0xc85af4
    // 0xc85ae0: mov             x16, x2
    // 0xc85ae4: mov             x2, x0
    // 0xc85ae8: mov             x0, x16
    // 0xc85aec: mov             x1, x3
    // 0xc85af0: b               #0xc85b30
    // 0xc85af4: r16 = Color
    //     0xc85af4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc85af8: ldr             x16, [x16, #0xf18]
    // 0xc85afc: r30 = Color
    //     0xc85afc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc85b00: ldr             lr, [lr, #0xf18]
    // 0xc85b04: stp             lr, x16, [SP, #-0x10]!
    // 0xc85b08: r0 = ==()
    //     0xc85b08: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc85b0c: add             SP, SP, #0x10
    // 0xc85b10: tbnz            w0, #4, #0xc87658
    // 0xc85b14: ldur            x0, [fp, #-0x20]
    // 0xc85b18: ldur            x1, [fp, #-8]
    // 0xc85b1c: LoadField: r2 = r1->field_7
    //     0xc85b1c: ldur            x2, [x1, #7]
    // 0xc85b20: LoadField: r3 = r0->field_7
    //     0xc85b20: ldur            x3, [x0, #7]
    // 0xc85b24: cmp             x2, x3
    // 0xc85b28: b.ne            #0xc87658
    // 0xc85b2c: ldr             x2, [fp, #0x10]
    // 0xc85b30: LoadField: r3 = r2->field_13
    //     0xc85b30: ldur            w3, [x2, #0x13]
    // 0xc85b34: DecompressPointer r3
    //     0xc85b34: add             x3, x3, HEAP, lsl #32
    // 0xc85b38: cmp             w3, NULL
    // 0xc85b3c: b.ne            #0xc85b48
    // 0xc85b40: ldur            x4, [fp, #-0x18]
    // 0xc85b44: b               #0xc85b4c
    // 0xc85b48: mov             x4, x3
    // 0xc85b4c: ldr             x3, [fp, #0x18]
    // 0xc85b50: stur            x4, [fp, #-0x38]
    // 0xc85b54: LoadField: r5 = r3->field_13
    //     0xc85b54: ldur            w5, [x3, #0x13]
    // 0xc85b58: DecompressPointer r5
    //     0xc85b58: add             x5, x5, HEAP, lsl #32
    // 0xc85b5c: cmp             w5, NULL
    // 0xc85b60: b.ne            #0xc85b68
    // 0xc85b64: ldur            x5, [fp, #-0x10]
    // 0xc85b68: stur            x5, [fp, #-0x30]
    // 0xc85b6c: r6 = LoadClassIdInstr(r4)
    //     0xc85b6c: ldur            x6, [x4, #-1]
    //     0xc85b70: ubfx            x6, x6, #0xc, #0x14
    // 0xc85b74: lsl             x6, x6, #1
    // 0xc85b78: stur            x6, [fp, #-0x28]
    // 0xc85b7c: r17 = 10114
    //     0xc85b7c: mov             x17, #0x2782
    // 0xc85b80: cmp             w6, w17
    // 0xc85b84: b.eq            #0xc85b94
    // 0xc85b88: r17 = 10118
    //     0xc85b88: mov             x17, #0x2786
    // 0xc85b8c: cmp             w6, w17
    // 0xc85b90: b.ne            #0xc85c70
    // 0xc85b94: cmp             w4, w5
    // 0xc85b98: b.ne            #0xc85ba4
    // 0xc85b9c: mov             x0, x2
    // 0xc85ba0: b               #0xc85ca0
    // 0xc85ba4: stp             x4, x5, [SP, #-0x10]!
    // 0xc85ba8: r0 = _haveSameRuntimeType()
    //     0xc85ba8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc85bac: add             SP, SP, #0x10
    // 0xc85bb0: tbnz            w0, #4, #0xc87658
    // 0xc85bb4: ldur            x0, [fp, #-0x30]
    // 0xc85bb8: r1 = LoadClassIdInstr(r0)
    //     0xc85bb8: ldur            x1, [x0, #-1]
    //     0xc85bbc: ubfx            x1, x1, #0xc, #0x14
    // 0xc85bc0: lsl             x1, x1, #1
    // 0xc85bc4: r17 = 10124
    //     0xc85bc4: mov             x17, #0x278c
    // 0xc85bc8: cmp             w1, w17
    // 0xc85bcc: b.gt            #0xc85bdc
    // 0xc85bd0: r17 = 10122
    //     0xc85bd0: mov             x17, #0x278a
    // 0xc85bd4: cmp             w1, w17
    // 0xc85bd8: b.ge            #0xc85bf4
    // 0xc85bdc: r17 = 10114
    //     0xc85bdc: mov             x17, #0x2782
    // 0xc85be0: cmp             w1, w17
    // 0xc85be4: b.eq            #0xc85bf4
    // 0xc85be8: r17 = 10118
    //     0xc85be8: mov             x17, #0x2786
    // 0xc85bec: cmp             w1, w17
    // 0xc85bf0: b.ne            #0xc85bfc
    // 0xc85bf4: LoadField: r1 = r0->field_7
    //     0xc85bf4: ldur            x1, [x0, #7]
    // 0xc85bf8: b               #0xc85c0c
    // 0xc85bfc: LoadField: r1 = r0->field_f
    //     0xc85bfc: ldur            w1, [x0, #0xf]
    // 0xc85c00: DecompressPointer r1
    //     0xc85c00: add             x1, x1, HEAP, lsl #32
    // 0xc85c04: LoadField: r0 = r1->field_7
    //     0xc85c04: ldur            x0, [x1, #7]
    // 0xc85c08: mov             x1, x0
    // 0xc85c0c: ldur            x0, [fp, #-0x28]
    // 0xc85c10: r17 = 10124
    //     0xc85c10: mov             x17, #0x278c
    // 0xc85c14: cmp             w0, w17
    // 0xc85c18: b.gt            #0xc85c28
    // 0xc85c1c: r17 = 10122
    //     0xc85c1c: mov             x17, #0x278a
    // 0xc85c20: cmp             w0, w17
    // 0xc85c24: b.ge            #0xc85c40
    // 0xc85c28: r17 = 10114
    //     0xc85c28: mov             x17, #0x2782
    // 0xc85c2c: cmp             w0, w17
    // 0xc85c30: b.eq            #0xc85c40
    // 0xc85c34: r17 = 10118
    //     0xc85c34: mov             x17, #0x2786
    // 0xc85c38: cmp             w0, w17
    // 0xc85c3c: b.ne            #0xc85c4c
    // 0xc85c40: ldur            x2, [fp, #-0x38]
    // 0xc85c44: LoadField: r0 = r2->field_7
    //     0xc85c44: ldur            x0, [x2, #7]
    // 0xc85c48: b               #0xc85c60
    // 0xc85c4c: ldur            x2, [fp, #-0x38]
    // 0xc85c50: LoadField: r0 = r2->field_f
    //     0xc85c50: ldur            w0, [x2, #0xf]
    // 0xc85c54: DecompressPointer r0
    //     0xc85c54: add             x0, x0, HEAP, lsl #32
    // 0xc85c58: LoadField: r2 = r0->field_7
    //     0xc85c58: ldur            x2, [x0, #7]
    // 0xc85c5c: mov             x0, x2
    // 0xc85c60: cmp             x1, x0
    // 0xc85c64: b.ne            #0xc87658
    // 0xc85c68: ldr             x0, [fp, #0x10]
    // 0xc85c6c: b               #0xc85ca0
    // 0xc85c70: mov             x2, x4
    // 0xc85c74: mov             x0, x5
    // 0xc85c78: r1 = LoadClassIdInstr(r2)
    //     0xc85c78: ldur            x1, [x2, #-1]
    //     0xc85c7c: ubfx            x1, x1, #0xc, #0x14
    // 0xc85c80: stp             x0, x2, [SP, #-0x10]!
    // 0xc85c84: mov             x0, x1
    // 0xc85c88: mov             lr, x0
    // 0xc85c8c: ldr             lr, [x21, lr, lsl #3]
    // 0xc85c90: blr             lr
    // 0xc85c94: add             SP, SP, #0x10
    // 0xc85c98: tbnz            w0, #4, #0xc87658
    // 0xc85c9c: ldr             x0, [fp, #0x10]
    // 0xc85ca0: LoadField: r1 = r0->field_17
    //     0xc85ca0: ldur            w1, [x0, #0x17]
    // 0xc85ca4: DecompressPointer r1
    //     0xc85ca4: add             x1, x1, HEAP, lsl #32
    // 0xc85ca8: cmp             w1, NULL
    // 0xc85cac: b.ne            #0xc85cb8
    // 0xc85cb0: ldur            x2, [fp, #-0x20]
    // 0xc85cb4: b               #0xc85cbc
    // 0xc85cb8: mov             x2, x1
    // 0xc85cbc: ldr             x1, [fp, #0x18]
    // 0xc85cc0: stur            x2, [fp, #-0x30]
    // 0xc85cc4: LoadField: r3 = r1->field_17
    //     0xc85cc4: ldur            w3, [x1, #0x17]
    // 0xc85cc8: DecompressPointer r3
    //     0xc85cc8: add             x3, x3, HEAP, lsl #32
    // 0xc85ccc: cmp             w3, NULL
    // 0xc85cd0: b.ne            #0xc85cd8
    // 0xc85cd4: ldur            x3, [fp, #-8]
    // 0xc85cd8: stur            x3, [fp, #-0x28]
    // 0xc85cdc: cmp             w2, w3
    // 0xc85ce0: b.eq            #0xc85d24
    // 0xc85ce4: r16 = Color
    //     0xc85ce4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc85ce8: ldr             x16, [x16, #0xf18]
    // 0xc85cec: r30 = Color
    //     0xc85cec: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc85cf0: ldr             lr, [lr, #0xf18]
    // 0xc85cf4: stp             lr, x16, [SP, #-0x10]!
    // 0xc85cf8: r0 = ==()
    //     0xc85cf8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc85cfc: add             SP, SP, #0x10
    // 0xc85d00: tbnz            w0, #4, #0xc87658
    // 0xc85d04: ldur            x0, [fp, #-0x30]
    // 0xc85d08: ldur            x1, [fp, #-0x28]
    // 0xc85d0c: LoadField: r2 = r1->field_7
    //     0xc85d0c: ldur            x2, [x1, #7]
    // 0xc85d10: LoadField: r1 = r0->field_7
    //     0xc85d10: ldur            x1, [x0, #7]
    // 0xc85d14: cmp             x2, x1
    // 0xc85d18: b.ne            #0xc87658
    // 0xc85d1c: ldr             x1, [fp, #0x18]
    // 0xc85d20: ldr             x0, [fp, #0x10]
    // 0xc85d24: LoadField: r2 = r0->field_1b
    //     0xc85d24: ldur            w2, [x0, #0x1b]
    // 0xc85d28: DecompressPointer r2
    //     0xc85d28: add             x2, x2, HEAP, lsl #32
    // 0xc85d2c: stur            x2, [fp, #-0x38]
    // 0xc85d30: LoadField: r3 = r1->field_1b
    //     0xc85d30: ldur            w3, [x1, #0x1b]
    // 0xc85d34: DecompressPointer r3
    //     0xc85d34: add             x3, x3, HEAP, lsl #32
    // 0xc85d38: stur            x3, [fp, #-0x30]
    // 0xc85d3c: r4 = LoadClassIdInstr(r2)
    //     0xc85d3c: ldur            x4, [x2, #-1]
    //     0xc85d40: ubfx            x4, x4, #0xc, #0x14
    // 0xc85d44: lsl             x4, x4, #1
    // 0xc85d48: stur            x4, [fp, #-0x28]
    // 0xc85d4c: r17 = 10114
    //     0xc85d4c: mov             x17, #0x2782
    // 0xc85d50: cmp             w4, w17
    // 0xc85d54: b.eq            #0xc85d64
    // 0xc85d58: r17 = 10118
    //     0xc85d58: mov             x17, #0x2786
    // 0xc85d5c: cmp             w4, w17
    // 0xc85d60: b.ne            #0xc85e3c
    // 0xc85d64: cmp             w2, w3
    // 0xc85d68: b.eq            #0xc85e6c
    // 0xc85d6c: stp             x2, x3, [SP, #-0x10]!
    // 0xc85d70: r0 = _haveSameRuntimeType()
    //     0xc85d70: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc85d74: add             SP, SP, #0x10
    // 0xc85d78: tbnz            w0, #4, #0xc87658
    // 0xc85d7c: ldur            x1, [fp, #-0x30]
    // 0xc85d80: r0 = LoadClassIdInstr(r1)
    //     0xc85d80: ldur            x0, [x1, #-1]
    //     0xc85d84: ubfx            x0, x0, #0xc, #0x14
    // 0xc85d88: lsl             x0, x0, #1
    // 0xc85d8c: r17 = 10124
    //     0xc85d8c: mov             x17, #0x278c
    // 0xc85d90: cmp             w0, w17
    // 0xc85d94: b.gt            #0xc85da4
    // 0xc85d98: r17 = 10122
    //     0xc85d98: mov             x17, #0x278a
    // 0xc85d9c: cmp             w0, w17
    // 0xc85da0: b.ge            #0xc85dbc
    // 0xc85da4: r17 = 10114
    //     0xc85da4: mov             x17, #0x2782
    // 0xc85da8: cmp             w0, w17
    // 0xc85dac: b.eq            #0xc85dbc
    // 0xc85db0: r17 = 10118
    //     0xc85db0: mov             x17, #0x2786
    // 0xc85db4: cmp             w0, w17
    // 0xc85db8: b.ne            #0xc85dc8
    // 0xc85dbc: LoadField: r0 = r1->field_7
    //     0xc85dbc: ldur            x0, [x1, #7]
    // 0xc85dc0: mov             x2, x0
    // 0xc85dc4: b               #0xc85dd4
    // 0xc85dc8: LoadField: r0 = r1->field_f
    //     0xc85dc8: ldur            w0, [x1, #0xf]
    // 0xc85dcc: DecompressPointer r0
    //     0xc85dcc: add             x0, x0, HEAP, lsl #32
    // 0xc85dd0: LoadField: r2 = r0->field_7
    //     0xc85dd0: ldur            x2, [x0, #7]
    // 0xc85dd4: ldur            x0, [fp, #-0x28]
    // 0xc85dd8: r17 = 10124
    //     0xc85dd8: mov             x17, #0x278c
    // 0xc85ddc: cmp             w0, w17
    // 0xc85de0: b.gt            #0xc85df0
    // 0xc85de4: r17 = 10122
    //     0xc85de4: mov             x17, #0x278a
    // 0xc85de8: cmp             w0, w17
    // 0xc85dec: b.ge            #0xc85e08
    // 0xc85df0: r17 = 10114
    //     0xc85df0: mov             x17, #0x2782
    // 0xc85df4: cmp             w0, w17
    // 0xc85df8: b.eq            #0xc85e08
    // 0xc85dfc: r17 = 10118
    //     0xc85dfc: mov             x17, #0x2786
    // 0xc85e00: cmp             w0, w17
    // 0xc85e04: b.ne            #0xc85e14
    // 0xc85e08: ldur            x3, [fp, #-0x38]
    // 0xc85e0c: LoadField: r0 = r3->field_7
    //     0xc85e0c: ldur            x0, [x3, #7]
    // 0xc85e10: b               #0xc85e28
    // 0xc85e14: ldur            x3, [fp, #-0x38]
    // 0xc85e18: LoadField: r0 = r3->field_f
    //     0xc85e18: ldur            w0, [x3, #0xf]
    // 0xc85e1c: DecompressPointer r0
    //     0xc85e1c: add             x0, x0, HEAP, lsl #32
    // 0xc85e20: LoadField: r4 = r0->field_7
    //     0xc85e20: ldur            x4, [x0, #7]
    // 0xc85e24: mov             x0, x4
    // 0xc85e28: cmp             x2, x0
    // 0xc85e2c: b.ne            #0xc87658
    // 0xc85e30: ldr             x1, [fp, #0x18]
    // 0xc85e34: ldr             x0, [fp, #0x10]
    // 0xc85e38: b               #0xc85e6c
    // 0xc85e3c: mov             x1, x3
    // 0xc85e40: mov             x3, x2
    // 0xc85e44: r0 = LoadClassIdInstr(r3)
    //     0xc85e44: ldur            x0, [x3, #-1]
    //     0xc85e48: ubfx            x0, x0, #0xc, #0x14
    // 0xc85e4c: stp             x1, x3, [SP, #-0x10]!
    // 0xc85e50: mov             lr, x0
    // 0xc85e54: ldr             lr, [x21, lr, lsl #3]
    // 0xc85e58: blr             lr
    // 0xc85e5c: add             SP, SP, #0x10
    // 0xc85e60: tbnz            w0, #4, #0xc87658
    // 0xc85e64: ldr             x1, [fp, #0x18]
    // 0xc85e68: ldr             x0, [fp, #0x10]
    // 0xc85e6c: LoadField: r2 = r0->field_1f
    //     0xc85e6c: ldur            w2, [x0, #0x1f]
    // 0xc85e70: DecompressPointer r2
    //     0xc85e70: add             x2, x2, HEAP, lsl #32
    // 0xc85e74: stur            x2, [fp, #-0x40]
    // 0xc85e78: LoadField: r3 = r1->field_1f
    //     0xc85e78: ldur            w3, [x1, #0x1f]
    // 0xc85e7c: DecompressPointer r3
    //     0xc85e7c: add             x3, x3, HEAP, lsl #32
    // 0xc85e80: stur            x3, [fp, #-0x28]
    // 0xc85e84: cmp             w2, w3
    // 0xc85e88: b.ne            #0xc85ea0
    // 0xc85e8c: mov             x16, x2
    // 0xc85e90: mov             x2, x0
    // 0xc85e94: mov             x0, x16
    // 0xc85e98: mov             x1, x3
    // 0xc85e9c: b               #0xc85edc
    // 0xc85ea0: r16 = Color
    //     0xc85ea0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc85ea4: ldr             x16, [x16, #0xf18]
    // 0xc85ea8: r30 = Color
    //     0xc85ea8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc85eac: ldr             lr, [lr, #0xf18]
    // 0xc85eb0: stp             lr, x16, [SP, #-0x10]!
    // 0xc85eb4: r0 = ==()
    //     0xc85eb4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc85eb8: add             SP, SP, #0x10
    // 0xc85ebc: tbnz            w0, #4, #0xc87658
    // 0xc85ec0: ldur            x0, [fp, #-0x40]
    // 0xc85ec4: ldur            x1, [fp, #-0x28]
    // 0xc85ec8: LoadField: r2 = r1->field_7
    //     0xc85ec8: ldur            x2, [x1, #7]
    // 0xc85ecc: LoadField: r3 = r0->field_7
    //     0xc85ecc: ldur            x3, [x0, #7]
    // 0xc85ed0: cmp             x2, x3
    // 0xc85ed4: b.ne            #0xc87658
    // 0xc85ed8: ldr             x2, [fp, #0x10]
    // 0xc85edc: LoadField: r3 = r2->field_23
    //     0xc85edc: ldur            w3, [x2, #0x23]
    // 0xc85ee0: DecompressPointer r3
    //     0xc85ee0: add             x3, x3, HEAP, lsl #32
    // 0xc85ee4: cmp             w3, NULL
    // 0xc85ee8: b.ne            #0xc85ef4
    // 0xc85eec: ldur            x4, [fp, #-0x38]
    // 0xc85ef0: b               #0xc85ef8
    // 0xc85ef4: mov             x4, x3
    // 0xc85ef8: ldr             x3, [fp, #0x18]
    // 0xc85efc: stur            x4, [fp, #-0x58]
    // 0xc85f00: LoadField: r5 = r3->field_23
    //     0xc85f00: ldur            w5, [x3, #0x23]
    // 0xc85f04: DecompressPointer r5
    //     0xc85f04: add             x5, x5, HEAP, lsl #32
    // 0xc85f08: cmp             w5, NULL
    // 0xc85f0c: b.ne            #0xc85f14
    // 0xc85f10: ldur            x5, [fp, #-0x30]
    // 0xc85f14: stur            x5, [fp, #-0x50]
    // 0xc85f18: r6 = LoadClassIdInstr(r4)
    //     0xc85f18: ldur            x6, [x4, #-1]
    //     0xc85f1c: ubfx            x6, x6, #0xc, #0x14
    // 0xc85f20: lsl             x6, x6, #1
    // 0xc85f24: stur            x6, [fp, #-0x48]
    // 0xc85f28: r17 = 10114
    //     0xc85f28: mov             x17, #0x2782
    // 0xc85f2c: cmp             w6, w17
    // 0xc85f30: b.eq            #0xc85f40
    // 0xc85f34: r17 = 10118
    //     0xc85f34: mov             x17, #0x2786
    // 0xc85f38: cmp             w6, w17
    // 0xc85f3c: b.ne            #0xc8601c
    // 0xc85f40: cmp             w4, w5
    // 0xc85f44: b.ne            #0xc85f50
    // 0xc85f48: mov             x0, x2
    // 0xc85f4c: b               #0xc8604c
    // 0xc85f50: stp             x4, x5, [SP, #-0x10]!
    // 0xc85f54: r0 = _haveSameRuntimeType()
    //     0xc85f54: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc85f58: add             SP, SP, #0x10
    // 0xc85f5c: tbnz            w0, #4, #0xc87658
    // 0xc85f60: ldur            x0, [fp, #-0x50]
    // 0xc85f64: r1 = LoadClassIdInstr(r0)
    //     0xc85f64: ldur            x1, [x0, #-1]
    //     0xc85f68: ubfx            x1, x1, #0xc, #0x14
    // 0xc85f6c: lsl             x1, x1, #1
    // 0xc85f70: r17 = 10124
    //     0xc85f70: mov             x17, #0x278c
    // 0xc85f74: cmp             w1, w17
    // 0xc85f78: b.gt            #0xc85f88
    // 0xc85f7c: r17 = 10122
    //     0xc85f7c: mov             x17, #0x278a
    // 0xc85f80: cmp             w1, w17
    // 0xc85f84: b.ge            #0xc85fa0
    // 0xc85f88: r17 = 10114
    //     0xc85f88: mov             x17, #0x2782
    // 0xc85f8c: cmp             w1, w17
    // 0xc85f90: b.eq            #0xc85fa0
    // 0xc85f94: r17 = 10118
    //     0xc85f94: mov             x17, #0x2786
    // 0xc85f98: cmp             w1, w17
    // 0xc85f9c: b.ne            #0xc85fa8
    // 0xc85fa0: LoadField: r1 = r0->field_7
    //     0xc85fa0: ldur            x1, [x0, #7]
    // 0xc85fa4: b               #0xc85fb8
    // 0xc85fa8: LoadField: r1 = r0->field_f
    //     0xc85fa8: ldur            w1, [x0, #0xf]
    // 0xc85fac: DecompressPointer r1
    //     0xc85fac: add             x1, x1, HEAP, lsl #32
    // 0xc85fb0: LoadField: r0 = r1->field_7
    //     0xc85fb0: ldur            x0, [x1, #7]
    // 0xc85fb4: mov             x1, x0
    // 0xc85fb8: ldur            x0, [fp, #-0x48]
    // 0xc85fbc: r17 = 10124
    //     0xc85fbc: mov             x17, #0x278c
    // 0xc85fc0: cmp             w0, w17
    // 0xc85fc4: b.gt            #0xc85fd4
    // 0xc85fc8: r17 = 10122
    //     0xc85fc8: mov             x17, #0x278a
    // 0xc85fcc: cmp             w0, w17
    // 0xc85fd0: b.ge            #0xc85fec
    // 0xc85fd4: r17 = 10114
    //     0xc85fd4: mov             x17, #0x2782
    // 0xc85fd8: cmp             w0, w17
    // 0xc85fdc: b.eq            #0xc85fec
    // 0xc85fe0: r17 = 10118
    //     0xc85fe0: mov             x17, #0x2786
    // 0xc85fe4: cmp             w0, w17
    // 0xc85fe8: b.ne            #0xc85ff8
    // 0xc85fec: ldur            x2, [fp, #-0x58]
    // 0xc85ff0: LoadField: r0 = r2->field_7
    //     0xc85ff0: ldur            x0, [x2, #7]
    // 0xc85ff4: b               #0xc8600c
    // 0xc85ff8: ldur            x2, [fp, #-0x58]
    // 0xc85ffc: LoadField: r0 = r2->field_f
    //     0xc85ffc: ldur            w0, [x2, #0xf]
    // 0xc86000: DecompressPointer r0
    //     0xc86000: add             x0, x0, HEAP, lsl #32
    // 0xc86004: LoadField: r2 = r0->field_7
    //     0xc86004: ldur            x2, [x0, #7]
    // 0xc86008: mov             x0, x2
    // 0xc8600c: cmp             x1, x0
    // 0xc86010: b.ne            #0xc87658
    // 0xc86014: ldr             x0, [fp, #0x10]
    // 0xc86018: b               #0xc8604c
    // 0xc8601c: mov             x2, x4
    // 0xc86020: mov             x0, x5
    // 0xc86024: r1 = LoadClassIdInstr(r2)
    //     0xc86024: ldur            x1, [x2, #-1]
    //     0xc86028: ubfx            x1, x1, #0xc, #0x14
    // 0xc8602c: stp             x0, x2, [SP, #-0x10]!
    // 0xc86030: mov             x0, x1
    // 0xc86034: mov             lr, x0
    // 0xc86038: ldr             lr, [x21, lr, lsl #3]
    // 0xc8603c: blr             lr
    // 0xc86040: add             SP, SP, #0x10
    // 0xc86044: tbnz            w0, #4, #0xc87658
    // 0xc86048: ldr             x0, [fp, #0x10]
    // 0xc8604c: LoadField: r1 = r0->field_27
    //     0xc8604c: ldur            w1, [x0, #0x27]
    // 0xc86050: DecompressPointer r1
    //     0xc86050: add             x1, x1, HEAP, lsl #32
    // 0xc86054: cmp             w1, NULL
    // 0xc86058: b.ne            #0xc86064
    // 0xc8605c: ldur            x2, [fp, #-0x40]
    // 0xc86060: b               #0xc86068
    // 0xc86064: mov             x2, x1
    // 0xc86068: ldr             x1, [fp, #0x18]
    // 0xc8606c: stur            x2, [fp, #-0x50]
    // 0xc86070: LoadField: r3 = r1->field_27
    //     0xc86070: ldur            w3, [x1, #0x27]
    // 0xc86074: DecompressPointer r3
    //     0xc86074: add             x3, x3, HEAP, lsl #32
    // 0xc86078: cmp             w3, NULL
    // 0xc8607c: b.ne            #0xc86084
    // 0xc86080: ldur            x3, [fp, #-0x28]
    // 0xc86084: stur            x3, [fp, #-0x48]
    // 0xc86088: cmp             w2, w3
    // 0xc8608c: b.eq            #0xc860cc
    // 0xc86090: r16 = Color
    //     0xc86090: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86094: ldr             x16, [x16, #0xf18]
    // 0xc86098: r30 = Color
    //     0xc86098: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc8609c: ldr             lr, [lr, #0xf18]
    // 0xc860a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc860a4: r0 = ==()
    //     0xc860a4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc860a8: add             SP, SP, #0x10
    // 0xc860ac: tbnz            w0, #4, #0xc87658
    // 0xc860b0: ldur            x0, [fp, #-0x50]
    // 0xc860b4: ldur            x1, [fp, #-0x48]
    // 0xc860b8: LoadField: r2 = r1->field_7
    //     0xc860b8: ldur            x2, [x1, #7]
    // 0xc860bc: LoadField: r1 = r0->field_7
    //     0xc860bc: ldur            x1, [x0, #7]
    // 0xc860c0: cmp             x2, x1
    // 0xc860c4: b.ne            #0xc87658
    // 0xc860c8: ldr             x0, [fp, #0x10]
    // 0xc860cc: LoadField: r1 = r0->field_2b
    //     0xc860cc: ldur            w1, [x0, #0x2b]
    // 0xc860d0: DecompressPointer r1
    //     0xc860d0: add             x1, x1, HEAP, lsl #32
    // 0xc860d4: cmp             w1, NULL
    // 0xc860d8: b.ne            #0xc860e4
    // 0xc860dc: ldur            x2, [fp, #-0x38]
    // 0xc860e0: b               #0xc860e8
    // 0xc860e4: mov             x2, x1
    // 0xc860e8: ldr             x1, [fp, #0x18]
    // 0xc860ec: stur            x2, [fp, #-0x58]
    // 0xc860f0: LoadField: r3 = r1->field_2b
    //     0xc860f0: ldur            w3, [x1, #0x2b]
    // 0xc860f4: DecompressPointer r3
    //     0xc860f4: add             x3, x3, HEAP, lsl #32
    // 0xc860f8: cmp             w3, NULL
    // 0xc860fc: b.ne            #0xc86104
    // 0xc86100: ldur            x3, [fp, #-0x30]
    // 0xc86104: stur            x3, [fp, #-0x50]
    // 0xc86108: r4 = LoadClassIdInstr(r2)
    //     0xc86108: ldur            x4, [x2, #-1]
    //     0xc8610c: ubfx            x4, x4, #0xc, #0x14
    // 0xc86110: lsl             x4, x4, #1
    // 0xc86114: stur            x4, [fp, #-0x48]
    // 0xc86118: r17 = 10114
    //     0xc86118: mov             x17, #0x2782
    // 0xc8611c: cmp             w4, w17
    // 0xc86120: b.eq            #0xc86130
    // 0xc86124: r17 = 10118
    //     0xc86124: mov             x17, #0x2786
    // 0xc86128: cmp             w4, w17
    // 0xc8612c: b.ne            #0xc86204
    // 0xc86130: cmp             w2, w3
    // 0xc86134: b.eq            #0xc86230
    // 0xc86138: stp             x2, x3, [SP, #-0x10]!
    // 0xc8613c: r0 = _haveSameRuntimeType()
    //     0xc8613c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc86140: add             SP, SP, #0x10
    // 0xc86144: tbnz            w0, #4, #0xc87658
    // 0xc86148: ldur            x0, [fp, #-0x50]
    // 0xc8614c: r1 = LoadClassIdInstr(r0)
    //     0xc8614c: ldur            x1, [x0, #-1]
    //     0xc86150: ubfx            x1, x1, #0xc, #0x14
    // 0xc86154: lsl             x1, x1, #1
    // 0xc86158: r17 = 10124
    //     0xc86158: mov             x17, #0x278c
    // 0xc8615c: cmp             w1, w17
    // 0xc86160: b.gt            #0xc86170
    // 0xc86164: r17 = 10122
    //     0xc86164: mov             x17, #0x278a
    // 0xc86168: cmp             w1, w17
    // 0xc8616c: b.ge            #0xc86188
    // 0xc86170: r17 = 10114
    //     0xc86170: mov             x17, #0x2782
    // 0xc86174: cmp             w1, w17
    // 0xc86178: b.eq            #0xc86188
    // 0xc8617c: r17 = 10118
    //     0xc8617c: mov             x17, #0x2786
    // 0xc86180: cmp             w1, w17
    // 0xc86184: b.ne            #0xc86190
    // 0xc86188: LoadField: r1 = r0->field_7
    //     0xc86188: ldur            x1, [x0, #7]
    // 0xc8618c: b               #0xc861a0
    // 0xc86190: LoadField: r1 = r0->field_f
    //     0xc86190: ldur            w1, [x0, #0xf]
    // 0xc86194: DecompressPointer r1
    //     0xc86194: add             x1, x1, HEAP, lsl #32
    // 0xc86198: LoadField: r0 = r1->field_7
    //     0xc86198: ldur            x0, [x1, #7]
    // 0xc8619c: mov             x1, x0
    // 0xc861a0: ldur            x0, [fp, #-0x48]
    // 0xc861a4: r17 = 10124
    //     0xc861a4: mov             x17, #0x278c
    // 0xc861a8: cmp             w0, w17
    // 0xc861ac: b.gt            #0xc861bc
    // 0xc861b0: r17 = 10122
    //     0xc861b0: mov             x17, #0x278a
    // 0xc861b4: cmp             w0, w17
    // 0xc861b8: b.ge            #0xc861d4
    // 0xc861bc: r17 = 10114
    //     0xc861bc: mov             x17, #0x2782
    // 0xc861c0: cmp             w0, w17
    // 0xc861c4: b.eq            #0xc861d4
    // 0xc861c8: r17 = 10118
    //     0xc861c8: mov             x17, #0x2786
    // 0xc861cc: cmp             w0, w17
    // 0xc861d0: b.ne            #0xc861e0
    // 0xc861d4: ldur            x2, [fp, #-0x58]
    // 0xc861d8: LoadField: r0 = r2->field_7
    //     0xc861d8: ldur            x0, [x2, #7]
    // 0xc861dc: b               #0xc861f4
    // 0xc861e0: ldur            x2, [fp, #-0x58]
    // 0xc861e4: LoadField: r0 = r2->field_f
    //     0xc861e4: ldur            w0, [x2, #0xf]
    // 0xc861e8: DecompressPointer r0
    //     0xc861e8: add             x0, x0, HEAP, lsl #32
    // 0xc861ec: LoadField: r2 = r0->field_7
    //     0xc861ec: ldur            x2, [x0, #7]
    // 0xc861f0: mov             x0, x2
    // 0xc861f4: cmp             x1, x0
    // 0xc861f8: b.ne            #0xc87658
    // 0xc861fc: ldr             x0, [fp, #0x10]
    // 0xc86200: b               #0xc86230
    // 0xc86204: mov             x0, x3
    // 0xc86208: r1 = LoadClassIdInstr(r2)
    //     0xc86208: ldur            x1, [x2, #-1]
    //     0xc8620c: ubfx            x1, x1, #0xc, #0x14
    // 0xc86210: stp             x0, x2, [SP, #-0x10]!
    // 0xc86214: mov             x0, x1
    // 0xc86218: mov             lr, x0
    // 0xc8621c: ldr             lr, [x21, lr, lsl #3]
    // 0xc86220: blr             lr
    // 0xc86224: add             SP, SP, #0x10
    // 0xc86228: tbnz            w0, #4, #0xc87658
    // 0xc8622c: ldr             x0, [fp, #0x10]
    // 0xc86230: LoadField: r1 = r0->field_2f
    //     0xc86230: ldur            w1, [x0, #0x2f]
    // 0xc86234: DecompressPointer r1
    //     0xc86234: add             x1, x1, HEAP, lsl #32
    // 0xc86238: cmp             w1, NULL
    // 0xc8623c: b.ne            #0xc86248
    // 0xc86240: ldur            x2, [fp, #-0x40]
    // 0xc86244: b               #0xc8624c
    // 0xc86248: mov             x2, x1
    // 0xc8624c: ldr             x1, [fp, #0x18]
    // 0xc86250: stur            x2, [fp, #-0x40]
    // 0xc86254: LoadField: r3 = r1->field_2f
    //     0xc86254: ldur            w3, [x1, #0x2f]
    // 0xc86258: DecompressPointer r3
    //     0xc86258: add             x3, x3, HEAP, lsl #32
    // 0xc8625c: cmp             w3, NULL
    // 0xc86260: b.ne            #0xc86268
    // 0xc86264: ldur            x3, [fp, #-0x28]
    // 0xc86268: stur            x3, [fp, #-0x28]
    // 0xc8626c: cmp             w2, w3
    // 0xc86270: b.eq            #0xc862ac
    // 0xc86274: r16 = Color
    //     0xc86274: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86278: ldr             x16, [x16, #0xf18]
    // 0xc8627c: r30 = Color
    //     0xc8627c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86280: ldr             lr, [lr, #0xf18]
    // 0xc86284: stp             lr, x16, [SP, #-0x10]!
    // 0xc86288: r0 = ==()
    //     0xc86288: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc8628c: add             SP, SP, #0x10
    // 0xc86290: tbnz            w0, #4, #0xc87658
    // 0xc86294: ldur            x0, [fp, #-0x40]
    // 0xc86298: ldur            x1, [fp, #-0x28]
    // 0xc8629c: LoadField: r2 = r1->field_7
    //     0xc8629c: ldur            x2, [x1, #7]
    // 0xc862a0: LoadField: r1 = r0->field_7
    //     0xc862a0: ldur            x1, [x0, #7]
    // 0xc862a4: cmp             x2, x1
    // 0xc862a8: b.ne            #0xc87658
    // 0xc862ac: ldr             x16, [fp, #0x10]
    // 0xc862b0: SaveReg r16
    //     0xc862b0: str             x16, [SP, #-8]!
    // 0xc862b4: r0 = tertiaryContainer()
    //     0xc862b4: bl              #0x6cd584  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0xc862b8: add             SP, SP, #8
    // 0xc862bc: stur            x0, [fp, #-0x28]
    // 0xc862c0: ldr             x16, [fp, #0x18]
    // 0xc862c4: SaveReg r16
    //     0xc862c4: str             x16, [SP, #-8]!
    // 0xc862c8: r0 = tertiaryContainer()
    //     0xc862c8: bl              #0x6cd584  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::tertiaryContainer
    // 0xc862cc: add             SP, SP, #8
    // 0xc862d0: mov             x1, x0
    // 0xc862d4: ldur            x0, [fp, #-0x28]
    // 0xc862d8: stur            x1, [fp, #-0x48]
    // 0xc862dc: r2 = LoadClassIdInstr(r0)
    //     0xc862dc: ldur            x2, [x0, #-1]
    //     0xc862e0: ubfx            x2, x2, #0xc, #0x14
    // 0xc862e4: lsl             x2, x2, #1
    // 0xc862e8: stur            x2, [fp, #-0x40]
    // 0xc862ec: r17 = 10114
    //     0xc862ec: mov             x17, #0x2782
    // 0xc862f0: cmp             w2, w17
    // 0xc862f4: b.eq            #0xc86304
    // 0xc862f8: r17 = 10118
    //     0xc862f8: mov             x17, #0x2786
    // 0xc862fc: cmp             w2, w17
    // 0xc86300: b.ne            #0xc863d4
    // 0xc86304: cmp             w0, w1
    // 0xc86308: b.eq            #0xc86400
    // 0xc8630c: stp             x0, x1, [SP, #-0x10]!
    // 0xc86310: r0 = _haveSameRuntimeType()
    //     0xc86310: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc86314: add             SP, SP, #0x10
    // 0xc86318: tbnz            w0, #4, #0xc87658
    // 0xc8631c: ldur            x0, [fp, #-0x48]
    // 0xc86320: r1 = LoadClassIdInstr(r0)
    //     0xc86320: ldur            x1, [x0, #-1]
    //     0xc86324: ubfx            x1, x1, #0xc, #0x14
    // 0xc86328: lsl             x1, x1, #1
    // 0xc8632c: r17 = 10124
    //     0xc8632c: mov             x17, #0x278c
    // 0xc86330: cmp             w1, w17
    // 0xc86334: b.gt            #0xc86344
    // 0xc86338: r17 = 10122
    //     0xc86338: mov             x17, #0x278a
    // 0xc8633c: cmp             w1, w17
    // 0xc86340: b.ge            #0xc8635c
    // 0xc86344: r17 = 10114
    //     0xc86344: mov             x17, #0x2782
    // 0xc86348: cmp             w1, w17
    // 0xc8634c: b.eq            #0xc8635c
    // 0xc86350: r17 = 10118
    //     0xc86350: mov             x17, #0x2786
    // 0xc86354: cmp             w1, w17
    // 0xc86358: b.ne            #0xc86364
    // 0xc8635c: LoadField: r1 = r0->field_7
    //     0xc8635c: ldur            x1, [x0, #7]
    // 0xc86360: b               #0xc86374
    // 0xc86364: LoadField: r1 = r0->field_f
    //     0xc86364: ldur            w1, [x0, #0xf]
    // 0xc86368: DecompressPointer r1
    //     0xc86368: add             x1, x1, HEAP, lsl #32
    // 0xc8636c: LoadField: r0 = r1->field_7
    //     0xc8636c: ldur            x0, [x1, #7]
    // 0xc86370: mov             x1, x0
    // 0xc86374: ldur            x0, [fp, #-0x40]
    // 0xc86378: r17 = 10124
    //     0xc86378: mov             x17, #0x278c
    // 0xc8637c: cmp             w0, w17
    // 0xc86380: b.gt            #0xc86390
    // 0xc86384: r17 = 10122
    //     0xc86384: mov             x17, #0x278a
    // 0xc86388: cmp             w0, w17
    // 0xc8638c: b.ge            #0xc863a8
    // 0xc86390: r17 = 10114
    //     0xc86390: mov             x17, #0x2782
    // 0xc86394: cmp             w0, w17
    // 0xc86398: b.eq            #0xc863a8
    // 0xc8639c: r17 = 10118
    //     0xc8639c: mov             x17, #0x2786
    // 0xc863a0: cmp             w0, w17
    // 0xc863a4: b.ne            #0xc863b4
    // 0xc863a8: ldur            x2, [fp, #-0x28]
    // 0xc863ac: LoadField: r0 = r2->field_7
    //     0xc863ac: ldur            x0, [x2, #7]
    // 0xc863b0: b               #0xc863c8
    // 0xc863b4: ldur            x2, [fp, #-0x28]
    // 0xc863b8: LoadField: r0 = r2->field_f
    //     0xc863b8: ldur            w0, [x2, #0xf]
    // 0xc863bc: DecompressPointer r0
    //     0xc863bc: add             x0, x0, HEAP, lsl #32
    // 0xc863c0: LoadField: r2 = r0->field_7
    //     0xc863c0: ldur            x2, [x0, #7]
    // 0xc863c4: mov             x0, x2
    // 0xc863c8: cmp             x1, x0
    // 0xc863cc: b.ne            #0xc87658
    // 0xc863d0: b               #0xc86400
    // 0xc863d4: mov             x2, x0
    // 0xc863d8: mov             x0, x1
    // 0xc863dc: r1 = LoadClassIdInstr(r2)
    //     0xc863dc: ldur            x1, [x2, #-1]
    //     0xc863e0: ubfx            x1, x1, #0xc, #0x14
    // 0xc863e4: stp             x0, x2, [SP, #-0x10]!
    // 0xc863e8: mov             x0, x1
    // 0xc863ec: mov             lr, x0
    // 0xc863f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc863f4: blr             lr
    // 0xc863f8: add             SP, SP, #0x10
    // 0xc863fc: tbnz            w0, #4, #0xc87658
    // 0xc86400: ldr             x16, [fp, #0x10]
    // 0xc86404: SaveReg r16
    //     0xc86404: str             x16, [SP, #-8]!
    // 0xc86408: r0 = onTertiaryContainer()
    //     0xc86408: bl              #0x6cd53c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0xc8640c: add             SP, SP, #8
    // 0xc86410: stur            x0, [fp, #-0x28]
    // 0xc86414: ldr             x16, [fp, #0x18]
    // 0xc86418: SaveReg r16
    //     0xc86418: str             x16, [SP, #-8]!
    // 0xc8641c: r0 = onTertiaryContainer()
    //     0xc8641c: bl              #0x6cd53c  ; [package:flutter/src/material/color_scheme.dart] ColorScheme::onTertiaryContainer
    // 0xc86420: add             SP, SP, #8
    // 0xc86424: mov             x1, x0
    // 0xc86428: ldur            x0, [fp, #-0x28]
    // 0xc8642c: stur            x1, [fp, #-0x40]
    // 0xc86430: cmp             w0, w1
    // 0xc86434: b.eq            #0xc86470
    // 0xc86438: r16 = Color
    //     0xc86438: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc8643c: ldr             x16, [x16, #0xf18]
    // 0xc86440: r30 = Color
    //     0xc86440: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86444: ldr             lr, [lr, #0xf18]
    // 0xc86448: stp             lr, x16, [SP, #-0x10]!
    // 0xc8644c: r0 = ==()
    //     0xc8644c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86450: add             SP, SP, #0x10
    // 0xc86454: tbnz            w0, #4, #0xc87658
    // 0xc86458: ldur            x0, [fp, #-0x28]
    // 0xc8645c: ldur            x1, [fp, #-0x40]
    // 0xc86460: LoadField: r2 = r1->field_7
    //     0xc86460: ldur            x2, [x1, #7]
    // 0xc86464: LoadField: r1 = r0->field_7
    //     0xc86464: ldur            x1, [x0, #7]
    // 0xc86468: cmp             x2, x1
    // 0xc8646c: b.ne            #0xc87658
    // 0xc86470: ldr             x1, [fp, #0x18]
    // 0xc86474: ldr             x0, [fp, #0x10]
    // 0xc86478: LoadField: r2 = r0->field_3b
    //     0xc86478: ldur            w2, [x0, #0x3b]
    // 0xc8647c: DecompressPointer r2
    //     0xc8647c: add             x2, x2, HEAP, lsl #32
    // 0xc86480: stur            x2, [fp, #-0x48]
    // 0xc86484: LoadField: r3 = r1->field_3b
    //     0xc86484: ldur            w3, [x1, #0x3b]
    // 0xc86488: DecompressPointer r3
    //     0xc86488: add             x3, x3, HEAP, lsl #32
    // 0xc8648c: stur            x3, [fp, #-0x40]
    // 0xc86490: r4 = LoadClassIdInstr(r2)
    //     0xc86490: ldur            x4, [x2, #-1]
    //     0xc86494: ubfx            x4, x4, #0xc, #0x14
    // 0xc86498: lsl             x4, x4, #1
    // 0xc8649c: stur            x4, [fp, #-0x28]
    // 0xc864a0: r17 = 10114
    //     0xc864a0: mov             x17, #0x2782
    // 0xc864a4: cmp             w4, w17
    // 0xc864a8: b.eq            #0xc864b8
    // 0xc864ac: r17 = 10118
    //     0xc864ac: mov             x17, #0x2786
    // 0xc864b0: cmp             w4, w17
    // 0xc864b4: b.ne            #0xc86590
    // 0xc864b8: cmp             w2, w3
    // 0xc864bc: b.eq            #0xc865c0
    // 0xc864c0: stp             x2, x3, [SP, #-0x10]!
    // 0xc864c4: r0 = _haveSameRuntimeType()
    //     0xc864c4: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc864c8: add             SP, SP, #0x10
    // 0xc864cc: tbnz            w0, #4, #0xc87658
    // 0xc864d0: ldur            x1, [fp, #-0x40]
    // 0xc864d4: r0 = LoadClassIdInstr(r1)
    //     0xc864d4: ldur            x0, [x1, #-1]
    //     0xc864d8: ubfx            x0, x0, #0xc, #0x14
    // 0xc864dc: lsl             x0, x0, #1
    // 0xc864e0: r17 = 10124
    //     0xc864e0: mov             x17, #0x278c
    // 0xc864e4: cmp             w0, w17
    // 0xc864e8: b.gt            #0xc864f8
    // 0xc864ec: r17 = 10122
    //     0xc864ec: mov             x17, #0x278a
    // 0xc864f0: cmp             w0, w17
    // 0xc864f4: b.ge            #0xc86510
    // 0xc864f8: r17 = 10114
    //     0xc864f8: mov             x17, #0x2782
    // 0xc864fc: cmp             w0, w17
    // 0xc86500: b.eq            #0xc86510
    // 0xc86504: r17 = 10118
    //     0xc86504: mov             x17, #0x2786
    // 0xc86508: cmp             w0, w17
    // 0xc8650c: b.ne            #0xc8651c
    // 0xc86510: LoadField: r0 = r1->field_7
    //     0xc86510: ldur            x0, [x1, #7]
    // 0xc86514: mov             x2, x0
    // 0xc86518: b               #0xc86528
    // 0xc8651c: LoadField: r0 = r1->field_f
    //     0xc8651c: ldur            w0, [x1, #0xf]
    // 0xc86520: DecompressPointer r0
    //     0xc86520: add             x0, x0, HEAP, lsl #32
    // 0xc86524: LoadField: r2 = r0->field_7
    //     0xc86524: ldur            x2, [x0, #7]
    // 0xc86528: ldur            x0, [fp, #-0x28]
    // 0xc8652c: r17 = 10124
    //     0xc8652c: mov             x17, #0x278c
    // 0xc86530: cmp             w0, w17
    // 0xc86534: b.gt            #0xc86544
    // 0xc86538: r17 = 10122
    //     0xc86538: mov             x17, #0x278a
    // 0xc8653c: cmp             w0, w17
    // 0xc86540: b.ge            #0xc8655c
    // 0xc86544: r17 = 10114
    //     0xc86544: mov             x17, #0x2782
    // 0xc86548: cmp             w0, w17
    // 0xc8654c: b.eq            #0xc8655c
    // 0xc86550: r17 = 10118
    //     0xc86550: mov             x17, #0x2786
    // 0xc86554: cmp             w0, w17
    // 0xc86558: b.ne            #0xc86568
    // 0xc8655c: ldur            x3, [fp, #-0x48]
    // 0xc86560: LoadField: r0 = r3->field_7
    //     0xc86560: ldur            x0, [x3, #7]
    // 0xc86564: b               #0xc8657c
    // 0xc86568: ldur            x3, [fp, #-0x48]
    // 0xc8656c: LoadField: r0 = r3->field_f
    //     0xc8656c: ldur            w0, [x3, #0xf]
    // 0xc86570: DecompressPointer r0
    //     0xc86570: add             x0, x0, HEAP, lsl #32
    // 0xc86574: LoadField: r4 = r0->field_7
    //     0xc86574: ldur            x4, [x0, #7]
    // 0xc86578: mov             x0, x4
    // 0xc8657c: cmp             x2, x0
    // 0xc86580: b.ne            #0xc87658
    // 0xc86584: ldr             x1, [fp, #0x18]
    // 0xc86588: ldr             x0, [fp, #0x10]
    // 0xc8658c: b               #0xc865c0
    // 0xc86590: mov             x1, x3
    // 0xc86594: mov             x3, x2
    // 0xc86598: r0 = LoadClassIdInstr(r3)
    //     0xc86598: ldur            x0, [x3, #-1]
    //     0xc8659c: ubfx            x0, x0, #0xc, #0x14
    // 0xc865a0: stp             x1, x3, [SP, #-0x10]!
    // 0xc865a4: mov             lr, x0
    // 0xc865a8: ldr             lr, [x21, lr, lsl #3]
    // 0xc865ac: blr             lr
    // 0xc865b0: add             SP, SP, #0x10
    // 0xc865b4: tbnz            w0, #4, #0xc87658
    // 0xc865b8: ldr             x1, [fp, #0x18]
    // 0xc865bc: ldr             x0, [fp, #0x10]
    // 0xc865c0: LoadField: r2 = r0->field_3f
    //     0xc865c0: ldur            w2, [x0, #0x3f]
    // 0xc865c4: DecompressPointer r2
    //     0xc865c4: add             x2, x2, HEAP, lsl #32
    // 0xc865c8: stur            x2, [fp, #-0x50]
    // 0xc865cc: LoadField: r3 = r1->field_3f
    //     0xc865cc: ldur            w3, [x1, #0x3f]
    // 0xc865d0: DecompressPointer r3
    //     0xc865d0: add             x3, x3, HEAP, lsl #32
    // 0xc865d4: stur            x3, [fp, #-0x28]
    // 0xc865d8: cmp             w2, w3
    // 0xc865dc: b.ne            #0xc865f4
    // 0xc865e0: mov             x16, x2
    // 0xc865e4: mov             x2, x0
    // 0xc865e8: mov             x0, x16
    // 0xc865ec: mov             x1, x3
    // 0xc865f0: b               #0xc86630
    // 0xc865f4: r16 = Color
    //     0xc865f4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc865f8: ldr             x16, [x16, #0xf18]
    // 0xc865fc: r30 = Color
    //     0xc865fc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86600: ldr             lr, [lr, #0xf18]
    // 0xc86604: stp             lr, x16, [SP, #-0x10]!
    // 0xc86608: r0 = ==()
    //     0xc86608: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc8660c: add             SP, SP, #0x10
    // 0xc86610: tbnz            w0, #4, #0xc87658
    // 0xc86614: ldur            x0, [fp, #-0x50]
    // 0xc86618: ldur            x1, [fp, #-0x28]
    // 0xc8661c: LoadField: r2 = r1->field_7
    //     0xc8661c: ldur            x2, [x1, #7]
    // 0xc86620: LoadField: r3 = r0->field_7
    //     0xc86620: ldur            x3, [x0, #7]
    // 0xc86624: cmp             x2, x3
    // 0xc86628: b.ne            #0xc87658
    // 0xc8662c: ldr             x2, [fp, #0x10]
    // 0xc86630: LoadField: r3 = r2->field_43
    //     0xc86630: ldur            w3, [x2, #0x43]
    // 0xc86634: DecompressPointer r3
    //     0xc86634: add             x3, x3, HEAP, lsl #32
    // 0xc86638: cmp             w3, NULL
    // 0xc8663c: b.ne            #0xc86648
    // 0xc86640: ldur            x4, [fp, #-0x48]
    // 0xc86644: b               #0xc8664c
    // 0xc86648: mov             x4, x3
    // 0xc8664c: ldr             x3, [fp, #0x18]
    // 0xc86650: stur            x4, [fp, #-0x58]
    // 0xc86654: LoadField: r5 = r3->field_43
    //     0xc86654: ldur            w5, [x3, #0x43]
    // 0xc86658: DecompressPointer r5
    //     0xc86658: add             x5, x5, HEAP, lsl #32
    // 0xc8665c: cmp             w5, NULL
    // 0xc86660: b.ne            #0xc86668
    // 0xc86664: ldur            x5, [fp, #-0x40]
    // 0xc86668: stur            x5, [fp, #-0x48]
    // 0xc8666c: r6 = LoadClassIdInstr(r4)
    //     0xc8666c: ldur            x6, [x4, #-1]
    //     0xc86670: ubfx            x6, x6, #0xc, #0x14
    // 0xc86674: lsl             x6, x6, #1
    // 0xc86678: stur            x6, [fp, #-0x40]
    // 0xc8667c: r17 = 10114
    //     0xc8667c: mov             x17, #0x2782
    // 0xc86680: cmp             w6, w17
    // 0xc86684: b.eq            #0xc86694
    // 0xc86688: r17 = 10118
    //     0xc86688: mov             x17, #0x2786
    // 0xc8668c: cmp             w6, w17
    // 0xc86690: b.ne            #0xc86770
    // 0xc86694: cmp             w4, w5
    // 0xc86698: b.ne            #0xc866a4
    // 0xc8669c: mov             x0, x2
    // 0xc866a0: b               #0xc867a0
    // 0xc866a4: stp             x4, x5, [SP, #-0x10]!
    // 0xc866a8: r0 = _haveSameRuntimeType()
    //     0xc866a8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc866ac: add             SP, SP, #0x10
    // 0xc866b0: tbnz            w0, #4, #0xc87658
    // 0xc866b4: ldur            x0, [fp, #-0x48]
    // 0xc866b8: r1 = LoadClassIdInstr(r0)
    //     0xc866b8: ldur            x1, [x0, #-1]
    //     0xc866bc: ubfx            x1, x1, #0xc, #0x14
    // 0xc866c0: lsl             x1, x1, #1
    // 0xc866c4: r17 = 10124
    //     0xc866c4: mov             x17, #0x278c
    // 0xc866c8: cmp             w1, w17
    // 0xc866cc: b.gt            #0xc866dc
    // 0xc866d0: r17 = 10122
    //     0xc866d0: mov             x17, #0x278a
    // 0xc866d4: cmp             w1, w17
    // 0xc866d8: b.ge            #0xc866f4
    // 0xc866dc: r17 = 10114
    //     0xc866dc: mov             x17, #0x2782
    // 0xc866e0: cmp             w1, w17
    // 0xc866e4: b.eq            #0xc866f4
    // 0xc866e8: r17 = 10118
    //     0xc866e8: mov             x17, #0x2786
    // 0xc866ec: cmp             w1, w17
    // 0xc866f0: b.ne            #0xc866fc
    // 0xc866f4: LoadField: r1 = r0->field_7
    //     0xc866f4: ldur            x1, [x0, #7]
    // 0xc866f8: b               #0xc8670c
    // 0xc866fc: LoadField: r1 = r0->field_f
    //     0xc866fc: ldur            w1, [x0, #0xf]
    // 0xc86700: DecompressPointer r1
    //     0xc86700: add             x1, x1, HEAP, lsl #32
    // 0xc86704: LoadField: r0 = r1->field_7
    //     0xc86704: ldur            x0, [x1, #7]
    // 0xc86708: mov             x1, x0
    // 0xc8670c: ldur            x0, [fp, #-0x40]
    // 0xc86710: r17 = 10124
    //     0xc86710: mov             x17, #0x278c
    // 0xc86714: cmp             w0, w17
    // 0xc86718: b.gt            #0xc86728
    // 0xc8671c: r17 = 10122
    //     0xc8671c: mov             x17, #0x278a
    // 0xc86720: cmp             w0, w17
    // 0xc86724: b.ge            #0xc86740
    // 0xc86728: r17 = 10114
    //     0xc86728: mov             x17, #0x2782
    // 0xc8672c: cmp             w0, w17
    // 0xc86730: b.eq            #0xc86740
    // 0xc86734: r17 = 10118
    //     0xc86734: mov             x17, #0x2786
    // 0xc86738: cmp             w0, w17
    // 0xc8673c: b.ne            #0xc8674c
    // 0xc86740: ldur            x2, [fp, #-0x58]
    // 0xc86744: LoadField: r0 = r2->field_7
    //     0xc86744: ldur            x0, [x2, #7]
    // 0xc86748: b               #0xc86760
    // 0xc8674c: ldur            x2, [fp, #-0x58]
    // 0xc86750: LoadField: r0 = r2->field_f
    //     0xc86750: ldur            w0, [x2, #0xf]
    // 0xc86754: DecompressPointer r0
    //     0xc86754: add             x0, x0, HEAP, lsl #32
    // 0xc86758: LoadField: r2 = r0->field_7
    //     0xc86758: ldur            x2, [x0, #7]
    // 0xc8675c: mov             x0, x2
    // 0xc86760: cmp             x1, x0
    // 0xc86764: b.ne            #0xc87658
    // 0xc86768: ldr             x0, [fp, #0x10]
    // 0xc8676c: b               #0xc867a0
    // 0xc86770: mov             x2, x4
    // 0xc86774: mov             x0, x5
    // 0xc86778: r1 = LoadClassIdInstr(r2)
    //     0xc86778: ldur            x1, [x2, #-1]
    //     0xc8677c: ubfx            x1, x1, #0xc, #0x14
    // 0xc86780: stp             x0, x2, [SP, #-0x10]!
    // 0xc86784: mov             x0, x1
    // 0xc86788: mov             lr, x0
    // 0xc8678c: ldr             lr, [x21, lr, lsl #3]
    // 0xc86790: blr             lr
    // 0xc86794: add             SP, SP, #0x10
    // 0xc86798: tbnz            w0, #4, #0xc87658
    // 0xc8679c: ldr             x0, [fp, #0x10]
    // 0xc867a0: LoadField: r1 = r0->field_47
    //     0xc867a0: ldur            w1, [x0, #0x47]
    // 0xc867a4: DecompressPointer r1
    //     0xc867a4: add             x1, x1, HEAP, lsl #32
    // 0xc867a8: cmp             w1, NULL
    // 0xc867ac: b.ne            #0xc867b8
    // 0xc867b0: ldur            x2, [fp, #-0x50]
    // 0xc867b4: b               #0xc867bc
    // 0xc867b8: mov             x2, x1
    // 0xc867bc: ldr             x1, [fp, #0x18]
    // 0xc867c0: stur            x2, [fp, #-0x40]
    // 0xc867c4: LoadField: r3 = r1->field_47
    //     0xc867c4: ldur            w3, [x1, #0x47]
    // 0xc867c8: DecompressPointer r3
    //     0xc867c8: add             x3, x3, HEAP, lsl #32
    // 0xc867cc: cmp             w3, NULL
    // 0xc867d0: b.ne            #0xc867d8
    // 0xc867d4: ldur            x3, [fp, #-0x28]
    // 0xc867d8: stur            x3, [fp, #-0x28]
    // 0xc867dc: cmp             w2, w3
    // 0xc867e0: b.eq            #0xc86824
    // 0xc867e4: r16 = Color
    //     0xc867e4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc867e8: ldr             x16, [x16, #0xf18]
    // 0xc867ec: r30 = Color
    //     0xc867ec: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc867f0: ldr             lr, [lr, #0xf18]
    // 0xc867f4: stp             lr, x16, [SP, #-0x10]!
    // 0xc867f8: r0 = ==()
    //     0xc867f8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc867fc: add             SP, SP, #0x10
    // 0xc86800: tbnz            w0, #4, #0xc87658
    // 0xc86804: ldur            x0, [fp, #-0x40]
    // 0xc86808: ldur            x1, [fp, #-0x28]
    // 0xc8680c: LoadField: r2 = r1->field_7
    //     0xc8680c: ldur            x2, [x1, #7]
    // 0xc86810: LoadField: r1 = r0->field_7
    //     0xc86810: ldur            x1, [x0, #7]
    // 0xc86814: cmp             x2, x1
    // 0xc86818: b.ne            #0xc87658
    // 0xc8681c: ldr             x1, [fp, #0x18]
    // 0xc86820: ldr             x0, [fp, #0x10]
    // 0xc86824: LoadField: r2 = r0->field_4b
    //     0xc86824: ldur            w2, [x0, #0x4b]
    // 0xc86828: DecompressPointer r2
    //     0xc86828: add             x2, x2, HEAP, lsl #32
    // 0xc8682c: stur            x2, [fp, #-0x48]
    // 0xc86830: LoadField: r3 = r1->field_4b
    //     0xc86830: ldur            w3, [x1, #0x4b]
    // 0xc86834: DecompressPointer r3
    //     0xc86834: add             x3, x3, HEAP, lsl #32
    // 0xc86838: stur            x3, [fp, #-0x40]
    // 0xc8683c: r4 = LoadClassIdInstr(r2)
    //     0xc8683c: ldur            x4, [x2, #-1]
    //     0xc86840: ubfx            x4, x4, #0xc, #0x14
    // 0xc86844: lsl             x4, x4, #1
    // 0xc86848: stur            x4, [fp, #-0x28]
    // 0xc8684c: r17 = 10114
    //     0xc8684c: mov             x17, #0x2782
    // 0xc86850: cmp             w4, w17
    // 0xc86854: b.eq            #0xc86864
    // 0xc86858: r17 = 10118
    //     0xc86858: mov             x17, #0x2786
    // 0xc8685c: cmp             w4, w17
    // 0xc86860: b.ne            #0xc8693c
    // 0xc86864: cmp             w2, w3
    // 0xc86868: b.eq            #0xc8696c
    // 0xc8686c: stp             x2, x3, [SP, #-0x10]!
    // 0xc86870: r0 = _haveSameRuntimeType()
    //     0xc86870: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc86874: add             SP, SP, #0x10
    // 0xc86878: tbnz            w0, #4, #0xc87658
    // 0xc8687c: ldur            x0, [fp, #-0x40]
    // 0xc86880: r1 = LoadClassIdInstr(r0)
    //     0xc86880: ldur            x1, [x0, #-1]
    //     0xc86884: ubfx            x1, x1, #0xc, #0x14
    // 0xc86888: lsl             x1, x1, #1
    // 0xc8688c: r17 = 10124
    //     0xc8688c: mov             x17, #0x278c
    // 0xc86890: cmp             w1, w17
    // 0xc86894: b.gt            #0xc868a4
    // 0xc86898: r17 = 10122
    //     0xc86898: mov             x17, #0x278a
    // 0xc8689c: cmp             w1, w17
    // 0xc868a0: b.ge            #0xc868bc
    // 0xc868a4: r17 = 10114
    //     0xc868a4: mov             x17, #0x2782
    // 0xc868a8: cmp             w1, w17
    // 0xc868ac: b.eq            #0xc868bc
    // 0xc868b0: r17 = 10118
    //     0xc868b0: mov             x17, #0x2786
    // 0xc868b4: cmp             w1, w17
    // 0xc868b8: b.ne            #0xc868c4
    // 0xc868bc: LoadField: r1 = r0->field_7
    //     0xc868bc: ldur            x1, [x0, #7]
    // 0xc868c0: b               #0xc868d4
    // 0xc868c4: LoadField: r1 = r0->field_f
    //     0xc868c4: ldur            w1, [x0, #0xf]
    // 0xc868c8: DecompressPointer r1
    //     0xc868c8: add             x1, x1, HEAP, lsl #32
    // 0xc868cc: LoadField: r0 = r1->field_7
    //     0xc868cc: ldur            x0, [x1, #7]
    // 0xc868d0: mov             x1, x0
    // 0xc868d4: ldur            x0, [fp, #-0x28]
    // 0xc868d8: r17 = 10124
    //     0xc868d8: mov             x17, #0x278c
    // 0xc868dc: cmp             w0, w17
    // 0xc868e0: b.gt            #0xc868f0
    // 0xc868e4: r17 = 10122
    //     0xc868e4: mov             x17, #0x278a
    // 0xc868e8: cmp             w0, w17
    // 0xc868ec: b.ge            #0xc86908
    // 0xc868f0: r17 = 10114
    //     0xc868f0: mov             x17, #0x2782
    // 0xc868f4: cmp             w0, w17
    // 0xc868f8: b.eq            #0xc86908
    // 0xc868fc: r17 = 10118
    //     0xc868fc: mov             x17, #0x2786
    // 0xc86900: cmp             w0, w17
    // 0xc86904: b.ne            #0xc86914
    // 0xc86908: ldur            x2, [fp, #-0x48]
    // 0xc8690c: LoadField: r0 = r2->field_7
    //     0xc8690c: ldur            x0, [x2, #7]
    // 0xc86910: b               #0xc86928
    // 0xc86914: ldur            x2, [fp, #-0x48]
    // 0xc86918: LoadField: r0 = r2->field_f
    //     0xc86918: ldur            w0, [x2, #0xf]
    // 0xc8691c: DecompressPointer r0
    //     0xc8691c: add             x0, x0, HEAP, lsl #32
    // 0xc86920: LoadField: r2 = r0->field_7
    //     0xc86920: ldur            x2, [x0, #7]
    // 0xc86924: mov             x0, x2
    // 0xc86928: cmp             x1, x0
    // 0xc8692c: b.ne            #0xc87658
    // 0xc86930: ldr             x1, [fp, #0x18]
    // 0xc86934: ldr             x0, [fp, #0x10]
    // 0xc86938: b               #0xc8696c
    // 0xc8693c: mov             x0, x3
    // 0xc86940: r1 = LoadClassIdInstr(r2)
    //     0xc86940: ldur            x1, [x2, #-1]
    //     0xc86944: ubfx            x1, x1, #0xc, #0x14
    // 0xc86948: stp             x0, x2, [SP, #-0x10]!
    // 0xc8694c: mov             x0, x1
    // 0xc86950: mov             lr, x0
    // 0xc86954: ldr             lr, [x21, lr, lsl #3]
    // 0xc86958: blr             lr
    // 0xc8695c: add             SP, SP, #0x10
    // 0xc86960: tbnz            w0, #4, #0xc87658
    // 0xc86964: ldr             x1, [fp, #0x18]
    // 0xc86968: ldr             x0, [fp, #0x10]
    // 0xc8696c: LoadField: r2 = r0->field_4f
    //     0xc8696c: ldur            w2, [x0, #0x4f]
    // 0xc86970: DecompressPointer r2
    //     0xc86970: add             x2, x2, HEAP, lsl #32
    // 0xc86974: stur            x2, [fp, #-0x40]
    // 0xc86978: LoadField: r3 = r1->field_4f
    //     0xc86978: ldur            w3, [x1, #0x4f]
    // 0xc8697c: DecompressPointer r3
    //     0xc8697c: add             x3, x3, HEAP, lsl #32
    // 0xc86980: stur            x3, [fp, #-0x28]
    // 0xc86984: cmp             w2, w3
    // 0xc86988: b.ne            #0xc869a8
    // 0xc8698c: mov             x16, x3
    // 0xc86990: mov             x3, x1
    // 0xc86994: mov             x1, x16
    // 0xc86998: mov             x16, x2
    // 0xc8699c: mov             x2, x0
    // 0xc869a0: mov             x0, x16
    // 0xc869a4: b               #0xc869e8
    // 0xc869a8: r16 = Color
    //     0xc869a8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc869ac: ldr             x16, [x16, #0xf18]
    // 0xc869b0: r30 = Color
    //     0xc869b0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc869b4: ldr             lr, [lr, #0xf18]
    // 0xc869b8: stp             lr, x16, [SP, #-0x10]!
    // 0xc869bc: r0 = ==()
    //     0xc869bc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc869c0: add             SP, SP, #0x10
    // 0xc869c4: tbnz            w0, #4, #0xc87658
    // 0xc869c8: ldur            x0, [fp, #-0x40]
    // 0xc869cc: ldur            x1, [fp, #-0x28]
    // 0xc869d0: LoadField: r2 = r1->field_7
    //     0xc869d0: ldur            x2, [x1, #7]
    // 0xc869d4: LoadField: r3 = r0->field_7
    //     0xc869d4: ldur            x3, [x0, #7]
    // 0xc869d8: cmp             x2, x3
    // 0xc869dc: b.ne            #0xc87658
    // 0xc869e0: ldr             x3, [fp, #0x18]
    // 0xc869e4: ldr             x2, [fp, #0x10]
    // 0xc869e8: LoadField: r4 = r2->field_53
    //     0xc869e8: ldur            w4, [x2, #0x53]
    // 0xc869ec: DecompressPointer r4
    //     0xc869ec: add             x4, x4, HEAP, lsl #32
    // 0xc869f0: stur            x4, [fp, #-0x58]
    // 0xc869f4: LoadField: r5 = r3->field_53
    //     0xc869f4: ldur            w5, [x3, #0x53]
    // 0xc869f8: DecompressPointer r5
    //     0xc869f8: add             x5, x5, HEAP, lsl #32
    // 0xc869fc: stur            x5, [fp, #-0x50]
    // 0xc86a00: r6 = LoadClassIdInstr(r4)
    //     0xc86a00: ldur            x6, [x4, #-1]
    //     0xc86a04: ubfx            x6, x6, #0xc, #0x14
    // 0xc86a08: lsl             x6, x6, #1
    // 0xc86a0c: stur            x6, [fp, #-0x48]
    // 0xc86a10: r17 = 10114
    //     0xc86a10: mov             x17, #0x2782
    // 0xc86a14: cmp             w6, w17
    // 0xc86a18: b.eq            #0xc86a28
    // 0xc86a1c: r17 = 10118
    //     0xc86a1c: mov             x17, #0x2786
    // 0xc86a20: cmp             w6, w17
    // 0xc86a24: b.ne            #0xc86b0c
    // 0xc86a28: cmp             w4, w5
    // 0xc86a2c: b.ne            #0xc86a3c
    // 0xc86a30: mov             x1, x3
    // 0xc86a34: mov             x0, x2
    // 0xc86a38: b               #0xc86b3c
    // 0xc86a3c: stp             x4, x5, [SP, #-0x10]!
    // 0xc86a40: r0 = _haveSameRuntimeType()
    //     0xc86a40: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc86a44: add             SP, SP, #0x10
    // 0xc86a48: tbnz            w0, #4, #0xc87658
    // 0xc86a4c: ldur            x1, [fp, #-0x50]
    // 0xc86a50: r0 = LoadClassIdInstr(r1)
    //     0xc86a50: ldur            x0, [x1, #-1]
    //     0xc86a54: ubfx            x0, x0, #0xc, #0x14
    // 0xc86a58: lsl             x0, x0, #1
    // 0xc86a5c: r17 = 10124
    //     0xc86a5c: mov             x17, #0x278c
    // 0xc86a60: cmp             w0, w17
    // 0xc86a64: b.gt            #0xc86a74
    // 0xc86a68: r17 = 10122
    //     0xc86a68: mov             x17, #0x278a
    // 0xc86a6c: cmp             w0, w17
    // 0xc86a70: b.ge            #0xc86a8c
    // 0xc86a74: r17 = 10114
    //     0xc86a74: mov             x17, #0x2782
    // 0xc86a78: cmp             w0, w17
    // 0xc86a7c: b.eq            #0xc86a8c
    // 0xc86a80: r17 = 10118
    //     0xc86a80: mov             x17, #0x2786
    // 0xc86a84: cmp             w0, w17
    // 0xc86a88: b.ne            #0xc86a98
    // 0xc86a8c: LoadField: r0 = r1->field_7
    //     0xc86a8c: ldur            x0, [x1, #7]
    // 0xc86a90: mov             x2, x0
    // 0xc86a94: b               #0xc86aa4
    // 0xc86a98: LoadField: r0 = r1->field_f
    //     0xc86a98: ldur            w0, [x1, #0xf]
    // 0xc86a9c: DecompressPointer r0
    //     0xc86a9c: add             x0, x0, HEAP, lsl #32
    // 0xc86aa0: LoadField: r2 = r0->field_7
    //     0xc86aa0: ldur            x2, [x0, #7]
    // 0xc86aa4: ldur            x0, [fp, #-0x48]
    // 0xc86aa8: r17 = 10124
    //     0xc86aa8: mov             x17, #0x278c
    // 0xc86aac: cmp             w0, w17
    // 0xc86ab0: b.gt            #0xc86ac0
    // 0xc86ab4: r17 = 10122
    //     0xc86ab4: mov             x17, #0x278a
    // 0xc86ab8: cmp             w0, w17
    // 0xc86abc: b.ge            #0xc86ad8
    // 0xc86ac0: r17 = 10114
    //     0xc86ac0: mov             x17, #0x2782
    // 0xc86ac4: cmp             w0, w17
    // 0xc86ac8: b.eq            #0xc86ad8
    // 0xc86acc: r17 = 10118
    //     0xc86acc: mov             x17, #0x2786
    // 0xc86ad0: cmp             w0, w17
    // 0xc86ad4: b.ne            #0xc86ae4
    // 0xc86ad8: ldur            x3, [fp, #-0x58]
    // 0xc86adc: LoadField: r0 = r3->field_7
    //     0xc86adc: ldur            x0, [x3, #7]
    // 0xc86ae0: b               #0xc86af8
    // 0xc86ae4: ldur            x3, [fp, #-0x58]
    // 0xc86ae8: LoadField: r0 = r3->field_f
    //     0xc86ae8: ldur            w0, [x3, #0xf]
    // 0xc86aec: DecompressPointer r0
    //     0xc86aec: add             x0, x0, HEAP, lsl #32
    // 0xc86af0: LoadField: r4 = r0->field_7
    //     0xc86af0: ldur            x4, [x0, #7]
    // 0xc86af4: mov             x0, x4
    // 0xc86af8: cmp             x2, x0
    // 0xc86afc: b.ne            #0xc87658
    // 0xc86b00: ldr             x1, [fp, #0x18]
    // 0xc86b04: ldr             x0, [fp, #0x10]
    // 0xc86b08: b               #0xc86b3c
    // 0xc86b0c: mov             x3, x4
    // 0xc86b10: mov             x1, x5
    // 0xc86b14: r0 = LoadClassIdInstr(r3)
    //     0xc86b14: ldur            x0, [x3, #-1]
    //     0xc86b18: ubfx            x0, x0, #0xc, #0x14
    // 0xc86b1c: stp             x1, x3, [SP, #-0x10]!
    // 0xc86b20: mov             lr, x0
    // 0xc86b24: ldr             lr, [x21, lr, lsl #3]
    // 0xc86b28: blr             lr
    // 0xc86b2c: add             SP, SP, #0x10
    // 0xc86b30: tbnz            w0, #4, #0xc87658
    // 0xc86b34: ldr             x1, [fp, #0x18]
    // 0xc86b38: ldr             x0, [fp, #0x10]
    // 0xc86b3c: LoadField: r2 = r0->field_57
    //     0xc86b3c: ldur            w2, [x0, #0x57]
    // 0xc86b40: DecompressPointer r2
    //     0xc86b40: add             x2, x2, HEAP, lsl #32
    // 0xc86b44: stur            x2, [fp, #-0x60]
    // 0xc86b48: LoadField: r3 = r1->field_57
    //     0xc86b48: ldur            w3, [x1, #0x57]
    // 0xc86b4c: DecompressPointer r3
    //     0xc86b4c: add             x3, x3, HEAP, lsl #32
    // 0xc86b50: stur            x3, [fp, #-0x48]
    // 0xc86b54: cmp             w2, w3
    // 0xc86b58: b.ne            #0xc86b70
    // 0xc86b5c: mov             x16, x2
    // 0xc86b60: mov             x2, x0
    // 0xc86b64: mov             x0, x16
    // 0xc86b68: mov             x1, x3
    // 0xc86b6c: b               #0xc86bac
    // 0xc86b70: r16 = Color
    //     0xc86b70: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86b74: ldr             x16, [x16, #0xf18]
    // 0xc86b78: r30 = Color
    //     0xc86b78: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86b7c: ldr             lr, [lr, #0xf18]
    // 0xc86b80: stp             lr, x16, [SP, #-0x10]!
    // 0xc86b84: r0 = ==()
    //     0xc86b84: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86b88: add             SP, SP, #0x10
    // 0xc86b8c: tbnz            w0, #4, #0xc87658
    // 0xc86b90: ldur            x0, [fp, #-0x60]
    // 0xc86b94: ldur            x1, [fp, #-0x48]
    // 0xc86b98: LoadField: r2 = r1->field_7
    //     0xc86b98: ldur            x2, [x1, #7]
    // 0xc86b9c: LoadField: r3 = r0->field_7
    //     0xc86b9c: ldur            x3, [x0, #7]
    // 0xc86ba0: cmp             x2, x3
    // 0xc86ba4: b.ne            #0xc87658
    // 0xc86ba8: ldr             x2, [fp, #0x10]
    // 0xc86bac: LoadField: r3 = r2->field_5b
    //     0xc86bac: ldur            w3, [x2, #0x5b]
    // 0xc86bb0: DecompressPointer r3
    //     0xc86bb0: add             x3, x3, HEAP, lsl #32
    // 0xc86bb4: cmp             w3, NULL
    // 0xc86bb8: b.ne            #0xc86bc4
    // 0xc86bbc: ldur            x4, [fp, #-0x58]
    // 0xc86bc0: b               #0xc86bc8
    // 0xc86bc4: mov             x4, x3
    // 0xc86bc8: ldr             x3, [fp, #0x18]
    // 0xc86bcc: stur            x4, [fp, #-0x78]
    // 0xc86bd0: LoadField: r5 = r3->field_5b
    //     0xc86bd0: ldur            w5, [x3, #0x5b]
    // 0xc86bd4: DecompressPointer r5
    //     0xc86bd4: add             x5, x5, HEAP, lsl #32
    // 0xc86bd8: cmp             w5, NULL
    // 0xc86bdc: b.ne            #0xc86be4
    // 0xc86be0: ldur            x5, [fp, #-0x50]
    // 0xc86be4: stur            x5, [fp, #-0x70]
    // 0xc86be8: r6 = LoadClassIdInstr(r4)
    //     0xc86be8: ldur            x6, [x4, #-1]
    //     0xc86bec: ubfx            x6, x6, #0xc, #0x14
    // 0xc86bf0: lsl             x6, x6, #1
    // 0xc86bf4: stur            x6, [fp, #-0x68]
    // 0xc86bf8: r17 = 10114
    //     0xc86bf8: mov             x17, #0x2782
    // 0xc86bfc: cmp             w6, w17
    // 0xc86c00: b.eq            #0xc86c10
    // 0xc86c04: r17 = 10118
    //     0xc86c04: mov             x17, #0x2786
    // 0xc86c08: cmp             w6, w17
    // 0xc86c0c: b.ne            #0xc86cec
    // 0xc86c10: cmp             w4, w5
    // 0xc86c14: b.ne            #0xc86c20
    // 0xc86c18: mov             x0, x2
    // 0xc86c1c: b               #0xc86d1c
    // 0xc86c20: stp             x4, x5, [SP, #-0x10]!
    // 0xc86c24: r0 = _haveSameRuntimeType()
    //     0xc86c24: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc86c28: add             SP, SP, #0x10
    // 0xc86c2c: tbnz            w0, #4, #0xc87658
    // 0xc86c30: ldur            x0, [fp, #-0x70]
    // 0xc86c34: r1 = LoadClassIdInstr(r0)
    //     0xc86c34: ldur            x1, [x0, #-1]
    //     0xc86c38: ubfx            x1, x1, #0xc, #0x14
    // 0xc86c3c: lsl             x1, x1, #1
    // 0xc86c40: r17 = 10124
    //     0xc86c40: mov             x17, #0x278c
    // 0xc86c44: cmp             w1, w17
    // 0xc86c48: b.gt            #0xc86c58
    // 0xc86c4c: r17 = 10122
    //     0xc86c4c: mov             x17, #0x278a
    // 0xc86c50: cmp             w1, w17
    // 0xc86c54: b.ge            #0xc86c70
    // 0xc86c58: r17 = 10114
    //     0xc86c58: mov             x17, #0x2782
    // 0xc86c5c: cmp             w1, w17
    // 0xc86c60: b.eq            #0xc86c70
    // 0xc86c64: r17 = 10118
    //     0xc86c64: mov             x17, #0x2786
    // 0xc86c68: cmp             w1, w17
    // 0xc86c6c: b.ne            #0xc86c78
    // 0xc86c70: LoadField: r1 = r0->field_7
    //     0xc86c70: ldur            x1, [x0, #7]
    // 0xc86c74: b               #0xc86c88
    // 0xc86c78: LoadField: r1 = r0->field_f
    //     0xc86c78: ldur            w1, [x0, #0xf]
    // 0xc86c7c: DecompressPointer r1
    //     0xc86c7c: add             x1, x1, HEAP, lsl #32
    // 0xc86c80: LoadField: r0 = r1->field_7
    //     0xc86c80: ldur            x0, [x1, #7]
    // 0xc86c84: mov             x1, x0
    // 0xc86c88: ldur            x0, [fp, #-0x68]
    // 0xc86c8c: r17 = 10124
    //     0xc86c8c: mov             x17, #0x278c
    // 0xc86c90: cmp             w0, w17
    // 0xc86c94: b.gt            #0xc86ca4
    // 0xc86c98: r17 = 10122
    //     0xc86c98: mov             x17, #0x278a
    // 0xc86c9c: cmp             w0, w17
    // 0xc86ca0: b.ge            #0xc86cbc
    // 0xc86ca4: r17 = 10114
    //     0xc86ca4: mov             x17, #0x2782
    // 0xc86ca8: cmp             w0, w17
    // 0xc86cac: b.eq            #0xc86cbc
    // 0xc86cb0: r17 = 10118
    //     0xc86cb0: mov             x17, #0x2786
    // 0xc86cb4: cmp             w0, w17
    // 0xc86cb8: b.ne            #0xc86cc8
    // 0xc86cbc: ldur            x2, [fp, #-0x78]
    // 0xc86cc0: LoadField: r0 = r2->field_7
    //     0xc86cc0: ldur            x0, [x2, #7]
    // 0xc86cc4: b               #0xc86cdc
    // 0xc86cc8: ldur            x2, [fp, #-0x78]
    // 0xc86ccc: LoadField: r0 = r2->field_f
    //     0xc86ccc: ldur            w0, [x2, #0xf]
    // 0xc86cd0: DecompressPointer r0
    //     0xc86cd0: add             x0, x0, HEAP, lsl #32
    // 0xc86cd4: LoadField: r2 = r0->field_7
    //     0xc86cd4: ldur            x2, [x0, #7]
    // 0xc86cd8: mov             x0, x2
    // 0xc86cdc: cmp             x1, x0
    // 0xc86ce0: b.ne            #0xc87658
    // 0xc86ce4: ldr             x0, [fp, #0x10]
    // 0xc86ce8: b               #0xc86d1c
    // 0xc86cec: mov             x2, x4
    // 0xc86cf0: mov             x0, x5
    // 0xc86cf4: r1 = LoadClassIdInstr(r2)
    //     0xc86cf4: ldur            x1, [x2, #-1]
    //     0xc86cf8: ubfx            x1, x1, #0xc, #0x14
    // 0xc86cfc: stp             x0, x2, [SP, #-0x10]!
    // 0xc86d00: mov             x0, x1
    // 0xc86d04: mov             lr, x0
    // 0xc86d08: ldr             lr, [x21, lr, lsl #3]
    // 0xc86d0c: blr             lr
    // 0xc86d10: add             SP, SP, #0x10
    // 0xc86d14: tbnz            w0, #4, #0xc87658
    // 0xc86d18: ldr             x0, [fp, #0x10]
    // 0xc86d1c: LoadField: r1 = r0->field_5f
    //     0xc86d1c: ldur            w1, [x0, #0x5f]
    // 0xc86d20: DecompressPointer r1
    //     0xc86d20: add             x1, x1, HEAP, lsl #32
    // 0xc86d24: cmp             w1, NULL
    // 0xc86d28: b.ne            #0xc86d34
    // 0xc86d2c: ldur            x2, [fp, #-0x60]
    // 0xc86d30: b               #0xc86d38
    // 0xc86d34: mov             x2, x1
    // 0xc86d38: ldr             x1, [fp, #0x18]
    // 0xc86d3c: stur            x2, [fp, #-0x70]
    // 0xc86d40: LoadField: r3 = r1->field_5f
    //     0xc86d40: ldur            w3, [x1, #0x5f]
    // 0xc86d44: DecompressPointer r3
    //     0xc86d44: add             x3, x3, HEAP, lsl #32
    // 0xc86d48: cmp             w3, NULL
    // 0xc86d4c: b.ne            #0xc86d54
    // 0xc86d50: ldur            x3, [fp, #-0x48]
    // 0xc86d54: stur            x3, [fp, #-0x68]
    // 0xc86d58: cmp             w2, w3
    // 0xc86d5c: b.eq            #0xc86d9c
    // 0xc86d60: r16 = Color
    //     0xc86d60: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86d64: ldr             x16, [x16, #0xf18]
    // 0xc86d68: r30 = Color
    //     0xc86d68: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86d6c: ldr             lr, [lr, #0xf18]
    // 0xc86d70: stp             lr, x16, [SP, #-0x10]!
    // 0xc86d74: r0 = ==()
    //     0xc86d74: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86d78: add             SP, SP, #0x10
    // 0xc86d7c: tbnz            w0, #4, #0xc87658
    // 0xc86d80: ldur            x0, [fp, #-0x70]
    // 0xc86d84: ldur            x1, [fp, #-0x68]
    // 0xc86d88: LoadField: r2 = r1->field_7
    //     0xc86d88: ldur            x2, [x1, #7]
    // 0xc86d8c: LoadField: r1 = r0->field_7
    //     0xc86d8c: ldur            x1, [x0, #7]
    // 0xc86d90: cmp             x2, x1
    // 0xc86d94: b.ne            #0xc87658
    // 0xc86d98: ldr             x0, [fp, #0x10]
    // 0xc86d9c: LoadField: r1 = r0->field_63
    //     0xc86d9c: ldur            w1, [x0, #0x63]
    // 0xc86da0: DecompressPointer r1
    //     0xc86da0: add             x1, x1, HEAP, lsl #32
    // 0xc86da4: cmp             w1, NULL
    // 0xc86da8: b.ne            #0xc86db4
    // 0xc86dac: ldur            x2, [fp, #-0x40]
    // 0xc86db0: b               #0xc86db8
    // 0xc86db4: mov             x2, x1
    // 0xc86db8: ldr             x1, [fp, #0x18]
    // 0xc86dbc: stur            x2, [fp, #-0x70]
    // 0xc86dc0: LoadField: r3 = r1->field_63
    //     0xc86dc0: ldur            w3, [x1, #0x63]
    // 0xc86dc4: DecompressPointer r3
    //     0xc86dc4: add             x3, x3, HEAP, lsl #32
    // 0xc86dc8: cmp             w3, NULL
    // 0xc86dcc: b.ne            #0xc86dd4
    // 0xc86dd0: ldur            x3, [fp, #-0x28]
    // 0xc86dd4: stur            x3, [fp, #-0x68]
    // 0xc86dd8: cmp             w2, w3
    // 0xc86ddc: b.eq            #0xc86e1c
    // 0xc86de0: r16 = Color
    //     0xc86de0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86de4: ldr             x16, [x16, #0xf18]
    // 0xc86de8: r30 = Color
    //     0xc86de8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86dec: ldr             lr, [lr, #0xf18]
    // 0xc86df0: stp             lr, x16, [SP, #-0x10]!
    // 0xc86df4: r0 = ==()
    //     0xc86df4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86df8: add             SP, SP, #0x10
    // 0xc86dfc: tbnz            w0, #4, #0xc87658
    // 0xc86e00: ldur            x0, [fp, #-0x70]
    // 0xc86e04: ldur            x1, [fp, #-0x68]
    // 0xc86e08: LoadField: r2 = r1->field_7
    //     0xc86e08: ldur            x2, [x1, #7]
    // 0xc86e0c: LoadField: r1 = r0->field_7
    //     0xc86e0c: ldur            x1, [x0, #7]
    // 0xc86e10: cmp             x2, x1
    // 0xc86e14: b.ne            #0xc87658
    // 0xc86e18: ldr             x0, [fp, #0x10]
    // 0xc86e1c: LoadField: r1 = r0->field_67
    //     0xc86e1c: ldur            w1, [x0, #0x67]
    // 0xc86e20: DecompressPointer r1
    //     0xc86e20: add             x1, x1, HEAP, lsl #32
    // 0xc86e24: cmp             w1, NULL
    // 0xc86e28: b.ne            #0xc86e34
    // 0xc86e2c: ldur            x2, [fp, #-0x40]
    // 0xc86e30: b               #0xc86e38
    // 0xc86e34: mov             x2, x1
    // 0xc86e38: ldr             x1, [fp, #0x18]
    // 0xc86e3c: stur            x2, [fp, #-0x40]
    // 0xc86e40: LoadField: r3 = r1->field_67
    //     0xc86e40: ldur            w3, [x1, #0x67]
    // 0xc86e44: DecompressPointer r3
    //     0xc86e44: add             x3, x3, HEAP, lsl #32
    // 0xc86e48: cmp             w3, NULL
    // 0xc86e4c: b.ne            #0xc86e54
    // 0xc86e50: ldur            x3, [fp, #-0x28]
    // 0xc86e54: stur            x3, [fp, #-0x28]
    // 0xc86e58: cmp             w2, w3
    // 0xc86e5c: b.eq            #0xc86e9c
    // 0xc86e60: r16 = Color
    //     0xc86e60: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86e64: ldr             x16, [x16, #0xf18]
    // 0xc86e68: r30 = Color
    //     0xc86e68: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86e6c: ldr             lr, [lr, #0xf18]
    // 0xc86e70: stp             lr, x16, [SP, #-0x10]!
    // 0xc86e74: r0 = ==()
    //     0xc86e74: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86e78: add             SP, SP, #0x10
    // 0xc86e7c: tbnz            w0, #4, #0xc87658
    // 0xc86e80: ldur            x0, [fp, #-0x40]
    // 0xc86e84: ldur            x1, [fp, #-0x28]
    // 0xc86e88: LoadField: r2 = r1->field_7
    //     0xc86e88: ldur            x2, [x1, #7]
    // 0xc86e8c: LoadField: r1 = r0->field_7
    //     0xc86e8c: ldur            x1, [x0, #7]
    // 0xc86e90: cmp             x2, x1
    // 0xc86e94: b.ne            #0xc87658
    // 0xc86e98: ldr             x0, [fp, #0x10]
    // 0xc86e9c: LoadField: r1 = r0->field_6b
    //     0xc86e9c: ldur            w1, [x0, #0x6b]
    // 0xc86ea0: DecompressPointer r1
    //     0xc86ea0: add             x1, x1, HEAP, lsl #32
    // 0xc86ea4: cmp             w1, NULL
    // 0xc86ea8: b.ne            #0xc86eb8
    // 0xc86eac: r2 = Instance_Color
    //     0xc86eac: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xc86eb0: ldr             x2, [x2, #0xf38]
    // 0xc86eb4: b               #0xc86ebc
    // 0xc86eb8: mov             x2, x1
    // 0xc86ebc: ldr             x1, [fp, #0x18]
    // 0xc86ec0: stur            x2, [fp, #-0x40]
    // 0xc86ec4: LoadField: r3 = r1->field_6b
    //     0xc86ec4: ldur            w3, [x1, #0x6b]
    // 0xc86ec8: DecompressPointer r3
    //     0xc86ec8: add             x3, x3, HEAP, lsl #32
    // 0xc86ecc: cmp             w3, NULL
    // 0xc86ed0: b.ne            #0xc86edc
    // 0xc86ed4: r3 = Instance_Color
    //     0xc86ed4: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xc86ed8: ldr             x3, [x3, #0xf38]
    // 0xc86edc: stur            x3, [fp, #-0x28]
    // 0xc86ee0: cmp             w2, w3
    // 0xc86ee4: b.eq            #0xc86f24
    // 0xc86ee8: r16 = Color
    //     0xc86ee8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86eec: ldr             x16, [x16, #0xf18]
    // 0xc86ef0: r30 = Color
    //     0xc86ef0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86ef4: ldr             lr, [lr, #0xf18]
    // 0xc86ef8: stp             lr, x16, [SP, #-0x10]!
    // 0xc86efc: r0 = ==()
    //     0xc86efc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86f00: add             SP, SP, #0x10
    // 0xc86f04: tbnz            w0, #4, #0xc87658
    // 0xc86f08: ldur            x0, [fp, #-0x40]
    // 0xc86f0c: ldur            x1, [fp, #-0x28]
    // 0xc86f10: LoadField: r2 = r1->field_7
    //     0xc86f10: ldur            x2, [x1, #7]
    // 0xc86f14: LoadField: r1 = r0->field_7
    //     0xc86f14: ldur            x1, [x0, #7]
    // 0xc86f18: cmp             x2, x1
    // 0xc86f1c: b.ne            #0xc87658
    // 0xc86f20: ldr             x0, [fp, #0x10]
    // 0xc86f24: LoadField: r1 = r0->field_6f
    //     0xc86f24: ldur            w1, [x0, #0x6f]
    // 0xc86f28: DecompressPointer r1
    //     0xc86f28: add             x1, x1, HEAP, lsl #32
    // 0xc86f2c: cmp             w1, NULL
    // 0xc86f30: b.ne            #0xc86f40
    // 0xc86f34: r2 = Instance_Color
    //     0xc86f34: add             x2, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xc86f38: ldr             x2, [x2, #0xf38]
    // 0xc86f3c: b               #0xc86f44
    // 0xc86f40: mov             x2, x1
    // 0xc86f44: ldr             x1, [fp, #0x18]
    // 0xc86f48: stur            x2, [fp, #-0x40]
    // 0xc86f4c: LoadField: r3 = r1->field_6f
    //     0xc86f4c: ldur            w3, [x1, #0x6f]
    // 0xc86f50: DecompressPointer r3
    //     0xc86f50: add             x3, x3, HEAP, lsl #32
    // 0xc86f54: cmp             w3, NULL
    // 0xc86f58: b.ne            #0xc86f64
    // 0xc86f5c: r3 = Instance_Color
    //     0xc86f5c: add             x3, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xc86f60: ldr             x3, [x3, #0xf38]
    // 0xc86f64: stur            x3, [fp, #-0x28]
    // 0xc86f68: cmp             w2, w3
    // 0xc86f6c: b.eq            #0xc86fac
    // 0xc86f70: r16 = Color
    //     0xc86f70: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86f74: ldr             x16, [x16, #0xf18]
    // 0xc86f78: r30 = Color
    //     0xc86f78: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86f7c: ldr             lr, [lr, #0xf18]
    // 0xc86f80: stp             lr, x16, [SP, #-0x10]!
    // 0xc86f84: r0 = ==()
    //     0xc86f84: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc86f88: add             SP, SP, #0x10
    // 0xc86f8c: tbnz            w0, #4, #0xc87658
    // 0xc86f90: ldur            x0, [fp, #-0x40]
    // 0xc86f94: ldur            x1, [fp, #-0x28]
    // 0xc86f98: LoadField: r2 = r1->field_7
    //     0xc86f98: ldur            x2, [x1, #7]
    // 0xc86f9c: LoadField: r1 = r0->field_7
    //     0xc86f9c: ldur            x1, [x0, #7]
    // 0xc86fa0: cmp             x2, x1
    // 0xc86fa4: b.ne            #0xc87658
    // 0xc86fa8: ldr             x0, [fp, #0x10]
    // 0xc86fac: LoadField: r1 = r0->field_73
    //     0xc86fac: ldur            w1, [x0, #0x73]
    // 0xc86fb0: DecompressPointer r1
    //     0xc86fb0: add             x1, x1, HEAP, lsl #32
    // 0xc86fb4: cmp             w1, NULL
    // 0xc86fb8: b.ne            #0xc86fc4
    // 0xc86fbc: ldur            x2, [fp, #-0x60]
    // 0xc86fc0: b               #0xc86fc8
    // 0xc86fc4: mov             x2, x1
    // 0xc86fc8: ldr             x1, [fp, #0x18]
    // 0xc86fcc: stur            x2, [fp, #-0x40]
    // 0xc86fd0: LoadField: r3 = r1->field_73
    //     0xc86fd0: ldur            w3, [x1, #0x73]
    // 0xc86fd4: DecompressPointer r3
    //     0xc86fd4: add             x3, x3, HEAP, lsl #32
    // 0xc86fd8: cmp             w3, NULL
    // 0xc86fdc: b.ne            #0xc86fe4
    // 0xc86fe0: ldur            x3, [fp, #-0x48]
    // 0xc86fe4: stur            x3, [fp, #-0x28]
    // 0xc86fe8: cmp             w2, w3
    // 0xc86fec: b.eq            #0xc8702c
    // 0xc86ff0: r16 = Color
    //     0xc86ff0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86ff4: ldr             x16, [x16, #0xf18]
    // 0xc86ff8: r30 = Color
    //     0xc86ff8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc86ffc: ldr             lr, [lr, #0xf18]
    // 0xc87000: stp             lr, x16, [SP, #-0x10]!
    // 0xc87004: r0 = ==()
    //     0xc87004: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc87008: add             SP, SP, #0x10
    // 0xc8700c: tbnz            w0, #4, #0xc87658
    // 0xc87010: ldur            x0, [fp, #-0x40]
    // 0xc87014: ldur            x1, [fp, #-0x28]
    // 0xc87018: LoadField: r2 = r1->field_7
    //     0xc87018: ldur            x2, [x1, #7]
    // 0xc8701c: LoadField: r1 = r0->field_7
    //     0xc8701c: ldur            x1, [x0, #7]
    // 0xc87020: cmp             x2, x1
    // 0xc87024: b.ne            #0xc87658
    // 0xc87028: ldr             x0, [fp, #0x10]
    // 0xc8702c: LoadField: r1 = r0->field_77
    //     0xc8702c: ldur            w1, [x0, #0x77]
    // 0xc87030: DecompressPointer r1
    //     0xc87030: add             x1, x1, HEAP, lsl #32
    // 0xc87034: cmp             w1, NULL
    // 0xc87038: b.ne            #0xc87044
    // 0xc8703c: ldur            x2, [fp, #-0x58]
    // 0xc87040: b               #0xc87048
    // 0xc87044: mov             x2, x1
    // 0xc87048: ldr             x1, [fp, #0x18]
    // 0xc8704c: stur            x2, [fp, #-0x48]
    // 0xc87050: LoadField: r3 = r1->field_77
    //     0xc87050: ldur            w3, [x1, #0x77]
    // 0xc87054: DecompressPointer r3
    //     0xc87054: add             x3, x3, HEAP, lsl #32
    // 0xc87058: cmp             w3, NULL
    // 0xc8705c: b.ne            #0xc87064
    // 0xc87060: ldur            x3, [fp, #-0x50]
    // 0xc87064: stur            x3, [fp, #-0x40]
    // 0xc87068: r4 = LoadClassIdInstr(r2)
    //     0xc87068: ldur            x4, [x2, #-1]
    //     0xc8706c: ubfx            x4, x4, #0xc, #0x14
    // 0xc87070: lsl             x4, x4, #1
    // 0xc87074: stur            x4, [fp, #-0x28]
    // 0xc87078: r17 = 10114
    //     0xc87078: mov             x17, #0x2782
    // 0xc8707c: cmp             w4, w17
    // 0xc87080: b.eq            #0xc87090
    // 0xc87084: r17 = 10118
    //     0xc87084: mov             x17, #0x2786
    // 0xc87088: cmp             w4, w17
    // 0xc8708c: b.ne            #0xc87164
    // 0xc87090: cmp             w2, w3
    // 0xc87094: b.eq            #0xc87190
    // 0xc87098: stp             x2, x3, [SP, #-0x10]!
    // 0xc8709c: r0 = _haveSameRuntimeType()
    //     0xc8709c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc870a0: add             SP, SP, #0x10
    // 0xc870a4: tbnz            w0, #4, #0xc87658
    // 0xc870a8: ldur            x0, [fp, #-0x40]
    // 0xc870ac: r1 = LoadClassIdInstr(r0)
    //     0xc870ac: ldur            x1, [x0, #-1]
    //     0xc870b0: ubfx            x1, x1, #0xc, #0x14
    // 0xc870b4: lsl             x1, x1, #1
    // 0xc870b8: r17 = 10124
    //     0xc870b8: mov             x17, #0x278c
    // 0xc870bc: cmp             w1, w17
    // 0xc870c0: b.gt            #0xc870d0
    // 0xc870c4: r17 = 10122
    //     0xc870c4: mov             x17, #0x278a
    // 0xc870c8: cmp             w1, w17
    // 0xc870cc: b.ge            #0xc870e8
    // 0xc870d0: r17 = 10114
    //     0xc870d0: mov             x17, #0x2782
    // 0xc870d4: cmp             w1, w17
    // 0xc870d8: b.eq            #0xc870e8
    // 0xc870dc: r17 = 10118
    //     0xc870dc: mov             x17, #0x2786
    // 0xc870e0: cmp             w1, w17
    // 0xc870e4: b.ne            #0xc870f0
    // 0xc870e8: LoadField: r1 = r0->field_7
    //     0xc870e8: ldur            x1, [x0, #7]
    // 0xc870ec: b               #0xc87100
    // 0xc870f0: LoadField: r1 = r0->field_f
    //     0xc870f0: ldur            w1, [x0, #0xf]
    // 0xc870f4: DecompressPointer r1
    //     0xc870f4: add             x1, x1, HEAP, lsl #32
    // 0xc870f8: LoadField: r0 = r1->field_7
    //     0xc870f8: ldur            x0, [x1, #7]
    // 0xc870fc: mov             x1, x0
    // 0xc87100: ldur            x0, [fp, #-0x28]
    // 0xc87104: r17 = 10124
    //     0xc87104: mov             x17, #0x278c
    // 0xc87108: cmp             w0, w17
    // 0xc8710c: b.gt            #0xc8711c
    // 0xc87110: r17 = 10122
    //     0xc87110: mov             x17, #0x278a
    // 0xc87114: cmp             w0, w17
    // 0xc87118: b.ge            #0xc87134
    // 0xc8711c: r17 = 10114
    //     0xc8711c: mov             x17, #0x2782
    // 0xc87120: cmp             w0, w17
    // 0xc87124: b.eq            #0xc87134
    // 0xc87128: r17 = 10118
    //     0xc87128: mov             x17, #0x2786
    // 0xc8712c: cmp             w0, w17
    // 0xc87130: b.ne            #0xc87140
    // 0xc87134: ldur            x2, [fp, #-0x48]
    // 0xc87138: LoadField: r0 = r2->field_7
    //     0xc87138: ldur            x0, [x2, #7]
    // 0xc8713c: b               #0xc87154
    // 0xc87140: ldur            x2, [fp, #-0x48]
    // 0xc87144: LoadField: r0 = r2->field_f
    //     0xc87144: ldur            w0, [x2, #0xf]
    // 0xc87148: DecompressPointer r0
    //     0xc87148: add             x0, x0, HEAP, lsl #32
    // 0xc8714c: LoadField: r2 = r0->field_7
    //     0xc8714c: ldur            x2, [x0, #7]
    // 0xc87150: mov             x0, x2
    // 0xc87154: cmp             x1, x0
    // 0xc87158: b.ne            #0xc87658
    // 0xc8715c: ldr             x0, [fp, #0x10]
    // 0xc87160: b               #0xc87190
    // 0xc87164: mov             x0, x3
    // 0xc87168: r1 = LoadClassIdInstr(r2)
    //     0xc87168: ldur            x1, [x2, #-1]
    //     0xc8716c: ubfx            x1, x1, #0xc, #0x14
    // 0xc87170: stp             x0, x2, [SP, #-0x10]!
    // 0xc87174: mov             x0, x1
    // 0xc87178: mov             lr, x0
    // 0xc8717c: ldr             lr, [x21, lr, lsl #3]
    // 0xc87180: blr             lr
    // 0xc87184: add             SP, SP, #0x10
    // 0xc87188: tbnz            w0, #4, #0xc87658
    // 0xc8718c: ldr             x0, [fp, #0x10]
    // 0xc87190: LoadField: r1 = r0->field_7b
    //     0xc87190: ldur            w1, [x0, #0x7b]
    // 0xc87194: DecompressPointer r1
    //     0xc87194: add             x1, x1, HEAP, lsl #32
    // 0xc87198: cmp             w1, NULL
    // 0xc8719c: b.ne            #0xc871a8
    // 0xc871a0: ldur            x2, [fp, #-0x20]
    // 0xc871a4: b               #0xc871ac
    // 0xc871a8: mov             x2, x1
    // 0xc871ac: ldr             x1, [fp, #0x18]
    // 0xc871b0: stur            x2, [fp, #-0x20]
    // 0xc871b4: LoadField: r3 = r1->field_7b
    //     0xc871b4: ldur            w3, [x1, #0x7b]
    // 0xc871b8: DecompressPointer r3
    //     0xc871b8: add             x3, x3, HEAP, lsl #32
    // 0xc871bc: cmp             w3, NULL
    // 0xc871c0: b.ne            #0xc871c8
    // 0xc871c4: ldur            x3, [fp, #-8]
    // 0xc871c8: stur            x3, [fp, #-8]
    // 0xc871cc: cmp             w2, w3
    // 0xc871d0: b.eq            #0xc87210
    // 0xc871d4: r16 = Color
    //     0xc871d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc871d8: ldr             x16, [x16, #0xf18]
    // 0xc871dc: r30 = Color
    //     0xc871dc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc871e0: ldr             lr, [lr, #0xf18]
    // 0xc871e4: stp             lr, x16, [SP, #-0x10]!
    // 0xc871e8: r0 = ==()
    //     0xc871e8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc871ec: add             SP, SP, #0x10
    // 0xc871f0: tbnz            w0, #4, #0xc87658
    // 0xc871f4: ldur            x0, [fp, #-0x20]
    // 0xc871f8: ldur            x1, [fp, #-8]
    // 0xc871fc: LoadField: r2 = r1->field_7
    //     0xc871fc: ldur            x2, [x1, #7]
    // 0xc87200: LoadField: r1 = r0->field_7
    //     0xc87200: ldur            x1, [x0, #7]
    // 0xc87204: cmp             x2, x1
    // 0xc87208: b.ne            #0xc87658
    // 0xc8720c: ldr             x0, [fp, #0x10]
    // 0xc87210: LoadField: r1 = r0->field_83
    //     0xc87210: ldur            w1, [x0, #0x83]
    // 0xc87214: DecompressPointer r1
    //     0xc87214: add             x1, x1, HEAP, lsl #32
    // 0xc87218: cmp             w1, NULL
    // 0xc8721c: b.ne            #0xc87228
    // 0xc87220: ldur            x2, [fp, #-0x18]
    // 0xc87224: b               #0xc8722c
    // 0xc87228: mov             x2, x1
    // 0xc8722c: ldr             x1, [fp, #0x18]
    // 0xc87230: stur            x2, [fp, #-0x28]
    // 0xc87234: LoadField: r3 = r1->field_83
    //     0xc87234: ldur            w3, [x1, #0x83]
    // 0xc87238: DecompressPointer r3
    //     0xc87238: add             x3, x3, HEAP, lsl #32
    // 0xc8723c: cmp             w3, NULL
    // 0xc87240: b.ne            #0xc87248
    // 0xc87244: ldur            x3, [fp, #-0x10]
    // 0xc87248: stur            x3, [fp, #-0x20]
    // 0xc8724c: r4 = LoadClassIdInstr(r2)
    //     0xc8724c: ldur            x4, [x2, #-1]
    //     0xc87250: ubfx            x4, x4, #0xc, #0x14
    // 0xc87254: lsl             x4, x4, #1
    // 0xc87258: stur            x4, [fp, #-8]
    // 0xc8725c: r17 = 10114
    //     0xc8725c: mov             x17, #0x2782
    // 0xc87260: cmp             w4, w17
    // 0xc87264: b.eq            #0xc87274
    // 0xc87268: r17 = 10118
    //     0xc87268: mov             x17, #0x2786
    // 0xc8726c: cmp             w4, w17
    // 0xc87270: b.ne            #0xc87348
    // 0xc87274: cmp             w2, w3
    // 0xc87278: b.eq            #0xc87374
    // 0xc8727c: stp             x2, x3, [SP, #-0x10]!
    // 0xc87280: r0 = _haveSameRuntimeType()
    //     0xc87280: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc87284: add             SP, SP, #0x10
    // 0xc87288: tbnz            w0, #4, #0xc87658
    // 0xc8728c: ldur            x0, [fp, #-0x20]
    // 0xc87290: r1 = LoadClassIdInstr(r0)
    //     0xc87290: ldur            x1, [x0, #-1]
    //     0xc87294: ubfx            x1, x1, #0xc, #0x14
    // 0xc87298: lsl             x1, x1, #1
    // 0xc8729c: r17 = 10124
    //     0xc8729c: mov             x17, #0x278c
    // 0xc872a0: cmp             w1, w17
    // 0xc872a4: b.gt            #0xc872b4
    // 0xc872a8: r17 = 10122
    //     0xc872a8: mov             x17, #0x278a
    // 0xc872ac: cmp             w1, w17
    // 0xc872b0: b.ge            #0xc872cc
    // 0xc872b4: r17 = 10114
    //     0xc872b4: mov             x17, #0x2782
    // 0xc872b8: cmp             w1, w17
    // 0xc872bc: b.eq            #0xc872cc
    // 0xc872c0: r17 = 10118
    //     0xc872c0: mov             x17, #0x2786
    // 0xc872c4: cmp             w1, w17
    // 0xc872c8: b.ne            #0xc872d4
    // 0xc872cc: LoadField: r1 = r0->field_7
    //     0xc872cc: ldur            x1, [x0, #7]
    // 0xc872d0: b               #0xc872e4
    // 0xc872d4: LoadField: r1 = r0->field_f
    //     0xc872d4: ldur            w1, [x0, #0xf]
    // 0xc872d8: DecompressPointer r1
    //     0xc872d8: add             x1, x1, HEAP, lsl #32
    // 0xc872dc: LoadField: r0 = r1->field_7
    //     0xc872dc: ldur            x0, [x1, #7]
    // 0xc872e0: mov             x1, x0
    // 0xc872e4: ldur            x0, [fp, #-8]
    // 0xc872e8: r17 = 10124
    //     0xc872e8: mov             x17, #0x278c
    // 0xc872ec: cmp             w0, w17
    // 0xc872f0: b.gt            #0xc87300
    // 0xc872f4: r17 = 10122
    //     0xc872f4: mov             x17, #0x278a
    // 0xc872f8: cmp             w0, w17
    // 0xc872fc: b.ge            #0xc87318
    // 0xc87300: r17 = 10114
    //     0xc87300: mov             x17, #0x2782
    // 0xc87304: cmp             w0, w17
    // 0xc87308: b.eq            #0xc87318
    // 0xc8730c: r17 = 10118
    //     0xc8730c: mov             x17, #0x2786
    // 0xc87310: cmp             w0, w17
    // 0xc87314: b.ne            #0xc87324
    // 0xc87318: ldur            x2, [fp, #-0x28]
    // 0xc8731c: LoadField: r0 = r2->field_7
    //     0xc8731c: ldur            x0, [x2, #7]
    // 0xc87320: b               #0xc87338
    // 0xc87324: ldur            x2, [fp, #-0x28]
    // 0xc87328: LoadField: r0 = r2->field_f
    //     0xc87328: ldur            w0, [x2, #0xf]
    // 0xc8732c: DecompressPointer r0
    //     0xc8732c: add             x0, x0, HEAP, lsl #32
    // 0xc87330: LoadField: r2 = r0->field_7
    //     0xc87330: ldur            x2, [x0, #7]
    // 0xc87334: mov             x0, x2
    // 0xc87338: cmp             x1, x0
    // 0xc8733c: b.ne            #0xc87658
    // 0xc87340: ldr             x0, [fp, #0x10]
    // 0xc87344: b               #0xc87374
    // 0xc87348: mov             x0, x3
    // 0xc8734c: r1 = LoadClassIdInstr(r2)
    //     0xc8734c: ldur            x1, [x2, #-1]
    //     0xc87350: ubfx            x1, x1, #0xc, #0x14
    // 0xc87354: stp             x0, x2, [SP, #-0x10]!
    // 0xc87358: mov             x0, x1
    // 0xc8735c: mov             lr, x0
    // 0xc87360: ldr             lr, [x21, lr, lsl #3]
    // 0xc87364: blr             lr
    // 0xc87368: add             SP, SP, #0x10
    // 0xc8736c: tbnz            w0, #4, #0xc87658
    // 0xc87370: ldr             x0, [fp, #0x10]
    // 0xc87374: LoadField: r1 = r0->field_87
    //     0xc87374: ldur            w1, [x0, #0x87]
    // 0xc87378: DecompressPointer r1
    //     0xc87378: add             x1, x1, HEAP, lsl #32
    // 0xc8737c: cmp             w1, NULL
    // 0xc87380: b.ne            #0xc8738c
    // 0xc87384: ldur            x2, [fp, #-0x38]
    // 0xc87388: b               #0xc87390
    // 0xc8738c: mov             x2, x1
    // 0xc87390: ldr             x1, [fp, #0x18]
    // 0xc87394: stur            x2, [fp, #-0x28]
    // 0xc87398: LoadField: r3 = r1->field_87
    //     0xc87398: ldur            w3, [x1, #0x87]
    // 0xc8739c: DecompressPointer r3
    //     0xc8739c: add             x3, x3, HEAP, lsl #32
    // 0xc873a0: cmp             w3, NULL
    // 0xc873a4: b.ne            #0xc873ac
    // 0xc873a8: ldur            x3, [fp, #-0x30]
    // 0xc873ac: stur            x3, [fp, #-0x20]
    // 0xc873b0: r4 = LoadClassIdInstr(r2)
    //     0xc873b0: ldur            x4, [x2, #-1]
    //     0xc873b4: ubfx            x4, x4, #0xc, #0x14
    // 0xc873b8: lsl             x4, x4, #1
    // 0xc873bc: stur            x4, [fp, #-8]
    // 0xc873c0: r17 = 10114
    //     0xc873c0: mov             x17, #0x2782
    // 0xc873c4: cmp             w4, w17
    // 0xc873c8: b.eq            #0xc873d8
    // 0xc873cc: r17 = 10118
    //     0xc873cc: mov             x17, #0x2786
    // 0xc873d0: cmp             w4, w17
    // 0xc873d4: b.ne            #0xc874ac
    // 0xc873d8: cmp             w2, w3
    // 0xc873dc: b.eq            #0xc874d8
    // 0xc873e0: stp             x2, x3, [SP, #-0x10]!
    // 0xc873e4: r0 = _haveSameRuntimeType()
    //     0xc873e4: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc873e8: add             SP, SP, #0x10
    // 0xc873ec: tbnz            w0, #4, #0xc87658
    // 0xc873f0: ldur            x0, [fp, #-0x20]
    // 0xc873f4: r1 = LoadClassIdInstr(r0)
    //     0xc873f4: ldur            x1, [x0, #-1]
    //     0xc873f8: ubfx            x1, x1, #0xc, #0x14
    // 0xc873fc: lsl             x1, x1, #1
    // 0xc87400: r17 = 10124
    //     0xc87400: mov             x17, #0x278c
    // 0xc87404: cmp             w1, w17
    // 0xc87408: b.gt            #0xc87418
    // 0xc8740c: r17 = 10122
    //     0xc8740c: mov             x17, #0x278a
    // 0xc87410: cmp             w1, w17
    // 0xc87414: b.ge            #0xc87430
    // 0xc87418: r17 = 10114
    //     0xc87418: mov             x17, #0x2782
    // 0xc8741c: cmp             w1, w17
    // 0xc87420: b.eq            #0xc87430
    // 0xc87424: r17 = 10118
    //     0xc87424: mov             x17, #0x2786
    // 0xc87428: cmp             w1, w17
    // 0xc8742c: b.ne            #0xc87438
    // 0xc87430: LoadField: r1 = r0->field_7
    //     0xc87430: ldur            x1, [x0, #7]
    // 0xc87434: b               #0xc87448
    // 0xc87438: LoadField: r1 = r0->field_f
    //     0xc87438: ldur            w1, [x0, #0xf]
    // 0xc8743c: DecompressPointer r1
    //     0xc8743c: add             x1, x1, HEAP, lsl #32
    // 0xc87440: LoadField: r0 = r1->field_7
    //     0xc87440: ldur            x0, [x1, #7]
    // 0xc87444: mov             x1, x0
    // 0xc87448: ldur            x0, [fp, #-8]
    // 0xc8744c: r17 = 10124
    //     0xc8744c: mov             x17, #0x278c
    // 0xc87450: cmp             w0, w17
    // 0xc87454: b.gt            #0xc87464
    // 0xc87458: r17 = 10122
    //     0xc87458: mov             x17, #0x278a
    // 0xc8745c: cmp             w0, w17
    // 0xc87460: b.ge            #0xc8747c
    // 0xc87464: r17 = 10114
    //     0xc87464: mov             x17, #0x2782
    // 0xc87468: cmp             w0, w17
    // 0xc8746c: b.eq            #0xc8747c
    // 0xc87470: r17 = 10118
    //     0xc87470: mov             x17, #0x2786
    // 0xc87474: cmp             w0, w17
    // 0xc87478: b.ne            #0xc87488
    // 0xc8747c: ldur            x2, [fp, #-0x28]
    // 0xc87480: LoadField: r0 = r2->field_7
    //     0xc87480: ldur            x0, [x2, #7]
    // 0xc87484: b               #0xc8749c
    // 0xc87488: ldur            x2, [fp, #-0x28]
    // 0xc8748c: LoadField: r0 = r2->field_f
    //     0xc8748c: ldur            w0, [x2, #0xf]
    // 0xc87490: DecompressPointer r0
    //     0xc87490: add             x0, x0, HEAP, lsl #32
    // 0xc87494: LoadField: r2 = r0->field_7
    //     0xc87494: ldur            x2, [x0, #7]
    // 0xc87498: mov             x0, x2
    // 0xc8749c: cmp             x1, x0
    // 0xc874a0: b.ne            #0xc87658
    // 0xc874a4: ldr             x0, [fp, #0x10]
    // 0xc874a8: b               #0xc874d8
    // 0xc874ac: mov             x0, x3
    // 0xc874b0: r1 = LoadClassIdInstr(r2)
    //     0xc874b0: ldur            x1, [x2, #-1]
    //     0xc874b4: ubfx            x1, x1, #0xc, #0x14
    // 0xc874b8: stp             x0, x2, [SP, #-0x10]!
    // 0xc874bc: mov             x0, x1
    // 0xc874c0: mov             lr, x0
    // 0xc874c4: ldr             lr, [x21, lr, lsl #3]
    // 0xc874c8: blr             lr
    // 0xc874cc: add             SP, SP, #0x10
    // 0xc874d0: tbnz            w0, #4, #0xc87658
    // 0xc874d4: ldr             x0, [fp, #0x10]
    // 0xc874d8: LoadField: r1 = r0->field_7f
    //     0xc874d8: ldur            w1, [x0, #0x7f]
    // 0xc874dc: DecompressPointer r1
    //     0xc874dc: add             x1, x1, HEAP, lsl #32
    // 0xc874e0: cmp             w1, NULL
    // 0xc874e4: b.ne            #0xc874ec
    // 0xc874e8: ldur            x1, [fp, #-0x18]
    // 0xc874ec: ldr             x0, [fp, #0x18]
    // 0xc874f0: stur            x1, [fp, #-0x18]
    // 0xc874f4: LoadField: r2 = r0->field_7f
    //     0xc874f4: ldur            w2, [x0, #0x7f]
    // 0xc874f8: DecompressPointer r2
    //     0xc874f8: add             x2, x2, HEAP, lsl #32
    // 0xc874fc: cmp             w2, NULL
    // 0xc87500: b.ne            #0xc8750c
    // 0xc87504: ldur            x0, [fp, #-0x10]
    // 0xc87508: b               #0xc87510
    // 0xc8750c: mov             x0, x2
    // 0xc87510: stur            x0, [fp, #-0x10]
    // 0xc87514: r2 = LoadClassIdInstr(r1)
    //     0xc87514: ldur            x2, [x1, #-1]
    //     0xc87518: ubfx            x2, x2, #0xc, #0x14
    // 0xc8751c: lsl             x2, x2, #1
    // 0xc87520: stur            x2, [fp, #-8]
    // 0xc87524: r17 = 10114
    //     0xc87524: mov             x17, #0x2782
    // 0xc87528: cmp             w2, w17
    // 0xc8752c: b.eq            #0xc8753c
    // 0xc87530: r17 = 10118
    //     0xc87530: mov             x17, #0x2786
    // 0xc87534: cmp             w2, w17
    // 0xc87538: b.ne            #0xc87628
    // 0xc8753c: cmp             w1, w0
    // 0xc87540: b.ne            #0xc8754c
    // 0xc87544: r1 = true
    //     0xc87544: add             x1, NULL, #0x20  ; true
    // 0xc87548: b               #0xc87650
    // 0xc8754c: stp             x1, x0, [SP, #-0x10]!
    // 0xc87550: r0 = _haveSameRuntimeType()
    //     0xc87550: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc87554: add             SP, SP, #0x10
    // 0xc87558: tbz             w0, #4, #0xc87564
    // 0xc8755c: r1 = false
    //     0xc8755c: add             x1, NULL, #0x30  ; false
    // 0xc87560: b               #0xc87650
    // 0xc87564: ldur            x0, [fp, #-0x10]
    // 0xc87568: r1 = LoadClassIdInstr(r0)
    //     0xc87568: ldur            x1, [x0, #-1]
    //     0xc8756c: ubfx            x1, x1, #0xc, #0x14
    // 0xc87570: lsl             x1, x1, #1
    // 0xc87574: r17 = 10124
    //     0xc87574: mov             x17, #0x278c
    // 0xc87578: cmp             w1, w17
    // 0xc8757c: b.gt            #0xc8758c
    // 0xc87580: r17 = 10122
    //     0xc87580: mov             x17, #0x278a
    // 0xc87584: cmp             w1, w17
    // 0xc87588: b.ge            #0xc875a4
    // 0xc8758c: r17 = 10114
    //     0xc8758c: mov             x17, #0x2782
    // 0xc87590: cmp             w1, w17
    // 0xc87594: b.eq            #0xc875a4
    // 0xc87598: r17 = 10118
    //     0xc87598: mov             x17, #0x2786
    // 0xc8759c: cmp             w1, w17
    // 0xc875a0: b.ne            #0xc875ac
    // 0xc875a4: LoadField: r1 = r0->field_7
    //     0xc875a4: ldur            x1, [x0, #7]
    // 0xc875a8: b               #0xc875bc
    // 0xc875ac: LoadField: r1 = r0->field_f
    //     0xc875ac: ldur            w1, [x0, #0xf]
    // 0xc875b0: DecompressPointer r1
    //     0xc875b0: add             x1, x1, HEAP, lsl #32
    // 0xc875b4: LoadField: r0 = r1->field_7
    //     0xc875b4: ldur            x0, [x1, #7]
    // 0xc875b8: mov             x1, x0
    // 0xc875bc: ldur            x0, [fp, #-8]
    // 0xc875c0: r17 = 10124
    //     0xc875c0: mov             x17, #0x278c
    // 0xc875c4: cmp             w0, w17
    // 0xc875c8: b.gt            #0xc875d8
    // 0xc875cc: r17 = 10122
    //     0xc875cc: mov             x17, #0x278a
    // 0xc875d0: cmp             w0, w17
    // 0xc875d4: b.ge            #0xc875f0
    // 0xc875d8: r17 = 10114
    //     0xc875d8: mov             x17, #0x2782
    // 0xc875dc: cmp             w0, w17
    // 0xc875e0: b.eq            #0xc875f0
    // 0xc875e4: r17 = 10118
    //     0xc875e4: mov             x17, #0x2786
    // 0xc875e8: cmp             w0, w17
    // 0xc875ec: b.ne            #0xc875fc
    // 0xc875f0: ldur            x2, [fp, #-0x18]
    // 0xc875f4: LoadField: r0 = r2->field_7
    //     0xc875f4: ldur            x0, [x2, #7]
    // 0xc875f8: b               #0xc87610
    // 0xc875fc: ldur            x2, [fp, #-0x18]
    // 0xc87600: LoadField: r0 = r2->field_f
    //     0xc87600: ldur            w0, [x2, #0xf]
    // 0xc87604: DecompressPointer r0
    //     0xc87604: add             x0, x0, HEAP, lsl #32
    // 0xc87608: LoadField: r2 = r0->field_7
    //     0xc87608: ldur            x2, [x0, #7]
    // 0xc8760c: mov             x0, x2
    // 0xc87610: cmp             x1, x0
    // 0xc87614: r16 = true
    //     0xc87614: add             x16, NULL, #0x20  ; true
    // 0xc87618: r17 = false
    //     0xc87618: add             x17, NULL, #0x30  ; false
    // 0xc8761c: csel            x2, x16, x17, eq
    // 0xc87620: mov             x1, x2
    // 0xc87624: b               #0xc87650
    // 0xc87628: mov             x2, x1
    // 0xc8762c: r1 = LoadClassIdInstr(r2)
    //     0xc8762c: ldur            x1, [x2, #-1]
    //     0xc87630: ubfx            x1, x1, #0xc, #0x14
    // 0xc87634: stp             x0, x2, [SP, #-0x10]!
    // 0xc87638: mov             x0, x1
    // 0xc8763c: mov             lr, x0
    // 0xc87640: ldr             lr, [x21, lr, lsl #3]
    // 0xc87644: blr             lr
    // 0xc87648: add             SP, SP, #0x10
    // 0xc8764c: mov             x1, x0
    // 0xc87650: mov             x0, x1
    // 0xc87654: b               #0xc8765c
    // 0xc87658: r0 = false
    //     0xc87658: add             x0, NULL, #0x30  ; false
    // 0xc8765c: LeaveFrame
    //     0xc8765c: mov             SP, fp
    //     0xc87660: ldp             fp, lr, [SP], #0x10
    // 0xc87664: ret
    //     0xc87664: ret             
    // 0xc87668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc87668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8766c: b               #0xc8589c
  }
}

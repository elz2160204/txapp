// lib: , url: package:flutter/src/material/button_style_button.dart

// class id: 1049198, size: 0x8
class :: {
}

// class id: 2461, size: 0x68, field offset: 0x64
class _RenderInputPadding extends RenderShiftedBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f4f4, size: 0x18
    // 0x62f4f4: r4 = 0
    //     0x62f4f4: mov             x4, #0
    // 0x62f4f8: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f4f8: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b8f8] AnonymousClosure: (0x62f50c), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicHeight (0x62f400)
    //     0x62f4fc: ldr             x1, [x17, #0x8f8]
    // 0x62f500: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f500: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f504: LoadField: r0 = r24->field_17
    //     0x62f504: ldur            x0, [x24, #0x17]
    // 0x62f508: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f50c, size: 0x4c
    // 0x62f50c: EnterFrame
    //     0x62f50c: stp             fp, lr, [SP, #-0x10]!
    //     0x62f510: mov             fp, SP
    // 0x62f514: ldr             x0, [fp, #0x18]
    // 0x62f518: LoadField: r1 = r0->field_17
    //     0x62f518: ldur            w1, [x0, #0x17]
    // 0x62f51c: DecompressPointer r1
    //     0x62f51c: add             x1, x1, HEAP, lsl #32
    // 0x62f520: CheckStackOverflow
    //     0x62f520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f524: cmp             SP, x16
    //     0x62f528: b.ls            #0x62f550
    // 0x62f52c: LoadField: r0 = r1->field_f
    //     0x62f52c: ldur            w0, [x1, #0xf]
    // 0x62f530: DecompressPointer r0
    //     0x62f530: add             x0, x0, HEAP, lsl #32
    // 0x62f534: ldr             x16, [fp, #0x10]
    // 0x62f538: stp             x16, x0, [SP, #-0x10]!
    // 0x62f53c: r0 = computeMaxIntrinsicHeight()
    //     0x62f53c: bl              #0x62f400  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicHeight
    // 0x62f540: add             SP, SP, #0x10
    // 0x62f544: LeaveFrame
    //     0x62f544: mov             SP, fp
    //     0x62f548: ldp             fp, lr, [SP], #0x10
    // 0x62f54c: ret
    //     0x62f54c: ret             
    // 0x62f550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f550: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f554: b               #0x62f52c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x635f0c, size: 0x18
    // 0x635f0c: r4 = 0
    //     0x635f0c: mov             x4, #0
    // 0x635f10: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635f10: add             x17, PP, #0x40, lsl #12  ; [pp+0x401f0] AnonymousClosure: (0x635f24), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicWidth (0x635e18)
    //     0x635f14: ldr             x1, [x17, #0x1f0]
    // 0x635f18: r24 = BuildNonGenericMethodExtractorStub
    //     0x635f18: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635f1c: LoadField: r0 = r24->field_17
    //     0x635f1c: ldur            x0, [x24, #0x17]
    // 0x635f20: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635f24, size: 0x4c
    // 0x635f24: EnterFrame
    //     0x635f24: stp             fp, lr, [SP, #-0x10]!
    //     0x635f28: mov             fp, SP
    // 0x635f2c: ldr             x0, [fp, #0x18]
    // 0x635f30: LoadField: r1 = r0->field_17
    //     0x635f30: ldur            w1, [x0, #0x17]
    // 0x635f34: DecompressPointer r1
    //     0x635f34: add             x1, x1, HEAP, lsl #32
    // 0x635f38: CheckStackOverflow
    //     0x635f38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635f3c: cmp             SP, x16
    //     0x635f40: b.ls            #0x635f68
    // 0x635f44: LoadField: r0 = r1->field_f
    //     0x635f44: ldur            w0, [x1, #0xf]
    // 0x635f48: DecompressPointer r0
    //     0x635f48: add             x0, x0, HEAP, lsl #32
    // 0x635f4c: ldr             x16, [fp, #0x10]
    // 0x635f50: stp             x16, x0, [SP, #-0x10]!
    // 0x635f54: r0 = computeMaxIntrinsicWidth()
    //     0x635f54: bl              #0x635e18  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicWidth
    // 0x635f58: add             SP, SP, #0x10
    // 0x635f5c: LeaveFrame
    //     0x635f5c: mov             SP, fp
    //     0x635f60: ldp             fp, lr, [SP], #0x10
    // 0x635f64: ret
    //     0x635f64: ret             
    // 0x635f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635f6c: b               #0x635f44
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x639158, size: 0x18
    // 0x639158: r4 = 0
    //     0x639158: mov             x4, #0
    // 0x63915c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x63915c: add             x17, PP, #0x53, lsl #12  ; [pp+0x532b0] AnonymousClosure: (0x639170), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicHeight (0x639064)
    //     0x639160: ldr             x1, [x17, #0x2b0]
    // 0x639164: r24 = BuildNonGenericMethodExtractorStub
    //     0x639164: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x639168: LoadField: r0 = r24->field_17
    //     0x639168: ldur            x0, [x24, #0x17]
    // 0x63916c: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x639170, size: 0x4c
    // 0x639170: EnterFrame
    //     0x639170: stp             fp, lr, [SP, #-0x10]!
    //     0x639174: mov             fp, SP
    // 0x639178: ldr             x0, [fp, #0x18]
    // 0x63917c: LoadField: r1 = r0->field_17
    //     0x63917c: ldur            w1, [x0, #0x17]
    // 0x639180: DecompressPointer r1
    //     0x639180: add             x1, x1, HEAP, lsl #32
    // 0x639184: CheckStackOverflow
    //     0x639184: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x639188: cmp             SP, x16
    //     0x63918c: b.ls            #0x6391b4
    // 0x639190: LoadField: r0 = r1->field_f
    //     0x639190: ldur            w0, [x1, #0xf]
    // 0x639194: DecompressPointer r0
    //     0x639194: add             x0, x0, HEAP, lsl #32
    // 0x639198: ldr             x16, [fp, #0x10]
    // 0x63919c: stp             x16, x0, [SP, #-0x10]!
    // 0x6391a0: r0 = computeMinIntrinsicHeight()
    //     0x6391a0: bl              #0x639064  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicHeight
    // 0x6391a4: add             SP, SP, #0x10
    // 0x6391a8: LeaveFrame
    //     0x6391a8: mov             SP, fp
    //     0x6391ac: ldp             fp, lr, [SP], #0x10
    // 0x6391b0: ret
    //     0x6391b0: ret             
    // 0x6391b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6391b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6391b8: b               #0x639190
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63bd94, size: 0x18
    // 0x63bd94: r4 = 0
    //     0x63bd94: mov             x4, #0
    // 0x63bd98: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63bd98: add             x17, PP, #0x50, lsl #12  ; [pp+0x50cd8] AnonymousClosure: (0x63bdac), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth (0x63bca0)
    //     0x63bd9c: ldr             x1, [x17, #0xcd8]
    // 0x63bda0: r24 = BuildNonGenericMethodExtractorStub
    //     0x63bda0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63bda4: LoadField: r0 = r24->field_17
    //     0x63bda4: ldur            x0, [x24, #0x17]
    // 0x63bda8: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63bdac, size: 0x4c
    // 0x63bdac: EnterFrame
    //     0x63bdac: stp             fp, lr, [SP, #-0x10]!
    //     0x63bdb0: mov             fp, SP
    // 0x63bdb4: ldr             x0, [fp, #0x18]
    // 0x63bdb8: LoadField: r1 = r0->field_17
    //     0x63bdb8: ldur            w1, [x0, #0x17]
    // 0x63bdbc: DecompressPointer r1
    //     0x63bdbc: add             x1, x1, HEAP, lsl #32
    // 0x63bdc0: CheckStackOverflow
    //     0x63bdc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63bdc4: cmp             SP, x16
    //     0x63bdc8: b.ls            #0x63bdf0
    // 0x63bdcc: LoadField: r0 = r1->field_f
    //     0x63bdcc: ldur            w0, [x1, #0xf]
    // 0x63bdd0: DecompressPointer r0
    //     0x63bdd0: add             x0, x0, HEAP, lsl #32
    // 0x63bdd4: ldr             x16, [fp, #0x10]
    // 0x63bdd8: stp             x16, x0, [SP, #-0x10]!
    // 0x63bddc: r0 = computeMinIntrinsicWidth()
    //     0x63bddc: bl              #0x63bca0  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth
    // 0x63bde0: add             SP, SP, #0x10
    // 0x63bde4: LeaveFrame
    //     0x63bde4: mov             SP, fp
    //     0x63bde8: ldp             fp, lr, [SP], #0x10
    // 0x63bdec: ret
    //     0x63bdec: ret             
    // 0x63bdf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63bdf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63bdf4: b               #0x63bdcc
  }
  [closure] bool <anonymous closure>(dynamic, BoxHitTestResult, Offset) {
    // ** addr: 0x64088c, size: 0x84
    // 0x64088c: EnterFrame
    //     0x64088c: stp             fp, lr, [SP, #-0x10]!
    //     0x640890: mov             fp, SP
    // 0x640894: ldr             x0, [fp, #0x20]
    // 0x640898: LoadField: r1 = r0->field_17
    //     0x640898: ldur            w1, [x0, #0x17]
    // 0x64089c: DecompressPointer r1
    //     0x64089c: add             x1, x1, HEAP, lsl #32
    // 0x6408a0: CheckStackOverflow
    //     0x6408a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6408a4: cmp             SP, x16
    //     0x6408a8: b.ls            #0x640904
    // 0x6408ac: LoadField: r0 = r1->field_f
    //     0x6408ac: ldur            w0, [x1, #0xf]
    // 0x6408b0: DecompressPointer r0
    //     0x6408b0: add             x0, x0, HEAP, lsl #32
    // 0x6408b4: LoadField: r2 = r0->field_5f
    //     0x6408b4: ldur            w2, [x0, #0x5f]
    // 0x6408b8: DecompressPointer r2
    //     0x6408b8: add             x2, x2, HEAP, lsl #32
    // 0x6408bc: cmp             w2, NULL
    // 0x6408c0: b.eq            #0x64090c
    // 0x6408c4: LoadField: r0 = r1->field_13
    //     0x6408c4: ldur            w0, [x1, #0x13]
    // 0x6408c8: DecompressPointer r0
    //     0x6408c8: add             x0, x0, HEAP, lsl #32
    // 0x6408cc: r1 = LoadClassIdInstr(r2)
    //     0x6408cc: ldur            x1, [x2, #-1]
    //     0x6408d0: ubfx            x1, x1, #0xc, #0x14
    // 0x6408d4: ldr             x16, [fp, #0x18]
    // 0x6408d8: stp             x16, x2, [SP, #-0x10]!
    // 0x6408dc: SaveReg r0
    //     0x6408dc: str             x0, [SP, #-8]!
    // 0x6408e0: mov             x0, x1
    // 0x6408e4: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x6408e4: mov             x17, #0xefa2
    //     0x6408e8: add             lr, x0, x17
    //     0x6408ec: ldr             lr, [x21, lr, lsl #3]
    //     0x6408f0: blr             lr
    // 0x6408f4: add             SP, SP, #0x18
    // 0x6408f8: LeaveFrame
    //     0x6408f8: mov             SP, fp
    //     0x6408fc: ldp             fp, lr, [SP], #0x10
    // 0x640900: ret
    //     0x640900: ret             
    // 0x640904: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640904: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640908: b               #0x6408ac
    // 0x64090c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x64090c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x640910, size: 0x110
    // 0x640910: EnterFrame
    //     0x640910: stp             fp, lr, [SP, #-0x10]!
    //     0x640914: mov             fp, SP
    // 0x640918: AllocStack(0x10)
    //     0x640918: sub             SP, SP, #0x10
    // 0x64091c: CheckStackOverflow
    //     0x64091c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640920: cmp             SP, x16
    //     0x640924: b.ls            #0x640a10
    // 0x640928: r1 = 2
    //     0x640928: mov             x1, #2
    // 0x64092c: r0 = AllocateContext()
    //     0x64092c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x640930: mov             x1, x0
    // 0x640934: ldr             x0, [fp, #0x20]
    // 0x640938: stur            x1, [fp, #-8]
    // 0x64093c: StoreField: r1->field_f = r0
    //     0x64093c: stur            w0, [x1, #0xf]
    // 0x640940: ldr             x16, [fp, #0x18]
    // 0x640944: stp             x16, x0, [SP, #-0x10]!
    // 0x640948: ldr             x16, [fp, #0x10]
    // 0x64094c: SaveReg r16
    //     0x64094c: str             x16, [SP, #-8]!
    // 0x640950: r0 = hitTest()
    //     0x640950: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x640954: add             SP, SP, #0x18
    // 0x640958: tbnz            w0, #4, #0x64096c
    // 0x64095c: r0 = true
    //     0x64095c: add             x0, NULL, #0x20  ; true
    // 0x640960: LeaveFrame
    //     0x640960: mov             SP, fp
    //     0x640964: ldp             fp, lr, [SP], #0x10
    // 0x640968: ret
    //     0x640968: ret             
    // 0x64096c: ldr             x0, [fp, #0x20]
    // 0x640970: ldur            x2, [fp, #-8]
    // 0x640974: LoadField: r1 = r0->field_5f
    //     0x640974: ldur            w1, [x0, #0x5f]
    // 0x640978: DecompressPointer r1
    //     0x640978: add             x1, x1, HEAP, lsl #32
    // 0x64097c: cmp             w1, NULL
    // 0x640980: b.eq            #0x640a18
    // 0x640984: LoadField: r0 = r1->field_57
    //     0x640984: ldur            w0, [x1, #0x57]
    // 0x640988: DecompressPointer r0
    //     0x640988: add             x0, x0, HEAP, lsl #32
    // 0x64098c: cmp             w0, NULL
    // 0x640990: b.eq            #0x640a1c
    // 0x640994: SaveReg r0
    //     0x640994: str             x0, [SP, #-8]!
    // 0x640998: r0 = center()
    //     0x640998: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x64099c: add             SP, SP, #8
    // 0x6409a0: mov             x1, x0
    // 0x6409a4: ldur            x2, [fp, #-8]
    // 0x6409a8: stur            x1, [fp, #-0x10]
    // 0x6409ac: StoreField: r2->field_13 = r0
    //     0x6409ac: stur            w0, [x2, #0x13]
    //     0x6409b0: ldurb           w16, [x2, #-1]
    //     0x6409b4: ldurb           w17, [x0, #-1]
    //     0x6409b8: and             x16, x17, x16, lsr #2
    //     0x6409bc: tst             x16, HEAP, lsr #32
    //     0x6409c0: b.eq            #0x6409c8
    //     0x6409c4: bl              #0xd6828c
    // 0x6409c8: SaveReg r1
    //     0x6409c8: str             x1, [SP, #-8]!
    // 0x6409cc: r0 = forceToPoint()
    //     0x6409cc: bl              #0x640758  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::forceToPoint
    // 0x6409d0: add             SP, SP, #8
    // 0x6409d4: ldur            x2, [fp, #-8]
    // 0x6409d8: r1 = Function '<anonymous closure>':.
    //     0x6409d8: add             x1, PP, #0x40, lsl #12  ; [pp+0x401f8] AnonymousClosure: (0x64088c), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::hitTest (0x640910)
    //     0x6409dc: ldr             x1, [x1, #0x1f8]
    // 0x6409e0: stur            x0, [fp, #-8]
    // 0x6409e4: r0 = AllocateClosure()
    //     0x6409e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6409e8: ldr             x16, [fp, #0x18]
    // 0x6409ec: stp             x0, x16, [SP, #-0x10]!
    // 0x6409f0: ldur            x16, [fp, #-0x10]
    // 0x6409f4: ldur            lr, [fp, #-8]
    // 0x6409f8: stp             lr, x16, [SP, #-0x10]!
    // 0x6409fc: r0 = addWithRawTransform()
    //     0x6409fc: bl              #0x622f84  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0x640a00: add             SP, SP, #0x20
    // 0x640a04: LeaveFrame
    //     0x640a04: mov             SP, fp
    //     0x640a08: ldp             fp, lr, [SP], #0x10
    // 0x640a0c: ret
    //     0x640a0c: ret             
    // 0x640a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640a10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x640a14: b               #0x640928
    // 0x640a18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640a18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x640a1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640a1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x692b20, size: 0x1a0
    // 0x692b20: EnterFrame
    //     0x692b20: stp             fp, lr, [SP, #-0x10]!
    //     0x692b24: mov             fp, SP
    // 0x692b28: AllocStack(0x18)
    //     0x692b28: sub             SP, SP, #0x18
    // 0x692b2c: CheckStackOverflow
    //     0x692b2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x692b30: cmp             SP, x16
    //     0x692b34: b.ls            #0x692cb0
    // 0x692b38: ldr             x3, [fp, #0x10]
    // 0x692b3c: LoadField: r4 = r3->field_27
    //     0x692b3c: ldur            w4, [x3, #0x27]
    // 0x692b40: DecompressPointer r4
    //     0x692b40: add             x4, x4, HEAP, lsl #32
    // 0x692b44: stur            x4, [fp, #-8]
    // 0x692b48: cmp             w4, NULL
    // 0x692b4c: b.eq            #0x692c90
    // 0x692b50: mov             x0, x4
    // 0x692b54: r2 = Null
    //     0x692b54: mov             x2, NULL
    // 0x692b58: r1 = Null
    //     0x692b58: mov             x1, NULL
    // 0x692b5c: r4 = LoadClassIdInstr(r0)
    //     0x692b5c: ldur            x4, [x0, #-1]
    //     0x692b60: ubfx            x4, x4, #0xc, #0x14
    // 0x692b64: sub             x4, x4, #0x80d
    // 0x692b68: cmp             x4, #1
    // 0x692b6c: b.ls            #0x692b84
    // 0x692b70: r8 = BoxConstraints
    //     0x692b70: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x692b74: ldr             x8, [x8, #0x1d0]
    // 0x692b78: r3 = Null
    //     0x692b78: add             x3, PP, #0x40, lsl #12  ; [pp+0x40200] Null
    //     0x692b7c: ldr             x3, [x3, #0x200]
    // 0x692b80: r0 = BoxConstraints()
    //     0x692b80: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x692b84: ldr             x16, [fp, #0x10]
    // 0x692b88: ldur            lr, [fp, #-8]
    // 0x692b8c: stp             lr, x16, [SP, #-0x10]!
    // 0x692b90: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0x692b90: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf80] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7fe6e1e8aefc)
    //     0x692b94: ldr             x16, [x16, #0xf80]
    // 0x692b98: SaveReg r16
    //     0x692b98: str             x16, [SP, #-8]!
    // 0x692b9c: r0 = _computeSize()
    //     0x692b9c: bl              #0x6929cc  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0x692ba0: add             SP, SP, #0x18
    // 0x692ba4: mov             x3, x0
    // 0x692ba8: ldr             x1, [fp, #0x10]
    // 0x692bac: stur            x3, [fp, #-0x18]
    // 0x692bb0: StoreField: r1->field_57 = r0
    //     0x692bb0: stur            w0, [x1, #0x57]
    //     0x692bb4: ldurb           w16, [x1, #-1]
    //     0x692bb8: ldurb           w17, [x0, #-1]
    //     0x692bbc: and             x16, x17, x16, lsr #2
    //     0x692bc0: tst             x16, HEAP, lsr #32
    //     0x692bc4: b.eq            #0x692bcc
    //     0x692bc8: bl              #0xd6826c
    // 0x692bcc: LoadField: r4 = r1->field_5f
    //     0x692bcc: ldur            w4, [x1, #0x5f]
    // 0x692bd0: DecompressPointer r4
    //     0x692bd0: add             x4, x4, HEAP, lsl #32
    // 0x692bd4: stur            x4, [fp, #-0x10]
    // 0x692bd8: cmp             w4, NULL
    // 0x692bdc: b.eq            #0x692c80
    // 0x692be0: LoadField: r5 = r4->field_17
    //     0x692be0: ldur            w5, [x4, #0x17]
    // 0x692be4: DecompressPointer r5
    //     0x692be4: add             x5, x5, HEAP, lsl #32
    // 0x692be8: stur            x5, [fp, #-8]
    // 0x692bec: cmp             w5, NULL
    // 0x692bf0: b.eq            #0x692cb8
    // 0x692bf4: mov             x0, x5
    // 0x692bf8: r2 = Null
    //     0x692bf8: mov             x2, NULL
    // 0x692bfc: r1 = Null
    //     0x692bfc: mov             x1, NULL
    // 0x692c00: r4 = LoadClassIdInstr(r0)
    //     0x692c00: ldur            x4, [x0, #-1]
    //     0x692c04: ubfx            x4, x4, #0xc, #0x14
    // 0x692c08: sub             x4, x4, #0x7ff
    // 0x692c0c: cmp             x4, #0xb
    // 0x692c10: b.ls            #0x692c28
    // 0x692c14: r8 = BoxParentData
    //     0x692c14: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x692c18: ldr             x8, [x8, #0x1b0]
    // 0x692c1c: r3 = Null
    //     0x692c1c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40210] Null
    //     0x692c20: ldr             x3, [x3, #0x210]
    // 0x692c24: r0 = DefaultTypeTest()
    //     0x692c24: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x692c28: ldur            x0, [fp, #-0x10]
    // 0x692c2c: LoadField: r1 = r0->field_57
    //     0x692c2c: ldur            w1, [x0, #0x57]
    // 0x692c30: DecompressPointer r1
    //     0x692c30: add             x1, x1, HEAP, lsl #32
    // 0x692c34: cmp             w1, NULL
    // 0x692c38: b.eq            #0x692cbc
    // 0x692c3c: ldur            x16, [fp, #-0x18]
    // 0x692c40: stp             x1, x16, [SP, #-0x10]!
    // 0x692c44: r0 = -()
    //     0x692c44: bl              #0x50e344  ; [dart:ui] Size::-
    // 0x692c48: add             SP, SP, #0x10
    // 0x692c4c: r16 = Instance_Alignment
    //     0x692c4c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x692c50: ldr             x16, [x16, #0xc70]
    // 0x692c54: stp             x0, x16, [SP, #-0x10]!
    // 0x692c58: r0 = alongOffset()
    //     0x692c58: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x692c5c: add             SP, SP, #0x10
    // 0x692c60: ldur            x1, [fp, #-8]
    // 0x692c64: StoreField: r1->field_7 = r0
    //     0x692c64: stur            w0, [x1, #7]
    //     0x692c68: ldurb           w16, [x1, #-1]
    //     0x692c6c: ldurb           w17, [x0, #-1]
    //     0x692c70: and             x16, x17, x16, lsr #2
    //     0x692c74: tst             x16, HEAP, lsr #32
    //     0x692c78: b.eq            #0x692c80
    //     0x692c7c: bl              #0xd6826c
    // 0x692c80: r0 = Null
    //     0x692c80: mov             x0, NULL
    // 0x692c84: LeaveFrame
    //     0x692c84: mov             SP, fp
    //     0x692c88: ldp             fp, lr, [SP], #0x10
    // 0x692c8c: ret
    //     0x692c8c: ret             
    // 0x692c90: r0 = StateError()
    //     0x692c90: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x692c94: mov             x1, x0
    // 0x692c98: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x692c98: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x692c9c: ldr             x0, [x0, #0x1e8]
    // 0x692ca0: StoreField: r1->field_b = r0
    //     0x692ca0: stur            w0, [x1, #0xb]
    // 0x692ca4: mov             x0, x1
    // 0x692ca8: r0 = Throw()
    //     0x692ca8: bl              #0xd67e38  ; ThrowStub
    // 0x692cac: brk             #0
    // 0x692cb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x692cb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x692cb4: b               #0x692b38
    // 0x692cb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692cb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x692cbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x692cbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e394, size: 0x48
    // 0xa5e394: EnterFrame
    //     0xa5e394: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e398: mov             fp, SP
    // 0xa5e39c: CheckStackOverflow
    //     0xa5e39c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e3a0: cmp             SP, x16
    //     0xa5e3a4: b.ls            #0xa5e3d4
    // 0xa5e3a8: ldr             x16, [fp, #0x18]
    // 0xa5e3ac: ldr             lr, [fp, #0x10]
    // 0xa5e3b0: stp             lr, x16, [SP, #-0x10]!
    // 0xa5e3b4: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xa5e3b4: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf88] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7fe6e1e33c20)
    //     0xa5e3b8: ldr             x16, [x16, #0xf88]
    // 0xa5e3bc: SaveReg r16
    //     0xa5e3bc: str             x16, [SP, #-8]!
    // 0xa5e3c0: r0 = _computeSize()
    //     0xa5e3c0: bl              #0x6929cc  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0xa5e3c4: add             SP, SP, #0x18
    // 0xa5e3c8: LeaveFrame
    //     0xa5e3c8: mov             SP, fp
    //     0xa5e3cc: ldp             fp, lr, [SP], #0x10
    // 0xa5e3d0: ret
    //     0xa5e3d0: ret             
    // 0xa5e3d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e3d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e3d8: b               #0xa5e3a8
  }
}

// class id: 2828, size: 0xc, field offset: 0x8
//   const constructor, 
class _MouseCursor extends MaterialStateMouseCursor {

  _ resolve(/* No info */) {
    // ** addr: 0x5a6acc, size: 0x5c
    // 0x5a6acc: EnterFrame
    //     0x5a6acc: stp             fp, lr, [SP, #-0x10]!
    //     0x5a6ad0: mov             fp, SP
    // 0x5a6ad4: CheckStackOverflow
    //     0x5a6ad4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a6ad8: cmp             SP, x16
    //     0x5a6adc: b.ls            #0x5a6b1c
    // 0x5a6ae0: ldr             x0, [fp, #0x18]
    // 0x5a6ae4: LoadField: r1 = r0->field_7
    //     0x5a6ae4: ldur            w1, [x0, #7]
    // 0x5a6ae8: DecompressPointer r1
    //     0x5a6ae8: add             x1, x1, HEAP, lsl #32
    // 0x5a6aec: ldr             x16, [fp, #0x10]
    // 0x5a6af0: stp             x16, x1, [SP, #-0x10]!
    // 0x5a6af4: mov             x0, x1
    // 0x5a6af8: ClosureCall
    //     0x5a6af8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5a6afc: ldur            x2, [x0, #0x1f]
    //     0x5a6b00: blr             x2
    // 0x5a6b04: add             SP, SP, #0x10
    // 0x5a6b08: cmp             w0, NULL
    // 0x5a6b0c: b.eq            #0x5a6b24
    // 0x5a6b10: LeaveFrame
    //     0x5a6b10: mov             SP, fp
    //     0x5a6b14: ldp             fp, lr, [SP], #0x10
    // 0x5a6b18: ret
    //     0x5a6b18: ret             
    // 0x5a6b1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a6b1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a6b20: b               #0x5a6ae0
    // 0x5a6b24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a6b24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ debugDescription(/* No info */) {
    // ** addr: 0xc0b138, size: 0xc
    // 0xc0b138: r0 = "ButtonStyleButton_MouseCursor"
    //     0xc0b138: add             x0, PP, #0x37, lsl #12  ; [pp+0x37960] "ButtonStyleButton_MouseCursor"
    //     0xc0b13c: ldr             x0, [x0, #0x960]
    // 0xc0b140: ret
    //     0xc0b140: ret             
  }
}

// class id: 3333, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __ButtonStyleState&State&TickerProviderStateMixin extends State<ButtonStyleButton>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x6162dc, size: 0x178
    // 0x6162dc: EnterFrame
    //     0x6162dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6162e0: mov             fp, SP
    // 0x6162e4: AllocStack(0x10)
    //     0x6162e4: sub             SP, SP, #0x10
    // 0x6162e8: CheckStackOverflow
    //     0x6162e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6162ec: cmp             SP, x16
    //     0x6162f0: b.ls            #0x616444
    // 0x6162f4: ldr             x0, [fp, #0x18]
    // 0x6162f8: LoadField: r1 = r0->field_17
    //     0x6162f8: ldur            w1, [x0, #0x17]
    // 0x6162fc: DecompressPointer r1
    //     0x6162fc: add             x1, x1, HEAP, lsl #32
    // 0x616300: cmp             w1, NULL
    // 0x616304: b.ne            #0x616314
    // 0x616308: SaveReg r0
    //     0x616308: str             x0, [SP, #-8]!
    // 0x61630c: r0 = _updateTickerModeNotifier()
    //     0x61630c: bl              #0x61647c  ; [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x616310: add             SP, SP, #8
    // 0x616314: ldr             x0, [fp, #0x18]
    // 0x616318: LoadField: r1 = r0->field_13
    //     0x616318: ldur            w1, [x0, #0x13]
    // 0x61631c: DecompressPointer r1
    //     0x61631c: add             x1, x1, HEAP, lsl #32
    // 0x616320: cmp             w1, NULL
    // 0x616324: b.ne            #0x6163bc
    // 0x616328: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x616328: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x61632c: ldr             x0, [x0, #0x598]
    //     0x616330: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x616334: cmp             w0, w16
    //     0x616338: b.ne            #0x616344
    //     0x61633c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x616340: bl              #0xd67cdc
    // 0x616344: r1 = <_WidgetTicker>
    //     0x616344: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x616348: ldr             x1, [x1, #0x210]
    // 0x61634c: stur            x0, [fp, #-8]
    // 0x616350: r0 = _Set()
    //     0x616350: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x616354: mov             x1, x0
    // 0x616358: ldur            x0, [fp, #-8]
    // 0x61635c: stur            x1, [fp, #-0x10]
    // 0x616360: StoreField: r1->field_1b = r0
    //     0x616360: stur            w0, [x1, #0x1b]
    // 0x616364: StoreField: r1->field_b = rZR
    //     0x616364: stur            wzr, [x1, #0xb]
    // 0x616368: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x616368: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x61636c: ldr             x0, [x0, #0x5a0]
    //     0x616370: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x616374: cmp             w0, w16
    //     0x616378: b.ne            #0x616384
    //     0x61637c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x616380: bl              #0xd67cdc
    // 0x616384: mov             x1, x0
    // 0x616388: ldur            x0, [fp, #-0x10]
    // 0x61638c: StoreField: r0->field_f = r1
    //     0x61638c: stur            w1, [x0, #0xf]
    // 0x616390: StoreField: r0->field_13 = rZR
    //     0x616390: stur            wzr, [x0, #0x13]
    // 0x616394: StoreField: r0->field_17 = rZR
    //     0x616394: stur            wzr, [x0, #0x17]
    // 0x616398: ldr             x1, [fp, #0x18]
    // 0x61639c: StoreField: r1->field_13 = r0
    //     0x61639c: stur            w0, [x1, #0x13]
    //     0x6163a0: ldurb           w16, [x1, #-1]
    //     0x6163a4: ldurb           w17, [x0, #-1]
    //     0x6163a8: and             x16, x17, x16, lsr #2
    //     0x6163ac: tst             x16, HEAP, lsr #32
    //     0x6163b0: b.eq            #0x6163b8
    //     0x6163b4: bl              #0xd6826c
    // 0x6163b8: b               #0x6163c0
    // 0x6163bc: mov             x1, x0
    // 0x6163c0: ldr             x0, [fp, #0x10]
    // 0x6163c4: r0 = _WidgetTicker()
    //     0x6163c4: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x6163c8: mov             x1, x0
    // 0x6163cc: ldr             x0, [fp, #0x18]
    // 0x6163d0: stur            x1, [fp, #-8]
    // 0x6163d4: StoreField: r1->field_1b = r0
    //     0x6163d4: stur            w0, [x1, #0x1b]
    // 0x6163d8: r2 = false
    //     0x6163d8: add             x2, NULL, #0x30  ; false
    // 0x6163dc: StoreField: r1->field_b = r2
    //     0x6163dc: stur            w2, [x1, #0xb]
    // 0x6163e0: ldr             x2, [fp, #0x10]
    // 0x6163e4: StoreField: r1->field_13 = r2
    //     0x6163e4: stur            w2, [x1, #0x13]
    // 0x6163e8: LoadField: r2 = r0->field_17
    //     0x6163e8: ldur            w2, [x0, #0x17]
    // 0x6163ec: DecompressPointer r2
    //     0x6163ec: add             x2, x2, HEAP, lsl #32
    // 0x6163f0: cmp             w2, NULL
    // 0x6163f4: b.eq            #0x61644c
    // 0x6163f8: LoadField: r3 = r2->field_27
    //     0x6163f8: ldur            w3, [x2, #0x27]
    // 0x6163fc: DecompressPointer r3
    //     0x6163fc: add             x3, x3, HEAP, lsl #32
    // 0x616400: eor             x2, x3, #0x10
    // 0x616404: stp             x2, x1, [SP, #-0x10]!
    // 0x616408: r0 = muted=()
    //     0x616408: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x61640c: add             SP, SP, #0x10
    // 0x616410: ldr             x0, [fp, #0x18]
    // 0x616414: LoadField: r1 = r0->field_13
    //     0x616414: ldur            w1, [x0, #0x13]
    // 0x616418: DecompressPointer r1
    //     0x616418: add             x1, x1, HEAP, lsl #32
    // 0x61641c: cmp             w1, NULL
    // 0x616420: b.eq            #0x616450
    // 0x616424: ldur            x16, [fp, #-8]
    // 0x616428: stp             x16, x1, [SP, #-0x10]!
    // 0x61642c: r0 = add()
    //     0x61642c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x616430: add             SP, SP, #0x10
    // 0x616434: ldur            x0, [fp, #-8]
    // 0x616438: LeaveFrame
    //     0x616438: mov             SP, fp
    //     0x61643c: ldp             fp, lr, [SP], #0x10
    // 0x616440: ret
    //     0x616440: ret             
    // 0x616444: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616444: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616448: b               #0x6162f4
    // 0x61644c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61644c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616450: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x61647c, size: 0x11c
    // 0x61647c: EnterFrame
    //     0x61647c: stp             fp, lr, [SP, #-0x10]!
    //     0x616480: mov             fp, SP
    // 0x616484: AllocStack(0x10)
    //     0x616484: sub             SP, SP, #0x10
    // 0x616488: CheckStackOverflow
    //     0x616488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61648c: cmp             SP, x16
    //     0x616490: b.ls            #0x61658c
    // 0x616494: ldr             x0, [fp, #0x10]
    // 0x616498: LoadField: r1 = r0->field_f
    //     0x616498: ldur            w1, [x0, #0xf]
    // 0x61649c: DecompressPointer r1
    //     0x61649c: add             x1, x1, HEAP, lsl #32
    // 0x6164a0: cmp             w1, NULL
    // 0x6164a4: b.eq            #0x616594
    // 0x6164a8: SaveReg r1
    //     0x6164a8: str             x1, [SP, #-8]!
    // 0x6164ac: r0 = getNotifier()
    //     0x6164ac: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6164b0: add             SP, SP, #8
    // 0x6164b4: mov             x1, x0
    // 0x6164b8: ldr             x0, [fp, #0x10]
    // 0x6164bc: stur            x1, [fp, #-0x10]
    // 0x6164c0: LoadField: r2 = r0->field_17
    //     0x6164c0: ldur            w2, [x0, #0x17]
    // 0x6164c4: DecompressPointer r2
    //     0x6164c4: add             x2, x2, HEAP, lsl #32
    // 0x6164c8: stur            x2, [fp, #-8]
    // 0x6164cc: cmp             w1, w2
    // 0x6164d0: b.ne            #0x6164e4
    // 0x6164d4: r0 = Null
    //     0x6164d4: mov             x0, NULL
    // 0x6164d8: LeaveFrame
    //     0x6164d8: mov             SP, fp
    //     0x6164dc: ldp             fp, lr, [SP], #0x10
    // 0x6164e0: ret
    //     0x6164e0: ret             
    // 0x6164e4: cmp             w2, NULL
    // 0x6164e8: b.eq            #0x616524
    // 0x6164ec: r1 = 1
    //     0x6164ec: mov             x1, #1
    // 0x6164f0: r0 = AllocateContext()
    //     0x6164f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6164f4: mov             x1, x0
    // 0x6164f8: ldr             x0, [fp, #0x10]
    // 0x6164fc: StoreField: r1->field_f = r0
    //     0x6164fc: stur            w0, [x1, #0xf]
    // 0x616500: mov             x2, x1
    // 0x616504: r1 = Function '_updateTickers@156311458':.
    //     0x616504: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e768] AnonymousClosure: (0x616598), in [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickers (0x6165e0)
    //     0x616508: ldr             x1, [x1, #0x768]
    // 0x61650c: r0 = AllocateClosure()
    //     0x61650c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x616510: ldur            x16, [fp, #-8]
    // 0x616514: stp             x0, x16, [SP, #-0x10]!
    // 0x616518: r0 = removeListener()
    //     0x616518: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x61651c: add             SP, SP, #0x10
    // 0x616520: ldr             x0, [fp, #0x10]
    // 0x616524: r1 = 1
    //     0x616524: mov             x1, #1
    // 0x616528: r0 = AllocateContext()
    //     0x616528: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61652c: mov             x1, x0
    // 0x616530: ldr             x0, [fp, #0x10]
    // 0x616534: StoreField: r1->field_f = r0
    //     0x616534: stur            w0, [x1, #0xf]
    // 0x616538: mov             x2, x1
    // 0x61653c: r1 = Function '_updateTickers@156311458':.
    //     0x61653c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e768] AnonymousClosure: (0x616598), in [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickers (0x6165e0)
    //     0x616540: ldr             x1, [x1, #0x768]
    // 0x616544: r0 = AllocateClosure()
    //     0x616544: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x616548: ldur            x16, [fp, #-0x10]
    // 0x61654c: stp             x0, x16, [SP, #-0x10]!
    // 0x616550: r0 = addListener()
    //     0x616550: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x616554: add             SP, SP, #0x10
    // 0x616558: ldur            x0, [fp, #-0x10]
    // 0x61655c: ldr             x1, [fp, #0x10]
    // 0x616560: StoreField: r1->field_17 = r0
    //     0x616560: stur            w0, [x1, #0x17]
    //     0x616564: ldurb           w16, [x1, #-1]
    //     0x616568: ldurb           w17, [x0, #-1]
    //     0x61656c: and             x16, x17, x16, lsr #2
    //     0x616570: tst             x16, HEAP, lsr #32
    //     0x616574: b.eq            #0x61657c
    //     0x616578: bl              #0xd6826c
    // 0x61657c: r0 = Null
    //     0x61657c: mov             x0, NULL
    // 0x616580: LeaveFrame
    //     0x616580: mov             SP, fp
    //     0x616584: ldp             fp, lr, [SP], #0x10
    // 0x616588: ret
    //     0x616588: ret             
    // 0x61658c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61658c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616590: b               #0x616494
    // 0x616594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616594: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x616598, size: 0x48
    // 0x616598: EnterFrame
    //     0x616598: stp             fp, lr, [SP, #-0x10]!
    //     0x61659c: mov             fp, SP
    // 0x6165a0: ldr             x0, [fp, #0x10]
    // 0x6165a4: LoadField: r1 = r0->field_17
    //     0x6165a4: ldur            w1, [x0, #0x17]
    // 0x6165a8: DecompressPointer r1
    //     0x6165a8: add             x1, x1, HEAP, lsl #32
    // 0x6165ac: CheckStackOverflow
    //     0x6165ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6165b0: cmp             SP, x16
    //     0x6165b4: b.ls            #0x6165d8
    // 0x6165b8: LoadField: r0 = r1->field_f
    //     0x6165b8: ldur            w0, [x1, #0xf]
    // 0x6165bc: DecompressPointer r0
    //     0x6165bc: add             x0, x0, HEAP, lsl #32
    // 0x6165c0: SaveReg r0
    //     0x6165c0: str             x0, [SP, #-8]!
    // 0x6165c4: r0 = _updateTickers()
    //     0x6165c4: bl              #0x6165e0  ; [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickers
    // 0x6165c8: add             SP, SP, #8
    // 0x6165cc: LeaveFrame
    //     0x6165cc: mov             SP, fp
    //     0x6165d0: ldp             fp, lr, [SP], #0x10
    // 0x6165d4: ret
    //     0x6165d4: ret             
    // 0x6165d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6165d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6165dc: b               #0x6165b8
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x6165e0, size: 0x150
    // 0x6165e0: EnterFrame
    //     0x6165e0: stp             fp, lr, [SP, #-0x10]!
    //     0x6165e4: mov             fp, SP
    // 0x6165e8: AllocStack(0x20)
    //     0x6165e8: sub             SP, SP, #0x20
    // 0x6165ec: CheckStackOverflow
    //     0x6165ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6165f0: cmp             SP, x16
    //     0x6165f4: b.ls            #0x61671c
    // 0x6165f8: ldr             x0, [fp, #0x10]
    // 0x6165fc: LoadField: r1 = r0->field_13
    //     0x6165fc: ldur            w1, [x0, #0x13]
    // 0x616600: DecompressPointer r1
    //     0x616600: add             x1, x1, HEAP, lsl #32
    // 0x616604: cmp             w1, NULL
    // 0x616608: b.eq            #0x61670c
    // 0x61660c: LoadField: r2 = r0->field_17
    //     0x61660c: ldur            w2, [x0, #0x17]
    // 0x616610: DecompressPointer r2
    //     0x616610: add             x2, x2, HEAP, lsl #32
    // 0x616614: cmp             w2, NULL
    // 0x616618: b.eq            #0x616724
    // 0x61661c: LoadField: r0 = r2->field_27
    //     0x61661c: ldur            w0, [x2, #0x27]
    // 0x616620: DecompressPointer r0
    //     0x616620: add             x0, x0, HEAP, lsl #32
    // 0x616624: eor             x2, x0, #0x10
    // 0x616628: stur            x2, [fp, #-8]
    // 0x61662c: SaveReg r1
    //     0x61662c: str             x1, [SP, #-8]!
    // 0x616630: r0 = iterator()
    //     0x616630: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x616634: add             SP, SP, #8
    // 0x616638: stur            x0, [fp, #-0x18]
    // 0x61663c: LoadField: r2 = r0->field_7
    //     0x61663c: ldur            w2, [x0, #7]
    // 0x616640: DecompressPointer r2
    //     0x616640: add             x2, x2, HEAP, lsl #32
    // 0x616644: stur            x2, [fp, #-0x10]
    // 0x616648: ldur            x1, [fp, #-8]
    // 0x61664c: CheckStackOverflow
    //     0x61664c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616650: cmp             SP, x16
    //     0x616654: b.ls            #0x616728
    // 0x616658: SaveReg r0
    //     0x616658: str             x0, [SP, #-8]!
    // 0x61665c: r0 = moveNext()
    //     0x61665c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x616660: add             SP, SP, #8
    // 0x616664: tbnz            w0, #4, #0x61670c
    // 0x616668: ldur            x3, [fp, #-0x18]
    // 0x61666c: LoadField: r4 = r3->field_33
    //     0x61666c: ldur            w4, [x3, #0x33]
    // 0x616670: DecompressPointer r4
    //     0x616670: add             x4, x4, HEAP, lsl #32
    // 0x616674: stur            x4, [fp, #-0x20]
    // 0x616678: cmp             w4, NULL
    // 0x61667c: b.ne            #0x6166b0
    // 0x616680: mov             x0, x4
    // 0x616684: ldur            x2, [fp, #-0x10]
    // 0x616688: r1 = Null
    //     0x616688: mov             x1, NULL
    // 0x61668c: cmp             w2, NULL
    // 0x616690: b.eq            #0x6166b0
    // 0x616694: LoadField: r4 = r2->field_17
    //     0x616694: ldur            w4, [x2, #0x17]
    // 0x616698: DecompressPointer r4
    //     0x616698: add             x4, x4, HEAP, lsl #32
    // 0x61669c: r8 = X0
    //     0x61669c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6166a0: LoadField: r9 = r4->field_7
    //     0x6166a0: ldur            x9, [x4, #7]
    // 0x6166a4: r3 = Null
    //     0x6166a4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e758] Null
    //     0x6166a8: ldr             x3, [x3, #0x758]
    // 0x6166ac: blr             x9
    // 0x6166b0: ldur            x1, [fp, #-8]
    // 0x6166b4: ldur            x0, [fp, #-0x20]
    // 0x6166b8: LoadField: r2 = r0->field_b
    //     0x6166b8: ldur            w2, [x0, #0xb]
    // 0x6166bc: DecompressPointer r2
    //     0x6166bc: add             x2, x2, HEAP, lsl #32
    // 0x6166c0: cmp             w1, w2
    // 0x6166c4: b.eq            #0x616700
    // 0x6166c8: StoreField: r0->field_b = r1
    //     0x6166c8: stur            w1, [x0, #0xb]
    // 0x6166cc: tbnz            w1, #4, #0x6166e0
    // 0x6166d0: SaveReg r0
    //     0x6166d0: str             x0, [SP, #-8]!
    // 0x6166d4: r0 = unscheduleTick()
    //     0x6166d4: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x6166d8: add             SP, SP, #8
    // 0x6166dc: b               #0x616700
    // 0x6166e0: SaveReg r0
    //     0x6166e0: str             x0, [SP, #-8]!
    // 0x6166e4: r0 = shouldScheduleTick()
    //     0x6166e4: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x6166e8: add             SP, SP, #8
    // 0x6166ec: tbnz            w0, #4, #0x616700
    // 0x6166f0: ldur            x16, [fp, #-0x20]
    // 0x6166f4: SaveReg r16
    //     0x6166f4: str             x16, [SP, #-8]!
    // 0x6166f8: r0 = scheduleTick()
    //     0x6166f8: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x6166fc: add             SP, SP, #8
    // 0x616700: ldur            x0, [fp, #-0x18]
    // 0x616704: ldur            x2, [fp, #-0x10]
    // 0x616708: b               #0x616648
    // 0x61670c: r0 = Null
    //     0x61670c: mov             x0, NULL
    // 0x616710: LeaveFrame
    //     0x616710: mov             SP, fp
    //     0x616714: ldp             fp, lr, [SP], #0x10
    // 0x616718: ret
    //     0x616718: ret             
    // 0x61671c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61671c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616720: b               #0x6165f8
    // 0x616724: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616724: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61672c: b               #0x616658
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f2e0, size: 0x4c
    // 0x81f2e0: EnterFrame
    //     0x81f2e0: stp             fp, lr, [SP, #-0x10]!
    //     0x81f2e4: mov             fp, SP
    // 0x81f2e8: CheckStackOverflow
    //     0x81f2e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f2ec: cmp             SP, x16
    //     0x81f2f0: b.ls            #0x81f324
    // 0x81f2f4: ldr             x16, [fp, #0x10]
    // 0x81f2f8: SaveReg r16
    //     0x81f2f8: str             x16, [SP, #-8]!
    // 0x81f2fc: r0 = _updateTickerModeNotifier()
    //     0x81f2fc: bl              #0x61647c  ; [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f300: add             SP, SP, #8
    // 0x81f304: ldr             x16, [fp, #0x10]
    // 0x81f308: SaveReg r16
    //     0x81f308: str             x16, [SP, #-8]!
    // 0x81f30c: r0 = _updateTickers()
    //     0x81f30c: bl              #0x6165e0  ; [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f310: add             SP, SP, #8
    // 0x81f314: r0 = Null
    //     0x81f314: mov             x0, NULL
    // 0x81f318: LeaveFrame
    //     0x81f318: mov             SP, fp
    //     0x81f31c: ldp             fp, lr, [SP], #0x10
    // 0x81f320: ret
    //     0x81f320: ret             
    // 0x81f324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f328: b               #0x81f2f4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa511f0, size: 0x8c
    // 0xa511f0: EnterFrame
    //     0xa511f0: stp             fp, lr, [SP, #-0x10]!
    //     0xa511f4: mov             fp, SP
    // 0xa511f8: AllocStack(0x8)
    //     0xa511f8: sub             SP, SP, #8
    // 0xa511fc: CheckStackOverflow
    //     0xa511fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51200: cmp             SP, x16
    //     0xa51204: b.ls            #0xa51274
    // 0xa51208: ldr             x0, [fp, #0x10]
    // 0xa5120c: LoadField: r1 = r0->field_17
    //     0xa5120c: ldur            w1, [x0, #0x17]
    // 0xa51210: DecompressPointer r1
    //     0xa51210: add             x1, x1, HEAP, lsl #32
    // 0xa51214: stur            x1, [fp, #-8]
    // 0xa51218: cmp             w1, NULL
    // 0xa5121c: b.ne            #0xa51228
    // 0xa51220: mov             x1, x0
    // 0xa51224: b               #0xa51260
    // 0xa51228: r1 = 1
    //     0xa51228: mov             x1, #1
    // 0xa5122c: r0 = AllocateContext()
    //     0xa5122c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa51230: mov             x1, x0
    // 0xa51234: ldr             x0, [fp, #0x10]
    // 0xa51238: StoreField: r1->field_f = r0
    //     0xa51238: stur            w0, [x1, #0xf]
    // 0xa5123c: mov             x2, x1
    // 0xa51240: r1 = Function '_updateTickers@156311458':.
    //     0xa51240: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e768] AnonymousClosure: (0x616598), in [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::_updateTickers (0x6165e0)
    //     0xa51244: ldr             x1, [x1, #0x768]
    // 0xa51248: r0 = AllocateClosure()
    //     0xa51248: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa5124c: ldur            x16, [fp, #-8]
    // 0xa51250: stp             x0, x16, [SP, #-0x10]!
    // 0xa51254: r0 = removeListener()
    //     0xa51254: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa51258: add             SP, SP, #0x10
    // 0xa5125c: ldr             x1, [fp, #0x10]
    // 0xa51260: StoreField: r1->field_17 = rNULL
    //     0xa51260: stur            NULL, [x1, #0x17]
    // 0xa51264: r0 = Null
    //     0xa51264: mov             x0, NULL
    // 0xa51268: LeaveFrame
    //     0xa51268: mov             SP, fp
    //     0xa5126c: ldp             fp, lr, [SP], #0x10
    // 0xa51270: ret
    //     0xa51270: ret             
    // 0xa51274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51278: b               #0xa51208
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa5127c, size: 0x48
    // 0xa5127c: EnterFrame
    //     0xa5127c: stp             fp, lr, [SP, #-0x10]!
    //     0xa51280: mov             fp, SP
    // 0xa51284: ldr             x0, [fp, #0x10]
    // 0xa51288: LoadField: r1 = r0->field_17
    //     0xa51288: ldur            w1, [x0, #0x17]
    // 0xa5128c: DecompressPointer r1
    //     0xa5128c: add             x1, x1, HEAP, lsl #32
    // 0xa51290: CheckStackOverflow
    //     0xa51290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51294: cmp             SP, x16
    //     0xa51298: b.ls            #0xa512bc
    // 0xa5129c: LoadField: r0 = r1->field_f
    //     0xa5129c: ldur            w0, [x1, #0xf]
    // 0xa512a0: DecompressPointer r0
    //     0xa512a0: add             x0, x0, HEAP, lsl #32
    // 0xa512a4: SaveReg r0
    //     0xa512a4: str             x0, [SP, #-8]!
    // 0xa512a8: r0 = dispose()
    //     0xa512a8: bl              #0xa511f0  ; [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::dispose
    // 0xa512ac: add             SP, SP, #8
    // 0xa512b0: LeaveFrame
    //     0xa512b0: mov             SP, fp
    //     0xa512b4: ldp             fp, lr, [SP], #0x10
    // 0xa512b8: ret
    //     0xa512b8: ret             
    // 0xa512bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa512bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa512c0: b               #0xa5129c
  }
}

// class id: 3334, size: 0x2c, field offset: 0x1c
class _ButtonStyleState extends __ButtonStyleState&State&TickerProviderStateMixin {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b0580, size: 0x2a4
    // 0x7b0580: EnterFrame
    //     0x7b0580: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0584: mov             fp, SP
    // 0x7b0588: AllocStack(0x8)
    //     0x7b0588: sub             SP, SP, #8
    // 0x7b058c: CheckStackOverflow
    //     0x7b058c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0590: cmp             SP, x16
    //     0x7b0594: b.ls            #0x7b0804
    // 0x7b0598: ldr             x0, [fp, #0x10]
    // 0x7b059c: r2 = Null
    //     0x7b059c: mov             x2, NULL
    // 0x7b05a0: r1 = Null
    //     0x7b05a0: mov             x1, NULL
    // 0x7b05a4: r4 = 59
    //     0x7b05a4: mov             x4, #0x3b
    // 0x7b05a8: branchIfSmi(r0, 0x7b05b4)
    //     0x7b05a8: tbz             w0, #0, #0x7b05b4
    // 0x7b05ac: r4 = LoadClassIdInstr(r0)
    //     0x7b05ac: ldur            x4, [x0, #-1]
    //     0x7b05b0: ubfx            x4, x4, #0xc, #0x14
    // 0x7b05b4: r17 = -4161
    //     0x7b05b4: mov             x17, #-0x1041
    // 0x7b05b8: add             x4, x4, x17
    // 0x7b05bc: cmp             x4, #4
    // 0x7b05c0: b.ls            #0x7b05d8
    // 0x7b05c4: r8 = ButtonStyleButton
    //     0x7b05c4: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e730] Type: ButtonStyleButton
    //     0x7b05c8: ldr             x8, [x8, #0x730]
    // 0x7b05cc: r3 = Null
    //     0x7b05cc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e738] Null
    //     0x7b05d0: ldr             x3, [x3, #0x738]
    // 0x7b05d4: r0 = ButtonStyleButton()
    //     0x7b05d4: bl              #0x616454  ; IsType_ButtonStyleButton_Stub
    // 0x7b05d8: ldr             x3, [fp, #0x18]
    // 0x7b05dc: LoadField: r2 = r3->field_7
    //     0x7b05dc: ldur            w2, [x3, #7]
    // 0x7b05e0: DecompressPointer r2
    //     0x7b05e0: add             x2, x2, HEAP, lsl #32
    // 0x7b05e4: ldr             x0, [fp, #0x10]
    // 0x7b05e8: r1 = Null
    //     0x7b05e8: mov             x1, NULL
    // 0x7b05ec: cmp             w2, NULL
    // 0x7b05f0: b.eq            #0x7b0614
    // 0x7b05f4: LoadField: r4 = r2->field_17
    //     0x7b05f4: ldur            w4, [x2, #0x17]
    // 0x7b05f8: DecompressPointer r4
    //     0x7b05f8: add             x4, x4, HEAP, lsl #32
    // 0x7b05fc: r8 = X0 bound StatefulWidget
    //     0x7b05fc: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b0600: ldr             x8, [x8, #0x858]
    // 0x7b0604: LoadField: r9 = r4->field_7
    //     0x7b0604: ldur            x9, [x4, #7]
    // 0x7b0608: r3 = Null
    //     0x7b0608: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e748] Null
    //     0x7b060c: ldr             x3, [x3, #0x748]
    // 0x7b0610: blr             x9
    // 0x7b0614: ldr             x0, [fp, #0x18]
    // 0x7b0618: LoadField: r1 = r0->field_b
    //     0x7b0618: ldur            w1, [x0, #0xb]
    // 0x7b061c: DecompressPointer r1
    //     0x7b061c: add             x1, x1, HEAP, lsl #32
    // 0x7b0620: cmp             w1, NULL
    // 0x7b0624: b.eq            #0x7b080c
    // 0x7b0628: LoadField: r2 = r1->field_2b
    //     0x7b0628: ldur            w2, [x1, #0x2b]
    // 0x7b062c: DecompressPointer r2
    //     0x7b062c: add             x2, x2, HEAP, lsl #32
    // 0x7b0630: ldr             x1, [fp, #0x10]
    // 0x7b0634: LoadField: r3 = r1->field_2b
    //     0x7b0634: ldur            w3, [x1, #0x2b]
    // 0x7b0638: DecompressPointer r3
    //     0x7b0638: add             x3, x3, HEAP, lsl #32
    // 0x7b063c: stur            x3, [fp, #-8]
    // 0x7b0640: cmp             w2, w3
    // 0x7b0644: b.eq            #0x7b06d8
    // 0x7b0648: cmp             w3, NULL
    // 0x7b064c: b.eq            #0x7b0688
    // 0x7b0650: r1 = 1
    //     0x7b0650: mov             x1, #1
    // 0x7b0654: r0 = AllocateContext()
    //     0x7b0654: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b0658: mov             x1, x0
    // 0x7b065c: ldr             x0, [fp, #0x18]
    // 0x7b0660: StoreField: r1->field_f = r0
    //     0x7b0660: stur            w0, [x1, #0xf]
    // 0x7b0664: mov             x2, x1
    // 0x7b0668: r1 = Function 'handleStatesControllerChange':.
    //     0x7b0668: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e720] AnonymousClosure: (0x7b0c08), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange (0x7b0c50)
    //     0x7b066c: ldr             x1, [x1, #0x720]
    // 0x7b0670: r0 = AllocateClosure()
    //     0x7b0670: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0674: ldur            x16, [fp, #-8]
    // 0x7b0678: stp             x0, x16, [SP, #-0x10]!
    // 0x7b067c: r0 = removeListener()
    //     0x7b067c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7b0680: add             SP, SP, #0x10
    // 0x7b0684: ldr             x0, [fp, #0x18]
    // 0x7b0688: LoadField: r1 = r0->field_b
    //     0x7b0688: ldur            w1, [x0, #0xb]
    // 0x7b068c: DecompressPointer r1
    //     0x7b068c: add             x1, x1, HEAP, lsl #32
    // 0x7b0690: cmp             w1, NULL
    // 0x7b0694: b.eq            #0x7b0810
    // 0x7b0698: LoadField: r2 = r1->field_2b
    //     0x7b0698: ldur            w2, [x1, #0x2b]
    // 0x7b069c: DecompressPointer r2
    //     0x7b069c: add             x2, x2, HEAP, lsl #32
    // 0x7b06a0: cmp             w2, NULL
    // 0x7b06a4: b.eq            #0x7b06cc
    // 0x7b06a8: LoadField: r1 = r0->field_27
    //     0x7b06a8: ldur            w1, [x0, #0x27]
    // 0x7b06ac: DecompressPointer r1
    //     0x7b06ac: add             x1, x1, HEAP, lsl #32
    // 0x7b06b0: cmp             w1, NULL
    // 0x7b06b4: b.eq            #0x7b06c8
    // 0x7b06b8: SaveReg r1
    //     0x7b06b8: str             x1, [SP, #-8]!
    // 0x7b06bc: r0 = dispose()
    //     0x7b06bc: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x7b06c0: add             SP, SP, #8
    // 0x7b06c4: ldr             x0, [fp, #0x18]
    // 0x7b06c8: StoreField: r0->field_27 = rNULL
    //     0x7b06c8: stur            NULL, [x0, #0x27]
    // 0x7b06cc: SaveReg r0
    //     0x7b06cc: str             x0, [SP, #-8]!
    // 0x7b06d0: r0 = initStatesController()
    //     0x7b06d0: bl              #0x7b0908  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::initStatesController
    // 0x7b06d4: add             SP, SP, #8
    // 0x7b06d8: ldr             x0, [fp, #0x18]
    // 0x7b06dc: LoadField: r1 = r0->field_b
    //     0x7b06dc: ldur            w1, [x0, #0xb]
    // 0x7b06e0: DecompressPointer r1
    //     0x7b06e0: add             x1, x1, HEAP, lsl #32
    // 0x7b06e4: cmp             w1, NULL
    // 0x7b06e8: b.eq            #0x7b0814
    // 0x7b06ec: LoadField: r2 = r1->field_b
    //     0x7b06ec: ldur            w2, [x1, #0xb]
    // 0x7b06f0: DecompressPointer r2
    //     0x7b06f0: add             x2, x2, HEAP, lsl #32
    // 0x7b06f4: cmp             w2, NULL
    // 0x7b06f8: b.eq            #0x7b0704
    // 0x7b06fc: r4 = true
    //     0x7b06fc: add             x4, NULL, #0x20  ; true
    // 0x7b0700: b               #0x7b0708
    // 0x7b0704: r4 = false
    //     0x7b0704: add             x4, NULL, #0x30  ; false
    // 0x7b0708: ldr             x3, [fp, #0x10]
    // 0x7b070c: LoadField: r5 = r3->field_b
    //     0x7b070c: ldur            w5, [x3, #0xb]
    // 0x7b0710: DecompressPointer r5
    //     0x7b0710: add             x5, x5, HEAP, lsl #32
    // 0x7b0714: cmp             w5, NULL
    // 0x7b0718: b.eq            #0x7b0724
    // 0x7b071c: r3 = true
    //     0x7b071c: add             x3, NULL, #0x20  ; true
    // 0x7b0720: b               #0x7b0728
    // 0x7b0724: r3 = false
    //     0x7b0724: add             x3, NULL, #0x30  ; false
    // 0x7b0728: cmp             w4, w3
    // 0x7b072c: b.eq            #0x7b07f4
    // 0x7b0730: LoadField: r3 = r1->field_2b
    //     0x7b0730: ldur            w3, [x1, #0x2b]
    // 0x7b0734: DecompressPointer r3
    //     0x7b0734: add             x3, x3, HEAP, lsl #32
    // 0x7b0738: cmp             w3, NULL
    // 0x7b073c: b.ne            #0x7b0754
    // 0x7b0740: LoadField: r1 = r0->field_27
    //     0x7b0740: ldur            w1, [x0, #0x27]
    // 0x7b0744: DecompressPointer r1
    //     0x7b0744: add             x1, x1, HEAP, lsl #32
    // 0x7b0748: cmp             w1, NULL
    // 0x7b074c: b.eq            #0x7b0818
    // 0x7b0750: b               #0x7b0758
    // 0x7b0754: mov             x1, x3
    // 0x7b0758: cmp             w2, NULL
    // 0x7b075c: b.eq            #0x7b0768
    // 0x7b0760: r2 = true
    //     0x7b0760: add             x2, NULL, #0x20  ; true
    // 0x7b0764: b               #0x7b076c
    // 0x7b0768: r2 = false
    //     0x7b0768: add             x2, NULL, #0x30  ; false
    // 0x7b076c: eor             x3, x2, #0x10
    // 0x7b0770: r16 = Instance_MaterialState
    //     0x7b0770: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b0774: ldr             x16, [x16, #0x2a0]
    // 0x7b0778: stp             x16, x1, [SP, #-0x10]!
    // 0x7b077c: SaveReg r3
    //     0x7b077c: str             x3, [SP, #-8]!
    // 0x7b0780: r0 = update()
    //     0x7b0780: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b0784: add             SP, SP, #0x18
    // 0x7b0788: ldr             x0, [fp, #0x18]
    // 0x7b078c: LoadField: r1 = r0->field_b
    //     0x7b078c: ldur            w1, [x0, #0xb]
    // 0x7b0790: DecompressPointer r1
    //     0x7b0790: add             x1, x1, HEAP, lsl #32
    // 0x7b0794: cmp             w1, NULL
    // 0x7b0798: b.eq            #0x7b081c
    // 0x7b079c: LoadField: r2 = r1->field_b
    //     0x7b079c: ldur            w2, [x1, #0xb]
    // 0x7b07a0: DecompressPointer r2
    //     0x7b07a0: add             x2, x2, HEAP, lsl #32
    // 0x7b07a4: cmp             w2, NULL
    // 0x7b07a8: b.ne            #0x7b07f4
    // 0x7b07ac: LoadField: r2 = r1->field_2b
    //     0x7b07ac: ldur            w2, [x1, #0x2b]
    // 0x7b07b0: DecompressPointer r2
    //     0x7b07b0: add             x2, x2, HEAP, lsl #32
    // 0x7b07b4: cmp             w2, NULL
    // 0x7b07b8: b.ne            #0x7b07d4
    // 0x7b07bc: LoadField: r1 = r0->field_27
    //     0x7b07bc: ldur            w1, [x0, #0x27]
    // 0x7b07c0: DecompressPointer r1
    //     0x7b07c0: add             x1, x1, HEAP, lsl #32
    // 0x7b07c4: cmp             w1, NULL
    // 0x7b07c8: b.eq            #0x7b0820
    // 0x7b07cc: mov             x0, x1
    // 0x7b07d0: b               #0x7b07d8
    // 0x7b07d4: mov             x0, x2
    // 0x7b07d8: r16 = Instance_MaterialState
    //     0x7b07d8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x7b07dc: ldr             x16, [x16, #0xf90]
    // 0x7b07e0: stp             x16, x0, [SP, #-0x10]!
    // 0x7b07e4: r16 = false
    //     0x7b07e4: add             x16, NULL, #0x30  ; false
    // 0x7b07e8: SaveReg r16
    //     0x7b07e8: str             x16, [SP, #-8]!
    // 0x7b07ec: r0 = update()
    //     0x7b07ec: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b07f0: add             SP, SP, #0x18
    // 0x7b07f4: r0 = Null
    //     0x7b07f4: mov             x0, NULL
    // 0x7b07f8: LeaveFrame
    //     0x7b07f8: mov             SP, fp
    //     0x7b07fc: ldp             fp, lr, [SP], #0x10
    // 0x7b0800: ret
    //     0x7b0800: ret             
    // 0x7b0804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0808: b               #0x7b0598
    // 0x7b080c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b080c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0810: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0810: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0814: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0814: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0818: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0818: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b081c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b081c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0820: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0820: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ statesController(/* No info */) {
    // ** addr: 0x7b0824, size: 0x5c
    // 0x7b0824: EnterFrame
    //     0x7b0824: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0828: mov             fp, SP
    // 0x7b082c: ldr             x1, [fp, #0x10]
    // 0x7b0830: LoadField: r2 = r1->field_b
    //     0x7b0830: ldur            w2, [x1, #0xb]
    // 0x7b0834: DecompressPointer r2
    //     0x7b0834: add             x2, x2, HEAP, lsl #32
    // 0x7b0838: cmp             w2, NULL
    // 0x7b083c: b.eq            #0x7b0878
    // 0x7b0840: LoadField: r3 = r2->field_2b
    //     0x7b0840: ldur            w3, [x2, #0x2b]
    // 0x7b0844: DecompressPointer r3
    //     0x7b0844: add             x3, x3, HEAP, lsl #32
    // 0x7b0848: cmp             w3, NULL
    // 0x7b084c: b.ne            #0x7b0868
    // 0x7b0850: LoadField: r2 = r1->field_27
    //     0x7b0850: ldur            w2, [x1, #0x27]
    // 0x7b0854: DecompressPointer r2
    //     0x7b0854: add             x2, x2, HEAP, lsl #32
    // 0x7b0858: cmp             w2, NULL
    // 0x7b085c: b.eq            #0x7b087c
    // 0x7b0860: mov             x0, x2
    // 0x7b0864: b               #0x7b086c
    // 0x7b0868: mov             x0, x3
    // 0x7b086c: LeaveFrame
    //     0x7b086c: mov             SP, fp
    //     0x7b0870: ldp             fp, lr, [SP], #0x10
    // 0x7b0874: ret
    //     0x7b0874: ret             
    // 0x7b0878: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0878: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b087c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b087c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initStatesController(/* No info */) {
    // ** addr: 0x7b0908, size: 0x190
    // 0x7b0908: EnterFrame
    //     0x7b0908: stp             fp, lr, [SP, #-0x10]!
    //     0x7b090c: mov             fp, SP
    // 0x7b0910: AllocStack(0x8)
    //     0x7b0910: sub             SP, SP, #8
    // 0x7b0914: CheckStackOverflow
    //     0x7b0914: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0918: cmp             SP, x16
    //     0x7b091c: b.ls            #0x7b0a7c
    // 0x7b0920: ldr             x0, [fp, #0x10]
    // 0x7b0924: LoadField: r1 = r0->field_b
    //     0x7b0924: ldur            w1, [x0, #0xb]
    // 0x7b0928: DecompressPointer r1
    //     0x7b0928: add             x1, x1, HEAP, lsl #32
    // 0x7b092c: cmp             w1, NULL
    // 0x7b0930: b.eq            #0x7b0a84
    // 0x7b0934: LoadField: r2 = r1->field_2b
    //     0x7b0934: ldur            w2, [x1, #0x2b]
    // 0x7b0938: DecompressPointer r2
    //     0x7b0938: add             x2, x2, HEAP, lsl #32
    // 0x7b093c: cmp             w2, NULL
    // 0x7b0940: b.ne            #0x7b098c
    // 0x7b0944: r1 = <Set<MaterialState>>
    //     0x7b0944: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e518] TypeArguments: <Set<MaterialState>>
    //     0x7b0948: ldr             x1, [x1, #0x518]
    // 0x7b094c: r0 = MaterialStatesController()
    //     0x7b094c: bl              #0x7b0bfc  ; AllocateMaterialStatesControllerStub -> MaterialStatesController (size=0x2c)
    // 0x7b0950: stur            x0, [fp, #-8]
    // 0x7b0954: SaveReg r0
    //     0x7b0954: str             x0, [SP, #-8]!
    // 0x7b0958: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b0958: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b095c: r0 = MaterialStatesController()
    //     0x7b095c: bl              #0x7b0a98  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::MaterialStatesController
    // 0x7b0960: add             SP, SP, #8
    // 0x7b0964: ldur            x0, [fp, #-8]
    // 0x7b0968: ldr             x1, [fp, #0x10]
    // 0x7b096c: StoreField: r1->field_27 = r0
    //     0x7b096c: stur            w0, [x1, #0x27]
    //     0x7b0970: ldurb           w16, [x1, #-1]
    //     0x7b0974: ldurb           w17, [x0, #-1]
    //     0x7b0978: and             x16, x17, x16, lsr #2
    //     0x7b097c: tst             x16, HEAP, lsr #32
    //     0x7b0980: b.eq            #0x7b0988
    //     0x7b0984: bl              #0xd6826c
    // 0x7b0988: b               #0x7b0990
    // 0x7b098c: mov             x1, x0
    // 0x7b0990: LoadField: r0 = r1->field_b
    //     0x7b0990: ldur            w0, [x1, #0xb]
    // 0x7b0994: DecompressPointer r0
    //     0x7b0994: add             x0, x0, HEAP, lsl #32
    // 0x7b0998: cmp             w0, NULL
    // 0x7b099c: b.eq            #0x7b0a88
    // 0x7b09a0: LoadField: r2 = r0->field_2b
    //     0x7b09a0: ldur            w2, [x0, #0x2b]
    // 0x7b09a4: DecompressPointer r2
    //     0x7b09a4: add             x2, x2, HEAP, lsl #32
    // 0x7b09a8: cmp             w2, NULL
    // 0x7b09ac: b.ne            #0x7b09c0
    // 0x7b09b0: LoadField: r2 = r1->field_27
    //     0x7b09b0: ldur            w2, [x1, #0x27]
    // 0x7b09b4: DecompressPointer r2
    //     0x7b09b4: add             x2, x2, HEAP, lsl #32
    // 0x7b09b8: cmp             w2, NULL
    // 0x7b09bc: b.eq            #0x7b0a8c
    // 0x7b09c0: LoadField: r3 = r0->field_b
    //     0x7b09c0: ldur            w3, [x0, #0xb]
    // 0x7b09c4: DecompressPointer r3
    //     0x7b09c4: add             x3, x3, HEAP, lsl #32
    // 0x7b09c8: cmp             w3, NULL
    // 0x7b09cc: b.eq            #0x7b09d8
    // 0x7b09d0: r0 = true
    //     0x7b09d0: add             x0, NULL, #0x20  ; true
    // 0x7b09d4: b               #0x7b09dc
    // 0x7b09d8: r0 = false
    //     0x7b09d8: add             x0, NULL, #0x30  ; false
    // 0x7b09dc: eor             x3, x0, #0x10
    // 0x7b09e0: r16 = Instance_MaterialState
    //     0x7b09e0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b09e4: ldr             x16, [x16, #0x2a0]
    // 0x7b09e8: stp             x16, x2, [SP, #-0x10]!
    // 0x7b09ec: SaveReg r3
    //     0x7b09ec: str             x3, [SP, #-8]!
    // 0x7b09f0: r0 = update()
    //     0x7b09f0: bl              #0x7b0880  ; [package:flutter/src/material/material_state.dart] MaterialStatesController::update
    // 0x7b09f4: add             SP, SP, #0x18
    // 0x7b09f8: ldr             x0, [fp, #0x10]
    // 0x7b09fc: LoadField: r1 = r0->field_b
    //     0x7b09fc: ldur            w1, [x0, #0xb]
    // 0x7b0a00: DecompressPointer r1
    //     0x7b0a00: add             x1, x1, HEAP, lsl #32
    // 0x7b0a04: cmp             w1, NULL
    // 0x7b0a08: b.eq            #0x7b0a90
    // 0x7b0a0c: LoadField: r2 = r1->field_2b
    //     0x7b0a0c: ldur            w2, [x1, #0x2b]
    // 0x7b0a10: DecompressPointer r2
    //     0x7b0a10: add             x2, x2, HEAP, lsl #32
    // 0x7b0a14: cmp             w2, NULL
    // 0x7b0a18: b.ne            #0x7b0a30
    // 0x7b0a1c: LoadField: r1 = r0->field_27
    //     0x7b0a1c: ldur            w1, [x0, #0x27]
    // 0x7b0a20: DecompressPointer r1
    //     0x7b0a20: add             x1, x1, HEAP, lsl #32
    // 0x7b0a24: cmp             w1, NULL
    // 0x7b0a28: b.eq            #0x7b0a94
    // 0x7b0a2c: b               #0x7b0a34
    // 0x7b0a30: mov             x1, x2
    // 0x7b0a34: stur            x1, [fp, #-8]
    // 0x7b0a38: r1 = 1
    //     0x7b0a38: mov             x1, #1
    // 0x7b0a3c: r0 = AllocateContext()
    //     0x7b0a3c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b0a40: mov             x1, x0
    // 0x7b0a44: ldr             x0, [fp, #0x10]
    // 0x7b0a48: StoreField: r1->field_f = r0
    //     0x7b0a48: stur            w0, [x1, #0xf]
    // 0x7b0a4c: mov             x2, x1
    // 0x7b0a50: r1 = Function 'handleStatesControllerChange':.
    //     0x7b0a50: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e720] AnonymousClosure: (0x7b0c08), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange (0x7b0c50)
    //     0x7b0a54: ldr             x1, [x1, #0x720]
    // 0x7b0a58: r0 = AllocateClosure()
    //     0x7b0a58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0a5c: ldur            x16, [fp, #-8]
    // 0x7b0a60: stp             x0, x16, [SP, #-0x10]!
    // 0x7b0a64: r0 = addListener()
    //     0x7b0a64: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7b0a68: add             SP, SP, #0x10
    // 0x7b0a6c: r0 = Null
    //     0x7b0a6c: mov             x0, NULL
    // 0x7b0a70: LeaveFrame
    //     0x7b0a70: mov             SP, fp
    //     0x7b0a74: ldp             fp, lr, [SP], #0x10
    // 0x7b0a78: ret
    //     0x7b0a78: ret             
    // 0x7b0a7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0a7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0a80: b               #0x7b0920
    // 0x7b0a84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0a84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0a88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0a88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0a8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0a8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0a90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0a90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0a94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0a94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void handleStatesControllerChange(dynamic) {
    // ** addr: 0x7b0c08, size: 0x48
    // 0x7b0c08: EnterFrame
    //     0x7b0c08: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0c0c: mov             fp, SP
    // 0x7b0c10: ldr             x0, [fp, #0x10]
    // 0x7b0c14: LoadField: r1 = r0->field_17
    //     0x7b0c14: ldur            w1, [x0, #0x17]
    // 0x7b0c18: DecompressPointer r1
    //     0x7b0c18: add             x1, x1, HEAP, lsl #32
    // 0x7b0c1c: CheckStackOverflow
    //     0x7b0c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0c20: cmp             SP, x16
    //     0x7b0c24: b.ls            #0x7b0c48
    // 0x7b0c28: LoadField: r0 = r1->field_f
    //     0x7b0c28: ldur            w0, [x1, #0xf]
    // 0x7b0c2c: DecompressPointer r0
    //     0x7b0c2c: add             x0, x0, HEAP, lsl #32
    // 0x7b0c30: SaveReg r0
    //     0x7b0c30: str             x0, [SP, #-8]!
    // 0x7b0c34: r0 = handleStatesControllerChange()
    //     0x7b0c34: bl              #0x7b0c50  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange
    // 0x7b0c38: add             SP, SP, #8
    // 0x7b0c3c: LeaveFrame
    //     0x7b0c3c: mov             SP, fp
    //     0x7b0c40: ldp             fp, lr, [SP], #0x10
    // 0x7b0c44: ret
    //     0x7b0c44: ret             
    // 0x7b0c48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0c48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0c4c: b               #0x7b0c28
  }
  _ handleStatesControllerChange(/* No info */) {
    // ** addr: 0x7b0c50, size: 0x4c
    // 0x7b0c50: EnterFrame
    //     0x7b0c50: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0c54: mov             fp, SP
    // 0x7b0c58: CheckStackOverflow
    //     0x7b0c58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0c5c: cmp             SP, x16
    //     0x7b0c60: b.ls            #0x7b0c94
    // 0x7b0c64: r1 = Function '<anonymous closure>':.
    //     0x7b0c64: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e728] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7b0c68: ldr             x1, [x1, #0x728]
    // 0x7b0c6c: r2 = Null
    //     0x7b0c6c: mov             x2, NULL
    // 0x7b0c70: r0 = AllocateClosure()
    //     0x7b0c70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0c74: ldr             x16, [fp, #0x10]
    // 0x7b0c78: stp             x0, x16, [SP, #-0x10]!
    // 0x7b0c7c: r0 = setState()
    //     0x7b0c7c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b0c80: add             SP, SP, #0x10
    // 0x7b0c84: r0 = Null
    //     0x7b0c84: mov             x0, NULL
    // 0x7b0c88: LeaveFrame
    //     0x7b0c88: mov             SP, fp
    //     0x7b0c8c: ldp             fp, lr, [SP], #0x10
    // 0x7b0c90: ret
    //     0x7b0c90: ret             
    // 0x7b0c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0c98: b               #0x7b0c64
  }
  _ build(/* No info */) {
    // ** addr: 0x84bfac, size: 0x10f4
    // 0x84bfac: EnterFrame
    //     0x84bfac: stp             fp, lr, [SP, #-0x10]!
    //     0x84bfb0: mov             fp, SP
    // 0x84bfb4: AllocStack(0xe8)
    //     0x84bfb4: sub             SP, SP, #0xe8
    // 0x84bfb8: CheckStackOverflow
    //     0x84bfb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84bfbc: cmp             SP, x16
    //     0x84bfc0: b.ls            #0x84d018
    // 0x84bfc4: r1 = 5
    //     0x84bfc4: mov             x1, #5
    // 0x84bfc8: r0 = AllocateContext()
    //     0x84bfc8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84bfcc: mov             x2, x0
    // 0x84bfd0: ldr             x1, [fp, #0x18]
    // 0x84bfd4: stur            x2, [fp, #-8]
    // 0x84bfd8: StoreField: r2->field_f = r1
    //     0x84bfd8: stur            w1, [x2, #0xf]
    // 0x84bfdc: LoadField: r0 = r1->field_b
    //     0x84bfdc: ldur            w0, [x1, #0xb]
    // 0x84bfe0: DecompressPointer r0
    //     0x84bfe0: add             x0, x0, HEAP, lsl #32
    // 0x84bfe4: cmp             w0, NULL
    // 0x84bfe8: b.eq            #0x84d020
    // 0x84bfec: LoadField: r3 = r0->field_1b
    //     0x84bfec: ldur            w3, [x0, #0x1b]
    // 0x84bff0: DecompressPointer r3
    //     0x84bff0: add             x3, x3, HEAP, lsl #32
    // 0x84bff4: StoreField: r2->field_13 = r3
    //     0x84bff4: stur            w3, [x2, #0x13]
    // 0x84bff8: r3 = LoadClassIdInstr(r0)
    //     0x84bff8: ldur            x3, [x0, #-1]
    //     0x84bffc: ubfx            x3, x3, #0xc, #0x14
    // 0x84c000: ldr             x16, [fp, #0x10]
    // 0x84c004: stp             x16, x0, [SP, #-0x10]!
    // 0x84c008: mov             x0, x3
    // 0x84c00c: r0 = GDT[cid_x0 + 0xcd1]()
    //     0x84c00c: add             lr, x0, #0xcd1
    //     0x84c010: ldr             lr, [x21, lr, lsl #3]
    //     0x84c014: blr             lr
    // 0x84c018: add             SP, SP, #0x10
    // 0x84c01c: ldur            x2, [fp, #-8]
    // 0x84c020: StoreField: r2->field_17 = r0
    //     0x84c020: stur            w0, [x2, #0x17]
    //     0x84c024: ldurb           w16, [x2, #-1]
    //     0x84c028: ldurb           w17, [x0, #-1]
    //     0x84c02c: and             x16, x17, x16, lsr #2
    //     0x84c030: tst             x16, HEAP, lsr #32
    //     0x84c034: b.eq            #0x84c03c
    //     0x84c038: bl              #0xd6828c
    // 0x84c03c: ldr             x1, [fp, #0x18]
    // 0x84c040: LoadField: r0 = r1->field_b
    //     0x84c040: ldur            w0, [x1, #0xb]
    // 0x84c044: DecompressPointer r0
    //     0x84c044: add             x0, x0, HEAP, lsl #32
    // 0x84c048: cmp             w0, NULL
    // 0x84c04c: b.eq            #0x84d024
    // 0x84c050: r3 = LoadClassIdInstr(r0)
    //     0x84c050: ldur            x3, [x0, #-1]
    //     0x84c054: ubfx            x3, x3, #0xc, #0x14
    // 0x84c058: ldr             x16, [fp, #0x10]
    // 0x84c05c: stp             x16, x0, [SP, #-0x10]!
    // 0x84c060: mov             x0, x3
    // 0x84c064: r0 = GDT[cid_x0 + 0xcbc]()
    //     0x84c064: add             lr, x0, #0xcbc
    //     0x84c068: ldr             lr, [x21, lr, lsl #3]
    //     0x84c06c: blr             lr
    // 0x84c070: add             SP, SP, #0x10
    // 0x84c074: ldur            x3, [fp, #-8]
    // 0x84c078: StoreField: r3->field_1b = r0
    //     0x84c078: stur            w0, [x3, #0x1b]
    //     0x84c07c: ldurb           w16, [x3, #-1]
    //     0x84c080: ldurb           w17, [x0, #-1]
    //     0x84c084: and             x16, x17, x16, lsr #2
    //     0x84c088: tst             x16, HEAP, lsr #32
    //     0x84c08c: b.eq            #0x84c094
    //     0x84c090: bl              #0xd682ac
    // 0x84c094: mov             x2, x3
    // 0x84c098: r1 = Function 'effectiveValue':.
    //     0x84c098: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5b0] AnonymousClosure: (0x84df44), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c09c: ldr             x1, [x1, #0x5b0]
    // 0x84c0a0: r0 = AllocateClosure()
    //     0x84c0a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c0a4: mov             x4, x0
    // 0x84c0a8: r3 = 
    //     0x84c0a8: ldr             x3, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    // 0x84c0ac: stur            x4, [fp, #-0x10]
    // 0x84c0b0: StoreField: r4->field_f = r3
    //     0x84c0b0: stur            w3, [x4, #0xf]
    // 0x84c0b4: mov             x0, x4
    // 0x84c0b8: ldur            x5, [fp, #-8]
    // 0x84c0bc: StoreField: r5->field_1f = r0
    //     0x84c0bc: stur            w0, [x5, #0x1f]
    //     0x84c0c0: ldurb           w16, [x5, #-1]
    //     0x84c0c4: ldurb           w17, [x0, #-1]
    //     0x84c0c8: and             x16, x17, x16, lsr #2
    //     0x84c0cc: tst             x16, HEAP, lsr #32
    //     0x84c0d0: b.eq            #0x84c0d8
    //     0x84c0d4: bl              #0xd682ec
    // 0x84c0d8: mov             x2, x5
    // 0x84c0dc: r1 = Function 'resolve':.
    //     0x84c0dc: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5b8] AnonymousClosure: (0x84dd5c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c0e0: ldr             x1, [x1, #0x5b8]
    // 0x84c0e4: r0 = AllocateClosure()
    //     0x84c0e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c0e8: mov             x3, x0
    // 0x84c0ec: r0 = 
    //     0x84c0ec: ldr             x0, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    // 0x84c0f0: stur            x3, [fp, #-0x18]
    // 0x84c0f4: StoreField: r3->field_f = r0
    //     0x84c0f4: stur            w0, [x3, #0xf]
    // 0x84c0f8: r1 = Function '<anonymous closure>':.
    //     0x84c0f8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5c0] AnonymousClosure: (0x84dd00), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c0fc: ldr             x1, [x1, #0x5c0]
    // 0x84c100: r2 = Null
    //     0x84c100: mov             x2, NULL
    // 0x84c104: r0 = AllocateClosure()
    //     0x84c104: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c108: r16 = <double?>
    //     0x84c108: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0x84c10c: ldr             x16, [x16, #0xb88]
    // 0x84c110: ldur            lr, [fp, #-0x18]
    // 0x84c114: stp             lr, x16, [SP, #-0x10]!
    // 0x84c118: SaveReg r0
    //     0x84c118: str             x0, [SP, #-8]!
    // 0x84c11c: ldur            x0, [fp, #-0x18]
    // 0x84c120: ClosureCall
    //     0x84c120: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c124: ldur            x2, [x0, #0x1f]
    //     0x84c128: blr             x2
    // 0x84c12c: add             SP, SP, #0x18
    // 0x84c130: r1 = Function '<anonymous closure>':.
    //     0x84c130: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5c8] AnonymousClosure: (0x84dca4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c134: ldr             x1, [x1, #0x5c8]
    // 0x84c138: r2 = Null
    //     0x84c138: mov             x2, NULL
    // 0x84c13c: stur            x0, [fp, #-0x20]
    // 0x84c140: r0 = AllocateClosure()
    //     0x84c140: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c144: r16 = <TextStyle?>
    //     0x84c144: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0x84c148: ldr             x16, [x16, #0x8c0]
    // 0x84c14c: ldur            lr, [fp, #-0x18]
    // 0x84c150: stp             lr, x16, [SP, #-0x10]!
    // 0x84c154: SaveReg r0
    //     0x84c154: str             x0, [SP, #-8]!
    // 0x84c158: ldur            x0, [fp, #-0x18]
    // 0x84c15c: ClosureCall
    //     0x84c15c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c160: ldur            x2, [x0, #0x1f]
    //     0x84c164: blr             x2
    // 0x84c168: add             SP, SP, #0x18
    // 0x84c16c: r1 = Function '<anonymous closure>':.
    //     0x84c16c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5d0] AnonymousClosure: (0x84dc48), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c170: ldr             x1, [x1, #0x5d0]
    // 0x84c174: r2 = Null
    //     0x84c174: mov             x2, NULL
    // 0x84c178: stur            x0, [fp, #-0x28]
    // 0x84c17c: r0 = AllocateClosure()
    //     0x84c17c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c180: r16 = <Color?>
    //     0x84c180: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84c184: ldr             x16, [x16, #0xf68]
    // 0x84c188: ldur            lr, [fp, #-0x18]
    // 0x84c18c: stp             lr, x16, [SP, #-0x10]!
    // 0x84c190: SaveReg r0
    //     0x84c190: str             x0, [SP, #-8]!
    // 0x84c194: ldur            x0, [fp, #-0x18]
    // 0x84c198: ClosureCall
    //     0x84c198: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c19c: ldur            x2, [x0, #0x1f]
    //     0x84c1a0: blr             x2
    // 0x84c1a4: add             SP, SP, #0x18
    // 0x84c1a8: r1 = Function '<anonymous closure>':.
    //     0x84c1a8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5d8] AnonymousClosure: (0x84dbec), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c1ac: ldr             x1, [x1, #0x5d8]
    // 0x84c1b0: r2 = Null
    //     0x84c1b0: mov             x2, NULL
    // 0x84c1b4: stur            x0, [fp, #-0x30]
    // 0x84c1b8: r0 = AllocateClosure()
    //     0x84c1b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c1bc: r16 = <Color?>
    //     0x84c1bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84c1c0: ldr             x16, [x16, #0xf68]
    // 0x84c1c4: ldur            lr, [fp, #-0x18]
    // 0x84c1c8: stp             lr, x16, [SP, #-0x10]!
    // 0x84c1cc: SaveReg r0
    //     0x84c1cc: str             x0, [SP, #-8]!
    // 0x84c1d0: ldur            x0, [fp, #-0x18]
    // 0x84c1d4: ClosureCall
    //     0x84c1d4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c1d8: ldur            x2, [x0, #0x1f]
    //     0x84c1dc: blr             x2
    // 0x84c1e0: add             SP, SP, #0x18
    // 0x84c1e4: r1 = Function '<anonymous closure>':.
    //     0x84c1e4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5e0] AnonymousClosure: (0x84db90), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c1e8: ldr             x1, [x1, #0x5e0]
    // 0x84c1ec: r2 = Null
    //     0x84c1ec: mov             x2, NULL
    // 0x84c1f0: stur            x0, [fp, #-0x38]
    // 0x84c1f4: r0 = AllocateClosure()
    //     0x84c1f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c1f8: r16 = <Color?>
    //     0x84c1f8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84c1fc: ldr             x16, [x16, #0xf68]
    // 0x84c200: ldur            lr, [fp, #-0x18]
    // 0x84c204: stp             lr, x16, [SP, #-0x10]!
    // 0x84c208: SaveReg r0
    //     0x84c208: str             x0, [SP, #-8]!
    // 0x84c20c: ldur            x0, [fp, #-0x18]
    // 0x84c210: ClosureCall
    //     0x84c210: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c214: ldur            x2, [x0, #0x1f]
    //     0x84c218: blr             x2
    // 0x84c21c: add             SP, SP, #0x18
    // 0x84c220: r1 = Function '<anonymous closure>':.
    //     0x84c220: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5e8] AnonymousClosure: (0x84db34), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c224: ldr             x1, [x1, #0x5e8]
    // 0x84c228: r2 = Null
    //     0x84c228: mov             x2, NULL
    // 0x84c22c: stur            x0, [fp, #-0x40]
    // 0x84c230: r0 = AllocateClosure()
    //     0x84c230: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c234: r16 = <Color?>
    //     0x84c234: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84c238: ldr             x16, [x16, #0xf68]
    // 0x84c23c: ldur            lr, [fp, #-0x18]
    // 0x84c240: stp             lr, x16, [SP, #-0x10]!
    // 0x84c244: SaveReg r0
    //     0x84c244: str             x0, [SP, #-8]!
    // 0x84c248: ldur            x0, [fp, #-0x18]
    // 0x84c24c: ClosureCall
    //     0x84c24c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c250: ldur            x2, [x0, #0x1f]
    //     0x84c254: blr             x2
    // 0x84c258: add             SP, SP, #0x18
    // 0x84c25c: r1 = Function '<anonymous closure>':.
    //     0x84c25c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5f0] AnonymousClosure: (0x84dad8), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c260: ldr             x1, [x1, #0x5f0]
    // 0x84c264: r2 = Null
    //     0x84c264: mov             x2, NULL
    // 0x84c268: stur            x0, [fp, #-0x48]
    // 0x84c26c: r0 = AllocateClosure()
    //     0x84c26c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c270: r16 = <EdgeInsetsGeometry?>
    //     0x84c270: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db98] TypeArguments: <EdgeInsetsGeometry?>
    //     0x84c274: ldr             x16, [x16, #0xb98]
    // 0x84c278: ldur            lr, [fp, #-0x18]
    // 0x84c27c: stp             lr, x16, [SP, #-0x10]!
    // 0x84c280: SaveReg r0
    //     0x84c280: str             x0, [SP, #-8]!
    // 0x84c284: ldur            x0, [fp, #-0x18]
    // 0x84c288: ClosureCall
    //     0x84c288: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c28c: ldur            x2, [x0, #0x1f]
    //     0x84c290: blr             x2
    // 0x84c294: add             SP, SP, #0x18
    // 0x84c298: r1 = Function '<anonymous closure>':.
    //     0x84c298: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5f8] AnonymousClosure: (0x84da7c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c29c: ldr             x1, [x1, #0x5f8]
    // 0x84c2a0: r2 = Null
    //     0x84c2a0: mov             x2, NULL
    // 0x84c2a4: stur            x0, [fp, #-0x50]
    // 0x84c2a8: r0 = AllocateClosure()
    //     0x84c2a8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c2ac: r16 = <Size?>
    //     0x84c2ac: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0x84c2b0: ldr             x16, [x16, #0xba8]
    // 0x84c2b4: ldur            lr, [fp, #-0x18]
    // 0x84c2b8: stp             lr, x16, [SP, #-0x10]!
    // 0x84c2bc: SaveReg r0
    //     0x84c2bc: str             x0, [SP, #-8]!
    // 0x84c2c0: ldur            x0, [fp, #-0x18]
    // 0x84c2c4: ClosureCall
    //     0x84c2c4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c2c8: ldur            x2, [x0, #0x1f]
    //     0x84c2cc: blr             x2
    // 0x84c2d0: add             SP, SP, #0x18
    // 0x84c2d4: r1 = Function '<anonymous closure>':.
    //     0x84c2d4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e600] AnonymousClosure: (0x84da58), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c2d8: ldr             x1, [x1, #0x600]
    // 0x84c2dc: r2 = Null
    //     0x84c2dc: mov             x2, NULL
    // 0x84c2e0: stur            x0, [fp, #-0x58]
    // 0x84c2e4: r0 = AllocateClosure()
    //     0x84c2e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c2e8: r16 = <Size?>
    //     0x84c2e8: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0x84c2ec: ldr             x16, [x16, #0xba8]
    // 0x84c2f0: ldur            lr, [fp, #-0x18]
    // 0x84c2f4: stp             lr, x16, [SP, #-0x10]!
    // 0x84c2f8: SaveReg r0
    //     0x84c2f8: str             x0, [SP, #-8]!
    // 0x84c2fc: ldur            x0, [fp, #-0x18]
    // 0x84c300: ClosureCall
    //     0x84c300: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c304: ldur            x2, [x0, #0x1f]
    //     0x84c308: blr             x2
    // 0x84c30c: add             SP, SP, #0x18
    // 0x84c310: r1 = Function '<anonymous closure>':.
    //     0x84c310: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e608] AnonymousClosure: (0x84d9fc), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c314: ldr             x1, [x1, #0x608]
    // 0x84c318: r2 = Null
    //     0x84c318: mov             x2, NULL
    // 0x84c31c: stur            x0, [fp, #-0x60]
    // 0x84c320: r0 = AllocateClosure()
    //     0x84c320: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c324: r16 = <Size?>
    //     0x84c324: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dba8] TypeArguments: <Size?>
    //     0x84c328: ldr             x16, [x16, #0xba8]
    // 0x84c32c: ldur            lr, [fp, #-0x18]
    // 0x84c330: stp             lr, x16, [SP, #-0x10]!
    // 0x84c334: SaveReg r0
    //     0x84c334: str             x0, [SP, #-8]!
    // 0x84c338: ldur            x0, [fp, #-0x18]
    // 0x84c33c: ClosureCall
    //     0x84c33c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c340: ldur            x2, [x0, #0x1f]
    //     0x84c344: blr             x2
    // 0x84c348: add             SP, SP, #0x18
    // 0x84c34c: r1 = Function '<anonymous closure>':.
    //     0x84c34c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e610] AnonymousClosure: (0x84d9d8), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c350: ldr             x1, [x1, #0x610]
    // 0x84c354: r2 = Null
    //     0x84c354: mov             x2, NULL
    // 0x84c358: stur            x0, [fp, #-0x68]
    // 0x84c35c: r0 = AllocateClosure()
    //     0x84c35c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c360: r16 = <Color?>
    //     0x84c360: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84c364: ldr             x16, [x16, #0xf68]
    // 0x84c368: ldur            lr, [fp, #-0x18]
    // 0x84c36c: stp             lr, x16, [SP, #-0x10]!
    // 0x84c370: SaveReg r0
    //     0x84c370: str             x0, [SP, #-8]!
    // 0x84c374: ldur            x0, [fp, #-0x18]
    // 0x84c378: ClosureCall
    //     0x84c378: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c37c: ldur            x2, [x0, #0x1f]
    //     0x84c380: blr             x2
    // 0x84c384: add             SP, SP, #0x18
    // 0x84c388: r1 = Function '<anonymous closure>':.
    //     0x84c388: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e618] AnonymousClosure: (0x84d974), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c38c: ldr             x1, [x1, #0x618]
    // 0x84c390: r2 = Null
    //     0x84c390: mov             x2, NULL
    // 0x84c394: stur            x0, [fp, #-0x70]
    // 0x84c398: r0 = AllocateClosure()
    //     0x84c398: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c39c: r16 = <double?>
    //     0x84c39c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0x84c3a0: ldr             x16, [x16, #0xb88]
    // 0x84c3a4: ldur            lr, [fp, #-0x18]
    // 0x84c3a8: stp             lr, x16, [SP, #-0x10]!
    // 0x84c3ac: SaveReg r0
    //     0x84c3ac: str             x0, [SP, #-8]!
    // 0x84c3b0: ldur            x0, [fp, #-0x18]
    // 0x84c3b4: ClosureCall
    //     0x84c3b4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c3b8: ldur            x2, [x0, #0x1f]
    //     0x84c3bc: blr             x2
    // 0x84c3c0: add             SP, SP, #0x18
    // 0x84c3c4: r1 = Function '<anonymous closure>':.
    //     0x84c3c4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e620] AnonymousClosure: (0x84d6d8), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c3c8: ldr             x1, [x1, #0x620]
    // 0x84c3cc: r2 = Null
    //     0x84c3cc: mov             x2, NULL
    // 0x84c3d0: stur            x0, [fp, #-0x78]
    // 0x84c3d4: r0 = AllocateClosure()
    //     0x84c3d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c3d8: r16 = <BorderSide?>
    //     0x84c3d8: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e628] TypeArguments: <BorderSide?>
    //     0x84c3dc: ldr             x16, [x16, #0x628]
    // 0x84c3e0: ldur            lr, [fp, #-0x18]
    // 0x84c3e4: stp             lr, x16, [SP, #-0x10]!
    // 0x84c3e8: SaveReg r0
    //     0x84c3e8: str             x0, [SP, #-8]!
    // 0x84c3ec: ldur            x0, [fp, #-0x18]
    // 0x84c3f0: ClosureCall
    //     0x84c3f0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c3f4: ldur            x2, [x0, #0x1f]
    //     0x84c3f8: blr             x2
    // 0x84c3fc: add             SP, SP, #0x18
    // 0x84c400: r1 = Function '<anonymous closure>':.
    //     0x84c400: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e630] AnonymousClosure: (0x84d67c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c404: ldr             x1, [x1, #0x630]
    // 0x84c408: r2 = Null
    //     0x84c408: mov             x2, NULL
    // 0x84c40c: stur            x0, [fp, #-0x80]
    // 0x84c410: r0 = AllocateClosure()
    //     0x84c410: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c414: r16 = <OutlinedBorder?>
    //     0x84c414: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbb8] TypeArguments: <OutlinedBorder?>
    //     0x84c418: ldr             x16, [x16, #0xbb8]
    // 0x84c41c: ldur            lr, [fp, #-0x18]
    // 0x84c420: stp             lr, x16, [SP, #-0x10]!
    // 0x84c424: SaveReg r0
    //     0x84c424: str             x0, [SP, #-8]!
    // 0x84c428: ldur            x0, [fp, #-0x18]
    // 0x84c42c: ClosureCall
    //     0x84c42c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c430: ldur            x2, [x0, #0x1f]
    //     0x84c434: blr             x2
    // 0x84c438: add             SP, SP, #0x18
    // 0x84c43c: stur            x0, [fp, #-0x18]
    // 0x84c440: r0 = _MouseCursor()
    //     0x84c440: bl              #0x84d198  ; Allocate_MouseCursorStub -> _MouseCursor (size=0xc)
    // 0x84c444: ldur            x2, [fp, #-8]
    // 0x84c448: r1 = Function '<anonymous closure>':.
    //     0x84c448: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e638] AnonymousClosure: (0x84d528), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c44c: ldr             x1, [x1, #0x638]
    // 0x84c450: stur            x0, [fp, #-0x88]
    // 0x84c454: r0 = AllocateClosure()
    //     0x84c454: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c458: mov             x1, x0
    // 0x84c45c: ldur            x0, [fp, #-0x88]
    // 0x84c460: StoreField: r0->field_7 = r1
    //     0x84c460: stur            w1, [x0, #7]
    // 0x84c464: ldur            x2, [fp, #-8]
    // 0x84c468: r1 = Function '<anonymous closure>':.
    //     0x84c468: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e640] AnonymousClosure: (0x84d3d0), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c46c: ldr             x1, [x1, #0x640]
    // 0x84c470: r0 = AllocateClosure()
    //     0x84c470: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c474: r16 = <Color?>
    //     0x84c474: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84c478: ldr             x16, [x16, #0xf68]
    // 0x84c47c: stp             x0, x16, [SP, #-0x10]!
    // 0x84c480: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84c480: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84c484: r0 = resolveWith()
    //     0x84c484: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84c488: add             SP, SP, #0x10
    // 0x84c48c: r1 = Function '<anonymous closure>':.
    //     0x84c48c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e648] AnonymousClosure: (0x84d374), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c490: ldr             x1, [x1, #0x648]
    // 0x84c494: r2 = Null
    //     0x84c494: mov             x2, NULL
    // 0x84c498: stur            x0, [fp, #-0x90]
    // 0x84c49c: r0 = AllocateClosure()
    //     0x84c49c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c4a0: r16 = <VisualDensity>
    //     0x84c4a0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e650] TypeArguments: <VisualDensity>
    //     0x84c4a4: ldr             x16, [x16, #0x650]
    // 0x84c4a8: ldur            lr, [fp, #-0x10]
    // 0x84c4ac: stp             lr, x16, [SP, #-0x10]!
    // 0x84c4b0: SaveReg r0
    //     0x84c4b0: str             x0, [SP, #-8]!
    // 0x84c4b4: ldur            x0, [fp, #-0x10]
    // 0x84c4b8: ClosureCall
    //     0x84c4b8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c4bc: ldur            x2, [x0, #0x1f]
    //     0x84c4c0: blr             x2
    // 0x84c4c4: add             SP, SP, #0x18
    // 0x84c4c8: r1 = Function '<anonymous closure>':.
    //     0x84c4c8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e658] AnonymousClosure: (0x84d318), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c4cc: ldr             x1, [x1, #0x658]
    // 0x84c4d0: r2 = Null
    //     0x84c4d0: mov             x2, NULL
    // 0x84c4d4: stur            x0, [fp, #-0x98]
    // 0x84c4d8: r0 = AllocateClosure()
    //     0x84c4d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c4dc: r16 = <MaterialTapTargetSize>
    //     0x84c4dc: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e660] TypeArguments: <MaterialTapTargetSize>
    //     0x84c4e0: ldr             x16, [x16, #0x660]
    // 0x84c4e4: ldur            lr, [fp, #-0x10]
    // 0x84c4e8: stp             lr, x16, [SP, #-0x10]!
    // 0x84c4ec: SaveReg r0
    //     0x84c4ec: str             x0, [SP, #-8]!
    // 0x84c4f0: ldur            x0, [fp, #-0x10]
    // 0x84c4f4: ClosureCall
    //     0x84c4f4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c4f8: ldur            x2, [x0, #0x1f]
    //     0x84c4fc: blr             x2
    // 0x84c500: add             SP, SP, #0x18
    // 0x84c504: r1 = Function '<anonymous closure>':.
    //     0x84c504: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e668] AnonymousClosure: (0x84d2f4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c508: ldr             x1, [x1, #0x668]
    // 0x84c50c: r2 = Null
    //     0x84c50c: mov             x2, NULL
    // 0x84c510: stur            x0, [fp, #-0xa0]
    // 0x84c514: r0 = AllocateClosure()
    //     0x84c514: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c518: r16 = <Duration>
    //     0x84c518: ldr             x16, [PP, #0x1ef0]  ; [pp+0x1ef0] TypeArguments: <Duration>
    // 0x84c51c: ldur            lr, [fp, #-0x10]
    // 0x84c520: stp             lr, x16, [SP, #-0x10]!
    // 0x84c524: SaveReg r0
    //     0x84c524: str             x0, [SP, #-8]!
    // 0x84c528: ldur            x0, [fp, #-0x10]
    // 0x84c52c: ClosureCall
    //     0x84c52c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c530: ldur            x2, [x0, #0x1f]
    //     0x84c534: blr             x2
    // 0x84c538: add             SP, SP, #0x18
    // 0x84c53c: r1 = Function '<anonymous closure>':.
    //     0x84c53c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e670] AnonymousClosure: (0x84d2d0), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c540: ldr             x1, [x1, #0x670]
    // 0x84c544: r2 = Null
    //     0x84c544: mov             x2, NULL
    // 0x84c548: stur            x0, [fp, #-0xa8]
    // 0x84c54c: r0 = AllocateClosure()
    //     0x84c54c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c550: r16 = <bool>
    //     0x84c550: ldr             x16, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x84c554: ldur            lr, [fp, #-0x10]
    // 0x84c558: stp             lr, x16, [SP, #-0x10]!
    // 0x84c55c: SaveReg r0
    //     0x84c55c: str             x0, [SP, #-8]!
    // 0x84c560: ldur            x0, [fp, #-0x10]
    // 0x84c564: ClosureCall
    //     0x84c564: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c568: ldur            x2, [x0, #0x1f]
    //     0x84c56c: blr             x2
    // 0x84c570: add             SP, SP, #0x18
    // 0x84c574: r1 = Function '<anonymous closure>':.
    //     0x84c574: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e678] AnonymousClosure: (0x84d27c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c578: ldr             x1, [x1, #0x678]
    // 0x84c57c: r2 = Null
    //     0x84c57c: mov             x2, NULL
    // 0x84c580: stur            x0, [fp, #-0xb0]
    // 0x84c584: r0 = AllocateClosure()
    //     0x84c584: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c588: r16 = <AlignmentGeometry>
    //     0x84c588: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e680] TypeArguments: <AlignmentGeometry>
    //     0x84c58c: ldr             x16, [x16, #0x680]
    // 0x84c590: ldur            lr, [fp, #-0x10]
    // 0x84c594: stp             lr, x16, [SP, #-0x10]!
    // 0x84c598: SaveReg r0
    //     0x84c598: str             x0, [SP, #-8]!
    // 0x84c59c: ldur            x0, [fp, #-0x10]
    // 0x84c5a0: ClosureCall
    //     0x84c5a0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c5a4: ldur            x2, [x0, #0x1f]
    //     0x84c5a8: blr             x2
    // 0x84c5ac: add             SP, SP, #0x18
    // 0x84c5b0: mov             x1, x0
    // 0x84c5b4: ldur            x0, [fp, #-0x98]
    // 0x84c5b8: stur            x1, [fp, #-0xb8]
    // 0x84c5bc: cmp             w0, NULL
    // 0x84c5c0: b.eq            #0x84d028
    // 0x84c5c4: SaveReg r0
    //     0x84c5c4: str             x0, [SP, #-8]!
    // 0x84c5c8: r0 = baseSizeAdjustment()
    //     0x84c5c8: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x84c5cc: add             SP, SP, #8
    // 0x84c5d0: r1 = Function '<anonymous closure>':.
    //     0x84c5d0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e688] AnonymousClosure: (0x84d220), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84c5d4: ldr             x1, [x1, #0x688]
    // 0x84c5d8: r2 = Null
    //     0x84c5d8: mov             x2, NULL
    // 0x84c5dc: stur            x0, [fp, #-0xc0]
    // 0x84c5e0: r0 = AllocateClosure()
    //     0x84c5e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84c5e4: r16 = <InteractiveInkFeatureFactory>
    //     0x84c5e4: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e690] TypeArguments: <InteractiveInkFeatureFactory>
    //     0x84c5e8: ldr             x16, [x16, #0x690]
    // 0x84c5ec: ldur            lr, [fp, #-0x10]
    // 0x84c5f0: stp             lr, x16, [SP, #-0x10]!
    // 0x84c5f4: SaveReg r0
    //     0x84c5f4: str             x0, [SP, #-8]!
    // 0x84c5f8: ldur            x0, [fp, #-0x10]
    // 0x84c5fc: ClosureCall
    //     0x84c5fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84c600: ldur            x2, [x0, #0x1f]
    //     0x84c604: blr             x2
    // 0x84c608: add             SP, SP, #0x18
    // 0x84c60c: mov             x1, x0
    // 0x84c610: ldur            x0, [fp, #-0x58]
    // 0x84c614: stur            x1, [fp, #-0x10]
    // 0x84c618: cmp             w0, NULL
    // 0x84c61c: b.eq            #0x84d02c
    // 0x84c620: LoadField: d0 = r0->field_7
    //     0x84c620: ldur            d0, [x0, #7]
    // 0x84c624: stur            d0, [fp, #-0xe8]
    // 0x84c628: LoadField: d1 = r0->field_f
    //     0x84c628: ldur            d1, [x0, #0xf]
    // 0x84c62c: ldur            x0, [fp, #-0x68]
    // 0x84c630: stur            d1, [fp, #-0xe0]
    // 0x84c634: cmp             w0, NULL
    // 0x84c638: b.eq            #0x84d030
    // 0x84c63c: LoadField: d2 = r0->field_7
    //     0x84c63c: ldur            d2, [x0, #7]
    // 0x84c640: stur            d2, [fp, #-0xd8]
    // 0x84c644: LoadField: d3 = r0->field_f
    //     0x84c644: ldur            d3, [x0, #0xf]
    // 0x84c648: stur            d3, [fp, #-0xd0]
    // 0x84c64c: r0 = BoxConstraints()
    //     0x84c64c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x84c650: ldur            d0, [fp, #-0xe8]
    // 0x84c654: StoreField: r0->field_7 = d0
    //     0x84c654: stur            d0, [x0, #7]
    // 0x84c658: ldur            d0, [fp, #-0xd8]
    // 0x84c65c: StoreField: r0->field_f = d0
    //     0x84c65c: stur            d0, [x0, #0xf]
    // 0x84c660: ldur            d0, [fp, #-0xe0]
    // 0x84c664: StoreField: r0->field_17 = d0
    //     0x84c664: stur            d0, [x0, #0x17]
    // 0x84c668: ldur            d0, [fp, #-0xd0]
    // 0x84c66c: StoreField: r0->field_1f = d0
    //     0x84c66c: stur            d0, [x0, #0x1f]
    // 0x84c670: ldur            x16, [fp, #-0x98]
    // 0x84c674: stp             x0, x16, [SP, #-0x10]!
    // 0x84c678: r0 = effectiveConstraints()
    //     0x84c678: bl              #0x84bb78  ; [package:flutter/src/material/theme_data.dart] VisualDensity::effectiveConstraints
    // 0x84c67c: add             SP, SP, #0x10
    // 0x84c680: mov             x1, x0
    // 0x84c684: ldur            x0, [fp, #-0x60]
    // 0x84c688: stur            x1, [fp, #-0x58]
    // 0x84c68c: cmp             w0, NULL
    // 0x84c690: b.eq            #0x84c788
    // 0x84c694: stp             x0, x1, [SP, #-0x10]!
    // 0x84c698: r0 = constrain()
    //     0x84c698: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x84c69c: add             SP, SP, #0x10
    // 0x84c6a0: stur            x0, [fp, #-0x60]
    // 0x84c6a4: LoadField: d0 = r0->field_7
    //     0x84c6a4: ldur            d0, [x0, #7]
    // 0x84c6a8: mov             x1, v0.d[0]
    // 0x84c6ac: and             x1, x1, #0x7fffffffffffffff
    // 0x84c6b0: r17 = 9218868437227405312
    //     0x84c6b0: mov             x17, #0x7ff0000000000000
    // 0x84c6b4: cmp             x1, x17
    // 0x84c6b8: b.eq            #0x84c710
    // 0x84c6bc: fcmp            d0, d0
    // 0x84c6c0: b.vs            #0x84c710
    // 0x84c6c4: r1 = inline_Allocate_Double()
    //     0x84c6c4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84c6c8: add             x1, x1, #0x10
    //     0x84c6cc: cmp             x2, x1
    //     0x84c6d0: b.ls            #0x84d034
    //     0x84c6d4: str             x1, [THR, #0x60]  ; THR::top
    //     0x84c6d8: sub             x1, x1, #0xf
    //     0x84c6dc: mov             x2, #0xd108
    //     0x84c6e0: movk            x2, #3, lsl #16
    //     0x84c6e4: stur            x2, [x1, #-1]
    // 0x84c6e8: StoreField: r1->field_7 = d0
    //     0x84c6e8: stur            d0, [x1, #7]
    // 0x84c6ec: ldur            x16, [fp, #-0x58]
    // 0x84c6f0: stp             x1, x16, [SP, #-0x10]!
    // 0x84c6f4: SaveReg r1
    //     0x84c6f4: str             x1, [SP, #-8]!
    // 0x84c6f8: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x84c6f8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x84c6fc: ldr             x4, [x4, #0x588]
    // 0x84c700: r0 = copyWith()
    //     0x84c700: bl              #0x690914  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0x84c704: add             SP, SP, #0x18
    // 0x84c708: mov             x1, x0
    // 0x84c70c: b               #0x84c714
    // 0x84c710: ldur            x1, [fp, #-0x58]
    // 0x84c714: ldur            x0, [fp, #-0x60]
    // 0x84c718: LoadField: d0 = r0->field_f
    //     0x84c718: ldur            d0, [x0, #0xf]
    // 0x84c71c: mov             x0, v0.d[0]
    // 0x84c720: and             x0, x0, #0x7fffffffffffffff
    // 0x84c724: r17 = 9218868437227405312
    //     0x84c724: mov             x17, #0x7ff0000000000000
    // 0x84c728: cmp             x0, x17
    // 0x84c72c: b.eq            #0x84c77c
    // 0x84c730: fcmp            d0, d0
    // 0x84c734: b.vs            #0x84c77c
    // 0x84c738: r0 = inline_Allocate_Double()
    //     0x84c738: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x84c73c: add             x0, x0, #0x10
    //     0x84c740: cmp             x2, x0
    //     0x84c744: b.ls            #0x84d050
    //     0x84c748: str             x0, [THR, #0x60]  ; THR::top
    //     0x84c74c: sub             x0, x0, #0xf
    //     0x84c750: mov             x2, #0xd108
    //     0x84c754: movk            x2, #3, lsl #16
    //     0x84c758: stur            x2, [x0, #-1]
    // 0x84c75c: StoreField: r0->field_7 = d0
    //     0x84c75c: stur            d0, [x0, #7]
    // 0x84c760: stp             x0, x1, [SP, #-0x10]!
    // 0x84c764: SaveReg r0
    //     0x84c764: str             x0, [SP, #-8]!
    // 0x84c768: r4 = const [0, 0x3, 0x3, 0x1, maxHeight, 0x2, minHeight, 0x1, null]
    //     0x84c768: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e698] List(9) [0, 0x3, 0x3, 0x1, "maxHeight", 0x2, "minHeight", 0x1, Null]
    //     0x84c76c: ldr             x4, [x4, #0x698]
    // 0x84c770: r0 = copyWith()
    //     0x84c770: bl              #0x690914  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0x84c774: add             SP, SP, #0x18
    // 0x84c778: b               #0x84c780
    // 0x84c77c: mov             x0, x1
    // 0x84c780: mov             x1, x0
    // 0x84c784: b               #0x84c78c
    // 0x84c788: ldur            x1, [fp, #-0x58]
    // 0x84c78c: ldur            x0, [fp, #-0xc0]
    // 0x84c790: d0 = 0.000000
    //     0x84c790: eor             v0.16b, v0.16b, v0.16b
    // 0x84c794: stur            x1, [fp, #-0x58]
    // 0x84c798: LoadField: d1 = r0->field_f
    //     0x84c798: ldur            d1, [x0, #0xf]
    // 0x84c79c: stur            d1, [fp, #-0xe0]
    // 0x84c7a0: LoadField: d2 = r0->field_7
    //     0x84c7a0: ldur            d2, [x0, #7]
    // 0x84c7a4: stur            d2, [fp, #-0xd8]
    // 0x84c7a8: fcmp            d0, d2
    // 0x84c7ac: b.vs            #0x84c7bc
    // 0x84c7b0: b.le            #0x84c7bc
    // 0x84c7b4: d0 = 0.000000
    //     0x84c7b4: eor             v0.16b, v0.16b, v0.16b
    // 0x84c7b8: b               #0x84c7fc
    // 0x84c7bc: fcmp            d0, d2
    // 0x84c7c0: b.vs            #0x84c7d0
    // 0x84c7c4: b.ge            #0x84c7d0
    // 0x84c7c8: mov             v0.16b, v2.16b
    // 0x84c7cc: b               #0x84c7fc
    // 0x84c7d0: fcmp            d0, d0
    // 0x84c7d4: b.vs            #0x84c7e8
    // 0x84c7d8: b.ne            #0x84c7e8
    // 0x84c7dc: fadd            d3, d0, d2
    // 0x84c7e0: mov             v0.16b, v3.16b
    // 0x84c7e4: b               #0x84c7fc
    // 0x84c7e8: fcmp            d2, d2
    // 0x84c7ec: b.vc            #0x84c7f8
    // 0x84c7f0: mov             v0.16b, v2.16b
    // 0x84c7f4: b               #0x84c7fc
    // 0x84c7f8: d0 = 0.000000
    //     0x84c7f8: eor             v0.16b, v0.16b, v0.16b
    // 0x84c7fc: ldur            x2, [fp, #-0x50]
    // 0x84c800: ldur            x0, [fp, #-0xa8]
    // 0x84c804: stur            d0, [fp, #-0xd0]
    // 0x84c808: cmp             w2, NULL
    // 0x84c80c: b.eq            #0x84d068
    // 0x84c810: r0 = EdgeInsets()
    //     0x84c810: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x84c814: ldur            d0, [fp, #-0xd0]
    // 0x84c818: StoreField: r0->field_7 = d0
    //     0x84c818: stur            d0, [x0, #7]
    // 0x84c81c: ldur            d1, [fp, #-0xe0]
    // 0x84c820: StoreField: r0->field_f = d1
    //     0x84c820: stur            d1, [x0, #0xf]
    // 0x84c824: StoreField: r0->field_17 = d0
    //     0x84c824: stur            d0, [x0, #0x17]
    // 0x84c828: StoreField: r0->field_1f = d1
    //     0x84c828: stur            d1, [x0, #0x1f]
    // 0x84c82c: ldur            x1, [fp, #-0x50]
    // 0x84c830: r2 = LoadClassIdInstr(r1)
    //     0x84c830: ldur            x2, [x1, #-1]
    //     0x84c834: ubfx            x2, x2, #0xc, #0x14
    // 0x84c838: stp             x0, x1, [SP, #-0x10]!
    // 0x84c83c: mov             x0, x2
    // 0x84c840: r0 = GDT[cid_x0 + -0xfcc]()
    //     0x84c840: sub             lr, x0, #0xfcc
    //     0x84c844: ldr             lr, [x21, lr, lsl #3]
    //     0x84c848: blr             lr
    // 0x84c84c: add             SP, SP, #0x10
    // 0x84c850: r1 = LoadClassIdInstr(r0)
    //     0x84c850: ldur            x1, [x0, #-1]
    //     0x84c854: ubfx            x1, x1, #0xc, #0x14
    // 0x84c858: r16 = Instance__MixedEdgeInsets
    //     0x84c858: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6a0] Obj!_MixedEdgeInsets@b357d1
    //     0x84c85c: ldr             x16, [x16, #0x6a0]
    // 0x84c860: stp             x16, x0, [SP, #-0x10]!
    // 0x84c864: mov             x0, x1
    // 0x84c868: r0 = GDT[cid_x0 + -0xfc3]()
    //     0x84c868: sub             lr, x0, #0xfc3
    //     0x84c86c: ldr             lr, [x21, lr, lsl #3]
    //     0x84c870: blr             lr
    // 0x84c874: add             SP, SP, #0x10
    // 0x84c878: mov             x2, x0
    // 0x84c87c: ldur            x1, [fp, #-0xa8]
    // 0x84c880: stur            x2, [fp, #-0x50]
    // 0x84c884: cmp             w1, NULL
    // 0x84c888: b.eq            #0x84d06c
    // 0x84c88c: LoadField: r0 = r1->field_7
    //     0x84c88c: ldur            x0, [x1, #7]
    // 0x84c890: cmp             x0, #0
    // 0x84c894: b.le            #0x84cb50
    // 0x84c898: ldr             x3, [fp, #0x18]
    // 0x84c89c: LoadField: r0 = r3->field_1f
    //     0x84c89c: ldur            w0, [x3, #0x1f]
    // 0x84c8a0: DecompressPointer r0
    //     0x84c8a0: add             x0, x0, HEAP, lsl #32
    // 0x84c8a4: cmp             w0, NULL
    // 0x84c8a8: b.eq            #0x84cb50
    // 0x84c8ac: LoadField: r4 = r3->field_23
    //     0x84c8ac: ldur            w4, [x3, #0x23]
    // 0x84c8b0: DecompressPointer r4
    //     0x84c8b0: add             x4, x4, HEAP, lsl #32
    // 0x84c8b4: cmp             w4, NULL
    // 0x84c8b8: b.eq            #0x84cb50
    // 0x84c8bc: r4 = LoadClassIdInstr(r0)
    //     0x84c8bc: ldur            x4, [x0, #-1]
    //     0x84c8c0: ubfx            x4, x4, #0xc, #0x14
    // 0x84c8c4: ldur            x16, [fp, #-0x20]
    // 0x84c8c8: stp             x16, x0, [SP, #-0x10]!
    // 0x84c8cc: mov             x0, x4
    // 0x84c8d0: mov             lr, x0
    // 0x84c8d4: ldr             lr, [x21, lr, lsl #3]
    // 0x84c8d8: blr             lr
    // 0x84c8dc: add             SP, SP, #0x10
    // 0x84c8e0: tbz             w0, #4, #0x84cb50
    // 0x84c8e4: ldr             x1, [fp, #0x18]
    // 0x84c8e8: LoadField: r0 = r1->field_23
    //     0x84c8e8: ldur            w0, [x1, #0x23]
    // 0x84c8ec: DecompressPointer r0
    //     0x84c8ec: add             x0, x0, HEAP, lsl #32
    // 0x84c8f0: cmp             w0, NULL
    // 0x84c8f4: b.eq            #0x84d070
    // 0x84c8f8: r2 = LoadClassIdInstr(r0)
    //     0x84c8f8: ldur            x2, [x0, #-1]
    //     0x84c8fc: ubfx            x2, x2, #0xc, #0x14
    // 0x84c900: lsl             x2, x2, #1
    // 0x84c904: r17 = 10124
    //     0x84c904: mov             x17, #0x278c
    // 0x84c908: cmp             w2, w17
    // 0x84c90c: b.gt            #0x84c91c
    // 0x84c910: r17 = 10122
    //     0x84c910: mov             x17, #0x278a
    // 0x84c914: cmp             w2, w17
    // 0x84c918: b.ge            #0x84c934
    // 0x84c91c: r17 = 10114
    //     0x84c91c: mov             x17, #0x2782
    // 0x84c920: cmp             w2, w17
    // 0x84c924: b.eq            #0x84c934
    // 0x84c928: r17 = 10118
    //     0x84c928: mov             x17, #0x2786
    // 0x84c92c: cmp             w2, w17
    // 0x84c930: b.ne            #0x84c940
    // 0x84c934: LoadField: r2 = r0->field_7
    //     0x84c934: ldur            x2, [x0, #7]
    // 0x84c938: mov             x3, x2
    // 0x84c93c: b               #0x84c950
    // 0x84c940: LoadField: r2 = r0->field_f
    //     0x84c940: ldur            w2, [x0, #0xf]
    // 0x84c944: DecompressPointer r2
    //     0x84c944: add             x2, x2, HEAP, lsl #32
    // 0x84c948: LoadField: r0 = r2->field_7
    //     0x84c948: ldur            x0, [x2, #7]
    // 0x84c94c: mov             x3, x0
    // 0x84c950: ldur            x2, [fp, #-0x30]
    // 0x84c954: stur            x3, [fp, #-0xc8]
    // 0x84c958: cmp             w2, NULL
    // 0x84c95c: b.eq            #0x84d074
    // 0x84c960: r0 = LoadClassIdInstr(r2)
    //     0x84c960: ldur            x0, [x2, #-1]
    //     0x84c964: ubfx            x0, x0, #0xc, #0x14
    // 0x84c968: SaveReg r2
    //     0x84c968: str             x2, [SP, #-8]!
    // 0x84c96c: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x84c96c: sub             lr, x0, #0xf7e
    //     0x84c970: ldr             lr, [x21, lr, lsl #3]
    //     0x84c974: blr             lr
    // 0x84c978: add             SP, SP, #8
    // 0x84c97c: mov             x1, x0
    // 0x84c980: ldur            x0, [fp, #-0xc8]
    // 0x84c984: cmp             x0, x1
    // 0x84c988: b.eq            #0x84cb50
    // 0x84c98c: ldr             x0, [fp, #0x18]
    // 0x84c990: LoadField: r1 = r0->field_23
    //     0x84c990: ldur            w1, [x0, #0x23]
    // 0x84c994: DecompressPointer r1
    //     0x84c994: add             x1, x1, HEAP, lsl #32
    // 0x84c998: cmp             w1, NULL
    // 0x84c99c: b.eq            #0x84d078
    // 0x84c9a0: SaveReg r1
    //     0x84c9a0: str             x1, [SP, #-8]!
    // 0x84c9a4: r0 = opacity()
    //     0x84c9a4: bl              #0x84d0ac  ; [dart:ui] Color::opacity
    // 0x84c9a8: add             SP, SP, #8
    // 0x84c9ac: mov             v1.16b, v0.16b
    // 0x84c9b0: d0 = 1.000000
    //     0x84c9b0: fmov            d0, #1.00000000
    // 0x84c9b4: fcmp            d1, d0
    // 0x84c9b8: b.vs            #0x84cb50
    // 0x84c9bc: b.ne            #0x84cb50
    // 0x84c9c0: ldur            x16, [fp, #-0x30]
    // 0x84c9c4: SaveReg r16
    //     0x84c9c4: str             x16, [SP, #-8]!
    // 0x84c9c8: r0 = opacity()
    //     0x84c9c8: bl              #0x84d0ac  ; [dart:ui] Color::opacity
    // 0x84c9cc: add             SP, SP, #8
    // 0x84c9d0: mov             v1.16b, v0.16b
    // 0x84c9d4: d0 = 1.000000
    //     0x84c9d4: fmov            d0, #1.00000000
    // 0x84c9d8: fcmp            d1, d0
    // 0x84c9dc: b.vs            #0x84cb50
    // 0x84c9e0: b.ge            #0x84cb50
    // 0x84c9e4: ldur            x1, [fp, #-0x20]
    // 0x84c9e8: r0 = 59
    //     0x84c9e8: mov             x0, #0x3b
    // 0x84c9ec: branchIfSmi(r1, 0x84c9f8)
    //     0x84c9ec: tbz             w1, #0, #0x84c9f8
    // 0x84c9f0: r0 = LoadClassIdInstr(r1)
    //     0x84c9f0: ldur            x0, [x1, #-1]
    //     0x84c9f4: ubfx            x0, x0, #0xc, #0x14
    // 0x84c9f8: stp             xzr, x1, [SP, #-0x10]!
    // 0x84c9fc: mov             lr, x0
    // 0x84ca00: ldr             lr, [x21, lr, lsl #3]
    // 0x84ca04: blr             lr
    // 0x84ca08: add             SP, SP, #0x10
    // 0x84ca0c: tbnz            w0, #4, #0x84cb50
    // 0x84ca10: ldr             x1, [fp, #0x18]
    // 0x84ca14: LoadField: r0 = r1->field_1b
    //     0x84ca14: ldur            w0, [x1, #0x1b]
    // 0x84ca18: DecompressPointer r0
    //     0x84ca18: add             x0, x0, HEAP, lsl #32
    // 0x84ca1c: cmp             w0, NULL
    // 0x84ca20: b.ne            #0x84ca2c
    // 0x84ca24: r0 = Null
    //     0x84ca24: mov             x0, NULL
    // 0x84ca28: b               #0x84ca38
    // 0x84ca2c: LoadField: r2 = r0->field_27
    //     0x84ca2c: ldur            w2, [x0, #0x27]
    // 0x84ca30: DecompressPointer r2
    //     0x84ca30: add             x2, x2, HEAP, lsl #32
    // 0x84ca34: mov             x0, x2
    // 0x84ca38: r2 = LoadClassIdInstr(r0)
    //     0x84ca38: ldur            x2, [x0, #-1]
    //     0x84ca3c: ubfx            x2, x2, #0xc, #0x14
    // 0x84ca40: ldur            x16, [fp, #-0xa8]
    // 0x84ca44: stp             x16, x0, [SP, #-0x10]!
    // 0x84ca48: mov             x0, x2
    // 0x84ca4c: mov             lr, x0
    // 0x84ca50: ldr             lr, [x21, lr, lsl #3]
    // 0x84ca54: blr             lr
    // 0x84ca58: add             SP, SP, #0x10
    // 0x84ca5c: tbz             w0, #4, #0x84caf8
    // 0x84ca60: ldr             x0, [fp, #0x18]
    // 0x84ca64: LoadField: r1 = r0->field_1b
    //     0x84ca64: ldur            w1, [x0, #0x1b]
    // 0x84ca68: DecompressPointer r1
    //     0x84ca68: add             x1, x1, HEAP, lsl #32
    // 0x84ca6c: cmp             w1, NULL
    // 0x84ca70: b.eq            #0x84ca84
    // 0x84ca74: SaveReg r1
    //     0x84ca74: str             x1, [SP, #-8]!
    // 0x84ca78: r0 = dispose()
    //     0x84ca78: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0x84ca7c: add             SP, SP, #8
    // 0x84ca80: ldr             x0, [fp, #0x18]
    // 0x84ca84: r1 = <double>
    //     0x84ca84: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x84ca88: r0 = AnimationController()
    //     0x84ca88: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x84ca8c: stur            x0, [fp, #-0x60]
    // 0x84ca90: ldr             x16, [fp, #0x18]
    // 0x84ca94: stp             x16, x0, [SP, #-0x10]!
    // 0x84ca98: ldur            x16, [fp, #-0xa8]
    // 0x84ca9c: SaveReg r16
    //     0x84ca9c: str             x16, [SP, #-8]!
    // 0x84caa0: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x84caa0: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x84caa4: ldr             x4, [x4, #0xa0]
    // 0x84caa8: r0 = AnimationController()
    //     0x84caa8: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x84caac: add             SP, SP, #0x18
    // 0x84cab0: ldur            x2, [fp, #-8]
    // 0x84cab4: r1 = Function '<anonymous closure>':.
    //     0x84cab4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6a8] AnonymousClosure: (0x84d1a4), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84cab8: ldr             x1, [x1, #0x6a8]
    // 0x84cabc: r0 = AllocateClosure()
    //     0x84cabc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84cac0: ldur            x16, [fp, #-0x60]
    // 0x84cac4: stp             x0, x16, [SP, #-0x10]!
    // 0x84cac8: r0 = addStatusListener()
    //     0x84cac8: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x84cacc: add             SP, SP, #0x10
    // 0x84cad0: ldur            x0, [fp, #-0x60]
    // 0x84cad4: ldr             x1, [fp, #0x18]
    // 0x84cad8: StoreField: r1->field_1b = r0
    //     0x84cad8: stur            w0, [x1, #0x1b]
    //     0x84cadc: ldurb           w16, [x1, #-1]
    //     0x84cae0: ldurb           w17, [x0, #-1]
    //     0x84cae4: and             x16, x17, x16, lsr #2
    //     0x84cae8: tst             x16, HEAP, lsr #32
    //     0x84caec: b.eq            #0x84caf4
    //     0x84caf0: bl              #0xd6826c
    // 0x84caf4: b               #0x84cafc
    // 0x84caf8: ldr             x1, [fp, #0x18]
    // 0x84cafc: LoadField: r0 = r1->field_23
    //     0x84cafc: ldur            w0, [x1, #0x23]
    // 0x84cb00: DecompressPointer r0
    //     0x84cb00: add             x0, x0, HEAP, lsl #32
    // 0x84cb04: stur            x0, [fp, #-8]
    // 0x84cb08: LoadField: r2 = r1->field_1b
    //     0x84cb08: ldur            w2, [x1, #0x1b]
    // 0x84cb0c: DecompressPointer r2
    //     0x84cb0c: add             x2, x2, HEAP, lsl #32
    // 0x84cb10: cmp             w2, NULL
    // 0x84cb14: b.eq            #0x84d07c
    // 0x84cb18: stp             xzr, x2, [SP, #-0x10]!
    // 0x84cb1c: r0 = value=()
    //     0x84cb1c: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x84cb20: add             SP, SP, #0x10
    // 0x84cb24: ldr             x0, [fp, #0x18]
    // 0x84cb28: LoadField: r1 = r0->field_1b
    //     0x84cb28: ldur            w1, [x0, #0x1b]
    // 0x84cb2c: DecompressPointer r1
    //     0x84cb2c: add             x1, x1, HEAP, lsl #32
    // 0x84cb30: cmp             w1, NULL
    // 0x84cb34: b.eq            #0x84d080
    // 0x84cb38: SaveReg r1
    //     0x84cb38: str             x1, [SP, #-8]!
    // 0x84cb3c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84cb3c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84cb40: r0 = forward()
    //     0x84cb40: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84cb44: add             SP, SP, #8
    // 0x84cb48: ldur            x4, [fp, #-8]
    // 0x84cb4c: b               #0x84cb54
    // 0x84cb50: ldur            x4, [fp, #-0x30]
    // 0x84cb54: ldr             x1, [fp, #0x18]
    // 0x84cb58: ldur            x2, [fp, #-0x20]
    // 0x84cb5c: ldur            x3, [fp, #-0x28]
    // 0x84cb60: mov             x0, x2
    // 0x84cb64: stur            x4, [fp, #-8]
    // 0x84cb68: StoreField: r1->field_1f = r0
    //     0x84cb68: stur            w0, [x1, #0x1f]
    //     0x84cb6c: tbz             w0, #0, #0x84cb88
    //     0x84cb70: ldurb           w16, [x1, #-1]
    //     0x84cb74: ldurb           w17, [x0, #-1]
    //     0x84cb78: and             x16, x17, x16, lsr #2
    //     0x84cb7c: tst             x16, HEAP, lsr #32
    //     0x84cb80: b.eq            #0x84cb88
    //     0x84cb84: bl              #0xd6826c
    // 0x84cb88: mov             x0, x4
    // 0x84cb8c: StoreField: r1->field_23 = r0
    //     0x84cb8c: stur            w0, [x1, #0x23]
    //     0x84cb90: tbz             w0, #0, #0x84cbac
    //     0x84cb94: ldurb           w16, [x1, #-1]
    //     0x84cb98: ldurb           w17, [x0, #-1]
    //     0x84cb9c: and             x16, x17, x16, lsr #2
    //     0x84cba0: tst             x16, HEAP, lsr #32
    //     0x84cba4: b.eq            #0x84cbac
    //     0x84cba8: bl              #0xd6826c
    // 0x84cbac: cmp             w2, NULL
    // 0x84cbb0: b.eq            #0x84d084
    // 0x84cbb4: cmp             w3, NULL
    // 0x84cbb8: b.ne            #0x84cbc8
    // 0x84cbbc: mov             x1, x4
    // 0x84cbc0: r3 = Null
    //     0x84cbc0: mov             x3, NULL
    // 0x84cbc4: b               #0x84cbe8
    // 0x84cbc8: ldur            x16, [fp, #-0x38]
    // 0x84cbcc: stp             x16, x3, [SP, #-0x10]!
    // 0x84cbd0: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x84cbd0: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x84cbd4: ldr             x4, [x4, #0x168]
    // 0x84cbd8: r0 = copyWith()
    //     0x84cbd8: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x84cbdc: add             SP, SP, #0x10
    // 0x84cbe0: mov             x3, x0
    // 0x84cbe4: ldur            x1, [fp, #-8]
    // 0x84cbe8: ldur            x2, [fp, #-0x18]
    // 0x84cbec: stur            x3, [fp, #-0x28]
    // 0x84cbf0: cmp             w2, NULL
    // 0x84cbf4: b.eq            #0x84d088
    // 0x84cbf8: r0 = LoadClassIdInstr(r2)
    //     0x84cbf8: ldur            x0, [x2, #-1]
    //     0x84cbfc: ubfx            x0, x0, #0xc, #0x14
    // 0x84cc00: ldur            x16, [fp, #-0x80]
    // 0x84cc04: stp             x16, x2, [SP, #-0x10]!
    // 0x84cc08: r0 = GDT[cid_x0 + -0xfaa]()
    //     0x84cc08: sub             lr, x0, #0xfaa
    //     0x84cc0c: ldr             lr, [x21, lr, lsl #3]
    //     0x84cc10: blr             lr
    // 0x84cc14: add             SP, SP, #0x10
    // 0x84cc18: mov             x2, x0
    // 0x84cc1c: ldur            x1, [fp, #-8]
    // 0x84cc20: stur            x2, [fp, #-0x98]
    // 0x84cc24: cmp             w1, NULL
    // 0x84cc28: b.ne            #0x84cc38
    // 0x84cc2c: r4 = Instance_MaterialType
    //     0x84cc2c: add             x4, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x84cc30: ldr             x4, [x4, #0x2a8]
    // 0x84cc34: b               #0x84cc40
    // 0x84cc38: r4 = Instance_MaterialType
    //     0x84cc38: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e6b0] Obj!MaterialType@b65551
    //     0x84cc3c: ldr             x4, [x4, #0x6b0]
    // 0x84cc40: ldr             x3, [fp, #0x18]
    // 0x84cc44: stur            x4, [fp, #-0x68]
    // 0x84cc48: LoadField: r0 = r3->field_b
    //     0x84cc48: ldur            w0, [x3, #0xb]
    // 0x84cc4c: DecompressPointer r0
    //     0x84cc4c: add             x0, x0, HEAP, lsl #32
    // 0x84cc50: cmp             w0, NULL
    // 0x84cc54: b.eq            #0x84d08c
    // 0x84cc58: LoadField: r5 = r0->field_b
    //     0x84cc58: ldur            w5, [x0, #0xb]
    // 0x84cc5c: DecompressPointer r5
    //     0x84cc5c: add             x5, x5, HEAP, lsl #32
    // 0x84cc60: stur            x5, [fp, #-0x60]
    // 0x84cc64: cmp             w5, NULL
    // 0x84cc68: b.eq            #0x84cc74
    // 0x84cc6c: r7 = true
    //     0x84cc6c: add             x7, NULL, #0x20  ; true
    // 0x84cc70: b               #0x84cc78
    // 0x84cc74: r7 = false
    //     0x84cc74: add             x7, NULL, #0x30  ; false
    // 0x84cc78: ldur            x6, [fp, #-0x70]
    // 0x84cc7c: ldur            x0, [fp, #-0x18]
    // 0x84cc80: stur            x7, [fp, #-0x30]
    // 0x84cc84: r8 = LoadClassIdInstr(r0)
    //     0x84cc84: ldur            x8, [x0, #-1]
    //     0x84cc88: ubfx            x8, x8, #0xc, #0x14
    // 0x84cc8c: ldur            x16, [fp, #-0x80]
    // 0x84cc90: stp             x16, x0, [SP, #-0x10]!
    // 0x84cc94: mov             x0, x8
    // 0x84cc98: r0 = GDT[cid_x0 + -0xfaa]()
    //     0x84cc98: sub             lr, x0, #0xfaa
    //     0x84cc9c: ldr             lr, [x21, lr, lsl #3]
    //     0x84cca0: blr             lr
    // 0x84cca4: add             SP, SP, #0x10
    // 0x84cca8: stur            x0, [fp, #-0x18]
    // 0x84ccac: ldr             x16, [fp, #0x18]
    // 0x84ccb0: SaveReg r16
    //     0x84ccb0: str             x16, [SP, #-8]!
    // 0x84ccb4: r0 = statesController()
    //     0x84ccb4: bl              #0x7b0824  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::statesController
    // 0x84ccb8: add             SP, SP, #8
    // 0x84ccbc: mov             x1, x0
    // 0x84ccc0: ldur            x0, [fp, #-0x70]
    // 0x84ccc4: stur            x1, [fp, #-0x80]
    // 0x84ccc8: cmp             w0, NULL
    // 0x84cccc: b.ne            #0x84ccd8
    // 0x84ccd0: ldur            x6, [fp, #-0x38]
    // 0x84ccd4: b               #0x84ccdc
    // 0x84ccd8: mov             x6, x0
    // 0x84ccdc: ldr             x0, [fp, #0x18]
    // 0x84cce0: ldur            x5, [fp, #-0x78]
    // 0x84cce4: ldur            x4, [fp, #-0xb0]
    // 0x84cce8: ldur            x3, [fp, #-0xb8]
    // 0x84ccec: ldur            x2, [fp, #-0x50]
    // 0x84ccf0: stur            x6, [fp, #-0x38]
    // 0x84ccf4: r0 = IconThemeData()
    //     0x84ccf4: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0x84ccf8: mov             x1, x0
    // 0x84ccfc: ldur            x0, [fp, #-0x78]
    // 0x84cd00: stur            x1, [fp, #-0x70]
    // 0x84cd04: StoreField: r1->field_7 = r0
    //     0x84cd04: stur            w0, [x1, #7]
    // 0x84cd08: ldur            x0, [fp, #-0x38]
    // 0x84cd0c: StoreField: r1->field_1b = r0
    //     0x84cd0c: stur            w0, [x1, #0x1b]
    // 0x84cd10: ldur            x0, [fp, #-0xb8]
    // 0x84cd14: cmp             w0, NULL
    // 0x84cd18: b.eq            #0x84d090
    // 0x84cd1c: ldr             x2, [fp, #0x18]
    // 0x84cd20: LoadField: r3 = r2->field_b
    //     0x84cd20: ldur            w3, [x2, #0xb]
    // 0x84cd24: DecompressPointer r3
    //     0x84cd24: add             x3, x3, HEAP, lsl #32
    // 0x84cd28: cmp             w3, NULL
    // 0x84cd2c: b.eq            #0x84d094
    // 0x84cd30: LoadField: r4 = r3->field_2f
    //     0x84cd30: ldur            w4, [x3, #0x2f]
    // 0x84cd34: DecompressPointer r4
    //     0x84cd34: add             x4, x4, HEAP, lsl #32
    // 0x84cd38: stur            x4, [fp, #-0x38]
    // 0x84cd3c: r0 = Align()
    //     0x84cd3c: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x84cd40: mov             x1, x0
    // 0x84cd44: ldur            x0, [fp, #-0xb8]
    // 0x84cd48: stur            x1, [fp, #-0x78]
    // 0x84cd4c: StoreField: r1->field_f = r0
    //     0x84cd4c: stur            w0, [x1, #0xf]
    // 0x84cd50: r0 = 1.000000
    //     0x84cd50: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x84cd54: StoreField: r1->field_13 = r0
    //     0x84cd54: stur            w0, [x1, #0x13]
    // 0x84cd58: StoreField: r1->field_17 = r0
    //     0x84cd58: stur            w0, [x1, #0x17]
    // 0x84cd5c: ldur            x0, [fp, #-0x38]
    // 0x84cd60: StoreField: r1->field_b = r0
    //     0x84cd60: stur            w0, [x1, #0xb]
    // 0x84cd64: r0 = Padding()
    //     0x84cd64: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x84cd68: mov             x1, x0
    // 0x84cd6c: ldur            x0, [fp, #-0x50]
    // 0x84cd70: StoreField: r1->field_f = r0
    //     0x84cd70: stur            w0, [x1, #0xf]
    // 0x84cd74: ldur            x0, [fp, #-0x78]
    // 0x84cd78: StoreField: r1->field_b = r0
    //     0x84cd78: stur            w0, [x1, #0xb]
    // 0x84cd7c: ldur            x16, [fp, #-0x70]
    // 0x84cd80: stp             x16, x1, [SP, #-0x10]!
    // 0x84cd84: r0 = merge()
    //     0x84cd84: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0x84cd88: add             SP, SP, #0x10
    // 0x84cd8c: mov             x1, x0
    // 0x84cd90: ldur            x0, [fp, #-0xb0]
    // 0x84cd94: stur            x1, [fp, #-0x50]
    // 0x84cd98: cmp             w0, NULL
    // 0x84cd9c: b.ne            #0x84cda8
    // 0x84cda0: r24 = true
    //     0x84cda0: add             x24, NULL, #0x20  ; true
    // 0x84cda4: b               #0x84cdac
    // 0x84cda8: mov             x24, x0
    // 0x84cdac: ldur            x9, [fp, #-0x20]
    // 0x84cdb0: ldur            x23, [fp, #-0x40]
    // 0x84cdb4: ldur            x20, [fp, #-0x48]
    // 0x84cdb8: ldur            x19, [fp, #-0x88]
    // 0x84cdbc: ldur            x14, [fp, #-0x90]
    // 0x84cdc0: ldur            x13, [fp, #-0xa0]
    // 0x84cdc4: ldur            x10, [fp, #-0xa8]
    // 0x84cdc8: ldur            x12, [fp, #-0x10]
    // 0x84cdcc: ldur            x11, [fp, #-0x58]
    // 0x84cdd0: ldur            x3, [fp, #-8]
    // 0x84cdd4: ldur            x8, [fp, #-0x28]
    // 0x84cdd8: ldur            x4, [fp, #-0x98]
    // 0x84cddc: ldur            x5, [fp, #-0x68]
    // 0x84cde0: ldur            x6, [fp, #-0x60]
    // 0x84cde4: ldur            x2, [fp, #-0x18]
    // 0x84cde8: ldur            x0, [fp, #-0x80]
    // 0x84cdec: ldur            x7, [fp, #-0x30]
    // 0x84cdf0: stur            x24, [fp, #-0x38]
    // 0x84cdf4: r0 = InkWell()
    //     0x84cdf4: bl              #0x832ed8  ; AllocateInkWellStub -> InkWell (size=0x7c)
    // 0x84cdf8: mov             x1, x0
    // 0x84cdfc: ldur            x0, [fp, #-0x50]
    // 0x84ce00: stur            x1, [fp, #-0x70]
    // 0x84ce04: StoreField: r1->field_b = r0
    //     0x84ce04: stur            w0, [x1, #0xb]
    // 0x84ce08: ldur            x0, [fp, #-0x60]
    // 0x84ce0c: StoreField: r1->field_f = r0
    //     0x84ce0c: stur            w0, [x1, #0xf]
    // 0x84ce10: ldur            x0, [fp, #-0x88]
    // 0x84ce14: StoreField: r1->field_2f = r0
    //     0x84ce14: stur            w0, [x1, #0x2f]
    // 0x84ce18: r0 = true
    //     0x84ce18: add             x0, NULL, #0x20  ; true
    // 0x84ce1c: StoreField: r1->field_33 = r0
    //     0x84ce1c: stur            w0, [x1, #0x33]
    // 0x84ce20: r2 = Instance_BoxShape
    //     0x84ce20: add             x2, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x84ce24: ldr             x2, [x2, #0xe68]
    // 0x84ce28: StoreField: r1->field_37 = r2
    //     0x84ce28: stur            w2, [x1, #0x37]
    // 0x84ce2c: ldur            x2, [fp, #-0x18]
    // 0x84ce30: StoreField: r1->field_43 = r2
    //     0x84ce30: stur            w2, [x1, #0x43]
    // 0x84ce34: r2 = Instance_Color
    //     0x84ce34: add             x2, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x84ce38: ldr             x2, [x2, #0xc08]
    // 0x84ce3c: StoreField: r1->field_4f = r2
    //     0x84ce3c: stur            w2, [x1, #0x4f]
    // 0x84ce40: ldur            x2, [fp, #-0x90]
    // 0x84ce44: StoreField: r1->field_53 = r2
    //     0x84ce44: stur            w2, [x1, #0x53]
    // 0x84ce48: ldur            x2, [fp, #-0x10]
    // 0x84ce4c: StoreField: r1->field_5b = r2
    //     0x84ce4c: stur            w2, [x1, #0x5b]
    // 0x84ce50: ldur            x2, [fp, #-0x38]
    // 0x84ce54: StoreField: r1->field_5f = r2
    //     0x84ce54: stur            w2, [x1, #0x5f]
    // 0x84ce58: r2 = false
    //     0x84ce58: add             x2, NULL, #0x30  ; false
    // 0x84ce5c: StoreField: r1->field_63 = r2
    //     0x84ce5c: stur            w2, [x1, #0x63]
    // 0x84ce60: ldur            x3, [fp, #-0x30]
    // 0x84ce64: StoreField: r1->field_73 = r3
    //     0x84ce64: stur            w3, [x1, #0x73]
    // 0x84ce68: StoreField: r1->field_6b = r2
    //     0x84ce68: stur            w2, [x1, #0x6b]
    // 0x84ce6c: ldur            x2, [fp, #-0x80]
    // 0x84ce70: StoreField: r1->field_77 = r2
    //     0x84ce70: stur            w2, [x1, #0x77]
    // 0x84ce74: r0 = Material()
    //     0x84ce74: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x84ce78: mov             x1, x0
    // 0x84ce7c: ldur            x0, [fp, #-0x68]
    // 0x84ce80: stur            x1, [fp, #-0x10]
    // 0x84ce84: StoreField: r1->field_f = r0
    //     0x84ce84: stur            w0, [x1, #0xf]
    // 0x84ce88: ldur            x0, [fp, #-0x20]
    // 0x84ce8c: LoadField: d0 = r0->field_7
    //     0x84ce8c: ldur            d0, [x0, #7]
    // 0x84ce90: StoreField: r1->field_13 = d0
    //     0x84ce90: stur            d0, [x1, #0x13]
    // 0x84ce94: ldur            x0, [fp, #-8]
    // 0x84ce98: StoreField: r1->field_1b = r0
    //     0x84ce98: stur            w0, [x1, #0x1b]
    // 0x84ce9c: ldur            x0, [fp, #-0x40]
    // 0x84cea0: StoreField: r1->field_1f = r0
    //     0x84cea0: stur            w0, [x1, #0x1f]
    // 0x84cea4: ldur            x0, [fp, #-0x48]
    // 0x84cea8: StoreField: r1->field_23 = r0
    //     0x84cea8: stur            w0, [x1, #0x23]
    // 0x84ceac: ldur            x0, [fp, #-0x28]
    // 0x84ceb0: StoreField: r1->field_27 = r0
    //     0x84ceb0: stur            w0, [x1, #0x27]
    // 0x84ceb4: ldur            x0, [fp, #-0x98]
    // 0x84ceb8: StoreField: r1->field_2b = r0
    //     0x84ceb8: stur            w0, [x1, #0x2b]
    // 0x84cebc: r0 = true
    //     0x84cebc: add             x0, NULL, #0x20  ; true
    // 0x84cec0: StoreField: r1->field_2f = r0
    //     0x84cec0: stur            w0, [x1, #0x2f]
    // 0x84cec4: r0 = Instance_Clip
    //     0x84cec4: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x84cec8: ldr             x0, [x0, #0xb38]
    // 0x84cecc: StoreField: r1->field_33 = r0
    //     0x84cecc: stur            w0, [x1, #0x33]
    // 0x84ced0: ldur            x0, [fp, #-0xa8]
    // 0x84ced4: StoreField: r1->field_37 = r0
    //     0x84ced4: stur            w0, [x1, #0x37]
    // 0x84ced8: ldur            x0, [fp, #-0x70]
    // 0x84cedc: StoreField: r1->field_b = r0
    //     0x84cedc: stur            w0, [x1, #0xb]
    // 0x84cee0: r0 = ConstrainedBox()
    //     0x84cee0: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x84cee4: mov             x1, x0
    // 0x84cee8: ldur            x0, [fp, #-0x58]
    // 0x84ceec: stur            x1, [fp, #-8]
    // 0x84cef0: StoreField: r1->field_f = r0
    //     0x84cef0: stur            w0, [x1, #0xf]
    // 0x84cef4: ldur            x0, [fp, #-0x10]
    // 0x84cef8: StoreField: r1->field_b = r0
    //     0x84cef8: stur            w0, [x1, #0xb]
    // 0x84cefc: ldur            x0, [fp, #-0xa0]
    // 0x84cf00: cmp             w0, NULL
    // 0x84cf04: b.eq            #0x84d098
    // 0x84cf08: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x84cf08: mov             x2, #0x76
    //     0x84cf0c: tbz             w0, #0, #0x84cf1c
    //     0x84cf10: ldur            x2, [x0, #-1]
    //     0x84cf14: ubfx            x2, x2, #0xc, #0x14
    //     0x84cf18: lsl             x2, x2, #1
    // 0x84cf1c: r17 = 11886
    //     0x84cf1c: mov             x17, #0x2e6e
    // 0x84cf20: cmp             w2, w17
    // 0x84cf24: b.ne            #0x84cf78
    // 0x84cf28: LoadField: r2 = r0->field_7
    //     0x84cf28: ldur            x2, [x0, #7]
    // 0x84cf2c: cmp             x2, #0
    // 0x84cf30: b.gt            #0x84cf70
    // 0x84cf34: ldur            d0, [fp, #-0xe0]
    // 0x84cf38: ldur            d1, [fp, #-0xd8]
    // 0x84cf3c: d2 = 48.000000
    //     0x84cf3c: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0x84cf40: ldr             d2, [x17, #0xbd0]
    // 0x84cf44: fadd            d3, d2, d1
    // 0x84cf48: stur            d3, [fp, #-0xe8]
    // 0x84cf4c: fadd            d1, d2, d0
    // 0x84cf50: stur            d1, [fp, #-0xd0]
    // 0x84cf54: r0 = Size()
    //     0x84cf54: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x84cf58: ldur            d0, [fp, #-0xe8]
    // 0x84cf5c: StoreField: r0->field_7 = d0
    //     0x84cf5c: stur            d0, [x0, #7]
    // 0x84cf60: ldur            d0, [fp, #-0xd0]
    // 0x84cf64: StoreField: r0->field_f = d0
    //     0x84cf64: stur            d0, [x0, #0xf]
    // 0x84cf68: mov             x1, x0
    // 0x84cf6c: b               #0x84cf7c
    // 0x84cf70: r1 = Instance_Size
    //     0x84cf70: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x84cf74: b               #0x84cf7c
    // 0x84cf78: r1 = Null
    //     0x84cf78: mov             x1, NULL
    // 0x84cf7c: ldr             x0, [fp, #0x18]
    // 0x84cf80: stur            x1, [fp, #-0x18]
    // 0x84cf84: LoadField: r2 = r0->field_b
    //     0x84cf84: ldur            w2, [x0, #0xb]
    // 0x84cf88: DecompressPointer r2
    //     0x84cf88: add             x2, x2, HEAP, lsl #32
    // 0x84cf8c: cmp             w2, NULL
    // 0x84cf90: b.eq            #0x84d09c
    // 0x84cf94: LoadField: r0 = r2->field_b
    //     0x84cf94: ldur            w0, [x2, #0xb]
    // 0x84cf98: DecompressPointer r0
    //     0x84cf98: add             x0, x0, HEAP, lsl #32
    // 0x84cf9c: cmp             w0, NULL
    // 0x84cfa0: b.eq            #0x84cfac
    // 0x84cfa4: r2 = true
    //     0x84cfa4: add             x2, NULL, #0x20  ; true
    // 0x84cfa8: b               #0x84cfb0
    // 0x84cfac: r2 = false
    //     0x84cfac: add             x2, NULL, #0x30  ; false
    // 0x84cfb0: ldur            x0, [fp, #-8]
    // 0x84cfb4: stur            x2, [fp, #-0x10]
    // 0x84cfb8: r0 = _InputPadding()
    //     0x84cfb8: bl              #0x84d0a0  ; Allocate_InputPaddingStub -> _InputPadding (size=0x14)
    // 0x84cfbc: mov             x1, x0
    // 0x84cfc0: ldur            x0, [fp, #-0x18]
    // 0x84cfc4: stur            x1, [fp, #-0x20]
    // 0x84cfc8: StoreField: r1->field_f = r0
    //     0x84cfc8: stur            w0, [x1, #0xf]
    // 0x84cfcc: ldur            x0, [fp, #-8]
    // 0x84cfd0: StoreField: r1->field_b = r0
    //     0x84cfd0: stur            w0, [x1, #0xb]
    // 0x84cfd4: r0 = Semantics()
    //     0x84cfd4: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x84cfd8: stur            x0, [fp, #-8]
    // 0x84cfdc: r16 = true
    //     0x84cfdc: add             x16, NULL, #0x20  ; true
    // 0x84cfe0: stp             x16, x0, [SP, #-0x10]!
    // 0x84cfe4: r16 = true
    //     0x84cfe4: add             x16, NULL, #0x20  ; true
    // 0x84cfe8: ldur            lr, [fp, #-0x10]
    // 0x84cfec: stp             lr, x16, [SP, #-0x10]!
    // 0x84cff0: ldur            x16, [fp, #-0x20]
    // 0x84cff4: SaveReg r16
    //     0x84cff4: str             x16, [SP, #-8]!
    // 0x84cff8: r4 = const [0, 0x5, 0x5, 0x1, button, 0x2, child, 0x4, container, 0x1, enabled, 0x3, null]
    //     0x84cff8: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e6b8] List(13) [0, 0x5, 0x5, 0x1, "button", 0x2, "child", 0x4, "container", 0x1, "enabled", 0x3, Null]
    //     0x84cffc: ldr             x4, [x4, #0x6b8]
    // 0x84d000: r0 = Semantics()
    //     0x84d000: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x84d004: add             SP, SP, #0x28
    // 0x84d008: ldur            x0, [fp, #-8]
    // 0x84d00c: LeaveFrame
    //     0x84d00c: mov             SP, fp
    //     0x84d010: ldp             fp, lr, [SP], #0x10
    // 0x84d014: ret
    //     0x84d014: ret             
    // 0x84d018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d01c: b               #0x84bfc4
    // 0x84d020: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d020: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d024: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d024: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d02c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d02c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d030: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84d030: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84d034: SaveReg d0
    //     0x84d034: str             q0, [SP, #-0x10]!
    // 0x84d038: SaveReg r0
    //     0x84d038: str             x0, [SP, #-8]!
    // 0x84d03c: r0 = AllocateDouble()
    //     0x84d03c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84d040: mov             x1, x0
    // 0x84d044: RestoreReg r0
    //     0x84d044: ldr             x0, [SP], #8
    // 0x84d048: RestoreReg d0
    //     0x84d048: ldr             q0, [SP], #0x10
    // 0x84d04c: b               #0x84c6e8
    // 0x84d050: SaveReg d0
    //     0x84d050: str             q0, [SP, #-0x10]!
    // 0x84d054: SaveReg r1
    //     0x84d054: str             x1, [SP, #-8]!
    // 0x84d058: r0 = AllocateDouble()
    //     0x84d058: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84d05c: RestoreReg r1
    //     0x84d05c: ldr             x1, [SP], #8
    // 0x84d060: RestoreReg d0
    //     0x84d060: ldr             q0, [SP], #0x10
    // 0x84d064: b               #0x84c75c
    // 0x84d068: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84d068: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84d06c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d06c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d074: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d078: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d07c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d07c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d080: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d080: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d084: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d084: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d088: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d08c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d08c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d090: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d090: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d094: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d094: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d098: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d098: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84d09c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84d09c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, AnimationStatus) {
    // ** addr: 0x84d1a4, size: 0x7c
    // 0x84d1a4: EnterFrame
    //     0x84d1a4: stp             fp, lr, [SP, #-0x10]!
    //     0x84d1a8: mov             fp, SP
    // 0x84d1ac: AllocStack(0x8)
    //     0x84d1ac: sub             SP, SP, #8
    // 0x84d1b0: SetupParameters()
    //     0x84d1b0: ldr             x0, [fp, #0x18]
    //     0x84d1b4: ldur            w1, [x0, #0x17]
    //     0x84d1b8: add             x1, x1, HEAP, lsl #32
    // 0x84d1bc: CheckStackOverflow
    //     0x84d1bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d1c0: cmp             SP, x16
    //     0x84d1c4: b.ls            #0x84d218
    // 0x84d1c8: ldr             x0, [fp, #0x10]
    // 0x84d1cc: r16 = Instance_AnimationStatus
    //     0x84d1cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x84d1d0: ldr             x16, [x16, #0xba0]
    // 0x84d1d4: cmp             w0, w16
    // 0x84d1d8: b.ne            #0x84d208
    // 0x84d1dc: LoadField: r0 = r1->field_f
    //     0x84d1dc: ldur            w0, [x1, #0xf]
    // 0x84d1e0: DecompressPointer r0
    //     0x84d1e0: add             x0, x0, HEAP, lsl #32
    // 0x84d1e4: stur            x0, [fp, #-8]
    // 0x84d1e8: r1 = Function '<anonymous closure>':.
    //     0x84d1e8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6c0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x84d1ec: ldr             x1, [x1, #0x6c0]
    // 0x84d1f0: r2 = Null
    //     0x84d1f0: mov             x2, NULL
    // 0x84d1f4: r0 = AllocateClosure()
    //     0x84d1f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84d1f8: ldur            x16, [fp, #-8]
    // 0x84d1fc: stp             x0, x16, [SP, #-0x10]!
    // 0x84d200: r0 = setState()
    //     0x84d200: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84d204: add             SP, SP, #0x10
    // 0x84d208: r0 = Null
    //     0x84d208: mov             x0, NULL
    // 0x84d20c: LeaveFrame
    //     0x84d20c: mov             SP, fp
    //     0x84d210: ldp             fp, lr, [SP], #0x10
    // 0x84d214: ret
    //     0x84d214: ret             
    // 0x84d218: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d218: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d21c: b               #0x84d1c8
  }
  [closure] InteractiveInkFeatureFactory? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d220, size: 0x5c
    // 0x84d220: EnterFrame
    //     0x84d220: stp             fp, lr, [SP, #-0x10]!
    //     0x84d224: mov             fp, SP
    // 0x84d228: CheckStackOverflow
    //     0x84d228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d22c: cmp             SP, x16
    //     0x84d230: b.ls            #0x84d274
    // 0x84d234: ldr             x0, [fp, #0x10]
    // 0x84d238: cmp             w0, NULL
    // 0x84d23c: b.ne            #0x84d248
    // 0x84d240: r0 = Null
    //     0x84d240: mov             x0, NULL
    // 0x84d244: b               #0x84d268
    // 0x84d248: r1 = LoadClassIdInstr(r0)
    //     0x84d248: ldur            x1, [x0, #-1]
    //     0x84d24c: ubfx            x1, x1, #0xc, #0x14
    // 0x84d250: SaveReg r0
    //     0x84d250: str             x0, [SP, #-8]!
    // 0x84d254: mov             x0, x1
    // 0x84d258: r0 = GDT[cid_x0 + -0xe82]()
    //     0x84d258: sub             lr, x0, #0xe82
    //     0x84d25c: ldr             lr, [x21, lr, lsl #3]
    //     0x84d260: blr             lr
    // 0x84d264: add             SP, SP, #8
    // 0x84d268: LeaveFrame
    //     0x84d268: mov             SP, fp
    //     0x84d26c: ldp             fp, lr, [SP], #0x10
    // 0x84d270: ret
    //     0x84d270: ret             
    // 0x84d274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d278: b               #0x84d234
  }
  [closure] AlignmentGeometry? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d27c, size: 0x24
    // 0x84d27c: ldr             x1, [SP]
    // 0x84d280: cmp             w1, NULL
    // 0x84d284: b.ne            #0x84d290
    // 0x84d288: r0 = Null
    //     0x84d288: mov             x0, NULL
    // 0x84d28c: b               #0x84d29c
    // 0x84d290: LoadField: r2 = r1->field_57
    //     0x84d290: ldur            w2, [x1, #0x57]
    // 0x84d294: DecompressPointer r2
    //     0x84d294: add             x2, x2, HEAP, lsl #32
    // 0x84d298: mov             x0, x2
    // 0x84d29c: ret
    //     0x84d29c: ret             
  }
  [closure] bool? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d2d0, size: 0x24
    // 0x84d2d0: ldr             x1, [SP]
    // 0x84d2d4: cmp             w1, NULL
    // 0x84d2d8: b.ne            #0x84d2e4
    // 0x84d2dc: r0 = Null
    //     0x84d2dc: mov             x0, NULL
    // 0x84d2e0: b               #0x84d2f0
    // 0x84d2e4: LoadField: r2 = r1->field_53
    //     0x84d2e4: ldur            w2, [x1, #0x53]
    // 0x84d2e8: DecompressPointer r2
    //     0x84d2e8: add             x2, x2, HEAP, lsl #32
    // 0x84d2ec: mov             x0, x2
    // 0x84d2f0: ret
    //     0x84d2f0: ret             
  }
  [closure] Duration? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d2f4, size: 0x24
    // 0x84d2f4: ldr             x1, [SP]
    // 0x84d2f8: cmp             w1, NULL
    // 0x84d2fc: b.ne            #0x84d308
    // 0x84d300: r0 = Null
    //     0x84d300: mov             x0, NULL
    // 0x84d304: b               #0x84d314
    // 0x84d308: LoadField: r2 = r1->field_4f
    //     0x84d308: ldur            w2, [x1, #0x4f]
    // 0x84d30c: DecompressPointer r2
    //     0x84d30c: add             x2, x2, HEAP, lsl #32
    // 0x84d310: mov             x0, x2
    // 0x84d314: ret
    //     0x84d314: ret             
  }
  [closure] MaterialTapTargetSize? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d318, size: 0x5c
    // 0x84d318: EnterFrame
    //     0x84d318: stp             fp, lr, [SP, #-0x10]!
    //     0x84d31c: mov             fp, SP
    // 0x84d320: CheckStackOverflow
    //     0x84d320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d324: cmp             SP, x16
    //     0x84d328: b.ls            #0x84d36c
    // 0x84d32c: ldr             x0, [fp, #0x10]
    // 0x84d330: cmp             w0, NULL
    // 0x84d334: b.ne            #0x84d340
    // 0x84d338: r0 = Null
    //     0x84d338: mov             x0, NULL
    // 0x84d33c: b               #0x84d360
    // 0x84d340: r1 = LoadClassIdInstr(r0)
    //     0x84d340: ldur            x1, [x0, #-1]
    //     0x84d344: ubfx            x1, x1, #0xc, #0x14
    // 0x84d348: SaveReg r0
    //     0x84d348: str             x0, [SP, #-8]!
    // 0x84d34c: mov             x0, x1
    // 0x84d350: r0 = GDT[cid_x0 + -0xeb0]()
    //     0x84d350: sub             lr, x0, #0xeb0
    //     0x84d354: ldr             lr, [x21, lr, lsl #3]
    //     0x84d358: blr             lr
    // 0x84d35c: add             SP, SP, #8
    // 0x84d360: LeaveFrame
    //     0x84d360: mov             SP, fp
    //     0x84d364: ldp             fp, lr, [SP], #0x10
    // 0x84d368: ret
    //     0x84d368: ret             
    // 0x84d36c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d36c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d370: b               #0x84d32c
  }
  [closure] VisualDensity? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d374, size: 0x5c
    // 0x84d374: EnterFrame
    //     0x84d374: stp             fp, lr, [SP, #-0x10]!
    //     0x84d378: mov             fp, SP
    // 0x84d37c: CheckStackOverflow
    //     0x84d37c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d380: cmp             SP, x16
    //     0x84d384: b.ls            #0x84d3c8
    // 0x84d388: ldr             x0, [fp, #0x10]
    // 0x84d38c: cmp             w0, NULL
    // 0x84d390: b.ne            #0x84d39c
    // 0x84d394: r0 = Null
    //     0x84d394: mov             x0, NULL
    // 0x84d398: b               #0x84d3bc
    // 0x84d39c: r1 = LoadClassIdInstr(r0)
    //     0x84d39c: ldur            x1, [x0, #-1]
    //     0x84d3a0: ubfx            x1, x1, #0xc, #0x14
    // 0x84d3a4: SaveReg r0
    //     0x84d3a4: str             x0, [SP, #-8]!
    // 0x84d3a8: mov             x0, x1
    // 0x84d3ac: r0 = GDT[cid_x0 + -0xeb5]()
    //     0x84d3ac: sub             lr, x0, #0xeb5
    //     0x84d3b0: ldr             lr, [x21, lr, lsl #3]
    //     0x84d3b4: blr             lr
    // 0x84d3b8: add             SP, SP, #8
    // 0x84d3bc: LeaveFrame
    //     0x84d3bc: mov             SP, fp
    //     0x84d3c0: ldp             fp, lr, [SP], #0x10
    // 0x84d3c4: ret
    //     0x84d3c4: ret             
    // 0x84d3c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d3c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d3cc: b               #0x84d388
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x84d3d0, size: 0x9c
    // 0x84d3d0: EnterFrame
    //     0x84d3d0: stp             fp, lr, [SP, #-0x10]!
    //     0x84d3d4: mov             fp, SP
    // 0x84d3d8: AllocStack(0x10)
    //     0x84d3d8: sub             SP, SP, #0x10
    // 0x84d3dc: SetupParameters()
    //     0x84d3dc: ldr             x0, [fp, #0x18]
    //     0x84d3e0: ldur            w1, [x0, #0x17]
    //     0x84d3e4: add             x1, x1, HEAP, lsl #32
    //     0x84d3e8: stur            x1, [fp, #-8]
    // 0x84d3ec: CheckStackOverflow
    //     0x84d3ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d3f0: cmp             SP, x16
    //     0x84d3f4: b.ls            #0x84d464
    // 0x84d3f8: r1 = 1
    //     0x84d3f8: mov             x1, #1
    // 0x84d3fc: r0 = AllocateContext()
    //     0x84d3fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84d400: mov             x1, x0
    // 0x84d404: ldur            x0, [fp, #-8]
    // 0x84d408: StoreField: r1->field_b = r0
    //     0x84d408: stur            w0, [x1, #0xb]
    // 0x84d40c: ldr             x2, [fp, #0x10]
    // 0x84d410: StoreField: r1->field_f = r2
    //     0x84d410: stur            w2, [x1, #0xf]
    // 0x84d414: LoadField: r3 = r0->field_1f
    //     0x84d414: ldur            w3, [x0, #0x1f]
    // 0x84d418: DecompressPointer r3
    //     0x84d418: add             x3, x3, HEAP, lsl #32
    // 0x84d41c: mov             x2, x1
    // 0x84d420: stur            x3, [fp, #-0x10]
    // 0x84d424: r1 = Function '<anonymous closure>':.
    //     0x84d424: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6c8] AnonymousClosure: (0x84d46c), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84d428: ldr             x1, [x1, #0x6c8]
    // 0x84d42c: r0 = AllocateClosure()
    //     0x84d42c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84d430: r16 = <Color>
    //     0x84d430: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84d434: ldr             x16, [x16, #0x3f8]
    // 0x84d438: ldur            lr, [fp, #-0x10]
    // 0x84d43c: stp             lr, x16, [SP, #-0x10]!
    // 0x84d440: SaveReg r0
    //     0x84d440: str             x0, [SP, #-8]!
    // 0x84d444: ldur            x0, [fp, #-0x10]
    // 0x84d448: ClosureCall
    //     0x84d448: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84d44c: ldur            x2, [x0, #0x1f]
    //     0x84d450: blr             x2
    // 0x84d454: add             SP, SP, #0x18
    // 0x84d458: LeaveFrame
    //     0x84d458: mov             SP, fp
    //     0x84d45c: ldp             fp, lr, [SP], #0x10
    // 0x84d460: ret
    //     0x84d460: ret             
    // 0x84d464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d468: b               #0x84d3f8
  }
  [closure] Color? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d46c, size: 0xbc
    // 0x84d46c: EnterFrame
    //     0x84d46c: stp             fp, lr, [SP, #-0x10]!
    //     0x84d470: mov             fp, SP
    // 0x84d474: AllocStack(0x8)
    //     0x84d474: sub             SP, SP, #8
    // 0x84d478: SetupParameters()
    //     0x84d478: ldr             x0, [fp, #0x18]
    //     0x84d47c: ldur            w1, [x0, #0x17]
    //     0x84d480: add             x1, x1, HEAP, lsl #32
    //     0x84d484: stur            x1, [fp, #-8]
    // 0x84d488: CheckStackOverflow
    //     0x84d488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d48c: cmp             SP, x16
    //     0x84d490: b.ls            #0x84d520
    // 0x84d494: ldr             x0, [fp, #0x10]
    // 0x84d498: cmp             w0, NULL
    // 0x84d49c: b.ne            #0x84d4a8
    // 0x84d4a0: r0 = Null
    //     0x84d4a0: mov             x0, NULL
    // 0x84d4a4: b               #0x84d514
    // 0x84d4a8: r2 = LoadClassIdInstr(r0)
    //     0x84d4a8: ldur            x2, [x0, #-1]
    //     0x84d4ac: ubfx            x2, x2, #0xc, #0x14
    // 0x84d4b0: SaveReg r0
    //     0x84d4b0: str             x0, [SP, #-8]!
    // 0x84d4b4: mov             x0, x2
    // 0x84d4b8: r0 = GDT[cid_x0 + -0xf1b]()
    //     0x84d4b8: sub             lr, x0, #0xf1b
    //     0x84d4bc: ldr             lr, [x21, lr, lsl #3]
    //     0x84d4c0: blr             lr
    // 0x84d4c4: add             SP, SP, #8
    // 0x84d4c8: cmp             w0, NULL
    // 0x84d4cc: b.ne            #0x84d4d8
    // 0x84d4d0: r1 = Null
    //     0x84d4d0: mov             x1, NULL
    // 0x84d4d4: b               #0x84d510
    // 0x84d4d8: ldur            x1, [fp, #-8]
    // 0x84d4dc: LoadField: r2 = r1->field_f
    //     0x84d4dc: ldur            w2, [x1, #0xf]
    // 0x84d4e0: DecompressPointer r2
    //     0x84d4e0: add             x2, x2, HEAP, lsl #32
    // 0x84d4e4: r1 = LoadClassIdInstr(r0)
    //     0x84d4e4: ldur            x1, [x0, #-1]
    //     0x84d4e8: ubfx            x1, x1, #0xc, #0x14
    // 0x84d4ec: stp             x2, x0, [SP, #-0x10]!
    // 0x84d4f0: mov             x0, x1
    // 0x84d4f4: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x84d4f4: mov             x17, #0x5e7
    //     0x84d4f8: movk            x17, #1, lsl #16
    //     0x84d4fc: add             lr, x0, x17
    //     0x84d500: ldr             lr, [x21, lr, lsl #3]
    //     0x84d504: blr             lr
    // 0x84d508: add             SP, SP, #0x10
    // 0x84d50c: mov             x1, x0
    // 0x84d510: mov             x0, x1
    // 0x84d514: LeaveFrame
    //     0x84d514: mov             SP, fp
    //     0x84d518: ldp             fp, lr, [SP], #0x10
    // 0x84d51c: ret
    //     0x84d51c: ret             
    // 0x84d520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d524: b               #0x84d494
  }
  [closure] MouseCursor? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x84d528, size: 0x98
    // 0x84d528: EnterFrame
    //     0x84d528: stp             fp, lr, [SP, #-0x10]!
    //     0x84d52c: mov             fp, SP
    // 0x84d530: AllocStack(0x10)
    //     0x84d530: sub             SP, SP, #0x10
    // 0x84d534: SetupParameters()
    //     0x84d534: ldr             x0, [fp, #0x18]
    //     0x84d538: ldur            w1, [x0, #0x17]
    //     0x84d53c: add             x1, x1, HEAP, lsl #32
    //     0x84d540: stur            x1, [fp, #-8]
    // 0x84d544: CheckStackOverflow
    //     0x84d544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d548: cmp             SP, x16
    //     0x84d54c: b.ls            #0x84d5b8
    // 0x84d550: r1 = 1
    //     0x84d550: mov             x1, #1
    // 0x84d554: r0 = AllocateContext()
    //     0x84d554: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84d558: mov             x1, x0
    // 0x84d55c: ldur            x0, [fp, #-8]
    // 0x84d560: StoreField: r1->field_b = r0
    //     0x84d560: stur            w0, [x1, #0xb]
    // 0x84d564: ldr             x2, [fp, #0x10]
    // 0x84d568: StoreField: r1->field_f = r2
    //     0x84d568: stur            w2, [x1, #0xf]
    // 0x84d56c: LoadField: r3 = r0->field_1f
    //     0x84d56c: ldur            w3, [x0, #0x1f]
    // 0x84d570: DecompressPointer r3
    //     0x84d570: add             x3, x3, HEAP, lsl #32
    // 0x84d574: mov             x2, x1
    // 0x84d578: stur            x3, [fp, #-0x10]
    // 0x84d57c: r1 = Function '<anonymous closure>':.
    //     0x84d57c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6d0] AnonymousClosure: (0x84d5c0), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84d580: ldr             x1, [x1, #0x6d0]
    // 0x84d584: r0 = AllocateClosure()
    //     0x84d584: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84d588: r16 = <MouseCursor>
    //     0x84d588: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x84d58c: ldur            lr, [fp, #-0x10]
    // 0x84d590: stp             lr, x16, [SP, #-0x10]!
    // 0x84d594: SaveReg r0
    //     0x84d594: str             x0, [SP, #-8]!
    // 0x84d598: ldur            x0, [fp, #-0x10]
    // 0x84d59c: ClosureCall
    //     0x84d59c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84d5a0: ldur            x2, [x0, #0x1f]
    //     0x84d5a4: blr             x2
    // 0x84d5a8: add             SP, SP, #0x18
    // 0x84d5ac: LeaveFrame
    //     0x84d5ac: mov             SP, fp
    //     0x84d5b0: ldp             fp, lr, [SP], #0x10
    // 0x84d5b4: ret
    //     0x84d5b4: ret             
    // 0x84d5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d5b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d5bc: b               #0x84d550
  }
  [closure] MouseCursor? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d5c0, size: 0xbc
    // 0x84d5c0: EnterFrame
    //     0x84d5c0: stp             fp, lr, [SP, #-0x10]!
    //     0x84d5c4: mov             fp, SP
    // 0x84d5c8: AllocStack(0x8)
    //     0x84d5c8: sub             SP, SP, #8
    // 0x84d5cc: SetupParameters()
    //     0x84d5cc: ldr             x0, [fp, #0x18]
    //     0x84d5d0: ldur            w1, [x0, #0x17]
    //     0x84d5d4: add             x1, x1, HEAP, lsl #32
    //     0x84d5d8: stur            x1, [fp, #-8]
    // 0x84d5dc: CheckStackOverflow
    //     0x84d5dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d5e0: cmp             SP, x16
    //     0x84d5e4: b.ls            #0x84d674
    // 0x84d5e8: ldr             x0, [fp, #0x10]
    // 0x84d5ec: cmp             w0, NULL
    // 0x84d5f0: b.ne            #0x84d5fc
    // 0x84d5f4: r0 = Null
    //     0x84d5f4: mov             x0, NULL
    // 0x84d5f8: b               #0x84d668
    // 0x84d5fc: r2 = LoadClassIdInstr(r0)
    //     0x84d5fc: ldur            x2, [x0, #-1]
    //     0x84d600: ubfx            x2, x2, #0xc, #0x14
    // 0x84d604: SaveReg r0
    //     0x84d604: str             x0, [SP, #-8]!
    // 0x84d608: mov             x0, x2
    // 0x84d60c: r0 = GDT[cid_x0 + -0xebb]()
    //     0x84d60c: sub             lr, x0, #0xebb
    //     0x84d610: ldr             lr, [x21, lr, lsl #3]
    //     0x84d614: blr             lr
    // 0x84d618: add             SP, SP, #8
    // 0x84d61c: cmp             w0, NULL
    // 0x84d620: b.ne            #0x84d62c
    // 0x84d624: r1 = Null
    //     0x84d624: mov             x1, NULL
    // 0x84d628: b               #0x84d664
    // 0x84d62c: ldur            x1, [fp, #-8]
    // 0x84d630: LoadField: r2 = r1->field_f
    //     0x84d630: ldur            w2, [x1, #0xf]
    // 0x84d634: DecompressPointer r2
    //     0x84d634: add             x2, x2, HEAP, lsl #32
    // 0x84d638: r1 = LoadClassIdInstr(r0)
    //     0x84d638: ldur            x1, [x0, #-1]
    //     0x84d63c: ubfx            x1, x1, #0xc, #0x14
    // 0x84d640: stp             x2, x0, [SP, #-0x10]!
    // 0x84d644: mov             x0, x1
    // 0x84d648: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x84d648: mov             x17, #0x5e7
    //     0x84d64c: movk            x17, #1, lsl #16
    //     0x84d650: add             lr, x0, x17
    //     0x84d654: ldr             lr, [x21, lr, lsl #3]
    //     0x84d658: blr             lr
    // 0x84d65c: add             SP, SP, #0x10
    // 0x84d660: mov             x1, x0
    // 0x84d664: mov             x0, x1
    // 0x84d668: LeaveFrame
    //     0x84d668: mov             SP, fp
    //     0x84d66c: ldp             fp, lr, [SP], #0x10
    // 0x84d670: ret
    //     0x84d670: ret             
    // 0x84d674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d678: b               #0x84d5e8
  }
  [closure] MaterialStateProperty<OutlinedBorder?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d67c, size: 0x5c
    // 0x84d67c: EnterFrame
    //     0x84d67c: stp             fp, lr, [SP, #-0x10]!
    //     0x84d680: mov             fp, SP
    // 0x84d684: CheckStackOverflow
    //     0x84d684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d688: cmp             SP, x16
    //     0x84d68c: b.ls            #0x84d6d0
    // 0x84d690: ldr             x0, [fp, #0x10]
    // 0x84d694: cmp             w0, NULL
    // 0x84d698: b.ne            #0x84d6a4
    // 0x84d69c: r0 = Null
    //     0x84d69c: mov             x0, NULL
    // 0x84d6a0: b               #0x84d6c4
    // 0x84d6a4: r1 = LoadClassIdInstr(r0)
    //     0x84d6a4: ldur            x1, [x0, #-1]
    //     0x84d6a8: ubfx            x1, x1, #0xc, #0x14
    // 0x84d6ac: SaveReg r0
    //     0x84d6ac: str             x0, [SP, #-8]!
    // 0x84d6b0: mov             x0, x1
    // 0x84d6b4: r0 = GDT[cid_x0 + -0xec3]()
    //     0x84d6b4: sub             lr, x0, #0xec3
    //     0x84d6b8: ldr             lr, [x21, lr, lsl #3]
    //     0x84d6bc: blr             lr
    // 0x84d6c0: add             SP, SP, #8
    // 0x84d6c4: LeaveFrame
    //     0x84d6c4: mov             SP, fp
    //     0x84d6c8: ldp             fp, lr, [SP], #0x10
    // 0x84d6cc: ret
    //     0x84d6cc: ret             
    // 0x84d6d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d6d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d6d4: b               #0x84d690
  }
  [closure] MaterialStateProperty<BorderSide?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d6d8, size: 0xc8
    // 0x84d6d8: EnterFrame
    //     0x84d6d8: stp             fp, lr, [SP, #-0x10]!
    //     0x84d6dc: mov             fp, SP
    // 0x84d6e0: CheckStackOverflow
    //     0x84d6e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d6e4: cmp             SP, x16
    //     0x84d6e8: b.ls            #0x84d798
    // 0x84d6ec: ldr             x0, [fp, #0x10]
    // 0x84d6f0: cmp             w0, NULL
    // 0x84d6f4: b.ne            #0x84d700
    // 0x84d6f8: r0 = Null
    //     0x84d6f8: mov             x0, NULL
    // 0x84d6fc: b               #0x84d78c
    // 0x84d700: r1 = LoadClassIdInstr(r0)
    //     0x84d700: ldur            x1, [x0, #-1]
    //     0x84d704: ubfx            x1, x1, #0xc, #0x14
    // 0x84d708: lsl             x1, x1, #1
    // 0x84d70c: r17 = 5660
    //     0x84d70c: mov             x17, #0x161c
    // 0x84d710: cmp             w1, w17
    // 0x84d714: b.gt            #0x84d724
    // 0x84d718: r17 = 5658
    //     0x84d718: mov             x17, #0x161a
    // 0x84d71c: cmp             w1, w17
    // 0x84d720: b.ge            #0x84d73c
    // 0x84d724: r17 = 5666
    //     0x84d724: mov             x17, #0x1622
    // 0x84d728: cmp             w1, w17
    // 0x84d72c: b.gt            #0x84d748
    // 0x84d730: r17 = 5664
    //     0x84d730: mov             x17, #0x1620
    // 0x84d734: cmp             w1, w17
    // 0x84d738: b.lt            #0x84d748
    // 0x84d73c: LoadField: r1 = r0->field_3b
    //     0x84d73c: ldur            w1, [x0, #0x3b]
    // 0x84d740: DecompressPointer r1
    //     0x84d740: add             x1, x1, HEAP, lsl #32
    // 0x84d744: b               #0x84d788
    // 0x84d748: r1 = 1
    //     0x84d748: mov             x1, #1
    // 0x84d74c: r0 = AllocateContext()
    //     0x84d74c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84d750: mov             x1, x0
    // 0x84d754: ldr             x0, [fp, #0x10]
    // 0x84d758: StoreField: r1->field_f = r0
    //     0x84d758: stur            w0, [x1, #0xf]
    // 0x84d75c: mov             x2, x1
    // 0x84d760: r1 = Function '<anonymous closure>':.
    //     0x84d760: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6d8] AnonymousClosure: (0x84d7a0), of [package:flutter/src/material/outlined_button.dart] _OutlinedButtonDefaultsM3
    //     0x84d764: ldr             x1, [x1, #0x6d8]
    // 0x84d768: r0 = AllocateClosure()
    //     0x84d768: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84d76c: r16 = <BorderSide>
    //     0x84d76c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6e0] TypeArguments: <BorderSide>
    //     0x84d770: ldr             x16, [x16, #0x6e0]
    // 0x84d774: stp             x0, x16, [SP, #-0x10]!
    // 0x84d778: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84d778: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84d77c: r0 = resolveWith()
    //     0x84d77c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84d780: add             SP, SP, #0x10
    // 0x84d784: mov             x1, x0
    // 0x84d788: mov             x0, x1
    // 0x84d78c: LeaveFrame
    //     0x84d78c: mov             SP, fp
    //     0x84d790: ldp             fp, lr, [SP], #0x10
    // 0x84d794: ret
    //     0x84d794: ret             
    // 0x84d798: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d798: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d79c: b               #0x84d6ec
  }
  [closure] MaterialStateProperty<double?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d974, size: 0x64
    // 0x84d974: ldr             x1, [SP]
    // 0x84d978: cmp             w1, NULL
    // 0x84d97c: b.ne            #0x84d988
    // 0x84d980: r0 = Null
    //     0x84d980: mov             x0, NULL
    // 0x84d984: b               #0x84d9d4
    // 0x84d988: r2 = LoadClassIdInstr(r1)
    //     0x84d988: ldur            x2, [x1, #-1]
    //     0x84d98c: ubfx            x2, x2, #0xc, #0x14
    // 0x84d990: lsl             x2, x2, #1
    // 0x84d994: r17 = 5662
    //     0x84d994: mov             x17, #0x161e
    // 0x84d998: cmp             w2, w17
    // 0x84d99c: b.gt            #0x84d9ac
    // 0x84d9a0: r17 = 5658
    //     0x84d9a0: mov             x17, #0x161a
    // 0x84d9a4: cmp             w2, w17
    // 0x84d9a8: b.ge            #0x84d9c4
    // 0x84d9ac: r17 = 5664
    //     0x84d9ac: mov             x17, #0x1620
    // 0x84d9b0: cmp             w2, w17
    // 0x84d9b4: b.ne            #0x84d9c4
    // 0x84d9b8: r1 = Instance_MaterialStatePropertyAll
    //     0x84d9b8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6f0] Obj!MaterialStatePropertyAll<double>@b37c81
    //     0x84d9bc: ldr             x1, [x1, #0x6f0]
    // 0x84d9c0: b               #0x84d9d0
    // 0x84d9c4: LoadField: r2 = r1->field_37
    //     0x84d9c4: ldur            w2, [x1, #0x37]
    // 0x84d9c8: DecompressPointer r2
    //     0x84d9c8: add             x2, x2, HEAP, lsl #32
    // 0x84d9cc: mov             x1, x2
    // 0x84d9d0: mov             x0, x1
    // 0x84d9d4: ret
    //     0x84d9d4: ret             
  }
  [closure] MaterialStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d9d8, size: 0x24
    // 0x84d9d8: ldr             x1, [SP]
    // 0x84d9dc: cmp             w1, NULL
    // 0x84d9e0: b.ne            #0x84d9ec
    // 0x84d9e4: r0 = Null
    //     0x84d9e4: mov             x0, NULL
    // 0x84d9e8: b               #0x84d9f8
    // 0x84d9ec: LoadField: r2 = r1->field_33
    //     0x84d9ec: ldur            w2, [x1, #0x33]
    // 0x84d9f0: DecompressPointer r2
    //     0x84d9f0: add             x2, x2, HEAP, lsl #32
    // 0x84d9f4: mov             x0, x2
    // 0x84d9f8: ret
    //     0x84d9f8: ret             
  }
  [closure] MaterialStateProperty<Size?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84d9fc, size: 0x5c
    // 0x84d9fc: EnterFrame
    //     0x84d9fc: stp             fp, lr, [SP, #-0x10]!
    //     0x84da00: mov             fp, SP
    // 0x84da04: CheckStackOverflow
    //     0x84da04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84da08: cmp             SP, x16
    //     0x84da0c: b.ls            #0x84da50
    // 0x84da10: ldr             x0, [fp, #0x10]
    // 0x84da14: cmp             w0, NULL
    // 0x84da18: b.ne            #0x84da24
    // 0x84da1c: r0 = Null
    //     0x84da1c: mov             x0, NULL
    // 0x84da20: b               #0x84da44
    // 0x84da24: r1 = LoadClassIdInstr(r0)
    //     0x84da24: ldur            x1, [x0, #-1]
    //     0x84da28: ubfx            x1, x1, #0xc, #0x14
    // 0x84da2c: SaveReg r0
    //     0x84da2c: str             x0, [SP, #-8]!
    // 0x84da30: mov             x0, x1
    // 0x84da34: r0 = GDT[cid_x0 + -0xed4]()
    //     0x84da34: sub             lr, x0, #0xed4
    //     0x84da38: ldr             lr, [x21, lr, lsl #3]
    //     0x84da3c: blr             lr
    // 0x84da40: add             SP, SP, #8
    // 0x84da44: LeaveFrame
    //     0x84da44: mov             SP, fp
    //     0x84da48: ldp             fp, lr, [SP], #0x10
    // 0x84da4c: ret
    //     0x84da4c: ret             
    // 0x84da50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84da50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84da54: b               #0x84da10
  }
  [closure] MaterialStateProperty<Size?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84da58, size: 0x24
    // 0x84da58: ldr             x1, [SP]
    // 0x84da5c: cmp             w1, NULL
    // 0x84da60: b.ne            #0x84da6c
    // 0x84da64: r0 = Null
    //     0x84da64: mov             x0, NULL
    // 0x84da68: b               #0x84da78
    // 0x84da6c: LoadField: r2 = r1->field_2b
    //     0x84da6c: ldur            w2, [x1, #0x2b]
    // 0x84da70: DecompressPointer r2
    //     0x84da70: add             x2, x2, HEAP, lsl #32
    // 0x84da74: mov             x0, x2
    // 0x84da78: ret
    //     0x84da78: ret             
  }
  [closure] MaterialStateProperty<Size?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84da7c, size: 0x5c
    // 0x84da7c: EnterFrame
    //     0x84da7c: stp             fp, lr, [SP, #-0x10]!
    //     0x84da80: mov             fp, SP
    // 0x84da84: CheckStackOverflow
    //     0x84da84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84da88: cmp             SP, x16
    //     0x84da8c: b.ls            #0x84dad0
    // 0x84da90: ldr             x0, [fp, #0x10]
    // 0x84da94: cmp             w0, NULL
    // 0x84da98: b.ne            #0x84daa4
    // 0x84da9c: r0 = Null
    //     0x84da9c: mov             x0, NULL
    // 0x84daa0: b               #0x84dac4
    // 0x84daa4: r1 = LoadClassIdInstr(r0)
    //     0x84daa4: ldur            x1, [x0, #-1]
    //     0x84daa8: ubfx            x1, x1, #0xc, #0x14
    // 0x84daac: SaveReg r0
    //     0x84daac: str             x0, [SP, #-8]!
    // 0x84dab0: mov             x0, x1
    // 0x84dab4: r0 = GDT[cid_x0 + -0xedb]()
    //     0x84dab4: sub             lr, x0, #0xedb
    //     0x84dab8: ldr             lr, [x21, lr, lsl #3]
    //     0x84dabc: blr             lr
    // 0x84dac0: add             SP, SP, #8
    // 0x84dac4: LeaveFrame
    //     0x84dac4: mov             SP, fp
    //     0x84dac8: ldp             fp, lr, [SP], #0x10
    // 0x84dacc: ret
    //     0x84dacc: ret             
    // 0x84dad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dad4: b               #0x84da90
  }
  [closure] MaterialStateProperty<EdgeInsetsGeometry?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84dad8, size: 0x5c
    // 0x84dad8: EnterFrame
    //     0x84dad8: stp             fp, lr, [SP, #-0x10]!
    //     0x84dadc: mov             fp, SP
    // 0x84dae0: CheckStackOverflow
    //     0x84dae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84dae4: cmp             SP, x16
    //     0x84dae8: b.ls            #0x84db2c
    // 0x84daec: ldr             x0, [fp, #0x10]
    // 0x84daf0: cmp             w0, NULL
    // 0x84daf4: b.ne            #0x84db00
    // 0x84daf8: r0 = Null
    //     0x84daf8: mov             x0, NULL
    // 0x84dafc: b               #0x84db20
    // 0x84db00: r1 = LoadClassIdInstr(r0)
    //     0x84db00: ldur            x1, [x0, #-1]
    //     0x84db04: ubfx            x1, x1, #0xc, #0x14
    // 0x84db08: SaveReg r0
    //     0x84db08: str             x0, [SP, #-8]!
    // 0x84db0c: mov             x0, x1
    // 0x84db10: r0 = GDT[cid_x0 + -0xee0]()
    //     0x84db10: sub             lr, x0, #0xee0
    //     0x84db14: ldr             lr, [x21, lr, lsl #3]
    //     0x84db18: blr             lr
    // 0x84db1c: add             SP, SP, #8
    // 0x84db20: LeaveFrame
    //     0x84db20: mov             SP, fp
    //     0x84db24: ldp             fp, lr, [SP], #0x10
    // 0x84db28: ret
    //     0x84db28: ret             
    // 0x84db2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84db2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84db30: b               #0x84daec
  }
  [closure] MaterialStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84db34, size: 0x5c
    // 0x84db34: EnterFrame
    //     0x84db34: stp             fp, lr, [SP, #-0x10]!
    //     0x84db38: mov             fp, SP
    // 0x84db3c: CheckStackOverflow
    //     0x84db3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84db40: cmp             SP, x16
    //     0x84db44: b.ls            #0x84db88
    // 0x84db48: ldr             x0, [fp, #0x10]
    // 0x84db4c: cmp             w0, NULL
    // 0x84db50: b.ne            #0x84db5c
    // 0x84db54: r0 = Null
    //     0x84db54: mov             x0, NULL
    // 0x84db58: b               #0x84db7c
    // 0x84db5c: r1 = LoadClassIdInstr(r0)
    //     0x84db5c: ldur            x1, [x0, #-1]
    //     0x84db60: ubfx            x1, x1, #0xc, #0x14
    // 0x84db64: SaveReg r0
    //     0x84db64: str             x0, [SP, #-8]!
    // 0x84db68: mov             x0, x1
    // 0x84db6c: r0 = GDT[cid_x0 + -0xef6]()
    //     0x84db6c: sub             lr, x0, #0xef6
    //     0x84db70: ldr             lr, [x21, lr, lsl #3]
    //     0x84db74: blr             lr
    // 0x84db78: add             SP, SP, #8
    // 0x84db7c: LeaveFrame
    //     0x84db7c: mov             SP, fp
    //     0x84db80: ldp             fp, lr, [SP], #0x10
    // 0x84db84: ret
    //     0x84db84: ret             
    // 0x84db88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84db88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84db8c: b               #0x84db48
  }
  [closure] MaterialStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84db90, size: 0x5c
    // 0x84db90: EnterFrame
    //     0x84db90: stp             fp, lr, [SP, #-0x10]!
    //     0x84db94: mov             fp, SP
    // 0x84db98: CheckStackOverflow
    //     0x84db98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84db9c: cmp             SP, x16
    //     0x84dba0: b.ls            #0x84dbe4
    // 0x84dba4: ldr             x0, [fp, #0x10]
    // 0x84dba8: cmp             w0, NULL
    // 0x84dbac: b.ne            #0x84dbb8
    // 0x84dbb0: r0 = Null
    //     0x84dbb0: mov             x0, NULL
    // 0x84dbb4: b               #0x84dbd8
    // 0x84dbb8: r1 = LoadClassIdInstr(r0)
    //     0x84dbb8: ldur            x1, [x0, #-1]
    //     0x84dbbc: ubfx            x1, x1, #0xc, #0x14
    // 0x84dbc0: SaveReg r0
    //     0x84dbc0: str             x0, [SP, #-8]!
    // 0x84dbc4: mov             x0, x1
    // 0x84dbc8: r0 = GDT[cid_x0 + -0xefb]()
    //     0x84dbc8: sub             lr, x0, #0xefb
    //     0x84dbcc: ldr             lr, [x21, lr, lsl #3]
    //     0x84dbd0: blr             lr
    // 0x84dbd4: add             SP, SP, #8
    // 0x84dbd8: LeaveFrame
    //     0x84dbd8: mov             SP, fp
    //     0x84dbdc: ldp             fp, lr, [SP], #0x10
    // 0x84dbe0: ret
    //     0x84dbe0: ret             
    // 0x84dbe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dbe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dbe8: b               #0x84dba4
  }
  [closure] MaterialStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84dbec, size: 0x5c
    // 0x84dbec: EnterFrame
    //     0x84dbec: stp             fp, lr, [SP, #-0x10]!
    //     0x84dbf0: mov             fp, SP
    // 0x84dbf4: CheckStackOverflow
    //     0x84dbf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84dbf8: cmp             SP, x16
    //     0x84dbfc: b.ls            #0x84dc40
    // 0x84dc00: ldr             x0, [fp, #0x10]
    // 0x84dc04: cmp             w0, NULL
    // 0x84dc08: b.ne            #0x84dc14
    // 0x84dc0c: r0 = Null
    //     0x84dc0c: mov             x0, NULL
    // 0x84dc10: b               #0x84dc34
    // 0x84dc14: r1 = LoadClassIdInstr(r0)
    //     0x84dc14: ldur            x1, [x0, #-1]
    //     0x84dc18: ubfx            x1, x1, #0xc, #0x14
    // 0x84dc1c: SaveReg r0
    //     0x84dc1c: str             x0, [SP, #-8]!
    // 0x84dc20: mov             x0, x1
    // 0x84dc24: r0 = GDT[cid_x0 + -0xf4f]()
    //     0x84dc24: sub             lr, x0, #0xf4f
    //     0x84dc28: ldr             lr, [x21, lr, lsl #3]
    //     0x84dc2c: blr             lr
    // 0x84dc30: add             SP, SP, #8
    // 0x84dc34: LeaveFrame
    //     0x84dc34: mov             SP, fp
    //     0x84dc38: ldp             fp, lr, [SP], #0x10
    // 0x84dc3c: ret
    //     0x84dc3c: ret             
    // 0x84dc40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dc40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dc44: b               #0x84dc00
  }
  [closure] MaterialStateProperty<Color?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84dc48, size: 0x5c
    // 0x84dc48: EnterFrame
    //     0x84dc48: stp             fp, lr, [SP, #-0x10]!
    //     0x84dc4c: mov             fp, SP
    // 0x84dc50: CheckStackOverflow
    //     0x84dc50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84dc54: cmp             SP, x16
    //     0x84dc58: b.ls            #0x84dc9c
    // 0x84dc5c: ldr             x0, [fp, #0x10]
    // 0x84dc60: cmp             w0, NULL
    // 0x84dc64: b.ne            #0x84dc70
    // 0x84dc68: r0 = Null
    //     0x84dc68: mov             x0, NULL
    // 0x84dc6c: b               #0x84dc90
    // 0x84dc70: r1 = LoadClassIdInstr(r0)
    //     0x84dc70: ldur            x1, [x0, #-1]
    //     0x84dc74: ubfx            x1, x1, #0xc, #0x14
    // 0x84dc78: SaveReg r0
    //     0x84dc78: str             x0, [SP, #-8]!
    // 0x84dc7c: mov             x0, x1
    // 0x84dc80: r0 = GDT[cid_x0 + -0xf54]()
    //     0x84dc80: sub             lr, x0, #0xf54
    //     0x84dc84: ldr             lr, [x21, lr, lsl #3]
    //     0x84dc88: blr             lr
    // 0x84dc8c: add             SP, SP, #8
    // 0x84dc90: LeaveFrame
    //     0x84dc90: mov             SP, fp
    //     0x84dc94: ldp             fp, lr, [SP], #0x10
    // 0x84dc98: ret
    //     0x84dc98: ret             
    // 0x84dc9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dc9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dca0: b               #0x84dc5c
  }
  [closure] MaterialStateProperty<TextStyle?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84dca4, size: 0x5c
    // 0x84dca4: EnterFrame
    //     0x84dca4: stp             fp, lr, [SP, #-0x10]!
    //     0x84dca8: mov             fp, SP
    // 0x84dcac: CheckStackOverflow
    //     0x84dcac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84dcb0: cmp             SP, x16
    //     0x84dcb4: b.ls            #0x84dcf8
    // 0x84dcb8: ldr             x0, [fp, #0x10]
    // 0x84dcbc: cmp             w0, NULL
    // 0x84dcc0: b.ne            #0x84dccc
    // 0x84dcc4: r0 = Null
    //     0x84dcc4: mov             x0, NULL
    // 0x84dcc8: b               #0x84dcec
    // 0x84dccc: r1 = LoadClassIdInstr(r0)
    //     0x84dccc: ldur            x1, [x0, #-1]
    //     0x84dcd0: ubfx            x1, x1, #0xc, #0x14
    // 0x84dcd4: SaveReg r0
    //     0x84dcd4: str             x0, [SP, #-8]!
    // 0x84dcd8: mov             x0, x1
    // 0x84dcdc: r0 = GDT[cid_x0 + -0xf5d]()
    //     0x84dcdc: sub             lr, x0, #0xf5d
    //     0x84dce0: ldr             lr, [x21, lr, lsl #3]
    //     0x84dce4: blr             lr
    // 0x84dce8: add             SP, SP, #8
    // 0x84dcec: LeaveFrame
    //     0x84dcec: mov             SP, fp
    //     0x84dcf0: ldp             fp, lr, [SP], #0x10
    // 0x84dcf4: ret
    //     0x84dcf4: ret             
    // 0x84dcf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dcf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dcfc: b               #0x84dcb8
  }
  [closure] MaterialStateProperty<double?>? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84dd00, size: 0x5c
    // 0x84dd00: EnterFrame
    //     0x84dd00: stp             fp, lr, [SP, #-0x10]!
    //     0x84dd04: mov             fp, SP
    // 0x84dd08: CheckStackOverflow
    //     0x84dd08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84dd0c: cmp             SP, x16
    //     0x84dd10: b.ls            #0x84dd54
    // 0x84dd14: ldr             x0, [fp, #0x10]
    // 0x84dd18: cmp             w0, NULL
    // 0x84dd1c: b.ne            #0x84dd28
    // 0x84dd20: r0 = Null
    //     0x84dd20: mov             x0, NULL
    // 0x84dd24: b               #0x84dd48
    // 0x84dd28: r1 = LoadClassIdInstr(r0)
    //     0x84dd28: ldur            x1, [x0, #-1]
    //     0x84dd2c: ubfx            x1, x1, #0xc, #0x14
    // 0x84dd30: SaveReg r0
    //     0x84dd30: str             x0, [SP, #-8]!
    // 0x84dd34: mov             x0, x1
    // 0x84dd38: r0 = GDT[cid_x0 + -0xee9]()
    //     0x84dd38: sub             lr, x0, #0xee9
    //     0x84dd3c: ldr             lr, [x21, lr, lsl #3]
    //     0x84dd40: blr             lr
    // 0x84dd44: add             SP, SP, #8
    // 0x84dd48: LeaveFrame
    //     0x84dd48: mov             SP, fp
    //     0x84dd4c: ldp             fp, lr, [SP], #0x10
    // 0x84dd50: ret
    //     0x84dd50: ret             
    // 0x84dd54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84dd54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84dd58: b               #0x84dd14
  }
  [closure] Y0? resolve<Y0>(dynamic, (dynamic, ButtonStyle?) => MaterialStateProperty<Y0>?) {
    // ** addr: 0x84dd5c, size: 0xe8
    // 0x84dd5c: EnterFrame
    //     0x84dd5c: stp             fp, lr, [SP, #-0x10]!
    //     0x84dd60: mov             fp, SP
    // 0x84dd64: AllocStack(0x18)
    //     0x84dd64: sub             SP, SP, #0x18
    // 0x84dd68: SetupParameters()
    //     0x84dd68: ldr             x0, [fp, #0x18]
    //     0x84dd6c: mov             x1, x4
    //     0x84dd70: ldur            w2, [x0, #0x17]
    //     0x84dd74: add             x2, x2, HEAP, lsl #32
    //     0x84dd78: stur            x2, [fp, #-0x10]
    //     0x84dd7c: ldur            w3, [x1, #0xf]
    //     0x84dd80: add             x3, x3, HEAP, lsl #32
    //     0x84dd84: cbnz            w3, #0x84dd90
    //     0x84dd88: mov             x1, NULL
    //     0x84dd8c: b               #0x84dda0
    //     0x84dd90: ldur            w3, [x1, #0x17]
    //     0x84dd94: add             x3, x3, HEAP, lsl #32
    //     0x84dd98: add             x1, fp, w3, sxtw #2
    //     0x84dd9c: ldr             x1, [x1, #0x10]
    //     0x84dda0: ldur            w3, [x0, #0xf]
    //     0x84dda4: add             x3, x3, HEAP, lsl #32
    //     0x84dda8: ldr             x16, [PP, #0x50]  ; [pp+0x50] TypeArguments: 
    //     0x84ddac: cmp             w3, w16
    //     0x84ddb0: b.eq            #0x84ddb8
    //     0x84ddb4: mov             x1, x3
    //     0x84ddb8: ldr             x0, [fp, #0x10]
    //     0x84ddbc: stur            x1, [fp, #-8]
    // 0x84ddc0: CheckStackOverflow
    //     0x84ddc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84ddc4: cmp             SP, x16
    //     0x84ddc8: b.ls            #0x84de3c
    // 0x84ddcc: r1 = 1
    //     0x84ddcc: mov             x1, #1
    // 0x84ddd0: r0 = AllocateContext()
    //     0x84ddd0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84ddd4: mov             x1, x0
    // 0x84ddd8: ldur            x0, [fp, #-0x10]
    // 0x84dddc: StoreField: r1->field_b = r0
    //     0x84dddc: stur            w0, [x1, #0xb]
    // 0x84dde0: ldr             x2, [fp, #0x10]
    // 0x84dde4: StoreField: r1->field_f = r2
    //     0x84dde4: stur            w2, [x1, #0xf]
    // 0x84dde8: LoadField: r3 = r0->field_1f
    //     0x84dde8: ldur            w3, [x0, #0x1f]
    // 0x84ddec: DecompressPointer r3
    //     0x84ddec: add             x3, x3, HEAP, lsl #32
    // 0x84ddf0: mov             x2, x1
    // 0x84ddf4: stur            x3, [fp, #-0x18]
    // 0x84ddf8: r1 = Function '<anonymous closure>':.
    //     0x84ddf8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e6f8] AnonymousClosure: (0x84de44), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::build (0x84bfac)
    //     0x84ddfc: ldr             x1, [x1, #0x6f8]
    // 0x84de00: r0 = AllocateClosure()
    //     0x84de00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84de04: mov             x1, x0
    // 0x84de08: ldur            x0, [fp, #-8]
    // 0x84de0c: StoreField: r1->field_b = r0
    //     0x84de0c: stur            w0, [x1, #0xb]
    // 0x84de10: ldur            x16, [fp, #-0x18]
    // 0x84de14: stp             x16, x0, [SP, #-0x10]!
    // 0x84de18: SaveReg r1
    //     0x84de18: str             x1, [SP, #-8]!
    // 0x84de1c: ldur            x0, [fp, #-0x18]
    // 0x84de20: ClosureCall
    //     0x84de20: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    //     0x84de24: ldur            x2, [x0, #0x1f]
    //     0x84de28: blr             x2
    // 0x84de2c: add             SP, SP, #0x18
    // 0x84de30: LeaveFrame
    //     0x84de30: mov             SP, fp
    //     0x84de34: ldp             fp, lr, [SP], #0x10
    // 0x84de38: ret
    //     0x84de38: ret             
    // 0x84de3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84de3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84de40: b               #0x84ddcc
  }
  [closure] Y0? <anonymous closure>(dynamic, ButtonStyle?) {
    // ** addr: 0x84de44, size: 0x100
    // 0x84de44: EnterFrame
    //     0x84de44: stp             fp, lr, [SP, #-0x10]!
    //     0x84de48: mov             fp, SP
    // 0x84de4c: AllocStack(0x8)
    //     0x84de4c: sub             SP, SP, #8
    // 0x84de50: SetupParameters()
    //     0x84de50: ldr             x0, [fp, #0x18]
    //     0x84de54: ldur            w1, [x0, #0x17]
    //     0x84de58: add             x1, x1, HEAP, lsl #32
    //     0x84de5c: stur            x1, [fp, #-8]
    // 0x84de60: CheckStackOverflow
    //     0x84de60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84de64: cmp             SP, x16
    //     0x84de68: b.ls            #0x84df30
    // 0x84de6c: LoadField: r0 = r1->field_f
    //     0x84de6c: ldur            w0, [x1, #0xf]
    // 0x84de70: DecompressPointer r0
    //     0x84de70: add             x0, x0, HEAP, lsl #32
    // 0x84de74: cmp             w0, NULL
    // 0x84de78: b.eq            #0x84df38
    // 0x84de7c: ldr             x16, [fp, #0x10]
    // 0x84de80: stp             x16, x0, [SP, #-0x10]!
    // 0x84de84: ClosureCall
    //     0x84de84: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84de88: ldur            x2, [x0, #0x1f]
    //     0x84de8c: blr             x2
    // 0x84de90: add             SP, SP, #0x10
    // 0x84de94: cmp             w0, NULL
    // 0x84de98: b.ne            #0x84dea4
    // 0x84de9c: r0 = Null
    //     0x84de9c: mov             x0, NULL
    // 0x84dea0: b               #0x84df24
    // 0x84dea4: ldur            x1, [fp, #-8]
    // 0x84dea8: LoadField: r2 = r1->field_b
    //     0x84dea8: ldur            w2, [x1, #0xb]
    // 0x84deac: DecompressPointer r2
    //     0x84deac: add             x2, x2, HEAP, lsl #32
    // 0x84deb0: LoadField: r1 = r2->field_f
    //     0x84deb0: ldur            w1, [x2, #0xf]
    // 0x84deb4: DecompressPointer r1
    //     0x84deb4: add             x1, x1, HEAP, lsl #32
    // 0x84deb8: LoadField: r2 = r1->field_b
    //     0x84deb8: ldur            w2, [x1, #0xb]
    // 0x84debc: DecompressPointer r2
    //     0x84debc: add             x2, x2, HEAP, lsl #32
    // 0x84dec0: cmp             w2, NULL
    // 0x84dec4: b.eq            #0x84df3c
    // 0x84dec8: LoadField: r3 = r2->field_2b
    //     0x84dec8: ldur            w3, [x2, #0x2b]
    // 0x84decc: DecompressPointer r3
    //     0x84decc: add             x3, x3, HEAP, lsl #32
    // 0x84ded0: cmp             w3, NULL
    // 0x84ded4: b.ne            #0x84def0
    // 0x84ded8: LoadField: r2 = r1->field_27
    //     0x84ded8: ldur            w2, [x1, #0x27]
    // 0x84dedc: DecompressPointer r2
    //     0x84dedc: add             x2, x2, HEAP, lsl #32
    // 0x84dee0: cmp             w2, NULL
    // 0x84dee4: b.eq            #0x84df40
    // 0x84dee8: mov             x1, x2
    // 0x84deec: b               #0x84def4
    // 0x84def0: mov             x1, x3
    // 0x84def4: LoadField: r2 = r1->field_27
    //     0x84def4: ldur            w2, [x1, #0x27]
    // 0x84def8: DecompressPointer r2
    //     0x84def8: add             x2, x2, HEAP, lsl #32
    // 0x84defc: r1 = LoadClassIdInstr(r0)
    //     0x84defc: ldur            x1, [x0, #-1]
    //     0x84df00: ubfx            x1, x1, #0xc, #0x14
    // 0x84df04: stp             x2, x0, [SP, #-0x10]!
    // 0x84df08: mov             x0, x1
    // 0x84df0c: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x84df0c: mov             x17, #0x5e7
    //     0x84df10: movk            x17, #1, lsl #16
    //     0x84df14: add             lr, x0, x17
    //     0x84df18: ldr             lr, [x21, lr, lsl #3]
    //     0x84df1c: blr             lr
    // 0x84df20: add             SP, SP, #0x10
    // 0x84df24: LeaveFrame
    //     0x84df24: mov             SP, fp
    //     0x84df28: ldp             fp, lr, [SP], #0x10
    // 0x84df2c: ret
    //     0x84df2c: ret             
    // 0x84df30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84df30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84df34: b               #0x84de6c
    // 0x84df38: r0 = NullErrorSharedWithoutFPURegs()
    //     0x84df38: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x84df3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84df3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84df40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84df40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Y0? effectiveValue<Y0>(dynamic, (dynamic, ButtonStyle?) => Y0?) {
    // ** addr: 0x84df44, size: 0xdc
    // 0x84df44: EnterFrame
    //     0x84df44: stp             fp, lr, [SP, #-0x10]!
    //     0x84df48: mov             fp, SP
    // 0x84df4c: AllocStack(0x18)
    //     0x84df4c: sub             SP, SP, #0x18
    // 0x84df50: SetupParameters()
    //     0x84df50: ldr             x0, [fp, #0x18]
    //     0x84df54: ldur            w1, [x0, #0x17]
    //     0x84df58: add             x1, x1, HEAP, lsl #32
    //     0x84df5c: stur            x1, [fp, #-8]
    // 0x84df60: CheckStackOverflow
    //     0x84df60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84df64: cmp             SP, x16
    //     0x84df68: b.ls            #0x84e018
    // 0x84df6c: LoadField: r0 = r1->field_13
    //     0x84df6c: ldur            w0, [x1, #0x13]
    // 0x84df70: DecompressPointer r0
    //     0x84df70: add             x0, x0, HEAP, lsl #32
    // 0x84df74: ldr             x16, [fp, #0x10]
    // 0x84df78: stp             x0, x16, [SP, #-0x10]!
    // 0x84df7c: ldr             x0, [fp, #0x10]
    // 0x84df80: ClosureCall
    //     0x84df80: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84df84: ldur            x2, [x0, #0x1f]
    //     0x84df88: blr             x2
    // 0x84df8c: add             SP, SP, #0x10
    // 0x84df90: mov             x2, x0
    // 0x84df94: ldur            x1, [fp, #-8]
    // 0x84df98: stur            x2, [fp, #-0x10]
    // 0x84df9c: LoadField: r0 = r1->field_17
    //     0x84df9c: ldur            w0, [x1, #0x17]
    // 0x84dfa0: DecompressPointer r0
    //     0x84dfa0: add             x0, x0, HEAP, lsl #32
    // 0x84dfa4: ldr             x16, [fp, #0x10]
    // 0x84dfa8: stp             x0, x16, [SP, #-0x10]!
    // 0x84dfac: ldr             x0, [fp, #0x10]
    // 0x84dfb0: ClosureCall
    //     0x84dfb0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84dfb4: ldur            x2, [x0, #0x1f]
    //     0x84dfb8: blr             x2
    // 0x84dfbc: add             SP, SP, #0x10
    // 0x84dfc0: mov             x1, x0
    // 0x84dfc4: ldur            x0, [fp, #-8]
    // 0x84dfc8: stur            x1, [fp, #-0x18]
    // 0x84dfcc: LoadField: r2 = r0->field_1b
    //     0x84dfcc: ldur            w2, [x0, #0x1b]
    // 0x84dfd0: DecompressPointer r2
    //     0x84dfd0: add             x2, x2, HEAP, lsl #32
    // 0x84dfd4: ldr             x16, [fp, #0x10]
    // 0x84dfd8: stp             x2, x16, [SP, #-0x10]!
    // 0x84dfdc: ldr             x0, [fp, #0x10]
    // 0x84dfe0: ClosureCall
    //     0x84dfe0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84dfe4: ldur            x2, [x0, #0x1f]
    //     0x84dfe8: blr             x2
    // 0x84dfec: add             SP, SP, #0x10
    // 0x84dff0: ldur            x1, [fp, #-0x10]
    // 0x84dff4: cmp             w1, NULL
    // 0x84dff8: b.ne            #0x84e000
    // 0x84dffc: ldur            x1, [fp, #-0x18]
    // 0x84e000: cmp             w1, NULL
    // 0x84e004: b.eq            #0x84e00c
    // 0x84e008: mov             x0, x1
    // 0x84e00c: LeaveFrame
    //     0x84e00c: mov             SP, fp
    //     0x84e010: ldp             fp, lr, [SP], #0x10
    // 0x84e014: ret
    //     0x84e014: ret             
    // 0x84e018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84e018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84e01c: b               #0x84df6c
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d94c0, size: 0x3c
    // 0x9d94c0: EnterFrame
    //     0x9d94c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d94c4: mov             fp, SP
    // 0x9d94c8: CheckStackOverflow
    //     0x9d94c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d94cc: cmp             SP, x16
    //     0x9d94d0: b.ls            #0x9d94f4
    // 0x9d94d4: ldr             x16, [fp, #0x10]
    // 0x9d94d8: SaveReg r16
    //     0x9d94d8: str             x16, [SP, #-8]!
    // 0x9d94dc: r0 = initStatesController()
    //     0x9d94dc: bl              #0x7b0908  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::initStatesController
    // 0x9d94e0: add             SP, SP, #8
    // 0x9d94e4: r0 = Null
    //     0x9d94e4: mov             x0, NULL
    // 0x9d94e8: LeaveFrame
    //     0x9d94e8: mov             SP, fp
    //     0x9d94ec: ldp             fp, lr, [SP], #0x10
    // 0x9d94f0: ret
    //     0x9d94f0: ret             
    // 0x9d94f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d94f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d94f8: b               #0x9d94d4
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4aa68, size: 0x18
    // 0xa4aa68: r4 = 7
    //     0xa4aa68: mov             x4, #7
    // 0xa4aa6c: r1 = Function 'dispose':.
    //     0xa4aa6c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b900] AnonymousClosure: (0xa4aa80), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::dispose (0xa510f4)
    //     0xa4aa70: ldr             x1, [x17, #0x900]
    // 0xa4aa74: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4aa74: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4aa78: LoadField: r0 = r24->field_17
    //     0xa4aa78: ldur            x0, [x24, #0x17]
    // 0xa4aa7c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4aa80, size: 0x48
    // 0xa4aa80: EnterFrame
    //     0xa4aa80: stp             fp, lr, [SP, #-0x10]!
    //     0xa4aa84: mov             fp, SP
    // 0xa4aa88: ldr             x0, [fp, #0x10]
    // 0xa4aa8c: LoadField: r1 = r0->field_17
    //     0xa4aa8c: ldur            w1, [x0, #0x17]
    // 0xa4aa90: DecompressPointer r1
    //     0xa4aa90: add             x1, x1, HEAP, lsl #32
    // 0xa4aa94: CheckStackOverflow
    //     0xa4aa94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4aa98: cmp             SP, x16
    //     0xa4aa9c: b.ls            #0xa4aac0
    // 0xa4aaa0: LoadField: r0 = r1->field_f
    //     0xa4aaa0: ldur            w0, [x1, #0xf]
    // 0xa4aaa4: DecompressPointer r0
    //     0xa4aaa4: add             x0, x0, HEAP, lsl #32
    // 0xa4aaa8: SaveReg r0
    //     0xa4aaa8: str             x0, [SP, #-8]!
    // 0xa4aaac: r0 = dispose()
    //     0xa4aaac: bl              #0xa510f4  ; [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::dispose
    // 0xa4aab0: add             SP, SP, #8
    // 0xa4aab4: LeaveFrame
    //     0xa4aab4: mov             SP, fp
    //     0xa4aab8: ldp             fp, lr, [SP], #0x10
    // 0xa4aabc: ret
    //     0xa4aabc: ret             
    // 0xa4aac0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4aac0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4aac4: b               #0xa4aaa0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa510f4, size: 0xfc
    // 0xa510f4: EnterFrame
    //     0xa510f4: stp             fp, lr, [SP, #-0x10]!
    //     0xa510f8: mov             fp, SP
    // 0xa510fc: AllocStack(0x8)
    //     0xa510fc: sub             SP, SP, #8
    // 0xa51100: CheckStackOverflow
    //     0xa51100: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51104: cmp             SP, x16
    //     0xa51108: b.ls            #0xa511e0
    // 0xa5110c: ldr             x0, [fp, #0x10]
    // 0xa51110: LoadField: r1 = r0->field_b
    //     0xa51110: ldur            w1, [x0, #0xb]
    // 0xa51114: DecompressPointer r1
    //     0xa51114: add             x1, x1, HEAP, lsl #32
    // 0xa51118: cmp             w1, NULL
    // 0xa5111c: b.eq            #0xa511e8
    // 0xa51120: LoadField: r2 = r1->field_2b
    //     0xa51120: ldur            w2, [x1, #0x2b]
    // 0xa51124: DecompressPointer r2
    //     0xa51124: add             x2, x2, HEAP, lsl #32
    // 0xa51128: cmp             w2, NULL
    // 0xa5112c: b.ne            #0xa51144
    // 0xa51130: LoadField: r1 = r0->field_27
    //     0xa51130: ldur            w1, [x0, #0x27]
    // 0xa51134: DecompressPointer r1
    //     0xa51134: add             x1, x1, HEAP, lsl #32
    // 0xa51138: cmp             w1, NULL
    // 0xa5113c: b.eq            #0xa511ec
    // 0xa51140: b               #0xa51148
    // 0xa51144: mov             x1, x2
    // 0xa51148: stur            x1, [fp, #-8]
    // 0xa5114c: r1 = 1
    //     0xa5114c: mov             x1, #1
    // 0xa51150: r0 = AllocateContext()
    //     0xa51150: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa51154: mov             x1, x0
    // 0xa51158: ldr             x0, [fp, #0x10]
    // 0xa5115c: StoreField: r1->field_f = r0
    //     0xa5115c: stur            w0, [x1, #0xf]
    // 0xa51160: mov             x2, x1
    // 0xa51164: r1 = Function 'handleStatesControllerChange':.
    //     0xa51164: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e720] AnonymousClosure: (0x7b0c08), in [package:flutter/src/material/button_style_button.dart] _ButtonStyleState::handleStatesControllerChange (0x7b0c50)
    //     0xa51168: ldr             x1, [x1, #0x720]
    // 0xa5116c: r0 = AllocateClosure()
    //     0xa5116c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa51170: ldur            x16, [fp, #-8]
    // 0xa51174: stp             x0, x16, [SP, #-0x10]!
    // 0xa51178: r0 = removeListener()
    //     0xa51178: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa5117c: add             SP, SP, #0x10
    // 0xa51180: ldr             x0, [fp, #0x10]
    // 0xa51184: LoadField: r1 = r0->field_27
    //     0xa51184: ldur            w1, [x0, #0x27]
    // 0xa51188: DecompressPointer r1
    //     0xa51188: add             x1, x1, HEAP, lsl #32
    // 0xa5118c: cmp             w1, NULL
    // 0xa51190: b.eq            #0xa511a4
    // 0xa51194: SaveReg r1
    //     0xa51194: str             x1, [SP, #-8]!
    // 0xa51198: r0 = dispose()
    //     0xa51198: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0xa5119c: add             SP, SP, #8
    // 0xa511a0: ldr             x0, [fp, #0x10]
    // 0xa511a4: LoadField: r1 = r0->field_1b
    //     0xa511a4: ldur            w1, [x0, #0x1b]
    // 0xa511a8: DecompressPointer r1
    //     0xa511a8: add             x1, x1, HEAP, lsl #32
    // 0xa511ac: cmp             w1, NULL
    // 0xa511b0: b.eq            #0xa511c0
    // 0xa511b4: SaveReg r1
    //     0xa511b4: str             x1, [SP, #-8]!
    // 0xa511b8: r0 = dispose()
    //     0xa511b8: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa511bc: add             SP, SP, #8
    // 0xa511c0: ldr             x16, [fp, #0x10]
    // 0xa511c4: SaveReg r16
    //     0xa511c4: str             x16, [SP, #-8]!
    // 0xa511c8: r0 = dispose()
    //     0xa511c8: bl              #0xa511f0  ; [package:flutter/src/material/button_style_button.dart] __ButtonStyleState&State&TickerProviderStateMixin::dispose
    // 0xa511cc: add             SP, SP, #8
    // 0xa511d0: r0 = Null
    //     0xa511d0: mov             x0, NULL
    // 0xa511d4: LeaveFrame
    //     0xa511d4: mov             SP, fp
    //     0xa511d8: ldp             fp, lr, [SP], #0x10
    // 0xa511dc: ret
    //     0xa511dc: ret             
    // 0xa511e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa511e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa511e4: b               #0xa5110c
    // 0xa511e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa511e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa511ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa511ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3674, size: 0x14, field offset: 0x10
//   const constructor, 
class _InputPadding extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c27d8, size: 0x80
    // 0x6c27d8: EnterFrame
    //     0x6c27d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c27dc: mov             fp, SP
    // 0x6c27e0: CheckStackOverflow
    //     0x6c27e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c27e4: cmp             SP, x16
    //     0x6c27e8: b.ls            #0x6c2850
    // 0x6c27ec: ldr             x0, [fp, #0x10]
    // 0x6c27f0: r2 = Null
    //     0x6c27f0: mov             x2, NULL
    // 0x6c27f4: r1 = Null
    //     0x6c27f4: mov             x1, NULL
    // 0x6c27f8: r4 = 59
    //     0x6c27f8: mov             x4, #0x3b
    // 0x6c27fc: branchIfSmi(r0, 0x6c2808)
    //     0x6c27fc: tbz             w0, #0, #0x6c2808
    // 0x6c2800: r4 = LoadClassIdInstr(r0)
    //     0x6c2800: ldur            x4, [x0, #-1]
    //     0x6c2804: ubfx            x4, x4, #0xc, #0x14
    // 0x6c2808: cmp             x4, #0x99d
    // 0x6c280c: b.eq            #0x6c2824
    // 0x6c2810: r8 = _RenderInputPadding
    //     0x6c2810: add             x8, PP, #0x37, lsl #12  ; [pp+0x37948] Type: _RenderInputPadding
    //     0x6c2814: ldr             x8, [x8, #0x948]
    // 0x6c2818: r3 = Null
    //     0x6c2818: add             x3, PP, #0x37, lsl #12  ; [pp+0x37950] Null
    //     0x6c281c: ldr             x3, [x3, #0x950]
    // 0x6c2820: r0 = DefaultTypeTest()
    //     0x6c2820: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c2824: ldr             x0, [fp, #0x20]
    // 0x6c2828: LoadField: r1 = r0->field_f
    //     0x6c2828: ldur            w1, [x0, #0xf]
    // 0x6c282c: DecompressPointer r1
    //     0x6c282c: add             x1, x1, HEAP, lsl #32
    // 0x6c2830: ldr             x16, [fp, #0x10]
    // 0x6c2834: stp             x1, x16, [SP, #-0x10]!
    // 0x6c2838: r0 = minSize=()
    //     0x6c2838: bl              #0x6c2738  ; [package:flutter/src/material/button.dart] _RenderInputPadding::minSize=
    // 0x6c283c: add             SP, SP, #0x10
    // 0x6c2840: r0 = Null
    //     0x6c2840: mov             x0, NULL
    // 0x6c2844: LeaveFrame
    //     0x6c2844: mov             SP, fp
    //     0x6c2848: ldp             fp, lr, [SP], #0x10
    // 0x6c284c: ret
    //     0x6c284c: ret             
    // 0x6c2850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2854: b               #0x6c27ec
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ea220, size: 0x70
    // 0x6ea220: EnterFrame
    //     0x6ea220: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea224: mov             fp, SP
    // 0x6ea228: AllocStack(0x10)
    //     0x6ea228: sub             SP, SP, #0x10
    // 0x6ea22c: CheckStackOverflow
    //     0x6ea22c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea230: cmp             SP, x16
    //     0x6ea234: b.ls            #0x6ea288
    // 0x6ea238: ldr             x0, [fp, #0x18]
    // 0x6ea23c: LoadField: r1 = r0->field_f
    //     0x6ea23c: ldur            w1, [x0, #0xf]
    // 0x6ea240: DecompressPointer r1
    //     0x6ea240: add             x1, x1, HEAP, lsl #32
    // 0x6ea244: stur            x1, [fp, #-8]
    // 0x6ea248: r0 = _RenderInputPadding()
    //     0x6ea248: bl              #0x6ea290  ; Allocate_RenderInputPaddingStub -> _RenderInputPadding (size=0x68)
    // 0x6ea24c: mov             x1, x0
    // 0x6ea250: ldur            x0, [fp, #-8]
    // 0x6ea254: stur            x1, [fp, #-0x10]
    // 0x6ea258: StoreField: r1->field_63 = r0
    //     0x6ea258: stur            w0, [x1, #0x63]
    // 0x6ea25c: SaveReg r1
    //     0x6ea25c: str             x1, [SP, #-8]!
    // 0x6ea260: r0 = RenderObject()
    //     0x6ea260: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea264: add             SP, SP, #8
    // 0x6ea268: ldur            x16, [fp, #-0x10]
    // 0x6ea26c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea270: r0 = child=()
    //     0x6ea270: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea274: add             SP, SP, #0x10
    // 0x6ea278: ldur            x0, [fp, #-0x10]
    // 0x6ea27c: LeaveFrame
    //     0x6ea27c: mov             SP, fp
    //     0x6ea280: ldp             fp, lr, [SP], #0x10
    // 0x6ea284: ret
    //     0x6ea284: ret             
    // 0x6ea288: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea288: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea28c: b               #0x6ea238
  }
}

// class id: 4160, size: 0x34, field offset: 0xc
//   const constructor, 
abstract class ButtonStyleButton extends StatefulWidget {

  static _ allOrNull(/* No info */) {
    // ** addr: 0x9173fc, size: 0x60
    // 0x9173fc: EnterFrame
    //     0x9173fc: stp             fp, lr, [SP, #-0x10]!
    //     0x917400: mov             fp, SP
    // 0x917404: mov             x0, x4
    // 0x917408: LoadField: r1 = r0->field_f
    //     0x917408: ldur            w1, [x0, #0xf]
    // 0x91740c: DecompressPointer r1
    //     0x91740c: add             x1, x1, HEAP, lsl #32
    // 0x917410: cbnz            w1, #0x91741c
    // 0x917414: r1 = Null
    //     0x917414: mov             x1, NULL
    // 0x917418: b               #0x917430
    // 0x91741c: LoadField: r1 = r0->field_17
    //     0x91741c: ldur            w1, [x0, #0x17]
    // 0x917420: DecompressPointer r1
    //     0x917420: add             x1, x1, HEAP, lsl #32
    // 0x917424: add             x0, fp, w1, sxtw #2
    // 0x917428: ldr             x0, [x0, #0x10]
    // 0x91742c: mov             x1, x0
    // 0x917430: ldr             x0, [fp, #0x10]
    // 0x917434: cmp             w0, NULL
    // 0x917438: b.ne            #0x917444
    // 0x91743c: r0 = Null
    //     0x91743c: mov             x0, NULL
    // 0x917440: b               #0x917450
    // 0x917444: r0 = MaterialStatePropertyAll()
    //     0x917444: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0x917448: ldr             x1, [fp, #0x10]
    // 0x91744c: StoreField: r0->field_b = r1
    //     0x91744c: stur            w1, [x0, #0xb]
    // 0x917450: LeaveFrame
    //     0x917450: mov             SP, fp
    //     0x917454: ldp             fp, lr, [SP], #0x10
    // 0x917458: ret
    //     0x917458: ret             
  }
  _ createState(/* No info */) {
    // ** addr: 0xa4032c, size: 0x20
    // 0xa4032c: EnterFrame
    //     0xa4032c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40330: mov             fp, SP
    // 0xa40334: r1 = <ButtonStyleButton>
    //     0xa40334: add             x1, PP, #0x28, lsl #12  ; [pp+0x28c70] TypeArguments: <ButtonStyleButton>
    //     0xa40338: ldr             x1, [x1, #0xc70]
    // 0xa4033c: r0 = _ButtonStyleState()
    //     0xa4033c: bl              #0xa4034c  ; Allocate_ButtonStyleStateStub -> _ButtonStyleState (size=0x2c)
    // 0xa40340: LeaveFrame
    //     0xa40340: mov             SP, fp
    //     0xa40344: ldp             fp, lr, [SP], #0x10
    // 0xa40348: ret
    //     0xa40348: ret             
  }
  static _ scaledPadding(/* No info */) {
    // ** addr: 0xc14c04, size: 0x150
    // 0xc14c04: EnterFrame
    //     0xc14c04: stp             fp, lr, [SP, #-0x10]!
    //     0xc14c08: mov             fp, SP
    // 0xc14c0c: d0 = 1.000000
    //     0xc14c0c: fmov            d0, #1.00000000
    // 0xc14c10: CheckStackOverflow
    //     0xc14c10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc14c14: cmp             SP, x16
    //     0xc14c18: b.ls            #0xc14d24
    // 0xc14c1c: ldr             d1, [fp, #0x10]
    // 0xc14c20: fcmp            d1, d0
    // 0xc14c24: b.vs            #0xc14c3c
    // 0xc14c28: b.gt            #0xc14c3c
    // 0xc14c2c: ldr             x0, [fp, #0x20]
    // 0xc14c30: LeaveFrame
    //     0xc14c30: mov             SP, fp
    //     0xc14c34: ldp             fp, lr, [SP], #0x10
    // 0xc14c38: ret
    //     0xc14c38: ret             
    // 0xc14c3c: d2 = 3.000000
    //     0xc14c3c: fmov            d2, #3.00000000
    // 0xc14c40: fcmp            d1, d2
    // 0xc14c44: b.vs            #0xc14c60
    // 0xc14c48: b.lt            #0xc14c60
    // 0xc14c4c: r0 = Instance_EdgeInsets
    //     0xc14c4c: add             x0, PP, #0x27, lsl #12  ; [pp+0x27030] Obj!EdgeInsets@b363b1
    //     0xc14c50: ldr             x0, [x0, #0x30]
    // 0xc14c54: LeaveFrame
    //     0xc14c54: mov             SP, fp
    //     0xc14c58: ldp             fp, lr, [SP], #0x10
    // 0xc14c5c: ret
    //     0xc14c5c: ret             
    // 0xc14c60: d2 = 2.000000
    //     0xc14c60: fmov            d2, #2.00000000
    // 0xc14c64: fcmp            d1, d2
    // 0xc14c68: b.vs            #0xc14cc8
    // 0xc14c6c: b.gt            #0xc14cc8
    // 0xc14c70: fsub            d2, d1, d0
    // 0xc14c74: r0 = inline_Allocate_Double()
    //     0xc14c74: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc14c78: add             x0, x0, #0x10
    //     0xc14c7c: cmp             x1, x0
    //     0xc14c80: b.ls            #0xc14d2c
    //     0xc14c84: str             x0, [THR, #0x60]  ; THR::top
    //     0xc14c88: sub             x0, x0, #0xf
    //     0xc14c8c: mov             x1, #0xd108
    //     0xc14c90: movk            x1, #3, lsl #16
    //     0xc14c94: stur            x1, [x0, #-1]
    // 0xc14c98: StoreField: r0->field_7 = d2
    //     0xc14c98: stur            d2, [x0, #7]
    // 0xc14c9c: ldr             x16, [fp, #0x20]
    // 0xc14ca0: ldr             lr, [fp, #0x18]
    // 0xc14ca4: stp             lr, x16, [SP, #-0x10]!
    // 0xc14ca8: SaveReg r0
    //     0xc14ca8: str             x0, [SP, #-8]!
    // 0xc14cac: r0 = lerp()
    //     0xc14cac: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xc14cb0: add             SP, SP, #0x18
    // 0xc14cb4: cmp             w0, NULL
    // 0xc14cb8: b.eq            #0xc14d3c
    // 0xc14cbc: LeaveFrame
    //     0xc14cbc: mov             SP, fp
    //     0xc14cc0: ldp             fp, lr, [SP], #0x10
    // 0xc14cc4: ret
    //     0xc14cc4: ret             
    // 0xc14cc8: fsub            d0, d1, d2
    // 0xc14ccc: r0 = inline_Allocate_Double()
    //     0xc14ccc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc14cd0: add             x0, x0, #0x10
    //     0xc14cd4: cmp             x1, x0
    //     0xc14cd8: b.ls            #0xc14d40
    //     0xc14cdc: str             x0, [THR, #0x60]  ; THR::top
    //     0xc14ce0: sub             x0, x0, #0xf
    //     0xc14ce4: mov             x1, #0xd108
    //     0xc14ce8: movk            x1, #3, lsl #16
    //     0xc14cec: stur            x1, [x0, #-1]
    // 0xc14cf0: StoreField: r0->field_7 = d0
    //     0xc14cf0: stur            d0, [x0, #7]
    // 0xc14cf4: ldr             x16, [fp, #0x18]
    // 0xc14cf8: r30 = Instance_EdgeInsets
    //     0xc14cf8: add             lr, PP, #0x27, lsl #12  ; [pp+0x27030] Obj!EdgeInsets@b363b1
    //     0xc14cfc: ldr             lr, [lr, #0x30]
    // 0xc14d00: stp             lr, x16, [SP, #-0x10]!
    // 0xc14d04: SaveReg r0
    //     0xc14d04: str             x0, [SP, #-8]!
    // 0xc14d08: r0 = lerp()
    //     0xc14d08: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xc14d0c: add             SP, SP, #0x18
    // 0xc14d10: cmp             w0, NULL
    // 0xc14d14: b.eq            #0xc14d50
    // 0xc14d18: LeaveFrame
    //     0xc14d18: mov             SP, fp
    //     0xc14d1c: ldp             fp, lr, [SP], #0x10
    // 0xc14d20: ret
    //     0xc14d20: ret             
    // 0xc14d24: r0 = StackOverflowSharedWithFPURegs()
    //     0xc14d24: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc14d28: b               #0xc14c1c
    // 0xc14d2c: SaveReg d2
    //     0xc14d2c: str             q2, [SP, #-0x10]!
    // 0xc14d30: r0 = AllocateDouble()
    //     0xc14d30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc14d34: RestoreReg d2
    //     0xc14d34: ldr             q2, [SP], #0x10
    // 0xc14d38: b               #0xc14c98
    // 0xc14d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc14d3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc14d40: SaveReg d0
    //     0xc14d40: str             q0, [SP, #-0x10]!
    // 0xc14d44: r0 = AllocateDouble()
    //     0xc14d44: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc14d48: RestoreReg d0
    //     0xc14d48: ldr             q0, [SP], #0x10
    // 0xc14d4c: b               #0xc14cf0
    // 0xc14d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc14d50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/material/bottom_navigation_bar_theme.dart

// class id: 1049191, size: 0x8
class :: {
}

// class id: 2837, size: 0x40, field offset: 0x8
//   const constructor, 
class BottomNavigationBarThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafdda8, size: 0x88
    // 0xafdda8: EnterFrame
    //     0xafdda8: stp             fp, lr, [SP, #-0x10]!
    //     0xafddac: mov             fp, SP
    // 0xafddb0: CheckStackOverflow
    //     0xafddb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafddb4: cmp             SP, x16
    //     0xafddb8: b.ls            #0xafde28
    // 0xafddbc: ldr             x0, [fp, #0x10]
    // 0xafddc0: LoadField: r1 = r0->field_b
    //     0xafddc0: ldur            w1, [x0, #0xb]
    // 0xafddc4: DecompressPointer r1
    //     0xafddc4: add             x1, x1, HEAP, lsl #32
    // 0xafddc8: LoadField: r2 = r0->field_f
    //     0xafddc8: ldur            w2, [x0, #0xf]
    // 0xafddcc: DecompressPointer r2
    //     0xafddcc: add             x2, x2, HEAP, lsl #32
    // 0xafddd0: LoadField: r3 = r0->field_13
    //     0xafddd0: ldur            w3, [x0, #0x13]
    // 0xafddd4: DecompressPointer r3
    //     0xafddd4: add             x3, x3, HEAP, lsl #32
    // 0xafddd8: stp             x1, NULL, [SP, #-0x10]!
    // 0xafdddc: stp             x3, x2, [SP, #-0x10]!
    // 0xafdde0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdde4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdde8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafddec: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafddf0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafddf4: r4 = const [0, 0xe, 0xe, 0xe, null]
    //     0xafddf4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe3d8] List(5) [0, 0xe, 0xe, 0xe, Null]
    //     0xafddf8: ldr             x4, [x4, #0x3d8]
    // 0xafddfc: r0 = hash()
    //     0xafddfc: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafde00: add             SP, SP, #0x70
    // 0xafde04: mov             x2, x0
    // 0xafde08: r0 = BoxInt64Instr(r2)
    //     0xafde08: sbfiz           x0, x2, #1, #0x1f
    //     0xafde0c: cmp             x2, x0, asr #1
    //     0xafde10: b.eq            #0xafde1c
    //     0xafde14: bl              #0xd69bb8
    //     0xafde18: stur            x2, [x0, #7]
    // 0xafde1c: LeaveFrame
    //     0xafde1c: mov             SP, fp
    //     0xafde20: ldp             fp, lr, [SP], #0x10
    // 0xafde24: ret
    //     0xafde24: ret             
    // 0xafde28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafde28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafde2c: b               #0xafddbc
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5bbc, size: 0x180
    // 0xbf5bbc: EnterFrame
    //     0xbf5bbc: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5bc0: mov             fp, SP
    // 0xbf5bc4: AllocStack(0x20)
    //     0xbf5bc4: sub             SP, SP, #0x20
    // 0xbf5bc8: CheckStackOverflow
    //     0xbf5bc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5bcc: cmp             SP, x16
    //     0xbf5bd0: b.ls            #0xbf5d24
    // 0xbf5bd4: ldr             d0, [fp, #0x10]
    // 0xbf5bd8: r0 = inline_Allocate_Double()
    //     0xbf5bd8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf5bdc: add             x0, x0, #0x10
    //     0xbf5be0: cmp             x1, x0
    //     0xbf5be4: b.ls            #0xbf5d2c
    //     0xbf5be8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf5bec: sub             x0, x0, #0xf
    //     0xbf5bf0: mov             x1, #0xd108
    //     0xbf5bf4: movk            x1, #3, lsl #16
    //     0xbf5bf8: stur            x1, [x0, #-1]
    // 0xbf5bfc: StoreField: r0->field_7 = d0
    //     0xbf5bfc: stur            d0, [x0, #7]
    // 0xbf5c00: stur            x0, [fp, #-8]
    // 0xbf5c04: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5c08: SaveReg r0
    //     0xbf5c08: str             x0, [SP, #-8]!
    // 0xbf5c0c: r0 = lerp()
    //     0xbf5c0c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5c10: add             SP, SP, #0x18
    // 0xbf5c14: ldr             x0, [fp, #0x20]
    // 0xbf5c18: LoadField: r1 = r0->field_b
    //     0xbf5c18: ldur            w1, [x0, #0xb]
    // 0xbf5c1c: DecompressPointer r1
    //     0xbf5c1c: add             x1, x1, HEAP, lsl #32
    // 0xbf5c20: ldr             x2, [fp, #0x18]
    // 0xbf5c24: LoadField: r3 = r2->field_b
    //     0xbf5c24: ldur            w3, [x2, #0xb]
    // 0xbf5c28: DecompressPointer r3
    //     0xbf5c28: add             x3, x3, HEAP, lsl #32
    // 0xbf5c2c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf5c30: ldur            x16, [fp, #-8]
    // 0xbf5c34: SaveReg r16
    //     0xbf5c34: str             x16, [SP, #-8]!
    // 0xbf5c38: r0 = lerpDouble()
    //     0xbf5c38: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5c3c: add             SP, SP, #0x18
    // 0xbf5c40: mov             x1, x0
    // 0xbf5c44: ldr             x0, [fp, #0x20]
    // 0xbf5c48: stur            x1, [fp, #-0x10]
    // 0xbf5c4c: LoadField: r2 = r0->field_f
    //     0xbf5c4c: ldur            w2, [x0, #0xf]
    // 0xbf5c50: DecompressPointer r2
    //     0xbf5c50: add             x2, x2, HEAP, lsl #32
    // 0xbf5c54: ldr             x3, [fp, #0x18]
    // 0xbf5c58: LoadField: r4 = r3->field_f
    //     0xbf5c58: ldur            w4, [x3, #0xf]
    // 0xbf5c5c: DecompressPointer r4
    //     0xbf5c5c: add             x4, x4, HEAP, lsl #32
    // 0xbf5c60: stp             x4, x2, [SP, #-0x10]!
    // 0xbf5c64: ldur            x16, [fp, #-8]
    // 0xbf5c68: SaveReg r16
    //     0xbf5c68: str             x16, [SP, #-8]!
    // 0xbf5c6c: r0 = lerp()
    //     0xbf5c6c: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf5c70: add             SP, SP, #0x18
    // 0xbf5c74: mov             x1, x0
    // 0xbf5c78: ldr             x0, [fp, #0x20]
    // 0xbf5c7c: stur            x1, [fp, #-0x18]
    // 0xbf5c80: LoadField: r2 = r0->field_13
    //     0xbf5c80: ldur            w2, [x0, #0x13]
    // 0xbf5c84: DecompressPointer r2
    //     0xbf5c84: add             x2, x2, HEAP, lsl #32
    // 0xbf5c88: ldr             x0, [fp, #0x18]
    // 0xbf5c8c: LoadField: r3 = r0->field_13
    //     0xbf5c8c: ldur            w3, [x0, #0x13]
    // 0xbf5c90: DecompressPointer r3
    //     0xbf5c90: add             x3, x3, HEAP, lsl #32
    // 0xbf5c94: stp             x3, x2, [SP, #-0x10]!
    // 0xbf5c98: ldur            x16, [fp, #-8]
    // 0xbf5c9c: SaveReg r16
    //     0xbf5c9c: str             x16, [SP, #-8]!
    // 0xbf5ca0: r0 = lerp()
    //     0xbf5ca0: bl              #0xbf6cb4  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::lerp
    // 0xbf5ca4: add             SP, SP, #0x18
    // 0xbf5ca8: stur            x0, [fp, #-0x20]
    // 0xbf5cac: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5cb0: ldur            x16, [fp, #-8]
    // 0xbf5cb4: SaveReg r16
    //     0xbf5cb4: str             x16, [SP, #-8]!
    // 0xbf5cb8: r0 = lerp()
    //     0xbf5cb8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5cbc: add             SP, SP, #0x18
    // 0xbf5cc0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5cc4: ldur            x16, [fp, #-8]
    // 0xbf5cc8: SaveReg r16
    //     0xbf5cc8: str             x16, [SP, #-8]!
    // 0xbf5ccc: r0 = lerp()
    //     0xbf5ccc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5cd0: add             SP, SP, #0x18
    // 0xbf5cd4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5cd8: ldur            x16, [fp, #-8]
    // 0xbf5cdc: SaveReg r16
    //     0xbf5cdc: str             x16, [SP, #-8]!
    // 0xbf5ce0: r0 = lerp()
    //     0xbf5ce0: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5ce4: add             SP, SP, #0x18
    // 0xbf5ce8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5cec: ldur            x16, [fp, #-8]
    // 0xbf5cf0: SaveReg r16
    //     0xbf5cf0: str             x16, [SP, #-8]!
    // 0xbf5cf4: r0 = lerp()
    //     0xbf5cf4: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5cf8: add             SP, SP, #0x18
    // 0xbf5cfc: r0 = BottomNavigationBarThemeData()
    //     0xbf5cfc: bl              #0xbf5d3c  ; AllocateBottomNavigationBarThemeDataStub -> BottomNavigationBarThemeData (size=0x40)
    // 0xbf5d00: ldur            x1, [fp, #-0x10]
    // 0xbf5d04: StoreField: r0->field_b = r1
    //     0xbf5d04: stur            w1, [x0, #0xb]
    // 0xbf5d08: ldur            x1, [fp, #-0x18]
    // 0xbf5d0c: StoreField: r0->field_f = r1
    //     0xbf5d0c: stur            w1, [x0, #0xf]
    // 0xbf5d10: ldur            x1, [fp, #-0x20]
    // 0xbf5d14: StoreField: r0->field_13 = r1
    //     0xbf5d14: stur            w1, [x0, #0x13]
    // 0xbf5d18: LeaveFrame
    //     0xbf5d18: mov             SP, fp
    //     0xbf5d1c: ldp             fp, lr, [SP], #0x10
    // 0xbf5d20: ret
    //     0xbf5d20: ret             
    // 0xbf5d24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5d24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5d28: b               #0xbf5bd4
    // 0xbf5d2c: SaveReg d0
    //     0xbf5d2c: str             q0, [SP, #-0x10]!
    // 0xbf5d30: r0 = AllocateDouble()
    //     0xbf5d30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf5d34: RestoreReg d0
    //     0xbf5d34: ldr             q0, [SP], #0x10
    // 0xbf5d38: b               #0xbf5bfc
  }
  _ ==(/* No info */) {
    // ** addr: 0xc837bc, size: 0x1a4
    // 0xc837bc: EnterFrame
    //     0xc837bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc837c0: mov             fp, SP
    // 0xc837c4: CheckStackOverflow
    //     0xc837c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc837c8: cmp             SP, x16
    //     0xc837cc: b.ls            #0xc83958
    // 0xc837d0: ldr             x1, [fp, #0x10]
    // 0xc837d4: cmp             w1, NULL
    // 0xc837d8: b.ne            #0xc837ec
    // 0xc837dc: r0 = false
    //     0xc837dc: add             x0, NULL, #0x30  ; false
    // 0xc837e0: LeaveFrame
    //     0xc837e0: mov             SP, fp
    //     0xc837e4: ldp             fp, lr, [SP], #0x10
    // 0xc837e8: ret
    //     0xc837e8: ret             
    // 0xc837ec: ldr             x2, [fp, #0x18]
    // 0xc837f0: cmp             w2, w1
    // 0xc837f4: b.ne            #0xc83808
    // 0xc837f8: r0 = true
    //     0xc837f8: add             x0, NULL, #0x20  ; true
    // 0xc837fc: LeaveFrame
    //     0xc837fc: mov             SP, fp
    //     0xc83800: ldp             fp, lr, [SP], #0x10
    // 0xc83804: ret
    //     0xc83804: ret             
    // 0xc83808: r0 = 59
    //     0xc83808: mov             x0, #0x3b
    // 0xc8380c: branchIfSmi(r1, 0xc83818)
    //     0xc8380c: tbz             w1, #0, #0xc83818
    // 0xc83810: r0 = LoadClassIdInstr(r1)
    //     0xc83810: ldur            x0, [x1, #-1]
    //     0xc83814: ubfx            x0, x0, #0xc, #0x14
    // 0xc83818: SaveReg r1
    //     0xc83818: str             x1, [SP, #-8]!
    // 0xc8381c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8381c: mov             x17, #0x57c5
    //     0xc83820: add             lr, x0, x17
    //     0xc83824: ldr             lr, [x21, lr, lsl #3]
    //     0xc83828: blr             lr
    // 0xc8382c: add             SP, SP, #8
    // 0xc83830: r1 = LoadClassIdInstr(r0)
    //     0xc83830: ldur            x1, [x0, #-1]
    //     0xc83834: ubfx            x1, x1, #0xc, #0x14
    // 0xc83838: r16 = BottomNavigationBarThemeData
    //     0xc83838: add             x16, PP, #0xe, lsl #12  ; [pp+0xe498] Type: BottomNavigationBarThemeData
    //     0xc8383c: ldr             x16, [x16, #0x498]
    // 0xc83840: stp             x16, x0, [SP, #-0x10]!
    // 0xc83844: mov             x0, x1
    // 0xc83848: mov             lr, x0
    // 0xc8384c: ldr             lr, [x21, lr, lsl #3]
    // 0xc83850: blr             lr
    // 0xc83854: add             SP, SP, #0x10
    // 0xc83858: tbz             w0, #4, #0xc8386c
    // 0xc8385c: r0 = false
    //     0xc8385c: add             x0, NULL, #0x30  ; false
    // 0xc83860: LeaveFrame
    //     0xc83860: mov             SP, fp
    //     0xc83864: ldp             fp, lr, [SP], #0x10
    // 0xc83868: ret
    //     0xc83868: ret             
    // 0xc8386c: ldr             x1, [fp, #0x10]
    // 0xc83870: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc83870: mov             x0, #0x76
    //     0xc83874: tbz             w1, #0, #0xc83884
    //     0xc83878: ldur            x0, [x1, #-1]
    //     0xc8387c: ubfx            x0, x0, #0xc, #0x14
    //     0xc83880: lsl             x0, x0, #1
    // 0xc83884: r17 = 5674
    //     0xc83884: mov             x17, #0x162a
    // 0xc83888: cmp             w0, w17
    // 0xc8388c: b.ne            #0xc83948
    // 0xc83890: ldr             x2, [fp, #0x18]
    // 0xc83894: LoadField: r0 = r1->field_b
    //     0xc83894: ldur            w0, [x1, #0xb]
    // 0xc83898: DecompressPointer r0
    //     0xc83898: add             x0, x0, HEAP, lsl #32
    // 0xc8389c: LoadField: r3 = r2->field_b
    //     0xc8389c: ldur            w3, [x2, #0xb]
    // 0xc838a0: DecompressPointer r3
    //     0xc838a0: add             x3, x3, HEAP, lsl #32
    // 0xc838a4: r4 = LoadClassIdInstr(r0)
    //     0xc838a4: ldur            x4, [x0, #-1]
    //     0xc838a8: ubfx            x4, x4, #0xc, #0x14
    // 0xc838ac: stp             x3, x0, [SP, #-0x10]!
    // 0xc838b0: mov             x0, x4
    // 0xc838b4: mov             lr, x0
    // 0xc838b8: ldr             lr, [x21, lr, lsl #3]
    // 0xc838bc: blr             lr
    // 0xc838c0: add             SP, SP, #0x10
    // 0xc838c4: tbnz            w0, #4, #0xc83948
    // 0xc838c8: ldr             x2, [fp, #0x18]
    // 0xc838cc: ldr             x1, [fp, #0x10]
    // 0xc838d0: LoadField: r0 = r1->field_f
    //     0xc838d0: ldur            w0, [x1, #0xf]
    // 0xc838d4: DecompressPointer r0
    //     0xc838d4: add             x0, x0, HEAP, lsl #32
    // 0xc838d8: LoadField: r3 = r2->field_f
    //     0xc838d8: ldur            w3, [x2, #0xf]
    // 0xc838dc: DecompressPointer r3
    //     0xc838dc: add             x3, x3, HEAP, lsl #32
    // 0xc838e0: r4 = LoadClassIdInstr(r0)
    //     0xc838e0: ldur            x4, [x0, #-1]
    //     0xc838e4: ubfx            x4, x4, #0xc, #0x14
    // 0xc838e8: stp             x3, x0, [SP, #-0x10]!
    // 0xc838ec: mov             x0, x4
    // 0xc838f0: mov             lr, x0
    // 0xc838f4: ldr             lr, [x21, lr, lsl #3]
    // 0xc838f8: blr             lr
    // 0xc838fc: add             SP, SP, #0x10
    // 0xc83900: tbnz            w0, #4, #0xc83948
    // 0xc83904: ldr             x1, [fp, #0x18]
    // 0xc83908: ldr             x0, [fp, #0x10]
    // 0xc8390c: LoadField: r2 = r0->field_13
    //     0xc8390c: ldur            w2, [x0, #0x13]
    // 0xc83910: DecompressPointer r2
    //     0xc83910: add             x2, x2, HEAP, lsl #32
    // 0xc83914: LoadField: r0 = r1->field_13
    //     0xc83914: ldur            w0, [x1, #0x13]
    // 0xc83918: DecompressPointer r0
    //     0xc83918: add             x0, x0, HEAP, lsl #32
    // 0xc8391c: r1 = LoadClassIdInstr(r2)
    //     0xc8391c: ldur            x1, [x2, #-1]
    //     0xc83920: ubfx            x1, x1, #0xc, #0x14
    // 0xc83924: stp             x0, x2, [SP, #-0x10]!
    // 0xc83928: mov             x0, x1
    // 0xc8392c: mov             lr, x0
    // 0xc83930: ldr             lr, [x21, lr, lsl #3]
    // 0xc83934: blr             lr
    // 0xc83938: add             SP, SP, #0x10
    // 0xc8393c: tbnz            w0, #4, #0xc83948
    // 0xc83940: r0 = true
    //     0xc83940: add             x0, NULL, #0x20  ; true
    // 0xc83944: b               #0xc8394c
    // 0xc83948: r0 = false
    //     0xc83948: add             x0, NULL, #0x30  ; false
    // 0xc8394c: LeaveFrame
    //     0xc8394c: mov             SP, fp
    //     0xc83950: ldp             fp, lr, [SP], #0x10
    // 0xc83954: ret
    //     0xc83954: ret             
    // 0xc83958: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc83958: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8395c: b               #0xc837d0
  }
}

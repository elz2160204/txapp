// lib: , url: package:flutter/src/material/checkbox.dart

// class id: 1049203, size: 0x8
class :: {
}

// class id: 2817, size: 0x34, field offset: 0x2c
class _CheckboxDefaultsM3 extends CheckboxThemeData {

  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x8513d8, size: 0x198
    // 0x8513d8: EnterFrame
    //     0x8513d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8513dc: mov             fp, SP
    // 0x8513e0: AllocStack(0x8)
    //     0x8513e0: sub             SP, SP, #8
    // 0x8513e4: SetupParameters()
    //     0x8513e4: ldr             x0, [fp, #0x18]
    //     0x8513e8: ldur            w1, [x0, #0x17]
    //     0x8513ec: add             x1, x1, HEAP, lsl #32
    //     0x8513f0: stur            x1, [fp, #-8]
    // 0x8513f4: CheckStackOverflow
    //     0x8513f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8513f8: cmp             SP, x16
    //     0x8513fc: b.ls            #0x851568
    // 0x851400: ldr             x2, [fp, #0x10]
    // 0x851404: r0 = LoadClassIdInstr(r2)
    //     0x851404: ldur            x0, [x2, #-1]
    //     0x851408: ubfx            x0, x0, #0xc, #0x14
    // 0x85140c: r16 = Instance_MaterialState
    //     0x85140c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x851410: ldr             x16, [x16, #0x2a0]
    // 0x851414: stp             x16, x2, [SP, #-0x10]!
    // 0x851418: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851418: mov             x17, #0xc98a
    //     0x85141c: add             lr, x0, x17
    //     0x851420: ldr             lr, [x21, lr, lsl #3]
    //     0x851424: blr             lr
    // 0x851428: add             SP, SP, #0x10
    // 0x85142c: tbnz            w0, #4, #0x85149c
    // 0x851430: ldr             x1, [fp, #0x10]
    // 0x851434: r0 = LoadClassIdInstr(r1)
    //     0x851434: ldur            x0, [x1, #-1]
    //     0x851438: ubfx            x0, x0, #0xc, #0x14
    // 0x85143c: r16 = Instance_MaterialState
    //     0x85143c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x851440: ldr             x16, [x16, #0xf70]
    // 0x851444: stp             x16, x1, [SP, #-0x10]!
    // 0x851448: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851448: mov             x17, #0xc98a
    //     0x85144c: add             lr, x0, x17
    //     0x851450: ldr             lr, [x21, lr, lsl #3]
    //     0x851454: blr             lr
    // 0x851458: add             SP, SP, #0x10
    // 0x85145c: tbnz            w0, #4, #0x851488
    // 0x851460: ldur            x2, [fp, #-8]
    // 0x851464: LoadField: r0 = r2->field_f
    //     0x851464: ldur            w0, [x2, #0xf]
    // 0x851468: DecompressPointer r0
    //     0x851468: add             x0, x0, HEAP, lsl #32
    // 0x85146c: LoadField: r1 = r0->field_2f
    //     0x85146c: ldur            w1, [x0, #0x2f]
    // 0x851470: DecompressPointer r1
    //     0x851470: add             x1, x1, HEAP, lsl #32
    // 0x851474: LoadField: r0 = r1->field_53
    //     0x851474: ldur            w0, [x1, #0x53]
    // 0x851478: DecompressPointer r0
    //     0x851478: add             x0, x0, HEAP, lsl #32
    // 0x85147c: LeaveFrame
    //     0x85147c: mov             SP, fp
    //     0x851480: ldp             fp, lr, [SP], #0x10
    // 0x851484: ret
    //     0x851484: ret             
    // 0x851488: r0 = Instance_Color
    //     0x851488: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x85148c: ldr             x0, [x0, #0xc08]
    // 0x851490: LeaveFrame
    //     0x851490: mov             SP, fp
    //     0x851494: ldp             fp, lr, [SP], #0x10
    // 0x851498: ret
    //     0x851498: ret             
    // 0x85149c: ldr             x1, [fp, #0x10]
    // 0x8514a0: ldur            x2, [fp, #-8]
    // 0x8514a4: r0 = LoadClassIdInstr(r1)
    //     0x8514a4: ldur            x0, [x1, #-1]
    //     0x8514a8: ubfx            x0, x0, #0xc, #0x14
    // 0x8514ac: r16 = Instance_MaterialState
    //     0x8514ac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x8514b0: ldr             x16, [x16, #0xf70]
    // 0x8514b4: stp             x16, x1, [SP, #-0x10]!
    // 0x8514b8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8514b8: mov             x17, #0xc98a
    //     0x8514bc: add             lr, x0, x17
    //     0x8514c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8514c4: blr             lr
    // 0x8514c8: add             SP, SP, #0x10
    // 0x8514cc: tbnz            w0, #4, #0x851554
    // 0x8514d0: ldr             x0, [fp, #0x10]
    // 0x8514d4: r1 = LoadClassIdInstr(r0)
    //     0x8514d4: ldur            x1, [x0, #-1]
    //     0x8514d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8514dc: r16 = Instance_MaterialState
    //     0x8514dc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!MaterialState@b654b1
    //     0x8514e0: ldr             x16, [x16, #0x298]
    // 0x8514e4: stp             x16, x0, [SP, #-0x10]!
    // 0x8514e8: mov             x0, x1
    // 0x8514ec: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8514ec: mov             x17, #0xc98a
    //     0x8514f0: add             lr, x0, x17
    //     0x8514f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8514f8: blr             lr
    // 0x8514fc: add             SP, SP, #0x10
    // 0x851500: tbnz            w0, #4, #0x85152c
    // 0x851504: ldur            x1, [fp, #-8]
    // 0x851508: LoadField: r2 = r1->field_f
    //     0x851508: ldur            w2, [x1, #0xf]
    // 0x85150c: DecompressPointer r2
    //     0x85150c: add             x2, x2, HEAP, lsl #32
    // 0x851510: LoadField: r3 = r2->field_2f
    //     0x851510: ldur            w3, [x2, #0x2f]
    // 0x851514: DecompressPointer r3
    //     0x851514: add             x3, x3, HEAP, lsl #32
    // 0x851518: LoadField: r0 = r3->field_3f
    //     0x851518: ldur            w0, [x3, #0x3f]
    // 0x85151c: DecompressPointer r0
    //     0x85151c: add             x0, x0, HEAP, lsl #32
    // 0x851520: LeaveFrame
    //     0x851520: mov             SP, fp
    //     0x851524: ldp             fp, lr, [SP], #0x10
    // 0x851528: ret
    //     0x851528: ret             
    // 0x85152c: ldur            x1, [fp, #-8]
    // 0x851530: LoadField: r2 = r1->field_f
    //     0x851530: ldur            w2, [x1, #0xf]
    // 0x851534: DecompressPointer r2
    //     0x851534: add             x2, x2, HEAP, lsl #32
    // 0x851538: LoadField: r1 = r2->field_2f
    //     0x851538: ldur            w1, [x2, #0x2f]
    // 0x85153c: DecompressPointer r1
    //     0x85153c: add             x1, x1, HEAP, lsl #32
    // 0x851540: LoadField: r0 = r1->field_f
    //     0x851540: ldur            w0, [x1, #0xf]
    // 0x851544: DecompressPointer r0
    //     0x851544: add             x0, x0, HEAP, lsl #32
    // 0x851548: LeaveFrame
    //     0x851548: mov             SP, fp
    //     0x85154c: ldp             fp, lr, [SP], #0x10
    // 0x851550: ret
    //     0x851550: ret             
    // 0x851554: r0 = Instance_Color
    //     0x851554: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x851558: ldr             x0, [x0, #0xc08]
    // 0x85155c: LeaveFrame
    //     0x85155c: mov             SP, fp
    //     0x851560: ldp             fp, lr, [SP], #0x10
    // 0x851564: ret
    //     0x851564: ret             
    // 0x851568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851568: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85156c: b               #0x851400
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x85171c, size: 0x514
    // 0x85171c: EnterFrame
    //     0x85171c: stp             fp, lr, [SP, #-0x10]!
    //     0x851720: mov             fp, SP
    // 0x851724: AllocStack(0x8)
    //     0x851724: sub             SP, SP, #8
    // 0x851728: SetupParameters()
    //     0x851728: ldr             x0, [fp, #0x18]
    //     0x85172c: ldur            w1, [x0, #0x17]
    //     0x851730: add             x1, x1, HEAP, lsl #32
    //     0x851734: stur            x1, [fp, #-8]
    // 0x851738: CheckStackOverflow
    //     0x851738: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85173c: cmp             SP, x16
    //     0x851740: b.ls            #0x851c28
    // 0x851744: ldr             x2, [fp, #0x10]
    // 0x851748: r0 = LoadClassIdInstr(r2)
    //     0x851748: ldur            x0, [x2, #-1]
    //     0x85174c: ubfx            x0, x0, #0xc, #0x14
    // 0x851750: r16 = Instance_MaterialState
    //     0x851750: add             x16, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!MaterialState@b654b1
    //     0x851754: ldr             x16, [x16, #0x298]
    // 0x851758: stp             x16, x2, [SP, #-0x10]!
    // 0x85175c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x85175c: mov             x17, #0xc98a
    //     0x851760: add             lr, x0, x17
    //     0x851764: ldr             lr, [x21, lr, lsl #3]
    //     0x851768: blr             lr
    // 0x85176c: add             SP, SP, #0x10
    // 0x851770: tbnz            w0, #4, #0x8518ec
    // 0x851774: ldr             x1, [fp, #0x10]
    // 0x851778: r0 = LoadClassIdInstr(r1)
    //     0x851778: ldur            x0, [x1, #-1]
    //     0x85177c: ubfx            x0, x0, #0xc, #0x14
    // 0x851780: r16 = Instance_MaterialState
    //     0x851780: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x851784: ldr             x16, [x16, #0xf90]
    // 0x851788: stp             x16, x1, [SP, #-0x10]!
    // 0x85178c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x85178c: mov             x17, #0xc98a
    //     0x851790: add             lr, x0, x17
    //     0x851794: ldr             lr, [x21, lr, lsl #3]
    //     0x851798: blr             lr
    // 0x85179c: add             SP, SP, #0x10
    // 0x8517a0: tbnz            w0, #4, #0x8517e4
    // 0x8517a4: ldur            x1, [fp, #-8]
    // 0x8517a8: d0 = 0.120000
    //     0x8517a8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8517ac: ldr             d0, [x17, #0xf48]
    // 0x8517b0: LoadField: r0 = r1->field_f
    //     0x8517b0: ldur            w0, [x1, #0xf]
    // 0x8517b4: DecompressPointer r0
    //     0x8517b4: add             x0, x0, HEAP, lsl #32
    // 0x8517b8: LoadField: r1 = r0->field_2f
    //     0x8517b8: ldur            w1, [x0, #0x2f]
    // 0x8517bc: DecompressPointer r1
    //     0x8517bc: add             x1, x1, HEAP, lsl #32
    // 0x8517c0: LoadField: r0 = r1->field_3b
    //     0x8517c0: ldur            w0, [x1, #0x3b]
    // 0x8517c4: DecompressPointer r0
    //     0x8517c4: add             x0, x0, HEAP, lsl #32
    // 0x8517c8: SaveReg r0
    //     0x8517c8: str             x0, [SP, #-8]!
    // 0x8517cc: SaveReg d0
    //     0x8517cc: str             d0, [SP, #-8]!
    // 0x8517d0: r0 = withOpacity()
    //     0x8517d0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8517d4: add             SP, SP, #0x10
    // 0x8517d8: LeaveFrame
    //     0x8517d8: mov             SP, fp
    //     0x8517dc: ldp             fp, lr, [SP], #0x10
    // 0x8517e0: ret
    //     0x8517e0: ret             
    // 0x8517e4: ldr             x2, [fp, #0x10]
    // 0x8517e8: ldur            x1, [fp, #-8]
    // 0x8517ec: d0 = 0.120000
    //     0x8517ec: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8517f0: ldr             d0, [x17, #0xf48]
    // 0x8517f4: r0 = LoadClassIdInstr(r2)
    //     0x8517f4: ldur            x0, [x2, #-1]
    //     0x8517f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8517fc: r16 = Instance_MaterialState
    //     0x8517fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x851800: ldr             x16, [x16, #0xf78]
    // 0x851804: stp             x16, x2, [SP, #-0x10]!
    // 0x851808: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851808: mov             x17, #0xc98a
    //     0x85180c: add             lr, x0, x17
    //     0x851810: ldr             lr, [x21, lr, lsl #3]
    //     0x851814: blr             lr
    // 0x851818: add             SP, SP, #0x10
    // 0x85181c: tbnz            w0, #4, #0x851860
    // 0x851820: ldur            x1, [fp, #-8]
    // 0x851824: d0 = 0.080000
    //     0x851824: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x851828: ldr             d0, [x17, #0xf80]
    // 0x85182c: LoadField: r0 = r1->field_f
    //     0x85182c: ldur            w0, [x1, #0xf]
    // 0x851830: DecompressPointer r0
    //     0x851830: add             x0, x0, HEAP, lsl #32
    // 0x851834: LoadField: r1 = r0->field_2f
    //     0x851834: ldur            w1, [x0, #0x2f]
    // 0x851838: DecompressPointer r1
    //     0x851838: add             x1, x1, HEAP, lsl #32
    // 0x85183c: LoadField: r0 = r1->field_3b
    //     0x85183c: ldur            w0, [x1, #0x3b]
    // 0x851840: DecompressPointer r0
    //     0x851840: add             x0, x0, HEAP, lsl #32
    // 0x851844: SaveReg r0
    //     0x851844: str             x0, [SP, #-8]!
    // 0x851848: SaveReg d0
    //     0x851848: str             d0, [SP, #-8]!
    // 0x85184c: r0 = withOpacity()
    //     0x85184c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851850: add             SP, SP, #0x10
    // 0x851854: LeaveFrame
    //     0x851854: mov             SP, fp
    //     0x851858: ldp             fp, lr, [SP], #0x10
    // 0x85185c: ret
    //     0x85185c: ret             
    // 0x851860: ldr             x2, [fp, #0x10]
    // 0x851864: ldur            x1, [fp, #-8]
    // 0x851868: d0 = 0.080000
    //     0x851868: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x85186c: ldr             d0, [x17, #0xf80]
    // 0x851870: r0 = LoadClassIdInstr(r2)
    //     0x851870: ldur            x0, [x2, #-1]
    //     0x851874: ubfx            x0, x0, #0xc, #0x14
    // 0x851878: r16 = Instance_MaterialState
    //     0x851878: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x85187c: ldr             x16, [x16, #0xf88]
    // 0x851880: stp             x16, x2, [SP, #-0x10]!
    // 0x851884: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851884: mov             x17, #0xc98a
    //     0x851888: add             lr, x0, x17
    //     0x85188c: ldr             lr, [x21, lr, lsl #3]
    //     0x851890: blr             lr
    // 0x851894: add             SP, SP, #0x10
    // 0x851898: tbnz            w0, #4, #0x8518dc
    // 0x85189c: ldur            x1, [fp, #-8]
    // 0x8518a0: d0 = 0.120000
    //     0x8518a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8518a4: ldr             d0, [x17, #0xf48]
    // 0x8518a8: LoadField: r0 = r1->field_f
    //     0x8518a8: ldur            w0, [x1, #0xf]
    // 0x8518ac: DecompressPointer r0
    //     0x8518ac: add             x0, x0, HEAP, lsl #32
    // 0x8518b0: LoadField: r1 = r0->field_2f
    //     0x8518b0: ldur            w1, [x0, #0x2f]
    // 0x8518b4: DecompressPointer r1
    //     0x8518b4: add             x1, x1, HEAP, lsl #32
    // 0x8518b8: LoadField: r0 = r1->field_3b
    //     0x8518b8: ldur            w0, [x1, #0x3b]
    // 0x8518bc: DecompressPointer r0
    //     0x8518bc: add             x0, x0, HEAP, lsl #32
    // 0x8518c0: SaveReg r0
    //     0x8518c0: str             x0, [SP, #-8]!
    // 0x8518c4: SaveReg d0
    //     0x8518c4: str             d0, [SP, #-8]!
    // 0x8518c8: r0 = withOpacity()
    //     0x8518c8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8518cc: add             SP, SP, #0x10
    // 0x8518d0: LeaveFrame
    //     0x8518d0: mov             SP, fp
    //     0x8518d4: ldp             fp, lr, [SP], #0x10
    // 0x8518d8: ret
    //     0x8518d8: ret             
    // 0x8518dc: ldur            x1, [fp, #-8]
    // 0x8518e0: d0 = 0.120000
    //     0x8518e0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8518e4: ldr             d0, [x17, #0xf48]
    // 0x8518e8: b               #0x8518f8
    // 0x8518ec: ldur            x1, [fp, #-8]
    // 0x8518f0: d0 = 0.120000
    //     0x8518f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8518f4: ldr             d0, [x17, #0xf48]
    // 0x8518f8: ldr             x2, [fp, #0x10]
    // 0x8518fc: r0 = LoadClassIdInstr(r2)
    //     0x8518fc: ldur            x0, [x2, #-1]
    //     0x851900: ubfx            x0, x0, #0xc, #0x14
    // 0x851904: r16 = Instance_MaterialState
    //     0x851904: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x851908: ldr             x16, [x16, #0xf70]
    // 0x85190c: stp             x16, x2, [SP, #-0x10]!
    // 0x851910: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851910: mov             x17, #0xc98a
    //     0x851914: add             lr, x0, x17
    //     0x851918: ldr             lr, [x21, lr, lsl #3]
    //     0x85191c: blr             lr
    // 0x851920: add             SP, SP, #0x10
    // 0x851924: tbnz            w0, #4, #0x851a9c
    // 0x851928: ldr             x1, [fp, #0x10]
    // 0x85192c: r0 = LoadClassIdInstr(r1)
    //     0x85192c: ldur            x0, [x1, #-1]
    //     0x851930: ubfx            x0, x0, #0xc, #0x14
    // 0x851934: r16 = Instance_MaterialState
    //     0x851934: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x851938: ldr             x16, [x16, #0xf90]
    // 0x85193c: stp             x16, x1, [SP, #-0x10]!
    // 0x851940: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851940: mov             x17, #0xc98a
    //     0x851944: add             lr, x0, x17
    //     0x851948: ldr             lr, [x21, lr, lsl #3]
    //     0x85194c: blr             lr
    // 0x851950: add             SP, SP, #0x10
    // 0x851954: tbnz            w0, #4, #0x851998
    // 0x851958: ldur            x1, [fp, #-8]
    // 0x85195c: d0 = 0.120000
    //     0x85195c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x851960: ldr             d0, [x17, #0xf48]
    // 0x851964: LoadField: r0 = r1->field_f
    //     0x851964: ldur            w0, [x1, #0xf]
    // 0x851968: DecompressPointer r0
    //     0x851968: add             x0, x0, HEAP, lsl #32
    // 0x85196c: LoadField: r1 = r0->field_2f
    //     0x85196c: ldur            w1, [x0, #0x2f]
    // 0x851970: DecompressPointer r1
    //     0x851970: add             x1, x1, HEAP, lsl #32
    // 0x851974: LoadField: r0 = r1->field_57
    //     0x851974: ldur            w0, [x1, #0x57]
    // 0x851978: DecompressPointer r0
    //     0x851978: add             x0, x0, HEAP, lsl #32
    // 0x85197c: SaveReg r0
    //     0x85197c: str             x0, [SP, #-8]!
    // 0x851980: SaveReg d0
    //     0x851980: str             d0, [SP, #-8]!
    // 0x851984: r0 = withOpacity()
    //     0x851984: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851988: add             SP, SP, #0x10
    // 0x85198c: LeaveFrame
    //     0x85198c: mov             SP, fp
    //     0x851990: ldp             fp, lr, [SP], #0x10
    // 0x851994: ret
    //     0x851994: ret             
    // 0x851998: ldr             x2, [fp, #0x10]
    // 0x85199c: ldur            x1, [fp, #-8]
    // 0x8519a0: d0 = 0.120000
    //     0x8519a0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8519a4: ldr             d0, [x17, #0xf48]
    // 0x8519a8: r0 = LoadClassIdInstr(r2)
    //     0x8519a8: ldur            x0, [x2, #-1]
    //     0x8519ac: ubfx            x0, x0, #0xc, #0x14
    // 0x8519b0: r16 = Instance_MaterialState
    //     0x8519b0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x8519b4: ldr             x16, [x16, #0xf78]
    // 0x8519b8: stp             x16, x2, [SP, #-0x10]!
    // 0x8519bc: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8519bc: mov             x17, #0xc98a
    //     0x8519c0: add             lr, x0, x17
    //     0x8519c4: ldr             lr, [x21, lr, lsl #3]
    //     0x8519c8: blr             lr
    // 0x8519cc: add             SP, SP, #0x10
    // 0x8519d0: tbnz            w0, #4, #0x851a14
    // 0x8519d4: ldur            x1, [fp, #-8]
    // 0x8519d8: d0 = 0.080000
    //     0x8519d8: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x8519dc: ldr             d0, [x17, #0xf80]
    // 0x8519e0: LoadField: r0 = r1->field_f
    //     0x8519e0: ldur            w0, [x1, #0xf]
    // 0x8519e4: DecompressPointer r0
    //     0x8519e4: add             x0, x0, HEAP, lsl #32
    // 0x8519e8: LoadField: r1 = r0->field_2f
    //     0x8519e8: ldur            w1, [x0, #0x2f]
    // 0x8519ec: DecompressPointer r1
    //     0x8519ec: add             x1, x1, HEAP, lsl #32
    // 0x8519f0: LoadField: r0 = r1->field_b
    //     0x8519f0: ldur            w0, [x1, #0xb]
    // 0x8519f4: DecompressPointer r0
    //     0x8519f4: add             x0, x0, HEAP, lsl #32
    // 0x8519f8: SaveReg r0
    //     0x8519f8: str             x0, [SP, #-8]!
    // 0x8519fc: SaveReg d0
    //     0x8519fc: str             d0, [SP, #-8]!
    // 0x851a00: r0 = withOpacity()
    //     0x851a00: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851a04: add             SP, SP, #0x10
    // 0x851a08: LeaveFrame
    //     0x851a08: mov             SP, fp
    //     0x851a0c: ldp             fp, lr, [SP], #0x10
    // 0x851a10: ret
    //     0x851a10: ret             
    // 0x851a14: ldr             x2, [fp, #0x10]
    // 0x851a18: ldur            x1, [fp, #-8]
    // 0x851a1c: r0 = LoadClassIdInstr(r2)
    //     0x851a1c: ldur            x0, [x2, #-1]
    //     0x851a20: ubfx            x0, x0, #0xc, #0x14
    // 0x851a24: r16 = Instance_MaterialState
    //     0x851a24: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x851a28: ldr             x16, [x16, #0xf88]
    // 0x851a2c: stp             x16, x2, [SP, #-0x10]!
    // 0x851a30: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851a30: mov             x17, #0xc98a
    //     0x851a34: add             lr, x0, x17
    //     0x851a38: ldr             lr, [x21, lr, lsl #3]
    //     0x851a3c: blr             lr
    // 0x851a40: add             SP, SP, #0x10
    // 0x851a44: tbnz            w0, #4, #0x851a88
    // 0x851a48: ldur            x1, [fp, #-8]
    // 0x851a4c: d1 = 0.120000
    //     0x851a4c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x851a50: ldr             d1, [x17, #0xf48]
    // 0x851a54: LoadField: r0 = r1->field_f
    //     0x851a54: ldur            w0, [x1, #0xf]
    // 0x851a58: DecompressPointer r0
    //     0x851a58: add             x0, x0, HEAP, lsl #32
    // 0x851a5c: LoadField: r1 = r0->field_2f
    //     0x851a5c: ldur            w1, [x0, #0x2f]
    // 0x851a60: DecompressPointer r1
    //     0x851a60: add             x1, x1, HEAP, lsl #32
    // 0x851a64: LoadField: r0 = r1->field_b
    //     0x851a64: ldur            w0, [x1, #0xb]
    // 0x851a68: DecompressPointer r0
    //     0x851a68: add             x0, x0, HEAP, lsl #32
    // 0x851a6c: SaveReg r0
    //     0x851a6c: str             x0, [SP, #-8]!
    // 0x851a70: SaveReg d1
    //     0x851a70: str             d1, [SP, #-8]!
    // 0x851a74: r0 = withOpacity()
    //     0x851a74: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851a78: add             SP, SP, #0x10
    // 0x851a7c: LeaveFrame
    //     0x851a7c: mov             SP, fp
    //     0x851a80: ldp             fp, lr, [SP], #0x10
    // 0x851a84: ret
    //     0x851a84: ret             
    // 0x851a88: r0 = Instance_Color
    //     0x851a88: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x851a8c: ldr             x0, [x0, #0xc08]
    // 0x851a90: LeaveFrame
    //     0x851a90: mov             SP, fp
    //     0x851a94: ldp             fp, lr, [SP], #0x10
    // 0x851a98: ret
    //     0x851a98: ret             
    // 0x851a9c: ldr             x2, [fp, #0x10]
    // 0x851aa0: ldur            x1, [fp, #-8]
    // 0x851aa4: d1 = 0.120000
    //     0x851aa4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x851aa8: ldr             d1, [x17, #0xf48]
    // 0x851aac: d0 = 0.080000
    //     0x851aac: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x851ab0: ldr             d0, [x17, #0xf80]
    // 0x851ab4: r0 = LoadClassIdInstr(r2)
    //     0x851ab4: ldur            x0, [x2, #-1]
    //     0x851ab8: ubfx            x0, x0, #0xc, #0x14
    // 0x851abc: r16 = Instance_MaterialState
    //     0x851abc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x851ac0: ldr             x16, [x16, #0xf90]
    // 0x851ac4: stp             x16, x2, [SP, #-0x10]!
    // 0x851ac8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851ac8: mov             x17, #0xc98a
    //     0x851acc: add             lr, x0, x17
    //     0x851ad0: ldr             lr, [x21, lr, lsl #3]
    //     0x851ad4: blr             lr
    // 0x851ad8: add             SP, SP, #0x10
    // 0x851adc: tbnz            w0, #4, #0x851b20
    // 0x851ae0: ldur            x1, [fp, #-8]
    // 0x851ae4: d0 = 0.120000
    //     0x851ae4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x851ae8: ldr             d0, [x17, #0xf48]
    // 0x851aec: LoadField: r0 = r1->field_f
    //     0x851aec: ldur            w0, [x1, #0xf]
    // 0x851af0: DecompressPointer r0
    //     0x851af0: add             x0, x0, HEAP, lsl #32
    // 0x851af4: LoadField: r1 = r0->field_2f
    //     0x851af4: ldur            w1, [x0, #0x2f]
    // 0x851af8: DecompressPointer r1
    //     0x851af8: add             x1, x1, HEAP, lsl #32
    // 0x851afc: LoadField: r0 = r1->field_b
    //     0x851afc: ldur            w0, [x1, #0xb]
    // 0x851b00: DecompressPointer r0
    //     0x851b00: add             x0, x0, HEAP, lsl #32
    // 0x851b04: SaveReg r0
    //     0x851b04: str             x0, [SP, #-8]!
    // 0x851b08: SaveReg d0
    //     0x851b08: str             d0, [SP, #-8]!
    // 0x851b0c: r0 = withOpacity()
    //     0x851b0c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851b10: add             SP, SP, #0x10
    // 0x851b14: LeaveFrame
    //     0x851b14: mov             SP, fp
    //     0x851b18: ldp             fp, lr, [SP], #0x10
    // 0x851b1c: ret
    //     0x851b1c: ret             
    // 0x851b20: ldr             x2, [fp, #0x10]
    // 0x851b24: ldur            x1, [fp, #-8]
    // 0x851b28: d0 = 0.120000
    //     0x851b28: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x851b2c: ldr             d0, [x17, #0xf48]
    // 0x851b30: r0 = LoadClassIdInstr(r2)
    //     0x851b30: ldur            x0, [x2, #-1]
    //     0x851b34: ubfx            x0, x0, #0xc, #0x14
    // 0x851b38: r16 = Instance_MaterialState
    //     0x851b38: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x851b3c: ldr             x16, [x16, #0xf78]
    // 0x851b40: stp             x16, x2, [SP, #-0x10]!
    // 0x851b44: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851b44: mov             x17, #0xc98a
    //     0x851b48: add             lr, x0, x17
    //     0x851b4c: ldr             lr, [x21, lr, lsl #3]
    //     0x851b50: blr             lr
    // 0x851b54: add             SP, SP, #0x10
    // 0x851b58: tbnz            w0, #4, #0x851b9c
    // 0x851b5c: ldur            x1, [fp, #-8]
    // 0x851b60: d0 = 0.080000
    //     0x851b60: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x851b64: ldr             d0, [x17, #0xf80]
    // 0x851b68: LoadField: r0 = r1->field_f
    //     0x851b68: ldur            w0, [x1, #0xf]
    // 0x851b6c: DecompressPointer r0
    //     0x851b6c: add             x0, x0, HEAP, lsl #32
    // 0x851b70: LoadField: r1 = r0->field_2f
    //     0x851b70: ldur            w1, [x0, #0x2f]
    // 0x851b74: DecompressPointer r1
    //     0x851b74: add             x1, x1, HEAP, lsl #32
    // 0x851b78: LoadField: r0 = r1->field_57
    //     0x851b78: ldur            w0, [x1, #0x57]
    // 0x851b7c: DecompressPointer r0
    //     0x851b7c: add             x0, x0, HEAP, lsl #32
    // 0x851b80: SaveReg r0
    //     0x851b80: str             x0, [SP, #-8]!
    // 0x851b84: SaveReg d0
    //     0x851b84: str             d0, [SP, #-8]!
    // 0x851b88: r0 = withOpacity()
    //     0x851b88: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851b8c: add             SP, SP, #0x10
    // 0x851b90: LeaveFrame
    //     0x851b90: mov             SP, fp
    //     0x851b94: ldp             fp, lr, [SP], #0x10
    // 0x851b98: ret
    //     0x851b98: ret             
    // 0x851b9c: ldr             x0, [fp, #0x10]
    // 0x851ba0: ldur            x1, [fp, #-8]
    // 0x851ba4: r2 = LoadClassIdInstr(r0)
    //     0x851ba4: ldur            x2, [x0, #-1]
    //     0x851ba8: ubfx            x2, x2, #0xc, #0x14
    // 0x851bac: r16 = Instance_MaterialState
    //     0x851bac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x851bb0: ldr             x16, [x16, #0xf88]
    // 0x851bb4: stp             x16, x0, [SP, #-0x10]!
    // 0x851bb8: mov             x0, x2
    // 0x851bbc: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851bbc: mov             x17, #0xc98a
    //     0x851bc0: add             lr, x0, x17
    //     0x851bc4: ldr             lr, [x21, lr, lsl #3]
    //     0x851bc8: blr             lr
    // 0x851bcc: add             SP, SP, #0x10
    // 0x851bd0: tbnz            w0, #4, #0x851c14
    // 0x851bd4: ldur            x0, [fp, #-8]
    // 0x851bd8: d0 = 0.120000
    //     0x851bd8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x851bdc: ldr             d0, [x17, #0xf48]
    // 0x851be0: LoadField: r1 = r0->field_f
    //     0x851be0: ldur            w1, [x0, #0xf]
    // 0x851be4: DecompressPointer r1
    //     0x851be4: add             x1, x1, HEAP, lsl #32
    // 0x851be8: LoadField: r0 = r1->field_2f
    //     0x851be8: ldur            w0, [x1, #0x2f]
    // 0x851bec: DecompressPointer r0
    //     0x851bec: add             x0, x0, HEAP, lsl #32
    // 0x851bf0: LoadField: r1 = r0->field_57
    //     0x851bf0: ldur            w1, [x0, #0x57]
    // 0x851bf4: DecompressPointer r1
    //     0x851bf4: add             x1, x1, HEAP, lsl #32
    // 0x851bf8: SaveReg r1
    //     0x851bf8: str             x1, [SP, #-8]!
    // 0x851bfc: SaveReg d0
    //     0x851bfc: str             d0, [SP, #-8]!
    // 0x851c00: r0 = withOpacity()
    //     0x851c00: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851c04: add             SP, SP, #0x10
    // 0x851c08: LeaveFrame
    //     0x851c08: mov             SP, fp
    //     0x851c0c: ldp             fp, lr, [SP], #0x10
    // 0x851c10: ret
    //     0x851c10: ret             
    // 0x851c14: r0 = Instance_Color
    //     0x851c14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x851c18: ldr             x0, [x0, #0xc08]
    // 0x851c1c: LeaveFrame
    //     0x851c1c: mov             SP, fp
    //     0x851c20: ldp             fp, lr, [SP], #0x10
    // 0x851c24: ret
    //     0x851c24: ret             
    // 0x851c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851c28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851c2c: b               #0x851744
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x851d40, size: 0x2b4
    // 0x851d40: EnterFrame
    //     0x851d40: stp             fp, lr, [SP, #-0x10]!
    //     0x851d44: mov             fp, SP
    // 0x851d48: AllocStack(0x8)
    //     0x851d48: sub             SP, SP, #8
    // 0x851d4c: SetupParameters()
    //     0x851d4c: ldr             x0, [fp, #0x18]
    //     0x851d50: ldur            w1, [x0, #0x17]
    //     0x851d54: add             x1, x1, HEAP, lsl #32
    //     0x851d58: stur            x1, [fp, #-8]
    // 0x851d5c: CheckStackOverflow
    //     0x851d5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x851d60: cmp             SP, x16
    //     0x851d64: b.ls            #0x851fec
    // 0x851d68: ldr             x2, [fp, #0x10]
    // 0x851d6c: r0 = LoadClassIdInstr(r2)
    //     0x851d6c: ldur            x0, [x2, #-1]
    //     0x851d70: ubfx            x0, x0, #0xc, #0x14
    // 0x851d74: r16 = Instance_MaterialState
    //     0x851d74: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x851d78: ldr             x16, [x16, #0x2a0]
    // 0x851d7c: stp             x16, x2, [SP, #-0x10]!
    // 0x851d80: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851d80: mov             x17, #0xc98a
    //     0x851d84: add             lr, x0, x17
    //     0x851d88: ldr             lr, [x21, lr, lsl #3]
    //     0x851d8c: blr             lr
    // 0x851d90: add             SP, SP, #0x10
    // 0x851d94: tbnz            w0, #4, #0x851dd8
    // 0x851d98: ldur            x1, [fp, #-8]
    // 0x851d9c: d0 = 0.380000
    //     0x851d9c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0x851da0: ldr             d0, [x17, #0x140]
    // 0x851da4: LoadField: r0 = r1->field_f
    //     0x851da4: ldur            w0, [x1, #0xf]
    // 0x851da8: DecompressPointer r0
    //     0x851da8: add             x0, x0, HEAP, lsl #32
    // 0x851dac: LoadField: r1 = r0->field_2f
    //     0x851dac: ldur            w1, [x0, #0x2f]
    // 0x851db0: DecompressPointer r1
    //     0x851db0: add             x1, x1, HEAP, lsl #32
    // 0x851db4: LoadField: r0 = r1->field_57
    //     0x851db4: ldur            w0, [x1, #0x57]
    // 0x851db8: DecompressPointer r0
    //     0x851db8: add             x0, x0, HEAP, lsl #32
    // 0x851dbc: SaveReg r0
    //     0x851dbc: str             x0, [SP, #-8]!
    // 0x851dc0: SaveReg d0
    //     0x851dc0: str             d0, [SP, #-8]!
    // 0x851dc4: r0 = withOpacity()
    //     0x851dc4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x851dc8: add             SP, SP, #0x10
    // 0x851dcc: LeaveFrame
    //     0x851dcc: mov             SP, fp
    //     0x851dd0: ldp             fp, lr, [SP], #0x10
    // 0x851dd4: ret
    //     0x851dd4: ret             
    // 0x851dd8: ldr             x2, [fp, #0x10]
    // 0x851ddc: ldur            x1, [fp, #-8]
    // 0x851de0: r0 = LoadClassIdInstr(r2)
    //     0x851de0: ldur            x0, [x2, #-1]
    //     0x851de4: ubfx            x0, x0, #0xc, #0x14
    // 0x851de8: r16 = Instance_MaterialState
    //     0x851de8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!MaterialState@b654b1
    //     0x851dec: ldr             x16, [x16, #0x298]
    // 0x851df0: stp             x16, x2, [SP, #-0x10]!
    // 0x851df4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851df4: mov             x17, #0xc98a
    //     0x851df8: add             lr, x0, x17
    //     0x851dfc: ldr             lr, [x21, lr, lsl #3]
    //     0x851e00: blr             lr
    // 0x851e04: add             SP, SP, #0x10
    // 0x851e08: tbnz            w0, #4, #0x851e34
    // 0x851e0c: ldur            x1, [fp, #-8]
    // 0x851e10: LoadField: r0 = r1->field_f
    //     0x851e10: ldur            w0, [x1, #0xf]
    // 0x851e14: DecompressPointer r0
    //     0x851e14: add             x0, x0, HEAP, lsl #32
    // 0x851e18: LoadField: r1 = r0->field_2f
    //     0x851e18: ldur            w1, [x0, #0x2f]
    // 0x851e1c: DecompressPointer r1
    //     0x851e1c: add             x1, x1, HEAP, lsl #32
    // 0x851e20: LoadField: r0 = r1->field_3b
    //     0x851e20: ldur            w0, [x1, #0x3b]
    // 0x851e24: DecompressPointer r0
    //     0x851e24: add             x0, x0, HEAP, lsl #32
    // 0x851e28: LeaveFrame
    //     0x851e28: mov             SP, fp
    //     0x851e2c: ldp             fp, lr, [SP], #0x10
    // 0x851e30: ret
    //     0x851e30: ret             
    // 0x851e34: ldr             x2, [fp, #0x10]
    // 0x851e38: ldur            x1, [fp, #-8]
    // 0x851e3c: r0 = LoadClassIdInstr(r2)
    //     0x851e3c: ldur            x0, [x2, #-1]
    //     0x851e40: ubfx            x0, x0, #0xc, #0x14
    // 0x851e44: r16 = Instance_MaterialState
    //     0x851e44: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x851e48: ldr             x16, [x16, #0xf70]
    // 0x851e4c: stp             x16, x2, [SP, #-0x10]!
    // 0x851e50: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851e50: mov             x17, #0xc98a
    //     0x851e54: add             lr, x0, x17
    //     0x851e58: ldr             lr, [x21, lr, lsl #3]
    //     0x851e5c: blr             lr
    // 0x851e60: add             SP, SP, #0x10
    // 0x851e64: tbnz            w0, #4, #0x851e90
    // 0x851e68: ldur            x1, [fp, #-8]
    // 0x851e6c: LoadField: r0 = r1->field_f
    //     0x851e6c: ldur            w0, [x1, #0xf]
    // 0x851e70: DecompressPointer r0
    //     0x851e70: add             x0, x0, HEAP, lsl #32
    // 0x851e74: LoadField: r1 = r0->field_2f
    //     0x851e74: ldur            w1, [x0, #0x2f]
    // 0x851e78: DecompressPointer r1
    //     0x851e78: add             x1, x1, HEAP, lsl #32
    // 0x851e7c: LoadField: r0 = r1->field_b
    //     0x851e7c: ldur            w0, [x1, #0xb]
    // 0x851e80: DecompressPointer r0
    //     0x851e80: add             x0, x0, HEAP, lsl #32
    // 0x851e84: LeaveFrame
    //     0x851e84: mov             SP, fp
    //     0x851e88: ldp             fp, lr, [SP], #0x10
    // 0x851e8c: ret
    //     0x851e8c: ret             
    // 0x851e90: ldr             x2, [fp, #0x10]
    // 0x851e94: ldur            x1, [fp, #-8]
    // 0x851e98: r0 = LoadClassIdInstr(r2)
    //     0x851e98: ldur            x0, [x2, #-1]
    //     0x851e9c: ubfx            x0, x0, #0xc, #0x14
    // 0x851ea0: r16 = Instance_MaterialState
    //     0x851ea0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x851ea4: ldr             x16, [x16, #0xf90]
    // 0x851ea8: stp             x16, x2, [SP, #-0x10]!
    // 0x851eac: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851eac: mov             x17, #0xc98a
    //     0x851eb0: add             lr, x0, x17
    //     0x851eb4: ldr             lr, [x21, lr, lsl #3]
    //     0x851eb8: blr             lr
    // 0x851ebc: add             SP, SP, #0x10
    // 0x851ec0: tbnz            w0, #4, #0x851eec
    // 0x851ec4: ldur            x1, [fp, #-8]
    // 0x851ec8: LoadField: r0 = r1->field_f
    //     0x851ec8: ldur            w0, [x1, #0xf]
    // 0x851ecc: DecompressPointer r0
    //     0x851ecc: add             x0, x0, HEAP, lsl #32
    // 0x851ed0: LoadField: r1 = r0->field_2f
    //     0x851ed0: ldur            w1, [x0, #0x2f]
    // 0x851ed4: DecompressPointer r1
    //     0x851ed4: add             x1, x1, HEAP, lsl #32
    // 0x851ed8: LoadField: r0 = r1->field_57
    //     0x851ed8: ldur            w0, [x1, #0x57]
    // 0x851edc: DecompressPointer r0
    //     0x851edc: add             x0, x0, HEAP, lsl #32
    // 0x851ee0: LeaveFrame
    //     0x851ee0: mov             SP, fp
    //     0x851ee4: ldp             fp, lr, [SP], #0x10
    // 0x851ee8: ret
    //     0x851ee8: ret             
    // 0x851eec: ldr             x2, [fp, #0x10]
    // 0x851ef0: ldur            x1, [fp, #-8]
    // 0x851ef4: r0 = LoadClassIdInstr(r2)
    //     0x851ef4: ldur            x0, [x2, #-1]
    //     0x851ef8: ubfx            x0, x0, #0xc, #0x14
    // 0x851efc: r16 = Instance_MaterialState
    //     0x851efc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x851f00: ldr             x16, [x16, #0xf78]
    // 0x851f04: stp             x16, x2, [SP, #-0x10]!
    // 0x851f08: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851f08: mov             x17, #0xc98a
    //     0x851f0c: add             lr, x0, x17
    //     0x851f10: ldr             lr, [x21, lr, lsl #3]
    //     0x851f14: blr             lr
    // 0x851f18: add             SP, SP, #0x10
    // 0x851f1c: tbnz            w0, #4, #0x851f48
    // 0x851f20: ldur            x1, [fp, #-8]
    // 0x851f24: LoadField: r0 = r1->field_f
    //     0x851f24: ldur            w0, [x1, #0xf]
    // 0x851f28: DecompressPointer r0
    //     0x851f28: add             x0, x0, HEAP, lsl #32
    // 0x851f2c: LoadField: r1 = r0->field_2f
    //     0x851f2c: ldur            w1, [x0, #0x2f]
    // 0x851f30: DecompressPointer r1
    //     0x851f30: add             x1, x1, HEAP, lsl #32
    // 0x851f34: LoadField: r0 = r1->field_57
    //     0x851f34: ldur            w0, [x1, #0x57]
    // 0x851f38: DecompressPointer r0
    //     0x851f38: add             x0, x0, HEAP, lsl #32
    // 0x851f3c: LeaveFrame
    //     0x851f3c: mov             SP, fp
    //     0x851f40: ldp             fp, lr, [SP], #0x10
    // 0x851f44: ret
    //     0x851f44: ret             
    // 0x851f48: ldr             x0, [fp, #0x10]
    // 0x851f4c: ldur            x1, [fp, #-8]
    // 0x851f50: r2 = LoadClassIdInstr(r0)
    //     0x851f50: ldur            x2, [x0, #-1]
    //     0x851f54: ubfx            x2, x2, #0xc, #0x14
    // 0x851f58: r16 = Instance_MaterialState
    //     0x851f58: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x851f5c: ldr             x16, [x16, #0xf88]
    // 0x851f60: stp             x16, x0, [SP, #-0x10]!
    // 0x851f64: mov             x0, x2
    // 0x851f68: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851f68: mov             x17, #0xc98a
    //     0x851f6c: add             lr, x0, x17
    //     0x851f70: ldr             lr, [x21, lr, lsl #3]
    //     0x851f74: blr             lr
    // 0x851f78: add             SP, SP, #0x10
    // 0x851f7c: tbnz            w0, #4, #0x851fa8
    // 0x851f80: ldur            x1, [fp, #-8]
    // 0x851f84: LoadField: r2 = r1->field_f
    //     0x851f84: ldur            w2, [x1, #0xf]
    // 0x851f88: DecompressPointer r2
    //     0x851f88: add             x2, x2, HEAP, lsl #32
    // 0x851f8c: LoadField: r3 = r2->field_2f
    //     0x851f8c: ldur            w3, [x2, #0x2f]
    // 0x851f90: DecompressPointer r3
    //     0x851f90: add             x3, x3, HEAP, lsl #32
    // 0x851f94: LoadField: r0 = r3->field_57
    //     0x851f94: ldur            w0, [x3, #0x57]
    // 0x851f98: DecompressPointer r0
    //     0x851f98: add             x0, x0, HEAP, lsl #32
    // 0x851f9c: LeaveFrame
    //     0x851f9c: mov             SP, fp
    //     0x851fa0: ldp             fp, lr, [SP], #0x10
    // 0x851fa4: ret
    //     0x851fa4: ret             
    // 0x851fa8: ldur            x1, [fp, #-8]
    // 0x851fac: LoadField: r2 = r1->field_f
    //     0x851fac: ldur            w2, [x1, #0xf]
    // 0x851fb0: DecompressPointer r2
    //     0x851fb0: add             x2, x2, HEAP, lsl #32
    // 0x851fb4: LoadField: r1 = r2->field_2f
    //     0x851fb4: ldur            w1, [x2, #0x2f]
    // 0x851fb8: DecompressPointer r1
    //     0x851fb8: add             x1, x1, HEAP, lsl #32
    // 0x851fbc: LoadField: r2 = r1->field_5f
    //     0x851fbc: ldur            w2, [x1, #0x5f]
    // 0x851fc0: DecompressPointer r2
    //     0x851fc0: add             x2, x2, HEAP, lsl #32
    // 0x851fc4: cmp             w2, NULL
    // 0x851fc8: b.ne            #0x851fdc
    // 0x851fcc: LoadField: r3 = r1->field_57
    //     0x851fcc: ldur            w3, [x1, #0x57]
    // 0x851fd0: DecompressPointer r3
    //     0x851fd0: add             x3, x3, HEAP, lsl #32
    // 0x851fd4: mov             x0, x3
    // 0x851fd8: b               #0x851fe0
    // 0x851fdc: mov             x0, x2
    // 0x851fe0: LeaveFrame
    //     0x851fe0: mov             SP, fp
    //     0x851fe4: ldp             fp, lr, [SP], #0x10
    // 0x851fe8: ret
    //     0x851fe8: ret             
    // 0x851fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851fec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851ff0: b               #0x851d68
  }
}

// class id: 2818, size: 0x34, field offset: 0x2c
class _CheckboxDefaultsM2 extends CheckboxThemeData {

  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x851570, size: 0x1ac
    // 0x851570: EnterFrame
    //     0x851570: stp             fp, lr, [SP, #-0x10]!
    //     0x851574: mov             fp, SP
    // 0x851578: AllocStack(0x10)
    //     0x851578: sub             SP, SP, #0x10
    // 0x85157c: SetupParameters()
    //     0x85157c: ldr             x0, [fp, #0x18]
    //     0x851580: ldur            w1, [x0, #0x17]
    //     0x851584: add             x1, x1, HEAP, lsl #32
    //     0x851588: stur            x1, [fp, #-8]
    // 0x85158c: CheckStackOverflow
    //     0x85158c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x851590: cmp             SP, x16
    //     0x851594: b.ls            #0x851714
    // 0x851598: ldr             x2, [fp, #0x10]
    // 0x85159c: r0 = LoadClassIdInstr(r2)
    //     0x85159c: ldur            x0, [x2, #-1]
    //     0x8515a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8515a4: r16 = Instance_MaterialState
    //     0x8515a4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x8515a8: ldr             x16, [x16, #0xf90]
    // 0x8515ac: stp             x16, x2, [SP, #-0x10]!
    // 0x8515b0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8515b0: mov             x17, #0xc98a
    //     0x8515b4: add             lr, x0, x17
    //     0x8515b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8515bc: blr             lr
    // 0x8515c0: add             SP, SP, #0x10
    // 0x8515c4: tbnz            w0, #4, #0x851644
    // 0x8515c8: ldur            x1, [fp, #-8]
    // 0x8515cc: LoadField: r0 = r1->field_f
    //     0x8515cc: ldur            w0, [x1, #0xf]
    // 0x8515d0: DecompressPointer r0
    //     0x8515d0: add             x0, x0, HEAP, lsl #32
    // 0x8515d4: stur            x0, [fp, #-0x10]
    // 0x8515d8: r1 = 1
    //     0x8515d8: mov             x1, #1
    // 0x8515dc: r0 = AllocateContext()
    //     0x8515dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8515e0: mov             x1, x0
    // 0x8515e4: ldur            x0, [fp, #-0x10]
    // 0x8515e8: StoreField: r1->field_f = r0
    //     0x8515e8: stur            w0, [x1, #0xf]
    // 0x8515ec: mov             x2, x1
    // 0x8515f0: r1 = Function '<anonymous closure>':.
    //     0x8515f0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe400] AnonymousClosure: (0x851c30), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x8515f4: ldr             x1, [x1, #0x400]
    // 0x8515f8: r0 = AllocateClosure()
    //     0x8515f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8515fc: r16 = <Color>
    //     0x8515fc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x851600: ldr             x16, [x16, #0x3f8]
    // 0x851604: stp             x0, x16, [SP, #-0x10]!
    // 0x851608: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x851608: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x85160c: r0 = resolveWith()
    //     0x85160c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x851610: add             SP, SP, #0x10
    // 0x851614: ldr             x16, [fp, #0x10]
    // 0x851618: stp             x16, x0, [SP, #-0x10]!
    // 0x85161c: r0 = build()
    //     0x85161c: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x851620: add             SP, SP, #0x10
    // 0x851624: SaveReg r0
    //     0x851624: str             x0, [SP, #-8]!
    // 0x851628: r0 = 31
    //     0x851628: mov             x0, #0x1f
    // 0x85162c: SaveReg r0
    //     0x85162c: str             x0, [SP, #-8]!
    // 0x851630: r0 = withAlpha()
    //     0x851630: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x851634: add             SP, SP, #0x10
    // 0x851638: LeaveFrame
    //     0x851638: mov             SP, fp
    //     0x85163c: ldp             fp, lr, [SP], #0x10
    // 0x851640: ret
    //     0x851640: ret             
    // 0x851644: ldr             x2, [fp, #0x10]
    // 0x851648: ldur            x1, [fp, #-8]
    // 0x85164c: r0 = LoadClassIdInstr(r2)
    //     0x85164c: ldur            x0, [x2, #-1]
    //     0x851650: ubfx            x0, x0, #0xc, #0x14
    // 0x851654: r16 = Instance_MaterialState
    //     0x851654: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x851658: ldr             x16, [x16, #0xf78]
    // 0x85165c: stp             x16, x2, [SP, #-0x10]!
    // 0x851660: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851660: mov             x17, #0xc98a
    //     0x851664: add             lr, x0, x17
    //     0x851668: ldr             lr, [x21, lr, lsl #3]
    //     0x85166c: blr             lr
    // 0x851670: add             SP, SP, #0x10
    // 0x851674: tbnz            w0, #4, #0x8516a0
    // 0x851678: ldur            x1, [fp, #-8]
    // 0x85167c: LoadField: r0 = r1->field_f
    //     0x85167c: ldur            w0, [x1, #0xf]
    // 0x851680: DecompressPointer r0
    //     0x851680: add             x0, x0, HEAP, lsl #32
    // 0x851684: LoadField: r1 = r0->field_2b
    //     0x851684: ldur            w1, [x0, #0x2b]
    // 0x851688: DecompressPointer r1
    //     0x851688: add             x1, x1, HEAP, lsl #32
    // 0x85168c: LoadField: r0 = r1->field_5b
    //     0x85168c: ldur            w0, [x1, #0x5b]
    // 0x851690: DecompressPointer r0
    //     0x851690: add             x0, x0, HEAP, lsl #32
    // 0x851694: LeaveFrame
    //     0x851694: mov             SP, fp
    //     0x851698: ldp             fp, lr, [SP], #0x10
    // 0x85169c: ret
    //     0x85169c: ret             
    // 0x8516a0: ldr             x0, [fp, #0x10]
    // 0x8516a4: ldur            x1, [fp, #-8]
    // 0x8516a8: r2 = LoadClassIdInstr(r0)
    //     0x8516a8: ldur            x2, [x0, #-1]
    //     0x8516ac: ubfx            x2, x2, #0xc, #0x14
    // 0x8516b0: r16 = Instance_MaterialState
    //     0x8516b0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x8516b4: ldr             x16, [x16, #0xf88]
    // 0x8516b8: stp             x16, x0, [SP, #-0x10]!
    // 0x8516bc: mov             x0, x2
    // 0x8516c0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8516c0: mov             x17, #0xc98a
    //     0x8516c4: add             lr, x0, x17
    //     0x8516c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8516cc: blr             lr
    // 0x8516d0: add             SP, SP, #0x10
    // 0x8516d4: tbnz            w0, #4, #0x851700
    // 0x8516d8: ldur            x1, [fp, #-8]
    // 0x8516dc: LoadField: r2 = r1->field_f
    //     0x8516dc: ldur            w2, [x1, #0xf]
    // 0x8516e0: DecompressPointer r2
    //     0x8516e0: add             x2, x2, HEAP, lsl #32
    // 0x8516e4: LoadField: r1 = r2->field_2b
    //     0x8516e4: ldur            w1, [x2, #0x2b]
    // 0x8516e8: DecompressPointer r1
    //     0x8516e8: add             x1, x1, HEAP, lsl #32
    // 0x8516ec: LoadField: r0 = r1->field_4f
    //     0x8516ec: ldur            w0, [x1, #0x4f]
    // 0x8516f0: DecompressPointer r0
    //     0x8516f0: add             x0, x0, HEAP, lsl #32
    // 0x8516f4: LeaveFrame
    //     0x8516f4: mov             SP, fp
    //     0x8516f8: ldp             fp, lr, [SP], #0x10
    // 0x8516fc: ret
    //     0x8516fc: ret             
    // 0x851700: r0 = Instance_Color
    //     0x851700: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x851704: ldr             x0, [x0, #0xc08]
    // 0x851708: LeaveFrame
    //     0x851708: mov             SP, fp
    //     0x85170c: ldp             fp, lr, [SP], #0x10
    // 0x851710: ret
    //     0x851710: ret             
    // 0x851714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851714: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851718: b               #0x851598
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x851c30, size: 0x110
    // 0x851c30: EnterFrame
    //     0x851c30: stp             fp, lr, [SP, #-0x10]!
    //     0x851c34: mov             fp, SP
    // 0x851c38: AllocStack(0x8)
    //     0x851c38: sub             SP, SP, #8
    // 0x851c3c: SetupParameters()
    //     0x851c3c: ldr             x0, [fp, #0x18]
    //     0x851c40: ldur            w1, [x0, #0x17]
    //     0x851c44: add             x1, x1, HEAP, lsl #32
    //     0x851c48: stur            x1, [fp, #-8]
    // 0x851c4c: CheckStackOverflow
    //     0x851c4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x851c50: cmp             SP, x16
    //     0x851c54: b.ls            #0x851d38
    // 0x851c58: ldr             x2, [fp, #0x10]
    // 0x851c5c: r0 = LoadClassIdInstr(r2)
    //     0x851c5c: ldur            x0, [x2, #-1]
    //     0x851c60: ubfx            x0, x0, #0xc, #0x14
    // 0x851c64: r16 = Instance_MaterialState
    //     0x851c64: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x851c68: ldr             x16, [x16, #0x2a0]
    // 0x851c6c: stp             x16, x2, [SP, #-0x10]!
    // 0x851c70: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851c70: mov             x17, #0xc98a
    //     0x851c74: add             lr, x0, x17
    //     0x851c78: ldr             lr, [x21, lr, lsl #3]
    //     0x851c7c: blr             lr
    // 0x851c80: add             SP, SP, #0x10
    // 0x851c84: tbnz            w0, #4, #0x851cb0
    // 0x851c88: ldur            x1, [fp, #-8]
    // 0x851c8c: LoadField: r0 = r1->field_f
    //     0x851c8c: ldur            w0, [x1, #0xf]
    // 0x851c90: DecompressPointer r0
    //     0x851c90: add             x0, x0, HEAP, lsl #32
    // 0x851c94: LoadField: r1 = r0->field_2b
    //     0x851c94: ldur            w1, [x0, #0x2b]
    // 0x851c98: DecompressPointer r1
    //     0x851c98: add             x1, x1, HEAP, lsl #32
    // 0x851c9c: LoadField: r0 = r1->field_47
    //     0x851c9c: ldur            w0, [x1, #0x47]
    // 0x851ca0: DecompressPointer r0
    //     0x851ca0: add             x0, x0, HEAP, lsl #32
    // 0x851ca4: LeaveFrame
    //     0x851ca4: mov             SP, fp
    //     0x851ca8: ldp             fp, lr, [SP], #0x10
    // 0x851cac: ret
    //     0x851cac: ret             
    // 0x851cb0: ldr             x0, [fp, #0x10]
    // 0x851cb4: ldur            x1, [fp, #-8]
    // 0x851cb8: r2 = LoadClassIdInstr(r0)
    //     0x851cb8: ldur            x2, [x0, #-1]
    //     0x851cbc: ubfx            x2, x2, #0xc, #0x14
    // 0x851cc0: r16 = Instance_MaterialState
    //     0x851cc0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x851cc4: ldr             x16, [x16, #0xf70]
    // 0x851cc8: stp             x16, x0, [SP, #-0x10]!
    // 0x851ccc: mov             x0, x2
    // 0x851cd0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x851cd0: mov             x17, #0xc98a
    //     0x851cd4: add             lr, x0, x17
    //     0x851cd8: ldr             lr, [x21, lr, lsl #3]
    //     0x851cdc: blr             lr
    // 0x851ce0: add             SP, SP, #0x10
    // 0x851ce4: tbnz            w0, #4, #0x851d10
    // 0x851ce8: ldur            x1, [fp, #-8]
    // 0x851cec: LoadField: r2 = r1->field_f
    //     0x851cec: ldur            w2, [x1, #0xf]
    // 0x851cf0: DecompressPointer r2
    //     0x851cf0: add             x2, x2, HEAP, lsl #32
    // 0x851cf4: LoadField: r3 = r2->field_2f
    //     0x851cf4: ldur            w3, [x2, #0x2f]
    // 0x851cf8: DecompressPointer r3
    //     0x851cf8: add             x3, x3, HEAP, lsl #32
    // 0x851cfc: LoadField: r0 = r3->field_1b
    //     0x851cfc: ldur            w0, [x3, #0x1b]
    // 0x851d00: DecompressPointer r0
    //     0x851d00: add             x0, x0, HEAP, lsl #32
    // 0x851d04: LeaveFrame
    //     0x851d04: mov             SP, fp
    //     0x851d08: ldp             fp, lr, [SP], #0x10
    // 0x851d0c: ret
    //     0x851d0c: ret             
    // 0x851d10: ldur            x1, [fp, #-8]
    // 0x851d14: LoadField: r2 = r1->field_f
    //     0x851d14: ldur            w2, [x1, #0xf]
    // 0x851d18: DecompressPointer r2
    //     0x851d18: add             x2, x2, HEAP, lsl #32
    // 0x851d1c: LoadField: r1 = r2->field_2b
    //     0x851d1c: ldur            w1, [x2, #0x2b]
    // 0x851d20: DecompressPointer r1
    //     0x851d20: add             x1, x1, HEAP, lsl #32
    // 0x851d24: LoadField: r0 = r1->field_83
    //     0x851d24: ldur            w0, [x1, #0x83]
    // 0x851d28: DecompressPointer r0
    //     0x851d28: add             x0, x0, HEAP, lsl #32
    // 0x851d2c: LeaveFrame
    //     0x851d2c: mov             SP, fp
    //     0x851d30: ldp             fp, lr, [SP], #0x10
    // 0x851d34: ret
    //     0x851d34: ret             
    // 0x851d38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851d38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851d3c: b               #0x851c58
  }
}

// class id: 3330, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CheckboxState&State&TickerProviderStateMixin extends State<Checkbox>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x616730, size: 0x178
    // 0x616730: EnterFrame
    //     0x616730: stp             fp, lr, [SP, #-0x10]!
    //     0x616734: mov             fp, SP
    // 0x616738: AllocStack(0x10)
    //     0x616738: sub             SP, SP, #0x10
    // 0x61673c: CheckStackOverflow
    //     0x61673c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616740: cmp             SP, x16
    //     0x616744: b.ls            #0x616898
    // 0x616748: ldr             x0, [fp, #0x18]
    // 0x61674c: LoadField: r1 = r0->field_17
    //     0x61674c: ldur            w1, [x0, #0x17]
    // 0x616750: DecompressPointer r1
    //     0x616750: add             x1, x1, HEAP, lsl #32
    // 0x616754: cmp             w1, NULL
    // 0x616758: b.ne            #0x616768
    // 0x61675c: SaveReg r0
    //     0x61675c: str             x0, [SP, #-8]!
    // 0x616760: r0 = _updateTickerModeNotifier()
    //     0x616760: bl              #0x6168cc  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x616764: add             SP, SP, #8
    // 0x616768: ldr             x0, [fp, #0x18]
    // 0x61676c: LoadField: r1 = r0->field_13
    //     0x61676c: ldur            w1, [x0, #0x13]
    // 0x616770: DecompressPointer r1
    //     0x616770: add             x1, x1, HEAP, lsl #32
    // 0x616774: cmp             w1, NULL
    // 0x616778: b.ne            #0x616810
    // 0x61677c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x61677c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x616780: ldr             x0, [x0, #0x598]
    //     0x616784: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x616788: cmp             w0, w16
    //     0x61678c: b.ne            #0x616798
    //     0x616790: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x616794: bl              #0xd67cdc
    // 0x616798: r1 = <_WidgetTicker>
    //     0x616798: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x61679c: ldr             x1, [x1, #0x210]
    // 0x6167a0: stur            x0, [fp, #-8]
    // 0x6167a4: r0 = _Set()
    //     0x6167a4: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x6167a8: mov             x1, x0
    // 0x6167ac: ldur            x0, [fp, #-8]
    // 0x6167b0: stur            x1, [fp, #-0x10]
    // 0x6167b4: StoreField: r1->field_1b = r0
    //     0x6167b4: stur            w0, [x1, #0x1b]
    // 0x6167b8: StoreField: r1->field_b = rZR
    //     0x6167b8: stur            wzr, [x1, #0xb]
    // 0x6167bc: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x6167bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6167c0: ldr             x0, [x0, #0x5a0]
    //     0x6167c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6167c8: cmp             w0, w16
    //     0x6167cc: b.ne            #0x6167d8
    //     0x6167d0: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x6167d4: bl              #0xd67cdc
    // 0x6167d8: mov             x1, x0
    // 0x6167dc: ldur            x0, [fp, #-0x10]
    // 0x6167e0: StoreField: r0->field_f = r1
    //     0x6167e0: stur            w1, [x0, #0xf]
    // 0x6167e4: StoreField: r0->field_13 = rZR
    //     0x6167e4: stur            wzr, [x0, #0x13]
    // 0x6167e8: StoreField: r0->field_17 = rZR
    //     0x6167e8: stur            wzr, [x0, #0x17]
    // 0x6167ec: ldr             x1, [fp, #0x18]
    // 0x6167f0: StoreField: r1->field_13 = r0
    //     0x6167f0: stur            w0, [x1, #0x13]
    //     0x6167f4: ldurb           w16, [x1, #-1]
    //     0x6167f8: ldurb           w17, [x0, #-1]
    //     0x6167fc: and             x16, x17, x16, lsr #2
    //     0x616800: tst             x16, HEAP, lsr #32
    //     0x616804: b.eq            #0x61680c
    //     0x616808: bl              #0xd6826c
    // 0x61680c: b               #0x616814
    // 0x616810: mov             x1, x0
    // 0x616814: ldr             x0, [fp, #0x10]
    // 0x616818: r0 = _WidgetTicker()
    //     0x616818: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x61681c: mov             x1, x0
    // 0x616820: ldr             x0, [fp, #0x18]
    // 0x616824: stur            x1, [fp, #-8]
    // 0x616828: StoreField: r1->field_1b = r0
    //     0x616828: stur            w0, [x1, #0x1b]
    // 0x61682c: r2 = false
    //     0x61682c: add             x2, NULL, #0x30  ; false
    // 0x616830: StoreField: r1->field_b = r2
    //     0x616830: stur            w2, [x1, #0xb]
    // 0x616834: ldr             x2, [fp, #0x10]
    // 0x616838: StoreField: r1->field_13 = r2
    //     0x616838: stur            w2, [x1, #0x13]
    // 0x61683c: LoadField: r2 = r0->field_17
    //     0x61683c: ldur            w2, [x0, #0x17]
    // 0x616840: DecompressPointer r2
    //     0x616840: add             x2, x2, HEAP, lsl #32
    // 0x616844: cmp             w2, NULL
    // 0x616848: b.eq            #0x6168a0
    // 0x61684c: LoadField: r3 = r2->field_27
    //     0x61684c: ldur            w3, [x2, #0x27]
    // 0x616850: DecompressPointer r3
    //     0x616850: add             x3, x3, HEAP, lsl #32
    // 0x616854: eor             x2, x3, #0x10
    // 0x616858: stp             x2, x1, [SP, #-0x10]!
    // 0x61685c: r0 = muted=()
    //     0x61685c: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x616860: add             SP, SP, #0x10
    // 0x616864: ldr             x0, [fp, #0x18]
    // 0x616868: LoadField: r1 = r0->field_13
    //     0x616868: ldur            w1, [x0, #0x13]
    // 0x61686c: DecompressPointer r1
    //     0x61686c: add             x1, x1, HEAP, lsl #32
    // 0x616870: cmp             w1, NULL
    // 0x616874: b.eq            #0x6168a4
    // 0x616878: ldur            x16, [fp, #-8]
    // 0x61687c: stp             x16, x1, [SP, #-0x10]!
    // 0x616880: r0 = add()
    //     0x616880: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x616884: add             SP, SP, #0x10
    // 0x616888: ldur            x0, [fp, #-8]
    // 0x61688c: LeaveFrame
    //     0x61688c: mov             SP, fp
    //     0x616890: ldp             fp, lr, [SP], #0x10
    // 0x616894: ret
    //     0x616894: ret             
    // 0x616898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616898: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61689c: b               #0x616748
    // 0x6168a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6168a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6168a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6168cc, size: 0x11c
    // 0x6168cc: EnterFrame
    //     0x6168cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6168d0: mov             fp, SP
    // 0x6168d4: AllocStack(0x10)
    //     0x6168d4: sub             SP, SP, #0x10
    // 0x6168d8: CheckStackOverflow
    //     0x6168d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6168dc: cmp             SP, x16
    //     0x6168e0: b.ls            #0x6169dc
    // 0x6168e4: ldr             x0, [fp, #0x10]
    // 0x6168e8: LoadField: r1 = r0->field_f
    //     0x6168e8: ldur            w1, [x0, #0xf]
    // 0x6168ec: DecompressPointer r1
    //     0x6168ec: add             x1, x1, HEAP, lsl #32
    // 0x6168f0: cmp             w1, NULL
    // 0x6168f4: b.eq            #0x6169e4
    // 0x6168f8: SaveReg r1
    //     0x6168f8: str             x1, [SP, #-8]!
    // 0x6168fc: r0 = getNotifier()
    //     0x6168fc: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x616900: add             SP, SP, #8
    // 0x616904: mov             x1, x0
    // 0x616908: ldr             x0, [fp, #0x10]
    // 0x61690c: stur            x1, [fp, #-0x10]
    // 0x616910: LoadField: r2 = r0->field_17
    //     0x616910: ldur            w2, [x0, #0x17]
    // 0x616914: DecompressPointer r2
    //     0x616914: add             x2, x2, HEAP, lsl #32
    // 0x616918: stur            x2, [fp, #-8]
    // 0x61691c: cmp             w1, w2
    // 0x616920: b.ne            #0x616934
    // 0x616924: r0 = Null
    //     0x616924: mov             x0, NULL
    // 0x616928: LeaveFrame
    //     0x616928: mov             SP, fp
    //     0x61692c: ldp             fp, lr, [SP], #0x10
    // 0x616930: ret
    //     0x616930: ret             
    // 0x616934: cmp             w2, NULL
    // 0x616938: b.eq            #0x616974
    // 0x61693c: r1 = 1
    //     0x61693c: mov             x1, #1
    // 0x616940: r0 = AllocateContext()
    //     0x616940: bl              #0xd68aa4  ; AllocateContextStub
    // 0x616944: mov             x1, x0
    // 0x616948: ldr             x0, [fp, #0x10]
    // 0x61694c: StoreField: r1->field_f = r0
    //     0x61694c: stur            w0, [x1, #0xf]
    // 0x616950: mov             x2, x1
    // 0x616954: r1 = Function '_updateTickers@156311458':.
    //     0x616954: add             x1, PP, #0x56, lsl #12  ; [pp+0x56628] AnonymousClosure: (0x6169e8), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickers (0x616a30)
    //     0x616958: ldr             x1, [x1, #0x628]
    // 0x61695c: r0 = AllocateClosure()
    //     0x61695c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x616960: ldur            x16, [fp, #-8]
    // 0x616964: stp             x0, x16, [SP, #-0x10]!
    // 0x616968: r0 = removeListener()
    //     0x616968: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x61696c: add             SP, SP, #0x10
    // 0x616970: ldr             x0, [fp, #0x10]
    // 0x616974: r1 = 1
    //     0x616974: mov             x1, #1
    // 0x616978: r0 = AllocateContext()
    //     0x616978: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61697c: mov             x1, x0
    // 0x616980: ldr             x0, [fp, #0x10]
    // 0x616984: StoreField: r1->field_f = r0
    //     0x616984: stur            w0, [x1, #0xf]
    // 0x616988: mov             x2, x1
    // 0x61698c: r1 = Function '_updateTickers@156311458':.
    //     0x61698c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56628] AnonymousClosure: (0x6169e8), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickers (0x616a30)
    //     0x616990: ldr             x1, [x1, #0x628]
    // 0x616994: r0 = AllocateClosure()
    //     0x616994: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x616998: ldur            x16, [fp, #-0x10]
    // 0x61699c: stp             x0, x16, [SP, #-0x10]!
    // 0x6169a0: r0 = addListener()
    //     0x6169a0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x6169a4: add             SP, SP, #0x10
    // 0x6169a8: ldur            x0, [fp, #-0x10]
    // 0x6169ac: ldr             x1, [fp, #0x10]
    // 0x6169b0: StoreField: r1->field_17 = r0
    //     0x6169b0: stur            w0, [x1, #0x17]
    //     0x6169b4: ldurb           w16, [x1, #-1]
    //     0x6169b8: ldurb           w17, [x0, #-1]
    //     0x6169bc: and             x16, x17, x16, lsr #2
    //     0x6169c0: tst             x16, HEAP, lsr #32
    //     0x6169c4: b.eq            #0x6169cc
    //     0x6169c8: bl              #0xd6826c
    // 0x6169cc: r0 = Null
    //     0x6169cc: mov             x0, NULL
    // 0x6169d0: LeaveFrame
    //     0x6169d0: mov             SP, fp
    //     0x6169d4: ldp             fp, lr, [SP], #0x10
    // 0x6169d8: ret
    //     0x6169d8: ret             
    // 0x6169dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6169dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6169e0: b               #0x6168e4
    // 0x6169e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6169e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x6169e8, size: 0x48
    // 0x6169e8: EnterFrame
    //     0x6169e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6169ec: mov             fp, SP
    // 0x6169f0: ldr             x0, [fp, #0x10]
    // 0x6169f4: LoadField: r1 = r0->field_17
    //     0x6169f4: ldur            w1, [x0, #0x17]
    // 0x6169f8: DecompressPointer r1
    //     0x6169f8: add             x1, x1, HEAP, lsl #32
    // 0x6169fc: CheckStackOverflow
    //     0x6169fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616a00: cmp             SP, x16
    //     0x616a04: b.ls            #0x616a28
    // 0x616a08: LoadField: r0 = r1->field_f
    //     0x616a08: ldur            w0, [x1, #0xf]
    // 0x616a0c: DecompressPointer r0
    //     0x616a0c: add             x0, x0, HEAP, lsl #32
    // 0x616a10: SaveReg r0
    //     0x616a10: str             x0, [SP, #-8]!
    // 0x616a14: r0 = _updateTickers()
    //     0x616a14: bl              #0x616a30  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickers
    // 0x616a18: add             SP, SP, #8
    // 0x616a1c: LeaveFrame
    //     0x616a1c: mov             SP, fp
    //     0x616a20: ldp             fp, lr, [SP], #0x10
    // 0x616a24: ret
    //     0x616a24: ret             
    // 0x616a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616a2c: b               #0x616a08
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x616a30, size: 0x150
    // 0x616a30: EnterFrame
    //     0x616a30: stp             fp, lr, [SP, #-0x10]!
    //     0x616a34: mov             fp, SP
    // 0x616a38: AllocStack(0x20)
    //     0x616a38: sub             SP, SP, #0x20
    // 0x616a3c: CheckStackOverflow
    //     0x616a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616a40: cmp             SP, x16
    //     0x616a44: b.ls            #0x616b6c
    // 0x616a48: ldr             x0, [fp, #0x10]
    // 0x616a4c: LoadField: r1 = r0->field_13
    //     0x616a4c: ldur            w1, [x0, #0x13]
    // 0x616a50: DecompressPointer r1
    //     0x616a50: add             x1, x1, HEAP, lsl #32
    // 0x616a54: cmp             w1, NULL
    // 0x616a58: b.eq            #0x616b5c
    // 0x616a5c: LoadField: r2 = r0->field_17
    //     0x616a5c: ldur            w2, [x0, #0x17]
    // 0x616a60: DecompressPointer r2
    //     0x616a60: add             x2, x2, HEAP, lsl #32
    // 0x616a64: cmp             w2, NULL
    // 0x616a68: b.eq            #0x616b74
    // 0x616a6c: LoadField: r0 = r2->field_27
    //     0x616a6c: ldur            w0, [x2, #0x27]
    // 0x616a70: DecompressPointer r0
    //     0x616a70: add             x0, x0, HEAP, lsl #32
    // 0x616a74: eor             x2, x0, #0x10
    // 0x616a78: stur            x2, [fp, #-8]
    // 0x616a7c: SaveReg r1
    //     0x616a7c: str             x1, [SP, #-8]!
    // 0x616a80: r0 = iterator()
    //     0x616a80: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x616a84: add             SP, SP, #8
    // 0x616a88: stur            x0, [fp, #-0x18]
    // 0x616a8c: LoadField: r2 = r0->field_7
    //     0x616a8c: ldur            w2, [x0, #7]
    // 0x616a90: DecompressPointer r2
    //     0x616a90: add             x2, x2, HEAP, lsl #32
    // 0x616a94: stur            x2, [fp, #-0x10]
    // 0x616a98: ldur            x1, [fp, #-8]
    // 0x616a9c: CheckStackOverflow
    //     0x616a9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x616aa0: cmp             SP, x16
    //     0x616aa4: b.ls            #0x616b78
    // 0x616aa8: SaveReg r0
    //     0x616aa8: str             x0, [SP, #-8]!
    // 0x616aac: r0 = moveNext()
    //     0x616aac: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x616ab0: add             SP, SP, #8
    // 0x616ab4: tbnz            w0, #4, #0x616b5c
    // 0x616ab8: ldur            x3, [fp, #-0x18]
    // 0x616abc: LoadField: r4 = r3->field_33
    //     0x616abc: ldur            w4, [x3, #0x33]
    // 0x616ac0: DecompressPointer r4
    //     0x616ac0: add             x4, x4, HEAP, lsl #32
    // 0x616ac4: stur            x4, [fp, #-0x20]
    // 0x616ac8: cmp             w4, NULL
    // 0x616acc: b.ne            #0x616b00
    // 0x616ad0: mov             x0, x4
    // 0x616ad4: ldur            x2, [fp, #-0x10]
    // 0x616ad8: r1 = Null
    //     0x616ad8: mov             x1, NULL
    // 0x616adc: cmp             w2, NULL
    // 0x616ae0: b.eq            #0x616b00
    // 0x616ae4: LoadField: r4 = r2->field_17
    //     0x616ae4: ldur            w4, [x2, #0x17]
    // 0x616ae8: DecompressPointer r4
    //     0x616ae8: add             x4, x4, HEAP, lsl #32
    // 0x616aec: r8 = X0
    //     0x616aec: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x616af0: LoadField: r9 = r4->field_7
    //     0x616af0: ldur            x9, [x4, #7]
    // 0x616af4: r3 = Null
    //     0x616af4: add             x3, PP, #0x56, lsl #12  ; [pp+0x56618] Null
    //     0x616af8: ldr             x3, [x3, #0x618]
    // 0x616afc: blr             x9
    // 0x616b00: ldur            x1, [fp, #-8]
    // 0x616b04: ldur            x0, [fp, #-0x20]
    // 0x616b08: LoadField: r2 = r0->field_b
    //     0x616b08: ldur            w2, [x0, #0xb]
    // 0x616b0c: DecompressPointer r2
    //     0x616b0c: add             x2, x2, HEAP, lsl #32
    // 0x616b10: cmp             w1, w2
    // 0x616b14: b.eq            #0x616b50
    // 0x616b18: StoreField: r0->field_b = r1
    //     0x616b18: stur            w1, [x0, #0xb]
    // 0x616b1c: tbnz            w1, #4, #0x616b30
    // 0x616b20: SaveReg r0
    //     0x616b20: str             x0, [SP, #-8]!
    // 0x616b24: r0 = unscheduleTick()
    //     0x616b24: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x616b28: add             SP, SP, #8
    // 0x616b2c: b               #0x616b50
    // 0x616b30: SaveReg r0
    //     0x616b30: str             x0, [SP, #-8]!
    // 0x616b34: r0 = shouldScheduleTick()
    //     0x616b34: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x616b38: add             SP, SP, #8
    // 0x616b3c: tbnz            w0, #4, #0x616b50
    // 0x616b40: ldur            x16, [fp, #-0x20]
    // 0x616b44: SaveReg r16
    //     0x616b44: str             x16, [SP, #-8]!
    // 0x616b48: r0 = scheduleTick()
    //     0x616b48: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x616b4c: add             SP, SP, #8
    // 0x616b50: ldur            x0, [fp, #-0x18]
    // 0x616b54: ldur            x2, [fp, #-0x10]
    // 0x616b58: b               #0x616a98
    // 0x616b5c: r0 = Null
    //     0x616b5c: mov             x0, NULL
    // 0x616b60: LeaveFrame
    //     0x616b60: mov             SP, fp
    //     0x616b64: ldp             fp, lr, [SP], #0x10
    // 0x616b68: ret
    //     0x616b68: ret             
    // 0x616b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616b6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616b70: b               #0x616a48
    // 0x616b74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x616b74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x616b78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x616b78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x616b7c: b               #0x616aa8
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f32c, size: 0x4c
    // 0x81f32c: EnterFrame
    //     0x81f32c: stp             fp, lr, [SP, #-0x10]!
    //     0x81f330: mov             fp, SP
    // 0x81f334: CheckStackOverflow
    //     0x81f334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f338: cmp             SP, x16
    //     0x81f33c: b.ls            #0x81f370
    // 0x81f340: ldr             x16, [fp, #0x10]
    // 0x81f344: SaveReg r16
    //     0x81f344: str             x16, [SP, #-8]!
    // 0x81f348: r0 = _updateTickerModeNotifier()
    //     0x81f348: bl              #0x6168cc  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f34c: add             SP, SP, #8
    // 0x81f350: ldr             x16, [fp, #0x10]
    // 0x81f354: SaveReg r16
    //     0x81f354: str             x16, [SP, #-8]!
    // 0x81f358: r0 = _updateTickers()
    //     0x81f358: bl              #0x616a30  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f35c: add             SP, SP, #8
    // 0x81f360: r0 = Null
    //     0x81f360: mov             x0, NULL
    // 0x81f364: LeaveFrame
    //     0x81f364: mov             SP, fp
    //     0x81f368: ldp             fp, lr, [SP], #0x10
    // 0x81f36c: ret
    //     0x81f36c: ret             
    // 0x81f370: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f370: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f374: b               #0x81f340
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa5145c, size: 0x8c
    // 0xa5145c: EnterFrame
    //     0xa5145c: stp             fp, lr, [SP, #-0x10]!
    //     0xa51460: mov             fp, SP
    // 0xa51464: AllocStack(0x8)
    //     0xa51464: sub             SP, SP, #8
    // 0xa51468: CheckStackOverflow
    //     0xa51468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5146c: cmp             SP, x16
    //     0xa51470: b.ls            #0xa514e0
    // 0xa51474: ldr             x0, [fp, #0x10]
    // 0xa51478: LoadField: r1 = r0->field_17
    //     0xa51478: ldur            w1, [x0, #0x17]
    // 0xa5147c: DecompressPointer r1
    //     0xa5147c: add             x1, x1, HEAP, lsl #32
    // 0xa51480: stur            x1, [fp, #-8]
    // 0xa51484: cmp             w1, NULL
    // 0xa51488: b.ne            #0xa51494
    // 0xa5148c: mov             x1, x0
    // 0xa51490: b               #0xa514cc
    // 0xa51494: r1 = 1
    //     0xa51494: mov             x1, #1
    // 0xa51498: r0 = AllocateContext()
    //     0xa51498: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5149c: mov             x1, x0
    // 0xa514a0: ldr             x0, [fp, #0x10]
    // 0xa514a4: StoreField: r1->field_f = r0
    //     0xa514a4: stur            w0, [x1, #0xf]
    // 0xa514a8: mov             x2, x1
    // 0xa514ac: r1 = Function '_updateTickers@156311458':.
    //     0xa514ac: add             x1, PP, #0x56, lsl #12  ; [pp+0x56628] AnonymousClosure: (0x6169e8), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::_updateTickers (0x616a30)
    //     0xa514b0: ldr             x1, [x1, #0x628]
    // 0xa514b4: r0 = AllocateClosure()
    //     0xa514b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa514b8: ldur            x16, [fp, #-8]
    // 0xa514bc: stp             x0, x16, [SP, #-0x10]!
    // 0xa514c0: r0 = removeListener()
    //     0xa514c0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa514c4: add             SP, SP, #0x10
    // 0xa514c8: ldr             x1, [fp, #0x10]
    // 0xa514cc: StoreField: r1->field_17 = rNULL
    //     0xa514cc: stur            NULL, [x1, #0x17]
    // 0xa514d0: r0 = Null
    //     0xa514d0: mov             x0, NULL
    // 0xa514d4: LeaveFrame
    //     0xa514d4: mov             SP, fp
    //     0xa514d8: ldp             fp, lr, [SP], #0x10
    // 0xa514dc: ret
    //     0xa514dc: ret             
    // 0xa514e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa514e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa514e4: b               #0xa51474
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa514e8, size: 0x48
    // 0xa514e8: EnterFrame
    //     0xa514e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa514ec: mov             fp, SP
    // 0xa514f0: ldr             x0, [fp, #0x10]
    // 0xa514f4: LoadField: r1 = r0->field_17
    //     0xa514f4: ldur            w1, [x0, #0x17]
    // 0xa514f8: DecompressPointer r1
    //     0xa514f8: add             x1, x1, HEAP, lsl #32
    // 0xa514fc: CheckStackOverflow
    //     0xa514fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51500: cmp             SP, x16
    //     0xa51504: b.ls            #0xa51528
    // 0xa51508: LoadField: r0 = r1->field_f
    //     0xa51508: ldur            w0, [x1, #0xf]
    // 0xa5150c: DecompressPointer r0
    //     0xa5150c: add             x0, x0, HEAP, lsl #32
    // 0xa51510: SaveReg r0
    //     0xa51510: str             x0, [SP, #-8]!
    // 0xa51514: r0 = dispose()
    //     0xa51514: bl              #0xa5145c  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::dispose
    // 0xa51518: add             SP, SP, #8
    // 0xa5151c: LeaveFrame
    //     0xa5151c: mov             SP, fp
    //     0xa51520: ldp             fp, lr, [SP], #0x10
    // 0xa51524: ret
    //     0xa51524: ret             
    // 0xa51528: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51528: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5152c: b               #0xa51508
  }
}

// class id: 3331, size: 0x4c, field offset: 0x1c
//   transformed mixin,
abstract class __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin extends __CheckboxState&State&TickerProviderStateMixin
     with ToggleableStateMixin<X0 bound StatefulWidget> {

  late AnimationController _positionController; // offset: 0x1c
  late AnimationController _reactionController; // offset: 0x24
  late AnimationController _reactionHoverFadeController; // offset: 0x30
  late AnimationController _reactionFocusFadeController; // offset: 0x38
  late CurvedAnimation _position; // offset: 0x20
  late Animation<double> _reaction; // offset: 0x28
  late Animation<double> _reactionFocusFade; // offset: 0x34
  late Animation<double> _reactionHoverFade; // offset: 0x2c
  late final Map<Type, Action<Intent>> _actionMap; // offset: 0x3c

  _ animateToValue(/* No info */) {
    // ** addr: 0x7b0d84, size: 0xb4
    // 0x7b0d84: EnterFrame
    //     0x7b0d84: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0d88: mov             fp, SP
    // 0x7b0d8c: CheckStackOverflow
    //     0x7b0d8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0d90: cmp             SP, x16
    //     0x7b0d94: b.ls            #0x7b0e14
    // 0x7b0d98: ldr             x0, [fp, #0x10]
    // 0x7b0d9c: LoadField: r1 = r0->field_b
    //     0x7b0d9c: ldur            w1, [x0, #0xb]
    // 0x7b0da0: DecompressPointer r1
    //     0x7b0da0: add             x1, x1, HEAP, lsl #32
    // 0x7b0da4: cmp             w1, NULL
    // 0x7b0da8: b.eq            #0x7b0e1c
    // 0x7b0dac: LoadField: r2 = r1->field_b
    //     0x7b0dac: ldur            w2, [x1, #0xb]
    // 0x7b0db0: DecompressPointer r2
    //     0x7b0db0: add             x2, x2, HEAP, lsl #32
    // 0x7b0db4: tbnz            w2, #4, #0x7b0de0
    // 0x7b0db8: LoadField: r1 = r0->field_1b
    //     0x7b0db8: ldur            w1, [x0, #0x1b]
    // 0x7b0dbc: DecompressPointer r1
    //     0x7b0dbc: add             x1, x1, HEAP, lsl #32
    // 0x7b0dc0: r16 = Sentinel
    //     0x7b0dc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b0dc4: cmp             w1, w16
    // 0x7b0dc8: b.eq            #0x7b0e20
    // 0x7b0dcc: SaveReg r1
    //     0x7b0dcc: str             x1, [SP, #-8]!
    // 0x7b0dd0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b0dd0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b0dd4: r0 = forward()
    //     0x7b0dd4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7b0dd8: add             SP, SP, #8
    // 0x7b0ddc: b               #0x7b0e04
    // 0x7b0de0: LoadField: r1 = r0->field_1b
    //     0x7b0de0: ldur            w1, [x0, #0x1b]
    // 0x7b0de4: DecompressPointer r1
    //     0x7b0de4: add             x1, x1, HEAP, lsl #32
    // 0x7b0de8: r16 = Sentinel
    //     0x7b0de8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b0dec: cmp             w1, w16
    // 0x7b0df0: b.eq            #0x7b0e2c
    // 0x7b0df4: SaveReg r1
    //     0x7b0df4: str             x1, [SP, #-8]!
    // 0x7b0df8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b0df8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b0dfc: r0 = reverse()
    //     0x7b0dfc: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x7b0e00: add             SP, SP, #8
    // 0x7b0e04: r0 = Null
    //     0x7b0e04: mov             x0, NULL
    // 0x7b0e08: LeaveFrame
    //     0x7b0e08: mov             SP, fp
    //     0x7b0e0c: ldp             fp, lr, [SP], #0x10
    // 0x7b0e10: ret
    //     0x7b0e10: ret             
    // 0x7b0e14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0e14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0e18: b               #0x7b0d98
    // 0x7b0e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0e1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0e20: r9 = _positionController
    //     0x7b0e20: add             x9, PP, #0x56, lsl #12  ; [pp+0x564e0] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._positionController@837519154>: late (offset: 0x1c)
    //     0x7b0e24: ldr             x9, [x9, #0x4e0]
    // 0x7b0e28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b0e28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b0e2c: r9 = _positionController
    //     0x7b0e2c: add             x9, PP, #0x56, lsl #12  ; [pp+0x564e0] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._positionController@837519154>: late (offset: 0x1c)
    //     0x7b0e30: ldr             x9, [x9, #0x4e0]
    // 0x7b0e34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b0e34: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ buildToggleable(/* No info */) {
    // ** addr: 0x84f120, size: 0x2a0
    // 0x84f120: EnterFrame
    //     0x84f120: stp             fp, lr, [SP, #-0x10]!
    //     0x84f124: mov             fp, SP
    // 0x84f128: AllocStack(0x50)
    //     0x84f128: sub             SP, SP, #0x50
    // 0x84f12c: CheckStackOverflow
    //     0x84f12c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f130: cmp             SP, x16
    //     0x84f134: b.ls            #0x84f3b0
    // 0x84f138: ldr             x1, [fp, #0x28]
    // 0x84f13c: LoadField: r0 = r1->field_3b
    //     0x84f13c: ldur            w0, [x1, #0x3b]
    // 0x84f140: DecompressPointer r0
    //     0x84f140: add             x0, x0, HEAP, lsl #32
    // 0x84f144: r16 = Sentinel
    //     0x84f144: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84f148: cmp             w0, w16
    // 0x84f14c: b.ne            #0x84f15c
    // 0x84f150: r2 = _actionMap
    //     0x84f150: add             x2, PP, #0x56, lsl #12  ; [pp+0x56580] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._actionMap@837519154>: late final (offset: 0x3c)
    //     0x84f154: ldr             x2, [x2, #0x580]
    // 0x84f158: r0 = InitLateFinalInstanceField()
    //     0x84f158: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x84f15c: mov             x1, x0
    // 0x84f160: ldr             x0, [fp, #0x28]
    // 0x84f164: stur            x1, [fp, #-8]
    // 0x84f168: LoadField: r2 = r0->field_b
    //     0x84f168: ldur            w2, [x0, #0xb]
    // 0x84f16c: DecompressPointer r2
    //     0x84f16c: add             x2, x2, HEAP, lsl #32
    // 0x84f170: cmp             w2, NULL
    // 0x84f174: b.eq            #0x84f3b8
    // 0x84f178: r1 = 1
    //     0x84f178: mov             x1, #1
    // 0x84f17c: r0 = AllocateContext()
    //     0x84f17c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f180: mov             x1, x0
    // 0x84f184: ldr             x0, [fp, #0x28]
    // 0x84f188: stur            x1, [fp, #-0x10]
    // 0x84f18c: StoreField: r1->field_f = r0
    //     0x84f18c: stur            w0, [x1, #0xf]
    // 0x84f190: r1 = 1
    //     0x84f190: mov             x1, #1
    // 0x84f194: r0 = AllocateContext()
    //     0x84f194: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f198: mov             x1, x0
    // 0x84f19c: ldr             x0, [fp, #0x28]
    // 0x84f1a0: stur            x1, [fp, #-0x18]
    // 0x84f1a4: StoreField: r1->field_f = r0
    //     0x84f1a4: stur            w0, [x1, #0xf]
    // 0x84f1a8: SaveReg r0
    //     0x84f1a8: str             x0, [SP, #-8]!
    // 0x84f1ac: r0 = states()
    //     0x84f1ac: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84f1b0: add             SP, SP, #8
    // 0x84f1b4: ldr             x16, [fp, #0x20]
    // 0x84f1b8: stp             x0, x16, [SP, #-0x10]!
    // 0x84f1bc: r0 = build()
    //     0x84f1bc: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84f1c0: add             SP, SP, #0x10
    // 0x84f1c4: mov             x1, x0
    // 0x84f1c8: ldr             x0, [fp, #0x28]
    // 0x84f1cc: stur            x1, [fp, #-0x20]
    // 0x84f1d0: LoadField: r2 = r0->field_b
    //     0x84f1d0: ldur            w2, [x0, #0xb]
    // 0x84f1d4: DecompressPointer r2
    //     0x84f1d4: add             x2, x2, HEAP, lsl #32
    // 0x84f1d8: cmp             w2, NULL
    // 0x84f1dc: b.eq            #0x84f3bc
    // 0x84f1e0: r1 = 1
    //     0x84f1e0: mov             x1, #1
    // 0x84f1e4: r0 = AllocateContext()
    //     0x84f1e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f1e8: mov             x1, x0
    // 0x84f1ec: ldr             x0, [fp, #0x28]
    // 0x84f1f0: stur            x1, [fp, #-0x28]
    // 0x84f1f4: StoreField: r1->field_f = r0
    //     0x84f1f4: stur            w0, [x1, #0xf]
    // 0x84f1f8: r1 = 1
    //     0x84f1f8: mov             x1, #1
    // 0x84f1fc: r0 = AllocateContext()
    //     0x84f1fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f200: mov             x1, x0
    // 0x84f204: ldr             x0, [fp, #0x28]
    // 0x84f208: stur            x1, [fp, #-0x30]
    // 0x84f20c: StoreField: r1->field_f = r0
    //     0x84f20c: stur            w0, [x1, #0xf]
    // 0x84f210: r1 = 1
    //     0x84f210: mov             x1, #1
    // 0x84f214: r0 = AllocateContext()
    //     0x84f214: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f218: mov             x1, x0
    // 0x84f21c: ldr             x0, [fp, #0x28]
    // 0x84f220: stur            x1, [fp, #-0x38]
    // 0x84f224: StoreField: r1->field_f = r0
    //     0x84f224: stur            w0, [x1, #0xf]
    // 0x84f228: r1 = 1
    //     0x84f228: mov             x1, #1
    // 0x84f22c: r0 = AllocateContext()
    //     0x84f22c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f230: mov             x1, x0
    // 0x84f234: ldr             x0, [fp, #0x28]
    // 0x84f238: stur            x1, [fp, #-0x40]
    // 0x84f23c: StoreField: r1->field_f = r0
    //     0x84f23c: stur            w0, [x1, #0xf]
    // 0x84f240: SaveReg r0
    //     0x84f240: str             x0, [SP, #-8]!
    // 0x84f244: r0 = restorationId()
    //     0x84f244: bl              #0x7d453c  ; [package:flutter/src/widgets/restoration.dart] _RestorationScopeState::restorationId
    // 0x84f248: add             SP, SP, #8
    // 0x84f24c: r0 = CustomPaint()
    //     0x84f24c: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x84f250: mov             x1, x0
    // 0x84f254: ldr             x0, [fp, #0x18]
    // 0x84f258: stur            x1, [fp, #-0x48]
    // 0x84f25c: StoreField: r1->field_f = r0
    //     0x84f25c: stur            w0, [x1, #0xf]
    // 0x84f260: ldr             x0, [fp, #0x10]
    // 0x84f264: StoreField: r1->field_17 = r0
    //     0x84f264: stur            w0, [x1, #0x17]
    // 0x84f268: r0 = false
    //     0x84f268: add             x0, NULL, #0x30  ; false
    // 0x84f26c: StoreField: r1->field_1b = r0
    //     0x84f26c: stur            w0, [x1, #0x1b]
    // 0x84f270: StoreField: r1->field_1f = r0
    //     0x84f270: stur            w0, [x1, #0x1f]
    // 0x84f274: r0 = Semantics()
    //     0x84f274: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x84f278: stur            x0, [fp, #-0x50]
    // 0x84f27c: r16 = true
    //     0x84f27c: add             x16, NULL, #0x20  ; true
    // 0x84f280: stp             x16, x0, [SP, #-0x10]!
    // 0x84f284: ldur            x16, [fp, #-0x48]
    // 0x84f288: SaveReg r16
    //     0x84f288: str             x16, [SP, #-8]!
    // 0x84f28c: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, enabled, 0x1, null]
    //     0x84f28c: add             x4, PP, #0x56, lsl #12  ; [pp+0x56588] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "enabled", 0x1, Null]
    //     0x84f290: ldr             x4, [x4, #0x588]
    // 0x84f294: r0 = Semantics()
    //     0x84f294: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x84f298: add             SP, SP, #0x18
    // 0x84f29c: r0 = GestureDetector()
    //     0x84f29c: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x84f2a0: ldur            x2, [fp, #-0x28]
    // 0x84f2a4: r1 = Function '_handleTapDown@837519154':.
    //     0x84f2a4: add             x1, PP, #0x56, lsl #12  ; [pp+0x56590] AnonymousClosure: (0x84fb94), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapDown (0x84fbe0)
    //     0x84f2a8: ldr             x1, [x1, #0x590]
    // 0x84f2ac: stur            x0, [fp, #-0x28]
    // 0x84f2b0: r0 = AllocateClosure()
    //     0x84f2b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f2b4: ldur            x2, [fp, #-0x30]
    // 0x84f2b8: r1 = Function '_handleTap@837519154':.
    //     0x84f2b8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56598] AnonymousClosure: (0x84fa18), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTap (0x84fa94)
    //     0x84f2bc: ldr             x1, [x1, #0x598]
    // 0x84f2c0: stur            x0, [fp, #-0x30]
    // 0x84f2c4: r0 = AllocateClosure()
    //     0x84f2c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f2c8: ldur            x2, [fp, #-0x38]
    // 0x84f2cc: r1 = Function '_handleTapEnd@837519154':.
    //     0x84f2cc: add             x1, PP, #0x56, lsl #12  ; [pp+0x565a0] AnonymousClosure: (0x84f8b8), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapEnd (0x84f934)
    //     0x84f2d0: ldr             x1, [x1, #0x5a0]
    // 0x84f2d4: stur            x0, [fp, #-0x38]
    // 0x84f2d8: r0 = AllocateClosure()
    //     0x84f2d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f2dc: ldur            x2, [fp, #-0x40]
    // 0x84f2e0: r1 = Function '_handleTapEnd@837519154':.
    //     0x84f2e0: add             x1, PP, #0x56, lsl #12  ; [pp+0x565a0] AnonymousClosure: (0x84f8b8), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapEnd (0x84f934)
    //     0x84f2e4: ldr             x1, [x1, #0x5a0]
    // 0x84f2e8: stur            x0, [fp, #-0x40]
    // 0x84f2ec: r0 = AllocateClosure()
    //     0x84f2ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f2f0: ldur            x16, [fp, #-0x28]
    // 0x84f2f4: r30 = false
    //     0x84f2f4: add             lr, NULL, #0x30  ; false
    // 0x84f2f8: stp             lr, x16, [SP, #-0x10]!
    // 0x84f2fc: ldur            x16, [fp, #-0x30]
    // 0x84f300: ldur            lr, [fp, #-0x38]
    // 0x84f304: stp             lr, x16, [SP, #-0x10]!
    // 0x84f308: ldur            x16, [fp, #-0x40]
    // 0x84f30c: stp             x0, x16, [SP, #-0x10]!
    // 0x84f310: ldur            x16, [fp, #-0x50]
    // 0x84f314: SaveReg r16
    //     0x84f314: str             x16, [SP, #-8]!
    // 0x84f318: r4 = const [0, 0x7, 0x7, 0x1, child, 0x6, excludeFromSemantics, 0x1, onTap, 0x3, onTapCancel, 0x5, onTapDown, 0x2, onTapUp, 0x4, null]
    //     0x84f318: add             x4, PP, #0x56, lsl #12  ; [pp+0x565a8] List(17) [0, 0x7, 0x7, 0x1, "child", 0x6, "excludeFromSemantics", 0x1, "onTap", 0x3, "onTapCancel", 0x5, "onTapDown", 0x2, "onTapUp", 0x4, Null]
    //     0x84f31c: ldr             x4, [x4, #0x5a8]
    // 0x84f320: r0 = GestureDetector()
    //     0x84f320: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x84f324: add             SP, SP, #0x38
    // 0x84f328: r0 = FocusableActionDetector()
    //     0x84f328: bl              #0x84f3c0  ; AllocateFocusableActionDetectorStub -> FocusableActionDetector (size=0x40)
    // 0x84f32c: mov             x3, x0
    // 0x84f330: r0 = true
    //     0x84f330: add             x0, NULL, #0x20  ; true
    // 0x84f334: stur            x3, [fp, #-0x30]
    // 0x84f338: StoreField: r3->field_b = r0
    //     0x84f338: stur            w0, [x3, #0xb]
    // 0x84f33c: r1 = false
    //     0x84f33c: add             x1, NULL, #0x30  ; false
    // 0x84f340: StoreField: r3->field_13 = r1
    //     0x84f340: stur            w1, [x3, #0x13]
    // 0x84f344: StoreField: r3->field_17 = r0
    //     0x84f344: stur            w0, [x3, #0x17]
    // 0x84f348: StoreField: r3->field_1b = r0
    //     0x84f348: stur            w0, [x3, #0x1b]
    // 0x84f34c: ldur            x1, [fp, #-8]
    // 0x84f350: StoreField: r3->field_1f = r1
    //     0x84f350: stur            w1, [x3, #0x1f]
    // 0x84f354: ldur            x2, [fp, #-0x10]
    // 0x84f358: r1 = Function '_handleFocusHighlightChanged@837519154':.
    //     0x84f358: add             x1, PP, #0x56, lsl #12  ; [pp+0x565b0] AnonymousClosure: (0x84f650), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleFocusHighlightChanged (0x84f69c)
    //     0x84f35c: ldr             x1, [x1, #0x5b0]
    // 0x84f360: r0 = AllocateClosure()
    //     0x84f360: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f364: mov             x1, x0
    // 0x84f368: ldur            x0, [fp, #-0x30]
    // 0x84f36c: StoreField: r0->field_27 = r1
    //     0x84f36c: stur            w1, [x0, #0x27]
    // 0x84f370: ldur            x2, [fp, #-0x18]
    // 0x84f374: r1 = Function '_handleHoverChanged@837519154':.
    //     0x84f374: add             x1, PP, #0x56, lsl #12  ; [pp+0x565b8] AnonymousClosure: (0x84f3cc), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleHoverChanged (0x84f418)
    //     0x84f378: ldr             x1, [x1, #0x5b8]
    // 0x84f37c: r0 = AllocateClosure()
    //     0x84f37c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f380: mov             x1, x0
    // 0x84f384: ldur            x0, [fp, #-0x30]
    // 0x84f388: StoreField: r0->field_2b = r1
    //     0x84f388: stur            w1, [x0, #0x2b]
    // 0x84f38c: ldur            x1, [fp, #-0x20]
    // 0x84f390: StoreField: r0->field_33 = r1
    //     0x84f390: stur            w1, [x0, #0x33]
    // 0x84f394: r1 = true
    //     0x84f394: add             x1, NULL, #0x20  ; true
    // 0x84f398: StoreField: r0->field_37 = r1
    //     0x84f398: stur            w1, [x0, #0x37]
    // 0x84f39c: ldur            x1, [fp, #-0x28]
    // 0x84f3a0: StoreField: r0->field_3b = r1
    //     0x84f3a0: stur            w1, [x0, #0x3b]
    // 0x84f3a4: LeaveFrame
    //     0x84f3a4: mov             SP, fp
    //     0x84f3a8: ldp             fp, lr, [SP], #0x10
    // 0x84f3ac: ret
    //     0x84f3ac: ret             
    // 0x84f3b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f3b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f3b4: b               #0x84f138
    // 0x84f3b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f3b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f3bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f3bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleHoverChanged(dynamic, bool) {
    // ** addr: 0x84f3cc, size: 0x4c
    // 0x84f3cc: EnterFrame
    //     0x84f3cc: stp             fp, lr, [SP, #-0x10]!
    //     0x84f3d0: mov             fp, SP
    // 0x84f3d4: ldr             x0, [fp, #0x18]
    // 0x84f3d8: LoadField: r1 = r0->field_17
    //     0x84f3d8: ldur            w1, [x0, #0x17]
    // 0x84f3dc: DecompressPointer r1
    //     0x84f3dc: add             x1, x1, HEAP, lsl #32
    // 0x84f3e0: CheckStackOverflow
    //     0x84f3e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f3e4: cmp             SP, x16
    //     0x84f3e8: b.ls            #0x84f410
    // 0x84f3ec: LoadField: r0 = r1->field_f
    //     0x84f3ec: ldur            w0, [x1, #0xf]
    // 0x84f3f0: DecompressPointer r0
    //     0x84f3f0: add             x0, x0, HEAP, lsl #32
    // 0x84f3f4: ldr             x16, [fp, #0x10]
    // 0x84f3f8: stp             x16, x0, [SP, #-0x10]!
    // 0x84f3fc: r0 = _handleHoverChanged()
    //     0x84f3fc: bl              #0x84f418  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleHoverChanged
    // 0x84f400: add             SP, SP, #0x10
    // 0x84f404: LeaveFrame
    //     0x84f404: mov             SP, fp
    //     0x84f408: ldp             fp, lr, [SP], #0x10
    // 0x84f40c: ret
    //     0x84f40c: ret             
    // 0x84f410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f414: b               #0x84f3ec
  }
  _ _handleHoverChanged(/* No info */) {
    // ** addr: 0x84f418, size: 0x110
    // 0x84f418: EnterFrame
    //     0x84f418: stp             fp, lr, [SP, #-0x10]!
    //     0x84f41c: mov             fp, SP
    // 0x84f420: AllocStack(0x10)
    //     0x84f420: sub             SP, SP, #0x10
    // 0x84f424: CheckStackOverflow
    //     0x84f424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f428: cmp             SP, x16
    //     0x84f42c: b.ls            #0x84f508
    // 0x84f430: r1 = 2
    //     0x84f430: mov             x1, #2
    // 0x84f434: r0 = AllocateContext()
    //     0x84f434: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f438: mov             x3, x0
    // 0x84f43c: ldr             x0, [fp, #0x18]
    // 0x84f440: stur            x3, [fp, #-8]
    // 0x84f444: StoreField: r3->field_f = r0
    //     0x84f444: stur            w0, [x3, #0xf]
    // 0x84f448: ldr             x1, [fp, #0x10]
    // 0x84f44c: StoreField: r3->field_13 = r1
    //     0x84f44c: stur            w1, [x3, #0x13]
    // 0x84f450: LoadField: r2 = r0->field_47
    //     0x84f450: ldur            w2, [x0, #0x47]
    // 0x84f454: DecompressPointer r2
    //     0x84f454: add             x2, x2, HEAP, lsl #32
    // 0x84f458: cmp             w1, w2
    // 0x84f45c: b.eq            #0x84f4f8
    // 0x84f460: mov             x2, x3
    // 0x84f464: r1 = Function '<anonymous closure>':.
    //     0x84f464: add             x1, PP, #0x56, lsl #12  ; [pp+0x565c0] AnonymousClosure: (0x84f528), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar (0x84f570)
    //     0x84f468: ldr             x1, [x1, #0x5c0]
    // 0x84f46c: r0 = AllocateClosure()
    //     0x84f46c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f470: ldr             x16, [fp, #0x18]
    // 0x84f474: stp             x0, x16, [SP, #-0x10]!
    // 0x84f478: r0 = setState()
    //     0x84f478: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84f47c: add             SP, SP, #0x10
    // 0x84f480: ldur            x0, [fp, #-8]
    // 0x84f484: LoadField: r1 = r0->field_13
    //     0x84f484: ldur            w1, [x0, #0x13]
    // 0x84f488: DecompressPointer r1
    //     0x84f488: add             x1, x1, HEAP, lsl #32
    // 0x84f48c: mov             x0, x1
    // 0x84f490: stur            x1, [fp, #-0x10]
    // 0x84f494: tbnz            w0, #5, #0x84f49c
    // 0x84f498: r0 = AssertBoolean()
    //     0x84f498: bl              #0xd67df0  ; AssertBooleanStub
    // 0x84f49c: ldur            x0, [fp, #-0x10]
    // 0x84f4a0: tbnz            w0, #4, #0x84f4d0
    // 0x84f4a4: ldr             x0, [fp, #0x18]
    // 0x84f4a8: LoadField: r1 = r0->field_2f
    //     0x84f4a8: ldur            w1, [x0, #0x2f]
    // 0x84f4ac: DecompressPointer r1
    //     0x84f4ac: add             x1, x1, HEAP, lsl #32
    // 0x84f4b0: r16 = Sentinel
    //     0x84f4b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84f4b4: cmp             w1, w16
    // 0x84f4b8: b.eq            #0x84f510
    // 0x84f4bc: SaveReg r1
    //     0x84f4bc: str             x1, [SP, #-8]!
    // 0x84f4c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84f4c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84f4c4: r0 = forward()
    //     0x84f4c4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84f4c8: add             SP, SP, #8
    // 0x84f4cc: b               #0x84f4f8
    // 0x84f4d0: ldr             x0, [fp, #0x18]
    // 0x84f4d4: LoadField: r1 = r0->field_2f
    //     0x84f4d4: ldur            w1, [x0, #0x2f]
    // 0x84f4d8: DecompressPointer r1
    //     0x84f4d8: add             x1, x1, HEAP, lsl #32
    // 0x84f4dc: r16 = Sentinel
    //     0x84f4dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84f4e0: cmp             w1, w16
    // 0x84f4e4: b.eq            #0x84f51c
    // 0x84f4e8: SaveReg r1
    //     0x84f4e8: str             x1, [SP, #-8]!
    // 0x84f4ec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84f4ec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84f4f0: r0 = reverse()
    //     0x84f4f0: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x84f4f4: add             SP, SP, #8
    // 0x84f4f8: r0 = Null
    //     0x84f4f8: mov             x0, NULL
    // 0x84f4fc: LeaveFrame
    //     0x84f4fc: mov             SP, fp
    //     0x84f500: ldp             fp, lr, [SP], #0x10
    // 0x84f504: ret
    //     0x84f504: ret             
    // 0x84f508: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f508: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f50c: b               #0x84f430
    // 0x84f510: r9 = _reactionHoverFadeController
    //     0x84f510: add             x9, PP, #0x56, lsl #12  ; [pp+0x564f0] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionHoverFadeController@837519154>: late (offset: 0x30)
    //     0x84f514: ldr             x9, [x9, #0x4f0]
    // 0x84f518: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f518: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f51c: r9 = _reactionHoverFadeController
    //     0x84f51c: add             x9, PP, #0x56, lsl #12  ; [pp+0x564f0] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionHoverFadeController@837519154>: late (offset: 0x30)
    //     0x84f520: ldr             x9, [x9, #0x4f0]
    // 0x84f524: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f524: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleFocusHighlightChanged(dynamic, bool) {
    // ** addr: 0x84f650, size: 0x4c
    // 0x84f650: EnterFrame
    //     0x84f650: stp             fp, lr, [SP, #-0x10]!
    //     0x84f654: mov             fp, SP
    // 0x84f658: ldr             x0, [fp, #0x18]
    // 0x84f65c: LoadField: r1 = r0->field_17
    //     0x84f65c: ldur            w1, [x0, #0x17]
    // 0x84f660: DecompressPointer r1
    //     0x84f660: add             x1, x1, HEAP, lsl #32
    // 0x84f664: CheckStackOverflow
    //     0x84f664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f668: cmp             SP, x16
    //     0x84f66c: b.ls            #0x84f694
    // 0x84f670: LoadField: r0 = r1->field_f
    //     0x84f670: ldur            w0, [x1, #0xf]
    // 0x84f674: DecompressPointer r0
    //     0x84f674: add             x0, x0, HEAP, lsl #32
    // 0x84f678: ldr             x16, [fp, #0x10]
    // 0x84f67c: stp             x16, x0, [SP, #-0x10]!
    // 0x84f680: r0 = _handleFocusHighlightChanged()
    //     0x84f680: bl              #0x84f69c  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleFocusHighlightChanged
    // 0x84f684: add             SP, SP, #0x10
    // 0x84f688: LeaveFrame
    //     0x84f688: mov             SP, fp
    //     0x84f68c: ldp             fp, lr, [SP], #0x10
    // 0x84f690: ret
    //     0x84f690: ret             
    // 0x84f694: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f694: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f698: b               #0x84f670
  }
  _ _handleFocusHighlightChanged(/* No info */) {
    // ** addr: 0x84f69c, size: 0x110
    // 0x84f69c: EnterFrame
    //     0x84f69c: stp             fp, lr, [SP, #-0x10]!
    //     0x84f6a0: mov             fp, SP
    // 0x84f6a4: AllocStack(0x10)
    //     0x84f6a4: sub             SP, SP, #0x10
    // 0x84f6a8: CheckStackOverflow
    //     0x84f6a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f6ac: cmp             SP, x16
    //     0x84f6b0: b.ls            #0x84f78c
    // 0x84f6b4: r1 = 2
    //     0x84f6b4: mov             x1, #2
    // 0x84f6b8: r0 = AllocateContext()
    //     0x84f6b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f6bc: mov             x3, x0
    // 0x84f6c0: ldr             x0, [fp, #0x18]
    // 0x84f6c4: stur            x3, [fp, #-8]
    // 0x84f6c8: StoreField: r3->field_f = r0
    //     0x84f6c8: stur            w0, [x3, #0xf]
    // 0x84f6cc: ldr             x1, [fp, #0x10]
    // 0x84f6d0: StoreField: r3->field_13 = r1
    //     0x84f6d0: stur            w1, [x3, #0x13]
    // 0x84f6d4: LoadField: r2 = r0->field_43
    //     0x84f6d4: ldur            w2, [x0, #0x43]
    // 0x84f6d8: DecompressPointer r2
    //     0x84f6d8: add             x2, x2, HEAP, lsl #32
    // 0x84f6dc: cmp             w1, w2
    // 0x84f6e0: b.eq            #0x84f77c
    // 0x84f6e4: mov             x2, x3
    // 0x84f6e8: r1 = Function '<anonymous closure>':.
    //     0x84f6e8: add             x1, PP, #0x56, lsl #12  ; [pp+0x565c8] AnonymousClosure: (0x84f7ac), in [package:flutter/src/material/slider.dart] _SliderState::_handleFocusHighlightChanged (0x84f7f4)
    //     0x84f6ec: ldr             x1, [x1, #0x5c8]
    // 0x84f6f0: r0 = AllocateClosure()
    //     0x84f6f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f6f4: ldr             x16, [fp, #0x18]
    // 0x84f6f8: stp             x0, x16, [SP, #-0x10]!
    // 0x84f6fc: r0 = setState()
    //     0x84f6fc: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84f700: add             SP, SP, #0x10
    // 0x84f704: ldur            x0, [fp, #-8]
    // 0x84f708: LoadField: r1 = r0->field_13
    //     0x84f708: ldur            w1, [x0, #0x13]
    // 0x84f70c: DecompressPointer r1
    //     0x84f70c: add             x1, x1, HEAP, lsl #32
    // 0x84f710: mov             x0, x1
    // 0x84f714: stur            x1, [fp, #-0x10]
    // 0x84f718: tbnz            w0, #5, #0x84f720
    // 0x84f71c: r0 = AssertBoolean()
    //     0x84f71c: bl              #0xd67df0  ; AssertBooleanStub
    // 0x84f720: ldur            x0, [fp, #-0x10]
    // 0x84f724: tbnz            w0, #4, #0x84f754
    // 0x84f728: ldr             x0, [fp, #0x18]
    // 0x84f72c: LoadField: r1 = r0->field_37
    //     0x84f72c: ldur            w1, [x0, #0x37]
    // 0x84f730: DecompressPointer r1
    //     0x84f730: add             x1, x1, HEAP, lsl #32
    // 0x84f734: r16 = Sentinel
    //     0x84f734: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84f738: cmp             w1, w16
    // 0x84f73c: b.eq            #0x84f794
    // 0x84f740: SaveReg r1
    //     0x84f740: str             x1, [SP, #-8]!
    // 0x84f744: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84f744: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84f748: r0 = forward()
    //     0x84f748: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84f74c: add             SP, SP, #8
    // 0x84f750: b               #0x84f77c
    // 0x84f754: ldr             x0, [fp, #0x18]
    // 0x84f758: LoadField: r1 = r0->field_37
    //     0x84f758: ldur            w1, [x0, #0x37]
    // 0x84f75c: DecompressPointer r1
    //     0x84f75c: add             x1, x1, HEAP, lsl #32
    // 0x84f760: r16 = Sentinel
    //     0x84f760: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84f764: cmp             w1, w16
    // 0x84f768: b.eq            #0x84f7a0
    // 0x84f76c: SaveReg r1
    //     0x84f76c: str             x1, [SP, #-8]!
    // 0x84f770: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84f770: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84f774: r0 = reverse()
    //     0x84f774: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x84f778: add             SP, SP, #8
    // 0x84f77c: r0 = Null
    //     0x84f77c: mov             x0, NULL
    // 0x84f780: LeaveFrame
    //     0x84f780: mov             SP, fp
    //     0x84f784: ldp             fp, lr, [SP], #0x10
    // 0x84f788: ret
    //     0x84f788: ret             
    // 0x84f78c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f78c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f790: b               #0x84f6b4
    // 0x84f794: r9 = _reactionFocusFadeController
    //     0x84f794: add             x9, PP, #0x56, lsl #12  ; [pp+0x564f8] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionFocusFadeController@837519154>: late (offset: 0x38)
    //     0x84f798: ldr             x9, [x9, #0x4f8]
    // 0x84f79c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f79c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f7a0: r9 = _reactionFocusFadeController
    //     0x84f7a0: add             x9, PP, #0x56, lsl #12  ; [pp+0x564f8] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionFocusFadeController@837519154>: late (offset: 0x38)
    //     0x84f7a4: ldr             x9, [x9, #0x4f8]
    // 0x84f7a8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f7a8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTapEnd(dynamic, [TapUpDetails?]) {
    // ** addr: 0x84f8b8, size: 0x7c
    // 0x84f8b8: EnterFrame
    //     0x84f8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x84f8bc: mov             fp, SP
    // 0x84f8c0: mov             x0, x4
    // 0x84f8c4: LoadField: r1 = r0->field_13
    //     0x84f8c4: ldur            w1, [x0, #0x13]
    // 0x84f8c8: DecompressPointer r1
    //     0x84f8c8: add             x1, x1, HEAP, lsl #32
    // 0x84f8cc: sub             x0, x1, #2
    // 0x84f8d0: add             x1, fp, w0, sxtw #2
    // 0x84f8d4: ldr             x1, [x1, #0x10]
    // 0x84f8d8: cmp             w0, #2
    // 0x84f8dc: b.lt            #0x84f8f0
    // 0x84f8e0: add             x2, fp, w0, sxtw #2
    // 0x84f8e4: ldr             x2, [x2, #8]
    // 0x84f8e8: mov             x0, x2
    // 0x84f8ec: b               #0x84f8f4
    // 0x84f8f0: r0 = Null
    //     0x84f8f0: mov             x0, NULL
    // 0x84f8f4: LoadField: r2 = r1->field_17
    //     0x84f8f4: ldur            w2, [x1, #0x17]
    // 0x84f8f8: DecompressPointer r2
    //     0x84f8f8: add             x2, x2, HEAP, lsl #32
    // 0x84f8fc: CheckStackOverflow
    //     0x84f8fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f900: cmp             SP, x16
    //     0x84f904: b.ls            #0x84f92c
    // 0x84f908: LoadField: r1 = r2->field_f
    //     0x84f908: ldur            w1, [x2, #0xf]
    // 0x84f90c: DecompressPointer r1
    //     0x84f90c: add             x1, x1, HEAP, lsl #32
    // 0x84f910: stp             x0, x1, [SP, #-0x10]!
    // 0x84f914: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x84f914: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x84f918: r0 = _handleTapEnd()
    //     0x84f918: bl              #0x84f934  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapEnd
    // 0x84f91c: add             SP, SP, #0x10
    // 0x84f920: LeaveFrame
    //     0x84f920: mov             SP, fp
    //     0x84f924: ldp             fp, lr, [SP], #0x10
    // 0x84f928: ret
    //     0x84f928: ret             
    // 0x84f92c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f92c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f930: b               #0x84f908
  }
  _ _handleTapEnd(/* No info */) {
    // ** addr: 0x84f934, size: 0xc4
    // 0x84f934: EnterFrame
    //     0x84f934: stp             fp, lr, [SP, #-0x10]!
    //     0x84f938: mov             fp, SP
    // 0x84f93c: AllocStack(0x8)
    //     0x84f93c: sub             SP, SP, #8
    // 0x84f940: SetupParameters(__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin<Checkbox> this /* r1, fp-0x8 */)
    //     0x84f940: mov             x0, x4
    //     0x84f944: ldur            w1, [x0, #0x13]
    //     0x84f948: add             x1, x1, HEAP, lsl #32
    //     0x84f94c: sub             x0, x1, #2
    //     0x84f950: add             x1, fp, w0, sxtw #2
    //     0x84f954: ldr             x1, [x1, #0x10]
    //     0x84f958: stur            x1, [fp, #-8]
    // 0x84f95c: CheckStackOverflow
    //     0x84f95c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f960: cmp             SP, x16
    //     0x84f964: b.ls            #0x84f9e4
    // 0x84f968: r1 = 1
    //     0x84f968: mov             x1, #1
    // 0x84f96c: r0 = AllocateContext()
    //     0x84f96c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f970: mov             x1, x0
    // 0x84f974: ldur            x0, [fp, #-8]
    // 0x84f978: StoreField: r1->field_f = r0
    //     0x84f978: stur            w0, [x1, #0xf]
    // 0x84f97c: LoadField: r2 = r0->field_3f
    //     0x84f97c: ldur            w2, [x0, #0x3f]
    // 0x84f980: DecompressPointer r2
    //     0x84f980: add             x2, x2, HEAP, lsl #32
    // 0x84f984: cmp             w2, NULL
    // 0x84f988: b.eq            #0x84f9ac
    // 0x84f98c: mov             x2, x1
    // 0x84f990: r1 = Function '<anonymous closure>':.
    //     0x84f990: add             x1, PP, #0x56, lsl #12  ; [pp+0x565d0] AnonymousClosure: (0x84f9f8), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapEnd (0x84f934)
    //     0x84f994: ldr             x1, [x1, #0x5d0]
    // 0x84f998: r0 = AllocateClosure()
    //     0x84f998: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f99c: ldur            x16, [fp, #-8]
    // 0x84f9a0: stp             x0, x16, [SP, #-0x10]!
    // 0x84f9a4: r0 = setState()
    //     0x84f9a4: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84f9a8: add             SP, SP, #0x10
    // 0x84f9ac: ldur            x0, [fp, #-8]
    // 0x84f9b0: LoadField: r1 = r0->field_23
    //     0x84f9b0: ldur            w1, [x0, #0x23]
    // 0x84f9b4: DecompressPointer r1
    //     0x84f9b4: add             x1, x1, HEAP, lsl #32
    // 0x84f9b8: r16 = Sentinel
    //     0x84f9b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84f9bc: cmp             w1, w16
    // 0x84f9c0: b.eq            #0x84f9ec
    // 0x84f9c4: SaveReg r1
    //     0x84f9c4: str             x1, [SP, #-8]!
    // 0x84f9c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84f9c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84f9cc: r0 = reverse()
    //     0x84f9cc: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x84f9d0: add             SP, SP, #8
    // 0x84f9d4: r0 = Null
    //     0x84f9d4: mov             x0, NULL
    // 0x84f9d8: LeaveFrame
    //     0x84f9d8: mov             SP, fp
    //     0x84f9dc: ldp             fp, lr, [SP], #0x10
    // 0x84f9e0: ret
    //     0x84f9e0: ret             
    // 0x84f9e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f9e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f9e8: b               #0x84f968
    // 0x84f9ec: r9 = _reactionController
    //     0x84f9ec: add             x9, PP, #0x56, lsl #12  ; [pp+0x564e8] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionController@837519154>: late (offset: 0x24)
    //     0x84f9f0: ldr             x9, [x9, #0x4e8]
    // 0x84f9f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f9f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84f9f8, size: 0x20
    // 0x84f9f8: ldr             x1, [SP]
    // 0x84f9fc: LoadField: r2 = r1->field_17
    //     0x84f9fc: ldur            w2, [x1, #0x17]
    // 0x84fa00: DecompressPointer r2
    //     0x84fa00: add             x2, x2, HEAP, lsl #32
    // 0x84fa04: LoadField: r1 = r2->field_f
    //     0x84fa04: ldur            w1, [x2, #0xf]
    // 0x84fa08: DecompressPointer r1
    //     0x84fa08: add             x1, x1, HEAP, lsl #32
    // 0x84fa0c: StoreField: r1->field_3f = rNULL
    //     0x84fa0c: stur            NULL, [x1, #0x3f]
    // 0x84fa10: r0 = Null
    //     0x84fa10: mov             x0, NULL
    // 0x84fa14: ret
    //     0x84fa14: ret             
  }
  [closure] void _handleTap(dynamic, [Intent?]) {
    // ** addr: 0x84fa18, size: 0x7c
    // 0x84fa18: EnterFrame
    //     0x84fa18: stp             fp, lr, [SP, #-0x10]!
    //     0x84fa1c: mov             fp, SP
    // 0x84fa20: mov             x0, x4
    // 0x84fa24: LoadField: r1 = r0->field_13
    //     0x84fa24: ldur            w1, [x0, #0x13]
    // 0x84fa28: DecompressPointer r1
    //     0x84fa28: add             x1, x1, HEAP, lsl #32
    // 0x84fa2c: sub             x0, x1, #2
    // 0x84fa30: add             x1, fp, w0, sxtw #2
    // 0x84fa34: ldr             x1, [x1, #0x10]
    // 0x84fa38: cmp             w0, #2
    // 0x84fa3c: b.lt            #0x84fa50
    // 0x84fa40: add             x2, fp, w0, sxtw #2
    // 0x84fa44: ldr             x2, [x2, #8]
    // 0x84fa48: mov             x0, x2
    // 0x84fa4c: b               #0x84fa54
    // 0x84fa50: r0 = Null
    //     0x84fa50: mov             x0, NULL
    // 0x84fa54: LoadField: r2 = r1->field_17
    //     0x84fa54: ldur            w2, [x1, #0x17]
    // 0x84fa58: DecompressPointer r2
    //     0x84fa58: add             x2, x2, HEAP, lsl #32
    // 0x84fa5c: CheckStackOverflow
    //     0x84fa5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fa60: cmp             SP, x16
    //     0x84fa64: b.ls            #0x84fa8c
    // 0x84fa68: LoadField: r1 = r2->field_f
    //     0x84fa68: ldur            w1, [x2, #0xf]
    // 0x84fa6c: DecompressPointer r1
    //     0x84fa6c: add             x1, x1, HEAP, lsl #32
    // 0x84fa70: stp             x0, x1, [SP, #-0x10]!
    // 0x84fa74: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x84fa74: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x84fa78: r0 = _handleTap()
    //     0x84fa78: bl              #0x84fa94  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTap
    // 0x84fa7c: add             SP, SP, #0x10
    // 0x84fa80: LeaveFrame
    //     0x84fa80: mov             SP, fp
    //     0x84fa84: ldp             fp, lr, [SP], #0x10
    // 0x84fa88: ret
    //     0x84fa88: ret             
    // 0x84fa8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fa8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fa90: b               #0x84fa68
  }
  _ _handleTap(/* No info */) {
    // ** addr: 0x84fa94, size: 0x100
    // 0x84fa94: EnterFrame
    //     0x84fa94: stp             fp, lr, [SP, #-0x10]!
    //     0x84fa98: mov             fp, SP
    // 0x84fa9c: AllocStack(0x8)
    //     0x84fa9c: sub             SP, SP, #8
    // 0x84faa0: SetupParameters(__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin<Checkbox> this /* r1, fp-0x8 */)
    //     0x84faa0: mov             x0, x4
    //     0x84faa4: ldur            w1, [x0, #0x13]
    //     0x84faa8: add             x1, x1, HEAP, lsl #32
    //     0x84faac: sub             x0, x1, #2
    //     0x84fab0: add             x1, fp, w0, sxtw #2
    //     0x84fab4: ldr             x1, [x1, #0x10]
    //     0x84fab8: stur            x1, [fp, #-8]
    // 0x84fabc: CheckStackOverflow
    //     0x84fabc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fac0: cmp             SP, x16
    //     0x84fac4: b.ls            #0x84fb80
    // 0x84fac8: LoadField: r0 = r1->field_b
    //     0x84fac8: ldur            w0, [x1, #0xb]
    // 0x84facc: DecompressPointer r0
    //     0x84facc: add             x0, x0, HEAP, lsl #32
    // 0x84fad0: cmp             w0, NULL
    // 0x84fad4: b.eq            #0x84fb88
    // 0x84fad8: LoadField: r2 = r0->field_b
    //     0x84fad8: ldur            w2, [x0, #0xb]
    // 0x84fadc: DecompressPointer r2
    //     0x84fadc: add             x2, x2, HEAP, lsl #32
    // 0x84fae0: tbz             w2, #4, #0x84fb0c
    // 0x84fae4: LoadField: r2 = r0->field_f
    //     0x84fae4: ldur            w2, [x0, #0xf]
    // 0x84fae8: DecompressPointer r2
    //     0x84fae8: add             x2, x2, HEAP, lsl #32
    // 0x84faec: r16 = true
    //     0x84faec: add             x16, NULL, #0x20  ; true
    // 0x84faf0: stp             x16, x2, [SP, #-0x10]!
    // 0x84faf4: mov             x0, x2
    // 0x84faf8: ClosureCall
    //     0x84faf8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84fafc: ldur            x2, [x0, #0x1f]
    //     0x84fb00: blr             x2
    // 0x84fb04: add             SP, SP, #0x10
    // 0x84fb08: b               #0x84fb34
    // 0x84fb0c: tbnz            w2, #4, #0x84fb34
    // 0x84fb10: LoadField: r1 = r0->field_f
    //     0x84fb10: ldur            w1, [x0, #0xf]
    // 0x84fb14: DecompressPointer r1
    //     0x84fb14: add             x1, x1, HEAP, lsl #32
    // 0x84fb18: r16 = false
    //     0x84fb18: add             x16, NULL, #0x30  ; false
    // 0x84fb1c: stp             x16, x1, [SP, #-0x10]!
    // 0x84fb20: mov             x0, x1
    // 0x84fb24: ClosureCall
    //     0x84fb24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x84fb28: ldur            x2, [x0, #0x1f]
    //     0x84fb2c: blr             x2
    // 0x84fb30: add             SP, SP, #0x10
    // 0x84fb34: ldur            x0, [fp, #-8]
    // 0x84fb38: LoadField: r1 = r0->field_f
    //     0x84fb38: ldur            w1, [x0, #0xf]
    // 0x84fb3c: DecompressPointer r1
    //     0x84fb3c: add             x1, x1, HEAP, lsl #32
    // 0x84fb40: cmp             w1, NULL
    // 0x84fb44: b.eq            #0x84fb8c
    // 0x84fb48: SaveReg r1
    //     0x84fb48: str             x1, [SP, #-8]!
    // 0x84fb4c: r0 = findRenderObject()
    //     0x84fb4c: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x84fb50: add             SP, SP, #8
    // 0x84fb54: cmp             w0, NULL
    // 0x84fb58: b.eq            #0x84fb90
    // 0x84fb5c: r16 = Instance_TapSemanticEvent
    //     0x84fb5c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e308] Obj!TapSemanticEvent@b351e1
    //     0x84fb60: ldr             x16, [x16, #0x308]
    // 0x84fb64: stp             x16, x0, [SP, #-0x10]!
    // 0x84fb68: r0 = sendSemanticsEvent()
    //     0x84fb68: bl              #0x83c044  ; [package:flutter/src/rendering/object.dart] RenderObject::sendSemanticsEvent
    // 0x84fb6c: add             SP, SP, #0x10
    // 0x84fb70: r0 = Null
    //     0x84fb70: mov             x0, NULL
    // 0x84fb74: LeaveFrame
    //     0x84fb74: mov             SP, fp
    //     0x84fb78: ldp             fp, lr, [SP], #0x10
    // 0x84fb7c: ret
    //     0x84fb7c: ret             
    // 0x84fb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fb80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fb84: b               #0x84fac8
    // 0x84fb88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84fb88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84fb8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84fb8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84fb90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84fb90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x84fb94, size: 0x4c
    // 0x84fb94: EnterFrame
    //     0x84fb94: stp             fp, lr, [SP, #-0x10]!
    //     0x84fb98: mov             fp, SP
    // 0x84fb9c: ldr             x0, [fp, #0x18]
    // 0x84fba0: LoadField: r1 = r0->field_17
    //     0x84fba0: ldur            w1, [x0, #0x17]
    // 0x84fba4: DecompressPointer r1
    //     0x84fba4: add             x1, x1, HEAP, lsl #32
    // 0x84fba8: CheckStackOverflow
    //     0x84fba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fbac: cmp             SP, x16
    //     0x84fbb0: b.ls            #0x84fbd8
    // 0x84fbb4: LoadField: r0 = r1->field_f
    //     0x84fbb4: ldur            w0, [x1, #0xf]
    // 0x84fbb8: DecompressPointer r0
    //     0x84fbb8: add             x0, x0, HEAP, lsl #32
    // 0x84fbbc: ldr             x16, [fp, #0x10]
    // 0x84fbc0: stp             x16, x0, [SP, #-0x10]!
    // 0x84fbc4: r0 = _handleTapDown()
    //     0x84fbc4: bl              #0x84fbe0  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapDown
    // 0x84fbc8: add             SP, SP, #0x10
    // 0x84fbcc: LeaveFrame
    //     0x84fbcc: mov             SP, fp
    //     0x84fbd0: ldp             fp, lr, [SP], #0x10
    // 0x84fbd4: ret
    //     0x84fbd4: ret             
    // 0x84fbd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fbd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fbdc: b               #0x84fbb4
  }
  _ _handleTapDown(/* No info */) {
    // ** addr: 0x84fbe0, size: 0xb0
    // 0x84fbe0: EnterFrame
    //     0x84fbe0: stp             fp, lr, [SP, #-0x10]!
    //     0x84fbe4: mov             fp, SP
    // 0x84fbe8: CheckStackOverflow
    //     0x84fbe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fbec: cmp             SP, x16
    //     0x84fbf0: b.ls            #0x84fc78
    // 0x84fbf4: r1 = 2
    //     0x84fbf4: mov             x1, #2
    // 0x84fbf8: r0 = AllocateContext()
    //     0x84fbf8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84fbfc: mov             x1, x0
    // 0x84fc00: ldr             x0, [fp, #0x18]
    // 0x84fc04: StoreField: r1->field_f = r0
    //     0x84fc04: stur            w0, [x1, #0xf]
    // 0x84fc08: ldr             x2, [fp, #0x10]
    // 0x84fc0c: StoreField: r1->field_13 = r2
    //     0x84fc0c: stur            w2, [x1, #0x13]
    // 0x84fc10: LoadField: r2 = r0->field_b
    //     0x84fc10: ldur            w2, [x0, #0xb]
    // 0x84fc14: DecompressPointer r2
    //     0x84fc14: add             x2, x2, HEAP, lsl #32
    // 0x84fc18: cmp             w2, NULL
    // 0x84fc1c: b.eq            #0x84fc80
    // 0x84fc20: mov             x2, x1
    // 0x84fc24: r1 = Function '<anonymous closure>':.
    //     0x84fc24: add             x1, PP, #0x56, lsl #12  ; [pp+0x565d8] AnonymousClosure: (0x84fc90), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTapDown (0x84fbe0)
    //     0x84fc28: ldr             x1, [x1, #0x5d8]
    // 0x84fc2c: r0 = AllocateClosure()
    //     0x84fc2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84fc30: ldr             x16, [fp, #0x18]
    // 0x84fc34: stp             x0, x16, [SP, #-0x10]!
    // 0x84fc38: r0 = setState()
    //     0x84fc38: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84fc3c: add             SP, SP, #0x10
    // 0x84fc40: ldr             x0, [fp, #0x18]
    // 0x84fc44: LoadField: r1 = r0->field_23
    //     0x84fc44: ldur            w1, [x0, #0x23]
    // 0x84fc48: DecompressPointer r1
    //     0x84fc48: add             x1, x1, HEAP, lsl #32
    // 0x84fc4c: r16 = Sentinel
    //     0x84fc4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84fc50: cmp             w1, w16
    // 0x84fc54: b.eq            #0x84fc84
    // 0x84fc58: SaveReg r1
    //     0x84fc58: str             x1, [SP, #-8]!
    // 0x84fc5c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84fc5c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x84fc60: r0 = forward()
    //     0x84fc60: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x84fc64: add             SP, SP, #8
    // 0x84fc68: r0 = Null
    //     0x84fc68: mov             x0, NULL
    // 0x84fc6c: LeaveFrame
    //     0x84fc6c: mov             SP, fp
    //     0x84fc70: ldp             fp, lr, [SP], #0x10
    // 0x84fc74: ret
    //     0x84fc74: ret             
    // 0x84fc78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fc78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fc7c: b               #0x84fbf4
    // 0x84fc80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84fc80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84fc84: r9 = _reactionController
    //     0x84fc84: add             x9, PP, #0x56, lsl #12  ; [pp+0x564e8] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionController@837519154>: late (offset: 0x24)
    //     0x84fc88: ldr             x9, [x9, #0x4e8]
    // 0x84fc8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84fc8c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84fc90, size: 0x50
    // 0x84fc90: ldr             x1, [SP]
    // 0x84fc94: LoadField: r2 = r1->field_17
    //     0x84fc94: ldur            w2, [x1, #0x17]
    // 0x84fc98: DecompressPointer r2
    //     0x84fc98: add             x2, x2, HEAP, lsl #32
    // 0x84fc9c: LoadField: r1 = r2->field_f
    //     0x84fc9c: ldur            w1, [x2, #0xf]
    // 0x84fca0: DecompressPointer r1
    //     0x84fca0: add             x1, x1, HEAP, lsl #32
    // 0x84fca4: LoadField: r3 = r2->field_13
    //     0x84fca4: ldur            w3, [x2, #0x13]
    // 0x84fca8: DecompressPointer r3
    //     0x84fca8: add             x3, x3, HEAP, lsl #32
    // 0x84fcac: LoadField: r0 = r3->field_f
    //     0x84fcac: ldur            w0, [x3, #0xf]
    // 0x84fcb0: DecompressPointer r0
    //     0x84fcb0: add             x0, x0, HEAP, lsl #32
    // 0x84fcb4: StoreField: r1->field_3f = r0
    //     0x84fcb4: stur            w0, [x1, #0x3f]
    //     0x84fcb8: ldurb           w16, [x1, #-1]
    //     0x84fcbc: ldurb           w17, [x0, #-1]
    //     0x84fcc0: and             x16, x17, x16, lsr #2
    //     0x84fcc4: tst             x16, HEAP, lsr #32
    //     0x84fcc8: b.eq            #0x84fcd8
    //     0x84fccc: str             lr, [SP, #-8]!
    //     0x84fcd0: bl              #0xd6826c
    //     0x84fcd4: ldr             lr, [SP], #8
    // 0x84fcd8: r0 = Null
    //     0x84fcd8: mov             x0, NULL
    // 0x84fcdc: ret
    //     0x84fcdc: ret             
  }
  Map<Type, Action<Intent>> _actionMap(__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin) {
    // ** addr: 0x84fce0, size: 0x158
    // 0x84fce0: EnterFrame
    //     0x84fce0: stp             fp, lr, [SP, #-0x10]!
    //     0x84fce4: mov             fp, SP
    // 0x84fce8: AllocStack(0x18)
    //     0x84fce8: sub             SP, SP, #0x18
    // 0x84fcec: CheckStackOverflow
    //     0x84fcec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fcf0: cmp             SP, x16
    //     0x84fcf4: b.ls            #0x84fe30
    // 0x84fcf8: r1 = Null
    //     0x84fcf8: mov             x1, NULL
    // 0x84fcfc: r2 = 4
    //     0x84fcfc: mov             x2, #4
    // 0x84fd00: r0 = AllocateArray()
    //     0x84fd00: bl              #0xd6987c  ; AllocateArrayStub
    // 0x84fd04: mov             x1, x0
    // 0x84fd08: stur            x1, [fp, #-8]
    // 0x84fd0c: r17 = ActivateIntent
    //     0x84fd0c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e460] Type: ActivateIntent
    //     0x84fd10: ldr             x17, [x17, #0x460]
    // 0x84fd14: StoreField: r1->field_f = r17
    //     0x84fd14: stur            w17, [x1, #0xf]
    // 0x84fd18: ldr             x0, [fp, #0x10]
    // 0x84fd1c: r2 = 59
    //     0x84fd1c: mov             x2, #0x3b
    // 0x84fd20: branchIfSmi(r0, 0x84fd2c)
    //     0x84fd20: tbz             w0, #0, #0x84fd2c
    // 0x84fd24: r2 = LoadClassIdInstr(r0)
    //     0x84fd24: ldur            x2, [x0, #-1]
    //     0x84fd28: ubfx            x2, x2, #0xc, #0x14
    // 0x84fd2c: SaveReg r0
    //     0x84fd2c: str             x0, [SP, #-8]!
    // 0x84fd30: mov             x0, x2
    // 0x84fd34: r0 = GDT[cid_x0 + -0x1000]()
    //     0x84fd34: sub             lr, x0, #1, lsl #12
    //     0x84fd38: ldr             lr, [x21, lr, lsl #3]
    //     0x84fd3c: blr             lr
    // 0x84fd40: add             SP, SP, #8
    // 0x84fd44: r1 = <ActivateIntent>
    //     0x84fd44: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e468] TypeArguments: <ActivateIntent>
    //     0x84fd48: ldr             x1, [x1, #0x468]
    // 0x84fd4c: stur            x0, [fp, #-0x10]
    // 0x84fd50: r0 = CallbackAction()
    //     0x84fd50: bl              #0x837e0c  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0x84fd54: mov             x2, x0
    // 0x84fd58: ldur            x0, [fp, #-0x10]
    // 0x84fd5c: stur            x2, [fp, #-0x18]
    // 0x84fd60: StoreField: r2->field_13 = r0
    //     0x84fd60: stur            w0, [x2, #0x13]
    // 0x84fd64: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0x84fd64: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x84fd68: ldr             x1, [x1, #0xcc0]
    // 0x84fd6c: r0 = ObserverList()
    //     0x84fd6c: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x84fd70: mov             x1, x0
    // 0x84fd74: r0 = false
    //     0x84fd74: add             x0, NULL, #0x30  ; false
    // 0x84fd78: stur            x1, [fp, #-0x10]
    // 0x84fd7c: StoreField: r1->field_f = r0
    //     0x84fd7c: stur            w0, [x1, #0xf]
    // 0x84fd80: r0 = Sentinel
    //     0x84fd80: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84fd84: StoreField: r1->field_13 = r0
    //     0x84fd84: stur            w0, [x1, #0x13]
    // 0x84fd88: r16 = <(dynamic this, Action<Intent>) => void?>
    //     0x84fd88: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x84fd8c: ldr             x16, [x16, #0xcc0]
    // 0x84fd90: stp             xzr, x16, [SP, #-0x10]!
    // 0x84fd94: r0 = _GrowableList()
    //     0x84fd94: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x84fd98: add             SP, SP, #0x10
    // 0x84fd9c: ldur            x1, [fp, #-0x10]
    // 0x84fda0: StoreField: r1->field_b = r0
    //     0x84fda0: stur            w0, [x1, #0xb]
    //     0x84fda4: ldurb           w16, [x1, #-1]
    //     0x84fda8: ldurb           w17, [x0, #-1]
    //     0x84fdac: and             x16, x17, x16, lsr #2
    //     0x84fdb0: tst             x16, HEAP, lsr #32
    //     0x84fdb4: b.eq            #0x84fdbc
    //     0x84fdb8: bl              #0xd6826c
    // 0x84fdbc: mov             x0, x1
    // 0x84fdc0: ldur            x1, [fp, #-0x18]
    // 0x84fdc4: StoreField: r1->field_b = r0
    //     0x84fdc4: stur            w0, [x1, #0xb]
    //     0x84fdc8: ldurb           w16, [x1, #-1]
    //     0x84fdcc: ldurb           w17, [x0, #-1]
    //     0x84fdd0: and             x16, x17, x16, lsr #2
    //     0x84fdd4: tst             x16, HEAP, lsr #32
    //     0x84fdd8: b.eq            #0x84fde0
    //     0x84fddc: bl              #0xd6826c
    // 0x84fde0: mov             x0, x1
    // 0x84fde4: ldur            x1, [fp, #-8]
    // 0x84fde8: ArrayStore: r1[1] = r0  ; List_4
    //     0x84fde8: add             x25, x1, #0x13
    //     0x84fdec: str             w0, [x25]
    //     0x84fdf0: tbz             w0, #0, #0x84fe0c
    //     0x84fdf4: ldurb           w16, [x1, #-1]
    //     0x84fdf8: ldurb           w17, [x0, #-1]
    //     0x84fdfc: and             x16, x17, x16, lsr #2
    //     0x84fe00: tst             x16, HEAP, lsr #32
    //     0x84fe04: b.eq            #0x84fe0c
    //     0x84fe08: bl              #0xd67e5c
    // 0x84fe0c: r16 = <Type, Action<Intent>>
    //     0x84fe0c: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e40] TypeArguments: <Type, Action<Intent>>
    //     0x84fe10: ldr             x16, [x16, #0xe40]
    // 0x84fe14: ldur            lr, [fp, #-8]
    // 0x84fe18: stp             lr, x16, [SP, #-0x10]!
    // 0x84fe1c: r0 = Map._fromLiteral()
    //     0x84fe1c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x84fe20: add             SP, SP, #0x10
    // 0x84fe24: LeaveFrame
    //     0x84fe24: mov             SP, fp
    //     0x84fe28: ldp             fp, lr, [SP], #0x10
    // 0x84fe2c: ret
    //     0x84fe2c: ret             
    // 0x84fe30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84fe30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84fe34: b               #0x84fcf8
  }
  get _ states(/* No info */) {
    // ** addr: 0x8510b4, size: 0x13c
    // 0x8510b4: EnterFrame
    //     0x8510b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8510b8: mov             fp, SP
    // 0x8510bc: AllocStack(0x10)
    //     0x8510bc: sub             SP, SP, #0x10
    // 0x8510c0: CheckStackOverflow
    //     0x8510c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8510c4: cmp             SP, x16
    //     0x8510c8: b.ls            #0x8511e0
    // 0x8510cc: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x8510cc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8510d0: ldr             x0, [x0, #0x598]
    //     0x8510d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8510d8: cmp             w0, w16
    //     0x8510dc: b.ne            #0x8510e8
    //     0x8510e0: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x8510e4: bl              #0xd67cdc
    // 0x8510e8: r1 = <MaterialState>
    //     0x8510e8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x8510ec: ldr             x1, [x1, #0xcf0]
    // 0x8510f0: stur            x0, [fp, #-8]
    // 0x8510f4: r0 = _Set()
    //     0x8510f4: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x8510f8: mov             x1, x0
    // 0x8510fc: ldur            x0, [fp, #-8]
    // 0x851100: stur            x1, [fp, #-0x10]
    // 0x851104: StoreField: r1->field_1b = r0
    //     0x851104: stur            w0, [x1, #0x1b]
    // 0x851108: StoreField: r1->field_b = rZR
    //     0x851108: stur            wzr, [x1, #0xb]
    // 0x85110c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x85110c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x851110: ldr             x0, [x0, #0x5a0]
    //     0x851114: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x851118: cmp             w0, w16
    //     0x85111c: b.ne            #0x851128
    //     0x851120: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x851124: bl              #0xd67cdc
    // 0x851128: mov             x1, x0
    // 0x85112c: ldur            x0, [fp, #-0x10]
    // 0x851130: StoreField: r0->field_f = r1
    //     0x851130: stur            w1, [x0, #0xf]
    // 0x851134: StoreField: r0->field_13 = rZR
    //     0x851134: stur            wzr, [x0, #0x13]
    // 0x851138: StoreField: r0->field_17 = rZR
    //     0x851138: stur            wzr, [x0, #0x17]
    // 0x85113c: ldr             x1, [fp, #0x10]
    // 0x851140: LoadField: r2 = r1->field_b
    //     0x851140: ldur            w2, [x1, #0xb]
    // 0x851144: DecompressPointer r2
    //     0x851144: add             x2, x2, HEAP, lsl #32
    // 0x851148: cmp             w2, NULL
    // 0x85114c: b.eq            #0x8511e8
    // 0x851150: LoadField: r2 = r1->field_47
    //     0x851150: ldur            w2, [x1, #0x47]
    // 0x851154: DecompressPointer r2
    //     0x851154: add             x2, x2, HEAP, lsl #32
    // 0x851158: tbnz            w2, #4, #0x851170
    // 0x85115c: r16 = Instance_MaterialState
    //     0x85115c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x851160: ldr             x16, [x16, #0xf78]
    // 0x851164: stp             x16, x0, [SP, #-0x10]!
    // 0x851168: r0 = add()
    //     0x851168: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x85116c: add             SP, SP, #0x10
    // 0x851170: ldr             x0, [fp, #0x10]
    // 0x851174: LoadField: r1 = r0->field_43
    //     0x851174: ldur            w1, [x0, #0x43]
    // 0x851178: DecompressPointer r1
    //     0x851178: add             x1, x1, HEAP, lsl #32
    // 0x85117c: tbnz            w1, #4, #0x851198
    // 0x851180: ldur            x16, [fp, #-0x10]
    // 0x851184: r30 = Instance_MaterialState
    //     0x851184: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x851188: ldr             lr, [lr, #0xf88]
    // 0x85118c: stp             lr, x16, [SP, #-0x10]!
    // 0x851190: r0 = add()
    //     0x851190: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x851194: add             SP, SP, #0x10
    // 0x851198: ldr             x0, [fp, #0x10]
    // 0x85119c: LoadField: r1 = r0->field_b
    //     0x85119c: ldur            w1, [x0, #0xb]
    // 0x8511a0: DecompressPointer r1
    //     0x8511a0: add             x1, x1, HEAP, lsl #32
    // 0x8511a4: cmp             w1, NULL
    // 0x8511a8: b.eq            #0x8511ec
    // 0x8511ac: LoadField: r0 = r1->field_b
    //     0x8511ac: ldur            w0, [x1, #0xb]
    // 0x8511b0: DecompressPointer r0
    //     0x8511b0: add             x0, x0, HEAP, lsl #32
    // 0x8511b4: tbnz            w0, #4, #0x8511d0
    // 0x8511b8: ldur            x16, [fp, #-0x10]
    // 0x8511bc: r30 = Instance_MaterialState
    //     0x8511bc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x8511c0: ldr             lr, [lr, #0xf70]
    // 0x8511c4: stp             lr, x16, [SP, #-0x10]!
    // 0x8511c8: r0 = add()
    //     0x8511c8: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x8511cc: add             SP, SP, #0x10
    // 0x8511d0: ldur            x0, [fp, #-0x10]
    // 0x8511d4: LeaveFrame
    //     0x8511d4: mov             SP, fp
    //     0x8511d8: ldp             fp, lr, [SP], #0x10
    // 0x8511dc: ret
    //     0x8511dc: ret             
    // 0x8511e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8511e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8511e4: b               #0x8510cc
    // 0x8511e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8511e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8511ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8511ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d955c, size: 0x414
    // 0x9d955c: EnterFrame
    //     0x9d955c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9560: mov             fp, SP
    // 0x9d9564: AllocStack(0x10)
    //     0x9d9564: sub             SP, SP, #0x10
    // 0x9d9568: CheckStackOverflow
    //     0x9d9568: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d956c: cmp             SP, x16
    //     0x9d9570: b.ls            #0x9d991c
    // 0x9d9574: ldr             x16, [fp, #0x10]
    // 0x9d9578: SaveReg r16
    //     0x9d9578: str             x16, [SP, #-8]!
    // 0x9d957c: r0 = exoPlayerConfig()
    //     0x9d957c: bl              #0xce589c  ; [package:flutter3_frame/core/components/exo_player/exo_player_short_view.dart] _ExoPlayerShortViewState::exoPlayerConfig
    // 0x9d9580: add             SP, SP, #8
    // 0x9d9584: tbz             w0, #4, #0x9d9590
    // 0x9d9588: d0 = 0.000000
    //     0x9d9588: eor             v0.16b, v0.16b, v0.16b
    // 0x9d958c: b               #0x9d9594
    // 0x9d9590: d0 = 1.000000
    //     0x9d9590: fmov            d0, #1.00000000
    // 0x9d9594: ldr             x0, [fp, #0x10]
    // 0x9d9598: r2 = inline_Allocate_Double()
    //     0x9d9598: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0x9d959c: add             x2, x2, #0x10
    //     0x9d95a0: cmp             x1, x2
    //     0x9d95a4: b.ls            #0x9d9924
    //     0x9d95a8: str             x2, [THR, #0x60]  ; THR::top
    //     0x9d95ac: sub             x2, x2, #0xf
    //     0x9d95b0: mov             x1, #0xd108
    //     0x9d95b4: movk            x1, #3, lsl #16
    //     0x9d95b8: stur            x1, [x2, #-1]
    // 0x9d95bc: StoreField: r2->field_7 = d0
    //     0x9d95bc: stur            d0, [x2, #7]
    // 0x9d95c0: stur            x2, [fp, #-8]
    // 0x9d95c4: r1 = <double>
    //     0x9d95c4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d95c8: r0 = AnimationController()
    //     0x9d95c8: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d95cc: stur            x0, [fp, #-0x10]
    // 0x9d95d0: ldr             x16, [fp, #0x10]
    // 0x9d95d4: stp             x16, x0, [SP, #-0x10]!
    // 0x9d95d8: r16 = Instance_Duration
    //     0x9d95d8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d95dc: ldr             x16, [x16, #0x9e0]
    // 0x9d95e0: ldur            lr, [fp, #-8]
    // 0x9d95e4: stp             lr, x16, [SP, #-0x10]!
    // 0x9d95e8: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, value, 0x3, null]
    //     0x9d95e8: add             x4, PP, #0x40, lsl #12  ; [pp+0x40158] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "value", 0x3, Null]
    //     0x9d95ec: ldr             x4, [x4, #0x158]
    // 0x9d95f0: r0 = AnimationController()
    //     0x9d95f0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d95f4: add             SP, SP, #0x20
    // 0x9d95f8: ldur            x0, [fp, #-0x10]
    // 0x9d95fc: ldr             x2, [fp, #0x10]
    // 0x9d9600: StoreField: r2->field_1b = r0
    //     0x9d9600: stur            w0, [x2, #0x1b]
    //     0x9d9604: ldurb           w16, [x2, #-1]
    //     0x9d9608: ldurb           w17, [x0, #-1]
    //     0x9d960c: and             x16, x17, x16, lsr #2
    //     0x9d9610: tst             x16, HEAP, lsr #32
    //     0x9d9614: b.eq            #0x9d961c
    //     0x9d9618: bl              #0xd6828c
    // 0x9d961c: r1 = <double>
    //     0x9d961c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9620: r0 = CurvedAnimation()
    //     0x9d9620: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9d9624: stur            x0, [fp, #-8]
    // 0x9d9628: r16 = Instance_Cubic
    //     0x9d9628: add             x16, PP, #0x27, lsl #12  ; [pp+0x27110] Obj!Cubic<double>@b4f431
    //     0x9d962c: ldr             x16, [x16, #0x110]
    // 0x9d9630: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9634: ldur            x16, [fp, #-0x10]
    // 0x9d9638: r30 = Instance_Cubic
    //     0x9d9638: add             lr, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0x9d963c: ldr             lr, [lr, #0x970]
    // 0x9d9640: stp             lr, x16, [SP, #-0x10]!
    // 0x9d9644: r4 = const [0, 0x4, 0x4, 0x3, reverseCurve, 0x3, null]
    //     0x9d9644: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cb40] List(7) [0, 0x4, 0x4, 0x3, "reverseCurve", 0x3, Null]
    //     0x9d9648: ldr             x4, [x4, #0xb40]
    // 0x9d964c: r0 = CurvedAnimation()
    //     0x9d964c: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9d9650: add             SP, SP, #0x20
    // 0x9d9654: ldur            x0, [fp, #-8]
    // 0x9d9658: ldr             x2, [fp, #0x10]
    // 0x9d965c: StoreField: r2->field_1f = r0
    //     0x9d965c: stur            w0, [x2, #0x1f]
    //     0x9d9660: ldurb           w16, [x2, #-1]
    //     0x9d9664: ldurb           w17, [x0, #-1]
    //     0x9d9668: and             x16, x17, x16, lsr #2
    //     0x9d966c: tst             x16, HEAP, lsr #32
    //     0x9d9670: b.eq            #0x9d9678
    //     0x9d9674: bl              #0xd6828c
    // 0x9d9678: r1 = <double>
    //     0x9d9678: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d967c: r0 = AnimationController()
    //     0x9d967c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d9680: stur            x0, [fp, #-8]
    // 0x9d9684: ldr             x16, [fp, #0x10]
    // 0x9d9688: stp             x16, x0, [SP, #-0x10]!
    // 0x9d968c: r16 = Instance_Duration
    //     0x9d968c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x9d9690: ldr             x16, [x16, #0x9f0]
    // 0x9d9694: SaveReg r16
    //     0x9d9694: str             x16, [SP, #-8]!
    // 0x9d9698: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d9698: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d969c: ldr             x4, [x4, #0xa0]
    // 0x9d96a0: r0 = AnimationController()
    //     0x9d96a0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d96a4: add             SP, SP, #0x18
    // 0x9d96a8: ldur            x0, [fp, #-8]
    // 0x9d96ac: ldr             x2, [fp, #0x10]
    // 0x9d96b0: StoreField: r2->field_23 = r0
    //     0x9d96b0: stur            w0, [x2, #0x23]
    //     0x9d96b4: ldurb           w16, [x2, #-1]
    //     0x9d96b8: ldurb           w17, [x0, #-1]
    //     0x9d96bc: and             x16, x17, x16, lsr #2
    //     0x9d96c0: tst             x16, HEAP, lsr #32
    //     0x9d96c4: b.eq            #0x9d96cc
    //     0x9d96c8: bl              #0xd6828c
    // 0x9d96cc: r1 = <double>
    //     0x9d96cc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d96d0: r0 = CurvedAnimation()
    //     0x9d96d0: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9d96d4: stur            x0, [fp, #-0x10]
    // 0x9d96d8: r16 = Instance_Cubic
    //     0x9d96d8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x9d96dc: ldr             x16, [x16, #0x2c8]
    // 0x9d96e0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d96e4: ldur            x16, [fp, #-8]
    // 0x9d96e8: SaveReg r16
    //     0x9d96e8: str             x16, [SP, #-8]!
    // 0x9d96ec: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9d96ec: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9d96f0: r0 = CurvedAnimation()
    //     0x9d96f0: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9d96f4: add             SP, SP, #0x18
    // 0x9d96f8: ldur            x0, [fp, #-0x10]
    // 0x9d96fc: ldr             x2, [fp, #0x10]
    // 0x9d9700: StoreField: r2->field_27 = r0
    //     0x9d9700: stur            w0, [x2, #0x27]
    //     0x9d9704: ldurb           w16, [x2, #-1]
    //     0x9d9708: ldurb           w17, [x0, #-1]
    //     0x9d970c: and             x16, x17, x16, lsr #2
    //     0x9d9710: tst             x16, HEAP, lsr #32
    //     0x9d9714: b.eq            #0x9d971c
    //     0x9d9718: bl              #0xd6828c
    // 0x9d971c: LoadField: r0 = r2->field_47
    //     0x9d971c: ldur            w0, [x2, #0x47]
    // 0x9d9720: DecompressPointer r0
    //     0x9d9720: add             x0, x0, HEAP, lsl #32
    // 0x9d9724: tbz             w0, #4, #0x9d9734
    // 0x9d9728: LoadField: r0 = r2->field_43
    //     0x9d9728: ldur            w0, [x2, #0x43]
    // 0x9d972c: DecompressPointer r0
    //     0x9d972c: add             x0, x0, HEAP, lsl #32
    // 0x9d9730: tbnz            w0, #4, #0x9d973c
    // 0x9d9734: d0 = 1.000000
    //     0x9d9734: fmov            d0, #1.00000000
    // 0x9d9738: b               #0x9d9740
    // 0x9d973c: d0 = 0.000000
    //     0x9d973c: eor             v0.16b, v0.16b, v0.16b
    // 0x9d9740: r0 = inline_Allocate_Double()
    //     0x9d9740: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9d9744: add             x0, x0, #0x10
    //     0x9d9748: cmp             x1, x0
    //     0x9d974c: b.ls            #0x9d9940
    //     0x9d9750: str             x0, [THR, #0x60]  ; THR::top
    //     0x9d9754: sub             x0, x0, #0xf
    //     0x9d9758: mov             x1, #0xd108
    //     0x9d975c: movk            x1, #3, lsl #16
    //     0x9d9760: stur            x1, [x0, #-1]
    // 0x9d9764: StoreField: r0->field_7 = d0
    //     0x9d9764: stur            d0, [x0, #7]
    // 0x9d9768: stur            x0, [fp, #-8]
    // 0x9d976c: r1 = <double>
    //     0x9d976c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9770: r0 = AnimationController()
    //     0x9d9770: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d9774: stur            x0, [fp, #-0x10]
    // 0x9d9778: ldr             x16, [fp, #0x10]
    // 0x9d977c: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9780: r16 = Instance_Duration
    //     0x9d9780: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e8] Obj!Duration@b67b01
    //     0x9d9784: ldr             x16, [x16, #0x9e8]
    // 0x9d9788: ldur            lr, [fp, #-8]
    // 0x9d978c: stp             lr, x16, [SP, #-0x10]!
    // 0x9d9790: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, value, 0x3, null]
    //     0x9d9790: add             x4, PP, #0x40, lsl #12  ; [pp+0x40158] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "value", 0x3, Null]
    //     0x9d9794: ldr             x4, [x4, #0x158]
    // 0x9d9798: r0 = AnimationController()
    //     0x9d9798: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d979c: add             SP, SP, #0x20
    // 0x9d97a0: ldur            x0, [fp, #-0x10]
    // 0x9d97a4: ldr             x2, [fp, #0x10]
    // 0x9d97a8: StoreField: r2->field_2f = r0
    //     0x9d97a8: stur            w0, [x2, #0x2f]
    //     0x9d97ac: ldurb           w16, [x2, #-1]
    //     0x9d97b0: ldurb           w17, [x0, #-1]
    //     0x9d97b4: and             x16, x17, x16, lsr #2
    //     0x9d97b8: tst             x16, HEAP, lsr #32
    //     0x9d97bc: b.eq            #0x9d97c4
    //     0x9d97c0: bl              #0xd6828c
    // 0x9d97c4: r1 = <double>
    //     0x9d97c4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d97c8: r0 = CurvedAnimation()
    //     0x9d97c8: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9d97cc: stur            x0, [fp, #-8]
    // 0x9d97d0: r16 = Instance_Cubic
    //     0x9d97d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x9d97d4: ldr             x16, [x16, #0x2c8]
    // 0x9d97d8: stp             x16, x0, [SP, #-0x10]!
    // 0x9d97dc: ldur            x16, [fp, #-0x10]
    // 0x9d97e0: SaveReg r16
    //     0x9d97e0: str             x16, [SP, #-8]!
    // 0x9d97e4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9d97e4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9d97e8: r0 = CurvedAnimation()
    //     0x9d97e8: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9d97ec: add             SP, SP, #0x18
    // 0x9d97f0: ldur            x0, [fp, #-8]
    // 0x9d97f4: ldr             x2, [fp, #0x10]
    // 0x9d97f8: StoreField: r2->field_2b = r0
    //     0x9d97f8: stur            w0, [x2, #0x2b]
    //     0x9d97fc: ldurb           w16, [x2, #-1]
    //     0x9d9800: ldurb           w17, [x0, #-1]
    //     0x9d9804: and             x16, x17, x16, lsr #2
    //     0x9d9808: tst             x16, HEAP, lsr #32
    //     0x9d980c: b.eq            #0x9d9814
    //     0x9d9810: bl              #0xd6828c
    // 0x9d9814: LoadField: r0 = r2->field_47
    //     0x9d9814: ldur            w0, [x2, #0x47]
    // 0x9d9818: DecompressPointer r0
    //     0x9d9818: add             x0, x0, HEAP, lsl #32
    // 0x9d981c: tbz             w0, #4, #0x9d982c
    // 0x9d9820: LoadField: r0 = r2->field_43
    //     0x9d9820: ldur            w0, [x2, #0x43]
    // 0x9d9824: DecompressPointer r0
    //     0x9d9824: add             x0, x0, HEAP, lsl #32
    // 0x9d9828: tbnz            w0, #4, #0x9d9834
    // 0x9d982c: d0 = 1.000000
    //     0x9d982c: fmov            d0, #1.00000000
    // 0x9d9830: b               #0x9d9838
    // 0x9d9834: d0 = 0.000000
    //     0x9d9834: eor             v0.16b, v0.16b, v0.16b
    // 0x9d9838: r0 = inline_Allocate_Double()
    //     0x9d9838: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9d983c: add             x0, x0, #0x10
    //     0x9d9840: cmp             x1, x0
    //     0x9d9844: b.ls            #0x9d9958
    //     0x9d9848: str             x0, [THR, #0x60]  ; THR::top
    //     0x9d984c: sub             x0, x0, #0xf
    //     0x9d9850: mov             x1, #0xd108
    //     0x9d9854: movk            x1, #3, lsl #16
    //     0x9d9858: stur            x1, [x0, #-1]
    // 0x9d985c: StoreField: r0->field_7 = d0
    //     0x9d985c: stur            d0, [x0, #7]
    // 0x9d9860: stur            x0, [fp, #-8]
    // 0x9d9864: r1 = <double>
    //     0x9d9864: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d9868: r0 = AnimationController()
    //     0x9d9868: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d986c: stur            x0, [fp, #-0x10]
    // 0x9d9870: ldr             x16, [fp, #0x10]
    // 0x9d9874: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9878: r16 = Instance_Duration
    //     0x9d9878: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e8] Obj!Duration@b67b01
    //     0x9d987c: ldr             x16, [x16, #0x9e8]
    // 0x9d9880: ldur            lr, [fp, #-8]
    // 0x9d9884: stp             lr, x16, [SP, #-0x10]!
    // 0x9d9888: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, value, 0x3, null]
    //     0x9d9888: add             x4, PP, #0x40, lsl #12  ; [pp+0x40158] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "value", 0x3, Null]
    //     0x9d988c: ldr             x4, [x4, #0x158]
    // 0x9d9890: r0 = AnimationController()
    //     0x9d9890: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d9894: add             SP, SP, #0x20
    // 0x9d9898: ldur            x0, [fp, #-0x10]
    // 0x9d989c: ldr             x2, [fp, #0x10]
    // 0x9d98a0: StoreField: r2->field_37 = r0
    //     0x9d98a0: stur            w0, [x2, #0x37]
    //     0x9d98a4: ldurb           w16, [x2, #-1]
    //     0x9d98a8: ldurb           w17, [x0, #-1]
    //     0x9d98ac: and             x16, x17, x16, lsr #2
    //     0x9d98b0: tst             x16, HEAP, lsr #32
    //     0x9d98b4: b.eq            #0x9d98bc
    //     0x9d98b8: bl              #0xd6828c
    // 0x9d98bc: r1 = <double>
    //     0x9d98bc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d98c0: r0 = CurvedAnimation()
    //     0x9d98c0: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9d98c4: stur            x0, [fp, #-8]
    // 0x9d98c8: r16 = Instance_Cubic
    //     0x9d98c8: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x9d98cc: ldr             x16, [x16, #0x2c8]
    // 0x9d98d0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d98d4: ldur            x16, [fp, #-0x10]
    // 0x9d98d8: SaveReg r16
    //     0x9d98d8: str             x16, [SP, #-8]!
    // 0x9d98dc: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9d98dc: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9d98e0: r0 = CurvedAnimation()
    //     0x9d98e0: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9d98e4: add             SP, SP, #0x18
    // 0x9d98e8: ldur            x0, [fp, #-8]
    // 0x9d98ec: ldr             x1, [fp, #0x10]
    // 0x9d98f0: StoreField: r1->field_33 = r0
    //     0x9d98f0: stur            w0, [x1, #0x33]
    //     0x9d98f4: ldurb           w16, [x1, #-1]
    //     0x9d98f8: ldurb           w17, [x0, #-1]
    //     0x9d98fc: and             x16, x17, x16, lsr #2
    //     0x9d9900: tst             x16, HEAP, lsr #32
    //     0x9d9904: b.eq            #0x9d990c
    //     0x9d9908: bl              #0xd6826c
    // 0x9d990c: r0 = Null
    //     0x9d990c: mov             x0, NULL
    // 0x9d9910: LeaveFrame
    //     0x9d9910: mov             SP, fp
    //     0x9d9914: ldp             fp, lr, [SP], #0x10
    // 0x9d9918: ret
    //     0x9d9918: ret             
    // 0x9d991c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d991c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d9920: b               #0x9d9574
    // 0x9d9924: SaveReg d0
    //     0x9d9924: str             q0, [SP, #-0x10]!
    // 0x9d9928: SaveReg r0
    //     0x9d9928: str             x0, [SP, #-8]!
    // 0x9d992c: r0 = AllocateDouble()
    //     0x9d992c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x9d9930: mov             x2, x0
    // 0x9d9934: RestoreReg r0
    //     0x9d9934: ldr             x0, [SP], #8
    // 0x9d9938: RestoreReg d0
    //     0x9d9938: ldr             q0, [SP], #0x10
    // 0x9d993c: b               #0x9d95bc
    // 0x9d9940: SaveReg d0
    //     0x9d9940: str             q0, [SP, #-0x10]!
    // 0x9d9944: SaveReg r2
    //     0x9d9944: str             x2, [SP, #-8]!
    // 0x9d9948: r0 = AllocateDouble()
    //     0x9d9948: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x9d994c: RestoreReg r2
    //     0x9d994c: ldr             x2, [SP], #8
    // 0x9d9950: RestoreReg d0
    //     0x9d9950: ldr             q0, [SP], #0x10
    // 0x9d9954: b               #0x9d9764
    // 0x9d9958: SaveReg d0
    //     0x9d9958: str             q0, [SP, #-0x10]!
    // 0x9d995c: SaveReg r2
    //     0x9d995c: str             x2, [SP, #-8]!
    // 0x9d9960: r0 = AllocateDouble()
    //     0x9d9960: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x9d9964: RestoreReg r2
    //     0x9d9964: ldr             x2, [SP], #8
    // 0x9d9968: RestoreReg d0
    //     0x9d9968: ldr             q0, [SP], #0x10
    // 0x9d996c: b               #0x9d985c
  }
  _ __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin(/* No info */) {
    // ** addr: 0xa40444, size: 0x40
    // 0xa40444: r2 = Sentinel
    //     0xa40444: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40448: r1 = false
    //     0xa40448: add             x1, NULL, #0x30  ; false
    // 0xa4044c: ldr             x3, [SP]
    // 0xa40450: StoreField: r3->field_1b = r2
    //     0xa40450: stur            w2, [x3, #0x1b]
    // 0xa40454: StoreField: r3->field_1f = r2
    //     0xa40454: stur            w2, [x3, #0x1f]
    // 0xa40458: StoreField: r3->field_23 = r2
    //     0xa40458: stur            w2, [x3, #0x23]
    // 0xa4045c: StoreField: r3->field_27 = r2
    //     0xa4045c: stur            w2, [x3, #0x27]
    // 0xa40460: StoreField: r3->field_2b = r2
    //     0xa40460: stur            w2, [x3, #0x2b]
    // 0xa40464: StoreField: r3->field_2f = r2
    //     0xa40464: stur            w2, [x3, #0x2f]
    // 0xa40468: StoreField: r3->field_33 = r2
    //     0xa40468: stur            w2, [x3, #0x33]
    // 0xa4046c: StoreField: r3->field_37 = r2
    //     0xa4046c: stur            w2, [x3, #0x37]
    // 0xa40470: StoreField: r3->field_3b = r2
    //     0xa40470: stur            w2, [x3, #0x3b]
    // 0xa40474: StoreField: r3->field_43 = r1
    //     0xa40474: stur            w1, [x3, #0x43]
    // 0xa40478: StoreField: r3->field_47 = r1
    //     0xa40478: stur            w1, [x3, #0x47]
    // 0xa4047c: r0 = Null
    //     0xa4047c: mov             x0, NULL
    // 0xa40480: ret
    //     0xa40480: ret             
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa51318, size: 0xfc
    // 0xa51318: EnterFrame
    //     0xa51318: stp             fp, lr, [SP, #-0x10]!
    //     0xa5131c: mov             fp, SP
    // 0xa51320: CheckStackOverflow
    //     0xa51320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51324: cmp             SP, x16
    //     0xa51328: b.ls            #0xa513dc
    // 0xa5132c: ldr             x0, [fp, #0x10]
    // 0xa51330: LoadField: r1 = r0->field_1b
    //     0xa51330: ldur            w1, [x0, #0x1b]
    // 0xa51334: DecompressPointer r1
    //     0xa51334: add             x1, x1, HEAP, lsl #32
    // 0xa51338: r16 = Sentinel
    //     0xa51338: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5133c: cmp             w1, w16
    // 0xa51340: b.eq            #0xa513e4
    // 0xa51344: SaveReg r1
    //     0xa51344: str             x1, [SP, #-8]!
    // 0xa51348: r0 = dispose()
    //     0xa51348: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa5134c: add             SP, SP, #8
    // 0xa51350: ldr             x0, [fp, #0x10]
    // 0xa51354: LoadField: r1 = r0->field_23
    //     0xa51354: ldur            w1, [x0, #0x23]
    // 0xa51358: DecompressPointer r1
    //     0xa51358: add             x1, x1, HEAP, lsl #32
    // 0xa5135c: r16 = Sentinel
    //     0xa5135c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa51360: cmp             w1, w16
    // 0xa51364: b.eq            #0xa513f0
    // 0xa51368: SaveReg r1
    //     0xa51368: str             x1, [SP, #-8]!
    // 0xa5136c: r0 = dispose()
    //     0xa5136c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa51370: add             SP, SP, #8
    // 0xa51374: ldr             x0, [fp, #0x10]
    // 0xa51378: LoadField: r1 = r0->field_2f
    //     0xa51378: ldur            w1, [x0, #0x2f]
    // 0xa5137c: DecompressPointer r1
    //     0xa5137c: add             x1, x1, HEAP, lsl #32
    // 0xa51380: r16 = Sentinel
    //     0xa51380: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa51384: cmp             w1, w16
    // 0xa51388: b.eq            #0xa513fc
    // 0xa5138c: SaveReg r1
    //     0xa5138c: str             x1, [SP, #-8]!
    // 0xa51390: r0 = dispose()
    //     0xa51390: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa51394: add             SP, SP, #8
    // 0xa51398: ldr             x0, [fp, #0x10]
    // 0xa5139c: LoadField: r1 = r0->field_37
    //     0xa5139c: ldur            w1, [x0, #0x37]
    // 0xa513a0: DecompressPointer r1
    //     0xa513a0: add             x1, x1, HEAP, lsl #32
    // 0xa513a4: r16 = Sentinel
    //     0xa513a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa513a8: cmp             w1, w16
    // 0xa513ac: b.eq            #0xa51408
    // 0xa513b0: SaveReg r1
    //     0xa513b0: str             x1, [SP, #-8]!
    // 0xa513b4: r0 = dispose()
    //     0xa513b4: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa513b8: add             SP, SP, #8
    // 0xa513bc: ldr             x16, [fp, #0x10]
    // 0xa513c0: SaveReg r16
    //     0xa513c0: str             x16, [SP, #-8]!
    // 0xa513c4: r0 = dispose()
    //     0xa513c4: bl              #0xa5145c  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin::dispose
    // 0xa513c8: add             SP, SP, #8
    // 0xa513cc: r0 = Null
    //     0xa513cc: mov             x0, NULL
    // 0xa513d0: LeaveFrame
    //     0xa513d0: mov             SP, fp
    //     0xa513d4: ldp             fp, lr, [SP], #0x10
    // 0xa513d8: ret
    //     0xa513d8: ret             
    // 0xa513dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa513dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa513e0: b               #0xa5132c
    // 0xa513e4: r9 = _positionController
    //     0xa513e4: add             x9, PP, #0x56, lsl #12  ; [pp+0x564e0] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._positionController@837519154>: late (offset: 0x1c)
    //     0xa513e8: ldr             x9, [x9, #0x4e0]
    // 0xa513ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa513ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa513f0: r9 = _reactionController
    //     0xa513f0: add             x9, PP, #0x56, lsl #12  ; [pp+0x564e8] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionController@837519154>: late (offset: 0x24)
    //     0xa513f4: ldr             x9, [x9, #0x4e8]
    // 0xa513f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa513f8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa513fc: r9 = _reactionHoverFadeController
    //     0xa513fc: add             x9, PP, #0x56, lsl #12  ; [pp+0x564f0] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionHoverFadeController@837519154>: late (offset: 0x30)
    //     0xa51400: ldr             x9, [x9, #0x4f0]
    // 0xa51404: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa51404: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa51408: r9 = _reactionFocusFadeController
    //     0xa51408: add             x9, PP, #0x56, lsl #12  ; [pp+0x564f8] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionFocusFadeController@837519154>: late (offset: 0x38)
    //     0xa5140c: ldr             x9, [x9, #0x4f8]
    // 0xa51410: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa51410: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa51414, size: 0x48
    // 0xa51414: EnterFrame
    //     0xa51414: stp             fp, lr, [SP, #-0x10]!
    //     0xa51418: mov             fp, SP
    // 0xa5141c: ldr             x0, [fp, #0x10]
    // 0xa51420: LoadField: r1 = r0->field_17
    //     0xa51420: ldur            w1, [x0, #0x17]
    // 0xa51424: DecompressPointer r1
    //     0xa51424: add             x1, x1, HEAP, lsl #32
    // 0xa51428: CheckStackOverflow
    //     0xa51428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5142c: cmp             SP, x16
    //     0xa51430: b.ls            #0xa51454
    // 0xa51434: LoadField: r0 = r1->field_f
    //     0xa51434: ldur            w0, [x1, #0xf]
    // 0xa51438: DecompressPointer r0
    //     0xa51438: add             x0, x0, HEAP, lsl #32
    // 0xa5143c: SaveReg r0
    //     0xa5143c: str             x0, [SP, #-8]!
    // 0xa51440: r0 = dispose()
    //     0xa51440: bl              #0xa51318  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::dispose
    // 0xa51444: add             SP, SP, #8
    // 0xa51448: LeaveFrame
    //     0xa51448: mov             SP, fp
    //     0xa5144c: ldp             fp, lr, [SP], #0x10
    // 0xa51450: ret
    //     0xa51450: ret             
    // 0xa51454: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51454: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51458: b               #0xa51434
  }
  dynamic _handleTap(dynamic) {
    // ** addr: 0xce3e84, size: 0x18
    // 0xce3e84: r4 = 7
    //     0xce3e84: mov             x4, #7
    // 0xce3e88: r1 = Function '_handleTap@837519154':.
    //     0xce3e88: add             x17, PP, #0x56, lsl #12  ; [pp+0x56598] AnonymousClosure: (0x84fa18), in [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::_handleTap (0x84fa94)
    //     0xce3e8c: ldr             x1, [x17, #0x598]
    // 0xce3e90: r24 = BuildNonGenericMethodExtractorStub
    //     0xce3e90: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xce3e94: LoadField: r0 = r24->field_17
    //     0xce3e94: ldur            x0, [x24, #0x17]
    // 0xce3e98: br              x0
  }
}

// class id: 3332, size: 0x54, field offset: 0x4c
class _CheckboxState extends __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b0c9c, size: 0xe8
    // 0x7b0c9c: EnterFrame
    //     0x7b0c9c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0ca0: mov             fp, SP
    // 0x7b0ca4: CheckStackOverflow
    //     0x7b0ca4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0ca8: cmp             SP, x16
    //     0x7b0cac: b.ls            #0x7b0d78
    // 0x7b0cb0: ldr             x0, [fp, #0x10]
    // 0x7b0cb4: r2 = Null
    //     0x7b0cb4: mov             x2, NULL
    // 0x7b0cb8: r1 = Null
    //     0x7b0cb8: mov             x1, NULL
    // 0x7b0cbc: r4 = 59
    //     0x7b0cbc: mov             x4, #0x3b
    // 0x7b0cc0: branchIfSmi(r0, 0x7b0ccc)
    //     0x7b0cc0: tbz             w0, #0, #0x7b0ccc
    // 0x7b0cc4: r4 = LoadClassIdInstr(r0)
    //     0x7b0cc4: ldur            x4, [x0, #-1]
    //     0x7b0cc8: ubfx            x4, x4, #0xc, #0x14
    // 0x7b0ccc: r17 = 4159
    //     0x7b0ccc: mov             x17, #0x103f
    // 0x7b0cd0: cmp             x4, x17
    // 0x7b0cd4: b.eq            #0x7b0cec
    // 0x7b0cd8: r8 = Checkbox
    //     0x7b0cd8: add             x8, PP, #0x56, lsl #12  ; [pp+0x565e8] Type: Checkbox
    //     0x7b0cdc: ldr             x8, [x8, #0x5e8]
    // 0x7b0ce0: r3 = Null
    //     0x7b0ce0: add             x3, PP, #0x56, lsl #12  ; [pp+0x565f0] Null
    //     0x7b0ce4: ldr             x3, [x3, #0x5f0]
    // 0x7b0ce8: r0 = Checkbox()
    //     0x7b0ce8: bl              #0x6168a8  ; IsType_Checkbox_Stub
    // 0x7b0cec: ldr             x3, [fp, #0x18]
    // 0x7b0cf0: LoadField: r2 = r3->field_7
    //     0x7b0cf0: ldur            w2, [x3, #7]
    // 0x7b0cf4: DecompressPointer r2
    //     0x7b0cf4: add             x2, x2, HEAP, lsl #32
    // 0x7b0cf8: ldr             x0, [fp, #0x10]
    // 0x7b0cfc: r1 = Null
    //     0x7b0cfc: mov             x1, NULL
    // 0x7b0d00: cmp             w2, NULL
    // 0x7b0d04: b.eq            #0x7b0d28
    // 0x7b0d08: LoadField: r4 = r2->field_17
    //     0x7b0d08: ldur            w4, [x2, #0x17]
    // 0x7b0d0c: DecompressPointer r4
    //     0x7b0d0c: add             x4, x4, HEAP, lsl #32
    // 0x7b0d10: r8 = X0 bound StatefulWidget
    //     0x7b0d10: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b0d14: ldr             x8, [x8, #0x858]
    // 0x7b0d18: LoadField: r9 = r4->field_7
    //     0x7b0d18: ldur            x9, [x4, #7]
    // 0x7b0d1c: r3 = Null
    //     0x7b0d1c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56600] Null
    //     0x7b0d20: ldr             x3, [x3, #0x600]
    // 0x7b0d24: blr             x9
    // 0x7b0d28: ldr             x0, [fp, #0x10]
    // 0x7b0d2c: LoadField: r1 = r0->field_b
    //     0x7b0d2c: ldur            w1, [x0, #0xb]
    // 0x7b0d30: DecompressPointer r1
    //     0x7b0d30: add             x1, x1, HEAP, lsl #32
    // 0x7b0d34: ldr             x0, [fp, #0x18]
    // 0x7b0d38: LoadField: r2 = r0->field_b
    //     0x7b0d38: ldur            w2, [x0, #0xb]
    // 0x7b0d3c: DecompressPointer r2
    //     0x7b0d3c: add             x2, x2, HEAP, lsl #32
    // 0x7b0d40: cmp             w2, NULL
    // 0x7b0d44: b.eq            #0x7b0d80
    // 0x7b0d48: LoadField: r3 = r2->field_b
    //     0x7b0d48: ldur            w3, [x2, #0xb]
    // 0x7b0d4c: DecompressPointer r3
    //     0x7b0d4c: add             x3, x3, HEAP, lsl #32
    // 0x7b0d50: cmp             w1, w3
    // 0x7b0d54: b.eq            #0x7b0d68
    // 0x7b0d58: StoreField: r0->field_4f = r1
    //     0x7b0d58: stur            w1, [x0, #0x4f]
    // 0x7b0d5c: SaveReg r0
    //     0x7b0d5c: str             x0, [SP, #-8]!
    // 0x7b0d60: r0 = animateToValue()
    //     0x7b0d60: bl              #0x7b0d84  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::animateToValue
    // 0x7b0d64: add             SP, SP, #8
    // 0x7b0d68: r0 = Null
    //     0x7b0d68: mov             x0, NULL
    // 0x7b0d6c: LeaveFrame
    //     0x7b0d6c: mov             SP, fp
    //     0x7b0d70: ldp             fp, lr, [SP], #0x10
    // 0x7b0d74: ret
    //     0x7b0d74: ret             
    // 0x7b0d78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0d78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0d7c: b               #0x7b0cb0
    // 0x7b0d80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0d80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x84e050, size: 0x10d0
    // 0x84e050: EnterFrame
    //     0x84e050: stp             fp, lr, [SP, #-0x10]!
    //     0x84e054: mov             fp, SP
    // 0x84e058: AllocStack(0x70)
    //     0x84e058: sub             SP, SP, #0x70
    // 0x84e05c: CheckStackOverflow
    //     0x84e05c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84e060: cmp             SP, x16
    //     0x84e064: b.ls            #0x84f088
    // 0x84e068: r1 = 2
    //     0x84e068: mov             x1, #2
    // 0x84e06c: r0 = AllocateContext()
    //     0x84e06c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e070: mov             x1, x0
    // 0x84e074: ldr             x0, [fp, #0x18]
    // 0x84e078: stur            x1, [fp, #-8]
    // 0x84e07c: StoreField: r1->field_f = r0
    //     0x84e07c: stur            w0, [x1, #0xf]
    // 0x84e080: ldr             x16, [fp, #0x10]
    // 0x84e084: SaveReg r16
    //     0x84e084: str             x16, [SP, #-8]!
    // 0x84e088: r0 = of()
    //     0x84e088: bl              #0x851208  ; [package:flutter/src/material/checkbox_theme.dart] CheckboxTheme::of
    // 0x84e08c: add             SP, SP, #8
    // 0x84e090: mov             x1, x0
    // 0x84e094: ldur            x2, [fp, #-8]
    // 0x84e098: stur            x1, [fp, #-0x10]
    // 0x84e09c: StoreField: r2->field_13 = r0
    //     0x84e09c: stur            w0, [x2, #0x13]
    //     0x84e0a0: ldurb           w16, [x2, #-1]
    //     0x84e0a4: ldurb           w17, [x0, #-1]
    //     0x84e0a8: and             x16, x17, x16, lsr #2
    //     0x84e0ac: tst             x16, HEAP, lsr #32
    //     0x84e0b0: b.eq            #0x84e0b8
    //     0x84e0b4: bl              #0xd6828c
    // 0x84e0b8: ldr             x16, [fp, #0x10]
    // 0x84e0bc: SaveReg r16
    //     0x84e0bc: str             x16, [SP, #-8]!
    // 0x84e0c0: r0 = of()
    //     0x84e0c0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84e0c4: add             SP, SP, #8
    // 0x84e0c8: LoadField: r1 = r0->field_2b
    //     0x84e0c8: ldur            w1, [x0, #0x2b]
    // 0x84e0cc: DecompressPointer r1
    //     0x84e0cc: add             x1, x1, HEAP, lsl #32
    // 0x84e0d0: tbnz            w1, #4, #0x84e13c
    // 0x84e0d4: ldr             x16, [fp, #0x10]
    // 0x84e0d8: SaveReg r16
    //     0x84e0d8: str             x16, [SP, #-8]!
    // 0x84e0dc: r0 = of()
    //     0x84e0dc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84e0e0: add             SP, SP, #8
    // 0x84e0e4: stur            x0, [fp, #-0x18]
    // 0x84e0e8: r0 = _CheckboxDefaultsM3()
    //     0x84e0e8: bl              #0x8511fc  ; Allocate_CheckboxDefaultsM3Stub -> _CheckboxDefaultsM3 (size=0x34)
    // 0x84e0ec: mov             x1, x0
    // 0x84e0f0: ldur            x0, [fp, #-0x18]
    // 0x84e0f4: stur            x1, [fp, #-0x20]
    // 0x84e0f8: StoreField: r1->field_2b = r0
    //     0x84e0f8: stur            w0, [x1, #0x2b]
    // 0x84e0fc: ldr             x16, [fp, #0x10]
    // 0x84e100: SaveReg r16
    //     0x84e100: str             x16, [SP, #-8]!
    // 0x84e104: r0 = of()
    //     0x84e104: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84e108: add             SP, SP, #8
    // 0x84e10c: LoadField: r1 = r0->field_3f
    //     0x84e10c: ldur            w1, [x0, #0x3f]
    // 0x84e110: DecompressPointer r1
    //     0x84e110: add             x1, x1, HEAP, lsl #32
    // 0x84e114: mov             x0, x1
    // 0x84e118: ldur            x1, [fp, #-0x20]
    // 0x84e11c: StoreField: r1->field_2f = r0
    //     0x84e11c: stur            w0, [x1, #0x2f]
    //     0x84e120: ldurb           w16, [x1, #-1]
    //     0x84e124: ldurb           w17, [x0, #-1]
    //     0x84e128: and             x16, x17, x16, lsr #2
    //     0x84e12c: tst             x16, HEAP, lsr #32
    //     0x84e130: b.eq            #0x84e138
    //     0x84e134: bl              #0xd6826c
    // 0x84e138: b               #0x84e1a0
    // 0x84e13c: ldr             x16, [fp, #0x10]
    // 0x84e140: SaveReg r16
    //     0x84e140: str             x16, [SP, #-8]!
    // 0x84e144: r0 = of()
    //     0x84e144: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84e148: add             SP, SP, #8
    // 0x84e14c: stur            x0, [fp, #-0x18]
    // 0x84e150: r0 = _CheckboxDefaultsM2()
    //     0x84e150: bl              #0x8511f0  ; Allocate_CheckboxDefaultsM2Stub -> _CheckboxDefaultsM2 (size=0x34)
    // 0x84e154: mov             x1, x0
    // 0x84e158: ldur            x0, [fp, #-0x18]
    // 0x84e15c: stur            x1, [fp, #-0x20]
    // 0x84e160: StoreField: r1->field_2b = r0
    //     0x84e160: stur            w0, [x1, #0x2b]
    // 0x84e164: ldr             x16, [fp, #0x10]
    // 0x84e168: SaveReg r16
    //     0x84e168: str             x16, [SP, #-8]!
    // 0x84e16c: r0 = of()
    //     0x84e16c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84e170: add             SP, SP, #8
    // 0x84e174: LoadField: r1 = r0->field_3f
    //     0x84e174: ldur            w1, [x0, #0x3f]
    // 0x84e178: DecompressPointer r1
    //     0x84e178: add             x1, x1, HEAP, lsl #32
    // 0x84e17c: mov             x0, x1
    // 0x84e180: ldur            x1, [fp, #-0x20]
    // 0x84e184: StoreField: r1->field_2f = r0
    //     0x84e184: stur            w0, [x1, #0x2f]
    //     0x84e188: ldurb           w16, [x1, #-1]
    //     0x84e18c: ldurb           w17, [x0, #-1]
    //     0x84e190: and             x16, x17, x16, lsr #2
    //     0x84e194: tst             x16, HEAP, lsr #32
    //     0x84e198: b.eq            #0x84e1a0
    //     0x84e19c: bl              #0xd6826c
    // 0x84e1a0: ldr             x0, [fp, #0x18]
    // 0x84e1a4: stur            x1, [fp, #-0x20]
    // 0x84e1a8: LoadField: r2 = r0->field_b
    //     0x84e1a8: ldur            w2, [x0, #0xb]
    // 0x84e1ac: DecompressPointer r2
    //     0x84e1ac: add             x2, x2, HEAP, lsl #32
    // 0x84e1b0: cmp             w2, NULL
    // 0x84e1b4: b.eq            #0x84f090
    // 0x84e1b8: r2 = LoadClassIdInstr(r1)
    //     0x84e1b8: ldur            x2, [x1, #-1]
    //     0x84e1bc: ubfx            x2, x2, #0xc, #0x14
    // 0x84e1c0: lsl             x2, x2, #1
    // 0x84e1c4: stur            x2, [fp, #-0x18]
    // 0x84e1c8: r17 = 5632
    //     0x84e1c8: mov             x17, #0x1600
    // 0x84e1cc: cmp             w2, w17
    // 0x84e1d0: b.ne            #0x84e1e0
    // 0x84e1d4: LoadField: r3 = r1->field_1f
    //     0x84e1d4: ldur            w3, [x1, #0x1f]
    // 0x84e1d8: DecompressPointer r3
    //     0x84e1d8: add             x3, x3, HEAP, lsl #32
    // 0x84e1dc: b               #0x84e218
    // 0x84e1e0: r17 = 5634
    //     0x84e1e0: mov             x17, #0x1602
    // 0x84e1e4: cmp             w2, w17
    // 0x84e1e8: b.ne            #0x84e204
    // 0x84e1ec: LoadField: r3 = r1->field_2b
    //     0x84e1ec: ldur            w3, [x1, #0x2b]
    // 0x84e1f0: DecompressPointer r3
    //     0x84e1f0: add             x3, x3, HEAP, lsl #32
    // 0x84e1f4: LoadField: r4 = r3->field_2f
    //     0x84e1f4: ldur            w4, [x3, #0x2f]
    // 0x84e1f8: DecompressPointer r4
    //     0x84e1f8: add             x4, x4, HEAP, lsl #32
    // 0x84e1fc: mov             x3, x4
    // 0x84e200: b               #0x84e218
    // 0x84e204: LoadField: r3 = r1->field_2b
    //     0x84e204: ldur            w3, [x1, #0x2b]
    // 0x84e208: DecompressPointer r3
    //     0x84e208: add             x3, x3, HEAP, lsl #32
    // 0x84e20c: LoadField: r4 = r3->field_2f
    //     0x84e20c: ldur            w4, [x3, #0x2f]
    // 0x84e210: DecompressPointer r4
    //     0x84e210: add             x4, x4, HEAP, lsl #32
    // 0x84e214: mov             x3, x4
    // 0x84e218: SaveReg r3
    //     0x84e218: str             x3, [SP, #-8]!
    // 0x84e21c: r0 = baseSizeAdjustment()
    //     0x84e21c: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x84e220: add             SP, SP, #8
    // 0x84e224: r16 = Instance_Size
    //     0x84e224: add             x16, PP, #0x56, lsl #12  ; [pp+0x56540] Obj!Size@b5ed31
    //     0x84e228: ldr             x16, [x16, #0x540]
    // 0x84e22c: stp             x0, x16, [SP, #-0x10]!
    // 0x84e230: r0 = +()
    //     0x84e230: bl              #0x50e25c  ; [dart:ui] Size::+
    // 0x84e234: add             SP, SP, #0x10
    // 0x84e238: ldur            x2, [fp, #-8]
    // 0x84e23c: r1 = Function '<anonymous closure>':.
    //     0x84e23c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56548] AnonymousClosure: (0x851350), in [package:flutter/src/material/checkbox.dart] _CheckboxState::build (0x84e050)
    //     0x84e240: ldr             x1, [x1, #0x548]
    // 0x84e244: stur            x0, [fp, #-8]
    // 0x84e248: r0 = AllocateClosure()
    //     0x84e248: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e24c: r16 = <MouseCursor>
    //     0x84e24c: ldr             x16, [PP, #0x3980]  ; [pp+0x3980] TypeArguments: <MouseCursor>
    // 0x84e250: stp             x0, x16, [SP, #-0x10]!
    // 0x84e254: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e254: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e258: r0 = resolveWith()
    //     0x84e258: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e25c: add             SP, SP, #0x10
    // 0x84e260: stur            x0, [fp, #-0x28]
    // 0x84e264: ldr             x16, [fp, #0x18]
    // 0x84e268: SaveReg r16
    //     0x84e268: str             x16, [SP, #-8]!
    // 0x84e26c: r0 = states()
    //     0x84e26c: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84e270: add             SP, SP, #8
    // 0x84e274: r16 = Instance_MaterialState
    //     0x84e274: add             x16, PP, #0xe, lsl #12  ; [pp+0xe298] Obj!MaterialState@b654b1
    //     0x84e278: ldr             x16, [x16, #0x298]
    // 0x84e27c: stp             x16, x0, [SP, #-0x10]!
    // 0x84e280: r0 = add()
    //     0x84e280: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84e284: add             SP, SP, #0x10
    // 0x84e288: ldr             x0, [fp, #0x18]
    // 0x84e28c: LoadField: r1 = r0->field_b
    //     0x84e28c: ldur            w1, [x0, #0xb]
    // 0x84e290: DecompressPointer r1
    //     0x84e290: add             x1, x1, HEAP, lsl #32
    // 0x84e294: cmp             w1, NULL
    // 0x84e298: b.eq            #0x84f094
    // 0x84e29c: SaveReg r0
    //     0x84e29c: str             x0, [SP, #-8]!
    // 0x84e2a0: r0 = states()
    //     0x84e2a0: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84e2a4: add             SP, SP, #8
    // 0x84e2a8: stur            x0, [fp, #-0x30]
    // 0x84e2ac: r16 = Instance_MaterialState
    //     0x84e2ac: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x84e2b0: ldr             x16, [x16, #0xf70]
    // 0x84e2b4: stp             x16, x0, [SP, #-0x10]!
    // 0x84e2b8: r0 = add()
    //     0x84e2b8: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84e2bc: add             SP, SP, #0x10
    // 0x84e2c0: ldr             x0, [fp, #0x18]
    // 0x84e2c4: LoadField: r1 = r0->field_b
    //     0x84e2c4: ldur            w1, [x0, #0xb]
    // 0x84e2c8: DecompressPointer r1
    //     0x84e2c8: add             x1, x1, HEAP, lsl #32
    // 0x84e2cc: cmp             w1, NULL
    // 0x84e2d0: b.eq            #0x84f098
    // 0x84e2d4: SaveReg r0
    //     0x84e2d4: str             x0, [SP, #-8]!
    // 0x84e2d8: r0 = states()
    //     0x84e2d8: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84e2dc: add             SP, SP, #8
    // 0x84e2e0: stur            x0, [fp, #-0x38]
    // 0x84e2e4: r16 = Instance_MaterialState
    //     0x84e2e4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x84e2e8: ldr             x16, [x16, #0xf70]
    // 0x84e2ec: stp             x16, x0, [SP, #-0x10]!
    // 0x84e2f0: r0 = remove()
    //     0x84e2f0: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x84e2f4: add             SP, SP, #0x10
    // 0x84e2f8: ldr             x0, [fp, #0x18]
    // 0x84e2fc: LoadField: r1 = r0->field_b
    //     0x84e2fc: ldur            w1, [x0, #0xb]
    // 0x84e300: DecompressPointer r1
    //     0x84e300: add             x1, x1, HEAP, lsl #32
    // 0x84e304: cmp             w1, NULL
    // 0x84e308: b.eq            #0x84f09c
    // 0x84e30c: r1 = 1
    //     0x84e30c: mov             x1, #1
    // 0x84e310: r0 = AllocateContext()
    //     0x84e310: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e314: mov             x1, x0
    // 0x84e318: ldr             x0, [fp, #0x18]
    // 0x84e31c: StoreField: r1->field_f = r0
    //     0x84e31c: stur            w0, [x1, #0xf]
    // 0x84e320: mov             x2, x1
    // 0x84e324: r1 = Function '<anonymous closure>':.
    //     0x84e324: add             x1, PP, #0x56, lsl #12  ; [pp+0x56550] AnonymousClosure: (0x851268), in [package:flutter/src/material/checkbox.dart] _CheckboxState::_widgetFillColor (0x851050)
    //     0x84e328: ldr             x1, [x1, #0x550]
    // 0x84e32c: r0 = AllocateClosure()
    //     0x84e32c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e330: r16 = <Color?>
    //     0x84e330: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84e334: ldr             x16, [x16, #0xf68]
    // 0x84e338: stp             x0, x16, [SP, #-0x10]!
    // 0x84e33c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e33c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e340: r0 = resolveWith()
    //     0x84e340: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e344: add             SP, SP, #0x10
    // 0x84e348: ldur            x16, [fp, #-0x30]
    // 0x84e34c: stp             x16, x0, [SP, #-0x10]!
    // 0x84e350: r0 = build()
    //     0x84e350: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e354: add             SP, SP, #0x10
    // 0x84e358: cmp             w0, NULL
    // 0x84e35c: b.ne            #0x84e38c
    // 0x84e360: ldur            x0, [fp, #-0x10]
    // 0x84e364: LoadField: r1 = r0->field_b
    //     0x84e364: ldur            w1, [x0, #0xb]
    // 0x84e368: DecompressPointer r1
    //     0x84e368: add             x1, x1, HEAP, lsl #32
    // 0x84e36c: cmp             w1, NULL
    // 0x84e370: b.ne            #0x84e37c
    // 0x84e374: r0 = Null
    //     0x84e374: mov             x0, NULL
    // 0x84e378: b               #0x84e38c
    // 0x84e37c: ldur            x16, [fp, #-0x30]
    // 0x84e380: stp             x16, x1, [SP, #-0x10]!
    // 0x84e384: r0 = resolve()
    //     0x84e384: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84e388: add             SP, SP, #0x10
    // 0x84e38c: stur            x0, [fp, #-0x40]
    // 0x84e390: cmp             w0, NULL
    // 0x84e394: b.ne            #0x84e46c
    // 0x84e398: ldur            x1, [fp, #-0x18]
    // 0x84e39c: r17 = 5632
    //     0x84e39c: mov             x17, #0x1600
    // 0x84e3a0: cmp             w1, w17
    // 0x84e3a4: b.ne            #0x84e3bc
    // 0x84e3a8: ldur            x2, [fp, #-0x20]
    // 0x84e3ac: LoadField: r3 = r2->field_b
    //     0x84e3ac: ldur            w3, [x2, #0xb]
    // 0x84e3b0: DecompressPointer r3
    //     0x84e3b0: add             x3, x3, HEAP, lsl #32
    // 0x84e3b4: mov             x0, x3
    // 0x84e3b8: b               #0x84e44c
    // 0x84e3bc: ldur            x2, [fp, #-0x20]
    // 0x84e3c0: r17 = 5634
    //     0x84e3c0: mov             x17, #0x1602
    // 0x84e3c4: cmp             w1, w17
    // 0x84e3c8: b.ne            #0x84e40c
    // 0x84e3cc: r1 = 1
    //     0x84e3cc: mov             x1, #1
    // 0x84e3d0: r0 = AllocateContext()
    //     0x84e3d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e3d4: mov             x1, x0
    // 0x84e3d8: ldur            x0, [fp, #-0x20]
    // 0x84e3dc: StoreField: r1->field_f = r0
    //     0x84e3dc: stur            w0, [x1, #0xf]
    // 0x84e3e0: mov             x2, x1
    // 0x84e3e4: r1 = Function '<anonymous closure>':.
    //     0x84e3e4: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f0] AnonymousClosure: (0x851d40), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84e3e8: ldr             x1, [x1, #0x3f0]
    // 0x84e3ec: r0 = AllocateClosure()
    //     0x84e3ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e3f0: r16 = <Color>
    //     0x84e3f0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e3f4: ldr             x16, [x16, #0x3f8]
    // 0x84e3f8: stp             x0, x16, [SP, #-0x10]!
    // 0x84e3fc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e3fc: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e400: r0 = resolveWith()
    //     0x84e400: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e404: add             SP, SP, #0x10
    // 0x84e408: b               #0x84e44c
    // 0x84e40c: mov             x0, x2
    // 0x84e410: r1 = 1
    //     0x84e410: mov             x1, #1
    // 0x84e414: r0 = AllocateContext()
    //     0x84e414: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e418: mov             x1, x0
    // 0x84e41c: ldur            x0, [fp, #-0x20]
    // 0x84e420: StoreField: r1->field_f = r0
    //     0x84e420: stur            w0, [x1, #0xf]
    // 0x84e424: mov             x2, x1
    // 0x84e428: r1 = Function '<anonymous closure>':.
    //     0x84e428: add             x1, PP, #0xe, lsl #12  ; [pp+0xe400] AnonymousClosure: (0x851c30), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x84e42c: ldr             x1, [x1, #0x400]
    // 0x84e430: r0 = AllocateClosure()
    //     0x84e430: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e434: r16 = <Color>
    //     0x84e434: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e438: ldr             x16, [x16, #0x3f8]
    // 0x84e43c: stp             x0, x16, [SP, #-0x10]!
    // 0x84e440: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e440: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e444: r0 = resolveWith()
    //     0x84e444: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e448: add             SP, SP, #0x10
    // 0x84e44c: ldur            x16, [fp, #-0x30]
    // 0x84e450: stp             x16, x0, [SP, #-0x10]!
    // 0x84e454: r0 = build()
    //     0x84e454: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e458: add             SP, SP, #0x10
    // 0x84e45c: cmp             w0, NULL
    // 0x84e460: b.eq            #0x84f0a0
    // 0x84e464: mov             x1, x0
    // 0x84e468: b               #0x84e470
    // 0x84e46c: ldur            x1, [fp, #-0x40]
    // 0x84e470: ldr             x0, [fp, #0x18]
    // 0x84e474: stur            x1, [fp, #-0x48]
    // 0x84e478: LoadField: r2 = r0->field_b
    //     0x84e478: ldur            w2, [x0, #0xb]
    // 0x84e47c: DecompressPointer r2
    //     0x84e47c: add             x2, x2, HEAP, lsl #32
    // 0x84e480: cmp             w2, NULL
    // 0x84e484: b.eq            #0x84f0a4
    // 0x84e488: SaveReg r0
    //     0x84e488: str             x0, [SP, #-8]!
    // 0x84e48c: r0 = _widgetFillColor()
    //     0x84e48c: bl              #0x851050  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::_widgetFillColor
    // 0x84e490: add             SP, SP, #8
    // 0x84e494: ldur            x16, [fp, #-0x38]
    // 0x84e498: stp             x16, x0, [SP, #-0x10]!
    // 0x84e49c: r0 = build()
    //     0x84e49c: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e4a0: add             SP, SP, #0x10
    // 0x84e4a4: cmp             w0, NULL
    // 0x84e4a8: b.ne            #0x84e4d8
    // 0x84e4ac: ldur            x0, [fp, #-0x10]
    // 0x84e4b0: LoadField: r1 = r0->field_b
    //     0x84e4b0: ldur            w1, [x0, #0xb]
    // 0x84e4b4: DecompressPointer r1
    //     0x84e4b4: add             x1, x1, HEAP, lsl #32
    // 0x84e4b8: cmp             w1, NULL
    // 0x84e4bc: b.ne            #0x84e4c8
    // 0x84e4c0: r0 = Null
    //     0x84e4c0: mov             x0, NULL
    // 0x84e4c4: b               #0x84e4d8
    // 0x84e4c8: ldur            x16, [fp, #-0x38]
    // 0x84e4cc: stp             x16, x1, [SP, #-0x10]!
    // 0x84e4d0: r0 = resolve()
    //     0x84e4d0: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84e4d4: add             SP, SP, #0x10
    // 0x84e4d8: stur            x0, [fp, #-0x50]
    // 0x84e4dc: cmp             w0, NULL
    // 0x84e4e0: b.ne            #0x84e5b8
    // 0x84e4e4: ldur            x1, [fp, #-0x18]
    // 0x84e4e8: r17 = 5632
    //     0x84e4e8: mov             x17, #0x1600
    // 0x84e4ec: cmp             w1, w17
    // 0x84e4f0: b.ne            #0x84e508
    // 0x84e4f4: ldur            x2, [fp, #-0x20]
    // 0x84e4f8: LoadField: r3 = r2->field_b
    //     0x84e4f8: ldur            w3, [x2, #0xb]
    // 0x84e4fc: DecompressPointer r3
    //     0x84e4fc: add             x3, x3, HEAP, lsl #32
    // 0x84e500: mov             x0, x3
    // 0x84e504: b               #0x84e598
    // 0x84e508: ldur            x2, [fp, #-0x20]
    // 0x84e50c: r17 = 5634
    //     0x84e50c: mov             x17, #0x1602
    // 0x84e510: cmp             w1, w17
    // 0x84e514: b.ne            #0x84e558
    // 0x84e518: r1 = 1
    //     0x84e518: mov             x1, #1
    // 0x84e51c: r0 = AllocateContext()
    //     0x84e51c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e520: mov             x1, x0
    // 0x84e524: ldur            x0, [fp, #-0x20]
    // 0x84e528: StoreField: r1->field_f = r0
    //     0x84e528: stur            w0, [x1, #0xf]
    // 0x84e52c: mov             x2, x1
    // 0x84e530: r1 = Function '<anonymous closure>':.
    //     0x84e530: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f0] AnonymousClosure: (0x851d40), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84e534: ldr             x1, [x1, #0x3f0]
    // 0x84e538: r0 = AllocateClosure()
    //     0x84e538: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e53c: r16 = <Color>
    //     0x84e53c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e540: ldr             x16, [x16, #0x3f8]
    // 0x84e544: stp             x0, x16, [SP, #-0x10]!
    // 0x84e548: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e548: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e54c: r0 = resolveWith()
    //     0x84e54c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e550: add             SP, SP, #0x10
    // 0x84e554: b               #0x84e598
    // 0x84e558: mov             x0, x2
    // 0x84e55c: r1 = 1
    //     0x84e55c: mov             x1, #1
    // 0x84e560: r0 = AllocateContext()
    //     0x84e560: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e564: mov             x1, x0
    // 0x84e568: ldur            x0, [fp, #-0x20]
    // 0x84e56c: StoreField: r1->field_f = r0
    //     0x84e56c: stur            w0, [x1, #0xf]
    // 0x84e570: mov             x2, x1
    // 0x84e574: r1 = Function '<anonymous closure>':.
    //     0x84e574: add             x1, PP, #0xe, lsl #12  ; [pp+0xe400] AnonymousClosure: (0x851c30), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x84e578: ldr             x1, [x1, #0x400]
    // 0x84e57c: r0 = AllocateClosure()
    //     0x84e57c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e580: r16 = <Color>
    //     0x84e580: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e584: ldr             x16, [x16, #0x3f8]
    // 0x84e588: stp             x0, x16, [SP, #-0x10]!
    // 0x84e58c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e58c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e590: r0 = resolveWith()
    //     0x84e590: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e594: add             SP, SP, #0x10
    // 0x84e598: ldur            x16, [fp, #-0x38]
    // 0x84e59c: stp             x16, x0, [SP, #-0x10]!
    // 0x84e5a0: r0 = build()
    //     0x84e5a0: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e5a4: add             SP, SP, #0x10
    // 0x84e5a8: cmp             w0, NULL
    // 0x84e5ac: b.eq            #0x84f0a8
    // 0x84e5b0: mov             x2, x0
    // 0x84e5b4: b               #0x84e5bc
    // 0x84e5b8: ldur            x2, [fp, #-0x50]
    // 0x84e5bc: ldr             x1, [fp, #0x18]
    // 0x84e5c0: ldur            x0, [fp, #-0x10]
    // 0x84e5c4: stur            x2, [fp, #-0x58]
    // 0x84e5c8: LoadField: r3 = r1->field_b
    //     0x84e5c8: ldur            w3, [x1, #0xb]
    // 0x84e5cc: DecompressPointer r3
    //     0x84e5cc: add             x3, x3, HEAP, lsl #32
    // 0x84e5d0: cmp             w3, NULL
    // 0x84e5d4: b.eq            #0x84f0ac
    // 0x84e5d8: SaveReg r1
    //     0x84e5d8: str             x1, [SP, #-8]!
    // 0x84e5dc: r0 = states()
    //     0x84e5dc: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84e5e0: add             SP, SP, #8
    // 0x84e5e4: stur            x0, [fp, #-0x60]
    // 0x84e5e8: r16 = Instance_MaterialState
    //     0x84e5e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x84e5ec: ldr             x16, [x16, #0xf88]
    // 0x84e5f0: stp             x16, x0, [SP, #-0x10]!
    // 0x84e5f4: r0 = add()
    //     0x84e5f4: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84e5f8: add             SP, SP, #0x10
    // 0x84e5fc: ldr             x0, [fp, #0x18]
    // 0x84e600: LoadField: r1 = r0->field_b
    //     0x84e600: ldur            w1, [x0, #0xb]
    // 0x84e604: DecompressPointer r1
    //     0x84e604: add             x1, x1, HEAP, lsl #32
    // 0x84e608: cmp             w1, NULL
    // 0x84e60c: b.eq            #0x84f0b0
    // 0x84e610: ldur            x1, [fp, #-0x10]
    // 0x84e614: LoadField: r2 = r1->field_13
    //     0x84e614: ldur            w2, [x1, #0x13]
    // 0x84e618: DecompressPointer r2
    //     0x84e618: add             x2, x2, HEAP, lsl #32
    // 0x84e61c: stur            x2, [fp, #-0x68]
    // 0x84e620: cmp             w2, NULL
    // 0x84e624: b.ne            #0x84e630
    // 0x84e628: r0 = Null
    //     0x84e628: mov             x0, NULL
    // 0x84e62c: b               #0x84e640
    // 0x84e630: ldur            x16, [fp, #-0x60]
    // 0x84e634: stp             x16, x2, [SP, #-0x10]!
    // 0x84e638: r0 = resolve()
    //     0x84e638: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84e63c: add             SP, SP, #0x10
    // 0x84e640: cmp             w0, NULL
    // 0x84e644: b.ne            #0x84e71c
    // 0x84e648: ldur            x0, [fp, #-0x18]
    // 0x84e64c: r17 = 5632
    //     0x84e64c: mov             x17, #0x1600
    // 0x84e650: cmp             w0, w17
    // 0x84e654: b.ne            #0x84e66c
    // 0x84e658: ldur            x1, [fp, #-0x20]
    // 0x84e65c: LoadField: r2 = r1->field_13
    //     0x84e65c: ldur            w2, [x1, #0x13]
    // 0x84e660: DecompressPointer r2
    //     0x84e660: add             x2, x2, HEAP, lsl #32
    // 0x84e664: mov             x0, x2
    // 0x84e668: b               #0x84e6fc
    // 0x84e66c: ldur            x1, [fp, #-0x20]
    // 0x84e670: r17 = 5634
    //     0x84e670: mov             x17, #0x1602
    // 0x84e674: cmp             w0, w17
    // 0x84e678: b.ne            #0x84e6bc
    // 0x84e67c: r1 = 1
    //     0x84e67c: mov             x1, #1
    // 0x84e680: r0 = AllocateContext()
    //     0x84e680: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e684: mov             x1, x0
    // 0x84e688: ldur            x0, [fp, #-0x20]
    // 0x84e68c: StoreField: r1->field_f = r0
    //     0x84e68c: stur            w0, [x1, #0xf]
    // 0x84e690: mov             x2, x1
    // 0x84e694: r1 = Function '<anonymous closure>':.
    //     0x84e694: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84e698: ldr             x1, [x1, #0x410]
    // 0x84e69c: r0 = AllocateClosure()
    //     0x84e69c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e6a0: r16 = <Color>
    //     0x84e6a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e6a4: ldr             x16, [x16, #0x3f8]
    // 0x84e6a8: stp             x0, x16, [SP, #-0x10]!
    // 0x84e6ac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e6ac: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e6b0: r0 = resolveWith()
    //     0x84e6b0: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e6b4: add             SP, SP, #0x10
    // 0x84e6b8: b               #0x84e6fc
    // 0x84e6bc: mov             x0, x1
    // 0x84e6c0: r1 = 1
    //     0x84e6c0: mov             x1, #1
    // 0x84e6c4: r0 = AllocateContext()
    //     0x84e6c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e6c8: mov             x1, x0
    // 0x84e6cc: ldur            x0, [fp, #-0x20]
    // 0x84e6d0: StoreField: r1->field_f = r0
    //     0x84e6d0: stur            w0, [x1, #0xf]
    // 0x84e6d4: mov             x2, x1
    // 0x84e6d8: r1 = Function '<anonymous closure>':.
    //     0x84e6d8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x84e6dc: ldr             x1, [x1, #0x418]
    // 0x84e6e0: r0 = AllocateClosure()
    //     0x84e6e0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e6e4: r16 = <Color?>
    //     0x84e6e4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84e6e8: ldr             x16, [x16, #0xf68]
    // 0x84e6ec: stp             x0, x16, [SP, #-0x10]!
    // 0x84e6f0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e6f0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e6f4: r0 = resolveWith()
    //     0x84e6f4: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e6f8: add             SP, SP, #0x10
    // 0x84e6fc: ldur            x16, [fp, #-0x60]
    // 0x84e700: stp             x16, x0, [SP, #-0x10]!
    // 0x84e704: r0 = build()
    //     0x84e704: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e708: add             SP, SP, #0x10
    // 0x84e70c: cmp             w0, NULL
    // 0x84e710: b.eq            #0x84f0b4
    // 0x84e714: mov             x2, x0
    // 0x84e718: b               #0x84e720
    // 0x84e71c: mov             x2, x0
    // 0x84e720: ldr             x0, [fp, #0x18]
    // 0x84e724: ldur            x1, [fp, #-0x68]
    // 0x84e728: stur            x2, [fp, #-0x60]
    // 0x84e72c: LoadField: r3 = r0->field_b
    //     0x84e72c: ldur            w3, [x0, #0xb]
    // 0x84e730: DecompressPointer r3
    //     0x84e730: add             x3, x3, HEAP, lsl #32
    // 0x84e734: cmp             w3, NULL
    // 0x84e738: b.eq            #0x84f0b8
    // 0x84e73c: SaveReg r0
    //     0x84e73c: str             x0, [SP, #-8]!
    // 0x84e740: r0 = states()
    //     0x84e740: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84e744: add             SP, SP, #8
    // 0x84e748: stur            x0, [fp, #-0x70]
    // 0x84e74c: r16 = Instance_MaterialState
    //     0x84e74c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x84e750: ldr             x16, [x16, #0xf78]
    // 0x84e754: stp             x16, x0, [SP, #-0x10]!
    // 0x84e758: r0 = add()
    //     0x84e758: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84e75c: add             SP, SP, #0x10
    // 0x84e760: ldr             x0, [fp, #0x18]
    // 0x84e764: LoadField: r1 = r0->field_b
    //     0x84e764: ldur            w1, [x0, #0xb]
    // 0x84e768: DecompressPointer r1
    //     0x84e768: add             x1, x1, HEAP, lsl #32
    // 0x84e76c: cmp             w1, NULL
    // 0x84e770: b.eq            #0x84f0bc
    // 0x84e774: ldur            x1, [fp, #-0x68]
    // 0x84e778: cmp             w1, NULL
    // 0x84e77c: b.ne            #0x84e788
    // 0x84e780: r0 = Null
    //     0x84e780: mov             x0, NULL
    // 0x84e784: b               #0x84e798
    // 0x84e788: ldur            x16, [fp, #-0x70]
    // 0x84e78c: stp             x16, x1, [SP, #-0x10]!
    // 0x84e790: r0 = resolve()
    //     0x84e790: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84e794: add             SP, SP, #0x10
    // 0x84e798: cmp             w0, NULL
    // 0x84e79c: b.ne            #0x84e874
    // 0x84e7a0: ldur            x0, [fp, #-0x18]
    // 0x84e7a4: r17 = 5632
    //     0x84e7a4: mov             x17, #0x1600
    // 0x84e7a8: cmp             w0, w17
    // 0x84e7ac: b.ne            #0x84e7c4
    // 0x84e7b0: ldur            x1, [fp, #-0x20]
    // 0x84e7b4: LoadField: r2 = r1->field_13
    //     0x84e7b4: ldur            w2, [x1, #0x13]
    // 0x84e7b8: DecompressPointer r2
    //     0x84e7b8: add             x2, x2, HEAP, lsl #32
    // 0x84e7bc: mov             x0, x2
    // 0x84e7c0: b               #0x84e854
    // 0x84e7c4: ldur            x1, [fp, #-0x20]
    // 0x84e7c8: r17 = 5634
    //     0x84e7c8: mov             x17, #0x1602
    // 0x84e7cc: cmp             w0, w17
    // 0x84e7d0: b.ne            #0x84e814
    // 0x84e7d4: r1 = 1
    //     0x84e7d4: mov             x1, #1
    // 0x84e7d8: r0 = AllocateContext()
    //     0x84e7d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e7dc: mov             x1, x0
    // 0x84e7e0: ldur            x0, [fp, #-0x20]
    // 0x84e7e4: StoreField: r1->field_f = r0
    //     0x84e7e4: stur            w0, [x1, #0xf]
    // 0x84e7e8: mov             x2, x1
    // 0x84e7ec: r1 = Function '<anonymous closure>':.
    //     0x84e7ec: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84e7f0: ldr             x1, [x1, #0x410]
    // 0x84e7f4: r0 = AllocateClosure()
    //     0x84e7f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e7f8: r16 = <Color>
    //     0x84e7f8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e7fc: ldr             x16, [x16, #0x3f8]
    // 0x84e800: stp             x0, x16, [SP, #-0x10]!
    // 0x84e804: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e804: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e808: r0 = resolveWith()
    //     0x84e808: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e80c: add             SP, SP, #0x10
    // 0x84e810: b               #0x84e854
    // 0x84e814: mov             x0, x1
    // 0x84e818: r1 = 1
    //     0x84e818: mov             x1, #1
    // 0x84e81c: r0 = AllocateContext()
    //     0x84e81c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e820: mov             x1, x0
    // 0x84e824: ldur            x0, [fp, #-0x20]
    // 0x84e828: StoreField: r1->field_f = r0
    //     0x84e828: stur            w0, [x1, #0xf]
    // 0x84e82c: mov             x2, x1
    // 0x84e830: r1 = Function '<anonymous closure>':.
    //     0x84e830: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x84e834: ldr             x1, [x1, #0x418]
    // 0x84e838: r0 = AllocateClosure()
    //     0x84e838: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e83c: r16 = <Color?>
    //     0x84e83c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84e840: ldr             x16, [x16, #0xf68]
    // 0x84e844: stp             x0, x16, [SP, #-0x10]!
    // 0x84e848: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e848: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e84c: r0 = resolveWith()
    //     0x84e84c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e850: add             SP, SP, #0x10
    // 0x84e854: ldur            x16, [fp, #-0x70]
    // 0x84e858: stp             x16, x0, [SP, #-0x10]!
    // 0x84e85c: r0 = build()
    //     0x84e85c: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e860: add             SP, SP, #0x10
    // 0x84e864: cmp             w0, NULL
    // 0x84e868: b.eq            #0x84f0c0
    // 0x84e86c: mov             x2, x0
    // 0x84e870: b               #0x84e878
    // 0x84e874: mov             x2, x0
    // 0x84e878: ldr             x0, [fp, #0x18]
    // 0x84e87c: ldur            x1, [fp, #-0x68]
    // 0x84e880: stur            x2, [fp, #-0x70]
    // 0x84e884: ldur            x16, [fp, #-0x30]
    // 0x84e888: r30 = Instance_MaterialState
    //     0x84e888: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x84e88c: ldr             lr, [lr, #0xf90]
    // 0x84e890: stp             lr, x16, [SP, #-0x10]!
    // 0x84e894: r0 = add()
    //     0x84e894: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84e898: add             SP, SP, #0x10
    // 0x84e89c: ldr             x0, [fp, #0x18]
    // 0x84e8a0: LoadField: r1 = r0->field_b
    //     0x84e8a0: ldur            w1, [x0, #0xb]
    // 0x84e8a4: DecompressPointer r1
    //     0x84e8a4: add             x1, x1, HEAP, lsl #32
    // 0x84e8a8: cmp             w1, NULL
    // 0x84e8ac: b.eq            #0x84f0c4
    // 0x84e8b0: ldur            x1, [fp, #-0x68]
    // 0x84e8b4: cmp             w1, NULL
    // 0x84e8b8: b.ne            #0x84e8c4
    // 0x84e8bc: r0 = Null
    //     0x84e8bc: mov             x0, NULL
    // 0x84e8c0: b               #0x84e8d4
    // 0x84e8c4: ldur            x16, [fp, #-0x30]
    // 0x84e8c8: stp             x16, x1, [SP, #-0x10]!
    // 0x84e8cc: r0 = resolve()
    //     0x84e8cc: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84e8d0: add             SP, SP, #0x10
    // 0x84e8d4: cmp             w0, NULL
    // 0x84e8d8: b.ne            #0x84e900
    // 0x84e8dc: ldur            x0, [fp, #-0x40]
    // 0x84e8e0: cmp             w0, NULL
    // 0x84e8e4: b.ne            #0x84e8f0
    // 0x84e8e8: r0 = Null
    //     0x84e8e8: mov             x0, NULL
    // 0x84e8ec: b               #0x84e900
    // 0x84e8f0: r1 = 31
    //     0x84e8f0: mov             x1, #0x1f
    // 0x84e8f4: stp             x1, x0, [SP, #-0x10]!
    // 0x84e8f8: r0 = withAlpha()
    //     0x84e8f8: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x84e8fc: add             SP, SP, #0x10
    // 0x84e900: cmp             w0, NULL
    // 0x84e904: b.ne            #0x84e9dc
    // 0x84e908: ldur            x0, [fp, #-0x18]
    // 0x84e90c: r17 = 5632
    //     0x84e90c: mov             x17, #0x1600
    // 0x84e910: cmp             w0, w17
    // 0x84e914: b.ne            #0x84e92c
    // 0x84e918: ldur            x1, [fp, #-0x20]
    // 0x84e91c: LoadField: r2 = r1->field_13
    //     0x84e91c: ldur            w2, [x1, #0x13]
    // 0x84e920: DecompressPointer r2
    //     0x84e920: add             x2, x2, HEAP, lsl #32
    // 0x84e924: mov             x0, x2
    // 0x84e928: b               #0x84e9bc
    // 0x84e92c: ldur            x1, [fp, #-0x20]
    // 0x84e930: r17 = 5634
    //     0x84e930: mov             x17, #0x1602
    // 0x84e934: cmp             w0, w17
    // 0x84e938: b.ne            #0x84e97c
    // 0x84e93c: r1 = 1
    //     0x84e93c: mov             x1, #1
    // 0x84e940: r0 = AllocateContext()
    //     0x84e940: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e944: mov             x1, x0
    // 0x84e948: ldur            x0, [fp, #-0x20]
    // 0x84e94c: StoreField: r1->field_f = r0
    //     0x84e94c: stur            w0, [x1, #0xf]
    // 0x84e950: mov             x2, x1
    // 0x84e954: r1 = Function '<anonymous closure>':.
    //     0x84e954: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84e958: ldr             x1, [x1, #0x410]
    // 0x84e95c: r0 = AllocateClosure()
    //     0x84e95c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e960: r16 = <Color>
    //     0x84e960: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84e964: ldr             x16, [x16, #0x3f8]
    // 0x84e968: stp             x0, x16, [SP, #-0x10]!
    // 0x84e96c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e96c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e970: r0 = resolveWith()
    //     0x84e970: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e974: add             SP, SP, #0x10
    // 0x84e978: b               #0x84e9bc
    // 0x84e97c: mov             x0, x1
    // 0x84e980: r1 = 1
    //     0x84e980: mov             x1, #1
    // 0x84e984: r0 = AllocateContext()
    //     0x84e984: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84e988: mov             x1, x0
    // 0x84e98c: ldur            x0, [fp, #-0x20]
    // 0x84e990: StoreField: r1->field_f = r0
    //     0x84e990: stur            w0, [x1, #0xf]
    // 0x84e994: mov             x2, x1
    // 0x84e998: r1 = Function '<anonymous closure>':.
    //     0x84e998: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x84e99c: ldr             x1, [x1, #0x418]
    // 0x84e9a0: r0 = AllocateClosure()
    //     0x84e9a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84e9a4: r16 = <Color?>
    //     0x84e9a4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84e9a8: ldr             x16, [x16, #0xf68]
    // 0x84e9ac: stp             x0, x16, [SP, #-0x10]!
    // 0x84e9b0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84e9b0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84e9b4: r0 = resolveWith()
    //     0x84e9b4: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84e9b8: add             SP, SP, #0x10
    // 0x84e9bc: ldur            x16, [fp, #-0x30]
    // 0x84e9c0: stp             x16, x0, [SP, #-0x10]!
    // 0x84e9c4: r0 = build()
    //     0x84e9c4: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84e9c8: add             SP, SP, #0x10
    // 0x84e9cc: cmp             w0, NULL
    // 0x84e9d0: b.eq            #0x84f0c8
    // 0x84e9d4: mov             x2, x0
    // 0x84e9d8: b               #0x84e9e0
    // 0x84e9dc: mov             x2, x0
    // 0x84e9e0: ldr             x0, [fp, #0x18]
    // 0x84e9e4: ldur            x1, [fp, #-0x68]
    // 0x84e9e8: stur            x2, [fp, #-0x30]
    // 0x84e9ec: ldur            x16, [fp, #-0x38]
    // 0x84e9f0: r30 = Instance_MaterialState
    //     0x84e9f0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x84e9f4: ldr             lr, [lr, #0xf90]
    // 0x84e9f8: stp             lr, x16, [SP, #-0x10]!
    // 0x84e9fc: r0 = add()
    //     0x84e9fc: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x84ea00: add             SP, SP, #0x10
    // 0x84ea04: ldr             x0, [fp, #0x18]
    // 0x84ea08: LoadField: r1 = r0->field_b
    //     0x84ea08: ldur            w1, [x0, #0xb]
    // 0x84ea0c: DecompressPointer r1
    //     0x84ea0c: add             x1, x1, HEAP, lsl #32
    // 0x84ea10: cmp             w1, NULL
    // 0x84ea14: b.eq            #0x84f0cc
    // 0x84ea18: ldur            x1, [fp, #-0x68]
    // 0x84ea1c: cmp             w1, NULL
    // 0x84ea20: b.ne            #0x84ea2c
    // 0x84ea24: r0 = Null
    //     0x84ea24: mov             x0, NULL
    // 0x84ea28: b               #0x84ea3c
    // 0x84ea2c: ldur            x16, [fp, #-0x38]
    // 0x84ea30: stp             x16, x1, [SP, #-0x10]!
    // 0x84ea34: r0 = resolve()
    //     0x84ea34: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84ea38: add             SP, SP, #0x10
    // 0x84ea3c: cmp             w0, NULL
    // 0x84ea40: b.ne            #0x84ea68
    // 0x84ea44: ldur            x0, [fp, #-0x50]
    // 0x84ea48: cmp             w0, NULL
    // 0x84ea4c: b.ne            #0x84ea58
    // 0x84ea50: r0 = Null
    //     0x84ea50: mov             x0, NULL
    // 0x84ea54: b               #0x84ea68
    // 0x84ea58: r1 = 31
    //     0x84ea58: mov             x1, #0x1f
    // 0x84ea5c: stp             x1, x0, [SP, #-0x10]!
    // 0x84ea60: r0 = withAlpha()
    //     0x84ea60: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0x84ea64: add             SP, SP, #0x10
    // 0x84ea68: cmp             w0, NULL
    // 0x84ea6c: b.ne            #0x84eb44
    // 0x84ea70: ldur            x0, [fp, #-0x18]
    // 0x84ea74: r17 = 5632
    //     0x84ea74: mov             x17, #0x1600
    // 0x84ea78: cmp             w0, w17
    // 0x84ea7c: b.ne            #0x84ea94
    // 0x84ea80: ldur            x1, [fp, #-0x20]
    // 0x84ea84: LoadField: r2 = r1->field_13
    //     0x84ea84: ldur            w2, [x1, #0x13]
    // 0x84ea88: DecompressPointer r2
    //     0x84ea88: add             x2, x2, HEAP, lsl #32
    // 0x84ea8c: mov             x0, x2
    // 0x84ea90: b               #0x84eb24
    // 0x84ea94: ldur            x1, [fp, #-0x20]
    // 0x84ea98: r17 = 5634
    //     0x84ea98: mov             x17, #0x1602
    // 0x84ea9c: cmp             w0, w17
    // 0x84eaa0: b.ne            #0x84eae4
    // 0x84eaa4: r1 = 1
    //     0x84eaa4: mov             x1, #1
    // 0x84eaa8: r0 = AllocateContext()
    //     0x84eaa8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84eaac: mov             x1, x0
    // 0x84eab0: ldur            x0, [fp, #-0x20]
    // 0x84eab4: StoreField: r1->field_f = r0
    //     0x84eab4: stur            w0, [x1, #0xf]
    // 0x84eab8: mov             x2, x1
    // 0x84eabc: r1 = Function '<anonymous closure>':.
    //     0x84eabc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe410] AnonymousClosure: (0x85171c), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84eac0: ldr             x1, [x1, #0x410]
    // 0x84eac4: r0 = AllocateClosure()
    //     0x84eac4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84eac8: r16 = <Color>
    //     0x84eac8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84eacc: ldr             x16, [x16, #0x3f8]
    // 0x84ead0: stp             x0, x16, [SP, #-0x10]!
    // 0x84ead4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84ead4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84ead8: r0 = resolveWith()
    //     0x84ead8: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84eadc: add             SP, SP, #0x10
    // 0x84eae0: b               #0x84eb24
    // 0x84eae4: mov             x0, x1
    // 0x84eae8: r1 = 1
    //     0x84eae8: mov             x1, #1
    // 0x84eaec: r0 = AllocateContext()
    //     0x84eaec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84eaf0: mov             x1, x0
    // 0x84eaf4: ldur            x0, [fp, #-0x20]
    // 0x84eaf8: StoreField: r1->field_f = r0
    //     0x84eaf8: stur            w0, [x1, #0xf]
    // 0x84eafc: mov             x2, x1
    // 0x84eb00: r1 = Function '<anonymous closure>':.
    //     0x84eb00: add             x1, PP, #0xe, lsl #12  ; [pp+0xe418] AnonymousClosure: (0x851570), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM2
    //     0x84eb04: ldr             x1, [x1, #0x418]
    // 0x84eb08: r0 = AllocateClosure()
    //     0x84eb08: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84eb0c: r16 = <Color?>
    //     0x84eb0c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84eb10: ldr             x16, [x16, #0xf68]
    // 0x84eb14: stp             x0, x16, [SP, #-0x10]!
    // 0x84eb18: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84eb18: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84eb1c: r0 = resolveWith()
    //     0x84eb1c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84eb20: add             SP, SP, #0x10
    // 0x84eb24: ldur            x16, [fp, #-0x38]
    // 0x84eb28: stp             x16, x0, [SP, #-0x10]!
    // 0x84eb2c: r0 = build()
    //     0x84eb2c: bl              #0xb24f58  ; [package:flutter/src/widgets/basic.dart] Builder::build
    // 0x84eb30: add             SP, SP, #0x10
    // 0x84eb34: cmp             w0, NULL
    // 0x84eb38: b.eq            #0x84f0d0
    // 0x84eb3c: mov             x1, x0
    // 0x84eb40: b               #0x84eb48
    // 0x84eb44: mov             x1, x0
    // 0x84eb48: ldr             x0, [fp, #0x18]
    // 0x84eb4c: stur            x1, [fp, #-0x38]
    // 0x84eb50: LoadField: r2 = r0->field_3f
    //     0x84eb50: ldur            w2, [x0, #0x3f]
    // 0x84eb54: DecompressPointer r2
    //     0x84eb54: add             x2, x2, HEAP, lsl #32
    // 0x84eb58: cmp             w2, NULL
    // 0x84eb5c: b.eq            #0x84ebd4
    // 0x84eb60: SaveReg r0
    //     0x84eb60: str             x0, [SP, #-8]!
    // 0x84eb64: r0 = states()
    //     0x84eb64: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84eb68: add             SP, SP, #8
    // 0x84eb6c: r16 = Instance_MaterialState
    //     0x84eb6c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x84eb70: ldr             x16, [x16, #0xf70]
    // 0x84eb74: stp             x16, x0, [SP, #-0x10]!
    // 0x84eb78: r0 = contains()
    //     0x84eb78: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84eb7c: add             SP, SP, #0x10
    // 0x84eb80: tbnz            w0, #4, #0x84eb8c
    // 0x84eb84: ldur            x0, [fp, #-0x30]
    // 0x84eb88: b               #0x84eb90
    // 0x84eb8c: ldur            x0, [fp, #-0x38]
    // 0x84eb90: stur            x0, [fp, #-0x40]
    // 0x84eb94: ldr             x16, [fp, #0x18]
    // 0x84eb98: SaveReg r16
    //     0x84eb98: str             x16, [SP, #-8]!
    // 0x84eb9c: r0 = states()
    //     0x84eb9c: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84eba0: add             SP, SP, #8
    // 0x84eba4: r16 = Instance_MaterialState
    //     0x84eba4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x84eba8: ldr             x16, [x16, #0xf70]
    // 0x84ebac: stp             x16, x0, [SP, #-0x10]!
    // 0x84ebb0: r0 = contains()
    //     0x84ebb0: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84ebb4: add             SP, SP, #0x10
    // 0x84ebb8: tbnz            w0, #4, #0x84ebc4
    // 0x84ebbc: ldur            x0, [fp, #-0x30]
    // 0x84ebc0: b               #0x84ebc8
    // 0x84ebc4: ldur            x0, [fp, #-0x38]
    // 0x84ebc8: mov             x3, x0
    // 0x84ebcc: ldur            x2, [fp, #-0x40]
    // 0x84ebd0: b               #0x84ebdc
    // 0x84ebd4: ldur            x3, [fp, #-0x60]
    // 0x84ebd8: ldur            x2, [fp, #-0x70]
    // 0x84ebdc: ldr             x0, [fp, #0x18]
    // 0x84ebe0: ldur            x1, [fp, #-0x10]
    // 0x84ebe4: stur            x3, [fp, #-0x40]
    // 0x84ebe8: stur            x2, [fp, #-0x50]
    // 0x84ebec: LoadField: r4 = r0->field_b
    //     0x84ebec: ldur            w4, [x0, #0xb]
    // 0x84ebf0: DecompressPointer r4
    //     0x84ebf0: add             x4, x4, HEAP, lsl #32
    // 0x84ebf4: cmp             w4, NULL
    // 0x84ebf8: b.eq            #0x84f0d4
    // 0x84ebfc: SaveReg r0
    //     0x84ebfc: str             x0, [SP, #-8]!
    // 0x84ec00: r0 = states()
    //     0x84ec00: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84ec04: add             SP, SP, #8
    // 0x84ec08: mov             x1, x0
    // 0x84ec0c: ldr             x0, [fp, #0x18]
    // 0x84ec10: stur            x1, [fp, #-0x60]
    // 0x84ec14: LoadField: r2 = r0->field_b
    //     0x84ec14: ldur            w2, [x0, #0xb]
    // 0x84ec18: DecompressPointer r2
    //     0x84ec18: add             x2, x2, HEAP, lsl #32
    // 0x84ec1c: cmp             w2, NULL
    // 0x84ec20: b.eq            #0x84f0d8
    // 0x84ec24: ldur            x2, [fp, #-0x10]
    // 0x84ec28: LoadField: r3 = r2->field_f
    //     0x84ec28: ldur            w3, [x2, #0xf]
    // 0x84ec2c: DecompressPointer r3
    //     0x84ec2c: add             x3, x3, HEAP, lsl #32
    // 0x84ec30: cmp             w3, NULL
    // 0x84ec34: b.ne            #0x84ec40
    // 0x84ec38: r0 = Null
    //     0x84ec38: mov             x0, NULL
    // 0x84ec3c: b               #0x84ec4c
    // 0x84ec40: stp             x1, x3, [SP, #-0x10]!
    // 0x84ec44: r0 = resolve()
    //     0x84ec44: bl              #0x5b6058  ; [package:flutter/src/material/material_state.dart] _LerpProperties::resolve
    // 0x84ec48: add             SP, SP, #0x10
    // 0x84ec4c: cmp             w0, NULL
    // 0x84ec50: b.ne            #0x84ed1c
    // 0x84ec54: ldur            x0, [fp, #-0x18]
    // 0x84ec58: r17 = 5632
    //     0x84ec58: mov             x17, #0x1600
    // 0x84ec5c: cmp             w0, w17
    // 0x84ec60: b.ne            #0x84ec78
    // 0x84ec64: ldur            x1, [fp, #-0x20]
    // 0x84ec68: LoadField: r2 = r1->field_f
    //     0x84ec68: ldur            w2, [x1, #0xf]
    // 0x84ec6c: DecompressPointer r2
    //     0x84ec6c: add             x2, x2, HEAP, lsl #32
    // 0x84ec70: mov             x0, x2
    // 0x84ec74: b               #0x84ece0
    // 0x84ec78: ldur            x1, [fp, #-0x20]
    // 0x84ec7c: r17 = 5634
    //     0x84ec7c: mov             x17, #0x1602
    // 0x84ec80: cmp             w0, w17
    // 0x84ec84: b.ne            #0x84ecc8
    // 0x84ec88: r1 = 1
    //     0x84ec88: mov             x1, #1
    // 0x84ec8c: r0 = AllocateContext()
    //     0x84ec8c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84ec90: mov             x1, x0
    // 0x84ec94: ldur            x0, [fp, #-0x20]
    // 0x84ec98: StoreField: r1->field_f = r0
    //     0x84ec98: stur            w0, [x1, #0xf]
    // 0x84ec9c: mov             x2, x1
    // 0x84eca0: r1 = Function '<anonymous closure>':.
    //     0x84eca0: add             x1, PP, #0xe, lsl #12  ; [pp+0xe408] AnonymousClosure: (0x8513d8), of [package:flutter/src/material/checkbox.dart] _CheckboxDefaultsM3
    //     0x84eca4: ldr             x1, [x1, #0x408]
    // 0x84eca8: r0 = AllocateClosure()
    //     0x84eca8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84ecac: r16 = <Color>
    //     0x84ecac: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84ecb0: ldr             x16, [x16, #0x3f8]
    // 0x84ecb4: stp             x0, x16, [SP, #-0x10]!
    // 0x84ecb8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x84ecb8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x84ecbc: r0 = resolveWith()
    //     0x84ecbc: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x84ecc0: add             SP, SP, #0x10
    // 0x84ecc4: b               #0x84ece0
    // 0x84ecc8: r16 = <Color>
    //     0x84ecc8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x84eccc: ldr             x16, [x16, #0x3f8]
    // 0x84ecd0: SaveReg r16
    //     0x84ecd0: str             x16, [SP, #-8]!
    // 0x84ecd4: r4 = const [0x1, 0, 0, 0, null]
    //     0x84ecd4: ldr             x4, [PP, #0x38]  ; [pp+0x38] List(5) [0x1, 0, 0, 0, Null]
    // 0x84ecd8: r0 = all()
    //     0x84ecd8: bl              #0x850ff4  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::all
    // 0x84ecdc: add             SP, SP, #8
    // 0x84ece0: r1 = LoadClassIdInstr(r0)
    //     0x84ece0: ldur            x1, [x0, #-1]
    //     0x84ece4: ubfx            x1, x1, #0xc, #0x14
    // 0x84ece8: ldur            x16, [fp, #-0x60]
    // 0x84ecec: stp             x16, x0, [SP, #-0x10]!
    // 0x84ecf0: mov             x0, x1
    // 0x84ecf4: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x84ecf4: mov             x17, #0x5e7
    //     0x84ecf8: movk            x17, #1, lsl #16
    //     0x84ecfc: add             lr, x0, x17
    //     0x84ed00: ldr             lr, [x21, lr, lsl #3]
    //     0x84ed04: blr             lr
    // 0x84ed08: add             SP, SP, #0x10
    // 0x84ed0c: cmp             w0, NULL
    // 0x84ed10: b.eq            #0x84f0dc
    // 0x84ed14: mov             x2, x0
    // 0x84ed18: b               #0x84ed20
    // 0x84ed1c: mov             x2, x0
    // 0x84ed20: ldr             x0, [fp, #0x18]
    // 0x84ed24: ldur            x1, [fp, #-0x10]
    // 0x84ed28: stur            x2, [fp, #-0x60]
    // 0x84ed2c: LoadField: r3 = r0->field_b
    //     0x84ed2c: ldur            w3, [x0, #0xb]
    // 0x84ed30: DecompressPointer r3
    //     0x84ed30: add             x3, x3, HEAP, lsl #32
    // 0x84ed34: cmp             w3, NULL
    // 0x84ed38: b.eq            #0x84f0e0
    // 0x84ed3c: LoadField: r4 = r1->field_17
    //     0x84ed3c: ldur            w4, [x1, #0x17]
    // 0x84ed40: DecompressPointer r4
    //     0x84ed40: add             x4, x4, HEAP, lsl #32
    // 0x84ed44: cmp             w4, NULL
    // 0x84ed48: b.ne            #0x84ed94
    // 0x84ed4c: ldur            x1, [fp, #-0x18]
    // 0x84ed50: r17 = 5632
    //     0x84ed50: mov             x17, #0x1600
    // 0x84ed54: cmp             w1, w17
    // 0x84ed58: b.ne            #0x84ed70
    // 0x84ed5c: ldur            x1, [fp, #-0x20]
    // 0x84ed60: LoadField: r4 = r1->field_17
    //     0x84ed60: ldur            w4, [x1, #0x17]
    // 0x84ed64: DecompressPointer r4
    //     0x84ed64: add             x4, x4, HEAP, lsl #32
    // 0x84ed68: mov             x1, x4
    // 0x84ed6c: b               #0x84ed98
    // 0x84ed70: r17 = 5634
    //     0x84ed70: mov             x17, #0x1602
    // 0x84ed74: cmp             w1, w17
    // 0x84ed78: b.ne            #0x84ed88
    // 0x84ed7c: r1 = 20.000000
    //     0x84ed7c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0x84ed80: ldr             x1, [x1, #0x420]
    // 0x84ed84: b               #0x84ed98
    // 0x84ed88: r1 = 20.000000
    //     0x84ed88: add             x1, PP, #0xe, lsl #12  ; [pp+0xe420] 20
    //     0x84ed8c: ldr             x1, [x1, #0x420]
    // 0x84ed90: b               #0x84ed98
    // 0x84ed94: mov             x1, x4
    // 0x84ed98: stur            x1, [fp, #-0x20]
    // 0x84ed9c: LoadField: r4 = r3->field_b
    //     0x84ed9c: ldur            w4, [x3, #0xb]
    // 0x84eda0: DecompressPointer r4
    //     0x84eda0: add             x4, x4, HEAP, lsl #32
    // 0x84eda4: stur            x4, [fp, #-0x18]
    // 0x84eda8: LoadField: r3 = r0->field_4b
    //     0x84eda8: ldur            w3, [x0, #0x4b]
    // 0x84edac: DecompressPointer r3
    //     0x84edac: add             x3, x3, HEAP, lsl #32
    // 0x84edb0: stur            x3, [fp, #-0x10]
    // 0x84edb4: LoadField: r5 = r0->field_1f
    //     0x84edb4: ldur            w5, [x0, #0x1f]
    // 0x84edb8: DecompressPointer r5
    //     0x84edb8: add             x5, x5, HEAP, lsl #32
    // 0x84edbc: r16 = Sentinel
    //     0x84edbc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84edc0: cmp             w5, w16
    // 0x84edc4: b.eq            #0x84f0e4
    // 0x84edc8: stp             x5, x3, [SP, #-0x10]!
    // 0x84edcc: r0 = position=()
    //     0x84edcc: bl              #0x850ef4  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::position=
    // 0x84edd0: add             SP, SP, #0x10
    // 0x84edd4: ldr             x0, [fp, #0x18]
    // 0x84edd8: LoadField: r1 = r0->field_27
    //     0x84edd8: ldur            w1, [x0, #0x27]
    // 0x84eddc: DecompressPointer r1
    //     0x84eddc: add             x1, x1, HEAP, lsl #32
    // 0x84ede0: r16 = Sentinel
    //     0x84ede0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84ede4: cmp             w1, w16
    // 0x84ede8: b.eq            #0x84f0f0
    // 0x84edec: ldur            x16, [fp, #-0x10]
    // 0x84edf0: stp             x1, x16, [SP, #-0x10]!
    // 0x84edf4: r0 = reaction=()
    //     0x84edf4: bl              #0x850df4  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::reaction=
    // 0x84edf8: add             SP, SP, #0x10
    // 0x84edfc: ldr             x0, [fp, #0x18]
    // 0x84ee00: LoadField: r1 = r0->field_33
    //     0x84ee00: ldur            w1, [x0, #0x33]
    // 0x84ee04: DecompressPointer r1
    //     0x84ee04: add             x1, x1, HEAP, lsl #32
    // 0x84ee08: r16 = Sentinel
    //     0x84ee08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84ee0c: cmp             w1, w16
    // 0x84ee10: b.eq            #0x84f0fc
    // 0x84ee14: ldur            x16, [fp, #-0x10]
    // 0x84ee18: stp             x1, x16, [SP, #-0x10]!
    // 0x84ee1c: r0 = reactionFocusFade=()
    //     0x84ee1c: bl              #0x850cf4  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::reactionFocusFade=
    // 0x84ee20: add             SP, SP, #0x10
    // 0x84ee24: ldr             x0, [fp, #0x18]
    // 0x84ee28: LoadField: r1 = r0->field_2b
    //     0x84ee28: ldur            w1, [x0, #0x2b]
    // 0x84ee2c: DecompressPointer r1
    //     0x84ee2c: add             x1, x1, HEAP, lsl #32
    // 0x84ee30: r16 = Sentinel
    //     0x84ee30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x84ee34: cmp             w1, w16
    // 0x84ee38: b.eq            #0x84f108
    // 0x84ee3c: ldur            x16, [fp, #-0x10]
    // 0x84ee40: stp             x1, x16, [SP, #-0x10]!
    // 0x84ee44: r0 = reactionHoverFade=()
    //     0x84ee44: bl              #0x850bf4  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::reactionHoverFade=
    // 0x84ee48: add             SP, SP, #0x10
    // 0x84ee4c: ldur            x16, [fp, #-0x10]
    // 0x84ee50: ldur            lr, [fp, #-0x38]
    // 0x84ee54: stp             lr, x16, [SP, #-0x10]!
    // 0x84ee58: r0 = inactiveReactionColor=()
    //     0x84ee58: bl              #0x850a08  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::inactiveReactionColor=
    // 0x84ee5c: add             SP, SP, #0x10
    // 0x84ee60: ldur            x16, [fp, #-0x10]
    // 0x84ee64: ldur            lr, [fp, #-0x30]
    // 0x84ee68: stp             lr, x16, [SP, #-0x10]!
    // 0x84ee6c: r0 = reactionColor=()
    //     0x84ee6c: bl              #0x85081c  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::reactionColor=
    // 0x84ee70: add             SP, SP, #0x10
    // 0x84ee74: ldur            x16, [fp, #-0x10]
    // 0x84ee78: ldur            lr, [fp, #-0x50]
    // 0x84ee7c: stp             lr, x16, [SP, #-0x10]!
    // 0x84ee80: r0 = hoverColor=()
    //     0x84ee80: bl              #0x850630  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::hoverColor=
    // 0x84ee84: add             SP, SP, #0x10
    // 0x84ee88: ldur            x16, [fp, #-0x10]
    // 0x84ee8c: ldur            lr, [fp, #-0x40]
    // 0x84ee90: stp             lr, x16, [SP, #-0x10]!
    // 0x84ee94: r0 = focusColor=()
    //     0x84ee94: bl              #0x850444  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::focusColor=
    // 0x84ee98: add             SP, SP, #0x10
    // 0x84ee9c: ldur            x0, [fp, #-0x20]
    // 0x84eea0: LoadField: d0 = r0->field_7
    //     0x84eea0: ldur            d0, [x0, #7]
    // 0x84eea4: ldur            x16, [fp, #-0x10]
    // 0x84eea8: SaveReg r16
    //     0x84eea8: str             x16, [SP, #-8]!
    // 0x84eeac: SaveReg d0
    //     0x84eeac: str             d0, [SP, #-8]!
    // 0x84eeb0: r0 = splashRadius=()
    //     0x84eeb0: bl              #0x85036c  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::splashRadius=
    // 0x84eeb4: add             SP, SP, #0x10
    // 0x84eeb8: ldr             x0, [fp, #0x18]
    // 0x84eebc: LoadField: r1 = r0->field_3f
    //     0x84eebc: ldur            w1, [x0, #0x3f]
    // 0x84eec0: DecompressPointer r1
    //     0x84eec0: add             x1, x1, HEAP, lsl #32
    // 0x84eec4: ldur            x16, [fp, #-0x10]
    // 0x84eec8: stp             x1, x16, [SP, #-0x10]!
    // 0x84eecc: r0 = downPosition=()
    //     0x84eecc: bl              #0x8502cc  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::downPosition=
    // 0x84eed0: add             SP, SP, #0x10
    // 0x84eed4: ldr             x16, [fp, #0x18]
    // 0x84eed8: SaveReg r16
    //     0x84eed8: str             x16, [SP, #-8]!
    // 0x84eedc: r0 = states()
    //     0x84eedc: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84eee0: add             SP, SP, #8
    // 0x84eee4: r16 = Instance_MaterialState
    //     0x84eee4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x84eee8: ldr             x16, [x16, #0xf88]
    // 0x84eeec: stp             x16, x0, [SP, #-0x10]!
    // 0x84eef0: r0 = contains()
    //     0x84eef0: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84eef4: add             SP, SP, #0x10
    // 0x84eef8: ldur            x16, [fp, #-0x10]
    // 0x84eefc: stp             x0, x16, [SP, #-0x10]!
    // 0x84ef00: r0 = isFocused=()
    //     0x84ef00: bl              #0x850268  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::isFocused=
    // 0x84ef04: add             SP, SP, #0x10
    // 0x84ef08: ldr             x16, [fp, #0x18]
    // 0x84ef0c: SaveReg r16
    //     0x84ef0c: str             x16, [SP, #-8]!
    // 0x84ef10: r0 = states()
    //     0x84ef10: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84ef14: add             SP, SP, #8
    // 0x84ef18: r16 = Instance_MaterialState
    //     0x84ef18: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x84ef1c: ldr             x16, [x16, #0xf78]
    // 0x84ef20: stp             x16, x0, [SP, #-0x10]!
    // 0x84ef24: r0 = contains()
    //     0x84ef24: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84ef28: add             SP, SP, #0x10
    // 0x84ef2c: ldur            x16, [fp, #-0x10]
    // 0x84ef30: stp             x0, x16, [SP, #-0x10]!
    // 0x84ef34: r0 = isHovered=()
    //     0x84ef34: bl              #0x850204  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::isHovered=
    // 0x84ef38: add             SP, SP, #0x10
    // 0x84ef3c: ldur            x16, [fp, #-0x10]
    // 0x84ef40: ldur            lr, [fp, #-0x48]
    // 0x84ef44: stp             lr, x16, [SP, #-0x10]!
    // 0x84ef48: r0 = activeColor=()
    //     0x84ef48: bl              #0x850164  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::activeColor=
    // 0x84ef4c: add             SP, SP, #0x10
    // 0x84ef50: ldur            x16, [fp, #-0x10]
    // 0x84ef54: ldur            lr, [fp, #-0x58]
    // 0x84ef58: stp             lr, x16, [SP, #-0x10]!
    // 0x84ef5c: r0 = inactiveColor=()
    //     0x84ef5c: bl              #0x8500c4  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::inactiveColor=
    // 0x84ef60: add             SP, SP, #0x10
    // 0x84ef64: ldur            x16, [fp, #-0x10]
    // 0x84ef68: ldur            lr, [fp, #-0x60]
    // 0x84ef6c: stp             lr, x16, [SP, #-0x10]!
    // 0x84ef70: r0 = checkColor=()
    //     0x84ef70: bl              #0x850024  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::checkColor=
    // 0x84ef74: add             SP, SP, #0x10
    // 0x84ef78: ldr             x0, [fp, #0x18]
    // 0x84ef7c: LoadField: r1 = r0->field_b
    //     0x84ef7c: ldur            w1, [x0, #0xb]
    // 0x84ef80: DecompressPointer r1
    //     0x84ef80: add             x1, x1, HEAP, lsl #32
    // 0x84ef84: cmp             w1, NULL
    // 0x84ef88: b.eq            #0x84f114
    // 0x84ef8c: LoadField: r2 = r1->field_b
    //     0x84ef8c: ldur            w2, [x1, #0xb]
    // 0x84ef90: DecompressPointer r2
    //     0x84ef90: add             x2, x2, HEAP, lsl #32
    // 0x84ef94: ldur            x16, [fp, #-0x10]
    // 0x84ef98: stp             x2, x16, [SP, #-0x10]!
    // 0x84ef9c: r0 = value=()
    //     0x84ef9c: bl              #0x84ffc0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::value=
    // 0x84efa0: add             SP, SP, #0x10
    // 0x84efa4: ldr             x0, [fp, #0x18]
    // 0x84efa8: LoadField: r1 = r0->field_4f
    //     0x84efa8: ldur            w1, [x0, #0x4f]
    // 0x84efac: DecompressPointer r1
    //     0x84efac: add             x1, x1, HEAP, lsl #32
    // 0x84efb0: ldur            x16, [fp, #-0x10]
    // 0x84efb4: stp             x1, x16, [SP, #-0x10]!
    // 0x84efb8: r0 = previousValue=()
    //     0x84efb8: bl              #0x84ff5c  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::previousValue=
    // 0x84efbc: add             SP, SP, #0x10
    // 0x84efc0: ldr             x0, [fp, #0x18]
    // 0x84efc4: LoadField: r1 = r0->field_b
    //     0x84efc4: ldur            w1, [x0, #0xb]
    // 0x84efc8: DecompressPointer r1
    //     0x84efc8: add             x1, x1, HEAP, lsl #32
    // 0x84efcc: cmp             w1, NULL
    // 0x84efd0: b.eq            #0x84f118
    // 0x84efd4: LoadField: r2 = r1->field_47
    //     0x84efd4: ldur            w2, [x1, #0x47]
    // 0x84efd8: DecompressPointer r2
    //     0x84efd8: add             x2, x2, HEAP, lsl #32
    // 0x84efdc: ldur            x16, [fp, #-0x10]
    // 0x84efe0: stp             x2, x16, [SP, #-0x10]!
    // 0x84efe4: r0 = shape=()
    //     0x84efe4: bl              #0x84febc  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::shape=
    // 0x84efe8: add             SP, SP, #0x10
    // 0x84efec: ldr             x0, [fp, #0x18]
    // 0x84eff0: LoadField: r1 = r0->field_b
    //     0x84eff0: ldur            w1, [x0, #0xb]
    // 0x84eff4: DecompressPointer r1
    //     0x84eff4: add             x1, x1, HEAP, lsl #32
    // 0x84eff8: cmp             w1, NULL
    // 0x84effc: b.eq            #0x84f11c
    // 0x84f000: SaveReg r0
    //     0x84f000: str             x0, [SP, #-8]!
    // 0x84f004: r0 = _resolveSide()
    //     0x84f004: bl              #0x84fe58  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::_resolveSide
    // 0x84f008: add             SP, SP, #8
    // 0x84f00c: ldr             x16, [fp, #0x18]
    // 0x84f010: SaveReg r16
    //     0x84f010: str             x16, [SP, #-8]!
    // 0x84f014: r0 = _resolveSide()
    //     0x84f014: bl              #0x84fe58  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::_resolveSide
    // 0x84f018: add             SP, SP, #8
    // 0x84f01c: ldur            x16, [fp, #-0x10]
    // 0x84f020: stp             NULL, x16, [SP, #-0x10]!
    // 0x84f024: r0 = Shader._()
    //     0x84f024: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x84f028: add             SP, SP, #0x10
    // 0x84f02c: ldr             x16, [fp, #0x18]
    // 0x84f030: ldur            lr, [fp, #-0x28]
    // 0x84f034: stp             lr, x16, [SP, #-0x10]!
    // 0x84f038: ldur            x16, [fp, #-0x10]
    // 0x84f03c: ldur            lr, [fp, #-8]
    // 0x84f040: stp             lr, x16, [SP, #-0x10]!
    // 0x84f044: r0 = buildToggleable()
    //     0x84f044: bl              #0x84f120  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::buildToggleable
    // 0x84f048: add             SP, SP, #0x20
    // 0x84f04c: stur            x0, [fp, #-8]
    // 0x84f050: r0 = Semantics()
    //     0x84f050: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x84f054: stur            x0, [fp, #-0x10]
    // 0x84f058: ldur            x16, [fp, #-0x18]
    // 0x84f05c: stp             x16, x0, [SP, #-0x10]!
    // 0x84f060: ldur            x16, [fp, #-8]
    // 0x84f064: stp             x16, NULL, [SP, #-0x10]!
    // 0x84f068: r4 = const [0, 0x4, 0x4, 0x1, checked, 0x1, child, 0x3, mixed, 0x2, null]
    //     0x84f068: add             x4, PP, #0x56, lsl #12  ; [pp+0x56558] List(11) [0, 0x4, 0x4, 0x1, "checked", 0x1, "child", 0x3, "mixed", 0x2, Null]
    //     0x84f06c: ldr             x4, [x4, #0x558]
    // 0x84f070: r0 = Semantics()
    //     0x84f070: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x84f074: add             SP, SP, #0x20
    // 0x84f078: ldur            x0, [fp, #-0x10]
    // 0x84f07c: LeaveFrame
    //     0x84f07c: mov             SP, fp
    //     0x84f080: ldp             fp, lr, [SP], #0x10
    // 0x84f084: ret
    //     0x84f084: ret             
    // 0x84f088: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f088: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f08c: b               #0x84e068
    // 0x84f090: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f090: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f094: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f094: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f098: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f098: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f09c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f09c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f0e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f0e4: r9 = _position
    //     0x84f0e4: add             x9, PP, #0x56, lsl #12  ; [pp+0x56560] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._position@837519154>: late (offset: 0x20)
    //     0x84f0e8: ldr             x9, [x9, #0x560]
    // 0x84f0ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f0ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f0f0: r9 = _reaction
    //     0x84f0f0: add             x9, PP, #0x56, lsl #12  ; [pp+0x56568] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reaction@837519154>: late (offset: 0x28)
    //     0x84f0f4: ldr             x9, [x9, #0x568]
    // 0x84f0f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f0f8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f0fc: r9 = _reactionFocusFade
    //     0x84f0fc: add             x9, PP, #0x56, lsl #12  ; [pp+0x56570] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionFocusFade@837519154>: late (offset: 0x34)
    //     0x84f100: ldr             x9, [x9, #0x570]
    // 0x84f104: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f104: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f108: r9 = _reactionHoverFade
    //     0x84f108: add             x9, PP, #0x56, lsl #12  ; [pp+0x56578] Field <__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin@704279226._reactionHoverFade@837519154>: late (offset: 0x2c)
    //     0x84f10c: ldr             x9, [x9, #0x578]
    // 0x84f110: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x84f110: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x84f114: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f114: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f118: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84f11c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84f11c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _resolveSide(/* No info */) {
    // ** addr: 0x84fe58, size: 0x64
    // 0x84fe58: EnterFrame
    //     0x84fe58: stp             fp, lr, [SP, #-0x10]!
    //     0x84fe5c: mov             fp, SP
    // 0x84fe60: CheckStackOverflow
    //     0x84fe60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fe64: cmp             SP, x16
    //     0x84fe68: b.ls            #0x84feb4
    // 0x84fe6c: ldr             x16, [fp, #0x10]
    // 0x84fe70: SaveReg r16
    //     0x84fe70: str             x16, [SP, #-8]!
    // 0x84fe74: r0 = states()
    //     0x84fe74: bl              #0x8510b4  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::states
    // 0x84fe78: add             SP, SP, #8
    // 0x84fe7c: r16 = Instance_MaterialState
    //     0x84fe7c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x84fe80: ldr             x16, [x16, #0xf70]
    // 0x84fe84: stp             x16, x0, [SP, #-0x10]!
    // 0x84fe88: r0 = contains()
    //     0x84fe88: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84fe8c: add             SP, SP, #0x10
    // 0x84fe90: tbz             w0, #4, #0x84fea4
    // 0x84fe94: r0 = Null
    //     0x84fe94: mov             x0, NULL
    // 0x84fe98: LeaveFrame
    //     0x84fe98: mov             SP, fp
    //     0x84fe9c: ldp             fp, lr, [SP], #0x10
    // 0x84fea0: ret
    //     0x84fea0: ret             
    // 0x84fea4: r0 = Null
    //     0x84fea4: mov             x0, NULL
    // 0x84fea8: LeaveFrame
    //     0x84fea8: mov             SP, fp
    //     0x84feac: ldp             fp, lr, [SP], #0x10
    // 0x84feb0: ret
    //     0x84feb0: ret             
    // 0x84feb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84feb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84feb8: b               #0x84fe6c
  }
  get _ _widgetFillColor(/* No info */) {
    // ** addr: 0x851050, size: 0x64
    // 0x851050: EnterFrame
    //     0x851050: stp             fp, lr, [SP, #-0x10]!
    //     0x851054: mov             fp, SP
    // 0x851058: CheckStackOverflow
    //     0x851058: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85105c: cmp             SP, x16
    //     0x851060: b.ls            #0x8510ac
    // 0x851064: r1 = 1
    //     0x851064: mov             x1, #1
    // 0x851068: r0 = AllocateContext()
    //     0x851068: bl              #0xd68aa4  ; AllocateContextStub
    // 0x85106c: mov             x1, x0
    // 0x851070: ldr             x0, [fp, #0x10]
    // 0x851074: StoreField: r1->field_f = r0
    //     0x851074: stur            w0, [x1, #0xf]
    // 0x851078: mov             x2, x1
    // 0x85107c: r1 = Function '<anonymous closure>':.
    //     0x85107c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56550] AnonymousClosure: (0x851268), in [package:flutter/src/material/checkbox.dart] _CheckboxState::_widgetFillColor (0x851050)
    //     0x851080: ldr             x1, [x1, #0x550]
    // 0x851084: r0 = AllocateClosure()
    //     0x851084: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x851088: r16 = <Color?>
    //     0x851088: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x85108c: ldr             x16, [x16, #0xf68]
    // 0x851090: stp             x0, x16, [SP, #-0x10]!
    // 0x851094: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x851094: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x851098: r0 = resolveWith()
    //     0x851098: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0x85109c: add             SP, SP, #0x10
    // 0x8510a0: LeaveFrame
    //     0x8510a0: mov             SP, fp
    //     0x8510a4: ldp             fp, lr, [SP], #0x10
    // 0x8510a8: ret
    //     0x8510a8: ret             
    // 0x8510ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8510ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8510b0: b               #0x851064
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x851268, size: 0xe8
    // 0x851268: EnterFrame
    //     0x851268: stp             fp, lr, [SP, #-0x10]!
    //     0x85126c: mov             fp, SP
    // 0x851270: AllocStack(0x8)
    //     0x851270: sub             SP, SP, #8
    // 0x851274: SetupParameters()
    //     0x851274: ldr             x0, [fp, #0x18]
    //     0x851278: ldur            w1, [x0, #0x17]
    //     0x85127c: add             x1, x1, HEAP, lsl #32
    //     0x851280: stur            x1, [fp, #-8]
    // 0x851284: CheckStackOverflow
    //     0x851284: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x851288: cmp             SP, x16
    //     0x85128c: b.ls            #0x851344
    // 0x851290: ldr             x2, [fp, #0x10]
    // 0x851294: r0 = LoadClassIdInstr(r2)
    //     0x851294: ldur            x0, [x2, #-1]
    //     0x851298: ubfx            x0, x0, #0xc, #0x14
    // 0x85129c: r16 = Instance_MaterialState
    //     0x85129c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x8512a0: ldr             x16, [x16, #0x2a0]
    // 0x8512a4: stp             x16, x2, [SP, #-0x10]!
    // 0x8512a8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8512a8: mov             x17, #0xc98a
    //     0x8512ac: add             lr, x0, x17
    //     0x8512b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8512b4: blr             lr
    // 0x8512b8: add             SP, SP, #0x10
    // 0x8512bc: tbnz            w0, #4, #0x8512d0
    // 0x8512c0: r0 = Null
    //     0x8512c0: mov             x0, NULL
    // 0x8512c4: LeaveFrame
    //     0x8512c4: mov             SP, fp
    //     0x8512c8: ldp             fp, lr, [SP], #0x10
    // 0x8512cc: ret
    //     0x8512cc: ret             
    // 0x8512d0: ldr             x0, [fp, #0x10]
    // 0x8512d4: r1 = LoadClassIdInstr(r0)
    //     0x8512d4: ldur            x1, [x0, #-1]
    //     0x8512d8: ubfx            x1, x1, #0xc, #0x14
    // 0x8512dc: r16 = Instance_MaterialState
    //     0x8512dc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf70] Obj!MaterialState@b65491
    //     0x8512e0: ldr             x16, [x16, #0xf70]
    // 0x8512e4: stp             x16, x0, [SP, #-0x10]!
    // 0x8512e8: mov             x0, x1
    // 0x8512ec: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8512ec: mov             x17, #0xc98a
    //     0x8512f0: add             lr, x0, x17
    //     0x8512f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8512f8: blr             lr
    // 0x8512fc: add             SP, SP, #0x10
    // 0x851300: tbnz            w0, #4, #0x851334
    // 0x851304: ldur            x1, [fp, #-8]
    // 0x851308: LoadField: r2 = r1->field_f
    //     0x851308: ldur            w2, [x1, #0xf]
    // 0x85130c: DecompressPointer r2
    //     0x85130c: add             x2, x2, HEAP, lsl #32
    // 0x851310: LoadField: r1 = r2->field_b
    //     0x851310: ldur            w1, [x2, #0xb]
    // 0x851314: DecompressPointer r1
    //     0x851314: add             x1, x1, HEAP, lsl #32
    // 0x851318: cmp             w1, NULL
    // 0x85131c: b.eq            #0x85134c
    // 0x851320: LoadField: r0 = r1->field_17
    //     0x851320: ldur            w0, [x1, #0x17]
    // 0x851324: DecompressPointer r0
    //     0x851324: add             x0, x0, HEAP, lsl #32
    // 0x851328: LeaveFrame
    //     0x851328: mov             SP, fp
    //     0x85132c: ldp             fp, lr, [SP], #0x10
    // 0x851330: ret
    //     0x851330: ret             
    // 0x851334: r0 = Null
    //     0x851334: mov             x0, NULL
    // 0x851338: LeaveFrame
    //     0x851338: mov             SP, fp
    //     0x85133c: ldp             fp, lr, [SP], #0x10
    // 0x851340: ret
    //     0x851340: ret             
    // 0x851344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x851344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x851348: b               #0x851290
    // 0x85134c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85134c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] MouseCursor <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x851350, size: 0x88
    // 0x851350: EnterFrame
    //     0x851350: stp             fp, lr, [SP, #-0x10]!
    //     0x851354: mov             fp, SP
    // 0x851358: ldr             x0, [fp, #0x18]
    // 0x85135c: LoadField: r1 = r0->field_17
    //     0x85135c: ldur            w1, [x0, #0x17]
    // 0x851360: DecompressPointer r1
    //     0x851360: add             x1, x1, HEAP, lsl #32
    // 0x851364: CheckStackOverflow
    //     0x851364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x851368: cmp             SP, x16
    //     0x85136c: b.ls            #0x8513cc
    // 0x851370: LoadField: r0 = r1->field_f
    //     0x851370: ldur            w0, [x1, #0xf]
    // 0x851374: DecompressPointer r0
    //     0x851374: add             x0, x0, HEAP, lsl #32
    // 0x851378: LoadField: r1 = r0->field_b
    //     0x851378: ldur            w1, [x0, #0xb]
    // 0x85137c: DecompressPointer r1
    //     0x85137c: add             x1, x1, HEAP, lsl #32
    // 0x851380: cmp             w1, NULL
    // 0x851384: b.eq            #0x8513d4
    // 0x851388: r16 = <MouseCursor?>
    //     0x851388: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0x85138c: ldr             x16, [x16, #0x8b8]
    // 0x851390: stp             NULL, x16, [SP, #-0x10]!
    // 0x851394: ldr             x16, [fp, #0x10]
    // 0x851398: SaveReg r16
    //     0x851398: str             x16, [SP, #-8]!
    // 0x85139c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x85139c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8513a0: r0 = resolveAs()
    //     0x8513a0: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x8513a4: add             SP, SP, #0x18
    // 0x8513a8: r16 = Instance__EnabledAndDisabledMouseCursor
    //     0x8513a8: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0x8513ac: ldr             x16, [x16, #0x208]
    // 0x8513b0: ldr             lr, [fp, #0x10]
    // 0x8513b4: stp             lr, x16, [SP, #-0x10]!
    // 0x8513b8: r0 = resolve()
    //     0x8513b8: bl              #0x5a6cbc  ; [package:flutter/src/material/material_state.dart] _EnabledAndDisabledMouseCursor::resolve
    // 0x8513bc: add             SP, SP, #0x10
    // 0x8513c0: LeaveFrame
    //     0x8513c0: mov             SP, fp
    //     0x8513c4: ldp             fp, lr, [SP], #0x10
    // 0x8513c8: ret
    //     0x8513c8: ret             
    // 0x8513cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8513cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8513d0: b               #0x851370
    // 0x8513d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8513d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d94fc, size: 0x60
    // 0x9d94fc: EnterFrame
    //     0x9d94fc: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9500: mov             fp, SP
    // 0x9d9504: CheckStackOverflow
    //     0x9d9504: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9508: cmp             SP, x16
    //     0x9d950c: b.ls            #0x9d9550
    // 0x9d9510: ldr             x16, [fp, #0x10]
    // 0x9d9514: SaveReg r16
    //     0x9d9514: str             x16, [SP, #-8]!
    // 0x9d9518: r0 = initState()
    //     0x9d9518: bl              #0x9d955c  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::initState
    // 0x9d951c: add             SP, SP, #8
    // 0x9d9520: ldr             x1, [fp, #0x10]
    // 0x9d9524: LoadField: r2 = r1->field_b
    //     0x9d9524: ldur            w2, [x1, #0xb]
    // 0x9d9528: DecompressPointer r2
    //     0x9d9528: add             x2, x2, HEAP, lsl #32
    // 0x9d952c: cmp             w2, NULL
    // 0x9d9530: b.eq            #0x9d9558
    // 0x9d9534: LoadField: r3 = r2->field_b
    //     0x9d9534: ldur            w3, [x2, #0xb]
    // 0x9d9538: DecompressPointer r3
    //     0x9d9538: add             x3, x3, HEAP, lsl #32
    // 0x9d953c: StoreField: r1->field_4f = r3
    //     0x9d953c: stur            w3, [x1, #0x4f]
    // 0x9d9540: r0 = Null
    //     0x9d9540: mov             x0, NULL
    // 0x9d9544: LeaveFrame
    //     0x9d9544: mov             SP, fp
    //     0x9d9548: ldp             fp, lr, [SP], #0x10
    // 0x9d954c: ret
    //     0x9d954c: ret             
    // 0x9d9550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d9550: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d9554: b               #0x9d9510
    // 0x9d9558: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d9558: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _CheckboxState(/* No info */) {
    // ** addr: 0xa403a4, size: 0xa0
    // 0xa403a4: EnterFrame
    //     0xa403a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa403a8: mov             fp, SP
    // 0xa403ac: AllocStack(0x8)
    //     0xa403ac: sub             SP, SP, #8
    // 0xa403b0: CheckStackOverflow
    //     0xa403b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa403b4: cmp             SP, x16
    //     0xa403b8: b.ls            #0xa4043c
    // 0xa403bc: r0 = _CheckboxPainter()
    //     0xa403bc: bl              #0xa40484  ; Allocate_CheckboxPainterStub -> _CheckboxPainter (size=0x70)
    // 0xa403c0: mov             x1, x0
    // 0xa403c4: r0 = 0
    //     0xa403c4: mov             x0, #0
    // 0xa403c8: stur            x1, [fp, #-8]
    // 0xa403cc: StoreField: r1->field_7 = r0
    //     0xa403cc: stur            x0, [x1, #7]
    // 0xa403d0: StoreField: r1->field_13 = r0
    //     0xa403d0: stur            x0, [x1, #0x13]
    // 0xa403d4: StoreField: r1->field_1b = r0
    //     0xa403d4: stur            x0, [x1, #0x1b]
    // 0xa403d8: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0xa403d8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa403dc: ldr             x0, [x0, #0x1580]
    //     0xa403e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa403e4: cmp             w0, w16
    //     0xa403e8: b.ne            #0xa403f4
    //     0xa403ec: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0xa403f0: bl              #0xd67cdc
    // 0xa403f4: mov             x1, x0
    // 0xa403f8: ldur            x0, [fp, #-8]
    // 0xa403fc: StoreField: r0->field_f = r1
    //     0xa403fc: stur            w1, [x0, #0xf]
    // 0xa40400: ldr             x1, [fp, #0x10]
    // 0xa40404: StoreField: r1->field_4b = r0
    //     0xa40404: stur            w0, [x1, #0x4b]
    //     0xa40408: ldurb           w16, [x1, #-1]
    //     0xa4040c: ldurb           w17, [x0, #-1]
    //     0xa40410: and             x16, x17, x16, lsr #2
    //     0xa40414: tst             x16, HEAP, lsr #32
    //     0xa40418: b.eq            #0xa40420
    //     0xa4041c: bl              #0xd6826c
    // 0xa40420: SaveReg r1
    //     0xa40420: str             x1, [SP, #-8]!
    // 0xa40424: r0 = __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin()
    //     0xa40424: bl              #0xa40444  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::__CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin
    // 0xa40428: add             SP, SP, #8
    // 0xa4042c: r0 = Null
    //     0xa4042c: mov             x0, NULL
    // 0xa40430: LeaveFrame
    //     0xa40430: mov             SP, fp
    //     0xa40434: ldp             fp, lr, [SP], #0x10
    // 0xa40438: ret
    //     0xa40438: ret             
    // 0xa4043c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4043c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40440: b               #0xa403bc
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4aac8, size: 0x18
    // 0xa4aac8: r4 = 7
    //     0xa4aac8: mov             x4, #7
    // 0xa4aacc: r1 = Function 'dispose':.
    //     0xa4aacc: add             x17, PP, #0x56, lsl #12  ; [pp+0x56538] AnonymousClosure: (0xa4aae0), in [package:flutter/src/material/checkbox.dart] _CheckboxState::dispose (0xa512c4)
    //     0xa4aad0: ldr             x1, [x17, #0x538]
    // 0xa4aad4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4aad4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4aad8: LoadField: r0 = r24->field_17
    //     0xa4aad8: ldur            x0, [x24, #0x17]
    // 0xa4aadc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4aae0, size: 0x48
    // 0xa4aae0: EnterFrame
    //     0xa4aae0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4aae4: mov             fp, SP
    // 0xa4aae8: ldr             x0, [fp, #0x10]
    // 0xa4aaec: LoadField: r1 = r0->field_17
    //     0xa4aaec: ldur            w1, [x0, #0x17]
    // 0xa4aaf0: DecompressPointer r1
    //     0xa4aaf0: add             x1, x1, HEAP, lsl #32
    // 0xa4aaf4: CheckStackOverflow
    //     0xa4aaf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4aaf8: cmp             SP, x16
    //     0xa4aafc: b.ls            #0xa4ab20
    // 0xa4ab00: LoadField: r0 = r1->field_f
    //     0xa4ab00: ldur            w0, [x1, #0xf]
    // 0xa4ab04: DecompressPointer r0
    //     0xa4ab04: add             x0, x0, HEAP, lsl #32
    // 0xa4ab08: SaveReg r0
    //     0xa4ab08: str             x0, [SP, #-8]!
    // 0xa4ab0c: r0 = dispose()
    //     0xa4ab0c: bl              #0xa512c4  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::dispose
    // 0xa4ab10: add             SP, SP, #8
    // 0xa4ab14: LeaveFrame
    //     0xa4ab14: mov             SP, fp
    //     0xa4ab18: ldp             fp, lr, [SP], #0x10
    // 0xa4ab1c: ret
    //     0xa4ab1c: ret             
    // 0xa4ab20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ab20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ab24: b               #0xa4ab00
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa512c4, size: 0x54
    // 0xa512c4: EnterFrame
    //     0xa512c4: stp             fp, lr, [SP, #-0x10]!
    //     0xa512c8: mov             fp, SP
    // 0xa512cc: CheckStackOverflow
    //     0xa512cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa512d0: cmp             SP, x16
    //     0xa512d4: b.ls            #0xa51310
    // 0xa512d8: ldr             x0, [fp, #0x10]
    // 0xa512dc: LoadField: r1 = r0->field_4b
    //     0xa512dc: ldur            w1, [x0, #0x4b]
    // 0xa512e0: DecompressPointer r1
    //     0xa512e0: add             x1, x1, HEAP, lsl #32
    // 0xa512e4: SaveReg r1
    //     0xa512e4: str             x1, [SP, #-8]!
    // 0xa512e8: r0 = dispose()
    //     0xa512e8: bl              #0x9c2368  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::dispose
    // 0xa512ec: add             SP, SP, #8
    // 0xa512f0: ldr             x16, [fp, #0x10]
    // 0xa512f4: SaveReg r16
    //     0xa512f4: str             x16, [SP, #-8]!
    // 0xa512f8: r0 = dispose()
    //     0xa512f8: bl              #0xa51318  ; [package:flutter/src/material/checkbox.dart] __CheckboxState&State&TickerProviderStateMixin&ToggleableStateMixin::dispose
    // 0xa512fc: add             SP, SP, #8
    // 0xa51300: r0 = Null
    //     0xa51300: mov             x0, NULL
    // 0xa51304: LeaveFrame
    //     0xa51304: mov             SP, fp
    //     0xa51308: ldp             fp, lr, [SP], #0x10
    // 0xa5130c: ret
    //     0xa5130c: ret             
    // 0xa51310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa51310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa51314: b               #0xa512d8
  }
}

// class id: 4159, size: 0x54, field offset: 0xc
//   const constructor, 
class Checkbox extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40358, size: 0x4c
    // 0xa40358: EnterFrame
    //     0xa40358: stp             fp, lr, [SP, #-0x10]!
    //     0xa4035c: mov             fp, SP
    // 0xa40360: AllocStack(0x8)
    //     0xa40360: sub             SP, SP, #8
    // 0xa40364: CheckStackOverflow
    //     0xa40364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40368: cmp             SP, x16
    //     0xa4036c: b.ls            #0xa4039c
    // 0xa40370: r1 = <Checkbox>
    //     0xa40370: add             x1, PP, #0x55, lsl #12  ; [pp+0x558f0] TypeArguments: <Checkbox>
    //     0xa40374: ldr             x1, [x1, #0x8f0]
    // 0xa40378: r0 = _CheckboxState()
    //     0xa40378: bl              #0xa40490  ; Allocate_CheckboxStateStub -> _CheckboxState (size=0x54)
    // 0xa4037c: stur            x0, [fp, #-8]
    // 0xa40380: SaveReg r0
    //     0xa40380: str             x0, [SP, #-8]!
    // 0xa40384: r0 = _CheckboxState()
    //     0xa40384: bl              #0xa403a4  ; [package:flutter/src/material/checkbox.dart] _CheckboxState::_CheckboxState
    // 0xa40388: add             SP, SP, #8
    // 0xa4038c: ldur            x0, [fp, #-8]
    // 0xa40390: LeaveFrame
    //     0xa40390: mov             SP, fp
    //     0xa40394: ldp             fp, lr, [SP], #0x10
    // 0xa40398: ret
    //     0xa40398: ret             
    // 0xa4039c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4039c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa403a0: b               #0xa40370
  }
}

// class id: 4835, size: 0x70, field offset: 0x5c
class _CheckboxPainter extends ToggleablePainter {

  set _ shape=(/* No info */) {
    // ** addr: 0x84febc, size: 0xa0
    // 0x84febc: EnterFrame
    //     0x84febc: stp             fp, lr, [SP, #-0x10]!
    //     0x84fec0: mov             fp, SP
    // 0x84fec4: CheckStackOverflow
    //     0x84fec4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84fec8: cmp             SP, x16
    //     0x84fecc: b.ls            #0x84ff54
    // 0x84fed0: ldr             x1, [fp, #0x18]
    // 0x84fed4: LoadField: r0 = r1->field_67
    //     0x84fed4: ldur            w0, [x1, #0x67]
    // 0x84fed8: DecompressPointer r0
    //     0x84fed8: add             x0, x0, HEAP, lsl #32
    // 0x84fedc: r2 = LoadClassIdInstr(r0)
    //     0x84fedc: ldur            x2, [x0, #-1]
    //     0x84fee0: ubfx            x2, x2, #0xc, #0x14
    // 0x84fee4: ldr             x16, [fp, #0x10]
    // 0x84fee8: stp             x16, x0, [SP, #-0x10]!
    // 0x84feec: mov             x0, x2
    // 0x84fef0: mov             lr, x0
    // 0x84fef4: ldr             lr, [x21, lr, lsl #3]
    // 0x84fef8: blr             lr
    // 0x84fefc: add             SP, SP, #0x10
    // 0x84ff00: tbnz            w0, #4, #0x84ff14
    // 0x84ff04: r0 = Null
    //     0x84ff04: mov             x0, NULL
    // 0x84ff08: LeaveFrame
    //     0x84ff08: mov             SP, fp
    //     0x84ff0c: ldp             fp, lr, [SP], #0x10
    // 0x84ff10: ret
    //     0x84ff10: ret             
    // 0x84ff14: ldr             x1, [fp, #0x18]
    // 0x84ff18: ldr             x0, [fp, #0x10]
    // 0x84ff1c: StoreField: r1->field_67 = r0
    //     0x84ff1c: stur            w0, [x1, #0x67]
    //     0x84ff20: ldurb           w16, [x1, #-1]
    //     0x84ff24: ldurb           w17, [x0, #-1]
    //     0x84ff28: and             x16, x17, x16, lsr #2
    //     0x84ff2c: tst             x16, HEAP, lsr #32
    //     0x84ff30: b.eq            #0x84ff38
    //     0x84ff34: bl              #0xd6826c
    // 0x84ff38: SaveReg r1
    //     0x84ff38: str             x1, [SP, #-8]!
    // 0x84ff3c: r0 = notifyListeners()
    //     0x84ff3c: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x84ff40: add             SP, SP, #8
    // 0x84ff44: r0 = Null
    //     0x84ff44: mov             x0, NULL
    // 0x84ff48: LeaveFrame
    //     0x84ff48: mov             SP, fp
    //     0x84ff4c: ldp             fp, lr, [SP], #0x10
    // 0x84ff50: ret
    //     0x84ff50: ret             
    // 0x84ff54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ff54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ff58: b               #0x84fed0
  }
  set _ previousValue=(/* No info */) {
    // ** addr: 0x84ff5c, size: 0x64
    // 0x84ff5c: EnterFrame
    //     0x84ff5c: stp             fp, lr, [SP, #-0x10]!
    //     0x84ff60: mov             fp, SP
    // 0x84ff64: CheckStackOverflow
    //     0x84ff64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84ff68: cmp             SP, x16
    //     0x84ff6c: b.ls            #0x84ffb8
    // 0x84ff70: ldr             x0, [fp, #0x18]
    // 0x84ff74: LoadField: r1 = r0->field_63
    //     0x84ff74: ldur            w1, [x0, #0x63]
    // 0x84ff78: DecompressPointer r1
    //     0x84ff78: add             x1, x1, HEAP, lsl #32
    // 0x84ff7c: ldr             x2, [fp, #0x10]
    // 0x84ff80: cmp             w1, w2
    // 0x84ff84: b.ne            #0x84ff98
    // 0x84ff88: r0 = Null
    //     0x84ff88: mov             x0, NULL
    // 0x84ff8c: LeaveFrame
    //     0x84ff8c: mov             SP, fp
    //     0x84ff90: ldp             fp, lr, [SP], #0x10
    // 0x84ff94: ret
    //     0x84ff94: ret             
    // 0x84ff98: StoreField: r0->field_63 = r2
    //     0x84ff98: stur            w2, [x0, #0x63]
    // 0x84ff9c: SaveReg r0
    //     0x84ff9c: str             x0, [SP, #-8]!
    // 0x84ffa0: r0 = notifyListeners()
    //     0x84ffa0: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x84ffa4: add             SP, SP, #8
    // 0x84ffa8: r0 = Null
    //     0x84ffa8: mov             x0, NULL
    // 0x84ffac: LeaveFrame
    //     0x84ffac: mov             SP, fp
    //     0x84ffb0: ldp             fp, lr, [SP], #0x10
    // 0x84ffb4: ret
    //     0x84ffb4: ret             
    // 0x84ffb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84ffb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84ffbc: b               #0x84ff70
  }
  set _ value=(/* No info */) {
    // ** addr: 0x84ffc0, size: 0x64
    // 0x84ffc0: EnterFrame
    //     0x84ffc0: stp             fp, lr, [SP, #-0x10]!
    //     0x84ffc4: mov             fp, SP
    // 0x84ffc8: CheckStackOverflow
    //     0x84ffc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84ffcc: cmp             SP, x16
    //     0x84ffd0: b.ls            #0x85001c
    // 0x84ffd4: ldr             x0, [fp, #0x18]
    // 0x84ffd8: LoadField: r1 = r0->field_5f
    //     0x84ffd8: ldur            w1, [x0, #0x5f]
    // 0x84ffdc: DecompressPointer r1
    //     0x84ffdc: add             x1, x1, HEAP, lsl #32
    // 0x84ffe0: ldr             x2, [fp, #0x10]
    // 0x84ffe4: cmp             w1, w2
    // 0x84ffe8: b.ne            #0x84fffc
    // 0x84ffec: r0 = Null
    //     0x84ffec: mov             x0, NULL
    // 0x84fff0: LeaveFrame
    //     0x84fff0: mov             SP, fp
    //     0x84fff4: ldp             fp, lr, [SP], #0x10
    // 0x84fff8: ret
    //     0x84fff8: ret             
    // 0x84fffc: StoreField: r0->field_5f = r2
    //     0x84fffc: stur            w2, [x0, #0x5f]
    // 0x850000: SaveReg r0
    //     0x850000: str             x0, [SP, #-8]!
    // 0x850004: r0 = notifyListeners()
    //     0x850004: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850008: add             SP, SP, #8
    // 0x85000c: r0 = Null
    //     0x85000c: mov             x0, NULL
    // 0x850010: LeaveFrame
    //     0x850010: mov             SP, fp
    //     0x850014: ldp             fp, lr, [SP], #0x10
    // 0x850018: ret
    //     0x850018: ret             
    // 0x85001c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85001c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850020: b               #0x84ffd4
  }
  set _ checkColor=(/* No info */) {
    // ** addr: 0x850024, size: 0xa0
    // 0x850024: EnterFrame
    //     0x850024: stp             fp, lr, [SP, #-0x10]!
    //     0x850028: mov             fp, SP
    // 0x85002c: CheckStackOverflow
    //     0x85002c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850030: cmp             SP, x16
    //     0x850034: b.ls            #0x8500bc
    // 0x850038: ldr             x1, [fp, #0x18]
    // 0x85003c: LoadField: r0 = r1->field_5b
    //     0x85003c: ldur            w0, [x1, #0x5b]
    // 0x850040: DecompressPointer r0
    //     0x850040: add             x0, x0, HEAP, lsl #32
    // 0x850044: r2 = LoadClassIdInstr(r0)
    //     0x850044: ldur            x2, [x0, #-1]
    //     0x850048: ubfx            x2, x2, #0xc, #0x14
    // 0x85004c: ldr             x16, [fp, #0x10]
    // 0x850050: stp             x16, x0, [SP, #-0x10]!
    // 0x850054: mov             x0, x2
    // 0x850058: mov             lr, x0
    // 0x85005c: ldr             lr, [x21, lr, lsl #3]
    // 0x850060: blr             lr
    // 0x850064: add             SP, SP, #0x10
    // 0x850068: tbnz            w0, #4, #0x85007c
    // 0x85006c: r0 = Null
    //     0x85006c: mov             x0, NULL
    // 0x850070: LeaveFrame
    //     0x850070: mov             SP, fp
    //     0x850074: ldp             fp, lr, [SP], #0x10
    // 0x850078: ret
    //     0x850078: ret             
    // 0x85007c: ldr             x1, [fp, #0x18]
    // 0x850080: ldr             x0, [fp, #0x10]
    // 0x850084: StoreField: r1->field_5b = r0
    //     0x850084: stur            w0, [x1, #0x5b]
    //     0x850088: ldurb           w16, [x1, #-1]
    //     0x85008c: ldurb           w17, [x0, #-1]
    //     0x850090: and             x16, x17, x16, lsr #2
    //     0x850094: tst             x16, HEAP, lsr #32
    //     0x850098: b.eq            #0x8500a0
    //     0x85009c: bl              #0xd6826c
    // 0x8500a0: SaveReg r1
    //     0x8500a0: str             x1, [SP, #-8]!
    // 0x8500a4: r0 = notifyListeners()
    //     0x8500a4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8500a8: add             SP, SP, #8
    // 0x8500ac: r0 = Null
    //     0x8500ac: mov             x0, NULL
    // 0x8500b0: LeaveFrame
    //     0x8500b0: mov             SP, fp
    //     0x8500b4: ldp             fp, lr, [SP], #0x10
    // 0x8500b8: ret
    //     0x8500b8: ret             
    // 0x8500bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8500bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8500c0: b               #0x850038
  }
  _ paint(/* No info */) {
    // ** addr: 0xa65950, size: 0x5c0
    // 0xa65950: EnterFrame
    //     0xa65950: stp             fp, lr, [SP, #-0x10]!
    //     0xa65954: mov             fp, SP
    // 0xa65958: AllocStack(0x38)
    //     0xa65958: sub             SP, SP, #0x38
    // 0xa6595c: CheckStackOverflow
    //     0xa6595c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa65960: cmp             SP, x16
    //     0xa65964: b.ls            #0xa65efc
    // 0xa65968: ldr             x16, [fp, #0x10]
    // 0xa6596c: SaveReg r16
    //     0xa6596c: str             x16, [SP, #-8]!
    // 0xa65970: r0 = center()
    //     0xa65970: bl              #0x64082c  ; [dart:ui] Size::center
    // 0xa65974: add             SP, SP, #8
    // 0xa65978: ldr             x16, [fp, #0x20]
    // 0xa6597c: ldr             lr, [fp, #0x18]
    // 0xa65980: stp             lr, x16, [SP, #-0x10]!
    // 0xa65984: SaveReg r0
    //     0xa65984: str             x0, [SP, #-8]!
    // 0xa65988: r0 = paintRadialReaction()
    //     0xa65988: bl              #0xa66c10  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::paintRadialReaction
    // 0xa6598c: add             SP, SP, #0x18
    // 0xa65990: ldr             x16, [fp, #0x20]
    // 0xa65994: SaveReg r16
    //     0xa65994: str             x16, [SP, #-8]!
    // 0xa65998: r0 = _createStrokePaint()
    //     0xa65998: bl              #0xa66b24  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_createStrokePaint
    // 0xa6599c: add             SP, SP, #8
    // 0xa659a0: stur            x0, [fp, #-8]
    // 0xa659a4: ldr             x16, [fp, #0x10]
    // 0xa659a8: r30 = 2.000000
    //     0xa659a8: add             lr, PP, #0x25, lsl #12  ; [pp+0x259a8] 2
    //     0xa659ac: ldr             lr, [lr, #0x9a8]
    // 0xa659b0: stp             lr, x16, [SP, #-0x10]!
    // 0xa659b4: r0 = /()
    //     0xa659b4: bl              #0x50e098  ; [dart:ui] Size::/
    // 0xa659b8: add             SP, SP, #0x10
    // 0xa659bc: stur            x0, [fp, #-0x10]
    // 0xa659c0: r16 = Instance_Size
    //     0xa659c0: add             x16, PP, #0x56, lsl #12  ; [pp+0x56500] Obj!Size@b5edf1
    //     0xa659c4: ldr             x16, [x16, #0x500]
    // 0xa659c8: r30 = 2.000000
    //     0xa659c8: add             lr, PP, #0x25, lsl #12  ; [pp+0x259a8] 2
    //     0xa659cc: ldr             lr, [lr, #0x9a8]
    // 0xa659d0: stp             lr, x16, [SP, #-0x10]!
    // 0xa659d4: r0 = /()
    //     0xa659d4: bl              #0x50e098  ; [dart:ui] Size::/
    // 0xa659d8: add             SP, SP, #0x10
    // 0xa659dc: ldur            x16, [fp, #-0x10]
    // 0xa659e0: stp             x0, x16, [SP, #-0x10]!
    // 0xa659e4: r0 = -()
    //     0xa659e4: bl              #0x50e344  ; [dart:ui] Size::-
    // 0xa659e8: add             SP, SP, #0x10
    // 0xa659ec: mov             x2, x0
    // 0xa659f0: ldr             x1, [fp, #0x20]
    // 0xa659f4: stur            x2, [fp, #-0x10]
    // 0xa659f8: LoadField: r0 = r1->field_23
    //     0xa659f8: ldur            w0, [x1, #0x23]
    // 0xa659fc: DecompressPointer r0
    //     0xa659fc: add             x0, x0, HEAP, lsl #32
    // 0xa65a00: cmp             w0, NULL
    // 0xa65a04: b.eq            #0xa65f04
    // 0xa65a08: LoadField: r3 = r0->field_b
    //     0xa65a08: ldur            w3, [x0, #0xb]
    // 0xa65a0c: DecompressPointer r3
    //     0xa65a0c: add             x3, x3, HEAP, lsl #32
    // 0xa65a10: r0 = LoadClassIdInstr(r3)
    //     0xa65a10: ldur            x0, [x3, #-1]
    //     0xa65a14: ubfx            x0, x0, #0xc, #0x14
    // 0xa65a18: SaveReg r3
    //     0xa65a18: str             x3, [SP, #-8]!
    // 0xa65a1c: r0 = GDT[cid_x0 + 0x376]()
    //     0xa65a1c: add             lr, x0, #0x376
    //     0xa65a20: ldr             lr, [x21, lr, lsl #3]
    //     0xa65a24: blr             lr
    // 0xa65a28: add             SP, SP, #8
    // 0xa65a2c: r16 = Instance_AnimationStatus
    //     0xa65a2c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdbb8] Obj!AnimationStatus@b65f31
    //     0xa65a30: ldr             x16, [x16, #0xbb8]
    // 0xa65a34: cmp             w0, w16
    // 0xa65a38: b.eq            #0xa65a4c
    // 0xa65a3c: r16 = Instance_AnimationStatus
    //     0xa65a3c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0xa65a40: ldr             x16, [x16, #0xba0]
    // 0xa65a44: cmp             w0, w16
    // 0xa65a48: b.ne            #0xa65a78
    // 0xa65a4c: ldr             x0, [fp, #0x20]
    // 0xa65a50: LoadField: r1 = r0->field_23
    //     0xa65a50: ldur            w1, [x0, #0x23]
    // 0xa65a54: DecompressPointer r1
    //     0xa65a54: add             x1, x1, HEAP, lsl #32
    // 0xa65a58: cmp             w1, NULL
    // 0xa65a5c: b.eq            #0xa65f08
    // 0xa65a60: SaveReg r1
    //     0xa65a60: str             x1, [SP, #-8]!
    // 0xa65a64: r0 = value()
    //     0xa65a64: bl              #0xc24674  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xa65a68: add             SP, SP, #8
    // 0xa65a6c: LoadField: d0 = r0->field_7
    //     0xa65a6c: ldur            d0, [x0, #7]
    // 0xa65a70: d1 = 1.000000
    //     0xa65a70: fmov            d1, #1.00000000
    // 0xa65a74: b               #0xa65aa8
    // 0xa65a78: ldr             x0, [fp, #0x20]
    // 0xa65a7c: LoadField: r1 = r0->field_23
    //     0xa65a7c: ldur            w1, [x0, #0x23]
    // 0xa65a80: DecompressPointer r1
    //     0xa65a80: add             x1, x1, HEAP, lsl #32
    // 0xa65a84: cmp             w1, NULL
    // 0xa65a88: b.eq            #0xa65f0c
    // 0xa65a8c: SaveReg r1
    //     0xa65a8c: str             x1, [SP, #-8]!
    // 0xa65a90: r0 = value()
    //     0xa65a90: bl              #0xc24674  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xa65a94: add             SP, SP, #8
    // 0xa65a98: LoadField: d0 = r0->field_7
    //     0xa65a98: ldur            d0, [x0, #7]
    // 0xa65a9c: d1 = 1.000000
    //     0xa65a9c: fmov            d1, #1.00000000
    // 0xa65aa0: fsub            d2, d1, d0
    // 0xa65aa4: mov             v0.16b, v2.16b
    // 0xa65aa8: ldr             x0, [fp, #0x20]
    // 0xa65aac: stur            d0, [fp, #-0x38]
    // 0xa65ab0: LoadField: r1 = r0->field_63
    //     0xa65ab0: ldur            w1, [x0, #0x63]
    // 0xa65ab4: DecompressPointer r1
    //     0xa65ab4: add             x1, x1, HEAP, lsl #32
    // 0xa65ab8: r16 = false
    //     0xa65ab8: add             x16, NULL, #0x30  ; false
    // 0xa65abc: cmp             w1, w16
    // 0xa65ac0: b.eq            #0xa65ad8
    // 0xa65ac4: LoadField: r1 = r0->field_5f
    //     0xa65ac4: ldur            w1, [x0, #0x5f]
    // 0xa65ac8: DecompressPointer r1
    //     0xa65ac8: add             x1, x1, HEAP, lsl #32
    // 0xa65acc: r16 = false
    //     0xa65acc: add             x16, NULL, #0x30  ; false
    // 0xa65ad0: cmp             w1, w16
    // 0xa65ad4: b.ne            #0xa65cf4
    // 0xa65ad8: LoadField: r1 = r0->field_5f
    //     0xa65ad8: ldur            w1, [x0, #0x5f]
    // 0xa65adc: DecompressPointer r1
    //     0xa65adc: add             x1, x1, HEAP, lsl #32
    // 0xa65ae0: r16 = false
    //     0xa65ae0: add             x16, NULL, #0x30  ; false
    // 0xa65ae4: cmp             w1, w16
    // 0xa65ae8: b.ne            #0xa65af4
    // 0xa65aec: fsub            d2, d1, d0
    // 0xa65af0: mov             v0.16b, v2.16b
    // 0xa65af4: stur            d0, [fp, #-0x30]
    // 0xa65af8: ldur            x16, [fp, #-0x10]
    // 0xa65afc: stp             x16, x0, [SP, #-0x10]!
    // 0xa65b00: SaveReg d0
    //     0xa65b00: str             d0, [SP, #-8]!
    // 0xa65b04: r0 = _outerRectAt()
    //     0xa65b04: bl              #0xa66a60  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_outerRectAt
    // 0xa65b08: add             SP, SP, #0x18
    // 0xa65b0c: stur            x0, [fp, #-0x18]
    // 0xa65b10: r16 = 112
    //     0xa65b10: mov             x16, #0x70
    // 0xa65b14: stp             x16, NULL, [SP, #-0x10]!
    // 0xa65b18: r0 = ByteData()
    //     0xa65b18: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa65b1c: add             SP, SP, #0x10
    // 0xa65b20: stur            x0, [fp, #-0x20]
    // 0xa65b24: r0 = Paint()
    //     0xa65b24: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa65b28: mov             x1, x0
    // 0xa65b2c: ldur            x0, [fp, #-0x20]
    // 0xa65b30: stur            x1, [fp, #-0x28]
    // 0xa65b34: StoreField: r1->field_7 = r0
    //     0xa65b34: stur            w0, [x1, #7]
    // 0xa65b38: ldr             x16, [fp, #0x20]
    // 0xa65b3c: SaveReg r16
    //     0xa65b3c: str             x16, [SP, #-8]!
    // 0xa65b40: ldur            d0, [fp, #-0x30]
    // 0xa65b44: SaveReg d0
    //     0xa65b44: str             d0, [SP, #-8]!
    // 0xa65b48: r0 = _colorAt()
    //     0xa65b48: bl              #0xa66974  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_colorAt
    // 0xa65b4c: add             SP, SP, #0x10
    // 0xa65b50: r1 = LoadClassIdInstr(r0)
    //     0xa65b50: ldur            x1, [x0, #-1]
    //     0xa65b54: ubfx            x1, x1, #0xc, #0x14
    // 0xa65b58: lsl             x1, x1, #1
    // 0xa65b5c: r17 = 10124
    //     0xa65b5c: mov             x17, #0x278c
    // 0xa65b60: cmp             w1, w17
    // 0xa65b64: b.gt            #0xa65b74
    // 0xa65b68: r17 = 10122
    //     0xa65b68: mov             x17, #0x278a
    // 0xa65b6c: cmp             w1, w17
    // 0xa65b70: b.ge            #0xa65b8c
    // 0xa65b74: r17 = 10114
    //     0xa65b74: mov             x17, #0x2782
    // 0xa65b78: cmp             w1, w17
    // 0xa65b7c: b.eq            #0xa65b8c
    // 0xa65b80: r17 = 10118
    //     0xa65b80: mov             x17, #0x2786
    // 0xa65b84: cmp             w1, w17
    // 0xa65b88: b.ne            #0xa65b94
    // 0xa65b8c: LoadField: r1 = r0->field_7
    //     0xa65b8c: ldur            x1, [x0, #7]
    // 0xa65b90: b               #0xa65ba4
    // 0xa65b94: LoadField: r1 = r0->field_f
    //     0xa65b94: ldur            w1, [x0, #0xf]
    // 0xa65b98: DecompressPointer r1
    //     0xa65b98: add             x1, x1, HEAP, lsl #32
    // 0xa65b9c: LoadField: r0 = r1->field_7
    //     0xa65b9c: ldur            x0, [x1, #7]
    // 0xa65ba0: mov             x1, x0
    // 0xa65ba4: ldur            d0, [fp, #-0x30]
    // 0xa65ba8: ldur            x0, [fp, #-0x20]
    // 0xa65bac: d1 = 0.500000
    //     0xa65bac: fmov            d1, #0.50000000
    // 0xa65bb0: eor             x2, x1, #0xff000000
    // 0xa65bb4: LoadField: r1 = r0->field_17
    //     0xa65bb4: ldur            w1, [x0, #0x17]
    // 0xa65bb8: DecompressPointer r1
    //     0xa65bb8: add             x1, x1, HEAP, lsl #32
    // 0xa65bbc: sxtw            x2, w2
    // 0xa65bc0: LoadField: r0 = r1->field_7
    //     0xa65bc0: ldur            x0, [x1, #7]
    // 0xa65bc4: str             w2, [x0, #4]
    // 0xa65bc8: fcmp            d0, d1
    // 0xa65bcc: b.vs            #0xa65c40
    // 0xa65bd0: b.gt            #0xa65c40
    // 0xa65bd4: ldur            x16, [fp, #-0x28]
    // 0xa65bd8: SaveReg r16
    //     0xa65bd8: str             x16, [SP, #-8]!
    // 0xa65bdc: r0 = color()
    //     0xa65bdc: bl              #0x7071ec  ; [dart:ui] Paint::color
    // 0xa65be0: add             SP, SP, #8
    // 0xa65be4: stur            x0, [fp, #-0x20]
    // 0xa65be8: r0 = BorderSide()
    //     0xa65be8: bl              #0x5b55d0  ; AllocateBorderSideStub -> BorderSide (size=0x20)
    // 0xa65bec: mov             x1, x0
    // 0xa65bf0: ldur            x0, [fp, #-0x20]
    // 0xa65bf4: StoreField: r1->field_7 = r0
    //     0xa65bf4: stur            w0, [x1, #7]
    // 0xa65bf8: d2 = 2.000000
    //     0xa65bf8: fmov            d2, #2.00000000
    // 0xa65bfc: StoreField: r1->field_b = d2
    //     0xa65bfc: stur            d2, [x1, #0xb]
    // 0xa65c00: r0 = Instance_BorderStyle
    //     0xa65c00: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0xa65c04: ldr             x0, [x0, #0xbd0]
    // 0xa65c08: StoreField: r1->field_13 = r0
    //     0xa65c08: stur            w0, [x1, #0x13]
    // 0xa65c0c: d0 = -1.000000
    //     0xa65c0c: fmov            d0, #-1.00000000
    // 0xa65c10: StoreField: r1->field_17 = d0
    //     0xa65c10: stur            d0, [x1, #0x17]
    // 0xa65c14: ldr             x16, [fp, #0x20]
    // 0xa65c18: ldr             lr, [fp, #0x18]
    // 0xa65c1c: stp             lr, x16, [SP, #-0x10]!
    // 0xa65c20: ldur            x16, [fp, #-0x18]
    // 0xa65c24: ldur            lr, [fp, #-0x28]
    // 0xa65c28: stp             lr, x16, [SP, #-0x10]!
    // 0xa65c2c: r16 = false
    //     0xa65c2c: add             x16, NULL, #0x30  ; false
    // 0xa65c30: stp             x16, x1, [SP, #-0x10]!
    // 0xa65c34: r0 = _drawBox()
    //     0xa65c34: bl              #0xa668b0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xa65c38: add             SP, SP, #0x30
    // 0xa65c3c: b               #0xa65eec
    // 0xa65c40: ldr             x0, [fp, #0x20]
    // 0xa65c44: d2 = 2.000000
    //     0xa65c44: fmov            d2, #2.00000000
    // 0xa65c48: ldr             x16, [fp, #0x18]
    // 0xa65c4c: stp             x16, x0, [SP, #-0x10]!
    // 0xa65c50: ldur            x16, [fp, #-0x18]
    // 0xa65c54: ldur            lr, [fp, #-0x28]
    // 0xa65c58: stp             lr, x16, [SP, #-0x10]!
    // 0xa65c5c: r16 = true
    //     0xa65c5c: add             x16, NULL, #0x20  ; true
    // 0xa65c60: stp             x16, NULL, [SP, #-0x10]!
    // 0xa65c64: r0 = _drawBox()
    //     0xa65c64: bl              #0xa668b0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xa65c68: add             SP, SP, #0x30
    // 0xa65c6c: ldur            d0, [fp, #-0x30]
    // 0xa65c70: d2 = 0.500000
    //     0xa65c70: fmov            d2, #0.50000000
    // 0xa65c74: fsub            d1, d0, d2
    // 0xa65c78: d3 = 2.000000
    //     0xa65c78: fmov            d3, #2.00000000
    // 0xa65c7c: fmul            d0, d1, d3
    // 0xa65c80: ldr             x0, [fp, #0x20]
    // 0xa65c84: LoadField: r1 = r0->field_63
    //     0xa65c84: ldur            w1, [x0, #0x63]
    // 0xa65c88: DecompressPointer r1
    //     0xa65c88: add             x1, x1, HEAP, lsl #32
    // 0xa65c8c: cmp             w1, NULL
    // 0xa65c90: b.eq            #0xa65ca4
    // 0xa65c94: LoadField: r1 = r0->field_5f
    //     0xa65c94: ldur            w1, [x0, #0x5f]
    // 0xa65c98: DecompressPointer r1
    //     0xa65c98: add             x1, x1, HEAP, lsl #32
    // 0xa65c9c: cmp             w1, NULL
    // 0xa65ca0: b.ne            #0xa65ccc
    // 0xa65ca4: ldr             x16, [fp, #0x18]
    // 0xa65ca8: stp             x16, x0, [SP, #-0x10]!
    // 0xa65cac: ldur            x16, [fp, #-0x10]
    // 0xa65cb0: SaveReg r16
    //     0xa65cb0: str             x16, [SP, #-8]!
    // 0xa65cb4: SaveReg d0
    //     0xa65cb4: str             d0, [SP, #-8]!
    // 0xa65cb8: ldur            x16, [fp, #-8]
    // 0xa65cbc: SaveReg r16
    //     0xa65cbc: str             x16, [SP, #-8]!
    // 0xa65cc0: r0 = _drawDash()
    //     0xa65cc0: bl              #0xa66268  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xa65cc4: add             SP, SP, #0x28
    // 0xa65cc8: b               #0xa65eec
    // 0xa65ccc: ldr             x16, [fp, #0x18]
    // 0xa65cd0: stp             x16, x0, [SP, #-0x10]!
    // 0xa65cd4: ldur            x16, [fp, #-0x10]
    // 0xa65cd8: SaveReg r16
    //     0xa65cd8: str             x16, [SP, #-8]!
    // 0xa65cdc: SaveReg d0
    //     0xa65cdc: str             d0, [SP, #-8]!
    // 0xa65ce0: ldur            x16, [fp, #-8]
    // 0xa65ce4: SaveReg r16
    //     0xa65ce4: str             x16, [SP, #-8]!
    // 0xa65ce8: r0 = _drawCheck()
    //     0xa65ce8: bl              #0xa65f10  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xa65cec: add             SP, SP, #0x28
    // 0xa65cf0: b               #0xa65eec
    // 0xa65cf4: d2 = 0.500000
    //     0xa65cf4: fmov            d2, #0.50000000
    // 0xa65cf8: d3 = 2.000000
    //     0xa65cf8: fmov            d3, #2.00000000
    // 0xa65cfc: ldur            x16, [fp, #-0x10]
    // 0xa65d00: stp             x16, x0, [SP, #-0x10]!
    // 0xa65d04: SaveReg d1
    //     0xa65d04: str             d1, [SP, #-8]!
    // 0xa65d08: r0 = _outerRectAt()
    //     0xa65d08: bl              #0xa66a60  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_outerRectAt
    // 0xa65d0c: add             SP, SP, #0x18
    // 0xa65d10: stur            x0, [fp, #-0x18]
    // 0xa65d14: r16 = 112
    //     0xa65d14: mov             x16, #0x70
    // 0xa65d18: stp             x16, NULL, [SP, #-0x10]!
    // 0xa65d1c: r0 = ByteData()
    //     0xa65d1c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa65d20: add             SP, SP, #0x10
    // 0xa65d24: stur            x0, [fp, #-0x20]
    // 0xa65d28: r0 = Paint()
    //     0xa65d28: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa65d2c: mov             x1, x0
    // 0xa65d30: ldur            x0, [fp, #-0x20]
    // 0xa65d34: stur            x1, [fp, #-0x28]
    // 0xa65d38: StoreField: r1->field_7 = r0
    //     0xa65d38: stur            w0, [x1, #7]
    // 0xa65d3c: ldr             x16, [fp, #0x20]
    // 0xa65d40: SaveReg r16
    //     0xa65d40: str             x16, [SP, #-8]!
    // 0xa65d44: d0 = 1.000000
    //     0xa65d44: fmov            d0, #1.00000000
    // 0xa65d48: SaveReg d0
    //     0xa65d48: str             d0, [SP, #-8]!
    // 0xa65d4c: r0 = _colorAt()
    //     0xa65d4c: bl              #0xa66974  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_colorAt
    // 0xa65d50: add             SP, SP, #0x10
    // 0xa65d54: r1 = LoadClassIdInstr(r0)
    //     0xa65d54: ldur            x1, [x0, #-1]
    //     0xa65d58: ubfx            x1, x1, #0xc, #0x14
    // 0xa65d5c: lsl             x1, x1, #1
    // 0xa65d60: r17 = 10124
    //     0xa65d60: mov             x17, #0x278c
    // 0xa65d64: cmp             w1, w17
    // 0xa65d68: b.gt            #0xa65d78
    // 0xa65d6c: r17 = 10122
    //     0xa65d6c: mov             x17, #0x278a
    // 0xa65d70: cmp             w1, w17
    // 0xa65d74: b.ge            #0xa65d90
    // 0xa65d78: r17 = 10114
    //     0xa65d78: mov             x17, #0x2782
    // 0xa65d7c: cmp             w1, w17
    // 0xa65d80: b.eq            #0xa65d90
    // 0xa65d84: r17 = 10118
    //     0xa65d84: mov             x17, #0x2786
    // 0xa65d88: cmp             w1, w17
    // 0xa65d8c: b.ne            #0xa65d98
    // 0xa65d90: LoadField: r1 = r0->field_7
    //     0xa65d90: ldur            x1, [x0, #7]
    // 0xa65d94: b               #0xa65da8
    // 0xa65d98: LoadField: r1 = r0->field_f
    //     0xa65d98: ldur            w1, [x0, #0xf]
    // 0xa65d9c: DecompressPointer r1
    //     0xa65d9c: add             x1, x1, HEAP, lsl #32
    // 0xa65da0: LoadField: r0 = r1->field_7
    //     0xa65da0: ldur            x0, [x1, #7]
    // 0xa65da4: mov             x1, x0
    // 0xa65da8: ldur            d0, [fp, #-0x38]
    // 0xa65dac: ldur            x0, [fp, #-0x20]
    // 0xa65db0: eor             x2, x1, #0xff000000
    // 0xa65db4: LoadField: r1 = r0->field_17
    //     0xa65db4: ldur            w1, [x0, #0x17]
    // 0xa65db8: DecompressPointer r1
    //     0xa65db8: add             x1, x1, HEAP, lsl #32
    // 0xa65dbc: sxtw            x2, w2
    // 0xa65dc0: LoadField: r0 = r1->field_7
    //     0xa65dc0: ldur            x0, [x1, #7]
    // 0xa65dc4: str             w2, [x0, #4]
    // 0xa65dc8: ldr             x16, [fp, #0x20]
    // 0xa65dcc: ldr             lr, [fp, #0x18]
    // 0xa65dd0: stp             lr, x16, [SP, #-0x10]!
    // 0xa65dd4: ldur            x16, [fp, #-0x18]
    // 0xa65dd8: ldur            lr, [fp, #-0x28]
    // 0xa65ddc: stp             lr, x16, [SP, #-0x10]!
    // 0xa65de0: r16 = true
    //     0xa65de0: add             x16, NULL, #0x20  ; true
    // 0xa65de4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa65de8: r0 = _drawBox()
    //     0xa65de8: bl              #0xa668b0  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawBox
    // 0xa65dec: add             SP, SP, #0x30
    // 0xa65df0: ldur            d0, [fp, #-0x38]
    // 0xa65df4: d1 = 0.500000
    //     0xa65df4: fmov            d1, #0.50000000
    // 0xa65df8: fcmp            d0, d1
    // 0xa65dfc: b.vs            #0xa65e7c
    // 0xa65e00: b.gt            #0xa65e7c
    // 0xa65e04: ldr             x0, [fp, #0x20]
    // 0xa65e08: d1 = 1.000000
    //     0xa65e08: fmov            d1, #1.00000000
    // 0xa65e0c: d2 = 2.000000
    //     0xa65e0c: fmov            d2, #2.00000000
    // 0xa65e10: fmul            d3, d0, d2
    // 0xa65e14: fsub            d0, d1, d3
    // 0xa65e18: LoadField: r1 = r0->field_63
    //     0xa65e18: ldur            w1, [x0, #0x63]
    // 0xa65e1c: DecompressPointer r1
    //     0xa65e1c: add             x1, x1, HEAP, lsl #32
    // 0xa65e20: cmp             w1, NULL
    // 0xa65e24: b.eq            #0xa65e54
    // 0xa65e28: tbnz            w1, #4, #0xa65e54
    // 0xa65e2c: ldr             x16, [fp, #0x18]
    // 0xa65e30: stp             x16, x0, [SP, #-0x10]!
    // 0xa65e34: ldur            x16, [fp, #-0x10]
    // 0xa65e38: SaveReg r16
    //     0xa65e38: str             x16, [SP, #-8]!
    // 0xa65e3c: SaveReg d0
    //     0xa65e3c: str             d0, [SP, #-8]!
    // 0xa65e40: ldur            x16, [fp, #-8]
    // 0xa65e44: SaveReg r16
    //     0xa65e44: str             x16, [SP, #-8]!
    // 0xa65e48: r0 = _drawCheck()
    //     0xa65e48: bl              #0xa65f10  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xa65e4c: add             SP, SP, #0x28
    // 0xa65e50: b               #0xa65eec
    // 0xa65e54: ldr             x16, [fp, #0x18]
    // 0xa65e58: stp             x16, x0, [SP, #-0x10]!
    // 0xa65e5c: ldur            x16, [fp, #-0x10]
    // 0xa65e60: SaveReg r16
    //     0xa65e60: str             x16, [SP, #-8]!
    // 0xa65e64: SaveReg d0
    //     0xa65e64: str             d0, [SP, #-8]!
    // 0xa65e68: ldur            x16, [fp, #-8]
    // 0xa65e6c: SaveReg r16
    //     0xa65e6c: str             x16, [SP, #-8]!
    // 0xa65e70: r0 = _drawDash()
    //     0xa65e70: bl              #0xa66268  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xa65e74: add             SP, SP, #0x28
    // 0xa65e78: b               #0xa65eec
    // 0xa65e7c: ldr             x0, [fp, #0x20]
    // 0xa65e80: d2 = 2.000000
    //     0xa65e80: fmov            d2, #2.00000000
    // 0xa65e84: fsub            d3, d0, d1
    // 0xa65e88: fmul            d0, d3, d2
    // 0xa65e8c: LoadField: r1 = r0->field_5f
    //     0xa65e8c: ldur            w1, [x0, #0x5f]
    // 0xa65e90: DecompressPointer r1
    //     0xa65e90: add             x1, x1, HEAP, lsl #32
    // 0xa65e94: cmp             w1, NULL
    // 0xa65e98: b.eq            #0xa65ec8
    // 0xa65e9c: tbnz            w1, #4, #0xa65ec8
    // 0xa65ea0: ldr             x16, [fp, #0x18]
    // 0xa65ea4: stp             x16, x0, [SP, #-0x10]!
    // 0xa65ea8: ldur            x16, [fp, #-0x10]
    // 0xa65eac: SaveReg r16
    //     0xa65eac: str             x16, [SP, #-8]!
    // 0xa65eb0: SaveReg d0
    //     0xa65eb0: str             d0, [SP, #-8]!
    // 0xa65eb4: ldur            x16, [fp, #-8]
    // 0xa65eb8: SaveReg r16
    //     0xa65eb8: str             x16, [SP, #-8]!
    // 0xa65ebc: r0 = _drawCheck()
    //     0xa65ebc: bl              #0xa65f10  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawCheck
    // 0xa65ec0: add             SP, SP, #0x28
    // 0xa65ec4: b               #0xa65eec
    // 0xa65ec8: ldr             x16, [fp, #0x18]
    // 0xa65ecc: stp             x16, x0, [SP, #-0x10]!
    // 0xa65ed0: ldur            x16, [fp, #-0x10]
    // 0xa65ed4: SaveReg r16
    //     0xa65ed4: str             x16, [SP, #-8]!
    // 0xa65ed8: SaveReg d0
    //     0xa65ed8: str             d0, [SP, #-8]!
    // 0xa65edc: ldur            x16, [fp, #-8]
    // 0xa65ee0: SaveReg r16
    //     0xa65ee0: str             x16, [SP, #-8]!
    // 0xa65ee4: r0 = _drawDash()
    //     0xa65ee4: bl              #0xa66268  ; [package:flutter/src/material/checkbox.dart] _CheckboxPainter::_drawDash
    // 0xa65ee8: add             SP, SP, #0x28
    // 0xa65eec: r0 = Null
    //     0xa65eec: mov             x0, NULL
    // 0xa65ef0: LeaveFrame
    //     0xa65ef0: mov             SP, fp
    //     0xa65ef4: ldp             fp, lr, [SP], #0x10
    // 0xa65ef8: ret
    //     0xa65ef8: ret             
    // 0xa65efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa65efc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa65f00: b               #0xa65968
    // 0xa65f04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa65f04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa65f08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa65f08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa65f0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa65f0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _drawCheck(/* No info */) {
    // ** addr: 0xa65f10, size: 0x358
    // 0xa65f10: EnterFrame
    //     0xa65f10: stp             fp, lr, [SP, #-0x10]!
    //     0xa65f14: mov             fp, SP
    // 0xa65f18: AllocStack(0x20)
    //     0xa65f18: sub             SP, SP, #0x20
    // 0xa65f1c: CheckStackOverflow
    //     0xa65f1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa65f20: cmp             SP, x16
    //     0xa65f24: b.ls            #0xa661d8
    // 0xa65f28: r0 = Path()
    //     0xa65f28: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa65f2c: stur            x0, [fp, #-8]
    // 0xa65f30: SaveReg r0
    //     0xa65f30: str             x0, [SP, #-8]!
    // 0xa65f34: r0 = _constructor()
    //     0xa65f34: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa65f38: add             SP, SP, #8
    // 0xa65f3c: ldr             d1, [fp, #0x18]
    // 0xa65f40: d0 = 0.500000
    //     0xa65f40: fmov            d0, #0.50000000
    // 0xa65f44: fcmp            d1, d0
    // 0xa65f48: b.vs            #0xa6604c
    // 0xa65f4c: b.ge            #0xa6604c
    // 0xa65f50: ldr             x0, [fp, #0x20]
    // 0xa65f54: d2 = 2.000000
    //     0xa65f54: fmov            d2, #2.00000000
    // 0xa65f58: fmul            d0, d1, d2
    // 0xa65f5c: r16 = Instance_Offset
    //     0xa65f5c: add             x16, PP, #0x56, lsl #12  ; [pp+0x56508] Obj!Offset@b5f1b1
    //     0xa65f60: ldr             x16, [x16, #0x508]
    // 0xa65f64: r30 = Instance_Offset
    //     0xa65f64: add             lr, PP, #0x56, lsl #12  ; [pp+0x56510] Obj!Offset@b5f191
    //     0xa65f68: ldr             lr, [lr, #0x510]
    // 0xa65f6c: stp             lr, x16, [SP, #-0x10]!
    // 0xa65f70: SaveReg d0
    //     0xa65f70: str             d0, [SP, #-8]!
    // 0xa65f74: r0 = lerp()
    //     0xa65f74: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xa65f78: add             SP, SP, #0x18
    // 0xa65f7c: stur            x0, [fp, #-0x10]
    // 0xa65f80: cmp             w0, NULL
    // 0xa65f84: b.eq            #0xa661e0
    // 0xa65f88: ldr             x1, [fp, #0x20]
    // 0xa65f8c: LoadField: d0 = r1->field_7
    //     0xa65f8c: ldur            d0, [x1, #7]
    // 0xa65f90: stur            d0, [fp, #-0x20]
    // 0xa65f94: r2 = Instance_Offset
    //     0xa65f94: add             x2, PP, #0x56, lsl #12  ; [pp+0x56508] Obj!Offset@b5f1b1
    //     0xa65f98: ldr             x2, [x2, #0x508]
    // 0xa65f9c: LoadField: d1 = r2->field_7
    //     0xa65f9c: ldur            d1, [x2, #7]
    // 0xa65fa0: fadd            d2, d0, d1
    // 0xa65fa4: LoadField: d1 = r1->field_f
    //     0xa65fa4: ldur            d1, [x1, #0xf]
    // 0xa65fa8: stur            d1, [fp, #-0x18]
    // 0xa65fac: LoadField: d3 = r2->field_f
    //     0xa65fac: ldur            d3, [x2, #0xf]
    // 0xa65fb0: fadd            d4, d1, d3
    // 0xa65fb4: r1 = inline_Allocate_Double()
    //     0xa65fb4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa65fb8: add             x1, x1, #0x10
    //     0xa65fbc: cmp             x2, x1
    //     0xa65fc0: b.ls            #0xa661e4
    //     0xa65fc4: str             x1, [THR, #0x60]  ; THR::top
    //     0xa65fc8: sub             x1, x1, #0xf
    //     0xa65fcc: mov             x2, #0xd108
    //     0xa65fd0: movk            x2, #3, lsl #16
    //     0xa65fd4: stur            x2, [x1, #-1]
    // 0xa65fd8: StoreField: r1->field_7 = d2
    //     0xa65fd8: stur            d2, [x1, #7]
    // 0xa65fdc: ldur            x16, [fp, #-8]
    // 0xa65fe0: stp             x1, x16, [SP, #-0x10]!
    // 0xa65fe4: SaveReg d4
    //     0xa65fe4: str             d4, [SP, #-8]!
    // 0xa65fe8: r0 = moveTo()
    //     0xa65fe8: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa65fec: add             SP, SP, #0x18
    // 0xa65ff0: ldur            x0, [fp, #-0x10]
    // 0xa65ff4: LoadField: d0 = r0->field_7
    //     0xa65ff4: ldur            d0, [x0, #7]
    // 0xa65ff8: ldur            d1, [fp, #-0x20]
    // 0xa65ffc: fadd            d2, d1, d0
    // 0xa66000: LoadField: d0 = r0->field_f
    //     0xa66000: ldur            d0, [x0, #0xf]
    // 0xa66004: ldur            d1, [fp, #-0x18]
    // 0xa66008: fadd            d3, d1, d0
    // 0xa6600c: r0 = inline_Allocate_Double()
    //     0xa6600c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa66010: add             x0, x0, #0x10
    //     0xa66014: cmp             x1, x0
    //     0xa66018: b.ls            #0xa66208
    //     0xa6601c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa66020: sub             x0, x0, #0xf
    //     0xa66024: mov             x1, #0xd108
    //     0xa66028: movk            x1, #3, lsl #16
    //     0xa6602c: stur            x1, [x0, #-1]
    // 0xa66030: StoreField: r0->field_7 = d2
    //     0xa66030: stur            d2, [x0, #7]
    // 0xa66034: ldur            x16, [fp, #-8]
    // 0xa66038: stp             x0, x16, [SP, #-0x10]!
    // 0xa6603c: SaveReg d3
    //     0xa6603c: str             d3, [SP, #-8]!
    // 0xa66040: r0 = lineTo()
    //     0xa66040: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa66044: add             SP, SP, #0x18
    // 0xa66048: b               #0xa661ac
    // 0xa6604c: ldr             x1, [fp, #0x20]
    // 0xa66050: r2 = Instance_Offset
    //     0xa66050: add             x2, PP, #0x56, lsl #12  ; [pp+0x56508] Obj!Offset@b5f1b1
    //     0xa66054: ldr             x2, [x2, #0x508]
    // 0xa66058: d2 = 2.000000
    //     0xa66058: fmov            d2, #2.00000000
    // 0xa6605c: fsub            d3, d1, d0
    // 0xa66060: fmul            d0, d3, d2
    // 0xa66064: r16 = Instance_Offset
    //     0xa66064: add             x16, PP, #0x56, lsl #12  ; [pp+0x56510] Obj!Offset@b5f191
    //     0xa66068: ldr             x16, [x16, #0x510]
    // 0xa6606c: r30 = Instance_Offset
    //     0xa6606c: add             lr, PP, #0x56, lsl #12  ; [pp+0x56518] Obj!Offset@b5f171
    //     0xa66070: ldr             lr, [lr, #0x518]
    // 0xa66074: stp             lr, x16, [SP, #-0x10]!
    // 0xa66078: SaveReg d0
    //     0xa66078: str             d0, [SP, #-8]!
    // 0xa6607c: r0 = lerp()
    //     0xa6607c: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xa66080: add             SP, SP, #0x18
    // 0xa66084: stur            x0, [fp, #-0x10]
    // 0xa66088: cmp             w0, NULL
    // 0xa6608c: b.eq            #0xa66218
    // 0xa66090: ldr             x1, [fp, #0x20]
    // 0xa66094: LoadField: d0 = r1->field_7
    //     0xa66094: ldur            d0, [x1, #7]
    // 0xa66098: stur            d0, [fp, #-0x20]
    // 0xa6609c: r2 = Instance_Offset
    //     0xa6609c: add             x2, PP, #0x56, lsl #12  ; [pp+0x56508] Obj!Offset@b5f1b1
    //     0xa660a0: ldr             x2, [x2, #0x508]
    // 0xa660a4: LoadField: d1 = r2->field_7
    //     0xa660a4: ldur            d1, [x2, #7]
    // 0xa660a8: fadd            d2, d0, d1
    // 0xa660ac: LoadField: d1 = r1->field_f
    //     0xa660ac: ldur            d1, [x1, #0xf]
    // 0xa660b0: stur            d1, [fp, #-0x18]
    // 0xa660b4: LoadField: d3 = r2->field_f
    //     0xa660b4: ldur            d3, [x2, #0xf]
    // 0xa660b8: fadd            d4, d1, d3
    // 0xa660bc: r1 = inline_Allocate_Double()
    //     0xa660bc: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa660c0: add             x1, x1, #0x10
    //     0xa660c4: cmp             x2, x1
    //     0xa660c8: b.ls            #0xa6621c
    //     0xa660cc: str             x1, [THR, #0x60]  ; THR::top
    //     0xa660d0: sub             x1, x1, #0xf
    //     0xa660d4: mov             x2, #0xd108
    //     0xa660d8: movk            x2, #3, lsl #16
    //     0xa660dc: stur            x2, [x1, #-1]
    // 0xa660e0: StoreField: r1->field_7 = d2
    //     0xa660e0: stur            d2, [x1, #7]
    // 0xa660e4: ldur            x16, [fp, #-8]
    // 0xa660e8: stp             x1, x16, [SP, #-0x10]!
    // 0xa660ec: SaveReg d4
    //     0xa660ec: str             d4, [SP, #-8]!
    // 0xa660f0: r0 = moveTo()
    //     0xa660f0: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa660f4: add             SP, SP, #0x18
    // 0xa660f8: r0 = Instance_Offset
    //     0xa660f8: add             x0, PP, #0x56, lsl #12  ; [pp+0x56510] Obj!Offset@b5f191
    //     0xa660fc: ldr             x0, [x0, #0x510]
    // 0xa66100: LoadField: d0 = r0->field_7
    //     0xa66100: ldur            d0, [x0, #7]
    // 0xa66104: ldur            d1, [fp, #-0x20]
    // 0xa66108: fadd            d2, d1, d0
    // 0xa6610c: LoadField: d0 = r0->field_f
    //     0xa6610c: ldur            d0, [x0, #0xf]
    // 0xa66110: ldur            d3, [fp, #-0x18]
    // 0xa66114: fadd            d4, d3, d0
    // 0xa66118: r0 = inline_Allocate_Double()
    //     0xa66118: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6611c: add             x0, x0, #0x10
    //     0xa66120: cmp             x1, x0
    //     0xa66124: b.ls            #0xa66240
    //     0xa66128: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6612c: sub             x0, x0, #0xf
    //     0xa66130: mov             x1, #0xd108
    //     0xa66134: movk            x1, #3, lsl #16
    //     0xa66138: stur            x1, [x0, #-1]
    // 0xa6613c: StoreField: r0->field_7 = d2
    //     0xa6613c: stur            d2, [x0, #7]
    // 0xa66140: ldur            x16, [fp, #-8]
    // 0xa66144: stp             x0, x16, [SP, #-0x10]!
    // 0xa66148: SaveReg d4
    //     0xa66148: str             d4, [SP, #-8]!
    // 0xa6614c: r0 = lineTo()
    //     0xa6614c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa66150: add             SP, SP, #0x18
    // 0xa66154: ldur            x0, [fp, #-0x10]
    // 0xa66158: LoadField: d0 = r0->field_7
    //     0xa66158: ldur            d0, [x0, #7]
    // 0xa6615c: ldur            d1, [fp, #-0x20]
    // 0xa66160: fadd            d2, d1, d0
    // 0xa66164: LoadField: d0 = r0->field_f
    //     0xa66164: ldur            d0, [x0, #0xf]
    // 0xa66168: ldur            d1, [fp, #-0x18]
    // 0xa6616c: fadd            d3, d1, d0
    // 0xa66170: r0 = inline_Allocate_Double()
    //     0xa66170: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa66174: add             x0, x0, #0x10
    //     0xa66178: cmp             x1, x0
    //     0xa6617c: b.ls            #0xa66258
    //     0xa66180: str             x0, [THR, #0x60]  ; THR::top
    //     0xa66184: sub             x0, x0, #0xf
    //     0xa66188: mov             x1, #0xd108
    //     0xa6618c: movk            x1, #3, lsl #16
    //     0xa66190: stur            x1, [x0, #-1]
    // 0xa66194: StoreField: r0->field_7 = d2
    //     0xa66194: stur            d2, [x0, #7]
    // 0xa66198: ldur            x16, [fp, #-8]
    // 0xa6619c: stp             x0, x16, [SP, #-0x10]!
    // 0xa661a0: SaveReg d3
    //     0xa661a0: str             d3, [SP, #-8]!
    // 0xa661a4: r0 = lineTo()
    //     0xa661a4: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa661a8: add             SP, SP, #0x18
    // 0xa661ac: ldr             x16, [fp, #0x28]
    // 0xa661b0: ldur            lr, [fp, #-8]
    // 0xa661b4: stp             lr, x16, [SP, #-0x10]!
    // 0xa661b8: ldr             x16, [fp, #0x10]
    // 0xa661bc: SaveReg r16
    //     0xa661bc: str             x16, [SP, #-8]!
    // 0xa661c0: r0 = drawPath()
    //     0xa661c0: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa661c4: add             SP, SP, #0x18
    // 0xa661c8: r0 = Null
    //     0xa661c8: mov             x0, NULL
    // 0xa661cc: LeaveFrame
    //     0xa661cc: mov             SP, fp
    //     0xa661d0: ldp             fp, lr, [SP], #0x10
    // 0xa661d4: ret
    //     0xa661d4: ret             
    // 0xa661d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa661d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa661dc: b               #0xa65f28
    // 0xa661e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa661e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa661e4: stp             q2, q4, [SP, #-0x20]!
    // 0xa661e8: stp             q0, q1, [SP, #-0x20]!
    // 0xa661ec: SaveReg r0
    //     0xa661ec: str             x0, [SP, #-8]!
    // 0xa661f0: r0 = AllocateDouble()
    //     0xa661f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa661f4: mov             x1, x0
    // 0xa661f8: RestoreReg r0
    //     0xa661f8: ldr             x0, [SP], #8
    // 0xa661fc: ldp             q0, q1, [SP], #0x20
    // 0xa66200: ldp             q2, q4, [SP], #0x20
    // 0xa66204: b               #0xa65fd8
    // 0xa66208: stp             q2, q3, [SP, #-0x20]!
    // 0xa6620c: r0 = AllocateDouble()
    //     0xa6620c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa66210: ldp             q2, q3, [SP], #0x20
    // 0xa66214: b               #0xa66030
    // 0xa66218: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66218: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6621c: stp             q2, q4, [SP, #-0x20]!
    // 0xa66220: stp             q0, q1, [SP, #-0x20]!
    // 0xa66224: SaveReg r0
    //     0xa66224: str             x0, [SP, #-8]!
    // 0xa66228: r0 = AllocateDouble()
    //     0xa66228: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6622c: mov             x1, x0
    // 0xa66230: RestoreReg r0
    //     0xa66230: ldr             x0, [SP], #8
    // 0xa66234: ldp             q0, q1, [SP], #0x20
    // 0xa66238: ldp             q2, q4, [SP], #0x20
    // 0xa6623c: b               #0xa660e0
    // 0xa66240: stp             q3, q4, [SP, #-0x20]!
    // 0xa66244: stp             q1, q2, [SP, #-0x20]!
    // 0xa66248: r0 = AllocateDouble()
    //     0xa66248: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6624c: ldp             q1, q2, [SP], #0x20
    // 0xa66250: ldp             q3, q4, [SP], #0x20
    // 0xa66254: b               #0xa6613c
    // 0xa66258: stp             q2, q3, [SP, #-0x20]!
    // 0xa6625c: r0 = AllocateDouble()
    //     0xa6625c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa66260: ldp             q2, q3, [SP], #0x20
    // 0xa66264: b               #0xa66194
  }
  _ _drawDash(/* No info */) {
    // ** addr: 0xa66268, size: 0xe8
    // 0xa66268: EnterFrame
    //     0xa66268: stp             fp, lr, [SP, #-0x10]!
    //     0xa6626c: mov             fp, SP
    // 0xa66270: AllocStack(0x10)
    //     0xa66270: sub             SP, SP, #0x10
    // 0xa66274: d0 = 1.000000
    //     0xa66274: fmov            d0, #1.00000000
    // 0xa66278: CheckStackOverflow
    //     0xa66278: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6627c: cmp             SP, x16
    //     0xa66280: b.ls            #0xa66340
    // 0xa66284: ldr             d1, [fp, #0x18]
    // 0xa66288: fsub            d2, d0, d1
    // 0xa6628c: r16 = Instance_Offset
    //     0xa6628c: add             x16, PP, #0x56, lsl #12  ; [pp+0x56520] Obj!Offset@b5f211
    //     0xa66290: ldr             x16, [x16, #0x520]
    // 0xa66294: r30 = Instance_Offset
    //     0xa66294: add             lr, PP, #0x56, lsl #12  ; [pp+0x56528] Obj!Offset@b5f1f1
    //     0xa66298: ldr             lr, [lr, #0x528]
    // 0xa6629c: stp             lr, x16, [SP, #-0x10]!
    // 0xa662a0: SaveReg d2
    //     0xa662a0: str             d2, [SP, #-8]!
    // 0xa662a4: r0 = lerp()
    //     0xa662a4: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xa662a8: add             SP, SP, #0x18
    // 0xa662ac: stur            x0, [fp, #-8]
    // 0xa662b0: cmp             w0, NULL
    // 0xa662b4: b.eq            #0xa66348
    // 0xa662b8: r16 = Instance_Offset
    //     0xa662b8: add             x16, PP, #0x56, lsl #12  ; [pp+0x56528] Obj!Offset@b5f1f1
    //     0xa662bc: ldr             x16, [x16, #0x528]
    // 0xa662c0: r30 = Instance_Offset
    //     0xa662c0: add             lr, PP, #0x56, lsl #12  ; [pp+0x56530] Obj!Offset@b5f1d1
    //     0xa662c4: ldr             lr, [lr, #0x530]
    // 0xa662c8: stp             lr, x16, [SP, #-0x10]!
    // 0xa662cc: ldr             d0, [fp, #0x18]
    // 0xa662d0: SaveReg d0
    //     0xa662d0: str             d0, [SP, #-8]!
    // 0xa662d4: r0 = lerp()
    //     0xa662d4: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xa662d8: add             SP, SP, #0x18
    // 0xa662dc: stur            x0, [fp, #-0x10]
    // 0xa662e0: cmp             w0, NULL
    // 0xa662e4: b.eq            #0xa6634c
    // 0xa662e8: ldr             x16, [fp, #0x20]
    // 0xa662ec: ldur            lr, [fp, #-8]
    // 0xa662f0: stp             lr, x16, [SP, #-0x10]!
    // 0xa662f4: r0 = +()
    //     0xa662f4: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xa662f8: add             SP, SP, #0x10
    // 0xa662fc: stur            x0, [fp, #-8]
    // 0xa66300: ldr             x16, [fp, #0x20]
    // 0xa66304: ldur            lr, [fp, #-0x10]
    // 0xa66308: stp             lr, x16, [SP, #-0x10]!
    // 0xa6630c: r0 = +()
    //     0xa6630c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xa66310: add             SP, SP, #0x10
    // 0xa66314: ldr             x16, [fp, #0x28]
    // 0xa66318: ldur            lr, [fp, #-8]
    // 0xa6631c: stp             lr, x16, [SP, #-0x10]!
    // 0xa66320: ldr             x16, [fp, #0x10]
    // 0xa66324: stp             x16, x0, [SP, #-0x10]!
    // 0xa66328: r0 = drawLine()
    //     0xa66328: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xa6632c: add             SP, SP, #0x20
    // 0xa66330: r0 = Null
    //     0xa66330: mov             x0, NULL
    // 0xa66334: LeaveFrame
    //     0xa66334: mov             SP, fp
    //     0xa66338: ldp             fp, lr, [SP], #0x10
    // 0xa6633c: ret
    //     0xa6633c: ret             
    // 0xa66340: r0 = StackOverflowSharedWithFPURegs()
    //     0xa66340: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa66344: b               #0xa66284
    // 0xa66348: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66348: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa6634c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6634c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _drawBox(/* No info */) {
    // ** addr: 0xa668b0, size: 0xc4
    // 0xa668b0: EnterFrame
    //     0xa668b0: stp             fp, lr, [SP, #-0x10]!
    //     0xa668b4: mov             fp, SP
    // 0xa668b8: CheckStackOverflow
    //     0xa668b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa668bc: cmp             SP, x16
    //     0xa668c0: b.ls            #0xa66964
    // 0xa668c4: ldr             x0, [fp, #0x10]
    // 0xa668c8: tbnz            w0, #4, #0xa6690c
    // 0xa668cc: ldr             x0, [fp, #0x38]
    // 0xa668d0: LoadField: r1 = r0->field_67
    //     0xa668d0: ldur            w1, [x0, #0x67]
    // 0xa668d4: DecompressPointer r1
    //     0xa668d4: add             x1, x1, HEAP, lsl #32
    // 0xa668d8: cmp             w1, NULL
    // 0xa668dc: b.eq            #0xa6696c
    // 0xa668e0: ldr             x16, [fp, #0x28]
    // 0xa668e4: stp             x16, x1, [SP, #-0x10]!
    // 0xa668e8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xa668e8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xa668ec: r0 = getOuterPath()
    //     0xa668ec: bl              #0xcfa384  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::getOuterPath
    // 0xa668f0: add             SP, SP, #0x10
    // 0xa668f4: ldr             x16, [fp, #0x30]
    // 0xa668f8: stp             x0, x16, [SP, #-0x10]!
    // 0xa668fc: ldr             x16, [fp, #0x20]
    // 0xa66900: SaveReg r16
    //     0xa66900: str             x16, [SP, #-8]!
    // 0xa66904: r0 = drawPath()
    //     0xa66904: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa66908: add             SP, SP, #0x18
    // 0xa6690c: ldr             x0, [fp, #0x18]
    // 0xa66910: cmp             w0, NULL
    // 0xa66914: b.eq            #0xa66954
    // 0xa66918: ldr             x1, [fp, #0x38]
    // 0xa6691c: LoadField: r2 = r1->field_67
    //     0xa6691c: ldur            w2, [x1, #0x67]
    // 0xa66920: DecompressPointer r2
    //     0xa66920: add             x2, x2, HEAP, lsl #32
    // 0xa66924: cmp             w2, NULL
    // 0xa66928: b.eq            #0xa66970
    // 0xa6692c: stp             x0, x2, [SP, #-0x10]!
    // 0xa66930: r0 = copyWith()
    //     0xa66930: bl              #0xcf8d1c  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::copyWith
    // 0xa66934: add             SP, SP, #0x10
    // 0xa66938: ldr             x16, [fp, #0x30]
    // 0xa6693c: stp             x16, x0, [SP, #-0x10]!
    // 0xa66940: ldr             x16, [fp, #0x28]
    // 0xa66944: SaveReg r16
    //     0xa66944: str             x16, [SP, #-8]!
    // 0xa66948: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa66948: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa6694c: r0 = paint()
    //     0xa6694c: bl              #0xbd3ed8  ; [package:flutter/src/painting/rounded_rectangle_border.dart] RoundedRectangleBorder::paint
    // 0xa66950: add             SP, SP, #0x18
    // 0xa66954: r0 = Null
    //     0xa66954: mov             x0, NULL
    // 0xa66958: LeaveFrame
    //     0xa66958: mov             SP, fp
    //     0xa6695c: ldp             fp, lr, [SP], #0x10
    // 0xa66960: ret
    //     0xa66960: ret             
    // 0xa66964: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa66964: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa66968: b               #0xa668c4
    // 0xa6696c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6696c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66970: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _colorAt(/* No info */) {
    // ** addr: 0xa66974, size: 0xec
    // 0xa66974: EnterFrame
    //     0xa66974: stp             fp, lr, [SP, #-0x10]!
    //     0xa66978: mov             fp, SP
    // 0xa6697c: d0 = 0.250000
    //     0xa6697c: fmov            d0, #0.25000000
    // 0xa66980: CheckStackOverflow
    //     0xa66980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa66984: cmp             SP, x16
    //     0xa66988: b.ls            #0xa66a30
    // 0xa6698c: ldr             d1, [fp, #0x10]
    // 0xa66990: fcmp            d1, d0
    // 0xa66994: b.vs            #0xa669b8
    // 0xa66998: b.lt            #0xa669b8
    // 0xa6699c: ldr             x0, [fp, #0x18]
    // 0xa669a0: LoadField: r1 = r0->field_33
    //     0xa669a0: ldur            w1, [x0, #0x33]
    // 0xa669a4: DecompressPointer r1
    //     0xa669a4: add             x1, x1, HEAP, lsl #32
    // 0xa669a8: cmp             w1, NULL
    // 0xa669ac: b.eq            #0xa66a38
    // 0xa669b0: mov             x0, x1
    // 0xa669b4: b               #0xa66a24
    // 0xa669b8: ldr             x0, [fp, #0x18]
    // 0xa669bc: d0 = 4.000000
    //     0xa669bc: fmov            d0, #4.00000000
    // 0xa669c0: LoadField: r1 = r0->field_37
    //     0xa669c0: ldur            w1, [x0, #0x37]
    // 0xa669c4: DecompressPointer r1
    //     0xa669c4: add             x1, x1, HEAP, lsl #32
    // 0xa669c8: cmp             w1, NULL
    // 0xa669cc: b.eq            #0xa66a3c
    // 0xa669d0: LoadField: r2 = r0->field_33
    //     0xa669d0: ldur            w2, [x0, #0x33]
    // 0xa669d4: DecompressPointer r2
    //     0xa669d4: add             x2, x2, HEAP, lsl #32
    // 0xa669d8: cmp             w2, NULL
    // 0xa669dc: b.eq            #0xa66a40
    // 0xa669e0: fmul            d2, d1, d0
    // 0xa669e4: r0 = inline_Allocate_Double()
    //     0xa669e4: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xa669e8: add             x0, x0, #0x10
    //     0xa669ec: cmp             x3, x0
    //     0xa669f0: b.ls            #0xa66a44
    //     0xa669f4: str             x0, [THR, #0x60]  ; THR::top
    //     0xa669f8: sub             x0, x0, #0xf
    //     0xa669fc: mov             x3, #0xd108
    //     0xa66a00: movk            x3, #3, lsl #16
    //     0xa66a04: stur            x3, [x0, #-1]
    // 0xa66a08: StoreField: r0->field_7 = d2
    //     0xa66a08: stur            d2, [x0, #7]
    // 0xa66a0c: stp             x2, x1, [SP, #-0x10]!
    // 0xa66a10: SaveReg r0
    //     0xa66a10: str             x0, [SP, #-8]!
    // 0xa66a14: r0 = lerp()
    //     0xa66a14: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xa66a18: add             SP, SP, #0x18
    // 0xa66a1c: cmp             w0, NULL
    // 0xa66a20: b.eq            #0xa66a5c
    // 0xa66a24: LeaveFrame
    //     0xa66a24: mov             SP, fp
    //     0xa66a28: ldp             fp, lr, [SP], #0x10
    // 0xa66a2c: ret
    //     0xa66a2c: ret             
    // 0xa66a30: r0 = StackOverflowSharedWithFPURegs()
    //     0xa66a30: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa66a34: b               #0xa6698c
    // 0xa66a38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66a38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66a3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa66a3c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa66a40: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa66a40: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xa66a44: SaveReg d2
    //     0xa66a44: str             q2, [SP, #-0x10]!
    // 0xa66a48: stp             x1, x2, [SP, #-0x10]!
    // 0xa66a4c: r0 = AllocateDouble()
    //     0xa66a4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa66a50: ldp             x1, x2, [SP], #0x10
    // 0xa66a54: RestoreReg d2
    //     0xa66a54: ldr             q2, [SP], #0x10
    // 0xa66a58: b               #0xa66a08
    // 0xa66a5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66a5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _outerRectAt(/* No info */) {
    // ** addr: 0xa66a60, size: 0xc4
    // 0xa66a60: EnterFrame
    //     0xa66a60: stp             fp, lr, [SP, #-0x10]!
    //     0xa66a64: mov             fp, SP
    // 0xa66a68: AllocStack(0x20)
    //     0xa66a68: sub             SP, SP, #0x20
    // 0xa66a6c: d1 = 0.500000
    //     0xa66a6c: fmov            d1, #0.50000000
    // 0xa66a70: d0 = 0.000000
    //     0xa66a70: eor             v0.16b, v0.16b, v0.16b
    // 0xa66a74: ldr             d2, [fp, #0x10]
    // 0xa66a78: fsub            d3, d2, d1
    // 0xa66a7c: fcmp            d3, d0
    // 0xa66a80: b.vs            #0xa66a90
    // 0xa66a84: b.ne            #0xa66a90
    // 0xa66a88: d3 = 0.000000
    //     0xa66a88: eor             v3.16b, v3.16b, v3.16b
    // 0xa66a8c: b               #0xa66aac
    // 0xa66a90: fcmp            d3, d0
    // 0xa66a94: b.vs            #0xa66aa4
    // 0xa66a98: b.ge            #0xa66aa4
    // 0xa66a9c: fneg            d0, d3
    // 0xa66aa0: b               #0xa66aa8
    // 0xa66aa4: mov             v0.16b, v3.16b
    // 0xa66aa8: mov             v3.16b, v0.16b
    // 0xa66aac: ldr             x0, [fp, #0x18]
    // 0xa66ab0: d2 = 2.000000
    //     0xa66ab0: fmov            d2, #2.00000000
    // 0xa66ab4: d1 = 1.000000
    //     0xa66ab4: fmov            d1, #1.00000000
    // 0xa66ab8: d0 = 18.000000
    //     0xa66ab8: fmov            d0, #18.00000000
    // 0xa66abc: fmul            d4, d3, d2
    // 0xa66ac0: fsub            d3, d1, d4
    // 0xa66ac4: fmul            d1, d3, d2
    // 0xa66ac8: fsub            d2, d0, d1
    // 0xa66acc: LoadField: d0 = r0->field_7
    //     0xa66acc: ldur            d0, [x0, #7]
    // 0xa66ad0: fadd            d1, d0, d3
    // 0xa66ad4: stur            d1, [fp, #-0x20]
    // 0xa66ad8: LoadField: d0 = r0->field_f
    //     0xa66ad8: ldur            d0, [x0, #0xf]
    // 0xa66adc: fadd            d4, d0, d3
    // 0xa66ae0: stur            d4, [fp, #-0x18]
    // 0xa66ae4: fadd            d0, d1, d2
    // 0xa66ae8: stur            d0, [fp, #-0x10]
    // 0xa66aec: fadd            d3, d4, d2
    // 0xa66af0: stur            d3, [fp, #-8]
    // 0xa66af4: r0 = Rect()
    //     0xa66af4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa66af8: ldur            d0, [fp, #-0x20]
    // 0xa66afc: StoreField: r0->field_7 = d0
    //     0xa66afc: stur            d0, [x0, #7]
    // 0xa66b00: ldur            d0, [fp, #-0x18]
    // 0xa66b04: StoreField: r0->field_f = d0
    //     0xa66b04: stur            d0, [x0, #0xf]
    // 0xa66b08: ldur            d0, [fp, #-0x10]
    // 0xa66b0c: StoreField: r0->field_17 = d0
    //     0xa66b0c: stur            d0, [x0, #0x17]
    // 0xa66b10: ldur            d0, [fp, #-8]
    // 0xa66b14: StoreField: r0->field_1f = d0
    //     0xa66b14: stur            d0, [x0, #0x1f]
    // 0xa66b18: LeaveFrame
    //     0xa66b18: mov             SP, fp
    //     0xa66b1c: ldp             fp, lr, [SP], #0x10
    // 0xa66b20: ret
    //     0xa66b20: ret             
  }
  _ _createStrokePaint(/* No info */) {
    // ** addr: 0xa66b24, size: 0xec
    // 0xa66b24: EnterFrame
    //     0xa66b24: stp             fp, lr, [SP, #-0x10]!
    //     0xa66b28: mov             fp, SP
    // 0xa66b2c: AllocStack(0x8)
    //     0xa66b2c: sub             SP, SP, #8
    // 0xa66b30: CheckStackOverflow
    //     0xa66b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa66b34: cmp             SP, x16
    //     0xa66b38: b.ls            #0xa66c04
    // 0xa66b3c: r16 = 112
    //     0xa66b3c: mov             x16, #0x70
    // 0xa66b40: stp             x16, NULL, [SP, #-0x10]!
    // 0xa66b44: r0 = ByteData()
    //     0xa66b44: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa66b48: add             SP, SP, #0x10
    // 0xa66b4c: stur            x0, [fp, #-8]
    // 0xa66b50: r0 = Paint()
    //     0xa66b50: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa66b54: ldur            x1, [fp, #-8]
    // 0xa66b58: StoreField: r0->field_7 = r1
    //     0xa66b58: stur            w1, [x0, #7]
    // 0xa66b5c: ldr             x2, [fp, #0x10]
    // 0xa66b60: LoadField: r3 = r2->field_5b
    //     0xa66b60: ldur            w3, [x2, #0x5b]
    // 0xa66b64: DecompressPointer r3
    //     0xa66b64: add             x3, x3, HEAP, lsl #32
    // 0xa66b68: cmp             w3, NULL
    // 0xa66b6c: b.eq            #0xa66c0c
    // 0xa66b70: r2 = LoadClassIdInstr(r3)
    //     0xa66b70: ldur            x2, [x3, #-1]
    //     0xa66b74: ubfx            x2, x2, #0xc, #0x14
    // 0xa66b78: lsl             x2, x2, #1
    // 0xa66b7c: r17 = 10124
    //     0xa66b7c: mov             x17, #0x278c
    // 0xa66b80: cmp             w2, w17
    // 0xa66b84: b.gt            #0xa66b94
    // 0xa66b88: r17 = 10122
    //     0xa66b88: mov             x17, #0x278a
    // 0xa66b8c: cmp             w2, w17
    // 0xa66b90: b.ge            #0xa66bac
    // 0xa66b94: r17 = 10114
    //     0xa66b94: mov             x17, #0x2782
    // 0xa66b98: cmp             w2, w17
    // 0xa66b9c: b.eq            #0xa66bac
    // 0xa66ba0: r17 = 10118
    //     0xa66ba0: mov             x17, #0x2786
    // 0xa66ba4: cmp             w2, w17
    // 0xa66ba8: b.ne            #0xa66bb8
    // 0xa66bac: LoadField: r2 = r3->field_7
    //     0xa66bac: ldur            x2, [x3, #7]
    // 0xa66bb0: mov             x3, x2
    // 0xa66bb4: b               #0xa66bc4
    // 0xa66bb8: LoadField: r2 = r3->field_f
    //     0xa66bb8: ldur            w2, [x3, #0xf]
    // 0xa66bbc: DecompressPointer r2
    //     0xa66bbc: add             x2, x2, HEAP, lsl #32
    // 0xa66bc0: LoadField: r3 = r2->field_7
    //     0xa66bc0: ldur            x3, [x2, #7]
    // 0xa66bc4: r2 = 1
    //     0xa66bc4: mov             x2, #1
    // 0xa66bc8: d0 = 2.000000
    //     0xa66bc8: fmov            d0, #2.00000000
    // 0xa66bcc: eor             x4, x3, #0xff000000
    // 0xa66bd0: LoadField: r3 = r1->field_17
    //     0xa66bd0: ldur            w3, [x1, #0x17]
    // 0xa66bd4: DecompressPointer r3
    //     0xa66bd4: add             x3, x3, HEAP, lsl #32
    // 0xa66bd8: sxtw            x4, w4
    // 0xa66bdc: LoadField: r1 = r3->field_7
    //     0xa66bdc: ldur            x1, [x3, #7]
    // 0xa66be0: str             w4, [x1, #4]
    // 0xa66be4: LoadField: r1 = r3->field_7
    //     0xa66be4: ldur            x1, [x3, #7]
    // 0xa66be8: str             w2, [x1, #0xc]
    // 0xa66bec: fcvt            s1, d0
    // 0xa66bf0: LoadField: r1 = r3->field_7
    //     0xa66bf0: ldur            x1, [x3, #7]
    // 0xa66bf4: str             s1, [x1, #0x10]
    // 0xa66bf8: LeaveFrame
    //     0xa66bf8: mov             SP, fp
    //     0xa66bfc: ldp             fp, lr, [SP], #0x10
    // 0xa66c00: ret
    //     0xa66c00: ret             
    // 0xa66c04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa66c04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa66c08: b               #0xa66b3c
    // 0xa66c0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66c0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

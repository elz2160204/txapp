// lib: , url: package:flutter/src/material/button_bar_theme.dart

// class id: 1049196, size: 0x8
class :: {
}

// class id: 2834, size: 0x2c, field offset: 0x8
//   const constructor, 
class ButtonBarThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafdf80, size: 0x78
    // 0xafdf80: EnterFrame
    //     0xafdf80: stp             fp, lr, [SP, #-0x10]!
    //     0xafdf84: mov             fp, SP
    // 0xafdf88: CheckStackOverflow
    //     0xafdf88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafdf8c: cmp             SP, x16
    //     0xafdf90: b.ls            #0xafdff0
    // 0xafdf94: ldr             x0, [fp, #0x10]
    // 0xafdf98: LoadField: r1 = r0->field_13
    //     0xafdf98: ldur            w1, [x0, #0x13]
    // 0xafdf9c: DecompressPointer r1
    //     0xafdf9c: add             x1, x1, HEAP, lsl #32
    // 0xafdfa0: LoadField: r2 = r0->field_17
    //     0xafdfa0: ldur            w2, [x0, #0x17]
    // 0xafdfa4: DecompressPointer r2
    //     0xafdfa4: add             x2, x2, HEAP, lsl #32
    // 0xafdfa8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdfac: stp             x1, NULL, [SP, #-0x10]!
    // 0xafdfb0: stp             NULL, x2, [SP, #-0x10]!
    // 0xafdfb4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdfb8: SaveReg rNULL
    //     0xafdfb8: str             NULL, [SP, #-8]!
    // 0xafdfbc: r4 = const [0, 0x9, 0x9, 0x9, null]
    //     0xafdfbc: add             x4, PP, #0xe, lsl #12  ; [pp+0xe428] List(5) [0, 0x9, 0x9, 0x9, Null]
    //     0xafdfc0: ldr             x4, [x4, #0x428]
    // 0xafdfc4: r0 = hash()
    //     0xafdfc4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafdfc8: add             SP, SP, #0x48
    // 0xafdfcc: mov             x2, x0
    // 0xafdfd0: r0 = BoxInt64Instr(r2)
    //     0xafdfd0: sbfiz           x0, x2, #1, #0x1f
    //     0xafdfd4: cmp             x2, x0, asr #1
    //     0xafdfd8: b.eq            #0xafdfe4
    //     0xafdfdc: bl              #0xd69bb8
    //     0xafdfe0: stur            x2, [x0, #7]
    // 0xafdfe4: LeaveFrame
    //     0xafdfe4: mov             SP, fp
    //     0xafdfe8: ldp             fp, lr, [SP], #0x10
    // 0xafdfec: ret
    //     0xafdfec: ret             
    // 0xafdff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafdff0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafdff4: b               #0xafdf94
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf58f8, size: 0x108
    // 0xbf58f8: EnterFrame
    //     0xbf58f8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf58fc: mov             fp, SP
    // 0xbf5900: AllocStack(0x18)
    //     0xbf5900: sub             SP, SP, #0x18
    // 0xbf5904: CheckStackOverflow
    //     0xbf5904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5908: cmp             SP, x16
    //     0xbf590c: b.ls            #0xbf59d4
    // 0xbf5910: ldr             x0, [fp, #0x20]
    // 0xbf5914: LoadField: r1 = r0->field_13
    //     0xbf5914: ldur            w1, [x0, #0x13]
    // 0xbf5918: DecompressPointer r1
    //     0xbf5918: add             x1, x1, HEAP, lsl #32
    // 0xbf591c: ldr             x2, [fp, #0x18]
    // 0xbf5920: LoadField: r3 = r2->field_13
    //     0xbf5920: ldur            w3, [x2, #0x13]
    // 0xbf5924: DecompressPointer r3
    //     0xbf5924: add             x3, x3, HEAP, lsl #32
    // 0xbf5928: ldr             d0, [fp, #0x10]
    // 0xbf592c: r4 = inline_Allocate_Double()
    //     0xbf592c: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf5930: add             x4, x4, #0x10
    //     0xbf5934: cmp             x5, x4
    //     0xbf5938: b.ls            #0xbf59dc
    //     0xbf593c: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf5940: sub             x4, x4, #0xf
    //     0xbf5944: mov             x5, #0xd108
    //     0xbf5948: movk            x5, #3, lsl #16
    //     0xbf594c: stur            x5, [x4, #-1]
    // 0xbf5950: StoreField: r4->field_7 = d0
    //     0xbf5950: stur            d0, [x4, #7]
    // 0xbf5954: stur            x4, [fp, #-8]
    // 0xbf5958: stp             x3, x1, [SP, #-0x10]!
    // 0xbf595c: SaveReg r4
    //     0xbf595c: str             x4, [SP, #-8]!
    // 0xbf5960: r0 = lerpDouble()
    //     0xbf5960: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5964: add             SP, SP, #0x18
    // 0xbf5968: mov             x1, x0
    // 0xbf596c: ldr             x0, [fp, #0x20]
    // 0xbf5970: stur            x1, [fp, #-0x10]
    // 0xbf5974: LoadField: r2 = r0->field_17
    //     0xbf5974: ldur            w2, [x0, #0x17]
    // 0xbf5978: DecompressPointer r2
    //     0xbf5978: add             x2, x2, HEAP, lsl #32
    // 0xbf597c: ldr             x0, [fp, #0x18]
    // 0xbf5980: LoadField: r3 = r0->field_17
    //     0xbf5980: ldur            w3, [x0, #0x17]
    // 0xbf5984: DecompressPointer r3
    //     0xbf5984: add             x3, x3, HEAP, lsl #32
    // 0xbf5988: stp             x3, x2, [SP, #-0x10]!
    // 0xbf598c: ldur            x16, [fp, #-8]
    // 0xbf5990: SaveReg r16
    //     0xbf5990: str             x16, [SP, #-8]!
    // 0xbf5994: r0 = lerpDouble()
    //     0xbf5994: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5998: add             SP, SP, #0x18
    // 0xbf599c: stur            x0, [fp, #-0x18]
    // 0xbf59a0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf59a4: ldur            x16, [fp, #-8]
    // 0xbf59a8: SaveReg r16
    //     0xbf59a8: str             x16, [SP, #-8]!
    // 0xbf59ac: r0 = lerp()
    //     0xbf59ac: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf59b0: add             SP, SP, #0x18
    // 0xbf59b4: r0 = ButtonBarThemeData()
    //     0xbf59b4: bl              #0xbf5a00  ; AllocateButtonBarThemeDataStub -> ButtonBarThemeData (size=0x2c)
    // 0xbf59b8: ldur            x1, [fp, #-0x10]
    // 0xbf59bc: StoreField: r0->field_13 = r1
    //     0xbf59bc: stur            w1, [x0, #0x13]
    // 0xbf59c0: ldur            x1, [fp, #-0x18]
    // 0xbf59c4: StoreField: r0->field_17 = r1
    //     0xbf59c4: stur            w1, [x0, #0x17]
    // 0xbf59c8: LeaveFrame
    //     0xbf59c8: mov             SP, fp
    //     0xbf59cc: ldp             fp, lr, [SP], #0x10
    // 0xbf59d0: ret
    //     0xbf59d0: ret             
    // 0xbf59d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf59d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf59d8: b               #0xbf5910
    // 0xbf59dc: SaveReg d0
    //     0xbf59dc: str             q0, [SP, #-0x10]!
    // 0xbf59e0: stp             x2, x3, [SP, #-0x10]!
    // 0xbf59e4: stp             x0, x1, [SP, #-0x10]!
    // 0xbf59e8: r0 = AllocateDouble()
    //     0xbf59e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf59ec: mov             x4, x0
    // 0xbf59f0: ldp             x0, x1, [SP], #0x10
    // 0xbf59f4: ldp             x2, x3, [SP], #0x10
    // 0xbf59f8: RestoreReg d0
    //     0xbf59f8: ldr             q0, [SP], #0x10
    // 0xbf59fc: b               #0xbf5950
  }
  _ ==(/* No info */) {
    // ** addr: 0xc83d14, size: 0x168
    // 0xc83d14: EnterFrame
    //     0xc83d14: stp             fp, lr, [SP, #-0x10]!
    //     0xc83d18: mov             fp, SP
    // 0xc83d1c: CheckStackOverflow
    //     0xc83d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc83d20: cmp             SP, x16
    //     0xc83d24: b.ls            #0xc83e74
    // 0xc83d28: ldr             x1, [fp, #0x10]
    // 0xc83d2c: cmp             w1, NULL
    // 0xc83d30: b.ne            #0xc83d44
    // 0xc83d34: r0 = false
    //     0xc83d34: add             x0, NULL, #0x30  ; false
    // 0xc83d38: LeaveFrame
    //     0xc83d38: mov             SP, fp
    //     0xc83d3c: ldp             fp, lr, [SP], #0x10
    // 0xc83d40: ret
    //     0xc83d40: ret             
    // 0xc83d44: ldr             x2, [fp, #0x18]
    // 0xc83d48: cmp             w2, w1
    // 0xc83d4c: b.ne            #0xc83d60
    // 0xc83d50: r0 = true
    //     0xc83d50: add             x0, NULL, #0x20  ; true
    // 0xc83d54: LeaveFrame
    //     0xc83d54: mov             SP, fp
    //     0xc83d58: ldp             fp, lr, [SP], #0x10
    // 0xc83d5c: ret
    //     0xc83d5c: ret             
    // 0xc83d60: r0 = 59
    //     0xc83d60: mov             x0, #0x3b
    // 0xc83d64: branchIfSmi(r1, 0xc83d70)
    //     0xc83d64: tbz             w1, #0, #0xc83d70
    // 0xc83d68: r0 = LoadClassIdInstr(r1)
    //     0xc83d68: ldur            x0, [x1, #-1]
    //     0xc83d6c: ubfx            x0, x0, #0xc, #0x14
    // 0xc83d70: SaveReg r1
    //     0xc83d70: str             x1, [SP, #-8]!
    // 0xc83d74: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc83d74: mov             x17, #0x57c5
    //     0xc83d78: add             lr, x0, x17
    //     0xc83d7c: ldr             lr, [x21, lr, lsl #3]
    //     0xc83d80: blr             lr
    // 0xc83d84: add             SP, SP, #8
    // 0xc83d88: r1 = LoadClassIdInstr(r0)
    //     0xc83d88: ldur            x1, [x0, #-1]
    //     0xc83d8c: ubfx            x1, x1, #0xc, #0x14
    // 0xc83d90: r16 = ButtonBarThemeData
    //     0xc83d90: add             x16, PP, #0xe, lsl #12  ; [pp+0xe490] Type: ButtonBarThemeData
    //     0xc83d94: ldr             x16, [x16, #0x490]
    // 0xc83d98: stp             x16, x0, [SP, #-0x10]!
    // 0xc83d9c: mov             x0, x1
    // 0xc83da0: mov             lr, x0
    // 0xc83da4: ldr             lr, [x21, lr, lsl #3]
    // 0xc83da8: blr             lr
    // 0xc83dac: add             SP, SP, #0x10
    // 0xc83db0: tbz             w0, #4, #0xc83dc4
    // 0xc83db4: r0 = false
    //     0xc83db4: add             x0, NULL, #0x30  ; false
    // 0xc83db8: LeaveFrame
    //     0xc83db8: mov             SP, fp
    //     0xc83dbc: ldp             fp, lr, [SP], #0x10
    // 0xc83dc0: ret
    //     0xc83dc0: ret             
    // 0xc83dc4: ldr             x1, [fp, #0x10]
    // 0xc83dc8: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc83dc8: mov             x0, #0x76
    //     0xc83dcc: tbz             w1, #0, #0xc83ddc
    //     0xc83dd0: ldur            x0, [x1, #-1]
    //     0xc83dd4: ubfx            x0, x0, #0xc, #0x14
    //     0xc83dd8: lsl             x0, x0, #1
    // 0xc83ddc: r17 = 5668
    //     0xc83ddc: mov             x17, #0x1624
    // 0xc83de0: cmp             w0, w17
    // 0xc83de4: b.ne            #0xc83e64
    // 0xc83de8: ldr             x2, [fp, #0x18]
    // 0xc83dec: LoadField: r0 = r1->field_13
    //     0xc83dec: ldur            w0, [x1, #0x13]
    // 0xc83df0: DecompressPointer r0
    //     0xc83df0: add             x0, x0, HEAP, lsl #32
    // 0xc83df4: LoadField: r3 = r2->field_13
    //     0xc83df4: ldur            w3, [x2, #0x13]
    // 0xc83df8: DecompressPointer r3
    //     0xc83df8: add             x3, x3, HEAP, lsl #32
    // 0xc83dfc: r4 = LoadClassIdInstr(r0)
    //     0xc83dfc: ldur            x4, [x0, #-1]
    //     0xc83e00: ubfx            x4, x4, #0xc, #0x14
    // 0xc83e04: stp             x3, x0, [SP, #-0x10]!
    // 0xc83e08: mov             x0, x4
    // 0xc83e0c: mov             lr, x0
    // 0xc83e10: ldr             lr, [x21, lr, lsl #3]
    // 0xc83e14: blr             lr
    // 0xc83e18: add             SP, SP, #0x10
    // 0xc83e1c: tbnz            w0, #4, #0xc83e64
    // 0xc83e20: ldr             x1, [fp, #0x18]
    // 0xc83e24: ldr             x0, [fp, #0x10]
    // 0xc83e28: LoadField: r2 = r0->field_17
    //     0xc83e28: ldur            w2, [x0, #0x17]
    // 0xc83e2c: DecompressPointer r2
    //     0xc83e2c: add             x2, x2, HEAP, lsl #32
    // 0xc83e30: LoadField: r0 = r1->field_17
    //     0xc83e30: ldur            w0, [x1, #0x17]
    // 0xc83e34: DecompressPointer r0
    //     0xc83e34: add             x0, x0, HEAP, lsl #32
    // 0xc83e38: r1 = LoadClassIdInstr(r2)
    //     0xc83e38: ldur            x1, [x2, #-1]
    //     0xc83e3c: ubfx            x1, x1, #0xc, #0x14
    // 0xc83e40: stp             x0, x2, [SP, #-0x10]!
    // 0xc83e44: mov             x0, x1
    // 0xc83e48: mov             lr, x0
    // 0xc83e4c: ldr             lr, [x21, lr, lsl #3]
    // 0xc83e50: blr             lr
    // 0xc83e54: add             SP, SP, #0x10
    // 0xc83e58: tbnz            w0, #4, #0xc83e64
    // 0xc83e5c: r0 = true
    //     0xc83e5c: add             x0, NULL, #0x20  ; true
    // 0xc83e60: b               #0xc83e68
    // 0xc83e64: r0 = false
    //     0xc83e64: add             x0, NULL, #0x30  ; false
    // 0xc83e68: LeaveFrame
    //     0xc83e68: mov             SP, fp
    //     0xc83e6c: ldp             fp, lr, [SP], #0x10
    // 0xc83e70: ret
    //     0xc83e70: ret             
    // 0xc83e74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc83e74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc83e78: b               #0xc83d28
  }
}

// lib: , url: package:flutter/src/material/progress_indicator.dart

// class id: 1049292, size: 0x8
class :: {
}

// class id: 2773, size: 0x24, field offset: 0x1c
class _LinearProgressIndicatorDefaultsM3 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x20

  get _ linearMinHeight(/* No info */) {
    // ** addr: 0xcdcccc, size: 0xc
    // 0xcdcccc: r0 = 4.000000
    //     0xcdcccc: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e718] 4
    //     0xcdccd0: ldr             x0, [x0, #0x718]
    // 0xcdccd4: ret
    //     0xcdccd4: ret             
  }
  get _ linearTrackColor(/* No info */) {
    // ** addr: 0xcdcd7c, size: 0x70
    // 0xcdcd7c: EnterFrame
    //     0xcdcd7c: stp             fp, lr, [SP, #-0x10]!
    //     0xcdcd80: mov             fp, SP
    // 0xcdcd84: CheckStackOverflow
    //     0xcdcd84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdcd88: cmp             SP, x16
    //     0xcdcd8c: b.ls            #0xcdcde4
    // 0xcdcd90: ldr             x1, [fp, #0x10]
    // 0xcdcd94: LoadField: r0 = r1->field_1f
    //     0xcdcd94: ldur            w0, [x1, #0x1f]
    // 0xcdcd98: DecompressPointer r0
    //     0xcdcd98: add             x0, x0, HEAP, lsl #32
    // 0xcdcd9c: r16 = Sentinel
    //     0xcdcd9c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcdcda0: cmp             w0, w16
    // 0xcdcda4: b.ne            #0xcdcdb4
    // 0xcdcda8: r2 = _colors
    //     0xcdcda8: add             x2, PP, #0x50, lsl #12  ; [pp+0x50900] Field <_LinearProgressIndicatorDefaultsM3@793243954._colors@793243954>: late final (offset: 0x20)
    //     0xcdcdac: ldr             x2, [x2, #0x900]
    // 0xcdcdb0: r0 = InitLateFinalInstanceField()
    //     0xcdcdb0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcdcdb4: LoadField: r1 = r0->field_5b
    //     0xcdcdb4: ldur            w1, [x0, #0x5b]
    // 0xcdcdb8: DecompressPointer r1
    //     0xcdcdb8: add             x1, x1, HEAP, lsl #32
    // 0xcdcdbc: cmp             w1, NULL
    // 0xcdcdc0: b.ne            #0xcdcdd4
    // 0xcdcdc4: LoadField: r2 = r0->field_53
    //     0xcdcdc4: ldur            w2, [x0, #0x53]
    // 0xcdcdc8: DecompressPointer r2
    //     0xcdcdc8: add             x2, x2, HEAP, lsl #32
    // 0xcdcdcc: mov             x0, x2
    // 0xcdcdd0: b               #0xcdcdd8
    // 0xcdcdd4: mov             x0, x1
    // 0xcdcdd8: LeaveFrame
    //     0xcdcdd8: mov             SP, fp
    //     0xcdcddc: ldp             fp, lr, [SP], #0x10
    // 0xcdcde0: ret
    //     0xcdcde0: ret             
    // 0xcdcde4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdcde4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdcde8: b               #0xcdcd90
  }
  get _ color(/* No info */) {
    // ** addr: 0xce4b40, size: 0x58
    // 0xce4b40: EnterFrame
    //     0xce4b40: stp             fp, lr, [SP, #-0x10]!
    //     0xce4b44: mov             fp, SP
    // 0xce4b48: CheckStackOverflow
    //     0xce4b48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce4b4c: cmp             SP, x16
    //     0xce4b50: b.ls            #0xce4b90
    // 0xce4b54: ldr             x1, [fp, #0x10]
    // 0xce4b58: LoadField: r0 = r1->field_1f
    //     0xce4b58: ldur            w0, [x1, #0x1f]
    // 0xce4b5c: DecompressPointer r0
    //     0xce4b5c: add             x0, x0, HEAP, lsl #32
    // 0xce4b60: r16 = Sentinel
    //     0xce4b60: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce4b64: cmp             w0, w16
    // 0xce4b68: b.ne            #0xce4b78
    // 0xce4b6c: r2 = _colors
    //     0xce4b6c: add             x2, PP, #0x50, lsl #12  ; [pp+0x50900] Field <_LinearProgressIndicatorDefaultsM3@793243954._colors@793243954>: late final (offset: 0x20)
    //     0xce4b70: ldr             x2, [x2, #0x900]
    // 0xce4b74: r0 = InitLateFinalInstanceField()
    //     0xce4b74: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce4b78: LoadField: r1 = r0->field_b
    //     0xce4b78: ldur            w1, [x0, #0xb]
    // 0xce4b7c: DecompressPointer r1
    //     0xce4b7c: add             x1, x1, HEAP, lsl #32
    // 0xce4b80: mov             x0, x1
    // 0xce4b84: LeaveFrame
    //     0xce4b84: mov             SP, fp
    //     0xce4b88: ldp             fp, lr, [SP], #0x10
    // 0xce4b8c: ret
    //     0xce4b8c: ret             
    // 0xce4b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4b90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4b94: b               #0xce4b54
  }
}

// class id: 2774, size: 0x24, field offset: 0x1c
class _CircularProgressIndicatorDefaultsM3 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x20

  get _ color(/* No info */) {
    // ** addr: 0xce4ae8, size: 0x58
    // 0xce4ae8: EnterFrame
    //     0xce4ae8: stp             fp, lr, [SP, #-0x10]!
    //     0xce4aec: mov             fp, SP
    // 0xce4af0: CheckStackOverflow
    //     0xce4af0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce4af4: cmp             SP, x16
    //     0xce4af8: b.ls            #0xce4b38
    // 0xce4afc: ldr             x1, [fp, #0x10]
    // 0xce4b00: LoadField: r0 = r1->field_1f
    //     0xce4b00: ldur            w0, [x1, #0x1f]
    // 0xce4b04: DecompressPointer r0
    //     0xce4b04: add             x0, x0, HEAP, lsl #32
    // 0xce4b08: r16 = Sentinel
    //     0xce4b08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce4b0c: cmp             w0, w16
    // 0xce4b10: b.ne            #0xce4b20
    // 0xce4b14: r2 = _colors
    //     0xce4b14: add             x2, PP, #0x22, lsl #12  ; [pp+0x22068] Field <_CircularProgressIndicatorDefaultsM3@793243954._colors@793243954>: late final (offset: 0x20)
    //     0xce4b18: ldr             x2, [x2, #0x68]
    // 0xce4b1c: r0 = InitLateFinalInstanceField()
    //     0xce4b1c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce4b20: LoadField: r1 = r0->field_b
    //     0xce4b20: ldur            w1, [x0, #0xb]
    // 0xce4b24: DecompressPointer r1
    //     0xce4b24: add             x1, x1, HEAP, lsl #32
    // 0xce4b28: mov             x0, x1
    // 0xce4b2c: LeaveFrame
    //     0xce4b2c: mov             SP, fp
    //     0xce4b30: ldp             fp, lr, [SP], #0x10
    // 0xce4b34: ret
    //     0xce4b34: ret             
    // 0xce4b38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4b38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4b3c: b               #0xce4afc
  }
}

// class id: 2775, size: 0x24, field offset: 0x1c
class _LinearProgressIndicatorDefaultsM2 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x20

  get _ linearTrackColor(/* No info */) {
    // ** addr: 0xcdccd8, size: 0x58
    // 0xcdccd8: EnterFrame
    //     0xcdccd8: stp             fp, lr, [SP, #-0x10]!
    //     0xcdccdc: mov             fp, SP
    // 0xcdcce0: CheckStackOverflow
    //     0xcdcce0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdcce4: cmp             SP, x16
    //     0xcdcce8: b.ls            #0xcdcd28
    // 0xcdccec: ldr             x1, [fp, #0x10]
    // 0xcdccf0: LoadField: r0 = r1->field_1f
    //     0xcdccf0: ldur            w0, [x1, #0x1f]
    // 0xcdccf4: DecompressPointer r0
    //     0xcdccf4: add             x0, x0, HEAP, lsl #32
    // 0xcdccf8: r16 = Sentinel
    //     0xcdccf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcdccfc: cmp             w0, w16
    // 0xcdcd00: b.ne            #0xcdcd10
    // 0xcdcd04: r2 = _colors
    //     0xcdcd04: add             x2, PP, #0x50, lsl #12  ; [pp+0x508b8] Field <_LinearProgressIndicatorDefaultsM2@793243954._colors@793243954>: late final (offset: 0x20)
    //     0xcdcd08: ldr             x2, [x2, #0x8b8]
    // 0xcdcd0c: r0 = InitLateFinalInstanceField()
    //     0xcdcd0c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xcdcd10: LoadField: r1 = r0->field_4b
    //     0xcdcd10: ldur            w1, [x0, #0x4b]
    // 0xcdcd14: DecompressPointer r1
    //     0xcdcd14: add             x1, x1, HEAP, lsl #32
    // 0xcdcd18: mov             x0, x1
    // 0xcdcd1c: LeaveFrame
    //     0xcdcd1c: mov             SP, fp
    //     0xcdcd20: ldp             fp, lr, [SP], #0x10
    // 0xcdcd24: ret
    //     0xcdcd24: ret             
    // 0xcdcd28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdcd28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdcd2c: b               #0xcdccec
  }
  ColorScheme _colors(_LinearProgressIndicatorDefaultsM2) {
    // ** addr: 0xcdcd30, size: 0x4c
    // 0xcdcd30: EnterFrame
    //     0xcdcd30: stp             fp, lr, [SP, #-0x10]!
    //     0xcdcd34: mov             fp, SP
    // 0xcdcd38: CheckStackOverflow
    //     0xcdcd38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdcd3c: cmp             SP, x16
    //     0xcdcd40: b.ls            #0xcdcd74
    // 0xcdcd44: ldr             x0, [fp, #0x10]
    // 0xcdcd48: LoadField: r1 = r0->field_1b
    //     0xcdcd48: ldur            w1, [x0, #0x1b]
    // 0xcdcd4c: DecompressPointer r1
    //     0xcdcd4c: add             x1, x1, HEAP, lsl #32
    // 0xcdcd50: SaveReg r1
    //     0xcdcd50: str             x1, [SP, #-8]!
    // 0xcdcd54: r0 = of()
    //     0xcdcd54: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcdcd58: add             SP, SP, #8
    // 0xcdcd5c: LoadField: r1 = r0->field_3f
    //     0xcdcd5c: ldur            w1, [x0, #0x3f]
    // 0xcdcd60: DecompressPointer r1
    //     0xcdcd60: add             x1, x1, HEAP, lsl #32
    // 0xcdcd64: mov             x0, x1
    // 0xcdcd68: LeaveFrame
    //     0xcdcd68: mov             SP, fp
    //     0xcdcd6c: ldp             fp, lr, [SP], #0x10
    // 0xcdcd70: ret
    //     0xcdcd70: ret             
    // 0xcdcd74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdcd74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdcd78: b               #0xcdcd44
  }
  get _ color(/* No info */) {
    // ** addr: 0xce4a90, size: 0x58
    // 0xce4a90: EnterFrame
    //     0xce4a90: stp             fp, lr, [SP, #-0x10]!
    //     0xce4a94: mov             fp, SP
    // 0xce4a98: CheckStackOverflow
    //     0xce4a98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce4a9c: cmp             SP, x16
    //     0xce4aa0: b.ls            #0xce4ae0
    // 0xce4aa4: ldr             x1, [fp, #0x10]
    // 0xce4aa8: LoadField: r0 = r1->field_1f
    //     0xce4aa8: ldur            w0, [x1, #0x1f]
    // 0xce4aac: DecompressPointer r0
    //     0xce4aac: add             x0, x0, HEAP, lsl #32
    // 0xce4ab0: r16 = Sentinel
    //     0xce4ab0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce4ab4: cmp             w0, w16
    // 0xce4ab8: b.ne            #0xce4ac8
    // 0xce4abc: r2 = _colors
    //     0xce4abc: add             x2, PP, #0x50, lsl #12  ; [pp+0x508b8] Field <_LinearProgressIndicatorDefaultsM2@793243954._colors@793243954>: late final (offset: 0x20)
    //     0xce4ac0: ldr             x2, [x2, #0x8b8]
    // 0xce4ac4: r0 = InitLateFinalInstanceField()
    //     0xce4ac4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce4ac8: LoadField: r1 = r0->field_b
    //     0xce4ac8: ldur            w1, [x0, #0xb]
    // 0xce4acc: DecompressPointer r1
    //     0xce4acc: add             x1, x1, HEAP, lsl #32
    // 0xce4ad0: mov             x0, x1
    // 0xce4ad4: LeaveFrame
    //     0xce4ad4: mov             SP, fp
    //     0xce4ad8: ldp             fp, lr, [SP], #0x10
    // 0xce4adc: ret
    //     0xce4adc: ret             
    // 0xce4ae0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4ae0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4ae4: b               #0xce4aa4
  }
}

// class id: 2776, size: 0x24, field offset: 0x1c
class _CircularProgressIndicatorDefaultsM2 extends ProgressIndicatorThemeData {

  late final ColorScheme _colors; // offset: 0x20

  get _ color(/* No info */) {
    // ** addr: 0xce4a38, size: 0x58
    // 0xce4a38: EnterFrame
    //     0xce4a38: stp             fp, lr, [SP, #-0x10]!
    //     0xce4a3c: mov             fp, SP
    // 0xce4a40: CheckStackOverflow
    //     0xce4a40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce4a44: cmp             SP, x16
    //     0xce4a48: b.ls            #0xce4a88
    // 0xce4a4c: ldr             x1, [fp, #0x10]
    // 0xce4a50: LoadField: r0 = r1->field_1f
    //     0xce4a50: ldur            w0, [x1, #0x1f]
    // 0xce4a54: DecompressPointer r0
    //     0xce4a54: add             x0, x0, HEAP, lsl #32
    // 0xce4a58: r16 = Sentinel
    //     0xce4a58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce4a5c: cmp             w0, w16
    // 0xce4a60: b.ne            #0xce4a70
    // 0xce4a64: r2 = _colors
    //     0xce4a64: add             x2, PP, #0x22, lsl #12  ; [pp+0x22060] Field <_CircularProgressIndicatorDefaultsM2@793243954._colors@793243954>: late final (offset: 0x20)
    //     0xce4a68: ldr             x2, [x2, #0x60]
    // 0xce4a6c: r0 = InitLateFinalInstanceField()
    //     0xce4a6c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce4a70: LoadField: r1 = r0->field_b
    //     0xce4a70: ldur            w1, [x0, #0xb]
    // 0xce4a74: DecompressPointer r1
    //     0xce4a74: add             x1, x1, HEAP, lsl #32
    // 0xce4a78: mov             x0, x1
    // 0xce4a7c: LeaveFrame
    //     0xce4a7c: mov             SP, fp
    //     0xce4a80: ldp             fp, lr, [SP], #0x10
    // 0xce4a84: ret
    //     0xce4a84: ret             
    // 0xce4a88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce4a88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce4a8c: b               #0xce4a4c
  }
}

// class id: 3286, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CircularProgressIndicatorState&State&SingleTickerProviderStateMixin extends State<CircularProgressIndicator>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x6180f4, size: 0x98
    // 0x6180f4: EnterFrame
    //     0x6180f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6180f8: mov             fp, SP
    // 0x6180fc: CheckStackOverflow
    //     0x6180fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618100: cmp             SP, x16
    //     0x618104: b.ls            #0x618180
    // 0x618108: r0 = Ticker()
    //     0x618108: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x61810c: mov             x1, x0
    // 0x618110: r0 = false
    //     0x618110: add             x0, NULL, #0x30  ; false
    // 0x618114: StoreField: r1->field_b = r0
    //     0x618114: stur            w0, [x1, #0xb]
    // 0x618118: ldr             x0, [fp, #0x10]
    // 0x61811c: StoreField: r1->field_13 = r0
    //     0x61811c: stur            w0, [x1, #0x13]
    // 0x618120: mov             x0, x1
    // 0x618124: ldr             x1, [fp, #0x18]
    // 0x618128: StoreField: r1->field_13 = r0
    //     0x618128: stur            w0, [x1, #0x13]
    //     0x61812c: ldurb           w16, [x1, #-1]
    //     0x618130: ldurb           w17, [x0, #-1]
    //     0x618134: and             x16, x17, x16, lsr #2
    //     0x618138: tst             x16, HEAP, lsr #32
    //     0x61813c: b.eq            #0x618144
    //     0x618140: bl              #0xd6826c
    // 0x618144: SaveReg r1
    //     0x618144: str             x1, [SP, #-8]!
    // 0x618148: r0 = _updateTickerModeNotifier()
    //     0x618148: bl              #0x6181b4  ; [package:flutter/src/material/progress_indicator.dart] __CircularProgressIndicatorState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x61814c: add             SP, SP, #8
    // 0x618150: ldr             x16, [fp, #0x18]
    // 0x618154: SaveReg r16
    //     0x618154: str             x16, [SP, #-8]!
    // 0x618158: r0 = _updateTicker()
    //     0x618158: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x61815c: add             SP, SP, #8
    // 0x618160: ldr             x1, [fp, #0x18]
    // 0x618164: LoadField: r0 = r1->field_13
    //     0x618164: ldur            w0, [x1, #0x13]
    // 0x618168: DecompressPointer r0
    //     0x618168: add             x0, x0, HEAP, lsl #32
    // 0x61816c: cmp             w0, NULL
    // 0x618170: b.eq            #0x618188
    // 0x618174: LeaveFrame
    //     0x618174: mov             SP, fp
    //     0x618178: ldp             fp, lr, [SP], #0x10
    // 0x61817c: ret
    //     0x61817c: ret             
    // 0x618180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618184: b               #0x618108
    // 0x618188: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618188: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6181b4, size: 0x11c
    // 0x6181b4: EnterFrame
    //     0x6181b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6181b8: mov             fp, SP
    // 0x6181bc: AllocStack(0x10)
    //     0x6181bc: sub             SP, SP, #0x10
    // 0x6181c0: CheckStackOverflow
    //     0x6181c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6181c4: cmp             SP, x16
    //     0x6181c8: b.ls            #0x6182c4
    // 0x6181cc: ldr             x0, [fp, #0x10]
    // 0x6181d0: LoadField: r1 = r0->field_f
    //     0x6181d0: ldur            w1, [x0, #0xf]
    // 0x6181d4: DecompressPointer r1
    //     0x6181d4: add             x1, x1, HEAP, lsl #32
    // 0x6181d8: cmp             w1, NULL
    // 0x6181dc: b.eq            #0x6182cc
    // 0x6181e0: SaveReg r1
    //     0x6181e0: str             x1, [SP, #-8]!
    // 0x6181e4: r0 = getNotifier()
    //     0x6181e4: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6181e8: add             SP, SP, #8
    // 0x6181ec: mov             x1, x0
    // 0x6181f0: ldr             x0, [fp, #0x10]
    // 0x6181f4: stur            x1, [fp, #-0x10]
    // 0x6181f8: LoadField: r2 = r0->field_17
    //     0x6181f8: ldur            w2, [x0, #0x17]
    // 0x6181fc: DecompressPointer r2
    //     0x6181fc: add             x2, x2, HEAP, lsl #32
    // 0x618200: stur            x2, [fp, #-8]
    // 0x618204: cmp             w1, w2
    // 0x618208: b.ne            #0x61821c
    // 0x61820c: r0 = Null
    //     0x61820c: mov             x0, NULL
    // 0x618210: LeaveFrame
    //     0x618210: mov             SP, fp
    //     0x618214: ldp             fp, lr, [SP], #0x10
    // 0x618218: ret
    //     0x618218: ret             
    // 0x61821c: cmp             w2, NULL
    // 0x618220: b.eq            #0x61825c
    // 0x618224: r1 = 1
    //     0x618224: mov             x1, #1
    // 0x618228: r0 = AllocateContext()
    //     0x618228: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61822c: mov             x1, x0
    // 0x618230: ldr             x0, [fp, #0x10]
    // 0x618234: StoreField: r1->field_f = r0
    //     0x618234: stur            w0, [x1, #0xf]
    // 0x618238: mov             x2, x1
    // 0x61823c: r1 = Function '_updateTicker@156311458':.
    //     0x61823c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0b8] AnonymousClosure: (0x6182d0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x618240: ldr             x1, [x1, #0xb8]
    // 0x618244: r0 = AllocateClosure()
    //     0x618244: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618248: ldur            x16, [fp, #-8]
    // 0x61824c: stp             x0, x16, [SP, #-0x10]!
    // 0x618250: r0 = removeListener()
    //     0x618250: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x618254: add             SP, SP, #0x10
    // 0x618258: ldr             x0, [fp, #0x10]
    // 0x61825c: r1 = 1
    //     0x61825c: mov             x1, #1
    // 0x618260: r0 = AllocateContext()
    //     0x618260: bl              #0xd68aa4  ; AllocateContextStub
    // 0x618264: mov             x1, x0
    // 0x618268: ldr             x0, [fp, #0x10]
    // 0x61826c: StoreField: r1->field_f = r0
    //     0x61826c: stur            w0, [x1, #0xf]
    // 0x618270: mov             x2, x1
    // 0x618274: r1 = Function '_updateTicker@156311458':.
    //     0x618274: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0b8] AnonymousClosure: (0x6182d0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x618278: ldr             x1, [x1, #0xb8]
    // 0x61827c: r0 = AllocateClosure()
    //     0x61827c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618280: ldur            x16, [fp, #-0x10]
    // 0x618284: stp             x0, x16, [SP, #-0x10]!
    // 0x618288: r0 = addListener()
    //     0x618288: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x61828c: add             SP, SP, #0x10
    // 0x618290: ldur            x0, [fp, #-0x10]
    // 0x618294: ldr             x1, [fp, #0x10]
    // 0x618298: StoreField: r1->field_17 = r0
    //     0x618298: stur            w0, [x1, #0x17]
    //     0x61829c: ldurb           w16, [x1, #-1]
    //     0x6182a0: ldurb           w17, [x0, #-1]
    //     0x6182a4: and             x16, x17, x16, lsr #2
    //     0x6182a8: tst             x16, HEAP, lsr #32
    //     0x6182ac: b.eq            #0x6182b4
    //     0x6182b0: bl              #0xd6826c
    // 0x6182b4: r0 = Null
    //     0x6182b4: mov             x0, NULL
    // 0x6182b8: LeaveFrame
    //     0x6182b8: mov             SP, fp
    //     0x6182bc: ldp             fp, lr, [SP], #0x10
    // 0x6182c0: ret
    //     0x6182c0: ret             
    // 0x6182c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6182c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6182c8: b               #0x6181cc
    // 0x6182cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6182cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x6182d0, size: 0x48
    // 0x6182d0: EnterFrame
    //     0x6182d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6182d4: mov             fp, SP
    // 0x6182d8: ldr             x0, [fp, #0x10]
    // 0x6182dc: LoadField: r1 = r0->field_17
    //     0x6182dc: ldur            w1, [x0, #0x17]
    // 0x6182e0: DecompressPointer r1
    //     0x6182e0: add             x1, x1, HEAP, lsl #32
    // 0x6182e4: CheckStackOverflow
    //     0x6182e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6182e8: cmp             SP, x16
    //     0x6182ec: b.ls            #0x618310
    // 0x6182f0: LoadField: r0 = r1->field_f
    //     0x6182f0: ldur            w0, [x1, #0xf]
    // 0x6182f4: DecompressPointer r0
    //     0x6182f4: add             x0, x0, HEAP, lsl #32
    // 0x6182f8: SaveReg r0
    //     0x6182f8: str             x0, [SP, #-8]!
    // 0x6182fc: r0 = _updateTicker()
    //     0x6182fc: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x618300: add             SP, SP, #8
    // 0x618304: LeaveFrame
    //     0x618304: mov             SP, fp
    //     0x618308: ldp             fp, lr, [SP], #0x10
    // 0x61830c: ret
    //     0x61830c: ret             
    // 0x618310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618314: b               #0x6182f0
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f58c, size: 0x4c
    // 0x81f58c: EnterFrame
    //     0x81f58c: stp             fp, lr, [SP, #-0x10]!
    //     0x81f590: mov             fp, SP
    // 0x81f594: CheckStackOverflow
    //     0x81f594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f598: cmp             SP, x16
    //     0x81f59c: b.ls            #0x81f5d0
    // 0x81f5a0: ldr             x16, [fp, #0x10]
    // 0x81f5a4: SaveReg r16
    //     0x81f5a4: str             x16, [SP, #-8]!
    // 0x81f5a8: r0 = _updateTickerModeNotifier()
    //     0x81f5a8: bl              #0x6181b4  ; [package:flutter/src/material/progress_indicator.dart] __CircularProgressIndicatorState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f5ac: add             SP, SP, #8
    // 0x81f5b0: ldr             x16, [fp, #0x10]
    // 0x81f5b4: SaveReg r16
    //     0x81f5b4: str             x16, [SP, #-8]!
    // 0x81f5b8: r0 = _updateTicker()
    //     0x81f5b8: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f5bc: add             SP, SP, #8
    // 0x81f5c0: r0 = Null
    //     0x81f5c0: mov             x0, NULL
    // 0x81f5c4: LeaveFrame
    //     0x81f5c4: mov             SP, fp
    //     0x81f5c8: ldp             fp, lr, [SP], #0x10
    // 0x81f5cc: ret
    //     0x81f5cc: ret             
    // 0x81f5d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f5d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f5d4: b               #0x81f5a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52498, size: 0x8c
    // 0xa52498: EnterFrame
    //     0xa52498: stp             fp, lr, [SP, #-0x10]!
    //     0xa5249c: mov             fp, SP
    // 0xa524a0: AllocStack(0x8)
    //     0xa524a0: sub             SP, SP, #8
    // 0xa524a4: CheckStackOverflow
    //     0xa524a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa524a8: cmp             SP, x16
    //     0xa524ac: b.ls            #0xa5251c
    // 0xa524b0: ldr             x0, [fp, #0x10]
    // 0xa524b4: LoadField: r1 = r0->field_17
    //     0xa524b4: ldur            w1, [x0, #0x17]
    // 0xa524b8: DecompressPointer r1
    //     0xa524b8: add             x1, x1, HEAP, lsl #32
    // 0xa524bc: stur            x1, [fp, #-8]
    // 0xa524c0: cmp             w1, NULL
    // 0xa524c4: b.ne            #0xa524d0
    // 0xa524c8: mov             x1, x0
    // 0xa524cc: b               #0xa52508
    // 0xa524d0: r1 = 1
    //     0xa524d0: mov             x1, #1
    // 0xa524d4: r0 = AllocateContext()
    //     0xa524d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa524d8: mov             x1, x0
    // 0xa524dc: ldr             x0, [fp, #0x10]
    // 0xa524e0: StoreField: r1->field_f = r0
    //     0xa524e0: stur            w0, [x1, #0xf]
    // 0xa524e4: mov             x2, x1
    // 0xa524e8: r1 = Function '_updateTicker@156311458':.
    //     0xa524e8: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d0b8] AnonymousClosure: (0x6182d0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa524ec: ldr             x1, [x1, #0xb8]
    // 0xa524f0: r0 = AllocateClosure()
    //     0xa524f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa524f4: ldur            x16, [fp, #-8]
    // 0xa524f8: stp             x0, x16, [SP, #-0x10]!
    // 0xa524fc: r0 = removeListener()
    //     0xa524fc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa52500: add             SP, SP, #0x10
    // 0xa52504: ldr             x1, [fp, #0x10]
    // 0xa52508: StoreField: r1->field_17 = rNULL
    //     0xa52508: stur            NULL, [x1, #0x17]
    // 0xa5250c: r0 = Null
    //     0xa5250c: mov             x0, NULL
    // 0xa52510: LeaveFrame
    //     0xa52510: mov             SP, fp
    //     0xa52514: ldp             fp, lr, [SP], #0x10
    // 0xa52518: ret
    //     0xa52518: ret             
    // 0xa5251c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5251c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52520: b               #0xa524b0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa52524, size: 0x48
    // 0xa52524: EnterFrame
    //     0xa52524: stp             fp, lr, [SP, #-0x10]!
    //     0xa52528: mov             fp, SP
    // 0xa5252c: ldr             x0, [fp, #0x10]
    // 0xa52530: LoadField: r1 = r0->field_17
    //     0xa52530: ldur            w1, [x0, #0x17]
    // 0xa52534: DecompressPointer r1
    //     0xa52534: add             x1, x1, HEAP, lsl #32
    // 0xa52538: CheckStackOverflow
    //     0xa52538: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5253c: cmp             SP, x16
    //     0xa52540: b.ls            #0xa52564
    // 0xa52544: LoadField: r0 = r1->field_f
    //     0xa52544: ldur            w0, [x1, #0xf]
    // 0xa52548: DecompressPointer r0
    //     0xa52548: add             x0, x0, HEAP, lsl #32
    // 0xa5254c: SaveReg r0
    //     0xa5254c: str             x0, [SP, #-8]!
    // 0xa52550: r0 = dispose()
    //     0xa52550: bl              #0xa52498  ; [package:flutter/src/material/progress_indicator.dart] __CircularProgressIndicatorState&State&SingleTickerProviderStateMixin::dispose
    // 0xa52554: add             SP, SP, #8
    // 0xa52558: LeaveFrame
    //     0xa52558: mov             SP, fp
    //     0xa5255c: ldp             fp, lr, [SP], #0x10
    // 0xa52560: ret
    //     0xa52560: ret             
    // 0xa52564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52568: b               #0xa52544
  }
}

// class id: 3287, size: 0x20, field offset: 0x1c
class _CircularProgressIndicatorState extends __CircularProgressIndicatorState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c
  static late final Animatable<double> _strokeHeadTween; // offset: 0xe08
  static late final Animatable<double> _strokeTailTween; // offset: 0xe0c
  static late final Animatable<double> _offsetTween; // offset: 0xe10
  static late final Animatable<double> _rotationTween; // offset: 0xe14

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b9204, size: 0x178
    // 0x7b9204: EnterFrame
    //     0x7b9204: stp             fp, lr, [SP, #-0x10]!
    //     0x7b9208: mov             fp, SP
    // 0x7b920c: CheckStackOverflow
    //     0x7b920c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b9210: cmp             SP, x16
    //     0x7b9214: b.ls            #0x7b9358
    // 0x7b9218: ldr             x0, [fp, #0x10]
    // 0x7b921c: r2 = Null
    //     0x7b921c: mov             x2, NULL
    // 0x7b9220: r1 = Null
    //     0x7b9220: mov             x1, NULL
    // 0x7b9224: r4 = 59
    //     0x7b9224: mov             x4, #0x3b
    // 0x7b9228: branchIfSmi(r0, 0x7b9234)
    //     0x7b9228: tbz             w0, #0, #0x7b9234
    // 0x7b922c: r4 = LoadClassIdInstr(r0)
    //     0x7b922c: ldur            x4, [x0, #-1]
    //     0x7b9230: ubfx            x4, x4, #0xc, #0x14
    // 0x7b9234: r17 = -4128
    //     0x7b9234: mov             x17, #-0x1020
    // 0x7b9238: add             x4, x4, x17
    // 0x7b923c: cmp             x4, #1
    // 0x7b9240: b.ls            #0x7b9258
    // 0x7b9244: r8 = CircularProgressIndicator
    //     0x7b9244: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d058] Type: CircularProgressIndicator
    //     0x7b9248: ldr             x8, [x8, #0x58]
    // 0x7b924c: r3 = Null
    //     0x7b924c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d060] Null
    //     0x7b9250: ldr             x3, [x3, #0x60]
    // 0x7b9254: r0 = CircularProgressIndicator()
    //     0x7b9254: bl              #0x61818c  ; IsType_CircularProgressIndicator_Stub
    // 0x7b9258: ldr             x3, [fp, #0x18]
    // 0x7b925c: LoadField: r2 = r3->field_7
    //     0x7b925c: ldur            w2, [x3, #7]
    // 0x7b9260: DecompressPointer r2
    //     0x7b9260: add             x2, x2, HEAP, lsl #32
    // 0x7b9264: ldr             x0, [fp, #0x10]
    // 0x7b9268: r1 = Null
    //     0x7b9268: mov             x1, NULL
    // 0x7b926c: cmp             w2, NULL
    // 0x7b9270: b.eq            #0x7b9294
    // 0x7b9274: LoadField: r4 = r2->field_17
    //     0x7b9274: ldur            w4, [x2, #0x17]
    // 0x7b9278: DecompressPointer r4
    //     0x7b9278: add             x4, x4, HEAP, lsl #32
    // 0x7b927c: r8 = X0 bound StatefulWidget
    //     0x7b927c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b9280: ldr             x8, [x8, #0x858]
    // 0x7b9284: LoadField: r9 = r4->field_7
    //     0x7b9284: ldur            x9, [x4, #7]
    // 0x7b9288: r3 = Null
    //     0x7b9288: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d070] Null
    //     0x7b928c: ldr             x3, [x3, #0x70]
    // 0x7b9290: blr             x9
    // 0x7b9294: ldr             x0, [fp, #0x18]
    // 0x7b9298: LoadField: r1 = r0->field_b
    //     0x7b9298: ldur            w1, [x0, #0xb]
    // 0x7b929c: DecompressPointer r1
    //     0x7b929c: add             x1, x1, HEAP, lsl #32
    // 0x7b92a0: cmp             w1, NULL
    // 0x7b92a4: b.eq            #0x7b9360
    // 0x7b92a8: LoadField: r2 = r1->field_b
    //     0x7b92a8: ldur            w2, [x1, #0xb]
    // 0x7b92ac: DecompressPointer r2
    //     0x7b92ac: add             x2, x2, HEAP, lsl #32
    // 0x7b92b0: cmp             w2, NULL
    // 0x7b92b4: b.ne            #0x7b9300
    // 0x7b92b8: LoadField: r1 = r0->field_1b
    //     0x7b92b8: ldur            w1, [x0, #0x1b]
    // 0x7b92bc: DecompressPointer r1
    //     0x7b92bc: add             x1, x1, HEAP, lsl #32
    // 0x7b92c0: r16 = Sentinel
    //     0x7b92c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b92c4: cmp             w1, w16
    // 0x7b92c8: b.eq            #0x7b9364
    // 0x7b92cc: LoadField: r3 = r1->field_2f
    //     0x7b92cc: ldur            w3, [x1, #0x2f]
    // 0x7b92d0: DecompressPointer r3
    //     0x7b92d0: add             x3, x3, HEAP, lsl #32
    // 0x7b92d4: cmp             w3, NULL
    // 0x7b92d8: b.eq            #0x7b92ec
    // 0x7b92dc: LoadField: r4 = r3->field_7
    //     0x7b92dc: ldur            w4, [x3, #7]
    // 0x7b92e0: DecompressPointer r4
    //     0x7b92e0: add             x4, x4, HEAP, lsl #32
    // 0x7b92e4: cmp             w4, NULL
    // 0x7b92e8: b.ne            #0x7b9300
    // 0x7b92ec: SaveReg r1
    //     0x7b92ec: str             x1, [SP, #-8]!
    // 0x7b92f0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b92f0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b92f4: r0 = repeat()
    //     0x7b92f4: bl              #0x7b8ecc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x7b92f8: add             SP, SP, #8
    // 0x7b92fc: b               #0x7b9348
    // 0x7b9300: cmp             w2, NULL
    // 0x7b9304: b.eq            #0x7b9348
    // 0x7b9308: LoadField: r1 = r0->field_1b
    //     0x7b9308: ldur            w1, [x0, #0x1b]
    // 0x7b930c: DecompressPointer r1
    //     0x7b930c: add             x1, x1, HEAP, lsl #32
    // 0x7b9310: r16 = Sentinel
    //     0x7b9310: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b9314: cmp             w1, w16
    // 0x7b9318: b.eq            #0x7b9370
    // 0x7b931c: SaveReg r1
    //     0x7b931c: str             x1, [SP, #-8]!
    // 0x7b9320: r0 = isAnimating()
    //     0x7b9320: bl              #0x7b937c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::isAnimating
    // 0x7b9324: add             SP, SP, #8
    // 0x7b9328: tbnz            w0, #4, #0x7b9348
    // 0x7b932c: ldr             x0, [fp, #0x18]
    // 0x7b9330: LoadField: r1 = r0->field_1b
    //     0x7b9330: ldur            w1, [x0, #0x1b]
    // 0x7b9334: DecompressPointer r1
    //     0x7b9334: add             x1, x1, HEAP, lsl #32
    // 0x7b9338: SaveReg r1
    //     0x7b9338: str             x1, [SP, #-8]!
    // 0x7b933c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b933c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b9340: r0 = stop()
    //     0x7b9340: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x7b9344: add             SP, SP, #8
    // 0x7b9348: r0 = Null
    //     0x7b9348: mov             x0, NULL
    // 0x7b934c: LeaveFrame
    //     0x7b934c: mov             SP, fp
    //     0x7b9350: ldp             fp, lr, [SP], #0x10
    // 0x7b9354: ret
    //     0x7b9354: ret             
    // 0x7b9358: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b9358: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b935c: b               #0x7b9218
    // 0x7b9360: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b9360: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b9364: r9 = _controller
    //     0x7b9364: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x7b9368: ldr             x9, [x9, #0xfc8]
    // 0x7b936c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b936c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b9370: r9 = _controller
    //     0x7b9370: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x7b9374: ldr             x9, [x9, #0xfc8]
    // 0x7b9378: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b9378: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _rotationTween() {
    // ** addr: 0x863b64, size: 0x28
    // 0x863b64: EnterFrame
    //     0x863b64: stp             fp, lr, [SP, #-0x10]!
    //     0x863b68: mov             fp, SP
    // 0x863b6c: r1 = <double>
    //     0x863b6c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863b70: r0 = CurveTween()
    //     0x863b70: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863b74: r1 = Instance_SawTooth
    //     0x863b74: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cff0] Obj!SawTooth<double>@b4fc41
    //     0x863b78: ldr             x1, [x1, #0xff0]
    // 0x863b7c: StoreField: r0->field_b = r1
    //     0x863b7c: stur            w1, [x0, #0xb]
    // 0x863b80: LeaveFrame
    //     0x863b80: mov             SP, fp
    //     0x863b84: ldp             fp, lr, [SP], #0x10
    // 0x863b88: ret
    //     0x863b88: ret             
  }
  static Animatable<double> _offsetTween() {
    // ** addr: 0x863b8c, size: 0x28
    // 0x863b8c: EnterFrame
    //     0x863b8c: stp             fp, lr, [SP, #-0x10]!
    //     0x863b90: mov             fp, SP
    // 0x863b94: r1 = <double>
    //     0x863b94: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863b98: r0 = CurveTween()
    //     0x863b98: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863b9c: r1 = Instance_SawTooth
    //     0x863b9c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cff8] Obj!SawTooth<double>@b4fc61
    //     0x863ba0: ldr             x1, [x1, #0xff8]
    // 0x863ba4: StoreField: r0->field_b = r1
    //     0x863ba4: stur            w1, [x0, #0xb]
    // 0x863ba8: LeaveFrame
    //     0x863ba8: mov             SP, fp
    //     0x863bac: ldp             fp, lr, [SP], #0x10
    // 0x863bb0: ret
    //     0x863bb0: ret             
  }
  static Animatable<double> _strokeTailTween() {
    // ** addr: 0x863bb4, size: 0x70
    // 0x863bb4: EnterFrame
    //     0x863bb4: stp             fp, lr, [SP, #-0x10]!
    //     0x863bb8: mov             fp, SP
    // 0x863bbc: AllocStack(0x8)
    //     0x863bbc: sub             SP, SP, #8
    // 0x863bc0: CheckStackOverflow
    //     0x863bc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x863bc4: cmp             SP, x16
    //     0x863bc8: b.ls            #0x863c1c
    // 0x863bcc: r1 = <double>
    //     0x863bcc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863bd0: r0 = CurveTween()
    //     0x863bd0: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863bd4: mov             x2, x0
    // 0x863bd8: r0 = Instance_Interval
    //     0x863bd8: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d000] Obj!Interval<double>@b4f881
    //     0x863bdc: ldr             x0, [x0]
    // 0x863be0: stur            x2, [fp, #-8]
    // 0x863be4: StoreField: r2->field_b = r0
    //     0x863be4: stur            w0, [x2, #0xb]
    // 0x863be8: r1 = <double>
    //     0x863be8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863bec: r0 = CurveTween()
    //     0x863bec: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863bf0: mov             x1, x0
    // 0x863bf4: r0 = Instance_SawTooth
    //     0x863bf4: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cff8] Obj!SawTooth<double>@b4fc61
    //     0x863bf8: ldr             x0, [x0, #0xff8]
    // 0x863bfc: StoreField: r1->field_b = r0
    //     0x863bfc: stur            w0, [x1, #0xb]
    // 0x863c00: ldur            x16, [fp, #-8]
    // 0x863c04: stp             x1, x16, [SP, #-0x10]!
    // 0x863c08: r0 = chain()
    //     0x863c08: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x863c0c: add             SP, SP, #0x10
    // 0x863c10: LeaveFrame
    //     0x863c10: mov             SP, fp
    //     0x863c14: ldp             fp, lr, [SP], #0x10
    // 0x863c18: ret
    //     0x863c18: ret             
    // 0x863c1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863c1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863c20: b               #0x863bcc
  }
  static Animatable<double> _strokeHeadTween() {
    // ** addr: 0x863c24, size: 0x70
    // 0x863c24: EnterFrame
    //     0x863c24: stp             fp, lr, [SP, #-0x10]!
    //     0x863c28: mov             fp, SP
    // 0x863c2c: AllocStack(0x8)
    //     0x863c2c: sub             SP, SP, #8
    // 0x863c30: CheckStackOverflow
    //     0x863c30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x863c34: cmp             SP, x16
    //     0x863c38: b.ls            #0x863c8c
    // 0x863c3c: r1 = <double>
    //     0x863c3c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863c40: r0 = CurveTween()
    //     0x863c40: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863c44: mov             x2, x0
    // 0x863c48: r0 = Instance_Interval
    //     0x863c48: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d008] Obj!Interval<double>@b4f8a1
    //     0x863c4c: ldr             x0, [x0, #8]
    // 0x863c50: stur            x2, [fp, #-8]
    // 0x863c54: StoreField: r2->field_b = r0
    //     0x863c54: stur            w0, [x2, #0xb]
    // 0x863c58: r1 = <double>
    //     0x863c58: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863c5c: r0 = CurveTween()
    //     0x863c5c: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863c60: mov             x1, x0
    // 0x863c64: r0 = Instance_SawTooth
    //     0x863c64: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1cff8] Obj!SawTooth<double>@b4fc61
    //     0x863c68: ldr             x0, [x0, #0xff8]
    // 0x863c6c: StoreField: r1->field_b = r0
    //     0x863c6c: stur            w0, [x1, #0xb]
    // 0x863c70: ldur            x16, [fp, #-8]
    // 0x863c74: stp             x1, x16, [SP, #-0x10]!
    // 0x863c78: r0 = chain()
    //     0x863c78: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x863c7c: add             SP, SP, #0x10
    // 0x863c80: LeaveFrame
    //     0x863c80: mov             SP, fp
    //     0x863c84: ldp             fp, lr, [SP], #0x10
    // 0x863c88: ret
    //     0x863c88: ret             
    // 0x863c8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863c8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863c90: b               #0x863c3c
  }
  _ build(/* No info */) {
    // ** addr: 0x863cbc, size: 0x16c
    // 0x863cbc: EnterFrame
    //     0x863cbc: stp             fp, lr, [SP, #-0x10]!
    //     0x863cc0: mov             fp, SP
    // 0x863cc4: CheckStackOverflow
    //     0x863cc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x863cc8: cmp             SP, x16
    //     0x863ccc: b.ls            #0x863e18
    // 0x863cd0: ldr             x0, [fp, #0x18]
    // 0x863cd4: LoadField: r1 = r0->field_b
    //     0x863cd4: ldur            w1, [x0, #0xb]
    // 0x863cd8: DecompressPointer r1
    //     0x863cd8: add             x1, x1, HEAP, lsl #32
    // 0x863cdc: cmp             w1, NULL
    // 0x863ce0: b.eq            #0x863e20
    // 0x863ce4: LoadField: r2 = r1->field_23
    //     0x863ce4: ldur            w2, [x1, #0x23]
    // 0x863ce8: DecompressPointer r2
    //     0x863ce8: add             x2, x2, HEAP, lsl #32
    // 0x863cec: LoadField: r3 = r2->field_7
    //     0x863cec: ldur            x3, [x2, #7]
    // 0x863cf0: cmp             x3, #0
    // 0x863cf4: b.gt            #0x863d50
    // 0x863cf8: LoadField: r2 = r1->field_b
    //     0x863cf8: ldur            w2, [x1, #0xb]
    // 0x863cfc: DecompressPointer r2
    //     0x863cfc: add             x2, x2, HEAP, lsl #32
    // 0x863d00: cmp             w2, NULL
    // 0x863d04: b.eq            #0x863d38
    // 0x863d08: ldr             x16, [fp, #0x10]
    // 0x863d0c: stp             x16, x0, [SP, #-0x10]!
    // 0x863d10: r16 = 0.000000
    //     0x863d10: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x863d14: r30 = 0.000000
    //     0x863d14: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x863d18: stp             lr, x16, [SP, #-0x10]!
    // 0x863d1c: r16 = 0.000000
    //     0x863d1c: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x863d20: stp             xzr, x16, [SP, #-0x10]!
    // 0x863d24: r0 = _buildMaterialIndicator()
    //     0x863d24: bl              #0x86415c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildMaterialIndicator
    // 0x863d28: add             SP, SP, #0x30
    // 0x863d2c: LeaveFrame
    //     0x863d2c: mov             SP, fp
    //     0x863d30: ldp             fp, lr, [SP], #0x10
    // 0x863d34: ret
    //     0x863d34: ret             
    // 0x863d38: SaveReg r0
    //     0x863d38: str             x0, [SP, #-8]!
    // 0x863d3c: r0 = _buildAnimation()
    //     0x863d3c: bl              #0x863ef0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildAnimation
    // 0x863d40: add             SP, SP, #8
    // 0x863d44: LeaveFrame
    //     0x863d44: mov             SP, fp
    //     0x863d48: ldp             fp, lr, [SP], #0x10
    // 0x863d4c: ret
    //     0x863d4c: ret             
    // 0x863d50: ldr             x16, [fp, #0x10]
    // 0x863d54: SaveReg r16
    //     0x863d54: str             x16, [SP, #-8]!
    // 0x863d58: r0 = of()
    //     0x863d58: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x863d5c: add             SP, SP, #8
    // 0x863d60: LoadField: r1 = r0->field_1f
    //     0x863d60: ldur            w1, [x0, #0x1f]
    // 0x863d64: DecompressPointer r1
    //     0x863d64: add             x1, x1, HEAP, lsl #32
    // 0x863d68: LoadField: r0 = r1->field_7
    //     0x863d68: ldur            x0, [x1, #7]
    // 0x863d6c: cmp             x0, #2
    // 0x863d70: b.gt            #0x863d80
    // 0x863d74: cmp             x0, #1
    // 0x863d78: b.gt            #0x863d90
    // 0x863d7c: b               #0x863dac
    // 0x863d80: cmp             x0, #4
    // 0x863d84: b.gt            #0x863dac
    // 0x863d88: cmp             x0, #3
    // 0x863d8c: b.le            #0x863dac
    // 0x863d90: ldr             x16, [fp, #0x18]
    // 0x863d94: SaveReg r16
    //     0x863d94: str             x16, [SP, #-8]!
    // 0x863d98: r0 = _buildCupertinoIndicator()
    //     0x863d98: bl              #0x863e28  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildCupertinoIndicator
    // 0x863d9c: add             SP, SP, #8
    // 0x863da0: LeaveFrame
    //     0x863da0: mov             SP, fp
    //     0x863da4: ldp             fp, lr, [SP], #0x10
    // 0x863da8: ret
    //     0x863da8: ret             
    // 0x863dac: ldr             x0, [fp, #0x18]
    // 0x863db0: LoadField: r1 = r0->field_b
    //     0x863db0: ldur            w1, [x0, #0xb]
    // 0x863db4: DecompressPointer r1
    //     0x863db4: add             x1, x1, HEAP, lsl #32
    // 0x863db8: cmp             w1, NULL
    // 0x863dbc: b.eq            #0x863e24
    // 0x863dc0: LoadField: r2 = r1->field_b
    //     0x863dc0: ldur            w2, [x1, #0xb]
    // 0x863dc4: DecompressPointer r2
    //     0x863dc4: add             x2, x2, HEAP, lsl #32
    // 0x863dc8: cmp             w2, NULL
    // 0x863dcc: b.eq            #0x863e00
    // 0x863dd0: ldr             x16, [fp, #0x10]
    // 0x863dd4: stp             x16, x0, [SP, #-0x10]!
    // 0x863dd8: r16 = 0.000000
    //     0x863dd8: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x863ddc: r30 = 0.000000
    //     0x863ddc: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x863de0: stp             lr, x16, [SP, #-0x10]!
    // 0x863de4: r16 = 0.000000
    //     0x863de4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x863de8: stp             xzr, x16, [SP, #-0x10]!
    // 0x863dec: r0 = _buildMaterialIndicator()
    //     0x863dec: bl              #0x86415c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildMaterialIndicator
    // 0x863df0: add             SP, SP, #0x30
    // 0x863df4: LeaveFrame
    //     0x863df4: mov             SP, fp
    //     0x863df8: ldp             fp, lr, [SP], #0x10
    // 0x863dfc: ret
    //     0x863dfc: ret             
    // 0x863e00: SaveReg r0
    //     0x863e00: str             x0, [SP, #-8]!
    // 0x863e04: r0 = _buildAnimation()
    //     0x863e04: bl              #0x863ef0  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildAnimation
    // 0x863e08: add             SP, SP, #8
    // 0x863e0c: LeaveFrame
    //     0x863e0c: mov             SP, fp
    //     0x863e10: ldp             fp, lr, [SP], #0x10
    // 0x863e14: ret
    //     0x863e14: ret             
    // 0x863e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863e18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863e1c: b               #0x863cd0
    // 0x863e20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x863e20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x863e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x863e24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildCupertinoIndicator(/* No info */) {
    // ** addr: 0x863e28, size: 0xbc
    // 0x863e28: EnterFrame
    //     0x863e28: stp             fp, lr, [SP, #-0x10]!
    //     0x863e2c: mov             fp, SP
    // 0x863e30: AllocStack(0x10)
    //     0x863e30: sub             SP, SP, #0x10
    // 0x863e34: CheckStackOverflow
    //     0x863e34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x863e38: cmp             SP, x16
    //     0x863e3c: b.ls            #0x863ed4
    // 0x863e40: ldr             x1, [fp, #0x10]
    // 0x863e44: LoadField: r0 = r1->field_b
    //     0x863e44: ldur            w0, [x1, #0xb]
    // 0x863e48: DecompressPointer r0
    //     0x863e48: add             x0, x0, HEAP, lsl #32
    // 0x863e4c: cmp             w0, NULL
    // 0x863e50: b.eq            #0x863edc
    // 0x863e54: r2 = LoadClassIdInstr(r0)
    //     0x863e54: ldur            x2, [x0, #-1]
    //     0x863e58: ubfx            x2, x2, #0xc, #0x14
    // 0x863e5c: SaveReg r0
    //     0x863e5c: str             x0, [SP, #-8]!
    // 0x863e60: mov             x0, x2
    // 0x863e64: r0 = GDT[cid_x0 + -0x1000]()
    //     0x863e64: sub             lr, x0, #1, lsl #12
    //     0x863e68: ldr             lr, [x21, lr, lsl #3]
    //     0x863e6c: blr             lr
    // 0x863e70: add             SP, SP, #8
    // 0x863e74: mov             x1, x0
    // 0x863e78: ldr             x0, [fp, #0x10]
    // 0x863e7c: stur            x1, [fp, #-0x10]
    // 0x863e80: LoadField: r2 = r0->field_b
    //     0x863e80: ldur            w2, [x0, #0xb]
    // 0x863e84: DecompressPointer r2
    //     0x863e84: add             x2, x2, HEAP, lsl #32
    // 0x863e88: cmp             w2, NULL
    // 0x863e8c: b.eq            #0x863ee0
    // 0x863e90: LoadField: r0 = r2->field_7
    //     0x863e90: ldur            w0, [x2, #7]
    // 0x863e94: DecompressPointer r0
    //     0x863e94: add             x0, x0, HEAP, lsl #32
    // 0x863e98: stur            x0, [fp, #-8]
    // 0x863e9c: r0 = CupertinoActivityIndicator()
    //     0x863e9c: bl              #0x863ee4  ; AllocateCupertinoActivityIndicatorStub -> CupertinoActivityIndicator (size=0x24)
    // 0x863ea0: ldur            x1, [fp, #-0x10]
    // 0x863ea4: StoreField: r0->field_b = r1
    //     0x863ea4: stur            w1, [x0, #0xb]
    // 0x863ea8: r1 = true
    //     0x863ea8: add             x1, NULL, #0x20  ; true
    // 0x863eac: StoreField: r0->field_f = r1
    //     0x863eac: stur            w1, [x0, #0xf]
    // 0x863eb0: d0 = 10.000000
    //     0x863eb0: fmov            d0, #10.00000000
    // 0x863eb4: StoreField: r0->field_13 = d0
    //     0x863eb4: stur            d0, [x0, #0x13]
    // 0x863eb8: d0 = 1.000000
    //     0x863eb8: fmov            d0, #1.00000000
    // 0x863ebc: StoreField: r0->field_1b = d0
    //     0x863ebc: stur            d0, [x0, #0x1b]
    // 0x863ec0: ldur            x1, [fp, #-8]
    // 0x863ec4: StoreField: r0->field_7 = r1
    //     0x863ec4: stur            w1, [x0, #7]
    // 0x863ec8: LeaveFrame
    //     0x863ec8: mov             SP, fp
    //     0x863ecc: ldp             fp, lr, [SP], #0x10
    // 0x863ed0: ret
    //     0x863ed0: ret             
    // 0x863ed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863ed4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863ed8: b               #0x863e40
    // 0x863edc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x863edc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x863ee0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x863ee0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildAnimation(/* No info */) {
    // ** addr: 0x863ef0, size: 0x78
    // 0x863ef0: EnterFrame
    //     0x863ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x863ef4: mov             fp, SP
    // 0x863ef8: AllocStack(0x10)
    //     0x863ef8: sub             SP, SP, #0x10
    // 0x863efc: r1 = 1
    //     0x863efc: mov             x1, #1
    // 0x863f00: r0 = AllocateContext()
    //     0x863f00: bl              #0xd68aa4  ; AllocateContextStub
    // 0x863f04: mov             x1, x0
    // 0x863f08: ldr             x0, [fp, #0x10]
    // 0x863f0c: StoreField: r1->field_f = r0
    //     0x863f0c: stur            w0, [x1, #0xf]
    // 0x863f10: LoadField: r3 = r0->field_1b
    //     0x863f10: ldur            w3, [x0, #0x1b]
    // 0x863f14: DecompressPointer r3
    //     0x863f14: add             x3, x3, HEAP, lsl #32
    // 0x863f18: r16 = Sentinel
    //     0x863f18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x863f1c: cmp             w3, w16
    // 0x863f20: b.eq            #0x863f5c
    // 0x863f24: mov             x2, x1
    // 0x863f28: stur            x3, [fp, #-8]
    // 0x863f2c: r1 = Function '<anonymous closure>':.
    //     0x863f2c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cfc0] AnonymousClosure: (0x863f68), in [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildAnimation (0x863ef0)
    //     0x863f30: ldr             x1, [x1, #0xfc0]
    // 0x863f34: r0 = AllocateClosure()
    //     0x863f34: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x863f38: stur            x0, [fp, #-0x10]
    // 0x863f3c: r0 = AnimatedBuilder()
    //     0x863f3c: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x863f40: ldur            x1, [fp, #-0x10]
    // 0x863f44: StoreField: r0->field_f = r1
    //     0x863f44: stur            w1, [x0, #0xf]
    // 0x863f48: ldur            x1, [fp, #-8]
    // 0x863f4c: StoreField: r0->field_b = r1
    //     0x863f4c: stur            w1, [x0, #0xb]
    // 0x863f50: LeaveFrame
    //     0x863f50: mov             SP, fp
    //     0x863f54: ldp             fp, lr, [SP], #0x10
    // 0x863f58: ret
    //     0x863f58: ret             
    // 0x863f5c: r9 = _controller
    //     0x863f5c: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x863f60: ldr             x9, [x9, #0xfc8]
    // 0x863f64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x863f64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x863f68, size: 0x1f4
    // 0x863f68: EnterFrame
    //     0x863f68: stp             fp, lr, [SP, #-0x10]!
    //     0x863f6c: mov             fp, SP
    // 0x863f70: AllocStack(0x28)
    //     0x863f70: sub             SP, SP, #0x28
    // 0x863f74: SetupParameters()
    //     0x863f74: ldr             x0, [fp, #0x20]
    //     0x863f78: ldur            w1, [x0, #0x17]
    //     0x863f7c: add             x1, x1, HEAP, lsl #32
    //     0x863f80: stur            x1, [fp, #-0x10]
    // 0x863f84: CheckStackOverflow
    //     0x863f84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x863f88: cmp             SP, x16
    //     0x863f8c: b.ls            #0x864124
    // 0x863f90: LoadField: r0 = r1->field_f
    //     0x863f90: ldur            w0, [x1, #0xf]
    // 0x863f94: DecompressPointer r0
    //     0x863f94: add             x0, x0, HEAP, lsl #32
    // 0x863f98: stur            x0, [fp, #-8]
    // 0x863f9c: r0 = InitLateStaticField(0xe08) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_strokeHeadTween
    //     0x863f9c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x863fa0: ldr             x0, [x0, #0x1c10]
    //     0x863fa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x863fa8: cmp             w0, w16
    //     0x863fac: b.ne            #0x863fbc
    //     0x863fb0: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfd0] Field <_CircularProgressIndicatorState@793243954._strokeHeadTween@793243954>: static late final (offset: 0xe08)
    //     0x863fb4: ldr             x2, [x2, #0xfd0]
    //     0x863fb8: bl              #0xd67cdc
    // 0x863fbc: mov             x1, x0
    // 0x863fc0: ldur            x0, [fp, #-0x10]
    // 0x863fc4: LoadField: r2 = r0->field_f
    //     0x863fc4: ldur            w2, [x0, #0xf]
    // 0x863fc8: DecompressPointer r2
    //     0x863fc8: add             x2, x2, HEAP, lsl #32
    // 0x863fcc: LoadField: r3 = r2->field_1b
    //     0x863fcc: ldur            w3, [x2, #0x1b]
    // 0x863fd0: DecompressPointer r3
    //     0x863fd0: add             x3, x3, HEAP, lsl #32
    // 0x863fd4: r16 = Sentinel
    //     0x863fd4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x863fd8: cmp             w3, w16
    // 0x863fdc: b.eq            #0x86412c
    // 0x863fe0: stp             x3, x1, [SP, #-0x10]!
    // 0x863fe4: r0 = evaluate()
    //     0x863fe4: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x863fe8: add             SP, SP, #0x10
    // 0x863fec: stur            x0, [fp, #-0x18]
    // 0x863ff0: r0 = InitLateStaticField(0xe0c) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_strokeTailTween
    //     0x863ff0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x863ff4: ldr             x0, [x0, #0x1c18]
    //     0x863ff8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x863ffc: cmp             w0, w16
    //     0x864000: b.ne            #0x864010
    //     0x864004: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfd8] Field <_CircularProgressIndicatorState@793243954._strokeTailTween@793243954>: static late final (offset: 0xe0c)
    //     0x864008: ldr             x2, [x2, #0xfd8]
    //     0x86400c: bl              #0xd67cdc
    // 0x864010: mov             x1, x0
    // 0x864014: ldur            x0, [fp, #-0x10]
    // 0x864018: LoadField: r2 = r0->field_f
    //     0x864018: ldur            w2, [x0, #0xf]
    // 0x86401c: DecompressPointer r2
    //     0x86401c: add             x2, x2, HEAP, lsl #32
    // 0x864020: LoadField: r3 = r2->field_1b
    //     0x864020: ldur            w3, [x2, #0x1b]
    // 0x864024: DecompressPointer r3
    //     0x864024: add             x3, x3, HEAP, lsl #32
    // 0x864028: r16 = Sentinel
    //     0x864028: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x86402c: cmp             w3, w16
    // 0x864030: b.eq            #0x864138
    // 0x864034: stp             x3, x1, [SP, #-0x10]!
    // 0x864038: r0 = evaluate()
    //     0x864038: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x86403c: add             SP, SP, #0x10
    // 0x864040: stur            x0, [fp, #-0x20]
    // 0x864044: r0 = InitLateStaticField(0xe10) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_offsetTween
    //     0x864044: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x864048: ldr             x0, [x0, #0x1c20]
    //     0x86404c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x864050: cmp             w0, w16
    //     0x864054: b.ne            #0x864064
    //     0x864058: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfe0] Field <_CircularProgressIndicatorState@793243954._offsetTween@793243954>: static late final (offset: 0xe10)
    //     0x86405c: ldr             x2, [x2, #0xfe0]
    //     0x864060: bl              #0xd67cdc
    // 0x864064: mov             x1, x0
    // 0x864068: ldur            x0, [fp, #-0x10]
    // 0x86406c: LoadField: r2 = r0->field_f
    //     0x86406c: ldur            w2, [x0, #0xf]
    // 0x864070: DecompressPointer r2
    //     0x864070: add             x2, x2, HEAP, lsl #32
    // 0x864074: LoadField: r3 = r2->field_1b
    //     0x864074: ldur            w3, [x2, #0x1b]
    // 0x864078: DecompressPointer r3
    //     0x864078: add             x3, x3, HEAP, lsl #32
    // 0x86407c: r16 = Sentinel
    //     0x86407c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x864080: cmp             w3, w16
    // 0x864084: b.eq            #0x864144
    // 0x864088: stp             x3, x1, [SP, #-0x10]!
    // 0x86408c: r0 = evaluate()
    //     0x86408c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x864090: add             SP, SP, #0x10
    // 0x864094: stur            x0, [fp, #-0x28]
    // 0x864098: r0 = InitLateStaticField(0xe14) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_rotationTween
    //     0x864098: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x86409c: ldr             x0, [x0, #0x1c28]
    //     0x8640a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8640a4: cmp             w0, w16
    //     0x8640a8: b.ne            #0x8640b8
    //     0x8640ac: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfe8] Field <_CircularProgressIndicatorState@793243954._rotationTween@793243954>: static late final (offset: 0xe14)
    //     0x8640b0: ldr             x2, [x2, #0xfe8]
    //     0x8640b4: bl              #0xd67cdc
    // 0x8640b8: mov             x1, x0
    // 0x8640bc: ldur            x0, [fp, #-0x10]
    // 0x8640c0: LoadField: r2 = r0->field_f
    //     0x8640c0: ldur            w2, [x0, #0xf]
    // 0x8640c4: DecompressPointer r2
    //     0x8640c4: add             x2, x2, HEAP, lsl #32
    // 0x8640c8: LoadField: r0 = r2->field_1b
    //     0x8640c8: ldur            w0, [x2, #0x1b]
    // 0x8640cc: DecompressPointer r0
    //     0x8640cc: add             x0, x0, HEAP, lsl #32
    // 0x8640d0: r16 = Sentinel
    //     0x8640d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8640d4: cmp             w0, w16
    // 0x8640d8: b.eq            #0x864150
    // 0x8640dc: stp             x0, x1, [SP, #-0x10]!
    // 0x8640e0: r0 = evaluate()
    //     0x8640e0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x8640e4: add             SP, SP, #0x10
    // 0x8640e8: LoadField: d0 = r0->field_7
    //     0x8640e8: ldur            d0, [x0, #7]
    // 0x8640ec: ldur            x16, [fp, #-8]
    // 0x8640f0: ldr             lr, [fp, #0x18]
    // 0x8640f4: stp             lr, x16, [SP, #-0x10]!
    // 0x8640f8: ldur            x16, [fp, #-0x18]
    // 0x8640fc: ldur            lr, [fp, #-0x20]
    // 0x864100: stp             lr, x16, [SP, #-0x10]!
    // 0x864104: ldur            x16, [fp, #-0x28]
    // 0x864108: SaveReg r16
    //     0x864108: str             x16, [SP, #-8]!
    // 0x86410c: SaveReg d0
    //     0x86410c: str             d0, [SP, #-8]!
    // 0x864110: r0 = _buildMaterialIndicator()
    //     0x864110: bl              #0x86415c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_buildMaterialIndicator
    // 0x864114: add             SP, SP, #0x30
    // 0x864118: LeaveFrame
    //     0x864118: mov             SP, fp
    //     0x86411c: ldp             fp, lr, [SP], #0x10
    // 0x864120: ret
    //     0x864120: ret             
    // 0x864124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x864124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x864128: b               #0x863f90
    // 0x86412c: r9 = _controller
    //     0x86412c: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x864130: ldr             x9, [x9, #0xfc8]
    // 0x864134: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864134: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864138: r9 = _controller
    //     0x864138: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x86413c: ldr             x9, [x9, #0xfc8]
    // 0x864140: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864140: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864144: r9 = _controller
    //     0x864144: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x864148: ldr             x9, [x9, #0xfc8]
    // 0x86414c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x86414c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x864150: r9 = _controller
    //     0x864150: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x864154: ldr             x9, [x9, #0xfc8]
    // 0x864158: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x864158: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildMaterialIndicator(/* No info */) {
    // ** addr: 0x86415c, size: 0x2f4
    // 0x86415c: EnterFrame
    //     0x86415c: stp             fp, lr, [SP, #-0x10]!
    //     0x864160: mov             fp, SP
    // 0x864164: AllocStack(0x40)
    //     0x864164: sub             SP, SP, #0x40
    // 0x864168: CheckStackOverflow
    //     0x864168: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86416c: cmp             SP, x16
    //     0x864170: b.ls            #0x8643f4
    // 0x864174: ldr             x16, [fp, #0x30]
    // 0x864178: SaveReg r16
    //     0x864178: str             x16, [SP, #-8]!
    // 0x86417c: r0 = of()
    //     0x86417c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x864180: add             SP, SP, #8
    // 0x864184: LoadField: r1 = r0->field_2b
    //     0x864184: ldur            w1, [x0, #0x2b]
    // 0x864188: DecompressPointer r1
    //     0x864188: add             x1, x1, HEAP, lsl #32
    // 0x86418c: tbnz            w1, #4, #0x8641b4
    // 0x864190: ldr             x0, [fp, #0x30]
    // 0x864194: r0 = _CircularProgressIndicatorDefaultsM3()
    //     0x864194: bl              #0x864468  ; Allocate_CircularProgressIndicatorDefaultsM3Stub -> _CircularProgressIndicatorDefaultsM3 (size=0x24)
    // 0x864198: mov             x1, x0
    // 0x86419c: r0 = Sentinel
    //     0x86419c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8641a0: StoreField: r1->field_1f = r0
    //     0x8641a0: stur            w0, [x1, #0x1f]
    // 0x8641a4: ldr             x2, [fp, #0x30]
    // 0x8641a8: StoreField: r1->field_1b = r2
    //     0x8641a8: stur            w2, [x1, #0x1b]
    // 0x8641ac: mov             x3, x1
    // 0x8641b0: b               #0x8641d8
    // 0x8641b4: ldr             x2, [fp, #0x30]
    // 0x8641b8: r0 = Sentinel
    //     0x8641b8: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8641bc: r0 = _CircularProgressIndicatorDefaultsM2()
    //     0x8641bc: bl              #0x86445c  ; Allocate_CircularProgressIndicatorDefaultsM2Stub -> _CircularProgressIndicatorDefaultsM2 (size=0x24)
    // 0x8641c0: mov             x1, x0
    // 0x8641c4: r0 = Sentinel
    //     0x8641c4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8641c8: StoreField: r1->field_1f = r0
    //     0x8641c8: stur            w0, [x1, #0x1f]
    // 0x8641cc: ldr             x2, [fp, #0x30]
    // 0x8641d0: StoreField: r1->field_1b = r2
    //     0x8641d0: stur            w2, [x1, #0x1b]
    // 0x8641d4: mov             x3, x1
    // 0x8641d8: ldr             x1, [fp, #0x38]
    // 0x8641dc: stur            x3, [fp, #-8]
    // 0x8641e0: LoadField: r0 = r1->field_b
    //     0x8641e0: ldur            w0, [x1, #0xb]
    // 0x8641e4: DecompressPointer r0
    //     0x8641e4: add             x0, x0, HEAP, lsl #32
    // 0x8641e8: cmp             w0, NULL
    // 0x8641ec: b.eq            #0x8643fc
    // 0x8641f0: r4 = LoadClassIdInstr(r0)
    //     0x8641f0: ldur            x4, [x0, #-1]
    //     0x8641f4: ubfx            x4, x4, #0xc, #0x14
    // 0x8641f8: SaveReg r0
    //     0x8641f8: str             x0, [SP, #-8]!
    // 0x8641fc: mov             x0, x4
    // 0x864200: r0 = GDT[cid_x0 + -0x1000]()
    //     0x864200: sub             lr, x0, #1, lsl #12
    //     0x864204: ldr             lr, [x21, lr, lsl #3]
    //     0x864208: blr             lr
    // 0x86420c: add             SP, SP, #8
    // 0x864210: cmp             w0, NULL
    // 0x864214: b.ne            #0x864230
    // 0x864218: ldr             x16, [fp, #0x30]
    // 0x86421c: SaveReg r16
    //     0x86421c: str             x16, [SP, #-8]!
    // 0x864220: r0 = of()
    //     0x864220: bl              #0x862a5c  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0x864224: add             SP, SP, #8
    // 0x864228: r3 = Null
    //     0x864228: mov             x3, NULL
    // 0x86422c: b               #0x864234
    // 0x864230: mov             x3, x0
    // 0x864234: ldr             x1, [fp, #0x38]
    // 0x864238: ldr             x2, [fp, #0x20]
    // 0x86423c: ldr             d0, [fp, #0x10]
    // 0x864240: ldur            x0, [fp, #-8]
    // 0x864244: stur            x3, [fp, #-0x18]
    // 0x864248: LoadField: r4 = r1->field_b
    //     0x864248: ldur            w4, [x1, #0xb]
    // 0x86424c: DecompressPointer r4
    //     0x86424c: add             x4, x4, HEAP, lsl #32
    // 0x864250: stur            x4, [fp, #-0x10]
    // 0x864254: cmp             w4, NULL
    // 0x864258: b.eq            #0x864400
    // 0x86425c: r5 = LoadClassIdInstr(r0)
    //     0x86425c: ldur            x5, [x0, #-1]
    //     0x864260: ubfx            x5, x5, #0xc, #0x14
    // 0x864264: SaveReg r0
    //     0x864264: str             x0, [SP, #-8]!
    // 0x864268: mov             x0, x5
    // 0x86426c: r0 = GDT[cid_x0 + -0xe43]()
    //     0x86426c: sub             lr, x0, #0xe43
    //     0x864270: ldr             lr, [x21, lr, lsl #3]
    //     0x864274: blr             lr
    // 0x864278: add             SP, SP, #8
    // 0x86427c: ldur            x16, [fp, #-0x10]
    // 0x864280: ldr             lr, [fp, #0x30]
    // 0x864284: stp             lr, x16, [SP, #-0x10]!
    // 0x864288: SaveReg r0
    //     0x864288: str             x0, [SP, #-8]!
    // 0x86428c: r4 = const [0, 0x3, 0x3, 0x2, defaultColor, 0x2, null]
    //     0x86428c: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d010] List(7) [0, 0x3, 0x3, 0x2, "defaultColor", 0x2, Null]
    //     0x864290: ldr             x4, [x4, #0x10]
    // 0x864294: r0 = _getValueColor()
    //     0x864294: bl              #0x86292c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_getValueColor
    // 0x864298: add             SP, SP, #0x18
    // 0x86429c: mov             x1, x0
    // 0x8642a0: ldr             x0, [fp, #0x38]
    // 0x8642a4: stur            x1, [fp, #-0x30]
    // 0x8642a8: LoadField: r2 = r0->field_b
    //     0x8642a8: ldur            w2, [x0, #0xb]
    // 0x8642ac: DecompressPointer r2
    //     0x8642ac: add             x2, x2, HEAP, lsl #32
    // 0x8642b0: cmp             w2, NULL
    // 0x8642b4: b.eq            #0x864404
    // 0x8642b8: LoadField: r0 = r2->field_b
    //     0x8642b8: ldur            w0, [x2, #0xb]
    // 0x8642bc: DecompressPointer r0
    //     0x8642bc: add             x0, x0, HEAP, lsl #32
    // 0x8642c0: stur            x0, [fp, #-0x28]
    // 0x8642c4: LoadField: d0 = r2->field_27
    //     0x8642c4: ldur            d0, [x2, #0x27]
    // 0x8642c8: ldr             x2, [fp, #0x20]
    // 0x8642cc: LoadField: d1 = r2->field_7
    //     0x8642cc: ldur            d1, [x2, #7]
    // 0x8642d0: ldr             d2, [fp, #0x10]
    // 0x8642d4: stur            d1, [fp, #-0x40]
    // 0x8642d8: r2 = inline_Allocate_Double()
    //     0x8642d8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8642dc: add             x2, x2, #0x10
    //     0x8642e0: cmp             x3, x2
    //     0x8642e4: b.ls            #0x864408
    //     0x8642e8: str             x2, [THR, #0x60]  ; THR::top
    //     0x8642ec: sub             x2, x2, #0xf
    //     0x8642f0: mov             x3, #0xd108
    //     0x8642f4: movk            x3, #3, lsl #16
    //     0x8642f8: stur            x3, [x2, #-1]
    // 0x8642fc: StoreField: r2->field_7 = d2
    //     0x8642fc: stur            d2, [x2, #7]
    // 0x864300: stur            x2, [fp, #-0x20]
    // 0x864304: r3 = inline_Allocate_Double()
    //     0x864304: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x864308: add             x3, x3, #0x10
    //     0x86430c: cmp             x4, x3
    //     0x864310: b.ls            #0x86442c
    //     0x864314: str             x3, [THR, #0x60]  ; THR::top
    //     0x864318: sub             x3, x3, #0xf
    //     0x86431c: mov             x4, #0xd108
    //     0x864320: movk            x4, #3, lsl #16
    //     0x864324: stur            x4, [x3, #-1]
    // 0x864328: StoreField: r3->field_7 = d0
    //     0x864328: stur            d0, [x3, #7]
    // 0x86432c: stur            x3, [fp, #-8]
    // 0x864330: r0 = _CircularProgressIndicatorPainter()
    //     0x864330: bl              #0x864450  ; Allocate_CircularProgressIndicatorPainterStub -> _CircularProgressIndicatorPainter (size=0x50)
    // 0x864334: stur            x0, [fp, #-0x38]
    // 0x864338: ldr             x16, [fp, #0x28]
    // 0x86433c: stp             x16, x0, [SP, #-0x10]!
    // 0x864340: ldr             x16, [fp, #0x18]
    // 0x864344: ldur            lr, [fp, #-0x20]
    // 0x864348: stp             lr, x16, [SP, #-0x10]!
    // 0x86434c: ldur            x16, [fp, #-8]
    // 0x864350: SaveReg r16
    //     0x864350: str             x16, [SP, #-8]!
    // 0x864354: ldur            d0, [fp, #-0x40]
    // 0x864358: SaveReg d0
    //     0x864358: str             d0, [SP, #-8]!
    // 0x86435c: ldur            x16, [fp, #-0x28]
    // 0x864360: ldur            lr, [fp, #-0x30]
    // 0x864364: stp             lr, x16, [SP, #-0x10]!
    // 0x864368: ldur            x16, [fp, #-0x18]
    // 0x86436c: SaveReg r16
    //     0x86436c: str             x16, [SP, #-8]!
    // 0x864370: r4 = const [0, 0x9, 0x9, 0x8, backgroundColor, 0x8, null]
    //     0x864370: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d018] List(7) [0, 0x9, 0x9, 0x8, "backgroundColor", 0x8, Null]
    //     0x864374: ldr             x4, [x4, #0x18]
    // 0x864378: r0 = _CircularProgressIndicatorPainter()
    //     0x864378: bl              #0x86374c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorPainter::_CircularProgressIndicatorPainter
    // 0x86437c: add             SP, SP, #0x48
    // 0x864380: r0 = CustomPaint()
    //     0x864380: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x864384: mov             x1, x0
    // 0x864388: ldur            x0, [fp, #-0x38]
    // 0x86438c: stur            x1, [fp, #-8]
    // 0x864390: StoreField: r1->field_f = r0
    //     0x864390: stur            w0, [x1, #0xf]
    // 0x864394: r0 = Instance_Size
    //     0x864394: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x864398: StoreField: r1->field_17 = r0
    //     0x864398: stur            w0, [x1, #0x17]
    // 0x86439c: r0 = false
    //     0x86439c: add             x0, NULL, #0x30  ; false
    // 0x8643a0: StoreField: r1->field_1b = r0
    //     0x8643a0: stur            w0, [x1, #0x1b]
    // 0x8643a4: StoreField: r1->field_1f = r0
    //     0x8643a4: stur            w0, [x1, #0x1f]
    // 0x8643a8: r0 = Container()
    //     0x8643a8: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x8643ac: stur            x0, [fp, #-0x18]
    // 0x8643b0: r16 = Instance_BoxConstraints
    //     0x8643b0: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d020] Obj!BoxConstraints@b35411
    //     0x8643b4: ldr             x16, [x16, #0x20]
    // 0x8643b8: stp             x16, x0, [SP, #-0x10]!
    // 0x8643bc: ldur            x16, [fp, #-8]
    // 0x8643c0: SaveReg r16
    //     0x8643c0: str             x16, [SP, #-8]!
    // 0x8643c4: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, constraints, 0x1, null]
    //     0x8643c4: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d028] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "constraints", 0x1, Null]
    //     0x8643c8: ldr             x4, [x4, #0x28]
    // 0x8643cc: r0 = Container()
    //     0x8643cc: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8643d0: add             SP, SP, #0x18
    // 0x8643d4: ldur            x16, [fp, #-0x10]
    // 0x8643d8: ldur            lr, [fp, #-0x18]
    // 0x8643dc: stp             lr, x16, [SP, #-0x10]!
    // 0x8643e0: r0 = _buildSemanticsWrapper()
    //     0x8643e0: bl              #0x8627e0  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_buildSemanticsWrapper
    // 0x8643e4: add             SP, SP, #0x10
    // 0x8643e8: LeaveFrame
    //     0x8643e8: mov             SP, fp
    //     0x8643ec: ldp             fp, lr, [SP], #0x10
    // 0x8643f0: ret
    //     0x8643f0: ret             
    // 0x8643f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8643f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8643f8: b               #0x864174
    // 0x8643fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8643fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x864400: r0 = NullCastErrorSharedWithFPURegs()
    //     0x864400: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x864404: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x864404: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x864408: stp             q1, q2, [SP, #-0x20]!
    // 0x86440c: SaveReg d0
    //     0x86440c: str             q0, [SP, #-0x10]!
    // 0x864410: stp             x0, x1, [SP, #-0x10]!
    // 0x864414: r0 = AllocateDouble()
    //     0x864414: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x864418: mov             x2, x0
    // 0x86441c: ldp             x0, x1, [SP], #0x10
    // 0x864420: RestoreReg d0
    //     0x864420: ldr             q0, [SP], #0x10
    // 0x864424: ldp             q1, q2, [SP], #0x20
    // 0x864428: b               #0x8642fc
    // 0x86442c: stp             q0, q1, [SP, #-0x20]!
    // 0x864430: stp             x1, x2, [SP, #-0x10]!
    // 0x864434: SaveReg r0
    //     0x864434: str             x0, [SP, #-8]!
    // 0x864438: r0 = AllocateDouble()
    //     0x864438: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x86443c: mov             x3, x0
    // 0x864440: RestoreReg r0
    //     0x864440: ldr             x0, [SP], #8
    // 0x864444: ldp             x1, x2, [SP], #0x10
    // 0x864448: ldp             q0, q1, [SP], #0x20
    // 0x86444c: b               #0x864328
  }
  _ initState(/* No info */) {
    // ** addr: 0x9db14c, size: 0xbc
    // 0x9db14c: EnterFrame
    //     0x9db14c: stp             fp, lr, [SP, #-0x10]!
    //     0x9db150: mov             fp, SP
    // 0x9db154: AllocStack(0x8)
    //     0x9db154: sub             SP, SP, #8
    // 0x9db158: CheckStackOverflow
    //     0x9db158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db15c: cmp             SP, x16
    //     0x9db160: b.ls            #0x9db1fc
    // 0x9db164: r1 = <double>
    //     0x9db164: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db168: r0 = AnimationController()
    //     0x9db168: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db16c: stur            x0, [fp, #-8]
    // 0x9db170: ldr             x16, [fp, #0x10]
    // 0x9db174: stp             x16, x0, [SP, #-0x10]!
    // 0x9db178: r16 = Instance_Duration
    //     0x9db178: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d098] Obj!Duration@b67ca1
    //     0x9db17c: ldr             x16, [x16, #0x98]
    // 0x9db180: SaveReg r16
    //     0x9db180: str             x16, [SP, #-8]!
    // 0x9db184: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db184: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db188: ldr             x4, [x4, #0xa0]
    // 0x9db18c: r0 = AnimationController()
    //     0x9db18c: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db190: add             SP, SP, #0x18
    // 0x9db194: ldur            x0, [fp, #-8]
    // 0x9db198: ldr             x1, [fp, #0x10]
    // 0x9db19c: StoreField: r1->field_1b = r0
    //     0x9db19c: stur            w0, [x1, #0x1b]
    //     0x9db1a0: ldurb           w16, [x1, #-1]
    //     0x9db1a4: ldurb           w17, [x0, #-1]
    //     0x9db1a8: and             x16, x17, x16, lsr #2
    //     0x9db1ac: tst             x16, HEAP, lsr #32
    //     0x9db1b0: b.eq            #0x9db1b8
    //     0x9db1b4: bl              #0xd6826c
    // 0x9db1b8: LoadField: r0 = r1->field_b
    //     0x9db1b8: ldur            w0, [x1, #0xb]
    // 0x9db1bc: DecompressPointer r0
    //     0x9db1bc: add             x0, x0, HEAP, lsl #32
    // 0x9db1c0: cmp             w0, NULL
    // 0x9db1c4: b.eq            #0x9db204
    // 0x9db1c8: LoadField: r1 = r0->field_b
    //     0x9db1c8: ldur            w1, [x0, #0xb]
    // 0x9db1cc: DecompressPointer r1
    //     0x9db1cc: add             x1, x1, HEAP, lsl #32
    // 0x9db1d0: cmp             w1, NULL
    // 0x9db1d4: b.ne            #0x9db1ec
    // 0x9db1d8: ldur            x16, [fp, #-8]
    // 0x9db1dc: SaveReg r16
    //     0x9db1dc: str             x16, [SP, #-8]!
    // 0x9db1e0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9db1e0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9db1e4: r0 = repeat()
    //     0x9db1e4: bl              #0x7b8ecc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9db1e8: add             SP, SP, #8
    // 0x9db1ec: r0 = Null
    //     0x9db1ec: mov             x0, NULL
    // 0x9db1f0: LeaveFrame
    //     0x9db1f0: mov             SP, fp
    //     0x9db1f4: ldp             fp, lr, [SP], #0x10
    // 0x9db1f8: ret
    //     0x9db1f8: ret             
    // 0x9db1fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db1fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db200: b               #0x9db164
    // 0x9db204: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db204: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4afa8, size: 0x18
    // 0xa4afa8: r4 = 7
    //     0xa4afa8: mov             x4, #7
    // 0xa4afac: r1 = Function 'dispose':.
    //     0xa4afac: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b638] AnonymousClosure: (0xa4afc0), in [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::dispose (0xa5242c)
    //     0xa4afb0: ldr             x1, [x17, #0x638]
    // 0xa4afb4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4afb4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4afb8: LoadField: r0 = r24->field_17
    //     0xa4afb8: ldur            x0, [x24, #0x17]
    // 0xa4afbc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4afc0, size: 0x48
    // 0xa4afc0: EnterFrame
    //     0xa4afc0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4afc4: mov             fp, SP
    // 0xa4afc8: ldr             x0, [fp, #0x10]
    // 0xa4afcc: LoadField: r1 = r0->field_17
    //     0xa4afcc: ldur            w1, [x0, #0x17]
    // 0xa4afd0: DecompressPointer r1
    //     0xa4afd0: add             x1, x1, HEAP, lsl #32
    // 0xa4afd4: CheckStackOverflow
    //     0xa4afd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4afd8: cmp             SP, x16
    //     0xa4afdc: b.ls            #0xa4b000
    // 0xa4afe0: LoadField: r0 = r1->field_f
    //     0xa4afe0: ldur            w0, [x1, #0xf]
    // 0xa4afe4: DecompressPointer r0
    //     0xa4afe4: add             x0, x0, HEAP, lsl #32
    // 0xa4afe8: SaveReg r0
    //     0xa4afe8: str             x0, [SP, #-8]!
    // 0xa4afec: r0 = dispose()
    //     0xa4afec: bl              #0xa5242c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::dispose
    // 0xa4aff0: add             SP, SP, #8
    // 0xa4aff4: LeaveFrame
    //     0xa4aff4: mov             SP, fp
    //     0xa4aff8: ldp             fp, lr, [SP], #0x10
    // 0xa4affc: ret
    //     0xa4affc: ret             
    // 0xa4b000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b004: b               #0xa4afe0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa5242c, size: 0x6c
    // 0xa5242c: EnterFrame
    //     0xa5242c: stp             fp, lr, [SP, #-0x10]!
    //     0xa52430: mov             fp, SP
    // 0xa52434: CheckStackOverflow
    //     0xa52434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52438: cmp             SP, x16
    //     0xa5243c: b.ls            #0xa52484
    // 0xa52440: ldr             x0, [fp, #0x10]
    // 0xa52444: LoadField: r1 = r0->field_1b
    //     0xa52444: ldur            w1, [x0, #0x1b]
    // 0xa52448: DecompressPointer r1
    //     0xa52448: add             x1, x1, HEAP, lsl #32
    // 0xa5244c: r16 = Sentinel
    //     0xa5244c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52450: cmp             w1, w16
    // 0xa52454: b.eq            #0xa5248c
    // 0xa52458: SaveReg r1
    //     0xa52458: str             x1, [SP, #-8]!
    // 0xa5245c: r0 = dispose()
    //     0xa5245c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa52460: add             SP, SP, #8
    // 0xa52464: ldr             x16, [fp, #0x10]
    // 0xa52468: SaveReg r16
    //     0xa52468: str             x16, [SP, #-8]!
    // 0xa5246c: r0 = dispose()
    //     0xa5246c: bl              #0xa52498  ; [package:flutter/src/material/progress_indicator.dart] __CircularProgressIndicatorState&State&SingleTickerProviderStateMixin::dispose
    // 0xa52470: add             SP, SP, #8
    // 0xa52474: r0 = Null
    //     0xa52474: mov             x0, NULL
    // 0xa52478: LeaveFrame
    //     0xa52478: mov             SP, fp
    //     0xa5247c: ldp             fp, lr, [SP], #0x10
    // 0xa52480: ret
    //     0xa52480: ret             
    // 0xa52484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52488: b               #0xa52440
    // 0xa5248c: r9 = _controller
    //     0xa5248c: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0xa52490: ldr             x9, [x9, #0xfc8]
    // 0xa52494: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52494: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3288, size: 0x2c, field offset: 0x20
class _RefreshProgressIndicatorState extends _CircularProgressIndicatorState {

  late final Animatable<double> _convertTween; // offset: 0x20
  late final Animatable<double> _additionalRotationTween; // offset: 0x24

  _ build(/* No info */) {
    // ** addr: 0x862b78, size: 0x110
    // 0x862b78: EnterFrame
    //     0x862b78: stp             fp, lr, [SP, #-0x10]!
    //     0x862b7c: mov             fp, SP
    // 0x862b80: AllocStack(0x10)
    //     0x862b80: sub             SP, SP, #0x10
    // 0x862b84: CheckStackOverflow
    //     0x862b84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x862b88: cmp             SP, x16
    //     0x862b8c: b.ls            #0x862c70
    // 0x862b90: ldr             x2, [fp, #0x18]
    // 0x862b94: LoadField: r0 = r2->field_b
    //     0x862b94: ldur            w0, [x2, #0xb]
    // 0x862b98: DecompressPointer r0
    //     0x862b98: add             x0, x0, HEAP, lsl #32
    // 0x862b9c: cmp             w0, NULL
    // 0x862ba0: b.eq            #0x862c78
    // 0x862ba4: LoadField: r3 = r0->field_b
    //     0x862ba4: ldur            w3, [x0, #0xb]
    // 0x862ba8: DecompressPointer r3
    //     0x862ba8: add             x3, x3, HEAP, lsl #32
    // 0x862bac: stur            x3, [fp, #-0x10]
    // 0x862bb0: cmp             w3, NULL
    // 0x862bb4: b.eq            #0x862c54
    // 0x862bb8: mov             x0, x3
    // 0x862bbc: StoreField: r2->field_27 = r0
    //     0x862bbc: stur            w0, [x2, #0x27]
    //     0x862bc0: ldurb           w16, [x2, #-1]
    //     0x862bc4: ldurb           w17, [x0, #-1]
    //     0x862bc8: and             x16, x17, x16, lsr #2
    //     0x862bcc: tst             x16, HEAP, lsr #32
    //     0x862bd0: b.eq            #0x862bd8
    //     0x862bd4: bl              #0xd6828c
    // 0x862bd8: LoadField: r0 = r2->field_1b
    //     0x862bd8: ldur            w0, [x2, #0x1b]
    // 0x862bdc: DecompressPointer r0
    //     0x862bdc: add             x0, x0, HEAP, lsl #32
    // 0x862be0: r16 = Sentinel
    //     0x862be0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862be4: cmp             w0, w16
    // 0x862be8: b.eq            #0x862c7c
    // 0x862bec: mov             x1, x2
    // 0x862bf0: stur            x0, [fp, #-8]
    // 0x862bf4: LoadField: r0 = r1->field_1f
    //     0x862bf4: ldur            w0, [x1, #0x1f]
    // 0x862bf8: DecompressPointer r0
    //     0x862bf8: add             x0, x0, HEAP, lsl #32
    // 0x862bfc: r16 = Sentinel
    //     0x862bfc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862c00: cmp             w0, w16
    // 0x862c04: b.ne            #0x862c14
    // 0x862c08: r2 = _convertTween
    //     0x862c08: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b5d0] Field <_RefreshProgressIndicatorState@793243954._convertTween@793243954>: late final (offset: 0x20)
    //     0x862c0c: ldr             x2, [x2, #0x5d0]
    // 0x862c10: r0 = InitLateFinalInstanceField()
    //     0x862c10: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x862c14: mov             x1, x0
    // 0x862c18: ldur            x0, [fp, #-0x10]
    // 0x862c1c: LoadField: d0 = r0->field_7
    //     0x862c1c: ldur            d0, [x0, #7]
    // 0x862c20: SaveReg r1
    //     0x862c20: str             x1, [SP, #-8]!
    // 0x862c24: SaveReg d0
    //     0x862c24: str             d0, [SP, #-8]!
    // 0x862c28: r0 = transform()
    //     0x862c28: bl              #0xc09e58  ; [package:flutter/src/animation/tween.dart] CurveTween::transform
    // 0x862c2c: add             SP, SP, #0x10
    // 0x862c30: LoadField: d0 = r0->field_7
    //     0x862c30: ldur            d0, [x0, #7]
    // 0x862c34: d1 = 0.000225
    //     0x862c34: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b5d8] IMM: double(0.000225022502250225) from 0x3f2d7e80937882e1
    //     0x862c38: ldr             d1, [x17, #0x5d8]
    // 0x862c3c: fmul            d2, d0, d1
    // 0x862c40: ldur            x16, [fp, #-8]
    // 0x862c44: SaveReg r16
    //     0x862c44: str             x16, [SP, #-8]!
    // 0x862c48: SaveReg d2
    //     0x862c48: str             d2, [SP, #-8]!
    // 0x862c4c: r0 = value=()
    //     0x862c4c: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x862c50: add             SP, SP, #0x10
    // 0x862c54: ldr             x16, [fp, #0x18]
    // 0x862c58: SaveReg r16
    //     0x862c58: str             x16, [SP, #-8]!
    // 0x862c5c: r0 = _buildAnimation()
    //     0x862c5c: bl              #0x862c88  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorState::_buildAnimation
    // 0x862c60: add             SP, SP, #8
    // 0x862c64: LeaveFrame
    //     0x862c64: mov             SP, fp
    //     0x862c68: ldp             fp, lr, [SP], #0x10
    // 0x862c6c: ret
    //     0x862c6c: ret             
    // 0x862c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862c70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862c74: b               #0x862b90
    // 0x862c78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x862c78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x862c7c: r9 = _controller
    //     0x862c7c: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862c80: ldr             x9, [x9, #0xfc8]
    // 0x862c84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862c84: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildAnimation(/* No info */) {
    // ** addr: 0x862c88, size: 0x78
    // 0x862c88: EnterFrame
    //     0x862c88: stp             fp, lr, [SP, #-0x10]!
    //     0x862c8c: mov             fp, SP
    // 0x862c90: AllocStack(0x10)
    //     0x862c90: sub             SP, SP, #0x10
    // 0x862c94: r1 = 1
    //     0x862c94: mov             x1, #1
    // 0x862c98: r0 = AllocateContext()
    //     0x862c98: bl              #0xd68aa4  ; AllocateContextStub
    // 0x862c9c: mov             x1, x0
    // 0x862ca0: ldr             x0, [fp, #0x10]
    // 0x862ca4: StoreField: r1->field_f = r0
    //     0x862ca4: stur            w0, [x1, #0xf]
    // 0x862ca8: LoadField: r3 = r0->field_1b
    //     0x862ca8: ldur            w3, [x0, #0x1b]
    // 0x862cac: DecompressPointer r3
    //     0x862cac: add             x3, x3, HEAP, lsl #32
    // 0x862cb0: r16 = Sentinel
    //     0x862cb0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862cb4: cmp             w3, w16
    // 0x862cb8: b.eq            #0x862cf4
    // 0x862cbc: mov             x2, x1
    // 0x862cc0: stur            x3, [fp, #-8]
    // 0x862cc4: r1 = Function '<anonymous closure>':.
    //     0x862cc4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b5e8] AnonymousClosure: (0x862d00), in [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorState::_buildAnimation (0x862c88)
    //     0x862cc8: ldr             x1, [x1, #0x5e8]
    // 0x862ccc: r0 = AllocateClosure()
    //     0x862ccc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x862cd0: stur            x0, [fp, #-0x10]
    // 0x862cd4: r0 = AnimatedBuilder()
    //     0x862cd4: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x862cd8: ldur            x1, [fp, #-0x10]
    // 0x862cdc: StoreField: r0->field_f = r1
    //     0x862cdc: stur            w1, [x0, #0xf]
    // 0x862ce0: ldur            x1, [fp, #-8]
    // 0x862ce4: StoreField: r0->field_b = r1
    //     0x862ce4: stur            w1, [x0, #0xb]
    // 0x862ce8: LeaveFrame
    //     0x862ce8: mov             SP, fp
    //     0x862cec: ldp             fp, lr, [SP], #0x10
    // 0x862cf0: ret
    //     0x862cf0: ret             
    // 0x862cf4: r9 = _controller
    //     0x862cf4: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862cf8: ldr             x9, [x9, #0xfc8]
    // 0x862cfc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862cfc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x862d00, size: 0x248
    // 0x862d00: EnterFrame
    //     0x862d00: stp             fp, lr, [SP, #-0x10]!
    //     0x862d04: mov             fp, SP
    // 0x862d08: AllocStack(0x28)
    //     0x862d08: sub             SP, SP, #0x28
    // 0x862d0c: SetupParameters()
    //     0x862d0c: ldr             x0, [fp, #0x20]
    //     0x862d10: ldur            w1, [x0, #0x17]
    //     0x862d14: add             x1, x1, HEAP, lsl #32
    //     0x862d18: stur            x1, [fp, #-0x10]
    // 0x862d1c: CheckStackOverflow
    //     0x862d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x862d20: cmp             SP, x16
    //     0x862d24: b.ls            #0x862ef4
    // 0x862d28: LoadField: r0 = r1->field_f
    //     0x862d28: ldur            w0, [x1, #0xf]
    // 0x862d2c: DecompressPointer r0
    //     0x862d2c: add             x0, x0, HEAP, lsl #32
    // 0x862d30: stur            x0, [fp, #-8]
    // 0x862d34: r0 = InitLateStaticField(0xe08) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_strokeHeadTween
    //     0x862d34: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x862d38: ldr             x0, [x0, #0x1c10]
    //     0x862d3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x862d40: cmp             w0, w16
    //     0x862d44: b.ne            #0x862d54
    //     0x862d48: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfd0] Field <_CircularProgressIndicatorState@793243954._strokeHeadTween@793243954>: static late final (offset: 0xe08)
    //     0x862d4c: ldr             x2, [x2, #0xfd0]
    //     0x862d50: bl              #0xd67cdc
    // 0x862d54: mov             x1, x0
    // 0x862d58: ldur            x0, [fp, #-0x10]
    // 0x862d5c: LoadField: r2 = r0->field_f
    //     0x862d5c: ldur            w2, [x0, #0xf]
    // 0x862d60: DecompressPointer r2
    //     0x862d60: add             x2, x2, HEAP, lsl #32
    // 0x862d64: LoadField: r3 = r2->field_1b
    //     0x862d64: ldur            w3, [x2, #0x1b]
    // 0x862d68: DecompressPointer r3
    //     0x862d68: add             x3, x3, HEAP, lsl #32
    // 0x862d6c: r16 = Sentinel
    //     0x862d6c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862d70: cmp             w3, w16
    // 0x862d74: b.eq            #0x862efc
    // 0x862d78: stp             x3, x1, [SP, #-0x10]!
    // 0x862d7c: r0 = evaluate()
    //     0x862d7c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x862d80: add             SP, SP, #0x10
    // 0x862d84: LoadField: d0 = r0->field_7
    //     0x862d84: ldur            d0, [x0, #7]
    // 0x862d88: d1 = 1.050000
    //     0x862d88: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e7b8] IMM: double(1.05) from 0x3ff0cccccccccccd
    //     0x862d8c: ldr             d1, [x17, #0x7b8]
    // 0x862d90: fmul            d2, d1, d0
    // 0x862d94: stur            d2, [fp, #-0x28]
    // 0x862d98: r0 = InitLateStaticField(0xe0c) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_strokeTailTween
    //     0x862d98: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x862d9c: ldr             x0, [x0, #0x1c18]
    //     0x862da0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x862da4: cmp             w0, w16
    //     0x862da8: b.ne            #0x862db8
    //     0x862dac: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfd8] Field <_CircularProgressIndicatorState@793243954._strokeTailTween@793243954>: static late final (offset: 0xe0c)
    //     0x862db0: ldr             x2, [x2, #0xfd8]
    //     0x862db4: bl              #0xd67cdc
    // 0x862db8: mov             x1, x0
    // 0x862dbc: ldur            x0, [fp, #-0x10]
    // 0x862dc0: LoadField: r2 = r0->field_f
    //     0x862dc0: ldur            w2, [x0, #0xf]
    // 0x862dc4: DecompressPointer r2
    //     0x862dc4: add             x2, x2, HEAP, lsl #32
    // 0x862dc8: LoadField: r3 = r2->field_1b
    //     0x862dc8: ldur            w3, [x2, #0x1b]
    // 0x862dcc: DecompressPointer r3
    //     0x862dcc: add             x3, x3, HEAP, lsl #32
    // 0x862dd0: r16 = Sentinel
    //     0x862dd0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862dd4: cmp             w3, w16
    // 0x862dd8: b.eq            #0x862f08
    // 0x862ddc: stp             x3, x1, [SP, #-0x10]!
    // 0x862de0: r0 = evaluate()
    //     0x862de0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x862de4: add             SP, SP, #0x10
    // 0x862de8: stur            x0, [fp, #-0x18]
    // 0x862dec: r0 = InitLateStaticField(0xe10) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_offsetTween
    //     0x862dec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x862df0: ldr             x0, [x0, #0x1c20]
    //     0x862df4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x862df8: cmp             w0, w16
    //     0x862dfc: b.ne            #0x862e0c
    //     0x862e00: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfe0] Field <_CircularProgressIndicatorState@793243954._offsetTween@793243954>: static late final (offset: 0xe10)
    //     0x862e04: ldr             x2, [x2, #0xfe0]
    //     0x862e08: bl              #0xd67cdc
    // 0x862e0c: mov             x1, x0
    // 0x862e10: ldur            x0, [fp, #-0x10]
    // 0x862e14: LoadField: r2 = r0->field_f
    //     0x862e14: ldur            w2, [x0, #0xf]
    // 0x862e18: DecompressPointer r2
    //     0x862e18: add             x2, x2, HEAP, lsl #32
    // 0x862e1c: LoadField: r3 = r2->field_1b
    //     0x862e1c: ldur            w3, [x2, #0x1b]
    // 0x862e20: DecompressPointer r3
    //     0x862e20: add             x3, x3, HEAP, lsl #32
    // 0x862e24: r16 = Sentinel
    //     0x862e24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862e28: cmp             w3, w16
    // 0x862e2c: b.eq            #0x862f14
    // 0x862e30: stp             x3, x1, [SP, #-0x10]!
    // 0x862e34: r0 = evaluate()
    //     0x862e34: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x862e38: add             SP, SP, #0x10
    // 0x862e3c: stur            x0, [fp, #-0x20]
    // 0x862e40: r0 = InitLateStaticField(0xe14) // [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorState::_rotationTween
    //     0x862e40: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x862e44: ldr             x0, [x0, #0x1c28]
    //     0x862e48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x862e4c: cmp             w0, w16
    //     0x862e50: b.ne            #0x862e60
    //     0x862e54: add             x2, PP, #0x1c, lsl #12  ; [pp+0x1cfe8] Field <_CircularProgressIndicatorState@793243954._rotationTween@793243954>: static late final (offset: 0xe14)
    //     0x862e58: ldr             x2, [x2, #0xfe8]
    //     0x862e5c: bl              #0xd67cdc
    // 0x862e60: mov             x1, x0
    // 0x862e64: ldur            x0, [fp, #-0x10]
    // 0x862e68: LoadField: r2 = r0->field_f
    //     0x862e68: ldur            w2, [x0, #0xf]
    // 0x862e6c: DecompressPointer r2
    //     0x862e6c: add             x2, x2, HEAP, lsl #32
    // 0x862e70: LoadField: r0 = r2->field_1b
    //     0x862e70: ldur            w0, [x2, #0x1b]
    // 0x862e74: DecompressPointer r0
    //     0x862e74: add             x0, x0, HEAP, lsl #32
    // 0x862e78: r16 = Sentinel
    //     0x862e78: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862e7c: cmp             w0, w16
    // 0x862e80: b.eq            #0x862f20
    // 0x862e84: stp             x0, x1, [SP, #-0x10]!
    // 0x862e88: r0 = evaluate()
    //     0x862e88: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x862e8c: add             SP, SP, #0x10
    // 0x862e90: ldur            d0, [fp, #-0x28]
    // 0x862e94: r1 = inline_Allocate_Double()
    //     0x862e94: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x862e98: add             x1, x1, #0x10
    //     0x862e9c: cmp             x2, x1
    //     0x862ea0: b.ls            #0x862f2c
    //     0x862ea4: str             x1, [THR, #0x60]  ; THR::top
    //     0x862ea8: sub             x1, x1, #0xf
    //     0x862eac: mov             x2, #0xd108
    //     0x862eb0: movk            x2, #3, lsl #16
    //     0x862eb4: stur            x2, [x1, #-1]
    // 0x862eb8: StoreField: r1->field_7 = d0
    //     0x862eb8: stur            d0, [x1, #7]
    // 0x862ebc: LoadField: d0 = r0->field_7
    //     0x862ebc: ldur            d0, [x0, #7]
    // 0x862ec0: ldur            x16, [fp, #-8]
    // 0x862ec4: ldr             lr, [fp, #0x18]
    // 0x862ec8: stp             lr, x16, [SP, #-0x10]!
    // 0x862ecc: ldur            x16, [fp, #-0x18]
    // 0x862ed0: stp             x16, x1, [SP, #-0x10]!
    // 0x862ed4: ldur            x16, [fp, #-0x20]
    // 0x862ed8: SaveReg r16
    //     0x862ed8: str             x16, [SP, #-8]!
    // 0x862edc: SaveReg d0
    //     0x862edc: str             d0, [SP, #-8]!
    // 0x862ee0: r0 = _buildMaterialIndicator()
    //     0x862ee0: bl              #0x862f48  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorState::_buildMaterialIndicator
    // 0x862ee4: add             SP, SP, #0x30
    // 0x862ee8: LeaveFrame
    //     0x862ee8: mov             SP, fp
    //     0x862eec: ldp             fp, lr, [SP], #0x10
    // 0x862ef0: ret
    //     0x862ef0: ret             
    // 0x862ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862ef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862ef8: b               #0x862d28
    // 0x862efc: r9 = _controller
    //     0x862efc: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862f00: ldr             x9, [x9, #0xfc8]
    // 0x862f04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862f04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x862f08: r9 = _controller
    //     0x862f08: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862f0c: ldr             x9, [x9, #0xfc8]
    // 0x862f10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862f10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x862f14: r9 = _controller
    //     0x862f14: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862f18: ldr             x9, [x9, #0xfc8]
    // 0x862f1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862f1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x862f20: r9 = _controller
    //     0x862f20: add             x9, PP, #0x1c, lsl #12  ; [pp+0x1cfc8] Field <_CircularProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862f24: ldr             x9, [x9, #0xfc8]
    // 0x862f28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862f28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x862f2c: SaveReg d0
    //     0x862f2c: str             q0, [SP, #-0x10]!
    // 0x862f30: SaveReg r0
    //     0x862f30: str             x0, [SP, #-8]!
    // 0x862f34: r0 = AllocateDouble()
    //     0x862f34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x862f38: mov             x1, x0
    // 0x862f3c: RestoreReg r0
    //     0x862f3c: ldr             x0, [SP], #8
    // 0x862f40: RestoreReg d0
    //     0x862f40: ldr             q0, [SP], #0x10
    // 0x862f44: b               #0x862eb8
  }
  _ _buildMaterialIndicator(/* No info */) {
    // ** addr: 0x862f48, size: 0x520
    // 0x862f48: EnterFrame
    //     0x862f48: stp             fp, lr, [SP, #-0x10]!
    //     0x862f4c: mov             fp, SP
    // 0x862f50: AllocStack(0x58)
    //     0x862f50: sub             SP, SP, #0x58
    // 0x862f54: CheckStackOverflow
    //     0x862f54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x862f58: cmp             SP, x16
    //     0x862f5c: b.ls            #0x8633c4
    // 0x862f60: ldr             x1, [fp, #0x38]
    // 0x862f64: LoadField: r0 = r1->field_b
    //     0x862f64: ldur            w0, [x1, #0xb]
    // 0x862f68: DecompressPointer r0
    //     0x862f68: add             x0, x0, HEAP, lsl #32
    // 0x862f6c: cmp             w0, NULL
    // 0x862f70: b.eq            #0x8633cc
    // 0x862f74: LoadField: r2 = r0->field_b
    //     0x862f74: ldur            w2, [x0, #0xb]
    // 0x862f78: DecompressPointer r2
    //     0x862f78: add             x2, x2, HEAP, lsl #32
    // 0x862f7c: stur            x2, [fp, #-8]
    // 0x862f80: cmp             w2, NULL
    // 0x862f84: b.ne            #0x862f94
    // 0x862f88: mov             x0, x2
    // 0x862f8c: d0 = 0.000000
    //     0x862f8c: eor             v0.16b, v0.16b, v0.16b
    // 0x862f90: b               #0x862fb8
    // 0x862f94: LoadField: d0 = r2->field_7
    //     0x862f94: ldur            d0, [x2, #7]
    // 0x862f98: r16 = Instance_Interval
    //     0x862f98: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b5e0] Obj!Interval<double>@b4f861
    //     0x862f9c: ldr             x16, [x16, #0x5e0]
    // 0x862fa0: SaveReg r16
    //     0x862fa0: str             x16, [SP, #-8]!
    // 0x862fa4: SaveReg d0
    //     0x862fa4: str             d0, [SP, #-8]!
    // 0x862fa8: r0 = transform()
    //     0x862fa8: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0x862fac: add             SP, SP, #0x10
    // 0x862fb0: LoadField: d0 = r0->field_7
    //     0x862fb0: ldur            d0, [x0, #7]
    // 0x862fb4: ldur            x0, [fp, #-8]
    // 0x862fb8: stur            d0, [fp, #-0x40]
    // 0x862fbc: cmp             w0, NULL
    // 0x862fc0: b.ne            #0x862fe4
    // 0x862fc4: ldr             x2, [fp, #0x38]
    // 0x862fc8: LoadField: r1 = r2->field_27
    //     0x862fc8: ldur            w1, [x2, #0x27]
    // 0x862fcc: DecompressPointer r1
    //     0x862fcc: add             x1, x1, HEAP, lsl #32
    // 0x862fd0: cmp             w1, NULL
    // 0x862fd4: b.ne            #0x862fe8
    // 0x862fd8: mov             x0, x2
    // 0x862fdc: d0 = 0.000000
    //     0x862fdc: eor             v0.16b, v0.16b, v0.16b
    // 0x862fe0: b               #0x863064
    // 0x862fe4: ldr             x2, [fp, #0x38]
    // 0x862fe8: mov             x1, x2
    // 0x862fec: LoadField: r0 = r1->field_23
    //     0x862fec: ldur            w0, [x1, #0x23]
    // 0x862ff0: DecompressPointer r0
    //     0x862ff0: add             x0, x0, HEAP, lsl #32
    // 0x862ff4: r16 = Sentinel
    //     0x862ff4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862ff8: cmp             w0, w16
    // 0x862ffc: b.ne            #0x86300c
    // 0x863000: r2 = _additionalRotationTween
    //     0x863000: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b5f0] Field <_RefreshProgressIndicatorState@793243954._additionalRotationTween@793243954>: late final (offset: 0x24)
    //     0x863004: ldr             x2, [x2, #0x5f0]
    // 0x863008: r0 = InitLateFinalInstanceField()
    //     0x863008: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0x86300c: mov             x1, x0
    // 0x863010: ldur            x0, [fp, #-8]
    // 0x863014: cmp             w0, NULL
    // 0x863018: b.ne            #0x863038
    // 0x86301c: ldr             x2, [fp, #0x38]
    // 0x863020: LoadField: r0 = r2->field_27
    //     0x863020: ldur            w0, [x2, #0x27]
    // 0x863024: DecompressPointer r0
    //     0x863024: add             x0, x0, HEAP, lsl #32
    // 0x863028: cmp             w0, NULL
    // 0x86302c: b.eq            #0x8633d0
    // 0x863030: LoadField: d0 = r0->field_7
    //     0x863030: ldur            d0, [x0, #7]
    // 0x863034: b               #0x863040
    // 0x863038: ldr             x2, [fp, #0x38]
    // 0x86303c: LoadField: d0 = r0->field_7
    //     0x86303c: ldur            d0, [x0, #7]
    // 0x863040: SaveReg r1
    //     0x863040: str             x1, [SP, #-8]!
    // 0x863044: SaveReg d0
    //     0x863044: str             d0, [SP, #-8]!
    // 0x863048: r0 = transform()
    //     0x863048: bl              #0xc09f14  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::transform
    // 0x86304c: add             SP, SP, #0x10
    // 0x863050: LoadField: d0 = r0->field_7
    //     0x863050: ldur            d0, [x0, #7]
    // 0x863054: d1 = 3.141593
    //     0x863054: ldr             d1, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0x863058: fmul            d2, d1, d0
    // 0x86305c: mov             v0.16b, v2.16b
    // 0x863060: ldr             x0, [fp, #0x38]
    // 0x863064: stur            d0, [fp, #-0x48]
    // 0x863068: LoadField: r1 = r0->field_b
    //     0x863068: ldur            w1, [x0, #0xb]
    // 0x86306c: DecompressPointer r1
    //     0x86306c: add             x1, x1, HEAP, lsl #32
    // 0x863070: cmp             w1, NULL
    // 0x863074: b.eq            #0x8633d4
    // 0x863078: ldr             x16, [fp, #0x30]
    // 0x86307c: stp             x16, x1, [SP, #-0x10]!
    // 0x863080: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x863080: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x863084: r0 = _getValueColor()
    //     0x863084: bl              #0x86292c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_getValueColor
    // 0x863088: add             SP, SP, #0x10
    // 0x86308c: stur            x0, [fp, #-8]
    // 0x863090: SaveReg r0
    //     0x863090: str             x0, [SP, #-8]!
    // 0x863094: r0 = opacity()
    //     0x863094: bl              #0x84d0ac  ; [dart:ui] Color::opacity
    // 0x863098: add             SP, SP, #8
    // 0x86309c: stur            d0, [fp, #-0x50]
    // 0x8630a0: ldur            x16, [fp, #-8]
    // 0x8630a4: SaveReg r16
    //     0x8630a4: str             x16, [SP, #-8]!
    // 0x8630a8: d1 = 1.000000
    //     0x8630a8: fmov            d1, #1.00000000
    // 0x8630ac: SaveReg d1
    //     0x8630ac: str             d1, [SP, #-8]!
    // 0x8630b0: r0 = withOpacity()
    //     0x8630b0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8630b4: add             SP, SP, #0x10
    // 0x8630b8: mov             x2, x0
    // 0x8630bc: ldr             x1, [fp, #0x38]
    // 0x8630c0: stur            x2, [fp, #-8]
    // 0x8630c4: LoadField: r0 = r1->field_b
    //     0x8630c4: ldur            w0, [x1, #0xb]
    // 0x8630c8: DecompressPointer r0
    //     0x8630c8: add             x0, x0, HEAP, lsl #32
    // 0x8630cc: cmp             w0, NULL
    // 0x8630d0: b.eq            #0x8633d8
    // 0x8630d4: r3 = LoadClassIdInstr(r0)
    //     0x8630d4: ldur            x3, [x0, #-1]
    //     0x8630d8: ubfx            x3, x3, #0xc, #0x14
    // 0x8630dc: SaveReg r0
    //     0x8630dc: str             x0, [SP, #-8]!
    // 0x8630e0: mov             x0, x3
    // 0x8630e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8630e4: sub             lr, x0, #1, lsl #12
    //     0x8630e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8630ec: blr             lr
    // 0x8630f0: add             SP, SP, #8
    // 0x8630f4: cmp             w0, NULL
    // 0x8630f8: b.ne            #0x863110
    // 0x8630fc: ldr             x16, [fp, #0x30]
    // 0x863100: SaveReg r16
    //     0x863100: str             x16, [SP, #-8]!
    // 0x863104: r0 = of()
    //     0x863104: bl              #0x862a5c  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0x863108: add             SP, SP, #8
    // 0x86310c: r0 = Null
    //     0x86310c: mov             x0, NULL
    // 0x863110: cmp             w0, NULL
    // 0x863114: b.ne            #0x863138
    // 0x863118: ldr             x16, [fp, #0x30]
    // 0x86311c: SaveReg r16
    //     0x86311c: str             x16, [SP, #-8]!
    // 0x863120: r0 = of()
    //     0x863120: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x863124: add             SP, SP, #8
    // 0x863128: LoadField: r1 = r0->field_37
    //     0x863128: ldur            w1, [x0, #0x37]
    // 0x86312c: DecompressPointer r1
    //     0x86312c: add             x1, x1, HEAP, lsl #32
    // 0x863130: mov             x2, x1
    // 0x863134: b               #0x86313c
    // 0x863138: mov             x2, x0
    // 0x86313c: ldr             x0, [fp, #0x38]
    // 0x863140: ldr             x1, [fp, #0x20]
    // 0x863144: ldr             d3, [fp, #0x10]
    // 0x863148: ldur            d2, [fp, #-0x40]
    // 0x86314c: ldur            d1, [fp, #-0x48]
    // 0x863150: ldur            d0, [fp, #-0x50]
    // 0x863154: stur            x2, [fp, #-0x30]
    // 0x863158: LoadField: r3 = r0->field_b
    //     0x863158: ldur            w3, [x0, #0xb]
    // 0x86315c: DecompressPointer r3
    //     0x86315c: add             x3, x3, HEAP, lsl #32
    // 0x863160: stur            x3, [fp, #-0x28]
    // 0x863164: cmp             w3, NULL
    // 0x863168: b.eq            #0x8633dc
    // 0x86316c: LoadField: d4 = r3->field_27
    //     0x86316c: ldur            d4, [x3, #0x27]
    // 0x863170: LoadField: d5 = r1->field_7
    //     0x863170: ldur            d5, [x1, #7]
    // 0x863174: stur            d5, [fp, #-0x58]
    // 0x863178: r0 = inline_Allocate_Double()
    //     0x863178: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x86317c: add             x0, x0, #0x10
    //     0x863180: cmp             x1, x0
    //     0x863184: b.ls            #0x8633e0
    //     0x863188: str             x0, [THR, #0x60]  ; THR::top
    //     0x86318c: sub             x0, x0, #0xf
    //     0x863190: mov             x1, #0xd108
    //     0x863194: movk            x1, #3, lsl #16
    //     0x863198: stur            x1, [x0, #-1]
    // 0x86319c: StoreField: r0->field_7 = d3
    //     0x86319c: stur            d3, [x0, #7]
    // 0x8631a0: stur            x0, [fp, #-0x20]
    // 0x8631a4: r1 = inline_Allocate_Double()
    //     0x8631a4: ldp             x1, x4, [THR, #0x60]  ; THR::top
    //     0x8631a8: add             x1, x1, #0x10
    //     0x8631ac: cmp             x4, x1
    //     0x8631b0: b.ls            #0x863408
    //     0x8631b4: str             x1, [THR, #0x60]  ; THR::top
    //     0x8631b8: sub             x1, x1, #0xf
    //     0x8631bc: mov             x4, #0xd108
    //     0x8631c0: movk            x4, #3, lsl #16
    //     0x8631c4: stur            x4, [x1, #-1]
    // 0x8631c8: StoreField: r1->field_7 = d2
    //     0x8631c8: stur            d2, [x1, #7]
    // 0x8631cc: stur            x1, [fp, #-0x18]
    // 0x8631d0: r4 = inline_Allocate_Double()
    //     0x8631d0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x8631d4: add             x4, x4, #0x10
    //     0x8631d8: cmp             x5, x4
    //     0x8631dc: b.ls            #0x86343c
    //     0x8631e0: str             x4, [THR, #0x60]  ; THR::top
    //     0x8631e4: sub             x4, x4, #0xf
    //     0x8631e8: mov             x5, #0xd108
    //     0x8631ec: movk            x5, #3, lsl #16
    //     0x8631f0: stur            x5, [x4, #-1]
    // 0x8631f4: StoreField: r4->field_7 = d4
    //     0x8631f4: stur            d4, [x4, #7]
    // 0x8631f8: stur            x4, [fp, #-0x10]
    // 0x8631fc: r0 = _RefreshProgressIndicatorPainter()
    //     0x8631fc: bl              #0x8639a0  ; Allocate_RefreshProgressIndicatorPainterStub -> _RefreshProgressIndicatorPainter (size=0x58)
    // 0x863200: stur            x0, [fp, #-0x38]
    // 0x863204: ldur            x16, [fp, #-0x18]
    // 0x863208: stp             x16, x0, [SP, #-0x10]!
    // 0x86320c: ldr             x16, [fp, #0x28]
    // 0x863210: ldr             lr, [fp, #0x18]
    // 0x863214: stp             lr, x16, [SP, #-0x10]!
    // 0x863218: ldur            x16, [fp, #-0x20]
    // 0x86321c: ldur            lr, [fp, #-0x10]
    // 0x863220: stp             lr, x16, [SP, #-0x10]!
    // 0x863224: ldur            d0, [fp, #-0x58]
    // 0x863228: SaveReg d0
    //     0x863228: str             d0, [SP, #-8]!
    // 0x86322c: ldur            x16, [fp, #-8]
    // 0x863230: SaveReg r16
    //     0x863230: str             x16, [SP, #-8]!
    // 0x863234: r0 = _RefreshProgressIndicatorPainter()
    //     0x863234: bl              #0x8636d8  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorPainter::_RefreshProgressIndicatorPainter
    // 0x863238: add             SP, SP, #0x40
    // 0x86323c: r0 = CustomPaint()
    //     0x86323c: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x863240: mov             x1, x0
    // 0x863244: ldur            x0, [fp, #-0x38]
    // 0x863248: stur            x1, [fp, #-8]
    // 0x86324c: StoreField: r1->field_f = r0
    //     0x86324c: stur            w0, [x1, #0xf]
    // 0x863250: r0 = Instance_Size
    //     0x863250: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x863254: StoreField: r1->field_17 = r0
    //     0x863254: stur            w0, [x1, #0x17]
    // 0x863258: r0 = false
    //     0x863258: add             x0, NULL, #0x30  ; false
    // 0x86325c: StoreField: r1->field_1b = r0
    //     0x86325c: stur            w0, [x1, #0x1b]
    // 0x863260: StoreField: r1->field_1f = r0
    //     0x863260: stur            w0, [x1, #0x1f]
    // 0x863264: r0 = Transform()
    //     0x863264: bl              #0x8636cc  ; AllocateTransformStub -> Transform (size=0x24)
    // 0x863268: mov             x1, x0
    // 0x86326c: r0 = Instance_Alignment
    //     0x86326c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x863270: ldr             x0, [x0, #0xc70]
    // 0x863274: stur            x1, [fp, #-0x10]
    // 0x863278: StoreField: r1->field_17 = r0
    //     0x863278: stur            w0, [x1, #0x17]
    // 0x86327c: r0 = true
    //     0x86327c: add             x0, NULL, #0x20  ; true
    // 0x863280: StoreField: r1->field_1b = r0
    //     0x863280: stur            w0, [x1, #0x1b]
    // 0x863284: ldur            d0, [fp, #-0x48]
    // 0x863288: SaveReg d0
    //     0x863288: str             d0, [SP, #-8]!
    // 0x86328c: r0 = _computeRotation()
    //     0x86328c: bl              #0x863468  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0x863290: add             SP, SP, #8
    // 0x863294: ldur            x1, [fp, #-0x10]
    // 0x863298: StoreField: r1->field_f = r0
    //     0x863298: stur            w0, [x1, #0xf]
    //     0x86329c: ldurb           w16, [x1, #-1]
    //     0x8632a0: ldurb           w17, [x0, #-1]
    //     0x8632a4: and             x16, x17, x16, lsr #2
    //     0x8632a8: tst             x16, HEAP, lsr #32
    //     0x8632ac: b.eq            #0x8632b4
    //     0x8632b0: bl              #0xd6826c
    // 0x8632b4: ldur            x0, [fp, #-8]
    // 0x8632b8: StoreField: r1->field_b = r0
    //     0x8632b8: stur            w0, [x1, #0xb]
    //     0x8632bc: ldurb           w16, [x1, #-1]
    //     0x8632c0: ldurb           w17, [x0, #-1]
    //     0x8632c4: and             x16, x17, x16, lsr #2
    //     0x8632c8: tst             x16, HEAP, lsr #32
    //     0x8632cc: b.eq            #0x8632d4
    //     0x8632d0: bl              #0xd6826c
    // 0x8632d4: r0 = Opacity()
    //     0x8632d4: bl              #0x822694  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x8632d8: ldur            d0, [fp, #-0x50]
    // 0x8632dc: stur            x0, [fp, #-8]
    // 0x8632e0: StoreField: r0->field_f = d0
    //     0x8632e0: stur            d0, [x0, #0xf]
    // 0x8632e4: r1 = false
    //     0x8632e4: add             x1, NULL, #0x30  ; false
    // 0x8632e8: StoreField: r0->field_17 = r1
    //     0x8632e8: stur            w1, [x0, #0x17]
    // 0x8632ec: ldur            x1, [fp, #-0x10]
    // 0x8632f0: StoreField: r0->field_b = r1
    //     0x8632f0: stur            w1, [x0, #0xb]
    // 0x8632f4: r0 = Padding()
    //     0x8632f4: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8632f8: mov             x1, x0
    // 0x8632fc: r0 = Instance_EdgeInsets
    //     0x8632fc: add             x0, PP, #0x33, lsl #12  ; [pp+0x33990] Obj!EdgeInsets@b35d81
    //     0x863300: ldr             x0, [x0, #0x990]
    // 0x863304: stur            x1, [fp, #-0x10]
    // 0x863308: StoreField: r1->field_f = r0
    //     0x863308: stur            w0, [x1, #0xf]
    // 0x86330c: ldur            x0, [fp, #-8]
    // 0x863310: StoreField: r1->field_b = r0
    //     0x863310: stur            w0, [x1, #0xb]
    // 0x863314: r0 = Material()
    //     0x863314: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x863318: mov             x1, x0
    // 0x86331c: r0 = Instance_MaterialType
    //     0x86331c: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b5f8] Obj!MaterialType@b65571
    //     0x863320: ldr             x0, [x0, #0x5f8]
    // 0x863324: stur            x1, [fp, #-8]
    // 0x863328: StoreField: r1->field_f = r0
    //     0x863328: stur            w0, [x1, #0xf]
    // 0x86332c: d0 = 2.000000
    //     0x86332c: fmov            d0, #2.00000000
    // 0x863330: StoreField: r1->field_13 = d0
    //     0x863330: stur            d0, [x1, #0x13]
    // 0x863334: ldur            x0, [fp, #-0x30]
    // 0x863338: StoreField: r1->field_1b = r0
    //     0x863338: stur            w0, [x1, #0x1b]
    // 0x86333c: r0 = true
    //     0x86333c: add             x0, NULL, #0x20  ; true
    // 0x863340: StoreField: r1->field_2f = r0
    //     0x863340: stur            w0, [x1, #0x2f]
    // 0x863344: r0 = Instance_Clip
    //     0x863344: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x863348: ldr             x0, [x0, #0xb38]
    // 0x86334c: StoreField: r1->field_33 = r0
    //     0x86334c: stur            w0, [x1, #0x33]
    // 0x863350: r0 = Instance_Duration
    //     0x863350: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x863354: ldr             x0, [x0, #0x9e0]
    // 0x863358: StoreField: r1->field_37 = r0
    //     0x863358: stur            w0, [x1, #0x37]
    // 0x86335c: ldur            x0, [fp, #-0x10]
    // 0x863360: StoreField: r1->field_b = r0
    //     0x863360: stur            w0, [x1, #0xb]
    // 0x863364: r0 = Container()
    //     0x863364: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x863368: stur            x0, [fp, #-0x10]
    // 0x86336c: r16 = 41.000000
    //     0x86336c: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b600] 41
    //     0x863370: ldr             x16, [x16, #0x600]
    // 0x863374: stp             x16, x0, [SP, #-0x10]!
    // 0x863378: r16 = 41.000000
    //     0x863378: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b600] 41
    //     0x86337c: ldr             x16, [x16, #0x600]
    // 0x863380: r30 = Instance_EdgeInsets
    //     0x863380: add             lr, PP, #0x4b, lsl #12  ; [pp+0x4b608] Obj!EdgeInsets@b35de1
    //     0x863384: ldr             lr, [lr, #0x608]
    // 0x863388: stp             lr, x16, [SP, #-0x10]!
    // 0x86338c: ldur            x16, [fp, #-8]
    // 0x863390: SaveReg r16
    //     0x863390: str             x16, [SP, #-8]!
    // 0x863394: r4 = const [0, 0x5, 0x5, 0x1, child, 0x4, height, 0x2, margin, 0x3, width, 0x1, null]
    //     0x863394: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c508] List(13) [0, 0x5, 0x5, 0x1, "child", 0x4, "height", 0x2, "margin", 0x3, "width", 0x1, Null]
    //     0x863398: ldr             x4, [x4, #0x508]
    // 0x86339c: r0 = Container()
    //     0x86339c: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8633a0: add             SP, SP, #0x28
    // 0x8633a4: ldur            x16, [fp, #-0x28]
    // 0x8633a8: ldur            lr, [fp, #-0x10]
    // 0x8633ac: stp             lr, x16, [SP, #-0x10]!
    // 0x8633b0: r0 = _buildSemanticsWrapper()
    //     0x8633b0: bl              #0x8627e0  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_buildSemanticsWrapper
    // 0x8633b4: add             SP, SP, #0x10
    // 0x8633b8: LeaveFrame
    //     0x8633b8: mov             SP, fp
    //     0x8633bc: ldp             fp, lr, [SP], #0x10
    // 0x8633c0: ret
    //     0x8633c0: ret             
    // 0x8633c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8633c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8633c8: b               #0x862f60
    // 0x8633cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8633cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8633d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8633d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8633d4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8633d4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8633d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8633d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8633dc: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8633dc: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8633e0: stp             q4, q5, [SP, #-0x20]!
    // 0x8633e4: stp             q2, q3, [SP, #-0x20]!
    // 0x8633e8: stp             q0, q1, [SP, #-0x20]!
    // 0x8633ec: stp             x2, x3, [SP, #-0x10]!
    // 0x8633f0: r0 = AllocateDouble()
    //     0x8633f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8633f4: ldp             x2, x3, [SP], #0x10
    // 0x8633f8: ldp             q0, q1, [SP], #0x20
    // 0x8633fc: ldp             q2, q3, [SP], #0x20
    // 0x863400: ldp             q4, q5, [SP], #0x20
    // 0x863404: b               #0x86319c
    // 0x863408: stp             q4, q5, [SP, #-0x20]!
    // 0x86340c: stp             q1, q2, [SP, #-0x20]!
    // 0x863410: SaveReg d0
    //     0x863410: str             q0, [SP, #-0x10]!
    // 0x863414: stp             x2, x3, [SP, #-0x10]!
    // 0x863418: SaveReg r0
    //     0x863418: str             x0, [SP, #-8]!
    // 0x86341c: r0 = AllocateDouble()
    //     0x86341c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x863420: mov             x1, x0
    // 0x863424: RestoreReg r0
    //     0x863424: ldr             x0, [SP], #8
    // 0x863428: ldp             x2, x3, [SP], #0x10
    // 0x86342c: RestoreReg d0
    //     0x86342c: ldr             q0, [SP], #0x10
    // 0x863430: ldp             q1, q2, [SP], #0x20
    // 0x863434: ldp             q4, q5, [SP], #0x20
    // 0x863438: b               #0x8631c8
    // 0x86343c: stp             q4, q5, [SP, #-0x20]!
    // 0x863440: stp             q0, q1, [SP, #-0x20]!
    // 0x863444: stp             x2, x3, [SP, #-0x10]!
    // 0x863448: stp             x0, x1, [SP, #-0x10]!
    // 0x86344c: r0 = AllocateDouble()
    //     0x86344c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x863450: mov             x4, x0
    // 0x863454: ldp             x0, x1, [SP], #0x10
    // 0x863458: ldp             x2, x3, [SP], #0x10
    // 0x86345c: ldp             q0, q1, [SP], #0x20
    // 0x863460: ldp             q4, q5, [SP], #0x20
    // 0x863464: b               #0x8631f4
  }
  Animatable<double> _additionalRotationTween(_RefreshProgressIndicatorState) {
    // ** addr: 0x8639ac, size: 0x1b8
    // 0x8639ac: EnterFrame
    //     0x8639ac: stp             fp, lr, [SP, #-0x10]!
    //     0x8639b0: mov             fp, SP
    // 0x8639b4: AllocStack(0x20)
    //     0x8639b4: sub             SP, SP, #0x20
    // 0x8639b8: d1 = 0.100000
    //     0x8639b8: ldr             d1, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0x8639bc: d0 = 0.200000
    //     0x8639bc: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a918] IMM: double(0.2) from 0x3fc999999999999a
    //     0x8639c0: ldr             d0, [x17, #0x918]
    // 0x8639c4: CheckStackOverflow
    //     0x8639c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8639c8: cmp             SP, x16
    //     0x8639cc: b.ls            #0x863b34
    // 0x8639d0: fneg            d2, d1
    // 0x8639d4: fneg            d1, d0
    // 0x8639d8: stur            d1, [fp, #-0x20]
    // 0x8639dc: r0 = inline_Allocate_Double()
    //     0x8639dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8639e0: add             x0, x0, #0x10
    //     0x8639e4: cmp             x1, x0
    //     0x8639e8: b.ls            #0x863b3c
    //     0x8639ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x8639f0: sub             x0, x0, #0xf
    //     0x8639f4: mov             x1, #0xd108
    //     0x8639f8: movk            x1, #3, lsl #16
    //     0x8639fc: stur            x1, [x0, #-1]
    // 0x863a00: StoreField: r0->field_7 = d2
    //     0x863a00: stur            d2, [x0, #7]
    // 0x863a04: stur            x0, [fp, #-8]
    // 0x863a08: r1 = <double>
    //     0x863a08: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863a0c: r0 = Tween()
    //     0x863a0c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x863a10: mov             x2, x0
    // 0x863a14: ldur            x0, [fp, #-8]
    // 0x863a18: stur            x2, [fp, #-0x10]
    // 0x863a1c: StoreField: r2->field_b = r0
    //     0x863a1c: stur            w0, [x2, #0xb]
    // 0x863a20: ldur            d0, [fp, #-0x20]
    // 0x863a24: r0 = inline_Allocate_Double()
    //     0x863a24: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x863a28: add             x0, x0, #0x10
    //     0x863a2c: cmp             x1, x0
    //     0x863a30: b.ls            #0x863b4c
    //     0x863a34: str             x0, [THR, #0x60]  ; THR::top
    //     0x863a38: sub             x0, x0, #0xf
    //     0x863a3c: mov             x1, #0xd108
    //     0x863a40: movk            x1, #3, lsl #16
    //     0x863a44: stur            x1, [x0, #-1]
    // 0x863a48: StoreField: r0->field_7 = d0
    //     0x863a48: stur            d0, [x0, #7]
    // 0x863a4c: stur            x0, [fp, #-8]
    // 0x863a50: StoreField: r2->field_f = r0
    //     0x863a50: stur            w0, [x2, #0xf]
    // 0x863a54: r1 = <double>
    //     0x863a54: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863a58: r0 = TweenSequenceItem()
    //     0x863a58: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x863a5c: mov             x2, x0
    // 0x863a60: ldur            x0, [fp, #-0x10]
    // 0x863a64: stur            x2, [fp, #-0x18]
    // 0x863a68: StoreField: r2->field_b = r0
    //     0x863a68: stur            w0, [x2, #0xb]
    // 0x863a6c: d0 = 0.330000
    //     0x863a6c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b610] IMM: double(0.33) from 0x3fd51eb851eb851f
    //     0x863a70: ldr             d0, [x17, #0x610]
    // 0x863a74: StoreField: r2->field_f = d0
    //     0x863a74: stur            d0, [x2, #0xf]
    // 0x863a78: r1 = <double>
    //     0x863a78: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863a7c: r0 = Tween()
    //     0x863a7c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x863a80: mov             x2, x0
    // 0x863a84: ldur            x0, [fp, #-8]
    // 0x863a88: stur            x2, [fp, #-0x10]
    // 0x863a8c: StoreField: r2->field_b = r0
    //     0x863a8c: stur            w0, [x2, #0xb]
    // 0x863a90: r0 = 1.350000
    //     0x863a90: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b618] 1.35
    //     0x863a94: ldr             x0, [x0, #0x618]
    // 0x863a98: StoreField: r2->field_f = r0
    //     0x863a98: stur            w0, [x2, #0xf]
    // 0x863a9c: r1 = <double>
    //     0x863a9c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863aa0: r0 = TweenSequenceItem()
    //     0x863aa0: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x863aa4: mov             x3, x0
    // 0x863aa8: ldur            x0, [fp, #-0x10]
    // 0x863aac: stur            x3, [fp, #-8]
    // 0x863ab0: StoreField: r3->field_b = r0
    //     0x863ab0: stur            w0, [x3, #0xb]
    // 0x863ab4: d0 = 0.670000
    //     0x863ab4: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b620] IMM: double(0.6699999999999999) from 0x3fe570a3d70a3d70
    //     0x863ab8: ldr             d0, [x17, #0x620]
    // 0x863abc: StoreField: r3->field_f = d0
    //     0x863abc: stur            d0, [x3, #0xf]
    // 0x863ac0: r1 = Null
    //     0x863ac0: mov             x1, NULL
    // 0x863ac4: r2 = 4
    //     0x863ac4: mov             x2, #4
    // 0x863ac8: r0 = AllocateArray()
    //     0x863ac8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x863acc: mov             x2, x0
    // 0x863ad0: ldur            x0, [fp, #-0x18]
    // 0x863ad4: stur            x2, [fp, #-0x10]
    // 0x863ad8: StoreField: r2->field_f = r0
    //     0x863ad8: stur            w0, [x2, #0xf]
    // 0x863adc: ldur            x0, [fp, #-8]
    // 0x863ae0: StoreField: r2->field_13 = r0
    //     0x863ae0: stur            w0, [x2, #0x13]
    // 0x863ae4: r1 = <TweenSequenceItem<double>>
    //     0x863ae4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a0] TypeArguments: <TweenSequenceItem<double>>
    //     0x863ae8: ldr             x1, [x1, #0x3a0]
    // 0x863aec: r0 = AllocateGrowableArray()
    //     0x863aec: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x863af0: mov             x2, x0
    // 0x863af4: ldur            x0, [fp, #-0x10]
    // 0x863af8: stur            x2, [fp, #-8]
    // 0x863afc: StoreField: r2->field_f = r0
    //     0x863afc: stur            w0, [x2, #0xf]
    // 0x863b00: r0 = 4
    //     0x863b00: mov             x0, #4
    // 0x863b04: StoreField: r2->field_b = r0
    //     0x863b04: stur            w0, [x2, #0xb]
    // 0x863b08: r1 = <double>
    //     0x863b08: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863b0c: r0 = TweenSequence()
    //     0x863b0c: bl              #0x7b7b18  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0x863b10: stur            x0, [fp, #-0x10]
    // 0x863b14: ldur            x16, [fp, #-8]
    // 0x863b18: stp             x16, x0, [SP, #-0x10]!
    // 0x863b1c: r0 = TweenSequence()
    //     0x863b1c: bl              #0x7b7778  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0x863b20: add             SP, SP, #0x10
    // 0x863b24: ldur            x0, [fp, #-0x10]
    // 0x863b28: LeaveFrame
    //     0x863b28: mov             SP, fp
    //     0x863b2c: ldp             fp, lr, [SP], #0x10
    // 0x863b30: ret
    //     0x863b30: ret             
    // 0x863b34: r0 = StackOverflowSharedWithFPURegs()
    //     0x863b34: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x863b38: b               #0x8639d0
    // 0x863b3c: stp             q1, q2, [SP, #-0x20]!
    // 0x863b40: r0 = AllocateDouble()
    //     0x863b40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x863b44: ldp             q1, q2, [SP], #0x20
    // 0x863b48: b               #0x863a00
    // 0x863b4c: SaveReg d0
    //     0x863b4c: str             q0, [SP, #-0x10]!
    // 0x863b50: SaveReg r2
    //     0x863b50: str             x2, [SP, #-8]!
    // 0x863b54: r0 = AllocateDouble()
    //     0x863b54: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x863b58: RestoreReg r2
    //     0x863b58: ldr             x2, [SP], #8
    // 0x863b5c: RestoreReg d0
    //     0x863b5c: ldr             q0, [SP], #0x10
    // 0x863b60: b               #0x863a48
  }
  Animatable<double> _convertTween(_RefreshProgressIndicatorState) {
    // ** addr: 0x863c94, size: 0x28
    // 0x863c94: EnterFrame
    //     0x863c94: stp             fp, lr, [SP, #-0x10]!
    //     0x863c98: mov             fp, SP
    // 0x863c9c: r1 = <double>
    //     0x863c9c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x863ca0: r0 = CurveTween()
    //     0x863ca0: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x863ca4: r1 = Instance_Interval
    //     0x863ca4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b5e0] Obj!Interval<double>@b4f861
    //     0x863ca8: ldr             x1, [x1, #0x5e0]
    // 0x863cac: StoreField: r0->field_b = r1
    //     0x863cac: stur            w1, [x0, #0xb]
    // 0x863cb0: LeaveFrame
    //     0x863cb0: mov             SP, fp
    //     0x863cb4: ldp             fp, lr, [SP], #0x10
    // 0x863cb8: ret
    //     0x863cb8: ret             
  }
}

// class id: 3289, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __LinearProgressIndicatorState&State&SingleTickerProviderStateMixin extends State<LinearProgressIndicator>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x617ed4, size: 0x98
    // 0x617ed4: EnterFrame
    //     0x617ed4: stp             fp, lr, [SP, #-0x10]!
    //     0x617ed8: mov             fp, SP
    // 0x617edc: CheckStackOverflow
    //     0x617edc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617ee0: cmp             SP, x16
    //     0x617ee4: b.ls            #0x617f60
    // 0x617ee8: r0 = Ticker()
    //     0x617ee8: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x617eec: mov             x1, x0
    // 0x617ef0: r0 = false
    //     0x617ef0: add             x0, NULL, #0x30  ; false
    // 0x617ef4: StoreField: r1->field_b = r0
    //     0x617ef4: stur            w0, [x1, #0xb]
    // 0x617ef8: ldr             x0, [fp, #0x10]
    // 0x617efc: StoreField: r1->field_13 = r0
    //     0x617efc: stur            w0, [x1, #0x13]
    // 0x617f00: mov             x0, x1
    // 0x617f04: ldr             x1, [fp, #0x18]
    // 0x617f08: StoreField: r1->field_13 = r0
    //     0x617f08: stur            w0, [x1, #0x13]
    //     0x617f0c: ldurb           w16, [x1, #-1]
    //     0x617f10: ldurb           w17, [x0, #-1]
    //     0x617f14: and             x16, x17, x16, lsr #2
    //     0x617f18: tst             x16, HEAP, lsr #32
    //     0x617f1c: b.eq            #0x617f24
    //     0x617f20: bl              #0xd6826c
    // 0x617f24: SaveReg r1
    //     0x617f24: str             x1, [SP, #-8]!
    // 0x617f28: r0 = _updateTickerModeNotifier()
    //     0x617f28: bl              #0x617f90  ; [package:flutter/src/material/progress_indicator.dart] __LinearProgressIndicatorState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x617f2c: add             SP, SP, #8
    // 0x617f30: ldr             x16, [fp, #0x18]
    // 0x617f34: SaveReg r16
    //     0x617f34: str             x16, [SP, #-8]!
    // 0x617f38: r0 = _updateTicker()
    //     0x617f38: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x617f3c: add             SP, SP, #8
    // 0x617f40: ldr             x1, [fp, #0x18]
    // 0x617f44: LoadField: r0 = r1->field_13
    //     0x617f44: ldur            w0, [x1, #0x13]
    // 0x617f48: DecompressPointer r0
    //     0x617f48: add             x0, x0, HEAP, lsl #32
    // 0x617f4c: cmp             w0, NULL
    // 0x617f50: b.eq            #0x617f68
    // 0x617f54: LeaveFrame
    //     0x617f54: mov             SP, fp
    //     0x617f58: ldp             fp, lr, [SP], #0x10
    // 0x617f5c: ret
    //     0x617f5c: ret             
    // 0x617f60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x617f60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x617f64: b               #0x617ee8
    // 0x617f68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x617f68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x617f90, size: 0x11c
    // 0x617f90: EnterFrame
    //     0x617f90: stp             fp, lr, [SP, #-0x10]!
    //     0x617f94: mov             fp, SP
    // 0x617f98: AllocStack(0x10)
    //     0x617f98: sub             SP, SP, #0x10
    // 0x617f9c: CheckStackOverflow
    //     0x617f9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x617fa0: cmp             SP, x16
    //     0x617fa4: b.ls            #0x6180a0
    // 0x617fa8: ldr             x0, [fp, #0x10]
    // 0x617fac: LoadField: r1 = r0->field_f
    //     0x617fac: ldur            w1, [x0, #0xf]
    // 0x617fb0: DecompressPointer r1
    //     0x617fb0: add             x1, x1, HEAP, lsl #32
    // 0x617fb4: cmp             w1, NULL
    // 0x617fb8: b.eq            #0x6180a8
    // 0x617fbc: SaveReg r1
    //     0x617fbc: str             x1, [SP, #-8]!
    // 0x617fc0: r0 = getNotifier()
    //     0x617fc0: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x617fc4: add             SP, SP, #8
    // 0x617fc8: mov             x1, x0
    // 0x617fcc: ldr             x0, [fp, #0x10]
    // 0x617fd0: stur            x1, [fp, #-0x10]
    // 0x617fd4: LoadField: r2 = r0->field_17
    //     0x617fd4: ldur            w2, [x0, #0x17]
    // 0x617fd8: DecompressPointer r2
    //     0x617fd8: add             x2, x2, HEAP, lsl #32
    // 0x617fdc: stur            x2, [fp, #-8]
    // 0x617fe0: cmp             w1, w2
    // 0x617fe4: b.ne            #0x617ff8
    // 0x617fe8: r0 = Null
    //     0x617fe8: mov             x0, NULL
    // 0x617fec: LeaveFrame
    //     0x617fec: mov             SP, fp
    //     0x617ff0: ldp             fp, lr, [SP], #0x10
    // 0x617ff4: ret
    //     0x617ff4: ret             
    // 0x617ff8: cmp             w2, NULL
    // 0x617ffc: b.eq            #0x618038
    // 0x618000: r1 = 1
    //     0x618000: mov             x1, #1
    // 0x618004: r0 = AllocateContext()
    //     0x618004: bl              #0xd68aa4  ; AllocateContextStub
    // 0x618008: mov             x1, x0
    // 0x61800c: ldr             x0, [fp, #0x10]
    // 0x618010: StoreField: r1->field_f = r0
    //     0x618010: stur            w0, [x1, #0xf]
    // 0x618014: mov             x2, x1
    // 0x618018: r1 = Function '_updateTicker@156311458':.
    //     0x618018: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b630] AnonymousClosure: (0x6180ac), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x61801c: ldr             x1, [x1, #0x630]
    // 0x618020: r0 = AllocateClosure()
    //     0x618020: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618024: ldur            x16, [fp, #-8]
    // 0x618028: stp             x0, x16, [SP, #-0x10]!
    // 0x61802c: r0 = removeListener()
    //     0x61802c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x618030: add             SP, SP, #0x10
    // 0x618034: ldr             x0, [fp, #0x10]
    // 0x618038: r1 = 1
    //     0x618038: mov             x1, #1
    // 0x61803c: r0 = AllocateContext()
    //     0x61803c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x618040: mov             x1, x0
    // 0x618044: ldr             x0, [fp, #0x10]
    // 0x618048: StoreField: r1->field_f = r0
    //     0x618048: stur            w0, [x1, #0xf]
    // 0x61804c: mov             x2, x1
    // 0x618050: r1 = Function '_updateTicker@156311458':.
    //     0x618050: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b630] AnonymousClosure: (0x6180ac), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x618054: ldr             x1, [x1, #0x630]
    // 0x618058: r0 = AllocateClosure()
    //     0x618058: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x61805c: ldur            x16, [fp, #-0x10]
    // 0x618060: stp             x0, x16, [SP, #-0x10]!
    // 0x618064: r0 = addListener()
    //     0x618064: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x618068: add             SP, SP, #0x10
    // 0x61806c: ldur            x0, [fp, #-0x10]
    // 0x618070: ldr             x1, [fp, #0x10]
    // 0x618074: StoreField: r1->field_17 = r0
    //     0x618074: stur            w0, [x1, #0x17]
    //     0x618078: ldurb           w16, [x1, #-1]
    //     0x61807c: ldurb           w17, [x0, #-1]
    //     0x618080: and             x16, x17, x16, lsr #2
    //     0x618084: tst             x16, HEAP, lsr #32
    //     0x618088: b.eq            #0x618090
    //     0x61808c: bl              #0xd6826c
    // 0x618090: r0 = Null
    //     0x618090: mov             x0, NULL
    // 0x618094: LeaveFrame
    //     0x618094: mov             SP, fp
    //     0x618098: ldp             fp, lr, [SP], #0x10
    // 0x61809c: ret
    //     0x61809c: ret             
    // 0x6180a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6180a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6180a4: b               #0x617fa8
    // 0x6180a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6180a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x6180ac, size: 0x48
    // 0x6180ac: EnterFrame
    //     0x6180ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6180b0: mov             fp, SP
    // 0x6180b4: ldr             x0, [fp, #0x10]
    // 0x6180b8: LoadField: r1 = r0->field_17
    //     0x6180b8: ldur            w1, [x0, #0x17]
    // 0x6180bc: DecompressPointer r1
    //     0x6180bc: add             x1, x1, HEAP, lsl #32
    // 0x6180c0: CheckStackOverflow
    //     0x6180c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6180c4: cmp             SP, x16
    //     0x6180c8: b.ls            #0x6180ec
    // 0x6180cc: LoadField: r0 = r1->field_f
    //     0x6180cc: ldur            w0, [x1, #0xf]
    // 0x6180d0: DecompressPointer r0
    //     0x6180d0: add             x0, x0, HEAP, lsl #32
    // 0x6180d4: SaveReg r0
    //     0x6180d4: str             x0, [SP, #-8]!
    // 0x6180d8: r0 = _updateTicker()
    //     0x6180d8: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x6180dc: add             SP, SP, #8
    // 0x6180e0: LeaveFrame
    //     0x6180e0: mov             SP, fp
    //     0x6180e4: ldp             fp, lr, [SP], #0x10
    // 0x6180e8: ret
    //     0x6180e8: ret             
    // 0x6180ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6180ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6180f0: b               #0x6180cc
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f540, size: 0x4c
    // 0x81f540: EnterFrame
    //     0x81f540: stp             fp, lr, [SP, #-0x10]!
    //     0x81f544: mov             fp, SP
    // 0x81f548: CheckStackOverflow
    //     0x81f548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f54c: cmp             SP, x16
    //     0x81f550: b.ls            #0x81f584
    // 0x81f554: ldr             x16, [fp, #0x10]
    // 0x81f558: SaveReg r16
    //     0x81f558: str             x16, [SP, #-8]!
    // 0x81f55c: r0 = _updateTickerModeNotifier()
    //     0x81f55c: bl              #0x617f90  ; [package:flutter/src/material/progress_indicator.dart] __LinearProgressIndicatorState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f560: add             SP, SP, #8
    // 0x81f564: ldr             x16, [fp, #0x10]
    // 0x81f568: SaveReg r16
    //     0x81f568: str             x16, [SP, #-8]!
    // 0x81f56c: r0 = _updateTicker()
    //     0x81f56c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f570: add             SP, SP, #8
    // 0x81f574: r0 = Null
    //     0x81f574: mov             x0, NULL
    // 0x81f578: LeaveFrame
    //     0x81f578: mov             SP, fp
    //     0x81f57c: ldp             fp, lr, [SP], #0x10
    // 0x81f580: ret
    //     0x81f580: ret             
    // 0x81f584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f588: b               #0x81f554
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52358, size: 0x8c
    // 0xa52358: EnterFrame
    //     0xa52358: stp             fp, lr, [SP, #-0x10]!
    //     0xa5235c: mov             fp, SP
    // 0xa52360: AllocStack(0x8)
    //     0xa52360: sub             SP, SP, #8
    // 0xa52364: CheckStackOverflow
    //     0xa52364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52368: cmp             SP, x16
    //     0xa5236c: b.ls            #0xa523dc
    // 0xa52370: ldr             x0, [fp, #0x10]
    // 0xa52374: LoadField: r1 = r0->field_17
    //     0xa52374: ldur            w1, [x0, #0x17]
    // 0xa52378: DecompressPointer r1
    //     0xa52378: add             x1, x1, HEAP, lsl #32
    // 0xa5237c: stur            x1, [fp, #-8]
    // 0xa52380: cmp             w1, NULL
    // 0xa52384: b.ne            #0xa52390
    // 0xa52388: mov             x1, x0
    // 0xa5238c: b               #0xa523c8
    // 0xa52390: r1 = 1
    //     0xa52390: mov             x1, #1
    // 0xa52394: r0 = AllocateContext()
    //     0xa52394: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52398: mov             x1, x0
    // 0xa5239c: ldr             x0, [fp, #0x10]
    // 0xa523a0: StoreField: r1->field_f = r0
    //     0xa523a0: stur            w0, [x1, #0xf]
    // 0xa523a4: mov             x2, x1
    // 0xa523a8: r1 = Function '_updateTicker@156311458':.
    //     0xa523a8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b630] AnonymousClosure: (0x6180ac), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa523ac: ldr             x1, [x1, #0x630]
    // 0xa523b0: r0 = AllocateClosure()
    //     0xa523b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa523b4: ldur            x16, [fp, #-8]
    // 0xa523b8: stp             x0, x16, [SP, #-0x10]!
    // 0xa523bc: r0 = removeListener()
    //     0xa523bc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa523c0: add             SP, SP, #0x10
    // 0xa523c4: ldr             x1, [fp, #0x10]
    // 0xa523c8: StoreField: r1->field_17 = rNULL
    //     0xa523c8: stur            NULL, [x1, #0x17]
    // 0xa523cc: r0 = Null
    //     0xa523cc: mov             x0, NULL
    // 0xa523d0: LeaveFrame
    //     0xa523d0: mov             SP, fp
    //     0xa523d4: ldp             fp, lr, [SP], #0x10
    // 0xa523d8: ret
    //     0xa523d8: ret             
    // 0xa523dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa523dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa523e0: b               #0xa52370
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa523e4, size: 0x48
    // 0xa523e4: EnterFrame
    //     0xa523e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa523e8: mov             fp, SP
    // 0xa523ec: ldr             x0, [fp, #0x10]
    // 0xa523f0: LoadField: r1 = r0->field_17
    //     0xa523f0: ldur            w1, [x0, #0x17]
    // 0xa523f4: DecompressPointer r1
    //     0xa523f4: add             x1, x1, HEAP, lsl #32
    // 0xa523f8: CheckStackOverflow
    //     0xa523f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa523fc: cmp             SP, x16
    //     0xa52400: b.ls            #0xa52424
    // 0xa52404: LoadField: r0 = r1->field_f
    //     0xa52404: ldur            w0, [x1, #0xf]
    // 0xa52408: DecompressPointer r0
    //     0xa52408: add             x0, x0, HEAP, lsl #32
    // 0xa5240c: SaveReg r0
    //     0xa5240c: str             x0, [SP, #-8]!
    // 0xa52410: r0 = dispose()
    //     0xa52410: bl              #0xa52358  ; [package:flutter/src/material/progress_indicator.dart] __LinearProgressIndicatorState&State&SingleTickerProviderStateMixin::dispose
    // 0xa52414: add             SP, SP, #8
    // 0xa52418: LeaveFrame
    //     0xa52418: mov             SP, fp
    //     0xa5241c: ldp             fp, lr, [SP], #0x10
    // 0xa52420: ret
    //     0xa52420: ret             
    // 0xa52424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52428: b               #0xa52404
  }
}

// class id: 3290, size: 0x20, field offset: 0x1c
class _LinearProgressIndicatorState extends __LinearProgressIndicatorState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b8d54, size: 0x178
    // 0x7b8d54: EnterFrame
    //     0x7b8d54: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8d58: mov             fp, SP
    // 0x7b8d5c: CheckStackOverflow
    //     0x7b8d5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8d60: cmp             SP, x16
    //     0x7b8d64: b.ls            #0x7b8ea8
    // 0x7b8d68: ldr             x0, [fp, #0x10]
    // 0x7b8d6c: r2 = Null
    //     0x7b8d6c: mov             x2, NULL
    // 0x7b8d70: r1 = Null
    //     0x7b8d70: mov             x1, NULL
    // 0x7b8d74: r4 = 59
    //     0x7b8d74: mov             x4, #0x3b
    // 0x7b8d78: branchIfSmi(r0, 0x7b8d84)
    //     0x7b8d78: tbz             w0, #0, #0x7b8d84
    // 0x7b8d7c: r4 = LoadClassIdInstr(r0)
    //     0x7b8d7c: ldur            x4, [x0, #-1]
    //     0x7b8d80: ubfx            x4, x4, #0xc, #0x14
    // 0x7b8d84: r17 = 4130
    //     0x7b8d84: mov             x17, #0x1022
    // 0x7b8d88: cmp             x4, x17
    // 0x7b8d8c: b.eq            #0x7b8da4
    // 0x7b8d90: r8 = LinearProgressIndicator
    //     0x7b8d90: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b658] Type: LinearProgressIndicator
    //     0x7b8d94: ldr             x8, [x8, #0x658]
    // 0x7b8d98: r3 = Null
    //     0x7b8d98: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b660] Null
    //     0x7b8d9c: ldr             x3, [x3, #0x660]
    // 0x7b8da0: r0 = LinearProgressIndicator()
    //     0x7b8da0: bl              #0x617f6c  ; IsType_LinearProgressIndicator_Stub
    // 0x7b8da4: ldr             x3, [fp, #0x18]
    // 0x7b8da8: LoadField: r2 = r3->field_7
    //     0x7b8da8: ldur            w2, [x3, #7]
    // 0x7b8dac: DecompressPointer r2
    //     0x7b8dac: add             x2, x2, HEAP, lsl #32
    // 0x7b8db0: ldr             x0, [fp, #0x10]
    // 0x7b8db4: r1 = Null
    //     0x7b8db4: mov             x1, NULL
    // 0x7b8db8: cmp             w2, NULL
    // 0x7b8dbc: b.eq            #0x7b8de0
    // 0x7b8dc0: LoadField: r4 = r2->field_17
    //     0x7b8dc0: ldur            w4, [x2, #0x17]
    // 0x7b8dc4: DecompressPointer r4
    //     0x7b8dc4: add             x4, x4, HEAP, lsl #32
    // 0x7b8dc8: r8 = X0 bound StatefulWidget
    //     0x7b8dc8: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b8dcc: ldr             x8, [x8, #0x858]
    // 0x7b8dd0: LoadField: r9 = r4->field_7
    //     0x7b8dd0: ldur            x9, [x4, #7]
    // 0x7b8dd4: r3 = Null
    //     0x7b8dd4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b670] Null
    //     0x7b8dd8: ldr             x3, [x3, #0x670]
    // 0x7b8ddc: blr             x9
    // 0x7b8de0: ldr             x0, [fp, #0x18]
    // 0x7b8de4: LoadField: r1 = r0->field_b
    //     0x7b8de4: ldur            w1, [x0, #0xb]
    // 0x7b8de8: DecompressPointer r1
    //     0x7b8de8: add             x1, x1, HEAP, lsl #32
    // 0x7b8dec: cmp             w1, NULL
    // 0x7b8df0: b.eq            #0x7b8eb0
    // 0x7b8df4: LoadField: r2 = r1->field_b
    //     0x7b8df4: ldur            w2, [x1, #0xb]
    // 0x7b8df8: DecompressPointer r2
    //     0x7b8df8: add             x2, x2, HEAP, lsl #32
    // 0x7b8dfc: cmp             w2, NULL
    // 0x7b8e00: b.ne            #0x7b8e4c
    // 0x7b8e04: LoadField: r1 = r0->field_1b
    //     0x7b8e04: ldur            w1, [x0, #0x1b]
    // 0x7b8e08: DecompressPointer r1
    //     0x7b8e08: add             x1, x1, HEAP, lsl #32
    // 0x7b8e0c: r16 = Sentinel
    //     0x7b8e0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8e10: cmp             w1, w16
    // 0x7b8e14: b.eq            #0x7b8eb4
    // 0x7b8e18: LoadField: r3 = r1->field_2f
    //     0x7b8e18: ldur            w3, [x1, #0x2f]
    // 0x7b8e1c: DecompressPointer r3
    //     0x7b8e1c: add             x3, x3, HEAP, lsl #32
    // 0x7b8e20: cmp             w3, NULL
    // 0x7b8e24: b.eq            #0x7b8e38
    // 0x7b8e28: LoadField: r4 = r3->field_7
    //     0x7b8e28: ldur            w4, [x3, #7]
    // 0x7b8e2c: DecompressPointer r4
    //     0x7b8e2c: add             x4, x4, HEAP, lsl #32
    // 0x7b8e30: cmp             w4, NULL
    // 0x7b8e34: b.ne            #0x7b8e4c
    // 0x7b8e38: SaveReg r1
    //     0x7b8e38: str             x1, [SP, #-8]!
    // 0x7b8e3c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b8e3c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b8e40: r0 = repeat()
    //     0x7b8e40: bl              #0x7b8ecc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x7b8e44: add             SP, SP, #8
    // 0x7b8e48: b               #0x7b8e98
    // 0x7b8e4c: cmp             w2, NULL
    // 0x7b8e50: b.eq            #0x7b8e98
    // 0x7b8e54: LoadField: r1 = r0->field_1b
    //     0x7b8e54: ldur            w1, [x0, #0x1b]
    // 0x7b8e58: DecompressPointer r1
    //     0x7b8e58: add             x1, x1, HEAP, lsl #32
    // 0x7b8e5c: r16 = Sentinel
    //     0x7b8e5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8e60: cmp             w1, w16
    // 0x7b8e64: b.eq            #0x7b8ec0
    // 0x7b8e68: LoadField: r0 = r1->field_2f
    //     0x7b8e68: ldur            w0, [x1, #0x2f]
    // 0x7b8e6c: DecompressPointer r0
    //     0x7b8e6c: add             x0, x0, HEAP, lsl #32
    // 0x7b8e70: cmp             w0, NULL
    // 0x7b8e74: b.eq            #0x7b8e98
    // 0x7b8e78: LoadField: r2 = r0->field_7
    //     0x7b8e78: ldur            w2, [x0, #7]
    // 0x7b8e7c: DecompressPointer r2
    //     0x7b8e7c: add             x2, x2, HEAP, lsl #32
    // 0x7b8e80: cmp             w2, NULL
    // 0x7b8e84: b.eq            #0x7b8e98
    // 0x7b8e88: SaveReg r1
    //     0x7b8e88: str             x1, [SP, #-8]!
    // 0x7b8e8c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b8e8c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b8e90: r0 = stop()
    //     0x7b8e90: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0x7b8e94: add             SP, SP, #8
    // 0x7b8e98: r0 = Null
    //     0x7b8e98: mov             x0, NULL
    // 0x7b8e9c: LeaveFrame
    //     0x7b8e9c: mov             SP, fp
    //     0x7b8ea0: ldp             fp, lr, [SP], #0x10
    // 0x7b8ea4: ret
    //     0x7b8ea4: ret             
    // 0x7b8ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8ea8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8eac: b               #0x7b8d68
    // 0x7b8eb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b8eb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b8eb4: r9 = _controller
    //     0x7b8eb4: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b650] Field <_LinearProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x7b8eb8: ldr             x9, [x9, #0x650]
    // 0x7b8ebc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b8ebc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b8ec0: r9 = _controller
    //     0x7b8ec0: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b650] Field <_LinearProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x7b8ec4: ldr             x9, [x9, #0x650]
    // 0x7b8ec8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b8ec8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x8623a0, size: 0x150
    // 0x8623a0: EnterFrame
    //     0x8623a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8623a4: mov             fp, SP
    // 0x8623a8: AllocStack(0x10)
    //     0x8623a8: sub             SP, SP, #0x10
    // 0x8623ac: CheckStackOverflow
    //     0x8623ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8623b0: cmp             SP, x16
    //     0x8623b4: b.ls            #0x8624c0
    // 0x8623b8: r1 = 2
    //     0x8623b8: mov             x1, #2
    // 0x8623bc: r0 = AllocateContext()
    //     0x8623bc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8623c0: mov             x1, x0
    // 0x8623c4: ldr             x0, [fp, #0x18]
    // 0x8623c8: stur            x1, [fp, #-8]
    // 0x8623cc: StoreField: r1->field_f = r0
    //     0x8623cc: stur            w0, [x1, #0xf]
    // 0x8623d0: ldr             x16, [fp, #0x10]
    // 0x8623d4: SaveReg r16
    //     0x8623d4: str             x16, [SP, #-8]!
    // 0x8623d8: r0 = of()
    //     0x8623d8: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x8623dc: add             SP, SP, #8
    // 0x8623e0: mov             x1, x0
    // 0x8623e4: ldur            x2, [fp, #-8]
    // 0x8623e8: StoreField: r2->field_13 = r0
    //     0x8623e8: stur            w0, [x2, #0x13]
    //     0x8623ec: ldurb           w16, [x2, #-1]
    //     0x8623f0: ldurb           w17, [x0, #-1]
    //     0x8623f4: and             x16, x17, x16, lsr #2
    //     0x8623f8: tst             x16, HEAP, lsr #32
    //     0x8623fc: b.eq            #0x862404
    //     0x862400: bl              #0xd6828c
    // 0x862404: ldr             x0, [fp, #0x18]
    // 0x862408: LoadField: r3 = r0->field_b
    //     0x862408: ldur            w3, [x0, #0xb]
    // 0x86240c: DecompressPointer r3
    //     0x86240c: add             x3, x3, HEAP, lsl #32
    // 0x862410: cmp             w3, NULL
    // 0x862414: b.eq            #0x8624c8
    // 0x862418: LoadField: r4 = r3->field_b
    //     0x862418: ldur            w4, [x3, #0xb]
    // 0x86241c: DecompressPointer r4
    //     0x86241c: add             x4, x4, HEAP, lsl #32
    // 0x862420: cmp             w4, NULL
    // 0x862424: b.eq            #0x862478
    // 0x862428: LoadField: r2 = r0->field_1b
    //     0x862428: ldur            w2, [x0, #0x1b]
    // 0x86242c: DecompressPointer r2
    //     0x86242c: add             x2, x2, HEAP, lsl #32
    // 0x862430: r16 = Sentinel
    //     0x862430: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862434: cmp             w2, w16
    // 0x862438: b.eq            #0x8624cc
    // 0x86243c: LoadField: r3 = r2->field_37
    //     0x86243c: ldur            w3, [x2, #0x37]
    // 0x862440: DecompressPointer r3
    //     0x862440: add             x3, x3, HEAP, lsl #32
    // 0x862444: r16 = Sentinel
    //     0x862444: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862448: cmp             w3, w16
    // 0x86244c: b.eq            #0x8624d8
    // 0x862450: LoadField: d0 = r3->field_7
    //     0x862450: ldur            d0, [x3, #7]
    // 0x862454: ldr             x16, [fp, #0x10]
    // 0x862458: stp             x16, x0, [SP, #-0x10]!
    // 0x86245c: SaveReg d0
    //     0x86245c: str             d0, [SP, #-8]!
    // 0x862460: SaveReg r1
    //     0x862460: str             x1, [SP, #-8]!
    // 0x862464: r0 = _buildIndicator()
    //     0x862464: bl              #0x8624f0  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_buildIndicator
    // 0x862468: add             SP, SP, #0x20
    // 0x86246c: LeaveFrame
    //     0x86246c: mov             SP, fp
    //     0x862470: ldp             fp, lr, [SP], #0x10
    // 0x862474: ret
    //     0x862474: ret             
    // 0x862478: LoadField: r3 = r0->field_1b
    //     0x862478: ldur            w3, [x0, #0x1b]
    // 0x86247c: DecompressPointer r3
    //     0x86247c: add             x3, x3, HEAP, lsl #32
    // 0x862480: r16 = Sentinel
    //     0x862480: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862484: cmp             w3, w16
    // 0x862488: b.eq            #0x8624e4
    // 0x86248c: stur            x3, [fp, #-0x10]
    // 0x862490: r1 = Function '<anonymous closure>':.
    //     0x862490: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b648] AnonymousClosure: (0x862ad8), in [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::build (0x8623a0)
    //     0x862494: ldr             x1, [x1, #0x648]
    // 0x862498: r0 = AllocateClosure()
    //     0x862498: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86249c: stur            x0, [fp, #-8]
    // 0x8624a0: r0 = AnimatedBuilder()
    //     0x8624a0: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x8624a4: ldur            x1, [fp, #-8]
    // 0x8624a8: StoreField: r0->field_f = r1
    //     0x8624a8: stur            w1, [x0, #0xf]
    // 0x8624ac: ldur            x1, [fp, #-0x10]
    // 0x8624b0: StoreField: r0->field_b = r1
    //     0x8624b0: stur            w1, [x0, #0xb]
    // 0x8624b4: LeaveFrame
    //     0x8624b4: mov             SP, fp
    //     0x8624b8: ldp             fp, lr, [SP], #0x10
    // 0x8624bc: ret
    //     0x8624bc: ret             
    // 0x8624c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8624c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8624c4: b               #0x8623b8
    // 0x8624c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8624c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8624cc: r9 = _controller
    //     0x8624cc: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b650] Field <_LinearProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x8624d0: ldr             x9, [x9, #0x650]
    // 0x8624d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8624d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8624d8: r9 = _value
    //     0x8624d8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x8624dc: ldr             x9, [x9, #0xbb0]
    // 0x8624e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8624e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8624e4: r9 = _controller
    //     0x8624e4: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b650] Field <_LinearProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x8624e8: ldr             x9, [x9, #0x650]
    // 0x8624ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8624ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _buildIndicator(/* No info */) {
    // ** addr: 0x8624f0, size: 0x2f0
    // 0x8624f0: EnterFrame
    //     0x8624f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8624f4: mov             fp, SP
    // 0x8624f8: AllocStack(0x38)
    //     0x8624f8: sub             SP, SP, #0x38
    // 0x8624fc: CheckStackOverflow
    //     0x8624fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x862500: cmp             SP, x16
    //     0x862504: b.ls            #0x8627c8
    // 0x862508: ldr             x16, [fp, #0x20]
    // 0x86250c: SaveReg r16
    //     0x86250c: str             x16, [SP, #-8]!
    // 0x862510: r0 = of()
    //     0x862510: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x862514: add             SP, SP, #8
    // 0x862518: LoadField: r1 = r0->field_2b
    //     0x862518: ldur            w1, [x0, #0x2b]
    // 0x86251c: DecompressPointer r1
    //     0x86251c: add             x1, x1, HEAP, lsl #32
    // 0x862520: tbnz            w1, #4, #0x86254c
    // 0x862524: ldr             x0, [fp, #0x20]
    // 0x862528: r0 = _LinearProgressIndicatorDefaultsM3()
    //     0x862528: bl              #0x862acc  ; Allocate_LinearProgressIndicatorDefaultsM3Stub -> _LinearProgressIndicatorDefaultsM3 (size=0x24)
    // 0x86252c: mov             x1, x0
    // 0x862530: r0 = Sentinel
    //     0x862530: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862534: StoreField: r1->field_1f = r0
    //     0x862534: stur            w0, [x1, #0x1f]
    // 0x862538: ldr             x2, [fp, #0x20]
    // 0x86253c: StoreField: r1->field_1b = r2
    //     0x86253c: stur            w2, [x1, #0x1b]
    // 0x862540: mov             x0, x2
    // 0x862544: mov             x2, x1
    // 0x862548: b               #0x862570
    // 0x86254c: ldr             x2, [fp, #0x20]
    // 0x862550: r0 = Sentinel
    //     0x862550: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862554: r0 = _LinearProgressIndicatorDefaultsM2()
    //     0x862554: bl              #0x862ac0  ; Allocate_LinearProgressIndicatorDefaultsM2Stub -> _LinearProgressIndicatorDefaultsM2 (size=0x24)
    // 0x862558: mov             x1, x0
    // 0x86255c: r0 = Sentinel
    //     0x86255c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862560: StoreField: r1->field_1f = r0
    //     0x862560: stur            w0, [x1, #0x1f]
    // 0x862564: ldr             x0, [fp, #0x20]
    // 0x862568: StoreField: r1->field_1b = r0
    //     0x862568: stur            w0, [x1, #0x1b]
    // 0x86256c: mov             x2, x1
    // 0x862570: ldr             x1, [fp, #0x28]
    // 0x862574: stur            x2, [fp, #-8]
    // 0x862578: SaveReg r0
    //     0x862578: str             x0, [SP, #-8]!
    // 0x86257c: r0 = of()
    //     0x86257c: bl              #0x862a5c  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0x862580: add             SP, SP, #8
    // 0x862584: mov             x2, x0
    // 0x862588: ldr             x1, [fp, #0x28]
    // 0x86258c: stur            x2, [fp, #-0x10]
    // 0x862590: LoadField: r0 = r1->field_b
    //     0x862590: ldur            w0, [x1, #0xb]
    // 0x862594: DecompressPointer r0
    //     0x862594: add             x0, x0, HEAP, lsl #32
    // 0x862598: cmp             w0, NULL
    // 0x86259c: b.eq            #0x8627d0
    // 0x8625a0: LoadField: r3 = r0->field_f
    //     0x8625a0: ldur            w3, [x0, #0xf]
    // 0x8625a4: DecompressPointer r3
    //     0x8625a4: add             x3, x3, HEAP, lsl #32
    // 0x8625a8: cmp             w3, NULL
    // 0x8625ac: b.ne            #0x8625b8
    // 0x8625b0: r0 = Null
    //     0x8625b0: mov             x0, NULL
    // 0x8625b4: b               #0x8625bc
    // 0x8625b8: mov             x0, x3
    // 0x8625bc: cmp             w0, NULL
    // 0x8625c0: b.ne            #0x8625ec
    // 0x8625c4: ldur            x3, [fp, #-8]
    // 0x8625c8: r0 = LoadClassIdInstr(r3)
    //     0x8625c8: ldur            x0, [x3, #-1]
    //     0x8625cc: ubfx            x0, x0, #0xc, #0x14
    // 0x8625d0: SaveReg r3
    //     0x8625d0: str             x3, [SP, #-8]!
    // 0x8625d4: r0 = GDT[cid_x0 + -0xc71]()
    //     0x8625d4: sub             lr, x0, #0xc71
    //     0x8625d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8625dc: blr             lr
    // 0x8625e0: add             SP, SP, #8
    // 0x8625e4: mov             x2, x0
    // 0x8625e8: b               #0x8625f0
    // 0x8625ec: mov             x2, x0
    // 0x8625f0: ldr             x1, [fp, #0x28]
    // 0x8625f4: stur            x2, [fp, #-0x18]
    // 0x8625f8: LoadField: r0 = r1->field_b
    //     0x8625f8: ldur            w0, [x1, #0xb]
    // 0x8625fc: DecompressPointer r0
    //     0x8625fc: add             x0, x0, HEAP, lsl #32
    // 0x862600: cmp             w0, NULL
    // 0x862604: b.eq            #0x8627d4
    // 0x862608: LoadField: r3 = r0->field_23
    //     0x862608: ldur            w3, [x0, #0x23]
    // 0x86260c: DecompressPointer r3
    //     0x86260c: add             x3, x3, HEAP, lsl #32
    // 0x862610: cmp             w3, NULL
    // 0x862614: b.ne            #0x86262c
    // 0x862618: ldur            x0, [fp, #-0x10]
    // 0x86261c: LoadField: r3 = r0->field_f
    //     0x86261c: ldur            w3, [x0, #0xf]
    // 0x862620: DecompressPointer r3
    //     0x862620: add             x3, x3, HEAP, lsl #32
    // 0x862624: mov             x0, x3
    // 0x862628: b               #0x862630
    // 0x86262c: mov             x0, x3
    // 0x862630: cmp             w0, NULL
    // 0x862634: b.ne            #0x862660
    // 0x862638: ldur            x3, [fp, #-8]
    // 0x86263c: r0 = LoadClassIdInstr(r3)
    //     0x86263c: ldur            x0, [x3, #-1]
    //     0x862640: ubfx            x0, x0, #0xc, #0x14
    // 0x862644: SaveReg r3
    //     0x862644: str             x3, [SP, #-8]!
    // 0x862648: r0 = GDT[cid_x0 + -0xc6c]()
    //     0x862648: sub             lr, x0, #0xc6c
    //     0x86264c: ldr             lr, [x21, lr, lsl #3]
    //     0x862650: blr             lr
    // 0x862654: add             SP, SP, #8
    // 0x862658: d1 = 4.000000
    //     0x862658: fmov            d1, #4.00000000
    // 0x86265c: b               #0x862668
    // 0x862660: LoadField: d0 = r0->field_7
    //     0x862660: ldur            d0, [x0, #7]
    // 0x862664: mov             v1.16b, v0.16b
    // 0x862668: ldr             x0, [fp, #0x28]
    // 0x86266c: ldr             d0, [fp, #0x18]
    // 0x862670: ldr             x3, [fp, #0x10]
    // 0x862674: ldur            x2, [fp, #-8]
    // 0x862678: ldur            x1, [fp, #-0x18]
    // 0x86267c: stur            d1, [fp, #-0x38]
    // 0x862680: LoadField: r4 = r0->field_b
    //     0x862680: ldur            w4, [x0, #0xb]
    // 0x862684: DecompressPointer r4
    //     0x862684: add             x4, x4, HEAP, lsl #32
    // 0x862688: stur            x4, [fp, #-0x10]
    // 0x86268c: cmp             w4, NULL
    // 0x862690: b.eq            #0x8627d8
    // 0x862694: r0 = BoxConstraints()
    //     0x862694: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x862698: mov             x1, x0
    // 0x86269c: d0 = inf
    //     0x86269c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x8626a0: stur            x1, [fp, #-0x20]
    // 0x8626a4: StoreField: r1->field_7 = d0
    //     0x8626a4: stur            d0, [x1, #7]
    // 0x8626a8: StoreField: r1->field_f = d0
    //     0x8626a8: stur            d0, [x1, #0xf]
    // 0x8626ac: ldur            d1, [fp, #-0x38]
    // 0x8626b0: StoreField: r1->field_17 = d1
    //     0x8626b0: stur            d1, [x1, #0x17]
    // 0x8626b4: StoreField: r1->field_1f = d0
    //     0x8626b4: stur            d0, [x1, #0x1f]
    // 0x8626b8: ldur            x0, [fp, #-8]
    // 0x8626bc: r2 = LoadClassIdInstr(r0)
    //     0x8626bc: ldur            x2, [x0, #-1]
    //     0x8626c0: ubfx            x2, x2, #0xc, #0x14
    // 0x8626c4: SaveReg r0
    //     0x8626c4: str             x0, [SP, #-8]!
    // 0x8626c8: mov             x0, x2
    // 0x8626cc: r0 = GDT[cid_x0 + -0xe43]()
    //     0x8626cc: sub             lr, x0, #0xe43
    //     0x8626d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8626d4: blr             lr
    // 0x8626d8: add             SP, SP, #8
    // 0x8626dc: ldur            x16, [fp, #-0x10]
    // 0x8626e0: ldr             lr, [fp, #0x20]
    // 0x8626e4: stp             lr, x16, [SP, #-0x10]!
    // 0x8626e8: SaveReg r0
    //     0x8626e8: str             x0, [SP, #-8]!
    // 0x8626ec: r4 = const [0, 0x3, 0x3, 0x2, defaultColor, 0x2, null]
    //     0x8626ec: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d010] List(7) [0, 0x3, 0x3, 0x2, "defaultColor", 0x2, Null]
    //     0x8626f0: ldr             x4, [x4, #0x10]
    // 0x8626f4: r0 = _getValueColor()
    //     0x8626f4: bl              #0x86292c  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_getValueColor
    // 0x8626f8: add             SP, SP, #0x18
    // 0x8626fc: mov             x1, x0
    // 0x862700: ldr             x0, [fp, #0x28]
    // 0x862704: stur            x1, [fp, #-0x28]
    // 0x862708: LoadField: r2 = r0->field_b
    //     0x862708: ldur            w2, [x0, #0xb]
    // 0x86270c: DecompressPointer r2
    //     0x86270c: add             x2, x2, HEAP, lsl #32
    // 0x862710: cmp             w2, NULL
    // 0x862714: b.eq            #0x8627dc
    // 0x862718: LoadField: r0 = r2->field_b
    //     0x862718: ldur            w0, [x2, #0xb]
    // 0x86271c: DecompressPointer r0
    //     0x86271c: add             x0, x0, HEAP, lsl #32
    // 0x862720: stur            x0, [fp, #-8]
    // 0x862724: r0 = _LinearProgressIndicatorPainter()
    //     0x862724: bl              #0x862920  ; Allocate_LinearProgressIndicatorPainterStub -> _LinearProgressIndicatorPainter (size=0x24)
    // 0x862728: mov             x1, x0
    // 0x86272c: ldur            x0, [fp, #-0x18]
    // 0x862730: stur            x1, [fp, #-0x30]
    // 0x862734: StoreField: r1->field_b = r0
    //     0x862734: stur            w0, [x1, #0xb]
    // 0x862738: ldur            x0, [fp, #-0x28]
    // 0x86273c: StoreField: r1->field_f = r0
    //     0x86273c: stur            w0, [x1, #0xf]
    // 0x862740: ldur            x0, [fp, #-8]
    // 0x862744: StoreField: r1->field_13 = r0
    //     0x862744: stur            w0, [x1, #0x13]
    // 0x862748: ldr             d0, [fp, #0x18]
    // 0x86274c: StoreField: r1->field_17 = d0
    //     0x86274c: stur            d0, [x1, #0x17]
    // 0x862750: ldr             x0, [fp, #0x10]
    // 0x862754: StoreField: r1->field_1f = r0
    //     0x862754: stur            w0, [x1, #0x1f]
    // 0x862758: r0 = CustomPaint()
    //     0x862758: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x86275c: mov             x1, x0
    // 0x862760: ldur            x0, [fp, #-0x30]
    // 0x862764: stur            x1, [fp, #-8]
    // 0x862768: StoreField: r1->field_f = r0
    //     0x862768: stur            w0, [x1, #0xf]
    // 0x86276c: r0 = Instance_Size
    //     0x86276c: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x862770: StoreField: r1->field_17 = r0
    //     0x862770: stur            w0, [x1, #0x17]
    // 0x862774: r0 = false
    //     0x862774: add             x0, NULL, #0x30  ; false
    // 0x862778: StoreField: r1->field_1b = r0
    //     0x862778: stur            w0, [x1, #0x1b]
    // 0x86277c: StoreField: r1->field_1f = r0
    //     0x86277c: stur            w0, [x1, #0x1f]
    // 0x862780: r0 = Container()
    //     0x862780: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x862784: stur            x0, [fp, #-0x18]
    // 0x862788: ldur            x16, [fp, #-0x20]
    // 0x86278c: stp             x16, x0, [SP, #-0x10]!
    // 0x862790: ldur            x16, [fp, #-8]
    // 0x862794: SaveReg r16
    //     0x862794: str             x16, [SP, #-8]!
    // 0x862798: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, constraints, 0x1, null]
    //     0x862798: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d028] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "constraints", 0x1, Null]
    //     0x86279c: ldr             x4, [x4, #0x28]
    // 0x8627a0: r0 = Container()
    //     0x8627a0: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x8627a4: add             SP, SP, #0x18
    // 0x8627a8: ldur            x16, [fp, #-0x10]
    // 0x8627ac: ldur            lr, [fp, #-0x18]
    // 0x8627b0: stp             lr, x16, [SP, #-0x10]!
    // 0x8627b4: r0 = _buildSemanticsWrapper()
    //     0x8627b4: bl              #0x8627e0  ; [package:flutter/src/material/progress_indicator.dart] ProgressIndicator::_buildSemanticsWrapper
    // 0x8627b8: add             SP, SP, #0x10
    // 0x8627bc: LeaveFrame
    //     0x8627bc: mov             SP, fp
    //     0x8627c0: ldp             fp, lr, [SP], #0x10
    // 0x8627c4: ret
    //     0x8627c4: ret             
    // 0x8627c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8627c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8627cc: b               #0x862508
    // 0x8627d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8627d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8627d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8627d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8627d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8627d8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8627dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8627dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x862ad8, size: 0xa0
    // 0x862ad8: EnterFrame
    //     0x862ad8: stp             fp, lr, [SP, #-0x10]!
    //     0x862adc: mov             fp, SP
    // 0x862ae0: ldr             x0, [fp, #0x20]
    // 0x862ae4: LoadField: r1 = r0->field_17
    //     0x862ae4: ldur            w1, [x0, #0x17]
    // 0x862ae8: DecompressPointer r1
    //     0x862ae8: add             x1, x1, HEAP, lsl #32
    // 0x862aec: CheckStackOverflow
    //     0x862aec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x862af0: cmp             SP, x16
    //     0x862af4: b.ls            #0x862b58
    // 0x862af8: LoadField: r0 = r1->field_f
    //     0x862af8: ldur            w0, [x1, #0xf]
    // 0x862afc: DecompressPointer r0
    //     0x862afc: add             x0, x0, HEAP, lsl #32
    // 0x862b00: LoadField: r2 = r0->field_1b
    //     0x862b00: ldur            w2, [x0, #0x1b]
    // 0x862b04: DecompressPointer r2
    //     0x862b04: add             x2, x2, HEAP, lsl #32
    // 0x862b08: r16 = Sentinel
    //     0x862b08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862b0c: cmp             w2, w16
    // 0x862b10: b.eq            #0x862b60
    // 0x862b14: LoadField: r3 = r2->field_37
    //     0x862b14: ldur            w3, [x2, #0x37]
    // 0x862b18: DecompressPointer r3
    //     0x862b18: add             x3, x3, HEAP, lsl #32
    // 0x862b1c: r16 = Sentinel
    //     0x862b1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862b20: cmp             w3, w16
    // 0x862b24: b.eq            #0x862b6c
    // 0x862b28: LoadField: r2 = r1->field_13
    //     0x862b28: ldur            w2, [x1, #0x13]
    // 0x862b2c: DecompressPointer r2
    //     0x862b2c: add             x2, x2, HEAP, lsl #32
    // 0x862b30: LoadField: d0 = r3->field_7
    //     0x862b30: ldur            d0, [x3, #7]
    // 0x862b34: ldr             x16, [fp, #0x18]
    // 0x862b38: stp             x16, x0, [SP, #-0x10]!
    // 0x862b3c: SaveReg d0
    //     0x862b3c: str             d0, [SP, #-8]!
    // 0x862b40: SaveReg r2
    //     0x862b40: str             x2, [SP, #-8]!
    // 0x862b44: r0 = _buildIndicator()
    //     0x862b44: bl              #0x8624f0  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::_buildIndicator
    // 0x862b48: add             SP, SP, #0x20
    // 0x862b4c: LeaveFrame
    //     0x862b4c: mov             SP, fp
    //     0x862b50: ldp             fp, lr, [SP], #0x10
    // 0x862b54: ret
    //     0x862b54: ret             
    // 0x862b58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862b58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862b5c: b               #0x862af8
    // 0x862b60: r9 = _controller
    //     0x862b60: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b650] Field <_LinearProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0x862b64: ldr             x9, [x9, #0x650]
    // 0x862b68: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862b68: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x862b6c: r9 = _value
    //     0x862b6c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x862b70: ldr             x9, [x9, #0xbb0]
    // 0x862b74: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862b74: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9db090, size: 0xbc
    // 0x9db090: EnterFrame
    //     0x9db090: stp             fp, lr, [SP, #-0x10]!
    //     0x9db094: mov             fp, SP
    // 0x9db098: AllocStack(0x8)
    //     0x9db098: sub             SP, SP, #8
    // 0x9db09c: CheckStackOverflow
    //     0x9db09c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db0a0: cmp             SP, x16
    //     0x9db0a4: b.ls            #0x9db140
    // 0x9db0a8: r1 = <double>
    //     0x9db0a8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db0ac: r0 = AnimationController()
    //     0x9db0ac: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db0b0: stur            x0, [fp, #-8]
    // 0x9db0b4: ldr             x16, [fp, #0x10]
    // 0x9db0b8: stp             x16, x0, [SP, #-0x10]!
    // 0x9db0bc: r16 = Instance_Duration
    //     0x9db0bc: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b680] Obj!Duration@b67c91
    //     0x9db0c0: ldr             x16, [x16, #0x680]
    // 0x9db0c4: SaveReg r16
    //     0x9db0c4: str             x16, [SP, #-8]!
    // 0x9db0c8: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db0c8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db0cc: ldr             x4, [x4, #0xa0]
    // 0x9db0d0: r0 = AnimationController()
    //     0x9db0d0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db0d4: add             SP, SP, #0x18
    // 0x9db0d8: ldur            x0, [fp, #-8]
    // 0x9db0dc: ldr             x1, [fp, #0x10]
    // 0x9db0e0: StoreField: r1->field_1b = r0
    //     0x9db0e0: stur            w0, [x1, #0x1b]
    //     0x9db0e4: ldurb           w16, [x1, #-1]
    //     0x9db0e8: ldurb           w17, [x0, #-1]
    //     0x9db0ec: and             x16, x17, x16, lsr #2
    //     0x9db0f0: tst             x16, HEAP, lsr #32
    //     0x9db0f4: b.eq            #0x9db0fc
    //     0x9db0f8: bl              #0xd6826c
    // 0x9db0fc: LoadField: r0 = r1->field_b
    //     0x9db0fc: ldur            w0, [x1, #0xb]
    // 0x9db100: DecompressPointer r0
    //     0x9db100: add             x0, x0, HEAP, lsl #32
    // 0x9db104: cmp             w0, NULL
    // 0x9db108: b.eq            #0x9db148
    // 0x9db10c: LoadField: r1 = r0->field_b
    //     0x9db10c: ldur            w1, [x0, #0xb]
    // 0x9db110: DecompressPointer r1
    //     0x9db110: add             x1, x1, HEAP, lsl #32
    // 0x9db114: cmp             w1, NULL
    // 0x9db118: b.ne            #0x9db130
    // 0x9db11c: ldur            x16, [fp, #-8]
    // 0x9db120: SaveReg r16
    //     0x9db120: str             x16, [SP, #-8]!
    // 0x9db124: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9db124: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9db128: r0 = repeat()
    //     0x9db128: bl              #0x7b8ecc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9db12c: add             SP, SP, #8
    // 0x9db130: r0 = Null
    //     0x9db130: mov             x0, NULL
    // 0x9db134: LeaveFrame
    //     0x9db134: mov             SP, fp
    //     0x9db138: ldp             fp, lr, [SP], #0x10
    // 0x9db13c: ret
    //     0x9db13c: ret             
    // 0x9db140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db140: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db144: b               #0x9db0a8
    // 0x9db148: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db148: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4af48, size: 0x18
    // 0xa4af48: r4 = 7
    //     0xa4af48: mov             x4, #7
    // 0xa4af4c: r1 = Function 'dispose':.
    //     0xa4af4c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b640] AnonymousClosure: (0xa4af60), in [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::dispose (0xa522ec)
    //     0xa4af50: ldr             x1, [x17, #0x640]
    // 0xa4af54: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4af54: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4af58: LoadField: r0 = r24->field_17
    //     0xa4af58: ldur            x0, [x24, #0x17]
    // 0xa4af5c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4af60, size: 0x48
    // 0xa4af60: EnterFrame
    //     0xa4af60: stp             fp, lr, [SP, #-0x10]!
    //     0xa4af64: mov             fp, SP
    // 0xa4af68: ldr             x0, [fp, #0x10]
    // 0xa4af6c: LoadField: r1 = r0->field_17
    //     0xa4af6c: ldur            w1, [x0, #0x17]
    // 0xa4af70: DecompressPointer r1
    //     0xa4af70: add             x1, x1, HEAP, lsl #32
    // 0xa4af74: CheckStackOverflow
    //     0xa4af74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4af78: cmp             SP, x16
    //     0xa4af7c: b.ls            #0xa4afa0
    // 0xa4af80: LoadField: r0 = r1->field_f
    //     0xa4af80: ldur            w0, [x1, #0xf]
    // 0xa4af84: DecompressPointer r0
    //     0xa4af84: add             x0, x0, HEAP, lsl #32
    // 0xa4af88: SaveReg r0
    //     0xa4af88: str             x0, [SP, #-8]!
    // 0xa4af8c: r0 = dispose()
    //     0xa4af8c: bl              #0xa522ec  ; [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorState::dispose
    // 0xa4af90: add             SP, SP, #8
    // 0xa4af94: LeaveFrame
    //     0xa4af94: mov             SP, fp
    //     0xa4af98: ldp             fp, lr, [SP], #0x10
    // 0xa4af9c: ret
    //     0xa4af9c: ret             
    // 0xa4afa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4afa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4afa4: b               #0xa4af80
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa522ec, size: 0x6c
    // 0xa522ec: EnterFrame
    //     0xa522ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa522f0: mov             fp, SP
    // 0xa522f4: CheckStackOverflow
    //     0xa522f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa522f8: cmp             SP, x16
    //     0xa522fc: b.ls            #0xa52344
    // 0xa52300: ldr             x0, [fp, #0x10]
    // 0xa52304: LoadField: r1 = r0->field_1b
    //     0xa52304: ldur            w1, [x0, #0x1b]
    // 0xa52308: DecompressPointer r1
    //     0xa52308: add             x1, x1, HEAP, lsl #32
    // 0xa5230c: r16 = Sentinel
    //     0xa5230c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52310: cmp             w1, w16
    // 0xa52314: b.eq            #0xa5234c
    // 0xa52318: SaveReg r1
    //     0xa52318: str             x1, [SP, #-8]!
    // 0xa5231c: r0 = dispose()
    //     0xa5231c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa52320: add             SP, SP, #8
    // 0xa52324: ldr             x16, [fp, #0x10]
    // 0xa52328: SaveReg r16
    //     0xa52328: str             x16, [SP, #-8]!
    // 0xa5232c: r0 = dispose()
    //     0xa5232c: bl              #0xa52358  ; [package:flutter/src/material/progress_indicator.dart] __LinearProgressIndicatorState&State&SingleTickerProviderStateMixin::dispose
    // 0xa52330: add             SP, SP, #8
    // 0xa52334: r0 = Null
    //     0xa52334: mov             x0, NULL
    // 0xa52338: LeaveFrame
    //     0xa52338: mov             SP, fp
    //     0xa5233c: ldp             fp, lr, [SP], #0x10
    // 0xa52340: ret
    //     0xa52340: ret             
    // 0xa52344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52348: b               #0xa52300
    // 0xa5234c: r9 = _controller
    //     0xa5234c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b650] Field <_LinearProgressIndicatorState@793243954._controller@793243954>: late (offset: 0x1c)
    //     0xa52350: ldr             x9, [x9, #0x650]
    // 0xa52354: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52354: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4127, size: 0x24, field offset: 0xc
//   const constructor, 
abstract class ProgressIndicator extends StatefulWidget {

  _ _buildSemanticsWrapper(/* No info */) {
    // ** addr: 0x8627e0, size: 0x140
    // 0x8627e0: EnterFrame
    //     0x8627e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8627e4: mov             fp, SP
    // 0x8627e8: AllocStack(0x18)
    //     0x8627e8: sub             SP, SP, #0x18
    // 0x8627ec: CheckStackOverflow
    //     0x8627ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8627f0: cmp             SP, x16
    //     0x8627f4: b.ls            #0x8628fc
    // 0x8627f8: ldr             x0, [fp, #0x18]
    // 0x8627fc: LoadField: r1 = r0->field_b
    //     0x8627fc: ldur            w1, [x0, #0xb]
    // 0x862800: DecompressPointer r1
    //     0x862800: add             x1, x1, HEAP, lsl #32
    // 0x862804: cmp             w1, NULL
    // 0x862808: b.eq            #0x8628a8
    // 0x86280c: d0 = 100.000000
    //     0x86280c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x862810: ldr             d0, [x17, #0x308]
    // 0x862814: LoadField: d1 = r1->field_7
    //     0x862814: ldur            d1, [x1, #7]
    // 0x862818: fmul            d2, d1, d0
    // 0x86281c: mov             v0.16b, v2.16b
    // 0x862820: stp             fp, lr, [SP, #-0x10]!
    // 0x862824: mov             fp, SP
    // 0x862828: CallRuntime_LibcRound(double) -> double
    //     0x862828: and             SP, SP, #0xfffffffffffffff0
    //     0x86282c: mov             sp, SP
    //     0x862830: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x862834: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x862838: blr             x16
    //     0x86283c: mov             x16, #8
    //     0x862840: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x862844: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x862848: sub             sp, x16, #1, lsl #12
    //     0x86284c: mov             SP, fp
    //     0x862850: ldp             fp, lr, [SP], #0x10
    // 0x862854: fcmp            d0, d0
    // 0x862858: b.vs            #0x862904
    // 0x86285c: fcvtzs          x0, d0
    // 0x862860: asr             x16, x0, #0x1e
    // 0x862864: cmp             x16, x0, asr #63
    // 0x862868: b.ne            #0x862904
    // 0x86286c: lsl             x0, x0, #1
    // 0x862870: stur            x0, [fp, #-8]
    // 0x862874: r1 = Null
    //     0x862874: mov             x1, NULL
    // 0x862878: r2 = 4
    //     0x862878: mov             x2, #4
    // 0x86287c: r0 = AllocateArray()
    //     0x86287c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x862880: mov             x1, x0
    // 0x862884: ldur            x0, [fp, #-8]
    // 0x862888: StoreField: r1->field_f = r0
    //     0x862888: stur            w0, [x1, #0xf]
    // 0x86288c: r17 = "%"
    //     0x86288c: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x862890: StoreField: r1->field_13 = r17
    //     0x862890: stur            w17, [x1, #0x13]
    // 0x862894: SaveReg r1
    //     0x862894: str             x1, [SP, #-8]!
    // 0x862898: r0 = _interpolate()
    //     0x862898: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x86289c: add             SP, SP, #8
    // 0x8628a0: mov             x1, x0
    // 0x8628a4: b               #0x8628ac
    // 0x8628a8: r1 = Null
    //     0x8628a8: mov             x1, NULL
    // 0x8628ac: ldr             x0, [fp, #0x18]
    // 0x8628b0: stur            x1, [fp, #-0x10]
    // 0x8628b4: LoadField: r2 = r0->field_1b
    //     0x8628b4: ldur            w2, [x0, #0x1b]
    // 0x8628b8: DecompressPointer r2
    //     0x8628b8: add             x2, x2, HEAP, lsl #32
    // 0x8628bc: stur            x2, [fp, #-8]
    // 0x8628c0: r0 = Semantics()
    //     0x8628c0: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x8628c4: stur            x0, [fp, #-0x18]
    // 0x8628c8: ldur            x16, [fp, #-8]
    // 0x8628cc: stp             x16, x0, [SP, #-0x10]!
    // 0x8628d0: ldur            x16, [fp, #-0x10]
    // 0x8628d4: ldr             lr, [fp, #0x10]
    // 0x8628d8: stp             lr, x16, [SP, #-0x10]!
    // 0x8628dc: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, label, 0x1, value, 0x2, null]
    //     0x8628dc: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d030] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "label", 0x1, "value", 0x2, Null]
    //     0x8628e0: ldr             x4, [x4, #0x30]
    // 0x8628e4: r0 = Semantics()
    //     0x8628e4: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x8628e8: add             SP, SP, #0x20
    // 0x8628ec: ldur            x0, [fp, #-0x18]
    // 0x8628f0: LeaveFrame
    //     0x8628f0: mov             SP, fp
    //     0x8628f4: ldp             fp, lr, [SP], #0x10
    // 0x8628f8: ret
    //     0x8628f8: ret             
    // 0x8628fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8628fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862900: b               #0x8627f8
    // 0x862904: SaveReg d0
    //     0x862904: str             q0, [SP, #-0x10]!
    // 0x862908: r0 = 218
    //     0x862908: mov             x0, #0xda
    // 0x86290c: r24 = DoubleToIntegerStub
    //     0x86290c: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x862910: LoadField: r30 = r24->field_7
    //     0x862910: ldur            lr, [x24, #7]
    // 0x862914: blr             lr
    // 0x862918: RestoreReg d0
    //     0x862918: ldr             q0, [SP], #0x10
    // 0x86291c: b               #0x862870
  }
  _ _getValueColor(/* No info */) {
    // ** addr: 0x86292c, size: 0x130
    // 0x86292c: EnterFrame
    //     0x86292c: stp             fp, lr, [SP, #-0x10]!
    //     0x862930: mov             fp, SP
    // 0x862934: AllocStack(0x18)
    //     0x862934: sub             SP, SP, #0x18
    // 0x862938: SetupParameters(ProgressIndicator this /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic defaultColor = Null /* r1, fp-0x8 */})
    //     0x862938: mov             x0, x4
    //     0x86293c: ldur            w1, [x0, #0x13]
    //     0x862940: add             x1, x1, HEAP, lsl #32
    //     0x862944: sub             x2, x1, #4
    //     0x862948: add             x3, fp, w2, sxtw #2
    //     0x86294c: ldr             x3, [x3, #0x18]
    //     0x862950: stur            x3, [fp, #-0x18]
    //     0x862954: add             x4, fp, w2, sxtw #2
    //     0x862958: ldr             x4, [x4, #0x10]
    //     0x86295c: stur            x4, [fp, #-0x10]
    //     0x862960: ldur            w2, [x0, #0x1f]
    //     0x862964: add             x2, x2, HEAP, lsl #32
    //     0x862968: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d048] "defaultColor"
    //     0x86296c: ldr             x16, [x16, #0x48]
    //     0x862970: cmp             w2, w16
    //     0x862974: b.ne            #0x862990
    //     0x862978: ldur            w2, [x0, #0x23]
    //     0x86297c: add             x2, x2, HEAP, lsl #32
    //     0x862980: sub             w0, w1, w2
    //     0x862984: add             x1, fp, w0, sxtw #2
    //     0x862988: ldr             x1, [x1, #8]
    //     0x86298c: b               #0x862994
    //     0x862990: mov             x1, NULL
    //     0x862994: stur            x1, [fp, #-8]
    // 0x862998: CheckStackOverflow
    //     0x862998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86299c: cmp             SP, x16
    //     0x8629a0: b.ls            #0x862a54
    // 0x8629a4: LoadField: r0 = r3->field_17
    //     0x8629a4: ldur            w0, [x3, #0x17]
    // 0x8629a8: DecompressPointer r0
    //     0x8629a8: add             x0, x0, HEAP, lsl #32
    // 0x8629ac: cmp             w0, NULL
    // 0x8629b0: b.ne            #0x8629bc
    // 0x8629b4: r0 = Null
    //     0x8629b4: mov             x0, NULL
    // 0x8629b8: b               #0x8629dc
    // 0x8629bc: r2 = LoadClassIdInstr(r0)
    //     0x8629bc: ldur            x2, [x0, #-1]
    //     0x8629c0: ubfx            x2, x2, #0xc, #0x14
    // 0x8629c4: SaveReg r0
    //     0x8629c4: str             x0, [SP, #-8]!
    // 0x8629c8: mov             x0, x2
    // 0x8629cc: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x8629cc: add             lr, x0, #0xb7c
    //     0x8629d0: ldr             lr, [x21, lr, lsl #3]
    //     0x8629d4: blr             lr
    // 0x8629d8: add             SP, SP, #8
    // 0x8629dc: cmp             w0, NULL
    // 0x8629e0: b.ne            #0x8629f4
    // 0x8629e4: ldur            x0, [fp, #-0x18]
    // 0x8629e8: LoadField: r1 = r0->field_13
    //     0x8629e8: ldur            w1, [x0, #0x13]
    // 0x8629ec: DecompressPointer r1
    //     0x8629ec: add             x1, x1, HEAP, lsl #32
    // 0x8629f0: mov             x0, x1
    // 0x8629f4: cmp             w0, NULL
    // 0x8629f8: b.ne            #0x862a10
    // 0x8629fc: ldur            x16, [fp, #-0x10]
    // 0x862a00: SaveReg r16
    //     0x862a00: str             x16, [SP, #-8]!
    // 0x862a04: r0 = of()
    //     0x862a04: bl              #0x862a5c  ; [package:flutter/src/material/progress_indicator_theme.dart] ProgressIndicatorTheme::of
    // 0x862a08: add             SP, SP, #8
    // 0x862a0c: r0 = Null
    //     0x862a0c: mov             x0, NULL
    // 0x862a10: cmp             w0, NULL
    // 0x862a14: b.ne            #0x862a1c
    // 0x862a18: ldur            x0, [fp, #-8]
    // 0x862a1c: cmp             w0, NULL
    // 0x862a20: b.ne            #0x862a48
    // 0x862a24: ldur            x16, [fp, #-0x10]
    // 0x862a28: SaveReg r16
    //     0x862a28: str             x16, [SP, #-8]!
    // 0x862a2c: r0 = of()
    //     0x862a2c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x862a30: add             SP, SP, #8
    // 0x862a34: LoadField: r1 = r0->field_3f
    //     0x862a34: ldur            w1, [x0, #0x3f]
    // 0x862a38: DecompressPointer r1
    //     0x862a38: add             x1, x1, HEAP, lsl #32
    // 0x862a3c: LoadField: r2 = r1->field_b
    //     0x862a3c: ldur            w2, [x1, #0xb]
    // 0x862a40: DecompressPointer r2
    //     0x862a40: add             x2, x2, HEAP, lsl #32
    // 0x862a44: mov             x0, x2
    // 0x862a48: LeaveFrame
    //     0x862a48: mov             SP, fp
    //     0x862a4c: ldp             fp, lr, [SP], #0x10
    // 0x862a50: ret
    //     0x862a50: ret             
    // 0x862a54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x862a54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x862a58: b               #0x8629a4
  }
}

// class id: 4128, size: 0x30, field offset: 0x24
//   const constructor, 
class CircularProgressIndicator extends ProgressIndicator {

  AlwaysStoppedAnimation<Color?> field_18;
  _ActivityIndicatorType field_24;
  _Double field_28;
  Color field_14;

  _ createState(/* No info */) {
    // ** addr: 0xa40f0c, size: 0x28
    // 0xa40f0c: EnterFrame
    //     0xa40f0c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40f10: mov             fp, SP
    // 0xa40f14: r1 = <CircularProgressIndicator>
    //     0xa40f14: add             x1, PP, #0x15, lsl #12  ; [pp+0x15288] TypeArguments: <CircularProgressIndicator>
    //     0xa40f18: ldr             x1, [x1, #0x288]
    // 0xa40f1c: r0 = _CircularProgressIndicatorState()
    //     0xa40f1c: bl              #0xa40f34  ; Allocate_CircularProgressIndicatorStateStub -> _CircularProgressIndicatorState (size=0x20)
    // 0xa40f20: r1 = Sentinel
    //     0xa40f20: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40f24: StoreField: r0->field_1b = r1
    //     0xa40f24: stur            w1, [x0, #0x1b]
    // 0xa40f28: LeaveFrame
    //     0xa40f28: mov             SP, fp
    //     0xa40f2c: ldp             fp, lr, [SP], #0x10
    // 0xa40f30: ret
    //     0xa40f30: ret             
  }
}

// class id: 4129, size: 0x30, field offset: 0x30
//   const constructor, 
class RefreshProgressIndicator extends CircularProgressIndicator {

  _ createState(/* No info */) {
    // ** addr: 0xa40ed0, size: 0x30
    // 0xa40ed0: EnterFrame
    //     0xa40ed0: stp             fp, lr, [SP, #-0x10]!
    //     0xa40ed4: mov             fp, SP
    // 0xa40ed8: r1 = <CircularProgressIndicator>
    //     0xa40ed8: add             x1, PP, #0x15, lsl #12  ; [pp+0x15288] TypeArguments: <CircularProgressIndicator>
    //     0xa40edc: ldr             x1, [x1, #0x288]
    // 0xa40ee0: r0 = _RefreshProgressIndicatorState()
    //     0xa40ee0: bl              #0xa40f00  ; Allocate_RefreshProgressIndicatorStateStub -> _RefreshProgressIndicatorState (size=0x2c)
    // 0xa40ee4: r1 = Sentinel
    //     0xa40ee4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40ee8: StoreField: r0->field_1f = r1
    //     0xa40ee8: stur            w1, [x0, #0x1f]
    // 0xa40eec: StoreField: r0->field_23 = r1
    //     0xa40eec: stur            w1, [x0, #0x23]
    // 0xa40ef0: StoreField: r0->field_1b = r1
    //     0xa40ef0: stur            w1, [x0, #0x1b]
    // 0xa40ef4: LeaveFrame
    //     0xa40ef4: mov             SP, fp
    //     0xa40ef8: ldp             fp, lr, [SP], #0x10
    // 0xa40efc: ret
    //     0xa40efc: ret             
  }
}

// class id: 4130, size: 0x28, field offset: 0x24
//   const constructor, 
class LinearProgressIndicator extends ProgressIndicator {

  _ createState(/* No info */) {
    // ** addr: 0xa40e9c, size: 0x28
    // 0xa40e9c: EnterFrame
    //     0xa40e9c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40ea0: mov             fp, SP
    // 0xa40ea4: r1 = <LinearProgressIndicator>
    //     0xa40ea4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fff8] TypeArguments: <LinearProgressIndicator>
    //     0xa40ea8: ldr             x1, [x1, #0xff8]
    // 0xa40eac: r0 = _LinearProgressIndicatorState()
    //     0xa40eac: bl              #0xa40ec4  ; Allocate_LinearProgressIndicatorStateStub -> _LinearProgressIndicatorState (size=0x20)
    // 0xa40eb0: r1 = Sentinel
    //     0xa40eb0: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40eb4: StoreField: r0->field_1b = r1
    //     0xa40eb4: stur            w1, [x0, #0x1b]
    // 0xa40eb8: LeaveFrame
    //     0xa40eb8: mov             SP, fp
    //     0xa40ebc: ldp             fp, lr, [SP], #0x10
    // 0xa40ec0: ret
    //     0xa40ec0: ret             
  }
}

// class id: 4373, size: 0x50, field offset: 0xc
class _CircularProgressIndicatorPainter extends CustomPainter {

  _ _CircularProgressIndicatorPainter(/* No info */) {
    // ** addr: 0x86374c, size: 0x254
    // 0x86374c: EnterFrame
    //     0x86374c: stp             fp, lr, [SP, #-0x10]!
    //     0x863750: mov             fp, SP
    // 0x863754: mov             x1, x4
    // 0x863758: LoadField: r2 = r1->field_13
    //     0x863758: ldur            w2, [x1, #0x13]
    // 0x86375c: DecompressPointer r2
    //     0x86375c: add             x2, x2, HEAP, lsl #32
    // 0x863760: sub             x3, x2, #0x10
    // 0x863764: add             x4, fp, w3, sxtw #2
    // 0x863768: ldr             x4, [x4, #0x48]
    // 0x86376c: add             x5, fp, w3, sxtw #2
    // 0x863770: ldr             x5, [x5, #0x40]
    // 0x863774: add             x6, fp, w3, sxtw #2
    // 0x863778: ldr             x6, [x6, #0x38]
    // 0x86377c: add             x7, fp, w3, sxtw #2
    // 0x863780: ldr             x7, [x7, #0x30]
    // 0x863784: add             x8, fp, w3, sxtw #2
    // 0x863788: ldr             x8, [x8, #0x28]
    // 0x86378c: add             x9, fp, w3, sxtw #2
    // 0x863790: ldr             d0, [x9, #0x20]
    // 0x863794: add             x9, fp, w3, sxtw #2
    // 0x863798: ldr             x9, [x9, #0x18]
    // 0x86379c: add             x10, fp, w3, sxtw #2
    // 0x8637a0: ldr             x10, [x10, #0x10]
    // 0x8637a4: LoadField: r3 = r1->field_1f
    //     0x8637a4: ldur            w3, [x1, #0x1f]
    // 0x8637a8: DecompressPointer r3
    //     0x8637a8: add             x3, x3, HEAP, lsl #32
    // 0x8637ac: r16 = "backgroundColor"
    //     0x8637ac: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc48] "backgroundColor"
    //     0x8637b0: ldr             x16, [x16, #0xc48]
    // 0x8637b4: cmp             w3, w16
    // 0x8637b8: b.ne            #0x8637d8
    // 0x8637bc: LoadField: r3 = r1->field_23
    //     0x8637bc: ldur            w3, [x1, #0x23]
    // 0x8637c0: DecompressPointer r3
    //     0x8637c0: add             x3, x3, HEAP, lsl #32
    // 0x8637c4: sub             w1, w2, w3
    // 0x8637c8: add             x2, fp, w1, sxtw #2
    // 0x8637cc: ldr             x2, [x2, #8]
    // 0x8637d0: mov             x0, x2
    // 0x8637d4: b               #0x8637dc
    // 0x8637d8: r0 = Null
    //     0x8637d8: mov             x0, NULL
    // 0x8637dc: StoreField: r4->field_b = r0
    //     0x8637dc: stur            w0, [x4, #0xb]
    //     0x8637e0: ldurb           w16, [x4, #-1]
    //     0x8637e4: ldurb           w17, [x0, #-1]
    //     0x8637e8: and             x16, x17, x16, lsr #2
    //     0x8637ec: tst             x16, HEAP, lsr #32
    //     0x8637f0: b.eq            #0x8637f8
    //     0x8637f4: bl              #0xd682cc
    // 0x8637f8: mov             x0, x10
    // 0x8637fc: StoreField: r4->field_f = r0
    //     0x8637fc: stur            w0, [x4, #0xf]
    //     0x863800: ldurb           w16, [x4, #-1]
    //     0x863804: ldurb           w17, [x0, #-1]
    //     0x863808: and             x16, x17, x16, lsr #2
    //     0x86380c: tst             x16, HEAP, lsr #32
    //     0x863810: b.eq            #0x863818
    //     0x863814: bl              #0xd682cc
    // 0x863818: mov             x0, x9
    // 0x86381c: StoreField: r4->field_13 = r0
    //     0x86381c: stur            w0, [x4, #0x13]
    //     0x863820: ldurb           w16, [x4, #-1]
    //     0x863824: ldurb           w17, [x0, #-1]
    //     0x863828: and             x16, x17, x16, lsr #2
    //     0x86382c: tst             x16, HEAP, lsr #32
    //     0x863830: b.eq            #0x863838
    //     0x863834: bl              #0xd682cc
    // 0x863838: LoadField: d1 = r5->field_7
    //     0x863838: ldur            d1, [x5, #7]
    // 0x86383c: StoreField: r4->field_17 = d1
    //     0x86383c: stur            d1, [x4, #0x17]
    // 0x863840: StoreField: r4->field_1f = d0
    //     0x863840: stur            d0, [x4, #0x1f]
    // 0x863844: LoadField: d2 = r6->field_7
    //     0x863844: ldur            d2, [x6, #7]
    // 0x863848: StoreField: r4->field_27 = d2
    //     0x863848: stur            d2, [x4, #0x27]
    // 0x86384c: LoadField: d3 = r7->field_7
    //     0x86384c: ldur            d3, [x7, #7]
    // 0x863850: StoreField: r4->field_2f = d3
    //     0x863850: stur            d3, [x4, #0x2f]
    // 0x863854: LoadField: d4 = r8->field_7
    //     0x863854: ldur            d4, [x8, #7]
    // 0x863858: StoreField: r4->field_37 = d4
    //     0x863858: stur            d4, [x4, #0x37]
    // 0x86385c: cmp             w9, NULL
    // 0x863860: b.eq            #0x86387c
    // 0x863864: d2 = -1.570796
    //     0x863864: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0x863868: ldr             d2, [x17, #0x38]
    // 0x86386c: d8 = 3.000000
    //     0x86386c: fmov            d8, #3.00000000
    // 0x863870: d7 = 2.000000
    //     0x863870: fmov            d7, #2.00000000
    // 0x863874: d5 = 3.141593
    //     0x863874: ldr             d5, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0x863878: b               #0x8638c0
    // 0x86387c: d8 = 3.000000
    //     0x86387c: fmov            d8, #3.00000000
    // 0x863880: d7 = 2.000000
    //     0x863880: fmov            d7, #2.00000000
    // 0x863884: d6 = -1.570796
    //     0x863884: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d038] IMM: double(-1.5707963267948966) from 0xbff921fb54442d18
    //     0x863888: ldr             d6, [x17, #0x38]
    // 0x86388c: d5 = 3.141593
    //     0x86388c: ldr             d5, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0x863890: d4 = 0.500000
    //     0x863890: fmov            d4, #0.50000000
    // 0x863894: fmul            d9, d0, d8
    // 0x863898: fdiv            d10, d9, d7
    // 0x86389c: fmul            d9, d10, d5
    // 0x8638a0: fadd            d10, d6, d9
    // 0x8638a4: fmul            d6, d3, d5
    // 0x8638a8: fmul            d3, d6, d7
    // 0x8638ac: fadd            d6, d10, d3
    // 0x8638b0: fmul            d3, d2, d4
    // 0x8638b4: fmul            d2, d3, d5
    // 0x8638b8: fadd            d3, d6, d2
    // 0x8638bc: mov             v2.16b, v3.16b
    // 0x8638c0: StoreField: r4->field_3f = d2
    //     0x8638c0: stur            d2, [x4, #0x3f]
    // 0x8638c4: cmp             w9, NULL
    // 0x8638c8: b.eq            #0x86392c
    // 0x8638cc: d2 = 0.000000
    //     0x8638cc: eor             v2.16b, v2.16b, v2.16b
    // 0x8638d0: LoadField: d3 = r9->field_7
    //     0x8638d0: ldur            d3, [x9, #7]
    // 0x8638d4: fcmp            d3, d2
    // 0x8638d8: b.vs            #0x8638e8
    // 0x8638dc: b.ge            #0x8638e8
    // 0x8638e0: d4 = 0.000000
    //     0x8638e0: eor             v4.16b, v4.16b, v4.16b
    // 0x8638e4: b               #0x863918
    // 0x8638e8: d4 = 1.000000
    //     0x8638e8: fmov            d4, #1.00000000
    // 0x8638ec: fcmp            d3, d4
    // 0x8638f0: b.vs            #0x863900
    // 0x8638f4: b.le            #0x863900
    // 0x8638f8: d4 = 1.000000
    //     0x8638f8: fmov            d4, #1.00000000
    // 0x8638fc: b               #0x863918
    // 0x863900: LoadField: d4 = r9->field_7
    //     0x863900: ldur            d4, [x9, #7]
    // 0x863904: fcmp            d4, d4
    // 0x863908: b.vc            #0x863914
    // 0x86390c: d4 = 1.000000
    //     0x86390c: fmov            d4, #1.00000000
    // 0x863910: b               #0x863918
    // 0x863914: mov             v4.16b, v3.16b
    // 0x863918: d3 = 6.282185
    //     0x863918: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d040] IMM: double(6.282185307179586) from 0x401920f52f66fdfd
    //     0x86391c: ldr             d3, [x17, #0x40]
    // 0x863920: fmul            d6, d4, d3
    // 0x863924: mov             v0.16b, v6.16b
    // 0x863928: b               #0x86398c
    // 0x86392c: d2 = 0.000000
    //     0x86392c: eor             v2.16b, v2.16b, v2.16b
    // 0x863930: d3 = 0.001000
    //     0x863930: add             x17, PP, #8, lsl #12  ; [pp+0x8c38] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    //     0x863934: ldr             d3, [x17, #0xc38]
    // 0x863938: fmul            d4, d1, d8
    // 0x86393c: fdiv            d1, d4, d7
    // 0x863940: fmul            d4, d1, d5
    // 0x863944: fmul            d1, d0, d8
    // 0x863948: fdiv            d0, d1, d7
    // 0x86394c: fmul            d1, d0, d5
    // 0x863950: fsub            d0, d4, d1
    // 0x863954: fcmp            d0, d3
    // 0x863958: b.vs            #0x863960
    // 0x86395c: b.gt            #0x86398c
    // 0x863960: fcmp            d0, d3
    // 0x863964: b.vs            #0x863978
    // 0x863968: b.ge            #0x863978
    // 0x86396c: d0 = 0.001000
    //     0x86396c: add             x17, PP, #8, lsl #12  ; [pp+0x8c38] IMM: double(0.001) from 0x3f50624dd2f1a9fc
    //     0x863970: ldr             d0, [x17, #0xc38]
    // 0x863974: b               #0x86398c
    // 0x863978: fcmp            d0, d2
    // 0x86397c: b.vs            #0x86398c
    // 0x863980: b.ne            #0x86398c
    // 0x863984: fadd            d1, d0, d3
    // 0x863988: mov             v0.16b, v1.16b
    // 0x86398c: StoreField: r4->field_47 = d0
    //     0x86398c: stur            d0, [x4, #0x47]
    // 0x863990: r0 = Null
    //     0x863990: mov             x0, NULL
    // 0x863994: LeaveFrame
    //     0x863994: mov             SP, fp
    //     0x863998: ldp             fp, lr, [SP], #0x10
    // 0x86399c: ret
    //     0x86399c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xa6fbfc, size: 0x2a0
    // 0xa6fbfc: EnterFrame
    //     0xa6fbfc: stp             fp, lr, [SP, #-0x10]!
    //     0xa6fc00: mov             fp, SP
    // 0xa6fc04: AllocStack(0x30)
    //     0xa6fc04: sub             SP, SP, #0x30
    // 0xa6fc08: CheckStackOverflow
    //     0xa6fc08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6fc0c: cmp             SP, x16
    //     0xa6fc10: b.ls            #0xa6fe7c
    // 0xa6fc14: r16 = 112
    //     0xa6fc14: mov             x16, #0x70
    // 0xa6fc18: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6fc1c: r0 = ByteData()
    //     0xa6fc1c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6fc20: add             SP, SP, #0x10
    // 0xa6fc24: stur            x0, [fp, #-8]
    // 0xa6fc28: r0 = Paint()
    //     0xa6fc28: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6fc2c: mov             x1, x0
    // 0xa6fc30: ldur            x0, [fp, #-8]
    // 0xa6fc34: stur            x1, [fp, #-0x18]
    // 0xa6fc38: StoreField: r1->field_7 = r0
    //     0xa6fc38: stur            w0, [x1, #7]
    // 0xa6fc3c: ldr             x2, [fp, #0x20]
    // 0xa6fc40: LoadField: r3 = r2->field_f
    //     0xa6fc40: ldur            w3, [x2, #0xf]
    // 0xa6fc44: DecompressPointer r3
    //     0xa6fc44: add             x3, x3, HEAP, lsl #32
    // 0xa6fc48: r4 = LoadClassIdInstr(r3)
    //     0xa6fc48: ldur            x4, [x3, #-1]
    //     0xa6fc4c: ubfx            x4, x4, #0xc, #0x14
    // 0xa6fc50: lsl             x4, x4, #1
    // 0xa6fc54: r17 = 10124
    //     0xa6fc54: mov             x17, #0x278c
    // 0xa6fc58: cmp             w4, w17
    // 0xa6fc5c: b.gt            #0xa6fc6c
    // 0xa6fc60: r17 = 10122
    //     0xa6fc60: mov             x17, #0x278a
    // 0xa6fc64: cmp             w4, w17
    // 0xa6fc68: b.ge            #0xa6fc84
    // 0xa6fc6c: r17 = 10114
    //     0xa6fc6c: mov             x17, #0x2782
    // 0xa6fc70: cmp             w4, w17
    // 0xa6fc74: b.eq            #0xa6fc84
    // 0xa6fc78: r17 = 10118
    //     0xa6fc78: mov             x17, #0x2786
    // 0xa6fc7c: cmp             w4, w17
    // 0xa6fc80: b.ne            #0xa6fc8c
    // 0xa6fc84: LoadField: r4 = r3->field_7
    //     0xa6fc84: ldur            x4, [x3, #7]
    // 0xa6fc88: b               #0xa6fc9c
    // 0xa6fc8c: LoadField: r4 = r3->field_f
    //     0xa6fc8c: ldur            w4, [x3, #0xf]
    // 0xa6fc90: DecompressPointer r4
    //     0xa6fc90: add             x4, x4, HEAP, lsl #32
    // 0xa6fc94: LoadField: r3 = r4->field_7
    //     0xa6fc94: ldur            x3, [x4, #7]
    // 0xa6fc98: mov             x4, x3
    // 0xa6fc9c: r3 = 1
    //     0xa6fc9c: mov             x3, #1
    // 0xa6fca0: eor             x5, x4, #0xff000000
    // 0xa6fca4: LoadField: r4 = r0->field_17
    //     0xa6fca4: ldur            w4, [x0, #0x17]
    // 0xa6fca8: DecompressPointer r4
    //     0xa6fca8: add             x4, x4, HEAP, lsl #32
    // 0xa6fcac: stur            x4, [fp, #-0x10]
    // 0xa6fcb0: sxtw            x5, w5
    // 0xa6fcb4: LoadField: r0 = r4->field_7
    //     0xa6fcb4: ldur            x0, [x4, #7]
    // 0xa6fcb8: str             w5, [x0, #4]
    // 0xa6fcbc: LoadField: d0 = r2->field_37
    //     0xa6fcbc: ldur            d0, [x2, #0x37]
    // 0xa6fcc0: fcvt            s1, d0
    // 0xa6fcc4: stur            d1, [fp, #-0x30]
    // 0xa6fcc8: LoadField: r0 = r4->field_7
    //     0xa6fcc8: ldur            x0, [x4, #7]
    // 0xa6fccc: str             s1, [x0, #0x10]
    // 0xa6fcd0: LoadField: r0 = r4->field_7
    //     0xa6fcd0: ldur            x0, [x4, #7]
    // 0xa6fcd4: str             w3, [x0, #0xc]
    // 0xa6fcd8: LoadField: r0 = r2->field_b
    //     0xa6fcd8: ldur            w0, [x2, #0xb]
    // 0xa6fcdc: DecompressPointer r0
    //     0xa6fcdc: add             x0, x0, HEAP, lsl #32
    // 0xa6fce0: stur            x0, [fp, #-8]
    // 0xa6fce4: cmp             w0, NULL
    // 0xa6fce8: b.eq            #0xa6fddc
    // 0xa6fcec: r16 = 112
    //     0xa6fcec: mov             x16, #0x70
    // 0xa6fcf0: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6fcf4: r0 = ByteData()
    //     0xa6fcf4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6fcf8: add             SP, SP, #0x10
    // 0xa6fcfc: stur            x0, [fp, #-0x20]
    // 0xa6fd00: r0 = Paint()
    //     0xa6fd00: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6fd04: mov             x1, x0
    // 0xa6fd08: ldur            x0, [fp, #-0x20]
    // 0xa6fd0c: stur            x1, [fp, #-0x28]
    // 0xa6fd10: StoreField: r1->field_7 = r0
    //     0xa6fd10: stur            w0, [x1, #7]
    // 0xa6fd14: ldur            x2, [fp, #-8]
    // 0xa6fd18: r3 = LoadClassIdInstr(r2)
    //     0xa6fd18: ldur            x3, [x2, #-1]
    //     0xa6fd1c: ubfx            x3, x3, #0xc, #0x14
    // 0xa6fd20: lsl             x3, x3, #1
    // 0xa6fd24: r17 = 10124
    //     0xa6fd24: mov             x17, #0x278c
    // 0xa6fd28: cmp             w3, w17
    // 0xa6fd2c: b.gt            #0xa6fd3c
    // 0xa6fd30: r17 = 10122
    //     0xa6fd30: mov             x17, #0x278a
    // 0xa6fd34: cmp             w3, w17
    // 0xa6fd38: b.ge            #0xa6fd54
    // 0xa6fd3c: r17 = 10114
    //     0xa6fd3c: mov             x17, #0x2782
    // 0xa6fd40: cmp             w3, w17
    // 0xa6fd44: b.eq            #0xa6fd54
    // 0xa6fd48: r17 = 10118
    //     0xa6fd48: mov             x17, #0x2786
    // 0xa6fd4c: cmp             w3, w17
    // 0xa6fd50: b.ne            #0xa6fd5c
    // 0xa6fd54: LoadField: r3 = r2->field_7
    //     0xa6fd54: ldur            x3, [x2, #7]
    // 0xa6fd58: b               #0xa6fd6c
    // 0xa6fd5c: LoadField: r3 = r2->field_f
    //     0xa6fd5c: ldur            w3, [x2, #0xf]
    // 0xa6fd60: DecompressPointer r3
    //     0xa6fd60: add             x3, x3, HEAP, lsl #32
    // 0xa6fd64: LoadField: r2 = r3->field_7
    //     0xa6fd64: ldur            x2, [x3, #7]
    // 0xa6fd68: mov             x3, x2
    // 0xa6fd6c: ldur            d0, [fp, #-0x30]
    // 0xa6fd70: r2 = 1
    //     0xa6fd70: mov             x2, #1
    // 0xa6fd74: eor             x4, x3, #0xff000000
    // 0xa6fd78: LoadField: r3 = r0->field_17
    //     0xa6fd78: ldur            w3, [x0, #0x17]
    // 0xa6fd7c: DecompressPointer r3
    //     0xa6fd7c: add             x3, x3, HEAP, lsl #32
    // 0xa6fd80: sxtw            x4, w4
    // 0xa6fd84: LoadField: r0 = r3->field_7
    //     0xa6fd84: ldur            x0, [x3, #7]
    // 0xa6fd88: str             w4, [x0, #4]
    // 0xa6fd8c: LoadField: r0 = r3->field_7
    //     0xa6fd8c: ldur            x0, [x3, #7]
    // 0xa6fd90: str             s0, [x0, #0x10]
    // 0xa6fd94: LoadField: r0 = r3->field_7
    //     0xa6fd94: ldur            x0, [x3, #7]
    // 0xa6fd98: str             w2, [x0, #0xc]
    // 0xa6fd9c: r16 = Instance_Offset
    //     0xa6fd9c: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa6fda0: ldr             lr, [fp, #0x10]
    // 0xa6fda4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6fda8: r0 = &()
    //     0xa6fda8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa6fdac: add             SP, SP, #0x10
    // 0xa6fdb0: ldr             x16, [fp, #0x18]
    // 0xa6fdb4: stp             x0, x16, [SP, #-0x10]!
    // 0xa6fdb8: r16 = 0.000000
    //     0xa6fdb8: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa6fdbc: SaveReg r16
    //     0xa6fdbc: str             x16, [SP, #-8]!
    // 0xa6fdc0: d0 = 6.282185
    //     0xa6fdc0: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d040] IMM: double(6.282185307179586) from 0x401920f52f66fdfd
    //     0xa6fdc4: ldr             d0, [x17, #0x40]
    // 0xa6fdc8: SaveReg d0
    //     0xa6fdc8: str             d0, [SP, #-8]!
    // 0xa6fdcc: ldur            x16, [fp, #-0x28]
    // 0xa6fdd0: SaveReg r16
    //     0xa6fdd0: str             x16, [SP, #-8]!
    // 0xa6fdd4: r0 = drawArc()
    //     0xa6fdd4: bl              #0xa6fe9c  ; [dart:ui] Canvas::drawArc
    // 0xa6fdd8: add             SP, SP, #0x28
    // 0xa6fddc: ldr             x0, [fp, #0x20]
    // 0xa6fde0: LoadField: r1 = r0->field_13
    //     0xa6fde0: ldur            w1, [x0, #0x13]
    // 0xa6fde4: DecompressPointer r1
    //     0xa6fde4: add             x1, x1, HEAP, lsl #32
    // 0xa6fde8: cmp             w1, NULL
    // 0xa6fdec: b.ne            #0xa6fe00
    // 0xa6fdf0: ldur            x1, [fp, #-0x10]
    // 0xa6fdf4: r2 = 2
    //     0xa6fdf4: mov             x2, #2
    // 0xa6fdf8: LoadField: r3 = r1->field_7
    //     0xa6fdf8: ldur            x3, [x1, #7]
    // 0xa6fdfc: str             w2, [x3, #0x14]
    // 0xa6fe00: r16 = Instance_Offset
    //     0xa6fe00: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa6fe04: ldr             lr, [fp, #0x10]
    // 0xa6fe08: stp             lr, x16, [SP, #-0x10]!
    // 0xa6fe0c: r0 = &()
    //     0xa6fe0c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa6fe10: add             SP, SP, #0x10
    // 0xa6fe14: mov             x1, x0
    // 0xa6fe18: ldr             x0, [fp, #0x20]
    // 0xa6fe1c: LoadField: d0 = r0->field_3f
    //     0xa6fe1c: ldur            d0, [x0, #0x3f]
    // 0xa6fe20: LoadField: d1 = r0->field_47
    //     0xa6fe20: ldur            d1, [x0, #0x47]
    // 0xa6fe24: r0 = inline_Allocate_Double()
    //     0xa6fe24: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xa6fe28: add             x0, x0, #0x10
    //     0xa6fe2c: cmp             x2, x0
    //     0xa6fe30: b.ls            #0xa6fe84
    //     0xa6fe34: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6fe38: sub             x0, x0, #0xf
    //     0xa6fe3c: mov             x2, #0xd108
    //     0xa6fe40: movk            x2, #3, lsl #16
    //     0xa6fe44: stur            x2, [x0, #-1]
    // 0xa6fe48: StoreField: r0->field_7 = d0
    //     0xa6fe48: stur            d0, [x0, #7]
    // 0xa6fe4c: ldr             x16, [fp, #0x18]
    // 0xa6fe50: stp             x1, x16, [SP, #-0x10]!
    // 0xa6fe54: SaveReg r0
    //     0xa6fe54: str             x0, [SP, #-8]!
    // 0xa6fe58: SaveReg d1
    //     0xa6fe58: str             d1, [SP, #-8]!
    // 0xa6fe5c: ldur            x16, [fp, #-0x18]
    // 0xa6fe60: SaveReg r16
    //     0xa6fe60: str             x16, [SP, #-8]!
    // 0xa6fe64: r0 = drawArc()
    //     0xa6fe64: bl              #0xa6fe9c  ; [dart:ui] Canvas::drawArc
    // 0xa6fe68: add             SP, SP, #0x28
    // 0xa6fe6c: r0 = Null
    //     0xa6fe6c: mov             x0, NULL
    // 0xa6fe70: LeaveFrame
    //     0xa6fe70: mov             SP, fp
    //     0xa6fe74: ldp             fp, lr, [SP], #0x10
    // 0xa6fe78: ret
    //     0xa6fe78: ret             
    // 0xa6fe7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6fe7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6fe80: b               #0xa6fc14
    // 0xa6fe84: stp             q0, q1, [SP, #-0x20]!
    // 0xa6fe88: SaveReg r1
    //     0xa6fe88: str             x1, [SP, #-8]!
    // 0xa6fe8c: r0 = AllocateDouble()
    //     0xa6fe8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6fe90: RestoreReg r1
    //     0xa6fe90: ldr             x1, [SP], #8
    // 0xa6fe94: ldp             q0, q1, [SP], #0x20
    // 0xa6fe98: b               #0xa6fe48
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa7a0e4, size: 0x2a4
    // 0xa7a0e4: EnterFrame
    //     0xa7a0e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa7a0e8: mov             fp, SP
    // 0xa7a0ec: AllocStack(0x18)
    //     0xa7a0ec: sub             SP, SP, #0x18
    // 0xa7a0f0: CheckStackOverflow
    //     0xa7a0f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa7a0f4: cmp             SP, x16
    //     0xa7a0f8: b.ls            #0xa7a380
    // 0xa7a0fc: ldr             x0, [fp, #0x10]
    // 0xa7a100: r2 = Null
    //     0xa7a100: mov             x2, NULL
    // 0xa7a104: r1 = Null
    //     0xa7a104: mov             x1, NULL
    // 0xa7a108: r4 = 59
    //     0xa7a108: mov             x4, #0x3b
    // 0xa7a10c: branchIfSmi(r0, 0xa7a118)
    //     0xa7a10c: tbz             w0, #0, #0xa7a118
    // 0xa7a110: r4 = LoadClassIdInstr(r0)
    //     0xa7a110: ldur            x4, [x0, #-1]
    //     0xa7a114: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a118: r17 = -4373
    //     0xa7a118: mov             x17, #-0x1115
    // 0xa7a11c: add             x4, x4, x17
    // 0xa7a120: cmp             x4, #1
    // 0xa7a124: b.ls            #0xa7a13c
    // 0xa7a128: r8 = _CircularProgressIndicatorPainter
    //     0xa7a128: add             x8, PP, #0x28, lsl #12  ; [pp+0x28998] Type: _CircularProgressIndicatorPainter
    //     0xa7a12c: ldr             x8, [x8, #0x998]
    // 0xa7a130: r3 = Null
    //     0xa7a130: add             x3, PP, #0x28, lsl #12  ; [pp+0x289a0] Null
    //     0xa7a134: ldr             x3, [x3, #0x9a0]
    // 0xa7a138: r0 = DefaultTypeTest()
    //     0xa7a138: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa7a13c: ldr             x1, [fp, #0x10]
    // 0xa7a140: LoadField: r0 = r1->field_b
    //     0xa7a140: ldur            w0, [x1, #0xb]
    // 0xa7a144: DecompressPointer r0
    //     0xa7a144: add             x0, x0, HEAP, lsl #32
    // 0xa7a148: ldr             x2, [fp, #0x18]
    // 0xa7a14c: LoadField: r3 = r2->field_b
    //     0xa7a14c: ldur            w3, [x2, #0xb]
    // 0xa7a150: DecompressPointer r3
    //     0xa7a150: add             x3, x3, HEAP, lsl #32
    // 0xa7a154: r4 = LoadClassIdInstr(r0)
    //     0xa7a154: ldur            x4, [x0, #-1]
    //     0xa7a158: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a15c: stp             x3, x0, [SP, #-0x10]!
    // 0xa7a160: mov             x0, x4
    // 0xa7a164: mov             lr, x0
    // 0xa7a168: ldr             lr, [x21, lr, lsl #3]
    // 0xa7a16c: blr             lr
    // 0xa7a170: add             SP, SP, #0x10
    // 0xa7a174: tbnz            w0, #4, #0xa7a350
    // 0xa7a178: ldr             x1, [fp, #0x18]
    // 0xa7a17c: ldr             x0, [fp, #0x10]
    // 0xa7a180: LoadField: r2 = r0->field_f
    //     0xa7a180: ldur            w2, [x0, #0xf]
    // 0xa7a184: DecompressPointer r2
    //     0xa7a184: add             x2, x2, HEAP, lsl #32
    // 0xa7a188: stur            x2, [fp, #-0x18]
    // 0xa7a18c: LoadField: r3 = r1->field_f
    //     0xa7a18c: ldur            w3, [x1, #0xf]
    // 0xa7a190: DecompressPointer r3
    //     0xa7a190: add             x3, x3, HEAP, lsl #32
    // 0xa7a194: stur            x3, [fp, #-0x10]
    // 0xa7a198: r4 = LoadClassIdInstr(r2)
    //     0xa7a198: ldur            x4, [x2, #-1]
    //     0xa7a19c: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a1a0: lsl             x4, x4, #1
    // 0xa7a1a4: stur            x4, [fp, #-8]
    // 0xa7a1a8: r17 = 10114
    //     0xa7a1a8: mov             x17, #0x2782
    // 0xa7a1ac: cmp             w4, w17
    // 0xa7a1b0: b.eq            #0xa7a1c0
    // 0xa7a1b4: r17 = 10118
    //     0xa7a1b4: mov             x17, #0x2786
    // 0xa7a1b8: cmp             w4, w17
    // 0xa7a1bc: b.ne            #0xa7a2a4
    // 0xa7a1c0: cmp             w2, w3
    // 0xa7a1c4: b.ne            #0xa7a1d4
    // 0xa7a1c8: mov             x2, x1
    // 0xa7a1cc: mov             x1, x0
    // 0xa7a1d0: b               #0xa7a2d4
    // 0xa7a1d4: stp             x2, x3, [SP, #-0x10]!
    // 0xa7a1d8: r0 = _haveSameRuntimeType()
    //     0xa7a1d8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa7a1dc: add             SP, SP, #0x10
    // 0xa7a1e0: tbnz            w0, #4, #0xa7a350
    // 0xa7a1e4: ldur            x0, [fp, #-0x10]
    // 0xa7a1e8: r1 = LoadClassIdInstr(r0)
    //     0xa7a1e8: ldur            x1, [x0, #-1]
    //     0xa7a1ec: ubfx            x1, x1, #0xc, #0x14
    // 0xa7a1f0: lsl             x1, x1, #1
    // 0xa7a1f4: r17 = 10124
    //     0xa7a1f4: mov             x17, #0x278c
    // 0xa7a1f8: cmp             w1, w17
    // 0xa7a1fc: b.gt            #0xa7a20c
    // 0xa7a200: r17 = 10122
    //     0xa7a200: mov             x17, #0x278a
    // 0xa7a204: cmp             w1, w17
    // 0xa7a208: b.ge            #0xa7a224
    // 0xa7a20c: r17 = 10114
    //     0xa7a20c: mov             x17, #0x2782
    // 0xa7a210: cmp             w1, w17
    // 0xa7a214: b.eq            #0xa7a224
    // 0xa7a218: r17 = 10118
    //     0xa7a218: mov             x17, #0x2786
    // 0xa7a21c: cmp             w1, w17
    // 0xa7a220: b.ne            #0xa7a22c
    // 0xa7a224: LoadField: r1 = r0->field_7
    //     0xa7a224: ldur            x1, [x0, #7]
    // 0xa7a228: b               #0xa7a23c
    // 0xa7a22c: LoadField: r1 = r0->field_f
    //     0xa7a22c: ldur            w1, [x0, #0xf]
    // 0xa7a230: DecompressPointer r1
    //     0xa7a230: add             x1, x1, HEAP, lsl #32
    // 0xa7a234: LoadField: r0 = r1->field_7
    //     0xa7a234: ldur            x0, [x1, #7]
    // 0xa7a238: mov             x1, x0
    // 0xa7a23c: ldur            x0, [fp, #-8]
    // 0xa7a240: r17 = 10124
    //     0xa7a240: mov             x17, #0x278c
    // 0xa7a244: cmp             w0, w17
    // 0xa7a248: b.gt            #0xa7a258
    // 0xa7a24c: r17 = 10122
    //     0xa7a24c: mov             x17, #0x278a
    // 0xa7a250: cmp             w0, w17
    // 0xa7a254: b.ge            #0xa7a270
    // 0xa7a258: r17 = 10114
    //     0xa7a258: mov             x17, #0x2782
    // 0xa7a25c: cmp             w0, w17
    // 0xa7a260: b.eq            #0xa7a270
    // 0xa7a264: r17 = 10118
    //     0xa7a264: mov             x17, #0x2786
    // 0xa7a268: cmp             w0, w17
    // 0xa7a26c: b.ne            #0xa7a27c
    // 0xa7a270: ldur            x2, [fp, #-0x18]
    // 0xa7a274: LoadField: r0 = r2->field_7
    //     0xa7a274: ldur            x0, [x2, #7]
    // 0xa7a278: b               #0xa7a290
    // 0xa7a27c: ldur            x2, [fp, #-0x18]
    // 0xa7a280: LoadField: r0 = r2->field_f
    //     0xa7a280: ldur            w0, [x2, #0xf]
    // 0xa7a284: DecompressPointer r0
    //     0xa7a284: add             x0, x0, HEAP, lsl #32
    // 0xa7a288: LoadField: r2 = r0->field_7
    //     0xa7a288: ldur            x2, [x0, #7]
    // 0xa7a28c: mov             x0, x2
    // 0xa7a290: cmp             x1, x0
    // 0xa7a294: b.ne            #0xa7a350
    // 0xa7a298: ldr             x2, [fp, #0x18]
    // 0xa7a29c: ldr             x1, [fp, #0x10]
    // 0xa7a2a0: b               #0xa7a2d4
    // 0xa7a2a4: mov             x0, x3
    // 0xa7a2a8: r1 = LoadClassIdInstr(r2)
    //     0xa7a2a8: ldur            x1, [x2, #-1]
    //     0xa7a2ac: ubfx            x1, x1, #0xc, #0x14
    // 0xa7a2b0: stp             x0, x2, [SP, #-0x10]!
    // 0xa7a2b4: mov             x0, x1
    // 0xa7a2b8: mov             lr, x0
    // 0xa7a2bc: ldr             lr, [x21, lr, lsl #3]
    // 0xa7a2c0: blr             lr
    // 0xa7a2c4: add             SP, SP, #0x10
    // 0xa7a2c8: tbnz            w0, #4, #0xa7a350
    // 0xa7a2cc: ldr             x2, [fp, #0x18]
    // 0xa7a2d0: ldr             x1, [fp, #0x10]
    // 0xa7a2d4: LoadField: r0 = r1->field_13
    //     0xa7a2d4: ldur            w0, [x1, #0x13]
    // 0xa7a2d8: DecompressPointer r0
    //     0xa7a2d8: add             x0, x0, HEAP, lsl #32
    // 0xa7a2dc: LoadField: r3 = r2->field_13
    //     0xa7a2dc: ldur            w3, [x2, #0x13]
    // 0xa7a2e0: DecompressPointer r3
    //     0xa7a2e0: add             x3, x3, HEAP, lsl #32
    // 0xa7a2e4: r4 = LoadClassIdInstr(r0)
    //     0xa7a2e4: ldur            x4, [x0, #-1]
    //     0xa7a2e8: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a2ec: stp             x3, x0, [SP, #-0x10]!
    // 0xa7a2f0: mov             x0, x4
    // 0xa7a2f4: mov             lr, x0
    // 0xa7a2f8: ldr             lr, [x21, lr, lsl #3]
    // 0xa7a2fc: blr             lr
    // 0xa7a300: add             SP, SP, #0x10
    // 0xa7a304: tbnz            w0, #4, #0xa7a350
    // 0xa7a308: ldr             x2, [fp, #0x18]
    // 0xa7a30c: ldr             x1, [fp, #0x10]
    // 0xa7a310: LoadField: d0 = r1->field_17
    //     0xa7a310: ldur            d0, [x1, #0x17]
    // 0xa7a314: LoadField: d1 = r2->field_17
    //     0xa7a314: ldur            d1, [x2, #0x17]
    // 0xa7a318: fcmp            d0, d1
    // 0xa7a31c: b.ne            #0xa7a350
    // 0xa7a320: LoadField: d0 = r1->field_1f
    //     0xa7a320: ldur            d0, [x1, #0x1f]
    // 0xa7a324: LoadField: d1 = r2->field_1f
    //     0xa7a324: ldur            d1, [x2, #0x1f]
    // 0xa7a328: fcmp            d0, d1
    // 0xa7a32c: b.ne            #0xa7a350
    // 0xa7a330: LoadField: d0 = r1->field_27
    //     0xa7a330: ldur            d0, [x1, #0x27]
    // 0xa7a334: LoadField: d1 = r2->field_27
    //     0xa7a334: ldur            d1, [x2, #0x27]
    // 0xa7a338: fcmp            d0, d1
    // 0xa7a33c: b.ne            #0xa7a350
    // 0xa7a340: LoadField: d0 = r1->field_2f
    //     0xa7a340: ldur            d0, [x1, #0x2f]
    // 0xa7a344: LoadField: d1 = r2->field_2f
    //     0xa7a344: ldur            d1, [x2, #0x2f]
    // 0xa7a348: fcmp            d0, d1
    // 0xa7a34c: b.eq            #0xa7a358
    // 0xa7a350: r0 = true
    //     0xa7a350: add             x0, NULL, #0x20  ; true
    // 0xa7a354: b               #0xa7a374
    // 0xa7a358: LoadField: d0 = r1->field_37
    //     0xa7a358: ldur            d0, [x1, #0x37]
    // 0xa7a35c: LoadField: d1 = r2->field_37
    //     0xa7a35c: ldur            d1, [x2, #0x37]
    // 0xa7a360: fcmp            d0, d1
    // 0xa7a364: r16 = true
    //     0xa7a364: add             x16, NULL, #0x20  ; true
    // 0xa7a368: r17 = false
    //     0xa7a368: add             x17, NULL, #0x30  ; false
    // 0xa7a36c: csel            x1, x16, x17, ne
    // 0xa7a370: mov             x0, x1
    // 0xa7a374: LeaveFrame
    //     0xa7a374: mov             SP, fp
    //     0xa7a378: ldp             fp, lr, [SP], #0x10
    // 0xa7a37c: ret
    //     0xa7a37c: ret             
    // 0xa7a380: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa7a380: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa7a384: b               #0xa7a0fc
  }
}

// class id: 4374, size: 0x58, field offset: 0x50
class _RefreshProgressIndicatorPainter extends _CircularProgressIndicatorPainter {

  _ _RefreshProgressIndicatorPainter(/* No info */) {
    // ** addr: 0x8636d8, size: 0x74
    // 0x8636d8: EnterFrame
    //     0x8636d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8636dc: mov             fp, SP
    // 0x8636e0: CheckStackOverflow
    //     0x8636e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8636e4: cmp             SP, x16
    //     0x8636e8: b.ls            #0x863744
    // 0x8636ec: ldr             x0, [fp, #0x40]
    // 0x8636f0: LoadField: d0 = r0->field_7
    //     0x8636f0: ldur            d0, [x0, #7]
    // 0x8636f4: ldr             x0, [fp, #0x48]
    // 0x8636f8: StoreField: r0->field_4f = d0
    //     0x8636f8: stur            d0, [x0, #0x4f]
    // 0x8636fc: ldr             x16, [fp, #0x38]
    // 0x863700: stp             x16, x0, [SP, #-0x10]!
    // 0x863704: ldr             x16, [fp, #0x30]
    // 0x863708: ldr             lr, [fp, #0x28]
    // 0x86370c: stp             lr, x16, [SP, #-0x10]!
    // 0x863710: ldr             x16, [fp, #0x20]
    // 0x863714: SaveReg r16
    //     0x863714: str             x16, [SP, #-8]!
    // 0x863718: ldr             d0, [fp, #0x18]
    // 0x86371c: SaveReg d0
    //     0x86371c: str             d0, [SP, #-8]!
    // 0x863720: ldr             x16, [fp, #0x10]
    // 0x863724: stp             x16, NULL, [SP, #-0x10]!
    // 0x863728: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0x863728: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0x86372c: r0 = _CircularProgressIndicatorPainter()
    //     0x86372c: bl              #0x86374c  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorPainter::_CircularProgressIndicatorPainter
    // 0x863730: add             SP, SP, #0x40
    // 0x863734: r0 = Null
    //     0x863734: mov             x0, NULL
    // 0x863738: LeaveFrame
    //     0x863738: mov             SP, fp
    //     0x86373c: ldp             fp, lr, [SP], #0x10
    // 0x863740: ret
    //     0x863740: ret             
    // 0x863744: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x863744: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x863748: b               #0x8636ec
  }
  _ paint(/* No info */) {
    // ** addr: 0xa6f81c, size: 0x78
    // 0xa6f81c: EnterFrame
    //     0xa6f81c: stp             fp, lr, [SP, #-0x10]!
    //     0xa6f820: mov             fp, SP
    // 0xa6f824: CheckStackOverflow
    //     0xa6f824: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6f828: cmp             SP, x16
    //     0xa6f82c: b.ls            #0xa6f88c
    // 0xa6f830: ldr             x16, [fp, #0x20]
    // 0xa6f834: ldr             lr, [fp, #0x18]
    // 0xa6f838: stp             lr, x16, [SP, #-0x10]!
    // 0xa6f83c: ldr             x16, [fp, #0x10]
    // 0xa6f840: SaveReg r16
    //     0xa6f840: str             x16, [SP, #-8]!
    // 0xa6f844: r0 = paint()
    //     0xa6f844: bl              #0xa6fbfc  ; [package:flutter/src/material/progress_indicator.dart] _CircularProgressIndicatorPainter::paint
    // 0xa6f848: add             SP, SP, #0x18
    // 0xa6f84c: ldr             x0, [fp, #0x20]
    // 0xa6f850: LoadField: d0 = r0->field_4f
    //     0xa6f850: ldur            d0, [x0, #0x4f]
    // 0xa6f854: d1 = 0.000000
    //     0xa6f854: eor             v1.16b, v1.16b, v1.16b
    // 0xa6f858: fcmp            d0, d1
    // 0xa6f85c: b.vs            #0xa6f87c
    // 0xa6f860: b.le            #0xa6f87c
    // 0xa6f864: ldr             x16, [fp, #0x18]
    // 0xa6f868: stp             x16, x0, [SP, #-0x10]!
    // 0xa6f86c: ldr             x16, [fp, #0x10]
    // 0xa6f870: SaveReg r16
    //     0xa6f870: str             x16, [SP, #-8]!
    // 0xa6f874: r0 = paintArrowhead()
    //     0xa6f874: bl              #0xa6f894  ; [package:flutter/src/material/progress_indicator.dart] _RefreshProgressIndicatorPainter::paintArrowhead
    // 0xa6f878: add             SP, SP, #0x18
    // 0xa6f87c: r0 = Null
    //     0xa6f87c: mov             x0, NULL
    // 0xa6f880: LeaveFrame
    //     0xa6f880: mov             SP, fp
    //     0xa6f884: ldp             fp, lr, [SP], #0x10
    // 0xa6f888: ret
    //     0xa6f888: ret             
    // 0xa6f88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6f88c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6f890: b               #0xa6f830
  }
  _ paintArrowhead(/* No info */) {
    // ** addr: 0xa6f894, size: 0x368
    // 0xa6f894: EnterFrame
    //     0xa6f894: stp             fp, lr, [SP, #-0x10]!
    //     0xa6f898: mov             fp, SP
    // 0xa6f89c: AllocStack(0x50)
    //     0xa6f89c: sub             SP, SP, #0x50
    // 0xa6f8a0: CheckStackOverflow
    //     0xa6f8a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6f8a4: cmp             SP, x16
    //     0xa6f8a8: b.ls            #0xa6fbb4
    // 0xa6f8ac: ldr             x0, [fp, #0x20]
    // 0xa6f8b0: LoadField: d0 = r0->field_3f
    //     0xa6f8b0: ldur            d0, [x0, #0x3f]
    // 0xa6f8b4: LoadField: d1 = r0->field_47
    //     0xa6f8b4: ldur            d1, [x0, #0x47]
    // 0xa6f8b8: fadd            d2, d0, d1
    // 0xa6f8bc: mov             v0.16b, v2.16b
    // 0xa6f8c0: stur            d2, [fp, #-0x18]
    // 0xa6f8c4: stp             fp, lr, [SP, #-0x10]!
    // 0xa6f8c8: mov             fp, SP
    // 0xa6f8cc: CallRuntime_LibcCos(double) -> double
    //     0xa6f8cc: and             SP, SP, #0xfffffffffffffff0
    //     0xa6f8d0: mov             sp, SP
    //     0xa6f8d4: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xa6f8d8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa6f8dc: blr             x16
    //     0xa6f8e0: mov             x16, #8
    //     0xa6f8e4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa6f8e8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xa6f8ec: sub             sp, x16, #1, lsl #12
    //     0xa6f8f0: mov             SP, fp
    //     0xa6f8f4: ldp             fp, lr, [SP], #0x10
    // 0xa6f8f8: mov             v1.16b, v0.16b
    // 0xa6f8fc: ldur            d0, [fp, #-0x18]
    // 0xa6f900: stur            d1, [fp, #-0x18]
    // 0xa6f904: stp             fp, lr, [SP, #-0x10]!
    // 0xa6f908: mov             fp, SP
    // 0xa6f90c: CallRuntime_LibcSin(double) -> double
    //     0xa6f90c: and             SP, SP, #0xfffffffffffffff0
    //     0xa6f910: mov             sp, SP
    //     0xa6f914: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xa6f918: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa6f91c: blr             x16
    //     0xa6f920: mov             x16, #8
    //     0xa6f924: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xa6f928: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xa6f92c: sub             sp, x16, #1, lsl #12
    //     0xa6f930: mov             SP, fp
    //     0xa6f934: ldp             fp, lr, [SP], #0x10
    // 0xa6f938: ldr             x0, [fp, #0x10]
    // 0xa6f93c: stur            d0, [fp, #-0x50]
    // 0xa6f940: LoadField: d1 = r0->field_7
    //     0xa6f940: ldur            d1, [x0, #7]
    // 0xa6f944: d2 = 2.000000
    //     0xa6f944: fmov            d2, #2.00000000
    // 0xa6f948: fdiv            d3, d1, d2
    // 0xa6f94c: ldur            d1, [fp, #-0x18]
    // 0xa6f950: stur            d3, [fp, #-0x48]
    // 0xa6f954: fmul            d4, d1, d3
    // 0xa6f958: fadd            d5, d3, d4
    // 0xa6f95c: fneg            d4, d0
    // 0xa6f960: ldr             x0, [fp, #0x20]
    // 0xa6f964: LoadField: d6 = r0->field_37
    //     0xa6f964: ldur            d6, [x0, #0x37]
    // 0xa6f968: stur            d6, [fp, #-0x40]
    // 0xa6f96c: fmul            d7, d4, d6
    // 0xa6f970: fmul            d4, d7, d2
    // 0xa6f974: LoadField: d7 = r0->field_4f
    //     0xa6f974: ldur            d7, [x0, #0x4f]
    // 0xa6f978: fmul            d8, d4, d7
    // 0xa6f97c: fadd            d4, d5, d8
    // 0xa6f980: stur            d4, [fp, #-0x38]
    // 0xa6f984: fmul            d5, d0, d3
    // 0xa6f988: fadd            d8, d3, d5
    // 0xa6f98c: fmul            d5, d1, d6
    // 0xa6f990: fmul            d9, d5, d2
    // 0xa6f994: fmul            d5, d9, d7
    // 0xa6f998: fadd            d9, d8, d5
    // 0xa6f99c: stur            d9, [fp, #-0x30]
    // 0xa6f9a0: fmul            d5, d6, d2
    // 0xa6f9a4: fmul            d2, d5, d7
    // 0xa6f9a8: fsub            d5, d3, d2
    // 0xa6f9ac: stur            d5, [fp, #-0x28]
    // 0xa6f9b0: fadd            d7, d3, d2
    // 0xa6f9b4: stur            d7, [fp, #-0x20]
    // 0xa6f9b8: r0 = Path()
    //     0xa6f9b8: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6f9bc: stur            x0, [fp, #-8]
    // 0xa6f9c0: SaveReg r0
    //     0xa6f9c0: str             x0, [SP, #-8]!
    // 0xa6f9c4: r0 = _constructor()
    //     0xa6f9c4: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6f9c8: add             SP, SP, #8
    // 0xa6f9cc: ldur            d1, [fp, #-0x28]
    // 0xa6f9d0: ldur            d0, [fp, #-0x18]
    // 0xa6f9d4: fmul            d2, d0, d1
    // 0xa6f9d8: ldur            d3, [fp, #-0x48]
    // 0xa6f9dc: fadd            d4, d3, d2
    // 0xa6f9e0: ldur            d2, [fp, #-0x50]
    // 0xa6f9e4: fmul            d5, d2, d1
    // 0xa6f9e8: fadd            d1, d3, d5
    // 0xa6f9ec: r0 = inline_Allocate_Double()
    //     0xa6f9ec: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6f9f0: add             x0, x0, #0x10
    //     0xa6f9f4: cmp             x1, x0
    //     0xa6f9f8: b.ls            #0xa6fbbc
    //     0xa6f9fc: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6fa00: sub             x0, x0, #0xf
    //     0xa6fa04: mov             x1, #0xd108
    //     0xa6fa08: movk            x1, #3, lsl #16
    //     0xa6fa0c: stur            x1, [x0, #-1]
    // 0xa6fa10: StoreField: r0->field_7 = d4
    //     0xa6fa10: stur            d4, [x0, #7]
    // 0xa6fa14: ldur            x16, [fp, #-8]
    // 0xa6fa18: stp             x0, x16, [SP, #-0x10]!
    // 0xa6fa1c: SaveReg d1
    //     0xa6fa1c: str             d1, [SP, #-8]!
    // 0xa6fa20: r0 = moveTo()
    //     0xa6fa20: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6fa24: add             SP, SP, #0x18
    // 0xa6fa28: ldur            d1, [fp, #-0x20]
    // 0xa6fa2c: ldur            d0, [fp, #-0x18]
    // 0xa6fa30: fmul            d2, d0, d1
    // 0xa6fa34: ldur            d0, [fp, #-0x48]
    // 0xa6fa38: fadd            d3, d0, d2
    // 0xa6fa3c: ldur            d2, [fp, #-0x50]
    // 0xa6fa40: fmul            d4, d2, d1
    // 0xa6fa44: fadd            d1, d0, d4
    // 0xa6fa48: r0 = inline_Allocate_Double()
    //     0xa6fa48: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6fa4c: add             x0, x0, #0x10
    //     0xa6fa50: cmp             x1, x0
    //     0xa6fa54: b.ls            #0xa6fbdc
    //     0xa6fa58: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6fa5c: sub             x0, x0, #0xf
    //     0xa6fa60: mov             x1, #0xd108
    //     0xa6fa64: movk            x1, #3, lsl #16
    //     0xa6fa68: stur            x1, [x0, #-1]
    // 0xa6fa6c: StoreField: r0->field_7 = d3
    //     0xa6fa6c: stur            d3, [x0, #7]
    // 0xa6fa70: ldur            x16, [fp, #-8]
    // 0xa6fa74: stp             x0, x16, [SP, #-0x10]!
    // 0xa6fa78: SaveReg d1
    //     0xa6fa78: str             d1, [SP, #-8]!
    // 0xa6fa7c: r0 = lineTo()
    //     0xa6fa7c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6fa80: add             SP, SP, #0x18
    // 0xa6fa84: ldur            d0, [fp, #-0x38]
    // 0xa6fa88: r0 = inline_Allocate_Double()
    //     0xa6fa88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6fa8c: add             x0, x0, #0x10
    //     0xa6fa90: cmp             x1, x0
    //     0xa6fa94: b.ls            #0xa6fbec
    //     0xa6fa98: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6fa9c: sub             x0, x0, #0xf
    //     0xa6faa0: mov             x1, #0xd108
    //     0xa6faa4: movk            x1, #3, lsl #16
    //     0xa6faa8: stur            x1, [x0, #-1]
    // 0xa6faac: StoreField: r0->field_7 = d0
    //     0xa6faac: stur            d0, [x0, #7]
    // 0xa6fab0: ldur            x16, [fp, #-8]
    // 0xa6fab4: stp             x0, x16, [SP, #-0x10]!
    // 0xa6fab8: ldur            d0, [fp, #-0x30]
    // 0xa6fabc: SaveReg d0
    //     0xa6fabc: str             d0, [SP, #-8]!
    // 0xa6fac0: r0 = lineTo()
    //     0xa6fac0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6fac4: add             SP, SP, #0x18
    // 0xa6fac8: ldur            x16, [fp, #-8]
    // 0xa6facc: SaveReg r16
    //     0xa6facc: str             x16, [SP, #-8]!
    // 0xa6fad0: r0 = close()
    //     0xa6fad0: bl              #0x668e78  ; [dart:ui] Path::close
    // 0xa6fad4: add             SP, SP, #8
    // 0xa6fad8: r16 = 112
    //     0xa6fad8: mov             x16, #0x70
    // 0xa6fadc: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6fae0: r0 = ByteData()
    //     0xa6fae0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6fae4: add             SP, SP, #0x10
    // 0xa6fae8: stur            x0, [fp, #-0x10]
    // 0xa6faec: r0 = Paint()
    //     0xa6faec: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6faf0: mov             x1, x0
    // 0xa6faf4: ldur            x0, [fp, #-0x10]
    // 0xa6faf8: StoreField: r1->field_7 = r0
    //     0xa6faf8: stur            w0, [x1, #7]
    // 0xa6fafc: ldr             x2, [fp, #0x20]
    // 0xa6fb00: LoadField: r3 = r2->field_f
    //     0xa6fb00: ldur            w3, [x2, #0xf]
    // 0xa6fb04: DecompressPointer r3
    //     0xa6fb04: add             x3, x3, HEAP, lsl #32
    // 0xa6fb08: r2 = LoadClassIdInstr(r3)
    //     0xa6fb08: ldur            x2, [x3, #-1]
    //     0xa6fb0c: ubfx            x2, x2, #0xc, #0x14
    // 0xa6fb10: lsl             x2, x2, #1
    // 0xa6fb14: r17 = 10124
    //     0xa6fb14: mov             x17, #0x278c
    // 0xa6fb18: cmp             w2, w17
    // 0xa6fb1c: b.gt            #0xa6fb2c
    // 0xa6fb20: r17 = 10122
    //     0xa6fb20: mov             x17, #0x278a
    // 0xa6fb24: cmp             w2, w17
    // 0xa6fb28: b.ge            #0xa6fb44
    // 0xa6fb2c: r17 = 10114
    //     0xa6fb2c: mov             x17, #0x2782
    // 0xa6fb30: cmp             w2, w17
    // 0xa6fb34: b.eq            #0xa6fb44
    // 0xa6fb38: r17 = 10118
    //     0xa6fb38: mov             x17, #0x2786
    // 0xa6fb3c: cmp             w2, w17
    // 0xa6fb40: b.ne            #0xa6fb4c
    // 0xa6fb44: LoadField: r2 = r3->field_7
    //     0xa6fb44: ldur            x2, [x3, #7]
    // 0xa6fb48: b               #0xa6fb5c
    // 0xa6fb4c: LoadField: r2 = r3->field_f
    //     0xa6fb4c: ldur            w2, [x3, #0xf]
    // 0xa6fb50: DecompressPointer r2
    //     0xa6fb50: add             x2, x2, HEAP, lsl #32
    // 0xa6fb54: LoadField: r3 = r2->field_7
    //     0xa6fb54: ldur            x3, [x2, #7]
    // 0xa6fb58: mov             x2, x3
    // 0xa6fb5c: ldur            d0, [fp, #-0x40]
    // 0xa6fb60: eor             x3, x2, #0xff000000
    // 0xa6fb64: LoadField: r2 = r0->field_17
    //     0xa6fb64: ldur            w2, [x0, #0x17]
    // 0xa6fb68: DecompressPointer r2
    //     0xa6fb68: add             x2, x2, HEAP, lsl #32
    // 0xa6fb6c: sxtw            x3, w3
    // 0xa6fb70: LoadField: r0 = r2->field_7
    //     0xa6fb70: ldur            x0, [x2, #7]
    // 0xa6fb74: str             w3, [x0, #4]
    // 0xa6fb78: fcvt            s1, d0
    // 0xa6fb7c: LoadField: r0 = r2->field_7
    //     0xa6fb7c: ldur            x0, [x2, #7]
    // 0xa6fb80: str             s1, [x0, #0x10]
    // 0xa6fb84: LoadField: r0 = r2->field_7
    //     0xa6fb84: ldur            x0, [x2, #7]
    // 0xa6fb88: str             wzr, [x0, #0xc]
    // 0xa6fb8c: ldr             x16, [fp, #0x18]
    // 0xa6fb90: ldur            lr, [fp, #-8]
    // 0xa6fb94: stp             lr, x16, [SP, #-0x10]!
    // 0xa6fb98: SaveReg r1
    //     0xa6fb98: str             x1, [SP, #-8]!
    // 0xa6fb9c: r0 = drawPath()
    //     0xa6fb9c: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6fba0: add             SP, SP, #0x18
    // 0xa6fba4: r0 = Null
    //     0xa6fba4: mov             x0, NULL
    // 0xa6fba8: LeaveFrame
    //     0xa6fba8: mov             SP, fp
    //     0xa6fbac: ldp             fp, lr, [SP], #0x10
    // 0xa6fbb0: ret
    //     0xa6fbb0: ret             
    // 0xa6fbb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6fbb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6fbb8: b               #0xa6f8ac
    // 0xa6fbbc: stp             q3, q4, [SP, #-0x20]!
    // 0xa6fbc0: stp             q1, q2, [SP, #-0x20]!
    // 0xa6fbc4: SaveReg d0
    //     0xa6fbc4: str             q0, [SP, #-0x10]!
    // 0xa6fbc8: r0 = AllocateDouble()
    //     0xa6fbc8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6fbcc: RestoreReg d0
    //     0xa6fbcc: ldr             q0, [SP], #0x10
    // 0xa6fbd0: ldp             q1, q2, [SP], #0x20
    // 0xa6fbd4: ldp             q3, q4, [SP], #0x20
    // 0xa6fbd8: b               #0xa6fa10
    // 0xa6fbdc: stp             q1, q3, [SP, #-0x20]!
    // 0xa6fbe0: r0 = AllocateDouble()
    //     0xa6fbe0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6fbe4: ldp             q1, q3, [SP], #0x20
    // 0xa6fbe8: b               #0xa6fa6c
    // 0xa6fbec: SaveReg d0
    //     0xa6fbec: str             q0, [SP, #-0x10]!
    // 0xa6fbf0: r0 = AllocateDouble()
    //     0xa6fbf0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6fbf4: RestoreReg d0
    //     0xa6fbf4: ldr             q0, [SP], #0x10
    // 0xa6fbf8: b               #0xa6faac
  }
}

// class id: 4375, size: 0x24, field offset: 0xc
//   const constructor, 
class _LinearProgressIndicatorPainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa6f1b0, size: 0x534
    // 0xa6f1b0: EnterFrame
    //     0xa6f1b0: stp             fp, lr, [SP, #-0x10]!
    //     0xa6f1b4: mov             fp, SP
    // 0xa6f1b8: AllocStack(0x48)
    //     0xa6f1b8: sub             SP, SP, #0x48
    // 0xa6f1bc: CheckStackOverflow
    //     0xa6f1bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6f1c0: cmp             SP, x16
    //     0xa6f1c4: b.ls            #0xa6f65c
    // 0xa6f1c8: r1 = 4
    //     0xa6f1c8: mov             x1, #4
    // 0xa6f1cc: r0 = AllocateContext()
    //     0xa6f1cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa6f1d0: mov             x1, x0
    // 0xa6f1d4: ldr             x0, [fp, #0x20]
    // 0xa6f1d8: stur            x1, [fp, #-8]
    // 0xa6f1dc: StoreField: r1->field_f = r0
    //     0xa6f1dc: stur            w0, [x1, #0xf]
    // 0xa6f1e0: ldr             x2, [fp, #0x18]
    // 0xa6f1e4: StoreField: r1->field_13 = r2
    //     0xa6f1e4: stur            w2, [x1, #0x13]
    // 0xa6f1e8: ldr             x2, [fp, #0x10]
    // 0xa6f1ec: StoreField: r1->field_17 = r2
    //     0xa6f1ec: stur            w2, [x1, #0x17]
    // 0xa6f1f0: r16 = 112
    //     0xa6f1f0: mov             x16, #0x70
    // 0xa6f1f4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6f1f8: r0 = ByteData()
    //     0xa6f1f8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6f1fc: add             SP, SP, #0x10
    // 0xa6f200: stur            x0, [fp, #-0x10]
    // 0xa6f204: r0 = Paint()
    //     0xa6f204: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6f208: mov             x1, x0
    // 0xa6f20c: ldur            x0, [fp, #-0x10]
    // 0xa6f210: stur            x1, [fp, #-0x20]
    // 0xa6f214: StoreField: r1->field_7 = r0
    //     0xa6f214: stur            w0, [x1, #7]
    // 0xa6f218: ldr             x2, [fp, #0x20]
    // 0xa6f21c: LoadField: r3 = r2->field_b
    //     0xa6f21c: ldur            w3, [x2, #0xb]
    // 0xa6f220: DecompressPointer r3
    //     0xa6f220: add             x3, x3, HEAP, lsl #32
    // 0xa6f224: r4 = LoadClassIdInstr(r3)
    //     0xa6f224: ldur            x4, [x3, #-1]
    //     0xa6f228: ubfx            x4, x4, #0xc, #0x14
    // 0xa6f22c: lsl             x4, x4, #1
    // 0xa6f230: r17 = 10124
    //     0xa6f230: mov             x17, #0x278c
    // 0xa6f234: cmp             w4, w17
    // 0xa6f238: b.gt            #0xa6f248
    // 0xa6f23c: r17 = 10122
    //     0xa6f23c: mov             x17, #0x278a
    // 0xa6f240: cmp             w4, w17
    // 0xa6f244: b.ge            #0xa6f260
    // 0xa6f248: r17 = 10114
    //     0xa6f248: mov             x17, #0x2782
    // 0xa6f24c: cmp             w4, w17
    // 0xa6f250: b.eq            #0xa6f260
    // 0xa6f254: r17 = 10118
    //     0xa6f254: mov             x17, #0x2786
    // 0xa6f258: cmp             w4, w17
    // 0xa6f25c: b.ne            #0xa6f268
    // 0xa6f260: LoadField: r4 = r3->field_7
    //     0xa6f260: ldur            x4, [x3, #7]
    // 0xa6f264: b               #0xa6f278
    // 0xa6f268: LoadField: r4 = r3->field_f
    //     0xa6f268: ldur            w4, [x3, #0xf]
    // 0xa6f26c: DecompressPointer r4
    //     0xa6f26c: add             x4, x4, HEAP, lsl #32
    // 0xa6f270: LoadField: r3 = r4->field_7
    //     0xa6f270: ldur            x3, [x4, #7]
    // 0xa6f274: mov             x4, x3
    // 0xa6f278: ldur            x3, [fp, #-8]
    // 0xa6f27c: eor             x5, x4, #0xff000000
    // 0xa6f280: LoadField: r4 = r0->field_17
    //     0xa6f280: ldur            w4, [x0, #0x17]
    // 0xa6f284: DecompressPointer r4
    //     0xa6f284: add             x4, x4, HEAP, lsl #32
    // 0xa6f288: stur            x4, [fp, #-0x18]
    // 0xa6f28c: sxtw            x5, w5
    // 0xa6f290: LoadField: r0 = r4->field_7
    //     0xa6f290: ldur            x0, [x4, #7]
    // 0xa6f294: str             w5, [x0, #4]
    // 0xa6f298: LoadField: r0 = r4->field_7
    //     0xa6f298: ldur            x0, [x4, #7]
    // 0xa6f29c: str             wzr, [x0, #0xc]
    // 0xa6f2a0: mov             x0, x1
    // 0xa6f2a4: StoreField: r3->field_1b = r0
    //     0xa6f2a4: stur            w0, [x3, #0x1b]
    //     0xa6f2a8: ldurb           w16, [x3, #-1]
    //     0xa6f2ac: ldurb           w17, [x0, #-1]
    //     0xa6f2b0: and             x16, x17, x16, lsr #2
    //     0xa6f2b4: tst             x16, HEAP, lsr #32
    //     0xa6f2b8: b.eq            #0xa6f2c0
    //     0xa6f2bc: bl              #0xd682ac
    // 0xa6f2c0: LoadField: r0 = r3->field_13
    //     0xa6f2c0: ldur            w0, [x3, #0x13]
    // 0xa6f2c4: DecompressPointer r0
    //     0xa6f2c4: add             x0, x0, HEAP, lsl #32
    // 0xa6f2c8: stur            x0, [fp, #-0x10]
    // 0xa6f2cc: LoadField: r5 = r3->field_17
    //     0xa6f2cc: ldur            w5, [x3, #0x17]
    // 0xa6f2d0: DecompressPointer r5
    //     0xa6f2d0: add             x5, x5, HEAP, lsl #32
    // 0xa6f2d4: r16 = Instance_Offset
    //     0xa6f2d4: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa6f2d8: stp             x5, x16, [SP, #-0x10]!
    // 0xa6f2dc: r0 = &()
    //     0xa6f2dc: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa6f2e0: add             SP, SP, #0x10
    // 0xa6f2e4: ldur            x16, [fp, #-0x10]
    // 0xa6f2e8: stp             x0, x16, [SP, #-0x10]!
    // 0xa6f2ec: ldur            x16, [fp, #-0x20]
    // 0xa6f2f0: SaveReg r16
    //     0xa6f2f0: str             x16, [SP, #-8]!
    // 0xa6f2f4: r0 = drawRect()
    //     0xa6f2f4: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xa6f2f8: add             SP, SP, #0x18
    // 0xa6f2fc: ldr             x0, [fp, #0x20]
    // 0xa6f300: LoadField: r1 = r0->field_f
    //     0xa6f300: ldur            w1, [x0, #0xf]
    // 0xa6f304: DecompressPointer r1
    //     0xa6f304: add             x1, x1, HEAP, lsl #32
    // 0xa6f308: r2 = LoadClassIdInstr(r1)
    //     0xa6f308: ldur            x2, [x1, #-1]
    //     0xa6f30c: ubfx            x2, x2, #0xc, #0x14
    // 0xa6f310: lsl             x2, x2, #1
    // 0xa6f314: r17 = 10124
    //     0xa6f314: mov             x17, #0x278c
    // 0xa6f318: cmp             w2, w17
    // 0xa6f31c: b.gt            #0xa6f32c
    // 0xa6f320: r17 = 10122
    //     0xa6f320: mov             x17, #0x278a
    // 0xa6f324: cmp             w2, w17
    // 0xa6f328: b.ge            #0xa6f344
    // 0xa6f32c: r17 = 10114
    //     0xa6f32c: mov             x17, #0x2782
    // 0xa6f330: cmp             w2, w17
    // 0xa6f334: b.eq            #0xa6f344
    // 0xa6f338: r17 = 10118
    //     0xa6f338: mov             x17, #0x2786
    // 0xa6f33c: cmp             w2, w17
    // 0xa6f340: b.ne            #0xa6f34c
    // 0xa6f344: LoadField: r2 = r1->field_7
    //     0xa6f344: ldur            x2, [x1, #7]
    // 0xa6f348: b               #0xa6f35c
    // 0xa6f34c: LoadField: r2 = r1->field_f
    //     0xa6f34c: ldur            w2, [x1, #0xf]
    // 0xa6f350: DecompressPointer r2
    //     0xa6f350: add             x2, x2, HEAP, lsl #32
    // 0xa6f354: LoadField: r1 = r2->field_7
    //     0xa6f354: ldur            x1, [x2, #7]
    // 0xa6f358: mov             x2, x1
    // 0xa6f35c: ldur            x1, [fp, #-0x18]
    // 0xa6f360: eor             x3, x2, #0xff000000
    // 0xa6f364: sxtw            x3, w3
    // 0xa6f368: LoadField: r2 = r1->field_7
    //     0xa6f368: ldur            x2, [x1, #7]
    // 0xa6f36c: str             w3, [x2, #4]
    // 0xa6f370: ldur            x2, [fp, #-8]
    // 0xa6f374: r1 = Function 'drawBar':.
    //     0xa6f374: add             x1, PP, #0x50, lsl #12  ; [pp+0x508d8] AnonymousClosure: (0xa6f6e4), in [package:flutter/src/material/progress_indicator.dart] _LinearProgressIndicatorPainter::paint (0xa6f1b0)
    //     0xa6f378: ldr             x1, [x1, #0x8d8]
    // 0xa6f37c: r0 = AllocateClosure()
    //     0xa6f37c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa6f380: mov             x1, x0
    // 0xa6f384: ldr             x0, [fp, #0x20]
    // 0xa6f388: stur            x1, [fp, #-0x10]
    // 0xa6f38c: LoadField: r2 = r0->field_13
    //     0xa6f38c: ldur            w2, [x0, #0x13]
    // 0xa6f390: DecompressPointer r2
    //     0xa6f390: add             x2, x2, HEAP, lsl #32
    // 0xa6f394: cmp             w2, NULL
    // 0xa6f398: b.eq            #0xa6f448
    // 0xa6f39c: d0 = 0.000000
    //     0xa6f39c: eor             v0.16b, v0.16b, v0.16b
    // 0xa6f3a0: LoadField: d1 = r2->field_7
    //     0xa6f3a0: ldur            d1, [x2, #7]
    // 0xa6f3a4: fcmp            d1, d0
    // 0xa6f3a8: b.vs            #0xa6f3b8
    // 0xa6f3ac: b.ge            #0xa6f3b8
    // 0xa6f3b0: d0 = 0.000000
    //     0xa6f3b0: eor             v0.16b, v0.16b, v0.16b
    // 0xa6f3b4: b               #0xa6f3e8
    // 0xa6f3b8: d0 = 1.000000
    //     0xa6f3b8: fmov            d0, #1.00000000
    // 0xa6f3bc: fcmp            d1, d0
    // 0xa6f3c0: b.vs            #0xa6f3d0
    // 0xa6f3c4: b.le            #0xa6f3d0
    // 0xa6f3c8: d0 = 1.000000
    //     0xa6f3c8: fmov            d0, #1.00000000
    // 0xa6f3cc: b               #0xa6f3e8
    // 0xa6f3d0: LoadField: d0 = r2->field_7
    //     0xa6f3d0: ldur            d0, [x2, #7]
    // 0xa6f3d4: fcmp            d0, d0
    // 0xa6f3d8: b.vc            #0xa6f3e4
    // 0xa6f3dc: d0 = 1.000000
    //     0xa6f3dc: fmov            d0, #1.00000000
    // 0xa6f3e0: b               #0xa6f3e8
    // 0xa6f3e4: mov             v0.16b, v1.16b
    // 0xa6f3e8: ldur            x2, [fp, #-8]
    // 0xa6f3ec: LoadField: r0 = r2->field_17
    //     0xa6f3ec: ldur            w0, [x2, #0x17]
    // 0xa6f3f0: DecompressPointer r0
    //     0xa6f3f0: add             x0, x0, HEAP, lsl #32
    // 0xa6f3f4: LoadField: d1 = r0->field_7
    //     0xa6f3f4: ldur            d1, [x0, #7]
    // 0xa6f3f8: fmul            d2, d0, d1
    // 0xa6f3fc: r0 = inline_Allocate_Double()
    //     0xa6f3fc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xa6f400: add             x0, x0, #0x10
    //     0xa6f404: cmp             x2, x0
    //     0xa6f408: b.ls            #0xa6f664
    //     0xa6f40c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6f410: sub             x0, x0, #0xf
    //     0xa6f414: mov             x2, #0xd108
    //     0xa6f418: movk            x2, #3, lsl #16
    //     0xa6f41c: stur            x2, [x0, #-1]
    // 0xa6f420: StoreField: r0->field_7 = d2
    //     0xa6f420: stur            d2, [x0, #7]
    // 0xa6f424: r16 = 0.000000
    //     0xa6f424: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa6f428: stp             x16, x1, [SP, #-0x10]!
    // 0xa6f42c: SaveReg r0
    //     0xa6f42c: str             x0, [SP, #-8]!
    // 0xa6f430: mov             x0, x1
    // 0xa6f434: ClosureCall
    //     0xa6f434: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xa6f438: ldur            x2, [x0, #0x1f]
    //     0xa6f43c: blr             x2
    // 0xa6f440: add             SP, SP, #0x18
    // 0xa6f444: b               #0xa6f64c
    // 0xa6f448: ldur            x2, [fp, #-8]
    // 0xa6f44c: LoadField: r3 = r2->field_17
    //     0xa6f44c: ldur            w3, [x2, #0x17]
    // 0xa6f450: DecompressPointer r3
    //     0xa6f450: add             x3, x3, HEAP, lsl #32
    // 0xa6f454: LoadField: d0 = r3->field_7
    //     0xa6f454: ldur            d0, [x3, #7]
    // 0xa6f458: stur            d0, [fp, #-0x30]
    // 0xa6f45c: LoadField: d1 = r0->field_17
    //     0xa6f45c: ldur            d1, [x0, #0x17]
    // 0xa6f460: stur            d1, [fp, #-0x28]
    // 0xa6f464: r16 = Instance_Interval
    //     0xa6f464: add             x16, PP, #0x50, lsl #12  ; [pp+0x508e0] Obj!Interval<double>@b4fc01
    //     0xa6f468: ldr             x16, [x16, #0x8e0]
    // 0xa6f46c: SaveReg r16
    //     0xa6f46c: str             x16, [SP, #-8]!
    // 0xa6f470: SaveReg d1
    //     0xa6f470: str             d1, [SP, #-8]!
    // 0xa6f474: r0 = transform()
    //     0xa6f474: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xa6f478: add             SP, SP, #0x10
    // 0xa6f47c: LoadField: d0 = r0->field_7
    //     0xa6f47c: ldur            d0, [x0, #7]
    // 0xa6f480: ldur            d1, [fp, #-0x30]
    // 0xa6f484: fmul            d2, d1, d0
    // 0xa6f488: ldur            x0, [fp, #-8]
    // 0xa6f48c: stur            d2, [fp, #-0x38]
    // 0xa6f490: LoadField: r1 = r0->field_17
    //     0xa6f490: ldur            w1, [x0, #0x17]
    // 0xa6f494: DecompressPointer r1
    //     0xa6f494: add             x1, x1, HEAP, lsl #32
    // 0xa6f498: LoadField: d0 = r1->field_7
    //     0xa6f498: ldur            d0, [x1, #7]
    // 0xa6f49c: stur            d0, [fp, #-0x30]
    // 0xa6f4a0: r16 = Instance_Interval
    //     0xa6f4a0: add             x16, PP, #0x50, lsl #12  ; [pp+0x508e8] Obj!Interval<double>@b4fbe1
    //     0xa6f4a4: ldr             x16, [x16, #0x8e8]
    // 0xa6f4a8: SaveReg r16
    //     0xa6f4a8: str             x16, [SP, #-8]!
    // 0xa6f4ac: ldur            d1, [fp, #-0x28]
    // 0xa6f4b0: SaveReg d1
    //     0xa6f4b0: str             d1, [SP, #-8]!
    // 0xa6f4b4: r0 = transform()
    //     0xa6f4b4: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xa6f4b8: add             SP, SP, #0x10
    // 0xa6f4bc: LoadField: d0 = r0->field_7
    //     0xa6f4bc: ldur            d0, [x0, #7]
    // 0xa6f4c0: ldur            d1, [fp, #-0x30]
    // 0xa6f4c4: fmul            d2, d1, d0
    // 0xa6f4c8: ldur            d0, [fp, #-0x38]
    // 0xa6f4cc: fsub            d1, d2, d0
    // 0xa6f4d0: ldur            x0, [fp, #-8]
    // 0xa6f4d4: stur            d1, [fp, #-0x40]
    // 0xa6f4d8: LoadField: r1 = r0->field_17
    //     0xa6f4d8: ldur            w1, [x0, #0x17]
    // 0xa6f4dc: DecompressPointer r1
    //     0xa6f4dc: add             x1, x1, HEAP, lsl #32
    // 0xa6f4e0: LoadField: d2 = r1->field_7
    //     0xa6f4e0: ldur            d2, [x1, #7]
    // 0xa6f4e4: stur            d2, [fp, #-0x30]
    // 0xa6f4e8: r16 = Instance_Interval
    //     0xa6f4e8: add             x16, PP, #0x50, lsl #12  ; [pp+0x508f0] Obj!Interval<double>@b4fbc1
    //     0xa6f4ec: ldr             x16, [x16, #0x8f0]
    // 0xa6f4f0: SaveReg r16
    //     0xa6f4f0: str             x16, [SP, #-8]!
    // 0xa6f4f4: ldur            d3, [fp, #-0x28]
    // 0xa6f4f8: SaveReg d3
    //     0xa6f4f8: str             d3, [SP, #-8]!
    // 0xa6f4fc: r0 = transform()
    //     0xa6f4fc: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xa6f500: add             SP, SP, #0x10
    // 0xa6f504: LoadField: d0 = r0->field_7
    //     0xa6f504: ldur            d0, [x0, #7]
    // 0xa6f508: ldur            d1, [fp, #-0x30]
    // 0xa6f50c: fmul            d2, d1, d0
    // 0xa6f510: ldur            x0, [fp, #-8]
    // 0xa6f514: stur            d2, [fp, #-0x48]
    // 0xa6f518: LoadField: r1 = r0->field_17
    //     0xa6f518: ldur            w1, [x0, #0x17]
    // 0xa6f51c: DecompressPointer r1
    //     0xa6f51c: add             x1, x1, HEAP, lsl #32
    // 0xa6f520: LoadField: d0 = r1->field_7
    //     0xa6f520: ldur            d0, [x1, #7]
    // 0xa6f524: stur            d0, [fp, #-0x30]
    // 0xa6f528: r16 = Instance_Interval
    //     0xa6f528: add             x16, PP, #0x50, lsl #12  ; [pp+0x508f8] Obj!Interval<double>@b4fba1
    //     0xa6f52c: ldr             x16, [x16, #0x8f8]
    // 0xa6f530: SaveReg r16
    //     0xa6f530: str             x16, [SP, #-8]!
    // 0xa6f534: ldur            d1, [fp, #-0x28]
    // 0xa6f538: SaveReg d1
    //     0xa6f538: str             d1, [SP, #-8]!
    // 0xa6f53c: r0 = transform()
    //     0xa6f53c: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xa6f540: add             SP, SP, #0x10
    // 0xa6f544: LoadField: d0 = r0->field_7
    //     0xa6f544: ldur            d0, [x0, #7]
    // 0xa6f548: ldur            d1, [fp, #-0x30]
    // 0xa6f54c: fmul            d2, d1, d0
    // 0xa6f550: ldur            d0, [fp, #-0x48]
    // 0xa6f554: fsub            d1, d2, d0
    // 0xa6f558: ldur            d2, [fp, #-0x38]
    // 0xa6f55c: stur            d1, [fp, #-0x28]
    // 0xa6f560: r0 = inline_Allocate_Double()
    //     0xa6f560: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6f564: add             x0, x0, #0x10
    //     0xa6f568: cmp             x1, x0
    //     0xa6f56c: b.ls            #0xa6f67c
    //     0xa6f570: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6f574: sub             x0, x0, #0xf
    //     0xa6f578: mov             x1, #0xd108
    //     0xa6f57c: movk            x1, #3, lsl #16
    //     0xa6f580: stur            x1, [x0, #-1]
    // 0xa6f584: StoreField: r0->field_7 = d2
    //     0xa6f584: stur            d2, [x0, #7]
    // 0xa6f588: ldur            d2, [fp, #-0x40]
    // 0xa6f58c: r1 = inline_Allocate_Double()
    //     0xa6f58c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa6f590: add             x1, x1, #0x10
    //     0xa6f594: cmp             x2, x1
    //     0xa6f598: b.ls            #0xa6f694
    //     0xa6f59c: str             x1, [THR, #0x60]  ; THR::top
    //     0xa6f5a0: sub             x1, x1, #0xf
    //     0xa6f5a4: mov             x2, #0xd108
    //     0xa6f5a8: movk            x2, #3, lsl #16
    //     0xa6f5ac: stur            x2, [x1, #-1]
    // 0xa6f5b0: StoreField: r1->field_7 = d2
    //     0xa6f5b0: stur            d2, [x1, #7]
    // 0xa6f5b4: ldur            x16, [fp, #-0x10]
    // 0xa6f5b8: stp             x0, x16, [SP, #-0x10]!
    // 0xa6f5bc: SaveReg r1
    //     0xa6f5bc: str             x1, [SP, #-8]!
    // 0xa6f5c0: ldur            x0, [fp, #-0x10]
    // 0xa6f5c4: ClosureCall
    //     0xa6f5c4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xa6f5c8: ldur            x2, [x0, #0x1f]
    //     0xa6f5cc: blr             x2
    // 0xa6f5d0: add             SP, SP, #0x18
    // 0xa6f5d4: ldur            d0, [fp, #-0x48]
    // 0xa6f5d8: r0 = inline_Allocate_Double()
    //     0xa6f5d8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6f5dc: add             x0, x0, #0x10
    //     0xa6f5e0: cmp             x1, x0
    //     0xa6f5e4: b.ls            #0xa6f6b8
    //     0xa6f5e8: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6f5ec: sub             x0, x0, #0xf
    //     0xa6f5f0: mov             x1, #0xd108
    //     0xa6f5f4: movk            x1, #3, lsl #16
    //     0xa6f5f8: stur            x1, [x0, #-1]
    // 0xa6f5fc: StoreField: r0->field_7 = d0
    //     0xa6f5fc: stur            d0, [x0, #7]
    // 0xa6f600: ldur            d0, [fp, #-0x28]
    // 0xa6f604: r1 = inline_Allocate_Double()
    //     0xa6f604: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa6f608: add             x1, x1, #0x10
    //     0xa6f60c: cmp             x2, x1
    //     0xa6f610: b.ls            #0xa6f6c8
    //     0xa6f614: str             x1, [THR, #0x60]  ; THR::top
    //     0xa6f618: sub             x1, x1, #0xf
    //     0xa6f61c: mov             x2, #0xd108
    //     0xa6f620: movk            x2, #3, lsl #16
    //     0xa6f624: stur            x2, [x1, #-1]
    // 0xa6f628: StoreField: r1->field_7 = d0
    //     0xa6f628: stur            d0, [x1, #7]
    // 0xa6f62c: ldur            x16, [fp, #-0x10]
    // 0xa6f630: stp             x0, x16, [SP, #-0x10]!
    // 0xa6f634: SaveReg r1
    //     0xa6f634: str             x1, [SP, #-8]!
    // 0xa6f638: ldur            x0, [fp, #-0x10]
    // 0xa6f63c: ClosureCall
    //     0xa6f63c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xa6f640: ldur            x2, [x0, #0x1f]
    //     0xa6f644: blr             x2
    // 0xa6f648: add             SP, SP, #0x18
    // 0xa6f64c: r0 = Null
    //     0xa6f64c: mov             x0, NULL
    // 0xa6f650: LeaveFrame
    //     0xa6f650: mov             SP, fp
    //     0xa6f654: ldp             fp, lr, [SP], #0x10
    // 0xa6f658: ret
    //     0xa6f658: ret             
    // 0xa6f65c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6f65c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6f660: b               #0xa6f1c8
    // 0xa6f664: SaveReg d2
    //     0xa6f664: str             q2, [SP, #-0x10]!
    // 0xa6f668: SaveReg r1
    //     0xa6f668: str             x1, [SP, #-8]!
    // 0xa6f66c: r0 = AllocateDouble()
    //     0xa6f66c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6f670: RestoreReg r1
    //     0xa6f670: ldr             x1, [SP], #8
    // 0xa6f674: RestoreReg d2
    //     0xa6f674: ldr             q2, [SP], #0x10
    // 0xa6f678: b               #0xa6f420
    // 0xa6f67c: stp             q1, q2, [SP, #-0x20]!
    // 0xa6f680: SaveReg d0
    //     0xa6f680: str             q0, [SP, #-0x10]!
    // 0xa6f684: r0 = AllocateDouble()
    //     0xa6f684: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6f688: RestoreReg d0
    //     0xa6f688: ldr             q0, [SP], #0x10
    // 0xa6f68c: ldp             q1, q2, [SP], #0x20
    // 0xa6f690: b               #0xa6f584
    // 0xa6f694: stp             q1, q2, [SP, #-0x20]!
    // 0xa6f698: SaveReg d0
    //     0xa6f698: str             q0, [SP, #-0x10]!
    // 0xa6f69c: SaveReg r0
    //     0xa6f69c: str             x0, [SP, #-8]!
    // 0xa6f6a0: r0 = AllocateDouble()
    //     0xa6f6a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6f6a4: mov             x1, x0
    // 0xa6f6a8: RestoreReg r0
    //     0xa6f6a8: ldr             x0, [SP], #8
    // 0xa6f6ac: RestoreReg d0
    //     0xa6f6ac: ldr             q0, [SP], #0x10
    // 0xa6f6b0: ldp             q1, q2, [SP], #0x20
    // 0xa6f6b4: b               #0xa6f5b0
    // 0xa6f6b8: SaveReg d0
    //     0xa6f6b8: str             q0, [SP, #-0x10]!
    // 0xa6f6bc: r0 = AllocateDouble()
    //     0xa6f6bc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6f6c0: RestoreReg d0
    //     0xa6f6c0: ldr             q0, [SP], #0x10
    // 0xa6f6c4: b               #0xa6f5fc
    // 0xa6f6c8: SaveReg d0
    //     0xa6f6c8: str             q0, [SP, #-0x10]!
    // 0xa6f6cc: SaveReg r0
    //     0xa6f6cc: str             x0, [SP, #-8]!
    // 0xa6f6d0: r0 = AllocateDouble()
    //     0xa6f6d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6f6d4: mov             x1, x0
    // 0xa6f6d8: RestoreReg r0
    //     0xa6f6d8: ldr             x0, [SP], #8
    // 0xa6f6dc: RestoreReg d0
    //     0xa6f6dc: ldr             q0, [SP], #0x10
    // 0xa6f6e0: b               #0xa6f628
  }
  [closure] void drawBar(dynamic, double, double) {
    // ** addr: 0xa6f6e4, size: 0x138
    // 0xa6f6e4: EnterFrame
    //     0xa6f6e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa6f6e8: mov             fp, SP
    // 0xa6f6ec: AllocStack(0x28)
    //     0xa6f6ec: sub             SP, SP, #0x28
    // 0xa6f6f0: SetupParameters()
    //     0xa6f6f0: eor             v0.16b, v0.16b, v0.16b
    //     0xa6f6f4: ldr             x0, [fp, #0x20]
    //     0xa6f6f8: ldur            w1, [x0, #0x17]
    //     0xa6f6fc: add             x1, x1, HEAP, lsl #32
    //     0xa6f700: stur            x1, [fp, #-0x10]
    // 0xa6f6f0: d0 = 0.000000
    // 0xa6f704: CheckStackOverflow
    //     0xa6f704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6f708: cmp             SP, x16
    //     0xa6f70c: b.ls            #0xa6f814
    // 0xa6f710: ldr             x0, [fp, #0x10]
    // 0xa6f714: LoadField: d1 = r0->field_7
    //     0xa6f714: ldur            d1, [x0, #7]
    // 0xa6f718: stur            d1, [fp, #-0x28]
    // 0xa6f71c: fcmp            d1, d0
    // 0xa6f720: b.vs            #0xa6f738
    // 0xa6f724: b.gt            #0xa6f738
    // 0xa6f728: r0 = Null
    //     0xa6f728: mov             x0, NULL
    // 0xa6f72c: LeaveFrame
    //     0xa6f72c: mov             SP, fp
    //     0xa6f730: ldp             fp, lr, [SP], #0x10
    // 0xa6f734: ret
    //     0xa6f734: ret             
    // 0xa6f738: LoadField: r0 = r1->field_f
    //     0xa6f738: ldur            w0, [x1, #0xf]
    // 0xa6f73c: DecompressPointer r0
    //     0xa6f73c: add             x0, x0, HEAP, lsl #32
    // 0xa6f740: LoadField: r2 = r0->field_1f
    //     0xa6f740: ldur            w2, [x0, #0x1f]
    // 0xa6f744: DecompressPointer r2
    //     0xa6f744: add             x2, x2, HEAP, lsl #32
    // 0xa6f748: LoadField: r0 = r2->field_7
    //     0xa6f748: ldur            x0, [x2, #7]
    // 0xa6f74c: cmp             x0, #0
    // 0xa6f750: b.gt            #0xa6f778
    // 0xa6f754: ldr             x0, [fp, #0x18]
    // 0xa6f758: LoadField: r2 = r1->field_17
    //     0xa6f758: ldur            w2, [x1, #0x17]
    // 0xa6f75c: DecompressPointer r2
    //     0xa6f75c: add             x2, x2, HEAP, lsl #32
    // 0xa6f760: LoadField: d2 = r2->field_7
    //     0xa6f760: ldur            d2, [x2, #7]
    // 0xa6f764: fsub            d3, d2, d1
    // 0xa6f768: LoadField: d2 = r0->field_7
    //     0xa6f768: ldur            d2, [x0, #7]
    // 0xa6f76c: fsub            d4, d3, d2
    // 0xa6f770: mov             v2.16b, v4.16b
    // 0xa6f774: b               #0xa6f780
    // 0xa6f778: ldr             x0, [fp, #0x18]
    // 0xa6f77c: LoadField: d2 = r0->field_7
    //     0xa6f77c: ldur            d2, [x0, #7]
    // 0xa6f780: stur            d2, [fp, #-0x20]
    // 0xa6f784: LoadField: r0 = r1->field_13
    //     0xa6f784: ldur            w0, [x1, #0x13]
    // 0xa6f788: DecompressPointer r0
    //     0xa6f788: add             x0, x0, HEAP, lsl #32
    // 0xa6f78c: stur            x0, [fp, #-8]
    // 0xa6f790: r0 = Offset()
    //     0xa6f790: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6f794: ldur            d0, [fp, #-0x20]
    // 0xa6f798: stur            x0, [fp, #-0x18]
    // 0xa6f79c: StoreField: r0->field_7 = d0
    //     0xa6f79c: stur            d0, [x0, #7]
    // 0xa6f7a0: d0 = 0.000000
    //     0xa6f7a0: eor             v0.16b, v0.16b, v0.16b
    // 0xa6f7a4: StoreField: r0->field_f = d0
    //     0xa6f7a4: stur            d0, [x0, #0xf]
    // 0xa6f7a8: ldur            x1, [fp, #-0x10]
    // 0xa6f7ac: LoadField: r2 = r1->field_17
    //     0xa6f7ac: ldur            w2, [x1, #0x17]
    // 0xa6f7b0: DecompressPointer r2
    //     0xa6f7b0: add             x2, x2, HEAP, lsl #32
    // 0xa6f7b4: LoadField: d0 = r2->field_f
    //     0xa6f7b4: ldur            d0, [x2, #0xf]
    // 0xa6f7b8: stur            d0, [fp, #-0x20]
    // 0xa6f7bc: r0 = Size()
    //     0xa6f7bc: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa6f7c0: ldur            d0, [fp, #-0x28]
    // 0xa6f7c4: StoreField: r0->field_7 = d0
    //     0xa6f7c4: stur            d0, [x0, #7]
    // 0xa6f7c8: ldur            d0, [fp, #-0x20]
    // 0xa6f7cc: StoreField: r0->field_f = d0
    //     0xa6f7cc: stur            d0, [x0, #0xf]
    // 0xa6f7d0: ldur            x16, [fp, #-0x18]
    // 0xa6f7d4: stp             x0, x16, [SP, #-0x10]!
    // 0xa6f7d8: r0 = &()
    //     0xa6f7d8: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xa6f7dc: add             SP, SP, #0x10
    // 0xa6f7e0: mov             x1, x0
    // 0xa6f7e4: ldur            x0, [fp, #-0x10]
    // 0xa6f7e8: LoadField: r2 = r0->field_1b
    //     0xa6f7e8: ldur            w2, [x0, #0x1b]
    // 0xa6f7ec: DecompressPointer r2
    //     0xa6f7ec: add             x2, x2, HEAP, lsl #32
    // 0xa6f7f0: ldur            x16, [fp, #-8]
    // 0xa6f7f4: stp             x1, x16, [SP, #-0x10]!
    // 0xa6f7f8: SaveReg r2
    //     0xa6f7f8: str             x2, [SP, #-8]!
    // 0xa6f7fc: r0 = drawRect()
    //     0xa6f7fc: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xa6f800: add             SP, SP, #0x18
    // 0xa6f804: r0 = Null
    //     0xa6f804: mov             x0, NULL
    // 0xa6f808: LeaveFrame
    //     0xa6f808: mov             SP, fp
    //     0xa6f80c: ldp             fp, lr, [SP], #0x10
    // 0xa6f810: ret
    //     0xa6f810: ret             
    // 0xa6f814: r0 = StackOverflowSharedWithFPURegs()
    //     0xa6f814: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa6f818: b               #0xa6f710
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa79d54, size: 0x390
    // 0xa79d54: EnterFrame
    //     0xa79d54: stp             fp, lr, [SP, #-0x10]!
    //     0xa79d58: mov             fp, SP
    // 0xa79d5c: AllocStack(0x18)
    //     0xa79d5c: sub             SP, SP, #0x18
    // 0xa79d60: CheckStackOverflow
    //     0xa79d60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa79d64: cmp             SP, x16
    //     0xa79d68: b.ls            #0xa7a0dc
    // 0xa79d6c: ldr             x0, [fp, #0x10]
    // 0xa79d70: r2 = Null
    //     0xa79d70: mov             x2, NULL
    // 0xa79d74: r1 = Null
    //     0xa79d74: mov             x1, NULL
    // 0xa79d78: r4 = 59
    //     0xa79d78: mov             x4, #0x3b
    // 0xa79d7c: branchIfSmi(r0, 0xa79d88)
    //     0xa79d7c: tbz             w0, #0, #0xa79d88
    // 0xa79d80: r4 = LoadClassIdInstr(r0)
    //     0xa79d80: ldur            x4, [x0, #-1]
    //     0xa79d84: ubfx            x4, x4, #0xc, #0x14
    // 0xa79d88: r17 = 4375
    //     0xa79d88: mov             x17, #0x1117
    // 0xa79d8c: cmp             x4, x17
    // 0xa79d90: b.eq            #0xa79da8
    // 0xa79d94: r8 = _LinearProgressIndicatorPainter
    //     0xa79d94: add             x8, PP, #0x50, lsl #12  ; [pp+0x508c0] Type: _LinearProgressIndicatorPainter
    //     0xa79d98: ldr             x8, [x8, #0x8c0]
    // 0xa79d9c: r3 = Null
    //     0xa79d9c: add             x3, PP, #0x50, lsl #12  ; [pp+0x508c8] Null
    //     0xa79da0: ldr             x3, [x3, #0x8c8]
    // 0xa79da4: r0 = DefaultTypeTest()
    //     0xa79da4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa79da8: ldr             x0, [fp, #0x10]
    // 0xa79dac: LoadField: r1 = r0->field_b
    //     0xa79dac: ldur            w1, [x0, #0xb]
    // 0xa79db0: DecompressPointer r1
    //     0xa79db0: add             x1, x1, HEAP, lsl #32
    // 0xa79db4: ldr             x2, [fp, #0x18]
    // 0xa79db8: stur            x1, [fp, #-0x18]
    // 0xa79dbc: LoadField: r3 = r2->field_b
    //     0xa79dbc: ldur            w3, [x2, #0xb]
    // 0xa79dc0: DecompressPointer r3
    //     0xa79dc0: add             x3, x3, HEAP, lsl #32
    // 0xa79dc4: stur            x3, [fp, #-0x10]
    // 0xa79dc8: r4 = LoadClassIdInstr(r1)
    //     0xa79dc8: ldur            x4, [x1, #-1]
    //     0xa79dcc: ubfx            x4, x4, #0xc, #0x14
    // 0xa79dd0: lsl             x4, x4, #1
    // 0xa79dd4: stur            x4, [fp, #-8]
    // 0xa79dd8: r17 = 10114
    //     0xa79dd8: mov             x17, #0x2782
    // 0xa79ddc: cmp             w4, w17
    // 0xa79de0: b.eq            #0xa79df0
    // 0xa79de4: r17 = 10118
    //     0xa79de4: mov             x17, #0x2786
    // 0xa79de8: cmp             w4, w17
    // 0xa79dec: b.ne            #0xa79ed0
    // 0xa79df0: cmp             w1, w3
    // 0xa79df4: b.ne            #0xa79e00
    // 0xa79df8: mov             x1, x2
    // 0xa79dfc: b               #0xa79f04
    // 0xa79e00: stp             x1, x3, [SP, #-0x10]!
    // 0xa79e04: r0 = _haveSameRuntimeType()
    //     0xa79e04: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa79e08: add             SP, SP, #0x10
    // 0xa79e0c: tbnz            w0, #4, #0xa7a0a4
    // 0xa79e10: ldur            x0, [fp, #-0x10]
    // 0xa79e14: r1 = LoadClassIdInstr(r0)
    //     0xa79e14: ldur            x1, [x0, #-1]
    //     0xa79e18: ubfx            x1, x1, #0xc, #0x14
    // 0xa79e1c: lsl             x1, x1, #1
    // 0xa79e20: r17 = 10124
    //     0xa79e20: mov             x17, #0x278c
    // 0xa79e24: cmp             w1, w17
    // 0xa79e28: b.gt            #0xa79e38
    // 0xa79e2c: r17 = 10122
    //     0xa79e2c: mov             x17, #0x278a
    // 0xa79e30: cmp             w1, w17
    // 0xa79e34: b.ge            #0xa79e50
    // 0xa79e38: r17 = 10114
    //     0xa79e38: mov             x17, #0x2782
    // 0xa79e3c: cmp             w1, w17
    // 0xa79e40: b.eq            #0xa79e50
    // 0xa79e44: r17 = 10118
    //     0xa79e44: mov             x17, #0x2786
    // 0xa79e48: cmp             w1, w17
    // 0xa79e4c: b.ne            #0xa79e58
    // 0xa79e50: LoadField: r1 = r0->field_7
    //     0xa79e50: ldur            x1, [x0, #7]
    // 0xa79e54: b               #0xa79e68
    // 0xa79e58: LoadField: r1 = r0->field_f
    //     0xa79e58: ldur            w1, [x0, #0xf]
    // 0xa79e5c: DecompressPointer r1
    //     0xa79e5c: add             x1, x1, HEAP, lsl #32
    // 0xa79e60: LoadField: r0 = r1->field_7
    //     0xa79e60: ldur            x0, [x1, #7]
    // 0xa79e64: mov             x1, x0
    // 0xa79e68: ldur            x0, [fp, #-8]
    // 0xa79e6c: r17 = 10124
    //     0xa79e6c: mov             x17, #0x278c
    // 0xa79e70: cmp             w0, w17
    // 0xa79e74: b.gt            #0xa79e84
    // 0xa79e78: r17 = 10122
    //     0xa79e78: mov             x17, #0x278a
    // 0xa79e7c: cmp             w0, w17
    // 0xa79e80: b.ge            #0xa79e9c
    // 0xa79e84: r17 = 10114
    //     0xa79e84: mov             x17, #0x2782
    // 0xa79e88: cmp             w0, w17
    // 0xa79e8c: b.eq            #0xa79e9c
    // 0xa79e90: r17 = 10118
    //     0xa79e90: mov             x17, #0x2786
    // 0xa79e94: cmp             w0, w17
    // 0xa79e98: b.ne            #0xa79ea8
    // 0xa79e9c: ldur            x2, [fp, #-0x18]
    // 0xa79ea0: LoadField: r0 = r2->field_7
    //     0xa79ea0: ldur            x0, [x2, #7]
    // 0xa79ea4: b               #0xa79ebc
    // 0xa79ea8: ldur            x2, [fp, #-0x18]
    // 0xa79eac: LoadField: r0 = r2->field_f
    //     0xa79eac: ldur            w0, [x2, #0xf]
    // 0xa79eb0: DecompressPointer r0
    //     0xa79eb0: add             x0, x0, HEAP, lsl #32
    // 0xa79eb4: LoadField: r2 = r0->field_7
    //     0xa79eb4: ldur            x2, [x0, #7]
    // 0xa79eb8: mov             x0, x2
    // 0xa79ebc: cmp             x1, x0
    // 0xa79ec0: b.ne            #0xa7a0a4
    // 0xa79ec4: ldr             x1, [fp, #0x18]
    // 0xa79ec8: ldr             x0, [fp, #0x10]
    // 0xa79ecc: b               #0xa79f04
    // 0xa79ed0: mov             x2, x1
    // 0xa79ed4: mov             x0, x3
    // 0xa79ed8: r1 = LoadClassIdInstr(r2)
    //     0xa79ed8: ldur            x1, [x2, #-1]
    //     0xa79edc: ubfx            x1, x1, #0xc, #0x14
    // 0xa79ee0: stp             x0, x2, [SP, #-0x10]!
    // 0xa79ee4: mov             x0, x1
    // 0xa79ee8: mov             lr, x0
    // 0xa79eec: ldr             lr, [x21, lr, lsl #3]
    // 0xa79ef0: blr             lr
    // 0xa79ef4: add             SP, SP, #0x10
    // 0xa79ef8: tbnz            w0, #4, #0xa7a0a4
    // 0xa79efc: ldr             x1, [fp, #0x18]
    // 0xa79f00: ldr             x0, [fp, #0x10]
    // 0xa79f04: LoadField: r2 = r0->field_f
    //     0xa79f04: ldur            w2, [x0, #0xf]
    // 0xa79f08: DecompressPointer r2
    //     0xa79f08: add             x2, x2, HEAP, lsl #32
    // 0xa79f0c: stur            x2, [fp, #-0x18]
    // 0xa79f10: LoadField: r3 = r1->field_f
    //     0xa79f10: ldur            w3, [x1, #0xf]
    // 0xa79f14: DecompressPointer r3
    //     0xa79f14: add             x3, x3, HEAP, lsl #32
    // 0xa79f18: stur            x3, [fp, #-0x10]
    // 0xa79f1c: r4 = LoadClassIdInstr(r2)
    //     0xa79f1c: ldur            x4, [x2, #-1]
    //     0xa79f20: ubfx            x4, x4, #0xc, #0x14
    // 0xa79f24: lsl             x4, x4, #1
    // 0xa79f28: stur            x4, [fp, #-8]
    // 0xa79f2c: r17 = 10114
    //     0xa79f2c: mov             x17, #0x2782
    // 0xa79f30: cmp             w4, w17
    // 0xa79f34: b.eq            #0xa79f44
    // 0xa79f38: r17 = 10118
    //     0xa79f38: mov             x17, #0x2786
    // 0xa79f3c: cmp             w4, w17
    // 0xa79f40: b.ne            #0xa7a028
    // 0xa79f44: cmp             w2, w3
    // 0xa79f48: b.ne            #0xa79f58
    // 0xa79f4c: mov             x2, x1
    // 0xa79f50: mov             x1, x0
    // 0xa79f54: b               #0xa7a058
    // 0xa79f58: stp             x2, x3, [SP, #-0x10]!
    // 0xa79f5c: r0 = _haveSameRuntimeType()
    //     0xa79f5c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa79f60: add             SP, SP, #0x10
    // 0xa79f64: tbnz            w0, #4, #0xa7a0a4
    // 0xa79f68: ldur            x0, [fp, #-0x10]
    // 0xa79f6c: r1 = LoadClassIdInstr(r0)
    //     0xa79f6c: ldur            x1, [x0, #-1]
    //     0xa79f70: ubfx            x1, x1, #0xc, #0x14
    // 0xa79f74: lsl             x1, x1, #1
    // 0xa79f78: r17 = 10124
    //     0xa79f78: mov             x17, #0x278c
    // 0xa79f7c: cmp             w1, w17
    // 0xa79f80: b.gt            #0xa79f90
    // 0xa79f84: r17 = 10122
    //     0xa79f84: mov             x17, #0x278a
    // 0xa79f88: cmp             w1, w17
    // 0xa79f8c: b.ge            #0xa79fa8
    // 0xa79f90: r17 = 10114
    //     0xa79f90: mov             x17, #0x2782
    // 0xa79f94: cmp             w1, w17
    // 0xa79f98: b.eq            #0xa79fa8
    // 0xa79f9c: r17 = 10118
    //     0xa79f9c: mov             x17, #0x2786
    // 0xa79fa0: cmp             w1, w17
    // 0xa79fa4: b.ne            #0xa79fb0
    // 0xa79fa8: LoadField: r1 = r0->field_7
    //     0xa79fa8: ldur            x1, [x0, #7]
    // 0xa79fac: b               #0xa79fc0
    // 0xa79fb0: LoadField: r1 = r0->field_f
    //     0xa79fb0: ldur            w1, [x0, #0xf]
    // 0xa79fb4: DecompressPointer r1
    //     0xa79fb4: add             x1, x1, HEAP, lsl #32
    // 0xa79fb8: LoadField: r0 = r1->field_7
    //     0xa79fb8: ldur            x0, [x1, #7]
    // 0xa79fbc: mov             x1, x0
    // 0xa79fc0: ldur            x0, [fp, #-8]
    // 0xa79fc4: r17 = 10124
    //     0xa79fc4: mov             x17, #0x278c
    // 0xa79fc8: cmp             w0, w17
    // 0xa79fcc: b.gt            #0xa79fdc
    // 0xa79fd0: r17 = 10122
    //     0xa79fd0: mov             x17, #0x278a
    // 0xa79fd4: cmp             w0, w17
    // 0xa79fd8: b.ge            #0xa79ff4
    // 0xa79fdc: r17 = 10114
    //     0xa79fdc: mov             x17, #0x2782
    // 0xa79fe0: cmp             w0, w17
    // 0xa79fe4: b.eq            #0xa79ff4
    // 0xa79fe8: r17 = 10118
    //     0xa79fe8: mov             x17, #0x2786
    // 0xa79fec: cmp             w0, w17
    // 0xa79ff0: b.ne            #0xa7a000
    // 0xa79ff4: ldur            x2, [fp, #-0x18]
    // 0xa79ff8: LoadField: r0 = r2->field_7
    //     0xa79ff8: ldur            x0, [x2, #7]
    // 0xa79ffc: b               #0xa7a014
    // 0xa7a000: ldur            x2, [fp, #-0x18]
    // 0xa7a004: LoadField: r0 = r2->field_f
    //     0xa7a004: ldur            w0, [x2, #0xf]
    // 0xa7a008: DecompressPointer r0
    //     0xa7a008: add             x0, x0, HEAP, lsl #32
    // 0xa7a00c: LoadField: r2 = r0->field_7
    //     0xa7a00c: ldur            x2, [x0, #7]
    // 0xa7a010: mov             x0, x2
    // 0xa7a014: cmp             x1, x0
    // 0xa7a018: b.ne            #0xa7a0a4
    // 0xa7a01c: ldr             x2, [fp, #0x18]
    // 0xa7a020: ldr             x1, [fp, #0x10]
    // 0xa7a024: b               #0xa7a058
    // 0xa7a028: mov             x0, x3
    // 0xa7a02c: r1 = LoadClassIdInstr(r2)
    //     0xa7a02c: ldur            x1, [x2, #-1]
    //     0xa7a030: ubfx            x1, x1, #0xc, #0x14
    // 0xa7a034: stp             x0, x2, [SP, #-0x10]!
    // 0xa7a038: mov             x0, x1
    // 0xa7a03c: mov             lr, x0
    // 0xa7a040: ldr             lr, [x21, lr, lsl #3]
    // 0xa7a044: blr             lr
    // 0xa7a048: add             SP, SP, #0x10
    // 0xa7a04c: tbnz            w0, #4, #0xa7a0a4
    // 0xa7a050: ldr             x2, [fp, #0x18]
    // 0xa7a054: ldr             x1, [fp, #0x10]
    // 0xa7a058: LoadField: r0 = r1->field_13
    //     0xa7a058: ldur            w0, [x1, #0x13]
    // 0xa7a05c: DecompressPointer r0
    //     0xa7a05c: add             x0, x0, HEAP, lsl #32
    // 0xa7a060: LoadField: r3 = r2->field_13
    //     0xa7a060: ldur            w3, [x2, #0x13]
    // 0xa7a064: DecompressPointer r3
    //     0xa7a064: add             x3, x3, HEAP, lsl #32
    // 0xa7a068: r4 = LoadClassIdInstr(r0)
    //     0xa7a068: ldur            x4, [x0, #-1]
    //     0xa7a06c: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a070: stp             x3, x0, [SP, #-0x10]!
    // 0xa7a074: mov             x0, x4
    // 0xa7a078: mov             lr, x0
    // 0xa7a07c: ldr             lr, [x21, lr, lsl #3]
    // 0xa7a080: blr             lr
    // 0xa7a084: add             SP, SP, #0x10
    // 0xa7a088: tbnz            w0, #4, #0xa7a0a4
    // 0xa7a08c: ldr             x2, [fp, #0x18]
    // 0xa7a090: ldr             x1, [fp, #0x10]
    // 0xa7a094: LoadField: d0 = r1->field_17
    //     0xa7a094: ldur            d0, [x1, #0x17]
    // 0xa7a098: LoadField: d1 = r2->field_17
    //     0xa7a098: ldur            d1, [x2, #0x17]
    // 0xa7a09c: fcmp            d0, d1
    // 0xa7a0a0: b.eq            #0xa7a0ac
    // 0xa7a0a4: r0 = true
    //     0xa7a0a4: add             x0, NULL, #0x20  ; true
    // 0xa7a0a8: b               #0xa7a0d0
    // 0xa7a0ac: LoadField: r3 = r1->field_1f
    //     0xa7a0ac: ldur            w3, [x1, #0x1f]
    // 0xa7a0b0: DecompressPointer r3
    //     0xa7a0b0: add             x3, x3, HEAP, lsl #32
    // 0xa7a0b4: LoadField: r1 = r2->field_1f
    //     0xa7a0b4: ldur            w1, [x2, #0x1f]
    // 0xa7a0b8: DecompressPointer r1
    //     0xa7a0b8: add             x1, x1, HEAP, lsl #32
    // 0xa7a0bc: cmp             w3, w1
    // 0xa7a0c0: r16 = true
    //     0xa7a0c0: add             x16, NULL, #0x20  ; true
    // 0xa7a0c4: r17 = false
    //     0xa7a0c4: add             x17, NULL, #0x30  ; false
    // 0xa7a0c8: csel            x2, x16, x17, ne
    // 0xa7a0cc: mov             x0, x2
    // 0xa7a0d0: LeaveFrame
    //     0xa7a0d0: mov             SP, fp
    //     0xa7a0d4: ldp             fp, lr, [SP], #0x10
    // 0xa7a0d8: ret
    //     0xa7a0d8: ret             
    // 0xa7a0dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa7a0dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa7a0e0: b               #0xa79d6c
  }
}

// class id: 5953, size: 0x14, field offset: 0x14
enum _ActivityIndicatorType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16418, size: 0x5c
    // 0xb16418: EnterFrame
    //     0xb16418: stp             fp, lr, [SP, #-0x10]!
    //     0xb1641c: mov             fp, SP
    // 0xb16420: CheckStackOverflow
    //     0xb16420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16424: cmp             SP, x16
    //     0xb16428: b.ls            #0xb1646c
    // 0xb1642c: r1 = Null
    //     0xb1642c: mov             x1, NULL
    // 0xb16430: r2 = 4
    //     0xb16430: mov             x2, #4
    // 0xb16434: r0 = AllocateArray()
    //     0xb16434: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb16438: r17 = "_ActivityIndicatorType."
    //     0xb16438: add             x17, PP, #0x15, lsl #12  ; [pp+0x15280] "_ActivityIndicatorType."
    //     0xb1643c: ldr             x17, [x17, #0x280]
    // 0xb16440: StoreField: r0->field_f = r17
    //     0xb16440: stur            w17, [x0, #0xf]
    // 0xb16444: ldr             x1, [fp, #0x10]
    // 0xb16448: LoadField: r2 = r1->field_f
    //     0xb16448: ldur            w2, [x1, #0xf]
    // 0xb1644c: DecompressPointer r2
    //     0xb1644c: add             x2, x2, HEAP, lsl #32
    // 0xb16450: StoreField: r0->field_13 = r2
    //     0xb16450: stur            w2, [x0, #0x13]
    // 0xb16454: SaveReg r0
    //     0xb16454: str             x0, [SP, #-8]!
    // 0xb16458: r0 = _interpolate()
    //     0xb16458: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1645c: add             SP, SP, #8
    // 0xb16460: LeaveFrame
    //     0xb16460: mov             SP, fp
    //     0xb16464: ldp             fp, lr, [SP], #0x10
    // 0xb16468: ret
    //     0xb16468: ret             
    // 0xb1646c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1646c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16470: b               #0xb1642c
  }
}

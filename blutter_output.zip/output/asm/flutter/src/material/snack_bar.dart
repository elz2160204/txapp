// lib: , url: package:flutter/src/material/snack_bar.dart

// class id: 1049311, size: 0x8
class :: {
}

// class id: 4119, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class SnackBar extends StatefulWidget {
}

// class id: 5947, size: 0x14, field offset: 0x14
enum SnackBarClosedReason extends _Enum {
}

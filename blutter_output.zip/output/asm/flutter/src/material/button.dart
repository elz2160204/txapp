// lib: , url: package:flutter/src/material/button.dart

// class id: 1049194, size: 0x8
class :: {
}

// class id: 2462, size: 0x68, field offset: 0x64
class _RenderInputPadding extends RenderShiftedBox {

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62f39c, size: 0x18
    // 0x62f39c: r4 = 0
    //     0x62f39c: mov             x4, #0
    // 0x62f3a0: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62f3a0: add             x17, PP, #0x50, lsl #12  ; [pp+0x50ce0] AnonymousClosure: (0x62f3b4), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicHeight (0x62f400)
    //     0x62f3a4: ldr             x1, [x17, #0xce0]
    // 0x62f3a8: r24 = BuildNonGenericMethodExtractorStub
    //     0x62f3a8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62f3ac: LoadField: r0 = r24->field_17
    //     0x62f3ac: ldur            x0, [x24, #0x17]
    // 0x62f3b0: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62f3b4, size: 0x4c
    // 0x62f3b4: EnterFrame
    //     0x62f3b4: stp             fp, lr, [SP, #-0x10]!
    //     0x62f3b8: mov             fp, SP
    // 0x62f3bc: ldr             x0, [fp, #0x18]
    // 0x62f3c0: LoadField: r1 = r0->field_17
    //     0x62f3c0: ldur            w1, [x0, #0x17]
    // 0x62f3c4: DecompressPointer r1
    //     0x62f3c4: add             x1, x1, HEAP, lsl #32
    // 0x62f3c8: CheckStackOverflow
    //     0x62f3c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f3cc: cmp             SP, x16
    //     0x62f3d0: b.ls            #0x62f3f8
    // 0x62f3d4: LoadField: r0 = r1->field_f
    //     0x62f3d4: ldur            w0, [x1, #0xf]
    // 0x62f3d8: DecompressPointer r0
    //     0x62f3d8: add             x0, x0, HEAP, lsl #32
    // 0x62f3dc: ldr             x16, [fp, #0x10]
    // 0x62f3e0: stp             x16, x0, [SP, #-0x10]!
    // 0x62f3e4: r0 = computeMaxIntrinsicHeight()
    //     0x62f3e4: bl              #0x62f400  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicHeight
    // 0x62f3e8: add             SP, SP, #0x10
    // 0x62f3ec: LeaveFrame
    //     0x62f3ec: mov             SP, fp
    //     0x62f3f0: ldp             fp, lr, [SP], #0x10
    // 0x62f3f4: ret
    //     0x62f3f4: ret             
    // 0x62f3f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f3f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f3fc: b               #0x62f3d4
  }
  _ computeMaxIntrinsicHeight(/* No info */) {
    // ** addr: 0x62f400, size: 0xf4
    // 0x62f400: EnterFrame
    //     0x62f400: stp             fp, lr, [SP, #-0x10]!
    //     0x62f404: mov             fp, SP
    // 0x62f408: CheckStackOverflow
    //     0x62f408: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62f40c: cmp             SP, x16
    //     0x62f410: b.ls            #0x62f4dc
    // 0x62f414: ldr             x0, [fp, #0x18]
    // 0x62f418: LoadField: r1 = r0->field_5f
    //     0x62f418: ldur            w1, [x0, #0x5f]
    // 0x62f41c: DecompressPointer r1
    //     0x62f41c: add             x1, x1, HEAP, lsl #32
    // 0x62f420: cmp             w1, NULL
    // 0x62f424: b.eq            #0x62f4cc
    // 0x62f428: ldr             x2, [fp, #0x10]
    // 0x62f42c: LoadField: d0 = r2->field_7
    //     0x62f42c: ldur            d0, [x2, #7]
    // 0x62f430: SaveReg r1
    //     0x62f430: str             x1, [SP, #-8]!
    // 0x62f434: SaveReg d0
    //     0x62f434: str             d0, [SP, #-8]!
    // 0x62f438: r0 = getMaxIntrinsicHeight()
    //     0x62f438: bl              #0x62cb24  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicHeight
    // 0x62f43c: add             SP, SP, #0x10
    // 0x62f440: ldr             x1, [fp, #0x18]
    // 0x62f444: LoadField: r2 = r1->field_63
    //     0x62f444: ldur            w2, [x1, #0x63]
    // 0x62f448: DecompressPointer r2
    //     0x62f448: add             x2, x2, HEAP, lsl #32
    // 0x62f44c: LoadField: d1 = r2->field_f
    //     0x62f44c: ldur            d1, [x2, #0xf]
    // 0x62f450: fcmp            d0, d1
    // 0x62f454: b.vs            #0x62f45c
    // 0x62f458: b.gt            #0x62f498
    // 0x62f45c: fcmp            d0, d1
    // 0x62f460: b.vs            #0x62f470
    // 0x62f464: b.ge            #0x62f470
    // 0x62f468: mov             v0.16b, v1.16b
    // 0x62f46c: b               #0x62f498
    // 0x62f470: d2 = 0.000000
    //     0x62f470: eor             v2.16b, v2.16b, v2.16b
    // 0x62f474: fcmp            d0, d2
    // 0x62f478: b.vs            #0x62f48c
    // 0x62f47c: b.ne            #0x62f48c
    // 0x62f480: fadd            d2, d0, d1
    // 0x62f484: mov             v0.16b, v2.16b
    // 0x62f488: b               #0x62f498
    // 0x62f48c: fcmp            d1, d1
    // 0x62f490: b.vc            #0x62f498
    // 0x62f494: mov             v0.16b, v1.16b
    // 0x62f498: r0 = inline_Allocate_Double()
    //     0x62f498: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62f49c: add             x0, x0, #0x10
    //     0x62f4a0: cmp             x1, x0
    //     0x62f4a4: b.ls            #0x62f4e4
    //     0x62f4a8: str             x0, [THR, #0x60]  ; THR::top
    //     0x62f4ac: sub             x0, x0, #0xf
    //     0x62f4b0: mov             x1, #0xd108
    //     0x62f4b4: movk            x1, #3, lsl #16
    //     0x62f4b8: stur            x1, [x0, #-1]
    // 0x62f4bc: StoreField: r0->field_7 = d0
    //     0x62f4bc: stur            d0, [x0, #7]
    // 0x62f4c0: LeaveFrame
    //     0x62f4c0: mov             SP, fp
    //     0x62f4c4: ldp             fp, lr, [SP], #0x10
    // 0x62f4c8: ret
    //     0x62f4c8: ret             
    // 0x62f4cc: r0 = 0.000000
    //     0x62f4cc: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x62f4d0: LeaveFrame
    //     0x62f4d0: mov             SP, fp
    //     0x62f4d4: ldp             fp, lr, [SP], #0x10
    // 0x62f4d8: ret
    //     0x62f4d8: ret             
    // 0x62f4dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62f4dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62f4e0: b               #0x62f414
    // 0x62f4e4: SaveReg d0
    //     0x62f4e4: str             q0, [SP, #-0x10]!
    // 0x62f4e8: r0 = AllocateDouble()
    //     0x62f4e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62f4ec: RestoreReg d0
    //     0x62f4ec: ldr             q0, [SP], #0x10
    // 0x62f4f0: b               #0x62f4bc
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x635db4, size: 0x18
    // 0x635db4: r4 = 0
    //     0x635db4: mov             x4, #0
    // 0x635db8: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x635db8: add             x17, PP, #0x50, lsl #12  ; [pp+0x50ce8] AnonymousClosure: (0x635dcc), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicWidth (0x635e18)
    //     0x635dbc: ldr             x1, [x17, #0xce8]
    // 0x635dc0: r24 = BuildNonGenericMethodExtractorStub
    //     0x635dc0: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x635dc4: LoadField: r0 = r24->field_17
    //     0x635dc4: ldur            x0, [x24, #0x17]
    // 0x635dc8: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x635dcc, size: 0x4c
    // 0x635dcc: EnterFrame
    //     0x635dcc: stp             fp, lr, [SP, #-0x10]!
    //     0x635dd0: mov             fp, SP
    // 0x635dd4: ldr             x0, [fp, #0x18]
    // 0x635dd8: LoadField: r1 = r0->field_17
    //     0x635dd8: ldur            w1, [x0, #0x17]
    // 0x635ddc: DecompressPointer r1
    //     0x635ddc: add             x1, x1, HEAP, lsl #32
    // 0x635de0: CheckStackOverflow
    //     0x635de0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635de4: cmp             SP, x16
    //     0x635de8: b.ls            #0x635e10
    // 0x635dec: LoadField: r0 = r1->field_f
    //     0x635dec: ldur            w0, [x1, #0xf]
    // 0x635df0: DecompressPointer r0
    //     0x635df0: add             x0, x0, HEAP, lsl #32
    // 0x635df4: ldr             x16, [fp, #0x10]
    // 0x635df8: stp             x16, x0, [SP, #-0x10]!
    // 0x635dfc: r0 = computeMaxIntrinsicWidth()
    //     0x635dfc: bl              #0x635e18  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMaxIntrinsicWidth
    // 0x635e00: add             SP, SP, #0x10
    // 0x635e04: LeaveFrame
    //     0x635e04: mov             SP, fp
    //     0x635e08: ldp             fp, lr, [SP], #0x10
    // 0x635e0c: ret
    //     0x635e0c: ret             
    // 0x635e10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635e10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635e14: b               #0x635dec
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x635e18, size: 0xf4
    // 0x635e18: EnterFrame
    //     0x635e18: stp             fp, lr, [SP, #-0x10]!
    //     0x635e1c: mov             fp, SP
    // 0x635e20: CheckStackOverflow
    //     0x635e20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x635e24: cmp             SP, x16
    //     0x635e28: b.ls            #0x635ef4
    // 0x635e2c: ldr             x0, [fp, #0x18]
    // 0x635e30: LoadField: r1 = r0->field_5f
    //     0x635e30: ldur            w1, [x0, #0x5f]
    // 0x635e34: DecompressPointer r1
    //     0x635e34: add             x1, x1, HEAP, lsl #32
    // 0x635e38: cmp             w1, NULL
    // 0x635e3c: b.eq            #0x635ee4
    // 0x635e40: ldr             x2, [fp, #0x10]
    // 0x635e44: LoadField: d0 = r2->field_7
    //     0x635e44: ldur            d0, [x2, #7]
    // 0x635e48: SaveReg r1
    //     0x635e48: str             x1, [SP, #-8]!
    // 0x635e4c: SaveReg d0
    //     0x635e4c: str             d0, [SP, #-8]!
    // 0x635e50: r0 = getMaxIntrinsicWidth()
    //     0x635e50: bl              #0x62cb94  ; [package:flutter/src/rendering/box.dart] RenderBox::getMaxIntrinsicWidth
    // 0x635e54: add             SP, SP, #0x10
    // 0x635e58: ldr             x1, [fp, #0x18]
    // 0x635e5c: LoadField: r2 = r1->field_63
    //     0x635e5c: ldur            w2, [x1, #0x63]
    // 0x635e60: DecompressPointer r2
    //     0x635e60: add             x2, x2, HEAP, lsl #32
    // 0x635e64: LoadField: d1 = r2->field_7
    //     0x635e64: ldur            d1, [x2, #7]
    // 0x635e68: fcmp            d0, d1
    // 0x635e6c: b.vs            #0x635e74
    // 0x635e70: b.gt            #0x635eb0
    // 0x635e74: fcmp            d0, d1
    // 0x635e78: b.vs            #0x635e88
    // 0x635e7c: b.ge            #0x635e88
    // 0x635e80: mov             v0.16b, v1.16b
    // 0x635e84: b               #0x635eb0
    // 0x635e88: d2 = 0.000000
    //     0x635e88: eor             v2.16b, v2.16b, v2.16b
    // 0x635e8c: fcmp            d0, d2
    // 0x635e90: b.vs            #0x635ea4
    // 0x635e94: b.ne            #0x635ea4
    // 0x635e98: fadd            d2, d0, d1
    // 0x635e9c: mov             v0.16b, v2.16b
    // 0x635ea0: b               #0x635eb0
    // 0x635ea4: fcmp            d1, d1
    // 0x635ea8: b.vc            #0x635eb0
    // 0x635eac: mov             v0.16b, v1.16b
    // 0x635eb0: r0 = inline_Allocate_Double()
    //     0x635eb0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x635eb4: add             x0, x0, #0x10
    //     0x635eb8: cmp             x1, x0
    //     0x635ebc: b.ls            #0x635efc
    //     0x635ec0: str             x0, [THR, #0x60]  ; THR::top
    //     0x635ec4: sub             x0, x0, #0xf
    //     0x635ec8: mov             x1, #0xd108
    //     0x635ecc: movk            x1, #3, lsl #16
    //     0x635ed0: stur            x1, [x0, #-1]
    // 0x635ed4: StoreField: r0->field_7 = d0
    //     0x635ed4: stur            d0, [x0, #7]
    // 0x635ed8: LeaveFrame
    //     0x635ed8: mov             SP, fp
    //     0x635edc: ldp             fp, lr, [SP], #0x10
    // 0x635ee0: ret
    //     0x635ee0: ret             
    // 0x635ee4: r0 = 0.000000
    //     0x635ee4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x635ee8: LeaveFrame
    //     0x635ee8: mov             SP, fp
    //     0x635eec: ldp             fp, lr, [SP], #0x10
    // 0x635ef0: ret
    //     0x635ef0: ret             
    // 0x635ef4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x635ef4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x635ef8: b               #0x635e2c
    // 0x635efc: SaveReg d0
    //     0x635efc: str             q0, [SP, #-0x10]!
    // 0x635f00: r0 = AllocateDouble()
    //     0x635f00: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x635f04: RestoreReg d0
    //     0x635f04: ldr             q0, [SP], #0x10
    // 0x635f08: b               #0x635ed4
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x639000, size: 0x18
    // 0x639000: r4 = 0
    //     0x639000: mov             x4, #0
    // 0x639004: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x639004: add             x17, PP, #0x53, lsl #12  ; [pp+0x532b8] AnonymousClosure: (0x639018), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicHeight (0x639064)
    //     0x639008: ldr             x1, [x17, #0x2b8]
    // 0x63900c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63900c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x639010: LoadField: r0 = r24->field_17
    //     0x639010: ldur            x0, [x24, #0x17]
    // 0x639014: br              x0
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x639018, size: 0x4c
    // 0x639018: EnterFrame
    //     0x639018: stp             fp, lr, [SP, #-0x10]!
    //     0x63901c: mov             fp, SP
    // 0x639020: ldr             x0, [fp, #0x18]
    // 0x639024: LoadField: r1 = r0->field_17
    //     0x639024: ldur            w1, [x0, #0x17]
    // 0x639028: DecompressPointer r1
    //     0x639028: add             x1, x1, HEAP, lsl #32
    // 0x63902c: CheckStackOverflow
    //     0x63902c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x639030: cmp             SP, x16
    //     0x639034: b.ls            #0x63905c
    // 0x639038: LoadField: r0 = r1->field_f
    //     0x639038: ldur            w0, [x1, #0xf]
    // 0x63903c: DecompressPointer r0
    //     0x63903c: add             x0, x0, HEAP, lsl #32
    // 0x639040: ldr             x16, [fp, #0x10]
    // 0x639044: stp             x16, x0, [SP, #-0x10]!
    // 0x639048: r0 = computeMinIntrinsicHeight()
    //     0x639048: bl              #0x639064  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicHeight
    // 0x63904c: add             SP, SP, #0x10
    // 0x639050: LeaveFrame
    //     0x639050: mov             SP, fp
    //     0x639054: ldp             fp, lr, [SP], #0x10
    // 0x639058: ret
    //     0x639058: ret             
    // 0x63905c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63905c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639060: b               #0x639038
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x639064, size: 0xf4
    // 0x639064: EnterFrame
    //     0x639064: stp             fp, lr, [SP, #-0x10]!
    //     0x639068: mov             fp, SP
    // 0x63906c: CheckStackOverflow
    //     0x63906c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x639070: cmp             SP, x16
    //     0x639074: b.ls            #0x639140
    // 0x639078: ldr             x0, [fp, #0x18]
    // 0x63907c: LoadField: r1 = r0->field_5f
    //     0x63907c: ldur            w1, [x0, #0x5f]
    // 0x639080: DecompressPointer r1
    //     0x639080: add             x1, x1, HEAP, lsl #32
    // 0x639084: cmp             w1, NULL
    // 0x639088: b.eq            #0x639130
    // 0x63908c: ldr             x2, [fp, #0x10]
    // 0x639090: LoadField: d0 = r2->field_7
    //     0x639090: ldur            d0, [x2, #7]
    // 0x639094: SaveReg r1
    //     0x639094: str             x1, [SP, #-8]!
    // 0x639098: SaveReg d0
    //     0x639098: str             d0, [SP, #-8]!
    // 0x63909c: r0 = getMinIntrinsicHeight()
    //     0x63909c: bl              #0x630a58  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicHeight
    // 0x6390a0: add             SP, SP, #0x10
    // 0x6390a4: ldr             x1, [fp, #0x18]
    // 0x6390a8: LoadField: r2 = r1->field_63
    //     0x6390a8: ldur            w2, [x1, #0x63]
    // 0x6390ac: DecompressPointer r2
    //     0x6390ac: add             x2, x2, HEAP, lsl #32
    // 0x6390b0: LoadField: d1 = r2->field_f
    //     0x6390b0: ldur            d1, [x2, #0xf]
    // 0x6390b4: fcmp            d0, d1
    // 0x6390b8: b.vs            #0x6390c0
    // 0x6390bc: b.gt            #0x6390fc
    // 0x6390c0: fcmp            d0, d1
    // 0x6390c4: b.vs            #0x6390d4
    // 0x6390c8: b.ge            #0x6390d4
    // 0x6390cc: mov             v0.16b, v1.16b
    // 0x6390d0: b               #0x6390fc
    // 0x6390d4: d2 = 0.000000
    //     0x6390d4: eor             v2.16b, v2.16b, v2.16b
    // 0x6390d8: fcmp            d0, d2
    // 0x6390dc: b.vs            #0x6390f0
    // 0x6390e0: b.ne            #0x6390f0
    // 0x6390e4: fadd            d2, d0, d1
    // 0x6390e8: mov             v0.16b, v2.16b
    // 0x6390ec: b               #0x6390fc
    // 0x6390f0: fcmp            d1, d1
    // 0x6390f4: b.vc            #0x6390fc
    // 0x6390f8: mov             v0.16b, v1.16b
    // 0x6390fc: r0 = inline_Allocate_Double()
    //     0x6390fc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x639100: add             x0, x0, #0x10
    //     0x639104: cmp             x1, x0
    //     0x639108: b.ls            #0x639148
    //     0x63910c: str             x0, [THR, #0x60]  ; THR::top
    //     0x639110: sub             x0, x0, #0xf
    //     0x639114: mov             x1, #0xd108
    //     0x639118: movk            x1, #3, lsl #16
    //     0x63911c: stur            x1, [x0, #-1]
    // 0x639120: StoreField: r0->field_7 = d0
    //     0x639120: stur            d0, [x0, #7]
    // 0x639124: LeaveFrame
    //     0x639124: mov             SP, fp
    //     0x639128: ldp             fp, lr, [SP], #0x10
    // 0x63912c: ret
    //     0x63912c: ret             
    // 0x639130: r0 = 0.000000
    //     0x639130: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x639134: LeaveFrame
    //     0x639134: mov             SP, fp
    //     0x639138: ldp             fp, lr, [SP], #0x10
    // 0x63913c: ret
    //     0x63913c: ret             
    // 0x639140: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x639140: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x639144: b               #0x639078
    // 0x639148: SaveReg d0
    //     0x639148: str             q0, [SP, #-0x10]!
    // 0x63914c: r0 = AllocateDouble()
    //     0x63914c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x639150: RestoreReg d0
    //     0x639150: ldr             q0, [SP], #0x10
    // 0x639154: b               #0x639120
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63bc3c, size: 0x18
    // 0x63bc3c: r4 = 0
    //     0x63bc3c: mov             x4, #0
    // 0x63bc40: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63bc40: add             x17, PP, #0x50, lsl #12  ; [pp+0x50cf0] AnonymousClosure: (0x63bc54), in [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth (0x63bca0)
    //     0x63bc44: ldr             x1, [x17, #0xcf0]
    // 0x63bc48: r24 = BuildNonGenericMethodExtractorStub
    //     0x63bc48: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63bc4c: LoadField: r0 = r24->field_17
    //     0x63bc4c: ldur            x0, [x24, #0x17]
    // 0x63bc50: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63bc54, size: 0x4c
    // 0x63bc54: EnterFrame
    //     0x63bc54: stp             fp, lr, [SP, #-0x10]!
    //     0x63bc58: mov             fp, SP
    // 0x63bc5c: ldr             x0, [fp, #0x18]
    // 0x63bc60: LoadField: r1 = r0->field_17
    //     0x63bc60: ldur            w1, [x0, #0x17]
    // 0x63bc64: DecompressPointer r1
    //     0x63bc64: add             x1, x1, HEAP, lsl #32
    // 0x63bc68: CheckStackOverflow
    //     0x63bc68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63bc6c: cmp             SP, x16
    //     0x63bc70: b.ls            #0x63bc98
    // 0x63bc74: LoadField: r0 = r1->field_f
    //     0x63bc74: ldur            w0, [x1, #0xf]
    // 0x63bc78: DecompressPointer r0
    //     0x63bc78: add             x0, x0, HEAP, lsl #32
    // 0x63bc7c: ldr             x16, [fp, #0x10]
    // 0x63bc80: stp             x16, x0, [SP, #-0x10]!
    // 0x63bc84: r0 = computeMinIntrinsicWidth()
    //     0x63bc84: bl              #0x63bca0  ; [package:flutter/src/material/button.dart] _RenderInputPadding::computeMinIntrinsicWidth
    // 0x63bc88: add             SP, SP, #0x10
    // 0x63bc8c: LeaveFrame
    //     0x63bc8c: mov             SP, fp
    //     0x63bc90: ldp             fp, lr, [SP], #0x10
    // 0x63bc94: ret
    //     0x63bc94: ret             
    // 0x63bc98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63bc98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63bc9c: b               #0x63bc74
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63bca0, size: 0xf4
    // 0x63bca0: EnterFrame
    //     0x63bca0: stp             fp, lr, [SP, #-0x10]!
    //     0x63bca4: mov             fp, SP
    // 0x63bca8: CheckStackOverflow
    //     0x63bca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63bcac: cmp             SP, x16
    //     0x63bcb0: b.ls            #0x63bd7c
    // 0x63bcb4: ldr             x0, [fp, #0x18]
    // 0x63bcb8: LoadField: r1 = r0->field_5f
    //     0x63bcb8: ldur            w1, [x0, #0x5f]
    // 0x63bcbc: DecompressPointer r1
    //     0x63bcbc: add             x1, x1, HEAP, lsl #32
    // 0x63bcc0: cmp             w1, NULL
    // 0x63bcc4: b.eq            #0x63bd6c
    // 0x63bcc8: ldr             x2, [fp, #0x10]
    // 0x63bccc: LoadField: d0 = r2->field_7
    //     0x63bccc: ldur            d0, [x2, #7]
    // 0x63bcd0: SaveReg r1
    //     0x63bcd0: str             x1, [SP, #-8]!
    // 0x63bcd4: SaveReg d0
    //     0x63bcd4: str             d0, [SP, #-8]!
    // 0x63bcd8: r0 = getMinIntrinsicWidth()
    //     0x63bcd8: bl              #0x630b18  ; [package:flutter/src/rendering/box.dart] RenderBox::getMinIntrinsicWidth
    // 0x63bcdc: add             SP, SP, #0x10
    // 0x63bce0: ldr             x1, [fp, #0x18]
    // 0x63bce4: LoadField: r2 = r1->field_63
    //     0x63bce4: ldur            w2, [x1, #0x63]
    // 0x63bce8: DecompressPointer r2
    //     0x63bce8: add             x2, x2, HEAP, lsl #32
    // 0x63bcec: LoadField: d1 = r2->field_7
    //     0x63bcec: ldur            d1, [x2, #7]
    // 0x63bcf0: fcmp            d0, d1
    // 0x63bcf4: b.vs            #0x63bcfc
    // 0x63bcf8: b.gt            #0x63bd38
    // 0x63bcfc: fcmp            d0, d1
    // 0x63bd00: b.vs            #0x63bd10
    // 0x63bd04: b.ge            #0x63bd10
    // 0x63bd08: mov             v0.16b, v1.16b
    // 0x63bd0c: b               #0x63bd38
    // 0x63bd10: d2 = 0.000000
    //     0x63bd10: eor             v2.16b, v2.16b, v2.16b
    // 0x63bd14: fcmp            d0, d2
    // 0x63bd18: b.vs            #0x63bd2c
    // 0x63bd1c: b.ne            #0x63bd2c
    // 0x63bd20: fadd            d2, d0, d1
    // 0x63bd24: mov             v0.16b, v2.16b
    // 0x63bd28: b               #0x63bd38
    // 0x63bd2c: fcmp            d1, d1
    // 0x63bd30: b.vc            #0x63bd38
    // 0x63bd34: mov             v0.16b, v1.16b
    // 0x63bd38: r0 = inline_Allocate_Double()
    //     0x63bd38: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63bd3c: add             x0, x0, #0x10
    //     0x63bd40: cmp             x1, x0
    //     0x63bd44: b.ls            #0x63bd84
    //     0x63bd48: str             x0, [THR, #0x60]  ; THR::top
    //     0x63bd4c: sub             x0, x0, #0xf
    //     0x63bd50: mov             x1, #0xd108
    //     0x63bd54: movk            x1, #3, lsl #16
    //     0x63bd58: stur            x1, [x0, #-1]
    // 0x63bd5c: StoreField: r0->field_7 = d0
    //     0x63bd5c: stur            d0, [x0, #7]
    // 0x63bd60: LeaveFrame
    //     0x63bd60: mov             SP, fp
    //     0x63bd64: ldp             fp, lr, [SP], #0x10
    // 0x63bd68: ret
    //     0x63bd68: ret             
    // 0x63bd6c: r0 = 0.000000
    //     0x63bd6c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63bd70: LeaveFrame
    //     0x63bd70: mov             SP, fp
    //     0x63bd74: ldp             fp, lr, [SP], #0x10
    // 0x63bd78: ret
    //     0x63bd78: ret             
    // 0x63bd7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63bd7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63bd80: b               #0x63bcb4
    // 0x63bd84: SaveReg d0
    //     0x63bd84: str             q0, [SP, #-0x10]!
    // 0x63bd88: r0 = AllocateDouble()
    //     0x63bd88: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63bd8c: RestoreReg d0
    //     0x63bd8c: ldr             q0, [SP], #0x10
    // 0x63bd90: b               #0x63bd5c
  }
  _ hitTest(/* No info */) {
    // ** addr: 0x640648, size: 0x110
    // 0x640648: EnterFrame
    //     0x640648: stp             fp, lr, [SP, #-0x10]!
    //     0x64064c: mov             fp, SP
    // 0x640650: AllocStack(0x10)
    //     0x640650: sub             SP, SP, #0x10
    // 0x640654: CheckStackOverflow
    //     0x640654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x640658: cmp             SP, x16
    //     0x64065c: b.ls            #0x640748
    // 0x640660: r1 = 2
    //     0x640660: mov             x1, #2
    // 0x640664: r0 = AllocateContext()
    //     0x640664: bl              #0xd68aa4  ; AllocateContextStub
    // 0x640668: mov             x1, x0
    // 0x64066c: ldr             x0, [fp, #0x20]
    // 0x640670: stur            x1, [fp, #-8]
    // 0x640674: StoreField: r1->field_f = r0
    //     0x640674: stur            w0, [x1, #0xf]
    // 0x640678: ldr             x16, [fp, #0x18]
    // 0x64067c: stp             x16, x0, [SP, #-0x10]!
    // 0x640680: ldr             x16, [fp, #0x10]
    // 0x640684: SaveReg r16
    //     0x640684: str             x16, [SP, #-8]!
    // 0x640688: r0 = hitTest()
    //     0x640688: bl              #0x640b9c  ; [package:flutter/src/rendering/box.dart] RenderBox::hitTest
    // 0x64068c: add             SP, SP, #0x18
    // 0x640690: tbnz            w0, #4, #0x6406a4
    // 0x640694: r0 = true
    //     0x640694: add             x0, NULL, #0x20  ; true
    // 0x640698: LeaveFrame
    //     0x640698: mov             SP, fp
    //     0x64069c: ldp             fp, lr, [SP], #0x10
    // 0x6406a0: ret
    //     0x6406a0: ret             
    // 0x6406a4: ldr             x0, [fp, #0x20]
    // 0x6406a8: ldur            x2, [fp, #-8]
    // 0x6406ac: LoadField: r1 = r0->field_5f
    //     0x6406ac: ldur            w1, [x0, #0x5f]
    // 0x6406b0: DecompressPointer r1
    //     0x6406b0: add             x1, x1, HEAP, lsl #32
    // 0x6406b4: cmp             w1, NULL
    // 0x6406b8: b.eq            #0x640750
    // 0x6406bc: LoadField: r0 = r1->field_57
    //     0x6406bc: ldur            w0, [x1, #0x57]
    // 0x6406c0: DecompressPointer r0
    //     0x6406c0: add             x0, x0, HEAP, lsl #32
    // 0x6406c4: cmp             w0, NULL
    // 0x6406c8: b.eq            #0x640754
    // 0x6406cc: SaveReg r0
    //     0x6406cc: str             x0, [SP, #-8]!
    // 0x6406d0: r0 = center()
    //     0x6406d0: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x6406d4: add             SP, SP, #8
    // 0x6406d8: mov             x1, x0
    // 0x6406dc: ldur            x2, [fp, #-8]
    // 0x6406e0: stur            x1, [fp, #-0x10]
    // 0x6406e4: StoreField: r2->field_13 = r0
    //     0x6406e4: stur            w0, [x2, #0x13]
    //     0x6406e8: ldurb           w16, [x2, #-1]
    //     0x6406ec: ldurb           w17, [x0, #-1]
    //     0x6406f0: and             x16, x17, x16, lsr #2
    //     0x6406f4: tst             x16, HEAP, lsr #32
    //     0x6406f8: b.eq            #0x640700
    //     0x6406fc: bl              #0xd6828c
    // 0x640700: SaveReg r1
    //     0x640700: str             x1, [SP, #-8]!
    // 0x640704: r0 = forceToPoint()
    //     0x640704: bl              #0x640758  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::forceToPoint
    // 0x640708: add             SP, SP, #8
    // 0x64070c: ldur            x2, [fp, #-8]
    // 0x640710: r1 = Function '<anonymous closure>':.
    //     0x640710: add             x1, PP, #0x50, lsl #12  ; [pp+0x50cf8] AnonymousClosure: (0x64088c), in [package:flutter/src/material/button_style_button.dart] _RenderInputPadding::hitTest (0x640910)
    //     0x640714: ldr             x1, [x1, #0xcf8]
    // 0x640718: stur            x0, [fp, #-8]
    // 0x64071c: r0 = AllocateClosure()
    //     0x64071c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x640720: ldr             x16, [fp, #0x18]
    // 0x640724: stp             x0, x16, [SP, #-0x10]!
    // 0x640728: ldur            x16, [fp, #-0x10]
    // 0x64072c: ldur            lr, [fp, #-8]
    // 0x640730: stp             lr, x16, [SP, #-0x10]!
    // 0x640734: r0 = addWithRawTransform()
    //     0x640734: bl              #0x622f84  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithRawTransform
    // 0x640738: add             SP, SP, #0x20
    // 0x64073c: LeaveFrame
    //     0x64073c: mov             SP, fp
    //     0x640740: ldp             fp, lr, [SP], #0x10
    // 0x640744: ret
    //     0x640744: ret             
    // 0x640748: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x640748: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64074c: b               #0x640660
    // 0x640750: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640750: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x640754: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x640754: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69282c, size: 0x1a0
    // 0x69282c: EnterFrame
    //     0x69282c: stp             fp, lr, [SP, #-0x10]!
    //     0x692830: mov             fp, SP
    // 0x692834: AllocStack(0x18)
    //     0x692834: sub             SP, SP, #0x18
    // 0x692838: CheckStackOverflow
    //     0x692838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69283c: cmp             SP, x16
    //     0x692840: b.ls            #0x6929bc
    // 0x692844: ldr             x3, [fp, #0x10]
    // 0x692848: LoadField: r4 = r3->field_27
    //     0x692848: ldur            w4, [x3, #0x27]
    // 0x69284c: DecompressPointer r4
    //     0x69284c: add             x4, x4, HEAP, lsl #32
    // 0x692850: stur            x4, [fp, #-8]
    // 0x692854: cmp             w4, NULL
    // 0x692858: b.eq            #0x69299c
    // 0x69285c: mov             x0, x4
    // 0x692860: r2 = Null
    //     0x692860: mov             x2, NULL
    // 0x692864: r1 = Null
    //     0x692864: mov             x1, NULL
    // 0x692868: r4 = LoadClassIdInstr(r0)
    //     0x692868: ldur            x4, [x0, #-1]
    //     0x69286c: ubfx            x4, x4, #0xc, #0x14
    // 0x692870: sub             x4, x4, #0x80d
    // 0x692874: cmp             x4, #1
    // 0x692878: b.ls            #0x692890
    // 0x69287c: r8 = BoxConstraints
    //     0x69287c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x692880: ldr             x8, [x8, #0x1d0]
    // 0x692884: r3 = Null
    //     0x692884: add             x3, PP, #0x50, lsl #12  ; [pp+0x50d00] Null
    //     0x692888: ldr             x3, [x3, #0xd00]
    // 0x69288c: r0 = BoxConstraints()
    //     0x69288c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x692890: ldr             x16, [fp, #0x10]
    // 0x692894: ldur            lr, [fp, #-8]
    // 0x692898: stp             lr, x16, [SP, #-0x10]!
    // 0x69289c: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static.
    //     0x69289c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf80] Closure: (RenderBox, BoxConstraints) => Size from Function 'layoutChild': static. (0x7fe6e1e8aefc)
    //     0x6928a0: ldr             x16, [x16, #0xf80]
    // 0x6928a4: SaveReg r16
    //     0x6928a4: str             x16, [SP, #-8]!
    // 0x6928a8: r0 = _computeSize()
    //     0x6928a8: bl              #0x6929cc  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0x6928ac: add             SP, SP, #0x18
    // 0x6928b0: mov             x3, x0
    // 0x6928b4: ldr             x1, [fp, #0x10]
    // 0x6928b8: stur            x3, [fp, #-0x18]
    // 0x6928bc: StoreField: r1->field_57 = r0
    //     0x6928bc: stur            w0, [x1, #0x57]
    //     0x6928c0: ldurb           w16, [x1, #-1]
    //     0x6928c4: ldurb           w17, [x0, #-1]
    //     0x6928c8: and             x16, x17, x16, lsr #2
    //     0x6928cc: tst             x16, HEAP, lsr #32
    //     0x6928d0: b.eq            #0x6928d8
    //     0x6928d4: bl              #0xd6826c
    // 0x6928d8: LoadField: r4 = r1->field_5f
    //     0x6928d8: ldur            w4, [x1, #0x5f]
    // 0x6928dc: DecompressPointer r4
    //     0x6928dc: add             x4, x4, HEAP, lsl #32
    // 0x6928e0: stur            x4, [fp, #-0x10]
    // 0x6928e4: cmp             w4, NULL
    // 0x6928e8: b.eq            #0x69298c
    // 0x6928ec: LoadField: r5 = r4->field_17
    //     0x6928ec: ldur            w5, [x4, #0x17]
    // 0x6928f0: DecompressPointer r5
    //     0x6928f0: add             x5, x5, HEAP, lsl #32
    // 0x6928f4: stur            x5, [fp, #-8]
    // 0x6928f8: cmp             w5, NULL
    // 0x6928fc: b.eq            #0x6929c4
    // 0x692900: mov             x0, x5
    // 0x692904: r2 = Null
    //     0x692904: mov             x2, NULL
    // 0x692908: r1 = Null
    //     0x692908: mov             x1, NULL
    // 0x69290c: r4 = LoadClassIdInstr(r0)
    //     0x69290c: ldur            x4, [x0, #-1]
    //     0x692910: ubfx            x4, x4, #0xc, #0x14
    // 0x692914: sub             x4, x4, #0x7ff
    // 0x692918: cmp             x4, #0xb
    // 0x69291c: b.ls            #0x692934
    // 0x692920: r8 = BoxParentData
    //     0x692920: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x692924: ldr             x8, [x8, #0x1b0]
    // 0x692928: r3 = Null
    //     0x692928: add             x3, PP, #0x50, lsl #12  ; [pp+0x50d10] Null
    //     0x69292c: ldr             x3, [x3, #0xd10]
    // 0x692930: r0 = DefaultTypeTest()
    //     0x692930: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x692934: ldur            x0, [fp, #-0x10]
    // 0x692938: LoadField: r1 = r0->field_57
    //     0x692938: ldur            w1, [x0, #0x57]
    // 0x69293c: DecompressPointer r1
    //     0x69293c: add             x1, x1, HEAP, lsl #32
    // 0x692940: cmp             w1, NULL
    // 0x692944: b.eq            #0x6929c8
    // 0x692948: ldur            x16, [fp, #-0x18]
    // 0x69294c: stp             x1, x16, [SP, #-0x10]!
    // 0x692950: r0 = -()
    //     0x692950: bl              #0x50e344  ; [dart:ui] Size::-
    // 0x692954: add             SP, SP, #0x10
    // 0x692958: r16 = Instance_Alignment
    //     0x692958: add             x16, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x69295c: ldr             x16, [x16, #0xc70]
    // 0x692960: stp             x0, x16, [SP, #-0x10]!
    // 0x692964: r0 = alongOffset()
    //     0x692964: bl              #0x626350  ; [package:flutter/src/painting/alignment.dart] Alignment::alongOffset
    // 0x692968: add             SP, SP, #0x10
    // 0x69296c: ldur            x1, [fp, #-8]
    // 0x692970: StoreField: r1->field_7 = r0
    //     0x692970: stur            w0, [x1, #7]
    //     0x692974: ldurb           w16, [x1, #-1]
    //     0x692978: ldurb           w17, [x0, #-1]
    //     0x69297c: and             x16, x17, x16, lsr #2
    //     0x692980: tst             x16, HEAP, lsr #32
    //     0x692984: b.eq            #0x69298c
    //     0x692988: bl              #0xd6826c
    // 0x69298c: r0 = Null
    //     0x69298c: mov             x0, NULL
    // 0x692990: LeaveFrame
    //     0x692990: mov             SP, fp
    //     0x692994: ldp             fp, lr, [SP], #0x10
    // 0x692998: ret
    //     0x692998: ret             
    // 0x69299c: r0 = StateError()
    //     0x69299c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6929a0: mov             x1, x0
    // 0x6929a4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6929a4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6929a8: ldr             x0, [x0, #0x1e8]
    // 0x6929ac: StoreField: r1->field_b = r0
    //     0x6929ac: stur            w0, [x1, #0xb]
    // 0x6929b0: mov             x0, x1
    // 0x6929b4: r0 = Throw()
    //     0x6929b4: bl              #0xd67e38  ; ThrowStub
    // 0x6929b8: brk             #0
    // 0x6929bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6929bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6929c0: b               #0x692844
    // 0x6929c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6929c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6929c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6929c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _computeSize(/* No info */) {
    // ** addr: 0x6929cc, size: 0x154
    // 0x6929cc: EnterFrame
    //     0x6929cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6929d0: mov             fp, SP
    // 0x6929d4: AllocStack(0x10)
    //     0x6929d4: sub             SP, SP, #0x10
    // 0x6929d8: CheckStackOverflow
    //     0x6929d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6929dc: cmp             SP, x16
    //     0x6929e0: b.ls            #0x692b18
    // 0x6929e4: ldr             x1, [fp, #0x20]
    // 0x6929e8: LoadField: r0 = r1->field_5f
    //     0x6929e8: ldur            w0, [x1, #0x5f]
    // 0x6929ec: DecompressPointer r0
    //     0x6929ec: add             x0, x0, HEAP, lsl #32
    // 0x6929f0: cmp             w0, NULL
    // 0x6929f4: b.eq            #0x692b08
    // 0x6929f8: ldr             x16, [fp, #0x10]
    // 0x6929fc: stp             x0, x16, [SP, #-0x10]!
    // 0x692a00: ldr             x16, [fp, #0x18]
    // 0x692a04: SaveReg r16
    //     0x692a04: str             x16, [SP, #-8]!
    // 0x692a08: ldr             x0, [fp, #0x10]
    // 0x692a0c: ClosureCall
    //     0x692a0c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x692a10: ldur            x2, [x0, #0x1f]
    //     0x692a14: blr             x2
    // 0x692a18: add             SP, SP, #0x18
    // 0x692a1c: LoadField: d0 = r0->field_7
    //     0x692a1c: ldur            d0, [x0, #7]
    // 0x692a20: ldr             x1, [fp, #0x20]
    // 0x692a24: LoadField: r2 = r1->field_63
    //     0x692a24: ldur            w2, [x1, #0x63]
    // 0x692a28: DecompressPointer r2
    //     0x692a28: add             x2, x2, HEAP, lsl #32
    // 0x692a2c: LoadField: d1 = r2->field_7
    //     0x692a2c: ldur            d1, [x2, #7]
    // 0x692a30: fcmp            d0, d1
    // 0x692a34: b.vs            #0x692a44
    // 0x692a38: b.le            #0x692a44
    // 0x692a3c: d2 = 0.000000
    //     0x692a3c: eor             v2.16b, v2.16b, v2.16b
    // 0x692a40: b               #0x692a84
    // 0x692a44: fcmp            d0, d1
    // 0x692a48: b.vs            #0x692a5c
    // 0x692a4c: b.ge            #0x692a5c
    // 0x692a50: mov             v0.16b, v1.16b
    // 0x692a54: d2 = 0.000000
    //     0x692a54: eor             v2.16b, v2.16b, v2.16b
    // 0x692a58: b               #0x692a84
    // 0x692a5c: d2 = 0.000000
    //     0x692a5c: eor             v2.16b, v2.16b, v2.16b
    // 0x692a60: fcmp            d0, d2
    // 0x692a64: b.vs            #0x692a78
    // 0x692a68: b.ne            #0x692a78
    // 0x692a6c: fadd            d3, d0, d1
    // 0x692a70: mov             v0.16b, v3.16b
    // 0x692a74: b               #0x692a84
    // 0x692a78: fcmp            d1, d1
    // 0x692a7c: b.vc            #0x692a84
    // 0x692a80: mov             v0.16b, v1.16b
    // 0x692a84: stur            d0, [fp, #-0x10]
    // 0x692a88: LoadField: d1 = r0->field_f
    //     0x692a88: ldur            d1, [x0, #0xf]
    // 0x692a8c: LoadField: d3 = r2->field_f
    //     0x692a8c: ldur            d3, [x2, #0xf]
    // 0x692a90: fcmp            d1, d3
    // 0x692a94: b.vs            #0x692a9c
    // 0x692a98: b.gt            #0x692ad4
    // 0x692a9c: fcmp            d1, d3
    // 0x692aa0: b.vs            #0x692ab0
    // 0x692aa4: b.ge            #0x692ab0
    // 0x692aa8: mov             v1.16b, v3.16b
    // 0x692aac: b               #0x692ad4
    // 0x692ab0: fcmp            d1, d2
    // 0x692ab4: b.vs            #0x692ac8
    // 0x692ab8: b.ne            #0x692ac8
    // 0x692abc: fadd            d2, d1, d3
    // 0x692ac0: mov             v1.16b, v2.16b
    // 0x692ac4: b               #0x692ad4
    // 0x692ac8: fcmp            d3, d3
    // 0x692acc: b.vc            #0x692ad4
    // 0x692ad0: mov             v1.16b, v3.16b
    // 0x692ad4: stur            d1, [fp, #-8]
    // 0x692ad8: r0 = Size()
    //     0x692ad8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x692adc: ldur            d0, [fp, #-0x10]
    // 0x692ae0: StoreField: r0->field_7 = d0
    //     0x692ae0: stur            d0, [x0, #7]
    // 0x692ae4: ldur            d0, [fp, #-8]
    // 0x692ae8: StoreField: r0->field_f = d0
    //     0x692ae8: stur            d0, [x0, #0xf]
    // 0x692aec: ldr             x16, [fp, #0x18]
    // 0x692af0: stp             x0, x16, [SP, #-0x10]!
    // 0x692af4: r0 = constrain()
    //     0x692af4: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x692af8: add             SP, SP, #0x10
    // 0x692afc: LeaveFrame
    //     0x692afc: mov             SP, fp
    //     0x692b00: ldp             fp, lr, [SP], #0x10
    // 0x692b04: ret
    //     0x692b04: ret             
    // 0x692b08: r0 = Instance_Size
    //     0x692b08: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x692b0c: LeaveFrame
    //     0x692b0c: mov             SP, fp
    //     0x692b10: ldp             fp, lr, [SP], #0x10
    // 0x692b14: ret
    //     0x692b14: ret             
    // 0x692b18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x692b18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x692b1c: b               #0x6929e4
  }
  set _ minSize=(/* No info */) {
    // ** addr: 0x6c2738, size: 0xa0
    // 0x6c2738: EnterFrame
    //     0x6c2738: stp             fp, lr, [SP, #-0x10]!
    //     0x6c273c: mov             fp, SP
    // 0x6c2740: CheckStackOverflow
    //     0x6c2740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2744: cmp             SP, x16
    //     0x6c2748: b.ls            #0x6c27d0
    // 0x6c274c: ldr             x1, [fp, #0x18]
    // 0x6c2750: LoadField: r0 = r1->field_63
    //     0x6c2750: ldur            w0, [x1, #0x63]
    // 0x6c2754: DecompressPointer r0
    //     0x6c2754: add             x0, x0, HEAP, lsl #32
    // 0x6c2758: ldr             x2, [fp, #0x10]
    // 0x6c275c: LoadField: d0 = r2->field_7
    //     0x6c275c: ldur            d0, [x2, #7]
    // 0x6c2760: LoadField: d1 = r0->field_7
    //     0x6c2760: ldur            d1, [x0, #7]
    // 0x6c2764: fcmp            d0, d1
    // 0x6c2768: b.vs            #0x6c2794
    // 0x6c276c: b.ne            #0x6c2794
    // 0x6c2770: LoadField: d0 = r2->field_f
    //     0x6c2770: ldur            d0, [x2, #0xf]
    // 0x6c2774: LoadField: d1 = r0->field_f
    //     0x6c2774: ldur            d1, [x0, #0xf]
    // 0x6c2778: fcmp            d0, d1
    // 0x6c277c: b.vs            #0x6c2794
    // 0x6c2780: b.ne            #0x6c2794
    // 0x6c2784: r0 = Null
    //     0x6c2784: mov             x0, NULL
    // 0x6c2788: LeaveFrame
    //     0x6c2788: mov             SP, fp
    //     0x6c278c: ldp             fp, lr, [SP], #0x10
    // 0x6c2790: ret
    //     0x6c2790: ret             
    // 0x6c2794: mov             x0, x2
    // 0x6c2798: StoreField: r1->field_63 = r0
    //     0x6c2798: stur            w0, [x1, #0x63]
    //     0x6c279c: ldurb           w16, [x1, #-1]
    //     0x6c27a0: ldurb           w17, [x0, #-1]
    //     0x6c27a4: and             x16, x17, x16, lsr #2
    //     0x6c27a8: tst             x16, HEAP, lsr #32
    //     0x6c27ac: b.eq            #0x6c27b4
    //     0x6c27b0: bl              #0xd6826c
    // 0x6c27b4: SaveReg r1
    //     0x6c27b4: str             x1, [SP, #-8]!
    // 0x6c27b8: r0 = markNeedsLayout()
    //     0x6c27b8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c27bc: add             SP, SP, #8
    // 0x6c27c0: r0 = Null
    //     0x6c27c0: mov             x0, NULL
    // 0x6c27c4: LeaveFrame
    //     0x6c27c4: mov             SP, fp
    //     0x6c27c8: ldp             fp, lr, [SP], #0x10
    // 0x6c27cc: ret
    //     0x6c27cc: ret             
    // 0x6c27d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c27d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c27d4: b               #0x6c274c
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e34c, size: 0x48
    // 0xa5e34c: EnterFrame
    //     0xa5e34c: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e350: mov             fp, SP
    // 0xa5e354: CheckStackOverflow
    //     0xa5e354: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e358: cmp             SP, x16
    //     0xa5e35c: b.ls            #0xa5e38c
    // 0xa5e360: ldr             x16, [fp, #0x18]
    // 0xa5e364: ldr             lr, [fp, #0x10]
    // 0xa5e368: stp             lr, x16, [SP, #-0x10]!
    // 0xa5e36c: r16 = Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static.
    //     0xa5e36c: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1cf88] Closure: (RenderBox, BoxConstraints) => Size from Function 'dryLayoutChild': static. (0x7fe6e1e33c20)
    //     0xa5e370: ldr             x16, [x16, #0xf88]
    // 0xa5e374: SaveReg r16
    //     0xa5e374: str             x16, [SP, #-8]!
    // 0xa5e378: r0 = _computeSize()
    //     0xa5e378: bl              #0x6929cc  ; [package:flutter/src/material/button.dart] _RenderInputPadding::_computeSize
    // 0xa5e37c: add             SP, SP, #0x18
    // 0xa5e380: LeaveFrame
    //     0xa5e380: mov             SP, fp
    //     0xa5e384: ldp             fp, lr, [SP], #0x10
    // 0xa5e388: ret
    //     0xa5e388: ret             
    // 0xa5e38c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5e38c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5e390: b               #0xa5e360
  }
}

// class id: 3335, size: 0x18, field offset: 0x14
//   transformed mixin,
abstract class __RawMaterialButtonState&State&MaterialStateMixin extends State<RawMaterialButton>
     with MaterialStateMixin<X0 bound StatefulWidget> {

  get _ isPressed(/* No info */) {
    // ** addr: 0x7b0394, size: 0x48
    // 0x7b0394: EnterFrame
    //     0x7b0394: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0398: mov             fp, SP
    // 0x7b039c: CheckStackOverflow
    //     0x7b039c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b03a0: cmp             SP, x16
    //     0x7b03a4: b.ls            #0x7b03d4
    // 0x7b03a8: ldr             x0, [fp, #0x10]
    // 0x7b03ac: LoadField: r1 = r0->field_13
    //     0x7b03ac: ldur            w1, [x0, #0x13]
    // 0x7b03b0: DecompressPointer r1
    //     0x7b03b0: add             x1, x1, HEAP, lsl #32
    // 0x7b03b4: r16 = Instance_MaterialState
    //     0x7b03b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x7b03b8: ldr             x16, [x16, #0xf90]
    // 0x7b03bc: stp             x16, x1, [SP, #-0x10]!
    // 0x7b03c0: r0 = contains()
    //     0x7b03c0: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x7b03c4: add             SP, SP, #0x10
    // 0x7b03c8: LeaveFrame
    //     0x7b03c8: mov             SP, fp
    //     0x7b03cc: ldp             fp, lr, [SP], #0x10
    // 0x7b03d0: ret
    //     0x7b03d0: ret             
    // 0x7b03d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b03d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b03d8: b               #0x7b03a8
  }
  get _ isDisabled(/* No info */) {
    // ** addr: 0x7b03dc, size: 0x48
    // 0x7b03dc: EnterFrame
    //     0x7b03dc: stp             fp, lr, [SP, #-0x10]!
    //     0x7b03e0: mov             fp, SP
    // 0x7b03e4: CheckStackOverflow
    //     0x7b03e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b03e8: cmp             SP, x16
    //     0x7b03ec: b.ls            #0x7b041c
    // 0x7b03f0: ldr             x0, [fp, #0x10]
    // 0x7b03f4: LoadField: r1 = r0->field_13
    //     0x7b03f4: ldur            w1, [x0, #0x13]
    // 0x7b03f8: DecompressPointer r1
    //     0x7b03f8: add             x1, x1, HEAP, lsl #32
    // 0x7b03fc: r16 = Instance_MaterialState
    //     0x7b03fc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b0400: ldr             x16, [x16, #0x2a0]
    // 0x7b0404: stp             x16, x1, [SP, #-0x10]!
    // 0x7b0408: r0 = contains()
    //     0x7b0408: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x7b040c: add             SP, SP, #0x10
    // 0x7b0410: LeaveFrame
    //     0x7b0410: mov             SP, fp
    //     0x7b0414: ldp             fp, lr, [SP], #0x10
    // 0x7b0418: ret
    //     0x7b0418: ret             
    // 0x7b041c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b041c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0420: b               #0x7b03f0
  }
  _ removeMaterialState(/* No info */) {
    // ** addr: 0x7b0424, size: 0x6c
    // 0x7b0424: EnterFrame
    //     0x7b0424: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0428: mov             fp, SP
    // 0x7b042c: CheckStackOverflow
    //     0x7b042c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0430: cmp             SP, x16
    //     0x7b0434: b.ls            #0x7b0488
    // 0x7b0438: ldr             x0, [fp, #0x18]
    // 0x7b043c: LoadField: r1 = r0->field_13
    //     0x7b043c: ldur            w1, [x0, #0x13]
    // 0x7b0440: DecompressPointer r1
    //     0x7b0440: add             x1, x1, HEAP, lsl #32
    // 0x7b0444: ldr             x16, [fp, #0x10]
    // 0x7b0448: stp             x16, x1, [SP, #-0x10]!
    // 0x7b044c: r0 = remove()
    //     0x7b044c: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x7b0450: add             SP, SP, #0x10
    // 0x7b0454: tbnz            w0, #4, #0x7b0478
    // 0x7b0458: r1 = Function '<anonymous closure>':.
    //     0x7b0458: add             x1, PP, #0x40, lsl #12  ; [pp+0x40228] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7b045c: ldr             x1, [x1, #0x228]
    // 0x7b0460: r2 = Null
    //     0x7b0460: mov             x2, NULL
    // 0x7b0464: r0 = AllocateClosure()
    //     0x7b0464: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0468: ldr             x16, [fp, #0x18]
    // 0x7b046c: stp             x0, x16, [SP, #-0x10]!
    // 0x7b0470: r0 = setState()
    //     0x7b0470: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b0474: add             SP, SP, #0x10
    // 0x7b0478: r0 = Null
    //     0x7b0478: mov             x0, NULL
    // 0x7b047c: LeaveFrame
    //     0x7b047c: mov             SP, fp
    //     0x7b0480: ldp             fp, lr, [SP], #0x10
    // 0x7b0484: ret
    //     0x7b0484: ret             
    // 0x7b0488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b048c: b               #0x7b0438
  }
  _ setMaterialState(/* No info */) {
    // ** addr: 0x7b0490, size: 0x60
    // 0x7b0490: EnterFrame
    //     0x7b0490: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0494: mov             fp, SP
    // 0x7b0498: CheckStackOverflow
    //     0x7b0498: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b049c: cmp             SP, x16
    //     0x7b04a0: b.ls            #0x7b04e8
    // 0x7b04a4: ldr             x0, [fp, #0x10]
    // 0x7b04a8: tbnz            w0, #4, #0x7b04c4
    // 0x7b04ac: ldr             x16, [fp, #0x20]
    // 0x7b04b0: ldr             lr, [fp, #0x18]
    // 0x7b04b4: stp             lr, x16, [SP, #-0x10]!
    // 0x7b04b8: r0 = addMaterialState()
    //     0x7b04b8: bl              #0x7b04f0  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::addMaterialState
    // 0x7b04bc: add             SP, SP, #0x10
    // 0x7b04c0: b               #0x7b04d8
    // 0x7b04c4: ldr             x16, [fp, #0x20]
    // 0x7b04c8: ldr             lr, [fp, #0x18]
    // 0x7b04cc: stp             lr, x16, [SP, #-0x10]!
    // 0x7b04d0: r0 = removeMaterialState()
    //     0x7b04d0: bl              #0x7b0424  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::removeMaterialState
    // 0x7b04d4: add             SP, SP, #0x10
    // 0x7b04d8: r0 = Null
    //     0x7b04d8: mov             x0, NULL
    // 0x7b04dc: LeaveFrame
    //     0x7b04dc: mov             SP, fp
    //     0x7b04e0: ldp             fp, lr, [SP], #0x10
    // 0x7b04e4: ret
    //     0x7b04e4: ret             
    // 0x7b04e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b04e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b04ec: b               #0x7b04a4
  }
  _ addMaterialState(/* No info */) {
    // ** addr: 0x7b04f0, size: 0x6c
    // 0x7b04f0: EnterFrame
    //     0x7b04f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7b04f4: mov             fp, SP
    // 0x7b04f8: CheckStackOverflow
    //     0x7b04f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b04fc: cmp             SP, x16
    //     0x7b0500: b.ls            #0x7b0554
    // 0x7b0504: ldr             x0, [fp, #0x18]
    // 0x7b0508: LoadField: r1 = r0->field_13
    //     0x7b0508: ldur            w1, [x0, #0x13]
    // 0x7b050c: DecompressPointer r1
    //     0x7b050c: add             x1, x1, HEAP, lsl #32
    // 0x7b0510: ldr             x16, [fp, #0x10]
    // 0x7b0514: stp             x16, x1, [SP, #-0x10]!
    // 0x7b0518: r0 = add()
    //     0x7b0518: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x7b051c: add             SP, SP, #0x10
    // 0x7b0520: tbnz            w0, #4, #0x7b0544
    // 0x7b0524: r1 = Function '<anonymous closure>':.
    //     0x7b0524: add             x1, PP, #0x40, lsl #12  ; [pp+0x40230] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7b0528: ldr             x1, [x1, #0x230]
    // 0x7b052c: r2 = Null
    //     0x7b052c: mov             x2, NULL
    // 0x7b0530: r0 = AllocateClosure()
    //     0x7b0530: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0534: ldr             x16, [fp, #0x18]
    // 0x7b0538: stp             x0, x16, [SP, #-0x10]!
    // 0x7b053c: r0 = setState()
    //     0x7b053c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b0540: add             SP, SP, #0x10
    // 0x7b0544: r0 = Null
    //     0x7b0544: mov             x0, NULL
    // 0x7b0548: LeaveFrame
    //     0x7b0548: mov             SP, fp
    //     0x7b054c: ldp             fp, lr, [SP], #0x10
    // 0x7b0550: ret
    //     0x7b0550: ret             
    // 0x7b0554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0554: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0558: b               #0x7b0504
  }
  get _ isFocused(/* No info */) {
    // ** addr: 0x84bae8, size: 0x48
    // 0x84bae8: EnterFrame
    //     0x84bae8: stp             fp, lr, [SP, #-0x10]!
    //     0x84baec: mov             fp, SP
    // 0x84baf0: CheckStackOverflow
    //     0x84baf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84baf4: cmp             SP, x16
    //     0x84baf8: b.ls            #0x84bb28
    // 0x84bafc: ldr             x0, [fp, #0x10]
    // 0x84bb00: LoadField: r1 = r0->field_13
    //     0x84bb00: ldur            w1, [x0, #0x13]
    // 0x84bb04: DecompressPointer r1
    //     0x84bb04: add             x1, x1, HEAP, lsl #32
    // 0x84bb08: r16 = Instance_MaterialState
    //     0x84bb08: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x84bb0c: ldr             x16, [x16, #0xf88]
    // 0x84bb10: stp             x16, x1, [SP, #-0x10]!
    // 0x84bb14: r0 = contains()
    //     0x84bb14: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84bb18: add             SP, SP, #0x10
    // 0x84bb1c: LeaveFrame
    //     0x84bb1c: mov             SP, fp
    //     0x84bb20: ldp             fp, lr, [SP], #0x10
    // 0x84bb24: ret
    //     0x84bb24: ret             
    // 0x84bb28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bb28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bb2c: b               #0x84bafc
  }
  get _ isHovered(/* No info */) {
    // ** addr: 0x84bb30, size: 0x48
    // 0x84bb30: EnterFrame
    //     0x84bb30: stp             fp, lr, [SP, #-0x10]!
    //     0x84bb34: mov             fp, SP
    // 0x84bb38: CheckStackOverflow
    //     0x84bb38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84bb3c: cmp             SP, x16
    //     0x84bb40: b.ls            #0x84bb70
    // 0x84bb44: ldr             x0, [fp, #0x10]
    // 0x84bb48: LoadField: r1 = r0->field_13
    //     0x84bb48: ldur            w1, [x0, #0x13]
    // 0x84bb4c: DecompressPointer r1
    //     0x84bb4c: add             x1, x1, HEAP, lsl #32
    // 0x84bb50: r16 = Instance_MaterialState
    //     0x84bb50: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x84bb54: ldr             x16, [x16, #0xf78]
    // 0x84bb58: stp             x16, x1, [SP, #-0x10]!
    // 0x84bb5c: r0 = contains()
    //     0x84bb5c: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84bb60: add             SP, SP, #0x10
    // 0x84bb64: LeaveFrame
    //     0x84bb64: mov             SP, fp
    //     0x84bb68: ldp             fp, lr, [SP], #0x10
    // 0x84bb6c: ret
    //     0x84bb6c: ret             
    // 0x84bb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bb70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bb74: b               #0x84bb44
  }
  [closure] void <anonymous closure>(dynamic, bool) {
    // ** addr: 0x84bd18, size: 0xa8
    // 0x84bd18: EnterFrame
    //     0x84bd18: stp             fp, lr, [SP, #-0x10]!
    //     0x84bd1c: mov             fp, SP
    // 0x84bd20: AllocStack(0x8)
    //     0x84bd20: sub             SP, SP, #8
    // 0x84bd24: SetupParameters()
    //     0x84bd24: ldr             x0, [fp, #0x18]
    //     0x84bd28: ldur            w1, [x0, #0x17]
    //     0x84bd2c: add             x1, x1, HEAP, lsl #32
    //     0x84bd30: stur            x1, [fp, #-8]
    // 0x84bd34: CheckStackOverflow
    //     0x84bd34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84bd38: cmp             SP, x16
    //     0x84bd3c: b.ls            #0x84bdb8
    // 0x84bd40: LoadField: r0 = r1->field_f
    //     0x84bd40: ldur            w0, [x1, #0xf]
    // 0x84bd44: DecompressPointer r0
    //     0x84bd44: add             x0, x0, HEAP, lsl #32
    // 0x84bd48: LoadField: r2 = r0->field_13
    //     0x84bd48: ldur            w2, [x0, #0x13]
    // 0x84bd4c: DecompressPointer r2
    //     0x84bd4c: add             x2, x2, HEAP, lsl #32
    // 0x84bd50: LoadField: r0 = r1->field_13
    //     0x84bd50: ldur            w0, [x1, #0x13]
    // 0x84bd54: DecompressPointer r0
    //     0x84bd54: add             x0, x0, HEAP, lsl #32
    // 0x84bd58: stp             x0, x2, [SP, #-0x10]!
    // 0x84bd5c: r0 = contains()
    //     0x84bd5c: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x84bd60: add             SP, SP, #0x10
    // 0x84bd64: mov             x1, x0
    // 0x84bd68: ldr             x0, [fp, #0x10]
    // 0x84bd6c: cmp             w1, w0
    // 0x84bd70: b.ne            #0x84bd84
    // 0x84bd74: r0 = Null
    //     0x84bd74: mov             x0, NULL
    // 0x84bd78: LeaveFrame
    //     0x84bd78: mov             SP, fp
    //     0x84bd7c: ldp             fp, lr, [SP], #0x10
    // 0x84bd80: ret
    //     0x84bd80: ret             
    // 0x84bd84: ldur            x1, [fp, #-8]
    // 0x84bd88: LoadField: r2 = r1->field_f
    //     0x84bd88: ldur            w2, [x1, #0xf]
    // 0x84bd8c: DecompressPointer r2
    //     0x84bd8c: add             x2, x2, HEAP, lsl #32
    // 0x84bd90: LoadField: r3 = r1->field_13
    //     0x84bd90: ldur            w3, [x1, #0x13]
    // 0x84bd94: DecompressPointer r3
    //     0x84bd94: add             x3, x3, HEAP, lsl #32
    // 0x84bd98: stp             x3, x2, [SP, #-0x10]!
    // 0x84bd9c: SaveReg r0
    //     0x84bd9c: str             x0, [SP, #-8]!
    // 0x84bda0: r0 = setMaterialState()
    //     0x84bda0: bl              #0x7b0490  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::setMaterialState
    // 0x84bda4: add             SP, SP, #0x18
    // 0x84bda8: r0 = Null
    //     0x84bda8: mov             x0, NULL
    // 0x84bdac: LeaveFrame
    //     0x84bdac: mov             SP, fp
    //     0x84bdb0: ldp             fp, lr, [SP], #0x10
    // 0x84bdb4: ret
    //     0x84bdb4: ret             
    // 0x84bdb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bdb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bdbc: b               #0x84bd40
  }
  _ __RawMaterialButtonState&State&MaterialStateMixin(/* No info */) {
    // ** addr: 0xa40260, size: 0xc0
    // 0xa40260: EnterFrame
    //     0xa40260: stp             fp, lr, [SP, #-0x10]!
    //     0xa40264: mov             fp, SP
    // 0xa40268: AllocStack(0x10)
    //     0xa40268: sub             SP, SP, #0x10
    // 0xa4026c: CheckStackOverflow
    //     0xa4026c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40270: cmp             SP, x16
    //     0xa40274: b.ls            #0xa40318
    // 0xa40278: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xa40278: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa4027c: ldr             x0, [x0, #0x598]
    //     0xa40280: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa40284: cmp             w0, w16
    //     0xa40288: b.ne            #0xa40294
    //     0xa4028c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xa40290: bl              #0xd67cdc
    // 0xa40294: r1 = <MaterialState>
    //     0xa40294: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0xa40298: ldr             x1, [x1, #0xcf0]
    // 0xa4029c: stur            x0, [fp, #-8]
    // 0xa402a0: r0 = _Set()
    //     0xa402a0: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xa402a4: mov             x1, x0
    // 0xa402a8: ldur            x0, [fp, #-8]
    // 0xa402ac: stur            x1, [fp, #-0x10]
    // 0xa402b0: StoreField: r1->field_1b = r0
    //     0xa402b0: stur            w0, [x1, #0x1b]
    // 0xa402b4: StoreField: r1->field_b = rZR
    //     0xa402b4: stur            wzr, [x1, #0xb]
    // 0xa402b8: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xa402b8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa402bc: ldr             x0, [x0, #0x5a0]
    //     0xa402c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa402c4: cmp             w0, w16
    //     0xa402c8: b.ne            #0xa402d4
    //     0xa402cc: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xa402d0: bl              #0xd67cdc
    // 0xa402d4: mov             x1, x0
    // 0xa402d8: ldur            x0, [fp, #-0x10]
    // 0xa402dc: StoreField: r0->field_f = r1
    //     0xa402dc: stur            w1, [x0, #0xf]
    // 0xa402e0: StoreField: r0->field_13 = rZR
    //     0xa402e0: stur            wzr, [x0, #0x13]
    // 0xa402e4: StoreField: r0->field_17 = rZR
    //     0xa402e4: stur            wzr, [x0, #0x17]
    // 0xa402e8: ldr             x1, [fp, #0x10]
    // 0xa402ec: StoreField: r1->field_13 = r0
    //     0xa402ec: stur            w0, [x1, #0x13]
    //     0xa402f0: ldurb           w16, [x1, #-1]
    //     0xa402f4: ldurb           w17, [x0, #-1]
    //     0xa402f8: and             x16, x17, x16, lsr #2
    //     0xa402fc: tst             x16, HEAP, lsr #32
    //     0xa40300: b.eq            #0xa40308
    //     0xa40304: bl              #0xd6826c
    // 0xa40308: r0 = Null
    //     0xa40308: mov             x0, NULL
    // 0xa4030c: LeaveFrame
    //     0xa4030c: mov             SP, fp
    //     0xa40310: ldp             fp, lr, [SP], #0x10
    // 0xa40314: ret
    //     0xa40314: ret             
    // 0xa40318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa40318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4031c: b               #0xa40278
  }
}

// class id: 3336, size: 0x18, field offset: 0x18
class _RawMaterialButtonState extends __RawMaterialButtonState&State&MaterialStateMixin {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b0240, size: 0x154
    // 0x7b0240: EnterFrame
    //     0x7b0240: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0244: mov             fp, SP
    // 0x7b0248: CheckStackOverflow
    //     0x7b0248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b024c: cmp             SP, x16
    //     0x7b0250: b.ls            #0x7b0388
    // 0x7b0254: ldr             x0, [fp, #0x10]
    // 0x7b0258: r2 = Null
    //     0x7b0258: mov             x2, NULL
    // 0x7b025c: r1 = Null
    //     0x7b025c: mov             x1, NULL
    // 0x7b0260: r4 = 59
    //     0x7b0260: mov             x4, #0x3b
    // 0x7b0264: branchIfSmi(r0, 0x7b0270)
    //     0x7b0264: tbz             w0, #0, #0x7b0270
    // 0x7b0268: r4 = LoadClassIdInstr(r0)
    //     0x7b0268: ldur            x4, [x0, #-1]
    //     0x7b026c: ubfx            x4, x4, #0xc, #0x14
    // 0x7b0270: r17 = 4166
    //     0x7b0270: mov             x17, #0x1046
    // 0x7b0274: cmp             x4, x17
    // 0x7b0278: b.eq            #0x7b0290
    // 0x7b027c: r8 = RawMaterialButton
    //     0x7b027c: add             x8, PP, #0x40, lsl #12  ; [pp+0x40238] Type: RawMaterialButton
    //     0x7b0280: ldr             x8, [x8, #0x238]
    // 0x7b0284: r3 = Null
    //     0x7b0284: add             x3, PP, #0x40, lsl #12  ; [pp+0x40240] Null
    //     0x7b0288: ldr             x3, [x3, #0x240]
    // 0x7b028c: r0 = RawMaterialButton()
    //     0x7b028c: bl              #0x7b055c  ; IsType_RawMaterialButton_Stub
    // 0x7b0290: ldr             x3, [fp, #0x18]
    // 0x7b0294: LoadField: r2 = r3->field_7
    //     0x7b0294: ldur            w2, [x3, #7]
    // 0x7b0298: DecompressPointer r2
    //     0x7b0298: add             x2, x2, HEAP, lsl #32
    // 0x7b029c: ldr             x0, [fp, #0x10]
    // 0x7b02a0: r1 = Null
    //     0x7b02a0: mov             x1, NULL
    // 0x7b02a4: cmp             w2, NULL
    // 0x7b02a8: b.eq            #0x7b02cc
    // 0x7b02ac: LoadField: r4 = r2->field_17
    //     0x7b02ac: ldur            w4, [x2, #0x17]
    // 0x7b02b0: DecompressPointer r4
    //     0x7b02b0: add             x4, x4, HEAP, lsl #32
    // 0x7b02b4: r8 = X0 bound StatefulWidget
    //     0x7b02b4: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b02b8: ldr             x8, [x8, #0x858]
    // 0x7b02bc: LoadField: r9 = r4->field_7
    //     0x7b02bc: ldur            x9, [x4, #7]
    // 0x7b02c0: r3 = Null
    //     0x7b02c0: add             x3, PP, #0x40, lsl #12  ; [pp+0x40250] Null
    //     0x7b02c4: ldr             x3, [x3, #0x250]
    // 0x7b02c8: blr             x9
    // 0x7b02cc: ldr             x0, [fp, #0x18]
    // 0x7b02d0: LoadField: r1 = r0->field_b
    //     0x7b02d0: ldur            w1, [x0, #0xb]
    // 0x7b02d4: DecompressPointer r1
    //     0x7b02d4: add             x1, x1, HEAP, lsl #32
    // 0x7b02d8: cmp             w1, NULL
    // 0x7b02dc: b.eq            #0x7b0390
    // 0x7b02e0: LoadField: r2 = r1->field_b
    //     0x7b02e0: ldur            w2, [x1, #0xb]
    // 0x7b02e4: DecompressPointer r2
    //     0x7b02e4: add             x2, x2, HEAP, lsl #32
    // 0x7b02e8: cmp             w2, NULL
    // 0x7b02ec: b.eq            #0x7b02f8
    // 0x7b02f0: r1 = true
    //     0x7b02f0: add             x1, NULL, #0x20  ; true
    // 0x7b02f4: b               #0x7b02fc
    // 0x7b02f8: r1 = false
    //     0x7b02f8: add             x1, NULL, #0x30  ; false
    // 0x7b02fc: eor             x2, x1, #0x10
    // 0x7b0300: r16 = Instance_MaterialState
    //     0x7b0300: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b0304: ldr             x16, [x16, #0x2a0]
    // 0x7b0308: stp             x16, x0, [SP, #-0x10]!
    // 0x7b030c: SaveReg r2
    //     0x7b030c: str             x2, [SP, #-8]!
    // 0x7b0310: r0 = setMaterialState()
    //     0x7b0310: bl              #0x7b0490  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::setMaterialState
    // 0x7b0314: add             SP, SP, #0x18
    // 0x7b0318: ldr             x0, [fp, #0x18]
    // 0x7b031c: LoadField: r1 = r0->field_13
    //     0x7b031c: ldur            w1, [x0, #0x13]
    // 0x7b0320: DecompressPointer r1
    //     0x7b0320: add             x1, x1, HEAP, lsl #32
    // 0x7b0324: r16 = Instance_MaterialState
    //     0x7b0324: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x7b0328: ldr             x16, [x16, #0x2a0]
    // 0x7b032c: stp             x16, x1, [SP, #-0x10]!
    // 0x7b0330: r0 = contains()
    //     0x7b0330: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x7b0334: add             SP, SP, #0x10
    // 0x7b0338: tbnz            w0, #4, #0x7b0378
    // 0x7b033c: ldr             x0, [fp, #0x18]
    // 0x7b0340: LoadField: r1 = r0->field_13
    //     0x7b0340: ldur            w1, [x0, #0x13]
    // 0x7b0344: DecompressPointer r1
    //     0x7b0344: add             x1, x1, HEAP, lsl #32
    // 0x7b0348: r16 = Instance_MaterialState
    //     0x7b0348: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x7b034c: ldr             x16, [x16, #0xf90]
    // 0x7b0350: stp             x16, x1, [SP, #-0x10]!
    // 0x7b0354: r0 = contains()
    //     0x7b0354: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0x7b0358: add             SP, SP, #0x10
    // 0x7b035c: tbnz            w0, #4, #0x7b0378
    // 0x7b0360: ldr             x16, [fp, #0x18]
    // 0x7b0364: r30 = Instance_MaterialState
    //     0x7b0364: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x7b0368: ldr             lr, [lr, #0xf90]
    // 0x7b036c: stp             lr, x16, [SP, #-0x10]!
    // 0x7b0370: r0 = removeMaterialState()
    //     0x7b0370: bl              #0x7b0424  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::removeMaterialState
    // 0x7b0374: add             SP, SP, #0x10
    // 0x7b0378: r0 = Null
    //     0x7b0378: mov             x0, NULL
    // 0x7b037c: LeaveFrame
    //     0x7b037c: mov             SP, fp
    //     0x7b0380: ldp             fp, lr, [SP], #0x10
    // 0x7b0384: ret
    //     0x7b0384: ret             
    // 0x7b0388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0388: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b038c: b               #0x7b0254
    // 0x7b0390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0390: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x84aec0, size: 0x734
    // 0x84aec0: EnterFrame
    //     0x84aec0: stp             fp, lr, [SP, #-0x10]!
    //     0x84aec4: mov             fp, SP
    // 0x84aec8: AllocStack(0xb8)
    //     0x84aec8: sub             SP, SP, #0xb8
    // 0x84aecc: CheckStackOverflow
    //     0x84aecc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84aed0: cmp             SP, x16
    //     0x84aed4: b.ls            #0x84b5c4
    // 0x84aed8: ldr             x0, [fp, #0x18]
    // 0x84aedc: LoadField: r1 = r0->field_b
    //     0x84aedc: ldur            w1, [x0, #0xb]
    // 0x84aee0: DecompressPointer r1
    //     0x84aee0: add             x1, x1, HEAP, lsl #32
    // 0x84aee4: cmp             w1, NULL
    // 0x84aee8: b.eq            #0x84b5cc
    // 0x84aeec: LoadField: r2 = r1->field_1b
    //     0x84aeec: ldur            w2, [x1, #0x1b]
    // 0x84aef0: DecompressPointer r2
    //     0x84aef0: add             x2, x2, HEAP, lsl #32
    // 0x84aef4: LoadField: r1 = r2->field_b
    //     0x84aef4: ldur            w1, [x2, #0xb]
    // 0x84aef8: DecompressPointer r1
    //     0x84aef8: add             x1, x1, HEAP, lsl #32
    // 0x84aefc: LoadField: r2 = r0->field_13
    //     0x84aefc: ldur            w2, [x0, #0x13]
    // 0x84af00: DecompressPointer r2
    //     0x84af00: add             x2, x2, HEAP, lsl #32
    // 0x84af04: r16 = <Color?>
    //     0x84af04: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x84af08: ldr             x16, [x16, #0xf68]
    // 0x84af0c: stp             x1, x16, [SP, #-0x10]!
    // 0x84af10: SaveReg r2
    //     0x84af10: str             x2, [SP, #-8]!
    // 0x84af14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x84af14: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x84af18: r0 = resolveAs()
    //     0x84af18: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x84af1c: add             SP, SP, #0x18
    // 0x84af20: mov             x1, x0
    // 0x84af24: ldr             x0, [fp, #0x18]
    // 0x84af28: stur            x1, [fp, #-8]
    // 0x84af2c: LoadField: r2 = r0->field_b
    //     0x84af2c: ldur            w2, [x0, #0xb]
    // 0x84af30: DecompressPointer r2
    //     0x84af30: add             x2, x2, HEAP, lsl #32
    // 0x84af34: cmp             w2, NULL
    // 0x84af38: b.eq            #0x84b5d0
    // 0x84af3c: LoadField: r3 = r2->field_67
    //     0x84af3c: ldur            w3, [x2, #0x67]
    // 0x84af40: DecompressPointer r3
    //     0x84af40: add             x3, x3, HEAP, lsl #32
    // 0x84af44: LoadField: r2 = r0->field_13
    //     0x84af44: ldur            w2, [x0, #0x13]
    // 0x84af48: DecompressPointer r2
    //     0x84af48: add             x2, x2, HEAP, lsl #32
    // 0x84af4c: r16 = <ShapeBorder?>
    //     0x84af4c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28a40] TypeArguments: <ShapeBorder?>
    //     0x84af50: ldr             x16, [x16, #0xa40]
    // 0x84af54: stp             x3, x16, [SP, #-0x10]!
    // 0x84af58: SaveReg r2
    //     0x84af58: str             x2, [SP, #-8]!
    // 0x84af5c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x84af5c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x84af60: r0 = resolveAs()
    //     0x84af60: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x84af64: add             SP, SP, #0x18
    // 0x84af68: mov             x1, x0
    // 0x84af6c: ldr             x0, [fp, #0x18]
    // 0x84af70: stur            x1, [fp, #-0x10]
    // 0x84af74: LoadField: r2 = r0->field_b
    //     0x84af74: ldur            w2, [x0, #0xb]
    // 0x84af78: DecompressPointer r2
    //     0x84af78: add             x2, x2, HEAP, lsl #32
    // 0x84af7c: cmp             w2, NULL
    // 0x84af80: b.eq            #0x84b5d4
    // 0x84af84: LoadField: r3 = r2->field_5f
    //     0x84af84: ldur            w3, [x2, #0x5f]
    // 0x84af88: DecompressPointer r3
    //     0x84af88: add             x3, x3, HEAP, lsl #32
    // 0x84af8c: SaveReg r3
    //     0x84af8c: str             x3, [SP, #-8]!
    // 0x84af90: r0 = baseSizeAdjustment()
    //     0x84af90: bl              #0x630630  ; [package:flutter/src/material/theme_data.dart] VisualDensity::baseSizeAdjustment
    // 0x84af94: add             SP, SP, #8
    // 0x84af98: mov             x1, x0
    // 0x84af9c: ldr             x0, [fp, #0x18]
    // 0x84afa0: stur            x1, [fp, #-0x18]
    // 0x84afa4: LoadField: r2 = r0->field_b
    //     0x84afa4: ldur            w2, [x0, #0xb]
    // 0x84afa8: DecompressPointer r2
    //     0x84afa8: add             x2, x2, HEAP, lsl #32
    // 0x84afac: cmp             w2, NULL
    // 0x84afb0: b.eq            #0x84b5d8
    // 0x84afb4: LoadField: r3 = r2->field_5f
    //     0x84afb4: ldur            w3, [x2, #0x5f]
    // 0x84afb8: DecompressPointer r3
    //     0x84afb8: add             x3, x3, HEAP, lsl #32
    // 0x84afbc: LoadField: r4 = r2->field_63
    //     0x84afbc: ldur            w4, [x2, #0x63]
    // 0x84afc0: DecompressPointer r4
    //     0x84afc0: add             x4, x4, HEAP, lsl #32
    // 0x84afc4: stp             x4, x3, [SP, #-0x10]!
    // 0x84afc8: r0 = effectiveConstraints()
    //     0x84afc8: bl              #0x84bb78  ; [package:flutter/src/material/theme_data.dart] VisualDensity::effectiveConstraints
    // 0x84afcc: add             SP, SP, #0x10
    // 0x84afd0: mov             x1, x0
    // 0x84afd4: ldr             x0, [fp, #0x18]
    // 0x84afd8: stur            x1, [fp, #-0x20]
    // 0x84afdc: LoadField: r2 = r0->field_b
    //     0x84afdc: ldur            w2, [x0, #0xb]
    // 0x84afe0: DecompressPointer r2
    //     0x84afe0: add             x2, x2, HEAP, lsl #32
    // 0x84afe4: cmp             w2, NULL
    // 0x84afe8: b.eq            #0x84b5dc
    // 0x84afec: LoadField: r3 = r2->field_17
    //     0x84afec: ldur            w3, [x2, #0x17]
    // 0x84aff0: DecompressPointer r3
    //     0x84aff0: add             x3, x3, HEAP, lsl #32
    // 0x84aff4: cmp             w3, NULL
    // 0x84aff8: b.ne            #0x84b004
    // 0x84affc: r3 = Instance__EnabledAndDisabledMouseCursor
    //     0x84affc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0x84b000: ldr             x3, [x3, #0x208]
    // 0x84b004: ldur            x2, [fp, #-0x18]
    // 0x84b008: LoadField: r4 = r0->field_13
    //     0x84b008: ldur            w4, [x0, #0x13]
    // 0x84b00c: DecompressPointer r4
    //     0x84b00c: add             x4, x4, HEAP, lsl #32
    // 0x84b010: r16 = <MouseCursor?>
    //     0x84b010: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0x84b014: ldr             x16, [x16, #0x8b8]
    // 0x84b018: stp             x3, x16, [SP, #-0x10]!
    // 0x84b01c: SaveReg r4
    //     0x84b01c: str             x4, [SP, #-8]!
    // 0x84b020: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x84b020: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x84b024: r0 = resolveAs()
    //     0x84b024: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x84b028: add             SP, SP, #0x18
    // 0x84b02c: mov             x1, x0
    // 0x84b030: ldr             x0, [fp, #0x18]
    // 0x84b034: stur            x1, [fp, #-0x30]
    // 0x84b038: LoadField: r2 = r0->field_b
    //     0x84b038: ldur            w2, [x0, #0xb]
    // 0x84b03c: DecompressPointer r2
    //     0x84b03c: add             x2, x2, HEAP, lsl #32
    // 0x84b040: cmp             w2, NULL
    // 0x84b044: b.eq            #0x84b5e0
    // 0x84b048: LoadField: r3 = r2->field_5b
    //     0x84b048: ldur            w3, [x2, #0x5b]
    // 0x84b04c: DecompressPointer r3
    //     0x84b04c: add             x3, x3, HEAP, lsl #32
    // 0x84b050: ldur            x2, [fp, #-0x18]
    // 0x84b054: stur            x3, [fp, #-0x28]
    // 0x84b058: LoadField: d0 = r2->field_7
    //     0x84b058: ldur            d0, [x2, #7]
    // 0x84b05c: stur            d0, [fp, #-0xb0]
    // 0x84b060: LoadField: d1 = r2->field_f
    //     0x84b060: ldur            d1, [x2, #0xf]
    // 0x84b064: stur            d1, [fp, #-0xa8]
    // 0x84b068: r0 = EdgeInsets()
    //     0x84b068: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x84b06c: ldur            d0, [fp, #-0xb0]
    // 0x84b070: StoreField: r0->field_7 = d0
    //     0x84b070: stur            d0, [x0, #7]
    // 0x84b074: ldur            d1, [fp, #-0xa8]
    // 0x84b078: StoreField: r0->field_f = d1
    //     0x84b078: stur            d1, [x0, #0xf]
    // 0x84b07c: StoreField: r0->field_17 = d0
    //     0x84b07c: stur            d0, [x0, #0x17]
    // 0x84b080: StoreField: r0->field_1f = d1
    //     0x84b080: stur            d1, [x0, #0x1f]
    // 0x84b084: ldur            x1, [fp, #-0x28]
    // 0x84b088: r2 = LoadClassIdInstr(r1)
    //     0x84b088: ldur            x2, [x1, #-1]
    //     0x84b08c: ubfx            x2, x2, #0xc, #0x14
    // 0x84b090: lsl             x2, x2, #1
    // 0x84b094: r17 = 4204
    //     0x84b094: mov             x17, #0x106c
    // 0x84b098: cmp             w2, w17
    // 0x84b09c: b.ne            #0x84b0b0
    // 0x84b0a0: stp             x0, x1, [SP, #-0x10]!
    // 0x84b0a4: r0 = add()
    //     0x84b0a4: bl              #0xcfb938  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::add
    // 0x84b0a8: add             SP, SP, #0x10
    // 0x84b0ac: b               #0x84b0ec
    // 0x84b0b0: r17 = 4206
    //     0x84b0b0: mov             x17, #0x106e
    // 0x84b0b4: cmp             w2, w17
    // 0x84b0b8: b.ne            #0x84b0cc
    // 0x84b0bc: stp             x0, x1, [SP, #-0x10]!
    // 0x84b0c0: r0 = +()
    //     0x84b0c0: bl              #0x518b08  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::+
    // 0x84b0c4: add             SP, SP, #0x10
    // 0x84b0c8: b               #0x84b0ec
    // 0x84b0cc: r2 = LoadClassIdInstr(r1)
    //     0x84b0cc: ldur            x2, [x1, #-1]
    //     0x84b0d0: ubfx            x2, x2, #0xc, #0x14
    // 0x84b0d4: stp             x0, x1, [SP, #-0x10]!
    // 0x84b0d8: mov             x0, x2
    // 0x84b0dc: r0 = GDT[cid_x0 + -0xfcc]()
    //     0x84b0dc: sub             lr, x0, #0xfcc
    //     0x84b0e0: ldr             lr, [x21, lr, lsl #3]
    //     0x84b0e4: blr             lr
    // 0x84b0e8: add             SP, SP, #0x10
    // 0x84b0ec: ldr             x1, [fp, #0x18]
    // 0x84b0f0: r2 = LoadClassIdInstr(r0)
    //     0x84b0f0: ldur            x2, [x0, #-1]
    //     0x84b0f4: ubfx            x2, x2, #0xc, #0x14
    // 0x84b0f8: r16 = Instance__MixedEdgeInsets
    //     0x84b0f8: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e6a0] Obj!_MixedEdgeInsets@b357d1
    //     0x84b0fc: ldr             x16, [x16, #0x6a0]
    // 0x84b100: stp             x16, x0, [SP, #-0x10]!
    // 0x84b104: mov             x0, x2
    // 0x84b108: r0 = GDT[cid_x0 + -0xfc3]()
    //     0x84b108: sub             lr, x0, #0xfc3
    //     0x84b10c: ldr             lr, [x21, lr, lsl #3]
    //     0x84b110: blr             lr
    // 0x84b114: add             SP, SP, #0x10
    // 0x84b118: stur            x0, [fp, #-0x18]
    // 0x84b11c: ldr             x16, [fp, #0x18]
    // 0x84b120: SaveReg r16
    //     0x84b120: str             x16, [SP, #-8]!
    // 0x84b124: r0 = _effectiveElevation()
    //     0x84b124: bl              #0x84b9b4  ; [package:flutter/src/material/button.dart] _RawMaterialButtonState::_effectiveElevation
    // 0x84b128: add             SP, SP, #8
    // 0x84b12c: ldr             x0, [fp, #0x18]
    // 0x84b130: stur            d0, [fp, #-0xb8]
    // 0x84b134: LoadField: r1 = r0->field_b
    //     0x84b134: ldur            w1, [x0, #0xb]
    // 0x84b138: DecompressPointer r1
    //     0x84b138: add             x1, x1, HEAP, lsl #32
    // 0x84b13c: cmp             w1, NULL
    // 0x84b140: b.eq            #0x84b5e4
    // 0x84b144: LoadField: r2 = r1->field_1b
    //     0x84b144: ldur            w2, [x1, #0x1b]
    // 0x84b148: DecompressPointer r2
    //     0x84b148: add             x2, x2, HEAP, lsl #32
    // 0x84b14c: ldur            x16, [fp, #-8]
    // 0x84b150: stp             x16, x2, [SP, #-0x10]!
    // 0x84b154: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x84b154: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x84b158: ldr             x4, [x4, #0x168]
    // 0x84b15c: r0 = copyWith()
    //     0x84b15c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x84b160: add             SP, SP, #0x10
    // 0x84b164: mov             x1, x0
    // 0x84b168: ldr             x0, [fp, #0x18]
    // 0x84b16c: stur            x1, [fp, #-0x38]
    // 0x84b170: LoadField: r2 = r0->field_b
    //     0x84b170: ldur            w2, [x0, #0xb]
    // 0x84b174: DecompressPointer r2
    //     0x84b174: add             x2, x2, HEAP, lsl #32
    // 0x84b178: cmp             w2, NULL
    // 0x84b17c: b.eq            #0x84b5e8
    // 0x84b180: LoadField: r3 = r2->field_1f
    //     0x84b180: ldur            w3, [x2, #0x1f]
    // 0x84b184: DecompressPointer r3
    //     0x84b184: add             x3, x3, HEAP, lsl #32
    // 0x84b188: stur            x3, [fp, #-0x28]
    // 0x84b18c: ldr             x16, [fp, #0x10]
    // 0x84b190: SaveReg r16
    //     0x84b190: str             x16, [SP, #-8]!
    // 0x84b194: r0 = of()
    //     0x84b194: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84b198: add             SP, SP, #8
    // 0x84b19c: LoadField: r1 = r0->field_2b
    //     0x84b19c: ldur            w1, [x0, #0x2b]
    // 0x84b1a0: DecompressPointer r1
    //     0x84b1a0: add             x1, x1, HEAP, lsl #32
    // 0x84b1a4: tbnz            w1, #4, #0x84b1c4
    // 0x84b1a8: ldr             x16, [fp, #0x10]
    // 0x84b1ac: SaveReg r16
    //     0x84b1ac: str             x16, [SP, #-8]!
    // 0x84b1b0: r0 = of()
    //     0x84b1b0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84b1b4: add             SP, SP, #8
    // 0x84b1b8: LoadField: r1 = r0->field_7b
    //     0x84b1b8: ldur            w1, [x0, #0x7b]
    // 0x84b1bc: DecompressPointer r1
    //     0x84b1bc: add             x1, x1, HEAP, lsl #32
    // 0x84b1c0: b               #0x84b1c8
    // 0x84b1c4: r1 = Null
    //     0x84b1c4: mov             x1, NULL
    // 0x84b1c8: ldr             x0, [fp, #0x18]
    // 0x84b1cc: stur            x1, [fp, #-0x60]
    // 0x84b1d0: LoadField: r2 = r0->field_b
    //     0x84b1d0: ldur            w2, [x0, #0xb]
    // 0x84b1d4: DecompressPointer r2
    //     0x84b1d4: add             x2, x2, HEAP, lsl #32
    // 0x84b1d8: stur            x2, [fp, #-0x58]
    // 0x84b1dc: cmp             w2, NULL
    // 0x84b1e0: b.eq            #0x84b5ec
    // 0x84b1e4: LoadField: r3 = r2->field_1f
    //     0x84b1e4: ldur            w3, [x2, #0x1f]
    // 0x84b1e8: DecompressPointer r3
    //     0x84b1e8: add             x3, x3, HEAP, lsl #32
    // 0x84b1ec: cmp             w3, NULL
    // 0x84b1f0: b.ne            #0x84b200
    // 0x84b1f4: r3 = Instance_MaterialType
    //     0x84b1f4: add             x3, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x84b1f8: ldr             x3, [x3, #0x2a8]
    // 0x84b1fc: b               #0x84b208
    // 0x84b200: r3 = Instance_MaterialType
    //     0x84b200: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e6b0] Obj!MaterialType@b65551
    //     0x84b204: ldr             x3, [x3, #0x6b0]
    // 0x84b208: stur            x3, [fp, #-0x50]
    // 0x84b20c: LoadField: r4 = r2->field_b
    //     0x84b20c: ldur            w4, [x2, #0xb]
    // 0x84b210: DecompressPointer r4
    //     0x84b210: add             x4, x4, HEAP, lsl #32
    // 0x84b214: stur            x4, [fp, #-0x48]
    // 0x84b218: cmp             w4, NULL
    // 0x84b21c: b.eq            #0x84b228
    // 0x84b220: r11 = true
    //     0x84b220: add             x11, NULL, #0x20  ; true
    // 0x84b224: b               #0x84b22c
    // 0x84b228: r11 = false
    //     0x84b228: add             x11, NULL, #0x30  ; false
    // 0x84b22c: ldur            x10, [fp, #-8]
    // 0x84b230: ldur            x9, [fp, #-0x10]
    // 0x84b234: ldur            x8, [fp, #-0x20]
    // 0x84b238: ldur            x7, [fp, #-0x30]
    // 0x84b23c: ldur            d0, [fp, #-0xb8]
    // 0x84b240: ldur            x5, [fp, #-0x38]
    // 0x84b244: ldur            x6, [fp, #-0x28]
    // 0x84b248: stur            x11, [fp, #-0x40]
    // 0x84b24c: r1 = 2
    //     0x84b24c: mov             x1, #2
    // 0x84b250: r0 = AllocateContext()
    //     0x84b250: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84b254: mov             x1, x0
    // 0x84b258: ldr             x0, [fp, #0x18]
    // 0x84b25c: stur            x1, [fp, #-0x68]
    // 0x84b260: StoreField: r1->field_f = r0
    //     0x84b260: stur            w0, [x1, #0xf]
    // 0x84b264: r2 = Instance_MaterialState
    //     0x84b264: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x84b268: ldr             x2, [x2, #0xf88]
    // 0x84b26c: StoreField: r1->field_13 = r2
    //     0x84b26c: stur            w2, [x1, #0x13]
    // 0x84b270: r1 = 2
    //     0x84b270: mov             x1, #2
    // 0x84b274: r0 = AllocateContext()
    //     0x84b274: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84b278: mov             x1, x0
    // 0x84b27c: ldr             x0, [fp, #0x18]
    // 0x84b280: stur            x1, [fp, #-0x90]
    // 0x84b284: StoreField: r1->field_f = r0
    //     0x84b284: stur            w0, [x1, #0xf]
    // 0x84b288: r2 = Instance_MaterialState
    //     0x84b288: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x84b28c: ldr             x2, [x2, #0xf90]
    // 0x84b290: StoreField: r1->field_13 = r2
    //     0x84b290: stur            w2, [x1, #0x13]
    // 0x84b294: ldur            x2, [fp, #-0x58]
    // 0x84b298: LoadField: r3 = r2->field_2f
    //     0x84b298: ldur            w3, [x2, #0x2f]
    // 0x84b29c: DecompressPointer r3
    //     0x84b29c: add             x3, x3, HEAP, lsl #32
    // 0x84b2a0: stur            x3, [fp, #-0x88]
    // 0x84b2a4: LoadField: r4 = r2->field_2b
    //     0x84b2a4: ldur            w4, [x2, #0x2b]
    // 0x84b2a8: DecompressPointer r4
    //     0x84b2a8: add             x4, x4, HEAP, lsl #32
    // 0x84b2ac: stur            x4, [fp, #-0x80]
    // 0x84b2b0: LoadField: r5 = r2->field_23
    //     0x84b2b0: ldur            w5, [x2, #0x23]
    // 0x84b2b4: DecompressPointer r5
    //     0x84b2b4: add             x5, x5, HEAP, lsl #32
    // 0x84b2b8: stur            x5, [fp, #-0x78]
    // 0x84b2bc: LoadField: r6 = r2->field_27
    //     0x84b2bc: ldur            w6, [x2, #0x27]
    // 0x84b2c0: DecompressPointer r6
    //     0x84b2c0: add             x6, x6, HEAP, lsl #32
    // 0x84b2c4: stur            x6, [fp, #-0x70]
    // 0x84b2c8: r1 = 2
    //     0x84b2c8: mov             x1, #2
    // 0x84b2cc: r0 = AllocateContext()
    //     0x84b2cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84b2d0: mov             x1, x0
    // 0x84b2d4: ldr             x0, [fp, #0x18]
    // 0x84b2d8: stur            x1, [fp, #-0x98]
    // 0x84b2dc: StoreField: r1->field_f = r0
    //     0x84b2dc: stur            w0, [x1, #0xf]
    // 0x84b2e0: r2 = Instance_MaterialState
    //     0x84b2e0: add             x2, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x84b2e4: ldr             x2, [x2, #0xf78]
    // 0x84b2e8: StoreField: r1->field_13 = r2
    //     0x84b2e8: stur            w2, [x1, #0x13]
    // 0x84b2ec: r0 = IconThemeData()
    //     0x84b2ec: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0x84b2f0: mov             x1, x0
    // 0x84b2f4: ldur            x0, [fp, #-8]
    // 0x84b2f8: stur            x1, [fp, #-0xa0]
    // 0x84b2fc: StoreField: r1->field_1b = r0
    //     0x84b2fc: stur            w0, [x1, #0x1b]
    // 0x84b300: ldur            x0, [fp, #-0x58]
    // 0x84b304: LoadField: r2 = r0->field_6f
    //     0x84b304: ldur            w2, [x0, #0x6f]
    // 0x84b308: DecompressPointer r2
    //     0x84b308: add             x2, x2, HEAP, lsl #32
    // 0x84b30c: stur            x2, [fp, #-8]
    // 0x84b310: r0 = Center()
    //     0x84b310: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0x84b314: mov             x1, x0
    // 0x84b318: r0 = Instance_Alignment
    //     0x84b318: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x84b31c: ldr             x0, [x0, #0xc70]
    // 0x84b320: stur            x1, [fp, #-0x58]
    // 0x84b324: StoreField: r1->field_f = r0
    //     0x84b324: stur            w0, [x1, #0xf]
    // 0x84b328: r0 = 1.000000
    //     0x84b328: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x84b32c: StoreField: r1->field_13 = r0
    //     0x84b32c: stur            w0, [x1, #0x13]
    // 0x84b330: StoreField: r1->field_17 = r0
    //     0x84b330: stur            w0, [x1, #0x17]
    // 0x84b334: ldur            x0, [fp, #-8]
    // 0x84b338: StoreField: r1->field_b = r0
    //     0x84b338: stur            w0, [x1, #0xb]
    // 0x84b33c: r0 = Container()
    //     0x84b33c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x84b340: stur            x0, [fp, #-8]
    // 0x84b344: ldur            x16, [fp, #-0x18]
    // 0x84b348: stp             x16, x0, [SP, #-0x10]!
    // 0x84b34c: ldur            x16, [fp, #-0x58]
    // 0x84b350: SaveReg r16
    //     0x84b350: str             x16, [SP, #-8]!
    // 0x84b354: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, padding, 0x1, null]
    //     0x84b354: add             x4, PP, #0x25, lsl #12  ; [pp+0x25990] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "padding", 0x1, Null]
    //     0x84b358: ldr             x4, [x4, #0x990]
    // 0x84b35c: r0 = Container()
    //     0x84b35c: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x84b360: add             SP, SP, #0x18
    // 0x84b364: ldur            x16, [fp, #-8]
    // 0x84b368: ldur            lr, [fp, #-0xa0]
    // 0x84b36c: stp             lr, x16, [SP, #-0x10]!
    // 0x84b370: r0 = merge()
    //     0x84b370: bl              #0x847e00  ; [package:flutter/src/widgets/icon_theme.dart] IconTheme::merge
    // 0x84b374: add             SP, SP, #0x10
    // 0x84b378: stur            x0, [fp, #-8]
    // 0x84b37c: r0 = InkWell()
    //     0x84b37c: bl              #0x832ed8  ; AllocateInkWellStub -> InkWell (size=0x7c)
    // 0x84b380: mov             x3, x0
    // 0x84b384: ldur            x0, [fp, #-8]
    // 0x84b388: stur            x3, [fp, #-0x18]
    // 0x84b38c: StoreField: r3->field_b = r0
    //     0x84b38c: stur            w0, [x3, #0xb]
    // 0x84b390: ldur            x0, [fp, #-0x48]
    // 0x84b394: StoreField: r3->field_f = r0
    //     0x84b394: stur            w0, [x3, #0xf]
    // 0x84b398: ldur            x2, [fp, #-0x90]
    // 0x84b39c: r1 = Function '<anonymous closure>':.
    //     0x84b39c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40220] AnonymousClosure: (0x84bd18), of [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin
    //     0x84b3a0: ldr             x1, [x1, #0x220]
    // 0x84b3a4: r0 = AllocateClosure()
    //     0x84b3a4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84b3a8: mov             x1, x0
    // 0x84b3ac: ldur            x0, [fp, #-0x18]
    // 0x84b3b0: StoreField: r0->field_27 = r1
    //     0x84b3b0: stur            w1, [x0, #0x27]
    // 0x84b3b4: ldur            x2, [fp, #-0x98]
    // 0x84b3b8: r1 = Function '<anonymous closure>':.
    //     0x84b3b8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40220] AnonymousClosure: (0x84bd18), of [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin
    //     0x84b3bc: ldr             x1, [x1, #0x220]
    // 0x84b3c0: r0 = AllocateClosure()
    //     0x84b3c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84b3c4: mov             x1, x0
    // 0x84b3c8: ldur            x0, [fp, #-0x18]
    // 0x84b3cc: StoreField: r0->field_2b = r1
    //     0x84b3cc: stur            w1, [x0, #0x2b]
    // 0x84b3d0: ldur            x1, [fp, #-0x30]
    // 0x84b3d4: StoreField: r0->field_2f = r1
    //     0x84b3d4: stur            w1, [x0, #0x2f]
    // 0x84b3d8: r3 = true
    //     0x84b3d8: add             x3, NULL, #0x20  ; true
    // 0x84b3dc: StoreField: r0->field_33 = r3
    //     0x84b3dc: stur            w3, [x0, #0x33]
    // 0x84b3e0: r1 = Instance_BoxShape
    //     0x84b3e0: add             x1, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x84b3e4: ldr             x1, [x1, #0xe68]
    // 0x84b3e8: StoreField: r0->field_37 = r1
    //     0x84b3e8: stur            w1, [x0, #0x37]
    // 0x84b3ec: ldur            x4, [fp, #-0x10]
    // 0x84b3f0: StoreField: r0->field_43 = r4
    //     0x84b3f0: stur            w4, [x0, #0x43]
    // 0x84b3f4: ldur            x1, [fp, #-0x78]
    // 0x84b3f8: StoreField: r0->field_47 = r1
    //     0x84b3f8: stur            w1, [x0, #0x47]
    // 0x84b3fc: ldur            x1, [fp, #-0x70]
    // 0x84b400: StoreField: r0->field_4b = r1
    //     0x84b400: stur            w1, [x0, #0x4b]
    // 0x84b404: ldur            x1, [fp, #-0x80]
    // 0x84b408: StoreField: r0->field_4f = r1
    //     0x84b408: stur            w1, [x0, #0x4f]
    // 0x84b40c: ldur            x1, [fp, #-0x88]
    // 0x84b410: StoreField: r0->field_57 = r1
    //     0x84b410: stur            w1, [x0, #0x57]
    // 0x84b414: StoreField: r0->field_5f = r3
    //     0x84b414: stur            w3, [x0, #0x5f]
    // 0x84b418: r5 = false
    //     0x84b418: add             x5, NULL, #0x30  ; false
    // 0x84b41c: StoreField: r0->field_63 = r5
    //     0x84b41c: stur            w5, [x0, #0x63]
    // 0x84b420: ldur            x1, [fp, #-0x40]
    // 0x84b424: StoreField: r0->field_73 = r1
    //     0x84b424: stur            w1, [x0, #0x73]
    // 0x84b428: ldur            x2, [fp, #-0x68]
    // 0x84b42c: r1 = Function '<anonymous closure>':.
    //     0x84b42c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40220] AnonymousClosure: (0x84bd18), of [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin
    //     0x84b430: ldr             x1, [x1, #0x220]
    // 0x84b434: r0 = AllocateClosure()
    //     0x84b434: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84b438: mov             x1, x0
    // 0x84b43c: ldur            x0, [fp, #-0x18]
    // 0x84b440: StoreField: r0->field_67 = r1
    //     0x84b440: stur            w1, [x0, #0x67]
    // 0x84b444: r1 = false
    //     0x84b444: add             x1, NULL, #0x30  ; false
    // 0x84b448: StoreField: r0->field_6b = r1
    //     0x84b448: stur            w1, [x0, #0x6b]
    // 0x84b44c: r0 = Material()
    //     0x84b44c: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x84b450: mov             x1, x0
    // 0x84b454: ldur            x0, [fp, #-0x50]
    // 0x84b458: stur            x1, [fp, #-8]
    // 0x84b45c: StoreField: r1->field_f = r0
    //     0x84b45c: stur            w0, [x1, #0xf]
    // 0x84b460: ldur            d0, [fp, #-0xb8]
    // 0x84b464: StoreField: r1->field_13 = d0
    //     0x84b464: stur            d0, [x1, #0x13]
    // 0x84b468: ldur            x0, [fp, #-0x28]
    // 0x84b46c: StoreField: r1->field_1b = r0
    //     0x84b46c: stur            w0, [x1, #0x1b]
    // 0x84b470: ldur            x0, [fp, #-0x60]
    // 0x84b474: StoreField: r1->field_1f = r0
    //     0x84b474: stur            w0, [x1, #0x1f]
    // 0x84b478: ldur            x0, [fp, #-0x38]
    // 0x84b47c: StoreField: r1->field_27 = r0
    //     0x84b47c: stur            w0, [x1, #0x27]
    // 0x84b480: ldur            x0, [fp, #-0x10]
    // 0x84b484: StoreField: r1->field_2b = r0
    //     0x84b484: stur            w0, [x1, #0x2b]
    // 0x84b488: r0 = true
    //     0x84b488: add             x0, NULL, #0x20  ; true
    // 0x84b48c: StoreField: r1->field_2f = r0
    //     0x84b48c: stur            w0, [x1, #0x2f]
    // 0x84b490: r0 = Instance_Clip
    //     0x84b490: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x84b494: ldr             x0, [x0, #0xb38]
    // 0x84b498: StoreField: r1->field_33 = r0
    //     0x84b498: stur            w0, [x1, #0x33]
    // 0x84b49c: r0 = Instance_Duration
    //     0x84b49c: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x84b4a0: ldr             x0, [x0, #0x9e0]
    // 0x84b4a4: StoreField: r1->field_37 = r0
    //     0x84b4a4: stur            w0, [x1, #0x37]
    // 0x84b4a8: ldur            x0, [fp, #-0x18]
    // 0x84b4ac: StoreField: r1->field_b = r0
    //     0x84b4ac: stur            w0, [x1, #0xb]
    // 0x84b4b0: r0 = ConstrainedBox()
    //     0x84b4b0: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x84b4b4: mov             x1, x0
    // 0x84b4b8: ldur            x0, [fp, #-0x20]
    // 0x84b4bc: stur            x1, [fp, #-0x10]
    // 0x84b4c0: StoreField: r1->field_f = r0
    //     0x84b4c0: stur            w0, [x1, #0xf]
    // 0x84b4c4: ldur            x0, [fp, #-8]
    // 0x84b4c8: StoreField: r1->field_b = r0
    //     0x84b4c8: stur            w0, [x1, #0xb]
    // 0x84b4cc: ldr             x0, [fp, #0x18]
    // 0x84b4d0: LoadField: r2 = r0->field_b
    //     0x84b4d0: ldur            w2, [x0, #0xb]
    // 0x84b4d4: DecompressPointer r2
    //     0x84b4d4: add             x2, x2, HEAP, lsl #32
    // 0x84b4d8: stur            x2, [fp, #-8]
    // 0x84b4dc: cmp             w2, NULL
    // 0x84b4e0: b.eq            #0x84b5f0
    // 0x84b4e4: LoadField: r0 = r2->field_73
    //     0x84b4e4: ldur            w0, [x2, #0x73]
    // 0x84b4e8: DecompressPointer r0
    //     0x84b4e8: add             x0, x0, HEAP, lsl #32
    // 0x84b4ec: LoadField: r3 = r0->field_7
    //     0x84b4ec: ldur            x3, [x0, #7]
    // 0x84b4f0: cmp             x3, #0
    // 0x84b4f4: b.gt            #0x84b534
    // 0x84b4f8: ldur            d0, [fp, #-0xb0]
    // 0x84b4fc: ldur            d1, [fp, #-0xa8]
    // 0x84b500: d2 = 48.000000
    //     0x84b500: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0x84b504: ldr             d2, [x17, #0xbd0]
    // 0x84b508: fadd            d3, d2, d0
    // 0x84b50c: stur            d3, [fp, #-0xb8]
    // 0x84b510: fadd            d0, d2, d1
    // 0x84b514: stur            d0, [fp, #-0xb0]
    // 0x84b518: r0 = Size()
    //     0x84b518: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x84b51c: ldur            d0, [fp, #-0xb8]
    // 0x84b520: StoreField: r0->field_7 = d0
    //     0x84b520: stur            d0, [x0, #7]
    // 0x84b524: ldur            d0, [fp, #-0xb0]
    // 0x84b528: StoreField: r0->field_f = d0
    //     0x84b528: stur            d0, [x0, #0xf]
    // 0x84b52c: mov             x1, x0
    // 0x84b530: b               #0x84b538
    // 0x84b534: r1 = Instance_Size
    //     0x84b534: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x84b538: ldur            x0, [fp, #-8]
    // 0x84b53c: stur            x1, [fp, #-0x18]
    // 0x84b540: LoadField: r2 = r0->field_b
    //     0x84b540: ldur            w2, [x0, #0xb]
    // 0x84b544: DecompressPointer r2
    //     0x84b544: add             x2, x2, HEAP, lsl #32
    // 0x84b548: cmp             w2, NULL
    // 0x84b54c: b.eq            #0x84b558
    // 0x84b550: r2 = true
    //     0x84b550: add             x2, NULL, #0x20  ; true
    // 0x84b554: b               #0x84b55c
    // 0x84b558: r2 = false
    //     0x84b558: add             x2, NULL, #0x30  ; false
    // 0x84b55c: ldur            x0, [fp, #-0x10]
    // 0x84b560: stur            x2, [fp, #-8]
    // 0x84b564: r0 = _InputPadding()
    //     0x84b564: bl              #0x84b9a8  ; Allocate_InputPaddingStub -> _InputPadding (size=0x14)
    // 0x84b568: mov             x1, x0
    // 0x84b56c: ldur            x0, [fp, #-0x18]
    // 0x84b570: stur            x1, [fp, #-0x20]
    // 0x84b574: StoreField: r1->field_f = r0
    //     0x84b574: stur            w0, [x1, #0xf]
    // 0x84b578: ldur            x0, [fp, #-0x10]
    // 0x84b57c: StoreField: r1->field_b = r0
    //     0x84b57c: stur            w0, [x1, #0xb]
    // 0x84b580: r0 = Semantics()
    //     0x84b580: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x84b584: stur            x0, [fp, #-0x10]
    // 0x84b588: r16 = true
    //     0x84b588: add             x16, NULL, #0x20  ; true
    // 0x84b58c: stp             x16, x0, [SP, #-0x10]!
    // 0x84b590: r16 = true
    //     0x84b590: add             x16, NULL, #0x20  ; true
    // 0x84b594: ldur            lr, [fp, #-8]
    // 0x84b598: stp             lr, x16, [SP, #-0x10]!
    // 0x84b59c: ldur            x16, [fp, #-0x20]
    // 0x84b5a0: SaveReg r16
    //     0x84b5a0: str             x16, [SP, #-8]!
    // 0x84b5a4: r4 = const [0, 0x5, 0x5, 0x1, button, 0x2, child, 0x4, container, 0x1, enabled, 0x3, null]
    //     0x84b5a4: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e6b8] List(13) [0, 0x5, 0x5, 0x1, "button", 0x2, "child", 0x4, "container", 0x1, "enabled", 0x3, Null]
    //     0x84b5a8: ldr             x4, [x4, #0x6b8]
    // 0x84b5ac: r0 = Semantics()
    //     0x84b5ac: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x84b5b0: add             SP, SP, #0x28
    // 0x84b5b4: ldur            x0, [fp, #-0x10]
    // 0x84b5b8: LeaveFrame
    //     0x84b5b8: mov             SP, fp
    //     0x84b5bc: ldp             fp, lr, [SP], #0x10
    // 0x84b5c0: ret
    //     0x84b5c0: ret             
    // 0x84b5c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84b5c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84b5c8: b               #0x84aed8
    // 0x84b5cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5e4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84b5e4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x84b5e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84b5f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84b5f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveElevation(/* No info */) {
    // ** addr: 0x84b9b4, size: 0x134
    // 0x84b9b4: EnterFrame
    //     0x84b9b4: stp             fp, lr, [SP, #-0x10]!
    //     0x84b9b8: mov             fp, SP
    // 0x84b9bc: CheckStackOverflow
    //     0x84b9bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84b9c0: cmp             SP, x16
    //     0x84b9c4: b.ls            #0x84bacc
    // 0x84b9c8: ldr             x16, [fp, #0x10]
    // 0x84b9cc: SaveReg r16
    //     0x84b9cc: str             x16, [SP, #-8]!
    // 0x84b9d0: r0 = isDisabled()
    //     0x84b9d0: bl              #0x7b03dc  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::isDisabled
    // 0x84b9d4: add             SP, SP, #8
    // 0x84b9d8: tbnz            w0, #4, #0x84ba00
    // 0x84b9dc: ldr             x0, [fp, #0x10]
    // 0x84b9e0: LoadField: r1 = r0->field_b
    //     0x84b9e0: ldur            w1, [x0, #0xb]
    // 0x84b9e4: DecompressPointer r1
    //     0x84b9e4: add             x1, x1, HEAP, lsl #32
    // 0x84b9e8: cmp             w1, NULL
    // 0x84b9ec: b.eq            #0x84bad4
    // 0x84b9f0: LoadField: d0 = r1->field_53
    //     0x84b9f0: ldur            d0, [x1, #0x53]
    // 0x84b9f4: LeaveFrame
    //     0x84b9f4: mov             SP, fp
    //     0x84b9f8: ldp             fp, lr, [SP], #0x10
    // 0x84b9fc: ret
    //     0x84b9fc: ret             
    // 0x84ba00: ldr             x0, [fp, #0x10]
    // 0x84ba04: SaveReg r0
    //     0x84ba04: str             x0, [SP, #-8]!
    // 0x84ba08: r0 = isPressed()
    //     0x84ba08: bl              #0x7b0394  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::isPressed
    // 0x84ba0c: add             SP, SP, #8
    // 0x84ba10: tbnz            w0, #4, #0x84ba38
    // 0x84ba14: ldr             x0, [fp, #0x10]
    // 0x84ba18: LoadField: r1 = r0->field_b
    //     0x84ba18: ldur            w1, [x0, #0xb]
    // 0x84ba1c: DecompressPointer r1
    //     0x84ba1c: add             x1, x1, HEAP, lsl #32
    // 0x84ba20: cmp             w1, NULL
    // 0x84ba24: b.eq            #0x84bad8
    // 0x84ba28: LoadField: d0 = r1->field_4b
    //     0x84ba28: ldur            d0, [x1, #0x4b]
    // 0x84ba2c: LeaveFrame
    //     0x84ba2c: mov             SP, fp
    //     0x84ba30: ldp             fp, lr, [SP], #0x10
    // 0x84ba34: ret
    //     0x84ba34: ret             
    // 0x84ba38: ldr             x0, [fp, #0x10]
    // 0x84ba3c: SaveReg r0
    //     0x84ba3c: str             x0, [SP, #-8]!
    // 0x84ba40: r0 = isHovered()
    //     0x84ba40: bl              #0x84bb30  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::isHovered
    // 0x84ba44: add             SP, SP, #8
    // 0x84ba48: tbnz            w0, #4, #0x84ba70
    // 0x84ba4c: ldr             x0, [fp, #0x10]
    // 0x84ba50: LoadField: r1 = r0->field_b
    //     0x84ba50: ldur            w1, [x0, #0xb]
    // 0x84ba54: DecompressPointer r1
    //     0x84ba54: add             x1, x1, HEAP, lsl #32
    // 0x84ba58: cmp             w1, NULL
    // 0x84ba5c: b.eq            #0x84badc
    // 0x84ba60: LoadField: d0 = r1->field_3b
    //     0x84ba60: ldur            d0, [x1, #0x3b]
    // 0x84ba64: LeaveFrame
    //     0x84ba64: mov             SP, fp
    //     0x84ba68: ldp             fp, lr, [SP], #0x10
    // 0x84ba6c: ret
    //     0x84ba6c: ret             
    // 0x84ba70: ldr             x0, [fp, #0x10]
    // 0x84ba74: SaveReg r0
    //     0x84ba74: str             x0, [SP, #-8]!
    // 0x84ba78: r0 = isFocused()
    //     0x84ba78: bl              #0x84bae8  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::isFocused
    // 0x84ba7c: add             SP, SP, #8
    // 0x84ba80: tbnz            w0, #4, #0x84baa8
    // 0x84ba84: ldr             x0, [fp, #0x10]
    // 0x84ba88: LoadField: r1 = r0->field_b
    //     0x84ba88: ldur            w1, [x0, #0xb]
    // 0x84ba8c: DecompressPointer r1
    //     0x84ba8c: add             x1, x1, HEAP, lsl #32
    // 0x84ba90: cmp             w1, NULL
    // 0x84ba94: b.eq            #0x84bae0
    // 0x84ba98: LoadField: d0 = r1->field_43
    //     0x84ba98: ldur            d0, [x1, #0x43]
    // 0x84ba9c: LeaveFrame
    //     0x84ba9c: mov             SP, fp
    //     0x84baa0: ldp             fp, lr, [SP], #0x10
    // 0x84baa4: ret
    //     0x84baa4: ret             
    // 0x84baa8: ldr             x0, [fp, #0x10]
    // 0x84baac: LoadField: r1 = r0->field_b
    //     0x84baac: ldur            w1, [x0, #0xb]
    // 0x84bab0: DecompressPointer r1
    //     0x84bab0: add             x1, x1, HEAP, lsl #32
    // 0x84bab4: cmp             w1, NULL
    // 0x84bab8: b.eq            #0x84bae4
    // 0x84babc: LoadField: d0 = r1->field_33
    //     0x84babc: ldur            d0, [x1, #0x33]
    // 0x84bac0: LeaveFrame
    //     0x84bac0: mov             SP, fp
    //     0x84bac4: ldp             fp, lr, [SP], #0x10
    // 0x84bac8: ret
    //     0x84bac8: ret             
    // 0x84bacc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84bacc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84bad0: b               #0x84b9c8
    // 0x84bad4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84bad4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84bad8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84bad8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84badc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84badc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84bae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84bae0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84bae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84bae4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9444, size: 0x7c
    // 0x9d9444: EnterFrame
    //     0x9d9444: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9448: mov             fp, SP
    // 0x9d944c: CheckStackOverflow
    //     0x9d944c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9450: cmp             SP, x16
    //     0x9d9454: b.ls            #0x9d94b4
    // 0x9d9458: ldr             x0, [fp, #0x10]
    // 0x9d945c: LoadField: r1 = r0->field_b
    //     0x9d945c: ldur            w1, [x0, #0xb]
    // 0x9d9460: DecompressPointer r1
    //     0x9d9460: add             x1, x1, HEAP, lsl #32
    // 0x9d9464: cmp             w1, NULL
    // 0x9d9468: b.eq            #0x9d94bc
    // 0x9d946c: LoadField: r2 = r1->field_b
    //     0x9d946c: ldur            w2, [x1, #0xb]
    // 0x9d9470: DecompressPointer r2
    //     0x9d9470: add             x2, x2, HEAP, lsl #32
    // 0x9d9474: cmp             w2, NULL
    // 0x9d9478: b.eq            #0x9d9484
    // 0x9d947c: r1 = true
    //     0x9d947c: add             x1, NULL, #0x20  ; true
    // 0x9d9480: b               #0x9d9488
    // 0x9d9484: r1 = false
    //     0x9d9484: add             x1, NULL, #0x30  ; false
    // 0x9d9488: eor             x2, x1, #0x10
    // 0x9d948c: r16 = Instance_MaterialState
    //     0x9d948c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x9d9490: ldr             x16, [x16, #0x2a0]
    // 0x9d9494: stp             x16, x0, [SP, #-0x10]!
    // 0x9d9498: SaveReg r2
    //     0x9d9498: str             x2, [SP, #-8]!
    // 0x9d949c: r0 = setMaterialState()
    //     0x9d949c: bl              #0x7b0490  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::setMaterialState
    // 0x9d94a0: add             SP, SP, #0x18
    // 0x9d94a4: r0 = Null
    //     0x9d94a4: mov             x0, NULL
    // 0x9d94a8: LeaveFrame
    //     0x9d94a8: mov             SP, fp
    //     0x9d94ac: ldp             fp, lr, [SP], #0x10
    // 0x9d94b0: ret
    //     0x9d94b0: ret             
    // 0x9d94b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d94b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d94b8: b               #0x9d9458
    // 0x9d94bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d94bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3675, size: 0x14, field offset: 0x10
//   const constructor, 
class _InputPadding extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c26b8, size: 0x80
    // 0x6c26b8: EnterFrame
    //     0x6c26b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6c26bc: mov             fp, SP
    // 0x6c26c0: CheckStackOverflow
    //     0x6c26c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c26c4: cmp             SP, x16
    //     0x6c26c8: b.ls            #0x6c2730
    // 0x6c26cc: ldr             x0, [fp, #0x10]
    // 0x6c26d0: r2 = Null
    //     0x6c26d0: mov             x2, NULL
    // 0x6c26d4: r1 = Null
    //     0x6c26d4: mov             x1, NULL
    // 0x6c26d8: r4 = 59
    //     0x6c26d8: mov             x4, #0x3b
    // 0x6c26dc: branchIfSmi(r0, 0x6c26e8)
    //     0x6c26dc: tbz             w0, #0, #0x6c26e8
    // 0x6c26e0: r4 = LoadClassIdInstr(r0)
    //     0x6c26e0: ldur            x4, [x0, #-1]
    //     0x6c26e4: ubfx            x4, x4, #0xc, #0x14
    // 0x6c26e8: cmp             x4, #0x99e
    // 0x6c26ec: b.eq            #0x6c2704
    // 0x6c26f0: r8 = _RenderInputPadding
    //     0x6c26f0: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b910] Type: _RenderInputPadding
    //     0x6c26f4: ldr             x8, [x8, #0x910]
    // 0x6c26f8: r3 = Null
    //     0x6c26f8: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b918] Null
    //     0x6c26fc: ldr             x3, [x3, #0x918]
    // 0x6c2700: r0 = DefaultTypeTest()
    //     0x6c2700: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c2704: ldr             x0, [fp, #0x20]
    // 0x6c2708: LoadField: r1 = r0->field_f
    //     0x6c2708: ldur            w1, [x0, #0xf]
    // 0x6c270c: DecompressPointer r1
    //     0x6c270c: add             x1, x1, HEAP, lsl #32
    // 0x6c2710: ldr             x16, [fp, #0x10]
    // 0x6c2714: stp             x1, x16, [SP, #-0x10]!
    // 0x6c2718: r0 = minSize=()
    //     0x6c2718: bl              #0x6c2738  ; [package:flutter/src/material/button.dart] _RenderInputPadding::minSize=
    // 0x6c271c: add             SP, SP, #0x10
    // 0x6c2720: r0 = Null
    //     0x6c2720: mov             x0, NULL
    // 0x6c2724: LeaveFrame
    //     0x6c2724: mov             SP, fp
    //     0x6c2728: ldp             fp, lr, [SP], #0x10
    // 0x6c272c: ret
    //     0x6c272c: ret             
    // 0x6c2730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2730: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2734: b               #0x6c26cc
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ea1a4, size: 0x70
    // 0x6ea1a4: EnterFrame
    //     0x6ea1a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea1a8: mov             fp, SP
    // 0x6ea1ac: AllocStack(0x10)
    //     0x6ea1ac: sub             SP, SP, #0x10
    // 0x6ea1b0: CheckStackOverflow
    //     0x6ea1b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea1b4: cmp             SP, x16
    //     0x6ea1b8: b.ls            #0x6ea20c
    // 0x6ea1bc: ldr             x0, [fp, #0x18]
    // 0x6ea1c0: LoadField: r1 = r0->field_f
    //     0x6ea1c0: ldur            w1, [x0, #0xf]
    // 0x6ea1c4: DecompressPointer r1
    //     0x6ea1c4: add             x1, x1, HEAP, lsl #32
    // 0x6ea1c8: stur            x1, [fp, #-8]
    // 0x6ea1cc: r0 = _RenderInputPadding()
    //     0x6ea1cc: bl              #0x6ea214  ; Allocate_RenderInputPaddingStub -> _RenderInputPadding (size=0x68)
    // 0x6ea1d0: mov             x1, x0
    // 0x6ea1d4: ldur            x0, [fp, #-8]
    // 0x6ea1d8: stur            x1, [fp, #-0x10]
    // 0x6ea1dc: StoreField: r1->field_63 = r0
    //     0x6ea1dc: stur            w0, [x1, #0x63]
    // 0x6ea1e0: SaveReg r1
    //     0x6ea1e0: str             x1, [SP, #-8]!
    // 0x6ea1e4: r0 = RenderObject()
    //     0x6ea1e4: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea1e8: add             SP, SP, #8
    // 0x6ea1ec: ldur            x16, [fp, #-0x10]
    // 0x6ea1f0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea1f4: r0 = child=()
    //     0x6ea1f4: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea1f8: add             SP, SP, #0x10
    // 0x6ea1fc: ldur            x0, [fp, #-0x10]
    // 0x6ea200: LeaveFrame
    //     0x6ea200: mov             SP, fp
    //     0x6ea204: ldp             fp, lr, [SP], #0x10
    // 0x6ea208: ret
    //     0x6ea208: ret             
    // 0x6ea20c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea20c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea210: b               #0x6ea1bc
  }
}

// class id: 4166, size: 0x88, field offset: 0xc
//   const constructor, 
class RawMaterialButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40214, size: 0x4c
    // 0xa40214: EnterFrame
    //     0xa40214: stp             fp, lr, [SP, #-0x10]!
    //     0xa40218: mov             fp, SP
    // 0xa4021c: AllocStack(0x8)
    //     0xa4021c: sub             SP, SP, #8
    // 0xa40220: CheckStackOverflow
    //     0xa40220: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40224: cmp             SP, x16
    //     0xa40228: b.ls            #0xa40258
    // 0xa4022c: r1 = <RawMaterialButton>
    //     0xa4022c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37968] TypeArguments: <RawMaterialButton>
    //     0xa40230: ldr             x1, [x1, #0x968]
    // 0xa40234: r0 = _RawMaterialButtonState()
    //     0xa40234: bl              #0xa40320  ; Allocate_RawMaterialButtonStateStub -> _RawMaterialButtonState (size=0x18)
    // 0xa40238: stur            x0, [fp, #-8]
    // 0xa4023c: SaveReg r0
    //     0xa4023c: str             x0, [SP, #-8]!
    // 0xa40240: r0 = __RawMaterialButtonState&State&MaterialStateMixin()
    //     0xa40240: bl              #0xa40260  ; [package:flutter/src/material/button.dart] __RawMaterialButtonState&State&MaterialStateMixin::__RawMaterialButtonState&State&MaterialStateMixin
    // 0xa40244: add             SP, SP, #8
    // 0xa40248: ldur            x0, [fp, #-8]
    // 0xa4024c: LeaveFrame
    //     0xa4024c: mov             SP, fp
    //     0xa40250: ldp             fp, lr, [SP], #0x10
    // 0xa40254: ret
    //     0xa40254: ret             
    // 0xa40258: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa40258: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4025c: b               #0xa4022c
  }
}

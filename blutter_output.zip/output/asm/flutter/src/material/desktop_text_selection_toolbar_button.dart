// lib: , url: package:flutter/src/material/desktop_text_selection_toolbar_button.dart

// class id: 1049222, size: 0x8
class :: {
}

// class id: 3860, size: 0x14, field offset: 0xc
//   const constructor, 
class DesktopTextSelectionToolbarButton extends StatelessWidget {

  _ DesktopTextSelectionToolbarButton.text(/* No info */) {
    // ** addr: 0x8525a8, size: 0xfc
    // 0x8525a8: EnterFrame
    //     0x8525a8: stp             fp, lr, [SP, #-0x10]!
    //     0x8525ac: mov             fp, SP
    // 0x8525b0: AllocStack(0x8)
    //     0x8525b0: sub             SP, SP, #8
    // 0x8525b4: CheckStackOverflow
    //     0x8525b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8525b8: cmp             SP, x16
    //     0x8525bc: b.ls            #0x85269c
    // 0x8525c0: ldr             x0, [fp, #0x18]
    // 0x8525c4: ldr             x1, [fp, #0x28]
    // 0x8525c8: StoreField: r1->field_b = r0
    //     0x8525c8: stur            w0, [x1, #0xb]
    //     0x8525cc: ldurb           w16, [x1, #-1]
    //     0x8525d0: ldurb           w17, [x0, #-1]
    //     0x8525d4: and             x16, x17, x16, lsr #2
    //     0x8525d8: tst             x16, HEAP, lsr #32
    //     0x8525dc: b.eq            #0x8525e4
    //     0x8525e0: bl              #0xd6826c
    // 0x8525e4: ldr             x16, [fp, #0x20]
    // 0x8525e8: SaveReg r16
    //     0x8525e8: str             x16, [SP, #-8]!
    // 0x8525ec: r0 = of()
    //     0x8525ec: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8525f0: add             SP, SP, #8
    // 0x8525f4: LoadField: r1 = r0->field_3f
    //     0x8525f4: ldur            w1, [x0, #0x3f]
    // 0x8525f8: DecompressPointer r1
    //     0x8525f8: add             x1, x1, HEAP, lsl #32
    // 0x8525fc: LoadField: r0 = r1->field_7
    //     0x8525fc: ldur            w0, [x1, #7]
    // 0x852600: DecompressPointer r0
    //     0x852600: add             x0, x0, HEAP, lsl #32
    // 0x852604: r16 = Instance_Brightness
    //     0x852604: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x852608: cmp             w0, w16
    // 0x85260c: b.ne            #0x85261c
    // 0x852610: r2 = Instance_Color
    //     0x852610: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x852614: ldr             x2, [x2, #0xbe8]
    // 0x852618: b               #0x852624
    // 0x85261c: r2 = Instance_Color
    //     0x85261c: add             x2, PP, #0x28, lsl #12  ; [pp+0x28da0] Obj!Color@b5d1e1
    //     0x852620: ldr             x2, [x2, #0xda0]
    // 0x852624: ldr             x0, [fp, #0x28]
    // 0x852628: ldr             x1, [fp, #0x10]
    // 0x85262c: r16 = Instance_TextStyle
    //     0x85262c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28da8] Obj!TextStyle@b43b41
    //     0x852630: ldr             x16, [x16, #0xda8]
    // 0x852634: stp             x2, x16, [SP, #-0x10]!
    // 0x852638: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x852638: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x85263c: ldr             x4, [x4, #0x168]
    // 0x852640: r0 = copyWith()
    //     0x852640: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x852644: add             SP, SP, #0x10
    // 0x852648: stur            x0, [fp, #-8]
    // 0x85264c: r0 = Text()
    //     0x85264c: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0x852650: ldr             x1, [fp, #0x10]
    // 0x852654: StoreField: r0->field_b = r1
    //     0x852654: stur            w1, [x0, #0xb]
    // 0x852658: ldur            x1, [fp, #-8]
    // 0x85265c: StoreField: r0->field_13 = r1
    //     0x85265c: stur            w1, [x0, #0x13]
    // 0x852660: r1 = Instance_TextOverflow
    //     0x852660: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x852664: ldr             x1, [x1, #0x428]
    // 0x852668: StoreField: r0->field_2b = r1
    //     0x852668: stur            w1, [x0, #0x2b]
    // 0x85266c: ldr             x1, [fp, #0x28]
    // 0x852670: StoreField: r1->field_f = r0
    //     0x852670: stur            w0, [x1, #0xf]
    //     0x852674: ldurb           w16, [x1, #-1]
    //     0x852678: ldurb           w17, [x0, #-1]
    //     0x85267c: and             x16, x17, x16, lsr #2
    //     0x852680: tst             x16, HEAP, lsr #32
    //     0x852684: b.eq            #0x85268c
    //     0x852688: bl              #0xd6826c
    // 0x85268c: r0 = Null
    //     0x85268c: mov             x0, NULL
    // 0x852690: LeaveFrame
    //     0x852690: mov             SP, fp
    //     0x852694: ldp             fp, lr, [SP], #0x10
    // 0x852698: ret
    //     0x852698: ret             
    // 0x85269c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85269c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8526a0: b               #0x8525c0
  }
  _ build(/* No info */) {
    // ** addr: 0xb1e42c, size: 0x12c
    // 0xb1e42c: EnterFrame
    //     0xb1e42c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e430: mov             fp, SP
    // 0xb1e434: AllocStack(0x20)
    //     0xb1e434: sub             SP, SP, #0x20
    // 0xb1e438: CheckStackOverflow
    //     0xb1e438: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1e43c: cmp             SP, x16
    //     0xb1e440: b.ls            #0xb1e550
    // 0xb1e444: ldr             x16, [fp, #0x10]
    // 0xb1e448: SaveReg r16
    //     0xb1e448: str             x16, [SP, #-8]!
    // 0xb1e44c: r0 = of()
    //     0xb1e44c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1e450: add             SP, SP, #8
    // 0xb1e454: LoadField: r1 = r0->field_3f
    //     0xb1e454: ldur            w1, [x0, #0x3f]
    // 0xb1e458: DecompressPointer r1
    //     0xb1e458: add             x1, x1, HEAP, lsl #32
    // 0xb1e45c: LoadField: r0 = r1->field_7
    //     0xb1e45c: ldur            w0, [x1, #7]
    // 0xb1e460: DecompressPointer r0
    //     0xb1e460: add             x0, x0, HEAP, lsl #32
    // 0xb1e464: r16 = Instance_Brightness
    //     0xb1e464: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0xb1e468: cmp             w0, w16
    // 0xb1e46c: b.ne            #0xb1e47c
    // 0xb1e470: r1 = Instance_Color
    //     0xb1e470: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0xb1e474: ldr             x1, [x1, #0xbe8]
    // 0xb1e478: b               #0xb1e484
    // 0xb1e47c: r1 = Instance_Color
    //     0xb1e47c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28da0] Obj!Color@b5d1e1
    //     0xb1e480: ldr             x1, [x1, #0xda0]
    // 0xb1e484: ldr             x0, [fp, #0x18]
    // 0xb1e488: r16 = Instance_Size
    //     0xb1e488: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e590] Obj!Size@b5ee11
    //     0xb1e48c: ldr             x16, [x16, #0x590]
    // 0xb1e490: stp             x16, x1, [SP, #-0x10]!
    // 0xb1e494: r16 = Instance_EdgeInsets
    //     0xb1e494: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e598] Obj!EdgeInsets@b35c91
    //     0xb1e498: ldr             x16, [x16, #0x598]
    // 0xb1e49c: r30 = Instance_RoundedRectangleBorder
    //     0xb1e49c: add             lr, PP, #0x15, lsl #12  ; [pp+0x15300] Obj!RoundedRectangleBorder@b383d1
    //     0xb1e4a0: ldr             lr, [lr, #0x300]
    // 0xb1e4a4: stp             lr, x16, [SP, #-0x10]!
    // 0xb1e4a8: r16 = Instance_Alignment
    //     0xb1e4a8: add             x16, PP, #0x26, lsl #12  ; [pp+0x26fb8] Obj!Alignment@b37b51
    //     0xb1e4ac: ldr             x16, [x16, #0xfb8]
    // 0xb1e4b0: r30 = Instance_SystemMouseCursor
    //     0xb1e4b0: ldr             lr, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xb1e4b4: stp             lr, x16, [SP, #-0x10]!
    // 0xb1e4b8: r16 = Instance_SystemMouseCursor
    //     0xb1e4b8: ldr             x16, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xb1e4bc: SaveReg r16
    //     0xb1e4bc: str             x16, [SP, #-8]!
    // 0xb1e4c0: r4 = const [0, 0x7, 0x7, 0x4, alignment, 0x4, disabledMouseCursor, 0x6, enabledMouseCursor, 0x5, null]
    //     0xb1e4c0: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e5a0] List(11) [0, 0x7, 0x7, 0x4, "alignment", 0x4, "disabledMouseCursor", 0x6, "enabledMouseCursor", 0x5, Null]
    //     0xb1e4c4: ldr             x4, [x4, #0x5a0]
    // 0xb1e4c8: r0 = styleFrom()
    //     0xb1e4c8: bl              #0xb1e558  ; [package:flutter/src/material/text_button.dart] TextButton::styleFrom
    // 0xb1e4cc: add             SP, SP, #0x38
    // 0xb1e4d0: mov             x1, x0
    // 0xb1e4d4: ldr             x0, [fp, #0x18]
    // 0xb1e4d8: stur            x1, [fp, #-0x18]
    // 0xb1e4dc: LoadField: r2 = r0->field_b
    //     0xb1e4dc: ldur            w2, [x0, #0xb]
    // 0xb1e4e0: DecompressPointer r2
    //     0xb1e4e0: add             x2, x2, HEAP, lsl #32
    // 0xb1e4e4: stur            x2, [fp, #-0x10]
    // 0xb1e4e8: LoadField: r3 = r0->field_f
    //     0xb1e4e8: ldur            w3, [x0, #0xf]
    // 0xb1e4ec: DecompressPointer r3
    //     0xb1e4ec: add             x3, x3, HEAP, lsl #32
    // 0xb1e4f0: stur            x3, [fp, #-8]
    // 0xb1e4f4: r0 = TextButton()
    //     0xb1e4f4: bl              #0x916a68  ; AllocateTextButtonStub -> TextButton (size=0x34)
    // 0xb1e4f8: mov             x1, x0
    // 0xb1e4fc: ldur            x0, [fp, #-0x10]
    // 0xb1e500: stur            x1, [fp, #-0x20]
    // 0xb1e504: StoreField: r1->field_b = r0
    //     0xb1e504: stur            w0, [x1, #0xb]
    // 0xb1e508: ldur            x0, [fp, #-0x18]
    // 0xb1e50c: StoreField: r1->field_1b = r0
    //     0xb1e50c: stur            w0, [x1, #0x1b]
    // 0xb1e510: r0 = false
    //     0xb1e510: add             x0, NULL, #0x30  ; false
    // 0xb1e514: StoreField: r1->field_27 = r0
    //     0xb1e514: stur            w0, [x1, #0x27]
    // 0xb1e518: r0 = Instance_Clip
    //     0xb1e518: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb1e51c: ldr             x0, [x0, #0xb38]
    // 0xb1e520: StoreField: r1->field_1f = r0
    //     0xb1e520: stur            w0, [x1, #0x1f]
    // 0xb1e524: ldur            x0, [fp, #-8]
    // 0xb1e528: StoreField: r1->field_2f = r0
    //     0xb1e528: stur            w0, [x1, #0x2f]
    // 0xb1e52c: r0 = SizedBox()
    //     0xb1e52c: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb1e530: r1 = inf
    //     0xb1e530: add             x1, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0xb1e534: ldr             x1, [x1, #0x218]
    // 0xb1e538: StoreField: r0->field_f = r1
    //     0xb1e538: stur            w1, [x0, #0xf]
    // 0xb1e53c: ldur            x1, [fp, #-0x20]
    // 0xb1e540: StoreField: r0->field_b = r1
    //     0xb1e540: stur            w1, [x0, #0xb]
    // 0xb1e544: LeaveFrame
    //     0xb1e544: mov             SP, fp
    //     0xb1e548: ldp             fp, lr, [SP], #0x10
    // 0xb1e54c: ret
    //     0xb1e54c: ret             
    // 0xb1e550: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e550: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e554: b               #0xb1e444
  }
}

// lib: , url: package:flutter/src/material/material_state_mixin.dart

// class id: 1049271, size: 0x8
class :: {
}

// class id: 3337, size: 0x14, field offset: 0x14
abstract class MaterialStateMixin<X0 bound StatefulWidget> extends State<X0 bound StatefulWidget> {
}

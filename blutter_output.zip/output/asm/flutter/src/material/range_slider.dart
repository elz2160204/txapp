// lib: , url: package:flutter/src/material/range_slider.dart

// class id: 1049297, size: 0x8
class :: {
}

// class id: 2438, size: 0x60, field offset: 0x60
//   transformed mixin,
abstract class __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin extends RenderBox
     with RelayoutWhenSystemFontsChangeMixin {

  _ attach(/* No info */) {
    // ** addr: 0x9be01c, size: 0x110
    // 0x9be01c: EnterFrame
    //     0x9be01c: stp             fp, lr, [SP, #-0x10]!
    //     0x9be020: mov             fp, SP
    // 0x9be024: AllocStack(0x8)
    //     0x9be024: sub             SP, SP, #8
    // 0x9be028: CheckStackOverflow
    //     0x9be028: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9be02c: cmp             SP, x16
    //     0x9be030: b.ls            #0x9be120
    // 0x9be034: ldr             x16, [fp, #0x18]
    // 0x9be038: ldr             lr, [fp, #0x10]
    // 0x9be03c: stp             lr, x16, [SP, #-0x10]!
    // 0x9be040: r0 = attach()
    //     0x9be040: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9be044: add             SP, SP, #0x10
    // 0x9be048: r0 = LoadStaticField(0xe6c)
    //     0x9be048: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9be04c: ldr             x0, [x0, #0x1cd8]
    // 0x9be050: cmp             w0, NULL
    // 0x9be054: b.eq            #0x9be128
    // 0x9be058: LoadField: r1 = r0->field_ab
    //     0x9be058: ldur            w1, [x0, #0xab]
    // 0x9be05c: DecompressPointer r1
    //     0x9be05c: add             x1, x1, HEAP, lsl #32
    // 0x9be060: ldr             x0, [fp, #0x18]
    // 0x9be064: stur            x1, [fp, #-8]
    // 0x9be068: r2 = LoadClassIdInstr(r0)
    //     0x9be068: ldur            x2, [x0, #-1]
    //     0x9be06c: ubfx            x2, x2, #0xc, #0x14
    // 0x9be070: lsl             x2, x2, #1
    // 0x9be074: r17 = 4882
    //     0x9be074: mov             x17, #0x1312
    // 0x9be078: cmp             w2, w17
    // 0x9be07c: b.ne            #0x9be0a8
    // 0x9be080: r1 = 1
    //     0x9be080: mov             x1, #1
    // 0x9be084: r0 = AllocateContext()
    //     0x9be084: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9be088: mov             x1, x0
    // 0x9be08c: ldr             x0, [fp, #0x18]
    // 0x9be090: StoreField: r1->field_f = r0
    //     0x9be090: stur            w0, [x1, #0xf]
    // 0x9be094: mov             x2, x1
    // 0x9be098: r1 = Function 'systemFontsDidChange':.
    //     0x9be098: add             x1, PP, #0x50, lsl #12  ; [pp+0x508a0] AnonymousClosure: (0x9be224), in [package:flutter/src/rendering/editable.dart] RenderEditable::systemFontsDidChange (0x9be26c)
    //     0x9be09c: ldr             x1, [x1, #0x8a0]
    // 0x9be0a0: r0 = AllocateClosure()
    //     0x9be0a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9be0a4: b               #0x9be100
    // 0x9be0a8: r17 = 4884
    //     0x9be0a8: mov             x17, #0x1314
    // 0x9be0ac: cmp             w2, w17
    // 0x9be0b0: b.ne            #0x9be0dc
    // 0x9be0b4: r1 = 1
    //     0x9be0b4: mov             x1, #1
    // 0x9be0b8: r0 = AllocateContext()
    //     0x9be0b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9be0bc: mov             x1, x0
    // 0x9be0c0: ldr             x0, [fp, #0x18]
    // 0x9be0c4: StoreField: r1->field_f = r0
    //     0x9be0c4: stur            w0, [x1, #0xf]
    // 0x9be0c8: mov             x2, x1
    // 0x9be0cc: r1 = Function 'systemFontsDidChange':.
    //     0x9be0cc: add             x1, PP, #0x50, lsl #12  ; [pp+0x508a8] AnonymousClosure: (0x9be1d8), of [package:flutter/src/material/range_slider.dart] __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin
    //     0x9be0d0: ldr             x1, [x1, #0x8a8]
    // 0x9be0d4: r0 = AllocateClosure()
    //     0x9be0d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9be0d8: b               #0x9be100
    // 0x9be0dc: r1 = 1
    //     0x9be0dc: mov             x1, #1
    // 0x9be0e0: r0 = AllocateContext()
    //     0x9be0e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9be0e4: mov             x1, x0
    // 0x9be0e8: ldr             x0, [fp, #0x18]
    // 0x9be0ec: StoreField: r1->field_f = r0
    //     0x9be0ec: stur            w0, [x1, #0xf]
    // 0x9be0f0: mov             x2, x1
    // 0x9be0f4: r1 = Function 'systemFontsDidChange':.
    //     0x9be0f4: add             x1, PP, #0x50, lsl #12  ; [pp+0x508b0] AnonymousClosure: (0x9be12c), in [package:flutter/src/material/slider.dart] _RenderSlider::systemFontsDidChange (0x9be174)
    //     0x9be0f8: ldr             x1, [x1, #0x8b0]
    // 0x9be0fc: r0 = AllocateClosure()
    //     0x9be0fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9be100: ldur            x16, [fp, #-8]
    // 0x9be104: stp             x0, x16, [SP, #-0x10]!
    // 0x9be108: r0 = addListener()
    //     0x9be108: bl              #0x6e9740  ; [package:flutter/src/painting/binding.dart] _SystemFontsNotifier::addListener
    // 0x9be10c: add             SP, SP, #0x10
    // 0x9be110: r0 = Null
    //     0x9be110: mov             x0, NULL
    // 0x9be114: LeaveFrame
    //     0x9be114: mov             SP, fp
    //     0x9be118: ldp             fp, lr, [SP], #0x10
    // 0x9be11c: ret
    //     0x9be11c: ret             
    // 0x9be120: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9be120: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9be124: b               #0x9be034
    // 0x9be128: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9be128: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void systemFontsDidChange(dynamic) {
    // ** addr: 0x9be1d8, size: 0x4c
    // 0x9be1d8: EnterFrame
    //     0x9be1d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9be1dc: mov             fp, SP
    // 0x9be1e0: ldr             x0, [fp, #0x10]
    // 0x9be1e4: LoadField: r1 = r0->field_17
    //     0x9be1e4: ldur            w1, [x0, #0x17]
    // 0x9be1e8: DecompressPointer r1
    //     0x9be1e8: add             x1, x1, HEAP, lsl #32
    // 0x9be1ec: CheckStackOverflow
    //     0x9be1ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9be1f0: cmp             SP, x16
    //     0x9be1f4: b.ls            #0x9be21c
    // 0x9be1f8: LoadField: r0 = r1->field_f
    //     0x9be1f8: ldur            w0, [x1, #0xf]
    // 0x9be1fc: DecompressPointer r0
    //     0x9be1fc: add             x0, x0, HEAP, lsl #32
    // 0x9be200: SaveReg r0
    //     0x9be200: str             x0, [SP, #-8]!
    // 0x9be204: r0 = markNeedsLayout()
    //     0x9be204: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x9be208: add             SP, SP, #8
    // 0x9be20c: r0 = Null
    //     0x9be20c: mov             x0, NULL
    // 0x9be210: LeaveFrame
    //     0x9be210: mov             SP, fp
    //     0x9be214: ldp             fp, lr, [SP], #0x10
    // 0x9be218: ret
    //     0x9be218: ret             
    // 0x9be21c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9be21c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9be220: b               #0x9be1f8
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69bec, size: 0x114
    // 0xa69bec: EnterFrame
    //     0xa69bec: stp             fp, lr, [SP, #-0x10]!
    //     0xa69bf0: mov             fp, SP
    // 0xa69bf4: AllocStack(0x8)
    //     0xa69bf4: sub             SP, SP, #8
    // 0xa69bf8: CheckStackOverflow
    //     0xa69bf8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69bfc: cmp             SP, x16
    //     0xa69c00: b.ls            #0xa69cf4
    // 0xa69c04: r0 = LoadStaticField(0xe6c)
    //     0xa69c04: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa69c08: ldr             x0, [x0, #0x1cd8]
    // 0xa69c0c: cmp             w0, NULL
    // 0xa69c10: b.eq            #0xa69cfc
    // 0xa69c14: LoadField: r1 = r0->field_ab
    //     0xa69c14: ldur            w1, [x0, #0xab]
    // 0xa69c18: DecompressPointer r1
    //     0xa69c18: add             x1, x1, HEAP, lsl #32
    // 0xa69c1c: ldr             x0, [fp, #0x10]
    // 0xa69c20: stur            x1, [fp, #-8]
    // 0xa69c24: r2 = LoadClassIdInstr(r0)
    //     0xa69c24: ldur            x2, [x0, #-1]
    //     0xa69c28: ubfx            x2, x2, #0xc, #0x14
    // 0xa69c2c: lsl             x2, x2, #1
    // 0xa69c30: r17 = 4882
    //     0xa69c30: mov             x17, #0x1312
    // 0xa69c34: cmp             w2, w17
    // 0xa69c38: b.ne            #0xa69c64
    // 0xa69c3c: r1 = 1
    //     0xa69c3c: mov             x1, #1
    // 0xa69c40: r0 = AllocateContext()
    //     0xa69c40: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69c44: mov             x1, x0
    // 0xa69c48: ldr             x0, [fp, #0x10]
    // 0xa69c4c: StoreField: r1->field_f = r0
    //     0xa69c4c: stur            w0, [x1, #0xf]
    // 0xa69c50: mov             x2, x1
    // 0xa69c54: r1 = Function 'systemFontsDidChange':.
    //     0xa69c54: add             x1, PP, #0x50, lsl #12  ; [pp+0x508a0] AnonymousClosure: (0x9be224), in [package:flutter/src/rendering/editable.dart] RenderEditable::systemFontsDidChange (0x9be26c)
    //     0xa69c58: ldr             x1, [x1, #0x8a0]
    // 0xa69c5c: r0 = AllocateClosure()
    //     0xa69c5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69c60: b               #0xa69cc4
    // 0xa69c64: r17 = 4884
    //     0xa69c64: mov             x17, #0x1314
    // 0xa69c68: cmp             w2, w17
    // 0xa69c6c: b.ne            #0xa69c9c
    // 0xa69c70: ldr             x0, [fp, #0x10]
    // 0xa69c74: r1 = 1
    //     0xa69c74: mov             x1, #1
    // 0xa69c78: r0 = AllocateContext()
    //     0xa69c78: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69c7c: mov             x1, x0
    // 0xa69c80: ldr             x0, [fp, #0x10]
    // 0xa69c84: StoreField: r1->field_f = r0
    //     0xa69c84: stur            w0, [x1, #0xf]
    // 0xa69c88: mov             x2, x1
    // 0xa69c8c: r1 = Function 'systemFontsDidChange':.
    //     0xa69c8c: add             x1, PP, #0x50, lsl #12  ; [pp+0x508a8] AnonymousClosure: (0x9be1d8), of [package:flutter/src/material/range_slider.dart] __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin
    //     0xa69c90: ldr             x1, [x1, #0x8a8]
    // 0xa69c94: r0 = AllocateClosure()
    //     0xa69c94: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69c98: b               #0xa69cc4
    // 0xa69c9c: ldr             x0, [fp, #0x10]
    // 0xa69ca0: r1 = 1
    //     0xa69ca0: mov             x1, #1
    // 0xa69ca4: r0 = AllocateContext()
    //     0xa69ca4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69ca8: mov             x1, x0
    // 0xa69cac: ldr             x0, [fp, #0x10]
    // 0xa69cb0: StoreField: r1->field_f = r0
    //     0xa69cb0: stur            w0, [x1, #0xf]
    // 0xa69cb4: mov             x2, x1
    // 0xa69cb8: r1 = Function 'systemFontsDidChange':.
    //     0xa69cb8: add             x1, PP, #0x50, lsl #12  ; [pp+0x508b0] AnonymousClosure: (0x9be12c), in [package:flutter/src/material/slider.dart] _RenderSlider::systemFontsDidChange (0x9be174)
    //     0xa69cbc: ldr             x1, [x1, #0x8b0]
    // 0xa69cc0: r0 = AllocateClosure()
    //     0xa69cc0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69cc4: ldur            x16, [fp, #-8]
    // 0xa69cc8: stp             x0, x16, [SP, #-0x10]!
    // 0xa69ccc: r0 = removeListener()
    //     0xa69ccc: bl              #0x6f63c0  ; [package:flutter/src/painting/binding.dart] _SystemFontsNotifier::removeListener
    // 0xa69cd0: add             SP, SP, #0x10
    // 0xa69cd4: ldr             x16, [fp, #0x10]
    // 0xa69cd8: SaveReg r16
    //     0xa69cd8: str             x16, [SP, #-8]!
    // 0xa69cdc: r0 = detach()
    //     0xa69cdc: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa69ce0: add             SP, SP, #8
    // 0xa69ce4: r0 = Null
    //     0xa69ce4: mov             x0, NULL
    // 0xa69ce8: LeaveFrame
    //     0xa69ce8: mov             SP, fp
    //     0xa69cec: ldp             fp, lr, [SP], #0x10
    // 0xa69cf0: ret
    //     0xa69cf0: ret             
    // 0xa69cf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69cf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69cf8: b               #0xa69c04
    // 0xa69cfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa69cfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

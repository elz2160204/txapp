// lib: , url: package:flutter/src/material/navigation_drawer_theme.dart

// class id: 1049281, size: 0x8
class :: {
}

// class id: 2781, size: 0x30, field offset: 0x8
//   const constructor, 
class NavigationDrawerThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00b08, size: 0x84
    // 0xb00b08: EnterFrame
    //     0xb00b08: stp             fp, lr, [SP, #-0x10]!
    //     0xb00b0c: mov             fp, SP
    // 0xb00b10: CheckStackOverflow
    //     0xb00b10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00b14: cmp             SP, x16
    //     0xb00b18: b.ls            #0xb00b84
    // 0xb00b1c: ldr             x0, [fp, #0x10]
    // 0xb00b20: LoadField: r1 = r0->field_7
    //     0xb00b20: ldur            w1, [x0, #7]
    // 0xb00b24: DecompressPointer r1
    //     0xb00b24: add             x1, x1, HEAP, lsl #32
    // 0xb00b28: LoadField: r2 = r0->field_f
    //     0xb00b28: ldur            w2, [x0, #0xf]
    // 0xb00b2c: DecompressPointer r2
    //     0xb00b2c: add             x2, x2, HEAP, lsl #32
    // 0xb00b30: LoadField: r3 = r0->field_27
    //     0xb00b30: ldur            w3, [x0, #0x27]
    // 0xb00b34: DecompressPointer r3
    //     0xb00b34: add             x3, x3, HEAP, lsl #32
    // 0xb00b38: LoadField: r4 = r0->field_2b
    //     0xb00b38: ldur            w4, [x0, #0x2b]
    // 0xb00b3c: DecompressPointer r4
    //     0xb00b3c: add             x4, x4, HEAP, lsl #32
    // 0xb00b40: stp             NULL, x1, [SP, #-0x10]!
    // 0xb00b44: stp             NULL, x2, [SP, #-0x10]!
    // 0xb00b48: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00b4c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00b50: stp             x4, x3, [SP, #-0x10]!
    // 0xb00b54: r4 = const [0, 0xa, 0xa, 0xa, null]
    //     0xb00b54: ldr             x4, [PP, #0x2558]  ; [pp+0x2558] List(5) [0, 0xa, 0xa, 0xa, Null]
    // 0xb00b58: r0 = hash()
    //     0xb00b58: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00b5c: add             SP, SP, #0x50
    // 0xb00b60: mov             x2, x0
    // 0xb00b64: r0 = BoxInt64Instr(r2)
    //     0xb00b64: sbfiz           x0, x2, #1, #0x1f
    //     0xb00b68: cmp             x2, x0, asr #1
    //     0xb00b6c: b.eq            #0xb00b78
    //     0xb00b70: bl              #0xd69bb8
    //     0xb00b74: stur            x2, [x0, #7]
    // 0xb00b78: LeaveFrame
    //     0xb00b78: mov             SP, fp
    //     0xb00b7c: ldp             fp, lr, [SP], #0x10
    // 0xb00b80: ret
    //     0xb00b80: ret             
    // 0xb00b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00b88: b               #0xb00b1c
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf37ec, size: 0x200
    // 0xbf37ec: EnterFrame
    //     0xbf37ec: stp             fp, lr, [SP, #-0x10]!
    //     0xbf37f0: mov             fp, SP
    // 0xbf37f4: AllocStack(0x20)
    //     0xbf37f4: sub             SP, SP, #0x20
    // 0xbf37f8: CheckStackOverflow
    //     0xbf37f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf37fc: cmp             SP, x16
    //     0xbf3800: b.ls            #0xbf39c0
    // 0xbf3804: ldr             x0, [fp, #0x20]
    // 0xbf3808: LoadField: r1 = r0->field_7
    //     0xbf3808: ldur            w1, [x0, #7]
    // 0xbf380c: DecompressPointer r1
    //     0xbf380c: add             x1, x1, HEAP, lsl #32
    // 0xbf3810: ldr             x2, [fp, #0x18]
    // 0xbf3814: LoadField: r3 = r2->field_7
    //     0xbf3814: ldur            w3, [x2, #7]
    // 0xbf3818: DecompressPointer r3
    //     0xbf3818: add             x3, x3, HEAP, lsl #32
    // 0xbf381c: ldr             d0, [fp, #0x10]
    // 0xbf3820: r4 = inline_Allocate_Double()
    //     0xbf3820: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf3824: add             x4, x4, #0x10
    //     0xbf3828: cmp             x5, x4
    //     0xbf382c: b.ls            #0xbf39c8
    //     0xbf3830: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf3834: sub             x4, x4, #0xf
    //     0xbf3838: mov             x5, #0xd108
    //     0xbf383c: movk            x5, #3, lsl #16
    //     0xbf3840: stur            x5, [x4, #-1]
    // 0xbf3844: StoreField: r4->field_7 = d0
    //     0xbf3844: stur            d0, [x4, #7]
    // 0xbf3848: stur            x4, [fp, #-8]
    // 0xbf384c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3850: SaveReg r4
    //     0xbf3850: str             x4, [SP, #-8]!
    // 0xbf3854: r0 = lerpDouble()
    //     0xbf3854: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3858: add             SP, SP, #0x18
    // 0xbf385c: stur            x0, [fp, #-0x10]
    // 0xbf3860: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf3864: ldur            x16, [fp, #-8]
    // 0xbf3868: SaveReg r16
    //     0xbf3868: str             x16, [SP, #-8]!
    // 0xbf386c: r0 = lerp()
    //     0xbf386c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf3870: add             SP, SP, #0x18
    // 0xbf3874: ldr             x0, [fp, #0x20]
    // 0xbf3878: LoadField: r1 = r0->field_f
    //     0xbf3878: ldur            w1, [x0, #0xf]
    // 0xbf387c: DecompressPointer r1
    //     0xbf387c: add             x1, x1, HEAP, lsl #32
    // 0xbf3880: ldr             x2, [fp, #0x18]
    // 0xbf3884: LoadField: r3 = r2->field_f
    //     0xbf3884: ldur            w3, [x2, #0xf]
    // 0xbf3888: DecompressPointer r3
    //     0xbf3888: add             x3, x3, HEAP, lsl #32
    // 0xbf388c: stp             x3, x1, [SP, #-0x10]!
    // 0xbf3890: ldur            x16, [fp, #-8]
    // 0xbf3894: SaveReg r16
    //     0xbf3894: str             x16, [SP, #-8]!
    // 0xbf3898: r0 = lerpDouble()
    //     0xbf3898: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf389c: add             SP, SP, #0x18
    // 0xbf38a0: stur            x0, [fp, #-0x18]
    // 0xbf38a4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf38a8: ldur            x16, [fp, #-8]
    // 0xbf38ac: SaveReg r16
    //     0xbf38ac: str             x16, [SP, #-8]!
    // 0xbf38b0: r0 = lerp()
    //     0xbf38b0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf38b4: add             SP, SP, #0x18
    // 0xbf38b8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf38bc: ldur            x16, [fp, #-8]
    // 0xbf38c0: SaveReg r16
    //     0xbf38c0: str             x16, [SP, #-8]!
    // 0xbf38c4: r0 = lerp()
    //     0xbf38c4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf38c8: add             SP, SP, #0x18
    // 0xbf38cc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf38d0: ldur            x16, [fp, #-8]
    // 0xbf38d4: SaveReg r16
    //     0xbf38d4: str             x16, [SP, #-8]!
    // 0xbf38d8: r0 = lerp()
    //     0xbf38d8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf38dc: add             SP, SP, #0x18
    // 0xbf38e0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf38e4: ldur            x16, [fp, #-8]
    // 0xbf38e8: SaveReg r16
    //     0xbf38e8: str             x16, [SP, #-8]!
    // 0xbf38ec: r0 = lerp()
    //     0xbf38ec: bl              #0xbec39c  ; [dart:ui] Size::lerp
    // 0xbf38f0: add             SP, SP, #0x18
    // 0xbf38f4: ldr             x0, [fp, #0x20]
    // 0xbf38f8: LoadField: r1 = r0->field_27
    //     0xbf38f8: ldur            w1, [x0, #0x27]
    // 0xbf38fc: DecompressPointer r1
    //     0xbf38fc: add             x1, x1, HEAP, lsl #32
    // 0xbf3900: ldr             x2, [fp, #0x18]
    // 0xbf3904: LoadField: r3 = r2->field_27
    //     0xbf3904: ldur            w3, [x2, #0x27]
    // 0xbf3908: DecompressPointer r3
    //     0xbf3908: add             x3, x3, HEAP, lsl #32
    // 0xbf390c: r16 = <TextStyle?>
    //     0xbf390c: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0xbf3910: ldr             x16, [x16, #0x8c0]
    // 0xbf3914: stp             x1, x16, [SP, #-0x10]!
    // 0xbf3918: SaveReg r3
    //     0xbf3918: str             x3, [SP, #-8]!
    // 0xbf391c: ldr             d0, [fp, #0x10]
    // 0xbf3920: SaveReg d0
    //     0xbf3920: str             d0, [SP, #-8]!
    // 0xbf3924: r16 = Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static.
    //     0xbf3924: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db78] Closure: (TextStyle?, TextStyle?, double) => TextStyle? from Function 'lerp': static. (0x7fe6e22ec598)
    //     0xbf3928: ldr             x16, [x16, #0xb78]
    // 0xbf392c: SaveReg r16
    //     0xbf392c: str             x16, [SP, #-8]!
    // 0xbf3930: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3930: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3934: r0 = lerp()
    //     0xbf3934: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3938: add             SP, SP, #0x28
    // 0xbf393c: mov             x1, x0
    // 0xbf3940: ldr             x0, [fp, #0x20]
    // 0xbf3944: stur            x1, [fp, #-8]
    // 0xbf3948: LoadField: r2 = r0->field_2b
    //     0xbf3948: ldur            w2, [x0, #0x2b]
    // 0xbf394c: DecompressPointer r2
    //     0xbf394c: add             x2, x2, HEAP, lsl #32
    // 0xbf3950: ldr             x0, [fp, #0x18]
    // 0xbf3954: LoadField: r3 = r0->field_2b
    //     0xbf3954: ldur            w3, [x0, #0x2b]
    // 0xbf3958: DecompressPointer r3
    //     0xbf3958: add             x3, x3, HEAP, lsl #32
    // 0xbf395c: r16 = <IconThemeData?>
    //     0xbf395c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbc8] TypeArguments: <IconThemeData?>
    //     0xbf3960: ldr             x16, [x16, #0xbc8]
    // 0xbf3964: stp             x2, x16, [SP, #-0x10]!
    // 0xbf3968: SaveReg r3
    //     0xbf3968: str             x3, [SP, #-8]!
    // 0xbf396c: ldr             d0, [fp, #0x10]
    // 0xbf3970: SaveReg d0
    //     0xbf3970: str             d0, [SP, #-8]!
    // 0xbf3974: r16 = Closure: (IconThemeData?, IconThemeData?, double) => IconThemeData from Function 'lerp': static.
    //     0xbf3974: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbd0] Closure: (IconThemeData?, IconThemeData?, double) => IconThemeData from Function 'lerp': static. (0x7fe6e23f39f8)
    //     0xbf3978: ldr             x16, [x16, #0xbd0]
    // 0xbf397c: SaveReg r16
    //     0xbf397c: str             x16, [SP, #-8]!
    // 0xbf3980: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf3980: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf3984: r0 = lerp()
    //     0xbf3984: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf3988: add             SP, SP, #0x28
    // 0xbf398c: stur            x0, [fp, #-0x20]
    // 0xbf3990: r0 = NavigationDrawerThemeData()
    //     0xbf3990: bl              #0xbf39ec  ; AllocateNavigationDrawerThemeDataStub -> NavigationDrawerThemeData (size=0x30)
    // 0xbf3994: ldur            x1, [fp, #-0x10]
    // 0xbf3998: StoreField: r0->field_7 = r1
    //     0xbf3998: stur            w1, [x0, #7]
    // 0xbf399c: ldur            x1, [fp, #-0x18]
    // 0xbf39a0: StoreField: r0->field_f = r1
    //     0xbf39a0: stur            w1, [x0, #0xf]
    // 0xbf39a4: ldur            x1, [fp, #-8]
    // 0xbf39a8: StoreField: r0->field_27 = r1
    //     0xbf39a8: stur            w1, [x0, #0x27]
    // 0xbf39ac: ldur            x1, [fp, #-0x20]
    // 0xbf39b0: StoreField: r0->field_2b = r1
    //     0xbf39b0: stur            w1, [x0, #0x2b]
    // 0xbf39b4: LeaveFrame
    //     0xbf39b4: mov             SP, fp
    //     0xbf39b8: ldp             fp, lr, [SP], #0x10
    // 0xbf39bc: ret
    //     0xbf39bc: ret             
    // 0xbf39c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf39c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf39c4: b               #0xbf3804
    // 0xbf39c8: SaveReg d0
    //     0xbf39c8: str             q0, [SP, #-0x10]!
    // 0xbf39cc: stp             x2, x3, [SP, #-0x10]!
    // 0xbf39d0: stp             x0, x1, [SP, #-0x10]!
    // 0xbf39d4: r0 = AllocateDouble()
    //     0xbf39d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf39d8: mov             x4, x0
    // 0xbf39dc: ldp             x0, x1, [SP], #0x10
    // 0xbf39e0: ldp             x2, x3, [SP], #0x10
    // 0xbf39e4: RestoreReg d0
    //     0xbf39e4: ldr             q0, [SP], #0x10
    // 0xbf39e8: b               #0xbf3844
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8c0ec, size: 0x1a8
    // 0xc8c0ec: EnterFrame
    //     0xc8c0ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc8c0f0: mov             fp, SP
    // 0xc8c0f4: CheckStackOverflow
    //     0xc8c0f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8c0f8: cmp             SP, x16
    //     0xc8c0fc: b.ls            #0xc8c28c
    // 0xc8c100: ldr             x1, [fp, #0x10]
    // 0xc8c104: cmp             w1, NULL
    // 0xc8c108: b.ne            #0xc8c11c
    // 0xc8c10c: r0 = false
    //     0xc8c10c: add             x0, NULL, #0x30  ; false
    // 0xc8c110: LeaveFrame
    //     0xc8c110: mov             SP, fp
    //     0xc8c114: ldp             fp, lr, [SP], #0x10
    // 0xc8c118: ret
    //     0xc8c118: ret             
    // 0xc8c11c: ldr             x2, [fp, #0x18]
    // 0xc8c120: cmp             w2, w1
    // 0xc8c124: b.ne            #0xc8c138
    // 0xc8c128: r0 = true
    //     0xc8c128: add             x0, NULL, #0x20  ; true
    // 0xc8c12c: LeaveFrame
    //     0xc8c12c: mov             SP, fp
    //     0xc8c130: ldp             fp, lr, [SP], #0x10
    // 0xc8c134: ret
    //     0xc8c134: ret             
    // 0xc8c138: r0 = 59
    //     0xc8c138: mov             x0, #0x3b
    // 0xc8c13c: branchIfSmi(r1, 0xc8c148)
    //     0xc8c13c: tbz             w1, #0, #0xc8c148
    // 0xc8c140: r0 = LoadClassIdInstr(r1)
    //     0xc8c140: ldur            x0, [x1, #-1]
    //     0xc8c144: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c148: SaveReg r1
    //     0xc8c148: str             x1, [SP, #-8]!
    // 0xc8c14c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8c14c: mov             x17, #0x57c5
    //     0xc8c150: add             lr, x0, x17
    //     0xc8c154: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c158: blr             lr
    // 0xc8c15c: add             SP, SP, #8
    // 0xc8c160: r1 = LoadClassIdInstr(r0)
    //     0xc8c160: ldur            x1, [x0, #-1]
    //     0xc8c164: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c168: r16 = NavigationDrawerThemeData
    //     0xc8c168: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1d8] Type: NavigationDrawerThemeData
    //     0xc8c16c: ldr             x16, [x16, #0x1d8]
    // 0xc8c170: stp             x16, x0, [SP, #-0x10]!
    // 0xc8c174: mov             x0, x1
    // 0xc8c178: mov             lr, x0
    // 0xc8c17c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c180: blr             lr
    // 0xc8c184: add             SP, SP, #0x10
    // 0xc8c188: tbz             w0, #4, #0xc8c19c
    // 0xc8c18c: r0 = false
    //     0xc8c18c: add             x0, NULL, #0x30  ; false
    // 0xc8c190: LeaveFrame
    //     0xc8c190: mov             SP, fp
    //     0xc8c194: ldp             fp, lr, [SP], #0x10
    // 0xc8c198: ret
    //     0xc8c198: ret             
    // 0xc8c19c: ldr             x1, [fp, #0x10]
    // 0xc8c1a0: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8c1a0: mov             x0, #0x76
    //     0xc8c1a4: tbz             w1, #0, #0xc8c1b4
    //     0xc8c1a8: ldur            x0, [x1, #-1]
    //     0xc8c1ac: ubfx            x0, x0, #0xc, #0x14
    //     0xc8c1b0: lsl             x0, x0, #1
    // 0xc8c1b4: r17 = 5562
    //     0xc8c1b4: mov             x17, #0x15ba
    // 0xc8c1b8: cmp             w0, w17
    // 0xc8c1bc: b.ne            #0xc8c27c
    // 0xc8c1c0: ldr             x2, [fp, #0x18]
    // 0xc8c1c4: LoadField: r0 = r1->field_7
    //     0xc8c1c4: ldur            w0, [x1, #7]
    // 0xc8c1c8: DecompressPointer r0
    //     0xc8c1c8: add             x0, x0, HEAP, lsl #32
    // 0xc8c1cc: LoadField: r3 = r2->field_7
    //     0xc8c1cc: ldur            w3, [x2, #7]
    // 0xc8c1d0: DecompressPointer r3
    //     0xc8c1d0: add             x3, x3, HEAP, lsl #32
    // 0xc8c1d4: r4 = LoadClassIdInstr(r0)
    //     0xc8c1d4: ldur            x4, [x0, #-1]
    //     0xc8c1d8: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c1dc: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c1e0: mov             x0, x4
    // 0xc8c1e4: mov             lr, x0
    // 0xc8c1e8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c1ec: blr             lr
    // 0xc8c1f0: add             SP, SP, #0x10
    // 0xc8c1f4: tbnz            w0, #4, #0xc8c27c
    // 0xc8c1f8: ldr             x2, [fp, #0x18]
    // 0xc8c1fc: ldr             x1, [fp, #0x10]
    // 0xc8c200: LoadField: r0 = r1->field_f
    //     0xc8c200: ldur            w0, [x1, #0xf]
    // 0xc8c204: DecompressPointer r0
    //     0xc8c204: add             x0, x0, HEAP, lsl #32
    // 0xc8c208: LoadField: r3 = r2->field_f
    //     0xc8c208: ldur            w3, [x2, #0xf]
    // 0xc8c20c: DecompressPointer r3
    //     0xc8c20c: add             x3, x3, HEAP, lsl #32
    // 0xc8c210: r4 = LoadClassIdInstr(r0)
    //     0xc8c210: ldur            x4, [x0, #-1]
    //     0xc8c214: ubfx            x4, x4, #0xc, #0x14
    // 0xc8c218: stp             x3, x0, [SP, #-0x10]!
    // 0xc8c21c: mov             x0, x4
    // 0xc8c220: mov             lr, x0
    // 0xc8c224: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c228: blr             lr
    // 0xc8c22c: add             SP, SP, #0x10
    // 0xc8c230: tbnz            w0, #4, #0xc8c27c
    // 0xc8c234: ldr             x2, [fp, #0x18]
    // 0xc8c238: ldr             x1, [fp, #0x10]
    // 0xc8c23c: LoadField: r3 = r1->field_27
    //     0xc8c23c: ldur            w3, [x1, #0x27]
    // 0xc8c240: DecompressPointer r3
    //     0xc8c240: add             x3, x3, HEAP, lsl #32
    // 0xc8c244: LoadField: r4 = r2->field_27
    //     0xc8c244: ldur            w4, [x2, #0x27]
    // 0xc8c248: DecompressPointer r4
    //     0xc8c248: add             x4, x4, HEAP, lsl #32
    // 0xc8c24c: cmp             w3, w4
    // 0xc8c250: b.ne            #0xc8c27c
    // 0xc8c254: LoadField: r3 = r1->field_2b
    //     0xc8c254: ldur            w3, [x1, #0x2b]
    // 0xc8c258: DecompressPointer r3
    //     0xc8c258: add             x3, x3, HEAP, lsl #32
    // 0xc8c25c: LoadField: r1 = r2->field_2b
    //     0xc8c25c: ldur            w1, [x2, #0x2b]
    // 0xc8c260: DecompressPointer r1
    //     0xc8c260: add             x1, x1, HEAP, lsl #32
    // 0xc8c264: cmp             w3, w1
    // 0xc8c268: r16 = true
    //     0xc8c268: add             x16, NULL, #0x20  ; true
    // 0xc8c26c: r17 = false
    //     0xc8c26c: add             x17, NULL, #0x30  ; false
    // 0xc8c270: csel            x2, x16, x17, eq
    // 0xc8c274: mov             x0, x2
    // 0xc8c278: b               #0xc8c280
    // 0xc8c27c: r0 = false
    //     0xc8c27c: add             x0, NULL, #0x30  ; false
    // 0xc8c280: LeaveFrame
    //     0xc8c280: mov             SP, fp
    //     0xc8c284: ldp             fp, lr, [SP], #0x10
    // 0xc8c288: ret
    //     0xc8c288: ret             
    // 0xc8c28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8c28c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8c290: b               #0xc8c100
  }
}

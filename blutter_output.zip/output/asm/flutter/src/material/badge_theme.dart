// lib: , url: package:flutter/src/material/badge_theme.dart

// class id: 1049185, size: 0x8
class :: {
}

// class id: 2840, size: 0x24, field offset: 0x8
//   const constructor, 
class BadgeThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafdc64, size: 0x70
    // 0xafdc64: EnterFrame
    //     0xafdc64: stp             fp, lr, [SP, #-0x10]!
    //     0xafdc68: mov             fp, SP
    // 0xafdc6c: CheckStackOverflow
    //     0xafdc6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafdc70: cmp             SP, x16
    //     0xafdc74: b.ls            #0xafdccc
    // 0xafdc78: ldr             x0, [fp, #0x10]
    // 0xafdc7c: LoadField: r1 = r0->field_f
    //     0xafdc7c: ldur            w1, [x0, #0xf]
    // 0xafdc80: DecompressPointer r1
    //     0xafdc80: add             x1, x1, HEAP, lsl #32
    // 0xafdc84: LoadField: r2 = r0->field_13
    //     0xafdc84: ldur            w2, [x0, #0x13]
    // 0xafdc88: DecompressPointer r2
    //     0xafdc88: add             x2, x2, HEAP, lsl #32
    // 0xafdc8c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdc90: stp             x2, x1, [SP, #-0x10]!
    // 0xafdc94: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdc98: SaveReg rNULL
    //     0xafdc98: str             NULL, [SP, #-8]!
    // 0xafdc9c: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xafdc9c: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xafdca0: r0 = hash()
    //     0xafdca0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafdca4: add             SP, SP, #0x38
    // 0xafdca8: mov             x2, x0
    // 0xafdcac: r0 = BoxInt64Instr(r2)
    //     0xafdcac: sbfiz           x0, x2, #1, #0x1f
    //     0xafdcb0: cmp             x2, x0, asr #1
    //     0xafdcb4: b.eq            #0xafdcc0
    //     0xafdcb8: bl              #0xd69bb8
    //     0xafdcbc: stur            x2, [x0, #7]
    // 0xafdcc0: LeaveFrame
    //     0xafdcc0: mov             SP, fp
    //     0xafdcc4: ldp             fp, lr, [SP], #0x10
    // 0xafdcc8: ret
    //     0xafdcc8: ret             
    // 0xafdccc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafdccc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafdcd0: b               #0xafdc78
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5fac, size: 0x130
    // 0xbf5fac: EnterFrame
    //     0xbf5fac: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5fb0: mov             fp, SP
    // 0xbf5fb4: AllocStack(0x18)
    //     0xbf5fb4: sub             SP, SP, #0x18
    // 0xbf5fb8: CheckStackOverflow
    //     0xbf5fb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5fbc: cmp             SP, x16
    //     0xbf5fc0: b.ls            #0xbf60c4
    // 0xbf5fc4: ldr             d0, [fp, #0x10]
    // 0xbf5fc8: r0 = inline_Allocate_Double()
    //     0xbf5fc8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf5fcc: add             x0, x0, #0x10
    //     0xbf5fd0: cmp             x1, x0
    //     0xbf5fd4: b.ls            #0xbf60cc
    //     0xbf5fd8: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf5fdc: sub             x0, x0, #0xf
    //     0xbf5fe0: mov             x1, #0xd108
    //     0xbf5fe4: movk            x1, #3, lsl #16
    //     0xbf5fe8: stur            x1, [x0, #-1]
    // 0xbf5fec: StoreField: r0->field_7 = d0
    //     0xbf5fec: stur            d0, [x0, #7]
    // 0xbf5ff0: stur            x0, [fp, #-8]
    // 0xbf5ff4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5ff8: SaveReg r0
    //     0xbf5ff8: str             x0, [SP, #-8]!
    // 0xbf5ffc: r0 = lerp()
    //     0xbf5ffc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf6000: add             SP, SP, #0x18
    // 0xbf6004: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf6008: ldur            x16, [fp, #-8]
    // 0xbf600c: SaveReg r16
    //     0xbf600c: str             x16, [SP, #-8]!
    // 0xbf6010: r0 = lerp()
    //     0xbf6010: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf6014: add             SP, SP, #0x18
    // 0xbf6018: ldr             x0, [fp, #0x20]
    // 0xbf601c: LoadField: r1 = r0->field_f
    //     0xbf601c: ldur            w1, [x0, #0xf]
    // 0xbf6020: DecompressPointer r1
    //     0xbf6020: add             x1, x1, HEAP, lsl #32
    // 0xbf6024: ldr             x2, [fp, #0x18]
    // 0xbf6028: LoadField: r3 = r2->field_f
    //     0xbf6028: ldur            w3, [x2, #0xf]
    // 0xbf602c: DecompressPointer r3
    //     0xbf602c: add             x3, x3, HEAP, lsl #32
    // 0xbf6030: stp             x3, x1, [SP, #-0x10]!
    // 0xbf6034: ldur            x16, [fp, #-8]
    // 0xbf6038: SaveReg r16
    //     0xbf6038: str             x16, [SP, #-8]!
    // 0xbf603c: r0 = lerpDouble()
    //     0xbf603c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf6040: add             SP, SP, #0x18
    // 0xbf6044: mov             x1, x0
    // 0xbf6048: ldr             x0, [fp, #0x20]
    // 0xbf604c: stur            x1, [fp, #-0x10]
    // 0xbf6050: LoadField: r2 = r0->field_13
    //     0xbf6050: ldur            w2, [x0, #0x13]
    // 0xbf6054: DecompressPointer r2
    //     0xbf6054: add             x2, x2, HEAP, lsl #32
    // 0xbf6058: ldr             x0, [fp, #0x18]
    // 0xbf605c: LoadField: r3 = r0->field_13
    //     0xbf605c: ldur            w3, [x0, #0x13]
    // 0xbf6060: DecompressPointer r3
    //     0xbf6060: add             x3, x3, HEAP, lsl #32
    // 0xbf6064: stp             x3, x2, [SP, #-0x10]!
    // 0xbf6068: ldur            x16, [fp, #-8]
    // 0xbf606c: SaveReg r16
    //     0xbf606c: str             x16, [SP, #-8]!
    // 0xbf6070: r0 = lerpDouble()
    //     0xbf6070: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf6074: add             SP, SP, #0x18
    // 0xbf6078: stur            x0, [fp, #-0x18]
    // 0xbf607c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf6080: ldur            x16, [fp, #-8]
    // 0xbf6084: SaveReg r16
    //     0xbf6084: str             x16, [SP, #-8]!
    // 0xbf6088: r0 = lerp()
    //     0xbf6088: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf608c: add             SP, SP, #0x18
    // 0xbf6090: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf6094: ldur            x16, [fp, #-8]
    // 0xbf6098: SaveReg r16
    //     0xbf6098: str             x16, [SP, #-8]!
    // 0xbf609c: r0 = lerp()
    //     0xbf609c: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf60a0: add             SP, SP, #0x18
    // 0xbf60a4: r0 = BadgeThemeData()
    //     0xbf60a4: bl              #0xbf60dc  ; AllocateBadgeThemeDataStub -> BadgeThemeData (size=0x24)
    // 0xbf60a8: ldur            x1, [fp, #-0x10]
    // 0xbf60ac: StoreField: r0->field_f = r1
    //     0xbf60ac: stur            w1, [x0, #0xf]
    // 0xbf60b0: ldur            x1, [fp, #-0x18]
    // 0xbf60b4: StoreField: r0->field_13 = r1
    //     0xbf60b4: stur            w1, [x0, #0x13]
    // 0xbf60b8: LeaveFrame
    //     0xbf60b8: mov             SP, fp
    //     0xbf60bc: ldp             fp, lr, [SP], #0x10
    // 0xbf60c0: ret
    //     0xbf60c0: ret             
    // 0xbf60c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf60c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf60c8: b               #0xbf5fc4
    // 0xbf60cc: SaveReg d0
    //     0xbf60cc: str             q0, [SP, #-0x10]!
    // 0xbf60d0: r0 = AllocateDouble()
    //     0xbf60d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf60d4: RestoreReg d0
    //     0xbf60d4: ldr             q0, [SP], #0x10
    // 0xbf60d8: b               #0xbf5fec
  }
  _ ==(/* No info */) {
    // ** addr: 0xc833c0, size: 0x168
    // 0xc833c0: EnterFrame
    //     0xc833c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc833c4: mov             fp, SP
    // 0xc833c8: CheckStackOverflow
    //     0xc833c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc833cc: cmp             SP, x16
    //     0xc833d0: b.ls            #0xc83520
    // 0xc833d4: ldr             x1, [fp, #0x10]
    // 0xc833d8: cmp             w1, NULL
    // 0xc833dc: b.ne            #0xc833f0
    // 0xc833e0: r0 = false
    //     0xc833e0: add             x0, NULL, #0x30  ; false
    // 0xc833e4: LeaveFrame
    //     0xc833e4: mov             SP, fp
    //     0xc833e8: ldp             fp, lr, [SP], #0x10
    // 0xc833ec: ret
    //     0xc833ec: ret             
    // 0xc833f0: ldr             x2, [fp, #0x18]
    // 0xc833f4: cmp             w2, w1
    // 0xc833f8: b.ne            #0xc8340c
    // 0xc833fc: r0 = true
    //     0xc833fc: add             x0, NULL, #0x20  ; true
    // 0xc83400: LeaveFrame
    //     0xc83400: mov             SP, fp
    //     0xc83404: ldp             fp, lr, [SP], #0x10
    // 0xc83408: ret
    //     0xc83408: ret             
    // 0xc8340c: r0 = 59
    //     0xc8340c: mov             x0, #0x3b
    // 0xc83410: branchIfSmi(r1, 0xc8341c)
    //     0xc83410: tbz             w1, #0, #0xc8341c
    // 0xc83414: r0 = LoadClassIdInstr(r1)
    //     0xc83414: ldur            x0, [x1, #-1]
    //     0xc83418: ubfx            x0, x0, #0xc, #0x14
    // 0xc8341c: SaveReg r1
    //     0xc8341c: str             x1, [SP, #-8]!
    // 0xc83420: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc83420: mov             x17, #0x57c5
    //     0xc83424: add             lr, x0, x17
    //     0xc83428: ldr             lr, [x21, lr, lsl #3]
    //     0xc8342c: blr             lr
    // 0xc83430: add             SP, SP, #8
    // 0xc83434: r1 = LoadClassIdInstr(r0)
    //     0xc83434: ldur            x1, [x0, #-1]
    //     0xc83438: ubfx            x1, x1, #0xc, #0x14
    // 0xc8343c: r16 = BadgeThemeData
    //     0xc8343c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe4b0] Type: BadgeThemeData
    //     0xc83440: ldr             x16, [x16, #0x4b0]
    // 0xc83444: stp             x16, x0, [SP, #-0x10]!
    // 0xc83448: mov             x0, x1
    // 0xc8344c: mov             lr, x0
    // 0xc83450: ldr             lr, [x21, lr, lsl #3]
    // 0xc83454: blr             lr
    // 0xc83458: add             SP, SP, #0x10
    // 0xc8345c: tbz             w0, #4, #0xc83470
    // 0xc83460: r0 = false
    //     0xc83460: add             x0, NULL, #0x30  ; false
    // 0xc83464: LeaveFrame
    //     0xc83464: mov             SP, fp
    //     0xc83468: ldp             fp, lr, [SP], #0x10
    // 0xc8346c: ret
    //     0xc8346c: ret             
    // 0xc83470: ldr             x1, [fp, #0x10]
    // 0xc83474: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc83474: mov             x0, #0x76
    //     0xc83478: tbz             w1, #0, #0xc83488
    //     0xc8347c: ldur            x0, [x1, #-1]
    //     0xc83480: ubfx            x0, x0, #0xc, #0x14
    //     0xc83484: lsl             x0, x0, #1
    // 0xc83488: r17 = 5680
    //     0xc83488: mov             x17, #0x1630
    // 0xc8348c: cmp             w0, w17
    // 0xc83490: b.ne            #0xc83510
    // 0xc83494: ldr             x2, [fp, #0x18]
    // 0xc83498: LoadField: r0 = r1->field_f
    //     0xc83498: ldur            w0, [x1, #0xf]
    // 0xc8349c: DecompressPointer r0
    //     0xc8349c: add             x0, x0, HEAP, lsl #32
    // 0xc834a0: LoadField: r3 = r2->field_f
    //     0xc834a0: ldur            w3, [x2, #0xf]
    // 0xc834a4: DecompressPointer r3
    //     0xc834a4: add             x3, x3, HEAP, lsl #32
    // 0xc834a8: r4 = LoadClassIdInstr(r0)
    //     0xc834a8: ldur            x4, [x0, #-1]
    //     0xc834ac: ubfx            x4, x4, #0xc, #0x14
    // 0xc834b0: stp             x3, x0, [SP, #-0x10]!
    // 0xc834b4: mov             x0, x4
    // 0xc834b8: mov             lr, x0
    // 0xc834bc: ldr             lr, [x21, lr, lsl #3]
    // 0xc834c0: blr             lr
    // 0xc834c4: add             SP, SP, #0x10
    // 0xc834c8: tbnz            w0, #4, #0xc83510
    // 0xc834cc: ldr             x1, [fp, #0x18]
    // 0xc834d0: ldr             x0, [fp, #0x10]
    // 0xc834d4: LoadField: r2 = r0->field_13
    //     0xc834d4: ldur            w2, [x0, #0x13]
    // 0xc834d8: DecompressPointer r2
    //     0xc834d8: add             x2, x2, HEAP, lsl #32
    // 0xc834dc: LoadField: r0 = r1->field_13
    //     0xc834dc: ldur            w0, [x1, #0x13]
    // 0xc834e0: DecompressPointer r0
    //     0xc834e0: add             x0, x0, HEAP, lsl #32
    // 0xc834e4: r1 = LoadClassIdInstr(r2)
    //     0xc834e4: ldur            x1, [x2, #-1]
    //     0xc834e8: ubfx            x1, x1, #0xc, #0x14
    // 0xc834ec: stp             x0, x2, [SP, #-0x10]!
    // 0xc834f0: mov             x0, x1
    // 0xc834f4: mov             lr, x0
    // 0xc834f8: ldr             lr, [x21, lr, lsl #3]
    // 0xc834fc: blr             lr
    // 0xc83500: add             SP, SP, #0x10
    // 0xc83504: tbnz            w0, #4, #0xc83510
    // 0xc83508: r0 = true
    //     0xc83508: add             x0, NULL, #0x20  ; true
    // 0xc8350c: b               #0xc83514
    // 0xc83510: r0 = false
    //     0xc83510: add             x0, NULL, #0x30  ; false
    // 0xc83514: LeaveFrame
    //     0xc83514: mov             SP, fp
    //     0xc83518: ldp             fp, lr, [SP], #0x10
    // 0xc8351c: ret
    //     0xc8351c: ret             
    // 0xc83520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc83520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc83524: b               #0xc833d4
  }
}

// lib: , url: package:flutter/src/material/banner_theme.dart

// class id: 1049187, size: 0x8
class :: {
}

// class id: 2839, size: 0x28, field offset: 0x8
//   const constructor, 
class MaterialBannerThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafdcd4, size: 0x68
    // 0xafdcd4: EnterFrame
    //     0xafdcd4: stp             fp, lr, [SP, #-0x10]!
    //     0xafdcd8: mov             fp, SP
    // 0xafdcdc: CheckStackOverflow
    //     0xafdcdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafdce0: cmp             SP, x16
    //     0xafdce4: b.ls            #0xafdd34
    // 0xafdce8: ldr             x0, [fp, #0x10]
    // 0xafdcec: LoadField: r1 = r0->field_1b
    //     0xafdcec: ldur            w1, [x0, #0x1b]
    // 0xafdcf0: DecompressPointer r1
    //     0xafdcf0: add             x1, x1, HEAP, lsl #32
    // 0xafdcf4: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdcf8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdcfc: stp             x1, NULL, [SP, #-0x10]!
    // 0xafdd00: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdd04: r4 = const [0, 0x8, 0x8, 0x8, null]
    //     0xafdd04: ldr             x4, [PP, #0x6da0]  ; [pp+0x6da0] List(5) [0, 0x8, 0x8, 0x8, Null]
    // 0xafdd08: r0 = hash()
    //     0xafdd08: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafdd0c: add             SP, SP, #0x40
    // 0xafdd10: mov             x2, x0
    // 0xafdd14: r0 = BoxInt64Instr(r2)
    //     0xafdd14: sbfiz           x0, x2, #1, #0x1f
    //     0xafdd18: cmp             x2, x0, asr #1
    //     0xafdd1c: b.eq            #0xafdd28
    //     0xafdd20: bl              #0xd69bb8
    //     0xafdd24: stur            x2, [x0, #7]
    // 0xafdd28: LeaveFrame
    //     0xafdd28: mov             SP, fp
    //     0xafdd2c: ldp             fp, lr, [SP], #0x10
    // 0xafdd30: ret
    //     0xafdd30: ret             
    // 0xafdd34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafdd34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafdd38: b               #0xafdce8
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5e70, size: 0x130
    // 0xbf5e70: EnterFrame
    //     0xbf5e70: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5e74: mov             fp, SP
    // 0xbf5e78: AllocStack(0x10)
    //     0xbf5e78: sub             SP, SP, #0x10
    // 0xbf5e7c: CheckStackOverflow
    //     0xbf5e7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5e80: cmp             SP, x16
    //     0xbf5e84: b.ls            #0xbf5f88
    // 0xbf5e88: ldr             d0, [fp, #0x10]
    // 0xbf5e8c: r0 = inline_Allocate_Double()
    //     0xbf5e8c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf5e90: add             x0, x0, #0x10
    //     0xbf5e94: cmp             x1, x0
    //     0xbf5e98: b.ls            #0xbf5f90
    //     0xbf5e9c: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf5ea0: sub             x0, x0, #0xf
    //     0xbf5ea4: mov             x1, #0xd108
    //     0xbf5ea8: movk            x1, #3, lsl #16
    //     0xbf5eac: stur            x1, [x0, #-1]
    // 0xbf5eb0: StoreField: r0->field_7 = d0
    //     0xbf5eb0: stur            d0, [x0, #7]
    // 0xbf5eb4: stur            x0, [fp, #-8]
    // 0xbf5eb8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5ebc: SaveReg r0
    //     0xbf5ebc: str             x0, [SP, #-8]!
    // 0xbf5ec0: r0 = lerp()
    //     0xbf5ec0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5ec4: add             SP, SP, #0x18
    // 0xbf5ec8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5ecc: ldur            x16, [fp, #-8]
    // 0xbf5ed0: SaveReg r16
    //     0xbf5ed0: str             x16, [SP, #-8]!
    // 0xbf5ed4: r0 = lerp()
    //     0xbf5ed4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5ed8: add             SP, SP, #0x18
    // 0xbf5edc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5ee0: ldur            x16, [fp, #-8]
    // 0xbf5ee4: SaveReg r16
    //     0xbf5ee4: str             x16, [SP, #-8]!
    // 0xbf5ee8: r0 = lerp()
    //     0xbf5ee8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5eec: add             SP, SP, #0x18
    // 0xbf5ef0: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5ef4: ldur            x16, [fp, #-8]
    // 0xbf5ef8: SaveReg r16
    //     0xbf5ef8: str             x16, [SP, #-8]!
    // 0xbf5efc: r0 = lerp()
    //     0xbf5efc: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5f00: add             SP, SP, #0x18
    // 0xbf5f04: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5f08: ldur            x16, [fp, #-8]
    // 0xbf5f0c: SaveReg r16
    //     0xbf5f0c: str             x16, [SP, #-8]!
    // 0xbf5f10: r0 = lerp()
    //     0xbf5f10: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf5f14: add             SP, SP, #0x18
    // 0xbf5f18: ldr             x0, [fp, #0x20]
    // 0xbf5f1c: LoadField: r1 = r0->field_1b
    //     0xbf5f1c: ldur            w1, [x0, #0x1b]
    // 0xbf5f20: DecompressPointer r1
    //     0xbf5f20: add             x1, x1, HEAP, lsl #32
    // 0xbf5f24: ldr             x0, [fp, #0x18]
    // 0xbf5f28: LoadField: r2 = r0->field_1b
    //     0xbf5f28: ldur            w2, [x0, #0x1b]
    // 0xbf5f2c: DecompressPointer r2
    //     0xbf5f2c: add             x2, x2, HEAP, lsl #32
    // 0xbf5f30: stp             x2, x1, [SP, #-0x10]!
    // 0xbf5f34: ldur            x16, [fp, #-8]
    // 0xbf5f38: SaveReg r16
    //     0xbf5f38: str             x16, [SP, #-8]!
    // 0xbf5f3c: r0 = lerpDouble()
    //     0xbf5f3c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5f40: add             SP, SP, #0x18
    // 0xbf5f44: stur            x0, [fp, #-0x10]
    // 0xbf5f48: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5f4c: ldur            x16, [fp, #-8]
    // 0xbf5f50: SaveReg r16
    //     0xbf5f50: str             x16, [SP, #-8]!
    // 0xbf5f54: r0 = lerp()
    //     0xbf5f54: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf5f58: add             SP, SP, #0x18
    // 0xbf5f5c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5f60: ldur            x16, [fp, #-8]
    // 0xbf5f64: SaveReg r16
    //     0xbf5f64: str             x16, [SP, #-8]!
    // 0xbf5f68: r0 = lerp()
    //     0xbf5f68: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf5f6c: add             SP, SP, #0x18
    // 0xbf5f70: r0 = MaterialBannerThemeData()
    //     0xbf5f70: bl              #0xbf5fa0  ; AllocateMaterialBannerThemeDataStub -> MaterialBannerThemeData (size=0x28)
    // 0xbf5f74: ldur            x1, [fp, #-0x10]
    // 0xbf5f78: StoreField: r0->field_1b = r1
    //     0xbf5f78: stur            w1, [x0, #0x1b]
    // 0xbf5f7c: LeaveFrame
    //     0xbf5f7c: mov             SP, fp
    //     0xbf5f80: ldp             fp, lr, [SP], #0x10
    // 0xbf5f84: ret
    //     0xbf5f84: ret             
    // 0xbf5f88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5f88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5f8c: b               #0xbf5e88
    // 0xbf5f90: SaveReg d0
    //     0xbf5f90: str             q0, [SP, #-0x10]!
    // 0xbf5f94: r0 = AllocateDouble()
    //     0xbf5f94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf5f98: RestoreReg d0
    //     0xbf5f98: ldr             q0, [SP], #0x10
    // 0xbf5f9c: b               #0xbf5eb0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc83528, size: 0x12c
    // 0xc83528: EnterFrame
    //     0xc83528: stp             fp, lr, [SP, #-0x10]!
    //     0xc8352c: mov             fp, SP
    // 0xc83530: CheckStackOverflow
    //     0xc83530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc83534: cmp             SP, x16
    //     0xc83538: b.ls            #0xc8364c
    // 0xc8353c: ldr             x1, [fp, #0x10]
    // 0xc83540: cmp             w1, NULL
    // 0xc83544: b.ne            #0xc83558
    // 0xc83548: r0 = false
    //     0xc83548: add             x0, NULL, #0x30  ; false
    // 0xc8354c: LeaveFrame
    //     0xc8354c: mov             SP, fp
    //     0xc83550: ldp             fp, lr, [SP], #0x10
    // 0xc83554: ret
    //     0xc83554: ret             
    // 0xc83558: ldr             x2, [fp, #0x18]
    // 0xc8355c: cmp             w2, w1
    // 0xc83560: b.ne            #0xc83574
    // 0xc83564: r0 = true
    //     0xc83564: add             x0, NULL, #0x20  ; true
    // 0xc83568: LeaveFrame
    //     0xc83568: mov             SP, fp
    //     0xc8356c: ldp             fp, lr, [SP], #0x10
    // 0xc83570: ret
    //     0xc83570: ret             
    // 0xc83574: r0 = 59
    //     0xc83574: mov             x0, #0x3b
    // 0xc83578: branchIfSmi(r1, 0xc83584)
    //     0xc83578: tbz             w1, #0, #0xc83584
    // 0xc8357c: r0 = LoadClassIdInstr(r1)
    //     0xc8357c: ldur            x0, [x1, #-1]
    //     0xc83580: ubfx            x0, x0, #0xc, #0x14
    // 0xc83584: SaveReg r1
    //     0xc83584: str             x1, [SP, #-8]!
    // 0xc83588: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc83588: mov             x17, #0x57c5
    //     0xc8358c: add             lr, x0, x17
    //     0xc83590: ldr             lr, [x21, lr, lsl #3]
    //     0xc83594: blr             lr
    // 0xc83598: add             SP, SP, #8
    // 0xc8359c: r1 = LoadClassIdInstr(r0)
    //     0xc8359c: ldur            x1, [x0, #-1]
    //     0xc835a0: ubfx            x1, x1, #0xc, #0x14
    // 0xc835a4: r16 = MaterialBannerThemeData
    //     0xc835a4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe4a8] Type: MaterialBannerThemeData
    //     0xc835a8: ldr             x16, [x16, #0x4a8]
    // 0xc835ac: stp             x16, x0, [SP, #-0x10]!
    // 0xc835b0: mov             x0, x1
    // 0xc835b4: mov             lr, x0
    // 0xc835b8: ldr             lr, [x21, lr, lsl #3]
    // 0xc835bc: blr             lr
    // 0xc835c0: add             SP, SP, #0x10
    // 0xc835c4: tbz             w0, #4, #0xc835d8
    // 0xc835c8: r0 = false
    //     0xc835c8: add             x0, NULL, #0x30  ; false
    // 0xc835cc: LeaveFrame
    //     0xc835cc: mov             SP, fp
    //     0xc835d0: ldp             fp, lr, [SP], #0x10
    // 0xc835d4: ret
    //     0xc835d4: ret             
    // 0xc835d8: ldr             x0, [fp, #0x10]
    // 0xc835dc: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc835dc: mov             x1, #0x76
    //     0xc835e0: tbz             w0, #0, #0xc835f0
    //     0xc835e4: ldur            x1, [x0, #-1]
    //     0xc835e8: ubfx            x1, x1, #0xc, #0x14
    //     0xc835ec: lsl             x1, x1, #1
    // 0xc835f0: r17 = 5678
    //     0xc835f0: mov             x17, #0x162e
    // 0xc835f4: cmp             w1, w17
    // 0xc835f8: b.ne            #0xc8363c
    // 0xc835fc: ldr             x1, [fp, #0x18]
    // 0xc83600: LoadField: r2 = r0->field_1b
    //     0xc83600: ldur            w2, [x0, #0x1b]
    // 0xc83604: DecompressPointer r2
    //     0xc83604: add             x2, x2, HEAP, lsl #32
    // 0xc83608: LoadField: r0 = r1->field_1b
    //     0xc83608: ldur            w0, [x1, #0x1b]
    // 0xc8360c: DecompressPointer r0
    //     0xc8360c: add             x0, x0, HEAP, lsl #32
    // 0xc83610: r1 = LoadClassIdInstr(r2)
    //     0xc83610: ldur            x1, [x2, #-1]
    //     0xc83614: ubfx            x1, x1, #0xc, #0x14
    // 0xc83618: stp             x0, x2, [SP, #-0x10]!
    // 0xc8361c: mov             x0, x1
    // 0xc83620: mov             lr, x0
    // 0xc83624: ldr             lr, [x21, lr, lsl #3]
    // 0xc83628: blr             lr
    // 0xc8362c: add             SP, SP, #0x10
    // 0xc83630: tbnz            w0, #4, #0xc8363c
    // 0xc83634: r0 = true
    //     0xc83634: add             x0, NULL, #0x20  ; true
    // 0xc83638: b               #0xc83640
    // 0xc8363c: r0 = false
    //     0xc8363c: add             x0, NULL, #0x30  ; false
    // 0xc83640: LeaveFrame
    //     0xc83640: mov             SP, fp
    //     0xc83644: ldp             fp, lr, [SP], #0x10
    // 0xc83648: ret
    //     0xc83648: ret             
    // 0xc8364c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8364c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc83650: b               #0xc8353c
  }
}

// class id: 3550, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class MaterialBannerTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0x86564c, size: 0x60
    // 0x86564c: EnterFrame
    //     0x86564c: stp             fp, lr, [SP, #-0x10]!
    //     0x865650: mov             fp, SP
    // 0x865654: CheckStackOverflow
    //     0x865654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x865658: cmp             SP, x16
    //     0x86565c: b.ls            #0x8656a4
    // 0x865660: r16 = <MaterialBannerTheme>
    //     0x865660: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e60] TypeArguments: <MaterialBannerTheme>
    //     0x865664: ldr             x16, [x16, #0xe60]
    // 0x865668: ldr             lr, [fp, #0x10]
    // 0x86566c: stp             lr, x16, [SP, #-0x10]!
    // 0x865670: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x865670: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x865674: r0 = dependOnInheritedWidgetOfExactType()
    //     0x865674: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x865678: add             SP, SP, #0x10
    // 0x86567c: ldr             x16, [fp, #0x10]
    // 0x865680: SaveReg r16
    //     0x865680: str             x16, [SP, #-8]!
    // 0x865684: r0 = of()
    //     0x865684: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x865688: add             SP, SP, #8
    // 0x86568c: LoadField: r1 = r0->field_a3
    //     0x86568c: ldur            w1, [x0, #0xa3]
    // 0x865690: DecompressPointer r1
    //     0x865690: add             x1, x1, HEAP, lsl #32
    // 0x865694: mov             x0, x1
    // 0x865698: LeaveFrame
    //     0x865698: mov             SP, fp
    //     0x86569c: ldp             fp, lr, [SP], #0x10
    // 0x8656a0: ret
    //     0x8656a0: ret             
    // 0x8656a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8656a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8656a8: b               #0x865660
  }
}

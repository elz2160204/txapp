// lib: , url: package:flutter/src/material/floating_action_button_theme.dart

// class id: 1049247, size: 0x8
class :: {
}

// class id: 2798, size: 0x5c, field offset: 0x8
//   const constructor, 
class FloatingActionButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff404, size: 0x828
    // 0xaff404: EnterFrame
    //     0xaff404: stp             fp, lr, [SP, #-0x10]!
    //     0xaff408: mov             fp, SP
    // 0xaff40c: AllocStack(0xa8)
    //     0xaff40c: sub             SP, SP, #0xa8
    // 0xaff410: CheckStackOverflow
    //     0xaff410: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff414: cmp             SP, x16
    //     0xaff418: b.ls            #0xaffbe4
    // 0xaff41c: ldr             x0, [fp, #0x10]
    // 0xaff420: r2 = LoadClassIdInstr(r0)
    //     0xaff420: ldur            x2, [x0, #-1]
    //     0xaff424: ubfx            x2, x2, #0xc, #0x14
    // 0xaff428: lsl             x2, x2, #1
    // 0xaff42c: stur            x2, [fp, #-8]
    // 0xaff430: r17 = 5596
    //     0xaff430: mov             x17, #0x15dc
    // 0xaff434: cmp             w2, w17
    // 0xaff438: b.ne            #0xaff44c
    // 0xaff43c: LoadField: r1 = r0->field_7
    //     0xaff43c: ldur            w1, [x0, #7]
    // 0xaff440: DecompressPointer r1
    //     0xaff440: add             x1, x1, HEAP, lsl #32
    // 0xaff444: mov             x3, x1
    // 0xaff448: b               #0xaff4c8
    // 0xaff44c: r17 = 5598
    //     0xaff44c: mov             x17, #0x15de
    // 0xaff450: cmp             w2, w17
    // 0xaff454: b.ne            #0xaff4b0
    // 0xaff458: mov             x1, x0
    // 0xaff45c: LoadField: r0 = r1->field_67
    //     0xaff45c: ldur            w0, [x1, #0x67]
    // 0xaff460: DecompressPointer r0
    //     0xaff460: add             x0, x0, HEAP, lsl #32
    // 0xaff464: r16 = Sentinel
    //     0xaff464: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaff468: cmp             w0, w16
    // 0xaff46c: b.ne            #0xaff47c
    // 0xaff470: r2 = _colors
    //     0xaff470: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xaff474: ldr             x2, [x2, #0x328]
    // 0xaff478: r0 = InitLateFinalInstanceField()
    //     0xaff478: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaff47c: LoadField: r1 = r0->field_17
    //     0xaff47c: ldur            w1, [x0, #0x17]
    // 0xaff480: DecompressPointer r1
    //     0xaff480: add             x1, x1, HEAP, lsl #32
    // 0xaff484: cmp             w1, NULL
    // 0xaff488: b.ne            #0xaff49c
    // 0xaff48c: LoadField: r1 = r0->field_f
    //     0xaff48c: ldur            w1, [x0, #0xf]
    // 0xaff490: DecompressPointer r1
    //     0xaff490: add             x1, x1, HEAP, lsl #32
    // 0xaff494: mov             x0, x1
    // 0xaff498: b               #0xaff4a0
    // 0xaff49c: mov             x0, x1
    // 0xaff4a0: mov             x3, x0
    // 0xaff4a4: ldr             x0, [fp, #0x10]
    // 0xaff4a8: ldur            x2, [fp, #-8]
    // 0xaff4ac: b               #0xaff4c8
    // 0xaff4b0: LoadField: r1 = r0->field_67
    //     0xaff4b0: ldur            w1, [x0, #0x67]
    // 0xaff4b4: DecompressPointer r1
    //     0xaff4b4: add             x1, x1, HEAP, lsl #32
    // 0xaff4b8: LoadField: r2 = r1->field_1f
    //     0xaff4b8: ldur            w2, [x1, #0x1f]
    // 0xaff4bc: DecompressPointer r2
    //     0xaff4bc: add             x2, x2, HEAP, lsl #32
    // 0xaff4c0: mov             x3, x2
    // 0xaff4c4: ldur            x2, [fp, #-8]
    // 0xaff4c8: stur            x3, [fp, #-0x10]
    // 0xaff4cc: r17 = 5596
    //     0xaff4cc: mov             x17, #0x15dc
    // 0xaff4d0: cmp             w2, w17
    // 0xaff4d4: b.ne            #0xaff4e8
    // 0xaff4d8: LoadField: r1 = r0->field_b
    //     0xaff4d8: ldur            w1, [x0, #0xb]
    // 0xaff4dc: DecompressPointer r1
    //     0xaff4dc: add             x1, x1, HEAP, lsl #32
    // 0xaff4e0: mov             x3, x1
    // 0xaff4e4: b               #0xaff564
    // 0xaff4e8: r17 = 5598
    //     0xaff4e8: mov             x17, #0x15de
    // 0xaff4ec: cmp             w2, w17
    // 0xaff4f0: b.ne            #0xaff54c
    // 0xaff4f4: mov             x1, x0
    // 0xaff4f8: LoadField: r0 = r1->field_67
    //     0xaff4f8: ldur            w0, [x1, #0x67]
    // 0xaff4fc: DecompressPointer r0
    //     0xaff4fc: add             x0, x0, HEAP, lsl #32
    // 0xaff500: r16 = Sentinel
    //     0xaff500: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaff504: cmp             w0, w16
    // 0xaff508: b.ne            #0xaff518
    // 0xaff50c: r2 = _colors
    //     0xaff50c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xaff510: ldr             x2, [x2, #0x328]
    // 0xaff514: r0 = InitLateFinalInstanceField()
    //     0xaff514: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaff518: LoadField: r1 = r0->field_13
    //     0xaff518: ldur            w1, [x0, #0x13]
    // 0xaff51c: DecompressPointer r1
    //     0xaff51c: add             x1, x1, HEAP, lsl #32
    // 0xaff520: cmp             w1, NULL
    // 0xaff524: b.ne            #0xaff538
    // 0xaff528: LoadField: r1 = r0->field_b
    //     0xaff528: ldur            w1, [x0, #0xb]
    // 0xaff52c: DecompressPointer r1
    //     0xaff52c: add             x1, x1, HEAP, lsl #32
    // 0xaff530: mov             x0, x1
    // 0xaff534: b               #0xaff53c
    // 0xaff538: mov             x0, x1
    // 0xaff53c: mov             x3, x0
    // 0xaff540: ldr             x0, [fp, #0x10]
    // 0xaff544: ldur            x2, [fp, #-8]
    // 0xaff548: b               #0xaff564
    // 0xaff54c: LoadField: r1 = r0->field_67
    //     0xaff54c: ldur            w1, [x0, #0x67]
    // 0xaff550: DecompressPointer r1
    //     0xaff550: add             x1, x1, HEAP, lsl #32
    // 0xaff554: LoadField: r2 = r1->field_1b
    //     0xaff554: ldur            w2, [x1, #0x1b]
    // 0xaff558: DecompressPointer r2
    //     0xaff558: add             x2, x2, HEAP, lsl #32
    // 0xaff55c: mov             x3, x2
    // 0xaff560: ldur            x2, [fp, #-8]
    // 0xaff564: stur            x3, [fp, #-0x18]
    // 0xaff568: r17 = 5596
    //     0xaff568: mov             x17, #0x15dc
    // 0xaff56c: cmp             w2, w17
    // 0xaff570: b.ne            #0xaff584
    // 0xaff574: LoadField: r1 = r0->field_f
    //     0xaff574: ldur            w1, [x0, #0xf]
    // 0xaff578: DecompressPointer r1
    //     0xaff578: add             x1, x1, HEAP, lsl #32
    // 0xaff57c: mov             x3, x1
    // 0xaff580: b               #0xaff618
    // 0xaff584: r17 = 5598
    //     0xaff584: mov             x17, #0x15de
    // 0xaff588: cmp             w2, w17
    // 0xaff58c: b.ne            #0xaff600
    // 0xaff590: mov             x1, x0
    // 0xaff594: LoadField: r0 = r1->field_67
    //     0xaff594: ldur            w0, [x1, #0x67]
    // 0xaff598: DecompressPointer r0
    //     0xaff598: add             x0, x0, HEAP, lsl #32
    // 0xaff59c: r16 = Sentinel
    //     0xaff59c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaff5a0: cmp             w0, w16
    // 0xaff5a4: b.ne            #0xaff5b4
    // 0xaff5a8: r2 = _colors
    //     0xaff5a8: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xaff5ac: ldr             x2, [x2, #0x328]
    // 0xaff5b0: r0 = InitLateFinalInstanceField()
    //     0xaff5b0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaff5b4: LoadField: r1 = r0->field_17
    //     0xaff5b4: ldur            w1, [x0, #0x17]
    // 0xaff5b8: DecompressPointer r1
    //     0xaff5b8: add             x1, x1, HEAP, lsl #32
    // 0xaff5bc: cmp             w1, NULL
    // 0xaff5c0: b.ne            #0xaff5d4
    // 0xaff5c4: LoadField: r1 = r0->field_f
    //     0xaff5c4: ldur            w1, [x0, #0xf]
    // 0xaff5c8: DecompressPointer r1
    //     0xaff5c8: add             x1, x1, HEAP, lsl #32
    // 0xaff5cc: mov             x0, x1
    // 0xaff5d0: b               #0xaff5d8
    // 0xaff5d4: mov             x0, x1
    // 0xaff5d8: d0 = 0.120000
    //     0xaff5d8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xaff5dc: ldr             d0, [x17, #0xf48]
    // 0xaff5e0: SaveReg r0
    //     0xaff5e0: str             x0, [SP, #-8]!
    // 0xaff5e4: SaveReg d0
    //     0xaff5e4: str             d0, [SP, #-8]!
    // 0xaff5e8: r0 = withOpacity()
    //     0xaff5e8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xaff5ec: add             SP, SP, #0x10
    // 0xaff5f0: mov             x3, x0
    // 0xaff5f4: ldr             x0, [fp, #0x10]
    // 0xaff5f8: ldur            x2, [fp, #-8]
    // 0xaff5fc: b               #0xaff618
    // 0xaff600: LoadField: r1 = r0->field_63
    //     0xaff600: ldur            w1, [x0, #0x63]
    // 0xaff604: DecompressPointer r1
    //     0xaff604: add             x1, x1, HEAP, lsl #32
    // 0xaff608: LoadField: r2 = r1->field_4f
    //     0xaff608: ldur            w2, [x1, #0x4f]
    // 0xaff60c: DecompressPointer r2
    //     0xaff60c: add             x2, x2, HEAP, lsl #32
    // 0xaff610: mov             x3, x2
    // 0xaff614: ldur            x2, [fp, #-8]
    // 0xaff618: stur            x3, [fp, #-0x20]
    // 0xaff61c: r17 = 5596
    //     0xaff61c: mov             x17, #0x15dc
    // 0xaff620: cmp             w2, w17
    // 0xaff624: b.ne            #0xaff638
    // 0xaff628: LoadField: r1 = r0->field_13
    //     0xaff628: ldur            w1, [x0, #0x13]
    // 0xaff62c: DecompressPointer r1
    //     0xaff62c: add             x1, x1, HEAP, lsl #32
    // 0xaff630: mov             x3, x1
    // 0xaff634: b               #0xaff6cc
    // 0xaff638: r17 = 5598
    //     0xaff638: mov             x17, #0x15de
    // 0xaff63c: cmp             w2, w17
    // 0xaff640: b.ne            #0xaff6b4
    // 0xaff644: mov             x1, x0
    // 0xaff648: LoadField: r0 = r1->field_67
    //     0xaff648: ldur            w0, [x1, #0x67]
    // 0xaff64c: DecompressPointer r0
    //     0xaff64c: add             x0, x0, HEAP, lsl #32
    // 0xaff650: r16 = Sentinel
    //     0xaff650: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaff654: cmp             w0, w16
    // 0xaff658: b.ne            #0xaff668
    // 0xaff65c: r2 = _colors
    //     0xaff65c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xaff660: ldr             x2, [x2, #0x328]
    // 0xaff664: r0 = InitLateFinalInstanceField()
    //     0xaff664: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaff668: LoadField: r1 = r0->field_17
    //     0xaff668: ldur            w1, [x0, #0x17]
    // 0xaff66c: DecompressPointer r1
    //     0xaff66c: add             x1, x1, HEAP, lsl #32
    // 0xaff670: cmp             w1, NULL
    // 0xaff674: b.ne            #0xaff688
    // 0xaff678: LoadField: r1 = r0->field_f
    //     0xaff678: ldur            w1, [x0, #0xf]
    // 0xaff67c: DecompressPointer r1
    //     0xaff67c: add             x1, x1, HEAP, lsl #32
    // 0xaff680: mov             x0, x1
    // 0xaff684: b               #0xaff68c
    // 0xaff688: mov             x0, x1
    // 0xaff68c: d0 = 0.080000
    //     0xaff68c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xaff690: ldr             d0, [x17, #0xf80]
    // 0xaff694: SaveReg r0
    //     0xaff694: str             x0, [SP, #-8]!
    // 0xaff698: SaveReg d0
    //     0xaff698: str             d0, [SP, #-8]!
    // 0xaff69c: r0 = withOpacity()
    //     0xaff69c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xaff6a0: add             SP, SP, #0x10
    // 0xaff6a4: mov             x3, x0
    // 0xaff6a8: ldr             x0, [fp, #0x10]
    // 0xaff6ac: ldur            x2, [fp, #-8]
    // 0xaff6b0: b               #0xaff6cc
    // 0xaff6b4: LoadField: r1 = r0->field_63
    //     0xaff6b4: ldur            w1, [x0, #0x63]
    // 0xaff6b8: DecompressPointer r1
    //     0xaff6b8: add             x1, x1, HEAP, lsl #32
    // 0xaff6bc: LoadField: r2 = r1->field_5b
    //     0xaff6bc: ldur            w2, [x1, #0x5b]
    // 0xaff6c0: DecompressPointer r2
    //     0xaff6c0: add             x2, x2, HEAP, lsl #32
    // 0xaff6c4: mov             x3, x2
    // 0xaff6c8: ldur            x2, [fp, #-8]
    // 0xaff6cc: stur            x3, [fp, #-0x28]
    // 0xaff6d0: r17 = 5596
    //     0xaff6d0: mov             x17, #0x15dc
    // 0xaff6d4: cmp             w2, w17
    // 0xaff6d8: b.ne            #0xaff700
    // 0xaff6dc: LoadField: r1 = r0->field_17
    //     0xaff6dc: ldur            w1, [x0, #0x17]
    // 0xaff6e0: DecompressPointer r1
    //     0xaff6e0: add             x1, x1, HEAP, lsl #32
    // 0xaff6e4: mov             x16, x0
    // 0xaff6e8: mov             x0, x1
    // 0xaff6ec: mov             x1, x16
    // 0xaff6f0: mov             x16, x2
    // 0xaff6f4: mov             x2, x0
    // 0xaff6f8: mov             x0, x16
    // 0xaff6fc: b               #0xaff794
    // 0xaff700: r17 = 5598
    //     0xaff700: mov             x17, #0x15de
    // 0xaff704: cmp             w2, w17
    // 0xaff708: b.ne            #0xaff77c
    // 0xaff70c: mov             x1, x0
    // 0xaff710: LoadField: r0 = r1->field_67
    //     0xaff710: ldur            w0, [x1, #0x67]
    // 0xaff714: DecompressPointer r0
    //     0xaff714: add             x0, x0, HEAP, lsl #32
    // 0xaff718: r16 = Sentinel
    //     0xaff718: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaff71c: cmp             w0, w16
    // 0xaff720: b.ne            #0xaff730
    // 0xaff724: r2 = _colors
    //     0xaff724: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xaff728: ldr             x2, [x2, #0x328]
    // 0xaff72c: r0 = InitLateFinalInstanceField()
    //     0xaff72c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaff730: LoadField: r1 = r0->field_17
    //     0xaff730: ldur            w1, [x0, #0x17]
    // 0xaff734: DecompressPointer r1
    //     0xaff734: add             x1, x1, HEAP, lsl #32
    // 0xaff738: cmp             w1, NULL
    // 0xaff73c: b.ne            #0xaff750
    // 0xaff740: LoadField: r1 = r0->field_f
    //     0xaff740: ldur            w1, [x0, #0xf]
    // 0xaff744: DecompressPointer r1
    //     0xaff744: add             x1, x1, HEAP, lsl #32
    // 0xaff748: mov             x0, x1
    // 0xaff74c: b               #0xaff754
    // 0xaff750: mov             x0, x1
    // 0xaff754: d0 = 0.120000
    //     0xaff754: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xaff758: ldr             d0, [x17, #0xf48]
    // 0xaff75c: SaveReg r0
    //     0xaff75c: str             x0, [SP, #-8]!
    // 0xaff760: SaveReg d0
    //     0xaff760: str             d0, [SP, #-8]!
    // 0xaff764: r0 = withOpacity()
    //     0xaff764: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xaff768: add             SP, SP, #0x10
    // 0xaff76c: mov             x2, x0
    // 0xaff770: ldr             x1, [fp, #0x10]
    // 0xaff774: ldur            x0, [fp, #-8]
    // 0xaff778: b               #0xaff794
    // 0xaff77c: mov             x1, x0
    // 0xaff780: LoadField: r0 = r1->field_63
    //     0xaff780: ldur            w0, [x1, #0x63]
    // 0xaff784: DecompressPointer r0
    //     0xaff784: add             x0, x0, HEAP, lsl #32
    // 0xaff788: LoadField: r2 = r0->field_7f
    //     0xaff788: ldur            w2, [x0, #0x7f]
    // 0xaff78c: DecompressPointer r2
    //     0xaff78c: add             x2, x2, HEAP, lsl #32
    // 0xaff790: ldur            x0, [fp, #-8]
    // 0xaff794: stur            x2, [fp, #-0x98]
    // 0xaff798: LoadField: r3 = r1->field_1b
    //     0xaff798: ldur            w3, [x1, #0x1b]
    // 0xaff79c: DecompressPointer r3
    //     0xaff79c: add             x3, x3, HEAP, lsl #32
    // 0xaff7a0: stur            x3, [fp, #-0x90]
    // 0xaff7a4: LoadField: r4 = r1->field_1f
    //     0xaff7a4: ldur            w4, [x1, #0x1f]
    // 0xaff7a8: DecompressPointer r4
    //     0xaff7a8: add             x4, x4, HEAP, lsl #32
    // 0xaff7ac: stur            x4, [fp, #-0x88]
    // 0xaff7b0: LoadField: r5 = r1->field_23
    //     0xaff7b0: ldur            w5, [x1, #0x23]
    // 0xaff7b4: DecompressPointer r5
    //     0xaff7b4: add             x5, x5, HEAP, lsl #32
    // 0xaff7b8: stur            x5, [fp, #-0x80]
    // 0xaff7bc: LoadField: r6 = r1->field_27
    //     0xaff7bc: ldur            w6, [x1, #0x27]
    // 0xaff7c0: DecompressPointer r6
    //     0xaff7c0: add             x6, x6, HEAP, lsl #32
    // 0xaff7c4: stur            x6, [fp, #-0x78]
    // 0xaff7c8: LoadField: r7 = r1->field_2b
    //     0xaff7c8: ldur            w7, [x1, #0x2b]
    // 0xaff7cc: DecompressPointer r7
    //     0xaff7cc: add             x7, x7, HEAP, lsl #32
    // 0xaff7d0: stur            x7, [fp, #-0x70]
    // 0xaff7d4: r17 = 5596
    //     0xaff7d4: mov             x17, #0x15dc
    // 0xaff7d8: cmp             w0, w17
    // 0xaff7dc: b.ne            #0xaff7ec
    // 0xaff7e0: LoadField: r8 = r1->field_2f
    //     0xaff7e0: ldur            w8, [x1, #0x2f]
    // 0xaff7e4: DecompressPointer r8
    //     0xaff7e4: add             x8, x8, HEAP, lsl #32
    // 0xaff7e8: b               #0xaff878
    // 0xaff7ec: r17 = 5598
    //     0xaff7ec: mov             x17, #0x15de
    // 0xaff7f0: cmp             w0, w17
    // 0xaff7f4: b.ne            #0xaff84c
    // 0xaff7f8: LoadField: r8 = r1->field_5f
    //     0xaff7f8: ldur            w8, [x1, #0x5f]
    // 0xaff7fc: DecompressPointer r8
    //     0xaff7fc: add             x8, x8, HEAP, lsl #32
    // 0xaff800: LoadField: r9 = r8->field_7
    //     0xaff800: ldur            x9, [x8, #7]
    // 0xaff804: cmp             x9, #1
    // 0xaff808: b.gt            #0xaff82c
    // 0xaff80c: cmp             x9, #0
    // 0xaff810: b.gt            #0xaff820
    // 0xaff814: r8 = Instance_RoundedRectangleBorder
    //     0xaff814: add             x8, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xaff818: ldr             x8, [x8, #0x330]
    // 0xaff81c: b               #0xaff878
    // 0xaff820: r8 = Instance_RoundedRectangleBorder
    //     0xaff820: add             x8, PP, #0xe, lsl #12  ; [pp+0xe338] Obj!RoundedRectangleBorder@b38421
    //     0xaff824: ldr             x8, [x8, #0x338]
    // 0xaff828: b               #0xaff878
    // 0xaff82c: cmp             x9, #2
    // 0xaff830: b.gt            #0xaff840
    // 0xaff834: r8 = Instance_RoundedRectangleBorder
    //     0xaff834: add             x8, PP, #0xe, lsl #12  ; [pp+0xe340] Obj!RoundedRectangleBorder@b38411
    //     0xaff838: ldr             x8, [x8, #0x340]
    // 0xaff83c: b               #0xaff878
    // 0xaff840: r8 = Instance_RoundedRectangleBorder
    //     0xaff840: add             x8, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xaff844: ldr             x8, [x8, #0x330]
    // 0xaff848: b               #0xaff878
    // 0xaff84c: LoadField: r8 = r1->field_5b
    //     0xaff84c: ldur            w8, [x1, #0x5b]
    // 0xaff850: DecompressPointer r8
    //     0xaff850: add             x8, x8, HEAP, lsl #32
    // 0xaff854: r16 = Instance__FloatingActionButtonType
    //     0xaff854: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xaff858: ldr             x16, [x16, #0x348]
    // 0xaff85c: cmp             w8, w16
    // 0xaff860: b.ne            #0xaff870
    // 0xaff864: r8 = Instance_StadiumBorder
    //     0xaff864: add             x8, PP, #0xe, lsl #12  ; [pp+0xe350] Obj!StadiumBorder@b383b1
    //     0xaff868: ldr             x8, [x8, #0x350]
    // 0xaff86c: b               #0xaff878
    // 0xaff870: r8 = Instance_CircleBorder
    //     0xaff870: add             x8, PP, #0xe, lsl #12  ; [pp+0xe358] Obj!CircleBorder@b38441
    //     0xaff874: ldr             x8, [x8, #0x358]
    // 0xaff878: stur            x8, [fp, #-0x68]
    // 0xaff87c: LoadField: r9 = r1->field_33
    //     0xaff87c: ldur            w9, [x1, #0x33]
    // 0xaff880: DecompressPointer r9
    //     0xaff880: add             x9, x9, HEAP, lsl #32
    // 0xaff884: stur            x9, [fp, #-0x60]
    // 0xaff888: r17 = 5596
    //     0xaff888: mov             x17, #0x15dc
    // 0xaff88c: cmp             w0, w17
    // 0xaff890: b.ne            #0xaff8a0
    // 0xaff894: LoadField: r10 = r1->field_37
    //     0xaff894: ldur            w10, [x1, #0x37]
    // 0xaff898: DecompressPointer r10
    //     0xaff898: add             x10, x10, HEAP, lsl #32
    // 0xaff89c: b               #0xaff950
    // 0xaff8a0: r17 = 5598
    //     0xaff8a0: mov             x17, #0x15de
    // 0xaff8a4: cmp             w0, w17
    // 0xaff8a8: b.ne            #0xaff900
    // 0xaff8ac: LoadField: r10 = r1->field_5f
    //     0xaff8ac: ldur            w10, [x1, #0x5f]
    // 0xaff8b0: DecompressPointer r10
    //     0xaff8b0: add             x10, x10, HEAP, lsl #32
    // 0xaff8b4: LoadField: r11 = r10->field_7
    //     0xaff8b4: ldur            x11, [x10, #7]
    // 0xaff8b8: cmp             x11, #1
    // 0xaff8bc: b.gt            #0xaff8e0
    // 0xaff8c0: cmp             x11, #0
    // 0xaff8c4: b.gt            #0xaff8d4
    // 0xaff8c8: r10 = 24.000000
    //     0xaff8c8: add             x10, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xaff8cc: ldr             x10, [x10, #0x360]
    // 0xaff8d0: b               #0xaff950
    // 0xaff8d4: r10 = 24.000000
    //     0xaff8d4: add             x10, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xaff8d8: ldr             x10, [x10, #0x360]
    // 0xaff8dc: b               #0xaff950
    // 0xaff8e0: cmp             x11, #2
    // 0xaff8e4: b.gt            #0xaff8f4
    // 0xaff8e8: r10 = 36.000000
    //     0xaff8e8: add             x10, PP, #0xe, lsl #12  ; [pp+0xe368] 36
    //     0xaff8ec: ldr             x10, [x10, #0x368]
    // 0xaff8f0: b               #0xaff950
    // 0xaff8f4: r10 = 24.000000
    //     0xaff8f4: add             x10, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xaff8f8: ldr             x10, [x10, #0x360]
    // 0xaff8fc: b               #0xaff950
    // 0xaff900: LoadField: r10 = r1->field_5b
    //     0xaff900: ldur            w10, [x1, #0x5b]
    // 0xaff904: DecompressPointer r10
    //     0xaff904: add             x10, x10, HEAP, lsl #32
    // 0xaff908: r16 = Instance__FloatingActionButtonType
    //     0xaff908: add             x16, PP, #0xe, lsl #12  ; [pp+0xe370] Obj!_FloatingActionButtonType@b65891
    //     0xaff90c: ldr             x16, [x16, #0x370]
    // 0xaff910: cmp             w10, w16
    // 0xaff914: b.ne            #0xaff924
    // 0xaff918: d0 = 36.000000
    //     0xaff918: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xaff91c: ldr             d0, [x17, #0xfa8]
    // 0xaff920: b               #0xaff928
    // 0xaff924: d0 = 24.000000
    //     0xaff924: fmov            d0, #24.00000000
    // 0xaff928: r10 = inline_Allocate_Double()
    //     0xaff928: ldp             x10, x11, [THR, #0x60]  ; THR::top
    //     0xaff92c: add             x10, x10, #0x10
    //     0xaff930: cmp             x11, x10
    //     0xaff934: b.ls            #0xaffbec
    //     0xaff938: str             x10, [THR, #0x60]  ; THR::top
    //     0xaff93c: sub             x10, x10, #0xf
    //     0xaff940: mov             x11, #0xd108
    //     0xaff944: movk            x11, #3, lsl #16
    //     0xaff948: stur            x11, [x10, #-1]
    // 0xaff94c: StoreField: r10->field_7 = d0
    //     0xaff94c: stur            d0, [x10, #7]
    // 0xaff950: stur            x10, [fp, #-0x58]
    // 0xaff954: LoadField: r11 = r1->field_3b
    //     0xaff954: ldur            w11, [x1, #0x3b]
    // 0xaff958: DecompressPointer r11
    //     0xaff958: add             x11, x11, HEAP, lsl #32
    // 0xaff95c: stur            x11, [fp, #-0x50]
    // 0xaff960: LoadField: r12 = r1->field_3f
    //     0xaff960: ldur            w12, [x1, #0x3f]
    // 0xaff964: DecompressPointer r12
    //     0xaff964: add             x12, x12, HEAP, lsl #32
    // 0xaff968: stur            x12, [fp, #-0x48]
    // 0xaff96c: LoadField: r13 = r1->field_43
    //     0xaff96c: ldur            w13, [x1, #0x43]
    // 0xaff970: DecompressPointer r13
    //     0xaff970: add             x13, x13, HEAP, lsl #32
    // 0xaff974: stur            x13, [fp, #-0x40]
    // 0xaff978: LoadField: r14 = r1->field_47
    //     0xaff978: ldur            w14, [x1, #0x47]
    // 0xaff97c: DecompressPointer r14
    //     0xaff97c: add             x14, x14, HEAP, lsl #32
    // 0xaff980: stur            x14, [fp, #-0x38]
    // 0xaff984: LoadField: r19 = r1->field_4b
    //     0xaff984: ldur            w19, [x1, #0x4b]
    // 0xaff988: DecompressPointer r19
    //     0xaff988: add             x19, x19, HEAP, lsl #32
    // 0xaff98c: stur            x19, [fp, #-0x30]
    // 0xaff990: r17 = 5596
    //     0xaff990: mov             x17, #0x15dc
    // 0xaff994: cmp             w0, w17
    // 0xaff998: b.ne            #0xaff9ac
    // 0xaff99c: LoadField: r20 = r1->field_4f
    //     0xaff99c: ldur            w20, [x1, #0x4f]
    // 0xaff9a0: DecompressPointer r20
    //     0xaff9a0: add             x20, x20, HEAP, lsl #32
    // 0xaff9a4: mov             x2, x20
    // 0xaff9a8: b               #0xaffa7c
    // 0xaff9ac: r17 = 5598
    //     0xaff9ac: mov             x17, #0x15de
    // 0xaff9b0: cmp             w0, w17
    // 0xaff9b4: b.ne            #0xaffa18
    // 0xaff9b8: LoadField: r20 = r1->field_63
    //     0xaff9b8: ldur            w20, [x1, #0x63]
    // 0xaff9bc: DecompressPointer r20
    //     0xaff9bc: add             x20, x20, HEAP, lsl #32
    // 0xaff9c0: tbnz            w20, #4, #0xaff9e4
    // 0xaff9c4: LoadField: r20 = r1->field_5f
    //     0xaff9c4: ldur            w20, [x1, #0x5f]
    // 0xaff9c8: DecompressPointer r20
    //     0xaff9c8: add             x20, x20, HEAP, lsl #32
    // 0xaff9cc: r16 = Instance__FloatingActionButtonType
    //     0xaff9cc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xaff9d0: ldr             x16, [x16, #0x348]
    // 0xaff9d4: cmp             w20, w16
    // 0xaff9d8: b.ne            #0xaff9e4
    // 0xaff9dc: d0 = 16.000000
    //     0xaff9dc: fmov            d0, #16.00000000
    // 0xaff9e0: b               #0xaff9e8
    // 0xaff9e4: d0 = 20.000000
    //     0xaff9e4: fmov            d0, #20.00000000
    // 0xaff9e8: stur            d0, [fp, #-0xa8]
    // 0xaff9ec: r0 = EdgeInsetsDirectional()
    //     0xaff9ec: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xaff9f0: ldur            d0, [fp, #-0xa8]
    // 0xaff9f4: StoreField: r0->field_7 = d0
    //     0xaff9f4: stur            d0, [x0, #7]
    // 0xaff9f8: d0 = 0.000000
    //     0xaff9f8: eor             v0.16b, v0.16b, v0.16b
    // 0xaff9fc: StoreField: r0->field_f = d0
    //     0xaff9fc: stur            d0, [x0, #0xf]
    // 0xaffa00: d1 = 20.000000
    //     0xaffa00: fmov            d1, #20.00000000
    // 0xaffa04: StoreField: r0->field_17 = d1
    //     0xaffa04: stur            d1, [x0, #0x17]
    // 0xaffa08: StoreField: r0->field_1f = d0
    //     0xaffa08: stur            d0, [x0, #0x1f]
    // 0xaffa0c: mov             x2, x0
    // 0xaffa10: ldur            x0, [fp, #-8]
    // 0xaffa14: b               #0xaffa7c
    // 0xaffa18: d1 = 20.000000
    //     0xaffa18: fmov            d1, #20.00000000
    // 0xaffa1c: d0 = 0.000000
    //     0xaffa1c: eor             v0.16b, v0.16b, v0.16b
    // 0xaffa20: LoadField: r0 = r1->field_5f
    //     0xaffa20: ldur            w0, [x1, #0x5f]
    // 0xaffa24: DecompressPointer r0
    //     0xaffa24: add             x0, x0, HEAP, lsl #32
    // 0xaffa28: tbnz            w0, #4, #0xaffa4c
    // 0xaffa2c: LoadField: r0 = r1->field_5b
    //     0xaffa2c: ldur            w0, [x1, #0x5b]
    // 0xaffa30: DecompressPointer r0
    //     0xaffa30: add             x0, x0, HEAP, lsl #32
    // 0xaffa34: r16 = Instance__FloatingActionButtonType
    //     0xaffa34: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xaffa38: ldr             x16, [x16, #0x348]
    // 0xaffa3c: cmp             w0, w16
    // 0xaffa40: b.ne            #0xaffa4c
    // 0xaffa44: d2 = 16.000000
    //     0xaffa44: fmov            d2, #16.00000000
    // 0xaffa48: b               #0xaffa50
    // 0xaffa4c: d2 = 20.000000
    //     0xaffa4c: fmov            d2, #20.00000000
    // 0xaffa50: stur            d2, [fp, #-0xa8]
    // 0xaffa54: r0 = EdgeInsetsDirectional()
    //     0xaffa54: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xaffa58: ldur            d0, [fp, #-0xa8]
    // 0xaffa5c: StoreField: r0->field_7 = d0
    //     0xaffa5c: stur            d0, [x0, #7]
    // 0xaffa60: d0 = 0.000000
    //     0xaffa60: eor             v0.16b, v0.16b, v0.16b
    // 0xaffa64: StoreField: r0->field_f = d0
    //     0xaffa64: stur            d0, [x0, #0xf]
    // 0xaffa68: d1 = 20.000000
    //     0xaffa68: fmov            d1, #20.00000000
    // 0xaffa6c: StoreField: r0->field_17 = d1
    //     0xaffa6c: stur            d1, [x0, #0x17]
    // 0xaffa70: StoreField: r0->field_1f = d0
    //     0xaffa70: stur            d0, [x0, #0x1f]
    // 0xaffa74: mov             x2, x0
    // 0xaffa78: ldur            x0, [fp, #-8]
    // 0xaffa7c: stur            x2, [fp, #-0xa0]
    // 0xaffa80: r17 = 5596
    //     0xaffa80: mov             x17, #0x15dc
    // 0xaffa84: cmp             w0, w17
    // 0xaffa88: b.ne            #0xaffa9c
    // 0xaffa8c: ldr             x1, [fp, #0x10]
    // 0xaffa90: LoadField: r0 = r1->field_53
    //     0xaffa90: ldur            w0, [x1, #0x53]
    // 0xaffa94: DecompressPointer r0
    //     0xaffa94: add             x0, x0, HEAP, lsl #32
    // 0xaffa98: b               #0xaffb18
    // 0xaffa9c: ldr             x1, [fp, #0x10]
    // 0xaffaa0: r17 = 5598
    //     0xaffaa0: mov             x17, #0x15de
    // 0xaffaa4: cmp             w0, w17
    // 0xaffaa8: b.ne            #0xaffadc
    // 0xaffaac: LoadField: r0 = r1->field_6b
    //     0xaffaac: ldur            w0, [x1, #0x6b]
    // 0xaffab0: DecompressPointer r0
    //     0xaffab0: add             x0, x0, HEAP, lsl #32
    // 0xaffab4: r16 = Sentinel
    //     0xaffab4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xaffab8: cmp             w0, w16
    // 0xaffabc: b.ne            #0xaffacc
    // 0xaffac0: r2 = _textTheme
    //     0xaffac0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe378] Field <_FABDefaultsM3@746192485._textTheme@746192485>: late final (offset: 0x6c)
    //     0xaffac4: ldr             x2, [x2, #0x378]
    // 0xaffac8: r0 = InitLateFinalInstanceField()
    //     0xaffac8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xaffacc: LoadField: r1 = r0->field_37
    //     0xaffacc: ldur            w1, [x0, #0x37]
    // 0xaffad0: DecompressPointer r1
    //     0xaffad0: add             x1, x1, HEAP, lsl #32
    // 0xaffad4: mov             x0, x1
    // 0xaffad8: b               #0xaffb18
    // 0xaffadc: LoadField: r0 = r1->field_63
    //     0xaffadc: ldur            w0, [x1, #0x63]
    // 0xaffae0: DecompressPointer r0
    //     0xaffae0: add             x0, x0, HEAP, lsl #32
    // 0xaffae4: LoadField: r1 = r0->field_93
    //     0xaffae4: ldur            w1, [x0, #0x93]
    // 0xaffae8: DecompressPointer r1
    //     0xaffae8: add             x1, x1, HEAP, lsl #32
    // 0xaffaec: LoadField: r0 = r1->field_37
    //     0xaffaec: ldur            w0, [x1, #0x37]
    // 0xaffaf0: DecompressPointer r0
    //     0xaffaf0: add             x0, x0, HEAP, lsl #32
    // 0xaffaf4: cmp             w0, NULL
    // 0xaffaf8: b.eq            #0xaffc28
    // 0xaffafc: r16 = 1.200000
    //     0xaffafc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe380] 1.2
    //     0xaffb00: ldr             x16, [x16, #0x380]
    // 0xaffb04: stp             x16, x0, [SP, #-0x10]!
    // 0xaffb08: r4 = const [0, 0x2, 0x2, 0x1, letterSpacing, 0x1, null]
    //     0xaffb08: add             x4, PP, #0xe, lsl #12  ; [pp+0xe388] List(7) [0, 0x2, 0x2, 0x1, "letterSpacing", 0x1, Null]
    //     0xaffb0c: ldr             x4, [x4, #0x388]
    // 0xaffb10: r0 = copyWith()
    //     0xaffb10: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xaffb14: add             SP, SP, #0x10
    // 0xaffb18: stp             NULL, x0, [SP, #-0x10]!
    // 0xaffb1c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xaffb1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xaffb20: r0 = hash()
    //     0xaffb20: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaffb24: add             SP, SP, #0x10
    // 0xaffb28: mov             x2, x0
    // 0xaffb2c: r0 = BoxInt64Instr(r2)
    //     0xaffb2c: sbfiz           x0, x2, #1, #0x1f
    //     0xaffb30: cmp             x2, x0, asr #1
    //     0xaffb34: b.eq            #0xaffb40
    //     0xaffb38: bl              #0xd69bb8
    //     0xaffb3c: stur            x2, [x0, #7]
    // 0xaffb40: ldur            x16, [fp, #-0x10]
    // 0xaffb44: ldur            lr, [fp, #-0x18]
    // 0xaffb48: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb4c: ldur            x16, [fp, #-0x20]
    // 0xaffb50: ldur            lr, [fp, #-0x28]
    // 0xaffb54: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb58: ldur            x16, [fp, #-0x98]
    // 0xaffb5c: ldur            lr, [fp, #-0x90]
    // 0xaffb60: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb64: ldur            x16, [fp, #-0x88]
    // 0xaffb68: ldur            lr, [fp, #-0x80]
    // 0xaffb6c: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb70: ldur            x16, [fp, #-0x78]
    // 0xaffb74: ldur            lr, [fp, #-0x70]
    // 0xaffb78: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb7c: ldur            x16, [fp, #-0x68]
    // 0xaffb80: ldur            lr, [fp, #-0x60]
    // 0xaffb84: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb88: ldur            x16, [fp, #-0x58]
    // 0xaffb8c: ldur            lr, [fp, #-0x50]
    // 0xaffb90: stp             lr, x16, [SP, #-0x10]!
    // 0xaffb94: ldur            x16, [fp, #-0x48]
    // 0xaffb98: ldur            lr, [fp, #-0x40]
    // 0xaffb9c: stp             lr, x16, [SP, #-0x10]!
    // 0xaffba0: ldur            x16, [fp, #-0x38]
    // 0xaffba4: ldur            lr, [fp, #-0x30]
    // 0xaffba8: stp             lr, x16, [SP, #-0x10]!
    // 0xaffbac: ldur            x16, [fp, #-0xa0]
    // 0xaffbb0: stp             x0, x16, [SP, #-0x10]!
    // 0xaffbb4: r4 = const [0, 0x14, 0x14, 0x14, null]
    //     0xaffbb4: ldr             x4, [PP, #0x70d8]  ; [pp+0x70d8] List(5) [0, 0x14, 0x14, 0x14, Null]
    // 0xaffbb8: r0 = hash()
    //     0xaffbb8: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaffbbc: add             SP, SP, #0xa0
    // 0xaffbc0: mov             x2, x0
    // 0xaffbc4: r0 = BoxInt64Instr(r2)
    //     0xaffbc4: sbfiz           x0, x2, #1, #0x1f
    //     0xaffbc8: cmp             x2, x0, asr #1
    //     0xaffbcc: b.eq            #0xaffbd8
    //     0xaffbd0: bl              #0xd69bb8
    //     0xaffbd4: stur            x2, [x0, #7]
    // 0xaffbd8: LeaveFrame
    //     0xaffbd8: mov             SP, fp
    //     0xaffbdc: ldp             fp, lr, [SP], #0x10
    // 0xaffbe0: ret
    //     0xaffbe0: ret             
    // 0xaffbe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaffbe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaffbe8: b               #0xaff41c
    // 0xaffbec: SaveReg d0
    //     0xaffbec: str             q0, [SP, #-0x10]!
    // 0xaffbf0: stp             x8, x9, [SP, #-0x10]!
    // 0xaffbf4: stp             x6, x7, [SP, #-0x10]!
    // 0xaffbf8: stp             x4, x5, [SP, #-0x10]!
    // 0xaffbfc: stp             x2, x3, [SP, #-0x10]!
    // 0xaffc00: stp             x0, x1, [SP, #-0x10]!
    // 0xaffc04: r0 = AllocateDouble()
    //     0xaffc04: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaffc08: mov             x10, x0
    // 0xaffc0c: ldp             x0, x1, [SP], #0x10
    // 0xaffc10: ldp             x2, x3, [SP], #0x10
    // 0xaffc14: ldp             x4, x5, [SP], #0x10
    // 0xaffc18: ldp             x6, x7, [SP], #0x10
    // 0xaffc1c: ldp             x8, x9, [SP], #0x10
    // 0xaffc20: RestoreReg d0
    //     0xaffc20: ldr             q0, [SP], #0x10
    // 0xaffc24: b               #0xaff94c
    // 0xaffc28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xaffc28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf45a0, size: 0x3d8
    // 0xbf45a0: EnterFrame
    //     0xbf45a0: stp             fp, lr, [SP, #-0x10]!
    //     0xbf45a4: mov             fp, SP
    // 0xbf45a8: AllocStack(0x68)
    //     0xbf45a8: sub             SP, SP, #0x68
    // 0xbf45ac: CheckStackOverflow
    //     0xbf45ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf45b0: cmp             SP, x16
    //     0xbf45b4: b.ls            #0xbf4960
    // 0xbf45b8: ldr             d0, [fp, #0x10]
    // 0xbf45bc: r0 = inline_Allocate_Double()
    //     0xbf45bc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf45c0: add             x0, x0, #0x10
    //     0xbf45c4: cmp             x1, x0
    //     0xbf45c8: b.ls            #0xbf4968
    //     0xbf45cc: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf45d0: sub             x0, x0, #0xf
    //     0xbf45d4: mov             x1, #0xd108
    //     0xbf45d8: movk            x1, #3, lsl #16
    //     0xbf45dc: stur            x1, [x0, #-1]
    // 0xbf45e0: StoreField: r0->field_7 = d0
    //     0xbf45e0: stur            d0, [x0, #7]
    // 0xbf45e4: stur            x0, [fp, #-8]
    // 0xbf45e8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf45ec: SaveReg r0
    //     0xbf45ec: str             x0, [SP, #-8]!
    // 0xbf45f0: r0 = lerp()
    //     0xbf45f0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf45f4: add             SP, SP, #0x18
    // 0xbf45f8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf45fc: ldur            x16, [fp, #-8]
    // 0xbf4600: SaveReg r16
    //     0xbf4600: str             x16, [SP, #-8]!
    // 0xbf4604: r0 = lerp()
    //     0xbf4604: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4608: add             SP, SP, #0x18
    // 0xbf460c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4610: ldur            x16, [fp, #-8]
    // 0xbf4614: SaveReg r16
    //     0xbf4614: str             x16, [SP, #-8]!
    // 0xbf4618: r0 = lerp()
    //     0xbf4618: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf461c: add             SP, SP, #0x18
    // 0xbf4620: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4624: ldur            x16, [fp, #-8]
    // 0xbf4628: SaveReg r16
    //     0xbf4628: str             x16, [SP, #-8]!
    // 0xbf462c: r0 = lerp()
    //     0xbf462c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4630: add             SP, SP, #0x18
    // 0xbf4634: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4638: ldur            x16, [fp, #-8]
    // 0xbf463c: SaveReg r16
    //     0xbf463c: str             x16, [SP, #-8]!
    // 0xbf4640: r0 = lerp()
    //     0xbf4640: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf4644: add             SP, SP, #0x18
    // 0xbf4648: ldr             x0, [fp, #0x20]
    // 0xbf464c: LoadField: r1 = r0->field_1b
    //     0xbf464c: ldur            w1, [x0, #0x1b]
    // 0xbf4650: DecompressPointer r1
    //     0xbf4650: add             x1, x1, HEAP, lsl #32
    // 0xbf4654: ldr             x2, [fp, #0x18]
    // 0xbf4658: LoadField: r3 = r2->field_1b
    //     0xbf4658: ldur            w3, [x2, #0x1b]
    // 0xbf465c: DecompressPointer r3
    //     0xbf465c: add             x3, x3, HEAP, lsl #32
    // 0xbf4660: stp             x3, x1, [SP, #-0x10]!
    // 0xbf4664: ldur            x16, [fp, #-8]
    // 0xbf4668: SaveReg r16
    //     0xbf4668: str             x16, [SP, #-8]!
    // 0xbf466c: r0 = lerpDouble()
    //     0xbf466c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4670: add             SP, SP, #0x18
    // 0xbf4674: mov             x1, x0
    // 0xbf4678: ldr             x0, [fp, #0x20]
    // 0xbf467c: stur            x1, [fp, #-0x10]
    // 0xbf4680: LoadField: r2 = r0->field_1f
    //     0xbf4680: ldur            w2, [x0, #0x1f]
    // 0xbf4684: DecompressPointer r2
    //     0xbf4684: add             x2, x2, HEAP, lsl #32
    // 0xbf4688: ldr             x3, [fp, #0x18]
    // 0xbf468c: LoadField: r4 = r3->field_1f
    //     0xbf468c: ldur            w4, [x3, #0x1f]
    // 0xbf4690: DecompressPointer r4
    //     0xbf4690: add             x4, x4, HEAP, lsl #32
    // 0xbf4694: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4698: ldur            x16, [fp, #-8]
    // 0xbf469c: SaveReg r16
    //     0xbf469c: str             x16, [SP, #-8]!
    // 0xbf46a0: r0 = lerpDouble()
    //     0xbf46a0: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf46a4: add             SP, SP, #0x18
    // 0xbf46a8: mov             x1, x0
    // 0xbf46ac: ldr             x0, [fp, #0x20]
    // 0xbf46b0: stur            x1, [fp, #-0x18]
    // 0xbf46b4: LoadField: r2 = r0->field_23
    //     0xbf46b4: ldur            w2, [x0, #0x23]
    // 0xbf46b8: DecompressPointer r2
    //     0xbf46b8: add             x2, x2, HEAP, lsl #32
    // 0xbf46bc: ldr             x3, [fp, #0x18]
    // 0xbf46c0: LoadField: r4 = r3->field_23
    //     0xbf46c0: ldur            w4, [x3, #0x23]
    // 0xbf46c4: DecompressPointer r4
    //     0xbf46c4: add             x4, x4, HEAP, lsl #32
    // 0xbf46c8: stp             x4, x2, [SP, #-0x10]!
    // 0xbf46cc: ldur            x16, [fp, #-8]
    // 0xbf46d0: SaveReg r16
    //     0xbf46d0: str             x16, [SP, #-8]!
    // 0xbf46d4: r0 = lerpDouble()
    //     0xbf46d4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf46d8: add             SP, SP, #0x18
    // 0xbf46dc: mov             x1, x0
    // 0xbf46e0: ldr             x0, [fp, #0x20]
    // 0xbf46e4: stur            x1, [fp, #-0x20]
    // 0xbf46e8: LoadField: r2 = r0->field_27
    //     0xbf46e8: ldur            w2, [x0, #0x27]
    // 0xbf46ec: DecompressPointer r2
    //     0xbf46ec: add             x2, x2, HEAP, lsl #32
    // 0xbf46f0: ldr             x3, [fp, #0x18]
    // 0xbf46f4: LoadField: r4 = r3->field_27
    //     0xbf46f4: ldur            w4, [x3, #0x27]
    // 0xbf46f8: DecompressPointer r4
    //     0xbf46f8: add             x4, x4, HEAP, lsl #32
    // 0xbf46fc: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4700: ldur            x16, [fp, #-8]
    // 0xbf4704: SaveReg r16
    //     0xbf4704: str             x16, [SP, #-8]!
    // 0xbf4708: r0 = lerpDouble()
    //     0xbf4708: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf470c: add             SP, SP, #0x18
    // 0xbf4710: mov             x1, x0
    // 0xbf4714: ldr             x0, [fp, #0x20]
    // 0xbf4718: stur            x1, [fp, #-0x28]
    // 0xbf471c: LoadField: r2 = r0->field_2b
    //     0xbf471c: ldur            w2, [x0, #0x2b]
    // 0xbf4720: DecompressPointer r2
    //     0xbf4720: add             x2, x2, HEAP, lsl #32
    // 0xbf4724: ldr             x3, [fp, #0x18]
    // 0xbf4728: LoadField: r4 = r3->field_2b
    //     0xbf4728: ldur            w4, [x3, #0x2b]
    // 0xbf472c: DecompressPointer r4
    //     0xbf472c: add             x4, x4, HEAP, lsl #32
    // 0xbf4730: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4734: ldur            x16, [fp, #-8]
    // 0xbf4738: SaveReg r16
    //     0xbf4738: str             x16, [SP, #-8]!
    // 0xbf473c: r0 = lerpDouble()
    //     0xbf473c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf4740: add             SP, SP, #0x18
    // 0xbf4744: ldr             d1, [fp, #0x10]
    // 0xbf4748: d0 = 0.500000
    //     0xbf4748: fmov            d0, #0.50000000
    // 0xbf474c: stur            x0, [fp, #-0x38]
    // 0xbf4750: fcmp            d1, d0
    // 0xbf4754: b.vs            #0xbf4774
    // 0xbf4758: b.ge            #0xbf4774
    // 0xbf475c: ldr             x1, [fp, #0x20]
    // 0xbf4760: LoadField: r2 = r1->field_33
    //     0xbf4760: ldur            w2, [x1, #0x33]
    // 0xbf4764: DecompressPointer r2
    //     0xbf4764: add             x2, x2, HEAP, lsl #32
    // 0xbf4768: mov             x7, x2
    // 0xbf476c: ldr             x2, [fp, #0x18]
    // 0xbf4770: b               #0xbf4788
    // 0xbf4774: ldr             x1, [fp, #0x20]
    // 0xbf4778: ldr             x2, [fp, #0x18]
    // 0xbf477c: LoadField: r3 = r2->field_33
    //     0xbf477c: ldur            w3, [x2, #0x33]
    // 0xbf4780: DecompressPointer r3
    //     0xbf4780: add             x3, x3, HEAP, lsl #32
    // 0xbf4784: mov             x7, x3
    // 0xbf4788: ldur            x6, [fp, #-0x10]
    // 0xbf478c: ldur            x5, [fp, #-0x18]
    // 0xbf4790: ldur            x4, [fp, #-0x20]
    // 0xbf4794: ldur            x3, [fp, #-0x28]
    // 0xbf4798: stur            x7, [fp, #-0x30]
    // 0xbf479c: LoadField: r8 = r1->field_37
    //     0xbf479c: ldur            w8, [x1, #0x37]
    // 0xbf47a0: DecompressPointer r8
    //     0xbf47a0: add             x8, x8, HEAP, lsl #32
    // 0xbf47a4: LoadField: r9 = r2->field_37
    //     0xbf47a4: ldur            w9, [x2, #0x37]
    // 0xbf47a8: DecompressPointer r9
    //     0xbf47a8: add             x9, x9, HEAP, lsl #32
    // 0xbf47ac: stp             x9, x8, [SP, #-0x10]!
    // 0xbf47b0: ldur            x16, [fp, #-8]
    // 0xbf47b4: SaveReg r16
    //     0xbf47b4: str             x16, [SP, #-8]!
    // 0xbf47b8: r0 = lerpDouble()
    //     0xbf47b8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf47bc: add             SP, SP, #0x18
    // 0xbf47c0: mov             x1, x0
    // 0xbf47c4: ldr             x0, [fp, #0x20]
    // 0xbf47c8: stur            x1, [fp, #-0x40]
    // 0xbf47cc: LoadField: r2 = r0->field_3b
    //     0xbf47cc: ldur            w2, [x0, #0x3b]
    // 0xbf47d0: DecompressPointer r2
    //     0xbf47d0: add             x2, x2, HEAP, lsl #32
    // 0xbf47d4: ldr             x3, [fp, #0x18]
    // 0xbf47d8: LoadField: r4 = r3->field_3b
    //     0xbf47d8: ldur            w4, [x3, #0x3b]
    // 0xbf47dc: DecompressPointer r4
    //     0xbf47dc: add             x4, x4, HEAP, lsl #32
    // 0xbf47e0: stp             x4, x2, [SP, #-0x10]!
    // 0xbf47e4: ldr             d0, [fp, #0x10]
    // 0xbf47e8: SaveReg d0
    //     0xbf47e8: str             d0, [SP, #-8]!
    // 0xbf47ec: r0 = lerp()
    //     0xbf47ec: bl              #0xbee9cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0xbf47f0: add             SP, SP, #0x18
    // 0xbf47f4: mov             x1, x0
    // 0xbf47f8: ldr             x0, [fp, #0x20]
    // 0xbf47fc: stur            x1, [fp, #-0x48]
    // 0xbf4800: LoadField: r2 = r0->field_3f
    //     0xbf4800: ldur            w2, [x0, #0x3f]
    // 0xbf4804: DecompressPointer r2
    //     0xbf4804: add             x2, x2, HEAP, lsl #32
    // 0xbf4808: ldr             x3, [fp, #0x18]
    // 0xbf480c: LoadField: r4 = r3->field_3f
    //     0xbf480c: ldur            w4, [x3, #0x3f]
    // 0xbf4810: DecompressPointer r4
    //     0xbf4810: add             x4, x4, HEAP, lsl #32
    // 0xbf4814: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4818: ldr             d0, [fp, #0x10]
    // 0xbf481c: SaveReg d0
    //     0xbf481c: str             d0, [SP, #-8]!
    // 0xbf4820: r0 = lerp()
    //     0xbf4820: bl              #0xbee9cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0xbf4824: add             SP, SP, #0x18
    // 0xbf4828: mov             x1, x0
    // 0xbf482c: ldr             x0, [fp, #0x20]
    // 0xbf4830: stur            x1, [fp, #-0x50]
    // 0xbf4834: LoadField: r2 = r0->field_43
    //     0xbf4834: ldur            w2, [x0, #0x43]
    // 0xbf4838: DecompressPointer r2
    //     0xbf4838: add             x2, x2, HEAP, lsl #32
    // 0xbf483c: ldr             x3, [fp, #0x18]
    // 0xbf4840: LoadField: r4 = r3->field_43
    //     0xbf4840: ldur            w4, [x3, #0x43]
    // 0xbf4844: DecompressPointer r4
    //     0xbf4844: add             x4, x4, HEAP, lsl #32
    // 0xbf4848: stp             x4, x2, [SP, #-0x10]!
    // 0xbf484c: ldr             d0, [fp, #0x10]
    // 0xbf4850: SaveReg d0
    //     0xbf4850: str             d0, [SP, #-8]!
    // 0xbf4854: r0 = lerp()
    //     0xbf4854: bl              #0xbee9cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0xbf4858: add             SP, SP, #0x18
    // 0xbf485c: mov             x1, x0
    // 0xbf4860: ldr             x0, [fp, #0x20]
    // 0xbf4864: stur            x1, [fp, #-0x58]
    // 0xbf4868: LoadField: r2 = r0->field_47
    //     0xbf4868: ldur            w2, [x0, #0x47]
    // 0xbf486c: DecompressPointer r2
    //     0xbf486c: add             x2, x2, HEAP, lsl #32
    // 0xbf4870: ldr             x3, [fp, #0x18]
    // 0xbf4874: LoadField: r4 = r3->field_47
    //     0xbf4874: ldur            w4, [x3, #0x47]
    // 0xbf4878: DecompressPointer r4
    //     0xbf4878: add             x4, x4, HEAP, lsl #32
    // 0xbf487c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf4880: ldr             d0, [fp, #0x10]
    // 0xbf4884: SaveReg d0
    //     0xbf4884: str             d0, [SP, #-8]!
    // 0xbf4888: r0 = lerp()
    //     0xbf4888: bl              #0xbee9cc  ; [package:flutter/src/rendering/box.dart] BoxConstraints::lerp
    // 0xbf488c: add             SP, SP, #0x18
    // 0xbf4890: mov             x1, x0
    // 0xbf4894: ldr             x0, [fp, #0x20]
    // 0xbf4898: stur            x1, [fp, #-0x60]
    // 0xbf489c: LoadField: r2 = r0->field_4b
    //     0xbf489c: ldur            w2, [x0, #0x4b]
    // 0xbf48a0: DecompressPointer r2
    //     0xbf48a0: add             x2, x2, HEAP, lsl #32
    // 0xbf48a4: ldr             x0, [fp, #0x18]
    // 0xbf48a8: LoadField: r3 = r0->field_4b
    //     0xbf48a8: ldur            w3, [x0, #0x4b]
    // 0xbf48ac: DecompressPointer r3
    //     0xbf48ac: add             x3, x3, HEAP, lsl #32
    // 0xbf48b0: stp             x3, x2, [SP, #-0x10]!
    // 0xbf48b4: ldur            x16, [fp, #-8]
    // 0xbf48b8: SaveReg r16
    //     0xbf48b8: str             x16, [SP, #-8]!
    // 0xbf48bc: r0 = lerpDouble()
    //     0xbf48bc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf48c0: add             SP, SP, #0x18
    // 0xbf48c4: stur            x0, [fp, #-0x68]
    // 0xbf48c8: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf48cc: ldur            x16, [fp, #-8]
    // 0xbf48d0: SaveReg r16
    //     0xbf48d0: str             x16, [SP, #-8]!
    // 0xbf48d4: r0 = lerp()
    //     0xbf48d4: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf48d8: add             SP, SP, #0x18
    // 0xbf48dc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf48e0: ldur            x16, [fp, #-8]
    // 0xbf48e4: SaveReg r16
    //     0xbf48e4: str             x16, [SP, #-8]!
    // 0xbf48e8: r0 = lerp()
    //     0xbf48e8: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf48ec: add             SP, SP, #0x18
    // 0xbf48f0: r0 = FloatingActionButtonThemeData()
    //     0xbf48f0: bl              #0xbf4978  ; AllocateFloatingActionButtonThemeDataStub -> FloatingActionButtonThemeData (size=0x5c)
    // 0xbf48f4: ldur            x1, [fp, #-0x10]
    // 0xbf48f8: StoreField: r0->field_1b = r1
    //     0xbf48f8: stur            w1, [x0, #0x1b]
    // 0xbf48fc: ldur            x1, [fp, #-0x18]
    // 0xbf4900: StoreField: r0->field_1f = r1
    //     0xbf4900: stur            w1, [x0, #0x1f]
    // 0xbf4904: ldur            x1, [fp, #-0x20]
    // 0xbf4908: StoreField: r0->field_23 = r1
    //     0xbf4908: stur            w1, [x0, #0x23]
    // 0xbf490c: ldur            x1, [fp, #-0x28]
    // 0xbf4910: StoreField: r0->field_27 = r1
    //     0xbf4910: stur            w1, [x0, #0x27]
    // 0xbf4914: ldur            x1, [fp, #-0x38]
    // 0xbf4918: StoreField: r0->field_2b = r1
    //     0xbf4918: stur            w1, [x0, #0x2b]
    // 0xbf491c: ldur            x1, [fp, #-0x30]
    // 0xbf4920: StoreField: r0->field_33 = r1
    //     0xbf4920: stur            w1, [x0, #0x33]
    // 0xbf4924: ldur            x1, [fp, #-0x40]
    // 0xbf4928: StoreField: r0->field_37 = r1
    //     0xbf4928: stur            w1, [x0, #0x37]
    // 0xbf492c: ldur            x1, [fp, #-0x48]
    // 0xbf4930: StoreField: r0->field_3b = r1
    //     0xbf4930: stur            w1, [x0, #0x3b]
    // 0xbf4934: ldur            x1, [fp, #-0x50]
    // 0xbf4938: StoreField: r0->field_3f = r1
    //     0xbf4938: stur            w1, [x0, #0x3f]
    // 0xbf493c: ldur            x1, [fp, #-0x58]
    // 0xbf4940: StoreField: r0->field_43 = r1
    //     0xbf4940: stur            w1, [x0, #0x43]
    // 0xbf4944: ldur            x1, [fp, #-0x60]
    // 0xbf4948: StoreField: r0->field_47 = r1
    //     0xbf4948: stur            w1, [x0, #0x47]
    // 0xbf494c: ldur            x1, [fp, #-0x68]
    // 0xbf4950: StoreField: r0->field_4b = r1
    //     0xbf4950: stur            w1, [x0, #0x4b]
    // 0xbf4954: LeaveFrame
    //     0xbf4954: mov             SP, fp
    //     0xbf4958: ldp             fp, lr, [SP], #0x10
    // 0xbf495c: ret
    //     0xbf495c: ret             
    // 0xbf4960: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf4960: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4964: b               #0xbf45b8
    // 0xbf4968: SaveReg d0
    //     0xbf4968: str             q0, [SP, #-0x10]!
    // 0xbf496c: r0 = AllocateDouble()
    //     0xbf496c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf4970: RestoreReg d0
    //     0xbf4970: ldr             q0, [SP], #0x10
    // 0xbf4974: b               #0xbf45e0
  }
  _ ==(/* No info */) {
    // ** addr: 0xc88cac, size: 0x1294
    // 0xc88cac: EnterFrame
    //     0xc88cac: stp             fp, lr, [SP, #-0x10]!
    //     0xc88cb0: mov             fp, SP
    // 0xc88cb4: AllocStack(0x20)
    //     0xc88cb4: sub             SP, SP, #0x20
    // 0xc88cb8: CheckStackOverflow
    //     0xc88cb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc88cbc: cmp             SP, x16
    //     0xc88cc0: b.ls            #0xc89ee4
    // 0xc88cc4: ldr             x1, [fp, #0x10]
    // 0xc88cc8: cmp             w1, NULL
    // 0xc88ccc: b.ne            #0xc88ce0
    // 0xc88cd0: r0 = false
    //     0xc88cd0: add             x0, NULL, #0x30  ; false
    // 0xc88cd4: LeaveFrame
    //     0xc88cd4: mov             SP, fp
    //     0xc88cd8: ldp             fp, lr, [SP], #0x10
    // 0xc88cdc: ret
    //     0xc88cdc: ret             
    // 0xc88ce0: ldr             x2, [fp, #0x18]
    // 0xc88ce4: cmp             w2, w1
    // 0xc88ce8: b.ne            #0xc88cfc
    // 0xc88cec: r0 = true
    //     0xc88cec: add             x0, NULL, #0x20  ; true
    // 0xc88cf0: LeaveFrame
    //     0xc88cf0: mov             SP, fp
    //     0xc88cf4: ldp             fp, lr, [SP], #0x10
    // 0xc88cf8: ret
    //     0xc88cf8: ret             
    // 0xc88cfc: r0 = 59
    //     0xc88cfc: mov             x0, #0x3b
    // 0xc88d00: branchIfSmi(r1, 0xc88d0c)
    //     0xc88d00: tbz             w1, #0, #0xc88d0c
    // 0xc88d04: r0 = LoadClassIdInstr(r1)
    //     0xc88d04: ldur            x0, [x1, #-1]
    //     0xc88d08: ubfx            x0, x0, #0xc, #0x14
    // 0xc88d0c: SaveReg r1
    //     0xc88d0c: str             x1, [SP, #-8]!
    // 0xc88d10: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc88d10: mov             x17, #0x57c5
    //     0xc88d14: add             lr, x0, x17
    //     0xc88d18: ldr             lr, [x21, lr, lsl #3]
    //     0xc88d1c: blr             lr
    // 0xc88d20: add             SP, SP, #8
    // 0xc88d24: stur            x0, [fp, #-8]
    // 0xc88d28: ldr             x16, [fp, #0x18]
    // 0xc88d2c: SaveReg r16
    //     0xc88d2c: str             x16, [SP, #-8]!
    // 0xc88d30: r0 = runtimeType()
    //     0xc88d30: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc88d34: add             SP, SP, #8
    // 0xc88d38: mov             x1, x0
    // 0xc88d3c: ldur            x0, [fp, #-8]
    // 0xc88d40: r2 = LoadClassIdInstr(r0)
    //     0xc88d40: ldur            x2, [x0, #-1]
    //     0xc88d44: ubfx            x2, x2, #0xc, #0x14
    // 0xc88d48: stp             x1, x0, [SP, #-0x10]!
    // 0xc88d4c: mov             x0, x2
    // 0xc88d50: mov             lr, x0
    // 0xc88d54: ldr             lr, [x21, lr, lsl #3]
    // 0xc88d58: blr             lr
    // 0xc88d5c: add             SP, SP, #0x10
    // 0xc88d60: tbz             w0, #4, #0xc88d74
    // 0xc88d64: r0 = false
    //     0xc88d64: add             x0, NULL, #0x30  ; false
    // 0xc88d68: LeaveFrame
    //     0xc88d68: mov             SP, fp
    //     0xc88d6c: ldp             fp, lr, [SP], #0x10
    // 0xc88d70: ret
    //     0xc88d70: ret             
    // 0xc88d74: ldr             x0, [fp, #0x10]
    // 0xc88d78: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc88d78: mov             x2, #0x76
    //     0xc88d7c: tbz             w0, #0, #0xc88d8c
    //     0xc88d80: ldur            x2, [x0, #-1]
    //     0xc88d84: ubfx            x2, x2, #0xc, #0x14
    //     0xc88d88: lsl             x2, x2, #1
    // 0xc88d8c: stur            x2, [fp, #-8]
    // 0xc88d90: r1 = LoadInt32Instr(r2)
    //     0xc88d90: sbfx            x1, x2, #1, #0x1f
    // 0xc88d94: cmp             x1, #0xaee
    // 0xc88d98: b.lt            #0xc89ed4
    // 0xc88d9c: cmp             x1, #0xaf0
    // 0xc88da0: b.gt            #0xc89ed4
    // 0xc88da4: r17 = 5596
    //     0xc88da4: mov             x17, #0x15dc
    // 0xc88da8: cmp             w2, w17
    // 0xc88dac: b.ne            #0xc88dc0
    // 0xc88db0: LoadField: r1 = r0->field_7
    //     0xc88db0: ldur            w1, [x0, #7]
    // 0xc88db4: DecompressPointer r1
    //     0xc88db4: add             x1, x1, HEAP, lsl #32
    // 0xc88db8: mov             x3, x1
    // 0xc88dbc: b               #0xc88e34
    // 0xc88dc0: r17 = 5598
    //     0xc88dc0: mov             x17, #0x15de
    // 0xc88dc4: cmp             w2, w17
    // 0xc88dc8: b.ne            #0xc88e20
    // 0xc88dcc: mov             x1, x0
    // 0xc88dd0: LoadField: r0 = r1->field_67
    //     0xc88dd0: ldur            w0, [x1, #0x67]
    // 0xc88dd4: DecompressPointer r0
    //     0xc88dd4: add             x0, x0, HEAP, lsl #32
    // 0xc88dd8: r16 = Sentinel
    //     0xc88dd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc88ddc: cmp             w0, w16
    // 0xc88de0: b.ne            #0xc88df0
    // 0xc88de4: r2 = _colors
    //     0xc88de4: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc88de8: ldr             x2, [x2, #0x328]
    // 0xc88dec: r0 = InitLateFinalInstanceField()
    //     0xc88dec: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc88df0: LoadField: r1 = r0->field_17
    //     0xc88df0: ldur            w1, [x0, #0x17]
    // 0xc88df4: DecompressPointer r1
    //     0xc88df4: add             x1, x1, HEAP, lsl #32
    // 0xc88df8: cmp             w1, NULL
    // 0xc88dfc: b.ne            #0xc88e10
    // 0xc88e00: LoadField: r1 = r0->field_f
    //     0xc88e00: ldur            w1, [x0, #0xf]
    // 0xc88e04: DecompressPointer r1
    //     0xc88e04: add             x1, x1, HEAP, lsl #32
    // 0xc88e08: mov             x0, x1
    // 0xc88e0c: b               #0xc88e14
    // 0xc88e10: mov             x0, x1
    // 0xc88e14: mov             x3, x0
    // 0xc88e18: ldr             x0, [fp, #0x10]
    // 0xc88e1c: b               #0xc88e34
    // 0xc88e20: LoadField: r1 = r0->field_67
    //     0xc88e20: ldur            w1, [x0, #0x67]
    // 0xc88e24: DecompressPointer r1
    //     0xc88e24: add             x1, x1, HEAP, lsl #32
    // 0xc88e28: LoadField: r2 = r1->field_1f
    //     0xc88e28: ldur            w2, [x1, #0x1f]
    // 0xc88e2c: DecompressPointer r2
    //     0xc88e2c: add             x2, x2, HEAP, lsl #32
    // 0xc88e30: mov             x3, x2
    // 0xc88e34: ldr             x2, [fp, #0x18]
    // 0xc88e38: stur            x3, [fp, #-0x18]
    // 0xc88e3c: r4 = LoadClassIdInstr(r2)
    //     0xc88e3c: ldur            x4, [x2, #-1]
    //     0xc88e40: ubfx            x4, x4, #0xc, #0x14
    // 0xc88e44: lsl             x4, x4, #1
    // 0xc88e48: stur            x4, [fp, #-0x10]
    // 0xc88e4c: r17 = 5596
    //     0xc88e4c: mov             x17, #0x15dc
    // 0xc88e50: cmp             w4, w17
    // 0xc88e54: b.ne            #0xc88e74
    // 0xc88e58: LoadField: r1 = r2->field_7
    //     0xc88e58: ldur            w1, [x2, #7]
    // 0xc88e5c: DecompressPointer r1
    //     0xc88e5c: add             x1, x1, HEAP, lsl #32
    // 0xc88e60: mov             x16, x2
    // 0xc88e64: mov             x2, x1
    // 0xc88e68: mov             x1, x16
    // 0xc88e6c: mov             x0, x3
    // 0xc88e70: b               #0xc88ef0
    // 0xc88e74: r17 = 5598
    //     0xc88e74: mov             x17, #0x15de
    // 0xc88e78: cmp             w4, w17
    // 0xc88e7c: b.ne            #0xc88ed8
    // 0xc88e80: mov             x1, x2
    // 0xc88e84: LoadField: r0 = r1->field_67
    //     0xc88e84: ldur            w0, [x1, #0x67]
    // 0xc88e88: DecompressPointer r0
    //     0xc88e88: add             x0, x0, HEAP, lsl #32
    // 0xc88e8c: r16 = Sentinel
    //     0xc88e8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc88e90: cmp             w0, w16
    // 0xc88e94: b.ne            #0xc88ea4
    // 0xc88e98: r2 = _colors
    //     0xc88e98: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc88e9c: ldr             x2, [x2, #0x328]
    // 0xc88ea0: r0 = InitLateFinalInstanceField()
    //     0xc88ea0: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc88ea4: LoadField: r1 = r0->field_17
    //     0xc88ea4: ldur            w1, [x0, #0x17]
    // 0xc88ea8: DecompressPointer r1
    //     0xc88ea8: add             x1, x1, HEAP, lsl #32
    // 0xc88eac: cmp             w1, NULL
    // 0xc88eb0: b.ne            #0xc88ec4
    // 0xc88eb4: LoadField: r1 = r0->field_f
    //     0xc88eb4: ldur            w1, [x0, #0xf]
    // 0xc88eb8: DecompressPointer r1
    //     0xc88eb8: add             x1, x1, HEAP, lsl #32
    // 0xc88ebc: mov             x0, x1
    // 0xc88ec0: b               #0xc88ec8
    // 0xc88ec4: mov             x0, x1
    // 0xc88ec8: mov             x2, x0
    // 0xc88ecc: ldr             x1, [fp, #0x18]
    // 0xc88ed0: ldur            x0, [fp, #-0x18]
    // 0xc88ed4: b               #0xc88ef0
    // 0xc88ed8: mov             x1, x2
    // 0xc88edc: LoadField: r0 = r1->field_67
    //     0xc88edc: ldur            w0, [x1, #0x67]
    // 0xc88ee0: DecompressPointer r0
    //     0xc88ee0: add             x0, x0, HEAP, lsl #32
    // 0xc88ee4: LoadField: r2 = r0->field_1f
    //     0xc88ee4: ldur            w2, [x0, #0x1f]
    // 0xc88ee8: DecompressPointer r2
    //     0xc88ee8: add             x2, x2, HEAP, lsl #32
    // 0xc88eec: ldur            x0, [fp, #-0x18]
    // 0xc88ef0: r3 = LoadClassIdInstr(r0)
    //     0xc88ef0: ldur            x3, [x0, #-1]
    //     0xc88ef4: ubfx            x3, x3, #0xc, #0x14
    // 0xc88ef8: stp             x2, x0, [SP, #-0x10]!
    // 0xc88efc: mov             x0, x3
    // 0xc88f00: mov             lr, x0
    // 0xc88f04: ldr             lr, [x21, lr, lsl #3]
    // 0xc88f08: blr             lr
    // 0xc88f0c: add             SP, SP, #0x10
    // 0xc88f10: tbnz            w0, #4, #0xc89ed4
    // 0xc88f14: ldur            x0, [fp, #-8]
    // 0xc88f18: r17 = 5596
    //     0xc88f18: mov             x17, #0x15dc
    // 0xc88f1c: cmp             w0, w17
    // 0xc88f20: b.ne            #0xc88f3c
    // 0xc88f24: ldr             x2, [fp, #0x10]
    // 0xc88f28: LoadField: r1 = r2->field_b
    //     0xc88f28: ldur            w1, [x2, #0xb]
    // 0xc88f2c: DecompressPointer r1
    //     0xc88f2c: add             x1, x1, HEAP, lsl #32
    // 0xc88f30: mov             x3, x1
    // 0xc88f34: mov             x0, x2
    // 0xc88f38: b               #0xc88fb8
    // 0xc88f3c: ldr             x2, [fp, #0x10]
    // 0xc88f40: r17 = 5598
    //     0xc88f40: mov             x17, #0x15de
    // 0xc88f44: cmp             w0, w17
    // 0xc88f48: b.ne            #0xc88fa0
    // 0xc88f4c: mov             x1, x2
    // 0xc88f50: LoadField: r0 = r1->field_67
    //     0xc88f50: ldur            w0, [x1, #0x67]
    // 0xc88f54: DecompressPointer r0
    //     0xc88f54: add             x0, x0, HEAP, lsl #32
    // 0xc88f58: r16 = Sentinel
    //     0xc88f58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc88f5c: cmp             w0, w16
    // 0xc88f60: b.ne            #0xc88f70
    // 0xc88f64: r2 = _colors
    //     0xc88f64: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc88f68: ldr             x2, [x2, #0x328]
    // 0xc88f6c: r0 = InitLateFinalInstanceField()
    //     0xc88f6c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc88f70: LoadField: r1 = r0->field_13
    //     0xc88f70: ldur            w1, [x0, #0x13]
    // 0xc88f74: DecompressPointer r1
    //     0xc88f74: add             x1, x1, HEAP, lsl #32
    // 0xc88f78: cmp             w1, NULL
    // 0xc88f7c: b.ne            #0xc88f90
    // 0xc88f80: LoadField: r1 = r0->field_b
    //     0xc88f80: ldur            w1, [x0, #0xb]
    // 0xc88f84: DecompressPointer r1
    //     0xc88f84: add             x1, x1, HEAP, lsl #32
    // 0xc88f88: mov             x0, x1
    // 0xc88f8c: b               #0xc88f94
    // 0xc88f90: mov             x0, x1
    // 0xc88f94: mov             x3, x0
    // 0xc88f98: ldr             x0, [fp, #0x10]
    // 0xc88f9c: b               #0xc88fb8
    // 0xc88fa0: mov             x0, x2
    // 0xc88fa4: LoadField: r1 = r0->field_67
    //     0xc88fa4: ldur            w1, [x0, #0x67]
    // 0xc88fa8: DecompressPointer r1
    //     0xc88fa8: add             x1, x1, HEAP, lsl #32
    // 0xc88fac: LoadField: r2 = r1->field_1b
    //     0xc88fac: ldur            w2, [x1, #0x1b]
    // 0xc88fb0: DecompressPointer r2
    //     0xc88fb0: add             x2, x2, HEAP, lsl #32
    // 0xc88fb4: mov             x3, x2
    // 0xc88fb8: ldur            x2, [fp, #-0x10]
    // 0xc88fbc: stur            x3, [fp, #-0x18]
    // 0xc88fc0: r17 = 5596
    //     0xc88fc0: mov             x17, #0x15dc
    // 0xc88fc4: cmp             w2, w17
    // 0xc88fc8: b.ne            #0xc88fe8
    // 0xc88fcc: ldr             x4, [fp, #0x18]
    // 0xc88fd0: LoadField: r1 = r4->field_b
    //     0xc88fd0: ldur            w1, [x4, #0xb]
    // 0xc88fd4: DecompressPointer r1
    //     0xc88fd4: add             x1, x1, HEAP, lsl #32
    // 0xc88fd8: mov             x2, x1
    // 0xc88fdc: mov             x1, x4
    // 0xc88fe0: mov             x0, x3
    // 0xc88fe4: b               #0xc89068
    // 0xc88fe8: ldr             x4, [fp, #0x18]
    // 0xc88fec: r17 = 5598
    //     0xc88fec: mov             x17, #0x15de
    // 0xc88ff0: cmp             w2, w17
    // 0xc88ff4: b.ne            #0xc89050
    // 0xc88ff8: mov             x1, x4
    // 0xc88ffc: LoadField: r0 = r1->field_67
    //     0xc88ffc: ldur            w0, [x1, #0x67]
    // 0xc89000: DecompressPointer r0
    //     0xc89000: add             x0, x0, HEAP, lsl #32
    // 0xc89004: r16 = Sentinel
    //     0xc89004: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc89008: cmp             w0, w16
    // 0xc8900c: b.ne            #0xc8901c
    // 0xc89010: r2 = _colors
    //     0xc89010: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc89014: ldr             x2, [x2, #0x328]
    // 0xc89018: r0 = InitLateFinalInstanceField()
    //     0xc89018: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc8901c: LoadField: r1 = r0->field_13
    //     0xc8901c: ldur            w1, [x0, #0x13]
    // 0xc89020: DecompressPointer r1
    //     0xc89020: add             x1, x1, HEAP, lsl #32
    // 0xc89024: cmp             w1, NULL
    // 0xc89028: b.ne            #0xc8903c
    // 0xc8902c: LoadField: r1 = r0->field_b
    //     0xc8902c: ldur            w1, [x0, #0xb]
    // 0xc89030: DecompressPointer r1
    //     0xc89030: add             x1, x1, HEAP, lsl #32
    // 0xc89034: mov             x0, x1
    // 0xc89038: b               #0xc89040
    // 0xc8903c: mov             x0, x1
    // 0xc89040: mov             x2, x0
    // 0xc89044: ldr             x1, [fp, #0x18]
    // 0xc89048: ldur            x0, [fp, #-0x18]
    // 0xc8904c: b               #0xc89068
    // 0xc89050: mov             x1, x4
    // 0xc89054: LoadField: r0 = r1->field_67
    //     0xc89054: ldur            w0, [x1, #0x67]
    // 0xc89058: DecompressPointer r0
    //     0xc89058: add             x0, x0, HEAP, lsl #32
    // 0xc8905c: LoadField: r2 = r0->field_1b
    //     0xc8905c: ldur            w2, [x0, #0x1b]
    // 0xc89060: DecompressPointer r2
    //     0xc89060: add             x2, x2, HEAP, lsl #32
    // 0xc89064: ldur            x0, [fp, #-0x18]
    // 0xc89068: r3 = LoadClassIdInstr(r0)
    //     0xc89068: ldur            x3, [x0, #-1]
    //     0xc8906c: ubfx            x3, x3, #0xc, #0x14
    // 0xc89070: stp             x2, x0, [SP, #-0x10]!
    // 0xc89074: mov             x0, x3
    // 0xc89078: mov             lr, x0
    // 0xc8907c: ldr             lr, [x21, lr, lsl #3]
    // 0xc89080: blr             lr
    // 0xc89084: add             SP, SP, #0x10
    // 0xc89088: tbnz            w0, #4, #0xc89ed4
    // 0xc8908c: ldur            x0, [fp, #-8]
    // 0xc89090: r17 = 5596
    //     0xc89090: mov             x17, #0x15dc
    // 0xc89094: cmp             w0, w17
    // 0xc89098: b.ne            #0xc890b4
    // 0xc8909c: ldr             x2, [fp, #0x10]
    // 0xc890a0: LoadField: r1 = r2->field_f
    //     0xc890a0: ldur            w1, [x2, #0xf]
    // 0xc890a4: DecompressPointer r1
    //     0xc890a4: add             x1, x1, HEAP, lsl #32
    // 0xc890a8: mov             x3, x1
    // 0xc890ac: mov             x0, x2
    // 0xc890b0: b               #0xc89148
    // 0xc890b4: ldr             x2, [fp, #0x10]
    // 0xc890b8: r17 = 5598
    //     0xc890b8: mov             x17, #0x15de
    // 0xc890bc: cmp             w0, w17
    // 0xc890c0: b.ne            #0xc89130
    // 0xc890c4: mov             x1, x2
    // 0xc890c8: LoadField: r0 = r1->field_67
    //     0xc890c8: ldur            w0, [x1, #0x67]
    // 0xc890cc: DecompressPointer r0
    //     0xc890cc: add             x0, x0, HEAP, lsl #32
    // 0xc890d0: r16 = Sentinel
    //     0xc890d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc890d4: cmp             w0, w16
    // 0xc890d8: b.ne            #0xc890e8
    // 0xc890dc: r2 = _colors
    //     0xc890dc: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc890e0: ldr             x2, [x2, #0x328]
    // 0xc890e4: r0 = InitLateFinalInstanceField()
    //     0xc890e4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc890e8: LoadField: r1 = r0->field_17
    //     0xc890e8: ldur            w1, [x0, #0x17]
    // 0xc890ec: DecompressPointer r1
    //     0xc890ec: add             x1, x1, HEAP, lsl #32
    // 0xc890f0: cmp             w1, NULL
    // 0xc890f4: b.ne            #0xc89108
    // 0xc890f8: LoadField: r1 = r0->field_f
    //     0xc890f8: ldur            w1, [x0, #0xf]
    // 0xc890fc: DecompressPointer r1
    //     0xc890fc: add             x1, x1, HEAP, lsl #32
    // 0xc89100: mov             x0, x1
    // 0xc89104: b               #0xc8910c
    // 0xc89108: mov             x0, x1
    // 0xc8910c: d0 = 0.120000
    //     0xc8910c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc89110: ldr             d0, [x17, #0xf48]
    // 0xc89114: SaveReg r0
    //     0xc89114: str             x0, [SP, #-8]!
    // 0xc89118: SaveReg d0
    //     0xc89118: str             d0, [SP, #-8]!
    // 0xc8911c: r0 = withOpacity()
    //     0xc8911c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc89120: add             SP, SP, #0x10
    // 0xc89124: mov             x3, x0
    // 0xc89128: ldr             x0, [fp, #0x10]
    // 0xc8912c: b               #0xc89148
    // 0xc89130: mov             x0, x2
    // 0xc89134: LoadField: r1 = r0->field_63
    //     0xc89134: ldur            w1, [x0, #0x63]
    // 0xc89138: DecompressPointer r1
    //     0xc89138: add             x1, x1, HEAP, lsl #32
    // 0xc8913c: LoadField: r2 = r1->field_4f
    //     0xc8913c: ldur            w2, [x1, #0x4f]
    // 0xc89140: DecompressPointer r2
    //     0xc89140: add             x2, x2, HEAP, lsl #32
    // 0xc89144: mov             x3, x2
    // 0xc89148: ldur            x2, [fp, #-0x10]
    // 0xc8914c: stur            x3, [fp, #-0x18]
    // 0xc89150: r17 = 5596
    //     0xc89150: mov             x17, #0x15dc
    // 0xc89154: cmp             w2, w17
    // 0xc89158: b.ne            #0xc89178
    // 0xc8915c: ldr             x4, [fp, #0x18]
    // 0xc89160: LoadField: r1 = r4->field_f
    //     0xc89160: ldur            w1, [x4, #0xf]
    // 0xc89164: DecompressPointer r1
    //     0xc89164: add             x1, x1, HEAP, lsl #32
    // 0xc89168: mov             x2, x1
    // 0xc8916c: mov             x1, x4
    // 0xc89170: mov             x0, x3
    // 0xc89174: b               #0xc89210
    // 0xc89178: ldr             x4, [fp, #0x18]
    // 0xc8917c: r17 = 5598
    //     0xc8917c: mov             x17, #0x15de
    // 0xc89180: cmp             w2, w17
    // 0xc89184: b.ne            #0xc891f8
    // 0xc89188: mov             x1, x4
    // 0xc8918c: LoadField: r0 = r1->field_67
    //     0xc8918c: ldur            w0, [x1, #0x67]
    // 0xc89190: DecompressPointer r0
    //     0xc89190: add             x0, x0, HEAP, lsl #32
    // 0xc89194: r16 = Sentinel
    //     0xc89194: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc89198: cmp             w0, w16
    // 0xc8919c: b.ne            #0xc891ac
    // 0xc891a0: r2 = _colors
    //     0xc891a0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc891a4: ldr             x2, [x2, #0x328]
    // 0xc891a8: r0 = InitLateFinalInstanceField()
    //     0xc891a8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc891ac: LoadField: r1 = r0->field_17
    //     0xc891ac: ldur            w1, [x0, #0x17]
    // 0xc891b0: DecompressPointer r1
    //     0xc891b0: add             x1, x1, HEAP, lsl #32
    // 0xc891b4: cmp             w1, NULL
    // 0xc891b8: b.ne            #0xc891cc
    // 0xc891bc: LoadField: r1 = r0->field_f
    //     0xc891bc: ldur            w1, [x0, #0xf]
    // 0xc891c0: DecompressPointer r1
    //     0xc891c0: add             x1, x1, HEAP, lsl #32
    // 0xc891c4: mov             x0, x1
    // 0xc891c8: b               #0xc891d0
    // 0xc891cc: mov             x0, x1
    // 0xc891d0: d0 = 0.120000
    //     0xc891d0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc891d4: ldr             d0, [x17, #0xf48]
    // 0xc891d8: SaveReg r0
    //     0xc891d8: str             x0, [SP, #-8]!
    // 0xc891dc: SaveReg d0
    //     0xc891dc: str             d0, [SP, #-8]!
    // 0xc891e0: r0 = withOpacity()
    //     0xc891e0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc891e4: add             SP, SP, #0x10
    // 0xc891e8: mov             x2, x0
    // 0xc891ec: ldr             x1, [fp, #0x18]
    // 0xc891f0: ldur            x0, [fp, #-0x18]
    // 0xc891f4: b               #0xc89210
    // 0xc891f8: mov             x1, x4
    // 0xc891fc: LoadField: r0 = r1->field_63
    //     0xc891fc: ldur            w0, [x1, #0x63]
    // 0xc89200: DecompressPointer r0
    //     0xc89200: add             x0, x0, HEAP, lsl #32
    // 0xc89204: LoadField: r2 = r0->field_4f
    //     0xc89204: ldur            w2, [x0, #0x4f]
    // 0xc89208: DecompressPointer r2
    //     0xc89208: add             x2, x2, HEAP, lsl #32
    // 0xc8920c: ldur            x0, [fp, #-0x18]
    // 0xc89210: r3 = LoadClassIdInstr(r0)
    //     0xc89210: ldur            x3, [x0, #-1]
    //     0xc89214: ubfx            x3, x3, #0xc, #0x14
    // 0xc89218: stp             x2, x0, [SP, #-0x10]!
    // 0xc8921c: mov             x0, x3
    // 0xc89220: mov             lr, x0
    // 0xc89224: ldr             lr, [x21, lr, lsl #3]
    // 0xc89228: blr             lr
    // 0xc8922c: add             SP, SP, #0x10
    // 0xc89230: tbnz            w0, #4, #0xc89ed4
    // 0xc89234: ldur            x0, [fp, #-8]
    // 0xc89238: r17 = 5596
    //     0xc89238: mov             x17, #0x15dc
    // 0xc8923c: cmp             w0, w17
    // 0xc89240: b.ne            #0xc8925c
    // 0xc89244: ldr             x2, [fp, #0x10]
    // 0xc89248: LoadField: r1 = r2->field_13
    //     0xc89248: ldur            w1, [x2, #0x13]
    // 0xc8924c: DecompressPointer r1
    //     0xc8924c: add             x1, x1, HEAP, lsl #32
    // 0xc89250: mov             x3, x1
    // 0xc89254: mov             x0, x2
    // 0xc89258: b               #0xc892f0
    // 0xc8925c: ldr             x2, [fp, #0x10]
    // 0xc89260: r17 = 5598
    //     0xc89260: mov             x17, #0x15de
    // 0xc89264: cmp             w0, w17
    // 0xc89268: b.ne            #0xc892d8
    // 0xc8926c: mov             x1, x2
    // 0xc89270: LoadField: r0 = r1->field_67
    //     0xc89270: ldur            w0, [x1, #0x67]
    // 0xc89274: DecompressPointer r0
    //     0xc89274: add             x0, x0, HEAP, lsl #32
    // 0xc89278: r16 = Sentinel
    //     0xc89278: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc8927c: cmp             w0, w16
    // 0xc89280: b.ne            #0xc89290
    // 0xc89284: r2 = _colors
    //     0xc89284: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc89288: ldr             x2, [x2, #0x328]
    // 0xc8928c: r0 = InitLateFinalInstanceField()
    //     0xc8928c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc89290: LoadField: r1 = r0->field_17
    //     0xc89290: ldur            w1, [x0, #0x17]
    // 0xc89294: DecompressPointer r1
    //     0xc89294: add             x1, x1, HEAP, lsl #32
    // 0xc89298: cmp             w1, NULL
    // 0xc8929c: b.ne            #0xc892b0
    // 0xc892a0: LoadField: r1 = r0->field_f
    //     0xc892a0: ldur            w1, [x0, #0xf]
    // 0xc892a4: DecompressPointer r1
    //     0xc892a4: add             x1, x1, HEAP, lsl #32
    // 0xc892a8: mov             x0, x1
    // 0xc892ac: b               #0xc892b4
    // 0xc892b0: mov             x0, x1
    // 0xc892b4: d0 = 0.080000
    //     0xc892b4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xc892b8: ldr             d0, [x17, #0xf80]
    // 0xc892bc: SaveReg r0
    //     0xc892bc: str             x0, [SP, #-8]!
    // 0xc892c0: SaveReg d0
    //     0xc892c0: str             d0, [SP, #-8]!
    // 0xc892c4: r0 = withOpacity()
    //     0xc892c4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc892c8: add             SP, SP, #0x10
    // 0xc892cc: mov             x3, x0
    // 0xc892d0: ldr             x0, [fp, #0x10]
    // 0xc892d4: b               #0xc892f0
    // 0xc892d8: mov             x0, x2
    // 0xc892dc: LoadField: r1 = r0->field_63
    //     0xc892dc: ldur            w1, [x0, #0x63]
    // 0xc892e0: DecompressPointer r1
    //     0xc892e0: add             x1, x1, HEAP, lsl #32
    // 0xc892e4: LoadField: r2 = r1->field_5b
    //     0xc892e4: ldur            w2, [x1, #0x5b]
    // 0xc892e8: DecompressPointer r2
    //     0xc892e8: add             x2, x2, HEAP, lsl #32
    // 0xc892ec: mov             x3, x2
    // 0xc892f0: ldur            x2, [fp, #-0x10]
    // 0xc892f4: stur            x3, [fp, #-0x18]
    // 0xc892f8: r17 = 5596
    //     0xc892f8: mov             x17, #0x15dc
    // 0xc892fc: cmp             w2, w17
    // 0xc89300: b.ne            #0xc89320
    // 0xc89304: ldr             x4, [fp, #0x18]
    // 0xc89308: LoadField: r1 = r4->field_13
    //     0xc89308: ldur            w1, [x4, #0x13]
    // 0xc8930c: DecompressPointer r1
    //     0xc8930c: add             x1, x1, HEAP, lsl #32
    // 0xc89310: mov             x2, x1
    // 0xc89314: mov             x1, x4
    // 0xc89318: mov             x0, x3
    // 0xc8931c: b               #0xc893b8
    // 0xc89320: ldr             x4, [fp, #0x18]
    // 0xc89324: r17 = 5598
    //     0xc89324: mov             x17, #0x15de
    // 0xc89328: cmp             w2, w17
    // 0xc8932c: b.ne            #0xc893a0
    // 0xc89330: mov             x1, x4
    // 0xc89334: LoadField: r0 = r1->field_67
    //     0xc89334: ldur            w0, [x1, #0x67]
    // 0xc89338: DecompressPointer r0
    //     0xc89338: add             x0, x0, HEAP, lsl #32
    // 0xc8933c: r16 = Sentinel
    //     0xc8933c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc89340: cmp             w0, w16
    // 0xc89344: b.ne            #0xc89354
    // 0xc89348: r2 = _colors
    //     0xc89348: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc8934c: ldr             x2, [x2, #0x328]
    // 0xc89350: r0 = InitLateFinalInstanceField()
    //     0xc89350: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc89354: LoadField: r1 = r0->field_17
    //     0xc89354: ldur            w1, [x0, #0x17]
    // 0xc89358: DecompressPointer r1
    //     0xc89358: add             x1, x1, HEAP, lsl #32
    // 0xc8935c: cmp             w1, NULL
    // 0xc89360: b.ne            #0xc89374
    // 0xc89364: LoadField: r1 = r0->field_f
    //     0xc89364: ldur            w1, [x0, #0xf]
    // 0xc89368: DecompressPointer r1
    //     0xc89368: add             x1, x1, HEAP, lsl #32
    // 0xc8936c: mov             x0, x1
    // 0xc89370: b               #0xc89378
    // 0xc89374: mov             x0, x1
    // 0xc89378: d0 = 0.080000
    //     0xc89378: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xc8937c: ldr             d0, [x17, #0xf80]
    // 0xc89380: SaveReg r0
    //     0xc89380: str             x0, [SP, #-8]!
    // 0xc89384: SaveReg d0
    //     0xc89384: str             d0, [SP, #-8]!
    // 0xc89388: r0 = withOpacity()
    //     0xc89388: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8938c: add             SP, SP, #0x10
    // 0xc89390: mov             x2, x0
    // 0xc89394: ldr             x1, [fp, #0x18]
    // 0xc89398: ldur            x0, [fp, #-0x18]
    // 0xc8939c: b               #0xc893b8
    // 0xc893a0: mov             x1, x4
    // 0xc893a4: LoadField: r0 = r1->field_63
    //     0xc893a4: ldur            w0, [x1, #0x63]
    // 0xc893a8: DecompressPointer r0
    //     0xc893a8: add             x0, x0, HEAP, lsl #32
    // 0xc893ac: LoadField: r2 = r0->field_5b
    //     0xc893ac: ldur            w2, [x0, #0x5b]
    // 0xc893b0: DecompressPointer r2
    //     0xc893b0: add             x2, x2, HEAP, lsl #32
    // 0xc893b4: ldur            x0, [fp, #-0x18]
    // 0xc893b8: r3 = LoadClassIdInstr(r0)
    //     0xc893b8: ldur            x3, [x0, #-1]
    //     0xc893bc: ubfx            x3, x3, #0xc, #0x14
    // 0xc893c0: stp             x2, x0, [SP, #-0x10]!
    // 0xc893c4: mov             x0, x3
    // 0xc893c8: mov             lr, x0
    // 0xc893cc: ldr             lr, [x21, lr, lsl #3]
    // 0xc893d0: blr             lr
    // 0xc893d4: add             SP, SP, #0x10
    // 0xc893d8: tbnz            w0, #4, #0xc89ed4
    // 0xc893dc: ldur            x0, [fp, #-8]
    // 0xc893e0: r17 = 5596
    //     0xc893e0: mov             x17, #0x15dc
    // 0xc893e4: cmp             w0, w17
    // 0xc893e8: b.ne            #0xc89404
    // 0xc893ec: ldr             x2, [fp, #0x10]
    // 0xc893f0: LoadField: r1 = r2->field_17
    //     0xc893f0: ldur            w1, [x2, #0x17]
    // 0xc893f4: DecompressPointer r1
    //     0xc893f4: add             x1, x1, HEAP, lsl #32
    // 0xc893f8: mov             x3, x1
    // 0xc893fc: mov             x0, x2
    // 0xc89400: b               #0xc89498
    // 0xc89404: ldr             x2, [fp, #0x10]
    // 0xc89408: r17 = 5598
    //     0xc89408: mov             x17, #0x15de
    // 0xc8940c: cmp             w0, w17
    // 0xc89410: b.ne            #0xc89480
    // 0xc89414: mov             x1, x2
    // 0xc89418: LoadField: r0 = r1->field_67
    //     0xc89418: ldur            w0, [x1, #0x67]
    // 0xc8941c: DecompressPointer r0
    //     0xc8941c: add             x0, x0, HEAP, lsl #32
    // 0xc89420: r16 = Sentinel
    //     0xc89420: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc89424: cmp             w0, w16
    // 0xc89428: b.ne            #0xc89438
    // 0xc8942c: r2 = _colors
    //     0xc8942c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc89430: ldr             x2, [x2, #0x328]
    // 0xc89434: r0 = InitLateFinalInstanceField()
    //     0xc89434: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc89438: LoadField: r1 = r0->field_17
    //     0xc89438: ldur            w1, [x0, #0x17]
    // 0xc8943c: DecompressPointer r1
    //     0xc8943c: add             x1, x1, HEAP, lsl #32
    // 0xc89440: cmp             w1, NULL
    // 0xc89444: b.ne            #0xc89458
    // 0xc89448: LoadField: r1 = r0->field_f
    //     0xc89448: ldur            w1, [x0, #0xf]
    // 0xc8944c: DecompressPointer r1
    //     0xc8944c: add             x1, x1, HEAP, lsl #32
    // 0xc89450: mov             x0, x1
    // 0xc89454: b               #0xc8945c
    // 0xc89458: mov             x0, x1
    // 0xc8945c: d0 = 0.120000
    //     0xc8945c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc89460: ldr             d0, [x17, #0xf48]
    // 0xc89464: SaveReg r0
    //     0xc89464: str             x0, [SP, #-8]!
    // 0xc89468: SaveReg d0
    //     0xc89468: str             d0, [SP, #-8]!
    // 0xc8946c: r0 = withOpacity()
    //     0xc8946c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc89470: add             SP, SP, #0x10
    // 0xc89474: mov             x3, x0
    // 0xc89478: ldr             x0, [fp, #0x10]
    // 0xc8947c: b               #0xc89498
    // 0xc89480: mov             x0, x2
    // 0xc89484: LoadField: r1 = r0->field_63
    //     0xc89484: ldur            w1, [x0, #0x63]
    // 0xc89488: DecompressPointer r1
    //     0xc89488: add             x1, x1, HEAP, lsl #32
    // 0xc8948c: LoadField: r2 = r1->field_7f
    //     0xc8948c: ldur            w2, [x1, #0x7f]
    // 0xc89490: DecompressPointer r2
    //     0xc89490: add             x2, x2, HEAP, lsl #32
    // 0xc89494: mov             x3, x2
    // 0xc89498: ldur            x2, [fp, #-0x10]
    // 0xc8949c: stur            x3, [fp, #-0x18]
    // 0xc894a0: r17 = 5596
    //     0xc894a0: mov             x17, #0x15dc
    // 0xc894a4: cmp             w2, w17
    // 0xc894a8: b.ne            #0xc894c8
    // 0xc894ac: ldr             x4, [fp, #0x18]
    // 0xc894b0: LoadField: r1 = r4->field_17
    //     0xc894b0: ldur            w1, [x4, #0x17]
    // 0xc894b4: DecompressPointer r1
    //     0xc894b4: add             x1, x1, HEAP, lsl #32
    // 0xc894b8: mov             x2, x1
    // 0xc894bc: mov             x1, x4
    // 0xc894c0: mov             x0, x3
    // 0xc894c4: b               #0xc89560
    // 0xc894c8: ldr             x4, [fp, #0x18]
    // 0xc894cc: r17 = 5598
    //     0xc894cc: mov             x17, #0x15de
    // 0xc894d0: cmp             w2, w17
    // 0xc894d4: b.ne            #0xc89548
    // 0xc894d8: mov             x1, x4
    // 0xc894dc: LoadField: r0 = r1->field_67
    //     0xc894dc: ldur            w0, [x1, #0x67]
    // 0xc894e0: DecompressPointer r0
    //     0xc894e0: add             x0, x0, HEAP, lsl #32
    // 0xc894e4: r16 = Sentinel
    //     0xc894e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc894e8: cmp             w0, w16
    // 0xc894ec: b.ne            #0xc894fc
    // 0xc894f0: r2 = _colors
    //     0xc894f0: add             x2, PP, #0xe, lsl #12  ; [pp+0xe328] Field <_FABDefaultsM3@746192485._colors@746192485>: late final (offset: 0x68)
    //     0xc894f4: ldr             x2, [x2, #0x328]
    // 0xc894f8: r0 = InitLateFinalInstanceField()
    //     0xc894f8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc894fc: LoadField: r1 = r0->field_17
    //     0xc894fc: ldur            w1, [x0, #0x17]
    // 0xc89500: DecompressPointer r1
    //     0xc89500: add             x1, x1, HEAP, lsl #32
    // 0xc89504: cmp             w1, NULL
    // 0xc89508: b.ne            #0xc8951c
    // 0xc8950c: LoadField: r1 = r0->field_f
    //     0xc8950c: ldur            w1, [x0, #0xf]
    // 0xc89510: DecompressPointer r1
    //     0xc89510: add             x1, x1, HEAP, lsl #32
    // 0xc89514: mov             x0, x1
    // 0xc89518: b               #0xc89520
    // 0xc8951c: mov             x0, x1
    // 0xc89520: d0 = 0.120000
    //     0xc89520: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc89524: ldr             d0, [x17, #0xf48]
    // 0xc89528: SaveReg r0
    //     0xc89528: str             x0, [SP, #-8]!
    // 0xc8952c: SaveReg d0
    //     0xc8952c: str             d0, [SP, #-8]!
    // 0xc89530: r0 = withOpacity()
    //     0xc89530: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc89534: add             SP, SP, #0x10
    // 0xc89538: mov             x2, x0
    // 0xc8953c: ldr             x1, [fp, #0x18]
    // 0xc89540: ldur            x0, [fp, #-0x18]
    // 0xc89544: b               #0xc89560
    // 0xc89548: mov             x1, x4
    // 0xc8954c: LoadField: r0 = r1->field_63
    //     0xc8954c: ldur            w0, [x1, #0x63]
    // 0xc89550: DecompressPointer r0
    //     0xc89550: add             x0, x0, HEAP, lsl #32
    // 0xc89554: LoadField: r2 = r0->field_7f
    //     0xc89554: ldur            w2, [x0, #0x7f]
    // 0xc89558: DecompressPointer r2
    //     0xc89558: add             x2, x2, HEAP, lsl #32
    // 0xc8955c: ldur            x0, [fp, #-0x18]
    // 0xc89560: r3 = LoadClassIdInstr(r0)
    //     0xc89560: ldur            x3, [x0, #-1]
    //     0xc89564: ubfx            x3, x3, #0xc, #0x14
    // 0xc89568: stp             x2, x0, [SP, #-0x10]!
    // 0xc8956c: mov             x0, x3
    // 0xc89570: mov             lr, x0
    // 0xc89574: ldr             lr, [x21, lr, lsl #3]
    // 0xc89578: blr             lr
    // 0xc8957c: add             SP, SP, #0x10
    // 0xc89580: tbnz            w0, #4, #0xc89ed4
    // 0xc89584: ldr             x1, [fp, #0x18]
    // 0xc89588: ldr             x2, [fp, #0x10]
    // 0xc8958c: LoadField: r0 = r2->field_1b
    //     0xc8958c: ldur            w0, [x2, #0x1b]
    // 0xc89590: DecompressPointer r0
    //     0xc89590: add             x0, x0, HEAP, lsl #32
    // 0xc89594: LoadField: r3 = r1->field_1b
    //     0xc89594: ldur            w3, [x1, #0x1b]
    // 0xc89598: DecompressPointer r3
    //     0xc89598: add             x3, x3, HEAP, lsl #32
    // 0xc8959c: r4 = LoadClassIdInstr(r0)
    //     0xc8959c: ldur            x4, [x0, #-1]
    //     0xc895a0: ubfx            x4, x4, #0xc, #0x14
    // 0xc895a4: stp             x3, x0, [SP, #-0x10]!
    // 0xc895a8: mov             x0, x4
    // 0xc895ac: mov             lr, x0
    // 0xc895b0: ldr             lr, [x21, lr, lsl #3]
    // 0xc895b4: blr             lr
    // 0xc895b8: add             SP, SP, #0x10
    // 0xc895bc: tbnz            w0, #4, #0xc89ed4
    // 0xc895c0: ldr             x1, [fp, #0x18]
    // 0xc895c4: ldr             x2, [fp, #0x10]
    // 0xc895c8: LoadField: r0 = r2->field_1f
    //     0xc895c8: ldur            w0, [x2, #0x1f]
    // 0xc895cc: DecompressPointer r0
    //     0xc895cc: add             x0, x0, HEAP, lsl #32
    // 0xc895d0: LoadField: r3 = r1->field_1f
    //     0xc895d0: ldur            w3, [x1, #0x1f]
    // 0xc895d4: DecompressPointer r3
    //     0xc895d4: add             x3, x3, HEAP, lsl #32
    // 0xc895d8: r4 = LoadClassIdInstr(r0)
    //     0xc895d8: ldur            x4, [x0, #-1]
    //     0xc895dc: ubfx            x4, x4, #0xc, #0x14
    // 0xc895e0: stp             x3, x0, [SP, #-0x10]!
    // 0xc895e4: mov             x0, x4
    // 0xc895e8: mov             lr, x0
    // 0xc895ec: ldr             lr, [x21, lr, lsl #3]
    // 0xc895f0: blr             lr
    // 0xc895f4: add             SP, SP, #0x10
    // 0xc895f8: tbnz            w0, #4, #0xc89ed4
    // 0xc895fc: ldr             x1, [fp, #0x18]
    // 0xc89600: ldr             x2, [fp, #0x10]
    // 0xc89604: LoadField: r0 = r2->field_23
    //     0xc89604: ldur            w0, [x2, #0x23]
    // 0xc89608: DecompressPointer r0
    //     0xc89608: add             x0, x0, HEAP, lsl #32
    // 0xc8960c: LoadField: r3 = r1->field_23
    //     0xc8960c: ldur            w3, [x1, #0x23]
    // 0xc89610: DecompressPointer r3
    //     0xc89610: add             x3, x3, HEAP, lsl #32
    // 0xc89614: r4 = LoadClassIdInstr(r0)
    //     0xc89614: ldur            x4, [x0, #-1]
    //     0xc89618: ubfx            x4, x4, #0xc, #0x14
    // 0xc8961c: stp             x3, x0, [SP, #-0x10]!
    // 0xc89620: mov             x0, x4
    // 0xc89624: mov             lr, x0
    // 0xc89628: ldr             lr, [x21, lr, lsl #3]
    // 0xc8962c: blr             lr
    // 0xc89630: add             SP, SP, #0x10
    // 0xc89634: tbnz            w0, #4, #0xc89ed4
    // 0xc89638: ldr             x1, [fp, #0x18]
    // 0xc8963c: ldr             x2, [fp, #0x10]
    // 0xc89640: LoadField: r0 = r2->field_27
    //     0xc89640: ldur            w0, [x2, #0x27]
    // 0xc89644: DecompressPointer r0
    //     0xc89644: add             x0, x0, HEAP, lsl #32
    // 0xc89648: LoadField: r3 = r1->field_27
    //     0xc89648: ldur            w3, [x1, #0x27]
    // 0xc8964c: DecompressPointer r3
    //     0xc8964c: add             x3, x3, HEAP, lsl #32
    // 0xc89650: r4 = LoadClassIdInstr(r0)
    //     0xc89650: ldur            x4, [x0, #-1]
    //     0xc89654: ubfx            x4, x4, #0xc, #0x14
    // 0xc89658: stp             x3, x0, [SP, #-0x10]!
    // 0xc8965c: mov             x0, x4
    // 0xc89660: mov             lr, x0
    // 0xc89664: ldr             lr, [x21, lr, lsl #3]
    // 0xc89668: blr             lr
    // 0xc8966c: add             SP, SP, #0x10
    // 0xc89670: tbnz            w0, #4, #0xc89ed4
    // 0xc89674: ldr             x1, [fp, #0x18]
    // 0xc89678: ldr             x2, [fp, #0x10]
    // 0xc8967c: LoadField: r0 = r2->field_2b
    //     0xc8967c: ldur            w0, [x2, #0x2b]
    // 0xc89680: DecompressPointer r0
    //     0xc89680: add             x0, x0, HEAP, lsl #32
    // 0xc89684: LoadField: r3 = r1->field_2b
    //     0xc89684: ldur            w3, [x1, #0x2b]
    // 0xc89688: DecompressPointer r3
    //     0xc89688: add             x3, x3, HEAP, lsl #32
    // 0xc8968c: r4 = LoadClassIdInstr(r0)
    //     0xc8968c: ldur            x4, [x0, #-1]
    //     0xc89690: ubfx            x4, x4, #0xc, #0x14
    // 0xc89694: stp             x3, x0, [SP, #-0x10]!
    // 0xc89698: mov             x0, x4
    // 0xc8969c: mov             lr, x0
    // 0xc896a0: ldr             lr, [x21, lr, lsl #3]
    // 0xc896a4: blr             lr
    // 0xc896a8: add             SP, SP, #0x10
    // 0xc896ac: tbnz            w0, #4, #0xc89ed4
    // 0xc896b0: ldur            x1, [fp, #-8]
    // 0xc896b4: r17 = 5596
    //     0xc896b4: mov             x17, #0x15dc
    // 0xc896b8: cmp             w1, w17
    // 0xc896bc: b.ne            #0xc896d0
    // 0xc896c0: ldr             x2, [fp, #0x10]
    // 0xc896c4: LoadField: r0 = r2->field_2f
    //     0xc896c4: ldur            w0, [x2, #0x2f]
    // 0xc896c8: DecompressPointer r0
    //     0xc896c8: add             x0, x0, HEAP, lsl #32
    // 0xc896cc: b               #0xc89760
    // 0xc896d0: ldr             x2, [fp, #0x10]
    // 0xc896d4: r17 = 5598
    //     0xc896d4: mov             x17, #0x15de
    // 0xc896d8: cmp             w1, w17
    // 0xc896dc: b.ne            #0xc89734
    // 0xc896e0: LoadField: r0 = r2->field_5f
    //     0xc896e0: ldur            w0, [x2, #0x5f]
    // 0xc896e4: DecompressPointer r0
    //     0xc896e4: add             x0, x0, HEAP, lsl #32
    // 0xc896e8: LoadField: r3 = r0->field_7
    //     0xc896e8: ldur            x3, [x0, #7]
    // 0xc896ec: cmp             x3, #1
    // 0xc896f0: b.gt            #0xc89714
    // 0xc896f4: cmp             x3, #0
    // 0xc896f8: b.gt            #0xc89708
    // 0xc896fc: r0 = Instance_RoundedRectangleBorder
    //     0xc896fc: add             x0, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xc89700: ldr             x0, [x0, #0x330]
    // 0xc89704: b               #0xc89760
    // 0xc89708: r0 = Instance_RoundedRectangleBorder
    //     0xc89708: add             x0, PP, #0xe, lsl #12  ; [pp+0xe338] Obj!RoundedRectangleBorder@b38421
    //     0xc8970c: ldr             x0, [x0, #0x338]
    // 0xc89710: b               #0xc89760
    // 0xc89714: cmp             x3, #2
    // 0xc89718: b.gt            #0xc89728
    // 0xc8971c: r0 = Instance_RoundedRectangleBorder
    //     0xc8971c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe340] Obj!RoundedRectangleBorder@b38411
    //     0xc89720: ldr             x0, [x0, #0x340]
    // 0xc89724: b               #0xc89760
    // 0xc89728: r0 = Instance_RoundedRectangleBorder
    //     0xc89728: add             x0, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xc8972c: ldr             x0, [x0, #0x330]
    // 0xc89730: b               #0xc89760
    // 0xc89734: LoadField: r0 = r2->field_5b
    //     0xc89734: ldur            w0, [x2, #0x5b]
    // 0xc89738: DecompressPointer r0
    //     0xc89738: add             x0, x0, HEAP, lsl #32
    // 0xc8973c: r16 = Instance__FloatingActionButtonType
    //     0xc8973c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xc89740: ldr             x16, [x16, #0x348]
    // 0xc89744: cmp             w0, w16
    // 0xc89748: b.ne            #0xc89758
    // 0xc8974c: r0 = Instance_StadiumBorder
    //     0xc8974c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe350] Obj!StadiumBorder@b383b1
    //     0xc89750: ldr             x0, [x0, #0x350]
    // 0xc89754: b               #0xc89760
    // 0xc89758: r0 = Instance_CircleBorder
    //     0xc89758: add             x0, PP, #0xe, lsl #12  ; [pp+0xe358] Obj!CircleBorder@b38441
    //     0xc8975c: ldr             x0, [x0, #0x358]
    // 0xc89760: ldur            x3, [fp, #-0x10]
    // 0xc89764: r17 = 5596
    //     0xc89764: mov             x17, #0x15dc
    // 0xc89768: cmp             w3, w17
    // 0xc8976c: b.ne            #0xc89780
    // 0xc89770: ldr             x4, [fp, #0x18]
    // 0xc89774: LoadField: r5 = r4->field_2f
    //     0xc89774: ldur            w5, [x4, #0x2f]
    // 0xc89778: DecompressPointer r5
    //     0xc89778: add             x5, x5, HEAP, lsl #32
    // 0xc8977c: b               #0xc89810
    // 0xc89780: ldr             x4, [fp, #0x18]
    // 0xc89784: r17 = 5598
    //     0xc89784: mov             x17, #0x15de
    // 0xc89788: cmp             w3, w17
    // 0xc8978c: b.ne            #0xc897e4
    // 0xc89790: LoadField: r5 = r4->field_5f
    //     0xc89790: ldur            w5, [x4, #0x5f]
    // 0xc89794: DecompressPointer r5
    //     0xc89794: add             x5, x5, HEAP, lsl #32
    // 0xc89798: LoadField: r6 = r5->field_7
    //     0xc89798: ldur            x6, [x5, #7]
    // 0xc8979c: cmp             x6, #1
    // 0xc897a0: b.gt            #0xc897c4
    // 0xc897a4: cmp             x6, #0
    // 0xc897a8: b.gt            #0xc897b8
    // 0xc897ac: r5 = Instance_RoundedRectangleBorder
    //     0xc897ac: add             x5, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xc897b0: ldr             x5, [x5, #0x330]
    // 0xc897b4: b               #0xc89810
    // 0xc897b8: r5 = Instance_RoundedRectangleBorder
    //     0xc897b8: add             x5, PP, #0xe, lsl #12  ; [pp+0xe338] Obj!RoundedRectangleBorder@b38421
    //     0xc897bc: ldr             x5, [x5, #0x338]
    // 0xc897c0: b               #0xc89810
    // 0xc897c4: cmp             x6, #2
    // 0xc897c8: b.gt            #0xc897d8
    // 0xc897cc: r5 = Instance_RoundedRectangleBorder
    //     0xc897cc: add             x5, PP, #0xe, lsl #12  ; [pp+0xe340] Obj!RoundedRectangleBorder@b38411
    //     0xc897d0: ldr             x5, [x5, #0x340]
    // 0xc897d4: b               #0xc89810
    // 0xc897d8: r5 = Instance_RoundedRectangleBorder
    //     0xc897d8: add             x5, PP, #0xe, lsl #12  ; [pp+0xe330] Obj!RoundedRectangleBorder@b38431
    //     0xc897dc: ldr             x5, [x5, #0x330]
    // 0xc897e0: b               #0xc89810
    // 0xc897e4: LoadField: r5 = r4->field_5b
    //     0xc897e4: ldur            w5, [x4, #0x5b]
    // 0xc897e8: DecompressPointer r5
    //     0xc897e8: add             x5, x5, HEAP, lsl #32
    // 0xc897ec: r16 = Instance__FloatingActionButtonType
    //     0xc897ec: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xc897f0: ldr             x16, [x16, #0x348]
    // 0xc897f4: cmp             w5, w16
    // 0xc897f8: b.ne            #0xc89808
    // 0xc897fc: r5 = Instance_StadiumBorder
    //     0xc897fc: add             x5, PP, #0xe, lsl #12  ; [pp+0xe350] Obj!StadiumBorder@b383b1
    //     0xc89800: ldr             x5, [x5, #0x350]
    // 0xc89804: b               #0xc89810
    // 0xc89808: r5 = Instance_CircleBorder
    //     0xc89808: add             x5, PP, #0xe, lsl #12  ; [pp+0xe358] Obj!CircleBorder@b38441
    //     0xc8980c: ldr             x5, [x5, #0x358]
    // 0xc89810: r6 = LoadClassIdInstr(r0)
    //     0xc89810: ldur            x6, [x0, #-1]
    //     0xc89814: ubfx            x6, x6, #0xc, #0x14
    // 0xc89818: stp             x5, x0, [SP, #-0x10]!
    // 0xc8981c: mov             x0, x6
    // 0xc89820: mov             lr, x0
    // 0xc89824: ldr             lr, [x21, lr, lsl #3]
    // 0xc89828: blr             lr
    // 0xc8982c: add             SP, SP, #0x10
    // 0xc89830: tbnz            w0, #4, #0xc89ed4
    // 0xc89834: ldr             x2, [fp, #0x18]
    // 0xc89838: ldr             x1, [fp, #0x10]
    // 0xc8983c: LoadField: r0 = r1->field_33
    //     0xc8983c: ldur            w0, [x1, #0x33]
    // 0xc89840: DecompressPointer r0
    //     0xc89840: add             x0, x0, HEAP, lsl #32
    // 0xc89844: LoadField: r3 = r2->field_33
    //     0xc89844: ldur            w3, [x2, #0x33]
    // 0xc89848: DecompressPointer r3
    //     0xc89848: add             x3, x3, HEAP, lsl #32
    // 0xc8984c: cmp             w0, w3
    // 0xc89850: b.ne            #0xc89ed4
    // 0xc89854: ldur            x3, [fp, #-8]
    // 0xc89858: r17 = 5596
    //     0xc89858: mov             x17, #0x15dc
    // 0xc8985c: cmp             w3, w17
    // 0xc89860: b.ne            #0xc89870
    // 0xc89864: LoadField: r0 = r1->field_37
    //     0xc89864: ldur            w0, [x1, #0x37]
    // 0xc89868: DecompressPointer r0
    //     0xc89868: add             x0, x0, HEAP, lsl #32
    // 0xc8986c: b               #0xc89920
    // 0xc89870: r17 = 5598
    //     0xc89870: mov             x17, #0x15de
    // 0xc89874: cmp             w3, w17
    // 0xc89878: b.ne            #0xc898d0
    // 0xc8987c: LoadField: r0 = r1->field_5f
    //     0xc8987c: ldur            w0, [x1, #0x5f]
    // 0xc89880: DecompressPointer r0
    //     0xc89880: add             x0, x0, HEAP, lsl #32
    // 0xc89884: LoadField: r4 = r0->field_7
    //     0xc89884: ldur            x4, [x0, #7]
    // 0xc89888: cmp             x4, #1
    // 0xc8988c: b.gt            #0xc898b0
    // 0xc89890: cmp             x4, #0
    // 0xc89894: b.gt            #0xc898a4
    // 0xc89898: r0 = 24.000000
    //     0xc89898: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc8989c: ldr             x0, [x0, #0x360]
    // 0xc898a0: b               #0xc89920
    // 0xc898a4: r0 = 24.000000
    //     0xc898a4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc898a8: ldr             x0, [x0, #0x360]
    // 0xc898ac: b               #0xc89920
    // 0xc898b0: cmp             x4, #2
    // 0xc898b4: b.gt            #0xc898c4
    // 0xc898b8: r0 = 36.000000
    //     0xc898b8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe368] 36
    //     0xc898bc: ldr             x0, [x0, #0x368]
    // 0xc898c0: b               #0xc89920
    // 0xc898c4: r0 = 24.000000
    //     0xc898c4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc898c8: ldr             x0, [x0, #0x360]
    // 0xc898cc: b               #0xc89920
    // 0xc898d0: LoadField: r0 = r1->field_5b
    //     0xc898d0: ldur            w0, [x1, #0x5b]
    // 0xc898d4: DecompressPointer r0
    //     0xc898d4: add             x0, x0, HEAP, lsl #32
    // 0xc898d8: r16 = Instance__FloatingActionButtonType
    //     0xc898d8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe370] Obj!_FloatingActionButtonType@b65891
    //     0xc898dc: ldr             x16, [x16, #0x370]
    // 0xc898e0: cmp             w0, w16
    // 0xc898e4: b.ne            #0xc898f4
    // 0xc898e8: d0 = 36.000000
    //     0xc898e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xc898ec: ldr             d0, [x17, #0xfa8]
    // 0xc898f0: b               #0xc898f8
    // 0xc898f4: d0 = 24.000000
    //     0xc898f4: fmov            d0, #24.00000000
    // 0xc898f8: r0 = inline_Allocate_Double()
    //     0xc898f8: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xc898fc: add             x0, x0, #0x10
    //     0xc89900: cmp             x4, x0
    //     0xc89904: b.ls            #0xc89eec
    //     0xc89908: str             x0, [THR, #0x60]  ; THR::top
    //     0xc8990c: sub             x0, x0, #0xf
    //     0xc89910: mov             x4, #0xd108
    //     0xc89914: movk            x4, #3, lsl #16
    //     0xc89918: stur            x4, [x0, #-1]
    // 0xc8991c: StoreField: r0->field_7 = d0
    //     0xc8991c: stur            d0, [x0, #7]
    // 0xc89920: ldur            x4, [fp, #-0x10]
    // 0xc89924: r17 = 5596
    //     0xc89924: mov             x17, #0x15dc
    // 0xc89928: cmp             w4, w17
    // 0xc8992c: b.ne            #0xc8993c
    // 0xc89930: LoadField: r5 = r2->field_37
    //     0xc89930: ldur            w5, [x2, #0x37]
    // 0xc89934: DecompressPointer r5
    //     0xc89934: add             x5, x5, HEAP, lsl #32
    // 0xc89938: b               #0xc899ec
    // 0xc8993c: r17 = 5598
    //     0xc8993c: mov             x17, #0x15de
    // 0xc89940: cmp             w4, w17
    // 0xc89944: b.ne            #0xc8999c
    // 0xc89948: LoadField: r5 = r2->field_5f
    //     0xc89948: ldur            w5, [x2, #0x5f]
    // 0xc8994c: DecompressPointer r5
    //     0xc8994c: add             x5, x5, HEAP, lsl #32
    // 0xc89950: LoadField: r6 = r5->field_7
    //     0xc89950: ldur            x6, [x5, #7]
    // 0xc89954: cmp             x6, #1
    // 0xc89958: b.gt            #0xc8997c
    // 0xc8995c: cmp             x6, #0
    // 0xc89960: b.gt            #0xc89970
    // 0xc89964: r5 = 24.000000
    //     0xc89964: add             x5, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc89968: ldr             x5, [x5, #0x360]
    // 0xc8996c: b               #0xc899ec
    // 0xc89970: r5 = 24.000000
    //     0xc89970: add             x5, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc89974: ldr             x5, [x5, #0x360]
    // 0xc89978: b               #0xc899ec
    // 0xc8997c: cmp             x6, #2
    // 0xc89980: b.gt            #0xc89990
    // 0xc89984: r5 = 36.000000
    //     0xc89984: add             x5, PP, #0xe, lsl #12  ; [pp+0xe368] 36
    //     0xc89988: ldr             x5, [x5, #0x368]
    // 0xc8998c: b               #0xc899ec
    // 0xc89990: r5 = 24.000000
    //     0xc89990: add             x5, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xc89994: ldr             x5, [x5, #0x360]
    // 0xc89998: b               #0xc899ec
    // 0xc8999c: LoadField: r5 = r2->field_5b
    //     0xc8999c: ldur            w5, [x2, #0x5b]
    // 0xc899a0: DecompressPointer r5
    //     0xc899a0: add             x5, x5, HEAP, lsl #32
    // 0xc899a4: r16 = Instance__FloatingActionButtonType
    //     0xc899a4: add             x16, PP, #0xe, lsl #12  ; [pp+0xe370] Obj!_FloatingActionButtonType@b65891
    //     0xc899a8: ldr             x16, [x16, #0x370]
    // 0xc899ac: cmp             w5, w16
    // 0xc899b0: b.ne            #0xc899c0
    // 0xc899b4: d0 = 36.000000
    //     0xc899b4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xc899b8: ldr             d0, [x17, #0xfa8]
    // 0xc899bc: b               #0xc899c4
    // 0xc899c0: d0 = 24.000000
    //     0xc899c0: fmov            d0, #24.00000000
    // 0xc899c4: r5 = inline_Allocate_Double()
    //     0xc899c4: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xc899c8: add             x5, x5, #0x10
    //     0xc899cc: cmp             x6, x5
    //     0xc899d0: b.ls            #0xc89f0c
    //     0xc899d4: str             x5, [THR, #0x60]  ; THR::top
    //     0xc899d8: sub             x5, x5, #0xf
    //     0xc899dc: mov             x6, #0xd108
    //     0xc899e0: movk            x6, #3, lsl #16
    //     0xc899e4: stur            x6, [x5, #-1]
    // 0xc899e8: StoreField: r5->field_7 = d0
    //     0xc899e8: stur            d0, [x5, #7]
    // 0xc899ec: r6 = LoadClassIdInstr(r0)
    //     0xc899ec: ldur            x6, [x0, #-1]
    //     0xc899f0: ubfx            x6, x6, #0xc, #0x14
    // 0xc899f4: stp             x5, x0, [SP, #-0x10]!
    // 0xc899f8: mov             x0, x6
    // 0xc899fc: mov             lr, x0
    // 0xc89a00: ldr             lr, [x21, lr, lsl #3]
    // 0xc89a04: blr             lr
    // 0xc89a08: add             SP, SP, #0x10
    // 0xc89a0c: tbnz            w0, #4, #0xc89ed4
    // 0xc89a10: ldr             x2, [fp, #0x18]
    // 0xc89a14: ldr             x1, [fp, #0x10]
    // 0xc89a18: LoadField: r0 = r1->field_3b
    //     0xc89a18: ldur            w0, [x1, #0x3b]
    // 0xc89a1c: DecompressPointer r0
    //     0xc89a1c: add             x0, x0, HEAP, lsl #32
    // 0xc89a20: LoadField: r3 = r2->field_3b
    //     0xc89a20: ldur            w3, [x2, #0x3b]
    // 0xc89a24: DecompressPointer r3
    //     0xc89a24: add             x3, x3, HEAP, lsl #32
    // 0xc89a28: r4 = LoadClassIdInstr(r0)
    //     0xc89a28: ldur            x4, [x0, #-1]
    //     0xc89a2c: ubfx            x4, x4, #0xc, #0x14
    // 0xc89a30: stp             x3, x0, [SP, #-0x10]!
    // 0xc89a34: mov             x0, x4
    // 0xc89a38: mov             lr, x0
    // 0xc89a3c: ldr             lr, [x21, lr, lsl #3]
    // 0xc89a40: blr             lr
    // 0xc89a44: add             SP, SP, #0x10
    // 0xc89a48: tbnz            w0, #4, #0xc89ed4
    // 0xc89a4c: ldr             x2, [fp, #0x18]
    // 0xc89a50: ldr             x1, [fp, #0x10]
    // 0xc89a54: LoadField: r0 = r1->field_3f
    //     0xc89a54: ldur            w0, [x1, #0x3f]
    // 0xc89a58: DecompressPointer r0
    //     0xc89a58: add             x0, x0, HEAP, lsl #32
    // 0xc89a5c: LoadField: r3 = r2->field_3f
    //     0xc89a5c: ldur            w3, [x2, #0x3f]
    // 0xc89a60: DecompressPointer r3
    //     0xc89a60: add             x3, x3, HEAP, lsl #32
    // 0xc89a64: r4 = LoadClassIdInstr(r0)
    //     0xc89a64: ldur            x4, [x0, #-1]
    //     0xc89a68: ubfx            x4, x4, #0xc, #0x14
    // 0xc89a6c: stp             x3, x0, [SP, #-0x10]!
    // 0xc89a70: mov             x0, x4
    // 0xc89a74: mov             lr, x0
    // 0xc89a78: ldr             lr, [x21, lr, lsl #3]
    // 0xc89a7c: blr             lr
    // 0xc89a80: add             SP, SP, #0x10
    // 0xc89a84: tbnz            w0, #4, #0xc89ed4
    // 0xc89a88: ldr             x2, [fp, #0x18]
    // 0xc89a8c: ldr             x1, [fp, #0x10]
    // 0xc89a90: LoadField: r0 = r1->field_43
    //     0xc89a90: ldur            w0, [x1, #0x43]
    // 0xc89a94: DecompressPointer r0
    //     0xc89a94: add             x0, x0, HEAP, lsl #32
    // 0xc89a98: LoadField: r3 = r2->field_43
    //     0xc89a98: ldur            w3, [x2, #0x43]
    // 0xc89a9c: DecompressPointer r3
    //     0xc89a9c: add             x3, x3, HEAP, lsl #32
    // 0xc89aa0: r4 = LoadClassIdInstr(r0)
    //     0xc89aa0: ldur            x4, [x0, #-1]
    //     0xc89aa4: ubfx            x4, x4, #0xc, #0x14
    // 0xc89aa8: stp             x3, x0, [SP, #-0x10]!
    // 0xc89aac: mov             x0, x4
    // 0xc89ab0: mov             lr, x0
    // 0xc89ab4: ldr             lr, [x21, lr, lsl #3]
    // 0xc89ab8: blr             lr
    // 0xc89abc: add             SP, SP, #0x10
    // 0xc89ac0: tbnz            w0, #4, #0xc89ed4
    // 0xc89ac4: ldr             x2, [fp, #0x18]
    // 0xc89ac8: ldr             x1, [fp, #0x10]
    // 0xc89acc: LoadField: r0 = r1->field_47
    //     0xc89acc: ldur            w0, [x1, #0x47]
    // 0xc89ad0: DecompressPointer r0
    //     0xc89ad0: add             x0, x0, HEAP, lsl #32
    // 0xc89ad4: LoadField: r3 = r2->field_47
    //     0xc89ad4: ldur            w3, [x2, #0x47]
    // 0xc89ad8: DecompressPointer r3
    //     0xc89ad8: add             x3, x3, HEAP, lsl #32
    // 0xc89adc: r4 = LoadClassIdInstr(r0)
    //     0xc89adc: ldur            x4, [x0, #-1]
    //     0xc89ae0: ubfx            x4, x4, #0xc, #0x14
    // 0xc89ae4: stp             x3, x0, [SP, #-0x10]!
    // 0xc89ae8: mov             x0, x4
    // 0xc89aec: mov             lr, x0
    // 0xc89af0: ldr             lr, [x21, lr, lsl #3]
    // 0xc89af4: blr             lr
    // 0xc89af8: add             SP, SP, #0x10
    // 0xc89afc: tbnz            w0, #4, #0xc89ed4
    // 0xc89b00: ldr             x2, [fp, #0x18]
    // 0xc89b04: ldr             x1, [fp, #0x10]
    // 0xc89b08: LoadField: r0 = r1->field_4b
    //     0xc89b08: ldur            w0, [x1, #0x4b]
    // 0xc89b0c: DecompressPointer r0
    //     0xc89b0c: add             x0, x0, HEAP, lsl #32
    // 0xc89b10: LoadField: r3 = r2->field_4b
    //     0xc89b10: ldur            w3, [x2, #0x4b]
    // 0xc89b14: DecompressPointer r3
    //     0xc89b14: add             x3, x3, HEAP, lsl #32
    // 0xc89b18: r4 = LoadClassIdInstr(r0)
    //     0xc89b18: ldur            x4, [x0, #-1]
    //     0xc89b1c: ubfx            x4, x4, #0xc, #0x14
    // 0xc89b20: stp             x3, x0, [SP, #-0x10]!
    // 0xc89b24: mov             x0, x4
    // 0xc89b28: mov             lr, x0
    // 0xc89b2c: ldr             lr, [x21, lr, lsl #3]
    // 0xc89b30: blr             lr
    // 0xc89b34: add             SP, SP, #0x10
    // 0xc89b38: tbnz            w0, #4, #0xc89ed4
    // 0xc89b3c: ldur            x0, [fp, #-8]
    // 0xc89b40: r17 = 5596
    //     0xc89b40: mov             x17, #0x15dc
    // 0xc89b44: cmp             w0, w17
    // 0xc89b48: b.ne            #0xc89b68
    // 0xc89b4c: ldr             x1, [fp, #0x10]
    // 0xc89b50: LoadField: r2 = r1->field_4f
    //     0xc89b50: ldur            w2, [x1, #0x4f]
    // 0xc89b54: DecompressPointer r2
    //     0xc89b54: add             x2, x2, HEAP, lsl #32
    // 0xc89b58: mov             x1, x2
    // 0xc89b5c: d1 = 20.000000
    //     0xc89b5c: fmov            d1, #20.00000000
    // 0xc89b60: d0 = 0.000000
    //     0xc89b60: eor             v0.16b, v0.16b, v0.16b
    // 0xc89b64: b               #0xc89c34
    // 0xc89b68: ldr             x1, [fp, #0x10]
    // 0xc89b6c: r17 = 5598
    //     0xc89b6c: mov             x17, #0x15de
    // 0xc89b70: cmp             w0, w17
    // 0xc89b74: b.ne            #0xc89bd4
    // 0xc89b78: LoadField: r2 = r1->field_63
    //     0xc89b78: ldur            w2, [x1, #0x63]
    // 0xc89b7c: DecompressPointer r2
    //     0xc89b7c: add             x2, x2, HEAP, lsl #32
    // 0xc89b80: tbnz            w2, #4, #0xc89ba4
    // 0xc89b84: LoadField: r2 = r1->field_5f
    //     0xc89b84: ldur            w2, [x1, #0x5f]
    // 0xc89b88: DecompressPointer r2
    //     0xc89b88: add             x2, x2, HEAP, lsl #32
    // 0xc89b8c: r16 = Instance__FloatingActionButtonType
    //     0xc89b8c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xc89b90: ldr             x16, [x16, #0x348]
    // 0xc89b94: cmp             w2, w16
    // 0xc89b98: b.ne            #0xc89ba4
    // 0xc89b9c: d0 = 16.000000
    //     0xc89b9c: fmov            d0, #16.00000000
    // 0xc89ba0: b               #0xc89ba8
    // 0xc89ba4: d0 = 20.000000
    //     0xc89ba4: fmov            d0, #20.00000000
    // 0xc89ba8: stur            d0, [fp, #-0x20]
    // 0xc89bac: r0 = EdgeInsetsDirectional()
    //     0xc89bac: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xc89bb0: ldur            d0, [fp, #-0x20]
    // 0xc89bb4: StoreField: r0->field_7 = d0
    //     0xc89bb4: stur            d0, [x0, #7]
    // 0xc89bb8: d0 = 0.000000
    //     0xc89bb8: eor             v0.16b, v0.16b, v0.16b
    // 0xc89bbc: StoreField: r0->field_f = d0
    //     0xc89bbc: stur            d0, [x0, #0xf]
    // 0xc89bc0: d1 = 20.000000
    //     0xc89bc0: fmov            d1, #20.00000000
    // 0xc89bc4: StoreField: r0->field_17 = d1
    //     0xc89bc4: stur            d1, [x0, #0x17]
    // 0xc89bc8: StoreField: r0->field_1f = d0
    //     0xc89bc8: stur            d0, [x0, #0x1f]
    // 0xc89bcc: mov             x1, x0
    // 0xc89bd0: b               #0xc89c34
    // 0xc89bd4: d1 = 20.000000
    //     0xc89bd4: fmov            d1, #20.00000000
    // 0xc89bd8: d0 = 0.000000
    //     0xc89bd8: eor             v0.16b, v0.16b, v0.16b
    // 0xc89bdc: LoadField: r0 = r1->field_5f
    //     0xc89bdc: ldur            w0, [x1, #0x5f]
    // 0xc89be0: DecompressPointer r0
    //     0xc89be0: add             x0, x0, HEAP, lsl #32
    // 0xc89be4: tbnz            w0, #4, #0xc89c08
    // 0xc89be8: LoadField: r0 = r1->field_5b
    //     0xc89be8: ldur            w0, [x1, #0x5b]
    // 0xc89bec: DecompressPointer r0
    //     0xc89bec: add             x0, x0, HEAP, lsl #32
    // 0xc89bf0: r16 = Instance__FloatingActionButtonType
    //     0xc89bf0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xc89bf4: ldr             x16, [x16, #0x348]
    // 0xc89bf8: cmp             w0, w16
    // 0xc89bfc: b.ne            #0xc89c08
    // 0xc89c00: d2 = 16.000000
    //     0xc89c00: fmov            d2, #16.00000000
    // 0xc89c04: b               #0xc89c0c
    // 0xc89c08: d2 = 20.000000
    //     0xc89c08: fmov            d2, #20.00000000
    // 0xc89c0c: stur            d2, [fp, #-0x20]
    // 0xc89c10: r0 = EdgeInsetsDirectional()
    //     0xc89c10: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xc89c14: ldur            d0, [fp, #-0x20]
    // 0xc89c18: StoreField: r0->field_7 = d0
    //     0xc89c18: stur            d0, [x0, #7]
    // 0xc89c1c: d0 = 0.000000
    //     0xc89c1c: eor             v0.16b, v0.16b, v0.16b
    // 0xc89c20: StoreField: r0->field_f = d0
    //     0xc89c20: stur            d0, [x0, #0xf]
    // 0xc89c24: d1 = 20.000000
    //     0xc89c24: fmov            d1, #20.00000000
    // 0xc89c28: StoreField: r0->field_17 = d1
    //     0xc89c28: stur            d1, [x0, #0x17]
    // 0xc89c2c: StoreField: r0->field_1f = d0
    //     0xc89c2c: stur            d0, [x0, #0x1f]
    // 0xc89c30: mov             x1, x0
    // 0xc89c34: ldur            x0, [fp, #-0x10]
    // 0xc89c38: stur            x1, [fp, #-0x18]
    // 0xc89c3c: r17 = 5596
    //     0xc89c3c: mov             x17, #0x15dc
    // 0xc89c40: cmp             w0, w17
    // 0xc89c44: b.ne            #0xc89c60
    // 0xc89c48: ldr             x2, [fp, #0x18]
    // 0xc89c4c: LoadField: r3 = r2->field_4f
    //     0xc89c4c: ldur            w3, [x2, #0x4f]
    // 0xc89c50: DecompressPointer r3
    //     0xc89c50: add             x3, x3, HEAP, lsl #32
    // 0xc89c54: mov             x0, x1
    // 0xc89c58: mov             x1, x3
    // 0xc89c5c: b               #0xc89d30
    // 0xc89c60: ldr             x2, [fp, #0x18]
    // 0xc89c64: r17 = 5598
    //     0xc89c64: mov             x17, #0x15de
    // 0xc89c68: cmp             w0, w17
    // 0xc89c6c: b.ne            #0xc89cd0
    // 0xc89c70: LoadField: r3 = r2->field_63
    //     0xc89c70: ldur            w3, [x2, #0x63]
    // 0xc89c74: DecompressPointer r3
    //     0xc89c74: add             x3, x3, HEAP, lsl #32
    // 0xc89c78: tbnz            w3, #4, #0xc89c9c
    // 0xc89c7c: LoadField: r3 = r2->field_5f
    //     0xc89c7c: ldur            w3, [x2, #0x5f]
    // 0xc89c80: DecompressPointer r3
    //     0xc89c80: add             x3, x3, HEAP, lsl #32
    // 0xc89c84: r16 = Instance__FloatingActionButtonType
    //     0xc89c84: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xc89c88: ldr             x16, [x16, #0x348]
    // 0xc89c8c: cmp             w3, w16
    // 0xc89c90: b.ne            #0xc89c9c
    // 0xc89c94: d2 = 16.000000
    //     0xc89c94: fmov            d2, #16.00000000
    // 0xc89c98: b               #0xc89ca0
    // 0xc89c9c: d2 = 20.000000
    //     0xc89c9c: fmov            d2, #20.00000000
    // 0xc89ca0: stur            d2, [fp, #-0x20]
    // 0xc89ca4: r0 = EdgeInsetsDirectional()
    //     0xc89ca4: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xc89ca8: ldur            d0, [fp, #-0x20]
    // 0xc89cac: StoreField: r0->field_7 = d0
    //     0xc89cac: stur            d0, [x0, #7]
    // 0xc89cb0: d0 = 0.000000
    //     0xc89cb0: eor             v0.16b, v0.16b, v0.16b
    // 0xc89cb4: StoreField: r0->field_f = d0
    //     0xc89cb4: stur            d0, [x0, #0xf]
    // 0xc89cb8: d1 = 20.000000
    //     0xc89cb8: fmov            d1, #20.00000000
    // 0xc89cbc: StoreField: r0->field_17 = d1
    //     0xc89cbc: stur            d1, [x0, #0x17]
    // 0xc89cc0: StoreField: r0->field_1f = d0
    //     0xc89cc0: stur            d0, [x0, #0x1f]
    // 0xc89cc4: mov             x1, x0
    // 0xc89cc8: ldur            x0, [fp, #-0x18]
    // 0xc89ccc: b               #0xc89d30
    // 0xc89cd0: mov             x1, x2
    // 0xc89cd4: LoadField: r0 = r1->field_5f
    //     0xc89cd4: ldur            w0, [x1, #0x5f]
    // 0xc89cd8: DecompressPointer r0
    //     0xc89cd8: add             x0, x0, HEAP, lsl #32
    // 0xc89cdc: tbnz            w0, #4, #0xc89d00
    // 0xc89ce0: LoadField: r0 = r1->field_5b
    //     0xc89ce0: ldur            w0, [x1, #0x5b]
    // 0xc89ce4: DecompressPointer r0
    //     0xc89ce4: add             x0, x0, HEAP, lsl #32
    // 0xc89ce8: r16 = Instance__FloatingActionButtonType
    //     0xc89ce8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe348] Obj!_FloatingActionButtonType@b658b1
    //     0xc89cec: ldr             x16, [x16, #0x348]
    // 0xc89cf0: cmp             w0, w16
    // 0xc89cf4: b.ne            #0xc89d00
    // 0xc89cf8: d2 = 16.000000
    //     0xc89cf8: fmov            d2, #16.00000000
    // 0xc89cfc: b               #0xc89d04
    // 0xc89d00: d2 = 20.000000
    //     0xc89d00: fmov            d2, #20.00000000
    // 0xc89d04: stur            d2, [fp, #-0x20]
    // 0xc89d08: r0 = EdgeInsetsDirectional()
    //     0xc89d08: bl              #0x84b6f4  ; AllocateEdgeInsetsDirectionalStub -> EdgeInsetsDirectional (size=0x28)
    // 0xc89d0c: ldur            d0, [fp, #-0x20]
    // 0xc89d10: StoreField: r0->field_7 = d0
    //     0xc89d10: stur            d0, [x0, #7]
    // 0xc89d14: d0 = 0.000000
    //     0xc89d14: eor             v0.16b, v0.16b, v0.16b
    // 0xc89d18: StoreField: r0->field_f = d0
    //     0xc89d18: stur            d0, [x0, #0xf]
    // 0xc89d1c: d1 = 20.000000
    //     0xc89d1c: fmov            d1, #20.00000000
    // 0xc89d20: StoreField: r0->field_17 = d1
    //     0xc89d20: stur            d1, [x0, #0x17]
    // 0xc89d24: StoreField: r0->field_1f = d0
    //     0xc89d24: stur            d0, [x0, #0x1f]
    // 0xc89d28: mov             x1, x0
    // 0xc89d2c: ldur            x0, [fp, #-0x18]
    // 0xc89d30: r2 = LoadClassIdInstr(r0)
    //     0xc89d30: ldur            x2, [x0, #-1]
    //     0xc89d34: ubfx            x2, x2, #0xc, #0x14
    // 0xc89d38: stp             x1, x0, [SP, #-0x10]!
    // 0xc89d3c: mov             x0, x2
    // 0xc89d40: mov             lr, x0
    // 0xc89d44: ldr             lr, [x21, lr, lsl #3]
    // 0xc89d48: blr             lr
    // 0xc89d4c: add             SP, SP, #0x10
    // 0xc89d50: tbnz            w0, #4, #0xc89ed4
    // 0xc89d54: ldur            x0, [fp, #-8]
    // 0xc89d58: r17 = 5596
    //     0xc89d58: mov             x17, #0x15dc
    // 0xc89d5c: cmp             w0, w17
    // 0xc89d60: b.ne            #0xc89d78
    // 0xc89d64: ldr             x1, [fp, #0x10]
    // 0xc89d68: LoadField: r0 = r1->field_53
    //     0xc89d68: ldur            w0, [x1, #0x53]
    // 0xc89d6c: DecompressPointer r0
    //     0xc89d6c: add             x0, x0, HEAP, lsl #32
    // 0xc89d70: mov             x2, x0
    // 0xc89d74: b               #0xc89df8
    // 0xc89d78: ldr             x1, [fp, #0x10]
    // 0xc89d7c: r17 = 5598
    //     0xc89d7c: mov             x17, #0x15de
    // 0xc89d80: cmp             w0, w17
    // 0xc89d84: b.ne            #0xc89db8
    // 0xc89d88: LoadField: r0 = r1->field_6b
    //     0xc89d88: ldur            w0, [x1, #0x6b]
    // 0xc89d8c: DecompressPointer r0
    //     0xc89d8c: add             x0, x0, HEAP, lsl #32
    // 0xc89d90: r16 = Sentinel
    //     0xc89d90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc89d94: cmp             w0, w16
    // 0xc89d98: b.ne            #0xc89da8
    // 0xc89d9c: r2 = _textTheme
    //     0xc89d9c: add             x2, PP, #0xe, lsl #12  ; [pp+0xe378] Field <_FABDefaultsM3@746192485._textTheme@746192485>: late final (offset: 0x6c)
    //     0xc89da0: ldr             x2, [x2, #0x378]
    // 0xc89da4: r0 = InitLateFinalInstanceField()
    //     0xc89da4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc89da8: LoadField: r1 = r0->field_37
    //     0xc89da8: ldur            w1, [x0, #0x37]
    // 0xc89dac: DecompressPointer r1
    //     0xc89dac: add             x1, x1, HEAP, lsl #32
    // 0xc89db0: mov             x2, x1
    // 0xc89db4: b               #0xc89df8
    // 0xc89db8: LoadField: r0 = r1->field_63
    //     0xc89db8: ldur            w0, [x1, #0x63]
    // 0xc89dbc: DecompressPointer r0
    //     0xc89dbc: add             x0, x0, HEAP, lsl #32
    // 0xc89dc0: LoadField: r1 = r0->field_93
    //     0xc89dc0: ldur            w1, [x0, #0x93]
    // 0xc89dc4: DecompressPointer r1
    //     0xc89dc4: add             x1, x1, HEAP, lsl #32
    // 0xc89dc8: LoadField: r0 = r1->field_37
    //     0xc89dc8: ldur            w0, [x1, #0x37]
    // 0xc89dcc: DecompressPointer r0
    //     0xc89dcc: add             x0, x0, HEAP, lsl #32
    // 0xc89dd0: cmp             w0, NULL
    // 0xc89dd4: b.eq            #0xc89f38
    // 0xc89dd8: r16 = 1.200000
    //     0xc89dd8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe380] 1.2
    //     0xc89ddc: ldr             x16, [x16, #0x380]
    // 0xc89de0: stp             x16, x0, [SP, #-0x10]!
    // 0xc89de4: r4 = const [0, 0x2, 0x2, 0x1, letterSpacing, 0x1, null]
    //     0xc89de4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe388] List(7) [0, 0x2, 0x2, 0x1, "letterSpacing", 0x1, Null]
    //     0xc89de8: ldr             x4, [x4, #0x388]
    // 0xc89dec: r0 = copyWith()
    //     0xc89dec: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xc89df0: add             SP, SP, #0x10
    // 0xc89df4: mov             x2, x0
    // 0xc89df8: ldur            x0, [fp, #-0x10]
    // 0xc89dfc: stur            x2, [fp, #-8]
    // 0xc89e00: r17 = 5596
    //     0xc89e00: mov             x17, #0x15dc
    // 0xc89e04: cmp             w0, w17
    // 0xc89e08: b.ne            #0xc89e24
    // 0xc89e0c: ldr             x1, [fp, #0x18]
    // 0xc89e10: LoadField: r0 = r1->field_53
    //     0xc89e10: ldur            w0, [x1, #0x53]
    // 0xc89e14: DecompressPointer r0
    //     0xc89e14: add             x0, x0, HEAP, lsl #32
    // 0xc89e18: mov             x1, x0
    // 0xc89e1c: mov             x0, x2
    // 0xc89e20: b               #0xc89ea8
    // 0xc89e24: ldr             x1, [fp, #0x18]
    // 0xc89e28: r17 = 5598
    //     0xc89e28: mov             x17, #0x15de
    // 0xc89e2c: cmp             w0, w17
    // 0xc89e30: b.ne            #0xc89e64
    // 0xc89e34: LoadField: r0 = r1->field_6b
    //     0xc89e34: ldur            w0, [x1, #0x6b]
    // 0xc89e38: DecompressPointer r0
    //     0xc89e38: add             x0, x0, HEAP, lsl #32
    // 0xc89e3c: r16 = Sentinel
    //     0xc89e3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc89e40: cmp             w0, w16
    // 0xc89e44: b.ne            #0xc89e54
    // 0xc89e48: r2 = _textTheme
    //     0xc89e48: add             x2, PP, #0xe, lsl #12  ; [pp+0xe378] Field <_FABDefaultsM3@746192485._textTheme@746192485>: late final (offset: 0x6c)
    //     0xc89e4c: ldr             x2, [x2, #0x378]
    // 0xc89e50: r0 = InitLateFinalInstanceField()
    //     0xc89e50: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xc89e54: LoadField: r1 = r0->field_37
    //     0xc89e54: ldur            w1, [x0, #0x37]
    // 0xc89e58: DecompressPointer r1
    //     0xc89e58: add             x1, x1, HEAP, lsl #32
    // 0xc89e5c: ldur            x0, [fp, #-8]
    // 0xc89e60: b               #0xc89ea8
    // 0xc89e64: LoadField: r0 = r1->field_63
    //     0xc89e64: ldur            w0, [x1, #0x63]
    // 0xc89e68: DecompressPointer r0
    //     0xc89e68: add             x0, x0, HEAP, lsl #32
    // 0xc89e6c: LoadField: r1 = r0->field_93
    //     0xc89e6c: ldur            w1, [x0, #0x93]
    // 0xc89e70: DecompressPointer r1
    //     0xc89e70: add             x1, x1, HEAP, lsl #32
    // 0xc89e74: LoadField: r0 = r1->field_37
    //     0xc89e74: ldur            w0, [x1, #0x37]
    // 0xc89e78: DecompressPointer r0
    //     0xc89e78: add             x0, x0, HEAP, lsl #32
    // 0xc89e7c: cmp             w0, NULL
    // 0xc89e80: b.eq            #0xc89f3c
    // 0xc89e84: r16 = 1.200000
    //     0xc89e84: add             x16, PP, #0xe, lsl #12  ; [pp+0xe380] 1.2
    //     0xc89e88: ldr             x16, [x16, #0x380]
    // 0xc89e8c: stp             x16, x0, [SP, #-0x10]!
    // 0xc89e90: r4 = const [0, 0x2, 0x2, 0x1, letterSpacing, 0x1, null]
    //     0xc89e90: add             x4, PP, #0xe, lsl #12  ; [pp+0xe388] List(7) [0, 0x2, 0x2, 0x1, "letterSpacing", 0x1, Null]
    //     0xc89e94: ldr             x4, [x4, #0x388]
    // 0xc89e98: r0 = copyWith()
    //     0xc89e98: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xc89e9c: add             SP, SP, #0x10
    // 0xc89ea0: mov             x1, x0
    // 0xc89ea4: ldur            x0, [fp, #-8]
    // 0xc89ea8: r2 = LoadClassIdInstr(r0)
    //     0xc89ea8: ldur            x2, [x0, #-1]
    //     0xc89eac: ubfx            x2, x2, #0xc, #0x14
    // 0xc89eb0: stp             x1, x0, [SP, #-0x10]!
    // 0xc89eb4: mov             x0, x2
    // 0xc89eb8: mov             lr, x0
    // 0xc89ebc: ldr             lr, [x21, lr, lsl #3]
    // 0xc89ec0: blr             lr
    // 0xc89ec4: add             SP, SP, #0x10
    // 0xc89ec8: tbnz            w0, #4, #0xc89ed4
    // 0xc89ecc: r0 = true
    //     0xc89ecc: add             x0, NULL, #0x20  ; true
    // 0xc89ed0: b               #0xc89ed8
    // 0xc89ed4: r0 = false
    //     0xc89ed4: add             x0, NULL, #0x30  ; false
    // 0xc89ed8: LeaveFrame
    //     0xc89ed8: mov             SP, fp
    //     0xc89edc: ldp             fp, lr, [SP], #0x10
    // 0xc89ee0: ret
    //     0xc89ee0: ret             
    // 0xc89ee4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc89ee4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc89ee8: b               #0xc88cc4
    // 0xc89eec: SaveReg d0
    //     0xc89eec: str             q0, [SP, #-0x10]!
    // 0xc89ef0: stp             x2, x3, [SP, #-0x10]!
    // 0xc89ef4: SaveReg r1
    //     0xc89ef4: str             x1, [SP, #-8]!
    // 0xc89ef8: r0 = AllocateDouble()
    //     0xc89ef8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc89efc: RestoreReg r1
    //     0xc89efc: ldr             x1, [SP], #8
    // 0xc89f00: ldp             x2, x3, [SP], #0x10
    // 0xc89f04: RestoreReg d0
    //     0xc89f04: ldr             q0, [SP], #0x10
    // 0xc89f08: b               #0xc8991c
    // 0xc89f0c: SaveReg d0
    //     0xc89f0c: str             q0, [SP, #-0x10]!
    // 0xc89f10: stp             x3, x4, [SP, #-0x10]!
    // 0xc89f14: stp             x1, x2, [SP, #-0x10]!
    // 0xc89f18: SaveReg r0
    //     0xc89f18: str             x0, [SP, #-8]!
    // 0xc89f1c: r0 = AllocateDouble()
    //     0xc89f1c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc89f20: mov             x5, x0
    // 0xc89f24: RestoreReg r0
    //     0xc89f24: ldr             x0, [SP], #8
    // 0xc89f28: ldp             x1, x2, [SP], #0x10
    // 0xc89f2c: ldp             x3, x4, [SP], #0x10
    // 0xc89f30: RestoreReg d0
    //     0xc89f30: ldr             q0, [SP], #0x10
    // 0xc89f34: b               #0xc899e8
    // 0xc89f38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc89f38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc89f3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc89f3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

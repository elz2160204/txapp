// lib: , url: package:flutter/src/material/desktop_text_selection.dart

// class id: 1049220, size: 0x8
class :: {

  static late final TextSelectionControls desktopTextSelectionHandleControls; // offset: 0xd74
  static late final TextSelectionControls desktopTextSelectionControls; // offset: 0xd78

  static TextSelectionControls desktopTextSelectionControls() {
    // ** addr: 0x83ec4c, size: 0x18
    // 0x83ec4c: EnterFrame
    //     0x83ec4c: stp             fp, lr, [SP, #-0x10]!
    //     0x83ec50: mov             fp, SP
    // 0x83ec54: r0 = DesktopTextSelectionControls()
    //     0x83ec54: bl              #0x83ec64  ; AllocateDesktopTextSelectionControlsStub -> DesktopTextSelectionControls (size=0x8)
    // 0x83ec58: LeaveFrame
    //     0x83ec58: mov             SP, fp
    //     0x83ec5c: ldp             fp, lr, [SP], #0x10
    // 0x83ec60: ret
    //     0x83ec60: ret             
  }
  static TextSelectionControls desktopTextSelectionHandleControls() {
    // ** addr: 0x872dd0, size: 0x18
    // 0x872dd0: EnterFrame
    //     0x872dd0: stp             fp, lr, [SP, #-0x10]!
    //     0x872dd4: mov             fp, SP
    // 0x872dd8: r0 = _DesktopTextSelectionHandleControls()
    //     0x872dd8: bl              #0x872de8  ; Allocate_DesktopTextSelectionHandleControlsStub -> _DesktopTextSelectionHandleControls (size=0x8)
    // 0x872ddc: LeaveFrame
    //     0x872ddc: mov             SP, fp
    //     0x872de0: ldp             fp, lr, [SP], #0x10
    // 0x872de4: ret
    //     0x872de4: ret             
  }
}

// class id: 3329, size: 0x14, field offset: 0x14
class _DesktopTextSelectionControlsToolbarState extends State<_DesktopTextSelectionControlsToolbar> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b0e38, size: 0x17c
    // 0x7b0e38: EnterFrame
    //     0x7b0e38: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0e3c: mov             fp, SP
    // 0x7b0e40: AllocStack(0x8)
    //     0x7b0e40: sub             SP, SP, #8
    // 0x7b0e44: CheckStackOverflow
    //     0x7b0e44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0e48: cmp             SP, x16
    //     0x7b0e4c: b.ls            #0x7b0fa4
    // 0x7b0e50: ldr             x0, [fp, #0x10]
    // 0x7b0e54: r2 = Null
    //     0x7b0e54: mov             x2, NULL
    // 0x7b0e58: r1 = Null
    //     0x7b0e58: mov             x1, NULL
    // 0x7b0e5c: r4 = 59
    //     0x7b0e5c: mov             x4, #0x3b
    // 0x7b0e60: branchIfSmi(r0, 0x7b0e6c)
    //     0x7b0e60: tbz             w0, #0, #0x7b0e6c
    // 0x7b0e64: r4 = LoadClassIdInstr(r0)
    //     0x7b0e64: ldur            x4, [x0, #-1]
    //     0x7b0e68: ubfx            x4, x4, #0xc, #0x14
    // 0x7b0e6c: r17 = 4158
    //     0x7b0e6c: mov             x17, #0x103e
    // 0x7b0e70: cmp             x4, x17
    // 0x7b0e74: b.eq            #0x7b0e8c
    // 0x7b0e78: r8 = _DesktopTextSelectionControlsToolbar
    //     0x7b0e78: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b8d0] Type: _DesktopTextSelectionControlsToolbar
    //     0x7b0e7c: ldr             x8, [x8, #0x8d0]
    // 0x7b0e80: r3 = Null
    //     0x7b0e80: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b8d8] Null
    //     0x7b0e84: ldr             x3, [x3, #0x8d8]
    // 0x7b0e88: r0 = _DesktopTextSelectionControlsToolbar()
    //     0x7b0e88: bl              #0x7b0fb4  ; IsType__DesktopTextSelectionControlsToolbar_Stub
    // 0x7b0e8c: ldr             x3, [fp, #0x18]
    // 0x7b0e90: LoadField: r2 = r3->field_7
    //     0x7b0e90: ldur            w2, [x3, #7]
    // 0x7b0e94: DecompressPointer r2
    //     0x7b0e94: add             x2, x2, HEAP, lsl #32
    // 0x7b0e98: ldr             x0, [fp, #0x10]
    // 0x7b0e9c: r1 = Null
    //     0x7b0e9c: mov             x1, NULL
    // 0x7b0ea0: cmp             w2, NULL
    // 0x7b0ea4: b.eq            #0x7b0ec8
    // 0x7b0ea8: LoadField: r4 = r2->field_17
    //     0x7b0ea8: ldur            w4, [x2, #0x17]
    // 0x7b0eac: DecompressPointer r4
    //     0x7b0eac: add             x4, x4, HEAP, lsl #32
    // 0x7b0eb0: r8 = X0 bound StatefulWidget
    //     0x7b0eb0: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b0eb4: ldr             x8, [x8, #0x858]
    // 0x7b0eb8: LoadField: r9 = r4->field_7
    //     0x7b0eb8: ldur            x9, [x4, #7]
    // 0x7b0ebc: r3 = Null
    //     0x7b0ebc: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b8e8] Null
    //     0x7b0ec0: ldr             x3, [x3, #0x8e8]
    // 0x7b0ec4: blr             x9
    // 0x7b0ec8: ldr             x0, [fp, #0x10]
    // 0x7b0ecc: LoadField: r1 = r0->field_b
    //     0x7b0ecc: ldur            w1, [x0, #0xb]
    // 0x7b0ed0: DecompressPointer r1
    //     0x7b0ed0: add             x1, x1, HEAP, lsl #32
    // 0x7b0ed4: ldr             x0, [fp, #0x18]
    // 0x7b0ed8: stur            x1, [fp, #-8]
    // 0x7b0edc: LoadField: r2 = r0->field_b
    //     0x7b0edc: ldur            w2, [x0, #0xb]
    // 0x7b0ee0: DecompressPointer r2
    //     0x7b0ee0: add             x2, x2, HEAP, lsl #32
    // 0x7b0ee4: cmp             w2, NULL
    // 0x7b0ee8: b.eq            #0x7b0fac
    // 0x7b0eec: LoadField: r3 = r2->field_b
    //     0x7b0eec: ldur            w3, [x2, #0xb]
    // 0x7b0ef0: DecompressPointer r3
    //     0x7b0ef0: add             x3, x3, HEAP, lsl #32
    // 0x7b0ef4: cmp             w1, w3
    // 0x7b0ef8: b.eq            #0x7b0f94
    // 0x7b0efc: cmp             w1, NULL
    // 0x7b0f00: b.eq            #0x7b0f3c
    // 0x7b0f04: r1 = 1
    //     0x7b0f04: mov             x1, #1
    // 0x7b0f08: r0 = AllocateContext()
    //     0x7b0f08: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b0f0c: mov             x1, x0
    // 0x7b0f10: ldr             x0, [fp, #0x18]
    // 0x7b0f14: StoreField: r1->field_f = r0
    //     0x7b0f14: stur            w0, [x1, #0xf]
    // 0x7b0f18: mov             x2, x1
    // 0x7b0f1c: r1 = Function '_onChangedClipboardStatus@721113492':.
    //     0x7b0f1c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b8c0] AnonymousClosure: (0x7b0fd8), in [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7b1020)
    //     0x7b0f20: ldr             x1, [x1, #0x8c0]
    // 0x7b0f24: r0 = AllocateClosure()
    //     0x7b0f24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0f28: ldur            x16, [fp, #-8]
    // 0x7b0f2c: stp             x0, x16, [SP, #-0x10]!
    // 0x7b0f30: r0 = removeListener()
    //     0x7b0f30: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0x7b0f34: add             SP, SP, #0x10
    // 0x7b0f38: ldr             x0, [fp, #0x18]
    // 0x7b0f3c: LoadField: r1 = r0->field_b
    //     0x7b0f3c: ldur            w1, [x0, #0xb]
    // 0x7b0f40: DecompressPointer r1
    //     0x7b0f40: add             x1, x1, HEAP, lsl #32
    // 0x7b0f44: cmp             w1, NULL
    // 0x7b0f48: b.eq            #0x7b0fb0
    // 0x7b0f4c: LoadField: r2 = r1->field_b
    //     0x7b0f4c: ldur            w2, [x1, #0xb]
    // 0x7b0f50: DecompressPointer r2
    //     0x7b0f50: add             x2, x2, HEAP, lsl #32
    // 0x7b0f54: stur            x2, [fp, #-8]
    // 0x7b0f58: cmp             w2, NULL
    // 0x7b0f5c: b.eq            #0x7b0f94
    // 0x7b0f60: r1 = 1
    //     0x7b0f60: mov             x1, #1
    // 0x7b0f64: r0 = AllocateContext()
    //     0x7b0f64: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b0f68: mov             x1, x0
    // 0x7b0f6c: ldr             x0, [fp, #0x18]
    // 0x7b0f70: StoreField: r1->field_f = r0
    //     0x7b0f70: stur            w0, [x1, #0xf]
    // 0x7b0f74: mov             x2, x1
    // 0x7b0f78: r1 = Function '_onChangedClipboardStatus@721113492':.
    //     0x7b0f78: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b8c0] AnonymousClosure: (0x7b0fd8), in [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7b1020)
    //     0x7b0f7c: ldr             x1, [x1, #0x8c0]
    // 0x7b0f80: r0 = AllocateClosure()
    //     0x7b0f80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0f84: ldur            x16, [fp, #-8]
    // 0x7b0f88: stp             x0, x16, [SP, #-0x10]!
    // 0x7b0f8c: r0 = addListener()
    //     0x7b0f8c: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x7b0f90: add             SP, SP, #0x10
    // 0x7b0f94: r0 = Null
    //     0x7b0f94: mov             x0, NULL
    // 0x7b0f98: LeaveFrame
    //     0x7b0f98: mov             SP, fp
    //     0x7b0f9c: ldp             fp, lr, [SP], #0x10
    // 0x7b0fa0: ret
    //     0x7b0fa0: ret             
    // 0x7b0fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0fa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0fa8: b               #0x7b0e50
    // 0x7b0fac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0fac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b0fb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0fb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onChangedClipboardStatus(dynamic) {
    // ** addr: 0x7b0fd8, size: 0x48
    // 0x7b0fd8: EnterFrame
    //     0x7b0fd8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0fdc: mov             fp, SP
    // 0x7b0fe0: ldr             x0, [fp, #0x10]
    // 0x7b0fe4: LoadField: r1 = r0->field_17
    //     0x7b0fe4: ldur            w1, [x0, #0x17]
    // 0x7b0fe8: DecompressPointer r1
    //     0x7b0fe8: add             x1, x1, HEAP, lsl #32
    // 0x7b0fec: CheckStackOverflow
    //     0x7b0fec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0ff0: cmp             SP, x16
    //     0x7b0ff4: b.ls            #0x7b1018
    // 0x7b0ff8: LoadField: r0 = r1->field_f
    //     0x7b0ff8: ldur            w0, [x1, #0xf]
    // 0x7b0ffc: DecompressPointer r0
    //     0x7b0ffc: add             x0, x0, HEAP, lsl #32
    // 0x7b1000: SaveReg r0
    //     0x7b1000: str             x0, [SP, #-8]!
    // 0x7b1004: r0 = _onChangedClipboardStatus()
    //     0x7b1004: bl              #0x7b1020  ; [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus
    // 0x7b1008: add             SP, SP, #8
    // 0x7b100c: LeaveFrame
    //     0x7b100c: mov             SP, fp
    //     0x7b1010: ldp             fp, lr, [SP], #0x10
    // 0x7b1014: ret
    //     0x7b1014: ret             
    // 0x7b1018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b1018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b101c: b               #0x7b0ff8
  }
  _ _onChangedClipboardStatus(/* No info */) {
    // ** addr: 0x7b1020, size: 0x4c
    // 0x7b1020: EnterFrame
    //     0x7b1020: stp             fp, lr, [SP, #-0x10]!
    //     0x7b1024: mov             fp, SP
    // 0x7b1028: CheckStackOverflow
    //     0x7b1028: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b102c: cmp             SP, x16
    //     0x7b1030: b.ls            #0x7b1064
    // 0x7b1034: r1 = Function '<anonymous closure>':.
    //     0x7b1034: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b8c8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7b1038: ldr             x1, [x1, #0x8c8]
    // 0x7b103c: r2 = Null
    //     0x7b103c: mov             x2, NULL
    // 0x7b1040: r0 = AllocateClosure()
    //     0x7b1040: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b1044: ldr             x16, [fp, #0x10]
    // 0x7b1048: stp             x0, x16, [SP, #-0x10]!
    // 0x7b104c: r0 = setState()
    //     0x7b104c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b1050: add             SP, SP, #0x10
    // 0x7b1054: r0 = Null
    //     0x7b1054: mov             x0, NULL
    // 0x7b1058: LeaveFrame
    //     0x7b1058: mov             SP, fp
    //     0x7b105c: ldp             fp, lr, [SP], #0x10
    // 0x7b1060: ret
    //     0x7b1060: ret             
    // 0x7b1064: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b1064: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b1068: b               #0x7b1034
  }
  _ build(/* No info */) {
    // ** addr: 0x851ff4, size: 0x5a8
    // 0x851ff4: EnterFrame
    //     0x851ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x851ff8: mov             fp, SP
    // 0x851ffc: AllocStack(0x30)
    //     0x851ffc: sub             SP, SP, #0x30
    // 0x852000: CheckStackOverflow
    //     0x852000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x852004: cmp             SP, x16
    //     0x852008: b.ls            #0x852568
    // 0x85200c: ldr             x0, [fp, #0x18]
    // 0x852010: LoadField: r1 = r0->field_b
    //     0x852010: ldur            w1, [x0, #0xb]
    // 0x852014: DecompressPointer r1
    //     0x852014: add             x1, x1, HEAP, lsl #32
    // 0x852018: cmp             w1, NULL
    // 0x85201c: b.eq            #0x852570
    // 0x852020: LoadField: r2 = r1->field_1b
    //     0x852020: ldur            w2, [x1, #0x1b]
    // 0x852024: DecompressPointer r2
    //     0x852024: add             x2, x2, HEAP, lsl #32
    // 0x852028: cmp             w2, NULL
    // 0x85202c: b.eq            #0x85206c
    // 0x852030: LoadField: r2 = r1->field_b
    //     0x852030: ldur            w2, [x1, #0xb]
    // 0x852034: DecompressPointer r2
    //     0x852034: add             x2, x2, HEAP, lsl #32
    // 0x852038: cmp             w2, NULL
    // 0x85203c: b.eq            #0x85206c
    // 0x852040: LoadField: r1 = r2->field_27
    //     0x852040: ldur            w1, [x2, #0x27]
    // 0x852044: DecompressPointer r1
    //     0x852044: add             x1, x1, HEAP, lsl #32
    // 0x852048: r16 = Instance_ClipboardStatus
    //     0x852048: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc88] Obj!ClipboardStatus@b63451
    //     0x85204c: ldr             x16, [x16, #0xc88]
    // 0x852050: cmp             w1, w16
    // 0x852054: b.ne            #0x85206c
    // 0x852058: r0 = Instance_SizedBox
    //     0x852058: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x85205c: ldr             x0, [x0, #0x738]
    // 0x852060: LeaveFrame
    //     0x852060: mov             SP, fp
    //     0x852064: ldp             fp, lr, [SP], #0x10
    // 0x852068: ret
    //     0x852068: ret             
    // 0x85206c: ldr             x16, [fp, #0x10]
    // 0x852070: SaveReg r16
    //     0x852070: str             x16, [SP, #-8]!
    // 0x852074: r0 = of()
    //     0x852074: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x852078: add             SP, SP, #8
    // 0x85207c: mov             x1, x0
    // 0x852080: ldr             x0, [fp, #0x18]
    // 0x852084: LoadField: r2 = r0->field_b
    //     0x852084: ldur            w2, [x0, #0xb]
    // 0x852088: DecompressPointer r2
    //     0x852088: add             x2, x2, HEAP, lsl #32
    // 0x85208c: cmp             w2, NULL
    // 0x852090: b.eq            #0x852574
    // 0x852094: LoadField: r3 = r2->field_27
    //     0x852094: ldur            w3, [x2, #0x27]
    // 0x852098: DecompressPointer r3
    //     0x852098: add             x3, x3, HEAP, lsl #32
    // 0x85209c: LoadField: d0 = r3->field_7
    //     0x85209c: ldur            d0, [x3, #7]
    // 0x8520a0: LoadField: r4 = r2->field_f
    //     0x8520a0: ldur            w4, [x2, #0xf]
    // 0x8520a4: DecompressPointer r4
    //     0x8520a4: add             x4, x4, HEAP, lsl #32
    // 0x8520a8: LoadField: d1 = r4->field_7
    //     0x8520a8: ldur            d1, [x4, #7]
    // 0x8520ac: fsub            d2, d0, d1
    // 0x8520b0: LoadField: r2 = r1->field_23
    //     0x8520b0: ldur            w2, [x1, #0x23]
    // 0x8520b4: DecompressPointer r2
    //     0x8520b4: add             x2, x2, HEAP, lsl #32
    // 0x8520b8: LoadField: d0 = r2->field_7
    //     0x8520b8: ldur            d0, [x2, #7]
    // 0x8520bc: LoadField: r5 = r1->field_7
    //     0x8520bc: ldur            w5, [x1, #7]
    // 0x8520c0: DecompressPointer r5
    //     0x8520c0: add             x5, x5, HEAP, lsl #32
    // 0x8520c4: LoadField: d1 = r5->field_7
    //     0x8520c4: ldur            d1, [x5, #7]
    // 0x8520c8: LoadField: d3 = r2->field_17
    //     0x8520c8: ldur            d3, [x2, #0x17]
    // 0x8520cc: fsub            d4, d1, d3
    // 0x8520d0: fcmp            d2, d0
    // 0x8520d4: b.vs            #0x8520dc
    // 0x8520d8: b.lt            #0x852104
    // 0x8520dc: fcmp            d2, d4
    // 0x8520e0: b.vs            #0x8520f0
    // 0x8520e4: b.le            #0x8520f0
    // 0x8520e8: mov             v0.16b, v4.16b
    // 0x8520ec: b               #0x852104
    // 0x8520f0: fcmp            d2, d2
    // 0x8520f4: b.vc            #0x852100
    // 0x8520f8: mov             v0.16b, v4.16b
    // 0x8520fc: b               #0x852104
    // 0x852100: mov             v0.16b, v2.16b
    // 0x852104: stur            d0, [fp, #-0x30]
    // 0x852108: LoadField: d1 = r3->field_f
    //     0x852108: ldur            d1, [x3, #0xf]
    // 0x85210c: LoadField: d2 = r4->field_f
    //     0x85210c: ldur            d2, [x4, #0xf]
    // 0x852110: fsub            d3, d1, d2
    // 0x852114: stur            d3, [fp, #-0x28]
    // 0x852118: r0 = Offset()
    //     0x852118: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x85211c: ldur            d0, [fp, #-0x30]
    // 0x852120: stur            x0, [fp, #-8]
    // 0x852124: StoreField: r0->field_7 = d0
    //     0x852124: stur            d0, [x0, #7]
    // 0x852128: ldur            d0, [fp, #-0x28]
    // 0x85212c: StoreField: r0->field_f = d0
    //     0x85212c: stur            d0, [x0, #0xf]
    // 0x852130: ldr             x16, [fp, #0x10]
    // 0x852134: SaveReg r16
    //     0x852134: str             x16, [SP, #-8]!
    // 0x852138: r0 = of()
    //     0x852138: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x85213c: add             SP, SP, #8
    // 0x852140: r16 = <Widget>
    //     0x852140: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x852144: ldr             x16, [x16, #0xea8]
    // 0x852148: stp             xzr, x16, [SP, #-0x10]!
    // 0x85214c: r0 = _GrowableList()
    //     0x85214c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x852150: add             SP, SP, #0x10
    // 0x852154: mov             x1, x0
    // 0x852158: ldr             x0, [fp, #0x18]
    // 0x85215c: stur            x1, [fp, #-0x18]
    // 0x852160: LoadField: r2 = r0->field_b
    //     0x852160: ldur            w2, [x0, #0xb]
    // 0x852164: DecompressPointer r2
    //     0x852164: add             x2, x2, HEAP, lsl #32
    // 0x852168: cmp             w2, NULL
    // 0x85216c: b.eq            #0x852578
    // 0x852170: LoadField: r3 = r2->field_17
    //     0x852170: ldur            w3, [x2, #0x17]
    // 0x852174: DecompressPointer r3
    //     0x852174: add             x3, x3, HEAP, lsl #32
    // 0x852178: stur            x3, [fp, #-0x10]
    // 0x85217c: cmp             w3, NULL
    // 0x852180: b.eq            #0x85223c
    // 0x852184: r0 = DesktopTextSelectionToolbarButton()
    //     0x852184: bl              #0x8526a4  ; AllocateDesktopTextSelectionToolbarButtonStub -> DesktopTextSelectionToolbarButton (size=0x14)
    // 0x852188: stur            x0, [fp, #-0x20]
    // 0x85218c: ldr             x16, [fp, #0x10]
    // 0x852190: stp             x16, x0, [SP, #-0x10]!
    // 0x852194: ldur            x16, [fp, #-0x10]
    // 0x852198: r30 = "Cut"
    //     0x852198: add             lr, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Cut"
    //     0x85219c: ldr             lr, [lr, #0xdd0]
    // 0x8521a0: stp             lr, x16, [SP, #-0x10]!
    // 0x8521a4: r0 = DesktopTextSelectionToolbarButton.text()
    //     0x8521a4: bl              #0x8525a8  ; [package:flutter/src/material/desktop_text_selection_toolbar_button.dart] DesktopTextSelectionToolbarButton::DesktopTextSelectionToolbarButton.text
    // 0x8521a8: add             SP, SP, #0x20
    // 0x8521ac: ldur            x0, [fp, #-0x18]
    // 0x8521b0: LoadField: r1 = r0->field_b
    //     0x8521b0: ldur            w1, [x0, #0xb]
    // 0x8521b4: DecompressPointer r1
    //     0x8521b4: add             x1, x1, HEAP, lsl #32
    // 0x8521b8: stur            x1, [fp, #-0x10]
    // 0x8521bc: LoadField: r2 = r0->field_f
    //     0x8521bc: ldur            w2, [x0, #0xf]
    // 0x8521c0: DecompressPointer r2
    //     0x8521c0: add             x2, x2, HEAP, lsl #32
    // 0x8521c4: LoadField: r3 = r2->field_b
    //     0x8521c4: ldur            w3, [x2, #0xb]
    // 0x8521c8: DecompressPointer r3
    //     0x8521c8: add             x3, x3, HEAP, lsl #32
    // 0x8521cc: cmp             w1, w3
    // 0x8521d0: b.ne            #0x8521e0
    // 0x8521d4: SaveReg r0
    //     0x8521d4: str             x0, [SP, #-8]!
    // 0x8521d8: r0 = _growToNextCapacity()
    //     0x8521d8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8521dc: add             SP, SP, #8
    // 0x8521e0: ldur            x2, [fp, #-0x18]
    // 0x8521e4: ldur            x0, [fp, #-0x10]
    // 0x8521e8: r3 = LoadInt32Instr(r0)
    //     0x8521e8: sbfx            x3, x0, #1, #0x1f
    // 0x8521ec: add             x0, x3, #1
    // 0x8521f0: lsl             x1, x0, #1
    // 0x8521f4: StoreField: r2->field_b = r1
    //     0x8521f4: stur            w1, [x2, #0xb]
    // 0x8521f8: mov             x1, x3
    // 0x8521fc: cmp             x1, x0
    // 0x852200: b.hs            #0x85257c
    // 0x852204: LoadField: r1 = r2->field_f
    //     0x852204: ldur            w1, [x2, #0xf]
    // 0x852208: DecompressPointer r1
    //     0x852208: add             x1, x1, HEAP, lsl #32
    // 0x85220c: ldur            x0, [fp, #-0x20]
    // 0x852210: ArrayStore: r1[r3] = r0  ; List_4
    //     0x852210: add             x25, x1, x3, lsl #2
    //     0x852214: add             x25, x25, #0xf
    //     0x852218: str             w0, [x25]
    //     0x85221c: tbz             w0, #0, #0x852238
    //     0x852220: ldurb           w16, [x1, #-1]
    //     0x852224: ldurb           w17, [x0, #-1]
    //     0x852228: and             x16, x17, x16, lsr #2
    //     0x85222c: tst             x16, HEAP, lsr #32
    //     0x852230: b.eq            #0x852238
    //     0x852234: bl              #0xd67e5c
    // 0x852238: b               #0x852240
    // 0x85223c: mov             x2, x1
    // 0x852240: ldr             x0, [fp, #0x18]
    // 0x852244: LoadField: r1 = r0->field_b
    //     0x852244: ldur            w1, [x0, #0xb]
    // 0x852248: DecompressPointer r1
    //     0x852248: add             x1, x1, HEAP, lsl #32
    // 0x85224c: cmp             w1, NULL
    // 0x852250: b.eq            #0x852580
    // 0x852254: LoadField: r3 = r1->field_13
    //     0x852254: ldur            w3, [x1, #0x13]
    // 0x852258: DecompressPointer r3
    //     0x852258: add             x3, x3, HEAP, lsl #32
    // 0x85225c: stur            x3, [fp, #-0x10]
    // 0x852260: cmp             w3, NULL
    // 0x852264: b.eq            #0x85231c
    // 0x852268: r0 = DesktopTextSelectionToolbarButton()
    //     0x852268: bl              #0x8526a4  ; AllocateDesktopTextSelectionToolbarButtonStub -> DesktopTextSelectionToolbarButton (size=0x14)
    // 0x85226c: stur            x0, [fp, #-0x20]
    // 0x852270: ldr             x16, [fp, #0x10]
    // 0x852274: stp             x16, x0, [SP, #-0x10]!
    // 0x852278: ldur            x16, [fp, #-0x10]
    // 0x85227c: r30 = "Copy"
    //     0x85227c: add             lr, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Copy"
    //     0x852280: ldr             lr, [lr, #0xdd8]
    // 0x852284: stp             lr, x16, [SP, #-0x10]!
    // 0x852288: r0 = DesktopTextSelectionToolbarButton.text()
    //     0x852288: bl              #0x8525a8  ; [package:flutter/src/material/desktop_text_selection_toolbar_button.dart] DesktopTextSelectionToolbarButton::DesktopTextSelectionToolbarButton.text
    // 0x85228c: add             SP, SP, #0x20
    // 0x852290: ldur            x0, [fp, #-0x18]
    // 0x852294: LoadField: r1 = r0->field_b
    //     0x852294: ldur            w1, [x0, #0xb]
    // 0x852298: DecompressPointer r1
    //     0x852298: add             x1, x1, HEAP, lsl #32
    // 0x85229c: stur            x1, [fp, #-0x10]
    // 0x8522a0: LoadField: r2 = r0->field_f
    //     0x8522a0: ldur            w2, [x0, #0xf]
    // 0x8522a4: DecompressPointer r2
    //     0x8522a4: add             x2, x2, HEAP, lsl #32
    // 0x8522a8: LoadField: r3 = r2->field_b
    //     0x8522a8: ldur            w3, [x2, #0xb]
    // 0x8522ac: DecompressPointer r3
    //     0x8522ac: add             x3, x3, HEAP, lsl #32
    // 0x8522b0: cmp             w1, w3
    // 0x8522b4: b.ne            #0x8522c4
    // 0x8522b8: SaveReg r0
    //     0x8522b8: str             x0, [SP, #-8]!
    // 0x8522bc: r0 = _growToNextCapacity()
    //     0x8522bc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8522c0: add             SP, SP, #8
    // 0x8522c4: ldur            x2, [fp, #-0x18]
    // 0x8522c8: ldur            x0, [fp, #-0x10]
    // 0x8522cc: r3 = LoadInt32Instr(r0)
    //     0x8522cc: sbfx            x3, x0, #1, #0x1f
    // 0x8522d0: add             x0, x3, #1
    // 0x8522d4: lsl             x1, x0, #1
    // 0x8522d8: StoreField: r2->field_b = r1
    //     0x8522d8: stur            w1, [x2, #0xb]
    // 0x8522dc: mov             x1, x3
    // 0x8522e0: cmp             x1, x0
    // 0x8522e4: b.hs            #0x852584
    // 0x8522e8: LoadField: r1 = r2->field_f
    //     0x8522e8: ldur            w1, [x2, #0xf]
    // 0x8522ec: DecompressPointer r1
    //     0x8522ec: add             x1, x1, HEAP, lsl #32
    // 0x8522f0: ldur            x0, [fp, #-0x20]
    // 0x8522f4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8522f4: add             x25, x1, x3, lsl #2
    //     0x8522f8: add             x25, x25, #0xf
    //     0x8522fc: str             w0, [x25]
    //     0x852300: tbz             w0, #0, #0x85231c
    //     0x852304: ldurb           w16, [x1, #-1]
    //     0x852308: ldurb           w17, [x0, #-1]
    //     0x85230c: and             x16, x17, x16, lsr #2
    //     0x852310: tst             x16, HEAP, lsr #32
    //     0x852314: b.eq            #0x85231c
    //     0x852318: bl              #0xd67e5c
    // 0x85231c: ldr             x0, [fp, #0x18]
    // 0x852320: LoadField: r1 = r0->field_b
    //     0x852320: ldur            w1, [x0, #0xb]
    // 0x852324: DecompressPointer r1
    //     0x852324: add             x1, x1, HEAP, lsl #32
    // 0x852328: cmp             w1, NULL
    // 0x85232c: b.eq            #0x852588
    // 0x852330: LoadField: r3 = r1->field_1b
    //     0x852330: ldur            w3, [x1, #0x1b]
    // 0x852334: DecompressPointer r3
    //     0x852334: add             x3, x3, HEAP, lsl #32
    // 0x852338: stur            x3, [fp, #-0x10]
    // 0x85233c: cmp             w3, NULL
    // 0x852340: b.eq            #0x852420
    // 0x852344: LoadField: r4 = r1->field_b
    //     0x852344: ldur            w4, [x1, #0xb]
    // 0x852348: DecompressPointer r4
    //     0x852348: add             x4, x4, HEAP, lsl #32
    // 0x85234c: cmp             w4, NULL
    // 0x852350: b.eq            #0x852420
    // 0x852354: LoadField: r1 = r4->field_27
    //     0x852354: ldur            w1, [x4, #0x27]
    // 0x852358: DecompressPointer r1
    //     0x852358: add             x1, x1, HEAP, lsl #32
    // 0x85235c: r16 = Instance_ClipboardStatus
    //     0x85235c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc68] Obj!ClipboardStatus@b63491
    //     0x852360: ldr             x16, [x16, #0xc68]
    // 0x852364: cmp             w1, w16
    // 0x852368: b.ne            #0x852420
    // 0x85236c: r0 = DesktopTextSelectionToolbarButton()
    //     0x85236c: bl              #0x8526a4  ; AllocateDesktopTextSelectionToolbarButtonStub -> DesktopTextSelectionToolbarButton (size=0x14)
    // 0x852370: stur            x0, [fp, #-0x20]
    // 0x852374: ldr             x16, [fp, #0x10]
    // 0x852378: stp             x16, x0, [SP, #-0x10]!
    // 0x85237c: ldur            x16, [fp, #-0x10]
    // 0x852380: r30 = "Paste"
    //     0x852380: add             lr, PP, #0x28, lsl #12  ; [pp+0x28de0] "Paste"
    //     0x852384: ldr             lr, [lr, #0xde0]
    // 0x852388: stp             lr, x16, [SP, #-0x10]!
    // 0x85238c: r0 = DesktopTextSelectionToolbarButton.text()
    //     0x85238c: bl              #0x8525a8  ; [package:flutter/src/material/desktop_text_selection_toolbar_button.dart] DesktopTextSelectionToolbarButton::DesktopTextSelectionToolbarButton.text
    // 0x852390: add             SP, SP, #0x20
    // 0x852394: ldur            x0, [fp, #-0x18]
    // 0x852398: LoadField: r1 = r0->field_b
    //     0x852398: ldur            w1, [x0, #0xb]
    // 0x85239c: DecompressPointer r1
    //     0x85239c: add             x1, x1, HEAP, lsl #32
    // 0x8523a0: stur            x1, [fp, #-0x10]
    // 0x8523a4: LoadField: r2 = r0->field_f
    //     0x8523a4: ldur            w2, [x0, #0xf]
    // 0x8523a8: DecompressPointer r2
    //     0x8523a8: add             x2, x2, HEAP, lsl #32
    // 0x8523ac: LoadField: r3 = r2->field_b
    //     0x8523ac: ldur            w3, [x2, #0xb]
    // 0x8523b0: DecompressPointer r3
    //     0x8523b0: add             x3, x3, HEAP, lsl #32
    // 0x8523b4: cmp             w1, w3
    // 0x8523b8: b.ne            #0x8523c8
    // 0x8523bc: SaveReg r0
    //     0x8523bc: str             x0, [SP, #-8]!
    // 0x8523c0: r0 = _growToNextCapacity()
    //     0x8523c0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8523c4: add             SP, SP, #8
    // 0x8523c8: ldur            x2, [fp, #-0x18]
    // 0x8523cc: ldur            x0, [fp, #-0x10]
    // 0x8523d0: r3 = LoadInt32Instr(r0)
    //     0x8523d0: sbfx            x3, x0, #1, #0x1f
    // 0x8523d4: add             x0, x3, #1
    // 0x8523d8: lsl             x1, x0, #1
    // 0x8523dc: StoreField: r2->field_b = r1
    //     0x8523dc: stur            w1, [x2, #0xb]
    // 0x8523e0: mov             x1, x3
    // 0x8523e4: cmp             x1, x0
    // 0x8523e8: b.hs            #0x85258c
    // 0x8523ec: LoadField: r1 = r2->field_f
    //     0x8523ec: ldur            w1, [x2, #0xf]
    // 0x8523f0: DecompressPointer r1
    //     0x8523f0: add             x1, x1, HEAP, lsl #32
    // 0x8523f4: ldur            x0, [fp, #-0x20]
    // 0x8523f8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8523f8: add             x25, x1, x3, lsl #2
    //     0x8523fc: add             x25, x25, #0xf
    //     0x852400: str             w0, [x25]
    //     0x852404: tbz             w0, #0, #0x852420
    //     0x852408: ldurb           w16, [x1, #-1]
    //     0x85240c: ldurb           w17, [x0, #-1]
    //     0x852410: and             x16, x17, x16, lsr #2
    //     0x852414: tst             x16, HEAP, lsr #32
    //     0x852418: b.eq            #0x852420
    //     0x85241c: bl              #0xd67e5c
    // 0x852420: ldr             x0, [fp, #0x18]
    // 0x852424: LoadField: r1 = r0->field_b
    //     0x852424: ldur            w1, [x0, #0xb]
    // 0x852428: DecompressPointer r1
    //     0x852428: add             x1, x1, HEAP, lsl #32
    // 0x85242c: cmp             w1, NULL
    // 0x852430: b.eq            #0x852590
    // 0x852434: LoadField: r3 = r1->field_1f
    //     0x852434: ldur            w3, [x1, #0x1f]
    // 0x852438: DecompressPointer r3
    //     0x852438: add             x3, x3, HEAP, lsl #32
    // 0x85243c: stur            x3, [fp, #-0x10]
    // 0x852440: cmp             w3, NULL
    // 0x852444: b.eq            #0x8524fc
    // 0x852448: r0 = DesktopTextSelectionToolbarButton()
    //     0x852448: bl              #0x8526a4  ; AllocateDesktopTextSelectionToolbarButtonStub -> DesktopTextSelectionToolbarButton (size=0x14)
    // 0x85244c: stur            x0, [fp, #-0x20]
    // 0x852450: ldr             x16, [fp, #0x10]
    // 0x852454: stp             x16, x0, [SP, #-0x10]!
    // 0x852458: ldur            x16, [fp, #-0x10]
    // 0x85245c: r30 = "Select all"
    //     0x85245c: add             lr, PP, #0x28, lsl #12  ; [pp+0x28de8] "Select all"
    //     0x852460: ldr             lr, [lr, #0xde8]
    // 0x852464: stp             lr, x16, [SP, #-0x10]!
    // 0x852468: r0 = DesktopTextSelectionToolbarButton.text()
    //     0x852468: bl              #0x8525a8  ; [package:flutter/src/material/desktop_text_selection_toolbar_button.dart] DesktopTextSelectionToolbarButton::DesktopTextSelectionToolbarButton.text
    // 0x85246c: add             SP, SP, #0x20
    // 0x852470: ldur            x0, [fp, #-0x18]
    // 0x852474: LoadField: r1 = r0->field_b
    //     0x852474: ldur            w1, [x0, #0xb]
    // 0x852478: DecompressPointer r1
    //     0x852478: add             x1, x1, HEAP, lsl #32
    // 0x85247c: stur            x1, [fp, #-0x10]
    // 0x852480: LoadField: r2 = r0->field_f
    //     0x852480: ldur            w2, [x0, #0xf]
    // 0x852484: DecompressPointer r2
    //     0x852484: add             x2, x2, HEAP, lsl #32
    // 0x852488: LoadField: r3 = r2->field_b
    //     0x852488: ldur            w3, [x2, #0xb]
    // 0x85248c: DecompressPointer r3
    //     0x85248c: add             x3, x3, HEAP, lsl #32
    // 0x852490: cmp             w1, w3
    // 0x852494: b.ne            #0x8524a4
    // 0x852498: SaveReg r0
    //     0x852498: str             x0, [SP, #-8]!
    // 0x85249c: r0 = _growToNextCapacity()
    //     0x85249c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8524a0: add             SP, SP, #8
    // 0x8524a4: ldur            x2, [fp, #-0x18]
    // 0x8524a8: ldur            x0, [fp, #-0x10]
    // 0x8524ac: r3 = LoadInt32Instr(r0)
    //     0x8524ac: sbfx            x3, x0, #1, #0x1f
    // 0x8524b0: add             x0, x3, #1
    // 0x8524b4: lsl             x1, x0, #1
    // 0x8524b8: StoreField: r2->field_b = r1
    //     0x8524b8: stur            w1, [x2, #0xb]
    // 0x8524bc: mov             x1, x3
    // 0x8524c0: cmp             x1, x0
    // 0x8524c4: b.hs            #0x852594
    // 0x8524c8: LoadField: r1 = r2->field_f
    //     0x8524c8: ldur            w1, [x2, #0xf]
    // 0x8524cc: DecompressPointer r1
    //     0x8524cc: add             x1, x1, HEAP, lsl #32
    // 0x8524d0: ldur            x0, [fp, #-0x20]
    // 0x8524d4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8524d4: add             x25, x1, x3, lsl #2
    //     0x8524d8: add             x25, x25, #0xf
    //     0x8524dc: str             w0, [x25]
    //     0x8524e0: tbz             w0, #0, #0x8524fc
    //     0x8524e4: ldurb           w16, [x1, #-1]
    //     0x8524e8: ldurb           w17, [x0, #-1]
    //     0x8524ec: and             x16, x17, x16, lsr #2
    //     0x8524f0: tst             x16, HEAP, lsr #32
    //     0x8524f4: b.eq            #0x8524fc
    //     0x8524f8: bl              #0xd67e5c
    // 0x8524fc: LoadField: r0 = r2->field_b
    //     0x8524fc: ldur            w0, [x2, #0xb]
    // 0x852500: DecompressPointer r0
    //     0x852500: add             x0, x0, HEAP, lsl #32
    // 0x852504: cbnz            w0, #0x85251c
    // 0x852508: r0 = Instance_SizedBox
    //     0x852508: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x85250c: ldr             x0, [x0, #0x738]
    // 0x852510: LeaveFrame
    //     0x852510: mov             SP, fp
    //     0x852514: ldp             fp, lr, [SP], #0x10
    // 0x852518: ret
    //     0x852518: ret             
    // 0x85251c: ldr             x0, [fp, #0x18]
    // 0x852520: LoadField: r1 = r0->field_b
    //     0x852520: ldur            w1, [x0, #0xb]
    // 0x852524: DecompressPointer r1
    //     0x852524: add             x1, x1, HEAP, lsl #32
    // 0x852528: cmp             w1, NULL
    // 0x85252c: b.eq            #0x852598
    // 0x852530: LoadField: r0 = r1->field_23
    //     0x852530: ldur            w0, [x1, #0x23]
    // 0x852534: DecompressPointer r0
    //     0x852534: add             x0, x0, HEAP, lsl #32
    // 0x852538: cmp             w0, NULL
    // 0x85253c: b.ne            #0x852544
    // 0x852540: ldur            x0, [fp, #-8]
    // 0x852544: stur            x0, [fp, #-8]
    // 0x852548: r0 = DesktopTextSelectionToolbar()
    //     0x852548: bl              #0x85259c  ; AllocateDesktopTextSelectionToolbarStub -> DesktopTextSelectionToolbar (size=0x14)
    // 0x85254c: ldur            x1, [fp, #-8]
    // 0x852550: StoreField: r0->field_b = r1
    //     0x852550: stur            w1, [x0, #0xb]
    // 0x852554: ldur            x1, [fp, #-0x18]
    // 0x852558: StoreField: r0->field_f = r1
    //     0x852558: stur            w1, [x0, #0xf]
    // 0x85255c: LeaveFrame
    //     0x85255c: mov             SP, fp
    //     0x852560: ldp             fp, lr, [SP], #0x10
    // 0x852564: ret
    //     0x852564: ret             
    // 0x852568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x852568: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85256c: b               #0x85200c
    // 0x852570: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852570: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852574: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852574: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852578: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85257c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x85257c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852580: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852580: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852584: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852584: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852588: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x85258c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x85258c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x852594: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x852594: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x852598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x852598: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9970, size: 0x90
    // 0x9d9970: EnterFrame
    //     0x9d9970: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9974: mov             fp, SP
    // 0x9d9978: AllocStack(0x8)
    //     0x9d9978: sub             SP, SP, #8
    // 0x9d997c: CheckStackOverflow
    //     0x9d997c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9980: cmp             SP, x16
    //     0x9d9984: b.ls            #0x9d99f4
    // 0x9d9988: ldr             x0, [fp, #0x10]
    // 0x9d998c: LoadField: r1 = r0->field_b
    //     0x9d998c: ldur            w1, [x0, #0xb]
    // 0x9d9990: DecompressPointer r1
    //     0x9d9990: add             x1, x1, HEAP, lsl #32
    // 0x9d9994: cmp             w1, NULL
    // 0x9d9998: b.eq            #0x9d99fc
    // 0x9d999c: LoadField: r2 = r1->field_b
    //     0x9d999c: ldur            w2, [x1, #0xb]
    // 0x9d99a0: DecompressPointer r2
    //     0x9d99a0: add             x2, x2, HEAP, lsl #32
    // 0x9d99a4: stur            x2, [fp, #-8]
    // 0x9d99a8: cmp             w2, NULL
    // 0x9d99ac: b.eq            #0x9d99e4
    // 0x9d99b0: r1 = 1
    //     0x9d99b0: mov             x1, #1
    // 0x9d99b4: r0 = AllocateContext()
    //     0x9d99b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d99b8: mov             x1, x0
    // 0x9d99bc: ldr             x0, [fp, #0x10]
    // 0x9d99c0: StoreField: r1->field_f = r0
    //     0x9d99c0: stur            w0, [x1, #0xf]
    // 0x9d99c4: mov             x2, x1
    // 0x9d99c8: r1 = Function '_onChangedClipboardStatus@721113492':.
    //     0x9d99c8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b8c0] AnonymousClosure: (0x7b0fd8), in [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7b1020)
    //     0x9d99cc: ldr             x1, [x1, #0x8c0]
    // 0x9d99d0: r0 = AllocateClosure()
    //     0x9d99d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d99d4: ldur            x16, [fp, #-8]
    // 0x9d99d8: stp             x0, x16, [SP, #-0x10]!
    // 0x9d99dc: r0 = addListener()
    //     0x9d99dc: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x9d99e0: add             SP, SP, #0x10
    // 0x9d99e4: r0 = Null
    //     0x9d99e4: mov             x0, NULL
    // 0x9d99e8: LeaveFrame
    //     0x9d99e8: mov             SP, fp
    //     0x9d99ec: ldp             fp, lr, [SP], #0x10
    // 0x9d99f0: ret
    //     0x9d99f0: ret             
    // 0x9d99f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d99f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d99f8: b               #0x9d9988
    // 0x9d99fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d99fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4ab28, size: 0x18
    // 0xa4ab28: r4 = 7
    //     0xa4ab28: mov             x4, #7
    // 0xa4ab2c: r1 = Function 'dispose':.
    //     0xa4ab2c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b8b8] AnonymousClosure: (0xa4ab40), in [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::dispose (0xa51530)
    //     0xa4ab30: ldr             x1, [x17, #0x8b8]
    // 0xa4ab34: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4ab34: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4ab38: LoadField: r0 = r24->field_17
    //     0xa4ab38: ldur            x0, [x24, #0x17]
    // 0xa4ab3c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4ab40, size: 0x48
    // 0xa4ab40: EnterFrame
    //     0xa4ab40: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ab44: mov             fp, SP
    // 0xa4ab48: ldr             x0, [fp, #0x10]
    // 0xa4ab4c: LoadField: r1 = r0->field_17
    //     0xa4ab4c: ldur            w1, [x0, #0x17]
    // 0xa4ab50: DecompressPointer r1
    //     0xa4ab50: add             x1, x1, HEAP, lsl #32
    // 0xa4ab54: CheckStackOverflow
    //     0xa4ab54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ab58: cmp             SP, x16
    //     0xa4ab5c: b.ls            #0xa4ab80
    // 0xa4ab60: LoadField: r0 = r1->field_f
    //     0xa4ab60: ldur            w0, [x1, #0xf]
    // 0xa4ab64: DecompressPointer r0
    //     0xa4ab64: add             x0, x0, HEAP, lsl #32
    // 0xa4ab68: SaveReg r0
    //     0xa4ab68: str             x0, [SP, #-8]!
    // 0xa4ab6c: r0 = dispose()
    //     0xa4ab6c: bl              #0xa51530  ; [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::dispose
    // 0xa4ab70: add             SP, SP, #8
    // 0xa4ab74: LeaveFrame
    //     0xa4ab74: mov             SP, fp
    //     0xa4ab78: ldp             fp, lr, [SP], #0x10
    // 0xa4ab7c: ret
    //     0xa4ab7c: ret             
    // 0xa4ab80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ab80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ab84: b               #0xa4ab60
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa51530, size: 0x90
    // 0xa51530: EnterFrame
    //     0xa51530: stp             fp, lr, [SP, #-0x10]!
    //     0xa51534: mov             fp, SP
    // 0xa51538: AllocStack(0x8)
    //     0xa51538: sub             SP, SP, #8
    // 0xa5153c: CheckStackOverflow
    //     0xa5153c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa51540: cmp             SP, x16
    //     0xa51544: b.ls            #0xa515b4
    // 0xa51548: ldr             x0, [fp, #0x10]
    // 0xa5154c: LoadField: r1 = r0->field_b
    //     0xa5154c: ldur            w1, [x0, #0xb]
    // 0xa51550: DecompressPointer r1
    //     0xa51550: add             x1, x1, HEAP, lsl #32
    // 0xa51554: cmp             w1, NULL
    // 0xa51558: b.eq            #0xa515bc
    // 0xa5155c: LoadField: r2 = r1->field_b
    //     0xa5155c: ldur            w2, [x1, #0xb]
    // 0xa51560: DecompressPointer r2
    //     0xa51560: add             x2, x2, HEAP, lsl #32
    // 0xa51564: stur            x2, [fp, #-8]
    // 0xa51568: cmp             w2, NULL
    // 0xa5156c: b.eq            #0xa515a4
    // 0xa51570: r1 = 1
    //     0xa51570: mov             x1, #1
    // 0xa51574: r0 = AllocateContext()
    //     0xa51574: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa51578: mov             x1, x0
    // 0xa5157c: ldr             x0, [fp, #0x10]
    // 0xa51580: StoreField: r1->field_f = r0
    //     0xa51580: stur            w0, [x1, #0xf]
    // 0xa51584: mov             x2, x1
    // 0xa51588: r1 = Function '_onChangedClipboardStatus@721113492':.
    //     0xa51588: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b8c0] AnonymousClosure: (0x7b0fd8), in [package:flutter/src/material/desktop_text_selection.dart] _DesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7b1020)
    //     0xa5158c: ldr             x1, [x1, #0x8c0]
    // 0xa51590: r0 = AllocateClosure()
    //     0xa51590: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa51594: ldur            x16, [fp, #-8]
    // 0xa51598: stp             x0, x16, [SP, #-0x10]!
    // 0xa5159c: r0 = removeListener()
    //     0xa5159c: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0xa515a0: add             SP, SP, #0x10
    // 0xa515a4: r0 = Null
    //     0xa515a4: mov             x0, NULL
    // 0xa515a8: LeaveFrame
    //     0xa515a8: mov             SP, fp
    //     0xa515ac: ldp             fp, lr, [SP], #0x10
    // 0xa515b0: ret
    //     0xa515b0: ret             
    // 0xa515b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa515b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa515b8: b               #0xa51548
    // 0xa515bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa515bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4158, size: 0x2c, field offset: 0xc
//   const constructor, 
class _DesktopTextSelectionControlsToolbar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa4049c, size: 0x20
    // 0xa4049c: EnterFrame
    //     0xa4049c: stp             fp, lr, [SP, #-0x10]!
    //     0xa404a0: mov             fp, SP
    // 0xa404a4: r1 = <_DesktopTextSelectionControlsToolbar>
    //     0xa404a4: add             x1, PP, #0x40, lsl #12  ; [pp+0x401e8] TypeArguments: <_DesktopTextSelectionControlsToolbar>
    //     0xa404a8: ldr             x1, [x1, #0x1e8]
    // 0xa404ac: r0 = _DesktopTextSelectionControlsToolbarState()
    //     0xa404ac: bl              #0xa404bc  ; Allocate_DesktopTextSelectionControlsToolbarStateStub -> _DesktopTextSelectionControlsToolbarState (size=0x14)
    // 0xa404b0: LeaveFrame
    //     0xa404b0: mov             SP, fp
    //     0xa404b4: ldp             fp, lr, [SP], #0x10
    // 0xa404b8: ret
    //     0xa404b8: ret             
  }
}

// class id: 4241, size: 0x8, field offset: 0x8
class DesktopTextSelectionControls extends TextSelectionControls {

  _ buildToolbar(/* No info */) {
    // ** addr: 0xc394b4, size: 0x18c
    // 0xc394b4: EnterFrame
    //     0xc394b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc394b8: mov             fp, SP
    // 0xc394bc: AllocStack(0x20)
    //     0xc394bc: sub             SP, SP, #0x20
    // 0xc394c0: CheckStackOverflow
    //     0xc394c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc394c4: cmp             SP, x16
    //     0xc394c8: b.ls            #0xc39638
    // 0xc394cc: r1 = 2
    //     0xc394cc: mov             x1, #2
    // 0xc394d0: r0 = AllocateContext()
    //     0xc394d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc394d4: mov             x1, x0
    // 0xc394d8: ldr             x0, [fp, #0x48]
    // 0xc394dc: stur            x1, [fp, #-8]
    // 0xc394e0: StoreField: r1->field_f = r0
    //     0xc394e0: stur            w0, [x1, #0xf]
    // 0xc394e4: ldr             x2, [fp, #0x20]
    // 0xc394e8: StoreField: r1->field_13 = r2
    //     0xc394e8: stur            w2, [x1, #0x13]
    // 0xc394ec: stp             x2, x0, [SP, #-0x10]!
    // 0xc394f0: r0 = canCut()
    //     0xc394f0: bl              #0xc0a7ac  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCut
    // 0xc394f4: add             SP, SP, #0x10
    // 0xc394f8: tbnz            w0, #4, #0xc39510
    // 0xc394fc: ldur            x2, [fp, #-8]
    // 0xc39500: r1 = Function '<anonymous closure>':.
    //     0xc39500: add             x1, PP, #0x37, lsl #12  ; [pp+0x37928] AnonymousClosure: (0xc39268), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39504: ldr             x1, [x1, #0x928]
    // 0xc39508: r0 = AllocateClosure()
    //     0xc39508: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc3950c: b               #0xc39514
    // 0xc39510: r0 = Null
    //     0xc39510: mov             x0, NULL
    // 0xc39514: ldur            x2, [fp, #-8]
    // 0xc39518: stur            x0, [fp, #-0x10]
    // 0xc3951c: LoadField: r1 = r2->field_13
    //     0xc3951c: ldur            w1, [x2, #0x13]
    // 0xc39520: DecompressPointer r1
    //     0xc39520: add             x1, x1, HEAP, lsl #32
    // 0xc39524: ldr             x16, [fp, #0x48]
    // 0xc39528: stp             x1, x16, [SP, #-0x10]!
    // 0xc3952c: r0 = canCopy()
    //     0xc3952c: bl              #0xc035f0  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCopy
    // 0xc39530: add             SP, SP, #0x10
    // 0xc39534: tbnz            w0, #4, #0xc3954c
    // 0xc39538: ldur            x2, [fp, #-8]
    // 0xc3953c: r1 = Function '<anonymous closure>':.
    //     0xc3953c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37930] AnonymousClosure: (0xc39214), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39540: ldr             x1, [x1, #0x930]
    // 0xc39544: r0 = AllocateClosure()
    //     0xc39544: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39548: b               #0xc39550
    // 0xc3954c: r0 = Null
    //     0xc3954c: mov             x0, NULL
    // 0xc39550: ldur            x2, [fp, #-8]
    // 0xc39554: stur            x0, [fp, #-0x18]
    // 0xc39558: LoadField: r1 = r2->field_13
    //     0xc39558: ldur            w1, [x2, #0x13]
    // 0xc3955c: DecompressPointer r1
    //     0xc3955c: add             x1, x1, HEAP, lsl #32
    // 0xc39560: SaveReg r1
    //     0xc39560: str             x1, [SP, #-8]!
    // 0xc39564: r0 = pasteEnabled()
    //     0xc39564: bl              #0x7a2b88  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::pasteEnabled
    // 0xc39568: add             SP, SP, #8
    // 0xc3956c: tbnz            w0, #4, #0xc39584
    // 0xc39570: ldur            x2, [fp, #-8]
    // 0xc39574: r1 = Function '<anonymous closure>':.
    //     0xc39574: add             x1, PP, #0x37, lsl #12  ; [pp+0x37938] AnonymousClosure: (0xc391c4), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39578: ldr             x1, [x1, #0x938]
    // 0xc3957c: r0 = AllocateClosure()
    //     0xc3957c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39580: b               #0xc39588
    // 0xc39584: r0 = Null
    //     0xc39584: mov             x0, NULL
    // 0xc39588: ldur            x2, [fp, #-8]
    // 0xc3958c: stur            x0, [fp, #-0x20]
    // 0xc39590: LoadField: r1 = r2->field_13
    //     0xc39590: ldur            w1, [x2, #0x13]
    // 0xc39594: DecompressPointer r1
    //     0xc39594: add             x1, x1, HEAP, lsl #32
    // 0xc39598: ldr             x16, [fp, #0x48]
    // 0xc3959c: stp             x1, x16, [SP, #-0x10]!
    // 0xc395a0: r0 = canSelectAll()
    //     0xc395a0: bl              #0xc3964c  ; [package:flutter/src/material/desktop_text_selection.dart] DesktopTextSelectionControls::canSelectAll
    // 0xc395a4: add             SP, SP, #0x10
    // 0xc395a8: tbnz            w0, #4, #0xc395c4
    // 0xc395ac: ldur            x2, [fp, #-8]
    // 0xc395b0: r1 = Function '<anonymous closure>':.
    //     0xc395b0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37940] AnonymousClosure: (0xc396ec), in [package:flutter/src/material/desktop_text_selection.dart] DesktopTextSelectionControls::buildToolbar (0xc394b4)
    //     0xc395b4: ldr             x1, [x1, #0x940]
    // 0xc395b8: r0 = AllocateClosure()
    //     0xc395b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc395bc: mov             x7, x0
    // 0xc395c0: b               #0xc395c8
    // 0xc395c4: r7 = Null
    //     0xc395c4: mov             x7, NULL
    // 0xc395c8: ldr             x6, [fp, #0x40]
    // 0xc395cc: ldr             x5, [fp, #0x30]
    // 0xc395d0: ldr             x4, [fp, #0x18]
    // 0xc395d4: ldr             x3, [fp, #0x10]
    // 0xc395d8: ldur            x2, [fp, #-0x10]
    // 0xc395dc: ldur            x1, [fp, #-0x18]
    // 0xc395e0: ldur            x0, [fp, #-0x20]
    // 0xc395e4: stur            x7, [fp, #-8]
    // 0xc395e8: r0 = _DesktopTextSelectionControlsToolbar()
    //     0xc395e8: bl              #0xc39640  ; Allocate_DesktopTextSelectionControlsToolbarStub -> _DesktopTextSelectionControlsToolbar (size=0x2c)
    // 0xc395ec: ldr             x1, [fp, #0x18]
    // 0xc395f0: StoreField: r0->field_b = r1
    //     0xc395f0: stur            w1, [x0, #0xb]
    // 0xc395f4: ldr             x1, [fp, #0x40]
    // 0xc395f8: StoreField: r0->field_f = r1
    //     0xc395f8: stur            w1, [x0, #0xf]
    // 0xc395fc: ldur            x1, [fp, #-0x18]
    // 0xc39600: StoreField: r0->field_13 = r1
    //     0xc39600: stur            w1, [x0, #0x13]
    // 0xc39604: ldur            x1, [fp, #-0x10]
    // 0xc39608: StoreField: r0->field_17 = r1
    //     0xc39608: stur            w1, [x0, #0x17]
    // 0xc3960c: ldur            x1, [fp, #-0x20]
    // 0xc39610: StoreField: r0->field_1b = r1
    //     0xc39610: stur            w1, [x0, #0x1b]
    // 0xc39614: ldur            x1, [fp, #-8]
    // 0xc39618: StoreField: r0->field_1f = r1
    //     0xc39618: stur            w1, [x0, #0x1f]
    // 0xc3961c: ldr             x1, [fp, #0x30]
    // 0xc39620: StoreField: r0->field_27 = r1
    //     0xc39620: stur            w1, [x0, #0x27]
    // 0xc39624: ldr             x1, [fp, #0x10]
    // 0xc39628: StoreField: r0->field_23 = r1
    //     0xc39628: stur            w1, [x0, #0x23]
    // 0xc3962c: LeaveFrame
    //     0xc3962c: mov             SP, fp
    //     0xc39630: ldp             fp, lr, [SP], #0x10
    // 0xc39634: ret
    //     0xc39634: ret             
    // 0xc39638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc39638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3963c: b               #0xc394cc
  }
  _ canSelectAll(/* No info */) {
    // ** addr: 0xc3964c, size: 0xa0
    // 0xc3964c: EnterFrame
    //     0xc3964c: stp             fp, lr, [SP, #-0x10]!
    //     0xc39650: mov             fp, SP
    // 0xc39654: ldr             x1, [fp, #0x10]
    // 0xc39658: LoadField: r2 = r1->field_b
    //     0xc39658: ldur            w2, [x1, #0xb]
    // 0xc3965c: DecompressPointer r2
    //     0xc3965c: add             x2, x2, HEAP, lsl #32
    // 0xc39660: cmp             w2, NULL
    // 0xc39664: b.eq            #0xc396e8
    // 0xc39668: LoadField: r1 = r2->field_13
    //     0xc39668: ldur            w1, [x2, #0x13]
    // 0xc3966c: DecompressPointer r1
    //     0xc3966c: add             x1, x1, HEAP, lsl #32
    // 0xc39670: LoadField: r3 = r1->field_27
    //     0xc39670: ldur            w3, [x1, #0x27]
    // 0xc39674: DecompressPointer r3
    //     0xc39674: add             x3, x3, HEAP, lsl #32
    // 0xc39678: LoadField: r1 = r2->field_33
    //     0xc39678: ldur            w1, [x2, #0x33]
    // 0xc3967c: DecompressPointer r1
    //     0xc3967c: add             x1, x1, HEAP, lsl #32
    // 0xc39680: LoadField: r2 = r1->field_13
    //     0xc39680: ldur            w2, [x1, #0x13]
    // 0xc39684: DecompressPointer r2
    //     0xc39684: add             x2, x2, HEAP, lsl #32
    // 0xc39688: tbnz            w2, #4, #0xc396d8
    // 0xc3968c: LoadField: r1 = r3->field_7
    //     0xc3968c: ldur            w1, [x3, #7]
    // 0xc39690: DecompressPointer r1
    //     0xc39690: add             x1, x1, HEAP, lsl #32
    // 0xc39694: LoadField: r2 = r1->field_7
    //     0xc39694: ldur            w2, [x1, #7]
    // 0xc39698: DecompressPointer r2
    //     0xc39698: add             x2, x2, HEAP, lsl #32
    // 0xc3969c: cbz             w2, #0xc396d8
    // 0xc396a0: LoadField: r1 = r3->field_b
    //     0xc396a0: ldur            w1, [x3, #0xb]
    // 0xc396a4: DecompressPointer r1
    //     0xc396a4: add             x1, x1, HEAP, lsl #32
    // 0xc396a8: LoadField: r3 = r1->field_7
    //     0xc396a8: ldur            x3, [x1, #7]
    // 0xc396ac: cbnz            x3, #0xc396d0
    // 0xc396b0: LoadField: r3 = r1->field_f
    //     0xc396b0: ldur            x3, [x1, #0xf]
    // 0xc396b4: r1 = LoadInt32Instr(r2)
    //     0xc396b4: sbfx            x1, x2, #1, #0x1f
    // 0xc396b8: cmp             x3, x1
    // 0xc396bc: r16 = true
    //     0xc396bc: add             x16, NULL, #0x20  ; true
    // 0xc396c0: r17 = false
    //     0xc396c0: add             x17, NULL, #0x30  ; false
    // 0xc396c4: csel            x2, x16, x17, ne
    // 0xc396c8: mov             x0, x2
    // 0xc396cc: b               #0xc396dc
    // 0xc396d0: r0 = true
    //     0xc396d0: add             x0, NULL, #0x20  ; true
    // 0xc396d4: b               #0xc396dc
    // 0xc396d8: r0 = false
    //     0xc396d8: add             x0, NULL, #0x30  ; false
    // 0xc396dc: LeaveFrame
    //     0xc396dc: mov             SP, fp
    //     0xc396e0: ldp             fp, lr, [SP], #0x10
    // 0xc396e4: ret
    //     0xc396e4: ret             
    // 0xc396e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc396e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc396ec, size: 0x50
    // 0xc396ec: EnterFrame
    //     0xc396ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc396f0: mov             fp, SP
    // 0xc396f4: ldr             x0, [fp, #0x10]
    // 0xc396f8: LoadField: r1 = r0->field_17
    //     0xc396f8: ldur            w1, [x0, #0x17]
    // 0xc396fc: DecompressPointer r1
    //     0xc396fc: add             x1, x1, HEAP, lsl #32
    // 0xc39700: CheckStackOverflow
    //     0xc39700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc39704: cmp             SP, x16
    //     0xc39708: b.ls            #0xc39734
    // 0xc3970c: LoadField: r0 = r1->field_f
    //     0xc3970c: ldur            w0, [x1, #0xf]
    // 0xc39710: DecompressPointer r0
    //     0xc39710: add             x0, x0, HEAP, lsl #32
    // 0xc39714: LoadField: r2 = r1->field_13
    //     0xc39714: ldur            w2, [x1, #0x13]
    // 0xc39718: DecompressPointer r2
    //     0xc39718: add             x2, x2, HEAP, lsl #32
    // 0xc3971c: stp             x2, x0, [SP, #-0x10]!
    // 0xc39720: r0 = handleSelectAll()
    //     0xc39720: bl              #0xc39030  ; [package:flutter/src/cupertino/desktop_text_selection.dart] CupertinoDesktopTextSelectionControls::handleSelectAll
    // 0xc39724: add             SP, SP, #0x10
    // 0xc39728: LeaveFrame
    //     0xc39728: mov             SP, fp
    //     0xc3972c: ldp             fp, lr, [SP], #0x10
    // 0xc39730: ret
    //     0xc39730: ret             
    // 0xc39734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc39734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc39738: b               #0xc3970c
  }
  _ getHandleAnchor(/* No info */) {
    // ** addr: 0xc527e4, size: 0x8
    // 0xc527e4: r0 = Instance_Offset
    //     0xc527e4: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xc527e8: ret
    //     0xc527e8: ret             
  }
  _ getHandleSize(/* No info */) {
    // ** addr: 0xcbab60, size: 0x8
    // 0xcbab60: r0 = Instance_Size
    //     0xcbab60: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xcbab64: ret
    //     0xcbab64: ret             
  }
}

// class id: 4242, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class __DesktopTextSelectionHandleControls&DesktopTextSelectionControls&TextSelectionHandleControls extends DesktopTextSelectionControls
     with TextSelectionHandleControls {
}

// class id: 4243, size: 0x8, field offset: 0x8
class _DesktopTextSelectionHandleControls extends __DesktopTextSelectionHandleControls&DesktopTextSelectionControls&TextSelectionHandleControls {
}

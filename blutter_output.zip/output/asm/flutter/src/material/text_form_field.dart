// lib: , url: package:flutter/src/material/text_form_field.dart

// class id: 1049324, size: 0x8
class :: {
}

// class id: 3268, size: 0x34, field offset: 0x30
class _TextFormFieldState extends FormFieldState<FormField<String>> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7befdc, size: 0x190
    // 0x7befdc: EnterFrame
    //     0x7befdc: stp             fp, lr, [SP, #-0x10]!
    //     0x7befe0: mov             fp, SP
    // 0x7befe4: AllocStack(0x8)
    //     0x7befe4: sub             SP, SP, #8
    // 0x7befe8: CheckStackOverflow
    //     0x7befe8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7befec: cmp             SP, x16
    //     0x7beff0: b.ls            #0x7bf158
    // 0x7beff4: ldr             x0, [fp, #0x10]
    // 0x7beff8: r2 = Null
    //     0x7beff8: mov             x2, NULL
    // 0x7beffc: r1 = Null
    //     0x7beffc: mov             x1, NULL
    // 0x7bf000: r4 = 59
    //     0x7bf000: mov             x4, #0x3b
    // 0x7bf004: branchIfSmi(r0, 0x7bf010)
    //     0x7bf004: tbz             w0, #0, #0x7bf010
    // 0x7bf008: r4 = LoadClassIdInstr(r0)
    //     0x7bf008: ldur            x4, [x0, #-1]
    //     0x7bf00c: ubfx            x4, x4, #0xc, #0x14
    // 0x7bf010: r17 = 4114
    //     0x7bf010: mov             x17, #0x1012
    // 0x7bf014: cmp             x4, x17
    // 0x7bf018: b.eq            #0x7bf030
    // 0x7bf01c: r8 = TextFormField<String>
    //     0x7bf01c: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fef8] Type: TextFormField<String>
    //     0x7bf020: ldr             x8, [x8, #0xef8]
    // 0x7bf024: r3 = Null
    //     0x7bf024: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3ff00] Null
    //     0x7bf028: ldr             x3, [x3, #0xf00]
    // 0x7bf02c: r0 = DefaultTypeTest()
    //     0x7bf02c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x7bf030: ldr             x16, [fp, #0x18]
    // 0x7bf034: ldr             lr, [fp, #0x10]
    // 0x7bf038: stp             lr, x16, [SP, #-0x10]!
    // 0x7bf03c: r0 = didUpdateWidget()
    //     0x7bf03c: bl              #0x7bf218  ; [package:flutter/src/widgets/form.dart] _FormFieldState&State&RestorationMixin::didUpdateWidget
    // 0x7bf040: add             SP, SP, #0x10
    // 0x7bf044: ldr             x0, [fp, #0x18]
    // 0x7bf048: LoadField: r1 = r0->field_b
    //     0x7bf048: ldur            w1, [x0, #0xb]
    // 0x7bf04c: DecompressPointer r1
    //     0x7bf04c: add             x1, x1, HEAP, lsl #32
    // 0x7bf050: cmp             w1, NULL
    // 0x7bf054: b.eq            #0x7bf160
    // 0x7bf058: LoadField: r2 = r1->field_27
    //     0x7bf058: ldur            w2, [x1, #0x27]
    // 0x7bf05c: DecompressPointer r2
    //     0x7bf05c: add             x2, x2, HEAP, lsl #32
    // 0x7bf060: ldr             x1, [fp, #0x10]
    // 0x7bf064: LoadField: r3 = r1->field_27
    //     0x7bf064: ldur            w3, [x1, #0x27]
    // 0x7bf068: DecompressPointer r3
    //     0x7bf068: add             x3, x3, HEAP, lsl #32
    // 0x7bf06c: stur            x3, [fp, #-8]
    // 0x7bf070: cmp             w2, w3
    // 0x7bf074: b.eq            #0x7bf148
    // 0x7bf078: r1 = 1
    //     0x7bf078: mov             x1, #1
    // 0x7bf07c: r0 = AllocateContext()
    //     0x7bf07c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bf080: mov             x1, x0
    // 0x7bf084: ldr             x0, [fp, #0x18]
    // 0x7bf088: StoreField: r1->field_f = r0
    //     0x7bf088: stur            w0, [x1, #0xf]
    // 0x7bf08c: mov             x2, x1
    // 0x7bf090: r1 = Function '_handleControllerChanged@824147271':.
    //     0x7bf090: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee8] AnonymousClosure: (0x7bf2c0), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0x7bf308)
    //     0x7bf094: ldr             x1, [x1, #0xee8]
    // 0x7bf098: r0 = AllocateClosure()
    //     0x7bf098: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bf09c: ldur            x16, [fp, #-8]
    // 0x7bf0a0: stp             x0, x16, [SP, #-0x10]!
    // 0x7bf0a4: r0 = removeListener()
    //     0x7bf0a4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7bf0a8: add             SP, SP, #0x10
    // 0x7bf0ac: ldr             x0, [fp, #0x18]
    // 0x7bf0b0: LoadField: r1 = r0->field_b
    //     0x7bf0b0: ldur            w1, [x0, #0xb]
    // 0x7bf0b4: DecompressPointer r1
    //     0x7bf0b4: add             x1, x1, HEAP, lsl #32
    // 0x7bf0b8: cmp             w1, NULL
    // 0x7bf0bc: b.eq            #0x7bf164
    // 0x7bf0c0: LoadField: r2 = r1->field_27
    //     0x7bf0c0: ldur            w2, [x1, #0x27]
    // 0x7bf0c4: DecompressPointer r2
    //     0x7bf0c4: add             x2, x2, HEAP, lsl #32
    // 0x7bf0c8: stur            x2, [fp, #-8]
    // 0x7bf0cc: r1 = 1
    //     0x7bf0cc: mov             x1, #1
    // 0x7bf0d0: r0 = AllocateContext()
    //     0x7bf0d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bf0d4: mov             x1, x0
    // 0x7bf0d8: ldr             x0, [fp, #0x18]
    // 0x7bf0dc: StoreField: r1->field_f = r0
    //     0x7bf0dc: stur            w0, [x1, #0xf]
    // 0x7bf0e0: mov             x2, x1
    // 0x7bf0e4: r1 = Function '_handleControllerChanged@824147271':.
    //     0x7bf0e4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee8] AnonymousClosure: (0x7bf2c0), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0x7bf308)
    //     0x7bf0e8: ldr             x1, [x1, #0xee8]
    // 0x7bf0ec: r0 = AllocateClosure()
    //     0x7bf0ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bf0f0: ldur            x16, [fp, #-8]
    // 0x7bf0f4: stp             x0, x16, [SP, #-0x10]!
    // 0x7bf0f8: r0 = addListener()
    //     0x7bf0f8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7bf0fc: add             SP, SP, #0x10
    // 0x7bf100: ldr             x1, [fp, #0x18]
    // 0x7bf104: LoadField: r2 = r1->field_b
    //     0x7bf104: ldur            w2, [x1, #0xb]
    // 0x7bf108: DecompressPointer r2
    //     0x7bf108: add             x2, x2, HEAP, lsl #32
    // 0x7bf10c: cmp             w2, NULL
    // 0x7bf110: b.eq            #0x7bf168
    // 0x7bf114: LoadField: r3 = r2->field_27
    //     0x7bf114: ldur            w3, [x2, #0x27]
    // 0x7bf118: DecompressPointer r3
    //     0x7bf118: add             x3, x3, HEAP, lsl #32
    // 0x7bf11c: LoadField: r2 = r3->field_27
    //     0x7bf11c: ldur            w2, [x3, #0x27]
    // 0x7bf120: DecompressPointer r2
    //     0x7bf120: add             x2, x2, HEAP, lsl #32
    // 0x7bf124: LoadField: r0 = r2->field_7
    //     0x7bf124: ldur            w0, [x2, #7]
    // 0x7bf128: DecompressPointer r0
    //     0x7bf128: add             x0, x0, HEAP, lsl #32
    // 0x7bf12c: StoreField: r1->field_23 = r0
    //     0x7bf12c: stur            w0, [x1, #0x23]
    //     0x7bf130: ldurb           w16, [x1, #-1]
    //     0x7bf134: ldurb           w17, [x0, #-1]
    //     0x7bf138: and             x16, x17, x16, lsr #2
    //     0x7bf13c: tst             x16, HEAP, lsr #32
    //     0x7bf140: b.eq            #0x7bf148
    //     0x7bf144: bl              #0xd6826c
    // 0x7bf148: r0 = Null
    //     0x7bf148: mov             x0, NULL
    // 0x7bf14c: LeaveFrame
    //     0x7bf14c: mov             SP, fp
    //     0x7bf150: ldp             fp, lr, [SP], #0x10
    // 0x7bf154: ret
    //     0x7bf154: ret             
    // 0x7bf158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf15c: b               #0x7beff4
    // 0x7bf160: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf160: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bf164: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf164: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bf168: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf168: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleControllerChanged(dynamic) {
    // ** addr: 0x7bf2c0, size: 0x48
    // 0x7bf2c0: EnterFrame
    //     0x7bf2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf2c4: mov             fp, SP
    // 0x7bf2c8: ldr             x0, [fp, #0x10]
    // 0x7bf2cc: LoadField: r1 = r0->field_17
    //     0x7bf2cc: ldur            w1, [x0, #0x17]
    // 0x7bf2d0: DecompressPointer r1
    //     0x7bf2d0: add             x1, x1, HEAP, lsl #32
    // 0x7bf2d4: CheckStackOverflow
    //     0x7bf2d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf2d8: cmp             SP, x16
    //     0x7bf2dc: b.ls            #0x7bf300
    // 0x7bf2e0: LoadField: r0 = r1->field_f
    //     0x7bf2e0: ldur            w0, [x1, #0xf]
    // 0x7bf2e4: DecompressPointer r0
    //     0x7bf2e4: add             x0, x0, HEAP, lsl #32
    // 0x7bf2e8: SaveReg r0
    //     0x7bf2e8: str             x0, [SP, #-8]!
    // 0x7bf2ec: r0 = _handleControllerChanged()
    //     0x7bf2ec: bl              #0x7bf308  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged
    // 0x7bf2f0: add             SP, SP, #8
    // 0x7bf2f4: LeaveFrame
    //     0x7bf2f4: mov             SP, fp
    //     0x7bf2f8: ldp             fp, lr, [SP], #0x10
    // 0x7bf2fc: ret
    //     0x7bf2fc: ret             
    // 0x7bf300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf304: b               #0x7bf2e0
  }
  _ _handleControllerChanged(/* No info */) {
    // ** addr: 0x7bf308, size: 0xf0
    // 0x7bf308: EnterFrame
    //     0x7bf308: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf30c: mov             fp, SP
    // 0x7bf310: AllocStack(0x8)
    //     0x7bf310: sub             SP, SP, #8
    // 0x7bf314: CheckStackOverflow
    //     0x7bf314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf318: cmp             SP, x16
    //     0x7bf31c: b.ls            #0x7bf3e8
    // 0x7bf320: ldr             x0, [fp, #0x10]
    // 0x7bf324: LoadField: r1 = r0->field_b
    //     0x7bf324: ldur            w1, [x0, #0xb]
    // 0x7bf328: DecompressPointer r1
    //     0x7bf328: add             x1, x1, HEAP, lsl #32
    // 0x7bf32c: cmp             w1, NULL
    // 0x7bf330: b.eq            #0x7bf3f0
    // 0x7bf334: LoadField: r2 = r1->field_27
    //     0x7bf334: ldur            w2, [x1, #0x27]
    // 0x7bf338: DecompressPointer r2
    //     0x7bf338: add             x2, x2, HEAP, lsl #32
    // 0x7bf33c: LoadField: r1 = r2->field_27
    //     0x7bf33c: ldur            w1, [x2, #0x27]
    // 0x7bf340: DecompressPointer r1
    //     0x7bf340: add             x1, x1, HEAP, lsl #32
    // 0x7bf344: LoadField: r2 = r1->field_7
    //     0x7bf344: ldur            w2, [x1, #7]
    // 0x7bf348: DecompressPointer r2
    //     0x7bf348: add             x2, x2, HEAP, lsl #32
    // 0x7bf34c: mov             x1, x0
    // 0x7bf350: stur            x2, [fp, #-8]
    // 0x7bf354: LoadField: r0 = r1->field_23
    //     0x7bf354: ldur            w0, [x1, #0x23]
    // 0x7bf358: DecompressPointer r0
    //     0x7bf358: add             x0, x0, HEAP, lsl #32
    // 0x7bf35c: r16 = Sentinel
    //     0x7bf35c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7bf360: cmp             w0, w16
    // 0x7bf364: b.ne            #0x7bf374
    // 0x7bf368: r2 = _value
    //     0x7bf368: add             x2, PP, #0x3f, lsl #12  ; [pp+0x3fef0] Field <FormFieldState._value@992032539>: late (offset: 0x24)
    //     0x7bf36c: ldr             x2, [x2, #0xef0]
    // 0x7bf370: r0 = InitLateInstanceField()
    //     0x7bf370: bl              #0xd67c38  ; InitLateInstanceFieldStub
    // 0x7bf374: mov             x1, x0
    // 0x7bf378: ldur            x0, [fp, #-8]
    // 0x7bf37c: r2 = LoadClassIdInstr(r0)
    //     0x7bf37c: ldur            x2, [x0, #-1]
    //     0x7bf380: ubfx            x2, x2, #0xc, #0x14
    // 0x7bf384: stp             x1, x0, [SP, #-0x10]!
    // 0x7bf388: mov             x0, x2
    // 0x7bf38c: mov             lr, x0
    // 0x7bf390: ldr             lr, [x21, lr, lsl #3]
    // 0x7bf394: blr             lr
    // 0x7bf398: add             SP, SP, #0x10
    // 0x7bf39c: tbz             w0, #4, #0x7bf3d8
    // 0x7bf3a0: ldr             x0, [fp, #0x10]
    // 0x7bf3a4: LoadField: r1 = r0->field_b
    //     0x7bf3a4: ldur            w1, [x0, #0xb]
    // 0x7bf3a8: DecompressPointer r1
    //     0x7bf3a8: add             x1, x1, HEAP, lsl #32
    // 0x7bf3ac: cmp             w1, NULL
    // 0x7bf3b0: b.eq            #0x7bf3f4
    // 0x7bf3b4: LoadField: r2 = r1->field_27
    //     0x7bf3b4: ldur            w2, [x1, #0x27]
    // 0x7bf3b8: DecompressPointer r2
    //     0x7bf3b8: add             x2, x2, HEAP, lsl #32
    // 0x7bf3bc: LoadField: r1 = r2->field_27
    //     0x7bf3bc: ldur            w1, [x2, #0x27]
    // 0x7bf3c0: DecompressPointer r1
    //     0x7bf3c0: add             x1, x1, HEAP, lsl #32
    // 0x7bf3c4: LoadField: r2 = r1->field_7
    //     0x7bf3c4: ldur            w2, [x1, #7]
    // 0x7bf3c8: DecompressPointer r2
    //     0x7bf3c8: add             x2, x2, HEAP, lsl #32
    // 0x7bf3cc: stp             x2, x0, [SP, #-0x10]!
    // 0x7bf3d0: r0 = didChange()
    //     0x7bf3d0: bl              #0x7bf42c  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::didChange
    // 0x7bf3d4: add             SP, SP, #0x10
    // 0x7bf3d8: r0 = Null
    //     0x7bf3d8: mov             x0, NULL
    // 0x7bf3dc: LeaveFrame
    //     0x7bf3dc: mov             SP, fp
    //     0x7bf3e0: ldp             fp, lr, [SP], #0x10
    // 0x7bf3e4: ret
    //     0x7bf3e4: ret             
    // 0x7bf3e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf3e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf3ec: b               #0x7bf320
    // 0x7bf3f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf3f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bf3f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf3f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _effectiveController(/* No info */) {
    // ** addr: 0x7bf3f8, size: 0x34
    // 0x7bf3f8: EnterFrame
    //     0x7bf3f8: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf3fc: mov             fp, SP
    // 0x7bf400: ldr             x1, [fp, #0x10]
    // 0x7bf404: LoadField: r2 = r1->field_b
    //     0x7bf404: ldur            w2, [x1, #0xb]
    // 0x7bf408: DecompressPointer r2
    //     0x7bf408: add             x2, x2, HEAP, lsl #32
    // 0x7bf40c: cmp             w2, NULL
    // 0x7bf410: b.eq            #0x7bf428
    // 0x7bf414: LoadField: r0 = r2->field_27
    //     0x7bf414: ldur            w0, [x2, #0x27]
    // 0x7bf418: DecompressPointer r0
    //     0x7bf418: add             x0, x0, HEAP, lsl #32
    // 0x7bf41c: LeaveFrame
    //     0x7bf41c: mov             SP, fp
    //     0x7bf420: ldp             fp, lr, [SP], #0x10
    // 0x7bf424: ret
    //     0x7bf424: ret             
    // 0x7bf428: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf428: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChange(/* No info */) {
    // ** addr: 0x7bf42c, size: 0xc4
    // 0x7bf42c: EnterFrame
    //     0x7bf42c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf430: mov             fp, SP
    // 0x7bf434: CheckStackOverflow
    //     0x7bf434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf438: cmp             SP, x16
    //     0x7bf43c: b.ls            #0x7bf4e0
    // 0x7bf440: ldr             x16, [fp, #0x18]
    // 0x7bf444: ldr             lr, [fp, #0x10]
    // 0x7bf448: stp             lr, x16, [SP, #-0x10]!
    // 0x7bf44c: r0 = didChange()
    //     0x7bf44c: bl              #0x7bf4f0  ; [package:flutter/src/widgets/form.dart] FormFieldState::didChange
    // 0x7bf450: add             SP, SP, #0x10
    // 0x7bf454: ldr             x1, [fp, #0x18]
    // 0x7bf458: LoadField: r0 = r1->field_b
    //     0x7bf458: ldur            w0, [x1, #0xb]
    // 0x7bf45c: DecompressPointer r0
    //     0x7bf45c: add             x0, x0, HEAP, lsl #32
    // 0x7bf460: cmp             w0, NULL
    // 0x7bf464: b.eq            #0x7bf4e8
    // 0x7bf468: LoadField: r2 = r0->field_27
    //     0x7bf468: ldur            w2, [x0, #0x27]
    // 0x7bf46c: DecompressPointer r2
    //     0x7bf46c: add             x2, x2, HEAP, lsl #32
    // 0x7bf470: LoadField: r0 = r2->field_27
    //     0x7bf470: ldur            w0, [x2, #0x27]
    // 0x7bf474: DecompressPointer r0
    //     0x7bf474: add             x0, x0, HEAP, lsl #32
    // 0x7bf478: LoadField: r2 = r0->field_7
    //     0x7bf478: ldur            w2, [x0, #7]
    // 0x7bf47c: DecompressPointer r2
    //     0x7bf47c: add             x2, x2, HEAP, lsl #32
    // 0x7bf480: r0 = LoadClassIdInstr(r2)
    //     0x7bf480: ldur            x0, [x2, #-1]
    //     0x7bf484: ubfx            x0, x0, #0xc, #0x14
    // 0x7bf488: ldr             x16, [fp, #0x10]
    // 0x7bf48c: stp             x16, x2, [SP, #-0x10]!
    // 0x7bf490: mov             lr, x0
    // 0x7bf494: ldr             lr, [x21, lr, lsl #3]
    // 0x7bf498: blr             lr
    // 0x7bf49c: add             SP, SP, #0x10
    // 0x7bf4a0: tbz             w0, #4, #0x7bf4d0
    // 0x7bf4a4: ldr             x0, [fp, #0x18]
    // 0x7bf4a8: LoadField: r1 = r0->field_b
    //     0x7bf4a8: ldur            w1, [x0, #0xb]
    // 0x7bf4ac: DecompressPointer r1
    //     0x7bf4ac: add             x1, x1, HEAP, lsl #32
    // 0x7bf4b0: cmp             w1, NULL
    // 0x7bf4b4: b.eq            #0x7bf4ec
    // 0x7bf4b8: LoadField: r0 = r1->field_27
    //     0x7bf4b8: ldur            w0, [x1, #0x27]
    // 0x7bf4bc: DecompressPointer r0
    //     0x7bf4bc: add             x0, x0, HEAP, lsl #32
    // 0x7bf4c0: ldr             x16, [fp, #0x10]
    // 0x7bf4c4: stp             x16, x0, [SP, #-0x10]!
    // 0x7bf4c8: r0 = text=()
    //     0x7bf4c8: bl              #0x79a774  ; [package:flutter/src/widgets/editable_text.dart] TextEditingController::text=
    // 0x7bf4cc: add             SP, SP, #0x10
    // 0x7bf4d0: r0 = Null
    //     0x7bf4d0: mov             x0, NULL
    // 0x7bf4d4: LeaveFrame
    //     0x7bf4d4: mov             SP, fp
    //     0x7bf4d8: ldp             fp, lr, [SP], #0x10
    // 0x7bf4dc: ret
    //     0x7bf4dc: ret             
    // 0x7bf4e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf4e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf4e4: b               #0x7bf440
    // 0x7bf4e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf4e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7bf4ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf4ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dbff4, size: 0x88
    // 0x9dbff4: EnterFrame
    //     0x9dbff4: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbff8: mov             fp, SP
    // 0x9dbffc: AllocStack(0x8)
    //     0x9dbffc: sub             SP, SP, #8
    // 0x9dc000: CheckStackOverflow
    //     0x9dc000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc004: cmp             SP, x16
    //     0x9dc008: b.ls            #0x9dc070
    // 0x9dc00c: ldr             x0, [fp, #0x10]
    // 0x9dc010: LoadField: r1 = r0->field_b
    //     0x9dc010: ldur            w1, [x0, #0xb]
    // 0x9dc014: DecompressPointer r1
    //     0x9dc014: add             x1, x1, HEAP, lsl #32
    // 0x9dc018: cmp             w1, NULL
    // 0x9dc01c: b.eq            #0x9dc078
    // 0x9dc020: LoadField: r2 = r1->field_27
    //     0x9dc020: ldur            w2, [x1, #0x27]
    // 0x9dc024: DecompressPointer r2
    //     0x9dc024: add             x2, x2, HEAP, lsl #32
    // 0x9dc028: stur            x2, [fp, #-8]
    // 0x9dc02c: r1 = 1
    //     0x9dc02c: mov             x1, #1
    // 0x9dc030: r0 = AllocateContext()
    //     0x9dc030: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dc034: mov             x1, x0
    // 0x9dc038: ldr             x0, [fp, #0x10]
    // 0x9dc03c: StoreField: r1->field_f = r0
    //     0x9dc03c: stur            w0, [x1, #0xf]
    // 0x9dc040: mov             x2, x1
    // 0x9dc044: r1 = Function '_handleControllerChanged@824147271':.
    //     0x9dc044: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee8] AnonymousClosure: (0x7bf2c0), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0x7bf308)
    //     0x9dc048: ldr             x1, [x1, #0xee8]
    // 0x9dc04c: r0 = AllocateClosure()
    //     0x9dc04c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dc050: ldur            x16, [fp, #-8]
    // 0x9dc054: stp             x0, x16, [SP, #-0x10]!
    // 0x9dc058: r0 = addListener()
    //     0x9dc058: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9dc05c: add             SP, SP, #0x10
    // 0x9dc060: r0 = Null
    //     0x9dc060: mov             x0, NULL
    // 0x9dc064: LeaveFrame
    //     0x9dc064: mov             SP, fp
    //     0x9dc068: ldp             fp, lr, [SP], #0x10
    // 0x9dc06c: ret
    //     0x9dc06c: ret             
    // 0x9dc070: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc070: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc074: b               #0x9dc00c
    // 0x9dc078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc078: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b368, size: 0x18
    // 0xa4b368: r4 = 7
    //     0xa4b368: mov             x4, #7
    // 0xa4b36c: r1 = Function 'dispose':.
    //     0xa4b36c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b558] AnonymousClosure: (0xa4b380), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::dispose (0xa53078)
    //     0xa4b370: ldr             x1, [x17, #0x558]
    // 0xa4b374: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b374: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b378: LoadField: r0 = r24->field_17
    //     0xa4b378: ldur            x0, [x24, #0x17]
    // 0xa4b37c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b380, size: 0x48
    // 0xa4b380: EnterFrame
    //     0xa4b380: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b384: mov             fp, SP
    // 0xa4b388: ldr             x0, [fp, #0x10]
    // 0xa4b38c: LoadField: r1 = r0->field_17
    //     0xa4b38c: ldur            w1, [x0, #0x17]
    // 0xa4b390: DecompressPointer r1
    //     0xa4b390: add             x1, x1, HEAP, lsl #32
    // 0xa4b394: CheckStackOverflow
    //     0xa4b394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b398: cmp             SP, x16
    //     0xa4b39c: b.ls            #0xa4b3c0
    // 0xa4b3a0: LoadField: r0 = r1->field_f
    //     0xa4b3a0: ldur            w0, [x1, #0xf]
    // 0xa4b3a4: DecompressPointer r0
    //     0xa4b3a4: add             x0, x0, HEAP, lsl #32
    // 0xa4b3a8: SaveReg r0
    //     0xa4b3a8: str             x0, [SP, #-8]!
    // 0xa4b3ac: r0 = dispose()
    //     0xa4b3ac: bl              #0xa53078  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::dispose
    // 0xa4b3b0: add             SP, SP, #8
    // 0xa4b3b4: LeaveFrame
    //     0xa4b3b4: mov             SP, fp
    //     0xa4b3b8: ldp             fp, lr, [SP], #0x10
    // 0xa4b3bc: ret
    //     0xa4b3bc: ret             
    // 0xa4b3c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b3c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b3c4: b               #0xa4b3a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa53078, size: 0xb8
    // 0xa53078: EnterFrame
    //     0xa53078: stp             fp, lr, [SP, #-0x10]!
    //     0xa5307c: mov             fp, SP
    // 0xa53080: AllocStack(0x8)
    //     0xa53080: sub             SP, SP, #8
    // 0xa53084: CheckStackOverflow
    //     0xa53084: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa53088: cmp             SP, x16
    //     0xa5308c: b.ls            #0xa53124
    // 0xa53090: ldr             x0, [fp, #0x10]
    // 0xa53094: LoadField: r1 = r0->field_b
    //     0xa53094: ldur            w1, [x0, #0xb]
    // 0xa53098: DecompressPointer r1
    //     0xa53098: add             x1, x1, HEAP, lsl #32
    // 0xa5309c: cmp             w1, NULL
    // 0xa530a0: b.eq            #0xa5312c
    // 0xa530a4: LoadField: r2 = r1->field_27
    //     0xa530a4: ldur            w2, [x1, #0x27]
    // 0xa530a8: DecompressPointer r2
    //     0xa530a8: add             x2, x2, HEAP, lsl #32
    // 0xa530ac: stur            x2, [fp, #-8]
    // 0xa530b0: r1 = 1
    //     0xa530b0: mov             x1, #1
    // 0xa530b4: r0 = AllocateContext()
    //     0xa530b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa530b8: mov             x1, x0
    // 0xa530bc: ldr             x0, [fp, #0x10]
    // 0xa530c0: StoreField: r1->field_f = r0
    //     0xa530c0: stur            w0, [x1, #0xf]
    // 0xa530c4: mov             x2, x1
    // 0xa530c8: r1 = Function '_handleControllerChanged@824147271':.
    //     0xa530c8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fee8] AnonymousClosure: (0x7bf2c0), in [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_handleControllerChanged (0x7bf308)
    //     0xa530cc: ldr             x1, [x1, #0xee8]
    // 0xa530d0: r0 = AllocateClosure()
    //     0xa530d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa530d4: ldur            x16, [fp, #-8]
    // 0xa530d8: stp             x0, x16, [SP, #-0x10]!
    // 0xa530dc: r0 = removeListener()
    //     0xa530dc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa530e0: add             SP, SP, #0x10
    // 0xa530e4: ldr             x0, [fp, #0x10]
    // 0xa530e8: LoadField: r1 = r0->field_2f
    //     0xa530e8: ldur            w1, [x0, #0x2f]
    // 0xa530ec: DecompressPointer r1
    //     0xa530ec: add             x1, x1, HEAP, lsl #32
    // 0xa530f0: cmp             w1, NULL
    // 0xa530f4: b.eq            #0xa53104
    // 0xa530f8: SaveReg r1
    //     0xa530f8: str             x1, [SP, #-8]!
    // 0xa530fc: r0 = dispose()
    //     0xa530fc: bl              #0x9c29bc  ; [package:flutter/src/widgets/restoration_properties.dart] RestorableChangeNotifier::dispose
    // 0xa53100: add             SP, SP, #8
    // 0xa53104: ldr             x16, [fp, #0x10]
    // 0xa53108: SaveReg r16
    //     0xa53108: str             x16, [SP, #-8]!
    // 0xa5310c: r0 = dispose()
    //     0xa5310c: bl              #0xa53130  ; [package:flutter/src/widgets/form.dart] _FormFieldState&State&RestorationMixin::dispose
    // 0xa53110: add             SP, SP, #8
    // 0xa53114: r0 = Null
    //     0xa53114: mov             x0, NULL
    // 0xa53118: LeaveFrame
    //     0xa53118: mov             SP, fp
    //     0xa5311c: ldp             fp, lr, [SP], #0x10
    // 0xa53120: ret
    //     0xa53120: ret             
    // 0xa53124: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53124: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa53128: b               #0xa53090
    // 0xa5312c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5312c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ restoreState(/* No info */) {
    // ** addr: 0xa6238c, size: 0xac
    // 0xa6238c: EnterFrame
    //     0xa6238c: stp             fp, lr, [SP, #-0x10]!
    //     0xa62390: mov             fp, SP
    // 0xa62394: CheckStackOverflow
    //     0xa62394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa62398: cmp             SP, x16
    //     0xa6239c: b.ls            #0xa6242c
    // 0xa623a0: ldr             x16, [fp, #0x18]
    // 0xa623a4: ldr             lr, [fp, #0x10]
    // 0xa623a8: stp             lr, x16, [SP, #-0x10]!
    // 0xa623ac: r0 = restoreState()
    //     0xa623ac: bl              #0xa625c4  ; [package:flutter/src/widgets/form.dart] FormFieldState::restoreState
    // 0xa623b0: add             SP, SP, #0x10
    // 0xa623b4: ldr             x0, [fp, #0x18]
    // 0xa623b8: LoadField: r1 = r0->field_2f
    //     0xa623b8: ldur            w1, [x0, #0x2f]
    // 0xa623bc: DecompressPointer r1
    //     0xa623bc: add             x1, x1, HEAP, lsl #32
    // 0xa623c0: cmp             w1, NULL
    // 0xa623c4: b.eq            #0xa623d4
    // 0xa623c8: SaveReg r0
    //     0xa623c8: str             x0, [SP, #-8]!
    // 0xa623cc: r0 = _registerController()
    //     0xa623cc: bl              #0xa62438  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_registerController
    // 0xa623d0: add             SP, SP, #8
    // 0xa623d4: ldr             x1, [fp, #0x18]
    // 0xa623d8: LoadField: r2 = r1->field_b
    //     0xa623d8: ldur            w2, [x1, #0xb]
    // 0xa623dc: DecompressPointer r2
    //     0xa623dc: add             x2, x2, HEAP, lsl #32
    // 0xa623e0: cmp             w2, NULL
    // 0xa623e4: b.eq            #0xa62434
    // 0xa623e8: LoadField: r3 = r2->field_27
    //     0xa623e8: ldur            w3, [x2, #0x27]
    // 0xa623ec: DecompressPointer r3
    //     0xa623ec: add             x3, x3, HEAP, lsl #32
    // 0xa623f0: LoadField: r2 = r3->field_27
    //     0xa623f0: ldur            w2, [x3, #0x27]
    // 0xa623f4: DecompressPointer r2
    //     0xa623f4: add             x2, x2, HEAP, lsl #32
    // 0xa623f8: LoadField: r0 = r2->field_7
    //     0xa623f8: ldur            w0, [x2, #7]
    // 0xa623fc: DecompressPointer r0
    //     0xa623fc: add             x0, x0, HEAP, lsl #32
    // 0xa62400: StoreField: r1->field_23 = r0
    //     0xa62400: stur            w0, [x1, #0x23]
    //     0xa62404: ldurb           w16, [x1, #-1]
    //     0xa62408: ldurb           w17, [x0, #-1]
    //     0xa6240c: and             x16, x17, x16, lsr #2
    //     0xa62410: tst             x16, HEAP, lsr #32
    //     0xa62414: b.eq            #0xa6241c
    //     0xa62418: bl              #0xd6826c
    // 0xa6241c: r0 = Null
    //     0xa6241c: mov             x0, NULL
    // 0xa62420: LeaveFrame
    //     0xa62420: mov             SP, fp
    //     0xa62424: ldp             fp, lr, [SP], #0x10
    // 0xa62428: ret
    //     0xa62428: ret             
    // 0xa6242c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6242c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62430: b               #0xa623a0
    // 0xa62434: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa62434: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _registerController(/* No info */) {
    // ** addr: 0xa62438, size: 0x58
    // 0xa62438: EnterFrame
    //     0xa62438: stp             fp, lr, [SP, #-0x10]!
    //     0xa6243c: mov             fp, SP
    // 0xa62440: CheckStackOverflow
    //     0xa62440: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa62444: cmp             SP, x16
    //     0xa62448: b.ls            #0xa62484
    // 0xa6244c: ldr             x0, [fp, #0x10]
    // 0xa62450: LoadField: r1 = r0->field_2f
    //     0xa62450: ldur            w1, [x0, #0x2f]
    // 0xa62454: DecompressPointer r1
    //     0xa62454: add             x1, x1, HEAP, lsl #32
    // 0xa62458: cmp             w1, NULL
    // 0xa6245c: b.eq            #0xa6248c
    // 0xa62460: stp             x1, x0, [SP, #-0x10]!
    // 0xa62464: r16 = "controller"
    //     0xa62464: ldr             x16, [PP, #0x5018]  ; [pp+0x5018] "controller"
    // 0xa62468: SaveReg r16
    //     0xa62468: str             x16, [SP, #-8]!
    // 0xa6246c: r0 = registerForRestoration()
    //     0xa6246c: bl              #0xa62490  ; [package:flutter/src/widgets/form.dart] _FormFieldState&State&RestorationMixin::registerForRestoration
    // 0xa62470: add             SP, SP, #0x18
    // 0xa62474: r0 = Null
    //     0xa62474: mov             x0, NULL
    // 0xa62478: LeaveFrame
    //     0xa62478: mov             SP, fp
    //     0xa6247c: ldp             fp, lr, [SP], #0x10
    // 0xa62480: ret
    //     0xa62480: ret             
    // 0xa62484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa62488: b               #0xa6244c
    // 0xa6248c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa6248c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4114, size: 0x2c, field offset: 0x28
class TextFormField extends FormField<String> {

  _ TextFormField(/* No info */) {
    // ** addr: 0x8b0354, size: 0x290
    // 0x8b0354: EnterFrame
    //     0x8b0354: stp             fp, lr, [SP, #-0x10]!
    //     0x8b0358: mov             fp, SP
    // 0x8b035c: AllocStack(0x40)
    //     0x8b035c: sub             SP, SP, #0x40
    // 0x8b0360: SetupParameters(TextFormField<String> this /* r3, fp-0x40 */, dynamic _ /* r4, fp-0x38 */, dynamic _ /* r5, fp-0x30 */, dynamic _ /* r6, fp-0x28 */, {dynamic cursorColor = Null /* r2, fp-0x20 */, dynamic maxLines = 2 /* r7, fp-0x18 */, dynamic minLines = Null /* r8, fp-0x10 */, dynamic obscureText = false /* r0, fp-0x8 */})
    //     0x8b0360: mov             x0, x4
    //     0x8b0364: ldur            w1, [x0, #0x13]
    //     0x8b0368: add             x1, x1, HEAP, lsl #32
    //     0x8b036c: sub             x2, x1, #8
    //     0x8b0370: add             x3, fp, w2, sxtw #2
    //     0x8b0374: ldr             x3, [x3, #0x28]
    //     0x8b0378: stur            x3, [fp, #-0x40]
    //     0x8b037c: add             x4, fp, w2, sxtw #2
    //     0x8b0380: ldr             x4, [x4, #0x20]
    //     0x8b0384: stur            x4, [fp, #-0x38]
    //     0x8b0388: add             x5, fp, w2, sxtw #2
    //     0x8b038c: ldr             x5, [x5, #0x18]
    //     0x8b0390: stur            x5, [fp, #-0x30]
    //     0x8b0394: add             x6, fp, w2, sxtw #2
    //     0x8b0398: ldr             x6, [x6, #0x10]
    //     0x8b039c: stur            x6, [fp, #-0x28]
    //     0x8b03a0: ldur            w2, [x0, #0x1f]
    //     0x8b03a4: add             x2, x2, HEAP, lsl #32
    //     0x8b03a8: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c090] "cursorColor"
    //     0x8b03ac: ldr             x16, [x16, #0x90]
    //     0x8b03b0: cmp             w2, w16
    //     0x8b03b4: b.ne            #0x8b03d4
    //     0x8b03b8: ldur            w2, [x0, #0x23]
    //     0x8b03bc: add             x2, x2, HEAP, lsl #32
    //     0x8b03c0: sub             w7, w1, w2
    //     0x8b03c4: add             x2, fp, w7, sxtw #2
    //     0x8b03c8: ldr             x2, [x2, #8]
    //     0x8b03cc: mov             x7, #1
    //     0x8b03d0: b               #0x8b03dc
    //     0x8b03d4: mov             x7, #0
    //     0x8b03d8: mov             x2, NULL
    //     0x8b03dc: stur            x2, [fp, #-0x20]
    //     0x8b03e0: lsl             x8, x7, #1
    //     0x8b03e4: lsl             w9, w8, #1
    //     0x8b03e8: add             w10, w9, #8
    //     0x8b03ec: add             x16, x0, w10, sxtw #1
    //     0x8b03f0: ldur            w11, [x16, #0xf]
    //     0x8b03f4: add             x11, x11, HEAP, lsl #32
    //     0x8b03f8: add             x16, PP, #0x15, lsl #12  ; [pp+0x15110] "maxLines"
    //     0x8b03fc: ldr             x16, [x16, #0x110]
    //     0x8b0400: cmp             w11, w16
    //     0x8b0404: b.ne            #0x8b0434
    //     0x8b0408: add             w7, w9, #0xa
    //     0x8b040c: add             x16, x0, w7, sxtw #1
    //     0x8b0410: ldur            w9, [x16, #0xf]
    //     0x8b0414: add             x9, x9, HEAP, lsl #32
    //     0x8b0418: sub             w7, w1, w9
    //     0x8b041c: add             x9, fp, w7, sxtw #2
    //     0x8b0420: ldr             x9, [x9, #8]
    //     0x8b0424: add             w7, w8, #2
    //     0x8b0428: sbfx            x8, x7, #1, #0x1f
    //     0x8b042c: mov             x7, x9
    //     0x8b0430: b               #0x8b043c
    //     0x8b0434: mov             x8, x7
    //     0x8b0438: mov             x7, #2
    //     0x8b043c: stur            x7, [fp, #-0x18]
    //     0x8b0440: lsl             x9, x8, #1
    //     0x8b0444: lsl             w10, w9, #1
    //     0x8b0448: add             w11, w10, #8
    //     0x8b044c: add             x16, x0, w11, sxtw #1
    //     0x8b0450: ldur            w12, [x16, #0xf]
    //     0x8b0454: add             x12, x12, HEAP, lsl #32
    //     0x8b0458: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c098] "minLines"
    //     0x8b045c: ldr             x16, [x16, #0x98]
    //     0x8b0460: cmp             w12, w16
    //     0x8b0464: b.ne            #0x8b0494
    //     0x8b0468: add             w8, w10, #0xa
    //     0x8b046c: add             x16, x0, w8, sxtw #1
    //     0x8b0470: ldur            w10, [x16, #0xf]
    //     0x8b0474: add             x10, x10, HEAP, lsl #32
    //     0x8b0478: sub             w8, w1, w10
    //     0x8b047c: add             x10, fp, w8, sxtw #2
    //     0x8b0480: ldr             x10, [x10, #8]
    //     0x8b0484: add             w8, w9, #2
    //     0x8b0488: sbfx            x9, x8, #1, #0x1f
    //     0x8b048c: mov             x8, x10
    //     0x8b0490: b               #0x8b049c
    //     0x8b0494: mov             x9, x8
    //     0x8b0498: mov             x8, NULL
    //     0x8b049c: stur            x8, [fp, #-0x10]
    //     0x8b04a0: lsl             x10, x9, #1
    //     0x8b04a4: lsl             w9, w10, #1
    //     0x8b04a8: add             w10, w9, #8
    //     0x8b04ac: add             x16, x0, w10, sxtw #1
    //     0x8b04b0: ldur            w11, [x16, #0xf]
    //     0x8b04b4: add             x11, x11, HEAP, lsl #32
    //     0x8b04b8: ldr             x16, [PP, #0x61b8]  ; [pp+0x61b8] "obscureText"
    //     0x8b04bc: cmp             w11, w16
    //     0x8b04c0: b.ne            #0x8b04e8
    //     0x8b04c4: add             w10, w9, #0xa
    //     0x8b04c8: add             x16, x0, w10, sxtw #1
    //     0x8b04cc: ldur            w9, [x16, #0xf]
    //     0x8b04d0: add             x9, x9, HEAP, lsl #32
    //     0x8b04d4: sub             w0, w1, w9
    //     0x8b04d8: add             x1, fp, w0, sxtw #2
    //     0x8b04dc: ldr             x1, [x1, #8]
    //     0x8b04e0: mov             x0, x1
    //     0x8b04e4: b               #0x8b04ec
    //     0x8b04e8: add             x0, NULL, #0x30  ; false
    //     0x8b04ec: stur            x0, [fp, #-8]
    // 0x8b04f0: r1 = 6
    //     0x8b04f0: mov             x1, #6
    // 0x8b04f4: r0 = AllocateContext()
    //     0x8b04f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8b04f8: mov             x2, x0
    // 0x8b04fc: ldur            x1, [fp, #-0x30]
    // 0x8b0500: StoreField: r2->field_f = r1
    //     0x8b0500: stur            w1, [x2, #0xf]
    // 0x8b0504: ldur            x0, [fp, #-0x28]
    // 0x8b0508: StoreField: r2->field_13 = r0
    //     0x8b0508: stur            w0, [x2, #0x13]
    // 0x8b050c: ldur            x0, [fp, #-0x20]
    // 0x8b0510: StoreField: r2->field_17 = r0
    //     0x8b0510: stur            w0, [x2, #0x17]
    // 0x8b0514: ldur            x0, [fp, #-0x18]
    // 0x8b0518: StoreField: r2->field_1b = r0
    //     0x8b0518: stur            w0, [x2, #0x1b]
    // 0x8b051c: ldur            x0, [fp, #-0x10]
    // 0x8b0520: StoreField: r2->field_1f = r0
    //     0x8b0520: stur            w0, [x2, #0x1f]
    // 0x8b0524: ldur            x0, [fp, #-8]
    // 0x8b0528: StoreField: r2->field_23 = r0
    //     0x8b0528: stur            w0, [x2, #0x23]
    // 0x8b052c: ldur            x0, [fp, #-0x38]
    // 0x8b0530: ldur            x3, [fp, #-0x40]
    // 0x8b0534: StoreField: r3->field_27 = r0
    //     0x8b0534: stur            w0, [x3, #0x27]
    //     0x8b0538: ldurb           w16, [x3, #-1]
    //     0x8b053c: ldurb           w17, [x0, #-1]
    //     0x8b0540: and             x16, x17, x16, lsr #2
    //     0x8b0544: tst             x16, HEAP, lsr #32
    //     0x8b0548: b.eq            #0x8b0550
    //     0x8b054c: bl              #0xd682ac
    // 0x8b0550: ldur            x0, [fp, #-0x38]
    // 0x8b0554: LoadField: r4 = r0->field_27
    //     0x8b0554: ldur            w4, [x0, #0x27]
    // 0x8b0558: DecompressPointer r4
    //     0x8b0558: add             x4, x4, HEAP, lsl #32
    // 0x8b055c: LoadField: r0 = r4->field_7
    //     0x8b055c: ldur            w0, [x4, #7]
    // 0x8b0560: DecompressPointer r0
    //     0x8b0560: add             x0, x0, HEAP, lsl #32
    // 0x8b0564: stur            x0, [fp, #-0x10]
    // 0x8b0568: LoadField: r4 = r1->field_bf
    //     0x8b0568: ldur            w4, [x1, #0xbf]
    // 0x8b056c: DecompressPointer r4
    //     0x8b056c: add             x4, x4, HEAP, lsl #32
    // 0x8b0570: stur            x4, [fp, #-8]
    // 0x8b0574: r1 = Function '<anonymous closure>':.
    //     0x8b0574: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0a0] AnonymousClosure: (0x8b05e4), in [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField (0x8b0354)
    //     0x8b0578: ldr             x1, [x1, #0xa0]
    // 0x8b057c: r0 = AllocateClosure()
    //     0x8b057c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8b0580: ldur            x1, [fp, #-0x40]
    // 0x8b0584: StoreField: r1->field_13 = r0
    //     0x8b0584: stur            w0, [x1, #0x13]
    //     0x8b0588: ldurb           w16, [x1, #-1]
    //     0x8b058c: ldurb           w17, [x0, #-1]
    //     0x8b0590: and             x16, x17, x16, lsr #2
    //     0x8b0594: tst             x16, HEAP, lsr #32
    //     0x8b0598: b.eq            #0x8b05a0
    //     0x8b059c: bl              #0xd6826c
    // 0x8b05a0: ldur            x0, [fp, #-0x10]
    // 0x8b05a4: StoreField: r1->field_17 = r0
    //     0x8b05a4: stur            w0, [x1, #0x17]
    //     0x8b05a8: ldurb           w16, [x1, #-1]
    //     0x8b05ac: ldurb           w17, [x0, #-1]
    //     0x8b05b0: and             x16, x17, x16, lsr #2
    //     0x8b05b4: tst             x16, HEAP, lsr #32
    //     0x8b05b8: b.eq            #0x8b05c0
    //     0x8b05bc: bl              #0xd6826c
    // 0x8b05c0: ldur            x2, [fp, #-8]
    // 0x8b05c4: StoreField: r1->field_1b = r2
    //     0x8b05c4: stur            w2, [x1, #0x1b]
    // 0x8b05c8: r2 = Instance_AutovalidateMode
    //     0x8b05c8: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c0a8] Obj!AutovalidateMode@b63bd1
    //     0x8b05cc: ldr             x2, [x2, #0xa8]
    // 0x8b05d0: StoreField: r1->field_1f = r2
    //     0x8b05d0: stur            w2, [x1, #0x1f]
    // 0x8b05d4: r0 = Null
    //     0x8b05d4: mov             x0, NULL
    // 0x8b05d8: LeaveFrame
    //     0x8b05d8: mov             SP, fp
    //     0x8b05dc: ldp             fp, lr, [SP], #0x10
    // 0x8b05e0: ret
    //     0x8b05e0: ret             
  }
  [closure] UnmanagedRestorationScope <anonymous closure>(dynamic, FormFieldState<String>) {
    // ** addr: 0x8b05e4, size: 0x30c
    // 0x8b05e4: EnterFrame
    //     0x8b05e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8b05e8: mov             fp, SP
    // 0x8b05ec: AllocStack(0x60)
    //     0x8b05ec: sub             SP, SP, #0x60
    // 0x8b05f0: SetupParameters()
    //     0x8b05f0: ldr             x0, [fp, #0x18]
    //     0x8b05f4: ldur            w1, [x0, #0x17]
    //     0x8b05f8: add             x1, x1, HEAP, lsl #32
    //     0x8b05fc: stur            x1, [fp, #-8]
    // 0x8b0600: CheckStackOverflow
    //     0x8b0600: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8b0604: cmp             SP, x16
    //     0x8b0608: b.ls            #0x8b08e4
    // 0x8b060c: r1 = 1
    //     0x8b060c: mov             x1, #1
    // 0x8b0610: r0 = AllocateContext()
    //     0x8b0610: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8b0614: mov             x4, x0
    // 0x8b0618: ldur            x3, [fp, #-8]
    // 0x8b061c: stur            x4, [fp, #-0x10]
    // 0x8b0620: StoreField: r4->field_b = r3
    //     0x8b0620: stur            w3, [x4, #0xb]
    // 0x8b0624: ldr             x5, [fp, #0x10]
    // 0x8b0628: StoreField: r4->field_f = r5
    //     0x8b0628: stur            w5, [x4, #0xf]
    // 0x8b062c: mov             x0, x5
    // 0x8b0630: r2 = Null
    //     0x8b0630: mov             x2, NULL
    // 0x8b0634: r1 = Null
    //     0x8b0634: mov             x1, NULL
    // 0x8b0638: r4 = LoadClassIdInstr(r0)
    //     0x8b0638: ldur            x4, [x0, #-1]
    //     0x8b063c: ubfx            x4, x4, #0xc, #0x14
    // 0x8b0640: cmp             x4, #0xcc4
    // 0x8b0644: b.eq            #0x8b065c
    // 0x8b0648: r8 = _TextFormFieldState<FormField<String>, String>
    //     0x8b0648: add             x8, PP, #0x2c, lsl #12  ; [pp+0x2c0b0] Type: _TextFormFieldState<FormField<String>, String>
    //     0x8b064c: ldr             x8, [x8, #0xb0]
    // 0x8b0650: r3 = Null
    //     0x8b0650: add             x3, PP, #0x2c, lsl #12  ; [pp+0x2c0b8] Null
    //     0x8b0654: ldr             x3, [x3, #0xb8]
    // 0x8b0658: r0 = DefaultTypeTest()
    //     0x8b0658: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x8b065c: ldur            x0, [fp, #-8]
    // 0x8b0660: LoadField: r1 = r0->field_f
    //     0x8b0660: ldur            w1, [x0, #0xf]
    // 0x8b0664: DecompressPointer r1
    //     0x8b0664: add             x1, x1, HEAP, lsl #32
    // 0x8b0668: ldr             x2, [fp, #0x10]
    // 0x8b066c: stur            x1, [fp, #-0x18]
    // 0x8b0670: LoadField: r3 = r2->field_f
    //     0x8b0670: ldur            w3, [x2, #0xf]
    // 0x8b0674: DecompressPointer r3
    //     0x8b0674: add             x3, x3, HEAP, lsl #32
    // 0x8b0678: cmp             w3, NULL
    // 0x8b067c: b.eq            #0x8b08ec
    // 0x8b0680: SaveReg r3
    //     0x8b0680: str             x3, [SP, #-8]!
    // 0x8b0684: r0 = of()
    //     0x8b0684: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8b0688: add             SP, SP, #8
    // 0x8b068c: ldur            x16, [fp, #-0x18]
    // 0x8b0690: SaveReg r16
    //     0x8b0690: str             x16, [SP, #-8]!
    // 0x8b0694: r0 = applyDefaults()
    //     0x8b0694: bl              #0x7b4a68  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::applyDefaults
    // 0x8b0698: add             SP, SP, #8
    // 0x8b069c: stur            x0, [fp, #-0x18]
    // 0x8b06a0: ldr             x16, [fp, #0x10]
    // 0x8b06a4: SaveReg r16
    //     0x8b06a4: str             x16, [SP, #-8]!
    // 0x8b06a8: r0 = _effectiveController()
    //     0x8b06a8: bl              #0x7bf3f8  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::_effectiveController
    // 0x8b06ac: add             SP, SP, #8
    // 0x8b06b0: stur            x0, [fp, #-0x20]
    // 0x8b06b4: ldr             x16, [fp, #0x10]
    // 0x8b06b8: SaveReg r16
    //     0x8b06b8: str             x16, [SP, #-8]!
    // 0x8b06bc: r0 = errorText()
    //     0x8b06bc: bl              #0x8b0904  ; [package:flutter/src/widgets/form.dart] FormFieldState::errorText
    // 0x8b06c0: add             SP, SP, #8
    // 0x8b06c4: ldur            x16, [fp, #-0x18]
    // 0x8b06c8: stp             x0, x16, [SP, #-0x10]!
    // 0x8b06cc: r4 = const [0, 0x2, 0x2, 0x1, errorText, 0x1, null]
    //     0x8b06cc: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2c0c8] List(7) [0, 0x2, 0x2, 0x1, "errorText", 0x1, Null]
    //     0x8b06d0: ldr             x4, [x4, #0xc8]
    // 0x8b06d4: r0 = copyWith()
    //     0x8b06d4: bl              #0x7b4d38  ; [package:flutter/src/material/input_decorator.dart] InputDecoration::copyWith
    // 0x8b06d8: add             SP, SP, #0x10
    // 0x8b06dc: mov             x2, x0
    // 0x8b06e0: ldur            x1, [fp, #-8]
    // 0x8b06e4: stur            x2, [fp, #-0x30]
    // 0x8b06e8: LoadField: r3 = r1->field_13
    //     0x8b06e8: ldur            w3, [x1, #0x13]
    // 0x8b06ec: DecompressPointer r3
    //     0x8b06ec: add             x3, x3, HEAP, lsl #32
    // 0x8b06f0: stur            x3, [fp, #-0x28]
    // 0x8b06f4: LoadField: r4 = r1->field_23
    //     0x8b06f4: ldur            w4, [x1, #0x23]
    // 0x8b06f8: DecompressPointer r4
    //     0x8b06f8: add             x4, x4, HEAP, lsl #32
    // 0x8b06fc: mov             x0, x4
    // 0x8b0700: stur            x4, [fp, #-0x18]
    // 0x8b0704: tbnz            w0, #5, #0x8b070c
    // 0x8b0708: r0 = AssertBoolean()
    //     0x8b0708: bl              #0xd67df0  ; AssertBooleanStub
    // 0x8b070c: ldur            x0, [fp, #-0x18]
    // 0x8b0710: tbnz            w0, #4, #0x8b0720
    // 0x8b0714: r1 = Instance_SmartDashesType
    //     0x8b0714: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0d0] Obj!SmartDashesType@b641f1
    //     0x8b0718: ldr             x1, [x1, #0xd0]
    // 0x8b071c: b               #0x8b0728
    // 0x8b0720: r1 = Instance_SmartDashesType
    //     0x8b0720: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f2a0] Obj!SmartDashesType@b641d1
    //     0x8b0724: ldr             x1, [x1, #0x2a0]
    // 0x8b0728: stur            x1, [fp, #-0x60]
    // 0x8b072c: tbnz            w0, #4, #0x8b073c
    // 0x8b0730: r6 = Instance_SmartQuotesType
    //     0x8b0730: add             x6, PP, #0x2c, lsl #12  ; [pp+0x2c0d8] Obj!SmartQuotesType@b641b1
    //     0x8b0734: ldr             x6, [x6, #0xd8]
    // 0x8b0738: b               #0x8b0744
    // 0x8b073c: r6 = Instance_SmartQuotesType
    //     0x8b073c: add             x6, PP, #0x1f, lsl #12  ; [pp+0x1f2a8] Obj!SmartQuotesType@b64191
    //     0x8b0740: ldr             x6, [x6, #0x2a8]
    // 0x8b0744: ldur            x2, [fp, #-8]
    // 0x8b0748: ldur            x5, [fp, #-0x20]
    // 0x8b074c: ldur            x3, [fp, #-0x30]
    // 0x8b0750: ldur            x4, [fp, #-0x28]
    // 0x8b0754: stur            x6, [fp, #-0x58]
    // 0x8b0758: LoadField: r7 = r2->field_1b
    //     0x8b0758: ldur            w7, [x2, #0x1b]
    // 0x8b075c: DecompressPointer r7
    //     0x8b075c: add             x7, x7, HEAP, lsl #32
    // 0x8b0760: stur            x7, [fp, #-0x50]
    // 0x8b0764: LoadField: r8 = r2->field_1f
    //     0x8b0764: ldur            w8, [x2, #0x1f]
    // 0x8b0768: DecompressPointer r8
    //     0x8b0768: add             x8, x8, HEAP, lsl #32
    // 0x8b076c: stur            x8, [fp, #-0x48]
    // 0x8b0770: LoadField: r9 = r2->field_f
    //     0x8b0770: ldur            w9, [x2, #0xf]
    // 0x8b0774: DecompressPointer r9
    //     0x8b0774: add             x9, x9, HEAP, lsl #32
    // 0x8b0778: LoadField: r10 = r9->field_bf
    //     0x8b0778: ldur            w10, [x9, #0xbf]
    // 0x8b077c: DecompressPointer r10
    //     0x8b077c: add             x10, x10, HEAP, lsl #32
    // 0x8b0780: stur            x10, [fp, #-0x40]
    // 0x8b0784: LoadField: r9 = r2->field_17
    //     0x8b0784: ldur            w9, [x2, #0x17]
    // 0x8b0788: DecompressPointer r9
    //     0x8b0788: add             x9, x9, HEAP, lsl #32
    // 0x8b078c: stur            x9, [fp, #-0x38]
    // 0x8b0790: r0 = TextField()
    //     0x8b0790: bl              #0x8b08f0  ; AllocateTextFieldStub -> TextField (size=0xf4)
    // 0x8b0794: mov             x3, x0
    // 0x8b0798: ldur            x0, [fp, #-0x20]
    // 0x8b079c: stur            x3, [fp, #-8]
    // 0x8b07a0: StoreField: r3->field_f = r0
    //     0x8b07a0: stur            w0, [x3, #0xf]
    // 0x8b07a4: ldur            x0, [fp, #-0x30]
    // 0x8b07a8: StoreField: r3->field_17 = r0
    //     0x8b07a8: stur            w0, [x3, #0x17]
    // 0x8b07ac: r0 = Instance_TextCapitalization
    //     0x8b07ac: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f268] Obj!TextCapitalization@b63fd1
    //     0x8b07b0: ldr             x0, [x0, #0x268]
    // 0x8b07b4: StoreField: r3->field_23 = r0
    //     0x8b07b4: stur            w0, [x3, #0x23]
    // 0x8b07b8: ldur            x0, [fp, #-0x28]
    // 0x8b07bc: StoreField: r3->field_27 = r0
    //     0x8b07bc: stur            w0, [x3, #0x27]
    // 0x8b07c0: r0 = Instance_TextAlign
    //     0x8b07c0: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x8b07c4: ldr             x0, [x0, #0xfe8]
    // 0x8b07c8: StoreField: r3->field_2f = r0
    //     0x8b07c8: stur            w0, [x3, #0x2f]
    // 0x8b07cc: r0 = false
    //     0x8b07cc: add             x0, NULL, #0x30  ; false
    // 0x8b07d0: StoreField: r3->field_63 = r0
    //     0x8b07d0: stur            w0, [x3, #0x63]
    // 0x8b07d4: StoreField: r3->field_3b = r0
    //     0x8b07d4: stur            w0, [x3, #0x3b]
    // 0x8b07d8: r1 = "•"
    //     0x8b07d8: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f278] "•"
    //     0x8b07dc: ldr             x1, [x1, #0x278]
    // 0x8b07e0: StoreField: r3->field_3f = r1
    //     0x8b07e0: stur            w1, [x3, #0x3f]
    // 0x8b07e4: ldur            x1, [fp, #-0x18]
    // 0x8b07e8: StoreField: r3->field_43 = r1
    //     0x8b07e8: stur            w1, [x3, #0x43]
    // 0x8b07ec: r4 = true
    //     0x8b07ec: add             x4, NULL, #0x20  ; true
    // 0x8b07f0: StoreField: r3->field_47 = r4
    //     0x8b07f0: stur            w4, [x3, #0x47]
    // 0x8b07f4: StoreField: r3->field_53 = r4
    //     0x8b07f4: stur            w4, [x3, #0x53]
    // 0x8b07f8: ldur            x5, [fp, #-0x50]
    // 0x8b07fc: StoreField: r3->field_57 = r5
    //     0x8b07fc: stur            w5, [x3, #0x57]
    // 0x8b0800: ldur            x1, [fp, #-0x48]
    // 0x8b0804: StoreField: r3->field_5b = r1
    //     0x8b0804: stur            w1, [x3, #0x5b]
    // 0x8b0808: StoreField: r3->field_5f = r0
    //     0x8b0808: stur            w0, [x3, #0x5f]
    // 0x8b080c: ldur            x2, [fp, #-0x10]
    // 0x8b0810: r1 = Function 'onChangedHandler':.
    //     0x8b0810: add             x1, PP, #0x2c, lsl #12  ; [pp+0x2c0e0] AnonymousClosure: (0x8b243c), in [package:flutter/src/material/text_form_field.dart] TextFormField::TextFormField (0x8b0354)
    //     0x8b0814: ldr             x1, [x1, #0xe0]
    // 0x8b0818: r0 = AllocateClosure()
    //     0x8b0818: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8b081c: mov             x1, x0
    // 0x8b0820: ldur            x0, [fp, #-8]
    // 0x8b0824: StoreField: r0->field_77 = r1
    //     0x8b0824: stur            w1, [x0, #0x77]
    // 0x8b0828: ldur            x1, [fp, #-0x40]
    // 0x8b082c: StoreField: r0->field_8b = r1
    //     0x8b082c: stur            w1, [x0, #0x8b]
    // 0x8b0830: d0 = 2.000000
    //     0x8b0830: fmov            d0, #2.00000000
    // 0x8b0834: StoreField: r0->field_8f = d0
    //     0x8b0834: stur            d0, [x0, #0x8f]
    // 0x8b0838: ldur            x1, [fp, #-0x38]
    // 0x8b083c: StoreField: r0->field_9f = r1
    //     0x8b083c: stur            w1, [x0, #0x9f]
    // 0x8b0840: r1 = Instance_BoxHeightStyle
    //     0x8b0840: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f280] Obj!BoxHeightStyle@b66db1
    //     0x8b0844: ldr             x1, [x1, #0x280]
    // 0x8b0848: StoreField: r0->field_a3 = r1
    //     0x8b0848: stur            w1, [x0, #0xa3]
    // 0x8b084c: r1 = Instance_BoxWidthStyle
    //     0x8b084c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f288] Obj!BoxWidthStyle@b66d91
    //     0x8b0850: ldr             x1, [x1, #0x288]
    // 0x8b0854: StoreField: r0->field_a7 = r1
    //     0x8b0854: stur            w1, [x0, #0xa7]
    // 0x8b0858: r1 = Instance_EdgeInsets
    //     0x8b0858: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f290] Obj!EdgeInsets@b35a21
    //     0x8b085c: ldr             x1, [x1, #0x290]
    // 0x8b0860: StoreField: r0->field_af = r1
    //     0x8b0860: stur            w1, [x0, #0xaf]
    // 0x8b0864: r1 = Instance_DragStartBehavior
    //     0x8b0864: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x8b0868: ldr             x1, [x1, #0xf88]
    // 0x8b086c: StoreField: r0->field_bb = r1
    //     0x8b086c: stur            w1, [x0, #0xbb]
    // 0x8b0870: r1 = Instance_Clip
    //     0x8b0870: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x8b0874: ldr             x1, [x1, #0x678]
    // 0x8b0878: StoreField: r0->field_db = r1
    //     0x8b0878: stur            w1, [x0, #0xdb]
    // 0x8b087c: r1 = true
    //     0x8b087c: add             x1, NULL, #0x20  ; true
    // 0x8b0880: StoreField: r0->field_e3 = r1
    //     0x8b0880: stur            w1, [x0, #0xe3]
    // 0x8b0884: StoreField: r0->field_e7 = r1
    //     0x8b0884: stur            w1, [x0, #0xe7]
    // 0x8b0888: r2 = Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@824147271': static.
    //     0x8b0888: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c0e8] Closure: (BuildContext, EditableTextState) => Widget from Function '_defaultContextMenuBuilder@824147271': static. (0x7fe6e20b0974)
    //     0x8b088c: ldr             x2, [x2, #0xe8]
    // 0x8b0890: StoreField: r0->field_eb = r2
    //     0x8b0890: stur            w2, [x0, #0xeb]
    // 0x8b0894: ldur            x2, [fp, #-0x60]
    // 0x8b0898: StoreField: r0->field_4b = r2
    //     0x8b0898: stur            w2, [x0, #0x4b]
    // 0x8b089c: ldur            x2, [fp, #-0x58]
    // 0x8b08a0: StoreField: r0->field_4f = r2
    //     0x8b08a0: stur            w2, [x0, #0x4f]
    // 0x8b08a4: ldur            x2, [fp, #-0x50]
    // 0x8b08a8: cmp             w2, #2
    // 0x8b08ac: b.ne            #0x8b08bc
    // 0x8b08b0: r2 = Instance_TextInputType
    //     0x8b08b0: add             x2, PP, #0x1f, lsl #12  ; [pp+0x1f2b0] Obj!TextInputType@b347d1
    //     0x8b08b4: ldr             x2, [x2, #0x2b0]
    // 0x8b08b8: b               #0x8b08c4
    // 0x8b08bc: r2 = Instance_TextInputType
    //     0x8b08bc: add             x2, PP, #0x2c, lsl #12  ; [pp+0x2c0f0] Obj!TextInputType@b347b1
    //     0x8b08c0: ldr             x2, [x2, #0xf0]
    // 0x8b08c4: StoreField: r0->field_1b = r2
    //     0x8b08c4: stur            w2, [x0, #0x1b]
    // 0x8b08c8: StoreField: r0->field_b3 = r1
    //     0x8b08c8: stur            w1, [x0, #0xb3]
    // 0x8b08cc: r0 = UnmanagedRestorationScope()
    //     0x8b08cc: bl              #0x83cd7c  ; AllocateUnmanagedRestorationScopeStub -> UnmanagedRestorationScope (size=0x14)
    // 0x8b08d0: ldur            x1, [fp, #-8]
    // 0x8b08d4: StoreField: r0->field_b = r1
    //     0x8b08d4: stur            w1, [x0, #0xb]
    // 0x8b08d8: LeaveFrame
    //     0x8b08d8: mov             SP, fp
    //     0x8b08dc: ldp             fp, lr, [SP], #0x10
    // 0x8b08e0: ret
    //     0x8b08e0: ret             
    // 0x8b08e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b08e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b08e8: b               #0x8b060c
    // 0x8b08ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8b08ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Widget _defaultContextMenuBuilder(dynamic, BuildContext, EditableTextState) {
    // ** addr: 0x8b0974, size: 0x3c
    // 0x8b0974: EnterFrame
    //     0x8b0974: stp             fp, lr, [SP, #-0x10]!
    //     0x8b0978: mov             fp, SP
    // 0x8b097c: CheckStackOverflow
    //     0x8b097c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8b0980: cmp             SP, x16
    //     0x8b0984: b.ls            #0x8b09a8
    // 0x8b0988: ldr             x16, [fp, #0x18]
    // 0x8b098c: ldr             lr, [fp, #0x10]
    // 0x8b0990: stp             lr, x16, [SP, #-0x10]!
    // 0x8b0994: r0 = _defaultContextMenuBuilder()
    //     0x8b0994: bl              #0x8b09b0  ; [package:flutter/src/material/text_field.dart] TextField::_defaultContextMenuBuilder
    // 0x8b0998: add             SP, SP, #0x10
    // 0x8b099c: LeaveFrame
    //     0x8b099c: mov             SP, fp
    //     0x8b09a0: ldp             fp, lr, [SP], #0x10
    // 0x8b09a4: ret
    //     0x8b09a4: ret             
    // 0x8b09a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b09a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b09ac: b               #0x8b0988
  }
  [closure] void onChangedHandler(dynamic, String) {
    // ** addr: 0x8b243c, size: 0x50
    // 0x8b243c: EnterFrame
    //     0x8b243c: stp             fp, lr, [SP, #-0x10]!
    //     0x8b2440: mov             fp, SP
    // 0x8b2444: ldr             x0, [fp, #0x18]
    // 0x8b2448: LoadField: r1 = r0->field_17
    //     0x8b2448: ldur            w1, [x0, #0x17]
    // 0x8b244c: DecompressPointer r1
    //     0x8b244c: add             x1, x1, HEAP, lsl #32
    // 0x8b2450: CheckStackOverflow
    //     0x8b2450: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8b2454: cmp             SP, x16
    //     0x8b2458: b.ls            #0x8b2484
    // 0x8b245c: LoadField: r0 = r1->field_f
    //     0x8b245c: ldur            w0, [x1, #0xf]
    // 0x8b2460: DecompressPointer r0
    //     0x8b2460: add             x0, x0, HEAP, lsl #32
    // 0x8b2464: ldr             x16, [fp, #0x10]
    // 0x8b2468: stp             x16, x0, [SP, #-0x10]!
    // 0x8b246c: r0 = didChange()
    //     0x8b246c: bl              #0x7bf42c  ; [package:flutter/src/material/text_form_field.dart] _TextFormFieldState::didChange
    // 0x8b2470: add             SP, SP, #0x10
    // 0x8b2474: r0 = Null
    //     0x8b2474: mov             x0, NULL
    // 0x8b2478: LeaveFrame
    //     0x8b2478: mov             SP, fp
    //     0x8b247c: ldp             fp, lr, [SP], #0x10
    // 0x8b2480: ret
    //     0x8b2480: ret             
    // 0x8b2484: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8b2484: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8b2488: b               #0x8b245c
  }
  _ createState(/* No info */) {
    // ** addr: 0xa4188c, size: 0x4c
    // 0xa4188c: EnterFrame
    //     0xa4188c: stp             fp, lr, [SP, #-0x10]!
    //     0xa41890: mov             fp, SP
    // 0xa41894: AllocStack(0x8)
    //     0xa41894: sub             SP, SP, #8
    // 0xa41898: CheckStackOverflow
    //     0xa41898: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4189c: cmp             SP, x16
    //     0xa418a0: b.ls            #0xa418d0
    // 0xa418a4: r1 = <FormField<String>, String>
    //     0xa418a4: add             x1, PP, #0x37, lsl #12  ; [pp+0x376c0] TypeArguments: <FormField<String>, String>
    //     0xa418a8: ldr             x1, [x1, #0x6c0]
    // 0xa418ac: r0 = _TextFormFieldState()
    //     0xa418ac: bl              #0xa41a2c  ; Allocate_TextFormFieldStateStub -> _TextFormFieldState (size=0x34)
    // 0xa418b0: stur            x0, [fp, #-8]
    // 0xa418b4: SaveReg r0
    //     0xa418b4: str             x0, [SP, #-8]!
    // 0xa418b8: r0 = FormFieldState()
    //     0xa418b8: bl              #0xa418d8  ; [package:flutter/src/widgets/form.dart] FormFieldState::FormFieldState
    // 0xa418bc: add             SP, SP, #8
    // 0xa418c0: ldur            x0, [fp, #-8]
    // 0xa418c4: LeaveFrame
    //     0xa418c4: mov             SP, fp
    //     0xa418c8: ldp             fp, lr, [SP], #0x10
    // 0xa418cc: ret
    //     0xa418cc: ret             
    // 0xa418d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa418d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa418d4: b               #0xa418a4
  }
}

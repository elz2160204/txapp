// lib: , url: package:flutter/src/material/text_selection_toolbar.dart

// class id: 1049327, size: 0x8
class :: {
}

// class id: 2449, size: 0x70, field offset: 0x60
//   transformed mixin,
abstract class __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin extends RenderBox
     with ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> {

  _ move(/* No info */) {
    // ** addr: 0x5af504, size: 0x170
    // 0x5af504: EnterFrame
    //     0x5af504: stp             fp, lr, [SP, #-0x10]!
    //     0x5af508: mov             fp, SP
    // 0x5af50c: AllocStack(0x8)
    //     0x5af50c: sub             SP, SP, #8
    // 0x5af510: CheckStackOverflow
    //     0x5af510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5af514: cmp             SP, x16
    //     0x5af518: b.ls            #0x5af668
    // 0x5af51c: ldr             x0, [fp, #0x18]
    // 0x5af520: r2 = Null
    //     0x5af520: mov             x2, NULL
    // 0x5af524: r1 = Null
    //     0x5af524: mov             x1, NULL
    // 0x5af528: r4 = 59
    //     0x5af528: mov             x4, #0x3b
    // 0x5af52c: branchIfSmi(r0, 0x5af538)
    //     0x5af52c: tbz             w0, #0, #0x5af538
    // 0x5af530: r4 = LoadClassIdInstr(r0)
    //     0x5af530: ldur            x4, [x0, #-1]
    //     0x5af534: ubfx            x4, x4, #0xc, #0x14
    // 0x5af538: sub             x4, x4, #0x965
    // 0x5af53c: cmp             x4, #0x8b
    // 0x5af540: b.ls            #0x5af558
    // 0x5af544: r8 = RenderBox
    //     0x5af544: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5af548: ldr             x8, [x8, #0xfa0]
    // 0x5af54c: r3 = Null
    //     0x5af54c: add             x3, PP, #0x50, lsl #12  ; [pp+0x506b0] Null
    //     0x5af550: ldr             x3, [x3, #0x6b0]
    // 0x5af554: r0 = RenderBox()
    //     0x5af554: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5af558: ldr             x0, [fp, #0x10]
    // 0x5af55c: r2 = Null
    //     0x5af55c: mov             x2, NULL
    // 0x5af560: r1 = Null
    //     0x5af560: mov             x1, NULL
    // 0x5af564: r4 = 59
    //     0x5af564: mov             x4, #0x3b
    // 0x5af568: branchIfSmi(r0, 0x5af574)
    //     0x5af568: tbz             w0, #0, #0x5af574
    // 0x5af56c: r4 = LoadClassIdInstr(r0)
    //     0x5af56c: ldur            x4, [x0, #-1]
    //     0x5af570: ubfx            x4, x4, #0xc, #0x14
    // 0x5af574: sub             x4, x4, #0x965
    // 0x5af578: cmp             x4, #0x8b
    // 0x5af57c: b.ls            #0x5af590
    // 0x5af580: r8 = RenderBox?
    //     0x5af580: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5af584: r3 = Null
    //     0x5af584: add             x3, PP, #0x50, lsl #12  ; [pp+0x506c0] Null
    //     0x5af588: ldr             x3, [x3, #0x6c0]
    // 0x5af58c: r0 = RenderBox?()
    //     0x5af58c: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5af590: ldr             x3, [fp, #0x18]
    // 0x5af594: LoadField: r4 = r3->field_17
    //     0x5af594: ldur            w4, [x3, #0x17]
    // 0x5af598: DecompressPointer r4
    //     0x5af598: add             x4, x4, HEAP, lsl #32
    // 0x5af59c: stur            x4, [fp, #-8]
    // 0x5af5a0: cmp             w4, NULL
    // 0x5af5a4: b.eq            #0x5af670
    // 0x5af5a8: mov             x0, x4
    // 0x5af5ac: r2 = Null
    //     0x5af5ac: mov             x2, NULL
    // 0x5af5b0: r1 = Null
    //     0x5af5b0: mov             x1, NULL
    // 0x5af5b4: r4 = LoadClassIdInstr(r0)
    //     0x5af5b4: ldur            x4, [x0, #-1]
    //     0x5af5b8: ubfx            x4, x4, #0xc, #0x14
    // 0x5af5bc: cmp             x4, #0x804
    // 0x5af5c0: b.eq            #0x5af5d8
    // 0x5af5c4: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5af5c4: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5af5c8: ldr             x8, [x8, #0x528]
    // 0x5af5cc: r3 = Null
    //     0x5af5cc: add             x3, PP, #0x50, lsl #12  ; [pp+0x506d0] Null
    //     0x5af5d0: ldr             x3, [x3, #0x6d0]
    // 0x5af5d4: r0 = DefaultTypeTest()
    //     0x5af5d4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af5d8: ldur            x0, [fp, #-8]
    // 0x5af5dc: LoadField: r1 = r0->field_f
    //     0x5af5dc: ldur            w1, [x0, #0xf]
    // 0x5af5e0: DecompressPointer r1
    //     0x5af5e0: add             x1, x1, HEAP, lsl #32
    // 0x5af5e4: r0 = LoadClassIdInstr(r1)
    //     0x5af5e4: ldur            x0, [x1, #-1]
    //     0x5af5e8: ubfx            x0, x0, #0xc, #0x14
    // 0x5af5ec: ldr             x16, [fp, #0x10]
    // 0x5af5f0: stp             x16, x1, [SP, #-0x10]!
    // 0x5af5f4: mov             lr, x0
    // 0x5af5f8: ldr             lr, [x21, lr, lsl #3]
    // 0x5af5fc: blr             lr
    // 0x5af600: add             SP, SP, #0x10
    // 0x5af604: tbnz            w0, #4, #0x5af618
    // 0x5af608: r0 = Null
    //     0x5af608: mov             x0, NULL
    // 0x5af60c: LeaveFrame
    //     0x5af60c: mov             SP, fp
    //     0x5af610: ldp             fp, lr, [SP], #0x10
    // 0x5af614: ret
    //     0x5af614: ret             
    // 0x5af618: ldr             x16, [fp, #0x20]
    // 0x5af61c: ldr             lr, [fp, #0x18]
    // 0x5af620: stp             lr, x16, [SP, #-0x10]!
    // 0x5af624: r0 = _removeFromChildList()
    //     0x5af624: bl              #0x5afbd4  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5af628: add             SP, SP, #0x10
    // 0x5af62c: ldr             x16, [fp, #0x20]
    // 0x5af630: ldr             lr, [fp, #0x18]
    // 0x5af634: stp             lr, x16, [SP, #-0x10]!
    // 0x5af638: ldr             x16, [fp, #0x10]
    // 0x5af63c: SaveReg r16
    //     0x5af63c: str             x16, [SP, #-8]!
    // 0x5af640: r0 = _insertIntoChildList()
    //     0x5af640: bl              #0x5af674  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5af644: add             SP, SP, #0x18
    // 0x5af648: ldr             x16, [fp, #0x20]
    // 0x5af64c: SaveReg r16
    //     0x5af64c: str             x16, [SP, #-8]!
    // 0x5af650: r0 = markNeedsLayout()
    //     0x5af650: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x5af654: add             SP, SP, #8
    // 0x5af658: r0 = Null
    //     0x5af658: mov             x0, NULL
    // 0x5af65c: LeaveFrame
    //     0x5af65c: mov             SP, fp
    //     0x5af660: ldp             fp, lr, [SP], #0x10
    // 0x5af664: ret
    //     0x5af664: ret             
    // 0x5af668: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5af668: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5af66c: b               #0x5af51c
    // 0x5af670: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af670: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _insertIntoChildList(/* No info */) {
    // ** addr: 0x5af674, size: 0x560
    // 0x5af674: EnterFrame
    //     0x5af674: stp             fp, lr, [SP, #-0x10]!
    //     0x5af678: mov             fp, SP
    // 0x5af67c: AllocStack(0x20)
    //     0x5af67c: sub             SP, SP, #0x20
    // 0x5af680: ldr             x3, [fp, #0x18]
    // 0x5af684: LoadField: r4 = r3->field_17
    //     0x5af684: ldur            w4, [x3, #0x17]
    // 0x5af688: DecompressPointer r4
    //     0x5af688: add             x4, x4, HEAP, lsl #32
    // 0x5af68c: stur            x4, [fp, #-8]
    // 0x5af690: cmp             w4, NULL
    // 0x5af694: b.eq            #0x5afbc4
    // 0x5af698: mov             x0, x4
    // 0x5af69c: r2 = Null
    //     0x5af69c: mov             x2, NULL
    // 0x5af6a0: r1 = Null
    //     0x5af6a0: mov             x1, NULL
    // 0x5af6a4: r4 = LoadClassIdInstr(r0)
    //     0x5af6a4: ldur            x4, [x0, #-1]
    //     0x5af6a8: ubfx            x4, x4, #0xc, #0x14
    // 0x5af6ac: cmp             x4, #0x804
    // 0x5af6b0: b.eq            #0x5af6c8
    // 0x5af6b4: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5af6b4: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5af6b8: ldr             x8, [x8, #0x528]
    // 0x5af6bc: r3 = Null
    //     0x5af6bc: add             x3, PP, #0x50, lsl #12  ; [pp+0x506e0] Null
    //     0x5af6c0: ldr             x3, [x3, #0x6e0]
    // 0x5af6c4: r0 = DefaultTypeTest()
    //     0x5af6c4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af6c8: ldr             x3, [fp, #0x20]
    // 0x5af6cc: LoadField: r0 = r3->field_5f
    //     0x5af6cc: ldur            x0, [x3, #0x5f]
    // 0x5af6d0: add             x1, x0, #1
    // 0x5af6d4: StoreField: r3->field_5f = r1
    //     0x5af6d4: stur            x1, [x3, #0x5f]
    // 0x5af6d8: ldr             x4, [fp, #0x10]
    // 0x5af6dc: cmp             w4, NULL
    // 0x5af6e0: b.ne            #0x5af868
    // 0x5af6e4: ldur            x4, [fp, #-8]
    // 0x5af6e8: LoadField: r5 = r3->field_67
    //     0x5af6e8: ldur            w5, [x3, #0x67]
    // 0x5af6ec: DecompressPointer r5
    //     0x5af6ec: add             x5, x5, HEAP, lsl #32
    // 0x5af6f0: stur            x5, [fp, #-0x10]
    // 0x5af6f4: LoadField: r2 = r4->field_b
    //     0x5af6f4: ldur            w2, [x4, #0xb]
    // 0x5af6f8: DecompressPointer r2
    //     0x5af6f8: add             x2, x2, HEAP, lsl #32
    // 0x5af6fc: mov             x0, x5
    // 0x5af700: r1 = Null
    //     0x5af700: mov             x1, NULL
    // 0x5af704: cmp             w0, NULL
    // 0x5af708: b.eq            #0x5af734
    // 0x5af70c: cmp             w2, NULL
    // 0x5af710: b.eq            #0x5af734
    // 0x5af714: LoadField: r4 = r2->field_17
    //     0x5af714: ldur            w4, [x2, #0x17]
    // 0x5af718: DecompressPointer r4
    //     0x5af718: add             x4, x4, HEAP, lsl #32
    // 0x5af71c: r8 = X0? bound RenderObject
    //     0x5af71c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af720: ldr             x8, [x8, #0x6e8]
    // 0x5af724: LoadField: r9 = r4->field_7
    //     0x5af724: ldur            x9, [x4, #7]
    // 0x5af728: r3 = Null
    //     0x5af728: add             x3, PP, #0x50, lsl #12  ; [pp+0x506f0] Null
    //     0x5af72c: ldr             x3, [x3, #0x6f0]
    // 0x5af730: blr             x9
    // 0x5af734: ldur            x0, [fp, #-0x10]
    // 0x5af738: ldur            x3, [fp, #-8]
    // 0x5af73c: StoreField: r3->field_13 = r0
    //     0x5af73c: stur            w0, [x3, #0x13]
    //     0x5af740: ldurb           w16, [x3, #-1]
    //     0x5af744: ldurb           w17, [x0, #-1]
    //     0x5af748: and             x16, x17, x16, lsr #2
    //     0x5af74c: tst             x16, HEAP, lsr #32
    //     0x5af750: b.eq            #0x5af758
    //     0x5af754: bl              #0xd682ac
    // 0x5af758: ldur            x0, [fp, #-0x10]
    // 0x5af75c: cmp             w0, NULL
    // 0x5af760: b.eq            #0x5af810
    // 0x5af764: LoadField: r3 = r0->field_17
    //     0x5af764: ldur            w3, [x0, #0x17]
    // 0x5af768: DecompressPointer r3
    //     0x5af768: add             x3, x3, HEAP, lsl #32
    // 0x5af76c: stur            x3, [fp, #-0x18]
    // 0x5af770: cmp             w3, NULL
    // 0x5af774: b.eq            #0x5afbc8
    // 0x5af778: mov             x0, x3
    // 0x5af77c: r2 = Null
    //     0x5af77c: mov             x2, NULL
    // 0x5af780: r1 = Null
    //     0x5af780: mov             x1, NULL
    // 0x5af784: r4 = LoadClassIdInstr(r0)
    //     0x5af784: ldur            x4, [x0, #-1]
    //     0x5af788: ubfx            x4, x4, #0xc, #0x14
    // 0x5af78c: cmp             x4, #0x804
    // 0x5af790: b.eq            #0x5af7a8
    // 0x5af794: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5af794: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5af798: ldr             x8, [x8, #0x528]
    // 0x5af79c: r3 = Null
    //     0x5af79c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50700] Null
    //     0x5af7a0: ldr             x3, [x3, #0x700]
    // 0x5af7a4: r0 = DefaultTypeTest()
    //     0x5af7a4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af7a8: ldur            x3, [fp, #-0x18]
    // 0x5af7ac: LoadField: r2 = r3->field_b
    //     0x5af7ac: ldur            w2, [x3, #0xb]
    // 0x5af7b0: DecompressPointer r2
    //     0x5af7b0: add             x2, x2, HEAP, lsl #32
    // 0x5af7b4: ldr             x0, [fp, #0x18]
    // 0x5af7b8: r1 = Null
    //     0x5af7b8: mov             x1, NULL
    // 0x5af7bc: cmp             w0, NULL
    // 0x5af7c0: b.eq            #0x5af7ec
    // 0x5af7c4: cmp             w2, NULL
    // 0x5af7c8: b.eq            #0x5af7ec
    // 0x5af7cc: LoadField: r4 = r2->field_17
    //     0x5af7cc: ldur            w4, [x2, #0x17]
    // 0x5af7d0: DecompressPointer r4
    //     0x5af7d0: add             x4, x4, HEAP, lsl #32
    // 0x5af7d4: r8 = X0? bound RenderObject
    //     0x5af7d4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af7d8: ldr             x8, [x8, #0x6e8]
    // 0x5af7dc: LoadField: r9 = r4->field_7
    //     0x5af7dc: ldur            x9, [x4, #7]
    // 0x5af7e0: r3 = Null
    //     0x5af7e0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50710] Null
    //     0x5af7e4: ldr             x3, [x3, #0x710]
    // 0x5af7e8: blr             x9
    // 0x5af7ec: ldr             x0, [fp, #0x18]
    // 0x5af7f0: ldur            x1, [fp, #-0x18]
    // 0x5af7f4: StoreField: r1->field_f = r0
    //     0x5af7f4: stur            w0, [x1, #0xf]
    //     0x5af7f8: ldurb           w16, [x1, #-1]
    //     0x5af7fc: ldurb           w17, [x0, #-1]
    //     0x5af800: and             x16, x17, x16, lsr #2
    //     0x5af804: tst             x16, HEAP, lsr #32
    //     0x5af808: b.eq            #0x5af810
    //     0x5af80c: bl              #0xd6826c
    // 0x5af810: ldr             x5, [fp, #0x20]
    // 0x5af814: ldr             x0, [fp, #0x18]
    // 0x5af818: StoreField: r5->field_67 = r0
    //     0x5af818: stur            w0, [x5, #0x67]
    //     0x5af81c: ldurb           w16, [x5, #-1]
    //     0x5af820: ldurb           w17, [x0, #-1]
    //     0x5af824: and             x16, x17, x16, lsr #2
    //     0x5af828: tst             x16, HEAP, lsr #32
    //     0x5af82c: b.eq            #0x5af834
    //     0x5af830: bl              #0xd682ec
    // 0x5af834: LoadField: r0 = r5->field_6b
    //     0x5af834: ldur            w0, [x5, #0x6b]
    // 0x5af838: DecompressPointer r0
    //     0x5af838: add             x0, x0, HEAP, lsl #32
    // 0x5af83c: cmp             w0, NULL
    // 0x5af840: b.ne            #0x5afbb4
    // 0x5af844: ldr             x0, [fp, #0x18]
    // 0x5af848: StoreField: r5->field_6b = r0
    //     0x5af848: stur            w0, [x5, #0x6b]
    //     0x5af84c: ldurb           w16, [x5, #-1]
    //     0x5af850: ldurb           w17, [x0, #-1]
    //     0x5af854: and             x16, x17, x16, lsr #2
    //     0x5af858: tst             x16, HEAP, lsr #32
    //     0x5af85c: b.eq            #0x5af864
    //     0x5af860: bl              #0xd682ec
    // 0x5af864: b               #0x5afbb4
    // 0x5af868: mov             x5, x3
    // 0x5af86c: ldur            x3, [fp, #-8]
    // 0x5af870: LoadField: r6 = r4->field_17
    //     0x5af870: ldur            w6, [x4, #0x17]
    // 0x5af874: DecompressPointer r6
    //     0x5af874: add             x6, x6, HEAP, lsl #32
    // 0x5af878: stur            x6, [fp, #-0x10]
    // 0x5af87c: cmp             w6, NULL
    // 0x5af880: b.eq            #0x5afbcc
    // 0x5af884: mov             x0, x6
    // 0x5af888: r2 = Null
    //     0x5af888: mov             x2, NULL
    // 0x5af88c: r1 = Null
    //     0x5af88c: mov             x1, NULL
    // 0x5af890: r4 = LoadClassIdInstr(r0)
    //     0x5af890: ldur            x4, [x0, #-1]
    //     0x5af894: ubfx            x4, x4, #0xc, #0x14
    // 0x5af898: cmp             x4, #0x804
    // 0x5af89c: b.eq            #0x5af8b4
    // 0x5af8a0: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5af8a0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5af8a4: ldr             x8, [x8, #0x528]
    // 0x5af8a8: r3 = Null
    //     0x5af8a8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50720] Null
    //     0x5af8ac: ldr             x3, [x3, #0x720]
    // 0x5af8b0: r0 = DefaultTypeTest()
    //     0x5af8b0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af8b4: ldur            x3, [fp, #-0x10]
    // 0x5af8b8: LoadField: r4 = r3->field_13
    //     0x5af8b8: ldur            w4, [x3, #0x13]
    // 0x5af8bc: DecompressPointer r4
    //     0x5af8bc: add             x4, x4, HEAP, lsl #32
    // 0x5af8c0: stur            x4, [fp, #-0x20]
    // 0x5af8c4: cmp             w4, NULL
    // 0x5af8c8: b.ne            #0x5af9c8
    // 0x5af8cc: ldr             x5, [fp, #0x20]
    // 0x5af8d0: ldur            x4, [fp, #-8]
    // 0x5af8d4: LoadField: r2 = r4->field_b
    //     0x5af8d4: ldur            w2, [x4, #0xb]
    // 0x5af8d8: DecompressPointer r2
    //     0x5af8d8: add             x2, x2, HEAP, lsl #32
    // 0x5af8dc: ldr             x0, [fp, #0x10]
    // 0x5af8e0: r1 = Null
    //     0x5af8e0: mov             x1, NULL
    // 0x5af8e4: cmp             w0, NULL
    // 0x5af8e8: b.eq            #0x5af914
    // 0x5af8ec: cmp             w2, NULL
    // 0x5af8f0: b.eq            #0x5af914
    // 0x5af8f4: LoadField: r4 = r2->field_17
    //     0x5af8f4: ldur            w4, [x2, #0x17]
    // 0x5af8f8: DecompressPointer r4
    //     0x5af8f8: add             x4, x4, HEAP, lsl #32
    // 0x5af8fc: r8 = X0? bound RenderObject
    //     0x5af8fc: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af900: ldr             x8, [x8, #0x6e8]
    // 0x5af904: LoadField: r9 = r4->field_7
    //     0x5af904: ldur            x9, [x4, #7]
    // 0x5af908: r3 = Null
    //     0x5af908: add             x3, PP, #0x50, lsl #12  ; [pp+0x50730] Null
    //     0x5af90c: ldr             x3, [x3, #0x730]
    // 0x5af910: blr             x9
    // 0x5af914: ldr             x0, [fp, #0x10]
    // 0x5af918: ldur            x3, [fp, #-8]
    // 0x5af91c: StoreField: r3->field_f = r0
    //     0x5af91c: stur            w0, [x3, #0xf]
    //     0x5af920: ldurb           w16, [x3, #-1]
    //     0x5af924: ldurb           w17, [x0, #-1]
    //     0x5af928: and             x16, x17, x16, lsr #2
    //     0x5af92c: tst             x16, HEAP, lsr #32
    //     0x5af930: b.eq            #0x5af938
    //     0x5af934: bl              #0xd682ac
    // 0x5af938: ldur            x3, [fp, #-0x10]
    // 0x5af93c: LoadField: r2 = r3->field_b
    //     0x5af93c: ldur            w2, [x3, #0xb]
    // 0x5af940: DecompressPointer r2
    //     0x5af940: add             x2, x2, HEAP, lsl #32
    // 0x5af944: ldr             x0, [fp, #0x18]
    // 0x5af948: r1 = Null
    //     0x5af948: mov             x1, NULL
    // 0x5af94c: cmp             w0, NULL
    // 0x5af950: b.eq            #0x5af97c
    // 0x5af954: cmp             w2, NULL
    // 0x5af958: b.eq            #0x5af97c
    // 0x5af95c: LoadField: r4 = r2->field_17
    //     0x5af95c: ldur            w4, [x2, #0x17]
    // 0x5af960: DecompressPointer r4
    //     0x5af960: add             x4, x4, HEAP, lsl #32
    // 0x5af964: r8 = X0? bound RenderObject
    //     0x5af964: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af968: ldr             x8, [x8, #0x6e8]
    // 0x5af96c: LoadField: r9 = r4->field_7
    //     0x5af96c: ldur            x9, [x4, #7]
    // 0x5af970: r3 = Null
    //     0x5af970: add             x3, PP, #0x50, lsl #12  ; [pp+0x50740] Null
    //     0x5af974: ldr             x3, [x3, #0x740]
    // 0x5af978: blr             x9
    // 0x5af97c: ldr             x0, [fp, #0x18]
    // 0x5af980: ldur            x5, [fp, #-0x10]
    // 0x5af984: StoreField: r5->field_13 = r0
    //     0x5af984: stur            w0, [x5, #0x13]
    //     0x5af988: ldurb           w16, [x5, #-1]
    //     0x5af98c: ldurb           w17, [x0, #-1]
    //     0x5af990: and             x16, x17, x16, lsr #2
    //     0x5af994: tst             x16, HEAP, lsr #32
    //     0x5af998: b.eq            #0x5af9a0
    //     0x5af99c: bl              #0xd682ec
    // 0x5af9a0: ldr             x0, [fp, #0x18]
    // 0x5af9a4: ldr             x1, [fp, #0x20]
    // 0x5af9a8: StoreField: r1->field_6b = r0
    //     0x5af9a8: stur            w0, [x1, #0x6b]
    //     0x5af9ac: ldurb           w16, [x1, #-1]
    //     0x5af9b0: ldurb           w17, [x0, #-1]
    //     0x5af9b4: and             x16, x17, x16, lsr #2
    //     0x5af9b8: tst             x16, HEAP, lsr #32
    //     0x5af9bc: b.eq            #0x5af9c4
    //     0x5af9c0: bl              #0xd6826c
    // 0x5af9c4: b               #0x5afbb4
    // 0x5af9c8: mov             x5, x3
    // 0x5af9cc: ldur            x3, [fp, #-8]
    // 0x5af9d0: LoadField: r6 = r3->field_b
    //     0x5af9d0: ldur            w6, [x3, #0xb]
    // 0x5af9d4: DecompressPointer r6
    //     0x5af9d4: add             x6, x6, HEAP, lsl #32
    // 0x5af9d8: mov             x0, x4
    // 0x5af9dc: mov             x2, x6
    // 0x5af9e0: stur            x6, [fp, #-0x18]
    // 0x5af9e4: r1 = Null
    //     0x5af9e4: mov             x1, NULL
    // 0x5af9e8: cmp             w0, NULL
    // 0x5af9ec: b.eq            #0x5afa18
    // 0x5af9f0: cmp             w2, NULL
    // 0x5af9f4: b.eq            #0x5afa18
    // 0x5af9f8: LoadField: r4 = r2->field_17
    //     0x5af9f8: ldur            w4, [x2, #0x17]
    // 0x5af9fc: DecompressPointer r4
    //     0x5af9fc: add             x4, x4, HEAP, lsl #32
    // 0x5afa00: r8 = X0? bound RenderObject
    //     0x5afa00: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afa04: ldr             x8, [x8, #0x6e8]
    // 0x5afa08: LoadField: r9 = r4->field_7
    //     0x5afa08: ldur            x9, [x4, #7]
    // 0x5afa0c: r3 = Null
    //     0x5afa0c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50750] Null
    //     0x5afa10: ldr             x3, [x3, #0x750]
    // 0x5afa14: blr             x9
    // 0x5afa18: ldur            x0, [fp, #-0x20]
    // 0x5afa1c: ldur            x3, [fp, #-8]
    // 0x5afa20: StoreField: r3->field_13 = r0
    //     0x5afa20: stur            w0, [x3, #0x13]
    //     0x5afa24: ldurb           w16, [x3, #-1]
    //     0x5afa28: ldurb           w17, [x0, #-1]
    //     0x5afa2c: and             x16, x17, x16, lsr #2
    //     0x5afa30: tst             x16, HEAP, lsr #32
    //     0x5afa34: b.eq            #0x5afa3c
    //     0x5afa38: bl              #0xd682ac
    // 0x5afa3c: ldr             x0, [fp, #0x10]
    // 0x5afa40: ldur            x2, [fp, #-0x18]
    // 0x5afa44: r1 = Null
    //     0x5afa44: mov             x1, NULL
    // 0x5afa48: cmp             w0, NULL
    // 0x5afa4c: b.eq            #0x5afa78
    // 0x5afa50: cmp             w2, NULL
    // 0x5afa54: b.eq            #0x5afa78
    // 0x5afa58: LoadField: r4 = r2->field_17
    //     0x5afa58: ldur            w4, [x2, #0x17]
    // 0x5afa5c: DecompressPointer r4
    //     0x5afa5c: add             x4, x4, HEAP, lsl #32
    // 0x5afa60: r8 = X0? bound RenderObject
    //     0x5afa60: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afa64: ldr             x8, [x8, #0x6e8]
    // 0x5afa68: LoadField: r9 = r4->field_7
    //     0x5afa68: ldur            x9, [x4, #7]
    // 0x5afa6c: r3 = Null
    //     0x5afa6c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50760] Null
    //     0x5afa70: ldr             x3, [x3, #0x760]
    // 0x5afa74: blr             x9
    // 0x5afa78: ldr             x0, [fp, #0x10]
    // 0x5afa7c: ldur            x1, [fp, #-8]
    // 0x5afa80: StoreField: r1->field_f = r0
    //     0x5afa80: stur            w0, [x1, #0xf]
    //     0x5afa84: ldurb           w16, [x1, #-1]
    //     0x5afa88: ldurb           w17, [x0, #-1]
    //     0x5afa8c: and             x16, x17, x16, lsr #2
    //     0x5afa90: tst             x16, HEAP, lsr #32
    //     0x5afa94: b.eq            #0x5afa9c
    //     0x5afa98: bl              #0xd6826c
    // 0x5afa9c: ldur            x0, [fp, #-0x20]
    // 0x5afaa0: LoadField: r3 = r0->field_17
    //     0x5afaa0: ldur            w3, [x0, #0x17]
    // 0x5afaa4: DecompressPointer r3
    //     0x5afaa4: add             x3, x3, HEAP, lsl #32
    // 0x5afaa8: stur            x3, [fp, #-8]
    // 0x5afaac: cmp             w3, NULL
    // 0x5afab0: b.eq            #0x5afbd0
    // 0x5afab4: mov             x0, x3
    // 0x5afab8: r2 = Null
    //     0x5afab8: mov             x2, NULL
    // 0x5afabc: r1 = Null
    //     0x5afabc: mov             x1, NULL
    // 0x5afac0: r4 = LoadClassIdInstr(r0)
    //     0x5afac0: ldur            x4, [x0, #-1]
    //     0x5afac4: ubfx            x4, x4, #0xc, #0x14
    // 0x5afac8: cmp             x4, #0x804
    // 0x5afacc: b.eq            #0x5afae4
    // 0x5afad0: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5afad0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5afad4: ldr             x8, [x8, #0x528]
    // 0x5afad8: r3 = Null
    //     0x5afad8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50770] Null
    //     0x5afadc: ldr             x3, [x3, #0x770]
    // 0x5afae0: r0 = DefaultTypeTest()
    //     0x5afae0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5afae4: ldur            x3, [fp, #-0x10]
    // 0x5afae8: LoadField: r2 = r3->field_b
    //     0x5afae8: ldur            w2, [x3, #0xb]
    // 0x5afaec: DecompressPointer r2
    //     0x5afaec: add             x2, x2, HEAP, lsl #32
    // 0x5afaf0: ldr             x0, [fp, #0x18]
    // 0x5afaf4: r1 = Null
    //     0x5afaf4: mov             x1, NULL
    // 0x5afaf8: cmp             w0, NULL
    // 0x5afafc: b.eq            #0x5afb28
    // 0x5afb00: cmp             w2, NULL
    // 0x5afb04: b.eq            #0x5afb28
    // 0x5afb08: LoadField: r4 = r2->field_17
    //     0x5afb08: ldur            w4, [x2, #0x17]
    // 0x5afb0c: DecompressPointer r4
    //     0x5afb0c: add             x4, x4, HEAP, lsl #32
    // 0x5afb10: r8 = X0? bound RenderObject
    //     0x5afb10: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afb14: ldr             x8, [x8, #0x6e8]
    // 0x5afb18: LoadField: r9 = r4->field_7
    //     0x5afb18: ldur            x9, [x4, #7]
    // 0x5afb1c: r3 = Null
    //     0x5afb1c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50780] Null
    //     0x5afb20: ldr             x3, [x3, #0x780]
    // 0x5afb24: blr             x9
    // 0x5afb28: ldr             x0, [fp, #0x18]
    // 0x5afb2c: ldur            x1, [fp, #-0x10]
    // 0x5afb30: StoreField: r1->field_13 = r0
    //     0x5afb30: stur            w0, [x1, #0x13]
    //     0x5afb34: ldurb           w16, [x1, #-1]
    //     0x5afb38: ldurb           w17, [x0, #-1]
    //     0x5afb3c: and             x16, x17, x16, lsr #2
    //     0x5afb40: tst             x16, HEAP, lsr #32
    //     0x5afb44: b.eq            #0x5afb4c
    //     0x5afb48: bl              #0xd6826c
    // 0x5afb4c: ldur            x3, [fp, #-8]
    // 0x5afb50: LoadField: r2 = r3->field_b
    //     0x5afb50: ldur            w2, [x3, #0xb]
    // 0x5afb54: DecompressPointer r2
    //     0x5afb54: add             x2, x2, HEAP, lsl #32
    // 0x5afb58: ldr             x0, [fp, #0x18]
    // 0x5afb5c: r1 = Null
    //     0x5afb5c: mov             x1, NULL
    // 0x5afb60: cmp             w0, NULL
    // 0x5afb64: b.eq            #0x5afb90
    // 0x5afb68: cmp             w2, NULL
    // 0x5afb6c: b.eq            #0x5afb90
    // 0x5afb70: LoadField: r4 = r2->field_17
    //     0x5afb70: ldur            w4, [x2, #0x17]
    // 0x5afb74: DecompressPointer r4
    //     0x5afb74: add             x4, x4, HEAP, lsl #32
    // 0x5afb78: r8 = X0? bound RenderObject
    //     0x5afb78: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afb7c: ldr             x8, [x8, #0x6e8]
    // 0x5afb80: LoadField: r9 = r4->field_7
    //     0x5afb80: ldur            x9, [x4, #7]
    // 0x5afb84: r3 = Null
    //     0x5afb84: add             x3, PP, #0x50, lsl #12  ; [pp+0x50790] Null
    //     0x5afb88: ldr             x3, [x3, #0x790]
    // 0x5afb8c: blr             x9
    // 0x5afb90: ldr             x0, [fp, #0x18]
    // 0x5afb94: ldur            x1, [fp, #-8]
    // 0x5afb98: StoreField: r1->field_f = r0
    //     0x5afb98: stur            w0, [x1, #0xf]
    //     0x5afb9c: ldurb           w16, [x1, #-1]
    //     0x5afba0: ldurb           w17, [x0, #-1]
    //     0x5afba4: and             x16, x17, x16, lsr #2
    //     0x5afba8: tst             x16, HEAP, lsr #32
    //     0x5afbac: b.eq            #0x5afbb4
    //     0x5afbb0: bl              #0xd6826c
    // 0x5afbb4: r0 = Null
    //     0x5afbb4: mov             x0, NULL
    // 0x5afbb8: LeaveFrame
    //     0x5afbb8: mov             SP, fp
    //     0x5afbbc: ldp             fp, lr, [SP], #0x10
    // 0x5afbc0: ret
    //     0x5afbc0: ret             
    // 0x5afbc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afbc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5afbc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afbc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5afbcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afbcc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5afbd0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afbd0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeFromChildList(/* No info */) {
    // ** addr: 0x5afbd4, size: 0x2c4
    // 0x5afbd4: EnterFrame
    //     0x5afbd4: stp             fp, lr, [SP, #-0x10]!
    //     0x5afbd8: mov             fp, SP
    // 0x5afbdc: AllocStack(0x20)
    //     0x5afbdc: sub             SP, SP, #0x20
    // 0x5afbe0: ldr             x0, [fp, #0x10]
    // 0x5afbe4: LoadField: r3 = r0->field_17
    //     0x5afbe4: ldur            w3, [x0, #0x17]
    // 0x5afbe8: DecompressPointer r3
    //     0x5afbe8: add             x3, x3, HEAP, lsl #32
    // 0x5afbec: stur            x3, [fp, #-8]
    // 0x5afbf0: cmp             w3, NULL
    // 0x5afbf4: b.eq            #0x5afe8c
    // 0x5afbf8: mov             x0, x3
    // 0x5afbfc: r2 = Null
    //     0x5afbfc: mov             x2, NULL
    // 0x5afc00: r1 = Null
    //     0x5afc00: mov             x1, NULL
    // 0x5afc04: r4 = LoadClassIdInstr(r0)
    //     0x5afc04: ldur            x4, [x0, #-1]
    //     0x5afc08: ubfx            x4, x4, #0xc, #0x14
    // 0x5afc0c: cmp             x4, #0x804
    // 0x5afc10: b.eq            #0x5afc28
    // 0x5afc14: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5afc14: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5afc18: ldr             x8, [x8, #0x528]
    // 0x5afc1c: r3 = Null
    //     0x5afc1c: add             x3, PP, #0x50, lsl #12  ; [pp+0x507a0] Null
    //     0x5afc20: ldr             x3, [x3, #0x7a0]
    // 0x5afc24: r0 = DefaultTypeTest()
    //     0x5afc24: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5afc28: ldur            x3, [fp, #-8]
    // 0x5afc2c: LoadField: r4 = r3->field_f
    //     0x5afc2c: ldur            w4, [x3, #0xf]
    // 0x5afc30: DecompressPointer r4
    //     0x5afc30: add             x4, x4, HEAP, lsl #32
    // 0x5afc34: stur            x4, [fp, #-0x18]
    // 0x5afc38: cmp             w4, NULL
    // 0x5afc3c: b.ne            #0x5afc6c
    // 0x5afc40: ldr             x5, [fp, #0x18]
    // 0x5afc44: LoadField: r0 = r3->field_13
    //     0x5afc44: ldur            w0, [x3, #0x13]
    // 0x5afc48: DecompressPointer r0
    //     0x5afc48: add             x0, x0, HEAP, lsl #32
    // 0x5afc4c: StoreField: r5->field_67 = r0
    //     0x5afc4c: stur            w0, [x5, #0x67]
    //     0x5afc50: ldurb           w16, [x5, #-1]
    //     0x5afc54: ldurb           w17, [x0, #-1]
    //     0x5afc58: and             x16, x17, x16, lsr #2
    //     0x5afc5c: tst             x16, HEAP, lsr #32
    //     0x5afc60: b.eq            #0x5afc68
    //     0x5afc64: bl              #0xd682ec
    // 0x5afc68: b               #0x5afd30
    // 0x5afc6c: ldr             x5, [fp, #0x18]
    // 0x5afc70: LoadField: r6 = r4->field_17
    //     0x5afc70: ldur            w6, [x4, #0x17]
    // 0x5afc74: DecompressPointer r6
    //     0x5afc74: add             x6, x6, HEAP, lsl #32
    // 0x5afc78: stur            x6, [fp, #-0x10]
    // 0x5afc7c: cmp             w6, NULL
    // 0x5afc80: b.eq            #0x5afe90
    // 0x5afc84: mov             x0, x6
    // 0x5afc88: r2 = Null
    //     0x5afc88: mov             x2, NULL
    // 0x5afc8c: r1 = Null
    //     0x5afc8c: mov             x1, NULL
    // 0x5afc90: r4 = LoadClassIdInstr(r0)
    //     0x5afc90: ldur            x4, [x0, #-1]
    //     0x5afc94: ubfx            x4, x4, #0xc, #0x14
    // 0x5afc98: cmp             x4, #0x804
    // 0x5afc9c: b.eq            #0x5afcb4
    // 0x5afca0: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5afca0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5afca4: ldr             x8, [x8, #0x528]
    // 0x5afca8: r3 = Null
    //     0x5afca8: add             x3, PP, #0x50, lsl #12  ; [pp+0x507b0] Null
    //     0x5afcac: ldr             x3, [x3, #0x7b0]
    // 0x5afcb0: r0 = DefaultTypeTest()
    //     0x5afcb0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5afcb4: ldur            x3, [fp, #-8]
    // 0x5afcb8: LoadField: r4 = r3->field_13
    //     0x5afcb8: ldur            w4, [x3, #0x13]
    // 0x5afcbc: DecompressPointer r4
    //     0x5afcbc: add             x4, x4, HEAP, lsl #32
    // 0x5afcc0: ldur            x5, [fp, #-0x10]
    // 0x5afcc4: stur            x4, [fp, #-0x20]
    // 0x5afcc8: LoadField: r2 = r5->field_b
    //     0x5afcc8: ldur            w2, [x5, #0xb]
    // 0x5afccc: DecompressPointer r2
    //     0x5afccc: add             x2, x2, HEAP, lsl #32
    // 0x5afcd0: mov             x0, x4
    // 0x5afcd4: r1 = Null
    //     0x5afcd4: mov             x1, NULL
    // 0x5afcd8: cmp             w0, NULL
    // 0x5afcdc: b.eq            #0x5afd08
    // 0x5afce0: cmp             w2, NULL
    // 0x5afce4: b.eq            #0x5afd08
    // 0x5afce8: LoadField: r4 = r2->field_17
    //     0x5afce8: ldur            w4, [x2, #0x17]
    // 0x5afcec: DecompressPointer r4
    //     0x5afcec: add             x4, x4, HEAP, lsl #32
    // 0x5afcf0: r8 = X0? bound RenderObject
    //     0x5afcf0: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afcf4: ldr             x8, [x8, #0x6e8]
    // 0x5afcf8: LoadField: r9 = r4->field_7
    //     0x5afcf8: ldur            x9, [x4, #7]
    // 0x5afcfc: r3 = Null
    //     0x5afcfc: add             x3, PP, #0x50, lsl #12  ; [pp+0x507c0] Null
    //     0x5afd00: ldr             x3, [x3, #0x7c0]
    // 0x5afd04: blr             x9
    // 0x5afd08: ldur            x0, [fp, #-0x20]
    // 0x5afd0c: ldur            x1, [fp, #-0x10]
    // 0x5afd10: StoreField: r1->field_13 = r0
    //     0x5afd10: stur            w0, [x1, #0x13]
    //     0x5afd14: ldurb           w16, [x1, #-1]
    //     0x5afd18: ldurb           w17, [x0, #-1]
    //     0x5afd1c: and             x16, x17, x16, lsr #2
    //     0x5afd20: tst             x16, HEAP, lsr #32
    //     0x5afd24: b.eq            #0x5afd2c
    //     0x5afd28: bl              #0xd6826c
    // 0x5afd2c: ldur            x3, [fp, #-8]
    // 0x5afd30: LoadField: r0 = r3->field_13
    //     0x5afd30: ldur            w0, [x3, #0x13]
    // 0x5afd34: DecompressPointer r0
    //     0x5afd34: add             x0, x0, HEAP, lsl #32
    // 0x5afd38: cmp             w0, NULL
    // 0x5afd3c: b.ne            #0x5afd68
    // 0x5afd40: ldr             x4, [fp, #0x18]
    // 0x5afd44: ldur            x0, [fp, #-0x18]
    // 0x5afd48: StoreField: r4->field_6b = r0
    //     0x5afd48: stur            w0, [x4, #0x6b]
    //     0x5afd4c: ldurb           w16, [x4, #-1]
    //     0x5afd50: ldurb           w17, [x0, #-1]
    //     0x5afd54: and             x16, x17, x16, lsr #2
    //     0x5afd58: tst             x16, HEAP, lsr #32
    //     0x5afd5c: b.eq            #0x5afd64
    //     0x5afd60: bl              #0xd682cc
    // 0x5afd64: b               #0x5afe20
    // 0x5afd68: ldr             x4, [fp, #0x18]
    // 0x5afd6c: LoadField: r5 = r0->field_17
    //     0x5afd6c: ldur            w5, [x0, #0x17]
    // 0x5afd70: DecompressPointer r5
    //     0x5afd70: add             x5, x5, HEAP, lsl #32
    // 0x5afd74: stur            x5, [fp, #-0x10]
    // 0x5afd78: cmp             w5, NULL
    // 0x5afd7c: b.eq            #0x5afe94
    // 0x5afd80: mov             x0, x5
    // 0x5afd84: r2 = Null
    //     0x5afd84: mov             x2, NULL
    // 0x5afd88: r1 = Null
    //     0x5afd88: mov             x1, NULL
    // 0x5afd8c: r4 = LoadClassIdInstr(r0)
    //     0x5afd8c: ldur            x4, [x0, #-1]
    //     0x5afd90: ubfx            x4, x4, #0xc, #0x14
    // 0x5afd94: cmp             x4, #0x804
    // 0x5afd98: b.eq            #0x5afdb0
    // 0x5afd9c: r8 = ToolbarItemsParentData<RenderBox>
    //     0x5afd9c: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x5afda0: ldr             x8, [x8, #0x528]
    // 0x5afda4: r3 = Null
    //     0x5afda4: add             x3, PP, #0x50, lsl #12  ; [pp+0x507d0] Null
    //     0x5afda8: ldr             x3, [x3, #0x7d0]
    // 0x5afdac: r0 = DefaultTypeTest()
    //     0x5afdac: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5afdb0: ldur            x3, [fp, #-0x10]
    // 0x5afdb4: LoadField: r2 = r3->field_b
    //     0x5afdb4: ldur            w2, [x3, #0xb]
    // 0x5afdb8: DecompressPointer r2
    //     0x5afdb8: add             x2, x2, HEAP, lsl #32
    // 0x5afdbc: ldur            x0, [fp, #-0x18]
    // 0x5afdc0: r1 = Null
    //     0x5afdc0: mov             x1, NULL
    // 0x5afdc4: cmp             w0, NULL
    // 0x5afdc8: b.eq            #0x5afdf4
    // 0x5afdcc: cmp             w2, NULL
    // 0x5afdd0: b.eq            #0x5afdf4
    // 0x5afdd4: LoadField: r4 = r2->field_17
    //     0x5afdd4: ldur            w4, [x2, #0x17]
    // 0x5afdd8: DecompressPointer r4
    //     0x5afdd8: add             x4, x4, HEAP, lsl #32
    // 0x5afddc: r8 = X0? bound RenderObject
    //     0x5afddc: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afde0: ldr             x8, [x8, #0x6e8]
    // 0x5afde4: LoadField: r9 = r4->field_7
    //     0x5afde4: ldur            x9, [x4, #7]
    // 0x5afde8: r3 = Null
    //     0x5afde8: add             x3, PP, #0x50, lsl #12  ; [pp+0x507e0] Null
    //     0x5afdec: ldr             x3, [x3, #0x7e0]
    // 0x5afdf0: blr             x9
    // 0x5afdf4: ldur            x0, [fp, #-0x18]
    // 0x5afdf8: ldur            x1, [fp, #-0x10]
    // 0x5afdfc: StoreField: r1->field_f = r0
    //     0x5afdfc: stur            w0, [x1, #0xf]
    //     0x5afe00: ldurb           w16, [x1, #-1]
    //     0x5afe04: ldurb           w17, [x0, #-1]
    //     0x5afe08: and             x16, x17, x16, lsr #2
    //     0x5afe0c: tst             x16, HEAP, lsr #32
    //     0x5afe10: b.eq            #0x5afe18
    //     0x5afe14: bl              #0xd6826c
    // 0x5afe18: ldr             x4, [fp, #0x18]
    // 0x5afe1c: ldur            x3, [fp, #-8]
    // 0x5afe20: LoadField: r2 = r3->field_b
    //     0x5afe20: ldur            w2, [x3, #0xb]
    // 0x5afe24: DecompressPointer r2
    //     0x5afe24: add             x2, x2, HEAP, lsl #32
    // 0x5afe28: r0 = Null
    //     0x5afe28: mov             x0, NULL
    // 0x5afe2c: r1 = Null
    //     0x5afe2c: mov             x1, NULL
    // 0x5afe30: cmp             w0, NULL
    // 0x5afe34: b.eq            #0x5afe60
    // 0x5afe38: cmp             w2, NULL
    // 0x5afe3c: b.eq            #0x5afe60
    // 0x5afe40: LoadField: r4 = r2->field_17
    //     0x5afe40: ldur            w4, [x2, #0x17]
    // 0x5afe44: DecompressPointer r4
    //     0x5afe44: add             x4, x4, HEAP, lsl #32
    // 0x5afe48: r8 = X0? bound RenderObject
    //     0x5afe48: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5afe4c: ldr             x8, [x8, #0x6e8]
    // 0x5afe50: LoadField: r9 = r4->field_7
    //     0x5afe50: ldur            x9, [x4, #7]
    // 0x5afe54: r3 = Null
    //     0x5afe54: add             x3, PP, #0x50, lsl #12  ; [pp+0x507f0] Null
    //     0x5afe58: ldr             x3, [x3, #0x7f0]
    // 0x5afe5c: blr             x9
    // 0x5afe60: ldur            x1, [fp, #-8]
    // 0x5afe64: StoreField: r1->field_f = rNULL
    //     0x5afe64: stur            NULL, [x1, #0xf]
    // 0x5afe68: StoreField: r1->field_13 = rNULL
    //     0x5afe68: stur            NULL, [x1, #0x13]
    // 0x5afe6c: ldr             x1, [fp, #0x18]
    // 0x5afe70: LoadField: r2 = r1->field_5f
    //     0x5afe70: ldur            x2, [x1, #0x5f]
    // 0x5afe74: sub             x3, x2, #1
    // 0x5afe78: StoreField: r1->field_5f = r3
    //     0x5afe78: stur            x3, [x1, #0x5f]
    // 0x5afe7c: r0 = Null
    //     0x5afe7c: mov             x0, NULL
    // 0x5afe80: LeaveFrame
    //     0x5afe80: mov             SP, fp
    //     0x5afe84: ldp             fp, lr, [SP], #0x10
    // 0x5afe88: ret
    //     0x5afe88: ret             
    // 0x5afe8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afe8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5afe90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afe90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5afe94: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5afe94: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x5e9954, size: 0x90
    // 0x5e9954: EnterFrame
    //     0x5e9954: stp             fp, lr, [SP, #-0x10]!
    //     0x5e9958: mov             fp, SP
    // 0x5e995c: CheckStackOverflow
    //     0x5e995c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e9960: cmp             SP, x16
    //     0x5e9964: b.ls            #0x5e99dc
    // 0x5e9968: ldr             x0, [fp, #0x10]
    // 0x5e996c: r2 = Null
    //     0x5e996c: mov             x2, NULL
    // 0x5e9970: r1 = Null
    //     0x5e9970: mov             x1, NULL
    // 0x5e9974: r4 = 59
    //     0x5e9974: mov             x4, #0x3b
    // 0x5e9978: branchIfSmi(r0, 0x5e9984)
    //     0x5e9978: tbz             w0, #0, #0x5e9984
    // 0x5e997c: r4 = LoadClassIdInstr(r0)
    //     0x5e997c: ldur            x4, [x0, #-1]
    //     0x5e9980: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9984: sub             x4, x4, #0x965
    // 0x5e9988: cmp             x4, #0x8b
    // 0x5e998c: b.ls            #0x5e99a4
    // 0x5e9990: r8 = RenderBox
    //     0x5e9990: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9994: ldr             x8, [x8, #0xfa0]
    // 0x5e9998: r3 = Null
    //     0x5e9998: add             x3, PP, #0x50, lsl #12  ; [pp+0x50800] Null
    //     0x5e999c: ldr             x3, [x3, #0x800]
    // 0x5e99a0: r0 = RenderBox()
    //     0x5e99a0: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e99a4: ldr             x16, [fp, #0x18]
    // 0x5e99a8: ldr             lr, [fp, #0x10]
    // 0x5e99ac: stp             lr, x16, [SP, #-0x10]!
    // 0x5e99b0: r0 = _removeFromChildList()
    //     0x5e99b0: bl              #0x5afbd4  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5e99b4: add             SP, SP, #0x10
    // 0x5e99b8: ldr             x16, [fp, #0x18]
    // 0x5e99bc: ldr             lr, [fp, #0x10]
    // 0x5e99c0: stp             lr, x16, [SP, #-0x10]!
    // 0x5e99c4: r0 = dropChild()
    //     0x5e99c4: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e99c8: add             SP, SP, #0x10
    // 0x5e99cc: r0 = Null
    //     0x5e99cc: mov             x0, NULL
    // 0x5e99d0: LeaveFrame
    //     0x5e99d0: mov             SP, fp
    //     0x5e99d4: ldp             fp, lr, [SP], #0x10
    // 0x5e99d8: ret
    //     0x5e99d8: ret             
    // 0x5e99dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e99dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e99e0: b               #0x5e9968
  }
  _ insert(/* No info */) {
    // ** addr: 0x5e9a74, size: 0xd0
    // 0x5e9a74: EnterFrame
    //     0x5e9a74: stp             fp, lr, [SP, #-0x10]!
    //     0x5e9a78: mov             fp, SP
    // 0x5e9a7c: CheckStackOverflow
    //     0x5e9a7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e9a80: cmp             SP, x16
    //     0x5e9a84: b.ls            #0x5e9b3c
    // 0x5e9a88: ldr             x0, [fp, #0x18]
    // 0x5e9a8c: r2 = Null
    //     0x5e9a8c: mov             x2, NULL
    // 0x5e9a90: r1 = Null
    //     0x5e9a90: mov             x1, NULL
    // 0x5e9a94: r4 = 59
    //     0x5e9a94: mov             x4, #0x3b
    // 0x5e9a98: branchIfSmi(r0, 0x5e9aa4)
    //     0x5e9a98: tbz             w0, #0, #0x5e9aa4
    // 0x5e9a9c: r4 = LoadClassIdInstr(r0)
    //     0x5e9a9c: ldur            x4, [x0, #-1]
    //     0x5e9aa0: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9aa4: sub             x4, x4, #0x965
    // 0x5e9aa8: cmp             x4, #0x8b
    // 0x5e9aac: b.ls            #0x5e9ac4
    // 0x5e9ab0: r8 = RenderBox
    //     0x5e9ab0: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9ab4: ldr             x8, [x8, #0xfa0]
    // 0x5e9ab8: r3 = Null
    //     0x5e9ab8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50810] Null
    //     0x5e9abc: ldr             x3, [x3, #0x810]
    // 0x5e9ac0: r0 = RenderBox()
    //     0x5e9ac0: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e9ac4: ldr             x0, [fp, #0x10]
    // 0x5e9ac8: r2 = Null
    //     0x5e9ac8: mov             x2, NULL
    // 0x5e9acc: r1 = Null
    //     0x5e9acc: mov             x1, NULL
    // 0x5e9ad0: r4 = 59
    //     0x5e9ad0: mov             x4, #0x3b
    // 0x5e9ad4: branchIfSmi(r0, 0x5e9ae0)
    //     0x5e9ad4: tbz             w0, #0, #0x5e9ae0
    // 0x5e9ad8: r4 = LoadClassIdInstr(r0)
    //     0x5e9ad8: ldur            x4, [x0, #-1]
    //     0x5e9adc: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9ae0: sub             x4, x4, #0x965
    // 0x5e9ae4: cmp             x4, #0x8b
    // 0x5e9ae8: b.ls            #0x5e9afc
    // 0x5e9aec: r8 = RenderBox?
    //     0x5e9aec: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5e9af0: r3 = Null
    //     0x5e9af0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50820] Null
    //     0x5e9af4: ldr             x3, [x3, #0x820]
    // 0x5e9af8: r0 = RenderBox?()
    //     0x5e9af8: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5e9afc: ldr             x16, [fp, #0x20]
    // 0x5e9b00: ldr             lr, [fp, #0x18]
    // 0x5e9b04: stp             lr, x16, [SP, #-0x10]!
    // 0x5e9b08: r0 = adoptChild()
    //     0x5e9b08: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x5e9b0c: add             SP, SP, #0x10
    // 0x5e9b10: ldr             x16, [fp, #0x20]
    // 0x5e9b14: ldr             lr, [fp, #0x18]
    // 0x5e9b18: stp             lr, x16, [SP, #-0x10]!
    // 0x5e9b1c: ldr             x16, [fp, #0x10]
    // 0x5e9b20: SaveReg r16
    //     0x5e9b20: str             x16, [SP, #-8]!
    // 0x5e9b24: r0 = _insertIntoChildList()
    //     0x5e9b24: bl              #0x5af674  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5e9b28: add             SP, SP, #0x18
    // 0x5e9b2c: r0 = Null
    //     0x5e9b2c: mov             x0, NULL
    // 0x5e9b30: LeaveFrame
    //     0x5e9b30: mov             SP, fp
    //     0x5e9b34: ldp             fp, lr, [SP], #0x10
    // 0x5e9b38: ret
    //     0x5e9b38: ret             
    // 0x5e9b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e9b3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e9b40: b               #0x5e9a88
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bfa38, size: 0xd8
    // 0x6bfa38: EnterFrame
    //     0x6bfa38: stp             fp, lr, [SP, #-0x10]!
    //     0x6bfa3c: mov             fp, SP
    // 0x6bfa40: AllocStack(0x10)
    //     0x6bfa40: sub             SP, SP, #0x10
    // 0x6bfa44: CheckStackOverflow
    //     0x6bfa44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bfa48: cmp             SP, x16
    //     0x6bfa4c: b.ls            #0x6bfafc
    // 0x6bfa50: ldr             x0, [fp, #0x18]
    // 0x6bfa54: LoadField: r1 = r0->field_67
    //     0x6bfa54: ldur            w1, [x0, #0x67]
    // 0x6bfa58: DecompressPointer r1
    //     0x6bfa58: add             x1, x1, HEAP, lsl #32
    // 0x6bfa5c: stur            x1, [fp, #-8]
    // 0x6bfa60: CheckStackOverflow
    //     0x6bfa60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bfa64: cmp             SP, x16
    //     0x6bfa68: b.ls            #0x6bfb04
    // 0x6bfa6c: cmp             w1, NULL
    // 0x6bfa70: b.eq            #0x6bfaec
    // 0x6bfa74: ldr             x16, [fp, #0x10]
    // 0x6bfa78: stp             x1, x16, [SP, #-0x10]!
    // 0x6bfa7c: ldr             x0, [fp, #0x10]
    // 0x6bfa80: ClosureCall
    //     0x6bfa80: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bfa84: ldur            x2, [x0, #0x1f]
    //     0x6bfa88: blr             x2
    // 0x6bfa8c: add             SP, SP, #0x10
    // 0x6bfa90: ldur            x0, [fp, #-8]
    // 0x6bfa94: LoadField: r3 = r0->field_17
    //     0x6bfa94: ldur            w3, [x0, #0x17]
    // 0x6bfa98: DecompressPointer r3
    //     0x6bfa98: add             x3, x3, HEAP, lsl #32
    // 0x6bfa9c: stur            x3, [fp, #-0x10]
    // 0x6bfaa0: cmp             w3, NULL
    // 0x6bfaa4: b.eq            #0x6bfb0c
    // 0x6bfaa8: mov             x0, x3
    // 0x6bfaac: r2 = Null
    //     0x6bfaac: mov             x2, NULL
    // 0x6bfab0: r1 = Null
    //     0x6bfab0: mov             x1, NULL
    // 0x6bfab4: r4 = LoadClassIdInstr(r0)
    //     0x6bfab4: ldur            x4, [x0, #-1]
    //     0x6bfab8: ubfx            x4, x4, #0xc, #0x14
    // 0x6bfabc: cmp             x4, #0x804
    // 0x6bfac0: b.eq            #0x6bfad8
    // 0x6bfac4: r8 = ToolbarItemsParentData<RenderBox>
    //     0x6bfac4: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x6bfac8: ldr             x8, [x8, #0x528]
    // 0x6bfacc: r3 = Null
    //     0x6bfacc: add             x3, PP, #0x50, lsl #12  ; [pp+0x50660] Null
    //     0x6bfad0: ldr             x3, [x3, #0x660]
    // 0x6bfad4: r0 = DefaultTypeTest()
    //     0x6bfad4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bfad8: ldur            x1, [fp, #-0x10]
    // 0x6bfadc: LoadField: r0 = r1->field_13
    //     0x6bfadc: ldur            w0, [x1, #0x13]
    // 0x6bfae0: DecompressPointer r0
    //     0x6bfae0: add             x0, x0, HEAP, lsl #32
    // 0x6bfae4: mov             x1, x0
    // 0x6bfae8: b               #0x6bfa5c
    // 0x6bfaec: r0 = Null
    //     0x6bfaec: mov             x0, NULL
    // 0x6bfaf0: LeaveFrame
    //     0x6bfaf0: mov             SP, fp
    //     0x6bfaf4: ldp             fp, lr, [SP], #0x10
    // 0x6bfaf8: ret
    //     0x6bfaf8: ret             
    // 0x6bfafc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bfafc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bfb00: b               #0x6bfa50
    // 0x6bfb04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bfb04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bfb08: b               #0x6bfa6c
    // 0x6bfb0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bfb0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792d34, size: 0xf8
    // 0x792d34: EnterFrame
    //     0x792d34: stp             fp, lr, [SP, #-0x10]!
    //     0x792d38: mov             fp, SP
    // 0x792d3c: AllocStack(0x10)
    //     0x792d3c: sub             SP, SP, #0x10
    // 0x792d40: CheckStackOverflow
    //     0x792d40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792d44: cmp             SP, x16
    //     0x792d48: b.ls            #0x792e18
    // 0x792d4c: ldr             x1, [fp, #0x10]
    // 0x792d50: LoadField: r0 = r1->field_67
    //     0x792d50: ldur            w0, [x1, #0x67]
    // 0x792d54: DecompressPointer r0
    //     0x792d54: add             x0, x0, HEAP, lsl #32
    // 0x792d58: mov             x2, x0
    // 0x792d5c: stur            x2, [fp, #-8]
    // 0x792d60: CheckStackOverflow
    //     0x792d60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792d64: cmp             SP, x16
    //     0x792d68: b.ls            #0x792e20
    // 0x792d6c: cmp             w2, NULL
    // 0x792d70: b.eq            #0x792e08
    // 0x792d74: LoadField: r0 = r2->field_7
    //     0x792d74: ldur            x0, [x2, #7]
    // 0x792d78: LoadField: r3 = r1->field_7
    //     0x792d78: ldur            x3, [x1, #7]
    // 0x792d7c: cmp             x0, x3
    // 0x792d80: b.gt            #0x792dac
    // 0x792d84: add             x0, x3, #1
    // 0x792d88: StoreField: r2->field_7 = r0
    //     0x792d88: stur            x0, [x2, #7]
    // 0x792d8c: r0 = LoadClassIdInstr(r2)
    //     0x792d8c: ldur            x0, [x2, #-1]
    //     0x792d90: ubfx            x0, x0, #0xc, #0x14
    // 0x792d94: SaveReg r2
    //     0x792d94: str             x2, [SP, #-8]!
    // 0x792d98: r0 = GDT[cid_x0 + 0xbdf1]()
    //     0x792d98: mov             x17, #0xbdf1
    //     0x792d9c: add             lr, x0, x17
    //     0x792da0: ldr             lr, [x21, lr, lsl #3]
    //     0x792da4: blr             lr
    // 0x792da8: add             SP, SP, #8
    // 0x792dac: ldur            x0, [fp, #-8]
    // 0x792db0: LoadField: r3 = r0->field_17
    //     0x792db0: ldur            w3, [x0, #0x17]
    // 0x792db4: DecompressPointer r3
    //     0x792db4: add             x3, x3, HEAP, lsl #32
    // 0x792db8: stur            x3, [fp, #-0x10]
    // 0x792dbc: cmp             w3, NULL
    // 0x792dc0: b.eq            #0x792e28
    // 0x792dc4: mov             x0, x3
    // 0x792dc8: r2 = Null
    //     0x792dc8: mov             x2, NULL
    // 0x792dcc: r1 = Null
    //     0x792dcc: mov             x1, NULL
    // 0x792dd0: r4 = LoadClassIdInstr(r0)
    //     0x792dd0: ldur            x4, [x0, #-1]
    //     0x792dd4: ubfx            x4, x4, #0xc, #0x14
    // 0x792dd8: cmp             x4, #0x804
    // 0x792ddc: b.eq            #0x792df4
    // 0x792de0: r8 = ToolbarItemsParentData<RenderBox>
    //     0x792de0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x792de4: ldr             x8, [x8, #0x528]
    // 0x792de8: r3 = Null
    //     0x792de8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50670] Null
    //     0x792dec: ldr             x3, [x3, #0x670]
    // 0x792df0: r0 = DefaultTypeTest()
    //     0x792df0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x792df4: ldur            x1, [fp, #-0x10]
    // 0x792df8: LoadField: r2 = r1->field_13
    //     0x792df8: ldur            w2, [x1, #0x13]
    // 0x792dfc: DecompressPointer r2
    //     0x792dfc: add             x2, x2, HEAP, lsl #32
    // 0x792e00: ldr             x1, [fp, #0x10]
    // 0x792e04: b               #0x792d5c
    // 0x792e08: r0 = Null
    //     0x792e08: mov             x0, NULL
    // 0x792e0c: LeaveFrame
    //     0x792e0c: mov             SP, fp
    //     0x792e10: ldp             fp, lr, [SP], #0x10
    // 0x792e14: ret
    //     0x792e14: ret             
    // 0x792e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792e18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792e1c: b               #0x792d4c
    // 0x792e20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792e20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792e24: b               #0x792d6c
    // 0x792e28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x792e28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd92c, size: 0x128
    // 0x9bd92c: EnterFrame
    //     0x9bd92c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd930: mov             fp, SP
    // 0x9bd934: AllocStack(0x10)
    //     0x9bd934: sub             SP, SP, #0x10
    // 0x9bd938: CheckStackOverflow
    //     0x9bd938: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd93c: cmp             SP, x16
    //     0x9bd940: b.ls            #0x9bda40
    // 0x9bd944: ldr             x0, [fp, #0x10]
    // 0x9bd948: r2 = Null
    //     0x9bd948: mov             x2, NULL
    // 0x9bd94c: r1 = Null
    //     0x9bd94c: mov             x1, NULL
    // 0x9bd950: r4 = 59
    //     0x9bd950: mov             x4, #0x3b
    // 0x9bd954: branchIfSmi(r0, 0x9bd960)
    //     0x9bd954: tbz             w0, #0, #0x9bd960
    // 0x9bd958: r4 = LoadClassIdInstr(r0)
    //     0x9bd958: ldur            x4, [x0, #-1]
    //     0x9bd95c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd960: cmp             x4, #0x7e6
    // 0x9bd964: b.eq            #0x9bd978
    // 0x9bd968: r8 = PipelineOwner
    //     0x9bd968: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd96c: r3 = Null
    //     0x9bd96c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50690] Null
    //     0x9bd970: ldr             x3, [x3, #0x690]
    // 0x9bd974: r0 = DefaultTypeTest()
    //     0x9bd974: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd978: ldr             x16, [fp, #0x18]
    // 0x9bd97c: ldr             lr, [fp, #0x10]
    // 0x9bd980: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd984: r0 = attach()
    //     0x9bd984: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bd988: add             SP, SP, #0x10
    // 0x9bd98c: ldr             x0, [fp, #0x18]
    // 0x9bd990: LoadField: r1 = r0->field_67
    //     0x9bd990: ldur            w1, [x0, #0x67]
    // 0x9bd994: DecompressPointer r1
    //     0x9bd994: add             x1, x1, HEAP, lsl #32
    // 0x9bd998: stur            x1, [fp, #-8]
    // 0x9bd99c: CheckStackOverflow
    //     0x9bd99c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd9a0: cmp             SP, x16
    //     0x9bd9a4: b.ls            #0x9bda48
    // 0x9bd9a8: cmp             w1, NULL
    // 0x9bd9ac: b.eq            #0x9bda30
    // 0x9bd9b0: r0 = LoadClassIdInstr(r1)
    //     0x9bd9b0: ldur            x0, [x1, #-1]
    //     0x9bd9b4: ubfx            x0, x0, #0xc, #0x14
    // 0x9bd9b8: ldr             x16, [fp, #0x10]
    // 0x9bd9bc: stp             x16, x1, [SP, #-0x10]!
    // 0x9bd9c0: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bd9c0: mov             x17, #0xaf1f
    //     0x9bd9c4: add             lr, x0, x17
    //     0x9bd9c8: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd9cc: blr             lr
    // 0x9bd9d0: add             SP, SP, #0x10
    // 0x9bd9d4: ldur            x0, [fp, #-8]
    // 0x9bd9d8: LoadField: r3 = r0->field_17
    //     0x9bd9d8: ldur            w3, [x0, #0x17]
    // 0x9bd9dc: DecompressPointer r3
    //     0x9bd9dc: add             x3, x3, HEAP, lsl #32
    // 0x9bd9e0: stur            x3, [fp, #-0x10]
    // 0x9bd9e4: cmp             w3, NULL
    // 0x9bd9e8: b.eq            #0x9bda50
    // 0x9bd9ec: mov             x0, x3
    // 0x9bd9f0: r2 = Null
    //     0x9bd9f0: mov             x2, NULL
    // 0x9bd9f4: r1 = Null
    //     0x9bd9f4: mov             x1, NULL
    // 0x9bd9f8: r4 = LoadClassIdInstr(r0)
    //     0x9bd9f8: ldur            x4, [x0, #-1]
    //     0x9bd9fc: ubfx            x4, x4, #0xc, #0x14
    // 0x9bda00: cmp             x4, #0x804
    // 0x9bda04: b.eq            #0x9bda1c
    // 0x9bda08: r8 = ToolbarItemsParentData<RenderBox>
    //     0x9bda08: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x9bda0c: ldr             x8, [x8, #0x528]
    // 0x9bda10: r3 = Null
    //     0x9bda10: add             x3, PP, #0x50, lsl #12  ; [pp+0x506a0] Null
    //     0x9bda14: ldr             x3, [x3, #0x6a0]
    // 0x9bda18: r0 = DefaultTypeTest()
    //     0x9bda18: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bda1c: ldur            x1, [fp, #-0x10]
    // 0x9bda20: LoadField: r0 = r1->field_13
    //     0x9bda20: ldur            w0, [x1, #0x13]
    // 0x9bda24: DecompressPointer r0
    //     0x9bda24: add             x0, x0, HEAP, lsl #32
    // 0x9bda28: mov             x1, x0
    // 0x9bda2c: b               #0x9bd998
    // 0x9bda30: r0 = Null
    //     0x9bda30: mov             x0, NULL
    // 0x9bda34: LeaveFrame
    //     0x9bda34: mov             SP, fp
    //     0x9bda38: ldp             fp, lr, [SP], #0x10
    // 0x9bda3c: ret
    //     0x9bda3c: ret             
    // 0x9bda40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bda40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bda44: b               #0x9bd944
    // 0x9bda48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bda48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bda4c: b               #0x9bd9a8
    // 0x9bda50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bda50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa695e8, size: 0xec
    // 0xa695e8: EnterFrame
    //     0xa695e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa695ec: mov             fp, SP
    // 0xa695f0: AllocStack(0x10)
    //     0xa695f0: sub             SP, SP, #0x10
    // 0xa695f4: CheckStackOverflow
    //     0xa695f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa695f8: cmp             SP, x16
    //     0xa695fc: b.ls            #0xa696c0
    // 0xa69600: ldr             x16, [fp, #0x10]
    // 0xa69604: SaveReg r16
    //     0xa69604: str             x16, [SP, #-8]!
    // 0xa69608: r0 = detach()
    //     0xa69608: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa6960c: add             SP, SP, #8
    // 0xa69610: ldr             x0, [fp, #0x10]
    // 0xa69614: LoadField: r1 = r0->field_67
    //     0xa69614: ldur            w1, [x0, #0x67]
    // 0xa69618: DecompressPointer r1
    //     0xa69618: add             x1, x1, HEAP, lsl #32
    // 0xa6961c: stur            x1, [fp, #-8]
    // 0xa69620: CheckStackOverflow
    //     0xa69620: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69624: cmp             SP, x16
    //     0xa69628: b.ls            #0xa696c8
    // 0xa6962c: cmp             w1, NULL
    // 0xa69630: b.eq            #0xa696b0
    // 0xa69634: r0 = LoadClassIdInstr(r1)
    //     0xa69634: ldur            x0, [x1, #-1]
    //     0xa69638: ubfx            x0, x0, #0xc, #0x14
    // 0xa6963c: SaveReg r1
    //     0xa6963c: str             x1, [SP, #-8]!
    // 0xa69640: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa69640: mov             x17, #0xa3cc
    //     0xa69644: add             lr, x0, x17
    //     0xa69648: ldr             lr, [x21, lr, lsl #3]
    //     0xa6964c: blr             lr
    // 0xa69650: add             SP, SP, #8
    // 0xa69654: ldur            x0, [fp, #-8]
    // 0xa69658: LoadField: r3 = r0->field_17
    //     0xa69658: ldur            w3, [x0, #0x17]
    // 0xa6965c: DecompressPointer r3
    //     0xa6965c: add             x3, x3, HEAP, lsl #32
    // 0xa69660: stur            x3, [fp, #-0x10]
    // 0xa69664: cmp             w3, NULL
    // 0xa69668: b.eq            #0xa696d0
    // 0xa6966c: mov             x0, x3
    // 0xa69670: r2 = Null
    //     0xa69670: mov             x2, NULL
    // 0xa69674: r1 = Null
    //     0xa69674: mov             x1, NULL
    // 0xa69678: r4 = LoadClassIdInstr(r0)
    //     0xa69678: ldur            x4, [x0, #-1]
    //     0xa6967c: ubfx            x4, x4, #0xc, #0x14
    // 0xa69680: cmp             x4, #0x804
    // 0xa69684: b.eq            #0xa6969c
    // 0xa69688: r8 = ToolbarItemsParentData<RenderBox>
    //     0xa69688: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0xa6968c: ldr             x8, [x8, #0x528]
    // 0xa69690: r3 = Null
    //     0xa69690: add             x3, PP, #0x50, lsl #12  ; [pp+0x50680] Null
    //     0xa69694: ldr             x3, [x3, #0x680]
    // 0xa69698: r0 = DefaultTypeTest()
    //     0xa69698: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa6969c: ldur            x1, [fp, #-0x10]
    // 0xa696a0: LoadField: r0 = r1->field_13
    //     0xa696a0: ldur            w0, [x1, #0x13]
    // 0xa696a4: DecompressPointer r0
    //     0xa696a4: add             x0, x0, HEAP, lsl #32
    // 0xa696a8: mov             x1, x0
    // 0xa696ac: b               #0xa6961c
    // 0xa696b0: r0 = Null
    //     0xa696b0: mov             x0, NULL
    // 0xa696b4: LeaveFrame
    //     0xa696b4: mov             SP, fp
    //     0xa696b8: ldp             fp, lr, [SP], #0x10
    // 0xa696bc: ret
    //     0xa696bc: ret             
    // 0xa696c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa696c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa696c4: b               #0xa69600
    // 0xa696c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa696c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa696cc: b               #0xa6962c
    // 0xa696d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa696d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2450, size: 0x80, field offset: 0x70
class _RenderTextSelectionToolbarItemsLayout extends __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x627d3c, size: 0x180
    // 0x627d3c: EnterFrame
    //     0x627d3c: stp             fp, lr, [SP, #-0x10]!
    //     0x627d40: mov             fp, SP
    // 0x627d44: AllocStack(0x20)
    //     0x627d44: sub             SP, SP, #0x20
    // 0x627d48: CheckStackOverflow
    //     0x627d48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627d4c: cmp             SP, x16
    //     0x627d50: b.ls            #0x627ea8
    // 0x627d54: ldr             x0, [fp, #0x20]
    // 0x627d58: LoadField: r1 = r0->field_6b
    //     0x627d58: ldur            w1, [x0, #0x6b]
    // 0x627d5c: DecompressPointer r1
    //     0x627d5c: add             x1, x1, HEAP, lsl #32
    // 0x627d60: mov             x3, x1
    // 0x627d64: stur            x3, [fp, #-0x10]
    // 0x627d68: CheckStackOverflow
    //     0x627d68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627d6c: cmp             SP, x16
    //     0x627d70: b.ls            #0x627eb0
    // 0x627d74: cmp             w3, NULL
    // 0x627d78: b.eq            #0x627e98
    // 0x627d7c: LoadField: r4 = r3->field_17
    //     0x627d7c: ldur            w4, [x3, #0x17]
    // 0x627d80: DecompressPointer r4
    //     0x627d80: add             x4, x4, HEAP, lsl #32
    // 0x627d84: stur            x4, [fp, #-8]
    // 0x627d88: cmp             w4, NULL
    // 0x627d8c: b.eq            #0x627eb8
    // 0x627d90: mov             x0, x4
    // 0x627d94: r2 = Null
    //     0x627d94: mov             x2, NULL
    // 0x627d98: r1 = Null
    //     0x627d98: mov             x1, NULL
    // 0x627d9c: r4 = LoadClassIdInstr(r0)
    //     0x627d9c: ldur            x4, [x0, #-1]
    //     0x627da0: ubfx            x4, x4, #0xc, #0x14
    // 0x627da4: cmp             x4, #0x804
    // 0x627da8: b.eq            #0x627dc0
    // 0x627dac: r8 = ToolbarItemsParentData<RenderBox>
    //     0x627dac: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x627db0: ldr             x8, [x8, #0x528]
    // 0x627db4: r3 = Null
    //     0x627db4: add             x3, PP, #0x50, lsl #12  ; [pp+0x50540] Null
    //     0x627db8: ldr             x3, [x3, #0x540]
    // 0x627dbc: r0 = DefaultTypeTest()
    //     0x627dbc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x627dc0: ldur            x0, [fp, #-8]
    // 0x627dc4: LoadField: r1 = r0->field_17
    //     0x627dc4: ldur            w1, [x0, #0x17]
    // 0x627dc8: DecompressPointer r1
    //     0x627dc8: add             x1, x1, HEAP, lsl #32
    // 0x627dcc: tbz             w1, #4, #0x627de0
    // 0x627dd0: LoadField: r1 = r0->field_f
    //     0x627dd0: ldur            w1, [x0, #0xf]
    // 0x627dd4: DecompressPointer r1
    //     0x627dd4: add             x1, x1, HEAP, lsl #32
    // 0x627dd8: mov             x3, x1
    // 0x627ddc: b               #0x627d64
    // 0x627de0: ldur            x1, [fp, #-0x10]
    // 0x627de4: LoadField: r2 = r0->field_7
    //     0x627de4: ldur            w2, [x0, #7]
    // 0x627de8: DecompressPointer r2
    //     0x627de8: add             x2, x2, HEAP, lsl #32
    // 0x627dec: stur            x2, [fp, #-0x18]
    // 0x627df0: ldr             x16, [fp, #0x10]
    // 0x627df4: stp             x2, x16, [SP, #-0x10]!
    // 0x627df8: r0 = -()
    //     0x627df8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x627dfc: add             SP, SP, #0x10
    // 0x627e00: stur            x0, [fp, #-0x20]
    // 0x627e04: ldur            x16, [fp, #-0x18]
    // 0x627e08: SaveReg r16
    //     0x627e08: str             x16, [SP, #-8]!
    // 0x627e0c: r0 = unary-()
    //     0x627e0c: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x627e10: add             SP, SP, #8
    // 0x627e14: ldr             x16, [fp, #0x18]
    // 0x627e18: stp             x0, x16, [SP, #-0x10]!
    // 0x627e1c: r0 = pushOffset()
    //     0x627e1c: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x627e20: add             SP, SP, #0x10
    // 0x627e24: ldur            x0, [fp, #-0x10]
    // 0x627e28: r1 = LoadClassIdInstr(r0)
    //     0x627e28: ldur            x1, [x0, #-1]
    //     0x627e2c: ubfx            x1, x1, #0xc, #0x14
    // 0x627e30: ldr             x16, [fp, #0x18]
    // 0x627e34: stp             x16, x0, [SP, #-0x10]!
    // 0x627e38: ldur            x16, [fp, #-0x20]
    // 0x627e3c: SaveReg r16
    //     0x627e3c: str             x16, [SP, #-8]!
    // 0x627e40: mov             x0, x1
    // 0x627e44: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x627e44: mov             x17, #0xefa2
    //     0x627e48: add             lr, x0, x17
    //     0x627e4c: ldr             lr, [x21, lr, lsl #3]
    //     0x627e50: blr             lr
    // 0x627e54: add             SP, SP, #0x18
    // 0x627e58: stur            x0, [fp, #-0x10]
    // 0x627e5c: ldr             x16, [fp, #0x18]
    // 0x627e60: SaveReg r16
    //     0x627e60: str             x16, [SP, #-8]!
    // 0x627e64: r0 = popTransform()
    //     0x627e64: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x627e68: add             SP, SP, #8
    // 0x627e6c: ldur            x1, [fp, #-0x10]
    // 0x627e70: tbnz            w1, #4, #0x627e84
    // 0x627e74: r0 = true
    //     0x627e74: add             x0, NULL, #0x20  ; true
    // 0x627e78: LeaveFrame
    //     0x627e78: mov             SP, fp
    //     0x627e7c: ldp             fp, lr, [SP], #0x10
    // 0x627e80: ret
    //     0x627e80: ret             
    // 0x627e84: ldur            x1, [fp, #-8]
    // 0x627e88: LoadField: r2 = r1->field_f
    //     0x627e88: ldur            w2, [x1, #0xf]
    // 0x627e8c: DecompressPointer r2
    //     0x627e8c: add             x2, x2, HEAP, lsl #32
    // 0x627e90: mov             x3, x2
    // 0x627e94: b               #0x627d64
    // 0x627e98: r0 = false
    //     0x627e98: add             x0, NULL, #0x30  ; false
    // 0x627e9c: LeaveFrame
    //     0x627e9c: mov             SP, fp
    //     0x627ea0: ldp             fp, lr, [SP], #0x10
    // 0x627ea4: ret
    //     0x627ea4: ret             
    // 0x627ea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627ea8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627eac: b               #0x627d54
    // 0x627eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627eb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627eb4: b               #0x627d74
    // 0x627eb8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x627eb8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setupParentData(/* No info */) {
    // ** addr: 0x64b92c, size: 0x74
    // 0x64b92c: EnterFrame
    //     0x64b92c: stp             fp, lr, [SP, #-0x10]!
    //     0x64b930: mov             fp, SP
    // 0x64b934: ldr             x0, [fp, #0x10]
    // 0x64b938: LoadField: r1 = r0->field_17
    //     0x64b938: ldur            w1, [x0, #0x17]
    // 0x64b93c: DecompressPointer r1
    //     0x64b93c: add             x1, x1, HEAP, lsl #32
    // 0x64b940: r2 = LoadClassIdInstr(r1)
    //     0x64b940: ldur            x2, [x1, #-1]
    //     0x64b944: ubfx            x2, x2, #0xc, #0x14
    // 0x64b948: lsl             x2, x2, #1
    // 0x64b94c: r17 = 4104
    //     0x64b94c: mov             x17, #0x1008
    // 0x64b950: cmp             w2, w17
    // 0x64b954: b.eq            #0x64b990
    // 0x64b958: r1 = <RenderBox>
    //     0x64b958: ldr             x1, [PP, #0x3b20]  ; [pp+0x3b20] TypeArguments: <RenderBox>
    // 0x64b95c: r0 = ToolbarItemsParentData()
    //     0x64b95c: bl              #0x64b9a0  ; AllocateToolbarItemsParentDataStub -> ToolbarItemsParentData (size=0x1c)
    // 0x64b960: r1 = false
    //     0x64b960: add             x1, NULL, #0x30  ; false
    // 0x64b964: StoreField: r0->field_17 = r1
    //     0x64b964: stur            w1, [x0, #0x17]
    // 0x64b968: r1 = Instance_Offset
    //     0x64b968: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x64b96c: StoreField: r0->field_7 = r1
    //     0x64b96c: stur            w1, [x0, #7]
    // 0x64b970: ldr             x1, [fp, #0x10]
    // 0x64b974: StoreField: r1->field_17 = r0
    //     0x64b974: stur            w0, [x1, #0x17]
    //     0x64b978: ldurb           w16, [x1, #-1]
    //     0x64b97c: ldurb           w17, [x0, #-1]
    //     0x64b980: and             x16, x17, x16, lsr #2
    //     0x64b984: tst             x16, HEAP, lsr #32
    //     0x64b988: b.eq            #0x64b990
    //     0x64b98c: bl              #0xd6826c
    // 0x64b990: r0 = Null
    //     0x64b990: mov             x0, NULL
    // 0x64b994: LeaveFrame
    //     0x64b994: mov             SP, fp
    //     0x64b998: ldp             fp, lr, [SP], #0x10
    // 0x64b99c: ret
    //     0x64b99c: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0x66a340, size: 0x68
    // 0x66a340: EnterFrame
    //     0x66a340: stp             fp, lr, [SP, #-0x10]!
    //     0x66a344: mov             fp, SP
    // 0x66a348: CheckStackOverflow
    //     0x66a348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66a34c: cmp             SP, x16
    //     0x66a350: b.ls            #0x66a3a0
    // 0x66a354: r1 = 2
    //     0x66a354: mov             x1, #2
    // 0x66a358: r0 = AllocateContext()
    //     0x66a358: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66a35c: mov             x1, x0
    // 0x66a360: ldr             x0, [fp, #0x18]
    // 0x66a364: StoreField: r1->field_f = r0
    //     0x66a364: stur            w0, [x1, #0xf]
    // 0x66a368: ldr             x0, [fp, #0x10]
    // 0x66a36c: StoreField: r1->field_13 = r0
    //     0x66a36c: stur            w0, [x1, #0x13]
    // 0x66a370: mov             x2, x1
    // 0x66a374: r1 = Function '<anonymous closure>':.
    //     0x66a374: add             x1, PP, #0x50, lsl #12  ; [pp+0x50550] AnonymousClosure: (0x66a3a8), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::paint (0x66a340)
    //     0x66a378: ldr             x1, [x1, #0x550]
    // 0x66a37c: r0 = AllocateClosure()
    //     0x66a37c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x66a380: ldr             x16, [fp, #0x20]
    // 0x66a384: stp             x0, x16, [SP, #-0x10]!
    // 0x66a388: r0 = visitChildren()
    //     0x66a388: bl              #0x6bfa38  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0x66a38c: add             SP, SP, #0x10
    // 0x66a390: r0 = Null
    //     0x66a390: mov             x0, NULL
    // 0x66a394: LeaveFrame
    //     0x66a394: mov             SP, fp
    //     0x66a398: ldp             fp, lr, [SP], #0x10
    // 0x66a39c: ret
    //     0x66a39c: ret             
    // 0x66a3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66a3a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66a3a4: b               #0x66a354
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x66a3a8, size: 0x124
    // 0x66a3a8: EnterFrame
    //     0x66a3a8: stp             fp, lr, [SP, #-0x10]!
    //     0x66a3ac: mov             fp, SP
    // 0x66a3b0: AllocStack(0x18)
    //     0x66a3b0: sub             SP, SP, #0x18
    // 0x66a3b4: SetupParameters()
    //     0x66a3b4: ldr             x0, [fp, #0x18]
    //     0x66a3b8: ldur            w3, [x0, #0x17]
    //     0x66a3bc: add             x3, x3, HEAP, lsl #32
    //     0x66a3c0: stur            x3, [fp, #-8]
    // 0x66a3c4: CheckStackOverflow
    //     0x66a3c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66a3c8: cmp             SP, x16
    //     0x66a3cc: b.ls            #0x66a4c0
    // 0x66a3d0: ldr             x0, [fp, #0x10]
    // 0x66a3d4: r2 = Null
    //     0x66a3d4: mov             x2, NULL
    // 0x66a3d8: r1 = Null
    //     0x66a3d8: mov             x1, NULL
    // 0x66a3dc: r4 = LoadClassIdInstr(r0)
    //     0x66a3dc: ldur            x4, [x0, #-1]
    //     0x66a3e0: ubfx            x4, x4, #0xc, #0x14
    // 0x66a3e4: sub             x4, x4, #0x965
    // 0x66a3e8: cmp             x4, #0x8b
    // 0x66a3ec: b.ls            #0x66a404
    // 0x66a3f0: r8 = RenderBox
    //     0x66a3f0: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x66a3f4: ldr             x8, [x8, #0xfa0]
    // 0x66a3f8: r3 = Null
    //     0x66a3f8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50558] Null
    //     0x66a3fc: ldr             x3, [x3, #0x558]
    // 0x66a400: r0 = RenderBox()
    //     0x66a400: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x66a404: ldr             x3, [fp, #0x10]
    // 0x66a408: LoadField: r4 = r3->field_17
    //     0x66a408: ldur            w4, [x3, #0x17]
    // 0x66a40c: DecompressPointer r4
    //     0x66a40c: add             x4, x4, HEAP, lsl #32
    // 0x66a410: stur            x4, [fp, #-0x10]
    // 0x66a414: cmp             w4, NULL
    // 0x66a418: b.eq            #0x66a4c8
    // 0x66a41c: mov             x0, x4
    // 0x66a420: r2 = Null
    //     0x66a420: mov             x2, NULL
    // 0x66a424: r1 = Null
    //     0x66a424: mov             x1, NULL
    // 0x66a428: r4 = LoadClassIdInstr(r0)
    //     0x66a428: ldur            x4, [x0, #-1]
    //     0x66a42c: ubfx            x4, x4, #0xc, #0x14
    // 0x66a430: cmp             x4, #0x804
    // 0x66a434: b.eq            #0x66a44c
    // 0x66a438: r8 = ToolbarItemsParentData<RenderBox>
    //     0x66a438: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x66a43c: ldr             x8, [x8, #0x528]
    // 0x66a440: r3 = Null
    //     0x66a440: add             x3, PP, #0x50, lsl #12  ; [pp+0x50568] Null
    //     0x66a444: ldr             x3, [x3, #0x568]
    // 0x66a448: r0 = DefaultTypeTest()
    //     0x66a448: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66a44c: ldur            x0, [fp, #-0x10]
    // 0x66a450: LoadField: r1 = r0->field_17
    //     0x66a450: ldur            w1, [x0, #0x17]
    // 0x66a454: DecompressPointer r1
    //     0x66a454: add             x1, x1, HEAP, lsl #32
    // 0x66a458: tbz             w1, #4, #0x66a46c
    // 0x66a45c: r0 = Null
    //     0x66a45c: mov             x0, NULL
    // 0x66a460: LeaveFrame
    //     0x66a460: mov             SP, fp
    //     0x66a464: ldp             fp, lr, [SP], #0x10
    // 0x66a468: ret
    //     0x66a468: ret             
    // 0x66a46c: ldur            x1, [fp, #-8]
    // 0x66a470: LoadField: r2 = r1->field_f
    //     0x66a470: ldur            w2, [x1, #0xf]
    // 0x66a474: DecompressPointer r2
    //     0x66a474: add             x2, x2, HEAP, lsl #32
    // 0x66a478: stur            x2, [fp, #-0x18]
    // 0x66a47c: LoadField: r3 = r0->field_7
    //     0x66a47c: ldur            w3, [x0, #7]
    // 0x66a480: DecompressPointer r3
    //     0x66a480: add             x3, x3, HEAP, lsl #32
    // 0x66a484: LoadField: r0 = r1->field_13
    //     0x66a484: ldur            w0, [x1, #0x13]
    // 0x66a488: DecompressPointer r0
    //     0x66a488: add             x0, x0, HEAP, lsl #32
    // 0x66a48c: stp             x0, x3, [SP, #-0x10]!
    // 0x66a490: r0 = +()
    //     0x66a490: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66a494: add             SP, SP, #0x10
    // 0x66a498: ldur            x16, [fp, #-0x18]
    // 0x66a49c: ldr             lr, [fp, #0x10]
    // 0x66a4a0: stp             lr, x16, [SP, #-0x10]!
    // 0x66a4a4: SaveReg r0
    //     0x66a4a4: str             x0, [SP, #-8]!
    // 0x66a4a8: r0 = paintChild()
    //     0x66a4a8: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66a4ac: add             SP, SP, #0x18
    // 0x66a4b0: r0 = Null
    //     0x66a4b0: mov             x0, NULL
    // 0x66a4b4: LeaveFrame
    //     0x66a4b4: mov             SP, fp
    //     0x66a4b8: ldp             fp, lr, [SP], #0x10
    // 0x66a4bc: ret
    //     0x66a4bc: ret             
    // 0x66a4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66a4c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66a4c4: b               #0x66a3d0
    // 0x66a4c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66a4c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x676044, size: 0x60
    // 0x676044: EnterFrame
    //     0x676044: stp             fp, lr, [SP, #-0x10]!
    //     0x676048: mov             fp, SP
    // 0x67604c: CheckStackOverflow
    //     0x67604c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x676050: cmp             SP, x16
    //     0x676054: b.ls            #0x67609c
    // 0x676058: r1 = 1
    //     0x676058: mov             x1, #1
    // 0x67605c: r0 = AllocateContext()
    //     0x67605c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x676060: mov             x1, x0
    // 0x676064: ldr             x0, [fp, #0x10]
    // 0x676068: StoreField: r1->field_f = r0
    //     0x676068: stur            w0, [x1, #0xf]
    // 0x67606c: mov             x2, x1
    // 0x676070: r1 = Function '<anonymous closure>':.
    //     0x676070: add             x1, PP, #0x50, lsl #12  ; [pp+0x50510] AnonymousClosure: (0x6760a4), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::visitChildrenForSemantics (0x676044)
    //     0x676074: ldr             x1, [x1, #0x510]
    // 0x676078: r0 = AllocateClosure()
    //     0x676078: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x67607c: ldr             x16, [fp, #0x18]
    // 0x676080: stp             x0, x16, [SP, #-0x10]!
    // 0x676084: r0 = visitChildren()
    //     0x676084: bl              #0x6bfa38  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0x676088: add             SP, SP, #0x10
    // 0x67608c: r0 = Null
    //     0x67608c: mov             x0, NULL
    // 0x676090: LeaveFrame
    //     0x676090: mov             SP, fp
    //     0x676094: ldp             fp, lr, [SP], #0x10
    // 0x676098: ret
    //     0x676098: ret             
    // 0x67609c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x67609c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6760a0: b               #0x676058
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x6760a4, size: 0x104
    // 0x6760a4: EnterFrame
    //     0x6760a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6760a8: mov             fp, SP
    // 0x6760ac: AllocStack(0x10)
    //     0x6760ac: sub             SP, SP, #0x10
    // 0x6760b0: SetupParameters()
    //     0x6760b0: ldr             x0, [fp, #0x18]
    //     0x6760b4: ldur            w3, [x0, #0x17]
    //     0x6760b8: add             x3, x3, HEAP, lsl #32
    //     0x6760bc: stur            x3, [fp, #-8]
    // 0x6760c0: CheckStackOverflow
    //     0x6760c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6760c4: cmp             SP, x16
    //     0x6760c8: b.ls            #0x676198
    // 0x6760cc: ldr             x0, [fp, #0x10]
    // 0x6760d0: r2 = Null
    //     0x6760d0: mov             x2, NULL
    // 0x6760d4: r1 = Null
    //     0x6760d4: mov             x1, NULL
    // 0x6760d8: r4 = LoadClassIdInstr(r0)
    //     0x6760d8: ldur            x4, [x0, #-1]
    //     0x6760dc: ubfx            x4, x4, #0xc, #0x14
    // 0x6760e0: sub             x4, x4, #0x965
    // 0x6760e4: cmp             x4, #0x8b
    // 0x6760e8: b.ls            #0x676100
    // 0x6760ec: r8 = RenderBox
    //     0x6760ec: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6760f0: ldr             x8, [x8, #0xfa0]
    // 0x6760f4: r3 = Null
    //     0x6760f4: add             x3, PP, #0x50, lsl #12  ; [pp+0x50518] Null
    //     0x6760f8: ldr             x3, [x3, #0x518]
    // 0x6760fc: r0 = RenderBox()
    //     0x6760fc: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x676100: ldr             x3, [fp, #0x10]
    // 0x676104: LoadField: r4 = r3->field_17
    //     0x676104: ldur            w4, [x3, #0x17]
    // 0x676108: DecompressPointer r4
    //     0x676108: add             x4, x4, HEAP, lsl #32
    // 0x67610c: stur            x4, [fp, #-0x10]
    // 0x676110: cmp             w4, NULL
    // 0x676114: b.eq            #0x6761a0
    // 0x676118: mov             x0, x4
    // 0x67611c: r2 = Null
    //     0x67611c: mov             x2, NULL
    // 0x676120: r1 = Null
    //     0x676120: mov             x1, NULL
    // 0x676124: r4 = LoadClassIdInstr(r0)
    //     0x676124: ldur            x4, [x0, #-1]
    //     0x676128: ubfx            x4, x4, #0xc, #0x14
    // 0x67612c: cmp             x4, #0x804
    // 0x676130: b.eq            #0x676148
    // 0x676134: r8 = ToolbarItemsParentData<RenderBox>
    //     0x676134: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x676138: ldr             x8, [x8, #0x528]
    // 0x67613c: r3 = Null
    //     0x67613c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50530] Null
    //     0x676140: ldr             x3, [x3, #0x530]
    // 0x676144: r0 = DefaultTypeTest()
    //     0x676144: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x676148: ldur            x0, [fp, #-0x10]
    // 0x67614c: LoadField: r1 = r0->field_17
    //     0x67614c: ldur            w1, [x0, #0x17]
    // 0x676150: DecompressPointer r1
    //     0x676150: add             x1, x1, HEAP, lsl #32
    // 0x676154: tbnz            w1, #4, #0x676188
    // 0x676158: ldur            x0, [fp, #-8]
    // 0x67615c: LoadField: r1 = r0->field_f
    //     0x67615c: ldur            w1, [x0, #0xf]
    // 0x676160: DecompressPointer r1
    //     0x676160: add             x1, x1, HEAP, lsl #32
    // 0x676164: cmp             w1, NULL
    // 0x676168: b.eq            #0x6761a4
    // 0x67616c: ldr             x16, [fp, #0x10]
    // 0x676170: stp             x16, x1, [SP, #-0x10]!
    // 0x676174: mov             x0, x1
    // 0x676178: ClosureCall
    //     0x676178: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x67617c: ldur            x2, [x0, #0x1f]
    //     0x676180: blr             x2
    // 0x676184: add             SP, SP, #0x10
    // 0x676188: r0 = Null
    //     0x676188: mov             x0, NULL
    // 0x67618c: LeaveFrame
    //     0x67618c: mov             SP, fp
    //     0x676190: ldp             fp, lr, [SP], #0x10
    // 0x676194: ret
    //     0x676194: ret             
    // 0x676198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x676198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67619c: b               #0x6760cc
    // 0x6761a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6761a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6761a4: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6761a4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x695940, size: 0x114
    // 0x695940: EnterFrame
    //     0x695940: stp             fp, lr, [SP, #-0x10]!
    //     0x695944: mov             fp, SP
    // 0x695948: AllocStack(0x8)
    //     0x695948: sub             SP, SP, #8
    // 0x69594c: r0 = -1
    //     0x69594c: mov             x0, #-1
    // 0x695950: CheckStackOverflow
    //     0x695950: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x695954: cmp             SP, x16
    //     0x695958: b.ls            #0x695a4c
    // 0x69595c: ldr             x3, [fp, #0x10]
    // 0x695960: StoreField: r3->field_6f = r0
    //     0x695960: stur            x0, [x3, #0x6f]
    // 0x695964: LoadField: r0 = r3->field_67
    //     0x695964: ldur            w0, [x3, #0x67]
    // 0x695968: DecompressPointer r0
    //     0x695968: add             x0, x0, HEAP, lsl #32
    // 0x69596c: cmp             w0, NULL
    // 0x695970: b.ne            #0x6959fc
    // 0x695974: LoadField: r4 = r3->field_27
    //     0x695974: ldur            w4, [x3, #0x27]
    // 0x695978: DecompressPointer r4
    //     0x695978: add             x4, x4, HEAP, lsl #32
    // 0x69597c: stur            x4, [fp, #-8]
    // 0x695980: cmp             w4, NULL
    // 0x695984: b.eq            #0x695a2c
    // 0x695988: mov             x0, x4
    // 0x69598c: r2 = Null
    //     0x69598c: mov             x2, NULL
    // 0x695990: r1 = Null
    //     0x695990: mov             x1, NULL
    // 0x695994: r4 = LoadClassIdInstr(r0)
    //     0x695994: ldur            x4, [x0, #-1]
    //     0x695998: ubfx            x4, x4, #0xc, #0x14
    // 0x69599c: sub             x4, x4, #0x80d
    // 0x6959a0: cmp             x4, #1
    // 0x6959a4: b.ls            #0x6959bc
    // 0x6959a8: r8 = BoxConstraints
    //     0x6959a8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6959ac: ldr             x8, [x8, #0x1d0]
    // 0x6959b0: r3 = Null
    //     0x6959b0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50578] Null
    //     0x6959b4: ldr             x3, [x3, #0x578]
    // 0x6959b8: r0 = BoxConstraints()
    //     0x6959b8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6959bc: ldur            x16, [fp, #-8]
    // 0x6959c0: SaveReg r16
    //     0x6959c0: str             x16, [SP, #-8]!
    // 0x6959c4: r0 = smallest()
    //     0x6959c4: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x6959c8: add             SP, SP, #8
    // 0x6959cc: ldr             x1, [fp, #0x10]
    // 0x6959d0: StoreField: r1->field_57 = r0
    //     0x6959d0: stur            w0, [x1, #0x57]
    //     0x6959d4: ldurb           w16, [x1, #-1]
    //     0x6959d8: ldurb           w17, [x0, #-1]
    //     0x6959dc: and             x16, x17, x16, lsr #2
    //     0x6959e0: tst             x16, HEAP, lsr #32
    //     0x6959e4: b.eq            #0x6959ec
    //     0x6959e8: bl              #0xd6826c
    // 0x6959ec: r0 = Null
    //     0x6959ec: mov             x0, NULL
    // 0x6959f0: LeaveFrame
    //     0x6959f0: mov             SP, fp
    //     0x6959f4: ldp             fp, lr, [SP], #0x10
    // 0x6959f8: ret
    //     0x6959f8: ret             
    // 0x6959fc: mov             x1, x3
    // 0x695a00: SaveReg r1
    //     0x695a00: str             x1, [SP, #-8]!
    // 0x695a04: r0 = _layoutChildren()
    //     0x695a04: bl              #0x6962f8  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_layoutChildren
    // 0x695a08: add             SP, SP, #8
    // 0x695a0c: ldr             x16, [fp, #0x10]
    // 0x695a10: SaveReg r16
    //     0x695a10: str             x16, [SP, #-8]!
    // 0x695a14: r0 = _placeChildren()
    //     0x695a14: bl              #0x695a54  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildren
    // 0x695a18: add             SP, SP, #8
    // 0x695a1c: r0 = Null
    //     0x695a1c: mov             x0, NULL
    // 0x695a20: LeaveFrame
    //     0x695a20: mov             SP, fp
    //     0x695a24: ldp             fp, lr, [SP], #0x10
    // 0x695a28: ret
    //     0x695a28: ret             
    // 0x695a2c: r0 = StateError()
    //     0x695a2c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x695a30: mov             x1, x0
    // 0x695a34: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x695a34: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x695a38: ldr             x0, [x0, #0x1e8]
    // 0x695a3c: StoreField: r1->field_b = r0
    //     0x695a3c: stur            w0, [x1, #0xb]
    // 0x695a40: mov             x0, x1
    // 0x695a44: r0 = Throw()
    //     0x695a44: bl              #0xd67e38  ; ThrowStub
    // 0x695a48: brk             #0
    // 0x695a4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x695a4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x695a50: b               #0x69595c
  }
  _ _placeChildren(/* No info */) {
    // ** addr: 0x695a54, size: 0x3a0
    // 0x695a54: EnterFrame
    //     0x695a54: stp             fp, lr, [SP, #-0x10]!
    //     0x695a58: mov             fp, SP
    // 0x695a5c: AllocStack(0x38)
    //     0x695a5c: sub             SP, SP, #0x38
    // 0x695a60: CheckStackOverflow
    //     0x695a60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x695a64: cmp             SP, x16
    //     0x695a68: b.ls            #0x695db0
    // 0x695a6c: r1 = 6
    //     0x695a6c: mov             x1, #6
    // 0x695a70: r0 = AllocateContext()
    //     0x695a70: bl              #0xd68aa4  ; AllocateContextStub
    // 0x695a74: mov             x3, x0
    // 0x695a78: ldr             x0, [fp, #0x10]
    // 0x695a7c: stur            x3, [fp, #-0x10]
    // 0x695a80: StoreField: r3->field_f = r0
    //     0x695a80: stur            w0, [x3, #0xf]
    // 0x695a84: r1 = -2
    //     0x695a84: mov             x1, #-2
    // 0x695a88: StoreField: r3->field_13 = r1
    //     0x695a88: stur            w1, [x3, #0x13]
    // 0x695a8c: r1 = Instance_Size
    //     0x695a8c: ldr             x1, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x695a90: StoreField: r3->field_17 = r1
    //     0x695a90: stur            w1, [x3, #0x17]
    // 0x695a94: r1 = 0.000000
    //     0x695a94: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x695a98: StoreField: r3->field_1b = r1
    //     0x695a98: stur            w1, [x3, #0x1b]
    // 0x695a9c: LoadField: r4 = r0->field_67
    //     0x695a9c: ldur            w4, [x0, #0x67]
    // 0x695aa0: DecompressPointer r4
    //     0x695aa0: add             x4, x4, HEAP, lsl #32
    // 0x695aa4: stur            x4, [fp, #-8]
    // 0x695aa8: cmp             w4, NULL
    // 0x695aac: b.eq            #0x695db8
    // 0x695ab0: StoreField: r3->field_1f = r4
    //     0x695ab0: stur            w4, [x3, #0x1f]
    // 0x695ab4: LoadField: r1 = r0->field_7b
    //     0x695ab4: ldur            w1, [x0, #0x7b]
    // 0x695ab8: DecompressPointer r1
    //     0x695ab8: add             x1, x1, HEAP, lsl #32
    // 0x695abc: tbnz            w1, #4, #0x695ae4
    // 0x695ac0: LoadField: r1 = r0->field_77
    //     0x695ac0: ldur            w1, [x0, #0x77]
    // 0x695ac4: DecompressPointer r1
    //     0x695ac4: add             x1, x1, HEAP, lsl #32
    // 0x695ac8: tbz             w1, #4, #0x695ae4
    // 0x695acc: LoadField: r1 = r4->field_57
    //     0x695acc: ldur            w1, [x4, #0x57]
    // 0x695ad0: DecompressPointer r1
    //     0x695ad0: add             x1, x1, HEAP, lsl #32
    // 0x695ad4: cmp             w1, NULL
    // 0x695ad8: b.eq            #0x695dbc
    // 0x695adc: LoadField: d0 = r1->field_f
    //     0x695adc: ldur            d0, [x1, #0xf]
    // 0x695ae0: b               #0x695ae8
    // 0x695ae4: d0 = 0.000000
    //     0x695ae4: eor             v0.16b, v0.16b, v0.16b
    // 0x695ae8: r1 = inline_Allocate_Double()
    //     0x695ae8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x695aec: add             x1, x1, #0x10
    //     0x695af0: cmp             x2, x1
    //     0x695af4: b.ls            #0x695dc0
    //     0x695af8: str             x1, [THR, #0x60]  ; THR::top
    //     0x695afc: sub             x1, x1, #0xf
    //     0x695b00: mov             x2, #0xd108
    //     0x695b04: movk            x2, #3, lsl #16
    //     0x695b08: stur            x2, [x1, #-1]
    // 0x695b0c: StoreField: r1->field_7 = d0
    //     0x695b0c: stur            d0, [x1, #7]
    // 0x695b10: StoreField: r3->field_23 = r1
    //     0x695b10: stur            w1, [x3, #0x23]
    // 0x695b14: mov             x2, x3
    // 0x695b18: r1 = Function '<anonymous closure>':.
    //     0x695b18: add             x1, PP, #0x50, lsl #12  ; [pp+0x50588] AnonymousClosure: (0x695e68), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_placeChildren (0x695a54)
    //     0x695b1c: ldr             x1, [x1, #0x588]
    // 0x695b20: r0 = AllocateClosure()
    //     0x695b20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x695b24: ldr             x16, [fp, #0x10]
    // 0x695b28: stp             x0, x16, [SP, #-0x10]!
    // 0x695b2c: r0 = visitChildren()
    //     0x695b2c: bl              #0x6bfa38  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0x695b30: add             SP, SP, #0x10
    // 0x695b34: ldur            x3, [fp, #-8]
    // 0x695b38: LoadField: r4 = r3->field_17
    //     0x695b38: ldur            w4, [x3, #0x17]
    // 0x695b3c: DecompressPointer r4
    //     0x695b3c: add             x4, x4, HEAP, lsl #32
    // 0x695b40: stur            x4, [fp, #-0x18]
    // 0x695b44: cmp             w4, NULL
    // 0x695b48: b.eq            #0x695de4
    // 0x695b4c: mov             x0, x4
    // 0x695b50: r2 = Null
    //     0x695b50: mov             x2, NULL
    // 0x695b54: r1 = Null
    //     0x695b54: mov             x1, NULL
    // 0x695b58: r4 = LoadClassIdInstr(r0)
    //     0x695b58: ldur            x4, [x0, #-1]
    //     0x695b5c: ubfx            x4, x4, #0xc, #0x14
    // 0x695b60: cmp             x4, #0x804
    // 0x695b64: b.eq            #0x695b7c
    // 0x695b68: r8 = ToolbarItemsParentData<RenderBox>
    //     0x695b68: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x695b6c: ldr             x8, [x8, #0x528]
    // 0x695b70: r3 = Null
    //     0x695b70: add             x3, PP, #0x50, lsl #12  ; [pp+0x50590] Null
    //     0x695b74: ldr             x3, [x3, #0x590]
    // 0x695b78: r0 = DefaultTypeTest()
    //     0x695b78: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x695b7c: ldr             x0, [fp, #0x10]
    // 0x695b80: LoadField: r1 = r0->field_67
    //     0x695b80: ldur            w1, [x0, #0x67]
    // 0x695b84: DecompressPointer r1
    //     0x695b84: add             x1, x1, HEAP, lsl #32
    // 0x695b88: cmp             w1, NULL
    // 0x695b8c: b.eq            #0x695de8
    // 0x695b90: stp             x1, x0, [SP, #-0x10]!
    // 0x695b94: SaveReg rZR
    //     0x695b94: str             xzr, [SP, #-8]!
    // 0x695b98: r0 = _shouldPaintChild()
    //     0x695b98: bl              #0x695df4  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_shouldPaintChild
    // 0x695b9c: add             SP, SP, #0x18
    // 0x695ba0: tbnz            w0, #4, #0x695d68
    // 0x695ba4: ldr             x0, [fp, #0x10]
    // 0x695ba8: ldur            x1, [fp, #-0x18]
    // 0x695bac: r2 = true
    //     0x695bac: add             x2, NULL, #0x20  ; true
    // 0x695bb0: StoreField: r1->field_17 = r2
    //     0x695bb0: stur            w2, [x1, #0x17]
    // 0x695bb4: LoadField: r2 = r0->field_7b
    //     0x695bb4: ldur            w2, [x0, #0x7b]
    // 0x695bb8: DecompressPointer r2
    //     0x695bb8: add             x2, x2, HEAP, lsl #32
    // 0x695bbc: tbnz            w2, #4, #0x695ca8
    // 0x695bc0: LoadField: r2 = r0->field_77
    //     0x695bc0: ldur            w2, [x0, #0x77]
    // 0x695bc4: DecompressPointer r2
    //     0x695bc4: add             x2, x2, HEAP, lsl #32
    // 0x695bc8: stur            x2, [fp, #-0x28]
    // 0x695bcc: tbnz            w2, #4, #0x695bfc
    // 0x695bd0: ldur            x3, [fp, #-0x10]
    // 0x695bd4: LoadField: r4 = r3->field_23
    //     0x695bd4: ldur            w4, [x3, #0x23]
    // 0x695bd8: DecompressPointer r4
    //     0x695bd8: add             x4, x4, HEAP, lsl #32
    // 0x695bdc: stur            x4, [fp, #-0x20]
    // 0x695be0: r0 = Offset()
    //     0x695be0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x695be4: d0 = 0.000000
    //     0x695be4: eor             v0.16b, v0.16b, v0.16b
    // 0x695be8: StoreField: r0->field_7 = d0
    //     0x695be8: stur            d0, [x0, #7]
    // 0x695bec: ldur            x1, [fp, #-0x20]
    // 0x695bf0: LoadField: d0 = r1->field_7
    //     0x695bf0: ldur            d0, [x1, #7]
    // 0x695bf4: StoreField: r0->field_f = d0
    //     0x695bf4: stur            d0, [x0, #0xf]
    // 0x695bf8: b               #0x695c00
    // 0x695bfc: r0 = Instance_Offset
    //     0x695bfc: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x695c00: ldur            x3, [fp, #-0x10]
    // 0x695c04: ldur            x1, [fp, #-0x18]
    // 0x695c08: ldur            x2, [fp, #-0x28]
    // 0x695c0c: StoreField: r1->field_7 = r0
    //     0x695c0c: stur            w0, [x1, #7]
    //     0x695c10: ldurb           w16, [x1, #-1]
    //     0x695c14: ldurb           w17, [x0, #-1]
    //     0x695c18: and             x16, x17, x16, lsr #2
    //     0x695c1c: tst             x16, HEAP, lsr #32
    //     0x695c20: b.eq            #0x695c28
    //     0x695c24: bl              #0xd6826c
    // 0x695c28: LoadField: r0 = r3->field_17
    //     0x695c28: ldur            w0, [x3, #0x17]
    // 0x695c2c: DecompressPointer r0
    //     0x695c2c: add             x0, x0, HEAP, lsl #32
    // 0x695c30: LoadField: d0 = r0->field_7
    //     0x695c30: ldur            d0, [x0, #7]
    // 0x695c34: stur            d0, [fp, #-0x38]
    // 0x695c38: tbnz            w2, #4, #0x695c64
    // 0x695c3c: ldur            x2, [fp, #-8]
    // 0x695c40: LoadField: d1 = r0->field_f
    //     0x695c40: ldur            d1, [x0, #0xf]
    // 0x695c44: LoadField: r0 = r2->field_57
    //     0x695c44: ldur            w0, [x2, #0x57]
    // 0x695c48: DecompressPointer r0
    //     0x695c48: add             x0, x0, HEAP, lsl #32
    // 0x695c4c: cmp             w0, NULL
    // 0x695c50: b.eq            #0x695dec
    // 0x695c54: LoadField: d2 = r0->field_f
    //     0x695c54: ldur            d2, [x0, #0xf]
    // 0x695c58: fadd            d3, d1, d2
    // 0x695c5c: mov             v1.16b, v3.16b
    // 0x695c60: b               #0x695c68
    // 0x695c64: LoadField: d1 = r0->field_f
    //     0x695c64: ldur            d1, [x0, #0xf]
    // 0x695c68: stur            d1, [fp, #-0x30]
    // 0x695c6c: r0 = Size()
    //     0x695c6c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x695c70: ldur            d0, [fp, #-0x38]
    // 0x695c74: StoreField: r0->field_7 = d0
    //     0x695c74: stur            d0, [x0, #7]
    // 0x695c78: ldur            d0, [fp, #-0x30]
    // 0x695c7c: StoreField: r0->field_f = d0
    //     0x695c7c: stur            d0, [x0, #0xf]
    // 0x695c80: ldur            x3, [fp, #-0x10]
    // 0x695c84: StoreField: r3->field_17 = r0
    //     0x695c84: stur            w0, [x3, #0x17]
    //     0x695c88: ldurb           w16, [x3, #-1]
    //     0x695c8c: ldurb           w17, [x0, #-1]
    //     0x695c90: and             x16, x17, x16, lsr #2
    //     0x695c94: tst             x16, HEAP, lsr #32
    //     0x695c98: b.eq            #0x695ca0
    //     0x695c9c: bl              #0xd682ac
    // 0x695ca0: mov             x2, x3
    // 0x695ca4: b               #0x695d78
    // 0x695ca8: ldur            x3, [fp, #-0x10]
    // 0x695cac: ldur            x2, [fp, #-8]
    // 0x695cb0: d0 = 0.000000
    //     0x695cb0: eor             v0.16b, v0.16b, v0.16b
    // 0x695cb4: LoadField: r0 = r3->field_1b
    //     0x695cb4: ldur            w0, [x3, #0x1b]
    // 0x695cb8: DecompressPointer r0
    //     0x695cb8: add             x0, x0, HEAP, lsl #32
    // 0x695cbc: LoadField: d1 = r0->field_7
    //     0x695cbc: ldur            d1, [x0, #7]
    // 0x695cc0: stur            d1, [fp, #-0x30]
    // 0x695cc4: r0 = Offset()
    //     0x695cc4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x695cc8: ldur            d0, [fp, #-0x30]
    // 0x695ccc: StoreField: r0->field_7 = d0
    //     0x695ccc: stur            d0, [x0, #7]
    // 0x695cd0: d0 = 0.000000
    //     0x695cd0: eor             v0.16b, v0.16b, v0.16b
    // 0x695cd4: StoreField: r0->field_f = d0
    //     0x695cd4: stur            d0, [x0, #0xf]
    // 0x695cd8: ldur            x1, [fp, #-0x18]
    // 0x695cdc: StoreField: r1->field_7 = r0
    //     0x695cdc: stur            w0, [x1, #7]
    //     0x695ce0: ldurb           w16, [x1, #-1]
    //     0x695ce4: ldurb           w17, [x0, #-1]
    //     0x695ce8: and             x16, x17, x16, lsr #2
    //     0x695cec: tst             x16, HEAP, lsr #32
    //     0x695cf0: b.eq            #0x695cf8
    //     0x695cf4: bl              #0xd6826c
    // 0x695cf8: ldur            x0, [fp, #-0x10]
    // 0x695cfc: LoadField: r1 = r0->field_17
    //     0x695cfc: ldur            w1, [x0, #0x17]
    // 0x695d00: DecompressPointer r1
    //     0x695d00: add             x1, x1, HEAP, lsl #32
    // 0x695d04: LoadField: d0 = r1->field_7
    //     0x695d04: ldur            d0, [x1, #7]
    // 0x695d08: ldur            x2, [fp, #-8]
    // 0x695d0c: LoadField: r3 = r2->field_57
    //     0x695d0c: ldur            w3, [x2, #0x57]
    // 0x695d10: DecompressPointer r3
    //     0x695d10: add             x3, x3, HEAP, lsl #32
    // 0x695d14: cmp             w3, NULL
    // 0x695d18: b.eq            #0x695df0
    // 0x695d1c: LoadField: d1 = r3->field_7
    //     0x695d1c: ldur            d1, [x3, #7]
    // 0x695d20: fadd            d2, d0, d1
    // 0x695d24: stur            d2, [fp, #-0x38]
    // 0x695d28: LoadField: d0 = r1->field_f
    //     0x695d28: ldur            d0, [x1, #0xf]
    // 0x695d2c: stur            d0, [fp, #-0x30]
    // 0x695d30: r0 = Size()
    //     0x695d30: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x695d34: ldur            d0, [fp, #-0x38]
    // 0x695d38: StoreField: r0->field_7 = d0
    //     0x695d38: stur            d0, [x0, #7]
    // 0x695d3c: ldur            d0, [fp, #-0x30]
    // 0x695d40: StoreField: r0->field_f = d0
    //     0x695d40: stur            d0, [x0, #0xf]
    // 0x695d44: ldur            x2, [fp, #-0x10]
    // 0x695d48: StoreField: r2->field_17 = r0
    //     0x695d48: stur            w0, [x2, #0x17]
    //     0x695d4c: ldurb           w16, [x2, #-1]
    //     0x695d50: ldurb           w17, [x0, #-1]
    //     0x695d54: and             x16, x17, x16, lsr #2
    //     0x695d58: tst             x16, HEAP, lsr #32
    //     0x695d5c: b.eq            #0x695d64
    //     0x695d60: bl              #0xd6828c
    // 0x695d64: b               #0x695d78
    // 0x695d68: ldur            x2, [fp, #-0x10]
    // 0x695d6c: ldur            x1, [fp, #-0x18]
    // 0x695d70: r3 = false
    //     0x695d70: add             x3, NULL, #0x30  ; false
    // 0x695d74: StoreField: r1->field_17 = r3
    //     0x695d74: stur            w3, [x1, #0x17]
    // 0x695d78: ldr             x1, [fp, #0x10]
    // 0x695d7c: LoadField: r0 = r2->field_17
    //     0x695d7c: ldur            w0, [x2, #0x17]
    // 0x695d80: DecompressPointer r0
    //     0x695d80: add             x0, x0, HEAP, lsl #32
    // 0x695d84: StoreField: r1->field_57 = r0
    //     0x695d84: stur            w0, [x1, #0x57]
    //     0x695d88: ldurb           w16, [x1, #-1]
    //     0x695d8c: ldurb           w17, [x0, #-1]
    //     0x695d90: and             x16, x17, x16, lsr #2
    //     0x695d94: tst             x16, HEAP, lsr #32
    //     0x695d98: b.eq            #0x695da0
    //     0x695d9c: bl              #0xd6826c
    // 0x695da0: r0 = Null
    //     0x695da0: mov             x0, NULL
    // 0x695da4: LeaveFrame
    //     0x695da4: mov             SP, fp
    //     0x695da8: ldp             fp, lr, [SP], #0x10
    // 0x695dac: ret
    //     0x695dac: ret             
    // 0x695db0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x695db0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x695db4: b               #0x695a6c
    // 0x695db8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695db8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695dbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695dc0: SaveReg d0
    //     0x695dc0: str             q0, [SP, #-0x10]!
    // 0x695dc4: stp             x3, x4, [SP, #-0x10]!
    // 0x695dc8: SaveReg r0
    //     0x695dc8: str             x0, [SP, #-8]!
    // 0x695dcc: r0 = AllocateDouble()
    //     0x695dcc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x695dd0: mov             x1, x0
    // 0x695dd4: RestoreReg r0
    //     0x695dd4: ldr             x0, [SP], #8
    // 0x695dd8: ldp             x3, x4, [SP], #0x10
    // 0x695ddc: RestoreReg d0
    //     0x695ddc: ldr             q0, [SP], #0x10
    // 0x695de0: b               #0x695b0c
    // 0x695de4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695de4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695de8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695de8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695dec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x695dec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x695df0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x695df0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _shouldPaintChild(/* No info */) {
    // ** addr: 0x695df4, size: 0x74
    // 0x695df4: ldr             x1, [SP, #0x10]
    // 0x695df8: LoadField: r2 = r1->field_67
    //     0x695df8: ldur            w2, [x1, #0x67]
    // 0x695dfc: DecompressPointer r2
    //     0x695dfc: add             x2, x2, HEAP, lsl #32
    // 0x695e00: ldr             x3, [SP, #8]
    // 0x695e04: cmp             w3, w2
    // 0x695e08: b.ne            #0x695e24
    // 0x695e0c: LoadField: r2 = r1->field_6f
    //     0x695e0c: ldur            x2, [x1, #0x6f]
    // 0x695e10: cmn             x2, #1
    // 0x695e14: r16 = true
    //     0x695e14: add             x16, NULL, #0x20  ; true
    // 0x695e18: r17 = false
    //     0x695e18: add             x17, NULL, #0x30  ; false
    // 0x695e1c: csel            x0, x16, x17, ne
    // 0x695e20: ret
    //     0x695e20: ret             
    // 0x695e24: LoadField: r2 = r1->field_6f
    //     0x695e24: ldur            x2, [x1, #0x6f]
    // 0x695e28: cmn             x2, #1
    // 0x695e2c: b.ne            #0x695e38
    // 0x695e30: r0 = true
    //     0x695e30: add             x0, NULL, #0x20  ; true
    // 0x695e34: ret
    //     0x695e34: ret             
    // 0x695e38: ldr             x3, [SP]
    // 0x695e3c: cmp             x3, x2
    // 0x695e40: r16 = true
    //     0x695e40: add             x16, NULL, #0x20  ; true
    // 0x695e44: r17 = false
    //     0x695e44: add             x17, NULL, #0x30  ; false
    // 0x695e48: csel            x4, x16, x17, gt
    // 0x695e4c: LoadField: r2 = r1->field_7b
    //     0x695e4c: ldur            w2, [x1, #0x7b]
    // 0x695e50: DecompressPointer r2
    //     0x695e50: add             x2, x2, HEAP, lsl #32
    // 0x695e54: cmp             w4, w2
    // 0x695e58: r16 = true
    //     0x695e58: add             x16, NULL, #0x20  ; true
    // 0x695e5c: r17 = false
    //     0x695e5c: add             x17, NULL, #0x30  ; false
    // 0x695e60: csel            x0, x16, x17, eq
    // 0x695e64: ret
    //     0x695e64: ret             
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x695e68, size: 0x490
    // 0x695e68: EnterFrame
    //     0x695e68: stp             fp, lr, [SP, #-0x10]!
    //     0x695e6c: mov             fp, SP
    // 0x695e70: AllocStack(0x30)
    //     0x695e70: sub             SP, SP, #0x30
    // 0x695e74: SetupParameters()
    //     0x695e74: ldr             x0, [fp, #0x18]
    //     0x695e78: ldur            w3, [x0, #0x17]
    //     0x695e7c: add             x3, x3, HEAP, lsl #32
    //     0x695e80: stur            x3, [fp, #-0x10]
    // 0x695e84: CheckStackOverflow
    //     0x695e84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x695e88: cmp             SP, x16
    //     0x695e8c: b.ls            #0x6962a8
    // 0x695e90: LoadField: r0 = r3->field_13
    //     0x695e90: ldur            w0, [x3, #0x13]
    // 0x695e94: DecompressPointer r0
    //     0x695e94: add             x0, x0, HEAP, lsl #32
    // 0x695e98: cmp             w0, NULL
    // 0x695e9c: b.eq            #0x6962b0
    // 0x695ea0: r1 = LoadInt32Instr(r0)
    //     0x695ea0: sbfx            x1, x0, #1, #0x1f
    //     0x695ea4: tbz             w0, #0, #0x695eac
    //     0x695ea8: ldur            x1, [x0, #7]
    // 0x695eac: add             x4, x1, #1
    // 0x695eb0: stur            x4, [fp, #-8]
    // 0x695eb4: r0 = BoxInt64Instr(r4)
    //     0x695eb4: sbfiz           x0, x4, #1, #0x1f
    //     0x695eb8: cmp             x4, x0, asr #1
    //     0x695ebc: b.eq            #0x695ec8
    //     0x695ec0: bl              #0xd69bb8
    //     0x695ec4: stur            x4, [x0, #7]
    // 0x695ec8: StoreField: r3->field_13 = r0
    //     0x695ec8: stur            w0, [x3, #0x13]
    //     0x695ecc: tbz             w0, #0, #0x695ee8
    //     0x695ed0: ldurb           w16, [x3, #-1]
    //     0x695ed4: ldurb           w17, [x0, #-1]
    //     0x695ed8: and             x16, x17, x16, lsr #2
    //     0x695edc: tst             x16, HEAP, lsr #32
    //     0x695ee0: b.eq            #0x695ee8
    //     0x695ee4: bl              #0xd682ac
    // 0x695ee8: ldr             x0, [fp, #0x10]
    // 0x695eec: r2 = Null
    //     0x695eec: mov             x2, NULL
    // 0x695ef0: r1 = Null
    //     0x695ef0: mov             x1, NULL
    // 0x695ef4: r4 = LoadClassIdInstr(r0)
    //     0x695ef4: ldur            x4, [x0, #-1]
    //     0x695ef8: ubfx            x4, x4, #0xc, #0x14
    // 0x695efc: sub             x4, x4, #0x965
    // 0x695f00: cmp             x4, #0x8b
    // 0x695f04: b.ls            #0x695f1c
    // 0x695f08: r8 = RenderBox
    //     0x695f08: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x695f0c: ldr             x8, [x8, #0xfa0]
    // 0x695f10: r3 = Null
    //     0x695f10: add             x3, PP, #0x50, lsl #12  ; [pp+0x505a0] Null
    //     0x695f14: ldr             x3, [x3, #0x5a0]
    // 0x695f18: r0 = RenderBox()
    //     0x695f18: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x695f1c: ldr             x3, [fp, #0x10]
    // 0x695f20: LoadField: r4 = r3->field_17
    //     0x695f20: ldur            w4, [x3, #0x17]
    // 0x695f24: DecompressPointer r4
    //     0x695f24: add             x4, x4, HEAP, lsl #32
    // 0x695f28: stur            x4, [fp, #-0x18]
    // 0x695f2c: cmp             w4, NULL
    // 0x695f30: b.eq            #0x6962b4
    // 0x695f34: mov             x0, x4
    // 0x695f38: r2 = Null
    //     0x695f38: mov             x2, NULL
    // 0x695f3c: r1 = Null
    //     0x695f3c: mov             x1, NULL
    // 0x695f40: r4 = LoadClassIdInstr(r0)
    //     0x695f40: ldur            x4, [x0, #-1]
    //     0x695f44: ubfx            x4, x4, #0xc, #0x14
    // 0x695f48: cmp             x4, #0x804
    // 0x695f4c: b.eq            #0x695f64
    // 0x695f50: r8 = ToolbarItemsParentData<RenderBox>
    //     0x695f50: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x695f54: ldr             x8, [x8, #0x528]
    // 0x695f58: r3 = Null
    //     0x695f58: add             x3, PP, #0x50, lsl #12  ; [pp+0x505b0] Null
    //     0x695f5c: ldr             x3, [x3, #0x5b0]
    // 0x695f60: r0 = DefaultTypeTest()
    //     0x695f60: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x695f64: ldur            x0, [fp, #-0x10]
    // 0x695f68: LoadField: r1 = r0->field_1f
    //     0x695f68: ldur            w1, [x0, #0x1f]
    // 0x695f6c: DecompressPointer r1
    //     0x695f6c: add             x1, x1, HEAP, lsl #32
    // 0x695f70: ldr             x2, [fp, #0x10]
    // 0x695f74: cmp             w2, w1
    // 0x695f78: b.ne            #0x695f8c
    // 0x695f7c: r0 = Null
    //     0x695f7c: mov             x0, NULL
    // 0x695f80: LeaveFrame
    //     0x695f80: mov             SP, fp
    //     0x695f84: ldp             fp, lr, [SP], #0x10
    // 0x695f88: ret
    //     0x695f88: ret             
    // 0x695f8c: ldur            x1, [fp, #-8]
    // 0x695f90: LoadField: r3 = r0->field_f
    //     0x695f90: ldur            w3, [x0, #0xf]
    // 0x695f94: DecompressPointer r3
    //     0x695f94: add             x3, x3, HEAP, lsl #32
    // 0x695f98: stp             x2, x3, [SP, #-0x10]!
    // 0x695f9c: SaveReg r1
    //     0x695f9c: str             x1, [SP, #-8]!
    // 0x695fa0: r0 = _shouldPaintChild()
    //     0x695fa0: bl              #0x695df4  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_shouldPaintChild
    // 0x695fa4: add             SP, SP, #0x18
    // 0x695fa8: tbz             w0, #4, #0x695fc8
    // 0x695fac: ldur            x0, [fp, #-0x18]
    // 0x695fb0: r1 = false
    //     0x695fb0: add             x1, NULL, #0x30  ; false
    // 0x695fb4: StoreField: r0->field_17 = r1
    //     0x695fb4: stur            w1, [x0, #0x17]
    // 0x695fb8: r0 = Null
    //     0x695fb8: mov             x0, NULL
    // 0x695fbc: LeaveFrame
    //     0x695fbc: mov             SP, fp
    //     0x695fc0: ldp             fp, lr, [SP], #0x10
    // 0x695fc4: ret
    //     0x695fc4: ret             
    // 0x695fc8: ldur            x1, [fp, #-0x10]
    // 0x695fcc: ldur            x0, [fp, #-0x18]
    // 0x695fd0: r2 = true
    //     0x695fd0: add             x2, NULL, #0x20  ; true
    // 0x695fd4: StoreField: r0->field_17 = r2
    //     0x695fd4: stur            w2, [x0, #0x17]
    // 0x695fd8: LoadField: r2 = r1->field_f
    //     0x695fd8: ldur            w2, [x1, #0xf]
    // 0x695fdc: DecompressPointer r2
    //     0x695fdc: add             x2, x2, HEAP, lsl #32
    // 0x695fe0: LoadField: r3 = r2->field_7b
    //     0x695fe0: ldur            w3, [x2, #0x7b]
    // 0x695fe4: DecompressPointer r3
    //     0x695fe4: add             x3, x3, HEAP, lsl #32
    // 0x695fe8: tbz             w3, #4, #0x69613c
    // 0x695fec: ldr             x2, [fp, #0x10]
    // 0x695ff0: LoadField: r3 = r1->field_1b
    //     0x695ff0: ldur            w3, [x1, #0x1b]
    // 0x695ff4: DecompressPointer r3
    //     0x695ff4: add             x3, x3, HEAP, lsl #32
    // 0x695ff8: stur            x3, [fp, #-0x20]
    // 0x695ffc: LoadField: d0 = r3->field_7
    //     0x695ffc: ldur            d0, [x3, #7]
    // 0x696000: stur            d0, [fp, #-0x28]
    // 0x696004: r0 = Offset()
    //     0x696004: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x696008: ldur            d0, [fp, #-0x28]
    // 0x69600c: StoreField: r0->field_7 = d0
    //     0x69600c: stur            d0, [x0, #7]
    // 0x696010: d1 = 0.000000
    //     0x696010: eor             v1.16b, v1.16b, v1.16b
    // 0x696014: StoreField: r0->field_f = d1
    //     0x696014: stur            d1, [x0, #0xf]
    // 0x696018: ldur            x1, [fp, #-0x18]
    // 0x69601c: StoreField: r1->field_7 = r0
    //     0x69601c: stur            w0, [x1, #7]
    //     0x696020: ldurb           w16, [x1, #-1]
    //     0x696024: ldurb           w17, [x0, #-1]
    //     0x696028: and             x16, x17, x16, lsr #2
    //     0x69602c: tst             x16, HEAP, lsr #32
    //     0x696030: b.eq            #0x696038
    //     0x696034: bl              #0xd6826c
    // 0x696038: ldr             x0, [fp, #0x10]
    // 0x69603c: LoadField: r1 = r0->field_57
    //     0x69603c: ldur            w1, [x0, #0x57]
    // 0x696040: DecompressPointer r1
    //     0x696040: add             x1, x1, HEAP, lsl #32
    // 0x696044: cmp             w1, NULL
    // 0x696048: b.eq            #0x6962b8
    // 0x69604c: LoadField: d2 = r1->field_7
    //     0x69604c: ldur            d2, [x1, #7]
    // 0x696050: ldur            x0, [fp, #-0x20]
    // 0x696054: cmp             w0, NULL
    // 0x696058: b.eq            #0x6962bc
    // 0x69605c: fadd            d3, d0, d2
    // 0x696060: stur            d3, [fp, #-0x30]
    // 0x696064: r0 = inline_Allocate_Double()
    //     0x696064: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x696068: add             x0, x0, #0x10
    //     0x69606c: cmp             x2, x0
    //     0x696070: b.ls            #0x6962c0
    //     0x696074: str             x0, [THR, #0x60]  ; THR::top
    //     0x696078: sub             x0, x0, #0xf
    //     0x69607c: mov             x2, #0xd108
    //     0x696080: movk            x2, #3, lsl #16
    //     0x696084: stur            x2, [x0, #-1]
    // 0x696088: StoreField: r0->field_7 = d3
    //     0x696088: stur            d3, [x0, #7]
    // 0x69608c: ldur            x2, [fp, #-0x10]
    // 0x696090: StoreField: r2->field_1b = r0
    //     0x696090: stur            w0, [x2, #0x1b]
    //     0x696094: ldurb           w16, [x2, #-1]
    //     0x696098: ldurb           w17, [x0, #-1]
    //     0x69609c: and             x16, x17, x16, lsr #2
    //     0x6960a0: tst             x16, HEAP, lsr #32
    //     0x6960a4: b.eq            #0x6960ac
    //     0x6960a8: bl              #0xd6828c
    // 0x6960ac: LoadField: d0 = r1->field_f
    //     0x6960ac: ldur            d0, [x1, #0xf]
    // 0x6960b0: LoadField: r0 = r2->field_17
    //     0x6960b0: ldur            w0, [x2, #0x17]
    // 0x6960b4: DecompressPointer r0
    //     0x6960b4: add             x0, x0, HEAP, lsl #32
    // 0x6960b8: LoadField: d2 = r0->field_f
    //     0x6960b8: ldur            d2, [x0, #0xf]
    // 0x6960bc: fcmp            d0, d2
    // 0x6960c0: b.vs            #0x6960c8
    // 0x6960c4: b.gt            #0x696100
    // 0x6960c8: fcmp            d0, d2
    // 0x6960cc: b.vs            #0x6960dc
    // 0x6960d0: b.ge            #0x6960dc
    // 0x6960d4: mov             v0.16b, v2.16b
    // 0x6960d8: b               #0x696100
    // 0x6960dc: fcmp            d0, d1
    // 0x6960e0: b.vs            #0x6960f4
    // 0x6960e4: b.ne            #0x6960f4
    // 0x6960e8: fadd            d1, d0, d2
    // 0x6960ec: mov             v0.16b, v1.16b
    // 0x6960f0: b               #0x696100
    // 0x6960f4: fcmp            d2, d2
    // 0x6960f8: b.vc            #0x696100
    // 0x6960fc: mov             v0.16b, v2.16b
    // 0x696100: stur            d0, [fp, #-0x28]
    // 0x696104: r0 = Size()
    //     0x696104: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x696108: ldur            d0, [fp, #-0x30]
    // 0x69610c: StoreField: r0->field_7 = d0
    //     0x69610c: stur            d0, [x0, #7]
    // 0x696110: ldur            d0, [fp, #-0x28]
    // 0x696114: StoreField: r0->field_f = d0
    //     0x696114: stur            d0, [x0, #0xf]
    // 0x696118: ldur            x2, [fp, #-0x10]
    // 0x69611c: StoreField: r2->field_17 = r0
    //     0x69611c: stur            w0, [x2, #0x17]
    //     0x696120: ldurb           w16, [x2, #-1]
    //     0x696124: ldurb           w17, [x0, #-1]
    //     0x696128: and             x16, x17, x16, lsr #2
    //     0x69612c: tst             x16, HEAP, lsr #32
    //     0x696130: b.eq            #0x696138
    //     0x696134: bl              #0xd6828c
    // 0x696138: b               #0x696298
    // 0x69613c: mov             x2, x1
    // 0x696140: mov             x1, x0
    // 0x696144: ldr             x0, [fp, #0x10]
    // 0x696148: d1 = 0.000000
    //     0x696148: eor             v1.16b, v1.16b, v1.16b
    // 0x69614c: LoadField: r3 = r2->field_23
    //     0x69614c: ldur            w3, [x2, #0x23]
    // 0x696150: DecompressPointer r3
    //     0x696150: add             x3, x3, HEAP, lsl #32
    // 0x696154: stur            x3, [fp, #-0x20]
    // 0x696158: r0 = Offset()
    //     0x696158: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x69615c: d0 = 0.000000
    //     0x69615c: eor             v0.16b, v0.16b, v0.16b
    // 0x696160: StoreField: r0->field_7 = d0
    //     0x696160: stur            d0, [x0, #7]
    // 0x696164: ldur            x1, [fp, #-0x20]
    // 0x696168: LoadField: d1 = r1->field_7
    //     0x696168: ldur            d1, [x1, #7]
    // 0x69616c: StoreField: r0->field_f = d1
    //     0x69616c: stur            d1, [x0, #0xf]
    // 0x696170: ldur            x2, [fp, #-0x18]
    // 0x696174: StoreField: r2->field_7 = r0
    //     0x696174: stur            w0, [x2, #7]
    //     0x696178: ldurb           w16, [x2, #-1]
    //     0x69617c: ldurb           w17, [x0, #-1]
    //     0x696180: and             x16, x17, x16, lsr #2
    //     0x696184: tst             x16, HEAP, lsr #32
    //     0x696188: b.eq            #0x696190
    //     0x69618c: bl              #0xd6828c
    // 0x696190: ldr             x0, [fp, #0x10]
    // 0x696194: LoadField: r2 = r0->field_57
    //     0x696194: ldur            w2, [x0, #0x57]
    // 0x696198: DecompressPointer r2
    //     0x696198: add             x2, x2, HEAP, lsl #32
    // 0x69619c: cmp             w2, NULL
    // 0x6961a0: b.eq            #0x6962d8
    // 0x6961a4: LoadField: d2 = r2->field_f
    //     0x6961a4: ldur            d2, [x2, #0xf]
    // 0x6961a8: cmp             w1, NULL
    // 0x6961ac: b.eq            #0x6962dc
    // 0x6961b0: fadd            d3, d1, d2
    // 0x6961b4: stur            d3, [fp, #-0x30]
    // 0x6961b8: r0 = inline_Allocate_Double()
    //     0x6961b8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6961bc: add             x0, x0, #0x10
    //     0x6961c0: cmp             x1, x0
    //     0x6961c4: b.ls            #0x6962e0
    //     0x6961c8: str             x0, [THR, #0x60]  ; THR::top
    //     0x6961cc: sub             x0, x0, #0xf
    //     0x6961d0: mov             x1, #0xd108
    //     0x6961d4: movk            x1, #3, lsl #16
    //     0x6961d8: stur            x1, [x0, #-1]
    // 0x6961dc: StoreField: r0->field_7 = d3
    //     0x6961dc: stur            d3, [x0, #7]
    // 0x6961e0: ldur            x1, [fp, #-0x10]
    // 0x6961e4: StoreField: r1->field_23 = r0
    //     0x6961e4: stur            w0, [x1, #0x23]
    //     0x6961e8: ldurb           w16, [x1, #-1]
    //     0x6961ec: ldurb           w17, [x0, #-1]
    //     0x6961f0: and             x16, x17, x16, lsr #2
    //     0x6961f4: tst             x16, HEAP, lsr #32
    //     0x6961f8: b.eq            #0x696200
    //     0x6961fc: bl              #0xd6826c
    // 0x696200: LoadField: d1 = r2->field_7
    //     0x696200: ldur            d1, [x2, #7]
    // 0x696204: LoadField: r0 = r1->field_17
    //     0x696204: ldur            w0, [x1, #0x17]
    // 0x696208: DecompressPointer r0
    //     0x696208: add             x0, x0, HEAP, lsl #32
    // 0x69620c: LoadField: d2 = r0->field_7
    //     0x69620c: ldur            d2, [x0, #7]
    // 0x696210: fcmp            d1, d2
    // 0x696214: b.vs            #0x696224
    // 0x696218: b.le            #0x696224
    // 0x69621c: mov             v0.16b, v1.16b
    // 0x696220: b               #0x696260
    // 0x696224: fcmp            d1, d2
    // 0x696228: b.vs            #0x696238
    // 0x69622c: b.ge            #0x696238
    // 0x696230: mov             v0.16b, v2.16b
    // 0x696234: b               #0x696260
    // 0x696238: fcmp            d1, d0
    // 0x69623c: b.vs            #0x69624c
    // 0x696240: b.ne            #0x69624c
    // 0x696244: fadd            d0, d1, d2
    // 0x696248: b               #0x696260
    // 0x69624c: fcmp            d2, d2
    // 0x696250: b.vc            #0x69625c
    // 0x696254: mov             v0.16b, v2.16b
    // 0x696258: b               #0x696260
    // 0x69625c: mov             v0.16b, v1.16b
    // 0x696260: stur            d0, [fp, #-0x28]
    // 0x696264: r0 = Size()
    //     0x696264: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x696268: ldur            d0, [fp, #-0x28]
    // 0x69626c: StoreField: r0->field_7 = d0
    //     0x69626c: stur            d0, [x0, #7]
    // 0x696270: ldur            d0, [fp, #-0x30]
    // 0x696274: StoreField: r0->field_f = d0
    //     0x696274: stur            d0, [x0, #0xf]
    // 0x696278: ldur            x1, [fp, #-0x10]
    // 0x69627c: StoreField: r1->field_17 = r0
    //     0x69627c: stur            w0, [x1, #0x17]
    //     0x696280: ldurb           w16, [x1, #-1]
    //     0x696284: ldurb           w17, [x0, #-1]
    //     0x696288: and             x16, x17, x16, lsr #2
    //     0x69628c: tst             x16, HEAP, lsr #32
    //     0x696290: b.eq            #0x696298
    //     0x696294: bl              #0xd6826c
    // 0x696298: r0 = Null
    //     0x696298: mov             x0, NULL
    // 0x69629c: LeaveFrame
    //     0x69629c: mov             SP, fp
    //     0x6962a0: ldp             fp, lr, [SP], #0x10
    // 0x6962a4: ret
    //     0x6962a4: ret             
    // 0x6962a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6962a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6962ac: b               #0x695e90
    // 0x6962b0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6962b0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x6962b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6962b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6962b8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6962b8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6962bc: r0 = NullErrorSharedWithFPURegs()
    //     0x6962bc: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x6962c0: stp             q1, q3, [SP, #-0x20]!
    // 0x6962c4: SaveReg r1
    //     0x6962c4: str             x1, [SP, #-8]!
    // 0x6962c8: r0 = AllocateDouble()
    //     0x6962c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6962cc: RestoreReg r1
    //     0x6962cc: ldr             x1, [SP], #8
    // 0x6962d0: ldp             q1, q3, [SP], #0x20
    // 0x6962d4: b               #0x696088
    // 0x6962d8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6962d8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6962dc: r0 = NullErrorSharedWithFPURegs()
    //     0x6962dc: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x6962e0: stp             q0, q3, [SP, #-0x20]!
    // 0x6962e4: SaveReg r2
    //     0x6962e4: str             x2, [SP, #-8]!
    // 0x6962e8: r0 = AllocateDouble()
    //     0x6962e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6962ec: RestoreReg r2
    //     0x6962ec: ldr             x2, [SP], #8
    // 0x6962f0: ldp             q0, q3, [SP], #0x20
    // 0x6962f4: b               #0x6961dc
  }
  _ _layoutChildren(/* No info */) {
    // ** addr: 0x6962f8, size: 0x230
    // 0x6962f8: EnterFrame
    //     0x6962f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6962fc: mov             fp, SP
    // 0x696300: AllocStack(0x18)
    //     0x696300: sub             SP, SP, #0x18
    // 0x696304: CheckStackOverflow
    //     0x696304: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x696308: cmp             SP, x16
    //     0x69630c: b.ls            #0x696514
    // 0x696310: r1 = 4
    //     0x696310: mov             x1, #4
    // 0x696314: r0 = AllocateContext()
    //     0x696314: bl              #0xd68aa4  ; AllocateContextStub
    // 0x696318: mov             x4, x0
    // 0x69631c: ldr             x3, [fp, #0x10]
    // 0x696320: stur            x4, [fp, #-0x10]
    // 0x696324: StoreField: r4->field_f = r3
    //     0x696324: stur            w3, [x4, #0xf]
    // 0x696328: LoadField: r0 = r3->field_7b
    //     0x696328: ldur            w0, [x3, #0x7b]
    // 0x69632c: DecompressPointer r0
    //     0x69632c: add             x0, x0, HEAP, lsl #32
    // 0x696330: tbnz            w0, #4, #0x696384
    // 0x696334: LoadField: r5 = r3->field_27
    //     0x696334: ldur            w5, [x3, #0x27]
    // 0x696338: DecompressPointer r5
    //     0x696338: add             x5, x5, HEAP, lsl #32
    // 0x69633c: stur            x5, [fp, #-8]
    // 0x696340: cmp             w5, NULL
    // 0x696344: b.eq            #0x6964d4
    // 0x696348: mov             x0, x5
    // 0x69634c: r2 = Null
    //     0x69634c: mov             x2, NULL
    // 0x696350: r1 = Null
    //     0x696350: mov             x1, NULL
    // 0x696354: r4 = LoadClassIdInstr(r0)
    //     0x696354: ldur            x4, [x0, #-1]
    //     0x696358: ubfx            x4, x4, #0xc, #0x14
    // 0x69635c: sub             x4, x4, #0x80d
    // 0x696360: cmp             x4, #1
    // 0x696364: b.ls            #0x69637c
    // 0x696368: r8 = BoxConstraints
    //     0x696368: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69636c: ldr             x8, [x8, #0x1d0]
    // 0x696370: r3 = Null
    //     0x696370: add             x3, PP, #0x50, lsl #12  ; [pp+0x505c0] Null
    //     0x696374: ldr             x3, [x3, #0x5c0]
    // 0x696378: r0 = BoxConstraints()
    //     0x696378: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69637c: ldur            x4, [fp, #-8]
    // 0x696380: b               #0x696408
    // 0x696384: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x696384: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x696388: ldr             x0, [x0, #0x1e8]
    // 0x69638c: LoadField: r4 = r3->field_27
    //     0x69638c: ldur            w4, [x3, #0x27]
    // 0x696390: DecompressPointer r4
    //     0x696390: add             x4, x4, HEAP, lsl #32
    // 0x696394: stur            x4, [fp, #-8]
    // 0x696398: cmp             w4, NULL
    // 0x69639c: b.eq            #0x6964f4
    // 0x6963a0: mov             x0, x4
    // 0x6963a4: r2 = Null
    //     0x6963a4: mov             x2, NULL
    // 0x6963a8: r1 = Null
    //     0x6963a8: mov             x1, NULL
    // 0x6963ac: r4 = LoadClassIdInstr(r0)
    //     0x6963ac: ldur            x4, [x0, #-1]
    //     0x6963b0: ubfx            x4, x4, #0xc, #0x14
    // 0x6963b4: sub             x4, x4, #0x80d
    // 0x6963b8: cmp             x4, #1
    // 0x6963bc: b.ls            #0x6963d4
    // 0x6963c0: r8 = BoxConstraints
    //     0x6963c0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6963c4: ldr             x8, [x8, #0x1d0]
    // 0x6963c8: r3 = Null
    //     0x6963c8: add             x3, PP, #0x50, lsl #12  ; [pp+0x505d0] Null
    //     0x6963cc: ldr             x3, [x3, #0x5d0]
    // 0x6963d0: r0 = BoxConstraints()
    //     0x6963d0: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6963d4: ldur            x0, [fp, #-8]
    // 0x6963d8: LoadField: d0 = r0->field_f
    //     0x6963d8: ldur            d0, [x0, #0xf]
    // 0x6963dc: stur            d0, [fp, #-0x18]
    // 0x6963e0: r0 = BoxConstraints()
    //     0x6963e0: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6963e4: d0 = 0.000000
    //     0x6963e4: eor             v0.16b, v0.16b, v0.16b
    // 0x6963e8: StoreField: r0->field_7 = d0
    //     0x6963e8: stur            d0, [x0, #7]
    // 0x6963ec: ldur            d1, [fp, #-0x18]
    // 0x6963f0: StoreField: r0->field_f = d1
    //     0x6963f0: stur            d1, [x0, #0xf]
    // 0x6963f4: StoreField: r0->field_17 = d0
    //     0x6963f4: stur            d0, [x0, #0x17]
    // 0x6963f8: d0 = 44.000000
    //     0x6963f8: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dc30] IMM: double(44) from 0x4046000000000000
    //     0x6963fc: ldr             d0, [x17, #0xc30]
    // 0x696400: StoreField: r0->field_1f = d0
    //     0x696400: stur            d0, [x0, #0x1f]
    // 0x696404: mov             x4, x0
    // 0x696408: ldr             x0, [fp, #0x10]
    // 0x69640c: ldur            x3, [fp, #-0x10]
    // 0x696410: r2 = 0.000000
    //     0x696410: ldr             x2, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x696414: r1 = -2
    //     0x696414: mov             x1, #-2
    // 0x696418: stur            x4, [fp, #-8]
    // 0x69641c: StoreField: r3->field_13 = r4
    //     0x69641c: stur            w4, [x3, #0x13]
    // 0x696420: StoreField: r3->field_17 = r1
    //     0x696420: stur            w1, [x3, #0x17]
    // 0x696424: StoreField: r3->field_1b = r2
    //     0x696424: stur            w2, [x3, #0x1b]
    // 0x696428: mov             x2, x3
    // 0x69642c: r1 = Function '<anonymous closure>':.
    //     0x69642c: add             x1, PP, #0x50, lsl #12  ; [pp+0x505e0] AnonymousClosure: (0x696528), in [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::_layoutChildren (0x6962f8)
    //     0x696430: ldr             x1, [x1, #0x5e0]
    // 0x696434: r0 = AllocateClosure()
    //     0x696434: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x696438: ldr             x16, [fp, #0x10]
    // 0x69643c: stp             x0, x16, [SP, #-0x10]!
    // 0x696440: r0 = visitChildren()
    //     0x696440: bl              #0x6bfa38  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0x696444: add             SP, SP, #0x10
    // 0x696448: ldr             x1, [fp, #0x10]
    // 0x69644c: LoadField: r2 = r1->field_67
    //     0x69644c: ldur            w2, [x1, #0x67]
    // 0x696450: DecompressPointer r2
    //     0x696450: add             x2, x2, HEAP, lsl #32
    // 0x696454: cmp             w2, NULL
    // 0x696458: b.eq            #0x69651c
    // 0x69645c: LoadField: r3 = r1->field_6f
    //     0x69645c: ldur            x3, [x1, #0x6f]
    // 0x696460: cmn             x3, #1
    // 0x696464: b.eq            #0x6964c4
    // 0x696468: LoadField: r4 = r1->field_5f
    //     0x696468: ldur            x4, [x1, #0x5f]
    // 0x69646c: sub             x5, x4, #2
    // 0x696470: cmp             x3, x5
    // 0x696474: b.ne            #0x6964c4
    // 0x696478: ldur            x3, [fp, #-0x10]
    // 0x69647c: ldur            x4, [fp, #-8]
    // 0x696480: LoadField: r5 = r3->field_1b
    //     0x696480: ldur            w5, [x3, #0x1b]
    // 0x696484: DecompressPointer r5
    //     0x696484: add             x5, x5, HEAP, lsl #32
    // 0x696488: LoadField: r3 = r2->field_57
    //     0x696488: ldur            w3, [x2, #0x57]
    // 0x69648c: DecompressPointer r3
    //     0x69648c: add             x3, x3, HEAP, lsl #32
    // 0x696490: cmp             w3, NULL
    // 0x696494: b.eq            #0x696520
    // 0x696498: LoadField: d0 = r3->field_7
    //     0x696498: ldur            d0, [x3, #7]
    // 0x69649c: cmp             w5, NULL
    // 0x6964a0: b.eq            #0x696524
    // 0x6964a4: LoadField: d1 = r5->field_7
    //     0x6964a4: ldur            d1, [x5, #7]
    // 0x6964a8: fsub            d2, d1, d0
    // 0x6964ac: LoadField: d0 = r4->field_f
    //     0x6964ac: ldur            d0, [x4, #0xf]
    // 0x6964b0: fcmp            d2, d0
    // 0x6964b4: b.vs            #0x6964c4
    // 0x6964b8: b.gt            #0x6964c4
    // 0x6964bc: r2 = -1
    //     0x6964bc: mov             x2, #-1
    // 0x6964c0: StoreField: r1->field_6f = r2
    //     0x6964c0: stur            x2, [x1, #0x6f]
    // 0x6964c4: r0 = Null
    //     0x6964c4: mov             x0, NULL
    // 0x6964c8: LeaveFrame
    //     0x6964c8: mov             SP, fp
    //     0x6964cc: ldp             fp, lr, [SP], #0x10
    // 0x6964d0: ret
    //     0x6964d0: ret             
    // 0x6964d4: r0 = StateError()
    //     0x6964d4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6964d8: mov             x1, x0
    // 0x6964dc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6964dc: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6964e0: ldr             x0, [x0, #0x1e8]
    // 0x6964e4: StoreField: r1->field_b = r0
    //     0x6964e4: stur            w0, [x1, #0xb]
    // 0x6964e8: mov             x0, x1
    // 0x6964ec: r0 = Throw()
    //     0x6964ec: bl              #0xd67e38  ; ThrowStub
    // 0x6964f0: brk             #0
    // 0x6964f4: r0 = StateError()
    //     0x6964f4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6964f8: mov             x1, x0
    // 0x6964fc: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6964fc: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x696500: ldr             x0, [x0, #0x1e8]
    // 0x696504: StoreField: r1->field_b = r0
    //     0x696504: stur            w0, [x1, #0xb]
    // 0x696508: mov             x0, x1
    // 0x69650c: r0 = Throw()
    //     0x69650c: bl              #0xd67e38  ; ThrowStub
    // 0x696510: brk             #0
    // 0x696514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x696514: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x696518: b               #0x696310
    // 0x69651c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69651c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x696520: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x696520: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x696524: r0 = NullErrorSharedWithFPURegs()
    //     0x696524: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x696528, size: 0x23c
    // 0x696528: EnterFrame
    //     0x696528: stp             fp, lr, [SP, #-0x10]!
    //     0x69652c: mov             fp, SP
    // 0x696530: AllocStack(0x10)
    //     0x696530: sub             SP, SP, #0x10
    // 0x696534: SetupParameters()
    //     0x696534: ldr             x0, [fp, #0x18]
    //     0x696538: ldur            w3, [x0, #0x17]
    //     0x69653c: add             x3, x3, HEAP, lsl #32
    //     0x696540: stur            x3, [fp, #-8]
    // 0x696544: CheckStackOverflow
    //     0x696544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x696548: cmp             SP, x16
    //     0x69654c: b.ls            #0x696734
    // 0x696550: LoadField: r0 = r3->field_17
    //     0x696550: ldur            w0, [x3, #0x17]
    // 0x696554: DecompressPointer r0
    //     0x696554: add             x0, x0, HEAP, lsl #32
    // 0x696558: cmp             w0, NULL
    // 0x69655c: b.eq            #0x69673c
    // 0x696560: r1 = LoadInt32Instr(r0)
    //     0x696560: sbfx            x1, x0, #1, #0x1f
    //     0x696564: tbz             w0, #0, #0x69656c
    //     0x696568: ldur            x1, [x0, #7]
    // 0x69656c: add             x2, x1, #1
    // 0x696570: r0 = BoxInt64Instr(r2)
    //     0x696570: sbfiz           x0, x2, #1, #0x1f
    //     0x696574: cmp             x2, x0, asr #1
    //     0x696578: b.eq            #0x696584
    //     0x69657c: bl              #0xd69bb8
    //     0x696580: stur            x2, [x0, #7]
    // 0x696584: StoreField: r3->field_17 = r0
    //     0x696584: stur            w0, [x3, #0x17]
    //     0x696588: tbz             w0, #0, #0x6965a4
    //     0x69658c: ldurb           w16, [x3, #-1]
    //     0x696590: ldurb           w17, [x0, #-1]
    //     0x696594: and             x16, x17, x16, lsr #2
    //     0x696598: tst             x16, HEAP, lsr #32
    //     0x69659c: b.eq            #0x6965a4
    //     0x6965a0: bl              #0xd682ac
    // 0x6965a4: LoadField: r0 = r3->field_f
    //     0x6965a4: ldur            w0, [x3, #0xf]
    // 0x6965a8: DecompressPointer r0
    //     0x6965a8: add             x0, x0, HEAP, lsl #32
    // 0x6965ac: LoadField: r1 = r0->field_6f
    //     0x6965ac: ldur            x1, [x0, #0x6f]
    // 0x6965b0: cmn             x1, #1
    // 0x6965b4: b.eq            #0x6965d4
    // 0x6965b8: LoadField: r1 = r0->field_7b
    //     0x6965b8: ldur            w1, [x0, #0x7b]
    // 0x6965bc: DecompressPointer r1
    //     0x6965bc: add             x1, x1, HEAP, lsl #32
    // 0x6965c0: tbz             w1, #4, #0x6965d4
    // 0x6965c4: r0 = Null
    //     0x6965c4: mov             x0, NULL
    // 0x6965c8: LeaveFrame
    //     0x6965c8: mov             SP, fp
    //     0x6965cc: ldp             fp, lr, [SP], #0x10
    // 0x6965d0: ret
    //     0x6965d0: ret             
    // 0x6965d4: ldr             x4, [fp, #0x10]
    // 0x6965d8: mov             x0, x4
    // 0x6965dc: r2 = Null
    //     0x6965dc: mov             x2, NULL
    // 0x6965e0: r1 = Null
    //     0x6965e0: mov             x1, NULL
    // 0x6965e4: r4 = LoadClassIdInstr(r0)
    //     0x6965e4: ldur            x4, [x0, #-1]
    //     0x6965e8: ubfx            x4, x4, #0xc, #0x14
    // 0x6965ec: sub             x4, x4, #0x965
    // 0x6965f0: cmp             x4, #0x8b
    // 0x6965f4: b.ls            #0x69660c
    // 0x6965f8: r8 = RenderBox
    //     0x6965f8: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x6965fc: ldr             x8, [x8, #0xfa0]
    // 0x696600: r3 = Null
    //     0x696600: add             x3, PP, #0x50, lsl #12  ; [pp+0x505e8] Null
    //     0x696604: ldr             x3, [x3, #0x5e8]
    // 0x696608: r0 = RenderBox()
    //     0x696608: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x69660c: ldur            x0, [fp, #-8]
    // 0x696610: LoadField: r1 = r0->field_13
    //     0x696610: ldur            w1, [x0, #0x13]
    // 0x696614: DecompressPointer r1
    //     0x696614: add             x1, x1, HEAP, lsl #32
    // 0x696618: stur            x1, [fp, #-0x10]
    // 0x69661c: SaveReg r1
    //     0x69661c: str             x1, [SP, #-8]!
    // 0x696620: r0 = loosen()
    //     0x696620: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x696624: add             SP, SP, #8
    // 0x696628: ldr             x1, [fp, #0x10]
    // 0x69662c: r2 = LoadClassIdInstr(r1)
    //     0x69662c: ldur            x2, [x1, #-1]
    //     0x696630: ubfx            x2, x2, #0xc, #0x14
    // 0x696634: stp             x0, x1, [SP, #-0x10]!
    // 0x696638: r16 = true
    //     0x696638: add             x16, NULL, #0x20  ; true
    // 0x69663c: SaveReg r16
    //     0x69663c: str             x16, [SP, #-8]!
    // 0x696640: mov             x0, x2
    // 0x696644: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x696644: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x696648: ldr             x4, [x4, #0x1c8]
    // 0x69664c: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x69664c: mov             x17, #0xcdfb
    //     0x696650: add             lr, x0, x17
    //     0x696654: ldr             lr, [x21, lr, lsl #3]
    //     0x696658: blr             lr
    // 0x69665c: add             SP, SP, #0x18
    // 0x696660: ldur            x1, [fp, #-8]
    // 0x696664: LoadField: r2 = r1->field_1b
    //     0x696664: ldur            w2, [x1, #0x1b]
    // 0x696668: DecompressPointer r2
    //     0x696668: add             x2, x2, HEAP, lsl #32
    // 0x69666c: ldr             x3, [fp, #0x10]
    // 0x696670: LoadField: r4 = r3->field_57
    //     0x696670: ldur            w4, [x3, #0x57]
    // 0x696674: DecompressPointer r4
    //     0x696674: add             x4, x4, HEAP, lsl #32
    // 0x696678: cmp             w4, NULL
    // 0x69667c: b.eq            #0x696740
    // 0x696680: LoadField: d0 = r4->field_7
    //     0x696680: ldur            d0, [x4, #7]
    // 0x696684: cmp             w2, NULL
    // 0x696688: b.eq            #0x696744
    // 0x69668c: LoadField: d1 = r2->field_7
    //     0x69668c: ldur            d1, [x2, #7]
    // 0x696690: fadd            d2, d1, d0
    // 0x696694: r0 = inline_Allocate_Double()
    //     0x696694: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x696698: add             x0, x0, #0x10
    //     0x69669c: cmp             x2, x0
    //     0x6966a0: b.ls            #0x696748
    //     0x6966a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6966a8: sub             x0, x0, #0xf
    //     0x6966ac: mov             x2, #0xd108
    //     0x6966b0: movk            x2, #3, lsl #16
    //     0x6966b4: stur            x2, [x0, #-1]
    // 0x6966b8: StoreField: r0->field_7 = d2
    //     0x6966b8: stur            d2, [x0, #7]
    // 0x6966bc: StoreField: r1->field_1b = r0
    //     0x6966bc: stur            w0, [x1, #0x1b]
    //     0x6966c0: ldurb           w16, [x1, #-1]
    //     0x6966c4: ldurb           w17, [x0, #-1]
    //     0x6966c8: and             x16, x17, x16, lsr #2
    //     0x6966cc: tst             x16, HEAP, lsr #32
    //     0x6966d0: b.eq            #0x6966d8
    //     0x6966d4: bl              #0xd6826c
    // 0x6966d8: ldur            x2, [fp, #-0x10]
    // 0x6966dc: LoadField: d0 = r2->field_f
    //     0x6966dc: ldur            d0, [x2, #0xf]
    // 0x6966e0: fcmp            d2, d0
    // 0x6966e4: b.vs            #0x696724
    // 0x6966e8: b.le            #0x696724
    // 0x6966ec: LoadField: r2 = r1->field_f
    //     0x6966ec: ldur            w2, [x1, #0xf]
    // 0x6966f0: DecompressPointer r2
    //     0x6966f0: add             x2, x2, HEAP, lsl #32
    // 0x6966f4: LoadField: r3 = r2->field_6f
    //     0x6966f4: ldur            x3, [x2, #0x6f]
    // 0x6966f8: cmn             x3, #1
    // 0x6966fc: b.ne            #0x696724
    // 0x696700: LoadField: r3 = r1->field_17
    //     0x696700: ldur            w3, [x1, #0x17]
    // 0x696704: DecompressPointer r3
    //     0x696704: add             x3, x3, HEAP, lsl #32
    // 0x696708: cmp             w3, NULL
    // 0x69670c: b.eq            #0x696760
    // 0x696710: r1 = LoadInt32Instr(r3)
    //     0x696710: sbfx            x1, x3, #1, #0x1f
    //     0x696714: tbz             w3, #0, #0x69671c
    //     0x696718: ldur            x1, [x3, #7]
    // 0x69671c: sub             x3, x1, #1
    // 0x696720: StoreField: r2->field_6f = r3
    //     0x696720: stur            x3, [x2, #0x6f]
    // 0x696724: r0 = Null
    //     0x696724: mov             x0, NULL
    // 0x696728: LeaveFrame
    //     0x696728: mov             SP, fp
    //     0x69672c: ldp             fp, lr, [SP], #0x10
    // 0x696730: ret
    //     0x696730: ret             
    // 0x696734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x696734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x696738: b               #0x696550
    // 0x69673c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x69673c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x696740: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x696740: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x696744: r0 = NullErrorSharedWithFPURegs()
    //     0x696744: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x696748: SaveReg d2
    //     0x696748: str             q2, [SP, #-0x10]!
    // 0x69674c: SaveReg r1
    //     0x69674c: str             x1, [SP, #-8]!
    // 0x696750: r0 = AllocateDouble()
    //     0x696750: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x696754: RestoreReg r1
    //     0x696754: ldr             x1, [SP], #8
    // 0x696758: RestoreReg d2
    //     0x696758: ldr             q2, [SP], #0x10
    // 0x69675c: b               #0x6966b8
    // 0x696760: r0 = NullErrorSharedWithoutFPURegs()
    //     0x696760: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  set _ overflowOpen=(/* No info */) {
    // ** addr: 0x6e02d8, size: 0x64
    // 0x6e02d8: EnterFrame
    //     0x6e02d8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e02dc: mov             fp, SP
    // 0x6e02e0: CheckStackOverflow
    //     0x6e02e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e02e4: cmp             SP, x16
    //     0x6e02e8: b.ls            #0x6e0334
    // 0x6e02ec: ldr             x0, [fp, #0x18]
    // 0x6e02f0: LoadField: r1 = r0->field_7b
    //     0x6e02f0: ldur            w1, [x0, #0x7b]
    // 0x6e02f4: DecompressPointer r1
    //     0x6e02f4: add             x1, x1, HEAP, lsl #32
    // 0x6e02f8: ldr             x2, [fp, #0x10]
    // 0x6e02fc: cmp             w2, w1
    // 0x6e0300: b.ne            #0x6e0314
    // 0x6e0304: r0 = Null
    //     0x6e0304: mov             x0, NULL
    // 0x6e0308: LeaveFrame
    //     0x6e0308: mov             SP, fp
    //     0x6e030c: ldp             fp, lr, [SP], #0x10
    // 0x6e0310: ret
    //     0x6e0310: ret             
    // 0x6e0314: StoreField: r0->field_7b = r2
    //     0x6e0314: stur            w2, [x0, #0x7b]
    // 0x6e0318: SaveReg r0
    //     0x6e0318: str             x0, [SP, #-8]!
    // 0x6e031c: r0 = markNeedsLayout()
    //     0x6e031c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e0320: add             SP, SP, #8
    // 0x6e0324: r0 = Null
    //     0x6e0324: mov             x0, NULL
    // 0x6e0328: LeaveFrame
    //     0x6e0328: mov             SP, fp
    //     0x6e032c: ldp             fp, lr, [SP], #0x10
    // 0x6e0330: ret
    //     0x6e0330: ret             
    // 0x6e0334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e0338: b               #0x6e02ec
  }
  set _ isAbove=(/* No info */) {
    // ** addr: 0x6e033c, size: 0x64
    // 0x6e033c: EnterFrame
    //     0x6e033c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0340: mov             fp, SP
    // 0x6e0344: CheckStackOverflow
    //     0x6e0344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0348: cmp             SP, x16
    //     0x6e034c: b.ls            #0x6e0398
    // 0x6e0350: ldr             x0, [fp, #0x18]
    // 0x6e0354: LoadField: r1 = r0->field_77
    //     0x6e0354: ldur            w1, [x0, #0x77]
    // 0x6e0358: DecompressPointer r1
    //     0x6e0358: add             x1, x1, HEAP, lsl #32
    // 0x6e035c: ldr             x2, [fp, #0x10]
    // 0x6e0360: cmp             w2, w1
    // 0x6e0364: b.ne            #0x6e0378
    // 0x6e0368: r0 = Null
    //     0x6e0368: mov             x0, NULL
    // 0x6e036c: LeaveFrame
    //     0x6e036c: mov             SP, fp
    //     0x6e0370: ldp             fp, lr, [SP], #0x10
    // 0x6e0374: ret
    //     0x6e0374: ret             
    // 0x6e0378: StoreField: r0->field_77 = r2
    //     0x6e0378: stur            w2, [x0, #0x77]
    // 0x6e037c: SaveReg r0
    //     0x6e037c: str             x0, [SP, #-8]!
    // 0x6e0380: r0 = markNeedsLayout()
    //     0x6e0380: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e0384: add             SP, SP, #8
    // 0x6e0388: r0 = Null
    //     0x6e0388: mov             x0, NULL
    // 0x6e038c: LeaveFrame
    //     0x6e038c: mov             SP, fp
    //     0x6e0390: ldp             fp, lr, [SP], #0x10
    // 0x6e0394: ret
    //     0x6e0394: ret             
    // 0x6e0398: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0398: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e039c: b               #0x6e0350
  }
}

// class id: 2522, size: 0x70, field offset: 0x64
class _TextSelectionToolbarTrailingEdgeAlignRenderBox extends RenderProxyBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x625324, size: 0xdc
    // 0x625324: EnterFrame
    //     0x625324: stp             fp, lr, [SP, #-0x10]!
    //     0x625328: mov             fp, SP
    // 0x62532c: AllocStack(0x18)
    //     0x62532c: sub             SP, SP, #0x18
    // 0x625330: CheckStackOverflow
    //     0x625330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x625334: cmp             SP, x16
    //     0x625338: b.ls            #0x6253f0
    // 0x62533c: r1 = 1
    //     0x62533c: mov             x1, #1
    // 0x625340: r0 = AllocateContext()
    //     0x625340: bl              #0xd68aa4  ; AllocateContextStub
    // 0x625344: mov             x3, x0
    // 0x625348: ldr             x0, [fp, #0x20]
    // 0x62534c: stur            x3, [fp, #-0x10]
    // 0x625350: StoreField: r3->field_f = r0
    //     0x625350: stur            w0, [x3, #0xf]
    // 0x625354: LoadField: r1 = r0->field_5f
    //     0x625354: ldur            w1, [x0, #0x5f]
    // 0x625358: DecompressPointer r1
    //     0x625358: add             x1, x1, HEAP, lsl #32
    // 0x62535c: cmp             w1, NULL
    // 0x625360: b.eq            #0x6253f8
    // 0x625364: LoadField: r4 = r1->field_17
    //     0x625364: ldur            w4, [x1, #0x17]
    // 0x625368: DecompressPointer r4
    //     0x625368: add             x4, x4, HEAP, lsl #32
    // 0x62536c: stur            x4, [fp, #-8]
    // 0x625370: cmp             w4, NULL
    // 0x625374: b.eq            #0x6253fc
    // 0x625378: mov             x0, x4
    // 0x62537c: r2 = Null
    //     0x62537c: mov             x2, NULL
    // 0x625380: r1 = Null
    //     0x625380: mov             x1, NULL
    // 0x625384: r4 = LoadClassIdInstr(r0)
    //     0x625384: ldur            x4, [x0, #-1]
    //     0x625388: ubfx            x4, x4, #0xc, #0x14
    // 0x62538c: cmp             x4, #0x804
    // 0x625390: b.eq            #0x6253a8
    // 0x625394: r8 = ToolbarItemsParentData<RenderBox>
    //     0x625394: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x625398: ldr             x8, [x8, #0x528]
    // 0x62539c: r3 = Null
    //     0x62539c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50608] Null
    //     0x6253a0: ldr             x3, [x3, #0x608]
    // 0x6253a4: r0 = DefaultTypeTest()
    //     0x6253a4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6253a8: ldur            x0, [fp, #-8]
    // 0x6253ac: LoadField: r3 = r0->field_7
    //     0x6253ac: ldur            w3, [x0, #7]
    // 0x6253b0: DecompressPointer r3
    //     0x6253b0: add             x3, x3, HEAP, lsl #32
    // 0x6253b4: ldur            x2, [fp, #-0x10]
    // 0x6253b8: stur            x3, [fp, #-0x18]
    // 0x6253bc: r1 = Function '<anonymous closure>':.
    //     0x6253bc: add             x1, PP, #0x50, lsl #12  ; [pp+0x50618] AnonymousClosure: (0x625400), in [package:flutter/src/widgets/single_child_scroll_view.dart] _RenderSingleChildViewport::hitTestChildren (0x6277d0)
    //     0x6253c0: ldr             x1, [x1, #0x618]
    // 0x6253c4: r0 = AllocateClosure()
    //     0x6253c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6253c8: ldr             x16, [fp, #0x18]
    // 0x6253cc: stp             x0, x16, [SP, #-0x10]!
    // 0x6253d0: ldur            x16, [fp, #-0x18]
    // 0x6253d4: ldr             lr, [fp, #0x10]
    // 0x6253d8: stp             lr, x16, [SP, #-0x10]!
    // 0x6253dc: r0 = addWithPaintOffset()
    //     0x6253dc: bl              #0x622820  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x6253e0: add             SP, SP, #0x20
    // 0x6253e4: LeaveFrame
    //     0x6253e4: mov             SP, fp
    //     0x6253e8: ldp             fp, lr, [SP], #0x10
    // 0x6253ec: ret
    //     0x6253ec: ret             
    // 0x6253f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6253f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6253f4: b               #0x62533c
    // 0x6253f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6253f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6253fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6253fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x660ba8, size: 0xc8
    // 0x660ba8: EnterFrame
    //     0x660ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x660bac: mov             fp, SP
    // 0x660bb0: AllocStack(0x10)
    //     0x660bb0: sub             SP, SP, #0x10
    // 0x660bb4: CheckStackOverflow
    //     0x660bb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x660bb8: cmp             SP, x16
    //     0x660bbc: b.ls            #0x660c60
    // 0x660bc0: ldr             x0, [fp, #0x20]
    // 0x660bc4: LoadField: r3 = r0->field_5f
    //     0x660bc4: ldur            w3, [x0, #0x5f]
    // 0x660bc8: DecompressPointer r3
    //     0x660bc8: add             x3, x3, HEAP, lsl #32
    // 0x660bcc: stur            x3, [fp, #-0x10]
    // 0x660bd0: cmp             w3, NULL
    // 0x660bd4: b.eq            #0x660c68
    // 0x660bd8: LoadField: r4 = r3->field_17
    //     0x660bd8: ldur            w4, [x3, #0x17]
    // 0x660bdc: DecompressPointer r4
    //     0x660bdc: add             x4, x4, HEAP, lsl #32
    // 0x660be0: stur            x4, [fp, #-8]
    // 0x660be4: cmp             w4, NULL
    // 0x660be8: b.eq            #0x660c6c
    // 0x660bec: mov             x0, x4
    // 0x660bf0: r2 = Null
    //     0x660bf0: mov             x2, NULL
    // 0x660bf4: r1 = Null
    //     0x660bf4: mov             x1, NULL
    // 0x660bf8: r4 = LoadClassIdInstr(r0)
    //     0x660bf8: ldur            x4, [x0, #-1]
    //     0x660bfc: ubfx            x4, x4, #0xc, #0x14
    // 0x660c00: cmp             x4, #0x804
    // 0x660c04: b.eq            #0x660c1c
    // 0x660c08: r8 = ToolbarItemsParentData<RenderBox>
    //     0x660c08: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x660c0c: ldr             x8, [x8, #0x528]
    // 0x660c10: r3 = Null
    //     0x660c10: add             x3, PP, #0x50, lsl #12  ; [pp+0x50620] Null
    //     0x660c14: ldr             x3, [x3, #0x620]
    // 0x660c18: r0 = DefaultTypeTest()
    //     0x660c18: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x660c1c: ldur            x0, [fp, #-8]
    // 0x660c20: LoadField: r1 = r0->field_7
    //     0x660c20: ldur            w1, [x0, #7]
    // 0x660c24: DecompressPointer r1
    //     0x660c24: add             x1, x1, HEAP, lsl #32
    // 0x660c28: ldr             x16, [fp, #0x10]
    // 0x660c2c: stp             x16, x1, [SP, #-0x10]!
    // 0x660c30: r0 = +()
    //     0x660c30: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x660c34: add             SP, SP, #0x10
    // 0x660c38: ldr             x16, [fp, #0x18]
    // 0x660c3c: ldur            lr, [fp, #-0x10]
    // 0x660c40: stp             lr, x16, [SP, #-0x10]!
    // 0x660c44: SaveReg r0
    //     0x660c44: str             x0, [SP, #-8]!
    // 0x660c48: r0 = paintChild()
    //     0x660c48: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x660c4c: add             SP, SP, #0x18
    // 0x660c50: r0 = Null
    //     0x660c50: mov             x0, NULL
    // 0x660c54: LeaveFrame
    //     0x660c54: mov             SP, fp
    //     0x660c58: ldp             fp, lr, [SP], #0x10
    // 0x660c5c: ret
    //     0x660c5c: ret             
    // 0x660c60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x660c60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x660c64: b               #0x660bc0
    // 0x660c68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660c68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x660c6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x660c6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x68ecac, size: 0x3dc
    // 0x68ecac: EnterFrame
    //     0x68ecac: stp             fp, lr, [SP, #-0x10]!
    //     0x68ecb0: mov             fp, SP
    // 0x68ecb4: AllocStack(0x28)
    //     0x68ecb4: sub             SP, SP, #0x28
    // 0x68ecb8: CheckStackOverflow
    //     0x68ecb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68ecbc: cmp             SP, x16
    //     0x68ecc0: b.ls            #0x68f040
    // 0x68ecc4: ldr             x3, [fp, #0x10]
    // 0x68ecc8: LoadField: r4 = r3->field_5f
    //     0x68ecc8: ldur            w4, [x3, #0x5f]
    // 0x68eccc: DecompressPointer r4
    //     0x68eccc: add             x4, x4, HEAP, lsl #32
    // 0x68ecd0: stur            x4, [fp, #-0x10]
    // 0x68ecd4: cmp             w4, NULL
    // 0x68ecd8: b.eq            #0x68f048
    // 0x68ecdc: LoadField: r5 = r3->field_27
    //     0x68ecdc: ldur            w5, [x3, #0x27]
    // 0x68ece0: DecompressPointer r5
    //     0x68ece0: add             x5, x5, HEAP, lsl #32
    // 0x68ece4: stur            x5, [fp, #-8]
    // 0x68ece8: cmp             w5, NULL
    // 0x68ecec: b.eq            #0x68f008
    // 0x68ecf0: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68ecf0: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68ecf4: ldr             x6, [x6, #0x1e8]
    // 0x68ecf8: mov             x0, x5
    // 0x68ecfc: r2 = Null
    //     0x68ecfc: mov             x2, NULL
    // 0x68ed00: r1 = Null
    //     0x68ed00: mov             x1, NULL
    // 0x68ed04: r4 = LoadClassIdInstr(r0)
    //     0x68ed04: ldur            x4, [x0, #-1]
    //     0x68ed08: ubfx            x4, x4, #0xc, #0x14
    // 0x68ed0c: sub             x4, x4, #0x80d
    // 0x68ed10: cmp             x4, #1
    // 0x68ed14: b.ls            #0x68ed2c
    // 0x68ed18: r8 = BoxConstraints
    //     0x68ed18: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68ed1c: ldr             x8, [x8, #0x1d0]
    // 0x68ed20: r3 = Null
    //     0x68ed20: add             x3, PP, #0x50, lsl #12  ; [pp+0x50630] Null
    //     0x68ed24: ldr             x3, [x3, #0x630]
    // 0x68ed28: r0 = BoxConstraints()
    //     0x68ed28: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68ed2c: ldur            x16, [fp, #-8]
    // 0x68ed30: SaveReg r16
    //     0x68ed30: str             x16, [SP, #-8]!
    // 0x68ed34: r0 = loosen()
    //     0x68ed34: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x68ed38: add             SP, SP, #8
    // 0x68ed3c: mov             x1, x0
    // 0x68ed40: ldur            x0, [fp, #-0x10]
    // 0x68ed44: r2 = LoadClassIdInstr(r0)
    //     0x68ed44: ldur            x2, [x0, #-1]
    //     0x68ed48: ubfx            x2, x2, #0xc, #0x14
    // 0x68ed4c: stp             x1, x0, [SP, #-0x10]!
    // 0x68ed50: r16 = true
    //     0x68ed50: add             x16, NULL, #0x20  ; true
    // 0x68ed54: SaveReg r16
    //     0x68ed54: str             x16, [SP, #-8]!
    // 0x68ed58: mov             x0, x2
    // 0x68ed5c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68ed5c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68ed60: ldr             x4, [x4, #0x1c8]
    // 0x68ed64: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68ed64: mov             x17, #0xcdfb
    //     0x68ed68: add             lr, x0, x17
    //     0x68ed6c: ldr             lr, [x21, lr, lsl #3]
    //     0x68ed70: blr             lr
    // 0x68ed74: add             SP, SP, #0x18
    // 0x68ed78: ldr             x3, [fp, #0x10]
    // 0x68ed7c: LoadField: r0 = r3->field_67
    //     0x68ed7c: ldur            w0, [x3, #0x67]
    // 0x68ed80: DecompressPointer r0
    //     0x68ed80: add             x0, x0, HEAP, lsl #32
    // 0x68ed84: tbz             w0, #4, #0x68ee00
    // 0x68ed88: LoadField: r0 = r3->field_63
    //     0x68ed88: ldur            w0, [x3, #0x63]
    // 0x68ed8c: DecompressPointer r0
    //     0x68ed8c: add             x0, x0, HEAP, lsl #32
    // 0x68ed90: cmp             w0, NULL
    // 0x68ed94: b.ne            #0x68ee00
    // 0x68ed98: LoadField: r0 = r3->field_5f
    //     0x68ed98: ldur            w0, [x3, #0x5f]
    // 0x68ed9c: DecompressPointer r0
    //     0x68ed9c: add             x0, x0, HEAP, lsl #32
    // 0x68eda0: cmp             w0, NULL
    // 0x68eda4: b.eq            #0x68f04c
    // 0x68eda8: LoadField: r1 = r0->field_57
    //     0x68eda8: ldur            w1, [x0, #0x57]
    // 0x68edac: DecompressPointer r1
    //     0x68edac: add             x1, x1, HEAP, lsl #32
    // 0x68edb0: cmp             w1, NULL
    // 0x68edb4: b.eq            #0x68f050
    // 0x68edb8: LoadField: d0 = r1->field_7
    //     0x68edb8: ldur            d0, [x1, #7]
    // 0x68edbc: r0 = inline_Allocate_Double()
    //     0x68edbc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x68edc0: add             x0, x0, #0x10
    //     0x68edc4: cmp             x1, x0
    //     0x68edc8: b.ls            #0x68f054
    //     0x68edcc: str             x0, [THR, #0x60]  ; THR::top
    //     0x68edd0: sub             x0, x0, #0xf
    //     0x68edd4: mov             x1, #0xd108
    //     0x68edd8: movk            x1, #3, lsl #16
    //     0x68eddc: stur            x1, [x0, #-1]
    // 0x68ede0: StoreField: r0->field_7 = d0
    //     0x68ede0: stur            d0, [x0, #7]
    // 0x68ede4: StoreField: r3->field_63 = r0
    //     0x68ede4: stur            w0, [x3, #0x63]
    //     0x68ede8: ldurb           w16, [x3, #-1]
    //     0x68edec: ldurb           w17, [x0, #-1]
    //     0x68edf0: and             x16, x17, x16, lsr #2
    //     0x68edf4: tst             x16, HEAP, lsr #32
    //     0x68edf8: b.eq            #0x68ee00
    //     0x68edfc: bl              #0xd682ac
    // 0x68ee00: LoadField: r4 = r3->field_27
    //     0x68ee00: ldur            w4, [x3, #0x27]
    // 0x68ee04: DecompressPointer r4
    //     0x68ee04: add             x4, x4, HEAP, lsl #32
    // 0x68ee08: stur            x4, [fp, #-8]
    // 0x68ee0c: cmp             w4, NULL
    // 0x68ee10: b.eq            #0x68f020
    // 0x68ee14: mov             x0, x4
    // 0x68ee18: r2 = Null
    //     0x68ee18: mov             x2, NULL
    // 0x68ee1c: r1 = Null
    //     0x68ee1c: mov             x1, NULL
    // 0x68ee20: r4 = LoadClassIdInstr(r0)
    //     0x68ee20: ldur            x4, [x0, #-1]
    //     0x68ee24: ubfx            x4, x4, #0xc, #0x14
    // 0x68ee28: sub             x4, x4, #0x80d
    // 0x68ee2c: cmp             x4, #1
    // 0x68ee30: b.ls            #0x68ee48
    // 0x68ee34: r8 = BoxConstraints
    //     0x68ee34: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x68ee38: ldr             x8, [x8, #0x1d0]
    // 0x68ee3c: r3 = Null
    //     0x68ee3c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50640] Null
    //     0x68ee40: ldr             x3, [x3, #0x640]
    // 0x68ee44: r0 = BoxConstraints()
    //     0x68ee44: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x68ee48: ldr             x0, [fp, #0x10]
    // 0x68ee4c: LoadField: r1 = r0->field_63
    //     0x68ee4c: ldur            w1, [x0, #0x63]
    // 0x68ee50: DecompressPointer r1
    //     0x68ee50: add             x1, x1, HEAP, lsl #32
    // 0x68ee54: cmp             w1, NULL
    // 0x68ee58: b.eq            #0x68ee90
    // 0x68ee5c: LoadField: r2 = r0->field_5f
    //     0x68ee5c: ldur            w2, [x0, #0x5f]
    // 0x68ee60: DecompressPointer r2
    //     0x68ee60: add             x2, x2, HEAP, lsl #32
    // 0x68ee64: cmp             w2, NULL
    // 0x68ee68: b.eq            #0x68f06c
    // 0x68ee6c: LoadField: r3 = r2->field_57
    //     0x68ee6c: ldur            w3, [x2, #0x57]
    // 0x68ee70: DecompressPointer r3
    //     0x68ee70: add             x3, x3, HEAP, lsl #32
    // 0x68ee74: cmp             w3, NULL
    // 0x68ee78: b.eq            #0x68f070
    // 0x68ee7c: LoadField: d0 = r3->field_7
    //     0x68ee7c: ldur            d0, [x3, #7]
    // 0x68ee80: LoadField: d1 = r1->field_7
    //     0x68ee80: ldur            d1, [x1, #7]
    // 0x68ee84: fcmp            d0, d1
    // 0x68ee88: b.vs            #0x68eebc
    // 0x68ee8c: b.le            #0x68eebc
    // 0x68ee90: LoadField: r1 = r0->field_5f
    //     0x68ee90: ldur            w1, [x0, #0x5f]
    // 0x68ee94: DecompressPointer r1
    //     0x68ee94: add             x1, x1, HEAP, lsl #32
    // 0x68ee98: cmp             w1, NULL
    // 0x68ee9c: b.eq            #0x68f074
    // 0x68eea0: LoadField: r2 = r1->field_57
    //     0x68eea0: ldur            w2, [x1, #0x57]
    // 0x68eea4: DecompressPointer r2
    //     0x68eea4: add             x2, x2, HEAP, lsl #32
    // 0x68eea8: cmp             w2, NULL
    // 0x68eeac: b.eq            #0x68f078
    // 0x68eeb0: LoadField: d0 = r2->field_7
    //     0x68eeb0: ldur            d0, [x2, #7]
    // 0x68eeb4: mov             x1, x2
    // 0x68eeb8: b               #0x68eec4
    // 0x68eebc: mov             v0.16b, v1.16b
    // 0x68eec0: mov             x1, x3
    // 0x68eec4: stur            d0, [fp, #-0x28]
    // 0x68eec8: LoadField: d1 = r1->field_f
    //     0x68eec8: ldur            d1, [x1, #0xf]
    // 0x68eecc: stur            d1, [fp, #-0x20]
    // 0x68eed0: r0 = Size()
    //     0x68eed0: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x68eed4: ldur            d0, [fp, #-0x28]
    // 0x68eed8: StoreField: r0->field_7 = d0
    //     0x68eed8: stur            d0, [x0, #7]
    // 0x68eedc: ldur            d0, [fp, #-0x20]
    // 0x68eee0: StoreField: r0->field_f = d0
    //     0x68eee0: stur            d0, [x0, #0xf]
    // 0x68eee4: ldur            x16, [fp, #-8]
    // 0x68eee8: stp             x0, x16, [SP, #-0x10]!
    // 0x68eeec: r0 = constrain()
    //     0x68eeec: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x68eef0: add             SP, SP, #0x10
    // 0x68eef4: mov             x4, x0
    // 0x68eef8: ldr             x3, [fp, #0x10]
    // 0x68eefc: stur            x4, [fp, #-0x18]
    // 0x68ef00: StoreField: r3->field_57 = r0
    //     0x68ef00: stur            w0, [x3, #0x57]
    //     0x68ef04: ldurb           w16, [x3, #-1]
    //     0x68ef08: ldurb           w17, [x0, #-1]
    //     0x68ef0c: and             x16, x17, x16, lsr #2
    //     0x68ef10: tst             x16, HEAP, lsr #32
    //     0x68ef14: b.eq            #0x68ef1c
    //     0x68ef18: bl              #0xd682ac
    // 0x68ef1c: LoadField: r5 = r3->field_5f
    //     0x68ef1c: ldur            w5, [x3, #0x5f]
    // 0x68ef20: DecompressPointer r5
    //     0x68ef20: add             x5, x5, HEAP, lsl #32
    // 0x68ef24: stur            x5, [fp, #-0x10]
    // 0x68ef28: cmp             w5, NULL
    // 0x68ef2c: b.eq            #0x68f07c
    // 0x68ef30: LoadField: r6 = r5->field_17
    //     0x68ef30: ldur            w6, [x5, #0x17]
    // 0x68ef34: DecompressPointer r6
    //     0x68ef34: add             x6, x6, HEAP, lsl #32
    // 0x68ef38: stur            x6, [fp, #-8]
    // 0x68ef3c: cmp             w6, NULL
    // 0x68ef40: b.eq            #0x68f080
    // 0x68ef44: mov             x0, x6
    // 0x68ef48: r2 = Null
    //     0x68ef48: mov             x2, NULL
    // 0x68ef4c: r1 = Null
    //     0x68ef4c: mov             x1, NULL
    // 0x68ef50: r4 = LoadClassIdInstr(r0)
    //     0x68ef50: ldur            x4, [x0, #-1]
    //     0x68ef54: ubfx            x4, x4, #0xc, #0x14
    // 0x68ef58: cmp             x4, #0x804
    // 0x68ef5c: b.eq            #0x68ef74
    // 0x68ef60: r8 = ToolbarItemsParentData<RenderBox>
    //     0x68ef60: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x68ef64: ldr             x8, [x8, #0x528]
    // 0x68ef68: r3 = Null
    //     0x68ef68: add             x3, PP, #0x50, lsl #12  ; [pp+0x50650] Null
    //     0x68ef6c: ldr             x3, [x3, #0x650]
    // 0x68ef70: r0 = DefaultTypeTest()
    //     0x68ef70: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68ef74: ldr             x0, [fp, #0x10]
    // 0x68ef78: LoadField: r1 = r0->field_6b
    //     0x68ef78: ldur            w1, [x0, #0x6b]
    // 0x68ef7c: DecompressPointer r1
    //     0x68ef7c: add             x1, x1, HEAP, lsl #32
    // 0x68ef80: r16 = Instance_TextDirection
    //     0x68ef80: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x68ef84: cmp             w1, w16
    // 0x68ef88: b.ne            #0x68ef94
    // 0x68ef8c: d0 = 0.000000
    //     0x68ef8c: eor             v0.16b, v0.16b, v0.16b
    // 0x68ef90: b               #0x68efbc
    // 0x68ef94: ldur            x0, [fp, #-0x18]
    // 0x68ef98: ldur            x1, [fp, #-0x10]
    // 0x68ef9c: LoadField: d0 = r0->field_7
    //     0x68ef9c: ldur            d0, [x0, #7]
    // 0x68efa0: LoadField: r0 = r1->field_57
    //     0x68efa0: ldur            w0, [x1, #0x57]
    // 0x68efa4: DecompressPointer r0
    //     0x68efa4: add             x0, x0, HEAP, lsl #32
    // 0x68efa8: cmp             w0, NULL
    // 0x68efac: b.eq            #0x68f084
    // 0x68efb0: LoadField: d1 = r0->field_7
    //     0x68efb0: ldur            d1, [x0, #7]
    // 0x68efb4: fsub            d2, d0, d1
    // 0x68efb8: mov             v0.16b, v2.16b
    // 0x68efbc: ldur            x0, [fp, #-8]
    // 0x68efc0: stur            d0, [fp, #-0x20]
    // 0x68efc4: r0 = Offset()
    //     0x68efc4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68efc8: ldur            d0, [fp, #-0x20]
    // 0x68efcc: StoreField: r0->field_7 = d0
    //     0x68efcc: stur            d0, [x0, #7]
    // 0x68efd0: d0 = 0.000000
    //     0x68efd0: eor             v0.16b, v0.16b, v0.16b
    // 0x68efd4: StoreField: r0->field_f = d0
    //     0x68efd4: stur            d0, [x0, #0xf]
    // 0x68efd8: ldur            x1, [fp, #-8]
    // 0x68efdc: StoreField: r1->field_7 = r0
    //     0x68efdc: stur            w0, [x1, #7]
    //     0x68efe0: ldurb           w16, [x1, #-1]
    //     0x68efe4: ldurb           w17, [x0, #-1]
    //     0x68efe8: and             x16, x17, x16, lsr #2
    //     0x68efec: tst             x16, HEAP, lsr #32
    //     0x68eff0: b.eq            #0x68eff8
    //     0x68eff4: bl              #0xd6826c
    // 0x68eff8: r0 = Null
    //     0x68eff8: mov             x0, NULL
    // 0x68effc: LeaveFrame
    //     0x68effc: mov             SP, fp
    //     0x68f000: ldp             fp, lr, [SP], #0x10
    // 0x68f004: ret
    //     0x68f004: ret             
    // 0x68f008: r0 = StateError()
    //     0x68f008: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68f00c: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f00c: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f010: ldr             x6, [x6, #0x1e8]
    // 0x68f014: StoreField: r0->field_b = r6
    //     0x68f014: stur            w6, [x0, #0xb]
    // 0x68f018: r0 = Throw()
    //     0x68f018: bl              #0xd67e38  ; ThrowStub
    // 0x68f01c: brk             #0
    // 0x68f020: r0 = StateError()
    //     0x68f020: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x68f024: mov             x1, x0
    // 0x68f028: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f028: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x68f02c: ldr             x0, [x0, #0x1e8]
    // 0x68f030: StoreField: r1->field_b = r0
    //     0x68f030: stur            w0, [x1, #0xb]
    // 0x68f034: mov             x0, x1
    // 0x68f038: r0 = Throw()
    //     0x68f038: bl              #0xd67e38  ; ThrowStub
    // 0x68f03c: brk             #0
    // 0x68f040: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68f040: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68f044: b               #0x68ecc4
    // 0x68f048: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f048: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f04c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f04c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f050: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f050: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f054: SaveReg d0
    //     0x68f054: str             q0, [SP, #-0x10]!
    // 0x68f058: SaveReg r3
    //     0x68f058: str             x3, [SP, #-8]!
    // 0x68f05c: r0 = AllocateDouble()
    //     0x68f05c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68f060: RestoreReg r3
    //     0x68f060: ldr             x3, [SP], #8
    // 0x68f064: RestoreReg d0
    //     0x68f064: ldr             q0, [SP], #0x10
    // 0x68f068: b               #0x68ede0
    // 0x68f06c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f06c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f070: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f070: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f074: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f078: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f078: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f07c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f07c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f080: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68f080: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68f084: r0 = NullCastErrorSharedWithFPURegs()
    //     0x68f084: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ applyPaintTransform(/* No info */) {
    // ** addr: 0x6bc270, size: 0xdc
    // 0x6bc270: EnterFrame
    //     0x6bc270: stp             fp, lr, [SP, #-0x10]!
    //     0x6bc274: mov             fp, SP
    // 0x6bc278: AllocStack(0x8)
    //     0x6bc278: sub             SP, SP, #8
    // 0x6bc27c: CheckStackOverflow
    //     0x6bc27c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bc280: cmp             SP, x16
    //     0x6bc284: b.ls            #0x6bc330
    // 0x6bc288: ldr             x0, [fp, #0x18]
    // 0x6bc28c: LoadField: r3 = r0->field_17
    //     0x6bc28c: ldur            w3, [x0, #0x17]
    // 0x6bc290: DecompressPointer r3
    //     0x6bc290: add             x3, x3, HEAP, lsl #32
    // 0x6bc294: stur            x3, [fp, #-8]
    // 0x6bc298: cmp             w3, NULL
    // 0x6bc29c: b.eq            #0x6bc338
    // 0x6bc2a0: mov             x0, x3
    // 0x6bc2a4: r2 = Null
    //     0x6bc2a4: mov             x2, NULL
    // 0x6bc2a8: r1 = Null
    //     0x6bc2a8: mov             x1, NULL
    // 0x6bc2ac: r4 = LoadClassIdInstr(r0)
    //     0x6bc2ac: ldur            x4, [x0, #-1]
    //     0x6bc2b0: ubfx            x4, x4, #0xc, #0x14
    // 0x6bc2b4: cmp             x4, #0x804
    // 0x6bc2b8: b.eq            #0x6bc2d0
    // 0x6bc2bc: r8 = ToolbarItemsParentData<RenderBox>
    //     0x6bc2bc: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x6bc2c0: ldr             x8, [x8, #0x528]
    // 0x6bc2c4: r3 = Null
    //     0x6bc2c4: add             x3, PP, #0x50, lsl #12  ; [pp+0x505f8] Null
    //     0x6bc2c8: ldr             x3, [x3, #0x5f8]
    // 0x6bc2cc: r0 = DefaultTypeTest()
    //     0x6bc2cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bc2d0: ldur            x0, [fp, #-8]
    // 0x6bc2d4: LoadField: r1 = r0->field_7
    //     0x6bc2d4: ldur            w1, [x0, #7]
    // 0x6bc2d8: DecompressPointer r1
    //     0x6bc2d8: add             x1, x1, HEAP, lsl #32
    // 0x6bc2dc: LoadField: d0 = r1->field_7
    //     0x6bc2dc: ldur            d0, [x1, #7]
    // 0x6bc2e0: LoadField: d1 = r1->field_f
    //     0x6bc2e0: ldur            d1, [x1, #0xf]
    // 0x6bc2e4: r0 = inline_Allocate_Double()
    //     0x6bc2e4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6bc2e8: add             x0, x0, #0x10
    //     0x6bc2ec: cmp             x1, x0
    //     0x6bc2f0: b.ls            #0x6bc33c
    //     0x6bc2f4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6bc2f8: sub             x0, x0, #0xf
    //     0x6bc2fc: mov             x1, #0xd108
    //     0x6bc300: movk            x1, #3, lsl #16
    //     0x6bc304: stur            x1, [x0, #-1]
    // 0x6bc308: StoreField: r0->field_7 = d0
    //     0x6bc308: stur            d0, [x0, #7]
    // 0x6bc30c: ldr             x16, [fp, #0x10]
    // 0x6bc310: stp             x0, x16, [SP, #-0x10]!
    // 0x6bc314: SaveReg d1
    //     0x6bc314: str             d1, [SP, #-8]!
    // 0x6bc318: r0 = translate()
    //     0x6bc318: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0x6bc31c: add             SP, SP, #0x18
    // 0x6bc320: r0 = Null
    //     0x6bc320: mov             x0, NULL
    // 0x6bc324: LeaveFrame
    //     0x6bc324: mov             SP, fp
    //     0x6bc328: ldp             fp, lr, [SP], #0x10
    // 0x6bc32c: ret
    //     0x6bc32c: ret             
    // 0x6bc330: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bc330: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bc334: b               #0x6bc288
    // 0x6bc338: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bc338: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6bc33c: stp             q0, q1, [SP, #-0x20]!
    // 0x6bc340: r0 = AllocateDouble()
    //     0x6bc340: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6bc344: ldp             q0, q1, [SP], #0x20
    // 0x6bc348: b               #0x6bc308
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6c2a2c, size: 0x80
    // 0x6c2a2c: EnterFrame
    //     0x6c2a2c: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2a30: mov             fp, SP
    // 0x6c2a34: CheckStackOverflow
    //     0x6c2a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2a38: cmp             SP, x16
    //     0x6c2a3c: b.ls            #0x6c2aa4
    // 0x6c2a40: ldr             x1, [fp, #0x18]
    // 0x6c2a44: LoadField: r0 = r1->field_6b
    //     0x6c2a44: ldur            w0, [x1, #0x6b]
    // 0x6c2a48: DecompressPointer r0
    //     0x6c2a48: add             x0, x0, HEAP, lsl #32
    // 0x6c2a4c: ldr             x2, [fp, #0x10]
    // 0x6c2a50: cmp             w2, w0
    // 0x6c2a54: b.ne            #0x6c2a68
    // 0x6c2a58: r0 = Null
    //     0x6c2a58: mov             x0, NULL
    // 0x6c2a5c: LeaveFrame
    //     0x6c2a5c: mov             SP, fp
    //     0x6c2a60: ldp             fp, lr, [SP], #0x10
    // 0x6c2a64: ret
    //     0x6c2a64: ret             
    // 0x6c2a68: mov             x0, x2
    // 0x6c2a6c: StoreField: r1->field_6b = r0
    //     0x6c2a6c: stur            w0, [x1, #0x6b]
    //     0x6c2a70: ldurb           w16, [x1, #-1]
    //     0x6c2a74: ldurb           w17, [x0, #-1]
    //     0x6c2a78: and             x16, x17, x16, lsr #2
    //     0x6c2a7c: tst             x16, HEAP, lsr #32
    //     0x6c2a80: b.eq            #0x6c2a88
    //     0x6c2a84: bl              #0xd6826c
    // 0x6c2a88: SaveReg r1
    //     0x6c2a88: str             x1, [SP, #-8]!
    // 0x6c2a8c: r0 = markNeedsLayout()
    //     0x6c2a8c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c2a90: add             SP, SP, #8
    // 0x6c2a94: r0 = Null
    //     0x6c2a94: mov             x0, NULL
    // 0x6c2a98: LeaveFrame
    //     0x6c2a98: mov             SP, fp
    //     0x6c2a9c: ldp             fp, lr, [SP], #0x10
    // 0x6c2aa0: ret
    //     0x6c2aa0: ret             
    // 0x6c2aa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2aa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2aa8: b               #0x6c2a40
  }
  set _ overflowOpen=(/* No info */) {
    // ** addr: 0x6c2aac, size: 0x64
    // 0x6c2aac: EnterFrame
    //     0x6c2aac: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2ab0: mov             fp, SP
    // 0x6c2ab4: CheckStackOverflow
    //     0x6c2ab4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c2ab8: cmp             SP, x16
    //     0x6c2abc: b.ls            #0x6c2b08
    // 0x6c2ac0: ldr             x0, [fp, #0x18]
    // 0x6c2ac4: LoadField: r1 = r0->field_67
    //     0x6c2ac4: ldur            w1, [x0, #0x67]
    // 0x6c2ac8: DecompressPointer r1
    //     0x6c2ac8: add             x1, x1, HEAP, lsl #32
    // 0x6c2acc: ldr             x2, [fp, #0x10]
    // 0x6c2ad0: cmp             w2, w1
    // 0x6c2ad4: b.ne            #0x6c2ae8
    // 0x6c2ad8: r0 = Null
    //     0x6c2ad8: mov             x0, NULL
    // 0x6c2adc: LeaveFrame
    //     0x6c2adc: mov             SP, fp
    //     0x6c2ae0: ldp             fp, lr, [SP], #0x10
    // 0x6c2ae4: ret
    //     0x6c2ae4: ret             
    // 0x6c2ae8: StoreField: r0->field_67 = r2
    //     0x6c2ae8: stur            w2, [x0, #0x67]
    // 0x6c2aec: SaveReg r0
    //     0x6c2aec: str             x0, [SP, #-8]!
    // 0x6c2af0: r0 = markNeedsLayout()
    //     0x6c2af0: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c2af4: add             SP, SP, #8
    // 0x6c2af8: r0 = Null
    //     0x6c2af8: mov             x0, NULL
    // 0x6c2afc: LeaveFrame
    //     0x6c2afc: mov             SP, fp
    //     0x6c2b00: ldp             fp, lr, [SP], #0x10
    // 0x6c2b04: ret
    //     0x6c2b04: ret             
    // 0x6c2b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2b08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2b0c: b               #0x6c2ac0
  }
}

// class id: 3262, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __TextSelectionToolbarOverflowableState&State&TickerProviderStateMixin extends State<_TextSelectionToolbarOverflowable>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ activate(/* No info */) {
    // ** addr: 0x81f9dc, size: 0x3c
    // 0x81f9dc: EnterFrame
    //     0x81f9dc: stp             fp, lr, [SP, #-0x10]!
    //     0x81f9e0: mov             fp, SP
    // 0x81f9e4: CheckStackOverflow
    //     0x81f9e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f9e8: cmp             SP, x16
    //     0x81f9ec: b.ls            #0x81fa10
    // 0x81f9f0: ldr             x16, [fp, #0x10]
    // 0x81f9f4: SaveReg r16
    //     0x81f9f4: str             x16, [SP, #-8]!
    // 0x81f9f8: r0 = _updateTickerModeNotifier()
    //     0x81f9f8: bl              #0x81fa18  ; [package:flutter/src/material/text_selection_toolbar.dart] __TextSelectionToolbarOverflowableState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f9fc: add             SP, SP, #8
    // 0x81fa00: r0 = Null
    //     0x81fa00: mov             x0, NULL
    // 0x81fa04: LeaveFrame
    //     0x81fa04: mov             SP, fp
    //     0x81fa08: ldp             fp, lr, [SP], #0x10
    // 0x81fa0c: ret
    //     0x81fa0c: ret             
    // 0x81fa10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81fa10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81fa14: b               #0x81f9f0
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x81fa18, size: 0x11c
    // 0x81fa18: EnterFrame
    //     0x81fa18: stp             fp, lr, [SP, #-0x10]!
    //     0x81fa1c: mov             fp, SP
    // 0x81fa20: AllocStack(0x10)
    //     0x81fa20: sub             SP, SP, #0x10
    // 0x81fa24: CheckStackOverflow
    //     0x81fa24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81fa28: cmp             SP, x16
    //     0x81fa2c: b.ls            #0x81fb28
    // 0x81fa30: ldr             x0, [fp, #0x10]
    // 0x81fa34: LoadField: r1 = r0->field_f
    //     0x81fa34: ldur            w1, [x0, #0xf]
    // 0x81fa38: DecompressPointer r1
    //     0x81fa38: add             x1, x1, HEAP, lsl #32
    // 0x81fa3c: cmp             w1, NULL
    // 0x81fa40: b.eq            #0x81fb30
    // 0x81fa44: SaveReg r1
    //     0x81fa44: str             x1, [SP, #-8]!
    // 0x81fa48: r0 = getNotifier()
    //     0x81fa48: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x81fa4c: add             SP, SP, #8
    // 0x81fa50: mov             x1, x0
    // 0x81fa54: ldr             x0, [fp, #0x10]
    // 0x81fa58: stur            x1, [fp, #-0x10]
    // 0x81fa5c: LoadField: r2 = r0->field_17
    //     0x81fa5c: ldur            w2, [x0, #0x17]
    // 0x81fa60: DecompressPointer r2
    //     0x81fa60: add             x2, x2, HEAP, lsl #32
    // 0x81fa64: stur            x2, [fp, #-8]
    // 0x81fa68: cmp             w1, w2
    // 0x81fa6c: b.ne            #0x81fa80
    // 0x81fa70: r0 = Null
    //     0x81fa70: mov             x0, NULL
    // 0x81fa74: LeaveFrame
    //     0x81fa74: mov             SP, fp
    //     0x81fa78: ldp             fp, lr, [SP], #0x10
    // 0x81fa7c: ret
    //     0x81fa7c: ret             
    // 0x81fa80: cmp             w2, NULL
    // 0x81fa84: b.eq            #0x81fac0
    // 0x81fa88: r1 = 1
    //     0x81fa88: mov             x1, #1
    // 0x81fa8c: r0 = AllocateContext()
    //     0x81fa8c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x81fa90: mov             x1, x0
    // 0x81fa94: ldr             x0, [fp, #0x10]
    // 0x81fa98: StoreField: r1->field_f = r0
    //     0x81fa98: stur            w0, [x1, #0xf]
    // 0x81fa9c: mov             x2, x1
    // 0x81faa0: r1 = Function '_updateTickers@156311458':.
    //     0x81faa0: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fe68] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x81faa4: ldr             x1, [x1, #0xe68]
    // 0x81faa8: r0 = AllocateClosure()
    //     0x81faa8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x81faac: ldur            x16, [fp, #-8]
    // 0x81fab0: stp             x0, x16, [SP, #-0x10]!
    // 0x81fab4: r0 = removeListener()
    //     0x81fab4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x81fab8: add             SP, SP, #0x10
    // 0x81fabc: ldr             x0, [fp, #0x10]
    // 0x81fac0: r1 = 1
    //     0x81fac0: mov             x1, #1
    // 0x81fac4: r0 = AllocateContext()
    //     0x81fac4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x81fac8: mov             x1, x0
    // 0x81facc: ldr             x0, [fp, #0x10]
    // 0x81fad0: StoreField: r1->field_f = r0
    //     0x81fad0: stur            w0, [x1, #0xf]
    // 0x81fad4: mov             x2, x1
    // 0x81fad8: r1 = Function '_updateTickers@156311458':.
    //     0x81fad8: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fe68] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x81fadc: ldr             x1, [x1, #0xe68]
    // 0x81fae0: r0 = AllocateClosure()
    //     0x81fae0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x81fae4: ldur            x16, [fp, #-0x10]
    // 0x81fae8: stp             x0, x16, [SP, #-0x10]!
    // 0x81faec: r0 = addListener()
    //     0x81faec: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x81faf0: add             SP, SP, #0x10
    // 0x81faf4: ldur            x0, [fp, #-0x10]
    // 0x81faf8: ldr             x1, [fp, #0x10]
    // 0x81fafc: StoreField: r1->field_17 = r0
    //     0x81fafc: stur            w0, [x1, #0x17]
    //     0x81fb00: ldurb           w16, [x1, #-1]
    //     0x81fb04: ldurb           w17, [x0, #-1]
    //     0x81fb08: and             x16, x17, x16, lsr #2
    //     0x81fb0c: tst             x16, HEAP, lsr #32
    //     0x81fb10: b.eq            #0x81fb18
    //     0x81fb14: bl              #0xd6826c
    // 0x81fb18: r0 = Null
    //     0x81fb18: mov             x0, NULL
    // 0x81fb1c: LeaveFrame
    //     0x81fb1c: mov             SP, fp
    //     0x81fb20: ldp             fp, lr, [SP], #0x10
    // 0x81fb24: ret
    //     0x81fb24: ret             
    // 0x81fb28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81fb28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81fb2c: b               #0x81fa30
    // 0x81fb30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x81fb30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b428, size: 0x18
    // 0xa4b428: r4 = 7
    //     0xa4b428: mov             x4, #7
    // 0xa4b42c: r1 = Function 'dispose':.
    //     0xa4b42c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b4b0] AnonymousClosure: (0xa4b440), in [package:flutter/src/material/text_selection_toolbar.dart] __TextSelectionToolbarOverflowableState&State&TickerProviderStateMixin::dispose (0xa53354)
    //     0xa4b430: ldr             x1, [x17, #0x4b0]
    // 0xa4b434: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b434: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b438: LoadField: r0 = r24->field_17
    //     0xa4b438: ldur            x0, [x24, #0x17]
    // 0xa4b43c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b440, size: 0x48
    // 0xa4b440: EnterFrame
    //     0xa4b440: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b444: mov             fp, SP
    // 0xa4b448: ldr             x0, [fp, #0x10]
    // 0xa4b44c: LoadField: r1 = r0->field_17
    //     0xa4b44c: ldur            w1, [x0, #0x17]
    // 0xa4b450: DecompressPointer r1
    //     0xa4b450: add             x1, x1, HEAP, lsl #32
    // 0xa4b454: CheckStackOverflow
    //     0xa4b454: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b458: cmp             SP, x16
    //     0xa4b45c: b.ls            #0xa4b480
    // 0xa4b460: LoadField: r0 = r1->field_f
    //     0xa4b460: ldur            w0, [x1, #0xf]
    // 0xa4b464: DecompressPointer r0
    //     0xa4b464: add             x0, x0, HEAP, lsl #32
    // 0xa4b468: SaveReg r0
    //     0xa4b468: str             x0, [SP, #-8]!
    // 0xa4b46c: r0 = dispose()
    //     0xa4b46c: bl              #0xa53354  ; [package:flutter/src/material/text_selection_toolbar.dart] __TextSelectionToolbarOverflowableState&State&TickerProviderStateMixin::dispose
    // 0xa4b470: add             SP, SP, #8
    // 0xa4b474: LeaveFrame
    //     0xa4b474: mov             SP, fp
    //     0xa4b478: ldp             fp, lr, [SP], #0x10
    // 0xa4b47c: ret
    //     0xa4b47c: ret             
    // 0xa4b480: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b480: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b484: b               #0xa4b460
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa53354, size: 0x8c
    // 0xa53354: EnterFrame
    //     0xa53354: stp             fp, lr, [SP, #-0x10]!
    //     0xa53358: mov             fp, SP
    // 0xa5335c: AllocStack(0x8)
    //     0xa5335c: sub             SP, SP, #8
    // 0xa53360: CheckStackOverflow
    //     0xa53360: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa53364: cmp             SP, x16
    //     0xa53368: b.ls            #0xa533d8
    // 0xa5336c: ldr             x0, [fp, #0x10]
    // 0xa53370: LoadField: r1 = r0->field_17
    //     0xa53370: ldur            w1, [x0, #0x17]
    // 0xa53374: DecompressPointer r1
    //     0xa53374: add             x1, x1, HEAP, lsl #32
    // 0xa53378: stur            x1, [fp, #-8]
    // 0xa5337c: cmp             w1, NULL
    // 0xa53380: b.ne            #0xa5338c
    // 0xa53384: mov             x1, x0
    // 0xa53388: b               #0xa533c4
    // 0xa5338c: r1 = 1
    //     0xa5338c: mov             x1, #1
    // 0xa53390: r0 = AllocateContext()
    //     0xa53390: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa53394: mov             x1, x0
    // 0xa53398: ldr             x0, [fp, #0x10]
    // 0xa5339c: StoreField: r1->field_f = r0
    //     0xa5339c: stur            w0, [x1, #0xf]
    // 0xa533a0: mov             x2, x1
    // 0xa533a4: r1 = Function '_updateTickers@156311458':.
    //     0xa533a4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fe68] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa533a8: ldr             x1, [x1, #0xe68]
    // 0xa533ac: r0 = AllocateClosure()
    //     0xa533ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa533b0: ldur            x16, [fp, #-8]
    // 0xa533b4: stp             x0, x16, [SP, #-0x10]!
    // 0xa533b8: r0 = removeListener()
    //     0xa533b8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa533bc: add             SP, SP, #0x10
    // 0xa533c0: ldr             x1, [fp, #0x10]
    // 0xa533c4: StoreField: r1->field_17 = rNULL
    //     0xa533c4: stur            NULL, [x1, #0x17]
    // 0xa533c8: r0 = Null
    //     0xa533c8: mov             x0, NULL
    // 0xa533cc: LeaveFrame
    //     0xa533cc: mov             SP, fp
    //     0xa533d0: ldp             fp, lr, [SP], #0x10
    // 0xa533d4: ret
    //     0xa533d4: ret             
    // 0xa533d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa533d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa533dc: b               #0xa5336c
  }
}

// class id: 3263, size: 0x24, field offset: 0x1c
class _TextSelectionToolbarOverflowableState extends __TextSelectionToolbarOverflowableState&State&TickerProviderStateMixin {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bf9b0, size: 0x100
    // 0x7bf9b0: EnterFrame
    //     0x7bf9b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf9b4: mov             fp, SP
    // 0x7bf9b8: CheckStackOverflow
    //     0x7bf9b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf9bc: cmp             SP, x16
    //     0x7bf9c0: b.ls            #0x7bfaa4
    // 0x7bf9c4: ldr             x0, [fp, #0x10]
    // 0x7bf9c8: r2 = Null
    //     0x7bf9c8: mov             x2, NULL
    // 0x7bf9cc: r1 = Null
    //     0x7bf9cc: mov             x1, NULL
    // 0x7bf9d0: r4 = 59
    //     0x7bf9d0: mov             x4, #0x3b
    // 0x7bf9d4: branchIfSmi(r0, 0x7bf9e0)
    //     0x7bf9d4: tbz             w0, #0, #0x7bf9e0
    // 0x7bf9d8: r4 = LoadClassIdInstr(r0)
    //     0x7bf9d8: ldur            x4, [x0, #-1]
    //     0x7bf9dc: ubfx            x4, x4, #0xc, #0x14
    // 0x7bf9e0: r17 = 4111
    //     0x7bf9e0: mov             x17, #0x100f
    // 0x7bf9e4: cmp             x4, x17
    // 0x7bf9e8: b.eq            #0x7bfa00
    // 0x7bf9ec: r8 = _TextSelectionToolbarOverflowable
    //     0x7bf9ec: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fea0] Type: _TextSelectionToolbarOverflowable
    //     0x7bf9f0: ldr             x8, [x8, #0xea0]
    // 0x7bf9f4: r3 = Null
    //     0x7bf9f4: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fea8] Null
    //     0x7bf9f8: ldr             x3, [x3, #0xea8]
    // 0x7bf9fc: r0 = _TextSelectionToolbarOverflowable()
    //     0x7bf9fc: bl              #0x7bfaf4  ; IsType__TextSelectionToolbarOverflowable_Stub
    // 0x7bfa00: ldr             x3, [fp, #0x18]
    // 0x7bfa04: LoadField: r2 = r3->field_7
    //     0x7bfa04: ldur            w2, [x3, #7]
    // 0x7bfa08: DecompressPointer r2
    //     0x7bfa08: add             x2, x2, HEAP, lsl #32
    // 0x7bfa0c: ldr             x0, [fp, #0x10]
    // 0x7bfa10: r1 = Null
    //     0x7bfa10: mov             x1, NULL
    // 0x7bfa14: cmp             w2, NULL
    // 0x7bfa18: b.eq            #0x7bfa3c
    // 0x7bfa1c: LoadField: r4 = r2->field_17
    //     0x7bfa1c: ldur            w4, [x2, #0x17]
    // 0x7bfa20: DecompressPointer r4
    //     0x7bfa20: add             x4, x4, HEAP, lsl #32
    // 0x7bfa24: r8 = X0 bound StatefulWidget
    //     0x7bfa24: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bfa28: ldr             x8, [x8, #0x858]
    // 0x7bfa2c: LoadField: r9 = r4->field_7
    //     0x7bfa2c: ldur            x9, [x4, #7]
    // 0x7bfa30: r3 = Null
    //     0x7bfa30: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3feb8] Null
    //     0x7bfa34: ldr             x3, [x3, #0xeb8]
    // 0x7bfa38: blr             x9
    // 0x7bfa3c: ldr             x0, [fp, #0x18]
    // 0x7bfa40: LoadField: r1 = r0->field_b
    //     0x7bfa40: ldur            w1, [x0, #0xb]
    // 0x7bfa44: DecompressPointer r1
    //     0x7bfa44: add             x1, x1, HEAP, lsl #32
    // 0x7bfa48: cmp             w1, NULL
    // 0x7bfa4c: b.eq            #0x7bfaac
    // 0x7bfa50: LoadField: r2 = r1->field_b
    //     0x7bfa50: ldur            w2, [x1, #0xb]
    // 0x7bfa54: DecompressPointer r2
    //     0x7bfa54: add             x2, x2, HEAP, lsl #32
    // 0x7bfa58: ldr             x1, [fp, #0x10]
    // 0x7bfa5c: LoadField: r3 = r1->field_b
    //     0x7bfa5c: ldur            w3, [x1, #0xb]
    // 0x7bfa60: DecompressPointer r3
    //     0x7bfa60: add             x3, x3, HEAP, lsl #32
    // 0x7bfa64: r16 = <Widget>
    //     0x7bfa64: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x7bfa68: ldr             x16, [x16, #0xea8]
    // 0x7bfa6c: stp             x2, x16, [SP, #-0x10]!
    // 0x7bfa70: SaveReg r3
    //     0x7bfa70: str             x3, [SP, #-8]!
    // 0x7bfa74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7bfa74: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7bfa78: r0 = listEquals()
    //     0x7bfa78: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x7bfa7c: add             SP, SP, #0x18
    // 0x7bfa80: tbz             w0, #4, #0x7bfa94
    // 0x7bfa84: ldr             x16, [fp, #0x18]
    // 0x7bfa88: SaveReg r16
    //     0x7bfa88: str             x16, [SP, #-8]!
    // 0x7bfa8c: r0 = _reset()
    //     0x7bfa8c: bl              #0x7bfab0  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarOverflowableState::_reset
    // 0x7bfa90: add             SP, SP, #8
    // 0x7bfa94: r0 = Null
    //     0x7bfa94: mov             x0, NULL
    // 0x7bfa98: LeaveFrame
    //     0x7bfa98: mov             SP, fp
    //     0x7bfa9c: ldp             fp, lr, [SP], #0x10
    // 0x7bfaa0: ret
    //     0x7bfaa0: ret             
    // 0x7bfaa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bfaa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bfaa8: b               #0x7bf9c4
    // 0x7bfaac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bfaac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _reset(/* No info */) {
    // ** addr: 0x7bfab0, size: 0x44
    // 0x7bfab0: EnterFrame
    //     0x7bfab0: stp             fp, lr, [SP, #-0x10]!
    //     0x7bfab4: mov             fp, SP
    // 0x7bfab8: r0 = UniqueKey()
    //     0x7bfab8: bl              #0x594010  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0x7bfabc: ldr             x1, [fp, #0x10]
    // 0x7bfac0: StoreField: r1->field_1f = r0
    //     0x7bfac0: stur            w0, [x1, #0x1f]
    //     0x7bfac4: ldurb           w16, [x1, #-1]
    //     0x7bfac8: ldurb           w17, [x0, #-1]
    //     0x7bfacc: and             x16, x17, x16, lsr #2
    //     0x7bfad0: tst             x16, HEAP, lsr #32
    //     0x7bfad4: b.eq            #0x7bfadc
    //     0x7bfad8: bl              #0xd6826c
    // 0x7bfadc: r2 = false
    //     0x7bfadc: add             x2, NULL, #0x30  ; false
    // 0x7bfae0: StoreField: r1->field_1b = r2
    //     0x7bfae0: stur            w2, [x1, #0x1b]
    // 0x7bfae4: r0 = Null
    //     0x7bfae4: mov             x0, NULL
    // 0x7bfae8: LeaveFrame
    //     0x7bfae8: mov             SP, fp
    //     0x7bfaec: ldp             fp, lr, [SP], #0x10
    // 0x7bfaf0: ret
    //     0x7bfaf0: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0x873ba4, size: 0x268
    // 0x873ba4: EnterFrame
    //     0x873ba4: stp             fp, lr, [SP, #-0x10]!
    //     0x873ba8: mov             fp, SP
    // 0x873bac: AllocStack(0x50)
    //     0x873bac: sub             SP, SP, #0x50
    // 0x873bb0: CheckStackOverflow
    //     0x873bb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x873bb4: cmp             SP, x16
    //     0x873bb8: b.ls            #0x873e00
    // 0x873bbc: r1 = 1
    //     0x873bbc: mov             x1, #1
    // 0x873bc0: r0 = AllocateContext()
    //     0x873bc0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x873bc4: mov             x1, x0
    // 0x873bc8: ldr             x0, [fp, #0x18]
    // 0x873bcc: stur            x1, [fp, #-8]
    // 0x873bd0: StoreField: r1->field_f = r0
    //     0x873bd0: stur            w0, [x1, #0xf]
    // 0x873bd4: ldr             x16, [fp, #0x10]
    // 0x873bd8: SaveReg r16
    //     0x873bd8: str             x16, [SP, #-8]!
    // 0x873bdc: r0 = of()
    //     0x873bdc: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x873be0: add             SP, SP, #8
    // 0x873be4: ldr             x0, [fp, #0x18]
    // 0x873be8: LoadField: r1 = r0->field_1f
    //     0x873be8: ldur            w1, [x0, #0x1f]
    // 0x873bec: DecompressPointer r1
    //     0x873bec: add             x1, x1, HEAP, lsl #32
    // 0x873bf0: stur            x1, [fp, #-0x18]
    // 0x873bf4: LoadField: r2 = r0->field_1b
    //     0x873bf4: ldur            w2, [x0, #0x1b]
    // 0x873bf8: DecompressPointer r2
    //     0x873bf8: add             x2, x2, HEAP, lsl #32
    // 0x873bfc: stur            x2, [fp, #-0x10]
    // 0x873c00: ldr             x16, [fp, #0x10]
    // 0x873c04: SaveReg r16
    //     0x873c04: str             x16, [SP, #-8]!
    // 0x873c08: r0 = of()
    //     0x873c08: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x873c0c: add             SP, SP, #8
    // 0x873c10: mov             x1, x0
    // 0x873c14: ldr             x0, [fp, #0x18]
    // 0x873c18: stur            x1, [fp, #-0x40]
    // 0x873c1c: LoadField: r2 = r0->field_b
    //     0x873c1c: ldur            w2, [x0, #0xb]
    // 0x873c20: DecompressPointer r2
    //     0x873c20: add             x2, x2, HEAP, lsl #32
    // 0x873c24: stur            x2, [fp, #-0x38]
    // 0x873c28: cmp             w2, NULL
    // 0x873c2c: b.eq            #0x873e08
    // 0x873c30: LoadField: r3 = r2->field_f
    //     0x873c30: ldur            w3, [x2, #0xf]
    // 0x873c34: DecompressPointer r3
    //     0x873c34: add             x3, x3, HEAP, lsl #32
    // 0x873c38: stur            x3, [fp, #-0x30]
    // 0x873c3c: LoadField: r4 = r0->field_1b
    //     0x873c3c: ldur            w4, [x0, #0x1b]
    // 0x873c40: DecompressPointer r4
    //     0x873c40: add             x4, x4, HEAP, lsl #32
    // 0x873c44: stur            x4, [fp, #-0x28]
    // 0x873c48: tbnz            w4, #4, #0x873c58
    // 0x873c4c: r0 = Instance_IconData
    //     0x873c4c: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fe70] Obj!IconData@b33c71
    //     0x873c50: ldr             x0, [x0, #0xe70]
    // 0x873c54: b               #0x873c60
    // 0x873c58: r0 = Instance_IconData
    //     0x873c58: add             x0, PP, #0x31, lsl #12  ; [pp+0x31b50] Obj!IconData@b33c91
    //     0x873c5c: ldr             x0, [x0, #0xb50]
    // 0x873c60: stur            x0, [fp, #-0x20]
    // 0x873c64: r0 = Icon()
    //     0x873c64: bl              #0x825370  ; AllocateIconStub -> Icon (size=0x34)
    // 0x873c68: mov             x1, x0
    // 0x873c6c: ldur            x0, [fp, #-0x20]
    // 0x873c70: stur            x1, [fp, #-0x48]
    // 0x873c74: StoreField: r1->field_b = r0
    //     0x873c74: stur            w0, [x1, #0xb]
    // 0x873c78: ldur            x0, [fp, #-0x28]
    // 0x873c7c: tbnz            w0, #4, #0x873c8c
    // 0x873c80: r7 = "Back"
    //     0x873c80: add             x7, PP, #0x3f, lsl #12  ; [pp+0x3fe78] "Back"
    //     0x873c84: ldr             x7, [x7, #0xe78]
    // 0x873c88: b               #0x873c94
    // 0x873c8c: r7 = "More"
    //     0x873c8c: add             x7, PP, #0x3f, lsl #12  ; [pp+0x3fe80] "More"
    //     0x873c90: ldr             x7, [x7, #0xe80]
    // 0x873c94: ldur            x5, [fp, #-0x18]
    // 0x873c98: ldur            x6, [fp, #-0x10]
    // 0x873c9c: ldur            x2, [fp, #-0x40]
    // 0x873ca0: ldur            x4, [fp, #-0x30]
    // 0x873ca4: ldur            x3, [fp, #-0x38]
    // 0x873ca8: stur            x7, [fp, #-0x20]
    // 0x873cac: r0 = _TextSelectionToolbarOverflowButton()
    //     0x873cac: bl              #0x873e30  ; Allocate_TextSelectionToolbarOverflowButtonStub -> _TextSelectionToolbarOverflowButton (size=0x18)
    // 0x873cb0: mov             x3, x0
    // 0x873cb4: ldur            x0, [fp, #-0x48]
    // 0x873cb8: stur            x3, [fp, #-0x50]
    // 0x873cbc: StoreField: r3->field_b = r0
    //     0x873cbc: stur            w0, [x3, #0xb]
    // 0x873cc0: ldur            x2, [fp, #-8]
    // 0x873cc4: r1 = Function '<anonymous closure>':.
    //     0x873cc4: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fe88] AnonymousClosure: (0x873e3c), in [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarOverflowableState::build (0x873ba4)
    //     0x873cc8: ldr             x1, [x1, #0xe88]
    // 0x873ccc: r0 = AllocateClosure()
    //     0x873ccc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x873cd0: mov             x1, x0
    // 0x873cd4: ldur            x0, [fp, #-0x50]
    // 0x873cd8: StoreField: r0->field_f = r1
    //     0x873cd8: stur            w1, [x0, #0xf]
    // 0x873cdc: ldur            x1, [fp, #-0x20]
    // 0x873ce0: StoreField: r0->field_13 = r1
    //     0x873ce0: stur            w1, [x0, #0x13]
    // 0x873ce4: r1 = Null
    //     0x873ce4: mov             x1, NULL
    // 0x873ce8: r2 = 2
    //     0x873ce8: mov             x2, #2
    // 0x873cec: r0 = AllocateArray()
    //     0x873cec: bl              #0xd6987c  ; AllocateArrayStub
    // 0x873cf0: mov             x2, x0
    // 0x873cf4: ldur            x0, [fp, #-0x50]
    // 0x873cf8: stur            x2, [fp, #-8]
    // 0x873cfc: StoreField: r2->field_f = r0
    //     0x873cfc: stur            w0, [x2, #0xf]
    // 0x873d00: r1 = <Widget>
    //     0x873d00: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x873d04: ldr             x1, [x1, #0xea8]
    // 0x873d08: r0 = AllocateGrowableArray()
    //     0x873d08: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x873d0c: mov             x1, x0
    // 0x873d10: ldur            x0, [fp, #-8]
    // 0x873d14: stur            x1, [fp, #-0x20]
    // 0x873d18: StoreField: r1->field_f = r0
    //     0x873d18: stur            w0, [x1, #0xf]
    // 0x873d1c: r0 = 2
    //     0x873d1c: mov             x0, #2
    // 0x873d20: StoreField: r1->field_b = r0
    //     0x873d20: stur            w0, [x1, #0xb]
    // 0x873d24: ldur            x0, [fp, #-0x38]
    // 0x873d28: LoadField: r2 = r0->field_b
    //     0x873d28: ldur            w2, [x0, #0xb]
    // 0x873d2c: DecompressPointer r2
    //     0x873d2c: add             x2, x2, HEAP, lsl #32
    // 0x873d30: stp             x2, x1, [SP, #-0x10]!
    // 0x873d34: r0 = addAll()
    //     0x873d34: bl              #0x609364  ; [dart:core] _GrowableList::addAll
    // 0x873d38: add             SP, SP, #0x10
    // 0x873d3c: r0 = _TextSelectionToolbarItemsLayout()
    //     0x873d3c: bl              #0x873e24  ; Allocate_TextSelectionToolbarItemsLayoutStub -> _TextSelectionToolbarItemsLayout (size=0x18)
    // 0x873d40: mov             x1, x0
    // 0x873d44: ldur            x0, [fp, #-0x30]
    // 0x873d48: StoreField: r1->field_f = r0
    //     0x873d48: stur            w0, [x1, #0xf]
    // 0x873d4c: ldur            x0, [fp, #-0x28]
    // 0x873d50: StoreField: r1->field_13 = r0
    //     0x873d50: stur            w0, [x1, #0x13]
    // 0x873d54: ldur            x0, [fp, #-0x20]
    // 0x873d58: StoreField: r1->field_b = r0
    //     0x873d58: stur            w0, [x1, #0xb]
    // 0x873d5c: ldur            x0, [fp, #-0x38]
    // 0x873d60: LoadField: r2 = r0->field_13
    //     0x873d60: ldur            w2, [x0, #0x13]
    // 0x873d64: DecompressPointer r2
    //     0x873d64: add             x2, x2, HEAP, lsl #32
    // 0x873d68: ldr             x16, [fp, #0x10]
    // 0x873d6c: stp             x16, x2, [SP, #-0x10]!
    // 0x873d70: SaveReg r1
    //     0x873d70: str             x1, [SP, #-8]!
    // 0x873d74: mov             x0, x2
    // 0x873d78: ClosureCall
    //     0x873d78: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x873d7c: ldur            x2, [x0, #0x1f]
    //     0x873d80: blr             x2
    // 0x873d84: add             SP, SP, #0x18
    // 0x873d88: stur            x0, [fp, #-8]
    // 0x873d8c: r0 = AnimatedSize()
    //     0x873d8c: bl              #0x873e18  ; AllocateAnimatedSizeStub -> AnimatedSize (size=0x24)
    // 0x873d90: mov             x1, x0
    // 0x873d94: ldur            x0, [fp, #-8]
    // 0x873d98: stur            x1, [fp, #-0x20]
    // 0x873d9c: StoreField: r1->field_b = r0
    //     0x873d9c: stur            w0, [x1, #0xb]
    // 0x873da0: r0 = Instance_Alignment
    //     0x873da0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0x873da4: ldr             x0, [x0, #0xc70]
    // 0x873da8: StoreField: r1->field_f = r0
    //     0x873da8: stur            w0, [x1, #0xf]
    // 0x873dac: r0 = Instance__Linear
    //     0x873dac: add             x0, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x873db0: ldr             x0, [x0, #0x300]
    // 0x873db4: StoreField: r1->field_13 = r0
    //     0x873db4: stur            w0, [x1, #0x13]
    // 0x873db8: r0 = Instance_Duration
    //     0x873db8: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fe90] Obj!Duration@b67be1
    //     0x873dbc: ldr             x0, [x0, #0xe90]
    // 0x873dc0: StoreField: r1->field_17 = r0
    //     0x873dc0: stur            w0, [x1, #0x17]
    // 0x873dc4: r0 = Instance_Clip
    //     0x873dc4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x873dc8: ldr             x0, [x0, #0x678]
    // 0x873dcc: StoreField: r1->field_1f = r0
    //     0x873dcc: stur            w0, [x1, #0x1f]
    // 0x873dd0: r0 = _TextSelectionToolbarTrailingEdgeAlign()
    //     0x873dd0: bl              #0x873e0c  ; Allocate_TextSelectionToolbarTrailingEdgeAlignStub -> _TextSelectionToolbarTrailingEdgeAlign (size=0x18)
    // 0x873dd4: ldur            x1, [fp, #-0x10]
    // 0x873dd8: StoreField: r0->field_f = r1
    //     0x873dd8: stur            w1, [x0, #0xf]
    // 0x873ddc: ldur            x1, [fp, #-0x40]
    // 0x873de0: StoreField: r0->field_13 = r1
    //     0x873de0: stur            w1, [x0, #0x13]
    // 0x873de4: ldur            x1, [fp, #-0x20]
    // 0x873de8: StoreField: r0->field_b = r1
    //     0x873de8: stur            w1, [x0, #0xb]
    // 0x873dec: ldur            x1, [fp, #-0x18]
    // 0x873df0: StoreField: r0->field_7 = r1
    //     0x873df0: stur            w1, [x0, #7]
    // 0x873df4: LeaveFrame
    //     0x873df4: mov             SP, fp
    //     0x873df8: ldp             fp, lr, [SP], #0x10
    // 0x873dfc: ret
    //     0x873dfc: ret             
    // 0x873e00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873e00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873e04: b               #0x873bbc
    // 0x873e08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x873e08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x873e3c, size: 0x64
    // 0x873e3c: EnterFrame
    //     0x873e3c: stp             fp, lr, [SP, #-0x10]!
    //     0x873e40: mov             fp, SP
    // 0x873e44: AllocStack(0x8)
    //     0x873e44: sub             SP, SP, #8
    // 0x873e48: SetupParameters()
    //     0x873e48: ldr             x0, [fp, #0x10]
    //     0x873e4c: ldur            w2, [x0, #0x17]
    //     0x873e50: add             x2, x2, HEAP, lsl #32
    // 0x873e54: CheckStackOverflow
    //     0x873e54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x873e58: cmp             SP, x16
    //     0x873e5c: b.ls            #0x873e98
    // 0x873e60: LoadField: r0 = r2->field_f
    //     0x873e60: ldur            w0, [x2, #0xf]
    // 0x873e64: DecompressPointer r0
    //     0x873e64: add             x0, x0, HEAP, lsl #32
    // 0x873e68: stur            x0, [fp, #-8]
    // 0x873e6c: r1 = Function '<anonymous closure>':.
    //     0x873e6c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fe98] AnonymousClosure: (0x873ea0), in [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarOverflowableState::build (0x873ba4)
    //     0x873e70: ldr             x1, [x1, #0xe98]
    // 0x873e74: r0 = AllocateClosure()
    //     0x873e74: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x873e78: ldur            x16, [fp, #-8]
    // 0x873e7c: stp             x0, x16, [SP, #-0x10]!
    // 0x873e80: r0 = setState()
    //     0x873e80: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x873e84: add             SP, SP, #0x10
    // 0x873e88: r0 = Null
    //     0x873e88: mov             x0, NULL
    // 0x873e8c: LeaveFrame
    //     0x873e8c: mov             SP, fp
    //     0x873e90: ldp             fp, lr, [SP], #0x10
    // 0x873e94: ret
    //     0x873e94: ret             
    // 0x873e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873e98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873e9c: b               #0x873e60
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x873ea0, size: 0x2c
    // 0x873ea0: ldr             x1, [SP]
    // 0x873ea4: LoadField: r2 = r1->field_17
    //     0x873ea4: ldur            w2, [x1, #0x17]
    // 0x873ea8: DecompressPointer r2
    //     0x873ea8: add             x2, x2, HEAP, lsl #32
    // 0x873eac: LoadField: r1 = r2->field_f
    //     0x873eac: ldur            w1, [x2, #0xf]
    // 0x873eb0: DecompressPointer r1
    //     0x873eb0: add             x1, x1, HEAP, lsl #32
    // 0x873eb4: LoadField: r2 = r1->field_1b
    //     0x873eb4: ldur            w2, [x1, #0x1b]
    // 0x873eb8: DecompressPointer r2
    //     0x873eb8: add             x2, x2, HEAP, lsl #32
    // 0x873ebc: eor             x3, x2, #0x10
    // 0x873ec0: StoreField: r1->field_1b = r3
    //     0x873ec0: stur            w3, [x1, #0x1b]
    // 0x873ec4: r0 = Null
    //     0x873ec4: mov             x0, NULL
    // 0x873ec8: ret
    //     0x873ec8: ret             
  }
}

// class id: 3470, size: 0x4c, field offset: 0x4c
class _TextSelectionToolbarItemsLayoutElement extends MultiChildRenderObjectElement {
}

// class id: 3583, size: 0x18, field offset: 0x10
class _TextSelectionToolbarItemsLayout extends MultiChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6e023c, size: 0x9c
    // 0x6e023c: EnterFrame
    //     0x6e023c: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0240: mov             fp, SP
    // 0x6e0244: CheckStackOverflow
    //     0x6e0244: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0248: cmp             SP, x16
    //     0x6e024c: b.ls            #0x6e02d0
    // 0x6e0250: ldr             x0, [fp, #0x10]
    // 0x6e0254: r2 = Null
    //     0x6e0254: mov             x2, NULL
    // 0x6e0258: r1 = Null
    //     0x6e0258: mov             x1, NULL
    // 0x6e025c: r4 = 59
    //     0x6e025c: mov             x4, #0x3b
    // 0x6e0260: branchIfSmi(r0, 0x6e026c)
    //     0x6e0260: tbz             w0, #0, #0x6e026c
    // 0x6e0264: r4 = LoadClassIdInstr(r0)
    //     0x6e0264: ldur            x4, [x0, #-1]
    //     0x6e0268: ubfx            x4, x4, #0xc, #0x14
    // 0x6e026c: cmp             x4, #0x992
    // 0x6e0270: b.eq            #0x6e0288
    // 0x6e0274: r8 = _RenderTextSelectionToolbarItemsLayout
    //     0x6e0274: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b4b8] Type: _RenderTextSelectionToolbarItemsLayout
    //     0x6e0278: ldr             x8, [x8, #0x4b8]
    // 0x6e027c: r3 = Null
    //     0x6e027c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b4c0] Null
    //     0x6e0280: ldr             x3, [x3, #0x4c0]
    // 0x6e0284: r0 = DefaultTypeTest()
    //     0x6e0284: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6e0288: ldr             x0, [fp, #0x20]
    // 0x6e028c: LoadField: r1 = r0->field_f
    //     0x6e028c: ldur            w1, [x0, #0xf]
    // 0x6e0290: DecompressPointer r1
    //     0x6e0290: add             x1, x1, HEAP, lsl #32
    // 0x6e0294: ldr             x16, [fp, #0x10]
    // 0x6e0298: stp             x1, x16, [SP, #-0x10]!
    // 0x6e029c: r0 = isAbove=()
    //     0x6e029c: bl              #0x6e033c  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::isAbove=
    // 0x6e02a0: add             SP, SP, #0x10
    // 0x6e02a4: ldr             x0, [fp, #0x20]
    // 0x6e02a8: LoadField: r1 = r0->field_13
    //     0x6e02a8: ldur            w1, [x0, #0x13]
    // 0x6e02ac: DecompressPointer r1
    //     0x6e02ac: add             x1, x1, HEAP, lsl #32
    // 0x6e02b0: ldr             x16, [fp, #0x10]
    // 0x6e02b4: stp             x1, x16, [SP, #-0x10]!
    // 0x6e02b8: r0 = overflowOpen=()
    //     0x6e02b8: bl              #0x6e02d8  ; [package:flutter/src/material/text_selection_toolbar.dart] _RenderTextSelectionToolbarItemsLayout::overflowOpen=
    // 0x6e02bc: add             SP, SP, #0x10
    // 0x6e02c0: r0 = Null
    //     0x6e02c0: mov             x0, NULL
    // 0x6e02c4: LeaveFrame
    //     0x6e02c4: mov             SP, fp
    //     0x6e02c8: ldp             fp, lr, [SP], #0x10
    // 0x6e02cc: ret
    //     0x6e02cc: ret             
    // 0x6e02d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e02d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e02d4: b               #0x6e0250
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6f36ec, size: 0x84
    // 0x6f36ec: EnterFrame
    //     0x6f36ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6f36f0: mov             fp, SP
    // 0x6f36f4: AllocStack(0x18)
    //     0x6f36f4: sub             SP, SP, #0x18
    // 0x6f36f8: CheckStackOverflow
    //     0x6f36f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f36fc: cmp             SP, x16
    //     0x6f3700: b.ls            #0x6f3768
    // 0x6f3704: ldr             x0, [fp, #0x18]
    // 0x6f3708: LoadField: r1 = r0->field_f
    //     0x6f3708: ldur            w1, [x0, #0xf]
    // 0x6f370c: DecompressPointer r1
    //     0x6f370c: add             x1, x1, HEAP, lsl #32
    // 0x6f3710: stur            x1, [fp, #-0x10]
    // 0x6f3714: LoadField: r2 = r0->field_13
    //     0x6f3714: ldur            w2, [x0, #0x13]
    // 0x6f3718: DecompressPointer r2
    //     0x6f3718: add             x2, x2, HEAP, lsl #32
    // 0x6f371c: stur            x2, [fp, #-8]
    // 0x6f3720: r0 = _RenderTextSelectionToolbarItemsLayout()
    //     0x6f3720: bl              #0x6f3770  ; Allocate_RenderTextSelectionToolbarItemsLayoutStub -> _RenderTextSelectionToolbarItemsLayout (size=0x80)
    // 0x6f3724: mov             x1, x0
    // 0x6f3728: r0 = -1
    //     0x6f3728: mov             x0, #-1
    // 0x6f372c: stur            x1, [fp, #-0x18]
    // 0x6f3730: StoreField: r1->field_6f = r0
    //     0x6f3730: stur            x0, [x1, #0x6f]
    // 0x6f3734: ldur            x0, [fp, #-0x10]
    // 0x6f3738: StoreField: r1->field_77 = r0
    //     0x6f3738: stur            w0, [x1, #0x77]
    // 0x6f373c: ldur            x0, [fp, #-8]
    // 0x6f3740: StoreField: r1->field_7b = r0
    //     0x6f3740: stur            w0, [x1, #0x7b]
    // 0x6f3744: r0 = 0
    //     0x6f3744: mov             x0, #0
    // 0x6f3748: StoreField: r1->field_5f = r0
    //     0x6f3748: stur            x0, [x1, #0x5f]
    // 0x6f374c: SaveReg r1
    //     0x6f374c: str             x1, [SP, #-8]!
    // 0x6f3750: r0 = RenderObject()
    //     0x6f3750: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f3754: add             SP, SP, #8
    // 0x6f3758: ldur            x0, [fp, #-0x18]
    // 0x6f375c: LeaveFrame
    //     0x6f375c: mov             SP, fp
    //     0x6f3760: ldp             fp, lr, [SP], #0x10
    // 0x6f3764: ret
    //     0x6f3764: ret             
    // 0x6f3768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f3768: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f376c: b               #0x6f3704
  }
  _ createElement(/* No info */) {
    // ** addr: 0xa76d74, size: 0x48
    // 0xa76d74: EnterFrame
    //     0xa76d74: stp             fp, lr, [SP, #-0x10]!
    //     0xa76d78: mov             fp, SP
    // 0xa76d7c: AllocStack(0x8)
    //     0xa76d7c: sub             SP, SP, #8
    // 0xa76d80: CheckStackOverflow
    //     0xa76d80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa76d84: cmp             SP, x16
    //     0xa76d88: b.ls            #0xa76db4
    // 0xa76d8c: r0 = _TextSelectionToolbarItemsLayoutElement()
    //     0xa76d8c: bl              #0xa76e70  ; Allocate_TextSelectionToolbarItemsLayoutElementStub -> _TextSelectionToolbarItemsLayoutElement (size=0x4c)
    // 0xa76d90: stur            x0, [fp, #-8]
    // 0xa76d94: ldr             x16, [fp, #0x10]
    // 0xa76d98: stp             x16, x0, [SP, #-0x10]!
    // 0xa76d9c: r0 = MultiChildRenderObjectElement()
    //     0xa76d9c: bl              #0xa76dbc  ; [package:flutter/src/widgets/framework.dart] MultiChildRenderObjectElement::MultiChildRenderObjectElement
    // 0xa76da0: add             SP, SP, #0x10
    // 0xa76da4: ldur            x0, [fp, #-8]
    // 0xa76da8: LeaveFrame
    //     0xa76da8: mov             SP, fp
    //     0xa76dac: ldp             fp, lr, [SP], #0x10
    // 0xa76db0: ret
    //     0xa76db0: ret             
    // 0xa76db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa76db4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa76db8: b               #0xa76d8c
  }
}

// class id: 3671, size: 0x18, field offset: 0x10
//   const constructor, 
class _TextSelectionToolbarTrailingEdgeAlign extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c2990, size: 0x9c
    // 0x6c2990: EnterFrame
    //     0x6c2990: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2994: mov             fp, SP
    // 0x6c2998: CheckStackOverflow
    //     0x6c2998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c299c: cmp             SP, x16
    //     0x6c29a0: b.ls            #0x6c2a24
    // 0x6c29a4: ldr             x0, [fp, #0x10]
    // 0x6c29a8: r2 = Null
    //     0x6c29a8: mov             x2, NULL
    // 0x6c29ac: r1 = Null
    //     0x6c29ac: mov             x1, NULL
    // 0x6c29b0: r4 = 59
    //     0x6c29b0: mov             x4, #0x3b
    // 0x6c29b4: branchIfSmi(r0, 0x6c29c0)
    //     0x6c29b4: tbz             w0, #0, #0x6c29c0
    // 0x6c29b8: r4 = LoadClassIdInstr(r0)
    //     0x6c29b8: ldur            x4, [x0, #-1]
    //     0x6c29bc: ubfx            x4, x4, #0xc, #0x14
    // 0x6c29c0: cmp             x4, #0x9da
    // 0x6c29c4: b.eq            #0x6c29dc
    // 0x6c29c8: r8 = _TextSelectionToolbarTrailingEdgeAlignRenderBox
    //     0x6c29c8: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b4d0] Type: _TextSelectionToolbarTrailingEdgeAlignRenderBox
    //     0x6c29cc: ldr             x8, [x8, #0x4d0]
    // 0x6c29d0: r3 = Null
    //     0x6c29d0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b4d8] Null
    //     0x6c29d4: ldr             x3, [x3, #0x4d8]
    // 0x6c29d8: r0 = DefaultTypeTest()
    //     0x6c29d8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c29dc: ldr             x0, [fp, #0x20]
    // 0x6c29e0: LoadField: r1 = r0->field_f
    //     0x6c29e0: ldur            w1, [x0, #0xf]
    // 0x6c29e4: DecompressPointer r1
    //     0x6c29e4: add             x1, x1, HEAP, lsl #32
    // 0x6c29e8: ldr             x16, [fp, #0x10]
    // 0x6c29ec: stp             x1, x16, [SP, #-0x10]!
    // 0x6c29f0: r0 = overflowOpen=()
    //     0x6c29f0: bl              #0x6c2aac  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarTrailingEdgeAlignRenderBox::overflowOpen=
    // 0x6c29f4: add             SP, SP, #0x10
    // 0x6c29f8: ldr             x0, [fp, #0x20]
    // 0x6c29fc: LoadField: r1 = r0->field_13
    //     0x6c29fc: ldur            w1, [x0, #0x13]
    // 0x6c2a00: DecompressPointer r1
    //     0x6c2a00: add             x1, x1, HEAP, lsl #32
    // 0x6c2a04: ldr             x16, [fp, #0x10]
    // 0x6c2a08: stp             x1, x16, [SP, #-0x10]!
    // 0x6c2a0c: r0 = textDirection=()
    //     0x6c2a0c: bl              #0x6c2a2c  ; [package:flutter/src/material/text_selection_toolbar.dart] _TextSelectionToolbarTrailingEdgeAlignRenderBox::textDirection=
    // 0x6c2a10: add             SP, SP, #0x10
    // 0x6c2a14: r0 = Null
    //     0x6c2a14: mov             x0, NULL
    // 0x6c2a18: LeaveFrame
    //     0x6c2a18: mov             SP, fp
    //     0x6c2a1c: ldp             fp, lr, [SP], #0x10
    // 0x6c2a20: ret
    //     0x6c2a20: ret             
    // 0x6c2a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2a24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c2a28: b               #0x6c29a4
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ea3cc, size: 0x84
    // 0x6ea3cc: EnterFrame
    //     0x6ea3cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea3d0: mov             fp, SP
    // 0x6ea3d4: AllocStack(0x18)
    //     0x6ea3d4: sub             SP, SP, #0x18
    // 0x6ea3d8: CheckStackOverflow
    //     0x6ea3d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea3dc: cmp             SP, x16
    //     0x6ea3e0: b.ls            #0x6ea448
    // 0x6ea3e4: ldr             x0, [fp, #0x18]
    // 0x6ea3e8: LoadField: r1 = r0->field_f
    //     0x6ea3e8: ldur            w1, [x0, #0xf]
    // 0x6ea3ec: DecompressPointer r1
    //     0x6ea3ec: add             x1, x1, HEAP, lsl #32
    // 0x6ea3f0: stur            x1, [fp, #-0x10]
    // 0x6ea3f4: LoadField: r2 = r0->field_13
    //     0x6ea3f4: ldur            w2, [x0, #0x13]
    // 0x6ea3f8: DecompressPointer r2
    //     0x6ea3f8: add             x2, x2, HEAP, lsl #32
    // 0x6ea3fc: stur            x2, [fp, #-8]
    // 0x6ea400: r0 = _TextSelectionToolbarTrailingEdgeAlignRenderBox()
    //     0x6ea400: bl              #0x6ea450  ; Allocate_TextSelectionToolbarTrailingEdgeAlignRenderBoxStub -> _TextSelectionToolbarTrailingEdgeAlignRenderBox (size=0x70)
    // 0x6ea404: mov             x1, x0
    // 0x6ea408: ldur            x0, [fp, #-8]
    // 0x6ea40c: stur            x1, [fp, #-0x18]
    // 0x6ea410: StoreField: r1->field_6b = r0
    //     0x6ea410: stur            w0, [x1, #0x6b]
    // 0x6ea414: ldur            x0, [fp, #-0x10]
    // 0x6ea418: StoreField: r1->field_67 = r0
    //     0x6ea418: stur            w0, [x1, #0x67]
    // 0x6ea41c: SaveReg r1
    //     0x6ea41c: str             x1, [SP, #-8]!
    // 0x6ea420: r0 = RenderObject()
    //     0x6ea420: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea424: add             SP, SP, #8
    // 0x6ea428: ldur            x16, [fp, #-0x18]
    // 0x6ea42c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea430: r0 = child=()
    //     0x6ea430: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea434: add             SP, SP, #0x10
    // 0x6ea438: ldur            x0, [fp, #-0x18]
    // 0x6ea43c: LeaveFrame
    //     0x6ea43c: mov             SP, fp
    //     0x6ea440: ldp             fp, lr, [SP], #0x10
    // 0x6ea444: ret
    //     0x6ea444: ret             
    // 0x6ea448: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea448: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea44c: b               #0x6ea3e4
  }
}

// class id: 3839, size: 0x18, field offset: 0xc
//   const constructor, 
class _TextSelectionToolbarOverflowButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb24664, size: 0xb8
    // 0xb24664: EnterFrame
    //     0xb24664: stp             fp, lr, [SP, #-0x10]!
    //     0xb24668: mov             fp, SP
    // 0xb2466c: AllocStack(0x20)
    //     0xb2466c: sub             SP, SP, #0x20
    // 0xb24670: ldr             x0, [fp, #0x18]
    // 0xb24674: LoadField: r1 = r0->field_b
    //     0xb24674: ldur            w1, [x0, #0xb]
    // 0xb24678: DecompressPointer r1
    //     0xb24678: add             x1, x1, HEAP, lsl #32
    // 0xb2467c: stur            x1, [fp, #-0x18]
    // 0xb24680: LoadField: r2 = r0->field_f
    //     0xb24680: ldur            w2, [x0, #0xf]
    // 0xb24684: DecompressPointer r2
    //     0xb24684: add             x2, x2, HEAP, lsl #32
    // 0xb24688: stur            x2, [fp, #-0x10]
    // 0xb2468c: LoadField: r3 = r0->field_13
    //     0xb2468c: ldur            w3, [x0, #0x13]
    // 0xb24690: DecompressPointer r3
    //     0xb24690: add             x3, x3, HEAP, lsl #32
    // 0xb24694: stur            x3, [fp, #-8]
    // 0xb24698: r0 = IconButton()
    //     0xb24698: bl              #0x825364  ; AllocateIconButtonStub -> IconButton (size=0x64)
    // 0xb2469c: mov             x1, x0
    // 0xb246a0: ldur            x0, [fp, #-0x10]
    // 0xb246a4: stur            x1, [fp, #-0x20]
    // 0xb246a8: StoreField: r1->field_3b = r0
    //     0xb246a8: stur            w0, [x1, #0x3b]
    // 0xb246ac: r0 = false
    //     0xb246ac: add             x0, NULL, #0x30  ; false
    // 0xb246b0: StoreField: r1->field_47 = r0
    //     0xb246b0: stur            w0, [x1, #0x47]
    // 0xb246b4: ldur            x0, [fp, #-8]
    // 0xb246b8: StoreField: r1->field_4b = r0
    //     0xb246b8: stur            w0, [x1, #0x4b]
    // 0xb246bc: ldur            x0, [fp, #-0x18]
    // 0xb246c0: StoreField: r1->field_1f = r0
    //     0xb246c0: stur            w0, [x1, #0x1f]
    // 0xb246c4: r0 = Material()
    //     0xb246c4: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0xb246c8: r1 = Instance_MaterialType
    //     0xb246c8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc10] Obj!MaterialType@b65591
    //     0xb246cc: ldr             x1, [x1, #0xc10]
    // 0xb246d0: StoreField: r0->field_f = r1
    //     0xb246d0: stur            w1, [x0, #0xf]
    // 0xb246d4: d0 = 0.000000
    //     0xb246d4: eor             v0.16b, v0.16b, v0.16b
    // 0xb246d8: StoreField: r0->field_13 = d0
    //     0xb246d8: stur            d0, [x0, #0x13]
    // 0xb246dc: r1 = Instance_Color
    //     0xb246dc: add             x1, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0xb246e0: ldr             x1, [x1, #0xc08]
    // 0xb246e4: StoreField: r0->field_1b = r1
    //     0xb246e4: stur            w1, [x0, #0x1b]
    // 0xb246e8: r1 = true
    //     0xb246e8: add             x1, NULL, #0x20  ; true
    // 0xb246ec: StoreField: r0->field_2f = r1
    //     0xb246ec: stur            w1, [x0, #0x2f]
    // 0xb246f0: r1 = Instance_Clip
    //     0xb246f0: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb246f4: ldr             x1, [x1, #0xb38]
    // 0xb246f8: StoreField: r0->field_33 = r1
    //     0xb246f8: stur            w1, [x0, #0x33]
    // 0xb246fc: r1 = Instance_Duration
    //     0xb246fc: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb24700: ldr             x1, [x1, #0x9e0]
    // 0xb24704: StoreField: r0->field_37 = r1
    //     0xb24704: stur            w1, [x0, #0x37]
    // 0xb24708: ldur            x1, [fp, #-0x20]
    // 0xb2470c: StoreField: r0->field_b = r1
    //     0xb2470c: stur            w1, [x0, #0xb]
    // 0xb24710: LeaveFrame
    //     0xb24710: mov             SP, fp
    //     0xb24714: ldp             fp, lr, [SP], #0x10
    // 0xb24718: ret
    //     0xb24718: ret             
  }
}

// class id: 3840, size: 0x10, field offset: 0xc
//   const constructor, 
class _TextSelectionToolbarContainer extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb245f0, size: 0x74
    // 0xb245f0: EnterFrame
    //     0xb245f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb245f4: mov             fp, SP
    // 0xb245f8: AllocStack(0x8)
    //     0xb245f8: sub             SP, SP, #8
    // 0xb245fc: ldr             x0, [fp, #0x18]
    // 0xb24600: LoadField: r1 = r0->field_b
    //     0xb24600: ldur            w1, [x0, #0xb]
    // 0xb24604: DecompressPointer r1
    //     0xb24604: add             x1, x1, HEAP, lsl #32
    // 0xb24608: stur            x1, [fp, #-8]
    // 0xb2460c: r0 = Material()
    //     0xb2460c: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0xb24610: r1 = Instance_MaterialType
    //     0xb24610: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc10] Obj!MaterialType@b65591
    //     0xb24614: ldr             x1, [x1, #0xc10]
    // 0xb24618: StoreField: r0->field_f = r1
    //     0xb24618: stur            w1, [x0, #0xf]
    // 0xb2461c: d0 = 1.000000
    //     0xb2461c: fmov            d0, #1.00000000
    // 0xb24620: StoreField: r0->field_13 = d0
    //     0xb24620: stur            d0, [x0, #0x13]
    // 0xb24624: r1 = Instance_BorderRadius
    //     0xb24624: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dc18] Obj!BorderRadius@b37871
    //     0xb24628: ldr             x1, [x1, #0xc18]
    // 0xb2462c: StoreField: r0->field_3b = r1
    //     0xb2462c: stur            w1, [x0, #0x3b]
    // 0xb24630: r1 = true
    //     0xb24630: add             x1, NULL, #0x20  ; true
    // 0xb24634: StoreField: r0->field_2f = r1
    //     0xb24634: stur            w1, [x0, #0x2f]
    // 0xb24638: r1 = Instance_Clip
    //     0xb24638: add             x1, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0xb2463c: ldr             x1, [x1, #0xad0]
    // 0xb24640: StoreField: r0->field_33 = r1
    //     0xb24640: stur            w1, [x0, #0x33]
    // 0xb24644: r1 = Instance_Duration
    //     0xb24644: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb24648: ldr             x1, [x1, #0x9e0]
    // 0xb2464c: StoreField: r0->field_37 = r1
    //     0xb2464c: stur            w1, [x0, #0x37]
    // 0xb24650: ldur            x1, [fp, #-8]
    // 0xb24654: StoreField: r0->field_b = r1
    //     0xb24654: stur            w1, [x0, #0xb]
    // 0xb24658: LeaveFrame
    //     0xb24658: mov             SP, fp
    //     0xb2465c: ldp             fp, lr, [SP], #0x10
    // 0xb24660: ret
    //     0xb24660: ret             
  }
}

// class id: 3841, size: 0x1c, field offset: 0xc
//   const constructor, 
class TextSelectionToolbar extends StatelessWidget {

  [closure] static Widget _defaultToolbarBuilder(dynamic, BuildContext, Widget) {
    // ** addr: 0x873b3c, size: 0x3c
    // 0x873b3c: EnterFrame
    //     0x873b3c: stp             fp, lr, [SP, #-0x10]!
    //     0x873b40: mov             fp, SP
    // 0x873b44: CheckStackOverflow
    //     0x873b44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x873b48: cmp             SP, x16
    //     0x873b4c: b.ls            #0x873b70
    // 0x873b50: ldr             x16, [fp, #0x18]
    // 0x873b54: ldr             lr, [fp, #0x10]
    // 0x873b58: stp             lr, x16, [SP, #-0x10]!
    // 0x873b5c: r0 = _defaultToolbarBuilder()
    //     0x873b5c: bl              #0x873b78  ; [package:flutter/src/material/text_selection_toolbar.dart] TextSelectionToolbar::_defaultToolbarBuilder
    // 0x873b60: add             SP, SP, #0x10
    // 0x873b64: LeaveFrame
    //     0x873b64: mov             SP, fp
    //     0x873b68: ldp             fp, lr, [SP], #0x10
    // 0x873b6c: ret
    //     0x873b6c: ret             
    // 0x873b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873b70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873b74: b               #0x873b50
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0x873b78, size: 0x20
    // 0x873b78: EnterFrame
    //     0x873b78: stp             fp, lr, [SP, #-0x10]!
    //     0x873b7c: mov             fp, SP
    // 0x873b80: r0 = _TextSelectionToolbarContainer()
    //     0x873b80: bl              #0x873b98  ; Allocate_TextSelectionToolbarContainerStub -> _TextSelectionToolbarContainer (size=0x10)
    // 0x873b84: ldr             x1, [fp, #0x10]
    // 0x873b88: StoreField: r0->field_b = r1
    //     0x873b88: stur            w1, [x0, #0xb]
    // 0x873b8c: LeaveFrame
    //     0x873b8c: mov             SP, fp
    //     0x873b90: ldp             fp, lr, [SP], #0x10
    // 0x873b94: ret
    //     0x873b94: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xb24414, size: 0x1d0
    // 0xb24414: EnterFrame
    //     0xb24414: stp             fp, lr, [SP, #-0x10]!
    //     0xb24418: mov             fp, SP
    // 0xb2441c: AllocStack(0x38)
    //     0xb2441c: sub             SP, SP, #0x38
    // 0xb24420: CheckStackOverflow
    //     0xb24420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb24424: cmp             SP, x16
    //     0xb24428: b.ls            #0xb245dc
    // 0xb2442c: ldr             x0, [fp, #0x18]
    // 0xb24430: LoadField: r1 = r0->field_b
    //     0xb24430: ldur            w1, [x0, #0xb]
    // 0xb24434: DecompressPointer r1
    //     0xb24434: add             x1, x1, HEAP, lsl #32
    // 0xb24438: r16 = Instance_Offset
    //     0xb24438: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dc20] Obj!Offset@b5f2f1
    //     0xb2443c: ldr             x16, [x16, #0xc20]
    // 0xb24440: stp             x16, x1, [SP, #-0x10]!
    // 0xb24444: r0 = -()
    //     0xb24444: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xb24448: add             SP, SP, #0x10
    // 0xb2444c: mov             x1, x0
    // 0xb24450: ldr             x0, [fp, #0x18]
    // 0xb24454: stur            x1, [fp, #-8]
    // 0xb24458: LoadField: r2 = r0->field_f
    //     0xb24458: ldur            w2, [x0, #0xf]
    // 0xb2445c: DecompressPointer r2
    //     0xb2445c: add             x2, x2, HEAP, lsl #32
    // 0xb24460: r16 = Instance_Offset
    //     0xb24460: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dc28] Obj!Offset@b5f2d1
    //     0xb24464: ldr             x16, [x16, #0xc28]
    // 0xb24468: stp             x16, x2, [SP, #-0x10]!
    // 0xb2446c: r0 = +()
    //     0xb2446c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xb24470: add             SP, SP, #0x10
    // 0xb24474: stur            x0, [fp, #-0x10]
    // 0xb24478: ldr             x16, [fp, #0x10]
    // 0xb2447c: SaveReg r16
    //     0xb2447c: str             x16, [SP, #-8]!
    // 0xb24480: r0 = of()
    //     0xb24480: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb24484: add             SP, SP, #8
    // 0xb24488: LoadField: r1 = r0->field_23
    //     0xb24488: ldur            w1, [x0, #0x23]
    // 0xb2448c: DecompressPointer r1
    //     0xb2448c: add             x1, x1, HEAP, lsl #32
    // 0xb24490: LoadField: d0 = r1->field_f
    //     0xb24490: ldur            d0, [x1, #0xf]
    // 0xb24494: d1 = 8.000000
    //     0xb24494: fmov            d1, #8.00000000
    // 0xb24498: fadd            d2, d0, d1
    // 0xb2449c: ldur            x0, [fp, #-8]
    // 0xb244a0: stur            d2, [fp, #-0x38]
    // 0xb244a4: LoadField: d0 = r0->field_f
    //     0xb244a4: ldur            d0, [x0, #0xf]
    // 0xb244a8: fsub            d3, d0, d1
    // 0xb244ac: fsub            d0, d3, d2
    // 0xb244b0: d3 = 44.000000
    //     0xb244b0: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dc30] IMM: double(44) from 0x4046000000000000
    //     0xb244b4: ldr             d3, [x17, #0xc30]
    // 0xb244b8: fcmp            d3, d0
    // 0xb244bc: b.vs            #0xb244c4
    // 0xb244c0: b.le            #0xb244cc
    // 0xb244c4: r1 = false
    //     0xb244c4: add             x1, NULL, #0x30  ; false
    // 0xb244c8: b               #0xb244d0
    // 0xb244cc: r1 = true
    //     0xb244cc: add             x1, NULL, #0x20  ; true
    // 0xb244d0: stur            x1, [fp, #-0x18]
    // 0xb244d4: r0 = Offset()
    //     0xb244d4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb244d8: d0 = 8.000000
    //     0xb244d8: fmov            d0, #8.00000000
    // 0xb244dc: stur            x0, [fp, #-0x20]
    // 0xb244e0: StoreField: r0->field_7 = d0
    //     0xb244e0: stur            d0, [x0, #7]
    // 0xb244e4: ldur            d1, [fp, #-0x38]
    // 0xb244e8: StoreField: r0->field_f = d1
    //     0xb244e8: stur            d1, [x0, #0xf]
    // 0xb244ec: r0 = EdgeInsets()
    //     0xb244ec: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb244f0: d0 = 8.000000
    //     0xb244f0: fmov            d0, #8.00000000
    // 0xb244f4: stur            x0, [fp, #-0x28]
    // 0xb244f8: StoreField: r0->field_7 = d0
    //     0xb244f8: stur            d0, [x0, #7]
    // 0xb244fc: ldur            d1, [fp, #-0x38]
    // 0xb24500: StoreField: r0->field_f = d1
    //     0xb24500: stur            d1, [x0, #0xf]
    // 0xb24504: StoreField: r0->field_17 = d0
    //     0xb24504: stur            d0, [x0, #0x17]
    // 0xb24508: StoreField: r0->field_1f = d0
    //     0xb24508: stur            d0, [x0, #0x1f]
    // 0xb2450c: ldur            x16, [fp, #-8]
    // 0xb24510: ldur            lr, [fp, #-0x20]
    // 0xb24514: stp             lr, x16, [SP, #-0x10]!
    // 0xb24518: r0 = -()
    //     0xb24518: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xb2451c: add             SP, SP, #0x10
    // 0xb24520: stur            x0, [fp, #-8]
    // 0xb24524: ldur            x16, [fp, #-0x10]
    // 0xb24528: ldur            lr, [fp, #-0x20]
    // 0xb2452c: stp             lr, x16, [SP, #-0x10]!
    // 0xb24530: r0 = -()
    //     0xb24530: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xb24534: add             SP, SP, #0x10
    // 0xb24538: stur            x0, [fp, #-0x10]
    // 0xb2453c: r0 = TextSelectionToolbarLayoutDelegate()
    //     0xb2453c: bl              #0xb1d558  ; AllocateTextSelectionToolbarLayoutDelegateStub -> TextSelectionToolbarLayoutDelegate (size=0x18)
    // 0xb24540: mov             x1, x0
    // 0xb24544: ldur            x0, [fp, #-8]
    // 0xb24548: stur            x1, [fp, #-0x20]
    // 0xb2454c: StoreField: r1->field_b = r0
    //     0xb2454c: stur            w0, [x1, #0xb]
    // 0xb24550: ldur            x0, [fp, #-0x10]
    // 0xb24554: StoreField: r1->field_f = r0
    //     0xb24554: stur            w0, [x1, #0xf]
    // 0xb24558: ldur            x0, [fp, #-0x18]
    // 0xb2455c: StoreField: r1->field_13 = r0
    //     0xb2455c: stur            w0, [x1, #0x13]
    // 0xb24560: ldr             x2, [fp, #0x18]
    // 0xb24564: LoadField: r3 = r2->field_17
    //     0xb24564: ldur            w3, [x2, #0x17]
    // 0xb24568: DecompressPointer r3
    //     0xb24568: add             x3, x3, HEAP, lsl #32
    // 0xb2456c: stur            x3, [fp, #-0x10]
    // 0xb24570: LoadField: r4 = r2->field_13
    //     0xb24570: ldur            w4, [x2, #0x13]
    // 0xb24574: DecompressPointer r4
    //     0xb24574: add             x4, x4, HEAP, lsl #32
    // 0xb24578: stur            x4, [fp, #-8]
    // 0xb2457c: r0 = _TextSelectionToolbarOverflowable()
    //     0xb2457c: bl              #0xb245e4  ; Allocate_TextSelectionToolbarOverflowableStub -> _TextSelectionToolbarOverflowable (size=0x18)
    // 0xb24580: mov             x1, x0
    // 0xb24584: ldur            x0, [fp, #-0x18]
    // 0xb24588: stur            x1, [fp, #-0x30]
    // 0xb2458c: StoreField: r1->field_f = r0
    //     0xb2458c: stur            w0, [x1, #0xf]
    // 0xb24590: ldur            x0, [fp, #-0x10]
    // 0xb24594: StoreField: r1->field_13 = r0
    //     0xb24594: stur            w0, [x1, #0x13]
    // 0xb24598: ldur            x0, [fp, #-8]
    // 0xb2459c: StoreField: r1->field_b = r0
    //     0xb2459c: stur            w0, [x1, #0xb]
    // 0xb245a0: r0 = CustomSingleChildLayout()
    //     0xb245a0: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xb245a4: mov             x1, x0
    // 0xb245a8: ldur            x0, [fp, #-0x20]
    // 0xb245ac: stur            x1, [fp, #-8]
    // 0xb245b0: StoreField: r1->field_f = r0
    //     0xb245b0: stur            w0, [x1, #0xf]
    // 0xb245b4: ldur            x0, [fp, #-0x30]
    // 0xb245b8: StoreField: r1->field_b = r0
    //     0xb245b8: stur            w0, [x1, #0xb]
    // 0xb245bc: r0 = Padding()
    //     0xb245bc: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb245c0: ldur            x1, [fp, #-0x28]
    // 0xb245c4: StoreField: r0->field_f = r1
    //     0xb245c4: stur            w1, [x0, #0xf]
    // 0xb245c8: ldur            x1, [fp, #-8]
    // 0xb245cc: StoreField: r0->field_b = r1
    //     0xb245cc: stur            w1, [x0, #0xb]
    // 0xb245d0: LeaveFrame
    //     0xb245d0: mov             SP, fp
    //     0xb245d4: ldp             fp, lr, [SP], #0x10
    // 0xb245d8: ret
    //     0xb245d8: ret             
    // 0xb245dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb245dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb245e0: b               #0xb2442c
  }
}

// class id: 4111, size: 0x18, field offset: 0xc
//   const constructor, 
class _TextSelectionToolbarOverflowable extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa41a64, size: 0x44
    // 0xa41a64: EnterFrame
    //     0xa41a64: stp             fp, lr, [SP, #-0x10]!
    //     0xa41a68: mov             fp, SP
    // 0xa41a6c: AllocStack(0x8)
    //     0xa41a6c: sub             SP, SP, #8
    // 0xa41a70: r1 = <_TextSelectionToolbarOverflowable>
    //     0xa41a70: add             x1, PP, #0x37, lsl #12  ; [pp+0x372b0] TypeArguments: <_TextSelectionToolbarOverflowable>
    //     0xa41a74: ldr             x1, [x1, #0x2b0]
    // 0xa41a78: r0 = _TextSelectionToolbarOverflowableState()
    //     0xa41a78: bl              #0xa41aa8  ; Allocate_TextSelectionToolbarOverflowableStateStub -> _TextSelectionToolbarOverflowableState (size=0x24)
    // 0xa41a7c: mov             x1, x0
    // 0xa41a80: r0 = false
    //     0xa41a80: add             x0, NULL, #0x30  ; false
    // 0xa41a84: stur            x1, [fp, #-8]
    // 0xa41a88: StoreField: r1->field_1b = r0
    //     0xa41a88: stur            w0, [x1, #0x1b]
    // 0xa41a8c: r0 = UniqueKey()
    //     0xa41a8c: bl              #0x594010  ; AllocateUniqueKeyStub -> UniqueKey (size=0x8)
    // 0xa41a90: mov             x1, x0
    // 0xa41a94: ldur            x0, [fp, #-8]
    // 0xa41a98: StoreField: r0->field_1f = r1
    //     0xa41a98: stur            w1, [x0, #0x1f]
    // 0xa41a9c: LeaveFrame
    //     0xa41a9c: mov             SP, fp
    //     0xa41aa0: ldp             fp, lr, [SP], #0x10
    // 0xa41aa4: ret
    //     0xa41aa4: ret             
  }
}

// lib: , url: package:flutter/src/material/toggleable.dart

// class id: 1049337, size: 0x8
class :: {
}

// class id: 3422, size: 0x14, field offset: 0x14
abstract class ToggleableStateMixin<X0 bound StatefulWidget> extends TickerProviderStateMixin<X0 bound StatefulWidget> {
}

// class id: 4834, size: 0x5c, field offset: 0x24
abstract class ToggleablePainter extends ChangeNotifier
    implements CustomPainter {

  set _ inactiveColor=(/* No info */) {
    // ** addr: 0x8500c4, size: 0xa0
    // 0x8500c4: EnterFrame
    //     0x8500c4: stp             fp, lr, [SP, #-0x10]!
    //     0x8500c8: mov             fp, SP
    // 0x8500cc: CheckStackOverflow
    //     0x8500cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8500d0: cmp             SP, x16
    //     0x8500d4: b.ls            #0x85015c
    // 0x8500d8: ldr             x1, [fp, #0x18]
    // 0x8500dc: LoadField: r0 = r1->field_37
    //     0x8500dc: ldur            w0, [x1, #0x37]
    // 0x8500e0: DecompressPointer r0
    //     0x8500e0: add             x0, x0, HEAP, lsl #32
    // 0x8500e4: r2 = LoadClassIdInstr(r0)
    //     0x8500e4: ldur            x2, [x0, #-1]
    //     0x8500e8: ubfx            x2, x2, #0xc, #0x14
    // 0x8500ec: ldr             x16, [fp, #0x10]
    // 0x8500f0: stp             x16, x0, [SP, #-0x10]!
    // 0x8500f4: mov             x0, x2
    // 0x8500f8: mov             lr, x0
    // 0x8500fc: ldr             lr, [x21, lr, lsl #3]
    // 0x850100: blr             lr
    // 0x850104: add             SP, SP, #0x10
    // 0x850108: tbnz            w0, #4, #0x85011c
    // 0x85010c: r0 = Null
    //     0x85010c: mov             x0, NULL
    // 0x850110: LeaveFrame
    //     0x850110: mov             SP, fp
    //     0x850114: ldp             fp, lr, [SP], #0x10
    // 0x850118: ret
    //     0x850118: ret             
    // 0x85011c: ldr             x1, [fp, #0x18]
    // 0x850120: ldr             x0, [fp, #0x10]
    // 0x850124: StoreField: r1->field_37 = r0
    //     0x850124: stur            w0, [x1, #0x37]
    //     0x850128: ldurb           w16, [x1, #-1]
    //     0x85012c: ldurb           w17, [x0, #-1]
    //     0x850130: and             x16, x17, x16, lsr #2
    //     0x850134: tst             x16, HEAP, lsr #32
    //     0x850138: b.eq            #0x850140
    //     0x85013c: bl              #0xd6826c
    // 0x850140: SaveReg r1
    //     0x850140: str             x1, [SP, #-8]!
    // 0x850144: r0 = notifyListeners()
    //     0x850144: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850148: add             SP, SP, #8
    // 0x85014c: r0 = Null
    //     0x85014c: mov             x0, NULL
    // 0x850150: LeaveFrame
    //     0x850150: mov             SP, fp
    //     0x850154: ldp             fp, lr, [SP], #0x10
    // 0x850158: ret
    //     0x850158: ret             
    // 0x85015c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85015c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850160: b               #0x8500d8
  }
  set _ activeColor=(/* No info */) {
    // ** addr: 0x850164, size: 0xa0
    // 0x850164: EnterFrame
    //     0x850164: stp             fp, lr, [SP, #-0x10]!
    //     0x850168: mov             fp, SP
    // 0x85016c: CheckStackOverflow
    //     0x85016c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850170: cmp             SP, x16
    //     0x850174: b.ls            #0x8501fc
    // 0x850178: ldr             x1, [fp, #0x18]
    // 0x85017c: LoadField: r0 = r1->field_33
    //     0x85017c: ldur            w0, [x1, #0x33]
    // 0x850180: DecompressPointer r0
    //     0x850180: add             x0, x0, HEAP, lsl #32
    // 0x850184: r2 = LoadClassIdInstr(r0)
    //     0x850184: ldur            x2, [x0, #-1]
    //     0x850188: ubfx            x2, x2, #0xc, #0x14
    // 0x85018c: ldr             x16, [fp, #0x10]
    // 0x850190: stp             x16, x0, [SP, #-0x10]!
    // 0x850194: mov             x0, x2
    // 0x850198: mov             lr, x0
    // 0x85019c: ldr             lr, [x21, lr, lsl #3]
    // 0x8501a0: blr             lr
    // 0x8501a4: add             SP, SP, #0x10
    // 0x8501a8: tbnz            w0, #4, #0x8501bc
    // 0x8501ac: r0 = Null
    //     0x8501ac: mov             x0, NULL
    // 0x8501b0: LeaveFrame
    //     0x8501b0: mov             SP, fp
    //     0x8501b4: ldp             fp, lr, [SP], #0x10
    // 0x8501b8: ret
    //     0x8501b8: ret             
    // 0x8501bc: ldr             x1, [fp, #0x18]
    // 0x8501c0: ldr             x0, [fp, #0x10]
    // 0x8501c4: StoreField: r1->field_33 = r0
    //     0x8501c4: stur            w0, [x1, #0x33]
    //     0x8501c8: ldurb           w16, [x1, #-1]
    //     0x8501cc: ldurb           w17, [x0, #-1]
    //     0x8501d0: and             x16, x17, x16, lsr #2
    //     0x8501d4: tst             x16, HEAP, lsr #32
    //     0x8501d8: b.eq            #0x8501e0
    //     0x8501dc: bl              #0xd6826c
    // 0x8501e0: SaveReg r1
    //     0x8501e0: str             x1, [SP, #-8]!
    // 0x8501e4: r0 = notifyListeners()
    //     0x8501e4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8501e8: add             SP, SP, #8
    // 0x8501ec: r0 = Null
    //     0x8501ec: mov             x0, NULL
    // 0x8501f0: LeaveFrame
    //     0x8501f0: mov             SP, fp
    //     0x8501f4: ldp             fp, lr, [SP], #0x10
    // 0x8501f8: ret
    //     0x8501f8: ret             
    // 0x8501fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8501fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850200: b               #0x850178
  }
  set _ isHovered=(/* No info */) {
    // ** addr: 0x850204, size: 0x64
    // 0x850204: EnterFrame
    //     0x850204: stp             fp, lr, [SP, #-0x10]!
    //     0x850208: mov             fp, SP
    // 0x85020c: CheckStackOverflow
    //     0x85020c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850210: cmp             SP, x16
    //     0x850214: b.ls            #0x850260
    // 0x850218: ldr             x0, [fp, #0x18]
    // 0x85021c: LoadField: r1 = r0->field_57
    //     0x85021c: ldur            w1, [x0, #0x57]
    // 0x850220: DecompressPointer r1
    //     0x850220: add             x1, x1, HEAP, lsl #32
    // 0x850224: ldr             x2, [fp, #0x10]
    // 0x850228: cmp             w2, w1
    // 0x85022c: b.ne            #0x850240
    // 0x850230: r0 = Null
    //     0x850230: mov             x0, NULL
    // 0x850234: LeaveFrame
    //     0x850234: mov             SP, fp
    //     0x850238: ldp             fp, lr, [SP], #0x10
    // 0x85023c: ret
    //     0x85023c: ret             
    // 0x850240: StoreField: r0->field_57 = r2
    //     0x850240: stur            w2, [x0, #0x57]
    // 0x850244: SaveReg r0
    //     0x850244: str             x0, [SP, #-8]!
    // 0x850248: r0 = notifyListeners()
    //     0x850248: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x85024c: add             SP, SP, #8
    // 0x850250: r0 = Null
    //     0x850250: mov             x0, NULL
    // 0x850254: LeaveFrame
    //     0x850254: mov             SP, fp
    //     0x850258: ldp             fp, lr, [SP], #0x10
    // 0x85025c: ret
    //     0x85025c: ret             
    // 0x850260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850260: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850264: b               #0x850218
  }
  set _ isFocused=(/* No info */) {
    // ** addr: 0x850268, size: 0x64
    // 0x850268: EnterFrame
    //     0x850268: stp             fp, lr, [SP, #-0x10]!
    //     0x85026c: mov             fp, SP
    // 0x850270: CheckStackOverflow
    //     0x850270: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850274: cmp             SP, x16
    //     0x850278: b.ls            #0x8502c4
    // 0x85027c: ldr             x0, [fp, #0x18]
    // 0x850280: LoadField: r1 = r0->field_53
    //     0x850280: ldur            w1, [x0, #0x53]
    // 0x850284: DecompressPointer r1
    //     0x850284: add             x1, x1, HEAP, lsl #32
    // 0x850288: ldr             x2, [fp, #0x10]
    // 0x85028c: cmp             w2, w1
    // 0x850290: b.ne            #0x8502a4
    // 0x850294: r0 = Null
    //     0x850294: mov             x0, NULL
    // 0x850298: LeaveFrame
    //     0x850298: mov             SP, fp
    //     0x85029c: ldp             fp, lr, [SP], #0x10
    // 0x8502a0: ret
    //     0x8502a0: ret             
    // 0x8502a4: StoreField: r0->field_53 = r2
    //     0x8502a4: stur            w2, [x0, #0x53]
    // 0x8502a8: SaveReg r0
    //     0x8502a8: str             x0, [SP, #-8]!
    // 0x8502ac: r0 = notifyListeners()
    //     0x8502ac: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8502b0: add             SP, SP, #8
    // 0x8502b4: r0 = Null
    //     0x8502b4: mov             x0, NULL
    // 0x8502b8: LeaveFrame
    //     0x8502b8: mov             SP, fp
    //     0x8502bc: ldp             fp, lr, [SP], #0x10
    // 0x8502c0: ret
    //     0x8502c0: ret             
    // 0x8502c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8502c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8502c8: b               #0x85027c
  }
  set _ downPosition=(/* No info */) {
    // ** addr: 0x8502cc, size: 0xa0
    // 0x8502cc: EnterFrame
    //     0x8502cc: stp             fp, lr, [SP, #-0x10]!
    //     0x8502d0: mov             fp, SP
    // 0x8502d4: CheckStackOverflow
    //     0x8502d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8502d8: cmp             SP, x16
    //     0x8502dc: b.ls            #0x850364
    // 0x8502e0: ldr             x1, [fp, #0x18]
    // 0x8502e4: LoadField: r0 = r1->field_4f
    //     0x8502e4: ldur            w0, [x1, #0x4f]
    // 0x8502e8: DecompressPointer r0
    //     0x8502e8: add             x0, x0, HEAP, lsl #32
    // 0x8502ec: ldr             x2, [fp, #0x10]
    // 0x8502f0: r3 = LoadClassIdInstr(r2)
    //     0x8502f0: ldur            x3, [x2, #-1]
    //     0x8502f4: ubfx            x3, x3, #0xc, #0x14
    // 0x8502f8: stp             x0, x2, [SP, #-0x10]!
    // 0x8502fc: mov             x0, x3
    // 0x850300: mov             lr, x0
    // 0x850304: ldr             lr, [x21, lr, lsl #3]
    // 0x850308: blr             lr
    // 0x85030c: add             SP, SP, #0x10
    // 0x850310: tbnz            w0, #4, #0x850324
    // 0x850314: r0 = Null
    //     0x850314: mov             x0, NULL
    // 0x850318: LeaveFrame
    //     0x850318: mov             SP, fp
    //     0x85031c: ldp             fp, lr, [SP], #0x10
    // 0x850320: ret
    //     0x850320: ret             
    // 0x850324: ldr             x1, [fp, #0x18]
    // 0x850328: ldr             x0, [fp, #0x10]
    // 0x85032c: StoreField: r1->field_4f = r0
    //     0x85032c: stur            w0, [x1, #0x4f]
    //     0x850330: ldurb           w16, [x1, #-1]
    //     0x850334: ldurb           w17, [x0, #-1]
    //     0x850338: and             x16, x17, x16, lsr #2
    //     0x85033c: tst             x16, HEAP, lsr #32
    //     0x850340: b.eq            #0x850348
    //     0x850344: bl              #0xd6826c
    // 0x850348: SaveReg r1
    //     0x850348: str             x1, [SP, #-8]!
    // 0x85034c: r0 = notifyListeners()
    //     0x85034c: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850350: add             SP, SP, #8
    // 0x850354: r0 = Null
    //     0x850354: mov             x0, NULL
    // 0x850358: LeaveFrame
    //     0x850358: mov             SP, fp
    //     0x85035c: ldp             fp, lr, [SP], #0x10
    // 0x850360: ret
    //     0x850360: ret             
    // 0x850364: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850364: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850368: b               #0x8502e0
  }
  set _ splashRadius=(/* No info */) {
    // ** addr: 0x85036c, size: 0xd8
    // 0x85036c: EnterFrame
    //     0x85036c: stp             fp, lr, [SP, #-0x10]!
    //     0x850370: mov             fp, SP
    // 0x850374: AllocStack(0x8)
    //     0x850374: sub             SP, SP, #8
    // 0x850378: CheckStackOverflow
    //     0x850378: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85037c: cmp             SP, x16
    //     0x850380: b.ls            #0x850420
    // 0x850384: ldr             x0, [fp, #0x18]
    // 0x850388: LoadField: r1 = r0->field_4b
    //     0x850388: ldur            w1, [x0, #0x4b]
    // 0x85038c: DecompressPointer r1
    //     0x85038c: add             x1, x1, HEAP, lsl #32
    // 0x850390: ldr             d0, [fp, #0x10]
    // 0x850394: r2 = inline_Allocate_Double()
    //     0x850394: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x850398: add             x2, x2, #0x10
    //     0x85039c: cmp             x3, x2
    //     0x8503a0: b.ls            #0x850428
    //     0x8503a4: str             x2, [THR, #0x60]  ; THR::top
    //     0x8503a8: sub             x2, x2, #0xf
    //     0x8503ac: mov             x3, #0xd108
    //     0x8503b0: movk            x3, #3, lsl #16
    //     0x8503b4: stur            x3, [x2, #-1]
    // 0x8503b8: StoreField: r2->field_7 = d0
    //     0x8503b8: stur            d0, [x2, #7]
    // 0x8503bc: stur            x2, [fp, #-8]
    // 0x8503c0: stp             x1, x2, [SP, #-0x10]!
    // 0x8503c4: r0 = ==()
    //     0x8503c4: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x8503c8: add             SP, SP, #0x10
    // 0x8503cc: tbnz            w0, #4, #0x8503e0
    // 0x8503d0: r0 = Null
    //     0x8503d0: mov             x0, NULL
    // 0x8503d4: LeaveFrame
    //     0x8503d4: mov             SP, fp
    //     0x8503d8: ldp             fp, lr, [SP], #0x10
    // 0x8503dc: ret
    //     0x8503dc: ret             
    // 0x8503e0: ldr             x1, [fp, #0x18]
    // 0x8503e4: ldur            x0, [fp, #-8]
    // 0x8503e8: StoreField: r1->field_4b = r0
    //     0x8503e8: stur            w0, [x1, #0x4b]
    //     0x8503ec: ldurb           w16, [x1, #-1]
    //     0x8503f0: ldurb           w17, [x0, #-1]
    //     0x8503f4: and             x16, x17, x16, lsr #2
    //     0x8503f8: tst             x16, HEAP, lsr #32
    //     0x8503fc: b.eq            #0x850404
    //     0x850400: bl              #0xd6826c
    // 0x850404: SaveReg r1
    //     0x850404: str             x1, [SP, #-8]!
    // 0x850408: r0 = notifyListeners()
    //     0x850408: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x85040c: add             SP, SP, #8
    // 0x850410: r0 = Null
    //     0x850410: mov             x0, NULL
    // 0x850414: LeaveFrame
    //     0x850414: mov             SP, fp
    //     0x850418: ldp             fp, lr, [SP], #0x10
    // 0x85041c: ret
    //     0x85041c: ret             
    // 0x850420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850420: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850424: b               #0x850384
    // 0x850428: SaveReg d0
    //     0x850428: str             q0, [SP, #-0x10]!
    // 0x85042c: stp             x0, x1, [SP, #-0x10]!
    // 0x850430: r0 = AllocateDouble()
    //     0x850430: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x850434: mov             x2, x0
    // 0x850438: ldp             x0, x1, [SP], #0x10
    // 0x85043c: RestoreReg d0
    //     0x85043c: ldr             q0, [SP], #0x10
    // 0x850440: b               #0x8503b8
  }
  set _ focusColor=(/* No info */) {
    // ** addr: 0x850444, size: 0x1ec
    // 0x850444: EnterFrame
    //     0x850444: stp             fp, lr, [SP, #-0x10]!
    //     0x850448: mov             fp, SP
    // 0x85044c: AllocStack(0x10)
    //     0x85044c: sub             SP, SP, #0x10
    // 0x850450: CheckStackOverflow
    //     0x850450: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850454: cmp             SP, x16
    //     0x850458: b.ls            #0x850628
    // 0x85045c: ldr             x0, [fp, #0x18]
    // 0x850460: LoadField: r1 = r0->field_47
    //     0x850460: ldur            w1, [x0, #0x47]
    // 0x850464: DecompressPointer r1
    //     0x850464: add             x1, x1, HEAP, lsl #32
    // 0x850468: ldr             x2, [fp, #0x10]
    // 0x85046c: stur            x1, [fp, #-0x10]
    // 0x850470: r3 = LoadClassIdInstr(r2)
    //     0x850470: ldur            x3, [x2, #-1]
    //     0x850474: ubfx            x3, x3, #0xc, #0x14
    // 0x850478: lsl             x3, x3, #1
    // 0x85047c: stur            x3, [fp, #-8]
    // 0x850480: r17 = 10114
    //     0x850480: mov             x17, #0x2782
    // 0x850484: cmp             w3, w17
    // 0x850488: b.eq            #0x850498
    // 0x85048c: r17 = 10118
    //     0x85048c: mov             x17, #0x2786
    // 0x850490: cmp             w3, w17
    // 0x850494: b.ne            #0x8505b0
    // 0x850498: cmp             w1, NULL
    // 0x85049c: b.ne            #0x8504a8
    // 0x8504a0: mov             x1, x0
    // 0x8504a4: b               #0x8505ec
    // 0x8504a8: cmp             w2, w1
    // 0x8504ac: b.eq            #0x8505d8
    // 0x8504b0: stp             x2, x1, [SP, #-0x10]!
    // 0x8504b4: r0 = _haveSameRuntimeType()
    //     0x8504b4: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x8504b8: add             SP, SP, #0x10
    // 0x8504bc: tbz             w0, #4, #0x8504c8
    // 0x8504c0: ldr             x1, [fp, #0x18]
    // 0x8504c4: b               #0x8505ec
    // 0x8504c8: ldur            x0, [fp, #-0x10]
    // 0x8504cc: r1 = LoadClassIdInstr(r0)
    //     0x8504cc: ldur            x1, [x0, #-1]
    //     0x8504d0: ubfx            x1, x1, #0xc, #0x14
    // 0x8504d4: lsl             x1, x1, #1
    // 0x8504d8: r2 = LoadInt32Instr(r1)
    //     0x8504d8: sbfx            x2, x1, #1, #0x1f
    // 0x8504dc: r17 = 5057
    //     0x8504dc: mov             x17, #0x13c1
    // 0x8504e0: cmp             x2, x17
    // 0x8504e4: b.lt            #0x8505a4
    // 0x8504e8: r17 = 5064
    //     0x8504e8: mov             x17, #0x13c8
    // 0x8504ec: cmp             x2, x17
    // 0x8504f0: b.gt            #0x85059c
    // 0x8504f4: r17 = 10124
    //     0x8504f4: mov             x17, #0x278c
    // 0x8504f8: cmp             w1, w17
    // 0x8504fc: b.gt            #0x85050c
    // 0x850500: r17 = 10122
    //     0x850500: mov             x17, #0x278a
    // 0x850504: cmp             w1, w17
    // 0x850508: b.ge            #0x850524
    // 0x85050c: r17 = 10114
    //     0x85050c: mov             x17, #0x2782
    // 0x850510: cmp             w1, w17
    // 0x850514: b.eq            #0x850524
    // 0x850518: r17 = 10118
    //     0x850518: mov             x17, #0x2786
    // 0x85051c: cmp             w1, w17
    // 0x850520: b.ne            #0x85052c
    // 0x850524: LoadField: r1 = r0->field_7
    //     0x850524: ldur            x1, [x0, #7]
    // 0x850528: b               #0x85053c
    // 0x85052c: LoadField: r1 = r0->field_f
    //     0x85052c: ldur            w1, [x0, #0xf]
    // 0x850530: DecompressPointer r1
    //     0x850530: add             x1, x1, HEAP, lsl #32
    // 0x850534: LoadField: r0 = r1->field_7
    //     0x850534: ldur            x0, [x1, #7]
    // 0x850538: mov             x1, x0
    // 0x85053c: ldur            x0, [fp, #-8]
    // 0x850540: r17 = 10124
    //     0x850540: mov             x17, #0x278c
    // 0x850544: cmp             w0, w17
    // 0x850548: b.gt            #0x850558
    // 0x85054c: r17 = 10122
    //     0x85054c: mov             x17, #0x278a
    // 0x850550: cmp             w0, w17
    // 0x850554: b.ge            #0x850570
    // 0x850558: r17 = 10114
    //     0x850558: mov             x17, #0x2782
    // 0x85055c: cmp             w0, w17
    // 0x850560: b.eq            #0x850570
    // 0x850564: r17 = 10118
    //     0x850564: mov             x17, #0x2786
    // 0x850568: cmp             w0, w17
    // 0x85056c: b.ne            #0x85057c
    // 0x850570: ldr             x2, [fp, #0x10]
    // 0x850574: LoadField: r0 = r2->field_7
    //     0x850574: ldur            x0, [x2, #7]
    // 0x850578: b               #0x850590
    // 0x85057c: ldr             x2, [fp, #0x10]
    // 0x850580: LoadField: r0 = r2->field_f
    //     0x850580: ldur            w0, [x2, #0xf]
    // 0x850584: DecompressPointer r0
    //     0x850584: add             x0, x0, HEAP, lsl #32
    // 0x850588: LoadField: r3 = r0->field_7
    //     0x850588: ldur            x3, [x0, #7]
    // 0x85058c: mov             x0, x3
    // 0x850590: cmp             x1, x0
    // 0x850594: b.ne            #0x8505a8
    // 0x850598: b               #0x8505d8
    // 0x85059c: ldr             x2, [fp, #0x10]
    // 0x8505a0: b               #0x8505a8
    // 0x8505a4: ldr             x2, [fp, #0x10]
    // 0x8505a8: ldr             x1, [fp, #0x18]
    // 0x8505ac: b               #0x8505ec
    // 0x8505b0: mov             x0, x1
    // 0x8505b4: r1 = LoadClassIdInstr(r2)
    //     0x8505b4: ldur            x1, [x2, #-1]
    //     0x8505b8: ubfx            x1, x1, #0xc, #0x14
    // 0x8505bc: stp             x0, x2, [SP, #-0x10]!
    // 0x8505c0: mov             x0, x1
    // 0x8505c4: mov             lr, x0
    // 0x8505c8: ldr             lr, [x21, lr, lsl #3]
    // 0x8505cc: blr             lr
    // 0x8505d0: add             SP, SP, #0x10
    // 0x8505d4: tbnz            w0, #4, #0x8505e8
    // 0x8505d8: r0 = Null
    //     0x8505d8: mov             x0, NULL
    // 0x8505dc: LeaveFrame
    //     0x8505dc: mov             SP, fp
    //     0x8505e0: ldp             fp, lr, [SP], #0x10
    // 0x8505e4: ret
    //     0x8505e4: ret             
    // 0x8505e8: ldr             x1, [fp, #0x18]
    // 0x8505ec: ldr             x0, [fp, #0x10]
    // 0x8505f0: StoreField: r1->field_47 = r0
    //     0x8505f0: stur            w0, [x1, #0x47]
    //     0x8505f4: ldurb           w16, [x1, #-1]
    //     0x8505f8: ldurb           w17, [x0, #-1]
    //     0x8505fc: and             x16, x17, x16, lsr #2
    //     0x850600: tst             x16, HEAP, lsr #32
    //     0x850604: b.eq            #0x85060c
    //     0x850608: bl              #0xd6826c
    // 0x85060c: SaveReg r1
    //     0x85060c: str             x1, [SP, #-8]!
    // 0x850610: r0 = notifyListeners()
    //     0x850610: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850614: add             SP, SP, #8
    // 0x850618: r0 = Null
    //     0x850618: mov             x0, NULL
    // 0x85061c: LeaveFrame
    //     0x85061c: mov             SP, fp
    //     0x850620: ldp             fp, lr, [SP], #0x10
    // 0x850624: ret
    //     0x850624: ret             
    // 0x850628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85062c: b               #0x85045c
  }
  set _ hoverColor=(/* No info */) {
    // ** addr: 0x850630, size: 0x1ec
    // 0x850630: EnterFrame
    //     0x850630: stp             fp, lr, [SP, #-0x10]!
    //     0x850634: mov             fp, SP
    // 0x850638: AllocStack(0x10)
    //     0x850638: sub             SP, SP, #0x10
    // 0x85063c: CheckStackOverflow
    //     0x85063c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850640: cmp             SP, x16
    //     0x850644: b.ls            #0x850814
    // 0x850648: ldr             x0, [fp, #0x18]
    // 0x85064c: LoadField: r1 = r0->field_43
    //     0x85064c: ldur            w1, [x0, #0x43]
    // 0x850650: DecompressPointer r1
    //     0x850650: add             x1, x1, HEAP, lsl #32
    // 0x850654: ldr             x2, [fp, #0x10]
    // 0x850658: stur            x1, [fp, #-0x10]
    // 0x85065c: r3 = LoadClassIdInstr(r2)
    //     0x85065c: ldur            x3, [x2, #-1]
    //     0x850660: ubfx            x3, x3, #0xc, #0x14
    // 0x850664: lsl             x3, x3, #1
    // 0x850668: stur            x3, [fp, #-8]
    // 0x85066c: r17 = 10114
    //     0x85066c: mov             x17, #0x2782
    // 0x850670: cmp             w3, w17
    // 0x850674: b.eq            #0x850684
    // 0x850678: r17 = 10118
    //     0x850678: mov             x17, #0x2786
    // 0x85067c: cmp             w3, w17
    // 0x850680: b.ne            #0x85079c
    // 0x850684: cmp             w1, NULL
    // 0x850688: b.ne            #0x850694
    // 0x85068c: mov             x1, x0
    // 0x850690: b               #0x8507d8
    // 0x850694: cmp             w2, w1
    // 0x850698: b.eq            #0x8507c4
    // 0x85069c: stp             x2, x1, [SP, #-0x10]!
    // 0x8506a0: r0 = _haveSameRuntimeType()
    //     0x8506a0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x8506a4: add             SP, SP, #0x10
    // 0x8506a8: tbz             w0, #4, #0x8506b4
    // 0x8506ac: ldr             x1, [fp, #0x18]
    // 0x8506b0: b               #0x8507d8
    // 0x8506b4: ldur            x0, [fp, #-0x10]
    // 0x8506b8: r1 = LoadClassIdInstr(r0)
    //     0x8506b8: ldur            x1, [x0, #-1]
    //     0x8506bc: ubfx            x1, x1, #0xc, #0x14
    // 0x8506c0: lsl             x1, x1, #1
    // 0x8506c4: r2 = LoadInt32Instr(r1)
    //     0x8506c4: sbfx            x2, x1, #1, #0x1f
    // 0x8506c8: r17 = 5057
    //     0x8506c8: mov             x17, #0x13c1
    // 0x8506cc: cmp             x2, x17
    // 0x8506d0: b.lt            #0x850790
    // 0x8506d4: r17 = 5064
    //     0x8506d4: mov             x17, #0x13c8
    // 0x8506d8: cmp             x2, x17
    // 0x8506dc: b.gt            #0x850788
    // 0x8506e0: r17 = 10124
    //     0x8506e0: mov             x17, #0x278c
    // 0x8506e4: cmp             w1, w17
    // 0x8506e8: b.gt            #0x8506f8
    // 0x8506ec: r17 = 10122
    //     0x8506ec: mov             x17, #0x278a
    // 0x8506f0: cmp             w1, w17
    // 0x8506f4: b.ge            #0x850710
    // 0x8506f8: r17 = 10114
    //     0x8506f8: mov             x17, #0x2782
    // 0x8506fc: cmp             w1, w17
    // 0x850700: b.eq            #0x850710
    // 0x850704: r17 = 10118
    //     0x850704: mov             x17, #0x2786
    // 0x850708: cmp             w1, w17
    // 0x85070c: b.ne            #0x850718
    // 0x850710: LoadField: r1 = r0->field_7
    //     0x850710: ldur            x1, [x0, #7]
    // 0x850714: b               #0x850728
    // 0x850718: LoadField: r1 = r0->field_f
    //     0x850718: ldur            w1, [x0, #0xf]
    // 0x85071c: DecompressPointer r1
    //     0x85071c: add             x1, x1, HEAP, lsl #32
    // 0x850720: LoadField: r0 = r1->field_7
    //     0x850720: ldur            x0, [x1, #7]
    // 0x850724: mov             x1, x0
    // 0x850728: ldur            x0, [fp, #-8]
    // 0x85072c: r17 = 10124
    //     0x85072c: mov             x17, #0x278c
    // 0x850730: cmp             w0, w17
    // 0x850734: b.gt            #0x850744
    // 0x850738: r17 = 10122
    //     0x850738: mov             x17, #0x278a
    // 0x85073c: cmp             w0, w17
    // 0x850740: b.ge            #0x85075c
    // 0x850744: r17 = 10114
    //     0x850744: mov             x17, #0x2782
    // 0x850748: cmp             w0, w17
    // 0x85074c: b.eq            #0x85075c
    // 0x850750: r17 = 10118
    //     0x850750: mov             x17, #0x2786
    // 0x850754: cmp             w0, w17
    // 0x850758: b.ne            #0x850768
    // 0x85075c: ldr             x2, [fp, #0x10]
    // 0x850760: LoadField: r0 = r2->field_7
    //     0x850760: ldur            x0, [x2, #7]
    // 0x850764: b               #0x85077c
    // 0x850768: ldr             x2, [fp, #0x10]
    // 0x85076c: LoadField: r0 = r2->field_f
    //     0x85076c: ldur            w0, [x2, #0xf]
    // 0x850770: DecompressPointer r0
    //     0x850770: add             x0, x0, HEAP, lsl #32
    // 0x850774: LoadField: r3 = r0->field_7
    //     0x850774: ldur            x3, [x0, #7]
    // 0x850778: mov             x0, x3
    // 0x85077c: cmp             x1, x0
    // 0x850780: b.ne            #0x850794
    // 0x850784: b               #0x8507c4
    // 0x850788: ldr             x2, [fp, #0x10]
    // 0x85078c: b               #0x850794
    // 0x850790: ldr             x2, [fp, #0x10]
    // 0x850794: ldr             x1, [fp, #0x18]
    // 0x850798: b               #0x8507d8
    // 0x85079c: mov             x0, x1
    // 0x8507a0: r1 = LoadClassIdInstr(r2)
    //     0x8507a0: ldur            x1, [x2, #-1]
    //     0x8507a4: ubfx            x1, x1, #0xc, #0x14
    // 0x8507a8: stp             x0, x2, [SP, #-0x10]!
    // 0x8507ac: mov             x0, x1
    // 0x8507b0: mov             lr, x0
    // 0x8507b4: ldr             lr, [x21, lr, lsl #3]
    // 0x8507b8: blr             lr
    // 0x8507bc: add             SP, SP, #0x10
    // 0x8507c0: tbnz            w0, #4, #0x8507d4
    // 0x8507c4: r0 = Null
    //     0x8507c4: mov             x0, NULL
    // 0x8507c8: LeaveFrame
    //     0x8507c8: mov             SP, fp
    //     0x8507cc: ldp             fp, lr, [SP], #0x10
    // 0x8507d0: ret
    //     0x8507d0: ret             
    // 0x8507d4: ldr             x1, [fp, #0x18]
    // 0x8507d8: ldr             x0, [fp, #0x10]
    // 0x8507dc: StoreField: r1->field_43 = r0
    //     0x8507dc: stur            w0, [x1, #0x43]
    //     0x8507e0: ldurb           w16, [x1, #-1]
    //     0x8507e4: ldurb           w17, [x0, #-1]
    //     0x8507e8: and             x16, x17, x16, lsr #2
    //     0x8507ec: tst             x16, HEAP, lsr #32
    //     0x8507f0: b.eq            #0x8507f8
    //     0x8507f4: bl              #0xd6826c
    // 0x8507f8: SaveReg r1
    //     0x8507f8: str             x1, [SP, #-8]!
    // 0x8507fc: r0 = notifyListeners()
    //     0x8507fc: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850800: add             SP, SP, #8
    // 0x850804: r0 = Null
    //     0x850804: mov             x0, NULL
    // 0x850808: LeaveFrame
    //     0x850808: mov             SP, fp
    //     0x85080c: ldp             fp, lr, [SP], #0x10
    // 0x850810: ret
    //     0x850810: ret             
    // 0x850814: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850814: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850818: b               #0x850648
  }
  set _ reactionColor=(/* No info */) {
    // ** addr: 0x85081c, size: 0x1ec
    // 0x85081c: EnterFrame
    //     0x85081c: stp             fp, lr, [SP, #-0x10]!
    //     0x850820: mov             fp, SP
    // 0x850824: AllocStack(0x10)
    //     0x850824: sub             SP, SP, #0x10
    // 0x850828: CheckStackOverflow
    //     0x850828: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85082c: cmp             SP, x16
    //     0x850830: b.ls            #0x850a00
    // 0x850834: ldr             x0, [fp, #0x18]
    // 0x850838: LoadField: r1 = r0->field_3f
    //     0x850838: ldur            w1, [x0, #0x3f]
    // 0x85083c: DecompressPointer r1
    //     0x85083c: add             x1, x1, HEAP, lsl #32
    // 0x850840: ldr             x2, [fp, #0x10]
    // 0x850844: stur            x1, [fp, #-0x10]
    // 0x850848: r3 = LoadClassIdInstr(r2)
    //     0x850848: ldur            x3, [x2, #-1]
    //     0x85084c: ubfx            x3, x3, #0xc, #0x14
    // 0x850850: lsl             x3, x3, #1
    // 0x850854: stur            x3, [fp, #-8]
    // 0x850858: r17 = 10114
    //     0x850858: mov             x17, #0x2782
    // 0x85085c: cmp             w3, w17
    // 0x850860: b.eq            #0x850870
    // 0x850864: r17 = 10118
    //     0x850864: mov             x17, #0x2786
    // 0x850868: cmp             w3, w17
    // 0x85086c: b.ne            #0x850988
    // 0x850870: cmp             w1, NULL
    // 0x850874: b.ne            #0x850880
    // 0x850878: mov             x1, x0
    // 0x85087c: b               #0x8509c4
    // 0x850880: cmp             w2, w1
    // 0x850884: b.eq            #0x8509b0
    // 0x850888: stp             x2, x1, [SP, #-0x10]!
    // 0x85088c: r0 = _haveSameRuntimeType()
    //     0x85088c: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x850890: add             SP, SP, #0x10
    // 0x850894: tbz             w0, #4, #0x8508a0
    // 0x850898: ldr             x1, [fp, #0x18]
    // 0x85089c: b               #0x8509c4
    // 0x8508a0: ldur            x0, [fp, #-0x10]
    // 0x8508a4: r1 = LoadClassIdInstr(r0)
    //     0x8508a4: ldur            x1, [x0, #-1]
    //     0x8508a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8508ac: lsl             x1, x1, #1
    // 0x8508b0: r2 = LoadInt32Instr(r1)
    //     0x8508b0: sbfx            x2, x1, #1, #0x1f
    // 0x8508b4: r17 = 5057
    //     0x8508b4: mov             x17, #0x13c1
    // 0x8508b8: cmp             x2, x17
    // 0x8508bc: b.lt            #0x85097c
    // 0x8508c0: r17 = 5064
    //     0x8508c0: mov             x17, #0x13c8
    // 0x8508c4: cmp             x2, x17
    // 0x8508c8: b.gt            #0x850974
    // 0x8508cc: r17 = 10124
    //     0x8508cc: mov             x17, #0x278c
    // 0x8508d0: cmp             w1, w17
    // 0x8508d4: b.gt            #0x8508e4
    // 0x8508d8: r17 = 10122
    //     0x8508d8: mov             x17, #0x278a
    // 0x8508dc: cmp             w1, w17
    // 0x8508e0: b.ge            #0x8508fc
    // 0x8508e4: r17 = 10114
    //     0x8508e4: mov             x17, #0x2782
    // 0x8508e8: cmp             w1, w17
    // 0x8508ec: b.eq            #0x8508fc
    // 0x8508f0: r17 = 10118
    //     0x8508f0: mov             x17, #0x2786
    // 0x8508f4: cmp             w1, w17
    // 0x8508f8: b.ne            #0x850904
    // 0x8508fc: LoadField: r1 = r0->field_7
    //     0x8508fc: ldur            x1, [x0, #7]
    // 0x850900: b               #0x850914
    // 0x850904: LoadField: r1 = r0->field_f
    //     0x850904: ldur            w1, [x0, #0xf]
    // 0x850908: DecompressPointer r1
    //     0x850908: add             x1, x1, HEAP, lsl #32
    // 0x85090c: LoadField: r0 = r1->field_7
    //     0x85090c: ldur            x0, [x1, #7]
    // 0x850910: mov             x1, x0
    // 0x850914: ldur            x0, [fp, #-8]
    // 0x850918: r17 = 10124
    //     0x850918: mov             x17, #0x278c
    // 0x85091c: cmp             w0, w17
    // 0x850920: b.gt            #0x850930
    // 0x850924: r17 = 10122
    //     0x850924: mov             x17, #0x278a
    // 0x850928: cmp             w0, w17
    // 0x85092c: b.ge            #0x850948
    // 0x850930: r17 = 10114
    //     0x850930: mov             x17, #0x2782
    // 0x850934: cmp             w0, w17
    // 0x850938: b.eq            #0x850948
    // 0x85093c: r17 = 10118
    //     0x85093c: mov             x17, #0x2786
    // 0x850940: cmp             w0, w17
    // 0x850944: b.ne            #0x850954
    // 0x850948: ldr             x2, [fp, #0x10]
    // 0x85094c: LoadField: r0 = r2->field_7
    //     0x85094c: ldur            x0, [x2, #7]
    // 0x850950: b               #0x850968
    // 0x850954: ldr             x2, [fp, #0x10]
    // 0x850958: LoadField: r0 = r2->field_f
    //     0x850958: ldur            w0, [x2, #0xf]
    // 0x85095c: DecompressPointer r0
    //     0x85095c: add             x0, x0, HEAP, lsl #32
    // 0x850960: LoadField: r3 = r0->field_7
    //     0x850960: ldur            x3, [x0, #7]
    // 0x850964: mov             x0, x3
    // 0x850968: cmp             x1, x0
    // 0x85096c: b.ne            #0x850980
    // 0x850970: b               #0x8509b0
    // 0x850974: ldr             x2, [fp, #0x10]
    // 0x850978: b               #0x850980
    // 0x85097c: ldr             x2, [fp, #0x10]
    // 0x850980: ldr             x1, [fp, #0x18]
    // 0x850984: b               #0x8509c4
    // 0x850988: mov             x0, x1
    // 0x85098c: r1 = LoadClassIdInstr(r2)
    //     0x85098c: ldur            x1, [x2, #-1]
    //     0x850990: ubfx            x1, x1, #0xc, #0x14
    // 0x850994: stp             x0, x2, [SP, #-0x10]!
    // 0x850998: mov             x0, x1
    // 0x85099c: mov             lr, x0
    // 0x8509a0: ldr             lr, [x21, lr, lsl #3]
    // 0x8509a4: blr             lr
    // 0x8509a8: add             SP, SP, #0x10
    // 0x8509ac: tbnz            w0, #4, #0x8509c0
    // 0x8509b0: r0 = Null
    //     0x8509b0: mov             x0, NULL
    // 0x8509b4: LeaveFrame
    //     0x8509b4: mov             SP, fp
    //     0x8509b8: ldp             fp, lr, [SP], #0x10
    // 0x8509bc: ret
    //     0x8509bc: ret             
    // 0x8509c0: ldr             x1, [fp, #0x18]
    // 0x8509c4: ldr             x0, [fp, #0x10]
    // 0x8509c8: StoreField: r1->field_3f = r0
    //     0x8509c8: stur            w0, [x1, #0x3f]
    //     0x8509cc: ldurb           w16, [x1, #-1]
    //     0x8509d0: ldurb           w17, [x0, #-1]
    //     0x8509d4: and             x16, x17, x16, lsr #2
    //     0x8509d8: tst             x16, HEAP, lsr #32
    //     0x8509dc: b.eq            #0x8509e4
    //     0x8509e0: bl              #0xd6826c
    // 0x8509e4: SaveReg r1
    //     0x8509e4: str             x1, [SP, #-8]!
    // 0x8509e8: r0 = notifyListeners()
    //     0x8509e8: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x8509ec: add             SP, SP, #8
    // 0x8509f0: r0 = Null
    //     0x8509f0: mov             x0, NULL
    // 0x8509f4: LeaveFrame
    //     0x8509f4: mov             SP, fp
    //     0x8509f8: ldp             fp, lr, [SP], #0x10
    // 0x8509fc: ret
    //     0x8509fc: ret             
    // 0x850a00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850a00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850a04: b               #0x850834
  }
  set _ inactiveReactionColor=(/* No info */) {
    // ** addr: 0x850a08, size: 0x1ec
    // 0x850a08: EnterFrame
    //     0x850a08: stp             fp, lr, [SP, #-0x10]!
    //     0x850a0c: mov             fp, SP
    // 0x850a10: AllocStack(0x10)
    //     0x850a10: sub             SP, SP, #0x10
    // 0x850a14: CheckStackOverflow
    //     0x850a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850a18: cmp             SP, x16
    //     0x850a1c: b.ls            #0x850bec
    // 0x850a20: ldr             x0, [fp, #0x18]
    // 0x850a24: LoadField: r1 = r0->field_3b
    //     0x850a24: ldur            w1, [x0, #0x3b]
    // 0x850a28: DecompressPointer r1
    //     0x850a28: add             x1, x1, HEAP, lsl #32
    // 0x850a2c: ldr             x2, [fp, #0x10]
    // 0x850a30: stur            x1, [fp, #-0x10]
    // 0x850a34: r3 = LoadClassIdInstr(r2)
    //     0x850a34: ldur            x3, [x2, #-1]
    //     0x850a38: ubfx            x3, x3, #0xc, #0x14
    // 0x850a3c: lsl             x3, x3, #1
    // 0x850a40: stur            x3, [fp, #-8]
    // 0x850a44: r17 = 10114
    //     0x850a44: mov             x17, #0x2782
    // 0x850a48: cmp             w3, w17
    // 0x850a4c: b.eq            #0x850a5c
    // 0x850a50: r17 = 10118
    //     0x850a50: mov             x17, #0x2786
    // 0x850a54: cmp             w3, w17
    // 0x850a58: b.ne            #0x850b74
    // 0x850a5c: cmp             w1, NULL
    // 0x850a60: b.ne            #0x850a6c
    // 0x850a64: mov             x1, x0
    // 0x850a68: b               #0x850bb0
    // 0x850a6c: cmp             w2, w1
    // 0x850a70: b.eq            #0x850b9c
    // 0x850a74: stp             x2, x1, [SP, #-0x10]!
    // 0x850a78: r0 = _haveSameRuntimeType()
    //     0x850a78: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x850a7c: add             SP, SP, #0x10
    // 0x850a80: tbz             w0, #4, #0x850a8c
    // 0x850a84: ldr             x1, [fp, #0x18]
    // 0x850a88: b               #0x850bb0
    // 0x850a8c: ldur            x0, [fp, #-0x10]
    // 0x850a90: r1 = LoadClassIdInstr(r0)
    //     0x850a90: ldur            x1, [x0, #-1]
    //     0x850a94: ubfx            x1, x1, #0xc, #0x14
    // 0x850a98: lsl             x1, x1, #1
    // 0x850a9c: r2 = LoadInt32Instr(r1)
    //     0x850a9c: sbfx            x2, x1, #1, #0x1f
    // 0x850aa0: r17 = 5057
    //     0x850aa0: mov             x17, #0x13c1
    // 0x850aa4: cmp             x2, x17
    // 0x850aa8: b.lt            #0x850b68
    // 0x850aac: r17 = 5064
    //     0x850aac: mov             x17, #0x13c8
    // 0x850ab0: cmp             x2, x17
    // 0x850ab4: b.gt            #0x850b60
    // 0x850ab8: r17 = 10124
    //     0x850ab8: mov             x17, #0x278c
    // 0x850abc: cmp             w1, w17
    // 0x850ac0: b.gt            #0x850ad0
    // 0x850ac4: r17 = 10122
    //     0x850ac4: mov             x17, #0x278a
    // 0x850ac8: cmp             w1, w17
    // 0x850acc: b.ge            #0x850ae8
    // 0x850ad0: r17 = 10114
    //     0x850ad0: mov             x17, #0x2782
    // 0x850ad4: cmp             w1, w17
    // 0x850ad8: b.eq            #0x850ae8
    // 0x850adc: r17 = 10118
    //     0x850adc: mov             x17, #0x2786
    // 0x850ae0: cmp             w1, w17
    // 0x850ae4: b.ne            #0x850af0
    // 0x850ae8: LoadField: r1 = r0->field_7
    //     0x850ae8: ldur            x1, [x0, #7]
    // 0x850aec: b               #0x850b00
    // 0x850af0: LoadField: r1 = r0->field_f
    //     0x850af0: ldur            w1, [x0, #0xf]
    // 0x850af4: DecompressPointer r1
    //     0x850af4: add             x1, x1, HEAP, lsl #32
    // 0x850af8: LoadField: r0 = r1->field_7
    //     0x850af8: ldur            x0, [x1, #7]
    // 0x850afc: mov             x1, x0
    // 0x850b00: ldur            x0, [fp, #-8]
    // 0x850b04: r17 = 10124
    //     0x850b04: mov             x17, #0x278c
    // 0x850b08: cmp             w0, w17
    // 0x850b0c: b.gt            #0x850b1c
    // 0x850b10: r17 = 10122
    //     0x850b10: mov             x17, #0x278a
    // 0x850b14: cmp             w0, w17
    // 0x850b18: b.ge            #0x850b34
    // 0x850b1c: r17 = 10114
    //     0x850b1c: mov             x17, #0x2782
    // 0x850b20: cmp             w0, w17
    // 0x850b24: b.eq            #0x850b34
    // 0x850b28: r17 = 10118
    //     0x850b28: mov             x17, #0x2786
    // 0x850b2c: cmp             w0, w17
    // 0x850b30: b.ne            #0x850b40
    // 0x850b34: ldr             x2, [fp, #0x10]
    // 0x850b38: LoadField: r0 = r2->field_7
    //     0x850b38: ldur            x0, [x2, #7]
    // 0x850b3c: b               #0x850b54
    // 0x850b40: ldr             x2, [fp, #0x10]
    // 0x850b44: LoadField: r0 = r2->field_f
    //     0x850b44: ldur            w0, [x2, #0xf]
    // 0x850b48: DecompressPointer r0
    //     0x850b48: add             x0, x0, HEAP, lsl #32
    // 0x850b4c: LoadField: r3 = r0->field_7
    //     0x850b4c: ldur            x3, [x0, #7]
    // 0x850b50: mov             x0, x3
    // 0x850b54: cmp             x1, x0
    // 0x850b58: b.ne            #0x850b6c
    // 0x850b5c: b               #0x850b9c
    // 0x850b60: ldr             x2, [fp, #0x10]
    // 0x850b64: b               #0x850b6c
    // 0x850b68: ldr             x2, [fp, #0x10]
    // 0x850b6c: ldr             x1, [fp, #0x18]
    // 0x850b70: b               #0x850bb0
    // 0x850b74: mov             x0, x1
    // 0x850b78: r1 = LoadClassIdInstr(r2)
    //     0x850b78: ldur            x1, [x2, #-1]
    //     0x850b7c: ubfx            x1, x1, #0xc, #0x14
    // 0x850b80: stp             x0, x2, [SP, #-0x10]!
    // 0x850b84: mov             x0, x1
    // 0x850b88: mov             lr, x0
    // 0x850b8c: ldr             lr, [x21, lr, lsl #3]
    // 0x850b90: blr             lr
    // 0x850b94: add             SP, SP, #0x10
    // 0x850b98: tbnz            w0, #4, #0x850bac
    // 0x850b9c: r0 = Null
    //     0x850b9c: mov             x0, NULL
    // 0x850ba0: LeaveFrame
    //     0x850ba0: mov             SP, fp
    //     0x850ba4: ldp             fp, lr, [SP], #0x10
    // 0x850ba8: ret
    //     0x850ba8: ret             
    // 0x850bac: ldr             x1, [fp, #0x18]
    // 0x850bb0: ldr             x0, [fp, #0x10]
    // 0x850bb4: StoreField: r1->field_3b = r0
    //     0x850bb4: stur            w0, [x1, #0x3b]
    //     0x850bb8: ldurb           w16, [x1, #-1]
    //     0x850bbc: ldurb           w17, [x0, #-1]
    //     0x850bc0: and             x16, x17, x16, lsr #2
    //     0x850bc4: tst             x16, HEAP, lsr #32
    //     0x850bc8: b.eq            #0x850bd0
    //     0x850bcc: bl              #0xd6826c
    // 0x850bd0: SaveReg r1
    //     0x850bd0: str             x1, [SP, #-8]!
    // 0x850bd4: r0 = notifyListeners()
    //     0x850bd4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850bd8: add             SP, SP, #8
    // 0x850bdc: r0 = Null
    //     0x850bdc: mov             x0, NULL
    // 0x850be0: LeaveFrame
    //     0x850be0: mov             SP, fp
    //     0x850be4: ldp             fp, lr, [SP], #0x10
    // 0x850be8: ret
    //     0x850be8: ret             
    // 0x850bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850bf0: b               #0x850a20
  }
  set _ reactionHoverFade=(/* No info */) {
    // ** addr: 0x850bf4, size: 0x100
    // 0x850bf4: EnterFrame
    //     0x850bf4: stp             fp, lr, [SP, #-0x10]!
    //     0x850bf8: mov             fp, SP
    // 0x850bfc: AllocStack(0x8)
    //     0x850bfc: sub             SP, SP, #8
    // 0x850c00: CheckStackOverflow
    //     0x850c00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850c04: cmp             SP, x16
    //     0x850c08: b.ls            #0x850cec
    // 0x850c0c: ldr             x0, [fp, #0x18]
    // 0x850c10: LoadField: r1 = r0->field_2f
    //     0x850c10: ldur            w1, [x0, #0x2f]
    // 0x850c14: DecompressPointer r1
    //     0x850c14: add             x1, x1, HEAP, lsl #32
    // 0x850c18: ldr             x2, [fp, #0x10]
    // 0x850c1c: stur            x1, [fp, #-8]
    // 0x850c20: cmp             w2, w1
    // 0x850c24: b.ne            #0x850c38
    // 0x850c28: r0 = Null
    //     0x850c28: mov             x0, NULL
    // 0x850c2c: LeaveFrame
    //     0x850c2c: mov             SP, fp
    //     0x850c30: ldp             fp, lr, [SP], #0x10
    // 0x850c34: ret
    //     0x850c34: ret             
    // 0x850c38: cmp             w1, NULL
    // 0x850c3c: b.eq            #0x850c78
    // 0x850c40: r1 = 1
    //     0x850c40: mov             x1, #1
    // 0x850c44: r0 = AllocateContext()
    //     0x850c44: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850c48: mov             x1, x0
    // 0x850c4c: ldr             x0, [fp, #0x18]
    // 0x850c50: StoreField: r1->field_f = r0
    //     0x850c50: stur            w0, [x1, #0xf]
    // 0x850c54: mov             x2, x1
    // 0x850c58: r1 = Function 'notifyListeners':.
    //     0x850c58: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850c5c: ldr             x1, [x1, #0x298]
    // 0x850c60: r0 = AllocateClosure()
    //     0x850c60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850c64: ldur            x16, [fp, #-8]
    // 0x850c68: stp             x0, x16, [SP, #-0x10]!
    // 0x850c6c: r0 = removeListener()
    //     0x850c6c: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x850c70: add             SP, SP, #0x10
    // 0x850c74: ldr             x0, [fp, #0x18]
    // 0x850c78: r1 = 1
    //     0x850c78: mov             x1, #1
    // 0x850c7c: r0 = AllocateContext()
    //     0x850c7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850c80: mov             x1, x0
    // 0x850c84: ldr             x0, [fp, #0x18]
    // 0x850c88: StoreField: r1->field_f = r0
    //     0x850c88: stur            w0, [x1, #0xf]
    // 0x850c8c: mov             x2, x1
    // 0x850c90: r1 = Function 'notifyListeners':.
    //     0x850c90: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850c94: ldr             x1, [x1, #0x298]
    // 0x850c98: r0 = AllocateClosure()
    //     0x850c98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850c9c: ldr             x16, [fp, #0x10]
    // 0x850ca0: stp             x0, x16, [SP, #-0x10]!
    // 0x850ca4: r0 = addListener()
    //     0x850ca4: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x850ca8: add             SP, SP, #0x10
    // 0x850cac: ldr             x0, [fp, #0x10]
    // 0x850cb0: ldr             x1, [fp, #0x18]
    // 0x850cb4: StoreField: r1->field_2f = r0
    //     0x850cb4: stur            w0, [x1, #0x2f]
    //     0x850cb8: ldurb           w16, [x1, #-1]
    //     0x850cbc: ldurb           w17, [x0, #-1]
    //     0x850cc0: and             x16, x17, x16, lsr #2
    //     0x850cc4: tst             x16, HEAP, lsr #32
    //     0x850cc8: b.eq            #0x850cd0
    //     0x850ccc: bl              #0xd6826c
    // 0x850cd0: SaveReg r1
    //     0x850cd0: str             x1, [SP, #-8]!
    // 0x850cd4: r0 = notifyListeners()
    //     0x850cd4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850cd8: add             SP, SP, #8
    // 0x850cdc: r0 = Null
    //     0x850cdc: mov             x0, NULL
    // 0x850ce0: LeaveFrame
    //     0x850ce0: mov             SP, fp
    //     0x850ce4: ldp             fp, lr, [SP], #0x10
    // 0x850ce8: ret
    //     0x850ce8: ret             
    // 0x850cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850cec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850cf0: b               #0x850c0c
  }
  set _ reactionFocusFade=(/* No info */) {
    // ** addr: 0x850cf4, size: 0x100
    // 0x850cf4: EnterFrame
    //     0x850cf4: stp             fp, lr, [SP, #-0x10]!
    //     0x850cf8: mov             fp, SP
    // 0x850cfc: AllocStack(0x8)
    //     0x850cfc: sub             SP, SP, #8
    // 0x850d00: CheckStackOverflow
    //     0x850d00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850d04: cmp             SP, x16
    //     0x850d08: b.ls            #0x850dec
    // 0x850d0c: ldr             x0, [fp, #0x18]
    // 0x850d10: LoadField: r1 = r0->field_2b
    //     0x850d10: ldur            w1, [x0, #0x2b]
    // 0x850d14: DecompressPointer r1
    //     0x850d14: add             x1, x1, HEAP, lsl #32
    // 0x850d18: ldr             x2, [fp, #0x10]
    // 0x850d1c: stur            x1, [fp, #-8]
    // 0x850d20: cmp             w2, w1
    // 0x850d24: b.ne            #0x850d38
    // 0x850d28: r0 = Null
    //     0x850d28: mov             x0, NULL
    // 0x850d2c: LeaveFrame
    //     0x850d2c: mov             SP, fp
    //     0x850d30: ldp             fp, lr, [SP], #0x10
    // 0x850d34: ret
    //     0x850d34: ret             
    // 0x850d38: cmp             w1, NULL
    // 0x850d3c: b.eq            #0x850d78
    // 0x850d40: r1 = 1
    //     0x850d40: mov             x1, #1
    // 0x850d44: r0 = AllocateContext()
    //     0x850d44: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850d48: mov             x1, x0
    // 0x850d4c: ldr             x0, [fp, #0x18]
    // 0x850d50: StoreField: r1->field_f = r0
    //     0x850d50: stur            w0, [x1, #0xf]
    // 0x850d54: mov             x2, x1
    // 0x850d58: r1 = Function 'notifyListeners':.
    //     0x850d58: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850d5c: ldr             x1, [x1, #0x298]
    // 0x850d60: r0 = AllocateClosure()
    //     0x850d60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850d64: ldur            x16, [fp, #-8]
    // 0x850d68: stp             x0, x16, [SP, #-0x10]!
    // 0x850d6c: r0 = removeListener()
    //     0x850d6c: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x850d70: add             SP, SP, #0x10
    // 0x850d74: ldr             x0, [fp, #0x18]
    // 0x850d78: r1 = 1
    //     0x850d78: mov             x1, #1
    // 0x850d7c: r0 = AllocateContext()
    //     0x850d7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850d80: mov             x1, x0
    // 0x850d84: ldr             x0, [fp, #0x18]
    // 0x850d88: StoreField: r1->field_f = r0
    //     0x850d88: stur            w0, [x1, #0xf]
    // 0x850d8c: mov             x2, x1
    // 0x850d90: r1 = Function 'notifyListeners':.
    //     0x850d90: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850d94: ldr             x1, [x1, #0x298]
    // 0x850d98: r0 = AllocateClosure()
    //     0x850d98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850d9c: ldr             x16, [fp, #0x10]
    // 0x850da0: stp             x0, x16, [SP, #-0x10]!
    // 0x850da4: r0 = addListener()
    //     0x850da4: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x850da8: add             SP, SP, #0x10
    // 0x850dac: ldr             x0, [fp, #0x10]
    // 0x850db0: ldr             x1, [fp, #0x18]
    // 0x850db4: StoreField: r1->field_2b = r0
    //     0x850db4: stur            w0, [x1, #0x2b]
    //     0x850db8: ldurb           w16, [x1, #-1]
    //     0x850dbc: ldurb           w17, [x0, #-1]
    //     0x850dc0: and             x16, x17, x16, lsr #2
    //     0x850dc4: tst             x16, HEAP, lsr #32
    //     0x850dc8: b.eq            #0x850dd0
    //     0x850dcc: bl              #0xd6826c
    // 0x850dd0: SaveReg r1
    //     0x850dd0: str             x1, [SP, #-8]!
    // 0x850dd4: r0 = notifyListeners()
    //     0x850dd4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850dd8: add             SP, SP, #8
    // 0x850ddc: r0 = Null
    //     0x850ddc: mov             x0, NULL
    // 0x850de0: LeaveFrame
    //     0x850de0: mov             SP, fp
    //     0x850de4: ldp             fp, lr, [SP], #0x10
    // 0x850de8: ret
    //     0x850de8: ret             
    // 0x850dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850dec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850df0: b               #0x850d0c
  }
  set _ reaction=(/* No info */) {
    // ** addr: 0x850df4, size: 0x100
    // 0x850df4: EnterFrame
    //     0x850df4: stp             fp, lr, [SP, #-0x10]!
    //     0x850df8: mov             fp, SP
    // 0x850dfc: AllocStack(0x8)
    //     0x850dfc: sub             SP, SP, #8
    // 0x850e00: CheckStackOverflow
    //     0x850e00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850e04: cmp             SP, x16
    //     0x850e08: b.ls            #0x850eec
    // 0x850e0c: ldr             x0, [fp, #0x18]
    // 0x850e10: LoadField: r1 = r0->field_27
    //     0x850e10: ldur            w1, [x0, #0x27]
    // 0x850e14: DecompressPointer r1
    //     0x850e14: add             x1, x1, HEAP, lsl #32
    // 0x850e18: ldr             x2, [fp, #0x10]
    // 0x850e1c: stur            x1, [fp, #-8]
    // 0x850e20: cmp             w2, w1
    // 0x850e24: b.ne            #0x850e38
    // 0x850e28: r0 = Null
    //     0x850e28: mov             x0, NULL
    // 0x850e2c: LeaveFrame
    //     0x850e2c: mov             SP, fp
    //     0x850e30: ldp             fp, lr, [SP], #0x10
    // 0x850e34: ret
    //     0x850e34: ret             
    // 0x850e38: cmp             w1, NULL
    // 0x850e3c: b.eq            #0x850e78
    // 0x850e40: r1 = 1
    //     0x850e40: mov             x1, #1
    // 0x850e44: r0 = AllocateContext()
    //     0x850e44: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850e48: mov             x1, x0
    // 0x850e4c: ldr             x0, [fp, #0x18]
    // 0x850e50: StoreField: r1->field_f = r0
    //     0x850e50: stur            w0, [x1, #0xf]
    // 0x850e54: mov             x2, x1
    // 0x850e58: r1 = Function 'notifyListeners':.
    //     0x850e58: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850e5c: ldr             x1, [x1, #0x298]
    // 0x850e60: r0 = AllocateClosure()
    //     0x850e60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850e64: ldur            x16, [fp, #-8]
    // 0x850e68: stp             x0, x16, [SP, #-0x10]!
    // 0x850e6c: r0 = removeListener()
    //     0x850e6c: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x850e70: add             SP, SP, #0x10
    // 0x850e74: ldr             x0, [fp, #0x18]
    // 0x850e78: r1 = 1
    //     0x850e78: mov             x1, #1
    // 0x850e7c: r0 = AllocateContext()
    //     0x850e7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850e80: mov             x1, x0
    // 0x850e84: ldr             x0, [fp, #0x18]
    // 0x850e88: StoreField: r1->field_f = r0
    //     0x850e88: stur            w0, [x1, #0xf]
    // 0x850e8c: mov             x2, x1
    // 0x850e90: r1 = Function 'notifyListeners':.
    //     0x850e90: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850e94: ldr             x1, [x1, #0x298]
    // 0x850e98: r0 = AllocateClosure()
    //     0x850e98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850e9c: ldr             x16, [fp, #0x10]
    // 0x850ea0: stp             x0, x16, [SP, #-0x10]!
    // 0x850ea4: r0 = addListener()
    //     0x850ea4: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x850ea8: add             SP, SP, #0x10
    // 0x850eac: ldr             x0, [fp, #0x10]
    // 0x850eb0: ldr             x1, [fp, #0x18]
    // 0x850eb4: StoreField: r1->field_27 = r0
    //     0x850eb4: stur            w0, [x1, #0x27]
    //     0x850eb8: ldurb           w16, [x1, #-1]
    //     0x850ebc: ldurb           w17, [x0, #-1]
    //     0x850ec0: and             x16, x17, x16, lsr #2
    //     0x850ec4: tst             x16, HEAP, lsr #32
    //     0x850ec8: b.eq            #0x850ed0
    //     0x850ecc: bl              #0xd6826c
    // 0x850ed0: SaveReg r1
    //     0x850ed0: str             x1, [SP, #-8]!
    // 0x850ed4: r0 = notifyListeners()
    //     0x850ed4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850ed8: add             SP, SP, #8
    // 0x850edc: r0 = Null
    //     0x850edc: mov             x0, NULL
    // 0x850ee0: LeaveFrame
    //     0x850ee0: mov             SP, fp
    //     0x850ee4: ldp             fp, lr, [SP], #0x10
    // 0x850ee8: ret
    //     0x850ee8: ret             
    // 0x850eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850ef0: b               #0x850e0c
  }
  set _ position=(/* No info */) {
    // ** addr: 0x850ef4, size: 0x100
    // 0x850ef4: EnterFrame
    //     0x850ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x850ef8: mov             fp, SP
    // 0x850efc: AllocStack(0x8)
    //     0x850efc: sub             SP, SP, #8
    // 0x850f00: CheckStackOverflow
    //     0x850f00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x850f04: cmp             SP, x16
    //     0x850f08: b.ls            #0x850fec
    // 0x850f0c: ldr             x0, [fp, #0x18]
    // 0x850f10: LoadField: r1 = r0->field_23
    //     0x850f10: ldur            w1, [x0, #0x23]
    // 0x850f14: DecompressPointer r1
    //     0x850f14: add             x1, x1, HEAP, lsl #32
    // 0x850f18: ldr             x2, [fp, #0x10]
    // 0x850f1c: stur            x1, [fp, #-8]
    // 0x850f20: cmp             w2, w1
    // 0x850f24: b.ne            #0x850f38
    // 0x850f28: r0 = Null
    //     0x850f28: mov             x0, NULL
    // 0x850f2c: LeaveFrame
    //     0x850f2c: mov             SP, fp
    //     0x850f30: ldp             fp, lr, [SP], #0x10
    // 0x850f34: ret
    //     0x850f34: ret             
    // 0x850f38: cmp             w1, NULL
    // 0x850f3c: b.eq            #0x850f78
    // 0x850f40: r1 = 1
    //     0x850f40: mov             x1, #1
    // 0x850f44: r0 = AllocateContext()
    //     0x850f44: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850f48: mov             x1, x0
    // 0x850f4c: ldr             x0, [fp, #0x18]
    // 0x850f50: StoreField: r1->field_f = r0
    //     0x850f50: stur            w0, [x1, #0xf]
    // 0x850f54: mov             x2, x1
    // 0x850f58: r1 = Function 'notifyListeners':.
    //     0x850f58: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850f5c: ldr             x1, [x1, #0x298]
    // 0x850f60: r0 = AllocateClosure()
    //     0x850f60: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850f64: ldur            x16, [fp, #-8]
    // 0x850f68: stp             x0, x16, [SP, #-0x10]!
    // 0x850f6c: r0 = removeListener()
    //     0x850f6c: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x850f70: add             SP, SP, #0x10
    // 0x850f74: ldr             x0, [fp, #0x18]
    // 0x850f78: r1 = 1
    //     0x850f78: mov             x1, #1
    // 0x850f7c: r0 = AllocateContext()
    //     0x850f7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x850f80: mov             x1, x0
    // 0x850f84: ldr             x0, [fp, #0x18]
    // 0x850f88: StoreField: r1->field_f = r0
    //     0x850f88: stur            w0, [x1, #0xf]
    // 0x850f8c: mov             x2, x1
    // 0x850f90: r1 = Function 'notifyListeners':.
    //     0x850f90: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x850f94: ldr             x1, [x1, #0x298]
    // 0x850f98: r0 = AllocateClosure()
    //     0x850f98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x850f9c: ldr             x16, [fp, #0x10]
    // 0x850fa0: stp             x0, x16, [SP, #-0x10]!
    // 0x850fa4: r0 = addListener()
    //     0x850fa4: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x850fa8: add             SP, SP, #0x10
    // 0x850fac: ldr             x0, [fp, #0x10]
    // 0x850fb0: ldr             x1, [fp, #0x18]
    // 0x850fb4: StoreField: r1->field_23 = r0
    //     0x850fb4: stur            w0, [x1, #0x23]
    //     0x850fb8: ldurb           w16, [x1, #-1]
    //     0x850fbc: ldurb           w17, [x0, #-1]
    //     0x850fc0: and             x16, x17, x16, lsr #2
    //     0x850fc4: tst             x16, HEAP, lsr #32
    //     0x850fc8: b.eq            #0x850fd0
    //     0x850fcc: bl              #0xd6826c
    // 0x850fd0: SaveReg r1
    //     0x850fd0: str             x1, [SP, #-8]!
    // 0x850fd4: r0 = notifyListeners()
    //     0x850fd4: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x850fd8: add             SP, SP, #8
    // 0x850fdc: r0 = Null
    //     0x850fdc: mov             x0, NULL
    // 0x850fe0: LeaveFrame
    //     0x850fe0: mov             SP, fp
    //     0x850fe4: ldp             fp, lr, [SP], #0x10
    // 0x850fe8: ret
    //     0x850fe8: ret             
    // 0x850fec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x850fec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x850ff0: b               #0x850f0c
  }
  dynamic dispose(dynamic) {
    // ** addr: 0x9ba148, size: 0x18
    // 0x9ba148: r4 = 0
    //     0x9ba148: mov             x4, #0
    // 0x9ba14c: r1 = Function 'dispose':.
    //     0x9ba14c: add             x17, PP, #0x56, lsl #12  ; [pp+0x563f8] AnonymousClosure: (0x9ba160), in [package:flutter/src/material/toggleable.dart] ToggleablePainter::dispose (0x9c2368)
    //     0x9ba150: ldr             x1, [x17, #0x3f8]
    // 0x9ba154: r24 = BuildNonGenericMethodExtractorStub
    //     0x9ba154: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9ba158: LoadField: r0 = r24->field_17
    //     0x9ba158: ldur            x0, [x24, #0x17]
    // 0x9ba15c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0x9ba160, size: 0x48
    // 0x9ba160: EnterFrame
    //     0x9ba160: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba164: mov             fp, SP
    // 0x9ba168: ldr             x0, [fp, #0x10]
    // 0x9ba16c: LoadField: r1 = r0->field_17
    //     0x9ba16c: ldur            w1, [x0, #0x17]
    // 0x9ba170: DecompressPointer r1
    //     0x9ba170: add             x1, x1, HEAP, lsl #32
    // 0x9ba174: CheckStackOverflow
    //     0x9ba174: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ba178: cmp             SP, x16
    //     0x9ba17c: b.ls            #0x9ba1a0
    // 0x9ba180: LoadField: r0 = r1->field_f
    //     0x9ba180: ldur            w0, [x1, #0xf]
    // 0x9ba184: DecompressPointer r0
    //     0x9ba184: add             x0, x0, HEAP, lsl #32
    // 0x9ba188: SaveReg r0
    //     0x9ba188: str             x0, [SP, #-8]!
    // 0x9ba18c: r0 = dispose()
    //     0x9ba18c: bl              #0x9c2368  ; [package:flutter/src/material/toggleable.dart] ToggleablePainter::dispose
    // 0x9ba190: add             SP, SP, #8
    // 0x9ba194: LeaveFrame
    //     0x9ba194: mov             SP, fp
    //     0x9ba198: ldp             fp, lr, [SP], #0x10
    // 0x9ba19c: ret
    //     0x9ba19c: ret             
    // 0x9ba1a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba1a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba1a4: b               #0x9ba180
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9c2368, size: 0x170
    // 0x9c2368: EnterFrame
    //     0x9c2368: stp             fp, lr, [SP, #-0x10]!
    //     0x9c236c: mov             fp, SP
    // 0x9c2370: AllocStack(0x8)
    //     0x9c2370: sub             SP, SP, #8
    // 0x9c2374: CheckStackOverflow
    //     0x9c2374: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9c2378: cmp             SP, x16
    //     0x9c237c: b.ls            #0x9c24d0
    // 0x9c2380: ldr             x0, [fp, #0x10]
    // 0x9c2384: LoadField: r1 = r0->field_23
    //     0x9c2384: ldur            w1, [x0, #0x23]
    // 0x9c2388: DecompressPointer r1
    //     0x9c2388: add             x1, x1, HEAP, lsl #32
    // 0x9c238c: stur            x1, [fp, #-8]
    // 0x9c2390: cmp             w1, NULL
    // 0x9c2394: b.eq            #0x9c23d0
    // 0x9c2398: r1 = 1
    //     0x9c2398: mov             x1, #1
    // 0x9c239c: r0 = AllocateContext()
    //     0x9c239c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c23a0: mov             x1, x0
    // 0x9c23a4: ldr             x0, [fp, #0x10]
    // 0x9c23a8: StoreField: r1->field_f = r0
    //     0x9c23a8: stur            w0, [x1, #0xf]
    // 0x9c23ac: mov             x2, x1
    // 0x9c23b0: r1 = Function 'notifyListeners':.
    //     0x9c23b0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c23b4: ldr             x1, [x1, #0x298]
    // 0x9c23b8: r0 = AllocateClosure()
    //     0x9c23b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c23bc: ldur            x16, [fp, #-8]
    // 0x9c23c0: stp             x0, x16, [SP, #-0x10]!
    // 0x9c23c4: r0 = removeListener()
    //     0x9c23c4: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x9c23c8: add             SP, SP, #0x10
    // 0x9c23cc: ldr             x0, [fp, #0x10]
    // 0x9c23d0: LoadField: r1 = r0->field_27
    //     0x9c23d0: ldur            w1, [x0, #0x27]
    // 0x9c23d4: DecompressPointer r1
    //     0x9c23d4: add             x1, x1, HEAP, lsl #32
    // 0x9c23d8: stur            x1, [fp, #-8]
    // 0x9c23dc: cmp             w1, NULL
    // 0x9c23e0: b.eq            #0x9c241c
    // 0x9c23e4: r1 = 1
    //     0x9c23e4: mov             x1, #1
    // 0x9c23e8: r0 = AllocateContext()
    //     0x9c23e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c23ec: mov             x1, x0
    // 0x9c23f0: ldr             x0, [fp, #0x10]
    // 0x9c23f4: StoreField: r1->field_f = r0
    //     0x9c23f4: stur            w0, [x1, #0xf]
    // 0x9c23f8: mov             x2, x1
    // 0x9c23fc: r1 = Function 'notifyListeners':.
    //     0x9c23fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c2400: ldr             x1, [x1, #0x298]
    // 0x9c2404: r0 = AllocateClosure()
    //     0x9c2404: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2408: ldur            x16, [fp, #-8]
    // 0x9c240c: stp             x0, x16, [SP, #-0x10]!
    // 0x9c2410: r0 = removeListener()
    //     0x9c2410: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x9c2414: add             SP, SP, #0x10
    // 0x9c2418: ldr             x0, [fp, #0x10]
    // 0x9c241c: LoadField: r1 = r0->field_2b
    //     0x9c241c: ldur            w1, [x0, #0x2b]
    // 0x9c2420: DecompressPointer r1
    //     0x9c2420: add             x1, x1, HEAP, lsl #32
    // 0x9c2424: stur            x1, [fp, #-8]
    // 0x9c2428: cmp             w1, NULL
    // 0x9c242c: b.eq            #0x9c2468
    // 0x9c2430: r1 = 1
    //     0x9c2430: mov             x1, #1
    // 0x9c2434: r0 = AllocateContext()
    //     0x9c2434: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c2438: mov             x1, x0
    // 0x9c243c: ldr             x0, [fp, #0x10]
    // 0x9c2440: StoreField: r1->field_f = r0
    //     0x9c2440: stur            w0, [x1, #0xf]
    // 0x9c2444: mov             x2, x1
    // 0x9c2448: r1 = Function 'notifyListeners':.
    //     0x9c2448: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c244c: ldr             x1, [x1, #0x298]
    // 0x9c2450: r0 = AllocateClosure()
    //     0x9c2450: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2454: ldur            x16, [fp, #-8]
    // 0x9c2458: stp             x0, x16, [SP, #-0x10]!
    // 0x9c245c: r0 = removeListener()
    //     0x9c245c: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x9c2460: add             SP, SP, #0x10
    // 0x9c2464: ldr             x0, [fp, #0x10]
    // 0x9c2468: LoadField: r1 = r0->field_2f
    //     0x9c2468: ldur            w1, [x0, #0x2f]
    // 0x9c246c: DecompressPointer r1
    //     0x9c246c: add             x1, x1, HEAP, lsl #32
    // 0x9c2470: stur            x1, [fp, #-8]
    // 0x9c2474: cmp             w1, NULL
    // 0x9c2478: b.eq            #0x9c24b0
    // 0x9c247c: r1 = 1
    //     0x9c247c: mov             x1, #1
    // 0x9c2480: r0 = AllocateContext()
    //     0x9c2480: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c2484: mov             x1, x0
    // 0x9c2488: ldr             x0, [fp, #0x10]
    // 0x9c248c: StoreField: r1->field_f = r0
    //     0x9c248c: stur            w0, [x1, #0xf]
    // 0x9c2490: mov             x2, x1
    // 0x9c2494: r1 = Function 'notifyListeners':.
    //     0x9c2494: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c2498: ldr             x1, [x1, #0x298]
    // 0x9c249c: r0 = AllocateClosure()
    //     0x9c249c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c24a0: ldur            x16, [fp, #-8]
    // 0x9c24a4: stp             x0, x16, [SP, #-0x10]!
    // 0x9c24a8: r0 = removeListener()
    //     0x9c24a8: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0x9c24ac: add             SP, SP, #0x10
    // 0x9c24b0: ldr             x16, [fp, #0x10]
    // 0x9c24b4: SaveReg r16
    //     0x9c24b4: str             x16, [SP, #-8]!
    // 0x9c24b8: r0 = dispose()
    //     0x9c24b8: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x9c24bc: add             SP, SP, #8
    // 0x9c24c0: r0 = Null
    //     0x9c24c0: mov             x0, NULL
    // 0x9c24c4: LeaveFrame
    //     0x9c24c4: mov             SP, fp
    //     0x9c24c8: ldp             fp, lr, [SP], #0x10
    // 0x9c24cc: ret
    //     0x9c24cc: ret             
    // 0x9c24d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c24d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c24d4: b               #0x9c2380
  }
  _ paintRadialReaction(/* No info */) {
    // ** addr: 0xa66c10, size: 0x378
    // 0xa66c10: EnterFrame
    //     0xa66c10: stp             fp, lr, [SP, #-0x10]!
    //     0xa66c14: mov             fp, SP
    // 0xa66c18: AllocStack(0x28)
    //     0xa66c18: sub             SP, SP, #0x28
    // 0xa66c1c: CheckStackOverflow
    //     0xa66c1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa66c20: cmp             SP, x16
    //     0xa66c24: b.ls            #0xa66f44
    // 0xa66c28: ldr             x1, [fp, #0x20]
    // 0xa66c2c: LoadField: r0 = r1->field_27
    //     0xa66c2c: ldur            w0, [x1, #0x27]
    // 0xa66c30: DecompressPointer r0
    //     0xa66c30: add             x0, x0, HEAP, lsl #32
    // 0xa66c34: cmp             w0, NULL
    // 0xa66c38: b.eq            #0xa66f4c
    // 0xa66c3c: LoadField: r2 = r0->field_b
    //     0xa66c3c: ldur            w2, [x0, #0xb]
    // 0xa66c40: DecompressPointer r2
    //     0xa66c40: add             x2, x2, HEAP, lsl #32
    // 0xa66c44: r0 = LoadClassIdInstr(r2)
    //     0xa66c44: ldur            x0, [x2, #-1]
    //     0xa66c48: ubfx            x0, x0, #0xc, #0x14
    // 0xa66c4c: SaveReg r2
    //     0xa66c4c: str             x2, [SP, #-8]!
    // 0xa66c50: r0 = GDT[cid_x0 + 0x376]()
    //     0xa66c50: add             lr, x0, #0x376
    //     0xa66c54: ldr             lr, [x21, lr, lsl #3]
    //     0xa66c58: blr             lr
    // 0xa66c5c: add             SP, SP, #8
    // 0xa66c60: r16 = Instance_AnimationStatus
    //     0xa66c60: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0xa66c64: ldr             x16, [x16, #0xba8]
    // 0xa66c68: cmp             w0, w16
    // 0xa66c6c: b.ne            #0xa66d00
    // 0xa66c70: ldr             x1, [fp, #0x20]
    // 0xa66c74: LoadField: r0 = r1->field_2b
    //     0xa66c74: ldur            w0, [x1, #0x2b]
    // 0xa66c78: DecompressPointer r0
    //     0xa66c78: add             x0, x0, HEAP, lsl #32
    // 0xa66c7c: cmp             w0, NULL
    // 0xa66c80: b.eq            #0xa66f50
    // 0xa66c84: LoadField: r2 = r0->field_b
    //     0xa66c84: ldur            w2, [x0, #0xb]
    // 0xa66c88: DecompressPointer r2
    //     0xa66c88: add             x2, x2, HEAP, lsl #32
    // 0xa66c8c: r0 = LoadClassIdInstr(r2)
    //     0xa66c8c: ldur            x0, [x2, #-1]
    //     0xa66c90: ubfx            x0, x0, #0xc, #0x14
    // 0xa66c94: SaveReg r2
    //     0xa66c94: str             x2, [SP, #-8]!
    // 0xa66c98: r0 = GDT[cid_x0 + 0x376]()
    //     0xa66c98: add             lr, x0, #0x376
    //     0xa66c9c: ldr             lr, [x21, lr, lsl #3]
    //     0xa66ca0: blr             lr
    // 0xa66ca4: add             SP, SP, #8
    // 0xa66ca8: r16 = Instance_AnimationStatus
    //     0xa66ca8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0xa66cac: ldr             x16, [x16, #0xba8]
    // 0xa66cb0: cmp             w0, w16
    // 0xa66cb4: b.ne            #0xa66d00
    // 0xa66cb8: ldr             x1, [fp, #0x20]
    // 0xa66cbc: LoadField: r0 = r1->field_2f
    //     0xa66cbc: ldur            w0, [x1, #0x2f]
    // 0xa66cc0: DecompressPointer r0
    //     0xa66cc0: add             x0, x0, HEAP, lsl #32
    // 0xa66cc4: cmp             w0, NULL
    // 0xa66cc8: b.eq            #0xa66f54
    // 0xa66ccc: LoadField: r2 = r0->field_b
    //     0xa66ccc: ldur            w2, [x0, #0xb]
    // 0xa66cd0: DecompressPointer r2
    //     0xa66cd0: add             x2, x2, HEAP, lsl #32
    // 0xa66cd4: r0 = LoadClassIdInstr(r2)
    //     0xa66cd4: ldur            x0, [x2, #-1]
    //     0xa66cd8: ubfx            x0, x0, #0xc, #0x14
    // 0xa66cdc: SaveReg r2
    //     0xa66cdc: str             x2, [SP, #-8]!
    // 0xa66ce0: r0 = GDT[cid_x0 + 0x376]()
    //     0xa66ce0: add             lr, x0, #0x376
    //     0xa66ce4: ldr             lr, [x21, lr, lsl #3]
    //     0xa66ce8: blr             lr
    // 0xa66cec: add             SP, SP, #8
    // 0xa66cf0: r16 = Instance_AnimationStatus
    //     0xa66cf0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0xa66cf4: ldr             x16, [x16, #0xba8]
    // 0xa66cf8: cmp             w0, w16
    // 0xa66cfc: b.eq            #0xa66f34
    // 0xa66d00: ldr             x0, [fp, #0x20]
    // 0xa66d04: r16 = 112
    //     0xa66d04: mov             x16, #0x70
    // 0xa66d08: stp             x16, NULL, [SP, #-0x10]!
    // 0xa66d0c: r0 = ByteData()
    //     0xa66d0c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa66d10: add             SP, SP, #0x10
    // 0xa66d14: stur            x0, [fp, #-8]
    // 0xa66d18: r0 = Paint()
    //     0xa66d18: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa66d1c: mov             x1, x0
    // 0xa66d20: ldur            x0, [fp, #-8]
    // 0xa66d24: stur            x1, [fp, #-0x20]
    // 0xa66d28: StoreField: r1->field_7 = r0
    //     0xa66d28: stur            w0, [x1, #7]
    // 0xa66d2c: ldr             x2, [fp, #0x20]
    // 0xa66d30: LoadField: r3 = r2->field_3b
    //     0xa66d30: ldur            w3, [x2, #0x3b]
    // 0xa66d34: DecompressPointer r3
    //     0xa66d34: add             x3, x3, HEAP, lsl #32
    // 0xa66d38: stur            x3, [fp, #-0x18]
    // 0xa66d3c: cmp             w3, NULL
    // 0xa66d40: b.eq            #0xa66f58
    // 0xa66d44: LoadField: r4 = r2->field_3f
    //     0xa66d44: ldur            w4, [x2, #0x3f]
    // 0xa66d48: DecompressPointer r4
    //     0xa66d48: add             x4, x4, HEAP, lsl #32
    // 0xa66d4c: stur            x4, [fp, #-0x10]
    // 0xa66d50: cmp             w4, NULL
    // 0xa66d54: b.eq            #0xa66f5c
    // 0xa66d58: LoadField: r5 = r2->field_23
    //     0xa66d58: ldur            w5, [x2, #0x23]
    // 0xa66d5c: DecompressPointer r5
    //     0xa66d5c: add             x5, x5, HEAP, lsl #32
    // 0xa66d60: cmp             w5, NULL
    // 0xa66d64: b.eq            #0xa66f60
    // 0xa66d68: SaveReg r5
    //     0xa66d68: str             x5, [SP, #-8]!
    // 0xa66d6c: r0 = value()
    //     0xa66d6c: bl              #0xc24674  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xa66d70: add             SP, SP, #8
    // 0xa66d74: ldur            x16, [fp, #-0x18]
    // 0xa66d78: ldur            lr, [fp, #-0x10]
    // 0xa66d7c: stp             lr, x16, [SP, #-0x10]!
    // 0xa66d80: SaveReg r0
    //     0xa66d80: str             x0, [SP, #-8]!
    // 0xa66d84: r0 = lerp()
    //     0xa66d84: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xa66d88: add             SP, SP, #0x18
    // 0xa66d8c: mov             x1, x0
    // 0xa66d90: ldr             x0, [fp, #0x20]
    // 0xa66d94: stur            x1, [fp, #-0x18]
    // 0xa66d98: LoadField: r2 = r0->field_43
    //     0xa66d98: ldur            w2, [x0, #0x43]
    // 0xa66d9c: DecompressPointer r2
    //     0xa66d9c: add             x2, x2, HEAP, lsl #32
    // 0xa66da0: stur            x2, [fp, #-0x10]
    // 0xa66da4: cmp             w2, NULL
    // 0xa66da8: b.eq            #0xa66f64
    // 0xa66dac: LoadField: r3 = r0->field_2f
    //     0xa66dac: ldur            w3, [x0, #0x2f]
    // 0xa66db0: DecompressPointer r3
    //     0xa66db0: add             x3, x3, HEAP, lsl #32
    // 0xa66db4: cmp             w3, NULL
    // 0xa66db8: b.eq            #0xa66f68
    // 0xa66dbc: SaveReg r3
    //     0xa66dbc: str             x3, [SP, #-8]!
    // 0xa66dc0: r0 = value()
    //     0xa66dc0: bl              #0xc24674  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xa66dc4: add             SP, SP, #8
    // 0xa66dc8: ldur            x16, [fp, #-0x18]
    // 0xa66dcc: ldur            lr, [fp, #-0x10]
    // 0xa66dd0: stp             lr, x16, [SP, #-0x10]!
    // 0xa66dd4: SaveReg r0
    //     0xa66dd4: str             x0, [SP, #-8]!
    // 0xa66dd8: r0 = lerp()
    //     0xa66dd8: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xa66ddc: add             SP, SP, #0x18
    // 0xa66de0: mov             x1, x0
    // 0xa66de4: ldr             x0, [fp, #0x20]
    // 0xa66de8: stur            x1, [fp, #-0x18]
    // 0xa66dec: LoadField: r2 = r0->field_47
    //     0xa66dec: ldur            w2, [x0, #0x47]
    // 0xa66df0: DecompressPointer r2
    //     0xa66df0: add             x2, x2, HEAP, lsl #32
    // 0xa66df4: stur            x2, [fp, #-0x10]
    // 0xa66df8: cmp             w2, NULL
    // 0xa66dfc: b.eq            #0xa66f6c
    // 0xa66e00: LoadField: r3 = r0->field_2b
    //     0xa66e00: ldur            w3, [x0, #0x2b]
    // 0xa66e04: DecompressPointer r3
    //     0xa66e04: add             x3, x3, HEAP, lsl #32
    // 0xa66e08: cmp             w3, NULL
    // 0xa66e0c: b.eq            #0xa66f70
    // 0xa66e10: SaveReg r3
    //     0xa66e10: str             x3, [SP, #-8]!
    // 0xa66e14: r0 = value()
    //     0xa66e14: bl              #0xc24674  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::value
    // 0xa66e18: add             SP, SP, #8
    // 0xa66e1c: ldur            x16, [fp, #-0x18]
    // 0xa66e20: ldur            lr, [fp, #-0x10]
    // 0xa66e24: stp             lr, x16, [SP, #-0x10]!
    // 0xa66e28: SaveReg r0
    //     0xa66e28: str             x0, [SP, #-8]!
    // 0xa66e2c: r0 = lerp()
    //     0xa66e2c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xa66e30: add             SP, SP, #0x18
    // 0xa66e34: cmp             w0, NULL
    // 0xa66e38: b.eq            #0xa66f74
    // 0xa66e3c: LoadField: r1 = r0->field_7
    //     0xa66e3c: ldur            x1, [x0, #7]
    // 0xa66e40: eor             x0, x1, #0xff000000
    // 0xa66e44: ldur            x1, [fp, #-8]
    // 0xa66e48: LoadField: r2 = r1->field_17
    //     0xa66e48: ldur            w2, [x1, #0x17]
    // 0xa66e4c: DecompressPointer r2
    //     0xa66e4c: add             x2, x2, HEAP, lsl #32
    // 0xa66e50: sxtw            x0, w0
    // 0xa66e54: LoadField: r1 = r2->field_7
    //     0xa66e54: ldur            x1, [x2, #7]
    // 0xa66e58: str             w0, [x1, #4]
    // 0xa66e5c: ldr             x0, [fp, #0x20]
    // 0xa66e60: LoadField: r2 = r0->field_4b
    //     0xa66e60: ldur            w2, [x0, #0x4b]
    // 0xa66e64: DecompressPointer r2
    //     0xa66e64: add             x2, x2, HEAP, lsl #32
    // 0xa66e68: stur            x2, [fp, #-8]
    // 0xa66e6c: cmp             w2, NULL
    // 0xa66e70: b.eq            #0xa66f78
    // 0xa66e74: r1 = <double>
    //     0xa66e74: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa66e78: r0 = Tween()
    //     0xa66e78: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xa66e7c: mov             x1, x0
    // 0xa66e80: r0 = 0.000000
    //     0xa66e80: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xa66e84: StoreField: r1->field_b = r0
    //     0xa66e84: stur            w0, [x1, #0xb]
    // 0xa66e88: ldur            x0, [fp, #-8]
    // 0xa66e8c: StoreField: r1->field_f = r0
    //     0xa66e8c: stur            w0, [x1, #0xf]
    // 0xa66e90: ldr             x2, [fp, #0x20]
    // 0xa66e94: LoadField: r3 = r2->field_53
    //     0xa66e94: ldur            w3, [x2, #0x53]
    // 0xa66e98: DecompressPointer r3
    //     0xa66e98: add             x3, x3, HEAP, lsl #32
    // 0xa66e9c: cmp             w3, NULL
    // 0xa66ea0: b.eq            #0xa66f7c
    // 0xa66ea4: tbz             w3, #4, #0xa66ebc
    // 0xa66ea8: LoadField: r3 = r2->field_57
    //     0xa66ea8: ldur            w3, [x2, #0x57]
    // 0xa66eac: DecompressPointer r3
    //     0xa66eac: add             x3, x3, HEAP, lsl #32
    // 0xa66eb0: cmp             w3, NULL
    // 0xa66eb4: b.eq            #0xa66f80
    // 0xa66eb8: tbnz            w3, #4, #0xa66ec8
    // 0xa66ebc: LoadField: d0 = r0->field_7
    //     0xa66ebc: ldur            d0, [x0, #7]
    // 0xa66ec0: mov             v1.16b, v0.16b
    // 0xa66ec4: b               #0xa66eec
    // 0xa66ec8: LoadField: r0 = r2->field_27
    //     0xa66ec8: ldur            w0, [x2, #0x27]
    // 0xa66ecc: DecompressPointer r0
    //     0xa66ecc: add             x0, x0, HEAP, lsl #32
    // 0xa66ed0: cmp             w0, NULL
    // 0xa66ed4: b.eq            #0xa66f84
    // 0xa66ed8: stp             x0, x1, [SP, #-0x10]!
    // 0xa66edc: r0 = evaluate()
    //     0xa66edc: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xa66ee0: add             SP, SP, #0x10
    // 0xa66ee4: LoadField: d0 = r0->field_7
    //     0xa66ee4: ldur            d0, [x0, #7]
    // 0xa66ee8: mov             v1.16b, v0.16b
    // 0xa66eec: d0 = 0.000000
    //     0xa66eec: eor             v0.16b, v0.16b, v0.16b
    // 0xa66ef0: stur            d1, [fp, #-0x28]
    // 0xa66ef4: fcmp            d1, d0
    // 0xa66ef8: b.vs            #0xa66f34
    // 0xa66efc: b.le            #0xa66f34
    // 0xa66f00: ldr             x16, [fp, #0x10]
    // 0xa66f04: r30 = Instance_Offset
    //     0xa66f04: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa66f08: stp             lr, x16, [SP, #-0x10]!
    // 0xa66f0c: r0 = +()
    //     0xa66f0c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xa66f10: add             SP, SP, #0x10
    // 0xa66f14: ldr             x16, [fp, #0x18]
    // 0xa66f18: stp             x0, x16, [SP, #-0x10]!
    // 0xa66f1c: ldur            d0, [fp, #-0x28]
    // 0xa66f20: SaveReg d0
    //     0xa66f20: str             d0, [SP, #-8]!
    // 0xa66f24: ldur            x16, [fp, #-0x20]
    // 0xa66f28: SaveReg r16
    //     0xa66f28: str             x16, [SP, #-8]!
    // 0xa66f2c: r0 = drawCircle()
    //     0xa66f2c: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xa66f30: add             SP, SP, #0x20
    // 0xa66f34: r0 = Null
    //     0xa66f34: mov             x0, NULL
    // 0xa66f38: LeaveFrame
    //     0xa66f38: mov             SP, fp
    //     0xa66f3c: ldp             fp, lr, [SP], #0x10
    // 0xa66f40: ret
    //     0xa66f40: ret             
    // 0xa66f44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa66f44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa66f48: b               #0xa66c28
    // 0xa66f4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa66f84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa66f84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

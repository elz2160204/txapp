// lib: , url: package:flutter/src/material/bottom_app_bar_theme.dart

// class id: 1049189, size: 0x8
class :: {
}

// class id: 2838, size: 0x20, field offset: 0x8
//   const constructor, 
class BottomAppBarTheme extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafdd3c, size: 0x6c
    // 0xafdd3c: EnterFrame
    //     0xafdd3c: stp             fp, lr, [SP, #-0x10]!
    //     0xafdd40: mov             fp, SP
    // 0xafdd44: CheckStackOverflow
    //     0xafdd44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafdd48: cmp             SP, x16
    //     0xafdd4c: b.ls            #0xafdda0
    // 0xafdd50: ldr             x0, [fp, #0x10]
    // 0xafdd54: LoadField: r1 = r0->field_b
    //     0xafdd54: ldur            w1, [x0, #0xb]
    // 0xafdd58: DecompressPointer r1
    //     0xafdd58: add             x1, x1, HEAP, lsl #32
    // 0xafdd5c: LoadField: r2 = r0->field_13
    //     0xafdd5c: ldur            w2, [x0, #0x13]
    // 0xafdd60: DecompressPointer r2
    //     0xafdd60: add             x2, x2, HEAP, lsl #32
    // 0xafdd64: stp             x1, NULL, [SP, #-0x10]!
    // 0xafdd68: stp             x2, NULL, [SP, #-0x10]!
    // 0xafdd6c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xafdd70: r4 = const [0, 0x6, 0x6, 0x6, null]
    //     0xafdd70: ldr             x4, [PP, #0x1228]  ; [pp+0x1228] List(5) [0, 0x6, 0x6, 0x6, Null]
    // 0xafdd74: r0 = hash()
    //     0xafdd74: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafdd78: add             SP, SP, #0x30
    // 0xafdd7c: mov             x2, x0
    // 0xafdd80: r0 = BoxInt64Instr(r2)
    //     0xafdd80: sbfiz           x0, x2, #1, #0x1f
    //     0xafdd84: cmp             x2, x0, asr #1
    //     0xafdd88: b.eq            #0xafdd94
    //     0xafdd8c: bl              #0xd69bb8
    //     0xafdd90: stur            x2, [x0, #7]
    // 0xafdd94: LeaveFrame
    //     0xafdd94: mov             SP, fp
    //     0xafdd98: ldp             fp, lr, [SP], #0x10
    // 0xafdd9c: ret
    //     0xafdd9c: ret             
    // 0xafdda0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafdda0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafdda4: b               #0xafdd50
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf5d48, size: 0x11c
    // 0xbf5d48: EnterFrame
    //     0xbf5d48: stp             fp, lr, [SP, #-0x10]!
    //     0xbf5d4c: mov             fp, SP
    // 0xbf5d50: AllocStack(0x18)
    //     0xbf5d50: sub             SP, SP, #0x18
    // 0xbf5d54: CheckStackOverflow
    //     0xbf5d54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf5d58: cmp             SP, x16
    //     0xbf5d5c: b.ls            #0xbf5e4c
    // 0xbf5d60: ldr             d0, [fp, #0x10]
    // 0xbf5d64: r0 = inline_Allocate_Double()
    //     0xbf5d64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf5d68: add             x0, x0, #0x10
    //     0xbf5d6c: cmp             x1, x0
    //     0xbf5d70: b.ls            #0xbf5e54
    //     0xbf5d74: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf5d78: sub             x0, x0, #0xf
    //     0xbf5d7c: mov             x1, #0xd108
    //     0xbf5d80: movk            x1, #3, lsl #16
    //     0xbf5d84: stur            x1, [x0, #-1]
    // 0xbf5d88: StoreField: r0->field_7 = d0
    //     0xbf5d88: stur            d0, [x0, #7]
    // 0xbf5d8c: stur            x0, [fp, #-8]
    // 0xbf5d90: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5d94: SaveReg r0
    //     0xbf5d94: str             x0, [SP, #-8]!
    // 0xbf5d98: r0 = lerp()
    //     0xbf5d98: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5d9c: add             SP, SP, #0x18
    // 0xbf5da0: ldr             x0, [fp, #0x20]
    // 0xbf5da4: LoadField: r1 = r0->field_b
    //     0xbf5da4: ldur            w1, [x0, #0xb]
    // 0xbf5da8: DecompressPointer r1
    //     0xbf5da8: add             x1, x1, HEAP, lsl #32
    // 0xbf5dac: ldr             x2, [fp, #0x18]
    // 0xbf5db0: LoadField: r3 = r2->field_b
    //     0xbf5db0: ldur            w3, [x2, #0xb]
    // 0xbf5db4: DecompressPointer r3
    //     0xbf5db4: add             x3, x3, HEAP, lsl #32
    // 0xbf5db8: stp             x3, x1, [SP, #-0x10]!
    // 0xbf5dbc: ldur            x16, [fp, #-8]
    // 0xbf5dc0: SaveReg r16
    //     0xbf5dc0: str             x16, [SP, #-8]!
    // 0xbf5dc4: r0 = lerpDouble()
    //     0xbf5dc4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5dc8: add             SP, SP, #0x18
    // 0xbf5dcc: mov             x1, x0
    // 0xbf5dd0: ldr             x0, [fp, #0x20]
    // 0xbf5dd4: stur            x1, [fp, #-0x10]
    // 0xbf5dd8: LoadField: r2 = r0->field_13
    //     0xbf5dd8: ldur            w2, [x0, #0x13]
    // 0xbf5ddc: DecompressPointer r2
    //     0xbf5ddc: add             x2, x2, HEAP, lsl #32
    // 0xbf5de0: ldr             x0, [fp, #0x18]
    // 0xbf5de4: LoadField: r3 = r0->field_13
    //     0xbf5de4: ldur            w3, [x0, #0x13]
    // 0xbf5de8: DecompressPointer r3
    //     0xbf5de8: add             x3, x3, HEAP, lsl #32
    // 0xbf5dec: stp             x3, x2, [SP, #-0x10]!
    // 0xbf5df0: ldur            x16, [fp, #-8]
    // 0xbf5df4: SaveReg r16
    //     0xbf5df4: str             x16, [SP, #-8]!
    // 0xbf5df8: r0 = lerpDouble()
    //     0xbf5df8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf5dfc: add             SP, SP, #0x18
    // 0xbf5e00: stur            x0, [fp, #-0x18]
    // 0xbf5e04: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5e08: ldur            x16, [fp, #-8]
    // 0xbf5e0c: SaveReg r16
    //     0xbf5e0c: str             x16, [SP, #-8]!
    // 0xbf5e10: r0 = lerp()
    //     0xbf5e10: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf5e14: add             SP, SP, #0x18
    // 0xbf5e18: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf5e1c: ldur            x16, [fp, #-8]
    // 0xbf5e20: SaveReg r16
    //     0xbf5e20: str             x16, [SP, #-8]!
    // 0xbf5e24: r0 = lerp()
    //     0xbf5e24: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xbf5e28: add             SP, SP, #0x18
    // 0xbf5e2c: r0 = BottomAppBarTheme()
    //     0xbf5e2c: bl              #0xbf5e64  ; AllocateBottomAppBarThemeStub -> BottomAppBarTheme (size=0x20)
    // 0xbf5e30: ldur            x1, [fp, #-0x10]
    // 0xbf5e34: StoreField: r0->field_b = r1
    //     0xbf5e34: stur            w1, [x0, #0xb]
    // 0xbf5e38: ldur            x1, [fp, #-0x18]
    // 0xbf5e3c: StoreField: r0->field_13 = r1
    //     0xbf5e3c: stur            w1, [x0, #0x13]
    // 0xbf5e40: LeaveFrame
    //     0xbf5e40: mov             SP, fp
    //     0xbf5e44: ldp             fp, lr, [SP], #0x10
    // 0xbf5e48: ret
    //     0xbf5e48: ret             
    // 0xbf5e4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf5e4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf5e50: b               #0xbf5d60
    // 0xbf5e54: SaveReg d0
    //     0xbf5e54: str             q0, [SP, #-0x10]!
    // 0xbf5e58: r0 = AllocateDouble()
    //     0xbf5e58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf5e5c: RestoreReg d0
    //     0xbf5e5c: ldr             q0, [SP], #0x10
    // 0xbf5e60: b               #0xbf5d88
  }
  _ ==(/* No info */) {
    // ** addr: 0xc83654, size: 0x168
    // 0xc83654: EnterFrame
    //     0xc83654: stp             fp, lr, [SP, #-0x10]!
    //     0xc83658: mov             fp, SP
    // 0xc8365c: CheckStackOverflow
    //     0xc8365c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc83660: cmp             SP, x16
    //     0xc83664: b.ls            #0xc837b4
    // 0xc83668: ldr             x1, [fp, #0x10]
    // 0xc8366c: cmp             w1, NULL
    // 0xc83670: b.ne            #0xc83684
    // 0xc83674: r0 = false
    //     0xc83674: add             x0, NULL, #0x30  ; false
    // 0xc83678: LeaveFrame
    //     0xc83678: mov             SP, fp
    //     0xc8367c: ldp             fp, lr, [SP], #0x10
    // 0xc83680: ret
    //     0xc83680: ret             
    // 0xc83684: ldr             x2, [fp, #0x18]
    // 0xc83688: cmp             w2, w1
    // 0xc8368c: b.ne            #0xc836a0
    // 0xc83690: r0 = true
    //     0xc83690: add             x0, NULL, #0x20  ; true
    // 0xc83694: LeaveFrame
    //     0xc83694: mov             SP, fp
    //     0xc83698: ldp             fp, lr, [SP], #0x10
    // 0xc8369c: ret
    //     0xc8369c: ret             
    // 0xc836a0: r0 = 59
    //     0xc836a0: mov             x0, #0x3b
    // 0xc836a4: branchIfSmi(r1, 0xc836b0)
    //     0xc836a4: tbz             w1, #0, #0xc836b0
    // 0xc836a8: r0 = LoadClassIdInstr(r1)
    //     0xc836a8: ldur            x0, [x1, #-1]
    //     0xc836ac: ubfx            x0, x0, #0xc, #0x14
    // 0xc836b0: SaveReg r1
    //     0xc836b0: str             x1, [SP, #-8]!
    // 0xc836b4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc836b4: mov             x17, #0x57c5
    //     0xc836b8: add             lr, x0, x17
    //     0xc836bc: ldr             lr, [x21, lr, lsl #3]
    //     0xc836c0: blr             lr
    // 0xc836c4: add             SP, SP, #8
    // 0xc836c8: r1 = LoadClassIdInstr(r0)
    //     0xc836c8: ldur            x1, [x0, #-1]
    //     0xc836cc: ubfx            x1, x1, #0xc, #0x14
    // 0xc836d0: r16 = BottomAppBarTheme
    //     0xc836d0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe4a0] Type: BottomAppBarTheme
    //     0xc836d4: ldr             x16, [x16, #0x4a0]
    // 0xc836d8: stp             x16, x0, [SP, #-0x10]!
    // 0xc836dc: mov             x0, x1
    // 0xc836e0: mov             lr, x0
    // 0xc836e4: ldr             lr, [x21, lr, lsl #3]
    // 0xc836e8: blr             lr
    // 0xc836ec: add             SP, SP, #0x10
    // 0xc836f0: tbz             w0, #4, #0xc83704
    // 0xc836f4: r0 = false
    //     0xc836f4: add             x0, NULL, #0x30  ; false
    // 0xc836f8: LeaveFrame
    //     0xc836f8: mov             SP, fp
    //     0xc836fc: ldp             fp, lr, [SP], #0x10
    // 0xc83700: ret
    //     0xc83700: ret             
    // 0xc83704: ldr             x1, [fp, #0x10]
    // 0xc83708: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc83708: mov             x0, #0x76
    //     0xc8370c: tbz             w1, #0, #0xc8371c
    //     0xc83710: ldur            x0, [x1, #-1]
    //     0xc83714: ubfx            x0, x0, #0xc, #0x14
    //     0xc83718: lsl             x0, x0, #1
    // 0xc8371c: r17 = 5676
    //     0xc8371c: mov             x17, #0x162c
    // 0xc83720: cmp             w0, w17
    // 0xc83724: b.ne            #0xc837a4
    // 0xc83728: ldr             x2, [fp, #0x18]
    // 0xc8372c: LoadField: r0 = r1->field_b
    //     0xc8372c: ldur            w0, [x1, #0xb]
    // 0xc83730: DecompressPointer r0
    //     0xc83730: add             x0, x0, HEAP, lsl #32
    // 0xc83734: LoadField: r3 = r2->field_b
    //     0xc83734: ldur            w3, [x2, #0xb]
    // 0xc83738: DecompressPointer r3
    //     0xc83738: add             x3, x3, HEAP, lsl #32
    // 0xc8373c: r4 = LoadClassIdInstr(r0)
    //     0xc8373c: ldur            x4, [x0, #-1]
    //     0xc83740: ubfx            x4, x4, #0xc, #0x14
    // 0xc83744: stp             x3, x0, [SP, #-0x10]!
    // 0xc83748: mov             x0, x4
    // 0xc8374c: mov             lr, x0
    // 0xc83750: ldr             lr, [x21, lr, lsl #3]
    // 0xc83754: blr             lr
    // 0xc83758: add             SP, SP, #0x10
    // 0xc8375c: tbnz            w0, #4, #0xc837a4
    // 0xc83760: ldr             x1, [fp, #0x18]
    // 0xc83764: ldr             x0, [fp, #0x10]
    // 0xc83768: LoadField: r2 = r0->field_13
    //     0xc83768: ldur            w2, [x0, #0x13]
    // 0xc8376c: DecompressPointer r2
    //     0xc8376c: add             x2, x2, HEAP, lsl #32
    // 0xc83770: LoadField: r0 = r1->field_13
    //     0xc83770: ldur            w0, [x1, #0x13]
    // 0xc83774: DecompressPointer r0
    //     0xc83774: add             x0, x0, HEAP, lsl #32
    // 0xc83778: r1 = LoadClassIdInstr(r2)
    //     0xc83778: ldur            x1, [x2, #-1]
    //     0xc8377c: ubfx            x1, x1, #0xc, #0x14
    // 0xc83780: stp             x0, x2, [SP, #-0x10]!
    // 0xc83784: mov             x0, x1
    // 0xc83788: mov             lr, x0
    // 0xc8378c: ldr             lr, [x21, lr, lsl #3]
    // 0xc83790: blr             lr
    // 0xc83794: add             SP, SP, #0x10
    // 0xc83798: tbnz            w0, #4, #0xc837a4
    // 0xc8379c: r0 = true
    //     0xc8379c: add             x0, NULL, #0x20  ; true
    // 0xc837a0: b               #0xc837a8
    // 0xc837a4: r0 = false
    //     0xc837a4: add             x0, NULL, #0x30  ; false
    // 0xc837a8: LeaveFrame
    //     0xc837a8: mov             SP, fp
    //     0xc837ac: ldp             fp, lr, [SP], #0x10
    // 0xc837b0: ret
    //     0xc837b0: ret             
    // 0xc837b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc837b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc837b8: b               #0xc83668
  }
}

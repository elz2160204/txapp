// lib: , url: package:flutter/src/material/ink_ripple.dart

// class id: 1049256, size: 0x8
class :: {

  static _ _getTargetRadius(/* No info */) {
    // ** addr: 0x857088, size: 0x144
    // 0x857088: EnterFrame
    //     0x857088: stp             fp, lr, [SP, #-0x10]!
    //     0x85708c: mov             fp, SP
    // 0x857090: AllocStack(0x18)
    //     0x857090: sub             SP, SP, #0x18
    // 0x857094: CheckStackOverflow
    //     0x857094: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x857098: cmp             SP, x16
    //     0x85709c: b.ls            #0x8571c0
    // 0x8570a0: ldr             x0, [fp, #0x10]
    // 0x8570a4: cmp             w0, NULL
    // 0x8570a8: b.eq            #0x8570d0
    // 0x8570ac: SaveReg r0
    //     0x8570ac: str             x0, [SP, #-8]!
    // 0x8570b0: ClosureCall
    //     0x8570b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8570b4: ldur            x2, [x0, #0x1f]
    //     0x8570b8: blr             x2
    // 0x8570bc: add             SP, SP, #8
    // 0x8570c0: SaveReg r0
    //     0x8570c0: str             x0, [SP, #-8]!
    // 0x8570c4: r0 = size()
    //     0x8570c4: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x8570c8: add             SP, SP, #8
    // 0x8570cc: b               #0x8570e8
    // 0x8570d0: ldr             x0, [fp, #0x18]
    // 0x8570d4: LoadField: r1 = r0->field_57
    //     0x8570d4: ldur            w1, [x0, #0x57]
    // 0x8570d8: DecompressPointer r1
    //     0x8570d8: add             x1, x1, HEAP, lsl #32
    // 0x8570dc: cmp             w1, NULL
    // 0x8570e0: b.eq            #0x8571c8
    // 0x8570e4: mov             x0, x1
    // 0x8570e8: stur            x0, [fp, #-8]
    // 0x8570ec: SaveReg r0
    //     0x8570ec: str             x0, [SP, #-8]!
    // 0x8570f0: r0 = bottomRight()
    //     0x8570f0: bl              #0x857264  ; [dart:ui] Size::bottomRight
    // 0x8570f4: add             SP, SP, #8
    // 0x8570f8: LoadField: d0 = r0->field_7
    //     0x8570f8: ldur            d0, [x0, #7]
    // 0x8570fc: fmul            d1, d0, d0
    // 0x857100: LoadField: d0 = r0->field_f
    //     0x857100: ldur            d0, [x0, #0xf]
    // 0x857104: fmul            d2, d0, d0
    // 0x857108: fadd            d0, d1, d2
    // 0x85710c: fsqrt           d1, d0
    // 0x857110: stur            d1, [fp, #-0x18]
    // 0x857114: ldur            x16, [fp, #-8]
    // 0x857118: SaveReg r16
    //     0x857118: str             x16, [SP, #-8]!
    // 0x85711c: r0 = topRight()
    //     0x85711c: bl              #0x857218  ; [dart:ui] Size::topRight
    // 0x857120: add             SP, SP, #8
    // 0x857124: stur            x0, [fp, #-0x10]
    // 0x857128: ldur            x16, [fp, #-8]
    // 0x85712c: SaveReg r16
    //     0x85712c: str             x16, [SP, #-8]!
    // 0x857130: r0 = bottomLeft()
    //     0x857130: bl              #0x8571cc  ; [dart:ui] Size::bottomLeft
    // 0x857134: add             SP, SP, #8
    // 0x857138: ldur            x16, [fp, #-0x10]
    // 0x85713c: stp             x0, x16, [SP, #-0x10]!
    // 0x857140: r0 = -()
    //     0x857140: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x857144: add             SP, SP, #0x10
    // 0x857148: LoadField: d1 = r0->field_7
    //     0x857148: ldur            d1, [x0, #7]
    // 0x85714c: fmul            d2, d1, d1
    // 0x857150: LoadField: d1 = r0->field_f
    //     0x857150: ldur            d1, [x0, #0xf]
    // 0x857154: fmul            d3, d1, d1
    // 0x857158: fadd            d1, d2, d3
    // 0x85715c: fsqrt           d2, d1
    // 0x857160: ldur            d1, [fp, #-0x18]
    // 0x857164: fcmp            d1, d2
    // 0x857168: b.vs            #0x857178
    // 0x85716c: b.le            #0x857178
    // 0x857170: mov             v2.16b, v1.16b
    // 0x857174: b               #0x8571ac
    // 0x857178: fcmp            d1, d2
    // 0x85717c: b.vs            #0x857184
    // 0x857180: b.lt            #0x8571ac
    // 0x857184: d3 = 0.000000
    //     0x857184: eor             v3.16b, v3.16b, v3.16b
    // 0x857188: fcmp            d1, d3
    // 0x85718c: b.vs            #0x8571a0
    // 0x857190: b.ne            #0x8571a0
    // 0x857194: fadd            d3, d1, d2
    // 0x857198: mov             v2.16b, v3.16b
    // 0x85719c: b               #0x8571ac
    // 0x8571a0: fcmp            d2, d2
    // 0x8571a4: b.vs            #0x8571ac
    // 0x8571a8: mov             v2.16b, v1.16b
    // 0x8571ac: d1 = 2.000000
    //     0x8571ac: fmov            d1, #2.00000000
    // 0x8571b0: fdiv            d0, d2, d1
    // 0x8571b4: LeaveFrame
    //     0x8571b4: mov             SP, fp
    //     0x8571b8: ldp             fp, lr, [SP], #0x10
    // 0x8571bc: ret
    //     0x8571bc: ret             
    // 0x8571c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8571c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8571c4: b               #0x8570a0
    // 0x8571c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8571c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static Rect <anonymous closure>(dynamic) {
    // ** addr: 0x8573a4, size: 0x60
    // 0x8573a4: EnterFrame
    //     0x8573a4: stp             fp, lr, [SP, #-0x10]!
    //     0x8573a8: mov             fp, SP
    // 0x8573ac: ldr             x0, [fp, #0x10]
    // 0x8573b0: LoadField: r1 = r0->field_17
    //     0x8573b0: ldur            w1, [x0, #0x17]
    // 0x8573b4: DecompressPointer r1
    //     0x8573b4: add             x1, x1, HEAP, lsl #32
    // 0x8573b8: CheckStackOverflow
    //     0x8573b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8573bc: cmp             SP, x16
    //     0x8573c0: b.ls            #0x8573f8
    // 0x8573c4: LoadField: r0 = r1->field_f
    //     0x8573c4: ldur            w0, [x1, #0xf]
    // 0x8573c8: DecompressPointer r0
    //     0x8573c8: add             x0, x0, HEAP, lsl #32
    // 0x8573cc: LoadField: r1 = r0->field_57
    //     0x8573cc: ldur            w1, [x0, #0x57]
    // 0x8573d0: DecompressPointer r1
    //     0x8573d0: add             x1, x1, HEAP, lsl #32
    // 0x8573d4: cmp             w1, NULL
    // 0x8573d8: b.eq            #0x857400
    // 0x8573dc: r16 = Instance_Offset
    //     0x8573dc: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x8573e0: stp             x1, x16, [SP, #-0x10]!
    // 0x8573e4: r0 = &()
    //     0x8573e4: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x8573e8: add             SP, SP, #0x10
    // 0x8573ec: LeaveFrame
    //     0x8573ec: mov             SP, fp
    //     0x8573f0: ldp             fp, lr, [SP], #0x10
    // 0x8573f4: ret
    //     0x8573f4: ret             
    // 0x8573f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8573f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8573fc: b               #0x8573c4
    // 0x857400: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857400: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2193, size: 0x8, field offset: 0x8
//   const constructor, 
class _InkRippleFactory extends InteractiveInkFeatureFactory {
}

// class id: 2198, size: 0x4c, field offset: 0x18
class InkRipple extends InteractiveInkFeature {

  late AnimationController _radiusController; // offset: 0x38
  late AnimationController _fadeInController; // offset: 0x40
  late AnimationController _fadeOutController; // offset: 0x48
  static late final Animatable<double> _easeCurveTween; // offset: 0xda0
  static late final Animatable<double> _fadeOutIntervalTween; // offset: 0xda4
  late Animation<int> _fadeIn; // offset: 0x3c
  late Animation<int> _fadeOut; // offset: 0x44
  late Animation<double> _radius; // offset: 0x34

  _ InkRipple(/* No info */) {
    // ** addr: 0x85699c, size: 0x6ec
    // 0x85699c: EnterFrame
    //     0x85699c: stp             fp, lr, [SP, #-0x10]!
    //     0x8569a0: mov             fp, SP
    // 0x8569a4: AllocStack(0x40)
    //     0x8569a4: sub             SP, SP, #0x40
    // 0x8569a8: r0 = Sentinel
    //     0x8569a8: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8569ac: CheckStackOverflow
    //     0x8569ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8569b0: cmp             SP, x16
    //     0x8569b4: b.ls            #0x857050
    // 0x8569b8: ldr             x1, [fp, #0x68]
    // 0x8569bc: StoreField: r1->field_33 = r0
    //     0x8569bc: stur            w0, [x1, #0x33]
    // 0x8569c0: StoreField: r1->field_37 = r0
    //     0x8569c0: stur            w0, [x1, #0x37]
    // 0x8569c4: StoreField: r1->field_3b = r0
    //     0x8569c4: stur            w0, [x1, #0x3b]
    // 0x8569c8: StoreField: r1->field_3f = r0
    //     0x8569c8: stur            w0, [x1, #0x3f]
    // 0x8569cc: StoreField: r1->field_43 = r0
    //     0x8569cc: stur            w0, [x1, #0x43]
    // 0x8569d0: StoreField: r1->field_47 = r0
    //     0x8569d0: stur            w0, [x1, #0x47]
    // 0x8569d4: ldr             x0, [fp, #0x30]
    // 0x8569d8: StoreField: r1->field_17 = r0
    //     0x8569d8: stur            w0, [x1, #0x17]
    //     0x8569dc: ldurb           w16, [x1, #-1]
    //     0x8569e0: ldurb           w17, [x0, #-1]
    //     0x8569e4: and             x16, x17, x16, lsr #2
    //     0x8569e8: tst             x16, HEAP, lsr #32
    //     0x8569ec: b.eq            #0x8569f4
    //     0x8569f0: bl              #0xd6826c
    // 0x8569f4: ldr             x0, [fp, #0x60]
    // 0x8569f8: cmp             w0, NULL
    // 0x8569fc: b.ne            #0x856a08
    // 0x856a00: r0 = Instance_BorderRadius
    //     0x856a00: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x856a04: ldr             x0, [x0, #0x2c0]
    // 0x856a08: ldr             x2, [fp, #0x28]
    // 0x856a0c: StoreField: r1->field_1b = r0
    //     0x856a0c: stur            w0, [x1, #0x1b]
    //     0x856a10: ldurb           w16, [x1, #-1]
    //     0x856a14: ldurb           w17, [x0, #-1]
    //     0x856a18: and             x16, x17, x16, lsr #2
    //     0x856a1c: tst             x16, HEAP, lsr #32
    //     0x856a20: b.eq            #0x856a28
    //     0x856a24: bl              #0xd6826c
    // 0x856a28: ldr             x0, [fp, #0x40]
    // 0x856a2c: StoreField: r1->field_1f = r0
    //     0x856a2c: stur            w0, [x1, #0x1f]
    //     0x856a30: ldurb           w16, [x1, #-1]
    //     0x856a34: ldurb           w17, [x0, #-1]
    //     0x856a38: and             x16, x17, x16, lsr #2
    //     0x856a3c: tst             x16, HEAP, lsr #32
    //     0x856a40: b.eq            #0x856a48
    //     0x856a44: bl              #0xd6826c
    // 0x856a48: ldr             x0, [fp, #0x10]
    // 0x856a4c: StoreField: r1->field_2f = r0
    //     0x856a4c: stur            w0, [x1, #0x2f]
    //     0x856a50: ldurb           w16, [x1, #-1]
    //     0x856a54: ldurb           w17, [x0, #-1]
    //     0x856a58: and             x16, x17, x16, lsr #2
    //     0x856a5c: tst             x16, HEAP, lsr #32
    //     0x856a60: b.eq            #0x856a68
    //     0x856a64: bl              #0xd6826c
    // 0x856a68: cmp             w2, NULL
    // 0x856a6c: b.ne            #0x856a88
    // 0x856a70: ldr             x16, [fp, #0x18]
    // 0x856a74: ldr             lr, [fp, #0x20]
    // 0x856a78: stp             lr, x16, [SP, #-0x10]!
    // 0x856a7c: r0 = _getTargetRadius()
    //     0x856a7c: bl              #0x857088  ; [package:flutter/src/material/ink_ripple.dart] ::_getTargetRadius
    // 0x856a80: add             SP, SP, #0x10
    // 0x856a84: b               #0x856a8c
    // 0x856a88: LoadField: d0 = r2->field_7
    //     0x856a88: ldur            d0, [x2, #7]
    // 0x856a8c: ldr             x0, [fp, #0x68]
    // 0x856a90: ldr             x2, [fp, #0x20]
    // 0x856a94: ldr             x1, [fp, #0x18]
    // 0x856a98: stur            d0, [fp, #-0x38]
    // 0x856a9c: StoreField: r0->field_23 = d0
    //     0x856a9c: stur            d0, [x0, #0x23]
    // 0x856aa0: r1 = 1
    //     0x856aa0: mov             x1, #1
    // 0x856aa4: r0 = AllocateContext()
    //     0x856aa4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x856aa8: mov             x1, x0
    // 0x856aac: ldr             x0, [fp, #0x18]
    // 0x856ab0: StoreField: r1->field_f = r0
    //     0x856ab0: stur            w0, [x1, #0xf]
    // 0x856ab4: ldr             x2, [fp, #0x20]
    // 0x856ab8: cmp             w2, NULL
    // 0x856abc: b.eq            #0x856ac8
    // 0x856ac0: mov             x0, x2
    // 0x856ac4: b               #0x856ae8
    // 0x856ac8: ldr             x2, [fp, #0x50]
    // 0x856acc: tbnz            w2, #4, #0x856ae4
    // 0x856ad0: mov             x2, x1
    // 0x856ad4: r1 = Function '<anonymous closure>': static.
    //     0x856ad4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e350] AnonymousClosure: static (0x8573a4), of [package:flutter/src/material/ink_ripple.dart] 
    //     0x856ad8: ldr             x1, [x1, #0x350]
    // 0x856adc: r0 = AllocateClosure()
    //     0x856adc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x856ae0: b               #0x856ae8
    // 0x856ae4: r0 = Null
    //     0x856ae4: mov             x0, NULL
    // 0x856ae8: ldr             x2, [fp, #0x68]
    // 0x856aec: ldr             x4, [fp, #0x58]
    // 0x856af0: ldr             x3, [fp, #0x48]
    // 0x856af4: StoreField: r2->field_2b = r0
    //     0x856af4: stur            w0, [x2, #0x2b]
    //     0x856af8: tbz             w0, #0, #0x856b14
    //     0x856afc: ldurb           w16, [x2, #-1]
    //     0x856b00: ldurb           w17, [x0, #-1]
    //     0x856b04: and             x16, x17, x16, lsr #2
    //     0x856b08: tst             x16, HEAP, lsr #32
    //     0x856b0c: b.eq            #0x856b14
    //     0x856b10: bl              #0xd6828c
    // 0x856b14: mov             x0, x4
    // 0x856b18: StoreField: r2->field_13 = r0
    //     0x856b18: stur            w0, [x2, #0x13]
    //     0x856b1c: ldurb           w16, [x2, #-1]
    //     0x856b20: ldurb           w17, [x0, #-1]
    //     0x856b24: and             x16, x17, x16, lsr #2
    //     0x856b28: tst             x16, HEAP, lsr #32
    //     0x856b2c: b.eq            #0x856b34
    //     0x856b30: bl              #0xd6828c
    // 0x856b34: ldr             x0, [fp, #0x18]
    // 0x856b38: StoreField: r2->field_b = r0
    //     0x856b38: stur            w0, [x2, #0xb]
    //     0x856b3c: ldurb           w16, [x2, #-1]
    //     0x856b40: ldurb           w17, [x0, #-1]
    //     0x856b44: and             x16, x17, x16, lsr #2
    //     0x856b48: tst             x16, HEAP, lsr #32
    //     0x856b4c: b.eq            #0x856b54
    //     0x856b50: bl              #0xd6828c
    // 0x856b54: ldr             x0, [fp, #0x38]
    // 0x856b58: StoreField: r2->field_f = r0
    //     0x856b58: stur            w0, [x2, #0xf]
    //     0x856b5c: ldurb           w16, [x2, #-1]
    //     0x856b60: ldurb           w17, [x0, #-1]
    //     0x856b64: and             x16, x17, x16, lsr #2
    //     0x856b68: tst             x16, HEAP, lsr #32
    //     0x856b6c: b.eq            #0x856b74
    //     0x856b70: bl              #0xd6828c
    // 0x856b74: mov             x0, x3
    // 0x856b78: StoreField: r2->field_7 = r0
    //     0x856b78: stur            w0, [x2, #7]
    //     0x856b7c: ldurb           w16, [x2, #-1]
    //     0x856b80: ldurb           w17, [x0, #-1]
    //     0x856b84: and             x16, x17, x16, lsr #2
    //     0x856b88: tst             x16, HEAP, lsr #32
    //     0x856b8c: b.eq            #0x856b94
    //     0x856b90: bl              #0xd6828c
    // 0x856b94: LoadField: r0 = r3->field_63
    //     0x856b94: ldur            w0, [x3, #0x63]
    // 0x856b98: DecompressPointer r0
    //     0x856b98: add             x0, x0, HEAP, lsl #32
    // 0x856b9c: stur            x0, [fp, #-8]
    // 0x856ba0: r1 = <double>
    //     0x856ba0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x856ba4: r0 = AnimationController()
    //     0x856ba4: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x856ba8: stur            x0, [fp, #-0x10]
    // 0x856bac: ldur            x16, [fp, #-8]
    // 0x856bb0: stp             x16, x0, [SP, #-0x10]!
    // 0x856bb4: r16 = Instance_Duration
    //     0x856bb4: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e300] Obj!Duration@b67bc1
    //     0x856bb8: ldr             x16, [x16, #0x300]
    // 0x856bbc: SaveReg r16
    //     0x856bbc: str             x16, [SP, #-8]!
    // 0x856bc0: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x856bc0: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x856bc4: ldr             x4, [x4, #0xa0]
    // 0x856bc8: r0 = AnimationController()
    //     0x856bc8: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x856bcc: add             SP, SP, #0x18
    // 0x856bd0: r1 = 1
    //     0x856bd0: mov             x1, #1
    // 0x856bd4: r0 = AllocateContext()
    //     0x856bd4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x856bd8: mov             x1, x0
    // 0x856bdc: ldr             x0, [fp, #0x48]
    // 0x856be0: StoreField: r1->field_f = r0
    //     0x856be0: stur            w0, [x1, #0xf]
    // 0x856be4: mov             x2, x1
    // 0x856be8: r1 = Function 'markNeedsPaint':.
    //     0x856be8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x856bec: ldr             x1, [x1, #0xf60]
    // 0x856bf0: r0 = AllocateClosure()
    //     0x856bf0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x856bf4: ldur            x16, [fp, #-0x10]
    // 0x856bf8: stp             x0, x16, [SP, #-0x10]!
    // 0x856bfc: r0 = addActionListener()
    //     0x856bfc: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x856c00: add             SP, SP, #0x10
    // 0x856c04: ldur            x16, [fp, #-0x10]
    // 0x856c08: SaveReg r16
    //     0x856c08: str             x16, [SP, #-8]!
    // 0x856c0c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x856c0c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x856c10: r0 = forward()
    //     0x856c10: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x856c14: add             SP, SP, #8
    // 0x856c18: ldur            x0, [fp, #-0x10]
    // 0x856c1c: ldr             x2, [fp, #0x68]
    // 0x856c20: StoreField: r2->field_3f = r0
    //     0x856c20: stur            w0, [x2, #0x3f]
    //     0x856c24: ldurb           w16, [x2, #-1]
    //     0x856c28: ldurb           w17, [x0, #-1]
    //     0x856c2c: and             x16, x17, x16, lsr #2
    //     0x856c30: tst             x16, HEAP, lsr #32
    //     0x856c34: b.eq            #0x856c3c
    //     0x856c38: bl              #0xd6828c
    // 0x856c3c: ldr             x0, [fp, #0x58]
    // 0x856c40: r3 = LoadClassIdInstr(r0)
    //     0x856c40: ldur            x3, [x0, #-1]
    //     0x856c44: ubfx            x3, x3, #0xc, #0x14
    // 0x856c48: lsl             x3, x3, #1
    // 0x856c4c: stur            x3, [fp, #-0x20]
    // 0x856c50: r17 = 10124
    //     0x856c50: mov             x17, #0x278c
    // 0x856c54: cmp             w3, w17
    // 0x856c58: b.gt            #0x856c68
    // 0x856c5c: r17 = 10122
    //     0x856c5c: mov             x17, #0x278a
    // 0x856c60: cmp             w3, w17
    // 0x856c64: b.ge            #0x856c80
    // 0x856c68: r17 = 10114
    //     0x856c68: mov             x17, #0x2782
    // 0x856c6c: cmp             w3, w17
    // 0x856c70: b.eq            #0x856c80
    // 0x856c74: r17 = 10118
    //     0x856c74: mov             x17, #0x2786
    // 0x856c78: cmp             w3, w17
    // 0x856c7c: b.ne            #0x856c88
    // 0x856c80: LoadField: r1 = r0->field_7
    //     0x856c80: ldur            x1, [x0, #7]
    // 0x856c84: b               #0x856c98
    // 0x856c88: LoadField: r1 = r0->field_f
    //     0x856c88: ldur            w1, [x0, #0xf]
    // 0x856c8c: DecompressPointer r1
    //     0x856c8c: add             x1, x1, HEAP, lsl #32
    // 0x856c90: LoadField: r4 = r1->field_7
    //     0x856c90: ldur            x4, [x1, #7]
    // 0x856c94: mov             x1, x4
    // 0x856c98: ldr             x4, [fp, #0x48]
    // 0x856c9c: ldur            d0, [fp, #-0x38]
    // 0x856ca0: r5 = 4278190080
    //     0x856ca0: mov             x5, #0xff000000
    // 0x856ca4: ubfx            x1, x1, #0, #0x20
    // 0x856ca8: and             x6, x1, x5
    // 0x856cac: ubfx            x6, x6, #0, #0x20
    // 0x856cb0: asr             x7, x6, #0x18
    // 0x856cb4: stur            x7, [fp, #-0x18]
    // 0x856cb8: r1 = <int>
    //     0x856cb8: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x856cbc: r0 = IntTween()
    //     0x856cbc: bl              #0x7b2798  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0x856cc0: StoreField: r0->field_b = rZR
    //     0x856cc0: stur            wzr, [x0, #0xb]
    // 0x856cc4: ldur            x1, [fp, #-0x18]
    // 0x856cc8: lsl             x2, x1, #1
    // 0x856ccc: StoreField: r0->field_f = r2
    //     0x856ccc: stur            w2, [x0, #0xf]
    // 0x856cd0: ldur            x16, [fp, #-0x10]
    // 0x856cd4: stp             x16, x0, [SP, #-0x10]!
    // 0x856cd8: r0 = animate()
    //     0x856cd8: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x856cdc: add             SP, SP, #0x10
    // 0x856ce0: ldr             x2, [fp, #0x68]
    // 0x856ce4: StoreField: r2->field_3b = r0
    //     0x856ce4: stur            w0, [x2, #0x3b]
    //     0x856ce8: ldurb           w16, [x2, #-1]
    //     0x856cec: ldurb           w17, [x0, #-1]
    //     0x856cf0: and             x16, x17, x16, lsr #2
    //     0x856cf4: tst             x16, HEAP, lsr #32
    //     0x856cf8: b.eq            #0x856d00
    //     0x856cfc: bl              #0xd6828c
    // 0x856d00: r1 = <double>
    //     0x856d00: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x856d04: r0 = AnimationController()
    //     0x856d04: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x856d08: stur            x0, [fp, #-0x10]
    // 0x856d0c: ldur            x16, [fp, #-8]
    // 0x856d10: stp             x16, x0, [SP, #-0x10]!
    // 0x856d14: r16 = Instance_Duration
    //     0x856d14: ldr             x16, [PP, #0x1788]  ; [pp+0x1788] Obj!Duration@b67a21
    // 0x856d18: SaveReg r16
    //     0x856d18: str             x16, [SP, #-8]!
    // 0x856d1c: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x856d1c: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x856d20: ldr             x4, [x4, #0xa0]
    // 0x856d24: r0 = AnimationController()
    //     0x856d24: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x856d28: add             SP, SP, #0x18
    // 0x856d2c: r1 = 1
    //     0x856d2c: mov             x1, #1
    // 0x856d30: r0 = AllocateContext()
    //     0x856d30: bl              #0xd68aa4  ; AllocateContextStub
    // 0x856d34: mov             x1, x0
    // 0x856d38: ldr             x0, [fp, #0x48]
    // 0x856d3c: StoreField: r1->field_f = r0
    //     0x856d3c: stur            w0, [x1, #0xf]
    // 0x856d40: mov             x2, x1
    // 0x856d44: r1 = Function 'markNeedsPaint':.
    //     0x856d44: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x856d48: ldr             x1, [x1, #0xf60]
    // 0x856d4c: r0 = AllocateClosure()
    //     0x856d4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x856d50: ldur            x16, [fp, #-0x10]
    // 0x856d54: stp             x0, x16, [SP, #-0x10]!
    // 0x856d58: r0 = addActionListener()
    //     0x856d58: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x856d5c: add             SP, SP, #0x10
    // 0x856d60: ldur            x16, [fp, #-0x10]
    // 0x856d64: SaveReg r16
    //     0x856d64: str             x16, [SP, #-8]!
    // 0x856d68: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x856d68: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x856d6c: r0 = forward()
    //     0x856d6c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x856d70: add             SP, SP, #8
    // 0x856d74: ldur            x0, [fp, #-0x10]
    // 0x856d78: ldr             x2, [fp, #0x68]
    // 0x856d7c: StoreField: r2->field_37 = r0
    //     0x856d7c: stur            w0, [x2, #0x37]
    //     0x856d80: ldurb           w16, [x2, #-1]
    //     0x856d84: ldurb           w17, [x0, #-1]
    //     0x856d88: and             x16, x17, x16, lsr #2
    //     0x856d8c: tst             x16, HEAP, lsr #32
    //     0x856d90: b.eq            #0x856d98
    //     0x856d94: bl              #0xd6828c
    // 0x856d98: ldur            d0, [fp, #-0x38]
    // 0x856d9c: d1 = 0.300000
    //     0x856d9c: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c4f8] IMM: double(0.3) from 0x3fd3333333333333
    //     0x856da0: ldr             d1, [x17, #0x4f8]
    // 0x856da4: fmul            d2, d0, d1
    // 0x856da8: d1 = 5.000000
    //     0x856da8: fmov            d1, #5.00000000
    // 0x856dac: fadd            d3, d0, d1
    // 0x856db0: stur            d3, [fp, #-0x40]
    // 0x856db4: r0 = inline_Allocate_Double()
    //     0x856db4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x856db8: add             x0, x0, #0x10
    //     0x856dbc: cmp             x1, x0
    //     0x856dc0: b.ls            #0x857058
    //     0x856dc4: str             x0, [THR, #0x60]  ; THR::top
    //     0x856dc8: sub             x0, x0, #0xf
    //     0x856dcc: mov             x1, #0xd108
    //     0x856dd0: movk            x1, #3, lsl #16
    //     0x856dd4: stur            x1, [x0, #-1]
    // 0x856dd8: StoreField: r0->field_7 = d2
    //     0x856dd8: stur            d2, [x0, #7]
    // 0x856ddc: stur            x0, [fp, #-0x28]
    // 0x856de0: r1 = <double>
    //     0x856de0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x856de4: r0 = Tween()
    //     0x856de4: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x856de8: mov             x1, x0
    // 0x856dec: ldur            x0, [fp, #-0x28]
    // 0x856df0: stur            x1, [fp, #-0x30]
    // 0x856df4: StoreField: r1->field_b = r0
    //     0x856df4: stur            w0, [x1, #0xb]
    // 0x856df8: ldur            d0, [fp, #-0x40]
    // 0x856dfc: r0 = inline_Allocate_Double()
    //     0x856dfc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x856e00: add             x0, x0, #0x10
    //     0x856e04: cmp             x2, x0
    //     0x856e08: b.ls            #0x857070
    //     0x856e0c: str             x0, [THR, #0x60]  ; THR::top
    //     0x856e10: sub             x0, x0, #0xf
    //     0x856e14: mov             x2, #0xd108
    //     0x856e18: movk            x2, #3, lsl #16
    //     0x856e1c: stur            x2, [x0, #-1]
    // 0x856e20: StoreField: r0->field_7 = d0
    //     0x856e20: stur            d0, [x0, #7]
    // 0x856e24: StoreField: r1->field_f = r0
    //     0x856e24: stur            w0, [x1, #0xf]
    // 0x856e28: r0 = InitLateStaticField(0xda0) // [package:flutter/src/material/ink_ripple.dart] InkRipple::_easeCurveTween
    //     0x856e28: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x856e2c: ldr             x0, [x0, #0x1b40]
    //     0x856e30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x856e34: cmp             w0, w16
    //     0x856e38: b.ne            #0x856e48
    //     0x856e3c: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e358] Field <InkRipple._easeCurveTween@757110234>: static late final (offset: 0xda0)
    //     0x856e40: ldr             x2, [x2, #0x358]
    //     0x856e44: bl              #0xd67cdc
    // 0x856e48: ldur            x16, [fp, #-0x30]
    // 0x856e4c: stp             x0, x16, [SP, #-0x10]!
    // 0x856e50: r0 = chain()
    //     0x856e50: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x856e54: add             SP, SP, #0x10
    // 0x856e58: ldur            x16, [fp, #-0x10]
    // 0x856e5c: stp             x16, x0, [SP, #-0x10]!
    // 0x856e60: r0 = animate()
    //     0x856e60: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x856e64: add             SP, SP, #0x10
    // 0x856e68: ldr             x2, [fp, #0x68]
    // 0x856e6c: StoreField: r2->field_33 = r0
    //     0x856e6c: stur            w0, [x2, #0x33]
    //     0x856e70: ldurb           w16, [x2, #-1]
    //     0x856e74: ldurb           w17, [x0, #-1]
    //     0x856e78: and             x16, x17, x16, lsr #2
    //     0x856e7c: tst             x16, HEAP, lsr #32
    //     0x856e80: b.eq            #0x856e88
    //     0x856e84: bl              #0xd6828c
    // 0x856e88: r1 = <double>
    //     0x856e88: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x856e8c: r0 = AnimationController()
    //     0x856e8c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x856e90: stur            x0, [fp, #-0x10]
    // 0x856e94: ldur            x16, [fp, #-8]
    // 0x856e98: stp             x16, x0, [SP, #-0x10]!
    // 0x856e9c: r16 = Instance_Duration
    //     0x856e9c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e2d8] Obj!Duration@b67ba1
    //     0x856ea0: ldr             x16, [x16, #0x2d8]
    // 0x856ea4: SaveReg r16
    //     0x856ea4: str             x16, [SP, #-8]!
    // 0x856ea8: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x856ea8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x856eac: ldr             x4, [x4, #0xa0]
    // 0x856eb0: r0 = AnimationController()
    //     0x856eb0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x856eb4: add             SP, SP, #0x18
    // 0x856eb8: r1 = 1
    //     0x856eb8: mov             x1, #1
    // 0x856ebc: r0 = AllocateContext()
    //     0x856ebc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x856ec0: mov             x1, x0
    // 0x856ec4: ldr             x0, [fp, #0x48]
    // 0x856ec8: StoreField: r1->field_f = r0
    //     0x856ec8: stur            w0, [x1, #0xf]
    // 0x856ecc: mov             x2, x1
    // 0x856ed0: r1 = Function 'markNeedsPaint':.
    //     0x856ed0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x856ed4: ldr             x1, [x1, #0xf60]
    // 0x856ed8: r0 = AllocateClosure()
    //     0x856ed8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x856edc: ldur            x16, [fp, #-0x10]
    // 0x856ee0: stp             x0, x16, [SP, #-0x10]!
    // 0x856ee4: r0 = addActionListener()
    //     0x856ee4: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x856ee8: add             SP, SP, #0x10
    // 0x856eec: r1 = 1
    //     0x856eec: mov             x1, #1
    // 0x856ef0: r0 = AllocateContext()
    //     0x856ef0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x856ef4: mov             x1, x0
    // 0x856ef8: ldr             x0, [fp, #0x68]
    // 0x856efc: StoreField: r1->field_f = r0
    //     0x856efc: stur            w0, [x1, #0xf]
    // 0x856f00: mov             x2, x1
    // 0x856f04: r1 = Function '_handleAlphaStatusChanged@757110234':.
    //     0x856f04: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e360] AnonymousClosure: (0x8572e0), in [package:flutter/src/material/ink_ripple.dart] InkRipple::_handleAlphaStatusChanged (0x85732c)
    //     0x856f08: ldr             x1, [x1, #0x360]
    // 0x856f0c: r0 = AllocateClosure()
    //     0x856f0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x856f10: ldur            x16, [fp, #-0x10]
    // 0x856f14: stp             x0, x16, [SP, #-0x10]!
    // 0x856f18: r0 = addStatusListener()
    //     0x856f18: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x856f1c: add             SP, SP, #0x10
    // 0x856f20: ldur            x0, [fp, #-0x10]
    // 0x856f24: ldr             x2, [fp, #0x68]
    // 0x856f28: StoreField: r2->field_47 = r0
    //     0x856f28: stur            w0, [x2, #0x47]
    //     0x856f2c: ldurb           w16, [x2, #-1]
    //     0x856f30: ldurb           w17, [x0, #-1]
    //     0x856f34: and             x16, x17, x16, lsr #2
    //     0x856f38: tst             x16, HEAP, lsr #32
    //     0x856f3c: b.eq            #0x856f44
    //     0x856f40: bl              #0xd6828c
    // 0x856f44: ldur            x0, [fp, #-0x20]
    // 0x856f48: r17 = 10124
    //     0x856f48: mov             x17, #0x278c
    // 0x856f4c: cmp             w0, w17
    // 0x856f50: b.gt            #0x856f60
    // 0x856f54: r17 = 10122
    //     0x856f54: mov             x17, #0x278a
    // 0x856f58: cmp             w0, w17
    // 0x856f5c: b.ge            #0x856f78
    // 0x856f60: r17 = 10114
    //     0x856f60: mov             x17, #0x2782
    // 0x856f64: cmp             w0, w17
    // 0x856f68: b.eq            #0x856f78
    // 0x856f6c: r17 = 10118
    //     0x856f6c: mov             x17, #0x2786
    // 0x856f70: cmp             w0, w17
    // 0x856f74: b.ne            #0x856f84
    // 0x856f78: ldr             x0, [fp, #0x58]
    // 0x856f7c: LoadField: r1 = r0->field_7
    //     0x856f7c: ldur            x1, [x0, #7]
    // 0x856f80: b               #0x856f98
    // 0x856f84: ldr             x0, [fp, #0x58]
    // 0x856f88: LoadField: r1 = r0->field_f
    //     0x856f88: ldur            w1, [x0, #0xf]
    // 0x856f8c: DecompressPointer r1
    //     0x856f8c: add             x1, x1, HEAP, lsl #32
    // 0x856f90: LoadField: r0 = r1->field_7
    //     0x856f90: ldur            x0, [x1, #7]
    // 0x856f94: mov             x1, x0
    // 0x856f98: r0 = 4278190080
    //     0x856f98: mov             x0, #0xff000000
    // 0x856f9c: ubfx            x1, x1, #0, #0x20
    // 0x856fa0: and             x3, x1, x0
    // 0x856fa4: ubfx            x3, x3, #0, #0x20
    // 0x856fa8: asr             x0, x3, #0x18
    // 0x856fac: lsl             x3, x0, #1
    // 0x856fb0: stur            x3, [fp, #-8]
    // 0x856fb4: r1 = <int>
    //     0x856fb4: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x856fb8: r0 = IntTween()
    //     0x856fb8: bl              #0x7b2798  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0x856fbc: mov             x1, x0
    // 0x856fc0: ldur            x0, [fp, #-8]
    // 0x856fc4: stur            x1, [fp, #-0x20]
    // 0x856fc8: StoreField: r1->field_b = r0
    //     0x856fc8: stur            w0, [x1, #0xb]
    // 0x856fcc: StoreField: r1->field_f = rZR
    //     0x856fcc: stur            wzr, [x1, #0xf]
    // 0x856fd0: r0 = InitLateStaticField(0xda4) // [package:flutter/src/material/ink_ripple.dart] InkRipple::_fadeOutIntervalTween
    //     0x856fd0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x856fd4: ldr             x0, [x0, #0x1b48]
    //     0x856fd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x856fdc: cmp             w0, w16
    //     0x856fe0: b.ne            #0x856ff0
    //     0x856fe4: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e368] Field <InkRipple._fadeOutIntervalTween@757110234>: static late final (offset: 0xda4)
    //     0x856fe8: ldr             x2, [x2, #0x368]
    //     0x856fec: bl              #0xd67cdc
    // 0x856ff0: ldur            x16, [fp, #-0x20]
    // 0x856ff4: stp             x0, x16, [SP, #-0x10]!
    // 0x856ff8: r0 = chain()
    //     0x856ff8: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x856ffc: add             SP, SP, #0x10
    // 0x857000: ldur            x16, [fp, #-0x10]
    // 0x857004: stp             x16, x0, [SP, #-0x10]!
    // 0x857008: r0 = animate()
    //     0x857008: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x85700c: add             SP, SP, #0x10
    // 0x857010: ldr             x1, [fp, #0x68]
    // 0x857014: StoreField: r1->field_43 = r0
    //     0x857014: stur            w0, [x1, #0x43]
    //     0x857018: ldurb           w16, [x1, #-1]
    //     0x85701c: ldurb           w17, [x0, #-1]
    //     0x857020: and             x16, x17, x16, lsr #2
    //     0x857024: tst             x16, HEAP, lsr #32
    //     0x857028: b.eq            #0x857030
    //     0x85702c: bl              #0xd6826c
    // 0x857030: ldr             x16, [fp, #0x48]
    // 0x857034: stp             x1, x16, [SP, #-0x10]!
    // 0x857038: r0 = addInkFeature()
    //     0x857038: bl              #0x7b266c  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0x85703c: add             SP, SP, #0x10
    // 0x857040: r0 = Null
    //     0x857040: mov             x0, NULL
    // 0x857044: LeaveFrame
    //     0x857044: mov             SP, fp
    //     0x857048: ldp             fp, lr, [SP], #0x10
    // 0x85704c: ret
    //     0x85704c: ret             
    // 0x857050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857054: b               #0x8569b8
    // 0x857058: stp             q2, q3, [SP, #-0x20]!
    // 0x85705c: SaveReg r2
    //     0x85705c: str             x2, [SP, #-8]!
    // 0x857060: r0 = AllocateDouble()
    //     0x857060: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x857064: RestoreReg r2
    //     0x857064: ldr             x2, [SP], #8
    // 0x857068: ldp             q2, q3, [SP], #0x20
    // 0x85706c: b               #0x856dd8
    // 0x857070: SaveReg d0
    //     0x857070: str             q0, [SP, #-0x10]!
    // 0x857074: SaveReg r1
    //     0x857074: str             x1, [SP, #-8]!
    // 0x857078: r0 = AllocateDouble()
    //     0x857078: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x85707c: RestoreReg r1
    //     0x85707c: ldr             x1, [SP], #8
    // 0x857080: RestoreReg d0
    //     0x857080: ldr             q0, [SP], #0x10
    // 0x857084: b               #0x856e20
  }
  static Animatable<double> _fadeOutIntervalTween() {
    // ** addr: 0x8572b8, size: 0x28
    // 0x8572b8: EnterFrame
    //     0x8572b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8572bc: mov             fp, SP
    // 0x8572c0: r1 = <double>
    //     0x8572c0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8572c4: r0 = CurveTween()
    //     0x8572c4: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x8572c8: r1 = Instance_Interval
    //     0x8572c8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e370] Obj!Interval<double>@b4f841
    //     0x8572cc: ldr             x1, [x1, #0x370]
    // 0x8572d0: StoreField: r0->field_b = r1
    //     0x8572d0: stur            w1, [x0, #0xb]
    // 0x8572d4: LeaveFrame
    //     0x8572d4: mov             SP, fp
    //     0x8572d8: ldp             fp, lr, [SP], #0x10
    // 0x8572dc: ret
    //     0x8572dc: ret             
  }
  [closure] void _handleAlphaStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0x8572e0, size: 0x4c
    // 0x8572e0: EnterFrame
    //     0x8572e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8572e4: mov             fp, SP
    // 0x8572e8: ldr             x0, [fp, #0x18]
    // 0x8572ec: LoadField: r1 = r0->field_17
    //     0x8572ec: ldur            w1, [x0, #0x17]
    // 0x8572f0: DecompressPointer r1
    //     0x8572f0: add             x1, x1, HEAP, lsl #32
    // 0x8572f4: CheckStackOverflow
    //     0x8572f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8572f8: cmp             SP, x16
    //     0x8572fc: b.ls            #0x857324
    // 0x857300: LoadField: r0 = r1->field_f
    //     0x857300: ldur            w0, [x1, #0xf]
    // 0x857304: DecompressPointer r0
    //     0x857304: add             x0, x0, HEAP, lsl #32
    // 0x857308: ldr             x16, [fp, #0x10]
    // 0x85730c: stp             x16, x0, [SP, #-0x10]!
    // 0x857310: r0 = _handleAlphaStatusChanged()
    //     0x857310: bl              #0x85732c  ; [package:flutter/src/material/ink_ripple.dart] InkRipple::_handleAlphaStatusChanged
    // 0x857314: add             SP, SP, #0x10
    // 0x857318: LeaveFrame
    //     0x857318: mov             SP, fp
    //     0x85731c: ldp             fp, lr, [SP], #0x10
    // 0x857320: ret
    //     0x857320: ret             
    // 0x857324: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857324: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857328: b               #0x857300
  }
  _ _handleAlphaStatusChanged(/* No info */) {
    // ** addr: 0x85732c, size: 0x50
    // 0x85732c: EnterFrame
    //     0x85732c: stp             fp, lr, [SP, #-0x10]!
    //     0x857330: mov             fp, SP
    // 0x857334: CheckStackOverflow
    //     0x857334: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x857338: cmp             SP, x16
    //     0x85733c: b.ls            #0x857374
    // 0x857340: ldr             x0, [fp, #0x10]
    // 0x857344: r16 = Instance_AnimationStatus
    //     0x857344: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x857348: ldr             x16, [x16, #0xba0]
    // 0x85734c: cmp             w0, w16
    // 0x857350: b.ne            #0x857364
    // 0x857354: ldr             x16, [fp, #0x18]
    // 0x857358: SaveReg r16
    //     0x857358: str             x16, [SP, #-8]!
    // 0x85735c: r0 = dispose()
    //     0x85735c: bl              #0xbfead0  ; [package:flutter/src/material/ink_ripple.dart] InkRipple::dispose
    // 0x857360: add             SP, SP, #8
    // 0x857364: r0 = Null
    //     0x857364: mov             x0, NULL
    // 0x857368: LeaveFrame
    //     0x857368: mov             SP, fp
    //     0x85736c: ldp             fp, lr, [SP], #0x10
    // 0x857370: ret
    //     0x857370: ret             
    // 0x857374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857378: b               #0x857340
  }
  static Animatable<double> _easeCurveTween() {
    // ** addr: 0x85737c, size: 0x28
    // 0x85737c: EnterFrame
    //     0x85737c: stp             fp, lr, [SP, #-0x10]!
    //     0x857380: mov             fp, SP
    // 0x857384: r1 = <double>
    //     0x857384: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857388: r0 = CurveTween()
    //     0x857388: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x85738c: r1 = Instance_Cubic
    //     0x85738c: add             x1, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0x857390: ldr             x1, [x1, #0xfc8]
    // 0x857394: StoreField: r0->field_b = r1
    //     0x857394: stur            w1, [x0, #0xb]
    // 0x857398: LeaveFrame
    //     0x857398: mov             SP, fp
    //     0x85739c: ldp             fp, lr, [SP], #0x10
    // 0x8573a0: ret
    //     0x8573a0: ret             
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0xbe4790, size: 0x340
    // 0xbe4790: EnterFrame
    //     0xbe4790: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4794: mov             fp, SP
    // 0xbe4798: AllocStack(0x28)
    //     0xbe4798: sub             SP, SP, #0x28
    // 0xbe479c: CheckStackOverflow
    //     0xbe479c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe47a0: cmp             SP, x16
    //     0xbe47a4: b.ls            #0xbe4a78
    // 0xbe47a8: ldr             x0, [fp, #0x20]
    // 0xbe47ac: LoadField: r1 = r0->field_3f
    //     0xbe47ac: ldur            w1, [x0, #0x3f]
    // 0xbe47b0: DecompressPointer r1
    //     0xbe47b0: add             x1, x1, HEAP, lsl #32
    // 0xbe47b4: r16 = Sentinel
    //     0xbe47b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe47b8: cmp             w1, w16
    // 0xbe47bc: b.eq            #0xbe4a80
    // 0xbe47c0: LoadField: r2 = r1->field_2f
    //     0xbe47c0: ldur            w2, [x1, #0x2f]
    // 0xbe47c4: DecompressPointer r2
    //     0xbe47c4: add             x2, x2, HEAP, lsl #32
    // 0xbe47c8: cmp             w2, NULL
    // 0xbe47cc: b.eq            #0xbe4820
    // 0xbe47d0: LoadField: r1 = r2->field_7
    //     0xbe47d0: ldur            w1, [x2, #7]
    // 0xbe47d4: DecompressPointer r1
    //     0xbe47d4: add             x1, x1, HEAP, lsl #32
    // 0xbe47d8: cmp             w1, NULL
    // 0xbe47dc: b.eq            #0xbe4820
    // 0xbe47e0: LoadField: r1 = r0->field_3b
    //     0xbe47e0: ldur            w1, [x0, #0x3b]
    // 0xbe47e4: DecompressPointer r1
    //     0xbe47e4: add             x1, x1, HEAP, lsl #32
    // 0xbe47e8: r16 = Sentinel
    //     0xbe47e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe47ec: cmp             w1, w16
    // 0xbe47f0: b.eq            #0xbe4a8c
    // 0xbe47f4: LoadField: r2 = r1->field_f
    //     0xbe47f4: ldur            w2, [x1, #0xf]
    // 0xbe47f8: DecompressPointer r2
    //     0xbe47f8: add             x2, x2, HEAP, lsl #32
    // 0xbe47fc: LoadField: r3 = r1->field_b
    //     0xbe47fc: ldur            w3, [x1, #0xb]
    // 0xbe4800: DecompressPointer r3
    //     0xbe4800: add             x3, x3, HEAP, lsl #32
    // 0xbe4804: stp             x3, x2, [SP, #-0x10]!
    // 0xbe4808: r0 = evaluate()
    //     0xbe4808: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe480c: add             SP, SP, #0x10
    // 0xbe4810: r1 = LoadInt32Instr(r0)
    //     0xbe4810: sbfx            x1, x0, #1, #0x1f
    //     0xbe4814: tbz             w0, #0, #0xbe481c
    //     0xbe4818: ldur            x1, [x0, #7]
    // 0xbe481c: b               #0xbe4860
    // 0xbe4820: ldr             x0, [fp, #0x20]
    // 0xbe4824: LoadField: r1 = r0->field_43
    //     0xbe4824: ldur            w1, [x0, #0x43]
    // 0xbe4828: DecompressPointer r1
    //     0xbe4828: add             x1, x1, HEAP, lsl #32
    // 0xbe482c: r16 = Sentinel
    //     0xbe482c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4830: cmp             w1, w16
    // 0xbe4834: b.eq            #0xbe4a98
    // 0xbe4838: LoadField: r2 = r1->field_f
    //     0xbe4838: ldur            w2, [x1, #0xf]
    // 0xbe483c: DecompressPointer r2
    //     0xbe483c: add             x2, x2, HEAP, lsl #32
    // 0xbe4840: LoadField: r3 = r1->field_b
    //     0xbe4840: ldur            w3, [x1, #0xb]
    // 0xbe4844: DecompressPointer r3
    //     0xbe4844: add             x3, x3, HEAP, lsl #32
    // 0xbe4848: stp             x3, x2, [SP, #-0x10]!
    // 0xbe484c: r0 = evaluate()
    //     0xbe484c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe4850: add             SP, SP, #0x10
    // 0xbe4854: r1 = LoadInt32Instr(r0)
    //     0xbe4854: sbfx            x1, x0, #1, #0x1f
    //     0xbe4858: tbz             w0, #0, #0xbe4860
    //     0xbe485c: ldur            x1, [x0, #7]
    // 0xbe4860: ldr             x0, [fp, #0x20]
    // 0xbe4864: stur            x1, [fp, #-8]
    // 0xbe4868: r16 = 112
    //     0xbe4868: mov             x16, #0x70
    // 0xbe486c: stp             x16, NULL, [SP, #-0x10]!
    // 0xbe4870: r0 = ByteData()
    //     0xbe4870: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbe4874: add             SP, SP, #0x10
    // 0xbe4878: stur            x0, [fp, #-0x10]
    // 0xbe487c: r0 = Paint()
    //     0xbe487c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbe4880: mov             x1, x0
    // 0xbe4884: ldur            x0, [fp, #-0x10]
    // 0xbe4888: stur            x1, [fp, #-0x18]
    // 0xbe488c: StoreField: r1->field_7 = r0
    //     0xbe488c: stur            w0, [x1, #7]
    // 0xbe4890: ldr             x2, [fp, #0x20]
    // 0xbe4894: LoadField: r3 = r2->field_13
    //     0xbe4894: ldur            w3, [x2, #0x13]
    // 0xbe4898: DecompressPointer r3
    //     0xbe4898: add             x3, x3, HEAP, lsl #32
    // 0xbe489c: SaveReg r3
    //     0xbe489c: str             x3, [SP, #-8]!
    // 0xbe48a0: ldur            x3, [fp, #-8]
    // 0xbe48a4: SaveReg r3
    //     0xbe48a4: str             x3, [SP, #-8]!
    // 0xbe48a8: r0 = withAlpha()
    //     0xbe48a8: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0xbe48ac: add             SP, SP, #0x10
    // 0xbe48b0: LoadField: r1 = r0->field_7
    //     0xbe48b0: ldur            x1, [x0, #7]
    // 0xbe48b4: eor             x0, x1, #0xff000000
    // 0xbe48b8: ldur            x1, [fp, #-0x10]
    // 0xbe48bc: LoadField: r2 = r1->field_17
    //     0xbe48bc: ldur            w2, [x1, #0x17]
    // 0xbe48c0: DecompressPointer r2
    //     0xbe48c0: add             x2, x2, HEAP, lsl #32
    // 0xbe48c4: sxtw            x0, w0
    // 0xbe48c8: LoadField: r1 = r2->field_7
    //     0xbe48c8: ldur            x1, [x2, #7]
    // 0xbe48cc: str             w0, [x1, #4]
    // 0xbe48d0: ldr             x1, [fp, #0x20]
    // 0xbe48d4: LoadField: r2 = r1->field_2b
    //     0xbe48d4: ldur            w2, [x1, #0x2b]
    // 0xbe48d8: DecompressPointer r2
    //     0xbe48d8: add             x2, x2, HEAP, lsl #32
    // 0xbe48dc: stur            x2, [fp, #-0x10]
    // 0xbe48e0: cmp             w2, NULL
    // 0xbe48e4: b.eq            #0xbe4908
    // 0xbe48e8: SaveReg r2
    //     0xbe48e8: str             x2, [SP, #-8]!
    // 0xbe48ec: mov             x0, x2
    // 0xbe48f0: ClosureCall
    //     0xbe48f0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe48f4: ldur            x2, [x0, #0x1f]
    //     0xbe48f8: blr             x2
    // 0xbe48fc: add             SP, SP, #8
    // 0xbe4900: mov             x1, x0
    // 0xbe4904: b               #0xbe490c
    // 0xbe4908: r1 = Null
    //     0xbe4908: mov             x1, NULL
    // 0xbe490c: ldr             x0, [fp, #0x20]
    // 0xbe4910: LoadField: r2 = r0->field_17
    //     0xbe4910: ldur            w2, [x0, #0x17]
    // 0xbe4914: DecompressPointer r2
    //     0xbe4914: add             x2, x2, HEAP, lsl #32
    // 0xbe4918: stur            x2, [fp, #-0x20]
    // 0xbe491c: cmp             w1, NULL
    // 0xbe4920: b.eq            #0xbe4938
    // 0xbe4924: SaveReg r1
    //     0xbe4924: str             x1, [SP, #-8]!
    // 0xbe4928: r0 = center()
    //     0xbe4928: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xbe492c: add             SP, SP, #8
    // 0xbe4930: mov             x1, x0
    // 0xbe4934: b               #0xbe4960
    // 0xbe4938: LoadField: r1 = r0->field_b
    //     0xbe4938: ldur            w1, [x0, #0xb]
    // 0xbe493c: DecompressPointer r1
    //     0xbe493c: add             x1, x1, HEAP, lsl #32
    // 0xbe4940: LoadField: r2 = r1->field_57
    //     0xbe4940: ldur            w2, [x1, #0x57]
    // 0xbe4944: DecompressPointer r2
    //     0xbe4944: add             x2, x2, HEAP, lsl #32
    // 0xbe4948: cmp             w2, NULL
    // 0xbe494c: b.eq            #0xbe4aa4
    // 0xbe4950: SaveReg r2
    //     0xbe4950: str             x2, [SP, #-8]!
    // 0xbe4954: r0 = center()
    //     0xbe4954: bl              #0x64082c  ; [dart:ui] Size::center
    // 0xbe4958: add             SP, SP, #8
    // 0xbe495c: mov             x1, x0
    // 0xbe4960: ldr             x0, [fp, #0x20]
    // 0xbe4964: stur            x1, [fp, #-0x28]
    // 0xbe4968: LoadField: r2 = r0->field_37
    //     0xbe4968: ldur            w2, [x0, #0x37]
    // 0xbe496c: DecompressPointer r2
    //     0xbe496c: add             x2, x2, HEAP, lsl #32
    // 0xbe4970: r16 = Sentinel
    //     0xbe4970: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4974: cmp             w2, w16
    // 0xbe4978: b.eq            #0xbe4aa8
    // 0xbe497c: LoadField: r3 = r2->field_37
    //     0xbe497c: ldur            w3, [x2, #0x37]
    // 0xbe4980: DecompressPointer r3
    //     0xbe4980: add             x3, x3, HEAP, lsl #32
    // 0xbe4984: r16 = Sentinel
    //     0xbe4984: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4988: cmp             w3, w16
    // 0xbe498c: b.eq            #0xbe4ab4
    // 0xbe4990: LoadField: d0 = r3->field_7
    //     0xbe4990: ldur            d0, [x3, #7]
    // 0xbe4994: r16 = Instance_Cubic
    //     0xbe4994: add             x16, PP, #0xa, lsl #12  ; [pp+0xafc8] Obj!Cubic<double>@b4f341
    //     0xbe4998: ldr             x16, [x16, #0xfc8]
    // 0xbe499c: SaveReg r16
    //     0xbe499c: str             x16, [SP, #-8]!
    // 0xbe49a0: SaveReg d0
    //     0xbe49a0: str             d0, [SP, #-8]!
    // 0xbe49a4: r0 = transform()
    //     0xbe49a4: bl              #0xc504ac  ; [package:flutter/src/animation/curves.dart] Curve::transform
    // 0xbe49a8: add             SP, SP, #0x10
    // 0xbe49ac: LoadField: d0 = r0->field_7
    //     0xbe49ac: ldur            d0, [x0, #7]
    // 0xbe49b0: ldur            x16, [fp, #-0x20]
    // 0xbe49b4: ldur            lr, [fp, #-0x28]
    // 0xbe49b8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe49bc: SaveReg d0
    //     0xbe49bc: str             d0, [SP, #-8]!
    // 0xbe49c0: r0 = lerp()
    //     0xbe49c0: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xbe49c4: add             SP, SP, #0x18
    // 0xbe49c8: stur            x0, [fp, #-0x28]
    // 0xbe49cc: cmp             w0, NULL
    // 0xbe49d0: b.eq            #0xbe4ac0
    // 0xbe49d4: ldr             x1, [fp, #0x20]
    // 0xbe49d8: LoadField: r2 = r1->field_2f
    //     0xbe49d8: ldur            w2, [x1, #0x2f]
    // 0xbe49dc: DecompressPointer r2
    //     0xbe49dc: add             x2, x2, HEAP, lsl #32
    // 0xbe49e0: stur            x2, [fp, #-0x20]
    // 0xbe49e4: LoadField: r3 = r1->field_33
    //     0xbe49e4: ldur            w3, [x1, #0x33]
    // 0xbe49e8: DecompressPointer r3
    //     0xbe49e8: add             x3, x3, HEAP, lsl #32
    // 0xbe49ec: r16 = Sentinel
    //     0xbe49ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe49f0: cmp             w3, w16
    // 0xbe49f4: b.eq            #0xbe4ac4
    // 0xbe49f8: LoadField: r4 = r3->field_f
    //     0xbe49f8: ldur            w4, [x3, #0xf]
    // 0xbe49fc: DecompressPointer r4
    //     0xbe49fc: add             x4, x4, HEAP, lsl #32
    // 0xbe4a00: LoadField: r5 = r3->field_b
    //     0xbe4a00: ldur            w5, [x3, #0xb]
    // 0xbe4a04: DecompressPointer r5
    //     0xbe4a04: add             x5, x5, HEAP, lsl #32
    // 0xbe4a08: stp             x5, x4, [SP, #-0x10]!
    // 0xbe4a0c: r0 = evaluate()
    //     0xbe4a0c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe4a10: add             SP, SP, #0x10
    // 0xbe4a14: mov             x1, x0
    // 0xbe4a18: ldr             x0, [fp, #0x20]
    // 0xbe4a1c: LoadField: r2 = r0->field_1f
    //     0xbe4a1c: ldur            w2, [x0, #0x1f]
    // 0xbe4a20: DecompressPointer r2
    //     0xbe4a20: add             x2, x2, HEAP, lsl #32
    // 0xbe4a24: LoadField: r3 = r0->field_1b
    //     0xbe4a24: ldur            w3, [x0, #0x1b]
    // 0xbe4a28: DecompressPointer r3
    //     0xbe4a28: add             x3, x3, HEAP, lsl #32
    // 0xbe4a2c: LoadField: d0 = r1->field_7
    //     0xbe4a2c: ldur            d0, [x1, #7]
    // 0xbe4a30: stp             x3, x0, [SP, #-0x10]!
    // 0xbe4a34: ldr             x16, [fp, #0x18]
    // 0xbe4a38: ldur            lr, [fp, #-0x28]
    // 0xbe4a3c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4a40: ldur            x16, [fp, #-0x10]
    // 0xbe4a44: stp             x2, x16, [SP, #-0x10]!
    // 0xbe4a48: ldur            x16, [fp, #-0x18]
    // 0xbe4a4c: SaveReg r16
    //     0xbe4a4c: str             x16, [SP, #-8]!
    // 0xbe4a50: SaveReg d0
    //     0xbe4a50: str             d0, [SP, #-8]!
    // 0xbe4a54: ldur            x16, [fp, #-0x20]
    // 0xbe4a58: ldr             lr, [fp, #0x10]
    // 0xbe4a5c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4a60: r0 = paintInkCircle()
    //     0xbe4a60: bl              #0xbe4ad0  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::paintInkCircle
    // 0xbe4a64: add             SP, SP, #0x50
    // 0xbe4a68: r0 = Null
    //     0xbe4a68: mov             x0, NULL
    // 0xbe4a6c: LeaveFrame
    //     0xbe4a6c: mov             SP, fp
    //     0xbe4a70: ldp             fp, lr, [SP], #0x10
    // 0xbe4a74: ret
    //     0xbe4a74: ret             
    // 0xbe4a78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4a78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4a7c: b               #0xbe47a8
    // 0xbe4a80: r9 = _fadeInController
    //     0xbe4a80: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f0] Field <InkRipple._fadeInController@757110234>: late (offset: 0x40)
    //     0xbe4a84: ldr             x9, [x9, #0x2f0]
    // 0xbe4a88: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4a88: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe4a8c: r9 = _fadeIn
    //     0xbe4a8c: add             x9, PP, #0x37, lsl #12  ; [pp+0x378c8] Field <InkRipple._fadeIn@757110234>: late (offset: 0x3c)
    //     0xbe4a90: ldr             x9, [x9, #0x8c8]
    // 0xbe4a94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4a94: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe4a98: r9 = _fadeOut
    //     0xbe4a98: add             x9, PP, #0x37, lsl #12  ; [pp+0x378d0] Field <InkRipple._fadeOut@757110234>: late (offset: 0x44)
    //     0xbe4a9c: ldr             x9, [x9, #0x8d0]
    // 0xbe4aa0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4aa0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe4aa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4aa4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4aa8: r9 = _radiusController
    //     0xbe4aa8: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e8] Field <InkRipple._radiusController@757110234>: late (offset: 0x38)
    //     0xbe4aac: ldr             x9, [x9, #0x2e8]
    // 0xbe4ab0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4ab0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe4ab4: r9 = _value
    //     0xbe4ab4: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xbe4ab8: ldr             x9, [x9, #0xbb0]
    // 0xbe4abc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4abc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe4ac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe4ac0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe4ac4: r9 = _radius
    //     0xbe4ac4: add             x9, PP, #0x37, lsl #12  ; [pp+0x378d8] Field <InkRipple._radius@757110234>: late (offset: 0x34)
    //     0xbe4ac8: ldr             x9, [x9, #0x8d8]
    // 0xbe4acc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4acc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbfead0, size: 0xcc
    // 0xbfead0: EnterFrame
    //     0xbfead0: stp             fp, lr, [SP, #-0x10]!
    //     0xbfead4: mov             fp, SP
    // 0xbfead8: CheckStackOverflow
    //     0xbfead8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfeadc: cmp             SP, x16
    //     0xbfeae0: b.ls            #0xbfeb70
    // 0xbfeae4: ldr             x0, [fp, #0x10]
    // 0xbfeae8: LoadField: r1 = r0->field_37
    //     0xbfeae8: ldur            w1, [x0, #0x37]
    // 0xbfeaec: DecompressPointer r1
    //     0xbfeaec: add             x1, x1, HEAP, lsl #32
    // 0xbfeaf0: r16 = Sentinel
    //     0xbfeaf0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfeaf4: cmp             w1, w16
    // 0xbfeaf8: b.eq            #0xbfeb78
    // 0xbfeafc: SaveReg r1
    //     0xbfeafc: str             x1, [SP, #-8]!
    // 0xbfeb00: r0 = dispose()
    //     0xbfeb00: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfeb04: add             SP, SP, #8
    // 0xbfeb08: ldr             x0, [fp, #0x10]
    // 0xbfeb0c: LoadField: r1 = r0->field_3f
    //     0xbfeb0c: ldur            w1, [x0, #0x3f]
    // 0xbfeb10: DecompressPointer r1
    //     0xbfeb10: add             x1, x1, HEAP, lsl #32
    // 0xbfeb14: r16 = Sentinel
    //     0xbfeb14: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfeb18: cmp             w1, w16
    // 0xbfeb1c: b.eq            #0xbfeb84
    // 0xbfeb20: SaveReg r1
    //     0xbfeb20: str             x1, [SP, #-8]!
    // 0xbfeb24: r0 = dispose()
    //     0xbfeb24: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfeb28: add             SP, SP, #8
    // 0xbfeb2c: ldr             x0, [fp, #0x10]
    // 0xbfeb30: LoadField: r1 = r0->field_47
    //     0xbfeb30: ldur            w1, [x0, #0x47]
    // 0xbfeb34: DecompressPointer r1
    //     0xbfeb34: add             x1, x1, HEAP, lsl #32
    // 0xbfeb38: r16 = Sentinel
    //     0xbfeb38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfeb3c: cmp             w1, w16
    // 0xbfeb40: b.eq            #0xbfeb90
    // 0xbfeb44: SaveReg r1
    //     0xbfeb44: str             x1, [SP, #-8]!
    // 0xbfeb48: r0 = dispose()
    //     0xbfeb48: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfeb4c: add             SP, SP, #8
    // 0xbfeb50: ldr             x16, [fp, #0x10]
    // 0xbfeb54: SaveReg r16
    //     0xbfeb54: str             x16, [SP, #-8]!
    // 0xbfeb58: r0 = dispose()
    //     0xbfeb58: bl              #0x795b14  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0xbfeb5c: add             SP, SP, #8
    // 0xbfeb60: r0 = Null
    //     0xbfeb60: mov             x0, NULL
    // 0xbfeb64: LeaveFrame
    //     0xbfeb64: mov             SP, fp
    //     0xbfeb68: ldp             fp, lr, [SP], #0x10
    // 0xbfeb6c: ret
    //     0xbfeb6c: ret             
    // 0xbfeb70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfeb70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfeb74: b               #0xbfeae4
    // 0xbfeb78: r9 = _radiusController
    //     0xbfeb78: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e8] Field <InkRipple._radiusController@757110234>: late (offset: 0x38)
    //     0xbfeb7c: ldr             x9, [x9, #0x2e8]
    // 0xbfeb80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfeb80: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbfeb84: r9 = _fadeInController
    //     0xbfeb84: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f0] Field <InkRipple._fadeInController@757110234>: late (offset: 0x40)
    //     0xbfeb88: ldr             x9, [x9, #0x2f0]
    // 0xbfeb8c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfeb8c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbfeb90: r9 = _fadeOutController
    //     0xbfeb90: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2f8] Field <InkRipple._fadeOutController@757110234>: late (offset: 0x48)
    //     0xbfeb94: ldr             x9, [x9, #0x2f8]
    // 0xbfeb98: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfeb98: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

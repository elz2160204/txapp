// lib: , url: package:flutter/src/material/drawer.dart

// class id: 1049227, size: 0x8
class :: {
}

// class id: 3327, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _DrawerControllerState&State&SingleTickerProviderStateMixin extends State<DrawerController>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {
}

// class id: 3328, size: 0x38, field offset: 0x1c
class DrawerControllerState extends _DrawerControllerState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x24

  _ open(/* No info */) {
    // ** addr: 0x848c28, size: 0x74
    // 0x848c28: EnterFrame
    //     0x848c28: stp             fp, lr, [SP, #-0x10]!
    //     0x848c2c: mov             fp, SP
    // 0x848c30: CheckStackOverflow
    //     0x848c30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848c34: cmp             SP, x16
    //     0x848c38: b.ls            #0x848c84
    // 0x848c3c: ldr             x0, [fp, #0x10]
    // 0x848c40: LoadField: r1 = r0->field_23
    //     0x848c40: ldur            w1, [x0, #0x23]
    // 0x848c44: DecompressPointer r1
    //     0x848c44: add             x1, x1, HEAP, lsl #32
    // 0x848c48: r16 = Sentinel
    //     0x848c48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x848c4c: cmp             w1, w16
    // 0x848c50: b.eq            #0x848c8c
    // 0x848c54: SaveReg r1
    //     0x848c54: str             x1, [SP, #-8]!
    // 0x848c58: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x848c58: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x848c5c: r0 = fling()
    //     0x848c5c: bl              #0x82d318  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0x848c60: add             SP, SP, #8
    // 0x848c64: ldr             x0, [fp, #0x10]
    // 0x848c68: LoadField: r1 = r0->field_b
    //     0x848c68: ldur            w1, [x0, #0xb]
    // 0x848c6c: DecompressPointer r1
    //     0x848c6c: add             x1, x1, HEAP, lsl #32
    // 0x848c70: cmp             w1, NULL
    // 0x848c74: b.eq            #0x848c98
    // 0x848c78: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x848c78: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x848c7c: r0 = Throw()
    //     0x848c7c: bl              #0xd67e38  ; ThrowStub
    // 0x848c80: brk             #0
    // 0x848c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x848c84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x848c88: b               #0x848c3c
    // 0x848c8c: r9 = _controller
    //     0x848c8c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37a10] Field <DrawerControllerState._controller@728517151>: late (offset: 0x24)
    //     0x848c90: ldr             x9, [x9, #0xa10]
    // 0x848c94: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x848c94: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x848c98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848c98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ close(/* No info */) {
    // ** addr: 0x848c9c, size: 0xc4
    // 0x848c9c: EnterFrame
    //     0x848c9c: stp             fp, lr, [SP, #-0x10]!
    //     0x848ca0: mov             fp, SP
    // 0x848ca4: d0 = 1.000000
    //     0x848ca4: fmov            d0, #1.00000000
    // 0x848ca8: CheckStackOverflow
    //     0x848ca8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x848cac: cmp             SP, x16
    //     0x848cb0: b.ls            #0x848d2c
    // 0x848cb4: ldr             x0, [fp, #0x10]
    // 0x848cb8: LoadField: r1 = r0->field_23
    //     0x848cb8: ldur            w1, [x0, #0x23]
    // 0x848cbc: DecompressPointer r1
    //     0x848cbc: add             x1, x1, HEAP, lsl #32
    // 0x848cc0: r16 = Sentinel
    //     0x848cc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x848cc4: cmp             w1, w16
    // 0x848cc8: b.eq            #0x848d34
    // 0x848ccc: fneg            d1, d0
    // 0x848cd0: r2 = inline_Allocate_Double()
    //     0x848cd0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x848cd4: add             x2, x2, #0x10
    //     0x848cd8: cmp             x3, x2
    //     0x848cdc: b.ls            #0x848d40
    //     0x848ce0: str             x2, [THR, #0x60]  ; THR::top
    //     0x848ce4: sub             x2, x2, #0xf
    //     0x848ce8: mov             x3, #0xd108
    //     0x848cec: movk            x3, #3, lsl #16
    //     0x848cf0: stur            x3, [x2, #-1]
    // 0x848cf4: StoreField: r2->field_7 = d1
    //     0x848cf4: stur            d1, [x2, #7]
    // 0x848cf8: stp             x2, x1, [SP, #-0x10]!
    // 0x848cfc: r4 = const [0, 0x2, 0x2, 0x1, velocity, 0x1, null]
    //     0x848cfc: add             x4, PP, #0x37, lsl #12  ; [pp+0x37a40] List(7) [0, 0x2, 0x2, 0x1, "velocity", 0x1, Null]
    //     0x848d00: ldr             x4, [x4, #0xa40]
    // 0x848d04: r0 = fling()
    //     0x848d04: bl              #0x82d318  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::fling
    // 0x848d08: add             SP, SP, #0x10
    // 0x848d0c: ldr             x0, [fp, #0x10]
    // 0x848d10: LoadField: r1 = r0->field_b
    //     0x848d10: ldur            w1, [x0, #0xb]
    // 0x848d14: DecompressPointer r1
    //     0x848d14: add             x1, x1, HEAP, lsl #32
    // 0x848d18: cmp             w1, NULL
    // 0x848d1c: b.eq            #0x848d5c
    // 0x848d20: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x848d20: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x848d24: r0 = Throw()
    //     0x848d24: bl              #0xd67e38  ; ThrowStub
    // 0x848d28: brk             #0
    // 0x848d2c: r0 = StackOverflowSharedWithFPURegs()
    //     0x848d2c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x848d30: b               #0x848cb4
    // 0x848d34: r9 = _controller
    //     0x848d34: add             x9, PP, #0x37, lsl #12  ; [pp+0x37a10] Field <DrawerControllerState._controller@728517151>: late (offset: 0x24)
    //     0x848d38: ldr             x9, [x9, #0xa10]
    // 0x848d3c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x848d3c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x848d40: SaveReg d1
    //     0x848d40: str             q1, [SP, #-0x10]!
    // 0x848d44: stp             x0, x1, [SP, #-0x10]!
    // 0x848d48: r0 = AllocateDouble()
    //     0x848d48: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x848d4c: mov             x2, x0
    // 0x848d50: ldp             x0, x1, [SP], #0x10
    // 0x848d54: RestoreReg d1
    //     0x848d54: ldr             q1, [SP], #0x10
    // 0x848d58: b               #0x848cf4
    // 0x848d5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x848d5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4157, size: 0x2c, field offset: 0xc
//   const constructor, 
class DrawerController extends StatefulWidget {
}

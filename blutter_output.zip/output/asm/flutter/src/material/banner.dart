// lib: , url: package:flutter/src/material/banner.dart

// class id: 1049186, size: 0x8
class :: {
}

// class id: 4169, size: 0xc, field offset: 0xc
//   const constructor, 
abstract class MaterialBanner extends StatefulWidget {
}

// class id: 5973, size: 0x14, field offset: 0x14
abstract class MaterialBannerClosedReason extends _Enum {
}

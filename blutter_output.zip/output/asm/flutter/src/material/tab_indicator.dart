// lib: , url: package:flutter/src/material/tab_indicator.dart

// class id: 1049319, size: 0x8
class :: {
}

// class id: 2938, size: 0x14, field offset: 0x8
//   const constructor, 
class UnderlineTabIndicator extends Decoration {

  _ _indicatorRectFor(/* No info */) {
    // ** addr: 0xc70ba8, size: 0x108
    // 0xc70ba8: EnterFrame
    //     0xc70ba8: stp             fp, lr, [SP, #-0x10]!
    //     0xc70bac: mov             fp, SP
    // 0xc70bb0: AllocStack(0x20)
    //     0xc70bb0: sub             SP, SP, #0x20
    // 0xc70bb4: CheckStackOverflow
    //     0xc70bb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc70bb8: cmp             SP, x16
    //     0xc70bbc: b.ls            #0xc70ca4
    // 0xc70bc0: ldr             x1, [fp, #0x20]
    // 0xc70bc4: LoadField: r0 = r1->field_f
    //     0xc70bc4: ldur            w0, [x1, #0xf]
    // 0xc70bc8: DecompressPointer r0
    //     0xc70bc8: add             x0, x0, HEAP, lsl #32
    // 0xc70bcc: r2 = LoadClassIdInstr(r0)
    //     0xc70bcc: ldur            x2, [x0, #-1]
    //     0xc70bd0: ubfx            x2, x2, #0xc, #0x14
    // 0xc70bd4: lsl             x2, x2, #1
    // 0xc70bd8: r17 = 4206
    //     0xc70bd8: mov             x17, #0x106e
    // 0xc70bdc: cmp             w2, w17
    // 0xc70be0: b.ne            #0xc70bf4
    // 0xc70be4: mov             x16, x1
    // 0xc70be8: mov             x1, x0
    // 0xc70bec: mov             x0, x16
    // 0xc70bf0: b               #0xc70c20
    // 0xc70bf4: r2 = LoadClassIdInstr(r0)
    //     0xc70bf4: ldur            x2, [x0, #-1]
    //     0xc70bf8: ubfx            x2, x2, #0xc, #0x14
    // 0xc70bfc: ldr             x16, [fp, #0x10]
    // 0xc70c00: stp             x16, x0, [SP, #-0x10]!
    // 0xc70c04: mov             x0, x2
    // 0xc70c08: r0 = GDT[cid_x0 + -0xfdb]()
    //     0xc70c08: sub             lr, x0, #0xfdb
    //     0xc70c0c: ldr             lr, [x21, lr, lsl #3]
    //     0xc70c10: blr             lr
    // 0xc70c14: add             SP, SP, #0x10
    // 0xc70c18: mov             x1, x0
    // 0xc70c1c: ldr             x0, [fp, #0x20]
    // 0xc70c20: cmp             w1, NULL
    // 0xc70c24: b.eq            #0xc70cac
    // 0xc70c28: ldr             x16, [fp, #0x18]
    // 0xc70c2c: stp             x16, x1, [SP, #-0x10]!
    // 0xc70c30: r0 = deflateRect()
    //     0xc70c30: bl              #0x65ae60  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsets::deflateRect
    // 0xc70c34: add             SP, SP, #0x10
    // 0xc70c38: LoadField: d0 = r0->field_7
    //     0xc70c38: ldur            d0, [x0, #7]
    // 0xc70c3c: stur            d0, [fp, #-0x20]
    // 0xc70c40: LoadField: d1 = r0->field_1f
    //     0xc70c40: ldur            d1, [x0, #0x1f]
    // 0xc70c44: ldr             x1, [fp, #0x20]
    // 0xc70c48: LoadField: r2 = r1->field_b
    //     0xc70c48: ldur            w2, [x1, #0xb]
    // 0xc70c4c: DecompressPointer r2
    //     0xc70c4c: add             x2, x2, HEAP, lsl #32
    // 0xc70c50: LoadField: d2 = r2->field_b
    //     0xc70c50: ldur            d2, [x2, #0xb]
    // 0xc70c54: fsub            d3, d1, d2
    // 0xc70c58: stur            d3, [fp, #-0x18]
    // 0xc70c5c: LoadField: d1 = r0->field_17
    //     0xc70c5c: ldur            d1, [x0, #0x17]
    // 0xc70c60: fsub            d4, d1, d0
    // 0xc70c64: fadd            d1, d0, d4
    // 0xc70c68: stur            d1, [fp, #-0x10]
    // 0xc70c6c: fadd            d4, d3, d2
    // 0xc70c70: stur            d4, [fp, #-8]
    // 0xc70c74: r0 = Rect()
    //     0xc70c74: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc70c78: ldur            d0, [fp, #-0x20]
    // 0xc70c7c: StoreField: r0->field_7 = d0
    //     0xc70c7c: stur            d0, [x0, #7]
    // 0xc70c80: ldur            d0, [fp, #-0x18]
    // 0xc70c84: StoreField: r0->field_f = d0
    //     0xc70c84: stur            d0, [x0, #0xf]
    // 0xc70c88: ldur            d0, [fp, #-0x10]
    // 0xc70c8c: StoreField: r0->field_17 = d0
    //     0xc70c8c: stur            d0, [x0, #0x17]
    // 0xc70c90: ldur            d0, [fp, #-8]
    // 0xc70c94: StoreField: r0->field_1f = d0
    //     0xc70c94: stur            d0, [x0, #0x1f]
    // 0xc70c98: LeaveFrame
    //     0xc70c98: mov             SP, fp
    //     0xc70c9c: ldp             fp, lr, [SP], #0x10
    // 0xc70ca0: ret
    //     0xc70ca0: ret             
    // 0xc70ca4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc70ca4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc70ca8: b               #0xc70bc0
    // 0xc70cac: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc70cac: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ createBoxPainter(/* No info */) {
    // ** addr: 0xccf528, size: 0x44
    // 0xccf528: EnterFrame
    //     0xccf528: stp             fp, lr, [SP, #-0x10]!
    //     0xccf52c: mov             fp, SP
    // 0xccf530: AllocStack(0x8)
    //     0xccf530: sub             SP, SP, #8
    // 0xccf534: ldr             x0, [fp, #0x18]
    // 0xccf538: LoadField: r1 = r0->field_7
    //     0xccf538: ldur            w1, [x0, #7]
    // 0xccf53c: DecompressPointer r1
    //     0xccf53c: add             x1, x1, HEAP, lsl #32
    // 0xccf540: stur            x1, [fp, #-8]
    // 0xccf544: r0 = _UnderlinePainter()
    //     0xccf544: bl              #0xccf56c  ; Allocate_UnderlinePainterStub -> _UnderlinePainter (size=0x14)
    // 0xccf548: ldr             x1, [fp, #0x18]
    // 0xccf54c: StoreField: r0->field_b = r1
    //     0xccf54c: stur            w1, [x0, #0xb]
    // 0xccf550: ldur            x1, [fp, #-8]
    // 0xccf554: StoreField: r0->field_f = r1
    //     0xccf554: stur            w1, [x0, #0xf]
    // 0xccf558: ldr             x1, [fp, #0x10]
    // 0xccf55c: StoreField: r0->field_7 = r1
    //     0xccf55c: stur            w1, [x0, #7]
    // 0xccf560: LeaveFrame
    //     0xccf560: mov             SP, fp
    //     0xccf564: ldp             fp, lr, [SP], #0x10
    // 0xccf568: ret
    //     0xccf568: ret             
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0xcd51d8, size: 0x120
    // 0xcd51d8: EnterFrame
    //     0xcd51d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd51dc: mov             fp, SP
    // 0xcd51e0: AllocStack(0x10)
    //     0xcd51e0: sub             SP, SP, #0x10
    // 0xcd51e4: CheckStackOverflow
    //     0xcd51e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd51e8: cmp             SP, x16
    //     0xcd51ec: b.ls            #0xcd52cc
    // 0xcd51f0: ldr             x0, [fp, #0x18]
    // 0xcd51f4: r1 = LoadClassIdInstr(r0)
    //     0xcd51f4: ldur            x1, [x0, #-1]
    //     0xcd51f8: ubfx            x1, x1, #0xc, #0x14
    // 0xcd51fc: lsl             x1, x1, #1
    // 0xcd5200: r17 = 5876
    //     0xcd5200: mov             x17, #0x16f4
    // 0xcd5204: cmp             w1, w17
    // 0xcd5208: b.ne            #0xcd52bc
    // 0xcd520c: ldr             x1, [fp, #0x20]
    // 0xcd5210: ldr             d0, [fp, #0x10]
    // 0xcd5214: LoadField: r2 = r1->field_b
    //     0xcd5214: ldur            w2, [x1, #0xb]
    // 0xcd5218: DecompressPointer r2
    //     0xcd5218: add             x2, x2, HEAP, lsl #32
    // 0xcd521c: LoadField: r3 = r0->field_b
    //     0xcd521c: ldur            w3, [x0, #0xb]
    // 0xcd5220: DecompressPointer r3
    //     0xcd5220: add             x3, x3, HEAP, lsl #32
    // 0xcd5224: stp             x3, x2, [SP, #-0x10]!
    // 0xcd5228: SaveReg d0
    //     0xcd5228: str             d0, [SP, #-8]!
    // 0xcd522c: r0 = lerp()
    //     0xcd522c: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0xcd5230: add             SP, SP, #0x18
    // 0xcd5234: mov             x1, x0
    // 0xcd5238: ldr             x0, [fp, #0x20]
    // 0xcd523c: stur            x1, [fp, #-8]
    // 0xcd5240: LoadField: r2 = r0->field_f
    //     0xcd5240: ldur            w2, [x0, #0xf]
    // 0xcd5244: DecompressPointer r2
    //     0xcd5244: add             x2, x2, HEAP, lsl #32
    // 0xcd5248: ldr             x0, [fp, #0x18]
    // 0xcd524c: LoadField: r3 = r0->field_f
    //     0xcd524c: ldur            w3, [x0, #0xf]
    // 0xcd5250: DecompressPointer r3
    //     0xcd5250: add             x3, x3, HEAP, lsl #32
    // 0xcd5254: ldr             d0, [fp, #0x10]
    // 0xcd5258: r0 = inline_Allocate_Double()
    //     0xcd5258: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xcd525c: add             x0, x0, #0x10
    //     0xcd5260: cmp             x4, x0
    //     0xcd5264: b.ls            #0xcd52d4
    //     0xcd5268: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd526c: sub             x0, x0, #0xf
    //     0xcd5270: mov             x4, #0xd108
    //     0xcd5274: movk            x4, #3, lsl #16
    //     0xcd5278: stur            x4, [x0, #-1]
    // 0xcd527c: StoreField: r0->field_7 = d0
    //     0xcd527c: stur            d0, [x0, #7]
    // 0xcd5280: stp             x3, x2, [SP, #-0x10]!
    // 0xcd5284: SaveReg r0
    //     0xcd5284: str             x0, [SP, #-8]!
    // 0xcd5288: r0 = lerp()
    //     0xcd5288: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xcd528c: add             SP, SP, #0x18
    // 0xcd5290: stur            x0, [fp, #-0x10]
    // 0xcd5294: cmp             w0, NULL
    // 0xcd5298: b.eq            #0xcd52f4
    // 0xcd529c: r0 = UnderlineTabIndicator()
    //     0xcd529c: bl              #0x7bcf20  ; AllocateUnderlineTabIndicatorStub -> UnderlineTabIndicator (size=0x14)
    // 0xcd52a0: ldur            x1, [fp, #-8]
    // 0xcd52a4: StoreField: r0->field_b = r1
    //     0xcd52a4: stur            w1, [x0, #0xb]
    // 0xcd52a8: ldur            x1, [fp, #-0x10]
    // 0xcd52ac: StoreField: r0->field_f = r1
    //     0xcd52ac: stur            w1, [x0, #0xf]
    // 0xcd52b0: LeaveFrame
    //     0xcd52b0: mov             SP, fp
    //     0xcd52b4: ldp             fp, lr, [SP], #0x10
    // 0xcd52b8: ret
    //     0xcd52b8: ret             
    // 0xcd52bc: r0 = Null
    //     0xcd52bc: mov             x0, NULL
    // 0xcd52c0: LeaveFrame
    //     0xcd52c0: mov             SP, fp
    //     0xcd52c4: ldp             fp, lr, [SP], #0x10
    // 0xcd52c8: ret
    //     0xcd52c8: ret             
    // 0xcd52cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd52cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd52d0: b               #0xcd51f0
    // 0xcd52d4: SaveReg d0
    //     0xcd52d4: str             q0, [SP, #-0x10]!
    // 0xcd52d8: stp             x2, x3, [SP, #-0x10]!
    // 0xcd52dc: SaveReg r1
    //     0xcd52dc: str             x1, [SP, #-8]!
    // 0xcd52e0: r0 = AllocateDouble()
    //     0xcd52e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd52e4: RestoreReg r1
    //     0xcd52e4: ldr             x1, [SP], #8
    // 0xcd52e8: ldp             x2, x3, [SP], #0x10
    // 0xcd52ec: RestoreReg d0
    //     0xcd52ec: ldr             q0, [SP], #0x10
    // 0xcd52f0: b               #0xcd527c
    // 0xcd52f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd52f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0xcd71a8, size: 0x120
    // 0xcd71a8: EnterFrame
    //     0xcd71a8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd71ac: mov             fp, SP
    // 0xcd71b0: AllocStack(0x10)
    //     0xcd71b0: sub             SP, SP, #0x10
    // 0xcd71b4: CheckStackOverflow
    //     0xcd71b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd71b8: cmp             SP, x16
    //     0xcd71bc: b.ls            #0xcd729c
    // 0xcd71c0: ldr             x0, [fp, #0x18]
    // 0xcd71c4: r1 = LoadClassIdInstr(r0)
    //     0xcd71c4: ldur            x1, [x0, #-1]
    //     0xcd71c8: ubfx            x1, x1, #0xc, #0x14
    // 0xcd71cc: lsl             x1, x1, #1
    // 0xcd71d0: r17 = 5876
    //     0xcd71d0: mov             x17, #0x16f4
    // 0xcd71d4: cmp             w1, w17
    // 0xcd71d8: b.ne            #0xcd728c
    // 0xcd71dc: ldr             x1, [fp, #0x20]
    // 0xcd71e0: ldr             d0, [fp, #0x10]
    // 0xcd71e4: LoadField: r2 = r0->field_b
    //     0xcd71e4: ldur            w2, [x0, #0xb]
    // 0xcd71e8: DecompressPointer r2
    //     0xcd71e8: add             x2, x2, HEAP, lsl #32
    // 0xcd71ec: LoadField: r3 = r1->field_b
    //     0xcd71ec: ldur            w3, [x1, #0xb]
    // 0xcd71f0: DecompressPointer r3
    //     0xcd71f0: add             x3, x3, HEAP, lsl #32
    // 0xcd71f4: stp             x3, x2, [SP, #-0x10]!
    // 0xcd71f8: SaveReg d0
    //     0xcd71f8: str             d0, [SP, #-8]!
    // 0xcd71fc: r0 = lerp()
    //     0xcd71fc: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0xcd7200: add             SP, SP, #0x18
    // 0xcd7204: mov             x1, x0
    // 0xcd7208: ldr             x0, [fp, #0x18]
    // 0xcd720c: stur            x1, [fp, #-8]
    // 0xcd7210: LoadField: r2 = r0->field_f
    //     0xcd7210: ldur            w2, [x0, #0xf]
    // 0xcd7214: DecompressPointer r2
    //     0xcd7214: add             x2, x2, HEAP, lsl #32
    // 0xcd7218: ldr             x0, [fp, #0x20]
    // 0xcd721c: LoadField: r3 = r0->field_f
    //     0xcd721c: ldur            w3, [x0, #0xf]
    // 0xcd7220: DecompressPointer r3
    //     0xcd7220: add             x3, x3, HEAP, lsl #32
    // 0xcd7224: ldr             d0, [fp, #0x10]
    // 0xcd7228: r0 = inline_Allocate_Double()
    //     0xcd7228: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0xcd722c: add             x0, x0, #0x10
    //     0xcd7230: cmp             x4, x0
    //     0xcd7234: b.ls            #0xcd72a4
    //     0xcd7238: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd723c: sub             x0, x0, #0xf
    //     0xcd7240: mov             x4, #0xd108
    //     0xcd7244: movk            x4, #3, lsl #16
    //     0xcd7248: stur            x4, [x0, #-1]
    // 0xcd724c: StoreField: r0->field_7 = d0
    //     0xcd724c: stur            d0, [x0, #7]
    // 0xcd7250: stp             x3, x2, [SP, #-0x10]!
    // 0xcd7254: SaveReg r0
    //     0xcd7254: str             x0, [SP, #-8]!
    // 0xcd7258: r0 = lerp()
    //     0xcd7258: bl              #0xbf0f18  ; [package:flutter/src/painting/edge_insets.dart] EdgeInsetsGeometry::lerp
    // 0xcd725c: add             SP, SP, #0x18
    // 0xcd7260: stur            x0, [fp, #-0x10]
    // 0xcd7264: cmp             w0, NULL
    // 0xcd7268: b.eq            #0xcd72c4
    // 0xcd726c: r0 = UnderlineTabIndicator()
    //     0xcd726c: bl              #0x7bcf20  ; AllocateUnderlineTabIndicatorStub -> UnderlineTabIndicator (size=0x14)
    // 0xcd7270: ldur            x1, [fp, #-8]
    // 0xcd7274: StoreField: r0->field_b = r1
    //     0xcd7274: stur            w1, [x0, #0xb]
    // 0xcd7278: ldur            x1, [fp, #-0x10]
    // 0xcd727c: StoreField: r0->field_f = r1
    //     0xcd727c: stur            w1, [x0, #0xf]
    // 0xcd7280: LeaveFrame
    //     0xcd7280: mov             SP, fp
    //     0xcd7284: ldp             fp, lr, [SP], #0x10
    // 0xcd7288: ret
    //     0xcd7288: ret             
    // 0xcd728c: r0 = Null
    //     0xcd728c: mov             x0, NULL
    // 0xcd7290: LeaveFrame
    //     0xcd7290: mov             SP, fp
    //     0xcd7294: ldp             fp, lr, [SP], #0x10
    // 0xcd7298: ret
    //     0xcd7298: ret             
    // 0xcd729c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd729c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd72a0: b               #0xcd71c0
    // 0xcd72a4: SaveReg d0
    //     0xcd72a4: str             q0, [SP, #-0x10]!
    // 0xcd72a8: stp             x2, x3, [SP, #-0x10]!
    // 0xcd72ac: SaveReg r1
    //     0xcd72ac: str             x1, [SP, #-8]!
    // 0xcd72b0: r0 = AllocateDouble()
    //     0xcd72b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd72b4: RestoreReg r1
    //     0xcd72b4: ldr             x1, [SP], #8
    // 0xcd72b8: ldp             x2, x3, [SP], #0x10
    // 0xcd72bc: RestoreReg d0
    //     0xcd72bc: ldr             q0, [SP], #0x10
    // 0xcd72c0: b               #0xcd724c
    // 0xcd72c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd72c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4511, size: 0x14, field offset: 0xc
class _UnderlinePainter extends BoxPainter {

  _ paint(/* No info */) {
    // ** addr: 0xc70824, size: 0x384
    // 0xc70824: EnterFrame
    //     0xc70824: stp             fp, lr, [SP, #-0x10]!
    //     0xc70828: mov             fp, SP
    // 0xc7082c: AllocStack(0x58)
    //     0xc7082c: sub             SP, SP, #0x58
    // 0xc70830: CheckStackOverflow
    //     0xc70830: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc70834: cmp             SP, x16
    //     0xc70838: b.ls            #0xc70b94
    // 0xc7083c: ldr             x0, [fp, #0x10]
    // 0xc70840: LoadField: r1 = r0->field_17
    //     0xc70840: ldur            w1, [x0, #0x17]
    // 0xc70844: DecompressPointer r1
    //     0xc70844: add             x1, x1, HEAP, lsl #32
    // 0xc70848: cmp             w1, NULL
    // 0xc7084c: b.eq            #0xc70b9c
    // 0xc70850: ldr             x16, [fp, #0x18]
    // 0xc70854: stp             x1, x16, [SP, #-0x10]!
    // 0xc70858: r0 = &()
    //     0xc70858: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xc7085c: add             SP, SP, #0x10
    // 0xc70860: mov             x1, x0
    // 0xc70864: ldr             x0, [fp, #0x10]
    // 0xc70868: stur            x1, [fp, #-0x18]
    // 0xc7086c: LoadField: r2 = r0->field_13
    //     0xc7086c: ldur            w2, [x0, #0x13]
    // 0xc70870: DecompressPointer r2
    //     0xc70870: add             x2, x2, HEAP, lsl #32
    // 0xc70874: stur            x2, [fp, #-0x10]
    // 0xc70878: cmp             w2, NULL
    // 0xc7087c: b.eq            #0xc70ba0
    // 0xc70880: ldr             x0, [fp, #0x28]
    // 0xc70884: LoadField: r3 = r0->field_f
    //     0xc70884: ldur            w3, [x0, #0xf]
    // 0xc70888: DecompressPointer r3
    //     0xc70888: add             x3, x3, HEAP, lsl #32
    // 0xc7088c: stur            x3, [fp, #-8]
    // 0xc70890: cmp             w3, NULL
    // 0xc70894: b.eq            #0xc70a20
    // 0xc70898: r16 = 112
    //     0xc70898: mov             x16, #0x70
    // 0xc7089c: stp             x16, NULL, [SP, #-0x10]!
    // 0xc708a0: r0 = ByteData()
    //     0xc708a0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xc708a4: add             SP, SP, #0x10
    // 0xc708a8: stur            x0, [fp, #-0x20]
    // 0xc708ac: r0 = Paint()
    //     0xc708ac: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xc708b0: mov             x1, x0
    // 0xc708b4: ldur            x0, [fp, #-0x20]
    // 0xc708b8: stur            x1, [fp, #-0x30]
    // 0xc708bc: StoreField: r1->field_7 = r0
    //     0xc708bc: stur            w0, [x1, #7]
    // 0xc708c0: ldr             x2, [fp, #0x28]
    // 0xc708c4: LoadField: r3 = r2->field_b
    //     0xc708c4: ldur            w3, [x2, #0xb]
    // 0xc708c8: DecompressPointer r3
    //     0xc708c8: add             x3, x3, HEAP, lsl #32
    // 0xc708cc: LoadField: r2 = r3->field_b
    //     0xc708cc: ldur            w2, [x3, #0xb]
    // 0xc708d0: DecompressPointer r2
    //     0xc708d0: add             x2, x2, HEAP, lsl #32
    // 0xc708d4: stur            x2, [fp, #-0x28]
    // 0xc708d8: LoadField: r4 = r2->field_7
    //     0xc708d8: ldur            w4, [x2, #7]
    // 0xc708dc: DecompressPointer r4
    //     0xc708dc: add             x4, x4, HEAP, lsl #32
    // 0xc708e0: r5 = LoadClassIdInstr(r4)
    //     0xc708e0: ldur            x5, [x4, #-1]
    //     0xc708e4: ubfx            x5, x5, #0xc, #0x14
    // 0xc708e8: lsl             x5, x5, #1
    // 0xc708ec: r17 = 10124
    //     0xc708ec: mov             x17, #0x278c
    // 0xc708f0: cmp             w5, w17
    // 0xc708f4: b.gt            #0xc70904
    // 0xc708f8: r17 = 10122
    //     0xc708f8: mov             x17, #0x278a
    // 0xc708fc: cmp             w5, w17
    // 0xc70900: b.ge            #0xc7091c
    // 0xc70904: r17 = 10114
    //     0xc70904: mov             x17, #0x2782
    // 0xc70908: cmp             w5, w17
    // 0xc7090c: b.eq            #0xc7091c
    // 0xc70910: r17 = 10118
    //     0xc70910: mov             x17, #0x2786
    // 0xc70914: cmp             w5, w17
    // 0xc70918: b.ne            #0xc70924
    // 0xc7091c: LoadField: r5 = r4->field_7
    //     0xc7091c: ldur            x5, [x4, #7]
    // 0xc70920: b               #0xc70934
    // 0xc70924: LoadField: r5 = r4->field_f
    //     0xc70924: ldur            w5, [x4, #0xf]
    // 0xc70928: DecompressPointer r5
    //     0xc70928: add             x5, x5, HEAP, lsl #32
    // 0xc7092c: LoadField: r4 = r5->field_7
    //     0xc7092c: ldur            x4, [x5, #7]
    // 0xc70930: mov             x5, x4
    // 0xc70934: ldur            x4, [fp, #-8]
    // 0xc70938: eor             x6, x5, #0xff000000
    // 0xc7093c: LoadField: r5 = r0->field_17
    //     0xc7093c: ldur            w5, [x0, #0x17]
    // 0xc70940: DecompressPointer r5
    //     0xc70940: add             x5, x5, HEAP, lsl #32
    // 0xc70944: sxtw            x6, w6
    // 0xc70948: LoadField: r0 = r5->field_7
    //     0xc70948: ldur            x0, [x5, #7]
    // 0xc7094c: str             w6, [x0, #4]
    // 0xc70950: ldur            x16, [fp, #-0x18]
    // 0xc70954: stp             x16, x3, [SP, #-0x10]!
    // 0xc70958: ldur            x16, [fp, #-0x10]
    // 0xc7095c: SaveReg r16
    //     0xc7095c: str             x16, [SP, #-8]!
    // 0xc70960: r0 = _indicatorRectFor()
    //     0xc70960: bl              #0xc70ba8  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::_indicatorRectFor
    // 0xc70964: add             SP, SP, #0x18
    // 0xc70968: mov             x1, x0
    // 0xc7096c: ldur            x0, [fp, #-0x28]
    // 0xc70970: LoadField: d0 = r0->field_b
    //     0xc70970: ldur            d0, [x0, #0xb]
    // 0xc70974: d1 = 4.000000
    //     0xc70974: fmov            d1, #4.00000000
    // 0xc70978: fdiv            d2, d0, d1
    // 0xc7097c: SaveReg r1
    //     0xc7097c: str             x1, [SP, #-8]!
    // 0xc70980: SaveReg d2
    //     0xc70980: str             d2, [SP, #-8]!
    // 0xc70984: r0 = inflate()
    //     0xc70984: bl              #0x5d1480  ; [dart:ui] Rect::inflate
    // 0xc70988: add             SP, SP, #0x10
    // 0xc7098c: mov             x1, x0
    // 0xc70990: ldur            x0, [fp, #-8]
    // 0xc70994: stur            x1, [fp, #-0x48]
    // 0xc70998: LoadField: r2 = r0->field_7
    //     0xc70998: ldur            w2, [x0, #7]
    // 0xc7099c: DecompressPointer r2
    //     0xc7099c: add             x2, x2, HEAP, lsl #32
    // 0xc709a0: stur            x2, [fp, #-0x40]
    // 0xc709a4: LoadField: r3 = r0->field_b
    //     0xc709a4: ldur            w3, [x0, #0xb]
    // 0xc709a8: DecompressPointer r3
    //     0xc709a8: add             x3, x3, HEAP, lsl #32
    // 0xc709ac: stur            x3, [fp, #-0x38]
    // 0xc709b0: LoadField: r4 = r0->field_13
    //     0xc709b0: ldur            w4, [x0, #0x13]
    // 0xc709b4: DecompressPointer r4
    //     0xc709b4: add             x4, x4, HEAP, lsl #32
    // 0xc709b8: stur            x4, [fp, #-0x28]
    // 0xc709bc: LoadField: r5 = r0->field_f
    //     0xc709bc: ldur            w5, [x0, #0xf]
    // 0xc709c0: DecompressPointer r5
    //     0xc709c0: add             x5, x5, HEAP, lsl #32
    // 0xc709c4: stur            x5, [fp, #-0x20]
    // 0xc709c8: r0 = RRect()
    //     0xc709c8: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xc709cc: stur            x0, [fp, #-8]
    // 0xc709d0: ldur            x16, [fp, #-0x48]
    // 0xc709d4: stp             x16, x0, [SP, #-0x10]!
    // 0xc709d8: ldur            x16, [fp, #-0x40]
    // 0xc709dc: ldur            lr, [fp, #-0x38]
    // 0xc709e0: stp             lr, x16, [SP, #-0x10]!
    // 0xc709e4: ldur            x16, [fp, #-0x28]
    // 0xc709e8: ldur            lr, [fp, #-0x20]
    // 0xc709ec: stp             lr, x16, [SP, #-0x10]!
    // 0xc709f0: r4 = const [0, 0x6, 0x6, 0x2, bottomLeft, 0x5, bottomRight, 0x4, topLeft, 0x2, topRight, 0x3, null]
    //     0xc709f0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28950] List(13) [0, 0x6, 0x6, 0x2, "bottomLeft", 0x5, "bottomRight", 0x4, "topLeft", 0x2, "topRight", 0x3, Null]
    //     0xc709f4: ldr             x4, [x4, #0x950]
    // 0xc709f8: r0 = RRect.fromRectAndCorners()
    //     0xc709f8: bl              #0x6706f4  ; [dart:ui] RRect::RRect.fromRectAndCorners
    // 0xc709fc: add             SP, SP, #0x30
    // 0xc70a00: ldr             x16, [fp, #0x20]
    // 0xc70a04: ldur            lr, [fp, #-8]
    // 0xc70a08: stp             lr, x16, [SP, #-0x10]!
    // 0xc70a0c: ldur            x16, [fp, #-0x30]
    // 0xc70a10: SaveReg r16
    //     0xc70a10: str             x16, [SP, #-8]!
    // 0xc70a14: r0 = drawRRect()
    //     0xc70a14: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xc70a18: add             SP, SP, #0x18
    // 0xc70a1c: b               #0xc70b40
    // 0xc70a20: mov             x2, x0
    // 0xc70a24: LoadField: r0 = r2->field_b
    //     0xc70a24: ldur            w0, [x2, #0xb]
    // 0xc70a28: DecompressPointer r0
    //     0xc70a28: add             x0, x0, HEAP, lsl #32
    // 0xc70a2c: stur            x0, [fp, #-0x20]
    // 0xc70a30: LoadField: r1 = r0->field_b
    //     0xc70a30: ldur            w1, [x0, #0xb]
    // 0xc70a34: DecompressPointer r1
    //     0xc70a34: add             x1, x1, HEAP, lsl #32
    // 0xc70a38: stur            x1, [fp, #-8]
    // 0xc70a3c: SaveReg r1
    //     0xc70a3c: str             x1, [SP, #-8]!
    // 0xc70a40: r0 = toPaint()
    //     0xc70a40: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xc70a44: add             SP, SP, #8
    // 0xc70a48: stur            x0, [fp, #-0x38]
    // 0xc70a4c: cmp             w0, NULL
    // 0xc70a50: b.eq            #0xc70ba4
    // 0xc70a54: LoadField: r1 = r0->field_7
    //     0xc70a54: ldur            w1, [x0, #7]
    // 0xc70a58: DecompressPointer r1
    //     0xc70a58: add             x1, x1, HEAP, lsl #32
    // 0xc70a5c: LoadField: r2 = r1->field_13
    //     0xc70a5c: ldur            w2, [x1, #0x13]
    // 0xc70a60: DecompressPointer r2
    //     0xc70a60: add             x2, x2, HEAP, lsl #32
    // 0xc70a64: r3 = LoadInt32Instr(r2)
    //     0xc70a64: sbfx            x3, x2, #1, #0x1f
    // 0xc70a68: cmp             x3, #0x17
    // 0xc70a6c: b.le            #0xc70b50
    // 0xc70a70: ldur            x2, [fp, #-8]
    // 0xc70a74: r3 = 2
    //     0xc70a74: mov             x3, #2
    // 0xc70a78: LoadField: r4 = r1->field_17
    //     0xc70a78: ldur            w4, [x1, #0x17]
    // 0xc70a7c: DecompressPointer r4
    //     0xc70a7c: add             x4, x4, HEAP, lsl #32
    // 0xc70a80: LoadField: r5 = r1->field_1b
    //     0xc70a80: ldur            w5, [x1, #0x1b]
    // 0xc70a84: DecompressPointer r5
    //     0xc70a84: add             x5, x5, HEAP, lsl #32
    // 0xc70a88: r1 = LoadInt32Instr(r5)
    //     0xc70a88: sbfx            x1, x5, #1, #0x1f
    // 0xc70a8c: add             x5, x1, #0x14
    // 0xc70a90: LoadField: r1 = r4->field_7
    //     0xc70a90: ldur            x1, [x4, #7]
    // 0xc70a94: str             w3, [x1, x5]
    // 0xc70a98: ldur            x16, [fp, #-0x20]
    // 0xc70a9c: ldur            lr, [fp, #-0x18]
    // 0xc70aa0: stp             lr, x16, [SP, #-0x10]!
    // 0xc70aa4: ldur            x16, [fp, #-0x10]
    // 0xc70aa8: SaveReg r16
    //     0xc70aa8: str             x16, [SP, #-8]!
    // 0xc70aac: r0 = _indicatorRectFor()
    //     0xc70aac: bl              #0xc70ba8  ; [package:flutter/src/material/tab_indicator.dart] UnderlineTabIndicator::_indicatorRectFor
    // 0xc70ab0: add             SP, SP, #0x18
    // 0xc70ab4: mov             x1, x0
    // 0xc70ab8: ldur            x0, [fp, #-8]
    // 0xc70abc: LoadField: d0 = r0->field_b
    //     0xc70abc: ldur            d0, [x0, #0xb]
    // 0xc70ac0: d1 = 2.000000
    //     0xc70ac0: fmov            d1, #2.00000000
    // 0xc70ac4: fdiv            d2, d0, d1
    // 0xc70ac8: SaveReg r1
    //     0xc70ac8: str             x1, [SP, #-8]!
    // 0xc70acc: SaveReg d2
    //     0xc70acc: str             d2, [SP, #-8]!
    // 0xc70ad0: r0 = deflate()
    //     0xc70ad0: bl              #0x5d10ec  ; [dart:ui] Rect::deflate
    // 0xc70ad4: add             SP, SP, #0x10
    // 0xc70ad8: stur            x0, [fp, #-8]
    // 0xc70adc: LoadField: d0 = r0->field_7
    //     0xc70adc: ldur            d0, [x0, #7]
    // 0xc70ae0: stur            d0, [fp, #-0x58]
    // 0xc70ae4: LoadField: d1 = r0->field_1f
    //     0xc70ae4: ldur            d1, [x0, #0x1f]
    // 0xc70ae8: stur            d1, [fp, #-0x50]
    // 0xc70aec: r0 = Offset()
    //     0xc70aec: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc70af0: ldur            d0, [fp, #-0x58]
    // 0xc70af4: stur            x0, [fp, #-0x10]
    // 0xc70af8: StoreField: r0->field_7 = d0
    //     0xc70af8: stur            d0, [x0, #7]
    // 0xc70afc: ldur            d0, [fp, #-0x50]
    // 0xc70b00: StoreField: r0->field_f = d0
    //     0xc70b00: stur            d0, [x0, #0xf]
    // 0xc70b04: ldur            x1, [fp, #-8]
    // 0xc70b08: LoadField: d1 = r1->field_17
    //     0xc70b08: ldur            d1, [x1, #0x17]
    // 0xc70b0c: stur            d1, [fp, #-0x58]
    // 0xc70b10: r0 = Offset()
    //     0xc70b10: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc70b14: ldur            d0, [fp, #-0x58]
    // 0xc70b18: StoreField: r0->field_7 = d0
    //     0xc70b18: stur            d0, [x0, #7]
    // 0xc70b1c: ldur            d0, [fp, #-0x50]
    // 0xc70b20: StoreField: r0->field_f = d0
    //     0xc70b20: stur            d0, [x0, #0xf]
    // 0xc70b24: ldr             x16, [fp, #0x20]
    // 0xc70b28: ldur            lr, [fp, #-0x10]
    // 0xc70b2c: stp             lr, x16, [SP, #-0x10]!
    // 0xc70b30: ldur            x16, [fp, #-0x38]
    // 0xc70b34: stp             x16, x0, [SP, #-0x10]!
    // 0xc70b38: r0 = drawLine()
    //     0xc70b38: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xc70b3c: add             SP, SP, #0x20
    // 0xc70b40: r0 = Null
    //     0xc70b40: mov             x0, NULL
    // 0xc70b44: LeaveFrame
    //     0xc70b44: mov             SP, fp
    //     0xc70b48: ldp             fp, lr, [SP], #0x10
    // 0xc70b4c: ret
    //     0xc70b4c: ret             
    // 0xc70b50: sub             x0, x3, #4
    // 0xc70b54: lsl             x1, x0, #1
    // 0xc70b58: stur            x1, [fp, #-0x28]
    // 0xc70b5c: r0 = RangeError()
    //     0xc70b5c: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc70b60: stur            x0, [fp, #-0x30]
    // 0xc70b64: r16 = 40
    //     0xc70b64: mov             x16, #0x28
    // 0xc70b68: stp             x16, x0, [SP, #-0x10]!
    // 0xc70b6c: ldur            x16, [fp, #-0x28]
    // 0xc70b70: stp             x16, xzr, [SP, #-0x10]!
    // 0xc70b74: r16 = "byteOffset"
    //     0xc70b74: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc70b78: SaveReg r16
    //     0xc70b78: str             x16, [SP, #-8]!
    // 0xc70b7c: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc70b7c: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc70b80: r0 = RangeError.range()
    //     0xc70b80: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc70b84: add             SP, SP, #0x28
    // 0xc70b88: ldur            x0, [fp, #-0x30]
    // 0xc70b8c: r0 = Throw()
    //     0xc70b8c: bl              #0xd67e38  ; ThrowStub
    // 0xc70b90: brk             #0
    // 0xc70b94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc70b94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc70b98: b               #0xc7083c
    // 0xc70b9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc70b9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc70ba0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc70ba0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc70ba4: r0 = NullErrorSharedWithoutFPURegs()
    //     0xc70ba4: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

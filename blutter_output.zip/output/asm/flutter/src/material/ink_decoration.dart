// lib: , url: package:flutter/src/material/ink_decoration.dart

// class id: 1049254, size: 0x8
class :: {
}

// class id: 2200, size: 0x20, field offset: 0x14
class InkDecoration extends InkFeature {

  set _ configuration=(/* No info */) {
    // ** addr: 0x8544d8, size: 0x94
    // 0x8544d8: EnterFrame
    //     0x8544d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8544dc: mov             fp, SP
    // 0x8544e0: CheckStackOverflow
    //     0x8544e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8544e4: cmp             SP, x16
    //     0x8544e8: b.ls            #0x854564
    // 0x8544ec: ldr             x0, [fp, #0x18]
    // 0x8544f0: LoadField: r1 = r0->field_1b
    //     0x8544f0: ldur            w1, [x0, #0x1b]
    // 0x8544f4: DecompressPointer r1
    //     0x8544f4: add             x1, x1, HEAP, lsl #32
    // 0x8544f8: ldr             x16, [fp, #0x10]
    // 0x8544fc: stp             x1, x16, [SP, #-0x10]!
    // 0x854500: r0 = ==()
    //     0x854500: bl              #0xc9d8f4  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::==
    // 0x854504: add             SP, SP, #0x10
    // 0x854508: tbnz            w0, #4, #0x85451c
    // 0x85450c: r0 = Null
    //     0x85450c: mov             x0, NULL
    // 0x854510: LeaveFrame
    //     0x854510: mov             SP, fp
    //     0x854514: ldp             fp, lr, [SP], #0x10
    // 0x854518: ret
    //     0x854518: ret             
    // 0x85451c: ldr             x1, [fp, #0x18]
    // 0x854520: ldr             x0, [fp, #0x10]
    // 0x854524: StoreField: r1->field_1b = r0
    //     0x854524: stur            w0, [x1, #0x1b]
    //     0x854528: ldurb           w16, [x1, #-1]
    //     0x85452c: ldurb           w17, [x0, #-1]
    //     0x854530: and             x16, x17, x16, lsr #2
    //     0x854534: tst             x16, HEAP, lsr #32
    //     0x854538: b.eq            #0x854540
    //     0x85453c: bl              #0xd6826c
    // 0x854540: LoadField: r0 = r1->field_7
    //     0x854540: ldur            w0, [x1, #7]
    // 0x854544: DecompressPointer r0
    //     0x854544: add             x0, x0, HEAP, lsl #32
    // 0x854548: SaveReg r0
    //     0x854548: str             x0, [SP, #-8]!
    // 0x85454c: r0 = markNeedsPaint()
    //     0x85454c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x854550: add             SP, SP, #8
    // 0x854554: r0 = Null
    //     0x854554: mov             x0, NULL
    // 0x854558: LeaveFrame
    //     0x854558: mov             SP, fp
    //     0x85455c: ldp             fp, lr, [SP], #0x10
    // 0x854560: ret
    //     0x854560: ret             
    // 0x854564: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854564: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854568: b               #0x8544ec
  }
  set _ decoration=(/* No info */) {
    // ** addr: 0x85456c, size: 0x148
    // 0x85456c: EnterFrame
    //     0x85456c: stp             fp, lr, [SP, #-0x10]!
    //     0x854570: mov             fp, SP
    // 0x854574: AllocStack(0x8)
    //     0x854574: sub             SP, SP, #8
    // 0x854578: CheckStackOverflow
    //     0x854578: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85457c: cmp             SP, x16
    //     0x854580: b.ls            #0x8546ac
    // 0x854584: ldr             x1, [fp, #0x18]
    // 0x854588: LoadField: r0 = r1->field_17
    //     0x854588: ldur            w0, [x1, #0x17]
    // 0x85458c: DecompressPointer r0
    //     0x85458c: add             x0, x0, HEAP, lsl #32
    // 0x854590: ldr             x2, [fp, #0x10]
    // 0x854594: r3 = LoadClassIdInstr(r2)
    //     0x854594: ldur            x3, [x2, #-1]
    //     0x854598: ubfx            x3, x3, #0xc, #0x14
    // 0x85459c: stp             x0, x2, [SP, #-0x10]!
    // 0x8545a0: mov             x0, x3
    // 0x8545a4: mov             lr, x0
    // 0x8545a8: ldr             lr, [x21, lr, lsl #3]
    // 0x8545ac: blr             lr
    // 0x8545b0: add             SP, SP, #0x10
    // 0x8545b4: tbnz            w0, #4, #0x8545c8
    // 0x8545b8: r0 = Null
    //     0x8545b8: mov             x0, NULL
    // 0x8545bc: LeaveFrame
    //     0x8545bc: mov             SP, fp
    //     0x8545c0: ldp             fp, lr, [SP], #0x10
    // 0x8545c4: ret
    //     0x8545c4: ret             
    // 0x8545c8: ldr             x1, [fp, #0x18]
    // 0x8545cc: ldr             x0, [fp, #0x10]
    // 0x8545d0: StoreField: r1->field_17 = r0
    //     0x8545d0: stur            w0, [x1, #0x17]
    //     0x8545d4: ldurb           w16, [x1, #-1]
    //     0x8545d8: ldurb           w17, [x0, #-1]
    //     0x8545dc: and             x16, x17, x16, lsr #2
    //     0x8545e0: tst             x16, HEAP, lsr #32
    //     0x8545e4: b.eq            #0x8545ec
    //     0x8545e8: bl              #0xd6826c
    // 0x8545ec: LoadField: r0 = r1->field_13
    //     0x8545ec: ldur            w0, [x1, #0x13]
    // 0x8545f0: DecompressPointer r0
    //     0x8545f0: add             x0, x0, HEAP, lsl #32
    // 0x8545f4: cmp             w0, NULL
    // 0x8545f8: b.ne            #0x854604
    // 0x8545fc: mov             x0, x1
    // 0x854600: b               #0x854614
    // 0x854604: SaveReg r0
    //     0x854604: str             x0, [SP, #-8]!
    // 0x854608: r0 = dispose()
    //     0x854608: bl              #0xc75830  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::dispose
    // 0x85460c: add             SP, SP, #8
    // 0x854610: ldr             x0, [fp, #0x18]
    // 0x854614: LoadField: r1 = r0->field_17
    //     0x854614: ldur            w1, [x0, #0x17]
    // 0x854618: DecompressPointer r1
    //     0x854618: add             x1, x1, HEAP, lsl #32
    // 0x85461c: stur            x1, [fp, #-8]
    // 0x854620: cmp             w1, NULL
    // 0x854624: b.ne            #0x854634
    // 0x854628: mov             x1, x0
    // 0x85462c: r0 = Null
    //     0x85462c: mov             x0, NULL
    // 0x854630: b               #0x85466c
    // 0x854634: r1 = 1
    //     0x854634: mov             x1, #1
    // 0x854638: r0 = AllocateContext()
    //     0x854638: bl              #0xd68aa4  ; AllocateContextStub
    // 0x85463c: mov             x1, x0
    // 0x854640: ldr             x0, [fp, #0x18]
    // 0x854644: StoreField: r1->field_f = r0
    //     0x854644: stur            w0, [x1, #0xf]
    // 0x854648: mov             x2, x1
    // 0x85464c: r1 = Function '_handleChanged@755412529':.
    //     0x85464c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e28] AnonymousClosure: (0x8546b4), in [package:flutter/src/material/ink_decoration.dart] InkDecoration::_handleChanged (0x8546fc)
    //     0x854650: ldr             x1, [x1, #0xe28]
    // 0x854654: r0 = AllocateClosure()
    //     0x854654: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854658: ldur            x16, [fp, #-8]
    // 0x85465c: stp             x0, x16, [SP, #-0x10]!
    // 0x854660: r0 = createBoxPainter()
    //     0x854660: bl              #0xccf5ac  ; [package:flutter/src/painting/shape_decoration.dart] ShapeDecoration::createBoxPainter
    // 0x854664: add             SP, SP, #0x10
    // 0x854668: ldr             x1, [fp, #0x18]
    // 0x85466c: StoreField: r1->field_13 = r0
    //     0x85466c: stur            w0, [x1, #0x13]
    //     0x854670: ldurb           w16, [x1, #-1]
    //     0x854674: ldurb           w17, [x0, #-1]
    //     0x854678: and             x16, x17, x16, lsr #2
    //     0x85467c: tst             x16, HEAP, lsr #32
    //     0x854680: b.eq            #0x854688
    //     0x854684: bl              #0xd6826c
    // 0x854688: LoadField: r0 = r1->field_7
    //     0x854688: ldur            w0, [x1, #7]
    // 0x85468c: DecompressPointer r0
    //     0x85468c: add             x0, x0, HEAP, lsl #32
    // 0x854690: SaveReg r0
    //     0x854690: str             x0, [SP, #-8]!
    // 0x854694: r0 = markNeedsPaint()
    //     0x854694: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x854698: add             SP, SP, #8
    // 0x85469c: r0 = Null
    //     0x85469c: mov             x0, NULL
    // 0x8546a0: LeaveFrame
    //     0x8546a0: mov             SP, fp
    //     0x8546a4: ldp             fp, lr, [SP], #0x10
    // 0x8546a8: ret
    //     0x8546a8: ret             
    // 0x8546ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8546ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8546b0: b               #0x854584
  }
  [closure] void _handleChanged(dynamic) {
    // ** addr: 0x8546b4, size: 0x48
    // 0x8546b4: EnterFrame
    //     0x8546b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8546b8: mov             fp, SP
    // 0x8546bc: ldr             x0, [fp, #0x10]
    // 0x8546c0: LoadField: r1 = r0->field_17
    //     0x8546c0: ldur            w1, [x0, #0x17]
    // 0x8546c4: DecompressPointer r1
    //     0x8546c4: add             x1, x1, HEAP, lsl #32
    // 0x8546c8: CheckStackOverflow
    //     0x8546c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8546cc: cmp             SP, x16
    //     0x8546d0: b.ls            #0x8546f4
    // 0x8546d4: LoadField: r0 = r1->field_f
    //     0x8546d4: ldur            w0, [x1, #0xf]
    // 0x8546d8: DecompressPointer r0
    //     0x8546d8: add             x0, x0, HEAP, lsl #32
    // 0x8546dc: SaveReg r0
    //     0x8546dc: str             x0, [SP, #-8]!
    // 0x8546e0: r0 = _handleChanged()
    //     0x8546e0: bl              #0x8546fc  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::_handleChanged
    // 0x8546e4: add             SP, SP, #8
    // 0x8546e8: LeaveFrame
    //     0x8546e8: mov             SP, fp
    //     0x8546ec: ldp             fp, lr, [SP], #0x10
    // 0x8546f0: ret
    //     0x8546f0: ret             
    // 0x8546f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8546f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8546f8: b               #0x8546d4
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0x8546fc, size: 0x44
    // 0x8546fc: EnterFrame
    //     0x8546fc: stp             fp, lr, [SP, #-0x10]!
    //     0x854700: mov             fp, SP
    // 0x854704: CheckStackOverflow
    //     0x854704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x854708: cmp             SP, x16
    //     0x85470c: b.ls            #0x854738
    // 0x854710: ldr             x0, [fp, #0x10]
    // 0x854714: LoadField: r1 = r0->field_7
    //     0x854714: ldur            w1, [x0, #7]
    // 0x854718: DecompressPointer r1
    //     0x854718: add             x1, x1, HEAP, lsl #32
    // 0x85471c: SaveReg r1
    //     0x85471c: str             x1, [SP, #-8]!
    // 0x854720: r0 = markNeedsPaint()
    //     0x854720: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x854724: add             SP, SP, #8
    // 0x854728: r0 = Null
    //     0x854728: mov             x0, NULL
    // 0x85472c: LeaveFrame
    //     0x85472c: mov             SP, fp
    //     0x854730: ldp             fp, lr, [SP], #0x10
    // 0x854734: ret
    //     0x854734: ret             
    // 0x854738: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854738: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85473c: b               #0x854710
  }
  _ InkDecoration(/* No info */) {
    // ** addr: 0x854740, size: 0xd4
    // 0x854740: EnterFrame
    //     0x854740: stp             fp, lr, [SP, #-0x10]!
    //     0x854744: mov             fp, SP
    // 0x854748: CheckStackOverflow
    //     0x854748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85474c: cmp             SP, x16
    //     0x854750: b.ls            #0x85480c
    // 0x854754: ldr             x0, [fp, #0x30]
    // 0x854758: ldr             x1, [fp, #0x38]
    // 0x85475c: StoreField: r1->field_1b = r0
    //     0x85475c: stur            w0, [x1, #0x1b]
    //     0x854760: ldurb           w16, [x1, #-1]
    //     0x854764: ldurb           w17, [x0, #-1]
    //     0x854768: and             x16, x17, x16, lsr #2
    //     0x85476c: tst             x16, HEAP, lsr #32
    //     0x854770: b.eq            #0x854778
    //     0x854774: bl              #0xd6826c
    // 0x854778: ldr             x0, [fp, #0x10]
    // 0x85477c: StoreField: r1->field_b = r0
    //     0x85477c: stur            w0, [x1, #0xb]
    //     0x854780: ldurb           w16, [x1, #-1]
    //     0x854784: ldurb           w17, [x0, #-1]
    //     0x854788: and             x16, x17, x16, lsr #2
    //     0x85478c: tst             x16, HEAP, lsr #32
    //     0x854790: b.eq            #0x854798
    //     0x854794: bl              #0xd6826c
    // 0x854798: ldr             x0, [fp, #0x18]
    // 0x85479c: StoreField: r1->field_f = r0
    //     0x85479c: stur            w0, [x1, #0xf]
    //     0x8547a0: ldurb           w16, [x1, #-1]
    //     0x8547a4: ldurb           w17, [x0, #-1]
    //     0x8547a8: and             x16, x17, x16, lsr #2
    //     0x8547ac: tst             x16, HEAP, lsr #32
    //     0x8547b0: b.eq            #0x8547b8
    //     0x8547b4: bl              #0xd6826c
    // 0x8547b8: ldr             x0, [fp, #0x28]
    // 0x8547bc: StoreField: r1->field_7 = r0
    //     0x8547bc: stur            w0, [x1, #7]
    //     0x8547c0: ldurb           w16, [x1, #-1]
    //     0x8547c4: ldurb           w17, [x0, #-1]
    //     0x8547c8: and             x16, x17, x16, lsr #2
    //     0x8547cc: tst             x16, HEAP, lsr #32
    //     0x8547d0: b.eq            #0x8547d8
    //     0x8547d4: bl              #0xd6826c
    // 0x8547d8: ldr             x16, [fp, #0x20]
    // 0x8547dc: stp             x16, x1, [SP, #-0x10]!
    // 0x8547e0: r0 = decoration=()
    //     0x8547e0: bl              #0x85456c  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::decoration=
    // 0x8547e4: add             SP, SP, #0x10
    // 0x8547e8: ldr             x16, [fp, #0x28]
    // 0x8547ec: ldr             lr, [fp, #0x38]
    // 0x8547f0: stp             lr, x16, [SP, #-0x10]!
    // 0x8547f4: r0 = addInkFeature()
    //     0x8547f4: bl              #0x7b266c  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0x8547f8: add             SP, SP, #0x10
    // 0x8547fc: r0 = Null
    //     0x8547fc: mov             x0, NULL
    // 0x854800: LeaveFrame
    //     0x854800: mov             SP, fp
    //     0x854804: ldp             fp, lr, [SP], #0x10
    // 0x854808: ret
    //     0x854808: ret             
    // 0x85480c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85480c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854810: b               #0x854754
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0xbe4248, size: 0x160
    // 0xbe4248: EnterFrame
    //     0xbe4248: stp             fp, lr, [SP, #-0x10]!
    //     0xbe424c: mov             fp, SP
    // 0xbe4250: AllocStack(0x10)
    //     0xbe4250: sub             SP, SP, #0x10
    // 0xbe4254: CheckStackOverflow
    //     0xbe4254: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe4258: cmp             SP, x16
    //     0xbe425c: b.ls            #0xbe4394
    // 0xbe4260: ldr             x0, [fp, #0x20]
    // 0xbe4264: LoadField: r1 = r0->field_13
    //     0xbe4264: ldur            w1, [x0, #0x13]
    // 0xbe4268: DecompressPointer r1
    //     0xbe4268: add             x1, x1, HEAP, lsl #32
    // 0xbe426c: cmp             w1, NULL
    // 0xbe4270: b.ne            #0xbe4284
    // 0xbe4274: r0 = Null
    //     0xbe4274: mov             x0, NULL
    // 0xbe4278: LeaveFrame
    //     0xbe4278: mov             SP, fp
    //     0xbe427c: ldp             fp, lr, [SP], #0x10
    // 0xbe4280: ret
    //     0xbe4280: ret             
    // 0xbe4284: ldr             x16, [fp, #0x10]
    // 0xbe4288: SaveReg r16
    //     0xbe4288: str             x16, [SP, #-8]!
    // 0xbe428c: r0 = getAsTranslation()
    //     0xbe428c: bl              #0x665a04  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xbe4290: add             SP, SP, #8
    // 0xbe4294: mov             x1, x0
    // 0xbe4298: ldr             x0, [fp, #0x20]
    // 0xbe429c: stur            x1, [fp, #-8]
    // 0xbe42a0: LoadField: r2 = r0->field_1b
    //     0xbe42a0: ldur            w2, [x0, #0x1b]
    // 0xbe42a4: DecompressPointer r2
    //     0xbe42a4: add             x2, x2, HEAP, lsl #32
    // 0xbe42a8: LoadField: r3 = r0->field_b
    //     0xbe42a8: ldur            w3, [x0, #0xb]
    // 0xbe42ac: DecompressPointer r3
    //     0xbe42ac: add             x3, x3, HEAP, lsl #32
    // 0xbe42b0: LoadField: r4 = r3->field_57
    //     0xbe42b0: ldur            w4, [x3, #0x57]
    // 0xbe42b4: DecompressPointer r4
    //     0xbe42b4: add             x4, x4, HEAP, lsl #32
    // 0xbe42b8: cmp             w4, NULL
    // 0xbe42bc: b.eq            #0xbe439c
    // 0xbe42c0: stp             x4, x2, [SP, #-0x10]!
    // 0xbe42c4: r0 = copyWith()
    //     0xbe42c4: bl              #0x665584  ; [package:flutter/src/painting/image_provider.dart] ImageConfiguration::copyWith
    // 0xbe42c8: add             SP, SP, #0x10
    // 0xbe42cc: mov             x1, x0
    // 0xbe42d0: ldur            x0, [fp, #-8]
    // 0xbe42d4: stur            x1, [fp, #-0x10]
    // 0xbe42d8: cmp             w0, NULL
    // 0xbe42dc: b.ne            #0xbe4358
    // 0xbe42e0: ldr             x0, [fp, #0x20]
    // 0xbe42e4: ldr             x2, [fp, #0x10]
    // 0xbe42e8: ldr             x16, [fp, #0x18]
    // 0xbe42ec: SaveReg r16
    //     0xbe42ec: str             x16, [SP, #-8]!
    // 0xbe42f0: r0 = save()
    //     0xbe42f0: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xbe42f4: add             SP, SP, #8
    // 0xbe42f8: ldr             x0, [fp, #0x10]
    // 0xbe42fc: LoadField: r1 = r0->field_7
    //     0xbe42fc: ldur            w1, [x0, #7]
    // 0xbe4300: DecompressPointer r1
    //     0xbe4300: add             x1, x1, HEAP, lsl #32
    // 0xbe4304: ldr             x16, [fp, #0x18]
    // 0xbe4308: stp             x1, x16, [SP, #-0x10]!
    // 0xbe430c: r0 = transform()
    //     0xbe430c: bl              #0x656f48  ; [dart:ui] Canvas::transform
    // 0xbe4310: add             SP, SP, #0x10
    // 0xbe4314: ldr             x1, [fp, #0x20]
    // 0xbe4318: LoadField: r0 = r1->field_13
    //     0xbe4318: ldur            w0, [x1, #0x13]
    // 0xbe431c: DecompressPointer r0
    //     0xbe431c: add             x0, x0, HEAP, lsl #32
    // 0xbe4320: cmp             w0, NULL
    // 0xbe4324: b.eq            #0xbe43a0
    // 0xbe4328: ldr             x16, [fp, #0x18]
    // 0xbe432c: stp             x16, x0, [SP, #-0x10]!
    // 0xbe4330: r16 = Instance_Offset
    //     0xbe4330: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbe4334: ldur            lr, [fp, #-0x10]
    // 0xbe4338: stp             lr, x16, [SP, #-0x10]!
    // 0xbe433c: r0 = paint()
    //     0xbe433c: bl              #0xc71fa4  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::paint
    // 0xbe4340: add             SP, SP, #0x20
    // 0xbe4344: ldr             x16, [fp, #0x18]
    // 0xbe4348: SaveReg r16
    //     0xbe4348: str             x16, [SP, #-8]!
    // 0xbe434c: r0 = restore()
    //     0xbe434c: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xbe4350: add             SP, SP, #8
    // 0xbe4354: b               #0xbe4384
    // 0xbe4358: ldr             x1, [fp, #0x20]
    // 0xbe435c: LoadField: r2 = r1->field_13
    //     0xbe435c: ldur            w2, [x1, #0x13]
    // 0xbe4360: DecompressPointer r2
    //     0xbe4360: add             x2, x2, HEAP, lsl #32
    // 0xbe4364: cmp             w2, NULL
    // 0xbe4368: b.eq            #0xbe43a4
    // 0xbe436c: ldr             x16, [fp, #0x18]
    // 0xbe4370: stp             x16, x2, [SP, #-0x10]!
    // 0xbe4374: ldur            x16, [fp, #-0x10]
    // 0xbe4378: stp             x16, x0, [SP, #-0x10]!
    // 0xbe437c: r0 = paint()
    //     0xbe437c: bl              #0xc71fa4  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::paint
    // 0xbe4380: add             SP, SP, #0x20
    // 0xbe4384: r0 = Null
    //     0xbe4384: mov             x0, NULL
    // 0xbe4388: LeaveFrame
    //     0xbe4388: mov             SP, fp
    //     0xbe438c: ldp             fp, lr, [SP], #0x10
    // 0xbe4390: ret
    //     0xbe4390: ret             
    // 0xbe4394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4394: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4398: b               #0xbe4260
    // 0xbe439c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe439c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe43a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe43a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe43a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe43a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbfea08, size: 0x5c
    // 0xbfea08: EnterFrame
    //     0xbfea08: stp             fp, lr, [SP, #-0x10]!
    //     0xbfea0c: mov             fp, SP
    // 0xbfea10: CheckStackOverflow
    //     0xbfea10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfea14: cmp             SP, x16
    //     0xbfea18: b.ls            #0xbfea5c
    // 0xbfea1c: ldr             x0, [fp, #0x10]
    // 0xbfea20: LoadField: r1 = r0->field_13
    //     0xbfea20: ldur            w1, [x0, #0x13]
    // 0xbfea24: DecompressPointer r1
    //     0xbfea24: add             x1, x1, HEAP, lsl #32
    // 0xbfea28: cmp             w1, NULL
    // 0xbfea2c: b.eq            #0xbfea3c
    // 0xbfea30: SaveReg r1
    //     0xbfea30: str             x1, [SP, #-8]!
    // 0xbfea34: r0 = dispose()
    //     0xbfea34: bl              #0xc75830  ; [package:flutter/src/painting/shape_decoration.dart] _ShapeDecorationPainter::dispose
    // 0xbfea38: add             SP, SP, #8
    // 0xbfea3c: ldr             x16, [fp, #0x10]
    // 0xbfea40: SaveReg r16
    //     0xbfea40: str             x16, [SP, #-8]!
    // 0xbfea44: r0 = dispose()
    //     0xbfea44: bl              #0x795b14  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0xbfea48: add             SP, SP, #8
    // 0xbfea4c: r0 = Null
    //     0xbfea4c: mov             x0, NULL
    // 0xbfea50: LeaveFrame
    //     0xbfea50: mov             SP, fp
    //     0xbfea54: ldp             fp, lr, [SP], #0x10
    // 0xbfea58: ret
    //     0xbfea58: ret             
    // 0xbfea5c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfea5c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfea60: b               #0xbfea1c
  }
}

// class id: 3322, size: 0x1c, field offset: 0x14
class _InkState extends State<Ink> {

  _ deactivate(/* No info */) {
    // ** addr: 0x795658, size: 0x4c
    // 0x795658: EnterFrame
    //     0x795658: stp             fp, lr, [SP, #-0x10]!
    //     0x79565c: mov             fp, SP
    // 0x795660: CheckStackOverflow
    //     0x795660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795664: cmp             SP, x16
    //     0x795668: b.ls            #0x79569c
    // 0x79566c: ldr             x0, [fp, #0x10]
    // 0x795670: LoadField: r1 = r0->field_17
    //     0x795670: ldur            w1, [x0, #0x17]
    // 0x795674: DecompressPointer r1
    //     0x795674: add             x1, x1, HEAP, lsl #32
    // 0x795678: cmp             w1, NULL
    // 0x79567c: b.eq            #0x79568c
    // 0x795680: SaveReg r1
    //     0x795680: str             x1, [SP, #-8]!
    // 0x795684: r0 = dispose()
    //     0x795684: bl              #0xbfea08  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::dispose
    // 0x795688: add             SP, SP, #8
    // 0x79568c: r0 = Null
    //     0x79568c: mov             x0, NULL
    // 0x795690: LeaveFrame
    //     0x795690: mov             SP, fp
    //     0x795694: ldp             fp, lr, [SP], #0x10
    // 0x795698: ret
    //     0x795698: ret             
    // 0x79569c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x79569c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7956a0: b               #0x79566c
  }
  _ build(/* No info */) {
    // ** addr: 0x854104, size: 0xd0
    // 0x854104: EnterFrame
    //     0x854104: stp             fp, lr, [SP, #-0x10]!
    //     0x854108: mov             fp, SP
    // 0x85410c: AllocStack(0x20)
    //     0x85410c: sub             SP, SP, #0x20
    // 0x854110: CheckStackOverflow
    //     0x854110: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x854114: cmp             SP, x16
    //     0x854118: b.ls            #0x8541c4
    // 0x85411c: ldr             x0, [fp, #0x18]
    // 0x854120: LoadField: r1 = r0->field_13
    //     0x854120: ldur            w1, [x0, #0x13]
    // 0x854124: DecompressPointer r1
    //     0x854124: add             x1, x1, HEAP, lsl #32
    // 0x854128: stur            x1, [fp, #-8]
    // 0x85412c: LoadField: r2 = r0->field_b
    //     0x85412c: ldur            w2, [x0, #0xb]
    // 0x854130: DecompressPointer r2
    //     0x854130: add             x2, x2, HEAP, lsl #32
    // 0x854134: cmp             w2, NULL
    // 0x854138: b.eq            #0x8541cc
    // 0x85413c: SaveReg r2
    //     0x85413c: str             x2, [SP, #-8]!
    // 0x854140: r0 = _paddingIncludingDecoration()
    //     0x854140: bl              #0x8541d4  ; [package:flutter/src/material/ink_decoration.dart] Ink::_paddingIncludingDecoration
    // 0x854144: add             SP, SP, #8
    // 0x854148: stur            x0, [fp, #-0x10]
    // 0x85414c: r1 = 1
    //     0x85414c: mov             x1, #1
    // 0x854150: r0 = AllocateContext()
    //     0x854150: bl              #0xd68aa4  ; AllocateContextStub
    // 0x854154: mov             x1, x0
    // 0x854158: ldr             x0, [fp, #0x18]
    // 0x85415c: StoreField: r1->field_f = r0
    //     0x85415c: stur            w0, [x1, #0xf]
    // 0x854160: mov             x2, x1
    // 0x854164: r1 = Function '_build@755412529':.
    //     0x854164: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e08] AnonymousClosure: (0x854274), in [package:flutter/src/material/ink_decoration.dart] _InkState::_build (0x8542c0)
    //     0x854168: ldr             x1, [x1, #0xe08]
    // 0x85416c: r0 = AllocateClosure()
    //     0x85416c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x854170: stur            x0, [fp, #-0x18]
    // 0x854174: r0 = Builder()
    //     0x854174: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x854178: mov             x1, x0
    // 0x85417c: ldur            x0, [fp, #-0x18]
    // 0x854180: stur            x1, [fp, #-0x20]
    // 0x854184: StoreField: r1->field_b = r0
    //     0x854184: stur            w0, [x1, #0xb]
    // 0x854188: r0 = Padding()
    //     0x854188: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x85418c: ldur            x1, [fp, #-0x10]
    // 0x854190: StoreField: r0->field_f = r1
    //     0x854190: stur            w1, [x0, #0xf]
    // 0x854194: ldur            x1, [fp, #-0x20]
    // 0x854198: StoreField: r0->field_b = r1
    //     0x854198: stur            w1, [x0, #0xb]
    // 0x85419c: ldur            x1, [fp, #-8]
    // 0x8541a0: StoreField: r0->field_7 = r1
    //     0x8541a0: stur            w1, [x0, #7]
    // 0x8541a4: ldr             x1, [fp, #0x18]
    // 0x8541a8: LoadField: r2 = r1->field_b
    //     0x8541a8: ldur            w2, [x1, #0xb]
    // 0x8541ac: DecompressPointer r2
    //     0x8541ac: add             x2, x2, HEAP, lsl #32
    // 0x8541b0: cmp             w2, NULL
    // 0x8541b4: b.eq            #0x8541d0
    // 0x8541b8: LeaveFrame
    //     0x8541b8: mov             SP, fp
    //     0x8541bc: ldp             fp, lr, [SP], #0x10
    // 0x8541c0: ret
    //     0x8541c0: ret             
    // 0x8541c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8541c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8541c8: b               #0x85411c
    // 0x8541cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8541cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8541d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8541d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _build(dynamic, BuildContext) {
    // ** addr: 0x854274, size: 0x4c
    // 0x854274: EnterFrame
    //     0x854274: stp             fp, lr, [SP, #-0x10]!
    //     0x854278: mov             fp, SP
    // 0x85427c: ldr             x0, [fp, #0x18]
    // 0x854280: LoadField: r1 = r0->field_17
    //     0x854280: ldur            w1, [x0, #0x17]
    // 0x854284: DecompressPointer r1
    //     0x854284: add             x1, x1, HEAP, lsl #32
    // 0x854288: CheckStackOverflow
    //     0x854288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85428c: cmp             SP, x16
    //     0x854290: b.ls            #0x8542b8
    // 0x854294: LoadField: r0 = r1->field_f
    //     0x854294: ldur            w0, [x1, #0xf]
    // 0x854298: DecompressPointer r0
    //     0x854298: add             x0, x0, HEAP, lsl #32
    // 0x85429c: ldr             x16, [fp, #0x10]
    // 0x8542a0: stp             x16, x0, [SP, #-0x10]!
    // 0x8542a4: r0 = _build()
    //     0x8542a4: bl              #0x8542c0  ; [package:flutter/src/material/ink_decoration.dart] _InkState::_build
    // 0x8542a8: add             SP, SP, #0x10
    // 0x8542ac: LeaveFrame
    //     0x8542ac: mov             SP, fp
    //     0x8542b0: ldp             fp, lr, [SP], #0x10
    // 0x8542b4: ret
    //     0x8542b4: ret             
    // 0x8542b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8542b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8542bc: b               #0x854294
  }
  _ _build(/* No info */) {
    // ** addr: 0x8542c0, size: 0x218
    // 0x8542c0: EnterFrame
    //     0x8542c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8542c4: mov             fp, SP
    // 0x8542c8: AllocStack(0x30)
    //     0x8542c8: sub             SP, SP, #0x30
    // 0x8542cc: CheckStackOverflow
    //     0x8542cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8542d0: cmp             SP, x16
    //     0x8542d4: b.ls            #0x8544b8
    // 0x8542d8: ldr             x0, [fp, #0x18]
    // 0x8542dc: LoadField: r1 = r0->field_17
    //     0x8542dc: ldur            w1, [x0, #0x17]
    // 0x8542e0: DecompressPointer r1
    //     0x8542e0: add             x1, x1, HEAP, lsl #32
    // 0x8542e4: cmp             w1, NULL
    // 0x8542e8: b.ne            #0x85442c
    // 0x8542ec: LoadField: r1 = r0->field_b
    //     0x8542ec: ldur            w1, [x0, #0xb]
    // 0x8542f0: DecompressPointer r1
    //     0x8542f0: add             x1, x1, HEAP, lsl #32
    // 0x8542f4: cmp             w1, NULL
    // 0x8542f8: b.eq            #0x8544c0
    // 0x8542fc: LoadField: r2 = r1->field_13
    //     0x8542fc: ldur            w2, [x1, #0x13]
    // 0x854300: DecompressPointer r2
    //     0x854300: add             x2, x2, HEAP, lsl #32
    // 0x854304: stur            x2, [fp, #-8]
    // 0x854308: ldr             x16, [fp, #0x10]
    // 0x85430c: SaveReg r16
    //     0x85430c: str             x16, [SP, #-8]!
    // 0x854310: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x854310: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x854314: r0 = createLocalImageConfiguration()
    //     0x854314: bl              #0x6c7908  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0x854318: add             SP, SP, #8
    // 0x85431c: stur            x0, [fp, #-0x10]
    // 0x854320: ldr             x16, [fp, #0x10]
    // 0x854324: SaveReg r16
    //     0x854324: str             x16, [SP, #-8]!
    // 0x854328: r0 = of()
    //     0x854328: bl              #0x7b2858  ; [package:flutter/src/material/material.dart] Material::of
    // 0x85432c: add             SP, SP, #8
    // 0x854330: mov             x1, x0
    // 0x854334: ldr             x0, [fp, #0x18]
    // 0x854338: stur            x1, [fp, #-0x18]
    // 0x85433c: LoadField: r2 = r0->field_13
    //     0x85433c: ldur            w2, [x0, #0x13]
    // 0x854340: DecompressPointer r2
    //     0x854340: add             x2, x2, HEAP, lsl #32
    // 0x854344: SaveReg r2
    //     0x854344: str             x2, [SP, #-8]!
    // 0x854348: r0 = _currentElement()
    //     0x854348: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x85434c: add             SP, SP, #8
    // 0x854350: cmp             w0, NULL
    // 0x854354: b.eq            #0x8544c4
    // 0x854358: SaveReg r0
    //     0x854358: str             x0, [SP, #-8]!
    // 0x85435c: r0 = findRenderObject()
    //     0x85435c: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x854360: add             SP, SP, #8
    // 0x854364: mov             x3, x0
    // 0x854368: stur            x3, [fp, #-0x20]
    // 0x85436c: cmp             w3, NULL
    // 0x854370: b.eq            #0x8544c8
    // 0x854374: mov             x0, x3
    // 0x854378: r2 = Null
    //     0x854378: mov             x2, NULL
    // 0x85437c: r1 = Null
    //     0x85437c: mov             x1, NULL
    // 0x854380: r4 = LoadClassIdInstr(r0)
    //     0x854380: ldur            x4, [x0, #-1]
    //     0x854384: ubfx            x4, x4, #0xc, #0x14
    // 0x854388: sub             x4, x4, #0x965
    // 0x85438c: cmp             x4, #0x8b
    // 0x854390: b.ls            #0x8543a8
    // 0x854394: r8 = RenderBox
    //     0x854394: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x854398: ldr             x8, [x8, #0xfa0]
    // 0x85439c: r3 = Null
    //     0x85439c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56e10] Null
    //     0x8543a0: ldr             x3, [x3, #0xe10]
    // 0x8543a4: r0 = RenderBox()
    //     0x8543a4: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x8543a8: r1 = 1
    //     0x8543a8: mov             x1, #1
    // 0x8543ac: r0 = AllocateContext()
    //     0x8543ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8543b0: mov             x1, x0
    // 0x8543b4: ldr             x0, [fp, #0x18]
    // 0x8543b8: StoreField: r1->field_f = r0
    //     0x8543b8: stur            w0, [x1, #0xf]
    // 0x8543bc: mov             x2, x1
    // 0x8543c0: r1 = Function '_handleRemoved@755412529':.
    //     0x8543c0: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e20] AnonymousClosure: (0x854820), in [dart:convert] _JsonListener::handleNull (0x4f2ef0)
    //     0x8543c4: ldr             x1, [x1, #0xe20]
    // 0x8543c8: r0 = AllocateClosure()
    //     0x8543c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8543cc: stur            x0, [fp, #-0x28]
    // 0x8543d0: r0 = InkDecoration()
    //     0x8543d0: bl              #0x854814  ; AllocateInkDecorationStub -> InkDecoration (size=0x20)
    // 0x8543d4: stur            x0, [fp, #-0x30]
    // 0x8543d8: ldur            x16, [fp, #-0x10]
    // 0x8543dc: stp             x16, x0, [SP, #-0x10]!
    // 0x8543e0: ldur            x16, [fp, #-0x18]
    // 0x8543e4: ldur            lr, [fp, #-8]
    // 0x8543e8: stp             lr, x16, [SP, #-0x10]!
    // 0x8543ec: ldur            x16, [fp, #-0x28]
    // 0x8543f0: ldur            lr, [fp, #-0x20]
    // 0x8543f4: stp             lr, x16, [SP, #-0x10]!
    // 0x8543f8: r0 = InkDecoration()
    //     0x8543f8: bl              #0x854740  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::InkDecoration
    // 0x8543fc: add             SP, SP, #0x30
    // 0x854400: ldur            x0, [fp, #-0x30]
    // 0x854404: ldr             x2, [fp, #0x18]
    // 0x854408: StoreField: r2->field_17 = r0
    //     0x854408: stur            w0, [x2, #0x17]
    //     0x85440c: ldurb           w16, [x2, #-1]
    //     0x854410: ldurb           w17, [x0, #-1]
    //     0x854414: and             x16, x17, x16, lsr #2
    //     0x854418: tst             x16, HEAP, lsr #32
    //     0x85441c: b.eq            #0x854424
    //     0x854420: bl              #0xd6828c
    // 0x854424: mov             x1, x2
    // 0x854428: b               #0x854494
    // 0x85442c: mov             x2, x0
    // 0x854430: LoadField: r0 = r2->field_b
    //     0x854430: ldur            w0, [x2, #0xb]
    // 0x854434: DecompressPointer r0
    //     0x854434: add             x0, x0, HEAP, lsl #32
    // 0x854438: cmp             w0, NULL
    // 0x85443c: b.eq            #0x8544cc
    // 0x854440: LoadField: r3 = r0->field_13
    //     0x854440: ldur            w3, [x0, #0x13]
    // 0x854444: DecompressPointer r3
    //     0x854444: add             x3, x3, HEAP, lsl #32
    // 0x854448: stp             x3, x1, [SP, #-0x10]!
    // 0x85444c: r0 = decoration=()
    //     0x85444c: bl              #0x85456c  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::decoration=
    // 0x854450: add             SP, SP, #0x10
    // 0x854454: ldr             x0, [fp, #0x18]
    // 0x854458: LoadField: r1 = r0->field_17
    //     0x854458: ldur            w1, [x0, #0x17]
    // 0x85445c: DecompressPointer r1
    //     0x85445c: add             x1, x1, HEAP, lsl #32
    // 0x854460: stur            x1, [fp, #-8]
    // 0x854464: cmp             w1, NULL
    // 0x854468: b.eq            #0x8544d0
    // 0x85446c: ldr             x16, [fp, #0x10]
    // 0x854470: SaveReg r16
    //     0x854470: str             x16, [SP, #-8]!
    // 0x854474: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x854474: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x854478: r0 = createLocalImageConfiguration()
    //     0x854478: bl              #0x6c7908  ; [package:flutter/src/widgets/image.dart] ::createLocalImageConfiguration
    // 0x85447c: add             SP, SP, #8
    // 0x854480: ldur            x16, [fp, #-8]
    // 0x854484: stp             x0, x16, [SP, #-0x10]!
    // 0x854488: r0 = configuration=()
    //     0x854488: bl              #0x8544d8  ; [package:flutter/src/material/ink_decoration.dart] InkDecoration::configuration=
    // 0x85448c: add             SP, SP, #0x10
    // 0x854490: ldr             x1, [fp, #0x18]
    // 0x854494: LoadField: r2 = r1->field_b
    //     0x854494: ldur            w2, [x1, #0xb]
    // 0x854498: DecompressPointer r2
    //     0x854498: add             x2, x2, HEAP, lsl #32
    // 0x85449c: cmp             w2, NULL
    // 0x8544a0: b.eq            #0x8544d4
    // 0x8544a4: LoadField: r0 = r2->field_b
    //     0x8544a4: ldur            w0, [x2, #0xb]
    // 0x8544a8: DecompressPointer r0
    //     0x8544a8: add             x0, x0, HEAP, lsl #32
    // 0x8544ac: LeaveFrame
    //     0x8544ac: mov             SP, fp
    //     0x8544b0: ldp             fp, lr, [SP], #0x10
    // 0x8544b4: ret
    //     0x8544b4: ret             
    // 0x8544b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8544b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8544bc: b               #0x8542d8
    // 0x8544c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8544c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8544c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8544c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8544c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8544c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8544cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8544cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8544d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8544d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8544d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8544d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleRemoved(dynamic) {
    // ** addr: 0x854820, size: 0x48
    // 0x854820: EnterFrame
    //     0x854820: stp             fp, lr, [SP, #-0x10]!
    //     0x854824: mov             fp, SP
    // 0x854828: ldr             x0, [fp, #0x10]
    // 0x85482c: LoadField: r1 = r0->field_17
    //     0x85482c: ldur            w1, [x0, #0x17]
    // 0x854830: DecompressPointer r1
    //     0x854830: add             x1, x1, HEAP, lsl #32
    // 0x854834: CheckStackOverflow
    //     0x854834: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x854838: cmp             SP, x16
    //     0x85483c: b.ls            #0x854860
    // 0x854840: LoadField: r0 = r1->field_f
    //     0x854840: ldur            w0, [x1, #0xf]
    // 0x854844: DecompressPointer r0
    //     0x854844: add             x0, x0, HEAP, lsl #32
    // 0x854848: SaveReg r0
    //     0x854848: str             x0, [SP, #-8]!
    // 0x85484c: r0 = handleNull()
    //     0x85484c: bl              #0x4f2ef0  ; [dart:convert] _JsonListener::handleNull
    // 0x854850: add             SP, SP, #8
    // 0x854854: LeaveFrame
    //     0x854854: mov             SP, fp
    //     0x854858: ldp             fp, lr, [SP], #0x10
    // 0x85485c: ret
    //     0x85485c: ret             
    // 0x854860: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x854860: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854864: b               #0x854840
  }
}

// class id: 4153, size: 0x20, field offset: 0xc
class Ink extends StatefulWidget {

  get _ _paddingIncludingDecoration(/* No info */) {
    // ** addr: 0x8541d4, size: 0xa0
    // 0x8541d4: EnterFrame
    //     0x8541d4: stp             fp, lr, [SP, #-0x10]!
    //     0x8541d8: mov             fp, SP
    // 0x8541dc: AllocStack(0x8)
    //     0x8541dc: sub             SP, SP, #8
    // 0x8541e0: CheckStackOverflow
    //     0x8541e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8541e4: cmp             SP, x16
    //     0x8541e8: b.ls            #0x85426c
    // 0x8541ec: ldr             x0, [fp, #0x10]
    // 0x8541f0: LoadField: r1 = r0->field_13
    //     0x8541f0: ldur            w1, [x0, #0x13]
    // 0x8541f4: DecompressPointer r1
    //     0x8541f4: add             x1, x1, HEAP, lsl #32
    // 0x8541f8: cmp             w1, NULL
    // 0x8541fc: b.ne            #0x854214
    // 0x854200: r0 = Instance_EdgeInsets
    //     0x854200: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x854204: ldr             x0, [x0, #0xbd8]
    // 0x854208: LeaveFrame
    //     0x854208: mov             SP, fp
    //     0x85420c: ldp             fp, lr, [SP], #0x10
    // 0x854210: ret
    //     0x854210: ret             
    // 0x854214: LoadField: r2 = r1->field_17
    //     0x854214: ldur            w2, [x1, #0x17]
    // 0x854218: DecompressPointer r2
    //     0x854218: add             x2, x2, HEAP, lsl #32
    // 0x85421c: stur            x2, [fp, #-8]
    // 0x854220: r0 = LoadClassIdInstr(r2)
    //     0x854220: ldur            x0, [x2, #-1]
    //     0x854224: ubfx            x0, x0, #0xc, #0x14
    // 0x854228: SaveReg r2
    //     0x854228: str             x2, [SP, #-8]!
    // 0x85422c: r0 = GDT[cid_x0 + -0xe39]()
    //     0x85422c: sub             lr, x0, #0xe39
    //     0x854230: ldr             lr, [x21, lr, lsl #3]
    //     0x854234: blr             lr
    // 0x854238: add             SP, SP, #8
    // 0x85423c: ldur            x0, [fp, #-8]
    // 0x854240: r1 = LoadClassIdInstr(r0)
    //     0x854240: ldur            x1, [x0, #-1]
    //     0x854244: ubfx            x1, x1, #0xc, #0x14
    // 0x854248: SaveReg r0
    //     0x854248: str             x0, [SP, #-8]!
    // 0x85424c: mov             x0, x1
    // 0x854250: r0 = GDT[cid_x0 + -0xe39]()
    //     0x854250: sub             lr, x0, #0xe39
    //     0x854254: ldr             lr, [x21, lr, lsl #3]
    //     0x854258: blr             lr
    // 0x85425c: add             SP, SP, #8
    // 0x854260: LeaveFrame
    //     0x854260: mov             SP, fp
    //     0x854264: ldp             fp, lr, [SP], #0x10
    // 0x854268: ret
    //     0x854268: ret             
    // 0x85426c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85426c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x854270: b               #0x8541ec
  }
  _ createState(/* No info */) {
    // ** addr: 0xa40680, size: 0x3c
    // 0xa40680: EnterFrame
    //     0xa40680: stp             fp, lr, [SP, #-0x10]!
    //     0xa40684: mov             fp, SP
    // 0xa40688: AllocStack(0x8)
    //     0xa40688: sub             SP, SP, #8
    // 0xa4068c: r1 = <Ink>
    //     0xa4068c: add             x1, PP, #0x56, lsl #12  ; [pp+0x564d0] TypeArguments: <Ink>
    //     0xa40690: ldr             x1, [x1, #0x4d0]
    // 0xa40694: r0 = _InkState()
    //     0xa40694: bl              #0xa406bc  ; Allocate_InkStateStub -> _InkState (size=0x1c)
    // 0xa40698: r1 = <State<StatefulWidget>>
    //     0xa40698: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa4069c: stur            x0, [fp, #-8]
    // 0xa406a0: r0 = LabeledGlobalKey()
    //     0xa406a0: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa406a4: mov             x1, x0
    // 0xa406a8: ldur            x0, [fp, #-8]
    // 0xa406ac: StoreField: r0->field_13 = r1
    //     0xa406ac: stur            w1, [x0, #0x13]
    // 0xa406b0: LeaveFrame
    //     0xa406b0: mov             SP, fp
    //     0xa406b4: ldp             fp, lr, [SP], #0x10
    // 0xa406b8: ret
    //     0xa406b8: ret             
  }
}

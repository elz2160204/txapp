// lib: , url: package:flutter/src/material/ink_highlight.dart

// class id: 1049255, size: 0x8
class :: {
}

// class id: 2199, size: 0x3c, field offset: 0x18
class InkHighlight extends InteractiveInkFeature {

  late AnimationController _alphaController; // offset: 0x34
  late Animation<int> _alpha; // offset: 0x30

  _ deactivate(/* No info */) {
    // ** addr: 0x7b2080, size: 0x68
    // 0x7b2080: EnterFrame
    //     0x7b2080: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2084: mov             fp, SP
    // 0x7b2088: r0 = false
    //     0x7b2088: add             x0, NULL, #0x30  ; false
    // 0x7b208c: CheckStackOverflow
    //     0x7b208c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2090: cmp             SP, x16
    //     0x7b2094: b.ls            #0x7b20d4
    // 0x7b2098: ldr             x1, [fp, #0x10]
    // 0x7b209c: StoreField: r1->field_37 = r0
    //     0x7b209c: stur            w0, [x1, #0x37]
    // 0x7b20a0: LoadField: r0 = r1->field_33
    //     0x7b20a0: ldur            w0, [x1, #0x33]
    // 0x7b20a4: DecompressPointer r0
    //     0x7b20a4: add             x0, x0, HEAP, lsl #32
    // 0x7b20a8: r16 = Sentinel
    //     0x7b20a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b20ac: cmp             w0, w16
    // 0x7b20b0: b.eq            #0x7b20dc
    // 0x7b20b4: SaveReg r0
    //     0x7b20b4: str             x0, [SP, #-8]!
    // 0x7b20b8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b20b8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b20bc: r0 = reverse()
    //     0x7b20bc: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x7b20c0: add             SP, SP, #8
    // 0x7b20c4: r0 = Null
    //     0x7b20c4: mov             x0, NULL
    // 0x7b20c8: LeaveFrame
    //     0x7b20c8: mov             SP, fp
    //     0x7b20cc: ldp             fp, lr, [SP], #0x10
    // 0x7b20d0: ret
    //     0x7b20d0: ret             
    // 0x7b20d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b20d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b20d8: b               #0x7b2098
    // 0x7b20dc: r9 = _alphaController
    //     0x7b20dc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2a8] Field <InkHighlight._alphaController@756209331>: late (offset: 0x34)
    //     0x7b20e0: ldr             x9, [x9, #0x2a8]
    // 0x7b20e4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b20e4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ activate(/* No info */) {
    // ** addr: 0x7b20e8, size: 0x68
    // 0x7b20e8: EnterFrame
    //     0x7b20e8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b20ec: mov             fp, SP
    // 0x7b20f0: r0 = true
    //     0x7b20f0: add             x0, NULL, #0x20  ; true
    // 0x7b20f4: CheckStackOverflow
    //     0x7b20f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b20f8: cmp             SP, x16
    //     0x7b20fc: b.ls            #0x7b213c
    // 0x7b2100: ldr             x1, [fp, #0x10]
    // 0x7b2104: StoreField: r1->field_37 = r0
    //     0x7b2104: stur            w0, [x1, #0x37]
    // 0x7b2108: LoadField: r0 = r1->field_33
    //     0x7b2108: ldur            w0, [x1, #0x33]
    // 0x7b210c: DecompressPointer r0
    //     0x7b210c: add             x0, x0, HEAP, lsl #32
    // 0x7b2110: r16 = Sentinel
    //     0x7b2110: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b2114: cmp             w0, w16
    // 0x7b2118: b.eq            #0x7b2144
    // 0x7b211c: SaveReg r0
    //     0x7b211c: str             x0, [SP, #-8]!
    // 0x7b2120: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b2120: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b2124: r0 = forward()
    //     0x7b2124: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7b2128: add             SP, SP, #8
    // 0x7b212c: r0 = Null
    //     0x7b212c: mov             x0, NULL
    // 0x7b2130: LeaveFrame
    //     0x7b2130: mov             SP, fp
    //     0x7b2134: ldp             fp, lr, [SP], #0x10
    // 0x7b2138: ret
    //     0x7b2138: ret             
    // 0x7b213c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b213c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2140: b               #0x7b2100
    // 0x7b2144: r9 = _alphaController
    //     0x7b2144: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2a8] Field <InkHighlight._alphaController@756209331>: late (offset: 0x34)
    //     0x7b2148: ldr             x9, [x9, #0x2a8]
    // 0x7b214c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b214c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ InkHighlight(/* No info */) {
    // ** addr: 0x7b232c, size: 0x340
    // 0x7b232c: EnterFrame
    //     0x7b232c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b2330: mov             fp, SP
    // 0x7b2334: AllocStack(0x18)
    //     0x7b2334: sub             SP, SP, #0x18
    // 0x7b2338: r1 = Sentinel
    //     0x7b2338: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b233c: r0 = true
    //     0x7b233c: add             x0, NULL, #0x20  ; true
    // 0x7b2340: CheckStackOverflow
    //     0x7b2340: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b2344: cmp             SP, x16
    //     0x7b2348: b.ls            #0x7b2664
    // 0x7b234c: ldr             x2, [fp, #0x68]
    // 0x7b2350: StoreField: r2->field_2f = r1
    //     0x7b2350: stur            w1, [x2, #0x2f]
    // 0x7b2354: StoreField: r2->field_33 = r1
    //     0x7b2354: stur            w1, [x2, #0x33]
    // 0x7b2358: StoreField: r2->field_37 = r0
    //     0x7b2358: stur            w0, [x2, #0x37]
    // 0x7b235c: ldr             x0, [fp, #0x18]
    // 0x7b2360: StoreField: r2->field_17 = r0
    //     0x7b2360: stur            w0, [x2, #0x17]
    //     0x7b2364: ldurb           w16, [x2, #-1]
    //     0x7b2368: ldurb           w17, [x0, #-1]
    //     0x7b236c: and             x16, x17, x16, lsr #2
    //     0x7b2370: tst             x16, HEAP, lsr #32
    //     0x7b2374: b.eq            #0x7b237c
    //     0x7b2378: bl              #0xd6828c
    // 0x7b237c: ldr             x0, [fp, #0x30]
    // 0x7b2380: StoreField: r2->field_1b = r0
    //     0x7b2380: stur            w0, [x2, #0x1b]
    //     0x7b2384: ldurb           w16, [x2, #-1]
    //     0x7b2388: ldurb           w17, [x0, #-1]
    //     0x7b238c: and             x16, x17, x16, lsr #2
    //     0x7b2390: tst             x16, HEAP, lsr #32
    //     0x7b2394: b.eq            #0x7b239c
    //     0x7b2398: bl              #0xd6828c
    // 0x7b239c: ldr             x0, [fp, #0x60]
    // 0x7b23a0: cmp             w0, NULL
    // 0x7b23a4: b.ne            #0x7b23b0
    // 0x7b23a8: r0 = Instance_BorderRadius
    //     0x7b23a8: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x7b23ac: ldr             x0, [x0, #0x2c0]
    // 0x7b23b0: ldr             x3, [fp, #0x50]
    // 0x7b23b4: StoreField: r2->field_1f = r0
    //     0x7b23b4: stur            w0, [x2, #0x1f]
    //     0x7b23b8: ldurb           w16, [x2, #-1]
    //     0x7b23bc: ldurb           w17, [x0, #-1]
    //     0x7b23c0: and             x16, x17, x16, lsr #2
    //     0x7b23c4: tst             x16, HEAP, lsr #32
    //     0x7b23c8: b.eq            #0x7b23d0
    //     0x7b23cc: bl              #0xd6828c
    // 0x7b23d0: ldr             x0, [fp, #0x48]
    // 0x7b23d4: StoreField: r2->field_23 = r0
    //     0x7b23d4: stur            w0, [x2, #0x23]
    //     0x7b23d8: ldurb           w16, [x2, #-1]
    //     0x7b23dc: ldurb           w17, [x0, #-1]
    //     0x7b23e0: and             x16, x17, x16, lsr #2
    //     0x7b23e4: tst             x16, HEAP, lsr #32
    //     0x7b23e8: b.eq            #0x7b23f0
    //     0x7b23ec: bl              #0xd6828c
    // 0x7b23f0: ldr             x0, [fp, #0x10]
    // 0x7b23f4: StoreField: r2->field_2b = r0
    //     0x7b23f4: stur            w0, [x2, #0x2b]
    //     0x7b23f8: ldurb           w16, [x2, #-1]
    //     0x7b23fc: ldurb           w17, [x0, #-1]
    //     0x7b2400: and             x16, x17, x16, lsr #2
    //     0x7b2404: tst             x16, HEAP, lsr #32
    //     0x7b2408: b.eq            #0x7b2410
    //     0x7b240c: bl              #0xd6828c
    // 0x7b2410: ldr             x0, [fp, #0x28]
    // 0x7b2414: StoreField: r2->field_27 = r0
    //     0x7b2414: stur            w0, [x2, #0x27]
    //     0x7b2418: ldurb           w16, [x2, #-1]
    //     0x7b241c: ldurb           w17, [x0, #-1]
    //     0x7b2420: and             x16, x17, x16, lsr #2
    //     0x7b2424: tst             x16, HEAP, lsr #32
    //     0x7b2428: b.eq            #0x7b2430
    //     0x7b242c: bl              #0xd6828c
    // 0x7b2430: ldr             x0, [fp, #0x58]
    // 0x7b2434: StoreField: r2->field_13 = r0
    //     0x7b2434: stur            w0, [x2, #0x13]
    //     0x7b2438: ldurb           w16, [x2, #-1]
    //     0x7b243c: ldurb           w17, [x0, #-1]
    //     0x7b2440: and             x16, x17, x16, lsr #2
    //     0x7b2444: tst             x16, HEAP, lsr #32
    //     0x7b2448: b.eq            #0x7b2450
    //     0x7b244c: bl              #0xd6828c
    // 0x7b2450: ldr             x0, [fp, #0x20]
    // 0x7b2454: StoreField: r2->field_b = r0
    //     0x7b2454: stur            w0, [x2, #0xb]
    //     0x7b2458: ldurb           w16, [x2, #-1]
    //     0x7b245c: ldurb           w17, [x0, #-1]
    //     0x7b2460: and             x16, x17, x16, lsr #2
    //     0x7b2464: tst             x16, HEAP, lsr #32
    //     0x7b2468: b.eq            #0x7b2470
    //     0x7b246c: bl              #0xd6828c
    // 0x7b2470: ldr             x0, [fp, #0x38]
    // 0x7b2474: StoreField: r2->field_f = r0
    //     0x7b2474: stur            w0, [x2, #0xf]
    //     0x7b2478: ldurb           w16, [x2, #-1]
    //     0x7b247c: ldurb           w17, [x0, #-1]
    //     0x7b2480: and             x16, x17, x16, lsr #2
    //     0x7b2484: tst             x16, HEAP, lsr #32
    //     0x7b2488: b.eq            #0x7b2490
    //     0x7b248c: bl              #0xd6828c
    // 0x7b2490: mov             x0, x3
    // 0x7b2494: StoreField: r2->field_7 = r0
    //     0x7b2494: stur            w0, [x2, #7]
    //     0x7b2498: ldurb           w16, [x2, #-1]
    //     0x7b249c: ldurb           w17, [x0, #-1]
    //     0x7b24a0: and             x16, x17, x16, lsr #2
    //     0x7b24a4: tst             x16, HEAP, lsr #32
    //     0x7b24a8: b.eq            #0x7b24b0
    //     0x7b24ac: bl              #0xd6828c
    // 0x7b24b0: LoadField: r0 = r3->field_63
    //     0x7b24b0: ldur            w0, [x3, #0x63]
    // 0x7b24b4: DecompressPointer r0
    //     0x7b24b4: add             x0, x0, HEAP, lsl #32
    // 0x7b24b8: stur            x0, [fp, #-8]
    // 0x7b24bc: r1 = <double>
    //     0x7b24bc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b24c0: r0 = AnimationController()
    //     0x7b24c0: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x7b24c4: stur            x0, [fp, #-0x10]
    // 0x7b24c8: ldur            x16, [fp, #-8]
    // 0x7b24cc: stp             x16, x0, [SP, #-0x10]!
    // 0x7b24d0: ldr             x16, [fp, #0x40]
    // 0x7b24d4: SaveReg r16
    //     0x7b24d4: str             x16, [SP, #-8]!
    // 0x7b24d8: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x7b24d8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x7b24dc: ldr             x4, [x4, #0xa0]
    // 0x7b24e0: r0 = AnimationController()
    //     0x7b24e0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x7b24e4: add             SP, SP, #0x18
    // 0x7b24e8: r1 = 1
    //     0x7b24e8: mov             x1, #1
    // 0x7b24ec: r0 = AllocateContext()
    //     0x7b24ec: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b24f0: mov             x1, x0
    // 0x7b24f4: ldr             x0, [fp, #0x50]
    // 0x7b24f8: StoreField: r1->field_f = r0
    //     0x7b24f8: stur            w0, [x1, #0xf]
    // 0x7b24fc: mov             x2, x1
    // 0x7b2500: r1 = Function 'markNeedsPaint':.
    //     0x7b2500: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x7b2504: ldr             x1, [x1, #0xf60]
    // 0x7b2508: r0 = AllocateClosure()
    //     0x7b2508: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b250c: ldur            x16, [fp, #-0x10]
    // 0x7b2510: stp             x0, x16, [SP, #-0x10]!
    // 0x7b2514: r0 = addActionListener()
    //     0x7b2514: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x7b2518: add             SP, SP, #0x10
    // 0x7b251c: r1 = 1
    //     0x7b251c: mov             x1, #1
    // 0x7b2520: r0 = AllocateContext()
    //     0x7b2520: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b2524: mov             x1, x0
    // 0x7b2528: ldr             x0, [fp, #0x68]
    // 0x7b252c: StoreField: r1->field_f = r0
    //     0x7b252c: stur            w0, [x1, #0xf]
    // 0x7b2530: mov             x2, x1
    // 0x7b2534: r1 = Function '_handleAlphaStatusChanged@756209331':.
    //     0x7b2534: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e2b0] AnonymousClosure: (0x7b27a4), in [package:flutter/src/material/ink_highlight.dart] InkHighlight::_handleAlphaStatusChanged (0x7b27f0)
    //     0x7b2538: ldr             x1, [x1, #0x2b0]
    // 0x7b253c: r0 = AllocateClosure()
    //     0x7b253c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b2540: ldur            x16, [fp, #-0x10]
    // 0x7b2544: stp             x0, x16, [SP, #-0x10]!
    // 0x7b2548: r0 = addStatusListener()
    //     0x7b2548: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x7b254c: add             SP, SP, #0x10
    // 0x7b2550: ldur            x16, [fp, #-0x10]
    // 0x7b2554: SaveReg r16
    //     0x7b2554: str             x16, [SP, #-8]!
    // 0x7b2558: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b2558: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b255c: r0 = forward()
    //     0x7b255c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7b2560: add             SP, SP, #8
    // 0x7b2564: ldur            x0, [fp, #-0x10]
    // 0x7b2568: ldr             x2, [fp, #0x68]
    // 0x7b256c: StoreField: r2->field_33 = r0
    //     0x7b256c: stur            w0, [x2, #0x33]
    //     0x7b2570: ldurb           w16, [x2, #-1]
    //     0x7b2574: ldurb           w17, [x0, #-1]
    //     0x7b2578: and             x16, x17, x16, lsr #2
    //     0x7b257c: tst             x16, HEAP, lsr #32
    //     0x7b2580: b.eq            #0x7b2588
    //     0x7b2584: bl              #0xd6828c
    // 0x7b2588: LoadField: r0 = r2->field_13
    //     0x7b2588: ldur            w0, [x2, #0x13]
    // 0x7b258c: DecompressPointer r0
    //     0x7b258c: add             x0, x0, HEAP, lsl #32
    // 0x7b2590: r1 = LoadClassIdInstr(r0)
    //     0x7b2590: ldur            x1, [x0, #-1]
    //     0x7b2594: ubfx            x1, x1, #0xc, #0x14
    // 0x7b2598: lsl             x1, x1, #1
    // 0x7b259c: r17 = 10124
    //     0x7b259c: mov             x17, #0x278c
    // 0x7b25a0: cmp             w1, w17
    // 0x7b25a4: b.gt            #0x7b25b4
    // 0x7b25a8: r17 = 10122
    //     0x7b25a8: mov             x17, #0x278a
    // 0x7b25ac: cmp             w1, w17
    // 0x7b25b0: b.ge            #0x7b25cc
    // 0x7b25b4: r17 = 10114
    //     0x7b25b4: mov             x17, #0x2782
    // 0x7b25b8: cmp             w1, w17
    // 0x7b25bc: b.eq            #0x7b25cc
    // 0x7b25c0: r17 = 10118
    //     0x7b25c0: mov             x17, #0x2786
    // 0x7b25c4: cmp             w1, w17
    // 0x7b25c8: b.ne            #0x7b25d4
    // 0x7b25cc: LoadField: r1 = r0->field_7
    //     0x7b25cc: ldur            x1, [x0, #7]
    // 0x7b25d0: b               #0x7b25e4
    // 0x7b25d4: LoadField: r1 = r0->field_f
    //     0x7b25d4: ldur            w1, [x0, #0xf]
    // 0x7b25d8: DecompressPointer r1
    //     0x7b25d8: add             x1, x1, HEAP, lsl #32
    // 0x7b25dc: LoadField: r0 = r1->field_7
    //     0x7b25dc: ldur            x0, [x1, #7]
    // 0x7b25e0: mov             x1, x0
    // 0x7b25e4: r0 = 4278190080
    //     0x7b25e4: mov             x0, #0xff000000
    // 0x7b25e8: ubfx            x1, x1, #0, #0x20
    // 0x7b25ec: and             x3, x1, x0
    // 0x7b25f0: ubfx            x3, x3, #0, #0x20
    // 0x7b25f4: asr             x0, x3, #0x18
    // 0x7b25f8: stur            x0, [fp, #-0x18]
    // 0x7b25fc: r1 = <int>
    //     0x7b25fc: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x7b2600: r0 = IntTween()
    //     0x7b2600: bl              #0x7b2798  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0x7b2604: StoreField: r0->field_b = rZR
    //     0x7b2604: stur            wzr, [x0, #0xb]
    // 0x7b2608: ldur            x1, [fp, #-0x18]
    // 0x7b260c: lsl             x2, x1, #1
    // 0x7b2610: StoreField: r0->field_f = r2
    //     0x7b2610: stur            w2, [x0, #0xf]
    // 0x7b2614: ldur            x16, [fp, #-0x10]
    // 0x7b2618: stp             x16, x0, [SP, #-0x10]!
    // 0x7b261c: r0 = animate()
    //     0x7b261c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b2620: add             SP, SP, #0x10
    // 0x7b2624: ldr             x1, [fp, #0x68]
    // 0x7b2628: StoreField: r1->field_2f = r0
    //     0x7b2628: stur            w0, [x1, #0x2f]
    //     0x7b262c: ldurb           w16, [x1, #-1]
    //     0x7b2630: ldurb           w17, [x0, #-1]
    //     0x7b2634: and             x16, x17, x16, lsr #2
    //     0x7b2638: tst             x16, HEAP, lsr #32
    //     0x7b263c: b.eq            #0x7b2644
    //     0x7b2640: bl              #0xd6826c
    // 0x7b2644: ldr             x16, [fp, #0x50]
    // 0x7b2648: stp             x1, x16, [SP, #-0x10]!
    // 0x7b264c: r0 = addInkFeature()
    //     0x7b264c: bl              #0x7b266c  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0x7b2650: add             SP, SP, #0x10
    // 0x7b2654: r0 = Null
    //     0x7b2654: mov             x0, NULL
    // 0x7b2658: LeaveFrame
    //     0x7b2658: mov             SP, fp
    //     0x7b265c: ldp             fp, lr, [SP], #0x10
    // 0x7b2660: ret
    //     0x7b2660: ret             
    // 0x7b2664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2668: b               #0x7b234c
  }
  [closure] void _handleAlphaStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0x7b27a4, size: 0x4c
    // 0x7b27a4: EnterFrame
    //     0x7b27a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b27a8: mov             fp, SP
    // 0x7b27ac: ldr             x0, [fp, #0x18]
    // 0x7b27b0: LoadField: r1 = r0->field_17
    //     0x7b27b0: ldur            w1, [x0, #0x17]
    // 0x7b27b4: DecompressPointer r1
    //     0x7b27b4: add             x1, x1, HEAP, lsl #32
    // 0x7b27b8: CheckStackOverflow
    //     0x7b27b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b27bc: cmp             SP, x16
    //     0x7b27c0: b.ls            #0x7b27e8
    // 0x7b27c4: LoadField: r0 = r1->field_f
    //     0x7b27c4: ldur            w0, [x1, #0xf]
    // 0x7b27c8: DecompressPointer r0
    //     0x7b27c8: add             x0, x0, HEAP, lsl #32
    // 0x7b27cc: ldr             x16, [fp, #0x10]
    // 0x7b27d0: stp             x16, x0, [SP, #-0x10]!
    // 0x7b27d4: r0 = _handleAlphaStatusChanged()
    //     0x7b27d4: bl              #0x7b27f0  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::_handleAlphaStatusChanged
    // 0x7b27d8: add             SP, SP, #0x10
    // 0x7b27dc: LeaveFrame
    //     0x7b27dc: mov             SP, fp
    //     0x7b27e0: ldp             fp, lr, [SP], #0x10
    // 0x7b27e4: ret
    //     0x7b27e4: ret             
    // 0x7b27e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b27e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b27ec: b               #0x7b27c4
  }
  _ _handleAlphaStatusChanged(/* No info */) {
    // ** addr: 0x7b27f0, size: 0x5c
    // 0x7b27f0: EnterFrame
    //     0x7b27f0: stp             fp, lr, [SP, #-0x10]!
    //     0x7b27f4: mov             fp, SP
    // 0x7b27f8: CheckStackOverflow
    //     0x7b27f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b27fc: cmp             SP, x16
    //     0x7b2800: b.ls            #0x7b2844
    // 0x7b2804: ldr             x0, [fp, #0x10]
    // 0x7b2808: r16 = Instance_AnimationStatus
    //     0x7b2808: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x7b280c: ldr             x16, [x16, #0xba8]
    // 0x7b2810: cmp             w0, w16
    // 0x7b2814: b.ne            #0x7b2834
    // 0x7b2818: ldr             x0, [fp, #0x18]
    // 0x7b281c: LoadField: r1 = r0->field_37
    //     0x7b281c: ldur            w1, [x0, #0x37]
    // 0x7b2820: DecompressPointer r1
    //     0x7b2820: add             x1, x1, HEAP, lsl #32
    // 0x7b2824: tbz             w1, #4, #0x7b2834
    // 0x7b2828: SaveReg r0
    //     0x7b2828: str             x0, [SP, #-8]!
    // 0x7b282c: r0 = dispose()
    //     0x7b282c: bl              #0xbfea64  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::dispose
    // 0x7b2830: add             SP, SP, #8
    // 0x7b2834: r0 = Null
    //     0x7b2834: mov             x0, NULL
    // 0x7b2838: LeaveFrame
    //     0x7b2838: mov             SP, fp
    //     0x7b283c: ldp             fp, lr, [SP], #0x10
    // 0x7b2840: ret
    //     0x7b2840: ret             
    // 0x7b2844: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b2844: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b2848: b               #0x7b2804
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0xbe43a8, size: 0x1fc
    // 0xbe43a8: EnterFrame
    //     0xbe43a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe43ac: mov             fp, SP
    // 0xbe43b0: AllocStack(0x18)
    //     0xbe43b0: sub             SP, SP, #0x18
    // 0xbe43b4: CheckStackOverflow
    //     0xbe43b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe43b8: cmp             SP, x16
    //     0xbe43bc: b.ls            #0xbe458c
    // 0xbe43c0: r16 = 112
    //     0xbe43c0: mov             x16, #0x70
    // 0xbe43c4: stp             x16, NULL, [SP, #-0x10]!
    // 0xbe43c8: r0 = ByteData()
    //     0xbe43c8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbe43cc: add             SP, SP, #0x10
    // 0xbe43d0: stur            x0, [fp, #-8]
    // 0xbe43d4: r0 = Paint()
    //     0xbe43d4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbe43d8: mov             x1, x0
    // 0xbe43dc: ldur            x0, [fp, #-8]
    // 0xbe43e0: stur            x1, [fp, #-0x18]
    // 0xbe43e4: StoreField: r1->field_7 = r0
    //     0xbe43e4: stur            w0, [x1, #7]
    // 0xbe43e8: ldr             x2, [fp, #0x20]
    // 0xbe43ec: LoadField: r3 = r2->field_13
    //     0xbe43ec: ldur            w3, [x2, #0x13]
    // 0xbe43f0: DecompressPointer r3
    //     0xbe43f0: add             x3, x3, HEAP, lsl #32
    // 0xbe43f4: stur            x3, [fp, #-0x10]
    // 0xbe43f8: LoadField: r4 = r2->field_2f
    //     0xbe43f8: ldur            w4, [x2, #0x2f]
    // 0xbe43fc: DecompressPointer r4
    //     0xbe43fc: add             x4, x4, HEAP, lsl #32
    // 0xbe4400: r16 = Sentinel
    //     0xbe4400: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4404: cmp             w4, w16
    // 0xbe4408: b.eq            #0xbe4594
    // 0xbe440c: LoadField: r5 = r4->field_f
    //     0xbe440c: ldur            w5, [x4, #0xf]
    // 0xbe4410: DecompressPointer r5
    //     0xbe4410: add             x5, x5, HEAP, lsl #32
    // 0xbe4414: LoadField: r6 = r4->field_b
    //     0xbe4414: ldur            w6, [x4, #0xb]
    // 0xbe4418: DecompressPointer r6
    //     0xbe4418: add             x6, x6, HEAP, lsl #32
    // 0xbe441c: stp             x6, x5, [SP, #-0x10]!
    // 0xbe4420: r0 = evaluate()
    //     0xbe4420: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe4424: add             SP, SP, #0x10
    // 0xbe4428: r1 = LoadInt32Instr(r0)
    //     0xbe4428: sbfx            x1, x0, #1, #0x1f
    //     0xbe442c: tbz             w0, #0, #0xbe4434
    //     0xbe4430: ldur            x1, [x0, #7]
    // 0xbe4434: ldur            x16, [fp, #-0x10]
    // 0xbe4438: stp             x1, x16, [SP, #-0x10]!
    // 0xbe443c: r0 = withAlpha()
    //     0xbe443c: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0xbe4440: add             SP, SP, #0x10
    // 0xbe4444: LoadField: r1 = r0->field_7
    //     0xbe4444: ldur            x1, [x0, #7]
    // 0xbe4448: eor             x0, x1, #0xff000000
    // 0xbe444c: ldur            x1, [fp, #-8]
    // 0xbe4450: LoadField: r2 = r1->field_17
    //     0xbe4450: ldur            w2, [x1, #0x17]
    // 0xbe4454: DecompressPointer r2
    //     0xbe4454: add             x2, x2, HEAP, lsl #32
    // 0xbe4458: sxtw            x0, w0
    // 0xbe445c: LoadField: r1 = r2->field_7
    //     0xbe445c: ldur            x1, [x2, #7]
    // 0xbe4460: str             w0, [x1, #4]
    // 0xbe4464: ldr             x16, [fp, #0x10]
    // 0xbe4468: SaveReg r16
    //     0xbe4468: str             x16, [SP, #-8]!
    // 0xbe446c: r0 = getAsTranslation()
    //     0xbe446c: bl              #0x665a04  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xbe4470: add             SP, SP, #8
    // 0xbe4474: mov             x2, x0
    // 0xbe4478: ldr             x1, [fp, #0x20]
    // 0xbe447c: stur            x2, [fp, #-8]
    // 0xbe4480: LoadField: r0 = r1->field_27
    //     0xbe4480: ldur            w0, [x1, #0x27]
    // 0xbe4484: DecompressPointer r0
    //     0xbe4484: add             x0, x0, HEAP, lsl #32
    // 0xbe4488: cmp             w0, NULL
    // 0xbe448c: b.eq            #0xbe44ac
    // 0xbe4490: SaveReg r0
    //     0xbe4490: str             x0, [SP, #-8]!
    // 0xbe4494: ClosureCall
    //     0xbe4494: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe4498: ldur            x2, [x0, #0x1f]
    //     0xbe449c: blr             x2
    // 0xbe44a0: add             SP, SP, #8
    // 0xbe44a4: mov             x1, x0
    // 0xbe44a8: b               #0xbe44dc
    // 0xbe44ac: mov             x0, x1
    // 0xbe44b0: LoadField: r1 = r0->field_b
    //     0xbe44b0: ldur            w1, [x0, #0xb]
    // 0xbe44b4: DecompressPointer r1
    //     0xbe44b4: add             x1, x1, HEAP, lsl #32
    // 0xbe44b8: LoadField: r2 = r1->field_57
    //     0xbe44b8: ldur            w2, [x1, #0x57]
    // 0xbe44bc: DecompressPointer r2
    //     0xbe44bc: add             x2, x2, HEAP, lsl #32
    // 0xbe44c0: cmp             w2, NULL
    // 0xbe44c4: b.eq            #0xbe45a0
    // 0xbe44c8: r16 = Instance_Offset
    //     0xbe44c8: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xbe44cc: stp             x2, x16, [SP, #-0x10]!
    // 0xbe44d0: r0 = &()
    //     0xbe44d0: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xbe44d4: add             SP, SP, #0x10
    // 0xbe44d8: mov             x1, x0
    // 0xbe44dc: ldur            x0, [fp, #-8]
    // 0xbe44e0: stur            x1, [fp, #-0x10]
    // 0xbe44e4: cmp             w0, NULL
    // 0xbe44e8: b.ne            #0xbe4550
    // 0xbe44ec: ldr             x0, [fp, #0x10]
    // 0xbe44f0: ldr             x16, [fp, #0x18]
    // 0xbe44f4: SaveReg r16
    //     0xbe44f4: str             x16, [SP, #-8]!
    // 0xbe44f8: r0 = save()
    //     0xbe44f8: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xbe44fc: add             SP, SP, #8
    // 0xbe4500: ldr             x0, [fp, #0x10]
    // 0xbe4504: LoadField: r1 = r0->field_7
    //     0xbe4504: ldur            w1, [x0, #7]
    // 0xbe4508: DecompressPointer r1
    //     0xbe4508: add             x1, x1, HEAP, lsl #32
    // 0xbe450c: ldr             x16, [fp, #0x18]
    // 0xbe4510: stp             x1, x16, [SP, #-0x10]!
    // 0xbe4514: r0 = transform()
    //     0xbe4514: bl              #0x656f48  ; [dart:ui] Canvas::transform
    // 0xbe4518: add             SP, SP, #0x10
    // 0xbe451c: ldr             x16, [fp, #0x20]
    // 0xbe4520: ldr             lr, [fp, #0x18]
    // 0xbe4524: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4528: ldur            x16, [fp, #-0x10]
    // 0xbe452c: ldur            lr, [fp, #-0x18]
    // 0xbe4530: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4534: r0 = _paintHighlight()
    //     0xbe4534: bl              #0xbe45a4  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::_paintHighlight
    // 0xbe4538: add             SP, SP, #0x20
    // 0xbe453c: ldr             x16, [fp, #0x18]
    // 0xbe4540: SaveReg r16
    //     0xbe4540: str             x16, [SP, #-8]!
    // 0xbe4544: r0 = restore()
    //     0xbe4544: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xbe4548: add             SP, SP, #8
    // 0xbe454c: b               #0xbe457c
    // 0xbe4550: ldur            x16, [fp, #-0x10]
    // 0xbe4554: stp             x0, x16, [SP, #-0x10]!
    // 0xbe4558: r0 = shift()
    //     0xbe4558: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0xbe455c: add             SP, SP, #0x10
    // 0xbe4560: ldr             x16, [fp, #0x20]
    // 0xbe4564: ldr             lr, [fp, #0x18]
    // 0xbe4568: stp             lr, x16, [SP, #-0x10]!
    // 0xbe456c: ldur            x16, [fp, #-0x18]
    // 0xbe4570: stp             x16, x0, [SP, #-0x10]!
    // 0xbe4574: r0 = _paintHighlight()
    //     0xbe4574: bl              #0xbe45a4  ; [package:flutter/src/material/ink_highlight.dart] InkHighlight::_paintHighlight
    // 0xbe4578: add             SP, SP, #0x20
    // 0xbe457c: r0 = Null
    //     0xbe457c: mov             x0, NULL
    // 0xbe4580: LeaveFrame
    //     0xbe4580: mov             SP, fp
    //     0xbe4584: ldp             fp, lr, [SP], #0x10
    // 0xbe4588: ret
    //     0xbe4588: ret             
    // 0xbe458c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe458c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4590: b               #0xbe43c0
    // 0xbe4594: r9 = _alpha
    //     0xbe4594: add             x9, PP, #0x37, lsl #12  ; [pp+0x378e0] Field <InkHighlight._alpha@756209331>: late (offset: 0x30)
    //     0xbe4598: ldr             x9, [x9, #0x8e0]
    // 0xbe459c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe459c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe45a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe45a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _paintHighlight(/* No info */) {
    // ** addr: 0xbe45a4, size: 0x1ec
    // 0xbe45a4: EnterFrame
    //     0xbe45a4: stp             fp, lr, [SP, #-0x10]!
    //     0xbe45a8: mov             fp, SP
    // 0xbe45ac: AllocStack(0x28)
    //     0xbe45ac: sub             SP, SP, #0x28
    // 0xbe45b0: CheckStackOverflow
    //     0xbe45b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe45b4: cmp             SP, x16
    //     0xbe45b8: b.ls            #0xbe4788
    // 0xbe45bc: ldr             x16, [fp, #0x20]
    // 0xbe45c0: SaveReg r16
    //     0xbe45c0: str             x16, [SP, #-8]!
    // 0xbe45c4: r0 = save()
    //     0xbe45c4: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xbe45c8: add             SP, SP, #8
    // 0xbe45cc: ldr             x1, [fp, #0x28]
    // 0xbe45d0: LoadField: r0 = r1->field_23
    //     0xbe45d0: ldur            w0, [x1, #0x23]
    // 0xbe45d4: DecompressPointer r0
    //     0xbe45d4: add             x0, x0, HEAP, lsl #32
    // 0xbe45d8: cmp             w0, NULL
    // 0xbe45dc: b.eq            #0xbe462c
    // 0xbe45e0: LoadField: r2 = r1->field_2b
    //     0xbe45e0: ldur            w2, [x1, #0x2b]
    // 0xbe45e4: DecompressPointer r2
    //     0xbe45e4: add             x2, x2, HEAP, lsl #32
    // 0xbe45e8: r3 = LoadClassIdInstr(r0)
    //     0xbe45e8: ldur            x3, [x0, #-1]
    //     0xbe45ec: ubfx            x3, x3, #0xc, #0x14
    // 0xbe45f0: ldr             x16, [fp, #0x18]
    // 0xbe45f4: stp             x16, x0, [SP, #-0x10]!
    // 0xbe45f8: SaveReg r2
    //     0xbe45f8: str             x2, [SP, #-8]!
    // 0xbe45fc: mov             x0, x3
    // 0xbe4600: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xbe4600: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xbe4604: ldr             x4, [x4, #0x5b8]
    // 0xbe4608: r0 = GDT[cid_x0 + -0xfde]()
    //     0xbe4608: sub             lr, x0, #0xfde
    //     0xbe460c: ldr             lr, [x21, lr, lsl #3]
    //     0xbe4610: blr             lr
    // 0xbe4614: add             SP, SP, #0x18
    // 0xbe4618: ldr             x16, [fp, #0x20]
    // 0xbe461c: stp             x0, x16, [SP, #-0x10]!
    // 0xbe4620: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe4620: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe4624: r0 = clipPath()
    //     0xbe4624: bl              #0x6629f4  ; [dart:ui] Canvas::clipPath
    // 0xbe4628: add             SP, SP, #0x10
    // 0xbe462c: ldr             x0, [fp, #0x28]
    // 0xbe4630: LoadField: r1 = r0->field_17
    //     0xbe4630: ldur            w1, [x0, #0x17]
    // 0xbe4634: DecompressPointer r1
    //     0xbe4634: add             x1, x1, HEAP, lsl #32
    // 0xbe4638: LoadField: r2 = r1->field_7
    //     0xbe4638: ldur            x2, [x1, #7]
    // 0xbe463c: cmp             x2, #0
    // 0xbe4640: b.gt            #0xbe4714
    // 0xbe4644: LoadField: r1 = r0->field_1f
    //     0xbe4644: ldur            w1, [x0, #0x1f]
    // 0xbe4648: DecompressPointer r1
    //     0xbe4648: add             x1, x1, HEAP, lsl #32
    // 0xbe464c: stur            x1, [fp, #-8]
    // 0xbe4650: r16 = Instance_BorderRadius
    //     0xbe4650: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xbe4654: ldr             x16, [x16, #0x2c0]
    // 0xbe4658: stp             x16, x1, [SP, #-0x10]!
    // 0xbe465c: r0 = ==()
    //     0xbe465c: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xbe4660: add             SP, SP, #0x10
    // 0xbe4664: tbz             w0, #4, #0xbe46f4
    // 0xbe4668: ldur            x0, [fp, #-8]
    // 0xbe466c: LoadField: r1 = r0->field_7
    //     0xbe466c: ldur            w1, [x0, #7]
    // 0xbe4670: DecompressPointer r1
    //     0xbe4670: add             x1, x1, HEAP, lsl #32
    // 0xbe4674: stur            x1, [fp, #-0x28]
    // 0xbe4678: LoadField: r2 = r0->field_b
    //     0xbe4678: ldur            w2, [x0, #0xb]
    // 0xbe467c: DecompressPointer r2
    //     0xbe467c: add             x2, x2, HEAP, lsl #32
    // 0xbe4680: stur            x2, [fp, #-0x20]
    // 0xbe4684: LoadField: r3 = r0->field_f
    //     0xbe4684: ldur            w3, [x0, #0xf]
    // 0xbe4688: DecompressPointer r3
    //     0xbe4688: add             x3, x3, HEAP, lsl #32
    // 0xbe468c: stur            x3, [fp, #-0x18]
    // 0xbe4690: LoadField: r4 = r0->field_13
    //     0xbe4690: ldur            w4, [x0, #0x13]
    // 0xbe4694: DecompressPointer r4
    //     0xbe4694: add             x4, x4, HEAP, lsl #32
    // 0xbe4698: stur            x4, [fp, #-0x10]
    // 0xbe469c: r0 = RRect()
    //     0xbe469c: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xbe46a0: stur            x0, [fp, #-8]
    // 0xbe46a4: ldr             x16, [fp, #0x18]
    // 0xbe46a8: stp             x16, x0, [SP, #-0x10]!
    // 0xbe46ac: ldur            x16, [fp, #-0x28]
    // 0xbe46b0: ldur            lr, [fp, #-0x20]
    // 0xbe46b4: stp             lr, x16, [SP, #-0x10]!
    // 0xbe46b8: ldur            x16, [fp, #-0x18]
    // 0xbe46bc: ldur            lr, [fp, #-0x10]
    // 0xbe46c0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe46c4: r4 = const [0, 0x6, 0x6, 0x2, bottomLeft, 0x4, bottomRight, 0x5, topLeft, 0x2, topRight, 0x3, null]
    //     0xbe46c4: add             x4, PP, #0x21, lsl #12  ; [pp+0x21d00] List(13) [0, 0x6, 0x6, 0x2, "bottomLeft", 0x4, "bottomRight", 0x5, "topLeft", 0x2, "topRight", 0x3, Null]
    //     0xbe46c8: ldr             x4, [x4, #0xd00]
    // 0xbe46cc: r0 = RRect.fromRectAndCorners()
    //     0xbe46cc: bl              #0x6706f4  ; [dart:ui] RRect::RRect.fromRectAndCorners
    // 0xbe46d0: add             SP, SP, #0x30
    // 0xbe46d4: ldr             x16, [fp, #0x20]
    // 0xbe46d8: ldur            lr, [fp, #-8]
    // 0xbe46dc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe46e0: ldr             x16, [fp, #0x10]
    // 0xbe46e4: SaveReg r16
    //     0xbe46e4: str             x16, [SP, #-8]!
    // 0xbe46e8: r0 = drawRRect()
    //     0xbe46e8: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0xbe46ec: add             SP, SP, #0x18
    // 0xbe46f0: b               #0xbe4768
    // 0xbe46f4: ldr             x16, [fp, #0x20]
    // 0xbe46f8: ldr             lr, [fp, #0x18]
    // 0xbe46fc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4700: ldr             x16, [fp, #0x10]
    // 0xbe4704: SaveReg r16
    //     0xbe4704: str             x16, [SP, #-8]!
    // 0xbe4708: r0 = drawRect()
    //     0xbe4708: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xbe470c: add             SP, SP, #0x18
    // 0xbe4710: b               #0xbe4768
    // 0xbe4714: ldr             x16, [fp, #0x18]
    // 0xbe4718: SaveReg r16
    //     0xbe4718: str             x16, [SP, #-8]!
    // 0xbe471c: r0 = center()
    //     0xbe471c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xbe4720: add             SP, SP, #8
    // 0xbe4724: mov             x1, x0
    // 0xbe4728: ldr             x0, [fp, #0x28]
    // 0xbe472c: LoadField: r2 = r0->field_1b
    //     0xbe472c: ldur            w2, [x0, #0x1b]
    // 0xbe4730: DecompressPointer r2
    //     0xbe4730: add             x2, x2, HEAP, lsl #32
    // 0xbe4734: cmp             w2, NULL
    // 0xbe4738: b.ne            #0xbe4748
    // 0xbe473c: d0 = 35.000000
    //     0xbe473c: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c3a8] IMM: double(35) from 0x4041800000000000
    //     0xbe4740: ldr             d0, [x17, #0x3a8]
    // 0xbe4744: b               #0xbe474c
    // 0xbe4748: LoadField: d0 = r2->field_7
    //     0xbe4748: ldur            d0, [x2, #7]
    // 0xbe474c: ldr             x16, [fp, #0x20]
    // 0xbe4750: stp             x1, x16, [SP, #-0x10]!
    // 0xbe4754: SaveReg d0
    //     0xbe4754: str             d0, [SP, #-8]!
    // 0xbe4758: ldr             x16, [fp, #0x10]
    // 0xbe475c: SaveReg r16
    //     0xbe475c: str             x16, [SP, #-8]!
    // 0xbe4760: r0 = drawCircle()
    //     0xbe4760: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xbe4764: add             SP, SP, #0x20
    // 0xbe4768: ldr             x16, [fp, #0x20]
    // 0xbe476c: SaveReg r16
    //     0xbe476c: str             x16, [SP, #-8]!
    // 0xbe4770: r0 = restore()
    //     0xbe4770: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xbe4774: add             SP, SP, #8
    // 0xbe4778: r0 = Null
    //     0xbe4778: mov             x0, NULL
    // 0xbe477c: LeaveFrame
    //     0xbe477c: mov             SP, fp
    //     0xbe4780: ldp             fp, lr, [SP], #0x10
    // 0xbe4784: ret
    //     0xbe4784: ret             
    // 0xbe4788: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4788: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe478c: b               #0xbe45bc
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbfea64, size: 0x6c
    // 0xbfea64: EnterFrame
    //     0xbfea64: stp             fp, lr, [SP, #-0x10]!
    //     0xbfea68: mov             fp, SP
    // 0xbfea6c: CheckStackOverflow
    //     0xbfea6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfea70: cmp             SP, x16
    //     0xbfea74: b.ls            #0xbfeabc
    // 0xbfea78: ldr             x0, [fp, #0x10]
    // 0xbfea7c: LoadField: r1 = r0->field_33
    //     0xbfea7c: ldur            w1, [x0, #0x33]
    // 0xbfea80: DecompressPointer r1
    //     0xbfea80: add             x1, x1, HEAP, lsl #32
    // 0xbfea84: r16 = Sentinel
    //     0xbfea84: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfea88: cmp             w1, w16
    // 0xbfea8c: b.eq            #0xbfeac4
    // 0xbfea90: SaveReg r1
    //     0xbfea90: str             x1, [SP, #-8]!
    // 0xbfea94: r0 = dispose()
    //     0xbfea94: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfea98: add             SP, SP, #8
    // 0xbfea9c: ldr             x16, [fp, #0x10]
    // 0xbfeaa0: SaveReg r16
    //     0xbfeaa0: str             x16, [SP, #-8]!
    // 0xbfeaa4: r0 = dispose()
    //     0xbfeaa4: bl              #0x795b14  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0xbfeaa8: add             SP, SP, #8
    // 0xbfeaac: r0 = Null
    //     0xbfeaac: mov             x0, NULL
    // 0xbfeab0: LeaveFrame
    //     0xbfeab0: mov             SP, fp
    //     0xbfeab4: ldp             fp, lr, [SP], #0x10
    // 0xbfeab8: ret
    //     0xbfeab8: ret             
    // 0xbfeabc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfeabc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfeac0: b               #0xbfea78
    // 0xbfeac4: r9 = _alphaController
    //     0xbfeac4: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2a8] Field <InkHighlight._alphaController@756209331>: late (offset: 0x34)
    //     0xbfeac8: ldr             x9, [x9, #0x2a8]
    // 0xbfeacc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfeacc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/material/desktop_text_selection_toolbar.dart

// class id: 1049221, size: 0x8
class :: {
}

// class id: 3861, size: 0x14, field offset: 0xc
//   const constructor, 
class DesktopTextSelectionToolbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1e268, size: 0x140
    // 0xb1e268: EnterFrame
    //     0xb1e268: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e26c: mov             fp, SP
    // 0xb1e270: AllocStack(0x28)
    //     0xb1e270: sub             SP, SP, #0x28
    // 0xb1e274: CheckStackOverflow
    //     0xb1e274: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1e278: cmp             SP, x16
    //     0xb1e27c: b.ls            #0xb1e3a0
    // 0xb1e280: ldr             x16, [fp, #0x10]
    // 0xb1e284: SaveReg r16
    //     0xb1e284: str             x16, [SP, #-8]!
    // 0xb1e288: r0 = of()
    //     0xb1e288: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb1e28c: add             SP, SP, #8
    // 0xb1e290: LoadField: r1 = r0->field_23
    //     0xb1e290: ldur            w1, [x0, #0x23]
    // 0xb1e294: DecompressPointer r1
    //     0xb1e294: add             x1, x1, HEAP, lsl #32
    // 0xb1e298: LoadField: d0 = r1->field_f
    //     0xb1e298: ldur            d0, [x1, #0xf]
    // 0xb1e29c: d1 = 8.000000
    //     0xb1e29c: fmov            d1, #8.00000000
    // 0xb1e2a0: fadd            d2, d0, d1
    // 0xb1e2a4: stur            d2, [fp, #-0x28]
    // 0xb1e2a8: r0 = Offset()
    //     0xb1e2a8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb1e2ac: d0 = 8.000000
    //     0xb1e2ac: fmov            d0, #8.00000000
    // 0xb1e2b0: stur            x0, [fp, #-8]
    // 0xb1e2b4: StoreField: r0->field_7 = d0
    //     0xb1e2b4: stur            d0, [x0, #7]
    // 0xb1e2b8: ldur            d1, [fp, #-0x28]
    // 0xb1e2bc: StoreField: r0->field_f = d1
    //     0xb1e2bc: stur            d1, [x0, #0xf]
    // 0xb1e2c0: r0 = EdgeInsets()
    //     0xb1e2c0: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1e2c4: d0 = 8.000000
    //     0xb1e2c4: fmov            d0, #8.00000000
    // 0xb1e2c8: stur            x0, [fp, #-0x10]
    // 0xb1e2cc: StoreField: r0->field_7 = d0
    //     0xb1e2cc: stur            d0, [x0, #7]
    // 0xb1e2d0: ldur            d1, [fp, #-0x28]
    // 0xb1e2d4: StoreField: r0->field_f = d1
    //     0xb1e2d4: stur            d1, [x0, #0xf]
    // 0xb1e2d8: StoreField: r0->field_17 = d0
    //     0xb1e2d8: stur            d0, [x0, #0x17]
    // 0xb1e2dc: StoreField: r0->field_1f = d0
    //     0xb1e2dc: stur            d0, [x0, #0x1f]
    // 0xb1e2e0: ldr             x1, [fp, #0x18]
    // 0xb1e2e4: LoadField: r2 = r1->field_b
    //     0xb1e2e4: ldur            w2, [x1, #0xb]
    // 0xb1e2e8: DecompressPointer r2
    //     0xb1e2e8: add             x2, x2, HEAP, lsl #32
    // 0xb1e2ec: ldur            x16, [fp, #-8]
    // 0xb1e2f0: stp             x16, x2, [SP, #-0x10]!
    // 0xb1e2f4: r0 = -()
    //     0xb1e2f4: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xb1e2f8: add             SP, SP, #0x10
    // 0xb1e2fc: stur            x0, [fp, #-8]
    // 0xb1e300: r0 = DesktopTextSelectionToolbarLayoutDelegate()
    //     0xb1e300: bl              #0xb1cd20  ; AllocateDesktopTextSelectionToolbarLayoutDelegateStub -> DesktopTextSelectionToolbarLayoutDelegate (size=0x10)
    // 0xb1e304: mov             x1, x0
    // 0xb1e308: ldur            x0, [fp, #-8]
    // 0xb1e30c: stur            x1, [fp, #-0x18]
    // 0xb1e310: StoreField: r1->field_b = r0
    //     0xb1e310: stur            w0, [x1, #0xb]
    // 0xb1e314: ldr             x0, [fp, #0x18]
    // 0xb1e318: LoadField: r2 = r0->field_f
    //     0xb1e318: ldur            w2, [x0, #0xf]
    // 0xb1e31c: DecompressPointer r2
    //     0xb1e31c: add             x2, x2, HEAP, lsl #32
    // 0xb1e320: stur            x2, [fp, #-8]
    // 0xb1e324: r0 = Column()
    //     0xb1e324: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0xb1e328: stur            x0, [fp, #-0x20]
    // 0xb1e32c: ldur            x16, [fp, #-8]
    // 0xb1e330: stp             x16, x0, [SP, #-0x10]!
    // 0xb1e334: r16 = Instance_MainAxisSize
    //     0xb1e334: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0xb1e338: ldr             x16, [x16, #0xeb0]
    // 0xb1e33c: SaveReg r16
    //     0xb1e33c: str             x16, [SP, #-8]!
    // 0xb1e340: r4 = const [0, 0x3, 0x3, 0x2, mainAxisSize, 0x2, null]
    //     0xb1e340: add             x4, PP, #0xe, lsl #12  ; [pp+0xeeb8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisSize", 0x2, Null]
    //     0xb1e344: ldr             x4, [x4, #0xeb8]
    // 0xb1e348: r0 = Column()
    //     0xb1e348: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0xb1e34c: add             SP, SP, #0x18
    // 0xb1e350: ldur            x16, [fp, #-0x20]
    // 0xb1e354: SaveReg r16
    //     0xb1e354: str             x16, [SP, #-8]!
    // 0xb1e358: r0 = _defaultToolbarBuilder()
    //     0xb1e358: bl              #0xb1e3a8  ; [package:flutter/src/material/desktop_text_selection_toolbar.dart] DesktopTextSelectionToolbar::_defaultToolbarBuilder
    // 0xb1e35c: add             SP, SP, #8
    // 0xb1e360: stur            x0, [fp, #-8]
    // 0xb1e364: r0 = CustomSingleChildLayout()
    //     0xb1e364: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xb1e368: mov             x1, x0
    // 0xb1e36c: ldur            x0, [fp, #-0x18]
    // 0xb1e370: stur            x1, [fp, #-0x20]
    // 0xb1e374: StoreField: r1->field_f = r0
    //     0xb1e374: stur            w0, [x1, #0xf]
    // 0xb1e378: ldur            x0, [fp, #-8]
    // 0xb1e37c: StoreField: r1->field_b = r0
    //     0xb1e37c: stur            w0, [x1, #0xb]
    // 0xb1e380: r0 = Padding()
    //     0xb1e380: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1e384: ldur            x1, [fp, #-0x10]
    // 0xb1e388: StoreField: r0->field_f = r1
    //     0xb1e388: stur            w1, [x0, #0xf]
    // 0xb1e38c: ldur            x1, [fp, #-0x20]
    // 0xb1e390: StoreField: r0->field_b = r1
    //     0xb1e390: stur            w1, [x0, #0xb]
    // 0xb1e394: LeaveFrame
    //     0xb1e394: mov             SP, fp
    //     0xb1e398: ldp             fp, lr, [SP], #0x10
    // 0xb1e39c: ret
    //     0xb1e39c: ret             
    // 0xb1e3a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e3a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e3a4: b               #0xb1e280
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0xb1e3a8, size: 0x84
    // 0xb1e3a8: EnterFrame
    //     0xb1e3a8: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e3ac: mov             fp, SP
    // 0xb1e3b0: AllocStack(0x8)
    //     0xb1e3b0: sub             SP, SP, #8
    // 0xb1e3b4: r0 = Material()
    //     0xb1e3b4: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0xb1e3b8: mov             x1, x0
    // 0xb1e3bc: r0 = Instance_MaterialType
    //     0xb1e3bc: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2dc10] Obj!MaterialType@b65591
    //     0xb1e3c0: ldr             x0, [x0, #0xc10]
    // 0xb1e3c4: stur            x1, [fp, #-8]
    // 0xb1e3c8: StoreField: r1->field_f = r0
    //     0xb1e3c8: stur            w0, [x1, #0xf]
    // 0xb1e3cc: d0 = 1.000000
    //     0xb1e3cc: fmov            d0, #1.00000000
    // 0xb1e3d0: StoreField: r1->field_13 = d0
    //     0xb1e3d0: stur            d0, [x1, #0x13]
    // 0xb1e3d4: r0 = Instance_BorderRadius
    //     0xb1e3d4: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2dc18] Obj!BorderRadius@b37871
    //     0xb1e3d8: ldr             x0, [x0, #0xc18]
    // 0xb1e3dc: StoreField: r1->field_3b = r0
    //     0xb1e3dc: stur            w0, [x1, #0x3b]
    // 0xb1e3e0: r0 = true
    //     0xb1e3e0: add             x0, NULL, #0x20  ; true
    // 0xb1e3e4: StoreField: r1->field_2f = r0
    //     0xb1e3e4: stur            w0, [x1, #0x2f]
    // 0xb1e3e8: r0 = Instance_Clip
    //     0xb1e3e8: add             x0, PP, #0x21, lsl #12  ; [pp+0x21ad0] Obj!Clip@b676b1
    //     0xb1e3ec: ldr             x0, [x0, #0xad0]
    // 0xb1e3f0: StoreField: r1->field_33 = r0
    //     0xb1e3f0: stur            w0, [x1, #0x33]
    // 0xb1e3f4: r0 = Instance_Duration
    //     0xb1e3f4: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb1e3f8: ldr             x0, [x0, #0x9e0]
    // 0xb1e3fc: StoreField: r1->field_37 = r0
    //     0xb1e3fc: stur            w0, [x1, #0x37]
    // 0xb1e400: ldr             x0, [fp, #0x10]
    // 0xb1e404: StoreField: r1->field_b = r0
    //     0xb1e404: stur            w0, [x1, #0xb]
    // 0xb1e408: r0 = SizedBox()
    //     0xb1e408: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb1e40c: r1 = 222.000000
    //     0xb1e40c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e5a8] 222
    //     0xb1e410: ldr             x1, [x1, #0x5a8]
    // 0xb1e414: StoreField: r0->field_f = r1
    //     0xb1e414: stur            w1, [x0, #0xf]
    // 0xb1e418: ldur            x1, [fp, #-8]
    // 0xb1e41c: StoreField: r0->field_b = r1
    //     0xb1e41c: stur            w1, [x0, #0xb]
    // 0xb1e420: LeaveFrame
    //     0xb1e420: mov             SP, fp
    //     0xb1e424: ldp             fp, lr, [SP], #0x10
    // 0xb1e428: ret
    //     0xb1e428: ret             
  }
}

// lib: , url: package:flutter/src/material/input_border.dart

// class id: 1049260, size: 0x8
class :: {
}

// class id: 2181, size: 0xc, field offset: 0x8
//   const constructor, 
abstract class InputBorder extends ShapeBorder {
}

// class id: 2183, size: 0x10, field offset: 0xc
//   const constructor, 
class UnderlineInputBorder extends InputBorder {

  BorderSide field_8;
  BorderRadius field_c;

  _ lerpTo(/* No info */) {
    // ** addr: 0x70e0d4, size: 0xf8
    // 0x70e0d4: EnterFrame
    //     0x70e0d4: stp             fp, lr, [SP, #-0x10]!
    //     0x70e0d8: mov             fp, SP
    // 0x70e0dc: AllocStack(0x10)
    //     0x70e0dc: sub             SP, SP, #0x10
    // 0x70e0e0: CheckStackOverflow
    //     0x70e0e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70e0e4: cmp             SP, x16
    //     0x70e0e8: b.ls            #0x70e1c0
    // 0x70e0ec: ldr             x0, [fp, #0x18]
    // 0x70e0f0: r1 = LoadClassIdInstr(r0)
    //     0x70e0f0: ldur            x1, [x0, #-1]
    //     0x70e0f4: ubfx            x1, x1, #0xc, #0x14
    // 0x70e0f8: lsl             x1, x1, #1
    // 0x70e0fc: r17 = 4366
    //     0x70e0fc: mov             x17, #0x110e
    // 0x70e100: cmp             w1, w17
    // 0x70e104: b.ne            #0x70e198
    // 0x70e108: ldr             x1, [fp, #0x20]
    // 0x70e10c: ldr             d0, [fp, #0x10]
    // 0x70e110: LoadField: r2 = r1->field_7
    //     0x70e110: ldur            w2, [x1, #7]
    // 0x70e114: DecompressPointer r2
    //     0x70e114: add             x2, x2, HEAP, lsl #32
    // 0x70e118: LoadField: r3 = r0->field_7
    //     0x70e118: ldur            w3, [x0, #7]
    // 0x70e11c: DecompressPointer r3
    //     0x70e11c: add             x3, x3, HEAP, lsl #32
    // 0x70e120: stp             x3, x2, [SP, #-0x10]!
    // 0x70e124: SaveReg d0
    //     0x70e124: str             d0, [SP, #-8]!
    // 0x70e128: r0 = lerp()
    //     0x70e128: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70e12c: add             SP, SP, #0x18
    // 0x70e130: mov             x1, x0
    // 0x70e134: ldr             x0, [fp, #0x20]
    // 0x70e138: stur            x1, [fp, #-8]
    // 0x70e13c: LoadField: r2 = r0->field_b
    //     0x70e13c: ldur            w2, [x0, #0xb]
    // 0x70e140: DecompressPointer r2
    //     0x70e140: add             x2, x2, HEAP, lsl #32
    // 0x70e144: ldr             x3, [fp, #0x18]
    // 0x70e148: LoadField: r0 = r3->field_b
    //     0x70e148: ldur            w0, [x3, #0xb]
    // 0x70e14c: DecompressPointer r0
    //     0x70e14c: add             x0, x0, HEAP, lsl #32
    // 0x70e150: stp             x0, x2, [SP, #-0x10]!
    // 0x70e154: ldr             d0, [fp, #0x10]
    // 0x70e158: SaveReg d0
    //     0x70e158: str             d0, [SP, #-8]!
    // 0x70e15c: r0 = lerp()
    //     0x70e15c: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x70e160: add             SP, SP, #0x18
    // 0x70e164: stur            x0, [fp, #-0x10]
    // 0x70e168: cmp             w0, NULL
    // 0x70e16c: b.eq            #0x70e1c8
    // 0x70e170: r0 = UnderlineInputBorder()
    //     0x70e170: bl              #0x70e1f0  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0x70e174: mov             x1, x0
    // 0x70e178: ldur            x0, [fp, #-0x10]
    // 0x70e17c: StoreField: r1->field_b = r0
    //     0x70e17c: stur            w0, [x1, #0xb]
    // 0x70e180: ldur            x0, [fp, #-8]
    // 0x70e184: StoreField: r1->field_7 = r0
    //     0x70e184: stur            w0, [x1, #7]
    // 0x70e188: mov             x0, x1
    // 0x70e18c: LeaveFrame
    //     0x70e18c: mov             SP, fp
    //     0x70e190: ldp             fp, lr, [SP], #0x10
    // 0x70e194: ret
    //     0x70e194: ret             
    // 0x70e198: mov             x3, x0
    // 0x70e19c: ldr             x0, [fp, #0x20]
    // 0x70e1a0: ldr             d0, [fp, #0x10]
    // 0x70e1a4: stp             x3, x0, [SP, #-0x10]!
    // 0x70e1a8: SaveReg d0
    //     0x70e1a8: str             d0, [SP, #-8]!
    // 0x70e1ac: r0 = lerpTo()
    //     0x70e1ac: bl              #0x70f880  ; [package:flutter/src/painting/borders.dart] ShapeBorder::lerpTo
    // 0x70e1b0: add             SP, SP, #0x18
    // 0x70e1b4: LeaveFrame
    //     0x70e1b4: mov             SP, fp
    //     0x70e1b8: ldp             fp, lr, [SP], #0x10
    // 0x70e1bc: ret
    //     0x70e1bc: ret             
    // 0x70e1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70e1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70e1c4: b               #0x70e0ec
    // 0x70e1c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70e1c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0x70fb20, size: 0x104
    // 0x70fb20: EnterFrame
    //     0x70fb20: stp             fp, lr, [SP, #-0x10]!
    //     0x70fb24: mov             fp, SP
    // 0x70fb28: AllocStack(0x10)
    //     0x70fb28: sub             SP, SP, #0x10
    // 0x70fb2c: CheckStackOverflow
    //     0x70fb2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x70fb30: cmp             SP, x16
    //     0x70fb34: b.ls            #0x70fc18
    // 0x70fb38: ldr             x0, [fp, #0x18]
    // 0x70fb3c: r1 = LoadClassIdInstr(r0)
    //     0x70fb3c: ldur            x1, [x0, #-1]
    //     0x70fb40: ubfx            x1, x1, #0xc, #0x14
    // 0x70fb44: lsl             x1, x1, #1
    // 0x70fb48: r17 = 4366
    //     0x70fb48: mov             x17, #0x110e
    // 0x70fb4c: cmp             w1, w17
    // 0x70fb50: b.ne            #0x70fbe4
    // 0x70fb54: ldr             x1, [fp, #0x20]
    // 0x70fb58: ldr             d0, [fp, #0x10]
    // 0x70fb5c: LoadField: r2 = r0->field_7
    //     0x70fb5c: ldur            w2, [x0, #7]
    // 0x70fb60: DecompressPointer r2
    //     0x70fb60: add             x2, x2, HEAP, lsl #32
    // 0x70fb64: LoadField: r3 = r1->field_7
    //     0x70fb64: ldur            w3, [x1, #7]
    // 0x70fb68: DecompressPointer r3
    //     0x70fb68: add             x3, x3, HEAP, lsl #32
    // 0x70fb6c: stp             x3, x2, [SP, #-0x10]!
    // 0x70fb70: SaveReg d0
    //     0x70fb70: str             d0, [SP, #-8]!
    // 0x70fb74: r0 = lerp()
    //     0x70fb74: bl              #0x5b4870  ; [package:flutter/src/painting/borders.dart] BorderSide::lerp
    // 0x70fb78: add             SP, SP, #0x18
    // 0x70fb7c: mov             x1, x0
    // 0x70fb80: ldr             x0, [fp, #0x18]
    // 0x70fb84: stur            x1, [fp, #-8]
    // 0x70fb88: LoadField: r2 = r0->field_b
    //     0x70fb88: ldur            w2, [x0, #0xb]
    // 0x70fb8c: DecompressPointer r2
    //     0x70fb8c: add             x2, x2, HEAP, lsl #32
    // 0x70fb90: ldr             x3, [fp, #0x20]
    // 0x70fb94: LoadField: r0 = r3->field_b
    //     0x70fb94: ldur            w0, [x3, #0xb]
    // 0x70fb98: DecompressPointer r0
    //     0x70fb98: add             x0, x0, HEAP, lsl #32
    // 0x70fb9c: stp             x0, x2, [SP, #-0x10]!
    // 0x70fba0: ldr             d0, [fp, #0x10]
    // 0x70fba4: SaveReg d0
    //     0x70fba4: str             d0, [SP, #-8]!
    // 0x70fba8: r0 = lerp()
    //     0x70fba8: bl              #0x70e1fc  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::lerp
    // 0x70fbac: add             SP, SP, #0x18
    // 0x70fbb0: stur            x0, [fp, #-0x10]
    // 0x70fbb4: cmp             w0, NULL
    // 0x70fbb8: b.eq            #0x70fc20
    // 0x70fbbc: r0 = UnderlineInputBorder()
    //     0x70fbbc: bl              #0x70e1f0  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0x70fbc0: mov             x1, x0
    // 0x70fbc4: ldur            x0, [fp, #-0x10]
    // 0x70fbc8: StoreField: r1->field_b = r0
    //     0x70fbc8: stur            w0, [x1, #0xb]
    // 0x70fbcc: ldur            x0, [fp, #-8]
    // 0x70fbd0: StoreField: r1->field_7 = r0
    //     0x70fbd0: stur            w0, [x1, #7]
    // 0x70fbd4: mov             x0, x1
    // 0x70fbd8: LeaveFrame
    //     0x70fbd8: mov             SP, fp
    //     0x70fbdc: ldp             fp, lr, [SP], #0x10
    // 0x70fbe0: ret
    //     0x70fbe0: ret             
    // 0x70fbe4: ldr             x3, [fp, #0x20]
    // 0x70fbe8: ldr             d0, [fp, #0x10]
    // 0x70fbec: cmp             w0, NULL
    // 0x70fbf0: b.ne            #0x70fc08
    // 0x70fbf4: SaveReg r3
    //     0x70fbf4: str             x3, [SP, #-8]!
    // 0x70fbf8: SaveReg d0
    //     0x70fbf8: str             d0, [SP, #-8]!
    // 0x70fbfc: r0 = scale()
    //     0x70fbfc: bl              #0xcf84bc  ; [package:flutter/src/material/input_border.dart] UnderlineInputBorder::scale
    // 0x70fc00: add             SP, SP, #0x10
    // 0x70fc04: b               #0x70fc0c
    // 0x70fc08: r0 = Null
    //     0x70fc08: mov             x0, NULL
    // 0x70fc0c: LeaveFrame
    //     0x70fc0c: mov             SP, fp
    //     0x70fc10: ldp             fp, lr, [SP], #0x10
    // 0x70fc14: ret
    //     0x70fc14: ret             
    // 0x70fc18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x70fc18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x70fc1c: b               #0x70fb38
    // 0x70fc20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x70fc20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintInterior(/* No info */) {
    // ** addr: 0x71776c, size: 0x60
    // 0x71776c: EnterFrame
    //     0x71776c: stp             fp, lr, [SP, #-0x10]!
    //     0x717770: mov             fp, SP
    // 0x717774: CheckStackOverflow
    //     0x717774: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x717778: cmp             SP, x16
    //     0x71777c: b.ls            #0x7177c4
    // 0x717780: ldr             x0, [fp, #0x30]
    // 0x717784: LoadField: r1 = r0->field_b
    //     0x717784: ldur            w1, [x0, #0xb]
    // 0x717788: DecompressPointer r1
    //     0x717788: add             x1, x1, HEAP, lsl #32
    // 0x71778c: ldr             x16, [fp, #0x20]
    // 0x717790: stp             x16, x1, [SP, #-0x10]!
    // 0x717794: r0 = toRRect()
    //     0x717794: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0x717798: add             SP, SP, #0x10
    // 0x71779c: ldr             x16, [fp, #0x28]
    // 0x7177a0: stp             x0, x16, [SP, #-0x10]!
    // 0x7177a4: ldr             x16, [fp, #0x18]
    // 0x7177a8: SaveReg r16
    //     0x7177a8: str             x16, [SP, #-8]!
    // 0x7177ac: r0 = drawRRect()
    //     0x7177ac: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x7177b0: add             SP, SP, #0x18
    // 0x7177b4: r0 = Null
    //     0x7177b4: mov             x0, NULL
    // 0x7177b8: LeaveFrame
    //     0x7177b8: mov             SP, fp
    //     0x7177bc: ldp             fp, lr, [SP], #0x10
    // 0x7177c0: ret
    //     0x7177c0: ret             
    // 0x7177c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7177c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7177c8: b               #0x717780
  }
  _ getInnerPath(/* No info */) {
    // ** addr: 0x71aab8, size: 0x140
    // 0x71aab8: EnterFrame
    //     0x71aab8: stp             fp, lr, [SP, #-0x10]!
    //     0x71aabc: mov             fp, SP
    // 0x71aac0: AllocStack(0x38)
    //     0x71aac0: sub             SP, SP, #0x38
    // 0x71aac4: SetupParameters(UnderlineInputBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0x71aac4: mov             x0, x4
    //     0x71aac8: ldur            w1, [x0, #0x13]
    //     0x71aacc: add             x1, x1, HEAP, lsl #32
    //     0x71aad0: sub             x0, x1, #4
    //     0x71aad4: add             x1, fp, w0, sxtw #2
    //     0x71aad8: ldr             x1, [x1, #0x18]
    //     0x71aadc: stur            x1, [fp, #-0x10]
    //     0x71aae0: add             x2, fp, w0, sxtw #2
    //     0x71aae4: ldr             x2, [x2, #0x10]
    //     0x71aae8: stur            x2, [fp, #-8]
    // 0x71aaec: CheckStackOverflow
    //     0x71aaec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x71aaf0: cmp             SP, x16
    //     0x71aaf4: b.ls            #0x71abf0
    // 0x71aaf8: r0 = Path()
    //     0x71aaf8: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x71aafc: stur            x0, [fp, #-0x18]
    // 0x71ab00: SaveReg r0
    //     0x71ab00: str             x0, [SP, #-8]!
    // 0x71ab04: r0 = _constructor()
    //     0x71ab04: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x71ab08: add             SP, SP, #8
    // 0x71ab0c: ldur            x0, [fp, #-8]
    // 0x71ab10: LoadField: d0 = r0->field_7
    //     0x71ab10: ldur            d0, [x0, #7]
    // 0x71ab14: stur            d0, [fp, #-0x38]
    // 0x71ab18: LoadField: d1 = r0->field_f
    //     0x71ab18: ldur            d1, [x0, #0xf]
    // 0x71ab1c: stur            d1, [fp, #-0x30]
    // 0x71ab20: LoadField: d2 = r0->field_17
    //     0x71ab20: ldur            d2, [x0, #0x17]
    // 0x71ab24: fsub            d3, d2, d0
    // 0x71ab28: LoadField: d2 = r0->field_1f
    //     0x71ab28: ldur            d2, [x0, #0x1f]
    // 0x71ab2c: fsub            d4, d2, d1
    // 0x71ab30: ldur            x0, [fp, #-0x10]
    // 0x71ab34: LoadField: r1 = r0->field_7
    //     0x71ab34: ldur            w1, [x0, #7]
    // 0x71ab38: DecompressPointer r1
    //     0x71ab38: add             x1, x1, HEAP, lsl #32
    // 0x71ab3c: LoadField: d2 = r1->field_b
    //     0x71ab3c: ldur            d2, [x1, #0xb]
    // 0x71ab40: fsub            d5, d4, d2
    // 0x71ab44: d2 = 0.000000
    //     0x71ab44: eor             v2.16b, v2.16b, v2.16b
    // 0x71ab48: fcmp            d2, d5
    // 0x71ab4c: b.vs            #0x71ab5c
    // 0x71ab50: b.le            #0x71ab5c
    // 0x71ab54: d2 = 0.000000
    //     0x71ab54: eor             v2.16b, v2.16b, v2.16b
    // 0x71ab58: b               #0x71ab9c
    // 0x71ab5c: fcmp            d2, d5
    // 0x71ab60: b.vs            #0x71ab70
    // 0x71ab64: b.ge            #0x71ab70
    // 0x71ab68: mov             v2.16b, v5.16b
    // 0x71ab6c: b               #0x71ab9c
    // 0x71ab70: fcmp            d2, d2
    // 0x71ab74: b.vs            #0x71ab88
    // 0x71ab78: b.ne            #0x71ab88
    // 0x71ab7c: fadd            d4, d2, d5
    // 0x71ab80: mov             v2.16b, v4.16b
    // 0x71ab84: b               #0x71ab9c
    // 0x71ab88: fcmp            d5, d5
    // 0x71ab8c: b.vc            #0x71ab98
    // 0x71ab90: mov             v2.16b, v5.16b
    // 0x71ab94: b               #0x71ab9c
    // 0x71ab98: d2 = 0.000000
    //     0x71ab98: eor             v2.16b, v2.16b, v2.16b
    // 0x71ab9c: fadd            d4, d0, d3
    // 0x71aba0: stur            d4, [fp, #-0x28]
    // 0x71aba4: fadd            d3, d1, d2
    // 0x71aba8: stur            d3, [fp, #-0x20]
    // 0x71abac: r0 = Rect()
    //     0x71abac: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x71abb0: ldur            d0, [fp, #-0x38]
    // 0x71abb4: StoreField: r0->field_7 = d0
    //     0x71abb4: stur            d0, [x0, #7]
    // 0x71abb8: ldur            d0, [fp, #-0x30]
    // 0x71abbc: StoreField: r0->field_f = d0
    //     0x71abbc: stur            d0, [x0, #0xf]
    // 0x71abc0: ldur            d0, [fp, #-0x28]
    // 0x71abc4: StoreField: r0->field_17 = d0
    //     0x71abc4: stur            d0, [x0, #0x17]
    // 0x71abc8: ldur            d0, [fp, #-0x20]
    // 0x71abcc: StoreField: r0->field_1f = d0
    //     0x71abcc: stur            d0, [x0, #0x1f]
    // 0x71abd0: ldur            x16, [fp, #-0x18]
    // 0x71abd4: stp             x0, x16, [SP, #-0x10]!
    // 0x71abd8: r0 = addRect()
    //     0x71abd8: bl              #0x71a7b0  ; [dart:ui] Path::addRect
    // 0x71abdc: add             SP, SP, #0x10
    // 0x71abe0: ldur            x0, [fp, #-0x18]
    // 0x71abe4: LeaveFrame
    //     0x71abe4: mov             SP, fp
    //     0x71abe8: ldp             fp, lr, [SP], #0x10
    // 0x71abec: ret
    //     0x71abec: ret             
    // 0x71abf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x71abf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x71abf4: b               #0x71aaf8
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd343c, size: 0x2fc
    // 0xbd343c: EnterFrame
    //     0xbd343c: stp             fp, lr, [SP, #-0x10]!
    //     0xbd3440: mov             fp, SP
    // 0xbd3444: AllocStack(0x40)
    //     0xbd3444: sub             SP, SP, #0x40
    // 0xbd3448: SetupParameters(UnderlineInputBorder this /* r3, fp-0x30 */, dynamic _ /* r4, fp-0x28 */, dynamic _ /* r5, fp-0x20 */, {dynamic gapExtent, dynamic gapPercentage, dynamic gapStart, dynamic textDirection = Null /* r0, fp-0x18 */})
    //     0xbd3448: mov             x0, x4
    //     0xbd344c: ldur            w1, [x0, #0x13]
    //     0xbd3450: add             x1, x1, HEAP, lsl #32
    //     0xbd3454: sub             x2, x1, #6
    //     0xbd3458: add             x3, fp, w2, sxtw #2
    //     0xbd345c: ldr             x3, [x3, #0x20]
    //     0xbd3460: stur            x3, [fp, #-0x30]
    //     0xbd3464: add             x4, fp, w2, sxtw #2
    //     0xbd3468: ldr             x4, [x4, #0x18]
    //     0xbd346c: stur            x4, [fp, #-0x28]
    //     0xbd3470: add             x5, fp, w2, sxtw #2
    //     0xbd3474: ldr             x5, [x5, #0x10]
    //     0xbd3478: stur            x5, [fp, #-0x20]
    //     0xbd347c: ldur            w2, [x0, #0x1f]
    //     0xbd3480: add             x2, x2, HEAP, lsl #32
    //     0xbd3484: add             x16, PP, #0x37, lsl #12  ; [pp+0x377e0] "gapExtent"
    //     0xbd3488: ldr             x16, [x16, #0x7e0]
    //     0xbd348c: cmp             w2, w16
    //     0xbd3490: b.ne            #0xbd349c
    //     0xbd3494: mov             x2, #1
    //     0xbd3498: b               #0xbd34a0
    //     0xbd349c: mov             x2, #0
    //     0xbd34a0: lsl             x6, x2, #1
    //     0xbd34a4: lsl             w7, w6, #1
    //     0xbd34a8: add             w8, w7, #8
    //     0xbd34ac: add             x16, x0, w8, sxtw #1
    //     0xbd34b0: ldur            w7, [x16, #0xf]
    //     0xbd34b4: add             x7, x7, HEAP, lsl #32
    //     0xbd34b8: add             x16, PP, #0x37, lsl #12  ; [pp+0x377e8] "gapPercentage"
    //     0xbd34bc: ldr             x16, [x16, #0x7e8]
    //     0xbd34c0: cmp             w7, w16
    //     0xbd34c4: b.ne            #0xbd34d4
    //     0xbd34c8: add             w2, w6, #2
    //     0xbd34cc: sbfx            x6, x2, #1, #0x1f
    //     0xbd34d0: mov             x2, x6
    //     0xbd34d4: lsl             x6, x2, #1
    //     0xbd34d8: lsl             w7, w6, #1
    //     0xbd34dc: add             w8, w7, #8
    //     0xbd34e0: add             x16, x0, w8, sxtw #1
    //     0xbd34e4: ldur            w7, [x16, #0xf]
    //     0xbd34e8: add             x7, x7, HEAP, lsl #32
    //     0xbd34ec: add             x16, PP, #0x37, lsl #12  ; [pp+0x377f0] "gapStart"
    //     0xbd34f0: ldr             x16, [x16, #0x7f0]
    //     0xbd34f4: cmp             w7, w16
    //     0xbd34f8: b.ne            #0xbd3508
    //     0xbd34fc: add             w2, w6, #2
    //     0xbd3500: sbfx            x6, x2, #1, #0x1f
    //     0xbd3504: mov             x2, x6
    //     0xbd3508: lsl             x6, x2, #1
    //     0xbd350c: lsl             w2, w6, #1
    //     0xbd3510: add             w6, w2, #8
    //     0xbd3514: add             x16, x0, w6, sxtw #1
    //     0xbd3518: ldur            w7, [x16, #0xf]
    //     0xbd351c: add             x7, x7, HEAP, lsl #32
    //     0xbd3520: add             x16, PP, #0xe, lsl #12  ; [pp+0xef10] "textDirection"
    //     0xbd3524: ldr             x16, [x16, #0xf10]
    //     0xbd3528: cmp             w7, w16
    //     0xbd352c: b.ne            #0xbd3554
    //     0xbd3530: add             w6, w2, #0xa
    //     0xbd3534: add             x16, x0, w6, sxtw #1
    //     0xbd3538: ldur            w2, [x16, #0xf]
    //     0xbd353c: add             x2, x2, HEAP, lsl #32
    //     0xbd3540: sub             w0, w1, w2
    //     0xbd3544: add             x1, fp, w0, sxtw #2
    //     0xbd3548: ldr             x1, [x1, #8]
    //     0xbd354c: mov             x0, x1
    //     0xbd3550: b               #0xbd3558
    //     0xbd3554: mov             x0, NULL
    //     0xbd3558: stur            x0, [fp, #-0x18]
    // 0xbd355c: CheckStackOverflow
    //     0xbd355c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbd3560: cmp             SP, x16
    //     0xbd3564: b.ls            #0xbd3730
    // 0xbd3568: LoadField: r1 = r3->field_b
    //     0xbd3568: ldur            w1, [x3, #0xb]
    // 0xbd356c: DecompressPointer r1
    //     0xbd356c: add             x1, x1, HEAP, lsl #32
    // 0xbd3570: stur            x1, [fp, #-0x10]
    // 0xbd3574: LoadField: r2 = r1->field_f
    //     0xbd3574: ldur            w2, [x1, #0xf]
    // 0xbd3578: DecompressPointer r2
    //     0xbd3578: add             x2, x2, HEAP, lsl #32
    // 0xbd357c: stur            x2, [fp, #-8]
    // 0xbd3580: r16 = Instance_Radius
    //     0xbd3580: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xbd3584: ldr             x16, [x16, #0x478]
    // 0xbd3588: cmp             w2, w16
    // 0xbd358c: b.ne            #0xbd35a0
    // 0xbd3590: mov             x0, x1
    // 0xbd3594: r1 = Instance_Radius
    //     0xbd3594: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xbd3598: ldr             x1, [x1, #0x478]
    // 0xbd359c: b               #0xbd35f4
    // 0xbd35a0: r16 = Radius
    //     0xbd35a0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xbd35a4: ldr             x16, [x16, #0x470]
    // 0xbd35a8: r30 = Radius
    //     0xbd35a8: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xbd35ac: ldr             lr, [lr, #0x470]
    // 0xbd35b0: stp             lr, x16, [SP, #-0x10]!
    // 0xbd35b4: r0 = ==()
    //     0xbd35b4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xbd35b8: add             SP, SP, #0x10
    // 0xbd35bc: tbnz            w0, #4, #0xbd3660
    // 0xbd35c0: ldur            x0, [fp, #-8]
    // 0xbd35c4: r1 = Instance_Radius
    //     0xbd35c4: add             x1, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xbd35c8: ldr             x1, [x1, #0x478]
    // 0xbd35cc: LoadField: d0 = r1->field_7
    //     0xbd35cc: ldur            d0, [x1, #7]
    // 0xbd35d0: LoadField: d1 = r0->field_7
    //     0xbd35d0: ldur            d1, [x0, #7]
    // 0xbd35d4: fcmp            d0, d1
    // 0xbd35d8: b.vs            #0xbd3660
    // 0xbd35dc: b.ne            #0xbd3660
    // 0xbd35e0: LoadField: d0 = r1->field_f
    //     0xbd35e0: ldur            d0, [x1, #0xf]
    // 0xbd35e4: LoadField: d1 = r0->field_f
    //     0xbd35e4: ldur            d1, [x0, #0xf]
    // 0xbd35e8: fcmp            d0, d1
    // 0xbd35ec: b.ne            #0xbd3660
    // 0xbd35f0: ldur            x0, [fp, #-0x10]
    // 0xbd35f4: LoadField: r2 = r0->field_13
    //     0xbd35f4: ldur            w2, [x0, #0x13]
    // 0xbd35f8: DecompressPointer r2
    //     0xbd35f8: add             x2, x2, HEAP, lsl #32
    // 0xbd35fc: stur            x2, [fp, #-8]
    // 0xbd3600: r16 = Instance_Radius
    //     0xbd3600: add             x16, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xbd3604: ldr             x16, [x16, #0x478]
    // 0xbd3608: cmp             w2, w16
    // 0xbd360c: b.eq            #0xbd3698
    // 0xbd3610: r16 = Radius
    //     0xbd3610: add             x16, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xbd3614: ldr             x16, [x16, #0x470]
    // 0xbd3618: r30 = Radius
    //     0xbd3618: add             lr, PP, #0xe, lsl #12  ; [pp+0xe470] Type: Radius
    //     0xbd361c: ldr             lr, [lr, #0x470]
    // 0xbd3620: stp             lr, x16, [SP, #-0x10]!
    // 0xbd3624: r0 = ==()
    //     0xbd3624: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xbd3628: add             SP, SP, #0x10
    // 0xbd362c: tbnz            w0, #4, #0xbd3660
    // 0xbd3630: ldur            x1, [fp, #-8]
    // 0xbd3634: r0 = Instance_Radius
    //     0xbd3634: add             x0, PP, #0xe, lsl #12  ; [pp+0xe478] Obj!Radius@b5e821
    //     0xbd3638: ldr             x0, [x0, #0x478]
    // 0xbd363c: LoadField: d0 = r0->field_7
    //     0xbd363c: ldur            d0, [x0, #7]
    // 0xbd3640: LoadField: d1 = r1->field_7
    //     0xbd3640: ldur            d1, [x1, #7]
    // 0xbd3644: fcmp            d0, d1
    // 0xbd3648: b.vs            #0xbd3660
    // 0xbd364c: b.ne            #0xbd3660
    // 0xbd3650: LoadField: d0 = r0->field_f
    //     0xbd3650: ldur            d0, [x0, #0xf]
    // 0xbd3654: LoadField: d1 = r1->field_f
    //     0xbd3654: ldur            d1, [x1, #0xf]
    // 0xbd3658: fcmp            d0, d1
    // 0xbd365c: b.eq            #0xbd3698
    // 0xbd3660: ldur            x16, [fp, #-0x30]
    // 0xbd3664: ldur            lr, [fp, #-0x20]
    // 0xbd3668: stp             lr, x16, [SP, #-0x10]!
    // 0xbd366c: ldur            x16, [fp, #-0x18]
    // 0xbd3670: SaveReg r16
    //     0xbd3670: str             x16, [SP, #-8]!
    // 0xbd3674: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xbd3674: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xbd3678: ldr             x4, [x4, #0x5b8]
    // 0xbd367c: r0 = getOuterPath()
    //     0xbd367c: bl              #0xcfa25c  ; [package:flutter/src/material/input_border.dart] UnderlineInputBorder::getOuterPath
    // 0xbd3680: add             SP, SP, #0x18
    // 0xbd3684: ldur            x16, [fp, #-0x28]
    // 0xbd3688: stp             x0, x16, [SP, #-0x10]!
    // 0xbd368c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbd368c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbd3690: r0 = clipPath()
    //     0xbd3690: bl              #0x6629f4  ; [dart:ui] Canvas::clipPath
    // 0xbd3694: add             SP, SP, #0x10
    // 0xbd3698: ldur            x0, [fp, #-0x30]
    // 0xbd369c: ldur            x1, [fp, #-0x20]
    // 0xbd36a0: LoadField: d0 = r1->field_7
    //     0xbd36a0: ldur            d0, [x1, #7]
    // 0xbd36a4: stur            d0, [fp, #-0x40]
    // 0xbd36a8: LoadField: d1 = r1->field_1f
    //     0xbd36a8: ldur            d1, [x1, #0x1f]
    // 0xbd36ac: stur            d1, [fp, #-0x38]
    // 0xbd36b0: r0 = Offset()
    //     0xbd36b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbd36b4: ldur            d0, [fp, #-0x40]
    // 0xbd36b8: stur            x0, [fp, #-8]
    // 0xbd36bc: StoreField: r0->field_7 = d0
    //     0xbd36bc: stur            d0, [x0, #7]
    // 0xbd36c0: ldur            d0, [fp, #-0x38]
    // 0xbd36c4: StoreField: r0->field_f = d0
    //     0xbd36c4: stur            d0, [x0, #0xf]
    // 0xbd36c8: ldur            x1, [fp, #-0x20]
    // 0xbd36cc: LoadField: d1 = r1->field_17
    //     0xbd36cc: ldur            d1, [x1, #0x17]
    // 0xbd36d0: stur            d1, [fp, #-0x40]
    // 0xbd36d4: r0 = Offset()
    //     0xbd36d4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xbd36d8: ldur            d0, [fp, #-0x40]
    // 0xbd36dc: stur            x0, [fp, #-0x10]
    // 0xbd36e0: StoreField: r0->field_7 = d0
    //     0xbd36e0: stur            d0, [x0, #7]
    // 0xbd36e4: ldur            d0, [fp, #-0x38]
    // 0xbd36e8: StoreField: r0->field_f = d0
    //     0xbd36e8: stur            d0, [x0, #0xf]
    // 0xbd36ec: ldur            x1, [fp, #-0x30]
    // 0xbd36f0: LoadField: r2 = r1->field_7
    //     0xbd36f0: ldur            w2, [x1, #7]
    // 0xbd36f4: DecompressPointer r2
    //     0xbd36f4: add             x2, x2, HEAP, lsl #32
    // 0xbd36f8: SaveReg r2
    //     0xbd36f8: str             x2, [SP, #-8]!
    // 0xbd36fc: r0 = toPaint()
    //     0xbd36fc: bl              #0xbd2f38  ; [package:flutter/src/painting/borders.dart] BorderSide::toPaint
    // 0xbd3700: add             SP, SP, #8
    // 0xbd3704: ldur            x16, [fp, #-0x28]
    // 0xbd3708: ldur            lr, [fp, #-8]
    // 0xbd370c: stp             lr, x16, [SP, #-0x10]!
    // 0xbd3710: ldur            x16, [fp, #-0x10]
    // 0xbd3714: stp             x0, x16, [SP, #-0x10]!
    // 0xbd3718: r0 = drawLine()
    //     0xbd3718: bl              #0xa66350  ; [dart:ui] Canvas::drawLine
    // 0xbd371c: add             SP, SP, #0x20
    // 0xbd3720: r0 = Null
    //     0xbd3720: mov             x0, NULL
    // 0xbd3724: LeaveFrame
    //     0xbd3724: mov             SP, fp
    //     0xbd3728: ldp             fp, lr, [SP], #0x10
    // 0xbd372c: ret
    //     0xbd372c: ret             
    // 0xbd3730: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbd3730: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbd3734: b               #0xbd3568
  }
  _ ==(/* No info */) {
    // ** addr: 0xc99740, size: 0x118
    // 0xc99740: EnterFrame
    //     0xc99740: stp             fp, lr, [SP, #-0x10]!
    //     0xc99744: mov             fp, SP
    // 0xc99748: CheckStackOverflow
    //     0xc99748: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc9974c: cmp             SP, x16
    //     0xc99750: b.ls            #0xc99850
    // 0xc99754: ldr             x1, [fp, #0x10]
    // 0xc99758: cmp             w1, NULL
    // 0xc9975c: b.ne            #0xc99770
    // 0xc99760: r0 = false
    //     0xc99760: add             x0, NULL, #0x30  ; false
    // 0xc99764: LeaveFrame
    //     0xc99764: mov             SP, fp
    //     0xc99768: ldp             fp, lr, [SP], #0x10
    // 0xc9976c: ret
    //     0xc9976c: ret             
    // 0xc99770: ldr             x2, [fp, #0x18]
    // 0xc99774: cmp             w2, w1
    // 0xc99778: b.ne            #0xc9978c
    // 0xc9977c: r0 = true
    //     0xc9977c: add             x0, NULL, #0x20  ; true
    // 0xc99780: LeaveFrame
    //     0xc99780: mov             SP, fp
    //     0xc99784: ldp             fp, lr, [SP], #0x10
    // 0xc99788: ret
    //     0xc99788: ret             
    // 0xc9978c: r0 = 59
    //     0xc9978c: mov             x0, #0x3b
    // 0xc99790: branchIfSmi(r1, 0xc9979c)
    //     0xc99790: tbz             w1, #0, #0xc9979c
    // 0xc99794: r0 = LoadClassIdInstr(r1)
    //     0xc99794: ldur            x0, [x1, #-1]
    //     0xc99798: ubfx            x0, x0, #0xc, #0x14
    // 0xc9979c: SaveReg r1
    //     0xc9979c: str             x1, [SP, #-8]!
    // 0xc997a0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc997a0: mov             x17, #0x57c5
    //     0xc997a4: add             lr, x0, x17
    //     0xc997a8: ldr             lr, [x21, lr, lsl #3]
    //     0xc997ac: blr             lr
    // 0xc997b0: add             SP, SP, #8
    // 0xc997b4: r1 = LoadClassIdInstr(r0)
    //     0xc997b4: ldur            x1, [x0, #-1]
    //     0xc997b8: ubfx            x1, x1, #0xc, #0x14
    // 0xc997bc: r16 = UnderlineInputBorder
    //     0xc997bc: add             x16, PP, #0x40, lsl #12  ; [pp+0x40170] Type: UnderlineInputBorder
    //     0xc997c0: ldr             x16, [x16, #0x170]
    // 0xc997c4: stp             x16, x0, [SP, #-0x10]!
    // 0xc997c8: mov             x0, x1
    // 0xc997cc: mov             lr, x0
    // 0xc997d0: ldr             lr, [x21, lr, lsl #3]
    // 0xc997d4: blr             lr
    // 0xc997d8: add             SP, SP, #0x10
    // 0xc997dc: tbz             w0, #4, #0xc997f0
    // 0xc997e0: r0 = false
    //     0xc997e0: add             x0, NULL, #0x30  ; false
    // 0xc997e4: LeaveFrame
    //     0xc997e4: mov             SP, fp
    //     0xc997e8: ldp             fp, lr, [SP], #0x10
    // 0xc997ec: ret
    //     0xc997ec: ret             
    // 0xc997f0: ldr             x0, [fp, #0x10]
    // 0xc997f4: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc997f4: mov             x1, #0x76
    //     0xc997f8: tbz             w0, #0, #0xc99808
    //     0xc997fc: ldur            x1, [x0, #-1]
    //     0xc99800: ubfx            x1, x1, #0xc, #0x14
    //     0xc99804: lsl             x1, x1, #1
    // 0xc99808: r2 = LoadInt32Instr(r1)
    //     0xc99808: sbfx            x2, x1, #1, #0x1f
    // 0xc9980c: cmp             x2, #0x886
    // 0xc99810: b.lt            #0xc99840
    // 0xc99814: cmp             x2, #0x888
    // 0xc99818: b.gt            #0xc99840
    // 0xc9981c: ldr             x1, [fp, #0x18]
    // 0xc99820: LoadField: r2 = r0->field_7
    //     0xc99820: ldur            w2, [x0, #7]
    // 0xc99824: DecompressPointer r2
    //     0xc99824: add             x2, x2, HEAP, lsl #32
    // 0xc99828: LoadField: r0 = r1->field_7
    //     0xc99828: ldur            w0, [x1, #7]
    // 0xc9982c: DecompressPointer r0
    //     0xc9982c: add             x0, x0, HEAP, lsl #32
    // 0xc99830: stp             x0, x2, [SP, #-0x10]!
    // 0xc99834: r0 = ==()
    //     0xc99834: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xc99838: add             SP, SP, #0x10
    // 0xc9983c: b               #0xc99844
    // 0xc99840: r0 = false
    //     0xc99840: add             x0, NULL, #0x30  ; false
    // 0xc99844: LeaveFrame
    //     0xc99844: mov             SP, fp
    //     0xc99848: ldp             fp, lr, [SP], #0x10
    // 0xc9984c: ret
    //     0xc9984c: ret             
    // 0xc99850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc99850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc99854: b               #0xc99754
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0xceed7c, size: 0x48
    // 0xceed7c: EnterFrame
    //     0xceed7c: stp             fp, lr, [SP, #-0x10]!
    //     0xceed80: mov             fp, SP
    // 0xceed84: AllocStack(0x8)
    //     0xceed84: sub             SP, SP, #8
    // 0xceed88: ldr             x0, [fp, #0x10]
    // 0xceed8c: LoadField: r1 = r0->field_7
    //     0xceed8c: ldur            w1, [x0, #7]
    // 0xceed90: DecompressPointer r1
    //     0xceed90: add             x1, x1, HEAP, lsl #32
    // 0xceed94: LoadField: d0 = r1->field_b
    //     0xceed94: ldur            d0, [x1, #0xb]
    // 0xceed98: stur            d0, [fp, #-8]
    // 0xceed9c: r0 = EdgeInsets()
    //     0xceed9c: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xceeda0: d0 = 0.000000
    //     0xceeda0: eor             v0.16b, v0.16b, v0.16b
    // 0xceeda4: StoreField: r0->field_7 = d0
    //     0xceeda4: stur            d0, [x0, #7]
    // 0xceeda8: StoreField: r0->field_f = d0
    //     0xceeda8: stur            d0, [x0, #0xf]
    // 0xceedac: StoreField: r0->field_17 = d0
    //     0xceedac: stur            d0, [x0, #0x17]
    // 0xceedb0: ldur            d0, [fp, #-8]
    // 0xceedb4: StoreField: r0->field_1f = d0
    //     0xceedb4: stur            d0, [x0, #0x1f]
    // 0xceedb8: LeaveFrame
    //     0xceedb8: mov             SP, fp
    //     0xceedbc: ldp             fp, lr, [SP], #0x10
    // 0xceedc0: ret
    //     0xceedc0: ret             
  }
  _ scale(/* No info */) {
    // ** addr: 0xcf84bc, size: 0x68
    // 0xcf84bc: EnterFrame
    //     0xcf84bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcf84c0: mov             fp, SP
    // 0xcf84c4: AllocStack(0x8)
    //     0xcf84c4: sub             SP, SP, #8
    // 0xcf84c8: CheckStackOverflow
    //     0xcf84c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf84cc: cmp             SP, x16
    //     0xcf84d0: b.ls            #0xcf851c
    // 0xcf84d4: ldr             x0, [fp, #0x18]
    // 0xcf84d8: LoadField: r1 = r0->field_7
    //     0xcf84d8: ldur            w1, [x0, #7]
    // 0xcf84dc: DecompressPointer r1
    //     0xcf84dc: add             x1, x1, HEAP, lsl #32
    // 0xcf84e0: SaveReg r1
    //     0xcf84e0: str             x1, [SP, #-8]!
    // 0xcf84e4: ldr             d0, [fp, #0x10]
    // 0xcf84e8: SaveReg d0
    //     0xcf84e8: str             d0, [SP, #-8]!
    // 0xcf84ec: r0 = scale()
    //     0xcf84ec: bl              #0xcf83e4  ; [package:flutter/src/painting/borders.dart] BorderSide::scale
    // 0xcf84f0: add             SP, SP, #0x10
    // 0xcf84f4: stur            x0, [fp, #-8]
    // 0xcf84f8: r0 = UnderlineInputBorder()
    //     0xcf84f8: bl              #0x70e1f0  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0xcf84fc: r1 = Instance_BorderRadius
    //     0xcf84fc: add             x1, PP, #0x40, lsl #12  ; [pp+0x40178] Obj!BorderRadius@b374f1
    //     0xcf8500: ldr             x1, [x1, #0x178]
    // 0xcf8504: StoreField: r0->field_b = r1
    //     0xcf8504: stur            w1, [x0, #0xb]
    // 0xcf8508: ldur            x1, [fp, #-8]
    // 0xcf850c: StoreField: r0->field_7 = r1
    //     0xcf850c: stur            w1, [x0, #7]
    // 0xcf8510: LeaveFrame
    //     0xcf8510: mov             SP, fp
    //     0xcf8514: ldp             fp, lr, [SP], #0x10
    // 0xcf8518: ret
    //     0xcf8518: ret             
    // 0xcf851c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf851c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf8520: b               #0xcf84d4
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa25c, size: 0x98
    // 0xcfa25c: EnterFrame
    //     0xcfa25c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa260: mov             fp, SP
    // 0xcfa264: AllocStack(0x18)
    //     0xcfa264: sub             SP, SP, #0x18
    // 0xcfa268: SetupParameters(UnderlineInputBorder this /* r1, fp-0x10 */, dynamic _ /* r2, fp-0x8 */)
    //     0xcfa268: mov             x0, x4
    //     0xcfa26c: ldur            w1, [x0, #0x13]
    //     0xcfa270: add             x1, x1, HEAP, lsl #32
    //     0xcfa274: sub             x0, x1, #4
    //     0xcfa278: add             x1, fp, w0, sxtw #2
    //     0xcfa27c: ldr             x1, [x1, #0x18]
    //     0xcfa280: stur            x1, [fp, #-0x10]
    //     0xcfa284: add             x2, fp, w0, sxtw #2
    //     0xcfa288: ldr             x2, [x2, #0x10]
    //     0xcfa28c: stur            x2, [fp, #-8]
    // 0xcfa290: CheckStackOverflow
    //     0xcfa290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa294: cmp             SP, x16
    //     0xcfa298: b.ls            #0xcfa2ec
    // 0xcfa29c: r0 = Path()
    //     0xcfa29c: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa2a0: stur            x0, [fp, #-0x18]
    // 0xcfa2a4: SaveReg r0
    //     0xcfa2a4: str             x0, [SP, #-8]!
    // 0xcfa2a8: r0 = _constructor()
    //     0xcfa2a8: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa2ac: add             SP, SP, #8
    // 0xcfa2b0: ldur            x0, [fp, #-0x10]
    // 0xcfa2b4: LoadField: r1 = r0->field_b
    //     0xcfa2b4: ldur            w1, [x0, #0xb]
    // 0xcfa2b8: DecompressPointer r1
    //     0xcfa2b8: add             x1, x1, HEAP, lsl #32
    // 0xcfa2bc: ldur            x16, [fp, #-8]
    // 0xcfa2c0: stp             x16, x1, [SP, #-0x10]!
    // 0xcfa2c4: r0 = toRRect()
    //     0xcfa2c4: bl              #0x670600  ; [package:flutter/src/painting/border_radius.dart] BorderRadius::toRRect
    // 0xcfa2c8: add             SP, SP, #0x10
    // 0xcfa2cc: ldur            x16, [fp, #-0x18]
    // 0xcfa2d0: stp             x0, x16, [SP, #-0x10]!
    // 0xcfa2d4: r0 = addRRect()
    //     0xcfa2d4: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0xcfa2d8: add             SP, SP, #0x10
    // 0xcfa2dc: ldur            x0, [fp, #-0x18]
    // 0xcfa2e0: LeaveFrame
    //     0xcfa2e0: mov             SP, fp
    //     0xcfa2e4: ldp             fp, lr, [SP], #0x10
    // 0xcfa2e8: ret
    //     0xcfa2e8: ret             
    // 0xcfa2ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa2ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa2f0: b               #0xcfa29c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcfacec, size: 0x5c
    // 0xcfacec: EnterFrame
    //     0xcfacec: stp             fp, lr, [SP, #-0x10]!
    //     0xcfacf0: mov             fp, SP
    // 0xcfacf4: AllocStack(0x10)
    //     0xcfacf4: sub             SP, SP, #0x10
    // 0xcfacf8: ldr             x0, [fp, #0x10]
    // 0xcfacfc: cmp             w0, NULL
    // 0xcfad00: b.ne            #0xcfad14
    // 0xcfad04: ldr             x1, [fp, #0x18]
    // 0xcfad08: LoadField: r0 = r1->field_7
    //     0xcfad08: ldur            w0, [x1, #7]
    // 0xcfad0c: DecompressPointer r0
    //     0xcfad0c: add             x0, x0, HEAP, lsl #32
    // 0xcfad10: b               #0xcfad18
    // 0xcfad14: ldr             x1, [fp, #0x18]
    // 0xcfad18: stur            x0, [fp, #-0x10]
    // 0xcfad1c: LoadField: r2 = r1->field_b
    //     0xcfad1c: ldur            w2, [x1, #0xb]
    // 0xcfad20: DecompressPointer r2
    //     0xcfad20: add             x2, x2, HEAP, lsl #32
    // 0xcfad24: stur            x2, [fp, #-8]
    // 0xcfad28: r0 = UnderlineInputBorder()
    //     0xcfad28: bl              #0x70e1f0  ; AllocateUnderlineInputBorderStub -> UnderlineInputBorder (size=0x10)
    // 0xcfad2c: ldur            x1, [fp, #-8]
    // 0xcfad30: StoreField: r0->field_b = r1
    //     0xcfad30: stur            w1, [x0, #0xb]
    // 0xcfad34: ldur            x1, [fp, #-0x10]
    // 0xcfad38: StoreField: r0->field_7 = r1
    //     0xcfad38: stur            w1, [x0, #7]
    // 0xcfad3c: LeaveFrame
    //     0xcfad3c: mov             SP, fp
    //     0xcfad40: ldp             fp, lr, [SP], #0x10
    // 0xcfad44: ret
    //     0xcfad44: ret             
  }
}

// class id: 2184, size: 0xc, field offset: 0xc
//   const constructor, 
class _NoInputBorder extends InputBorder {

  BorderSide field_8;

  _ paintInterior(/* No info */) {
    // ** addr: 0x717724, size: 0x48
    // 0x717724: EnterFrame
    //     0x717724: stp             fp, lr, [SP, #-0x10]!
    //     0x717728: mov             fp, SP
    // 0x71772c: CheckStackOverflow
    //     0x71772c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x717730: cmp             SP, x16
    //     0x717734: b.ls            #0x717764
    // 0x717738: ldr             x16, [fp, #0x28]
    // 0x71773c: ldr             lr, [fp, #0x20]
    // 0x717740: stp             lr, x16, [SP, #-0x10]!
    // 0x717744: ldr             x16, [fp, #0x18]
    // 0x717748: SaveReg r16
    //     0x717748: str             x16, [SP, #-8]!
    // 0x71774c: r0 = drawRect()
    //     0x71774c: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0x717750: add             SP, SP, #0x18
    // 0x717754: r0 = Null
    //     0x717754: mov             x0, NULL
    // 0x717758: LeaveFrame
    //     0x717758: mov             SP, fp
    //     0x71775c: ldp             fp, lr, [SP], #0x10
    // 0x717760: ret
    //     0x717760: ret             
    // 0x717764: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x717764: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x717768: b               #0x717738
  }
  _ paint(/* No info */) {
    // ** addr: 0xbd33a0, size: 0x9c
    // 0xbd33a0: EnterFrame
    //     0xbd33a0: stp             fp, lr, [SP, #-0x10]!
    //     0xbd33a4: mov             fp, SP
    // 0xbd33a8: mov             x1, x4
    // 0xbd33ac: LoadField: r2 = r1->field_1f
    //     0xbd33ac: ldur            w2, [x1, #0x1f]
    // 0xbd33b0: DecompressPointer r2
    //     0xbd33b0: add             x2, x2, HEAP, lsl #32
    // 0xbd33b4: r16 = "gapExtent"
    //     0xbd33b4: add             x16, PP, #0x37, lsl #12  ; [pp+0x377e0] "gapExtent"
    //     0xbd33b8: ldr             x16, [x16, #0x7e0]
    // 0xbd33bc: cmp             w2, w16
    // 0xbd33c0: b.ne            #0xbd33cc
    // 0xbd33c4: r2 = 1
    //     0xbd33c4: mov             x2, #1
    // 0xbd33c8: b               #0xbd33d0
    // 0xbd33cc: r2 = 0
    //     0xbd33cc: mov             x2, #0
    // 0xbd33d0: lsl             x3, x2, #1
    // 0xbd33d4: lsl             w4, w3, #1
    // 0xbd33d8: add             w5, w4, #8
    // 0xbd33dc: ArrayLoad: r4 = r1[r5]  ; Unknown_4
    //     0xbd33dc: add             x16, x1, w5, sxtw #1
    //     0xbd33e0: ldur            w4, [x16, #0xf]
    // 0xbd33e4: DecompressPointer r4
    //     0xbd33e4: add             x4, x4, HEAP, lsl #32
    // 0xbd33e8: r16 = "gapPercentage"
    //     0xbd33e8: add             x16, PP, #0x37, lsl #12  ; [pp+0x377e8] "gapPercentage"
    //     0xbd33ec: ldr             x16, [x16, #0x7e8]
    // 0xbd33f0: cmp             w4, w16
    // 0xbd33f4: b.ne            #0xbd3404
    // 0xbd33f8: add             w4, w3, #2
    // 0xbd33fc: r3 = LoadInt32Instr(r4)
    //     0xbd33fc: sbfx            x3, x4, #1, #0x1f
    // 0xbd3400: mov             x2, x3
    // 0xbd3404: lsl             x3, x2, #1
    // 0xbd3408: lsl             w2, w3, #1
    // 0xbd340c: add             w3, w2, #8
    // 0xbd3410: ArrayLoad: r2 = r1[r3]  ; Unknown_4
    //     0xbd3410: add             x16, x1, w3, sxtw #1
    //     0xbd3414: ldur            w2, [x16, #0xf]
    // 0xbd3418: DecompressPointer r2
    //     0xbd3418: add             x2, x2, HEAP, lsl #32
    // 0xbd341c: r16 = "gapStart"
    //     0xbd341c: add             x16, PP, #0x37, lsl #12  ; [pp+0x377f0] "gapStart"
    //     0xbd3420: ldr             x16, [x16, #0x7f0]
    // 0xbd3424: cmp             w2, w16
    // 0xbd3428: b.eq            #0xbd342c
    // 0xbd342c: r0 = Null
    //     0xbd342c: mov             x0, NULL
    // 0xbd3430: LeaveFrame
    //     0xbd3430: mov             SP, fp
    //     0xbd3434: ldp             fp, lr, [SP], #0x10
    // 0xbd3438: ret
    //     0xbd3438: ret             
  }
  get _ dimensions(/* No info */) {
    // ** addr: 0xceed70, size: 0xc
    // 0xceed70: r0 = Instance_EdgeInsets
    //     0xceed70: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xceed74: ldr             x0, [x0, #0xbd8]
    // 0xceed78: ret
    //     0xceed78: ret             
  }
  _ getOuterPath(/* No info */) {
    // ** addr: 0xcfa1e8, size: 0x74
    // 0xcfa1e8: EnterFrame
    //     0xcfa1e8: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa1ec: mov             fp, SP
    // 0xcfa1f0: AllocStack(0x10)
    //     0xcfa1f0: sub             SP, SP, #0x10
    // 0xcfa1f4: SetupParameters(_NoInputBorder this /* r1, fp-0x8 */)
    //     0xcfa1f4: mov             x0, x4
    //     0xcfa1f8: ldur            w1, [x0, #0x13]
    //     0xcfa1fc: add             x1, x1, HEAP, lsl #32
    //     0xcfa200: sub             x0, x1, #4
    //     0xcfa204: add             x1, fp, w0, sxtw #2
    //     0xcfa208: ldr             x1, [x1, #0x10]
    //     0xcfa20c: stur            x1, [fp, #-8]
    // 0xcfa210: CheckStackOverflow
    //     0xcfa210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa214: cmp             SP, x16
    //     0xcfa218: b.ls            #0xcfa254
    // 0xcfa21c: r0 = Path()
    //     0xcfa21c: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcfa220: stur            x0, [fp, #-0x10]
    // 0xcfa224: SaveReg r0
    //     0xcfa224: str             x0, [SP, #-8]!
    // 0xcfa228: r0 = _constructor()
    //     0xcfa228: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcfa22c: add             SP, SP, #8
    // 0xcfa230: ldur            x16, [fp, #-0x10]
    // 0xcfa234: ldur            lr, [fp, #-8]
    // 0xcfa238: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa23c: r0 = addRect()
    //     0xcfa23c: bl              #0x71a7b0  ; [dart:ui] Path::addRect
    // 0xcfa240: add             SP, SP, #0x10
    // 0xcfa244: ldur            x0, [fp, #-0x10]
    // 0xcfa248: LeaveFrame
    //     0xcfa248: mov             SP, fp
    //     0xcfa24c: ldp             fp, lr, [SP], #0x10
    // 0xcfa250: ret
    //     0xcfa250: ret             
    // 0xcfa254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa254: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa258: b               #0xcfa21c
  }
  _ copyWith(/* No info */) {
    // ** addr: 0xcface0, size: 0xc
    // 0xcface0: r0 = Instance__NoInputBorder
    //     0xcface0: add             x0, PP, #0x2c, lsl #12  ; [pp+0x2c080] Obj!_NoInputBorder@b38481
    //     0xcface4: ldr             x0, [x0, #0x80]
    // 0xcface8: ret
    //     0xcface8: ret             
  }
}

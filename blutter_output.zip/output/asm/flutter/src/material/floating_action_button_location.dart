// lib: , url: package:flutter/src/material/floating_action_button_location.dart

// class id: 1049246, size: 0x8
class :: {
}

// class id: 2201, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class FloatingActionButtonAnimator extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xada638, size: 0xc
    // 0xada638: r0 = "FloatingActionButtonAnimator"
    //     0xada638: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c10] "FloatingActionButtonAnimator"
    //     0xada63c: ldr             x0, [x0, #0xc10]
    // 0xada640: ret
    //     0xada640: ret             
  }
}

// class id: 2202, size: 0x8, field offset: 0x8
//   const constructor, 
class _ScalingFabMotionAnimator extends FloatingActionButtonAnimator {

  static late final Animatable<double> _rotationTween; // offset: 0xd98
  static late final Animatable<double> _thresholdCenterTween; // offset: 0xd9c

  _ getRotationAnimation(/* No info */) {
    // ** addr: 0x7b9e78, size: 0x16c
    // 0x7b9e78: EnterFrame
    //     0x7b9e78: stp             fp, lr, [SP, #-0x10]!
    //     0x7b9e7c: mov             fp, SP
    // 0x7b9e80: AllocStack(0x18)
    //     0x7b9e80: sub             SP, SP, #0x18
    // 0x7b9e84: CheckStackOverflow
    //     0x7b9e84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b9e88: cmp             SP, x16
    //     0x7b9e8c: b.ls            #0x7b9fdc
    // 0x7b9e90: r0 = InitLateStaticField(0xd98) // [package:flutter/src/material/floating_action_button_location.dart] _ScalingFabMotionAnimator::_rotationTween
    //     0x7b9e90: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b9e94: ldr             x0, [x0, #0x1b30]
    //     0x7b9e98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b9e9c: cmp             w0, w16
    //     0x7b9ea0: b.ne            #0x7b9eb0
    //     0x7b9ea4: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e0d0] Field <_ScalingFabMotionAnimator@747063916._rotationTween@747063916>: static late final (offset: 0xd98)
    //     0x7b9ea8: ldr             x2, [x2, #0xd0]
    //     0x7b9eac: bl              #0xd67cdc
    // 0x7b9eb0: ldr             x16, [fp, #0x10]
    // 0x7b9eb4: stp             x16, x0, [SP, #-0x10]!
    // 0x7b9eb8: r0 = animate()
    //     0x7b9eb8: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b9ebc: add             SP, SP, #0x10
    // 0x7b9ec0: stur            x0, [fp, #-8]
    // 0x7b9ec4: r0 = InitLateStaticField(0xd9c) // [package:flutter/src/material/floating_action_button_location.dart] _ScalingFabMotionAnimator::_thresholdCenterTween
    //     0x7b9ec4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b9ec8: ldr             x0, [x0, #0x1b38]
    //     0x7b9ecc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b9ed0: cmp             w0, w16
    //     0x7b9ed4: b.ne            #0x7b9ee4
    //     0x7b9ed8: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2e0d8] Field <_ScalingFabMotionAnimator@747063916._thresholdCenterTween@747063916>: static late final (offset: 0xd9c)
    //     0x7b9edc: ldr             x2, [x2, #0xd8]
    //     0x7b9ee0: bl              #0xd67cdc
    // 0x7b9ee4: ldr             x16, [fp, #0x10]
    // 0x7b9ee8: stp             x16, x0, [SP, #-0x10]!
    // 0x7b9eec: r0 = animate()
    //     0x7b9eec: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b9ef0: add             SP, SP, #0x10
    // 0x7b9ef4: r1 = <double>
    //     0x7b9ef4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b9ef8: stur            x0, [fp, #-0x10]
    // 0x7b9efc: r0 = ReverseAnimation()
    //     0x7b9efc: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0x7b9f00: mov             x2, x0
    // 0x7b9f04: ldur            x0, [fp, #-0x10]
    // 0x7b9f08: stur            x2, [fp, #-0x18]
    // 0x7b9f0c: StoreField: r2->field_17 = r0
    //     0x7b9f0c: stur            w0, [x2, #0x17]
    // 0x7b9f10: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x7b9f10: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x7b9f14: ldr             x1, [x1, #0x3d8]
    // 0x7b9f18: r0 = ObserverList()
    //     0x7b9f18: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x7b9f1c: mov             x1, x0
    // 0x7b9f20: r0 = false
    //     0x7b9f20: add             x0, NULL, #0x30  ; false
    // 0x7b9f24: stur            x1, [fp, #-0x10]
    // 0x7b9f28: StoreField: r1->field_f = r0
    //     0x7b9f28: stur            w0, [x1, #0xf]
    // 0x7b9f2c: r0 = Sentinel
    //     0x7b9f2c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b9f30: StoreField: r1->field_13 = r0
    //     0x7b9f30: stur            w0, [x1, #0x13]
    // 0x7b9f34: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x7b9f34: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x7b9f38: ldr             x16, [x16, #0x3d8]
    // 0x7b9f3c: stp             xzr, x16, [SP, #-0x10]!
    // 0x7b9f40: r0 = _GrowableList()
    //     0x7b9f40: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7b9f44: add             SP, SP, #0x10
    // 0x7b9f48: ldur            x1, [fp, #-0x10]
    // 0x7b9f4c: StoreField: r1->field_b = r0
    //     0x7b9f4c: stur            w0, [x1, #0xb]
    //     0x7b9f50: ldurb           w16, [x1, #-1]
    //     0x7b9f54: ldurb           w17, [x0, #-1]
    //     0x7b9f58: and             x16, x17, x16, lsr #2
    //     0x7b9f5c: tst             x16, HEAP, lsr #32
    //     0x7b9f60: b.eq            #0x7b9f68
    //     0x7b9f64: bl              #0xd6826c
    // 0x7b9f68: mov             x0, x1
    // 0x7b9f6c: ldur            x2, [fp, #-0x18]
    // 0x7b9f70: StoreField: r2->field_13 = r0
    //     0x7b9f70: stur            w0, [x2, #0x13]
    //     0x7b9f74: ldurb           w16, [x2, #-1]
    //     0x7b9f78: ldurb           w17, [x0, #-1]
    //     0x7b9f7c: and             x16, x17, x16, lsr #2
    //     0x7b9f80: tst             x16, HEAP, lsr #32
    //     0x7b9f84: b.eq            #0x7b9f8c
    //     0x7b9f88: bl              #0xd6828c
    // 0x7b9f8c: r0 = 0
    //     0x7b9f8c: mov             x0, #0
    // 0x7b9f90: StoreField: r2->field_b = r0
    //     0x7b9f90: stur            x0, [x2, #0xb]
    // 0x7b9f94: r1 = <double>
    //     0x7b9f94: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b9f98: r0 = _AnimationSwap()
    //     0x7b9f98: bl              #0x7b9fe4  ; Allocate_AnimationSwapStub -> _AnimationSwap<X0> (size=0x38)
    // 0x7b9f9c: mov             x1, x0
    // 0x7b9fa0: ldr             x0, [fp, #0x10]
    // 0x7b9fa4: stur            x1, [fp, #-0x10]
    // 0x7b9fa8: StoreField: r1->field_2b = r0
    //     0x7b9fa8: stur            w0, [x1, #0x2b]
    // 0x7b9fac: d0 = 0.500000
    //     0x7b9fac: fmov            d0, #0.50000000
    // 0x7b9fb0: StoreField: r1->field_2f = d0
    //     0x7b9fb0: stur            d0, [x1, #0x2f]
    // 0x7b9fb4: ldur            x16, [fp, #-8]
    // 0x7b9fb8: stp             x16, x1, [SP, #-0x10]!
    // 0x7b9fbc: ldur            x16, [fp, #-0x18]
    // 0x7b9fc0: SaveReg r16
    //     0x7b9fc0: str             x16, [SP, #-8]!
    // 0x7b9fc4: r0 = CompoundAnimation()
    //     0x7b9fc4: bl              #0x7b9d00  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::CompoundAnimation
    // 0x7b9fc8: add             SP, SP, #0x18
    // 0x7b9fcc: ldur            x0, [fp, #-0x10]
    // 0x7b9fd0: LeaveFrame
    //     0x7b9fd0: mov             SP, fp
    //     0x7b9fd4: ldp             fp, lr, [SP], #0x10
    // 0x7b9fd8: ret
    //     0x7b9fd8: ret             
    // 0x7b9fdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b9fdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b9fe0: b               #0x7b9e90
  }
  static Animatable<double> _thresholdCenterTween() {
    // ** addr: 0x7b9ffc, size: 0x28
    // 0x7b9ffc: EnterFrame
    //     0x7b9ffc: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba000: mov             fp, SP
    // 0x7ba004: r1 = <double>
    //     0x7ba004: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba008: r0 = CurveTween()
    //     0x7ba008: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7ba00c: r1 = Instance_Threshold
    //     0x7ba00c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0e0] Obj!Threshold<double>@b4f701
    //     0x7ba010: ldr             x1, [x1, #0xe0]
    // 0x7ba014: StoreField: r0->field_b = r1
    //     0x7ba014: stur            w1, [x0, #0xb]
    // 0x7ba018: LeaveFrame
    //     0x7ba018: mov             SP, fp
    //     0x7ba01c: ldp             fp, lr, [SP], #0x10
    // 0x7ba020: ret
    //     0x7ba020: ret             
  }
  static Animatable<double> _rotationTween() {
    // ** addr: 0x7ba024, size: 0x30
    // 0x7ba024: EnterFrame
    //     0x7ba024: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba028: mov             fp, SP
    // 0x7ba02c: r1 = <double>
    //     0x7ba02c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba030: r0 = Tween()
    //     0x7ba030: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7ba034: r1 = 0.750000
    //     0x7ba034: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e0e8] 0.75
    //     0x7ba038: ldr             x1, [x1, #0xe8]
    // 0x7ba03c: StoreField: r0->field_b = r1
    //     0x7ba03c: stur            w1, [x0, #0xb]
    // 0x7ba040: r1 = 1.000000
    //     0x7ba040: ldr             x1, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7ba044: StoreField: r0->field_f = r1
    //     0x7ba044: stur            w1, [x0, #0xf]
    // 0x7ba048: LeaveFrame
    //     0x7ba048: mov             SP, fp
    //     0x7ba04c: ldp             fp, lr, [SP], #0x10
    // 0x7ba050: ret
    //     0x7ba050: ret             
  }
  _ getScaleAnimation(/* No info */) {
    // ** addr: 0x7ba054, size: 0x174
    // 0x7ba054: EnterFrame
    //     0x7ba054: stp             fp, lr, [SP, #-0x10]!
    //     0x7ba058: mov             fp, SP
    // 0x7ba05c: AllocStack(0x18)
    //     0x7ba05c: sub             SP, SP, #0x18
    // 0x7ba060: CheckStackOverflow
    //     0x7ba060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ba064: cmp             SP, x16
    //     0x7ba068: b.ls            #0x7ba1c0
    // 0x7ba06c: r1 = <double>
    //     0x7ba06c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba070: r0 = FlippedCurve()
    //     0x7ba070: bl              #0x7ba1ec  ; AllocateFlippedCurveStub -> FlippedCurve (size=0x10)
    // 0x7ba074: mov             x2, x0
    // 0x7ba078: r0 = Instance_Interval
    //     0x7ba078: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e0f0] Obj!Interval<double>@b4f761
    //     0x7ba07c: ldr             x0, [x0, #0xf0]
    // 0x7ba080: stur            x2, [fp, #-8]
    // 0x7ba084: StoreField: r2->field_b = r0
    //     0x7ba084: stur            w0, [x2, #0xb]
    // 0x7ba088: r1 = <double>
    //     0x7ba088: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba08c: r0 = CurveTween()
    //     0x7ba08c: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7ba090: mov             x1, x0
    // 0x7ba094: ldur            x0, [fp, #-8]
    // 0x7ba098: StoreField: r1->field_b = r0
    //     0x7ba098: stur            w0, [x1, #0xb]
    // 0x7ba09c: ldr             x16, [fp, #0x10]
    // 0x7ba0a0: stp             x16, x1, [SP, #-0x10]!
    // 0x7ba0a4: r0 = animate()
    //     0x7ba0a4: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7ba0a8: add             SP, SP, #0x10
    // 0x7ba0ac: r1 = <double>
    //     0x7ba0ac: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba0b0: stur            x0, [fp, #-8]
    // 0x7ba0b4: r0 = ReverseAnimation()
    //     0x7ba0b4: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0x7ba0b8: mov             x2, x0
    // 0x7ba0bc: ldur            x0, [fp, #-8]
    // 0x7ba0c0: stur            x2, [fp, #-0x10]
    // 0x7ba0c4: StoreField: r2->field_17 = r0
    //     0x7ba0c4: stur            w0, [x2, #0x17]
    // 0x7ba0c8: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0x7ba0c8: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x7ba0cc: ldr             x1, [x1, #0x3d8]
    // 0x7ba0d0: r0 = ObserverList()
    //     0x7ba0d0: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x7ba0d4: mov             x1, x0
    // 0x7ba0d8: r0 = false
    //     0x7ba0d8: add             x0, NULL, #0x30  ; false
    // 0x7ba0dc: stur            x1, [fp, #-8]
    // 0x7ba0e0: StoreField: r1->field_f = r0
    //     0x7ba0e0: stur            w0, [x1, #0xf]
    // 0x7ba0e4: r0 = Sentinel
    //     0x7ba0e4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7ba0e8: StoreField: r1->field_13 = r0
    //     0x7ba0e8: stur            w0, [x1, #0x13]
    // 0x7ba0ec: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0x7ba0ec: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0x7ba0f0: ldr             x16, [x16, #0x3d8]
    // 0x7ba0f4: stp             xzr, x16, [SP, #-0x10]!
    // 0x7ba0f8: r0 = _GrowableList()
    //     0x7ba0f8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7ba0fc: add             SP, SP, #0x10
    // 0x7ba100: ldur            x1, [fp, #-8]
    // 0x7ba104: StoreField: r1->field_b = r0
    //     0x7ba104: stur            w0, [x1, #0xb]
    //     0x7ba108: ldurb           w16, [x1, #-1]
    //     0x7ba10c: ldurb           w17, [x0, #-1]
    //     0x7ba110: and             x16, x17, x16, lsr #2
    //     0x7ba114: tst             x16, HEAP, lsr #32
    //     0x7ba118: b.eq            #0x7ba120
    //     0x7ba11c: bl              #0xd6826c
    // 0x7ba120: mov             x0, x1
    // 0x7ba124: ldur            x2, [fp, #-0x10]
    // 0x7ba128: StoreField: r2->field_13 = r0
    //     0x7ba128: stur            w0, [x2, #0x13]
    //     0x7ba12c: ldurb           w16, [x2, #-1]
    //     0x7ba130: ldurb           w17, [x0, #-1]
    //     0x7ba134: and             x16, x17, x16, lsr #2
    //     0x7ba138: tst             x16, HEAP, lsr #32
    //     0x7ba13c: b.eq            #0x7ba144
    //     0x7ba140: bl              #0xd6828c
    // 0x7ba144: r0 = 0
    //     0x7ba144: mov             x0, #0
    // 0x7ba148: StoreField: r2->field_b = r0
    //     0x7ba148: stur            x0, [x2, #0xb]
    // 0x7ba14c: r1 = <double>
    //     0x7ba14c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba150: r0 = CurveTween()
    //     0x7ba150: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7ba154: mov             x1, x0
    // 0x7ba158: r0 = Instance_Interval
    //     0x7ba158: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e0f0] Obj!Interval<double>@b4f761
    //     0x7ba15c: ldr             x0, [x0, #0xf0]
    // 0x7ba160: StoreField: r1->field_b = r0
    //     0x7ba160: stur            w0, [x1, #0xb]
    // 0x7ba164: ldr             x16, [fp, #0x10]
    // 0x7ba168: stp             x16, x1, [SP, #-0x10]!
    // 0x7ba16c: r0 = animate()
    //     0x7ba16c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7ba170: add             SP, SP, #0x10
    // 0x7ba174: r1 = <double>
    //     0x7ba174: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7ba178: stur            x0, [fp, #-8]
    // 0x7ba17c: r0 = _AnimationSwap()
    //     0x7ba17c: bl              #0x7b9fe4  ; Allocate_AnimationSwapStub -> _AnimationSwap<X0> (size=0x38)
    // 0x7ba180: mov             x1, x0
    // 0x7ba184: ldr             x0, [fp, #0x10]
    // 0x7ba188: stur            x1, [fp, #-0x18]
    // 0x7ba18c: StoreField: r1->field_2b = r0
    //     0x7ba18c: stur            w0, [x1, #0x2b]
    // 0x7ba190: d0 = 0.500000
    //     0x7ba190: fmov            d0, #0.50000000
    // 0x7ba194: StoreField: r1->field_2f = d0
    //     0x7ba194: stur            d0, [x1, #0x2f]
    // 0x7ba198: ldur            x16, [fp, #-0x10]
    // 0x7ba19c: stp             x16, x1, [SP, #-0x10]!
    // 0x7ba1a0: ldur            x16, [fp, #-8]
    // 0x7ba1a4: SaveReg r16
    //     0x7ba1a4: str             x16, [SP, #-8]!
    // 0x7ba1a8: r0 = CompoundAnimation()
    //     0x7ba1a8: bl              #0x7b9d00  ; [package:flutter/src/animation/animations.dart] CompoundAnimation::CompoundAnimation
    // 0x7ba1ac: add             SP, SP, #0x18
    // 0x7ba1b0: ldur            x0, [fp, #-0x18]
    // 0x7ba1b4: LeaveFrame
    //     0x7ba1b4: mov             SP, fp
    //     0x7ba1b8: ldp             fp, lr, [SP], #0x10
    // 0x7ba1bc: ret
    //     0x7ba1bc: ret             
    // 0x7ba1c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ba1c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ba1c4: b               #0x7ba06c
  }
}

// class id: 2203, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class FloatingActionButtonLocation extends Object {
}

// class id: 2205, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class StandardFabLocation extends FloatingActionButtonLocation {

  _ getOffset(/* No info */) {
    // ** addr: 0xcfa84c, size: 0x84
    // 0xcfa84c: EnterFrame
    //     0xcfa84c: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa850: mov             fp, SP
    // 0xcfa854: AllocStack(0x18)
    //     0xcfa854: sub             SP, SP, #0x18
    // 0xcfa858: CheckStackOverflow
    //     0xcfa858: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa85c: cmp             SP, x16
    //     0xcfa860: b.ls            #0xcfa8c8
    // 0xcfa864: ldr             x16, [fp, #0x18]
    // 0xcfa868: ldr             lr, [fp, #0x10]
    // 0xcfa86c: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa870: SaveReg rZR
    //     0xcfa870: str             xzr, [SP, #-8]!
    // 0xcfa874: r0 = getOffsetX()
    //     0xcfa874: bl              #0xcfabb0  ; [package:flutter/src/material/floating_action_button_location.dart] __EndTopFabLocation&StandardFabLocation&FabEndOffsetX::getOffsetX
    // 0xcfa878: add             SP, SP, #0x18
    // 0xcfa87c: stur            x0, [fp, #-8]
    // 0xcfa880: ldr             x16, [fp, #0x18]
    // 0xcfa884: ldr             lr, [fp, #0x10]
    // 0xcfa888: stp             lr, x16, [SP, #-0x10]!
    // 0xcfa88c: SaveReg rZR
    //     0xcfa88c: str             xzr, [SP, #-8]!
    // 0xcfa890: r0 = getOffsetY()
    //     0xcfa890: bl              #0xcfa8d0  ; [package:flutter/src/material/floating_action_button_location.dart] __EndFloatFabLocation&StandardFabLocation&FabEndOffsetX&FabFloatOffsetY::getOffsetY
    // 0xcfa894: add             SP, SP, #0x18
    // 0xcfa898: ldur            x0, [fp, #-8]
    // 0xcfa89c: stur            d0, [fp, #-0x18]
    // 0xcfa8a0: LoadField: d1 = r0->field_7
    //     0xcfa8a0: ldur            d1, [x0, #7]
    // 0xcfa8a4: stur            d1, [fp, #-0x10]
    // 0xcfa8a8: r0 = Offset()
    //     0xcfa8a8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcfa8ac: ldur            d0, [fp, #-0x10]
    // 0xcfa8b0: StoreField: r0->field_7 = d0
    //     0xcfa8b0: stur            d0, [x0, #7]
    // 0xcfa8b4: ldur            d0, [fp, #-0x18]
    // 0xcfa8b8: StoreField: r0->field_f = d0
    //     0xcfa8b8: stur            d0, [x0, #0xf]
    // 0xcfa8bc: LeaveFrame
    //     0xcfa8bc: mov             SP, fp
    //     0xcfa8c0: ldp             fp, lr, [SP], #0x10
    // 0xcfa8c4: ret
    //     0xcfa8c4: ret             
    // 0xcfa8c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfa8c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfa8cc: b               #0xcfa864
  }
  static _ _rightOffsetX(/* No info */) {
    // ** addr: 0xcfac9c, size: 0x44
    // 0xcfac9c: d1 = 16.000000
    //     0xcfac9c: fmov            d1, #16.00000000
    // 0xcfaca0: ldr             x0, [SP, #8]
    // 0xcfaca4: LoadField: r1 = r0->field_1f
    //     0xcfaca4: ldur            w1, [x0, #0x1f]
    // 0xcfaca8: DecompressPointer r1
    //     0xcfaca8: add             x1, x1, HEAP, lsl #32
    // 0xcfacac: LoadField: d2 = r1->field_7
    //     0xcfacac: ldur            d2, [x1, #7]
    // 0xcfacb0: fsub            d3, d2, d1
    // 0xcfacb4: LoadField: r1 = r0->field_17
    //     0xcfacb4: ldur            w1, [x0, #0x17]
    // 0xcfacb8: DecompressPointer r1
    //     0xcfacb8: add             x1, x1, HEAP, lsl #32
    // 0xcfacbc: LoadField: d1 = r1->field_17
    //     0xcfacbc: ldur            d1, [x1, #0x17]
    // 0xcfacc0: fsub            d2, d3, d1
    // 0xcfacc4: LoadField: r1 = r0->field_7
    //     0xcfacc4: ldur            w1, [x0, #7]
    // 0xcfacc8: DecompressPointer r1
    //     0xcfacc8: add             x1, x1, HEAP, lsl #32
    // 0xcfaccc: LoadField: d1 = r1->field_7
    //     0xcfaccc: ldur            d1, [x1, #7]
    // 0xcfacd0: fsub            d3, d2, d1
    // 0xcfacd4: ldr             d1, [SP]
    // 0xcfacd8: fadd            d0, d3, d1
    // 0xcfacdc: ret
    //     0xcfacdc: ret             
  }
}

// class id: 2206, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class __EndTopFabLocation&StandardFabLocation&FabEndOffsetX extends StandardFabLocation
     with FabEndOffsetX {

  _ getOffsetX(/* No info */) {
    // ** addr: 0xcfabb0, size: 0xec
    // 0xcfabb0: EnterFrame
    //     0xcfabb0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfabb4: mov             fp, SP
    // 0xcfabb8: CheckStackOverflow
    //     0xcfabb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfabbc: cmp             SP, x16
    //     0xcfabc0: b.ls            #0xcfac74
    // 0xcfabc4: ldr             x0, [fp, #0x18]
    // 0xcfabc8: LoadField: r1 = r0->field_27
    //     0xcfabc8: ldur            w1, [x0, #0x27]
    // 0xcfabcc: DecompressPointer r1
    //     0xcfabcc: add             x1, x1, HEAP, lsl #32
    // 0xcfabd0: LoadField: r2 = r1->field_7
    //     0xcfabd0: ldur            x2, [x1, #7]
    // 0xcfabd4: cmp             x2, #0
    // 0xcfabd8: b.gt            #0xcfac2c
    // 0xcfabdc: ldr             d1, [fp, #0x10]
    // 0xcfabe0: d0 = 16.000000
    //     0xcfabe0: fmov            d0, #16.00000000
    // 0xcfabe4: LoadField: r1 = r0->field_17
    //     0xcfabe4: ldur            w1, [x0, #0x17]
    // 0xcfabe8: DecompressPointer r1
    //     0xcfabe8: add             x1, x1, HEAP, lsl #32
    // 0xcfabec: LoadField: d2 = r1->field_7
    //     0xcfabec: ldur            d2, [x1, #7]
    // 0xcfabf0: fadd            d3, d0, d2
    // 0xcfabf4: fsub            d0, d3, d1
    // 0xcfabf8: r0 = inline_Allocate_Double()
    //     0xcfabf8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcfabfc: add             x0, x0, #0x10
    //     0xcfac00: cmp             x1, x0
    //     0xcfac04: b.ls            #0xcfac7c
    //     0xcfac08: str             x0, [THR, #0x60]  ; THR::top
    //     0xcfac0c: sub             x0, x0, #0xf
    //     0xcfac10: mov             x1, #0xd108
    //     0xcfac14: movk            x1, #3, lsl #16
    //     0xcfac18: stur            x1, [x0, #-1]
    // 0xcfac1c: StoreField: r0->field_7 = d0
    //     0xcfac1c: stur            d0, [x0, #7]
    // 0xcfac20: LeaveFrame
    //     0xcfac20: mov             SP, fp
    //     0xcfac24: ldp             fp, lr, [SP], #0x10
    // 0xcfac28: ret
    //     0xcfac28: ret             
    // 0xcfac2c: ldr             d1, [fp, #0x10]
    // 0xcfac30: SaveReg r0
    //     0xcfac30: str             x0, [SP, #-8]!
    // 0xcfac34: SaveReg d1
    //     0xcfac34: str             d1, [SP, #-8]!
    // 0xcfac38: r0 = _rightOffsetX()
    //     0xcfac38: bl              #0xcfac9c  ; [package:flutter/src/material/floating_action_button_location.dart] StandardFabLocation::_rightOffsetX
    // 0xcfac3c: add             SP, SP, #0x10
    // 0xcfac40: r0 = inline_Allocate_Double()
    //     0xcfac40: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcfac44: add             x0, x0, #0x10
    //     0xcfac48: cmp             x1, x0
    //     0xcfac4c: b.ls            #0xcfac8c
    //     0xcfac50: str             x0, [THR, #0x60]  ; THR::top
    //     0xcfac54: sub             x0, x0, #0xf
    //     0xcfac58: mov             x1, #0xd108
    //     0xcfac5c: movk            x1, #3, lsl #16
    //     0xcfac60: stur            x1, [x0, #-1]
    // 0xcfac64: StoreField: r0->field_7 = d0
    //     0xcfac64: stur            d0, [x0, #7]
    // 0xcfac68: LeaveFrame
    //     0xcfac68: mov             SP, fp
    //     0xcfac6c: ldp             fp, lr, [SP], #0x10
    // 0xcfac70: ret
    //     0xcfac70: ret             
    // 0xcfac74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcfac74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcfac78: b               #0xcfabc4
    // 0xcfac7c: SaveReg d0
    //     0xcfac7c: str             q0, [SP, #-0x10]!
    // 0xcfac80: r0 = AllocateDouble()
    //     0xcfac80: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcfac84: RestoreReg d0
    //     0xcfac84: ldr             q0, [SP], #0x10
    // 0xcfac88: b               #0xcfac1c
    // 0xcfac8c: SaveReg d0
    //     0xcfac8c: str             q0, [SP, #-0x10]!
    // 0xcfac90: r0 = AllocateDouble()
    //     0xcfac90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcfac94: RestoreReg d0
    //     0xcfac94: ldr             q0, [SP], #0x10
    // 0xcfac98: b               #0xcfac64
  }
}

// class id: 2207, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class __EndFloatFabLocation&StandardFabLocation&FabEndOffsetX&FabFloatOffsetY extends __EndTopFabLocation&StandardFabLocation&FabEndOffsetX
     with FabFloatOffsetY {

  _ getOffsetY(/* No info */) {
    // ** addr: 0xcfa8d0, size: 0x2e0
    // 0xcfa8d0: EnterFrame
    //     0xcfa8d0: stp             fp, lr, [SP, #-0x10]!
    //     0xcfa8d4: mov             fp, SP
    // 0xcfa8d8: AllocStack(0x28)
    //     0xcfa8d8: sub             SP, SP, #0x28
    // 0xcfa8dc: d0 = 16.000000
    //     0xcfa8dc: fmov            d0, #16.00000000
    // 0xcfa8e0: CheckStackOverflow
    //     0xcfa8e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcfa8e4: cmp             SP, x16
    //     0xcfa8e8: b.ls            #0xcfab78
    // 0xcfa8ec: ldr             x0, [fp, #0x18]
    // 0xcfa8f0: LoadField: d1 = r0->field_f
    //     0xcfa8f0: ldur            d1, [x0, #0xf]
    // 0xcfa8f4: stur            d1, [fp, #-0x28]
    // 0xcfa8f8: LoadField: r1 = r0->field_1f
    //     0xcfa8f8: ldur            w1, [x0, #0x1f]
    // 0xcfa8fc: DecompressPointer r1
    //     0xcfa8fc: add             x1, x1, HEAP, lsl #32
    // 0xcfa900: LoadField: d2 = r1->field_f
    //     0xcfa900: ldur            d2, [x1, #0xf]
    // 0xcfa904: fsub            d3, d2, d1
    // 0xcfa908: LoadField: r1 = r0->field_b
    //     0xcfa908: ldur            w1, [x0, #0xb]
    // 0xcfa90c: DecompressPointer r1
    //     0xcfa90c: add             x1, x1, HEAP, lsl #32
    // 0xcfa910: LoadField: d2 = r1->field_f
    //     0xcfa910: ldur            d2, [x1, #0xf]
    // 0xcfa914: stur            d2, [fp, #-0x20]
    // 0xcfa918: LoadField: r1 = r0->field_7
    //     0xcfa918: ldur            w1, [x0, #7]
    // 0xcfa91c: DecompressPointer r1
    //     0xcfa91c: add             x1, x1, HEAP, lsl #32
    // 0xcfa920: LoadField: d4 = r1->field_f
    //     0xcfa920: ldur            d4, [x1, #0xf]
    // 0xcfa924: stur            d4, [fp, #-0x18]
    // 0xcfa928: LoadField: r1 = r0->field_23
    //     0xcfa928: ldur            w1, [x0, #0x23]
    // 0xcfa92c: DecompressPointer r1
    //     0xcfa92c: add             x1, x1, HEAP, lsl #32
    // 0xcfa930: LoadField: d5 = r1->field_f
    //     0xcfa930: ldur            d5, [x1, #0xf]
    // 0xcfa934: LoadField: r1 = r0->field_1b
    //     0xcfa934: ldur            w1, [x0, #0x1b]
    // 0xcfa938: DecompressPointer r1
    //     0xcfa938: add             x1, x1, HEAP, lsl #32
    // 0xcfa93c: LoadField: d6 = r1->field_1f
    //     0xcfa93c: ldur            d6, [x1, #0x1f]
    // 0xcfa940: fsub            d7, d6, d3
    // 0xcfa944: fadd            d3, d7, d0
    // 0xcfa948: fcmp            d0, d3
    // 0xcfa94c: b.vs            #0xcfa960
    // 0xcfa950: b.le            #0xcfa960
    // 0xcfa954: d3 = 16.000000
    //     0xcfa954: fmov            d3, #16.00000000
    // 0xcfa958: d6 = 0.000000
    //     0xcfa958: eor             v6.16b, v6.16b, v6.16b
    // 0xcfa95c: b               #0xcfa99c
    // 0xcfa960: fcmp            d0, d3
    // 0xcfa964: b.vs            #0xcfa974
    // 0xcfa968: b.ge            #0xcfa974
    // 0xcfa96c: d6 = 0.000000
    //     0xcfa96c: eor             v6.16b, v6.16b, v6.16b
    // 0xcfa970: b               #0xcfa99c
    // 0xcfa974: d6 = 0.000000
    //     0xcfa974: eor             v6.16b, v6.16b, v6.16b
    // 0xcfa978: fcmp            d0, d6
    // 0xcfa97c: b.vs            #0xcfa990
    // 0xcfa980: b.ne            #0xcfa990
    // 0xcfa984: fadd            d7, d0, d3
    // 0xcfa988: mov             v3.16b, v7.16b
    // 0xcfa98c: b               #0xcfa99c
    // 0xcfa990: fcmp            d3, d3
    // 0xcfa994: b.vs            #0xcfa99c
    // 0xcfa998: d3 = 16.000000
    //     0xcfa998: fmov            d3, #16.00000000
    // 0xcfa99c: fsub            d7, d1, d4
    // 0xcfa9a0: fsub            d8, d7, d3
    // 0xcfa9a4: stur            d8, [fp, #-0x10]
    // 0xcfa9a8: fcmp            d5, d6
    // 0xcfa9ac: b.vs            #0xcfaa74
    // 0xcfa9b0: b.le            #0xcfaa74
    // 0xcfa9b4: fsub            d3, d1, d5
    // 0xcfa9b8: fsub            d5, d3, d4
    // 0xcfa9bc: fsub            d3, d5, d0
    // 0xcfa9c0: stur            d3, [fp, #-8]
    // 0xcfa9c4: fcmp            d8, d3
    // 0xcfa9c8: b.vs            #0xcfa9d8
    // 0xcfa9cc: b.le            #0xcfa9d8
    // 0xcfa9d0: mov             v0.16b, v3.16b
    // 0xcfa9d4: b               #0xcfaa6c
    // 0xcfa9d8: fcmp            d8, d3
    // 0xcfa9dc: b.vs            #0xcfa9ec
    // 0xcfa9e0: b.ge            #0xcfa9ec
    // 0xcfa9e4: mov             v0.16b, v8.16b
    // 0xcfa9e8: b               #0xcfaa6c
    // 0xcfa9ec: fcmp            d8, d6
    // 0xcfa9f0: b.vs            #0xcfa9f8
    // 0xcfa9f4: b.eq            #0xcfaa00
    // 0xcfa9f8: r0 = false
    //     0xcfa9f8: add             x0, NULL, #0x30  ; false
    // 0xcfa9fc: b               #0xcfaa04
    // 0xcfaa00: r0 = true
    //     0xcfaa00: add             x0, NULL, #0x20  ; true
    // 0xcfaa04: tbnz            w0, #4, #0xcfaa18
    // 0xcfaa08: fadd            d0, d8, d3
    // 0xcfaa0c: fmul            d5, d0, d8
    // 0xcfaa10: fmul            d0, d5, d3
    // 0xcfaa14: b               #0xcfaa6c
    // 0xcfaa18: tbnz            w0, #4, #0xcfaa5c
    // 0xcfaa1c: r0 = inline_Allocate_Double()
    //     0xcfaa1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcfaa20: add             x0, x0, #0x10
    //     0xcfaa24: cmp             x1, x0
    //     0xcfaa28: b.ls            #0xcfab80
    //     0xcfaa2c: str             x0, [THR, #0x60]  ; THR::top
    //     0xcfaa30: sub             x0, x0, #0xf
    //     0xcfaa34: mov             x1, #0xd108
    //     0xcfaa38: movk            x1, #3, lsl #16
    //     0xcfaa3c: stur            x1, [x0, #-1]
    // 0xcfaa40: StoreField: r0->field_7 = d3
    //     0xcfaa40: stur            d3, [x0, #7]
    // 0xcfaa44: SaveReg r0
    //     0xcfaa44: str             x0, [SP, #-8]!
    // 0xcfaa48: r0 = isNegative()
    //     0xcfaa48: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xcfaa4c: add             SP, SP, #8
    // 0xcfaa50: tbnz            w0, #4, #0xcfaa5c
    // 0xcfaa54: ldur            d0, [fp, #-8]
    // 0xcfaa58: b               #0xcfaa6c
    // 0xcfaa5c: ldur            d0, [fp, #-8]
    // 0xcfaa60: fcmp            d0, d0
    // 0xcfaa64: b.vs            #0xcfaa6c
    // 0xcfaa68: ldur            d0, [fp, #-0x10]
    // 0xcfaa6c: mov             v2.16b, v0.16b
    // 0xcfaa70: b               #0xcfaa78
    // 0xcfaa74: ldur            d2, [fp, #-0x10]
    // 0xcfaa78: ldur            d0, [fp, #-0x20]
    // 0xcfaa7c: d1 = 0.000000
    //     0xcfaa7c: eor             v1.16b, v1.16b, v1.16b
    // 0xcfaa80: stur            d2, [fp, #-0x10]
    // 0xcfaa84: fcmp            d0, d1
    // 0xcfaa88: b.vs            #0xcfab60
    // 0xcfaa8c: b.le            #0xcfab60
    // 0xcfaa90: ldur            d3, [fp, #-0x28]
    // 0xcfaa94: ldur            d4, [fp, #-0x18]
    // 0xcfaa98: d5 = 2.000000
    //     0xcfaa98: fmov            d5, #2.00000000
    // 0xcfaa9c: fsub            d6, d3, d0
    // 0xcfaaa0: fdiv            d0, d4, d5
    // 0xcfaaa4: fsub            d3, d6, d0
    // 0xcfaaa8: stur            d3, [fp, #-8]
    // 0xcfaaac: fcmp            d2, d3
    // 0xcfaab0: b.vs            #0xcfaac0
    // 0xcfaab4: b.le            #0xcfaac0
    // 0xcfaab8: mov             v1.16b, v3.16b
    // 0xcfaabc: b               #0xcfab58
    // 0xcfaac0: fcmp            d2, d3
    // 0xcfaac4: b.vs            #0xcfaad4
    // 0xcfaac8: b.ge            #0xcfaad4
    // 0xcfaacc: mov             v1.16b, v2.16b
    // 0xcfaad0: b               #0xcfab58
    // 0xcfaad4: fcmp            d2, d1
    // 0xcfaad8: b.vs            #0xcfaae0
    // 0xcfaadc: b.eq            #0xcfaae8
    // 0xcfaae0: r0 = false
    //     0xcfaae0: add             x0, NULL, #0x30  ; false
    // 0xcfaae4: b               #0xcfaaec
    // 0xcfaae8: r0 = true
    //     0xcfaae8: add             x0, NULL, #0x20  ; true
    // 0xcfaaec: tbnz            w0, #4, #0xcfab04
    // 0xcfaaf0: fadd            d0, d2, d3
    // 0xcfaaf4: fmul            d1, d0, d2
    // 0xcfaaf8: fmul            d0, d1, d3
    // 0xcfaafc: mov             v1.16b, v0.16b
    // 0xcfab00: b               #0xcfab58
    // 0xcfab04: tbnz            w0, #4, #0xcfab48
    // 0xcfab08: r0 = inline_Allocate_Double()
    //     0xcfab08: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcfab0c: add             x0, x0, #0x10
    //     0xcfab10: cmp             x1, x0
    //     0xcfab14: b.ls            #0xcfaba0
    //     0xcfab18: str             x0, [THR, #0x60]  ; THR::top
    //     0xcfab1c: sub             x0, x0, #0xf
    //     0xcfab20: mov             x1, #0xd108
    //     0xcfab24: movk            x1, #3, lsl #16
    //     0xcfab28: stur            x1, [x0, #-1]
    // 0xcfab2c: StoreField: r0->field_7 = d3
    //     0xcfab2c: stur            d3, [x0, #7]
    // 0xcfab30: SaveReg r0
    //     0xcfab30: str             x0, [SP, #-8]!
    // 0xcfab34: r0 = isNegative()
    //     0xcfab34: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0xcfab38: add             SP, SP, #8
    // 0xcfab3c: tbnz            w0, #4, #0xcfab48
    // 0xcfab40: ldur            d1, [fp, #-8]
    // 0xcfab44: b               #0xcfab58
    // 0xcfab48: ldur            d1, [fp, #-8]
    // 0xcfab4c: fcmp            d1, d1
    // 0xcfab50: b.vs            #0xcfab58
    // 0xcfab54: ldur            d1, [fp, #-0x10]
    // 0xcfab58: mov             v2.16b, v1.16b
    // 0xcfab5c: b               #0xcfab64
    // 0xcfab60: ldur            d2, [fp, #-0x10]
    // 0xcfab64: ldr             d1, [fp, #0x10]
    // 0xcfab68: fadd            d0, d2, d1
    // 0xcfab6c: LeaveFrame
    //     0xcfab6c: mov             SP, fp
    //     0xcfab70: ldp             fp, lr, [SP], #0x10
    // 0xcfab74: ret
    //     0xcfab74: ret             
    // 0xcfab78: r0 = StackOverflowSharedWithFPURegs()
    //     0xcfab78: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcfab7c: b               #0xcfa8ec
    // 0xcfab80: stp             q6, q8, [SP, #-0x20]!
    // 0xcfab84: stp             q3, q4, [SP, #-0x20]!
    // 0xcfab88: stp             q1, q2, [SP, #-0x20]!
    // 0xcfab8c: r0 = AllocateDouble()
    //     0xcfab8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcfab90: ldp             q1, q2, [SP], #0x20
    // 0xcfab94: ldp             q3, q4, [SP], #0x20
    // 0xcfab98: ldp             q6, q8, [SP], #0x20
    // 0xcfab9c: b               #0xcfaa40
    // 0xcfaba0: stp             q2, q3, [SP, #-0x20]!
    // 0xcfaba4: r0 = AllocateDouble()
    //     0xcfaba4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcfaba8: ldp             q2, q3, [SP], #0x20
    // 0xcfabac: b               #0xcfab2c
  }
}

// class id: 2208, size: 0x8, field offset: 0x8
//   const constructor, 
class _EndFloatFabLocation extends __EndFloatFabLocation&StandardFabLocation&FabEndOffsetX&FabFloatOffsetY {

  _ toString(/* No info */) {
    // ** addr: 0xada62c, size: 0xc
    // 0xada62c: r0 = "FloatingActionButtonLocation.endFloat"
    //     0xada62c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c18] "FloatingActionButtonLocation.endFloat"
    //     0xada630: ldr             x0, [x0, #0xc18]
    // 0xada634: ret
    //     0xada634: ret             
  }
}

// class id: 2209, size: 0x8, field offset: 0x8
abstract class FabEndOffsetX extends StandardFabLocation {
}

// class id: 2210, size: 0x8, field offset: 0x8
abstract class FabFloatOffsetY extends StandardFabLocation {
}

// class id: 4334, size: 0x38, field offset: 0x2c
class _AnimationSwap<X0> extends CompoundAnimation<X0> {

  get _ value(/* No info */) {
    // ** addr: 0xc250a0, size: 0xb4
    // 0xc250a0: EnterFrame
    //     0xc250a0: stp             fp, lr, [SP, #-0x10]!
    //     0xc250a4: mov             fp, SP
    // 0xc250a8: d0 = 0.500000
    //     0xc250a8: fmov            d0, #0.50000000
    // 0xc250ac: CheckStackOverflow
    //     0xc250ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc250b0: cmp             SP, x16
    //     0xc250b4: b.ls            #0xc25140
    // 0xc250b8: ldr             x0, [fp, #0x10]
    // 0xc250bc: LoadField: r1 = r0->field_2b
    //     0xc250bc: ldur            w1, [x0, #0x2b]
    // 0xc250c0: DecompressPointer r1
    //     0xc250c0: add             x1, x1, HEAP, lsl #32
    // 0xc250c4: LoadField: r2 = r1->field_37
    //     0xc250c4: ldur            w2, [x1, #0x37]
    // 0xc250c8: DecompressPointer r2
    //     0xc250c8: add             x2, x2, HEAP, lsl #32
    // 0xc250cc: r16 = Sentinel
    //     0xc250cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc250d0: cmp             w2, w16
    // 0xc250d4: b.eq            #0xc25148
    // 0xc250d8: LoadField: d1 = r2->field_7
    //     0xc250d8: ldur            d1, [x2, #7]
    // 0xc250dc: fcmp            d1, d0
    // 0xc250e0: b.vs            #0xc25110
    // 0xc250e4: b.ge            #0xc25110
    // 0xc250e8: LoadField: r1 = r0->field_1b
    //     0xc250e8: ldur            w1, [x0, #0x1b]
    // 0xc250ec: DecompressPointer r1
    //     0xc250ec: add             x1, x1, HEAP, lsl #32
    // 0xc250f0: r0 = LoadClassIdInstr(r1)
    //     0xc250f0: ldur            x0, [x1, #-1]
    //     0xc250f4: ubfx            x0, x0, #0xc, #0x14
    // 0xc250f8: SaveReg r1
    //     0xc250f8: str             x1, [SP, #-8]!
    // 0xc250fc: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc250fc: add             lr, x0, #0xb7c
    //     0xc25100: ldr             lr, [x21, lr, lsl #3]
    //     0xc25104: blr             lr
    // 0xc25108: add             SP, SP, #8
    // 0xc2510c: b               #0xc25134
    // 0xc25110: LoadField: r1 = r0->field_1f
    //     0xc25110: ldur            w1, [x0, #0x1f]
    // 0xc25114: DecompressPointer r1
    //     0xc25114: add             x1, x1, HEAP, lsl #32
    // 0xc25118: r0 = LoadClassIdInstr(r1)
    //     0xc25118: ldur            x0, [x1, #-1]
    //     0xc2511c: ubfx            x0, x0, #0xc, #0x14
    // 0xc25120: SaveReg r1
    //     0xc25120: str             x1, [SP, #-8]!
    // 0xc25124: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xc25124: add             lr, x0, #0xb7c
    //     0xc25128: ldr             lr, [x21, lr, lsl #3]
    //     0xc2512c: blr             lr
    // 0xc25130: add             SP, SP, #8
    // 0xc25134: LeaveFrame
    //     0xc25134: mov             SP, fp
    //     0xc25138: ldp             fp, lr, [SP], #0x10
    // 0xc2513c: ret
    //     0xc2513c: ret             
    // 0xc25140: r0 = StackOverflowSharedWithFPURegs()
    //     0xc25140: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc25144: b               #0xc250b8
    // 0xc25148: r9 = _value
    //     0xc25148: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xc2514c: ldr             x9, [x9, #0xbb0]
    // 0xc25150: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xc25150: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
}

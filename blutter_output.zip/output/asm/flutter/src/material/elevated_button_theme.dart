// lib: , url: package:flutter/src/material/elevated_button_theme.dart

// class id: 1049234, size: 0x8
class :: {
}

// class id: 2803, size: 0xc, field offset: 0x8
//   const constructor, 
class ElevatedButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf4b24, size: 0x68
    // 0xbf4b24: EnterFrame
    //     0xbf4b24: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4b28: mov             fp, SP
    // 0xbf4b2c: AllocStack(0x8)
    //     0xbf4b2c: sub             SP, SP, #8
    // 0xbf4b30: CheckStackOverflow
    //     0xbf4b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4b34: cmp             SP, x16
    //     0xbf4b38: b.ls            #0xbf4b84
    // 0xbf4b3c: ldr             x0, [fp, #0x20]
    // 0xbf4b40: LoadField: r1 = r0->field_7
    //     0xbf4b40: ldur            w1, [x0, #7]
    // 0xbf4b44: DecompressPointer r1
    //     0xbf4b44: add             x1, x1, HEAP, lsl #32
    // 0xbf4b48: ldr             x0, [fp, #0x18]
    // 0xbf4b4c: LoadField: r2 = r0->field_7
    //     0xbf4b4c: ldur            w2, [x0, #7]
    // 0xbf4b50: DecompressPointer r2
    //     0xbf4b50: add             x2, x2, HEAP, lsl #32
    // 0xbf4b54: stp             x2, x1, [SP, #-0x10]!
    // 0xbf4b58: ldr             d0, [fp, #0x10]
    // 0xbf4b5c: SaveReg d0
    //     0xbf4b5c: str             d0, [SP, #-8]!
    // 0xbf4b60: r0 = lerp()
    //     0xbf4b60: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbf4b64: add             SP, SP, #0x18
    // 0xbf4b68: stur            x0, [fp, #-8]
    // 0xbf4b6c: r0 = ElevatedButtonThemeData()
    //     0xbf4b6c: bl              #0xbf4b8c  ; AllocateElevatedButtonThemeDataStub -> ElevatedButtonThemeData (size=0xc)
    // 0xbf4b70: ldur            x1, [fp, #-8]
    // 0xbf4b74: StoreField: r0->field_7 = r1
    //     0xbf4b74: stur            w1, [x0, #7]
    // 0xbf4b78: LeaveFrame
    //     0xbf4b78: mov             SP, fp
    //     0xbf4b7c: ldp             fp, lr, [SP], #0x10
    // 0xbf4b80: ret
    //     0xbf4b80: ret             
    // 0xbf4b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf4b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4b88: b               #0xbf4b3c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc88970, size: 0x124
    // 0xc88970: EnterFrame
    //     0xc88970: stp             fp, lr, [SP, #-0x10]!
    //     0xc88974: mov             fp, SP
    // 0xc88978: CheckStackOverflow
    //     0xc88978: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8897c: cmp             SP, x16
    //     0xc88980: b.ls            #0xc88a8c
    // 0xc88984: ldr             x1, [fp, #0x10]
    // 0xc88988: cmp             w1, NULL
    // 0xc8898c: b.ne            #0xc889a0
    // 0xc88990: r0 = false
    //     0xc88990: add             x0, NULL, #0x30  ; false
    // 0xc88994: LeaveFrame
    //     0xc88994: mov             SP, fp
    //     0xc88998: ldp             fp, lr, [SP], #0x10
    // 0xc8899c: ret
    //     0xc8899c: ret             
    // 0xc889a0: ldr             x2, [fp, #0x18]
    // 0xc889a4: cmp             w2, w1
    // 0xc889a8: b.ne            #0xc889bc
    // 0xc889ac: r0 = true
    //     0xc889ac: add             x0, NULL, #0x20  ; true
    // 0xc889b0: LeaveFrame
    //     0xc889b0: mov             SP, fp
    //     0xc889b4: ldp             fp, lr, [SP], #0x10
    // 0xc889b8: ret
    //     0xc889b8: ret             
    // 0xc889bc: r0 = 59
    //     0xc889bc: mov             x0, #0x3b
    // 0xc889c0: branchIfSmi(r1, 0xc889cc)
    //     0xc889c0: tbz             w1, #0, #0xc889cc
    // 0xc889c4: r0 = LoadClassIdInstr(r1)
    //     0xc889c4: ldur            x0, [x1, #-1]
    //     0xc889c8: ubfx            x0, x0, #0xc, #0x14
    // 0xc889cc: SaveReg r1
    //     0xc889cc: str             x1, [SP, #-8]!
    // 0xc889d0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc889d0: mov             x17, #0x57c5
    //     0xc889d4: add             lr, x0, x17
    //     0xc889d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc889dc: blr             lr
    // 0xc889e0: add             SP, SP, #8
    // 0xc889e4: r1 = LoadClassIdInstr(r0)
    //     0xc889e4: ldur            x1, [x0, #-1]
    //     0xc889e8: ubfx            x1, x1, #0xc, #0x14
    // 0xc889ec: r16 = ElevatedButtonThemeData
    //     0xc889ec: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3a0] Type: ElevatedButtonThemeData
    //     0xc889f0: ldr             x16, [x16, #0x3a0]
    // 0xc889f4: stp             x16, x0, [SP, #-0x10]!
    // 0xc889f8: mov             x0, x1
    // 0xc889fc: mov             lr, x0
    // 0xc88a00: ldr             lr, [x21, lr, lsl #3]
    // 0xc88a04: blr             lr
    // 0xc88a08: add             SP, SP, #0x10
    // 0xc88a0c: tbz             w0, #4, #0xc88a20
    // 0xc88a10: r0 = false
    //     0xc88a10: add             x0, NULL, #0x30  ; false
    // 0xc88a14: LeaveFrame
    //     0xc88a14: mov             SP, fp
    //     0xc88a18: ldp             fp, lr, [SP], #0x10
    // 0xc88a1c: ret
    //     0xc88a1c: ret             
    // 0xc88a20: ldr             x0, [fp, #0x10]
    // 0xc88a24: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc88a24: mov             x1, #0x76
    //     0xc88a28: tbz             w0, #0, #0xc88a38
    //     0xc88a2c: ldur            x1, [x0, #-1]
    //     0xc88a30: ubfx            x1, x1, #0xc, #0x14
    //     0xc88a34: lsl             x1, x1, #1
    // 0xc88a38: r17 = 5606
    //     0xc88a38: mov             x17, #0x15e6
    // 0xc88a3c: cmp             w1, w17
    // 0xc88a40: b.ne            #0xc88a7c
    // 0xc88a44: ldr             x1, [fp, #0x18]
    // 0xc88a48: LoadField: r2 = r0->field_7
    //     0xc88a48: ldur            w2, [x0, #7]
    // 0xc88a4c: DecompressPointer r2
    //     0xc88a4c: add             x2, x2, HEAP, lsl #32
    // 0xc88a50: LoadField: r0 = r1->field_7
    //     0xc88a50: ldur            w0, [x1, #7]
    // 0xc88a54: DecompressPointer r0
    //     0xc88a54: add             x0, x0, HEAP, lsl #32
    // 0xc88a58: r1 = LoadClassIdInstr(r2)
    //     0xc88a58: ldur            x1, [x2, #-1]
    //     0xc88a5c: ubfx            x1, x1, #0xc, #0x14
    // 0xc88a60: stp             x0, x2, [SP, #-0x10]!
    // 0xc88a64: mov             x0, x1
    // 0xc88a68: mov             lr, x0
    // 0xc88a6c: ldr             lr, [x21, lr, lsl #3]
    // 0xc88a70: blr             lr
    // 0xc88a74: add             SP, SP, #0x10
    // 0xc88a78: b               #0xc88a80
    // 0xc88a7c: r0 = false
    //     0xc88a7c: add             x0, NULL, #0x30  ; false
    // 0xc88a80: LeaveFrame
    //     0xc88a80: mov             SP, fp
    //     0xc88a84: ldp             fp, lr, [SP], #0x10
    // 0xc88a88: ret
    //     0xc88a88: ret             
    // 0xc88a8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc88a8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc88a90: b               #0xc88984
  }
}

// class id: 3546, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ElevatedButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xc121c8, size: 0x60
    // 0xc121c8: EnterFrame
    //     0xc121c8: stp             fp, lr, [SP, #-0x10]!
    //     0xc121cc: mov             fp, SP
    // 0xc121d0: CheckStackOverflow
    //     0xc121d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc121d4: cmp             SP, x16
    //     0xc121d8: b.ls            #0xc12220
    // 0xc121dc: r16 = <ElevatedButtonTheme>
    //     0xc121dc: add             x16, PP, #0x37, lsl #12  ; [pp+0x37908] TypeArguments: <ElevatedButtonTheme>
    //     0xc121e0: ldr             x16, [x16, #0x908]
    // 0xc121e4: ldr             lr, [fp, #0x10]
    // 0xc121e8: stp             lr, x16, [SP, #-0x10]!
    // 0xc121ec: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc121ec: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc121f0: r0 = dependOnInheritedWidgetOfExactType()
    //     0xc121f0: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xc121f4: add             SP, SP, #0x10
    // 0xc121f8: ldr             x16, [fp, #0x10]
    // 0xc121fc: SaveReg r16
    //     0xc121fc: str             x16, [SP, #-8]!
    // 0xc12200: r0 = of()
    //     0xc12200: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc12204: add             SP, SP, #8
    // 0xc12208: LoadField: r1 = r0->field_db
    //     0xc12208: ldur            w1, [x0, #0xdb]
    // 0xc1220c: DecompressPointer r1
    //     0xc1220c: add             x1, x1, HEAP, lsl #32
    // 0xc12210: mov             x0, x1
    // 0xc12214: LeaveFrame
    //     0xc12214: mov             SP, fp
    //     0xc12218: ldp             fp, lr, [SP], #0x10
    // 0xc1221c: ret
    //     0xc1221c: ret             
    // 0xc12220: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc12220: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc12224: b               #0xc121dc
  }
}

// lib: , url: package:flutter/src/material/slider_theme.dart

// class id: 1049310, size: 0x8
class :: {
}

// class id: 2129, size: 0x8, field offset: 0x8
abstract class BaseSliderTrackShape extends Object {
}

// class id: 2134, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliderTrackShape extends Object {
}

// class id: 2135, size: 0x8, field offset: 0x8
//   const constructor, transformed mixin,
abstract class _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape extends SliderTrackShape
     with BaseSliderTrackShape {

  _ getPreferredRect(/* No info */) {
    // ** addr: 0x66c534, size: 0x3d8
    // 0x66c534: EnterFrame
    //     0x66c534: stp             fp, lr, [SP, #-0x10]!
    //     0x66c538: mov             fp, SP
    // 0x66c53c: AllocStack(0x48)
    //     0x66c53c: sub             SP, SP, #0x48
    // 0x66c540: SetupParameters(_RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, {dynamic isEnabled = false /* r5, fp-0x10 */, dynamic offset = Instance_Offset /* r0, fp-0x8 */})
    //     0x66c540: mov             x0, x4
    //     0x66c544: ldur            w1, [x0, #0x13]
    //     0x66c548: add             x1, x1, HEAP, lsl #32
    //     0x66c54c: sub             x2, x1, #6
    //     0x66c550: add             x3, fp, w2, sxtw #2
    //     0x66c554: ldr             x3, [x3, #0x18]
    //     0x66c558: stur            x3, [fp, #-0x20]
    //     0x66c55c: add             x4, fp, w2, sxtw #2
    //     0x66c560: ldr             x4, [x4, #0x10]
    //     0x66c564: stur            x4, [fp, #-0x18]
    //     0x66c568: ldur            w2, [x0, #0x1f]
    //     0x66c56c: add             x2, x2, HEAP, lsl #32
    //     0x66c570: add             x16, PP, #0x56, lsl #12  ; [pp+0x56470] "isEnabled"
    //     0x66c574: ldr             x16, [x16, #0x470]
    //     0x66c578: cmp             w2, w16
    //     0x66c57c: b.ne            #0x66c5a0
    //     0x66c580: ldur            w2, [x0, #0x23]
    //     0x66c584: add             x2, x2, HEAP, lsl #32
    //     0x66c588: sub             w5, w1, w2
    //     0x66c58c: add             x2, fp, w5, sxtw #2
    //     0x66c590: ldr             x2, [x2, #8]
    //     0x66c594: mov             x5, x2
    //     0x66c598: mov             x2, #1
    //     0x66c59c: b               #0x66c5a8
    //     0x66c5a0: add             x5, NULL, #0x30  ; false
    //     0x66c5a4: mov             x2, #0
    //     0x66c5a8: stur            x5, [fp, #-0x10]
    //     0x66c5ac: lsl             x6, x2, #1
    //     0x66c5b0: lsl             w2, w6, #1
    //     0x66c5b4: add             w6, w2, #8
    //     0x66c5b8: add             x16, x0, w6, sxtw #1
    //     0x66c5bc: ldur            w7, [x16, #0xf]
    //     0x66c5c0: add             x7, x7, HEAP, lsl #32
    //     0x66c5c4: add             x16, PP, #0x35, lsl #12  ; [pp+0x35530] "offset"
    //     0x66c5c8: ldr             x16, [x16, #0x530]
    //     0x66c5cc: cmp             w7, w16
    //     0x66c5d0: b.ne            #0x66c5f8
    //     0x66c5d4: add             w6, w2, #0xa
    //     0x66c5d8: add             x16, x0, w6, sxtw #1
    //     0x66c5dc: ldur            w2, [x16, #0xf]
    //     0x66c5e0: add             x2, x2, HEAP, lsl #32
    //     0x66c5e4: sub             w0, w1, w2
    //     0x66c5e8: add             x1, fp, w0, sxtw #2
    //     0x66c5ec: ldr             x1, [x1, #8]
    //     0x66c5f0: mov             x0, x1
    //     0x66c5f4: b               #0x66c5fc
    //     0x66c5f8: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    //     0x66c5fc: stur            x0, [fp, #-8]
    // 0x66c600: CheckStackOverflow
    //     0x66c600: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66c604: cmp             SP, x16
    //     0x66c608: b.ls            #0x66c8d4
    // 0x66c60c: LoadField: r1 = r4->field_4f
    //     0x66c60c: ldur            w1, [x4, #0x4f]
    // 0x66c610: DecompressPointer r1
    //     0x66c610: add             x1, x1, HEAP, lsl #32
    // 0x66c614: cmp             w1, NULL
    // 0x66c618: b.eq            #0x66c8dc
    // 0x66c61c: stp             x5, x1, [SP, #-0x10]!
    // 0x66c620: r0 = getPreferredSize()
    //     0x66c620: bl              #0x6314ac  ; [package:flutter/src/material/slider_theme.dart] RoundSliderThumbShape::getPreferredSize
    // 0x66c624: add             SP, SP, #0x10
    // 0x66c628: LoadField: d0 = r0->field_7
    //     0x66c628: ldur            d0, [x0, #7]
    // 0x66c62c: ldur            x0, [fp, #-0x18]
    // 0x66c630: stur            d0, [fp, #-0x28]
    // 0x66c634: LoadField: r1 = r0->field_47
    //     0x66c634: ldur            w1, [x0, #0x47]
    // 0x66c638: DecompressPointer r1
    //     0x66c638: add             x1, x1, HEAP, lsl #32
    // 0x66c63c: cmp             w1, NULL
    // 0x66c640: b.eq            #0x66c8e0
    // 0x66c644: ldur            x16, [fp, #-0x10]
    // 0x66c648: stp             x16, x1, [SP, #-0x10]!
    // 0x66c64c: r0 = getPreferredSize()
    //     0x66c64c: bl              #0x6314d0  ; [package:flutter/src/material/slider_theme.dart] RoundSliderOverlayShape::getPreferredSize
    // 0x66c650: add             SP, SP, #0x10
    // 0x66c654: LoadField: d0 = r0->field_7
    //     0x66c654: ldur            d0, [x0, #7]
    // 0x66c658: ldur            x0, [fp, #-0x18]
    // 0x66c65c: LoadField: r1 = r0->field_7
    //     0x66c65c: ldur            w1, [x0, #7]
    // 0x66c660: DecompressPointer r1
    //     0x66c660: add             x1, x1, HEAP, lsl #32
    // 0x66c664: cmp             w1, NULL
    // 0x66c668: b.eq            #0x66c8e4
    // 0x66c66c: ldur            x0, [fp, #-8]
    // 0x66c670: LoadField: d1 = r0->field_7
    //     0x66c670: ldur            d1, [x0, #7]
    // 0x66c674: d2 = 2.000000
    //     0x66c674: fmov            d2, #2.00000000
    // 0x66c678: fdiv            d3, d0, d2
    // 0x66c67c: ldur            d4, [fp, #-0x28]
    // 0x66c680: fdiv            d5, d4, d2
    // 0x66c684: fcmp            d3, d5
    // 0x66c688: b.vs            #0x66c698
    // 0x66c68c: b.le            #0x66c698
    // 0x66c690: d6 = 0.000000
    //     0x66c690: eor             v6.16b, v6.16b, v6.16b
    // 0x66c694: b               #0x66c6d8
    // 0x66c698: fcmp            d3, d5
    // 0x66c69c: b.vs            #0x66c6b0
    // 0x66c6a0: b.ge            #0x66c6b0
    // 0x66c6a4: mov             v3.16b, v5.16b
    // 0x66c6a8: d6 = 0.000000
    //     0x66c6a8: eor             v6.16b, v6.16b, v6.16b
    // 0x66c6ac: b               #0x66c6d8
    // 0x66c6b0: d6 = 0.000000
    //     0x66c6b0: eor             v6.16b, v6.16b, v6.16b
    // 0x66c6b4: fcmp            d3, d6
    // 0x66c6b8: b.vs            #0x66c6cc
    // 0x66c6bc: b.ne            #0x66c6cc
    // 0x66c6c0: fadd            d7, d3, d5
    // 0x66c6c4: mov             v3.16b, v7.16b
    // 0x66c6c8: b               #0x66c6d8
    // 0x66c6cc: fcmp            d5, d5
    // 0x66c6d0: b.vc            #0x66c6d8
    // 0x66c6d4: mov             v3.16b, v5.16b
    // 0x66c6d8: ldur            x2, [fp, #-0x20]
    // 0x66c6dc: fadd            d5, d1, d3
    // 0x66c6e0: stur            d5, [fp, #-0x40]
    // 0x66c6e4: LoadField: d1 = r0->field_f
    //     0x66c6e4: ldur            d1, [x0, #0xf]
    // 0x66c6e8: LoadField: r0 = r2->field_57
    //     0x66c6e8: ldur            w0, [x2, #0x57]
    // 0x66c6ec: DecompressPointer r0
    //     0x66c6ec: add             x0, x0, HEAP, lsl #32
    // 0x66c6f0: cmp             w0, NULL
    // 0x66c6f4: b.eq            #0x66c8e8
    // 0x66c6f8: LoadField: d3 = r0->field_f
    //     0x66c6f8: ldur            d3, [x0, #0xf]
    // 0x66c6fc: LoadField: d7 = r1->field_7
    //     0x66c6fc: ldur            d7, [x1, #7]
    // 0x66c700: fsub            d8, d3, d7
    // 0x66c704: fdiv            d3, d8, d2
    // 0x66c708: fadd            d2, d1, d3
    // 0x66c70c: stur            d2, [fp, #-0x38]
    // 0x66c710: LoadField: d1 = r0->field_7
    //     0x66c710: ldur            d1, [x0, #7]
    // 0x66c714: fadd            d3, d5, d1
    // 0x66c718: fcmp            d4, d0
    // 0x66c71c: b.vs            #0x66c72c
    // 0x66c720: b.le            #0x66c72c
    // 0x66c724: mov             v0.16b, v4.16b
    // 0x66c728: b               #0x66c75c
    // 0x66c72c: fcmp            d4, d0
    // 0x66c730: b.vs            #0x66c738
    // 0x66c734: b.lt            #0x66c75c
    // 0x66c738: fcmp            d4, d6
    // 0x66c73c: b.vs            #0x66c750
    // 0x66c740: b.ne            #0x66c750
    // 0x66c744: fadd            d1, d4, d0
    // 0x66c748: mov             v0.16b, v1.16b
    // 0x66c74c: b               #0x66c75c
    // 0x66c750: fcmp            d0, d0
    // 0x66c754: b.vs            #0x66c75c
    // 0x66c758: mov             v0.16b, v4.16b
    // 0x66c75c: fsub            d1, d3, d0
    // 0x66c760: stur            d1, [fp, #-0x30]
    // 0x66c764: fadd            d0, d2, d7
    // 0x66c768: stur            d0, [fp, #-0x28]
    // 0x66c76c: fcmp            d5, d1
    // 0x66c770: b.vs            #0x66c788
    // 0x66c774: b.le            #0x66c788
    // 0x66c778: mov             v2.16b, v1.16b
    // 0x66c77c: mov             v0.16b, v1.16b
    // 0x66c780: mov             v1.16b, v5.16b
    // 0x66c784: b               #0x66c840
    // 0x66c788: fcmp            d5, d1
    // 0x66c78c: b.vs            #0x66c7a4
    // 0x66c790: b.ge            #0x66c7a4
    // 0x66c794: mov             v2.16b, v5.16b
    // 0x66c798: mov             v0.16b, v1.16b
    // 0x66c79c: mov             v1.16b, v5.16b
    // 0x66c7a0: b               #0x66c840
    // 0x66c7a4: fcmp            d5, d6
    // 0x66c7a8: b.vs            #0x66c7b0
    // 0x66c7ac: b.eq            #0x66c7b8
    // 0x66c7b0: r0 = false
    //     0x66c7b0: add             x0, NULL, #0x30  ; false
    // 0x66c7b4: b               #0x66c7bc
    // 0x66c7b8: r0 = true
    //     0x66c7b8: add             x0, NULL, #0x20  ; true
    // 0x66c7bc: tbnz            w0, #4, #0x66c7dc
    // 0x66c7c0: fadd            d3, d5, d1
    // 0x66c7c4: fmul            d4, d3, d5
    // 0x66c7c8: fmul            d3, d4, d1
    // 0x66c7cc: mov             v2.16b, v3.16b
    // 0x66c7d0: mov             v0.16b, v1.16b
    // 0x66c7d4: mov             v1.16b, v5.16b
    // 0x66c7d8: b               #0x66c840
    // 0x66c7dc: tbnz            w0, #4, #0x66c820
    // 0x66c7e0: r0 = inline_Allocate_Double()
    //     0x66c7e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x66c7e4: add             x0, x0, #0x10
    //     0x66c7e8: cmp             x1, x0
    //     0x66c7ec: b.ls            #0x66c8ec
    //     0x66c7f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x66c7f4: sub             x0, x0, #0xf
    //     0x66c7f8: mov             x1, #0xd108
    //     0x66c7fc: movk            x1, #3, lsl #16
    //     0x66c800: stur            x1, [x0, #-1]
    // 0x66c804: StoreField: r0->field_7 = d1
    //     0x66c804: stur            d1, [x0, #7]
    // 0x66c808: SaveReg r0
    //     0x66c808: str             x0, [SP, #-8]!
    // 0x66c80c: r0 = isNegative()
    //     0x66c80c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x66c810: add             SP, SP, #8
    // 0x66c814: tbnz            w0, #4, #0x66c820
    // 0x66c818: ldur            d0, [fp, #-0x30]
    // 0x66c81c: b               #0x66c82c
    // 0x66c820: ldur            d0, [fp, #-0x30]
    // 0x66c824: fcmp            d0, d0
    // 0x66c828: b.vc            #0x66c838
    // 0x66c82c: mov             v2.16b, v0.16b
    // 0x66c830: ldur            d1, [fp, #-0x40]
    // 0x66c834: b               #0x66c840
    // 0x66c838: ldur            d2, [fp, #-0x40]
    // 0x66c83c: ldur            d1, [fp, #-0x40]
    // 0x66c840: stur            d2, [fp, #-0x48]
    // 0x66c844: fcmp            d1, d0
    // 0x66c848: b.vs            #0x66c858
    // 0x66c84c: b.le            #0x66c858
    // 0x66c850: mov             v3.16b, v1.16b
    // 0x66c854: b               #0x66c898
    // 0x66c858: fcmp            d1, d0
    // 0x66c85c: b.vs            #0x66c86c
    // 0x66c860: b.ge            #0x66c86c
    // 0x66c864: mov             v3.16b, v0.16b
    // 0x66c868: b               #0x66c898
    // 0x66c86c: d3 = 0.000000
    //     0x66c86c: eor             v3.16b, v3.16b, v3.16b
    // 0x66c870: fcmp            d1, d3
    // 0x66c874: b.vs            #0x66c884
    // 0x66c878: b.ne            #0x66c884
    // 0x66c87c: fadd            d3, d1, d0
    // 0x66c880: b               #0x66c898
    // 0x66c884: fcmp            d0, d0
    // 0x66c888: b.vc            #0x66c894
    // 0x66c88c: mov             v3.16b, v0.16b
    // 0x66c890: b               #0x66c898
    // 0x66c894: mov             v3.16b, v1.16b
    // 0x66c898: ldur            d0, [fp, #-0x38]
    // 0x66c89c: ldur            d1, [fp, #-0x28]
    // 0x66c8a0: stur            d3, [fp, #-0x30]
    // 0x66c8a4: r0 = Rect()
    //     0x66c8a4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x66c8a8: ldur            d0, [fp, #-0x48]
    // 0x66c8ac: StoreField: r0->field_7 = d0
    //     0x66c8ac: stur            d0, [x0, #7]
    // 0x66c8b0: ldur            d0, [fp, #-0x38]
    // 0x66c8b4: StoreField: r0->field_f = d0
    //     0x66c8b4: stur            d0, [x0, #0xf]
    // 0x66c8b8: ldur            d0, [fp, #-0x30]
    // 0x66c8bc: StoreField: r0->field_17 = d0
    //     0x66c8bc: stur            d0, [x0, #0x17]
    // 0x66c8c0: ldur            d0, [fp, #-0x28]
    // 0x66c8c4: StoreField: r0->field_1f = d0
    //     0x66c8c4: stur            d0, [x0, #0x1f]
    // 0x66c8c8: LeaveFrame
    //     0x66c8c8: mov             SP, fp
    //     0x66c8cc: ldp             fp, lr, [SP], #0x10
    // 0x66c8d0: ret
    //     0x66c8d0: ret             
    // 0x66c8d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66c8d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66c8d8: b               #0x66c60c
    // 0x66c8dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66c8dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66c8e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66c8e0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66c8e4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66c8e4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66c8e8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66c8e8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66c8ec: stp             q5, q6, [SP, #-0x20]!
    // 0x66c8f0: stp             q1, q2, [SP, #-0x20]!
    // 0x66c8f4: SaveReg d0
    //     0x66c8f4: str             q0, [SP, #-0x10]!
    // 0x66c8f8: r0 = AllocateDouble()
    //     0x66c8f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66c8fc: RestoreReg d0
    //     0x66c8fc: ldr             q0, [SP], #0x10
    // 0x66c900: ldp             q1, q2, [SP], #0x20
    // 0x66c904: ldp             q5, q6, [SP], #0x20
    // 0x66c908: b               #0x66c804
  }
}

// class id: 2136, size: 0x8, field offset: 0x8
//   const constructor, 
class RoundedRectSliderTrackShape extends _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape {

  _ paint(/* No info */) {
    // ** addr: 0x66bbf8, size: 0x6b4
    // 0x66bbf8: EnterFrame
    //     0x66bbf8: stp             fp, lr, [SP, #-0x10]!
    //     0x66bbfc: mov             fp, SP
    // 0x66bc00: AllocStack(0x80)
    //     0x66bc00: sub             SP, SP, #0x80
    // 0x66bc04: CheckStackOverflow
    //     0x66bc04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66bc08: cmp             SP, x16
    //     0x66bc0c: b.ls            #0x66c188
    // 0x66bc10: ldr             x0, [fp, #0x20]
    // 0x66bc14: LoadField: r1 = r0->field_7
    //     0x66bc14: ldur            w1, [x0, #7]
    // 0x66bc18: DecompressPointer r1
    //     0x66bc18: add             x1, x1, HEAP, lsl #32
    // 0x66bc1c: cmp             w1, NULL
    // 0x66bc20: b.eq            #0x66bc38
    // 0x66bc24: d0 = 0.000000
    //     0x66bc24: eor             v0.16b, v0.16b, v0.16b
    // 0x66bc28: LoadField: d1 = r1->field_7
    //     0x66bc28: ldur            d1, [x1, #7]
    // 0x66bc2c: fcmp            d1, d0
    // 0x66bc30: b.vs            #0x66bc48
    // 0x66bc34: b.gt            #0x66bc48
    // 0x66bc38: r0 = Null
    //     0x66bc38: mov             x0, NULL
    // 0x66bc3c: LeaveFrame
    //     0x66bc3c: mov             SP, fp
    //     0x66bc40: ldp             fp, lr, [SP], #0x10
    // 0x66bc44: ret
    //     0x66bc44: ret             
    // 0x66bc48: ldr             x2, [fp, #0x18]
    // 0x66bc4c: LoadField: r3 = r0->field_17
    //     0x66bc4c: ldur            w3, [x0, #0x17]
    // 0x66bc50: DecompressPointer r3
    //     0x66bc50: add             x3, x3, HEAP, lsl #32
    // 0x66bc54: stur            x3, [fp, #-0x10]
    // 0x66bc58: LoadField: r4 = r0->field_b
    //     0x66bc58: ldur            w4, [x0, #0xb]
    // 0x66bc5c: DecompressPointer r4
    //     0x66bc5c: add             x4, x4, HEAP, lsl #32
    // 0x66bc60: stur            x4, [fp, #-8]
    // 0x66bc64: r1 = <Color?>
    //     0x66bc64: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x66bc68: ldr             x1, [x1, #0xf68]
    // 0x66bc6c: r0 = ColorTween()
    //     0x66bc6c: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0x66bc70: mov             x2, x0
    // 0x66bc74: ldur            x0, [fp, #-0x10]
    // 0x66bc78: stur            x2, [fp, #-0x18]
    // 0x66bc7c: StoreField: r2->field_b = r0
    //     0x66bc7c: stur            w0, [x2, #0xb]
    // 0x66bc80: ldur            x0, [fp, #-8]
    // 0x66bc84: StoreField: r2->field_f = r0
    //     0x66bc84: stur            w0, [x2, #0xf]
    // 0x66bc88: ldr             x0, [fp, #0x20]
    // 0x66bc8c: LoadField: r3 = r0->field_1f
    //     0x66bc8c: ldur            w3, [x0, #0x1f]
    // 0x66bc90: DecompressPointer r3
    //     0x66bc90: add             x3, x3, HEAP, lsl #32
    // 0x66bc94: stur            x3, [fp, #-0x10]
    // 0x66bc98: LoadField: r4 = r0->field_f
    //     0x66bc98: ldur            w4, [x0, #0xf]
    // 0x66bc9c: DecompressPointer r4
    //     0x66bc9c: add             x4, x4, HEAP, lsl #32
    // 0x66bca0: stur            x4, [fp, #-8]
    // 0x66bca4: r1 = <Color?>
    //     0x66bca4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x66bca8: ldr             x1, [x1, #0xf68]
    // 0x66bcac: r0 = ColorTween()
    //     0x66bcac: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0x66bcb0: mov             x1, x0
    // 0x66bcb4: ldur            x0, [fp, #-0x10]
    // 0x66bcb8: stur            x1, [fp, #-0x20]
    // 0x66bcbc: StoreField: r1->field_b = r0
    //     0x66bcbc: stur            w0, [x1, #0xb]
    // 0x66bcc0: ldur            x0, [fp, #-8]
    // 0x66bcc4: StoreField: r1->field_f = r0
    //     0x66bcc4: stur            w0, [x1, #0xf]
    // 0x66bcc8: r16 = 112
    //     0x66bcc8: mov             x16, #0x70
    // 0x66bccc: stp             x16, NULL, [SP, #-0x10]!
    // 0x66bcd0: r0 = ByteData()
    //     0x66bcd0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x66bcd4: add             SP, SP, #0x10
    // 0x66bcd8: stur            x0, [fp, #-8]
    // 0x66bcdc: r0 = Paint()
    //     0x66bcdc: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x66bce0: mov             x1, x0
    // 0x66bce4: ldur            x0, [fp, #-8]
    // 0x66bce8: stur            x1, [fp, #-0x10]
    // 0x66bcec: StoreField: r1->field_7 = r0
    //     0x66bcec: stur            w0, [x1, #7]
    // 0x66bcf0: ldur            x16, [fp, #-0x18]
    // 0x66bcf4: ldr             lr, [fp, #0x40]
    // 0x66bcf8: stp             lr, x16, [SP, #-0x10]!
    // 0x66bcfc: r0 = evaluate()
    //     0x66bcfc: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x66bd00: add             SP, SP, #0x10
    // 0x66bd04: cmp             w0, NULL
    // 0x66bd08: b.eq            #0x66c190
    // 0x66bd0c: r1 = LoadClassIdInstr(r0)
    //     0x66bd0c: ldur            x1, [x0, #-1]
    //     0x66bd10: ubfx            x1, x1, #0xc, #0x14
    // 0x66bd14: SaveReg r0
    //     0x66bd14: str             x0, [SP, #-8]!
    // 0x66bd18: mov             x0, x1
    // 0x66bd1c: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x66bd1c: sub             lr, x0, #0xf7e
    //     0x66bd20: ldr             lr, [x21, lr, lsl #3]
    //     0x66bd24: blr             lr
    // 0x66bd28: add             SP, SP, #8
    // 0x66bd2c: eor             x1, x0, #0xff000000
    // 0x66bd30: ldur            x0, [fp, #-8]
    // 0x66bd34: LoadField: r2 = r0->field_17
    //     0x66bd34: ldur            w2, [x0, #0x17]
    // 0x66bd38: DecompressPointer r2
    //     0x66bd38: add             x2, x2, HEAP, lsl #32
    // 0x66bd3c: sxtw            x1, w1
    // 0x66bd40: LoadField: r0 = r2->field_7
    //     0x66bd40: ldur            x0, [x2, #7]
    // 0x66bd44: str             w1, [x0, #4]
    // 0x66bd48: r16 = 112
    //     0x66bd48: mov             x16, #0x70
    // 0x66bd4c: stp             x16, NULL, [SP, #-0x10]!
    // 0x66bd50: r0 = ByteData()
    //     0x66bd50: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x66bd54: add             SP, SP, #0x10
    // 0x66bd58: stur            x0, [fp, #-8]
    // 0x66bd5c: r0 = Paint()
    //     0x66bd5c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x66bd60: mov             x1, x0
    // 0x66bd64: ldur            x0, [fp, #-8]
    // 0x66bd68: stur            x1, [fp, #-0x18]
    // 0x66bd6c: StoreField: r1->field_7 = r0
    //     0x66bd6c: stur            w0, [x1, #7]
    // 0x66bd70: ldur            x16, [fp, #-0x20]
    // 0x66bd74: ldr             lr, [fp, #0x40]
    // 0x66bd78: stp             lr, x16, [SP, #-0x10]!
    // 0x66bd7c: r0 = evaluate()
    //     0x66bd7c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x66bd80: add             SP, SP, #0x10
    // 0x66bd84: cmp             w0, NULL
    // 0x66bd88: b.eq            #0x66c194
    // 0x66bd8c: r1 = LoadClassIdInstr(r0)
    //     0x66bd8c: ldur            x1, [x0, #-1]
    //     0x66bd90: ubfx            x1, x1, #0xc, #0x14
    // 0x66bd94: SaveReg r0
    //     0x66bd94: str             x0, [SP, #-8]!
    // 0x66bd98: mov             x0, x1
    // 0x66bd9c: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x66bd9c: sub             lr, x0, #0xf7e
    //     0x66bda0: ldr             lr, [x21, lr, lsl #3]
    //     0x66bda4: blr             lr
    // 0x66bda8: add             SP, SP, #8
    // 0x66bdac: eor             x1, x0, #0xff000000
    // 0x66bdb0: ldur            x0, [fp, #-8]
    // 0x66bdb4: LoadField: r2 = r0->field_17
    //     0x66bdb4: ldur            w2, [x0, #0x17]
    // 0x66bdb8: DecompressPointer r2
    //     0x66bdb8: add             x2, x2, HEAP, lsl #32
    // 0x66bdbc: sxtw            x1, w1
    // 0x66bdc0: LoadField: r0 = r2->field_7
    //     0x66bdc0: ldur            x0, [x2, #7]
    // 0x66bdc4: str             w1, [x0, #4]
    // 0x66bdc8: ldr             x0, [fp, #0x18]
    // 0x66bdcc: LoadField: r1 = r0->field_7
    //     0x66bdcc: ldur            x1, [x0, #7]
    // 0x66bdd0: cmp             x1, #0
    // 0x66bdd4: b.gt            #0x66bde4
    // 0x66bdd8: ldur            x2, [fp, #-0x18]
    // 0x66bddc: ldur            x1, [fp, #-0x10]
    // 0x66bde0: b               #0x66bdec
    // 0x66bde4: ldur            x2, [fp, #-0x10]
    // 0x66bde8: ldur            x1, [fp, #-0x18]
    // 0x66bdec: stur            x2, [fp, #-8]
    // 0x66bdf0: stur            x1, [fp, #-0x10]
    // 0x66bdf4: ldr             x16, [fp, #0x58]
    // 0x66bdf8: ldr             lr, [fp, #0x30]
    // 0x66bdfc: stp             lr, x16, [SP, #-0x10]!
    // 0x66be00: ldr             x16, [fp, #0x20]
    // 0x66be04: ldr             lr, [fp, #0x48]
    // 0x66be08: stp             lr, x16, [SP, #-0x10]!
    // 0x66be0c: ldr             x16, [fp, #0x38]
    // 0x66be10: SaveReg r16
    //     0x66be10: str             x16, [SP, #-8]!
    // 0x66be14: r4 = const [0, 0x5, 0x5, 0x3, isEnabled, 0x4, offset, 0x3, null]
    //     0x66be14: add             x4, PP, #0x56, lsl #12  ; [pp+0x56c90] List(9) [0, 0x5, 0x5, 0x3, "isEnabled", 0x4, "offset", 0x3, Null]
    //     0x66be18: ldr             x4, [x4, #0xc90]
    // 0x66be1c: r0 = getPreferredRect()
    //     0x66be1c: bl              #0x66c534  ; [package:flutter/src/material/slider_theme.dart] _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x66be20: add             SP, SP, #0x28
    // 0x66be24: stur            x0, [fp, #-0x18]
    // 0x66be28: LoadField: d0 = r0->field_1f
    //     0x66be28: ldur            d0, [x0, #0x1f]
    // 0x66be2c: stur            d0, [fp, #-0x80]
    // 0x66be30: LoadField: d1 = r0->field_f
    //     0x66be30: ldur            d1, [x0, #0xf]
    // 0x66be34: stur            d1, [fp, #-0x78]
    // 0x66be38: fsub            d2, d0, d1
    // 0x66be3c: stur            d2, [fp, #-0x70]
    // 0x66be40: d3 = 2.000000
    //     0x66be40: fmov            d3, #2.00000000
    // 0x66be44: fdiv            d4, d2, d3
    // 0x66be48: stur            d4, [fp, #-0x68]
    // 0x66be4c: r0 = Radius()
    //     0x66be4c: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x66be50: ldur            d0, [fp, #-0x68]
    // 0x66be54: stur            x0, [fp, #-0x20]
    // 0x66be58: StoreField: r0->field_7 = d0
    //     0x66be58: stur            d0, [x0, #7]
    // 0x66be5c: StoreField: r0->field_f = d0
    //     0x66be5c: stur            d0, [x0, #0xf]
    // 0x66be60: ldur            d0, [fp, #-0x70]
    // 0x66be64: d1 = 2.000000
    //     0x66be64: fmov            d1, #2.00000000
    // 0x66be68: fadd            d2, d0, d1
    // 0x66be6c: fdiv            d0, d2, d1
    // 0x66be70: stur            d0, [fp, #-0x68]
    // 0x66be74: r0 = Radius()
    //     0x66be74: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x66be78: ldur            d0, [fp, #-0x68]
    // 0x66be7c: stur            x0, [fp, #-0x28]
    // 0x66be80: StoreField: r0->field_7 = d0
    //     0x66be80: stur            d0, [x0, #7]
    // 0x66be84: StoreField: r0->field_f = d0
    //     0x66be84: stur            d0, [x0, #0xf]
    // 0x66be88: ldr             x16, [fp, #0x50]
    // 0x66be8c: SaveReg r16
    //     0x66be8c: str             x16, [SP, #-8]!
    // 0x66be90: r0 = canvas()
    //     0x66be90: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66be94: add             SP, SP, #8
    // 0x66be98: mov             x1, x0
    // 0x66be9c: ldur            x0, [fp, #-0x18]
    // 0x66bea0: stur            x1, [fp, #-0x58]
    // 0x66bea4: LoadField: d0 = r0->field_7
    //     0x66bea4: ldur            d0, [x0, #7]
    // 0x66bea8: ldr             x2, [fp, #0x18]
    // 0x66beac: r16 = Instance_TextDirection
    //     0x66beac: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x66beb0: cmp             w2, w16
    // 0x66beb4: b.ne            #0x66bec8
    // 0x66beb8: ldur            d1, [fp, #-0x78]
    // 0x66bebc: d2 = 1.000000
    //     0x66bebc: fmov            d2, #1.00000000
    // 0x66bec0: fsub            d3, d1, d2
    // 0x66bec4: b               #0x66bed4
    // 0x66bec8: ldur            d1, [fp, #-0x78]
    // 0x66becc: d2 = 1.000000
    //     0x66becc: fmov            d2, #1.00000000
    // 0x66bed0: mov             v3.16b, v1.16b
    // 0x66bed4: ldr             x3, [fp, #0x10]
    // 0x66bed8: LoadField: d4 = r3->field_7
    //     0x66bed8: ldur            d4, [x3, #7]
    // 0x66bedc: r16 = Instance_TextDirection
    //     0x66bedc: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x66bee0: cmp             w2, w16
    // 0x66bee4: b.ne            #0x66bef4
    // 0x66bee8: ldur            d5, [fp, #-0x80]
    // 0x66beec: fadd            d6, d5, d2
    // 0x66bef0: b               #0x66befc
    // 0x66bef4: ldur            d5, [fp, #-0x80]
    // 0x66bef8: mov             v6.16b, v5.16b
    // 0x66befc: stur            d6, [fp, #-0x68]
    // 0x66bf00: r16 = Instance_TextDirection
    //     0x66bf00: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x66bf04: cmp             w2, w16
    // 0x66bf08: b.ne            #0x66bf14
    // 0x66bf0c: ldur            x3, [fp, #-0x28]
    // 0x66bf10: b               #0x66bf18
    // 0x66bf14: ldur            x3, [fp, #-0x20]
    // 0x66bf18: stur            x3, [fp, #-0x50]
    // 0x66bf1c: r16 = Instance_TextDirection
    //     0x66bf1c: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x66bf20: cmp             w2, w16
    // 0x66bf24: b.ne            #0x66bf30
    // 0x66bf28: ldur            x4, [fp, #-0x28]
    // 0x66bf2c: b               #0x66bf34
    // 0x66bf30: ldur            x4, [fp, #-0x20]
    // 0x66bf34: stur            x4, [fp, #-0x48]
    // 0x66bf38: r5 = inline_Allocate_Double()
    //     0x66bf38: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x66bf3c: add             x5, x5, #0x10
    //     0x66bf40: cmp             x6, x5
    //     0x66bf44: b.ls            #0x66c198
    //     0x66bf48: str             x5, [THR, #0x60]  ; THR::top
    //     0x66bf4c: sub             x5, x5, #0xf
    //     0x66bf50: mov             x6, #0xd108
    //     0x66bf54: movk            x6, #3, lsl #16
    //     0x66bf58: stur            x6, [x5, #-1]
    // 0x66bf5c: StoreField: r5->field_7 = d0
    //     0x66bf5c: stur            d0, [x5, #7]
    // 0x66bf60: stur            x5, [fp, #-0x40]
    // 0x66bf64: r6 = inline_Allocate_Double()
    //     0x66bf64: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0x66bf68: add             x6, x6, #0x10
    //     0x66bf6c: cmp             x7, x6
    //     0x66bf70: b.ls            #0x66c1dc
    //     0x66bf74: str             x6, [THR, #0x60]  ; THR::top
    //     0x66bf78: sub             x6, x6, #0xf
    //     0x66bf7c: mov             x7, #0xd108
    //     0x66bf80: movk            x7, #3, lsl #16
    //     0x66bf84: stur            x7, [x6, #-1]
    // 0x66bf88: StoreField: r6->field_7 = d3
    //     0x66bf88: stur            d3, [x6, #7]
    // 0x66bf8c: stur            x6, [fp, #-0x38]
    // 0x66bf90: r7 = inline_Allocate_Double()
    //     0x66bf90: ldp             x7, x8, [THR, #0x60]  ; THR::top
    //     0x66bf94: add             x7, x7, #0x10
    //     0x66bf98: cmp             x8, x7
    //     0x66bf9c: b.ls            #0x66c218
    //     0x66bfa0: str             x7, [THR, #0x60]  ; THR::top
    //     0x66bfa4: sub             x7, x7, #0xf
    //     0x66bfa8: mov             x8, #0xd108
    //     0x66bfac: movk            x8, #3, lsl #16
    //     0x66bfb0: stur            x8, [x7, #-1]
    // 0x66bfb4: StoreField: r7->field_7 = d4
    //     0x66bfb4: stur            d4, [x7, #7]
    // 0x66bfb8: stur            x7, [fp, #-0x30]
    // 0x66bfbc: r0 = RRect()
    //     0x66bfbc: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x66bfc0: stur            x0, [fp, #-0x60]
    // 0x66bfc4: ldur            x16, [fp, #-0x40]
    // 0x66bfc8: stp             x16, x0, [SP, #-0x10]!
    // 0x66bfcc: ldur            x16, [fp, #-0x38]
    // 0x66bfd0: ldur            lr, [fp, #-0x30]
    // 0x66bfd4: stp             lr, x16, [SP, #-0x10]!
    // 0x66bfd8: ldur            d0, [fp, #-0x68]
    // 0x66bfdc: SaveReg d0
    //     0x66bfdc: str             d0, [SP, #-8]!
    // 0x66bfe0: ldur            x16, [fp, #-0x50]
    // 0x66bfe4: ldur            lr, [fp, #-0x48]
    // 0x66bfe8: stp             lr, x16, [SP, #-0x10]!
    // 0x66bfec: r4 = const [0, 0x7, 0x7, 0x5, bottomLeft, 0x6, topLeft, 0x5, null]
    //     0x66bfec: add             x4, PP, #0x56, lsl #12  ; [pp+0x56c98] List(9) [0, 0x7, 0x7, 0x5, "bottomLeft", 0x6, "topLeft", 0x5, Null]
    //     0x66bff0: ldr             x4, [x4, #0xc98]
    // 0x66bff4: r0 = RRect.fromLTRBAndCorners()
    //     0x66bff4: bl              #0x66c2ac  ; [dart:ui] RRect::RRect.fromLTRBAndCorners
    // 0x66bff8: add             SP, SP, #0x38
    // 0x66bffc: ldur            x16, [fp, #-0x58]
    // 0x66c000: ldur            lr, [fp, #-0x60]
    // 0x66c004: stp             lr, x16, [SP, #-0x10]!
    // 0x66c008: ldur            x16, [fp, #-8]
    // 0x66c00c: SaveReg r16
    //     0x66c00c: str             x16, [SP, #-8]!
    // 0x66c010: r0 = drawRRect()
    //     0x66c010: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x66c014: add             SP, SP, #0x18
    // 0x66c018: ldr             x16, [fp, #0x50]
    // 0x66c01c: SaveReg r16
    //     0x66c01c: str             x16, [SP, #-8]!
    // 0x66c020: r0 = canvas()
    //     0x66c020: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x66c024: add             SP, SP, #8
    // 0x66c028: mov             x1, x0
    // 0x66c02c: ldr             x0, [fp, #0x18]
    // 0x66c030: stur            x1, [fp, #-0x40]
    // 0x66c034: r16 = Instance_TextDirection
    //     0x66c034: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x66c038: cmp             w0, w16
    // 0x66c03c: b.ne            #0x66c054
    // 0x66c040: ldur            d0, [fp, #-0x78]
    // 0x66c044: d1 = 1.000000
    //     0x66c044: fmov            d1, #1.00000000
    // 0x66c048: fsub            d2, d0, d1
    // 0x66c04c: mov             v0.16b, v2.16b
    // 0x66c050: b               #0x66c05c
    // 0x66c054: ldur            d0, [fp, #-0x78]
    // 0x66c058: d1 = 1.000000
    //     0x66c058: fmov            d1, #1.00000000
    // 0x66c05c: ldur            x2, [fp, #-0x18]
    // 0x66c060: LoadField: d2 = r2->field_17
    //     0x66c060: ldur            d2, [x2, #0x17]
    // 0x66c064: r16 = Instance_TextDirection
    //     0x66c064: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x66c068: cmp             w0, w16
    // 0x66c06c: b.ne            #0x66c080
    // 0x66c070: ldur            d3, [fp, #-0x80]
    // 0x66c074: fadd            d4, d3, d1
    // 0x66c078: mov             v1.16b, v4.16b
    // 0x66c07c: b               #0x66c088
    // 0x66c080: ldur            d3, [fp, #-0x80]
    // 0x66c084: mov             v1.16b, v3.16b
    // 0x66c088: stur            d1, [fp, #-0x68]
    // 0x66c08c: r16 = Instance_TextDirection
    //     0x66c08c: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x66c090: cmp             w0, w16
    // 0x66c094: b.ne            #0x66c0a0
    // 0x66c098: ldur            x2, [fp, #-0x28]
    // 0x66c09c: b               #0x66c0a4
    // 0x66c0a0: ldur            x2, [fp, #-0x20]
    // 0x66c0a4: stur            x2, [fp, #-0x38]
    // 0x66c0a8: r16 = Instance_TextDirection
    //     0x66c0a8: ldr             x16, [PP, #0x4780]  ; [pp+0x4780] Obj!TextDirection@b66e11
    // 0x66c0ac: cmp             w0, w16
    // 0x66c0b0: b.ne            #0x66c0bc
    // 0x66c0b4: ldur            x0, [fp, #-0x28]
    // 0x66c0b8: b               #0x66c0c0
    // 0x66c0bc: ldur            x0, [fp, #-0x20]
    // 0x66c0c0: stur            x0, [fp, #-0x20]
    // 0x66c0c4: r3 = inline_Allocate_Double()
    //     0x66c0c4: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x66c0c8: add             x3, x3, #0x10
    //     0x66c0cc: cmp             x4, x3
    //     0x66c0d0: b.ls            #0x66c25c
    //     0x66c0d4: str             x3, [THR, #0x60]  ; THR::top
    //     0x66c0d8: sub             x3, x3, #0xf
    //     0x66c0dc: mov             x4, #0xd108
    //     0x66c0e0: movk            x4, #3, lsl #16
    //     0x66c0e4: stur            x4, [x3, #-1]
    // 0x66c0e8: StoreField: r3->field_7 = d0
    //     0x66c0e8: stur            d0, [x3, #7]
    // 0x66c0ec: stur            x3, [fp, #-0x18]
    // 0x66c0f0: r4 = inline_Allocate_Double()
    //     0x66c0f0: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x66c0f4: add             x4, x4, #0x10
    //     0x66c0f8: cmp             x5, x4
    //     0x66c0fc: b.ls            #0x66c288
    //     0x66c100: str             x4, [THR, #0x60]  ; THR::top
    //     0x66c104: sub             x4, x4, #0xf
    //     0x66c108: mov             x5, #0xd108
    //     0x66c10c: movk            x5, #3, lsl #16
    //     0x66c110: stur            x5, [x4, #-1]
    // 0x66c114: StoreField: r4->field_7 = d2
    //     0x66c114: stur            d2, [x4, #7]
    // 0x66c118: stur            x4, [fp, #-8]
    // 0x66c11c: r0 = RRect()
    //     0x66c11c: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x66c120: stur            x0, [fp, #-0x28]
    // 0x66c124: ldur            x16, [fp, #-0x30]
    // 0x66c128: stp             x16, x0, [SP, #-0x10]!
    // 0x66c12c: ldur            x16, [fp, #-0x18]
    // 0x66c130: ldur            lr, [fp, #-8]
    // 0x66c134: stp             lr, x16, [SP, #-0x10]!
    // 0x66c138: ldur            d0, [fp, #-0x68]
    // 0x66c13c: SaveReg d0
    //     0x66c13c: str             d0, [SP, #-8]!
    // 0x66c140: ldur            x16, [fp, #-0x38]
    // 0x66c144: ldur            lr, [fp, #-0x20]
    // 0x66c148: stp             lr, x16, [SP, #-0x10]!
    // 0x66c14c: r4 = const [0, 0x7, 0x7, 0x5, bottomRight, 0x6, topRight, 0x5, null]
    //     0x66c14c: add             x4, PP, #0x56, lsl #12  ; [pp+0x56ca0] List(9) [0, 0x7, 0x7, 0x5, "bottomRight", 0x6, "topRight", 0x5, Null]
    //     0x66c150: ldr             x4, [x4, #0xca0]
    // 0x66c154: r0 = RRect.fromLTRBAndCorners()
    //     0x66c154: bl              #0x66c2ac  ; [dart:ui] RRect::RRect.fromLTRBAndCorners
    // 0x66c158: add             SP, SP, #0x38
    // 0x66c15c: ldur            x16, [fp, #-0x40]
    // 0x66c160: ldur            lr, [fp, #-0x28]
    // 0x66c164: stp             lr, x16, [SP, #-0x10]!
    // 0x66c168: ldur            x16, [fp, #-0x10]
    // 0x66c16c: SaveReg r16
    //     0x66c16c: str             x16, [SP, #-8]!
    // 0x66c170: r0 = drawRRect()
    //     0x66c170: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x66c174: add             SP, SP, #0x18
    // 0x66c178: r0 = Null
    //     0x66c178: mov             x0, NULL
    // 0x66c17c: LeaveFrame
    //     0x66c17c: mov             SP, fp
    //     0x66c180: ldp             fp, lr, [SP], #0x10
    // 0x66c184: ret
    //     0x66c184: ret             
    // 0x66c188: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66c188: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66c18c: b               #0x66bc10
    // 0x66c190: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66c190: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66c194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66c194: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66c198: stp             q5, q6, [SP, #-0x20]!
    // 0x66c19c: stp             q3, q4, [SP, #-0x20]!
    // 0x66c1a0: stp             q1, q2, [SP, #-0x20]!
    // 0x66c1a4: SaveReg d0
    //     0x66c1a4: str             q0, [SP, #-0x10]!
    // 0x66c1a8: stp             x3, x4, [SP, #-0x10]!
    // 0x66c1ac: stp             x1, x2, [SP, #-0x10]!
    // 0x66c1b0: SaveReg r0
    //     0x66c1b0: str             x0, [SP, #-8]!
    // 0x66c1b4: r0 = AllocateDouble()
    //     0x66c1b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66c1b8: mov             x5, x0
    // 0x66c1bc: RestoreReg r0
    //     0x66c1bc: ldr             x0, [SP], #8
    // 0x66c1c0: ldp             x1, x2, [SP], #0x10
    // 0x66c1c4: ldp             x3, x4, [SP], #0x10
    // 0x66c1c8: RestoreReg d0
    //     0x66c1c8: ldr             q0, [SP], #0x10
    // 0x66c1cc: ldp             q1, q2, [SP], #0x20
    // 0x66c1d0: ldp             q3, q4, [SP], #0x20
    // 0x66c1d4: ldp             q5, q6, [SP], #0x20
    // 0x66c1d8: b               #0x66bf5c
    // 0x66c1dc: stp             q5, q6, [SP, #-0x20]!
    // 0x66c1e0: stp             q3, q4, [SP, #-0x20]!
    // 0x66c1e4: stp             q1, q2, [SP, #-0x20]!
    // 0x66c1e8: stp             x4, x5, [SP, #-0x10]!
    // 0x66c1ec: stp             x2, x3, [SP, #-0x10]!
    // 0x66c1f0: stp             x0, x1, [SP, #-0x10]!
    // 0x66c1f4: r0 = AllocateDouble()
    //     0x66c1f4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66c1f8: mov             x6, x0
    // 0x66c1fc: ldp             x0, x1, [SP], #0x10
    // 0x66c200: ldp             x2, x3, [SP], #0x10
    // 0x66c204: ldp             x4, x5, [SP], #0x10
    // 0x66c208: ldp             q1, q2, [SP], #0x20
    // 0x66c20c: ldp             q3, q4, [SP], #0x20
    // 0x66c210: ldp             q5, q6, [SP], #0x20
    // 0x66c214: b               #0x66bf88
    // 0x66c218: stp             q5, q6, [SP, #-0x20]!
    // 0x66c21c: stp             q2, q4, [SP, #-0x20]!
    // 0x66c220: SaveReg d1
    //     0x66c220: str             q1, [SP, #-0x10]!
    // 0x66c224: stp             x5, x6, [SP, #-0x10]!
    // 0x66c228: stp             x3, x4, [SP, #-0x10]!
    // 0x66c22c: stp             x1, x2, [SP, #-0x10]!
    // 0x66c230: SaveReg r0
    //     0x66c230: str             x0, [SP, #-8]!
    // 0x66c234: r0 = AllocateDouble()
    //     0x66c234: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66c238: mov             x7, x0
    // 0x66c23c: RestoreReg r0
    //     0x66c23c: ldr             x0, [SP], #8
    // 0x66c240: ldp             x1, x2, [SP], #0x10
    // 0x66c244: ldp             x3, x4, [SP], #0x10
    // 0x66c248: ldp             x5, x6, [SP], #0x10
    // 0x66c24c: RestoreReg d1
    //     0x66c24c: ldr             q1, [SP], #0x10
    // 0x66c250: ldp             q2, q4, [SP], #0x20
    // 0x66c254: ldp             q5, q6, [SP], #0x20
    // 0x66c258: b               #0x66bfb4
    // 0x66c25c: stp             q1, q2, [SP, #-0x20]!
    // 0x66c260: SaveReg d0
    //     0x66c260: str             q0, [SP, #-0x10]!
    // 0x66c264: stp             x1, x2, [SP, #-0x10]!
    // 0x66c268: SaveReg r0
    //     0x66c268: str             x0, [SP, #-8]!
    // 0x66c26c: r0 = AllocateDouble()
    //     0x66c26c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66c270: mov             x3, x0
    // 0x66c274: RestoreReg r0
    //     0x66c274: ldr             x0, [SP], #8
    // 0x66c278: ldp             x1, x2, [SP], #0x10
    // 0x66c27c: RestoreReg d0
    //     0x66c27c: ldr             q0, [SP], #0x10
    // 0x66c280: ldp             q1, q2, [SP], #0x20
    // 0x66c284: b               #0x66c0e8
    // 0x66c288: stp             q1, q2, [SP, #-0x20]!
    // 0x66c28c: stp             x2, x3, [SP, #-0x10]!
    // 0x66c290: stp             x0, x1, [SP, #-0x10]!
    // 0x66c294: r0 = AllocateDouble()
    //     0x66c294: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66c298: mov             x4, x0
    // 0x66c29c: ldp             x0, x1, [SP], #0x10
    // 0x66c2a0: ldp             x2, x3, [SP], #0x10
    // 0x66c2a4: ldp             q1, q2, [SP], #0x20
    // 0x66c2a8: b               #0x66c114
  }
}

// class id: 2137, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliderTickMarkShape extends Object {
}

// class id: 2138, size: 0xc, field offset: 0x8
//   const constructor, 
class RoundSliderTickMarkShape extends SliderTickMarkShape {

  _ getPreferredSize(/* No info */) {
    // ** addr: 0x631454, size: 0x58
    // 0x631454: EnterFrame
    //     0x631454: stp             fp, lr, [SP, #-0x10]!
    //     0x631458: mov             fp, SP
    // 0x63145c: AllocStack(0x8)
    //     0x63145c: sub             SP, SP, #8
    // 0x631460: d1 = 4.000000
    //     0x631460: fmov            d1, #4.00000000
    // 0x631464: d0 = 2.000000
    //     0x631464: fmov            d0, #2.00000000
    // 0x631468: ldr             x0, [fp, #0x10]
    // 0x63146c: LoadField: r1 = r0->field_7
    //     0x63146c: ldur            w1, [x0, #7]
    // 0x631470: DecompressPointer r1
    //     0x631470: add             x1, x1, HEAP, lsl #32
    // 0x631474: cmp             w1, NULL
    // 0x631478: b.eq            #0x6314a8
    // 0x63147c: LoadField: d2 = r1->field_7
    //     0x63147c: ldur            d2, [x1, #7]
    // 0x631480: fdiv            d3, d2, d1
    // 0x631484: fmul            d1, d3, d0
    // 0x631488: stur            d1, [fp, #-8]
    // 0x63148c: r0 = Size()
    //     0x63148c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x631490: ldur            d0, [fp, #-8]
    // 0x631494: StoreField: r0->field_7 = d0
    //     0x631494: stur            d0, [x0, #7]
    // 0x631498: StoreField: r0->field_f = d0
    //     0x631498: stur            d0, [x0, #0xf]
    // 0x63149c: LeaveFrame
    //     0x63149c: mov             SP, fp
    //     0x6314a0: ldp             fp, lr, [SP], #0x10
    // 0x6314a4: ret
    //     0x6314a4: ret             
    // 0x6314a8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6314a8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

// class id: 2139, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class SliderComponentShape extends Object {
}

// class id: 2140, size: 0x8, field offset: 0x8
//   const constructor, 
class DropSliderValueIndicatorShape extends SliderComponentShape {
}

// class id: 2141, size: 0x8, field offset: 0x8
//   const constructor, 
class RectangularSliderValueIndicatorShape extends SliderComponentShape {
}

// class id: 2142, size: 0x10, field offset: 0x8
//   const constructor, 
class RoundSliderOverlayShape extends SliderComponentShape {

  _Double field_8;

  _ getPreferredSize(/* No info */) {
    // ** addr: 0x6314d0, size: 0x28
    // 0x6314d0: EnterFrame
    //     0x6314d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6314d4: mov             fp, SP
    // 0x6314d8: r0 = Size()
    //     0x6314d8: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x6314dc: d0 = 48.000000
    //     0x6314dc: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0x6314e0: ldr             d0, [x17, #0xbd0]
    // 0x6314e4: StoreField: r0->field_7 = d0
    //     0x6314e4: stur            d0, [x0, #7]
    // 0x6314e8: StoreField: r0->field_f = d0
    //     0x6314e8: stur            d0, [x0, #0xf]
    // 0x6314ec: LeaveFrame
    //     0x6314ec: mov             SP, fp
    //     0x6314f0: ldp             fp, lr, [SP], #0x10
    // 0x6314f4: ret
    //     0x6314f4: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xcbcb50, size: 0x144
    // 0xcbcb50: EnterFrame
    //     0xcbcb50: stp             fp, lr, [SP, #-0x10]!
    //     0xcbcb54: mov             fp, SP
    // 0xcbcb58: AllocStack(0x18)
    //     0xcbcb58: sub             SP, SP, #0x18
    // 0xcbcb5c: CheckStackOverflow
    //     0xcbcb5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcbcb60: cmp             SP, x16
    //     0xcbcb64: b.ls            #0xcbcc88
    // 0xcbcb68: ldr             x16, [fp, #0x50]
    // 0xcbcb6c: SaveReg r16
    //     0xcbcb6c: str             x16, [SP, #-8]!
    // 0xcbcb70: r0 = canvas()
    //     0xcbcb70: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xcbcb74: add             SP, SP, #8
    // 0xcbcb78: r1 = <double>
    //     0xcbcb78: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcbcb7c: stur            x0, [fp, #-8]
    // 0xcbcb80: r0 = Tween()
    //     0xcbcb80: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xcbcb84: mov             x1, x0
    // 0xcbcb88: r0 = 0.000000
    //     0xcbcb88: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xcbcb8c: StoreField: r1->field_b = r0
    //     0xcbcb8c: stur            w0, [x1, #0xb]
    // 0xcbcb90: r0 = 24.000000
    //     0xcbcb90: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0xcbcb94: ldr             x0, [x0, #0x360]
    // 0xcbcb98: StoreField: r1->field_f = r0
    //     0xcbcb98: stur            w0, [x1, #0xf]
    // 0xcbcb9c: ldr             x16, [fp, #0x40]
    // 0xcbcba0: stp             x16, x1, [SP, #-0x10]!
    // 0xcbcba4: r0 = evaluate()
    //     0xcbcba4: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcbcba8: add             SP, SP, #0x10
    // 0xcbcbac: stur            x0, [fp, #-0x10]
    // 0xcbcbb0: r16 = 112
    //     0xcbcbb0: mov             x16, #0x70
    // 0xcbcbb4: stp             x16, NULL, [SP, #-0x10]!
    // 0xcbcbb8: r0 = ByteData()
    //     0xcbcbb8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xcbcbbc: add             SP, SP, #0x10
    // 0xcbcbc0: stur            x0, [fp, #-0x18]
    // 0xcbcbc4: r0 = Paint()
    //     0xcbcbc4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xcbcbc8: mov             x1, x0
    // 0xcbcbcc: ldur            x0, [fp, #-0x18]
    // 0xcbcbd0: StoreField: r1->field_7 = r0
    //     0xcbcbd0: stur            w0, [x1, #7]
    // 0xcbcbd4: ldr             x2, [fp, #0x18]
    // 0xcbcbd8: LoadField: r3 = r2->field_3f
    //     0xcbcbd8: ldur            w3, [x2, #0x3f]
    // 0xcbcbdc: DecompressPointer r3
    //     0xcbcbdc: add             x3, x3, HEAP, lsl #32
    // 0xcbcbe0: cmp             w3, NULL
    // 0xcbcbe4: b.eq            #0xcbcc90
    // 0xcbcbe8: r2 = LoadClassIdInstr(r3)
    //     0xcbcbe8: ldur            x2, [x3, #-1]
    //     0xcbcbec: ubfx            x2, x2, #0xc, #0x14
    // 0xcbcbf0: lsl             x2, x2, #1
    // 0xcbcbf4: r17 = 10124
    //     0xcbcbf4: mov             x17, #0x278c
    // 0xcbcbf8: cmp             w2, w17
    // 0xcbcbfc: b.gt            #0xcbcc0c
    // 0xcbcc00: r17 = 10122
    //     0xcbcc00: mov             x17, #0x278a
    // 0xcbcc04: cmp             w2, w17
    // 0xcbcc08: b.ge            #0xcbcc24
    // 0xcbcc0c: r17 = 10114
    //     0xcbcc0c: mov             x17, #0x2782
    // 0xcbcc10: cmp             w2, w17
    // 0xcbcc14: b.eq            #0xcbcc24
    // 0xcbcc18: r17 = 10118
    //     0xcbcc18: mov             x17, #0x2786
    // 0xcbcc1c: cmp             w2, w17
    // 0xcbcc20: b.ne            #0xcbcc30
    // 0xcbcc24: LoadField: r2 = r3->field_7
    //     0xcbcc24: ldur            x2, [x3, #7]
    // 0xcbcc28: mov             x3, x2
    // 0xcbcc2c: b               #0xcbcc3c
    // 0xcbcc30: LoadField: r2 = r3->field_f
    //     0xcbcc30: ldur            w2, [x3, #0xf]
    // 0xcbcc34: DecompressPointer r2
    //     0xcbcc34: add             x2, x2, HEAP, lsl #32
    // 0xcbcc38: LoadField: r3 = r2->field_7
    //     0xcbcc38: ldur            x3, [x2, #7]
    // 0xcbcc3c: ldur            x2, [fp, #-0x10]
    // 0xcbcc40: eor             x4, x3, #0xff000000
    // 0xcbcc44: LoadField: r3 = r0->field_17
    //     0xcbcc44: ldur            w3, [x0, #0x17]
    // 0xcbcc48: DecompressPointer r3
    //     0xcbcc48: add             x3, x3, HEAP, lsl #32
    // 0xcbcc4c: sxtw            x4, w4
    // 0xcbcc50: LoadField: r0 = r3->field_7
    //     0xcbcc50: ldur            x0, [x3, #7]
    // 0xcbcc54: str             w4, [x0, #4]
    // 0xcbcc58: LoadField: d0 = r2->field_7
    //     0xcbcc58: ldur            d0, [x2, #7]
    // 0xcbcc5c: ldur            x16, [fp, #-8]
    // 0xcbcc60: ldr             lr, [fp, #0x48]
    // 0xcbcc64: stp             lr, x16, [SP, #-0x10]!
    // 0xcbcc68: SaveReg d0
    //     0xcbcc68: str             d0, [SP, #-8]!
    // 0xcbcc6c: SaveReg r1
    //     0xcbcc6c: str             x1, [SP, #-8]!
    // 0xcbcc70: r0 = drawCircle()
    //     0xcbcc70: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xcbcc74: add             SP, SP, #0x20
    // 0xcbcc78: r0 = Null
    //     0xcbcc78: mov             x0, NULL
    // 0xcbcc7c: LeaveFrame
    //     0xcbcc7c: mov             SP, fp
    //     0xcbcc80: ldp             fp, lr, [SP], #0x10
    // 0xcbcc84: ret
    //     0xcbcc84: ret             
    // 0xcbcc88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcbcc88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcbcc8c: b               #0xcbcb68
    // 0xcbcc90: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcbcc90: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2143, size: 0x24, field offset: 0x8
//   const constructor, 
class RoundSliderThumbShape extends SliderComponentShape {

  _Double field_8;
  _Double field_14;
  _Double field_1c;

  _ getPreferredSize(/* No info */) {
    // ** addr: 0x6314ac, size: 0x24
    // 0x6314ac: EnterFrame
    //     0x6314ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6314b0: mov             fp, SP
    // 0x6314b4: r0 = Size()
    //     0x6314b4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x6314b8: d0 = 20.000000
    //     0x6314b8: fmov            d0, #20.00000000
    // 0x6314bc: StoreField: r0->field_7 = d0
    //     0x6314bc: stur            d0, [x0, #7]
    // 0x6314c0: StoreField: r0->field_f = d0
    //     0x6314c0: stur            d0, [x0, #0xf]
    // 0x6314c4: LeaveFrame
    //     0x6314c4: mov             SP, fp
    //     0x6314c8: ldp             fp, lr, [SP], #0x10
    // 0x6314cc: ret
    //     0x6314cc: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xcbc560, size: 0x284
    // 0xcbc560: EnterFrame
    //     0xcbc560: stp             fp, lr, [SP, #-0x10]!
    //     0xcbc564: mov             fp, SP
    // 0xcbc568: AllocStack(0x40)
    //     0xcbc568: sub             SP, SP, #0x40
    // 0xcbc56c: CheckStackOverflow
    //     0xcbc56c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcbc570: cmp             SP, x16
    //     0xcbc574: b.ls            #0xcbc7c8
    // 0xcbc578: ldr             x16, [fp, #0x50]
    // 0xcbc57c: SaveReg r16
    //     0xcbc57c: str             x16, [SP, #-8]!
    // 0xcbc580: r0 = canvas()
    //     0xcbc580: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xcbc584: add             SP, SP, #8
    // 0xcbc588: r1 = <double>
    //     0xcbc588: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcbc58c: stur            x0, [fp, #-8]
    // 0xcbc590: r0 = Tween()
    //     0xcbc590: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xcbc594: mov             x2, x0
    // 0xcbc598: r0 = 10.000000
    //     0xcbc598: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c5b8] 10
    //     0xcbc59c: ldr             x0, [x0, #0x5b8]
    // 0xcbc5a0: stur            x2, [fp, #-0x20]
    // 0xcbc5a4: StoreField: r2->field_b = r0
    //     0xcbc5a4: stur            w0, [x2, #0xb]
    // 0xcbc5a8: StoreField: r2->field_f = r0
    //     0xcbc5a8: stur            w0, [x2, #0xf]
    // 0xcbc5ac: ldr             x0, [fp, #0x18]
    // 0xcbc5b0: LoadField: r3 = r0->field_3b
    //     0xcbc5b0: ldur            w3, [x0, #0x3b]
    // 0xcbc5b4: DecompressPointer r3
    //     0xcbc5b4: add             x3, x3, HEAP, lsl #32
    // 0xcbc5b8: stur            x3, [fp, #-0x18]
    // 0xcbc5bc: LoadField: r4 = r0->field_33
    //     0xcbc5bc: ldur            w4, [x0, #0x33]
    // 0xcbc5c0: DecompressPointer r4
    //     0xcbc5c0: add             x4, x4, HEAP, lsl #32
    // 0xcbc5c4: stur            x4, [fp, #-0x10]
    // 0xcbc5c8: r1 = <Color?>
    //     0xcbc5c8: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xcbc5cc: ldr             x1, [x1, #0xf68]
    // 0xcbc5d0: r0 = ColorTween()
    //     0xcbc5d0: bl              #0x66c528  ; AllocateColorTweenStub -> ColorTween (size=0x14)
    // 0xcbc5d4: mov             x1, x0
    // 0xcbc5d8: ldur            x0, [fp, #-0x18]
    // 0xcbc5dc: StoreField: r1->field_b = r0
    //     0xcbc5dc: stur            w0, [x1, #0xb]
    // 0xcbc5e0: ldur            x0, [fp, #-0x10]
    // 0xcbc5e4: StoreField: r1->field_f = r0
    //     0xcbc5e4: stur            w0, [x1, #0xf]
    // 0xcbc5e8: ldr             x16, [fp, #0x38]
    // 0xcbc5ec: stp             x16, x1, [SP, #-0x10]!
    // 0xcbc5f0: r0 = evaluate()
    //     0xcbc5f0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcbc5f4: add             SP, SP, #0x10
    // 0xcbc5f8: stur            x0, [fp, #-0x10]
    // 0xcbc5fc: cmp             w0, NULL
    // 0xcbc600: b.eq            #0xcbc7d0
    // 0xcbc604: ldur            x16, [fp, #-0x20]
    // 0xcbc608: ldr             lr, [fp, #0x38]
    // 0xcbc60c: stp             lr, x16, [SP, #-0x10]!
    // 0xcbc610: r0 = evaluate()
    //     0xcbc610: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcbc614: add             SP, SP, #0x10
    // 0xcbc618: r1 = <double>
    //     0xcbc618: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcbc61c: stur            x0, [fp, #-0x18]
    // 0xcbc620: r0 = Tween()
    //     0xcbc620: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xcbc624: mov             x1, x0
    // 0xcbc628: r0 = 1.000000
    //     0xcbc628: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xcbc62c: StoreField: r1->field_b = r0
    //     0xcbc62c: stur            w0, [x1, #0xb]
    // 0xcbc630: r0 = 6.000000
    //     0xcbc630: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c20] 6
    //     0xcbc634: ldr             x0, [x0, #0xc20]
    // 0xcbc638: StoreField: r1->field_f = r0
    //     0xcbc638: stur            w0, [x1, #0xf]
    // 0xcbc63c: ldr             x16, [fp, #0x40]
    // 0xcbc640: stp             x16, x1, [SP, #-0x10]!
    // 0xcbc644: r0 = evaluate()
    //     0xcbc644: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcbc648: add             SP, SP, #0x10
    // 0xcbc64c: stur            x0, [fp, #-0x20]
    // 0xcbc650: r0 = Path()
    //     0xcbc650: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xcbc654: stur            x0, [fp, #-0x28]
    // 0xcbc658: SaveReg r0
    //     0xcbc658: str             x0, [SP, #-8]!
    // 0xcbc65c: r0 = _constructor()
    //     0xcbc65c: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xcbc660: add             SP, SP, #8
    // 0xcbc664: ldur            x0, [fp, #-0x18]
    // 0xcbc668: LoadField: d0 = r0->field_7
    //     0xcbc668: ldur            d0, [x0, #7]
    // 0xcbc66c: stur            d0, [fp, #-0x40]
    // 0xcbc670: d1 = 2.000000
    //     0xcbc670: fmov            d1, #2.00000000
    // 0xcbc674: fmul            d2, d1, d0
    // 0xcbc678: stur            d2, [fp, #-0x38]
    // 0xcbc67c: r0 = inline_Allocate_Double()
    //     0xcbc67c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcbc680: add             x0, x0, #0x10
    //     0xcbc684: cmp             x1, x0
    //     0xcbc688: b.ls            #0xcbc7d4
    //     0xcbc68c: str             x0, [THR, #0x60]  ; THR::top
    //     0xcbc690: sub             x0, x0, #0xf
    //     0xcbc694: mov             x1, #0xd108
    //     0xcbc698: movk            x1, #3, lsl #16
    //     0xcbc69c: stur            x1, [x0, #-1]
    // 0xcbc6a0: StoreField: r0->field_7 = d2
    //     0xcbc6a0: stur            d2, [x0, #7]
    // 0xcbc6a4: stur            x0, [fp, #-0x18]
    // 0xcbc6a8: r0 = Rect()
    //     0xcbc6a8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xcbc6ac: stur            x0, [fp, #-0x30]
    // 0xcbc6b0: ldr             x16, [fp, #0x48]
    // 0xcbc6b4: stp             x16, x0, [SP, #-0x10]!
    // 0xcbc6b8: ldur            x16, [fp, #-0x18]
    // 0xcbc6bc: SaveReg r16
    //     0xcbc6bc: str             x16, [SP, #-8]!
    // 0xcbc6c0: ldur            d0, [fp, #-0x38]
    // 0xcbc6c4: SaveReg d0
    //     0xcbc6c4: str             d0, [SP, #-8]!
    // 0xcbc6c8: r0 = Rect.fromCenter()
    //     0xcbc6c8: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0xcbc6cc: add             SP, SP, #0x20
    // 0xcbc6d0: ldur            x16, [fp, #-0x28]
    // 0xcbc6d4: ldur            lr, [fp, #-0x30]
    // 0xcbc6d8: stp             lr, x16, [SP, #-0x10]!
    // 0xcbc6dc: r16 = 0.000000
    //     0xcbc6dc: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xcbc6e0: SaveReg r16
    //     0xcbc6e0: str             x16, [SP, #-8]!
    // 0xcbc6e4: d0 = 6.283185
    //     0xcbc6e4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0xcbc6e8: ldr             d0, [x17, #0x848]
    // 0xcbc6ec: SaveReg d0
    //     0xcbc6ec: str             d0, [SP, #-8]!
    // 0xcbc6f0: r0 = addArc()
    //     0xcbc6f0: bl              #0xcbc7e4  ; [dart:ui] Path::addArc
    // 0xcbc6f4: add             SP, SP, #0x20
    // 0xcbc6f8: ldur            x0, [fp, #-0x20]
    // 0xcbc6fc: LoadField: d0 = r0->field_7
    //     0xcbc6fc: ldur            d0, [x0, #7]
    // 0xcbc700: ldur            x16, [fp, #-8]
    // 0xcbc704: ldur            lr, [fp, #-0x28]
    // 0xcbc708: stp             lr, x16, [SP, #-0x10]!
    // 0xcbc70c: r16 = Instance_Color
    //     0xcbc70c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xcbc710: ldr             x16, [x16, #0xf38]
    // 0xcbc714: SaveReg r16
    //     0xcbc714: str             x16, [SP, #-8]!
    // 0xcbc718: SaveReg d0
    //     0xcbc718: str             d0, [SP, #-8]!
    // 0xcbc71c: r16 = true
    //     0xcbc71c: add             x16, NULL, #0x20  ; true
    // 0xcbc720: SaveReg r16
    //     0xcbc720: str             x16, [SP, #-8]!
    // 0xcbc724: r0 = drawShadow()
    //     0xcbc724: bl              #0x663d94  ; [dart:ui] Canvas::drawShadow
    // 0xcbc728: add             SP, SP, #0x28
    // 0xcbc72c: r16 = 112
    //     0xcbc72c: mov             x16, #0x70
    // 0xcbc730: stp             x16, NULL, [SP, #-0x10]!
    // 0xcbc734: r0 = ByteData()
    //     0xcbc734: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xcbc738: add             SP, SP, #0x10
    // 0xcbc73c: stur            x0, [fp, #-0x18]
    // 0xcbc740: r0 = Paint()
    //     0xcbc740: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xcbc744: mov             x2, x0
    // 0xcbc748: ldur            x1, [fp, #-0x18]
    // 0xcbc74c: stur            x2, [fp, #-0x20]
    // 0xcbc750: StoreField: r2->field_7 = r1
    //     0xcbc750: stur            w1, [x2, #7]
    // 0xcbc754: ldur            x0, [fp, #-0x10]
    // 0xcbc758: r3 = LoadClassIdInstr(r0)
    //     0xcbc758: ldur            x3, [x0, #-1]
    //     0xcbc75c: ubfx            x3, x3, #0xc, #0x14
    // 0xcbc760: SaveReg r0
    //     0xcbc760: str             x0, [SP, #-8]!
    // 0xcbc764: mov             x0, x3
    // 0xcbc768: r0 = GDT[cid_x0 + -0xf7e]()
    //     0xcbc768: sub             lr, x0, #0xf7e
    //     0xcbc76c: ldr             lr, [x21, lr, lsl #3]
    //     0xcbc770: blr             lr
    // 0xcbc774: add             SP, SP, #8
    // 0xcbc778: eor             x1, x0, #0xff000000
    // 0xcbc77c: ldur            x0, [fp, #-0x18]
    // 0xcbc780: LoadField: r2 = r0->field_17
    //     0xcbc780: ldur            w2, [x0, #0x17]
    // 0xcbc784: DecompressPointer r2
    //     0xcbc784: add             x2, x2, HEAP, lsl #32
    // 0xcbc788: sxtw            x1, w1
    // 0xcbc78c: LoadField: r0 = r2->field_7
    //     0xcbc78c: ldur            x0, [x2, #7]
    // 0xcbc790: str             w1, [x0, #4]
    // 0xcbc794: ldur            x16, [fp, #-8]
    // 0xcbc798: ldr             lr, [fp, #0x48]
    // 0xcbc79c: stp             lr, x16, [SP, #-0x10]!
    // 0xcbc7a0: ldur            d0, [fp, #-0x40]
    // 0xcbc7a4: SaveReg d0
    //     0xcbc7a4: str             d0, [SP, #-8]!
    // 0xcbc7a8: ldur            x16, [fp, #-0x20]
    // 0xcbc7ac: SaveReg r16
    //     0xcbc7ac: str             x16, [SP, #-8]!
    // 0xcbc7b0: r0 = drawCircle()
    //     0xcbc7b0: bl              #0x674098  ; [dart:ui] Canvas::drawCircle
    // 0xcbc7b4: add             SP, SP, #0x20
    // 0xcbc7b8: r0 = Null
    //     0xcbc7b8: mov             x0, NULL
    // 0xcbc7bc: LeaveFrame
    //     0xcbc7bc: mov             SP, fp
    //     0xcbc7c0: ldp             fp, lr, [SP], #0x10
    // 0xcbc7c4: ret
    //     0xcbc7c4: ret             
    // 0xcbc7c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcbc7c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcbc7cc: b               #0xcbc578
    // 0xcbc7d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcbc7d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcbc7d4: stp             q0, q2, [SP, #-0x20]!
    // 0xcbc7d8: r0 = AllocateDouble()
    //     0xcbc7d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcbc7dc: ldp             q0, q2, [SP], #0x20
    // 0xcbc7e0: b               #0xcbc6a0
  }
}

// class id: 2727, size: 0x80, field offset: 0x8
//   const constructor, 
class SliderThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  _ copyWith(/* No info */) {
    // ** addr: 0x867ef0, size: 0x224
    // 0x867ef0: EnterFrame
    //     0x867ef0: stp             fp, lr, [SP, #-0x10]!
    //     0x867ef4: mov             fp, SP
    // 0x867ef8: AllocStack(0x18)
    //     0x867ef8: sub             SP, SP, #0x18
    // 0x867efc: CheckStackOverflow
    //     0x867efc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x867f00: cmp             SP, x16
    //     0x867f04: b.ls            #0x86810c
    // 0x867f08: ldr             x0, [fp, #0x28]
    // 0x867f0c: cmp             w0, NULL
    // 0x867f10: b.ne            #0x867f28
    // 0x867f14: ldr             x1, [fp, #0x98]
    // 0x867f18: LoadField: r0 = r1->field_7
    //     0x867f18: ldur            w0, [x1, #7]
    // 0x867f1c: DecompressPointer r0
    //     0x867f1c: add             x0, x0, HEAP, lsl #32
    // 0x867f20: mov             x2, x0
    // 0x867f24: b               #0x867f30
    // 0x867f28: ldr             x1, [fp, #0x98]
    // 0x867f2c: mov             x2, x0
    // 0x867f30: ldr             x0, [fp, #0x40]
    // 0x867f34: stur            x2, [fp, #-8]
    // 0x867f38: cmp             w0, NULL
    // 0x867f3c: b.ne            #0x867fd8
    // 0x867f40: r0 = LoadClassIdInstr(r1)
    //     0x867f40: ldur            x0, [x1, #-1]
    //     0x867f44: ubfx            x0, x0, #0xc, #0x14
    // 0x867f48: lsl             x0, x0, #1
    // 0x867f4c: r17 = 5454
    //     0x867f4c: mov             x17, #0x154e
    // 0x867f50: cmp             w0, w17
    // 0x867f54: b.ne            #0x867f64
    // 0x867f58: LoadField: r0 = r1->field_3f
    //     0x867f58: ldur            w0, [x1, #0x3f]
    // 0x867f5c: DecompressPointer r0
    //     0x867f5c: add             x0, x0, HEAP, lsl #32
    // 0x867f60: b               #0x867fd0
    // 0x867f64: r17 = 5456
    //     0x867f64: mov             x17, #0x1550
    // 0x867f68: cmp             w0, w17
    // 0x867f6c: b.ne            #0x867fa4
    // 0x867f70: r1 = 1
    //     0x867f70: mov             x1, #1
    // 0x867f74: r0 = AllocateContext()
    //     0x867f74: bl              #0xd68aa4  ; AllocateContextStub
    // 0x867f78: mov             x1, x0
    // 0x867f7c: ldr             x0, [fp, #0x98]
    // 0x867f80: StoreField: r1->field_f = r0
    //     0x867f80: stur            w0, [x1, #0xf]
    // 0x867f84: mov             x2, x1
    // 0x867f88: r1 = Function '<anonymous closure>':.
    //     0x867f88: add             x1, PP, #0xe, lsl #12  ; [pp+0xe150] AnonymousClosure: (0x868120), in [package:flutter/src/material/slider.dart] _SliderDefaultsM3::overlayColor (0xcebee4)
    //     0x867f8c: ldr             x1, [x1, #0x150]
    // 0x867f90: r0 = AllocateClosure()
    //     0x867f90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x867f94: SaveReg r0
    //     0x867f94: str             x0, [SP, #-8]!
    // 0x867f98: r0 = resolveWith()
    //     0x867f98: bl              #0x85c570  ; [package:flutter/src/material/material_state.dart] MaterialStateColor::resolveWith
    // 0x867f9c: add             SP, SP, #8
    // 0x867fa0: b               #0x867fd0
    // 0x867fa4: mov             x0, x1
    // 0x867fa8: d0 = 0.120000
    //     0x867fa8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x867fac: ldr             d0, [x17, #0xf48]
    // 0x867fb0: LoadField: r1 = r0->field_83
    //     0x867fb0: ldur            w1, [x0, #0x83]
    // 0x867fb4: DecompressPointer r1
    //     0x867fb4: add             x1, x1, HEAP, lsl #32
    // 0x867fb8: LoadField: r2 = r1->field_b
    //     0x867fb8: ldur            w2, [x1, #0xb]
    // 0x867fbc: DecompressPointer r2
    //     0x867fbc: add             x2, x2, HEAP, lsl #32
    // 0x867fc0: SaveReg r2
    //     0x867fc0: str             x2, [SP, #-8]!
    // 0x867fc4: SaveReg d0
    //     0x867fc4: str             d0, [SP, #-8]!
    // 0x867fc8: r0 = withOpacity()
    //     0x867fc8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x867fcc: add             SP, SP, #0x10
    // 0x867fd0: mov             x23, x0
    // 0x867fd4: b               #0x867fdc
    // 0x867fd8: mov             x23, x0
    // 0x867fdc: ldr             x0, [fp, #0x98]
    // 0x867fe0: ldr             x20, [fp, #0x90]
    // 0x867fe4: ldr             x19, [fp, #0x88]
    // 0x867fe8: ldr             x14, [fp, #0x80]
    // 0x867fec: ldr             x13, [fp, #0x78]
    // 0x867ff0: ldr             x12, [fp, #0x70]
    // 0x867ff4: ldr             x11, [fp, #0x68]
    // 0x867ff8: ldr             x10, [fp, #0x60]
    // 0x867ffc: ldr             x9, [fp, #0x58]
    // 0x868000: ldr             x8, [fp, #0x50]
    // 0x868004: ldr             x7, [fp, #0x48]
    // 0x868008: ldr             x6, [fp, #0x38]
    // 0x86800c: ldr             x5, [fp, #0x30]
    // 0x868010: ldr             x4, [fp, #0x20]
    // 0x868014: ldr             x3, [fp, #0x18]
    // 0x868018: ldr             x2, [fp, #0x10]
    // 0x86801c: ldur            x1, [fp, #-8]
    // 0x868020: stur            x23, [fp, #-0x18]
    // 0x868024: LoadField: r24 = r0->field_73
    //     0x868024: ldur            w24, [x0, #0x73]
    // 0x868028: DecompressPointer r24
    //     0x868028: add             x24, x24, HEAP, lsl #32
    // 0x86802c: stur            x24, [fp, #-0x10]
    // 0x868030: r0 = SliderThemeData()
    //     0x868030: bl              #0x868114  ; AllocateSliderThemeDataStub -> SliderThemeData (size=0x80)
    // 0x868034: ldur            x1, [fp, #-8]
    // 0x868038: StoreField: r0->field_7 = r1
    //     0x868038: stur            w1, [x0, #7]
    // 0x86803c: ldr             x1, [fp, #0x88]
    // 0x868040: StoreField: r0->field_b = r1
    //     0x868040: stur            w1, [x0, #0xb]
    // 0x868044: ldr             x1, [fp, #0x48]
    // 0x868048: StoreField: r0->field_f = r1
    //     0x868048: stur            w1, [x0, #0xf]
    // 0x86804c: ldr             x1, [fp, #0x38]
    // 0x868050: StoreField: r0->field_13 = r1
    //     0x868050: stur            w1, [x0, #0x13]
    // 0x868054: ldr             x1, [fp, #0x78]
    // 0x868058: StoreField: r0->field_17 = r1
    //     0x868058: stur            w1, [x0, #0x17]
    // 0x86805c: ldr             x1, [fp, #0x68]
    // 0x868060: StoreField: r0->field_1f = r1
    //     0x868060: stur            w1, [x0, #0x1f]
    // 0x868064: ldr             x1, [fp, #0x60]
    // 0x868068: StoreField: r0->field_1b = r1
    //     0x868068: stur            w1, [x0, #0x1b]
    // 0x86806c: ldr             x1, [fp, #0x90]
    // 0x868070: StoreField: r0->field_23 = r1
    //     0x868070: stur            w1, [x0, #0x23]
    // 0x868074: ldr             x1, [fp, #0x50]
    // 0x868078: StoreField: r0->field_27 = r1
    //     0x868078: stur            w1, [x0, #0x27]
    // 0x86807c: ldr             x1, [fp, #0x80]
    // 0x868080: StoreField: r0->field_2b = r1
    //     0x868080: stur            w1, [x0, #0x2b]
    // 0x868084: ldr             x1, [fp, #0x70]
    // 0x868088: StoreField: r0->field_2f = r1
    //     0x868088: stur            w1, [x0, #0x2f]
    // 0x86808c: ldr             x1, [fp, #0x30]
    // 0x868090: StoreField: r0->field_33 = r1
    //     0x868090: stur            w1, [x0, #0x33]
    // 0x868094: ldr             x1, [fp, #0x58]
    // 0x868098: StoreField: r0->field_3b = r1
    //     0x868098: stur            w1, [x0, #0x3b]
    // 0x86809c: ldur            x1, [fp, #-0x18]
    // 0x8680a0: StoreField: r0->field_3f = r1
    //     0x8680a0: stur            w1, [x0, #0x3f]
    // 0x8680a4: ldr             x1, [fp, #0x20]
    // 0x8680a8: StoreField: r0->field_43 = r1
    //     0x8680a8: stur            w1, [x0, #0x43]
    // 0x8680ac: r1 = Instance_RoundSliderOverlayShape
    //     0x8680ac: add             x1, PP, #0x55, lsl #12  ; [pp+0x557f0] Obj!RoundSliderOverlayShape@b37c11
    //     0x8680b0: ldr             x1, [x1, #0x7f0]
    // 0x8680b4: StoreField: r0->field_47 = r1
    //     0x8680b4: stur            w1, [x0, #0x47]
    // 0x8680b8: r1 = Instance_RoundSliderTickMarkShape
    //     0x8680b8: add             x1, PP, #0x55, lsl #12  ; [pp+0x557f8] Obj!RoundSliderTickMarkShape@b37be1
    //     0x8680bc: ldr             x1, [x1, #0x7f8]
    // 0x8680c0: StoreField: r0->field_4b = r1
    //     0x8680c0: stur            w1, [x0, #0x4b]
    // 0x8680c4: r1 = Instance_RoundSliderThumbShape
    //     0x8680c4: add             x1, PP, #0x55, lsl #12  ; [pp+0x55800] Obj!RoundSliderThumbShape@b37c21
    //     0x8680c8: ldr             x1, [x1, #0x800]
    // 0x8680cc: StoreField: r0->field_4f = r1
    //     0x8680cc: stur            w1, [x0, #0x4f]
    // 0x8680d0: r1 = Instance_RoundedRectSliderTrackShape
    //     0x8680d0: add             x1, PP, #0x55, lsl #12  ; [pp+0x55808] Obj!RoundedRectSliderTrackShape@b37bd1
    //     0x8680d4: ldr             x1, [x1, #0x808]
    // 0x8680d8: StoreField: r0->field_53 = r1
    //     0x8680d8: stur            w1, [x0, #0x53]
    // 0x8680dc: ldr             x1, [fp, #0x18]
    // 0x8680e0: StoreField: r0->field_57 = r1
    //     0x8680e0: stur            w1, [x0, #0x57]
    // 0x8680e4: r1 = Instance_ShowValueIndicator
    //     0x8680e4: add             x1, PP, #0x55, lsl #12  ; [pp+0x55810] Obj!ShowValueIndicator@b651b1
    //     0x8680e8: ldr             x1, [x1, #0x810]
    // 0x8680ec: StoreField: r0->field_6b = r1
    //     0x8680ec: stur            w1, [x0, #0x6b]
    // 0x8680f0: ldr             x1, [fp, #0x10]
    // 0x8680f4: StoreField: r0->field_6f = r1
    //     0x8680f4: stur            w1, [x0, #0x6f]
    // 0x8680f8: ldur            x1, [fp, #-0x10]
    // 0x8680fc: StoreField: r0->field_73 = r1
    //     0x8680fc: stur            w1, [x0, #0x73]
    // 0x868100: LeaveFrame
    //     0x868100: mov             SP, fp
    //     0x868104: ldp             fp, lr, [SP], #0x10
    // 0x868108: ret
    //     0x868108: ret             
    // 0x86810c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86810c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868110: b               #0x867f08
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb01008, size: 0xa6c
    // 0xb01008: EnterFrame
    //     0xb01008: stp             fp, lr, [SP, #-0x10]!
    //     0xb0100c: mov             fp, SP
    // 0xb01010: AllocStack(0xb0)
    //     0xb01010: sub             SP, SP, #0xb0
    // 0xb01014: CheckStackOverflow
    //     0xb01014: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb01018: cmp             SP, x16
    //     0xb0101c: b.ls            #0xb01a64
    // 0xb01020: ldr             x0, [fp, #0x10]
    // 0xb01024: LoadField: r1 = r0->field_7
    //     0xb01024: ldur            w1, [x0, #7]
    // 0xb01028: DecompressPointer r1
    //     0xb01028: add             x1, x1, HEAP, lsl #32
    // 0xb0102c: stur            x1, [fp, #-0x18]
    // 0xb01030: r2 = LoadClassIdInstr(r0)
    //     0xb01030: ldur            x2, [x0, #-1]
    //     0xb01034: ubfx            x2, x2, #0xc, #0x14
    // 0xb01038: lsl             x2, x2, #1
    // 0xb0103c: stur            x2, [fp, #-0x10]
    // 0xb01040: r17 = 5454
    //     0xb01040: mov             x17, #0x154e
    // 0xb01044: cmp             w2, w17
    // 0xb01048: b.ne            #0xb01058
    // 0xb0104c: LoadField: r3 = r0->field_b
    //     0xb0104c: ldur            w3, [x0, #0xb]
    // 0xb01050: DecompressPointer r3
    //     0xb01050: add             x3, x3, HEAP, lsl #32
    // 0xb01054: b               #0xb01090
    // 0xb01058: r17 = 5456
    //     0xb01058: mov             x17, #0x1550
    // 0xb0105c: cmp             w2, w17
    // 0xb01060: b.ne            #0xb0107c
    // 0xb01064: LoadField: r3 = r0->field_83
    //     0xb01064: ldur            w3, [x0, #0x83]
    // 0xb01068: DecompressPointer r3
    //     0xb01068: add             x3, x3, HEAP, lsl #32
    // 0xb0106c: LoadField: r4 = r3->field_b
    //     0xb0106c: ldur            w4, [x3, #0xb]
    // 0xb01070: DecompressPointer r4
    //     0xb01070: add             x4, x4, HEAP, lsl #32
    // 0xb01074: mov             x3, x4
    // 0xb01078: b               #0xb01090
    // 0xb0107c: LoadField: r3 = r0->field_83
    //     0xb0107c: ldur            w3, [x0, #0x83]
    // 0xb01080: DecompressPointer r3
    //     0xb01080: add             x3, x3, HEAP, lsl #32
    // 0xb01084: LoadField: r4 = r3->field_b
    //     0xb01084: ldur            w4, [x3, #0xb]
    // 0xb01088: DecompressPointer r4
    //     0xb01088: add             x4, x4, HEAP, lsl #32
    // 0xb0108c: mov             x3, x4
    // 0xb01090: stur            x3, [fp, #-8]
    // 0xb01094: r17 = 5454
    //     0xb01094: mov             x17, #0x154e
    // 0xb01098: cmp             w2, w17
    // 0xb0109c: b.ne            #0xb010b4
    // 0xb010a0: LoadField: r4 = r0->field_f
    //     0xb010a0: ldur            w4, [x0, #0xf]
    // 0xb010a4: DecompressPointer r4
    //     0xb010a4: add             x4, x4, HEAP, lsl #32
    // 0xb010a8: mov             x1, x4
    // 0xb010ac: mov             x0, x2
    // 0xb010b0: b               #0xb01128
    // 0xb010b4: r17 = 5456
    //     0xb010b4: mov             x17, #0x1550
    // 0xb010b8: cmp             w2, w17
    // 0xb010bc: b.ne            #0xb010f8
    // 0xb010c0: LoadField: r4 = r0->field_83
    //     0xb010c0: ldur            w4, [x0, #0x83]
    // 0xb010c4: DecompressPointer r4
    //     0xb010c4: add             x4, x4, HEAP, lsl #32
    // 0xb010c8: LoadField: r5 = r4->field_5b
    //     0xb010c8: ldur            w5, [x4, #0x5b]
    // 0xb010cc: DecompressPointer r5
    //     0xb010cc: add             x5, x5, HEAP, lsl #32
    // 0xb010d0: cmp             w5, NULL
    // 0xb010d4: b.ne            #0xb010e8
    // 0xb010d8: LoadField: r5 = r4->field_53
    //     0xb010d8: ldur            w5, [x4, #0x53]
    // 0xb010dc: DecompressPointer r5
    //     0xb010dc: add             x5, x5, HEAP, lsl #32
    // 0xb010e0: mov             x4, x5
    // 0xb010e4: b               #0xb010ec
    // 0xb010e8: mov             x4, x5
    // 0xb010ec: mov             x1, x4
    // 0xb010f0: mov             x0, x2
    // 0xb010f4: b               #0xb01128
    // 0xb010f8: d0 = 0.240000
    //     0xb010f8: add             x17, PP, #0xe, lsl #12  ; [pp+0xe130] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0xb010fc: ldr             d0, [x17, #0x130]
    // 0xb01100: LoadField: r4 = r0->field_83
    //     0xb01100: ldur            w4, [x0, #0x83]
    // 0xb01104: DecompressPointer r4
    //     0xb01104: add             x4, x4, HEAP, lsl #32
    // 0xb01108: LoadField: r5 = r4->field_b
    //     0xb01108: ldur            w5, [x4, #0xb]
    // 0xb0110c: DecompressPointer r5
    //     0xb0110c: add             x5, x5, HEAP, lsl #32
    // 0xb01110: SaveReg r5
    //     0xb01110: str             x5, [SP, #-8]!
    // 0xb01114: SaveReg d0
    //     0xb01114: str             d0, [SP, #-8]!
    // 0xb01118: r0 = withOpacity()
    //     0xb01118: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb0111c: add             SP, SP, #0x10
    // 0xb01120: mov             x1, x0
    // 0xb01124: ldur            x0, [fp, #-0x10]
    // 0xb01128: stur            x1, [fp, #-0x20]
    // 0xb0112c: r17 = 5454
    //     0xb0112c: mov             x17, #0x154e
    // 0xb01130: cmp             w0, w17
    // 0xb01134: b.ne            #0xb0114c
    // 0xb01138: ldr             x2, [fp, #0x10]
    // 0xb0113c: LoadField: r3 = r2->field_13
    //     0xb0113c: ldur            w3, [x2, #0x13]
    // 0xb01140: DecompressPointer r3
    //     0xb01140: add             x3, x3, HEAP, lsl #32
    // 0xb01144: mov             x1, x3
    // 0xb01148: b               #0xb011c4
    // 0xb0114c: ldr             x2, [fp, #0x10]
    // 0xb01150: r17 = 5456
    //     0xb01150: mov             x17, #0x1550
    // 0xb01154: cmp             w0, w17
    // 0xb01158: b.ne            #0xb01190
    // 0xb0115c: d0 = 0.540000
    //     0xb0115c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xb01160: ldr             d0, [x17, #0x138]
    // 0xb01164: LoadField: r3 = r2->field_83
    //     0xb01164: ldur            w3, [x2, #0x83]
    // 0xb01168: DecompressPointer r3
    //     0xb01168: add             x3, x3, HEAP, lsl #32
    // 0xb0116c: LoadField: r4 = r3->field_b
    //     0xb0116c: ldur            w4, [x3, #0xb]
    // 0xb01170: DecompressPointer r4
    //     0xb01170: add             x4, x4, HEAP, lsl #32
    // 0xb01174: SaveReg r4
    //     0xb01174: str             x4, [SP, #-8]!
    // 0xb01178: SaveReg d0
    //     0xb01178: str             d0, [SP, #-8]!
    // 0xb0117c: r0 = withOpacity()
    //     0xb0117c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb01180: add             SP, SP, #0x10
    // 0xb01184: mov             x1, x0
    // 0xb01188: ldur            x0, [fp, #-0x10]
    // 0xb0118c: b               #0xb011c4
    // 0xb01190: mov             x0, x2
    // 0xb01194: d0 = 0.540000
    //     0xb01194: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xb01198: ldr             d0, [x17, #0x138]
    // 0xb0119c: LoadField: r1 = r0->field_83
    //     0xb0119c: ldur            w1, [x0, #0x83]
    // 0xb011a0: DecompressPointer r1
    //     0xb011a0: add             x1, x1, HEAP, lsl #32
    // 0xb011a4: LoadField: r2 = r1->field_b
    //     0xb011a4: ldur            w2, [x1, #0xb]
    // 0xb011a8: DecompressPointer r2
    //     0xb011a8: add             x2, x2, HEAP, lsl #32
    // 0xb011ac: SaveReg r2
    //     0xb011ac: str             x2, [SP, #-8]!
    // 0xb011b0: SaveReg d0
    //     0xb011b0: str             d0, [SP, #-8]!
    // 0xb011b4: r0 = withOpacity()
    //     0xb011b4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb011b8: add             SP, SP, #0x10
    // 0xb011bc: mov             x1, x0
    // 0xb011c0: ldur            x0, [fp, #-0x10]
    // 0xb011c4: stur            x1, [fp, #-0x28]
    // 0xb011c8: r17 = 5454
    //     0xb011c8: mov             x17, #0x154e
    // 0xb011cc: cmp             w0, w17
    // 0xb011d0: b.ne            #0xb011e8
    // 0xb011d4: ldr             x2, [fp, #0x10]
    // 0xb011d8: LoadField: r3 = r2->field_17
    //     0xb011d8: ldur            w3, [x2, #0x17]
    // 0xb011dc: DecompressPointer r3
    //     0xb011dc: add             x3, x3, HEAP, lsl #32
    // 0xb011e0: mov             x1, x3
    // 0xb011e4: b               #0xb01260
    // 0xb011e8: ldr             x2, [fp, #0x10]
    // 0xb011ec: r17 = 5456
    //     0xb011ec: mov             x17, #0x1550
    // 0xb011f0: cmp             w0, w17
    // 0xb011f4: b.ne            #0xb0122c
    // 0xb011f8: d0 = 0.380000
    //     0xb011f8: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb011fc: ldr             d0, [x17, #0x140]
    // 0xb01200: LoadField: r3 = r2->field_83
    //     0xb01200: ldur            w3, [x2, #0x83]
    // 0xb01204: DecompressPointer r3
    //     0xb01204: add             x3, x3, HEAP, lsl #32
    // 0xb01208: LoadField: r4 = r3->field_57
    //     0xb01208: ldur            w4, [x3, #0x57]
    // 0xb0120c: DecompressPointer r4
    //     0xb0120c: add             x4, x4, HEAP, lsl #32
    // 0xb01210: SaveReg r4
    //     0xb01210: str             x4, [SP, #-8]!
    // 0xb01214: SaveReg d0
    //     0xb01214: str             d0, [SP, #-8]!
    // 0xb01218: r0 = withOpacity()
    //     0xb01218: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb0121c: add             SP, SP, #0x10
    // 0xb01220: mov             x1, x0
    // 0xb01224: ldur            x0, [fp, #-0x10]
    // 0xb01228: b               #0xb01260
    // 0xb0122c: mov             x0, x2
    // 0xb01230: d0 = 0.320000
    //     0xb01230: add             x17, PP, #0xe, lsl #12  ; [pp+0xe148] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0xb01234: ldr             d0, [x17, #0x148]
    // 0xb01238: LoadField: r1 = r0->field_83
    //     0xb01238: ldur            w1, [x0, #0x83]
    // 0xb0123c: DecompressPointer r1
    //     0xb0123c: add             x1, x1, HEAP, lsl #32
    // 0xb01240: LoadField: r2 = r1->field_57
    //     0xb01240: ldur            w2, [x1, #0x57]
    // 0xb01244: DecompressPointer r2
    //     0xb01244: add             x2, x2, HEAP, lsl #32
    // 0xb01248: SaveReg r2
    //     0xb01248: str             x2, [SP, #-8]!
    // 0xb0124c: SaveReg d0
    //     0xb0124c: str             d0, [SP, #-8]!
    // 0xb01250: r0 = withOpacity()
    //     0xb01250: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb01254: add             SP, SP, #0x10
    // 0xb01258: mov             x1, x0
    // 0xb0125c: ldur            x0, [fp, #-0x10]
    // 0xb01260: stur            x1, [fp, #-0x30]
    // 0xb01264: r17 = 5454
    //     0xb01264: mov             x17, #0x154e
    // 0xb01268: cmp             w0, w17
    // 0xb0126c: b.ne            #0xb01284
    // 0xb01270: ldr             x2, [fp, #0x10]
    // 0xb01274: LoadField: r3 = r2->field_1f
    //     0xb01274: ldur            w3, [x2, #0x1f]
    // 0xb01278: DecompressPointer r3
    //     0xb01278: add             x3, x3, HEAP, lsl #32
    // 0xb0127c: mov             x1, x3
    // 0xb01280: b               #0xb012fc
    // 0xb01284: ldr             x2, [fp, #0x10]
    // 0xb01288: r17 = 5456
    //     0xb01288: mov             x17, #0x1550
    // 0xb0128c: cmp             w0, w17
    // 0xb01290: b.ne            #0xb012c8
    // 0xb01294: d0 = 0.120000
    //     0xb01294: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb01298: ldr             d0, [x17, #0xf48]
    // 0xb0129c: LoadField: r3 = r2->field_83
    //     0xb0129c: ldur            w3, [x2, #0x83]
    // 0xb012a0: DecompressPointer r3
    //     0xb012a0: add             x3, x3, HEAP, lsl #32
    // 0xb012a4: LoadField: r4 = r3->field_57
    //     0xb012a4: ldur            w4, [x3, #0x57]
    // 0xb012a8: DecompressPointer r4
    //     0xb012a8: add             x4, x4, HEAP, lsl #32
    // 0xb012ac: SaveReg r4
    //     0xb012ac: str             x4, [SP, #-8]!
    // 0xb012b0: SaveReg d0
    //     0xb012b0: str             d0, [SP, #-8]!
    // 0xb012b4: r0 = withOpacity()
    //     0xb012b4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb012b8: add             SP, SP, #0x10
    // 0xb012bc: mov             x1, x0
    // 0xb012c0: ldur            x0, [fp, #-0x10]
    // 0xb012c4: b               #0xb012fc
    // 0xb012c8: mov             x0, x2
    // 0xb012cc: d0 = 0.120000
    //     0xb012cc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb012d0: ldr             d0, [x17, #0xf48]
    // 0xb012d4: LoadField: r1 = r0->field_83
    //     0xb012d4: ldur            w1, [x0, #0x83]
    // 0xb012d8: DecompressPointer r1
    //     0xb012d8: add             x1, x1, HEAP, lsl #32
    // 0xb012dc: LoadField: r2 = r1->field_57
    //     0xb012dc: ldur            w2, [x1, #0x57]
    // 0xb012e0: DecompressPointer r2
    //     0xb012e0: add             x2, x2, HEAP, lsl #32
    // 0xb012e4: SaveReg r2
    //     0xb012e4: str             x2, [SP, #-8]!
    // 0xb012e8: SaveReg d0
    //     0xb012e8: str             d0, [SP, #-8]!
    // 0xb012ec: r0 = withOpacity()
    //     0xb012ec: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb012f0: add             SP, SP, #0x10
    // 0xb012f4: mov             x1, x0
    // 0xb012f8: ldur            x0, [fp, #-0x10]
    // 0xb012fc: stur            x1, [fp, #-0x38]
    // 0xb01300: r17 = 5454
    //     0xb01300: mov             x17, #0x154e
    // 0xb01304: cmp             w0, w17
    // 0xb01308: b.ne            #0xb01320
    // 0xb0130c: ldr             x2, [fp, #0x10]
    // 0xb01310: LoadField: r3 = r2->field_1b
    //     0xb01310: ldur            w3, [x2, #0x1b]
    // 0xb01314: DecompressPointer r3
    //     0xb01314: add             x3, x3, HEAP, lsl #32
    // 0xb01318: mov             x1, x3
    // 0xb0131c: b               #0xb01398
    // 0xb01320: ldr             x2, [fp, #0x10]
    // 0xb01324: r17 = 5456
    //     0xb01324: mov             x17, #0x1550
    // 0xb01328: cmp             w0, w17
    // 0xb0132c: b.ne            #0xb01364
    // 0xb01330: d0 = 0.120000
    //     0xb01330: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb01334: ldr             d0, [x17, #0xf48]
    // 0xb01338: LoadField: r3 = r2->field_83
    //     0xb01338: ldur            w3, [x2, #0x83]
    // 0xb0133c: DecompressPointer r3
    //     0xb0133c: add             x3, x3, HEAP, lsl #32
    // 0xb01340: LoadField: r4 = r3->field_57
    //     0xb01340: ldur            w4, [x3, #0x57]
    // 0xb01344: DecompressPointer r4
    //     0xb01344: add             x4, x4, HEAP, lsl #32
    // 0xb01348: SaveReg r4
    //     0xb01348: str             x4, [SP, #-8]!
    // 0xb0134c: SaveReg d0
    //     0xb0134c: str             d0, [SP, #-8]!
    // 0xb01350: r0 = withOpacity()
    //     0xb01350: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb01354: add             SP, SP, #0x10
    // 0xb01358: mov             x1, x0
    // 0xb0135c: ldur            x0, [fp, #-0x10]
    // 0xb01360: b               #0xb01398
    // 0xb01364: mov             x0, x2
    // 0xb01368: d0 = 0.120000
    //     0xb01368: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb0136c: ldr             d0, [x17, #0xf48]
    // 0xb01370: LoadField: r1 = r0->field_83
    //     0xb01370: ldur            w1, [x0, #0x83]
    // 0xb01374: DecompressPointer r1
    //     0xb01374: add             x1, x1, HEAP, lsl #32
    // 0xb01378: LoadField: r2 = r1->field_57
    //     0xb01378: ldur            w2, [x1, #0x57]
    // 0xb0137c: DecompressPointer r2
    //     0xb0137c: add             x2, x2, HEAP, lsl #32
    // 0xb01380: SaveReg r2
    //     0xb01380: str             x2, [SP, #-8]!
    // 0xb01384: SaveReg d0
    //     0xb01384: str             d0, [SP, #-8]!
    // 0xb01388: r0 = withOpacity()
    //     0xb01388: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb0138c: add             SP, SP, #0x10
    // 0xb01390: mov             x1, x0
    // 0xb01394: ldur            x0, [fp, #-0x10]
    // 0xb01398: stur            x1, [fp, #-0x40]
    // 0xb0139c: r17 = 5454
    //     0xb0139c: mov             x17, #0x154e
    // 0xb013a0: cmp             w0, w17
    // 0xb013a4: b.ne            #0xb013bc
    // 0xb013a8: ldr             x2, [fp, #0x10]
    // 0xb013ac: LoadField: r3 = r2->field_23
    //     0xb013ac: ldur            w3, [x2, #0x23]
    // 0xb013b0: DecompressPointer r3
    //     0xb013b0: add             x3, x3, HEAP, lsl #32
    // 0xb013b4: mov             x1, x3
    // 0xb013b8: b               #0xb01434
    // 0xb013bc: ldr             x2, [fp, #0x10]
    // 0xb013c0: r17 = 5456
    //     0xb013c0: mov             x17, #0x1550
    // 0xb013c4: cmp             w0, w17
    // 0xb013c8: b.ne            #0xb01400
    // 0xb013cc: d0 = 0.380000
    //     0xb013cc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb013d0: ldr             d0, [x17, #0x140]
    // 0xb013d4: LoadField: r3 = r2->field_83
    //     0xb013d4: ldur            w3, [x2, #0x83]
    // 0xb013d8: DecompressPointer r3
    //     0xb013d8: add             x3, x3, HEAP, lsl #32
    // 0xb013dc: LoadField: r4 = r3->field_f
    //     0xb013dc: ldur            w4, [x3, #0xf]
    // 0xb013e0: DecompressPointer r4
    //     0xb013e0: add             x4, x4, HEAP, lsl #32
    // 0xb013e4: SaveReg r4
    //     0xb013e4: str             x4, [SP, #-8]!
    // 0xb013e8: SaveReg d0
    //     0xb013e8: str             d0, [SP, #-8]!
    // 0xb013ec: r0 = withOpacity()
    //     0xb013ec: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb013f0: add             SP, SP, #0x10
    // 0xb013f4: mov             x1, x0
    // 0xb013f8: ldur            x0, [fp, #-0x10]
    // 0xb013fc: b               #0xb01434
    // 0xb01400: mov             x0, x2
    // 0xb01404: d0 = 0.540000
    //     0xb01404: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xb01408: ldr             d0, [x17, #0x138]
    // 0xb0140c: LoadField: r1 = r0->field_83
    //     0xb0140c: ldur            w1, [x0, #0x83]
    // 0xb01410: DecompressPointer r1
    //     0xb01410: add             x1, x1, HEAP, lsl #32
    // 0xb01414: LoadField: r2 = r1->field_f
    //     0xb01414: ldur            w2, [x1, #0xf]
    // 0xb01418: DecompressPointer r2
    //     0xb01418: add             x2, x2, HEAP, lsl #32
    // 0xb0141c: SaveReg r2
    //     0xb0141c: str             x2, [SP, #-8]!
    // 0xb01420: SaveReg d0
    //     0xb01420: str             d0, [SP, #-8]!
    // 0xb01424: r0 = withOpacity()
    //     0xb01424: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb01428: add             SP, SP, #0x10
    // 0xb0142c: mov             x1, x0
    // 0xb01430: ldur            x0, [fp, #-0x10]
    // 0xb01434: stur            x1, [fp, #-0x48]
    // 0xb01438: r17 = 5454
    //     0xb01438: mov             x17, #0x154e
    // 0xb0143c: cmp             w0, w17
    // 0xb01440: b.ne            #0xb01458
    // 0xb01444: ldr             x2, [fp, #0x10]
    // 0xb01448: LoadField: r3 = r2->field_27
    //     0xb01448: ldur            w3, [x2, #0x27]
    // 0xb0144c: DecompressPointer r3
    //     0xb0144c: add             x3, x3, HEAP, lsl #32
    // 0xb01450: mov             x1, x3
    // 0xb01454: b               #0xb014ec
    // 0xb01458: ldr             x2, [fp, #0x10]
    // 0xb0145c: r17 = 5456
    //     0xb0145c: mov             x17, #0x1550
    // 0xb01460: cmp             w0, w17
    // 0xb01464: b.ne            #0xb014b8
    // 0xb01468: LoadField: r3 = r2->field_83
    //     0xb01468: ldur            w3, [x2, #0x83]
    // 0xb0146c: DecompressPointer r3
    //     0xb0146c: add             x3, x3, HEAP, lsl #32
    // 0xb01470: LoadField: r4 = r3->field_5f
    //     0xb01470: ldur            w4, [x3, #0x5f]
    // 0xb01474: DecompressPointer r4
    //     0xb01474: add             x4, x4, HEAP, lsl #32
    // 0xb01478: cmp             w4, NULL
    // 0xb0147c: b.ne            #0xb01490
    // 0xb01480: LoadField: r4 = r3->field_57
    //     0xb01480: ldur            w4, [x3, #0x57]
    // 0xb01484: DecompressPointer r4
    //     0xb01484: add             x4, x4, HEAP, lsl #32
    // 0xb01488: mov             x3, x4
    // 0xb0148c: b               #0xb01494
    // 0xb01490: mov             x3, x4
    // 0xb01494: d0 = 0.380000
    //     0xb01494: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb01498: ldr             d0, [x17, #0x140]
    // 0xb0149c: SaveReg r3
    //     0xb0149c: str             x3, [SP, #-8]!
    // 0xb014a0: SaveReg d0
    //     0xb014a0: str             d0, [SP, #-8]!
    // 0xb014a4: r0 = withOpacity()
    //     0xb014a4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb014a8: add             SP, SP, #0x10
    // 0xb014ac: mov             x1, x0
    // 0xb014b0: ldur            x0, [fp, #-0x10]
    // 0xb014b4: b               #0xb014ec
    // 0xb014b8: mov             x0, x2
    // 0xb014bc: d0 = 0.540000
    //     0xb014bc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xb014c0: ldr             d0, [x17, #0x138]
    // 0xb014c4: LoadField: r1 = r0->field_83
    //     0xb014c4: ldur            w1, [x0, #0x83]
    // 0xb014c8: DecompressPointer r1
    //     0xb014c8: add             x1, x1, HEAP, lsl #32
    // 0xb014cc: LoadField: r2 = r1->field_b
    //     0xb014cc: ldur            w2, [x1, #0xb]
    // 0xb014d0: DecompressPointer r2
    //     0xb014d0: add             x2, x2, HEAP, lsl #32
    // 0xb014d4: SaveReg r2
    //     0xb014d4: str             x2, [SP, #-8]!
    // 0xb014d8: SaveReg d0
    //     0xb014d8: str             d0, [SP, #-8]!
    // 0xb014dc: r0 = withOpacity()
    //     0xb014dc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb014e0: add             SP, SP, #0x10
    // 0xb014e4: mov             x1, x0
    // 0xb014e8: ldur            x0, [fp, #-0x10]
    // 0xb014ec: stur            x1, [fp, #-0x50]
    // 0xb014f0: r17 = 5454
    //     0xb014f0: mov             x17, #0x154e
    // 0xb014f4: cmp             w0, w17
    // 0xb014f8: b.ne            #0xb01510
    // 0xb014fc: ldr             x2, [fp, #0x10]
    // 0xb01500: LoadField: r3 = r2->field_2b
    //     0xb01500: ldur            w3, [x2, #0x2b]
    // 0xb01504: DecompressPointer r3
    //     0xb01504: add             x3, x3, HEAP, lsl #32
    // 0xb01508: mov             x1, x3
    // 0xb0150c: b               #0xb01588
    // 0xb01510: ldr             x2, [fp, #0x10]
    // 0xb01514: r17 = 5456
    //     0xb01514: mov             x17, #0x1550
    // 0xb01518: cmp             w0, w17
    // 0xb0151c: b.ne            #0xb01554
    // 0xb01520: d0 = 0.380000
    //     0xb01520: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb01524: ldr             d0, [x17, #0x140]
    // 0xb01528: LoadField: r3 = r2->field_83
    //     0xb01528: ldur            w3, [x2, #0x83]
    // 0xb0152c: DecompressPointer r3
    //     0xb0152c: add             x3, x3, HEAP, lsl #32
    // 0xb01530: LoadField: r4 = r3->field_57
    //     0xb01530: ldur            w4, [x3, #0x57]
    // 0xb01534: DecompressPointer r4
    //     0xb01534: add             x4, x4, HEAP, lsl #32
    // 0xb01538: SaveReg r4
    //     0xb01538: str             x4, [SP, #-8]!
    // 0xb0153c: SaveReg d0
    //     0xb0153c: str             d0, [SP, #-8]!
    // 0xb01540: r0 = withOpacity()
    //     0xb01540: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb01544: add             SP, SP, #0x10
    // 0xb01548: mov             x1, x0
    // 0xb0154c: ldur            x0, [fp, #-0x10]
    // 0xb01550: b               #0xb01588
    // 0xb01554: mov             x0, x2
    // 0xb01558: d0 = 0.120000
    //     0xb01558: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb0155c: ldr             d0, [x17, #0xf48]
    // 0xb01560: LoadField: r1 = r0->field_83
    //     0xb01560: ldur            w1, [x0, #0x83]
    // 0xb01564: DecompressPointer r1
    //     0xb01564: add             x1, x1, HEAP, lsl #32
    // 0xb01568: LoadField: r2 = r1->field_f
    //     0xb01568: ldur            w2, [x1, #0xf]
    // 0xb0156c: DecompressPointer r2
    //     0xb0156c: add             x2, x2, HEAP, lsl #32
    // 0xb01570: SaveReg r2
    //     0xb01570: str             x2, [SP, #-8]!
    // 0xb01574: SaveReg d0
    //     0xb01574: str             d0, [SP, #-8]!
    // 0xb01578: r0 = withOpacity()
    //     0xb01578: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb0157c: add             SP, SP, #0x10
    // 0xb01580: mov             x1, x0
    // 0xb01584: ldur            x0, [fp, #-0x10]
    // 0xb01588: stur            x1, [fp, #-0x58]
    // 0xb0158c: r17 = 5454
    //     0xb0158c: mov             x17, #0x154e
    // 0xb01590: cmp             w0, w17
    // 0xb01594: b.ne            #0xb015ac
    // 0xb01598: ldr             x2, [fp, #0x10]
    // 0xb0159c: LoadField: r3 = r2->field_2f
    //     0xb0159c: ldur            w3, [x2, #0x2f]
    // 0xb015a0: DecompressPointer r3
    //     0xb015a0: add             x3, x3, HEAP, lsl #32
    // 0xb015a4: mov             x1, x3
    // 0xb015a8: b               #0xb01624
    // 0xb015ac: ldr             x2, [fp, #0x10]
    // 0xb015b0: r17 = 5456
    //     0xb015b0: mov             x17, #0x1550
    // 0xb015b4: cmp             w0, w17
    // 0xb015b8: b.ne            #0xb015f0
    // 0xb015bc: d0 = 0.380000
    //     0xb015bc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb015c0: ldr             d0, [x17, #0x140]
    // 0xb015c4: LoadField: r3 = r2->field_83
    //     0xb015c4: ldur            w3, [x2, #0x83]
    // 0xb015c8: DecompressPointer r3
    //     0xb015c8: add             x3, x3, HEAP, lsl #32
    // 0xb015cc: LoadField: r4 = r3->field_57
    //     0xb015cc: ldur            w4, [x3, #0x57]
    // 0xb015d0: DecompressPointer r4
    //     0xb015d0: add             x4, x4, HEAP, lsl #32
    // 0xb015d4: SaveReg r4
    //     0xb015d4: str             x4, [SP, #-8]!
    // 0xb015d8: SaveReg d0
    //     0xb015d8: str             d0, [SP, #-8]!
    // 0xb015dc: r0 = withOpacity()
    //     0xb015dc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb015e0: add             SP, SP, #0x10
    // 0xb015e4: mov             x1, x0
    // 0xb015e8: ldur            x0, [fp, #-0x10]
    // 0xb015ec: b               #0xb01624
    // 0xb015f0: mov             x0, x2
    // 0xb015f4: d0 = 0.120000
    //     0xb015f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb015f8: ldr             d0, [x17, #0xf48]
    // 0xb015fc: LoadField: r1 = r0->field_83
    //     0xb015fc: ldur            w1, [x0, #0x83]
    // 0xb01600: DecompressPointer r1
    //     0xb01600: add             x1, x1, HEAP, lsl #32
    // 0xb01604: LoadField: r2 = r1->field_57
    //     0xb01604: ldur            w2, [x1, #0x57]
    // 0xb01608: DecompressPointer r2
    //     0xb01608: add             x2, x2, HEAP, lsl #32
    // 0xb0160c: SaveReg r2
    //     0xb0160c: str             x2, [SP, #-8]!
    // 0xb01610: SaveReg d0
    //     0xb01610: str             d0, [SP, #-8]!
    // 0xb01614: r0 = withOpacity()
    //     0xb01614: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb01618: add             SP, SP, #0x10
    // 0xb0161c: mov             x1, x0
    // 0xb01620: ldur            x0, [fp, #-0x10]
    // 0xb01624: stur            x1, [fp, #-0x70]
    // 0xb01628: r17 = 5454
    //     0xb01628: mov             x17, #0x154e
    // 0xb0162c: cmp             w0, w17
    // 0xb01630: b.ne            #0xb01644
    // 0xb01634: ldr             x2, [fp, #0x10]
    // 0xb01638: LoadField: r3 = r2->field_33
    //     0xb01638: ldur            w3, [x2, #0x33]
    // 0xb0163c: DecompressPointer r3
    //     0xb0163c: add             x3, x3, HEAP, lsl #32
    // 0xb01640: b               #0xb01680
    // 0xb01644: ldr             x2, [fp, #0x10]
    // 0xb01648: r17 = 5456
    //     0xb01648: mov             x17, #0x1550
    // 0xb0164c: cmp             w0, w17
    // 0xb01650: b.ne            #0xb0166c
    // 0xb01654: LoadField: r3 = r2->field_83
    //     0xb01654: ldur            w3, [x2, #0x83]
    // 0xb01658: DecompressPointer r3
    //     0xb01658: add             x3, x3, HEAP, lsl #32
    // 0xb0165c: LoadField: r4 = r3->field_b
    //     0xb0165c: ldur            w4, [x3, #0xb]
    // 0xb01660: DecompressPointer r4
    //     0xb01660: add             x4, x4, HEAP, lsl #32
    // 0xb01664: mov             x3, x4
    // 0xb01668: b               #0xb01680
    // 0xb0166c: LoadField: r3 = r2->field_83
    //     0xb0166c: ldur            w3, [x2, #0x83]
    // 0xb01670: DecompressPointer r3
    //     0xb01670: add             x3, x3, HEAP, lsl #32
    // 0xb01674: LoadField: r4 = r3->field_b
    //     0xb01674: ldur            w4, [x3, #0xb]
    // 0xb01678: DecompressPointer r4
    //     0xb01678: add             x4, x4, HEAP, lsl #32
    // 0xb0167c: mov             x3, x4
    // 0xb01680: stur            x3, [fp, #-0x68]
    // 0xb01684: r17 = 5454
    //     0xb01684: mov             x17, #0x154e
    // 0xb01688: cmp             w0, w17
    // 0xb0168c: b.ne            #0xb016a0
    // 0xb01690: LoadField: r4 = r2->field_3b
    //     0xb01690: ldur            w4, [x2, #0x3b]
    // 0xb01694: DecompressPointer r4
    //     0xb01694: add             x4, x4, HEAP, lsl #32
    // 0xb01698: mov             x1, x4
    // 0xb0169c: b               #0xb01754
    // 0xb016a0: r17 = 5456
    //     0xb016a0: mov             x17, #0x1550
    // 0xb016a4: cmp             w0, w17
    // 0xb016a8: b.ne            #0xb01700
    // 0xb016ac: d0 = 0.380000
    //     0xb016ac: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb016b0: ldr             d0, [x17, #0x140]
    // 0xb016b4: LoadField: r4 = r2->field_83
    //     0xb016b4: ldur            w4, [x2, #0x83]
    // 0xb016b8: DecompressPointer r4
    //     0xb016b8: add             x4, x4, HEAP, lsl #32
    // 0xb016bc: stur            x4, [fp, #-0x60]
    // 0xb016c0: LoadField: r5 = r4->field_57
    //     0xb016c0: ldur            w5, [x4, #0x57]
    // 0xb016c4: DecompressPointer r5
    //     0xb016c4: add             x5, x5, HEAP, lsl #32
    // 0xb016c8: SaveReg r5
    //     0xb016c8: str             x5, [SP, #-8]!
    // 0xb016cc: SaveReg d0
    //     0xb016cc: str             d0, [SP, #-8]!
    // 0xb016d0: r0 = withOpacity()
    //     0xb016d0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb016d4: add             SP, SP, #0x10
    // 0xb016d8: mov             x1, x0
    // 0xb016dc: ldur            x0, [fp, #-0x60]
    // 0xb016e0: LoadField: r2 = r0->field_53
    //     0xb016e0: ldur            w2, [x0, #0x53]
    // 0xb016e4: DecompressPointer r2
    //     0xb016e4: add             x2, x2, HEAP, lsl #32
    // 0xb016e8: stp             x2, x1, [SP, #-0x10]!
    // 0xb016ec: r0 = alphaBlend()
    //     0xb016ec: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xb016f0: add             SP, SP, #0x10
    // 0xb016f4: mov             x1, x0
    // 0xb016f8: ldur            x0, [fp, #-0x10]
    // 0xb016fc: b               #0xb01754
    // 0xb01700: mov             x0, x2
    // 0xb01704: d0 = 0.380000
    //     0xb01704: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xb01708: ldr             d0, [x17, #0x140]
    // 0xb0170c: LoadField: r1 = r0->field_83
    //     0xb0170c: ldur            w1, [x0, #0x83]
    // 0xb01710: DecompressPointer r1
    //     0xb01710: add             x1, x1, HEAP, lsl #32
    // 0xb01714: stur            x1, [fp, #-0x60]
    // 0xb01718: LoadField: r2 = r1->field_57
    //     0xb01718: ldur            w2, [x1, #0x57]
    // 0xb0171c: DecompressPointer r2
    //     0xb0171c: add             x2, x2, HEAP, lsl #32
    // 0xb01720: SaveReg r2
    //     0xb01720: str             x2, [SP, #-8]!
    // 0xb01724: SaveReg d0
    //     0xb01724: str             d0, [SP, #-8]!
    // 0xb01728: r0 = withOpacity()
    //     0xb01728: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb0172c: add             SP, SP, #0x10
    // 0xb01730: mov             x1, x0
    // 0xb01734: ldur            x0, [fp, #-0x60]
    // 0xb01738: LoadField: r2 = r0->field_53
    //     0xb01738: ldur            w2, [x0, #0x53]
    // 0xb0173c: DecompressPointer r2
    //     0xb0173c: add             x2, x2, HEAP, lsl #32
    // 0xb01740: stp             x2, x1, [SP, #-0x10]!
    // 0xb01744: r0 = alphaBlend()
    //     0xb01744: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xb01748: add             SP, SP, #0x10
    // 0xb0174c: mov             x1, x0
    // 0xb01750: ldur            x0, [fp, #-0x10]
    // 0xb01754: stur            x1, [fp, #-0x60]
    // 0xb01758: r17 = 5454
    //     0xb01758: mov             x17, #0x154e
    // 0xb0175c: cmp             w0, w17
    // 0xb01760: b.ne            #0xb01780
    // 0xb01764: ldr             x2, [fp, #0x10]
    // 0xb01768: LoadField: r3 = r2->field_3f
    //     0xb01768: ldur            w3, [x2, #0x3f]
    // 0xb0176c: DecompressPointer r3
    //     0xb0176c: add             x3, x3, HEAP, lsl #32
    // 0xb01770: mov             x1, x0
    // 0xb01774: mov             x0, x2
    // 0xb01778: mov             x2, x3
    // 0xb0177c: b               #0xb01808
    // 0xb01780: ldr             x2, [fp, #0x10]
    // 0xb01784: r17 = 5456
    //     0xb01784: mov             x17, #0x1550
    // 0xb01788: cmp             w0, w17
    // 0xb0178c: b.ne            #0xb017d0
    // 0xb01790: r1 = 1
    //     0xb01790: mov             x1, #1
    // 0xb01794: r0 = AllocateContext()
    //     0xb01794: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb01798: mov             x1, x0
    // 0xb0179c: ldr             x0, [fp, #0x10]
    // 0xb017a0: StoreField: r1->field_f = r0
    //     0xb017a0: stur            w0, [x1, #0xf]
    // 0xb017a4: mov             x2, x1
    // 0xb017a8: r1 = Function '<anonymous closure>':.
    //     0xb017a8: add             x1, PP, #0xe, lsl #12  ; [pp+0xe150] AnonymousClosure: (0x868120), in [package:flutter/src/material/slider.dart] _SliderDefaultsM3::overlayColor (0xcebee4)
    //     0xb017ac: ldr             x1, [x1, #0x150]
    // 0xb017b0: r0 = AllocateClosure()
    //     0xb017b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb017b4: SaveReg r0
    //     0xb017b4: str             x0, [SP, #-8]!
    // 0xb017b8: r0 = resolveWith()
    //     0xb017b8: bl              #0x85c570  ; [package:flutter/src/material/material_state.dart] MaterialStateColor::resolveWith
    // 0xb017bc: add             SP, SP, #8
    // 0xb017c0: mov             x2, x0
    // 0xb017c4: ldr             x0, [fp, #0x10]
    // 0xb017c8: ldur            x1, [fp, #-0x10]
    // 0xb017cc: b               #0xb01808
    // 0xb017d0: mov             x0, x2
    // 0xb017d4: d0 = 0.120000
    //     0xb017d4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xb017d8: ldr             d0, [x17, #0xf48]
    // 0xb017dc: LoadField: r1 = r0->field_83
    //     0xb017dc: ldur            w1, [x0, #0x83]
    // 0xb017e0: DecompressPointer r1
    //     0xb017e0: add             x1, x1, HEAP, lsl #32
    // 0xb017e4: LoadField: r2 = r1->field_b
    //     0xb017e4: ldur            w2, [x1, #0xb]
    // 0xb017e8: DecompressPointer r2
    //     0xb017e8: add             x2, x2, HEAP, lsl #32
    // 0xb017ec: SaveReg r2
    //     0xb017ec: str             x2, [SP, #-8]!
    // 0xb017f0: SaveReg d0
    //     0xb017f0: str             d0, [SP, #-8]!
    // 0xb017f4: r0 = withOpacity()
    //     0xb017f4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xb017f8: add             SP, SP, #0x10
    // 0xb017fc: mov             x2, x0
    // 0xb01800: ldr             x0, [fp, #0x10]
    // 0xb01804: ldur            x1, [fp, #-0x10]
    // 0xb01808: stur            x2, [fp, #-0xb0]
    // 0xb0180c: LoadField: r3 = r0->field_43
    //     0xb0180c: ldur            w3, [x0, #0x43]
    // 0xb01810: DecompressPointer r3
    //     0xb01810: add             x3, x3, HEAP, lsl #32
    // 0xb01814: stur            x3, [fp, #-0xa8]
    // 0xb01818: LoadField: r4 = r0->field_47
    //     0xb01818: ldur            w4, [x0, #0x47]
    // 0xb0181c: DecompressPointer r4
    //     0xb0181c: add             x4, x4, HEAP, lsl #32
    // 0xb01820: stur            x4, [fp, #-0xa0]
    // 0xb01824: LoadField: r5 = r0->field_4b
    //     0xb01824: ldur            w5, [x0, #0x4b]
    // 0xb01828: DecompressPointer r5
    //     0xb01828: add             x5, x5, HEAP, lsl #32
    // 0xb0182c: stur            x5, [fp, #-0x98]
    // 0xb01830: LoadField: r6 = r0->field_4f
    //     0xb01830: ldur            w6, [x0, #0x4f]
    // 0xb01834: DecompressPointer r6
    //     0xb01834: add             x6, x6, HEAP, lsl #32
    // 0xb01838: stur            x6, [fp, #-0x90]
    // 0xb0183c: LoadField: r7 = r0->field_53
    //     0xb0183c: ldur            w7, [x0, #0x53]
    // 0xb01840: DecompressPointer r7
    //     0xb01840: add             x7, x7, HEAP, lsl #32
    // 0xb01844: stur            x7, [fp, #-0x88]
    // 0xb01848: r17 = 5454
    //     0xb01848: mov             x17, #0x154e
    // 0xb0184c: cmp             w1, w17
    // 0xb01850: b.ne            #0xb01860
    // 0xb01854: LoadField: r8 = r0->field_57
    //     0xb01854: ldur            w8, [x0, #0x57]
    // 0xb01858: DecompressPointer r8
    //     0xb01858: add             x8, x8, HEAP, lsl #32
    // 0xb0185c: b               #0xb01880
    // 0xb01860: r17 = 5456
    //     0xb01860: mov             x17, #0x1550
    // 0xb01864: cmp             w1, w17
    // 0xb01868: b.ne            #0xb01878
    // 0xb0186c: r8 = Instance_DropSliderValueIndicatorShape
    //     0xb0186c: add             x8, PP, #0xe, lsl #12  ; [pp+0xe158] Obj!DropSliderValueIndicatorShape@b37bf1
    //     0xb01870: ldr             x8, [x8, #0x158]
    // 0xb01874: b               #0xb01880
    // 0xb01878: r8 = Instance_RectangularSliderValueIndicatorShape
    //     0xb01878: add             x8, PP, #0xe, lsl #12  ; [pp+0xe160] Obj!RectangularSliderValueIndicatorShape@b37c01
    //     0xb0187c: ldr             x8, [x8, #0x160]
    // 0xb01880: stur            x8, [fp, #-0x80]
    // 0xb01884: LoadField: r9 = r0->field_6b
    //     0xb01884: ldur            w9, [x0, #0x6b]
    // 0xb01888: DecompressPointer r9
    //     0xb01888: add             x9, x9, HEAP, lsl #32
    // 0xb0188c: stur            x9, [fp, #-0x78]
    // 0xb01890: r17 = 5454
    //     0xb01890: mov             x17, #0x154e
    // 0xb01894: cmp             w1, w17
    // 0xb01898: b.ne            #0xb018a8
    // 0xb0189c: LoadField: r1 = r0->field_6f
    //     0xb0189c: ldur            w1, [x0, #0x6f]
    // 0xb018a0: DecompressPointer r1
    //     0xb018a0: add             x1, x1, HEAP, lsl #32
    // 0xb018a4: b               #0xb01970
    // 0xb018a8: r17 = 5456
    //     0xb018a8: mov             x17, #0x1550
    // 0xb018ac: cmp             w1, w17
    // 0xb018b0: b.ne            #0xb01914
    // 0xb018b4: LoadField: r1 = r0->field_7f
    //     0xb018b4: ldur            w1, [x0, #0x7f]
    // 0xb018b8: DecompressPointer r1
    //     0xb018b8: add             x1, x1, HEAP, lsl #32
    // 0xb018bc: SaveReg r1
    //     0xb018bc: str             x1, [SP, #-8]!
    // 0xb018c0: r0 = of()
    //     0xb018c0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb018c4: add             SP, SP, #8
    // 0xb018c8: LoadField: r1 = r0->field_93
    //     0xb018c8: ldur            w1, [x0, #0x93]
    // 0xb018cc: DecompressPointer r1
    //     0xb018cc: add             x1, x1, HEAP, lsl #32
    // 0xb018d0: LoadField: r0 = r1->field_3b
    //     0xb018d0: ldur            w0, [x1, #0x3b]
    // 0xb018d4: DecompressPointer r0
    //     0xb018d4: add             x0, x0, HEAP, lsl #32
    // 0xb018d8: cmp             w0, NULL
    // 0xb018dc: b.eq            #0xb01a6c
    // 0xb018e0: ldr             x1, [fp, #0x10]
    // 0xb018e4: LoadField: r2 = r1->field_83
    //     0xb018e4: ldur            w2, [x1, #0x83]
    // 0xb018e8: DecompressPointer r2
    //     0xb018e8: add             x2, x2, HEAP, lsl #32
    // 0xb018ec: LoadField: r3 = r2->field_f
    //     0xb018ec: ldur            w3, [x2, #0xf]
    // 0xb018f0: DecompressPointer r3
    //     0xb018f0: add             x3, x3, HEAP, lsl #32
    // 0xb018f4: stp             x3, x0, [SP, #-0x10]!
    // 0xb018f8: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb018f8: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb018fc: ldr             x4, [x4, #0x168]
    // 0xb01900: r0 = copyWith()
    //     0xb01900: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb01904: add             SP, SP, #0x10
    // 0xb01908: mov             x1, x0
    // 0xb0190c: ldr             x0, [fp, #0x10]
    // 0xb01910: b               #0xb01970
    // 0xb01914: LoadField: r1 = r0->field_7f
    //     0xb01914: ldur            w1, [x0, #0x7f]
    // 0xb01918: DecompressPointer r1
    //     0xb01918: add             x1, x1, HEAP, lsl #32
    // 0xb0191c: SaveReg r1
    //     0xb0191c: str             x1, [SP, #-8]!
    // 0xb01920: r0 = of()
    //     0xb01920: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb01924: add             SP, SP, #8
    // 0xb01928: LoadField: r1 = r0->field_93
    //     0xb01928: ldur            w1, [x0, #0x93]
    // 0xb0192c: DecompressPointer r1
    //     0xb0192c: add             x1, x1, HEAP, lsl #32
    // 0xb01930: LoadField: r0 = r1->field_2b
    //     0xb01930: ldur            w0, [x1, #0x2b]
    // 0xb01934: DecompressPointer r0
    //     0xb01934: add             x0, x0, HEAP, lsl #32
    // 0xb01938: cmp             w0, NULL
    // 0xb0193c: b.eq            #0xb01a70
    // 0xb01940: ldr             x1, [fp, #0x10]
    // 0xb01944: LoadField: r2 = r1->field_83
    //     0xb01944: ldur            w2, [x1, #0x83]
    // 0xb01948: DecompressPointer r2
    //     0xb01948: add             x2, x2, HEAP, lsl #32
    // 0xb0194c: LoadField: r3 = r2->field_f
    //     0xb0194c: ldur            w3, [x2, #0xf]
    // 0xb01950: DecompressPointer r3
    //     0xb01950: add             x3, x3, HEAP, lsl #32
    // 0xb01954: stp             x3, x0, [SP, #-0x10]!
    // 0xb01958: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb01958: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb0195c: ldr             x4, [x4, #0x168]
    // 0xb01960: r0 = copyWith()
    //     0xb01960: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb01964: add             SP, SP, #0x10
    // 0xb01968: mov             x1, x0
    // 0xb0196c: ldr             x0, [fp, #0x10]
    // 0xb01970: LoadField: r2 = r0->field_73
    //     0xb01970: ldur            w2, [x0, #0x73]
    // 0xb01974: DecompressPointer r2
    //     0xb01974: add             x2, x2, HEAP, lsl #32
    // 0xb01978: ldur            x16, [fp, #-0x88]
    // 0xb0197c: ldur            lr, [fp, #-0x80]
    // 0xb01980: stp             lr, x16, [SP, #-0x10]!
    // 0xb01984: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb01988: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb0198c: ldur            x16, [fp, #-0x78]
    // 0xb01990: stp             x1, x16, [SP, #-0x10]!
    // 0xb01994: stp             NULL, x2, [SP, #-0x10]!
    // 0xb01998: SaveReg rNULL
    //     0xb01998: str             NULL, [SP, #-8]!
    // 0xb0199c: r4 = const [0, 0xb, 0xb, 0xb, null]
    //     0xb0199c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe128] List(5) [0, 0xb, 0xb, 0xb, Null]
    //     0xb019a0: ldr             x4, [x4, #0x128]
    // 0xb019a4: r0 = hash()
    //     0xb019a4: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb019a8: add             SP, SP, #0x58
    // 0xb019ac: mov             x2, x0
    // 0xb019b0: r0 = BoxInt64Instr(r2)
    //     0xb019b0: sbfiz           x0, x2, #1, #0x1f
    //     0xb019b4: cmp             x2, x0, asr #1
    //     0xb019b8: b.eq            #0xb019c4
    //     0xb019bc: bl              #0xd69bb8
    //     0xb019c0: stur            x2, [x0, #7]
    // 0xb019c4: ldur            x16, [fp, #-0x18]
    // 0xb019c8: ldur            lr, [fp, #-8]
    // 0xb019cc: stp             lr, x16, [SP, #-0x10]!
    // 0xb019d0: ldur            x16, [fp, #-0x20]
    // 0xb019d4: ldur            lr, [fp, #-0x28]
    // 0xb019d8: stp             lr, x16, [SP, #-0x10]!
    // 0xb019dc: ldur            x16, [fp, #-0x30]
    // 0xb019e0: ldur            lr, [fp, #-0x38]
    // 0xb019e4: stp             lr, x16, [SP, #-0x10]!
    // 0xb019e8: ldur            x16, [fp, #-0x40]
    // 0xb019ec: ldur            lr, [fp, #-0x48]
    // 0xb019f0: stp             lr, x16, [SP, #-0x10]!
    // 0xb019f4: ldur            x16, [fp, #-0x50]
    // 0xb019f8: ldur            lr, [fp, #-0x58]
    // 0xb019fc: stp             lr, x16, [SP, #-0x10]!
    // 0xb01a00: ldur            x16, [fp, #-0x70]
    // 0xb01a04: ldur            lr, [fp, #-0x68]
    // 0xb01a08: stp             lr, x16, [SP, #-0x10]!
    // 0xb01a0c: ldur            x16, [fp, #-0x60]
    // 0xb01a10: stp             x16, NULL, [SP, #-0x10]!
    // 0xb01a14: ldur            x16, [fp, #-0xb0]
    // 0xb01a18: ldur            lr, [fp, #-0xa8]
    // 0xb01a1c: stp             lr, x16, [SP, #-0x10]!
    // 0xb01a20: ldur            x16, [fp, #-0xa0]
    // 0xb01a24: ldur            lr, [fp, #-0x98]
    // 0xb01a28: stp             lr, x16, [SP, #-0x10]!
    // 0xb01a2c: ldur            x16, [fp, #-0x90]
    // 0xb01a30: stp             x0, x16, [SP, #-0x10]!
    // 0xb01a34: r4 = const [0, 0x14, 0x14, 0x14, null]
    //     0xb01a34: ldr             x4, [PP, #0x70d8]  ; [pp+0x70d8] List(5) [0, 0x14, 0x14, 0x14, Null]
    // 0xb01a38: r0 = hash()
    //     0xb01a38: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb01a3c: add             SP, SP, #0xa0
    // 0xb01a40: mov             x2, x0
    // 0xb01a44: r0 = BoxInt64Instr(r2)
    //     0xb01a44: sbfiz           x0, x2, #1, #0x1f
    //     0xb01a48: cmp             x2, x0, asr #1
    //     0xb01a4c: b.eq            #0xb01a58
    //     0xb01a50: bl              #0xd69bb8
    //     0xb01a54: stur            x2, [x0, #7]
    // 0xb01a58: LeaveFrame
    //     0xb01a58: mov             SP, fp
    //     0xb01a5c: ldp             fp, lr, [SP], #0x10
    // 0xb01a60: ret
    //     0xb01a60: ret             
    // 0xb01a64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb01a64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb01a68: b               #0xb01020
    // 0xb01a6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb01a6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb01a70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb01a70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf2b64, size: 0x5bc
    // 0xbf2b64: EnterFrame
    //     0xbf2b64: stp             fp, lr, [SP, #-0x10]!
    //     0xbf2b68: mov             fp, SP
    // 0xbf2b6c: AllocStack(0xb8)
    //     0xbf2b6c: sub             SP, SP, #0xb8
    // 0xbf2b70: CheckStackOverflow
    //     0xbf2b70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf2b74: cmp             SP, x16
    //     0xbf2b78: b.ls            #0xbf30f4
    // 0xbf2b7c: ldr             x0, [fp, #0x20]
    // 0xbf2b80: LoadField: r1 = r0->field_7
    //     0xbf2b80: ldur            w1, [x0, #7]
    // 0xbf2b84: DecompressPointer r1
    //     0xbf2b84: add             x1, x1, HEAP, lsl #32
    // 0xbf2b88: ldr             x2, [fp, #0x18]
    // 0xbf2b8c: LoadField: r3 = r2->field_7
    //     0xbf2b8c: ldur            w3, [x2, #7]
    // 0xbf2b90: DecompressPointer r3
    //     0xbf2b90: add             x3, x3, HEAP, lsl #32
    // 0xbf2b94: ldr             d0, [fp, #0x10]
    // 0xbf2b98: r4 = inline_Allocate_Double()
    //     0xbf2b98: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbf2b9c: add             x4, x4, #0x10
    //     0xbf2ba0: cmp             x5, x4
    //     0xbf2ba4: b.ls            #0xbf30fc
    //     0xbf2ba8: str             x4, [THR, #0x60]  ; THR::top
    //     0xbf2bac: sub             x4, x4, #0xf
    //     0xbf2bb0: mov             x5, #0xd108
    //     0xbf2bb4: movk            x5, #3, lsl #16
    //     0xbf2bb8: stur            x5, [x4, #-1]
    // 0xbf2bbc: StoreField: r4->field_7 = d0
    //     0xbf2bbc: stur            d0, [x4, #7]
    // 0xbf2bc0: stur            x4, [fp, #-8]
    // 0xbf2bc4: stp             x3, x1, [SP, #-0x10]!
    // 0xbf2bc8: SaveReg r4
    //     0xbf2bc8: str             x4, [SP, #-8]!
    // 0xbf2bcc: r0 = lerpDouble()
    //     0xbf2bcc: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf2bd0: add             SP, SP, #0x18
    // 0xbf2bd4: mov             x1, x0
    // 0xbf2bd8: ldr             x0, [fp, #0x20]
    // 0xbf2bdc: stur            x1, [fp, #-0x10]
    // 0xbf2be0: LoadField: r2 = r0->field_b
    //     0xbf2be0: ldur            w2, [x0, #0xb]
    // 0xbf2be4: DecompressPointer r2
    //     0xbf2be4: add             x2, x2, HEAP, lsl #32
    // 0xbf2be8: ldr             x3, [fp, #0x18]
    // 0xbf2bec: LoadField: r4 = r3->field_b
    //     0xbf2bec: ldur            w4, [x3, #0xb]
    // 0xbf2bf0: DecompressPointer r4
    //     0xbf2bf0: add             x4, x4, HEAP, lsl #32
    // 0xbf2bf4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2bf8: ldur            x16, [fp, #-8]
    // 0xbf2bfc: SaveReg r16
    //     0xbf2bfc: str             x16, [SP, #-8]!
    // 0xbf2c00: r0 = lerp()
    //     0xbf2c00: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2c04: add             SP, SP, #0x18
    // 0xbf2c08: mov             x1, x0
    // 0xbf2c0c: ldr             x0, [fp, #0x20]
    // 0xbf2c10: stur            x1, [fp, #-0x18]
    // 0xbf2c14: LoadField: r2 = r0->field_f
    //     0xbf2c14: ldur            w2, [x0, #0xf]
    // 0xbf2c18: DecompressPointer r2
    //     0xbf2c18: add             x2, x2, HEAP, lsl #32
    // 0xbf2c1c: ldr             x3, [fp, #0x18]
    // 0xbf2c20: LoadField: r4 = r3->field_f
    //     0xbf2c20: ldur            w4, [x3, #0xf]
    // 0xbf2c24: DecompressPointer r4
    //     0xbf2c24: add             x4, x4, HEAP, lsl #32
    // 0xbf2c28: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2c2c: ldur            x16, [fp, #-8]
    // 0xbf2c30: SaveReg r16
    //     0xbf2c30: str             x16, [SP, #-8]!
    // 0xbf2c34: r0 = lerp()
    //     0xbf2c34: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2c38: add             SP, SP, #0x18
    // 0xbf2c3c: mov             x1, x0
    // 0xbf2c40: ldr             x0, [fp, #0x20]
    // 0xbf2c44: stur            x1, [fp, #-0x20]
    // 0xbf2c48: LoadField: r2 = r0->field_13
    //     0xbf2c48: ldur            w2, [x0, #0x13]
    // 0xbf2c4c: DecompressPointer r2
    //     0xbf2c4c: add             x2, x2, HEAP, lsl #32
    // 0xbf2c50: ldr             x3, [fp, #0x18]
    // 0xbf2c54: LoadField: r4 = r3->field_13
    //     0xbf2c54: ldur            w4, [x3, #0x13]
    // 0xbf2c58: DecompressPointer r4
    //     0xbf2c58: add             x4, x4, HEAP, lsl #32
    // 0xbf2c5c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2c60: ldur            x16, [fp, #-8]
    // 0xbf2c64: SaveReg r16
    //     0xbf2c64: str             x16, [SP, #-8]!
    // 0xbf2c68: r0 = lerp()
    //     0xbf2c68: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2c6c: add             SP, SP, #0x18
    // 0xbf2c70: mov             x1, x0
    // 0xbf2c74: ldr             x0, [fp, #0x20]
    // 0xbf2c78: stur            x1, [fp, #-0x28]
    // 0xbf2c7c: LoadField: r2 = r0->field_17
    //     0xbf2c7c: ldur            w2, [x0, #0x17]
    // 0xbf2c80: DecompressPointer r2
    //     0xbf2c80: add             x2, x2, HEAP, lsl #32
    // 0xbf2c84: ldr             x3, [fp, #0x18]
    // 0xbf2c88: LoadField: r4 = r3->field_17
    //     0xbf2c88: ldur            w4, [x3, #0x17]
    // 0xbf2c8c: DecompressPointer r4
    //     0xbf2c8c: add             x4, x4, HEAP, lsl #32
    // 0xbf2c90: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2c94: ldur            x16, [fp, #-8]
    // 0xbf2c98: SaveReg r16
    //     0xbf2c98: str             x16, [SP, #-8]!
    // 0xbf2c9c: r0 = lerp()
    //     0xbf2c9c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2ca0: add             SP, SP, #0x18
    // 0xbf2ca4: mov             x1, x0
    // 0xbf2ca8: ldr             x0, [fp, #0x20]
    // 0xbf2cac: stur            x1, [fp, #-0x30]
    // 0xbf2cb0: LoadField: r2 = r0->field_1f
    //     0xbf2cb0: ldur            w2, [x0, #0x1f]
    // 0xbf2cb4: DecompressPointer r2
    //     0xbf2cb4: add             x2, x2, HEAP, lsl #32
    // 0xbf2cb8: ldr             x3, [fp, #0x18]
    // 0xbf2cbc: LoadField: r4 = r3->field_1f
    //     0xbf2cbc: ldur            w4, [x3, #0x1f]
    // 0xbf2cc0: DecompressPointer r4
    //     0xbf2cc0: add             x4, x4, HEAP, lsl #32
    // 0xbf2cc4: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2cc8: ldur            x16, [fp, #-8]
    // 0xbf2ccc: SaveReg r16
    //     0xbf2ccc: str             x16, [SP, #-8]!
    // 0xbf2cd0: r0 = lerp()
    //     0xbf2cd0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2cd4: add             SP, SP, #0x18
    // 0xbf2cd8: mov             x1, x0
    // 0xbf2cdc: ldr             x0, [fp, #0x20]
    // 0xbf2ce0: stur            x1, [fp, #-0x38]
    // 0xbf2ce4: LoadField: r2 = r0->field_1b
    //     0xbf2ce4: ldur            w2, [x0, #0x1b]
    // 0xbf2ce8: DecompressPointer r2
    //     0xbf2ce8: add             x2, x2, HEAP, lsl #32
    // 0xbf2cec: ldr             x3, [fp, #0x18]
    // 0xbf2cf0: LoadField: r4 = r3->field_1b
    //     0xbf2cf0: ldur            w4, [x3, #0x1b]
    // 0xbf2cf4: DecompressPointer r4
    //     0xbf2cf4: add             x4, x4, HEAP, lsl #32
    // 0xbf2cf8: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2cfc: ldur            x16, [fp, #-8]
    // 0xbf2d00: SaveReg r16
    //     0xbf2d00: str             x16, [SP, #-8]!
    // 0xbf2d04: r0 = lerp()
    //     0xbf2d04: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2d08: add             SP, SP, #0x18
    // 0xbf2d0c: mov             x1, x0
    // 0xbf2d10: ldr             x0, [fp, #0x20]
    // 0xbf2d14: stur            x1, [fp, #-0x40]
    // 0xbf2d18: LoadField: r2 = r0->field_23
    //     0xbf2d18: ldur            w2, [x0, #0x23]
    // 0xbf2d1c: DecompressPointer r2
    //     0xbf2d1c: add             x2, x2, HEAP, lsl #32
    // 0xbf2d20: ldr             x3, [fp, #0x18]
    // 0xbf2d24: LoadField: r4 = r3->field_23
    //     0xbf2d24: ldur            w4, [x3, #0x23]
    // 0xbf2d28: DecompressPointer r4
    //     0xbf2d28: add             x4, x4, HEAP, lsl #32
    // 0xbf2d2c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2d30: ldur            x16, [fp, #-8]
    // 0xbf2d34: SaveReg r16
    //     0xbf2d34: str             x16, [SP, #-8]!
    // 0xbf2d38: r0 = lerp()
    //     0xbf2d38: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2d3c: add             SP, SP, #0x18
    // 0xbf2d40: mov             x1, x0
    // 0xbf2d44: ldr             x0, [fp, #0x20]
    // 0xbf2d48: stur            x1, [fp, #-0x48]
    // 0xbf2d4c: LoadField: r2 = r0->field_27
    //     0xbf2d4c: ldur            w2, [x0, #0x27]
    // 0xbf2d50: DecompressPointer r2
    //     0xbf2d50: add             x2, x2, HEAP, lsl #32
    // 0xbf2d54: ldr             x3, [fp, #0x18]
    // 0xbf2d58: LoadField: r4 = r3->field_27
    //     0xbf2d58: ldur            w4, [x3, #0x27]
    // 0xbf2d5c: DecompressPointer r4
    //     0xbf2d5c: add             x4, x4, HEAP, lsl #32
    // 0xbf2d60: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2d64: ldur            x16, [fp, #-8]
    // 0xbf2d68: SaveReg r16
    //     0xbf2d68: str             x16, [SP, #-8]!
    // 0xbf2d6c: r0 = lerp()
    //     0xbf2d6c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2d70: add             SP, SP, #0x18
    // 0xbf2d74: mov             x1, x0
    // 0xbf2d78: ldr             x0, [fp, #0x20]
    // 0xbf2d7c: stur            x1, [fp, #-0x50]
    // 0xbf2d80: LoadField: r2 = r0->field_2b
    //     0xbf2d80: ldur            w2, [x0, #0x2b]
    // 0xbf2d84: DecompressPointer r2
    //     0xbf2d84: add             x2, x2, HEAP, lsl #32
    // 0xbf2d88: ldr             x3, [fp, #0x18]
    // 0xbf2d8c: LoadField: r4 = r3->field_2b
    //     0xbf2d8c: ldur            w4, [x3, #0x2b]
    // 0xbf2d90: DecompressPointer r4
    //     0xbf2d90: add             x4, x4, HEAP, lsl #32
    // 0xbf2d94: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2d98: ldur            x16, [fp, #-8]
    // 0xbf2d9c: SaveReg r16
    //     0xbf2d9c: str             x16, [SP, #-8]!
    // 0xbf2da0: r0 = lerp()
    //     0xbf2da0: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2da4: add             SP, SP, #0x18
    // 0xbf2da8: mov             x1, x0
    // 0xbf2dac: ldr             x0, [fp, #0x20]
    // 0xbf2db0: stur            x1, [fp, #-0x58]
    // 0xbf2db4: LoadField: r2 = r0->field_2f
    //     0xbf2db4: ldur            w2, [x0, #0x2f]
    // 0xbf2db8: DecompressPointer r2
    //     0xbf2db8: add             x2, x2, HEAP, lsl #32
    // 0xbf2dbc: ldr             x3, [fp, #0x18]
    // 0xbf2dc0: LoadField: r4 = r3->field_2f
    //     0xbf2dc0: ldur            w4, [x3, #0x2f]
    // 0xbf2dc4: DecompressPointer r4
    //     0xbf2dc4: add             x4, x4, HEAP, lsl #32
    // 0xbf2dc8: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2dcc: ldur            x16, [fp, #-8]
    // 0xbf2dd0: SaveReg r16
    //     0xbf2dd0: str             x16, [SP, #-8]!
    // 0xbf2dd4: r0 = lerp()
    //     0xbf2dd4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2dd8: add             SP, SP, #0x18
    // 0xbf2ddc: mov             x1, x0
    // 0xbf2de0: ldr             x0, [fp, #0x20]
    // 0xbf2de4: stur            x1, [fp, #-0x60]
    // 0xbf2de8: LoadField: r2 = r0->field_33
    //     0xbf2de8: ldur            w2, [x0, #0x33]
    // 0xbf2dec: DecompressPointer r2
    //     0xbf2dec: add             x2, x2, HEAP, lsl #32
    // 0xbf2df0: ldr             x3, [fp, #0x18]
    // 0xbf2df4: LoadField: r4 = r3->field_33
    //     0xbf2df4: ldur            w4, [x3, #0x33]
    // 0xbf2df8: DecompressPointer r4
    //     0xbf2df8: add             x4, x4, HEAP, lsl #32
    // 0xbf2dfc: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2e00: ldur            x16, [fp, #-8]
    // 0xbf2e04: SaveReg r16
    //     0xbf2e04: str             x16, [SP, #-8]!
    // 0xbf2e08: r0 = lerp()
    //     0xbf2e08: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2e0c: add             SP, SP, #0x18
    // 0xbf2e10: stur            x0, [fp, #-0x68]
    // 0xbf2e14: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf2e18: ldur            x16, [fp, #-8]
    // 0xbf2e1c: SaveReg r16
    //     0xbf2e1c: str             x16, [SP, #-8]!
    // 0xbf2e20: r0 = lerp()
    //     0xbf2e20: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2e24: add             SP, SP, #0x18
    // 0xbf2e28: ldr             x0, [fp, #0x20]
    // 0xbf2e2c: LoadField: r1 = r0->field_3b
    //     0xbf2e2c: ldur            w1, [x0, #0x3b]
    // 0xbf2e30: DecompressPointer r1
    //     0xbf2e30: add             x1, x1, HEAP, lsl #32
    // 0xbf2e34: ldr             x2, [fp, #0x18]
    // 0xbf2e38: LoadField: r3 = r2->field_3b
    //     0xbf2e38: ldur            w3, [x2, #0x3b]
    // 0xbf2e3c: DecompressPointer r3
    //     0xbf2e3c: add             x3, x3, HEAP, lsl #32
    // 0xbf2e40: stp             x3, x1, [SP, #-0x10]!
    // 0xbf2e44: ldur            x16, [fp, #-8]
    // 0xbf2e48: SaveReg r16
    //     0xbf2e48: str             x16, [SP, #-8]!
    // 0xbf2e4c: r0 = lerp()
    //     0xbf2e4c: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2e50: add             SP, SP, #0x18
    // 0xbf2e54: mov             x1, x0
    // 0xbf2e58: ldr             x0, [fp, #0x20]
    // 0xbf2e5c: stur            x1, [fp, #-0x70]
    // 0xbf2e60: LoadField: r2 = r0->field_3f
    //     0xbf2e60: ldur            w2, [x0, #0x3f]
    // 0xbf2e64: DecompressPointer r2
    //     0xbf2e64: add             x2, x2, HEAP, lsl #32
    // 0xbf2e68: ldr             x3, [fp, #0x18]
    // 0xbf2e6c: LoadField: r4 = r3->field_3f
    //     0xbf2e6c: ldur            w4, [x3, #0x3f]
    // 0xbf2e70: DecompressPointer r4
    //     0xbf2e70: add             x4, x4, HEAP, lsl #32
    // 0xbf2e74: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2e78: ldur            x16, [fp, #-8]
    // 0xbf2e7c: SaveReg r16
    //     0xbf2e7c: str             x16, [SP, #-8]!
    // 0xbf2e80: r0 = lerp()
    //     0xbf2e80: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2e84: add             SP, SP, #0x18
    // 0xbf2e88: mov             x1, x0
    // 0xbf2e8c: ldr             x0, [fp, #0x20]
    // 0xbf2e90: stur            x1, [fp, #-0x78]
    // 0xbf2e94: LoadField: r2 = r0->field_43
    //     0xbf2e94: ldur            w2, [x0, #0x43]
    // 0xbf2e98: DecompressPointer r2
    //     0xbf2e98: add             x2, x2, HEAP, lsl #32
    // 0xbf2e9c: ldr             x3, [fp, #0x18]
    // 0xbf2ea0: LoadField: r4 = r3->field_43
    //     0xbf2ea0: ldur            w4, [x3, #0x43]
    // 0xbf2ea4: DecompressPointer r4
    //     0xbf2ea4: add             x4, x4, HEAP, lsl #32
    // 0xbf2ea8: stp             x4, x2, [SP, #-0x10]!
    // 0xbf2eac: ldur            x16, [fp, #-8]
    // 0xbf2eb0: SaveReg r16
    //     0xbf2eb0: str             x16, [SP, #-8]!
    // 0xbf2eb4: r0 = lerp()
    //     0xbf2eb4: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbf2eb8: add             SP, SP, #0x18
    // 0xbf2ebc: ldr             d1, [fp, #0x10]
    // 0xbf2ec0: d0 = 0.500000
    //     0xbf2ec0: fmov            d0, #0.50000000
    // 0xbf2ec4: stur            x0, [fp, #-0x88]
    // 0xbf2ec8: fcmp            d1, d0
    // 0xbf2ecc: b.vs            #0xbf2ed4
    // 0xbf2ed0: b.lt            #0xbf2edc
    // 0xbf2ed4: r1 = false
    //     0xbf2ed4: add             x1, NULL, #0x30  ; false
    // 0xbf2ed8: b               #0xbf2ee0
    // 0xbf2edc: r1 = true
    //     0xbf2edc: add             x1, NULL, #0x20  ; true
    // 0xbf2ee0: tbnz            w1, #4, #0xbf2efc
    // 0xbf2ee4: ldr             x2, [fp, #0x20]
    // 0xbf2ee8: LoadField: r3 = r2->field_47
    //     0xbf2ee8: ldur            w3, [x2, #0x47]
    // 0xbf2eec: DecompressPointer r3
    //     0xbf2eec: add             x3, x3, HEAP, lsl #32
    // 0xbf2ef0: mov             x4, x3
    // 0xbf2ef4: ldr             x3, [fp, #0x18]
    // 0xbf2ef8: b               #0xbf2f0c
    // 0xbf2efc: ldr             x2, [fp, #0x20]
    // 0xbf2f00: ldr             x3, [fp, #0x18]
    // 0xbf2f04: LoadField: r4 = r3->field_47
    //     0xbf2f04: ldur            w4, [x3, #0x47]
    // 0xbf2f08: DecompressPointer r4
    //     0xbf2f08: add             x4, x4, HEAP, lsl #32
    // 0xbf2f0c: stur            x4, [fp, #-0xb0]
    // 0xbf2f10: tbnz            w1, #4, #0xbf2f20
    // 0xbf2f14: LoadField: r5 = r2->field_4b
    //     0xbf2f14: ldur            w5, [x2, #0x4b]
    // 0xbf2f18: DecompressPointer r5
    //     0xbf2f18: add             x5, x5, HEAP, lsl #32
    // 0xbf2f1c: b               #0xbf2f28
    // 0xbf2f20: LoadField: r5 = r3->field_4b
    //     0xbf2f20: ldur            w5, [x3, #0x4b]
    // 0xbf2f24: DecompressPointer r5
    //     0xbf2f24: add             x5, x5, HEAP, lsl #32
    // 0xbf2f28: stur            x5, [fp, #-0xa8]
    // 0xbf2f2c: tbnz            w1, #4, #0xbf2f3c
    // 0xbf2f30: LoadField: r6 = r2->field_4f
    //     0xbf2f30: ldur            w6, [x2, #0x4f]
    // 0xbf2f34: DecompressPointer r6
    //     0xbf2f34: add             x6, x6, HEAP, lsl #32
    // 0xbf2f38: b               #0xbf2f44
    // 0xbf2f3c: LoadField: r6 = r3->field_4f
    //     0xbf2f3c: ldur            w6, [x3, #0x4f]
    // 0xbf2f40: DecompressPointer r6
    //     0xbf2f40: add             x6, x6, HEAP, lsl #32
    // 0xbf2f44: stur            x6, [fp, #-0xa0]
    // 0xbf2f48: tbnz            w1, #4, #0xbf2f58
    // 0xbf2f4c: LoadField: r7 = r2->field_53
    //     0xbf2f4c: ldur            w7, [x2, #0x53]
    // 0xbf2f50: DecompressPointer r7
    //     0xbf2f50: add             x7, x7, HEAP, lsl #32
    // 0xbf2f54: b               #0xbf2f60
    // 0xbf2f58: LoadField: r7 = r3->field_53
    //     0xbf2f58: ldur            w7, [x3, #0x53]
    // 0xbf2f5c: DecompressPointer r7
    //     0xbf2f5c: add             x7, x7, HEAP, lsl #32
    // 0xbf2f60: stur            x7, [fp, #-0x98]
    // 0xbf2f64: tbnz            w1, #4, #0xbf2f74
    // 0xbf2f68: LoadField: r8 = r2->field_57
    //     0xbf2f68: ldur            w8, [x2, #0x57]
    // 0xbf2f6c: DecompressPointer r8
    //     0xbf2f6c: add             x8, x8, HEAP, lsl #32
    // 0xbf2f70: b               #0xbf2f7c
    // 0xbf2f74: LoadField: r8 = r3->field_57
    //     0xbf2f74: ldur            w8, [x3, #0x57]
    // 0xbf2f78: DecompressPointer r8
    //     0xbf2f78: add             x8, x8, HEAP, lsl #32
    // 0xbf2f7c: stur            x8, [fp, #-0x90]
    // 0xbf2f80: tbnz            w1, #4, #0xbf2f94
    // 0xbf2f84: LoadField: r1 = r2->field_6b
    //     0xbf2f84: ldur            w1, [x2, #0x6b]
    // 0xbf2f88: DecompressPointer r1
    //     0xbf2f88: add             x1, x1, HEAP, lsl #32
    // 0xbf2f8c: stur            x1, [fp, #-0x80]
    // 0xbf2f90: b               #0xbf2fa0
    // 0xbf2f94: LoadField: r1 = r3->field_6b
    //     0xbf2f94: ldur            w1, [x3, #0x6b]
    // 0xbf2f98: DecompressPointer r1
    //     0xbf2f98: add             x1, x1, HEAP, lsl #32
    // 0xbf2f9c: stur            x1, [fp, #-0x80]
    // 0xbf2fa0: ldur            x25, [fp, #-0x20]
    // 0xbf2fa4: ldur            x24, [fp, #-0x28]
    // 0xbf2fa8: ldur            x23, [fp, #-0x30]
    // 0xbf2fac: ldur            x20, [fp, #-0x38]
    // 0xbf2fb0: ldur            x19, [fp, #-0x40]
    // 0xbf2fb4: ldur            x14, [fp, #-0x48]
    // 0xbf2fb8: ldur            x13, [fp, #-0x50]
    // 0xbf2fbc: ldur            x12, [fp, #-0x58]
    // 0xbf2fc0: ldur            x11, [fp, #-0x60]
    // 0xbf2fc4: ldur            x10, [fp, #-0x68]
    // 0xbf2fc8: ldur            x9, [fp, #-0x70]
    // 0xbf2fcc: ldur            x1, [fp, #-0x78]
    // 0xbf2fd0: LoadField: r0 = r2->field_6f
    //     0xbf2fd0: ldur            w0, [x2, #0x6f]
    // 0xbf2fd4: DecompressPointer r0
    //     0xbf2fd4: add             x0, x0, HEAP, lsl #32
    // 0xbf2fd8: LoadField: r1 = r3->field_6f
    //     0xbf2fd8: ldur            w1, [x3, #0x6f]
    // 0xbf2fdc: DecompressPointer r1
    //     0xbf2fdc: add             x1, x1, HEAP, lsl #32
    // 0xbf2fe0: stp             x1, x0, [SP, #-0x10]!
    // 0xbf2fe4: ldur            x16, [fp, #-8]
    // 0xbf2fe8: SaveReg r16
    //     0xbf2fe8: str             x16, [SP, #-8]!
    // 0xbf2fec: r0 = lerp()
    //     0xbf2fec: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf2ff0: add             SP, SP, #0x18
    // 0xbf2ff4: mov             x1, x0
    // 0xbf2ff8: ldr             x0, [fp, #0x20]
    // 0xbf2ffc: stur            x1, [fp, #-0xb8]
    // 0xbf3000: LoadField: r2 = r0->field_73
    //     0xbf3000: ldur            w2, [x0, #0x73]
    // 0xbf3004: DecompressPointer r2
    //     0xbf3004: add             x2, x2, HEAP, lsl #32
    // 0xbf3008: ldr             x0, [fp, #0x18]
    // 0xbf300c: LoadField: r3 = r0->field_73
    //     0xbf300c: ldur            w3, [x0, #0x73]
    // 0xbf3010: DecompressPointer r3
    //     0xbf3010: add             x3, x3, HEAP, lsl #32
    // 0xbf3014: stp             x3, x2, [SP, #-0x10]!
    // 0xbf3018: ldur            x16, [fp, #-8]
    // 0xbf301c: SaveReg r16
    //     0xbf301c: str             x16, [SP, #-8]!
    // 0xbf3020: r0 = lerpDouble()
    //     0xbf3020: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf3024: add             SP, SP, #0x18
    // 0xbf3028: stur            x0, [fp, #-8]
    // 0xbf302c: r0 = SliderThemeData()
    //     0xbf302c: bl              #0x868114  ; AllocateSliderThemeDataStub -> SliderThemeData (size=0x80)
    // 0xbf3030: ldur            x1, [fp, #-0x10]
    // 0xbf3034: StoreField: r0->field_7 = r1
    //     0xbf3034: stur            w1, [x0, #7]
    // 0xbf3038: ldur            x1, [fp, #-0x18]
    // 0xbf303c: StoreField: r0->field_b = r1
    //     0xbf303c: stur            w1, [x0, #0xb]
    // 0xbf3040: ldur            x1, [fp, #-0x20]
    // 0xbf3044: StoreField: r0->field_f = r1
    //     0xbf3044: stur            w1, [x0, #0xf]
    // 0xbf3048: ldur            x1, [fp, #-0x28]
    // 0xbf304c: StoreField: r0->field_13 = r1
    //     0xbf304c: stur            w1, [x0, #0x13]
    // 0xbf3050: ldur            x1, [fp, #-0x30]
    // 0xbf3054: StoreField: r0->field_17 = r1
    //     0xbf3054: stur            w1, [x0, #0x17]
    // 0xbf3058: ldur            x1, [fp, #-0x38]
    // 0xbf305c: StoreField: r0->field_1f = r1
    //     0xbf305c: stur            w1, [x0, #0x1f]
    // 0xbf3060: ldur            x1, [fp, #-0x40]
    // 0xbf3064: StoreField: r0->field_1b = r1
    //     0xbf3064: stur            w1, [x0, #0x1b]
    // 0xbf3068: ldur            x1, [fp, #-0x48]
    // 0xbf306c: StoreField: r0->field_23 = r1
    //     0xbf306c: stur            w1, [x0, #0x23]
    // 0xbf3070: ldur            x1, [fp, #-0x50]
    // 0xbf3074: StoreField: r0->field_27 = r1
    //     0xbf3074: stur            w1, [x0, #0x27]
    // 0xbf3078: ldur            x1, [fp, #-0x58]
    // 0xbf307c: StoreField: r0->field_2b = r1
    //     0xbf307c: stur            w1, [x0, #0x2b]
    // 0xbf3080: ldur            x1, [fp, #-0x60]
    // 0xbf3084: StoreField: r0->field_2f = r1
    //     0xbf3084: stur            w1, [x0, #0x2f]
    // 0xbf3088: ldur            x1, [fp, #-0x68]
    // 0xbf308c: StoreField: r0->field_33 = r1
    //     0xbf308c: stur            w1, [x0, #0x33]
    // 0xbf3090: ldur            x1, [fp, #-0x70]
    // 0xbf3094: StoreField: r0->field_3b = r1
    //     0xbf3094: stur            w1, [x0, #0x3b]
    // 0xbf3098: ldur            x1, [fp, #-0x78]
    // 0xbf309c: StoreField: r0->field_3f = r1
    //     0xbf309c: stur            w1, [x0, #0x3f]
    // 0xbf30a0: ldur            x1, [fp, #-0x88]
    // 0xbf30a4: StoreField: r0->field_43 = r1
    //     0xbf30a4: stur            w1, [x0, #0x43]
    // 0xbf30a8: ldur            x1, [fp, #-0xb0]
    // 0xbf30ac: StoreField: r0->field_47 = r1
    //     0xbf30ac: stur            w1, [x0, #0x47]
    // 0xbf30b0: ldur            x1, [fp, #-0xa8]
    // 0xbf30b4: StoreField: r0->field_4b = r1
    //     0xbf30b4: stur            w1, [x0, #0x4b]
    // 0xbf30b8: ldur            x1, [fp, #-0xa0]
    // 0xbf30bc: StoreField: r0->field_4f = r1
    //     0xbf30bc: stur            w1, [x0, #0x4f]
    // 0xbf30c0: ldur            x1, [fp, #-0x98]
    // 0xbf30c4: StoreField: r0->field_53 = r1
    //     0xbf30c4: stur            w1, [x0, #0x53]
    // 0xbf30c8: ldur            x1, [fp, #-0x90]
    // 0xbf30cc: StoreField: r0->field_57 = r1
    //     0xbf30cc: stur            w1, [x0, #0x57]
    // 0xbf30d0: ldur            x1, [fp, #-0x80]
    // 0xbf30d4: StoreField: r0->field_6b = r1
    //     0xbf30d4: stur            w1, [x0, #0x6b]
    // 0xbf30d8: ldur            x1, [fp, #-0xb8]
    // 0xbf30dc: StoreField: r0->field_6f = r1
    //     0xbf30dc: stur            w1, [x0, #0x6f]
    // 0xbf30e0: ldur            x1, [fp, #-8]
    // 0xbf30e4: StoreField: r0->field_73 = r1
    //     0xbf30e4: stur            w1, [x0, #0x73]
    // 0xbf30e8: LeaveFrame
    //     0xbf30e8: mov             SP, fp
    //     0xbf30ec: ldp             fp, lr, [SP], #0x10
    // 0xbf30f0: ret
    //     0xbf30f0: ret             
    // 0xbf30f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf30f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf30f8: b               #0xbf2b7c
    // 0xbf30fc: SaveReg d0
    //     0xbf30fc: str             q0, [SP, #-0x10]!
    // 0xbf3100: stp             x2, x3, [SP, #-0x10]!
    // 0xbf3104: stp             x0, x1, [SP, #-0x10]!
    // 0xbf3108: r0 = AllocateDouble()
    //     0xbf3108: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf310c: mov             x4, x0
    // 0xbf3110: ldp             x0, x1, [SP], #0x10
    // 0xbf3114: ldp             x2, x3, [SP], #0x10
    // 0xbf3118: RestoreReg d0
    //     0xbf3118: ldr             q0, [SP], #0x10
    // 0xbf311c: b               #0xbf2bbc
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8d930, size: 0x167c
    // 0xc8d930: EnterFrame
    //     0xc8d930: stp             fp, lr, [SP, #-0x10]!
    //     0xc8d934: mov             fp, SP
    // 0xc8d938: AllocStack(0x20)
    //     0xc8d938: sub             SP, SP, #0x20
    // 0xc8d93c: CheckStackOverflow
    //     0xc8d93c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8d940: cmp             SP, x16
    //     0xc8d944: b.ls            #0xc8ef94
    // 0xc8d948: ldr             x1, [fp, #0x10]
    // 0xc8d94c: cmp             w1, NULL
    // 0xc8d950: b.ne            #0xc8d964
    // 0xc8d954: r0 = false
    //     0xc8d954: add             x0, NULL, #0x30  ; false
    // 0xc8d958: LeaveFrame
    //     0xc8d958: mov             SP, fp
    //     0xc8d95c: ldp             fp, lr, [SP], #0x10
    // 0xc8d960: ret
    //     0xc8d960: ret             
    // 0xc8d964: ldr             x2, [fp, #0x18]
    // 0xc8d968: cmp             w2, w1
    // 0xc8d96c: b.ne            #0xc8d980
    // 0xc8d970: r0 = true
    //     0xc8d970: add             x0, NULL, #0x20  ; true
    // 0xc8d974: LeaveFrame
    //     0xc8d974: mov             SP, fp
    //     0xc8d978: ldp             fp, lr, [SP], #0x10
    // 0xc8d97c: ret
    //     0xc8d97c: ret             
    // 0xc8d980: r0 = 59
    //     0xc8d980: mov             x0, #0x3b
    // 0xc8d984: branchIfSmi(r1, 0xc8d990)
    //     0xc8d984: tbz             w1, #0, #0xc8d990
    // 0xc8d988: r0 = LoadClassIdInstr(r1)
    //     0xc8d988: ldur            x0, [x1, #-1]
    //     0xc8d98c: ubfx            x0, x0, #0xc, #0x14
    // 0xc8d990: SaveReg r1
    //     0xc8d990: str             x1, [SP, #-8]!
    // 0xc8d994: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8d994: mov             x17, #0x57c5
    //     0xc8d998: add             lr, x0, x17
    //     0xc8d99c: ldr             lr, [x21, lr, lsl #3]
    //     0xc8d9a0: blr             lr
    // 0xc8d9a4: add             SP, SP, #8
    // 0xc8d9a8: stur            x0, [fp, #-8]
    // 0xc8d9ac: ldr             x16, [fp, #0x18]
    // 0xc8d9b0: SaveReg r16
    //     0xc8d9b0: str             x16, [SP, #-8]!
    // 0xc8d9b4: r0 = runtimeType()
    //     0xc8d9b4: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc8d9b8: add             SP, SP, #8
    // 0xc8d9bc: mov             x1, x0
    // 0xc8d9c0: ldur            x0, [fp, #-8]
    // 0xc8d9c4: r2 = LoadClassIdInstr(r0)
    //     0xc8d9c4: ldur            x2, [x0, #-1]
    //     0xc8d9c8: ubfx            x2, x2, #0xc, #0x14
    // 0xc8d9cc: stp             x1, x0, [SP, #-0x10]!
    // 0xc8d9d0: mov             x0, x2
    // 0xc8d9d4: mov             lr, x0
    // 0xc8d9d8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8d9dc: blr             lr
    // 0xc8d9e0: add             SP, SP, #0x10
    // 0xc8d9e4: tbz             w0, #4, #0xc8d9f8
    // 0xc8d9e8: r0 = false
    //     0xc8d9e8: add             x0, NULL, #0x30  ; false
    // 0xc8d9ec: LeaveFrame
    //     0xc8d9ec: mov             SP, fp
    //     0xc8d9f0: ldp             fp, lr, [SP], #0x10
    // 0xc8d9f4: ret
    //     0xc8d9f4: ret             
    // 0xc8d9f8: ldr             x1, [fp, #0x10]
    // 0xc8d9fc: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8d9fc: mov             x2, #0x76
    //     0xc8da00: tbz             w1, #0, #0xc8da10
    //     0xc8da04: ldur            x2, [x1, #-1]
    //     0xc8da08: ubfx            x2, x2, #0xc, #0x14
    //     0xc8da0c: lsl             x2, x2, #1
    // 0xc8da10: stur            x2, [fp, #-8]
    // 0xc8da14: r0 = LoadInt32Instr(r2)
    //     0xc8da14: sbfx            x0, x2, #1, #0x1f
    // 0xc8da18: cmp             x0, #0xaa7
    // 0xc8da1c: b.lt            #0xc8ef84
    // 0xc8da20: cmp             x0, #0xaa9
    // 0xc8da24: b.gt            #0xc8ef84
    // 0xc8da28: ldr             x3, [fp, #0x18]
    // 0xc8da2c: LoadField: r0 = r1->field_7
    //     0xc8da2c: ldur            w0, [x1, #7]
    // 0xc8da30: DecompressPointer r0
    //     0xc8da30: add             x0, x0, HEAP, lsl #32
    // 0xc8da34: LoadField: r4 = r3->field_7
    //     0xc8da34: ldur            w4, [x3, #7]
    // 0xc8da38: DecompressPointer r4
    //     0xc8da38: add             x4, x4, HEAP, lsl #32
    // 0xc8da3c: r5 = LoadClassIdInstr(r0)
    //     0xc8da3c: ldur            x5, [x0, #-1]
    //     0xc8da40: ubfx            x5, x5, #0xc, #0x14
    // 0xc8da44: stp             x4, x0, [SP, #-0x10]!
    // 0xc8da48: mov             x0, x5
    // 0xc8da4c: mov             lr, x0
    // 0xc8da50: ldr             lr, [x21, lr, lsl #3]
    // 0xc8da54: blr             lr
    // 0xc8da58: add             SP, SP, #0x10
    // 0xc8da5c: tbnz            w0, #4, #0xc8ef84
    // 0xc8da60: ldur            x1, [fp, #-8]
    // 0xc8da64: r17 = 5454
    //     0xc8da64: mov             x17, #0x154e
    // 0xc8da68: cmp             w1, w17
    // 0xc8da6c: b.ne            #0xc8da80
    // 0xc8da70: ldr             x2, [fp, #0x10]
    // 0xc8da74: LoadField: r0 = r2->field_b
    //     0xc8da74: ldur            w0, [x2, #0xb]
    // 0xc8da78: DecompressPointer r0
    //     0xc8da78: add             x0, x0, HEAP, lsl #32
    // 0xc8da7c: b               #0xc8dabc
    // 0xc8da80: ldr             x2, [fp, #0x10]
    // 0xc8da84: r17 = 5456
    //     0xc8da84: mov             x17, #0x1550
    // 0xc8da88: cmp             w1, w17
    // 0xc8da8c: b.ne            #0xc8daa8
    // 0xc8da90: LoadField: r0 = r2->field_83
    //     0xc8da90: ldur            w0, [x2, #0x83]
    // 0xc8da94: DecompressPointer r0
    //     0xc8da94: add             x0, x0, HEAP, lsl #32
    // 0xc8da98: LoadField: r3 = r0->field_b
    //     0xc8da98: ldur            w3, [x0, #0xb]
    // 0xc8da9c: DecompressPointer r3
    //     0xc8da9c: add             x3, x3, HEAP, lsl #32
    // 0xc8daa0: mov             x0, x3
    // 0xc8daa4: b               #0xc8dabc
    // 0xc8daa8: LoadField: r0 = r2->field_83
    //     0xc8daa8: ldur            w0, [x2, #0x83]
    // 0xc8daac: DecompressPointer r0
    //     0xc8daac: add             x0, x0, HEAP, lsl #32
    // 0xc8dab0: LoadField: r3 = r0->field_b
    //     0xc8dab0: ldur            w3, [x0, #0xb]
    // 0xc8dab4: DecompressPointer r3
    //     0xc8dab4: add             x3, x3, HEAP, lsl #32
    // 0xc8dab8: mov             x0, x3
    // 0xc8dabc: ldr             x3, [fp, #0x18]
    // 0xc8dac0: r4 = LoadClassIdInstr(r3)
    //     0xc8dac0: ldur            x4, [x3, #-1]
    //     0xc8dac4: ubfx            x4, x4, #0xc, #0x14
    // 0xc8dac8: lsl             x4, x4, #1
    // 0xc8dacc: stur            x4, [fp, #-0x10]
    // 0xc8dad0: r17 = 5454
    //     0xc8dad0: mov             x17, #0x154e
    // 0xc8dad4: cmp             w4, w17
    // 0xc8dad8: b.ne            #0xc8dae8
    // 0xc8dadc: LoadField: r5 = r3->field_b
    //     0xc8dadc: ldur            w5, [x3, #0xb]
    // 0xc8dae0: DecompressPointer r5
    //     0xc8dae0: add             x5, x5, HEAP, lsl #32
    // 0xc8dae4: b               #0xc8db20
    // 0xc8dae8: r17 = 5456
    //     0xc8dae8: mov             x17, #0x1550
    // 0xc8daec: cmp             w4, w17
    // 0xc8daf0: b.ne            #0xc8db0c
    // 0xc8daf4: LoadField: r5 = r3->field_83
    //     0xc8daf4: ldur            w5, [x3, #0x83]
    // 0xc8daf8: DecompressPointer r5
    //     0xc8daf8: add             x5, x5, HEAP, lsl #32
    // 0xc8dafc: LoadField: r6 = r5->field_b
    //     0xc8dafc: ldur            w6, [x5, #0xb]
    // 0xc8db00: DecompressPointer r6
    //     0xc8db00: add             x6, x6, HEAP, lsl #32
    // 0xc8db04: mov             x5, x6
    // 0xc8db08: b               #0xc8db20
    // 0xc8db0c: LoadField: r5 = r3->field_83
    //     0xc8db0c: ldur            w5, [x3, #0x83]
    // 0xc8db10: DecompressPointer r5
    //     0xc8db10: add             x5, x5, HEAP, lsl #32
    // 0xc8db14: LoadField: r6 = r5->field_b
    //     0xc8db14: ldur            w6, [x5, #0xb]
    // 0xc8db18: DecompressPointer r6
    //     0xc8db18: add             x6, x6, HEAP, lsl #32
    // 0xc8db1c: mov             x5, x6
    // 0xc8db20: r6 = LoadClassIdInstr(r0)
    //     0xc8db20: ldur            x6, [x0, #-1]
    //     0xc8db24: ubfx            x6, x6, #0xc, #0x14
    // 0xc8db28: stp             x5, x0, [SP, #-0x10]!
    // 0xc8db2c: mov             x0, x6
    // 0xc8db30: mov             lr, x0
    // 0xc8db34: ldr             lr, [x21, lr, lsl #3]
    // 0xc8db38: blr             lr
    // 0xc8db3c: add             SP, SP, #0x10
    // 0xc8db40: tbnz            w0, #4, #0xc8ef84
    // 0xc8db44: ldur            x0, [fp, #-8]
    // 0xc8db48: r17 = 5454
    //     0xc8db48: mov             x17, #0x154e
    // 0xc8db4c: cmp             w0, w17
    // 0xc8db50: b.ne            #0xc8db68
    // 0xc8db54: ldr             x1, [fp, #0x10]
    // 0xc8db58: LoadField: r2 = r1->field_f
    //     0xc8db58: ldur            w2, [x1, #0xf]
    // 0xc8db5c: DecompressPointer r2
    //     0xc8db5c: add             x2, x2, HEAP, lsl #32
    // 0xc8db60: mov             x1, x2
    // 0xc8db64: b               #0xc8dbd8
    // 0xc8db68: ldr             x1, [fp, #0x10]
    // 0xc8db6c: r17 = 5456
    //     0xc8db6c: mov             x17, #0x1550
    // 0xc8db70: cmp             w0, w17
    // 0xc8db74: b.ne            #0xc8dbac
    // 0xc8db78: LoadField: r2 = r1->field_83
    //     0xc8db78: ldur            w2, [x1, #0x83]
    // 0xc8db7c: DecompressPointer r2
    //     0xc8db7c: add             x2, x2, HEAP, lsl #32
    // 0xc8db80: LoadField: r3 = r2->field_5b
    //     0xc8db80: ldur            w3, [x2, #0x5b]
    // 0xc8db84: DecompressPointer r3
    //     0xc8db84: add             x3, x3, HEAP, lsl #32
    // 0xc8db88: cmp             w3, NULL
    // 0xc8db8c: b.ne            #0xc8dba0
    // 0xc8db90: LoadField: r3 = r2->field_53
    //     0xc8db90: ldur            w3, [x2, #0x53]
    // 0xc8db94: DecompressPointer r3
    //     0xc8db94: add             x3, x3, HEAP, lsl #32
    // 0xc8db98: mov             x2, x3
    // 0xc8db9c: b               #0xc8dba4
    // 0xc8dba0: mov             x2, x3
    // 0xc8dba4: mov             x1, x2
    // 0xc8dba8: b               #0xc8dbd8
    // 0xc8dbac: d0 = 0.240000
    //     0xc8dbac: add             x17, PP, #0xe, lsl #12  ; [pp+0xe130] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0xc8dbb0: ldr             d0, [x17, #0x130]
    // 0xc8dbb4: LoadField: r2 = r1->field_83
    //     0xc8dbb4: ldur            w2, [x1, #0x83]
    // 0xc8dbb8: DecompressPointer r2
    //     0xc8dbb8: add             x2, x2, HEAP, lsl #32
    // 0xc8dbbc: LoadField: r3 = r2->field_b
    //     0xc8dbbc: ldur            w3, [x2, #0xb]
    // 0xc8dbc0: DecompressPointer r3
    //     0xc8dbc0: add             x3, x3, HEAP, lsl #32
    // 0xc8dbc4: SaveReg r3
    //     0xc8dbc4: str             x3, [SP, #-8]!
    // 0xc8dbc8: SaveReg d0
    //     0xc8dbc8: str             d0, [SP, #-8]!
    // 0xc8dbcc: r0 = withOpacity()
    //     0xc8dbcc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dbd0: add             SP, SP, #0x10
    // 0xc8dbd4: mov             x1, x0
    // 0xc8dbd8: ldur            x0, [fp, #-0x10]
    // 0xc8dbdc: stur            x1, [fp, #-0x18]
    // 0xc8dbe0: r17 = 5454
    //     0xc8dbe0: mov             x17, #0x154e
    // 0xc8dbe4: cmp             w0, w17
    // 0xc8dbe8: b.ne            #0xc8dc04
    // 0xc8dbec: ldr             x2, [fp, #0x18]
    // 0xc8dbf0: LoadField: r3 = r2->field_f
    //     0xc8dbf0: ldur            w3, [x2, #0xf]
    // 0xc8dbf4: DecompressPointer r3
    //     0xc8dbf4: add             x3, x3, HEAP, lsl #32
    // 0xc8dbf8: mov             x0, x1
    // 0xc8dbfc: mov             x1, x3
    // 0xc8dc00: b               #0xc8dc7c
    // 0xc8dc04: ldr             x2, [fp, #0x18]
    // 0xc8dc08: r17 = 5456
    //     0xc8dc08: mov             x17, #0x1550
    // 0xc8dc0c: cmp             w0, w17
    // 0xc8dc10: b.ne            #0xc8dc4c
    // 0xc8dc14: LoadField: r3 = r2->field_83
    //     0xc8dc14: ldur            w3, [x2, #0x83]
    // 0xc8dc18: DecompressPointer r3
    //     0xc8dc18: add             x3, x3, HEAP, lsl #32
    // 0xc8dc1c: LoadField: r4 = r3->field_5b
    //     0xc8dc1c: ldur            w4, [x3, #0x5b]
    // 0xc8dc20: DecompressPointer r4
    //     0xc8dc20: add             x4, x4, HEAP, lsl #32
    // 0xc8dc24: cmp             w4, NULL
    // 0xc8dc28: b.ne            #0xc8dc3c
    // 0xc8dc2c: LoadField: r4 = r3->field_53
    //     0xc8dc2c: ldur            w4, [x3, #0x53]
    // 0xc8dc30: DecompressPointer r4
    //     0xc8dc30: add             x4, x4, HEAP, lsl #32
    // 0xc8dc34: mov             x3, x4
    // 0xc8dc38: b               #0xc8dc40
    // 0xc8dc3c: mov             x3, x4
    // 0xc8dc40: mov             x0, x1
    // 0xc8dc44: mov             x1, x3
    // 0xc8dc48: b               #0xc8dc7c
    // 0xc8dc4c: d0 = 0.240000
    //     0xc8dc4c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe130] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0xc8dc50: ldr             d0, [x17, #0x130]
    // 0xc8dc54: LoadField: r3 = r2->field_83
    //     0xc8dc54: ldur            w3, [x2, #0x83]
    // 0xc8dc58: DecompressPointer r3
    //     0xc8dc58: add             x3, x3, HEAP, lsl #32
    // 0xc8dc5c: LoadField: r4 = r3->field_b
    //     0xc8dc5c: ldur            w4, [x3, #0xb]
    // 0xc8dc60: DecompressPointer r4
    //     0xc8dc60: add             x4, x4, HEAP, lsl #32
    // 0xc8dc64: SaveReg r4
    //     0xc8dc64: str             x4, [SP, #-8]!
    // 0xc8dc68: SaveReg d0
    //     0xc8dc68: str             d0, [SP, #-8]!
    // 0xc8dc6c: r0 = withOpacity()
    //     0xc8dc6c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dc70: add             SP, SP, #0x10
    // 0xc8dc74: mov             x1, x0
    // 0xc8dc78: ldur            x0, [fp, #-0x18]
    // 0xc8dc7c: r2 = LoadClassIdInstr(r0)
    //     0xc8dc7c: ldur            x2, [x0, #-1]
    //     0xc8dc80: ubfx            x2, x2, #0xc, #0x14
    // 0xc8dc84: stp             x1, x0, [SP, #-0x10]!
    // 0xc8dc88: mov             x0, x2
    // 0xc8dc8c: mov             lr, x0
    // 0xc8dc90: ldr             lr, [x21, lr, lsl #3]
    // 0xc8dc94: blr             lr
    // 0xc8dc98: add             SP, SP, #0x10
    // 0xc8dc9c: tbnz            w0, #4, #0xc8ef84
    // 0xc8dca0: ldur            x0, [fp, #-8]
    // 0xc8dca4: r17 = 5454
    //     0xc8dca4: mov             x17, #0x154e
    // 0xc8dca8: cmp             w0, w17
    // 0xc8dcac: b.ne            #0xc8dcc4
    // 0xc8dcb0: ldr             x1, [fp, #0x10]
    // 0xc8dcb4: LoadField: r2 = r1->field_13
    //     0xc8dcb4: ldur            w2, [x1, #0x13]
    // 0xc8dcb8: DecompressPointer r2
    //     0xc8dcb8: add             x2, x2, HEAP, lsl #32
    // 0xc8dcbc: mov             x1, x2
    // 0xc8dcc0: b               #0xc8dd34
    // 0xc8dcc4: ldr             x1, [fp, #0x10]
    // 0xc8dcc8: r17 = 5456
    //     0xc8dcc8: mov             x17, #0x1550
    // 0xc8dccc: cmp             w0, w17
    // 0xc8dcd0: b.ne            #0xc8dd04
    // 0xc8dcd4: d0 = 0.540000
    //     0xc8dcd4: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8dcd8: ldr             d0, [x17, #0x138]
    // 0xc8dcdc: LoadField: r2 = r1->field_83
    //     0xc8dcdc: ldur            w2, [x1, #0x83]
    // 0xc8dce0: DecompressPointer r2
    //     0xc8dce0: add             x2, x2, HEAP, lsl #32
    // 0xc8dce4: LoadField: r3 = r2->field_b
    //     0xc8dce4: ldur            w3, [x2, #0xb]
    // 0xc8dce8: DecompressPointer r3
    //     0xc8dce8: add             x3, x3, HEAP, lsl #32
    // 0xc8dcec: SaveReg r3
    //     0xc8dcec: str             x3, [SP, #-8]!
    // 0xc8dcf0: SaveReg d0
    //     0xc8dcf0: str             d0, [SP, #-8]!
    // 0xc8dcf4: r0 = withOpacity()
    //     0xc8dcf4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dcf8: add             SP, SP, #0x10
    // 0xc8dcfc: mov             x1, x0
    // 0xc8dd00: b               #0xc8dd34
    // 0xc8dd04: mov             x0, x1
    // 0xc8dd08: d0 = 0.540000
    //     0xc8dd08: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8dd0c: ldr             d0, [x17, #0x138]
    // 0xc8dd10: LoadField: r1 = r0->field_83
    //     0xc8dd10: ldur            w1, [x0, #0x83]
    // 0xc8dd14: DecompressPointer r1
    //     0xc8dd14: add             x1, x1, HEAP, lsl #32
    // 0xc8dd18: LoadField: r2 = r1->field_b
    //     0xc8dd18: ldur            w2, [x1, #0xb]
    // 0xc8dd1c: DecompressPointer r2
    //     0xc8dd1c: add             x2, x2, HEAP, lsl #32
    // 0xc8dd20: SaveReg r2
    //     0xc8dd20: str             x2, [SP, #-8]!
    // 0xc8dd24: SaveReg d0
    //     0xc8dd24: str             d0, [SP, #-8]!
    // 0xc8dd28: r0 = withOpacity()
    //     0xc8dd28: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dd2c: add             SP, SP, #0x10
    // 0xc8dd30: mov             x1, x0
    // 0xc8dd34: ldur            x0, [fp, #-0x10]
    // 0xc8dd38: stur            x1, [fp, #-0x18]
    // 0xc8dd3c: r17 = 5454
    //     0xc8dd3c: mov             x17, #0x154e
    // 0xc8dd40: cmp             w0, w17
    // 0xc8dd44: b.ne            #0xc8dd60
    // 0xc8dd48: ldr             x2, [fp, #0x18]
    // 0xc8dd4c: LoadField: r3 = r2->field_13
    //     0xc8dd4c: ldur            w3, [x2, #0x13]
    // 0xc8dd50: DecompressPointer r3
    //     0xc8dd50: add             x3, x3, HEAP, lsl #32
    // 0xc8dd54: mov             x0, x1
    // 0xc8dd58: mov             x1, x3
    // 0xc8dd5c: b               #0xc8ddd8
    // 0xc8dd60: ldr             x2, [fp, #0x18]
    // 0xc8dd64: r17 = 5456
    //     0xc8dd64: mov             x17, #0x1550
    // 0xc8dd68: cmp             w0, w17
    // 0xc8dd6c: b.ne            #0xc8dda4
    // 0xc8dd70: d0 = 0.540000
    //     0xc8dd70: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8dd74: ldr             d0, [x17, #0x138]
    // 0xc8dd78: LoadField: r3 = r2->field_83
    //     0xc8dd78: ldur            w3, [x2, #0x83]
    // 0xc8dd7c: DecompressPointer r3
    //     0xc8dd7c: add             x3, x3, HEAP, lsl #32
    // 0xc8dd80: LoadField: r4 = r3->field_b
    //     0xc8dd80: ldur            w4, [x3, #0xb]
    // 0xc8dd84: DecompressPointer r4
    //     0xc8dd84: add             x4, x4, HEAP, lsl #32
    // 0xc8dd88: SaveReg r4
    //     0xc8dd88: str             x4, [SP, #-8]!
    // 0xc8dd8c: SaveReg d0
    //     0xc8dd8c: str             d0, [SP, #-8]!
    // 0xc8dd90: r0 = withOpacity()
    //     0xc8dd90: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dd94: add             SP, SP, #0x10
    // 0xc8dd98: mov             x1, x0
    // 0xc8dd9c: ldur            x0, [fp, #-0x18]
    // 0xc8dda0: b               #0xc8ddd8
    // 0xc8dda4: mov             x0, x2
    // 0xc8dda8: d0 = 0.540000
    //     0xc8dda8: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8ddac: ldr             d0, [x17, #0x138]
    // 0xc8ddb0: LoadField: r1 = r0->field_83
    //     0xc8ddb0: ldur            w1, [x0, #0x83]
    // 0xc8ddb4: DecompressPointer r1
    //     0xc8ddb4: add             x1, x1, HEAP, lsl #32
    // 0xc8ddb8: LoadField: r2 = r1->field_b
    //     0xc8ddb8: ldur            w2, [x1, #0xb]
    // 0xc8ddbc: DecompressPointer r2
    //     0xc8ddbc: add             x2, x2, HEAP, lsl #32
    // 0xc8ddc0: SaveReg r2
    //     0xc8ddc0: str             x2, [SP, #-8]!
    // 0xc8ddc4: SaveReg d0
    //     0xc8ddc4: str             d0, [SP, #-8]!
    // 0xc8ddc8: r0 = withOpacity()
    //     0xc8ddc8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8ddcc: add             SP, SP, #0x10
    // 0xc8ddd0: mov             x1, x0
    // 0xc8ddd4: ldur            x0, [fp, #-0x18]
    // 0xc8ddd8: r2 = LoadClassIdInstr(r0)
    //     0xc8ddd8: ldur            x2, [x0, #-1]
    //     0xc8dddc: ubfx            x2, x2, #0xc, #0x14
    // 0xc8dde0: stp             x1, x0, [SP, #-0x10]!
    // 0xc8dde4: mov             x0, x2
    // 0xc8dde8: mov             lr, x0
    // 0xc8ddec: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ddf0: blr             lr
    // 0xc8ddf4: add             SP, SP, #0x10
    // 0xc8ddf8: tbnz            w0, #4, #0xc8ef84
    // 0xc8ddfc: ldur            x0, [fp, #-8]
    // 0xc8de00: r17 = 5454
    //     0xc8de00: mov             x17, #0x154e
    // 0xc8de04: cmp             w0, w17
    // 0xc8de08: b.ne            #0xc8de20
    // 0xc8de0c: ldr             x1, [fp, #0x10]
    // 0xc8de10: LoadField: r2 = r1->field_17
    //     0xc8de10: ldur            w2, [x1, #0x17]
    // 0xc8de14: DecompressPointer r2
    //     0xc8de14: add             x2, x2, HEAP, lsl #32
    // 0xc8de18: mov             x1, x2
    // 0xc8de1c: b               #0xc8de90
    // 0xc8de20: ldr             x1, [fp, #0x10]
    // 0xc8de24: r17 = 5456
    //     0xc8de24: mov             x17, #0x1550
    // 0xc8de28: cmp             w0, w17
    // 0xc8de2c: b.ne            #0xc8de60
    // 0xc8de30: d0 = 0.380000
    //     0xc8de30: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8de34: ldr             d0, [x17, #0x140]
    // 0xc8de38: LoadField: r2 = r1->field_83
    //     0xc8de38: ldur            w2, [x1, #0x83]
    // 0xc8de3c: DecompressPointer r2
    //     0xc8de3c: add             x2, x2, HEAP, lsl #32
    // 0xc8de40: LoadField: r3 = r2->field_57
    //     0xc8de40: ldur            w3, [x2, #0x57]
    // 0xc8de44: DecompressPointer r3
    //     0xc8de44: add             x3, x3, HEAP, lsl #32
    // 0xc8de48: SaveReg r3
    //     0xc8de48: str             x3, [SP, #-8]!
    // 0xc8de4c: SaveReg d0
    //     0xc8de4c: str             d0, [SP, #-8]!
    // 0xc8de50: r0 = withOpacity()
    //     0xc8de50: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8de54: add             SP, SP, #0x10
    // 0xc8de58: mov             x1, x0
    // 0xc8de5c: b               #0xc8de90
    // 0xc8de60: mov             x0, x1
    // 0xc8de64: d0 = 0.320000
    //     0xc8de64: add             x17, PP, #0xe, lsl #12  ; [pp+0xe148] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0xc8de68: ldr             d0, [x17, #0x148]
    // 0xc8de6c: LoadField: r1 = r0->field_83
    //     0xc8de6c: ldur            w1, [x0, #0x83]
    // 0xc8de70: DecompressPointer r1
    //     0xc8de70: add             x1, x1, HEAP, lsl #32
    // 0xc8de74: LoadField: r2 = r1->field_57
    //     0xc8de74: ldur            w2, [x1, #0x57]
    // 0xc8de78: DecompressPointer r2
    //     0xc8de78: add             x2, x2, HEAP, lsl #32
    // 0xc8de7c: SaveReg r2
    //     0xc8de7c: str             x2, [SP, #-8]!
    // 0xc8de80: SaveReg d0
    //     0xc8de80: str             d0, [SP, #-8]!
    // 0xc8de84: r0 = withOpacity()
    //     0xc8de84: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8de88: add             SP, SP, #0x10
    // 0xc8de8c: mov             x1, x0
    // 0xc8de90: ldur            x0, [fp, #-0x10]
    // 0xc8de94: stur            x1, [fp, #-0x18]
    // 0xc8de98: r17 = 5454
    //     0xc8de98: mov             x17, #0x154e
    // 0xc8de9c: cmp             w0, w17
    // 0xc8dea0: b.ne            #0xc8debc
    // 0xc8dea4: ldr             x2, [fp, #0x18]
    // 0xc8dea8: LoadField: r3 = r2->field_17
    //     0xc8dea8: ldur            w3, [x2, #0x17]
    // 0xc8deac: DecompressPointer r3
    //     0xc8deac: add             x3, x3, HEAP, lsl #32
    // 0xc8deb0: mov             x0, x1
    // 0xc8deb4: mov             x1, x3
    // 0xc8deb8: b               #0xc8df34
    // 0xc8debc: ldr             x2, [fp, #0x18]
    // 0xc8dec0: r17 = 5456
    //     0xc8dec0: mov             x17, #0x1550
    // 0xc8dec4: cmp             w0, w17
    // 0xc8dec8: b.ne            #0xc8df00
    // 0xc8decc: d0 = 0.380000
    //     0xc8decc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8ded0: ldr             d0, [x17, #0x140]
    // 0xc8ded4: LoadField: r3 = r2->field_83
    //     0xc8ded4: ldur            w3, [x2, #0x83]
    // 0xc8ded8: DecompressPointer r3
    //     0xc8ded8: add             x3, x3, HEAP, lsl #32
    // 0xc8dedc: LoadField: r4 = r3->field_57
    //     0xc8dedc: ldur            w4, [x3, #0x57]
    // 0xc8dee0: DecompressPointer r4
    //     0xc8dee0: add             x4, x4, HEAP, lsl #32
    // 0xc8dee4: SaveReg r4
    //     0xc8dee4: str             x4, [SP, #-8]!
    // 0xc8dee8: SaveReg d0
    //     0xc8dee8: str             d0, [SP, #-8]!
    // 0xc8deec: r0 = withOpacity()
    //     0xc8deec: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8def0: add             SP, SP, #0x10
    // 0xc8def4: mov             x1, x0
    // 0xc8def8: ldur            x0, [fp, #-0x18]
    // 0xc8defc: b               #0xc8df34
    // 0xc8df00: mov             x0, x2
    // 0xc8df04: d0 = 0.320000
    //     0xc8df04: add             x17, PP, #0xe, lsl #12  ; [pp+0xe148] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0xc8df08: ldr             d0, [x17, #0x148]
    // 0xc8df0c: LoadField: r1 = r0->field_83
    //     0xc8df0c: ldur            w1, [x0, #0x83]
    // 0xc8df10: DecompressPointer r1
    //     0xc8df10: add             x1, x1, HEAP, lsl #32
    // 0xc8df14: LoadField: r2 = r1->field_57
    //     0xc8df14: ldur            w2, [x1, #0x57]
    // 0xc8df18: DecompressPointer r2
    //     0xc8df18: add             x2, x2, HEAP, lsl #32
    // 0xc8df1c: SaveReg r2
    //     0xc8df1c: str             x2, [SP, #-8]!
    // 0xc8df20: SaveReg d0
    //     0xc8df20: str             d0, [SP, #-8]!
    // 0xc8df24: r0 = withOpacity()
    //     0xc8df24: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8df28: add             SP, SP, #0x10
    // 0xc8df2c: mov             x1, x0
    // 0xc8df30: ldur            x0, [fp, #-0x18]
    // 0xc8df34: r2 = LoadClassIdInstr(r0)
    //     0xc8df34: ldur            x2, [x0, #-1]
    //     0xc8df38: ubfx            x2, x2, #0xc, #0x14
    // 0xc8df3c: stp             x1, x0, [SP, #-0x10]!
    // 0xc8df40: mov             x0, x2
    // 0xc8df44: mov             lr, x0
    // 0xc8df48: ldr             lr, [x21, lr, lsl #3]
    // 0xc8df4c: blr             lr
    // 0xc8df50: add             SP, SP, #0x10
    // 0xc8df54: tbnz            w0, #4, #0xc8ef84
    // 0xc8df58: ldur            x0, [fp, #-8]
    // 0xc8df5c: r17 = 5454
    //     0xc8df5c: mov             x17, #0x154e
    // 0xc8df60: cmp             w0, w17
    // 0xc8df64: b.ne            #0xc8df7c
    // 0xc8df68: ldr             x1, [fp, #0x10]
    // 0xc8df6c: LoadField: r2 = r1->field_1f
    //     0xc8df6c: ldur            w2, [x1, #0x1f]
    // 0xc8df70: DecompressPointer r2
    //     0xc8df70: add             x2, x2, HEAP, lsl #32
    // 0xc8df74: mov             x1, x2
    // 0xc8df78: b               #0xc8dfec
    // 0xc8df7c: ldr             x1, [fp, #0x10]
    // 0xc8df80: r17 = 5456
    //     0xc8df80: mov             x17, #0x1550
    // 0xc8df84: cmp             w0, w17
    // 0xc8df88: b.ne            #0xc8dfbc
    // 0xc8df8c: d0 = 0.120000
    //     0xc8df8c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8df90: ldr             d0, [x17, #0xf48]
    // 0xc8df94: LoadField: r2 = r1->field_83
    //     0xc8df94: ldur            w2, [x1, #0x83]
    // 0xc8df98: DecompressPointer r2
    //     0xc8df98: add             x2, x2, HEAP, lsl #32
    // 0xc8df9c: LoadField: r3 = r2->field_57
    //     0xc8df9c: ldur            w3, [x2, #0x57]
    // 0xc8dfa0: DecompressPointer r3
    //     0xc8dfa0: add             x3, x3, HEAP, lsl #32
    // 0xc8dfa4: SaveReg r3
    //     0xc8dfa4: str             x3, [SP, #-8]!
    // 0xc8dfa8: SaveReg d0
    //     0xc8dfa8: str             d0, [SP, #-8]!
    // 0xc8dfac: r0 = withOpacity()
    //     0xc8dfac: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dfb0: add             SP, SP, #0x10
    // 0xc8dfb4: mov             x1, x0
    // 0xc8dfb8: b               #0xc8dfec
    // 0xc8dfbc: mov             x0, x1
    // 0xc8dfc0: d0 = 0.120000
    //     0xc8dfc0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8dfc4: ldr             d0, [x17, #0xf48]
    // 0xc8dfc8: LoadField: r1 = r0->field_83
    //     0xc8dfc8: ldur            w1, [x0, #0x83]
    // 0xc8dfcc: DecompressPointer r1
    //     0xc8dfcc: add             x1, x1, HEAP, lsl #32
    // 0xc8dfd0: LoadField: r2 = r1->field_57
    //     0xc8dfd0: ldur            w2, [x1, #0x57]
    // 0xc8dfd4: DecompressPointer r2
    //     0xc8dfd4: add             x2, x2, HEAP, lsl #32
    // 0xc8dfd8: SaveReg r2
    //     0xc8dfd8: str             x2, [SP, #-8]!
    // 0xc8dfdc: SaveReg d0
    //     0xc8dfdc: str             d0, [SP, #-8]!
    // 0xc8dfe0: r0 = withOpacity()
    //     0xc8dfe0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8dfe4: add             SP, SP, #0x10
    // 0xc8dfe8: mov             x1, x0
    // 0xc8dfec: ldur            x0, [fp, #-0x10]
    // 0xc8dff0: stur            x1, [fp, #-0x18]
    // 0xc8dff4: r17 = 5454
    //     0xc8dff4: mov             x17, #0x154e
    // 0xc8dff8: cmp             w0, w17
    // 0xc8dffc: b.ne            #0xc8e018
    // 0xc8e000: ldr             x2, [fp, #0x18]
    // 0xc8e004: LoadField: r3 = r2->field_1f
    //     0xc8e004: ldur            w3, [x2, #0x1f]
    // 0xc8e008: DecompressPointer r3
    //     0xc8e008: add             x3, x3, HEAP, lsl #32
    // 0xc8e00c: mov             x0, x1
    // 0xc8e010: mov             x1, x3
    // 0xc8e014: b               #0xc8e090
    // 0xc8e018: ldr             x2, [fp, #0x18]
    // 0xc8e01c: r17 = 5456
    //     0xc8e01c: mov             x17, #0x1550
    // 0xc8e020: cmp             w0, w17
    // 0xc8e024: b.ne            #0xc8e05c
    // 0xc8e028: d0 = 0.120000
    //     0xc8e028: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e02c: ldr             d0, [x17, #0xf48]
    // 0xc8e030: LoadField: r3 = r2->field_83
    //     0xc8e030: ldur            w3, [x2, #0x83]
    // 0xc8e034: DecompressPointer r3
    //     0xc8e034: add             x3, x3, HEAP, lsl #32
    // 0xc8e038: LoadField: r4 = r3->field_57
    //     0xc8e038: ldur            w4, [x3, #0x57]
    // 0xc8e03c: DecompressPointer r4
    //     0xc8e03c: add             x4, x4, HEAP, lsl #32
    // 0xc8e040: SaveReg r4
    //     0xc8e040: str             x4, [SP, #-8]!
    // 0xc8e044: SaveReg d0
    //     0xc8e044: str             d0, [SP, #-8]!
    // 0xc8e048: r0 = withOpacity()
    //     0xc8e048: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e04c: add             SP, SP, #0x10
    // 0xc8e050: mov             x1, x0
    // 0xc8e054: ldur            x0, [fp, #-0x18]
    // 0xc8e058: b               #0xc8e090
    // 0xc8e05c: mov             x0, x2
    // 0xc8e060: d0 = 0.120000
    //     0xc8e060: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e064: ldr             d0, [x17, #0xf48]
    // 0xc8e068: LoadField: r1 = r0->field_83
    //     0xc8e068: ldur            w1, [x0, #0x83]
    // 0xc8e06c: DecompressPointer r1
    //     0xc8e06c: add             x1, x1, HEAP, lsl #32
    // 0xc8e070: LoadField: r2 = r1->field_57
    //     0xc8e070: ldur            w2, [x1, #0x57]
    // 0xc8e074: DecompressPointer r2
    //     0xc8e074: add             x2, x2, HEAP, lsl #32
    // 0xc8e078: SaveReg r2
    //     0xc8e078: str             x2, [SP, #-8]!
    // 0xc8e07c: SaveReg d0
    //     0xc8e07c: str             d0, [SP, #-8]!
    // 0xc8e080: r0 = withOpacity()
    //     0xc8e080: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e084: add             SP, SP, #0x10
    // 0xc8e088: mov             x1, x0
    // 0xc8e08c: ldur            x0, [fp, #-0x18]
    // 0xc8e090: r2 = LoadClassIdInstr(r0)
    //     0xc8e090: ldur            x2, [x0, #-1]
    //     0xc8e094: ubfx            x2, x2, #0xc, #0x14
    // 0xc8e098: stp             x1, x0, [SP, #-0x10]!
    // 0xc8e09c: mov             x0, x2
    // 0xc8e0a0: mov             lr, x0
    // 0xc8e0a4: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e0a8: blr             lr
    // 0xc8e0ac: add             SP, SP, #0x10
    // 0xc8e0b0: tbnz            w0, #4, #0xc8ef84
    // 0xc8e0b4: ldur            x0, [fp, #-8]
    // 0xc8e0b8: r17 = 5454
    //     0xc8e0b8: mov             x17, #0x154e
    // 0xc8e0bc: cmp             w0, w17
    // 0xc8e0c0: b.ne            #0xc8e0d8
    // 0xc8e0c4: ldr             x1, [fp, #0x10]
    // 0xc8e0c8: LoadField: r2 = r1->field_1b
    //     0xc8e0c8: ldur            w2, [x1, #0x1b]
    // 0xc8e0cc: DecompressPointer r2
    //     0xc8e0cc: add             x2, x2, HEAP, lsl #32
    // 0xc8e0d0: mov             x1, x2
    // 0xc8e0d4: b               #0xc8e148
    // 0xc8e0d8: ldr             x1, [fp, #0x10]
    // 0xc8e0dc: r17 = 5456
    //     0xc8e0dc: mov             x17, #0x1550
    // 0xc8e0e0: cmp             w0, w17
    // 0xc8e0e4: b.ne            #0xc8e118
    // 0xc8e0e8: d0 = 0.120000
    //     0xc8e0e8: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e0ec: ldr             d0, [x17, #0xf48]
    // 0xc8e0f0: LoadField: r2 = r1->field_83
    //     0xc8e0f0: ldur            w2, [x1, #0x83]
    // 0xc8e0f4: DecompressPointer r2
    //     0xc8e0f4: add             x2, x2, HEAP, lsl #32
    // 0xc8e0f8: LoadField: r3 = r2->field_57
    //     0xc8e0f8: ldur            w3, [x2, #0x57]
    // 0xc8e0fc: DecompressPointer r3
    //     0xc8e0fc: add             x3, x3, HEAP, lsl #32
    // 0xc8e100: SaveReg r3
    //     0xc8e100: str             x3, [SP, #-8]!
    // 0xc8e104: SaveReg d0
    //     0xc8e104: str             d0, [SP, #-8]!
    // 0xc8e108: r0 = withOpacity()
    //     0xc8e108: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e10c: add             SP, SP, #0x10
    // 0xc8e110: mov             x1, x0
    // 0xc8e114: b               #0xc8e148
    // 0xc8e118: mov             x0, x1
    // 0xc8e11c: d0 = 0.120000
    //     0xc8e11c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e120: ldr             d0, [x17, #0xf48]
    // 0xc8e124: LoadField: r1 = r0->field_83
    //     0xc8e124: ldur            w1, [x0, #0x83]
    // 0xc8e128: DecompressPointer r1
    //     0xc8e128: add             x1, x1, HEAP, lsl #32
    // 0xc8e12c: LoadField: r2 = r1->field_57
    //     0xc8e12c: ldur            w2, [x1, #0x57]
    // 0xc8e130: DecompressPointer r2
    //     0xc8e130: add             x2, x2, HEAP, lsl #32
    // 0xc8e134: SaveReg r2
    //     0xc8e134: str             x2, [SP, #-8]!
    // 0xc8e138: SaveReg d0
    //     0xc8e138: str             d0, [SP, #-8]!
    // 0xc8e13c: r0 = withOpacity()
    //     0xc8e13c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e140: add             SP, SP, #0x10
    // 0xc8e144: mov             x1, x0
    // 0xc8e148: ldur            x0, [fp, #-0x10]
    // 0xc8e14c: stur            x1, [fp, #-0x18]
    // 0xc8e150: r17 = 5454
    //     0xc8e150: mov             x17, #0x154e
    // 0xc8e154: cmp             w0, w17
    // 0xc8e158: b.ne            #0xc8e174
    // 0xc8e15c: ldr             x2, [fp, #0x18]
    // 0xc8e160: LoadField: r3 = r2->field_1b
    //     0xc8e160: ldur            w3, [x2, #0x1b]
    // 0xc8e164: DecompressPointer r3
    //     0xc8e164: add             x3, x3, HEAP, lsl #32
    // 0xc8e168: mov             x0, x1
    // 0xc8e16c: mov             x1, x3
    // 0xc8e170: b               #0xc8e1ec
    // 0xc8e174: ldr             x2, [fp, #0x18]
    // 0xc8e178: r17 = 5456
    //     0xc8e178: mov             x17, #0x1550
    // 0xc8e17c: cmp             w0, w17
    // 0xc8e180: b.ne            #0xc8e1b8
    // 0xc8e184: d0 = 0.120000
    //     0xc8e184: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e188: ldr             d0, [x17, #0xf48]
    // 0xc8e18c: LoadField: r3 = r2->field_83
    //     0xc8e18c: ldur            w3, [x2, #0x83]
    // 0xc8e190: DecompressPointer r3
    //     0xc8e190: add             x3, x3, HEAP, lsl #32
    // 0xc8e194: LoadField: r4 = r3->field_57
    //     0xc8e194: ldur            w4, [x3, #0x57]
    // 0xc8e198: DecompressPointer r4
    //     0xc8e198: add             x4, x4, HEAP, lsl #32
    // 0xc8e19c: SaveReg r4
    //     0xc8e19c: str             x4, [SP, #-8]!
    // 0xc8e1a0: SaveReg d0
    //     0xc8e1a0: str             d0, [SP, #-8]!
    // 0xc8e1a4: r0 = withOpacity()
    //     0xc8e1a4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e1a8: add             SP, SP, #0x10
    // 0xc8e1ac: mov             x1, x0
    // 0xc8e1b0: ldur            x0, [fp, #-0x18]
    // 0xc8e1b4: b               #0xc8e1ec
    // 0xc8e1b8: mov             x0, x2
    // 0xc8e1bc: d0 = 0.120000
    //     0xc8e1bc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e1c0: ldr             d0, [x17, #0xf48]
    // 0xc8e1c4: LoadField: r1 = r0->field_83
    //     0xc8e1c4: ldur            w1, [x0, #0x83]
    // 0xc8e1c8: DecompressPointer r1
    //     0xc8e1c8: add             x1, x1, HEAP, lsl #32
    // 0xc8e1cc: LoadField: r2 = r1->field_57
    //     0xc8e1cc: ldur            w2, [x1, #0x57]
    // 0xc8e1d0: DecompressPointer r2
    //     0xc8e1d0: add             x2, x2, HEAP, lsl #32
    // 0xc8e1d4: SaveReg r2
    //     0xc8e1d4: str             x2, [SP, #-8]!
    // 0xc8e1d8: SaveReg d0
    //     0xc8e1d8: str             d0, [SP, #-8]!
    // 0xc8e1dc: r0 = withOpacity()
    //     0xc8e1dc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e1e0: add             SP, SP, #0x10
    // 0xc8e1e4: mov             x1, x0
    // 0xc8e1e8: ldur            x0, [fp, #-0x18]
    // 0xc8e1ec: r2 = LoadClassIdInstr(r0)
    //     0xc8e1ec: ldur            x2, [x0, #-1]
    //     0xc8e1f0: ubfx            x2, x2, #0xc, #0x14
    // 0xc8e1f4: stp             x1, x0, [SP, #-0x10]!
    // 0xc8e1f8: mov             x0, x2
    // 0xc8e1fc: mov             lr, x0
    // 0xc8e200: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e204: blr             lr
    // 0xc8e208: add             SP, SP, #0x10
    // 0xc8e20c: tbnz            w0, #4, #0xc8ef84
    // 0xc8e210: ldur            x0, [fp, #-8]
    // 0xc8e214: r17 = 5454
    //     0xc8e214: mov             x17, #0x154e
    // 0xc8e218: cmp             w0, w17
    // 0xc8e21c: b.ne            #0xc8e234
    // 0xc8e220: ldr             x1, [fp, #0x10]
    // 0xc8e224: LoadField: r2 = r1->field_23
    //     0xc8e224: ldur            w2, [x1, #0x23]
    // 0xc8e228: DecompressPointer r2
    //     0xc8e228: add             x2, x2, HEAP, lsl #32
    // 0xc8e22c: mov             x1, x2
    // 0xc8e230: b               #0xc8e2a4
    // 0xc8e234: ldr             x1, [fp, #0x10]
    // 0xc8e238: r17 = 5456
    //     0xc8e238: mov             x17, #0x1550
    // 0xc8e23c: cmp             w0, w17
    // 0xc8e240: b.ne            #0xc8e274
    // 0xc8e244: d0 = 0.380000
    //     0xc8e244: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e248: ldr             d0, [x17, #0x140]
    // 0xc8e24c: LoadField: r2 = r1->field_83
    //     0xc8e24c: ldur            w2, [x1, #0x83]
    // 0xc8e250: DecompressPointer r2
    //     0xc8e250: add             x2, x2, HEAP, lsl #32
    // 0xc8e254: LoadField: r3 = r2->field_f
    //     0xc8e254: ldur            w3, [x2, #0xf]
    // 0xc8e258: DecompressPointer r3
    //     0xc8e258: add             x3, x3, HEAP, lsl #32
    // 0xc8e25c: SaveReg r3
    //     0xc8e25c: str             x3, [SP, #-8]!
    // 0xc8e260: SaveReg d0
    //     0xc8e260: str             d0, [SP, #-8]!
    // 0xc8e264: r0 = withOpacity()
    //     0xc8e264: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e268: add             SP, SP, #0x10
    // 0xc8e26c: mov             x1, x0
    // 0xc8e270: b               #0xc8e2a4
    // 0xc8e274: mov             x0, x1
    // 0xc8e278: d0 = 0.540000
    //     0xc8e278: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8e27c: ldr             d0, [x17, #0x138]
    // 0xc8e280: LoadField: r1 = r0->field_83
    //     0xc8e280: ldur            w1, [x0, #0x83]
    // 0xc8e284: DecompressPointer r1
    //     0xc8e284: add             x1, x1, HEAP, lsl #32
    // 0xc8e288: LoadField: r2 = r1->field_f
    //     0xc8e288: ldur            w2, [x1, #0xf]
    // 0xc8e28c: DecompressPointer r2
    //     0xc8e28c: add             x2, x2, HEAP, lsl #32
    // 0xc8e290: SaveReg r2
    //     0xc8e290: str             x2, [SP, #-8]!
    // 0xc8e294: SaveReg d0
    //     0xc8e294: str             d0, [SP, #-8]!
    // 0xc8e298: r0 = withOpacity()
    //     0xc8e298: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e29c: add             SP, SP, #0x10
    // 0xc8e2a0: mov             x1, x0
    // 0xc8e2a4: ldur            x0, [fp, #-0x10]
    // 0xc8e2a8: stur            x1, [fp, #-0x18]
    // 0xc8e2ac: r17 = 5454
    //     0xc8e2ac: mov             x17, #0x154e
    // 0xc8e2b0: cmp             w0, w17
    // 0xc8e2b4: b.ne            #0xc8e2d0
    // 0xc8e2b8: ldr             x2, [fp, #0x18]
    // 0xc8e2bc: LoadField: r3 = r2->field_23
    //     0xc8e2bc: ldur            w3, [x2, #0x23]
    // 0xc8e2c0: DecompressPointer r3
    //     0xc8e2c0: add             x3, x3, HEAP, lsl #32
    // 0xc8e2c4: mov             x0, x1
    // 0xc8e2c8: mov             x1, x3
    // 0xc8e2cc: b               #0xc8e348
    // 0xc8e2d0: ldr             x2, [fp, #0x18]
    // 0xc8e2d4: r17 = 5456
    //     0xc8e2d4: mov             x17, #0x1550
    // 0xc8e2d8: cmp             w0, w17
    // 0xc8e2dc: b.ne            #0xc8e314
    // 0xc8e2e0: d0 = 0.380000
    //     0xc8e2e0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e2e4: ldr             d0, [x17, #0x140]
    // 0xc8e2e8: LoadField: r3 = r2->field_83
    //     0xc8e2e8: ldur            w3, [x2, #0x83]
    // 0xc8e2ec: DecompressPointer r3
    //     0xc8e2ec: add             x3, x3, HEAP, lsl #32
    // 0xc8e2f0: LoadField: r4 = r3->field_f
    //     0xc8e2f0: ldur            w4, [x3, #0xf]
    // 0xc8e2f4: DecompressPointer r4
    //     0xc8e2f4: add             x4, x4, HEAP, lsl #32
    // 0xc8e2f8: SaveReg r4
    //     0xc8e2f8: str             x4, [SP, #-8]!
    // 0xc8e2fc: SaveReg d0
    //     0xc8e2fc: str             d0, [SP, #-8]!
    // 0xc8e300: r0 = withOpacity()
    //     0xc8e300: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e304: add             SP, SP, #0x10
    // 0xc8e308: mov             x1, x0
    // 0xc8e30c: ldur            x0, [fp, #-0x18]
    // 0xc8e310: b               #0xc8e348
    // 0xc8e314: mov             x0, x2
    // 0xc8e318: d0 = 0.540000
    //     0xc8e318: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8e31c: ldr             d0, [x17, #0x138]
    // 0xc8e320: LoadField: r1 = r0->field_83
    //     0xc8e320: ldur            w1, [x0, #0x83]
    // 0xc8e324: DecompressPointer r1
    //     0xc8e324: add             x1, x1, HEAP, lsl #32
    // 0xc8e328: LoadField: r2 = r1->field_f
    //     0xc8e328: ldur            w2, [x1, #0xf]
    // 0xc8e32c: DecompressPointer r2
    //     0xc8e32c: add             x2, x2, HEAP, lsl #32
    // 0xc8e330: SaveReg r2
    //     0xc8e330: str             x2, [SP, #-8]!
    // 0xc8e334: SaveReg d0
    //     0xc8e334: str             d0, [SP, #-8]!
    // 0xc8e338: r0 = withOpacity()
    //     0xc8e338: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e33c: add             SP, SP, #0x10
    // 0xc8e340: mov             x1, x0
    // 0xc8e344: ldur            x0, [fp, #-0x18]
    // 0xc8e348: r2 = LoadClassIdInstr(r0)
    //     0xc8e348: ldur            x2, [x0, #-1]
    //     0xc8e34c: ubfx            x2, x2, #0xc, #0x14
    // 0xc8e350: stp             x1, x0, [SP, #-0x10]!
    // 0xc8e354: mov             x0, x2
    // 0xc8e358: mov             lr, x0
    // 0xc8e35c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e360: blr             lr
    // 0xc8e364: add             SP, SP, #0x10
    // 0xc8e368: tbnz            w0, #4, #0xc8ef84
    // 0xc8e36c: ldur            x0, [fp, #-8]
    // 0xc8e370: r17 = 5454
    //     0xc8e370: mov             x17, #0x154e
    // 0xc8e374: cmp             w0, w17
    // 0xc8e378: b.ne            #0xc8e390
    // 0xc8e37c: ldr             x1, [fp, #0x10]
    // 0xc8e380: LoadField: r2 = r1->field_27
    //     0xc8e380: ldur            w2, [x1, #0x27]
    // 0xc8e384: DecompressPointer r2
    //     0xc8e384: add             x2, x2, HEAP, lsl #32
    // 0xc8e388: mov             x1, x2
    // 0xc8e38c: b               #0xc8e41c
    // 0xc8e390: ldr             x1, [fp, #0x10]
    // 0xc8e394: r17 = 5456
    //     0xc8e394: mov             x17, #0x1550
    // 0xc8e398: cmp             w0, w17
    // 0xc8e39c: b.ne            #0xc8e3ec
    // 0xc8e3a0: LoadField: r2 = r1->field_83
    //     0xc8e3a0: ldur            w2, [x1, #0x83]
    // 0xc8e3a4: DecompressPointer r2
    //     0xc8e3a4: add             x2, x2, HEAP, lsl #32
    // 0xc8e3a8: LoadField: r3 = r2->field_5f
    //     0xc8e3a8: ldur            w3, [x2, #0x5f]
    // 0xc8e3ac: DecompressPointer r3
    //     0xc8e3ac: add             x3, x3, HEAP, lsl #32
    // 0xc8e3b0: cmp             w3, NULL
    // 0xc8e3b4: b.ne            #0xc8e3c8
    // 0xc8e3b8: LoadField: r3 = r2->field_57
    //     0xc8e3b8: ldur            w3, [x2, #0x57]
    // 0xc8e3bc: DecompressPointer r3
    //     0xc8e3bc: add             x3, x3, HEAP, lsl #32
    // 0xc8e3c0: mov             x2, x3
    // 0xc8e3c4: b               #0xc8e3cc
    // 0xc8e3c8: mov             x2, x3
    // 0xc8e3cc: d0 = 0.380000
    //     0xc8e3cc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e3d0: ldr             d0, [x17, #0x140]
    // 0xc8e3d4: SaveReg r2
    //     0xc8e3d4: str             x2, [SP, #-8]!
    // 0xc8e3d8: SaveReg d0
    //     0xc8e3d8: str             d0, [SP, #-8]!
    // 0xc8e3dc: r0 = withOpacity()
    //     0xc8e3dc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e3e0: add             SP, SP, #0x10
    // 0xc8e3e4: mov             x1, x0
    // 0xc8e3e8: b               #0xc8e41c
    // 0xc8e3ec: mov             x0, x1
    // 0xc8e3f0: d0 = 0.540000
    //     0xc8e3f0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8e3f4: ldr             d0, [x17, #0x138]
    // 0xc8e3f8: LoadField: r1 = r0->field_83
    //     0xc8e3f8: ldur            w1, [x0, #0x83]
    // 0xc8e3fc: DecompressPointer r1
    //     0xc8e3fc: add             x1, x1, HEAP, lsl #32
    // 0xc8e400: LoadField: r2 = r1->field_b
    //     0xc8e400: ldur            w2, [x1, #0xb]
    // 0xc8e404: DecompressPointer r2
    //     0xc8e404: add             x2, x2, HEAP, lsl #32
    // 0xc8e408: SaveReg r2
    //     0xc8e408: str             x2, [SP, #-8]!
    // 0xc8e40c: SaveReg d0
    //     0xc8e40c: str             d0, [SP, #-8]!
    // 0xc8e410: r0 = withOpacity()
    //     0xc8e410: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e414: add             SP, SP, #0x10
    // 0xc8e418: mov             x1, x0
    // 0xc8e41c: ldur            x0, [fp, #-0x10]
    // 0xc8e420: stur            x1, [fp, #-0x18]
    // 0xc8e424: r17 = 5454
    //     0xc8e424: mov             x17, #0x154e
    // 0xc8e428: cmp             w0, w17
    // 0xc8e42c: b.ne            #0xc8e448
    // 0xc8e430: ldr             x2, [fp, #0x18]
    // 0xc8e434: LoadField: r3 = r2->field_27
    //     0xc8e434: ldur            w3, [x2, #0x27]
    // 0xc8e438: DecompressPointer r3
    //     0xc8e438: add             x3, x3, HEAP, lsl #32
    // 0xc8e43c: mov             x0, x1
    // 0xc8e440: mov             x1, x3
    // 0xc8e444: b               #0xc8e4dc
    // 0xc8e448: ldr             x2, [fp, #0x18]
    // 0xc8e44c: r17 = 5456
    //     0xc8e44c: mov             x17, #0x1550
    // 0xc8e450: cmp             w0, w17
    // 0xc8e454: b.ne            #0xc8e4a8
    // 0xc8e458: LoadField: r3 = r2->field_83
    //     0xc8e458: ldur            w3, [x2, #0x83]
    // 0xc8e45c: DecompressPointer r3
    //     0xc8e45c: add             x3, x3, HEAP, lsl #32
    // 0xc8e460: LoadField: r4 = r3->field_5f
    //     0xc8e460: ldur            w4, [x3, #0x5f]
    // 0xc8e464: DecompressPointer r4
    //     0xc8e464: add             x4, x4, HEAP, lsl #32
    // 0xc8e468: cmp             w4, NULL
    // 0xc8e46c: b.ne            #0xc8e480
    // 0xc8e470: LoadField: r4 = r3->field_57
    //     0xc8e470: ldur            w4, [x3, #0x57]
    // 0xc8e474: DecompressPointer r4
    //     0xc8e474: add             x4, x4, HEAP, lsl #32
    // 0xc8e478: mov             x3, x4
    // 0xc8e47c: b               #0xc8e484
    // 0xc8e480: mov             x3, x4
    // 0xc8e484: d0 = 0.380000
    //     0xc8e484: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e488: ldr             d0, [x17, #0x140]
    // 0xc8e48c: SaveReg r3
    //     0xc8e48c: str             x3, [SP, #-8]!
    // 0xc8e490: SaveReg d0
    //     0xc8e490: str             d0, [SP, #-8]!
    // 0xc8e494: r0 = withOpacity()
    //     0xc8e494: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e498: add             SP, SP, #0x10
    // 0xc8e49c: mov             x1, x0
    // 0xc8e4a0: ldur            x0, [fp, #-0x18]
    // 0xc8e4a4: b               #0xc8e4dc
    // 0xc8e4a8: mov             x0, x2
    // 0xc8e4ac: d0 = 0.540000
    //     0xc8e4ac: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xc8e4b0: ldr             d0, [x17, #0x138]
    // 0xc8e4b4: LoadField: r1 = r0->field_83
    //     0xc8e4b4: ldur            w1, [x0, #0x83]
    // 0xc8e4b8: DecompressPointer r1
    //     0xc8e4b8: add             x1, x1, HEAP, lsl #32
    // 0xc8e4bc: LoadField: r2 = r1->field_b
    //     0xc8e4bc: ldur            w2, [x1, #0xb]
    // 0xc8e4c0: DecompressPointer r2
    //     0xc8e4c0: add             x2, x2, HEAP, lsl #32
    // 0xc8e4c4: SaveReg r2
    //     0xc8e4c4: str             x2, [SP, #-8]!
    // 0xc8e4c8: SaveReg d0
    //     0xc8e4c8: str             d0, [SP, #-8]!
    // 0xc8e4cc: r0 = withOpacity()
    //     0xc8e4cc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e4d0: add             SP, SP, #0x10
    // 0xc8e4d4: mov             x1, x0
    // 0xc8e4d8: ldur            x0, [fp, #-0x18]
    // 0xc8e4dc: r2 = LoadClassIdInstr(r0)
    //     0xc8e4dc: ldur            x2, [x0, #-1]
    //     0xc8e4e0: ubfx            x2, x2, #0xc, #0x14
    // 0xc8e4e4: stp             x1, x0, [SP, #-0x10]!
    // 0xc8e4e8: mov             x0, x2
    // 0xc8e4ec: mov             lr, x0
    // 0xc8e4f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e4f4: blr             lr
    // 0xc8e4f8: add             SP, SP, #0x10
    // 0xc8e4fc: tbnz            w0, #4, #0xc8ef84
    // 0xc8e500: ldur            x0, [fp, #-8]
    // 0xc8e504: r17 = 5454
    //     0xc8e504: mov             x17, #0x154e
    // 0xc8e508: cmp             w0, w17
    // 0xc8e50c: b.ne            #0xc8e524
    // 0xc8e510: ldr             x1, [fp, #0x10]
    // 0xc8e514: LoadField: r2 = r1->field_2b
    //     0xc8e514: ldur            w2, [x1, #0x2b]
    // 0xc8e518: DecompressPointer r2
    //     0xc8e518: add             x2, x2, HEAP, lsl #32
    // 0xc8e51c: mov             x1, x2
    // 0xc8e520: b               #0xc8e594
    // 0xc8e524: ldr             x1, [fp, #0x10]
    // 0xc8e528: r17 = 5456
    //     0xc8e528: mov             x17, #0x1550
    // 0xc8e52c: cmp             w0, w17
    // 0xc8e530: b.ne            #0xc8e564
    // 0xc8e534: d0 = 0.380000
    //     0xc8e534: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e538: ldr             d0, [x17, #0x140]
    // 0xc8e53c: LoadField: r2 = r1->field_83
    //     0xc8e53c: ldur            w2, [x1, #0x83]
    // 0xc8e540: DecompressPointer r2
    //     0xc8e540: add             x2, x2, HEAP, lsl #32
    // 0xc8e544: LoadField: r3 = r2->field_57
    //     0xc8e544: ldur            w3, [x2, #0x57]
    // 0xc8e548: DecompressPointer r3
    //     0xc8e548: add             x3, x3, HEAP, lsl #32
    // 0xc8e54c: SaveReg r3
    //     0xc8e54c: str             x3, [SP, #-8]!
    // 0xc8e550: SaveReg d0
    //     0xc8e550: str             d0, [SP, #-8]!
    // 0xc8e554: r0 = withOpacity()
    //     0xc8e554: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e558: add             SP, SP, #0x10
    // 0xc8e55c: mov             x1, x0
    // 0xc8e560: b               #0xc8e594
    // 0xc8e564: mov             x0, x1
    // 0xc8e568: d0 = 0.120000
    //     0xc8e568: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e56c: ldr             d0, [x17, #0xf48]
    // 0xc8e570: LoadField: r1 = r0->field_83
    //     0xc8e570: ldur            w1, [x0, #0x83]
    // 0xc8e574: DecompressPointer r1
    //     0xc8e574: add             x1, x1, HEAP, lsl #32
    // 0xc8e578: LoadField: r2 = r1->field_f
    //     0xc8e578: ldur            w2, [x1, #0xf]
    // 0xc8e57c: DecompressPointer r2
    //     0xc8e57c: add             x2, x2, HEAP, lsl #32
    // 0xc8e580: SaveReg r2
    //     0xc8e580: str             x2, [SP, #-8]!
    // 0xc8e584: SaveReg d0
    //     0xc8e584: str             d0, [SP, #-8]!
    // 0xc8e588: r0 = withOpacity()
    //     0xc8e588: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e58c: add             SP, SP, #0x10
    // 0xc8e590: mov             x1, x0
    // 0xc8e594: ldur            x0, [fp, #-0x10]
    // 0xc8e598: stur            x1, [fp, #-0x18]
    // 0xc8e59c: r17 = 5454
    //     0xc8e59c: mov             x17, #0x154e
    // 0xc8e5a0: cmp             w0, w17
    // 0xc8e5a4: b.ne            #0xc8e5c0
    // 0xc8e5a8: ldr             x2, [fp, #0x18]
    // 0xc8e5ac: LoadField: r3 = r2->field_2b
    //     0xc8e5ac: ldur            w3, [x2, #0x2b]
    // 0xc8e5b0: DecompressPointer r3
    //     0xc8e5b0: add             x3, x3, HEAP, lsl #32
    // 0xc8e5b4: mov             x0, x1
    // 0xc8e5b8: mov             x1, x3
    // 0xc8e5bc: b               #0xc8e638
    // 0xc8e5c0: ldr             x2, [fp, #0x18]
    // 0xc8e5c4: r17 = 5456
    //     0xc8e5c4: mov             x17, #0x1550
    // 0xc8e5c8: cmp             w0, w17
    // 0xc8e5cc: b.ne            #0xc8e604
    // 0xc8e5d0: d0 = 0.380000
    //     0xc8e5d0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e5d4: ldr             d0, [x17, #0x140]
    // 0xc8e5d8: LoadField: r3 = r2->field_83
    //     0xc8e5d8: ldur            w3, [x2, #0x83]
    // 0xc8e5dc: DecompressPointer r3
    //     0xc8e5dc: add             x3, x3, HEAP, lsl #32
    // 0xc8e5e0: LoadField: r4 = r3->field_57
    //     0xc8e5e0: ldur            w4, [x3, #0x57]
    // 0xc8e5e4: DecompressPointer r4
    //     0xc8e5e4: add             x4, x4, HEAP, lsl #32
    // 0xc8e5e8: SaveReg r4
    //     0xc8e5e8: str             x4, [SP, #-8]!
    // 0xc8e5ec: SaveReg d0
    //     0xc8e5ec: str             d0, [SP, #-8]!
    // 0xc8e5f0: r0 = withOpacity()
    //     0xc8e5f0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e5f4: add             SP, SP, #0x10
    // 0xc8e5f8: mov             x1, x0
    // 0xc8e5fc: ldur            x0, [fp, #-0x18]
    // 0xc8e600: b               #0xc8e638
    // 0xc8e604: mov             x0, x2
    // 0xc8e608: d0 = 0.120000
    //     0xc8e608: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e60c: ldr             d0, [x17, #0xf48]
    // 0xc8e610: LoadField: r1 = r0->field_83
    //     0xc8e610: ldur            w1, [x0, #0x83]
    // 0xc8e614: DecompressPointer r1
    //     0xc8e614: add             x1, x1, HEAP, lsl #32
    // 0xc8e618: LoadField: r2 = r1->field_f
    //     0xc8e618: ldur            w2, [x1, #0xf]
    // 0xc8e61c: DecompressPointer r2
    //     0xc8e61c: add             x2, x2, HEAP, lsl #32
    // 0xc8e620: SaveReg r2
    //     0xc8e620: str             x2, [SP, #-8]!
    // 0xc8e624: SaveReg d0
    //     0xc8e624: str             d0, [SP, #-8]!
    // 0xc8e628: r0 = withOpacity()
    //     0xc8e628: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e62c: add             SP, SP, #0x10
    // 0xc8e630: mov             x1, x0
    // 0xc8e634: ldur            x0, [fp, #-0x18]
    // 0xc8e638: r2 = LoadClassIdInstr(r0)
    //     0xc8e638: ldur            x2, [x0, #-1]
    //     0xc8e63c: ubfx            x2, x2, #0xc, #0x14
    // 0xc8e640: stp             x1, x0, [SP, #-0x10]!
    // 0xc8e644: mov             x0, x2
    // 0xc8e648: mov             lr, x0
    // 0xc8e64c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e650: blr             lr
    // 0xc8e654: add             SP, SP, #0x10
    // 0xc8e658: tbnz            w0, #4, #0xc8ef84
    // 0xc8e65c: ldur            x0, [fp, #-8]
    // 0xc8e660: r17 = 5454
    //     0xc8e660: mov             x17, #0x154e
    // 0xc8e664: cmp             w0, w17
    // 0xc8e668: b.ne            #0xc8e680
    // 0xc8e66c: ldr             x1, [fp, #0x10]
    // 0xc8e670: LoadField: r2 = r1->field_2f
    //     0xc8e670: ldur            w2, [x1, #0x2f]
    // 0xc8e674: DecompressPointer r2
    //     0xc8e674: add             x2, x2, HEAP, lsl #32
    // 0xc8e678: mov             x1, x2
    // 0xc8e67c: b               #0xc8e6f0
    // 0xc8e680: ldr             x1, [fp, #0x10]
    // 0xc8e684: r17 = 5456
    //     0xc8e684: mov             x17, #0x1550
    // 0xc8e688: cmp             w0, w17
    // 0xc8e68c: b.ne            #0xc8e6c0
    // 0xc8e690: d0 = 0.380000
    //     0xc8e690: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e694: ldr             d0, [x17, #0x140]
    // 0xc8e698: LoadField: r2 = r1->field_83
    //     0xc8e698: ldur            w2, [x1, #0x83]
    // 0xc8e69c: DecompressPointer r2
    //     0xc8e69c: add             x2, x2, HEAP, lsl #32
    // 0xc8e6a0: LoadField: r3 = r2->field_57
    //     0xc8e6a0: ldur            w3, [x2, #0x57]
    // 0xc8e6a4: DecompressPointer r3
    //     0xc8e6a4: add             x3, x3, HEAP, lsl #32
    // 0xc8e6a8: SaveReg r3
    //     0xc8e6a8: str             x3, [SP, #-8]!
    // 0xc8e6ac: SaveReg d0
    //     0xc8e6ac: str             d0, [SP, #-8]!
    // 0xc8e6b0: r0 = withOpacity()
    //     0xc8e6b0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e6b4: add             SP, SP, #0x10
    // 0xc8e6b8: mov             x1, x0
    // 0xc8e6bc: b               #0xc8e6f0
    // 0xc8e6c0: mov             x0, x1
    // 0xc8e6c4: d0 = 0.120000
    //     0xc8e6c4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e6c8: ldr             d0, [x17, #0xf48]
    // 0xc8e6cc: LoadField: r1 = r0->field_83
    //     0xc8e6cc: ldur            w1, [x0, #0x83]
    // 0xc8e6d0: DecompressPointer r1
    //     0xc8e6d0: add             x1, x1, HEAP, lsl #32
    // 0xc8e6d4: LoadField: r2 = r1->field_57
    //     0xc8e6d4: ldur            w2, [x1, #0x57]
    // 0xc8e6d8: DecompressPointer r2
    //     0xc8e6d8: add             x2, x2, HEAP, lsl #32
    // 0xc8e6dc: SaveReg r2
    //     0xc8e6dc: str             x2, [SP, #-8]!
    // 0xc8e6e0: SaveReg d0
    //     0xc8e6e0: str             d0, [SP, #-8]!
    // 0xc8e6e4: r0 = withOpacity()
    //     0xc8e6e4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e6e8: add             SP, SP, #0x10
    // 0xc8e6ec: mov             x1, x0
    // 0xc8e6f0: ldur            x0, [fp, #-0x10]
    // 0xc8e6f4: stur            x1, [fp, #-0x18]
    // 0xc8e6f8: r17 = 5454
    //     0xc8e6f8: mov             x17, #0x154e
    // 0xc8e6fc: cmp             w0, w17
    // 0xc8e700: b.ne            #0xc8e71c
    // 0xc8e704: ldr             x2, [fp, #0x18]
    // 0xc8e708: LoadField: r3 = r2->field_2f
    //     0xc8e708: ldur            w3, [x2, #0x2f]
    // 0xc8e70c: DecompressPointer r3
    //     0xc8e70c: add             x3, x3, HEAP, lsl #32
    // 0xc8e710: mov             x0, x1
    // 0xc8e714: mov             x1, x3
    // 0xc8e718: b               #0xc8e794
    // 0xc8e71c: ldr             x2, [fp, #0x18]
    // 0xc8e720: r17 = 5456
    //     0xc8e720: mov             x17, #0x1550
    // 0xc8e724: cmp             w0, w17
    // 0xc8e728: b.ne            #0xc8e760
    // 0xc8e72c: d0 = 0.380000
    //     0xc8e72c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e730: ldr             d0, [x17, #0x140]
    // 0xc8e734: LoadField: r3 = r2->field_83
    //     0xc8e734: ldur            w3, [x2, #0x83]
    // 0xc8e738: DecompressPointer r3
    //     0xc8e738: add             x3, x3, HEAP, lsl #32
    // 0xc8e73c: LoadField: r4 = r3->field_57
    //     0xc8e73c: ldur            w4, [x3, #0x57]
    // 0xc8e740: DecompressPointer r4
    //     0xc8e740: add             x4, x4, HEAP, lsl #32
    // 0xc8e744: SaveReg r4
    //     0xc8e744: str             x4, [SP, #-8]!
    // 0xc8e748: SaveReg d0
    //     0xc8e748: str             d0, [SP, #-8]!
    // 0xc8e74c: r0 = withOpacity()
    //     0xc8e74c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e750: add             SP, SP, #0x10
    // 0xc8e754: mov             x1, x0
    // 0xc8e758: ldur            x0, [fp, #-0x18]
    // 0xc8e75c: b               #0xc8e794
    // 0xc8e760: mov             x0, x2
    // 0xc8e764: d0 = 0.120000
    //     0xc8e764: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8e768: ldr             d0, [x17, #0xf48]
    // 0xc8e76c: LoadField: r1 = r0->field_83
    //     0xc8e76c: ldur            w1, [x0, #0x83]
    // 0xc8e770: DecompressPointer r1
    //     0xc8e770: add             x1, x1, HEAP, lsl #32
    // 0xc8e774: LoadField: r2 = r1->field_57
    //     0xc8e774: ldur            w2, [x1, #0x57]
    // 0xc8e778: DecompressPointer r2
    //     0xc8e778: add             x2, x2, HEAP, lsl #32
    // 0xc8e77c: SaveReg r2
    //     0xc8e77c: str             x2, [SP, #-8]!
    // 0xc8e780: SaveReg d0
    //     0xc8e780: str             d0, [SP, #-8]!
    // 0xc8e784: r0 = withOpacity()
    //     0xc8e784: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e788: add             SP, SP, #0x10
    // 0xc8e78c: mov             x1, x0
    // 0xc8e790: ldur            x0, [fp, #-0x18]
    // 0xc8e794: r2 = LoadClassIdInstr(r0)
    //     0xc8e794: ldur            x2, [x0, #-1]
    //     0xc8e798: ubfx            x2, x2, #0xc, #0x14
    // 0xc8e79c: stp             x1, x0, [SP, #-0x10]!
    // 0xc8e7a0: mov             x0, x2
    // 0xc8e7a4: mov             lr, x0
    // 0xc8e7a8: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e7ac: blr             lr
    // 0xc8e7b0: add             SP, SP, #0x10
    // 0xc8e7b4: tbnz            w0, #4, #0xc8ef84
    // 0xc8e7b8: ldur            x1, [fp, #-8]
    // 0xc8e7bc: r17 = 5454
    //     0xc8e7bc: mov             x17, #0x154e
    // 0xc8e7c0: cmp             w1, w17
    // 0xc8e7c4: b.ne            #0xc8e7d8
    // 0xc8e7c8: ldr             x2, [fp, #0x10]
    // 0xc8e7cc: LoadField: r0 = r2->field_33
    //     0xc8e7cc: ldur            w0, [x2, #0x33]
    // 0xc8e7d0: DecompressPointer r0
    //     0xc8e7d0: add             x0, x0, HEAP, lsl #32
    // 0xc8e7d4: b               #0xc8e814
    // 0xc8e7d8: ldr             x2, [fp, #0x10]
    // 0xc8e7dc: r17 = 5456
    //     0xc8e7dc: mov             x17, #0x1550
    // 0xc8e7e0: cmp             w1, w17
    // 0xc8e7e4: b.ne            #0xc8e800
    // 0xc8e7e8: LoadField: r0 = r2->field_83
    //     0xc8e7e8: ldur            w0, [x2, #0x83]
    // 0xc8e7ec: DecompressPointer r0
    //     0xc8e7ec: add             x0, x0, HEAP, lsl #32
    // 0xc8e7f0: LoadField: r3 = r0->field_b
    //     0xc8e7f0: ldur            w3, [x0, #0xb]
    // 0xc8e7f4: DecompressPointer r3
    //     0xc8e7f4: add             x3, x3, HEAP, lsl #32
    // 0xc8e7f8: mov             x0, x3
    // 0xc8e7fc: b               #0xc8e814
    // 0xc8e800: LoadField: r0 = r2->field_83
    //     0xc8e800: ldur            w0, [x2, #0x83]
    // 0xc8e804: DecompressPointer r0
    //     0xc8e804: add             x0, x0, HEAP, lsl #32
    // 0xc8e808: LoadField: r3 = r0->field_b
    //     0xc8e808: ldur            w3, [x0, #0xb]
    // 0xc8e80c: DecompressPointer r3
    //     0xc8e80c: add             x3, x3, HEAP, lsl #32
    // 0xc8e810: mov             x0, x3
    // 0xc8e814: ldur            x3, [fp, #-0x10]
    // 0xc8e818: r17 = 5454
    //     0xc8e818: mov             x17, #0x154e
    // 0xc8e81c: cmp             w3, w17
    // 0xc8e820: b.ne            #0xc8e834
    // 0xc8e824: ldr             x4, [fp, #0x18]
    // 0xc8e828: LoadField: r5 = r4->field_33
    //     0xc8e828: ldur            w5, [x4, #0x33]
    // 0xc8e82c: DecompressPointer r5
    //     0xc8e82c: add             x5, x5, HEAP, lsl #32
    // 0xc8e830: b               #0xc8e870
    // 0xc8e834: ldr             x4, [fp, #0x18]
    // 0xc8e838: r17 = 5456
    //     0xc8e838: mov             x17, #0x1550
    // 0xc8e83c: cmp             w3, w17
    // 0xc8e840: b.ne            #0xc8e85c
    // 0xc8e844: LoadField: r5 = r4->field_83
    //     0xc8e844: ldur            w5, [x4, #0x83]
    // 0xc8e848: DecompressPointer r5
    //     0xc8e848: add             x5, x5, HEAP, lsl #32
    // 0xc8e84c: LoadField: r6 = r5->field_b
    //     0xc8e84c: ldur            w6, [x5, #0xb]
    // 0xc8e850: DecompressPointer r6
    //     0xc8e850: add             x6, x6, HEAP, lsl #32
    // 0xc8e854: mov             x5, x6
    // 0xc8e858: b               #0xc8e870
    // 0xc8e85c: LoadField: r5 = r4->field_83
    //     0xc8e85c: ldur            w5, [x4, #0x83]
    // 0xc8e860: DecompressPointer r5
    //     0xc8e860: add             x5, x5, HEAP, lsl #32
    // 0xc8e864: LoadField: r6 = r5->field_b
    //     0xc8e864: ldur            w6, [x5, #0xb]
    // 0xc8e868: DecompressPointer r6
    //     0xc8e868: add             x6, x6, HEAP, lsl #32
    // 0xc8e86c: mov             x5, x6
    // 0xc8e870: r6 = LoadClassIdInstr(r0)
    //     0xc8e870: ldur            x6, [x0, #-1]
    //     0xc8e874: ubfx            x6, x6, #0xc, #0x14
    // 0xc8e878: stp             x5, x0, [SP, #-0x10]!
    // 0xc8e87c: mov             x0, x6
    // 0xc8e880: mov             lr, x0
    // 0xc8e884: ldr             lr, [x21, lr, lsl #3]
    // 0xc8e888: blr             lr
    // 0xc8e88c: add             SP, SP, #0x10
    // 0xc8e890: tbnz            w0, #4, #0xc8ef84
    // 0xc8e894: ldur            x0, [fp, #-8]
    // 0xc8e898: r17 = 5454
    //     0xc8e898: mov             x17, #0x154e
    // 0xc8e89c: cmp             w0, w17
    // 0xc8e8a0: b.ne            #0xc8e8b8
    // 0xc8e8a4: ldr             x1, [fp, #0x10]
    // 0xc8e8a8: LoadField: r2 = r1->field_3b
    //     0xc8e8a8: ldur            w2, [x1, #0x3b]
    // 0xc8e8ac: DecompressPointer r2
    //     0xc8e8ac: add             x2, x2, HEAP, lsl #32
    // 0xc8e8b0: mov             x1, x2
    // 0xc8e8b4: b               #0xc8e968
    // 0xc8e8b8: ldr             x1, [fp, #0x10]
    // 0xc8e8bc: r17 = 5456
    //     0xc8e8bc: mov             x17, #0x1550
    // 0xc8e8c0: cmp             w0, w17
    // 0xc8e8c4: b.ne            #0xc8e918
    // 0xc8e8c8: d0 = 0.380000
    //     0xc8e8c8: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e8cc: ldr             d0, [x17, #0x140]
    // 0xc8e8d0: LoadField: r2 = r1->field_83
    //     0xc8e8d0: ldur            w2, [x1, #0x83]
    // 0xc8e8d4: DecompressPointer r2
    //     0xc8e8d4: add             x2, x2, HEAP, lsl #32
    // 0xc8e8d8: stur            x2, [fp, #-0x18]
    // 0xc8e8dc: LoadField: r3 = r2->field_57
    //     0xc8e8dc: ldur            w3, [x2, #0x57]
    // 0xc8e8e0: DecompressPointer r3
    //     0xc8e8e0: add             x3, x3, HEAP, lsl #32
    // 0xc8e8e4: SaveReg r3
    //     0xc8e8e4: str             x3, [SP, #-8]!
    // 0xc8e8e8: SaveReg d0
    //     0xc8e8e8: str             d0, [SP, #-8]!
    // 0xc8e8ec: r0 = withOpacity()
    //     0xc8e8ec: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e8f0: add             SP, SP, #0x10
    // 0xc8e8f4: mov             x1, x0
    // 0xc8e8f8: ldur            x0, [fp, #-0x18]
    // 0xc8e8fc: LoadField: r2 = r0->field_53
    //     0xc8e8fc: ldur            w2, [x0, #0x53]
    // 0xc8e900: DecompressPointer r2
    //     0xc8e900: add             x2, x2, HEAP, lsl #32
    // 0xc8e904: stp             x2, x1, [SP, #-0x10]!
    // 0xc8e908: r0 = alphaBlend()
    //     0xc8e908: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xc8e90c: add             SP, SP, #0x10
    // 0xc8e910: mov             x1, x0
    // 0xc8e914: b               #0xc8e968
    // 0xc8e918: mov             x0, x1
    // 0xc8e91c: d0 = 0.380000
    //     0xc8e91c: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e920: ldr             d0, [x17, #0x140]
    // 0xc8e924: LoadField: r1 = r0->field_83
    //     0xc8e924: ldur            w1, [x0, #0x83]
    // 0xc8e928: DecompressPointer r1
    //     0xc8e928: add             x1, x1, HEAP, lsl #32
    // 0xc8e92c: stur            x1, [fp, #-0x18]
    // 0xc8e930: LoadField: r2 = r1->field_57
    //     0xc8e930: ldur            w2, [x1, #0x57]
    // 0xc8e934: DecompressPointer r2
    //     0xc8e934: add             x2, x2, HEAP, lsl #32
    // 0xc8e938: SaveReg r2
    //     0xc8e938: str             x2, [SP, #-8]!
    // 0xc8e93c: SaveReg d0
    //     0xc8e93c: str             d0, [SP, #-8]!
    // 0xc8e940: r0 = withOpacity()
    //     0xc8e940: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e944: add             SP, SP, #0x10
    // 0xc8e948: mov             x1, x0
    // 0xc8e94c: ldur            x0, [fp, #-0x18]
    // 0xc8e950: LoadField: r2 = r0->field_53
    //     0xc8e950: ldur            w2, [x0, #0x53]
    // 0xc8e954: DecompressPointer r2
    //     0xc8e954: add             x2, x2, HEAP, lsl #32
    // 0xc8e958: stp             x2, x1, [SP, #-0x10]!
    // 0xc8e95c: r0 = alphaBlend()
    //     0xc8e95c: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xc8e960: add             SP, SP, #0x10
    // 0xc8e964: mov             x1, x0
    // 0xc8e968: ldur            x0, [fp, #-0x10]
    // 0xc8e96c: stur            x1, [fp, #-0x20]
    // 0xc8e970: r17 = 5454
    //     0xc8e970: mov             x17, #0x154e
    // 0xc8e974: cmp             w0, w17
    // 0xc8e978: b.ne            #0xc8e994
    // 0xc8e97c: ldr             x2, [fp, #0x18]
    // 0xc8e980: LoadField: r3 = r2->field_3b
    //     0xc8e980: ldur            w3, [x2, #0x3b]
    // 0xc8e984: DecompressPointer r3
    //     0xc8e984: add             x3, x3, HEAP, lsl #32
    // 0xc8e988: mov             x0, x1
    // 0xc8e98c: mov             x1, x3
    // 0xc8e990: b               #0xc8ea4c
    // 0xc8e994: ldr             x2, [fp, #0x18]
    // 0xc8e998: r17 = 5456
    //     0xc8e998: mov             x17, #0x1550
    // 0xc8e99c: cmp             w0, w17
    // 0xc8e9a0: b.ne            #0xc8e9f8
    // 0xc8e9a4: d0 = 0.380000
    //     0xc8e9a4: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8e9a8: ldr             d0, [x17, #0x140]
    // 0xc8e9ac: LoadField: r3 = r2->field_83
    //     0xc8e9ac: ldur            w3, [x2, #0x83]
    // 0xc8e9b0: DecompressPointer r3
    //     0xc8e9b0: add             x3, x3, HEAP, lsl #32
    // 0xc8e9b4: stur            x3, [fp, #-0x18]
    // 0xc8e9b8: LoadField: r4 = r3->field_57
    //     0xc8e9b8: ldur            w4, [x3, #0x57]
    // 0xc8e9bc: DecompressPointer r4
    //     0xc8e9bc: add             x4, x4, HEAP, lsl #32
    // 0xc8e9c0: SaveReg r4
    //     0xc8e9c0: str             x4, [SP, #-8]!
    // 0xc8e9c4: SaveReg d0
    //     0xc8e9c4: str             d0, [SP, #-8]!
    // 0xc8e9c8: r0 = withOpacity()
    //     0xc8e9c8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8e9cc: add             SP, SP, #0x10
    // 0xc8e9d0: mov             x1, x0
    // 0xc8e9d4: ldur            x0, [fp, #-0x18]
    // 0xc8e9d8: LoadField: r2 = r0->field_53
    //     0xc8e9d8: ldur            w2, [x0, #0x53]
    // 0xc8e9dc: DecompressPointer r2
    //     0xc8e9dc: add             x2, x2, HEAP, lsl #32
    // 0xc8e9e0: stp             x2, x1, [SP, #-0x10]!
    // 0xc8e9e4: r0 = alphaBlend()
    //     0xc8e9e4: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xc8e9e8: add             SP, SP, #0x10
    // 0xc8e9ec: mov             x1, x0
    // 0xc8e9f0: ldur            x0, [fp, #-0x20]
    // 0xc8e9f4: b               #0xc8ea4c
    // 0xc8e9f8: mov             x0, x2
    // 0xc8e9fc: d0 = 0.380000
    //     0xc8e9fc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc8ea00: ldr             d0, [x17, #0x140]
    // 0xc8ea04: LoadField: r1 = r0->field_83
    //     0xc8ea04: ldur            w1, [x0, #0x83]
    // 0xc8ea08: DecompressPointer r1
    //     0xc8ea08: add             x1, x1, HEAP, lsl #32
    // 0xc8ea0c: stur            x1, [fp, #-0x18]
    // 0xc8ea10: LoadField: r2 = r1->field_57
    //     0xc8ea10: ldur            w2, [x1, #0x57]
    // 0xc8ea14: DecompressPointer r2
    //     0xc8ea14: add             x2, x2, HEAP, lsl #32
    // 0xc8ea18: SaveReg r2
    //     0xc8ea18: str             x2, [SP, #-8]!
    // 0xc8ea1c: SaveReg d0
    //     0xc8ea1c: str             d0, [SP, #-8]!
    // 0xc8ea20: r0 = withOpacity()
    //     0xc8ea20: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8ea24: add             SP, SP, #0x10
    // 0xc8ea28: mov             x1, x0
    // 0xc8ea2c: ldur            x0, [fp, #-0x18]
    // 0xc8ea30: LoadField: r2 = r0->field_53
    //     0xc8ea30: ldur            w2, [x0, #0x53]
    // 0xc8ea34: DecompressPointer r2
    //     0xc8ea34: add             x2, x2, HEAP, lsl #32
    // 0xc8ea38: stp             x2, x1, [SP, #-0x10]!
    // 0xc8ea3c: r0 = alphaBlend()
    //     0xc8ea3c: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xc8ea40: add             SP, SP, #0x10
    // 0xc8ea44: mov             x1, x0
    // 0xc8ea48: ldur            x0, [fp, #-0x20]
    // 0xc8ea4c: r2 = LoadClassIdInstr(r0)
    //     0xc8ea4c: ldur            x2, [x0, #-1]
    //     0xc8ea50: ubfx            x2, x2, #0xc, #0x14
    // 0xc8ea54: stp             x1, x0, [SP, #-0x10]!
    // 0xc8ea58: mov             x0, x2
    // 0xc8ea5c: mov             lr, x0
    // 0xc8ea60: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ea64: blr             lr
    // 0xc8ea68: add             SP, SP, #0x10
    // 0xc8ea6c: tbnz            w0, #4, #0xc8ef84
    // 0xc8ea70: ldur            x0, [fp, #-8]
    // 0xc8ea74: r17 = 5454
    //     0xc8ea74: mov             x17, #0x154e
    // 0xc8ea78: cmp             w0, w17
    // 0xc8ea7c: b.ne            #0xc8ea94
    // 0xc8ea80: ldr             x1, [fp, #0x10]
    // 0xc8ea84: LoadField: r2 = r1->field_3f
    //     0xc8ea84: ldur            w2, [x1, #0x3f]
    // 0xc8ea88: DecompressPointer r2
    //     0xc8ea88: add             x2, x2, HEAP, lsl #32
    // 0xc8ea8c: mov             x1, x2
    // 0xc8ea90: b               #0xc8eb0c
    // 0xc8ea94: ldr             x1, [fp, #0x10]
    // 0xc8ea98: r17 = 5456
    //     0xc8ea98: mov             x17, #0x1550
    // 0xc8ea9c: cmp             w0, w17
    // 0xc8eaa0: b.ne            #0xc8eadc
    // 0xc8eaa4: r1 = 1
    //     0xc8eaa4: mov             x1, #1
    // 0xc8eaa8: r0 = AllocateContext()
    //     0xc8eaa8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc8eaac: mov             x1, x0
    // 0xc8eab0: ldr             x0, [fp, #0x10]
    // 0xc8eab4: StoreField: r1->field_f = r0
    //     0xc8eab4: stur            w0, [x1, #0xf]
    // 0xc8eab8: mov             x2, x1
    // 0xc8eabc: r1 = Function '<anonymous closure>':.
    //     0xc8eabc: add             x1, PP, #0xe, lsl #12  ; [pp+0xe150] AnonymousClosure: (0x868120), in [package:flutter/src/material/slider.dart] _SliderDefaultsM3::overlayColor (0xcebee4)
    //     0xc8eac0: ldr             x1, [x1, #0x150]
    // 0xc8eac4: r0 = AllocateClosure()
    //     0xc8eac4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc8eac8: SaveReg r0
    //     0xc8eac8: str             x0, [SP, #-8]!
    // 0xc8eacc: r0 = resolveWith()
    //     0xc8eacc: bl              #0x85c570  ; [package:flutter/src/material/material_state.dart] MaterialStateColor::resolveWith
    // 0xc8ead0: add             SP, SP, #8
    // 0xc8ead4: mov             x1, x0
    // 0xc8ead8: b               #0xc8eb0c
    // 0xc8eadc: mov             x0, x1
    // 0xc8eae0: d0 = 0.120000
    //     0xc8eae0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8eae4: ldr             d0, [x17, #0xf48]
    // 0xc8eae8: LoadField: r1 = r0->field_83
    //     0xc8eae8: ldur            w1, [x0, #0x83]
    // 0xc8eaec: DecompressPointer r1
    //     0xc8eaec: add             x1, x1, HEAP, lsl #32
    // 0xc8eaf0: LoadField: r2 = r1->field_b
    //     0xc8eaf0: ldur            w2, [x1, #0xb]
    // 0xc8eaf4: DecompressPointer r2
    //     0xc8eaf4: add             x2, x2, HEAP, lsl #32
    // 0xc8eaf8: SaveReg r2
    //     0xc8eaf8: str             x2, [SP, #-8]!
    // 0xc8eafc: SaveReg d0
    //     0xc8eafc: str             d0, [SP, #-8]!
    // 0xc8eb00: r0 = withOpacity()
    //     0xc8eb00: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8eb04: add             SP, SP, #0x10
    // 0xc8eb08: mov             x1, x0
    // 0xc8eb0c: ldur            x0, [fp, #-0x10]
    // 0xc8eb10: stur            x1, [fp, #-0x18]
    // 0xc8eb14: r17 = 5454
    //     0xc8eb14: mov             x17, #0x154e
    // 0xc8eb18: cmp             w0, w17
    // 0xc8eb1c: b.ne            #0xc8eb38
    // 0xc8eb20: ldr             x2, [fp, #0x18]
    // 0xc8eb24: LoadField: r3 = r2->field_3f
    //     0xc8eb24: ldur            w3, [x2, #0x3f]
    // 0xc8eb28: DecompressPointer r3
    //     0xc8eb28: add             x3, x3, HEAP, lsl #32
    // 0xc8eb2c: mov             x0, x1
    // 0xc8eb30: mov             x1, x3
    // 0xc8eb34: b               #0xc8ebb8
    // 0xc8eb38: ldr             x2, [fp, #0x18]
    // 0xc8eb3c: r17 = 5456
    //     0xc8eb3c: mov             x17, #0x1550
    // 0xc8eb40: cmp             w0, w17
    // 0xc8eb44: b.ne            #0xc8eb84
    // 0xc8eb48: r1 = 1
    //     0xc8eb48: mov             x1, #1
    // 0xc8eb4c: r0 = AllocateContext()
    //     0xc8eb4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc8eb50: mov             x1, x0
    // 0xc8eb54: ldr             x0, [fp, #0x18]
    // 0xc8eb58: StoreField: r1->field_f = r0
    //     0xc8eb58: stur            w0, [x1, #0xf]
    // 0xc8eb5c: mov             x2, x1
    // 0xc8eb60: r1 = Function '<anonymous closure>':.
    //     0xc8eb60: add             x1, PP, #0xe, lsl #12  ; [pp+0xe150] AnonymousClosure: (0x868120), in [package:flutter/src/material/slider.dart] _SliderDefaultsM3::overlayColor (0xcebee4)
    //     0xc8eb64: ldr             x1, [x1, #0x150]
    // 0xc8eb68: r0 = AllocateClosure()
    //     0xc8eb68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc8eb6c: SaveReg r0
    //     0xc8eb6c: str             x0, [SP, #-8]!
    // 0xc8eb70: r0 = resolveWith()
    //     0xc8eb70: bl              #0x85c570  ; [package:flutter/src/material/material_state.dart] MaterialStateColor::resolveWith
    // 0xc8eb74: add             SP, SP, #8
    // 0xc8eb78: mov             x1, x0
    // 0xc8eb7c: ldur            x0, [fp, #-0x18]
    // 0xc8eb80: b               #0xc8ebb8
    // 0xc8eb84: mov             x0, x2
    // 0xc8eb88: d0 = 0.120000
    //     0xc8eb88: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc8eb8c: ldr             d0, [x17, #0xf48]
    // 0xc8eb90: LoadField: r1 = r0->field_83
    //     0xc8eb90: ldur            w1, [x0, #0x83]
    // 0xc8eb94: DecompressPointer r1
    //     0xc8eb94: add             x1, x1, HEAP, lsl #32
    // 0xc8eb98: LoadField: r2 = r1->field_b
    //     0xc8eb98: ldur            w2, [x1, #0xb]
    // 0xc8eb9c: DecompressPointer r2
    //     0xc8eb9c: add             x2, x2, HEAP, lsl #32
    // 0xc8eba0: SaveReg r2
    //     0xc8eba0: str             x2, [SP, #-8]!
    // 0xc8eba4: SaveReg d0
    //     0xc8eba4: str             d0, [SP, #-8]!
    // 0xc8eba8: r0 = withOpacity()
    //     0xc8eba8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc8ebac: add             SP, SP, #0x10
    // 0xc8ebb0: mov             x1, x0
    // 0xc8ebb4: ldur            x0, [fp, #-0x18]
    // 0xc8ebb8: r2 = LoadClassIdInstr(r0)
    //     0xc8ebb8: ldur            x2, [x0, #-1]
    //     0xc8ebbc: ubfx            x2, x2, #0xc, #0x14
    // 0xc8ebc0: stp             x1, x0, [SP, #-0x10]!
    // 0xc8ebc4: mov             x0, x2
    // 0xc8ebc8: mov             lr, x0
    // 0xc8ebcc: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ebd0: blr             lr
    // 0xc8ebd4: add             SP, SP, #0x10
    // 0xc8ebd8: tbnz            w0, #4, #0xc8ef84
    // 0xc8ebdc: ldr             x1, [fp, #0x18]
    // 0xc8ebe0: ldr             x2, [fp, #0x10]
    // 0xc8ebe4: LoadField: r0 = r2->field_43
    //     0xc8ebe4: ldur            w0, [x2, #0x43]
    // 0xc8ebe8: DecompressPointer r0
    //     0xc8ebe8: add             x0, x0, HEAP, lsl #32
    // 0xc8ebec: LoadField: r3 = r1->field_43
    //     0xc8ebec: ldur            w3, [x1, #0x43]
    // 0xc8ebf0: DecompressPointer r3
    //     0xc8ebf0: add             x3, x3, HEAP, lsl #32
    // 0xc8ebf4: r4 = LoadClassIdInstr(r0)
    //     0xc8ebf4: ldur            x4, [x0, #-1]
    //     0xc8ebf8: ubfx            x4, x4, #0xc, #0x14
    // 0xc8ebfc: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ec00: mov             x0, x4
    // 0xc8ec04: mov             lr, x0
    // 0xc8ec08: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ec0c: blr             lr
    // 0xc8ec10: add             SP, SP, #0x10
    // 0xc8ec14: tbnz            w0, #4, #0xc8ef84
    // 0xc8ec18: ldr             x1, [fp, #0x18]
    // 0xc8ec1c: ldr             x2, [fp, #0x10]
    // 0xc8ec20: LoadField: r0 = r2->field_47
    //     0xc8ec20: ldur            w0, [x2, #0x47]
    // 0xc8ec24: DecompressPointer r0
    //     0xc8ec24: add             x0, x0, HEAP, lsl #32
    // 0xc8ec28: LoadField: r3 = r1->field_47
    //     0xc8ec28: ldur            w3, [x1, #0x47]
    // 0xc8ec2c: DecompressPointer r3
    //     0xc8ec2c: add             x3, x3, HEAP, lsl #32
    // 0xc8ec30: cmp             w0, w3
    // 0xc8ec34: b.ne            #0xc8ef84
    // 0xc8ec38: LoadField: r0 = r2->field_4b
    //     0xc8ec38: ldur            w0, [x2, #0x4b]
    // 0xc8ec3c: DecompressPointer r0
    //     0xc8ec3c: add             x0, x0, HEAP, lsl #32
    // 0xc8ec40: LoadField: r3 = r1->field_4b
    //     0xc8ec40: ldur            w3, [x1, #0x4b]
    // 0xc8ec44: DecompressPointer r3
    //     0xc8ec44: add             x3, x3, HEAP, lsl #32
    // 0xc8ec48: cmp             w0, w3
    // 0xc8ec4c: b.ne            #0xc8ef84
    // 0xc8ec50: LoadField: r0 = r2->field_4f
    //     0xc8ec50: ldur            w0, [x2, #0x4f]
    // 0xc8ec54: DecompressPointer r0
    //     0xc8ec54: add             x0, x0, HEAP, lsl #32
    // 0xc8ec58: LoadField: r3 = r1->field_4f
    //     0xc8ec58: ldur            w3, [x1, #0x4f]
    // 0xc8ec5c: DecompressPointer r3
    //     0xc8ec5c: add             x3, x3, HEAP, lsl #32
    // 0xc8ec60: cmp             w0, w3
    // 0xc8ec64: b.ne            #0xc8ef84
    // 0xc8ec68: LoadField: r0 = r2->field_53
    //     0xc8ec68: ldur            w0, [x2, #0x53]
    // 0xc8ec6c: DecompressPointer r0
    //     0xc8ec6c: add             x0, x0, HEAP, lsl #32
    // 0xc8ec70: LoadField: r3 = r1->field_53
    //     0xc8ec70: ldur            w3, [x1, #0x53]
    // 0xc8ec74: DecompressPointer r3
    //     0xc8ec74: add             x3, x3, HEAP, lsl #32
    // 0xc8ec78: cmp             w0, w3
    // 0xc8ec7c: b.ne            #0xc8ef84
    // 0xc8ec80: ldur            x3, [fp, #-8]
    // 0xc8ec84: r17 = 5454
    //     0xc8ec84: mov             x17, #0x154e
    // 0xc8ec88: cmp             w3, w17
    // 0xc8ec8c: b.ne            #0xc8ec9c
    // 0xc8ec90: LoadField: r0 = r2->field_57
    //     0xc8ec90: ldur            w0, [x2, #0x57]
    // 0xc8ec94: DecompressPointer r0
    //     0xc8ec94: add             x0, x0, HEAP, lsl #32
    // 0xc8ec98: b               #0xc8ecbc
    // 0xc8ec9c: r17 = 5456
    //     0xc8ec9c: mov             x17, #0x1550
    // 0xc8eca0: cmp             w3, w17
    // 0xc8eca4: b.ne            #0xc8ecb4
    // 0xc8eca8: r0 = Instance_DropSliderValueIndicatorShape
    //     0xc8eca8: add             x0, PP, #0xe, lsl #12  ; [pp+0xe158] Obj!DropSliderValueIndicatorShape@b37bf1
    //     0xc8ecac: ldr             x0, [x0, #0x158]
    // 0xc8ecb0: b               #0xc8ecbc
    // 0xc8ecb4: r0 = Instance_RectangularSliderValueIndicatorShape
    //     0xc8ecb4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe160] Obj!RectangularSliderValueIndicatorShape@b37c01
    //     0xc8ecb8: ldr             x0, [x0, #0x160]
    // 0xc8ecbc: ldur            x4, [fp, #-0x10]
    // 0xc8ecc0: r17 = 5454
    //     0xc8ecc0: mov             x17, #0x154e
    // 0xc8ecc4: cmp             w4, w17
    // 0xc8ecc8: b.ne            #0xc8ecd8
    // 0xc8eccc: LoadField: r5 = r1->field_57
    //     0xc8eccc: ldur            w5, [x1, #0x57]
    // 0xc8ecd0: DecompressPointer r5
    //     0xc8ecd0: add             x5, x5, HEAP, lsl #32
    // 0xc8ecd4: b               #0xc8ecf8
    // 0xc8ecd8: r17 = 5456
    //     0xc8ecd8: mov             x17, #0x1550
    // 0xc8ecdc: cmp             w4, w17
    // 0xc8ece0: b.ne            #0xc8ecf0
    // 0xc8ece4: r5 = Instance_DropSliderValueIndicatorShape
    //     0xc8ece4: add             x5, PP, #0xe, lsl #12  ; [pp+0xe158] Obj!DropSliderValueIndicatorShape@b37bf1
    //     0xc8ece8: ldr             x5, [x5, #0x158]
    // 0xc8ecec: b               #0xc8ecf8
    // 0xc8ecf0: r5 = Instance_RectangularSliderValueIndicatorShape
    //     0xc8ecf0: add             x5, PP, #0xe, lsl #12  ; [pp+0xe160] Obj!RectangularSliderValueIndicatorShape@b37c01
    //     0xc8ecf4: ldr             x5, [x5, #0x160]
    // 0xc8ecf8: r6 = LoadClassIdInstr(r0)
    //     0xc8ecf8: ldur            x6, [x0, #-1]
    //     0xc8ecfc: ubfx            x6, x6, #0xc, #0x14
    // 0xc8ed00: stp             x5, x0, [SP, #-0x10]!
    // 0xc8ed04: mov             x0, x6
    // 0xc8ed08: mov             lr, x0
    // 0xc8ed0c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ed10: blr             lr
    // 0xc8ed14: add             SP, SP, #0x10
    // 0xc8ed18: tbnz            w0, #4, #0xc8ef84
    // 0xc8ed1c: ldr             x0, [fp, #0x18]
    // 0xc8ed20: ldr             x1, [fp, #0x10]
    // 0xc8ed24: LoadField: r2 = r1->field_6b
    //     0xc8ed24: ldur            w2, [x1, #0x6b]
    // 0xc8ed28: DecompressPointer r2
    //     0xc8ed28: add             x2, x2, HEAP, lsl #32
    // 0xc8ed2c: LoadField: r3 = r0->field_6b
    //     0xc8ed2c: ldur            w3, [x0, #0x6b]
    // 0xc8ed30: DecompressPointer r3
    //     0xc8ed30: add             x3, x3, HEAP, lsl #32
    // 0xc8ed34: cmp             w2, w3
    // 0xc8ed38: b.ne            #0xc8ef84
    // 0xc8ed3c: ldur            x2, [fp, #-8]
    // 0xc8ed40: r17 = 5454
    //     0xc8ed40: mov             x17, #0x154e
    // 0xc8ed44: cmp             w2, w17
    // 0xc8ed48: b.ne            #0xc8ed5c
    // 0xc8ed4c: LoadField: r2 = r1->field_6f
    //     0xc8ed4c: ldur            w2, [x1, #0x6f]
    // 0xc8ed50: DecompressPointer r2
    //     0xc8ed50: add             x2, x2, HEAP, lsl #32
    // 0xc8ed54: mov             x1, x2
    // 0xc8ed58: b               #0xc8ee20
    // 0xc8ed5c: r17 = 5456
    //     0xc8ed5c: mov             x17, #0x1550
    // 0xc8ed60: cmp             w2, w17
    // 0xc8ed64: b.ne            #0xc8edc4
    // 0xc8ed68: LoadField: r2 = r1->field_7f
    //     0xc8ed68: ldur            w2, [x1, #0x7f]
    // 0xc8ed6c: DecompressPointer r2
    //     0xc8ed6c: add             x2, x2, HEAP, lsl #32
    // 0xc8ed70: SaveReg r2
    //     0xc8ed70: str             x2, [SP, #-8]!
    // 0xc8ed74: r0 = of()
    //     0xc8ed74: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8ed78: add             SP, SP, #8
    // 0xc8ed7c: LoadField: r1 = r0->field_93
    //     0xc8ed7c: ldur            w1, [x0, #0x93]
    // 0xc8ed80: DecompressPointer r1
    //     0xc8ed80: add             x1, x1, HEAP, lsl #32
    // 0xc8ed84: LoadField: r0 = r1->field_3b
    //     0xc8ed84: ldur            w0, [x1, #0x3b]
    // 0xc8ed88: DecompressPointer r0
    //     0xc8ed88: add             x0, x0, HEAP, lsl #32
    // 0xc8ed8c: cmp             w0, NULL
    // 0xc8ed90: b.eq            #0xc8ef9c
    // 0xc8ed94: ldr             x1, [fp, #0x10]
    // 0xc8ed98: LoadField: r2 = r1->field_83
    //     0xc8ed98: ldur            w2, [x1, #0x83]
    // 0xc8ed9c: DecompressPointer r2
    //     0xc8ed9c: add             x2, x2, HEAP, lsl #32
    // 0xc8eda0: LoadField: r3 = r2->field_f
    //     0xc8eda0: ldur            w3, [x2, #0xf]
    // 0xc8eda4: DecompressPointer r3
    //     0xc8eda4: add             x3, x3, HEAP, lsl #32
    // 0xc8eda8: stp             x3, x0, [SP, #-0x10]!
    // 0xc8edac: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xc8edac: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xc8edb0: ldr             x4, [x4, #0x168]
    // 0xc8edb4: r0 = copyWith()
    //     0xc8edb4: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xc8edb8: add             SP, SP, #0x10
    // 0xc8edbc: mov             x1, x0
    // 0xc8edc0: b               #0xc8ee20
    // 0xc8edc4: mov             x0, x1
    // 0xc8edc8: LoadField: r1 = r0->field_7f
    //     0xc8edc8: ldur            w1, [x0, #0x7f]
    // 0xc8edcc: DecompressPointer r1
    //     0xc8edcc: add             x1, x1, HEAP, lsl #32
    // 0xc8edd0: SaveReg r1
    //     0xc8edd0: str             x1, [SP, #-8]!
    // 0xc8edd4: r0 = of()
    //     0xc8edd4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8edd8: add             SP, SP, #8
    // 0xc8eddc: LoadField: r1 = r0->field_93
    //     0xc8eddc: ldur            w1, [x0, #0x93]
    // 0xc8ede0: DecompressPointer r1
    //     0xc8ede0: add             x1, x1, HEAP, lsl #32
    // 0xc8ede4: LoadField: r0 = r1->field_2b
    //     0xc8ede4: ldur            w0, [x1, #0x2b]
    // 0xc8ede8: DecompressPointer r0
    //     0xc8ede8: add             x0, x0, HEAP, lsl #32
    // 0xc8edec: cmp             w0, NULL
    // 0xc8edf0: b.eq            #0xc8efa0
    // 0xc8edf4: ldr             x1, [fp, #0x10]
    // 0xc8edf8: LoadField: r2 = r1->field_83
    //     0xc8edf8: ldur            w2, [x1, #0x83]
    // 0xc8edfc: DecompressPointer r2
    //     0xc8edfc: add             x2, x2, HEAP, lsl #32
    // 0xc8ee00: LoadField: r3 = r2->field_f
    //     0xc8ee00: ldur            w3, [x2, #0xf]
    // 0xc8ee04: DecompressPointer r3
    //     0xc8ee04: add             x3, x3, HEAP, lsl #32
    // 0xc8ee08: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ee0c: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xc8ee0c: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xc8ee10: ldr             x4, [x4, #0x168]
    // 0xc8ee14: r0 = copyWith()
    //     0xc8ee14: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xc8ee18: add             SP, SP, #0x10
    // 0xc8ee1c: mov             x1, x0
    // 0xc8ee20: ldur            x0, [fp, #-0x10]
    // 0xc8ee24: stur            x1, [fp, #-8]
    // 0xc8ee28: r17 = 5454
    //     0xc8ee28: mov             x17, #0x154e
    // 0xc8ee2c: cmp             w0, w17
    // 0xc8ee30: b.ne            #0xc8ee50
    // 0xc8ee34: ldr             x2, [fp, #0x18]
    // 0xc8ee38: LoadField: r0 = r2->field_6f
    //     0xc8ee38: ldur            w0, [x2, #0x6f]
    // 0xc8ee3c: DecompressPointer r0
    //     0xc8ee3c: add             x0, x0, HEAP, lsl #32
    // 0xc8ee40: mov             x16, x1
    // 0xc8ee44: mov             x1, x0
    // 0xc8ee48: mov             x0, x16
    // 0xc8ee4c: b               #0xc8ef20
    // 0xc8ee50: ldr             x2, [fp, #0x18]
    // 0xc8ee54: r17 = 5456
    //     0xc8ee54: mov             x17, #0x1550
    // 0xc8ee58: cmp             w0, w17
    // 0xc8ee5c: b.ne            #0xc8eec0
    // 0xc8ee60: LoadField: r0 = r2->field_7f
    //     0xc8ee60: ldur            w0, [x2, #0x7f]
    // 0xc8ee64: DecompressPointer r0
    //     0xc8ee64: add             x0, x0, HEAP, lsl #32
    // 0xc8ee68: SaveReg r0
    //     0xc8ee68: str             x0, [SP, #-8]!
    // 0xc8ee6c: r0 = of()
    //     0xc8ee6c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8ee70: add             SP, SP, #8
    // 0xc8ee74: LoadField: r1 = r0->field_93
    //     0xc8ee74: ldur            w1, [x0, #0x93]
    // 0xc8ee78: DecompressPointer r1
    //     0xc8ee78: add             x1, x1, HEAP, lsl #32
    // 0xc8ee7c: LoadField: r0 = r1->field_3b
    //     0xc8ee7c: ldur            w0, [x1, #0x3b]
    // 0xc8ee80: DecompressPointer r0
    //     0xc8ee80: add             x0, x0, HEAP, lsl #32
    // 0xc8ee84: cmp             w0, NULL
    // 0xc8ee88: b.eq            #0xc8efa4
    // 0xc8ee8c: ldr             x1, [fp, #0x18]
    // 0xc8ee90: LoadField: r2 = r1->field_83
    //     0xc8ee90: ldur            w2, [x1, #0x83]
    // 0xc8ee94: DecompressPointer r2
    //     0xc8ee94: add             x2, x2, HEAP, lsl #32
    // 0xc8ee98: LoadField: r3 = r2->field_f
    //     0xc8ee98: ldur            w3, [x2, #0xf]
    // 0xc8ee9c: DecompressPointer r3
    //     0xc8ee9c: add             x3, x3, HEAP, lsl #32
    // 0xc8eea0: stp             x3, x0, [SP, #-0x10]!
    // 0xc8eea4: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xc8eea4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xc8eea8: ldr             x4, [x4, #0x168]
    // 0xc8eeac: r0 = copyWith()
    //     0xc8eeac: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xc8eeb0: add             SP, SP, #0x10
    // 0xc8eeb4: mov             x1, x0
    // 0xc8eeb8: ldur            x0, [fp, #-8]
    // 0xc8eebc: b               #0xc8ef20
    // 0xc8eec0: mov             x0, x2
    // 0xc8eec4: LoadField: r1 = r0->field_7f
    //     0xc8eec4: ldur            w1, [x0, #0x7f]
    // 0xc8eec8: DecompressPointer r1
    //     0xc8eec8: add             x1, x1, HEAP, lsl #32
    // 0xc8eecc: SaveReg r1
    //     0xc8eecc: str             x1, [SP, #-8]!
    // 0xc8eed0: r0 = of()
    //     0xc8eed0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc8eed4: add             SP, SP, #8
    // 0xc8eed8: LoadField: r1 = r0->field_93
    //     0xc8eed8: ldur            w1, [x0, #0x93]
    // 0xc8eedc: DecompressPointer r1
    //     0xc8eedc: add             x1, x1, HEAP, lsl #32
    // 0xc8eee0: LoadField: r0 = r1->field_2b
    //     0xc8eee0: ldur            w0, [x1, #0x2b]
    // 0xc8eee4: DecompressPointer r0
    //     0xc8eee4: add             x0, x0, HEAP, lsl #32
    // 0xc8eee8: cmp             w0, NULL
    // 0xc8eeec: b.eq            #0xc8efa8
    // 0xc8eef0: ldr             x1, [fp, #0x18]
    // 0xc8eef4: LoadField: r2 = r1->field_83
    //     0xc8eef4: ldur            w2, [x1, #0x83]
    // 0xc8eef8: DecompressPointer r2
    //     0xc8eef8: add             x2, x2, HEAP, lsl #32
    // 0xc8eefc: LoadField: r3 = r2->field_f
    //     0xc8eefc: ldur            w3, [x2, #0xf]
    // 0xc8ef00: DecompressPointer r3
    //     0xc8ef00: add             x3, x3, HEAP, lsl #32
    // 0xc8ef04: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ef08: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xc8ef08: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xc8ef0c: ldr             x4, [x4, #0x168]
    // 0xc8ef10: r0 = copyWith()
    //     0xc8ef10: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xc8ef14: add             SP, SP, #0x10
    // 0xc8ef18: mov             x1, x0
    // 0xc8ef1c: ldur            x0, [fp, #-8]
    // 0xc8ef20: r2 = LoadClassIdInstr(r0)
    //     0xc8ef20: ldur            x2, [x0, #-1]
    //     0xc8ef24: ubfx            x2, x2, #0xc, #0x14
    // 0xc8ef28: stp             x1, x0, [SP, #-0x10]!
    // 0xc8ef2c: mov             x0, x2
    // 0xc8ef30: mov             lr, x0
    // 0xc8ef34: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ef38: blr             lr
    // 0xc8ef3c: add             SP, SP, #0x10
    // 0xc8ef40: tbnz            w0, #4, #0xc8ef84
    // 0xc8ef44: ldr             x0, [fp, #0x18]
    // 0xc8ef48: ldr             x1, [fp, #0x10]
    // 0xc8ef4c: LoadField: r2 = r1->field_73
    //     0xc8ef4c: ldur            w2, [x1, #0x73]
    // 0xc8ef50: DecompressPointer r2
    //     0xc8ef50: add             x2, x2, HEAP, lsl #32
    // 0xc8ef54: LoadField: r1 = r0->field_73
    //     0xc8ef54: ldur            w1, [x0, #0x73]
    // 0xc8ef58: DecompressPointer r1
    //     0xc8ef58: add             x1, x1, HEAP, lsl #32
    // 0xc8ef5c: r0 = LoadClassIdInstr(r2)
    //     0xc8ef5c: ldur            x0, [x2, #-1]
    //     0xc8ef60: ubfx            x0, x0, #0xc, #0x14
    // 0xc8ef64: stp             x1, x2, [SP, #-0x10]!
    // 0xc8ef68: mov             lr, x0
    // 0xc8ef6c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ef70: blr             lr
    // 0xc8ef74: add             SP, SP, #0x10
    // 0xc8ef78: tbnz            w0, #4, #0xc8ef84
    // 0xc8ef7c: r0 = true
    //     0xc8ef7c: add             x0, NULL, #0x20  ; true
    // 0xc8ef80: b               #0xc8ef88
    // 0xc8ef84: r0 = false
    //     0xc8ef84: add             x0, NULL, #0x30  ; false
    // 0xc8ef88: LeaveFrame
    //     0xc8ef88: mov             SP, fp
    //     0xc8ef8c: ldp             fp, lr, [SP], #0x10
    // 0xc8ef90: ret
    //     0xc8ef90: ret             
    // 0xc8ef94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8ef94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8ef98: b               #0xc8d948
    // 0xc8ef9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8ef9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc8efa0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8efa0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc8efa4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8efa4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc8efa8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc8efa8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  const get _ valueIndicatorShape(/* No info */) {
    // ** addr: 0xcebd68, size: 0x10
    // 0xcebd68: ldr             x1, [SP]
    // 0xcebd6c: LoadField: r0 = r1->field_57
    //     0xcebd6c: ldur            w0, [x1, #0x57]
    // 0xcebd70: DecompressPointer r0
    //     0xcebd70: add             x0, x0, HEAP, lsl #32
    // 0xcebd74: ret
    //     0xcebd74: ret             
  }
  const get _ valueIndicatorTextStyle(/* No info */) {
    // ** addr: 0xcebe80, size: 0x10
    // 0xcebe80: ldr             x1, [SP]
    // 0xcebe84: LoadField: r0 = r1->field_6f
    //     0xcebe84: ldur            w0, [x1, #0x6f]
    // 0xcebe88: DecompressPointer r0
    //     0xcebe88: add             x0, x0, HEAP, lsl #32
    // 0xcebe8c: ret
    //     0xcebe8c: ret             
  }
  const get _ overlayColor(/* No info */) {
    // ** addr: 0xcebf3c, size: 0x10
    // 0xcebf3c: ldr             x1, [SP]
    // 0xcebf40: LoadField: r0 = r1->field_3f
    //     0xcebf40: ldur            w0, [x1, #0x3f]
    // 0xcebf44: DecompressPointer r0
    //     0xcebf44: add             x0, x0, HEAP, lsl #32
    // 0xcebf48: ret
    //     0xcebf48: ret             
  }
  const get _ thumbColor(/* No info */) {
    // ** addr: 0xcebfd4, size: 0x10
    // 0xcebfd4: ldr             x1, [SP]
    // 0xcebfd8: LoadField: r0 = r1->field_33
    //     0xcebfd8: ldur            w0, [x1, #0x33]
    // 0xcebfdc: DecompressPointer r0
    //     0xcebfdc: add             x0, x0, HEAP, lsl #32
    // 0xcebfe0: ret
    //     0xcebfe0: ret             
  }
  const get _ disabledInactiveTickMarkColor(/* No info */) {
    // ** addr: 0xcebfe4, size: 0x10
    // 0xcebfe4: ldr             x1, [SP]
    // 0xcebfe8: LoadField: r0 = r1->field_2f
    //     0xcebfe8: ldur            w0, [x1, #0x2f]
    // 0xcebfec: DecompressPointer r0
    //     0xcebfec: add             x0, x0, HEAP, lsl #32
    // 0xcebff0: ret
    //     0xcebff0: ret             
  }
}

// class id: 3540, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class SliderTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0x8682e0, size: 0x64
    // 0x8682e0: EnterFrame
    //     0x8682e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8682e4: mov             fp, SP
    // 0x8682e8: CheckStackOverflow
    //     0x8682e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8682ec: cmp             SP, x16
    //     0x8682f0: b.ls            #0x86833c
    // 0x8682f4: r16 = <SliderTheme>
    //     0x8682f4: add             x16, PP, #0x55, lsl #12  ; [pp+0x55818] TypeArguments: <SliderTheme>
    //     0x8682f8: ldr             x16, [x16, #0x818]
    // 0x8682fc: ldr             lr, [fp, #0x10]
    // 0x868300: stp             lr, x16, [SP, #-0x10]!
    // 0x868304: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x868304: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x868308: r0 = dependOnInheritedWidgetOfExactType()
    //     0x868308: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x86830c: add             SP, SP, #0x10
    // 0x868310: ldr             x16, [fp, #0x10]
    // 0x868314: SaveReg r16
    //     0x868314: str             x16, [SP, #-8]!
    // 0x868318: r0 = of()
    //     0x868318: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x86831c: add             SP, SP, #8
    // 0x868320: r17 = 287
    //     0x868320: mov             x17, #0x11f
    // 0x868324: ldr             w1, [x0, x17]
    // 0x868328: DecompressPointer r1
    //     0x868328: add             x1, x1, HEAP, lsl #32
    // 0x86832c: mov             x0, x1
    // 0x868330: LeaveFrame
    //     0x868330: mov             SP, fp
    //     0x868334: ldp             fp, lr, [SP], #0x10
    // 0x868338: ret
    //     0x868338: ret             
    // 0x86833c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86833c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868340: b               #0x8682f4
  }
}

// class id: 5949, size: 0x14, field offset: 0x14
enum ShowValueIndicator extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb16588, size: 0x5c
    // 0xb16588: EnterFrame
    //     0xb16588: stp             fp, lr, [SP, #-0x10]!
    //     0xb1658c: mov             fp, SP
    // 0xb16590: CheckStackOverflow
    //     0xb16590: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16594: cmp             SP, x16
    //     0xb16598: b.ls            #0xb165dc
    // 0xb1659c: r1 = Null
    //     0xb1659c: mov             x1, NULL
    // 0xb165a0: r2 = 4
    //     0xb165a0: mov             x2, #4
    // 0xb165a4: r0 = AllocateArray()
    //     0xb165a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb165a8: r17 = "ShowValueIndicator."
    //     0xb165a8: add             x17, PP, #0x56, lsl #12  ; [pp+0x56400] "ShowValueIndicator."
    //     0xb165ac: ldr             x17, [x17, #0x400]
    // 0xb165b0: StoreField: r0->field_f = r17
    //     0xb165b0: stur            w17, [x0, #0xf]
    // 0xb165b4: ldr             x1, [fp, #0x10]
    // 0xb165b8: LoadField: r2 = r1->field_f
    //     0xb165b8: ldur            w2, [x1, #0xf]
    // 0xb165bc: DecompressPointer r2
    //     0xb165bc: add             x2, x2, HEAP, lsl #32
    // 0xb165c0: StoreField: r0->field_13 = r2
    //     0xb165c0: stur            w2, [x0, #0x13]
    // 0xb165c4: SaveReg r0
    //     0xb165c4: str             x0, [SP, #-8]!
    // 0xb165c8: r0 = _interpolate()
    //     0xb165c8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb165cc: add             SP, SP, #8
    // 0xb165d0: LeaveFrame
    //     0xb165d0: mov             SP, fp
    //     0xb165d4: ldp             fp, lr, [SP], #0x10
    // 0xb165d8: ret
    //     0xb165d8: ret             
    // 0xb165dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb165dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb165e0: b               #0xb1659c
  }
}

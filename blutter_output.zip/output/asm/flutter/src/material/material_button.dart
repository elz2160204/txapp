// lib: , url: package:flutter/src/material/material_button.dart

// class id: 1049268, size: 0x8
class :: {
}

// class id: 3848, size: 0x8c, field offset: 0xc
//   const constructor, 
class MaterialButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb231bc, size: 0x324
    // 0xb231bc: EnterFrame
    //     0xb231bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb231c0: mov             fp, SP
    // 0xb231c4: AllocStack(0x70)
    //     0xb231c4: sub             SP, SP, #0x70
    // 0xb231c8: CheckStackOverflow
    //     0xb231c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb231cc: cmp             SP, x16
    //     0xb231d0: b.ls            #0xb234b0
    // 0xb231d4: ldr             x16, [fp, #0x10]
    // 0xb231d8: SaveReg r16
    //     0xb231d8: str             x16, [SP, #-8]!
    // 0xb231dc: r0 = of()
    //     0xb231dc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb231e0: add             SP, SP, #8
    // 0xb231e4: stur            x0, [fp, #-8]
    // 0xb231e8: ldr             x16, [fp, #0x10]
    // 0xb231ec: SaveReg r16
    //     0xb231ec: str             x16, [SP, #-8]!
    // 0xb231f0: r0 = of()
    //     0xb231f0: bl              #0xb238b4  ; [package:flutter/src/material/button_theme.dart] ButtonTheme::of
    // 0xb231f4: add             SP, SP, #8
    // 0xb231f8: mov             x1, x0
    // 0xb231fc: ldr             x0, [fp, #0x18]
    // 0xb23200: stur            x1, [fp, #-0x18]
    // 0xb23204: LoadField: r2 = r0->field_b
    //     0xb23204: ldur            w2, [x0, #0xb]
    // 0xb23208: DecompressPointer r2
    //     0xb23208: add             x2, x2, HEAP, lsl #32
    // 0xb2320c: stur            x2, [fp, #-0x10]
    // 0xb23210: stp             x0, x1, [SP, #-0x10]!
    // 0xb23214: r0 = getFillColor()
    //     0xb23214: bl              #0xb23728  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getFillColor
    // 0xb23218: add             SP, SP, #0x10
    // 0xb2321c: mov             x1, x0
    // 0xb23220: ldur            x0, [fp, #-8]
    // 0xb23224: stur            x1, [fp, #-0x28]
    // 0xb23228: LoadField: r2 = r0->field_93
    //     0xb23228: ldur            w2, [x0, #0x93]
    // 0xb2322c: DecompressPointer r2
    //     0xb2322c: add             x2, x2, HEAP, lsl #32
    // 0xb23230: LoadField: r3 = r2->field_37
    //     0xb23230: ldur            w3, [x2, #0x37]
    // 0xb23234: DecompressPointer r3
    //     0xb23234: add             x3, x3, HEAP, lsl #32
    // 0xb23238: stur            x3, [fp, #-0x20]
    // 0xb2323c: cmp             w3, NULL
    // 0xb23240: b.eq            #0xb234b8
    // 0xb23244: ldur            x16, [fp, #-0x18]
    // 0xb23248: ldr             lr, [fp, #0x18]
    // 0xb2324c: stp             lr, x16, [SP, #-0x10]!
    // 0xb23250: r0 = getTextColor()
    //     0xb23250: bl              #0xb23630  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getTextColor
    // 0xb23254: add             SP, SP, #0x10
    // 0xb23258: ldur            x16, [fp, #-0x20]
    // 0xb2325c: stp             x0, x16, [SP, #-0x10]!
    // 0xb23260: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb23260: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb23264: ldr             x4, [x4, #0x168]
    // 0xb23268: r0 = copyWith()
    //     0xb23268: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xb2326c: add             SP, SP, #0x10
    // 0xb23270: stur            x0, [fp, #-0x20]
    // 0xb23274: ldur            x16, [fp, #-0x18]
    // 0xb23278: ldr             lr, [fp, #0x18]
    // 0xb2327c: stp             lr, x16, [SP, #-0x10]!
    // 0xb23280: r0 = getFocusColor()
    //     0xb23280: bl              #0xb235c4  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getFocusColor
    // 0xb23284: add             SP, SP, #0x10
    // 0xb23288: stur            x0, [fp, #-0x30]
    // 0xb2328c: ldur            x16, [fp, #-0x18]
    // 0xb23290: ldr             lr, [fp, #0x18]
    // 0xb23294: stp             lr, x16, [SP, #-0x10]!
    // 0xb23298: r0 = getHoverColor()
    //     0xb23298: bl              #0xb23558  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getHoverColor
    // 0xb2329c: add             SP, SP, #0x10
    // 0xb232a0: mov             x1, x0
    // 0xb232a4: ldur            x0, [fp, #-8]
    // 0xb232a8: stur            x1, [fp, #-0x48]
    // 0xb232ac: LoadField: r2 = r0->field_53
    //     0xb232ac: ldur            w2, [x0, #0x53]
    // 0xb232b0: DecompressPointer r2
    //     0xb232b0: add             x2, x2, HEAP, lsl #32
    // 0xb232b4: stur            x2, [fp, #-0x40]
    // 0xb232b8: LoadField: r3 = r0->field_7f
    //     0xb232b8: ldur            w3, [x0, #0x7f]
    // 0xb232bc: DecompressPointer r3
    //     0xb232bc: add             x3, x3, HEAP, lsl #32
    // 0xb232c0: ldr             x4, [fp, #0x18]
    // 0xb232c4: stur            x3, [fp, #-0x38]
    // 0xb232c8: LoadField: r5 = r4->field_3f
    //     0xb232c8: ldur            w5, [x4, #0x3f]
    // 0xb232cc: DecompressPointer r5
    //     0xb232cc: add             x5, x5, HEAP, lsl #32
    // 0xb232d0: cmp             w5, NULL
    // 0xb232d4: b.ne            #0xb232e0
    // 0xb232d8: d0 = 2.000000
    //     0xb232d8: fmov            d0, #2.00000000
    // 0xb232dc: b               #0xb232e4
    // 0xb232e0: LoadField: d0 = r5->field_7
    //     0xb232e0: ldur            d0, [x5, #7]
    // 0xb232e4: stur            d0, [fp, #-0x70]
    // 0xb232e8: ldur            x16, [fp, #-0x18]
    // 0xb232ec: stp             x4, x16, [SP, #-0x10]!
    // 0xb232f0: r0 = getPadding()
    //     0xb232f0: bl              #0xb2351c  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::getPadding
    // 0xb232f4: add             SP, SP, #0x10
    // 0xb232f8: mov             x1, x0
    // 0xb232fc: ldur            x0, [fp, #-8]
    // 0xb23300: stur            x1, [fp, #-0x58]
    // 0xb23304: LoadField: r2 = r0->field_2f
    //     0xb23304: ldur            w2, [x0, #0x2f]
    // 0xb23308: DecompressPointer r2
    //     0xb23308: add             x2, x2, HEAP, lsl #32
    // 0xb2330c: stur            x2, [fp, #-0x50]
    // 0xb23310: ldur            x16, [fp, #-0x18]
    // 0xb23314: SaveReg r16
    //     0xb23314: str             x16, [SP, #-8]!
    // 0xb23318: r0 = constraints()
    //     0xb23318: bl              #0xb234e0  ; [package:flutter/src/material/button_theme.dart] ButtonThemeData::constraints
    // 0xb2331c: add             SP, SP, #8
    // 0xb23320: mov             x1, x0
    // 0xb23324: ldr             x0, [fp, #0x18]
    // 0xb23328: LoadField: d0 = r0->field_7b
    //     0xb23328: ldur            d0, [x0, #0x7b]
    // 0xb2332c: LoadField: r2 = r0->field_83
    //     0xb2332c: ldur            w2, [x0, #0x83]
    // 0xb23330: DecompressPointer r2
    //     0xb23330: add             x2, x2, HEAP, lsl #32
    // 0xb23334: r3 = inline_Allocate_Double()
    //     0xb23334: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xb23338: add             x3, x3, #0x10
    //     0xb2333c: cmp             x4, x3
    //     0xb23340: b.ls            #0xb234bc
    //     0xb23344: str             x3, [THR, #0x60]  ; THR::top
    //     0xb23348: sub             x3, x3, #0xf
    //     0xb2334c: mov             x4, #0xd108
    //     0xb23350: movk            x4, #3, lsl #16
    //     0xb23354: stur            x4, [x3, #-1]
    // 0xb23358: StoreField: r3->field_7 = d0
    //     0xb23358: stur            d0, [x3, #7]
    // 0xb2335c: stp             x3, x1, [SP, #-0x10]!
    // 0xb23360: SaveReg r2
    //     0xb23360: str             x2, [SP, #-8]!
    // 0xb23364: r4 = const [0, 0x3, 0x3, 0x1, minHeight, 0x2, minWidth, 0x1, null]
    //     0xb23364: add             x4, PP, #0x2e, lsl #12  ; [pp+0x2e710] List(9) [0, 0x3, 0x3, 0x1, "minHeight", 0x2, "minWidth", 0x1, Null]
    //     0xb23368: ldr             x4, [x4, #0x710]
    // 0xb2336c: r0 = copyWith()
    //     0xb2336c: bl              #0x690914  ; [package:flutter/src/rendering/box.dart] BoxConstraints::copyWith
    // 0xb23370: add             SP, SP, #0x18
    // 0xb23374: mov             x1, x0
    // 0xb23378: ldr             x0, [fp, #0x18]
    // 0xb2337c: stur            x1, [fp, #-0x68]
    // 0xb23380: LoadField: r2 = r0->field_63
    //     0xb23380: ldur            w2, [x0, #0x63]
    // 0xb23384: DecompressPointer r2
    //     0xb23384: add             x2, x2, HEAP, lsl #32
    // 0xb23388: stur            x2, [fp, #-0x60]
    // 0xb2338c: LoadField: r3 = r0->field_77
    //     0xb2338c: ldur            w3, [x0, #0x77]
    // 0xb23390: DecompressPointer r3
    //     0xb23390: add             x3, x3, HEAP, lsl #32
    // 0xb23394: cmp             w3, NULL
    // 0xb23398: b.ne            #0xb233b0
    // 0xb2339c: ldur            x3, [fp, #-8]
    // 0xb233a0: LoadField: r4 = r3->field_17
    //     0xb233a0: ldur            w4, [x3, #0x17]
    // 0xb233a4: DecompressPointer r4
    //     0xb233a4: add             x4, x4, HEAP, lsl #32
    // 0xb233a8: mov             x12, x4
    // 0xb233ac: b               #0xb233b4
    // 0xb233b0: mov             x12, x3
    // 0xb233b4: ldur            x11, [fp, #-0x10]
    // 0xb233b8: ldur            x10, [fp, #-0x28]
    // 0xb233bc: ldur            x9, [fp, #-0x20]
    // 0xb233c0: ldur            x3, [fp, #-0x58]
    // 0xb233c4: ldur            x4, [fp, #-0x50]
    // 0xb233c8: ldur            x7, [fp, #-0x38]
    // 0xb233cc: ldur            x6, [fp, #-0x40]
    // 0xb233d0: ldur            x5, [fp, #-0x48]
    // 0xb233d4: ldur            x8, [fp, #-0x30]
    // 0xb233d8: ldur            d0, [fp, #-0x70]
    // 0xb233dc: stur            x12, [fp, #-0x18]
    // 0xb233e0: LoadField: r13 = r0->field_57
    //     0xb233e0: ldur            w13, [x0, #0x57]
    // 0xb233e4: DecompressPointer r13
    //     0xb233e4: add             x13, x13, HEAP, lsl #32
    // 0xb233e8: stur            x13, [fp, #-8]
    // 0xb233ec: r0 = RawMaterialButton()
    //     0xb233ec: bl              #0xb210e8  ; AllocateRawMaterialButtonStub -> RawMaterialButton (size=0x88)
    // 0xb233f0: ldur            x1, [fp, #-0x10]
    // 0xb233f4: StoreField: r0->field_b = r1
    //     0xb233f4: stur            w1, [x0, #0xb]
    // 0xb233f8: ldur            x1, [fp, #-0x20]
    // 0xb233fc: StoreField: r0->field_1b = r1
    //     0xb233fc: stur            w1, [x0, #0x1b]
    // 0xb23400: ldur            x1, [fp, #-0x28]
    // 0xb23404: StoreField: r0->field_1f = r1
    //     0xb23404: stur            w1, [x0, #0x1f]
    // 0xb23408: ldur            x1, [fp, #-0x30]
    // 0xb2340c: StoreField: r0->field_23 = r1
    //     0xb2340c: stur            w1, [x0, #0x23]
    // 0xb23410: ldur            x1, [fp, #-0x48]
    // 0xb23414: StoreField: r0->field_27 = r1
    //     0xb23414: stur            w1, [x0, #0x27]
    // 0xb23418: ldur            x1, [fp, #-0x40]
    // 0xb2341c: StoreField: r0->field_2b = r1
    //     0xb2341c: stur            w1, [x0, #0x2b]
    // 0xb23420: ldur            x1, [fp, #-0x38]
    // 0xb23424: StoreField: r0->field_2f = r1
    //     0xb23424: stur            w1, [x0, #0x2f]
    // 0xb23428: ldur            d0, [fp, #-0x70]
    // 0xb2342c: StoreField: r0->field_33 = d0
    //     0xb2342c: stur            d0, [x0, #0x33]
    // 0xb23430: d0 = 4.000000
    //     0xb23430: fmov            d0, #4.00000000
    // 0xb23434: StoreField: r0->field_43 = d0
    //     0xb23434: stur            d0, [x0, #0x43]
    // 0xb23438: StoreField: r0->field_3b = d0
    //     0xb23438: stur            d0, [x0, #0x3b]
    // 0xb2343c: d0 = 8.000000
    //     0xb2343c: fmov            d0, #8.00000000
    // 0xb23440: StoreField: r0->field_4b = d0
    //     0xb23440: stur            d0, [x0, #0x4b]
    // 0xb23444: d0 = 0.000000
    //     0xb23444: eor             v0.16b, v0.16b, v0.16b
    // 0xb23448: StoreField: r0->field_53 = d0
    //     0xb23448: stur            d0, [x0, #0x53]
    // 0xb2344c: ldur            x1, [fp, #-0x58]
    // 0xb23450: StoreField: r0->field_5b = r1
    //     0xb23450: stur            w1, [x0, #0x5b]
    // 0xb23454: ldur            x1, [fp, #-0x50]
    // 0xb23458: StoreField: r0->field_5f = r1
    //     0xb23458: stur            w1, [x0, #0x5f]
    // 0xb2345c: ldur            x1, [fp, #-0x68]
    // 0xb23460: StoreField: r0->field_63 = r1
    //     0xb23460: stur            w1, [x0, #0x63]
    // 0xb23464: ldur            x1, [fp, #-0x60]
    // 0xb23468: StoreField: r0->field_67 = r1
    //     0xb23468: stur            w1, [x0, #0x67]
    // 0xb2346c: r1 = Instance_Duration
    //     0xb2346c: add             x1, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xb23470: ldr             x1, [x1, #0x9e0]
    // 0xb23474: StoreField: r0->field_6b = r1
    //     0xb23474: stur            w1, [x0, #0x6b]
    // 0xb23478: r1 = Instance_Clip
    //     0xb23478: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0xb2347c: ldr             x1, [x1, #0xb38]
    // 0xb23480: StoreField: r0->field_7f = r1
    //     0xb23480: stur            w1, [x0, #0x7f]
    // 0xb23484: r1 = false
    //     0xb23484: add             x1, NULL, #0x30  ; false
    // 0xb23488: StoreField: r0->field_7b = r1
    //     0xb23488: stur            w1, [x0, #0x7b]
    // 0xb2348c: ldur            x1, [fp, #-8]
    // 0xb23490: StoreField: r0->field_6f = r1
    //     0xb23490: stur            w1, [x0, #0x6f]
    // 0xb23494: r1 = true
    //     0xb23494: add             x1, NULL, #0x20  ; true
    // 0xb23498: StoreField: r0->field_83 = r1
    //     0xb23498: stur            w1, [x0, #0x83]
    // 0xb2349c: ldur            x1, [fp, #-0x18]
    // 0xb234a0: StoreField: r0->field_73 = r1
    //     0xb234a0: stur            w1, [x0, #0x73]
    // 0xb234a4: LeaveFrame
    //     0xb234a4: mov             SP, fp
    //     0xb234a8: ldp             fp, lr, [SP], #0x10
    // 0xb234ac: ret
    //     0xb234ac: ret             
    // 0xb234b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb234b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb234b4: b               #0xb231d4
    // 0xb234b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb234b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb234bc: SaveReg d0
    //     0xb234bc: str             q0, [SP, #-0x10]!
    // 0xb234c0: stp             x1, x2, [SP, #-0x10]!
    // 0xb234c4: SaveReg r0
    //     0xb234c4: str             x0, [SP, #-8]!
    // 0xb234c8: r0 = AllocateDouble()
    //     0xb234c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb234cc: mov             x3, x0
    // 0xb234d0: RestoreReg r0
    //     0xb234d0: ldr             x0, [SP], #8
    // 0xb234d4: ldp             x1, x2, [SP], #0x10
    // 0xb234d8: RestoreReg d0
    //     0xb234d8: ldr             q0, [SP], #0x10
    // 0xb234dc: b               #0xb23358
  }
}

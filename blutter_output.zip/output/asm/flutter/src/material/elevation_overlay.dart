// lib: , url: package:flutter/src/material/elevation_overlay.dart

// class id: 1049235, size: 0x8
class :: {
}

// class id: 2213, size: 0x18, field offset: 0x8
//   const constructor, 
class _ElevationOpacity extends Object {

  _Mint field_8;
  _Mint field_10;
}

// class id: 2214, size: 0x8, field offset: 0x8
abstract class ElevationOverlay extends Object {

  static _ applyOverlay(/* No info */) {
    // ** addr: 0x860624, size: 0x13c
    // 0x860624: EnterFrame
    //     0x860624: stp             fp, lr, [SP, #-0x10]!
    //     0x860628: mov             fp, SP
    // 0x86062c: AllocStack(0x18)
    //     0x86062c: sub             SP, SP, #0x18
    // 0x860630: CheckStackOverflow
    //     0x860630: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860634: cmp             SP, x16
    //     0x860638: b.ls            #0x860758
    // 0x86063c: ldr             x16, [fp, #0x20]
    // 0x860640: SaveReg r16
    //     0x860640: str             x16, [SP, #-8]!
    // 0x860644: r0 = of()
    //     0x860644: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x860648: add             SP, SP, #8
    // 0x86064c: ldr             d1, [fp, #0x10]
    // 0x860650: d0 = 0.000000
    //     0x860650: eor             v0.16b, v0.16b, v0.16b
    // 0x860654: fcmp            d1, d0
    // 0x860658: b.vs            #0x860748
    // 0x86065c: b.le            #0x860748
    // 0x860660: LoadField: r1 = r0->field_7
    //     0x860660: ldur            w1, [x0, #7]
    // 0x860664: DecompressPointer r1
    //     0x860664: add             x1, x1, HEAP, lsl #32
    // 0x860668: tbnz            w1, #4, #0x860748
    // 0x86066c: LoadField: r1 = r0->field_3f
    //     0x86066c: ldur            w1, [x0, #0x3f]
    // 0x860670: DecompressPointer r1
    //     0x860670: add             x1, x1, HEAP, lsl #32
    // 0x860674: stur            x1, [fp, #-8]
    // 0x860678: LoadField: r0 = r1->field_7
    //     0x860678: ldur            w0, [x1, #7]
    // 0x86067c: DecompressPointer r0
    //     0x86067c: add             x0, x0, HEAP, lsl #32
    // 0x860680: r16 = Instance_Brightness
    //     0x860680: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x860684: cmp             w0, w16
    // 0x860688: b.ne            #0x860748
    // 0x86068c: d0 = 1.000000
    //     0x86068c: fmov            d0, #1.00000000
    // 0x860690: ldr             x16, [fp, #0x18]
    // 0x860694: SaveReg r16
    //     0x860694: str             x16, [SP, #-8]!
    // 0x860698: SaveReg d0
    //     0x860698: str             d0, [SP, #-8]!
    // 0x86069c: r0 = withOpacity()
    //     0x86069c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8606a0: add             SP, SP, #0x10
    // 0x8606a4: mov             x1, x0
    // 0x8606a8: ldur            x0, [fp, #-8]
    // 0x8606ac: stur            x1, [fp, #-0x10]
    // 0x8606b0: LoadField: r2 = r0->field_53
    //     0x8606b0: ldur            w2, [x0, #0x53]
    // 0x8606b4: DecompressPointer r2
    //     0x8606b4: add             x2, x2, HEAP, lsl #32
    // 0x8606b8: SaveReg r2
    //     0x8606b8: str             x2, [SP, #-8]!
    // 0x8606bc: d0 = 1.000000
    //     0x8606bc: fmov            d0, #1.00000000
    // 0x8606c0: SaveReg d0
    //     0x8606c0: str             d0, [SP, #-8]!
    // 0x8606c4: r0 = withOpacity()
    //     0x8606c4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8606c8: add             SP, SP, #0x10
    // 0x8606cc: mov             x1, x0
    // 0x8606d0: ldur            x0, [fp, #-0x10]
    // 0x8606d4: stur            x1, [fp, #-0x18]
    // 0x8606d8: cmp             w0, w1
    // 0x8606dc: b.eq            #0x860718
    // 0x8606e0: r16 = Color
    //     0x8606e0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x8606e4: ldr             x16, [x16, #0xf18]
    // 0x8606e8: r30 = Color
    //     0x8606e8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x8606ec: ldr             lr, [lr, #0xf18]
    // 0x8606f0: stp             lr, x16, [SP, #-0x10]!
    // 0x8606f4: r0 = ==()
    //     0x8606f4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x8606f8: add             SP, SP, #0x10
    // 0x8606fc: tbnz            w0, #4, #0x860748
    // 0x860700: ldur            x0, [fp, #-0x10]
    // 0x860704: ldur            x1, [fp, #-0x18]
    // 0x860708: LoadField: r2 = r1->field_7
    //     0x860708: ldur            x2, [x1, #7]
    // 0x86070c: LoadField: r1 = r0->field_7
    //     0x86070c: ldur            x1, [x0, #7]
    // 0x860710: cmp             x2, x1
    // 0x860714: b.ne            #0x860748
    // 0x860718: ldr             d0, [fp, #0x10]
    // 0x86071c: ldur            x0, [fp, #-8]
    // 0x860720: LoadField: r1 = r0->field_57
    //     0x860720: ldur            w1, [x0, #0x57]
    // 0x860724: DecompressPointer r1
    //     0x860724: add             x1, x1, HEAP, lsl #32
    // 0x860728: ldr             x16, [fp, #0x18]
    // 0x86072c: stp             x1, x16, [SP, #-0x10]!
    // 0x860730: SaveReg d0
    //     0x860730: str             d0, [SP, #-8]!
    // 0x860734: r0 = colorWithOverlay()
    //     0x860734: bl              #0x860760  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::colorWithOverlay
    // 0x860738: add             SP, SP, #0x18
    // 0x86073c: LeaveFrame
    //     0x86073c: mov             SP, fp
    //     0x860740: ldp             fp, lr, [SP], #0x10
    // 0x860744: ret
    //     0x860744: ret             
    // 0x860748: ldr             x0, [fp, #0x18]
    // 0x86074c: LeaveFrame
    //     0x86074c: mov             SP, fp
    //     0x860750: ldp             fp, lr, [SP], #0x10
    // 0x860754: ret
    //     0x860754: ret             
    // 0x860758: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860758: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86075c: b               #0x86063c
  }
  static _ colorWithOverlay(/* No info */) {
    // ** addr: 0x860760, size: 0x50
    // 0x860760: EnterFrame
    //     0x860760: stp             fp, lr, [SP, #-0x10]!
    //     0x860764: mov             fp, SP
    // 0x860768: CheckStackOverflow
    //     0x860768: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86076c: cmp             SP, x16
    //     0x860770: b.ls            #0x8607a8
    // 0x860774: ldr             x16, [fp, #0x18]
    // 0x860778: SaveReg r16
    //     0x860778: str             x16, [SP, #-8]!
    // 0x86077c: ldr             d0, [fp, #0x10]
    // 0x860780: SaveReg d0
    //     0x860780: str             d0, [SP, #-8]!
    // 0x860784: r0 = _overlayColor()
    //     0x860784: bl              #0x8607b0  ; [package:flutter/src/material/elevation_overlay.dart] ElevationOverlay::_overlayColor
    // 0x860788: add             SP, SP, #0x10
    // 0x86078c: ldr             x16, [fp, #0x20]
    // 0x860790: stp             x16, x0, [SP, #-0x10]!
    // 0x860794: r0 = alphaBlend()
    //     0x860794: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0x860798: add             SP, SP, #0x10
    // 0x86079c: LeaveFrame
    //     0x86079c: mov             SP, fp
    //     0x8607a0: ldp             fp, lr, [SP], #0x10
    // 0x8607a4: ret
    //     0x8607a4: ret             
    // 0x8607a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8607a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8607ac: b               #0x860774
  }
  static _ _overlayColor(/* No info */) {
    // ** addr: 0x8607b0, size: 0xa0
    // 0x8607b0: EnterFrame
    //     0x8607b0: stp             fp, lr, [SP, #-0x10]!
    //     0x8607b4: mov             fp, SP
    // 0x8607b8: d0 = 1.000000
    //     0x8607b8: fmov            d0, #1.00000000
    // 0x8607bc: CheckStackOverflow
    //     0x8607bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8607c0: cmp             SP, x16
    //     0x8607c4: b.ls            #0x860848
    // 0x8607c8: ldr             d1, [fp, #0x10]
    // 0x8607cc: fadd            d2, d1, d0
    // 0x8607d0: mov             v0.16b, v2.16b
    // 0x8607d4: stp             fp, lr, [SP, #-0x10]!
    // 0x8607d8: mov             fp, SP
    // 0x8607dc: CallRuntime_LibcLog(double) -> double
    //     0x8607dc: and             SP, SP, #0xfffffffffffffff0
    //     0x8607e0: mov             sp, SP
    //     0x8607e4: ldr             x16, [THR, #0x5c0]  ; THR::LibcLog
    //     0x8607e8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x8607ec: blr             x16
    //     0x8607f0: mov             x16, #8
    //     0x8607f4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x8607f8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x8607fc: sub             sp, x16, #1, lsl #12
    //     0x860800: mov             SP, fp
    //     0x860804: ldp             fp, lr, [SP], #0x10
    // 0x860808: mov             v1.16b, v0.16b
    // 0x86080c: d0 = 4.500000
    //     0x86080c: fmov            d0, #4.50000000
    // 0x860810: fmul            d2, d0, d1
    // 0x860814: d0 = 2.000000
    //     0x860814: fmov            d0, #2.00000000
    // 0x860818: fadd            d1, d2, d0
    // 0x86081c: d0 = 100.000000
    //     0x86081c: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x860820: ldr             d0, [x17, #0x308]
    // 0x860824: fdiv            d2, d1, d0
    // 0x860828: ldr             x16, [fp, #0x18]
    // 0x86082c: SaveReg r16
    //     0x86082c: str             x16, [SP, #-8]!
    // 0x860830: SaveReg d2
    //     0x860830: str             d2, [SP, #-8]!
    // 0x860834: r0 = withOpacity()
    //     0x860834: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x860838: add             SP, SP, #0x10
    // 0x86083c: LeaveFrame
    //     0x86083c: mov             SP, fp
    //     0x860840: ldp             fp, lr, [SP], #0x10
    // 0x860844: ret
    //     0x860844: ret             
    // 0x860848: r0 = StackOverflowSharedWithFPURegs()
    //     0x860848: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x86084c: b               #0x8607c8
  }
  static _ applySurfaceTint(/* No info */) {
    // ** addr: 0x860850, size: 0x238
    // 0x860850: EnterFrame
    //     0x860850: stp             fp, lr, [SP, #-0x10]!
    //     0x860854: mov             fp, SP
    // 0x860858: AllocStack(0x8)
    //     0x860858: sub             SP, SP, #8
    // 0x86085c: CheckStackOverflow
    //     0x86085c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x860860: cmp             SP, x16
    //     0x860864: b.ls            #0x860a70
    // 0x860868: ldr             x0, [fp, #0x18]
    // 0x86086c: cmp             w0, NULL
    // 0x860870: b.eq            #0x860a60
    // 0x860874: r1 = LoadClassIdInstr(r0)
    //     0x860874: ldur            x1, [x0, #-1]
    //     0x860878: ubfx            x1, x1, #0xc, #0x14
    // 0x86087c: lsl             x1, x1, #1
    // 0x860880: stur            x1, [fp, #-8]
    // 0x860884: r17 = 10114
    //     0x860884: mov             x17, #0x2782
    // 0x860888: cmp             w1, w17
    // 0x86088c: b.eq            #0x86089c
    // 0x860890: r17 = 10118
    //     0x860890: mov             x17, #0x2786
    // 0x860894: cmp             w1, w17
    // 0x860898: b.ne            #0x86092c
    // 0x86089c: r16 = Instance_Color
    //     0x86089c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x8608a0: ldr             x16, [x16, #0xc08]
    // 0x8608a4: cmp             w0, w16
    // 0x8608a8: b.eq            #0x860a60
    // 0x8608ac: SaveReg r0
    //     0x8608ac: str             x0, [SP, #-8]!
    // 0x8608b0: r0 = runtimeType()
    //     0x8608b0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0x8608b4: add             SP, SP, #8
    // 0x8608b8: r16 = Color
    //     0x8608b8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x8608bc: ldr             x16, [x16, #0xf18]
    // 0x8608c0: stp             x0, x16, [SP, #-0x10]!
    // 0x8608c4: r0 = ==()
    //     0x8608c4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x8608c8: add             SP, SP, #0x10
    // 0x8608cc: tbnz            w0, #4, #0x860958
    // 0x8608d0: ldur            x0, [fp, #-8]
    // 0x8608d4: r17 = 10124
    //     0x8608d4: mov             x17, #0x278c
    // 0x8608d8: cmp             w0, w17
    // 0x8608dc: b.gt            #0x8608ec
    // 0x8608e0: r17 = 10122
    //     0x8608e0: mov             x17, #0x278a
    // 0x8608e4: cmp             w0, w17
    // 0x8608e8: b.ge            #0x860904
    // 0x8608ec: r17 = 10114
    //     0x8608ec: mov             x17, #0x2782
    // 0x8608f0: cmp             w0, w17
    // 0x8608f4: b.eq            #0x860904
    // 0x8608f8: r17 = 10118
    //     0x8608f8: mov             x17, #0x2786
    // 0x8608fc: cmp             w0, w17
    // 0x860900: b.ne            #0x860910
    // 0x860904: ldr             x1, [fp, #0x18]
    // 0x860908: LoadField: r0 = r1->field_7
    //     0x860908: ldur            x0, [x1, #7]
    // 0x86090c: b               #0x860924
    // 0x860910: ldr             x1, [fp, #0x18]
    // 0x860914: LoadField: r0 = r1->field_f
    //     0x860914: ldur            w0, [x1, #0xf]
    // 0x860918: DecompressPointer r0
    //     0x860918: add             x0, x0, HEAP, lsl #32
    // 0x86091c: LoadField: r2 = r0->field_7
    //     0x86091c: ldur            x2, [x0, #7]
    // 0x860920: mov             x0, x2
    // 0x860924: cbz             x0, #0x860a60
    // 0x860928: b               #0x860958
    // 0x86092c: mov             x1, x0
    // 0x860930: r0 = LoadClassIdInstr(r1)
    //     0x860930: ldur            x0, [x1, #-1]
    //     0x860934: ubfx            x0, x0, #0xc, #0x14
    // 0x860938: r16 = Instance_Color
    //     0x860938: add             x16, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x86093c: ldr             x16, [x16, #0xc08]
    // 0x860940: stp             x16, x1, [SP, #-0x10]!
    // 0x860944: mov             lr, x0
    // 0x860948: ldr             lr, [x21, lr, lsl #3]
    // 0x86094c: blr             lr
    // 0x860950: add             SP, SP, #0x10
    // 0x860954: tbz             w0, #4, #0x860a60
    // 0x860958: ldr             d0, [fp, #0x10]
    // 0x86095c: r0 = Instance__ElevationOpacity
    //     0x86095c: add             x0, PP, #0x15, lsl #12  ; [pp+0x15310] Obj!_ElevationOpacity@b38651
    //     0x860960: ldr             x0, [x0, #0x310]
    // 0x860964: LoadField: d1 = r0->field_7
    //     0x860964: ldur            d1, [x0, #7]
    // 0x860968: fcmp            d0, d1
    // 0x86096c: b.vs            #0x86097c
    // 0x860970: b.ge            #0x86097c
    // 0x860974: LoadField: d0 = r0->field_f
    //     0x860974: ldur            d0, [x0, #0xf]
    // 0x860978: b               #0x860a30
    // 0x86097c: r3 = 0
    //     0x86097c: mov             x3, #0
    // 0x860980: r2 = const [Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity', Instance of '_ElevationOpacity']
    //     0x860980: add             x2, PP, #0x15, lsl #12  ; [pp+0x15318] List<_ElevationOpacity>(6)
    //     0x860984: ldr             x2, [x2, #0x318]
    // 0x860988: CheckStackOverflow
    //     0x860988: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86098c: cmp             SP, x16
    //     0x860990: b.ls            #0x860a78
    // 0x860994: mov             x1, x3
    // 0x860998: r0 = 6
    //     0x860998: mov             x0, #6
    // 0x86099c: cmp             x1, x0
    // 0x8609a0: b.hs            #0x860a80
    // 0x8609a4: ArrayLoad: r4 = r2[r3]  ; Unknown_4
    //     0x8609a4: add             x16, x2, x3, lsl #2
    //     0x8609a8: ldur            w4, [x16, #0xf]
    // 0x8609ac: DecompressPointer r4
    //     0x8609ac: add             x4, x4, HEAP, lsl #32
    // 0x8609b0: LoadField: d1 = r4->field_7
    //     0x8609b0: ldur            d1, [x4, #7]
    // 0x8609b4: fcmp            d0, d1
    // 0x8609b8: b.vs            #0x8609e8
    // 0x8609bc: b.lt            #0x8609e8
    // 0x8609c0: fcmp            d0, d1
    // 0x8609c4: b.vs            #0x8609cc
    // 0x8609c8: b.eq            #0x8609d8
    // 0x8609cc: add             x0, x3, #1
    // 0x8609d0: cmp             x0, #6
    // 0x8609d4: b.ne            #0x8609e0
    // 0x8609d8: LoadField: d0 = r4->field_f
    //     0x8609d8: ldur            d0, [x4, #0xf]
    // 0x8609dc: b               #0x860a30
    // 0x8609e0: mov             x3, x0
    // 0x8609e4: b               #0x860988
    // 0x8609e8: sub             x5, x3, #1
    // 0x8609ec: mov             x1, x5
    // 0x8609f0: r0 = 6
    //     0x8609f0: mov             x0, #6
    // 0x8609f4: cmp             x1, x0
    // 0x8609f8: b.hs            #0x860a84
    // 0x8609fc: ArrayLoad: r0 = r2[r5]  ; Unknown_4
    //     0x8609fc: add             x16, x2, x5, lsl #2
    //     0x860a00: ldur            w0, [x16, #0xf]
    // 0x860a04: DecompressPointer r0
    //     0x860a04: add             x0, x0, HEAP, lsl #32
    // 0x860a08: LoadField: d2 = r0->field_7
    //     0x860a08: ldur            d2, [x0, #7]
    // 0x860a0c: fsub            d3, d0, d2
    // 0x860a10: fsub            d0, d1, d2
    // 0x860a14: fdiv            d1, d3, d0
    // 0x860a18: LoadField: d0 = r0->field_f
    //     0x860a18: ldur            d0, [x0, #0xf]
    // 0x860a1c: LoadField: d2 = r4->field_f
    //     0x860a1c: ldur            d2, [x4, #0xf]
    // 0x860a20: fsub            d3, d2, d0
    // 0x860a24: fmul            d2, d1, d3
    // 0x860a28: fadd            d1, d0, d2
    // 0x860a2c: mov             v0.16b, v1.16b
    // 0x860a30: ldr             x16, [fp, #0x18]
    // 0x860a34: SaveReg r16
    //     0x860a34: str             x16, [SP, #-8]!
    // 0x860a38: SaveReg d0
    //     0x860a38: str             d0, [SP, #-8]!
    // 0x860a3c: r0 = withOpacity()
    //     0x860a3c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x860a40: add             SP, SP, #0x10
    // 0x860a44: ldr             x16, [fp, #0x20]
    // 0x860a48: stp             x16, x0, [SP, #-0x10]!
    // 0x860a4c: r0 = alphaBlend()
    //     0x860a4c: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0x860a50: add             SP, SP, #0x10
    // 0x860a54: LeaveFrame
    //     0x860a54: mov             SP, fp
    //     0x860a58: ldp             fp, lr, [SP], #0x10
    // 0x860a5c: ret
    //     0x860a5c: ret             
    // 0x860a60: ldr             x0, [fp, #0x20]
    // 0x860a64: LeaveFrame
    //     0x860a64: mov             SP, fp
    //     0x860a68: ldp             fp, lr, [SP], #0x10
    // 0x860a6c: ret
    //     0x860a6c: ret             
    // 0x860a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x860a70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x860a74: b               #0x860868
    // 0x860a78: r0 = StackOverflowSharedWithFPURegs()
    //     0x860a78: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x860a7c: b               #0x860994
    // 0x860a80: r0 = RangeErrorSharedWithFPURegs()
    //     0x860a80: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x860a84: r0 = RangeErrorSharedWithFPURegs()
    //     0x860a84: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
}

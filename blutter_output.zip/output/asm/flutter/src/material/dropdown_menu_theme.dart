// lib: , url: package:flutter/src/material/dropdown_menu_theme.dart

// class id: 1049232, size: 0x8
class :: {
}

// class id: 2804, size: 0x14, field offset: 0x8
//   const constructor, 
class DropdownMenuThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xaff33c, size: 0x60
    // 0xaff33c: EnterFrame
    //     0xaff33c: stp             fp, lr, [SP, #-0x10]!
    //     0xaff340: mov             fp, SP
    // 0xaff344: CheckStackOverflow
    //     0xaff344: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaff348: cmp             SP, x16
    //     0xaff34c: b.ls            #0xaff394
    // 0xaff350: ldr             x0, [fp, #0x10]
    // 0xaff354: LoadField: r1 = r0->field_f
    //     0xaff354: ldur            w1, [x0, #0xf]
    // 0xaff358: DecompressPointer r1
    //     0xaff358: add             x1, x1, HEAP, lsl #32
    // 0xaff35c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xaff360: SaveReg r1
    //     0xaff360: str             x1, [SP, #-8]!
    // 0xaff364: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xaff364: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xaff368: r0 = hash()
    //     0xaff368: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaff36c: add             SP, SP, #0x18
    // 0xaff370: mov             x2, x0
    // 0xaff374: r0 = BoxInt64Instr(r2)
    //     0xaff374: sbfiz           x0, x2, #1, #0x1f
    //     0xaff378: cmp             x2, x0, asr #1
    //     0xaff37c: b.eq            #0xaff388
    //     0xaff380: bl              #0xd69bb8
    //     0xaff384: stur            x2, [x0, #7]
    // 0xaff388: LeaveFrame
    //     0xaff388: mov             SP, fp
    //     0xaff38c: ldp             fp, lr, [SP], #0x10
    // 0xaff390: ret
    //     0xaff390: ret             
    // 0xaff394: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaff394: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaff398: b               #0xaff350
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf4b98, size: 0xb4
    // 0xbf4b98: EnterFrame
    //     0xbf4b98: stp             fp, lr, [SP, #-0x10]!
    //     0xbf4b9c: mov             fp, SP
    // 0xbf4ba0: AllocStack(0x8)
    //     0xbf4ba0: sub             SP, SP, #8
    // 0xbf4ba4: CheckStackOverflow
    //     0xbf4ba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf4ba8: cmp             SP, x16
    //     0xbf4bac: b.ls            #0xbf4c34
    // 0xbf4bb0: ldr             d0, [fp, #0x10]
    // 0xbf4bb4: r0 = inline_Allocate_Double()
    //     0xbf4bb4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbf4bb8: add             x0, x0, #0x10
    //     0xbf4bbc: cmp             x1, x0
    //     0xbf4bc0: b.ls            #0xbf4c3c
    //     0xbf4bc4: str             x0, [THR, #0x60]  ; THR::top
    //     0xbf4bc8: sub             x0, x0, #0xf
    //     0xbf4bcc: mov             x1, #0xd108
    //     0xbf4bd0: movk            x1, #3, lsl #16
    //     0xbf4bd4: stur            x1, [x0, #-1]
    // 0xbf4bd8: StoreField: r0->field_7 = d0
    //     0xbf4bd8: stur            d0, [x0, #7]
    // 0xbf4bdc: stp             NULL, NULL, [SP, #-0x10]!
    // 0xbf4be0: SaveReg r0
    //     0xbf4be0: str             x0, [SP, #-8]!
    // 0xbf4be4: r0 = lerp()
    //     0xbf4be4: bl              #0xaeb46c  ; [package:flutter/src/painting/text_style.dart] TextStyle::lerp
    // 0xbf4be8: add             SP, SP, #0x18
    // 0xbf4bec: ldr             x0, [fp, #0x20]
    // 0xbf4bf0: LoadField: r1 = r0->field_f
    //     0xbf4bf0: ldur            w1, [x0, #0xf]
    // 0xbf4bf4: DecompressPointer r1
    //     0xbf4bf4: add             x1, x1, HEAP, lsl #32
    // 0xbf4bf8: ldr             x0, [fp, #0x18]
    // 0xbf4bfc: LoadField: r2 = r0->field_f
    //     0xbf4bfc: ldur            w2, [x0, #0xf]
    // 0xbf4c00: DecompressPointer r2
    //     0xbf4c00: add             x2, x2, HEAP, lsl #32
    // 0xbf4c04: stp             x2, x1, [SP, #-0x10]!
    // 0xbf4c08: ldr             d0, [fp, #0x10]
    // 0xbf4c0c: SaveReg d0
    //     0xbf4c0c: str             d0, [SP, #-8]!
    // 0xbf4c10: r0 = lerp()
    //     0xbf4c10: bl              #0xbf3ca8  ; [package:flutter/src/material/menu_style.dart] MenuStyle::lerp
    // 0xbf4c14: add             SP, SP, #0x18
    // 0xbf4c18: stur            x0, [fp, #-8]
    // 0xbf4c1c: r0 = DropdownMenuThemeData()
    //     0xbf4c1c: bl              #0xbf4c4c  ; AllocateDropdownMenuThemeDataStub -> DropdownMenuThemeData (size=0x14)
    // 0xbf4c20: ldur            x1, [fp, #-8]
    // 0xbf4c24: StoreField: r0->field_f = r1
    //     0xbf4c24: stur            w1, [x0, #0xf]
    // 0xbf4c28: LeaveFrame
    //     0xbf4c28: mov             SP, fp
    //     0xbf4c2c: ldp             fp, lr, [SP], #0x10
    // 0xbf4c30: ret
    //     0xbf4c30: ret             
    // 0xbf4c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf4c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf4c38: b               #0xbf4bb0
    // 0xbf4c3c: SaveReg d0
    //     0xbf4c3c: str             q0, [SP, #-0x10]!
    // 0xbf4c40: r0 = AllocateDouble()
    //     0xbf4c40: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf4c44: RestoreReg d0
    //     0xbf4c44: ldr             q0, [SP], #0x10
    // 0xbf4c48: b               #0xbf4bd8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8884c, size: 0x124
    // 0xc8884c: EnterFrame
    //     0xc8884c: stp             fp, lr, [SP, #-0x10]!
    //     0xc88850: mov             fp, SP
    // 0xc88854: CheckStackOverflow
    //     0xc88854: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc88858: cmp             SP, x16
    //     0xc8885c: b.ls            #0xc88968
    // 0xc88860: ldr             x1, [fp, #0x10]
    // 0xc88864: cmp             w1, NULL
    // 0xc88868: b.ne            #0xc8887c
    // 0xc8886c: r0 = false
    //     0xc8886c: add             x0, NULL, #0x30  ; false
    // 0xc88870: LeaveFrame
    //     0xc88870: mov             SP, fp
    //     0xc88874: ldp             fp, lr, [SP], #0x10
    // 0xc88878: ret
    //     0xc88878: ret             
    // 0xc8887c: ldr             x2, [fp, #0x18]
    // 0xc88880: cmp             w2, w1
    // 0xc88884: b.ne            #0xc88898
    // 0xc88888: r0 = true
    //     0xc88888: add             x0, NULL, #0x20  ; true
    // 0xc8888c: LeaveFrame
    //     0xc8888c: mov             SP, fp
    //     0xc88890: ldp             fp, lr, [SP], #0x10
    // 0xc88894: ret
    //     0xc88894: ret             
    // 0xc88898: r0 = 59
    //     0xc88898: mov             x0, #0x3b
    // 0xc8889c: branchIfSmi(r1, 0xc888a8)
    //     0xc8889c: tbz             w1, #0, #0xc888a8
    // 0xc888a0: r0 = LoadClassIdInstr(r1)
    //     0xc888a0: ldur            x0, [x1, #-1]
    //     0xc888a4: ubfx            x0, x0, #0xc, #0x14
    // 0xc888a8: SaveReg r1
    //     0xc888a8: str             x1, [SP, #-8]!
    // 0xc888ac: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc888ac: mov             x17, #0x57c5
    //     0xc888b0: add             lr, x0, x17
    //     0xc888b4: ldr             lr, [x21, lr, lsl #3]
    //     0xc888b8: blr             lr
    // 0xc888bc: add             SP, SP, #8
    // 0xc888c0: r1 = LoadClassIdInstr(r0)
    //     0xc888c0: ldur            x1, [x0, #-1]
    //     0xc888c4: ubfx            x1, x1, #0xc, #0x14
    // 0xc888c8: r16 = DropdownMenuThemeData
    //     0xc888c8: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3a8] Type: DropdownMenuThemeData
    //     0xc888cc: ldr             x16, [x16, #0x3a8]
    // 0xc888d0: stp             x16, x0, [SP, #-0x10]!
    // 0xc888d4: mov             x0, x1
    // 0xc888d8: mov             lr, x0
    // 0xc888dc: ldr             lr, [x21, lr, lsl #3]
    // 0xc888e0: blr             lr
    // 0xc888e4: add             SP, SP, #0x10
    // 0xc888e8: tbz             w0, #4, #0xc888fc
    // 0xc888ec: r0 = false
    //     0xc888ec: add             x0, NULL, #0x30  ; false
    // 0xc888f0: LeaveFrame
    //     0xc888f0: mov             SP, fp
    //     0xc888f4: ldp             fp, lr, [SP], #0x10
    // 0xc888f8: ret
    //     0xc888f8: ret             
    // 0xc888fc: ldr             x0, [fp, #0x10]
    // 0xc88900: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc88900: mov             x1, #0x76
    //     0xc88904: tbz             w0, #0, #0xc88914
    //     0xc88908: ldur            x1, [x0, #-1]
    //     0xc8890c: ubfx            x1, x1, #0xc, #0x14
    //     0xc88910: lsl             x1, x1, #1
    // 0xc88914: r17 = 5608
    //     0xc88914: mov             x17, #0x15e8
    // 0xc88918: cmp             w1, w17
    // 0xc8891c: b.ne            #0xc88958
    // 0xc88920: ldr             x1, [fp, #0x18]
    // 0xc88924: LoadField: r2 = r0->field_f
    //     0xc88924: ldur            w2, [x0, #0xf]
    // 0xc88928: DecompressPointer r2
    //     0xc88928: add             x2, x2, HEAP, lsl #32
    // 0xc8892c: LoadField: r0 = r1->field_f
    //     0xc8892c: ldur            w0, [x1, #0xf]
    // 0xc88930: DecompressPointer r0
    //     0xc88930: add             x0, x0, HEAP, lsl #32
    // 0xc88934: r1 = LoadClassIdInstr(r2)
    //     0xc88934: ldur            x1, [x2, #-1]
    //     0xc88938: ubfx            x1, x1, #0xc, #0x14
    // 0xc8893c: stp             x0, x2, [SP, #-0x10]!
    // 0xc88940: mov             x0, x1
    // 0xc88944: mov             lr, x0
    // 0xc88948: ldr             lr, [x21, lr, lsl #3]
    // 0xc8894c: blr             lr
    // 0xc88950: add             SP, SP, #0x10
    // 0xc88954: b               #0xc8895c
    // 0xc88958: r0 = false
    //     0xc88958: add             x0, NULL, #0x30  ; false
    // 0xc8895c: LeaveFrame
    //     0xc8895c: mov             SP, fp
    //     0xc88960: ldp             fp, lr, [SP], #0x10
    // 0xc88964: ret
    //     0xc88964: ret             
    // 0xc88968: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc88968: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8896c: b               #0xc88860
  }
}

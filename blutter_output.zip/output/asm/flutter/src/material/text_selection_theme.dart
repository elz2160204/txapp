// lib: , url: package:flutter/src/material/text_selection_theme.dart

// class id: 1049326, size: 0x8
class :: {
}

// class id: 2720, size: 0x14, field offset: 0x8
//   const constructor, 
class TextSelectionThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbef1a8, size: 0x130
    // 0xbef1a8: EnterFrame
    //     0xbef1a8: stp             fp, lr, [SP, #-0x10]!
    //     0xbef1ac: mov             fp, SP
    // 0xbef1b0: AllocStack(0x18)
    //     0xbef1b0: sub             SP, SP, #0x18
    // 0xbef1b4: CheckStackOverflow
    //     0xbef1b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbef1b8: cmp             SP, x16
    //     0xbef1bc: b.ls            #0xbef2ac
    // 0xbef1c0: ldr             x0, [fp, #0x20]
    // 0xbef1c4: LoadField: r1 = r0->field_7
    //     0xbef1c4: ldur            w1, [x0, #7]
    // 0xbef1c8: DecompressPointer r1
    //     0xbef1c8: add             x1, x1, HEAP, lsl #32
    // 0xbef1cc: ldr             x2, [fp, #0x18]
    // 0xbef1d0: LoadField: r3 = r2->field_7
    //     0xbef1d0: ldur            w3, [x2, #7]
    // 0xbef1d4: DecompressPointer r3
    //     0xbef1d4: add             x3, x3, HEAP, lsl #32
    // 0xbef1d8: ldr             d0, [fp, #0x10]
    // 0xbef1dc: r4 = inline_Allocate_Double()
    //     0xbef1dc: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xbef1e0: add             x4, x4, #0x10
    //     0xbef1e4: cmp             x5, x4
    //     0xbef1e8: b.ls            #0xbef2b4
    //     0xbef1ec: str             x4, [THR, #0x60]  ; THR::top
    //     0xbef1f0: sub             x4, x4, #0xf
    //     0xbef1f4: mov             x5, #0xd108
    //     0xbef1f8: movk            x5, #3, lsl #16
    //     0xbef1fc: stur            x5, [x4, #-1]
    // 0xbef200: StoreField: r4->field_7 = d0
    //     0xbef200: stur            d0, [x4, #7]
    // 0xbef204: stur            x4, [fp, #-8]
    // 0xbef208: stp             x3, x1, [SP, #-0x10]!
    // 0xbef20c: SaveReg r4
    //     0xbef20c: str             x4, [SP, #-8]!
    // 0xbef210: r0 = lerp()
    //     0xbef210: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef214: add             SP, SP, #0x18
    // 0xbef218: mov             x1, x0
    // 0xbef21c: ldr             x0, [fp, #0x20]
    // 0xbef220: stur            x1, [fp, #-0x10]
    // 0xbef224: LoadField: r2 = r0->field_b
    //     0xbef224: ldur            w2, [x0, #0xb]
    // 0xbef228: DecompressPointer r2
    //     0xbef228: add             x2, x2, HEAP, lsl #32
    // 0xbef22c: ldr             x3, [fp, #0x18]
    // 0xbef230: LoadField: r4 = r3->field_b
    //     0xbef230: ldur            w4, [x3, #0xb]
    // 0xbef234: DecompressPointer r4
    //     0xbef234: add             x4, x4, HEAP, lsl #32
    // 0xbef238: stp             x4, x2, [SP, #-0x10]!
    // 0xbef23c: ldur            x16, [fp, #-8]
    // 0xbef240: SaveReg r16
    //     0xbef240: str             x16, [SP, #-8]!
    // 0xbef244: r0 = lerp()
    //     0xbef244: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef248: add             SP, SP, #0x18
    // 0xbef24c: mov             x1, x0
    // 0xbef250: ldr             x0, [fp, #0x20]
    // 0xbef254: stur            x1, [fp, #-0x18]
    // 0xbef258: LoadField: r2 = r0->field_f
    //     0xbef258: ldur            w2, [x0, #0xf]
    // 0xbef25c: DecompressPointer r2
    //     0xbef25c: add             x2, x2, HEAP, lsl #32
    // 0xbef260: ldr             x0, [fp, #0x18]
    // 0xbef264: LoadField: r3 = r0->field_f
    //     0xbef264: ldur            w3, [x0, #0xf]
    // 0xbef268: DecompressPointer r3
    //     0xbef268: add             x3, x3, HEAP, lsl #32
    // 0xbef26c: stp             x3, x2, [SP, #-0x10]!
    // 0xbef270: ldur            x16, [fp, #-8]
    // 0xbef274: SaveReg r16
    //     0xbef274: str             x16, [SP, #-8]!
    // 0xbef278: r0 = lerp()
    //     0xbef278: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xbef27c: add             SP, SP, #0x18
    // 0xbef280: stur            x0, [fp, #-8]
    // 0xbef284: r0 = TextSelectionThemeData()
    //     0xbef284: bl              #0x999dfc  ; AllocateTextSelectionThemeDataStub -> TextSelectionThemeData (size=0x14)
    // 0xbef288: ldur            x1, [fp, #-0x10]
    // 0xbef28c: StoreField: r0->field_7 = r1
    //     0xbef28c: stur            w1, [x0, #7]
    // 0xbef290: ldur            x1, [fp, #-0x18]
    // 0xbef294: StoreField: r0->field_b = r1
    //     0xbef294: stur            w1, [x0, #0xb]
    // 0xbef298: ldur            x1, [fp, #-8]
    // 0xbef29c: StoreField: r0->field_f = r1
    //     0xbef29c: stur            w1, [x0, #0xf]
    // 0xbef2a0: LeaveFrame
    //     0xbef2a0: mov             SP, fp
    //     0xbef2a4: ldp             fp, lr, [SP], #0x10
    // 0xbef2a8: ret
    //     0xbef2a8: ret             
    // 0xbef2ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbef2ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbef2b0: b               #0xbef1c0
    // 0xbef2b4: SaveReg d0
    //     0xbef2b4: str             q0, [SP, #-0x10]!
    // 0xbef2b8: stp             x2, x3, [SP, #-0x10]!
    // 0xbef2bc: stp             x0, x1, [SP, #-0x10]!
    // 0xbef2c0: r0 = AllocateDouble()
    //     0xbef2c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbef2c4: mov             x4, x0
    // 0xbef2c8: ldp             x0, x1, [SP], #0x10
    // 0xbef2cc: ldp             x2, x3, [SP], #0x10
    // 0xbef2d0: RestoreReg d0
    //     0xbef2d0: ldr             q0, [SP], #0x10
    // 0xbef2d4: b               #0xbef200
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8ff4c, size: 0x19c
    // 0xc8ff4c: EnterFrame
    //     0xc8ff4c: stp             fp, lr, [SP, #-0x10]!
    //     0xc8ff50: mov             fp, SP
    // 0xc8ff54: CheckStackOverflow
    //     0xc8ff54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8ff58: cmp             SP, x16
    //     0xc8ff5c: b.ls            #0xc900e0
    // 0xc8ff60: ldr             x1, [fp, #0x10]
    // 0xc8ff64: cmp             w1, NULL
    // 0xc8ff68: b.ne            #0xc8ff7c
    // 0xc8ff6c: r0 = false
    //     0xc8ff6c: add             x0, NULL, #0x30  ; false
    // 0xc8ff70: LeaveFrame
    //     0xc8ff70: mov             SP, fp
    //     0xc8ff74: ldp             fp, lr, [SP], #0x10
    // 0xc8ff78: ret
    //     0xc8ff78: ret             
    // 0xc8ff7c: ldr             x2, [fp, #0x18]
    // 0xc8ff80: cmp             w2, w1
    // 0xc8ff84: b.ne            #0xc8ff98
    // 0xc8ff88: r0 = true
    //     0xc8ff88: add             x0, NULL, #0x20  ; true
    // 0xc8ff8c: LeaveFrame
    //     0xc8ff8c: mov             SP, fp
    //     0xc8ff90: ldp             fp, lr, [SP], #0x10
    // 0xc8ff94: ret
    //     0xc8ff94: ret             
    // 0xc8ff98: r0 = 59
    //     0xc8ff98: mov             x0, #0x3b
    // 0xc8ff9c: branchIfSmi(r1, 0xc8ffa8)
    //     0xc8ff9c: tbz             w1, #0, #0xc8ffa8
    // 0xc8ffa0: r0 = LoadClassIdInstr(r1)
    //     0xc8ffa0: ldur            x0, [x1, #-1]
    //     0xc8ffa4: ubfx            x0, x0, #0xc, #0x14
    // 0xc8ffa8: SaveReg r1
    //     0xc8ffa8: str             x1, [SP, #-8]!
    // 0xc8ffac: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8ffac: mov             x17, #0x57c5
    //     0xc8ffb0: add             lr, x0, x17
    //     0xc8ffb4: ldr             lr, [x21, lr, lsl #3]
    //     0xc8ffb8: blr             lr
    // 0xc8ffbc: add             SP, SP, #8
    // 0xc8ffc0: r1 = LoadClassIdInstr(r0)
    //     0xc8ffc0: ldur            x1, [x0, #-1]
    //     0xc8ffc4: ubfx            x1, x1, #0xc, #0x14
    // 0xc8ffc8: r16 = TextSelectionThemeData
    //     0xc8ffc8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf40] Type: TextSelectionThemeData
    //     0xc8ffcc: ldr             x16, [x16, #0xf40]
    // 0xc8ffd0: stp             x16, x0, [SP, #-0x10]!
    // 0xc8ffd4: mov             x0, x1
    // 0xc8ffd8: mov             lr, x0
    // 0xc8ffdc: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ffe0: blr             lr
    // 0xc8ffe4: add             SP, SP, #0x10
    // 0xc8ffe8: tbz             w0, #4, #0xc8fffc
    // 0xc8ffec: r0 = false
    //     0xc8ffec: add             x0, NULL, #0x30  ; false
    // 0xc8fff0: LeaveFrame
    //     0xc8fff0: mov             SP, fp
    //     0xc8fff4: ldp             fp, lr, [SP], #0x10
    // 0xc8fff8: ret
    //     0xc8fff8: ret             
    // 0xc8fffc: ldr             x1, [fp, #0x10]
    // 0xc90000: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc90000: mov             x0, #0x76
    //     0xc90004: tbz             w1, #0, #0xc90014
    //     0xc90008: ldur            x0, [x1, #-1]
    //     0xc9000c: ubfx            x0, x0, #0xc, #0x14
    //     0xc90010: lsl             x0, x0, #1
    // 0xc90014: r17 = 5440
    //     0xc90014: mov             x17, #0x1540
    // 0xc90018: cmp             w0, w17
    // 0xc9001c: b.ne            #0xc900d0
    // 0xc90020: ldr             x2, [fp, #0x18]
    // 0xc90024: LoadField: r0 = r1->field_7
    //     0xc90024: ldur            w0, [x1, #7]
    // 0xc90028: DecompressPointer r0
    //     0xc90028: add             x0, x0, HEAP, lsl #32
    // 0xc9002c: LoadField: r3 = r2->field_7
    //     0xc9002c: ldur            w3, [x2, #7]
    // 0xc90030: DecompressPointer r3
    //     0xc90030: add             x3, x3, HEAP, lsl #32
    // 0xc90034: r4 = LoadClassIdInstr(r0)
    //     0xc90034: ldur            x4, [x0, #-1]
    //     0xc90038: ubfx            x4, x4, #0xc, #0x14
    // 0xc9003c: stp             x3, x0, [SP, #-0x10]!
    // 0xc90040: mov             x0, x4
    // 0xc90044: mov             lr, x0
    // 0xc90048: ldr             lr, [x21, lr, lsl #3]
    // 0xc9004c: blr             lr
    // 0xc90050: add             SP, SP, #0x10
    // 0xc90054: tbnz            w0, #4, #0xc900d0
    // 0xc90058: ldr             x2, [fp, #0x18]
    // 0xc9005c: ldr             x1, [fp, #0x10]
    // 0xc90060: LoadField: r0 = r1->field_b
    //     0xc90060: ldur            w0, [x1, #0xb]
    // 0xc90064: DecompressPointer r0
    //     0xc90064: add             x0, x0, HEAP, lsl #32
    // 0xc90068: LoadField: r3 = r2->field_b
    //     0xc90068: ldur            w3, [x2, #0xb]
    // 0xc9006c: DecompressPointer r3
    //     0xc9006c: add             x3, x3, HEAP, lsl #32
    // 0xc90070: r4 = LoadClassIdInstr(r0)
    //     0xc90070: ldur            x4, [x0, #-1]
    //     0xc90074: ubfx            x4, x4, #0xc, #0x14
    // 0xc90078: stp             x3, x0, [SP, #-0x10]!
    // 0xc9007c: mov             x0, x4
    // 0xc90080: mov             lr, x0
    // 0xc90084: ldr             lr, [x21, lr, lsl #3]
    // 0xc90088: blr             lr
    // 0xc9008c: add             SP, SP, #0x10
    // 0xc90090: tbnz            w0, #4, #0xc900d0
    // 0xc90094: ldr             x1, [fp, #0x18]
    // 0xc90098: ldr             x0, [fp, #0x10]
    // 0xc9009c: LoadField: r2 = r0->field_f
    //     0xc9009c: ldur            w2, [x0, #0xf]
    // 0xc900a0: DecompressPointer r2
    //     0xc900a0: add             x2, x2, HEAP, lsl #32
    // 0xc900a4: LoadField: r0 = r1->field_f
    //     0xc900a4: ldur            w0, [x1, #0xf]
    // 0xc900a8: DecompressPointer r0
    //     0xc900a8: add             x0, x0, HEAP, lsl #32
    // 0xc900ac: r1 = LoadClassIdInstr(r2)
    //     0xc900ac: ldur            x1, [x2, #-1]
    //     0xc900b0: ubfx            x1, x1, #0xc, #0x14
    // 0xc900b4: stp             x0, x2, [SP, #-0x10]!
    // 0xc900b8: mov             x0, x1
    // 0xc900bc: mov             lr, x0
    // 0xc900c0: ldr             lr, [x21, lr, lsl #3]
    // 0xc900c4: blr             lr
    // 0xc900c8: add             SP, SP, #0x10
    // 0xc900cc: b               #0xc900d4
    // 0xc900d0: r0 = false
    //     0xc900d0: add             x0, NULL, #0x30  ; false
    // 0xc900d4: LeaveFrame
    //     0xc900d4: mov             SP, fp
    //     0xc900d8: ldp             fp, lr, [SP], #0x10
    // 0xc900dc: ret
    //     0xc900dc: ret             
    // 0xc900e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc900e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc900e4: b               #0xc8ff60
  }
}

// class id: 3538, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class TextSelectionTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0x83d55c, size: 0x64
    // 0x83d55c: EnterFrame
    //     0x83d55c: stp             fp, lr, [SP, #-0x10]!
    //     0x83d560: mov             fp, SP
    // 0x83d564: CheckStackOverflow
    //     0x83d564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d568: cmp             SP, x16
    //     0x83d56c: b.ls            #0x83d5b8
    // 0x83d570: r16 = <TextSelectionTheme>
    //     0x83d570: add             x16, PP, #0x37, lsl #12  ; [pp+0x372d8] TypeArguments: <TextSelectionTheme>
    //     0x83d574: ldr             x16, [x16, #0x2d8]
    // 0x83d578: ldr             lr, [fp, #0x10]
    // 0x83d57c: stp             lr, x16, [SP, #-0x10]!
    // 0x83d580: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x83d580: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x83d584: r0 = dependOnInheritedWidgetOfExactType()
    //     0x83d584: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x83d588: add             SP, SP, #0x10
    // 0x83d58c: ldr             x16, [fp, #0x10]
    // 0x83d590: SaveReg r16
    //     0x83d590: str             x16, [SP, #-8]!
    // 0x83d594: r0 = of()
    //     0x83d594: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83d598: add             SP, SP, #8
    // 0x83d59c: r17 = 307
    //     0x83d59c: mov             x17, #0x133
    // 0x83d5a0: ldr             w1, [x0, x17]
    // 0x83d5a4: DecompressPointer r1
    //     0x83d5a4: add             x1, x1, HEAP, lsl #32
    // 0x83d5a8: mov             x0, x1
    // 0x83d5ac: LeaveFrame
    //     0x83d5ac: mov             SP, fp
    //     0x83d5b0: ldp             fp, lr, [SP], #0x10
    // 0x83d5b4: ret
    //     0x83d5b4: ret             
    // 0x83d5b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d5b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d5bc: b               #0x83d570
  }
}

// lib: , url: package:flutter/src/material/ink_splash.dart

// class id: 1049258, size: 0x8
class :: {

  static _ _getTargetRadius(/* No info */) {
    // ** addr: 0x8592f0, size: 0xa0
    // 0x8592f0: EnterFrame
    //     0x8592f0: stp             fp, lr, [SP, #-0x10]!
    //     0x8592f4: mov             fp, SP
    // 0x8592f8: CheckStackOverflow
    //     0x8592f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8592fc: cmp             SP, x16
    //     0x859300: b.ls            #0x859384
    // 0x859304: ldr             x0, [fp, #0x20]
    // 0x859308: tbnz            w0, #4, #0x859370
    // 0x85930c: ldr             x0, [fp, #0x18]
    // 0x859310: cmp             w0, NULL
    // 0x859314: b.eq            #0x85933c
    // 0x859318: SaveReg r0
    //     0x859318: str             x0, [SP, #-8]!
    // 0x85931c: ClosureCall
    //     0x85931c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x859320: ldur            x2, [x0, #0x1f]
    //     0x859324: blr             x2
    // 0x859328: add             SP, SP, #8
    // 0x85932c: SaveReg r0
    //     0x85932c: str             x0, [SP, #-8]!
    // 0x859330: r0 = size()
    //     0x859330: bl              #0x5bc584  ; [dart:ui] Rect::size
    // 0x859334: add             SP, SP, #8
    // 0x859338: b               #0x859354
    // 0x85933c: ldr             x0, [fp, #0x28]
    // 0x859340: LoadField: r1 = r0->field_57
    //     0x859340: ldur            w1, [x0, #0x57]
    // 0x859344: DecompressPointer r1
    //     0x859344: add             x1, x1, HEAP, lsl #32
    // 0x859348: cmp             w1, NULL
    // 0x85934c: b.eq            #0x85938c
    // 0x859350: mov             x0, x1
    // 0x859354: ldr             x16, [fp, #0x10]
    // 0x859358: stp             x16, x0, [SP, #-0x10]!
    // 0x85935c: r0 = _getSplashRadiusForPositionInSize()
    //     0x85935c: bl              #0x859390  ; [package:flutter/src/material/ink_splash.dart] ::_getSplashRadiusForPositionInSize
    // 0x859360: add             SP, SP, #0x10
    // 0x859364: LeaveFrame
    //     0x859364: mov             SP, fp
    //     0x859368: ldp             fp, lr, [SP], #0x10
    // 0x85936c: ret
    //     0x85936c: ret             
    // 0x859370: d0 = 35.000000
    //     0x859370: add             x17, PP, #0x2c, lsl #12  ; [pp+0x2c3a8] IMM: double(35) from 0x4041800000000000
    //     0x859374: ldr             d0, [x17, #0x3a8]
    // 0x859378: LeaveFrame
    //     0x859378: mov             SP, fp
    //     0x85937c: ldp             fp, lr, [SP], #0x10
    // 0x859380: ret
    //     0x859380: ret             
    // 0x859384: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x859384: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859388: b               #0x859304
    // 0x85938c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x85938c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ _getSplashRadiusForPositionInSize(/* No info */) {
    // ** addr: 0x859390, size: 0x228
    // 0x859390: EnterFrame
    //     0x859390: stp             fp, lr, [SP, #-0x10]!
    //     0x859394: mov             fp, SP
    // 0x859398: AllocStack(0x18)
    //     0x859398: sub             SP, SP, #0x18
    // 0x85939c: CheckStackOverflow
    //     0x85939c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8593a0: cmp             SP, x16
    //     0x8593a4: b.ls            #0x8595b0
    // 0x8593a8: ldr             x16, [fp, #0x10]
    // 0x8593ac: r30 = Instance_Offset
    //     0x8593ac: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x8593b0: stp             lr, x16, [SP, #-0x10]!
    // 0x8593b4: r0 = -()
    //     0x8593b4: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x8593b8: add             SP, SP, #0x10
    // 0x8593bc: LoadField: d0 = r0->field_7
    //     0x8593bc: ldur            d0, [x0, #7]
    // 0x8593c0: fmul            d1, d0, d0
    // 0x8593c4: LoadField: d0 = r0->field_f
    //     0x8593c4: ldur            d0, [x0, #0xf]
    // 0x8593c8: fmul            d2, d0, d0
    // 0x8593cc: fadd            d0, d1, d2
    // 0x8593d0: fsqrt           d1, d0
    // 0x8593d4: stur            d1, [fp, #-8]
    // 0x8593d8: ldr             x16, [fp, #0x18]
    // 0x8593dc: SaveReg r16
    //     0x8593dc: str             x16, [SP, #-8]!
    // 0x8593e0: r0 = topRight()
    //     0x8593e0: bl              #0x857218  ; [dart:ui] Size::topRight
    // 0x8593e4: add             SP, SP, #8
    // 0x8593e8: ldr             x16, [fp, #0x10]
    // 0x8593ec: stp             x0, x16, [SP, #-0x10]!
    // 0x8593f0: r0 = -()
    //     0x8593f0: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x8593f4: add             SP, SP, #0x10
    // 0x8593f8: LoadField: d0 = r0->field_7
    //     0x8593f8: ldur            d0, [x0, #7]
    // 0x8593fc: fmul            d1, d0, d0
    // 0x859400: LoadField: d0 = r0->field_f
    //     0x859400: ldur            d0, [x0, #0xf]
    // 0x859404: fmul            d2, d0, d0
    // 0x859408: fadd            d0, d1, d2
    // 0x85940c: fsqrt           d1, d0
    // 0x859410: stur            d1, [fp, #-0x10]
    // 0x859414: ldr             x16, [fp, #0x18]
    // 0x859418: SaveReg r16
    //     0x859418: str             x16, [SP, #-8]!
    // 0x85941c: r0 = bottomLeft()
    //     0x85941c: bl              #0x8571cc  ; [dart:ui] Size::bottomLeft
    // 0x859420: add             SP, SP, #8
    // 0x859424: ldr             x16, [fp, #0x10]
    // 0x859428: stp             x0, x16, [SP, #-0x10]!
    // 0x85942c: r0 = -()
    //     0x85942c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x859430: add             SP, SP, #0x10
    // 0x859434: LoadField: d0 = r0->field_7
    //     0x859434: ldur            d0, [x0, #7]
    // 0x859438: fmul            d1, d0, d0
    // 0x85943c: LoadField: d0 = r0->field_f
    //     0x85943c: ldur            d0, [x0, #0xf]
    // 0x859440: fmul            d2, d0, d0
    // 0x859444: fadd            d0, d1, d2
    // 0x859448: fsqrt           d1, d0
    // 0x85944c: stur            d1, [fp, #-0x18]
    // 0x859450: ldr             x16, [fp, #0x18]
    // 0x859454: SaveReg r16
    //     0x859454: str             x16, [SP, #-8]!
    // 0x859458: r0 = bottomRight()
    //     0x859458: bl              #0x857264  ; [dart:ui] Size::bottomRight
    // 0x85945c: add             SP, SP, #8
    // 0x859460: ldr             x16, [fp, #0x10]
    // 0x859464: stp             x0, x16, [SP, #-0x10]!
    // 0x859468: r0 = -()
    //     0x859468: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x85946c: add             SP, SP, #0x10
    // 0x859470: LoadField: d0 = r0->field_7
    //     0x859470: ldur            d0, [x0, #7]
    // 0x859474: fmul            d1, d0, d0
    // 0x859478: LoadField: d0 = r0->field_f
    //     0x859478: ldur            d0, [x0, #0xf]
    // 0x85947c: fmul            d2, d0, d0
    // 0x859480: fadd            d0, d1, d2
    // 0x859484: fsqrt           d1, d0
    // 0x859488: ldur            d2, [fp, #-8]
    // 0x85948c: ldur            d0, [fp, #-0x10]
    // 0x859490: fcmp            d2, d0
    // 0x859494: b.vs            #0x8594a4
    // 0x859498: b.le            #0x8594a4
    // 0x85949c: d3 = 0.000000
    //     0x85949c: eor             v3.16b, v3.16b, v3.16b
    // 0x8594a0: b               #0x8594e4
    // 0x8594a4: fcmp            d2, d0
    // 0x8594a8: b.vs            #0x8594bc
    // 0x8594ac: b.ge            #0x8594bc
    // 0x8594b0: mov             v2.16b, v0.16b
    // 0x8594b4: d3 = 0.000000
    //     0x8594b4: eor             v3.16b, v3.16b, v3.16b
    // 0x8594b8: b               #0x8594e4
    // 0x8594bc: d3 = 0.000000
    //     0x8594bc: eor             v3.16b, v3.16b, v3.16b
    // 0x8594c0: fcmp            d2, d3
    // 0x8594c4: b.vs            #0x8594d8
    // 0x8594c8: b.ne            #0x8594d8
    // 0x8594cc: fadd            d4, d2, d0
    // 0x8594d0: mov             v2.16b, v4.16b
    // 0x8594d4: b               #0x8594e4
    // 0x8594d8: fcmp            d0, d0
    // 0x8594dc: b.vc            #0x8594e4
    // 0x8594e0: mov             v2.16b, v0.16b
    // 0x8594e4: ldur            d0, [fp, #-0x18]
    // 0x8594e8: fcmp            d0, d1
    // 0x8594ec: b.vs            #0x8594f4
    // 0x8594f0: b.gt            #0x85952c
    // 0x8594f4: fcmp            d0, d1
    // 0x8594f8: b.vs            #0x859508
    // 0x8594fc: b.ge            #0x859508
    // 0x859500: mov             v0.16b, v1.16b
    // 0x859504: b               #0x85952c
    // 0x859508: fcmp            d0, d3
    // 0x85950c: b.vs            #0x859520
    // 0x859510: b.ne            #0x859520
    // 0x859514: fadd            d4, d0, d1
    // 0x859518: mov             v0.16b, v4.16b
    // 0x85951c: b               #0x85952c
    // 0x859520: fcmp            d1, d1
    // 0x859524: b.vc            #0x85952c
    // 0x859528: mov             v0.16b, v1.16b
    // 0x85952c: fcmp            d2, d0
    // 0x859530: b.vs            #0x859540
    // 0x859534: b.le            #0x859540
    // 0x859538: mov             v0.16b, v2.16b
    // 0x85953c: b               #0x859570
    // 0x859540: fcmp            d2, d0
    // 0x859544: b.vs            #0x85954c
    // 0x859548: b.lt            #0x859570
    // 0x85954c: fcmp            d2, d3
    // 0x859550: b.vs            #0x859564
    // 0x859554: b.ne            #0x859564
    // 0x859558: fadd            d1, d2, d0
    // 0x85955c: mov             v0.16b, v1.16b
    // 0x859560: b               #0x859570
    // 0x859564: fcmp            d0, d0
    // 0x859568: b.vs            #0x859570
    // 0x85956c: mov             v0.16b, v2.16b
    // 0x859570: stp             fp, lr, [SP, #-0x10]!
    // 0x859574: mov             fp, SP
    // 0x859578: CallRuntime_LibcCeil(double) -> double
    //     0x859578: and             SP, SP, #0xfffffffffffffff0
    //     0x85957c: mov             sp, SP
    //     0x859580: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x859584: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x859588: blr             x16
    //     0x85958c: mov             x16, #8
    //     0x859590: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x859594: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x859598: sub             sp, x16, #1, lsl #12
    //     0x85959c: mov             SP, fp
    //     0x8595a0: ldp             fp, lr, [SP], #0x10
    // 0x8595a4: LeaveFrame
    //     0x8595a4: mov             SP, fp
    //     0x8595a8: ldp             fp, lr, [SP], #0x10
    // 0x8595ac: ret
    //     0x8595ac: ret             
    // 0x8595b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8595b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8595b4: b               #0x8593a8
  }
}

// class id: 2191, size: 0x8, field offset: 0x8
//   const constructor, 
class _InkSplashFactory extends InteractiveInkFeatureFactory {
}

// class id: 2196, size: 0x48, field offset: 0x18
class InkSplash extends InteractiveInkFeature {

  late AnimationController _radiusController; // offset: 0x3c
  late Animation<int> _alpha; // offset: 0x40
  late Animation<double> _radius; // offset: 0x38

  _ InkSplash(/* No info */) {
    // ** addr: 0x858e18, size: 0x4d8
    // 0x858e18: EnterFrame
    //     0x858e18: stp             fp, lr, [SP, #-0x10]!
    //     0x858e1c: mov             fp, SP
    // 0x858e20: AllocStack(0x18)
    //     0x858e20: sub             SP, SP, #0x18
    // 0x858e24: r0 = Sentinel
    //     0x858e24: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x858e28: CheckStackOverflow
    //     0x858e28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x858e2c: cmp             SP, x16
    //     0x858e30: b.ls            #0x8592d0
    // 0x858e34: ldr             x1, [fp, #0x68]
    // 0x858e38: StoreField: r1->field_37 = r0
    //     0x858e38: stur            w0, [x1, #0x37]
    // 0x858e3c: StoreField: r1->field_3b = r0
    //     0x858e3c: stur            w0, [x1, #0x3b]
    // 0x858e40: StoreField: r1->field_3f = r0
    //     0x858e40: stur            w0, [x1, #0x3f]
    // 0x858e44: ldr             x0, [fp, #0x30]
    // 0x858e48: StoreField: r1->field_17 = r0
    //     0x858e48: stur            w0, [x1, #0x17]
    //     0x858e4c: ldurb           w16, [x1, #-1]
    //     0x858e50: ldurb           w17, [x0, #-1]
    //     0x858e54: and             x16, x17, x16, lsr #2
    //     0x858e58: tst             x16, HEAP, lsr #32
    //     0x858e5c: b.eq            #0x858e64
    //     0x858e60: bl              #0xd6826c
    // 0x858e64: ldr             x0, [fp, #0x60]
    // 0x858e68: cmp             w0, NULL
    // 0x858e6c: b.ne            #0x858e78
    // 0x858e70: r0 = Instance_BorderRadius
    //     0x858e70: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x858e74: ldr             x0, [x0, #0x2c0]
    // 0x858e78: ldr             x2, [fp, #0x28]
    // 0x858e7c: StoreField: r1->field_1b = r0
    //     0x858e7c: stur            w0, [x1, #0x1b]
    //     0x858e80: ldurb           w16, [x1, #-1]
    //     0x858e84: ldurb           w17, [x0, #-1]
    //     0x858e88: and             x16, x17, x16, lsr #2
    //     0x858e8c: tst             x16, HEAP, lsr #32
    //     0x858e90: b.eq            #0x858e98
    //     0x858e94: bl              #0xd6826c
    // 0x858e98: ldr             x0, [fp, #0x40]
    // 0x858e9c: StoreField: r1->field_1f = r0
    //     0x858e9c: stur            w0, [x1, #0x1f]
    //     0x858ea0: ldurb           w16, [x1, #-1]
    //     0x858ea4: ldurb           w17, [x0, #-1]
    //     0x858ea8: and             x16, x17, x16, lsr #2
    //     0x858eac: tst             x16, HEAP, lsr #32
    //     0x858eb0: b.eq            #0x858eb8
    //     0x858eb4: bl              #0xd6826c
    // 0x858eb8: cmp             w2, NULL
    // 0x858ebc: b.ne            #0x858ee4
    // 0x858ec0: ldr             x16, [fp, #0x18]
    // 0x858ec4: ldr             lr, [fp, #0x50]
    // 0x858ec8: stp             lr, x16, [SP, #-0x10]!
    // 0x858ecc: ldr             x16, [fp, #0x20]
    // 0x858ed0: ldr             lr, [fp, #0x30]
    // 0x858ed4: stp             lr, x16, [SP, #-0x10]!
    // 0x858ed8: r0 = _getTargetRadius()
    //     0x858ed8: bl              #0x8592f0  ; [package:flutter/src/material/ink_splash.dart] ::_getTargetRadius
    // 0x858edc: add             SP, SP, #0x20
    // 0x858ee0: b               #0x858ee8
    // 0x858ee4: LoadField: d0 = r2->field_7
    //     0x858ee4: ldur            d0, [x2, #7]
    // 0x858ee8: ldr             x0, [fp, #0x68]
    // 0x858eec: ldr             x2, [fp, #0x20]
    // 0x858ef0: ldr             x1, [fp, #0x18]
    // 0x858ef4: stur            d0, [fp, #-0x18]
    // 0x858ef8: StoreField: r0->field_23 = d0
    //     0x858ef8: stur            d0, [x0, #0x23]
    // 0x858efc: r1 = 1
    //     0x858efc: mov             x1, #1
    // 0x858f00: r0 = AllocateContext()
    //     0x858f00: bl              #0xd68aa4  ; AllocateContextStub
    // 0x858f04: mov             x1, x0
    // 0x858f08: ldr             x0, [fp, #0x18]
    // 0x858f0c: StoreField: r1->field_f = r0
    //     0x858f0c: stur            w0, [x1, #0xf]
    // 0x858f10: ldr             x2, [fp, #0x20]
    // 0x858f14: cmp             w2, NULL
    // 0x858f18: b.eq            #0x858f24
    // 0x858f1c: mov             x0, x2
    // 0x858f20: b               #0x858f44
    // 0x858f24: ldr             x3, [fp, #0x50]
    // 0x858f28: tbnz            w3, #4, #0x858f40
    // 0x858f2c: mov             x2, x1
    // 0x858f30: r1 = Function '<anonymous closure>': static.
    //     0x858f30: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e448] AnonymousClosure: static (0x8573a4), of [package:flutter/src/material/ink_ripple.dart] 
    //     0x858f34: ldr             x1, [x1, #0x448]
    // 0x858f38: r0 = AllocateClosure()
    //     0x858f38: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x858f3c: b               #0x858f44
    // 0x858f40: r0 = Null
    //     0x858f40: mov             x0, NULL
    // 0x858f44: ldr             x2, [fp, #0x68]
    // 0x858f48: ldr             x4, [fp, #0x58]
    // 0x858f4c: ldr             x1, [fp, #0x50]
    // 0x858f50: ldr             x3, [fp, #0x48]
    // 0x858f54: ldur            d0, [fp, #-0x18]
    // 0x858f58: StoreField: r2->field_2b = r0
    //     0x858f58: stur            w0, [x2, #0x2b]
    //     0x858f5c: tbz             w0, #0, #0x858f78
    //     0x858f60: ldurb           w16, [x2, #-1]
    //     0x858f64: ldurb           w17, [x0, #-1]
    //     0x858f68: and             x16, x17, x16, lsr #2
    //     0x858f6c: tst             x16, HEAP, lsr #32
    //     0x858f70: b.eq            #0x858f78
    //     0x858f74: bl              #0xd6828c
    // 0x858f78: eor             x0, x1, #0x10
    // 0x858f7c: StoreField: r2->field_2f = r0
    //     0x858f7c: stur            w0, [x2, #0x2f]
    // 0x858f80: ldr             x0, [fp, #0x10]
    // 0x858f84: StoreField: r2->field_33 = r0
    //     0x858f84: stur            w0, [x2, #0x33]
    //     0x858f88: ldurb           w16, [x2, #-1]
    //     0x858f8c: ldurb           w17, [x0, #-1]
    //     0x858f90: and             x16, x17, x16, lsr #2
    //     0x858f94: tst             x16, HEAP, lsr #32
    //     0x858f98: b.eq            #0x858fa0
    //     0x858f9c: bl              #0xd6828c
    // 0x858fa0: mov             x0, x4
    // 0x858fa4: StoreField: r2->field_13 = r0
    //     0x858fa4: stur            w0, [x2, #0x13]
    //     0x858fa8: ldurb           w16, [x2, #-1]
    //     0x858fac: ldurb           w17, [x0, #-1]
    //     0x858fb0: and             x16, x17, x16, lsr #2
    //     0x858fb4: tst             x16, HEAP, lsr #32
    //     0x858fb8: b.eq            #0x858fc0
    //     0x858fbc: bl              #0xd6828c
    // 0x858fc0: ldr             x0, [fp, #0x18]
    // 0x858fc4: StoreField: r2->field_b = r0
    //     0x858fc4: stur            w0, [x2, #0xb]
    //     0x858fc8: ldurb           w16, [x2, #-1]
    //     0x858fcc: ldurb           w17, [x0, #-1]
    //     0x858fd0: and             x16, x17, x16, lsr #2
    //     0x858fd4: tst             x16, HEAP, lsr #32
    //     0x858fd8: b.eq            #0x858fe0
    //     0x858fdc: bl              #0xd6828c
    // 0x858fe0: ldr             x0, [fp, #0x38]
    // 0x858fe4: StoreField: r2->field_f = r0
    //     0x858fe4: stur            w0, [x2, #0xf]
    //     0x858fe8: ldurb           w16, [x2, #-1]
    //     0x858fec: ldurb           w17, [x0, #-1]
    //     0x858ff0: and             x16, x17, x16, lsr #2
    //     0x858ff4: tst             x16, HEAP, lsr #32
    //     0x858ff8: b.eq            #0x859000
    //     0x858ffc: bl              #0xd6828c
    // 0x859000: mov             x0, x3
    // 0x859004: StoreField: r2->field_7 = r0
    //     0x859004: stur            w0, [x2, #7]
    //     0x859008: ldurb           w16, [x2, #-1]
    //     0x85900c: ldurb           w17, [x0, #-1]
    //     0x859010: and             x16, x17, x16, lsr #2
    //     0x859014: tst             x16, HEAP, lsr #32
    //     0x859018: b.eq            #0x859020
    //     0x85901c: bl              #0xd6828c
    // 0x859020: LoadField: r0 = r3->field_63
    //     0x859020: ldur            w0, [x3, #0x63]
    // 0x859024: DecompressPointer r0
    //     0x859024: add             x0, x0, HEAP, lsl #32
    // 0x859028: stur            x0, [fp, #-8]
    // 0x85902c: r1 = <double>
    //     0x85902c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x859030: r0 = AnimationController()
    //     0x859030: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x859034: stur            x0, [fp, #-0x10]
    // 0x859038: ldur            x16, [fp, #-8]
    // 0x85903c: stp             x16, x0, [SP, #-0x10]!
    // 0x859040: r16 = Instance_Duration
    //     0x859040: ldr             x16, [PP, #0x1788]  ; [pp+0x1788] Obj!Duration@b67a21
    // 0x859044: SaveReg r16
    //     0x859044: str             x16, [SP, #-8]!
    // 0x859048: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x859048: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x85904c: ldr             x4, [x4, #0xa0]
    // 0x859050: r0 = AnimationController()
    //     0x859050: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x859054: add             SP, SP, #0x18
    // 0x859058: r1 = 1
    //     0x859058: mov             x1, #1
    // 0x85905c: r0 = AllocateContext()
    //     0x85905c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x859060: mov             x1, x0
    // 0x859064: ldr             x0, [fp, #0x48]
    // 0x859068: StoreField: r1->field_f = r0
    //     0x859068: stur            w0, [x1, #0xf]
    // 0x85906c: mov             x2, x1
    // 0x859070: r1 = Function 'markNeedsPaint':.
    //     0x859070: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x859074: ldr             x1, [x1, #0xf60]
    // 0x859078: r0 = AllocateClosure()
    //     0x859078: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x85907c: ldur            x16, [fp, #-0x10]
    // 0x859080: stp             x0, x16, [SP, #-0x10]!
    // 0x859084: r0 = addActionListener()
    //     0x859084: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x859088: add             SP, SP, #0x10
    // 0x85908c: ldur            x16, [fp, #-0x10]
    // 0x859090: SaveReg r16
    //     0x859090: str             x16, [SP, #-8]!
    // 0x859094: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x859094: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x859098: r0 = forward()
    //     0x859098: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x85909c: add             SP, SP, #8
    // 0x8590a0: ldur            x0, [fp, #-0x10]
    // 0x8590a4: ldr             x2, [fp, #0x68]
    // 0x8590a8: StoreField: r2->field_3b = r0
    //     0x8590a8: stur            w0, [x2, #0x3b]
    //     0x8590ac: ldurb           w16, [x2, #-1]
    //     0x8590b0: ldurb           w17, [x0, #-1]
    //     0x8590b4: and             x16, x17, x16, lsr #2
    //     0x8590b8: tst             x16, HEAP, lsr #32
    //     0x8590bc: b.eq            #0x8590c4
    //     0x8590c0: bl              #0xd6828c
    // 0x8590c4: r1 = <double>
    //     0x8590c4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8590c8: r0 = Tween()
    //     0x8590c8: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x8590cc: mov             x1, x0
    // 0x8590d0: r0 = 0.000000
    //     0x8590d0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x8590d4: StoreField: r1->field_b = r0
    //     0x8590d4: stur            w0, [x1, #0xb]
    // 0x8590d8: ldur            d0, [fp, #-0x18]
    // 0x8590dc: r0 = inline_Allocate_Double()
    //     0x8590dc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x8590e0: add             x0, x0, #0x10
    //     0x8590e4: cmp             x2, x0
    //     0x8590e8: b.ls            #0x8592d8
    //     0x8590ec: str             x0, [THR, #0x60]  ; THR::top
    //     0x8590f0: sub             x0, x0, #0xf
    //     0x8590f4: mov             x2, #0xd108
    //     0x8590f8: movk            x2, #3, lsl #16
    //     0x8590fc: stur            x2, [x0, #-1]
    // 0x859100: StoreField: r0->field_7 = d0
    //     0x859100: stur            d0, [x0, #7]
    // 0x859104: StoreField: r1->field_f = r0
    //     0x859104: stur            w0, [x1, #0xf]
    // 0x859108: ldur            x16, [fp, #-0x10]
    // 0x85910c: stp             x16, x1, [SP, #-0x10]!
    // 0x859110: r0 = animate()
    //     0x859110: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x859114: add             SP, SP, #0x10
    // 0x859118: ldr             x2, [fp, #0x68]
    // 0x85911c: StoreField: r2->field_37 = r0
    //     0x85911c: stur            w0, [x2, #0x37]
    //     0x859120: ldurb           w16, [x2, #-1]
    //     0x859124: ldurb           w17, [x0, #-1]
    //     0x859128: and             x16, x17, x16, lsr #2
    //     0x85912c: tst             x16, HEAP, lsr #32
    //     0x859130: b.eq            #0x859138
    //     0x859134: bl              #0xd6828c
    // 0x859138: r1 = <double>
    //     0x859138: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x85913c: r0 = AnimationController()
    //     0x85913c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x859140: stur            x0, [fp, #-0x10]
    // 0x859144: ldur            x16, [fp, #-8]
    // 0x859148: stp             x16, x0, [SP, #-0x10]!
    // 0x85914c: r16 = Instance_Duration
    //     0x85914c: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x859150: ldr             x16, [x16, #0x9e0]
    // 0x859154: SaveReg r16
    //     0x859154: str             x16, [SP, #-8]!
    // 0x859158: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x859158: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x85915c: ldr             x4, [x4, #0xa0]
    // 0x859160: r0 = AnimationController()
    //     0x859160: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x859164: add             SP, SP, #0x18
    // 0x859168: r1 = 1
    //     0x859168: mov             x1, #1
    // 0x85916c: r0 = AllocateContext()
    //     0x85916c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x859170: mov             x1, x0
    // 0x859174: ldr             x0, [fp, #0x48]
    // 0x859178: StoreField: r1->field_f = r0
    //     0x859178: stur            w0, [x1, #0xf]
    // 0x85917c: mov             x2, x1
    // 0x859180: r1 = Function 'markNeedsPaint':.
    //     0x859180: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x859184: ldr             x1, [x1, #0xf60]
    // 0x859188: r0 = AllocateClosure()
    //     0x859188: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x85918c: ldur            x16, [fp, #-0x10]
    // 0x859190: stp             x0, x16, [SP, #-0x10]!
    // 0x859194: r0 = addActionListener()
    //     0x859194: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x859198: add             SP, SP, #0x10
    // 0x85919c: r1 = 1
    //     0x85919c: mov             x1, #1
    // 0x8591a0: r0 = AllocateContext()
    //     0x8591a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8591a4: mov             x1, x0
    // 0x8591a8: ldr             x0, [fp, #0x68]
    // 0x8591ac: StoreField: r1->field_f = r0
    //     0x8591ac: stur            w0, [x1, #0xf]
    // 0x8591b0: mov             x2, x1
    // 0x8591b4: r1 = Function '_handleAlphaStatusChanged@759036029':.
    //     0x8591b4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e450] AnonymousClosure: (0x8595b8), in [package:flutter/src/material/ink_splash.dart] InkSplash::_handleAlphaStatusChanged (0x859604)
    //     0x8591b8: ldr             x1, [x1, #0x450]
    // 0x8591bc: r0 = AllocateClosure()
    //     0x8591bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8591c0: ldur            x16, [fp, #-0x10]
    // 0x8591c4: stp             x0, x16, [SP, #-0x10]!
    // 0x8591c8: r0 = addStatusListener()
    //     0x8591c8: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x8591cc: add             SP, SP, #0x10
    // 0x8591d0: ldur            x0, [fp, #-0x10]
    // 0x8591d4: ldr             x2, [fp, #0x68]
    // 0x8591d8: StoreField: r2->field_43 = r0
    //     0x8591d8: stur            w0, [x2, #0x43]
    //     0x8591dc: ldurb           w16, [x2, #-1]
    //     0x8591e0: ldurb           w17, [x0, #-1]
    //     0x8591e4: and             x16, x17, x16, lsr #2
    //     0x8591e8: tst             x16, HEAP, lsr #32
    //     0x8591ec: b.eq            #0x8591f4
    //     0x8591f0: bl              #0xd6828c
    // 0x8591f4: ldr             x0, [fp, #0x58]
    // 0x8591f8: r1 = LoadClassIdInstr(r0)
    //     0x8591f8: ldur            x1, [x0, #-1]
    //     0x8591fc: ubfx            x1, x1, #0xc, #0x14
    // 0x859200: lsl             x1, x1, #1
    // 0x859204: r17 = 10124
    //     0x859204: mov             x17, #0x278c
    // 0x859208: cmp             w1, w17
    // 0x85920c: b.gt            #0x85921c
    // 0x859210: r17 = 10122
    //     0x859210: mov             x17, #0x278a
    // 0x859214: cmp             w1, w17
    // 0x859218: b.ge            #0x859234
    // 0x85921c: r17 = 10114
    //     0x85921c: mov             x17, #0x2782
    // 0x859220: cmp             w1, w17
    // 0x859224: b.eq            #0x859234
    // 0x859228: r17 = 10118
    //     0x859228: mov             x17, #0x2786
    // 0x85922c: cmp             w1, w17
    // 0x859230: b.ne            #0x85923c
    // 0x859234: LoadField: r1 = r0->field_7
    //     0x859234: ldur            x1, [x0, #7]
    // 0x859238: b               #0x85924c
    // 0x85923c: LoadField: r1 = r0->field_f
    //     0x85923c: ldur            w1, [x0, #0xf]
    // 0x859240: DecompressPointer r1
    //     0x859240: add             x1, x1, HEAP, lsl #32
    // 0x859244: LoadField: r0 = r1->field_7
    //     0x859244: ldur            x0, [x1, #7]
    // 0x859248: mov             x1, x0
    // 0x85924c: r0 = 4278190080
    //     0x85924c: mov             x0, #0xff000000
    // 0x859250: ubfx            x1, x1, #0, #0x20
    // 0x859254: and             x3, x1, x0
    // 0x859258: ubfx            x3, x3, #0, #0x20
    // 0x85925c: asr             x0, x3, #0x18
    // 0x859260: lsl             x3, x0, #1
    // 0x859264: stur            x3, [fp, #-8]
    // 0x859268: r1 = <int>
    //     0x859268: ldr             x1, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    // 0x85926c: r0 = IntTween()
    //     0x85926c: bl              #0x7b2798  ; AllocateIntTweenStub -> IntTween (size=0x14)
    // 0x859270: mov             x1, x0
    // 0x859274: ldur            x0, [fp, #-8]
    // 0x859278: StoreField: r1->field_b = r0
    //     0x859278: stur            w0, [x1, #0xb]
    // 0x85927c: StoreField: r1->field_f = rZR
    //     0x85927c: stur            wzr, [x1, #0xf]
    // 0x859280: ldur            x16, [fp, #-0x10]
    // 0x859284: stp             x16, x1, [SP, #-0x10]!
    // 0x859288: r0 = animate()
    //     0x859288: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x85928c: add             SP, SP, #0x10
    // 0x859290: ldr             x1, [fp, #0x68]
    // 0x859294: StoreField: r1->field_3f = r0
    //     0x859294: stur            w0, [x1, #0x3f]
    //     0x859298: ldurb           w16, [x1, #-1]
    //     0x85929c: ldurb           w17, [x0, #-1]
    //     0x8592a0: and             x16, x17, x16, lsr #2
    //     0x8592a4: tst             x16, HEAP, lsr #32
    //     0x8592a8: b.eq            #0x8592b0
    //     0x8592ac: bl              #0xd6826c
    // 0x8592b0: ldr             x16, [fp, #0x48]
    // 0x8592b4: stp             x1, x16, [SP, #-0x10]!
    // 0x8592b8: r0 = addInkFeature()
    //     0x8592b8: bl              #0x7b266c  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0x8592bc: add             SP, SP, #0x10
    // 0x8592c0: r0 = Null
    //     0x8592c0: mov             x0, NULL
    // 0x8592c4: LeaveFrame
    //     0x8592c4: mov             SP, fp
    //     0x8592c8: ldp             fp, lr, [SP], #0x10
    // 0x8592cc: ret
    //     0x8592cc: ret             
    // 0x8592d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8592d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8592d4: b               #0x858e34
    // 0x8592d8: SaveReg d0
    //     0x8592d8: str             q0, [SP, #-0x10]!
    // 0x8592dc: SaveReg r1
    //     0x8592dc: str             x1, [SP, #-8]!
    // 0x8592e0: r0 = AllocateDouble()
    //     0x8592e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8592e4: RestoreReg r1
    //     0x8592e4: ldr             x1, [SP], #8
    // 0x8592e8: RestoreReg d0
    //     0x8592e8: ldr             q0, [SP], #0x10
    // 0x8592ec: b               #0x859100
  }
  [closure] void _handleAlphaStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0x8595b8, size: 0x4c
    // 0x8595b8: EnterFrame
    //     0x8595b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8595bc: mov             fp, SP
    // 0x8595c0: ldr             x0, [fp, #0x18]
    // 0x8595c4: LoadField: r1 = r0->field_17
    //     0x8595c4: ldur            w1, [x0, #0x17]
    // 0x8595c8: DecompressPointer r1
    //     0x8595c8: add             x1, x1, HEAP, lsl #32
    // 0x8595cc: CheckStackOverflow
    //     0x8595cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8595d0: cmp             SP, x16
    //     0x8595d4: b.ls            #0x8595fc
    // 0x8595d8: LoadField: r0 = r1->field_f
    //     0x8595d8: ldur            w0, [x1, #0xf]
    // 0x8595dc: DecompressPointer r0
    //     0x8595dc: add             x0, x0, HEAP, lsl #32
    // 0x8595e0: ldr             x16, [fp, #0x10]
    // 0x8595e4: stp             x16, x0, [SP, #-0x10]!
    // 0x8595e8: r0 = _handleAlphaStatusChanged()
    //     0x8595e8: bl              #0x859604  ; [package:flutter/src/material/ink_splash.dart] InkSplash::_handleAlphaStatusChanged
    // 0x8595ec: add             SP, SP, #0x10
    // 0x8595f0: LeaveFrame
    //     0x8595f0: mov             SP, fp
    //     0x8595f4: ldp             fp, lr, [SP], #0x10
    // 0x8595f8: ret
    //     0x8595f8: ret             
    // 0x8595fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8595fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859600: b               #0x8595d8
  }
  _ _handleAlphaStatusChanged(/* No info */) {
    // ** addr: 0x859604, size: 0x50
    // 0x859604: EnterFrame
    //     0x859604: stp             fp, lr, [SP, #-0x10]!
    //     0x859608: mov             fp, SP
    // 0x85960c: CheckStackOverflow
    //     0x85960c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x859610: cmp             SP, x16
    //     0x859614: b.ls            #0x85964c
    // 0x859618: ldr             x0, [fp, #0x10]
    // 0x85961c: r16 = Instance_AnimationStatus
    //     0x85961c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x859620: ldr             x16, [x16, #0xba0]
    // 0x859624: cmp             w0, w16
    // 0x859628: b.ne            #0x85963c
    // 0x85962c: ldr             x16, [fp, #0x18]
    // 0x859630: SaveReg r16
    //     0x859630: str             x16, [SP, #-8]!
    // 0x859634: r0 = dispose()
    //     0x859634: bl              #0xbfee5c  ; [package:flutter/src/material/ink_splash.dart] InkSplash::dispose
    // 0x859638: add             SP, SP, #8
    // 0x85963c: r0 = Null
    //     0x85963c: mov             x0, NULL
    // 0x859640: LeaveFrame
    //     0x859640: mov             SP, fp
    //     0x859644: ldp             fp, lr, [SP], #0x10
    // 0x859648: ret
    //     0x859648: ret             
    // 0x85964c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85964c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x859650: b               #0x859618
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0xbe6164, size: 0x244
    // 0xbe6164: EnterFrame
    //     0xbe6164: stp             fp, lr, [SP, #-0x10]!
    //     0xbe6168: mov             fp, SP
    // 0xbe616c: AllocStack(0x18)
    //     0xbe616c: sub             SP, SP, #0x18
    // 0xbe6170: CheckStackOverflow
    //     0xbe6170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe6174: cmp             SP, x16
    //     0xbe6178: b.ls            #0xbe6368
    // 0xbe617c: r16 = 112
    //     0xbe617c: mov             x16, #0x70
    // 0xbe6180: stp             x16, NULL, [SP, #-0x10]!
    // 0xbe6184: r0 = ByteData()
    //     0xbe6184: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbe6188: add             SP, SP, #0x10
    // 0xbe618c: stur            x0, [fp, #-8]
    // 0xbe6190: r0 = Paint()
    //     0xbe6190: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbe6194: mov             x1, x0
    // 0xbe6198: ldur            x0, [fp, #-8]
    // 0xbe619c: stur            x1, [fp, #-0x18]
    // 0xbe61a0: StoreField: r1->field_7 = r0
    //     0xbe61a0: stur            w0, [x1, #7]
    // 0xbe61a4: ldr             x2, [fp, #0x20]
    // 0xbe61a8: LoadField: r3 = r2->field_13
    //     0xbe61a8: ldur            w3, [x2, #0x13]
    // 0xbe61ac: DecompressPointer r3
    //     0xbe61ac: add             x3, x3, HEAP, lsl #32
    // 0xbe61b0: stur            x3, [fp, #-0x10]
    // 0xbe61b4: LoadField: r4 = r2->field_3f
    //     0xbe61b4: ldur            w4, [x2, #0x3f]
    // 0xbe61b8: DecompressPointer r4
    //     0xbe61b8: add             x4, x4, HEAP, lsl #32
    // 0xbe61bc: r16 = Sentinel
    //     0xbe61bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe61c0: cmp             w4, w16
    // 0xbe61c4: b.eq            #0xbe6370
    // 0xbe61c8: LoadField: r5 = r4->field_f
    //     0xbe61c8: ldur            w5, [x4, #0xf]
    // 0xbe61cc: DecompressPointer r5
    //     0xbe61cc: add             x5, x5, HEAP, lsl #32
    // 0xbe61d0: LoadField: r6 = r4->field_b
    //     0xbe61d0: ldur            w6, [x4, #0xb]
    // 0xbe61d4: DecompressPointer r6
    //     0xbe61d4: add             x6, x6, HEAP, lsl #32
    // 0xbe61d8: stp             x6, x5, [SP, #-0x10]!
    // 0xbe61dc: r0 = evaluate()
    //     0xbe61dc: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe61e0: add             SP, SP, #0x10
    // 0xbe61e4: r1 = LoadInt32Instr(r0)
    //     0xbe61e4: sbfx            x1, x0, #1, #0x1f
    //     0xbe61e8: tbz             w0, #0, #0xbe61f0
    //     0xbe61ec: ldur            x1, [x0, #7]
    // 0xbe61f0: ldur            x16, [fp, #-0x10]
    // 0xbe61f4: stp             x1, x16, [SP, #-0x10]!
    // 0xbe61f8: r0 = withAlpha()
    //     0xbe61f8: bl              #0x5954c8  ; [dart:ui] Color::withAlpha
    // 0xbe61fc: add             SP, SP, #0x10
    // 0xbe6200: LoadField: r1 = r0->field_7
    //     0xbe6200: ldur            x1, [x0, #7]
    // 0xbe6204: eor             x0, x1, #0xff000000
    // 0xbe6208: ldur            x1, [fp, #-8]
    // 0xbe620c: LoadField: r2 = r1->field_17
    //     0xbe620c: ldur            w2, [x1, #0x17]
    // 0xbe6210: DecompressPointer r2
    //     0xbe6210: add             x2, x2, HEAP, lsl #32
    // 0xbe6214: sxtw            x0, w0
    // 0xbe6218: LoadField: r1 = r2->field_7
    //     0xbe6218: ldur            x1, [x2, #7]
    // 0xbe621c: str             w0, [x1, #4]
    // 0xbe6220: ldr             x0, [fp, #0x20]
    // 0xbe6224: LoadField: r1 = r0->field_17
    //     0xbe6224: ldur            w1, [x0, #0x17]
    // 0xbe6228: DecompressPointer r1
    //     0xbe6228: add             x1, x1, HEAP, lsl #32
    // 0xbe622c: stur            x1, [fp, #-8]
    // 0xbe6230: LoadField: r2 = r0->field_2f
    //     0xbe6230: ldur            w2, [x0, #0x2f]
    // 0xbe6234: DecompressPointer r2
    //     0xbe6234: add             x2, x2, HEAP, lsl #32
    // 0xbe6238: tbnz            w2, #4, #0xbe62b0
    // 0xbe623c: LoadField: r2 = r0->field_b
    //     0xbe623c: ldur            w2, [x0, #0xb]
    // 0xbe6240: DecompressPointer r2
    //     0xbe6240: add             x2, x2, HEAP, lsl #32
    // 0xbe6244: LoadField: r3 = r2->field_57
    //     0xbe6244: ldur            w3, [x2, #0x57]
    // 0xbe6248: DecompressPointer r3
    //     0xbe6248: add             x3, x3, HEAP, lsl #32
    // 0xbe624c: cmp             w3, NULL
    // 0xbe6250: b.eq            #0xbe637c
    // 0xbe6254: SaveReg r3
    //     0xbe6254: str             x3, [SP, #-8]!
    // 0xbe6258: r0 = center()
    //     0xbe6258: bl              #0x64082c  ; [dart:ui] Size::center
    // 0xbe625c: add             SP, SP, #8
    // 0xbe6260: mov             x1, x0
    // 0xbe6264: ldr             x0, [fp, #0x20]
    // 0xbe6268: LoadField: r2 = r0->field_3b
    //     0xbe6268: ldur            w2, [x0, #0x3b]
    // 0xbe626c: DecompressPointer r2
    //     0xbe626c: add             x2, x2, HEAP, lsl #32
    // 0xbe6270: r16 = Sentinel
    //     0xbe6270: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe6274: cmp             w2, w16
    // 0xbe6278: b.eq            #0xbe6380
    // 0xbe627c: LoadField: r3 = r2->field_37
    //     0xbe627c: ldur            w3, [x2, #0x37]
    // 0xbe6280: DecompressPointer r3
    //     0xbe6280: add             x3, x3, HEAP, lsl #32
    // 0xbe6284: r16 = Sentinel
    //     0xbe6284: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe6288: cmp             w3, w16
    // 0xbe628c: b.eq            #0xbe638c
    // 0xbe6290: LoadField: d0 = r3->field_7
    //     0xbe6290: ldur            d0, [x3, #7]
    // 0xbe6294: ldur            x16, [fp, #-8]
    // 0xbe6298: stp             x1, x16, [SP, #-0x10]!
    // 0xbe629c: SaveReg d0
    //     0xbe629c: str             d0, [SP, #-8]!
    // 0xbe62a0: r0 = lerp()
    //     0xbe62a0: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xbe62a4: add             SP, SP, #0x18
    // 0xbe62a8: mov             x1, x0
    // 0xbe62ac: b               #0xbe62b4
    // 0xbe62b0: ldur            x1, [fp, #-8]
    // 0xbe62b4: ldr             x0, [fp, #0x20]
    // 0xbe62b8: stur            x1, [fp, #-0x10]
    // 0xbe62bc: cmp             w1, NULL
    // 0xbe62c0: b.eq            #0xbe6398
    // 0xbe62c4: LoadField: r2 = r0->field_33
    //     0xbe62c4: ldur            w2, [x0, #0x33]
    // 0xbe62c8: DecompressPointer r2
    //     0xbe62c8: add             x2, x2, HEAP, lsl #32
    // 0xbe62cc: stur            x2, [fp, #-8]
    // 0xbe62d0: LoadField: r3 = r0->field_37
    //     0xbe62d0: ldur            w3, [x0, #0x37]
    // 0xbe62d4: DecompressPointer r3
    //     0xbe62d4: add             x3, x3, HEAP, lsl #32
    // 0xbe62d8: r16 = Sentinel
    //     0xbe62d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe62dc: cmp             w3, w16
    // 0xbe62e0: b.eq            #0xbe639c
    // 0xbe62e4: LoadField: r4 = r3->field_f
    //     0xbe62e4: ldur            w4, [x3, #0xf]
    // 0xbe62e8: DecompressPointer r4
    //     0xbe62e8: add             x4, x4, HEAP, lsl #32
    // 0xbe62ec: LoadField: r5 = r3->field_b
    //     0xbe62ec: ldur            w5, [x3, #0xb]
    // 0xbe62f0: DecompressPointer r5
    //     0xbe62f0: add             x5, x5, HEAP, lsl #32
    // 0xbe62f4: stp             x5, x4, [SP, #-0x10]!
    // 0xbe62f8: r0 = evaluate()
    //     0xbe62f8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe62fc: add             SP, SP, #0x10
    // 0xbe6300: mov             x1, x0
    // 0xbe6304: ldr             x0, [fp, #0x20]
    // 0xbe6308: LoadField: r2 = r0->field_1f
    //     0xbe6308: ldur            w2, [x0, #0x1f]
    // 0xbe630c: DecompressPointer r2
    //     0xbe630c: add             x2, x2, HEAP, lsl #32
    // 0xbe6310: LoadField: r3 = r0->field_1b
    //     0xbe6310: ldur            w3, [x0, #0x1b]
    // 0xbe6314: DecompressPointer r3
    //     0xbe6314: add             x3, x3, HEAP, lsl #32
    // 0xbe6318: LoadField: r4 = r0->field_2b
    //     0xbe6318: ldur            w4, [x0, #0x2b]
    // 0xbe631c: DecompressPointer r4
    //     0xbe631c: add             x4, x4, HEAP, lsl #32
    // 0xbe6320: LoadField: d0 = r1->field_7
    //     0xbe6320: ldur            d0, [x1, #7]
    // 0xbe6324: stp             x3, x0, [SP, #-0x10]!
    // 0xbe6328: ldr             x16, [fp, #0x18]
    // 0xbe632c: ldur            lr, [fp, #-0x10]
    // 0xbe6330: stp             lr, x16, [SP, #-0x10]!
    // 0xbe6334: stp             x2, x4, [SP, #-0x10]!
    // 0xbe6338: ldur            x16, [fp, #-0x18]
    // 0xbe633c: SaveReg r16
    //     0xbe633c: str             x16, [SP, #-8]!
    // 0xbe6340: SaveReg d0
    //     0xbe6340: str             d0, [SP, #-8]!
    // 0xbe6344: ldur            x16, [fp, #-8]
    // 0xbe6348: ldr             lr, [fp, #0x10]
    // 0xbe634c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe6350: r0 = paintInkCircle()
    //     0xbe6350: bl              #0xbe4ad0  ; [package:flutter/src/material/ink_well.dart] InteractiveInkFeature::paintInkCircle
    // 0xbe6354: add             SP, SP, #0x50
    // 0xbe6358: r0 = Null
    //     0xbe6358: mov             x0, NULL
    // 0xbe635c: LeaveFrame
    //     0xbe635c: mov             SP, fp
    //     0xbe6360: ldp             fp, lr, [SP], #0x10
    // 0xbe6364: ret
    //     0xbe6364: ret             
    // 0xbe6368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe6368: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe636c: b               #0xbe617c
    // 0xbe6370: r9 = _alpha
    //     0xbe6370: add             x9, PP, #0x37, lsl #12  ; [pp+0x37818] Field <InkSplash._alpha@759036029>: late (offset: 0x40)
    //     0xbe6374: ldr             x9, [x9, #0x818]
    // 0xbe6378: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe6378: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe637c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe637c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe6380: r9 = _radiusController
    //     0xbe6380: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e0] Field <InkSplash._radiusController@759036029>: late (offset: 0x3c)
    //     0xbe6384: ldr             x9, [x9, #0x2e0]
    // 0xbe6388: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe6388: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe638c: r9 = _value
    //     0xbe638c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xbe6390: ldr             x9, [x9, #0xbb0]
    // 0xbe6394: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe6394: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe6398: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe6398: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe639c: r9 = _radius
    //     0xbe639c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37820] Field <InkSplash._radius@759036029>: late (offset: 0x38)
    //     0xbe63a0: ldr             x9, [x9, #0x820]
    // 0xbe63a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe63a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbfee5c, size: 0x94
    // 0xbfee5c: EnterFrame
    //     0xbfee5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfee60: mov             fp, SP
    // 0xbfee64: CheckStackOverflow
    //     0xbfee64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfee68: cmp             SP, x16
    //     0xbfee6c: b.ls            #0xbfeed8
    // 0xbfee70: ldr             x0, [fp, #0x10]
    // 0xbfee74: LoadField: r1 = r0->field_3b
    //     0xbfee74: ldur            w1, [x0, #0x3b]
    // 0xbfee78: DecompressPointer r1
    //     0xbfee78: add             x1, x1, HEAP, lsl #32
    // 0xbfee7c: r16 = Sentinel
    //     0xbfee7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfee80: cmp             w1, w16
    // 0xbfee84: b.eq            #0xbfeee0
    // 0xbfee88: SaveReg r1
    //     0xbfee88: str             x1, [SP, #-8]!
    // 0xbfee8c: r0 = dispose()
    //     0xbfee8c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfee90: add             SP, SP, #8
    // 0xbfee94: ldr             x0, [fp, #0x10]
    // 0xbfee98: LoadField: r1 = r0->field_43
    //     0xbfee98: ldur            w1, [x0, #0x43]
    // 0xbfee9c: DecompressPointer r1
    //     0xbfee9c: add             x1, x1, HEAP, lsl #32
    // 0xbfeea0: cmp             w1, NULL
    // 0xbfeea4: b.eq            #0xbfeeec
    // 0xbfeea8: SaveReg r1
    //     0xbfeea8: str             x1, [SP, #-8]!
    // 0xbfeeac: r0 = dispose()
    //     0xbfeeac: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfeeb0: add             SP, SP, #8
    // 0xbfeeb4: ldr             x0, [fp, #0x10]
    // 0xbfeeb8: StoreField: r0->field_43 = rNULL
    //     0xbfeeb8: stur            NULL, [x0, #0x43]
    // 0xbfeebc: SaveReg r0
    //     0xbfeebc: str             x0, [SP, #-8]!
    // 0xbfeec0: r0 = dispose()
    //     0xbfeec0: bl              #0x795b14  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0xbfeec4: add             SP, SP, #8
    // 0xbfeec8: r0 = Null
    //     0xbfeec8: mov             x0, NULL
    // 0xbfeecc: LeaveFrame
    //     0xbfeecc: mov             SP, fp
    //     0xbfeed0: ldp             fp, lr, [SP], #0x10
    // 0xbfeed4: ret
    //     0xbfeed4: ret             
    // 0xbfeed8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfeed8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfeedc: b               #0xbfee70
    // 0xbfeee0: r9 = _radiusController
    //     0xbfeee0: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e2e0] Field <InkSplash._radiusController@759036029>: late (offset: 0x3c)
    //     0xbfeee4: ldr             x9, [x9, #0x2e0]
    // 0xbfeee8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfeee8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbfeeec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbfeeec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

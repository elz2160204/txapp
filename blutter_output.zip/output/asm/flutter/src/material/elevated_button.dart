// lib: , url: package:flutter/src/material/elevated_button.dart

// class id: 1049233, size: 0x8
class :: {

  static _ _scaledPadding(/* No info */) {
    // ** addr: 0xc14b4c, size: 0xb8
    // 0xc14b4c: EnterFrame
    //     0xc14b4c: stp             fp, lr, [SP, #-0x10]!
    //     0xc14b50: mov             fp, SP
    // 0xc14b54: CheckStackOverflow
    //     0xc14b54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc14b58: cmp             SP, x16
    //     0xc14b5c: b.ls            #0xc14bec
    // 0xc14b60: ldr             x16, [fp, #0x10]
    // 0xc14b64: SaveReg r16
    //     0xc14b64: str             x16, [SP, #-8]!
    // 0xc14b68: r0 = maybeOf()
    //     0xc14b68: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0xc14b6c: add             SP, SP, #8
    // 0xc14b70: cmp             w0, NULL
    // 0xc14b74: b.ne            #0xc14b80
    // 0xc14b78: r0 = Null
    //     0xc14b78: mov             x0, NULL
    // 0xc14b7c: b               #0xc14bac
    // 0xc14b80: LoadField: d0 = r0->field_13
    //     0xc14b80: ldur            d0, [x0, #0x13]
    // 0xc14b84: r0 = inline_Allocate_Double()
    //     0xc14b84: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc14b88: add             x0, x0, #0x10
    //     0xc14b8c: cmp             x1, x0
    //     0xc14b90: b.ls            #0xc14bf4
    //     0xc14b94: str             x0, [THR, #0x60]  ; THR::top
    //     0xc14b98: sub             x0, x0, #0xf
    //     0xc14b9c: mov             x1, #0xd108
    //     0xc14ba0: movk            x1, #3, lsl #16
    //     0xc14ba4: stur            x1, [x0, #-1]
    // 0xc14ba8: StoreField: r0->field_7 = d0
    //     0xc14ba8: stur            d0, [x0, #7]
    // 0xc14bac: cmp             w0, NULL
    // 0xc14bb0: b.ne            #0xc14bbc
    // 0xc14bb4: d0 = 1.000000
    //     0xc14bb4: fmov            d0, #1.00000000
    // 0xc14bb8: b               #0xc14bc0
    // 0xc14bbc: LoadField: d0 = r0->field_7
    //     0xc14bbc: ldur            d0, [x0, #7]
    // 0xc14bc0: r16 = Instance_EdgeInsets
    //     0xc14bc0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe438] Obj!EdgeInsets@b35c01
    //     0xc14bc4: ldr             x16, [x16, #0x438]
    // 0xc14bc8: r30 = Instance_EdgeInsets
    //     0xc14bc8: add             lr, PP, #0x37, lsl #12  ; [pp+0x37700] Obj!EdgeInsets@b36951
    //     0xc14bcc: ldr             lr, [lr, #0x700]
    // 0xc14bd0: stp             lr, x16, [SP, #-0x10]!
    // 0xc14bd4: SaveReg d0
    //     0xc14bd4: str             d0, [SP, #-8]!
    // 0xc14bd8: r0 = scaledPadding()
    //     0xc14bd8: bl              #0xc14c04  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::scaledPadding
    // 0xc14bdc: add             SP, SP, #0x18
    // 0xc14be0: LeaveFrame
    //     0xc14be0: mov             SP, fp
    //     0xc14be4: ldp             fp, lr, [SP], #0x10
    // 0xc14be8: ret
    //     0xc14be8: ret             
    // 0xc14bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc14bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc14bf0: b               #0xc14b60
    // 0xc14bf4: SaveReg d0
    //     0xc14bf4: str             q0, [SP, #-0x10]!
    // 0xc14bf8: r0 = AllocateDouble()
    //     0xc14bf8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc14bfc: RestoreReg d0
    //     0xc14bfc: ldr             q0, [SP], #0x10
    // 0xc14c00: b               #0xc14ba8
  }
}

// class id: 2227, size: 0xc, field offset: 0xc
//   transformed mixin,
abstract class __ElevatedButtonDefaultMouseCursor&MaterialStateProperty&Diagnosticable extends MaterialStateProperty<MouseCursor?>
     with Diagnosticable {
}

// class id: 2228, size: 0x14, field offset: 0xc
class _ElevatedButtonDefaultMouseCursor extends __ElevatedButtonDefaultMouseCursor&MaterialStateProperty&Diagnosticable {
}

// class id: 2229, size: 0xc, field offset: 0xc
//   transformed mixin,
abstract class __ElevatedButtonDefaultElevation&MaterialStateProperty&Diagnosticable extends MaterialStateProperty<double>
     with Diagnosticable {
}

// class id: 2230, size: 0x14, field offset: 0xc
class _ElevatedButtonDefaultElevation extends __ElevatedButtonDefaultElevation&MaterialStateProperty&Diagnosticable {

  _ resolve(/* No info */) {
    // ** addr: 0x5b5700, size: 0x244
    // 0x5b5700: EnterFrame
    //     0x5b5700: stp             fp, lr, [SP, #-0x10]!
    //     0x5b5704: mov             fp, SP
    // 0x5b5708: CheckStackOverflow
    //     0x5b5708: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b570c: cmp             SP, x16
    //     0x5b5710: b.ls            #0x5b58fc
    // 0x5b5714: ldr             x1, [fp, #0x10]
    // 0x5b5718: r0 = LoadClassIdInstr(r1)
    //     0x5b5718: ldur            x0, [x1, #-1]
    //     0x5b571c: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5720: r16 = Instance_MaterialState
    //     0x5b5720: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x5b5724: ldr             x16, [x16, #0x2a0]
    // 0x5b5728: stp             x16, x1, [SP, #-0x10]!
    // 0x5b572c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b572c: mov             x17, #0xc98a
    //     0x5b5730: add             lr, x0, x17
    //     0x5b5734: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5738: blr             lr
    // 0x5b573c: add             SP, SP, #0x10
    // 0x5b5740: tbnz            w0, #4, #0x5b5754
    // 0x5b5744: r0 = 0.000000
    //     0x5b5744: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x5b5748: LeaveFrame
    //     0x5b5748: mov             SP, fp
    //     0x5b574c: ldp             fp, lr, [SP], #0x10
    // 0x5b5750: ret
    //     0x5b5750: ret             
    // 0x5b5754: ldr             x1, [fp, #0x10]
    // 0x5b5758: r0 = LoadClassIdInstr(r1)
    //     0x5b5758: ldur            x0, [x1, #-1]
    //     0x5b575c: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5760: r16 = Instance_MaterialState
    //     0x5b5760: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x5b5764: ldr             x16, [x16, #0xf78]
    // 0x5b5768: stp             x16, x1, [SP, #-0x10]!
    // 0x5b576c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b576c: mov             x17, #0xc98a
    //     0x5b5770: add             lr, x0, x17
    //     0x5b5774: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5778: blr             lr
    // 0x5b577c: add             SP, SP, #0x10
    // 0x5b5780: tbnz            w0, #4, #0x5b57c8
    // 0x5b5784: ldr             x1, [fp, #0x18]
    // 0x5b5788: d0 = 2.000000
    //     0x5b5788: fmov            d0, #2.00000000
    // 0x5b578c: LoadField: d1 = r1->field_b
    //     0x5b578c: ldur            d1, [x1, #0xb]
    // 0x5b5790: fadd            d2, d1, d0
    // 0x5b5794: r0 = inline_Allocate_Double()
    //     0x5b5794: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5b5798: add             x0, x0, #0x10
    //     0x5b579c: cmp             x1, x0
    //     0x5b57a0: b.ls            #0x5b5904
    //     0x5b57a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x5b57a8: sub             x0, x0, #0xf
    //     0x5b57ac: mov             x1, #0xd108
    //     0x5b57b0: movk            x1, #3, lsl #16
    //     0x5b57b4: stur            x1, [x0, #-1]
    // 0x5b57b8: StoreField: r0->field_7 = d2
    //     0x5b57b8: stur            d2, [x0, #7]
    // 0x5b57bc: LeaveFrame
    //     0x5b57bc: mov             SP, fp
    //     0x5b57c0: ldp             fp, lr, [SP], #0x10
    // 0x5b57c4: ret
    //     0x5b57c4: ret             
    // 0x5b57c8: ldr             x1, [fp, #0x18]
    // 0x5b57cc: ldr             x2, [fp, #0x10]
    // 0x5b57d0: d0 = 2.000000
    //     0x5b57d0: fmov            d0, #2.00000000
    // 0x5b57d4: r0 = LoadClassIdInstr(r2)
    //     0x5b57d4: ldur            x0, [x2, #-1]
    //     0x5b57d8: ubfx            x0, x0, #0xc, #0x14
    // 0x5b57dc: r16 = Instance_MaterialState
    //     0x5b57dc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x5b57e0: ldr             x16, [x16, #0xf88]
    // 0x5b57e4: stp             x16, x2, [SP, #-0x10]!
    // 0x5b57e8: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b57e8: mov             x17, #0xc98a
    //     0x5b57ec: add             lr, x0, x17
    //     0x5b57f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5b57f4: blr             lr
    // 0x5b57f8: add             SP, SP, #0x10
    // 0x5b57fc: tbnz            w0, #4, #0x5b5844
    // 0x5b5800: ldr             x1, [fp, #0x18]
    // 0x5b5804: d0 = 2.000000
    //     0x5b5804: fmov            d0, #2.00000000
    // 0x5b5808: LoadField: d1 = r1->field_b
    //     0x5b5808: ldur            d1, [x1, #0xb]
    // 0x5b580c: fadd            d2, d1, d0
    // 0x5b5810: r0 = inline_Allocate_Double()
    //     0x5b5810: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5b5814: add             x0, x0, #0x10
    //     0x5b5818: cmp             x1, x0
    //     0x5b581c: b.ls            #0x5b5914
    //     0x5b5820: str             x0, [THR, #0x60]  ; THR::top
    //     0x5b5824: sub             x0, x0, #0xf
    //     0x5b5828: mov             x1, #0xd108
    //     0x5b582c: movk            x1, #3, lsl #16
    //     0x5b5830: stur            x1, [x0, #-1]
    // 0x5b5834: StoreField: r0->field_7 = d2
    //     0x5b5834: stur            d2, [x0, #7]
    // 0x5b5838: LeaveFrame
    //     0x5b5838: mov             SP, fp
    //     0x5b583c: ldp             fp, lr, [SP], #0x10
    // 0x5b5840: ret
    //     0x5b5840: ret             
    // 0x5b5844: ldr             x1, [fp, #0x18]
    // 0x5b5848: ldr             x0, [fp, #0x10]
    // 0x5b584c: r2 = LoadClassIdInstr(r0)
    //     0x5b584c: ldur            x2, [x0, #-1]
    //     0x5b5850: ubfx            x2, x2, #0xc, #0x14
    // 0x5b5854: r16 = Instance_MaterialState
    //     0x5b5854: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x5b5858: ldr             x16, [x16, #0xf90]
    // 0x5b585c: stp             x16, x0, [SP, #-0x10]!
    // 0x5b5860: mov             x0, x2
    // 0x5b5864: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5864: mov             x17, #0xc98a
    //     0x5b5868: add             lr, x0, x17
    //     0x5b586c: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5870: blr             lr
    // 0x5b5874: add             SP, SP, #0x10
    // 0x5b5878: tbnz            w0, #4, #0x5b58c0
    // 0x5b587c: ldr             x1, [fp, #0x18]
    // 0x5b5880: d0 = 6.000000
    //     0x5b5880: fmov            d0, #6.00000000
    // 0x5b5884: LoadField: d1 = r1->field_b
    //     0x5b5884: ldur            d1, [x1, #0xb]
    // 0x5b5888: fadd            d2, d1, d0
    // 0x5b588c: r0 = inline_Allocate_Double()
    //     0x5b588c: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x5b5890: add             x0, x0, #0x10
    //     0x5b5894: cmp             x2, x0
    //     0x5b5898: b.ls            #0x5b5924
    //     0x5b589c: str             x0, [THR, #0x60]  ; THR::top
    //     0x5b58a0: sub             x0, x0, #0xf
    //     0x5b58a4: mov             x2, #0xd108
    //     0x5b58a8: movk            x2, #3, lsl #16
    //     0x5b58ac: stur            x2, [x0, #-1]
    // 0x5b58b0: StoreField: r0->field_7 = d2
    //     0x5b58b0: stur            d2, [x0, #7]
    // 0x5b58b4: LeaveFrame
    //     0x5b58b4: mov             SP, fp
    //     0x5b58b8: ldp             fp, lr, [SP], #0x10
    // 0x5b58bc: ret
    //     0x5b58bc: ret             
    // 0x5b58c0: ldr             x1, [fp, #0x18]
    // 0x5b58c4: LoadField: d0 = r1->field_b
    //     0x5b58c4: ldur            d0, [x1, #0xb]
    // 0x5b58c8: r0 = inline_Allocate_Double()
    //     0x5b58c8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5b58cc: add             x0, x0, #0x10
    //     0x5b58d0: cmp             x1, x0
    //     0x5b58d4: b.ls            #0x5b5934
    //     0x5b58d8: str             x0, [THR, #0x60]  ; THR::top
    //     0x5b58dc: sub             x0, x0, #0xf
    //     0x5b58e0: mov             x1, #0xd108
    //     0x5b58e4: movk            x1, #3, lsl #16
    //     0x5b58e8: stur            x1, [x0, #-1]
    // 0x5b58ec: StoreField: r0->field_7 = d0
    //     0x5b58ec: stur            d0, [x0, #7]
    // 0x5b58f0: LeaveFrame
    //     0x5b58f0: mov             SP, fp
    //     0x5b58f4: ldp             fp, lr, [SP], #0x10
    // 0x5b58f8: ret
    //     0x5b58f8: ret             
    // 0x5b58fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b58fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b5900: b               #0x5b5714
    // 0x5b5904: SaveReg d2
    //     0x5b5904: str             q2, [SP, #-0x10]!
    // 0x5b5908: r0 = AllocateDouble()
    //     0x5b5908: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b590c: RestoreReg d2
    //     0x5b590c: ldr             q2, [SP], #0x10
    // 0x5b5910: b               #0x5b57b8
    // 0x5b5914: SaveReg d2
    //     0x5b5914: str             q2, [SP, #-0x10]!
    // 0x5b5918: r0 = AllocateDouble()
    //     0x5b5918: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b591c: RestoreReg d2
    //     0x5b591c: ldr             q2, [SP], #0x10
    // 0x5b5920: b               #0x5b5834
    // 0x5b5924: SaveReg d2
    //     0x5b5924: str             q2, [SP, #-0x10]!
    // 0x5b5928: r0 = AllocateDouble()
    //     0x5b5928: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b592c: RestoreReg d2
    //     0x5b592c: ldr             q2, [SP], #0x10
    // 0x5b5930: b               #0x5b58b0
    // 0x5b5934: SaveReg d0
    //     0x5b5934: str             q0, [SP, #-0x10]!
    // 0x5b5938: r0 = AllocateDouble()
    //     0x5b5938: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b593c: RestoreReg d0
    //     0x5b593c: ldr             q0, [SP], #0x10
    // 0x5b5940: b               #0x5b58ec
  }
}

// class id: 2231, size: 0xc, field offset: 0xc
//   transformed mixin,
abstract class __ElevatedButtonDefaultColor&MaterialStateProperty&Diagnosticable extends MaterialStateProperty<Color?>
     with Diagnosticable {
}

// class id: 2234, size: 0x10, field offset: 0xc
class _ElevatedButtonDefaultOverlay extends __ElevatedButtonDefaultColor&MaterialStateProperty&Diagnosticable {

  _ resolve(/* No info */) {
    // ** addr: 0x5b55dc, size: 0x124
    // 0x5b55dc: EnterFrame
    //     0x5b55dc: stp             fp, lr, [SP, #-0x10]!
    //     0x5b55e0: mov             fp, SP
    // 0x5b55e4: CheckStackOverflow
    //     0x5b55e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b55e8: cmp             SP, x16
    //     0x5b55ec: b.ls            #0x5b56f8
    // 0x5b55f0: ldr             x1, [fp, #0x10]
    // 0x5b55f4: r0 = LoadClassIdInstr(r1)
    //     0x5b55f4: ldur            x0, [x1, #-1]
    //     0x5b55f8: ubfx            x0, x0, #0xc, #0x14
    // 0x5b55fc: r16 = Instance_MaterialState
    //     0x5b55fc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x5b5600: ldr             x16, [x16, #0xf78]
    // 0x5b5604: stp             x16, x1, [SP, #-0x10]!
    // 0x5b5608: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b5608: mov             x17, #0xc98a
    //     0x5b560c: add             lr, x0, x17
    //     0x5b5610: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5614: blr             lr
    // 0x5b5618: add             SP, SP, #0x10
    // 0x5b561c: tbnz            w0, #4, #0x5b5650
    // 0x5b5620: ldr             x1, [fp, #0x18]
    // 0x5b5624: d0 = 0.080000
    //     0x5b5624: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x5b5628: ldr             d0, [x17, #0xf80]
    // 0x5b562c: LoadField: r0 = r1->field_b
    //     0x5b562c: ldur            w0, [x1, #0xb]
    // 0x5b5630: DecompressPointer r0
    //     0x5b5630: add             x0, x0, HEAP, lsl #32
    // 0x5b5634: SaveReg r0
    //     0x5b5634: str             x0, [SP, #-8]!
    // 0x5b5638: SaveReg d0
    //     0x5b5638: str             d0, [SP, #-8]!
    // 0x5b563c: r0 = withOpacity()
    //     0x5b563c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b5640: add             SP, SP, #0x10
    // 0x5b5644: LeaveFrame
    //     0x5b5644: mov             SP, fp
    //     0x5b5648: ldp             fp, lr, [SP], #0x10
    // 0x5b564c: ret
    //     0x5b564c: ret             
    // 0x5b5650: ldr             x1, [fp, #0x18]
    // 0x5b5654: ldr             x2, [fp, #0x10]
    // 0x5b5658: r0 = LoadClassIdInstr(r2)
    //     0x5b5658: ldur            x0, [x2, #-1]
    //     0x5b565c: ubfx            x0, x0, #0xc, #0x14
    // 0x5b5660: r16 = Instance_MaterialState
    //     0x5b5660: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x5b5664: ldr             x16, [x16, #0xf88]
    // 0x5b5668: stp             x16, x2, [SP, #-0x10]!
    // 0x5b566c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b566c: mov             x17, #0xc98a
    //     0x5b5670: add             lr, x0, x17
    //     0x5b5674: ldr             lr, [x21, lr, lsl #3]
    //     0x5b5678: blr             lr
    // 0x5b567c: add             SP, SP, #0x10
    // 0x5b5680: tbz             w0, #4, #0x5b56b8
    // 0x5b5684: ldr             x0, [fp, #0x10]
    // 0x5b5688: r1 = LoadClassIdInstr(r0)
    //     0x5b5688: ldur            x1, [x0, #-1]
    //     0x5b568c: ubfx            x1, x1, #0xc, #0x14
    // 0x5b5690: r16 = Instance_MaterialState
    //     0x5b5690: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0x5b5694: ldr             x16, [x16, #0xf90]
    // 0x5b5698: stp             x16, x0, [SP, #-0x10]!
    // 0x5b569c: mov             x0, x1
    // 0x5b56a0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5b56a0: mov             x17, #0xc98a
    //     0x5b56a4: add             lr, x0, x17
    //     0x5b56a8: ldr             lr, [x21, lr, lsl #3]
    //     0x5b56ac: blr             lr
    // 0x5b56b0: add             SP, SP, #0x10
    // 0x5b56b4: tbnz            w0, #4, #0x5b56e8
    // 0x5b56b8: ldr             x0, [fp, #0x18]
    // 0x5b56bc: d0 = 0.240000
    //     0x5b56bc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe130] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0x5b56c0: ldr             d0, [x17, #0x130]
    // 0x5b56c4: LoadField: r1 = r0->field_b
    //     0x5b56c4: ldur            w1, [x0, #0xb]
    // 0x5b56c8: DecompressPointer r1
    //     0x5b56c8: add             x1, x1, HEAP, lsl #32
    // 0x5b56cc: SaveReg r1
    //     0x5b56cc: str             x1, [SP, #-8]!
    // 0x5b56d0: SaveReg d0
    //     0x5b56d0: str             d0, [SP, #-8]!
    // 0x5b56d4: r0 = withOpacity()
    //     0x5b56d4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x5b56d8: add             SP, SP, #0x10
    // 0x5b56dc: LeaveFrame
    //     0x5b56dc: mov             SP, fp
    //     0x5b56e0: ldp             fp, lr, [SP], #0x10
    // 0x5b56e4: ret
    //     0x5b56e4: ret             
    // 0x5b56e8: r0 = Null
    //     0x5b56e8: mov             x0, NULL
    // 0x5b56ec: LeaveFrame
    //     0x5b56ec: mov             SP, fp
    //     0x5b56f0: ldp             fp, lr, [SP], #0x10
    // 0x5b56f4: ret
    //     0x5b56f4: ret             
    // 0x5b56f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b56f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b56fc: b               #0x5b55f0
  }
}

// class id: 2235, size: 0x14, field offset: 0xc
class _ElevatedButtonDefaultColor extends __ElevatedButtonDefaultColor&MaterialStateProperty&Diagnosticable {
}

// class id: 2833, size: 0x68, field offset: 0x60
class _ElevatedButtonDefaultsM3 extends ButtonStyle {

  late final ColorScheme _colors; // offset: 0x64

  ColorScheme _colors(_ElevatedButtonDefaultsM3) {
    // ** addr: 0x84d928, size: 0x4c
    // 0x84d928: EnterFrame
    //     0x84d928: stp             fp, lr, [SP, #-0x10]!
    //     0x84d92c: mov             fp, SP
    // 0x84d930: CheckStackOverflow
    //     0x84d930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84d934: cmp             SP, x16
    //     0x84d938: b.ls            #0x84d96c
    // 0x84d93c: ldr             x0, [fp, #0x10]
    // 0x84d940: LoadField: r1 = r0->field_5f
    //     0x84d940: ldur            w1, [x0, #0x5f]
    // 0x84d944: DecompressPointer r1
    //     0x84d944: add             x1, x1, HEAP, lsl #32
    // 0x84d948: SaveReg r1
    //     0x84d948: str             x1, [SP, #-8]!
    // 0x84d94c: r0 = of()
    //     0x84d94c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x84d950: add             SP, SP, #8
    // 0x84d954: LoadField: r1 = r0->field_3f
    //     0x84d954: ldur            w1, [x0, #0x3f]
    // 0x84d958: DecompressPointer r1
    //     0x84d958: add             x1, x1, HEAP, lsl #32
    // 0x84d95c: mov             x0, x1
    // 0x84d960: LeaveFrame
    //     0x84d960: mov             SP, fp
    //     0x84d964: ldp             fp, lr, [SP], #0x10
    // 0x84d968: ret
    //     0x84d968: ret             
    // 0x84d96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84d96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84d970: b               #0x84d93c
  }
  get _ mouseCursor(/* No info */) {
    // ** addr: 0xce5994, size: 0x50
    // 0xce5994: EnterFrame
    //     0xce5994: stp             fp, lr, [SP, #-0x10]!
    //     0xce5998: mov             fp, SP
    // 0xce599c: CheckStackOverflow
    //     0xce599c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce59a0: cmp             SP, x16
    //     0xce59a4: b.ls            #0xce59dc
    // 0xce59a8: r1 = Function '<anonymous closure>':.
    //     0xce59a8: add             x1, PP, #0x40, lsl #12  ; [pp+0x401b8] AnonymousClosure: (0x5b5d20), in [package:flutter/src/material/text_button.dart] _TextButtonDefaultsM3::mouseCursor (0xce5a84)
    //     0xce59ac: ldr             x1, [x1, #0x1b8]
    // 0xce59b0: r2 = Null
    //     0xce59b0: mov             x2, NULL
    // 0xce59b4: r0 = AllocateClosure()
    //     0xce59b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce59b8: r16 = <MouseCursor?>
    //     0xce59b8: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0xce59bc: ldr             x16, [x16, #0x8b8]
    // 0xce59c0: stp             x0, x16, [SP, #-0x10]!
    // 0xce59c4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce59c4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce59c8: r0 = resolveWith()
    //     0xce59c8: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce59cc: add             SP, SP, #0x10
    // 0xce59d0: LeaveFrame
    //     0xce59d0: mov             SP, fp
    //     0xce59d4: ldp             fp, lr, [SP], #0x10
    // 0xce59d8: ret
    //     0xce59d8: ret             
    // 0xce59dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce59dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce59e0: b               #0xce59a8
  }
  get _ padding(/* No info */) {
    // ** addr: 0xce5b14, size: 0x5c
    // 0xce5b14: EnterFrame
    //     0xce5b14: stp             fp, lr, [SP, #-0x10]!
    //     0xce5b18: mov             fp, SP
    // 0xce5b1c: AllocStack(0x8)
    //     0xce5b1c: sub             SP, SP, #8
    // 0xce5b20: CheckStackOverflow
    //     0xce5b20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5b24: cmp             SP, x16
    //     0xce5b28: b.ls            #0xce5b68
    // 0xce5b2c: ldr             x0, [fp, #0x10]
    // 0xce5b30: LoadField: r1 = r0->field_5f
    //     0xce5b30: ldur            w1, [x0, #0x5f]
    // 0xce5b34: DecompressPointer r1
    //     0xce5b34: add             x1, x1, HEAP, lsl #32
    // 0xce5b38: SaveReg r1
    //     0xce5b38: str             x1, [SP, #-8]!
    // 0xce5b3c: r0 = _scaledPadding()
    //     0xce5b3c: bl              #0xc14b4c  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0xce5b40: add             SP, SP, #8
    // 0xce5b44: r1 = <EdgeInsetsGeometry>
    //     0xce5b44: add             x1, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0xce5b48: ldr             x1, [x1, #0x8c8]
    // 0xce5b4c: stur            x0, [fp, #-8]
    // 0xce5b50: r0 = MaterialStatePropertyAll()
    //     0xce5b50: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xce5b54: ldur            x1, [fp, #-8]
    // 0xce5b58: StoreField: r0->field_b = r1
    //     0xce5b58: stur            w1, [x0, #0xb]
    // 0xce5b5c: LeaveFrame
    //     0xce5b5c: mov             SP, fp
    //     0xce5b60: ldp             fp, lr, [SP], #0x10
    // 0xce5b64: ret
    //     0xce5b64: ret             
    // 0xce5b68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5b68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5b6c: b               #0xce5b2c
  }
  get _ elevation(/* No info */) {
    // ** addr: 0xce5c34, size: 0x4c
    // 0xce5c34: EnterFrame
    //     0xce5c34: stp             fp, lr, [SP, #-0x10]!
    //     0xce5c38: mov             fp, SP
    // 0xce5c3c: CheckStackOverflow
    //     0xce5c3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5c40: cmp             SP, x16
    //     0xce5c44: b.ls            #0xce5c78
    // 0xce5c48: r1 = Function '<anonymous closure>':.
    //     0xce5c48: add             x1, PP, #0x40, lsl #12  ; [pp+0x401c0] AnonymousClosure: (0xce5c80), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::elevation (0xce5c34)
    //     0xce5c4c: ldr             x1, [x1, #0x1c0]
    // 0xce5c50: r2 = Null
    //     0xce5c50: mov             x2, NULL
    // 0xce5c54: r0 = AllocateClosure()
    //     0xce5c54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce5c58: r16 = <double>
    //     0xce5c58: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xce5c5c: stp             x0, x16, [SP, #-0x10]!
    // 0xce5c60: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce5c60: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce5c64: r0 = resolveWith()
    //     0xce5c64: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce5c68: add             SP, SP, #0x10
    // 0xce5c6c: LeaveFrame
    //     0xce5c6c: mov             SP, fp
    //     0xce5c70: ldp             fp, lr, [SP], #0x10
    // 0xce5c74: ret
    //     0xce5c74: ret             
    // 0xce5c78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5c78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5c7c: b               #0xce5c48
  }
  [closure] double <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce5c80, size: 0x134
    // 0xce5c80: EnterFrame
    //     0xce5c80: stp             fp, lr, [SP, #-0x10]!
    //     0xce5c84: mov             fp, SP
    // 0xce5c88: CheckStackOverflow
    //     0xce5c88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5c8c: cmp             SP, x16
    //     0xce5c90: b.ls            #0xce5dac
    // 0xce5c94: ldr             x1, [fp, #0x10]
    // 0xce5c98: r0 = LoadClassIdInstr(r1)
    //     0xce5c98: ldur            x0, [x1, #-1]
    //     0xce5c9c: ubfx            x0, x0, #0xc, #0x14
    // 0xce5ca0: r16 = Instance_MaterialState
    //     0xce5ca0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xce5ca4: ldr             x16, [x16, #0x2a0]
    // 0xce5ca8: stp             x16, x1, [SP, #-0x10]!
    // 0xce5cac: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce5cac: mov             x17, #0xc98a
    //     0xce5cb0: add             lr, x0, x17
    //     0xce5cb4: ldr             lr, [x21, lr, lsl #3]
    //     0xce5cb8: blr             lr
    // 0xce5cbc: add             SP, SP, #0x10
    // 0xce5cc0: tbnz            w0, #4, #0xce5cd4
    // 0xce5cc4: r0 = 0.000000
    //     0xce5cc4: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xce5cc8: LeaveFrame
    //     0xce5cc8: mov             SP, fp
    //     0xce5ccc: ldp             fp, lr, [SP], #0x10
    // 0xce5cd0: ret
    //     0xce5cd0: ret             
    // 0xce5cd4: ldr             x1, [fp, #0x10]
    // 0xce5cd8: r0 = LoadClassIdInstr(r1)
    //     0xce5cd8: ldur            x0, [x1, #-1]
    //     0xce5cdc: ubfx            x0, x0, #0xc, #0x14
    // 0xce5ce0: r16 = Instance_MaterialState
    //     0xce5ce0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xce5ce4: ldr             x16, [x16, #0xf78]
    // 0xce5ce8: stp             x16, x1, [SP, #-0x10]!
    // 0xce5cec: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce5cec: mov             x17, #0xc98a
    //     0xce5cf0: add             lr, x0, x17
    //     0xce5cf4: ldr             lr, [x21, lr, lsl #3]
    //     0xce5cf8: blr             lr
    // 0xce5cfc: add             SP, SP, #0x10
    // 0xce5d00: tbnz            w0, #4, #0xce5d18
    // 0xce5d04: r0 = 3.000000
    //     0xce5d04: add             x0, PP, #0xc, lsl #12  ; [pp+0xcaf0] 3
    //     0xce5d08: ldr             x0, [x0, #0xaf0]
    // 0xce5d0c: LeaveFrame
    //     0xce5d0c: mov             SP, fp
    //     0xce5d10: ldp             fp, lr, [SP], #0x10
    // 0xce5d14: ret
    //     0xce5d14: ret             
    // 0xce5d18: ldr             x1, [fp, #0x10]
    // 0xce5d1c: r0 = LoadClassIdInstr(r1)
    //     0xce5d1c: ldur            x0, [x1, #-1]
    //     0xce5d20: ubfx            x0, x0, #0xc, #0x14
    // 0xce5d24: r16 = Instance_MaterialState
    //     0xce5d24: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xce5d28: ldr             x16, [x16, #0xf88]
    // 0xce5d2c: stp             x16, x1, [SP, #-0x10]!
    // 0xce5d30: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce5d30: mov             x17, #0xc98a
    //     0xce5d34: add             lr, x0, x17
    //     0xce5d38: ldr             lr, [x21, lr, lsl #3]
    //     0xce5d3c: blr             lr
    // 0xce5d40: add             SP, SP, #0x10
    // 0xce5d44: tbnz            w0, #4, #0xce5d58
    // 0xce5d48: r0 = 1.000000
    //     0xce5d48: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xce5d4c: LeaveFrame
    //     0xce5d4c: mov             SP, fp
    //     0xce5d50: ldp             fp, lr, [SP], #0x10
    // 0xce5d54: ret
    //     0xce5d54: ret             
    // 0xce5d58: ldr             x0, [fp, #0x10]
    // 0xce5d5c: r1 = LoadClassIdInstr(r0)
    //     0xce5d5c: ldur            x1, [x0, #-1]
    //     0xce5d60: ubfx            x1, x1, #0xc, #0x14
    // 0xce5d64: r16 = Instance_MaterialState
    //     0xce5d64: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xce5d68: ldr             x16, [x16, #0xf90]
    // 0xce5d6c: stp             x16, x0, [SP, #-0x10]!
    // 0xce5d70: mov             x0, x1
    // 0xce5d74: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce5d74: mov             x17, #0xc98a
    //     0xce5d78: add             lr, x0, x17
    //     0xce5d7c: ldr             lr, [x21, lr, lsl #3]
    //     0xce5d80: blr             lr
    // 0xce5d84: add             SP, SP, #0x10
    // 0xce5d88: tbnz            w0, #4, #0xce5d9c
    // 0xce5d8c: r0 = 1.000000
    //     0xce5d8c: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xce5d90: LeaveFrame
    //     0xce5d90: mov             SP, fp
    //     0xce5d94: ldp             fp, lr, [SP], #0x10
    // 0xce5d98: ret
    //     0xce5d98: ret             
    // 0xce5d9c: r0 = 1.000000
    //     0xce5d9c: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xce5da0: LeaveFrame
    //     0xce5da0: mov             SP, fp
    //     0xce5da4: ldp             fp, lr, [SP], #0x10
    // 0xce5da8: ret
    //     0xce5da8: ret             
    // 0xce5dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5dac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5db0: b               #0xce5c94
  }
  get _ surfaceTintColor(/* No info */) {
    // ** addr: 0xce5dc0, size: 0x8c
    // 0xce5dc0: EnterFrame
    //     0xce5dc0: stp             fp, lr, [SP, #-0x10]!
    //     0xce5dc4: mov             fp, SP
    // 0xce5dc8: AllocStack(0x8)
    //     0xce5dc8: sub             SP, SP, #8
    // 0xce5dcc: CheckStackOverflow
    //     0xce5dcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5dd0: cmp             SP, x16
    //     0xce5dd4: b.ls            #0xce5e44
    // 0xce5dd8: ldr             x1, [fp, #0x10]
    // 0xce5ddc: LoadField: r0 = r1->field_63
    //     0xce5ddc: ldur            w0, [x1, #0x63]
    // 0xce5de0: DecompressPointer r0
    //     0xce5de0: add             x0, x0, HEAP, lsl #32
    // 0xce5de4: r16 = Sentinel
    //     0xce5de4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce5de8: cmp             w0, w16
    // 0xce5dec: b.ne            #0xce5dfc
    // 0xce5df0: r2 = _colors
    //     0xce5df0: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce5df4: ldr             x2, [x2, #0x1c8]
    // 0xce5df8: r0 = InitLateFinalInstanceField()
    //     0xce5df8: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce5dfc: LoadField: r1 = r0->field_7f
    //     0xce5dfc: ldur            w1, [x0, #0x7f]
    // 0xce5e00: DecompressPointer r1
    //     0xce5e00: add             x1, x1, HEAP, lsl #32
    // 0xce5e04: cmp             w1, NULL
    // 0xce5e08: b.ne            #0xce5e1c
    // 0xce5e0c: LoadField: r1 = r0->field_b
    //     0xce5e0c: ldur            w1, [x0, #0xb]
    // 0xce5e10: DecompressPointer r1
    //     0xce5e10: add             x1, x1, HEAP, lsl #32
    // 0xce5e14: mov             x0, x1
    // 0xce5e18: b               #0xce5e20
    // 0xce5e1c: mov             x0, x1
    // 0xce5e20: stur            x0, [fp, #-8]
    // 0xce5e24: r1 = <Color>
    //     0xce5e24: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xce5e28: ldr             x1, [x1, #0x3f8]
    // 0xce5e2c: r0 = MaterialStatePropertyAll()
    //     0xce5e2c: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xce5e30: ldur            x1, [fp, #-8]
    // 0xce5e34: StoreField: r0->field_b = r1
    //     0xce5e34: stur            w1, [x0, #0xb]
    // 0xce5e38: LeaveFrame
    //     0xce5e38: mov             SP, fp
    //     0xce5e3c: ldp             fp, lr, [SP], #0x10
    // 0xce5e40: ret
    //     0xce5e40: ret             
    // 0xce5e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5e48: b               #0xce5dd8
  }
  get _ shadowColor(/* No info */) {
    // ** addr: 0xce5e4c, size: 0x88
    // 0xce5e4c: EnterFrame
    //     0xce5e4c: stp             fp, lr, [SP, #-0x10]!
    //     0xce5e50: mov             fp, SP
    // 0xce5e54: AllocStack(0x8)
    //     0xce5e54: sub             SP, SP, #8
    // 0xce5e58: CheckStackOverflow
    //     0xce5e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce5e5c: cmp             SP, x16
    //     0xce5e60: b.ls            #0xce5ecc
    // 0xce5e64: ldr             x1, [fp, #0x10]
    // 0xce5e68: LoadField: r0 = r1->field_63
    //     0xce5e68: ldur            w0, [x1, #0x63]
    // 0xce5e6c: DecompressPointer r0
    //     0xce5e6c: add             x0, x0, HEAP, lsl #32
    // 0xce5e70: r16 = Sentinel
    //     0xce5e70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce5e74: cmp             w0, w16
    // 0xce5e78: b.ne            #0xce5e88
    // 0xce5e7c: r2 = _colors
    //     0xce5e7c: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce5e80: ldr             x2, [x2, #0x1c8]
    // 0xce5e84: r0 = InitLateFinalInstanceField()
    //     0xce5e84: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce5e88: LoadField: r1 = r0->field_6b
    //     0xce5e88: ldur            w1, [x0, #0x6b]
    // 0xce5e8c: DecompressPointer r1
    //     0xce5e8c: add             x1, x1, HEAP, lsl #32
    // 0xce5e90: cmp             w1, NULL
    // 0xce5e94: b.ne            #0xce5ea4
    // 0xce5e98: r0 = Instance_Color
    //     0xce5e98: add             x0, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xce5e9c: ldr             x0, [x0, #0xf38]
    // 0xce5ea0: b               #0xce5ea8
    // 0xce5ea4: mov             x0, x1
    // 0xce5ea8: stur            x0, [fp, #-8]
    // 0xce5eac: r1 = <Color>
    //     0xce5eac: add             x1, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xce5eb0: ldr             x1, [x1, #0x3f8]
    // 0xce5eb4: r0 = MaterialStatePropertyAll()
    //     0xce5eb4: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0xce5eb8: ldur            x1, [fp, #-8]
    // 0xce5ebc: StoreField: r0->field_b = r1
    //     0xce5ebc: stur            w1, [x0, #0xb]
    // 0xce5ec0: LeaveFrame
    //     0xce5ec0: mov             SP, fp
    //     0xce5ec4: ldp             fp, lr, [SP], #0x10
    // 0xce5ec8: ret
    //     0xce5ec8: ret             
    // 0xce5ecc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce5ecc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce5ed0: b               #0xce5e64
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xce656c, size: 0x64
    // 0xce656c: EnterFrame
    //     0xce656c: stp             fp, lr, [SP, #-0x10]!
    //     0xce6570: mov             fp, SP
    // 0xce6574: CheckStackOverflow
    //     0xce6574: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce6578: cmp             SP, x16
    //     0xce657c: b.ls            #0xce65c8
    // 0xce6580: r1 = 1
    //     0xce6580: mov             x1, #1
    // 0xce6584: r0 = AllocateContext()
    //     0xce6584: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce6588: mov             x1, x0
    // 0xce658c: ldr             x0, [fp, #0x10]
    // 0xce6590: StoreField: r1->field_f = r0
    //     0xce6590: stur            w0, [x1, #0xf]
    // 0xce6594: mov             x2, x1
    // 0xce6598: r1 = Function '<anonymous closure>':.
    //     0xce6598: add             x1, PP, #0x40, lsl #12  ; [pp+0x401d0] AnonymousClosure: (0xce65d0), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::overlayColor (0xce656c)
    //     0xce659c: ldr             x1, [x1, #0x1d0]
    // 0xce65a0: r0 = AllocateClosure()
    //     0xce65a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce65a4: r16 = <Color?>
    //     0xce65a4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce65a8: ldr             x16, [x16, #0xf68]
    // 0xce65ac: stp             x0, x16, [SP, #-0x10]!
    // 0xce65b0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce65b0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce65b4: r0 = resolveWith()
    //     0xce65b4: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce65b8: add             SP, SP, #0x10
    // 0xce65bc: LeaveFrame
    //     0xce65bc: mov             SP, fp
    //     0xce65c0: ldp             fp, lr, [SP], #0x10
    // 0xce65c4: ret
    //     0xce65c4: ret             
    // 0xce65c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce65c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce65cc: b               #0xce6580
  }
  [closure] Color? <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce65d0, size: 0x1f4
    // 0xce65d0: EnterFrame
    //     0xce65d0: stp             fp, lr, [SP, #-0x10]!
    //     0xce65d4: mov             fp, SP
    // 0xce65d8: AllocStack(0x8)
    //     0xce65d8: sub             SP, SP, #8
    // 0xce65dc: SetupParameters()
    //     0xce65dc: ldr             x0, [fp, #0x18]
    //     0xce65e0: ldur            w1, [x0, #0x17]
    //     0xce65e4: add             x1, x1, HEAP, lsl #32
    //     0xce65e8: stur            x1, [fp, #-8]
    // 0xce65ec: CheckStackOverflow
    //     0xce65ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce65f0: cmp             SP, x16
    //     0xce65f4: b.ls            #0xce67bc
    // 0xce65f8: ldr             x2, [fp, #0x10]
    // 0xce65fc: r0 = LoadClassIdInstr(r2)
    //     0xce65fc: ldur            x0, [x2, #-1]
    //     0xce6600: ubfx            x0, x0, #0xc, #0x14
    // 0xce6604: r16 = Instance_MaterialState
    //     0xce6604: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0xce6608: ldr             x16, [x16, #0xf78]
    // 0xce660c: stp             x16, x2, [SP, #-0x10]!
    // 0xce6610: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce6610: mov             x17, #0xc98a
    //     0xce6614: add             lr, x0, x17
    //     0xce6618: ldr             lr, [x21, lr, lsl #3]
    //     0xce661c: blr             lr
    // 0xce6620: add             SP, SP, #0x10
    // 0xce6624: tbnz            w0, #4, #0xce6684
    // 0xce6628: ldur            x1, [fp, #-8]
    // 0xce662c: LoadField: r0 = r1->field_f
    //     0xce662c: ldur            w0, [x1, #0xf]
    // 0xce6630: DecompressPointer r0
    //     0xce6630: add             x0, x0, HEAP, lsl #32
    // 0xce6634: mov             x1, x0
    // 0xce6638: LoadField: r0 = r1->field_63
    //     0xce6638: ldur            w0, [x1, #0x63]
    // 0xce663c: DecompressPointer r0
    //     0xce663c: add             x0, x0, HEAP, lsl #32
    // 0xce6640: r16 = Sentinel
    //     0xce6640: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce6644: cmp             w0, w16
    // 0xce6648: b.ne            #0xce6658
    // 0xce664c: r2 = _colors
    //     0xce664c: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce6650: ldr             x2, [x2, #0x1c8]
    // 0xce6654: r0 = InitLateFinalInstanceField()
    //     0xce6654: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6658: LoadField: r1 = r0->field_b
    //     0xce6658: ldur            w1, [x0, #0xb]
    // 0xce665c: DecompressPointer r1
    //     0xce665c: add             x1, x1, HEAP, lsl #32
    // 0xce6660: SaveReg r1
    //     0xce6660: str             x1, [SP, #-8]!
    // 0xce6664: d0 = 0.080000
    //     0xce6664: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xce6668: ldr             d0, [x17, #0xf80]
    // 0xce666c: SaveReg d0
    //     0xce666c: str             d0, [SP, #-8]!
    // 0xce6670: r0 = withOpacity()
    //     0xce6670: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6674: add             SP, SP, #0x10
    // 0xce6678: LeaveFrame
    //     0xce6678: mov             SP, fp
    //     0xce667c: ldp             fp, lr, [SP], #0x10
    // 0xce6680: ret
    //     0xce6680: ret             
    // 0xce6684: ldr             x2, [fp, #0x10]
    // 0xce6688: ldur            x1, [fp, #-8]
    // 0xce668c: r0 = LoadClassIdInstr(r2)
    //     0xce668c: ldur            x0, [x2, #-1]
    //     0xce6690: ubfx            x0, x0, #0xc, #0x14
    // 0xce6694: r16 = Instance_MaterialState
    //     0xce6694: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0xce6698: ldr             x16, [x16, #0xf88]
    // 0xce669c: stp             x16, x2, [SP, #-0x10]!
    // 0xce66a0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce66a0: mov             x17, #0xc98a
    //     0xce66a4: add             lr, x0, x17
    //     0xce66a8: ldr             lr, [x21, lr, lsl #3]
    //     0xce66ac: blr             lr
    // 0xce66b0: add             SP, SP, #0x10
    // 0xce66b4: tbnz            w0, #4, #0xce6714
    // 0xce66b8: ldur            x1, [fp, #-8]
    // 0xce66bc: LoadField: r0 = r1->field_f
    //     0xce66bc: ldur            w0, [x1, #0xf]
    // 0xce66c0: DecompressPointer r0
    //     0xce66c0: add             x0, x0, HEAP, lsl #32
    // 0xce66c4: mov             x1, x0
    // 0xce66c8: LoadField: r0 = r1->field_63
    //     0xce66c8: ldur            w0, [x1, #0x63]
    // 0xce66cc: DecompressPointer r0
    //     0xce66cc: add             x0, x0, HEAP, lsl #32
    // 0xce66d0: r16 = Sentinel
    //     0xce66d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce66d4: cmp             w0, w16
    // 0xce66d8: b.ne            #0xce66e8
    // 0xce66dc: r2 = _colors
    //     0xce66dc: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce66e0: ldr             x2, [x2, #0x1c8]
    // 0xce66e4: r0 = InitLateFinalInstanceField()
    //     0xce66e4: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce66e8: LoadField: r1 = r0->field_b
    //     0xce66e8: ldur            w1, [x0, #0xb]
    // 0xce66ec: DecompressPointer r1
    //     0xce66ec: add             x1, x1, HEAP, lsl #32
    // 0xce66f0: SaveReg r1
    //     0xce66f0: str             x1, [SP, #-8]!
    // 0xce66f4: d0 = 0.120000
    //     0xce66f4: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce66f8: ldr             d0, [x17, #0xf48]
    // 0xce66fc: SaveReg d0
    //     0xce66fc: str             d0, [SP, #-8]!
    // 0xce6700: r0 = withOpacity()
    //     0xce6700: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce6704: add             SP, SP, #0x10
    // 0xce6708: LeaveFrame
    //     0xce6708: mov             SP, fp
    //     0xce670c: ldp             fp, lr, [SP], #0x10
    // 0xce6710: ret
    //     0xce6710: ret             
    // 0xce6714: ldr             x0, [fp, #0x10]
    // 0xce6718: ldur            x1, [fp, #-8]
    // 0xce671c: d0 = 0.120000
    //     0xce671c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6720: ldr             d0, [x17, #0xf48]
    // 0xce6724: r2 = LoadClassIdInstr(r0)
    //     0xce6724: ldur            x2, [x0, #-1]
    //     0xce6728: ubfx            x2, x2, #0xc, #0x14
    // 0xce672c: r16 = Instance_MaterialState
    //     0xce672c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf90] Obj!MaterialState@b65431
    //     0xce6730: ldr             x16, [x16, #0xf90]
    // 0xce6734: stp             x16, x0, [SP, #-0x10]!
    // 0xce6738: mov             x0, x2
    // 0xce673c: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce673c: mov             x17, #0xc98a
    //     0xce6740: add             lr, x0, x17
    //     0xce6744: ldr             lr, [x21, lr, lsl #3]
    //     0xce6748: blr             lr
    // 0xce674c: add             SP, SP, #0x10
    // 0xce6750: tbnz            w0, #4, #0xce67ac
    // 0xce6754: ldur            x0, [fp, #-8]
    // 0xce6758: LoadField: r1 = r0->field_f
    //     0xce6758: ldur            w1, [x0, #0xf]
    // 0xce675c: DecompressPointer r1
    //     0xce675c: add             x1, x1, HEAP, lsl #32
    // 0xce6760: LoadField: r0 = r1->field_63
    //     0xce6760: ldur            w0, [x1, #0x63]
    // 0xce6764: DecompressPointer r0
    //     0xce6764: add             x0, x0, HEAP, lsl #32
    // 0xce6768: r16 = Sentinel
    //     0xce6768: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce676c: cmp             w0, w16
    // 0xce6770: b.ne            #0xce6780
    // 0xce6774: r2 = _colors
    //     0xce6774: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce6778: ldr             x2, [x2, #0x1c8]
    // 0xce677c: r0 = InitLateFinalInstanceField()
    //     0xce677c: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce6780: LoadField: r1 = r0->field_b
    //     0xce6780: ldur            w1, [x0, #0xb]
    // 0xce6784: DecompressPointer r1
    //     0xce6784: add             x1, x1, HEAP, lsl #32
    // 0xce6788: SaveReg r1
    //     0xce6788: str             x1, [SP, #-8]!
    // 0xce678c: d0 = 0.120000
    //     0xce678c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce6790: ldr             d0, [x17, #0xf48]
    // 0xce6794: SaveReg d0
    //     0xce6794: str             d0, [SP, #-8]!
    // 0xce6798: r0 = withOpacity()
    //     0xce6798: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce679c: add             SP, SP, #0x10
    // 0xce67a0: LeaveFrame
    //     0xce67a0: mov             SP, fp
    //     0xce67a4: ldp             fp, lr, [SP], #0x10
    // 0xce67a8: ret
    //     0xce67a8: ret             
    // 0xce67ac: r0 = Null
    //     0xce67ac: mov             x0, NULL
    // 0xce67b0: LeaveFrame
    //     0xce67b0: mov             SP, fp
    //     0xce67b4: ldp             fp, lr, [SP], #0x10
    // 0xce67b8: ret
    //     0xce67b8: ret             
    // 0xce67bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce67bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce67c0: b               #0xce65f8
  }
  get _ foregroundColor(/* No info */) {
    // ** addr: 0xce7504, size: 0x64
    // 0xce7504: EnterFrame
    //     0xce7504: stp             fp, lr, [SP, #-0x10]!
    //     0xce7508: mov             fp, SP
    // 0xce750c: CheckStackOverflow
    //     0xce750c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7510: cmp             SP, x16
    //     0xce7514: b.ls            #0xce7560
    // 0xce7518: r1 = 1
    //     0xce7518: mov             x1, #1
    // 0xce751c: r0 = AllocateContext()
    //     0xce751c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce7520: mov             x1, x0
    // 0xce7524: ldr             x0, [fp, #0x10]
    // 0xce7528: StoreField: r1->field_f = r0
    //     0xce7528: stur            w0, [x1, #0xf]
    // 0xce752c: mov             x2, x1
    // 0xce7530: r1 = Function '<anonymous closure>':.
    //     0xce7530: add             x1, PP, #0x40, lsl #12  ; [pp+0x401d8] AnonymousClosure: (0xce7568), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::foregroundColor (0xce7504)
    //     0xce7534: ldr             x1, [x1, #0x1d8]
    // 0xce7538: r0 = AllocateClosure()
    //     0xce7538: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce753c: r16 = <Color?>
    //     0xce753c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce7540: ldr             x16, [x16, #0xf68]
    // 0xce7544: stp             x0, x16, [SP, #-0x10]!
    // 0xce7548: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce7548: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce754c: r0 = resolveWith()
    //     0xce754c: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce7550: add             SP, SP, #0x10
    // 0xce7554: LeaveFrame
    //     0xce7554: mov             SP, fp
    //     0xce7558: ldp             fp, lr, [SP], #0x10
    // 0xce755c: ret
    //     0xce755c: ret             
    // 0xce7560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7560: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7564: b               #0xce7518
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce7568, size: 0x100
    // 0xce7568: EnterFrame
    //     0xce7568: stp             fp, lr, [SP, #-0x10]!
    //     0xce756c: mov             fp, SP
    // 0xce7570: AllocStack(0x8)
    //     0xce7570: sub             SP, SP, #8
    // 0xce7574: SetupParameters()
    //     0xce7574: ldr             x0, [fp, #0x18]
    //     0xce7578: ldur            w1, [x0, #0x17]
    //     0xce757c: add             x1, x1, HEAP, lsl #32
    //     0xce7580: stur            x1, [fp, #-8]
    // 0xce7584: CheckStackOverflow
    //     0xce7584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7588: cmp             SP, x16
    //     0xce758c: b.ls            #0xce7660
    // 0xce7590: ldr             x0, [fp, #0x10]
    // 0xce7594: r2 = LoadClassIdInstr(r0)
    //     0xce7594: ldur            x2, [x0, #-1]
    //     0xce7598: ubfx            x2, x2, #0xc, #0x14
    // 0xce759c: r16 = Instance_MaterialState
    //     0xce759c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xce75a0: ldr             x16, [x16, #0x2a0]
    // 0xce75a4: stp             x16, x0, [SP, #-0x10]!
    // 0xce75a8: mov             x0, x2
    // 0xce75ac: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce75ac: mov             x17, #0xc98a
    //     0xce75b0: add             lr, x0, x17
    //     0xce75b4: ldr             lr, [x21, lr, lsl #3]
    //     0xce75b8: blr             lr
    // 0xce75bc: add             SP, SP, #0x10
    // 0xce75c0: tbnz            w0, #4, #0xce761c
    // 0xce75c4: ldur            x0, [fp, #-8]
    // 0xce75c8: LoadField: r1 = r0->field_f
    //     0xce75c8: ldur            w1, [x0, #0xf]
    // 0xce75cc: DecompressPointer r1
    //     0xce75cc: add             x1, x1, HEAP, lsl #32
    // 0xce75d0: LoadField: r0 = r1->field_63
    //     0xce75d0: ldur            w0, [x1, #0x63]
    // 0xce75d4: DecompressPointer r0
    //     0xce75d4: add             x0, x0, HEAP, lsl #32
    // 0xce75d8: r16 = Sentinel
    //     0xce75d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce75dc: cmp             w0, w16
    // 0xce75e0: b.ne            #0xce75f0
    // 0xce75e4: r2 = _colors
    //     0xce75e4: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce75e8: ldr             x2, [x2, #0x1c8]
    // 0xce75ec: r0 = InitLateFinalInstanceField()
    //     0xce75ec: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce75f0: LoadField: r1 = r0->field_57
    //     0xce75f0: ldur            w1, [x0, #0x57]
    // 0xce75f4: DecompressPointer r1
    //     0xce75f4: add             x1, x1, HEAP, lsl #32
    // 0xce75f8: SaveReg r1
    //     0xce75f8: str             x1, [SP, #-8]!
    // 0xce75fc: d0 = 0.380000
    //     0xce75fc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xce7600: ldr             d0, [x17, #0x140]
    // 0xce7604: SaveReg d0
    //     0xce7604: str             d0, [SP, #-8]!
    // 0xce7608: r0 = withOpacity()
    //     0xce7608: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce760c: add             SP, SP, #0x10
    // 0xce7610: LeaveFrame
    //     0xce7610: mov             SP, fp
    //     0xce7614: ldp             fp, lr, [SP], #0x10
    // 0xce7618: ret
    //     0xce7618: ret             
    // 0xce761c: ldur            x0, [fp, #-8]
    // 0xce7620: LoadField: r1 = r0->field_f
    //     0xce7620: ldur            w1, [x0, #0xf]
    // 0xce7624: DecompressPointer r1
    //     0xce7624: add             x1, x1, HEAP, lsl #32
    // 0xce7628: LoadField: r0 = r1->field_63
    //     0xce7628: ldur            w0, [x1, #0x63]
    // 0xce762c: DecompressPointer r0
    //     0xce762c: add             x0, x0, HEAP, lsl #32
    // 0xce7630: r16 = Sentinel
    //     0xce7630: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7634: cmp             w0, w16
    // 0xce7638: b.ne            #0xce7648
    // 0xce763c: r2 = _colors
    //     0xce763c: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce7640: ldr             x2, [x2, #0x1c8]
    // 0xce7644: r0 = InitLateFinalInstanceField()
    //     0xce7644: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7648: LoadField: r1 = r0->field_b
    //     0xce7648: ldur            w1, [x0, #0xb]
    // 0xce764c: DecompressPointer r1
    //     0xce764c: add             x1, x1, HEAP, lsl #32
    // 0xce7650: mov             x0, x1
    // 0xce7654: LeaveFrame
    //     0xce7654: mov             SP, fp
    //     0xce7658: ldp             fp, lr, [SP], #0x10
    // 0xce765c: ret
    //     0xce765c: ret             
    // 0xce7660: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7660: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7664: b               #0xce7590
  }
  get _ backgroundColor(/* No info */) {
    // ** addr: 0xce7b28, size: 0x64
    // 0xce7b28: EnterFrame
    //     0xce7b28: stp             fp, lr, [SP, #-0x10]!
    //     0xce7b2c: mov             fp, SP
    // 0xce7b30: CheckStackOverflow
    //     0xce7b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7b34: cmp             SP, x16
    //     0xce7b38: b.ls            #0xce7b84
    // 0xce7b3c: r1 = 1
    //     0xce7b3c: mov             x1, #1
    // 0xce7b40: r0 = AllocateContext()
    //     0xce7b40: bl              #0xd68aa4  ; AllocateContextStub
    // 0xce7b44: mov             x1, x0
    // 0xce7b48: ldr             x0, [fp, #0x10]
    // 0xce7b4c: StoreField: r1->field_f = r0
    //     0xce7b4c: stur            w0, [x1, #0xf]
    // 0xce7b50: mov             x2, x1
    // 0xce7b54: r1 = Function '<anonymous closure>':.
    //     0xce7b54: add             x1, PP, #0x40, lsl #12  ; [pp+0x401e0] AnonymousClosure: (0xce7b8c), in [package:flutter/src/material/elevated_button.dart] _ElevatedButtonDefaultsM3::backgroundColor (0xce7b28)
    //     0xce7b58: ldr             x1, [x1, #0x1e0]
    // 0xce7b5c: r0 = AllocateClosure()
    //     0xce7b5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xce7b60: r16 = <Color?>
    //     0xce7b60: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xce7b64: ldr             x16, [x16, #0xf68]
    // 0xce7b68: stp             x0, x16, [SP, #-0x10]!
    // 0xce7b6c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xce7b6c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xce7b70: r0 = resolveWith()
    //     0xce7b70: bl              #0x84d13c  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveWith
    // 0xce7b74: add             SP, SP, #0x10
    // 0xce7b78: LeaveFrame
    //     0xce7b78: mov             SP, fp
    //     0xce7b7c: ldp             fp, lr, [SP], #0x10
    // 0xce7b80: ret
    //     0xce7b80: ret             
    // 0xce7b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7b88: b               #0xce7b3c
  }
  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0xce7b8c, size: 0x100
    // 0xce7b8c: EnterFrame
    //     0xce7b8c: stp             fp, lr, [SP, #-0x10]!
    //     0xce7b90: mov             fp, SP
    // 0xce7b94: AllocStack(0x8)
    //     0xce7b94: sub             SP, SP, #8
    // 0xce7b98: SetupParameters()
    //     0xce7b98: ldr             x0, [fp, #0x18]
    //     0xce7b9c: ldur            w1, [x0, #0x17]
    //     0xce7ba0: add             x1, x1, HEAP, lsl #32
    //     0xce7ba4: stur            x1, [fp, #-8]
    // 0xce7ba8: CheckStackOverflow
    //     0xce7ba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce7bac: cmp             SP, x16
    //     0xce7bb0: b.ls            #0xce7c84
    // 0xce7bb4: ldr             x0, [fp, #0x10]
    // 0xce7bb8: r2 = LoadClassIdInstr(r0)
    //     0xce7bb8: ldur            x2, [x0, #-1]
    //     0xce7bbc: ubfx            x2, x2, #0xc, #0x14
    // 0xce7bc0: r16 = Instance_MaterialState
    //     0xce7bc0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xce7bc4: ldr             x16, [x16, #0x2a0]
    // 0xce7bc8: stp             x16, x0, [SP, #-0x10]!
    // 0xce7bcc: mov             x0, x2
    // 0xce7bd0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xce7bd0: mov             x17, #0xc98a
    //     0xce7bd4: add             lr, x0, x17
    //     0xce7bd8: ldr             lr, [x21, lr, lsl #3]
    //     0xce7bdc: blr             lr
    // 0xce7be0: add             SP, SP, #0x10
    // 0xce7be4: tbnz            w0, #4, #0xce7c40
    // 0xce7be8: ldur            x0, [fp, #-8]
    // 0xce7bec: LoadField: r1 = r0->field_f
    //     0xce7bec: ldur            w1, [x0, #0xf]
    // 0xce7bf0: DecompressPointer r1
    //     0xce7bf0: add             x1, x1, HEAP, lsl #32
    // 0xce7bf4: LoadField: r0 = r1->field_63
    //     0xce7bf4: ldur            w0, [x1, #0x63]
    // 0xce7bf8: DecompressPointer r0
    //     0xce7bf8: add             x0, x0, HEAP, lsl #32
    // 0xce7bfc: r16 = Sentinel
    //     0xce7bfc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7c00: cmp             w0, w16
    // 0xce7c04: b.ne            #0xce7c14
    // 0xce7c08: r2 = _colors
    //     0xce7c08: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce7c0c: ldr             x2, [x2, #0x1c8]
    // 0xce7c10: r0 = InitLateFinalInstanceField()
    //     0xce7c10: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7c14: LoadField: r1 = r0->field_57
    //     0xce7c14: ldur            w1, [x0, #0x57]
    // 0xce7c18: DecompressPointer r1
    //     0xce7c18: add             x1, x1, HEAP, lsl #32
    // 0xce7c1c: SaveReg r1
    //     0xce7c1c: str             x1, [SP, #-8]!
    // 0xce7c20: d0 = 0.120000
    //     0xce7c20: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xce7c24: ldr             d0, [x17, #0xf48]
    // 0xce7c28: SaveReg d0
    //     0xce7c28: str             d0, [SP, #-8]!
    // 0xce7c2c: r0 = withOpacity()
    //     0xce7c2c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xce7c30: add             SP, SP, #0x10
    // 0xce7c34: LeaveFrame
    //     0xce7c34: mov             SP, fp
    //     0xce7c38: ldp             fp, lr, [SP], #0x10
    // 0xce7c3c: ret
    //     0xce7c3c: ret             
    // 0xce7c40: ldur            x0, [fp, #-8]
    // 0xce7c44: LoadField: r1 = r0->field_f
    //     0xce7c44: ldur            w1, [x0, #0xf]
    // 0xce7c48: DecompressPointer r1
    //     0xce7c48: add             x1, x1, HEAP, lsl #32
    // 0xce7c4c: LoadField: r0 = r1->field_63
    //     0xce7c4c: ldur            w0, [x1, #0x63]
    // 0xce7c50: DecompressPointer r0
    //     0xce7c50: add             x0, x0, HEAP, lsl #32
    // 0xce7c54: r16 = Sentinel
    //     0xce7c54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xce7c58: cmp             w0, w16
    // 0xce7c5c: b.ne            #0xce7c6c
    // 0xce7c60: r2 = _colors
    //     0xce7c60: add             x2, PP, #0x40, lsl #12  ; [pp+0x401c8] Field <_ElevatedButtonDefaultsM3@734256481._colors@734256481>: late final (offset: 0x64)
    //     0xce7c64: ldr             x2, [x2, #0x1c8]
    // 0xce7c68: r0 = InitLateFinalInstanceField()
    //     0xce7c68: bl              #0xd67b98  ; InitLateFinalInstanceFieldStub
    // 0xce7c6c: LoadField: r1 = r0->field_53
    //     0xce7c6c: ldur            w1, [x0, #0x53]
    // 0xce7c70: DecompressPointer r1
    //     0xce7c70: add             x1, x1, HEAP, lsl #32
    // 0xce7c74: mov             x0, x1
    // 0xce7c78: LeaveFrame
    //     0xce7c78: mov             SP, fp
    //     0xce7c7c: ldp             fp, lr, [SP], #0x10
    // 0xce7c80: ret
    //     0xce7c80: ret             
    // 0xce7c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce7c84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce7c88: b               #0xce7bb4
  }
}

// class id: 4165, size: 0x34, field offset: 0x34
//   const constructor, 
class ElevatedButton extends ButtonStyleButton {

  static _ styleFrom(/* No info */) {
    // ** addr: 0x916a80, size: 0x970
    // 0x916a80: EnterFrame
    //     0x916a80: stp             fp, lr, [SP, #-0x10]!
    //     0x916a84: mov             fp, SP
    // 0x916a88: AllocStack(0xa0)
    //     0x916a88: sub             SP, SP, #0xa0
    // 0x916a8c: SetupParameters(dynamic _ /* r3, fp-0x98 */, dynamic _ /* fp-0x8 */, {dynamic alignment = Null /* r5, fp-0x90 */, dynamic animationDuration = Null /* r6, fp-0x88 */, dynamic disabledBackgroundColor = Null /* r7 */, dynamic disabledForegroundColor = Null /* r8, fp-0x80 */, dynamic disabledMouseCursor = Null /* r9, fp-0x78 */, dynamic elevation = Null /* r10, fp-0x70 */, dynamic enableFeedback = Null /* r11, fp-0x68 */, dynamic enabledMouseCursor = Null /* r12, fp-0x60 */, dynamic foregroundColor = Null /* r13, fp-0x58 */, dynamic maximumSize = Null /* r14, fp-0x50 */, dynamic minimumSize = Null /* r19, fp-0x48 */, dynamic padding = Null /* r20, fp-0x40 */, dynamic shadowColor = Null /* fp-0x10 */, dynamic splashFactory = Null /* fp-0x18 */, dynamic tapTargetSize = Null /* fp-0x20 */, dynamic textStyle = Null /* r4, fp-0x38 */, dynamic visualDensity = Null /* r0, fp-0x30 */})
    //     0x916a8c: mov             x0, x4
    //     0x916a90: ldur            w1, [x0, #0x13]
    //     0x916a94: add             x1, x1, HEAP, lsl #32
    //     0x916a98: sub             x2, x1, #4
    //     0x916a9c: add             x3, fp, w2, sxtw #2
    //     0x916aa0: ldr             x3, [x3, #0x18]
    //     0x916aa4: stur            x3, [fp, #-0x98]
    //     0x916aa8: add             x4, fp, w2, sxtw #2
    //     0x916aac: ldr             x4, [x4, #0x10]
    //     0x916ab0: stur            x4, [fp, #-8]
    //     0x916ab4: ldur            w2, [x0, #0x1f]
    //     0x916ab8: add             x2, x2, HEAP, lsl #32
    //     0x916abc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdad8] "alignment"
    //     0x916ac0: ldr             x16, [x16, #0xad8]
    //     0x916ac4: cmp             w2, w16
    //     0x916ac8: b.ne            #0x916aec
    //     0x916acc: ldur            w2, [x0, #0x23]
    //     0x916ad0: add             x2, x2, HEAP, lsl #32
    //     0x916ad4: sub             w5, w1, w2
    //     0x916ad8: add             x2, fp, w5, sxtw #2
    //     0x916adc: ldr             x2, [x2, #8]
    //     0x916ae0: mov             x5, x2
    //     0x916ae4: mov             x2, #1
    //     0x916ae8: b               #0x916af4
    //     0x916aec: mov             x5, NULL
    //     0x916af0: mov             x2, #0
    //     0x916af4: stur            x5, [fp, #-0x90]
    //     0x916af8: lsl             x6, x2, #1
    //     0x916afc: lsl             w7, w6, #1
    //     0x916b00: add             w8, w7, #8
    //     0x916b04: add             x16, x0, w8, sxtw #1
    //     0x916b08: ldur            w9, [x16, #0xf]
    //     0x916b0c: add             x9, x9, HEAP, lsl #32
    //     0x916b10: add             x16, PP, #0x26, lsl #12  ; [pp+0x26850] "animationDuration"
    //     0x916b14: ldr             x16, [x16, #0x850]
    //     0x916b18: cmp             w9, w16
    //     0x916b1c: b.ne            #0x916b50
    //     0x916b20: add             w2, w7, #0xa
    //     0x916b24: add             x16, x0, w2, sxtw #1
    //     0x916b28: ldur            w7, [x16, #0xf]
    //     0x916b2c: add             x7, x7, HEAP, lsl #32
    //     0x916b30: sub             w2, w1, w7
    //     0x916b34: add             x7, fp, w2, sxtw #2
    //     0x916b38: ldr             x7, [x7, #8]
    //     0x916b3c: add             w2, w6, #2
    //     0x916b40: sbfx            x6, x2, #1, #0x1f
    //     0x916b44: mov             x2, x6
    //     0x916b48: mov             x6, x7
    //     0x916b4c: b               #0x916b54
    //     0x916b50: mov             x6, NULL
    //     0x916b54: stur            x6, [fp, #-0x88]
    //     0x916b58: lsl             x7, x2, #1
    //     0x916b5c: lsl             w8, w7, #1
    //     0x916b60: add             w9, w8, #8
    //     0x916b64: add             x16, x0, w9, sxtw #1
    //     0x916b68: ldur            w10, [x16, #0xf]
    //     0x916b6c: add             x10, x10, HEAP, lsl #32
    //     0x916b70: add             x16, PP, #0x26, lsl #12  ; [pp+0x26858] "disabledBackgroundColor"
    //     0x916b74: ldr             x16, [x16, #0x858]
    //     0x916b78: cmp             w10, w16
    //     0x916b7c: b.ne            #0x916bb0
    //     0x916b80: add             w2, w8, #0xa
    //     0x916b84: add             x16, x0, w2, sxtw #1
    //     0x916b88: ldur            w8, [x16, #0xf]
    //     0x916b8c: add             x8, x8, HEAP, lsl #32
    //     0x916b90: sub             w2, w1, w8
    //     0x916b94: add             x8, fp, w2, sxtw #2
    //     0x916b98: ldr             x8, [x8, #8]
    //     0x916b9c: add             w2, w7, #2
    //     0x916ba0: sbfx            x7, x2, #1, #0x1f
    //     0x916ba4: mov             x2, x7
    //     0x916ba8: mov             x7, x8
    //     0x916bac: b               #0x916bb4
    //     0x916bb0: mov             x7, NULL
    //     0x916bb4: lsl             x8, x2, #1
    //     0x916bb8: lsl             w9, w8, #1
    //     0x916bbc: add             w10, w9, #8
    //     0x916bc0: add             x16, x0, w10, sxtw #1
    //     0x916bc4: ldur            w11, [x16, #0xf]
    //     0x916bc8: add             x11, x11, HEAP, lsl #32
    //     0x916bcc: add             x16, PP, #0x26, lsl #12  ; [pp+0x26860] "disabledForegroundColor"
    //     0x916bd0: ldr             x16, [x16, #0x860]
    //     0x916bd4: cmp             w11, w16
    //     0x916bd8: b.ne            #0x916c0c
    //     0x916bdc: add             w2, w9, #0xa
    //     0x916be0: add             x16, x0, w2, sxtw #1
    //     0x916be4: ldur            w9, [x16, #0xf]
    //     0x916be8: add             x9, x9, HEAP, lsl #32
    //     0x916bec: sub             w2, w1, w9
    //     0x916bf0: add             x9, fp, w2, sxtw #2
    //     0x916bf4: ldr             x9, [x9, #8]
    //     0x916bf8: add             w2, w8, #2
    //     0x916bfc: sbfx            x8, x2, #1, #0x1f
    //     0x916c00: mov             x2, x8
    //     0x916c04: mov             x8, x9
    //     0x916c08: b               #0x916c10
    //     0x916c0c: mov             x8, NULL
    //     0x916c10: stur            x8, [fp, #-0x80]
    //     0x916c14: lsl             x9, x2, #1
    //     0x916c18: lsl             w10, w9, #1
    //     0x916c1c: add             w11, w10, #8
    //     0x916c20: add             x16, x0, w11, sxtw #1
    //     0x916c24: ldur            w12, [x16, #0xf]
    //     0x916c28: add             x12, x12, HEAP, lsl #32
    //     0x916c2c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26868] "disabledMouseCursor"
    //     0x916c30: ldr             x16, [x16, #0x868]
    //     0x916c34: cmp             w12, w16
    //     0x916c38: b.ne            #0x916c6c
    //     0x916c3c: add             w2, w10, #0xa
    //     0x916c40: add             x16, x0, w2, sxtw #1
    //     0x916c44: ldur            w10, [x16, #0xf]
    //     0x916c48: add             x10, x10, HEAP, lsl #32
    //     0x916c4c: sub             w2, w1, w10
    //     0x916c50: add             x10, fp, w2, sxtw #2
    //     0x916c54: ldr             x10, [x10, #8]
    //     0x916c58: add             w2, w9, #2
    //     0x916c5c: sbfx            x9, x2, #1, #0x1f
    //     0x916c60: mov             x2, x9
    //     0x916c64: mov             x9, x10
    //     0x916c68: b               #0x916c70
    //     0x916c6c: mov             x9, NULL
    //     0x916c70: stur            x9, [fp, #-0x78]
    //     0x916c74: lsl             x10, x2, #1
    //     0x916c78: lsl             w11, w10, #1
    //     0x916c7c: add             w12, w11, #8
    //     0x916c80: add             x16, x0, w12, sxtw #1
    //     0x916c84: ldur            w13, [x16, #0xf]
    //     0x916c88: add             x13, x13, HEAP, lsl #32
    //     0x916c8c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26870] "elevation"
    //     0x916c90: ldr             x16, [x16, #0x870]
    //     0x916c94: cmp             w13, w16
    //     0x916c98: b.ne            #0x916ccc
    //     0x916c9c: add             w2, w11, #0xa
    //     0x916ca0: add             x16, x0, w2, sxtw #1
    //     0x916ca4: ldur            w11, [x16, #0xf]
    //     0x916ca8: add             x11, x11, HEAP, lsl #32
    //     0x916cac: sub             w2, w1, w11
    //     0x916cb0: add             x11, fp, w2, sxtw #2
    //     0x916cb4: ldr             x11, [x11, #8]
    //     0x916cb8: add             w2, w10, #2
    //     0x916cbc: sbfx            x10, x2, #1, #0x1f
    //     0x916cc0: mov             x2, x10
    //     0x916cc4: mov             x10, x11
    //     0x916cc8: b               #0x916cd0
    //     0x916ccc: mov             x10, NULL
    //     0x916cd0: stur            x10, [fp, #-0x70]
    //     0x916cd4: lsl             x11, x2, #1
    //     0x916cd8: lsl             w12, w11, #1
    //     0x916cdc: add             w13, w12, #8
    //     0x916ce0: add             x16, x0, w13, sxtw #1
    //     0x916ce4: ldur            w14, [x16, #0xf]
    //     0x916ce8: add             x14, x14, HEAP, lsl #32
    //     0x916cec: add             x16, PP, #0x26, lsl #12  ; [pp+0x26878] "enableFeedback"
    //     0x916cf0: ldr             x16, [x16, #0x878]
    //     0x916cf4: cmp             w14, w16
    //     0x916cf8: b.ne            #0x916d2c
    //     0x916cfc: add             w2, w12, #0xa
    //     0x916d00: add             x16, x0, w2, sxtw #1
    //     0x916d04: ldur            w12, [x16, #0xf]
    //     0x916d08: add             x12, x12, HEAP, lsl #32
    //     0x916d0c: sub             w2, w1, w12
    //     0x916d10: add             x12, fp, w2, sxtw #2
    //     0x916d14: ldr             x12, [x12, #8]
    //     0x916d18: add             w2, w11, #2
    //     0x916d1c: sbfx            x11, x2, #1, #0x1f
    //     0x916d20: mov             x2, x11
    //     0x916d24: mov             x11, x12
    //     0x916d28: b               #0x916d30
    //     0x916d2c: mov             x11, NULL
    //     0x916d30: stur            x11, [fp, #-0x68]
    //     0x916d34: lsl             x12, x2, #1
    //     0x916d38: lsl             w13, w12, #1
    //     0x916d3c: add             w14, w13, #8
    //     0x916d40: add             x16, x0, w14, sxtw #1
    //     0x916d44: ldur            w19, [x16, #0xf]
    //     0x916d48: add             x19, x19, HEAP, lsl #32
    //     0x916d4c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26880] "enabledMouseCursor"
    //     0x916d50: ldr             x16, [x16, #0x880]
    //     0x916d54: cmp             w19, w16
    //     0x916d58: b.ne            #0x916d8c
    //     0x916d5c: add             w2, w13, #0xa
    //     0x916d60: add             x16, x0, w2, sxtw #1
    //     0x916d64: ldur            w13, [x16, #0xf]
    //     0x916d68: add             x13, x13, HEAP, lsl #32
    //     0x916d6c: sub             w2, w1, w13
    //     0x916d70: add             x13, fp, w2, sxtw #2
    //     0x916d74: ldr             x13, [x13, #8]
    //     0x916d78: add             w2, w12, #2
    //     0x916d7c: sbfx            x12, x2, #1, #0x1f
    //     0x916d80: mov             x2, x12
    //     0x916d84: mov             x12, x13
    //     0x916d88: b               #0x916d90
    //     0x916d8c: mov             x12, NULL
    //     0x916d90: stur            x12, [fp, #-0x60]
    //     0x916d94: lsl             x13, x2, #1
    //     0x916d98: lsl             w14, w13, #1
    //     0x916d9c: add             w19, w14, #8
    //     0x916da0: add             x16, x0, w19, sxtw #1
    //     0x916da4: ldur            w20, [x16, #0xf]
    //     0x916da8: add             x20, x20, HEAP, lsl #32
    //     0x916dac: add             x16, PP, #0x26, lsl #12  ; [pp+0x26888] "foregroundColor"
    //     0x916db0: ldr             x16, [x16, #0x888]
    //     0x916db4: cmp             w20, w16
    //     0x916db8: b.ne            #0x916dec
    //     0x916dbc: add             w2, w14, #0xa
    //     0x916dc0: add             x16, x0, w2, sxtw #1
    //     0x916dc4: ldur            w14, [x16, #0xf]
    //     0x916dc8: add             x14, x14, HEAP, lsl #32
    //     0x916dcc: sub             w2, w1, w14
    //     0x916dd0: add             x14, fp, w2, sxtw #2
    //     0x916dd4: ldr             x14, [x14, #8]
    //     0x916dd8: add             w2, w13, #2
    //     0x916ddc: sbfx            x13, x2, #1, #0x1f
    //     0x916de0: mov             x2, x13
    //     0x916de4: mov             x13, x14
    //     0x916de8: b               #0x916df0
    //     0x916dec: mov             x13, NULL
    //     0x916df0: stur            x13, [fp, #-0x58]
    //     0x916df4: lsl             x14, x2, #1
    //     0x916df8: lsl             w19, w14, #1
    //     0x916dfc: add             w20, w19, #8
    //     0x916e00: add             x16, x0, w20, sxtw #1
    //     0x916e04: ldur            w23, [x16, #0xf]
    //     0x916e08: add             x23, x23, HEAP, lsl #32
    //     0x916e0c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26890] "maximumSize"
    //     0x916e10: ldr             x16, [x16, #0x890]
    //     0x916e14: cmp             w23, w16
    //     0x916e18: b.ne            #0x916e4c
    //     0x916e1c: add             w2, w19, #0xa
    //     0x916e20: add             x16, x0, w2, sxtw #1
    //     0x916e24: ldur            w19, [x16, #0xf]
    //     0x916e28: add             x19, x19, HEAP, lsl #32
    //     0x916e2c: sub             w2, w1, w19
    //     0x916e30: add             x19, fp, w2, sxtw #2
    //     0x916e34: ldr             x19, [x19, #8]
    //     0x916e38: add             w2, w14, #2
    //     0x916e3c: sbfx            x14, x2, #1, #0x1f
    //     0x916e40: mov             x2, x14
    //     0x916e44: mov             x14, x19
    //     0x916e48: b               #0x916e50
    //     0x916e4c: mov             x14, NULL
    //     0x916e50: stur            x14, [fp, #-0x50]
    //     0x916e54: lsl             x19, x2, #1
    //     0x916e58: lsl             w20, w19, #1
    //     0x916e5c: add             w23, w20, #8
    //     0x916e60: add             x16, x0, w23, sxtw #1
    //     0x916e64: ldur            w24, [x16, #0xf]
    //     0x916e68: add             x24, x24, HEAP, lsl #32
    //     0x916e6c: add             x16, PP, #0x26, lsl #12  ; [pp+0x26898] "minimumSize"
    //     0x916e70: ldr             x16, [x16, #0x898]
    //     0x916e74: cmp             w24, w16
    //     0x916e78: b.ne            #0x916eac
    //     0x916e7c: add             w2, w20, #0xa
    //     0x916e80: add             x16, x0, w2, sxtw #1
    //     0x916e84: ldur            w20, [x16, #0xf]
    //     0x916e88: add             x20, x20, HEAP, lsl #32
    //     0x916e8c: sub             w2, w1, w20
    //     0x916e90: add             x20, fp, w2, sxtw #2
    //     0x916e94: ldr             x20, [x20, #8]
    //     0x916e98: add             w2, w19, #2
    //     0x916e9c: sbfx            x19, x2, #1, #0x1f
    //     0x916ea0: mov             x2, x19
    //     0x916ea4: mov             x19, x20
    //     0x916ea8: b               #0x916eb0
    //     0x916eac: mov             x19, NULL
    //     0x916eb0: stur            x19, [fp, #-0x48]
    //     0x916eb4: lsl             x20, x2, #1
    //     0x916eb8: lsl             w23, w20, #1
    //     0x916ebc: add             w24, w23, #8
    //     0x916ec0: add             x16, x0, w24, sxtw #1
    //     0x916ec4: ldur            w25, [x16, #0xf]
    //     0x916ec8: add             x25, x25, HEAP, lsl #32
    //     0x916ecc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb18] "padding"
    //     0x916ed0: ldr             x16, [x16, #0xb18]
    //     0x916ed4: cmp             w25, w16
    //     0x916ed8: b.ne            #0x916f0c
    //     0x916edc: add             w2, w23, #0xa
    //     0x916ee0: add             x16, x0, w2, sxtw #1
    //     0x916ee4: ldur            w23, [x16, #0xf]
    //     0x916ee8: add             x23, x23, HEAP, lsl #32
    //     0x916eec: sub             w2, w1, w23
    //     0x916ef0: add             x23, fp, w2, sxtw #2
    //     0x916ef4: ldr             x23, [x23, #8]
    //     0x916ef8: add             w2, w20, #2
    //     0x916efc: sbfx            x20, x2, #1, #0x1f
    //     0x916f00: mov             x2, x20
    //     0x916f04: mov             x20, x23
    //     0x916f08: b               #0x916f10
    //     0x916f0c: mov             x20, NULL
    //     0x916f10: stur            x20, [fp, #-0x40]
    //     0x916f14: lsl             x23, x2, #1
    //     0x916f18: lsl             w24, w23, #1
    //     0x916f1c: add             w25, w24, #8
    //     0x916f20: add             x16, x0, w25, sxtw #1
    //     0x916f24: ldur            w4, [x16, #0xf]
    //     0x916f28: add             x4, x4, HEAP, lsl #32
    //     0x916f2c: add             x16, PP, #0xc, lsl #12  ; [pp+0xce60] "shadowColor"
    //     0x916f30: ldr             x16, [x16, #0xe60]
    //     0x916f34: cmp             w4, w16
    //     0x916f38: b.ne            #0x916f68
    //     0x916f3c: add             w2, w24, #0xa
    //     0x916f40: add             x16, x0, w2, sxtw #1
    //     0x916f44: ldur            w4, [x16, #0xf]
    //     0x916f48: add             x4, x4, HEAP, lsl #32
    //     0x916f4c: sub             w2, w1, w4
    //     0x916f50: add             x4, fp, w2, sxtw #2
    //     0x916f54: ldr             x4, [x4, #8]
    //     0x916f58: add             w2, w23, #2
    //     0x916f5c: sbfx            x23, x2, #1, #0x1f
    //     0x916f60: mov             x2, x23
    //     0x916f64: b               #0x916f6c
    //     0x916f68: mov             x4, NULL
    //     0x916f6c: stur            x4, [fp, #-0x10]
    //     0x916f70: lsl             x23, x2, #1
    //     0x916f74: lsl             w24, w23, #1
    //     0x916f78: add             w25, w24, #8
    //     0x916f7c: add             x16, x0, w25, sxtw #1
    //     0x916f80: ldur            w4, [x16, #0xf]
    //     0x916f84: add             x4, x4, HEAP, lsl #32
    //     0x916f88: add             x16, PP, #0xc, lsl #12  ; [pp+0xce80] "splashFactory"
    //     0x916f8c: ldr             x16, [x16, #0xe80]
    //     0x916f90: cmp             w4, w16
    //     0x916f94: b.ne            #0x916fc4
    //     0x916f98: add             w2, w24, #0xa
    //     0x916f9c: add             x16, x0, w2, sxtw #1
    //     0x916fa0: ldur            w4, [x16, #0xf]
    //     0x916fa4: add             x4, x4, HEAP, lsl #32
    //     0x916fa8: sub             w2, w1, w4
    //     0x916fac: add             x4, fp, w2, sxtw #2
    //     0x916fb0: ldr             x4, [x4, #8]
    //     0x916fb4: add             w2, w23, #2
    //     0x916fb8: sbfx            x23, x2, #1, #0x1f
    //     0x916fbc: mov             x2, x23
    //     0x916fc0: b               #0x916fc8
    //     0x916fc4: mov             x4, NULL
    //     0x916fc8: stur            x4, [fp, #-0x18]
    //     0x916fcc: lsl             x23, x2, #1
    //     0x916fd0: lsl             w24, w23, #1
    //     0x916fd4: add             w25, w24, #8
    //     0x916fd8: add             x16, x0, w25, sxtw #1
    //     0x916fdc: ldur            w4, [x16, #0xf]
    //     0x916fe0: add             x4, x4, HEAP, lsl #32
    //     0x916fe4: add             x16, PP, #0x26, lsl #12  ; [pp+0x268a0] "tapTargetSize"
    //     0x916fe8: ldr             x16, [x16, #0x8a0]
    //     0x916fec: cmp             w4, w16
    //     0x916ff0: b.ne            #0x917020
    //     0x916ff4: add             w2, w24, #0xa
    //     0x916ff8: add             x16, x0, w2, sxtw #1
    //     0x916ffc: ldur            w4, [x16, #0xf]
    //     0x917000: add             x4, x4, HEAP, lsl #32
    //     0x917004: sub             w2, w1, w4
    //     0x917008: add             x4, fp, w2, sxtw #2
    //     0x91700c: ldr             x4, [x4, #8]
    //     0x917010: add             w2, w23, #2
    //     0x917014: sbfx            x23, x2, #1, #0x1f
    //     0x917018: mov             x2, x23
    //     0x91701c: b               #0x917024
    //     0x917020: mov             x4, NULL
    //     0x917024: stur            x4, [fp, #-0x20]
    //     0x917028: lsl             x23, x2, #1
    //     0x91702c: lsl             w24, w23, #1
    //     0x917030: add             w25, w24, #8
    //     0x917034: add             x16, x0, w25, sxtw #1
    //     0x917038: ldur            w4, [x16, #0xf]
    //     0x91703c: add             x4, x4, HEAP, lsl #32
    //     0x917040: add             x16, PP, #0x26, lsl #12  ; [pp+0x268a8] "textStyle"
    //     0x917044: ldr             x16, [x16, #0x8a8]
    //     0x917048: cmp             w4, w16
    //     0x91704c: b.ne            #0x91707c
    //     0x917050: add             w2, w24, #0xa
    //     0x917054: add             x16, x0, w2, sxtw #1
    //     0x917058: ldur            w4, [x16, #0xf]
    //     0x91705c: add             x4, x4, HEAP, lsl #32
    //     0x917060: sub             w2, w1, w4
    //     0x917064: add             x4, fp, w2, sxtw #2
    //     0x917068: ldr             x4, [x4, #8]
    //     0x91706c: add             w2, w23, #2
    //     0x917070: sbfx            x23, x2, #1, #0x1f
    //     0x917074: mov             x2, x23
    //     0x917078: b               #0x917080
    //     0x91707c: mov             x4, NULL
    //     0x917080: stur            x4, [fp, #-0x38]
    //     0x917084: lsl             x23, x2, #1
    //     0x917088: lsl             w2, w23, #1
    //     0x91708c: add             w23, w2, #8
    //     0x917090: add             x16, x0, w23, sxtw #1
    //     0x917094: ldur            w24, [x16, #0xf]
    //     0x917098: add             x24, x24, HEAP, lsl #32
    //     0x91709c: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b0] "visualDensity"
    //     0x9170a0: ldr             x16, [x16, #0x8b0]
    //     0x9170a4: cmp             w24, w16
    //     0x9170a8: b.ne            #0x9170d0
    //     0x9170ac: add             w23, w2, #0xa
    //     0x9170b0: add             x16, x0, w23, sxtw #1
    //     0x9170b4: ldur            w2, [x16, #0xf]
    //     0x9170b8: add             x2, x2, HEAP, lsl #32
    //     0x9170bc: sub             w0, w1, w2
    //     0x9170c0: add             x1, fp, w0, sxtw #2
    //     0x9170c4: ldr             x1, [x1, #8]
    //     0x9170c8: mov             x0, x1
    //     0x9170cc: b               #0x9170d4
    //     0x9170d0: mov             x0, NULL
    //     0x9170d4: stur            x0, [fp, #-0x30]
    // 0x9170d8: CheckStackOverflow
    //     0x9170d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9170dc: cmp             SP, x16
    //     0x9170e0: b.ls            #0x9173e8
    // 0x9170e4: cmp             w7, NULL
    // 0x9170e8: b.ne            #0x9170f4
    // 0x9170ec: r2 = Null
    //     0x9170ec: mov             x2, NULL
    // 0x9170f0: b               #0x9170f8
    // 0x9170f4: mov             x2, x7
    // 0x9170f8: stur            x2, [fp, #-0x28]
    // 0x9170fc: cmp             w3, NULL
    // 0x917100: b.ne            #0x917118
    // 0x917104: cmp             w2, NULL
    // 0x917108: b.ne            #0x917118
    // 0x91710c: mov             x0, x13
    // 0x917110: r2 = Null
    //     0x917110: mov             x2, NULL
    // 0x917114: b               #0x917140
    // 0x917118: r1 = <Color?>
    //     0x917118: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x91711c: ldr             x1, [x1, #0xf68]
    // 0x917120: r0 = _ElevatedButtonDefaultColor()
    //     0x917120: bl              #0x917480  ; Allocate_ElevatedButtonDefaultColorStub -> _ElevatedButtonDefaultColor (size=0x14)
    // 0x917124: mov             x1, x0
    // 0x917128: ldur            x0, [fp, #-0x98]
    // 0x91712c: StoreField: r1->field_b = r0
    //     0x91712c: stur            w0, [x1, #0xb]
    // 0x917130: ldur            x0, [fp, #-0x28]
    // 0x917134: StoreField: r1->field_f = r0
    //     0x917134: stur            w0, [x1, #0xf]
    // 0x917138: mov             x2, x1
    // 0x91713c: ldur            x0, [fp, #-0x58]
    // 0x917140: stur            x2, [fp, #-0x98]
    // 0x917144: cmp             w0, NULL
    // 0x917148: b.ne            #0x917154
    // 0x91714c: r3 = Null
    //     0x91714c: mov             x3, NULL
    // 0x917150: b               #0x917158
    // 0x917154: mov             x3, x0
    // 0x917158: ldur            x0, [fp, #-0x80]
    // 0x91715c: stur            x3, [fp, #-0x58]
    // 0x917160: cmp             w0, NULL
    // 0x917164: b.ne            #0x91716c
    // 0x917168: r0 = Null
    //     0x917168: mov             x0, NULL
    // 0x91716c: stur            x0, [fp, #-0x28]
    // 0x917170: cmp             w3, NULL
    // 0x917174: b.ne            #0x91718c
    // 0x917178: cmp             w0, NULL
    // 0x91717c: b.ne            #0x91718c
    // 0x917180: mov             x0, x3
    // 0x917184: r2 = Null
    //     0x917184: mov             x2, NULL
    // 0x917188: b               #0x9171b0
    // 0x91718c: r1 = <Color?>
    //     0x91718c: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x917190: ldr             x1, [x1, #0xf68]
    // 0x917194: r0 = _ElevatedButtonDefaultColor()
    //     0x917194: bl              #0x917480  ; Allocate_ElevatedButtonDefaultColorStub -> _ElevatedButtonDefaultColor (size=0x14)
    // 0x917198: mov             x1, x0
    // 0x91719c: ldur            x0, [fp, #-0x58]
    // 0x9171a0: StoreField: r1->field_b = r0
    //     0x9171a0: stur            w0, [x1, #0xb]
    // 0x9171a4: ldur            x2, [fp, #-0x28]
    // 0x9171a8: StoreField: r1->field_f = r2
    //     0x9171a8: stur            w2, [x1, #0xf]
    // 0x9171ac: mov             x2, x1
    // 0x9171b0: stur            x2, [fp, #-0x28]
    // 0x9171b4: cmp             w0, NULL
    // 0x9171b8: b.ne            #0x9171c4
    // 0x9171bc: r2 = Null
    //     0x9171bc: mov             x2, NULL
    // 0x9171c0: b               #0x9171e0
    // 0x9171c4: r1 = <Color?>
    //     0x9171c4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x9171c8: ldr             x1, [x1, #0xf68]
    // 0x9171cc: r0 = _ElevatedButtonDefaultOverlay()
    //     0x9171cc: bl              #0x917474  ; Allocate_ElevatedButtonDefaultOverlayStub -> _ElevatedButtonDefaultOverlay (size=0x10)
    // 0x9171d0: mov             x1, x0
    // 0x9171d4: ldur            x0, [fp, #-0x58]
    // 0x9171d8: StoreField: r1->field_b = r0
    //     0x9171d8: stur            w0, [x1, #0xb]
    // 0x9171dc: mov             x2, x1
    // 0x9171e0: ldur            x0, [fp, #-0x70]
    // 0x9171e4: stur            x2, [fp, #-0x58]
    // 0x9171e8: cmp             w0, NULL
    // 0x9171ec: b.ne            #0x9171f8
    // 0x9171f0: r2 = Null
    //     0x9171f0: mov             x2, NULL
    // 0x9171f4: b               #0x917214
    // 0x9171f8: LoadField: d0 = r0->field_7
    //     0x9171f8: ldur            d0, [x0, #7]
    // 0x9171fc: stur            d0, [fp, #-0xa0]
    // 0x917200: r1 = <double>
    //     0x917200: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x917204: r0 = _ElevatedButtonDefaultElevation()
    //     0x917204: bl              #0x917468  ; Allocate_ElevatedButtonDefaultElevationStub -> _ElevatedButtonDefaultElevation (size=0x14)
    // 0x917208: ldur            d0, [fp, #-0xa0]
    // 0x91720c: StoreField: r0->field_b = d0
    //     0x91720c: stur            d0, [x0, #0xb]
    // 0x917210: mov             x2, x0
    // 0x917214: ldur            x0, [fp, #-0x60]
    // 0x917218: stur            x2, [fp, #-0x70]
    // 0x91721c: cmp             w0, NULL
    // 0x917220: b.ne            #0x91723c
    // 0x917224: ldur            x3, [fp, #-0x78]
    // 0x917228: cmp             w3, NULL
    // 0x91722c: b.ne            #0x917240
    // 0x917230: mov             x0, x2
    // 0x917234: r12 = Null
    //     0x917234: mov             x12, NULL
    // 0x917238: b               #0x917268
    // 0x91723c: ldur            x3, [fp, #-0x78]
    // 0x917240: r1 = <MouseCursor?>
    //     0x917240: add             x1, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0x917244: ldr             x1, [x1, #0x8b8]
    // 0x917248: r0 = _ElevatedButtonDefaultMouseCursor()
    //     0x917248: bl              #0x91745c  ; Allocate_ElevatedButtonDefaultMouseCursorStub -> _ElevatedButtonDefaultMouseCursor (size=0x14)
    // 0x91724c: mov             x1, x0
    // 0x917250: ldur            x0, [fp, #-0x60]
    // 0x917254: StoreField: r1->field_b = r0
    //     0x917254: stur            w0, [x1, #0xb]
    // 0x917258: ldur            x0, [fp, #-0x78]
    // 0x91725c: StoreField: r1->field_f = r0
    //     0x91725c: stur            w0, [x1, #0xf]
    // 0x917260: mov             x12, x1
    // 0x917264: ldur            x0, [fp, #-0x70]
    // 0x917268: ldur            x5, [fp, #-0x90]
    // 0x91726c: ldur            x6, [fp, #-0x88]
    // 0x917270: ldur            x7, [fp, #-0x68]
    // 0x917274: ldur            x8, [fp, #-0x18]
    // 0x917278: ldur            x9, [fp, #-0x20]
    // 0x91727c: ldur            x10, [fp, #-0x38]
    // 0x917280: ldur            x11, [fp, #-0x30]
    // 0x917284: ldur            x4, [fp, #-0x98]
    // 0x917288: ldur            x3, [fp, #-0x28]
    // 0x91728c: ldur            x2, [fp, #-0x58]
    // 0x917290: stur            x12, [fp, #-0x60]
    // 0x917294: r1 = <TextStyle?>
    //     0x917294: add             x1, PP, #0x26, lsl #12  ; [pp+0x268c0] TypeArguments: <TextStyle?>
    //     0x917298: ldr             x1, [x1, #0x8c0]
    // 0x91729c: r0 = MaterialStatePropertyAll()
    //     0x91729c: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0x9172a0: mov             x1, x0
    // 0x9172a4: ldur            x0, [fp, #-0x38]
    // 0x9172a8: stur            x1, [fp, #-0x78]
    // 0x9172ac: StoreField: r1->field_b = r0
    //     0x9172ac: stur            w0, [x1, #0xb]
    // 0x9172b0: r16 = <Color>
    //     0x9172b0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0x9172b4: ldr             x16, [x16, #0x3f8]
    // 0x9172b8: ldur            lr, [fp, #-0x10]
    // 0x9172bc: stp             lr, x16, [SP, #-0x10]!
    // 0x9172c0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9172c0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9172c4: r0 = allOrNull()
    //     0x9172c4: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x9172c8: add             SP, SP, #0x10
    // 0x9172cc: stur            x0, [fp, #-0x10]
    // 0x9172d0: r16 = <EdgeInsetsGeometry>
    //     0x9172d0: add             x16, PP, #0x26, lsl #12  ; [pp+0x268c8] TypeArguments: <EdgeInsetsGeometry>
    //     0x9172d4: ldr             x16, [x16, #0x8c8]
    // 0x9172d8: ldur            lr, [fp, #-0x40]
    // 0x9172dc: stp             lr, x16, [SP, #-0x10]!
    // 0x9172e0: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9172e0: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9172e4: r0 = allOrNull()
    //     0x9172e4: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x9172e8: add             SP, SP, #0x10
    // 0x9172ec: stur            x0, [fp, #-0x38]
    // 0x9172f0: r16 = <Size>
    //     0x9172f0: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0x9172f4: ldr             x16, [x16, #0x8d0]
    // 0x9172f8: ldur            lr, [fp, #-0x48]
    // 0x9172fc: stp             lr, x16, [SP, #-0x10]!
    // 0x917300: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x917300: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x917304: r0 = allOrNull()
    //     0x917304: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x917308: add             SP, SP, #0x10
    // 0x91730c: stur            x0, [fp, #-0x40]
    // 0x917310: r16 = <Size>
    //     0x917310: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0x917314: ldr             x16, [x16, #0x8d0]
    // 0x917318: ldur            lr, [fp, #-0x50]
    // 0x91731c: stp             lr, x16, [SP, #-0x10]!
    // 0x917320: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x917320: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x917324: r0 = allOrNull()
    //     0x917324: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x917328: add             SP, SP, #0x10
    // 0x91732c: stur            x0, [fp, #-0x48]
    // 0x917330: r16 = <OutlinedBorder>
    //     0x917330: add             x16, PP, #0x26, lsl #12  ; [pp+0x268d8] TypeArguments: <OutlinedBorder>
    //     0x917334: ldr             x16, [x16, #0x8d8]
    // 0x917338: ldur            lr, [fp, #-8]
    // 0x91733c: stp             lr, x16, [SP, #-0x10]!
    // 0x917340: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x917340: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x917344: r0 = allOrNull()
    //     0x917344: bl              #0x9173fc  ; [package:flutter/src/material/button_style_button.dart] ButtonStyleButton::allOrNull
    // 0x917348: add             SP, SP, #0x10
    // 0x91734c: stur            x0, [fp, #-8]
    // 0x917350: r0 = ButtonStyle()
    //     0x917350: bl              #0x9173f0  ; AllocateButtonStyleStub -> ButtonStyle (size=0x60)
    // 0x917354: ldur            x1, [fp, #-0x78]
    // 0x917358: StoreField: r0->field_7 = r1
    //     0x917358: stur            w1, [x0, #7]
    // 0x91735c: ldur            x1, [fp, #-0x98]
    // 0x917360: StoreField: r0->field_b = r1
    //     0x917360: stur            w1, [x0, #0xb]
    // 0x917364: ldur            x1, [fp, #-0x28]
    // 0x917368: StoreField: r0->field_f = r1
    //     0x917368: stur            w1, [x0, #0xf]
    // 0x91736c: ldur            x1, [fp, #-0x58]
    // 0x917370: StoreField: r0->field_13 = r1
    //     0x917370: stur            w1, [x0, #0x13]
    // 0x917374: ldur            x1, [fp, #-0x10]
    // 0x917378: StoreField: r0->field_17 = r1
    //     0x917378: stur            w1, [x0, #0x17]
    // 0x91737c: ldur            x1, [fp, #-0x70]
    // 0x917380: StoreField: r0->field_1f = r1
    //     0x917380: stur            w1, [x0, #0x1f]
    // 0x917384: ldur            x1, [fp, #-0x38]
    // 0x917388: StoreField: r0->field_23 = r1
    //     0x917388: stur            w1, [x0, #0x23]
    // 0x91738c: ldur            x1, [fp, #-0x40]
    // 0x917390: StoreField: r0->field_27 = r1
    //     0x917390: stur            w1, [x0, #0x27]
    // 0x917394: ldur            x1, [fp, #-0x48]
    // 0x917398: StoreField: r0->field_2f = r1
    //     0x917398: stur            w1, [x0, #0x2f]
    // 0x91739c: ldur            x1, [fp, #-8]
    // 0x9173a0: StoreField: r0->field_3f = r1
    //     0x9173a0: stur            w1, [x0, #0x3f]
    // 0x9173a4: ldur            x1, [fp, #-0x60]
    // 0x9173a8: StoreField: r0->field_43 = r1
    //     0x9173a8: stur            w1, [x0, #0x43]
    // 0x9173ac: ldur            x1, [fp, #-0x30]
    // 0x9173b0: StoreField: r0->field_47 = r1
    //     0x9173b0: stur            w1, [x0, #0x47]
    // 0x9173b4: ldur            x1, [fp, #-0x20]
    // 0x9173b8: StoreField: r0->field_4b = r1
    //     0x9173b8: stur            w1, [x0, #0x4b]
    // 0x9173bc: ldur            x1, [fp, #-0x88]
    // 0x9173c0: StoreField: r0->field_4f = r1
    //     0x9173c0: stur            w1, [x0, #0x4f]
    // 0x9173c4: ldur            x1, [fp, #-0x68]
    // 0x9173c8: StoreField: r0->field_53 = r1
    //     0x9173c8: stur            w1, [x0, #0x53]
    // 0x9173cc: ldur            x1, [fp, #-0x90]
    // 0x9173d0: StoreField: r0->field_57 = r1
    //     0x9173d0: stur            w1, [x0, #0x57]
    // 0x9173d4: ldur            x1, [fp, #-0x18]
    // 0x9173d8: StoreField: r0->field_5b = r1
    //     0x9173d8: stur            w1, [x0, #0x5b]
    // 0x9173dc: LeaveFrame
    //     0x9173dc: mov             SP, fp
    //     0x9173e0: ldp             fp, lr, [SP], #0x10
    // 0x9173e4: ret
    //     0x9173e4: ret             
    // 0x9173e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9173e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9173ec: b               #0x9170e4
  }
  _ themeStyleOf(/* No info */) {
    // ** addr: 0xc12184, size: 0x44
    // 0xc12184: EnterFrame
    //     0xc12184: stp             fp, lr, [SP, #-0x10]!
    //     0xc12188: mov             fp, SP
    // 0xc1218c: CheckStackOverflow
    //     0xc1218c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc12190: cmp             SP, x16
    //     0xc12194: b.ls            #0xc121c0
    // 0xc12198: ldr             x16, [fp, #0x10]
    // 0xc1219c: SaveReg r16
    //     0xc1219c: str             x16, [SP, #-8]!
    // 0xc121a0: r0 = of()
    //     0xc121a0: bl              #0xc121c8  ; [package:flutter/src/material/elevated_button_theme.dart] ElevatedButtonTheme::of
    // 0xc121a4: add             SP, SP, #8
    // 0xc121a8: LoadField: r1 = r0->field_7
    //     0xc121a8: ldur            w1, [x0, #7]
    // 0xc121ac: DecompressPointer r1
    //     0xc121ac: add             x1, x1, HEAP, lsl #32
    // 0xc121b0: mov             x0, x1
    // 0xc121b4: LeaveFrame
    //     0xc121b4: mov             SP, fp
    //     0xc121b8: ldp             fp, lr, [SP], #0x10
    // 0xc121bc: ret
    //     0xc121bc: ret             
    // 0xc121c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc121c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc121c4: b               #0xc12198
  }
  _ defaultStyleOf(/* No info */) {
    // ** addr: 0xc1494c, size: 0x200
    // 0xc1494c: EnterFrame
    //     0xc1494c: stp             fp, lr, [SP, #-0x10]!
    //     0xc14950: mov             fp, SP
    // 0xc14954: AllocStack(0x38)
    //     0xc14954: sub             SP, SP, #0x38
    // 0xc14958: CheckStackOverflow
    //     0xc14958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc1495c: cmp             SP, x16
    //     0xc14960: b.ls            #0xc14b44
    // 0xc14964: ldr             x16, [fp, #0x10]
    // 0xc14968: SaveReg r16
    //     0xc14968: str             x16, [SP, #-8]!
    // 0xc1496c: r0 = of()
    //     0xc1496c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc14970: add             SP, SP, #8
    // 0xc14974: stur            x0, [fp, #-0x10]
    // 0xc14978: LoadField: r1 = r0->field_3f
    //     0xc14978: ldur            w1, [x0, #0x3f]
    // 0xc1497c: DecompressPointer r1
    //     0xc1497c: add             x1, x1, HEAP, lsl #32
    // 0xc14980: stur            x1, [fp, #-8]
    // 0xc14984: ldr             x16, [fp, #0x10]
    // 0xc14988: SaveReg r16
    //     0xc14988: str             x16, [SP, #-8]!
    // 0xc1498c: r0 = of()
    //     0xc1498c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc14990: add             SP, SP, #8
    // 0xc14994: LoadField: r1 = r0->field_2b
    //     0xc14994: ldur            w1, [x0, #0x2b]
    // 0xc14998: DecompressPointer r1
    //     0xc14998: add             x1, x1, HEAP, lsl #32
    // 0xc1499c: tbnz            w1, #4, #0xc149e4
    // 0xc149a0: ldr             x0, [fp, #0x10]
    // 0xc149a4: r0 = _ElevatedButtonDefaultsM3()
    //     0xc149a4: bl              #0xc14d54  ; Allocate_ElevatedButtonDefaultsM3Stub -> _ElevatedButtonDefaultsM3 (size=0x68)
    // 0xc149a8: mov             x1, x0
    // 0xc149ac: r0 = Sentinel
    //     0xc149ac: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xc149b0: StoreField: r1->field_63 = r0
    //     0xc149b0: stur            w0, [x1, #0x63]
    // 0xc149b4: ldr             x0, [fp, #0x10]
    // 0xc149b8: StoreField: r1->field_5f = r0
    //     0xc149b8: stur            w0, [x1, #0x5f]
    // 0xc149bc: r0 = Instance_Duration
    //     0xc149bc: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc149c0: ldr             x0, [x0, #0x9e0]
    // 0xc149c4: StoreField: r1->field_4f = r0
    //     0xc149c4: stur            w0, [x1, #0x4f]
    // 0xc149c8: r0 = true
    //     0xc149c8: add             x0, NULL, #0x20  ; true
    // 0xc149cc: StoreField: r1->field_53 = r0
    //     0xc149cc: stur            w0, [x1, #0x53]
    // 0xc149d0: r0 = Instance_Alignment
    //     0xc149d0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc149d4: ldr             x0, [x0, #0xc70]
    // 0xc149d8: StoreField: r1->field_57 = r0
    //     0xc149d8: stur            w0, [x1, #0x57]
    // 0xc149dc: mov             x0, x1
    // 0xc149e0: b               #0xc14b38
    // 0xc149e4: ldr             x0, [fp, #0x10]
    // 0xc149e8: ldur            x1, [fp, #-0x10]
    // 0xc149ec: ldur            x2, [fp, #-8]
    // 0xc149f0: d0 = 0.120000
    //     0xc149f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xc149f4: ldr             d0, [x17, #0xf48]
    // 0xc149f8: LoadField: r3 = r2->field_b
    //     0xc149f8: ldur            w3, [x2, #0xb]
    // 0xc149fc: DecompressPointer r3
    //     0xc149fc: add             x3, x3, HEAP, lsl #32
    // 0xc14a00: stur            x3, [fp, #-0x28]
    // 0xc14a04: LoadField: r4 = r2->field_f
    //     0xc14a04: ldur            w4, [x2, #0xf]
    // 0xc14a08: DecompressPointer r4
    //     0xc14a08: add             x4, x4, HEAP, lsl #32
    // 0xc14a0c: stur            x4, [fp, #-0x20]
    // 0xc14a10: LoadField: r5 = r2->field_57
    //     0xc14a10: ldur            w5, [x2, #0x57]
    // 0xc14a14: DecompressPointer r5
    //     0xc14a14: add             x5, x5, HEAP, lsl #32
    // 0xc14a18: stur            x5, [fp, #-0x18]
    // 0xc14a1c: SaveReg r5
    //     0xc14a1c: str             x5, [SP, #-8]!
    // 0xc14a20: SaveReg d0
    //     0xc14a20: str             d0, [SP, #-8]!
    // 0xc14a24: r0 = withOpacity()
    //     0xc14a24: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc14a28: add             SP, SP, #0x10
    // 0xc14a2c: stur            x0, [fp, #-8]
    // 0xc14a30: ldur            x16, [fp, #-0x18]
    // 0xc14a34: SaveReg r16
    //     0xc14a34: str             x16, [SP, #-8]!
    // 0xc14a38: d0 = 0.380000
    //     0xc14a38: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xc14a3c: ldr             d0, [x17, #0x140]
    // 0xc14a40: SaveReg d0
    //     0xc14a40: str             d0, [SP, #-8]!
    // 0xc14a44: r0 = withOpacity()
    //     0xc14a44: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xc14a48: add             SP, SP, #0x10
    // 0xc14a4c: mov             x1, x0
    // 0xc14a50: ldur            x0, [fp, #-0x10]
    // 0xc14a54: stur            x1, [fp, #-0x38]
    // 0xc14a58: LoadField: r2 = r0->field_7b
    //     0xc14a58: ldur            w2, [x0, #0x7b]
    // 0xc14a5c: DecompressPointer r2
    //     0xc14a5c: add             x2, x2, HEAP, lsl #32
    // 0xc14a60: stur            x2, [fp, #-0x30]
    // 0xc14a64: LoadField: r3 = r0->field_93
    //     0xc14a64: ldur            w3, [x0, #0x93]
    // 0xc14a68: DecompressPointer r3
    //     0xc14a68: add             x3, x3, HEAP, lsl #32
    // 0xc14a6c: LoadField: r4 = r3->field_37
    //     0xc14a6c: ldur            w4, [x3, #0x37]
    // 0xc14a70: DecompressPointer r4
    //     0xc14a70: add             x4, x4, HEAP, lsl #32
    // 0xc14a74: stur            x4, [fp, #-0x18]
    // 0xc14a78: ldr             x16, [fp, #0x10]
    // 0xc14a7c: SaveReg r16
    //     0xc14a7c: str             x16, [SP, #-8]!
    // 0xc14a80: r0 = _scaledPadding()
    //     0xc14a80: bl              #0xc14b4c  ; [package:flutter/src/material/elevated_button.dart] ::_scaledPadding
    // 0xc14a84: add             SP, SP, #8
    // 0xc14a88: mov             x1, x0
    // 0xc14a8c: ldur            x0, [fp, #-0x10]
    // 0xc14a90: LoadField: r2 = r0->field_2f
    //     0xc14a90: ldur            w2, [x0, #0x2f]
    // 0xc14a94: DecompressPointer r2
    //     0xc14a94: add             x2, x2, HEAP, lsl #32
    // 0xc14a98: LoadField: r3 = r0->field_17
    //     0xc14a98: ldur            w3, [x0, #0x17]
    // 0xc14a9c: DecompressPointer r3
    //     0xc14a9c: add             x3, x3, HEAP, lsl #32
    // 0xc14aa0: ldur            x16, [fp, #-0x28]
    // 0xc14aa4: r30 = Instance_RoundedRectangleBorder
    //     0xc14aa4: add             lr, PP, #0xe, lsl #12  ; [pp+0xe450] Obj!RoundedRectangleBorder@b383f1
    //     0xc14aa8: ldr             lr, [lr, #0x450]
    // 0xc14aac: stp             lr, x16, [SP, #-0x10]!
    // 0xc14ab0: ldur            x16, [fp, #-0x20]
    // 0xc14ab4: ldur            lr, [fp, #-8]
    // 0xc14ab8: stp             lr, x16, [SP, #-0x10]!
    // 0xc14abc: ldur            x16, [fp, #-0x38]
    // 0xc14ac0: ldur            lr, [fp, #-0x30]
    // 0xc14ac4: stp             lr, x16, [SP, #-0x10]!
    // 0xc14ac8: r16 = 2.000000
    //     0xc14ac8: add             x16, PP, #0x25, lsl #12  ; [pp+0x259a8] 2
    //     0xc14acc: ldr             x16, [x16, #0x9a8]
    // 0xc14ad0: ldur            lr, [fp, #-0x18]
    // 0xc14ad4: stp             lr, x16, [SP, #-0x10]!
    // 0xc14ad8: r16 = Instance_Size
    //     0xc14ad8: add             x16, PP, #0x37, lsl #12  ; [pp+0x376e8] Obj!Size@b5ee71
    //     0xc14adc: ldr             x16, [x16, #0x6e8]
    // 0xc14ae0: stp             x16, x1, [SP, #-0x10]!
    // 0xc14ae4: r16 = Instance_Size
    //     0xc14ae4: add             x16, PP, #0x37, lsl #12  ; [pp+0x376f0] Obj!Size@b5ee51
    //     0xc14ae8: ldr             x16, [x16, #0x6f0]
    // 0xc14aec: r30 = Instance_SystemMouseCursor
    //     0xc14aec: add             lr, PP, #0x25, lsl #12  ; [pp+0x25ea8] Obj!SystemMouseCursor@b489b1
    //     0xc14af0: ldr             lr, [lr, #0xea8]
    // 0xc14af4: stp             lr, x16, [SP, #-0x10]!
    // 0xc14af8: r16 = Instance_SystemMouseCursor
    //     0xc14af8: ldr             x16, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xc14afc: stp             x2, x16, [SP, #-0x10]!
    // 0xc14b00: r16 = Instance_Duration
    //     0xc14b00: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0xc14b04: ldr             x16, [x16, #0x9e0]
    // 0xc14b08: stp             x16, x3, [SP, #-0x10]!
    // 0xc14b0c: r16 = true
    //     0xc14b0c: add             x16, NULL, #0x20  ; true
    // 0xc14b10: r30 = Instance_Alignment
    //     0xc14b10: add             lr, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc14b14: ldr             lr, [lr, #0xc70]
    // 0xc14b18: stp             lr, x16, [SP, #-0x10]!
    // 0xc14b1c: r16 = Instance__InkRippleFactory
    //     0xc14b1c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf00] Obj!_InkRippleFactory@b38571
    //     0xc14b20: ldr             x16, [x16, #0xf00]
    // 0xc14b24: SaveReg r16
    //     0xc14b24: str             x16, [SP, #-8]!
    // 0xc14b28: r4 = const [0, 0x13, 0x13, 0x2, alignment, 0x11, animationDuration, 0xf, disabledBackgroundColor, 0x3, disabledForegroundColor, 0x4, disabledMouseCursor, 0xc, elevation, 0x6, enableFeedback, 0x10, enabledMouseCursor, 0xb, foregroundColor, 0x2, maximumSize, 0xa, minimumSize, 0x9, padding, 0x8, shadowColor, 0x5, splashFactory, 0x12, tapTargetSize, 0xe, textStyle, 0x7, visualDensity, 0xd, null]
    //     0xc14b28: add             x4, PP, #0x37, lsl #12  ; [pp+0x37910] List(39) [0, 0x13, 0x13, 0x2, "alignment", 0x11, "animationDuration", 0xf, "disabledBackgroundColor", 0x3, "disabledForegroundColor", 0x4, "disabledMouseCursor", 0xc, "elevation", 0x6, "enableFeedback", 0x10, "enabledMouseCursor", 0xb, "foregroundColor", 0x2, "maximumSize", 0xa, "minimumSize", 0x9, "padding", 0x8, "shadowColor", 0x5, "splashFactory", 0x12, "tapTargetSize", 0xe, "textStyle", 0x7, "visualDensity", 0xd, Null]
    //     0xc14b2c: ldr             x4, [x4, #0x910]
    // 0xc14b30: r0 = styleFrom()
    //     0xc14b30: bl              #0x916a80  ; [package:flutter/src/material/elevated_button.dart] ElevatedButton::styleFrom
    // 0xc14b34: add             SP, SP, #0x98
    // 0xc14b38: LeaveFrame
    //     0xc14b38: mov             SP, fp
    //     0xc14b3c: ldp             fp, lr, [SP], #0x10
    // 0xc14b40: ret
    //     0xc14b40: ret             
    // 0xc14b44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc14b44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc14b48: b               #0xc14964
  }
}

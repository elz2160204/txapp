// lib: , url: package:flutter/src/material/tooltip.dart

// class id: 1049338, size: 0x8
class :: {
}

// class id: 2245, size: 0x1c, field offset: 0xc
class _TooltipPositionDelegate extends SingleChildLayoutDelegate {

  _ shouldRelayout(/* No info */) {
    // ** addr: 0xb10254, size: 0xac
    // 0xb10254: EnterFrame
    //     0xb10254: stp             fp, lr, [SP, #-0x10]!
    //     0xb10258: mov             fp, SP
    // 0xb1025c: CheckStackOverflow
    //     0xb1025c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb10260: cmp             SP, x16
    //     0xb10264: b.ls            #0xb102f8
    // 0xb10268: ldr             x0, [fp, #0x10]
    // 0xb1026c: r2 = Null
    //     0xb1026c: mov             x2, NULL
    // 0xb10270: r1 = Null
    //     0xb10270: mov             x1, NULL
    // 0xb10274: r4 = 59
    //     0xb10274: mov             x4, #0x3b
    // 0xb10278: branchIfSmi(r0, 0xb10284)
    //     0xb10278: tbz             w0, #0, #0xb10284
    // 0xb1027c: r4 = LoadClassIdInstr(r0)
    //     0xb1027c: ldur            x4, [x0, #-1]
    //     0xb10280: ubfx            x4, x4, #0xc, #0x14
    // 0xb10284: cmp             x4, #0x8c5
    // 0xb10288: b.eq            #0xb102a0
    // 0xb1028c: r8 = _TooltipPositionDelegate
    //     0xb1028c: add             x8, PP, #0x55, lsl #12  ; [pp+0x55740] Type: _TooltipPositionDelegate
    //     0xb10290: ldr             x8, [x8, #0x740]
    // 0xb10294: r3 = Null
    //     0xb10294: add             x3, PP, #0x55, lsl #12  ; [pp+0x55748] Null
    //     0xb10298: ldr             x3, [x3, #0x748]
    // 0xb1029c: r0 = DefaultTypeTest()
    //     0xb1029c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xb102a0: ldr             x0, [fp, #0x18]
    // 0xb102a4: LoadField: r1 = r0->field_b
    //     0xb102a4: ldur            w1, [x0, #0xb]
    // 0xb102a8: DecompressPointer r1
    //     0xb102a8: add             x1, x1, HEAP, lsl #32
    // 0xb102ac: ldr             x2, [fp, #0x10]
    // 0xb102b0: LoadField: r3 = r2->field_b
    //     0xb102b0: ldur            w3, [x2, #0xb]
    // 0xb102b4: DecompressPointer r3
    //     0xb102b4: add             x3, x3, HEAP, lsl #32
    // 0xb102b8: stp             x3, x1, [SP, #-0x10]!
    // 0xb102bc: r0 = ==()
    //     0xb102bc: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0xb102c0: add             SP, SP, #0x10
    // 0xb102c4: tbnz            w0, #4, #0xb102e0
    // 0xb102c8: ldr             x1, [fp, #0x18]
    // 0xb102cc: ldr             x2, [fp, #0x10]
    // 0xb102d0: LoadField: d0 = r1->field_f
    //     0xb102d0: ldur            d0, [x1, #0xf]
    // 0xb102d4: LoadField: d1 = r2->field_f
    //     0xb102d4: ldur            d1, [x2, #0xf]
    // 0xb102d8: fcmp            d0, d1
    // 0xb102dc: b.eq            #0xb102e8
    // 0xb102e0: r0 = true
    //     0xb102e0: add             x0, NULL, #0x20  ; true
    // 0xb102e4: b               #0xb102ec
    // 0xb102e8: r0 = false
    //     0xb102e8: add             x0, NULL, #0x30  ; false
    // 0xb102ec: LeaveFrame
    //     0xb102ec: mov             SP, fp
    //     0xb102f0: ldp             fp, lr, [SP], #0x10
    // 0xb102f4: ret
    //     0xb102f4: ret             
    // 0xb102f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb102f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb102fc: b               #0xb10268
  }
  _ getPositionForChild(/* No info */) {
    // ** addr: 0xb10da8, size: 0x54
    // 0xb10da8: EnterFrame
    //     0xb10da8: stp             fp, lr, [SP, #-0x10]!
    //     0xb10dac: mov             fp, SP
    // 0xb10db0: CheckStackOverflow
    //     0xb10db0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb10db4: cmp             SP, x16
    //     0xb10db8: b.ls            #0xb10df4
    // 0xb10dbc: ldr             x0, [fp, #0x20]
    // 0xb10dc0: LoadField: r1 = r0->field_b
    //     0xb10dc0: ldur            w1, [x0, #0xb]
    // 0xb10dc4: DecompressPointer r1
    //     0xb10dc4: add             x1, x1, HEAP, lsl #32
    // 0xb10dc8: LoadField: d0 = r0->field_f
    //     0xb10dc8: ldur            d0, [x0, #0xf]
    // 0xb10dcc: ldr             x16, [fp, #0x10]
    // 0xb10dd0: ldr             lr, [fp, #0x18]
    // 0xb10dd4: stp             lr, x16, [SP, #-0x10]!
    // 0xb10dd8: SaveReg r1
    //     0xb10dd8: str             x1, [SP, #-8]!
    // 0xb10ddc: SaveReg d0
    //     0xb10ddc: str             d0, [SP, #-8]!
    // 0xb10de0: r0 = positionDependentBox()
    //     0xb10de0: bl              #0xb10dfc  ; [package:flutter/src/painting/geometry.dart] ::positionDependentBox
    // 0xb10de4: add             SP, SP, #0x20
    // 0xb10de8: LeaveFrame
    //     0xb10de8: mov             SP, fp
    //     0xb10dec: ldp             fp, lr, [SP], #0x10
    // 0xb10df0: ret
    //     0xb10df0: ret             
    // 0xb10df4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb10df4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb10df8: b               #0xb10dbc
  }
}

// class id: 3260, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _TooltipState&State&SingleTickerProviderStateMixin extends State<Tooltip>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x619250, size: 0x98
    // 0x619250: EnterFrame
    //     0x619250: stp             fp, lr, [SP, #-0x10]!
    //     0x619254: mov             fp, SP
    // 0x619258: CheckStackOverflow
    //     0x619258: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61925c: cmp             SP, x16
    //     0x619260: b.ls            #0x6192dc
    // 0x619264: r0 = Ticker()
    //     0x619264: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x619268: mov             x1, x0
    // 0x61926c: r0 = false
    //     0x61926c: add             x0, NULL, #0x30  ; false
    // 0x619270: StoreField: r1->field_b = r0
    //     0x619270: stur            w0, [x1, #0xb]
    // 0x619274: ldr             x0, [fp, #0x10]
    // 0x619278: StoreField: r1->field_13 = r0
    //     0x619278: stur            w0, [x1, #0x13]
    // 0x61927c: mov             x0, x1
    // 0x619280: ldr             x1, [fp, #0x18]
    // 0x619284: StoreField: r1->field_13 = r0
    //     0x619284: stur            w0, [x1, #0x13]
    //     0x619288: ldurb           w16, [x1, #-1]
    //     0x61928c: ldurb           w17, [x0, #-1]
    //     0x619290: and             x16, x17, x16, lsr #2
    //     0x619294: tst             x16, HEAP, lsr #32
    //     0x619298: b.eq            #0x6192a0
    //     0x61929c: bl              #0xd6826c
    // 0x6192a0: SaveReg r1
    //     0x6192a0: str             x1, [SP, #-8]!
    // 0x6192a4: r0 = _updateTickerModeNotifier()
    //     0x6192a4: bl              #0x61930c  ; [package:flutter/src/material/tooltip.dart] _TooltipState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x6192a8: add             SP, SP, #8
    // 0x6192ac: ldr             x16, [fp, #0x18]
    // 0x6192b0: SaveReg r16
    //     0x6192b0: str             x16, [SP, #-8]!
    // 0x6192b4: r0 = _updateTicker()
    //     0x6192b4: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x6192b8: add             SP, SP, #8
    // 0x6192bc: ldr             x1, [fp, #0x18]
    // 0x6192c0: LoadField: r0 = r1->field_13
    //     0x6192c0: ldur            w0, [x1, #0x13]
    // 0x6192c4: DecompressPointer r0
    //     0x6192c4: add             x0, x0, HEAP, lsl #32
    // 0x6192c8: cmp             w0, NULL
    // 0x6192cc: b.eq            #0x6192e4
    // 0x6192d0: LeaveFrame
    //     0x6192d0: mov             SP, fp
    //     0x6192d4: ldp             fp, lr, [SP], #0x10
    // 0x6192d8: ret
    //     0x6192d8: ret             
    // 0x6192dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6192dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6192e0: b               #0x619264
    // 0x6192e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6192e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x61930c, size: 0x11c
    // 0x61930c: EnterFrame
    //     0x61930c: stp             fp, lr, [SP, #-0x10]!
    //     0x619310: mov             fp, SP
    // 0x619314: AllocStack(0x10)
    //     0x619314: sub             SP, SP, #0x10
    // 0x619318: CheckStackOverflow
    //     0x619318: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61931c: cmp             SP, x16
    //     0x619320: b.ls            #0x61941c
    // 0x619324: ldr             x0, [fp, #0x10]
    // 0x619328: LoadField: r1 = r0->field_f
    //     0x619328: ldur            w1, [x0, #0xf]
    // 0x61932c: DecompressPointer r1
    //     0x61932c: add             x1, x1, HEAP, lsl #32
    // 0x619330: cmp             w1, NULL
    // 0x619334: b.eq            #0x619424
    // 0x619338: SaveReg r1
    //     0x619338: str             x1, [SP, #-8]!
    // 0x61933c: r0 = getNotifier()
    //     0x61933c: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x619340: add             SP, SP, #8
    // 0x619344: mov             x1, x0
    // 0x619348: ldr             x0, [fp, #0x10]
    // 0x61934c: stur            x1, [fp, #-0x10]
    // 0x619350: LoadField: r2 = r0->field_17
    //     0x619350: ldur            w2, [x0, #0x17]
    // 0x619354: DecompressPointer r2
    //     0x619354: add             x2, x2, HEAP, lsl #32
    // 0x619358: stur            x2, [fp, #-8]
    // 0x61935c: cmp             w1, w2
    // 0x619360: b.ne            #0x619374
    // 0x619364: r0 = Null
    //     0x619364: mov             x0, NULL
    // 0x619368: LeaveFrame
    //     0x619368: mov             SP, fp
    //     0x61936c: ldp             fp, lr, [SP], #0x10
    // 0x619370: ret
    //     0x619370: ret             
    // 0x619374: cmp             w2, NULL
    // 0x619378: b.eq            #0x6193b4
    // 0x61937c: r1 = 1
    //     0x61937c: mov             x1, #1
    // 0x619380: r0 = AllocateContext()
    //     0x619380: bl              #0xd68aa4  ; AllocateContextStub
    // 0x619384: mov             x1, x0
    // 0x619388: ldr             x0, [fp, #0x10]
    // 0x61938c: StoreField: r1->field_f = r0
    //     0x61938c: stur            w0, [x1, #0xf]
    // 0x619390: mov             x2, x1
    // 0x619394: r1 = Function '_updateTicker@156311458':.
    //     0x619394: add             x1, PP, #0x50, lsl #12  ; [pp+0x503c0] AnonymousClosure: (0x619428), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x619398: ldr             x1, [x1, #0x3c0]
    // 0x61939c: r0 = AllocateClosure()
    //     0x61939c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6193a0: ldur            x16, [fp, #-8]
    // 0x6193a4: stp             x0, x16, [SP, #-0x10]!
    // 0x6193a8: r0 = removeListener()
    //     0x6193a8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6193ac: add             SP, SP, #0x10
    // 0x6193b0: ldr             x0, [fp, #0x10]
    // 0x6193b4: r1 = 1
    //     0x6193b4: mov             x1, #1
    // 0x6193b8: r0 = AllocateContext()
    //     0x6193b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6193bc: mov             x1, x0
    // 0x6193c0: ldr             x0, [fp, #0x10]
    // 0x6193c4: StoreField: r1->field_f = r0
    //     0x6193c4: stur            w0, [x1, #0xf]
    // 0x6193c8: mov             x2, x1
    // 0x6193cc: r1 = Function '_updateTicker@156311458':.
    //     0x6193cc: add             x1, PP, #0x50, lsl #12  ; [pp+0x503c0] AnonymousClosure: (0x619428), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x6193d0: ldr             x1, [x1, #0x3c0]
    // 0x6193d4: r0 = AllocateClosure()
    //     0x6193d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6193d8: ldur            x16, [fp, #-0x10]
    // 0x6193dc: stp             x0, x16, [SP, #-0x10]!
    // 0x6193e0: r0 = addListener()
    //     0x6193e0: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x6193e4: add             SP, SP, #0x10
    // 0x6193e8: ldur            x0, [fp, #-0x10]
    // 0x6193ec: ldr             x1, [fp, #0x10]
    // 0x6193f0: StoreField: r1->field_17 = r0
    //     0x6193f0: stur            w0, [x1, #0x17]
    //     0x6193f4: ldurb           w16, [x1, #-1]
    //     0x6193f8: ldurb           w17, [x0, #-1]
    //     0x6193fc: and             x16, x17, x16, lsr #2
    //     0x619400: tst             x16, HEAP, lsr #32
    //     0x619404: b.eq            #0x61940c
    //     0x619408: bl              #0xd6826c
    // 0x61940c: r0 = Null
    //     0x61940c: mov             x0, NULL
    // 0x619410: LeaveFrame
    //     0x619410: mov             SP, fp
    //     0x619414: ldp             fp, lr, [SP], #0x10
    // 0x619418: ret
    //     0x619418: ret             
    // 0x61941c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61941c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x619420: b               #0x619324
    // 0x619424: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x619424: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x619428, size: 0x48
    // 0x619428: EnterFrame
    //     0x619428: stp             fp, lr, [SP, #-0x10]!
    //     0x61942c: mov             fp, SP
    // 0x619430: ldr             x0, [fp, #0x10]
    // 0x619434: LoadField: r1 = r0->field_17
    //     0x619434: ldur            w1, [x0, #0x17]
    // 0x619438: DecompressPointer r1
    //     0x619438: add             x1, x1, HEAP, lsl #32
    // 0x61943c: CheckStackOverflow
    //     0x61943c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x619440: cmp             SP, x16
    //     0x619444: b.ls            #0x619468
    // 0x619448: LoadField: r0 = r1->field_f
    //     0x619448: ldur            w0, [x1, #0xf]
    // 0x61944c: DecompressPointer r0
    //     0x61944c: add             x0, x0, HEAP, lsl #32
    // 0x619450: SaveReg r0
    //     0x619450: str             x0, [SP, #-8]!
    // 0x619454: r0 = _updateTicker()
    //     0x619454: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x619458: add             SP, SP, #8
    // 0x61945c: LeaveFrame
    //     0x61945c: mov             SP, fp
    //     0x619460: ldp             fp, lr, [SP], #0x10
    // 0x619464: ret
    //     0x619464: ret             
    // 0x619468: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x619468: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61946c: b               #0x619448
  }
  _ activate(/* No info */) {
    // ** addr: 0x81fb34, size: 0x4c
    // 0x81fb34: EnterFrame
    //     0x81fb34: stp             fp, lr, [SP, #-0x10]!
    //     0x81fb38: mov             fp, SP
    // 0x81fb3c: CheckStackOverflow
    //     0x81fb3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81fb40: cmp             SP, x16
    //     0x81fb44: b.ls            #0x81fb78
    // 0x81fb48: ldr             x16, [fp, #0x10]
    // 0x81fb4c: SaveReg r16
    //     0x81fb4c: str             x16, [SP, #-8]!
    // 0x81fb50: r0 = _updateTickerModeNotifier()
    //     0x81fb50: bl              #0x61930c  ; [package:flutter/src/material/tooltip.dart] _TooltipState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81fb54: add             SP, SP, #8
    // 0x81fb58: ldr             x16, [fp, #0x10]
    // 0x81fb5c: SaveReg r16
    //     0x81fb5c: str             x16, [SP, #-8]!
    // 0x81fb60: r0 = _updateTicker()
    //     0x81fb60: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81fb64: add             SP, SP, #8
    // 0x81fb68: r0 = Null
    //     0x81fb68: mov             x0, NULL
    // 0x81fb6c: LeaveFrame
    //     0x81fb6c: mov             SP, fp
    //     0x81fb70: ldp             fp, lr, [SP], #0x10
    // 0x81fb74: ret
    //     0x81fb74: ret             
    // 0x81fb78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81fb78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81fb7c: b               #0x81fb48
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa53514, size: 0x8c
    // 0xa53514: EnterFrame
    //     0xa53514: stp             fp, lr, [SP, #-0x10]!
    //     0xa53518: mov             fp, SP
    // 0xa5351c: AllocStack(0x8)
    //     0xa5351c: sub             SP, SP, #8
    // 0xa53520: CheckStackOverflow
    //     0xa53520: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa53524: cmp             SP, x16
    //     0xa53528: b.ls            #0xa53598
    // 0xa5352c: ldr             x0, [fp, #0x10]
    // 0xa53530: LoadField: r1 = r0->field_17
    //     0xa53530: ldur            w1, [x0, #0x17]
    // 0xa53534: DecompressPointer r1
    //     0xa53534: add             x1, x1, HEAP, lsl #32
    // 0xa53538: stur            x1, [fp, #-8]
    // 0xa5353c: cmp             w1, NULL
    // 0xa53540: b.ne            #0xa5354c
    // 0xa53544: mov             x1, x0
    // 0xa53548: b               #0xa53584
    // 0xa5354c: r1 = 1
    //     0xa5354c: mov             x1, #1
    // 0xa53550: r0 = AllocateContext()
    //     0xa53550: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa53554: mov             x1, x0
    // 0xa53558: ldr             x0, [fp, #0x10]
    // 0xa5355c: StoreField: r1->field_f = r0
    //     0xa5355c: stur            w0, [x1, #0xf]
    // 0xa53560: mov             x2, x1
    // 0xa53564: r1 = Function '_updateTicker@156311458':.
    //     0xa53564: add             x1, PP, #0x50, lsl #12  ; [pp+0x503c0] AnonymousClosure: (0x619428), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa53568: ldr             x1, [x1, #0x3c0]
    // 0xa5356c: r0 = AllocateClosure()
    //     0xa5356c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa53570: ldur            x16, [fp, #-8]
    // 0xa53574: stp             x0, x16, [SP, #-0x10]!
    // 0xa53578: r0 = removeListener()
    //     0xa53578: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa5357c: add             SP, SP, #0x10
    // 0xa53580: ldr             x1, [fp, #0x10]
    // 0xa53584: StoreField: r1->field_17 = rNULL
    //     0xa53584: stur            NULL, [x1, #0x17]
    // 0xa53588: r0 = Null
    //     0xa53588: mov             x0, NULL
    // 0xa5358c: LeaveFrame
    //     0xa5358c: mov             SP, fp
    //     0xa53590: ldp             fp, lr, [SP], #0x10
    // 0xa53594: ret
    //     0xa53594: ret             
    // 0xa53598: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53598: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5359c: b               #0xa5352c
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa535a0, size: 0x48
    // 0xa535a0: EnterFrame
    //     0xa535a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa535a4: mov             fp, SP
    // 0xa535a8: ldr             x0, [fp, #0x10]
    // 0xa535ac: LoadField: r1 = r0->field_17
    //     0xa535ac: ldur            w1, [x0, #0x17]
    // 0xa535b0: DecompressPointer r1
    //     0xa535b0: add             x1, x1, HEAP, lsl #32
    // 0xa535b4: CheckStackOverflow
    //     0xa535b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa535b8: cmp             SP, x16
    //     0xa535bc: b.ls            #0xa535e0
    // 0xa535c0: LoadField: r0 = r1->field_f
    //     0xa535c0: ldur            w0, [x1, #0xf]
    // 0xa535c4: DecompressPointer r0
    //     0xa535c4: add             x0, x0, HEAP, lsl #32
    // 0xa535c8: SaveReg r0
    //     0xa535c8: str             x0, [SP, #-8]!
    // 0xa535cc: r0 = dispose()
    //     0xa535cc: bl              #0xa53514  ; [package:flutter/src/material/tooltip.dart] _TooltipState&State&SingleTickerProviderStateMixin::dispose
    // 0xa535d0: add             SP, SP, #8
    // 0xa535d4: LeaveFrame
    //     0xa535d4: mov             SP, fp
    //     0xa535d8: ldp             fp, lr, [SP], #0x10
    // 0xa535dc: ret
    //     0xa535dc: ret             
    // 0xa535e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa535e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa535e4: b               #0xa535c0
  }
}

// class id: 3261, size: 0x78, field offset: 0x1c
class TooltipState extends _TooltipState&State&SingleTickerProviderStateMixin {

  static late final Set<TooltipState> _mouseIn; // offset: 0xe50
  late bool _isConcealed; // offset: 0x6c
  late bool _mouseIsConnected; // offset: 0x5c
  late AnimationController _controller; // offset: 0x40
  late bool _visible; // offset: 0x74
  late Duration _showDuration; // offset: 0x50
  late Duration _hoverShowDuration; // offset: 0x54
  late Duration _waitDuration; // offset: 0x58
  late double _height; // offset: 0x1c
  late EdgeInsetsGeometry _padding; // offset: 0x20
  late EdgeInsetsGeometry _margin; // offset: 0x24
  late Decoration _decoration; // offset: 0x28
  late TextStyle _textStyle; // offset: 0x2c
  late TextAlign _textAlign; // offset: 0x30
  late double _verticalOffset; // offset: 0x34
  late bool _preferBelow; // offset: 0x38
  late bool _forceRemoval; // offset: 0x70
  late bool _enableFeedback; // offset: 0x68
  late TooltipTriggerMode _triggerMode; // offset: 0x64

  _ deactivate(/* No info */) {
    // ** addr: 0x795c80, size: 0x70
    // 0x795c80: EnterFrame
    //     0x795c80: stp             fp, lr, [SP, #-0x10]!
    //     0x795c84: mov             fp, SP
    // 0x795c88: CheckStackOverflow
    //     0x795c88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795c8c: cmp             SP, x16
    //     0x795c90: b.ls            #0x795ce8
    // 0x795c94: ldr             x0, [fp, #0x10]
    // 0x795c98: LoadField: r1 = r0->field_43
    //     0x795c98: ldur            w1, [x0, #0x43]
    // 0x795c9c: DecompressPointer r1
    //     0x795c9c: add             x1, x1, HEAP, lsl #32
    // 0x795ca0: cmp             w1, NULL
    // 0x795ca4: b.eq            #0x795cb8
    // 0x795ca8: r16 = true
    //     0x795ca8: add             x16, NULL, #0x20  ; true
    // 0x795cac: stp             x16, x0, [SP, #-0x10]!
    // 0x795cb0: r0 = _dismissTooltip()
    //     0x795cb0: bl              #0x795d10  ; [package:flutter/src/material/tooltip.dart] TooltipState::_dismissTooltip
    // 0x795cb4: add             SP, SP, #0x10
    // 0x795cb8: ldr             x0, [fp, #0x10]
    // 0x795cbc: LoadField: r1 = r0->field_4b
    //     0x795cbc: ldur            w1, [x0, #0x4b]
    // 0x795cc0: DecompressPointer r1
    //     0x795cc0: add             x1, x1, HEAP, lsl #32
    // 0x795cc4: cmp             w1, NULL
    // 0x795cc8: b.eq            #0x795cd8
    // 0x795ccc: SaveReg r1
    //     0x795ccc: str             x1, [SP, #-8]!
    // 0x795cd0: r0 = cancel()
    //     0x795cd0: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x795cd4: add             SP, SP, #8
    // 0x795cd8: r0 = Null
    //     0x795cd8: mov             x0, NULL
    // 0x795cdc: LeaveFrame
    //     0x795cdc: mov             SP, fp
    //     0x795ce0: ldp             fp, lr, [SP], #0x10
    // 0x795ce4: ret
    //     0x795ce4: ret             
    // 0x795ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795ce8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795cec: b               #0x795c94
  }
  _ _dismissTooltip(/* No info */) {
    // ** addr: 0x795d10, size: 0x208
    // 0x795d10: EnterFrame
    //     0x795d10: stp             fp, lr, [SP, #-0x10]!
    //     0x795d14: mov             fp, SP
    // 0x795d18: AllocStack(0x8)
    //     0x795d18: sub             SP, SP, #8
    // 0x795d1c: CheckStackOverflow
    //     0x795d1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795d20: cmp             SP, x16
    //     0x795d24: b.ls            #0x795ee0
    // 0x795d28: ldr             x0, [fp, #0x18]
    // 0x795d2c: LoadField: r1 = r0->field_4b
    //     0x795d2c: ldur            w1, [x0, #0x4b]
    // 0x795d30: DecompressPointer r1
    //     0x795d30: add             x1, x1, HEAP, lsl #32
    // 0x795d34: cmp             w1, NULL
    // 0x795d38: b.eq            #0x795d4c
    // 0x795d3c: SaveReg r1
    //     0x795d3c: str             x1, [SP, #-8]!
    // 0x795d40: r0 = cancel()
    //     0x795d40: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x795d44: add             SP, SP, #8
    // 0x795d48: ldr             x0, [fp, #0x18]
    // 0x795d4c: ldr             x1, [fp, #0x10]
    // 0x795d50: StoreField: r0->field_4b = rNULL
    //     0x795d50: stur            NULL, [x0, #0x4b]
    // 0x795d54: tbnz            w1, #4, #0x795d74
    // 0x795d58: SaveReg r0
    //     0x795d58: str             x0, [SP, #-8]!
    // 0x795d5c: r0 = _removeEntry()
    //     0x795d5c: bl              #0x795f18  ; [package:flutter/src/material/tooltip.dart] TooltipState::_removeEntry
    // 0x795d60: add             SP, SP, #8
    // 0x795d64: r0 = Null
    //     0x795d64: mov             x0, NULL
    // 0x795d68: LeaveFrame
    //     0x795d68: mov             SP, fp
    //     0x795d6c: ldp             fp, lr, [SP], #0x10
    // 0x795d70: ret
    //     0x795d70: ret             
    // 0x795d74: r1 = true
    //     0x795d74: add             x1, NULL, #0x20  ; true
    // 0x795d78: StoreField: r0->field_6f = r1
    //     0x795d78: stur            w1, [x0, #0x6f]
    // 0x795d7c: LoadField: r1 = r0->field_5f
    //     0x795d7c: ldur            w1, [x0, #0x5f]
    // 0x795d80: DecompressPointer r1
    //     0x795d80: add             x1, x1, HEAP, lsl #32
    // 0x795d84: tbnz            w1, #4, #0x795e2c
    // 0x795d88: LoadField: r1 = r0->field_47
    //     0x795d88: ldur            w1, [x0, #0x47]
    // 0x795d8c: DecompressPointer r1
    //     0x795d8c: add             x1, x1, HEAP, lsl #32
    // 0x795d90: cmp             w1, NULL
    // 0x795d94: b.ne            #0x795e24
    // 0x795d98: LoadField: r1 = r0->field_4f
    //     0x795d98: ldur            w1, [x0, #0x4f]
    // 0x795d9c: DecompressPointer r1
    //     0x795d9c: add             x1, x1, HEAP, lsl #32
    // 0x795da0: r16 = Sentinel
    //     0x795da0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x795da4: cmp             w1, w16
    // 0x795da8: b.eq            #0x795ee8
    // 0x795dac: LoadField: r1 = r0->field_3f
    //     0x795dac: ldur            w1, [x0, #0x3f]
    // 0x795db0: DecompressPointer r1
    //     0x795db0: add             x1, x1, HEAP, lsl #32
    // 0x795db4: r16 = Sentinel
    //     0x795db4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x795db8: cmp             w1, w16
    // 0x795dbc: b.eq            #0x795ef4
    // 0x795dc0: stur            x1, [fp, #-8]
    // 0x795dc4: r1 = 1
    //     0x795dc4: mov             x1, #1
    // 0x795dc8: r0 = AllocateContext()
    //     0x795dc8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x795dcc: mov             x1, x0
    // 0x795dd0: ldur            x0, [fp, #-8]
    // 0x795dd4: StoreField: r1->field_f = r0
    //     0x795dd4: stur            w0, [x1, #0xf]
    // 0x795dd8: mov             x2, x1
    // 0x795ddc: r1 = Function 'reverse':.
    //     0x795ddc: add             x1, PP, #0x50, lsl #12  ; [pp+0x50420] AnonymousClosure: (0x591230), in [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse (0x591170)
    //     0x795de0: ldr             x1, [x1, #0x420]
    // 0x795de4: r0 = AllocateClosure()
    //     0x795de4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x795de8: r16 = Instance_Duration
    //     0x795de8: add             x16, PP, #0x50, lsl #12  ; [pp+0x503e0] Obj!Duration@b67b31
    //     0x795dec: ldr             x16, [x16, #0x3e0]
    // 0x795df0: stp             x16, NULL, [SP, #-0x10]!
    // 0x795df4: SaveReg r0
    //     0x795df4: str             x0, [SP, #-8]!
    // 0x795df8: r0 = Timer()
    //     0x795df8: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x795dfc: add             SP, SP, #0x18
    // 0x795e00: ldr             x1, [fp, #0x18]
    // 0x795e04: StoreField: r1->field_47 = r0
    //     0x795e04: stur            w0, [x1, #0x47]
    //     0x795e08: ldurb           w16, [x1, #-1]
    //     0x795e0c: ldurb           w17, [x0, #-1]
    //     0x795e10: and             x16, x17, x16, lsr #2
    //     0x795e14: tst             x16, HEAP, lsr #32
    //     0x795e18: b.eq            #0x795e20
    //     0x795e1c: bl              #0xd6826c
    // 0x795e20: b               #0x795ec8
    // 0x795e24: mov             x1, x0
    // 0x795e28: b               #0x795ec8
    // 0x795e2c: mov             x1, x0
    // 0x795e30: LoadField: r0 = r1->field_47
    //     0x795e30: ldur            w0, [x1, #0x47]
    // 0x795e34: DecompressPointer r0
    //     0x795e34: add             x0, x0, HEAP, lsl #32
    // 0x795e38: cmp             w0, NULL
    // 0x795e3c: b.ne            #0x795ec8
    // 0x795e40: LoadField: r0 = r1->field_53
    //     0x795e40: ldur            w0, [x1, #0x53]
    // 0x795e44: DecompressPointer r0
    //     0x795e44: add             x0, x0, HEAP, lsl #32
    // 0x795e48: r16 = Sentinel
    //     0x795e48: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x795e4c: cmp             w0, w16
    // 0x795e50: b.eq            #0x795f00
    // 0x795e54: LoadField: r0 = r1->field_3f
    //     0x795e54: ldur            w0, [x1, #0x3f]
    // 0x795e58: DecompressPointer r0
    //     0x795e58: add             x0, x0, HEAP, lsl #32
    // 0x795e5c: r16 = Sentinel
    //     0x795e5c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x795e60: cmp             w0, w16
    // 0x795e64: b.eq            #0x795f0c
    // 0x795e68: stur            x0, [fp, #-8]
    // 0x795e6c: r1 = 1
    //     0x795e6c: mov             x1, #1
    // 0x795e70: r0 = AllocateContext()
    //     0x795e70: bl              #0xd68aa4  ; AllocateContextStub
    // 0x795e74: mov             x1, x0
    // 0x795e78: ldur            x0, [fp, #-8]
    // 0x795e7c: StoreField: r1->field_f = r0
    //     0x795e7c: stur            w0, [x1, #0xf]
    // 0x795e80: mov             x2, x1
    // 0x795e84: r1 = Function 'reverse':.
    //     0x795e84: add             x1, PP, #0x50, lsl #12  ; [pp+0x50420] AnonymousClosure: (0x591230), in [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse (0x591170)
    //     0x795e88: ldr             x1, [x1, #0x420]
    // 0x795e8c: r0 = AllocateClosure()
    //     0x795e8c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x795e90: r16 = Instance_Duration
    //     0x795e90: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x795e94: ldr             x16, [x16, #0x9f0]
    // 0x795e98: stp             x16, NULL, [SP, #-0x10]!
    // 0x795e9c: SaveReg r0
    //     0x795e9c: str             x0, [SP, #-8]!
    // 0x795ea0: r0 = Timer()
    //     0x795ea0: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x795ea4: add             SP, SP, #0x18
    // 0x795ea8: ldr             x1, [fp, #0x18]
    // 0x795eac: StoreField: r1->field_47 = r0
    //     0x795eac: stur            w0, [x1, #0x47]
    //     0x795eb0: ldurb           w16, [x1, #-1]
    //     0x795eb4: ldurb           w17, [x0, #-1]
    //     0x795eb8: and             x16, x17, x16, lsr #2
    //     0x795ebc: tst             x16, HEAP, lsr #32
    //     0x795ec0: b.eq            #0x795ec8
    //     0x795ec4: bl              #0xd6826c
    // 0x795ec8: r2 = false
    //     0x795ec8: add             x2, NULL, #0x30  ; false
    // 0x795ecc: StoreField: r1->field_5f = r2
    //     0x795ecc: stur            w2, [x1, #0x5f]
    // 0x795ed0: r0 = Null
    //     0x795ed0: mov             x0, NULL
    // 0x795ed4: LeaveFrame
    //     0x795ed4: mov             SP, fp
    //     0x795ed8: ldp             fp, lr, [SP], #0x10
    // 0x795edc: ret
    //     0x795edc: ret             
    // 0x795ee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x795ee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x795ee4: b               #0x795d28
    // 0x795ee8: r9 = _showDuration
    //     0x795ee8: add             x9, PP, #0x50, lsl #12  ; [pp+0x50428] Field <TooltipState._showDuration@838220820>: late (offset: 0x50)
    //     0x795eec: ldr             x9, [x9, #0x428]
    // 0x795ef0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x795ef0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x795ef4: r9 = _controller
    //     0x795ef4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x795ef8: ldr             x9, [x9, #0x118]
    // 0x795efc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x795efc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x795f00: r9 = _hoverShowDuration
    //     0x795f00: add             x9, PP, #0x50, lsl #12  ; [pp+0x50430] Field <TooltipState._hoverShowDuration@838220820>: late (offset: 0x54)
    //     0x795f04: ldr             x9, [x9, #0x430]
    // 0x795f08: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x795f08: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x795f0c: r9 = _controller
    //     0x795f0c: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x795f10: ldr             x9, [x9, #0x118]
    // 0x795f14: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x795f14: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _removeEntry(/* No info */) {
    // ** addr: 0x795f18, size: 0x150
    // 0x795f18: EnterFrame
    //     0x795f18: stp             fp, lr, [SP, #-0x10]!
    //     0x795f1c: mov             fp, SP
    // 0x795f20: CheckStackOverflow
    //     0x795f20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x795f24: cmp             SP, x16
    //     0x795f28: b.ls            #0x796048
    // 0x795f2c: r0 = InitLateStaticField(0xe4c) // [package:flutter/src/material/tooltip.dart] Tooltip::_openedTooltips
    //     0x795f2c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x795f30: ldr             x0, [x0, #0x1c98]
    //     0x795f34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x795f38: cmp             w0, w16
    //     0x795f3c: b.ne            #0x795f4c
    //     0x795f40: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d0f8] Field <Tooltip._openedTooltips@838220820>: static late final (offset: 0xe4c)
    //     0x795f44: ldr             x2, [x2, #0xf8]
    //     0x795f48: bl              #0xd67cdc
    // 0x795f4c: ldr             x16, [fp, #0x10]
    // 0x795f50: stp             x16, x0, [SP, #-0x10]!
    // 0x795f54: r0 = remove()
    //     0x795f54: bl              #0x5f0814  ; [dart:core] _GrowableList::remove
    // 0x795f58: add             SP, SP, #0x10
    // 0x795f5c: r0 = InitLateStaticField(0xe50) // [package:flutter/src/material/tooltip.dart] TooltipState::_mouseIn
    //     0x795f5c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x795f60: ldr             x0, [x0, #0x1ca0]
    //     0x795f64: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x795f68: cmp             w0, w16
    //     0x795f6c: b.ne            #0x795f7c
    //     0x795f70: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d100] Field <TooltipState._mouseIn@838220820>: static late final (offset: 0xe50)
    //     0x795f74: ldr             x2, [x2, #0x100]
    //     0x795f78: bl              #0xd67cdc
    // 0x795f7c: ldr             x16, [fp, #0x10]
    // 0x795f80: stp             x16, x0, [SP, #-0x10]!
    // 0x795f84: r0 = remove()
    //     0x795f84: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x795f88: add             SP, SP, #0x10
    // 0x795f8c: ldr             x0, [fp, #0x10]
    // 0x795f90: LoadField: r1 = r0->field_47
    //     0x795f90: ldur            w1, [x0, #0x47]
    // 0x795f94: DecompressPointer r1
    //     0x795f94: add             x1, x1, HEAP, lsl #32
    // 0x795f98: cmp             w1, NULL
    // 0x795f9c: b.eq            #0x795fb0
    // 0x795fa0: SaveReg r1
    //     0x795fa0: str             x1, [SP, #-8]!
    // 0x795fa4: r0 = cancel()
    //     0x795fa4: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x795fa8: add             SP, SP, #8
    // 0x795fac: ldr             x0, [fp, #0x10]
    // 0x795fb0: StoreField: r0->field_47 = rNULL
    //     0x795fb0: stur            NULL, [x0, #0x47]
    // 0x795fb4: LoadField: r1 = r0->field_4b
    //     0x795fb4: ldur            w1, [x0, #0x4b]
    // 0x795fb8: DecompressPointer r1
    //     0x795fb8: add             x1, x1, HEAP, lsl #32
    // 0x795fbc: cmp             w1, NULL
    // 0x795fc0: b.eq            #0x795fd4
    // 0x795fc4: SaveReg r1
    //     0x795fc4: str             x1, [SP, #-8]!
    // 0x795fc8: r0 = cancel()
    //     0x795fc8: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x795fcc: add             SP, SP, #8
    // 0x795fd0: ldr             x0, [fp, #0x10]
    // 0x795fd4: StoreField: r0->field_4b = rNULL
    //     0x795fd4: stur            NULL, [x0, #0x4b]
    // 0x795fd8: LoadField: r1 = r0->field_6b
    //     0x795fd8: ldur            w1, [x0, #0x6b]
    // 0x795fdc: DecompressPointer r1
    //     0x795fdc: add             x1, x1, HEAP, lsl #32
    // 0x795fe0: r16 = Sentinel
    //     0x795fe0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x795fe4: cmp             w1, w16
    // 0x795fe8: b.eq            #0x796050
    // 0x795fec: tbz             w1, #4, #0x79600c
    // 0x795ff0: LoadField: r1 = r0->field_43
    //     0x795ff0: ldur            w1, [x0, #0x43]
    // 0x795ff4: DecompressPointer r1
    //     0x795ff4: add             x1, x1, HEAP, lsl #32
    // 0x795ff8: cmp             w1, NULL
    // 0x795ffc: b.eq            #0x79600c
    // 0x796000: SaveReg r1
    //     0x796000: str             x1, [SP, #-8]!
    // 0x796004: r0 = remove()
    //     0x796004: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x796008: add             SP, SP, #8
    // 0x79600c: ldr             x0, [fp, #0x10]
    // 0x796010: r1 = false
    //     0x796010: add             x1, NULL, #0x30  ; false
    // 0x796014: StoreField: r0->field_6b = r1
    //     0x796014: stur            w1, [x0, #0x6b]
    // 0x796018: StoreField: r0->field_43 = rNULL
    //     0x796018: stur            NULL, [x0, #0x43]
    // 0x79601c: LoadField: r1 = r0->field_5b
    //     0x79601c: ldur            w1, [x0, #0x5b]
    // 0x796020: DecompressPointer r1
    //     0x796020: add             x1, x1, HEAP, lsl #32
    // 0x796024: r16 = Sentinel
    //     0x796024: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x796028: cmp             w1, w16
    // 0x79602c: b.eq            #0x79605c
    // 0x796030: tbnz            w1, #4, #0x796038
    // 0x796034: r0 = _revealLastTooltip()
    //     0x796034: bl              #0x796068  ; [package:flutter/src/material/tooltip.dart] Tooltip::_revealLastTooltip
    // 0x796038: r0 = Null
    //     0x796038: mov             x0, NULL
    // 0x79603c: LeaveFrame
    //     0x79603c: mov             SP, fp
    //     0x796040: ldp             fp, lr, [SP], #0x10
    // 0x796044: ret
    //     0x796044: ret             
    // 0x796048: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x796048: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79604c: b               #0x795f2c
    // 0x796050: r9 = _isConcealed
    //     0x796050: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d108] Field <TooltipState._isConcealed@838220820>: late (offset: 0x6c)
    //     0x796054: ldr             x9, [x9, #0x108]
    // 0x796058: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x796058: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79605c: r9 = _mouseIsConnected
    //     0x79605c: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d110] Field <TooltipState._mouseIsConnected@838220820>: late (offset: 0x5c)
    //     0x796060: ldr             x9, [x9, #0x110]
    // 0x796064: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x796064: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _revealTooltip(/* No info */) {
    // ** addr: 0x7960d8, size: 0x190
    // 0x7960d8: EnterFrame
    //     0x7960d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7960dc: mov             fp, SP
    // 0x7960e0: CheckStackOverflow
    //     0x7960e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7960e4: cmp             SP, x16
    //     0x7960e8: b.ls            #0x796238
    // 0x7960ec: ldr             x0, [fp, #0x10]
    // 0x7960f0: LoadField: r1 = r0->field_6b
    //     0x7960f0: ldur            w1, [x0, #0x6b]
    // 0x7960f4: DecompressPointer r1
    //     0x7960f4: add             x1, x1, HEAP, lsl #32
    // 0x7960f8: r16 = Sentinel
    //     0x7960f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7960fc: cmp             w1, w16
    // 0x796100: b.eq            #0x796240
    // 0x796104: tbz             w1, #4, #0x796118
    // 0x796108: r0 = Null
    //     0x796108: mov             x0, NULL
    // 0x79610c: LeaveFrame
    //     0x79610c: mov             SP, fp
    //     0x796110: ldp             fp, lr, [SP], #0x10
    // 0x796114: ret
    //     0x796114: ret             
    // 0x796118: r1 = false
    //     0x796118: add             x1, NULL, #0x30  ; false
    // 0x79611c: StoreField: r0->field_6b = r1
    //     0x79611c: stur            w1, [x0, #0x6b]
    // 0x796120: LoadField: r1 = r0->field_47
    //     0x796120: ldur            w1, [x0, #0x47]
    // 0x796124: DecompressPointer r1
    //     0x796124: add             x1, x1, HEAP, lsl #32
    // 0x796128: cmp             w1, NULL
    // 0x79612c: b.eq            #0x796140
    // 0x796130: SaveReg r1
    //     0x796130: str             x1, [SP, #-8]!
    // 0x796134: r0 = cancel()
    //     0x796134: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x796138: add             SP, SP, #8
    // 0x79613c: ldr             x0, [fp, #0x10]
    // 0x796140: StoreField: r0->field_47 = rNULL
    //     0x796140: stur            NULL, [x0, #0x47]
    // 0x796144: LoadField: r1 = r0->field_4b
    //     0x796144: ldur            w1, [x0, #0x4b]
    // 0x796148: DecompressPointer r1
    //     0x796148: add             x1, x1, HEAP, lsl #32
    // 0x79614c: cmp             w1, NULL
    // 0x796150: b.eq            #0x796164
    // 0x796154: SaveReg r1
    //     0x796154: str             x1, [SP, #-8]!
    // 0x796158: r0 = cancel()
    //     0x796158: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x79615c: add             SP, SP, #8
    // 0x796160: ldr             x0, [fp, #0x10]
    // 0x796164: StoreField: r0->field_4b = rNULL
    //     0x796164: stur            NULL, [x0, #0x4b]
    // 0x796168: LoadField: r1 = r0->field_43
    //     0x796168: ldur            w1, [x0, #0x43]
    // 0x79616c: DecompressPointer r1
    //     0x79616c: add             x1, x1, HEAP, lsl #32
    // 0x796170: cmp             w1, NULL
    // 0x796174: b.eq            #0x79624c
    // 0x796178: LoadField: r2 = r1->field_13
    //     0x796178: ldur            w2, [x1, #0x13]
    // 0x79617c: DecompressPointer r2
    //     0x79617c: add             x2, x2, HEAP, lsl #32
    // 0x796180: LoadField: r1 = r2->field_27
    //     0x796180: ldur            w1, [x2, #0x27]
    // 0x796184: DecompressPointer r1
    //     0x796184: add             x1, x1, HEAP, lsl #32
    // 0x796188: tbz             w1, #4, #0x7961e4
    // 0x79618c: LoadField: r1 = r0->field_f
    //     0x79618c: ldur            w1, [x0, #0xf]
    // 0x796190: DecompressPointer r1
    //     0x796190: add             x1, x1, HEAP, lsl #32
    // 0x796194: cmp             w1, NULL
    // 0x796198: b.eq            #0x796250
    // 0x79619c: LoadField: r2 = r0->field_b
    //     0x79619c: ldur            w2, [x0, #0xb]
    // 0x7961a0: DecompressPointer r2
    //     0x7961a0: add             x2, x2, HEAP, lsl #32
    // 0x7961a4: cmp             w2, NULL
    // 0x7961a8: b.eq            #0x796254
    // 0x7961ac: SaveReg r1
    //     0x7961ac: str             x1, [SP, #-8]!
    // 0x7961b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7961b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7961b4: r0 = of()
    //     0x7961b4: bl              #0x59424c  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x7961b8: add             SP, SP, #8
    // 0x7961bc: mov             x1, x0
    // 0x7961c0: ldr             x0, [fp, #0x10]
    // 0x7961c4: LoadField: r2 = r0->field_43
    //     0x7961c4: ldur            w2, [x0, #0x43]
    // 0x7961c8: DecompressPointer r2
    //     0x7961c8: add             x2, x2, HEAP, lsl #32
    // 0x7961cc: cmp             w2, NULL
    // 0x7961d0: b.eq            #0x796258
    // 0x7961d4: stp             x2, x1, [SP, #-0x10]!
    // 0x7961d8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7961d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7961dc: r0 = insert()
    //     0x7961dc: bl              #0x594040  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insert
    // 0x7961e0: add             SP, SP, #0x10
    // 0x7961e4: ldr             x0, [fp, #0x10]
    // 0x7961e8: SaveReg r0
    //     0x7961e8: str             x0, [SP, #-8]!
    // 0x7961ec: r0 = _tooltipMessage()
    //     0x7961ec: bl              #0x796448  ; [package:flutter/src/material/tooltip.dart] TooltipState::_tooltipMessage
    // 0x7961f0: add             SP, SP, #8
    // 0x7961f4: SaveReg r0
    //     0x7961f4: str             x0, [SP, #-8]!
    // 0x7961f8: r0 = tooltip()
    //     0x7961f8: bl              #0x796268  ; [package:flutter/src/semantics/semantics_service.dart] SemanticsService::tooltip
    // 0x7961fc: add             SP, SP, #8
    // 0x796200: ldr             x0, [fp, #0x10]
    // 0x796204: LoadField: r1 = r0->field_3f
    //     0x796204: ldur            w1, [x0, #0x3f]
    // 0x796208: DecompressPointer r1
    //     0x796208: add             x1, x1, HEAP, lsl #32
    // 0x79620c: r16 = Sentinel
    //     0x79620c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x796210: cmp             w1, w16
    // 0x796214: b.eq            #0x79625c
    // 0x796218: SaveReg r1
    //     0x796218: str             x1, [SP, #-8]!
    // 0x79621c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x79621c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x796220: r0 = forward()
    //     0x796220: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x796224: add             SP, SP, #8
    // 0x796228: r0 = Null
    //     0x796228: mov             x0, NULL
    // 0x79622c: LeaveFrame
    //     0x79622c: mov             SP, fp
    //     0x796230: ldp             fp, lr, [SP], #0x10
    // 0x796234: ret
    //     0x796234: ret             
    // 0x796238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x796238: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79623c: b               #0x7960ec
    // 0x796240: r9 = _isConcealed
    //     0x796240: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d108] Field <TooltipState._isConcealed@838220820>: late (offset: 0x6c)
    //     0x796244: ldr             x9, [x9, #0x108]
    // 0x796248: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x796248: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x79624c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79624c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x796250: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x796250: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x796254: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x796254: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x796258: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x796258: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79625c: r9 = _controller
    //     0x79625c: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x796260: ldr             x9, [x9, #0x118]
    // 0x796264: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x796264: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ _tooltipMessage(/* No info */) {
    // ** addr: 0x796448, size: 0x58
    // 0x796448: EnterFrame
    //     0x796448: stp             fp, lr, [SP, #-0x10]!
    //     0x79644c: mov             fp, SP
    // 0x796450: ldr             x0, [fp, #0x10]
    // 0x796454: LoadField: r1 = r0->field_b
    //     0x796454: ldur            w1, [x0, #0xb]
    // 0x796458: DecompressPointer r1
    //     0x796458: add             x1, x1, HEAP, lsl #32
    // 0x79645c: cmp             w1, NULL
    // 0x796460: b.eq            #0x796498
    // 0x796464: LoadField: r0 = r1->field_b
    //     0x796464: ldur            w0, [x1, #0xb]
    // 0x796468: DecompressPointer r0
    //     0x796468: add             x0, x0, HEAP, lsl #32
    // 0x79646c: cmp             w0, NULL
    // 0x796470: b.eq            #0x796480
    // 0x796474: LeaveFrame
    //     0x796474: mov             SP, fp
    //     0x796478: ldp             fp, lr, [SP], #0x10
    // 0x79647c: ret
    //     0x79647c: ret             
    // 0x796480: r0 = Null
    //     0x796480: mov             x0, NULL
    // 0x796484: cmp             w0, NULL
    // 0x796488: b.eq            #0x79649c
    // 0x79648c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x79648c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x796490: r0 = Throw()
    //     0x796490: bl              #0xd67e38  ; ThrowStub
    // 0x796494: brk             #0
    // 0x796498: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x796498: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x79649c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x79649c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Set<TooltipState> _mouseIn() {
    // ** addr: 0x7964a0, size: 0x9c
    // 0x7964a0: EnterFrame
    //     0x7964a0: stp             fp, lr, [SP, #-0x10]!
    //     0x7964a4: mov             fp, SP
    // 0x7964a8: AllocStack(0x10)
    //     0x7964a8: sub             SP, SP, #0x10
    // 0x7964ac: CheckStackOverflow
    //     0x7964ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7964b0: cmp             SP, x16
    //     0x7964b4: b.ls            #0x796534
    // 0x7964b8: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x7964b8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7964bc: ldr             x0, [x0, #0x598]
    //     0x7964c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7964c4: cmp             w0, w16
    //     0x7964c8: b.ne            #0x7964d4
    //     0x7964cc: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x7964d0: bl              #0xd67cdc
    // 0x7964d4: r1 = <TooltipState<Tooltip>>
    //     0x7964d4: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d130] TypeArguments: <TooltipState<Tooltip>>
    //     0x7964d8: ldr             x1, [x1, #0x130]
    // 0x7964dc: stur            x0, [fp, #-8]
    // 0x7964e0: r0 = _Set()
    //     0x7964e0: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x7964e4: mov             x1, x0
    // 0x7964e8: ldur            x0, [fp, #-8]
    // 0x7964ec: stur            x1, [fp, #-0x10]
    // 0x7964f0: StoreField: r1->field_1b = r0
    //     0x7964f0: stur            w0, [x1, #0x1b]
    // 0x7964f4: StoreField: r1->field_b = rZR
    //     0x7964f4: stur            wzr, [x1, #0xb]
    // 0x7964f8: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x7964f8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7964fc: ldr             x0, [x0, #0x5a0]
    //     0x796500: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x796504: cmp             w0, w16
    //     0x796508: b.ne            #0x796514
    //     0x79650c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x796510: bl              #0xd67cdc
    // 0x796514: mov             x1, x0
    // 0x796518: ldur            x0, [fp, #-0x10]
    // 0x79651c: StoreField: r0->field_f = r1
    //     0x79651c: stur            w1, [x0, #0xf]
    // 0x796520: StoreField: r0->field_13 = rZR
    //     0x796520: stur            wzr, [x0, #0x13]
    // 0x796524: StoreField: r0->field_17 = rZR
    //     0x796524: stur            wzr, [x0, #0x17]
    // 0x796528: LeaveFrame
    //     0x796528: mov             SP, fp
    //     0x79652c: ldp             fp, lr, [SP], #0x10
    // 0x796530: ret
    //     0x796530: ret             
    // 0x796534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x796534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x796538: b               #0x7964b8
  }
  _ build(/* No info */) {
    // ** addr: 0x873ecc, size: 0x5f0
    // 0x873ecc: EnterFrame
    //     0x873ecc: stp             fp, lr, [SP, #-0x10]!
    //     0x873ed0: mov             fp, SP
    // 0x873ed4: AllocStack(0x28)
    //     0x873ed4: sub             SP, SP, #0x28
    // 0x873ed8: CheckStackOverflow
    //     0x873ed8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x873edc: cmp             SP, x16
    //     0x873ee0: b.ls            #0x874440
    // 0x873ee4: r1 = 1
    //     0x873ee4: mov             x1, #1
    // 0x873ee8: r0 = AllocateContext()
    //     0x873ee8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x873eec: mov             x1, x0
    // 0x873ef0: ldr             x0, [fp, #0x18]
    // 0x873ef4: stur            x1, [fp, #-8]
    // 0x873ef8: StoreField: r1->field_f = r0
    //     0x873ef8: stur            w0, [x1, #0xf]
    // 0x873efc: LoadField: r2 = r0->field_b
    //     0x873efc: ldur            w2, [x0, #0xb]
    // 0x873f00: DecompressPointer r2
    //     0x873f00: add             x2, x2, HEAP, lsl #32
    // 0x873f04: cmp             w2, NULL
    // 0x873f08: b.eq            #0x874448
    // 0x873f0c: LoadField: r3 = r2->field_b
    //     0x873f0c: ldur            w3, [x2, #0xb]
    // 0x873f10: DecompressPointer r3
    //     0x873f10: add             x3, x3, HEAP, lsl #32
    // 0x873f14: cmp             w3, NULL
    // 0x873f18: b.eq            #0x874410
    // 0x873f1c: r4 = Null
    //     0x873f1c: mov             x4, NULL
    // 0x873f20: LoadField: r5 = r3->field_7
    //     0x873f20: ldur            w5, [x3, #7]
    // 0x873f24: DecompressPointer r5
    //     0x873f24: add             x5, x5, HEAP, lsl #32
    // 0x873f28: cbnz            w5, #0x873f40
    // 0x873f2c: LoadField: r0 = r2->field_2b
    //     0x873f2c: ldur            w0, [x2, #0x2b]
    // 0x873f30: DecompressPointer r0
    //     0x873f30: add             x0, x0, HEAP, lsl #32
    // 0x873f34: LeaveFrame
    //     0x873f34: mov             SP, fp
    //     0x873f38: ldp             fp, lr, [SP], #0x10
    // 0x873f3c: ret
    //     0x873f3c: ret             
    // 0x873f40: ldr             x16, [fp, #0x10]
    // 0x873f44: SaveReg r16
    //     0x873f44: str             x16, [SP, #-8]!
    // 0x873f48: r0 = of()
    //     0x873f48: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x873f4c: add             SP, SP, #8
    // 0x873f50: stur            x0, [fp, #-0x10]
    // 0x873f54: ldr             x16, [fp, #0x10]
    // 0x873f58: SaveReg r16
    //     0x873f58: str             x16, [SP, #-8]!
    // 0x873f5c: r0 = of()
    //     0x873f5c: bl              #0x874630  ; [package:flutter/src/material/tooltip_theme.dart] TooltipTheme::of
    // 0x873f60: add             SP, SP, #8
    // 0x873f64: mov             x1, x0
    // 0x873f68: ldur            x0, [fp, #-0x10]
    // 0x873f6c: stur            x1, [fp, #-0x20]
    // 0x873f70: LoadField: r2 = r0->field_3f
    //     0x873f70: ldur            w2, [x0, #0x3f]
    // 0x873f74: DecompressPointer r2
    //     0x873f74: add             x2, x2, HEAP, lsl #32
    // 0x873f78: LoadField: r3 = r2->field_7
    //     0x873f78: ldur            w3, [x2, #7]
    // 0x873f7c: DecompressPointer r3
    //     0x873f7c: add             x3, x3, HEAP, lsl #32
    // 0x873f80: r16 = Instance_Brightness
    //     0x873f80: ldr             x16, [PP, #0x2138]  ; [pp+0x2138] Obj!Brightness@b66cf1
    // 0x873f84: cmp             w3, w16
    // 0x873f88: b.ne            #0x874038
    // 0x873f8c: LoadField: r2 = r0->field_93
    //     0x873f8c: ldur            w2, [x0, #0x93]
    // 0x873f90: DecompressPointer r2
    //     0x873f90: add             x2, x2, HEAP, lsl #32
    // 0x873f94: LoadField: r0 = r2->field_2f
    //     0x873f94: ldur            w0, [x2, #0x2f]
    // 0x873f98: DecompressPointer r0
    //     0x873f98: add             x0, x0, HEAP, lsl #32
    // 0x873f9c: stur            x0, [fp, #-0x18]
    // 0x873fa0: cmp             w0, NULL
    // 0x873fa4: b.eq            #0x87444c
    // 0x873fa8: ldr             x16, [fp, #0x18]
    // 0x873fac: SaveReg r16
    //     0x873fac: str             x16, [SP, #-8]!
    // 0x873fb0: r0 = _getDefaultFontSize()
    //     0x873fb0: bl              #0x8745b4  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultFontSize
    // 0x873fb4: add             SP, SP, #8
    // 0x873fb8: ldur            x16, [fp, #-0x18]
    // 0x873fbc: r30 = Instance_Color
    //     0x873fbc: add             lr, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x873fc0: ldr             lr, [lr, #0xf38]
    // 0x873fc4: stp             lr, x16, [SP, #-0x10]!
    // 0x873fc8: SaveReg r0
    //     0x873fc8: str             x0, [SP, #-8]!
    // 0x873fcc: r4 = const [0, 0x3, 0x3, 0x1, color, 0x1, fontSize, 0x2, null]
    //     0x873fcc: add             x4, PP, #0x50, lsl #12  ; [pp+0x503d0] List(9) [0, 0x3, 0x3, 0x1, "color", 0x1, "fontSize", 0x2, Null]
    //     0x873fd0: ldr             x4, [x4, #0x3d0]
    // 0x873fd4: r0 = copyWith()
    //     0x873fd4: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x873fd8: add             SP, SP, #0x18
    // 0x873fdc: stur            x0, [fp, #-0x18]
    // 0x873fe0: r16 = Instance_Color
    //     0x873fe0: add             x16, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x873fe4: ldr             x16, [x16, #0xbe8]
    // 0x873fe8: SaveReg r16
    //     0x873fe8: str             x16, [SP, #-8]!
    // 0x873fec: d0 = 0.900000
    //     0x873fec: add             x17, PP, #0x3e, lsl #12  ; [pp+0x3e3c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x873ff0: ldr             d0, [x17, #0x3c0]
    // 0x873ff4: SaveReg d0
    //     0x873ff4: str             d0, [SP, #-8]!
    // 0x873ff8: r0 = withOpacity()
    //     0x873ff8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x873ffc: add             SP, SP, #0x10
    // 0x874000: stur            x0, [fp, #-0x28]
    // 0x874004: r0 = BoxDecoration()
    //     0x874004: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x874008: mov             x1, x0
    // 0x87400c: ldur            x0, [fp, #-0x28]
    // 0x874010: StoreField: r1->field_7 = r0
    //     0x874010: stur            w0, [x1, #7]
    // 0x874014: r2 = Instance_BorderRadius
    //     0x874014: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2eba8] Obj!BorderRadius@b37551
    //     0x874018: ldr             x2, [x2, #0xba8]
    // 0x87401c: StoreField: r1->field_13 = r2
    //     0x87401c: stur            w2, [x1, #0x13]
    // 0x874020: r3 = Instance_BoxShape
    //     0x874020: add             x3, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x874024: ldr             x3, [x3, #0xe68]
    // 0x874028: StoreField: r1->field_23 = r3
    //     0x874028: stur            w3, [x1, #0x23]
    // 0x87402c: ldur            x3, [fp, #-0x18]
    // 0x874030: mov             x2, x1
    // 0x874034: b               #0x874110
    // 0x874038: r2 = Instance_BorderRadius
    //     0x874038: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2eba8] Obj!BorderRadius@b37551
    //     0x87403c: ldr             x2, [x2, #0xba8]
    // 0x874040: r3 = Instance_BoxShape
    //     0x874040: add             x3, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x874044: ldr             x3, [x3, #0xe68]
    // 0x874048: d0 = 0.900000
    //     0x874048: add             x17, PP, #0x3e, lsl #12  ; [pp+0x3e3c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x87404c: ldr             d0, [x17, #0x3c0]
    // 0x874050: LoadField: r1 = r0->field_93
    //     0x874050: ldur            w1, [x0, #0x93]
    // 0x874054: DecompressPointer r1
    //     0x874054: add             x1, x1, HEAP, lsl #32
    // 0x874058: LoadField: r0 = r1->field_2f
    //     0x874058: ldur            w0, [x1, #0x2f]
    // 0x87405c: DecompressPointer r0
    //     0x87405c: add             x0, x0, HEAP, lsl #32
    // 0x874060: stur            x0, [fp, #-0x10]
    // 0x874064: cmp             w0, NULL
    // 0x874068: b.eq            #0x874450
    // 0x87406c: ldr             x16, [fp, #0x18]
    // 0x874070: SaveReg r16
    //     0x874070: str             x16, [SP, #-8]!
    // 0x874074: r0 = _getDefaultFontSize()
    //     0x874074: bl              #0x8745b4  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultFontSize
    // 0x874078: add             SP, SP, #8
    // 0x87407c: ldur            x16, [fp, #-0x10]
    // 0x874080: r30 = Instance_Color
    //     0x874080: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x874084: ldr             lr, [lr, #0xbe8]
    // 0x874088: stp             lr, x16, [SP, #-0x10]!
    // 0x87408c: SaveReg r0
    //     0x87408c: str             x0, [SP, #-8]!
    // 0x874090: r4 = const [0, 0x3, 0x3, 0x1, color, 0x1, fontSize, 0x2, null]
    //     0x874090: add             x4, PP, #0x50, lsl #12  ; [pp+0x503d0] List(9) [0, 0x3, 0x3, 0x1, "color", 0x1, "fontSize", 0x2, Null]
    //     0x874094: ldr             x4, [x4, #0x3d0]
    // 0x874098: r0 = copyWith()
    //     0x874098: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x87409c: add             SP, SP, #0x18
    // 0x8740a0: stur            x0, [fp, #-0x10]
    // 0x8740a4: r16 = _ConstMap len:12
    //     0x8740a4: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf20] Map<int, Color>(12)
    //     0x8740a8: ldr             x16, [x16, #0xf20]
    // 0x8740ac: r30 = 1400
    //     0x8740ac: mov             lr, #0x578
    // 0x8740b0: stp             lr, x16, [SP, #-0x10]!
    // 0x8740b4: r0 = []()
    //     0x8740b4: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0x8740b8: add             SP, SP, #0x10
    // 0x8740bc: cmp             w0, NULL
    // 0x8740c0: b.eq            #0x874454
    // 0x8740c4: SaveReg r0
    //     0x8740c4: str             x0, [SP, #-8]!
    // 0x8740c8: d0 = 0.900000
    //     0x8740c8: add             x17, PP, #0x3e, lsl #12  ; [pp+0x3e3c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x8740cc: ldr             d0, [x17, #0x3c0]
    // 0x8740d0: SaveReg d0
    //     0x8740d0: str             d0, [SP, #-8]!
    // 0x8740d4: r0 = withOpacity()
    //     0x8740d4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8740d8: add             SP, SP, #0x10
    // 0x8740dc: stur            x0, [fp, #-0x18]
    // 0x8740e0: r0 = BoxDecoration()
    //     0x8740e0: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x8740e4: mov             x1, x0
    // 0x8740e8: ldur            x0, [fp, #-0x18]
    // 0x8740ec: StoreField: r1->field_7 = r0
    //     0x8740ec: stur            w0, [x1, #7]
    // 0x8740f0: r0 = Instance_BorderRadius
    //     0x8740f0: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2eba8] Obj!BorderRadius@b37551
    //     0x8740f4: ldr             x0, [x0, #0xba8]
    // 0x8740f8: StoreField: r1->field_13 = r0
    //     0x8740f8: stur            w0, [x1, #0x13]
    // 0x8740fc: r0 = Instance_BoxShape
    //     0x8740fc: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x874100: ldr             x0, [x0, #0xe68]
    // 0x874104: StoreField: r1->field_23 = r0
    //     0x874104: stur            w0, [x1, #0x23]
    // 0x874108: ldur            x3, [fp, #-0x10]
    // 0x87410c: mov             x2, x1
    // 0x874110: ldr             x1, [fp, #0x18]
    // 0x874114: ldur            x0, [fp, #-0x20]
    // 0x874118: stur            x3, [fp, #-0x10]
    // 0x87411c: stur            x2, [fp, #-0x18]
    // 0x874120: LoadField: r4 = r1->field_b
    //     0x874120: ldur            w4, [x1, #0xb]
    // 0x874124: DecompressPointer r4
    //     0x874124: add             x4, x4, HEAP, lsl #32
    // 0x874128: cmp             w4, NULL
    // 0x87412c: b.eq            #0x874458
    // 0x874130: LoadField: r4 = r0->field_7
    //     0x874130: ldur            w4, [x0, #7]
    // 0x874134: DecompressPointer r4
    //     0x874134: add             x4, x4, HEAP, lsl #32
    // 0x874138: cmp             w4, NULL
    // 0x87413c: b.ne            #0x874150
    // 0x874140: SaveReg r1
    //     0x874140: str             x1, [SP, #-8]!
    // 0x874144: r0 = _getDefaultTooltipHeight()
    //     0x874144: bl              #0x874538  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultTooltipHeight
    // 0x874148: add             SP, SP, #8
    // 0x87414c: b               #0x874154
    // 0x874150: mov             x0, x4
    // 0x874154: ldr             x2, [fp, #0x18]
    // 0x874158: ldur            x1, [fp, #-0x20]
    // 0x87415c: StoreField: r2->field_1b = r0
    //     0x87415c: stur            w0, [x2, #0x1b]
    //     0x874160: ldurb           w16, [x2, #-1]
    //     0x874164: ldurb           w17, [x0, #-1]
    //     0x874168: and             x16, x17, x16, lsr #2
    //     0x87416c: tst             x16, HEAP, lsr #32
    //     0x874170: b.eq            #0x874178
    //     0x874174: bl              #0xd6828c
    // 0x874178: LoadField: r0 = r2->field_b
    //     0x874178: ldur            w0, [x2, #0xb]
    // 0x87417c: DecompressPointer r0
    //     0x87417c: add             x0, x0, HEAP, lsl #32
    // 0x874180: cmp             w0, NULL
    // 0x874184: b.eq            #0x87445c
    // 0x874188: SaveReg r2
    //     0x874188: str             x2, [SP, #-8]!
    // 0x87418c: r0 = _getDefaultPadding()
    //     0x87418c: bl              #0x8744bc  ; [package:flutter/src/material/tooltip.dart] TooltipState::_getDefaultPadding
    // 0x874190: add             SP, SP, #8
    // 0x874194: ldr             x1, [fp, #0x18]
    // 0x874198: StoreField: r1->field_1f = r0
    //     0x874198: stur            w0, [x1, #0x1f]
    //     0x87419c: ldurb           w16, [x1, #-1]
    //     0x8741a0: ldurb           w17, [x0, #-1]
    //     0x8741a4: and             x16, x17, x16, lsr #2
    //     0x8741a8: tst             x16, HEAP, lsr #32
    //     0x8741ac: b.eq            #0x8741b4
    //     0x8741b0: bl              #0xd6826c
    // 0x8741b4: LoadField: r2 = r1->field_b
    //     0x8741b4: ldur            w2, [x1, #0xb]
    // 0x8741b8: DecompressPointer r2
    //     0x8741b8: add             x2, x2, HEAP, lsl #32
    // 0x8741bc: cmp             w2, NULL
    // 0x8741c0: b.eq            #0x874460
    // 0x8741c4: r0 = Instance_EdgeInsets
    //     0x8741c4: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x8741c8: ldr             x0, [x0, #0xbd8]
    // 0x8741cc: StoreField: r1->field_23 = r0
    //     0x8741cc: stur            w0, [x1, #0x23]
    // 0x8741d0: ldur            x0, [fp, #-0x20]
    // 0x8741d4: LoadField: r3 = r0->field_13
    //     0x8741d4: ldur            w3, [x0, #0x13]
    // 0x8741d8: DecompressPointer r3
    //     0x8741d8: add             x3, x3, HEAP, lsl #32
    // 0x8741dc: cmp             w3, NULL
    // 0x8741e0: b.ne            #0x8741ec
    // 0x8741e4: d0 = 24.000000
    //     0x8741e4: fmov            d0, #24.00000000
    // 0x8741e8: b               #0x8741f0
    // 0x8741ec: LoadField: d0 = r3->field_7
    //     0x8741ec: ldur            d0, [x3, #7]
    // 0x8741f0: r9 = true
    //     0x8741f0: add             x9, NULL, #0x20  ; true
    // 0x8741f4: r8 = false
    //     0x8741f4: add             x8, NULL, #0x30  ; false
    // 0x8741f8: r7 = Instance_TooltipTriggerMode
    //     0x8741f8: add             x7, PP, #0x50, lsl #12  ; [pp+0x503d8] Obj!TooltipTriggerMode@b65091
    //     0x8741fc: ldr             x7, [x7, #0x3d8]
    // 0x874200: r6 = Instance_Duration
    //     0x874200: add             x6, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x874204: ldr             x6, [x6, #0x9f0]
    // 0x874208: r5 = Instance_Duration
    //     0x874208: add             x5, PP, #0x50, lsl #12  ; [pp+0x503e0] Obj!Duration@b67b31
    //     0x87420c: ldr             x5, [x5, #0x3e0]
    // 0x874210: r4 = Instance_Duration
    //     0x874210: ldr             x4, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x874214: r3 = Instance_TextAlign
    //     0x874214: add             x3, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x874218: ldr             x3, [x3, #0xfe8]
    // 0x87421c: r0 = inline_Allocate_Double()
    //     0x87421c: ldp             x0, x10, [THR, #0x60]  ; THR::top
    //     0x874220: add             x0, x0, #0x10
    //     0x874224: cmp             x10, x0
    //     0x874228: b.ls            #0x874464
    //     0x87422c: str             x0, [THR, #0x60]  ; THR::top
    //     0x874230: sub             x0, x0, #0xf
    //     0x874234: mov             x10, #0xd108
    //     0x874238: movk            x10, #3, lsl #16
    //     0x87423c: stur            x10, [x0, #-1]
    // 0x874240: StoreField: r0->field_7 = d0
    //     0x874240: stur            d0, [x0, #7]
    // 0x874244: StoreField: r1->field_33 = r0
    //     0x874244: stur            w0, [x1, #0x33]
    //     0x874248: ldurb           w16, [x1, #-1]
    //     0x87424c: ldurb           w17, [x0, #-1]
    //     0x874250: and             x16, x17, x16, lsr #2
    //     0x874254: tst             x16, HEAP, lsr #32
    //     0x874258: b.eq            #0x874260
    //     0x87425c: bl              #0xd6826c
    // 0x874260: StoreField: r1->field_37 = r9
    //     0x874260: stur            w9, [x1, #0x37]
    // 0x874264: StoreField: r1->field_3b = r8
    //     0x874264: stur            w8, [x1, #0x3b]
    // 0x874268: ldur            x0, [fp, #-0x18]
    // 0x87426c: StoreField: r1->field_27 = r0
    //     0x87426c: stur            w0, [x1, #0x27]
    //     0x874270: ldurb           w16, [x1, #-1]
    //     0x874274: ldurb           w17, [x0, #-1]
    //     0x874278: and             x16, x17, x16, lsr #2
    //     0x87427c: tst             x16, HEAP, lsr #32
    //     0x874280: b.eq            #0x874288
    //     0x874284: bl              #0xd6826c
    // 0x874288: ldur            x0, [fp, #-0x10]
    // 0x87428c: StoreField: r1->field_2b = r0
    //     0x87428c: stur            w0, [x1, #0x2b]
    //     0x874290: ldurb           w16, [x1, #-1]
    //     0x874294: ldurb           w17, [x0, #-1]
    //     0x874298: and             x16, x17, x16, lsr #2
    //     0x87429c: tst             x16, HEAP, lsr #32
    //     0x8742a0: b.eq            #0x8742a8
    //     0x8742a4: bl              #0xd6826c
    // 0x8742a8: StoreField: r1->field_2f = r3
    //     0x8742a8: stur            w3, [x1, #0x2f]
    // 0x8742ac: StoreField: r1->field_57 = r4
    //     0x8742ac: stur            w4, [x1, #0x57]
    // 0x8742b0: StoreField: r1->field_4f = r5
    //     0x8742b0: stur            w5, [x1, #0x4f]
    // 0x8742b4: StoreField: r1->field_53 = r6
    //     0x8742b4: stur            w6, [x1, #0x53]
    // 0x8742b8: StoreField: r1->field_63 = r7
    //     0x8742b8: stur            w7, [x1, #0x63]
    // 0x8742bc: StoreField: r1->field_67 = r9
    //     0x8742bc: stur            w9, [x1, #0x67]
    // 0x8742c0: LoadField: r0 = r2->field_b
    //     0x8742c0: ldur            w0, [x2, #0xb]
    // 0x8742c4: DecompressPointer r0
    //     0x8742c4: add             x0, x0, HEAP, lsl #32
    // 0x8742c8: stur            x0, [fp, #-0x18]
    // 0x8742cc: cmp             w0, NULL
    // 0x8742d0: b.eq            #0x874428
    // 0x8742d4: LoadField: r3 = r2->field_2b
    //     0x8742d4: ldur            w3, [x2, #0x2b]
    // 0x8742d8: DecompressPointer r3
    //     0x8742d8: add             x3, x3, HEAP, lsl #32
    // 0x8742dc: stur            x3, [fp, #-0x10]
    // 0x8742e0: r0 = Semantics()
    //     0x8742e0: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x8742e4: stur            x0, [fp, #-0x20]
    // 0x8742e8: ldur            x16, [fp, #-0x18]
    // 0x8742ec: stp             x16, x0, [SP, #-0x10]!
    // 0x8742f0: ldur            x16, [fp, #-0x10]
    // 0x8742f4: SaveReg r16
    //     0x8742f4: str             x16, [SP, #-8]!
    // 0x8742f8: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, tooltip, 0x1, null]
    //     0x8742f8: add             x4, PP, #0x50, lsl #12  ; [pp+0x503e8] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "tooltip", 0x1, Null]
    //     0x8742fc: ldr             x4, [x4, #0x3e8]
    // 0x874300: r0 = Semantics()
    //     0x874300: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x874304: add             SP, SP, #0x18
    // 0x874308: ldr             x0, [fp, #0x18]
    // 0x87430c: LoadField: r1 = r0->field_73
    //     0x87430c: ldur            w1, [x0, #0x73]
    // 0x874310: DecompressPointer r1
    //     0x874310: add             x1, x1, HEAP, lsl #32
    // 0x874314: r16 = Sentinel
    //     0x874314: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874318: cmp             w1, w16
    // 0x87431c: b.eq            #0x87449c
    // 0x874320: r1 = 1
    //     0x874320: mov             x1, #1
    // 0x874324: r0 = AllocateContext()
    //     0x874324: bl              #0xd68aa4  ; AllocateContextStub
    // 0x874328: mov             x1, x0
    // 0x87432c: ldr             x0, [fp, #0x18]
    // 0x874330: stur            x1, [fp, #-0x10]
    // 0x874334: StoreField: r1->field_f = r0
    //     0x874334: stur            w0, [x1, #0xf]
    // 0x874338: r0 = GestureDetector()
    //     0x874338: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x87433c: ldur            x2, [fp, #-0x10]
    // 0x874340: r1 = Function '_handlePress@838220820':.
    //     0x874340: add             x1, PP, #0x50, lsl #12  ; [pp+0x503f0] AnonymousClosure: (0x8759f8), in [package:flutter/src/material/tooltip.dart] TooltipState::_handlePress (0x875a40)
    //     0x874344: ldr             x1, [x1, #0x3f0]
    // 0x874348: stur            x0, [fp, #-0x10]
    // 0x87434c: r0 = AllocateClosure()
    //     0x87434c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x874350: ldur            x16, [fp, #-0x10]
    // 0x874354: r30 = Instance_HitTestBehavior
    //     0x874354: add             lr, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x874358: ldr             lr, [lr, #0x408]
    // 0x87435c: stp             lr, x16, [SP, #-0x10]!
    // 0x874360: stp             NULL, x0, [SP, #-0x10]!
    // 0x874364: r16 = true
    //     0x874364: add             x16, NULL, #0x20  ; true
    // 0x874368: ldur            lr, [fp, #-0x20]
    // 0x87436c: stp             lr, x16, [SP, #-0x10]!
    // 0x874370: r4 = const [0, 0x6, 0x6, 0x1, behavior, 0x1, child, 0x5, excludeFromSemantics, 0x4, onLongPress, 0x2, onTap, 0x3, null]
    //     0x874370: add             x4, PP, #0x50, lsl #12  ; [pp+0x503f8] List(15) [0, 0x6, 0x6, 0x1, "behavior", 0x1, "child", 0x5, "excludeFromSemantics", 0x4, "onLongPress", 0x2, "onTap", 0x3, Null]
    //     0x874374: ldr             x4, [x4, #0x3f8]
    // 0x874378: r0 = GestureDetector()
    //     0x874378: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x87437c: add             SP, SP, #0x30
    // 0x874380: ldr             x0, [fp, #0x18]
    // 0x874384: LoadField: r1 = r0->field_5b
    //     0x874384: ldur            w1, [x0, #0x5b]
    // 0x874388: DecompressPointer r1
    //     0x874388: add             x1, x1, HEAP, lsl #32
    // 0x87438c: r16 = Sentinel
    //     0x87438c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874390: cmp             w1, w16
    // 0x874394: b.eq            #0x8744a8
    // 0x874398: tbnz            w1, #4, #0x8743fc
    // 0x87439c: ldur            x0, [fp, #-0x10]
    // 0x8743a0: r0 = MouseRegion()
    //     0x8743a0: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0x8743a4: ldur            x2, [fp, #-8]
    // 0x8743a8: r1 = Function '<anonymous closure>':.
    //     0x8743a8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50400] AnonymousClosure: (0x8747a0), in [package:flutter/src/material/tooltip.dart] TooltipState::build (0x873ecc)
    //     0x8743ac: ldr             x1, [x1, #0x400]
    // 0x8743b0: stur            x0, [fp, #-0x18]
    // 0x8743b4: r0 = AllocateClosure()
    //     0x8743b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8743b8: mov             x1, x0
    // 0x8743bc: ldur            x0, [fp, #-0x18]
    // 0x8743c0: StoreField: r0->field_f = r1
    //     0x8743c0: stur            w1, [x0, #0xf]
    // 0x8743c4: ldur            x2, [fp, #-8]
    // 0x8743c8: r1 = Function '<anonymous closure>':.
    //     0x8743c8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50408] AnonymousClosure: (0x874694), in [package:flutter/src/material/tooltip.dart] TooltipState::build (0x873ecc)
    //     0x8743cc: ldr             x1, [x1, #0x408]
    // 0x8743d0: r0 = AllocateClosure()
    //     0x8743d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8743d4: ldur            x1, [fp, #-0x18]
    // 0x8743d8: StoreField: r1->field_17 = r0
    //     0x8743d8: stur            w0, [x1, #0x17]
    // 0x8743dc: r2 = Instance__DeferringMouseCursor
    //     0x8743dc: ldr             x2, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x8743e0: StoreField: r1->field_1b = r2
    //     0x8743e0: stur            w2, [x1, #0x1b]
    // 0x8743e4: r2 = true
    //     0x8743e4: add             x2, NULL, #0x20  ; true
    // 0x8743e8: StoreField: r1->field_1f = r2
    //     0x8743e8: stur            w2, [x1, #0x1f]
    // 0x8743ec: ldur            x2, [fp, #-0x10]
    // 0x8743f0: StoreField: r1->field_b = r2
    //     0x8743f0: stur            w2, [x1, #0xb]
    // 0x8743f4: mov             x0, x1
    // 0x8743f8: b               #0x874404
    // 0x8743fc: ldur            x2, [fp, #-0x10]
    // 0x874400: mov             x0, x2
    // 0x874404: LeaveFrame
    //     0x874404: mov             SP, fp
    //     0x874408: ldp             fp, lr, [SP], #0x10
    // 0x87440c: ret
    //     0x87440c: ret             
    // 0x874410: r4 = Null
    //     0x874410: mov             x4, NULL
    // 0x874414: cmp             w4, NULL
    // 0x874418: b.eq            #0x8744b4
    // 0x87441c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x87441c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x874420: r0 = Throw()
    //     0x874420: bl              #0xd67e38  ; ThrowStub
    // 0x874424: brk             #0
    // 0x874428: r0 = Null
    //     0x874428: mov             x0, NULL
    // 0x87442c: cmp             w0, NULL
    // 0x874430: b.eq            #0x8744b8
    // 0x874434: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x874434: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x874438: r0 = Throw()
    //     0x874438: bl              #0xd67e38  ; ThrowStub
    // 0x87443c: brk             #0
    // 0x874440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874444: b               #0x873ee4
    // 0x874448: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x874448: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87444c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87444c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x874450: r0 = NullCastErrorSharedWithFPURegs()
    //     0x874450: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x874454: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x874454: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x874458: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x874458: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87445c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87445c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x874460: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x874460: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x874464: SaveReg d0
    //     0x874464: str             q0, [SP, #-0x10]!
    // 0x874468: stp             x8, x9, [SP, #-0x10]!
    // 0x87446c: stp             x6, x7, [SP, #-0x10]!
    // 0x874470: stp             x4, x5, [SP, #-0x10]!
    // 0x874474: stp             x2, x3, [SP, #-0x10]!
    // 0x874478: SaveReg r1
    //     0x874478: str             x1, [SP, #-8]!
    // 0x87447c: r0 = AllocateDouble()
    //     0x87447c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x874480: RestoreReg r1
    //     0x874480: ldr             x1, [SP], #8
    // 0x874484: ldp             x2, x3, [SP], #0x10
    // 0x874488: ldp             x4, x5, [SP], #0x10
    // 0x87448c: ldp             x6, x7, [SP], #0x10
    // 0x874490: ldp             x8, x9, [SP], #0x10
    // 0x874494: RestoreReg d0
    //     0x874494: ldr             q0, [SP], #0x10
    // 0x874498: b               #0x874240
    // 0x87449c: r9 = _visible
    //     0x87449c: add             x9, PP, #0x50, lsl #12  ; [pp+0x50410] Field <TooltipState._visible@838220820>: late (offset: 0x74)
    //     0x8744a0: ldr             x9, [x9, #0x410]
    // 0x8744a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8744a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8744a8: r9 = _mouseIsConnected
    //     0x8744a8: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d110] Field <TooltipState._mouseIsConnected@838220820>: late (offset: 0x5c)
    //     0x8744ac: ldr             x9, [x9, #0x110]
    // 0x8744b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8744b0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8744b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8744b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8744b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8744b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getDefaultPadding(/* No info */) {
    // ** addr: 0x8744bc, size: 0x7c
    // 0x8744bc: EnterFrame
    //     0x8744bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8744c0: mov             fp, SP
    // 0x8744c4: CheckStackOverflow
    //     0x8744c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8744c8: cmp             SP, x16
    //     0x8744cc: b.ls            #0x87452c
    // 0x8744d0: ldr             x0, [fp, #0x10]
    // 0x8744d4: LoadField: r1 = r0->field_f
    //     0x8744d4: ldur            w1, [x0, #0xf]
    // 0x8744d8: DecompressPointer r1
    //     0x8744d8: add             x1, x1, HEAP, lsl #32
    // 0x8744dc: cmp             w1, NULL
    // 0x8744e0: b.eq            #0x874534
    // 0x8744e4: SaveReg r1
    //     0x8744e4: str             x1, [SP, #-8]!
    // 0x8744e8: r0 = of()
    //     0x8744e8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8744ec: add             SP, SP, #8
    // 0x8744f0: LoadField: r1 = r0->field_1f
    //     0x8744f0: ldur            w1, [x0, #0x1f]
    // 0x8744f4: DecompressPointer r1
    //     0x8744f4: add             x1, x1, HEAP, lsl #32
    // 0x8744f8: LoadField: r2 = r1->field_7
    //     0x8744f8: ldur            x2, [x1, #7]
    // 0x8744fc: cmp             x2, #2
    // 0x874500: b.gt            #0x874518
    // 0x874504: r0 = Instance_EdgeInsets
    //     0x874504: add             x0, PP, #0x50, lsl #12  ; [pp+0x504d0] Obj!EdgeInsets@b35e11
    //     0x874508: ldr             x0, [x0, #0x4d0]
    // 0x87450c: LeaveFrame
    //     0x87450c: mov             SP, fp
    //     0x874510: ldp             fp, lr, [SP], #0x10
    // 0x874514: ret
    //     0x874514: ret             
    // 0x874518: r0 = Instance_EdgeInsets
    //     0x874518: add             x0, PP, #0x27, lsl #12  ; [pp+0x278c8] Obj!EdgeInsets@b35e41
    //     0x87451c: ldr             x0, [x0, #0x8c8]
    // 0x874520: LeaveFrame
    //     0x874520: mov             SP, fp
    //     0x874524: ldp             fp, lr, [SP], #0x10
    // 0x874528: ret
    //     0x874528: ret             
    // 0x87452c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87452c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874530: b               #0x8744d0
    // 0x874534: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x874534: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getDefaultTooltipHeight(/* No info */) {
    // ** addr: 0x874538, size: 0x7c
    // 0x874538: EnterFrame
    //     0x874538: stp             fp, lr, [SP, #-0x10]!
    //     0x87453c: mov             fp, SP
    // 0x874540: CheckStackOverflow
    //     0x874540: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x874544: cmp             SP, x16
    //     0x874548: b.ls            #0x8745a8
    // 0x87454c: ldr             x0, [fp, #0x10]
    // 0x874550: LoadField: r1 = r0->field_f
    //     0x874550: ldur            w1, [x0, #0xf]
    // 0x874554: DecompressPointer r1
    //     0x874554: add             x1, x1, HEAP, lsl #32
    // 0x874558: cmp             w1, NULL
    // 0x87455c: b.eq            #0x8745b0
    // 0x874560: SaveReg r1
    //     0x874560: str             x1, [SP, #-8]!
    // 0x874564: r0 = of()
    //     0x874564: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x874568: add             SP, SP, #8
    // 0x87456c: LoadField: r1 = r0->field_1f
    //     0x87456c: ldur            w1, [x0, #0x1f]
    // 0x874570: DecompressPointer r1
    //     0x874570: add             x1, x1, HEAP, lsl #32
    // 0x874574: LoadField: r2 = r1->field_7
    //     0x874574: ldur            x2, [x1, #7]
    // 0x874578: cmp             x2, #2
    // 0x87457c: b.gt            #0x874594
    // 0x874580: r0 = 32.000000
    //     0x874580: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2b080] 32
    //     0x874584: ldr             x0, [x0, #0x80]
    // 0x874588: LeaveFrame
    //     0x874588: mov             SP, fp
    //     0x87458c: ldp             fp, lr, [SP], #0x10
    // 0x874590: ret
    //     0x874590: ret             
    // 0x874594: r0 = 24.000000
    //     0x874594: add             x0, PP, #0xe, lsl #12  ; [pp+0xe360] 24
    //     0x874598: ldr             x0, [x0, #0x360]
    // 0x87459c: LeaveFrame
    //     0x87459c: mov             SP, fp
    //     0x8745a0: ldp             fp, lr, [SP], #0x10
    // 0x8745a4: ret
    //     0x8745a4: ret             
    // 0x8745a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8745a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8745ac: b               #0x87454c
    // 0x8745b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8745b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getDefaultFontSize(/* No info */) {
    // ** addr: 0x8745b4, size: 0x7c
    // 0x8745b4: EnterFrame
    //     0x8745b4: stp             fp, lr, [SP, #-0x10]!
    //     0x8745b8: mov             fp, SP
    // 0x8745bc: CheckStackOverflow
    //     0x8745bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8745c0: cmp             SP, x16
    //     0x8745c4: b.ls            #0x874624
    // 0x8745c8: ldr             x0, [fp, #0x10]
    // 0x8745cc: LoadField: r1 = r0->field_f
    //     0x8745cc: ldur            w1, [x0, #0xf]
    // 0x8745d0: DecompressPointer r1
    //     0x8745d0: add             x1, x1, HEAP, lsl #32
    // 0x8745d4: cmp             w1, NULL
    // 0x8745d8: b.eq            #0x87462c
    // 0x8745dc: SaveReg r1
    //     0x8745dc: str             x1, [SP, #-8]!
    // 0x8745e0: r0 = of()
    //     0x8745e0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8745e4: add             SP, SP, #8
    // 0x8745e8: LoadField: r1 = r0->field_1f
    //     0x8745e8: ldur            w1, [x0, #0x1f]
    // 0x8745ec: DecompressPointer r1
    //     0x8745ec: add             x1, x1, HEAP, lsl #32
    // 0x8745f0: LoadField: r2 = r1->field_7
    //     0x8745f0: ldur            x2, [x1, #7]
    // 0x8745f4: cmp             x2, #2
    // 0x8745f8: b.gt            #0x874610
    // 0x8745fc: r0 = 14.000000
    //     0x8745fc: add             x0, PP, #0x26, lsl #12  ; [pp+0x261c8] 14
    //     0x874600: ldr             x0, [x0, #0x1c8]
    // 0x874604: LeaveFrame
    //     0x874604: mov             SP, fp
    //     0x874608: ldp             fp, lr, [SP], #0x10
    // 0x87460c: ret
    //     0x87460c: ret             
    // 0x874610: r0 = 12.000000
    //     0x874610: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1fd90] 12
    //     0x874614: ldr             x0, [x0, #0xd90]
    // 0x874618: LeaveFrame
    //     0x874618: mov             SP, fp
    //     0x87461c: ldp             fp, lr, [SP], #0x10
    // 0x874620: ret
    //     0x874620: ret             
    // 0x874624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874628: b               #0x8745c8
    // 0x87462c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87462c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PointerExitEvent) {
    // ** addr: 0x874694, size: 0x4c
    // 0x874694: EnterFrame
    //     0x874694: stp             fp, lr, [SP, #-0x10]!
    //     0x874698: mov             fp, SP
    // 0x87469c: ldr             x0, [fp, #0x18]
    // 0x8746a0: LoadField: r1 = r0->field_17
    //     0x8746a0: ldur            w1, [x0, #0x17]
    // 0x8746a4: DecompressPointer r1
    //     0x8746a4: add             x1, x1, HEAP, lsl #32
    // 0x8746a8: CheckStackOverflow
    //     0x8746a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8746ac: cmp             SP, x16
    //     0x8746b0: b.ls            #0x8746d8
    // 0x8746b4: LoadField: r0 = r1->field_f
    //     0x8746b4: ldur            w0, [x1, #0xf]
    // 0x8746b8: DecompressPointer r0
    //     0x8746b8: add             x0, x0, HEAP, lsl #32
    // 0x8746bc: SaveReg r0
    //     0x8746bc: str             x0, [SP, #-8]!
    // 0x8746c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8746c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8746c4: r0 = _handleMouseExit()
    //     0x8746c4: bl              #0x8746e0  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseExit
    // 0x8746c8: add             SP, SP, #8
    // 0x8746cc: LeaveFrame
    //     0x8746cc: mov             SP, fp
    //     0x8746d0: ldp             fp, lr, [SP], #0x10
    // 0x8746d4: ret
    //     0x8746d4: ret             
    // 0x8746d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8746d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8746dc: b               #0x8746b4
  }
  _ _handleMouseExit(/* No info */) {
    // ** addr: 0x8746e0, size: 0xc0
    // 0x8746e0: EnterFrame
    //     0x8746e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8746e4: mov             fp, SP
    // 0x8746e8: mov             x0, x4
    // 0x8746ec: LoadField: r1 = r0->field_13
    //     0x8746ec: ldur            w1, [x0, #0x13]
    // 0x8746f0: DecompressPointer r1
    //     0x8746f0: add             x1, x1, HEAP, lsl #32
    // 0x8746f4: sub             x2, x1, #2
    // 0x8746f8: add             x3, fp, w2, sxtw #2
    // 0x8746fc: ldr             x3, [x3, #0x10]
    // 0x874700: LoadField: r2 = r0->field_1f
    //     0x874700: ldur            w2, [x0, #0x1f]
    // 0x874704: DecompressPointer r2
    //     0x874704: add             x2, x2, HEAP, lsl #32
    // 0x874708: r16 = "immediately"
    //     0x874708: add             x16, PP, #0x50, lsl #12  ; [pp+0x50418] "immediately"
    //     0x87470c: ldr             x16, [x16, #0x418]
    // 0x874710: cmp             w2, w16
    // 0x874714: b.ne            #0x874734
    // 0x874718: LoadField: r2 = r0->field_23
    //     0x874718: ldur            w2, [x0, #0x23]
    // 0x87471c: DecompressPointer r2
    //     0x87471c: add             x2, x2, HEAP, lsl #32
    // 0x874720: sub             w0, w1, w2
    // 0x874724: add             x1, fp, w0, sxtw #2
    // 0x874728: ldr             x1, [x1, #8]
    // 0x87472c: mov             x0, x1
    // 0x874730: b               #0x874738
    // 0x874734: r0 = false
    //     0x874734: add             x0, NULL, #0x30  ; false
    // 0x874738: CheckStackOverflow
    //     0x874738: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87473c: cmp             SP, x16
    //     0x874740: b.ls            #0x87478c
    // 0x874744: LoadField: r1 = r3->field_f
    //     0x874744: ldur            w1, [x3, #0xf]
    // 0x874748: DecompressPointer r1
    //     0x874748: add             x1, x1, HEAP, lsl #32
    // 0x87474c: cmp             w1, NULL
    // 0x874750: b.eq            #0x87477c
    // 0x874754: LoadField: r1 = r3->field_6b
    //     0x874754: ldur            w1, [x3, #0x6b]
    // 0x874758: DecompressPointer r1
    //     0x874758: add             x1, x1, HEAP, lsl #32
    // 0x87475c: r16 = Sentinel
    //     0x87475c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874760: cmp             w1, w16
    // 0x874764: b.eq            #0x874794
    // 0x874768: tbnz            w1, #4, #0x874770
    // 0x87476c: r0 = true
    //     0x87476c: add             x0, NULL, #0x20  ; true
    // 0x874770: stp             x0, x3, [SP, #-0x10]!
    // 0x874774: r0 = _dismissTooltip()
    //     0x874774: bl              #0x795d10  ; [package:flutter/src/material/tooltip.dart] TooltipState::_dismissTooltip
    // 0x874778: add             SP, SP, #0x10
    // 0x87477c: r0 = Null
    //     0x87477c: mov             x0, NULL
    // 0x874780: LeaveFrame
    //     0x874780: mov             SP, fp
    //     0x874784: ldp             fp, lr, [SP], #0x10
    // 0x874788: ret
    //     0x874788: ret             
    // 0x87478c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87478c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874790: b               #0x874744
    // 0x874794: r9 = _isConcealed
    //     0x874794: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d108] Field <TooltipState._isConcealed@838220820>: late (offset: 0x6c)
    //     0x874798: ldr             x9, [x9, #0x108]
    // 0x87479c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87479c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PointerEnterEvent) {
    // ** addr: 0x8747a0, size: 0x48
    // 0x8747a0: EnterFrame
    //     0x8747a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8747a4: mov             fp, SP
    // 0x8747a8: ldr             x0, [fp, #0x18]
    // 0x8747ac: LoadField: r1 = r0->field_17
    //     0x8747ac: ldur            w1, [x0, #0x17]
    // 0x8747b0: DecompressPointer r1
    //     0x8747b0: add             x1, x1, HEAP, lsl #32
    // 0x8747b4: CheckStackOverflow
    //     0x8747b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8747b8: cmp             SP, x16
    //     0x8747bc: b.ls            #0x8747e0
    // 0x8747c0: LoadField: r0 = r1->field_f
    //     0x8747c0: ldur            w0, [x1, #0xf]
    // 0x8747c4: DecompressPointer r0
    //     0x8747c4: add             x0, x0, HEAP, lsl #32
    // 0x8747c8: SaveReg r0
    //     0x8747c8: str             x0, [SP, #-8]!
    // 0x8747cc: r0 = _handleMouseEnter()
    //     0x8747cc: bl              #0x8747e8  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseEnter
    // 0x8747d0: add             SP, SP, #8
    // 0x8747d4: LeaveFrame
    //     0x8747d4: mov             SP, fp
    //     0x8747d8: ldp             fp, lr, [SP], #0x10
    // 0x8747dc: ret
    //     0x8747dc: ret             
    // 0x8747e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8747e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8747e4: b               #0x8747c0
  }
  _ _handleMouseEnter(/* No info */) {
    // ** addr: 0x8747e8, size: 0x4c
    // 0x8747e8: EnterFrame
    //     0x8747e8: stp             fp, lr, [SP, #-0x10]!
    //     0x8747ec: mov             fp, SP
    // 0x8747f0: CheckStackOverflow
    //     0x8747f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8747f4: cmp             SP, x16
    //     0x8747f8: b.ls            #0x87482c
    // 0x8747fc: ldr             x0, [fp, #0x10]
    // 0x874800: LoadField: r1 = r0->field_f
    //     0x874800: ldur            w1, [x0, #0xf]
    // 0x874804: DecompressPointer r1
    //     0x874804: add             x1, x1, HEAP, lsl #32
    // 0x874808: cmp             w1, NULL
    // 0x87480c: b.eq            #0x87481c
    // 0x874810: SaveReg r0
    //     0x874810: str             x0, [SP, #-8]!
    // 0x874814: r0 = _showTooltip()
    //     0x874814: bl              #0x874834  ; [package:flutter/src/material/tooltip.dart] TooltipState::_showTooltip
    // 0x874818: add             SP, SP, #8
    // 0x87481c: r0 = Null
    //     0x87481c: mov             x0, NULL
    // 0x874820: LeaveFrame
    //     0x874820: mov             SP, fp
    //     0x874824: ldp             fp, lr, [SP], #0x10
    // 0x874828: ret
    //     0x874828: ret             
    // 0x87482c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87482c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874830: b               #0x8747fc
  }
  _ _showTooltip(/* No info */) {
    // ** addr: 0x874834, size: 0xdc
    // 0x874834: EnterFrame
    //     0x874834: stp             fp, lr, [SP, #-0x10]!
    //     0x874838: mov             fp, SP
    // 0x87483c: CheckStackOverflow
    //     0x87483c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x874840: cmp             SP, x16
    //     0x874844: b.ls            #0x8748fc
    // 0x874848: ldr             x0, [fp, #0x10]
    // 0x87484c: LoadField: r1 = r0->field_47
    //     0x87484c: ldur            w1, [x0, #0x47]
    // 0x874850: DecompressPointer r1
    //     0x874850: add             x1, x1, HEAP, lsl #32
    // 0x874854: cmp             w1, NULL
    // 0x874858: b.eq            #0x87486c
    // 0x87485c: SaveReg r1
    //     0x87485c: str             x1, [SP, #-8]!
    // 0x874860: r0 = cancel()
    //     0x874860: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x874864: add             SP, SP, #8
    // 0x874868: ldr             x0, [fp, #0x10]
    // 0x87486c: StoreField: r0->field_47 = rNULL
    //     0x87486c: stur            NULL, [x0, #0x47]
    // 0x874870: LoadField: r1 = r0->field_4b
    //     0x874870: ldur            w1, [x0, #0x4b]
    // 0x874874: DecompressPointer r1
    //     0x874874: add             x1, x1, HEAP, lsl #32
    // 0x874878: cmp             w1, NULL
    // 0x87487c: b.ne            #0x8748ec
    // 0x874880: LoadField: r1 = r0->field_57
    //     0x874880: ldur            w1, [x0, #0x57]
    // 0x874884: DecompressPointer r1
    //     0x874884: add             x1, x1, HEAP, lsl #32
    // 0x874888: r16 = Sentinel
    //     0x874888: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x87488c: cmp             w1, w16
    // 0x874890: b.eq            #0x874904
    // 0x874894: r1 = 1
    //     0x874894: mov             x1, #1
    // 0x874898: r0 = AllocateContext()
    //     0x874898: bl              #0xd68aa4  ; AllocateContextStub
    // 0x87489c: mov             x1, x0
    // 0x8748a0: ldr             x0, [fp, #0x10]
    // 0x8748a4: StoreField: r1->field_f = r0
    //     0x8748a4: stur            w0, [x1, #0xf]
    // 0x8748a8: mov             x2, x1
    // 0x8748ac: r1 = Function 'ensureTooltipVisible':.
    //     0x8748ac: add             x1, PP, #0x50, lsl #12  ; [pp+0x50440] AnonymousClosure: (0x874910), in [package:flutter/src/material/tooltip.dart] TooltipState::ensureTooltipVisible (0x874958)
    //     0x8748b0: ldr             x1, [x1, #0x440]
    // 0x8748b4: r0 = AllocateClosure()
    //     0x8748b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8748b8: r16 = Instance_Duration
    //     0x8748b8: ldr             x16, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x8748bc: stp             x16, NULL, [SP, #-0x10]!
    // 0x8748c0: SaveReg r0
    //     0x8748c0: str             x0, [SP, #-8]!
    // 0x8748c4: r0 = Timer()
    //     0x8748c4: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x8748c8: add             SP, SP, #0x18
    // 0x8748cc: ldr             x1, [fp, #0x10]
    // 0x8748d0: StoreField: r1->field_4b = r0
    //     0x8748d0: stur            w0, [x1, #0x4b]
    //     0x8748d4: ldurb           w16, [x1, #-1]
    //     0x8748d8: ldurb           w17, [x0, #-1]
    //     0x8748dc: and             x16, x17, x16, lsr #2
    //     0x8748e0: tst             x16, HEAP, lsr #32
    //     0x8748e4: b.eq            #0x8748ec
    //     0x8748e8: bl              #0xd6826c
    // 0x8748ec: r0 = Null
    //     0x8748ec: mov             x0, NULL
    // 0x8748f0: LeaveFrame
    //     0x8748f0: mov             SP, fp
    //     0x8748f4: ldp             fp, lr, [SP], #0x10
    // 0x8748f8: ret
    //     0x8748f8: ret             
    // 0x8748fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8748fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874900: b               #0x874848
    // 0x874904: r9 = _waitDuration
    //     0x874904: add             x9, PP, #0x50, lsl #12  ; [pp+0x50448] Field <TooltipState._waitDuration@838220820>: late (offset: 0x58)
    //     0x874908: ldr             x9, [x9, #0x448]
    // 0x87490c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87490c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] bool ensureTooltipVisible(dynamic) {
    // ** addr: 0x874910, size: 0x48
    // 0x874910: EnterFrame
    //     0x874910: stp             fp, lr, [SP, #-0x10]!
    //     0x874914: mov             fp, SP
    // 0x874918: ldr             x0, [fp, #0x10]
    // 0x87491c: LoadField: r1 = r0->field_17
    //     0x87491c: ldur            w1, [x0, #0x17]
    // 0x874920: DecompressPointer r1
    //     0x874920: add             x1, x1, HEAP, lsl #32
    // 0x874924: CheckStackOverflow
    //     0x874924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x874928: cmp             SP, x16
    //     0x87492c: b.ls            #0x874950
    // 0x874930: LoadField: r0 = r1->field_f
    //     0x874930: ldur            w0, [x1, #0xf]
    // 0x874934: DecompressPointer r0
    //     0x874934: add             x0, x0, HEAP, lsl #32
    // 0x874938: SaveReg r0
    //     0x874938: str             x0, [SP, #-8]!
    // 0x87493c: r0 = ensureTooltipVisible()
    //     0x87493c: bl              #0x874958  ; [package:flutter/src/material/tooltip.dart] TooltipState::ensureTooltipVisible
    // 0x874940: add             SP, SP, #8
    // 0x874944: LeaveFrame
    //     0x874944: mov             SP, fp
    //     0x874948: ldp             fp, lr, [SP], #0x10
    // 0x87494c: ret
    //     0x87494c: ret             
    // 0x874950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874954: b               #0x874930
  }
  _ ensureTooltipVisible(/* No info */) {
    // ** addr: 0x874958, size: 0x1c4
    // 0x874958: EnterFrame
    //     0x874958: stp             fp, lr, [SP, #-0x10]!
    //     0x87495c: mov             fp, SP
    // 0x874960: CheckStackOverflow
    //     0x874960: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x874964: cmp             SP, x16
    //     0x874968: b.ls            #0x874ad8
    // 0x87496c: ldr             x0, [fp, #0x10]
    // 0x874970: LoadField: r1 = r0->field_73
    //     0x874970: ldur            w1, [x0, #0x73]
    // 0x874974: DecompressPointer r1
    //     0x874974: add             x1, x1, HEAP, lsl #32
    // 0x874978: r16 = Sentinel
    //     0x874978: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x87497c: cmp             w1, w16
    // 0x874980: b.eq            #0x874ae0
    // 0x874984: LoadField: r1 = r0->field_f
    //     0x874984: ldur            w1, [x0, #0xf]
    // 0x874988: DecompressPointer r1
    //     0x874988: add             x1, x1, HEAP, lsl #32
    // 0x87498c: cmp             w1, NULL
    // 0x874990: b.ne            #0x8749a4
    // 0x874994: r0 = false
    //     0x874994: add             x0, NULL, #0x30  ; false
    // 0x874998: LeaveFrame
    //     0x874998: mov             SP, fp
    //     0x87499c: ldp             fp, lr, [SP], #0x10
    // 0x8749a0: ret
    //     0x8749a0: ret             
    // 0x8749a4: LoadField: r1 = r0->field_4b
    //     0x8749a4: ldur            w1, [x0, #0x4b]
    // 0x8749a8: DecompressPointer r1
    //     0x8749a8: add             x1, x1, HEAP, lsl #32
    // 0x8749ac: cmp             w1, NULL
    // 0x8749b0: b.eq            #0x8749c4
    // 0x8749b4: SaveReg r1
    //     0x8749b4: str             x1, [SP, #-8]!
    // 0x8749b8: r0 = cancel()
    //     0x8749b8: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x8749bc: add             SP, SP, #8
    // 0x8749c0: ldr             x0, [fp, #0x10]
    // 0x8749c4: r1 = false
    //     0x8749c4: add             x1, NULL, #0x30  ; false
    // 0x8749c8: StoreField: r0->field_4b = rNULL
    //     0x8749c8: stur            NULL, [x0, #0x4b]
    // 0x8749cc: StoreField: r0->field_6f = r1
    //     0x8749cc: stur            w1, [x0, #0x6f]
    // 0x8749d0: LoadField: r2 = r0->field_6b
    //     0x8749d0: ldur            w2, [x0, #0x6b]
    // 0x8749d4: DecompressPointer r2
    //     0x8749d4: add             x2, x2, HEAP, lsl #32
    // 0x8749d8: r16 = Sentinel
    //     0x8749d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8749dc: cmp             w2, w16
    // 0x8749e0: b.eq            #0x874aec
    // 0x8749e4: tbnz            w2, #4, #0x874a2c
    // 0x8749e8: LoadField: r1 = r0->field_5b
    //     0x8749e8: ldur            w1, [x0, #0x5b]
    // 0x8749ec: DecompressPointer r1
    //     0x8749ec: add             x1, x1, HEAP, lsl #32
    // 0x8749f0: r16 = Sentinel
    //     0x8749f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8749f4: cmp             w1, w16
    // 0x8749f8: b.eq            #0x874af8
    // 0x8749fc: tbnz            w1, #4, #0x874a0c
    // 0x874a00: SaveReg r0
    //     0x874a00: str             x0, [SP, #-8]!
    // 0x874a04: r0 = _concealOtherTooltips()
    //     0x874a04: bl              #0x8757b8  ; [package:flutter/src/material/tooltip.dart] Tooltip::_concealOtherTooltips
    // 0x874a08: add             SP, SP, #8
    // 0x874a0c: ldr             x16, [fp, #0x10]
    // 0x874a10: SaveReg r16
    //     0x874a10: str             x16, [SP, #-8]!
    // 0x874a14: r0 = _revealTooltip()
    //     0x874a14: bl              #0x7960d8  ; [package:flutter/src/material/tooltip.dart] TooltipState::_revealTooltip
    // 0x874a18: add             SP, SP, #8
    // 0x874a1c: r0 = true
    //     0x874a1c: add             x0, NULL, #0x20  ; true
    // 0x874a20: LeaveFrame
    //     0x874a20: mov             SP, fp
    //     0x874a24: ldp             fp, lr, [SP], #0x10
    // 0x874a28: ret
    //     0x874a28: ret             
    // 0x874a2c: LoadField: r2 = r0->field_43
    //     0x874a2c: ldur            w2, [x0, #0x43]
    // 0x874a30: DecompressPointer r2
    //     0x874a30: add             x2, x2, HEAP, lsl #32
    // 0x874a34: cmp             w2, NULL
    // 0x874a38: b.eq            #0x874a94
    // 0x874a3c: LoadField: r2 = r0->field_47
    //     0x874a3c: ldur            w2, [x0, #0x47]
    // 0x874a40: DecompressPointer r2
    //     0x874a40: add             x2, x2, HEAP, lsl #32
    // 0x874a44: cmp             w2, NULL
    // 0x874a48: b.eq            #0x874a5c
    // 0x874a4c: SaveReg r2
    //     0x874a4c: str             x2, [SP, #-8]!
    // 0x874a50: r0 = cancel()
    //     0x874a50: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x874a54: add             SP, SP, #8
    // 0x874a58: ldr             x0, [fp, #0x10]
    // 0x874a5c: StoreField: r0->field_47 = rNULL
    //     0x874a5c: stur            NULL, [x0, #0x47]
    // 0x874a60: LoadField: r1 = r0->field_3f
    //     0x874a60: ldur            w1, [x0, #0x3f]
    // 0x874a64: DecompressPointer r1
    //     0x874a64: add             x1, x1, HEAP, lsl #32
    // 0x874a68: r16 = Sentinel
    //     0x874a68: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874a6c: cmp             w1, w16
    // 0x874a70: b.eq            #0x874b04
    // 0x874a74: SaveReg r1
    //     0x874a74: str             x1, [SP, #-8]!
    // 0x874a78: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x874a78: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x874a7c: r0 = forward()
    //     0x874a7c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x874a80: add             SP, SP, #8
    // 0x874a84: r0 = false
    //     0x874a84: add             x0, NULL, #0x30  ; false
    // 0x874a88: LeaveFrame
    //     0x874a88: mov             SP, fp
    //     0x874a8c: ldp             fp, lr, [SP], #0x10
    // 0x874a90: ret
    //     0x874a90: ret             
    // 0x874a94: SaveReg r0
    //     0x874a94: str             x0, [SP, #-8]!
    // 0x874a98: r0 = _createNewEntry()
    //     0x874a98: bl              #0x874b1c  ; [package:flutter/src/material/tooltip.dart] TooltipState::_createNewEntry
    // 0x874a9c: add             SP, SP, #8
    // 0x874aa0: ldr             x0, [fp, #0x10]
    // 0x874aa4: LoadField: r1 = r0->field_3f
    //     0x874aa4: ldur            w1, [x0, #0x3f]
    // 0x874aa8: DecompressPointer r1
    //     0x874aa8: add             x1, x1, HEAP, lsl #32
    // 0x874aac: r16 = Sentinel
    //     0x874aac: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874ab0: cmp             w1, w16
    // 0x874ab4: b.eq            #0x874b10
    // 0x874ab8: SaveReg r1
    //     0x874ab8: str             x1, [SP, #-8]!
    // 0x874abc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x874abc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x874ac0: r0 = forward()
    //     0x874ac0: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x874ac4: add             SP, SP, #8
    // 0x874ac8: r0 = true
    //     0x874ac8: add             x0, NULL, #0x20  ; true
    // 0x874acc: LeaveFrame
    //     0x874acc: mov             SP, fp
    //     0x874ad0: ldp             fp, lr, [SP], #0x10
    // 0x874ad4: ret
    //     0x874ad4: ret             
    // 0x874ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x874ad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x874adc: b               #0x87496c
    // 0x874ae0: r9 = _visible
    //     0x874ae0: add             x9, PP, #0x50, lsl #12  ; [pp+0x50410] Field <TooltipState._visible@838220820>: late (offset: 0x74)
    //     0x874ae4: ldr             x9, [x9, #0x410]
    // 0x874ae8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x874ae8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x874aec: r9 = _isConcealed
    //     0x874aec: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d108] Field <TooltipState._isConcealed@838220820>: late (offset: 0x6c)
    //     0x874af0: ldr             x9, [x9, #0x108]
    // 0x874af4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x874af4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x874af8: r9 = _mouseIsConnected
    //     0x874af8: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d110] Field <TooltipState._mouseIsConnected@838220820>: late (offset: 0x5c)
    //     0x874afc: ldr             x9, [x9, #0x110]
    // 0x874b00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x874b00: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x874b04: r9 = _controller
    //     0x874b04: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x874b08: ldr             x9, [x9, #0x118]
    // 0x874b0c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x874b0c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x874b10: r9 = _controller
    //     0x874b10: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x874b14: ldr             x9, [x9, #0x118]
    // 0x874b18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x874b18: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _createNewEntry(/* No info */) {
    // ** addr: 0x874b1c, size: 0x628
    // 0x874b1c: EnterFrame
    //     0x874b1c: stp             fp, lr, [SP, #-0x10]!
    //     0x874b20: mov             fp, SP
    // 0x874b24: AllocStack(0x70)
    //     0x874b24: sub             SP, SP, #0x70
    // 0x874b28: CheckStackOverflow
    //     0x874b28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x874b2c: cmp             SP, x16
    //     0x874b30: b.ls            #0x875098
    // 0x874b34: r1 = 2
    //     0x874b34: mov             x1, #2
    // 0x874b38: r0 = AllocateContext()
    //     0x874b38: bl              #0xd68aa4  ; AllocateContextStub
    // 0x874b3c: mov             x1, x0
    // 0x874b40: ldr             x0, [fp, #0x10]
    // 0x874b44: stur            x1, [fp, #-8]
    // 0x874b48: StoreField: r1->field_f = r0
    //     0x874b48: stur            w0, [x1, #0xf]
    // 0x874b4c: LoadField: r2 = r0->field_f
    //     0x874b4c: ldur            w2, [x0, #0xf]
    // 0x874b50: DecompressPointer r2
    //     0x874b50: add             x2, x2, HEAP, lsl #32
    // 0x874b54: cmp             w2, NULL
    // 0x874b58: b.eq            #0x8750a0
    // 0x874b5c: LoadField: r3 = r0->field_b
    //     0x874b5c: ldur            w3, [x0, #0xb]
    // 0x874b60: DecompressPointer r3
    //     0x874b60: add             x3, x3, HEAP, lsl #32
    // 0x874b64: cmp             w3, NULL
    // 0x874b68: b.eq            #0x8750a4
    // 0x874b6c: SaveReg r2
    //     0x874b6c: str             x2, [SP, #-8]!
    // 0x874b70: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x874b70: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x874b74: r0 = of()
    //     0x874b74: bl              #0x59424c  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x874b78: add             SP, SP, #8
    // 0x874b7c: mov             x1, x0
    // 0x874b80: ldr             x0, [fp, #0x10]
    // 0x874b84: stur            x1, [fp, #-0x10]
    // 0x874b88: LoadField: r2 = r0->field_f
    //     0x874b88: ldur            w2, [x0, #0xf]
    // 0x874b8c: DecompressPointer r2
    //     0x874b8c: add             x2, x2, HEAP, lsl #32
    // 0x874b90: cmp             w2, NULL
    // 0x874b94: b.eq            #0x8750a8
    // 0x874b98: SaveReg r2
    //     0x874b98: str             x2, [SP, #-8]!
    // 0x874b9c: r0 = findRenderObject()
    //     0x874b9c: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x874ba0: add             SP, SP, #8
    // 0x874ba4: mov             x3, x0
    // 0x874ba8: stur            x3, [fp, #-0x18]
    // 0x874bac: cmp             w3, NULL
    // 0x874bb0: b.eq            #0x8750ac
    // 0x874bb4: mov             x0, x3
    // 0x874bb8: r2 = Null
    //     0x874bb8: mov             x2, NULL
    // 0x874bbc: r1 = Null
    //     0x874bbc: mov             x1, NULL
    // 0x874bc0: r4 = LoadClassIdInstr(r0)
    //     0x874bc0: ldur            x4, [x0, #-1]
    //     0x874bc4: ubfx            x4, x4, #0xc, #0x14
    // 0x874bc8: sub             x4, x4, #0x965
    // 0x874bcc: cmp             x4, #0x8b
    // 0x874bd0: b.ls            #0x874be8
    // 0x874bd4: r8 = RenderBox
    //     0x874bd4: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x874bd8: ldr             x8, [x8, #0xfa0]
    // 0x874bdc: r3 = Null
    //     0x874bdc: add             x3, PP, #0x50, lsl #12  ; [pp+0x50450] Null
    //     0x874be0: ldr             x3, [x3, #0x450]
    // 0x874be4: r0 = RenderBox()
    //     0x874be4: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x874be8: ldur            x0, [fp, #-0x18]
    // 0x874bec: LoadField: r1 = r0->field_57
    //     0x874bec: ldur            w1, [x0, #0x57]
    // 0x874bf0: DecompressPointer r1
    //     0x874bf0: add             x1, x1, HEAP, lsl #32
    // 0x874bf4: cmp             w1, NULL
    // 0x874bf8: b.eq            #0x8750b0
    // 0x874bfc: SaveReg r1
    //     0x874bfc: str             x1, [SP, #-8]!
    // 0x874c00: r0 = center()
    //     0x874c00: bl              #0x64082c  ; [dart:ui] Size::center
    // 0x874c04: add             SP, SP, #8
    // 0x874c08: mov             x1, x0
    // 0x874c0c: ldur            x0, [fp, #-0x10]
    // 0x874c10: stur            x1, [fp, #-0x20]
    // 0x874c14: LoadField: r2 = r0->field_f
    //     0x874c14: ldur            w2, [x0, #0xf]
    // 0x874c18: DecompressPointer r2
    //     0x874c18: add             x2, x2, HEAP, lsl #32
    // 0x874c1c: cmp             w2, NULL
    // 0x874c20: b.eq            #0x8750b4
    // 0x874c24: SaveReg r2
    //     0x874c24: str             x2, [SP, #-8]!
    // 0x874c28: r0 = findRenderObject()
    //     0x874c28: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x874c2c: add             SP, SP, #8
    // 0x874c30: ldur            x16, [fp, #-0x18]
    // 0x874c34: ldur            lr, [fp, #-0x20]
    // 0x874c38: stp             lr, x16, [SP, #-0x10]!
    // 0x874c3c: SaveReg r0
    //     0x874c3c: str             x0, [SP, #-8]!
    // 0x874c40: r4 = const [0, 0x3, 0x3, 0x2, ancestor, 0x2, null]
    //     0x874c40: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1ca08] List(7) [0, 0x3, 0x3, 0x2, "ancestor", 0x2, Null]
    //     0x874c44: ldr             x4, [x4, #0xa08]
    // 0x874c48: r0 = localToGlobal()
    //     0x874c48: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0x874c4c: add             SP, SP, #0x18
    // 0x874c50: mov             x1, x0
    // 0x874c54: ldr             x0, [fp, #0x10]
    // 0x874c58: stur            x1, [fp, #-0x18]
    // 0x874c5c: LoadField: r2 = r0->field_f
    //     0x874c5c: ldur            w2, [x0, #0xf]
    // 0x874c60: DecompressPointer r2
    //     0x874c60: add             x2, x2, HEAP, lsl #32
    // 0x874c64: cmp             w2, NULL
    // 0x874c68: b.eq            #0x8750b8
    // 0x874c6c: SaveReg r2
    //     0x874c6c: str             x2, [SP, #-8]!
    // 0x874c70: r0 = of()
    //     0x874c70: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x874c74: add             SP, SP, #8
    // 0x874c78: mov             x1, x0
    // 0x874c7c: ldr             x0, [fp, #0x10]
    // 0x874c80: stur            x1, [fp, #-0x28]
    // 0x874c84: LoadField: r2 = r0->field_b
    //     0x874c84: ldur            w2, [x0, #0xb]
    // 0x874c88: DecompressPointer r2
    //     0x874c88: add             x2, x2, HEAP, lsl #32
    // 0x874c8c: cmp             w2, NULL
    // 0x874c90: b.eq            #0x8750bc
    // 0x874c94: LoadField: r3 = r2->field_b
    //     0x874c94: ldur            w3, [x2, #0xb]
    // 0x874c98: DecompressPointer r3
    //     0x874c98: add             x3, x3, HEAP, lsl #32
    // 0x874c9c: stur            x3, [fp, #-0x20]
    // 0x874ca0: r0 = TextSpan()
    //     0x874ca0: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x874ca4: mov             x3, x0
    // 0x874ca8: ldur            x0, [fp, #-0x20]
    // 0x874cac: stur            x3, [fp, #-0x40]
    // 0x874cb0: StoreField: r3->field_b = r0
    //     0x874cb0: stur            w0, [x3, #0xb]
    // 0x874cb4: r0 = Instance__DeferringMouseCursor
    //     0x874cb4: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x874cb8: StoreField: r3->field_17 = r0
    //     0x874cb8: stur            w0, [x3, #0x17]
    // 0x874cbc: ldr             x0, [fp, #0x10]
    // 0x874cc0: LoadField: r4 = r0->field_1b
    //     0x874cc0: ldur            w4, [x0, #0x1b]
    // 0x874cc4: DecompressPointer r4
    //     0x874cc4: add             x4, x4, HEAP, lsl #32
    // 0x874cc8: r16 = Sentinel
    //     0x874cc8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874ccc: cmp             w4, w16
    // 0x874cd0: b.eq            #0x8750c0
    // 0x874cd4: stur            x4, [fp, #-0x38]
    // 0x874cd8: LoadField: r5 = r0->field_1f
    //     0x874cd8: ldur            w5, [x0, #0x1f]
    // 0x874cdc: DecompressPointer r5
    //     0x874cdc: add             x5, x5, HEAP, lsl #32
    // 0x874ce0: r16 = Sentinel
    //     0x874ce0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874ce4: cmp             w5, w16
    // 0x874ce8: b.eq            #0x8750cc
    // 0x874cec: stur            x5, [fp, #-0x30]
    // 0x874cf0: LoadField: r1 = r0->field_23
    //     0x874cf0: ldur            w1, [x0, #0x23]
    // 0x874cf4: DecompressPointer r1
    //     0x874cf4: add             x1, x1, HEAP, lsl #32
    // 0x874cf8: r16 = Sentinel
    //     0x874cf8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874cfc: cmp             w1, w16
    // 0x874d00: b.eq            #0x8750d8
    // 0x874d04: LoadField: r6 = r0->field_5b
    //     0x874d04: ldur            w6, [x0, #0x5b]
    // 0x874d08: DecompressPointer r6
    //     0x874d08: add             x6, x6, HEAP, lsl #32
    // 0x874d0c: r16 = Sentinel
    //     0x874d0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874d10: cmp             w6, w16
    // 0x874d14: b.eq            #0x8750e4
    // 0x874d18: stur            x6, [fp, #-0x20]
    // 0x874d1c: tbnz            w6, #4, #0x874d38
    // 0x874d20: ldur            x2, [fp, #-8]
    // 0x874d24: r1 = Function '<anonymous closure>':.
    //     0x874d24: add             x1, PP, #0x50, lsl #12  ; [pp+0x50460] AnonymousClosure: (0x8747a0), in [package:flutter/src/material/tooltip.dart] TooltipState::build (0x873ecc)
    //     0x874d28: ldr             x1, [x1, #0x460]
    // 0x874d2c: r0 = AllocateClosure()
    //     0x874d2c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x874d30: mov             x3, x0
    // 0x874d34: b               #0x874d3c
    // 0x874d38: r3 = Null
    //     0x874d38: mov             x3, NULL
    // 0x874d3c: ldur            x0, [fp, #-0x20]
    // 0x874d40: stur            x3, [fp, #-0x48]
    // 0x874d44: tbnz            w0, #4, #0x874d60
    // 0x874d48: ldur            x2, [fp, #-8]
    // 0x874d4c: r1 = Function '<anonymous closure>':.
    //     0x874d4c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50468] AnonymousClosure: (0x874694), in [package:flutter/src/material/tooltip.dart] TooltipState::build (0x873ecc)
    //     0x874d50: ldr             x1, [x1, #0x468]
    // 0x874d54: r0 = AllocateClosure()
    //     0x874d54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x874d58: mov             x10, x0
    // 0x874d5c: b               #0x874d64
    // 0x874d60: r10 = Null
    //     0x874d60: mov             x10, NULL
    // 0x874d64: ldr             x3, [fp, #0x10]
    // 0x874d68: ldur            x8, [fp, #-8]
    // 0x874d6c: ldur            x7, [fp, #-0x18]
    // 0x874d70: ldur            x6, [fp, #-0x28]
    // 0x874d74: ldur            x0, [fp, #-0x48]
    // 0x874d78: ldur            x2, [fp, #-0x40]
    // 0x874d7c: ldur            x4, [fp, #-0x38]
    // 0x874d80: ldur            x5, [fp, #-0x30]
    // 0x874d84: stur            x10, [fp, #-0x60]
    // 0x874d88: LoadField: r11 = r3->field_27
    //     0x874d88: ldur            w11, [x3, #0x27]
    // 0x874d8c: DecompressPointer r11
    //     0x874d8c: add             x11, x11, HEAP, lsl #32
    // 0x874d90: r16 = Sentinel
    //     0x874d90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874d94: cmp             w11, w16
    // 0x874d98: b.eq            #0x8750f0
    // 0x874d9c: stur            x11, [fp, #-0x58]
    // 0x874da0: LoadField: r12 = r3->field_2b
    //     0x874da0: ldur            w12, [x3, #0x2b]
    // 0x874da4: DecompressPointer r12
    //     0x874da4: add             x12, x12, HEAP, lsl #32
    // 0x874da8: r16 = Sentinel
    //     0x874da8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874dac: cmp             w12, w16
    // 0x874db0: b.eq            #0x8750fc
    // 0x874db4: stur            x12, [fp, #-0x50]
    // 0x874db8: LoadField: r1 = r3->field_2f
    //     0x874db8: ldur            w1, [x3, #0x2f]
    // 0x874dbc: DecompressPointer r1
    //     0x874dbc: add             x1, x1, HEAP, lsl #32
    // 0x874dc0: r16 = Sentinel
    //     0x874dc0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874dc4: cmp             w1, w16
    // 0x874dc8: b.eq            #0x875108
    // 0x874dcc: LoadField: r13 = r3->field_3f
    //     0x874dcc: ldur            w13, [x3, #0x3f]
    // 0x874dd0: DecompressPointer r13
    //     0x874dd0: add             x13, x13, HEAP, lsl #32
    // 0x874dd4: r16 = Sentinel
    //     0x874dd4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874dd8: cmp             w13, w16
    // 0x874ddc: b.eq            #0x875114
    // 0x874de0: stur            x13, [fp, #-0x20]
    // 0x874de4: r1 = <double>
    //     0x874de4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x874de8: r0 = CurvedAnimation()
    //     0x874de8: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x874dec: stur            x0, [fp, #-0x68]
    // 0x874df0: r16 = Instance_Cubic
    //     0x874df0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x874df4: ldr             x16, [x16, #0x2c8]
    // 0x874df8: stp             x16, x0, [SP, #-0x10]!
    // 0x874dfc: ldur            x16, [fp, #-0x20]
    // 0x874e00: SaveReg r16
    //     0x874e00: str             x16, [SP, #-8]!
    // 0x874e04: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x874e04: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x874e08: r0 = CurvedAnimation()
    //     0x874e08: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x874e0c: add             SP, SP, #0x18
    // 0x874e10: ldr             x0, [fp, #0x10]
    // 0x874e14: LoadField: r1 = r0->field_33
    //     0x874e14: ldur            w1, [x0, #0x33]
    // 0x874e18: DecompressPointer r1
    //     0x874e18: add             x1, x1, HEAP, lsl #32
    // 0x874e1c: r16 = Sentinel
    //     0x874e1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874e20: cmp             w1, w16
    // 0x874e24: b.eq            #0x875120
    // 0x874e28: stur            x1, [fp, #-0x20]
    // 0x874e2c: LoadField: r2 = r0->field_37
    //     0x874e2c: ldur            w2, [x0, #0x37]
    // 0x874e30: DecompressPointer r2
    //     0x874e30: add             x2, x2, HEAP, lsl #32
    // 0x874e34: r16 = Sentinel
    //     0x874e34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x874e38: cmp             w2, w16
    // 0x874e3c: b.eq            #0x87512c
    // 0x874e40: ldur            x2, [fp, #-0x38]
    // 0x874e44: LoadField: d0 = r2->field_7
    //     0x874e44: ldur            d0, [x2, #7]
    // 0x874e48: stur            d0, [fp, #-0x70]
    // 0x874e4c: r0 = _TooltipOverlay()
    //     0x874e4c: bl              #0x875150  ; Allocate_TooltipOverlayStub -> _TooltipOverlay (size=0x48)
    // 0x874e50: ldur            d0, [fp, #-0x70]
    // 0x874e54: stur            x0, [fp, #-0x38]
    // 0x874e58: StoreField: r0->field_f = d0
    //     0x874e58: stur            d0, [x0, #0xf]
    // 0x874e5c: ldur            x1, [fp, #-0x40]
    // 0x874e60: StoreField: r0->field_b = r1
    //     0x874e60: stur            w1, [x0, #0xb]
    // 0x874e64: ldur            x1, [fp, #-0x30]
    // 0x874e68: StoreField: r0->field_17 = r1
    //     0x874e68: stur            w1, [x0, #0x17]
    // 0x874e6c: r1 = Instance_EdgeInsets
    //     0x874e6c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0x874e70: ldr             x1, [x1, #0xbd8]
    // 0x874e74: StoreField: r0->field_1b = r1
    //     0x874e74: stur            w1, [x0, #0x1b]
    // 0x874e78: ldur            x1, [fp, #-0x58]
    // 0x874e7c: StoreField: r0->field_1f = r1
    //     0x874e7c: stur            w1, [x0, #0x1f]
    // 0x874e80: ldur            x1, [fp, #-0x50]
    // 0x874e84: StoreField: r0->field_23 = r1
    //     0x874e84: stur            w1, [x0, #0x23]
    // 0x874e88: r1 = Instance_TextAlign
    //     0x874e88: add             x1, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x874e8c: ldr             x1, [x1, #0xfe8]
    // 0x874e90: StoreField: r0->field_27 = r1
    //     0x874e90: stur            w1, [x0, #0x27]
    // 0x874e94: ldur            x1, [fp, #-0x68]
    // 0x874e98: StoreField: r0->field_2b = r1
    //     0x874e98: stur            w1, [x0, #0x2b]
    // 0x874e9c: ldur            x1, [fp, #-0x18]
    // 0x874ea0: StoreField: r0->field_2f = r1
    //     0x874ea0: stur            w1, [x0, #0x2f]
    // 0x874ea4: ldur            x1, [fp, #-0x20]
    // 0x874ea8: LoadField: d0 = r1->field_7
    //     0x874ea8: ldur            d0, [x1, #7]
    // 0x874eac: StoreField: r0->field_33 = d0
    //     0x874eac: stur            d0, [x0, #0x33]
    // 0x874eb0: r1 = true
    //     0x874eb0: add             x1, NULL, #0x20  ; true
    // 0x874eb4: StoreField: r0->field_3b = r1
    //     0x874eb4: stur            w1, [x0, #0x3b]
    // 0x874eb8: ldur            x1, [fp, #-0x48]
    // 0x874ebc: StoreField: r0->field_3f = r1
    //     0x874ebc: stur            w1, [x0, #0x3f]
    // 0x874ec0: ldur            x1, [fp, #-0x60]
    // 0x874ec4: StoreField: r0->field_43 = r1
    //     0x874ec4: stur            w1, [x0, #0x43]
    // 0x874ec8: r0 = Directionality()
    //     0x874ec8: bl              #0x875144  ; AllocateDirectionalityStub -> Directionality (size=0x14)
    // 0x874ecc: mov             x1, x0
    // 0x874ed0: ldur            x0, [fp, #-0x28]
    // 0x874ed4: StoreField: r1->field_f = r0
    //     0x874ed4: stur            w0, [x1, #0xf]
    // 0x874ed8: ldur            x0, [fp, #-0x38]
    // 0x874edc: StoreField: r1->field_b = r0
    //     0x874edc: stur            w0, [x1, #0xb]
    // 0x874ee0: mov             x0, x1
    // 0x874ee4: ldur            x2, [fp, #-8]
    // 0x874ee8: StoreField: r2->field_13 = r0
    //     0x874ee8: stur            w0, [x2, #0x13]
    //     0x874eec: ldurb           w16, [x2, #-1]
    //     0x874ef0: ldurb           w17, [x0, #-1]
    //     0x874ef4: and             x16, x17, x16, lsr #2
    //     0x874ef8: tst             x16, HEAP, lsr #32
    //     0x874efc: b.eq            #0x874f04
    //     0x874f00: bl              #0xd6828c
    // 0x874f04: r1 = Function '<anonymous closure>':.
    //     0x874f04: add             x1, PP, #0x50, lsl #12  ; [pp+0x50470] AnonymousClosure: static (0x87515c), in [dart:ui] ImageDescriptor::encoded (0x875174)
    //     0x874f08: ldr             x1, [x1, #0x470]
    // 0x874f0c: r0 = AllocateClosure()
    //     0x874f0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x874f10: stur            x0, [fp, #-8]
    // 0x874f14: r0 = OverlayEntry()
    //     0x874f14: bl              #0x6efcd0  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x24)
    // 0x874f18: stur            x0, [fp, #-0x18]
    // 0x874f1c: ldur            x16, [fp, #-8]
    // 0x874f20: stp             x16, x0, [SP, #-0x10]!
    // 0x874f24: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x874f24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x874f28: r0 = OverlayEntry()
    //     0x874f28: bl              #0x594c98  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0x874f2c: add             SP, SP, #0x10
    // 0x874f30: ldur            x0, [fp, #-0x18]
    // 0x874f34: ldr             x1, [fp, #0x10]
    // 0x874f38: StoreField: r1->field_43 = r0
    //     0x874f38: stur            w0, [x1, #0x43]
    //     0x874f3c: ldurb           w16, [x1, #-1]
    //     0x874f40: ldurb           w17, [x0, #-1]
    //     0x874f44: and             x16, x17, x16, lsr #2
    //     0x874f48: tst             x16, HEAP, lsr #32
    //     0x874f4c: b.eq            #0x874f54
    //     0x874f50: bl              #0xd6826c
    // 0x874f54: r0 = false
    //     0x874f54: add             x0, NULL, #0x30  ; false
    // 0x874f58: StoreField: r1->field_6b = r0
    //     0x874f58: stur            w0, [x1, #0x6b]
    // 0x874f5c: ldur            x16, [fp, #-0x10]
    // 0x874f60: ldur            lr, [fp, #-0x18]
    // 0x874f64: stp             lr, x16, [SP, #-0x10]!
    // 0x874f68: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x874f68: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x874f6c: r0 = insert()
    //     0x874f6c: bl              #0x594040  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insert
    // 0x874f70: add             SP, SP, #0x10
    // 0x874f74: ldr             x0, [fp, #0x10]
    // 0x874f78: LoadField: r1 = r0->field_b
    //     0x874f78: ldur            w1, [x0, #0xb]
    // 0x874f7c: DecompressPointer r1
    //     0x874f7c: add             x1, x1, HEAP, lsl #32
    // 0x874f80: cmp             w1, NULL
    // 0x874f84: b.eq            #0x875138
    // 0x874f88: LoadField: r2 = r1->field_b
    //     0x874f88: ldur            w2, [x1, #0xb]
    // 0x874f8c: DecompressPointer r2
    //     0x874f8c: add             x2, x2, HEAP, lsl #32
    // 0x874f90: cmp             w2, NULL
    // 0x874f94: b.eq            #0x875080
    // 0x874f98: r1 = Null
    //     0x874f98: mov             x1, NULL
    // 0x874f9c: SaveReg r2
    //     0x874f9c: str             x2, [SP, #-8]!
    // 0x874fa0: r0 = tooltip()
    //     0x874fa0: bl              #0x796268  ; [package:flutter/src/semantics/semantics_service.dart] SemanticsService::tooltip
    // 0x874fa4: add             SP, SP, #8
    // 0x874fa8: ldr             x0, [fp, #0x10]
    // 0x874fac: LoadField: r1 = r0->field_5b
    //     0x874fac: ldur            w1, [x0, #0x5b]
    // 0x874fb0: DecompressPointer r1
    //     0x874fb0: add             x1, x1, HEAP, lsl #32
    // 0x874fb4: tbnz            w1, #4, #0x874fc4
    // 0x874fb8: SaveReg r0
    //     0x874fb8: str             x0, [SP, #-8]!
    // 0x874fbc: r0 = _concealOtherTooltips()
    //     0x874fbc: bl              #0x8757b8  ; [package:flutter/src/material/tooltip.dart] Tooltip::_concealOtherTooltips
    // 0x874fc0: add             SP, SP, #8
    // 0x874fc4: r0 = InitLateStaticField(0xe4c) // [package:flutter/src/material/tooltip.dart] Tooltip::_openedTooltips
    //     0x874fc4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x874fc8: ldr             x0, [x0, #0x1c98]
    //     0x874fcc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x874fd0: cmp             w0, w16
    //     0x874fd4: b.ne            #0x874fe4
    //     0x874fd8: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d0f8] Field <Tooltip._openedTooltips@838220820>: static late final (offset: 0xe4c)
    //     0x874fdc: ldr             x2, [x2, #0xf8]
    //     0x874fe0: bl              #0xd67cdc
    // 0x874fe4: stur            x0, [fp, #-0x10]
    // 0x874fe8: LoadField: r1 = r0->field_b
    //     0x874fe8: ldur            w1, [x0, #0xb]
    // 0x874fec: DecompressPointer r1
    //     0x874fec: add             x1, x1, HEAP, lsl #32
    // 0x874ff0: stur            x1, [fp, #-8]
    // 0x874ff4: LoadField: r2 = r0->field_f
    //     0x874ff4: ldur            w2, [x0, #0xf]
    // 0x874ff8: DecompressPointer r2
    //     0x874ff8: add             x2, x2, HEAP, lsl #32
    // 0x874ffc: LoadField: r3 = r2->field_b
    //     0x874ffc: ldur            w3, [x2, #0xb]
    // 0x875000: DecompressPointer r3
    //     0x875000: add             x3, x3, HEAP, lsl #32
    // 0x875004: cmp             w1, w3
    // 0x875008: b.ne            #0x875018
    // 0x87500c: SaveReg r0
    //     0x87500c: str             x0, [SP, #-8]!
    // 0x875010: r0 = _growToNextCapacity()
    //     0x875010: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x875014: add             SP, SP, #8
    // 0x875018: ldur            x2, [fp, #-0x10]
    // 0x87501c: ldur            x3, [fp, #-8]
    // 0x875020: r4 = LoadInt32Instr(r3)
    //     0x875020: sbfx            x4, x3, #1, #0x1f
    // 0x875024: add             x0, x4, #1
    // 0x875028: lsl             x3, x0, #1
    // 0x87502c: StoreField: r2->field_b = r3
    //     0x87502c: stur            w3, [x2, #0xb]
    // 0x875030: mov             x1, x4
    // 0x875034: cmp             x1, x0
    // 0x875038: b.hs            #0x87513c
    // 0x87503c: LoadField: r1 = r2->field_f
    //     0x87503c: ldur            w1, [x2, #0xf]
    // 0x875040: DecompressPointer r1
    //     0x875040: add             x1, x1, HEAP, lsl #32
    // 0x875044: ldr             x0, [fp, #0x10]
    // 0x875048: ArrayStore: r1[r4] = r0  ; List_4
    //     0x875048: add             x25, x1, x4, lsl #2
    //     0x87504c: add             x25, x25, #0xf
    //     0x875050: str             w0, [x25]
    //     0x875054: tbz             w0, #0, #0x875070
    //     0x875058: ldurb           w16, [x1, #-1]
    //     0x87505c: ldurb           w17, [x0, #-1]
    //     0x875060: and             x16, x17, x16, lsr #2
    //     0x875064: tst             x16, HEAP, lsr #32
    //     0x875068: b.eq            #0x875070
    //     0x87506c: bl              #0xd67e5c
    // 0x875070: r0 = Null
    //     0x875070: mov             x0, NULL
    // 0x875074: LeaveFrame
    //     0x875074: mov             SP, fp
    //     0x875078: ldp             fp, lr, [SP], #0x10
    // 0x87507c: ret
    //     0x87507c: ret             
    // 0x875080: r1 = Null
    //     0x875080: mov             x1, NULL
    // 0x875084: cmp             w1, NULL
    // 0x875088: b.eq            #0x875140
    // 0x87508c: r0 = "Attempt to execute code removed by Dart AOT compiler (TFA)"
    //     0x87508c: ldr             x0, [PP, #0x10b0]  ; [pp+0x10b0] "Attempt to execute code removed by Dart AOT compiler (TFA)"
    // 0x875090: r0 = Throw()
    //     0x875090: bl              #0xd67e38  ; ThrowStub
    // 0x875094: brk             #0
    // 0x875098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875098: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87509c: b               #0x874b34
    // 0x8750a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8750bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8750c0: r9 = _height
    //     0x8750c0: add             x9, PP, #0x50, lsl #12  ; [pp+0x50478] Field <TooltipState._height@838220820>: late (offset: 0x1c)
    //     0x8750c4: ldr             x9, [x9, #0x478]
    // 0x8750c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8750c8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8750cc: r9 = _padding
    //     0x8750cc: add             x9, PP, #0x50, lsl #12  ; [pp+0x50480] Field <TooltipState._padding@838220820>: late (offset: 0x20)
    //     0x8750d0: ldr             x9, [x9, #0x480]
    // 0x8750d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8750d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8750d8: r9 = _margin
    //     0x8750d8: add             x9, PP, #0x50, lsl #12  ; [pp+0x50488] Field <TooltipState._margin@838220820>: late (offset: 0x24)
    //     0x8750dc: ldr             x9, [x9, #0x488]
    // 0x8750e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8750e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8750e4: r9 = _mouseIsConnected
    //     0x8750e4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d110] Field <TooltipState._mouseIsConnected@838220820>: late (offset: 0x5c)
    //     0x8750e8: ldr             x9, [x9, #0x110]
    // 0x8750ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8750ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8750f0: r9 = _decoration
    //     0x8750f0: add             x9, PP, #0x50, lsl #12  ; [pp+0x50490] Field <TooltipState._decoration@838220820>: late (offset: 0x28)
    //     0x8750f4: ldr             x9, [x9, #0x490]
    // 0x8750f8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8750f8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8750fc: r9 = _textStyle
    //     0x8750fc: add             x9, PP, #0x50, lsl #12  ; [pp+0x50498] Field <TooltipState._textStyle@838220820>: late (offset: 0x2c)
    //     0x875100: ldr             x9, [x9, #0x498]
    // 0x875104: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875104: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x875108: r9 = _textAlign
    //     0x875108: add             x9, PP, #0x50, lsl #12  ; [pp+0x504a0] Field <TooltipState._textAlign@838220820>: late (offset: 0x30)
    //     0x87510c: ldr             x9, [x9, #0x4a0]
    // 0x875110: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875110: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x875114: r9 = _controller
    //     0x875114: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x875118: ldr             x9, [x9, #0x118]
    // 0x87511c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x87511c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x875120: r9 = _verticalOffset
    //     0x875120: add             x9, PP, #0x50, lsl #12  ; [pp+0x504a8] Field <TooltipState._verticalOffset@838220820>: late (offset: 0x34)
    //     0x875124: ldr             x9, [x9, #0x4a8]
    // 0x875128: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875128: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x87512c: r9 = _preferBelow
    //     0x87512c: add             x9, PP, #0x50, lsl #12  ; [pp+0x504b0] Field <TooltipState._preferBelow@838220820>: late (offset: 0x38)
    //     0x875130: ldr             x9, [x9, #0x4b0]
    // 0x875134: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875134: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x875138: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x875138: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87513c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x87513c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x875140: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x875140: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _concealTooltip(/* No info */) {
    // ** addr: 0x8758d0, size: 0x128
    // 0x8758d0: EnterFrame
    //     0x8758d0: stp             fp, lr, [SP, #-0x10]!
    //     0x8758d4: mov             fp, SP
    // 0x8758d8: CheckStackOverflow
    //     0x8758d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8758dc: cmp             SP, x16
    //     0x8758e0: b.ls            #0x8759cc
    // 0x8758e4: ldr             x0, [fp, #0x10]
    // 0x8758e8: LoadField: r1 = r0->field_6b
    //     0x8758e8: ldur            w1, [x0, #0x6b]
    // 0x8758ec: DecompressPointer r1
    //     0x8758ec: add             x1, x1, HEAP, lsl #32
    // 0x8758f0: r16 = Sentinel
    //     0x8758f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8758f4: cmp             w1, w16
    // 0x8758f8: b.eq            #0x8759d4
    // 0x8758fc: tbz             w1, #4, #0x875918
    // 0x875900: LoadField: r1 = r0->field_6f
    //     0x875900: ldur            w1, [x0, #0x6f]
    // 0x875904: DecompressPointer r1
    //     0x875904: add             x1, x1, HEAP, lsl #32
    // 0x875908: r16 = Sentinel
    //     0x875908: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x87590c: cmp             w1, w16
    // 0x875910: b.eq            #0x8759e0
    // 0x875914: tbnz            w1, #4, #0x875928
    // 0x875918: r0 = Null
    //     0x875918: mov             x0, NULL
    // 0x87591c: LeaveFrame
    //     0x87591c: mov             SP, fp
    //     0x875920: ldp             fp, lr, [SP], #0x10
    // 0x875924: ret
    //     0x875924: ret             
    // 0x875928: r1 = true
    //     0x875928: add             x1, NULL, #0x20  ; true
    // 0x87592c: StoreField: r0->field_6b = r1
    //     0x87592c: stur            w1, [x0, #0x6b]
    // 0x875930: LoadField: r1 = r0->field_47
    //     0x875930: ldur            w1, [x0, #0x47]
    // 0x875934: DecompressPointer r1
    //     0x875934: add             x1, x1, HEAP, lsl #32
    // 0x875938: cmp             w1, NULL
    // 0x87593c: b.eq            #0x875950
    // 0x875940: SaveReg r1
    //     0x875940: str             x1, [SP, #-8]!
    // 0x875944: r0 = cancel()
    //     0x875944: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x875948: add             SP, SP, #8
    // 0x87594c: ldr             x0, [fp, #0x10]
    // 0x875950: StoreField: r0->field_47 = rNULL
    //     0x875950: stur            NULL, [x0, #0x47]
    // 0x875954: LoadField: r1 = r0->field_4b
    //     0x875954: ldur            w1, [x0, #0x4b]
    // 0x875958: DecompressPointer r1
    //     0x875958: add             x1, x1, HEAP, lsl #32
    // 0x87595c: cmp             w1, NULL
    // 0x875960: b.eq            #0x875974
    // 0x875964: SaveReg r1
    //     0x875964: str             x1, [SP, #-8]!
    // 0x875968: r0 = cancel()
    //     0x875968: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x87596c: add             SP, SP, #8
    // 0x875970: ldr             x0, [fp, #0x10]
    // 0x875974: StoreField: r0->field_4b = rNULL
    //     0x875974: stur            NULL, [x0, #0x4b]
    // 0x875978: LoadField: r1 = r0->field_43
    //     0x875978: ldur            w1, [x0, #0x43]
    // 0x87597c: DecompressPointer r1
    //     0x87597c: add             x1, x1, HEAP, lsl #32
    // 0x875980: cmp             w1, NULL
    // 0x875984: b.eq            #0x875994
    // 0x875988: SaveReg r1
    //     0x875988: str             x1, [SP, #-8]!
    // 0x87598c: r0 = remove()
    //     0x87598c: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x875990: add             SP, SP, #8
    // 0x875994: ldr             x0, [fp, #0x10]
    // 0x875998: LoadField: r1 = r0->field_3f
    //     0x875998: ldur            w1, [x0, #0x3f]
    // 0x87599c: DecompressPointer r1
    //     0x87599c: add             x1, x1, HEAP, lsl #32
    // 0x8759a0: r16 = Sentinel
    //     0x8759a0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8759a4: cmp             w1, w16
    // 0x8759a8: b.eq            #0x8759ec
    // 0x8759ac: SaveReg r1
    //     0x8759ac: str             x1, [SP, #-8]!
    // 0x8759b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8759b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8759b4: r0 = reverse()
    //     0x8759b4: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x8759b8: add             SP, SP, #8
    // 0x8759bc: r0 = Null
    //     0x8759bc: mov             x0, NULL
    // 0x8759c0: LeaveFrame
    //     0x8759c0: mov             SP, fp
    //     0x8759c4: ldp             fp, lr, [SP], #0x10
    // 0x8759c8: ret
    //     0x8759c8: ret             
    // 0x8759cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8759cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8759d0: b               #0x8758e4
    // 0x8759d4: r9 = _isConcealed
    //     0x8759d4: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d108] Field <TooltipState._isConcealed@838220820>: late (offset: 0x6c)
    //     0x8759d8: ldr             x9, [x9, #0x108]
    // 0x8759dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8759dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8759e0: r9 = _forceRemoval
    //     0x8759e0: add             x9, PP, #0x50, lsl #12  ; [pp+0x504b8] Field <TooltipState._forceRemoval@838220820>: late (offset: 0x70)
    //     0x8759e4: ldr             x9, [x9, #0x4b8]
    // 0x8759e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8759e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8759ec: r9 = _controller
    //     0x8759ec: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0x8759f0: ldr             x9, [x9, #0x118]
    // 0x8759f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8759f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePress(dynamic) {
    // ** addr: 0x8759f8, size: 0x48
    // 0x8759f8: EnterFrame
    //     0x8759f8: stp             fp, lr, [SP, #-0x10]!
    //     0x8759fc: mov             fp, SP
    // 0x875a00: ldr             x0, [fp, #0x10]
    // 0x875a04: LoadField: r1 = r0->field_17
    //     0x875a04: ldur            w1, [x0, #0x17]
    // 0x875a08: DecompressPointer r1
    //     0x875a08: add             x1, x1, HEAP, lsl #32
    // 0x875a0c: CheckStackOverflow
    //     0x875a0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x875a10: cmp             SP, x16
    //     0x875a14: b.ls            #0x875a38
    // 0x875a18: LoadField: r0 = r1->field_f
    //     0x875a18: ldur            w0, [x1, #0xf]
    // 0x875a1c: DecompressPointer r0
    //     0x875a1c: add             x0, x0, HEAP, lsl #32
    // 0x875a20: SaveReg r0
    //     0x875a20: str             x0, [SP, #-8]!
    // 0x875a24: r0 = _handlePress()
    //     0x875a24: bl              #0x875a40  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handlePress
    // 0x875a28: add             SP, SP, #8
    // 0x875a2c: LeaveFrame
    //     0x875a2c: mov             SP, fp
    //     0x875a30: ldp             fp, lr, [SP], #0x10
    // 0x875a34: ret
    //     0x875a34: ret             
    // 0x875a38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875a38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875a3c: b               #0x875a18
  }
  _ _handlePress(/* No info */) {
    // ** addr: 0x875a40, size: 0xc4
    // 0x875a40: EnterFrame
    //     0x875a40: stp             fp, lr, [SP, #-0x10]!
    //     0x875a44: mov             fp, SP
    // 0x875a48: r0 = true
    //     0x875a48: add             x0, NULL, #0x20  ; true
    // 0x875a4c: CheckStackOverflow
    //     0x875a4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x875a50: cmp             SP, x16
    //     0x875a54: b.ls            #0x875adc
    // 0x875a58: ldr             x1, [fp, #0x10]
    // 0x875a5c: StoreField: r1->field_5f = r0
    //     0x875a5c: stur            w0, [x1, #0x5f]
    // 0x875a60: SaveReg r1
    //     0x875a60: str             x1, [SP, #-8]!
    // 0x875a64: r0 = ensureTooltipVisible()
    //     0x875a64: bl              #0x874958  ; [package:flutter/src/material/tooltip.dart] TooltipState::ensureTooltipVisible
    // 0x875a68: add             SP, SP, #8
    // 0x875a6c: tbnz            w0, #4, #0x875ab8
    // 0x875a70: ldr             x0, [fp, #0x10]
    // 0x875a74: LoadField: r1 = r0->field_67
    //     0x875a74: ldur            w1, [x0, #0x67]
    // 0x875a78: DecompressPointer r1
    //     0x875a78: add             x1, x1, HEAP, lsl #32
    // 0x875a7c: r16 = Sentinel
    //     0x875a7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x875a80: cmp             w1, w16
    // 0x875a84: b.eq            #0x875ae4
    // 0x875a88: LoadField: r1 = r0->field_63
    //     0x875a88: ldur            w1, [x0, #0x63]
    // 0x875a8c: DecompressPointer r1
    //     0x875a8c: add             x1, x1, HEAP, lsl #32
    // 0x875a90: r16 = Sentinel
    //     0x875a90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x875a94: cmp             w1, w16
    // 0x875a98: b.eq            #0x875af0
    // 0x875a9c: LoadField: r1 = r0->field_f
    //     0x875a9c: ldur            w1, [x0, #0xf]
    // 0x875aa0: DecompressPointer r1
    //     0x875aa0: add             x1, x1, HEAP, lsl #32
    // 0x875aa4: cmp             w1, NULL
    // 0x875aa8: b.eq            #0x875afc
    // 0x875aac: SaveReg r1
    //     0x875aac: str             x1, [SP, #-8]!
    // 0x875ab0: r0 = forLongPress()
    //     0x875ab0: bl              #0x83bf00  ; [package:flutter/src/material/feedback.dart] Feedback::forLongPress
    // 0x875ab4: add             SP, SP, #8
    // 0x875ab8: ldr             x1, [fp, #0x10]
    // 0x875abc: LoadField: r2 = r1->field_b
    //     0x875abc: ldur            w2, [x1, #0xb]
    // 0x875ac0: DecompressPointer r2
    //     0x875ac0: add             x2, x2, HEAP, lsl #32
    // 0x875ac4: cmp             w2, NULL
    // 0x875ac8: b.eq            #0x875b00
    // 0x875acc: r0 = Null
    //     0x875acc: mov             x0, NULL
    // 0x875ad0: LeaveFrame
    //     0x875ad0: mov             SP, fp
    //     0x875ad4: ldp             fp, lr, [SP], #0x10
    // 0x875ad8: ret
    //     0x875ad8: ret             
    // 0x875adc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x875adc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x875ae0: b               #0x875a58
    // 0x875ae4: r9 = _enableFeedback
    //     0x875ae4: add             x9, PP, #0x50, lsl #12  ; [pp+0x504c0] Field <TooltipState._enableFeedback@838220820>: late (offset: 0x68)
    //     0x875ae8: ldr             x9, [x9, #0x4c0]
    // 0x875aec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875aec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x875af0: r9 = _triggerMode
    //     0x875af0: add             x9, PP, #0x50, lsl #12  ; [pp+0x504c8] Field <TooltipState._triggerMode@838220820>: late (offset: 0x64)
    //     0x875af4: ldr             x9, [x9, #0x4c8]
    // 0x875af8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x875af8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x875afc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x875afc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x875b00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x875b00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dc10c, size: 0x1e8
    // 0x9dc10c: EnterFrame
    //     0x9dc10c: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc110: mov             fp, SP
    // 0x9dc114: AllocStack(0x8)
    //     0x9dc114: sub             SP, SP, #8
    // 0x9dc118: r0 = false
    //     0x9dc118: add             x0, NULL, #0x30  ; false
    // 0x9dc11c: CheckStackOverflow
    //     0x9dc11c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc120: cmp             SP, x16
    //     0x9dc124: b.ls            #0x9dc2d8
    // 0x9dc128: ldr             x2, [fp, #0x10]
    // 0x9dc12c: StoreField: r2->field_6b = r0
    //     0x9dc12c: stur            w0, [x2, #0x6b]
    // 0x9dc130: StoreField: r2->field_6f = r0
    //     0x9dc130: stur            w0, [x2, #0x6f]
    // 0x9dc134: r0 = LoadStaticField(0xea4)
    //     0x9dc134: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9dc138: ldr             x0, [x0, #0x1d48]
    // 0x9dc13c: cmp             w0, NULL
    // 0x9dc140: b.eq            #0x9dc2e0
    // 0x9dc144: LoadField: r1 = r0->field_b3
    //     0x9dc144: ldur            w1, [x0, #0xb3]
    // 0x9dc148: DecompressPointer r1
    //     0x9dc148: add             x1, x1, HEAP, lsl #32
    // 0x9dc14c: cmp             w1, NULL
    // 0x9dc150: b.eq            #0x9dc2e4
    // 0x9dc154: LoadField: r0 = r1->field_27
    //     0x9dc154: ldur            w0, [x1, #0x27]
    // 0x9dc158: DecompressPointer r0
    //     0x9dc158: add             x0, x0, HEAP, lsl #32
    // 0x9dc15c: LoadField: r1 = r0->field_13
    //     0x9dc15c: ldur            w1, [x0, #0x13]
    // 0x9dc160: DecompressPointer r1
    //     0x9dc160: add             x1, x1, HEAP, lsl #32
    // 0x9dc164: r3 = LoadInt32Instr(r1)
    //     0x9dc164: sbfx            x3, x1, #1, #0x1f
    // 0x9dc168: asr             x1, x3, #1
    // 0x9dc16c: LoadField: r3 = r0->field_17
    //     0x9dc16c: ldur            w3, [x0, #0x17]
    // 0x9dc170: DecompressPointer r3
    //     0x9dc170: add             x3, x3, HEAP, lsl #32
    // 0x9dc174: r0 = LoadInt32Instr(r3)
    //     0x9dc174: sbfx            x0, x3, #1, #0x1f
    // 0x9dc178: sub             x3, x1, x0
    // 0x9dc17c: cbnz            x3, #0x9dc188
    // 0x9dc180: r0 = false
    //     0x9dc180: add             x0, NULL, #0x30  ; false
    // 0x9dc184: b               #0x9dc18c
    // 0x9dc188: r0 = true
    //     0x9dc188: add             x0, NULL, #0x20  ; true
    // 0x9dc18c: StoreField: r2->field_5b = r0
    //     0x9dc18c: stur            w0, [x2, #0x5b]
    // 0x9dc190: r1 = <double>
    //     0x9dc190: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9dc194: r0 = AnimationController()
    //     0x9dc194: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9dc198: stur            x0, [fp, #-8]
    // 0x9dc19c: ldr             x16, [fp, #0x10]
    // 0x9dc1a0: stp             x16, x0, [SP, #-0x10]!
    // 0x9dc1a4: r16 = Instance_Duration
    //     0x9dc1a4: add             x16, PP, #0x20, lsl #12  ; [pp+0x20968] Obj!Duration@b67b41
    //     0x9dc1a8: ldr             x16, [x16, #0x968]
    // 0x9dc1ac: r30 = Instance_Duration
    //     0x9dc1ac: add             lr, PP, #0x2e, lsl #12  ; [pp+0x2e300] Obj!Duration@b67bc1
    //     0x9dc1b0: ldr             lr, [lr, #0x300]
    // 0x9dc1b4: stp             lr, x16, [SP, #-0x10]!
    // 0x9dc1b8: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0x9dc1b8: add             x4, PP, #0x21, lsl #12  ; [pp+0x218b8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0x9dc1bc: ldr             x4, [x4, #0x8b8]
    // 0x9dc1c0: r0 = AnimationController()
    //     0x9dc1c0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9dc1c4: add             SP, SP, #0x20
    // 0x9dc1c8: r1 = 1
    //     0x9dc1c8: mov             x1, #1
    // 0x9dc1cc: r0 = AllocateContext()
    //     0x9dc1cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dc1d0: mov             x1, x0
    // 0x9dc1d4: ldr             x0, [fp, #0x10]
    // 0x9dc1d8: StoreField: r1->field_f = r0
    //     0x9dc1d8: stur            w0, [x1, #0xf]
    // 0x9dc1dc: mov             x2, x1
    // 0x9dc1e0: r1 = Function '_handleStatusChanged@838220820':.
    //     0x9dc1e0: add             x1, PP, #0x50, lsl #12  ; [pp+0x50508] AnonymousClosure: (0x9dc2f4), in [package:flutter/src/material/tooltip.dart] TooltipState::_handleStatusChanged (0x9dc340)
    //     0x9dc1e4: ldr             x1, [x1, #0x508]
    // 0x9dc1e8: r0 = AllocateClosure()
    //     0x9dc1e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dc1ec: ldur            x16, [fp, #-8]
    // 0x9dc1f0: stp             x0, x16, [SP, #-0x10]!
    // 0x9dc1f4: r0 = addStatusListener()
    //     0x9dc1f4: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x9dc1f8: add             SP, SP, #0x10
    // 0x9dc1fc: ldur            x0, [fp, #-8]
    // 0x9dc200: ldr             x1, [fp, #0x10]
    // 0x9dc204: StoreField: r1->field_3f = r0
    //     0x9dc204: stur            w0, [x1, #0x3f]
    //     0x9dc208: ldurb           w16, [x1, #-1]
    //     0x9dc20c: ldurb           w17, [x0, #-1]
    //     0x9dc210: and             x16, x17, x16, lsr #2
    //     0x9dc214: tst             x16, HEAP, lsr #32
    //     0x9dc218: b.eq            #0x9dc220
    //     0x9dc21c: bl              #0xd6826c
    // 0x9dc220: r0 = LoadStaticField(0xea4)
    //     0x9dc220: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9dc224: ldr             x0, [x0, #0x1d48]
    // 0x9dc228: cmp             w0, NULL
    // 0x9dc22c: b.eq            #0x9dc2e8
    // 0x9dc230: LoadField: r2 = r0->field_b3
    //     0x9dc230: ldur            w2, [x0, #0xb3]
    // 0x9dc234: DecompressPointer r2
    //     0x9dc234: add             x2, x2, HEAP, lsl #32
    // 0x9dc238: stur            x2, [fp, #-8]
    // 0x9dc23c: cmp             w2, NULL
    // 0x9dc240: b.eq            #0x9dc2ec
    // 0x9dc244: r1 = 1
    //     0x9dc244: mov             x1, #1
    // 0x9dc248: r0 = AllocateContext()
    //     0x9dc248: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dc24c: mov             x1, x0
    // 0x9dc250: ldr             x0, [fp, #0x10]
    // 0x9dc254: StoreField: r1->field_f = r0
    //     0x9dc254: stur            w0, [x1, #0xf]
    // 0x9dc258: mov             x2, x1
    // 0x9dc25c: r1 = Function '_handleMouseTrackerChange@838220820':.
    //     0x9dc25c: add             x1, PP, #0x50, lsl #12  ; [pp+0x504e8] AnonymousClosure: (0x9dc568), in [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseTrackerChange (0x9dc5b0)
    //     0x9dc260: ldr             x1, [x1, #0x4e8]
    // 0x9dc264: r0 = AllocateClosure()
    //     0x9dc264: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dc268: ldur            x16, [fp, #-8]
    // 0x9dc26c: stp             x0, x16, [SP, #-0x10]!
    // 0x9dc270: r0 = addListener()
    //     0x9dc270: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9dc274: add             SP, SP, #0x10
    // 0x9dc278: r0 = LoadStaticField(0xd54)
    //     0x9dc278: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x9dc27c: ldr             x0, [x0, #0x1aa8]
    // 0x9dc280: cmp             w0, NULL
    // 0x9dc284: b.eq            #0x9dc2f0
    // 0x9dc288: LoadField: r1 = r0->field_13
    //     0x9dc288: ldur            w1, [x0, #0x13]
    // 0x9dc28c: DecompressPointer r1
    //     0x9dc28c: add             x1, x1, HEAP, lsl #32
    // 0x9dc290: stur            x1, [fp, #-8]
    // 0x9dc294: r1 = 1
    //     0x9dc294: mov             x1, #1
    // 0x9dc298: r0 = AllocateContext()
    //     0x9dc298: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dc29c: mov             x1, x0
    // 0x9dc2a0: ldr             x0, [fp, #0x10]
    // 0x9dc2a4: StoreField: r1->field_f = r0
    //     0x9dc2a4: stur            w0, [x1, #0xf]
    // 0x9dc2a8: mov             x2, x1
    // 0x9dc2ac: r1 = Function '_handlePointerEvent@838220820':.
    //     0x9dc2ac: add             x1, PP, #0x50, lsl #12  ; [pp+0x504e0] AnonymousClosure: (0x9dc3d8), in [package:flutter/src/material/tooltip.dart] TooltipState::_handlePointerEvent (0x9dc424)
    //     0x9dc2b0: ldr             x1, [x1, #0x4e0]
    // 0x9dc2b4: r0 = AllocateClosure()
    //     0x9dc2b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dc2b8: ldur            x16, [fp, #-8]
    // 0x9dc2bc: stp             x0, x16, [SP, #-0x10]!
    // 0x9dc2c0: r0 = addGlobalRoute()
    //     0x9dc2c0: bl              #0x5b9b94  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::addGlobalRoute
    // 0x9dc2c4: add             SP, SP, #0x10
    // 0x9dc2c8: r0 = Null
    //     0x9dc2c8: mov             x0, NULL
    // 0x9dc2cc: LeaveFrame
    //     0x9dc2cc: mov             SP, fp
    //     0x9dc2d0: ldp             fp, lr, [SP], #0x10
    // 0x9dc2d4: ret
    //     0x9dc2d4: ret             
    // 0x9dc2d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc2d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc2dc: b               #0x9dc128
    // 0x9dc2e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc2e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dc2e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc2e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dc2e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc2e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dc2ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc2ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dc2f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc2f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0x9dc2f4, size: 0x4c
    // 0x9dc2f4: EnterFrame
    //     0x9dc2f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc2f8: mov             fp, SP
    // 0x9dc2fc: ldr             x0, [fp, #0x18]
    // 0x9dc300: LoadField: r1 = r0->field_17
    //     0x9dc300: ldur            w1, [x0, #0x17]
    // 0x9dc304: DecompressPointer r1
    //     0x9dc304: add             x1, x1, HEAP, lsl #32
    // 0x9dc308: CheckStackOverflow
    //     0x9dc308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc30c: cmp             SP, x16
    //     0x9dc310: b.ls            #0x9dc338
    // 0x9dc314: LoadField: r0 = r1->field_f
    //     0x9dc314: ldur            w0, [x1, #0xf]
    // 0x9dc318: DecompressPointer r0
    //     0x9dc318: add             x0, x0, HEAP, lsl #32
    // 0x9dc31c: ldr             x16, [fp, #0x10]
    // 0x9dc320: stp             x16, x0, [SP, #-0x10]!
    // 0x9dc324: r0 = _handleStatusChanged()
    //     0x9dc324: bl              #0x9dc340  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handleStatusChanged
    // 0x9dc328: add             SP, SP, #0x10
    // 0x9dc32c: LeaveFrame
    //     0x9dc32c: mov             SP, fp
    //     0x9dc330: ldp             fp, lr, [SP], #0x10
    // 0x9dc334: ret
    //     0x9dc334: ret             
    // 0x9dc338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc33c: b               #0x9dc314
  }
  _ _handleStatusChanged(/* No info */) {
    // ** addr: 0x9dc340, size: 0x98
    // 0x9dc340: EnterFrame
    //     0x9dc340: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc344: mov             fp, SP
    // 0x9dc348: CheckStackOverflow
    //     0x9dc348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc34c: cmp             SP, x16
    //     0x9dc350: b.ls            #0x9dc3b8
    // 0x9dc354: ldr             x0, [fp, #0x10]
    // 0x9dc358: r16 = Instance_AnimationStatus
    //     0x9dc358: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x9dc35c: ldr             x16, [x16, #0xba8]
    // 0x9dc360: cmp             w0, w16
    // 0x9dc364: b.ne            #0x9dc3a8
    // 0x9dc368: ldr             x0, [fp, #0x18]
    // 0x9dc36c: LoadField: r1 = r0->field_6f
    //     0x9dc36c: ldur            w1, [x0, #0x6f]
    // 0x9dc370: DecompressPointer r1
    //     0x9dc370: add             x1, x1, HEAP, lsl #32
    // 0x9dc374: r16 = Sentinel
    //     0x9dc374: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9dc378: cmp             w1, w16
    // 0x9dc37c: b.eq            #0x9dc3c0
    // 0x9dc380: tbz             w1, #4, #0x9dc39c
    // 0x9dc384: LoadField: r1 = r0->field_6b
    //     0x9dc384: ldur            w1, [x0, #0x6b]
    // 0x9dc388: DecompressPointer r1
    //     0x9dc388: add             x1, x1, HEAP, lsl #32
    // 0x9dc38c: r16 = Sentinel
    //     0x9dc38c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9dc390: cmp             w1, w16
    // 0x9dc394: b.eq            #0x9dc3cc
    // 0x9dc398: tbz             w1, #4, #0x9dc3a8
    // 0x9dc39c: SaveReg r0
    //     0x9dc39c: str             x0, [SP, #-8]!
    // 0x9dc3a0: r0 = _removeEntry()
    //     0x9dc3a0: bl              #0x795f18  ; [package:flutter/src/material/tooltip.dart] TooltipState::_removeEntry
    // 0x9dc3a4: add             SP, SP, #8
    // 0x9dc3a8: r0 = Null
    //     0x9dc3a8: mov             x0, NULL
    // 0x9dc3ac: LeaveFrame
    //     0x9dc3ac: mov             SP, fp
    //     0x9dc3b0: ldp             fp, lr, [SP], #0x10
    // 0x9dc3b4: ret
    //     0x9dc3b4: ret             
    // 0x9dc3b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc3b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc3bc: b               #0x9dc354
    // 0x9dc3c0: r9 = _forceRemoval
    //     0x9dc3c0: add             x9, PP, #0x50, lsl #12  ; [pp+0x504b8] Field <TooltipState._forceRemoval@838220820>: late (offset: 0x70)
    //     0x9dc3c4: ldr             x9, [x9, #0x4b8]
    // 0x9dc3c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9dc3c8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9dc3cc: r9 = _isConcealed
    //     0x9dc3cc: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d108] Field <TooltipState._isConcealed@838220820>: late (offset: 0x6c)
    //     0x9dc3d0: ldr             x9, [x9, #0x108]
    // 0x9dc3d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9dc3d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePointerEvent(dynamic, PointerEvent) {
    // ** addr: 0x9dc3d8, size: 0x4c
    // 0x9dc3d8: EnterFrame
    //     0x9dc3d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc3dc: mov             fp, SP
    // 0x9dc3e0: ldr             x0, [fp, #0x18]
    // 0x9dc3e4: LoadField: r1 = r0->field_17
    //     0x9dc3e4: ldur            w1, [x0, #0x17]
    // 0x9dc3e8: DecompressPointer r1
    //     0x9dc3e8: add             x1, x1, HEAP, lsl #32
    // 0x9dc3ec: CheckStackOverflow
    //     0x9dc3ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc3f0: cmp             SP, x16
    //     0x9dc3f4: b.ls            #0x9dc41c
    // 0x9dc3f8: LoadField: r0 = r1->field_f
    //     0x9dc3f8: ldur            w0, [x1, #0xf]
    // 0x9dc3fc: DecompressPointer r0
    //     0x9dc3fc: add             x0, x0, HEAP, lsl #32
    // 0x9dc400: ldr             x16, [fp, #0x10]
    // 0x9dc404: stp             x16, x0, [SP, #-0x10]!
    // 0x9dc408: r0 = _handlePointerEvent()
    //     0x9dc408: bl              #0x9dc424  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handlePointerEvent
    // 0x9dc40c: add             SP, SP, #0x10
    // 0x9dc410: LeaveFrame
    //     0x9dc410: mov             SP, fp
    //     0x9dc414: ldp             fp, lr, [SP], #0x10
    // 0x9dc418: ret
    //     0x9dc418: ret             
    // 0x9dc41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc41c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc420: b               #0x9dc3f8
  }
  _ _handlePointerEvent(/* No info */) {
    // ** addr: 0x9dc424, size: 0x144
    // 0x9dc424: EnterFrame
    //     0x9dc424: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc428: mov             fp, SP
    // 0x9dc42c: CheckStackOverflow
    //     0x9dc42c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc430: cmp             SP, x16
    //     0x9dc434: b.ls            #0x9dc560
    // 0x9dc438: ldr             x3, [fp, #0x18]
    // 0x9dc43c: LoadField: r0 = r3->field_43
    //     0x9dc43c: ldur            w0, [x3, #0x43]
    // 0x9dc440: DecompressPointer r0
    //     0x9dc440: add             x0, x0, HEAP, lsl #32
    // 0x9dc444: cmp             w0, NULL
    // 0x9dc448: b.ne            #0x9dc45c
    // 0x9dc44c: r0 = Null
    //     0x9dc44c: mov             x0, NULL
    // 0x9dc450: LeaveFrame
    //     0x9dc450: mov             SP, fp
    //     0x9dc454: ldp             fp, lr, [SP], #0x10
    // 0x9dc458: ret
    //     0x9dc458: ret             
    // 0x9dc45c: ldr             x0, [fp, #0x10]
    // 0x9dc460: r2 = Null
    //     0x9dc460: mov             x2, NULL
    // 0x9dc464: r1 = Null
    //     0x9dc464: mov             x1, NULL
    // 0x9dc468: cmp             w0, NULL
    // 0x9dc46c: b.eq            #0x9dc48c
    // 0x9dc470: branchIfSmi(r0, 0x9dc48c)
    //     0x9dc470: tbz             w0, #0, #0x9dc48c
    // 0x9dc474: r3 = LoadClassIdInstr(r0)
    //     0x9dc474: ldur            x3, [x0, #-1]
    //     0x9dc478: ubfx            x3, x3, #0xc, #0x14
    // 0x9dc47c: cmp             x3, #0x906
    // 0x9dc480: b.eq            #0x9dc494
    // 0x9dc484: cmp             x3, #0xb3d
    // 0x9dc488: b.eq            #0x9dc494
    // 0x9dc48c: r0 = false
    //     0x9dc48c: add             x0, NULL, #0x30  ; false
    // 0x9dc490: b               #0x9dc498
    // 0x9dc494: r0 = true
    //     0x9dc494: add             x0, NULL, #0x20  ; true
    // 0x9dc498: tbz             w0, #4, #0x9dc4dc
    // 0x9dc49c: ldr             x0, [fp, #0x10]
    // 0x9dc4a0: r2 = Null
    //     0x9dc4a0: mov             x2, NULL
    // 0x9dc4a4: r1 = Null
    //     0x9dc4a4: mov             x1, NULL
    // 0x9dc4a8: cmp             w0, NULL
    // 0x9dc4ac: b.eq            #0x9dc4cc
    // 0x9dc4b0: branchIfSmi(r0, 0x9dc4cc)
    //     0x9dc4b0: tbz             w0, #0, #0x9dc4cc
    // 0x9dc4b4: r3 = LoadClassIdInstr(r0)
    //     0x9dc4b4: ldur            x3, [x0, #-1]
    //     0x9dc4b8: ubfx            x3, x3, #0xc, #0x14
    // 0x9dc4bc: cmp             x3, #0x8f8
    // 0x9dc4c0: b.eq            #0x9dc4d4
    // 0x9dc4c4: cmp             x3, #0xb35
    // 0x9dc4c8: b.eq            #0x9dc4d4
    // 0x9dc4cc: r0 = false
    //     0x9dc4cc: add             x0, NULL, #0x30  ; false
    // 0x9dc4d0: b               #0x9dc4d8
    // 0x9dc4d4: r0 = true
    //     0x9dc4d4: add             x0, NULL, #0x20  ; true
    // 0x9dc4d8: tbnz            w0, #4, #0x9dc4f4
    // 0x9dc4dc: ldr             x16, [fp, #0x18]
    // 0x9dc4e0: SaveReg r16
    //     0x9dc4e0: str             x16, [SP, #-8]!
    // 0x9dc4e4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9dc4e4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9dc4e8: r0 = _handleMouseExit()
    //     0x9dc4e8: bl              #0x8746e0  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseExit
    // 0x9dc4ec: add             SP, SP, #8
    // 0x9dc4f0: b               #0x9dc550
    // 0x9dc4f4: ldr             x0, [fp, #0x10]
    // 0x9dc4f8: r2 = Null
    //     0x9dc4f8: mov             x2, NULL
    // 0x9dc4fc: r1 = Null
    //     0x9dc4fc: mov             x1, NULL
    // 0x9dc500: cmp             w0, NULL
    // 0x9dc504: b.eq            #0x9dc524
    // 0x9dc508: branchIfSmi(r0, 0x9dc524)
    //     0x9dc508: tbz             w0, #0, #0x9dc524
    // 0x9dc50c: r3 = LoadClassIdInstr(r0)
    //     0x9dc50c: ldur            x3, [x0, #-1]
    //     0x9dc510: ubfx            x3, x3, #0xc, #0x14
    // 0x9dc514: cmp             x3, #0x90a
    // 0x9dc518: b.eq            #0x9dc52c
    // 0x9dc51c: cmp             x3, #0xb41
    // 0x9dc520: b.eq            #0x9dc52c
    // 0x9dc524: r0 = false
    //     0x9dc524: add             x0, NULL, #0x30  ; false
    // 0x9dc528: b               #0x9dc530
    // 0x9dc52c: r0 = true
    //     0x9dc52c: add             x0, NULL, #0x20  ; true
    // 0x9dc530: tbnz            w0, #4, #0x9dc550
    // 0x9dc534: ldr             x16, [fp, #0x18]
    // 0x9dc538: r30 = true
    //     0x9dc538: add             lr, NULL, #0x20  ; true
    // 0x9dc53c: stp             lr, x16, [SP, #-0x10]!
    // 0x9dc540: r4 = const [0, 0x2, 0x2, 0x1, immediately, 0x1, null]
    //     0x9dc540: add             x4, PP, #0x50, lsl #12  ; [pp+0x504f8] List(7) [0, 0x2, 0x2, 0x1, "immediately", 0x1, Null]
    //     0x9dc544: ldr             x4, [x4, #0x4f8]
    // 0x9dc548: r0 = _handleMouseExit()
    //     0x9dc548: bl              #0x8746e0  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseExit
    // 0x9dc54c: add             SP, SP, #0x10
    // 0x9dc550: r0 = Null
    //     0x9dc550: mov             x0, NULL
    // 0x9dc554: LeaveFrame
    //     0x9dc554: mov             SP, fp
    //     0x9dc558: ldp             fp, lr, [SP], #0x10
    // 0x9dc55c: ret
    //     0x9dc55c: ret             
    // 0x9dc560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc560: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc564: b               #0x9dc438
  }
  [closure] void _handleMouseTrackerChange(dynamic) {
    // ** addr: 0x9dc568, size: 0x48
    // 0x9dc568: EnterFrame
    //     0x9dc568: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc56c: mov             fp, SP
    // 0x9dc570: ldr             x0, [fp, #0x10]
    // 0x9dc574: LoadField: r1 = r0->field_17
    //     0x9dc574: ldur            w1, [x0, #0x17]
    // 0x9dc578: DecompressPointer r1
    //     0x9dc578: add             x1, x1, HEAP, lsl #32
    // 0x9dc57c: CheckStackOverflow
    //     0x9dc57c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc580: cmp             SP, x16
    //     0x9dc584: b.ls            #0x9dc5a8
    // 0x9dc588: LoadField: r0 = r1->field_f
    //     0x9dc588: ldur            w0, [x1, #0xf]
    // 0x9dc58c: DecompressPointer r0
    //     0x9dc58c: add             x0, x0, HEAP, lsl #32
    // 0x9dc590: SaveReg r0
    //     0x9dc590: str             x0, [SP, #-8]!
    // 0x9dc594: r0 = _handleMouseTrackerChange()
    //     0x9dc594: bl              #0x9dc5b0  ; [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseTrackerChange
    // 0x9dc598: add             SP, SP, #8
    // 0x9dc59c: LeaveFrame
    //     0x9dc59c: mov             SP, fp
    //     0x9dc5a0: ldp             fp, lr, [SP], #0x10
    // 0x9dc5a4: ret
    //     0x9dc5a4: ret             
    // 0x9dc5a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc5a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc5ac: b               #0x9dc588
  }
  _ _handleMouseTrackerChange(/* No info */) {
    // ** addr: 0x9dc5b0, size: 0x10c
    // 0x9dc5b0: EnterFrame
    //     0x9dc5b0: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc5b4: mov             fp, SP
    // 0x9dc5b8: CheckStackOverflow
    //     0x9dc5b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc5bc: cmp             SP, x16
    //     0x9dc5c0: b.ls            #0x9dc6a0
    // 0x9dc5c4: r1 = 2
    //     0x9dc5c4: mov             x1, #2
    // 0x9dc5c8: r0 = AllocateContext()
    //     0x9dc5c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dc5cc: mov             x1, x0
    // 0x9dc5d0: ldr             x0, [fp, #0x10]
    // 0x9dc5d4: StoreField: r1->field_f = r0
    //     0x9dc5d4: stur            w0, [x1, #0xf]
    // 0x9dc5d8: LoadField: r2 = r0->field_f
    //     0x9dc5d8: ldur            w2, [x0, #0xf]
    // 0x9dc5dc: DecompressPointer r2
    //     0x9dc5dc: add             x2, x2, HEAP, lsl #32
    // 0x9dc5e0: cmp             w2, NULL
    // 0x9dc5e4: b.ne            #0x9dc5f8
    // 0x9dc5e8: r0 = Null
    //     0x9dc5e8: mov             x0, NULL
    // 0x9dc5ec: LeaveFrame
    //     0x9dc5ec: mov             SP, fp
    //     0x9dc5f0: ldp             fp, lr, [SP], #0x10
    // 0x9dc5f4: ret
    //     0x9dc5f4: ret             
    // 0x9dc5f8: r2 = LoadStaticField(0xea4)
    //     0x9dc5f8: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x9dc5fc: ldr             x2, [x2, #0x1d48]
    // 0x9dc600: cmp             w2, NULL
    // 0x9dc604: b.eq            #0x9dc6a8
    // 0x9dc608: LoadField: r3 = r2->field_b3
    //     0x9dc608: ldur            w3, [x2, #0xb3]
    // 0x9dc60c: DecompressPointer r3
    //     0x9dc60c: add             x3, x3, HEAP, lsl #32
    // 0x9dc610: cmp             w3, NULL
    // 0x9dc614: b.eq            #0x9dc6ac
    // 0x9dc618: LoadField: r2 = r3->field_27
    //     0x9dc618: ldur            w2, [x3, #0x27]
    // 0x9dc61c: DecompressPointer r2
    //     0x9dc61c: add             x2, x2, HEAP, lsl #32
    // 0x9dc620: LoadField: r3 = r2->field_13
    //     0x9dc620: ldur            w3, [x2, #0x13]
    // 0x9dc624: DecompressPointer r3
    //     0x9dc624: add             x3, x3, HEAP, lsl #32
    // 0x9dc628: r4 = LoadInt32Instr(r3)
    //     0x9dc628: sbfx            x4, x3, #1, #0x1f
    // 0x9dc62c: asr             x3, x4, #1
    // 0x9dc630: LoadField: r4 = r2->field_17
    //     0x9dc630: ldur            w4, [x2, #0x17]
    // 0x9dc634: DecompressPointer r4
    //     0x9dc634: add             x4, x4, HEAP, lsl #32
    // 0x9dc638: r2 = LoadInt32Instr(r4)
    //     0x9dc638: sbfx            x2, x4, #1, #0x1f
    // 0x9dc63c: sub             x4, x3, x2
    // 0x9dc640: cbnz            x4, #0x9dc64c
    // 0x9dc644: r2 = false
    //     0x9dc644: add             x2, NULL, #0x30  ; false
    // 0x9dc648: b               #0x9dc650
    // 0x9dc64c: r2 = true
    //     0x9dc64c: add             x2, NULL, #0x20  ; true
    // 0x9dc650: StoreField: r1->field_13 = r2
    //     0x9dc650: stur            w2, [x1, #0x13]
    // 0x9dc654: LoadField: r3 = r0->field_5b
    //     0x9dc654: ldur            w3, [x0, #0x5b]
    // 0x9dc658: DecompressPointer r3
    //     0x9dc658: add             x3, x3, HEAP, lsl #32
    // 0x9dc65c: r16 = Sentinel
    //     0x9dc65c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9dc660: cmp             w3, w16
    // 0x9dc664: b.eq            #0x9dc6b0
    // 0x9dc668: cmp             w2, w3
    // 0x9dc66c: b.eq            #0x9dc690
    // 0x9dc670: mov             x2, x1
    // 0x9dc674: r1 = Function '<anonymous closure>':.
    //     0x9dc674: add             x1, PP, #0x50, lsl #12  ; [pp+0x504f0] AnonymousClosure: (0x9dc6bc), in [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseTrackerChange (0x9dc5b0)
    //     0x9dc678: ldr             x1, [x1, #0x4f0]
    // 0x9dc67c: r0 = AllocateClosure()
    //     0x9dc67c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dc680: ldr             x16, [fp, #0x10]
    // 0x9dc684: stp             x0, x16, [SP, #-0x10]!
    // 0x9dc688: r0 = setState()
    //     0x9dc688: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9dc68c: add             SP, SP, #0x10
    // 0x9dc690: r0 = Null
    //     0x9dc690: mov             x0, NULL
    // 0x9dc694: LeaveFrame
    //     0x9dc694: mov             SP, fp
    //     0x9dc698: ldp             fp, lr, [SP], #0x10
    // 0x9dc69c: ret
    //     0x9dc69c: ret             
    // 0x9dc6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc6a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc6a4: b               #0x9dc5c4
    // 0x9dc6a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc6a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dc6ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc6ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dc6b0: r9 = _mouseIsConnected
    //     0x9dc6b0: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d110] Field <TooltipState._mouseIsConnected@838220820>: late (offset: 0x5c)
    //     0x9dc6b4: ldr             x9, [x9, #0x110]
    // 0x9dc6b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9dc6b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9dc6bc, size: 0x48
    // 0x9dc6bc: ldr             x1, [SP]
    // 0x9dc6c0: LoadField: r2 = r1->field_17
    //     0x9dc6c0: ldur            w2, [x1, #0x17]
    // 0x9dc6c4: DecompressPointer r2
    //     0x9dc6c4: add             x2, x2, HEAP, lsl #32
    // 0x9dc6c8: LoadField: r1 = r2->field_f
    //     0x9dc6c8: ldur            w1, [x2, #0xf]
    // 0x9dc6cc: DecompressPointer r1
    //     0x9dc6cc: add             x1, x1, HEAP, lsl #32
    // 0x9dc6d0: LoadField: r0 = r2->field_13
    //     0x9dc6d0: ldur            w0, [x2, #0x13]
    // 0x9dc6d4: DecompressPointer r0
    //     0x9dc6d4: add             x0, x0, HEAP, lsl #32
    // 0x9dc6d8: StoreField: r1->field_5b = r0
    //     0x9dc6d8: stur            w0, [x1, #0x5b]
    //     0x9dc6dc: ldurb           w16, [x1, #-1]
    //     0x9dc6e0: ldurb           w17, [x0, #-1]
    //     0x9dc6e4: and             x16, x17, x16, lsr #2
    //     0x9dc6e8: tst             x16, HEAP, lsr #32
    //     0x9dc6ec: b.eq            #0x9dc6fc
    //     0x9dc6f0: str             lr, [SP, #-8]!
    //     0x9dc6f4: bl              #0xd6826c
    //     0x9dc6f8: ldr             lr, [SP], #8
    // 0x9dc6fc: r0 = Null
    //     0x9dc6fc: mov             x0, NULL
    // 0x9dc700: ret
    //     0x9dc700: ret             
  }
  _ TooltipState(/* No info */) {
    // ** addr: 0xa41b00, size: 0x64
    // 0xa41b00: r2 = Sentinel
    //     0xa41b00: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa41b04: r1 = false
    //     0xa41b04: add             x1, NULL, #0x30  ; false
    // 0xa41b08: ldr             x3, [SP]
    // 0xa41b0c: StoreField: r3->field_1b = r2
    //     0xa41b0c: stur            w2, [x3, #0x1b]
    // 0xa41b10: StoreField: r3->field_1f = r2
    //     0xa41b10: stur            w2, [x3, #0x1f]
    // 0xa41b14: StoreField: r3->field_23 = r2
    //     0xa41b14: stur            w2, [x3, #0x23]
    // 0xa41b18: StoreField: r3->field_27 = r2
    //     0xa41b18: stur            w2, [x3, #0x27]
    // 0xa41b1c: StoreField: r3->field_2b = r2
    //     0xa41b1c: stur            w2, [x3, #0x2b]
    // 0xa41b20: StoreField: r3->field_2f = r2
    //     0xa41b20: stur            w2, [x3, #0x2f]
    // 0xa41b24: StoreField: r3->field_33 = r2
    //     0xa41b24: stur            w2, [x3, #0x33]
    // 0xa41b28: StoreField: r3->field_37 = r2
    //     0xa41b28: stur            w2, [x3, #0x37]
    // 0xa41b2c: StoreField: r3->field_3b = r2
    //     0xa41b2c: stur            w2, [x3, #0x3b]
    // 0xa41b30: StoreField: r3->field_3f = r2
    //     0xa41b30: stur            w2, [x3, #0x3f]
    // 0xa41b34: StoreField: r3->field_4f = r2
    //     0xa41b34: stur            w2, [x3, #0x4f]
    // 0xa41b38: StoreField: r3->field_53 = r2
    //     0xa41b38: stur            w2, [x3, #0x53]
    // 0xa41b3c: StoreField: r3->field_57 = r2
    //     0xa41b3c: stur            w2, [x3, #0x57]
    // 0xa41b40: StoreField: r3->field_5b = r2
    //     0xa41b40: stur            w2, [x3, #0x5b]
    // 0xa41b44: StoreField: r3->field_5f = r1
    //     0xa41b44: stur            w1, [x3, #0x5f]
    // 0xa41b48: StoreField: r3->field_63 = r2
    //     0xa41b48: stur            w2, [x3, #0x63]
    // 0xa41b4c: StoreField: r3->field_67 = r2
    //     0xa41b4c: stur            w2, [x3, #0x67]
    // 0xa41b50: StoreField: r3->field_6b = r2
    //     0xa41b50: stur            w2, [x3, #0x6b]
    // 0xa41b54: StoreField: r3->field_6f = r2
    //     0xa41b54: stur            w2, [x3, #0x6f]
    // 0xa41b58: StoreField: r3->field_73 = r2
    //     0xa41b58: stur            w2, [x3, #0x73]
    // 0xa41b5c: r0 = Null
    //     0xa41b5c: mov             x0, NULL
    // 0xa41b60: ret
    //     0xa41b60: ret             
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b488, size: 0x18
    // 0xa4b488: r4 = 7
    //     0xa4b488: mov             x4, #7
    // 0xa4b48c: r1 = Function 'dispose':.
    //     0xa4b48c: add             x17, PP, #0x50, lsl #12  ; [pp+0x503c8] AnonymousClosure: (0xa4b4a0), in [package:flutter/src/material/tooltip.dart] TooltipState::dispose (0xa533e0)
    //     0xa4b490: ldr             x1, [x17, #0x3c8]
    // 0xa4b494: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b494: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b498: LoadField: r0 = r24->field_17
    //     0xa4b498: ldur            x0, [x24, #0x17]
    // 0xa4b49c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b4a0, size: 0x48
    // 0xa4b4a0: EnterFrame
    //     0xa4b4a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b4a4: mov             fp, SP
    // 0xa4b4a8: ldr             x0, [fp, #0x10]
    // 0xa4b4ac: LoadField: r1 = r0->field_17
    //     0xa4b4ac: ldur            w1, [x0, #0x17]
    // 0xa4b4b0: DecompressPointer r1
    //     0xa4b4b0: add             x1, x1, HEAP, lsl #32
    // 0xa4b4b4: CheckStackOverflow
    //     0xa4b4b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b4b8: cmp             SP, x16
    //     0xa4b4bc: b.ls            #0xa4b4e0
    // 0xa4b4c0: LoadField: r0 = r1->field_f
    //     0xa4b4c0: ldur            w0, [x1, #0xf]
    // 0xa4b4c4: DecompressPointer r0
    //     0xa4b4c4: add             x0, x0, HEAP, lsl #32
    // 0xa4b4c8: SaveReg r0
    //     0xa4b4c8: str             x0, [SP, #-8]!
    // 0xa4b4cc: r0 = dispose()
    //     0xa4b4cc: bl              #0xa533e0  ; [package:flutter/src/material/tooltip.dart] TooltipState::dispose
    // 0xa4b4d0: add             SP, SP, #8
    // 0xa4b4d4: LeaveFrame
    //     0xa4b4d4: mov             SP, fp
    //     0xa4b4d8: ldp             fp, lr, [SP], #0x10
    // 0xa4b4dc: ret
    //     0xa4b4dc: ret             
    // 0xa4b4e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b4e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b4e4: b               #0xa4b4c0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa533e0, size: 0x134
    // 0xa533e0: EnterFrame
    //     0xa533e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa533e4: mov             fp, SP
    // 0xa533e8: AllocStack(0x8)
    //     0xa533e8: sub             SP, SP, #8
    // 0xa533ec: CheckStackOverflow
    //     0xa533ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa533f0: cmp             SP, x16
    //     0xa533f4: b.ls            #0xa534f4
    // 0xa533f8: r0 = LoadStaticField(0xd54)
    //     0xa533f8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa533fc: ldr             x0, [x0, #0x1aa8]
    // 0xa53400: cmp             w0, NULL
    // 0xa53404: b.eq            #0xa534fc
    // 0xa53408: LoadField: r1 = r0->field_13
    //     0xa53408: ldur            w1, [x0, #0x13]
    // 0xa5340c: DecompressPointer r1
    //     0xa5340c: add             x1, x1, HEAP, lsl #32
    // 0xa53410: stur            x1, [fp, #-8]
    // 0xa53414: r1 = 1
    //     0xa53414: mov             x1, #1
    // 0xa53418: r0 = AllocateContext()
    //     0xa53418: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa5341c: mov             x1, x0
    // 0xa53420: ldr             x0, [fp, #0x10]
    // 0xa53424: StoreField: r1->field_f = r0
    //     0xa53424: stur            w0, [x1, #0xf]
    // 0xa53428: mov             x2, x1
    // 0xa5342c: r1 = Function '_handlePointerEvent@838220820':.
    //     0xa5342c: add             x1, PP, #0x50, lsl #12  ; [pp+0x504e0] AnonymousClosure: (0x9dc3d8), in [package:flutter/src/material/tooltip.dart] TooltipState::_handlePointerEvent (0x9dc424)
    //     0xa53430: ldr             x1, [x1, #0x4e0]
    // 0xa53434: r0 = AllocateClosure()
    //     0xa53434: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa53438: ldur            x16, [fp, #-8]
    // 0xa5343c: stp             x0, x16, [SP, #-0x10]!
    // 0xa53440: r0 = removeGlobalRoute()
    //     0xa53440: bl              #0xa535e8  ; [package:flutter/src/gestures/pointer_router.dart] PointerRouter::removeGlobalRoute
    // 0xa53444: add             SP, SP, #0x10
    // 0xa53448: r0 = LoadStaticField(0xea4)
    //     0xa53448: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa5344c: ldr             x0, [x0, #0x1d48]
    // 0xa53450: cmp             w0, NULL
    // 0xa53454: b.eq            #0xa53500
    // 0xa53458: LoadField: r1 = r0->field_b3
    //     0xa53458: ldur            w1, [x0, #0xb3]
    // 0xa5345c: DecompressPointer r1
    //     0xa5345c: add             x1, x1, HEAP, lsl #32
    // 0xa53460: stur            x1, [fp, #-8]
    // 0xa53464: cmp             w1, NULL
    // 0xa53468: b.eq            #0xa53504
    // 0xa5346c: r1 = 1
    //     0xa5346c: mov             x1, #1
    // 0xa53470: r0 = AllocateContext()
    //     0xa53470: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa53474: mov             x1, x0
    // 0xa53478: ldr             x0, [fp, #0x10]
    // 0xa5347c: StoreField: r1->field_f = r0
    //     0xa5347c: stur            w0, [x1, #0xf]
    // 0xa53480: mov             x2, x1
    // 0xa53484: r1 = Function '_handleMouseTrackerChange@838220820':.
    //     0xa53484: add             x1, PP, #0x50, lsl #12  ; [pp+0x504e8] AnonymousClosure: (0x9dc568), in [package:flutter/src/material/tooltip.dart] TooltipState::_handleMouseTrackerChange (0x9dc5b0)
    //     0xa53488: ldr             x1, [x1, #0x4e8]
    // 0xa5348c: r0 = AllocateClosure()
    //     0xa5348c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa53490: ldur            x16, [fp, #-8]
    // 0xa53494: stp             x0, x16, [SP, #-0x10]!
    // 0xa53498: r0 = removeListener()
    //     0xa53498: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa5349c: add             SP, SP, #0x10
    // 0xa534a0: ldr             x16, [fp, #0x10]
    // 0xa534a4: SaveReg r16
    //     0xa534a4: str             x16, [SP, #-8]!
    // 0xa534a8: r0 = _removeEntry()
    //     0xa534a8: bl              #0x795f18  ; [package:flutter/src/material/tooltip.dart] TooltipState::_removeEntry
    // 0xa534ac: add             SP, SP, #8
    // 0xa534b0: ldr             x0, [fp, #0x10]
    // 0xa534b4: LoadField: r1 = r0->field_3f
    //     0xa534b4: ldur            w1, [x0, #0x3f]
    // 0xa534b8: DecompressPointer r1
    //     0xa534b8: add             x1, x1, HEAP, lsl #32
    // 0xa534bc: r16 = Sentinel
    //     0xa534bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa534c0: cmp             w1, w16
    // 0xa534c4: b.eq            #0xa53508
    // 0xa534c8: SaveReg r1
    //     0xa534c8: str             x1, [SP, #-8]!
    // 0xa534cc: r0 = dispose()
    //     0xa534cc: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa534d0: add             SP, SP, #8
    // 0xa534d4: ldr             x16, [fp, #0x10]
    // 0xa534d8: SaveReg r16
    //     0xa534d8: str             x16, [SP, #-8]!
    // 0xa534dc: r0 = dispose()
    //     0xa534dc: bl              #0xa53514  ; [package:flutter/src/material/tooltip.dart] _TooltipState&State&SingleTickerProviderStateMixin::dispose
    // 0xa534e0: add             SP, SP, #8
    // 0xa534e4: r0 = Null
    //     0xa534e4: mov             x0, NULL
    // 0xa534e8: LeaveFrame
    //     0xa534e8: mov             SP, fp
    //     0xa534ec: ldp             fp, lr, [SP], #0x10
    // 0xa534f0: ret
    //     0xa534f0: ret             
    // 0xa534f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa534f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa534f8: b               #0xa533f8
    // 0xa534fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa534fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa53500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa53500: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa53504: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa53504: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa53508: r9 = _controller
    //     0xa53508: add             x9, PP, #0x1d, lsl #12  ; [pp+0x1d118] Field <TooltipState._controller@838220820>: late (offset: 0x40)
    //     0xa5350c: ldr             x9, [x9, #0x118]
    // 0xa53510: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa53510: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa626d8, size: 0x5c
    // 0xa626d8: EnterFrame
    //     0xa626d8: stp             fp, lr, [SP, #-0x10]!
    //     0xa626dc: mov             fp, SP
    // 0xa626e0: CheckStackOverflow
    //     0xa626e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa626e4: cmp             SP, x16
    //     0xa626e8: b.ls            #0xa62728
    // 0xa626ec: ldr             x0, [fp, #0x10]
    // 0xa626f0: LoadField: r1 = r0->field_f
    //     0xa626f0: ldur            w1, [x0, #0xf]
    // 0xa626f4: DecompressPointer r1
    //     0xa626f4: add             x1, x1, HEAP, lsl #32
    // 0xa626f8: cmp             w1, NULL
    // 0xa626fc: b.eq            #0xa62730
    // 0xa62700: SaveReg r1
    //     0xa62700: str             x1, [SP, #-8]!
    // 0xa62704: r0 = of()
    //     0xa62704: bl              #0xa62734  ; [package:flutter/src/material/tooltip_visibility.dart] TooltipVisibility::of
    // 0xa62708: add             SP, SP, #8
    // 0xa6270c: ldr             x2, [fp, #0x10]
    // 0xa62710: r1 = true
    //     0xa62710: add             x1, NULL, #0x20  ; true
    // 0xa62714: StoreField: r2->field_73 = r1
    //     0xa62714: stur            w1, [x2, #0x73]
    // 0xa62718: r0 = Null
    //     0xa62718: mov             x0, NULL
    // 0xa6271c: LeaveFrame
    //     0xa6271c: mov             SP, fp
    //     0xa62720: ldp             fp, lr, [SP], #0x10
    // 0xa62724: ret
    //     0xa62724: ret             
    // 0xa62728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa62728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6272c: b               #0xa626ec
    // 0xa62730: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa62730: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3836, size: 0x48, field offset: 0xc
//   const constructor, 
class _TooltipOverlay extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb24a5c, size: 0x3ac
    // 0xb24a5c: EnterFrame
    //     0xb24a5c: stp             fp, lr, [SP, #-0x10]!
    //     0xb24a60: mov             fp, SP
    // 0xb24a64: AllocStack(0x50)
    //     0xb24a64: sub             SP, SP, #0x50
    // 0xb24a68: CheckStackOverflow
    //     0xb24a68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb24a6c: cmp             SP, x16
    //     0xb24a70: b.ls            #0xb24dd0
    // 0xb24a74: ldr             x0, [fp, #0x18]
    // 0xb24a78: LoadField: r1 = r0->field_2b
    //     0xb24a78: ldur            w1, [x0, #0x2b]
    // 0xb24a7c: DecompressPointer r1
    //     0xb24a7c: add             x1, x1, HEAP, lsl #32
    // 0xb24a80: stur            x1, [fp, #-8]
    // 0xb24a84: LoadField: d0 = r0->field_f
    //     0xb24a84: ldur            d0, [x0, #0xf]
    // 0xb24a88: stur            d0, [fp, #-0x48]
    // 0xb24a8c: r0 = BoxConstraints()
    //     0xb24a8c: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0xb24a90: d0 = 0.000000
    //     0xb24a90: eor             v0.16b, v0.16b, v0.16b
    // 0xb24a94: stur            x0, [fp, #-0x10]
    // 0xb24a98: StoreField: r0->field_7 = d0
    //     0xb24a98: stur            d0, [x0, #7]
    // 0xb24a9c: d0 = inf
    //     0xb24a9c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xb24aa0: StoreField: r0->field_f = d0
    //     0xb24aa0: stur            d0, [x0, #0xf]
    // 0xb24aa4: ldur            d1, [fp, #-0x48]
    // 0xb24aa8: StoreField: r0->field_17 = d1
    //     0xb24aa8: stur            d1, [x0, #0x17]
    // 0xb24aac: StoreField: r0->field_1f = d0
    //     0xb24aac: stur            d0, [x0, #0x1f]
    // 0xb24ab0: ldr             x16, [fp, #0x10]
    // 0xb24ab4: SaveReg r16
    //     0xb24ab4: str             x16, [SP, #-8]!
    // 0xb24ab8: r0 = of()
    //     0xb24ab8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb24abc: add             SP, SP, #8
    // 0xb24ac0: LoadField: r1 = r0->field_93
    //     0xb24ac0: ldur            w1, [x0, #0x93]
    // 0xb24ac4: DecompressPointer r1
    //     0xb24ac4: add             x1, x1, HEAP, lsl #32
    // 0xb24ac8: LoadField: r0 = r1->field_2f
    //     0xb24ac8: ldur            w0, [x1, #0x2f]
    // 0xb24acc: DecompressPointer r0
    //     0xb24acc: add             x0, x0, HEAP, lsl #32
    // 0xb24ad0: stur            x0, [fp, #-0x38]
    // 0xb24ad4: cmp             w0, NULL
    // 0xb24ad8: b.eq            #0xb24dd8
    // 0xb24adc: ldr             x1, [fp, #0x18]
    // 0xb24ae0: LoadField: r2 = r1->field_1f
    //     0xb24ae0: ldur            w2, [x1, #0x1f]
    // 0xb24ae4: DecompressPointer r2
    //     0xb24ae4: add             x2, x2, HEAP, lsl #32
    // 0xb24ae8: stur            x2, [fp, #-0x30]
    // 0xb24aec: LoadField: r3 = r1->field_17
    //     0xb24aec: ldur            w3, [x1, #0x17]
    // 0xb24af0: DecompressPointer r3
    //     0xb24af0: add             x3, x3, HEAP, lsl #32
    // 0xb24af4: stur            x3, [fp, #-0x28]
    // 0xb24af8: LoadField: r4 = r1->field_b
    //     0xb24af8: ldur            w4, [x1, #0xb]
    // 0xb24afc: DecompressPointer r4
    //     0xb24afc: add             x4, x4, HEAP, lsl #32
    // 0xb24b00: stur            x4, [fp, #-0x20]
    // 0xb24b04: LoadField: r5 = r1->field_23
    //     0xb24b04: ldur            w5, [x1, #0x23]
    // 0xb24b08: DecompressPointer r5
    //     0xb24b08: add             x5, x5, HEAP, lsl #32
    // 0xb24b0c: stur            x5, [fp, #-0x18]
    // 0xb24b10: r0 = Text()
    //     0xb24b10: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0xb24b14: mov             x1, x0
    // 0xb24b18: ldur            x0, [fp, #-0x20]
    // 0xb24b1c: stur            x1, [fp, #-0x40]
    // 0xb24b20: StoreField: r1->field_f = r0
    //     0xb24b20: stur            w0, [x1, #0xf]
    // 0xb24b24: ldur            x0, [fp, #-0x18]
    // 0xb24b28: StoreField: r1->field_13 = r0
    //     0xb24b28: stur            w0, [x1, #0x13]
    // 0xb24b2c: r0 = Instance_TextAlign
    //     0xb24b2c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0xb24b30: ldr             x0, [x0, #0xfe8]
    // 0xb24b34: StoreField: r1->field_1b = r0
    //     0xb24b34: stur            w0, [x1, #0x1b]
    // 0xb24b38: r0 = Center()
    //     0xb24b38: bl              #0x826060  ; AllocateCenterStub -> Center (size=0x1c)
    // 0xb24b3c: mov             x1, x0
    // 0xb24b40: r0 = Instance_Alignment
    //     0xb24b40: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb24b44: ldr             x0, [x0, #0xc70]
    // 0xb24b48: stur            x1, [fp, #-0x18]
    // 0xb24b4c: StoreField: r1->field_f = r0
    //     0xb24b4c: stur            w0, [x1, #0xf]
    // 0xb24b50: r0 = 1.000000
    //     0xb24b50: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb24b54: StoreField: r1->field_13 = r0
    //     0xb24b54: stur            w0, [x1, #0x13]
    // 0xb24b58: StoreField: r1->field_17 = r0
    //     0xb24b58: stur            w0, [x1, #0x17]
    // 0xb24b5c: ldur            x0, [fp, #-0x40]
    // 0xb24b60: StoreField: r1->field_b = r0
    //     0xb24b60: stur            w0, [x1, #0xb]
    // 0xb24b64: r0 = Container()
    //     0xb24b64: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb24b68: stur            x0, [fp, #-0x20]
    // 0xb24b6c: ldur            x16, [fp, #-0x30]
    // 0xb24b70: stp             x16, x0, [SP, #-0x10]!
    // 0xb24b74: ldur            x16, [fp, #-0x28]
    // 0xb24b78: r30 = Instance_EdgeInsets
    //     0xb24b78: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbd8] Obj!EdgeInsets@b35ab1
    //     0xb24b7c: ldr             lr, [lr, #0xbd8]
    // 0xb24b80: stp             lr, x16, [SP, #-0x10]!
    // 0xb24b84: ldur            x16, [fp, #-0x18]
    // 0xb24b88: SaveReg r16
    //     0xb24b88: str             x16, [SP, #-8]!
    // 0xb24b8c: r4 = const [0, 0x5, 0x5, 0x1, child, 0x4, decoration, 0x1, margin, 0x3, padding, 0x2, null]
    //     0xb24b8c: add             x4, PP, #0x27, lsl #12  ; [pp+0x278d8] List(13) [0, 0x5, 0x5, 0x1, "child", 0x4, "decoration", 0x1, "margin", 0x3, "padding", 0x2, Null]
    //     0xb24b90: ldr             x4, [x4, #0x8d8]
    // 0xb24b94: r0 = Container()
    //     0xb24b94: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb24b98: add             SP, SP, #0x28
    // 0xb24b9c: r0 = DefaultTextStyle()
    //     0xb24b9c: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0xb24ba0: mov             x1, x0
    // 0xb24ba4: ldur            x0, [fp, #-0x38]
    // 0xb24ba8: stur            x1, [fp, #-0x18]
    // 0xb24bac: StoreField: r1->field_f = r0
    //     0xb24bac: stur            w0, [x1, #0xf]
    // 0xb24bb0: r0 = true
    //     0xb24bb0: add             x0, NULL, #0x20  ; true
    // 0xb24bb4: StoreField: r1->field_17 = r0
    //     0xb24bb4: stur            w0, [x1, #0x17]
    // 0xb24bb8: r2 = Instance_TextOverflow
    //     0xb24bb8: add             x2, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0xb24bbc: ldr             x2, [x2, #0x118]
    // 0xb24bc0: StoreField: r1->field_1b = r2
    //     0xb24bc0: stur            w2, [x1, #0x1b]
    // 0xb24bc4: r2 = Instance_TextWidthBasis
    //     0xb24bc4: add             x2, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0xb24bc8: ldr             x2, [x2, #0x148]
    // 0xb24bcc: StoreField: r1->field_23 = r2
    //     0xb24bcc: stur            w2, [x1, #0x23]
    // 0xb24bd0: ldur            x2, [fp, #-0x20]
    // 0xb24bd4: StoreField: r1->field_b = r2
    //     0xb24bd4: stur            w2, [x1, #0xb]
    // 0xb24bd8: r0 = ConstrainedBox()
    //     0xb24bd8: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0xb24bdc: mov             x1, x0
    // 0xb24be0: ldur            x0, [fp, #-0x10]
    // 0xb24be4: stur            x1, [fp, #-0x20]
    // 0xb24be8: StoreField: r1->field_f = r0
    //     0xb24be8: stur            w0, [x1, #0xf]
    // 0xb24bec: ldur            x0, [fp, #-0x18]
    // 0xb24bf0: StoreField: r1->field_b = r0
    //     0xb24bf0: stur            w0, [x1, #0xb]
    // 0xb24bf4: r0 = FadeTransition()
    //     0xb24bf4: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xb24bf8: mov             x1, x0
    // 0xb24bfc: ldur            x0, [fp, #-8]
    // 0xb24c00: stur            x1, [fp, #-0x10]
    // 0xb24c04: StoreField: r1->field_f = r0
    //     0xb24c04: stur            w0, [x1, #0xf]
    // 0xb24c08: r0 = false
    //     0xb24c08: add             x0, NULL, #0x30  ; false
    // 0xb24c0c: StoreField: r1->field_13 = r0
    //     0xb24c0c: stur            w0, [x1, #0x13]
    // 0xb24c10: ldur            x0, [fp, #-0x20]
    // 0xb24c14: StoreField: r1->field_b = r0
    //     0xb24c14: stur            w0, [x1, #0xb]
    // 0xb24c18: r0 = IgnorePointer()
    //     0xb24c18: bl              #0x8303bc  ; AllocateIgnorePointerStub -> IgnorePointer (size=0x18)
    // 0xb24c1c: mov             x1, x0
    // 0xb24c20: r0 = true
    //     0xb24c20: add             x0, NULL, #0x20  ; true
    // 0xb24c24: stur            x1, [fp, #-0x18]
    // 0xb24c28: StoreField: r1->field_f = r0
    //     0xb24c28: stur            w0, [x1, #0xf]
    // 0xb24c2c: ldur            x2, [fp, #-0x10]
    // 0xb24c30: StoreField: r1->field_b = r2
    //     0xb24c30: stur            w2, [x1, #0xb]
    // 0xb24c34: ldr             x2, [fp, #0x18]
    // 0xb24c38: LoadField: r3 = r2->field_3f
    //     0xb24c38: ldur            w3, [x2, #0x3f]
    // 0xb24c3c: DecompressPointer r3
    //     0xb24c3c: add             x3, x3, HEAP, lsl #32
    // 0xb24c40: stur            x3, [fp, #-0x10]
    // 0xb24c44: cmp             w3, NULL
    // 0xb24c48: b.ne            #0xb24c5c
    // 0xb24c4c: LoadField: r4 = r2->field_43
    //     0xb24c4c: ldur            w4, [x2, #0x43]
    // 0xb24c50: DecompressPointer r4
    //     0xb24c50: add             x4, x4, HEAP, lsl #32
    // 0xb24c54: cmp             w4, NULL
    // 0xb24c58: b.eq            #0xb24c9c
    // 0xb24c5c: LoadField: r4 = r2->field_43
    //     0xb24c5c: ldur            w4, [x2, #0x43]
    // 0xb24c60: DecompressPointer r4
    //     0xb24c60: add             x4, x4, HEAP, lsl #32
    // 0xb24c64: stur            x4, [fp, #-8]
    // 0xb24c68: r0 = MouseRegion()
    //     0xb24c68: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0xb24c6c: mov             x1, x0
    // 0xb24c70: ldur            x0, [fp, #-0x10]
    // 0xb24c74: StoreField: r1->field_f = r0
    //     0xb24c74: stur            w0, [x1, #0xf]
    // 0xb24c78: ldur            x0, [fp, #-8]
    // 0xb24c7c: StoreField: r1->field_17 = r0
    //     0xb24c7c: stur            w0, [x1, #0x17]
    // 0xb24c80: r0 = Instance__DeferringMouseCursor
    //     0xb24c80: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0xb24c84: StoreField: r1->field_1b = r0
    //     0xb24c84: stur            w0, [x1, #0x1b]
    // 0xb24c88: r0 = true
    //     0xb24c88: add             x0, NULL, #0x20  ; true
    // 0xb24c8c: StoreField: r1->field_1f = r0
    //     0xb24c8c: stur            w0, [x1, #0x1f]
    // 0xb24c90: ldur            x2, [fp, #-0x18]
    // 0xb24c94: StoreField: r1->field_b = r2
    //     0xb24c94: stur            w2, [x1, #0xb]
    // 0xb24c98: b               #0xb24ca4
    // 0xb24c9c: mov             x2, x1
    // 0xb24ca0: mov             x1, x2
    // 0xb24ca4: stur            x1, [fp, #-8]
    // 0xb24ca8: ldr             x16, [fp, #0x10]
    // 0xb24cac: SaveReg r16
    //     0xb24cac: str             x16, [SP, #-8]!
    // 0xb24cb0: r0 = maybeOf()
    //     0xb24cb0: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0xb24cb4: add             SP, SP, #8
    // 0xb24cb8: cmp             w0, NULL
    // 0xb24cbc: b.ne            #0xb24cc8
    // 0xb24cc0: r0 = Null
    //     0xb24cc0: mov             x0, NULL
    // 0xb24cc4: b               #0xb24cfc
    // 0xb24cc8: LoadField: r1 = r0->field_1f
    //     0xb24cc8: ldur            w1, [x0, #0x1f]
    // 0xb24ccc: DecompressPointer r1
    //     0xb24ccc: add             x1, x1, HEAP, lsl #32
    // 0xb24cd0: LoadField: d0 = r1->field_1f
    //     0xb24cd0: ldur            d0, [x1, #0x1f]
    // 0xb24cd4: r0 = inline_Allocate_Double()
    //     0xb24cd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb24cd8: add             x0, x0, #0x10
    //     0xb24cdc: cmp             x1, x0
    //     0xb24ce0: b.ls            #0xb24ddc
    //     0xb24ce4: str             x0, [THR, #0x60]  ; THR::top
    //     0xb24ce8: sub             x0, x0, #0xf
    //     0xb24cec: mov             x1, #0xd108
    //     0xb24cf0: movk            x1, #3, lsl #16
    //     0xb24cf4: stur            x1, [x0, #-1]
    // 0xb24cf8: StoreField: r0->field_7 = d0
    //     0xb24cf8: stur            d0, [x0, #7]
    // 0xb24cfc: cmp             w0, NULL
    // 0xb24d00: b.ne            #0xb24d0c
    // 0xb24d04: d0 = 0.000000
    //     0xb24d04: eor             v0.16b, v0.16b, v0.16b
    // 0xb24d08: b               #0xb24d10
    // 0xb24d0c: LoadField: d0 = r0->field_7
    //     0xb24d0c: ldur            d0, [x0, #7]
    // 0xb24d10: ldr             x1, [fp, #0x18]
    // 0xb24d14: ldur            x0, [fp, #-8]
    // 0xb24d18: stur            d0, [fp, #-0x50]
    // 0xb24d1c: LoadField: r2 = r1->field_2f
    //     0xb24d1c: ldur            w2, [x1, #0x2f]
    // 0xb24d20: DecompressPointer r2
    //     0xb24d20: add             x2, x2, HEAP, lsl #32
    // 0xb24d24: stur            x2, [fp, #-0x10]
    // 0xb24d28: LoadField: d1 = r1->field_33
    //     0xb24d28: ldur            d1, [x1, #0x33]
    // 0xb24d2c: stur            d1, [fp, #-0x48]
    // 0xb24d30: r0 = _TooltipPositionDelegate()
    //     0xb24d30: bl              #0xb24e08  ; Allocate_TooltipPositionDelegateStub -> _TooltipPositionDelegate (size=0x1c)
    // 0xb24d34: mov             x1, x0
    // 0xb24d38: ldur            x0, [fp, #-0x10]
    // 0xb24d3c: stur            x1, [fp, #-0x18]
    // 0xb24d40: StoreField: r1->field_b = r0
    //     0xb24d40: stur            w0, [x1, #0xb]
    // 0xb24d44: ldur            d0, [fp, #-0x48]
    // 0xb24d48: StoreField: r1->field_f = d0
    //     0xb24d48: stur            d0, [x1, #0xf]
    // 0xb24d4c: r0 = true
    //     0xb24d4c: add             x0, NULL, #0x20  ; true
    // 0xb24d50: StoreField: r1->field_17 = r0
    //     0xb24d50: stur            w0, [x1, #0x17]
    // 0xb24d54: r0 = CustomSingleChildLayout()
    //     0xb24d54: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xb24d58: mov             x2, x0
    // 0xb24d5c: ldur            x0, [fp, #-0x18]
    // 0xb24d60: stur            x2, [fp, #-0x10]
    // 0xb24d64: StoreField: r2->field_f = r0
    //     0xb24d64: stur            w0, [x2, #0xf]
    // 0xb24d68: ldur            x0, [fp, #-8]
    // 0xb24d6c: StoreField: r2->field_b = r0
    //     0xb24d6c: stur            w0, [x2, #0xb]
    // 0xb24d70: r1 = <StackParentData<RenderBox>>
    //     0xb24d70: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1c5a8] TypeArguments: <StackParentData<RenderBox>>
    //     0xb24d74: ldr             x1, [x1, #0x5a8]
    // 0xb24d78: r0 = Positioned()
    //     0xb24d78: bl              #0x8278a0  ; AllocatePositionedStub -> Positioned (size=0x2c)
    // 0xb24d7c: r1 = 0.000000
    //     0xb24d7c: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xb24d80: StoreField: r0->field_13 = r1
    //     0xb24d80: stur            w1, [x0, #0x13]
    // 0xb24d84: StoreField: r0->field_17 = r1
    //     0xb24d84: stur            w1, [x0, #0x17]
    // 0xb24d88: StoreField: r0->field_1b = r1
    //     0xb24d88: stur            w1, [x0, #0x1b]
    // 0xb24d8c: ldur            d0, [fp, #-0x50]
    // 0xb24d90: r1 = inline_Allocate_Double()
    //     0xb24d90: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xb24d94: add             x1, x1, #0x10
    //     0xb24d98: cmp             x2, x1
    //     0xb24d9c: b.ls            #0xb24dec
    //     0xb24da0: str             x1, [THR, #0x60]  ; THR::top
    //     0xb24da4: sub             x1, x1, #0xf
    //     0xb24da8: mov             x2, #0xd108
    //     0xb24dac: movk            x2, #3, lsl #16
    //     0xb24db0: stur            x2, [x1, #-1]
    // 0xb24db4: StoreField: r1->field_7 = d0
    //     0xb24db4: stur            d0, [x1, #7]
    // 0xb24db8: StoreField: r0->field_1f = r1
    //     0xb24db8: stur            w1, [x0, #0x1f]
    // 0xb24dbc: ldur            x1, [fp, #-0x10]
    // 0xb24dc0: StoreField: r0->field_b = r1
    //     0xb24dc0: stur            w1, [x0, #0xb]
    // 0xb24dc4: LeaveFrame
    //     0xb24dc4: mov             SP, fp
    //     0xb24dc8: ldp             fp, lr, [SP], #0x10
    // 0xb24dcc: ret
    //     0xb24dcc: ret             
    // 0xb24dd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb24dd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb24dd4: b               #0xb24a74
    // 0xb24dd8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb24dd8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xb24ddc: SaveReg d0
    //     0xb24ddc: str             q0, [SP, #-0x10]!
    // 0xb24de0: r0 = AllocateDouble()
    //     0xb24de0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb24de4: RestoreReg d0
    //     0xb24de4: ldr             q0, [SP], #0x10
    // 0xb24de8: b               #0xb24cf8
    // 0xb24dec: SaveReg d0
    //     0xb24dec: str             q0, [SP, #-0x10]!
    // 0xb24df0: SaveReg r0
    //     0xb24df0: str             x0, [SP, #-8]!
    // 0xb24df4: r0 = AllocateDouble()
    //     0xb24df4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb24df8: mov             x1, x0
    // 0xb24dfc: RestoreReg r0
    //     0xb24dfc: ldr             x0, [SP], #8
    // 0xb24e00: RestoreReg d0
    //     0xb24e00: ldr             q0, [SP], #0x10
    // 0xb24e04: b               #0xb24db4
  }
}

// class id: 4110, size: 0x50, field offset: 0xc
//   const constructor, 
class Tooltip extends StatefulWidget {

  static late final List<TooltipState> _openedTooltips; // offset: 0xe4c

  static void _revealLastTooltip() {
    // ** addr: 0x796068, size: 0x70
    // 0x796068: EnterFrame
    //     0x796068: stp             fp, lr, [SP, #-0x10]!
    //     0x79606c: mov             fp, SP
    // 0x796070: CheckStackOverflow
    //     0x796070: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x796074: cmp             SP, x16
    //     0x796078: b.ls            #0x7960d0
    // 0x79607c: r0 = InitLateStaticField(0xe4c) // [package:flutter/src/material/tooltip.dart] Tooltip::_openedTooltips
    //     0x79607c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x796080: ldr             x0, [x0, #0x1c98]
    //     0x796084: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x796088: cmp             w0, w16
    //     0x79608c: b.ne            #0x79609c
    //     0x796090: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d0f8] Field <Tooltip._openedTooltips@838220820>: static late final (offset: 0xe4c)
    //     0x796094: ldr             x2, [x2, #0xf8]
    //     0x796098: bl              #0xd67cdc
    // 0x79609c: LoadField: r1 = r0->field_b
    //     0x79609c: ldur            w1, [x0, #0xb]
    // 0x7960a0: DecompressPointer r1
    //     0x7960a0: add             x1, x1, HEAP, lsl #32
    // 0x7960a4: cbz             w1, #0x7960c0
    // 0x7960a8: SaveReg r0
    //     0x7960a8: str             x0, [SP, #-8]!
    // 0x7960ac: r0 = last()
    //     0x7960ac: bl              #0x621d20  ; [dart:core] _GrowableList::last
    // 0x7960b0: add             SP, SP, #8
    // 0x7960b4: SaveReg r0
    //     0x7960b4: str             x0, [SP, #-8]!
    // 0x7960b8: r0 = _revealTooltip()
    //     0x7960b8: bl              #0x7960d8  ; [package:flutter/src/material/tooltip.dart] TooltipState::_revealTooltip
    // 0x7960bc: add             SP, SP, #8
    // 0x7960c0: r0 = Null
    //     0x7960c0: mov             x0, NULL
    // 0x7960c4: LeaveFrame
    //     0x7960c4: mov             SP, fp
    //     0x7960c8: ldp             fp, lr, [SP], #0x10
    // 0x7960cc: ret
    //     0x7960cc: ret             
    // 0x7960d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7960d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7960d4: b               #0x79607c
  }
  static List<TooltipState> _openedTooltips() {
    // ** addr: 0x79653c, size: 0x3c
    // 0x79653c: EnterFrame
    //     0x79653c: stp             fp, lr, [SP, #-0x10]!
    //     0x796540: mov             fp, SP
    // 0x796544: CheckStackOverflow
    //     0x796544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x796548: cmp             SP, x16
    //     0x79654c: b.ls            #0x796570
    // 0x796550: r16 = <TooltipState<Tooltip>>
    //     0x796550: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d130] TypeArguments: <TooltipState<Tooltip>>
    //     0x796554: ldr             x16, [x16, #0x130]
    // 0x796558: stp             xzr, x16, [SP, #-0x10]!
    // 0x79655c: r0 = _GrowableList()
    //     0x79655c: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x796560: add             SP, SP, #0x10
    // 0x796564: LeaveFrame
    //     0x796564: mov             SP, fp
    //     0x796568: ldp             fp, lr, [SP], #0x10
    // 0x79656c: ret
    //     0x79656c: ret             
    // 0x796570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x796570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x796574: b               #0x796550
  }
  static bool dismissAllToolTips() {
    // ** addr: 0x846244, size: 0x138
    // 0x846244: EnterFrame
    //     0x846244: stp             fp, lr, [SP, #-0x10]!
    //     0x846248: mov             fp, SP
    // 0x84624c: AllocStack(0x10)
    //     0x84624c: sub             SP, SP, #0x10
    // 0x846250: CheckStackOverflow
    //     0x846250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x846254: cmp             SP, x16
    //     0x846258: b.ls            #0x84636c
    // 0x84625c: r0 = InitLateStaticField(0xe4c) // [package:flutter/src/material/tooltip.dart] Tooltip::_openedTooltips
    //     0x84625c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x846260: ldr             x0, [x0, #0x1c98]
    //     0x846264: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x846268: cmp             w0, w16
    //     0x84626c: b.ne            #0x84627c
    //     0x846270: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d0f8] Field <Tooltip._openedTooltips@838220820>: static late final (offset: 0xe4c)
    //     0x846274: ldr             x2, [x2, #0xf8]
    //     0x846278: bl              #0xd67cdc
    // 0x84627c: LoadField: r1 = r0->field_b
    //     0x84627c: ldur            w1, [x0, #0xb]
    // 0x846280: DecompressPointer r1
    //     0x846280: add             x1, x1, HEAP, lsl #32
    // 0x846284: cbz             w1, #0x84635c
    // 0x846288: SaveReg r0
    //     0x846288: str             x0, [SP, #-8]!
    // 0x84628c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x84628c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x846290: r0 = toList()
    //     0x846290: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0x846294: add             SP, SP, #8
    // 0x846298: r1 = LoadClassIdInstr(r0)
    //     0x846298: ldur            x1, [x0, #-1]
    //     0x84629c: ubfx            x1, x1, #0xc, #0x14
    // 0x8462a0: SaveReg r0
    //     0x8462a0: str             x0, [SP, #-8]!
    // 0x8462a4: mov             x0, x1
    // 0x8462a8: r0 = GDT[cid_x0 + 0xb940]()
    //     0x8462a8: mov             x17, #0xb940
    //     0x8462ac: add             lr, x0, x17
    //     0x8462b0: ldr             lr, [x21, lr, lsl #3]
    //     0x8462b4: blr             lr
    // 0x8462b8: add             SP, SP, #8
    // 0x8462bc: mov             x1, x0
    // 0x8462c0: stur            x1, [fp, #-8]
    // 0x8462c4: CheckStackOverflow
    //     0x8462c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8462c8: cmp             SP, x16
    //     0x8462cc: b.ls            #0x846374
    // 0x8462d0: r0 = LoadClassIdInstr(r1)
    //     0x8462d0: ldur            x0, [x1, #-1]
    //     0x8462d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8462d8: SaveReg r1
    //     0x8462d8: str             x1, [SP, #-8]!
    // 0x8462dc: r0 = GDT[cid_x0 + 0x541]()
    //     0x8462dc: add             lr, x0, #0x541
    //     0x8462e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8462e4: blr             lr
    // 0x8462e8: add             SP, SP, #8
    // 0x8462ec: tbnz            w0, #4, #0x84634c
    // 0x8462f0: ldur            x1, [fp, #-8]
    // 0x8462f4: r0 = LoadClassIdInstr(r1)
    //     0x8462f4: ldur            x0, [x1, #-1]
    //     0x8462f8: ubfx            x0, x0, #0xc, #0x14
    // 0x8462fc: SaveReg r1
    //     0x8462fc: str             x1, [SP, #-8]!
    // 0x846300: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x846300: add             lr, x0, #0x5ca
    //     0x846304: ldr             lr, [x21, lr, lsl #3]
    //     0x846308: blr             lr
    // 0x84630c: add             SP, SP, #8
    // 0x846310: stur            x0, [fp, #-0x10]
    // 0x846314: LoadField: r1 = r0->field_4b
    //     0x846314: ldur            w1, [x0, #0x4b]
    // 0x846318: DecompressPointer r1
    //     0x846318: add             x1, x1, HEAP, lsl #32
    // 0x84631c: cmp             w1, NULL
    // 0x846320: b.eq            #0x846334
    // 0x846324: SaveReg r1
    //     0x846324: str             x1, [SP, #-8]!
    // 0x846328: r0 = cancel()
    //     0x846328: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x84632c: add             SP, SP, #8
    // 0x846330: ldur            x0, [fp, #-0x10]
    // 0x846334: StoreField: r0->field_4b = rNULL
    //     0x846334: stur            NULL, [x0, #0x4b]
    // 0x846338: SaveReg r0
    //     0x846338: str             x0, [SP, #-8]!
    // 0x84633c: r0 = _removeEntry()
    //     0x84633c: bl              #0x795f18  ; [package:flutter/src/material/tooltip.dart] TooltipState::_removeEntry
    // 0x846340: add             SP, SP, #8
    // 0x846344: ldur            x1, [fp, #-8]
    // 0x846348: b               #0x8462c4
    // 0x84634c: r0 = true
    //     0x84634c: add             x0, NULL, #0x20  ; true
    // 0x846350: LeaveFrame
    //     0x846350: mov             SP, fp
    //     0x846354: ldp             fp, lr, [SP], #0x10
    // 0x846358: ret
    //     0x846358: ret             
    // 0x84635c: r0 = false
    //     0x84635c: add             x0, NULL, #0x30  ; false
    // 0x846360: LeaveFrame
    //     0x846360: mov             SP, fp
    //     0x846364: ldp             fp, lr, [SP], #0x10
    // 0x846368: ret
    //     0x846368: ret             
    // 0x84636c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84636c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846370: b               #0x84625c
    // 0x846374: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x846374: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x846378: b               #0x8462d0
  }
  static _ _concealOtherTooltips(/* No info */) {
    // ** addr: 0x8757b8, size: 0x118
    // 0x8757b8: EnterFrame
    //     0x8757b8: stp             fp, lr, [SP, #-0x10]!
    //     0x8757bc: mov             fp, SP
    // 0x8757c0: AllocStack(0x8)
    //     0x8757c0: sub             SP, SP, #8
    // 0x8757c4: CheckStackOverflow
    //     0x8757c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8757c8: cmp             SP, x16
    //     0x8757cc: b.ls            #0x8758c0
    // 0x8757d0: r0 = InitLateStaticField(0xe4c) // [package:flutter/src/material/tooltip.dart] Tooltip::_openedTooltips
    //     0x8757d0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x8757d4: ldr             x0, [x0, #0x1c98]
    //     0x8757d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x8757dc: cmp             w0, w16
    //     0x8757e0: b.ne            #0x8757f0
    //     0x8757e4: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d0f8] Field <Tooltip._openedTooltips@838220820>: static late final (offset: 0xe4c)
    //     0x8757e8: ldr             x2, [x2, #0xf8]
    //     0x8757ec: bl              #0xd67cdc
    // 0x8757f0: LoadField: r1 = r0->field_b
    //     0x8757f0: ldur            w1, [x0, #0xb]
    // 0x8757f4: DecompressPointer r1
    //     0x8757f4: add             x1, x1, HEAP, lsl #32
    // 0x8757f8: cbz             w1, #0x8758b0
    // 0x8757fc: SaveReg r0
    //     0x8757fc: str             x0, [SP, #-8]!
    // 0x875800: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x875800: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x875804: r0 = toList()
    //     0x875804: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0x875808: add             SP, SP, #8
    // 0x87580c: r1 = LoadClassIdInstr(r0)
    //     0x87580c: ldur            x1, [x0, #-1]
    //     0x875810: ubfx            x1, x1, #0xc, #0x14
    // 0x875814: SaveReg r0
    //     0x875814: str             x0, [SP, #-8]!
    // 0x875818: mov             x0, x1
    // 0x87581c: r0 = GDT[cid_x0 + 0xb940]()
    //     0x87581c: mov             x17, #0xb940
    //     0x875820: add             lr, x0, x17
    //     0x875824: ldr             lr, [x21, lr, lsl #3]
    //     0x875828: blr             lr
    // 0x87582c: add             SP, SP, #8
    // 0x875830: mov             x1, x0
    // 0x875834: stur            x1, [fp, #-8]
    // 0x875838: ldr             x2, [fp, #0x10]
    // 0x87583c: CheckStackOverflow
    //     0x87583c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x875840: cmp             SP, x16
    //     0x875844: b.ls            #0x8758c8
    // 0x875848: r0 = LoadClassIdInstr(r1)
    //     0x875848: ldur            x0, [x1, #-1]
    //     0x87584c: ubfx            x0, x0, #0xc, #0x14
    // 0x875850: SaveReg r1
    //     0x875850: str             x1, [SP, #-8]!
    // 0x875854: r0 = GDT[cid_x0 + 0x541]()
    //     0x875854: add             lr, x0, #0x541
    //     0x875858: ldr             lr, [x21, lr, lsl #3]
    //     0x87585c: blr             lr
    // 0x875860: add             SP, SP, #8
    // 0x875864: tbnz            w0, #4, #0x8758b0
    // 0x875868: ldr             x2, [fp, #0x10]
    // 0x87586c: ldur            x1, [fp, #-8]
    // 0x875870: r0 = LoadClassIdInstr(r1)
    //     0x875870: ldur            x0, [x1, #-1]
    //     0x875874: ubfx            x0, x0, #0xc, #0x14
    // 0x875878: SaveReg r1
    //     0x875878: str             x1, [SP, #-8]!
    // 0x87587c: r0 = GDT[cid_x0 + 0x5ca]()
    //     0x87587c: add             lr, x0, #0x5ca
    //     0x875880: ldr             lr, [x21, lr, lsl #3]
    //     0x875884: blr             lr
    // 0x875888: add             SP, SP, #8
    // 0x87588c: mov             x1, x0
    // 0x875890: ldr             x0, [fp, #0x10]
    // 0x875894: cmp             w1, w0
    // 0x875898: b.eq            #0x8758a8
    // 0x87589c: SaveReg r1
    //     0x87589c: str             x1, [SP, #-8]!
    // 0x8758a0: r0 = _concealTooltip()
    //     0x8758a0: bl              #0x8758d0  ; [package:flutter/src/material/tooltip.dart] TooltipState::_concealTooltip
    // 0x8758a4: add             SP, SP, #8
    // 0x8758a8: ldur            x1, [fp, #-8]
    // 0x8758ac: b               #0x875838
    // 0x8758b0: r0 = Null
    //     0x8758b0: mov             x0, NULL
    // 0x8758b4: LeaveFrame
    //     0x8758b4: mov             SP, fp
    //     0x8758b8: ldp             fp, lr, [SP], #0x10
    // 0x8758bc: ret
    //     0x8758bc: ret             
    // 0x8758c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8758c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8758c4: b               #0x8757d0
    // 0x8758c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8758c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8758cc: b               #0x875848
  }
  _ createState(/* No info */) {
    // ** addr: 0xa41ab4, size: 0x4c
    // 0xa41ab4: EnterFrame
    //     0xa41ab4: stp             fp, lr, [SP, #-0x10]!
    //     0xa41ab8: mov             fp, SP
    // 0xa41abc: AllocStack(0x8)
    //     0xa41abc: sub             SP, SP, #8
    // 0xa41ac0: CheckStackOverflow
    //     0xa41ac0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa41ac4: cmp             SP, x16
    //     0xa41ac8: b.ls            #0xa41af8
    // 0xa41acc: r1 = <Tooltip>
    //     0xa41acc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b4a8] TypeArguments: <Tooltip>
    //     0xa41ad0: ldr             x1, [x1, #0x4a8]
    // 0xa41ad4: r0 = TooltipState()
    //     0xa41ad4: bl              #0xa41b64  ; AllocateTooltipStateStub -> TooltipState (size=0x78)
    // 0xa41ad8: stur            x0, [fp, #-8]
    // 0xa41adc: SaveReg r0
    //     0xa41adc: str             x0, [SP, #-8]!
    // 0xa41ae0: r0 = TooltipState()
    //     0xa41ae0: bl              #0xa41b00  ; [package:flutter/src/material/tooltip.dart] TooltipState::TooltipState
    // 0xa41ae4: add             SP, SP, #8
    // 0xa41ae8: ldur            x0, [fp, #-8]
    // 0xa41aec: LeaveFrame
    //     0xa41aec: mov             SP, fp
    //     0xa41af0: ldp             fp, lr, [SP], #0x10
    // 0xa41af4: ret
    //     0xa41af4: ret             
    // 0xa41af8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa41af8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa41afc: b               #0xa41acc
  }
}

// lib: , url: package:flutter/src/material/back_button.dart

// class id: 1049183, size: 0x8
class :: {
}

// class id: 3863, size: 0x14, field offset: 0xc
//   const constructor, 
class BackButton extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1e0f0, size: 0x98
    // 0xb1e0f0: EnterFrame
    //     0xb1e0f0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e0f4: mov             fp, SP
    // 0xb1e0f8: AllocStack(0x8)
    //     0xb1e0f8: sub             SP, SP, #8
    // 0xb1e0fc: CheckStackOverflow
    //     0xb1e0fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1e100: cmp             SP, x16
    //     0xb1e104: b.ls            #0xb1e180
    // 0xb1e108: r1 = 2
    //     0xb1e108: mov             x1, #2
    // 0xb1e10c: r0 = AllocateContext()
    //     0xb1e10c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb1e110: mov             x1, x0
    // 0xb1e114: ldr             x0, [fp, #0x18]
    // 0xb1e118: stur            x1, [fp, #-8]
    // 0xb1e11c: StoreField: r1->field_f = r0
    //     0xb1e11c: stur            w0, [x1, #0xf]
    // 0xb1e120: ldr             x0, [fp, #0x10]
    // 0xb1e124: StoreField: r1->field_13 = r0
    //     0xb1e124: stur            w0, [x1, #0x13]
    // 0xb1e128: SaveReg r0
    //     0xb1e128: str             x0, [SP, #-8]!
    // 0xb1e12c: r0 = of()
    //     0xb1e12c: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xb1e130: add             SP, SP, #8
    // 0xb1e134: ldur            x2, [fp, #-8]
    // 0xb1e138: r1 = Function '<anonymous closure>':.
    //     0xb1e138: add             x1, PP, #0x40, lsl #12  ; [pp+0x402e0] AnonymousClosure: (0xb1e188), in [package:flutter/src/material/back_button.dart] BackButton::build (0xb1e0f0)
    //     0xb1e13c: ldr             x1, [x1, #0x2e0]
    // 0xb1e140: r0 = AllocateClosure()
    //     0xb1e140: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1e144: stur            x0, [fp, #-8]
    // 0xb1e148: r0 = IconButton()
    //     0xb1e148: bl              #0x825364  ; AllocateIconButtonStub -> IconButton (size=0x64)
    // 0xb1e14c: ldur            x1, [fp, #-8]
    // 0xb1e150: StoreField: r0->field_3b = r1
    //     0xb1e150: stur            w1, [x0, #0x3b]
    // 0xb1e154: r1 = false
    //     0xb1e154: add             x1, NULL, #0x30  ; false
    // 0xb1e158: StoreField: r0->field_47 = r1
    //     0xb1e158: stur            w1, [x0, #0x47]
    // 0xb1e15c: r1 = "Back"
    //     0xb1e15c: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fe78] "Back"
    //     0xb1e160: ldr             x1, [x1, #0xe78]
    // 0xb1e164: StoreField: r0->field_4b = r1
    //     0xb1e164: stur            w1, [x0, #0x4b]
    // 0xb1e168: r1 = Instance_BackButtonIcon
    //     0xb1e168: add             x1, PP, #0x40, lsl #12  ; [pp+0x402e8] Obj!BackButtonIcon@b4ee41
    //     0xb1e16c: ldr             x1, [x1, #0x2e8]
    // 0xb1e170: StoreField: r0->field_1f = r1
    //     0xb1e170: stur            w1, [x0, #0x1f]
    // 0xb1e174: LeaveFrame
    //     0xb1e174: mov             SP, fp
    //     0xb1e178: ldp             fp, lr, [SP], #0x10
    // 0xb1e17c: ret
    //     0xb1e17c: ret             
    // 0xb1e180: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e180: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e184: b               #0xb1e108
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xb1e188, size: 0x54
    // 0xb1e188: EnterFrame
    //     0xb1e188: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e18c: mov             fp, SP
    // 0xb1e190: ldr             x0, [fp, #0x10]
    // 0xb1e194: LoadField: r1 = r0->field_17
    //     0xb1e194: ldur            w1, [x0, #0x17]
    // 0xb1e198: DecompressPointer r1
    //     0xb1e198: add             x1, x1, HEAP, lsl #32
    // 0xb1e19c: CheckStackOverflow
    //     0xb1e19c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1e1a0: cmp             SP, x16
    //     0xb1e1a4: b.ls            #0xb1e1d4
    // 0xb1e1a8: LoadField: r0 = r1->field_13
    //     0xb1e1a8: ldur            w0, [x1, #0x13]
    // 0xb1e1ac: DecompressPointer r0
    //     0xb1e1ac: add             x0, x0, HEAP, lsl #32
    // 0xb1e1b0: r16 = <Object?>
    //     0xb1e1b0: ldr             x16, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0xb1e1b4: stp             x0, x16, [SP, #-0x10]!
    // 0xb1e1b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xb1e1b8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xb1e1bc: r0 = maybePop()
    //     0xb1e1bc: bl              #0xb1e1dc  ; [package:flutter/src/widgets/navigator.dart] Navigator::maybePop
    // 0xb1e1c0: add             SP, SP, #0x10
    // 0xb1e1c4: r0 = Null
    //     0xb1e1c4: mov             x0, NULL
    // 0xb1e1c8: LeaveFrame
    //     0xb1e1c8: mov             SP, fp
    //     0xb1e1cc: ldp             fp, lr, [SP], #0x10
    // 0xb1e1d0: ret
    //     0xb1e1d0: ret             
    // 0xb1e1d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e1d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e1d8: b               #0xb1e1a8
  }
}

// class id: 3864, size: 0xc, field offset: 0xc
//   const constructor, 
class BackButtonIcon extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1e060, size: 0x90
    // 0xb1e060: EnterFrame
    //     0xb1e060: stp             fp, lr, [SP, #-0x10]!
    //     0xb1e064: mov             fp, SP
    // 0xb1e068: AllocStack(0x8)
    //     0xb1e068: sub             SP, SP, #8
    // 0xb1e06c: CheckStackOverflow
    //     0xb1e06c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1e070: cmp             SP, x16
    //     0xb1e074: b.ls            #0xb1e0e8
    // 0xb1e078: ldr             x16, [fp, #0x10]
    // 0xb1e07c: SaveReg r16
    //     0xb1e07c: str             x16, [SP, #-8]!
    // 0xb1e080: r0 = of()
    //     0xb1e080: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1e084: add             SP, SP, #8
    // 0xb1e088: LoadField: r1 = r0->field_1f
    //     0xb1e088: ldur            w1, [x0, #0x1f]
    // 0xb1e08c: DecompressPointer r1
    //     0xb1e08c: add             x1, x1, HEAP, lsl #32
    // 0xb1e090: LoadField: r0 = r1->field_7
    //     0xb1e090: ldur            x0, [x1, #7]
    // 0xb1e094: cmp             x0, #2
    // 0xb1e098: b.gt            #0xb1e0a8
    // 0xb1e09c: cmp             x0, #1
    // 0xb1e0a0: b.gt            #0xb1e0b8
    // 0xb1e0a4: b               #0xb1e0c4
    // 0xb1e0a8: cmp             x0, #4
    // 0xb1e0ac: b.gt            #0xb1e0c4
    // 0xb1e0b0: cmp             x0, #3
    // 0xb1e0b4: b.le            #0xb1e0c4
    // 0xb1e0b8: r0 = Instance_IconData
    //     0xb1e0b8: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b940] Obj!IconData@b33d91
    //     0xb1e0bc: ldr             x0, [x0, #0x940]
    // 0xb1e0c0: b               #0xb1e0cc
    // 0xb1e0c4: r0 = Instance_IconData
    //     0xb1e0c4: add             x0, PP, #0x3f, lsl #12  ; [pp+0x3fe70] Obj!IconData@b33c71
    //     0xb1e0c8: ldr             x0, [x0, #0xe70]
    // 0xb1e0cc: stur            x0, [fp, #-8]
    // 0xb1e0d0: r0 = Icon()
    //     0xb1e0d0: bl              #0x825370  ; AllocateIconStub -> Icon (size=0x34)
    // 0xb1e0d4: ldur            x1, [fp, #-8]
    // 0xb1e0d8: StoreField: r0->field_b = r1
    //     0xb1e0d8: stur            w1, [x0, #0xb]
    // 0xb1e0dc: LeaveFrame
    //     0xb1e0dc: mov             SP, fp
    //     0xb1e0e0: ldp             fp, lr, [SP], #0x10
    // 0xb1e0e4: ret
    //     0xb1e0e4: ret             
    // 0xb1e0e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e0e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e0ec: b               #0xb1e078
  }
}

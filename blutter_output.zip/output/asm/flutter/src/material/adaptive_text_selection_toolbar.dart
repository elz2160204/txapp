// lib: , url: package:flutter/src/material/adaptive_text_selection_toolbar.dart

// class id: 1049176, size: 0x8
class :: {
}

// class id: 3865, size: 0x18, field offset: 0xc
//   const constructor, 
class AdaptiveTextSelectionToolbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1d720, size: 0x244
    // 0xb1d720: EnterFrame
    //     0xb1d720: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d724: mov             fp, SP
    // 0xb1d728: AllocStack(0x18)
    //     0xb1d728: sub             SP, SP, #0x18
    // 0xb1d72c: CheckStackOverflow
    //     0xb1d72c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d730: cmp             SP, x16
    //     0xb1d734: b.ls            #0xb1d95c
    // 0xb1d738: ldr             x0, [fp, #0x18]
    // 0xb1d73c: LoadField: r1 = r0->field_b
    //     0xb1d73c: ldur            w1, [x0, #0xb]
    // 0xb1d740: DecompressPointer r1
    //     0xb1d740: add             x1, x1, HEAP, lsl #32
    // 0xb1d744: LoadField: r2 = r1->field_b
    //     0xb1d744: ldur            w2, [x1, #0xb]
    // 0xb1d748: DecompressPointer r2
    //     0xb1d748: add             x2, x2, HEAP, lsl #32
    // 0xb1d74c: cbnz            w2, #0xb1d764
    // 0xb1d750: r0 = Instance_SizedBox
    //     0xb1d750: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0xb1d754: ldr             x0, [x0, #0x738]
    // 0xb1d758: LeaveFrame
    //     0xb1d758: mov             SP, fp
    //     0xb1d75c: ldp             fp, lr, [SP], #0x10
    // 0xb1d760: ret
    //     0xb1d760: ret             
    // 0xb1d764: ldr             x16, [fp, #0x10]
    // 0xb1d768: stp             x1, x16, [SP, #-0x10]!
    // 0xb1d76c: r0 = getAdaptiveButtons()
    //     0xb1d76c: bl              #0xb1d964  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons
    // 0xb1d770: add             SP, SP, #0x10
    // 0xb1d774: r1 = LoadClassIdInstr(r0)
    //     0xb1d774: ldur            x1, [x0, #-1]
    //     0xb1d778: ubfx            x1, x1, #0xc, #0x14
    // 0xb1d77c: SaveReg r0
    //     0xb1d77c: str             x0, [SP, #-8]!
    // 0xb1d780: mov             x0, x1
    // 0xb1d784: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb1d784: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb1d788: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xb1d788: mov             x17, #0xc8a1
    //     0xb1d78c: add             lr, x0, x17
    //     0xb1d790: ldr             lr, [x21, lr, lsl #3]
    //     0xb1d794: blr             lr
    // 0xb1d798: add             SP, SP, #8
    // 0xb1d79c: stur            x0, [fp, #-8]
    // 0xb1d7a0: ldr             x16, [fp, #0x10]
    // 0xb1d7a4: SaveReg r16
    //     0xb1d7a4: str             x16, [SP, #-8]!
    // 0xb1d7a8: r0 = of()
    //     0xb1d7a8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1d7ac: add             SP, SP, #8
    // 0xb1d7b0: LoadField: r1 = r0->field_1f
    //     0xb1d7b0: ldur            w1, [x0, #0x1f]
    // 0xb1d7b4: DecompressPointer r1
    //     0xb1d7b4: add             x1, x1, HEAP, lsl #32
    // 0xb1d7b8: LoadField: r0 = r1->field_7
    //     0xb1d7b8: ldur            x0, [x1, #7]
    // 0xb1d7bc: cmp             x0, #2
    // 0xb1d7c0: b.gt            #0xb1d8c8
    // 0xb1d7c4: cmp             x0, #1
    // 0xb1d7c8: b.gt            #0xb1d850
    // 0xb1d7cc: cmp             x0, #0
    // 0xb1d7d0: b.gt            #0xb1d844
    // 0xb1d7d4: ldr             x1, [fp, #0x18]
    // 0xb1d7d8: LoadField: r0 = r1->field_13
    //     0xb1d7d8: ldur            w0, [x1, #0x13]
    // 0xb1d7dc: DecompressPointer r0
    //     0xb1d7dc: add             x0, x0, HEAP, lsl #32
    // 0xb1d7e0: LoadField: r1 = r0->field_7
    //     0xb1d7e0: ldur            w1, [x0, #7]
    // 0xb1d7e4: DecompressPointer r1
    //     0xb1d7e4: add             x1, x1, HEAP, lsl #32
    // 0xb1d7e8: stur            x1, [fp, #-0x18]
    // 0xb1d7ec: LoadField: r2 = r0->field_b
    //     0xb1d7ec: ldur            w2, [x0, #0xb]
    // 0xb1d7f0: DecompressPointer r2
    //     0xb1d7f0: add             x2, x2, HEAP, lsl #32
    // 0xb1d7f4: cmp             w2, NULL
    // 0xb1d7f8: b.ne            #0xb1d800
    // 0xb1d7fc: mov             x2, x1
    // 0xb1d800: ldur            x0, [fp, #-8]
    // 0xb1d804: stur            x2, [fp, #-0x10]
    // 0xb1d808: r0 = TextSelectionToolbar()
    //     0xb1d808: bl              #0x8738d0  ; AllocateTextSelectionToolbarStub -> TextSelectionToolbar (size=0x1c)
    // 0xb1d80c: mov             x1, x0
    // 0xb1d810: ldur            x0, [fp, #-0x18]
    // 0xb1d814: StoreField: r1->field_b = r0
    //     0xb1d814: stur            w0, [x1, #0xb]
    // 0xb1d818: ldur            x0, [fp, #-0x10]
    // 0xb1d81c: StoreField: r1->field_f = r0
    //     0xb1d81c: stur            w0, [x1, #0xf]
    // 0xb1d820: r0 = Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@827142888': static.
    //     0xb1d820: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d50] Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@827142888': static. (0x7fe6e2073b3c)
    //     0xb1d824: ldr             x0, [x0, #0xd50]
    // 0xb1d828: StoreField: r1->field_17 = r0
    //     0xb1d828: stur            w0, [x1, #0x17]
    // 0xb1d82c: ldur            x0, [fp, #-8]
    // 0xb1d830: StoreField: r1->field_13 = r0
    //     0xb1d830: stur            w0, [x1, #0x13]
    // 0xb1d834: mov             x0, x1
    // 0xb1d838: LeaveFrame
    //     0xb1d838: mov             SP, fp
    //     0xb1d83c: ldp             fp, lr, [SP], #0x10
    // 0xb1d840: ret
    //     0xb1d840: ret             
    // 0xb1d844: ldr             x1, [fp, #0x18]
    // 0xb1d848: ldur            x0, [fp, #-8]
    // 0xb1d84c: b               #0xb1d928
    // 0xb1d850: ldr             x1, [fp, #0x18]
    // 0xb1d854: ldur            x0, [fp, #-8]
    // 0xb1d858: LoadField: r2 = r1->field_13
    //     0xb1d858: ldur            w2, [x1, #0x13]
    // 0xb1d85c: DecompressPointer r2
    //     0xb1d85c: add             x2, x2, HEAP, lsl #32
    // 0xb1d860: LoadField: r1 = r2->field_7
    //     0xb1d860: ldur            w1, [x2, #7]
    // 0xb1d864: DecompressPointer r1
    //     0xb1d864: add             x1, x1, HEAP, lsl #32
    // 0xb1d868: stur            x1, [fp, #-0x18]
    // 0xb1d86c: LoadField: r3 = r2->field_b
    //     0xb1d86c: ldur            w3, [x2, #0xb]
    // 0xb1d870: DecompressPointer r3
    //     0xb1d870: add             x3, x3, HEAP, lsl #32
    // 0xb1d874: cmp             w3, NULL
    // 0xb1d878: b.ne            #0xb1d884
    // 0xb1d87c: mov             x2, x1
    // 0xb1d880: b               #0xb1d888
    // 0xb1d884: mov             x2, x3
    // 0xb1d888: stur            x2, [fp, #-0x10]
    // 0xb1d88c: r0 = CupertinoTextSelectionToolbar()
    //     0xb1d88c: bl              #0x844d6c  ; AllocateCupertinoTextSelectionToolbarStub -> CupertinoTextSelectionToolbar (size=0x1c)
    // 0xb1d890: mov             x1, x0
    // 0xb1d894: ldur            x0, [fp, #-0x18]
    // 0xb1d898: StoreField: r1->field_b = r0
    //     0xb1d898: stur            w0, [x1, #0xb]
    // 0xb1d89c: ldur            x0, [fp, #-0x10]
    // 0xb1d8a0: StoreField: r1->field_f = r0
    //     0xb1d8a0: stur            w0, [x1, #0xf]
    // 0xb1d8a4: ldur            x2, [fp, #-8]
    // 0xb1d8a8: StoreField: r1->field_13 = r2
    //     0xb1d8a8: stur            w2, [x1, #0x13]
    // 0xb1d8ac: r0 = Closure: (BuildContext, Offset, bool, Widget) => Widget from Function '_defaultToolbarBuilder@621408280': static.
    //     0xb1d8ac: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d58] Closure: (BuildContext, Offset, bool, Widget) => Widget from Function '_defaultToolbarBuilder@621408280': static. (0x7fe6e2044eac)
    //     0xb1d8b0: ldr             x0, [x0, #0xd58]
    // 0xb1d8b4: StoreField: r1->field_17 = r0
    //     0xb1d8b4: stur            w0, [x1, #0x17]
    // 0xb1d8b8: mov             x0, x1
    // 0xb1d8bc: LeaveFrame
    //     0xb1d8bc: mov             SP, fp
    //     0xb1d8c0: ldp             fp, lr, [SP], #0x10
    // 0xb1d8c4: ret
    //     0xb1d8c4: ret             
    // 0xb1d8c8: ldr             x1, [fp, #0x18]
    // 0xb1d8cc: ldur            x2, [fp, #-8]
    // 0xb1d8d0: cmp             x0, #4
    // 0xb1d8d4: b.gt            #0xb1d924
    // 0xb1d8d8: cmp             x0, #3
    // 0xb1d8dc: b.gt            #0xb1d8e8
    // 0xb1d8e0: mov             x0, x2
    // 0xb1d8e4: b               #0xb1d928
    // 0xb1d8e8: LoadField: r0 = r1->field_13
    //     0xb1d8e8: ldur            w0, [x1, #0x13]
    // 0xb1d8ec: DecompressPointer r0
    //     0xb1d8ec: add             x0, x0, HEAP, lsl #32
    // 0xb1d8f0: LoadField: r1 = r0->field_7
    //     0xb1d8f0: ldur            w1, [x0, #7]
    // 0xb1d8f4: DecompressPointer r1
    //     0xb1d8f4: add             x1, x1, HEAP, lsl #32
    // 0xb1d8f8: stur            x1, [fp, #-0x10]
    // 0xb1d8fc: r0 = CupertinoDesktopTextSelectionToolbar()
    //     0xb1d8fc: bl              #0x840b2c  ; AllocateCupertinoDesktopTextSelectionToolbarStub -> CupertinoDesktopTextSelectionToolbar (size=0x14)
    // 0xb1d900: mov             x1, x0
    // 0xb1d904: ldur            x0, [fp, #-0x10]
    // 0xb1d908: StoreField: r1->field_b = r0
    //     0xb1d908: stur            w0, [x1, #0xb]
    // 0xb1d90c: ldur            x0, [fp, #-8]
    // 0xb1d910: StoreField: r1->field_f = r0
    //     0xb1d910: stur            w0, [x1, #0xf]
    // 0xb1d914: mov             x0, x1
    // 0xb1d918: LeaveFrame
    //     0xb1d918: mov             SP, fp
    //     0xb1d91c: ldp             fp, lr, [SP], #0x10
    // 0xb1d920: ret
    //     0xb1d920: ret             
    // 0xb1d924: mov             x0, x2
    // 0xb1d928: LoadField: r2 = r1->field_13
    //     0xb1d928: ldur            w2, [x1, #0x13]
    // 0xb1d92c: DecompressPointer r2
    //     0xb1d92c: add             x2, x2, HEAP, lsl #32
    // 0xb1d930: LoadField: r1 = r2->field_7
    //     0xb1d930: ldur            w1, [x2, #7]
    // 0xb1d934: DecompressPointer r1
    //     0xb1d934: add             x1, x1, HEAP, lsl #32
    // 0xb1d938: stur            x1, [fp, #-0x10]
    // 0xb1d93c: r0 = DesktopTextSelectionToolbar()
    //     0xb1d93c: bl              #0x85259c  ; AllocateDesktopTextSelectionToolbarStub -> DesktopTextSelectionToolbar (size=0x14)
    // 0xb1d940: ldur            x1, [fp, #-0x10]
    // 0xb1d944: StoreField: r0->field_b = r1
    //     0xb1d944: stur            w1, [x0, #0xb]
    // 0xb1d948: ldur            x1, [fp, #-8]
    // 0xb1d94c: StoreField: r0->field_f = r1
    //     0xb1d94c: stur            w1, [x0, #0xf]
    // 0xb1d950: LeaveFrame
    //     0xb1d950: mov             SP, fp
    //     0xb1d954: ldp             fp, lr, [SP], #0x10
    // 0xb1d958: ret
    //     0xb1d958: ret             
    // 0xb1d95c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d95c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d960: b               #0xb1d738
  }
  static _ getAdaptiveButtons(/* No info */) {
    // ** addr: 0xb1d964, size: 0x37c
    // 0xb1d964: EnterFrame
    //     0xb1d964: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d968: mov             fp, SP
    // 0xb1d96c: AllocStack(0x50)
    //     0xb1d96c: sub             SP, SP, #0x50
    // 0xb1d970: CheckStackOverflow
    //     0xb1d970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d974: cmp             SP, x16
    //     0xb1d978: b.ls            #0xb1dcc8
    // 0xb1d97c: r1 = 1
    //     0xb1d97c: mov             x1, #1
    // 0xb1d980: r0 = AllocateContext()
    //     0xb1d980: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb1d984: mov             x1, x0
    // 0xb1d988: ldr             x0, [fp, #0x18]
    // 0xb1d98c: stur            x1, [fp, #-8]
    // 0xb1d990: StoreField: r1->field_f = r0
    //     0xb1d990: stur            w0, [x1, #0xf]
    // 0xb1d994: SaveReg r0
    //     0xb1d994: str             x0, [SP, #-8]!
    // 0xb1d998: r0 = of()
    //     0xb1d998: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1d99c: add             SP, SP, #8
    // 0xb1d9a0: LoadField: r1 = r0->field_1f
    //     0xb1d9a0: ldur            w1, [x0, #0x1f]
    // 0xb1d9a4: DecompressPointer r1
    //     0xb1d9a4: add             x1, x1, HEAP, lsl #32
    // 0xb1d9a8: LoadField: r0 = r1->field_7
    //     0xb1d9a8: ldur            x0, [x1, #7]
    // 0xb1d9ac: cmp             x0, #2
    // 0xb1d9b0: b.gt            #0xb1dc40
    // 0xb1d9b4: cmp             x0, #1
    // 0xb1d9b8: b.gt            #0xb1dc04
    // 0xb1d9bc: r16 = <Widget>
    //     0xb1d9bc: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1d9c0: ldr             x16, [x16, #0xea8]
    // 0xb1d9c4: stp             xzr, x16, [SP, #-0x10]!
    // 0xb1d9c8: r0 = _GrowableList()
    //     0xb1d9c8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xb1d9cc: add             SP, SP, #0x10
    // 0xb1d9d0: mov             x2, x0
    // 0xb1d9d4: stur            x2, [fp, #-0x20]
    // 0xb1d9d8: r5 = 0
    //     0xb1d9d8: mov             x5, #0
    // 0xb1d9dc: ldr             x4, [fp, #0x10]
    // 0xb1d9e0: ldur            x3, [fp, #-8]
    // 0xb1d9e4: stur            x5, [fp, #-0x18]
    // 0xb1d9e8: CheckStackOverflow
    //     0xb1d9e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d9ec: cmp             SP, x16
    //     0xb1d9f0: b.ls            #0xb1dcd0
    // 0xb1d9f4: LoadField: r6 = r4->field_b
    //     0xb1d9f4: ldur            w6, [x4, #0xb]
    // 0xb1d9f8: DecompressPointer r6
    //     0xb1d9f8: add             x6, x6, HEAP, lsl #32
    // 0xb1d9fc: r7 = LoadInt32Instr(r6)
    //     0xb1d9fc: sbfx            x7, x6, #1, #0x1f
    // 0xb1da00: cmp             x5, x7
    // 0xb1da04: b.ge            #0xb1dbf4
    // 0xb1da08: mov             x0, x7
    // 0xb1da0c: mov             x1, x5
    // 0xb1da10: cmp             x1, x0
    // 0xb1da14: b.hs            #0xb1dcd8
    // 0xb1da18: LoadField: r0 = r4->field_f
    //     0xb1da18: ldur            w0, [x4, #0xf]
    // 0xb1da1c: DecompressPointer r0
    //     0xb1da1c: add             x0, x0, HEAP, lsl #32
    // 0xb1da20: ArrayLoad: r1 = r0[r5]  ; Unknown_4
    //     0xb1da20: add             x16, x0, x5, lsl #2
    //     0xb1da24: ldur            w1, [x16, #0xf]
    // 0xb1da28: DecompressPointer r1
    //     0xb1da28: add             x1, x1, HEAP, lsl #32
    // 0xb1da2c: stur            x1, [fp, #-0x10]
    // 0xb1da30: cbnz            x5, #0xb1da54
    // 0xb1da34: cmp             w6, #2
    // 0xb1da38: b.ne            #0xb1da48
    // 0xb1da3c: r0 = Instance__TextSelectionToolbarItemPosition
    //     0xb1da3c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d68] Obj!_TextSelectionToolbarItemPosition@b65151
    //     0xb1da40: ldr             x0, [x0, #0xd68]
    // 0xb1da44: b               #0xb1da74
    // 0xb1da48: r0 = Instance__TextSelectionToolbarItemPosition
    //     0xb1da48: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d70] Obj!_TextSelectionToolbarItemPosition@b65131
    //     0xb1da4c: ldr             x0, [x0, #0xd70]
    // 0xb1da50: b               #0xb1da74
    // 0xb1da54: sub             x0, x7, #1
    // 0xb1da58: cmp             x5, x0
    // 0xb1da5c: b.ne            #0xb1da6c
    // 0xb1da60: r0 = Instance__TextSelectionToolbarItemPosition
    //     0xb1da60: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d78] Obj!_TextSelectionToolbarItemPosition@b65111
    //     0xb1da64: ldr             x0, [x0, #0xd78]
    // 0xb1da68: b               #0xb1da74
    // 0xb1da6c: r0 = Instance__TextSelectionToolbarItemPosition
    //     0xb1da6c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d80] Obj!_TextSelectionToolbarItemPosition@b650f1
    //     0xb1da70: ldr             x0, [x0, #0xd80]
    // 0xb1da74: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xb1da74: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d70] Obj!_TextSelectionToolbarItemPosition@b65131
    //     0xb1da78: ldr             x16, [x16, #0xd70]
    // 0xb1da7c: cmp             w0, w16
    // 0xb1da80: b.eq            #0xb1da94
    // 0xb1da84: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xb1da84: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d68] Obj!_TextSelectionToolbarItemPosition@b65151
    //     0xb1da88: ldr             x16, [x16, #0xd68]
    // 0xb1da8c: cmp             w0, w16
    // 0xb1da90: b.ne            #0xb1da9c
    // 0xb1da94: d0 = 14.500000
    //     0xb1da94: fmov            d0, #14.50000000
    // 0xb1da98: b               #0xb1daa0
    // 0xb1da9c: d0 = 9.500000
    //     0xb1da9c: fmov            d0, #9.50000000
    // 0xb1daa0: stur            d0, [fp, #-0x50]
    // 0xb1daa4: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xb1daa4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d78] Obj!_TextSelectionToolbarItemPosition@b65111
    //     0xb1daa8: ldr             x16, [x16, #0xd78]
    // 0xb1daac: cmp             w0, w16
    // 0xb1dab0: b.eq            #0xb1dac4
    // 0xb1dab4: r16 = Instance__TextSelectionToolbarItemPosition
    //     0xb1dab4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28d68] Obj!_TextSelectionToolbarItemPosition@b65151
    //     0xb1dab8: ldr             x16, [x16, #0xd68]
    // 0xb1dabc: cmp             w0, w16
    // 0xb1dac0: b.ne            #0xb1dacc
    // 0xb1dac4: d1 = 14.500000
    //     0xb1dac4: fmov            d1, #14.50000000
    // 0xb1dac8: b               #0xb1dad0
    // 0xb1dacc: d1 = 9.500000
    //     0xb1dacc: fmov            d1, #9.50000000
    // 0xb1dad0: stur            d1, [fp, #-0x48]
    // 0xb1dad4: r0 = EdgeInsets()
    //     0xb1dad4: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1dad8: ldur            d0, [fp, #-0x50]
    // 0xb1dadc: stur            x0, [fp, #-0x30]
    // 0xb1dae0: StoreField: r0->field_7 = d0
    //     0xb1dae0: stur            d0, [x0, #7]
    // 0xb1dae4: d0 = 0.000000
    //     0xb1dae4: eor             v0.16b, v0.16b, v0.16b
    // 0xb1dae8: StoreField: r0->field_f = d0
    //     0xb1dae8: stur            d0, [x0, #0xf]
    // 0xb1daec: ldur            d1, [fp, #-0x48]
    // 0xb1daf0: StoreField: r0->field_17 = d1
    //     0xb1daf0: stur            d1, [x0, #0x17]
    // 0xb1daf4: StoreField: r0->field_1f = d0
    //     0xb1daf4: stur            d0, [x0, #0x1f]
    // 0xb1daf8: ldur            x1, [fp, #-0x10]
    // 0xb1dafc: LoadField: r2 = r1->field_7
    //     0xb1dafc: ldur            w2, [x1, #7]
    // 0xb1db00: DecompressPointer r2
    //     0xb1db00: add             x2, x2, HEAP, lsl #32
    // 0xb1db04: ldur            x3, [fp, #-8]
    // 0xb1db08: stur            x2, [fp, #-0x28]
    // 0xb1db0c: LoadField: r4 = r3->field_f
    //     0xb1db0c: ldur            w4, [x3, #0xf]
    // 0xb1db10: DecompressPointer r4
    //     0xb1db10: add             x4, x4, HEAP, lsl #32
    // 0xb1db14: stp             x1, x4, [SP, #-0x10]!
    // 0xb1db18: r0 = getButtonLabel()
    //     0xb1db18: bl              #0xb1dce0  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xb1db1c: add             SP, SP, #0x10
    // 0xb1db20: stur            x0, [fp, #-0x10]
    // 0xb1db24: r0 = Text()
    //     0xb1db24: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0xb1db28: mov             x1, x0
    // 0xb1db2c: ldur            x0, [fp, #-0x10]
    // 0xb1db30: stur            x1, [fp, #-0x38]
    // 0xb1db34: StoreField: r1->field_b = r0
    //     0xb1db34: stur            w0, [x1, #0xb]
    // 0xb1db38: r0 = TextSelectionToolbarTextButton()
    //     0xb1db38: bl              #0x873a38  ; AllocateTextSelectionToolbarTextButtonStub -> TextSelectionToolbarTextButton (size=0x18)
    // 0xb1db3c: mov             x1, x0
    // 0xb1db40: ldur            x0, [fp, #-0x38]
    // 0xb1db44: stur            x1, [fp, #-0x40]
    // 0xb1db48: StoreField: r1->field_b = r0
    //     0xb1db48: stur            w0, [x1, #0xb]
    // 0xb1db4c: ldur            x0, [fp, #-0x30]
    // 0xb1db50: StoreField: r1->field_13 = r0
    //     0xb1db50: stur            w0, [x1, #0x13]
    // 0xb1db54: ldur            x0, [fp, #-0x28]
    // 0xb1db58: StoreField: r1->field_f = r0
    //     0xb1db58: stur            w0, [x1, #0xf]
    // 0xb1db5c: ldur            x0, [fp, #-0x20]
    // 0xb1db60: LoadField: r2 = r0->field_b
    //     0xb1db60: ldur            w2, [x0, #0xb]
    // 0xb1db64: DecompressPointer r2
    //     0xb1db64: add             x2, x2, HEAP, lsl #32
    // 0xb1db68: stur            x2, [fp, #-0x10]
    // 0xb1db6c: LoadField: r3 = r0->field_f
    //     0xb1db6c: ldur            w3, [x0, #0xf]
    // 0xb1db70: DecompressPointer r3
    //     0xb1db70: add             x3, x3, HEAP, lsl #32
    // 0xb1db74: LoadField: r4 = r3->field_b
    //     0xb1db74: ldur            w4, [x3, #0xb]
    // 0xb1db78: DecompressPointer r4
    //     0xb1db78: add             x4, x4, HEAP, lsl #32
    // 0xb1db7c: cmp             w2, w4
    // 0xb1db80: b.ne            #0xb1db90
    // 0xb1db84: SaveReg r0
    //     0xb1db84: str             x0, [SP, #-8]!
    // 0xb1db88: r0 = _growToNextCapacity()
    //     0xb1db88: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb1db8c: add             SP, SP, #8
    // 0xb1db90: ldur            x2, [fp, #-0x20]
    // 0xb1db94: ldur            x3, [fp, #-0x18]
    // 0xb1db98: ldur            x0, [fp, #-0x10]
    // 0xb1db9c: r4 = LoadInt32Instr(r0)
    //     0xb1db9c: sbfx            x4, x0, #1, #0x1f
    // 0xb1dba0: add             x0, x4, #1
    // 0xb1dba4: lsl             x1, x0, #1
    // 0xb1dba8: StoreField: r2->field_b = r1
    //     0xb1dba8: stur            w1, [x2, #0xb]
    // 0xb1dbac: mov             x1, x4
    // 0xb1dbb0: cmp             x1, x0
    // 0xb1dbb4: b.hs            #0xb1dcdc
    // 0xb1dbb8: LoadField: r1 = r2->field_f
    //     0xb1dbb8: ldur            w1, [x2, #0xf]
    // 0xb1dbbc: DecompressPointer r1
    //     0xb1dbbc: add             x1, x1, HEAP, lsl #32
    // 0xb1dbc0: ldur            x0, [fp, #-0x40]
    // 0xb1dbc4: ArrayStore: r1[r4] = r0  ; List_4
    //     0xb1dbc4: add             x25, x1, x4, lsl #2
    //     0xb1dbc8: add             x25, x25, #0xf
    //     0xb1dbcc: str             w0, [x25]
    //     0xb1dbd0: tbz             w0, #0, #0xb1dbec
    //     0xb1dbd4: ldurb           w16, [x1, #-1]
    //     0xb1dbd8: ldurb           w17, [x0, #-1]
    //     0xb1dbdc: and             x16, x17, x16, lsr #2
    //     0xb1dbe0: tst             x16, HEAP, lsr #32
    //     0xb1dbe4: b.eq            #0xb1dbec
    //     0xb1dbe8: bl              #0xd67e5c
    // 0xb1dbec: add             x5, x3, #1
    // 0xb1dbf0: b               #0xb1d9dc
    // 0xb1dbf4: mov             x0, x2
    // 0xb1dbf8: LeaveFrame
    //     0xb1dbf8: mov             SP, fp
    //     0xb1dbfc: ldp             fp, lr, [SP], #0x10
    // 0xb1dc00: ret
    //     0xb1dc00: ret             
    // 0xb1dc04: ldur            x2, [fp, #-8]
    // 0xb1dc08: r1 = Function '<anonymous closure>': static.
    //     0xb1dc08: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d88] AnonymousClosure: static (0xb1dfd4), in [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons (0xb1d964)
    //     0xb1dc0c: ldr             x1, [x1, #0xd88]
    // 0xb1dc10: r0 = AllocateClosure()
    //     0xb1dc10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1dc14: r16 = <Widget>
    //     0xb1dc14: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1dc18: ldr             x16, [x16, #0xea8]
    // 0xb1dc1c: ldr             lr, [fp, #0x10]
    // 0xb1dc20: stp             lr, x16, [SP, #-0x10]!
    // 0xb1dc24: SaveReg r0
    //     0xb1dc24: str             x0, [SP, #-8]!
    // 0xb1dc28: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb1dc28: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb1dc2c: r0 = map()
    //     0xb1dc2c: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xb1dc30: add             SP, SP, #0x18
    // 0xb1dc34: LeaveFrame
    //     0xb1dc34: mov             SP, fp
    //     0xb1dc38: ldp             fp, lr, [SP], #0x10
    // 0xb1dc3c: ret
    //     0xb1dc3c: ret             
    // 0xb1dc40: cmp             x0, #4
    // 0xb1dc44: b.gt            #0xb1dc8c
    // 0xb1dc48: cmp             x0, #3
    // 0xb1dc4c: b.le            #0xb1dc8c
    // 0xb1dc50: ldur            x2, [fp, #-8]
    // 0xb1dc54: r1 = Function '<anonymous closure>': static.
    //     0xb1dc54: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d90] AnonymousClosure: static (0xb1df48), in [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons (0xb1d964)
    //     0xb1dc58: ldr             x1, [x1, #0xd90]
    // 0xb1dc5c: r0 = AllocateClosure()
    //     0xb1dc5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1dc60: r16 = <Widget>
    //     0xb1dc60: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1dc64: ldr             x16, [x16, #0xea8]
    // 0xb1dc68: ldr             lr, [fp, #0x10]
    // 0xb1dc6c: stp             lr, x16, [SP, #-0x10]!
    // 0xb1dc70: SaveReg r0
    //     0xb1dc70: str             x0, [SP, #-8]!
    // 0xb1dc74: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb1dc74: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb1dc78: r0 = map()
    //     0xb1dc78: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xb1dc7c: add             SP, SP, #0x18
    // 0xb1dc80: LeaveFrame
    //     0xb1dc80: mov             SP, fp
    //     0xb1dc84: ldp             fp, lr, [SP], #0x10
    // 0xb1dc88: ret
    //     0xb1dc88: ret             
    // 0xb1dc8c: ldur            x2, [fp, #-8]
    // 0xb1dc90: r1 = Function '<anonymous closure>': static.
    //     0xb1dc90: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d98] AnonymousClosure: static (0xb1debc), in [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getAdaptiveButtons (0xb1d964)
    //     0xb1dc94: ldr             x1, [x1, #0xd98]
    // 0xb1dc98: r0 = AllocateClosure()
    //     0xb1dc98: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb1dc9c: r16 = <Widget>
    //     0xb1dc9c: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1dca0: ldr             x16, [x16, #0xea8]
    // 0xb1dca4: ldr             lr, [fp, #0x10]
    // 0xb1dca8: stp             lr, x16, [SP, #-0x10]!
    // 0xb1dcac: SaveReg r0
    //     0xb1dcac: str             x0, [SP, #-8]!
    // 0xb1dcb0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb1dcb0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb1dcb4: r0 = map()
    //     0xb1dcb4: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xb1dcb8: add             SP, SP, #0x18
    // 0xb1dcbc: LeaveFrame
    //     0xb1dcbc: mov             SP, fp
    //     0xb1dcc0: ldp             fp, lr, [SP], #0x10
    // 0xb1dcc4: ret
    //     0xb1dcc4: ret             
    // 0xb1dcc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1dcc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1dccc: b               #0xb1d97c
    // 0xb1dcd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1dcd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1dcd4: b               #0xb1d9f4
    // 0xb1dcd8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1dcd8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb1dcdc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1dcdc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  static _ getButtonLabel(/* No info */) {
    // ** addr: 0xb1dce0, size: 0x120
    // 0xb1dce0: EnterFrame
    //     0xb1dce0: stp             fp, lr, [SP, #-0x10]!
    //     0xb1dce4: mov             fp, SP
    // 0xb1dce8: CheckStackOverflow
    //     0xb1dce8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1dcec: cmp             SP, x16
    //     0xb1dcf0: b.ls            #0xb1ddf8
    // 0xb1dcf4: ldr             x16, [fp, #0x18]
    // 0xb1dcf8: SaveReg r16
    //     0xb1dcf8: str             x16, [SP, #-8]!
    // 0xb1dcfc: r0 = of()
    //     0xb1dcfc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xb1dd00: add             SP, SP, #8
    // 0xb1dd04: LoadField: r1 = r0->field_1f
    //     0xb1dd04: ldur            w1, [x0, #0x1f]
    // 0xb1dd08: DecompressPointer r1
    //     0xb1dd08: add             x1, x1, HEAP, lsl #32
    // 0xb1dd0c: LoadField: r0 = r1->field_7
    //     0xb1dd0c: ldur            x0, [x1, #7]
    // 0xb1dd10: cmp             x0, #2
    // 0xb1dd14: b.gt            #0xb1dd24
    // 0xb1dd18: cmp             x0, #1
    // 0xb1dd1c: b.gt            #0xb1dd34
    // 0xb1dd20: b               #0xb1dd54
    // 0xb1dd24: cmp             x0, #4
    // 0xb1dd28: b.gt            #0xb1dd54
    // 0xb1dd2c: cmp             x0, #3
    // 0xb1dd30: b.le            #0xb1dd54
    // 0xb1dd34: ldr             x16, [fp, #0x18]
    // 0xb1dd38: ldr             lr, [fp, #0x10]
    // 0xb1dd3c: stp             lr, x16, [SP, #-0x10]!
    // 0xb1dd40: r0 = getButtonLabel()
    //     0xb1dd40: bl              #0xb1de00  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::getButtonLabel
    // 0xb1dd44: add             SP, SP, #0x10
    // 0xb1dd48: LeaveFrame
    //     0xb1dd48: mov             SP, fp
    //     0xb1dd4c: ldp             fp, lr, [SP], #0x10
    // 0xb1dd50: ret
    //     0xb1dd50: ret             
    // 0xb1dd54: ldr             x0, [fp, #0x10]
    // 0xb1dd58: ldr             x16, [fp, #0x18]
    // 0xb1dd5c: SaveReg r16
    //     0xb1dd5c: str             x16, [SP, #-8]!
    // 0xb1dd60: r0 = of()
    //     0xb1dd60: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0xb1dd64: add             SP, SP, #8
    // 0xb1dd68: ldr             x1, [fp, #0x10]
    // 0xb1dd6c: LoadField: r2 = r1->field_b
    //     0xb1dd6c: ldur            w2, [x1, #0xb]
    // 0xb1dd70: DecompressPointer r2
    //     0xb1dd70: add             x2, x2, HEAP, lsl #32
    // 0xb1dd74: LoadField: r1 = r2->field_7
    //     0xb1dd74: ldur            x1, [x2, #7]
    // 0xb1dd78: cmp             x1, #2
    // 0xb1dd7c: b.gt            #0xb1ddcc
    // 0xb1dd80: cmp             x1, #1
    // 0xb1dd84: b.gt            #0xb1ddb8
    // 0xb1dd88: cmp             x1, #0
    // 0xb1dd8c: b.gt            #0xb1dda4
    // 0xb1dd90: r0 = "Cut"
    //     0xb1dd90: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Cut"
    //     0xb1dd94: ldr             x0, [x0, #0xdd0]
    // 0xb1dd98: LeaveFrame
    //     0xb1dd98: mov             SP, fp
    //     0xb1dd9c: ldp             fp, lr, [SP], #0x10
    // 0xb1dda0: ret
    //     0xb1dda0: ret             
    // 0xb1dda4: r0 = "Copy"
    //     0xb1dda4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Copy"
    //     0xb1dda8: ldr             x0, [x0, #0xdd8]
    // 0xb1ddac: LeaveFrame
    //     0xb1ddac: mov             SP, fp
    //     0xb1ddb0: ldp             fp, lr, [SP], #0x10
    // 0xb1ddb4: ret
    //     0xb1ddb4: ret             
    // 0xb1ddb8: r0 = "Paste"
    //     0xb1ddb8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28de0] "Paste"
    //     0xb1ddbc: ldr             x0, [x0, #0xde0]
    // 0xb1ddc0: LeaveFrame
    //     0xb1ddc0: mov             SP, fp
    //     0xb1ddc4: ldp             fp, lr, [SP], #0x10
    // 0xb1ddc8: ret
    //     0xb1ddc8: ret             
    // 0xb1ddcc: cmp             x1, #3
    // 0xb1ddd0: b.gt            #0xb1dde8
    // 0xb1ddd4: r0 = "Select all"
    //     0xb1ddd4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28de8] "Select all"
    //     0xb1ddd8: ldr             x0, [x0, #0xde8]
    // 0xb1dddc: LeaveFrame
    //     0xb1dddc: mov             SP, fp
    //     0xb1dde0: ldp             fp, lr, [SP], #0x10
    // 0xb1dde4: ret
    //     0xb1dde4: ret             
    // 0xb1dde8: r0 = ""
    //     0xb1dde8: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xb1ddec: LeaveFrame
    //     0xb1ddec: mov             SP, fp
    //     0xb1ddf0: ldp             fp, lr, [SP], #0x10
    // 0xb1ddf4: ret
    //     0xb1ddf4: ret             
    // 0xb1ddf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1ddf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1ddfc: b               #0xb1dcf4
  }
  [closure] static DesktopTextSelectionToolbarButton <anonymous closure>(dynamic, ContextMenuButtonItem) {
    // ** addr: 0xb1debc, size: 0x8c
    // 0xb1debc: EnterFrame
    //     0xb1debc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1dec0: mov             fp, SP
    // 0xb1dec4: AllocStack(0x20)
    //     0xb1dec4: sub             SP, SP, #0x20
    // 0xb1dec8: SetupParameters()
    //     0xb1dec8: ldr             x0, [fp, #0x18]
    //     0xb1decc: ldur            w1, [x0, #0x17]
    //     0xb1ded0: add             x1, x1, HEAP, lsl #32
    // 0xb1ded4: CheckStackOverflow
    //     0xb1ded4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1ded8: cmp             SP, x16
    //     0xb1dedc: b.ls            #0xb1df40
    // 0xb1dee0: LoadField: r0 = r1->field_f
    //     0xb1dee0: ldur            w0, [x1, #0xf]
    // 0xb1dee4: DecompressPointer r0
    //     0xb1dee4: add             x0, x0, HEAP, lsl #32
    // 0xb1dee8: ldr             x1, [fp, #0x10]
    // 0xb1deec: stur            x0, [fp, #-0x10]
    // 0xb1def0: LoadField: r2 = r1->field_7
    //     0xb1def0: ldur            w2, [x1, #7]
    // 0xb1def4: DecompressPointer r2
    //     0xb1def4: add             x2, x2, HEAP, lsl #32
    // 0xb1def8: stur            x2, [fp, #-8]
    // 0xb1defc: stp             x1, x0, [SP, #-0x10]!
    // 0xb1df00: r0 = getButtonLabel()
    //     0xb1df00: bl              #0xb1dce0  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xb1df04: add             SP, SP, #0x10
    // 0xb1df08: stur            x0, [fp, #-0x18]
    // 0xb1df0c: r0 = DesktopTextSelectionToolbarButton()
    //     0xb1df0c: bl              #0x8526a4  ; AllocateDesktopTextSelectionToolbarButtonStub -> DesktopTextSelectionToolbarButton (size=0x14)
    // 0xb1df10: stur            x0, [fp, #-0x20]
    // 0xb1df14: ldur            x16, [fp, #-0x10]
    // 0xb1df18: stp             x16, x0, [SP, #-0x10]!
    // 0xb1df1c: ldur            x16, [fp, #-8]
    // 0xb1df20: ldur            lr, [fp, #-0x18]
    // 0xb1df24: stp             lr, x16, [SP, #-0x10]!
    // 0xb1df28: r0 = DesktopTextSelectionToolbarButton.text()
    //     0xb1df28: bl              #0x8525a8  ; [package:flutter/src/material/desktop_text_selection_toolbar_button.dart] DesktopTextSelectionToolbarButton::DesktopTextSelectionToolbarButton.text
    // 0xb1df2c: add             SP, SP, #0x20
    // 0xb1df30: ldur            x0, [fp, #-0x20]
    // 0xb1df34: LeaveFrame
    //     0xb1df34: mov             SP, fp
    //     0xb1df38: ldp             fp, lr, [SP], #0x10
    // 0xb1df3c: ret
    //     0xb1df3c: ret             
    // 0xb1df40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1df40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1df44: b               #0xb1dee0
  }
  [closure] static CupertinoDesktopTextSelectionToolbarButton <anonymous closure>(dynamic, ContextMenuButtonItem) {
    // ** addr: 0xb1df48, size: 0x8c
    // 0xb1df48: EnterFrame
    //     0xb1df48: stp             fp, lr, [SP, #-0x10]!
    //     0xb1df4c: mov             fp, SP
    // 0xb1df50: AllocStack(0x20)
    //     0xb1df50: sub             SP, SP, #0x20
    // 0xb1df54: SetupParameters()
    //     0xb1df54: ldr             x0, [fp, #0x18]
    //     0xb1df58: ldur            w1, [x0, #0x17]
    //     0xb1df5c: add             x1, x1, HEAP, lsl #32
    // 0xb1df60: CheckStackOverflow
    //     0xb1df60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1df64: cmp             SP, x16
    //     0xb1df68: b.ls            #0xb1dfcc
    // 0xb1df6c: LoadField: r0 = r1->field_f
    //     0xb1df6c: ldur            w0, [x1, #0xf]
    // 0xb1df70: DecompressPointer r0
    //     0xb1df70: add             x0, x0, HEAP, lsl #32
    // 0xb1df74: ldr             x1, [fp, #0x10]
    // 0xb1df78: stur            x0, [fp, #-0x10]
    // 0xb1df7c: LoadField: r2 = r1->field_7
    //     0xb1df7c: ldur            w2, [x1, #7]
    // 0xb1df80: DecompressPointer r2
    //     0xb1df80: add             x2, x2, HEAP, lsl #32
    // 0xb1df84: stur            x2, [fp, #-8]
    // 0xb1df88: stp             x1, x0, [SP, #-0x10]!
    // 0xb1df8c: r0 = getButtonLabel()
    //     0xb1df8c: bl              #0xb1dce0  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xb1df90: add             SP, SP, #0x10
    // 0xb1df94: stur            x0, [fp, #-0x18]
    // 0xb1df98: r0 = CupertinoDesktopTextSelectionToolbarButton()
    //     0xb1df98: bl              #0x840c28  ; AllocateCupertinoDesktopTextSelectionToolbarButtonStub -> CupertinoDesktopTextSelectionToolbarButton (size=0x18)
    // 0xb1df9c: stur            x0, [fp, #-0x20]
    // 0xb1dfa0: ldur            x16, [fp, #-0x10]
    // 0xb1dfa4: stp             x16, x0, [SP, #-0x10]!
    // 0xb1dfa8: ldur            x16, [fp, #-8]
    // 0xb1dfac: ldur            lr, [fp, #-0x18]
    // 0xb1dfb0: stp             lr, x16, [SP, #-0x10]!
    // 0xb1dfb4: r0 = CupertinoDesktopTextSelectionToolbarButton.text()
    //     0xb1dfb4: bl              #0x840b38  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] CupertinoDesktopTextSelectionToolbarButton::CupertinoDesktopTextSelectionToolbarButton.text
    // 0xb1dfb8: add             SP, SP, #0x20
    // 0xb1dfbc: ldur            x0, [fp, #-0x20]
    // 0xb1dfc0: LeaveFrame
    //     0xb1dfc0: mov             SP, fp
    //     0xb1dfc4: ldp             fp, lr, [SP], #0x10
    // 0xb1dfc8: ret
    //     0xb1dfc8: ret             
    // 0xb1dfcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1dfcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1dfd0: b               #0xb1df6c
  }
  [closure] static CupertinoTextSelectionToolbarButton <anonymous closure>(dynamic, ContextMenuButtonItem) {
    // ** addr: 0xb1dfd4, size: 0x8c
    // 0xb1dfd4: EnterFrame
    //     0xb1dfd4: stp             fp, lr, [SP, #-0x10]!
    //     0xb1dfd8: mov             fp, SP
    // 0xb1dfdc: AllocStack(0x18)
    //     0xb1dfdc: sub             SP, SP, #0x18
    // 0xb1dfe0: SetupParameters()
    //     0xb1dfe0: ldr             x0, [fp, #0x18]
    //     0xb1dfe4: ldur            w1, [x0, #0x17]
    //     0xb1dfe8: add             x1, x1, HEAP, lsl #32
    // 0xb1dfec: CheckStackOverflow
    //     0xb1dfec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1dff0: cmp             SP, x16
    //     0xb1dff4: b.ls            #0xb1e058
    // 0xb1dff8: ldr             x0, [fp, #0x10]
    // 0xb1dffc: LoadField: r2 = r0->field_7
    //     0xb1dffc: ldur            w2, [x0, #7]
    // 0xb1e000: DecompressPointer r2
    //     0xb1e000: add             x2, x2, HEAP, lsl #32
    // 0xb1e004: stur            x2, [fp, #-8]
    // 0xb1e008: LoadField: r3 = r1->field_f
    //     0xb1e008: ldur            w3, [x1, #0xf]
    // 0xb1e00c: DecompressPointer r3
    //     0xb1e00c: add             x3, x3, HEAP, lsl #32
    // 0xb1e010: stp             x0, x3, [SP, #-0x10]!
    // 0xb1e014: r0 = getButtonLabel()
    //     0xb1e014: bl              #0xb1dce0  ; [package:flutter/src/material/adaptive_text_selection_toolbar.dart] AdaptiveTextSelectionToolbar::getButtonLabel
    // 0xb1e018: add             SP, SP, #0x10
    // 0xb1e01c: stur            x0, [fp, #-0x10]
    // 0xb1e020: r0 = CupertinoTextSelectionToolbarButton()
    //     0xb1e020: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0xb1e024: stur            x0, [fp, #-0x18]
    // 0xb1e028: ldur            x16, [fp, #-0x10]
    // 0xb1e02c: stp             x16, x0, [SP, #-0x10]!
    // 0xb1e030: ldur            x16, [fp, #-8]
    // 0xb1e034: SaveReg r16
    //     0xb1e034: str             x16, [SP, #-8]!
    // 0xb1e038: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0xb1e038: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0xb1e03c: ldr             x4, [x4, #0xdb8]
    // 0xb1e040: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0xb1e040: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0xb1e044: add             SP, SP, #0x18
    // 0xb1e048: ldur            x0, [fp, #-0x18]
    // 0xb1e04c: LeaveFrame
    //     0xb1e04c: mov             SP, fp
    //     0xb1e050: ldp             fp, lr, [SP], #0x10
    // 0xb1e054: ret
    //     0xb1e054: ret             
    // 0xb1e058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1e058: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1e05c: b               #0xb1dff8
  }
}

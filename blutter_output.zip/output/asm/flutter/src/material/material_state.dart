// lib: , url: package:flutter/src/material/material_state.dart

// class id: 1049270, size: 0x8
class :: {
}

// class id: 2162, size: 0x10, field offset: 0x8
//   const constructor, 
class MaterialStatePropertyAll<X0> extends Object
    implements MaterialStateProperty<X0> {

  _Double field_c;

  _ toString(/* No info */) {
    // ** addr: 0xade2bc, size: 0x108
    // 0xade2bc: EnterFrame
    //     0xade2bc: stp             fp, lr, [SP, #-0x10]!
    //     0xade2c0: mov             fp, SP
    // 0xade2c4: AllocStack(0x10)
    //     0xade2c4: sub             SP, SP, #0x10
    // 0xade2c8: CheckStackOverflow
    //     0xade2c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xade2cc: cmp             SP, x16
    //     0xade2d0: b.ls            #0xade3bc
    // 0xade2d4: ldr             x0, [fp, #0x10]
    // 0xade2d8: LoadField: r3 = r0->field_b
    //     0xade2d8: ldur            w3, [x0, #0xb]
    // 0xade2dc: DecompressPointer r3
    //     0xade2dc: add             x3, x3, HEAP, lsl #32
    // 0xade2e0: stur            x3, [fp, #-8]
    // 0xade2e4: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0xade2e4: mov             x0, #0x76
    //     0xade2e8: tbz             w3, #0, #0xade2f8
    //     0xade2ec: ldur            x0, [x3, #-1]
    //     0xade2f0: ubfx            x0, x0, #0xc, #0x14
    //     0xade2f4: lsl             x0, x0, #1
    // 0xade2f8: cmp             w0, #0x7a
    // 0xade2fc: b.ne            #0xade378
    // 0xade300: r1 = Null
    //     0xade300: mov             x1, NULL
    // 0xade304: r2 = 6
    //     0xade304: mov             x2, #6
    // 0xade308: r0 = AllocateArray()
    //     0xade308: bl              #0xd6987c  ; AllocateArrayStub
    // 0xade30c: stur            x0, [fp, #-0x10]
    // 0xade310: r17 = "MaterialStatePropertyAll("
    //     0xade310: add             x17, PP, #0xe, lsl #12  ; [pp+0xe918] "MaterialStatePropertyAll("
    //     0xade314: ldr             x17, [x17, #0x918]
    // 0xade318: StoreField: r0->field_f = r17
    //     0xade318: stur            w17, [x0, #0xf]
    // 0xade31c: ldur            x16, [fp, #-8]
    // 0xade320: SaveReg r16
    //     0xade320: str             x16, [SP, #-8]!
    // 0xade324: r0 = debugFormatDouble()
    //     0xade324: bl              #0xa77fb4  ; [package:flutter/src/foundation/debug.dart] ::debugFormatDouble
    // 0xade328: add             SP, SP, #8
    // 0xade32c: ldur            x1, [fp, #-0x10]
    // 0xade330: ArrayStore: r1[1] = r0  ; List_4
    //     0xade330: add             x25, x1, #0x13
    //     0xade334: str             w0, [x25]
    //     0xade338: tbz             w0, #0, #0xade354
    //     0xade33c: ldurb           w16, [x1, #-1]
    //     0xade340: ldurb           w17, [x0, #-1]
    //     0xade344: and             x16, x17, x16, lsr #2
    //     0xade348: tst             x16, HEAP, lsr #32
    //     0xade34c: b.eq            #0xade354
    //     0xade350: bl              #0xd67e5c
    // 0xade354: ldur            x0, [fp, #-0x10]
    // 0xade358: r17 = ")"
    //     0xade358: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xade35c: StoreField: r0->field_17 = r17
    //     0xade35c: stur            w17, [x0, #0x17]
    // 0xade360: SaveReg r0
    //     0xade360: str             x0, [SP, #-8]!
    // 0xade364: r0 = _interpolate()
    //     0xade364: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xade368: add             SP, SP, #8
    // 0xade36c: LeaveFrame
    //     0xade36c: mov             SP, fp
    //     0xade370: ldp             fp, lr, [SP], #0x10
    // 0xade374: ret
    //     0xade374: ret             
    // 0xade378: mov             x0, x3
    // 0xade37c: r1 = Null
    //     0xade37c: mov             x1, NULL
    // 0xade380: r2 = 6
    //     0xade380: mov             x2, #6
    // 0xade384: r0 = AllocateArray()
    //     0xade384: bl              #0xd6987c  ; AllocateArrayStub
    // 0xade388: r17 = "MaterialStatePropertyAll("
    //     0xade388: add             x17, PP, #0xe, lsl #12  ; [pp+0xe918] "MaterialStatePropertyAll("
    //     0xade38c: ldr             x17, [x17, #0x918]
    // 0xade390: StoreField: r0->field_f = r17
    //     0xade390: stur            w17, [x0, #0xf]
    // 0xade394: ldur            x1, [fp, #-8]
    // 0xade398: StoreField: r0->field_13 = r1
    //     0xade398: stur            w1, [x0, #0x13]
    // 0xade39c: r17 = ")"
    //     0xade39c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xade3a0: StoreField: r0->field_17 = r17
    //     0xade3a0: stur            w17, [x0, #0x17]
    // 0xade3a4: SaveReg r0
    //     0xade3a4: str             x0, [SP, #-8]!
    // 0xade3a8: r0 = _interpolate()
    //     0xade3a8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xade3ac: add             SP, SP, #8
    // 0xade3b0: LeaveFrame
    //     0xade3b0: mov             SP, fp
    //     0xade3b4: ldp             fp, lr, [SP], #0x10
    // 0xade3b8: ret
    //     0xade3b8: ret             
    // 0xade3bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xade3bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xade3c0: b               #0xade2d4
  }
}

// class id: 2163, size: 0x10, field offset: 0x8
class _MaterialStatePropertyWith<X0> extends Object
    implements MaterialStateProperty<X0> {
}

// class id: 2164, size: 0x20, field offset: 0x8
//   const constructor, 
class _LerpProperties<X0> extends Object
    implements MaterialStateProperty<X0> {

  _ resolve(/* No info */) {
    // ** addr: 0x5b6058, size: 0x13c
    // 0x5b6058: EnterFrame
    //     0x5b6058: stp             fp, lr, [SP, #-0x10]!
    //     0x5b605c: mov             fp, SP
    // 0x5b6060: AllocStack(0x8)
    //     0x5b6060: sub             SP, SP, #8
    // 0x5b6064: CheckStackOverflow
    //     0x5b6064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5b6068: cmp             SP, x16
    //     0x5b606c: b.ls            #0x5b6174
    // 0x5b6070: ldr             x1, [fp, #0x18]
    // 0x5b6074: LoadField: r0 = r1->field_b
    //     0x5b6074: ldur            w0, [x1, #0xb]
    // 0x5b6078: DecompressPointer r0
    //     0x5b6078: add             x0, x0, HEAP, lsl #32
    // 0x5b607c: cmp             w0, NULL
    // 0x5b6080: b.ne            #0x5b608c
    // 0x5b6084: r2 = Null
    //     0x5b6084: mov             x2, NULL
    // 0x5b6088: b               #0x5b60c0
    // 0x5b608c: r2 = LoadClassIdInstr(r0)
    //     0x5b608c: ldur            x2, [x0, #-1]
    //     0x5b6090: ubfx            x2, x2, #0xc, #0x14
    // 0x5b6094: ldr             x16, [fp, #0x10]
    // 0x5b6098: stp             x16, x0, [SP, #-0x10]!
    // 0x5b609c: mov             x0, x2
    // 0x5b60a0: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x5b60a0: mov             x17, #0x5e7
    //     0x5b60a4: movk            x17, #1, lsl #16
    //     0x5b60a8: add             lr, x0, x17
    //     0x5b60ac: ldr             lr, [x21, lr, lsl #3]
    //     0x5b60b0: blr             lr
    // 0x5b60b4: add             SP, SP, #0x10
    // 0x5b60b8: mov             x2, x0
    // 0x5b60bc: ldr             x1, [fp, #0x18]
    // 0x5b60c0: stur            x2, [fp, #-8]
    // 0x5b60c4: LoadField: r0 = r1->field_f
    //     0x5b60c4: ldur            w0, [x1, #0xf]
    // 0x5b60c8: DecompressPointer r0
    //     0x5b60c8: add             x0, x0, HEAP, lsl #32
    // 0x5b60cc: cmp             w0, NULL
    // 0x5b60d0: b.ne            #0x5b60e0
    // 0x5b60d4: mov             x0, x1
    // 0x5b60d8: r1 = Null
    //     0x5b60d8: mov             x1, NULL
    // 0x5b60dc: b               #0x5b6114
    // 0x5b60e0: r3 = LoadClassIdInstr(r0)
    //     0x5b60e0: ldur            x3, [x0, #-1]
    //     0x5b60e4: ubfx            x3, x3, #0xc, #0x14
    // 0x5b60e8: ldr             x16, [fp, #0x10]
    // 0x5b60ec: stp             x16, x0, [SP, #-0x10]!
    // 0x5b60f0: mov             x0, x3
    // 0x5b60f4: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x5b60f4: mov             x17, #0x5e7
    //     0x5b60f8: movk            x17, #1, lsl #16
    //     0x5b60fc: add             lr, x0, x17
    //     0x5b6100: ldr             lr, [x21, lr, lsl #3]
    //     0x5b6104: blr             lr
    // 0x5b6108: add             SP, SP, #0x10
    // 0x5b610c: mov             x1, x0
    // 0x5b6110: ldr             x0, [fp, #0x18]
    // 0x5b6114: LoadField: d0 = r0->field_13
    //     0x5b6114: ldur            d0, [x0, #0x13]
    // 0x5b6118: LoadField: r2 = r0->field_1b
    //     0x5b6118: ldur            w2, [x0, #0x1b]
    // 0x5b611c: DecompressPointer r2
    //     0x5b611c: add             x2, x2, HEAP, lsl #32
    // 0x5b6120: r0 = inline_Allocate_Double()
    //     0x5b6120: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x5b6124: add             x0, x0, #0x10
    //     0x5b6128: cmp             x3, x0
    //     0x5b612c: b.ls            #0x5b617c
    //     0x5b6130: str             x0, [THR, #0x60]  ; THR::top
    //     0x5b6134: sub             x0, x0, #0xf
    //     0x5b6138: mov             x3, #0xd108
    //     0x5b613c: movk            x3, #3, lsl #16
    //     0x5b6140: stur            x3, [x0, #-1]
    // 0x5b6144: StoreField: r0->field_7 = d0
    //     0x5b6144: stur            d0, [x0, #7]
    // 0x5b6148: ldur            x16, [fp, #-8]
    // 0x5b614c: stp             x16, x2, [SP, #-0x10]!
    // 0x5b6150: stp             x0, x1, [SP, #-0x10]!
    // 0x5b6154: mov             x0, x2
    // 0x5b6158: ClosureCall
    //     0x5b6158: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    //     0x5b615c: ldur            x2, [x0, #0x1f]
    //     0x5b6160: blr             x2
    // 0x5b6164: add             SP, SP, #0x20
    // 0x5b6168: LeaveFrame
    //     0x5b6168: mov             SP, fp
    //     0x5b616c: ldp             fp, lr, [SP], #0x10
    // 0x5b6170: ret
    //     0x5b6170: ret             
    // 0x5b6174: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5b6174: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5b6178: b               #0x5b6070
    // 0x5b617c: SaveReg d0
    //     0x5b617c: str             q0, [SP, #-0x10]!
    // 0x5b6180: stp             x1, x2, [SP, #-0x10]!
    // 0x5b6184: r0 = AllocateDouble()
    //     0x5b6184: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5b6188: ldp             x1, x2, [SP], #0x10
    // 0x5b618c: RestoreReg d0
    //     0x5b618c: ldr             q0, [SP], #0x10
    // 0x5b6190: b               #0x5b6144
  }
}

// class id: 2216, size: 0xc, field offset: 0x8
abstract class MaterialStateProperty<X0> extends Object {

  static _ resolveAs(/* No info */) {
    // ** addr: 0x5a6b88, size: 0x104
    // 0x5a6b88: EnterFrame
    //     0x5a6b88: stp             fp, lr, [SP, #-0x10]!
    //     0x5a6b8c: mov             fp, SP
    // 0x5a6b90: mov             x0, x4
    // 0x5a6b94: LoadField: r1 = r0->field_f
    //     0x5a6b94: ldur            w1, [x0, #0xf]
    // 0x5a6b98: DecompressPointer r1
    //     0x5a6b98: add             x1, x1, HEAP, lsl #32
    // 0x5a6b9c: cbnz            w1, #0x5a6ba8
    // 0x5a6ba0: r1 = Null
    //     0x5a6ba0: mov             x1, NULL
    // 0x5a6ba4: b               #0x5a6bbc
    // 0x5a6ba8: LoadField: r1 = r0->field_17
    //     0x5a6ba8: ldur            w1, [x0, #0x17]
    // 0x5a6bac: DecompressPointer r1
    //     0x5a6bac: add             x1, x1, HEAP, lsl #32
    // 0x5a6bb0: add             x0, fp, w1, sxtw #2
    // 0x5a6bb4: ldr             x0, [x0, #0x10]
    // 0x5a6bb8: mov             x1, x0
    // 0x5a6bbc: CheckStackOverflow
    //     0x5a6bbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a6bc0: cmp             SP, x16
    //     0x5a6bc4: b.ls            #0x5a6c84
    // 0x5a6bc8: ldr             x0, [fp, #0x18]
    // 0x5a6bcc: r2 = Null
    //     0x5a6bcc: mov             x2, NULL
    // 0x5a6bd0: cmp             w0, NULL
    // 0x5a6bd4: b.eq            #0x5a6c28
    // 0x5a6bd8: branchIfSmi(r0, 0x5a6c28)
    //     0x5a6bd8: tbz             w0, #0, #0x5a6c28
    // 0x5a6bdc: r8 = MaterialStateProperty<Y0>
    //     0x5a6bdc: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2deb8] Type: MaterialStateProperty<Y0>
    //     0x5a6be0: ldr             x8, [x8, #0xeb8]
    // 0x5a6be4: r3 = SubtypeTestCache
    //     0x5a6be4: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2dec0] SubtypeTestCache
    //     0x5a6be8: ldr             x3, [x3, #0xec0]
    // 0x5a6bec: r24 = Subtype5TestCacheStub
    //     0x5a6bec: ldr             x24, [PP, #0xc78]  ; [pp+0xc78] Stub: Subtype5TestCache (0x4ae1bc)
    // 0x5a6bf0: LoadField: r30 = r24->field_7
    //     0x5a6bf0: ldur            lr, [x24, #7]
    // 0x5a6bf4: blr             lr
    // 0x5a6bf8: cmp             w7, NULL
    // 0x5a6bfc: b.eq            #0x5a6c08
    // 0x5a6c00: tbnz            w7, #4, #0x5a6c28
    // 0x5a6c04: b               #0x5a6c30
    // 0x5a6c08: r8 = MaterialStateProperty<Y0>
    //     0x5a6c08: add             x8, PP, #0x2d, lsl #12  ; [pp+0x2dec8] Type: MaterialStateProperty<Y0>
    //     0x5a6c0c: ldr             x8, [x8, #0xec8]
    // 0x5a6c10: r3 = SubtypeTestCache
    //     0x5a6c10: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2ded0] SubtypeTestCache
    //     0x5a6c14: ldr             x3, [x3, #0xed0]
    // 0x5a6c18: r24 = InstanceOfStub
    //     0x5a6c18: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x5a6c1c: LoadField: r30 = r24->field_7
    //     0x5a6c1c: ldur            lr, [x24, #7]
    // 0x5a6c20: blr             lr
    // 0x5a6c24: b               #0x5a6c34
    // 0x5a6c28: r0 = false
    //     0x5a6c28: add             x0, NULL, #0x30  ; false
    // 0x5a6c2c: b               #0x5a6c34
    // 0x5a6c30: r0 = true
    //     0x5a6c30: add             x0, NULL, #0x20  ; true
    // 0x5a6c34: tbnz            w0, #4, #0x5a6c74
    // 0x5a6c38: ldr             x0, [fp, #0x18]
    // 0x5a6c3c: r1 = LoadClassIdInstr(r0)
    //     0x5a6c3c: ldur            x1, [x0, #-1]
    //     0x5a6c40: ubfx            x1, x1, #0xc, #0x14
    // 0x5a6c44: ldr             x16, [fp, #0x10]
    // 0x5a6c48: stp             x16, x0, [SP, #-0x10]!
    // 0x5a6c4c: mov             x0, x1
    // 0x5a6c50: r0 = GDT[cid_x0 + 0x105e7]()
    //     0x5a6c50: mov             x17, #0x5e7
    //     0x5a6c54: movk            x17, #1, lsl #16
    //     0x5a6c58: add             lr, x0, x17
    //     0x5a6c5c: ldr             lr, [x21, lr, lsl #3]
    //     0x5a6c60: blr             lr
    // 0x5a6c64: add             SP, SP, #0x10
    // 0x5a6c68: LeaveFrame
    //     0x5a6c68: mov             SP, fp
    //     0x5a6c6c: ldp             fp, lr, [SP], #0x10
    // 0x5a6c70: ret
    //     0x5a6c70: ret             
    // 0x5a6c74: ldr             x0, [fp, #0x18]
    // 0x5a6c78: LeaveFrame
    //     0x5a6c78: mov             SP, fp
    //     0x5a6c7c: ldp             fp, lr, [SP], #0x10
    // 0x5a6c80: ret
    //     0x5a6c80: ret             
    // 0x5a6c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a6c84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a6c88: b               #0x5a6bc8
  }
  static _ resolveWith(/* No info */) {
    // ** addr: 0x84d13c, size: 0x50
    // 0x84d13c: EnterFrame
    //     0x84d13c: stp             fp, lr, [SP, #-0x10]!
    //     0x84d140: mov             fp, SP
    // 0x84d144: mov             x0, x4
    // 0x84d148: LoadField: r1 = r0->field_f
    //     0x84d148: ldur            w1, [x0, #0xf]
    // 0x84d14c: DecompressPointer r1
    //     0x84d14c: add             x1, x1, HEAP, lsl #32
    // 0x84d150: cbnz            w1, #0x84d15c
    // 0x84d154: r1 = Null
    //     0x84d154: mov             x1, NULL
    // 0x84d158: b               #0x84d170
    // 0x84d15c: LoadField: r1 = r0->field_17
    //     0x84d15c: ldur            w1, [x0, #0x17]
    // 0x84d160: DecompressPointer r1
    //     0x84d160: add             x1, x1, HEAP, lsl #32
    // 0x84d164: add             x0, fp, w1, sxtw #2
    // 0x84d168: ldr             x0, [x0, #0x10]
    // 0x84d16c: mov             x1, x0
    // 0x84d170: ldr             x0, [fp, #0x10]
    // 0x84d174: r0 = _MaterialStatePropertyWith()
    //     0x84d174: bl              #0x84d18c  ; Allocate_MaterialStatePropertyWithStub -> _MaterialStatePropertyWith<X0> (size=0x10)
    // 0x84d178: ldr             x1, [fp, #0x10]
    // 0x84d17c: StoreField: r0->field_b = r1
    //     0x84d17c: stur            w1, [x0, #0xb]
    // 0x84d180: LeaveFrame
    //     0x84d180: mov             SP, fp
    //     0x84d184: ldp             fp, lr, [SP], #0x10
    // 0x84d188: ret
    //     0x84d188: ret             
  }
  static _ all(/* No info */) {
    // ** addr: 0x850ff4, size: 0x50
    // 0x850ff4: EnterFrame
    //     0x850ff4: stp             fp, lr, [SP, #-0x10]!
    //     0x850ff8: mov             fp, SP
    // 0x850ffc: mov             x0, x4
    // 0x851000: LoadField: r1 = r0->field_f
    //     0x851000: ldur            w1, [x0, #0xf]
    // 0x851004: DecompressPointer r1
    //     0x851004: add             x1, x1, HEAP, lsl #32
    // 0x851008: cbnz            w1, #0x851014
    // 0x85100c: r1 = Null
    //     0x85100c: mov             x1, NULL
    // 0x851010: b               #0x851028
    // 0x851014: LoadField: r1 = r0->field_17
    //     0x851014: ldur            w1, [x0, #0x17]
    // 0x851018: DecompressPointer r1
    //     0x851018: add             x1, x1, HEAP, lsl #32
    // 0x85101c: add             x0, fp, w1, sxtw #2
    // 0x851020: ldr             x0, [x0, #0x10]
    // 0x851024: mov             x1, x0
    // 0x851028: r0 = MaterialStatePropertyAll()
    //     0x851028: bl              #0x851044  ; AllocateMaterialStatePropertyAllStub -> MaterialStatePropertyAll<X0> (size=0x10)
    // 0x85102c: r1 = Instance_Color
    //     0x85102c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x851030: ldr             x1, [x1, #0xbe8]
    // 0x851034: StoreField: r0->field_b = r1
    //     0x851034: stur            w1, [x0, #0xb]
    // 0x851038: LeaveFrame
    //     0x851038: mov             SP, fp
    //     0x85103c: ldp             fp, lr, [SP], #0x10
    // 0x851040: ret
    //     0x851040: ret             
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf0cf8, size: 0x98
    // 0xbf0cf8: EnterFrame
    //     0xbf0cf8: stp             fp, lr, [SP, #-0x10]!
    //     0xbf0cfc: mov             fp, SP
    // 0xbf0d00: mov             x0, x4
    // 0xbf0d04: LoadField: r1 = r0->field_f
    //     0xbf0d04: ldur            w1, [x0, #0xf]
    // 0xbf0d08: DecompressPointer r1
    //     0xbf0d08: add             x1, x1, HEAP, lsl #32
    // 0xbf0d0c: cbnz            w1, #0xbf0d18
    // 0xbf0d10: r1 = Null
    //     0xbf0d10: mov             x1, NULL
    // 0xbf0d14: b               #0xbf0d2c
    // 0xbf0d18: LoadField: r1 = r0->field_17
    //     0xbf0d18: ldur            w1, [x0, #0x17]
    // 0xbf0d1c: DecompressPointer r1
    //     0xbf0d1c: add             x1, x1, HEAP, lsl #32
    // 0xbf0d20: add             x0, fp, w1, sxtw #2
    // 0xbf0d24: ldr             x0, [x0, #0x10]
    // 0xbf0d28: mov             x1, x0
    // 0xbf0d2c: ldr             x0, [fp, #0x28]
    // 0xbf0d30: cmp             w0, NULL
    // 0xbf0d34: b.ne            #0xbf0d54
    // 0xbf0d38: ldr             x2, [fp, #0x20]
    // 0xbf0d3c: cmp             w2, NULL
    // 0xbf0d40: b.ne            #0xbf0d58
    // 0xbf0d44: r0 = Null
    //     0xbf0d44: mov             x0, NULL
    // 0xbf0d48: LeaveFrame
    //     0xbf0d48: mov             SP, fp
    //     0xbf0d4c: ldp             fp, lr, [SP], #0x10
    // 0xbf0d50: ret
    //     0xbf0d50: ret             
    // 0xbf0d54: ldr             x2, [fp, #0x20]
    // 0xbf0d58: ldr             d0, [fp, #0x18]
    // 0xbf0d5c: ldr             x3, [fp, #0x10]
    // 0xbf0d60: r0 = _LerpProperties()
    //     0xbf0d60: bl              #0xbf0d90  ; Allocate_LerpPropertiesStub -> _LerpProperties<X0> (size=0x20)
    // 0xbf0d64: ldr             x1, [fp, #0x28]
    // 0xbf0d68: StoreField: r0->field_b = r1
    //     0xbf0d68: stur            w1, [x0, #0xb]
    // 0xbf0d6c: ldr             x1, [fp, #0x20]
    // 0xbf0d70: StoreField: r0->field_f = r1
    //     0xbf0d70: stur            w1, [x0, #0xf]
    // 0xbf0d74: ldr             d0, [fp, #0x18]
    // 0xbf0d78: StoreField: r0->field_13 = d0
    //     0xbf0d78: stur            d0, [x0, #0x13]
    // 0xbf0d7c: ldr             x1, [fp, #0x10]
    // 0xbf0d80: StoreField: r0->field_1b = r1
    //     0xbf0d80: stur            w1, [x0, #0x1b]
    // 0xbf0d84: LeaveFrame
    //     0xbf0d84: mov             SP, fp
    //     0xbf0d88: ldp             fp, lr, [SP], #0x10
    // 0xbf0d8c: ret
    //     0xbf0d8c: ret             
  }
}

// class id: 2788, size: 0x70, field offset: 0x70
//   const constructor, 
abstract class MaterialStateTextStyle extends TextStyle
    implements MaterialStateProperty<X0> {

  static _ resolveWith(/* No info */) {
    // ** addr: 0x85bd30, size: 0x28
    // 0x85bd30: EnterFrame
    //     0x85bd30: stp             fp, lr, [SP, #-0x10]!
    //     0x85bd34: mov             fp, SP
    // 0x85bd38: r0 = _MaterialStateTextStyle()
    //     0x85bd38: bl              #0x85bd58  ; Allocate_MaterialStateTextStyleStub -> _MaterialStateTextStyle (size=0x74)
    // 0x85bd3c: ldr             x1, [fp, #0x10]
    // 0x85bd40: StoreField: r0->field_6f = r1
    //     0x85bd40: stur            w1, [x0, #0x6f]
    // 0x85bd44: r1 = true
    //     0x85bd44: add             x1, NULL, #0x20  ; true
    // 0x85bd48: StoreField: r0->field_7 = r1
    //     0x85bd48: stur            w1, [x0, #7]
    // 0x85bd4c: LeaveFrame
    //     0x85bd4c: mov             SP, fp
    //     0x85bd50: ldp             fp, lr, [SP], #0x10
    // 0x85bd54: ret
    //     0x85bd54: ret             
  }
}

// class id: 2789, size: 0x74, field offset: 0x70
//   const constructor, 
class _MaterialStateTextStyle extends MaterialStateTextStyle {

  _ resolve(/* No info */) {
    // ** addr: 0x5ac4ac, size: 0x50
    // 0x5ac4ac: EnterFrame
    //     0x5ac4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x5ac4b0: mov             fp, SP
    // 0x5ac4b4: CheckStackOverflow
    //     0x5ac4b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ac4b8: cmp             SP, x16
    //     0x5ac4bc: b.ls            #0x5ac4f4
    // 0x5ac4c0: ldr             x0, [fp, #0x18]
    // 0x5ac4c4: LoadField: r1 = r0->field_6f
    //     0x5ac4c4: ldur            w1, [x0, #0x6f]
    // 0x5ac4c8: DecompressPointer r1
    //     0x5ac4c8: add             x1, x1, HEAP, lsl #32
    // 0x5ac4cc: ldr             x16, [fp, #0x10]
    // 0x5ac4d0: stp             x16, x1, [SP, #-0x10]!
    // 0x5ac4d4: mov             x0, x1
    // 0x5ac4d8: ClosureCall
    //     0x5ac4d8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5ac4dc: ldur            x2, [x0, #0x1f]
    //     0x5ac4e0: blr             x2
    // 0x5ac4e4: add             SP, SP, #0x10
    // 0x5ac4e8: LeaveFrame
    //     0x5ac4e8: mov             SP, fp
    //     0x5ac4ec: ldp             fp, lr, [SP], #0x10
    // 0x5ac4f0: ret
    //     0x5ac4f0: ret             
    // 0x5ac4f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ac4f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ac4f8: b               #0x5ac4c0
  }
}

// class id: 2791, size: 0x20, field offset: 0x20
//   const constructor, 
abstract class MaterialStateBorderSide extends BorderSide
    implements MaterialStateProperty<X0> {

  static _ resolveWith(/* No info */) {
    // ** addr: 0x85ea68, size: 0x48
    // 0x85ea68: EnterFrame
    //     0x85ea68: stp             fp, lr, [SP, #-0x10]!
    //     0x85ea6c: mov             fp, SP
    // 0x85ea70: r0 = _MaterialStateBorderSide()
    //     0x85ea70: bl              #0x85eab0  ; Allocate_MaterialStateBorderSideStub -> _MaterialStateBorderSide (size=0x24)
    // 0x85ea74: ldr             x1, [fp, #0x10]
    // 0x85ea78: StoreField: r0->field_1f = r1
    //     0x85ea78: stur            w1, [x0, #0x1f]
    // 0x85ea7c: r1 = Instance_Color
    //     0x85ea7c: add             x1, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0x85ea80: ldr             x1, [x1, #0xf38]
    // 0x85ea84: StoreField: r0->field_7 = r1
    //     0x85ea84: stur            w1, [x0, #7]
    // 0x85ea88: d0 = 1.000000
    //     0x85ea88: fmov            d0, #1.00000000
    // 0x85ea8c: StoreField: r0->field_b = d0
    //     0x85ea8c: stur            d0, [x0, #0xb]
    // 0x85ea90: r1 = Instance_BorderStyle
    //     0x85ea90: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbd0] Obj!BorderStyle@b64ef1
    //     0x85ea94: ldr             x1, [x1, #0xbd0]
    // 0x85ea98: StoreField: r0->field_13 = r1
    //     0x85ea98: stur            w1, [x0, #0x13]
    // 0x85ea9c: d0 = -1.000000
    //     0x85ea9c: fmov            d0, #-1.00000000
    // 0x85eaa0: StoreField: r0->field_17 = d0
    //     0x85eaa0: stur            d0, [x0, #0x17]
    // 0x85eaa4: LeaveFrame
    //     0x85eaa4: mov             SP, fp
    //     0x85eaa8: ldp             fp, lr, [SP], #0x10
    // 0x85eaac: ret
    //     0x85eaac: ret             
  }
}

// class id: 2792, size: 0x24, field offset: 0x20
//   const constructor, 
class _MaterialStateBorderSide extends MaterialStateBorderSide {

  _ resolve(/* No info */) {
    // ** addr: 0x5ac45c, size: 0x50
    // 0x5ac45c: EnterFrame
    //     0x5ac45c: stp             fp, lr, [SP, #-0x10]!
    //     0x5ac460: mov             fp, SP
    // 0x5ac464: CheckStackOverflow
    //     0x5ac464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ac468: cmp             SP, x16
    //     0x5ac46c: b.ls            #0x5ac4a4
    // 0x5ac470: ldr             x0, [fp, #0x18]
    // 0x5ac474: LoadField: r1 = r0->field_1f
    //     0x5ac474: ldur            w1, [x0, #0x1f]
    // 0x5ac478: DecompressPointer r1
    //     0x5ac478: add             x1, x1, HEAP, lsl #32
    // 0x5ac47c: ldr             x16, [fp, #0x10]
    // 0x5ac480: stp             x16, x1, [SP, #-0x10]!
    // 0x5ac484: mov             x0, x1
    // 0x5ac488: ClosureCall
    //     0x5ac488: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5ac48c: ldur            x2, [x0, #0x1f]
    //     0x5ac490: blr             x2
    // 0x5ac494: add             SP, SP, #0x10
    // 0x5ac498: LeaveFrame
    //     0x5ac498: mov             SP, fp
    //     0x5ac49c: ldp             fp, lr, [SP], #0x10
    // 0x5ac4a0: ret
    //     0x5ac4a0: ret             
    // 0x5ac4a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ac4a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ac4a8: b               #0x5ac470
  }
}

// class id: 2825, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class MaterialStateMouseCursor extends MouseCursor
    implements MaterialStateProperty<X0> {

  _ createSession(/* No info */) {
    // ** addr: 0xcced2c, size: 0x188
    // 0xcced2c: EnterFrame
    //     0xcced2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcced30: mov             fp, SP
    // 0xcced34: AllocStack(0x10)
    //     0xcced34: sub             SP, SP, #0x10
    // 0xcced38: CheckStackOverflow
    //     0xcced38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcced3c: cmp             SP, x16
    //     0xcced40: b.ls            #0xcceea8
    // 0xcced44: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0xcced44: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcced48: ldr             x0, [x0, #0x598]
    //     0xcced4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcced50: cmp             w0, w16
    //     0xcced54: b.ne            #0xcced60
    //     0xcced58: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0xcced5c: bl              #0xd67cdc
    // 0xcced60: r1 = <MaterialState>
    //     0xcced60: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0xcced64: ldr             x1, [x1, #0xcf0]
    // 0xcced68: stur            x0, [fp, #-8]
    // 0xcced6c: r0 = _Set()
    //     0xcced6c: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0xcced70: mov             x1, x0
    // 0xcced74: ldur            x0, [fp, #-8]
    // 0xcced78: stur            x1, [fp, #-0x10]
    // 0xcced7c: StoreField: r1->field_1b = r0
    //     0xcced7c: stur            w0, [x1, #0x1b]
    // 0xcced80: StoreField: r1->field_b = rZR
    //     0xcced80: stur            wzr, [x1, #0xb]
    // 0xcced84: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0xcced84: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcced88: ldr             x0, [x0, #0x5a0]
    //     0xcced8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcced90: cmp             w0, w16
    //     0xcced94: b.ne            #0xcceda0
    //     0xcced98: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0xcced9c: bl              #0xd67cdc
    // 0xcceda0: mov             x1, x0
    // 0xcceda4: ldur            x0, [fp, #-0x10]
    // 0xcceda8: StoreField: r0->field_f = r1
    //     0xcceda8: stur            w1, [x0, #0xf]
    // 0xccedac: StoreField: r0->field_13 = rZR
    //     0xccedac: stur            wzr, [x0, #0x13]
    // 0xccedb0: StoreField: r0->field_17 = rZR
    //     0xccedb0: stur            wzr, [x0, #0x17]
    // 0xccedb4: ldr             x1, [fp, #0x18]
    // 0xccedb8: r2 = LoadClassIdInstr(r1)
    //     0xccedb8: ldur            x2, [x1, #-1]
    //     0xccedbc: ubfx            x2, x2, #0xc, #0x14
    // 0xccedc0: lsl             x2, x2, #1
    // 0xccedc4: r17 = 5652
    //     0xccedc4: mov             x17, #0x1614
    // 0xccedc8: cmp             w2, w17
    // 0xccedcc: b.ne            #0xccee04
    // 0xccedd0: r16 = Instance_MaterialState
    //     0xccedd0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0xccedd4: ldr             x16, [x16, #0x2a0]
    // 0xccedd8: stp             x16, x0, [SP, #-0x10]!
    // 0xcceddc: r0 = contains()
    //     0xcceddc: bl              #0x787194  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::contains
    // 0xccede0: add             SP, SP, #0x10
    // 0xccede4: tbnz            w0, #4, #0xccedf0
    // 0xccede8: r1 = Instance_SystemMouseCursor
    //     0xccede8: ldr             x1, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0xccedec: b               #0xccee78
    // 0xccedf0: ldr             x1, [fp, #0x18]
    // 0xccedf4: LoadField: r0 = r1->field_7
    //     0xccedf4: ldur            w0, [x1, #7]
    // 0xccedf8: DecompressPointer r0
    //     0xccedf8: add             x0, x0, HEAP, lsl #32
    // 0xccedfc: mov             x1, x0
    // 0xccee00: b               #0xccee78
    // 0xccee04: r17 = 5654
    //     0xccee04: mov             x17, #0x1616
    // 0xccee08: cmp             w2, w17
    // 0xccee0c: b.ne            #0xccee4c
    // 0xccee10: r16 = <MouseCursor?>
    //     0xccee10: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0xccee14: ldr             x16, [x16, #0x8b8]
    // 0xccee18: stp             NULL, x16, [SP, #-0x10]!
    // 0xccee1c: SaveReg r0
    //     0xccee1c: str             x0, [SP, #-8]!
    // 0xccee20: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xccee20: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xccee24: r0 = resolveAs()
    //     0xccee24: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0xccee28: add             SP, SP, #0x18
    // 0xccee2c: r16 = Instance__EnabledAndDisabledMouseCursor
    //     0xccee2c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0xccee30: ldr             x16, [x16, #0x208]
    // 0xccee34: ldur            lr, [fp, #-0x10]
    // 0xccee38: stp             lr, x16, [SP, #-0x10]!
    // 0xccee3c: r0 = resolve()
    //     0xccee3c: bl              #0x5a6cbc  ; [package:flutter/src/material/material_state.dart] _EnabledAndDisabledMouseCursor::resolve
    // 0xccee40: add             SP, SP, #0x10
    // 0xccee44: mov             x1, x0
    // 0xccee48: b               #0xccee78
    // 0xccee4c: LoadField: r0 = r1->field_7
    //     0xccee4c: ldur            w0, [x1, #7]
    // 0xccee50: DecompressPointer r0
    //     0xccee50: add             x0, x0, HEAP, lsl #32
    // 0xccee54: ldur            x16, [fp, #-0x10]
    // 0xccee58: stp             x16, x0, [SP, #-0x10]!
    // 0xccee5c: ClosureCall
    //     0xccee5c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xccee60: ldur            x2, [x0, #0x1f]
    //     0xccee64: blr             x2
    // 0xccee68: add             SP, SP, #0x10
    // 0xccee6c: cmp             w0, NULL
    // 0xccee70: b.eq            #0xcceeb0
    // 0xccee74: mov             x1, x0
    // 0xccee78: ldr             x0, [fp, #0x10]
    // 0xccee7c: r2 = LoadClassIdInstr(r1)
    //     0xccee7c: ldur            x2, [x1, #-1]
    //     0xccee80: ubfx            x2, x2, #0xc, #0x14
    // 0xccee84: stp             x0, x1, [SP, #-0x10]!
    // 0xccee88: mov             x0, x2
    // 0xccee8c: r0 = GDT[cid_x0 + -0xbd1]()
    //     0xccee8c: sub             lr, x0, #0xbd1
    //     0xccee90: ldr             lr, [x21, lr, lsl #3]
    //     0xccee94: blr             lr
    // 0xccee98: add             SP, SP, #0x10
    // 0xccee9c: LeaveFrame
    //     0xccee9c: mov             SP, fp
    //     0xcceea0: ldp             fp, lr, [SP], #0x10
    // 0xcceea4: ret
    //     0xcceea4: ret             
    // 0xcceea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcceea8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcceeac: b               #0xcced44
    // 0xcceeb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcceeb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2826, size: 0x14, field offset: 0x8
//   const constructor, 
class _EnabledAndDisabledMouseCursor extends MaterialStateMouseCursor {

  SystemMouseCursor field_8;
  SystemMouseCursor field_c;
  _OneByteString field_10;

  _ resolve(/* No info */) {
    // ** addr: 0x5a6cbc, size: 0x78
    // 0x5a6cbc: EnterFrame
    //     0x5a6cbc: stp             fp, lr, [SP, #-0x10]!
    //     0x5a6cc0: mov             fp, SP
    // 0x5a6cc4: CheckStackOverflow
    //     0x5a6cc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a6cc8: cmp             SP, x16
    //     0x5a6ccc: b.ls            #0x5a6d2c
    // 0x5a6cd0: ldr             x0, [fp, #0x10]
    // 0x5a6cd4: r1 = LoadClassIdInstr(r0)
    //     0x5a6cd4: ldur            x1, [x0, #-1]
    //     0x5a6cd8: ubfx            x1, x1, #0xc, #0x14
    // 0x5a6cdc: r16 = Instance_MaterialState
    //     0x5a6cdc: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x5a6ce0: ldr             x16, [x16, #0x2a0]
    // 0x5a6ce4: stp             x16, x0, [SP, #-0x10]!
    // 0x5a6ce8: mov             x0, x1
    // 0x5a6cec: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x5a6cec: mov             x17, #0xc98a
    //     0x5a6cf0: add             lr, x0, x17
    //     0x5a6cf4: ldr             lr, [x21, lr, lsl #3]
    //     0x5a6cf8: blr             lr
    // 0x5a6cfc: add             SP, SP, #0x10
    // 0x5a6d00: tbnz            w0, #4, #0x5a6d14
    // 0x5a6d04: r0 = Instance_SystemMouseCursor
    //     0x5a6d04: ldr             x0, [PP, #0x3988]  ; [pp+0x3988] Obj!SystemMouseCursor@b489a1
    // 0x5a6d08: LeaveFrame
    //     0x5a6d08: mov             SP, fp
    //     0x5a6d0c: ldp             fp, lr, [SP], #0x10
    // 0x5a6d10: ret
    //     0x5a6d10: ret             
    // 0x5a6d14: ldr             x1, [fp, #0x18]
    // 0x5a6d18: LoadField: r0 = r1->field_7
    //     0x5a6d18: ldur            w0, [x1, #7]
    // 0x5a6d1c: DecompressPointer r0
    //     0x5a6d1c: add             x0, x0, HEAP, lsl #32
    // 0x5a6d20: LeaveFrame
    //     0x5a6d20: mov             SP, fp
    //     0x5a6d24: ldp             fp, lr, [SP], #0x10
    // 0x5a6d28: ret
    //     0x5a6d28: ret             
    // 0x5a6d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a6d2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a6d30: b               #0x5a6cd0
  }
  get _ debugDescription(/* No info */) {
    // ** addr: 0xc0b150, size: 0x64
    // 0xc0b150: EnterFrame
    //     0xc0b150: stp             fp, lr, [SP, #-0x10]!
    //     0xc0b154: mov             fp, SP
    // 0xc0b158: CheckStackOverflow
    //     0xc0b158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc0b15c: cmp             SP, x16
    //     0xc0b160: b.ls            #0xc0b1ac
    // 0xc0b164: r1 = Null
    //     0xc0b164: mov             x1, NULL
    // 0xc0b168: r2 = 6
    //     0xc0b168: mov             x2, #6
    // 0xc0b16c: r0 = AllocateArray()
    //     0xc0b16c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc0b170: r17 = "MaterialStateMouseCursor("
    //     0xc0b170: add             x17, PP, #0x37, lsl #12  ; [pp+0x377c8] "MaterialStateMouseCursor("
    //     0xc0b174: ldr             x17, [x17, #0x7c8]
    // 0xc0b178: StoreField: r0->field_f = r17
    //     0xc0b178: stur            w17, [x0, #0xf]
    // 0xc0b17c: ldr             x1, [fp, #0x10]
    // 0xc0b180: LoadField: r2 = r1->field_f
    //     0xc0b180: ldur            w2, [x1, #0xf]
    // 0xc0b184: DecompressPointer r2
    //     0xc0b184: add             x2, x2, HEAP, lsl #32
    // 0xc0b188: StoreField: r0->field_13 = r2
    //     0xc0b188: stur            w2, [x0, #0x13]
    // 0xc0b18c: r17 = ")"
    //     0xc0b18c: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xc0b190: StoreField: r0->field_17 = r17
    //     0xc0b190: stur            w17, [x0, #0x17]
    // 0xc0b194: SaveReg r0
    //     0xc0b194: str             x0, [SP, #-8]!
    // 0xc0b198: r0 = _interpolate()
    //     0xc0b198: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc0b19c: add             SP, SP, #8
    // 0xc0b1a0: LeaveFrame
    //     0xc0b1a0: mov             SP, fp
    //     0xc0b1a4: ldp             fp, lr, [SP], #0x10
    // 0xc0b1a8: ret
    //     0xc0b1a8: ret             
    // 0xc0b1ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc0b1ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc0b1b0: b               #0xc0b164
  }
}

// class id: 4874, size: 0x2c, field offset: 0x2c
class MaterialStatesController extends ValueNotifier<Set<MaterialState>> {

  _ update(/* No info */) {
    // ** addr: 0x7b0880, size: 0x88
    // 0x7b0880: EnterFrame
    //     0x7b0880: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0884: mov             fp, SP
    // 0x7b0888: CheckStackOverflow
    //     0x7b0888: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b088c: cmp             SP, x16
    //     0x7b0890: b.ls            #0x7b0900
    // 0x7b0894: ldr             x0, [fp, #0x10]
    // 0x7b0898: tbnz            w0, #4, #0x7b08c0
    // 0x7b089c: ldr             x0, [fp, #0x20]
    // 0x7b08a0: LoadField: r1 = r0->field_27
    //     0x7b08a0: ldur            w1, [x0, #0x27]
    // 0x7b08a4: DecompressPointer r1
    //     0x7b08a4: add             x1, x1, HEAP, lsl #32
    // 0x7b08a8: ldr             x16, [fp, #0x18]
    // 0x7b08ac: stp             x16, x1, [SP, #-0x10]!
    // 0x7b08b0: r0 = add()
    //     0x7b08b0: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x7b08b4: add             SP, SP, #0x10
    // 0x7b08b8: tbnz            w0, #4, #0x7b08f0
    // 0x7b08bc: b               #0x7b08e0
    // 0x7b08c0: ldr             x0, [fp, #0x20]
    // 0x7b08c4: LoadField: r1 = r0->field_27
    //     0x7b08c4: ldur            w1, [x0, #0x27]
    // 0x7b08c8: DecompressPointer r1
    //     0x7b08c8: add             x1, x1, HEAP, lsl #32
    // 0x7b08cc: ldr             x16, [fp, #0x18]
    // 0x7b08d0: stp             x16, x1, [SP, #-0x10]!
    // 0x7b08d4: r0 = remove()
    //     0x7b08d4: bl              #0xcbad38  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::remove
    // 0x7b08d8: add             SP, SP, #0x10
    // 0x7b08dc: tbnz            w0, #4, #0x7b08f0
    // 0x7b08e0: ldr             x16, [fp, #0x20]
    // 0x7b08e4: SaveReg r16
    //     0x7b08e4: str             x16, [SP, #-8]!
    // 0x7b08e8: r0 = notifyListeners()
    //     0x7b08e8: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b08ec: add             SP, SP, #8
    // 0x7b08f0: r0 = Null
    //     0x7b08f0: mov             x0, NULL
    // 0x7b08f4: LeaveFrame
    //     0x7b08f4: mov             SP, fp
    //     0x7b08f8: ldp             fp, lr, [SP], #0x10
    // 0x7b08fc: ret
    //     0x7b08fc: ret             
    // 0x7b0900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0904: b               #0x7b0894
  }
  _ MaterialStatesController(/* No info */) {
    // ** addr: 0x7b0a98, size: 0x164
    // 0x7b0a98: EnterFrame
    //     0x7b0a98: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0a9c: mov             fp, SP
    // 0x7b0aa0: AllocStack(0x20)
    //     0x7b0aa0: sub             SP, SP, #0x20
    // 0x7b0aa4: SetupParameters(MaterialStatesController<Set<MaterialState>> this /* r1, fp-0x10 */, [dynamic _ = Null /* r0, fp-0x8 */])
    //     0x7b0aa4: mov             x0, x4
    //     0x7b0aa8: ldur            w1, [x0, #0x13]
    //     0x7b0aac: add             x1, x1, HEAP, lsl #32
    //     0x7b0ab0: sub             x0, x1, #2
    //     0x7b0ab4: add             x1, fp, w0, sxtw #2
    //     0x7b0ab8: ldr             x1, [x1, #0x10]
    //     0x7b0abc: stur            x1, [fp, #-0x10]
    //     0x7b0ac0: cmp             w0, #2
    //     0x7b0ac4: b.lt            #0x7b0ad8
    //     0x7b0ac8: add             x2, fp, w0, sxtw #2
    //     0x7b0acc: ldr             x2, [x2, #8]
    //     0x7b0ad0: mov             x0, x2
    //     0x7b0ad4: b               #0x7b0adc
    //     0x7b0ad8: mov             x0, NULL
    //     0x7b0adc: stur            x0, [fp, #-8]
    // 0x7b0ae0: CheckStackOverflow
    //     0x7b0ae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0ae4: cmp             SP, x16
    //     0x7b0ae8: b.ls            #0x7b0bf4
    // 0x7b0aec: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x7b0aec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b0af0: ldr             x0, [x0, #0x598]
    //     0x7b0af4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b0af8: cmp             w0, w16
    //     0x7b0afc: b.ne            #0x7b0b08
    //     0x7b0b00: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x7b0b04: bl              #0xd67cdc
    // 0x7b0b08: r1 = <MaterialState>
    //     0x7b0b08: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x7b0b0c: ldr             x1, [x1, #0xcf0]
    // 0x7b0b10: stur            x0, [fp, #-0x18]
    // 0x7b0b14: r0 = _Set()
    //     0x7b0b14: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x7b0b18: mov             x1, x0
    // 0x7b0b1c: ldur            x0, [fp, #-0x18]
    // 0x7b0b20: stur            x1, [fp, #-0x20]
    // 0x7b0b24: StoreField: r1->field_1b = r0
    //     0x7b0b24: stur            w0, [x1, #0x1b]
    // 0x7b0b28: StoreField: r1->field_b = rZR
    //     0x7b0b28: stur            wzr, [x1, #0xb]
    // 0x7b0b2c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x7b0b2c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b0b30: ldr             x0, [x0, #0x5a0]
    //     0x7b0b34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b0b38: cmp             w0, w16
    //     0x7b0b3c: b.ne            #0x7b0b48
    //     0x7b0b40: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x7b0b44: bl              #0xd67cdc
    // 0x7b0b48: mov             x1, x0
    // 0x7b0b4c: ldur            x0, [fp, #-0x20]
    // 0x7b0b50: StoreField: r0->field_f = r1
    //     0x7b0b50: stur            w1, [x0, #0xf]
    // 0x7b0b54: StoreField: r0->field_13 = rZR
    //     0x7b0b54: stur            wzr, [x0, #0x13]
    // 0x7b0b58: StoreField: r0->field_17 = rZR
    //     0x7b0b58: stur            wzr, [x0, #0x17]
    // 0x7b0b5c: ldur            x1, [fp, #-8]
    // 0x7b0b60: cmp             w1, NULL
    // 0x7b0b64: b.eq            #0x7b0b74
    // 0x7b0b68: stp             x1, x0, [SP, #-0x10]!
    // 0x7b0b6c: r0 = addAll()
    //     0x7b0b6c: bl              #0xc79cec  ; [dart:collection] _Set::addAll
    // 0x7b0b70: add             SP, SP, #0x10
    // 0x7b0b74: ldur            x1, [fp, #-0x10]
    // 0x7b0b78: r2 = 0
    //     0x7b0b78: mov             x2, #0
    // 0x7b0b7c: ldur            x0, [fp, #-0x20]
    // 0x7b0b80: StoreField: r1->field_27 = r0
    //     0x7b0b80: stur            w0, [x1, #0x27]
    //     0x7b0b84: ldurb           w16, [x1, #-1]
    //     0x7b0b88: ldurb           w17, [x0, #-1]
    //     0x7b0b8c: and             x16, x17, x16, lsr #2
    //     0x7b0b90: tst             x16, HEAP, lsr #32
    //     0x7b0b94: b.eq            #0x7b0b9c
    //     0x7b0b98: bl              #0xd6826c
    // 0x7b0b9c: StoreField: r1->field_7 = r2
    //     0x7b0b9c: stur            x2, [x1, #7]
    // 0x7b0ba0: StoreField: r1->field_13 = r2
    //     0x7b0ba0: stur            x2, [x1, #0x13]
    // 0x7b0ba4: StoreField: r1->field_1b = r2
    //     0x7b0ba4: stur            x2, [x1, #0x1b]
    // 0x7b0ba8: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x7b0ba8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b0bac: ldr             x0, [x0, #0x1580]
    //     0x7b0bb0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b0bb4: cmp             w0, w16
    //     0x7b0bb8: b.ne            #0x7b0bc4
    //     0x7b0bbc: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x7b0bc0: bl              #0xd67cdc
    // 0x7b0bc4: ldur            x1, [fp, #-0x10]
    // 0x7b0bc8: StoreField: r1->field_f = r0
    //     0x7b0bc8: stur            w0, [x1, #0xf]
    //     0x7b0bcc: ldurb           w16, [x1, #-1]
    //     0x7b0bd0: ldurb           w17, [x0, #-1]
    //     0x7b0bd4: and             x16, x17, x16, lsr #2
    //     0x7b0bd8: tst             x16, HEAP, lsr #32
    //     0x7b0bdc: b.eq            #0x7b0be4
    //     0x7b0be0: bl              #0xd6826c
    // 0x7b0be4: r0 = Null
    //     0x7b0be4: mov             x0, NULL
    // 0x7b0be8: LeaveFrame
    //     0x7b0be8: mov             SP, fp
    //     0x7b0bec: ldp             fp, lr, [SP], #0x10
    // 0x7b0bf0: ret
    //     0x7b0bf0: ret             
    // 0x7b0bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0bf8: b               #0x7b0aec
  }
}

// class id: 5058, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class MaterialStateColor extends Color
    implements MaterialStateProperty<X0> {

  static _ resolveWith(/* No info */) {
    // ** addr: 0x85c570, size: 0x48
    // 0x85c570: EnterFrame
    //     0x85c570: stp             fp, lr, [SP, #-0x10]!
    //     0x85c574: mov             fp, SP
    // 0x85c578: AllocStack(0x8)
    //     0x85c578: sub             SP, SP, #8
    // 0x85c57c: CheckStackOverflow
    //     0x85c57c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85c580: cmp             SP, x16
    //     0x85c584: b.ls            #0x85c5b0
    // 0x85c588: r0 = _MaterialStateColor()
    //     0x85c588: bl              #0x85c65c  ; Allocate_MaterialStateColorStub -> _MaterialStateColor (size=0x14)
    // 0x85c58c: stur            x0, [fp, #-8]
    // 0x85c590: ldr             x16, [fp, #0x10]
    // 0x85c594: stp             x16, x0, [SP, #-0x10]!
    // 0x85c598: r0 = _MaterialStateColor()
    //     0x85c598: bl              #0x85c5b8  ; [package:flutter/src/material/material_state.dart] _MaterialStateColor::_MaterialStateColor
    // 0x85c59c: add             SP, SP, #0x10
    // 0x85c5a0: ldur            x0, [fp, #-8]
    // 0x85c5a4: LeaveFrame
    //     0x85c5a4: mov             SP, fp
    //     0x85c5a8: ldp             fp, lr, [SP], #0x10
    // 0x85c5ac: ret
    //     0x85c5ac: ret             
    // 0x85c5b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85c5b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85c5b4: b               #0x85c588
  }
}

// class id: 5059, size: 0x14, field offset: 0x10
class _MaterialStateColor extends MaterialStateColor {

  _ resolve(/* No info */) {
    // ** addr: 0x4ca840, size: 0x50
    // 0x4ca840: EnterFrame
    //     0x4ca840: stp             fp, lr, [SP, #-0x10]!
    //     0x4ca844: mov             fp, SP
    // 0x4ca848: CheckStackOverflow
    //     0x4ca848: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x4ca84c: cmp             SP, x16
    //     0x4ca850: b.ls            #0x4ca888
    // 0x4ca854: ldr             x0, [fp, #0x18]
    // 0x4ca858: LoadField: r1 = r0->field_f
    //     0x4ca858: ldur            w1, [x0, #0xf]
    // 0x4ca85c: DecompressPointer r1
    //     0x4ca85c: add             x1, x1, HEAP, lsl #32
    // 0x4ca860: ldr             x16, [fp, #0x10]
    // 0x4ca864: stp             x16, x1, [SP, #-0x10]!
    // 0x4ca868: mov             x0, x1
    // 0x4ca86c: ClosureCall
    //     0x4ca86c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x4ca870: ldur            x2, [x0, #0x1f]
    //     0x4ca874: blr             x2
    // 0x4ca878: add             SP, SP, #0x10
    // 0x4ca87c: LeaveFrame
    //     0x4ca87c: mov             SP, fp
    //     0x4ca880: ldp             fp, lr, [SP], #0x10
    // 0x4ca884: ret
    //     0x4ca884: ret             
    // 0x4ca888: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x4ca888: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x4ca88c: b               #0x4ca854
  }
  _ _MaterialStateColor(/* No info */) {
    // ** addr: 0x85c5b8, size: 0xa4
    // 0x85c5b8: EnterFrame
    //     0x85c5b8: stp             fp, lr, [SP, #-0x10]!
    //     0x85c5bc: mov             fp, SP
    // 0x85c5c0: CheckStackOverflow
    //     0x85c5c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x85c5c4: cmp             SP, x16
    //     0x85c5c8: b.ls            #0x85c654
    // 0x85c5cc: ldr             x0, [fp, #0x10]
    // 0x85c5d0: ldr             x1, [fp, #0x18]
    // 0x85c5d4: StoreField: r1->field_f = r0
    //     0x85c5d4: stur            w0, [x1, #0xf]
    //     0x85c5d8: ldurb           w16, [x1, #-1]
    //     0x85c5dc: ldurb           w17, [x0, #-1]
    //     0x85c5e0: and             x16, x17, x16, lsr #2
    //     0x85c5e4: tst             x16, HEAP, lsr #32
    //     0x85c5e8: b.eq            #0x85c5f0
    //     0x85c5ec: bl              #0xd6826c
    // 0x85c5f0: ldr             x16, [fp, #0x10]
    // 0x85c5f4: r30 = _ConstSet len:0
    //     0x85c5f4: add             lr, PP, #0xe, lsl #12  ; [pp+0xe178] Set<MaterialState>(0)
    //     0x85c5f8: ldr             lr, [lr, #0x178]
    // 0x85c5fc: stp             lr, x16, [SP, #-0x10]!
    // 0x85c600: ldr             x0, [fp, #0x10]
    // 0x85c604: ClosureCall
    //     0x85c604: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x85c608: ldur            x2, [x0, #0x1f]
    //     0x85c60c: blr             x2
    // 0x85c610: add             SP, SP, #0x10
    // 0x85c614: r1 = LoadClassIdInstr(r0)
    //     0x85c614: ldur            x1, [x0, #-1]
    //     0x85c618: ubfx            x1, x1, #0xc, #0x14
    // 0x85c61c: SaveReg r0
    //     0x85c61c: str             x0, [SP, #-8]!
    // 0x85c620: mov             x0, x1
    // 0x85c624: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x85c624: sub             lr, x0, #0xf7e
    //     0x85c628: ldr             lr, [x21, lr, lsl #3]
    //     0x85c62c: blr             lr
    // 0x85c630: add             SP, SP, #8
    // 0x85c634: ubfx            x0, x0, #0, #0x20
    // 0x85c638: ubfx            x0, x0, #0, #0x20
    // 0x85c63c: ldr             x1, [fp, #0x18]
    // 0x85c640: StoreField: r1->field_7 = r0
    //     0x85c640: stur            x0, [x1, #7]
    // 0x85c644: r0 = Null
    //     0x85c644: mov             x0, NULL
    // 0x85c648: LeaveFrame
    //     0x85c648: mov             SP, fp
    //     0x85c64c: ldp             fp, lr, [SP], #0x10
    // 0x85c650: ret
    //     0x85c650: ret             
    // 0x85c654: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x85c654: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x85c658: b               #0x85c5cc
  }
}

// class id: 5957, size: 0x14, field offset: 0x14
enum MaterialState extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb163bc, size: 0x5c
    // 0xb163bc: EnterFrame
    //     0xb163bc: stp             fp, lr, [SP, #-0x10]!
    //     0xb163c0: mov             fp, SP
    // 0xb163c4: CheckStackOverflow
    //     0xb163c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb163c8: cmp             SP, x16
    //     0xb163cc: b.ls            #0xb16410
    // 0xb163d0: r1 = Null
    //     0xb163d0: mov             x1, NULL
    // 0xb163d4: r2 = 4
    //     0xb163d4: mov             x2, #4
    // 0xb163d8: r0 = AllocateArray()
    //     0xb163d8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb163dc: r17 = "MaterialState."
    //     0xb163dc: add             x17, PP, #0xe, lsl #12  ; [pp+0xe910] "MaterialState."
    //     0xb163e0: ldr             x17, [x17, #0x910]
    // 0xb163e4: StoreField: r0->field_f = r17
    //     0xb163e4: stur            w17, [x0, #0xf]
    // 0xb163e8: ldr             x1, [fp, #0x10]
    // 0xb163ec: LoadField: r2 = r1->field_f
    //     0xb163ec: ldur            w2, [x1, #0xf]
    // 0xb163f0: DecompressPointer r2
    //     0xb163f0: add             x2, x2, HEAP, lsl #32
    // 0xb163f4: StoreField: r0->field_13 = r2
    //     0xb163f4: stur            w2, [x0, #0x13]
    // 0xb163f8: SaveReg r0
    //     0xb163f8: str             x0, [SP, #-8]!
    // 0xb163fc: r0 = _interpolate()
    //     0xb163fc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16400: add             SP, SP, #8
    // 0xb16404: LeaveFrame
    //     0xb16404: mov             SP, fp
    //     0xb16408: ldp             fp, lr, [SP], #0x10
    // 0xb1640c: ret
    //     0xb1640c: ret             
    // 0xb16410: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16410: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16414: b               #0xb163d0
  }
}

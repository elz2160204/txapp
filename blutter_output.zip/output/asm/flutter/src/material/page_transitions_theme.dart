// lib: , url: package:flutter/src/material/page_transitions_theme.dart

// class id: 1049288, size: 0x8
class :: {

  static _ _drawImageScaledAndCentered(/* No info */) {
    // ** addr: 0xcaf588, size: 0x2a4
    // 0xcaf588: EnterFrame
    //     0xcaf588: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf58c: mov             fp, SP
    // 0xcaf590: AllocStack(0x50)
    //     0xcaf590: sub             SP, SP, #0x50
    // 0xcaf594: d0 = 0.000000
    //     0xcaf594: eor             v0.16b, v0.16b, v0.16b
    // 0xcaf598: CheckStackOverflow
    //     0xcaf598: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcaf59c: cmp             SP, x16
    //     0xcaf5a0: b.ls            #0xcaf80c
    // 0xcaf5a4: ldr             x0, [fp, #0x20]
    // 0xcaf5a8: LoadField: d1 = r0->field_7
    //     0xcaf5a8: ldur            d1, [x0, #7]
    // 0xcaf5ac: stur            d1, [fp, #-0x40]
    // 0xcaf5b0: fcmp            d1, d0
    // 0xcaf5b4: b.vs            #0xcaf5bc
    // 0xcaf5b8: b.le            #0xcaf5d4
    // 0xcaf5bc: ldr             x0, [fp, #0x18]
    // 0xcaf5c0: LoadField: d2 = r0->field_7
    //     0xcaf5c0: ldur            d2, [x0, #7]
    // 0xcaf5c4: stur            d2, [fp, #-0x38]
    // 0xcaf5c8: fcmp            d2, d0
    // 0xcaf5cc: b.vs            #0xcaf5e4
    // 0xcaf5d0: b.gt            #0xcaf5e4
    // 0xcaf5d4: r0 = Null
    //     0xcaf5d4: mov             x0, NULL
    // 0xcaf5d8: LeaveFrame
    //     0xcaf5d8: mov             SP, fp
    //     0xcaf5dc: ldp             fp, lr, [SP], #0x10
    // 0xcaf5e0: ret
    //     0xcaf5e0: ret             
    // 0xcaf5e4: ldr             x0, [fp, #0x28]
    // 0xcaf5e8: ldr             d3, [fp, #0x10]
    // 0xcaf5ec: r16 = 112
    //     0xcaf5ec: mov             x16, #0x70
    // 0xcaf5f0: stp             x16, NULL, [SP, #-0x10]!
    // 0xcaf5f4: r0 = ByteData()
    //     0xcaf5f4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xcaf5f8: add             SP, SP, #0x10
    // 0xcaf5fc: stur            x0, [fp, #-8]
    // 0xcaf600: r0 = Paint()
    //     0xcaf600: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xcaf604: mov             x1, x0
    // 0xcaf608: ldur            x0, [fp, #-8]
    // 0xcaf60c: stur            x1, [fp, #-0x18]
    // 0xcaf610: StoreField: r1->field_7 = r0
    //     0xcaf610: stur            w0, [x1, #7]
    // 0xcaf614: LoadField: r2 = r0->field_17
    //     0xcaf614: ldur            w2, [x0, #0x17]
    // 0xcaf618: DecompressPointer r2
    //     0xcaf618: add             x2, x2, HEAP, lsl #32
    // 0xcaf61c: stur            x2, [fp, #-0x10]
    // 0xcaf620: LoadField: r0 = r2->field_7
    //     0xcaf620: ldur            x0, [x2, #7]
    // 0xcaf624: r3 = 1
    //     0xcaf624: mov             x3, #1
    // 0xcaf628: str             w3, [x0, #0x20]
    // 0xcaf62c: ldur            d0, [fp, #-0x38]
    // 0xcaf630: d1 = 255.000000
    //     0xcaf630: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xcaf634: ldr             d1, [x17, #0x200]
    // 0xcaf638: fmul            d2, d0, d1
    // 0xcaf63c: r0 = inline_Allocate_Double()
    //     0xcaf63c: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0xcaf640: add             x0, x0, #0x10
    //     0xcaf644: cmp             x3, x0
    //     0xcaf648: b.ls            #0xcaf814
    //     0xcaf64c: str             x0, [THR, #0x60]  ; THR::top
    //     0xcaf650: sub             x0, x0, #0xf
    //     0xcaf654: mov             x3, #0xd108
    //     0xcaf658: movk            x3, #3, lsl #16
    //     0xcaf65c: stur            x3, [x0, #-1]
    // 0xcaf660: StoreField: r0->field_7 = d2
    //     0xcaf660: stur            d2, [x0, #7]
    // 0xcaf664: r16 = 2
    //     0xcaf664: mov             x16, #2
    // 0xcaf668: stp             x16, x0, [SP, #-0x10]!
    // 0xcaf66c: r0 = ~/()
    //     0xcaf66c: bl              #0x65adc0  ; [dart:core] _Double::~/
    // 0xcaf670: add             SP, SP, #0x10
    // 0xcaf674: r1 = LoadInt32Instr(r0)
    //     0xcaf674: sbfx            x1, x0, #1, #0x1f
    //     0xcaf678: tbz             w0, #0, #0xcaf680
    //     0xcaf67c: ldur            x1, [x0, #7]
    // 0xcaf680: r0 = 255
    //     0xcaf680: mov             x0, #0xff
    // 0xcaf684: and             x2, x1, x0
    // 0xcaf688: lsl             w0, w2, #0x18
    // 0xcaf68c: ubfx            x0, x0, #0, #0x20
    // 0xcaf690: eor             x1, x0, #0xff000000
    // 0xcaf694: sxtw            x1, w1
    // 0xcaf698: ldur            x0, [fp, #-0x10]
    // 0xcaf69c: LoadField: r2 = r0->field_7
    //     0xcaf69c: ldur            x2, [x0, #7]
    // 0xcaf6a0: str             w1, [x2, #4]
    // 0xcaf6a4: ldr             x0, [fp, #0x28]
    // 0xcaf6a8: LoadField: r1 = r0->field_f
    //     0xcaf6a8: ldur            x1, [x0, #0xf]
    // 0xcaf6ac: stur            x1, [fp, #-0x28]
    // 0xcaf6b0: scvtf           d0, x1
    // 0xcaf6b4: ldr             d1, [fp, #0x10]
    // 0xcaf6b8: fdiv            d2, d0, d1
    // 0xcaf6bc: LoadField: r2 = r0->field_17
    //     0xcaf6bc: ldur            x2, [x0, #0x17]
    // 0xcaf6c0: stur            x2, [fp, #-0x20]
    // 0xcaf6c4: scvtf           d0, x2
    // 0xcaf6c8: fdiv            d3, d0, d1
    // 0xcaf6cc: ldur            d0, [fp, #-0x40]
    // 0xcaf6d0: fmul            d1, d2, d0
    // 0xcaf6d4: fmul            d4, d3, d0
    // 0xcaf6d8: fsub            d0, d2, d1
    // 0xcaf6dc: d2 = 2.000000
    //     0xcaf6dc: fmov            d2, #2.00000000
    // 0xcaf6e0: fdiv            d5, d0, d2
    // 0xcaf6e4: stur            d5, [fp, #-0x50]
    // 0xcaf6e8: fsub            d0, d3, d4
    // 0xcaf6ec: fdiv            d3, d0, d2
    // 0xcaf6f0: stur            d3, [fp, #-0x48]
    // 0xcaf6f4: fadd            d0, d5, d1
    // 0xcaf6f8: stur            d0, [fp, #-0x40]
    // 0xcaf6fc: fadd            d1, d3, d4
    // 0xcaf700: stur            d1, [fp, #-0x38]
    // 0xcaf704: r0 = Rect()
    //     0xcaf704: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xcaf708: ldur            d0, [fp, #-0x50]
    // 0xcaf70c: stur            x0, [fp, #-8]
    // 0xcaf710: StoreField: r0->field_7 = d0
    //     0xcaf710: stur            d0, [x0, #7]
    // 0xcaf714: ldur            d0, [fp, #-0x48]
    // 0xcaf718: StoreField: r0->field_f = d0
    //     0xcaf718: stur            d0, [x0, #0xf]
    // 0xcaf71c: ldur            d0, [fp, #-0x40]
    // 0xcaf720: StoreField: r0->field_17 = d0
    //     0xcaf720: stur            d0, [x0, #0x17]
    // 0xcaf724: ldur            d0, [fp, #-0x38]
    // 0xcaf728: StoreField: r0->field_1f = d0
    //     0xcaf728: stur            d0, [x0, #0x1f]
    // 0xcaf72c: ldr             x16, [fp, #0x30]
    // 0xcaf730: SaveReg r16
    //     0xcaf730: str             x16, [SP, #-8]!
    // 0xcaf734: r0 = canvas()
    //     0xcaf734: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xcaf738: add             SP, SP, #8
    // 0xcaf73c: mov             x3, x0
    // 0xcaf740: ldur            x2, [fp, #-0x28]
    // 0xcaf744: stur            x3, [fp, #-0x10]
    // 0xcaf748: r0 = BoxInt64Instr(r2)
    //     0xcaf748: sbfiz           x0, x2, #1, #0x1f
    //     0xcaf74c: cmp             x2, x0, asr #1
    //     0xcaf750: b.eq            #0xcaf75c
    //     0xcaf754: bl              #0xd69bb8
    //     0xcaf758: stur            x2, [x0, #7]
    // 0xcaf75c: stp             x0, NULL, [SP, #-0x10]!
    // 0xcaf760: r0 = _Double.fromInteger()
    //     0xcaf760: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcaf764: add             SP, SP, #0x10
    // 0xcaf768: mov             x3, x0
    // 0xcaf76c: ldur            x2, [fp, #-0x20]
    // 0xcaf770: stur            x3, [fp, #-0x30]
    // 0xcaf774: r0 = BoxInt64Instr(r2)
    //     0xcaf774: sbfiz           x0, x2, #1, #0x1f
    //     0xcaf778: cmp             x2, x0, asr #1
    //     0xcaf77c: b.eq            #0xcaf788
    //     0xcaf780: bl              #0xd69bb8
    //     0xcaf784: stur            x2, [x0, #7]
    // 0xcaf788: stp             x0, NULL, [SP, #-0x10]!
    // 0xcaf78c: r0 = _Double.fromInteger()
    //     0xcaf78c: bl              #0x4f0614  ; [dart:core] _Double::_Double.fromInteger
    // 0xcaf790: add             SP, SP, #0x10
    // 0xcaf794: mov             x1, x0
    // 0xcaf798: ldur            x0, [fp, #-0x30]
    // 0xcaf79c: LoadField: d0 = r0->field_7
    //     0xcaf79c: ldur            d0, [x0, #7]
    // 0xcaf7a0: d1 = 0.000000
    //     0xcaf7a0: eor             v1.16b, v1.16b, v1.16b
    // 0xcaf7a4: fadd            d2, d1, d0
    // 0xcaf7a8: stur            d2, [fp, #-0x40]
    // 0xcaf7ac: LoadField: d0 = r1->field_7
    //     0xcaf7ac: ldur            d0, [x1, #7]
    // 0xcaf7b0: fadd            d3, d1, d0
    // 0xcaf7b4: stur            d3, [fp, #-0x38]
    // 0xcaf7b8: r0 = Rect()
    //     0xcaf7b8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xcaf7bc: d0 = 0.000000
    //     0xcaf7bc: eor             v0.16b, v0.16b, v0.16b
    // 0xcaf7c0: StoreField: r0->field_7 = d0
    //     0xcaf7c0: stur            d0, [x0, #7]
    // 0xcaf7c4: StoreField: r0->field_f = d0
    //     0xcaf7c4: stur            d0, [x0, #0xf]
    // 0xcaf7c8: ldur            d0, [fp, #-0x40]
    // 0xcaf7cc: StoreField: r0->field_17 = d0
    //     0xcaf7cc: stur            d0, [x0, #0x17]
    // 0xcaf7d0: ldur            d0, [fp, #-0x38]
    // 0xcaf7d4: StoreField: r0->field_1f = d0
    //     0xcaf7d4: stur            d0, [x0, #0x1f]
    // 0xcaf7d8: ldur            x16, [fp, #-0x10]
    // 0xcaf7dc: ldr             lr, [fp, #0x28]
    // 0xcaf7e0: stp             lr, x16, [SP, #-0x10]!
    // 0xcaf7e4: ldur            x16, [fp, #-8]
    // 0xcaf7e8: stp             x16, x0, [SP, #-0x10]!
    // 0xcaf7ec: ldur            x16, [fp, #-0x18]
    // 0xcaf7f0: SaveReg r16
    //     0xcaf7f0: str             x16, [SP, #-8]!
    // 0xcaf7f4: r0 = drawImageRect()
    //     0xcaf7f4: bl              #0x655a70  ; [dart:ui] Canvas::drawImageRect
    // 0xcaf7f8: add             SP, SP, #0x28
    // 0xcaf7fc: r0 = Null
    //     0xcaf7fc: mov             x0, NULL
    // 0xcaf800: LeaveFrame
    //     0xcaf800: mov             SP, fp
    //     0xcaf804: ldp             fp, lr, [SP], #0x10
    // 0xcaf808: ret
    //     0xcaf808: ret             
    // 0xcaf80c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcaf80c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcaf810: b               #0xcaf5a4
    // 0xcaf814: SaveReg d2
    //     0xcaf814: str             q2, [SP, #-0x10]!
    // 0xcaf818: stp             x1, x2, [SP, #-0x10]!
    // 0xcaf81c: r0 = AllocateDouble()
    //     0xcaf81c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcaf820: ldp             x1, x2, [SP], #0x10
    // 0xcaf824: RestoreReg d2
    //     0xcaf824: ldr             q2, [SP], #0x10
    // 0xcaf828: b               #0xcaf660
  }
  static _ _updateScaledTransform(/* No info */) {
    // ** addr: 0xcb02ec, size: 0x140
    // 0xcb02ec: EnterFrame
    //     0xcb02ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcb02f0: mov             fp, SP
    // 0xcb02f4: CheckStackOverflow
    //     0xcb02f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb02f8: cmp             SP, x16
    //     0xcb02fc: b.ls            #0xcb03f8
    // 0xcb0300: ldr             x16, [fp, #0x20]
    // 0xcb0304: SaveReg r16
    //     0xcb0304: str             x16, [SP, #-8]!
    // 0xcb0308: r0 = setIdentity()
    //     0xcb0308: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xcb030c: add             SP, SP, #8
    // 0xcb0310: ldr             d1, [fp, #0x18]
    // 0xcb0314: d0 = 1.000000
    //     0xcb0314: fmov            d0, #1.00000000
    // 0xcb0318: fcmp            d1, d0
    // 0xcb031c: b.vs            #0xcb0334
    // 0xcb0320: b.ne            #0xcb0334
    // 0xcb0324: r0 = Null
    //     0xcb0324: mov             x0, NULL
    // 0xcb0328: LeaveFrame
    //     0xcb0328: mov             SP, fp
    //     0xcb032c: ldp             fp, lr, [SP], #0x10
    // 0xcb0330: ret
    //     0xcb0330: ret             
    // 0xcb0334: ldr             x0, [fp, #0x10]
    // 0xcb0338: r1 = inline_Allocate_Double()
    //     0xcb0338: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xcb033c: add             x1, x1, #0x10
    //     0xcb0340: cmp             x2, x1
    //     0xcb0344: b.ls            #0xcb0400
    //     0xcb0348: str             x1, [THR, #0x60]  ; THR::top
    //     0xcb034c: sub             x1, x1, #0xf
    //     0xcb0350: mov             x2, #0xd108
    //     0xcb0354: movk            x2, #3, lsl #16
    //     0xcb0358: stur            x2, [x1, #-1]
    // 0xcb035c: StoreField: r1->field_7 = d1
    //     0xcb035c: stur            d1, [x1, #7]
    // 0xcb0360: ldr             x16, [fp, #0x20]
    // 0xcb0364: stp             x1, x16, [SP, #-0x10]!
    // 0xcb0368: SaveReg r1
    //     0xcb0368: str             x1, [SP, #-8]!
    // 0xcb036c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xcb036c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xcb0370: r0 = scale()
    //     0xcb0370: bl              #0x50b298  ; [package:vector_math/vector_math_64.dart] Matrix4::scale
    // 0xcb0374: add             SP, SP, #0x18
    // 0xcb0378: ldr             x0, [fp, #0x10]
    // 0xcb037c: LoadField: d0 = r0->field_7
    //     0xcb037c: ldur            d0, [x0, #7]
    // 0xcb0380: ldr             d1, [fp, #0x18]
    // 0xcb0384: fmul            d2, d0, d1
    // 0xcb0388: fsub            d3, d2, d0
    // 0xcb038c: d0 = 2.000000
    //     0xcb038c: fmov            d0, #2.00000000
    // 0xcb0390: fdiv            d2, d3, d0
    // 0xcb0394: LoadField: d3 = r0->field_f
    //     0xcb0394: ldur            d3, [x0, #0xf]
    // 0xcb0398: fmul            d4, d3, d1
    // 0xcb039c: fsub            d1, d4, d3
    // 0xcb03a0: fdiv            d3, d1, d0
    // 0xcb03a4: fneg            d0, d2
    // 0xcb03a8: fneg            d1, d3
    // 0xcb03ac: r0 = inline_Allocate_Double()
    //     0xcb03ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcb03b0: add             x0, x0, #0x10
    //     0xcb03b4: cmp             x1, x0
    //     0xcb03b8: b.ls            #0xcb041c
    //     0xcb03bc: str             x0, [THR, #0x60]  ; THR::top
    //     0xcb03c0: sub             x0, x0, #0xf
    //     0xcb03c4: mov             x1, #0xd108
    //     0xcb03c8: movk            x1, #3, lsl #16
    //     0xcb03cc: stur            x1, [x0, #-1]
    // 0xcb03d0: StoreField: r0->field_7 = d0
    //     0xcb03d0: stur            d0, [x0, #7]
    // 0xcb03d4: ldr             x16, [fp, #0x20]
    // 0xcb03d8: stp             x0, x16, [SP, #-0x10]!
    // 0xcb03dc: SaveReg d1
    //     0xcb03dc: str             d1, [SP, #-8]!
    // 0xcb03e0: r0 = translate()
    //     0xcb03e0: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0xcb03e4: add             SP, SP, #0x18
    // 0xcb03e8: r0 = Null
    //     0xcb03e8: mov             x0, NULL
    // 0xcb03ec: LeaveFrame
    //     0xcb03ec: mov             SP, fp
    //     0xcb03f0: ldp             fp, lr, [SP], #0x10
    // 0xcb03f4: ret
    //     0xcb03f4: ret             
    // 0xcb03f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb03f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb03fc: b               #0xcb0300
    // 0xcb0400: SaveReg d1
    //     0xcb0400: str             q1, [SP, #-0x10]!
    // 0xcb0404: SaveReg r0
    //     0xcb0404: str             x0, [SP, #-8]!
    // 0xcb0408: r0 = AllocateDouble()
    //     0xcb0408: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb040c: mov             x1, x0
    // 0xcb0410: RestoreReg r0
    //     0xcb0410: ldr             x0, [SP], #8
    // 0xcb0414: RestoreReg d1
    //     0xcb0414: ldr             q1, [SP], #0x10
    // 0xcb0418: b               #0xcb035c
    // 0xcb041c: stp             q0, q1, [SP, #-0x20]!
    // 0xcb0420: r0 = AllocateDouble()
    //     0xcb0420: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcb0424: ldp             q0, q1, [SP], #0x20
    // 0xcb0428: b               #0xcb03d0
  }
}

// class id: 2156, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class PageTransitionsBuilder extends Object {
}

// class id: 2157, size: 0x8, field offset: 0x8
//   const constructor, 
class CupertinoPageTransitionsBuilder extends PageTransitionsBuilder {

  _ buildTransitions(/* No info */) {
    // ** addr: 0xcf4de0, size: 0x78
    // 0xcf4de0: EnterFrame
    //     0xcf4de0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4de4: mov             fp, SP
    // 0xcf4de8: mov             x0, x4
    // 0xcf4dec: LoadField: r1 = r0->field_f
    //     0xcf4dec: ldur            w1, [x0, #0xf]
    // 0xcf4df0: DecompressPointer r1
    //     0xcf4df0: add             x1, x1, HEAP, lsl #32
    // 0xcf4df4: cbnz            w1, #0xcf4e00
    // 0xcf4df8: r0 = Null
    //     0xcf4df8: mov             x0, NULL
    // 0xcf4dfc: b               #0xcf4e10
    // 0xcf4e00: LoadField: r1 = r0->field_17
    //     0xcf4e00: ldur            w1, [x0, #0x17]
    // 0xcf4e04: DecompressPointer r1
    //     0xcf4e04: add             x1, x1, HEAP, lsl #32
    // 0xcf4e08: add             x0, fp, w1, sxtw #2
    // 0xcf4e0c: ldr             x0, [x0, #0x10]
    // 0xcf4e10: CheckStackOverflow
    //     0xcf4e10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf4e14: cmp             SP, x16
    //     0xcf4e18: b.ls            #0xcf4e50
    // 0xcf4e1c: ldr             x16, [fp, #0x28]
    // 0xcf4e20: stp             x16, x0, [SP, #-0x10]!
    // 0xcf4e24: ldr             x16, [fp, #0x20]
    // 0xcf4e28: ldr             lr, [fp, #0x18]
    // 0xcf4e2c: stp             lr, x16, [SP, #-0x10]!
    // 0xcf4e30: ldr             x16, [fp, #0x10]
    // 0xcf4e34: SaveReg r16
    //     0xcf4e34: str             x16, [SP, #-8]!
    // 0xcf4e38: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xcf4e38: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xcf4e3c: r0 = buildPageTransitions()
    //     0xcf4e3c: bl              #0xcf4e58  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::buildPageTransitions
    // 0xcf4e40: add             SP, SP, #0x28
    // 0xcf4e44: LeaveFrame
    //     0xcf4e44: mov             SP, fp
    //     0xcf4e48: ldp             fp, lr, [SP], #0x10
    // 0xcf4e4c: ret
    //     0xcf4e4c: ret             
    // 0xcf4e50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4e50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4e54: b               #0xcf4e1c
  }
}

// class id: 2158, size: 0x8, field offset: 0x8
//   const constructor, 
class ZoomPageTransitionsBuilder extends PageTransitionsBuilder {

  _ buildTransitions(/* No info */) {
    // ** addr: 0xcf4da8, size: 0x38
    // 0xcf4da8: EnterFrame
    //     0xcf4da8: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4dac: mov             fp, SP
    // 0xcf4db0: r0 = _ZoomPageTransition()
    //     0xcf4db0: bl              #0xa8a4b4  ; Allocate_ZoomPageTransitionStub -> _ZoomPageTransition (size=0x1c)
    // 0xcf4db4: ldr             x1, [fp, #0x20]
    // 0xcf4db8: StoreField: r0->field_b = r1
    //     0xcf4db8: stur            w1, [x0, #0xb]
    // 0xcf4dbc: ldr             x1, [fp, #0x18]
    // 0xcf4dc0: StoreField: r0->field_f = r1
    //     0xcf4dc0: stur            w1, [x0, #0xf]
    // 0xcf4dc4: r1 = true
    //     0xcf4dc4: add             x1, NULL, #0x20  ; true
    // 0xcf4dc8: StoreField: r0->field_13 = r1
    //     0xcf4dc8: stur            w1, [x0, #0x13]
    // 0xcf4dcc: ldr             x1, [fp, #0x10]
    // 0xcf4dd0: StoreField: r0->field_17 = r1
    //     0xcf4dd0: stur            w1, [x0, #0x17]
    // 0xcf4dd4: LeaveFrame
    //     0xcf4dd4: mov             SP, fp
    //     0xcf4dd8: ldp             fp, lr, [SP], #0x10
    // 0xcf4ddc: ret
    //     0xcf4ddc: ret             
  }
}

// class id: 2159, size: 0x8, field offset: 0x8
//   const constructor, 
class FadeUpwardsPageTransitionsBuilder extends PageTransitionsBuilder {
}

// class id: 2160, size: 0x8, field offset: 0x8
abstract class _ZoomTransitionBase extends Object {
}

// class id: 2778, size: 0xc, field offset: 0x8
//   const constructor, 
class PageTransitionsTheme extends _DiagnosticableTree&Object&Diagnosticable {

  _ConstMap<TargetPlatform, PageTransitionsBuilder> field_8;

  _ buildTransitions(/* No info */) {
    // ** addr: 0xa88c84, size: 0xf8
    // 0xa88c84: EnterFrame
    //     0xa88c84: stp             fp, lr, [SP, #-0x10]!
    //     0xa88c88: mov             fp, SP
    // 0xa88c8c: AllocStack(0x10)
    //     0xa88c8c: sub             SP, SP, #0x10
    // 0xa88c90: SetupParameters()
    //     0xa88c90: mov             x0, x4
    //     0xa88c94: ldur            w1, [x0, #0xf]
    //     0xa88c98: add             x1, x1, HEAP, lsl #32
    //     0xa88c9c: cbnz            w1, #0xa88ca8
    //     0xa88ca0: mov             x0, NULL
    //     0xa88ca4: b               #0xa88cb8
    //     0xa88ca8: ldur            w1, [x0, #0x17]
    //     0xa88cac: add             x1, x1, HEAP, lsl #32
    //     0xa88cb0: add             x0, fp, w1, sxtw #2
    //     0xa88cb4: ldr             x0, [x0, #0x10]
    //     0xa88cb8: stur            x0, [fp, #-8]
    // 0xa88cbc: CheckStackOverflow
    //     0xa88cbc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa88cc0: cmp             SP, x16
    //     0xa88cc4: b.ls            #0xa88d74
    // 0xa88cc8: ldr             x16, [fp, #0x28]
    // 0xa88ccc: SaveReg r16
    //     0xa88ccc: str             x16, [SP, #-8]!
    // 0xa88cd0: r0 = of()
    //     0xa88cd0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xa88cd4: add             SP, SP, #8
    // 0xa88cd8: LoadField: r1 = r0->field_1f
    //     0xa88cd8: ldur            w1, [x0, #0x1f]
    // 0xa88cdc: DecompressPointer r1
    //     0xa88cdc: add             x1, x1, HEAP, lsl #32
    // 0xa88ce0: stur            x1, [fp, #-0x10]
    // 0xa88ce4: ldr             x16, [fp, #0x30]
    // 0xa88ce8: SaveReg r16
    //     0xa88ce8: str             x16, [SP, #-8]!
    // 0xa88cec: r0 = isPopGestureInProgress()
    //     0xa88cec: bl              #0xa88d7c  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::isPopGestureInProgress
    // 0xa88cf0: add             SP, SP, #8
    // 0xa88cf4: tbnz            w0, #4, #0xa88d00
    // 0xa88cf8: r0 = Instance_TargetPlatform
    //     0xa88cf8: ldr             x0, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0xa88cfc: b               #0xa88d04
    // 0xa88d00: ldur            x0, [fp, #-0x10]
    // 0xa88d04: r16 = _ConstMap len:3
    //     0xa88d04: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1b8] Map<TargetPlatform, PageTransitionsBuilder>(3)
    //     0xa88d08: ldr             x16, [x16, #0x1b8]
    // 0xa88d0c: stp             x0, x16, [SP, #-0x10]!
    // 0xa88d10: r0 = []()
    //     0xa88d10: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xa88d14: add             SP, SP, #0x10
    // 0xa88d18: cmp             w0, NULL
    // 0xa88d1c: b.ne            #0xa88d28
    // 0xa88d20: r0 = Instance_ZoomPageTransitionsBuilder
    //     0xa88d20: add             x0, PP, #0x2a, lsl #12  ; [pp+0x2aa80] Obj!ZoomPageTransitionsBuilder@b37c71
    //     0xa88d24: ldr             x0, [x0, #0xa80]
    // 0xa88d28: r1 = LoadClassIdInstr(r0)
    //     0xa88d28: ldur            x1, [x0, #-1]
    //     0xa88d2c: ubfx            x1, x1, #0xc, #0x14
    // 0xa88d30: ldur            x16, [fp, #-8]
    // 0xa88d34: stp             x0, x16, [SP, #-0x10]!
    // 0xa88d38: ldr             x16, [fp, #0x30]
    // 0xa88d3c: ldr             lr, [fp, #0x20]
    // 0xa88d40: stp             lr, x16, [SP, #-0x10]!
    // 0xa88d44: ldr             x16, [fp, #0x18]
    // 0xa88d48: ldr             lr, [fp, #0x10]
    // 0xa88d4c: stp             lr, x16, [SP, #-0x10]!
    // 0xa88d50: mov             x0, x1
    // 0xa88d54: r4 = const [0x1, 0x5, 0x5, 0x5, null]
    //     0xa88d54: ldr             x4, [PP, #0x5120]  ; [pp+0x5120] List(5) [0x1, 0x5, 0x5, 0x5, Null]
    // 0xa88d58: r0 = GDT[cid_x0 + -0xf0b]()
    //     0xa88d58: sub             lr, x0, #0xf0b
    //     0xa88d5c: ldr             lr, [x21, lr, lsl #3]
    //     0xa88d60: blr             lr
    // 0xa88d64: add             SP, SP, #0x30
    // 0xa88d68: LeaveFrame
    //     0xa88d68: mov             SP, fp
    //     0xa88d6c: ldp             fp, lr, [SP], #0x10
    // 0xa88d70: ret
    //     0xa88d70: ret             
    // 0xa88d74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa88d74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa88d78: b               #0xa88cc8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xb00c2c, size: 0x5c
    // 0xb00c2c: EnterFrame
    //     0xb00c2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb00c30: mov             fp, SP
    // 0xb00c34: CheckStackOverflow
    //     0xb00c34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00c38: cmp             SP, x16
    //     0xb00c3c: b.ls            #0xb00c80
    // 0xb00c40: ldr             x16, [fp, #0x10]
    // 0xb00c44: SaveReg r16
    //     0xb00c44: str             x16, [SP, #-8]!
    // 0xb00c48: r0 = _all()
    //     0xb00c48: bl              #0xb00c88  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all
    // 0xb00c4c: add             SP, SP, #8
    // 0xb00c50: SaveReg r0
    //     0xb00c50: str             x0, [SP, #-8]!
    // 0xb00c54: r0 = hashAll()
    //     0xb00c54: bl              #0x707e08  ; [dart:core] Object::hashAll
    // 0xb00c58: add             SP, SP, #8
    // 0xb00c5c: mov             x2, x0
    // 0xb00c60: r0 = BoxInt64Instr(r2)
    //     0xb00c60: sbfiz           x0, x2, #1, #0x1f
    //     0xb00c64: cmp             x2, x0, asr #1
    //     0xb00c68: b.eq            #0xb00c74
    //     0xb00c6c: bl              #0xd69bb8
    //     0xb00c70: stur            x2, [x0, #7]
    // 0xb00c74: LeaveFrame
    //     0xb00c74: mov             SP, fp
    //     0xb00c78: ldp             fp, lr, [SP], #0x10
    // 0xb00c7c: ret
    //     0xb00c7c: ret             
    // 0xb00c80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00c80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00c84: b               #0xb00c40
  }
  _ _all(/* No info */) {
    // ** addr: 0xb00c88, size: 0x6c
    // 0xb00c88: EnterFrame
    //     0xb00c88: stp             fp, lr, [SP, #-0x10]!
    //     0xb00c8c: mov             fp, SP
    // 0xb00c90: CheckStackOverflow
    //     0xb00c90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00c94: cmp             SP, x16
    //     0xb00c98: b.ls            #0xb00cec
    // 0xb00c9c: r1 = Function '<anonymous closure>':.
    //     0xb00c9c: add             x1, PP, #0xe, lsl #12  ; [pp+0xe1a0] AnonymousClosure: (0xb00cf4), in [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all (0xb00c88)
    //     0xb00ca0: ldr             x1, [x1, #0x1a0]
    // 0xb00ca4: r2 = Null
    //     0xb00ca4: mov             x2, NULL
    // 0xb00ca8: r0 = AllocateClosure()
    //     0xb00ca8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb00cac: r16 = <PageTransitionsBuilder?>
    //     0xb00cac: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1a8] TypeArguments: <PageTransitionsBuilder?>
    //     0xb00cb0: ldr             x16, [x16, #0x1a8]
    // 0xb00cb4: r30 = const [Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform', Instance of 'TargetPlatform']
    //     0xb00cb4: add             lr, PP, #0xe, lsl #12  ; [pp+0xe1b0] List<TargetPlatform>(6)
    //     0xb00cb8: ldr             lr, [lr, #0x1b0]
    // 0xb00cbc: stp             lr, x16, [SP, #-0x10]!
    // 0xb00cc0: SaveReg r0
    //     0xb00cc0: str             x0, [SP, #-8]!
    // 0xb00cc4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xb00cc4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xb00cc8: r0 = map()
    //     0xb00cc8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xb00ccc: add             SP, SP, #0x18
    // 0xb00cd0: SaveReg r0
    //     0xb00cd0: str             x0, [SP, #-8]!
    // 0xb00cd4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xb00cd4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xb00cd8: r0 = toList()
    //     0xb00cd8: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xb00cdc: add             SP, SP, #8
    // 0xb00ce0: LeaveFrame
    //     0xb00ce0: mov             SP, fp
    //     0xb00ce4: ldp             fp, lr, [SP], #0x10
    // 0xb00ce8: ret
    //     0xb00ce8: ret             
    // 0xb00cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00cec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00cf0: b               #0xb00c9c
  }
  [closure] PageTransitionsBuilder? <anonymous closure>(dynamic, TargetPlatform) {
    // ** addr: 0xb00cf4, size: 0x40
    // 0xb00cf4: EnterFrame
    //     0xb00cf4: stp             fp, lr, [SP, #-0x10]!
    //     0xb00cf8: mov             fp, SP
    // 0xb00cfc: CheckStackOverflow
    //     0xb00cfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00d00: cmp             SP, x16
    //     0xb00d04: b.ls            #0xb00d2c
    // 0xb00d08: r16 = _ConstMap len:3
    //     0xb00d08: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1b8] Map<TargetPlatform, PageTransitionsBuilder>(3)
    //     0xb00d0c: ldr             x16, [x16, #0x1b8]
    // 0xb00d10: ldr             lr, [fp, #0x10]
    // 0xb00d14: stp             lr, x16, [SP, #-0x10]!
    // 0xb00d18: r0 = []()
    //     0xb00d18: bl              #0xccc83c  ; [dart:collection] __ConstMap&_HashVMImmutableBase&MapMixin&_HashBase&_OperatorEqualsAndCanonicalHashCode&_LinkedHashMapMixin&_UnmodifiableMapMixin&_ImmutableLinkedHashMapMixin::[]
    // 0xb00d1c: add             SP, SP, #0x10
    // 0xb00d20: LeaveFrame
    //     0xb00d20: mov             SP, fp
    //     0xb00d24: ldp             fp, lr, [SP], #0x10
    // 0xb00d28: ret
    //     0xb00d28: ret             
    // 0xb00d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00d2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00d30: b               #0xb00d08
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8c608, size: 0x154
    // 0xc8c608: EnterFrame
    //     0xc8c608: stp             fp, lr, [SP, #-0x10]!
    //     0xc8c60c: mov             fp, SP
    // 0xc8c610: AllocStack(0x8)
    //     0xc8c610: sub             SP, SP, #8
    // 0xc8c614: CheckStackOverflow
    //     0xc8c614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8c618: cmp             SP, x16
    //     0xc8c61c: b.ls            #0xc8c754
    // 0xc8c620: ldr             x1, [fp, #0x10]
    // 0xc8c624: cmp             w1, NULL
    // 0xc8c628: b.ne            #0xc8c63c
    // 0xc8c62c: r0 = false
    //     0xc8c62c: add             x0, NULL, #0x30  ; false
    // 0xc8c630: LeaveFrame
    //     0xc8c630: mov             SP, fp
    //     0xc8c634: ldp             fp, lr, [SP], #0x10
    // 0xc8c638: ret
    //     0xc8c638: ret             
    // 0xc8c63c: ldr             x2, [fp, #0x18]
    // 0xc8c640: cmp             w2, w1
    // 0xc8c644: b.ne            #0xc8c658
    // 0xc8c648: r0 = true
    //     0xc8c648: add             x0, NULL, #0x20  ; true
    // 0xc8c64c: LeaveFrame
    //     0xc8c64c: mov             SP, fp
    //     0xc8c650: ldp             fp, lr, [SP], #0x10
    // 0xc8c654: ret
    //     0xc8c654: ret             
    // 0xc8c658: r0 = 59
    //     0xc8c658: mov             x0, #0x3b
    // 0xc8c65c: branchIfSmi(r1, 0xc8c668)
    //     0xc8c65c: tbz             w1, #0, #0xc8c668
    // 0xc8c660: r0 = LoadClassIdInstr(r1)
    //     0xc8c660: ldur            x0, [x1, #-1]
    //     0xc8c664: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c668: SaveReg r1
    //     0xc8c668: str             x1, [SP, #-8]!
    // 0xc8c66c: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8c66c: mov             x17, #0x57c5
    //     0xc8c670: add             lr, x0, x17
    //     0xc8c674: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c678: blr             lr
    // 0xc8c67c: add             SP, SP, #8
    // 0xc8c680: r1 = LoadClassIdInstr(r0)
    //     0xc8c680: ldur            x1, [x0, #-1]
    //     0xc8c684: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c688: r16 = PageTransitionsTheme
    //     0xc8c688: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1c0] Type: PageTransitionsTheme
    //     0xc8c68c: ldr             x16, [x16, #0x1c0]
    // 0xc8c690: stp             x16, x0, [SP, #-0x10]!
    // 0xc8c694: mov             x0, x1
    // 0xc8c698: mov             lr, x0
    // 0xc8c69c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c6a0: blr             lr
    // 0xc8c6a4: add             SP, SP, #0x10
    // 0xc8c6a8: tbz             w0, #4, #0xc8c6bc
    // 0xc8c6ac: r0 = false
    //     0xc8c6ac: add             x0, NULL, #0x30  ; false
    // 0xc8c6b0: LeaveFrame
    //     0xc8c6b0: mov             SP, fp
    //     0xc8c6b4: ldp             fp, lr, [SP], #0x10
    // 0xc8c6b8: ret
    //     0xc8c6b8: ret             
    // 0xc8c6bc: ldr             x0, [fp, #0x10]
    // 0xc8c6c0: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8c6c0: mov             x1, #0x76
    //     0xc8c6c4: tbz             w0, #0, #0xc8c6d4
    //     0xc8c6c8: ldur            x1, [x0, #-1]
    //     0xc8c6cc: ubfx            x1, x1, #0xc, #0x14
    //     0xc8c6d0: lsl             x1, x1, #1
    // 0xc8c6d4: r17 = 5556
    //     0xc8c6d4: mov             x17, #0x15b4
    // 0xc8c6d8: cmp             w1, w17
    // 0xc8c6dc: b.ne            #0xc8c6f0
    // 0xc8c6e0: r0 = true
    //     0xc8c6e0: add             x0, NULL, #0x20  ; true
    // 0xc8c6e4: LeaveFrame
    //     0xc8c6e4: mov             SP, fp
    //     0xc8c6e8: ldp             fp, lr, [SP], #0x10
    // 0xc8c6ec: ret
    //     0xc8c6ec: ret             
    // 0xc8c6f0: r17 = 5556
    //     0xc8c6f0: mov             x17, #0x15b4
    // 0xc8c6f4: cmp             w1, w17
    // 0xc8c6f8: b.ne            #0xc8c744
    // 0xc8c6fc: ldr             x16, [fp, #0x18]
    // 0xc8c700: SaveReg r16
    //     0xc8c700: str             x16, [SP, #-8]!
    // 0xc8c704: r0 = _all()
    //     0xc8c704: bl              #0xb00c88  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all
    // 0xc8c708: add             SP, SP, #8
    // 0xc8c70c: stur            x0, [fp, #-8]
    // 0xc8c710: ldr             x16, [fp, #0x18]
    // 0xc8c714: SaveReg r16
    //     0xc8c714: str             x16, [SP, #-8]!
    // 0xc8c718: r0 = _all()
    //     0xc8c718: bl              #0xb00c88  ; [package:flutter/src/material/page_transitions_theme.dart] PageTransitionsTheme::_all
    // 0xc8c71c: add             SP, SP, #8
    // 0xc8c720: r16 = <PageTransitionsBuilder?>
    //     0xc8c720: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1a8] TypeArguments: <PageTransitionsBuilder?>
    //     0xc8c724: ldr             x16, [x16, #0x1a8]
    // 0xc8c728: ldur            lr, [fp, #-8]
    // 0xc8c72c: stp             lr, x16, [SP, #-0x10]!
    // 0xc8c730: SaveReg r0
    //     0xc8c730: str             x0, [SP, #-8]!
    // 0xc8c734: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc8c734: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc8c738: r0 = listEquals()
    //     0xc8c738: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0xc8c73c: add             SP, SP, #0x18
    // 0xc8c740: b               #0xc8c748
    // 0xc8c744: r0 = false
    //     0xc8c744: add             x0, NULL, #0x30  ; false
    // 0xc8c748: LeaveFrame
    //     0xc8c748: mov             SP, fp
    //     0xc8c74c: ldp             fp, lr, [SP], #0x10
    // 0xc8c750: ret
    //     0xc8c750: ret             
    // 0xc8c754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8c754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8c758: b               #0xc8c620
  }
}

// class id: 3291, size: 0x20, field offset: 0x14
//   transformed mixin,
abstract class __ZoomExitTransitionState&State&_ZoomTransitionBase extends State<_ZoomExitTransition>
     with _ZoomTransitionBase {

  late Animation<double> scaleTransition; // offset: 0x1c
  late Animation<double> fadeTransition; // offset: 0x18

  [closure] void onAnimationStatusChange(dynamic, AnimationStatus) {
    // ** addr: 0x7b8a8c, size: 0x4c
    // 0x7b8a8c: EnterFrame
    //     0x7b8a8c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8a90: mov             fp, SP
    // 0x7b8a94: ldr             x0, [fp, #0x18]
    // 0x7b8a98: LoadField: r1 = r0->field_17
    //     0x7b8a98: ldur            w1, [x0, #0x17]
    // 0x7b8a9c: DecompressPointer r1
    //     0x7b8a9c: add             x1, x1, HEAP, lsl #32
    // 0x7b8aa0: CheckStackOverflow
    //     0x7b8aa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8aa4: cmp             SP, x16
    //     0x7b8aa8: b.ls            #0x7b8ad0
    // 0x7b8aac: LoadField: r0 = r1->field_f
    //     0x7b8aac: ldur            w0, [x1, #0xf]
    // 0x7b8ab0: DecompressPointer r0
    //     0x7b8ab0: add             x0, x0, HEAP, lsl #32
    // 0x7b8ab4: ldr             x16, [fp, #0x10]
    // 0x7b8ab8: stp             x16, x0, [SP, #-0x10]!
    // 0x7b8abc: r0 = onAnimationStatusChange()
    //     0x7b8abc: bl              #0x7b8ad8  ; [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange
    // 0x7b8ac0: add             SP, SP, #0x10
    // 0x7b8ac4: LeaveFrame
    //     0x7b8ac4: mov             SP, fp
    //     0x7b8ac8: ldp             fp, lr, [SP], #0x10
    // 0x7b8acc: ret
    //     0x7b8acc: ret             
    // 0x7b8ad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8ad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8ad4: b               #0x7b8aac
  }
  _ onAnimationStatusChange(/* No info */) {
    // ** addr: 0x7b8ad8, size: 0xa4
    // 0x7b8ad8: EnterFrame
    //     0x7b8ad8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8adc: mov             fp, SP
    // 0x7b8ae0: CheckStackOverflow
    //     0x7b8ae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8ae4: cmp             SP, x16
    //     0x7b8ae8: b.ls            #0x7b8b70
    // 0x7b8aec: ldr             x0, [fp, #0x10]
    // 0x7b8af0: LoadField: r1 = r0->field_7
    //     0x7b8af0: ldur            x1, [x0, #7]
    // 0x7b8af4: cmp             x1, #1
    // 0x7b8af8: b.gt            #0x7b8b0c
    // 0x7b8afc: cmp             x1, #0
    // 0x7b8b00: b.gt            #0x7b8b14
    // 0x7b8b04: ldr             x0, [fp, #0x18]
    // 0x7b8b08: b               #0x7b8b48
    // 0x7b8b0c: cmp             x1, #2
    // 0x7b8b10: b.gt            #0x7b8b44
    // 0x7b8b14: ldr             x0, [fp, #0x18]
    // 0x7b8b18: LoadField: r1 = r0->field_13
    //     0x7b8b18: ldur            w1, [x0, #0x13]
    // 0x7b8b1c: DecompressPointer r1
    //     0x7b8b1c: add             x1, x1, HEAP, lsl #32
    // 0x7b8b20: LoadField: r2 = r0->field_b
    //     0x7b8b20: ldur            w2, [x0, #0xb]
    // 0x7b8b24: DecompressPointer r2
    //     0x7b8b24: add             x2, x2, HEAP, lsl #32
    // 0x7b8b28: cmp             w2, NULL
    // 0x7b8b2c: b.eq            #0x7b8b78
    // 0x7b8b30: r16 = true
    //     0x7b8b30: add             x16, NULL, #0x20  ; true
    // 0x7b8b34: stp             x16, x1, [SP, #-0x10]!
    // 0x7b8b38: r0 = allowSnapshotting=()
    //     0x7b8b38: bl              #0x7b7f54  ; [package:flutter/src/widgets/snapshot_widget.dart] SnapshotController::allowSnapshotting=
    // 0x7b8b3c: add             SP, SP, #0x10
    // 0x7b8b40: b               #0x7b8b60
    // 0x7b8b44: ldr             x0, [fp, #0x18]
    // 0x7b8b48: LoadField: r1 = r0->field_13
    //     0x7b8b48: ldur            w1, [x0, #0x13]
    // 0x7b8b4c: DecompressPointer r1
    //     0x7b8b4c: add             x1, x1, HEAP, lsl #32
    // 0x7b8b50: r16 = false
    //     0x7b8b50: add             x16, NULL, #0x30  ; false
    // 0x7b8b54: stp             x16, x1, [SP, #-0x10]!
    // 0x7b8b58: r0 = allowSnapshotting=()
    //     0x7b8b58: bl              #0x7b7f54  ; [package:flutter/src/widgets/snapshot_widget.dart] SnapshotController::allowSnapshotting=
    // 0x7b8b5c: add             SP, SP, #0x10
    // 0x7b8b60: r0 = Null
    //     0x7b8b60: mov             x0, NULL
    // 0x7b8b64: LeaveFrame
    //     0x7b8b64: mov             SP, fp
    //     0x7b8b68: ldp             fp, lr, [SP], #0x10
    // 0x7b8b6c: ret
    //     0x7b8b6c: ret             
    // 0x7b8b70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8b70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8b74: b               #0x7b8aec
    // 0x7b8b78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b8b78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onAnimationValueChange(dynamic) {
    // ** addr: 0x7b8b7c, size: 0x48
    // 0x7b8b7c: EnterFrame
    //     0x7b8b7c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8b80: mov             fp, SP
    // 0x7b8b84: ldr             x0, [fp, #0x10]
    // 0x7b8b88: LoadField: r1 = r0->field_17
    //     0x7b8b88: ldur            w1, [x0, #0x17]
    // 0x7b8b8c: DecompressPointer r1
    //     0x7b8b8c: add             x1, x1, HEAP, lsl #32
    // 0x7b8b90: CheckStackOverflow
    //     0x7b8b90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8b94: cmp             SP, x16
    //     0x7b8b98: b.ls            #0x7b8bbc
    // 0x7b8b9c: LoadField: r0 = r1->field_f
    //     0x7b8b9c: ldur            w0, [x1, #0xf]
    // 0x7b8ba0: DecompressPointer r0
    //     0x7b8ba0: add             x0, x0, HEAP, lsl #32
    // 0x7b8ba4: SaveReg r0
    //     0x7b8ba4: str             x0, [SP, #-8]!
    // 0x7b8ba8: r0 = onAnimationValueChange()
    //     0x7b8ba8: bl              #0x7b8bc4  ; [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationValueChange
    // 0x7b8bac: add             SP, SP, #8
    // 0x7b8bb0: LeaveFrame
    //     0x7b8bb0: mov             SP, fp
    //     0x7b8bb4: ldp             fp, lr, [SP], #0x10
    // 0x7b8bb8: ret
    //     0x7b8bb8: ret             
    // 0x7b8bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8bbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8bc0: b               #0x7b8b9c
  }
  _ onAnimationValueChange(/* No info */) {
    // ** addr: 0x7b8bc4, size: 0x190
    // 0x7b8bc4: EnterFrame
    //     0x7b8bc4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8bc8: mov             fp, SP
    // 0x7b8bcc: CheckStackOverflow
    //     0x7b8bcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8bd0: cmp             SP, x16
    //     0x7b8bd4: b.ls            #0x7b8d30
    // 0x7b8bd8: ldr             x0, [fp, #0x10]
    // 0x7b8bdc: LoadField: r1 = r0->field_1b
    //     0x7b8bdc: ldur            w1, [x0, #0x1b]
    // 0x7b8be0: DecompressPointer r1
    //     0x7b8be0: add             x1, x1, HEAP, lsl #32
    // 0x7b8be4: r16 = Sentinel
    //     0x7b8be4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8be8: cmp             w1, w16
    // 0x7b8bec: b.eq            #0x7b8d38
    // 0x7b8bf0: LoadField: r2 = r1->field_f
    //     0x7b8bf0: ldur            w2, [x1, #0xf]
    // 0x7b8bf4: DecompressPointer r2
    //     0x7b8bf4: add             x2, x2, HEAP, lsl #32
    // 0x7b8bf8: LoadField: r3 = r1->field_b
    //     0x7b8bf8: ldur            w3, [x1, #0xb]
    // 0x7b8bfc: DecompressPointer r3
    //     0x7b8bfc: add             x3, x3, HEAP, lsl #32
    // 0x7b8c00: stp             x3, x2, [SP, #-0x10]!
    // 0x7b8c04: r0 = evaluate()
    //     0x7b8c04: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x7b8c08: add             SP, SP, #0x10
    // 0x7b8c0c: LoadField: d0 = r0->field_7
    //     0x7b8c0c: ldur            d0, [x0, #7]
    // 0x7b8c10: d1 = 1.000000
    //     0x7b8c10: fmov            d1, #1.00000000
    // 0x7b8c14: fcmp            d0, d1
    // 0x7b8c18: b.vs            #0x7b8ce4
    // 0x7b8c1c: b.ne            #0x7b8ce4
    // 0x7b8c20: ldr             x1, [fp, #0x10]
    // 0x7b8c24: LoadField: r0 = r1->field_17
    //     0x7b8c24: ldur            w0, [x1, #0x17]
    // 0x7b8c28: DecompressPointer r0
    //     0x7b8c28: add             x0, x0, HEAP, lsl #32
    // 0x7b8c2c: r16 = Sentinel
    //     0x7b8c2c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8c30: cmp             w0, w16
    // 0x7b8c34: b.eq            #0x7b8d44
    // 0x7b8c38: r2 = LoadClassIdInstr(r0)
    //     0x7b8c38: ldur            x2, [x0, #-1]
    //     0x7b8c3c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b8c40: SaveReg r0
    //     0x7b8c40: str             x0, [SP, #-8]!
    // 0x7b8c44: mov             x0, x2
    // 0x7b8c48: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b8c48: add             lr, x0, #0xb7c
    //     0x7b8c4c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b8c50: blr             lr
    // 0x7b8c54: add             SP, SP, #8
    // 0x7b8c58: LoadField: d0 = r0->field_7
    //     0x7b8c58: ldur            d0, [x0, #7]
    // 0x7b8c5c: d1 = 0.000000
    //     0x7b8c5c: eor             v1.16b, v1.16b, v1.16b
    // 0x7b8c60: fcmp            d0, d1
    // 0x7b8c64: b.vs            #0x7b8c6c
    // 0x7b8c68: b.eq            #0x7b8cac
    // 0x7b8c6c: ldr             x1, [fp, #0x10]
    // 0x7b8c70: LoadField: r0 = r1->field_17
    //     0x7b8c70: ldur            w0, [x1, #0x17]
    // 0x7b8c74: DecompressPointer r0
    //     0x7b8c74: add             x0, x0, HEAP, lsl #32
    // 0x7b8c78: r2 = LoadClassIdInstr(r0)
    //     0x7b8c78: ldur            x2, [x0, #-1]
    //     0x7b8c7c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b8c80: SaveReg r0
    //     0x7b8c80: str             x0, [SP, #-8]!
    // 0x7b8c84: mov             x0, x2
    // 0x7b8c88: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b8c88: add             lr, x0, #0xb7c
    //     0x7b8c8c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b8c90: blr             lr
    // 0x7b8c94: add             SP, SP, #8
    // 0x7b8c98: LoadField: d0 = r0->field_7
    //     0x7b8c98: ldur            d0, [x0, #7]
    // 0x7b8c9c: d1 = 1.000000
    //     0x7b8c9c: fmov            d1, #1.00000000
    // 0x7b8ca0: fcmp            d0, d1
    // 0x7b8ca4: b.vs            #0x7b8cdc
    // 0x7b8ca8: b.ne            #0x7b8cdc
    // 0x7b8cac: ldr             x0, [fp, #0x10]
    // 0x7b8cb0: LoadField: r1 = r0->field_13
    //     0x7b8cb0: ldur            w1, [x0, #0x13]
    // 0x7b8cb4: DecompressPointer r1
    //     0x7b8cb4: add             x1, x1, HEAP, lsl #32
    // 0x7b8cb8: LoadField: r0 = r1->field_23
    //     0x7b8cb8: ldur            w0, [x1, #0x23]
    // 0x7b8cbc: DecompressPointer r0
    //     0x7b8cbc: add             x0, x0, HEAP, lsl #32
    // 0x7b8cc0: tbnz            w0, #4, #0x7b8d20
    // 0x7b8cc4: r0 = false
    //     0x7b8cc4: add             x0, NULL, #0x30  ; false
    // 0x7b8cc8: StoreField: r1->field_23 = r0
    //     0x7b8cc8: stur            w0, [x1, #0x23]
    // 0x7b8ccc: SaveReg r1
    //     0x7b8ccc: str             x1, [SP, #-8]!
    // 0x7b8cd0: r0 = notifyListeners()
    //     0x7b8cd0: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b8cd4: add             SP, SP, #8
    // 0x7b8cd8: b               #0x7b8d20
    // 0x7b8cdc: ldr             x0, [fp, #0x10]
    // 0x7b8ce0: b               #0x7b8ce8
    // 0x7b8ce4: ldr             x0, [fp, #0x10]
    // 0x7b8ce8: LoadField: r1 = r0->field_13
    //     0x7b8ce8: ldur            w1, [x0, #0x13]
    // 0x7b8cec: DecompressPointer r1
    //     0x7b8cec: add             x1, x1, HEAP, lsl #32
    // 0x7b8cf0: LoadField: r2 = r0->field_b
    //     0x7b8cf0: ldur            w2, [x0, #0xb]
    // 0x7b8cf4: DecompressPointer r2
    //     0x7b8cf4: add             x2, x2, HEAP, lsl #32
    // 0x7b8cf8: cmp             w2, NULL
    // 0x7b8cfc: b.eq            #0x7b8d50
    // 0x7b8d00: LoadField: r0 = r1->field_23
    //     0x7b8d00: ldur            w0, [x1, #0x23]
    // 0x7b8d04: DecompressPointer r0
    //     0x7b8d04: add             x0, x0, HEAP, lsl #32
    // 0x7b8d08: tbz             w0, #4, #0x7b8d20
    // 0x7b8d0c: r0 = true
    //     0x7b8d0c: add             x0, NULL, #0x20  ; true
    // 0x7b8d10: StoreField: r1->field_23 = r0
    //     0x7b8d10: stur            w0, [x1, #0x23]
    // 0x7b8d14: SaveReg r1
    //     0x7b8d14: str             x1, [SP, #-8]!
    // 0x7b8d18: r0 = notifyListeners()
    //     0x7b8d18: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b8d1c: add             SP, SP, #8
    // 0x7b8d20: r0 = Null
    //     0x7b8d20: mov             x0, NULL
    // 0x7b8d24: LeaveFrame
    //     0x7b8d24: mov             SP, fp
    //     0x7b8d28: ldp             fp, lr, [SP], #0x10
    // 0x7b8d2c: ret
    //     0x7b8d2c: ret             
    // 0x7b8d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8d30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8d34: b               #0x7b8bd8
    // 0x7b8d38: r9 = scaleTransition
    //     0x7b8d38: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6b8] Field <__ZoomExitTransitionState&State&_ZoomTransitionBase@789490068.scaleTransition>: late (offset: 0x1c)
    //     0x7b8d3c: ldr             x9, [x9, #0x6b8]
    // 0x7b8d40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b8d40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b8d44: r9 = fadeTransition
    //     0x7b8d44: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6c0] Field <__ZoomExitTransitionState&State&_ZoomTransitionBase@789490068.fadeTransition>: late (offset: 0x18)
    //     0x7b8d48: ldr             x9, [x9, #0x6c0]
    // 0x7b8d4c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7b8d4c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7b8d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b8d50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ __ZoomExitTransitionState&State&_ZoomTransitionBase(/* No info */) {
    // ** addr: 0xa40de4, size: 0xac
    // 0xa40de4: EnterFrame
    //     0xa40de4: stp             fp, lr, [SP, #-0x10]!
    //     0xa40de8: mov             fp, SP
    // 0xa40dec: AllocStack(0x8)
    //     0xa40dec: sub             SP, SP, #8
    // 0xa40df0: r0 = Sentinel
    //     0xa40df0: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40df4: CheckStackOverflow
    //     0xa40df4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40df8: cmp             SP, x16
    //     0xa40dfc: b.ls            #0xa40e88
    // 0xa40e00: ldr             x1, [fp, #0x10]
    // 0xa40e04: StoreField: r1->field_17 = r0
    //     0xa40e04: stur            w0, [x1, #0x17]
    // 0xa40e08: StoreField: r1->field_1b = r0
    //     0xa40e08: stur            w0, [x1, #0x1b]
    // 0xa40e0c: r0 = SnapshotController()
    //     0xa40e0c: bl              #0xa40d74  ; AllocateSnapshotControllerStub -> SnapshotController (size=0x28)
    // 0xa40e10: mov             x1, x0
    // 0xa40e14: r0 = false
    //     0xa40e14: add             x0, NULL, #0x30  ; false
    // 0xa40e18: stur            x1, [fp, #-8]
    // 0xa40e1c: StoreField: r1->field_23 = r0
    //     0xa40e1c: stur            w0, [x1, #0x23]
    // 0xa40e20: r0 = 0
    //     0xa40e20: mov             x0, #0
    // 0xa40e24: StoreField: r1->field_7 = r0
    //     0xa40e24: stur            x0, [x1, #7]
    // 0xa40e28: StoreField: r1->field_13 = r0
    //     0xa40e28: stur            x0, [x1, #0x13]
    // 0xa40e2c: StoreField: r1->field_1b = r0
    //     0xa40e2c: stur            x0, [x1, #0x1b]
    // 0xa40e30: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0xa40e30: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa40e34: ldr             x0, [x0, #0x1580]
    //     0xa40e38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa40e3c: cmp             w0, w16
    //     0xa40e40: b.ne            #0xa40e4c
    //     0xa40e44: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0xa40e48: bl              #0xd67cdc
    // 0xa40e4c: mov             x1, x0
    // 0xa40e50: ldur            x0, [fp, #-8]
    // 0xa40e54: StoreField: r0->field_f = r1
    //     0xa40e54: stur            w1, [x0, #0xf]
    // 0xa40e58: ldr             x1, [fp, #0x10]
    // 0xa40e5c: StoreField: r1->field_13 = r0
    //     0xa40e5c: stur            w0, [x1, #0x13]
    //     0xa40e60: ldurb           w16, [x1, #-1]
    //     0xa40e64: ldurb           w17, [x0, #-1]
    //     0xa40e68: and             x16, x17, x16, lsr #2
    //     0xa40e6c: tst             x16, HEAP, lsr #32
    //     0xa40e70: b.eq            #0xa40e78
    //     0xa40e74: bl              #0xd6826c
    // 0xa40e78: r0 = Null
    //     0xa40e78: mov             x0, NULL
    // 0xa40e7c: LeaveFrame
    //     0xa40e7c: mov             SP, fp
    //     0xa40e80: ldp             fp, lr, [SP], #0x10
    // 0xa40e84: ret
    //     0xa40e84: ret             
    // 0xa40e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa40e88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40e8c: b               #0xa40e00
  }
}

// class id: 3292, size: 0x24, field offset: 0x20
class _ZoomExitTransitionState extends __ZoomExitTransitionState&State&_ZoomTransitionBase {

  late _ZoomExitTransitionPainter delegate; // offset: 0x20
  static late final Animatable<double> _fadeOutTransition; // offset: 0xdf0
  static late final Animatable<double> _scaleDownTransition; // offset: 0xdf8
  static late final Animatable<double> _scaleUpTransition; // offset: 0xdf4

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b8190, size: 0x2a4
    // 0x7b8190: EnterFrame
    //     0x7b8190: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8194: mov             fp, SP
    // 0x7b8198: AllocStack(0x28)
    //     0x7b8198: sub             SP, SP, #0x28
    // 0x7b819c: CheckStackOverflow
    //     0x7b819c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b81a0: cmp             SP, x16
    //     0x7b81a4: b.ls            #0x7b8400
    // 0x7b81a8: ldr             x0, [fp, #0x10]
    // 0x7b81ac: r2 = Null
    //     0x7b81ac: mov             x2, NULL
    // 0x7b81b0: r1 = Null
    //     0x7b81b0: mov             x1, NULL
    // 0x7b81b4: r4 = 59
    //     0x7b81b4: mov             x4, #0x3b
    // 0x7b81b8: branchIfSmi(r0, 0x7b81c4)
    //     0x7b81b8: tbz             w0, #0, #0x7b81c4
    // 0x7b81bc: r4 = LoadClassIdInstr(r0)
    //     0x7b81bc: ldur            x4, [x0, #-1]
    //     0x7b81c0: ubfx            x4, x4, #0xc, #0x14
    // 0x7b81c4: r17 = 4131
    //     0x7b81c4: mov             x17, #0x1023
    // 0x7b81c8: cmp             x4, x17
    // 0x7b81cc: b.eq            #0x7b81e4
    // 0x7b81d0: r8 = _ZoomExitTransition
    //     0x7b81d0: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b6d0] Type: _ZoomExitTransition
    //     0x7b81d4: ldr             x8, [x8, #0x6d0]
    // 0x7b81d8: r3 = Null
    //     0x7b81d8: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b6d8] Null
    //     0x7b81dc: ldr             x3, [x3, #0x6d8]
    // 0x7b81e0: r0 = _ZoomExitTransition()
    //     0x7b81e0: bl              #0x7b8a68  ; IsType__ZoomExitTransition_Stub
    // 0x7b81e4: ldr             x0, [fp, #0x10]
    // 0x7b81e8: LoadField: r1 = r0->field_13
    //     0x7b81e8: ldur            w1, [x0, #0x13]
    // 0x7b81ec: DecompressPointer r1
    //     0x7b81ec: add             x1, x1, HEAP, lsl #32
    // 0x7b81f0: ldr             x2, [fp, #0x18]
    // 0x7b81f4: LoadField: r3 = r2->field_b
    //     0x7b81f4: ldur            w3, [x2, #0xb]
    // 0x7b81f8: DecompressPointer r3
    //     0x7b81f8: add             x3, x3, HEAP, lsl #32
    // 0x7b81fc: cmp             w3, NULL
    // 0x7b8200: b.eq            #0x7b8408
    // 0x7b8204: LoadField: r4 = r3->field_13
    //     0x7b8204: ldur            w4, [x3, #0x13]
    // 0x7b8208: DecompressPointer r4
    //     0x7b8208: add             x4, x4, HEAP, lsl #32
    // 0x7b820c: cmp             w1, w4
    // 0x7b8210: b.ne            #0x7b822c
    // 0x7b8214: LoadField: r1 = r0->field_b
    //     0x7b8214: ldur            w1, [x0, #0xb]
    // 0x7b8218: DecompressPointer r1
    //     0x7b8218: add             x1, x1, HEAP, lsl #32
    // 0x7b821c: LoadField: r4 = r3->field_b
    //     0x7b821c: ldur            w4, [x3, #0xb]
    // 0x7b8220: DecompressPointer r4
    //     0x7b8220: add             x4, x4, HEAP, lsl #32
    // 0x7b8224: cmp             w1, w4
    // 0x7b8228: b.eq            #0x7b83b4
    // 0x7b822c: LoadField: r1 = r0->field_b
    //     0x7b822c: ldur            w1, [x0, #0xb]
    // 0x7b8230: DecompressPointer r1
    //     0x7b8230: add             x1, x1, HEAP, lsl #32
    // 0x7b8234: stur            x1, [fp, #-8]
    // 0x7b8238: r1 = 1
    //     0x7b8238: mov             x1, #1
    // 0x7b823c: r0 = AllocateContext()
    //     0x7b823c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b8240: mov             x1, x0
    // 0x7b8244: ldr             x0, [fp, #0x18]
    // 0x7b8248: StoreField: r1->field_f = r0
    //     0x7b8248: stur            w0, [x1, #0xf]
    // 0x7b824c: mov             x2, x1
    // 0x7b8250: r1 = Function 'onAnimationValueChange':.
    //     0x7b8250: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6a8] AnonymousClosure: (0x7b8b7c), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationValueChange (0x7b8bc4)
    //     0x7b8254: ldr             x1, [x1, #0x6a8]
    // 0x7b8258: r0 = AllocateClosure()
    //     0x7b8258: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b825c: ldur            x1, [fp, #-8]
    // 0x7b8260: r2 = LoadClassIdInstr(r1)
    //     0x7b8260: ldur            x2, [x1, #-1]
    //     0x7b8264: ubfx            x2, x2, #0xc, #0x14
    // 0x7b8268: stp             x0, x1, [SP, #-0x10]!
    // 0x7b826c: mov             x0, x2
    // 0x7b8270: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x7b8270: mov             x17, #0xc2d6
    //     0x7b8274: add             lr, x0, x17
    //     0x7b8278: ldr             lr, [x21, lr, lsl #3]
    //     0x7b827c: blr             lr
    // 0x7b8280: add             SP, SP, #0x10
    // 0x7b8284: r1 = 1
    //     0x7b8284: mov             x1, #1
    // 0x7b8288: r0 = AllocateContext()
    //     0x7b8288: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b828c: mov             x1, x0
    // 0x7b8290: ldr             x0, [fp, #0x18]
    // 0x7b8294: StoreField: r1->field_f = r0
    //     0x7b8294: stur            w0, [x1, #0xf]
    // 0x7b8298: mov             x2, x1
    // 0x7b829c: r1 = Function 'onAnimationStatusChange':.
    //     0x7b829c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6b0] AnonymousClosure: (0x7b8a8c), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange (0x7b8ad8)
    //     0x7b82a0: ldr             x1, [x1, #0x6b0]
    // 0x7b82a4: r0 = AllocateClosure()
    //     0x7b82a4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b82a8: mov             x1, x0
    // 0x7b82ac: ldur            x0, [fp, #-8]
    // 0x7b82b0: r2 = LoadClassIdInstr(r0)
    //     0x7b82b0: ldur            x2, [x0, #-1]
    //     0x7b82b4: ubfx            x2, x2, #0xc, #0x14
    // 0x7b82b8: stp             x1, x0, [SP, #-0x10]!
    // 0x7b82bc: mov             x0, x2
    // 0x7b82c0: r0 = GDT[cid_x0 + 0x490]()
    //     0x7b82c0: add             lr, x0, #0x490
    //     0x7b82c4: ldr             lr, [x21, lr, lsl #3]
    //     0x7b82c8: blr             lr
    // 0x7b82cc: add             SP, SP, #0x10
    // 0x7b82d0: ldr             x16, [fp, #0x18]
    // 0x7b82d4: SaveReg r16
    //     0x7b82d4: str             x16, [SP, #-8]!
    // 0x7b82d8: r0 = _updateAnimations()
    //     0x7b82d8: bl              #0x7b8688  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_updateAnimations
    // 0x7b82dc: add             SP, SP, #8
    // 0x7b82e0: ldr             x0, [fp, #0x18]
    // 0x7b82e4: LoadField: r1 = r0->field_1f
    //     0x7b82e4: ldur            w1, [x0, #0x1f]
    // 0x7b82e8: DecompressPointer r1
    //     0x7b82e8: add             x1, x1, HEAP, lsl #32
    // 0x7b82ec: r16 = Sentinel
    //     0x7b82ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b82f0: cmp             w1, w16
    // 0x7b82f4: b.eq            #0x7b840c
    // 0x7b82f8: SaveReg r1
    //     0x7b82f8: str             x1, [SP, #-8]!
    // 0x7b82fc: r0 = dispose()
    //     0x7b82fc: bl              #0x9c2694  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::dispose
    // 0x7b8300: add             SP, SP, #8
    // 0x7b8304: ldr             x0, [fp, #0x18]
    // 0x7b8308: LoadField: r1 = r0->field_b
    //     0x7b8308: ldur            w1, [x0, #0xb]
    // 0x7b830c: DecompressPointer r1
    //     0x7b830c: add             x1, x1, HEAP, lsl #32
    // 0x7b8310: cmp             w1, NULL
    // 0x7b8314: b.eq            #0x7b8418
    // 0x7b8318: LoadField: r2 = r1->field_13
    //     0x7b8318: ldur            w2, [x1, #0x13]
    // 0x7b831c: DecompressPointer r2
    //     0x7b831c: add             x2, x2, HEAP, lsl #32
    // 0x7b8320: stur            x2, [fp, #-0x20]
    // 0x7b8324: LoadField: r3 = r0->field_17
    //     0x7b8324: ldur            w3, [x0, #0x17]
    // 0x7b8328: DecompressPointer r3
    //     0x7b8328: add             x3, x3, HEAP, lsl #32
    // 0x7b832c: r16 = Sentinel
    //     0x7b832c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8330: cmp             w3, w16
    // 0x7b8334: b.eq            #0x7b841c
    // 0x7b8338: stur            x3, [fp, #-0x18]
    // 0x7b833c: LoadField: r4 = r0->field_1b
    //     0x7b833c: ldur            w4, [x0, #0x1b]
    // 0x7b8340: DecompressPointer r4
    //     0x7b8340: add             x4, x4, HEAP, lsl #32
    // 0x7b8344: r16 = Sentinel
    //     0x7b8344: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8348: cmp             w4, w16
    // 0x7b834c: b.eq            #0x7b8428
    // 0x7b8350: stur            x4, [fp, #-0x10]
    // 0x7b8354: LoadField: r5 = r1->field_b
    //     0x7b8354: ldur            w5, [x1, #0xb]
    // 0x7b8358: DecompressPointer r5
    //     0x7b8358: add             x5, x5, HEAP, lsl #32
    // 0x7b835c: stur            x5, [fp, #-8]
    // 0x7b8360: r0 = _ZoomExitTransitionPainter()
    //     0x7b8360: bl              #0x7b867c  ; Allocate_ZoomExitTransitionPainterStub -> _ZoomExitTransitionPainter (size=0x40)
    // 0x7b8364: stur            x0, [fp, #-0x28]
    // 0x7b8368: ldur            x16, [fp, #-8]
    // 0x7b836c: stp             x16, x0, [SP, #-0x10]!
    // 0x7b8370: ldur            x16, [fp, #-0x18]
    // 0x7b8374: ldur            lr, [fp, #-0x20]
    // 0x7b8378: stp             lr, x16, [SP, #-0x10]!
    // 0x7b837c: ldur            x16, [fp, #-0x10]
    // 0x7b8380: SaveReg r16
    //     0x7b8380: str             x16, [SP, #-8]!
    // 0x7b8384: r0 = _ZoomExitTransitionPainter()
    //     0x7b8384: bl              #0x7b8434  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::_ZoomExitTransitionPainter
    // 0x7b8388: add             SP, SP, #0x28
    // 0x7b838c: ldur            x0, [fp, #-0x28]
    // 0x7b8390: ldr             x1, [fp, #0x18]
    // 0x7b8394: StoreField: r1->field_1f = r0
    //     0x7b8394: stur            w0, [x1, #0x1f]
    //     0x7b8398: ldurb           w16, [x1, #-1]
    //     0x7b839c: ldurb           w17, [x0, #-1]
    //     0x7b83a0: and             x16, x17, x16, lsr #2
    //     0x7b83a4: tst             x16, HEAP, lsr #32
    //     0x7b83a8: b.eq            #0x7b83b0
    //     0x7b83ac: bl              #0xd6826c
    // 0x7b83b0: b               #0x7b83b8
    // 0x7b83b4: mov             x1, x2
    // 0x7b83b8: LoadField: r2 = r1->field_7
    //     0x7b83b8: ldur            w2, [x1, #7]
    // 0x7b83bc: DecompressPointer r2
    //     0x7b83bc: add             x2, x2, HEAP, lsl #32
    // 0x7b83c0: ldr             x0, [fp, #0x10]
    // 0x7b83c4: r1 = Null
    //     0x7b83c4: mov             x1, NULL
    // 0x7b83c8: cmp             w2, NULL
    // 0x7b83cc: b.eq            #0x7b83f0
    // 0x7b83d0: LoadField: r4 = r2->field_17
    //     0x7b83d0: ldur            w4, [x2, #0x17]
    // 0x7b83d4: DecompressPointer r4
    //     0x7b83d4: add             x4, x4, HEAP, lsl #32
    // 0x7b83d8: r8 = X0 bound StatefulWidget
    //     0x7b83d8: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b83dc: ldr             x8, [x8, #0x858]
    // 0x7b83e0: LoadField: r9 = r4->field_7
    //     0x7b83e0: ldur            x9, [x4, #7]
    // 0x7b83e4: r3 = Null
    //     0x7b83e4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b6e8] Null
    //     0x7b83e8: ldr             x3, [x3, #0x6e8]
    // 0x7b83ec: blr             x9
    // 0x7b83f0: r0 = Null
    //     0x7b83f0: mov             x0, NULL
    // 0x7b83f4: LeaveFrame
    //     0x7b83f4: mov             SP, fp
    //     0x7b83f8: ldp             fp, lr, [SP], #0x10
    // 0x7b83fc: ret
    //     0x7b83fc: ret             
    // 0x7b8400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8404: b               #0x7b81a8
    // 0x7b8408: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b8408: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b840c: r9 = delegate
    //     0x7b840c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6a0] Field <_ZoomExitTransitionState@789490068.delegate>: late (offset: 0x20)
    //     0x7b8410: ldr             x9, [x9, #0x6a0]
    // 0x7b8414: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b8414: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b8418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b8418: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b841c: r9 = fadeTransition
    //     0x7b841c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6c0] Field <__ZoomExitTransitionState&State&_ZoomTransitionBase@789490068.fadeTransition>: late (offset: 0x18)
    //     0x7b8420: ldr             x9, [x9, #0x6c0]
    // 0x7b8424: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b8424: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b8428: r9 = scaleTransition
    //     0x7b8428: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6b8] Field <__ZoomExitTransitionState&State&_ZoomTransitionBase@789490068.scaleTransition>: late (offset: 0x1c)
    //     0x7b842c: ldr             x9, [x9, #0x6b8]
    // 0x7b8430: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b8430: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0x7b8688, size: 0x26c
    // 0x7b8688: EnterFrame
    //     0x7b8688: stp             fp, lr, [SP, #-0x10]!
    //     0x7b868c: mov             fp, SP
    // 0x7b8690: AllocStack(0x8)
    //     0x7b8690: sub             SP, SP, #8
    // 0x7b8694: CheckStackOverflow
    //     0x7b8694: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8698: cmp             SP, x16
    //     0x7b869c: b.ls            #0x7b88d4
    // 0x7b86a0: ldr             x0, [fp, #0x10]
    // 0x7b86a4: LoadField: r1 = r0->field_b
    //     0x7b86a4: ldur            w1, [x0, #0xb]
    // 0x7b86a8: DecompressPointer r1
    //     0x7b86a8: add             x1, x1, HEAP, lsl #32
    // 0x7b86ac: cmp             w1, NULL
    // 0x7b86b0: b.eq            #0x7b88dc
    // 0x7b86b4: LoadField: r2 = r1->field_13
    //     0x7b86b4: ldur            w2, [x1, #0x13]
    // 0x7b86b8: DecompressPointer r2
    //     0x7b86b8: add             x2, x2, HEAP, lsl #32
    // 0x7b86bc: tbnz            w2, #4, #0x7b8710
    // 0x7b86c0: r0 = InitLateStaticField(0xdf0) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_fadeOutTransition
    //     0x7b86c0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b86c4: ldr             x0, [x0, #0x1be0]
    //     0x7b86c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b86cc: cmp             w0, w16
    //     0x7b86d0: b.ne            #0x7b86e0
    //     0x7b86d4: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b700] Field <_ZoomExitTransitionState@789490068._fadeOutTransition@789490068>: static late final (offset: 0xdf0)
    //     0x7b86d8: ldr             x2, [x2, #0x700]
    //     0x7b86dc: bl              #0xd67cdc
    // 0x7b86e0: mov             x1, x0
    // 0x7b86e4: ldr             x0, [fp, #0x10]
    // 0x7b86e8: LoadField: r2 = r0->field_b
    //     0x7b86e8: ldur            w2, [x0, #0xb]
    // 0x7b86ec: DecompressPointer r2
    //     0x7b86ec: add             x2, x2, HEAP, lsl #32
    // 0x7b86f0: cmp             w2, NULL
    // 0x7b86f4: b.eq            #0x7b88e0
    // 0x7b86f8: LoadField: r3 = r2->field_b
    //     0x7b86f8: ldur            w3, [x2, #0xb]
    // 0x7b86fc: DecompressPointer r3
    //     0x7b86fc: add             x3, x3, HEAP, lsl #32
    // 0x7b8700: stp             x3, x1, [SP, #-0x10]!
    // 0x7b8704: r0 = animate()
    //     0x7b8704: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b8708: add             SP, SP, #0x10
    // 0x7b870c: b               #0x7b8718
    // 0x7b8710: r0 = Instance__AlwaysCompleteAnimation
    //     0x7b8710: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c8c0] Obj!_AlwaysCompleteAnimation<double>@b4fcd1
    //     0x7b8714: ldr             x0, [x0, #0x8c0]
    // 0x7b8718: ldr             x1, [fp, #0x10]
    // 0x7b871c: StoreField: r1->field_17 = r0
    //     0x7b871c: stur            w0, [x1, #0x17]
    //     0x7b8720: tbz             w0, #0, #0x7b873c
    //     0x7b8724: ldurb           w16, [x1, #-1]
    //     0x7b8728: ldurb           w17, [x0, #-1]
    //     0x7b872c: and             x16, x17, x16, lsr #2
    //     0x7b8730: tst             x16, HEAP, lsr #32
    //     0x7b8734: b.eq            #0x7b873c
    //     0x7b8738: bl              #0xd6826c
    // 0x7b873c: LoadField: r0 = r1->field_b
    //     0x7b873c: ldur            w0, [x1, #0xb]
    // 0x7b8740: DecompressPointer r0
    //     0x7b8740: add             x0, x0, HEAP, lsl #32
    // 0x7b8744: cmp             w0, NULL
    // 0x7b8748: b.eq            #0x7b88e4
    // 0x7b874c: LoadField: r2 = r0->field_13
    //     0x7b874c: ldur            w2, [x0, #0x13]
    // 0x7b8750: DecompressPointer r2
    //     0x7b8750: add             x2, x2, HEAP, lsl #32
    // 0x7b8754: tbnz            w2, #4, #0x7b8780
    // 0x7b8758: r0 = InitLateStaticField(0xdf8) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_scaleDownTransition
    //     0x7b8758: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b875c: ldr             x0, [x0, #0x1bf0]
    //     0x7b8760: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b8764: cmp             w0, w16
    //     0x7b8768: b.ne            #0x7b8778
    //     0x7b876c: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b708] Field <_ZoomExitTransitionState@789490068._scaleDownTransition@789490068>: static late final (offset: 0xdf8)
    //     0x7b8770: ldr             x2, [x2, #0x708]
    //     0x7b8774: bl              #0xd67cdc
    // 0x7b8778: mov             x1, x0
    // 0x7b877c: b               #0x7b87a4
    // 0x7b8780: r0 = InitLateStaticField(0xdf4) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_scaleUpTransition
    //     0x7b8780: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b8784: ldr             x0, [x0, #0x1be8]
    //     0x7b8788: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b878c: cmp             w0, w16
    //     0x7b8790: b.ne            #0x7b87a0
    //     0x7b8794: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b710] Field <_ZoomExitTransitionState@789490068._scaleUpTransition@789490068>: static late final (offset: 0xdf4)
    //     0x7b8798: ldr             x2, [x2, #0x710]
    //     0x7b879c: bl              #0xd67cdc
    // 0x7b87a0: mov             x1, x0
    // 0x7b87a4: ldr             x0, [fp, #0x10]
    // 0x7b87a8: LoadField: r2 = r0->field_b
    //     0x7b87a8: ldur            w2, [x0, #0xb]
    // 0x7b87ac: DecompressPointer r2
    //     0x7b87ac: add             x2, x2, HEAP, lsl #32
    // 0x7b87b0: cmp             w2, NULL
    // 0x7b87b4: b.eq            #0x7b88e8
    // 0x7b87b8: LoadField: r3 = r2->field_b
    //     0x7b87b8: ldur            w3, [x2, #0xb]
    // 0x7b87bc: DecompressPointer r3
    //     0x7b87bc: add             x3, x3, HEAP, lsl #32
    // 0x7b87c0: stp             x3, x1, [SP, #-0x10]!
    // 0x7b87c4: r0 = animate()
    //     0x7b87c4: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b87c8: add             SP, SP, #0x10
    // 0x7b87cc: ldr             x1, [fp, #0x10]
    // 0x7b87d0: StoreField: r1->field_1b = r0
    //     0x7b87d0: stur            w0, [x1, #0x1b]
    //     0x7b87d4: ldurb           w16, [x1, #-1]
    //     0x7b87d8: ldurb           w17, [x0, #-1]
    //     0x7b87dc: and             x16, x17, x16, lsr #2
    //     0x7b87e0: tst             x16, HEAP, lsr #32
    //     0x7b87e4: b.eq            #0x7b87ec
    //     0x7b87e8: bl              #0xd6826c
    // 0x7b87ec: LoadField: r0 = r1->field_b
    //     0x7b87ec: ldur            w0, [x1, #0xb]
    // 0x7b87f0: DecompressPointer r0
    //     0x7b87f0: add             x0, x0, HEAP, lsl #32
    // 0x7b87f4: cmp             w0, NULL
    // 0x7b87f8: b.eq            #0x7b88ec
    // 0x7b87fc: LoadField: r2 = r0->field_b
    //     0x7b87fc: ldur            w2, [x0, #0xb]
    // 0x7b8800: DecompressPointer r2
    //     0x7b8800: add             x2, x2, HEAP, lsl #32
    // 0x7b8804: stur            x2, [fp, #-8]
    // 0x7b8808: r1 = 1
    //     0x7b8808: mov             x1, #1
    // 0x7b880c: r0 = AllocateContext()
    //     0x7b880c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b8810: mov             x1, x0
    // 0x7b8814: ldr             x0, [fp, #0x10]
    // 0x7b8818: StoreField: r1->field_f = r0
    //     0x7b8818: stur            w0, [x1, #0xf]
    // 0x7b881c: mov             x2, x1
    // 0x7b8820: r1 = Function 'onAnimationValueChange':.
    //     0x7b8820: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6a8] AnonymousClosure: (0x7b8b7c), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationValueChange (0x7b8bc4)
    //     0x7b8824: ldr             x1, [x1, #0x6a8]
    // 0x7b8828: r0 = AllocateClosure()
    //     0x7b8828: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b882c: mov             x1, x0
    // 0x7b8830: ldur            x0, [fp, #-8]
    // 0x7b8834: r2 = LoadClassIdInstr(r0)
    //     0x7b8834: ldur            x2, [x0, #-1]
    //     0x7b8838: ubfx            x2, x2, #0xc, #0x14
    // 0x7b883c: stp             x1, x0, [SP, #-0x10]!
    // 0x7b8840: mov             x0, x2
    // 0x7b8844: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b8844: mov             x17, #0xc3ab
    //     0x7b8848: add             lr, x0, x17
    //     0x7b884c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b8850: blr             lr
    // 0x7b8854: add             SP, SP, #0x10
    // 0x7b8858: ldr             x0, [fp, #0x10]
    // 0x7b885c: LoadField: r1 = r0->field_b
    //     0x7b885c: ldur            w1, [x0, #0xb]
    // 0x7b8860: DecompressPointer r1
    //     0x7b8860: add             x1, x1, HEAP, lsl #32
    // 0x7b8864: cmp             w1, NULL
    // 0x7b8868: b.eq            #0x7b88f0
    // 0x7b886c: LoadField: r2 = r1->field_b
    //     0x7b886c: ldur            w2, [x1, #0xb]
    // 0x7b8870: DecompressPointer r2
    //     0x7b8870: add             x2, x2, HEAP, lsl #32
    // 0x7b8874: stur            x2, [fp, #-8]
    // 0x7b8878: r1 = 1
    //     0x7b8878: mov             x1, #1
    // 0x7b887c: r0 = AllocateContext()
    //     0x7b887c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b8880: mov             x1, x0
    // 0x7b8884: ldr             x0, [fp, #0x10]
    // 0x7b8888: StoreField: r1->field_f = r0
    //     0x7b8888: stur            w0, [x1, #0xf]
    // 0x7b888c: mov             x2, x1
    // 0x7b8890: r1 = Function 'onAnimationStatusChange':.
    //     0x7b8890: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6b0] AnonymousClosure: (0x7b8a8c), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange (0x7b8ad8)
    //     0x7b8894: ldr             x1, [x1, #0x6b0]
    // 0x7b8898: r0 = AllocateClosure()
    //     0x7b8898: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b889c: mov             x1, x0
    // 0x7b88a0: ldur            x0, [fp, #-8]
    // 0x7b88a4: r2 = LoadClassIdInstr(r0)
    //     0x7b88a4: ldur            x2, [x0, #-1]
    //     0x7b88a8: ubfx            x2, x2, #0xc, #0x14
    // 0x7b88ac: stp             x1, x0, [SP, #-0x10]!
    // 0x7b88b0: mov             x0, x2
    // 0x7b88b4: r0 = GDT[cid_x0 + 0x80c]()
    //     0x7b88b4: add             lr, x0, #0x80c
    //     0x7b88b8: ldr             lr, [x21, lr, lsl #3]
    //     0x7b88bc: blr             lr
    // 0x7b88c0: add             SP, SP, #0x10
    // 0x7b88c4: r0 = Null
    //     0x7b88c4: mov             x0, NULL
    // 0x7b88c8: LeaveFrame
    //     0x7b88c8: mov             SP, fp
    //     0x7b88cc: ldp             fp, lr, [SP], #0x10
    // 0x7b88d0: ret
    //     0x7b88d0: ret             
    // 0x7b88d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b88d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b88d8: b               #0x7b86a0
    // 0x7b88dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b88dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b88e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b88e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b88e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b88e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b88e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b88e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b88ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b88ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b88f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b88f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _scaleUpTransition() {
    // ** addr: 0x7b88f4, size: 0x80
    // 0x7b88f4: EnterFrame
    //     0x7b88f4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b88f8: mov             fp, SP
    // 0x7b88fc: AllocStack(0x8)
    //     0x7b88fc: sub             SP, SP, #8
    // 0x7b8900: CheckStackOverflow
    //     0x7b8900: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8904: cmp             SP, x16
    //     0x7b8908: b.ls            #0x7b896c
    // 0x7b890c: r1 = <double>
    //     0x7b890c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b8910: r0 = Tween()
    //     0x7b8910: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b8914: mov             x1, x0
    // 0x7b8918: r0 = 1.000000
    //     0x7b8918: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b891c: stur            x1, [fp, #-8]
    // 0x7b8920: StoreField: r1->field_b = r0
    //     0x7b8920: stur            w0, [x1, #0xb]
    // 0x7b8924: r0 = 1.050000
    //     0x7b8924: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b718] 1.05
    //     0x7b8928: ldr             x0, [x0, #0x718]
    // 0x7b892c: StoreField: r1->field_f = r0
    //     0x7b892c: stur            w0, [x1, #0xf]
    // 0x7b8930: r0 = InitLateStaticField(0xe00) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::_scaleCurveSequence
    //     0x7b8930: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b8934: ldr             x0, [x0, #0x1c00]
    //     0x7b8938: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b893c: cmp             w0, w16
    //     0x7b8940: b.ne            #0x7b8950
    //     0x7b8944: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b720] Field <_ZoomPageTransition@789490068._scaleCurveSequence@789490068>: static late final (offset: 0xe00)
    //     0x7b8948: ldr             x2, [x2, #0x720]
    //     0x7b894c: bl              #0xd67cdc
    // 0x7b8950: ldur            x16, [fp, #-8]
    // 0x7b8954: stp             x0, x16, [SP, #-0x10]!
    // 0x7b8958: r0 = chain()
    //     0x7b8958: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b895c: add             SP, SP, #0x10
    // 0x7b8960: LeaveFrame
    //     0x7b8960: mov             SP, fp
    //     0x7b8964: ldp             fp, lr, [SP], #0x10
    // 0x7b8968: ret
    //     0x7b8968: ret             
    // 0x7b896c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b896c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8970: b               #0x7b890c
  }
  static Animatable<double> _scaleDownTransition() {
    // ** addr: 0x7b8974, size: 0x80
    // 0x7b8974: EnterFrame
    //     0x7b8974: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8978: mov             fp, SP
    // 0x7b897c: AllocStack(0x8)
    //     0x7b897c: sub             SP, SP, #8
    // 0x7b8980: CheckStackOverflow
    //     0x7b8980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8984: cmp             SP, x16
    //     0x7b8988: b.ls            #0x7b89ec
    // 0x7b898c: r1 = <double>
    //     0x7b898c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b8990: r0 = Tween()
    //     0x7b8990: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b8994: mov             x1, x0
    // 0x7b8998: r0 = 1.000000
    //     0x7b8998: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b899c: stur            x1, [fp, #-8]
    // 0x7b89a0: StoreField: r1->field_b = r0
    //     0x7b89a0: stur            w0, [x1, #0xb]
    // 0x7b89a4: r0 = 0.900000
    //     0x7b89a4: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b750] 0.9
    //     0x7b89a8: ldr             x0, [x0, #0x750]
    // 0x7b89ac: StoreField: r1->field_f = r0
    //     0x7b89ac: stur            w0, [x1, #0xf]
    // 0x7b89b0: r0 = InitLateStaticField(0xe00) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::_scaleCurveSequence
    //     0x7b89b0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b89b4: ldr             x0, [x0, #0x1c00]
    //     0x7b89b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b89bc: cmp             w0, w16
    //     0x7b89c0: b.ne            #0x7b89d0
    //     0x7b89c4: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b720] Field <_ZoomPageTransition@789490068._scaleCurveSequence@789490068>: static late final (offset: 0xe00)
    //     0x7b89c8: ldr             x2, [x2, #0x720]
    //     0x7b89cc: bl              #0xd67cdc
    // 0x7b89d0: ldur            x16, [fp, #-8]
    // 0x7b89d4: stp             x0, x16, [SP, #-0x10]!
    // 0x7b89d8: r0 = chain()
    //     0x7b89d8: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b89dc: add             SP, SP, #0x10
    // 0x7b89e0: LeaveFrame
    //     0x7b89e0: mov             SP, fp
    //     0x7b89e4: ldp             fp, lr, [SP], #0x10
    // 0x7b89e8: ret
    //     0x7b89e8: ret             
    // 0x7b89ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b89ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b89f0: b               #0x7b898c
  }
  static Animatable<double> _fadeOutTransition() {
    // ** addr: 0x7b89f4, size: 0x74
    // 0x7b89f4: EnterFrame
    //     0x7b89f4: stp             fp, lr, [SP, #-0x10]!
    //     0x7b89f8: mov             fp, SP
    // 0x7b89fc: AllocStack(0x8)
    //     0x7b89fc: sub             SP, SP, #8
    // 0x7b8a00: CheckStackOverflow
    //     0x7b8a00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8a04: cmp             SP, x16
    //     0x7b8a08: b.ls            #0x7b8a60
    // 0x7b8a0c: r1 = <double>
    //     0x7b8a0c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b8a10: r0 = Tween()
    //     0x7b8a10: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b8a14: mov             x2, x0
    // 0x7b8a18: r0 = 1.000000
    //     0x7b8a18: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b8a1c: stur            x2, [fp, #-8]
    // 0x7b8a20: StoreField: r2->field_b = r0
    //     0x7b8a20: stur            w0, [x2, #0xb]
    // 0x7b8a24: r0 = 0.000000
    //     0x7b8a24: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x7b8a28: StoreField: r2->field_f = r0
    //     0x7b8a28: stur            w0, [x2, #0xf]
    // 0x7b8a2c: r1 = <double>
    //     0x7b8a2c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b8a30: r0 = CurveTween()
    //     0x7b8a30: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7b8a34: mov             x1, x0
    // 0x7b8a38: r0 = Instance_Interval
    //     0x7b8a38: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b758] Obj!Interval<double>@b4f741
    //     0x7b8a3c: ldr             x0, [x0, #0x758]
    // 0x7b8a40: StoreField: r1->field_b = r0
    //     0x7b8a40: stur            w0, [x1, #0xb]
    // 0x7b8a44: ldur            x16, [fp, #-8]
    // 0x7b8a48: stp             x1, x16, [SP, #-0x10]!
    // 0x7b8a4c: r0 = chain()
    //     0x7b8a4c: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b8a50: add             SP, SP, #0x10
    // 0x7b8a54: LeaveFrame
    //     0x7b8a54: mov             SP, fp
    //     0x7b8a58: ldp             fp, lr, [SP], #0x10
    // 0x7b8a5c: ret
    //     0x7b8a5c: ret             
    // 0x7b8a60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8a60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8a64: b               #0x7b8a0c
  }
  _ build(/* No info */) {
    // ** addr: 0x862304, size: 0x9c
    // 0x862304: EnterFrame
    //     0x862304: stp             fp, lr, [SP, #-0x10]!
    //     0x862308: mov             fp, SP
    // 0x86230c: AllocStack(0x18)
    //     0x86230c: sub             SP, SP, #0x18
    // 0x862310: ldr             x0, [fp, #0x18]
    // 0x862314: LoadField: r1 = r0->field_1f
    //     0x862314: ldur            w1, [x0, #0x1f]
    // 0x862318: DecompressPointer r1
    //     0x862318: add             x1, x1, HEAP, lsl #32
    // 0x86231c: r16 = Sentinel
    //     0x86231c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862320: cmp             w1, w16
    // 0x862324: b.eq            #0x862390
    // 0x862328: stur            x1, [fp, #-0x18]
    // 0x86232c: LoadField: r2 = r0->field_13
    //     0x86232c: ldur            w2, [x0, #0x13]
    // 0x862330: DecompressPointer r2
    //     0x862330: add             x2, x2, HEAP, lsl #32
    // 0x862334: stur            x2, [fp, #-0x10]
    // 0x862338: LoadField: r3 = r0->field_b
    //     0x862338: ldur            w3, [x0, #0xb]
    // 0x86233c: DecompressPointer r3
    //     0x86233c: add             x3, x3, HEAP, lsl #32
    // 0x862340: cmp             w3, NULL
    // 0x862344: b.eq            #0x86239c
    // 0x862348: LoadField: r0 = r3->field_17
    //     0x862348: ldur            w0, [x3, #0x17]
    // 0x86234c: DecompressPointer r0
    //     0x86234c: add             x0, x0, HEAP, lsl #32
    // 0x862350: stur            x0, [fp, #-8]
    // 0x862354: r0 = SnapshotWidget()
    //     0x862354: bl              #0x8622f8  ; AllocateSnapshotWidgetStub -> SnapshotWidget (size=0x20)
    // 0x862358: r1 = Instance_SnapshotMode
    //     0x862358: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b698] Obj!SnapshotMode@b634b1
    //     0x86235c: ldr             x1, [x1, #0x698]
    // 0x862360: StoreField: r0->field_13 = r1
    //     0x862360: stur            w1, [x0, #0x13]
    // 0x862364: ldur            x1, [fp, #-0x18]
    // 0x862368: StoreField: r0->field_1b = r1
    //     0x862368: stur            w1, [x0, #0x1b]
    // 0x86236c: r1 = true
    //     0x86236c: add             x1, NULL, #0x20  ; true
    // 0x862370: StoreField: r0->field_17 = r1
    //     0x862370: stur            w1, [x0, #0x17]
    // 0x862374: ldur            x1, [fp, #-0x10]
    // 0x862378: StoreField: r0->field_f = r1
    //     0x862378: stur            w1, [x0, #0xf]
    // 0x86237c: ldur            x1, [fp, #-8]
    // 0x862380: StoreField: r0->field_b = r1
    //     0x862380: stur            w1, [x0, #0xb]
    // 0x862384: LeaveFrame
    //     0x862384: mov             SP, fp
    //     0x862388: ldp             fp, lr, [SP], #0x10
    // 0x86238c: ret
    //     0x86238c: ret             
    // 0x862390: r9 = delegate
    //     0x862390: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6a0] Field <_ZoomExitTransitionState@789490068.delegate>: late (offset: 0x20)
    //     0x862394: ldr             x9, [x9, #0x6a0]
    // 0x862398: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x862398: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x86239c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86239c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9daf88, size: 0x108
    // 0x9daf88: EnterFrame
    //     0x9daf88: stp             fp, lr, [SP, #-0x10]!
    //     0x9daf8c: mov             fp, SP
    // 0x9daf90: AllocStack(0x28)
    //     0x9daf90: sub             SP, SP, #0x28
    // 0x9daf94: CheckStackOverflow
    //     0x9daf94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9daf98: cmp             SP, x16
    //     0x9daf9c: b.ls            #0x9db06c
    // 0x9dafa0: ldr             x16, [fp, #0x10]
    // 0x9dafa4: SaveReg r16
    //     0x9dafa4: str             x16, [SP, #-8]!
    // 0x9dafa8: r0 = _updateAnimations()
    //     0x9dafa8: bl              #0x7b8688  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::_updateAnimations
    // 0x9dafac: add             SP, SP, #8
    // 0x9dafb0: ldr             x0, [fp, #0x10]
    // 0x9dafb4: LoadField: r1 = r0->field_b
    //     0x9dafb4: ldur            w1, [x0, #0xb]
    // 0x9dafb8: DecompressPointer r1
    //     0x9dafb8: add             x1, x1, HEAP, lsl #32
    // 0x9dafbc: cmp             w1, NULL
    // 0x9dafc0: b.eq            #0x9db074
    // 0x9dafc4: LoadField: r2 = r1->field_13
    //     0x9dafc4: ldur            w2, [x1, #0x13]
    // 0x9dafc8: DecompressPointer r2
    //     0x9dafc8: add             x2, x2, HEAP, lsl #32
    // 0x9dafcc: stur            x2, [fp, #-0x20]
    // 0x9dafd0: LoadField: r3 = r0->field_17
    //     0x9dafd0: ldur            w3, [x0, #0x17]
    // 0x9dafd4: DecompressPointer r3
    //     0x9dafd4: add             x3, x3, HEAP, lsl #32
    // 0x9dafd8: r16 = Sentinel
    //     0x9dafd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9dafdc: cmp             w3, w16
    // 0x9dafe0: b.eq            #0x9db078
    // 0x9dafe4: stur            x3, [fp, #-0x18]
    // 0x9dafe8: LoadField: r4 = r0->field_1b
    //     0x9dafe8: ldur            w4, [x0, #0x1b]
    // 0x9dafec: DecompressPointer r4
    //     0x9dafec: add             x4, x4, HEAP, lsl #32
    // 0x9daff0: r16 = Sentinel
    //     0x9daff0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9daff4: cmp             w4, w16
    // 0x9daff8: b.eq            #0x9db084
    // 0x9daffc: stur            x4, [fp, #-0x10]
    // 0x9db000: LoadField: r5 = r1->field_b
    //     0x9db000: ldur            w5, [x1, #0xb]
    // 0x9db004: DecompressPointer r5
    //     0x9db004: add             x5, x5, HEAP, lsl #32
    // 0x9db008: stur            x5, [fp, #-8]
    // 0x9db00c: r0 = _ZoomExitTransitionPainter()
    //     0x9db00c: bl              #0x7b867c  ; Allocate_ZoomExitTransitionPainterStub -> _ZoomExitTransitionPainter (size=0x40)
    // 0x9db010: stur            x0, [fp, #-0x28]
    // 0x9db014: ldur            x16, [fp, #-8]
    // 0x9db018: stp             x16, x0, [SP, #-0x10]!
    // 0x9db01c: ldur            x16, [fp, #-0x18]
    // 0x9db020: ldur            lr, [fp, #-0x20]
    // 0x9db024: stp             lr, x16, [SP, #-0x10]!
    // 0x9db028: ldur            x16, [fp, #-0x10]
    // 0x9db02c: SaveReg r16
    //     0x9db02c: str             x16, [SP, #-8]!
    // 0x9db030: r0 = _ZoomExitTransitionPainter()
    //     0x9db030: bl              #0x7b8434  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::_ZoomExitTransitionPainter
    // 0x9db034: add             SP, SP, #0x28
    // 0x9db038: ldur            x0, [fp, #-0x28]
    // 0x9db03c: ldr             x1, [fp, #0x10]
    // 0x9db040: StoreField: r1->field_1f = r0
    //     0x9db040: stur            w0, [x1, #0x1f]
    //     0x9db044: ldurb           w16, [x1, #-1]
    //     0x9db048: ldurb           w17, [x0, #-1]
    //     0x9db04c: and             x16, x17, x16, lsr #2
    //     0x9db050: tst             x16, HEAP, lsr #32
    //     0x9db054: b.eq            #0x9db05c
    //     0x9db058: bl              #0xd6826c
    // 0x9db05c: r0 = Null
    //     0x9db05c: mov             x0, NULL
    // 0x9db060: LeaveFrame
    //     0x9db060: mov             SP, fp
    //     0x9db064: ldp             fp, lr, [SP], #0x10
    // 0x9db068: ret
    //     0x9db068: ret             
    // 0x9db06c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9db06c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9db070: b               #0x9dafa0
    // 0x9db074: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9db074: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9db078: r9 = fadeTransition
    //     0x9db078: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6c0] Field <__ZoomExitTransitionState&State&_ZoomTransitionBase@789490068.fadeTransition>: late (offset: 0x18)
    //     0x9db07c: ldr             x9, [x9, #0x6c0]
    // 0x9db080: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9db080: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9db084: r9 = scaleTransition
    //     0x9db084: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6b8] Field <__ZoomExitTransitionState&State&_ZoomTransitionBase@789490068.scaleTransition>: late (offset: 0x1c)
    //     0x9db088: ldr             x9, [x9, #0x6b8]
    // 0x9db08c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9db08c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4aee8, size: 0x18
    // 0xa4aee8: r4 = 7
    //     0xa4aee8: mov             x4, #7
    // 0xa4aeec: r1 = Function 'dispose':.
    //     0xa4aeec: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b690] AnonymousClosure: (0xa4af00), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::dispose (0xa521a8)
    //     0xa4aef0: ldr             x1, [x17, #0x690]
    // 0xa4aef4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4aef4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4aef8: LoadField: r0 = r24->field_17
    //     0xa4aef8: ldur            x0, [x24, #0x17]
    // 0xa4aefc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4af00, size: 0x48
    // 0xa4af00: EnterFrame
    //     0xa4af00: stp             fp, lr, [SP, #-0x10]!
    //     0xa4af04: mov             fp, SP
    // 0xa4af08: ldr             x0, [fp, #0x10]
    // 0xa4af0c: LoadField: r1 = r0->field_17
    //     0xa4af0c: ldur            w1, [x0, #0x17]
    // 0xa4af10: DecompressPointer r1
    //     0xa4af10: add             x1, x1, HEAP, lsl #32
    // 0xa4af14: CheckStackOverflow
    //     0xa4af14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4af18: cmp             SP, x16
    //     0xa4af1c: b.ls            #0xa4af40
    // 0xa4af20: LoadField: r0 = r1->field_f
    //     0xa4af20: ldur            w0, [x1, #0xf]
    // 0xa4af24: DecompressPointer r0
    //     0xa4af24: add             x0, x0, HEAP, lsl #32
    // 0xa4af28: SaveReg r0
    //     0xa4af28: str             x0, [SP, #-8]!
    // 0xa4af2c: r0 = dispose()
    //     0xa4af2c: bl              #0xa521a8  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionState::dispose
    // 0xa4af30: add             SP, SP, #8
    // 0xa4af34: LeaveFrame
    //     0xa4af34: mov             SP, fp
    //     0xa4af38: ldp             fp, lr, [SP], #0x10
    // 0xa4af3c: ret
    //     0xa4af3c: ret             
    // 0xa4af40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4af40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4af44: b               #0xa4af20
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa521a8, size: 0x144
    // 0xa521a8: EnterFrame
    //     0xa521a8: stp             fp, lr, [SP, #-0x10]!
    //     0xa521ac: mov             fp, SP
    // 0xa521b0: AllocStack(0x8)
    //     0xa521b0: sub             SP, SP, #8
    // 0xa521b4: CheckStackOverflow
    //     0xa521b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa521b8: cmp             SP, x16
    //     0xa521bc: b.ls            #0xa522d0
    // 0xa521c0: ldr             x0, [fp, #0x10]
    // 0xa521c4: LoadField: r1 = r0->field_b
    //     0xa521c4: ldur            w1, [x0, #0xb]
    // 0xa521c8: DecompressPointer r1
    //     0xa521c8: add             x1, x1, HEAP, lsl #32
    // 0xa521cc: cmp             w1, NULL
    // 0xa521d0: b.eq            #0xa522d8
    // 0xa521d4: LoadField: r2 = r1->field_b
    //     0xa521d4: ldur            w2, [x1, #0xb]
    // 0xa521d8: DecompressPointer r2
    //     0xa521d8: add             x2, x2, HEAP, lsl #32
    // 0xa521dc: stur            x2, [fp, #-8]
    // 0xa521e0: r1 = 1
    //     0xa521e0: mov             x1, #1
    // 0xa521e4: r0 = AllocateContext()
    //     0xa521e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa521e8: mov             x1, x0
    // 0xa521ec: ldr             x0, [fp, #0x10]
    // 0xa521f0: StoreField: r1->field_f = r0
    //     0xa521f0: stur            w0, [x1, #0xf]
    // 0xa521f4: mov             x2, x1
    // 0xa521f8: r1 = Function 'onAnimationValueChange':.
    //     0xa521f8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6a8] AnonymousClosure: (0x7b8b7c), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationValueChange (0x7b8bc4)
    //     0xa521fc: ldr             x1, [x1, #0x6a8]
    // 0xa52200: r0 = AllocateClosure()
    //     0xa52200: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52204: mov             x1, x0
    // 0xa52208: ldur            x0, [fp, #-8]
    // 0xa5220c: r2 = LoadClassIdInstr(r0)
    //     0xa5220c: ldur            x2, [x0, #-1]
    //     0xa52210: ubfx            x2, x2, #0xc, #0x14
    // 0xa52214: stp             x1, x0, [SP, #-0x10]!
    // 0xa52218: mov             x0, x2
    // 0xa5221c: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa5221c: mov             x17, #0xc2d6
    //     0xa52220: add             lr, x0, x17
    //     0xa52224: ldr             lr, [x21, lr, lsl #3]
    //     0xa52228: blr             lr
    // 0xa5222c: add             SP, SP, #0x10
    // 0xa52230: ldr             x0, [fp, #0x10]
    // 0xa52234: LoadField: r1 = r0->field_b
    //     0xa52234: ldur            w1, [x0, #0xb]
    // 0xa52238: DecompressPointer r1
    //     0xa52238: add             x1, x1, HEAP, lsl #32
    // 0xa5223c: cmp             w1, NULL
    // 0xa52240: b.eq            #0xa522dc
    // 0xa52244: LoadField: r2 = r1->field_b
    //     0xa52244: ldur            w2, [x1, #0xb]
    // 0xa52248: DecompressPointer r2
    //     0xa52248: add             x2, x2, HEAP, lsl #32
    // 0xa5224c: stur            x2, [fp, #-8]
    // 0xa52250: r1 = 1
    //     0xa52250: mov             x1, #1
    // 0xa52254: r0 = AllocateContext()
    //     0xa52254: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52258: mov             x1, x0
    // 0xa5225c: ldr             x0, [fp, #0x10]
    // 0xa52260: StoreField: r1->field_f = r0
    //     0xa52260: stur            w0, [x1, #0xf]
    // 0xa52264: mov             x2, x1
    // 0xa52268: r1 = Function 'onAnimationStatusChange':.
    //     0xa52268: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6b0] AnonymousClosure: (0x7b8a8c), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange (0x7b8ad8)
    //     0xa5226c: ldr             x1, [x1, #0x6b0]
    // 0xa52270: r0 = AllocateClosure()
    //     0xa52270: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52274: mov             x1, x0
    // 0xa52278: ldur            x0, [fp, #-8]
    // 0xa5227c: r2 = LoadClassIdInstr(r0)
    //     0xa5227c: ldur            x2, [x0, #-1]
    //     0xa52280: ubfx            x2, x2, #0xc, #0x14
    // 0xa52284: stp             x1, x0, [SP, #-0x10]!
    // 0xa52288: mov             x0, x2
    // 0xa5228c: r0 = GDT[cid_x0 + 0x490]()
    //     0xa5228c: add             lr, x0, #0x490
    //     0xa52290: ldr             lr, [x21, lr, lsl #3]
    //     0xa52294: blr             lr
    // 0xa52298: add             SP, SP, #0x10
    // 0xa5229c: ldr             x0, [fp, #0x10]
    // 0xa522a0: LoadField: r1 = r0->field_1f
    //     0xa522a0: ldur            w1, [x0, #0x1f]
    // 0xa522a4: DecompressPointer r1
    //     0xa522a4: add             x1, x1, HEAP, lsl #32
    // 0xa522a8: r16 = Sentinel
    //     0xa522a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa522ac: cmp             w1, w16
    // 0xa522b0: b.eq            #0xa522e0
    // 0xa522b4: SaveReg r1
    //     0xa522b4: str             x1, [SP, #-8]!
    // 0xa522b8: r0 = dispose()
    //     0xa522b8: bl              #0x9c2694  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::dispose
    // 0xa522bc: add             SP, SP, #8
    // 0xa522c0: r0 = Null
    //     0xa522c0: mov             x0, NULL
    // 0xa522c4: LeaveFrame
    //     0xa522c4: mov             SP, fp
    //     0xa522c8: ldp             fp, lr, [SP], #0x10
    // 0xa522cc: ret
    //     0xa522cc: ret             
    // 0xa522d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa522d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa522d4: b               #0xa521c0
    // 0xa522d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa522d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa522dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa522dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa522e0: r9 = delegate
    //     0xa522e0: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b6a0] Field <_ZoomExitTransitionState@789490068.delegate>: late (offset: 0x20)
    //     0xa522e4: ldr             x9, [x9, #0x6a0]
    // 0xa522e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa522e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3293, size: 0x20, field offset: 0x14
//   transformed mixin,
abstract class __ZoomEnterTransitionState&State&_ZoomTransitionBase extends State<_ZoomEnterTransition>
     with _ZoomTransitionBase {

  late Animation<double> scaleTransition; // offset: 0x1c
  late Animation<double> fadeTransition; // offset: 0x18

  [closure] void onAnimationStatusChange(dynamic, AnimationStatus) {
    // ** addr: 0x7b7e44, size: 0x4c
    // 0x7b7e44: EnterFrame
    //     0x7b7e44: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7e48: mov             fp, SP
    // 0x7b7e4c: ldr             x0, [fp, #0x18]
    // 0x7b7e50: LoadField: r1 = r0->field_17
    //     0x7b7e50: ldur            w1, [x0, #0x17]
    // 0x7b7e54: DecompressPointer r1
    //     0x7b7e54: add             x1, x1, HEAP, lsl #32
    // 0x7b7e58: CheckStackOverflow
    //     0x7b7e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7e5c: cmp             SP, x16
    //     0x7b7e60: b.ls            #0x7b7e88
    // 0x7b7e64: LoadField: r0 = r1->field_f
    //     0x7b7e64: ldur            w0, [x1, #0xf]
    // 0x7b7e68: DecompressPointer r0
    //     0x7b7e68: add             x0, x0, HEAP, lsl #32
    // 0x7b7e6c: ldr             x16, [fp, #0x10]
    // 0x7b7e70: stp             x16, x0, [SP, #-0x10]!
    // 0x7b7e74: r0 = onAnimationStatusChange()
    //     0x7b7e74: bl              #0x7b7e90  ; [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange
    // 0x7b7e78: add             SP, SP, #0x10
    // 0x7b7e7c: LeaveFrame
    //     0x7b7e7c: mov             SP, fp
    //     0x7b7e80: ldp             fp, lr, [SP], #0x10
    // 0x7b7e84: ret
    //     0x7b7e84: ret             
    // 0x7b7e88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7e88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7e8c: b               #0x7b7e64
  }
  _ onAnimationStatusChange(/* No info */) {
    // ** addr: 0x7b7e90, size: 0xc4
    // 0x7b7e90: EnterFrame
    //     0x7b7e90: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7e94: mov             fp, SP
    // 0x7b7e98: CheckStackOverflow
    //     0x7b7e98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7e9c: cmp             SP, x16
    //     0x7b7ea0: b.ls            #0x7b7f48
    // 0x7b7ea4: ldr             x0, [fp, #0x10]
    // 0x7b7ea8: LoadField: r1 = r0->field_7
    //     0x7b7ea8: ldur            x1, [x0, #7]
    // 0x7b7eac: cmp             x1, #1
    // 0x7b7eb0: b.gt            #0x7b7ec4
    // 0x7b7eb4: cmp             x1, #0
    // 0x7b7eb8: b.gt            #0x7b7ecc
    // 0x7b7ebc: ldr             x0, [fp, #0x18]
    // 0x7b7ec0: b               #0x7b7f10
    // 0x7b7ec4: cmp             x1, #2
    // 0x7b7ec8: b.gt            #0x7b7f0c
    // 0x7b7ecc: ldr             x0, [fp, #0x18]
    // 0x7b7ed0: LoadField: r1 = r0->field_13
    //     0x7b7ed0: ldur            w1, [x0, #0x13]
    // 0x7b7ed4: DecompressPointer r1
    //     0x7b7ed4: add             x1, x1, HEAP, lsl #32
    // 0x7b7ed8: LoadField: r2 = r0->field_b
    //     0x7b7ed8: ldur            w2, [x0, #0xb]
    // 0x7b7edc: DecompressPointer r2
    //     0x7b7edc: add             x2, x2, HEAP, lsl #32
    // 0x7b7ee0: cmp             w2, NULL
    // 0x7b7ee4: b.eq            #0x7b7f50
    // 0x7b7ee8: LoadField: r0 = r1->field_23
    //     0x7b7ee8: ldur            w0, [x1, #0x23]
    // 0x7b7eec: DecompressPointer r0
    //     0x7b7eec: add             x0, x0, HEAP, lsl #32
    // 0x7b7ef0: tbz             w0, #4, #0x7b7f38
    // 0x7b7ef4: r0 = true
    //     0x7b7ef4: add             x0, NULL, #0x20  ; true
    // 0x7b7ef8: StoreField: r1->field_23 = r0
    //     0x7b7ef8: stur            w0, [x1, #0x23]
    // 0x7b7efc: SaveReg r1
    //     0x7b7efc: str             x1, [SP, #-8]!
    // 0x7b7f00: r0 = notifyListeners()
    //     0x7b7f00: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b7f04: add             SP, SP, #8
    // 0x7b7f08: b               #0x7b7f38
    // 0x7b7f0c: ldr             x0, [fp, #0x18]
    // 0x7b7f10: LoadField: r1 = r0->field_13
    //     0x7b7f10: ldur            w1, [x0, #0x13]
    // 0x7b7f14: DecompressPointer r1
    //     0x7b7f14: add             x1, x1, HEAP, lsl #32
    // 0x7b7f18: LoadField: r0 = r1->field_23
    //     0x7b7f18: ldur            w0, [x1, #0x23]
    // 0x7b7f1c: DecompressPointer r0
    //     0x7b7f1c: add             x0, x0, HEAP, lsl #32
    // 0x7b7f20: tbnz            w0, #4, #0x7b7f38
    // 0x7b7f24: r0 = false
    //     0x7b7f24: add             x0, NULL, #0x30  ; false
    // 0x7b7f28: StoreField: r1->field_23 = r0
    //     0x7b7f28: stur            w0, [x1, #0x23]
    // 0x7b7f2c: SaveReg r1
    //     0x7b7f2c: str             x1, [SP, #-8]!
    // 0x7b7f30: r0 = notifyListeners()
    //     0x7b7f30: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b7f34: add             SP, SP, #8
    // 0x7b7f38: r0 = Null
    //     0x7b7f38: mov             x0, NULL
    // 0x7b7f3c: LeaveFrame
    //     0x7b7f3c: mov             SP, fp
    //     0x7b7f40: ldp             fp, lr, [SP], #0x10
    // 0x7b7f44: ret
    //     0x7b7f44: ret             
    // 0x7b7f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7f4c: b               #0x7b7ea4
    // 0x7b7f50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b7f50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onAnimationValueChange(dynamic) {
    // ** addr: 0x7b7fb8, size: 0x48
    // 0x7b7fb8: EnterFrame
    //     0x7b7fb8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7fbc: mov             fp, SP
    // 0x7b7fc0: ldr             x0, [fp, #0x10]
    // 0x7b7fc4: LoadField: r1 = r0->field_17
    //     0x7b7fc4: ldur            w1, [x0, #0x17]
    // 0x7b7fc8: DecompressPointer r1
    //     0x7b7fc8: add             x1, x1, HEAP, lsl #32
    // 0x7b7fcc: CheckStackOverflow
    //     0x7b7fcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7fd0: cmp             SP, x16
    //     0x7b7fd4: b.ls            #0x7b7ff8
    // 0x7b7fd8: LoadField: r0 = r1->field_f
    //     0x7b7fd8: ldur            w0, [x1, #0xf]
    // 0x7b7fdc: DecompressPointer r0
    //     0x7b7fdc: add             x0, x0, HEAP, lsl #32
    // 0x7b7fe0: SaveReg r0
    //     0x7b7fe0: str             x0, [SP, #-8]!
    // 0x7b7fe4: r0 = onAnimationValueChange()
    //     0x7b7fe4: bl              #0x7b8000  ; [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationValueChange
    // 0x7b7fe8: add             SP, SP, #8
    // 0x7b7fec: LeaveFrame
    //     0x7b7fec: mov             SP, fp
    //     0x7b7ff0: ldp             fp, lr, [SP], #0x10
    // 0x7b7ff4: ret
    //     0x7b7ff4: ret             
    // 0x7b7ff8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7ff8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7ffc: b               #0x7b7fd8
  }
  _ onAnimationValueChange(/* No info */) {
    // ** addr: 0x7b8000, size: 0x190
    // 0x7b8000: EnterFrame
    //     0x7b8000: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8004: mov             fp, SP
    // 0x7b8008: CheckStackOverflow
    //     0x7b8008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b800c: cmp             SP, x16
    //     0x7b8010: b.ls            #0x7b816c
    // 0x7b8014: ldr             x0, [fp, #0x10]
    // 0x7b8018: LoadField: r1 = r0->field_1b
    //     0x7b8018: ldur            w1, [x0, #0x1b]
    // 0x7b801c: DecompressPointer r1
    //     0x7b801c: add             x1, x1, HEAP, lsl #32
    // 0x7b8020: r16 = Sentinel
    //     0x7b8020: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b8024: cmp             w1, w16
    // 0x7b8028: b.eq            #0x7b8174
    // 0x7b802c: LoadField: r2 = r1->field_f
    //     0x7b802c: ldur            w2, [x1, #0xf]
    // 0x7b8030: DecompressPointer r2
    //     0x7b8030: add             x2, x2, HEAP, lsl #32
    // 0x7b8034: LoadField: r3 = r1->field_b
    //     0x7b8034: ldur            w3, [x1, #0xb]
    // 0x7b8038: DecompressPointer r3
    //     0x7b8038: add             x3, x3, HEAP, lsl #32
    // 0x7b803c: stp             x3, x2, [SP, #-0x10]!
    // 0x7b8040: r0 = evaluate()
    //     0x7b8040: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0x7b8044: add             SP, SP, #0x10
    // 0x7b8048: LoadField: d0 = r0->field_7
    //     0x7b8048: ldur            d0, [x0, #7]
    // 0x7b804c: d1 = 1.000000
    //     0x7b804c: fmov            d1, #1.00000000
    // 0x7b8050: fcmp            d0, d1
    // 0x7b8054: b.vs            #0x7b8120
    // 0x7b8058: b.ne            #0x7b8120
    // 0x7b805c: ldr             x1, [fp, #0x10]
    // 0x7b8060: LoadField: r0 = r1->field_17
    //     0x7b8060: ldur            w0, [x1, #0x17]
    // 0x7b8064: DecompressPointer r0
    //     0x7b8064: add             x0, x0, HEAP, lsl #32
    // 0x7b8068: r16 = Sentinel
    //     0x7b8068: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b806c: cmp             w0, w16
    // 0x7b8070: b.eq            #0x7b8180
    // 0x7b8074: r2 = LoadClassIdInstr(r0)
    //     0x7b8074: ldur            x2, [x0, #-1]
    //     0x7b8078: ubfx            x2, x2, #0xc, #0x14
    // 0x7b807c: SaveReg r0
    //     0x7b807c: str             x0, [SP, #-8]!
    // 0x7b8080: mov             x0, x2
    // 0x7b8084: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b8084: add             lr, x0, #0xb7c
    //     0x7b8088: ldr             lr, [x21, lr, lsl #3]
    //     0x7b808c: blr             lr
    // 0x7b8090: add             SP, SP, #8
    // 0x7b8094: LoadField: d0 = r0->field_7
    //     0x7b8094: ldur            d0, [x0, #7]
    // 0x7b8098: d1 = 0.000000
    //     0x7b8098: eor             v1.16b, v1.16b, v1.16b
    // 0x7b809c: fcmp            d0, d1
    // 0x7b80a0: b.vs            #0x7b80a8
    // 0x7b80a4: b.eq            #0x7b80e8
    // 0x7b80a8: ldr             x1, [fp, #0x10]
    // 0x7b80ac: LoadField: r0 = r1->field_17
    //     0x7b80ac: ldur            w0, [x1, #0x17]
    // 0x7b80b0: DecompressPointer r0
    //     0x7b80b0: add             x0, x0, HEAP, lsl #32
    // 0x7b80b4: r2 = LoadClassIdInstr(r0)
    //     0x7b80b4: ldur            x2, [x0, #-1]
    //     0x7b80b8: ubfx            x2, x2, #0xc, #0x14
    // 0x7b80bc: SaveReg r0
    //     0x7b80bc: str             x0, [SP, #-8]!
    // 0x7b80c0: mov             x0, x2
    // 0x7b80c4: r0 = GDT[cid_x0 + 0xb7c]()
    //     0x7b80c4: add             lr, x0, #0xb7c
    //     0x7b80c8: ldr             lr, [x21, lr, lsl #3]
    //     0x7b80cc: blr             lr
    // 0x7b80d0: add             SP, SP, #8
    // 0x7b80d4: LoadField: d0 = r0->field_7
    //     0x7b80d4: ldur            d0, [x0, #7]
    // 0x7b80d8: d1 = 1.000000
    //     0x7b80d8: fmov            d1, #1.00000000
    // 0x7b80dc: fcmp            d0, d1
    // 0x7b80e0: b.vs            #0x7b8118
    // 0x7b80e4: b.ne            #0x7b8118
    // 0x7b80e8: ldr             x0, [fp, #0x10]
    // 0x7b80ec: LoadField: r1 = r0->field_13
    //     0x7b80ec: ldur            w1, [x0, #0x13]
    // 0x7b80f0: DecompressPointer r1
    //     0x7b80f0: add             x1, x1, HEAP, lsl #32
    // 0x7b80f4: LoadField: r0 = r1->field_23
    //     0x7b80f4: ldur            w0, [x1, #0x23]
    // 0x7b80f8: DecompressPointer r0
    //     0x7b80f8: add             x0, x0, HEAP, lsl #32
    // 0x7b80fc: tbnz            w0, #4, #0x7b815c
    // 0x7b8100: r0 = false
    //     0x7b8100: add             x0, NULL, #0x30  ; false
    // 0x7b8104: StoreField: r1->field_23 = r0
    //     0x7b8104: stur            w0, [x1, #0x23]
    // 0x7b8108: SaveReg r1
    //     0x7b8108: str             x1, [SP, #-8]!
    // 0x7b810c: r0 = notifyListeners()
    //     0x7b810c: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b8110: add             SP, SP, #8
    // 0x7b8114: b               #0x7b815c
    // 0x7b8118: ldr             x0, [fp, #0x10]
    // 0x7b811c: b               #0x7b8124
    // 0x7b8120: ldr             x0, [fp, #0x10]
    // 0x7b8124: LoadField: r1 = r0->field_13
    //     0x7b8124: ldur            w1, [x0, #0x13]
    // 0x7b8128: DecompressPointer r1
    //     0x7b8128: add             x1, x1, HEAP, lsl #32
    // 0x7b812c: LoadField: r2 = r0->field_b
    //     0x7b812c: ldur            w2, [x0, #0xb]
    // 0x7b8130: DecompressPointer r2
    //     0x7b8130: add             x2, x2, HEAP, lsl #32
    // 0x7b8134: cmp             w2, NULL
    // 0x7b8138: b.eq            #0x7b818c
    // 0x7b813c: LoadField: r0 = r1->field_23
    //     0x7b813c: ldur            w0, [x1, #0x23]
    // 0x7b8140: DecompressPointer r0
    //     0x7b8140: add             x0, x0, HEAP, lsl #32
    // 0x7b8144: tbz             w0, #4, #0x7b815c
    // 0x7b8148: r0 = true
    //     0x7b8148: add             x0, NULL, #0x20  ; true
    // 0x7b814c: StoreField: r1->field_23 = r0
    //     0x7b814c: stur            w0, [x1, #0x23]
    // 0x7b8150: SaveReg r1
    //     0x7b8150: str             x1, [SP, #-8]!
    // 0x7b8154: r0 = notifyListeners()
    //     0x7b8154: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b8158: add             SP, SP, #8
    // 0x7b815c: r0 = Null
    //     0x7b815c: mov             x0, NULL
    // 0x7b8160: LeaveFrame
    //     0x7b8160: mov             SP, fp
    //     0x7b8164: ldp             fp, lr, [SP], #0x10
    // 0x7b8168: ret
    //     0x7b8168: ret             
    // 0x7b816c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b816c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8170: b               #0x7b8014
    // 0x7b8174: r9 = scaleTransition
    //     0x7b8174: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b780] Field <__ZoomEnterTransitionState&State&_ZoomTransitionBase@789490068.scaleTransition>: late (offset: 0x1c)
    //     0x7b8178: ldr             x9, [x9, #0x780]
    // 0x7b817c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b817c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b8180: r9 = fadeTransition
    //     0x7b8180: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b788] Field <__ZoomEnterTransitionState&State&_ZoomTransitionBase@789490068.fadeTransition>: late (offset: 0x18)
    //     0x7b8184: ldr             x9, [x9, #0x788]
    // 0x7b8188: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x7b8188: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x7b818c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b818c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3294, size: 0x24, field offset: 0x20
class _ZoomEnterTransitionState extends __ZoomEnterTransitionState&State&_ZoomTransitionBase {

  late _ZoomEnterTransitionPainter delegate; // offset: 0x20
  static late final Animatable<double> _fadeInTransition; // offset: 0xdd4
  static late final Animatable<double> _scaleDownTransition; // offset: 0xdd8
  static late final Animatable<double> _scaleUpTransition; // offset: 0xddc
  static late final Animatable<double?> _scrimOpacityTween; // offset: 0xde0

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7b6e48, size: 0x2a4
    // 0x7b6e48: EnterFrame
    //     0x7b6e48: stp             fp, lr, [SP, #-0x10]!
    //     0x7b6e4c: mov             fp, SP
    // 0x7b6e50: AllocStack(0x28)
    //     0x7b6e50: sub             SP, SP, #0x28
    // 0x7b6e54: CheckStackOverflow
    //     0x7b6e54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b6e58: cmp             SP, x16
    //     0x7b6e5c: b.ls            #0x7b70b8
    // 0x7b6e60: ldr             x0, [fp, #0x10]
    // 0x7b6e64: r2 = Null
    //     0x7b6e64: mov             x2, NULL
    // 0x7b6e68: r1 = Null
    //     0x7b6e68: mov             x1, NULL
    // 0x7b6e6c: r4 = 59
    //     0x7b6e6c: mov             x4, #0x3b
    // 0x7b6e70: branchIfSmi(r0, 0x7b6e7c)
    //     0x7b6e70: tbz             w0, #0, #0x7b6e7c
    // 0x7b6e74: r4 = LoadClassIdInstr(r0)
    //     0x7b6e74: ldur            x4, [x0, #-1]
    //     0x7b6e78: ubfx            x4, x4, #0xc, #0x14
    // 0x7b6e7c: r17 = 4132
    //     0x7b6e7c: mov             x17, #0x1024
    // 0x7b6e80: cmp             x4, x17
    // 0x7b6e84: b.eq            #0x7b6e9c
    // 0x7b6e88: r8 = _ZoomEnterTransition
    //     0x7b6e88: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b798] Type: _ZoomEnterTransition
    //     0x7b6e8c: ldr             x8, [x8, #0x798]
    // 0x7b6e90: r3 = Null
    //     0x7b6e90: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b7a0] Null
    //     0x7b6e94: ldr             x3, [x3, #0x7a0]
    // 0x7b6e98: r0 = _ZoomEnterTransition()
    //     0x7b6e98: bl              #0x7b7e20  ; IsType__ZoomEnterTransition_Stub
    // 0x7b6e9c: ldr             x0, [fp, #0x10]
    // 0x7b6ea0: LoadField: r1 = r0->field_17
    //     0x7b6ea0: ldur            w1, [x0, #0x17]
    // 0x7b6ea4: DecompressPointer r1
    //     0x7b6ea4: add             x1, x1, HEAP, lsl #32
    // 0x7b6ea8: ldr             x2, [fp, #0x18]
    // 0x7b6eac: LoadField: r3 = r2->field_b
    //     0x7b6eac: ldur            w3, [x2, #0xb]
    // 0x7b6eb0: DecompressPointer r3
    //     0x7b6eb0: add             x3, x3, HEAP, lsl #32
    // 0x7b6eb4: cmp             w3, NULL
    // 0x7b6eb8: b.eq            #0x7b70c0
    // 0x7b6ebc: LoadField: r4 = r3->field_17
    //     0x7b6ebc: ldur            w4, [x3, #0x17]
    // 0x7b6ec0: DecompressPointer r4
    //     0x7b6ec0: add             x4, x4, HEAP, lsl #32
    // 0x7b6ec4: cmp             w1, w4
    // 0x7b6ec8: b.ne            #0x7b6ee4
    // 0x7b6ecc: LoadField: r1 = r0->field_b
    //     0x7b6ecc: ldur            w1, [x0, #0xb]
    // 0x7b6ed0: DecompressPointer r1
    //     0x7b6ed0: add             x1, x1, HEAP, lsl #32
    // 0x7b6ed4: LoadField: r4 = r3->field_b
    //     0x7b6ed4: ldur            w4, [x3, #0xb]
    // 0x7b6ed8: DecompressPointer r4
    //     0x7b6ed8: add             x4, x4, HEAP, lsl #32
    // 0x7b6edc: cmp             w1, w4
    // 0x7b6ee0: b.eq            #0x7b706c
    // 0x7b6ee4: LoadField: r1 = r0->field_b
    //     0x7b6ee4: ldur            w1, [x0, #0xb]
    // 0x7b6ee8: DecompressPointer r1
    //     0x7b6ee8: add             x1, x1, HEAP, lsl #32
    // 0x7b6eec: stur            x1, [fp, #-8]
    // 0x7b6ef0: r1 = 1
    //     0x7b6ef0: mov             x1, #1
    // 0x7b6ef4: r0 = AllocateContext()
    //     0x7b6ef4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b6ef8: mov             x1, x0
    // 0x7b6efc: ldr             x0, [fp, #0x18]
    // 0x7b6f00: StoreField: r1->field_f = r0
    //     0x7b6f00: stur            w0, [x1, #0xf]
    // 0x7b6f04: mov             x2, x1
    // 0x7b6f08: r1 = Function 'onAnimationValueChange':.
    //     0x7b6f08: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b770] AnonymousClosure: (0x7b7fb8), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationValueChange (0x7b8000)
    //     0x7b6f0c: ldr             x1, [x1, #0x770]
    // 0x7b6f10: r0 = AllocateClosure()
    //     0x7b6f10: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6f14: ldur            x1, [fp, #-8]
    // 0x7b6f18: r2 = LoadClassIdInstr(r1)
    //     0x7b6f18: ldur            x2, [x1, #-1]
    //     0x7b6f1c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b6f20: stp             x0, x1, [SP, #-0x10]!
    // 0x7b6f24: mov             x0, x2
    // 0x7b6f28: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x7b6f28: mov             x17, #0xc2d6
    //     0x7b6f2c: add             lr, x0, x17
    //     0x7b6f30: ldr             lr, [x21, lr, lsl #3]
    //     0x7b6f34: blr             lr
    // 0x7b6f38: add             SP, SP, #0x10
    // 0x7b6f3c: r1 = 1
    //     0x7b6f3c: mov             x1, #1
    // 0x7b6f40: r0 = AllocateContext()
    //     0x7b6f40: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b6f44: mov             x1, x0
    // 0x7b6f48: ldr             x0, [fp, #0x18]
    // 0x7b6f4c: StoreField: r1->field_f = r0
    //     0x7b6f4c: stur            w0, [x1, #0xf]
    // 0x7b6f50: mov             x2, x1
    // 0x7b6f54: r1 = Function 'onAnimationStatusChange':.
    //     0x7b6f54: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b778] AnonymousClosure: (0x7b7e44), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange (0x7b7e90)
    //     0x7b6f58: ldr             x1, [x1, #0x778]
    // 0x7b6f5c: r0 = AllocateClosure()
    //     0x7b6f5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b6f60: mov             x1, x0
    // 0x7b6f64: ldur            x0, [fp, #-8]
    // 0x7b6f68: r2 = LoadClassIdInstr(r0)
    //     0x7b6f68: ldur            x2, [x0, #-1]
    //     0x7b6f6c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b6f70: stp             x1, x0, [SP, #-0x10]!
    // 0x7b6f74: mov             x0, x2
    // 0x7b6f78: r0 = GDT[cid_x0 + 0x490]()
    //     0x7b6f78: add             lr, x0, #0x490
    //     0x7b6f7c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b6f80: blr             lr
    // 0x7b6f84: add             SP, SP, #0x10
    // 0x7b6f88: ldr             x16, [fp, #0x18]
    // 0x7b6f8c: SaveReg r16
    //     0x7b6f8c: str             x16, [SP, #-8]!
    // 0x7b6f90: r0 = _updateAnimations()
    //     0x7b6f90: bl              #0x7b73d8  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_updateAnimations
    // 0x7b6f94: add             SP, SP, #8
    // 0x7b6f98: ldr             x0, [fp, #0x18]
    // 0x7b6f9c: LoadField: r1 = r0->field_1f
    //     0x7b6f9c: ldur            w1, [x0, #0x1f]
    // 0x7b6fa0: DecompressPointer r1
    //     0x7b6fa0: add             x1, x1, HEAP, lsl #32
    // 0x7b6fa4: r16 = Sentinel
    //     0x7b6fa4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b6fa8: cmp             w1, w16
    // 0x7b6fac: b.eq            #0x7b70c4
    // 0x7b6fb0: SaveReg r1
    //     0x7b6fb0: str             x1, [SP, #-8]!
    // 0x7b6fb4: r0 = dispose()
    //     0x7b6fb4: bl              #0x9c24d8  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::dispose
    // 0x7b6fb8: add             SP, SP, #8
    // 0x7b6fbc: ldr             x0, [fp, #0x18]
    // 0x7b6fc0: LoadField: r1 = r0->field_b
    //     0x7b6fc0: ldur            w1, [x0, #0xb]
    // 0x7b6fc4: DecompressPointer r1
    //     0x7b6fc4: add             x1, x1, HEAP, lsl #32
    // 0x7b6fc8: cmp             w1, NULL
    // 0x7b6fcc: b.eq            #0x7b70d0
    // 0x7b6fd0: LoadField: r2 = r1->field_17
    //     0x7b6fd0: ldur            w2, [x1, #0x17]
    // 0x7b6fd4: DecompressPointer r2
    //     0x7b6fd4: add             x2, x2, HEAP, lsl #32
    // 0x7b6fd8: stur            x2, [fp, #-0x20]
    // 0x7b6fdc: LoadField: r3 = r0->field_17
    //     0x7b6fdc: ldur            w3, [x0, #0x17]
    // 0x7b6fe0: DecompressPointer r3
    //     0x7b6fe0: add             x3, x3, HEAP, lsl #32
    // 0x7b6fe4: r16 = Sentinel
    //     0x7b6fe4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b6fe8: cmp             w3, w16
    // 0x7b6fec: b.eq            #0x7b70d4
    // 0x7b6ff0: stur            x3, [fp, #-0x18]
    // 0x7b6ff4: LoadField: r4 = r0->field_1b
    //     0x7b6ff4: ldur            w4, [x0, #0x1b]
    // 0x7b6ff8: DecompressPointer r4
    //     0x7b6ff8: add             x4, x4, HEAP, lsl #32
    // 0x7b6ffc: r16 = Sentinel
    //     0x7b6ffc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b7000: cmp             w4, w16
    // 0x7b7004: b.eq            #0x7b70e0
    // 0x7b7008: stur            x4, [fp, #-0x10]
    // 0x7b700c: LoadField: r5 = r1->field_b
    //     0x7b700c: ldur            w5, [x1, #0xb]
    // 0x7b7010: DecompressPointer r5
    //     0x7b7010: add             x5, x5, HEAP, lsl #32
    // 0x7b7014: stur            x5, [fp, #-8]
    // 0x7b7018: r0 = _ZoomEnterTransitionPainter()
    //     0x7b7018: bl              #0x7b73cc  ; Allocate_ZoomEnterTransitionPainterStub -> _ZoomEnterTransitionPainter (size=0x40)
    // 0x7b701c: stur            x0, [fp, #-0x28]
    // 0x7b7020: ldur            x16, [fp, #-8]
    // 0x7b7024: stp             x16, x0, [SP, #-0x10]!
    // 0x7b7028: ldur            x16, [fp, #-0x18]
    // 0x7b702c: ldur            lr, [fp, #-0x20]
    // 0x7b7030: stp             lr, x16, [SP, #-0x10]!
    // 0x7b7034: ldur            x16, [fp, #-0x10]
    // 0x7b7038: SaveReg r16
    //     0x7b7038: str             x16, [SP, #-8]!
    // 0x7b703c: r0 = _ZoomEnterTransitionPainter()
    //     0x7b703c: bl              #0x7b70ec  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_ZoomEnterTransitionPainter
    // 0x7b7040: add             SP, SP, #0x28
    // 0x7b7044: ldur            x0, [fp, #-0x28]
    // 0x7b7048: ldr             x1, [fp, #0x18]
    // 0x7b704c: StoreField: r1->field_1f = r0
    //     0x7b704c: stur            w0, [x1, #0x1f]
    //     0x7b7050: ldurb           w16, [x1, #-1]
    //     0x7b7054: ldurb           w17, [x0, #-1]
    //     0x7b7058: and             x16, x17, x16, lsr #2
    //     0x7b705c: tst             x16, HEAP, lsr #32
    //     0x7b7060: b.eq            #0x7b7068
    //     0x7b7064: bl              #0xd6826c
    // 0x7b7068: b               #0x7b7070
    // 0x7b706c: mov             x1, x2
    // 0x7b7070: LoadField: r2 = r1->field_7
    //     0x7b7070: ldur            w2, [x1, #7]
    // 0x7b7074: DecompressPointer r2
    //     0x7b7074: add             x2, x2, HEAP, lsl #32
    // 0x7b7078: ldr             x0, [fp, #0x10]
    // 0x7b707c: r1 = Null
    //     0x7b707c: mov             x1, NULL
    // 0x7b7080: cmp             w2, NULL
    // 0x7b7084: b.eq            #0x7b70a8
    // 0x7b7088: LoadField: r4 = r2->field_17
    //     0x7b7088: ldur            w4, [x2, #0x17]
    // 0x7b708c: DecompressPointer r4
    //     0x7b708c: add             x4, x4, HEAP, lsl #32
    // 0x7b7090: r8 = X0 bound StatefulWidget
    //     0x7b7090: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7b7094: ldr             x8, [x8, #0x858]
    // 0x7b7098: LoadField: r9 = r4->field_7
    //     0x7b7098: ldur            x9, [x4, #7]
    // 0x7b709c: r3 = Null
    //     0x7b709c: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b7b0] Null
    //     0x7b70a0: ldr             x3, [x3, #0x7b0]
    // 0x7b70a4: blr             x9
    // 0x7b70a8: r0 = Null
    //     0x7b70a8: mov             x0, NULL
    // 0x7b70ac: LeaveFrame
    //     0x7b70ac: mov             SP, fp
    //     0x7b70b0: ldp             fp, lr, [SP], #0x10
    // 0x7b70b4: ret
    //     0x7b70b4: ret             
    // 0x7b70b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b70b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b70bc: b               #0x7b6e60
    // 0x7b70c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b70c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b70c4: r9 = delegate
    //     0x7b70c4: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b768] Field <_ZoomEnterTransitionState@789490068.delegate>: late (offset: 0x20)
    //     0x7b70c8: ldr             x9, [x9, #0x768]
    // 0x7b70cc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b70cc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b70d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b70d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b70d4: r9 = fadeTransition
    //     0x7b70d4: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b788] Field <__ZoomEnterTransitionState&State&_ZoomTransitionBase@789490068.fadeTransition>: late (offset: 0x18)
    //     0x7b70d8: ldr             x9, [x9, #0x788]
    // 0x7b70dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b70dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7b70e0: r9 = scaleTransition
    //     0x7b70e0: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b780] Field <__ZoomEnterTransitionState&State&_ZoomTransitionBase@789490068.scaleTransition>: late (offset: 0x1c)
    //     0x7b70e4: ldr             x9, [x9, #0x780]
    // 0x7b70e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b70e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateAnimations(/* No info */) {
    // ** addr: 0x7b73d8, size: 0x270
    // 0x7b73d8: EnterFrame
    //     0x7b73d8: stp             fp, lr, [SP, #-0x10]!
    //     0x7b73dc: mov             fp, SP
    // 0x7b73e0: AllocStack(0x8)
    //     0x7b73e0: sub             SP, SP, #8
    // 0x7b73e4: CheckStackOverflow
    //     0x7b73e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b73e8: cmp             SP, x16
    //     0x7b73ec: b.ls            #0x7b7628
    // 0x7b73f0: ldr             x0, [fp, #0x10]
    // 0x7b73f4: LoadField: r1 = r0->field_b
    //     0x7b73f4: ldur            w1, [x0, #0xb]
    // 0x7b73f8: DecompressPointer r1
    //     0x7b73f8: add             x1, x1, HEAP, lsl #32
    // 0x7b73fc: cmp             w1, NULL
    // 0x7b7400: b.eq            #0x7b7630
    // 0x7b7404: LoadField: r2 = r1->field_17
    //     0x7b7404: ldur            w2, [x1, #0x17]
    // 0x7b7408: DecompressPointer r2
    //     0x7b7408: add             x2, x2, HEAP, lsl #32
    // 0x7b740c: tbnz            w2, #4, #0x7b7420
    // 0x7b7410: mov             x1, x0
    // 0x7b7414: r0 = Instance__AlwaysCompleteAnimation
    //     0x7b7414: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c8c0] Obj!_AlwaysCompleteAnimation<double>@b4fcd1
    //     0x7b7418: ldr             x0, [x0, #0x8c0]
    // 0x7b741c: b               #0x7b7470
    // 0x7b7420: r0 = InitLateStaticField(0xdd4) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_fadeInTransition
    //     0x7b7420: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b7424: ldr             x0, [x0, #0x1ba8]
    //     0x7b7428: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b742c: cmp             w0, w16
    //     0x7b7430: b.ne            #0x7b7440
    //     0x7b7434: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b7c0] Field <_ZoomEnterTransitionState@789490068._fadeInTransition@789490068>: static late final (offset: 0xdd4)
    //     0x7b7438: ldr             x2, [x2, #0x7c0]
    //     0x7b743c: bl              #0xd67cdc
    // 0x7b7440: mov             x1, x0
    // 0x7b7444: ldr             x0, [fp, #0x10]
    // 0x7b7448: LoadField: r2 = r0->field_b
    //     0x7b7448: ldur            w2, [x0, #0xb]
    // 0x7b744c: DecompressPointer r2
    //     0x7b744c: add             x2, x2, HEAP, lsl #32
    // 0x7b7450: cmp             w2, NULL
    // 0x7b7454: b.eq            #0x7b7634
    // 0x7b7458: LoadField: r3 = r2->field_b
    //     0x7b7458: ldur            w3, [x2, #0xb]
    // 0x7b745c: DecompressPointer r3
    //     0x7b745c: add             x3, x3, HEAP, lsl #32
    // 0x7b7460: stp             x3, x1, [SP, #-0x10]!
    // 0x7b7464: r0 = animate()
    //     0x7b7464: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b7468: add             SP, SP, #0x10
    // 0x7b746c: ldr             x1, [fp, #0x10]
    // 0x7b7470: StoreField: r1->field_17 = r0
    //     0x7b7470: stur            w0, [x1, #0x17]
    //     0x7b7474: tbz             w0, #0, #0x7b7490
    //     0x7b7478: ldurb           w16, [x1, #-1]
    //     0x7b747c: ldurb           w17, [x0, #-1]
    //     0x7b7480: and             x16, x17, x16, lsr #2
    //     0x7b7484: tst             x16, HEAP, lsr #32
    //     0x7b7488: b.eq            #0x7b7490
    //     0x7b748c: bl              #0xd6826c
    // 0x7b7490: LoadField: r0 = r1->field_b
    //     0x7b7490: ldur            w0, [x1, #0xb]
    // 0x7b7494: DecompressPointer r0
    //     0x7b7494: add             x0, x0, HEAP, lsl #32
    // 0x7b7498: cmp             w0, NULL
    // 0x7b749c: b.eq            #0x7b7638
    // 0x7b74a0: LoadField: r2 = r0->field_17
    //     0x7b74a0: ldur            w2, [x0, #0x17]
    // 0x7b74a4: DecompressPointer r2
    //     0x7b74a4: add             x2, x2, HEAP, lsl #32
    // 0x7b74a8: tbnz            w2, #4, #0x7b74d4
    // 0x7b74ac: r0 = InitLateStaticField(0xdd8) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_scaleDownTransition
    //     0x7b74ac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b74b0: ldr             x0, [x0, #0x1bb0]
    //     0x7b74b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b74b8: cmp             w0, w16
    //     0x7b74bc: b.ne            #0x7b74cc
    //     0x7b74c0: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b7c8] Field <_ZoomEnterTransitionState@789490068._scaleDownTransition@789490068>: static late final (offset: 0xdd8)
    //     0x7b74c4: ldr             x2, [x2, #0x7c8]
    //     0x7b74c8: bl              #0xd67cdc
    // 0x7b74cc: mov             x1, x0
    // 0x7b74d0: b               #0x7b74f8
    // 0x7b74d4: r0 = InitLateStaticField(0xddc) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_scaleUpTransition
    //     0x7b74d4: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b74d8: ldr             x0, [x0, #0x1bb8]
    //     0x7b74dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b74e0: cmp             w0, w16
    //     0x7b74e4: b.ne            #0x7b74f4
    //     0x7b74e8: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b7d0] Field <_ZoomEnterTransitionState@789490068._scaleUpTransition@789490068>: static late final (offset: 0xddc)
    //     0x7b74ec: ldr             x2, [x2, #0x7d0]
    //     0x7b74f0: bl              #0xd67cdc
    // 0x7b74f4: mov             x1, x0
    // 0x7b74f8: ldr             x0, [fp, #0x10]
    // 0x7b74fc: LoadField: r2 = r0->field_b
    //     0x7b74fc: ldur            w2, [x0, #0xb]
    // 0x7b7500: DecompressPointer r2
    //     0x7b7500: add             x2, x2, HEAP, lsl #32
    // 0x7b7504: cmp             w2, NULL
    // 0x7b7508: b.eq            #0x7b763c
    // 0x7b750c: LoadField: r3 = r2->field_b
    //     0x7b750c: ldur            w3, [x2, #0xb]
    // 0x7b7510: DecompressPointer r3
    //     0x7b7510: add             x3, x3, HEAP, lsl #32
    // 0x7b7514: stp             x3, x1, [SP, #-0x10]!
    // 0x7b7518: r0 = animate()
    //     0x7b7518: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x7b751c: add             SP, SP, #0x10
    // 0x7b7520: ldr             x1, [fp, #0x10]
    // 0x7b7524: StoreField: r1->field_1b = r0
    //     0x7b7524: stur            w0, [x1, #0x1b]
    //     0x7b7528: ldurb           w16, [x1, #-1]
    //     0x7b752c: ldurb           w17, [x0, #-1]
    //     0x7b7530: and             x16, x17, x16, lsr #2
    //     0x7b7534: tst             x16, HEAP, lsr #32
    //     0x7b7538: b.eq            #0x7b7540
    //     0x7b753c: bl              #0xd6826c
    // 0x7b7540: LoadField: r0 = r1->field_b
    //     0x7b7540: ldur            w0, [x1, #0xb]
    // 0x7b7544: DecompressPointer r0
    //     0x7b7544: add             x0, x0, HEAP, lsl #32
    // 0x7b7548: cmp             w0, NULL
    // 0x7b754c: b.eq            #0x7b7640
    // 0x7b7550: LoadField: r2 = r0->field_b
    //     0x7b7550: ldur            w2, [x0, #0xb]
    // 0x7b7554: DecompressPointer r2
    //     0x7b7554: add             x2, x2, HEAP, lsl #32
    // 0x7b7558: stur            x2, [fp, #-8]
    // 0x7b755c: r1 = 1
    //     0x7b755c: mov             x1, #1
    // 0x7b7560: r0 = AllocateContext()
    //     0x7b7560: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b7564: mov             x1, x0
    // 0x7b7568: ldr             x0, [fp, #0x10]
    // 0x7b756c: StoreField: r1->field_f = r0
    //     0x7b756c: stur            w0, [x1, #0xf]
    // 0x7b7570: mov             x2, x1
    // 0x7b7574: r1 = Function 'onAnimationValueChange':.
    //     0x7b7574: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b770] AnonymousClosure: (0x7b7fb8), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationValueChange (0x7b8000)
    //     0x7b7578: ldr             x1, [x1, #0x770]
    // 0x7b757c: r0 = AllocateClosure()
    //     0x7b757c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b7580: mov             x1, x0
    // 0x7b7584: ldur            x0, [fp, #-8]
    // 0x7b7588: r2 = LoadClassIdInstr(r0)
    //     0x7b7588: ldur            x2, [x0, #-1]
    //     0x7b758c: ubfx            x2, x2, #0xc, #0x14
    // 0x7b7590: stp             x1, x0, [SP, #-0x10]!
    // 0x7b7594: mov             x0, x2
    // 0x7b7598: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b7598: mov             x17, #0xc3ab
    //     0x7b759c: add             lr, x0, x17
    //     0x7b75a0: ldr             lr, [x21, lr, lsl #3]
    //     0x7b75a4: blr             lr
    // 0x7b75a8: add             SP, SP, #0x10
    // 0x7b75ac: ldr             x0, [fp, #0x10]
    // 0x7b75b0: LoadField: r1 = r0->field_b
    //     0x7b75b0: ldur            w1, [x0, #0xb]
    // 0x7b75b4: DecompressPointer r1
    //     0x7b75b4: add             x1, x1, HEAP, lsl #32
    // 0x7b75b8: cmp             w1, NULL
    // 0x7b75bc: b.eq            #0x7b7644
    // 0x7b75c0: LoadField: r2 = r1->field_b
    //     0x7b75c0: ldur            w2, [x1, #0xb]
    // 0x7b75c4: DecompressPointer r2
    //     0x7b75c4: add             x2, x2, HEAP, lsl #32
    // 0x7b75c8: stur            x2, [fp, #-8]
    // 0x7b75cc: r1 = 1
    //     0x7b75cc: mov             x1, #1
    // 0x7b75d0: r0 = AllocateContext()
    //     0x7b75d0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b75d4: mov             x1, x0
    // 0x7b75d8: ldr             x0, [fp, #0x10]
    // 0x7b75dc: StoreField: r1->field_f = r0
    //     0x7b75dc: stur            w0, [x1, #0xf]
    // 0x7b75e0: mov             x2, x1
    // 0x7b75e4: r1 = Function 'onAnimationStatusChange':.
    //     0x7b75e4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b778] AnonymousClosure: (0x7b7e44), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange (0x7b7e90)
    //     0x7b75e8: ldr             x1, [x1, #0x778]
    // 0x7b75ec: r0 = AllocateClosure()
    //     0x7b75ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b75f0: mov             x1, x0
    // 0x7b75f4: ldur            x0, [fp, #-8]
    // 0x7b75f8: r2 = LoadClassIdInstr(r0)
    //     0x7b75f8: ldur            x2, [x0, #-1]
    //     0x7b75fc: ubfx            x2, x2, #0xc, #0x14
    // 0x7b7600: stp             x1, x0, [SP, #-0x10]!
    // 0x7b7604: mov             x0, x2
    // 0x7b7608: r0 = GDT[cid_x0 + 0x80c]()
    //     0x7b7608: add             lr, x0, #0x80c
    //     0x7b760c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b7610: blr             lr
    // 0x7b7614: add             SP, SP, #0x10
    // 0x7b7618: r0 = Null
    //     0x7b7618: mov             x0, NULL
    // 0x7b761c: LeaveFrame
    //     0x7b761c: mov             SP, fp
    //     0x7b7620: ldp             fp, lr, [SP], #0x10
    // 0x7b7624: ret
    //     0x7b7624: ret             
    // 0x7b7628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b762c: b               #0x7b73f0
    // 0x7b7630: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b7630: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b7634: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b7634: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b7638: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b7638: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b763c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b763c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b7640: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b7640: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7b7644: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b7644: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static Animatable<double> _scaleUpTransition() {
    // ** addr: 0x7b7648, size: 0x80
    // 0x7b7648: EnterFrame
    //     0x7b7648: stp             fp, lr, [SP, #-0x10]!
    //     0x7b764c: mov             fp, SP
    // 0x7b7650: AllocStack(0x8)
    //     0x7b7650: sub             SP, SP, #8
    // 0x7b7654: CheckStackOverflow
    //     0x7b7654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7658: cmp             SP, x16
    //     0x7b765c: b.ls            #0x7b76c0
    // 0x7b7660: r1 = <double>
    //     0x7b7660: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7664: r0 = Tween()
    //     0x7b7664: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b7668: mov             x1, x0
    // 0x7b766c: r0 = 0.850000
    //     0x7b766c: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b7d8] 0.85
    //     0x7b7670: ldr             x0, [x0, #0x7d8]
    // 0x7b7674: stur            x1, [fp, #-8]
    // 0x7b7678: StoreField: r1->field_b = r0
    //     0x7b7678: stur            w0, [x1, #0xb]
    // 0x7b767c: r0 = 1.000000
    //     0x7b767c: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b7680: StoreField: r1->field_f = r0
    //     0x7b7680: stur            w0, [x1, #0xf]
    // 0x7b7684: r0 = InitLateStaticField(0xe00) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::_scaleCurveSequence
    //     0x7b7684: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b7688: ldr             x0, [x0, #0x1c00]
    //     0x7b768c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b7690: cmp             w0, w16
    //     0x7b7694: b.ne            #0x7b76a4
    //     0x7b7698: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b720] Field <_ZoomPageTransition@789490068._scaleCurveSequence@789490068>: static late final (offset: 0xe00)
    //     0x7b769c: ldr             x2, [x2, #0x720]
    //     0x7b76a0: bl              #0xd67cdc
    // 0x7b76a4: ldur            x16, [fp, #-8]
    // 0x7b76a8: stp             x0, x16, [SP, #-0x10]!
    // 0x7b76ac: r0 = chain()
    //     0x7b76ac: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b76b0: add             SP, SP, #0x10
    // 0x7b76b4: LeaveFrame
    //     0x7b76b4: mov             SP, fp
    //     0x7b76b8: ldp             fp, lr, [SP], #0x10
    // 0x7b76bc: ret
    //     0x7b76bc: ret             
    // 0x7b76c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b76c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b76c4: b               #0x7b7660
  }
  static Animatable<double> _scaleDownTransition() {
    // ** addr: 0x7b7d2c, size: 0x80
    // 0x7b7d2c: EnterFrame
    //     0x7b7d2c: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7d30: mov             fp, SP
    // 0x7b7d34: AllocStack(0x8)
    //     0x7b7d34: sub             SP, SP, #8
    // 0x7b7d38: CheckStackOverflow
    //     0x7b7d38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7d3c: cmp             SP, x16
    //     0x7b7d40: b.ls            #0x7b7da4
    // 0x7b7d44: r1 = <double>
    //     0x7b7d44: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7d48: r0 = Tween()
    //     0x7b7d48: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b7d4c: mov             x1, x0
    // 0x7b7d50: r0 = 1.100000
    //     0x7b7d50: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b7e0] 1.1
    //     0x7b7d54: ldr             x0, [x0, #0x7e0]
    // 0x7b7d58: stur            x1, [fp, #-8]
    // 0x7b7d5c: StoreField: r1->field_b = r0
    //     0x7b7d5c: stur            w0, [x1, #0xb]
    // 0x7b7d60: r0 = 1.000000
    //     0x7b7d60: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b7d64: StoreField: r1->field_f = r0
    //     0x7b7d64: stur            w0, [x1, #0xf]
    // 0x7b7d68: r0 = InitLateStaticField(0xe00) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::_scaleCurveSequence
    //     0x7b7d68: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b7d6c: ldr             x0, [x0, #0x1c00]
    //     0x7b7d70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b7d74: cmp             w0, w16
    //     0x7b7d78: b.ne            #0x7b7d88
    //     0x7b7d7c: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b720] Field <_ZoomPageTransition@789490068._scaleCurveSequence@789490068>: static late final (offset: 0xe00)
    //     0x7b7d80: ldr             x2, [x2, #0x720]
    //     0x7b7d84: bl              #0xd67cdc
    // 0x7b7d88: ldur            x16, [fp, #-8]
    // 0x7b7d8c: stp             x0, x16, [SP, #-0x10]!
    // 0x7b7d90: r0 = chain()
    //     0x7b7d90: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b7d94: add             SP, SP, #0x10
    // 0x7b7d98: LeaveFrame
    //     0x7b7d98: mov             SP, fp
    //     0x7b7d9c: ldp             fp, lr, [SP], #0x10
    // 0x7b7da0: ret
    //     0x7b7da0: ret             
    // 0x7b7da4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7da4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7da8: b               #0x7b7d44
  }
  static Animatable<double> _fadeInTransition() {
    // ** addr: 0x7b7dac, size: 0x74
    // 0x7b7dac: EnterFrame
    //     0x7b7dac: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7db0: mov             fp, SP
    // 0x7b7db4: AllocStack(0x8)
    //     0x7b7db4: sub             SP, SP, #8
    // 0x7b7db8: CheckStackOverflow
    //     0x7b7db8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7dbc: cmp             SP, x16
    //     0x7b7dc0: b.ls            #0x7b7e18
    // 0x7b7dc4: r1 = <double>
    //     0x7b7dc4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7dc8: r0 = Tween()
    //     0x7b7dc8: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b7dcc: mov             x2, x0
    // 0x7b7dd0: r0 = 0.000000
    //     0x7b7dd0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x7b7dd4: stur            x2, [fp, #-8]
    // 0x7b7dd8: StoreField: r2->field_b = r0
    //     0x7b7dd8: stur            w0, [x2, #0xb]
    // 0x7b7ddc: r0 = 1.000000
    //     0x7b7ddc: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b7de0: StoreField: r2->field_f = r0
    //     0x7b7de0: stur            w0, [x2, #0xf]
    // 0x7b7de4: r1 = <double>
    //     0x7b7de4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7de8: r0 = CurveTween()
    //     0x7b7de8: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7b7dec: mov             x1, x0
    // 0x7b7df0: r0 = Instance_Interval
    //     0x7b7df0: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b7e8] Obj!Interval<double>@b4f721
    //     0x7b7df4: ldr             x0, [x0, #0x7e8]
    // 0x7b7df8: StoreField: r1->field_b = r0
    //     0x7b7df8: stur            w0, [x1, #0xb]
    // 0x7b7dfc: ldur            x16, [fp, #-8]
    // 0x7b7e00: stp             x1, x16, [SP, #-0x10]!
    // 0x7b7e04: r0 = chain()
    //     0x7b7e04: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b7e08: add             SP, SP, #0x10
    // 0x7b7e0c: LeaveFrame
    //     0x7b7e0c: mov             SP, fp
    //     0x7b7e10: ldp             fp, lr, [SP], #0x10
    // 0x7b7e14: ret
    //     0x7b7e14: ret             
    // 0x7b7e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7e18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7e1c: b               #0x7b7dc4
  }
  _ build(/* No info */) {
    // ** addr: 0x86225c, size: 0x9c
    // 0x86225c: EnterFrame
    //     0x86225c: stp             fp, lr, [SP, #-0x10]!
    //     0x862260: mov             fp, SP
    // 0x862264: AllocStack(0x18)
    //     0x862264: sub             SP, SP, #0x18
    // 0x862268: ldr             x0, [fp, #0x18]
    // 0x86226c: LoadField: r1 = r0->field_1f
    //     0x86226c: ldur            w1, [x0, #0x1f]
    // 0x862270: DecompressPointer r1
    //     0x862270: add             x1, x1, HEAP, lsl #32
    // 0x862274: r16 = Sentinel
    //     0x862274: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x862278: cmp             w1, w16
    // 0x86227c: b.eq            #0x8622e8
    // 0x862280: stur            x1, [fp, #-0x18]
    // 0x862284: LoadField: r2 = r0->field_13
    //     0x862284: ldur            w2, [x0, #0x13]
    // 0x862288: DecompressPointer r2
    //     0x862288: add             x2, x2, HEAP, lsl #32
    // 0x86228c: stur            x2, [fp, #-0x10]
    // 0x862290: LoadField: r3 = r0->field_b
    //     0x862290: ldur            w3, [x0, #0xb]
    // 0x862294: DecompressPointer r3
    //     0x862294: add             x3, x3, HEAP, lsl #32
    // 0x862298: cmp             w3, NULL
    // 0x86229c: b.eq            #0x8622f4
    // 0x8622a0: LoadField: r0 = r3->field_f
    //     0x8622a0: ldur            w0, [x3, #0xf]
    // 0x8622a4: DecompressPointer r0
    //     0x8622a4: add             x0, x0, HEAP, lsl #32
    // 0x8622a8: stur            x0, [fp, #-8]
    // 0x8622ac: r0 = SnapshotWidget()
    //     0x8622ac: bl              #0x8622f8  ; AllocateSnapshotWidgetStub -> SnapshotWidget (size=0x20)
    // 0x8622b0: r1 = Instance_SnapshotMode
    //     0x8622b0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b698] Obj!SnapshotMode@b634b1
    //     0x8622b4: ldr             x1, [x1, #0x698]
    // 0x8622b8: StoreField: r0->field_13 = r1
    //     0x8622b8: stur            w1, [x0, #0x13]
    // 0x8622bc: ldur            x1, [fp, #-0x18]
    // 0x8622c0: StoreField: r0->field_1b = r1
    //     0x8622c0: stur            w1, [x0, #0x1b]
    // 0x8622c4: r1 = true
    //     0x8622c4: add             x1, NULL, #0x20  ; true
    // 0x8622c8: StoreField: r0->field_17 = r1
    //     0x8622c8: stur            w1, [x0, #0x17]
    // 0x8622cc: ldur            x1, [fp, #-0x10]
    // 0x8622d0: StoreField: r0->field_f = r1
    //     0x8622d0: stur            w1, [x0, #0xf]
    // 0x8622d4: ldur            x1, [fp, #-8]
    // 0x8622d8: StoreField: r0->field_b = r1
    //     0x8622d8: stur            w1, [x0, #0xb]
    // 0x8622dc: LeaveFrame
    //     0x8622dc: mov             SP, fp
    //     0x8622e0: ldp             fp, lr, [SP], #0x10
    // 0x8622e4: ret
    //     0x8622e4: ret             
    // 0x8622e8: r9 = delegate
    //     0x8622e8: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b768] Field <_ZoomEnterTransitionState@789490068.delegate>: late (offset: 0x20)
    //     0x8622ec: ldr             x9, [x9, #0x768]
    // 0x8622f0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8622f0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x8622f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8622f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dae80, size: 0x108
    // 0x9dae80: EnterFrame
    //     0x9dae80: stp             fp, lr, [SP, #-0x10]!
    //     0x9dae84: mov             fp, SP
    // 0x9dae88: AllocStack(0x28)
    //     0x9dae88: sub             SP, SP, #0x28
    // 0x9dae8c: CheckStackOverflow
    //     0x9dae8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dae90: cmp             SP, x16
    //     0x9dae94: b.ls            #0x9daf64
    // 0x9dae98: ldr             x16, [fp, #0x10]
    // 0x9dae9c: SaveReg r16
    //     0x9dae9c: str             x16, [SP, #-8]!
    // 0x9daea0: r0 = _updateAnimations()
    //     0x9daea0: bl              #0x7b73d8  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_updateAnimations
    // 0x9daea4: add             SP, SP, #8
    // 0x9daea8: ldr             x0, [fp, #0x10]
    // 0x9daeac: LoadField: r1 = r0->field_b
    //     0x9daeac: ldur            w1, [x0, #0xb]
    // 0x9daeb0: DecompressPointer r1
    //     0x9daeb0: add             x1, x1, HEAP, lsl #32
    // 0x9daeb4: cmp             w1, NULL
    // 0x9daeb8: b.eq            #0x9daf6c
    // 0x9daebc: LoadField: r2 = r1->field_17
    //     0x9daebc: ldur            w2, [x1, #0x17]
    // 0x9daec0: DecompressPointer r2
    //     0x9daec0: add             x2, x2, HEAP, lsl #32
    // 0x9daec4: stur            x2, [fp, #-0x20]
    // 0x9daec8: LoadField: r3 = r0->field_17
    //     0x9daec8: ldur            w3, [x0, #0x17]
    // 0x9daecc: DecompressPointer r3
    //     0x9daecc: add             x3, x3, HEAP, lsl #32
    // 0x9daed0: r16 = Sentinel
    //     0x9daed0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9daed4: cmp             w3, w16
    // 0x9daed8: b.eq            #0x9daf70
    // 0x9daedc: stur            x3, [fp, #-0x18]
    // 0x9daee0: LoadField: r4 = r0->field_1b
    //     0x9daee0: ldur            w4, [x0, #0x1b]
    // 0x9daee4: DecompressPointer r4
    //     0x9daee4: add             x4, x4, HEAP, lsl #32
    // 0x9daee8: r16 = Sentinel
    //     0x9daee8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9daeec: cmp             w4, w16
    // 0x9daef0: b.eq            #0x9daf7c
    // 0x9daef4: stur            x4, [fp, #-0x10]
    // 0x9daef8: LoadField: r5 = r1->field_b
    //     0x9daef8: ldur            w5, [x1, #0xb]
    // 0x9daefc: DecompressPointer r5
    //     0x9daefc: add             x5, x5, HEAP, lsl #32
    // 0x9daf00: stur            x5, [fp, #-8]
    // 0x9daf04: r0 = _ZoomEnterTransitionPainter()
    //     0x9daf04: bl              #0x7b73cc  ; Allocate_ZoomEnterTransitionPainterStub -> _ZoomEnterTransitionPainter (size=0x40)
    // 0x9daf08: stur            x0, [fp, #-0x28]
    // 0x9daf0c: ldur            x16, [fp, #-8]
    // 0x9daf10: stp             x16, x0, [SP, #-0x10]!
    // 0x9daf14: ldur            x16, [fp, #-0x18]
    // 0x9daf18: ldur            lr, [fp, #-0x20]
    // 0x9daf1c: stp             lr, x16, [SP, #-0x10]!
    // 0x9daf20: ldur            x16, [fp, #-0x10]
    // 0x9daf24: SaveReg r16
    //     0x9daf24: str             x16, [SP, #-8]!
    // 0x9daf28: r0 = _ZoomEnterTransitionPainter()
    //     0x9daf28: bl              #0x7b70ec  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_ZoomEnterTransitionPainter
    // 0x9daf2c: add             SP, SP, #0x28
    // 0x9daf30: ldur            x0, [fp, #-0x28]
    // 0x9daf34: ldr             x1, [fp, #0x10]
    // 0x9daf38: StoreField: r1->field_1f = r0
    //     0x9daf38: stur            w0, [x1, #0x1f]
    //     0x9daf3c: ldurb           w16, [x1, #-1]
    //     0x9daf40: ldurb           w17, [x0, #-1]
    //     0x9daf44: and             x16, x17, x16, lsr #2
    //     0x9daf48: tst             x16, HEAP, lsr #32
    //     0x9daf4c: b.eq            #0x9daf54
    //     0x9daf50: bl              #0xd6826c
    // 0x9daf54: r0 = Null
    //     0x9daf54: mov             x0, NULL
    // 0x9daf58: LeaveFrame
    //     0x9daf58: mov             SP, fp
    //     0x9daf5c: ldp             fp, lr, [SP], #0x10
    // 0x9daf60: ret
    //     0x9daf60: ret             
    // 0x9daf64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9daf64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9daf68: b               #0x9dae98
    // 0x9daf6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9daf6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9daf70: r9 = fadeTransition
    //     0x9daf70: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b788] Field <__ZoomEnterTransitionState&State&_ZoomTransitionBase@789490068.fadeTransition>: late (offset: 0x18)
    //     0x9daf74: ldr             x9, [x9, #0x788]
    // 0x9daf78: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9daf78: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9daf7c: r9 = scaleTransition
    //     0x9daf7c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b780] Field <__ZoomEnterTransitionState&State&_ZoomTransitionBase@789490068.scaleTransition>: late (offset: 0x1c)
    //     0x9daf80: ldr             x9, [x9, #0x780]
    // 0x9daf84: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9daf84: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4ae88, size: 0x18
    // 0xa4ae88: r4 = 7
    //     0xa4ae88: mov             x4, #7
    // 0xa4ae8c: r1 = Function 'dispose':.
    //     0xa4ae8c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b760] AnonymousClosure: (0xa4aea0), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::dispose (0xa52064)
    //     0xa4ae90: ldr             x1, [x17, #0x760]
    // 0xa4ae94: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4ae94: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4ae98: LoadField: r0 = r24->field_17
    //     0xa4ae98: ldur            x0, [x24, #0x17]
    // 0xa4ae9c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4aea0, size: 0x48
    // 0xa4aea0: EnterFrame
    //     0xa4aea0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4aea4: mov             fp, SP
    // 0xa4aea8: ldr             x0, [fp, #0x10]
    // 0xa4aeac: LoadField: r1 = r0->field_17
    //     0xa4aeac: ldur            w1, [x0, #0x17]
    // 0xa4aeb0: DecompressPointer r1
    //     0xa4aeb0: add             x1, x1, HEAP, lsl #32
    // 0xa4aeb4: CheckStackOverflow
    //     0xa4aeb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4aeb8: cmp             SP, x16
    //     0xa4aebc: b.ls            #0xa4aee0
    // 0xa4aec0: LoadField: r0 = r1->field_f
    //     0xa4aec0: ldur            w0, [x1, #0xf]
    // 0xa4aec4: DecompressPointer r0
    //     0xa4aec4: add             x0, x0, HEAP, lsl #32
    // 0xa4aec8: SaveReg r0
    //     0xa4aec8: str             x0, [SP, #-8]!
    // 0xa4aecc: r0 = dispose()
    //     0xa4aecc: bl              #0xa52064  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::dispose
    // 0xa4aed0: add             SP, SP, #8
    // 0xa4aed4: LeaveFrame
    //     0xa4aed4: mov             SP, fp
    //     0xa4aed8: ldp             fp, lr, [SP], #0x10
    // 0xa4aedc: ret
    //     0xa4aedc: ret             
    // 0xa4aee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4aee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4aee4: b               #0xa4aec0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52064, size: 0x144
    // 0xa52064: EnterFrame
    //     0xa52064: stp             fp, lr, [SP, #-0x10]!
    //     0xa52068: mov             fp, SP
    // 0xa5206c: AllocStack(0x8)
    //     0xa5206c: sub             SP, SP, #8
    // 0xa52070: CheckStackOverflow
    //     0xa52070: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52074: cmp             SP, x16
    //     0xa52078: b.ls            #0xa5218c
    // 0xa5207c: ldr             x0, [fp, #0x10]
    // 0xa52080: LoadField: r1 = r0->field_b
    //     0xa52080: ldur            w1, [x0, #0xb]
    // 0xa52084: DecompressPointer r1
    //     0xa52084: add             x1, x1, HEAP, lsl #32
    // 0xa52088: cmp             w1, NULL
    // 0xa5208c: b.eq            #0xa52194
    // 0xa52090: LoadField: r2 = r1->field_b
    //     0xa52090: ldur            w2, [x1, #0xb]
    // 0xa52094: DecompressPointer r2
    //     0xa52094: add             x2, x2, HEAP, lsl #32
    // 0xa52098: stur            x2, [fp, #-8]
    // 0xa5209c: r1 = 1
    //     0xa5209c: mov             x1, #1
    // 0xa520a0: r0 = AllocateContext()
    //     0xa520a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa520a4: mov             x1, x0
    // 0xa520a8: ldr             x0, [fp, #0x10]
    // 0xa520ac: StoreField: r1->field_f = r0
    //     0xa520ac: stur            w0, [x1, #0xf]
    // 0xa520b0: mov             x2, x1
    // 0xa520b4: r1 = Function 'onAnimationValueChange':.
    //     0xa520b4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b770] AnonymousClosure: (0x7b7fb8), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationValueChange (0x7b8000)
    //     0xa520b8: ldr             x1, [x1, #0x770]
    // 0xa520bc: r0 = AllocateClosure()
    //     0xa520bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa520c0: mov             x1, x0
    // 0xa520c4: ldur            x0, [fp, #-8]
    // 0xa520c8: r2 = LoadClassIdInstr(r0)
    //     0xa520c8: ldur            x2, [x0, #-1]
    //     0xa520cc: ubfx            x2, x2, #0xc, #0x14
    // 0xa520d0: stp             x1, x0, [SP, #-0x10]!
    // 0xa520d4: mov             x0, x2
    // 0xa520d8: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa520d8: mov             x17, #0xc2d6
    //     0xa520dc: add             lr, x0, x17
    //     0xa520e0: ldr             lr, [x21, lr, lsl #3]
    //     0xa520e4: blr             lr
    // 0xa520e8: add             SP, SP, #0x10
    // 0xa520ec: ldr             x0, [fp, #0x10]
    // 0xa520f0: LoadField: r1 = r0->field_b
    //     0xa520f0: ldur            w1, [x0, #0xb]
    // 0xa520f4: DecompressPointer r1
    //     0xa520f4: add             x1, x1, HEAP, lsl #32
    // 0xa520f8: cmp             w1, NULL
    // 0xa520fc: b.eq            #0xa52198
    // 0xa52100: LoadField: r2 = r1->field_b
    //     0xa52100: ldur            w2, [x1, #0xb]
    // 0xa52104: DecompressPointer r2
    //     0xa52104: add             x2, x2, HEAP, lsl #32
    // 0xa52108: stur            x2, [fp, #-8]
    // 0xa5210c: r1 = 1
    //     0xa5210c: mov             x1, #1
    // 0xa52110: r0 = AllocateContext()
    //     0xa52110: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52114: mov             x1, x0
    // 0xa52118: ldr             x0, [fp, #0x10]
    // 0xa5211c: StoreField: r1->field_f = r0
    //     0xa5211c: stur            w0, [x1, #0xf]
    // 0xa52120: mov             x2, x1
    // 0xa52124: r1 = Function 'onAnimationStatusChange':.
    //     0xa52124: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b778] AnonymousClosure: (0x7b7e44), in [package:flutter/src/material/page_transitions_theme.dart] __ZoomEnterTransitionState&State&_ZoomTransitionBase::onAnimationStatusChange (0x7b7e90)
    //     0xa52128: ldr             x1, [x1, #0x778]
    // 0xa5212c: r0 = AllocateClosure()
    //     0xa5212c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52130: mov             x1, x0
    // 0xa52134: ldur            x0, [fp, #-8]
    // 0xa52138: r2 = LoadClassIdInstr(r0)
    //     0xa52138: ldur            x2, [x0, #-1]
    //     0xa5213c: ubfx            x2, x2, #0xc, #0x14
    // 0xa52140: stp             x1, x0, [SP, #-0x10]!
    // 0xa52144: mov             x0, x2
    // 0xa52148: r0 = GDT[cid_x0 + 0x490]()
    //     0xa52148: add             lr, x0, #0x490
    //     0xa5214c: ldr             lr, [x21, lr, lsl #3]
    //     0xa52150: blr             lr
    // 0xa52154: add             SP, SP, #0x10
    // 0xa52158: ldr             x0, [fp, #0x10]
    // 0xa5215c: LoadField: r1 = r0->field_1f
    //     0xa5215c: ldur            w1, [x0, #0x1f]
    // 0xa52160: DecompressPointer r1
    //     0xa52160: add             x1, x1, HEAP, lsl #32
    // 0xa52164: r16 = Sentinel
    //     0xa52164: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52168: cmp             w1, w16
    // 0xa5216c: b.eq            #0xa5219c
    // 0xa52170: SaveReg r1
    //     0xa52170: str             x1, [SP, #-8]!
    // 0xa52174: r0 = dispose()
    //     0xa52174: bl              #0x9c24d8  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::dispose
    // 0xa52178: add             SP, SP, #8
    // 0xa5217c: r0 = Null
    //     0xa5217c: mov             x0, NULL
    // 0xa52180: LeaveFrame
    //     0xa52180: mov             SP, fp
    //     0xa52184: ldp             fp, lr, [SP], #0x10
    // 0xa52188: ret
    //     0xa52188: ret             
    // 0xa5218c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5218c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52190: b               #0xa5207c
    // 0xa52194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52194: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa52198: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa52198: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa5219c: r9 = delegate
    //     0xa5219c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4b768] Field <_ZoomEnterTransitionState@789490068.delegate>: late (offset: 0x20)
    //     0xa521a0: ldr             x9, [x9, #0x768]
    // 0xa521a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa521a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  static Animatable<double?> _scrimOpacityTween() {
    // ** addr: 0xcaf9b0, size: 0x7c
    // 0xcaf9b0: EnterFrame
    //     0xcaf9b0: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf9b4: mov             fp, SP
    // 0xcaf9b8: AllocStack(0x8)
    //     0xcaf9b8: sub             SP, SP, #8
    // 0xcaf9bc: CheckStackOverflow
    //     0xcaf9bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcaf9c0: cmp             SP, x16
    //     0xcaf9c4: b.ls            #0xcafa24
    // 0xcaf9c8: r1 = <double?>
    //     0xcaf9c8: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0xcaf9cc: ldr             x1, [x1, #0xb88]
    // 0xcaf9d0: r0 = Tween()
    //     0xcaf9d0: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xcaf9d4: mov             x2, x0
    // 0xcaf9d8: r0 = 0.000000
    //     0xcaf9d8: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0xcaf9dc: stur            x2, [fp, #-8]
    // 0xcaf9e0: StoreField: r2->field_b = r0
    //     0xcaf9e0: stur            w0, [x2, #0xb]
    // 0xcaf9e4: r0 = 0.600000
    //     0xcaf9e4: add             x0, PP, #0x4c, lsl #12  ; [pp+0x4c150] 0.6
    //     0xcaf9e8: ldr             x0, [x0, #0x150]
    // 0xcaf9ec: StoreField: r2->field_f = r0
    //     0xcaf9ec: stur            w0, [x2, #0xf]
    // 0xcaf9f0: r1 = <double>
    //     0xcaf9f0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xcaf9f4: r0 = CurveTween()
    //     0xcaf9f4: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xcaf9f8: mov             x1, x0
    // 0xcaf9fc: r0 = Instance_Interval
    //     0xcaf9fc: add             x0, PP, #0x55, lsl #12  ; [pp+0x55878] Obj!Interval<double>@b4fc21
    //     0xcafa00: ldr             x0, [x0, #0x878]
    // 0xcafa04: StoreField: r1->field_b = r0
    //     0xcafa04: stur            w0, [x1, #0xb]
    // 0xcafa08: ldur            x16, [fp, #-8]
    // 0xcafa0c: stp             x1, x16, [SP, #-0x10]!
    // 0xcafa10: r0 = chain()
    //     0xcafa10: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xcafa14: add             SP, SP, #0x10
    // 0xcafa18: LeaveFrame
    //     0xcafa18: mov             SP, fp
    //     0xcafa1c: ldp             fp, lr, [SP], #0x10
    // 0xcafa20: ret
    //     0xcafa20: ret             
    // 0xcafa24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcafa24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcafa28: b               #0xcaf9c8
  }
}

// class id: 3846, size: 0x1c, field offset: 0xc
//   const constructor, 
class _ZoomPageTransition extends StatelessWidget {

  static late final TweenSequence<double> _scaleCurveSequence; // offset: 0xe00
  static late final List<TweenSequenceItem<double>> fastOutExtraSlowInTweenSequenceItems; // offset: 0xdfc

  static TweenSequence<double> _scaleCurveSequence() {
    // ** addr: 0x7b7708, size: 0x70
    // 0x7b7708: EnterFrame
    //     0x7b7708: stp             fp, lr, [SP, #-0x10]!
    //     0x7b770c: mov             fp, SP
    // 0x7b7710: AllocStack(0x10)
    //     0x7b7710: sub             SP, SP, #0x10
    // 0x7b7714: CheckStackOverflow
    //     0x7b7714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7718: cmp             SP, x16
    //     0x7b771c: b.ls            #0x7b7770
    // 0x7b7720: r0 = InitLateStaticField(0xdfc) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::fastOutExtraSlowInTweenSequenceItems
    //     0x7b7720: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b7724: ldr             x0, [x0, #0x1bf8]
    //     0x7b7728: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b772c: cmp             w0, w16
    //     0x7b7730: b.ne            #0x7b7740
    //     0x7b7734: add             x2, PP, #0x4b, lsl #12  ; [pp+0x4b728] Field <_ZoomPageTransition@789490068.fastOutExtraSlowInTweenSequenceItems>: static late final (offset: 0xdfc)
    //     0x7b7738: ldr             x2, [x2, #0x728]
    //     0x7b773c: bl              #0xd67cdc
    // 0x7b7740: r1 = <double>
    //     0x7b7740: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7744: stur            x0, [fp, #-8]
    // 0x7b7748: r0 = TweenSequence()
    //     0x7b7748: bl              #0x7b7b18  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0x7b774c: stur            x0, [fp, #-0x10]
    // 0x7b7750: ldur            x16, [fp, #-8]
    // 0x7b7754: stp             x16, x0, [SP, #-0x10]!
    // 0x7b7758: r0 = TweenSequence()
    //     0x7b7758: bl              #0x7b7778  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0x7b775c: add             SP, SP, #0x10
    // 0x7b7760: ldur            x0, [fp, #-0x10]
    // 0x7b7764: LeaveFrame
    //     0x7b7764: mov             SP, fp
    //     0x7b7768: ldp             fp, lr, [SP], #0x10
    // 0x7b776c: ret
    //     0x7b776c: ret             
    // 0x7b7770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7770: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7774: b               #0x7b7720
  }
  static List<TweenSequenceItem<double>> fastOutExtraSlowInTweenSequenceItems() {
    // ** addr: 0x7b7b24, size: 0x154
    // 0x7b7b24: EnterFrame
    //     0x7b7b24: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7b28: mov             fp, SP
    // 0x7b7b2c: AllocStack(0x18)
    //     0x7b7b2c: sub             SP, SP, #0x18
    // 0x7b7b30: CheckStackOverflow
    //     0x7b7b30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7b34: cmp             SP, x16
    //     0x7b7b38: b.ls            #0x7b7c70
    // 0x7b7b3c: r1 = <double>
    //     0x7b7b3c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7b40: r0 = Tween()
    //     0x7b7b40: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b7b44: mov             x2, x0
    // 0x7b7b48: r0 = 0.000000
    //     0x7b7b48: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x7b7b4c: stur            x2, [fp, #-8]
    // 0x7b7b50: StoreField: r2->field_b = r0
    //     0x7b7b50: stur            w0, [x2, #0xb]
    // 0x7b7b54: r0 = 0.400000
    //     0x7b7b54: add             x0, PP, #0x42, lsl #12  ; [pp+0x42020] 0.4
    //     0x7b7b58: ldr             x0, [x0, #0x20]
    // 0x7b7b5c: StoreField: r2->field_f = r0
    //     0x7b7b5c: stur            w0, [x2, #0xf]
    // 0x7b7b60: r1 = <double>
    //     0x7b7b60: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7b64: r0 = CurveTween()
    //     0x7b7b64: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7b7b68: mov             x1, x0
    // 0x7b7b6c: r0 = Instance_Cubic
    //     0x7b7b6c: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b730] Obj!Cubic<double>@b4f401
    //     0x7b7b70: ldr             x0, [x0, #0x730]
    // 0x7b7b74: StoreField: r1->field_b = r0
    //     0x7b7b74: stur            w0, [x1, #0xb]
    // 0x7b7b78: ldur            x16, [fp, #-8]
    // 0x7b7b7c: stp             x1, x16, [SP, #-0x10]!
    // 0x7b7b80: r0 = chain()
    //     0x7b7b80: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b7b84: add             SP, SP, #0x10
    // 0x7b7b88: r1 = <double>
    //     0x7b7b88: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7b8c: stur            x0, [fp, #-8]
    // 0x7b7b90: r0 = TweenSequenceItem()
    //     0x7b7b90: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x7b7b94: mov             x2, x0
    // 0x7b7b98: ldur            x0, [fp, #-8]
    // 0x7b7b9c: stur            x2, [fp, #-0x10]
    // 0x7b7ba0: StoreField: r2->field_b = r0
    //     0x7b7ba0: stur            w0, [x2, #0xb]
    // 0x7b7ba4: d0 = 0.166666
    //     0x7b7ba4: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b738] IMM: double(0.166666) from 0x3fc5554fbdad7519
    //     0x7b7ba8: ldr             d0, [x17, #0x738]
    // 0x7b7bac: StoreField: r2->field_f = d0
    //     0x7b7bac: stur            d0, [x2, #0xf]
    // 0x7b7bb0: r1 = <double>
    //     0x7b7bb0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7bb4: r0 = Tween()
    //     0x7b7bb4: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x7b7bb8: mov             x2, x0
    // 0x7b7bbc: r0 = 0.400000
    //     0x7b7bbc: add             x0, PP, #0x42, lsl #12  ; [pp+0x42020] 0.4
    //     0x7b7bc0: ldr             x0, [x0, #0x20]
    // 0x7b7bc4: stur            x2, [fp, #-8]
    // 0x7b7bc8: StoreField: r2->field_b = r0
    //     0x7b7bc8: stur            w0, [x2, #0xb]
    // 0x7b7bcc: r0 = 1.000000
    //     0x7b7bcc: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x7b7bd0: StoreField: r2->field_f = r0
    //     0x7b7bd0: stur            w0, [x2, #0xf]
    // 0x7b7bd4: r1 = <double>
    //     0x7b7bd4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7bd8: r0 = CurveTween()
    //     0x7b7bd8: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x7b7bdc: mov             x1, x0
    // 0x7b7be0: r0 = Instance_Cubic
    //     0x7b7be0: add             x0, PP, #0x4b, lsl #12  ; [pp+0x4b740] Obj!Cubic<double>@b4f3d1
    //     0x7b7be4: ldr             x0, [x0, #0x740]
    // 0x7b7be8: StoreField: r1->field_b = r0
    //     0x7b7be8: stur            w0, [x1, #0xb]
    // 0x7b7bec: ldur            x16, [fp, #-8]
    // 0x7b7bf0: stp             x1, x16, [SP, #-0x10]!
    // 0x7b7bf4: r0 = chain()
    //     0x7b7bf4: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0x7b7bf8: add             SP, SP, #0x10
    // 0x7b7bfc: r1 = <double>
    //     0x7b7bfc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x7b7c00: stur            x0, [fp, #-8]
    // 0x7b7c04: r0 = TweenSequenceItem()
    //     0x7b7c04: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x7b7c08: mov             x3, x0
    // 0x7b7c0c: ldur            x0, [fp, #-8]
    // 0x7b7c10: stur            x3, [fp, #-0x18]
    // 0x7b7c14: StoreField: r3->field_b = r0
    //     0x7b7c14: stur            w0, [x3, #0xb]
    // 0x7b7c18: d0 = 0.833334
    //     0x7b7c18: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b748] IMM: double(0.833334) from 0x3feaaaac1094a2ba
    //     0x7b7c1c: ldr             d0, [x17, #0x748]
    // 0x7b7c20: StoreField: r3->field_f = d0
    //     0x7b7c20: stur            d0, [x3, #0xf]
    // 0x7b7c24: r1 = Null
    //     0x7b7c24: mov             x1, NULL
    // 0x7b7c28: r2 = 4
    //     0x7b7c28: mov             x2, #4
    // 0x7b7c2c: r0 = AllocateArray()
    //     0x7b7c2c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x7b7c30: mov             x2, x0
    // 0x7b7c34: ldur            x0, [fp, #-0x10]
    // 0x7b7c38: stur            x2, [fp, #-8]
    // 0x7b7c3c: StoreField: r2->field_f = r0
    //     0x7b7c3c: stur            w0, [x2, #0xf]
    // 0x7b7c40: ldur            x0, [fp, #-0x18]
    // 0x7b7c44: StoreField: r2->field_13 = r0
    //     0x7b7c44: stur            w0, [x2, #0x13]
    // 0x7b7c48: r1 = <TweenSequenceItem<double>>
    //     0x7b7c48: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a0] TypeArguments: <TweenSequenceItem<double>>
    //     0x7b7c4c: ldr             x1, [x1, #0x3a0]
    // 0x7b7c50: r0 = AllocateGrowableArray()
    //     0x7b7c50: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x7b7c54: ldur            x1, [fp, #-8]
    // 0x7b7c58: StoreField: r0->field_f = r1
    //     0x7b7c58: stur            w1, [x0, #0xf]
    // 0x7b7c5c: r1 = 4
    //     0x7b7c5c: mov             x1, #4
    // 0x7b7c60: StoreField: r0->field_b = r1
    //     0x7b7c60: stur            w1, [x0, #0xb]
    // 0x7b7c64: LeaveFrame
    //     0x7b7c64: mov             SP, fp
    //     0x7b7c68: ldp             fp, lr, [SP], #0x10
    // 0x7b7c6c: ret
    //     0x7b7c6c: ret             
    // 0x7b7c70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7c70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b7c74: b               #0x7b7b3c
  }
  _ build(/* No info */) {
    // ** addr: 0xb23b28, size: 0x1b0
    // 0xb23b28: EnterFrame
    //     0xb23b28: stp             fp, lr, [SP, #-0x10]!
    //     0xb23b2c: mov             fp, SP
    // 0xb23b30: AllocStack(0x28)
    //     0xb23b30: sub             SP, SP, #0x28
    // 0xb23b34: CheckStackOverflow
    //     0xb23b34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb23b38: cmp             SP, x16
    //     0xb23b3c: b.ls            #0xb23cd0
    // 0xb23b40: r1 = 1
    //     0xb23b40: mov             x1, #1
    // 0xb23b44: r0 = AllocateContext()
    //     0xb23b44: bl              #0xd68aa4  ; AllocateContextStub
    // 0xb23b48: mov             x2, x0
    // 0xb23b4c: ldr             x0, [fp, #0x18]
    // 0xb23b50: stur            x2, [fp, #-0x18]
    // 0xb23b54: StoreField: r2->field_f = r0
    //     0xb23b54: stur            w0, [x2, #0xf]
    // 0xb23b58: LoadField: r3 = r0->field_b
    //     0xb23b58: ldur            w3, [x0, #0xb]
    // 0xb23b5c: DecompressPointer r3
    //     0xb23b5c: add             x3, x3, HEAP, lsl #32
    // 0xb23b60: stur            x3, [fp, #-0x10]
    // 0xb23b64: LoadField: r4 = r0->field_f
    //     0xb23b64: ldur            w4, [x0, #0xf]
    // 0xb23b68: DecompressPointer r4
    //     0xb23b68: add             x4, x4, HEAP, lsl #32
    // 0xb23b6c: stur            x4, [fp, #-8]
    // 0xb23b70: r1 = <double>
    //     0xb23b70: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xb23b74: r0 = ReverseAnimation()
    //     0xb23b74: bl              #0x7b9ff0  ; AllocateReverseAnimationStub -> ReverseAnimation (size=0x1c)
    // 0xb23b78: mov             x2, x0
    // 0xb23b7c: ldur            x0, [fp, #-8]
    // 0xb23b80: stur            x2, [fp, #-0x20]
    // 0xb23b84: StoreField: r2->field_17 = r0
    //     0xb23b84: stur            w0, [x2, #0x17]
    // 0xb23b88: r1 = <(dynamic this, AnimationStatus) => void?>
    //     0xb23b88: add             x1, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0xb23b8c: ldr             x1, [x1, #0x3d8]
    // 0xb23b90: r0 = ObserverList()
    //     0xb23b90: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0xb23b94: mov             x1, x0
    // 0xb23b98: r0 = false
    //     0xb23b98: add             x0, NULL, #0x30  ; false
    // 0xb23b9c: stur            x1, [fp, #-8]
    // 0xb23ba0: StoreField: r1->field_f = r0
    //     0xb23ba0: stur            w0, [x1, #0xf]
    // 0xb23ba4: r0 = Sentinel
    //     0xb23ba4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xb23ba8: StoreField: r1->field_13 = r0
    //     0xb23ba8: stur            w0, [x1, #0x13]
    // 0xb23bac: r16 = <(dynamic this, AnimationStatus) => void?>
    //     0xb23bac: add             x16, PP, #0xf, lsl #12  ; [pp+0xf3d8] TypeArguments: <(dynamic this, AnimationStatus) => void?>
    //     0xb23bb0: ldr             x16, [x16, #0x3d8]
    // 0xb23bb4: stp             xzr, x16, [SP, #-0x10]!
    // 0xb23bb8: r0 = _GrowableList()
    //     0xb23bb8: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xb23bbc: add             SP, SP, #0x10
    // 0xb23bc0: ldur            x1, [fp, #-8]
    // 0xb23bc4: StoreField: r1->field_b = r0
    //     0xb23bc4: stur            w0, [x1, #0xb]
    //     0xb23bc8: ldurb           w16, [x1, #-1]
    //     0xb23bcc: ldurb           w17, [x0, #-1]
    //     0xb23bd0: and             x16, x17, x16, lsr #2
    //     0xb23bd4: tst             x16, HEAP, lsr #32
    //     0xb23bd8: b.eq            #0xb23be0
    //     0xb23bdc: bl              #0xd6826c
    // 0xb23be0: mov             x0, x1
    // 0xb23be4: ldur            x1, [fp, #-0x20]
    // 0xb23be8: StoreField: r1->field_13 = r0
    //     0xb23be8: stur            w0, [x1, #0x13]
    //     0xb23bec: ldurb           w16, [x1, #-1]
    //     0xb23bf0: ldurb           w17, [x0, #-1]
    //     0xb23bf4: and             x16, x17, x16, lsr #2
    //     0xb23bf8: tst             x16, HEAP, lsr #32
    //     0xb23bfc: b.eq            #0xb23c04
    //     0xb23c00: bl              #0xd6826c
    // 0xb23c04: r0 = 0
    //     0xb23c04: mov             x0, #0
    // 0xb23c08: StoreField: r1->field_b = r0
    //     0xb23c08: stur            x0, [x1, #0xb]
    // 0xb23c0c: ldr             x0, [fp, #0x18]
    // 0xb23c10: LoadField: r2 = r0->field_17
    //     0xb23c10: ldur            w2, [x0, #0x17]
    // 0xb23c14: DecompressPointer r2
    //     0xb23c14: add             x2, x2, HEAP, lsl #32
    // 0xb23c18: stur            x2, [fp, #-8]
    // 0xb23c1c: r0 = DualTransitionBuilder()
    //     0xb23c1c: bl              #0xb23cd8  ; AllocateDualTransitionBuilderStub -> DualTransitionBuilder (size=0x1c)
    // 0xb23c20: mov             x3, x0
    // 0xb23c24: ldur            x0, [fp, #-0x20]
    // 0xb23c28: stur            x3, [fp, #-0x28]
    // 0xb23c2c: StoreField: r3->field_b = r0
    //     0xb23c2c: stur            w0, [x3, #0xb]
    // 0xb23c30: ldur            x2, [fp, #-0x18]
    // 0xb23c34: r1 = Function '<anonymous closure>':.
    //     0xb23c34: add             x1, PP, #0x37, lsl #12  ; [pp+0x377a0] AnonymousClosure: (0xb23da0), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::build (0xb23b28)
    //     0xb23c38: ldr             x1, [x1, #0x7a0]
    // 0xb23c3c: r0 = AllocateClosure()
    //     0xb23c3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb23c40: mov             x1, x0
    // 0xb23c44: ldur            x0, [fp, #-0x28]
    // 0xb23c48: StoreField: r0->field_f = r1
    //     0xb23c48: stur            w1, [x0, #0xf]
    // 0xb23c4c: ldur            x2, [fp, #-0x18]
    // 0xb23c50: r1 = Function '<anonymous closure>':.
    //     0xb23c50: add             x1, PP, #0x37, lsl #12  ; [pp+0x377a8] AnonymousClosure: (0xb23d68), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::build (0xb23b28)
    //     0xb23c54: ldr             x1, [x1, #0x7a8]
    // 0xb23c58: r0 = AllocateClosure()
    //     0xb23c58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb23c5c: mov             x1, x0
    // 0xb23c60: ldur            x0, [fp, #-0x28]
    // 0xb23c64: StoreField: r0->field_13 = r1
    //     0xb23c64: stur            w1, [x0, #0x13]
    // 0xb23c68: ldur            x1, [fp, #-8]
    // 0xb23c6c: StoreField: r0->field_17 = r1
    //     0xb23c6c: stur            w1, [x0, #0x17]
    // 0xb23c70: r0 = DualTransitionBuilder()
    //     0xb23c70: bl              #0xb23cd8  ; AllocateDualTransitionBuilderStub -> DualTransitionBuilder (size=0x1c)
    // 0xb23c74: mov             x3, x0
    // 0xb23c78: ldur            x0, [fp, #-0x10]
    // 0xb23c7c: stur            x3, [fp, #-8]
    // 0xb23c80: StoreField: r3->field_b = r0
    //     0xb23c80: stur            w0, [x3, #0xb]
    // 0xb23c84: ldur            x2, [fp, #-0x18]
    // 0xb23c88: r1 = Function '<anonymous closure>':.
    //     0xb23c88: add             x1, PP, #0x37, lsl #12  ; [pp+0x377b0] AnonymousClosure: (0xb23d24), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::build (0xb23b28)
    //     0xb23c8c: ldr             x1, [x1, #0x7b0]
    // 0xb23c90: r0 = AllocateClosure()
    //     0xb23c90: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb23c94: mov             x1, x0
    // 0xb23c98: ldur            x0, [fp, #-8]
    // 0xb23c9c: StoreField: r0->field_f = r1
    //     0xb23c9c: stur            w1, [x0, #0xf]
    // 0xb23ca0: ldur            x2, [fp, #-0x18]
    // 0xb23ca4: r1 = Function '<anonymous closure>':.
    //     0xb23ca4: add             x1, PP, #0x37, lsl #12  ; [pp+0x377b8] AnonymousClosure: (0xb23ce4), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomPageTransition::build (0xb23b28)
    //     0xb23ca8: ldr             x1, [x1, #0x7b8]
    // 0xb23cac: r0 = AllocateClosure()
    //     0xb23cac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xb23cb0: mov             x1, x0
    // 0xb23cb4: ldur            x0, [fp, #-8]
    // 0xb23cb8: StoreField: r0->field_13 = r1
    //     0xb23cb8: stur            w1, [x0, #0x13]
    // 0xb23cbc: ldur            x1, [fp, #-0x28]
    // 0xb23cc0: StoreField: r0->field_17 = r1
    //     0xb23cc0: stur            w1, [x0, #0x17]
    // 0xb23cc4: LeaveFrame
    //     0xb23cc4: mov             SP, fp
    //     0xb23cc8: ldp             fp, lr, [SP], #0x10
    // 0xb23ccc: ret
    //     0xb23ccc: ret             
    // 0xb23cd0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb23cd0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb23cd4: b               #0xb23b40
  }
  [closure] _ZoomExitTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xb23ce4, size: 0x34
    // 0xb23ce4: EnterFrame
    //     0xb23ce4: stp             fp, lr, [SP, #-0x10]!
    //     0xb23ce8: mov             fp, SP
    // 0xb23cec: r0 = _ZoomExitTransition()
    //     0xb23cec: bl              #0xb23d18  ; Allocate_ZoomExitTransitionStub -> _ZoomExitTransition (size=0x1c)
    // 0xb23cf0: ldr             x1, [fp, #0x18]
    // 0xb23cf4: StoreField: r0->field_b = r1
    //     0xb23cf4: stur            w1, [x0, #0xb]
    // 0xb23cf8: r1 = true
    //     0xb23cf8: add             x1, NULL, #0x20  ; true
    // 0xb23cfc: StoreField: r0->field_13 = r1
    //     0xb23cfc: stur            w1, [x0, #0x13]
    // 0xb23d00: StoreField: r0->field_f = r1
    //     0xb23d00: stur            w1, [x0, #0xf]
    // 0xb23d04: ldr             x1, [fp, #0x10]
    // 0xb23d08: StoreField: r0->field_17 = r1
    //     0xb23d08: stur            w1, [x0, #0x17]
    // 0xb23d0c: LeaveFrame
    //     0xb23d0c: mov             SP, fp
    //     0xb23d10: ldp             fp, lr, [SP], #0x10
    // 0xb23d14: ret
    //     0xb23d14: ret             
  }
  [closure] _ZoomEnterTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xb23d24, size: 0x38
    // 0xb23d24: EnterFrame
    //     0xb23d24: stp             fp, lr, [SP, #-0x10]!
    //     0xb23d28: mov             fp, SP
    // 0xb23d2c: r0 = _ZoomEnterTransition()
    //     0xb23d2c: bl              #0xb23d5c  ; Allocate_ZoomEnterTransitionStub -> _ZoomEnterTransition (size=0x1c)
    // 0xb23d30: ldr             x1, [fp, #0x18]
    // 0xb23d34: StoreField: r0->field_b = r1
    //     0xb23d34: stur            w1, [x0, #0xb]
    // 0xb23d38: r1 = false
    //     0xb23d38: add             x1, NULL, #0x30  ; false
    // 0xb23d3c: StoreField: r0->field_17 = r1
    //     0xb23d3c: stur            w1, [x0, #0x17]
    // 0xb23d40: r1 = true
    //     0xb23d40: add             x1, NULL, #0x20  ; true
    // 0xb23d44: StoreField: r0->field_13 = r1
    //     0xb23d44: stur            w1, [x0, #0x13]
    // 0xb23d48: ldr             x1, [fp, #0x10]
    // 0xb23d4c: StoreField: r0->field_f = r1
    //     0xb23d4c: stur            w1, [x0, #0xf]
    // 0xb23d50: LeaveFrame
    //     0xb23d50: mov             SP, fp
    //     0xb23d54: ldp             fp, lr, [SP], #0x10
    // 0xb23d58: ret
    //     0xb23d58: ret             
  }
  [closure] _ZoomExitTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xb23d68, size: 0x38
    // 0xb23d68: EnterFrame
    //     0xb23d68: stp             fp, lr, [SP, #-0x10]!
    //     0xb23d6c: mov             fp, SP
    // 0xb23d70: r0 = _ZoomExitTransition()
    //     0xb23d70: bl              #0xb23d18  ; Allocate_ZoomExitTransitionStub -> _ZoomExitTransition (size=0x1c)
    // 0xb23d74: ldr             x1, [fp, #0x18]
    // 0xb23d78: StoreField: r0->field_b = r1
    //     0xb23d78: stur            w1, [x0, #0xb]
    // 0xb23d7c: r1 = false
    //     0xb23d7c: add             x1, NULL, #0x30  ; false
    // 0xb23d80: StoreField: r0->field_13 = r1
    //     0xb23d80: stur            w1, [x0, #0x13]
    // 0xb23d84: r1 = true
    //     0xb23d84: add             x1, NULL, #0x20  ; true
    // 0xb23d88: StoreField: r0->field_f = r1
    //     0xb23d88: stur            w1, [x0, #0xf]
    // 0xb23d8c: ldr             x1, [fp, #0x10]
    // 0xb23d90: StoreField: r0->field_17 = r1
    //     0xb23d90: stur            w1, [x0, #0x17]
    // 0xb23d94: LeaveFrame
    //     0xb23d94: mov             SP, fp
    //     0xb23d98: ldp             fp, lr, [SP], #0x10
    // 0xb23d9c: ret
    //     0xb23d9c: ret             
  }
  [closure] _ZoomEnterTransition <anonymous closure>(dynamic, BuildContext, Animation<double>, Widget?) {
    // ** addr: 0xb23da0, size: 0x34
    // 0xb23da0: EnterFrame
    //     0xb23da0: stp             fp, lr, [SP, #-0x10]!
    //     0xb23da4: mov             fp, SP
    // 0xb23da8: r0 = _ZoomEnterTransition()
    //     0xb23da8: bl              #0xb23d5c  ; Allocate_ZoomEnterTransitionStub -> _ZoomEnterTransition (size=0x1c)
    // 0xb23dac: ldr             x1, [fp, #0x18]
    // 0xb23db0: StoreField: r0->field_b = r1
    //     0xb23db0: stur            w1, [x0, #0xb]
    // 0xb23db4: r1 = true
    //     0xb23db4: add             x1, NULL, #0x20  ; true
    // 0xb23db8: StoreField: r0->field_17 = r1
    //     0xb23db8: stur            w1, [x0, #0x17]
    // 0xb23dbc: StoreField: r0->field_13 = r1
    //     0xb23dbc: stur            w1, [x0, #0x13]
    // 0xb23dc0: ldr             x1, [fp, #0x10]
    // 0xb23dc4: StoreField: r0->field_f = r1
    //     0xb23dc4: stur            w1, [x0, #0xf]
    // 0xb23dc8: LeaveFrame
    //     0xb23dc8: mov             SP, fp
    //     0xb23dcc: ldp             fp, lr, [SP], #0x10
    // 0xb23dd0: ret
    //     0xb23dd0: ret             
  }
}

// class id: 3847, size: 0x18, field offset: 0xc
class _FadeUpwardsPageTransition extends StatelessWidget {

  static late final Tween<Offset> _bottomUpTween; // offset: 0xde4
  static late final Animatable<double> _fastOutSlowInTween; // offset: 0xde8
  static late final Animatable<double> _easeInTween; // offset: 0xdec

  _ _FadeUpwardsPageTransition(/* No info */) {
    // ** addr: 0xa8a9ec, size: 0x128
    // 0xa8a9ec: EnterFrame
    //     0xa8a9ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa8a9f0: mov             fp, SP
    // 0xa8a9f4: AllocStack(0x8)
    //     0xa8a9f4: sub             SP, SP, #8
    // 0xa8a9f8: CheckStackOverflow
    //     0xa8a9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8a9fc: cmp             SP, x16
    //     0xa8aa00: b.ls            #0xa8ab0c
    // 0xa8aa04: ldr             x0, [fp, #0x18]
    // 0xa8aa08: ldr             x1, [fp, #0x20]
    // 0xa8aa0c: StoreField: r1->field_13 = r0
    //     0xa8aa0c: stur            w0, [x1, #0x13]
    //     0xa8aa10: ldurb           w16, [x1, #-1]
    //     0xa8aa14: ldurb           w17, [x0, #-1]
    //     0xa8aa18: and             x16, x17, x16, lsr #2
    //     0xa8aa1c: tst             x16, HEAP, lsr #32
    //     0xa8aa20: b.eq            #0xa8aa28
    //     0xa8aa24: bl              #0xd6826c
    // 0xa8aa28: r0 = InitLateStaticField(0xde4) // [package:flutter/src/material/page_transitions_theme.dart] _FadeUpwardsPageTransition::_bottomUpTween
    //     0xa8aa28: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa8aa2c: ldr             x0, [x0, #0x1bc8]
    //     0xa8aa30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa8aa34: cmp             w0, w16
    //     0xa8aa38: b.ne            #0xa8aa48
    //     0xa8aa3c: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2aaf8] Field <_FadeUpwardsPageTransition@789490068._bottomUpTween@789490068>: static late final (offset: 0xde4)
    //     0xa8aa40: ldr             x2, [x2, #0xaf8]
    //     0xa8aa44: bl              #0xd67cdc
    // 0xa8aa48: stur            x0, [fp, #-8]
    // 0xa8aa4c: r0 = InitLateStaticField(0xde8) // [package:flutter/src/material/page_transitions_theme.dart] _FadeUpwardsPageTransition::_fastOutSlowInTween
    //     0xa8aa4c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa8aa50: ldr             x0, [x0, #0x1bd0]
    //     0xa8aa54: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa8aa58: cmp             w0, w16
    //     0xa8aa5c: b.ne            #0xa8aa6c
    //     0xa8aa60: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab00] Field <_FadeUpwardsPageTransition@789490068._fastOutSlowInTween@789490068>: static late final (offset: 0xde8)
    //     0xa8aa64: ldr             x2, [x2, #0xb00]
    //     0xa8aa68: bl              #0xd67cdc
    // 0xa8aa6c: ldur            x16, [fp, #-8]
    // 0xa8aa70: stp             x0, x16, [SP, #-0x10]!
    // 0xa8aa74: r0 = chain()
    //     0xa8aa74: bl              #0x7b76c8  ; [package:flutter/src/animation/tween.dart] Animatable::chain
    // 0xa8aa78: add             SP, SP, #0x10
    // 0xa8aa7c: ldr             x16, [fp, #0x10]
    // 0xa8aa80: stp             x16, x0, [SP, #-0x10]!
    // 0xa8aa84: r0 = animate()
    //     0xa8aa84: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xa8aa88: add             SP, SP, #0x10
    // 0xa8aa8c: ldr             x1, [fp, #0x20]
    // 0xa8aa90: StoreField: r1->field_b = r0
    //     0xa8aa90: stur            w0, [x1, #0xb]
    //     0xa8aa94: ldurb           w16, [x1, #-1]
    //     0xa8aa98: ldurb           w17, [x0, #-1]
    //     0xa8aa9c: and             x16, x17, x16, lsr #2
    //     0xa8aaa0: tst             x16, HEAP, lsr #32
    //     0xa8aaa4: b.eq            #0xa8aaac
    //     0xa8aaa8: bl              #0xd6826c
    // 0xa8aaac: r0 = InitLateStaticField(0xdec) // [package:flutter/src/material/page_transitions_theme.dart] _FadeUpwardsPageTransition::_easeInTween
    //     0xa8aaac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa8aab0: ldr             x0, [x0, #0x1bd8]
    //     0xa8aab4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa8aab8: cmp             w0, w16
    //     0xa8aabc: b.ne            #0xa8aacc
    //     0xa8aac0: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2ab08] Field <_FadeUpwardsPageTransition@789490068._easeInTween@789490068>: static late final (offset: 0xdec)
    //     0xa8aac4: ldr             x2, [x2, #0xb08]
    //     0xa8aac8: bl              #0xd67cdc
    // 0xa8aacc: ldr             x16, [fp, #0x10]
    // 0xa8aad0: stp             x16, x0, [SP, #-0x10]!
    // 0xa8aad4: r0 = animate()
    //     0xa8aad4: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xa8aad8: add             SP, SP, #0x10
    // 0xa8aadc: ldr             x1, [fp, #0x20]
    // 0xa8aae0: StoreField: r1->field_f = r0
    //     0xa8aae0: stur            w0, [x1, #0xf]
    //     0xa8aae4: ldurb           w16, [x1, #-1]
    //     0xa8aae8: ldurb           w17, [x0, #-1]
    //     0xa8aaec: and             x16, x17, x16, lsr #2
    //     0xa8aaf0: tst             x16, HEAP, lsr #32
    //     0xa8aaf4: b.eq            #0xa8aafc
    //     0xa8aaf8: bl              #0xd6826c
    // 0xa8aafc: r0 = Null
    //     0xa8aafc: mov             x0, NULL
    // 0xa8ab00: LeaveFrame
    //     0xa8ab00: mov             SP, fp
    //     0xa8ab04: ldp             fp, lr, [SP], #0x10
    // 0xa8ab08: ret
    //     0xa8ab08: ret             
    // 0xa8ab0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8ab0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8ab10: b               #0xa8aa04
  }
  static Animatable<double> _fastOutSlowInTween() {
    // ** addr: 0xa8ab14, size: 0x28
    // 0xa8ab14: EnterFrame
    //     0xa8ab14: stp             fp, lr, [SP, #-0x10]!
    //     0xa8ab18: mov             fp, SP
    // 0xa8ab1c: r1 = <double>
    //     0xa8ab1c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa8ab20: r0 = CurveTween()
    //     0xa8ab20: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0xa8ab24: r1 = Instance_Cubic
    //     0xa8ab24: add             x1, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0xa8ab28: ldr             x1, [x1, #0x2c8]
    // 0xa8ab2c: StoreField: r0->field_b = r1
    //     0xa8ab2c: stur            w1, [x0, #0xb]
    // 0xa8ab30: LeaveFrame
    //     0xa8ab30: mov             SP, fp
    //     0xa8ab34: ldp             fp, lr, [SP], #0x10
    // 0xa8ab38: ret
    //     0xa8ab38: ret             
  }
  static Tween<Offset> _bottomUpTween() {
    // ** addr: 0xa8ab3c, size: 0x34
    // 0xa8ab3c: EnterFrame
    //     0xa8ab3c: stp             fp, lr, [SP, #-0x10]!
    //     0xa8ab40: mov             fp, SP
    // 0xa8ab44: r1 = <Offset>
    //     0xa8ab44: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0xa8ab48: ldr             x1, [x1, #0x7f8]
    // 0xa8ab4c: r0 = Tween()
    //     0xa8ab4c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xa8ab50: r1 = Instance_Offset
    //     0xa8ab50: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2ab10] Obj!Offset@b5f291
    //     0xa8ab54: ldr             x1, [x1, #0xb10]
    // 0xa8ab58: StoreField: r0->field_b = r1
    //     0xa8ab58: stur            w1, [x0, #0xb]
    // 0xa8ab5c: r1 = Instance_Offset
    //     0xa8ab5c: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa8ab60: StoreField: r0->field_f = r1
    //     0xa8ab60: stur            w1, [x0, #0xf]
    // 0xa8ab64: LeaveFrame
    //     0xa8ab64: mov             SP, fp
    //     0xa8ab68: ldp             fp, lr, [SP], #0x10
    // 0xa8ab6c: ret
    //     0xa8ab6c: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xb23aa8, size: 0x80
    // 0xb23aa8: EnterFrame
    //     0xb23aa8: stp             fp, lr, [SP, #-0x10]!
    //     0xb23aac: mov             fp, SP
    // 0xb23ab0: AllocStack(0x20)
    //     0xb23ab0: sub             SP, SP, #0x20
    // 0xb23ab4: ldr             x0, [fp, #0x18]
    // 0xb23ab8: LoadField: r1 = r0->field_b
    //     0xb23ab8: ldur            w1, [x0, #0xb]
    // 0xb23abc: DecompressPointer r1
    //     0xb23abc: add             x1, x1, HEAP, lsl #32
    // 0xb23ac0: stur            x1, [fp, #-0x18]
    // 0xb23ac4: LoadField: r2 = r0->field_f
    //     0xb23ac4: ldur            w2, [x0, #0xf]
    // 0xb23ac8: DecompressPointer r2
    //     0xb23ac8: add             x2, x2, HEAP, lsl #32
    // 0xb23acc: stur            x2, [fp, #-0x10]
    // 0xb23ad0: LoadField: r3 = r0->field_13
    //     0xb23ad0: ldur            w3, [x0, #0x13]
    // 0xb23ad4: DecompressPointer r3
    //     0xb23ad4: add             x3, x3, HEAP, lsl #32
    // 0xb23ad8: stur            x3, [fp, #-8]
    // 0xb23adc: r0 = FadeTransition()
    //     0xb23adc: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0xb23ae0: mov             x1, x0
    // 0xb23ae4: ldur            x0, [fp, #-0x10]
    // 0xb23ae8: stur            x1, [fp, #-0x20]
    // 0xb23aec: StoreField: r1->field_f = r0
    //     0xb23aec: stur            w0, [x1, #0xf]
    // 0xb23af0: r0 = false
    //     0xb23af0: add             x0, NULL, #0x30  ; false
    // 0xb23af4: StoreField: r1->field_13 = r0
    //     0xb23af4: stur            w0, [x1, #0x13]
    // 0xb23af8: ldur            x0, [fp, #-8]
    // 0xb23afc: StoreField: r1->field_b = r0
    //     0xb23afc: stur            w0, [x1, #0xb]
    // 0xb23b00: r0 = SlideTransition()
    //     0xb23b00: bl              #0x5a122c  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xb23b04: r1 = true
    //     0xb23b04: add             x1, NULL, #0x20  ; true
    // 0xb23b08: StoreField: r0->field_13 = r1
    //     0xb23b08: stur            w1, [x0, #0x13]
    // 0xb23b0c: ldur            x1, [fp, #-0x20]
    // 0xb23b10: StoreField: r0->field_17 = r1
    //     0xb23b10: stur            w1, [x0, #0x17]
    // 0xb23b14: ldur            x1, [fp, #-0x18]
    // 0xb23b18: StoreField: r0->field_b = r1
    //     0xb23b18: stur            w1, [x0, #0xb]
    // 0xb23b1c: LeaveFrame
    //     0xb23b1c: mov             SP, fp
    //     0xb23b20: ldp             fp, lr, [SP], #0x10
    // 0xb23b24: ret
    //     0xb23b24: ret             
  }
}

// class id: 4131, size: 0x1c, field offset: 0xc
//   const constructor, 
class _ZoomExitTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40d8c, size: 0x58
    // 0xa40d8c: EnterFrame
    //     0xa40d8c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40d90: mov             fp, SP
    // 0xa40d94: AllocStack(0x8)
    //     0xa40d94: sub             SP, SP, #8
    // 0xa40d98: CheckStackOverflow
    //     0xa40d98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40d9c: cmp             SP, x16
    //     0xa40da0: b.ls            #0xa40ddc
    // 0xa40da4: r1 = <_ZoomExitTransition>
    //     0xa40da4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40000] TypeArguments: <_ZoomExitTransition>
    //     0xa40da8: ldr             x1, [x1]
    // 0xa40dac: r0 = _ZoomExitTransitionState()
    //     0xa40dac: bl              #0xa40e90  ; Allocate_ZoomExitTransitionStateStub -> _ZoomExitTransitionState (size=0x24)
    // 0xa40db0: mov             x1, x0
    // 0xa40db4: r0 = Sentinel
    //     0xa40db4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40db8: stur            x1, [fp, #-8]
    // 0xa40dbc: StoreField: r1->field_1f = r0
    //     0xa40dbc: stur            w0, [x1, #0x1f]
    // 0xa40dc0: SaveReg r1
    //     0xa40dc0: str             x1, [SP, #-8]!
    // 0xa40dc4: r0 = __ZoomExitTransitionState&State&_ZoomTransitionBase()
    //     0xa40dc4: bl              #0xa40de4  ; [package:flutter/src/material/page_transitions_theme.dart] __ZoomExitTransitionState&State&_ZoomTransitionBase::__ZoomExitTransitionState&State&_ZoomTransitionBase
    // 0xa40dc8: add             SP, SP, #8
    // 0xa40dcc: ldur            x0, [fp, #-8]
    // 0xa40dd0: LeaveFrame
    //     0xa40dd0: mov             SP, fp
    //     0xa40dd4: ldp             fp, lr, [SP], #0x10
    // 0xa40dd8: ret
    //     0xa40dd8: ret             
    // 0xa40ddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa40ddc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40de0: b               #0xa40da4
  }
}

// class id: 4132, size: 0x1c, field offset: 0xc
//   const constructor, 
class _ZoomEnterTransition extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40cd4, size: 0xa0
    // 0xa40cd4: EnterFrame
    //     0xa40cd4: stp             fp, lr, [SP, #-0x10]!
    //     0xa40cd8: mov             fp, SP
    // 0xa40cdc: AllocStack(0x10)
    //     0xa40cdc: sub             SP, SP, #0x10
    // 0xa40ce0: CheckStackOverflow
    //     0xa40ce0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa40ce4: cmp             SP, x16
    //     0xa40ce8: b.ls            #0xa40d6c
    // 0xa40cec: r1 = <_ZoomEnterTransition>
    //     0xa40cec: add             x1, PP, #0x40, lsl #12  ; [pp+0x40008] TypeArguments: <_ZoomEnterTransition>
    //     0xa40cf0: ldr             x1, [x1, #8]
    // 0xa40cf4: r0 = _ZoomEnterTransitionState()
    //     0xa40cf4: bl              #0xa40d80  ; Allocate_ZoomEnterTransitionStateStub -> _ZoomEnterTransitionState (size=0x24)
    // 0xa40cf8: mov             x1, x0
    // 0xa40cfc: r0 = Sentinel
    //     0xa40cfc: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa40d00: stur            x1, [fp, #-8]
    // 0xa40d04: StoreField: r1->field_1f = r0
    //     0xa40d04: stur            w0, [x1, #0x1f]
    // 0xa40d08: StoreField: r1->field_17 = r0
    //     0xa40d08: stur            w0, [x1, #0x17]
    // 0xa40d0c: StoreField: r1->field_1b = r0
    //     0xa40d0c: stur            w0, [x1, #0x1b]
    // 0xa40d10: r0 = SnapshotController()
    //     0xa40d10: bl              #0xa40d74  ; AllocateSnapshotControllerStub -> SnapshotController (size=0x28)
    // 0xa40d14: mov             x1, x0
    // 0xa40d18: r0 = false
    //     0xa40d18: add             x0, NULL, #0x30  ; false
    // 0xa40d1c: stur            x1, [fp, #-0x10]
    // 0xa40d20: StoreField: r1->field_23 = r0
    //     0xa40d20: stur            w0, [x1, #0x23]
    // 0xa40d24: r0 = 0
    //     0xa40d24: mov             x0, #0
    // 0xa40d28: StoreField: r1->field_7 = r0
    //     0xa40d28: stur            x0, [x1, #7]
    // 0xa40d2c: StoreField: r1->field_13 = r0
    //     0xa40d2c: stur            x0, [x1, #0x13]
    // 0xa40d30: StoreField: r1->field_1b = r0
    //     0xa40d30: stur            x0, [x1, #0x1b]
    // 0xa40d34: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0xa40d34: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa40d38: ldr             x0, [x0, #0x1580]
    //     0xa40d3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa40d40: cmp             w0, w16
    //     0xa40d44: b.ne            #0xa40d50
    //     0xa40d48: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0xa40d4c: bl              #0xd67cdc
    // 0xa40d50: ldur            x1, [fp, #-0x10]
    // 0xa40d54: StoreField: r1->field_f = r0
    //     0xa40d54: stur            w0, [x1, #0xf]
    // 0xa40d58: ldur            x0, [fp, #-8]
    // 0xa40d5c: StoreField: r0->field_13 = r1
    //     0xa40d5c: stur            w1, [x0, #0x13]
    // 0xa40d60: LeaveFrame
    //     0xa40d60: mov             SP, fp
    //     0xa40d64: ldp             fp, lr, [SP], #0x10
    // 0xa40d68: ret
    //     0xa40d68: ret             
    // 0xa40d6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa40d6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa40d70: b               #0xa40cec
  }
}

// class id: 4831, size: 0x40, field offset: 0x24
class _ZoomExitTransitionPainter extends SnapshotPainter {

  [closure] void _onStatusChange(dynamic, dynamic) {
    // ** addr: 0x7b7380, size: 0x4c
    // 0x7b7380: EnterFrame
    //     0x7b7380: stp             fp, lr, [SP, #-0x10]!
    //     0x7b7384: mov             fp, SP
    // 0x7b7388: ldr             x0, [fp, #0x18]
    // 0x7b738c: LoadField: r1 = r0->field_17
    //     0x7b738c: ldur            w1, [x0, #0x17]
    // 0x7b7390: DecompressPointer r1
    //     0x7b7390: add             x1, x1, HEAP, lsl #32
    // 0x7b7394: CheckStackOverflow
    //     0x7b7394: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b7398: cmp             SP, x16
    //     0x7b739c: b.ls            #0x7b73c4
    // 0x7b73a0: LoadField: r0 = r1->field_f
    //     0x7b73a0: ldur            w0, [x1, #0xf]
    // 0x7b73a4: DecompressPointer r0
    //     0x7b73a4: add             x0, x0, HEAP, lsl #32
    // 0x7b73a8: SaveReg r0
    //     0x7b73a8: str             x0, [SP, #-8]!
    // 0x7b73ac: r0 = notifyListeners()
    //     0x7b73ac: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x7b73b0: add             SP, SP, #8
    // 0x7b73b4: r0 = Null
    //     0x7b73b4: mov             x0, NULL
    // 0x7b73b8: LeaveFrame
    //     0x7b73b8: mov             SP, fp
    //     0x7b73bc: ldp             fp, lr, [SP], #0x10
    // 0x7b73c0: ret
    //     0x7b73c0: ret             
    // 0x7b73c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b73c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b73c8: b               #0x7b73a0
  }
  _ _ZoomExitTransitionPainter(/* No info */) {
    // ** addr: 0x7b8434, size: 0x248
    // 0x7b8434: EnterFrame
    //     0x7b8434: stp             fp, lr, [SP, #-0x10]!
    //     0x7b8438: mov             fp, SP
    // 0x7b843c: AllocStack(0x8)
    //     0x7b843c: sub             SP, SP, #8
    // 0x7b8440: CheckStackOverflow
    //     0x7b8440: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b8444: cmp             SP, x16
    //     0x7b8448: b.ls            #0x7b8674
    // 0x7b844c: r0 = Matrix4()
    //     0x7b844c: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x7b8450: r4 = 32
    //     0x7b8450: mov             x4, #0x20
    // 0x7b8454: stur            x0, [fp, #-8]
    // 0x7b8458: r0 = AllocateFloat64Array()
    //     0x7b8458: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x7b845c: mov             x1, x0
    // 0x7b8460: ldur            x0, [fp, #-8]
    // 0x7b8464: StoreField: r0->field_7 = r1
    //     0x7b8464: stur            w1, [x0, #7]
    // 0x7b8468: ldr             x2, [fp, #0x30]
    // 0x7b846c: StoreField: r2->field_33 = r0
    //     0x7b846c: stur            w0, [x2, #0x33]
    //     0x7b8470: ldurb           w16, [x2, #-1]
    //     0x7b8474: ldurb           w17, [x0, #-1]
    //     0x7b8478: and             x16, x17, x16, lsr #2
    //     0x7b847c: tst             x16, HEAP, lsr #32
    //     0x7b8480: b.eq            #0x7b8488
    //     0x7b8484: bl              #0xd6828c
    // 0x7b8488: r1 = <OpacityLayer>
    //     0x7b8488: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6f8] TypeArguments: <OpacityLayer>
    //     0x7b848c: ldr             x1, [x1, #0x6f8]
    // 0x7b8490: r0 = LayerHandle()
    //     0x7b8490: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x7b8494: ldr             x2, [fp, #0x30]
    // 0x7b8498: StoreField: r2->field_37 = r0
    //     0x7b8498: stur            w0, [x2, #0x37]
    //     0x7b849c: ldurb           w16, [x2, #-1]
    //     0x7b84a0: ldurb           w17, [x0, #-1]
    //     0x7b84a4: and             x16, x17, x16, lsr #2
    //     0x7b84a8: tst             x16, HEAP, lsr #32
    //     0x7b84ac: b.eq            #0x7b84b4
    //     0x7b84b0: bl              #0xd6828c
    // 0x7b84b4: r1 = <TransformLayer>
    //     0x7b84b4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40c20] TypeArguments: <TransformLayer>
    //     0x7b84b8: ldr             x1, [x1, #0xc20]
    // 0x7b84bc: r0 = LayerHandle()
    //     0x7b84bc: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x7b84c0: ldr             x1, [fp, #0x30]
    // 0x7b84c4: StoreField: r1->field_3b = r0
    //     0x7b84c4: stur            w0, [x1, #0x3b]
    //     0x7b84c8: ldurb           w16, [x1, #-1]
    //     0x7b84cc: ldurb           w17, [x0, #-1]
    //     0x7b84d0: and             x16, x17, x16, lsr #2
    //     0x7b84d4: tst             x16, HEAP, lsr #32
    //     0x7b84d8: b.eq            #0x7b84e0
    //     0x7b84dc: bl              #0xd6826c
    // 0x7b84e0: ldr             x0, [fp, #0x18]
    // 0x7b84e4: StoreField: r1->field_23 = r0
    //     0x7b84e4: stur            w0, [x1, #0x23]
    // 0x7b84e8: ldr             x0, [fp, #0x10]
    // 0x7b84ec: StoreField: r1->field_27 = r0
    //     0x7b84ec: stur            w0, [x1, #0x27]
    //     0x7b84f0: ldurb           w16, [x1, #-1]
    //     0x7b84f4: ldurb           w17, [x0, #-1]
    //     0x7b84f8: and             x16, x17, x16, lsr #2
    //     0x7b84fc: tst             x16, HEAP, lsr #32
    //     0x7b8500: b.eq            #0x7b8508
    //     0x7b8504: bl              #0xd6826c
    // 0x7b8508: ldr             x0, [fp, #0x20]
    // 0x7b850c: StoreField: r1->field_2b = r0
    //     0x7b850c: stur            w0, [x1, #0x2b]
    //     0x7b8510: ldurb           w16, [x1, #-1]
    //     0x7b8514: ldurb           w17, [x0, #-1]
    //     0x7b8518: and             x16, x17, x16, lsr #2
    //     0x7b851c: tst             x16, HEAP, lsr #32
    //     0x7b8520: b.eq            #0x7b8528
    //     0x7b8524: bl              #0xd6826c
    // 0x7b8528: ldr             x0, [fp, #0x28]
    // 0x7b852c: StoreField: r1->field_2f = r0
    //     0x7b852c: stur            w0, [x1, #0x2f]
    //     0x7b8530: ldurb           w16, [x1, #-1]
    //     0x7b8534: ldurb           w17, [x0, #-1]
    //     0x7b8538: and             x16, x17, x16, lsr #2
    //     0x7b853c: tst             x16, HEAP, lsr #32
    //     0x7b8540: b.eq            #0x7b8548
    //     0x7b8544: bl              #0xd6826c
    // 0x7b8548: r0 = 0
    //     0x7b8548: mov             x0, #0
    // 0x7b854c: StoreField: r1->field_7 = r0
    //     0x7b854c: stur            x0, [x1, #7]
    // 0x7b8550: StoreField: r1->field_13 = r0
    //     0x7b8550: stur            x0, [x1, #0x13]
    // 0x7b8554: StoreField: r1->field_1b = r0
    //     0x7b8554: stur            x0, [x1, #0x1b]
    // 0x7b8558: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x7b8558: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b855c: ldr             x0, [x0, #0x1580]
    //     0x7b8560: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b8564: cmp             w0, w16
    //     0x7b8568: b.ne            #0x7b8574
    //     0x7b856c: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x7b8570: bl              #0xd67cdc
    // 0x7b8574: ldr             x1, [fp, #0x30]
    // 0x7b8578: StoreField: r1->field_f = r0
    //     0x7b8578: stur            w0, [x1, #0xf]
    //     0x7b857c: ldurb           w16, [x1, #-1]
    //     0x7b8580: ldurb           w17, [x0, #-1]
    //     0x7b8584: and             x16, x17, x16, lsr #2
    //     0x7b8588: tst             x16, HEAP, lsr #32
    //     0x7b858c: b.eq            #0x7b8594
    //     0x7b8590: bl              #0xd6826c
    // 0x7b8594: r1 = 1
    //     0x7b8594: mov             x1, #1
    // 0x7b8598: r0 = AllocateContext()
    //     0x7b8598: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b859c: mov             x1, x0
    // 0x7b85a0: ldr             x0, [fp, #0x30]
    // 0x7b85a4: StoreField: r1->field_f = r0
    //     0x7b85a4: stur            w0, [x1, #0xf]
    // 0x7b85a8: mov             x2, x1
    // 0x7b85ac: r1 = Function 'notifyListeners':.
    //     0x7b85ac: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x7b85b0: ldr             x1, [x1, #0x298]
    // 0x7b85b4: r0 = AllocateClosure()
    //     0x7b85b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b85b8: ldr             x16, [fp, #0x10]
    // 0x7b85bc: stp             x0, x16, [SP, #-0x10]!
    // 0x7b85c0: r0 = addListener()
    //     0x7b85c0: bl              #0x6e954c  ; [package:flutter/src/animation/tween.dart] __AnimatedEvaluation&Animation&AnimationWithParentMixin::addListener
    // 0x7b85c4: add             SP, SP, #0x10
    // 0x7b85c8: r1 = 1
    //     0x7b85c8: mov             x1, #1
    // 0x7b85cc: r0 = AllocateContext()
    //     0x7b85cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b85d0: mov             x1, x0
    // 0x7b85d4: ldr             x0, [fp, #0x30]
    // 0x7b85d8: StoreField: r1->field_f = r0
    //     0x7b85d8: stur            w0, [x1, #0xf]
    // 0x7b85dc: mov             x2, x1
    // 0x7b85e0: r1 = Function 'notifyListeners':.
    //     0x7b85e0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x7b85e4: ldr             x1, [x1, #0x298]
    // 0x7b85e8: r0 = AllocateClosure()
    //     0x7b85e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b85ec: mov             x1, x0
    // 0x7b85f0: ldr             x0, [fp, #0x20]
    // 0x7b85f4: r2 = LoadClassIdInstr(r0)
    //     0x7b85f4: ldur            x2, [x0, #-1]
    //     0x7b85f8: ubfx            x2, x2, #0xc, #0x14
    // 0x7b85fc: stp             x1, x0, [SP, #-0x10]!
    // 0x7b8600: mov             x0, x2
    // 0x7b8604: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b8604: mov             x17, #0xc3ab
    //     0x7b8608: add             lr, x0, x17
    //     0x7b860c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b8610: blr             lr
    // 0x7b8614: add             SP, SP, #0x10
    // 0x7b8618: r1 = 1
    //     0x7b8618: mov             x1, #1
    // 0x7b861c: r0 = AllocateContext()
    //     0x7b861c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b8620: mov             x1, x0
    // 0x7b8624: ldr             x0, [fp, #0x30]
    // 0x7b8628: StoreField: r1->field_f = r0
    //     0x7b8628: stur            w0, [x1, #0xf]
    // 0x7b862c: mov             x2, x1
    // 0x7b8630: r1 = Function '_onStatusChange@789490068':.
    //     0x7b8630: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6c8] AnonymousClosure: (0x7b7380), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter
    //     0x7b8634: ldr             x1, [x1, #0x6c8]
    // 0x7b8638: r0 = AllocateClosure()
    //     0x7b8638: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b863c: mov             x1, x0
    // 0x7b8640: ldr             x0, [fp, #0x28]
    // 0x7b8644: r2 = LoadClassIdInstr(r0)
    //     0x7b8644: ldur            x2, [x0, #-1]
    //     0x7b8648: ubfx            x2, x2, #0xc, #0x14
    // 0x7b864c: stp             x1, x0, [SP, #-0x10]!
    // 0x7b8650: mov             x0, x2
    // 0x7b8654: r0 = GDT[cid_x0 + 0x80c]()
    //     0x7b8654: add             lr, x0, #0x80c
    //     0x7b8658: ldr             lr, [x21, lr, lsl #3]
    //     0x7b865c: blr             lr
    // 0x7b8660: add             SP, SP, #0x10
    // 0x7b8664: r0 = Null
    //     0x7b8664: mov             x0, NULL
    // 0x7b8668: LeaveFrame
    //     0x7b8668: mov             SP, fp
    //     0x7b866c: ldp             fp, lr, [SP], #0x10
    // 0x7b8670: ret
    //     0x7b8670: ret             
    // 0x7b8674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b8674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b8678: b               #0x7b844c
  }
  dynamic dispose(dynamic) {
    // ** addr: 0x9ba208, size: 0x18
    // 0x9ba208: r4 = 0
    //     0x9ba208: mov             x4, #0
    // 0x9ba20c: r1 = Function 'dispose':.
    //     0x9ba20c: add             x17, PP, #0x50, lsl #12  ; [pp+0x50910] AnonymousClosure: (0x9ba220), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::dispose (0x9c2694)
    //     0x9ba210: ldr             x1, [x17, #0x910]
    // 0x9ba214: r24 = BuildNonGenericMethodExtractorStub
    //     0x9ba214: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9ba218: LoadField: r0 = r24->field_17
    //     0x9ba218: ldur            x0, [x24, #0x17]
    // 0x9ba21c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0x9ba220, size: 0x48
    // 0x9ba220: EnterFrame
    //     0x9ba220: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba224: mov             fp, SP
    // 0x9ba228: ldr             x0, [fp, #0x10]
    // 0x9ba22c: LoadField: r1 = r0->field_17
    //     0x9ba22c: ldur            w1, [x0, #0x17]
    // 0x9ba230: DecompressPointer r1
    //     0x9ba230: add             x1, x1, HEAP, lsl #32
    // 0x9ba234: CheckStackOverflow
    //     0x9ba234: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ba238: cmp             SP, x16
    //     0x9ba23c: b.ls            #0x9ba260
    // 0x9ba240: LoadField: r0 = r1->field_f
    //     0x9ba240: ldur            w0, [x1, #0xf]
    // 0x9ba244: DecompressPointer r0
    //     0x9ba244: add             x0, x0, HEAP, lsl #32
    // 0x9ba248: SaveReg r0
    //     0x9ba248: str             x0, [SP, #-8]!
    // 0x9ba24c: r0 = dispose()
    //     0x9ba24c: bl              #0x9c2694  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::dispose
    // 0x9ba250: add             SP, SP, #8
    // 0x9ba254: LeaveFrame
    //     0x9ba254: mov             SP, fp
    //     0x9ba258: ldp             fp, lr, [SP], #0x10
    // 0x9ba25c: ret
    //     0x9ba25c: ret             
    // 0x9ba260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba260: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba264: b               #0x9ba240
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9c2694, size: 0x170
    // 0x9c2694: EnterFrame
    //     0x9c2694: stp             fp, lr, [SP, #-0x10]!
    //     0x9c2698: mov             fp, SP
    // 0x9c269c: AllocStack(0x8)
    //     0x9c269c: sub             SP, SP, #8
    // 0x9c26a0: CheckStackOverflow
    //     0x9c26a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9c26a4: cmp             SP, x16
    //     0x9c26a8: b.ls            #0x9c27fc
    // 0x9c26ac: ldr             x0, [fp, #0x10]
    // 0x9c26b0: LoadField: r1 = r0->field_37
    //     0x9c26b0: ldur            w1, [x0, #0x37]
    // 0x9c26b4: DecompressPointer r1
    //     0x9c26b4: add             x1, x1, HEAP, lsl #32
    // 0x9c26b8: stp             NULL, x1, [SP, #-0x10]!
    // 0x9c26bc: r0 = layer=()
    //     0x9c26bc: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x9c26c0: add             SP, SP, #0x10
    // 0x9c26c4: ldr             x0, [fp, #0x10]
    // 0x9c26c8: LoadField: r1 = r0->field_3b
    //     0x9c26c8: ldur            w1, [x0, #0x3b]
    // 0x9c26cc: DecompressPointer r1
    //     0x9c26cc: add             x1, x1, HEAP, lsl #32
    // 0x9c26d0: stp             NULL, x1, [SP, #-0x10]!
    // 0x9c26d4: r0 = layer=()
    //     0x9c26d4: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x9c26d8: add             SP, SP, #0x10
    // 0x9c26dc: ldr             x0, [fp, #0x10]
    // 0x9c26e0: LoadField: r1 = r0->field_27
    //     0x9c26e0: ldur            w1, [x0, #0x27]
    // 0x9c26e4: DecompressPointer r1
    //     0x9c26e4: add             x1, x1, HEAP, lsl #32
    // 0x9c26e8: stur            x1, [fp, #-8]
    // 0x9c26ec: r1 = 1
    //     0x9c26ec: mov             x1, #1
    // 0x9c26f0: r0 = AllocateContext()
    //     0x9c26f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c26f4: mov             x1, x0
    // 0x9c26f8: ldr             x0, [fp, #0x10]
    // 0x9c26fc: StoreField: r1->field_f = r0
    //     0x9c26fc: stur            w0, [x1, #0xf]
    // 0x9c2700: mov             x2, x1
    // 0x9c2704: r1 = Function 'notifyListeners':.
    //     0x9c2704: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c2708: ldr             x1, [x1, #0x298]
    // 0x9c270c: r0 = AllocateClosure()
    //     0x9c270c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2710: ldur            x16, [fp, #-8]
    // 0x9c2714: stp             x0, x16, [SP, #-0x10]!
    // 0x9c2718: r0 = removeListener()
    //     0x9c2718: bl              #0x6f61cc  ; [package:flutter/src/animation/tween.dart] __AnimatedEvaluation&Animation&AnimationWithParentMixin::removeListener
    // 0x9c271c: add             SP, SP, #0x10
    // 0x9c2720: ldr             x0, [fp, #0x10]
    // 0x9c2724: LoadField: r1 = r0->field_2b
    //     0x9c2724: ldur            w1, [x0, #0x2b]
    // 0x9c2728: DecompressPointer r1
    //     0x9c2728: add             x1, x1, HEAP, lsl #32
    // 0x9c272c: stur            x1, [fp, #-8]
    // 0x9c2730: r1 = 1
    //     0x9c2730: mov             x1, #1
    // 0x9c2734: r0 = AllocateContext()
    //     0x9c2734: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c2738: mov             x1, x0
    // 0x9c273c: ldr             x0, [fp, #0x10]
    // 0x9c2740: StoreField: r1->field_f = r0
    //     0x9c2740: stur            w0, [x1, #0xf]
    // 0x9c2744: mov             x2, x1
    // 0x9c2748: r1 = Function 'notifyListeners':.
    //     0x9c2748: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c274c: ldr             x1, [x1, #0x298]
    // 0x9c2750: r0 = AllocateClosure()
    //     0x9c2750: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2754: mov             x1, x0
    // 0x9c2758: ldur            x0, [fp, #-8]
    // 0x9c275c: r2 = LoadClassIdInstr(r0)
    //     0x9c275c: ldur            x2, [x0, #-1]
    //     0x9c2760: ubfx            x2, x2, #0xc, #0x14
    // 0x9c2764: stp             x1, x0, [SP, #-0x10]!
    // 0x9c2768: mov             x0, x2
    // 0x9c276c: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x9c276c: mov             x17, #0xc2d6
    //     0x9c2770: add             lr, x0, x17
    //     0x9c2774: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2778: blr             lr
    // 0x9c277c: add             SP, SP, #0x10
    // 0x9c2780: ldr             x0, [fp, #0x10]
    // 0x9c2784: LoadField: r1 = r0->field_2f
    //     0x9c2784: ldur            w1, [x0, #0x2f]
    // 0x9c2788: DecompressPointer r1
    //     0x9c2788: add             x1, x1, HEAP, lsl #32
    // 0x9c278c: stur            x1, [fp, #-8]
    // 0x9c2790: r1 = 1
    //     0x9c2790: mov             x1, #1
    // 0x9c2794: r0 = AllocateContext()
    //     0x9c2794: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c2798: mov             x1, x0
    // 0x9c279c: ldr             x0, [fp, #0x10]
    // 0x9c27a0: StoreField: r1->field_f = r0
    //     0x9c27a0: stur            w0, [x1, #0xf]
    // 0x9c27a4: mov             x2, x1
    // 0x9c27a8: r1 = Function '_onStatusChange@789490068':.
    //     0x9c27a8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6c8] AnonymousClosure: (0x7b7380), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter
    //     0x9c27ac: ldr             x1, [x1, #0x6c8]
    // 0x9c27b0: r0 = AllocateClosure()
    //     0x9c27b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c27b4: mov             x1, x0
    // 0x9c27b8: ldur            x0, [fp, #-8]
    // 0x9c27bc: r2 = LoadClassIdInstr(r0)
    //     0x9c27bc: ldur            x2, [x0, #-1]
    //     0x9c27c0: ubfx            x2, x2, #0xc, #0x14
    // 0x9c27c4: stp             x1, x0, [SP, #-0x10]!
    // 0x9c27c8: mov             x0, x2
    // 0x9c27cc: r0 = GDT[cid_x0 + 0x490]()
    //     0x9c27cc: add             lr, x0, #0x490
    //     0x9c27d0: ldr             lr, [x21, lr, lsl #3]
    //     0x9c27d4: blr             lr
    // 0x9c27d8: add             SP, SP, #0x10
    // 0x9c27dc: ldr             x16, [fp, #0x10]
    // 0x9c27e0: SaveReg r16
    //     0x9c27e0: str             x16, [SP, #-8]!
    // 0x9c27e4: r0 = dispose()
    //     0x9c27e4: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x9c27e8: add             SP, SP, #8
    // 0x9c27ec: r0 = Null
    //     0x9c27ec: mov             x0, NULL
    // 0x9c27f0: LeaveFrame
    //     0x9c27f0: mov             SP, fp
    //     0x9c27f4: ldp             fp, lr, [SP], #0x10
    // 0x9c27f8: ret
    //     0x9c27f8: ret             
    // 0x9c27fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c27fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2800: b               #0x9c26ac
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xcaf2d4, size: 0x180
    // 0xcaf2d4: EnterFrame
    //     0xcaf2d4: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf2d8: mov             fp, SP
    // 0xcaf2dc: AllocStack(0x8)
    //     0xcaf2dc: sub             SP, SP, #8
    // 0xcaf2e0: CheckStackOverflow
    //     0xcaf2e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcaf2e4: cmp             SP, x16
    //     0xcaf2e8: b.ls            #0xcaf44c
    // 0xcaf2ec: ldr             x0, [fp, #0x10]
    // 0xcaf2f0: r2 = Null
    //     0xcaf2f0: mov             x2, NULL
    // 0xcaf2f4: r1 = Null
    //     0xcaf2f4: mov             x1, NULL
    // 0xcaf2f8: r4 = 59
    //     0xcaf2f8: mov             x4, #0x3b
    // 0xcaf2fc: branchIfSmi(r0, 0xcaf308)
    //     0xcaf2fc: tbz             w0, #0, #0xcaf308
    // 0xcaf300: r4 = LoadClassIdInstr(r0)
    //     0xcaf300: ldur            x4, [x0, #-1]
    //     0xcaf304: ubfx            x4, x4, #0xc, #0x14
    // 0xcaf308: r17 = 4831
    //     0xcaf308: mov             x17, #0x12df
    // 0xcaf30c: cmp             x4, x17
    // 0xcaf310: b.eq            #0xcaf328
    // 0xcaf314: r8 = _ZoomExitTransitionPainter
    //     0xcaf314: add             x8, PP, #0x53, lsl #12  ; [pp+0x53088] Type: _ZoomExitTransitionPainter
    //     0xcaf318: ldr             x8, [x8, #0x88]
    // 0xcaf31c: r3 = Null
    //     0xcaf31c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53090] Null
    //     0xcaf320: ldr             x3, [x3, #0x90]
    // 0xcaf324: r0 = DefaultTypeTest()
    //     0xcaf324: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcaf328: ldr             x1, [fp, #0x10]
    // 0xcaf32c: LoadField: r0 = r1->field_23
    //     0xcaf32c: ldur            w0, [x1, #0x23]
    // 0xcaf330: DecompressPointer r0
    //     0xcaf330: add             x0, x0, HEAP, lsl #32
    // 0xcaf334: ldr             x2, [fp, #0x18]
    // 0xcaf338: LoadField: r3 = r2->field_23
    //     0xcaf338: ldur            w3, [x2, #0x23]
    // 0xcaf33c: DecompressPointer r3
    //     0xcaf33c: add             x3, x3, HEAP, lsl #32
    // 0xcaf340: cmp             w0, w3
    // 0xcaf344: b.ne            #0xcaf3bc
    // 0xcaf348: LoadField: r0 = r1->field_2b
    //     0xcaf348: ldur            w0, [x1, #0x2b]
    // 0xcaf34c: DecompressPointer r0
    //     0xcaf34c: add             x0, x0, HEAP, lsl #32
    // 0xcaf350: r3 = LoadClassIdInstr(r0)
    //     0xcaf350: ldur            x3, [x0, #-1]
    //     0xcaf354: ubfx            x3, x3, #0xc, #0x14
    // 0xcaf358: SaveReg r0
    //     0xcaf358: str             x0, [SP, #-8]!
    // 0xcaf35c: mov             x0, x3
    // 0xcaf360: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf360: add             lr, x0, #0xb7c
    //     0xcaf364: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf368: blr             lr
    // 0xcaf36c: add             SP, SP, #8
    // 0xcaf370: mov             x2, x0
    // 0xcaf374: ldr             x1, [fp, #0x18]
    // 0xcaf378: stur            x2, [fp, #-8]
    // 0xcaf37c: LoadField: r0 = r1->field_2b
    //     0xcaf37c: ldur            w0, [x1, #0x2b]
    // 0xcaf380: DecompressPointer r0
    //     0xcaf380: add             x0, x0, HEAP, lsl #32
    // 0xcaf384: r3 = LoadClassIdInstr(r0)
    //     0xcaf384: ldur            x3, [x0, #-1]
    //     0xcaf388: ubfx            x3, x3, #0xc, #0x14
    // 0xcaf38c: SaveReg r0
    //     0xcaf38c: str             x0, [SP, #-8]!
    // 0xcaf390: mov             x0, x3
    // 0xcaf394: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf394: add             lr, x0, #0xb7c
    //     0xcaf398: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf39c: blr             lr
    // 0xcaf3a0: add             SP, SP, #8
    // 0xcaf3a4: mov             x1, x0
    // 0xcaf3a8: ldur            x0, [fp, #-8]
    // 0xcaf3ac: LoadField: d0 = r0->field_7
    //     0xcaf3ac: ldur            d0, [x0, #7]
    // 0xcaf3b0: LoadField: d1 = r1->field_7
    //     0xcaf3b0: ldur            d1, [x1, #7]
    // 0xcaf3b4: fcmp            d0, d1
    // 0xcaf3b8: b.eq            #0xcaf3c4
    // 0xcaf3bc: r0 = true
    //     0xcaf3bc: add             x0, NULL, #0x20  ; true
    // 0xcaf3c0: b               #0xcaf440
    // 0xcaf3c4: ldr             x0, [fp, #0x18]
    // 0xcaf3c8: ldr             x1, [fp, #0x10]
    // 0xcaf3cc: LoadField: r2 = r1->field_27
    //     0xcaf3cc: ldur            w2, [x1, #0x27]
    // 0xcaf3d0: DecompressPointer r2
    //     0xcaf3d0: add             x2, x2, HEAP, lsl #32
    // 0xcaf3d4: LoadField: r1 = r2->field_f
    //     0xcaf3d4: ldur            w1, [x2, #0xf]
    // 0xcaf3d8: DecompressPointer r1
    //     0xcaf3d8: add             x1, x1, HEAP, lsl #32
    // 0xcaf3dc: LoadField: r3 = r2->field_b
    //     0xcaf3dc: ldur            w3, [x2, #0xb]
    // 0xcaf3e0: DecompressPointer r3
    //     0xcaf3e0: add             x3, x3, HEAP, lsl #32
    // 0xcaf3e4: stp             x3, x1, [SP, #-0x10]!
    // 0xcaf3e8: r0 = evaluate()
    //     0xcaf3e8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcaf3ec: add             SP, SP, #0x10
    // 0xcaf3f0: mov             x1, x0
    // 0xcaf3f4: ldr             x0, [fp, #0x18]
    // 0xcaf3f8: stur            x1, [fp, #-8]
    // 0xcaf3fc: LoadField: r2 = r0->field_27
    //     0xcaf3fc: ldur            w2, [x0, #0x27]
    // 0xcaf400: DecompressPointer r2
    //     0xcaf400: add             x2, x2, HEAP, lsl #32
    // 0xcaf404: LoadField: r0 = r2->field_f
    //     0xcaf404: ldur            w0, [x2, #0xf]
    // 0xcaf408: DecompressPointer r0
    //     0xcaf408: add             x0, x0, HEAP, lsl #32
    // 0xcaf40c: LoadField: r3 = r2->field_b
    //     0xcaf40c: ldur            w3, [x2, #0xb]
    // 0xcaf410: DecompressPointer r3
    //     0xcaf410: add             x3, x3, HEAP, lsl #32
    // 0xcaf414: stp             x3, x0, [SP, #-0x10]!
    // 0xcaf418: r0 = evaluate()
    //     0xcaf418: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcaf41c: add             SP, SP, #0x10
    // 0xcaf420: ldur            x1, [fp, #-8]
    // 0xcaf424: LoadField: d0 = r1->field_7
    //     0xcaf424: ldur            d0, [x1, #7]
    // 0xcaf428: LoadField: d1 = r0->field_7
    //     0xcaf428: ldur            d1, [x0, #7]
    // 0xcaf42c: fcmp            d0, d1
    // 0xcaf430: r16 = true
    //     0xcaf430: add             x16, NULL, #0x20  ; true
    // 0xcaf434: r17 = false
    //     0xcaf434: add             x17, NULL, #0x30  ; false
    // 0xcaf438: csel            x1, x16, x17, ne
    // 0xcaf43c: mov             x0, x1
    // 0xcaf440: LeaveFrame
    //     0xcaf440: mov             SP, fp
    //     0xcaf444: ldp             fp, lr, [SP], #0x10
    // 0xcaf448: ret
    //     0xcaf448: ret             
    // 0xcaf44c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcaf44c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcaf450: b               #0xcaf2ec
  }
  _ paintSnapshot(/* No info */) {
    // ** addr: 0xcafa2c, size: 0xac
    // 0xcafa2c: EnterFrame
    //     0xcafa2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcafa30: mov             fp, SP
    // 0xcafa34: AllocStack(0x8)
    //     0xcafa34: sub             SP, SP, #8
    // 0xcafa38: CheckStackOverflow
    //     0xcafa38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcafa3c: cmp             SP, x16
    //     0xcafa40: b.ls            #0xcafad0
    // 0xcafa44: ldr             x0, [fp, #0x38]
    // 0xcafa48: LoadField: r1 = r0->field_27
    //     0xcafa48: ldur            w1, [x0, #0x27]
    // 0xcafa4c: DecompressPointer r1
    //     0xcafa4c: add             x1, x1, HEAP, lsl #32
    // 0xcafa50: LoadField: r2 = r1->field_f
    //     0xcafa50: ldur            w2, [x1, #0xf]
    // 0xcafa54: DecompressPointer r2
    //     0xcafa54: add             x2, x2, HEAP, lsl #32
    // 0xcafa58: LoadField: r3 = r1->field_b
    //     0xcafa58: ldur            w3, [x1, #0xb]
    // 0xcafa5c: DecompressPointer r3
    //     0xcafa5c: add             x3, x3, HEAP, lsl #32
    // 0xcafa60: stp             x3, x2, [SP, #-0x10]!
    // 0xcafa64: r0 = evaluate()
    //     0xcafa64: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcafa68: add             SP, SP, #0x10
    // 0xcafa6c: mov             x1, x0
    // 0xcafa70: ldr             x0, [fp, #0x38]
    // 0xcafa74: stur            x1, [fp, #-8]
    // 0xcafa78: LoadField: r2 = r0->field_2b
    //     0xcafa78: ldur            w2, [x0, #0x2b]
    // 0xcafa7c: DecompressPointer r2
    //     0xcafa7c: add             x2, x2, HEAP, lsl #32
    // 0xcafa80: r0 = LoadClassIdInstr(r2)
    //     0xcafa80: ldur            x0, [x2, #-1]
    //     0xcafa84: ubfx            x0, x0, #0xc, #0x14
    // 0xcafa88: SaveReg r2
    //     0xcafa88: str             x2, [SP, #-8]!
    // 0xcafa8c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcafa8c: add             lr, x0, #0xb7c
    //     0xcafa90: ldr             lr, [x21, lr, lsl #3]
    //     0xcafa94: blr             lr
    // 0xcafa98: add             SP, SP, #8
    // 0xcafa9c: ldr             x16, [fp, #0x30]
    // 0xcafaa0: ldr             lr, [fp, #0x18]
    // 0xcafaa4: stp             lr, x16, [SP, #-0x10]!
    // 0xcafaa8: ldur            x16, [fp, #-8]
    // 0xcafaac: stp             x0, x16, [SP, #-0x10]!
    // 0xcafab0: ldr             d0, [fp, #0x10]
    // 0xcafab4: SaveReg d0
    //     0xcafab4: str             d0, [SP, #-8]!
    // 0xcafab8: r0 = _drawImageScaledAndCentered()
    //     0xcafab8: bl              #0xcaf588  ; [package:flutter/src/material/page_transitions_theme.dart] ::_drawImageScaledAndCentered
    // 0xcafabc: add             SP, SP, #0x28
    // 0xcafac0: r0 = Null
    //     0xcafac0: mov             x0, NULL
    // 0xcafac4: LeaveFrame
    //     0xcafac4: mov             SP, fp
    //     0xcafac8: ldp             fp, lr, [SP], #0x10
    // 0xcafacc: ret
    //     0xcafacc: ret             
    // 0xcafad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcafad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcafad4: b               #0xcafa44
  }
  _ paint(/* No info */) {
    // ** addr: 0xcb0580, size: 0x1a0
    // 0xcb0580: EnterFrame
    //     0xcb0580: stp             fp, lr, [SP, #-0x10]!
    //     0xcb0584: mov             fp, SP
    // 0xcb0588: AllocStack(0x20)
    //     0xcb0588: sub             SP, SP, #0x20
    // 0xcb058c: CheckStackOverflow
    //     0xcb058c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb0590: cmp             SP, x16
    //     0xcb0594: b.ls            #0xcb0714
    // 0xcb0598: r1 = 2
    //     0xcb0598: mov             x1, #2
    // 0xcb059c: r0 = AllocateContext()
    //     0xcb059c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcb05a0: mov             x2, x0
    // 0xcb05a4: ldr             x1, [fp, #0x30]
    // 0xcb05a8: stur            x2, [fp, #-8]
    // 0xcb05ac: StoreField: r2->field_f = r1
    //     0xcb05ac: stur            w1, [x2, #0xf]
    // 0xcb05b0: ldr             x0, [fp, #0x10]
    // 0xcb05b4: StoreField: r2->field_13 = r0
    //     0xcb05b4: stur            w0, [x2, #0x13]
    // 0xcb05b8: LoadField: r0 = r1->field_2f
    //     0xcb05b8: ldur            w0, [x1, #0x2f]
    // 0xcb05bc: DecompressPointer r0
    //     0xcb05bc: add             x0, x0, HEAP, lsl #32
    // 0xcb05c0: r3 = LoadClassIdInstr(r0)
    //     0xcb05c0: ldur            x3, [x0, #-1]
    //     0xcb05c4: ubfx            x3, x3, #0xc, #0x14
    // 0xcb05c8: SaveReg r0
    //     0xcb05c8: str             x0, [SP, #-8]!
    // 0xcb05cc: mov             x0, x3
    // 0xcb05d0: r0 = GDT[cid_x0 + 0x376]()
    //     0xcb05d0: add             lr, x0, #0x376
    //     0xcb05d4: ldr             lr, [x21, lr, lsl #3]
    //     0xcb05d8: blr             lr
    // 0xcb05dc: add             SP, SP, #8
    // 0xcb05e0: LoadField: r1 = r0->field_7
    //     0xcb05e0: ldur            x1, [x0, #7]
    // 0xcb05e4: cmp             x1, #1
    // 0xcb05e8: b.gt            #0xcb05f8
    // 0xcb05ec: cmp             x1, #0
    // 0xcb05f0: b.gt            #0xcb0600
    // 0xcb05f4: b               #0xcb06d0
    // 0xcb05f8: cmp             x1, #2
    // 0xcb05fc: b.gt            #0xcb06d0
    // 0xcb0600: ldr             x0, [fp, #0x30]
    // 0xcb0604: LoadField: r1 = r0->field_33
    //     0xcb0604: ldur            w1, [x0, #0x33]
    // 0xcb0608: DecompressPointer r1
    //     0xcb0608: add             x1, x1, HEAP, lsl #32
    // 0xcb060c: stur            x1, [fp, #-0x10]
    // 0xcb0610: LoadField: r2 = r0->field_27
    //     0xcb0610: ldur            w2, [x0, #0x27]
    // 0xcb0614: DecompressPointer r2
    //     0xcb0614: add             x2, x2, HEAP, lsl #32
    // 0xcb0618: LoadField: r3 = r2->field_f
    //     0xcb0618: ldur            w3, [x2, #0xf]
    // 0xcb061c: DecompressPointer r3
    //     0xcb061c: add             x3, x3, HEAP, lsl #32
    // 0xcb0620: LoadField: r4 = r2->field_b
    //     0xcb0620: ldur            w4, [x2, #0xb]
    // 0xcb0624: DecompressPointer r4
    //     0xcb0624: add             x4, x4, HEAP, lsl #32
    // 0xcb0628: stp             x4, x3, [SP, #-0x10]!
    // 0xcb062c: r0 = evaluate()
    //     0xcb062c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcb0630: add             SP, SP, #0x10
    // 0xcb0634: LoadField: d0 = r0->field_7
    //     0xcb0634: ldur            d0, [x0, #7]
    // 0xcb0638: ldur            x16, [fp, #-0x10]
    // 0xcb063c: SaveReg r16
    //     0xcb063c: str             x16, [SP, #-8]!
    // 0xcb0640: SaveReg d0
    //     0xcb0640: str             d0, [SP, #-8]!
    // 0xcb0644: ldr             x16, [fp, #0x18]
    // 0xcb0648: SaveReg r16
    //     0xcb0648: str             x16, [SP, #-8]!
    // 0xcb064c: r0 = _updateScaledTransform()
    //     0xcb064c: bl              #0xcb02ec  ; [package:flutter/src/material/page_transitions_theme.dart] ::_updateScaledTransform
    // 0xcb0650: add             SP, SP, #0x18
    // 0xcb0654: ldr             x0, [fp, #0x30]
    // 0xcb0658: LoadField: r3 = r0->field_3b
    //     0xcb0658: ldur            w3, [x0, #0x3b]
    // 0xcb065c: DecompressPointer r3
    //     0xcb065c: add             x3, x3, HEAP, lsl #32
    // 0xcb0660: stur            x3, [fp, #-0x20]
    // 0xcb0664: LoadField: r0 = r3->field_b
    //     0xcb0664: ldur            w0, [x3, #0xb]
    // 0xcb0668: DecompressPointer r0
    //     0xcb0668: add             x0, x0, HEAP, lsl #32
    // 0xcb066c: ldur            x2, [fp, #-8]
    // 0xcb0670: stur            x0, [fp, #-0x18]
    // 0xcb0674: r1 = Function '<anonymous closure>':.
    //     0xcb0674: add             x1, PP, #0x55, lsl #12  ; [pp+0x55888] AnonymousClosure: (0xcb0720), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter::paint (0xcb0580)
    //     0xcb0678: ldr             x1, [x1, #0x888]
    // 0xcb067c: r0 = AllocateClosure()
    //     0xcb067c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcb0680: ldr             x16, [fp, #0x28]
    // 0xcb0684: r30 = true
    //     0xcb0684: add             lr, NULL, #0x20  ; true
    // 0xcb0688: stp             lr, x16, [SP, #-0x10]!
    // 0xcb068c: ldr             x16, [fp, #0x20]
    // 0xcb0690: ldur            lr, [fp, #-0x10]
    // 0xcb0694: stp             lr, x16, [SP, #-0x10]!
    // 0xcb0698: ldur            x16, [fp, #-0x18]
    // 0xcb069c: stp             x16, x0, [SP, #-0x10]!
    // 0xcb06a0: r4 = const [0, 0x6, 0x6, 0x5, oldLayer, 0x5, null]
    //     0xcb06a0: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cef8] List(7) [0, 0x6, 0x6, 0x5, "oldLayer", 0x5, Null]
    //     0xcb06a4: ldr             x4, [x4, #0xef8]
    // 0xcb06a8: r0 = pushTransform()
    //     0xcb06a8: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0xcb06ac: add             SP, SP, #0x30
    // 0xcb06b0: ldur            x16, [fp, #-0x20]
    // 0xcb06b4: stp             x0, x16, [SP, #-0x10]!
    // 0xcb06b8: r0 = layer=()
    //     0xcb06b8: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xcb06bc: add             SP, SP, #0x10
    // 0xcb06c0: r0 = Null
    //     0xcb06c0: mov             x0, NULL
    // 0xcb06c4: LeaveFrame
    //     0xcb06c4: mov             SP, fp
    //     0xcb06c8: ldp             fp, lr, [SP], #0x10
    // 0xcb06cc: ret
    //     0xcb06cc: ret             
    // 0xcb06d0: ldur            x0, [fp, #-8]
    // 0xcb06d4: LoadField: r1 = r0->field_13
    //     0xcb06d4: ldur            w1, [x0, #0x13]
    // 0xcb06d8: DecompressPointer r1
    //     0xcb06d8: add             x1, x1, HEAP, lsl #32
    // 0xcb06dc: cmp             w1, NULL
    // 0xcb06e0: b.eq            #0xcb071c
    // 0xcb06e4: ldr             x16, [fp, #0x28]
    // 0xcb06e8: stp             x16, x1, [SP, #-0x10]!
    // 0xcb06ec: ldr             x16, [fp, #0x20]
    // 0xcb06f0: SaveReg r16
    //     0xcb06f0: str             x16, [SP, #-8]!
    // 0xcb06f4: mov             x0, x1
    // 0xcb06f8: ClosureCall
    //     0xcb06f8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcb06fc: ldur            x2, [x0, #0x1f]
    //     0xcb0700: blr             x2
    // 0xcb0704: add             SP, SP, #0x18
    // 0xcb0708: LeaveFrame
    //     0xcb0708: mov             SP, fp
    //     0xcb070c: ldp             fp, lr, [SP], #0x10
    // 0xcb0710: ret
    //     0xcb0710: ret             
    // 0xcb0714: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb0714: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb0718: b               #0xcb0598
    // 0xcb071c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcb071c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0xcb0720, size: 0x154
    // 0xcb0720: EnterFrame
    //     0xcb0720: stp             fp, lr, [SP, #-0x10]!
    //     0xcb0724: mov             fp, SP
    // 0xcb0728: AllocStack(0x10)
    //     0xcb0728: sub             SP, SP, #0x10
    // 0xcb072c: SetupParameters()
    //     0xcb072c: ldr             x0, [fp, #0x20]
    //     0xcb0730: ldur            w1, [x0, #0x17]
    //     0xcb0734: add             x1, x1, HEAP, lsl #32
    //     0xcb0738: stur            x1, [fp, #-0x10]
    // 0xcb073c: CheckStackOverflow
    //     0xcb073c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb0740: cmp             SP, x16
    //     0xcb0744: b.ls            #0xcb0850
    // 0xcb0748: LoadField: r0 = r1->field_f
    //     0xcb0748: ldur            w0, [x1, #0xf]
    // 0xcb074c: DecompressPointer r0
    //     0xcb074c: add             x0, x0, HEAP, lsl #32
    // 0xcb0750: LoadField: r2 = r0->field_37
    //     0xcb0750: ldur            w2, [x0, #0x37]
    // 0xcb0754: DecompressPointer r2
    //     0xcb0754: add             x2, x2, HEAP, lsl #32
    // 0xcb0758: stur            x2, [fp, #-8]
    // 0xcb075c: LoadField: r3 = r0->field_2b
    //     0xcb075c: ldur            w3, [x0, #0x2b]
    // 0xcb0760: DecompressPointer r3
    //     0xcb0760: add             x3, x3, HEAP, lsl #32
    // 0xcb0764: r0 = LoadClassIdInstr(r3)
    //     0xcb0764: ldur            x0, [x3, #-1]
    //     0xcb0768: ubfx            x0, x0, #0xc, #0x14
    // 0xcb076c: SaveReg r3
    //     0xcb076c: str             x3, [SP, #-8]!
    // 0xcb0770: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcb0770: add             lr, x0, #0xb7c
    //     0xcb0774: ldr             lr, [x21, lr, lsl #3]
    //     0xcb0778: blr             lr
    // 0xcb077c: add             SP, SP, #8
    // 0xcb0780: LoadField: d0 = r0->field_7
    //     0xcb0780: ldur            d0, [x0, #7]
    // 0xcb0784: d1 = 255.000000
    //     0xcb0784: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xcb0788: ldr             d1, [x17, #0x200]
    // 0xcb078c: fmul            d2, d0, d1
    // 0xcb0790: mov             v0.16b, v2.16b
    // 0xcb0794: stp             fp, lr, [SP, #-0x10]!
    // 0xcb0798: mov             fp, SP
    // 0xcb079c: CallRuntime_LibcRound(double) -> double
    //     0xcb079c: and             SP, SP, #0xfffffffffffffff0
    //     0xcb07a0: mov             sp, SP
    //     0xcb07a4: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xcb07a8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcb07ac: blr             x16
    //     0xcb07b0: mov             x16, #8
    //     0xcb07b4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcb07b8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcb07bc: sub             sp, x16, #1, lsl #12
    //     0xcb07c0: mov             SP, fp
    //     0xcb07c4: ldp             fp, lr, [SP], #0x10
    // 0xcb07c8: fcmp            d0, d0
    // 0xcb07cc: b.vs            #0xcb0858
    // 0xcb07d0: fcvtzs          x0, d0
    // 0xcb07d4: asr             x16, x0, #0x1e
    // 0xcb07d8: cmp             x16, x0, asr #63
    // 0xcb07dc: b.ne            #0xcb0858
    // 0xcb07e0: lsl             x0, x0, #1
    // 0xcb07e4: ldur            x1, [fp, #-0x10]
    // 0xcb07e8: LoadField: r2 = r1->field_13
    //     0xcb07e8: ldur            w2, [x1, #0x13]
    // 0xcb07ec: DecompressPointer r2
    //     0xcb07ec: add             x2, x2, HEAP, lsl #32
    // 0xcb07f0: LoadField: r3 = r1->field_f
    //     0xcb07f0: ldur            w3, [x1, #0xf]
    // 0xcb07f4: DecompressPointer r3
    //     0xcb07f4: add             x3, x3, HEAP, lsl #32
    // 0xcb07f8: LoadField: r1 = r3->field_37
    //     0xcb07f8: ldur            w1, [x3, #0x37]
    // 0xcb07fc: DecompressPointer r1
    //     0xcb07fc: add             x1, x1, HEAP, lsl #32
    // 0xcb0800: LoadField: r3 = r1->field_b
    //     0xcb0800: ldur            w3, [x1, #0xb]
    // 0xcb0804: DecompressPointer r3
    //     0xcb0804: add             x3, x3, HEAP, lsl #32
    // 0xcb0808: r1 = LoadInt32Instr(r0)
    //     0xcb0808: sbfx            x1, x0, #1, #0x1f
    //     0xcb080c: tbz             w0, #0, #0xcb0814
    //     0xcb0810: ldur            x1, [x0, #7]
    // 0xcb0814: ldr             x16, [fp, #0x18]
    // 0xcb0818: ldr             lr, [fp, #0x10]
    // 0xcb081c: stp             lr, x16, [SP, #-0x10]!
    // 0xcb0820: stp             x2, x1, [SP, #-0x10]!
    // 0xcb0824: SaveReg r3
    //     0xcb0824: str             x3, [SP, #-8]!
    // 0xcb0828: r0 = pushOpacity()
    //     0xcb0828: bl              #0x66116c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushOpacity
    // 0xcb082c: add             SP, SP, #0x28
    // 0xcb0830: ldur            x16, [fp, #-8]
    // 0xcb0834: stp             x0, x16, [SP, #-0x10]!
    // 0xcb0838: r0 = layer=()
    //     0xcb0838: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xcb083c: add             SP, SP, #0x10
    // 0xcb0840: r0 = Null
    //     0xcb0840: mov             x0, NULL
    // 0xcb0844: LeaveFrame
    //     0xcb0844: mov             SP, fp
    //     0xcb0848: ldp             fp, lr, [SP], #0x10
    // 0xcb084c: ret
    //     0xcb084c: ret             
    // 0xcb0850: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb0850: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb0854: b               #0xcb0748
    // 0xcb0858: SaveReg d0
    //     0xcb0858: str             q0, [SP, #-0x10]!
    // 0xcb085c: r0 = 218
    //     0xcb085c: mov             x0, #0xda
    // 0xcb0860: r24 = DoubleToIntegerStub
    //     0xcb0860: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xcb0864: LoadField: r30 = r24->field_7
    //     0xcb0864: ldur            lr, [x24, #7]
    // 0xcb0868: blr             lr
    // 0xcb086c: RestoreReg d0
    //     0xcb086c: ldr             q0, [SP], #0x10
    // 0xcb0870: b               #0xcb07e4
  }
}

// class id: 4832, size: 0x40, field offset: 0x24
class _ZoomEnterTransitionPainter extends SnapshotPainter {

  _ _ZoomEnterTransitionPainter(/* No info */) {
    // ** addr: 0x7b70ec, size: 0x294
    // 0x7b70ec: EnterFrame
    //     0x7b70ec: stp             fp, lr, [SP, #-0x10]!
    //     0x7b70f0: mov             fp, SP
    // 0x7b70f4: AllocStack(0x8)
    //     0x7b70f4: sub             SP, SP, #8
    // 0x7b70f8: CheckStackOverflow
    //     0x7b70f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b70fc: cmp             SP, x16
    //     0x7b7100: b.ls            #0x7b7378
    // 0x7b7104: r0 = Matrix4()
    //     0x7b7104: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x7b7108: r4 = 32
    //     0x7b7108: mov             x4, #0x20
    // 0x7b710c: stur            x0, [fp, #-8]
    // 0x7b7110: r0 = AllocateFloat64Array()
    //     0x7b7110: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x7b7114: mov             x1, x0
    // 0x7b7118: ldur            x0, [fp, #-8]
    // 0x7b711c: StoreField: r0->field_7 = r1
    //     0x7b711c: stur            w1, [x0, #7]
    // 0x7b7120: ldr             x2, [fp, #0x30]
    // 0x7b7124: StoreField: r2->field_33 = r0
    //     0x7b7124: stur            w0, [x2, #0x33]
    //     0x7b7128: ldurb           w16, [x2, #-1]
    //     0x7b712c: ldurb           w17, [x0, #-1]
    //     0x7b7130: and             x16, x17, x16, lsr #2
    //     0x7b7134: tst             x16, HEAP, lsr #32
    //     0x7b7138: b.eq            #0x7b7140
    //     0x7b713c: bl              #0xd6828c
    // 0x7b7140: r1 = <OpacityLayer>
    //     0x7b7140: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b6f8] TypeArguments: <OpacityLayer>
    //     0x7b7144: ldr             x1, [x1, #0x6f8]
    // 0x7b7148: r0 = LayerHandle()
    //     0x7b7148: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x7b714c: ldr             x2, [fp, #0x30]
    // 0x7b7150: StoreField: r2->field_37 = r0
    //     0x7b7150: stur            w0, [x2, #0x37]
    //     0x7b7154: ldurb           w16, [x2, #-1]
    //     0x7b7158: ldurb           w17, [x0, #-1]
    //     0x7b715c: and             x16, x17, x16, lsr #2
    //     0x7b7160: tst             x16, HEAP, lsr #32
    //     0x7b7164: b.eq            #0x7b716c
    //     0x7b7168: bl              #0xd6828c
    // 0x7b716c: r1 = <TransformLayer>
    //     0x7b716c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40c20] TypeArguments: <TransformLayer>
    //     0x7b7170: ldr             x1, [x1, #0xc20]
    // 0x7b7174: r0 = LayerHandle()
    //     0x7b7174: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x7b7178: ldr             x1, [fp, #0x30]
    // 0x7b717c: StoreField: r1->field_3b = r0
    //     0x7b717c: stur            w0, [x1, #0x3b]
    //     0x7b7180: ldurb           w16, [x1, #-1]
    //     0x7b7184: ldurb           w17, [x0, #-1]
    //     0x7b7188: and             x16, x17, x16, lsr #2
    //     0x7b718c: tst             x16, HEAP, lsr #32
    //     0x7b7190: b.eq            #0x7b7198
    //     0x7b7194: bl              #0xd6826c
    // 0x7b7198: ldr             x0, [fp, #0x18]
    // 0x7b719c: StoreField: r1->field_23 = r0
    //     0x7b719c: stur            w0, [x1, #0x23]
    // 0x7b71a0: ldr             x0, [fp, #0x10]
    // 0x7b71a4: StoreField: r1->field_2b = r0
    //     0x7b71a4: stur            w0, [x1, #0x2b]
    //     0x7b71a8: ldurb           w16, [x1, #-1]
    //     0x7b71ac: ldurb           w17, [x0, #-1]
    //     0x7b71b0: and             x16, x17, x16, lsr #2
    //     0x7b71b4: tst             x16, HEAP, lsr #32
    //     0x7b71b8: b.eq            #0x7b71c0
    //     0x7b71bc: bl              #0xd6826c
    // 0x7b71c0: ldr             x0, [fp, #0x20]
    // 0x7b71c4: StoreField: r1->field_2f = r0
    //     0x7b71c4: stur            w0, [x1, #0x2f]
    //     0x7b71c8: ldurb           w16, [x1, #-1]
    //     0x7b71cc: ldurb           w17, [x0, #-1]
    //     0x7b71d0: and             x16, x17, x16, lsr #2
    //     0x7b71d4: tst             x16, HEAP, lsr #32
    //     0x7b71d8: b.eq            #0x7b71e0
    //     0x7b71dc: bl              #0xd6826c
    // 0x7b71e0: ldr             x0, [fp, #0x28]
    // 0x7b71e4: StoreField: r1->field_27 = r0
    //     0x7b71e4: stur            w0, [x1, #0x27]
    //     0x7b71e8: ldurb           w16, [x1, #-1]
    //     0x7b71ec: ldurb           w17, [x0, #-1]
    //     0x7b71f0: and             x16, x17, x16, lsr #2
    //     0x7b71f4: tst             x16, HEAP, lsr #32
    //     0x7b71f8: b.eq            #0x7b7200
    //     0x7b71fc: bl              #0xd6826c
    // 0x7b7200: r0 = 0
    //     0x7b7200: mov             x0, #0
    // 0x7b7204: StoreField: r1->field_7 = r0
    //     0x7b7204: stur            x0, [x1, #7]
    // 0x7b7208: StoreField: r1->field_13 = r0
    //     0x7b7208: stur            x0, [x1, #0x13]
    // 0x7b720c: StoreField: r1->field_1b = r0
    //     0x7b720c: stur            x0, [x1, #0x1b]
    // 0x7b7210: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x7b7210: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7b7214: ldr             x0, [x0, #0x1580]
    //     0x7b7218: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7b721c: cmp             w0, w16
    //     0x7b7220: b.ne            #0x7b722c
    //     0x7b7224: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x7b7228: bl              #0xd67cdc
    // 0x7b722c: ldr             x1, [fp, #0x30]
    // 0x7b7230: StoreField: r1->field_f = r0
    //     0x7b7230: stur            w0, [x1, #0xf]
    //     0x7b7234: ldurb           w16, [x1, #-1]
    //     0x7b7238: ldurb           w17, [x0, #-1]
    //     0x7b723c: and             x16, x17, x16, lsr #2
    //     0x7b7240: tst             x16, HEAP, lsr #32
    //     0x7b7244: b.eq            #0x7b724c
    //     0x7b7248: bl              #0xd6826c
    // 0x7b724c: r1 = 1
    //     0x7b724c: mov             x1, #1
    // 0x7b7250: r0 = AllocateContext()
    //     0x7b7250: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b7254: mov             x1, x0
    // 0x7b7258: ldr             x0, [fp, #0x30]
    // 0x7b725c: StoreField: r1->field_f = r0
    //     0x7b725c: stur            w0, [x1, #0xf]
    // 0x7b7260: mov             x2, x1
    // 0x7b7264: r1 = Function 'notifyListeners':.
    //     0x7b7264: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x7b7268: ldr             x1, [x1, #0x298]
    // 0x7b726c: r0 = AllocateClosure()
    //     0x7b726c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b7270: ldr             x1, [fp, #0x28]
    // 0x7b7274: r2 = LoadClassIdInstr(r1)
    //     0x7b7274: ldur            x2, [x1, #-1]
    //     0x7b7278: ubfx            x2, x2, #0xc, #0x14
    // 0x7b727c: stp             x0, x1, [SP, #-0x10]!
    // 0x7b7280: mov             x0, x2
    // 0x7b7284: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b7284: mov             x17, #0xc3ab
    //     0x7b7288: add             lr, x0, x17
    //     0x7b728c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b7290: blr             lr
    // 0x7b7294: add             SP, SP, #0x10
    // 0x7b7298: r1 = 1
    //     0x7b7298: mov             x1, #1
    // 0x7b729c: r0 = AllocateContext()
    //     0x7b729c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b72a0: mov             x1, x0
    // 0x7b72a4: ldr             x0, [fp, #0x30]
    // 0x7b72a8: StoreField: r1->field_f = r0
    //     0x7b72a8: stur            w0, [x1, #0xf]
    // 0x7b72ac: mov             x2, x1
    // 0x7b72b0: r1 = Function '_onStatusChange@789490068':.
    //     0x7b72b0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b790] AnonymousClosure: (0x7b7380), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter
    //     0x7b72b4: ldr             x1, [x1, #0x790]
    // 0x7b72b8: r0 = AllocateClosure()
    //     0x7b72b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b72bc: mov             x1, x0
    // 0x7b72c0: ldr             x0, [fp, #0x28]
    // 0x7b72c4: r2 = LoadClassIdInstr(r0)
    //     0x7b72c4: ldur            x2, [x0, #-1]
    //     0x7b72c8: ubfx            x2, x2, #0xc, #0x14
    // 0x7b72cc: stp             x1, x0, [SP, #-0x10]!
    // 0x7b72d0: mov             x0, x2
    // 0x7b72d4: r0 = GDT[cid_x0 + 0x80c]()
    //     0x7b72d4: add             lr, x0, #0x80c
    //     0x7b72d8: ldr             lr, [x21, lr, lsl #3]
    //     0x7b72dc: blr             lr
    // 0x7b72e0: add             SP, SP, #0x10
    // 0x7b72e4: r1 = 1
    //     0x7b72e4: mov             x1, #1
    // 0x7b72e8: r0 = AllocateContext()
    //     0x7b72e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b72ec: mov             x1, x0
    // 0x7b72f0: ldr             x0, [fp, #0x30]
    // 0x7b72f4: StoreField: r1->field_f = r0
    //     0x7b72f4: stur            w0, [x1, #0xf]
    // 0x7b72f8: mov             x2, x1
    // 0x7b72fc: r1 = Function 'notifyListeners':.
    //     0x7b72fc: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x7b7300: ldr             x1, [x1, #0x298]
    // 0x7b7304: r0 = AllocateClosure()
    //     0x7b7304: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b7308: ldr             x16, [fp, #0x10]
    // 0x7b730c: stp             x0, x16, [SP, #-0x10]!
    // 0x7b7310: r0 = addListener()
    //     0x7b7310: bl              #0x6e954c  ; [package:flutter/src/animation/tween.dart] __AnimatedEvaluation&Animation&AnimationWithParentMixin::addListener
    // 0x7b7314: add             SP, SP, #0x10
    // 0x7b7318: r1 = 1
    //     0x7b7318: mov             x1, #1
    // 0x7b731c: r0 = AllocateContext()
    //     0x7b731c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b7320: mov             x1, x0
    // 0x7b7324: ldr             x0, [fp, #0x30]
    // 0x7b7328: StoreField: r1->field_f = r0
    //     0x7b7328: stur            w0, [x1, #0xf]
    // 0x7b732c: mov             x2, x1
    // 0x7b7330: r1 = Function 'notifyListeners':.
    //     0x7b7330: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x7b7334: ldr             x1, [x1, #0x298]
    // 0x7b7338: r0 = AllocateClosure()
    //     0x7b7338: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b733c: mov             x1, x0
    // 0x7b7340: ldr             x0, [fp, #0x20]
    // 0x7b7344: r2 = LoadClassIdInstr(r0)
    //     0x7b7344: ldur            x2, [x0, #-1]
    //     0x7b7348: ubfx            x2, x2, #0xc, #0x14
    // 0x7b734c: stp             x1, x0, [SP, #-0x10]!
    // 0x7b7350: mov             x0, x2
    // 0x7b7354: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7b7354: mov             x17, #0xc3ab
    //     0x7b7358: add             lr, x0, x17
    //     0x7b735c: ldr             lr, [x21, lr, lsl #3]
    //     0x7b7360: blr             lr
    // 0x7b7364: add             SP, SP, #0x10
    // 0x7b7368: r0 = Null
    //     0x7b7368: mov             x0, NULL
    // 0x7b736c: LeaveFrame
    //     0x7b736c: mov             SP, fp
    //     0x7b7370: ldp             fp, lr, [SP], #0x10
    // 0x7b7374: ret
    //     0x7b7374: ret             
    // 0x7b7378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b7378: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b737c: b               #0x7b7104
  }
  dynamic dispose(dynamic) {
    // ** addr: 0x9ba1a8, size: 0x18
    // 0x9ba1a8: r4 = 0
    //     0x9ba1a8: mov             x4, #0
    // 0x9ba1ac: r1 = Function 'dispose':.
    //     0x9ba1ac: add             x17, PP, #0x50, lsl #12  ; [pp+0x50908] AnonymousClosure: (0x9ba1c0), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::dispose (0x9c24d8)
    //     0x9ba1b0: ldr             x1, [x17, #0x908]
    // 0x9ba1b4: r24 = BuildNonGenericMethodExtractorStub
    //     0x9ba1b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x9ba1b8: LoadField: r0 = r24->field_17
    //     0x9ba1b8: ldur            x0, [x24, #0x17]
    // 0x9ba1bc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0x9ba1c0, size: 0x48
    // 0x9ba1c0: EnterFrame
    //     0x9ba1c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba1c4: mov             fp, SP
    // 0x9ba1c8: ldr             x0, [fp, #0x10]
    // 0x9ba1cc: LoadField: r1 = r0->field_17
    //     0x9ba1cc: ldur            w1, [x0, #0x17]
    // 0x9ba1d0: DecompressPointer r1
    //     0x9ba1d0: add             x1, x1, HEAP, lsl #32
    // 0x9ba1d4: CheckStackOverflow
    //     0x9ba1d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ba1d8: cmp             SP, x16
    //     0x9ba1dc: b.ls            #0x9ba200
    // 0x9ba1e0: LoadField: r0 = r1->field_f
    //     0x9ba1e0: ldur            w0, [x1, #0xf]
    // 0x9ba1e4: DecompressPointer r0
    //     0x9ba1e4: add             x0, x0, HEAP, lsl #32
    // 0x9ba1e8: SaveReg r0
    //     0x9ba1e8: str             x0, [SP, #-8]!
    // 0x9ba1ec: r0 = dispose()
    //     0x9ba1ec: bl              #0x9c24d8  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::dispose
    // 0x9ba1f0: add             SP, SP, #8
    // 0x9ba1f4: LeaveFrame
    //     0x9ba1f4: mov             SP, fp
    //     0x9ba1f8: ldp             fp, lr, [SP], #0x10
    // 0x9ba1fc: ret
    //     0x9ba1fc: ret             
    // 0x9ba200: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba200: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba204: b               #0x9ba1e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0x9c24d8, size: 0x1bc
    // 0x9c24d8: EnterFrame
    //     0x9c24d8: stp             fp, lr, [SP, #-0x10]!
    //     0x9c24dc: mov             fp, SP
    // 0x9c24e0: AllocStack(0x8)
    //     0x9c24e0: sub             SP, SP, #8
    // 0x9c24e4: CheckStackOverflow
    //     0x9c24e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9c24e8: cmp             SP, x16
    //     0x9c24ec: b.ls            #0x9c268c
    // 0x9c24f0: ldr             x0, [fp, #0x10]
    // 0x9c24f4: LoadField: r1 = r0->field_27
    //     0x9c24f4: ldur            w1, [x0, #0x27]
    // 0x9c24f8: DecompressPointer r1
    //     0x9c24f8: add             x1, x1, HEAP, lsl #32
    // 0x9c24fc: stur            x1, [fp, #-8]
    // 0x9c2500: r1 = 1
    //     0x9c2500: mov             x1, #1
    // 0x9c2504: r0 = AllocateContext()
    //     0x9c2504: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c2508: mov             x1, x0
    // 0x9c250c: ldr             x0, [fp, #0x10]
    // 0x9c2510: StoreField: r1->field_f = r0
    //     0x9c2510: stur            w0, [x1, #0xf]
    // 0x9c2514: mov             x2, x1
    // 0x9c2518: r1 = Function 'notifyListeners':.
    //     0x9c2518: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c251c: ldr             x1, [x1, #0x298]
    // 0x9c2520: r0 = AllocateClosure()
    //     0x9c2520: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2524: ldur            x1, [fp, #-8]
    // 0x9c2528: r2 = LoadClassIdInstr(r1)
    //     0x9c2528: ldur            x2, [x1, #-1]
    //     0x9c252c: ubfx            x2, x2, #0xc, #0x14
    // 0x9c2530: stp             x0, x1, [SP, #-0x10]!
    // 0x9c2534: mov             x0, x2
    // 0x9c2538: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x9c2538: mov             x17, #0xc2d6
    //     0x9c253c: add             lr, x0, x17
    //     0x9c2540: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2544: blr             lr
    // 0x9c2548: add             SP, SP, #0x10
    // 0x9c254c: r1 = 1
    //     0x9c254c: mov             x1, #1
    // 0x9c2550: r0 = AllocateContext()
    //     0x9c2550: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c2554: mov             x1, x0
    // 0x9c2558: ldr             x0, [fp, #0x10]
    // 0x9c255c: StoreField: r1->field_f = r0
    //     0x9c255c: stur            w0, [x1, #0xf]
    // 0x9c2560: mov             x2, x1
    // 0x9c2564: r1 = Function '_onStatusChange@789490068':.
    //     0x9c2564: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b790] AnonymousClosure: (0x7b7380), of [package:flutter/src/material/page_transitions_theme.dart] _ZoomExitTransitionPainter
    //     0x9c2568: ldr             x1, [x1, #0x790]
    // 0x9c256c: r0 = AllocateClosure()
    //     0x9c256c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2570: mov             x1, x0
    // 0x9c2574: ldur            x0, [fp, #-8]
    // 0x9c2578: r2 = LoadClassIdInstr(r0)
    //     0x9c2578: ldur            x2, [x0, #-1]
    //     0x9c257c: ubfx            x2, x2, #0xc, #0x14
    // 0x9c2580: stp             x1, x0, [SP, #-0x10]!
    // 0x9c2584: mov             x0, x2
    // 0x9c2588: r0 = GDT[cid_x0 + 0x490]()
    //     0x9c2588: add             lr, x0, #0x490
    //     0x9c258c: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2590: blr             lr
    // 0x9c2594: add             SP, SP, #0x10
    // 0x9c2598: ldr             x0, [fp, #0x10]
    // 0x9c259c: LoadField: r1 = r0->field_2b
    //     0x9c259c: ldur            w1, [x0, #0x2b]
    // 0x9c25a0: DecompressPointer r1
    //     0x9c25a0: add             x1, x1, HEAP, lsl #32
    // 0x9c25a4: stur            x1, [fp, #-8]
    // 0x9c25a8: r1 = 1
    //     0x9c25a8: mov             x1, #1
    // 0x9c25ac: r0 = AllocateContext()
    //     0x9c25ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c25b0: mov             x1, x0
    // 0x9c25b4: ldr             x0, [fp, #0x10]
    // 0x9c25b8: StoreField: r1->field_f = r0
    //     0x9c25b8: stur            w0, [x1, #0xf]
    // 0x9c25bc: mov             x2, x1
    // 0x9c25c0: r1 = Function 'notifyListeners':.
    //     0x9c25c0: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c25c4: ldr             x1, [x1, #0x298]
    // 0x9c25c8: r0 = AllocateClosure()
    //     0x9c25c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c25cc: ldur            x16, [fp, #-8]
    // 0x9c25d0: stp             x0, x16, [SP, #-0x10]!
    // 0x9c25d4: r0 = removeListener()
    //     0x9c25d4: bl              #0x6f61cc  ; [package:flutter/src/animation/tween.dart] __AnimatedEvaluation&Animation&AnimationWithParentMixin::removeListener
    // 0x9c25d8: add             SP, SP, #0x10
    // 0x9c25dc: ldr             x0, [fp, #0x10]
    // 0x9c25e0: LoadField: r1 = r0->field_2f
    //     0x9c25e0: ldur            w1, [x0, #0x2f]
    // 0x9c25e4: DecompressPointer r1
    //     0x9c25e4: add             x1, x1, HEAP, lsl #32
    // 0x9c25e8: stur            x1, [fp, #-8]
    // 0x9c25ec: r1 = 1
    //     0x9c25ec: mov             x1, #1
    // 0x9c25f0: r0 = AllocateContext()
    //     0x9c25f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9c25f4: mov             x1, x0
    // 0x9c25f8: ldr             x0, [fp, #0x10]
    // 0x9c25fc: StoreField: r1->field_f = r0
    //     0x9c25fc: stur            w0, [x1, #0xf]
    // 0x9c2600: mov             x2, x1
    // 0x9c2604: r1 = Function 'notifyListeners':.
    //     0x9c2604: add             x1, PP, #0x29, lsl #12  ; [pp+0x29298] AnonymousClosure: (0x5014f0), in [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners (0x500f60)
    //     0x9c2608: ldr             x1, [x1, #0x298]
    // 0x9c260c: r0 = AllocateClosure()
    //     0x9c260c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9c2610: mov             x1, x0
    // 0x9c2614: ldur            x0, [fp, #-8]
    // 0x9c2618: r2 = LoadClassIdInstr(r0)
    //     0x9c2618: ldur            x2, [x0, #-1]
    //     0x9c261c: ubfx            x2, x2, #0xc, #0x14
    // 0x9c2620: stp             x1, x0, [SP, #-0x10]!
    // 0x9c2624: mov             x0, x2
    // 0x9c2628: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x9c2628: mov             x17, #0xc2d6
    //     0x9c262c: add             lr, x0, x17
    //     0x9c2630: ldr             lr, [x21, lr, lsl #3]
    //     0x9c2634: blr             lr
    // 0x9c2638: add             SP, SP, #0x10
    // 0x9c263c: ldr             x0, [fp, #0x10]
    // 0x9c2640: LoadField: r1 = r0->field_37
    //     0x9c2640: ldur            w1, [x0, #0x37]
    // 0x9c2644: DecompressPointer r1
    //     0x9c2644: add             x1, x1, HEAP, lsl #32
    // 0x9c2648: stp             NULL, x1, [SP, #-0x10]!
    // 0x9c264c: r0 = layer=()
    //     0x9c264c: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x9c2650: add             SP, SP, #0x10
    // 0x9c2654: ldr             x0, [fp, #0x10]
    // 0x9c2658: LoadField: r1 = r0->field_3b
    //     0x9c2658: ldur            w1, [x0, #0x3b]
    // 0x9c265c: DecompressPointer r1
    //     0x9c265c: add             x1, x1, HEAP, lsl #32
    // 0x9c2660: stp             NULL, x1, [SP, #-0x10]!
    // 0x9c2664: r0 = layer=()
    //     0x9c2664: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x9c2668: add             SP, SP, #0x10
    // 0x9c266c: ldr             x16, [fp, #0x10]
    // 0x9c2670: SaveReg r16
    //     0x9c2670: str             x16, [SP, #-8]!
    // 0x9c2674: r0 = dispose()
    //     0x9c2674: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x9c2678: add             SP, SP, #8
    // 0x9c267c: r0 = Null
    //     0x9c267c: mov             x0, NULL
    // 0x9c2680: LeaveFrame
    //     0x9c2680: mov             SP, fp
    //     0x9c2684: ldp             fp, lr, [SP], #0x10
    // 0x9c2688: ret
    //     0x9c2688: ret             
    // 0x9c268c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9c268c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9c2690: b               #0x9c24f0
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xcaf0e0, size: 0x1f4
    // 0xcaf0e0: EnterFrame
    //     0xcaf0e0: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf0e4: mov             fp, SP
    // 0xcaf0e8: AllocStack(0x8)
    //     0xcaf0e8: sub             SP, SP, #8
    // 0xcaf0ec: CheckStackOverflow
    //     0xcaf0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcaf0f0: cmp             SP, x16
    //     0xcaf0f4: b.ls            #0xcaf2cc
    // 0xcaf0f8: ldr             x0, [fp, #0x10]
    // 0xcaf0fc: r2 = Null
    //     0xcaf0fc: mov             x2, NULL
    // 0xcaf100: r1 = Null
    //     0xcaf100: mov             x1, NULL
    // 0xcaf104: r4 = 59
    //     0xcaf104: mov             x4, #0x3b
    // 0xcaf108: branchIfSmi(r0, 0xcaf114)
    //     0xcaf108: tbz             w0, #0, #0xcaf114
    // 0xcaf10c: r4 = LoadClassIdInstr(r0)
    //     0xcaf10c: ldur            x4, [x0, #-1]
    //     0xcaf110: ubfx            x4, x4, #0xc, #0x14
    // 0xcaf114: r17 = 4832
    //     0xcaf114: mov             x17, #0x12e0
    // 0xcaf118: cmp             x4, x17
    // 0xcaf11c: b.eq            #0xcaf134
    // 0xcaf120: r8 = _ZoomEnterTransitionPainter
    //     0xcaf120: add             x8, PP, #0x53, lsl #12  ; [pp+0x53070] Type: _ZoomEnterTransitionPainter
    //     0xcaf124: ldr             x8, [x8, #0x70]
    // 0xcaf128: r3 = Null
    //     0xcaf128: add             x3, PP, #0x53, lsl #12  ; [pp+0x53078] Null
    //     0xcaf12c: ldr             x3, [x3, #0x78]
    // 0xcaf130: r0 = DefaultTypeTest()
    //     0xcaf130: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcaf134: ldr             x1, [fp, #0x10]
    // 0xcaf138: LoadField: r0 = r1->field_23
    //     0xcaf138: ldur            w0, [x1, #0x23]
    // 0xcaf13c: DecompressPointer r0
    //     0xcaf13c: add             x0, x0, HEAP, lsl #32
    // 0xcaf140: ldr             x2, [fp, #0x18]
    // 0xcaf144: LoadField: r3 = r2->field_23
    //     0xcaf144: ldur            w3, [x2, #0x23]
    // 0xcaf148: DecompressPointer r3
    //     0xcaf148: add             x3, x3, HEAP, lsl #32
    // 0xcaf14c: cmp             w0, w3
    // 0xcaf150: b.ne            #0xcaf23c
    // 0xcaf154: LoadField: r0 = r1->field_27
    //     0xcaf154: ldur            w0, [x1, #0x27]
    // 0xcaf158: DecompressPointer r0
    //     0xcaf158: add             x0, x0, HEAP, lsl #32
    // 0xcaf15c: r3 = LoadClassIdInstr(r0)
    //     0xcaf15c: ldur            x3, [x0, #-1]
    //     0xcaf160: ubfx            x3, x3, #0xc, #0x14
    // 0xcaf164: SaveReg r0
    //     0xcaf164: str             x0, [SP, #-8]!
    // 0xcaf168: mov             x0, x3
    // 0xcaf16c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf16c: add             lr, x0, #0xb7c
    //     0xcaf170: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf174: blr             lr
    // 0xcaf178: add             SP, SP, #8
    // 0xcaf17c: mov             x2, x0
    // 0xcaf180: ldr             x1, [fp, #0x18]
    // 0xcaf184: stur            x2, [fp, #-8]
    // 0xcaf188: LoadField: r0 = r1->field_27
    //     0xcaf188: ldur            w0, [x1, #0x27]
    // 0xcaf18c: DecompressPointer r0
    //     0xcaf18c: add             x0, x0, HEAP, lsl #32
    // 0xcaf190: r3 = LoadClassIdInstr(r0)
    //     0xcaf190: ldur            x3, [x0, #-1]
    //     0xcaf194: ubfx            x3, x3, #0xc, #0x14
    // 0xcaf198: SaveReg r0
    //     0xcaf198: str             x0, [SP, #-8]!
    // 0xcaf19c: mov             x0, x3
    // 0xcaf1a0: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf1a0: add             lr, x0, #0xb7c
    //     0xcaf1a4: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf1a8: blr             lr
    // 0xcaf1ac: add             SP, SP, #8
    // 0xcaf1b0: mov             x1, x0
    // 0xcaf1b4: ldur            x0, [fp, #-8]
    // 0xcaf1b8: LoadField: d0 = r0->field_7
    //     0xcaf1b8: ldur            d0, [x0, #7]
    // 0xcaf1bc: LoadField: d1 = r1->field_7
    //     0xcaf1bc: ldur            d1, [x1, #7]
    // 0xcaf1c0: fcmp            d0, d1
    // 0xcaf1c4: b.ne            #0xcaf23c
    // 0xcaf1c8: ldr             x0, [fp, #0x18]
    // 0xcaf1cc: ldr             x1, [fp, #0x10]
    // 0xcaf1d0: LoadField: r2 = r1->field_2b
    //     0xcaf1d0: ldur            w2, [x1, #0x2b]
    // 0xcaf1d4: DecompressPointer r2
    //     0xcaf1d4: add             x2, x2, HEAP, lsl #32
    // 0xcaf1d8: LoadField: r3 = r2->field_f
    //     0xcaf1d8: ldur            w3, [x2, #0xf]
    // 0xcaf1dc: DecompressPointer r3
    //     0xcaf1dc: add             x3, x3, HEAP, lsl #32
    // 0xcaf1e0: LoadField: r4 = r2->field_b
    //     0xcaf1e0: ldur            w4, [x2, #0xb]
    // 0xcaf1e4: DecompressPointer r4
    //     0xcaf1e4: add             x4, x4, HEAP, lsl #32
    // 0xcaf1e8: stp             x4, x3, [SP, #-0x10]!
    // 0xcaf1ec: r0 = evaluate()
    //     0xcaf1ec: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcaf1f0: add             SP, SP, #0x10
    // 0xcaf1f4: mov             x1, x0
    // 0xcaf1f8: ldr             x0, [fp, #0x18]
    // 0xcaf1fc: stur            x1, [fp, #-8]
    // 0xcaf200: LoadField: r2 = r0->field_2b
    //     0xcaf200: ldur            w2, [x0, #0x2b]
    // 0xcaf204: DecompressPointer r2
    //     0xcaf204: add             x2, x2, HEAP, lsl #32
    // 0xcaf208: LoadField: r3 = r2->field_f
    //     0xcaf208: ldur            w3, [x2, #0xf]
    // 0xcaf20c: DecompressPointer r3
    //     0xcaf20c: add             x3, x3, HEAP, lsl #32
    // 0xcaf210: LoadField: r4 = r2->field_b
    //     0xcaf210: ldur            w4, [x2, #0xb]
    // 0xcaf214: DecompressPointer r4
    //     0xcaf214: add             x4, x4, HEAP, lsl #32
    // 0xcaf218: stp             x4, x3, [SP, #-0x10]!
    // 0xcaf21c: r0 = evaluate()
    //     0xcaf21c: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcaf220: add             SP, SP, #0x10
    // 0xcaf224: mov             x1, x0
    // 0xcaf228: ldur            x0, [fp, #-8]
    // 0xcaf22c: LoadField: d0 = r0->field_7
    //     0xcaf22c: ldur            d0, [x0, #7]
    // 0xcaf230: LoadField: d1 = r1->field_7
    //     0xcaf230: ldur            d1, [x1, #7]
    // 0xcaf234: fcmp            d0, d1
    // 0xcaf238: b.eq            #0xcaf244
    // 0xcaf23c: r0 = true
    //     0xcaf23c: add             x0, NULL, #0x20  ; true
    // 0xcaf240: b               #0xcaf2c0
    // 0xcaf244: ldr             x1, [fp, #0x18]
    // 0xcaf248: ldr             x0, [fp, #0x10]
    // 0xcaf24c: LoadField: r2 = r0->field_2f
    //     0xcaf24c: ldur            w2, [x0, #0x2f]
    // 0xcaf250: DecompressPointer r2
    //     0xcaf250: add             x2, x2, HEAP, lsl #32
    // 0xcaf254: r0 = LoadClassIdInstr(r2)
    //     0xcaf254: ldur            x0, [x2, #-1]
    //     0xcaf258: ubfx            x0, x0, #0xc, #0x14
    // 0xcaf25c: SaveReg r2
    //     0xcaf25c: str             x2, [SP, #-8]!
    // 0xcaf260: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf260: add             lr, x0, #0xb7c
    //     0xcaf264: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf268: blr             lr
    // 0xcaf26c: add             SP, SP, #8
    // 0xcaf270: mov             x1, x0
    // 0xcaf274: ldr             x0, [fp, #0x18]
    // 0xcaf278: stur            x1, [fp, #-8]
    // 0xcaf27c: LoadField: r2 = r0->field_2f
    //     0xcaf27c: ldur            w2, [x0, #0x2f]
    // 0xcaf280: DecompressPointer r2
    //     0xcaf280: add             x2, x2, HEAP, lsl #32
    // 0xcaf284: r0 = LoadClassIdInstr(r2)
    //     0xcaf284: ldur            x0, [x2, #-1]
    //     0xcaf288: ubfx            x0, x0, #0xc, #0x14
    // 0xcaf28c: SaveReg r2
    //     0xcaf28c: str             x2, [SP, #-8]!
    // 0xcaf290: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf290: add             lr, x0, #0xb7c
    //     0xcaf294: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf298: blr             lr
    // 0xcaf29c: add             SP, SP, #8
    // 0xcaf2a0: ldur            x1, [fp, #-8]
    // 0xcaf2a4: LoadField: d0 = r1->field_7
    //     0xcaf2a4: ldur            d0, [x1, #7]
    // 0xcaf2a8: LoadField: d1 = r0->field_7
    //     0xcaf2a8: ldur            d1, [x0, #7]
    // 0xcaf2ac: fcmp            d0, d1
    // 0xcaf2b0: r16 = true
    //     0xcaf2b0: add             x16, NULL, #0x20  ; true
    // 0xcaf2b4: r17 = false
    //     0xcaf2b4: add             x17, NULL, #0x30  ; false
    // 0xcaf2b8: csel            x1, x16, x17, ne
    // 0xcaf2bc: mov             x0, x1
    // 0xcaf2c0: LeaveFrame
    //     0xcaf2c0: mov             SP, fp
    //     0xcaf2c4: ldp             fp, lr, [SP], #0x10
    // 0xcaf2c8: ret
    //     0xcaf2c8: ret             
    // 0xcaf2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcaf2cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcaf2d0: b               #0xcaf0f8
  }
  _ paintSnapshot(/* No info */) {
    // ** addr: 0xcaf4bc, size: 0xcc
    // 0xcaf4bc: EnterFrame
    //     0xcaf4bc: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf4c0: mov             fp, SP
    // 0xcaf4c4: AllocStack(0x8)
    //     0xcaf4c4: sub             SP, SP, #8
    // 0xcaf4c8: CheckStackOverflow
    //     0xcaf4c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcaf4cc: cmp             SP, x16
    //     0xcaf4d0: b.ls            #0xcaf580
    // 0xcaf4d4: ldr             x16, [fp, #0x38]
    // 0xcaf4d8: ldr             lr, [fp, #0x30]
    // 0xcaf4dc: stp             lr, x16, [SP, #-0x10]!
    // 0xcaf4e0: ldr             x16, [fp, #0x28]
    // 0xcaf4e4: ldr             lr, [fp, #0x20]
    // 0xcaf4e8: stp             lr, x16, [SP, #-0x10]!
    // 0xcaf4ec: r0 = _drawScrim()
    //     0xcaf4ec: bl              #0xcaf82c  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_drawScrim
    // 0xcaf4f0: add             SP, SP, #0x20
    // 0xcaf4f4: ldr             x0, [fp, #0x38]
    // 0xcaf4f8: LoadField: r1 = r0->field_2b
    //     0xcaf4f8: ldur            w1, [x0, #0x2b]
    // 0xcaf4fc: DecompressPointer r1
    //     0xcaf4fc: add             x1, x1, HEAP, lsl #32
    // 0xcaf500: LoadField: r2 = r1->field_f
    //     0xcaf500: ldur            w2, [x1, #0xf]
    // 0xcaf504: DecompressPointer r2
    //     0xcaf504: add             x2, x2, HEAP, lsl #32
    // 0xcaf508: LoadField: r3 = r1->field_b
    //     0xcaf508: ldur            w3, [x1, #0xb]
    // 0xcaf50c: DecompressPointer r3
    //     0xcaf50c: add             x3, x3, HEAP, lsl #32
    // 0xcaf510: stp             x3, x2, [SP, #-0x10]!
    // 0xcaf514: r0 = evaluate()
    //     0xcaf514: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcaf518: add             SP, SP, #0x10
    // 0xcaf51c: mov             x1, x0
    // 0xcaf520: ldr             x0, [fp, #0x38]
    // 0xcaf524: stur            x1, [fp, #-8]
    // 0xcaf528: LoadField: r2 = r0->field_2f
    //     0xcaf528: ldur            w2, [x0, #0x2f]
    // 0xcaf52c: DecompressPointer r2
    //     0xcaf52c: add             x2, x2, HEAP, lsl #32
    // 0xcaf530: r0 = LoadClassIdInstr(r2)
    //     0xcaf530: ldur            x0, [x2, #-1]
    //     0xcaf534: ubfx            x0, x0, #0xc, #0x14
    // 0xcaf538: SaveReg r2
    //     0xcaf538: str             x2, [SP, #-8]!
    // 0xcaf53c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcaf53c: add             lr, x0, #0xb7c
    //     0xcaf540: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf544: blr             lr
    // 0xcaf548: add             SP, SP, #8
    // 0xcaf54c: ldr             x16, [fp, #0x30]
    // 0xcaf550: ldr             lr, [fp, #0x18]
    // 0xcaf554: stp             lr, x16, [SP, #-0x10]!
    // 0xcaf558: ldur            x16, [fp, #-8]
    // 0xcaf55c: stp             x0, x16, [SP, #-0x10]!
    // 0xcaf560: ldr             d0, [fp, #0x10]
    // 0xcaf564: SaveReg d0
    //     0xcaf564: str             d0, [SP, #-8]!
    // 0xcaf568: r0 = _drawImageScaledAndCentered()
    //     0xcaf568: bl              #0xcaf588  ; [package:flutter/src/material/page_transitions_theme.dart] ::_drawImageScaledAndCentered
    // 0xcaf56c: add             SP, SP, #0x28
    // 0xcaf570: r0 = Null
    //     0xcaf570: mov             x0, NULL
    // 0xcaf574: LeaveFrame
    //     0xcaf574: mov             SP, fp
    //     0xcaf578: ldp             fp, lr, [SP], #0x10
    // 0xcaf57c: ret
    //     0xcaf57c: ret             
    // 0xcaf580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcaf580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcaf584: b               #0xcaf4d4
  }
  _ _drawScrim(/* No info */) {
    // ** addr: 0xcaf82c, size: 0x184
    // 0xcaf82c: EnterFrame
    //     0xcaf82c: stp             fp, lr, [SP, #-0x10]!
    //     0xcaf830: mov             fp, SP
    // 0xcaf834: AllocStack(0x28)
    //     0xcaf834: sub             SP, SP, #0x28
    // 0xcaf838: CheckStackOverflow
    //     0xcaf838: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcaf83c: cmp             SP, x16
    //     0xcaf840: b.ls            #0xcaf9a4
    // 0xcaf844: ldr             x0, [fp, #0x28]
    // 0xcaf848: LoadField: r1 = r0->field_23
    //     0xcaf848: ldur            w1, [x0, #0x23]
    // 0xcaf84c: DecompressPointer r1
    //     0xcaf84c: add             x1, x1, HEAP, lsl #32
    // 0xcaf850: tbz             w1, #4, #0xcaf8d0
    // 0xcaf854: LoadField: r1 = r0->field_27
    //     0xcaf854: ldur            w1, [x0, #0x27]
    // 0xcaf858: DecompressPointer r1
    //     0xcaf858: add             x1, x1, HEAP, lsl #32
    // 0xcaf85c: stur            x1, [fp, #-8]
    // 0xcaf860: r0 = LoadClassIdInstr(r1)
    //     0xcaf860: ldur            x0, [x1, #-1]
    //     0xcaf864: ubfx            x0, x0, #0xc, #0x14
    // 0xcaf868: SaveReg r1
    //     0xcaf868: str             x1, [SP, #-8]!
    // 0xcaf86c: r0 = GDT[cid_x0 + 0x376]()
    //     0xcaf86c: add             lr, x0, #0x376
    //     0xcaf870: ldr             lr, [x21, lr, lsl #3]
    //     0xcaf874: blr             lr
    // 0xcaf878: add             SP, SP, #8
    // 0xcaf87c: r16 = Instance_AnimationStatus
    //     0xcaf87c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0xcaf880: ldr             x16, [x16, #0xba0]
    // 0xcaf884: cmp             w0, w16
    // 0xcaf888: b.eq            #0xcaf8d0
    // 0xcaf88c: r0 = InitLateStaticField(0xde0) // [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionState::_scrimOpacityTween
    //     0xcaf88c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xcaf890: ldr             x0, [x0, #0x1bc0]
    //     0xcaf894: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xcaf898: cmp             w0, w16
    //     0xcaf89c: b.ne            #0xcaf8ac
    //     0xcaf8a0: add             x2, PP, #0x55, lsl #12  ; [pp+0x55870] Field <_ZoomEnterTransitionState@789490068._scrimOpacityTween@789490068>: static late final (offset: 0xde0)
    //     0xcaf8a4: ldr             x2, [x2, #0x870]
    //     0xcaf8a8: bl              #0xd67cdc
    // 0xcaf8ac: ldur            x16, [fp, #-8]
    // 0xcaf8b0: stp             x16, x0, [SP, #-0x10]!
    // 0xcaf8b4: r0 = evaluate()
    //     0xcaf8b4: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcaf8b8: add             SP, SP, #0x10
    // 0xcaf8bc: cmp             w0, NULL
    // 0xcaf8c0: b.eq            #0xcaf9ac
    // 0xcaf8c4: LoadField: d0 = r0->field_7
    //     0xcaf8c4: ldur            d0, [x0, #7]
    // 0xcaf8c8: mov             v1.16b, v0.16b
    // 0xcaf8cc: b               #0xcaf8d4
    // 0xcaf8d0: d1 = 0.000000
    //     0xcaf8d0: eor             v1.16b, v1.16b, v1.16b
    // 0xcaf8d4: d0 = 0.000000
    //     0xcaf8d4: eor             v0.16b, v0.16b, v0.16b
    // 0xcaf8d8: stur            d1, [fp, #-0x28]
    // 0xcaf8dc: fcmp            d1, d0
    // 0xcaf8e0: b.vs            #0xcaf994
    // 0xcaf8e4: b.le            #0xcaf994
    // 0xcaf8e8: ldr             x16, [fp, #0x20]
    // 0xcaf8ec: SaveReg r16
    //     0xcaf8ec: str             x16, [SP, #-8]!
    // 0xcaf8f0: r0 = canvas()
    //     0xcaf8f0: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0xcaf8f4: add             SP, SP, #8
    // 0xcaf8f8: stur            x0, [fp, #-8]
    // 0xcaf8fc: ldr             x16, [fp, #0x18]
    // 0xcaf900: ldr             lr, [fp, #0x10]
    // 0xcaf904: stp             lr, x16, [SP, #-0x10]!
    // 0xcaf908: r0 = &()
    //     0xcaf908: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0xcaf90c: add             SP, SP, #0x10
    // 0xcaf910: stur            x0, [fp, #-0x10]
    // 0xcaf914: r16 = 112
    //     0xcaf914: mov             x16, #0x70
    // 0xcaf918: stp             x16, NULL, [SP, #-0x10]!
    // 0xcaf91c: r0 = ByteData()
    //     0xcaf91c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xcaf920: add             SP, SP, #0x10
    // 0xcaf924: stur            x0, [fp, #-0x18]
    // 0xcaf928: r0 = Paint()
    //     0xcaf928: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xcaf92c: mov             x1, x0
    // 0xcaf930: ldur            x0, [fp, #-0x18]
    // 0xcaf934: stur            x1, [fp, #-0x20]
    // 0xcaf938: StoreField: r1->field_7 = r0
    //     0xcaf938: stur            w0, [x1, #7]
    // 0xcaf93c: r16 = Instance_Color
    //     0xcaf93c: add             x16, PP, #0xc, lsl #12  ; [pp+0xcf38] Obj!Color@b5d081
    //     0xcaf940: ldr             x16, [x16, #0xf38]
    // 0xcaf944: SaveReg r16
    //     0xcaf944: str             x16, [SP, #-8]!
    // 0xcaf948: ldur            d0, [fp, #-0x28]
    // 0xcaf94c: SaveReg d0
    //     0xcaf94c: str             d0, [SP, #-8]!
    // 0xcaf950: r0 = withOpacity()
    //     0xcaf950: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcaf954: add             SP, SP, #0x10
    // 0xcaf958: LoadField: r1 = r0->field_7
    //     0xcaf958: ldur            x1, [x0, #7]
    // 0xcaf95c: eor             x0, x1, #0xff000000
    // 0xcaf960: ldur            x1, [fp, #-0x18]
    // 0xcaf964: LoadField: r2 = r1->field_17
    //     0xcaf964: ldur            w2, [x1, #0x17]
    // 0xcaf968: DecompressPointer r2
    //     0xcaf968: add             x2, x2, HEAP, lsl #32
    // 0xcaf96c: sxtw            x0, w0
    // 0xcaf970: LoadField: r1 = r2->field_7
    //     0xcaf970: ldur            x1, [x2, #7]
    // 0xcaf974: str             w0, [x1, #4]
    // 0xcaf978: ldur            x16, [fp, #-8]
    // 0xcaf97c: ldur            lr, [fp, #-0x10]
    // 0xcaf980: stp             lr, x16, [SP, #-0x10]!
    // 0xcaf984: ldur            x16, [fp, #-0x20]
    // 0xcaf988: SaveReg r16
    //     0xcaf988: str             x16, [SP, #-8]!
    // 0xcaf98c: r0 = drawRect()
    //     0xcaf98c: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xcaf990: add             SP, SP, #0x18
    // 0xcaf994: r0 = Null
    //     0xcaf994: mov             x0, NULL
    // 0xcaf998: LeaveFrame
    //     0xcaf998: mov             SP, fp
    //     0xcaf99c: ldp             fp, lr, [SP], #0x10
    // 0xcaf9a0: ret
    //     0xcaf9a0: ret             
    // 0xcaf9a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcaf9a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcaf9a8: b               #0xcaf844
    // 0xcaf9ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcaf9ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0xcb012c, size: 0x1c0
    // 0xcb012c: EnterFrame
    //     0xcb012c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb0130: mov             fp, SP
    // 0xcb0134: AllocStack(0x20)
    //     0xcb0134: sub             SP, SP, #0x20
    // 0xcb0138: CheckStackOverflow
    //     0xcb0138: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb013c: cmp             SP, x16
    //     0xcb0140: b.ls            #0xcb02e0
    // 0xcb0144: r1 = 2
    //     0xcb0144: mov             x1, #2
    // 0xcb0148: r0 = AllocateContext()
    //     0xcb0148: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcb014c: mov             x2, x0
    // 0xcb0150: ldr             x1, [fp, #0x30]
    // 0xcb0154: stur            x2, [fp, #-8]
    // 0xcb0158: StoreField: r2->field_f = r1
    //     0xcb0158: stur            w1, [x2, #0xf]
    // 0xcb015c: ldr             x0, [fp, #0x10]
    // 0xcb0160: StoreField: r2->field_13 = r0
    //     0xcb0160: stur            w0, [x2, #0x13]
    // 0xcb0164: LoadField: r0 = r1->field_27
    //     0xcb0164: ldur            w0, [x1, #0x27]
    // 0xcb0168: DecompressPointer r0
    //     0xcb0168: add             x0, x0, HEAP, lsl #32
    // 0xcb016c: r3 = LoadClassIdInstr(r0)
    //     0xcb016c: ldur            x3, [x0, #-1]
    //     0xcb0170: ubfx            x3, x3, #0xc, #0x14
    // 0xcb0174: SaveReg r0
    //     0xcb0174: str             x0, [SP, #-8]!
    // 0xcb0178: mov             x0, x3
    // 0xcb017c: r0 = GDT[cid_x0 + 0x376]()
    //     0xcb017c: add             lr, x0, #0x376
    //     0xcb0180: ldr             lr, [x21, lr, lsl #3]
    //     0xcb0184: blr             lr
    // 0xcb0188: add             SP, SP, #8
    // 0xcb018c: LoadField: r1 = r0->field_7
    //     0xcb018c: ldur            x1, [x0, #7]
    // 0xcb0190: cmp             x1, #1
    // 0xcb0194: b.gt            #0xcb01a4
    // 0xcb0198: cmp             x1, #0
    // 0xcb019c: b.gt            #0xcb01ac
    // 0xcb01a0: b               #0xcb029c
    // 0xcb01a4: cmp             x1, #2
    // 0xcb01a8: b.gt            #0xcb029c
    // 0xcb01ac: ldr             x0, [fp, #0x30]
    // 0xcb01b0: ldr             x16, [fp, #0x28]
    // 0xcb01b4: stp             x16, x0, [SP, #-0x10]!
    // 0xcb01b8: ldr             x16, [fp, #0x20]
    // 0xcb01bc: ldr             lr, [fp, #0x18]
    // 0xcb01c0: stp             lr, x16, [SP, #-0x10]!
    // 0xcb01c4: r0 = _drawScrim()
    //     0xcb01c4: bl              #0xcaf82c  ; [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::_drawScrim
    // 0xcb01c8: add             SP, SP, #0x20
    // 0xcb01cc: ldr             x0, [fp, #0x30]
    // 0xcb01d0: LoadField: r1 = r0->field_33
    //     0xcb01d0: ldur            w1, [x0, #0x33]
    // 0xcb01d4: DecompressPointer r1
    //     0xcb01d4: add             x1, x1, HEAP, lsl #32
    // 0xcb01d8: stur            x1, [fp, #-0x10]
    // 0xcb01dc: LoadField: r2 = r0->field_2b
    //     0xcb01dc: ldur            w2, [x0, #0x2b]
    // 0xcb01e0: DecompressPointer r2
    //     0xcb01e0: add             x2, x2, HEAP, lsl #32
    // 0xcb01e4: LoadField: r3 = r2->field_f
    //     0xcb01e4: ldur            w3, [x2, #0xf]
    // 0xcb01e8: DecompressPointer r3
    //     0xcb01e8: add             x3, x3, HEAP, lsl #32
    // 0xcb01ec: LoadField: r4 = r2->field_b
    //     0xcb01ec: ldur            w4, [x2, #0xb]
    // 0xcb01f0: DecompressPointer r4
    //     0xcb01f0: add             x4, x4, HEAP, lsl #32
    // 0xcb01f4: stp             x4, x3, [SP, #-0x10]!
    // 0xcb01f8: r0 = evaluate()
    //     0xcb01f8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xcb01fc: add             SP, SP, #0x10
    // 0xcb0200: LoadField: d0 = r0->field_7
    //     0xcb0200: ldur            d0, [x0, #7]
    // 0xcb0204: ldur            x16, [fp, #-0x10]
    // 0xcb0208: SaveReg r16
    //     0xcb0208: str             x16, [SP, #-8]!
    // 0xcb020c: SaveReg d0
    //     0xcb020c: str             d0, [SP, #-8]!
    // 0xcb0210: ldr             x16, [fp, #0x18]
    // 0xcb0214: SaveReg r16
    //     0xcb0214: str             x16, [SP, #-8]!
    // 0xcb0218: r0 = _updateScaledTransform()
    //     0xcb0218: bl              #0xcb02ec  ; [package:flutter/src/material/page_transitions_theme.dart] ::_updateScaledTransform
    // 0xcb021c: add             SP, SP, #0x18
    // 0xcb0220: ldr             x0, [fp, #0x30]
    // 0xcb0224: LoadField: r3 = r0->field_3b
    //     0xcb0224: ldur            w3, [x0, #0x3b]
    // 0xcb0228: DecompressPointer r3
    //     0xcb0228: add             x3, x3, HEAP, lsl #32
    // 0xcb022c: stur            x3, [fp, #-0x20]
    // 0xcb0230: LoadField: r0 = r3->field_b
    //     0xcb0230: ldur            w0, [x3, #0xb]
    // 0xcb0234: DecompressPointer r0
    //     0xcb0234: add             x0, x0, HEAP, lsl #32
    // 0xcb0238: ldur            x2, [fp, #-8]
    // 0xcb023c: stur            x0, [fp, #-0x18]
    // 0xcb0240: r1 = Function '<anonymous closure>':.
    //     0xcb0240: add             x1, PP, #0x55, lsl #12  ; [pp+0x55880] AnonymousClosure: (0xcb042c), in [package:flutter/src/material/page_transitions_theme.dart] _ZoomEnterTransitionPainter::paint (0xcb012c)
    //     0xcb0244: ldr             x1, [x1, #0x880]
    // 0xcb0248: r0 = AllocateClosure()
    //     0xcb0248: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcb024c: ldr             x16, [fp, #0x28]
    // 0xcb0250: r30 = true
    //     0xcb0250: add             lr, NULL, #0x20  ; true
    // 0xcb0254: stp             lr, x16, [SP, #-0x10]!
    // 0xcb0258: ldr             x16, [fp, #0x20]
    // 0xcb025c: ldur            lr, [fp, #-0x10]
    // 0xcb0260: stp             lr, x16, [SP, #-0x10]!
    // 0xcb0264: ldur            x16, [fp, #-0x18]
    // 0xcb0268: stp             x16, x0, [SP, #-0x10]!
    // 0xcb026c: r4 = const [0, 0x6, 0x6, 0x5, oldLayer, 0x5, null]
    //     0xcb026c: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cef8] List(7) [0, 0x6, 0x6, 0x5, "oldLayer", 0x5, Null]
    //     0xcb0270: ldr             x4, [x4, #0xef8]
    // 0xcb0274: r0 = pushTransform()
    //     0xcb0274: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0xcb0278: add             SP, SP, #0x30
    // 0xcb027c: ldur            x16, [fp, #-0x20]
    // 0xcb0280: stp             x0, x16, [SP, #-0x10]!
    // 0xcb0284: r0 = layer=()
    //     0xcb0284: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xcb0288: add             SP, SP, #0x10
    // 0xcb028c: r0 = Null
    //     0xcb028c: mov             x0, NULL
    // 0xcb0290: LeaveFrame
    //     0xcb0290: mov             SP, fp
    //     0xcb0294: ldp             fp, lr, [SP], #0x10
    // 0xcb0298: ret
    //     0xcb0298: ret             
    // 0xcb029c: ldur            x0, [fp, #-8]
    // 0xcb02a0: LoadField: r1 = r0->field_13
    //     0xcb02a0: ldur            w1, [x0, #0x13]
    // 0xcb02a4: DecompressPointer r1
    //     0xcb02a4: add             x1, x1, HEAP, lsl #32
    // 0xcb02a8: cmp             w1, NULL
    // 0xcb02ac: b.eq            #0xcb02e8
    // 0xcb02b0: ldr             x16, [fp, #0x28]
    // 0xcb02b4: stp             x16, x1, [SP, #-0x10]!
    // 0xcb02b8: ldr             x16, [fp, #0x20]
    // 0xcb02bc: SaveReg r16
    //     0xcb02bc: str             x16, [SP, #-8]!
    // 0xcb02c0: mov             x0, x1
    // 0xcb02c4: ClosureCall
    //     0xcb02c4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xcb02c8: ldur            x2, [x0, #0x1f]
    //     0xcb02cc: blr             x2
    // 0xcb02d0: add             SP, SP, #0x18
    // 0xcb02d4: LeaveFrame
    //     0xcb02d4: mov             SP, fp
    //     0xcb02d8: ldp             fp, lr, [SP], #0x10
    // 0xcb02dc: ret
    //     0xcb02dc: ret             
    // 0xcb02e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb02e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb02e4: b               #0xcb0144
    // 0xcb02e8: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcb02e8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0xcb042c, size: 0x154
    // 0xcb042c: EnterFrame
    //     0xcb042c: stp             fp, lr, [SP, #-0x10]!
    //     0xcb0430: mov             fp, SP
    // 0xcb0434: AllocStack(0x10)
    //     0xcb0434: sub             SP, SP, #0x10
    // 0xcb0438: SetupParameters()
    //     0xcb0438: ldr             x0, [fp, #0x20]
    //     0xcb043c: ldur            w1, [x0, #0x17]
    //     0xcb0440: add             x1, x1, HEAP, lsl #32
    //     0xcb0444: stur            x1, [fp, #-0x10]
    // 0xcb0448: CheckStackOverflow
    //     0xcb0448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcb044c: cmp             SP, x16
    //     0xcb0450: b.ls            #0xcb055c
    // 0xcb0454: LoadField: r0 = r1->field_f
    //     0xcb0454: ldur            w0, [x1, #0xf]
    // 0xcb0458: DecompressPointer r0
    //     0xcb0458: add             x0, x0, HEAP, lsl #32
    // 0xcb045c: LoadField: r2 = r0->field_37
    //     0xcb045c: ldur            w2, [x0, #0x37]
    // 0xcb0460: DecompressPointer r2
    //     0xcb0460: add             x2, x2, HEAP, lsl #32
    // 0xcb0464: stur            x2, [fp, #-8]
    // 0xcb0468: LoadField: r3 = r0->field_2f
    //     0xcb0468: ldur            w3, [x0, #0x2f]
    // 0xcb046c: DecompressPointer r3
    //     0xcb046c: add             x3, x3, HEAP, lsl #32
    // 0xcb0470: r0 = LoadClassIdInstr(r3)
    //     0xcb0470: ldur            x0, [x3, #-1]
    //     0xcb0474: ubfx            x0, x0, #0xc, #0x14
    // 0xcb0478: SaveReg r3
    //     0xcb0478: str             x3, [SP, #-8]!
    // 0xcb047c: r0 = GDT[cid_x0 + 0xb7c]()
    //     0xcb047c: add             lr, x0, #0xb7c
    //     0xcb0480: ldr             lr, [x21, lr, lsl #3]
    //     0xcb0484: blr             lr
    // 0xcb0488: add             SP, SP, #8
    // 0xcb048c: LoadField: d0 = r0->field_7
    //     0xcb048c: ldur            d0, [x0, #7]
    // 0xcb0490: d1 = 255.000000
    //     0xcb0490: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xcb0494: ldr             d1, [x17, #0x200]
    // 0xcb0498: fmul            d2, d0, d1
    // 0xcb049c: mov             v0.16b, v2.16b
    // 0xcb04a0: stp             fp, lr, [SP, #-0x10]!
    // 0xcb04a4: mov             fp, SP
    // 0xcb04a8: CallRuntime_LibcRound(double) -> double
    //     0xcb04a8: and             SP, SP, #0xfffffffffffffff0
    //     0xcb04ac: mov             sp, SP
    //     0xcb04b0: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0xcb04b4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcb04b8: blr             x16
    //     0xcb04bc: mov             x16, #8
    //     0xcb04c0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xcb04c4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xcb04c8: sub             sp, x16, #1, lsl #12
    //     0xcb04cc: mov             SP, fp
    //     0xcb04d0: ldp             fp, lr, [SP], #0x10
    // 0xcb04d4: fcmp            d0, d0
    // 0xcb04d8: b.vs            #0xcb0564
    // 0xcb04dc: fcvtzs          x0, d0
    // 0xcb04e0: asr             x16, x0, #0x1e
    // 0xcb04e4: cmp             x16, x0, asr #63
    // 0xcb04e8: b.ne            #0xcb0564
    // 0xcb04ec: lsl             x0, x0, #1
    // 0xcb04f0: ldur            x1, [fp, #-0x10]
    // 0xcb04f4: LoadField: r2 = r1->field_13
    //     0xcb04f4: ldur            w2, [x1, #0x13]
    // 0xcb04f8: DecompressPointer r2
    //     0xcb04f8: add             x2, x2, HEAP, lsl #32
    // 0xcb04fc: LoadField: r3 = r1->field_f
    //     0xcb04fc: ldur            w3, [x1, #0xf]
    // 0xcb0500: DecompressPointer r3
    //     0xcb0500: add             x3, x3, HEAP, lsl #32
    // 0xcb0504: LoadField: r1 = r3->field_37
    //     0xcb0504: ldur            w1, [x3, #0x37]
    // 0xcb0508: DecompressPointer r1
    //     0xcb0508: add             x1, x1, HEAP, lsl #32
    // 0xcb050c: LoadField: r3 = r1->field_b
    //     0xcb050c: ldur            w3, [x1, #0xb]
    // 0xcb0510: DecompressPointer r3
    //     0xcb0510: add             x3, x3, HEAP, lsl #32
    // 0xcb0514: r1 = LoadInt32Instr(r0)
    //     0xcb0514: sbfx            x1, x0, #1, #0x1f
    //     0xcb0518: tbz             w0, #0, #0xcb0520
    //     0xcb051c: ldur            x1, [x0, #7]
    // 0xcb0520: ldr             x16, [fp, #0x18]
    // 0xcb0524: ldr             lr, [fp, #0x10]
    // 0xcb0528: stp             lr, x16, [SP, #-0x10]!
    // 0xcb052c: stp             x2, x1, [SP, #-0x10]!
    // 0xcb0530: SaveReg r3
    //     0xcb0530: str             x3, [SP, #-8]!
    // 0xcb0534: r0 = pushOpacity()
    //     0xcb0534: bl              #0x66116c  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushOpacity
    // 0xcb0538: add             SP, SP, #0x28
    // 0xcb053c: ldur            x16, [fp, #-8]
    // 0xcb0540: stp             x0, x16, [SP, #-0x10]!
    // 0xcb0544: r0 = layer=()
    //     0xcb0544: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0xcb0548: add             SP, SP, #0x10
    // 0xcb054c: r0 = Null
    //     0xcb054c: mov             x0, NULL
    // 0xcb0550: LeaveFrame
    //     0xcb0550: mov             SP, fp
    //     0xcb0554: ldp             fp, lr, [SP], #0x10
    // 0xcb0558: ret
    //     0xcb0558: ret             
    // 0xcb055c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcb055c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcb0560: b               #0xcb0454
    // 0xcb0564: SaveReg d0
    //     0xcb0564: str             q0, [SP, #-0x10]!
    // 0xcb0568: r0 = 218
    //     0xcb0568: mov             x0, #0xda
    // 0xcb056c: r24 = DoubleToIntegerStub
    //     0xcb056c: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xcb0570: LoadField: r30 = r24->field_7
    //     0xcb0570: ldur            lr, [x24, #7]
    // 0xcb0574: blr             lr
    // 0xcb0578: RestoreReg d0
    //     0xcb0578: ldr             q0, [SP], #0x10
    // 0xcb057c: b               #0xcb04f0
  }
}

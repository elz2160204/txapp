// lib: , url: package:flutter/src/material/outlined_button_theme.dart

// class id: 1049286, size: 0x8
class :: {
}

// class id: 2779, size: 0xc, field offset: 0x8
//   const constructor, 
class OutlinedButtonThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  static _ lerp(/* No info */) {
    // ** addr: 0xbf3554, size: 0x68
    // 0xbf3554: EnterFrame
    //     0xbf3554: stp             fp, lr, [SP, #-0x10]!
    //     0xbf3558: mov             fp, SP
    // 0xbf355c: AllocStack(0x8)
    //     0xbf355c: sub             SP, SP, #8
    // 0xbf3560: CheckStackOverflow
    //     0xbf3560: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf3564: cmp             SP, x16
    //     0xbf3568: b.ls            #0xbf35b4
    // 0xbf356c: ldr             x0, [fp, #0x20]
    // 0xbf3570: LoadField: r1 = r0->field_7
    //     0xbf3570: ldur            w1, [x0, #7]
    // 0xbf3574: DecompressPointer r1
    //     0xbf3574: add             x1, x1, HEAP, lsl #32
    // 0xbf3578: ldr             x0, [fp, #0x18]
    // 0xbf357c: LoadField: r2 = r0->field_7
    //     0xbf357c: ldur            w2, [x0, #7]
    // 0xbf3580: DecompressPointer r2
    //     0xbf3580: add             x2, x2, HEAP, lsl #32
    // 0xbf3584: stp             x2, x1, [SP, #-0x10]!
    // 0xbf3588: ldr             d0, [fp, #0x10]
    // 0xbf358c: SaveReg d0
    //     0xbf358c: str             d0, [SP, #-8]!
    // 0xbf3590: r0 = lerp()
    //     0xbf3590: bl              #0xbef34c  ; [package:flutter/src/material/button_style.dart] ButtonStyle::lerp
    // 0xbf3594: add             SP, SP, #0x18
    // 0xbf3598: stur            x0, [fp, #-8]
    // 0xbf359c: r0 = OutlinedButtonThemeData()
    //     0xbf359c: bl              #0xbf35bc  ; AllocateOutlinedButtonThemeDataStub -> OutlinedButtonThemeData (size=0xc)
    // 0xbf35a0: ldur            x1, [fp, #-8]
    // 0xbf35a4: StoreField: r0->field_7 = r1
    //     0xbf35a4: stur            w1, [x0, #7]
    // 0xbf35a8: LeaveFrame
    //     0xbf35a8: mov             SP, fp
    //     0xbf35ac: ldp             fp, lr, [SP], #0x10
    // 0xbf35b0: ret
    //     0xbf35b0: ret             
    // 0xbf35b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf35b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf35b8: b               #0xbf356c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8c4e4, size: 0x124
    // 0xc8c4e4: EnterFrame
    //     0xc8c4e4: stp             fp, lr, [SP, #-0x10]!
    //     0xc8c4e8: mov             fp, SP
    // 0xc8c4ec: CheckStackOverflow
    //     0xc8c4ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8c4f0: cmp             SP, x16
    //     0xc8c4f4: b.ls            #0xc8c600
    // 0xc8c4f8: ldr             x1, [fp, #0x10]
    // 0xc8c4fc: cmp             w1, NULL
    // 0xc8c500: b.ne            #0xc8c514
    // 0xc8c504: r0 = false
    //     0xc8c504: add             x0, NULL, #0x30  ; false
    // 0xc8c508: LeaveFrame
    //     0xc8c508: mov             SP, fp
    //     0xc8c50c: ldp             fp, lr, [SP], #0x10
    // 0xc8c510: ret
    //     0xc8c510: ret             
    // 0xc8c514: ldr             x2, [fp, #0x18]
    // 0xc8c518: cmp             w2, w1
    // 0xc8c51c: b.ne            #0xc8c530
    // 0xc8c520: r0 = true
    //     0xc8c520: add             x0, NULL, #0x20  ; true
    // 0xc8c524: LeaveFrame
    //     0xc8c524: mov             SP, fp
    //     0xc8c528: ldp             fp, lr, [SP], #0x10
    // 0xc8c52c: ret
    //     0xc8c52c: ret             
    // 0xc8c530: r0 = 59
    //     0xc8c530: mov             x0, #0x3b
    // 0xc8c534: branchIfSmi(r1, 0xc8c540)
    //     0xc8c534: tbz             w1, #0, #0xc8c540
    // 0xc8c538: r0 = LoadClassIdInstr(r1)
    //     0xc8c538: ldur            x0, [x1, #-1]
    //     0xc8c53c: ubfx            x0, x0, #0xc, #0x14
    // 0xc8c540: SaveReg r1
    //     0xc8c540: str             x1, [SP, #-8]!
    // 0xc8c544: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8c544: mov             x17, #0x57c5
    //     0xc8c548: add             lr, x0, x17
    //     0xc8c54c: ldr             lr, [x21, lr, lsl #3]
    //     0xc8c550: blr             lr
    // 0xc8c554: add             SP, SP, #8
    // 0xc8c558: r1 = LoadClassIdInstr(r0)
    //     0xc8c558: ldur            x1, [x0, #-1]
    //     0xc8c55c: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c560: r16 = OutlinedButtonThemeData
    //     0xc8c560: add             x16, PP, #0xe, lsl #12  ; [pp+0xe1c8] Type: OutlinedButtonThemeData
    //     0xc8c564: ldr             x16, [x16, #0x1c8]
    // 0xc8c568: stp             x16, x0, [SP, #-0x10]!
    // 0xc8c56c: mov             x0, x1
    // 0xc8c570: mov             lr, x0
    // 0xc8c574: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c578: blr             lr
    // 0xc8c57c: add             SP, SP, #0x10
    // 0xc8c580: tbz             w0, #4, #0xc8c594
    // 0xc8c584: r0 = false
    //     0xc8c584: add             x0, NULL, #0x30  ; false
    // 0xc8c588: LeaveFrame
    //     0xc8c588: mov             SP, fp
    //     0xc8c58c: ldp             fp, lr, [SP], #0x10
    // 0xc8c590: ret
    //     0xc8c590: ret             
    // 0xc8c594: ldr             x0, [fp, #0x10]
    // 0xc8c598: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc8c598: mov             x1, #0x76
    //     0xc8c59c: tbz             w0, #0, #0xc8c5ac
    //     0xc8c5a0: ldur            x1, [x0, #-1]
    //     0xc8c5a4: ubfx            x1, x1, #0xc, #0x14
    //     0xc8c5a8: lsl             x1, x1, #1
    // 0xc8c5ac: r17 = 5558
    //     0xc8c5ac: mov             x17, #0x15b6
    // 0xc8c5b0: cmp             w1, w17
    // 0xc8c5b4: b.ne            #0xc8c5f0
    // 0xc8c5b8: ldr             x1, [fp, #0x18]
    // 0xc8c5bc: LoadField: r2 = r0->field_7
    //     0xc8c5bc: ldur            w2, [x0, #7]
    // 0xc8c5c0: DecompressPointer r2
    //     0xc8c5c0: add             x2, x2, HEAP, lsl #32
    // 0xc8c5c4: LoadField: r0 = r1->field_7
    //     0xc8c5c4: ldur            w0, [x1, #7]
    // 0xc8c5c8: DecompressPointer r0
    //     0xc8c5c8: add             x0, x0, HEAP, lsl #32
    // 0xc8c5cc: r1 = LoadClassIdInstr(r2)
    //     0xc8c5cc: ldur            x1, [x2, #-1]
    //     0xc8c5d0: ubfx            x1, x1, #0xc, #0x14
    // 0xc8c5d4: stp             x0, x2, [SP, #-0x10]!
    // 0xc8c5d8: mov             x0, x1
    // 0xc8c5dc: mov             lr, x0
    // 0xc8c5e0: ldr             lr, [x21, lr, lsl #3]
    // 0xc8c5e4: blr             lr
    // 0xc8c5e8: add             SP, SP, #0x10
    // 0xc8c5ec: b               #0xc8c5f4
    // 0xc8c5f0: r0 = false
    //     0xc8c5f0: add             x0, NULL, #0x30  ; false
    // 0xc8c5f4: LeaveFrame
    //     0xc8c5f4: mov             SP, fp
    //     0xc8c5f8: ldp             fp, lr, [SP], #0x10
    // 0xc8c5fc: ret
    //     0xc8c5fc: ret             
    // 0xc8c600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8c600: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8c604: b               #0xc8c4f8
  }
}

// class id: 3542, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class OutlinedButtonTheme extends InheritedTheme {

  static _ of(/* No info */) {
    // ** addr: 0xc13484, size: 0x64
    // 0xc13484: EnterFrame
    //     0xc13484: stp             fp, lr, [SP, #-0x10]!
    //     0xc13488: mov             fp, SP
    // 0xc1348c: CheckStackOverflow
    //     0xc1348c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc13490: cmp             SP, x16
    //     0xc13494: b.ls            #0xc134e0
    // 0xc13498: r16 = <OutlinedButtonTheme>
    //     0xc13498: add             x16, PP, #0x50, lsl #12  ; [pp+0x50918] TypeArguments: <OutlinedButtonTheme>
    //     0xc1349c: ldr             x16, [x16, #0x918]
    // 0xc134a0: ldr             lr, [fp, #0x10]
    // 0xc134a4: stp             lr, x16, [SP, #-0x10]!
    // 0xc134a8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc134a8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc134ac: r0 = dependOnInheritedWidgetOfExactType()
    //     0xc134ac: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xc134b0: add             SP, SP, #0x10
    // 0xc134b4: ldr             x16, [fp, #0x10]
    // 0xc134b8: SaveReg r16
    //     0xc134b8: str             x16, [SP, #-8]!
    // 0xc134bc: r0 = of()
    //     0xc134bc: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc134c0: add             SP, SP, #8
    // 0xc134c4: r17 = 267
    //     0xc134c4: mov             x17, #0x10b
    // 0xc134c8: ldr             w1, [x0, x17]
    // 0xc134cc: DecompressPointer r1
    //     0xc134cc: add             x1, x1, HEAP, lsl #32
    // 0xc134d0: mov             x0, x1
    // 0xc134d4: LeaveFrame
    //     0xc134d4: mov             SP, fp
    //     0xc134d8: ldp             fp, lr, [SP], #0x10
    // 0xc134dc: ret
    //     0xc134dc: ret             
    // 0xc134e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc134e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc134e4: b               #0xc13498
  }
}

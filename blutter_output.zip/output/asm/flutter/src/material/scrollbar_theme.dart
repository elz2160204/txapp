// lib: , url: package:flutter/src/material/scrollbar_theme.dart

// class id: 1049302, size: 0x8
class :: {

  [closure] static bool? _lerpBool(dynamic, bool?, bool?, double) {
    // ** addr: 0xbf87b0, size: 0x30
    // 0xbf87b0: d0 = 0.500000
    //     0xbf87b0: fmov            d0, #0.50000000
    // 0xbf87b4: ldr             x1, [SP]
    // 0xbf87b8: LoadField: d1 = r1->field_7
    //     0xbf87b8: ldur            d1, [x1, #7]
    // 0xbf87bc: fcmp            d1, d0
    // 0xbf87c0: b.vs            #0xbf87d4
    // 0xbf87c4: b.ge            #0xbf87d4
    // 0xbf87c8: ldr             x1, [SP, #0x10]
    // 0xbf87cc: mov             x0, x1
    // 0xbf87d0: b               #0xbf87dc
    // 0xbf87d4: ldr             x1, [SP, #8]
    // 0xbf87d8: mov             x0, x1
    // 0xbf87dc: ret
    //     0xbf87dc: ret             
  }
}

// class id: 2770, size: 0x3c, field offset: 0x8
//   const constructor, 
class ScrollbarThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ hashCode(/* No info */) {
    // ** addr: 0xb00ef4, size: 0xb8
    // 0xb00ef4: EnterFrame
    //     0xb00ef4: stp             fp, lr, [SP, #-0x10]!
    //     0xb00ef8: mov             fp, SP
    // 0xb00efc: CheckStackOverflow
    //     0xb00efc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb00f00: cmp             SP, x16
    //     0xb00f04: b.ls            #0xb00fa4
    // 0xb00f08: ldr             x0, [fp, #0x10]
    // 0xb00f0c: LoadField: r1 = r0->field_7
    //     0xb00f0c: ldur            w1, [x0, #7]
    // 0xb00f10: DecompressPointer r1
    //     0xb00f10: add             x1, x1, HEAP, lsl #32
    // 0xb00f14: LoadField: r2 = r0->field_b
    //     0xb00f14: ldur            w2, [x0, #0xb]
    // 0xb00f18: DecompressPointer r2
    //     0xb00f18: add             x2, x2, HEAP, lsl #32
    // 0xb00f1c: LoadField: r3 = r0->field_f
    //     0xb00f1c: ldur            w3, [x0, #0xf]
    // 0xb00f20: DecompressPointer r3
    //     0xb00f20: add             x3, x3, HEAP, lsl #32
    // 0xb00f24: LoadField: r4 = r0->field_23
    //     0xb00f24: ldur            w4, [x0, #0x23]
    // 0xb00f28: DecompressPointer r4
    //     0xb00f28: add             x4, x4, HEAP, lsl #32
    // 0xb00f2c: LoadField: r5 = r0->field_27
    //     0xb00f2c: ldur            w5, [x0, #0x27]
    // 0xb00f30: DecompressPointer r5
    //     0xb00f30: add             x5, x5, HEAP, lsl #32
    // 0xb00f34: LoadField: r6 = r0->field_2b
    //     0xb00f34: ldur            w6, [x0, #0x2b]
    // 0xb00f38: DecompressPointer r6
    //     0xb00f38: add             x6, x6, HEAP, lsl #32
    // 0xb00f3c: LoadField: r7 = r0->field_2f
    //     0xb00f3c: ldur            w7, [x0, #0x2f]
    // 0xb00f40: DecompressPointer r7
    //     0xb00f40: add             x7, x7, HEAP, lsl #32
    // 0xb00f44: LoadField: r8 = r0->field_33
    //     0xb00f44: ldur            w8, [x0, #0x33]
    // 0xb00f48: DecompressPointer r8
    //     0xb00f48: add             x8, x8, HEAP, lsl #32
    // 0xb00f4c: LoadField: r9 = r0->field_37
    //     0xb00f4c: ldur            w9, [x0, #0x37]
    // 0xb00f50: DecompressPointer r9
    //     0xb00f50: add             x9, x9, HEAP, lsl #32
    // 0xb00f54: stp             x2, x1, [SP, #-0x10]!
    // 0xb00f58: stp             NULL, x3, [SP, #-0x10]!
    // 0xb00f5c: stp             NULL, NULL, [SP, #-0x10]!
    // 0xb00f60: stp             x4, NULL, [SP, #-0x10]!
    // 0xb00f64: stp             x6, x5, [SP, #-0x10]!
    // 0xb00f68: stp             x8, x7, [SP, #-0x10]!
    // 0xb00f6c: SaveReg r9
    //     0xb00f6c: str             x9, [SP, #-8]!
    // 0xb00f70: r4 = const [0, 0xd, 0xd, 0xd, null]
    //     0xb00f70: add             x4, PP, #0xd, lsl #12  ; [pp+0xdee0] List(5) [0, 0xd, 0xd, 0xd, Null]
    //     0xb00f74: ldr             x4, [x4, #0xee0]
    // 0xb00f78: r0 = hash()
    //     0xb00f78: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xb00f7c: add             SP, SP, #0x68
    // 0xb00f80: mov             x2, x0
    // 0xb00f84: r0 = BoxInt64Instr(r2)
    //     0xb00f84: sbfiz           x0, x2, #1, #0x1f
    //     0xb00f88: cmp             x2, x0, asr #1
    //     0xb00f8c: b.eq            #0xb00f98
    //     0xb00f90: bl              #0xd69bb8
    //     0xb00f94: stur            x2, [x0, #7]
    // 0xb00f98: LeaveFrame
    //     0xb00f98: mov             SP, fp
    //     0xb00f9c: ldp             fp, lr, [SP], #0x10
    // 0xb00fa0: ret
    //     0xb00fa0: ret             
    // 0xb00fa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb00fa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb00fa8: b               #0xb00f08
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xbf845c, size: 0x348
    // 0xbf845c: EnterFrame
    //     0xbf845c: stp             fp, lr, [SP, #-0x10]!
    //     0xbf8460: mov             fp, SP
    // 0xbf8464: AllocStack(0x48)
    //     0xbf8464: sub             SP, SP, #0x48
    // 0xbf8468: CheckStackOverflow
    //     0xbf8468: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbf846c: cmp             SP, x16
    //     0xbf8470: b.ls            #0xbf8770
    // 0xbf8474: ldr             x0, [fp, #0x20]
    // 0xbf8478: LoadField: r1 = r0->field_7
    //     0xbf8478: ldur            w1, [x0, #7]
    // 0xbf847c: DecompressPointer r1
    //     0xbf847c: add             x1, x1, HEAP, lsl #32
    // 0xbf8480: ldr             x2, [fp, #0x18]
    // 0xbf8484: LoadField: r3 = r2->field_7
    //     0xbf8484: ldur            w3, [x2, #7]
    // 0xbf8488: DecompressPointer r3
    //     0xbf8488: add             x3, x3, HEAP, lsl #32
    // 0xbf848c: r16 = <bool?>
    //     0xbf848c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe630] TypeArguments: <bool?>
    //     0xbf8490: ldr             x16, [x16, #0x630]
    // 0xbf8494: stp             x1, x16, [SP, #-0x10]!
    // 0xbf8498: SaveReg r3
    //     0xbf8498: str             x3, [SP, #-8]!
    // 0xbf849c: ldr             d0, [fp, #0x10]
    // 0xbf84a0: SaveReg d0
    //     0xbf84a0: str             d0, [SP, #-8]!
    // 0xbf84a4: r16 = Closure: (bool?, bool?, double) => bool? from Function '_lerpBool@803072678': static.
    //     0xbf84a4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbd8] Closure: (bool?, bool?, double) => bool? from Function '_lerpBool@803072678': static. (0x7fe6e23f87b0)
    //     0xbf84a8: ldr             x16, [x16, #0xbd8]
    // 0xbf84ac: SaveReg r16
    //     0xbf84ac: str             x16, [SP, #-8]!
    // 0xbf84b0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf84b0: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf84b4: r0 = lerp()
    //     0xbf84b4: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf84b8: add             SP, SP, #0x28
    // 0xbf84bc: mov             x1, x0
    // 0xbf84c0: ldr             x0, [fp, #0x20]
    // 0xbf84c4: stur            x1, [fp, #-8]
    // 0xbf84c8: LoadField: r2 = r0->field_b
    //     0xbf84c8: ldur            w2, [x0, #0xb]
    // 0xbf84cc: DecompressPointer r2
    //     0xbf84cc: add             x2, x2, HEAP, lsl #32
    // 0xbf84d0: ldr             x3, [fp, #0x18]
    // 0xbf84d4: LoadField: r4 = r3->field_b
    //     0xbf84d4: ldur            w4, [x3, #0xb]
    // 0xbf84d8: DecompressPointer r4
    //     0xbf84d8: add             x4, x4, HEAP, lsl #32
    // 0xbf84dc: r16 = <double?>
    //     0xbf84dc: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db88] TypeArguments: <double?>
    //     0xbf84e0: ldr             x16, [x16, #0xb88]
    // 0xbf84e4: stp             x2, x16, [SP, #-0x10]!
    // 0xbf84e8: SaveReg r4
    //     0xbf84e8: str             x4, [SP, #-8]!
    // 0xbf84ec: ldr             d0, [fp, #0x10]
    // 0xbf84f0: SaveReg d0
    //     0xbf84f0: str             d0, [SP, #-8]!
    // 0xbf84f4: r16 = Closure: (num?, num?, double) => double? from Function 'lerpDouble': static.
    //     0xbf84f4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db90] Closure: (num?, num?, double) => double? from Function 'lerpDouble': static. (0x7fe6e1db558c)
    //     0xbf84f8: ldr             x16, [x16, #0xb90]
    // 0xbf84fc: SaveReg r16
    //     0xbf84fc: str             x16, [SP, #-8]!
    // 0xbf8500: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf8500: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf8504: r0 = lerp()
    //     0xbf8504: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf8508: add             SP, SP, #0x28
    // 0xbf850c: mov             x1, x0
    // 0xbf8510: ldr             x0, [fp, #0x20]
    // 0xbf8514: stur            x1, [fp, #-0x10]
    // 0xbf8518: LoadField: r2 = r0->field_f
    //     0xbf8518: ldur            w2, [x0, #0xf]
    // 0xbf851c: DecompressPointer r2
    //     0xbf851c: add             x2, x2, HEAP, lsl #32
    // 0xbf8520: ldr             x3, [fp, #0x18]
    // 0xbf8524: LoadField: r4 = r3->field_f
    //     0xbf8524: ldur            w4, [x3, #0xf]
    // 0xbf8528: DecompressPointer r4
    //     0xbf8528: add             x4, x4, HEAP, lsl #32
    // 0xbf852c: r16 = <bool?>
    //     0xbf852c: add             x16, PP, #0xe, lsl #12  ; [pp+0xe630] TypeArguments: <bool?>
    //     0xbf8530: ldr             x16, [x16, #0x630]
    // 0xbf8534: stp             x2, x16, [SP, #-0x10]!
    // 0xbf8538: SaveReg r4
    //     0xbf8538: str             x4, [SP, #-8]!
    // 0xbf853c: ldr             d0, [fp, #0x10]
    // 0xbf8540: SaveReg d0
    //     0xbf8540: str             d0, [SP, #-8]!
    // 0xbf8544: r16 = Closure: (bool?, bool?, double) => bool? from Function '_lerpBool@803072678': static.
    //     0xbf8544: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2dbd8] Closure: (bool?, bool?, double) => bool? from Function '_lerpBool@803072678': static. (0x7fe6e23f87b0)
    //     0xbf8548: ldr             x16, [x16, #0xbd8]
    // 0xbf854c: SaveReg r16
    //     0xbf854c: str             x16, [SP, #-8]!
    // 0xbf8550: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf8550: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf8554: r0 = lerp()
    //     0xbf8554: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf8558: add             SP, SP, #0x28
    // 0xbf855c: mov             x1, x0
    // 0xbf8560: ldr             x0, [fp, #0x20]
    // 0xbf8564: stur            x1, [fp, #-0x18]
    // 0xbf8568: LoadField: r2 = r0->field_23
    //     0xbf8568: ldur            w2, [x0, #0x23]
    // 0xbf856c: DecompressPointer r2
    //     0xbf856c: add             x2, x2, HEAP, lsl #32
    // 0xbf8570: ldr             x3, [fp, #0x18]
    // 0xbf8574: LoadField: r4 = r3->field_23
    //     0xbf8574: ldur            w4, [x3, #0x23]
    // 0xbf8578: DecompressPointer r4
    //     0xbf8578: add             x4, x4, HEAP, lsl #32
    // 0xbf857c: r16 = <Color?>
    //     0xbf857c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf8580: ldr             x16, [x16, #0xf68]
    // 0xbf8584: stp             x2, x16, [SP, #-0x10]!
    // 0xbf8588: SaveReg r4
    //     0xbf8588: str             x4, [SP, #-8]!
    // 0xbf858c: ldr             d0, [fp, #0x10]
    // 0xbf8590: SaveReg d0
    //     0xbf8590: str             d0, [SP, #-8]!
    // 0xbf8594: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf8594: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf8598: ldr             x16, [x16, #0xb80]
    // 0xbf859c: SaveReg r16
    //     0xbf859c: str             x16, [SP, #-8]!
    // 0xbf85a0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf85a0: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf85a4: r0 = lerp()
    //     0xbf85a4: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf85a8: add             SP, SP, #0x28
    // 0xbf85ac: mov             x1, x0
    // 0xbf85b0: ldr             x0, [fp, #0x20]
    // 0xbf85b4: stur            x1, [fp, #-0x20]
    // 0xbf85b8: LoadField: r2 = r0->field_27
    //     0xbf85b8: ldur            w2, [x0, #0x27]
    // 0xbf85bc: DecompressPointer r2
    //     0xbf85bc: add             x2, x2, HEAP, lsl #32
    // 0xbf85c0: ldr             x3, [fp, #0x18]
    // 0xbf85c4: LoadField: r4 = r3->field_27
    //     0xbf85c4: ldur            w4, [x3, #0x27]
    // 0xbf85c8: DecompressPointer r4
    //     0xbf85c8: add             x4, x4, HEAP, lsl #32
    // 0xbf85cc: r16 = <Color?>
    //     0xbf85cc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf85d0: ldr             x16, [x16, #0xf68]
    // 0xbf85d4: stp             x2, x16, [SP, #-0x10]!
    // 0xbf85d8: SaveReg r4
    //     0xbf85d8: str             x4, [SP, #-8]!
    // 0xbf85dc: ldr             d0, [fp, #0x10]
    // 0xbf85e0: SaveReg d0
    //     0xbf85e0: str             d0, [SP, #-8]!
    // 0xbf85e4: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf85e4: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf85e8: ldr             x16, [x16, #0xb80]
    // 0xbf85ec: SaveReg r16
    //     0xbf85ec: str             x16, [SP, #-8]!
    // 0xbf85f0: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf85f0: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf85f4: r0 = lerp()
    //     0xbf85f4: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf85f8: add             SP, SP, #0x28
    // 0xbf85fc: mov             x1, x0
    // 0xbf8600: ldr             x0, [fp, #0x20]
    // 0xbf8604: stur            x1, [fp, #-0x28]
    // 0xbf8608: LoadField: r2 = r0->field_2b
    //     0xbf8608: ldur            w2, [x0, #0x2b]
    // 0xbf860c: DecompressPointer r2
    //     0xbf860c: add             x2, x2, HEAP, lsl #32
    // 0xbf8610: ldr             x3, [fp, #0x18]
    // 0xbf8614: LoadField: r4 = r3->field_2b
    //     0xbf8614: ldur            w4, [x3, #0x2b]
    // 0xbf8618: DecompressPointer r4
    //     0xbf8618: add             x4, x4, HEAP, lsl #32
    // 0xbf861c: r16 = <Color?>
    //     0xbf861c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0xbf8620: ldr             x16, [x16, #0xf68]
    // 0xbf8624: stp             x2, x16, [SP, #-0x10]!
    // 0xbf8628: SaveReg r4
    //     0xbf8628: str             x4, [SP, #-8]!
    // 0xbf862c: ldr             d0, [fp, #0x10]
    // 0xbf8630: SaveReg d0
    //     0xbf8630: str             d0, [SP, #-8]!
    // 0xbf8634: r16 = Closure: (Color?, Color?, double) => Color? from Function 'lerp': static.
    //     0xbf8634: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2db80] Closure: (Color?, Color?, double) => Color? from Function 'lerp': static. (0x7fe6e1db515c)
    //     0xbf8638: ldr             x16, [x16, #0xb80]
    // 0xbf863c: SaveReg r16
    //     0xbf863c: str             x16, [SP, #-8]!
    // 0xbf8640: r4 = const [0x1, 0x4, 0x4, 0x4, null]
    //     0xbf8640: ldr             x4, [PP, #0x10f8]  ; [pp+0x10f8] List(5) [0x1, 0x4, 0x4, 0x4, Null]
    // 0xbf8644: r0 = lerp()
    //     0xbf8644: bl              #0xbf0cf8  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::lerp
    // 0xbf8648: add             SP, SP, #0x28
    // 0xbf864c: mov             x1, x0
    // 0xbf8650: ldr             x0, [fp, #0x20]
    // 0xbf8654: stur            x1, [fp, #-0x38]
    // 0xbf8658: LoadField: r2 = r0->field_2f
    //     0xbf8658: ldur            w2, [x0, #0x2f]
    // 0xbf865c: DecompressPointer r2
    //     0xbf865c: add             x2, x2, HEAP, lsl #32
    // 0xbf8660: ldr             x3, [fp, #0x18]
    // 0xbf8664: LoadField: r4 = r3->field_2f
    //     0xbf8664: ldur            w4, [x3, #0x2f]
    // 0xbf8668: DecompressPointer r4
    //     0xbf8668: add             x4, x4, HEAP, lsl #32
    // 0xbf866c: ldr             d0, [fp, #0x10]
    // 0xbf8670: r5 = inline_Allocate_Double()
    //     0xbf8670: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0xbf8674: add             x5, x5, #0x10
    //     0xbf8678: cmp             x6, x5
    //     0xbf867c: b.ls            #0xbf8778
    //     0xbf8680: str             x5, [THR, #0x60]  ; THR::top
    //     0xbf8684: sub             x5, x5, #0xf
    //     0xbf8688: mov             x6, #0xd108
    //     0xbf868c: movk            x6, #3, lsl #16
    //     0xbf8690: stur            x6, [x5, #-1]
    // 0xbf8694: StoreField: r5->field_7 = d0
    //     0xbf8694: stur            d0, [x5, #7]
    // 0xbf8698: stur            x5, [fp, #-0x30]
    // 0xbf869c: stp             x4, x2, [SP, #-0x10]!
    // 0xbf86a0: SaveReg r5
    //     0xbf86a0: str             x5, [SP, #-8]!
    // 0xbf86a4: r0 = lerpDouble()
    //     0xbf86a4: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf86a8: add             SP, SP, #0x18
    // 0xbf86ac: mov             x1, x0
    // 0xbf86b0: ldr             x0, [fp, #0x20]
    // 0xbf86b4: stur            x1, [fp, #-0x40]
    // 0xbf86b8: LoadField: r2 = r0->field_33
    //     0xbf86b8: ldur            w2, [x0, #0x33]
    // 0xbf86bc: DecompressPointer r2
    //     0xbf86bc: add             x2, x2, HEAP, lsl #32
    // 0xbf86c0: ldr             x3, [fp, #0x18]
    // 0xbf86c4: LoadField: r4 = r3->field_33
    //     0xbf86c4: ldur            w4, [x3, #0x33]
    // 0xbf86c8: DecompressPointer r4
    //     0xbf86c8: add             x4, x4, HEAP, lsl #32
    // 0xbf86cc: stp             x4, x2, [SP, #-0x10]!
    // 0xbf86d0: ldur            x16, [fp, #-0x30]
    // 0xbf86d4: SaveReg r16
    //     0xbf86d4: str             x16, [SP, #-8]!
    // 0xbf86d8: r0 = lerpDouble()
    //     0xbf86d8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf86dc: add             SP, SP, #0x18
    // 0xbf86e0: mov             x1, x0
    // 0xbf86e4: ldr             x0, [fp, #0x20]
    // 0xbf86e8: stur            x1, [fp, #-0x48]
    // 0xbf86ec: LoadField: r2 = r0->field_37
    //     0xbf86ec: ldur            w2, [x0, #0x37]
    // 0xbf86f0: DecompressPointer r2
    //     0xbf86f0: add             x2, x2, HEAP, lsl #32
    // 0xbf86f4: ldr             x0, [fp, #0x18]
    // 0xbf86f8: LoadField: r3 = r0->field_37
    //     0xbf86f8: ldur            w3, [x0, #0x37]
    // 0xbf86fc: DecompressPointer r3
    //     0xbf86fc: add             x3, x3, HEAP, lsl #32
    // 0xbf8700: stp             x3, x2, [SP, #-0x10]!
    // 0xbf8704: ldur            x16, [fp, #-0x30]
    // 0xbf8708: SaveReg r16
    //     0xbf8708: str             x16, [SP, #-8]!
    // 0xbf870c: r0 = lerpDouble()
    //     0xbf870c: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0xbf8710: add             SP, SP, #0x18
    // 0xbf8714: stur            x0, [fp, #-0x30]
    // 0xbf8718: r0 = ScrollbarThemeData()
    //     0xbf8718: bl              #0xbf87a4  ; AllocateScrollbarThemeDataStub -> ScrollbarThemeData (size=0x3c)
    // 0xbf871c: ldur            x1, [fp, #-8]
    // 0xbf8720: StoreField: r0->field_7 = r1
    //     0xbf8720: stur            w1, [x0, #7]
    // 0xbf8724: ldur            x1, [fp, #-0x10]
    // 0xbf8728: StoreField: r0->field_b = r1
    //     0xbf8728: stur            w1, [x0, #0xb]
    // 0xbf872c: ldur            x1, [fp, #-0x18]
    // 0xbf8730: StoreField: r0->field_f = r1
    //     0xbf8730: stur            w1, [x0, #0xf]
    // 0xbf8734: ldur            x1, [fp, #-0x20]
    // 0xbf8738: StoreField: r0->field_23 = r1
    //     0xbf8738: stur            w1, [x0, #0x23]
    // 0xbf873c: ldur            x1, [fp, #-0x28]
    // 0xbf8740: StoreField: r0->field_27 = r1
    //     0xbf8740: stur            w1, [x0, #0x27]
    // 0xbf8744: ldur            x1, [fp, #-0x38]
    // 0xbf8748: StoreField: r0->field_2b = r1
    //     0xbf8748: stur            w1, [x0, #0x2b]
    // 0xbf874c: ldur            x1, [fp, #-0x40]
    // 0xbf8750: StoreField: r0->field_2f = r1
    //     0xbf8750: stur            w1, [x0, #0x2f]
    // 0xbf8754: ldur            x1, [fp, #-0x48]
    // 0xbf8758: StoreField: r0->field_33 = r1
    //     0xbf8758: stur            w1, [x0, #0x33]
    // 0xbf875c: ldur            x1, [fp, #-0x30]
    // 0xbf8760: StoreField: r0->field_37 = r1
    //     0xbf8760: stur            w1, [x0, #0x37]
    // 0xbf8764: LeaveFrame
    //     0xbf8764: mov             SP, fp
    //     0xbf8768: ldp             fp, lr, [SP], #0x10
    // 0xbf876c: ret
    //     0xbf876c: ret             
    // 0xbf8770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbf8770: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbf8774: b               #0xbf8474
    // 0xbf8778: SaveReg d0
    //     0xbf8778: str             q0, [SP, #-0x10]!
    // 0xbf877c: stp             x3, x4, [SP, #-0x10]!
    // 0xbf8780: stp             x1, x2, [SP, #-0x10]!
    // 0xbf8784: SaveReg r0
    //     0xbf8784: str             x0, [SP, #-8]!
    // 0xbf8788: r0 = AllocateDouble()
    //     0xbf8788: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbf878c: mov             x5, x0
    // 0xbf8790: RestoreReg r0
    //     0xbf8790: ldr             x0, [SP], #8
    // 0xbf8794: ldp             x1, x2, [SP], #0x10
    // 0xbf8798: ldp             x3, x4, [SP], #0x10
    // 0xbf879c: RestoreReg d0
    //     0xbf879c: ldr             q0, [SP], #0x10
    // 0xbf87a0: b               #0xbf8694
  }
  _ ==(/* No info */) {
    // ** addr: 0xc8cc84, size: 0x22c
    // 0xc8cc84: EnterFrame
    //     0xc8cc84: stp             fp, lr, [SP, #-0x10]!
    //     0xc8cc88: mov             fp, SP
    // 0xc8cc8c: CheckStackOverflow
    //     0xc8cc8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc8cc90: cmp             SP, x16
    //     0xc8cc94: b.ls            #0xc8cea8
    // 0xc8cc98: ldr             x1, [fp, #0x10]
    // 0xc8cc9c: cmp             w1, NULL
    // 0xc8cca0: b.ne            #0xc8ccb4
    // 0xc8cca4: r0 = false
    //     0xc8cca4: add             x0, NULL, #0x30  ; false
    // 0xc8cca8: LeaveFrame
    //     0xc8cca8: mov             SP, fp
    //     0xc8ccac: ldp             fp, lr, [SP], #0x10
    // 0xc8ccb0: ret
    //     0xc8ccb0: ret             
    // 0xc8ccb4: ldr             x2, [fp, #0x18]
    // 0xc8ccb8: cmp             w2, w1
    // 0xc8ccbc: b.ne            #0xc8ccd0
    // 0xc8ccc0: r0 = true
    //     0xc8ccc0: add             x0, NULL, #0x20  ; true
    // 0xc8ccc4: LeaveFrame
    //     0xc8ccc4: mov             SP, fp
    //     0xc8ccc8: ldp             fp, lr, [SP], #0x10
    // 0xc8cccc: ret
    //     0xc8cccc: ret             
    // 0xc8ccd0: r0 = 59
    //     0xc8ccd0: mov             x0, #0x3b
    // 0xc8ccd4: branchIfSmi(r1, 0xc8cce0)
    //     0xc8ccd4: tbz             w1, #0, #0xc8cce0
    // 0xc8ccd8: r0 = LoadClassIdInstr(r1)
    //     0xc8ccd8: ldur            x0, [x1, #-1]
    //     0xc8ccdc: ubfx            x0, x0, #0xc, #0x14
    // 0xc8cce0: SaveReg r1
    //     0xc8cce0: str             x1, [SP, #-8]!
    // 0xc8cce4: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc8cce4: mov             x17, #0x57c5
    //     0xc8cce8: add             lr, x0, x17
    //     0xc8ccec: ldr             lr, [x21, lr, lsl #3]
    //     0xc8ccf0: blr             lr
    // 0xc8ccf4: add             SP, SP, #8
    // 0xc8ccf8: r1 = LoadClassIdInstr(r0)
    //     0xc8ccf8: ldur            x1, [x0, #-1]
    //     0xc8ccfc: ubfx            x1, x1, #0xc, #0x14
    // 0xc8cd00: r16 = ScrollbarThemeData
    //     0xc8cd00: add             x16, PP, #0xe, lsl #12  ; [pp+0xe188] Type: ScrollbarThemeData
    //     0xc8cd04: ldr             x16, [x16, #0x188]
    // 0xc8cd08: stp             x16, x0, [SP, #-0x10]!
    // 0xc8cd0c: mov             x0, x1
    // 0xc8cd10: mov             lr, x0
    // 0xc8cd14: ldr             lr, [x21, lr, lsl #3]
    // 0xc8cd18: blr             lr
    // 0xc8cd1c: add             SP, SP, #0x10
    // 0xc8cd20: tbz             w0, #4, #0xc8cd34
    // 0xc8cd24: r0 = false
    //     0xc8cd24: add             x0, NULL, #0x30  ; false
    // 0xc8cd28: LeaveFrame
    //     0xc8cd28: mov             SP, fp
    //     0xc8cd2c: ldp             fp, lr, [SP], #0x10
    // 0xc8cd30: ret
    //     0xc8cd30: ret             
    // 0xc8cd34: ldr             x1, [fp, #0x10]
    // 0xc8cd38: r0 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0xc8cd38: mov             x0, #0x76
    //     0xc8cd3c: tbz             w1, #0, #0xc8cd4c
    //     0xc8cd40: ldur            x0, [x1, #-1]
    //     0xc8cd44: ubfx            x0, x0, #0xc, #0x14
    //     0xc8cd48: lsl             x0, x0, #1
    // 0xc8cd4c: r17 = 5540
    //     0xc8cd4c: mov             x17, #0x15a4
    // 0xc8cd50: cmp             w0, w17
    // 0xc8cd54: b.ne            #0xc8ce98
    // 0xc8cd58: ldr             x2, [fp, #0x18]
    // 0xc8cd5c: LoadField: r0 = r1->field_7
    //     0xc8cd5c: ldur            w0, [x1, #7]
    // 0xc8cd60: DecompressPointer r0
    //     0xc8cd60: add             x0, x0, HEAP, lsl #32
    // 0xc8cd64: LoadField: r3 = r2->field_7
    //     0xc8cd64: ldur            w3, [x2, #7]
    // 0xc8cd68: DecompressPointer r3
    //     0xc8cd68: add             x3, x3, HEAP, lsl #32
    // 0xc8cd6c: cmp             w0, w3
    // 0xc8cd70: b.ne            #0xc8ce98
    // 0xc8cd74: LoadField: r0 = r1->field_b
    //     0xc8cd74: ldur            w0, [x1, #0xb]
    // 0xc8cd78: DecompressPointer r0
    //     0xc8cd78: add             x0, x0, HEAP, lsl #32
    // 0xc8cd7c: LoadField: r3 = r2->field_b
    //     0xc8cd7c: ldur            w3, [x2, #0xb]
    // 0xc8cd80: DecompressPointer r3
    //     0xc8cd80: add             x3, x3, HEAP, lsl #32
    // 0xc8cd84: cmp             w0, w3
    // 0xc8cd88: b.ne            #0xc8ce98
    // 0xc8cd8c: LoadField: r0 = r1->field_f
    //     0xc8cd8c: ldur            w0, [x1, #0xf]
    // 0xc8cd90: DecompressPointer r0
    //     0xc8cd90: add             x0, x0, HEAP, lsl #32
    // 0xc8cd94: LoadField: r3 = r2->field_f
    //     0xc8cd94: ldur            w3, [x2, #0xf]
    // 0xc8cd98: DecompressPointer r3
    //     0xc8cd98: add             x3, x3, HEAP, lsl #32
    // 0xc8cd9c: cmp             w0, w3
    // 0xc8cda0: b.ne            #0xc8ce98
    // 0xc8cda4: LoadField: r0 = r1->field_23
    //     0xc8cda4: ldur            w0, [x1, #0x23]
    // 0xc8cda8: DecompressPointer r0
    //     0xc8cda8: add             x0, x0, HEAP, lsl #32
    // 0xc8cdac: LoadField: r3 = r2->field_23
    //     0xc8cdac: ldur            w3, [x2, #0x23]
    // 0xc8cdb0: DecompressPointer r3
    //     0xc8cdb0: add             x3, x3, HEAP, lsl #32
    // 0xc8cdb4: cmp             w0, w3
    // 0xc8cdb8: b.ne            #0xc8ce98
    // 0xc8cdbc: LoadField: r0 = r1->field_27
    //     0xc8cdbc: ldur            w0, [x1, #0x27]
    // 0xc8cdc0: DecompressPointer r0
    //     0xc8cdc0: add             x0, x0, HEAP, lsl #32
    // 0xc8cdc4: LoadField: r3 = r2->field_27
    //     0xc8cdc4: ldur            w3, [x2, #0x27]
    // 0xc8cdc8: DecompressPointer r3
    //     0xc8cdc8: add             x3, x3, HEAP, lsl #32
    // 0xc8cdcc: cmp             w0, w3
    // 0xc8cdd0: b.ne            #0xc8ce98
    // 0xc8cdd4: LoadField: r0 = r1->field_2b
    //     0xc8cdd4: ldur            w0, [x1, #0x2b]
    // 0xc8cdd8: DecompressPointer r0
    //     0xc8cdd8: add             x0, x0, HEAP, lsl #32
    // 0xc8cddc: LoadField: r3 = r2->field_2b
    //     0xc8cddc: ldur            w3, [x2, #0x2b]
    // 0xc8cde0: DecompressPointer r3
    //     0xc8cde0: add             x3, x3, HEAP, lsl #32
    // 0xc8cde4: cmp             w0, w3
    // 0xc8cde8: b.ne            #0xc8ce98
    // 0xc8cdec: LoadField: r0 = r1->field_2f
    //     0xc8cdec: ldur            w0, [x1, #0x2f]
    // 0xc8cdf0: DecompressPointer r0
    //     0xc8cdf0: add             x0, x0, HEAP, lsl #32
    // 0xc8cdf4: LoadField: r3 = r2->field_2f
    //     0xc8cdf4: ldur            w3, [x2, #0x2f]
    // 0xc8cdf8: DecompressPointer r3
    //     0xc8cdf8: add             x3, x3, HEAP, lsl #32
    // 0xc8cdfc: r4 = LoadClassIdInstr(r0)
    //     0xc8cdfc: ldur            x4, [x0, #-1]
    //     0xc8ce00: ubfx            x4, x4, #0xc, #0x14
    // 0xc8ce04: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ce08: mov             x0, x4
    // 0xc8ce0c: mov             lr, x0
    // 0xc8ce10: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ce14: blr             lr
    // 0xc8ce18: add             SP, SP, #0x10
    // 0xc8ce1c: tbnz            w0, #4, #0xc8ce98
    // 0xc8ce20: ldr             x2, [fp, #0x18]
    // 0xc8ce24: ldr             x1, [fp, #0x10]
    // 0xc8ce28: LoadField: r0 = r1->field_33
    //     0xc8ce28: ldur            w0, [x1, #0x33]
    // 0xc8ce2c: DecompressPointer r0
    //     0xc8ce2c: add             x0, x0, HEAP, lsl #32
    // 0xc8ce30: LoadField: r3 = r2->field_33
    //     0xc8ce30: ldur            w3, [x2, #0x33]
    // 0xc8ce34: DecompressPointer r3
    //     0xc8ce34: add             x3, x3, HEAP, lsl #32
    // 0xc8ce38: r4 = LoadClassIdInstr(r0)
    //     0xc8ce38: ldur            x4, [x0, #-1]
    //     0xc8ce3c: ubfx            x4, x4, #0xc, #0x14
    // 0xc8ce40: stp             x3, x0, [SP, #-0x10]!
    // 0xc8ce44: mov             x0, x4
    // 0xc8ce48: mov             lr, x0
    // 0xc8ce4c: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ce50: blr             lr
    // 0xc8ce54: add             SP, SP, #0x10
    // 0xc8ce58: tbnz            w0, #4, #0xc8ce98
    // 0xc8ce5c: ldr             x1, [fp, #0x18]
    // 0xc8ce60: ldr             x0, [fp, #0x10]
    // 0xc8ce64: LoadField: r2 = r0->field_37
    //     0xc8ce64: ldur            w2, [x0, #0x37]
    // 0xc8ce68: DecompressPointer r2
    //     0xc8ce68: add             x2, x2, HEAP, lsl #32
    // 0xc8ce6c: LoadField: r0 = r1->field_37
    //     0xc8ce6c: ldur            w0, [x1, #0x37]
    // 0xc8ce70: DecompressPointer r0
    //     0xc8ce70: add             x0, x0, HEAP, lsl #32
    // 0xc8ce74: r1 = LoadClassIdInstr(r2)
    //     0xc8ce74: ldur            x1, [x2, #-1]
    //     0xc8ce78: ubfx            x1, x1, #0xc, #0x14
    // 0xc8ce7c: stp             x0, x2, [SP, #-0x10]!
    // 0xc8ce80: mov             x0, x1
    // 0xc8ce84: mov             lr, x0
    // 0xc8ce88: ldr             lr, [x21, lr, lsl #3]
    // 0xc8ce8c: blr             lr
    // 0xc8ce90: add             SP, SP, #0x10
    // 0xc8ce94: b               #0xc8ce9c
    // 0xc8ce98: r0 = false
    //     0xc8ce98: add             x0, NULL, #0x30  ; false
    // 0xc8ce9c: LeaveFrame
    //     0xc8ce9c: mov             SP, fp
    //     0xc8cea0: ldp             fp, lr, [SP], #0x10
    // 0xc8cea4: ret
    //     0xc8cea4: ret             
    // 0xc8cea8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc8cea8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc8ceac: b               #0xc8cc98
  }
}

// class id: 3524, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class ScrollbarTheme extends InheritedWidget {

  static _ of(/* No info */) {
    // ** addr: 0xa60f2c, size: 0x60
    // 0xa60f2c: EnterFrame
    //     0xa60f2c: stp             fp, lr, [SP, #-0x10]!
    //     0xa60f30: mov             fp, SP
    // 0xa60f34: CheckStackOverflow
    //     0xa60f34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60f38: cmp             SP, x16
    //     0xa60f3c: b.ls            #0xa60f84
    // 0xa60f40: r16 = <ScrollbarTheme>
    //     0xa60f40: add             x16, PP, #0x50, lsl #12  ; [pp+0x50840] TypeArguments: <ScrollbarTheme>
    //     0xa60f44: ldr             x16, [x16, #0x840]
    // 0xa60f48: ldr             lr, [fp, #0x10]
    // 0xa60f4c: stp             lr, x16, [SP, #-0x10]!
    // 0xa60f50: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xa60f50: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xa60f54: r0 = dependOnInheritedWidgetOfExactType()
    //     0xa60f54: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0xa60f58: add             SP, SP, #0x10
    // 0xa60f5c: ldr             x16, [fp, #0x10]
    // 0xa60f60: SaveReg r16
    //     0xa60f60: str             x16, [SP, #-8]!
    // 0xa60f64: r0 = of()
    //     0xa60f64: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xa60f68: add             SP, SP, #8
    // 0xa60f6c: LoadField: r1 = r0->field_23
    //     0xa60f6c: ldur            w1, [x0, #0x23]
    // 0xa60f70: DecompressPointer r1
    //     0xa60f70: add             x1, x1, HEAP, lsl #32
    // 0xa60f74: mov             x0, x1
    // 0xa60f78: LeaveFrame
    //     0xa60f78: mov             SP, fp
    //     0xa60f7c: ldp             fp, lr, [SP], #0x10
    // 0xa60f80: ret
    //     0xa60f80: ret             
    // 0xa60f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60f84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60f88: b               #0xa60f40
  }
}

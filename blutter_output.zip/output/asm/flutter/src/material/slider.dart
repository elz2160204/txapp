// lib: , url: package:flutter/src/material/slider.dart

// class id: 1049309, size: 0x8
class :: {
}

// class id: 2442, size: 0x68, field offset: 0x60
class _RenderValueIndicator extends __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin {

  late Animation<double> _valueIndicatorAnimation; // offset: 0x60

  _ paint(/* No info */) {
    // ** addr: 0x66c90c, size: 0x68
    // 0x66c90c: EnterFrame
    //     0x66c90c: stp             fp, lr, [SP, #-0x10]!
    //     0x66c910: mov             fp, SP
    // 0x66c914: CheckStackOverflow
    //     0x66c914: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66c918: cmp             SP, x16
    //     0x66c91c: b.ls            #0x66c96c
    // 0x66c920: ldr             x0, [fp, #0x20]
    // 0x66c924: LoadField: r1 = r0->field_63
    //     0x66c924: ldur            w1, [x0, #0x63]
    // 0x66c928: DecompressPointer r1
    //     0x66c928: add             x1, x1, HEAP, lsl #32
    // 0x66c92c: LoadField: r0 = r1->field_37
    //     0x66c92c: ldur            w0, [x1, #0x37]
    // 0x66c930: DecompressPointer r0
    //     0x66c930: add             x0, x0, HEAP, lsl #32
    // 0x66c934: cmp             w0, NULL
    // 0x66c938: b.eq            #0x66c95c
    // 0x66c93c: ldr             x16, [fp, #0x18]
    // 0x66c940: stp             x16, x0, [SP, #-0x10]!
    // 0x66c944: ldr             x16, [fp, #0x10]
    // 0x66c948: SaveReg r16
    //     0x66c948: str             x16, [SP, #-8]!
    // 0x66c94c: ClosureCall
    //     0x66c94c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x66c950: ldur            x2, [x0, #0x1f]
    //     0x66c954: blr             x2
    // 0x66c958: add             SP, SP, #0x18
    // 0x66c95c: r0 = Null
    //     0x66c95c: mov             x0, NULL
    // 0x66c960: LeaveFrame
    //     0x66c960: mov             SP, fp
    //     0x66c964: ldp             fp, lr, [SP], #0x10
    // 0x66c968: ret
    //     0x66c968: ret             
    // 0x66c96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66c96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66c970: b               #0x66c920
  }
  _ _RenderValueIndicator(/* No info */) {
    // ** addr: 0x6f0150, size: 0xe8
    // 0x6f0150: EnterFrame
    //     0x6f0150: stp             fp, lr, [SP, #-0x10]!
    //     0x6f0154: mov             fp, SP
    // 0x6f0158: AllocStack(0x10)
    //     0x6f0158: sub             SP, SP, #0x10
    // 0x6f015c: r0 = Sentinel
    //     0x6f015c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f0160: CheckStackOverflow
    //     0x6f0160: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0164: cmp             SP, x16
    //     0x6f0168: b.ls            #0x6f0224
    // 0x6f016c: ldr             x1, [fp, #0x18]
    // 0x6f0170: StoreField: r1->field_5f = r0
    //     0x6f0170: stur            w0, [x1, #0x5f]
    // 0x6f0174: ldr             x0, [fp, #0x10]
    // 0x6f0178: StoreField: r1->field_63 = r0
    //     0x6f0178: stur            w0, [x1, #0x63]
    //     0x6f017c: ldurb           w16, [x1, #-1]
    //     0x6f0180: ldurb           w17, [x0, #-1]
    //     0x6f0184: and             x16, x17, x16, lsr #2
    //     0x6f0188: tst             x16, HEAP, lsr #32
    //     0x6f018c: b.eq            #0x6f0194
    //     0x6f0190: bl              #0xd6826c
    // 0x6f0194: SaveReg r1
    //     0x6f0194: str             x1, [SP, #-8]!
    // 0x6f0198: r0 = RenderObject()
    //     0x6f0198: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f019c: add             SP, SP, #8
    // 0x6f01a0: ldr             x0, [fp, #0x18]
    // 0x6f01a4: LoadField: r1 = r0->field_63
    //     0x6f01a4: ldur            w1, [x0, #0x63]
    // 0x6f01a8: DecompressPointer r1
    //     0x6f01a8: add             x1, x1, HEAP, lsl #32
    // 0x6f01ac: LoadField: r2 = r1->field_1f
    //     0x6f01ac: ldur            w2, [x1, #0x1f]
    // 0x6f01b0: DecompressPointer r2
    //     0x6f01b0: add             x2, x2, HEAP, lsl #32
    // 0x6f01b4: r16 = Sentinel
    //     0x6f01b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6f01b8: cmp             w2, w16
    // 0x6f01bc: b.eq            #0x6f022c
    // 0x6f01c0: stur            x2, [fp, #-8]
    // 0x6f01c4: r1 = <double>
    //     0x6f01c4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6f01c8: r0 = CurvedAnimation()
    //     0x6f01c8: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6f01cc: stur            x0, [fp, #-0x10]
    // 0x6f01d0: r16 = Instance_Cubic
    //     0x6f01d0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x6f01d4: ldr             x16, [x16, #0x2c8]
    // 0x6f01d8: stp             x16, x0, [SP, #-0x10]!
    // 0x6f01dc: ldur            x16, [fp, #-8]
    // 0x6f01e0: SaveReg r16
    //     0x6f01e0: str             x16, [SP, #-8]!
    // 0x6f01e4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6f01e4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6f01e8: r0 = CurvedAnimation()
    //     0x6f01e8: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6f01ec: add             SP, SP, #0x18
    // 0x6f01f0: ldur            x0, [fp, #-0x10]
    // 0x6f01f4: ldr             x1, [fp, #0x18]
    // 0x6f01f8: StoreField: r1->field_5f = r0
    //     0x6f01f8: stur            w0, [x1, #0x5f]
    //     0x6f01fc: ldurb           w16, [x1, #-1]
    //     0x6f0200: ldurb           w17, [x0, #-1]
    //     0x6f0204: and             x16, x17, x16, lsr #2
    //     0x6f0208: tst             x16, HEAP, lsr #32
    //     0x6f020c: b.eq            #0x6f0214
    //     0x6f0210: bl              #0xd6826c
    // 0x6f0214: r0 = Null
    //     0x6f0214: mov             x0, NULL
    // 0x6f0218: LeaveFrame
    //     0x6f0218: mov             SP, fp
    //     0x6f021c: ldp             fp, lr, [SP], #0x10
    // 0x6f0220: ret
    //     0x6f0220: ret             
    // 0x6f0224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f0224: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f0228: b               #0x6f016c
    // 0x6f022c: r9 = valueIndicatorController
    //     0x6f022c: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6f0230: ldr             x9, [x9, #0x828]
    // 0x6f0234: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6f0234: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9be2c0, size: 0x138
    // 0x9be2c0: EnterFrame
    //     0x9be2c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9be2c4: mov             fp, SP
    // 0x9be2c8: AllocStack(0x8)
    //     0x9be2c8: sub             SP, SP, #8
    // 0x9be2cc: CheckStackOverflow
    //     0x9be2cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9be2d0: cmp             SP, x16
    //     0x9be2d4: b.ls            #0x9be3d8
    // 0x9be2d8: ldr             x0, [fp, #0x10]
    // 0x9be2dc: r2 = Null
    //     0x9be2dc: mov             x2, NULL
    // 0x9be2e0: r1 = Null
    //     0x9be2e0: mov             x1, NULL
    // 0x9be2e4: r4 = 59
    //     0x9be2e4: mov             x4, #0x3b
    // 0x9be2e8: branchIfSmi(r0, 0x9be2f4)
    //     0x9be2e8: tbz             w0, #0, #0x9be2f4
    // 0x9be2ec: r4 = LoadClassIdInstr(r0)
    //     0x9be2ec: ldur            x4, [x0, #-1]
    //     0x9be2f0: ubfx            x4, x4, #0xc, #0x14
    // 0x9be2f4: cmp             x4, #0x7e6
    // 0x9be2f8: b.eq            #0x9be30c
    // 0x9be2fc: r8 = PipelineOwner
    //     0x9be2fc: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9be300: r3 = Null
    //     0x9be300: add             x3, PP, #0x57, lsl #12  ; [pp+0x57308] Null
    //     0x9be304: ldr             x3, [x3, #0x308]
    // 0x9be308: r0 = DefaultTypeTest()
    //     0x9be308: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9be30c: ldr             x16, [fp, #0x18]
    // 0x9be310: ldr             lr, [fp, #0x10]
    // 0x9be314: stp             lr, x16, [SP, #-0x10]!
    // 0x9be318: r0 = attach()
    //     0x9be318: bl              #0x9be01c  ; [package:flutter/src/material/range_slider.dart] __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin::attach
    // 0x9be31c: add             SP, SP, #0x10
    // 0x9be320: ldr             x0, [fp, #0x18]
    // 0x9be324: LoadField: r1 = r0->field_5f
    //     0x9be324: ldur            w1, [x0, #0x5f]
    // 0x9be328: DecompressPointer r1
    //     0x9be328: add             x1, x1, HEAP, lsl #32
    // 0x9be32c: r16 = Sentinel
    //     0x9be32c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9be330: cmp             w1, w16
    // 0x9be334: b.eq            #0x9be3e0
    // 0x9be338: stur            x1, [fp, #-8]
    // 0x9be33c: r1 = 1
    //     0x9be33c: mov             x1, #1
    // 0x9be340: r0 = AllocateContext()
    //     0x9be340: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9be344: mov             x1, x0
    // 0x9be348: ldr             x0, [fp, #0x18]
    // 0x9be34c: StoreField: r1->field_f = r0
    //     0x9be34c: stur            w0, [x1, #0xf]
    // 0x9be350: mov             x2, x1
    // 0x9be354: r1 = Function 'markNeedsPaint':.
    //     0x9be354: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9be358: ldr             x1, [x1, #0xf60]
    // 0x9be35c: r0 = AllocateClosure()
    //     0x9be35c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9be360: ldur            x16, [fp, #-8]
    // 0x9be364: stp             x0, x16, [SP, #-0x10]!
    // 0x9be368: r0 = addListener()
    //     0x9be368: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x9be36c: add             SP, SP, #0x10
    // 0x9be370: ldr             x0, [fp, #0x18]
    // 0x9be374: LoadField: r1 = r0->field_63
    //     0x9be374: ldur            w1, [x0, #0x63]
    // 0x9be378: DecompressPointer r1
    //     0x9be378: add             x1, x1, HEAP, lsl #32
    // 0x9be37c: LoadField: r2 = r1->field_27
    //     0x9be37c: ldur            w2, [x1, #0x27]
    // 0x9be380: DecompressPointer r2
    //     0x9be380: add             x2, x2, HEAP, lsl #32
    // 0x9be384: r16 = Sentinel
    //     0x9be384: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9be388: cmp             w2, w16
    // 0x9be38c: b.eq            #0x9be3ec
    // 0x9be390: stur            x2, [fp, #-8]
    // 0x9be394: r1 = 1
    //     0x9be394: mov             x1, #1
    // 0x9be398: r0 = AllocateContext()
    //     0x9be398: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9be39c: mov             x1, x0
    // 0x9be3a0: ldr             x0, [fp, #0x18]
    // 0x9be3a4: StoreField: r1->field_f = r0
    //     0x9be3a4: stur            w0, [x1, #0xf]
    // 0x9be3a8: mov             x2, x1
    // 0x9be3ac: r1 = Function 'markNeedsPaint':.
    //     0x9be3ac: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9be3b0: ldr             x1, [x1, #0xf60]
    // 0x9be3b4: r0 = AllocateClosure()
    //     0x9be3b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9be3b8: ldur            x16, [fp, #-8]
    // 0x9be3bc: stp             x0, x16, [SP, #-0x10]!
    // 0x9be3c0: r0 = addActionListener()
    //     0x9be3c0: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9be3c4: add             SP, SP, #0x10
    // 0x9be3c8: r0 = Null
    //     0x9be3c8: mov             x0, NULL
    // 0x9be3cc: LeaveFrame
    //     0x9be3cc: mov             SP, fp
    //     0x9be3d0: ldp             fp, lr, [SP], #0x10
    // 0x9be3d4: ret
    //     0x9be3d4: ret             
    // 0x9be3d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9be3d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9be3dc: b               #0x9be2d8
    // 0x9be3e0: r9 = _valueIndicatorAnimation
    //     0x9be3e0: add             x9, PP, #0x57, lsl #12  ; [pp+0x57300] Field <_RenderValueIndicator@810231897._valueIndicatorAnimation@810231897>: late (offset: 0x60)
    //     0x9be3e4: ldr             x9, [x9, #0x300]
    // 0x9be3e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9be3e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9be3ec: r9 = positionController
    //     0x9be3ec: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0x9be3f0: ldr             x9, [x9, #0x838]
    // 0x9be3f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9be3f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69d00, size: 0x100
    // 0xa69d00: EnterFrame
    //     0xa69d00: stp             fp, lr, [SP, #-0x10]!
    //     0xa69d04: mov             fp, SP
    // 0xa69d08: AllocStack(0x8)
    //     0xa69d08: sub             SP, SP, #8
    // 0xa69d0c: CheckStackOverflow
    //     0xa69d0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69d10: cmp             SP, x16
    //     0xa69d14: b.ls            #0xa69de0
    // 0xa69d18: ldr             x0, [fp, #0x10]
    // 0xa69d1c: LoadField: r1 = r0->field_5f
    //     0xa69d1c: ldur            w1, [x0, #0x5f]
    // 0xa69d20: DecompressPointer r1
    //     0xa69d20: add             x1, x1, HEAP, lsl #32
    // 0xa69d24: r16 = Sentinel
    //     0xa69d24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69d28: cmp             w1, w16
    // 0xa69d2c: b.eq            #0xa69de8
    // 0xa69d30: stur            x1, [fp, #-8]
    // 0xa69d34: r1 = 1
    //     0xa69d34: mov             x1, #1
    // 0xa69d38: r0 = AllocateContext()
    //     0xa69d38: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69d3c: mov             x1, x0
    // 0xa69d40: ldr             x0, [fp, #0x10]
    // 0xa69d44: StoreField: r1->field_f = r0
    //     0xa69d44: stur            w0, [x1, #0xf]
    // 0xa69d48: mov             x2, x1
    // 0xa69d4c: r1 = Function 'markNeedsPaint':.
    //     0xa69d4c: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa69d50: ldr             x1, [x1, #0xf60]
    // 0xa69d54: r0 = AllocateClosure()
    //     0xa69d54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69d58: ldur            x16, [fp, #-8]
    // 0xa69d5c: stp             x0, x16, [SP, #-0x10]!
    // 0xa69d60: r0 = removeListener()
    //     0xa69d60: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0xa69d64: add             SP, SP, #0x10
    // 0xa69d68: ldr             x0, [fp, #0x10]
    // 0xa69d6c: LoadField: r1 = r0->field_63
    //     0xa69d6c: ldur            w1, [x0, #0x63]
    // 0xa69d70: DecompressPointer r1
    //     0xa69d70: add             x1, x1, HEAP, lsl #32
    // 0xa69d74: LoadField: r2 = r1->field_27
    //     0xa69d74: ldur            w2, [x1, #0x27]
    // 0xa69d78: DecompressPointer r2
    //     0xa69d78: add             x2, x2, HEAP, lsl #32
    // 0xa69d7c: r16 = Sentinel
    //     0xa69d7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69d80: cmp             w2, w16
    // 0xa69d84: b.eq            #0xa69df4
    // 0xa69d88: stur            x2, [fp, #-8]
    // 0xa69d8c: r1 = 1
    //     0xa69d8c: mov             x1, #1
    // 0xa69d90: r0 = AllocateContext()
    //     0xa69d90: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69d94: mov             x1, x0
    // 0xa69d98: ldr             x0, [fp, #0x10]
    // 0xa69d9c: StoreField: r1->field_f = r0
    //     0xa69d9c: stur            w0, [x1, #0xf]
    // 0xa69da0: mov             x2, x1
    // 0xa69da4: r1 = Function 'markNeedsPaint':.
    //     0xa69da4: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa69da8: ldr             x1, [x1, #0xf60]
    // 0xa69dac: r0 = AllocateClosure()
    //     0xa69dac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69db0: ldur            x16, [fp, #-8]
    // 0xa69db4: stp             x0, x16, [SP, #-0x10]!
    // 0xa69db8: r0 = removeListener()
    //     0xa69db8: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa69dbc: add             SP, SP, #0x10
    // 0xa69dc0: ldr             x16, [fp, #0x10]
    // 0xa69dc4: SaveReg r16
    //     0xa69dc4: str             x16, [SP, #-8]!
    // 0xa69dc8: r0 = detach()
    //     0xa69dc8: bl              #0xa69bec  ; [package:flutter/src/material/range_slider.dart] __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin::detach
    // 0xa69dcc: add             SP, SP, #8
    // 0xa69dd0: r0 = Null
    //     0xa69dd0: mov             x0, NULL
    // 0xa69dd4: LeaveFrame
    //     0xa69dd4: mov             SP, fp
    //     0xa69dd8: ldp             fp, lr, [SP], #0x10
    // 0xa69ddc: ret
    //     0xa69ddc: ret             
    // 0xa69de0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69de0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69de4: b               #0xa69d18
    // 0xa69de8: r9 = _valueIndicatorAnimation
    //     0xa69de8: add             x9, PP, #0x57, lsl #12  ; [pp+0x57300] Field <_RenderValueIndicator@810231897._valueIndicatorAnimation@810231897>: late (offset: 0x60)
    //     0xa69dec: ldr             x9, [x9, #0x300]
    // 0xa69df0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa69df0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa69df4: r9 = positionController
    //     0xa69df4: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0xa69df8: ldr             x9, [x9, #0x838]
    // 0xa69dfc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa69dfc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 2443, size: 0xd4, field offset: 0x60
class _RenderSlider extends __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin {

  late HorizontalDragGestureRecognizer _drag; // offset: 0x74
  late TapGestureRecognizer _tap; // offset: 0x78
  late Animation<double> _enableAnimation; // offset: 0x6c
  late Animation<double> _overlayAnimation; // offset: 0x64
  late Animation<double> _valueIndicatorAnimation; // offset: 0x68

  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x630f08, size: 0x18
    // 0x630f08: r4 = 0
    //     0x630f08: mov             x4, #0
    // 0x630f0c: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x630f0c: add             x17, PP, #0x56, lsl #12  ; [pp+0x56c18] AnonymousClosure: (0x630f20), in [package:flutter/src/material/slider.dart] _RenderSlider::computeMinIntrinsicHeight (0x630f6c)
    //     0x630f10: ldr             x1, [x17, #0xc18]
    // 0x630f14: r24 = BuildNonGenericMethodExtractorStub
    //     0x630f14: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x630f18: LoadField: r0 = r24->field_17
    //     0x630f18: ldur            x0, [x24, #0x17]
    // 0x630f1c: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x630f20, size: 0x4c
    // 0x630f20: EnterFrame
    //     0x630f20: stp             fp, lr, [SP, #-0x10]!
    //     0x630f24: mov             fp, SP
    // 0x630f28: ldr             x0, [fp, #0x18]
    // 0x630f2c: LoadField: r1 = r0->field_17
    //     0x630f2c: ldur            w1, [x0, #0x17]
    // 0x630f30: DecompressPointer r1
    //     0x630f30: add             x1, x1, HEAP, lsl #32
    // 0x630f34: CheckStackOverflow
    //     0x630f34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630f38: cmp             SP, x16
    //     0x630f3c: b.ls            #0x630f64
    // 0x630f40: LoadField: r0 = r1->field_f
    //     0x630f40: ldur            w0, [x1, #0xf]
    // 0x630f44: DecompressPointer r0
    //     0x630f44: add             x0, x0, HEAP, lsl #32
    // 0x630f48: ldr             x16, [fp, #0x10]
    // 0x630f4c: stp             x16, x0, [SP, #-0x10]!
    // 0x630f50: r0 = computeMinIntrinsicHeight()
    //     0x630f50: bl              #0x630f6c  ; [package:flutter/src/material/slider.dart] _RenderSlider::computeMinIntrinsicHeight
    // 0x630f54: add             SP, SP, #0x10
    // 0x630f58: LeaveFrame
    //     0x630f58: mov             SP, fp
    //     0x630f5c: ldp             fp, lr, [SP], #0x10
    // 0x630f60: ret
    //     0x630f60: ret             
    // 0x630f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x630f64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x630f68: b               #0x630f40
  }
  _ computeMinIntrinsicHeight(/* No info */) {
    // ** addr: 0x630f6c, size: 0xe8
    // 0x630f6c: EnterFrame
    //     0x630f6c: stp             fp, lr, [SP, #-0x10]!
    //     0x630f70: mov             fp, SP
    // 0x630f74: AllocStack(0x8)
    //     0x630f74: sub             SP, SP, #8
    // 0x630f78: CheckStackOverflow
    //     0x630f78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x630f7c: cmp             SP, x16
    //     0x630f80: b.ls            #0x631038
    // 0x630f84: ldr             x0, [fp, #0x18]
    // 0x630f88: LoadField: r1 = r0->field_a7
    //     0x630f88: ldur            w1, [x0, #0xa7]
    // 0x630f8c: DecompressPointer r1
    //     0x630f8c: add             x1, x1, HEAP, lsl #32
    // 0x630f90: LoadField: r2 = r1->field_7
    //     0x630f90: ldur            w2, [x1, #7]
    // 0x630f94: DecompressPointer r2
    //     0x630f94: add             x2, x2, HEAP, lsl #32
    // 0x630f98: stur            x2, [fp, #-8]
    // 0x630f9c: cmp             w2, NULL
    // 0x630fa0: b.eq            #0x631040
    // 0x630fa4: SaveReg r0
    //     0x630fa4: str             x0, [SP, #-8]!
    // 0x630fa8: r0 = _maxSliderPartHeight()
    //     0x630fa8: bl              #0x6310a0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartHeight
    // 0x630fac: add             SP, SP, #8
    // 0x630fb0: ldur            x1, [fp, #-8]
    // 0x630fb4: LoadField: d1 = r1->field_7
    //     0x630fb4: ldur            d1, [x1, #7]
    // 0x630fb8: fcmp            d1, d0
    // 0x630fbc: b.vs            #0x630fd0
    // 0x630fc0: b.le            #0x630fd0
    // 0x630fc4: LoadField: d2 = r1->field_7
    //     0x630fc4: ldur            d2, [x1, #7]
    // 0x630fc8: mov             v0.16b, v2.16b
    // 0x630fcc: b               #0x631004
    // 0x630fd0: fcmp            d1, d0
    // 0x630fd4: b.vs            #0x630fdc
    // 0x630fd8: b.lt            #0x631004
    // 0x630fdc: d2 = 0.000000
    //     0x630fdc: eor             v2.16b, v2.16b, v2.16b
    // 0x630fe0: fcmp            d1, d2
    // 0x630fe4: b.vs            #0x630ff8
    // 0x630fe8: b.ne            #0x630ff8
    // 0x630fec: fadd            d2, d1, d0
    // 0x630ff0: mov             v0.16b, v2.16b
    // 0x630ff4: b               #0x631004
    // 0x630ff8: fcmp            d0, d0
    // 0x630ffc: b.vs            #0x631004
    // 0x631000: LoadField: d0 = r1->field_7
    //     0x631000: ldur            d0, [x1, #7]
    // 0x631004: r0 = inline_Allocate_Double()
    //     0x631004: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x631008: add             x0, x0, #0x10
    //     0x63100c: cmp             x1, x0
    //     0x631010: b.ls            #0x631044
    //     0x631014: str             x0, [THR, #0x60]  ; THR::top
    //     0x631018: sub             x0, x0, #0xf
    //     0x63101c: mov             x1, #0xd108
    //     0x631020: movk            x1, #3, lsl #16
    //     0x631024: stur            x1, [x0, #-1]
    // 0x631028: StoreField: r0->field_7 = d0
    //     0x631028: stur            d0, [x0, #7]
    // 0x63102c: LeaveFrame
    //     0x63102c: mov             SP, fp
    //     0x631030: ldp             fp, lr, [SP], #0x10
    // 0x631034: ret
    //     0x631034: ret             
    // 0x631038: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x631038: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63103c: b               #0x630f84
    // 0x631040: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x631040: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x631044: SaveReg d0
    //     0x631044: str             q0, [SP, #-0x10]!
    // 0x631048: r0 = AllocateDouble()
    //     0x631048: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63104c: RestoreReg d0
    //     0x63104c: ldr             q0, [SP], #0x10
    // 0x631050: b               #0x631028
  }
  [closure] double computeMinIntrinsicHeight(dynamic, double) {
    // ** addr: 0x631054, size: 0x4c
    // 0x631054: EnterFrame
    //     0x631054: stp             fp, lr, [SP, #-0x10]!
    //     0x631058: mov             fp, SP
    // 0x63105c: ldr             x0, [fp, #0x18]
    // 0x631060: LoadField: r1 = r0->field_17
    //     0x631060: ldur            w1, [x0, #0x17]
    // 0x631064: DecompressPointer r1
    //     0x631064: add             x1, x1, HEAP, lsl #32
    // 0x631068: CheckStackOverflow
    //     0x631068: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63106c: cmp             SP, x16
    //     0x631070: b.ls            #0x631098
    // 0x631074: LoadField: r0 = r1->field_f
    //     0x631074: ldur            w0, [x1, #0xf]
    // 0x631078: DecompressPointer r0
    //     0x631078: add             x0, x0, HEAP, lsl #32
    // 0x63107c: ldr             x16, [fp, #0x10]
    // 0x631080: stp             x16, x0, [SP, #-0x10]!
    // 0x631084: r0 = computeMinIntrinsicHeight()
    //     0x631084: bl              #0x630f6c  ; [package:flutter/src/material/slider.dart] _RenderSlider::computeMinIntrinsicHeight
    // 0x631088: add             SP, SP, #0x10
    // 0x63108c: LeaveFrame
    //     0x63108c: mov             SP, fp
    //     0x631090: ldp             fp, lr, [SP], #0x10
    // 0x631094: ret
    //     0x631094: ret             
    // 0x631098: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x631098: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63109c: b               #0x631074
  }
  get _ _maxSliderPartHeight(/* No info */) {
    // ** addr: 0x6310a0, size: 0x84
    // 0x6310a0: EnterFrame
    //     0x6310a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6310a4: mov             fp, SP
    // 0x6310a8: AllocStack(0x8)
    //     0x6310a8: sub             SP, SP, #8
    // 0x6310ac: CheckStackOverflow
    //     0x6310ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6310b0: cmp             SP, x16
    //     0x6310b4: b.ls            #0x63111c
    // 0x6310b8: ldr             x16, [fp, #0x10]
    // 0x6310bc: SaveReg r16
    //     0x6310bc: str             x16, [SP, #-8]!
    // 0x6310c0: r0 = _sliderPartSizes()
    //     0x6310c0: bl              #0x631318  ; [package:flutter/src/material/slider.dart] _RenderSlider::_sliderPartSizes
    // 0x6310c4: add             SP, SP, #8
    // 0x6310c8: r1 = Function '<anonymous closure>':.
    //     0x6310c8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56c20] AnonymousClosure: (0x6314f8), in [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartHeight (0x6310a0)
    //     0x6310cc: ldr             x1, [x1, #0xc20]
    // 0x6310d0: r2 = Null
    //     0x6310d0: mov             x2, NULL
    // 0x6310d4: stur            x0, [fp, #-8]
    // 0x6310d8: r0 = AllocateClosure()
    //     0x6310d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6310dc: r16 = <double>
    //     0x6310dc: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6310e0: ldur            lr, [fp, #-8]
    // 0x6310e4: stp             lr, x16, [SP, #-0x10]!
    // 0x6310e8: SaveReg r0
    //     0x6310e8: str             x0, [SP, #-8]!
    // 0x6310ec: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x6310ec: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x6310f0: r0 = map()
    //     0x6310f0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x6310f4: add             SP, SP, #0x18
    // 0x6310f8: r16 = Closure: (double, double) => double from Function 'max': static.
    //     0x6310f8: add             x16, PP, #0x43, lsl #12  ; [pp+0x432d0] Closure: (double, double) => double from Function 'max': static. (0x7fe6e1d21dd0)
    //     0x6310fc: ldr             x16, [x16, #0x2d0]
    // 0x631100: stp             x16, x0, [SP, #-0x10]!
    // 0x631104: r0 = reduce()
    //     0x631104: bl              #0x631124  ; [dart:_internal] ListIterable::reduce
    // 0x631108: add             SP, SP, #0x10
    // 0x63110c: LoadField: d0 = r0->field_7
    //     0x63110c: ldur            d0, [x0, #7]
    // 0x631110: LeaveFrame
    //     0x631110: mov             SP, fp
    //     0x631114: ldp             fp, lr, [SP], #0x10
    // 0x631118: ret
    //     0x631118: ret             
    // 0x63111c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63111c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x631120: b               #0x6310b8
  }
  get _ _sliderPartSizes(/* No info */) {
    // ** addr: 0x631318, size: 0x13c
    // 0x631318: EnterFrame
    //     0x631318: stp             fp, lr, [SP, #-0x10]!
    //     0x63131c: mov             fp, SP
    // 0x631320: AllocStack(0x20)
    //     0x631320: sub             SP, SP, #0x20
    // 0x631324: CheckStackOverflow
    //     0x631324: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x631328: cmp             SP, x16
    //     0x63132c: b.ls            #0x631440
    // 0x631330: ldr             x0, [fp, #0x10]
    // 0x631334: LoadField: r1 = r0->field_a7
    //     0x631334: ldur            w1, [x0, #0xa7]
    // 0x631338: DecompressPointer r1
    //     0x631338: add             x1, x1, HEAP, lsl #32
    // 0x63133c: LoadField: r2 = r1->field_47
    //     0x63133c: ldur            w2, [x1, #0x47]
    // 0x631340: DecompressPointer r2
    //     0x631340: add             x2, x2, HEAP, lsl #32
    // 0x631344: cmp             w2, NULL
    // 0x631348: b.eq            #0x631448
    // 0x63134c: LoadField: r1 = r0->field_b7
    //     0x63134c: ldur            w1, [x0, #0xb7]
    // 0x631350: DecompressPointer r1
    //     0x631350: add             x1, x1, HEAP, lsl #32
    // 0x631354: cmp             w1, NULL
    // 0x631358: r16 = true
    //     0x631358: add             x16, NULL, #0x20  ; true
    // 0x63135c: r17 = false
    //     0x63135c: add             x17, NULL, #0x30  ; false
    // 0x631360: csel            x3, x16, x17, ne
    // 0x631364: stp             x3, x2, [SP, #-0x10]!
    // 0x631368: r0 = getPreferredSize()
    //     0x631368: bl              #0x6314d0  ; [package:flutter/src/material/slider_theme.dart] RoundSliderOverlayShape::getPreferredSize
    // 0x63136c: add             SP, SP, #0x10
    // 0x631370: mov             x1, x0
    // 0x631374: ldr             x0, [fp, #0x10]
    // 0x631378: stur            x1, [fp, #-8]
    // 0x63137c: LoadField: r2 = r0->field_a7
    //     0x63137c: ldur            w2, [x0, #0xa7]
    // 0x631380: DecompressPointer r2
    //     0x631380: add             x2, x2, HEAP, lsl #32
    // 0x631384: LoadField: r3 = r2->field_4f
    //     0x631384: ldur            w3, [x2, #0x4f]
    // 0x631388: DecompressPointer r3
    //     0x631388: add             x3, x3, HEAP, lsl #32
    // 0x63138c: cmp             w3, NULL
    // 0x631390: b.eq            #0x63144c
    // 0x631394: LoadField: r2 = r0->field_b7
    //     0x631394: ldur            w2, [x0, #0xb7]
    // 0x631398: DecompressPointer r2
    //     0x631398: add             x2, x2, HEAP, lsl #32
    // 0x63139c: cmp             w2, NULL
    // 0x6313a0: r16 = true
    //     0x6313a0: add             x16, NULL, #0x20  ; true
    // 0x6313a4: r17 = false
    //     0x6313a4: add             x17, NULL, #0x30  ; false
    // 0x6313a8: csel            x4, x16, x17, ne
    // 0x6313ac: stp             x4, x3, [SP, #-0x10]!
    // 0x6313b0: r0 = getPreferredSize()
    //     0x6313b0: bl              #0x6314ac  ; [package:flutter/src/material/slider_theme.dart] RoundSliderThumbShape::getPreferredSize
    // 0x6313b4: add             SP, SP, #0x10
    // 0x6313b8: mov             x1, x0
    // 0x6313bc: ldr             x0, [fp, #0x10]
    // 0x6313c0: stur            x1, [fp, #-0x10]
    // 0x6313c4: LoadField: r2 = r0->field_a7
    //     0x6313c4: ldur            w2, [x0, #0xa7]
    // 0x6313c8: DecompressPointer r2
    //     0x6313c8: add             x2, x2, HEAP, lsl #32
    // 0x6313cc: LoadField: r0 = r2->field_4b
    //     0x6313cc: ldur            w0, [x2, #0x4b]
    // 0x6313d0: DecompressPointer r0
    //     0x6313d0: add             x0, x0, HEAP, lsl #32
    // 0x6313d4: cmp             w0, NULL
    // 0x6313d8: b.eq            #0x631450
    // 0x6313dc: stp             x2, x0, [SP, #-0x10]!
    // 0x6313e0: r0 = getPreferredSize()
    //     0x6313e0: bl              #0x631454  ; [package:flutter/src/material/slider_theme.dart] RoundSliderTickMarkShape::getPreferredSize
    // 0x6313e4: add             SP, SP, #0x10
    // 0x6313e8: r1 = Null
    //     0x6313e8: mov             x1, NULL
    // 0x6313ec: r2 = 6
    //     0x6313ec: mov             x2, #6
    // 0x6313f0: stur            x0, [fp, #-0x18]
    // 0x6313f4: r0 = AllocateArray()
    //     0x6313f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6313f8: mov             x2, x0
    // 0x6313fc: ldur            x0, [fp, #-8]
    // 0x631400: stur            x2, [fp, #-0x20]
    // 0x631404: StoreField: r2->field_f = r0
    //     0x631404: stur            w0, [x2, #0xf]
    // 0x631408: ldur            x0, [fp, #-0x10]
    // 0x63140c: StoreField: r2->field_13 = r0
    //     0x63140c: stur            w0, [x2, #0x13]
    // 0x631410: ldur            x0, [fp, #-0x18]
    // 0x631414: StoreField: r2->field_17 = r0
    //     0x631414: stur            w0, [x2, #0x17]
    // 0x631418: r1 = <Size>
    //     0x631418: add             x1, PP, #0x26, lsl #12  ; [pp+0x268d0] TypeArguments: <Size>
    //     0x63141c: ldr             x1, [x1, #0x8d0]
    // 0x631420: r0 = AllocateGrowableArray()
    //     0x631420: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x631424: ldur            x1, [fp, #-0x20]
    // 0x631428: StoreField: r0->field_f = r1
    //     0x631428: stur            w1, [x0, #0xf]
    // 0x63142c: r1 = 6
    //     0x63142c: mov             x1, #6
    // 0x631430: StoreField: r0->field_b = r1
    //     0x631430: stur            w1, [x0, #0xb]
    // 0x631434: LeaveFrame
    //     0x631434: mov             SP, fp
    //     0x631438: ldp             fp, lr, [SP], #0x10
    // 0x63143c: ret
    //     0x63143c: ret             
    // 0x631440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x631440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x631444: b               #0x631330
    // 0x631448: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x631448: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63144c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63144c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x631450: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x631450: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic, Size) {
    // ** addr: 0x6314f8, size: 0x54
    // 0x6314f8: EnterFrame
    //     0x6314f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6314fc: mov             fp, SP
    // 0x631500: ldr             x1, [fp, #0x10]
    // 0x631504: LoadField: d0 = r1->field_f
    //     0x631504: ldur            d0, [x1, #0xf]
    // 0x631508: r0 = inline_Allocate_Double()
    //     0x631508: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63150c: add             x0, x0, #0x10
    //     0x631510: cmp             x1, x0
    //     0x631514: b.ls            #0x63153c
    //     0x631518: str             x0, [THR, #0x60]  ; THR::top
    //     0x63151c: sub             x0, x0, #0xf
    //     0x631520: mov             x1, #0xd108
    //     0x631524: movk            x1, #3, lsl #16
    //     0x631528: stur            x1, [x0, #-1]
    // 0x63152c: StoreField: r0->field_7 = d0
    //     0x63152c: stur            d0, [x0, #7]
    // 0x631530: LeaveFrame
    //     0x631530: mov             SP, fp
    //     0x631534: ldp             fp, lr, [SP], #0x10
    // 0x631538: ret
    //     0x631538: ret             
    // 0x63153c: SaveReg d0
    //     0x63153c: str             q0, [SP, #-0x10]!
    // 0x631540: r0 = AllocateDouble()
    //     0x631540: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x631544: RestoreReg d0
    //     0x631544: ldr             q0, [SP], #0x10
    // 0x631548: b               #0x63152c
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x636af4, size: 0x18
    // 0x636af4: r4 = 0
    //     0x636af4: mov             x4, #0
    // 0x636af8: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x636af8: add             x17, PP, #0x56, lsl #12  ; [pp+0x56c30] AnonymousClosure: (0x636b0c), of [package:flutter/src/material/slider.dart] _RenderSlider
    //     0x636afc: ldr             x1, [x17, #0xc30]
    // 0x636b00: r24 = BuildNonGenericMethodExtractorStub
    //     0x636b00: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x636b04: LoadField: r0 = r24->field_17
    //     0x636b04: ldur            x0, [x24, #0x17]
    // 0x636b08: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x636b0c, size: 0x90
    // 0x636b0c: EnterFrame
    //     0x636b0c: stp             fp, lr, [SP, #-0x10]!
    //     0x636b10: mov             fp, SP
    // 0x636b14: ldr             x0, [fp, #0x18]
    // 0x636b18: LoadField: r1 = r0->field_17
    //     0x636b18: ldur            w1, [x0, #0x17]
    // 0x636b1c: DecompressPointer r1
    //     0x636b1c: add             x1, x1, HEAP, lsl #32
    // 0x636b20: CheckStackOverflow
    //     0x636b20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636b24: cmp             SP, x16
    //     0x636b28: b.ls            #0x636b84
    // 0x636b2c: LoadField: r0 = r1->field_f
    //     0x636b2c: ldur            w0, [x1, #0xf]
    // 0x636b30: DecompressPointer r0
    //     0x636b30: add             x0, x0, HEAP, lsl #32
    // 0x636b34: SaveReg r0
    //     0x636b34: str             x0, [SP, #-8]!
    // 0x636b38: r0 = _maxSliderPartWidth()
    //     0x636b38: bl              #0x636b9c  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartWidth
    // 0x636b3c: add             SP, SP, #8
    // 0x636b40: mov             v1.16b, v0.16b
    // 0x636b44: d0 = 144.000000
    //     0x636b44: add             x17, PP, #0x56, lsl #12  ; [pp+0x56c38] IMM: double(144) from 0x4062000000000000
    //     0x636b48: ldr             d0, [x17, #0xc38]
    // 0x636b4c: fadd            d2, d0, d1
    // 0x636b50: r0 = inline_Allocate_Double()
    //     0x636b50: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x636b54: add             x0, x0, #0x10
    //     0x636b58: cmp             x1, x0
    //     0x636b5c: b.ls            #0x636b8c
    //     0x636b60: str             x0, [THR, #0x60]  ; THR::top
    //     0x636b64: sub             x0, x0, #0xf
    //     0x636b68: mov             x1, #0xd108
    //     0x636b6c: movk            x1, #3, lsl #16
    //     0x636b70: stur            x1, [x0, #-1]
    // 0x636b74: StoreField: r0->field_7 = d2
    //     0x636b74: stur            d2, [x0, #7]
    // 0x636b78: LeaveFrame
    //     0x636b78: mov             SP, fp
    //     0x636b7c: ldp             fp, lr, [SP], #0x10
    // 0x636b80: ret
    //     0x636b80: ret             
    // 0x636b84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636b84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636b88: b               #0x636b2c
    // 0x636b8c: SaveReg d2
    //     0x636b8c: str             q2, [SP, #-0x10]!
    // 0x636b90: r0 = AllocateDouble()
    //     0x636b90: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x636b94: RestoreReg d2
    //     0x636b94: ldr             q2, [SP], #0x10
    // 0x636b98: b               #0x636b74
  }
  get _ _maxSliderPartWidth(/* No info */) {
    // ** addr: 0x636b9c, size: 0x84
    // 0x636b9c: EnterFrame
    //     0x636b9c: stp             fp, lr, [SP, #-0x10]!
    //     0x636ba0: mov             fp, SP
    // 0x636ba4: AllocStack(0x8)
    //     0x636ba4: sub             SP, SP, #8
    // 0x636ba8: CheckStackOverflow
    //     0x636ba8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x636bac: cmp             SP, x16
    //     0x636bb0: b.ls            #0x636c18
    // 0x636bb4: ldr             x16, [fp, #0x10]
    // 0x636bb8: SaveReg r16
    //     0x636bb8: str             x16, [SP, #-8]!
    // 0x636bbc: r0 = _sliderPartSizes()
    //     0x636bbc: bl              #0x631318  ; [package:flutter/src/material/slider.dart] _RenderSlider::_sliderPartSizes
    // 0x636bc0: add             SP, SP, #8
    // 0x636bc4: r1 = Function '<anonymous closure>':.
    //     0x636bc4: add             x1, PP, #0x56, lsl #12  ; [pp+0x56c40] AnonymousClosure: (0xc43158), in [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartWidth (0x636b9c)
    //     0x636bc8: ldr             x1, [x1, #0xc40]
    // 0x636bcc: r2 = Null
    //     0x636bcc: mov             x2, NULL
    // 0x636bd0: stur            x0, [fp, #-8]
    // 0x636bd4: r0 = AllocateClosure()
    //     0x636bd4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x636bd8: r16 = <double>
    //     0x636bd8: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x636bdc: ldur            lr, [fp, #-8]
    // 0x636be0: stp             lr, x16, [SP, #-0x10]!
    // 0x636be4: SaveReg r0
    //     0x636be4: str             x0, [SP, #-8]!
    // 0x636be8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x636be8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x636bec: r0 = map()
    //     0x636bec: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x636bf0: add             SP, SP, #0x18
    // 0x636bf4: r16 = Closure: (double, double) => double from Function 'max': static.
    //     0x636bf4: add             x16, PP, #0x43, lsl #12  ; [pp+0x432d0] Closure: (double, double) => double from Function 'max': static. (0x7fe6e1d21dd0)
    //     0x636bf8: ldr             x16, [x16, #0x2d0]
    // 0x636bfc: stp             x16, x0, [SP, #-0x10]!
    // 0x636c00: r0 = reduce()
    //     0x636c00: bl              #0x631124  ; [dart:_internal] ListIterable::reduce
    // 0x636c04: add             SP, SP, #0x10
    // 0x636c08: LoadField: d0 = r0->field_7
    //     0x636c08: ldur            d0, [x0, #7]
    // 0x636c0c: LeaveFrame
    //     0x636c0c: mov             SP, fp
    //     0x636c10: ldp             fp, lr, [SP], #0x10
    // 0x636c14: ret
    //     0x636c14: ret             
    // 0x636c18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x636c18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x636c1c: b               #0x636bb4
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x639598, size: 0x18
    // 0x639598: r4 = 0
    //     0x639598: mov             x4, #0
    // 0x63959c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x63959c: add             x17, PP, #0x56, lsl #12  ; [pp+0x56c28] AnonymousClosure: (0x631054), in [package:flutter/src/material/slider.dart] _RenderSlider::computeMinIntrinsicHeight (0x630f6c)
    //     0x6395a0: ldr             x1, [x17, #0xc28]
    // 0x6395a4: r24 = BuildNonGenericMethodExtractorStub
    //     0x6395a4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6395a8: LoadField: r0 = r24->field_17
    //     0x6395a8: ldur            x0, [x24, #0x17]
    // 0x6395ac: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63c7c8, size: 0x18
    // 0x63c7c8: r4 = 0
    //     0x63c7c8: mov             x4, #0
    // 0x63c7cc: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63c7cc: add             x17, PP, #0x56, lsl #12  ; [pp+0x56c48] AnonymousClosure: (0x636b0c), of [package:flutter/src/material/slider.dart] _RenderSlider
    //     0x63c7d0: ldr             x1, [x17, #0xc48]
    // 0x63c7d4: r24 = BuildNonGenericMethodExtractorStub
    //     0x63c7d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63c7d8: LoadField: r0 = r24->field_17
    //     0x63c7d8: ldur            x0, [x24, #0x17]
    // 0x63c7dc: br              x0
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x650500, size: 0x4e8
    // 0x650500: EnterFrame
    //     0x650500: stp             fp, lr, [SP, #-0x10]!
    //     0x650504: mov             fp, SP
    // 0x650508: AllocStack(0x10)
    //     0x650508: sub             SP, SP, #0x10
    // 0x65050c: r0 = false
    //     0x65050c: add             x0, NULL, #0x30  ; false
    // 0x650510: CheckStackOverflow
    //     0x650510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x650514: cmp             SP, x16
    //     0x650518: b.ls            #0x65098c
    // 0x65051c: ldr             x1, [fp, #0x10]
    // 0x650520: StoreField: r1->field_7 = r0
    //     0x650520: stur            w0, [x1, #7]
    // 0x650524: ldr             x0, [fp, #0x18]
    // 0x650528: LoadField: r2 = r0->field_b7
    //     0x650528: ldur            w2, [x0, #0xb7]
    // 0x65052c: DecompressPointer r2
    //     0x65052c: add             x2, x2, HEAP, lsl #32
    // 0x650530: cmp             w2, NULL
    // 0x650534: r16 = true
    //     0x650534: add             x16, NULL, #0x20  ; true
    // 0x650538: r17 = false
    //     0x650538: add             x17, NULL, #0x30  ; false
    // 0x65053c: csel            x3, x16, x17, ne
    // 0x650540: stp             x3, x1, [SP, #-0x10]!
    // 0x650544: r0 = isEnabled=()
    //     0x650544: bl              #0x64fb68  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::isEnabled=
    // 0x650548: add             SP, SP, #0x10
    // 0x65054c: ldr             x1, [fp, #0x18]
    // 0x650550: LoadField: r0 = r1->field_c3
    //     0x650550: ldur            w0, [x1, #0xc3]
    // 0x650554: DecompressPointer r0
    //     0x650554: add             x0, x0, HEAP, lsl #32
    // 0x650558: ldr             x2, [fp, #0x10]
    // 0x65055c: StoreField: r2->field_73 = r0
    //     0x65055c: stur            w0, [x2, #0x73]
    //     0x650560: ldurb           w16, [x2, #-1]
    //     0x650564: ldurb           w17, [x0, #-1]
    //     0x650568: and             x16, x17, x16, lsr #2
    //     0x65056c: tst             x16, HEAP, lsr #32
    //     0x650570: b.eq            #0x650578
    //     0x650574: bl              #0xd6828c
    // 0x650578: r0 = true
    //     0x650578: add             x0, NULL, #0x20  ; true
    // 0x65057c: StoreField: r2->field_13 = r0
    //     0x65057c: stur            w0, [x2, #0x13]
    // 0x650580: LoadField: r3 = r1->field_b7
    //     0x650580: ldur            w3, [x1, #0xb7]
    // 0x650584: DecompressPointer r3
    //     0x650584: add             x3, x3, HEAP, lsl #32
    // 0x650588: cmp             w3, NULL
    // 0x65058c: b.eq            #0x650610
    // 0x650590: r1 = 1
    //     0x650590: mov             x1, #1
    // 0x650594: r0 = AllocateContext()
    //     0x650594: bl              #0xd68aa4  ; AllocateContextStub
    // 0x650598: mov             x1, x0
    // 0x65059c: ldr             x0, [fp, #0x18]
    // 0x6505a0: StoreField: r1->field_f = r0
    //     0x6505a0: stur            w0, [x1, #0xf]
    // 0x6505a4: mov             x2, x1
    // 0x6505a8: r1 = Function 'increaseAction':.
    //     0x6505a8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56c50] AnonymousClosure: (0x650b98), in [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction (0x650be0)
    //     0x6505ac: ldr             x1, [x1, #0xc50]
    // 0x6505b0: r0 = AllocateClosure()
    //     0x6505b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6505b4: ldr             x16, [fp, #0x10]
    // 0x6505b8: r30 = Instance_SemanticsAction
    //     0x6505b8: add             lr, PP, #0x56, lsl #12  ; [pp+0x560b8] Obj!SemanticsAction@b5cda1
    //     0x6505bc: ldr             lr, [lr, #0xb8]
    // 0x6505c0: stp             lr, x16, [SP, #-0x10]!
    // 0x6505c4: SaveReg r0
    //     0x6505c4: str             x0, [SP, #-8]!
    // 0x6505c8: r0 = _addArgumentlessAction()
    //     0x6505c8: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x6505cc: add             SP, SP, #0x18
    // 0x6505d0: r1 = 1
    //     0x6505d0: mov             x1, #1
    // 0x6505d4: r0 = AllocateContext()
    //     0x6505d4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6505d8: mov             x1, x0
    // 0x6505dc: ldr             x0, [fp, #0x18]
    // 0x6505e0: StoreField: r1->field_f = r0
    //     0x6505e0: stur            w0, [x1, #0xf]
    // 0x6505e4: mov             x2, x1
    // 0x6505e8: r1 = Function 'decreaseAction':.
    //     0x6505e8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56c58] AnonymousClosure: (0x650a50), in [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction (0x650a98)
    //     0x6505ec: ldr             x1, [x1, #0xc58]
    // 0x6505f0: r0 = AllocateClosure()
    //     0x6505f0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6505f4: ldr             x16, [fp, #0x10]
    // 0x6505f8: r30 = Instance_SemanticsAction
    //     0x6505f8: add             lr, PP, #0x56, lsl #12  ; [pp+0x560c8] Obj!SemanticsAction@b5cd91
    //     0x6505fc: ldr             lr, [lr, #0xc8]
    // 0x650600: stp             lr, x16, [SP, #-0x10]!
    // 0x650604: SaveReg r0
    //     0x650604: str             x0, [SP, #-8]!
    // 0x650608: r0 = _addArgumentlessAction()
    //     0x650608: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x65060c: add             SP, SP, #0x18
    // 0x650610: ldr             x0, [fp, #0x18]
    // 0x650614: ldr             x1, [fp, #0x10]
    // 0x650618: d1 = 100.000000
    //     0x650618: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x65061c: ldr             d1, [x17, #0x308]
    // 0x650620: LoadField: d0 = r0->field_8b
    //     0x650620: ldur            d0, [x0, #0x8b]
    // 0x650624: fmul            d2, d0, d1
    // 0x650628: mov             v0.16b, v2.16b
    // 0x65062c: stp             fp, lr, [SP, #-0x10]!
    // 0x650630: mov             fp, SP
    // 0x650634: CallRuntime_LibcRound(double) -> double
    //     0x650634: and             SP, SP, #0xfffffffffffffff0
    //     0x650638: mov             sp, SP
    //     0x65063c: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x650640: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x650644: blr             x16
    //     0x650648: mov             x16, #8
    //     0x65064c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x650650: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x650654: sub             sp, x16, #1, lsl #12
    //     0x650658: mov             SP, fp
    //     0x65065c: ldp             fp, lr, [SP], #0x10
    // 0x650660: fcmp            d0, d0
    // 0x650664: b.vs            #0x650994
    // 0x650668: fcvtzs          x0, d0
    // 0x65066c: asr             x16, x0, #0x1e
    // 0x650670: cmp             x16, x0, asr #63
    // 0x650674: b.ne            #0x650994
    // 0x650678: lsl             x0, x0, #1
    // 0x65067c: stur            x0, [fp, #-8]
    // 0x650680: r1 = Null
    //     0x650680: mov             x1, NULL
    // 0x650684: r2 = 4
    //     0x650684: mov             x2, #4
    // 0x650688: r0 = AllocateArray()
    //     0x650688: bl              #0xd6987c  ; AllocateArrayStub
    // 0x65068c: mov             x1, x0
    // 0x650690: ldur            x0, [fp, #-8]
    // 0x650694: StoreField: r1->field_f = r0
    //     0x650694: stur            w0, [x1, #0xf]
    // 0x650698: r17 = "%"
    //     0x650698: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x65069c: StoreField: r1->field_13 = r17
    //     0x65069c: stur            w17, [x1, #0x13]
    // 0x6506a0: SaveReg r1
    //     0x6506a0: str             x1, [SP, #-8]!
    // 0x6506a4: r0 = _interpolate()
    //     0x6506a4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x6506a8: add             SP, SP, #8
    // 0x6506ac: stur            x0, [fp, #-8]
    // 0x6506b0: r0 = AttributedString()
    //     0x6506b0: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x6506b4: mov             x1, x0
    // 0x6506b8: ldur            x0, [fp, #-8]
    // 0x6506bc: StoreField: r1->field_7 = r0
    //     0x6506bc: stur            w0, [x1, #7]
    // 0x6506c0: r2 = const []
    //     0x6506c0: ldr             x2, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x6506c4: StoreField: r1->field_b = r2
    //     0x6506c4: stur            w2, [x1, #0xb]
    // 0x6506c8: mov             x0, x1
    // 0x6506cc: ldr             x1, [fp, #0x10]
    // 0x6506d0: StoreField: r1->field_4b = r0
    //     0x6506d0: stur            w0, [x1, #0x4b]
    //     0x6506d4: ldurb           w16, [x1, #-1]
    //     0x6506d8: ldurb           w17, [x0, #-1]
    //     0x6506dc: and             x16, x17, x16, lsr #2
    //     0x6506e0: tst             x16, HEAP, lsr #32
    //     0x6506e4: b.eq            #0x6506ec
    //     0x6506e8: bl              #0xd6826c
    // 0x6506ec: r0 = true
    //     0x6506ec: add             x0, NULL, #0x20  ; true
    // 0x6506f0: StoreField: r1->field_13 = r0
    //     0x6506f0: stur            w0, [x1, #0x13]
    // 0x6506f4: ldr             x3, [fp, #0x18]
    // 0x6506f8: LoadField: d0 = r3->field_8b
    //     0x6506f8: ldur            d0, [x3, #0x8b]
    // 0x6506fc: stur            d0, [fp, #-0x10]
    // 0x650700: SaveReg r3
    //     0x650700: str             x3, [SP, #-8]!
    // 0x650704: r0 = _semanticActionUnit()
    //     0x650704: bl              #0x650a08  ; [package:flutter/src/material/slider.dart] _RenderSlider::_semanticActionUnit
    // 0x650708: add             SP, SP, #8
    // 0x65070c: mov             v1.16b, v0.16b
    // 0x650710: ldur            d0, [fp, #-0x10]
    // 0x650714: fadd            d2, d0, d1
    // 0x650718: d1 = 0.000000
    //     0x650718: eor             v1.16b, v1.16b, v1.16b
    // 0x65071c: fcmp            d2, d1
    // 0x650720: b.vs            #0x650734
    // 0x650724: b.ge            #0x650734
    // 0x650728: d0 = 0.000000
    //     0x650728: eor             v0.16b, v0.16b, v0.16b
    // 0x65072c: d3 = 1.000000
    //     0x65072c: fmov            d3, #1.00000000
    // 0x650730: b               #0x650760
    // 0x650734: d3 = 1.000000
    //     0x650734: fmov            d3, #1.00000000
    // 0x650738: fcmp            d2, d3
    // 0x65073c: b.vs            #0x65074c
    // 0x650740: b.le            #0x65074c
    // 0x650744: d0 = 1.000000
    //     0x650744: fmov            d0, #1.00000000
    // 0x650748: b               #0x650760
    // 0x65074c: fcmp            d2, d2
    // 0x650750: b.vc            #0x65075c
    // 0x650754: d0 = 1.000000
    //     0x650754: fmov            d0, #1.00000000
    // 0x650758: b               #0x650760
    // 0x65075c: mov             v0.16b, v2.16b
    // 0x650760: ldr             x1, [fp, #0x18]
    // 0x650764: ldr             x0, [fp, #0x10]
    // 0x650768: d2 = 100.000000
    //     0x650768: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x65076c: ldr             d2, [x17, #0x308]
    // 0x650770: fmul            d4, d0, d2
    // 0x650774: mov             v0.16b, v4.16b
    // 0x650778: stp             fp, lr, [SP, #-0x10]!
    // 0x65077c: mov             fp, SP
    // 0x650780: CallRuntime_LibcRound(double) -> double
    //     0x650780: and             SP, SP, #0xfffffffffffffff0
    //     0x650784: mov             sp, SP
    //     0x650788: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x65078c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x650790: blr             x16
    //     0x650794: mov             x16, #8
    //     0x650798: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x65079c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x6507a0: sub             sp, x16, #1, lsl #12
    //     0x6507a4: mov             SP, fp
    //     0x6507a8: ldp             fp, lr, [SP], #0x10
    // 0x6507ac: fcmp            d0, d0
    // 0x6507b0: b.vs            #0x6509b0
    // 0x6507b4: fcvtzs          x0, d0
    // 0x6507b8: asr             x16, x0, #0x1e
    // 0x6507bc: cmp             x16, x0, asr #63
    // 0x6507c0: b.ne            #0x6509b0
    // 0x6507c4: lsl             x0, x0, #1
    // 0x6507c8: stur            x0, [fp, #-8]
    // 0x6507cc: r1 = Null
    //     0x6507cc: mov             x1, NULL
    // 0x6507d0: r2 = 4
    //     0x6507d0: mov             x2, #4
    // 0x6507d4: r0 = AllocateArray()
    //     0x6507d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6507d8: mov             x1, x0
    // 0x6507dc: ldur            x0, [fp, #-8]
    // 0x6507e0: StoreField: r1->field_f = r0
    //     0x6507e0: stur            w0, [x1, #0xf]
    // 0x6507e4: r17 = "%"
    //     0x6507e4: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x6507e8: StoreField: r1->field_13 = r17
    //     0x6507e8: stur            w17, [x1, #0x13]
    // 0x6507ec: SaveReg r1
    //     0x6507ec: str             x1, [SP, #-8]!
    // 0x6507f0: r0 = _interpolate()
    //     0x6507f0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x6507f4: add             SP, SP, #8
    // 0x6507f8: stur            x0, [fp, #-8]
    // 0x6507fc: r0 = AttributedString()
    //     0x6507fc: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x650800: mov             x1, x0
    // 0x650804: ldur            x0, [fp, #-8]
    // 0x650808: StoreField: r1->field_7 = r0
    //     0x650808: stur            w0, [x1, #7]
    // 0x65080c: r2 = const []
    //     0x65080c: ldr             x2, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x650810: StoreField: r1->field_b = r2
    //     0x650810: stur            w2, [x1, #0xb]
    // 0x650814: mov             x0, x1
    // 0x650818: ldr             x1, [fp, #0x10]
    // 0x65081c: StoreField: r1->field_4f = r0
    //     0x65081c: stur            w0, [x1, #0x4f]
    //     0x650820: ldurb           w16, [x1, #-1]
    //     0x650824: ldurb           w17, [x0, #-1]
    //     0x650828: and             x16, x17, x16, lsr #2
    //     0x65082c: tst             x16, HEAP, lsr #32
    //     0x650830: b.eq            #0x650838
    //     0x650834: bl              #0xd6826c
    // 0x650838: r0 = true
    //     0x650838: add             x0, NULL, #0x20  ; true
    // 0x65083c: StoreField: r1->field_13 = r0
    //     0x65083c: stur            w0, [x1, #0x13]
    // 0x650840: ldr             x3, [fp, #0x18]
    // 0x650844: LoadField: d0 = r3->field_8b
    //     0x650844: ldur            d0, [x3, #0x8b]
    // 0x650848: stur            d0, [fp, #-0x10]
    // 0x65084c: SaveReg r3
    //     0x65084c: str             x3, [SP, #-8]!
    // 0x650850: r0 = _semanticActionUnit()
    //     0x650850: bl              #0x650a08  ; [package:flutter/src/material/slider.dart] _RenderSlider::_semanticActionUnit
    // 0x650854: add             SP, SP, #8
    // 0x650858: mov             v1.16b, v0.16b
    // 0x65085c: ldur            d0, [fp, #-0x10]
    // 0x650860: fsub            d2, d0, d1
    // 0x650864: d0 = 0.000000
    //     0x650864: eor             v0.16b, v0.16b, v0.16b
    // 0x650868: fcmp            d2, d0
    // 0x65086c: b.vs            #0x65087c
    // 0x650870: b.ge            #0x65087c
    // 0x650874: d1 = 0.000000
    //     0x650874: eor             v1.16b, v1.16b, v1.16b
    // 0x650878: b               #0x6508a8
    // 0x65087c: d0 = 1.000000
    //     0x65087c: fmov            d0, #1.00000000
    // 0x650880: fcmp            d2, d0
    // 0x650884: b.vs            #0x650894
    // 0x650888: b.le            #0x650894
    // 0x65088c: d1 = 1.000000
    //     0x65088c: fmov            d1, #1.00000000
    // 0x650890: b               #0x6508a8
    // 0x650894: fcmp            d2, d2
    // 0x650898: b.vc            #0x6508a4
    // 0x65089c: d1 = 1.000000
    //     0x65089c: fmov            d1, #1.00000000
    // 0x6508a0: b               #0x6508a8
    // 0x6508a4: mov             v1.16b, v2.16b
    // 0x6508a8: ldr             x0, [fp, #0x10]
    // 0x6508ac: d0 = 100.000000
    //     0x6508ac: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x6508b0: ldr             d0, [x17, #0x308]
    // 0x6508b4: fmul            d2, d1, d0
    // 0x6508b8: mov             v0.16b, v2.16b
    // 0x6508bc: stp             fp, lr, [SP, #-0x10]!
    // 0x6508c0: mov             fp, SP
    // 0x6508c4: CallRuntime_LibcRound(double) -> double
    //     0x6508c4: and             SP, SP, #0xfffffffffffffff0
    //     0x6508c8: mov             sp, SP
    //     0x6508cc: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x6508d0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x6508d4: blr             x16
    //     0x6508d8: mov             x16, #8
    //     0x6508dc: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x6508e0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x6508e4: sub             sp, x16, #1, lsl #12
    //     0x6508e8: mov             SP, fp
    //     0x6508ec: ldp             fp, lr, [SP], #0x10
    // 0x6508f0: fcmp            d0, d0
    // 0x6508f4: b.vs            #0x6509cc
    // 0x6508f8: fcvtzs          x0, d0
    // 0x6508fc: asr             x16, x0, #0x1e
    // 0x650900: cmp             x16, x0, asr #63
    // 0x650904: b.ne            #0x6509cc
    // 0x650908: lsl             x0, x0, #1
    // 0x65090c: stur            x0, [fp, #-8]
    // 0x650910: r1 = Null
    //     0x650910: mov             x1, NULL
    // 0x650914: r2 = 4
    //     0x650914: mov             x2, #4
    // 0x650918: r0 = AllocateArray()
    //     0x650918: bl              #0xd6987c  ; AllocateArrayStub
    // 0x65091c: mov             x1, x0
    // 0x650920: ldur            x0, [fp, #-8]
    // 0x650924: StoreField: r1->field_f = r0
    //     0x650924: stur            w0, [x1, #0xf]
    // 0x650928: r17 = "%"
    //     0x650928: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x65092c: StoreField: r1->field_13 = r17
    //     0x65092c: stur            w17, [x1, #0x13]
    // 0x650930: SaveReg r1
    //     0x650930: str             x1, [SP, #-8]!
    // 0x650934: r0 = _interpolate()
    //     0x650934: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x650938: add             SP, SP, #8
    // 0x65093c: stur            x0, [fp, #-8]
    // 0x650940: r0 = AttributedString()
    //     0x650940: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x650944: ldur            x1, [fp, #-8]
    // 0x650948: StoreField: r0->field_7 = r1
    //     0x650948: stur            w1, [x0, #7]
    // 0x65094c: r1 = const []
    //     0x65094c: ldr             x1, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x650950: StoreField: r0->field_b = r1
    //     0x650950: stur            w1, [x0, #0xb]
    // 0x650954: ldr             x1, [fp, #0x10]
    // 0x650958: StoreField: r1->field_53 = r0
    //     0x650958: stur            w0, [x1, #0x53]
    //     0x65095c: ldurb           w16, [x1, #-1]
    //     0x650960: ldurb           w17, [x0, #-1]
    //     0x650964: and             x16, x17, x16, lsr #2
    //     0x650968: tst             x16, HEAP, lsr #32
    //     0x65096c: b.eq            #0x650974
    //     0x650970: bl              #0xd6826c
    // 0x650974: r2 = true
    //     0x650974: add             x2, NULL, #0x20  ; true
    // 0x650978: StoreField: r1->field_13 = r2
    //     0x650978: stur            w2, [x1, #0x13]
    // 0x65097c: r0 = Null
    //     0x65097c: mov             x0, NULL
    // 0x650980: LeaveFrame
    //     0x650980: mov             SP, fp
    //     0x650984: ldp             fp, lr, [SP], #0x10
    // 0x650988: ret
    //     0x650988: ret             
    // 0x65098c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65098c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650990: b               #0x65051c
    // 0x650994: SaveReg d0
    //     0x650994: str             q0, [SP, #-0x10]!
    // 0x650998: r0 = 218
    //     0x650998: mov             x0, #0xda
    // 0x65099c: r24 = DoubleToIntegerStub
    //     0x65099c: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x6509a0: LoadField: r30 = r24->field_7
    //     0x6509a0: ldur            lr, [x24, #7]
    // 0x6509a4: blr             lr
    // 0x6509a8: RestoreReg d0
    //     0x6509a8: ldr             q0, [SP], #0x10
    // 0x6509ac: b               #0x65067c
    // 0x6509b0: SaveReg d0
    //     0x6509b0: str             q0, [SP, #-0x10]!
    // 0x6509b4: r0 = 218
    //     0x6509b4: mov             x0, #0xda
    // 0x6509b8: r24 = DoubleToIntegerStub
    //     0x6509b8: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x6509bc: LoadField: r30 = r24->field_7
    //     0x6509bc: ldur            lr, [x24, #7]
    // 0x6509c0: blr             lr
    // 0x6509c4: RestoreReg d0
    //     0x6509c4: ldr             q0, [SP], #0x10
    // 0x6509c8: b               #0x6507c8
    // 0x6509cc: SaveReg d0
    //     0x6509cc: str             q0, [SP, #-0x10]!
    // 0x6509d0: r0 = 218
    //     0x6509d0: mov             x0, #0xda
    // 0x6509d4: r24 = DoubleToIntegerStub
    //     0x6509d4: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x6509d8: LoadField: r30 = r24->field_7
    //     0x6509d8: ldur            lr, [x24, #7]
    // 0x6509dc: blr             lr
    // 0x6509e0: RestoreReg d0
    //     0x6509e0: ldr             q0, [SP], #0x10
    // 0x6509e4: b               #0x65090c
  }
  get _ isInteractive(/* No info */) {
    // ** addr: 0x6509e8, size: 0x20
    // 0x6509e8: ldr             x1, [SP]
    // 0x6509ec: LoadField: r2 = r1->field_b7
    //     0x6509ec: ldur            w2, [x1, #0xb7]
    // 0x6509f0: DecompressPointer r2
    //     0x6509f0: add             x2, x2, HEAP, lsl #32
    // 0x6509f4: cmp             w2, NULL
    // 0x6509f8: r16 = true
    //     0x6509f8: add             x16, NULL, #0x20  ; true
    // 0x6509fc: r17 = false
    //     0x6509fc: add             x17, NULL, #0x30  ; false
    // 0x650a00: csel            x0, x16, x17, ne
    // 0x650a04: ret
    //     0x650a04: ret             
  }
  get _ _semanticActionUnit(/* No info */) {
    // ** addr: 0x650a08, size: 0x48
    // 0x650a08: ldr             x0, [SP]
    // 0x650a0c: LoadField: r1 = r0->field_97
    //     0x650a0c: ldur            w1, [x0, #0x97]
    // 0x650a10: DecompressPointer r1
    //     0x650a10: add             x1, x1, HEAP, lsl #32
    // 0x650a14: LoadField: r0 = r1->field_7
    //     0x650a14: ldur            x0, [x1, #7]
    // 0x650a18: cmp             x0, #2
    // 0x650a1c: b.gt            #0x650a2c
    // 0x650a20: cmp             x0, #1
    // 0x650a24: b.gt            #0x650a3c
    // 0x650a28: b               #0x650a44
    // 0x650a2c: cmp             x0, #4
    // 0x650a30: b.gt            #0x650a44
    // 0x650a34: cmp             x0, #3
    // 0x650a38: b.le            #0x650a44
    // 0x650a3c: d0 = 0.100000
    //     0x650a3c: ldr             d0, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0x650a40: b               #0x650a4c
    // 0x650a44: d0 = 0.050000
    //     0x650a44: add             x17, PP, #0xd, lsl #12  ; [pp+0xd208] IMM: double(0.05) from 0x3fa999999999999a
    //     0x650a48: ldr             d0, [x17, #0x208]
    // 0x650a4c: ret
    //     0x650a4c: ret             
  }
  [closure] void decreaseAction(dynamic) {
    // ** addr: 0x650a50, size: 0x48
    // 0x650a50: EnterFrame
    //     0x650a50: stp             fp, lr, [SP, #-0x10]!
    //     0x650a54: mov             fp, SP
    // 0x650a58: ldr             x0, [fp, #0x10]
    // 0x650a5c: LoadField: r1 = r0->field_17
    //     0x650a5c: ldur            w1, [x0, #0x17]
    // 0x650a60: DecompressPointer r1
    //     0x650a60: add             x1, x1, HEAP, lsl #32
    // 0x650a64: CheckStackOverflow
    //     0x650a64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x650a68: cmp             SP, x16
    //     0x650a6c: b.ls            #0x650a90
    // 0x650a70: LoadField: r0 = r1->field_f
    //     0x650a70: ldur            w0, [x1, #0xf]
    // 0x650a74: DecompressPointer r0
    //     0x650a74: add             x0, x0, HEAP, lsl #32
    // 0x650a78: SaveReg r0
    //     0x650a78: str             x0, [SP, #-8]!
    // 0x650a7c: r0 = decreaseAction()
    //     0x650a7c: bl              #0x650a98  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction
    // 0x650a80: add             SP, SP, #8
    // 0x650a84: LeaveFrame
    //     0x650a84: mov             SP, fp
    //     0x650a88: ldp             fp, lr, [SP], #0x10
    // 0x650a8c: ret
    //     0x650a8c: ret             
    // 0x650a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x650a90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650a94: b               #0x650a70
  }
  _ decreaseAction(/* No info */) {
    // ** addr: 0x650a98, size: 0x100
    // 0x650a98: EnterFrame
    //     0x650a98: stp             fp, lr, [SP, #-0x10]!
    //     0x650a9c: mov             fp, SP
    // 0x650aa0: AllocStack(0x10)
    //     0x650aa0: sub             SP, SP, #0x10
    // 0x650aa4: CheckStackOverflow
    //     0x650aa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x650aa8: cmp             SP, x16
    //     0x650aac: b.ls            #0x650b80
    // 0x650ab0: ldr             x0, [fp, #0x10]
    // 0x650ab4: LoadField: r1 = r0->field_b7
    //     0x650ab4: ldur            w1, [x0, #0xb7]
    // 0x650ab8: DecompressPointer r1
    //     0x650ab8: add             x1, x1, HEAP, lsl #32
    // 0x650abc: stur            x1, [fp, #-8]
    // 0x650ac0: cmp             w1, NULL
    // 0x650ac4: b.eq            #0x650b70
    // 0x650ac8: LoadField: d0 = r0->field_8b
    //     0x650ac8: ldur            d0, [x0, #0x8b]
    // 0x650acc: stur            d0, [fp, #-0x10]
    // 0x650ad0: SaveReg r0
    //     0x650ad0: str             x0, [SP, #-8]!
    // 0x650ad4: r0 = _semanticActionUnit()
    //     0x650ad4: bl              #0x650a08  ; [package:flutter/src/material/slider.dart] _RenderSlider::_semanticActionUnit
    // 0x650ad8: add             SP, SP, #8
    // 0x650adc: mov             v1.16b, v0.16b
    // 0x650ae0: ldur            d0, [fp, #-0x10]
    // 0x650ae4: fsub            d2, d0, d1
    // 0x650ae8: d0 = 0.000000
    //     0x650ae8: eor             v0.16b, v0.16b, v0.16b
    // 0x650aec: fcmp            d2, d0
    // 0x650af0: b.vs            #0x650b00
    // 0x650af4: b.ge            #0x650b00
    // 0x650af8: d0 = 0.000000
    //     0x650af8: eor             v0.16b, v0.16b, v0.16b
    // 0x650afc: b               #0x650b2c
    // 0x650b00: d0 = 1.000000
    //     0x650b00: fmov            d0, #1.00000000
    // 0x650b04: fcmp            d2, d0
    // 0x650b08: b.vs            #0x650b18
    // 0x650b0c: b.le            #0x650b18
    // 0x650b10: d0 = 1.000000
    //     0x650b10: fmov            d0, #1.00000000
    // 0x650b14: b               #0x650b2c
    // 0x650b18: fcmp            d2, d2
    // 0x650b1c: b.vc            #0x650b28
    // 0x650b20: d0 = 1.000000
    //     0x650b20: fmov            d0, #1.00000000
    // 0x650b24: b               #0x650b2c
    // 0x650b28: mov             v0.16b, v2.16b
    // 0x650b2c: r0 = inline_Allocate_Double()
    //     0x650b2c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x650b30: add             x0, x0, #0x10
    //     0x650b34: cmp             x1, x0
    //     0x650b38: b.ls            #0x650b88
    //     0x650b3c: str             x0, [THR, #0x60]  ; THR::top
    //     0x650b40: sub             x0, x0, #0xf
    //     0x650b44: mov             x1, #0xd108
    //     0x650b48: movk            x1, #3, lsl #16
    //     0x650b4c: stur            x1, [x0, #-1]
    // 0x650b50: StoreField: r0->field_7 = d0
    //     0x650b50: stur            d0, [x0, #7]
    // 0x650b54: ldur            x16, [fp, #-8]
    // 0x650b58: stp             x0, x16, [SP, #-0x10]!
    // 0x650b5c: ldur            x0, [fp, #-8]
    // 0x650b60: ClosureCall
    //     0x650b60: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x650b64: ldur            x2, [x0, #0x1f]
    //     0x650b68: blr             x2
    // 0x650b6c: add             SP, SP, #0x10
    // 0x650b70: r0 = Null
    //     0x650b70: mov             x0, NULL
    // 0x650b74: LeaveFrame
    //     0x650b74: mov             SP, fp
    //     0x650b78: ldp             fp, lr, [SP], #0x10
    // 0x650b7c: ret
    //     0x650b7c: ret             
    // 0x650b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x650b80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650b84: b               #0x650ab0
    // 0x650b88: SaveReg d0
    //     0x650b88: str             q0, [SP, #-0x10]!
    // 0x650b8c: r0 = AllocateDouble()
    //     0x650b8c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x650b90: RestoreReg d0
    //     0x650b90: ldr             q0, [SP], #0x10
    // 0x650b94: b               #0x650b50
  }
  [closure] void increaseAction(dynamic) {
    // ** addr: 0x650b98, size: 0x48
    // 0x650b98: EnterFrame
    //     0x650b98: stp             fp, lr, [SP, #-0x10]!
    //     0x650b9c: mov             fp, SP
    // 0x650ba0: ldr             x0, [fp, #0x10]
    // 0x650ba4: LoadField: r1 = r0->field_17
    //     0x650ba4: ldur            w1, [x0, #0x17]
    // 0x650ba8: DecompressPointer r1
    //     0x650ba8: add             x1, x1, HEAP, lsl #32
    // 0x650bac: CheckStackOverflow
    //     0x650bac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x650bb0: cmp             SP, x16
    //     0x650bb4: b.ls            #0x650bd8
    // 0x650bb8: LoadField: r0 = r1->field_f
    //     0x650bb8: ldur            w0, [x1, #0xf]
    // 0x650bbc: DecompressPointer r0
    //     0x650bbc: add             x0, x0, HEAP, lsl #32
    // 0x650bc0: SaveReg r0
    //     0x650bc0: str             x0, [SP, #-8]!
    // 0x650bc4: r0 = increaseAction()
    //     0x650bc4: bl              #0x650be0  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction
    // 0x650bc8: add             SP, SP, #8
    // 0x650bcc: LeaveFrame
    //     0x650bcc: mov             SP, fp
    //     0x650bd0: ldp             fp, lr, [SP], #0x10
    // 0x650bd4: ret
    //     0x650bd4: ret             
    // 0x650bd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x650bd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650bdc: b               #0x650bb8
  }
  _ increaseAction(/* No info */) {
    // ** addr: 0x650be0, size: 0x118
    // 0x650be0: EnterFrame
    //     0x650be0: stp             fp, lr, [SP, #-0x10]!
    //     0x650be4: mov             fp, SP
    // 0x650be8: AllocStack(0x10)
    //     0x650be8: sub             SP, SP, #0x10
    // 0x650bec: CheckStackOverflow
    //     0x650bec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x650bf0: cmp             SP, x16
    //     0x650bf4: b.ls            #0x650cdc
    // 0x650bf8: ldr             x16, [fp, #0x10]
    // 0x650bfc: SaveReg r16
    //     0x650bfc: str             x16, [SP, #-8]!
    // 0x650c00: r0 = isInteractive()
    //     0x650c00: bl              #0x6509e8  ; [package:flutter/src/material/slider.dart] _RenderSlider::isInteractive
    // 0x650c04: add             SP, SP, #8
    // 0x650c08: tbnz            w0, #4, #0x650ccc
    // 0x650c0c: ldr             x0, [fp, #0x10]
    // 0x650c10: LoadField: r1 = r0->field_b7
    //     0x650c10: ldur            w1, [x0, #0xb7]
    // 0x650c14: DecompressPointer r1
    //     0x650c14: add             x1, x1, HEAP, lsl #32
    // 0x650c18: stur            x1, [fp, #-8]
    // 0x650c1c: cmp             w1, NULL
    // 0x650c20: b.eq            #0x650ce4
    // 0x650c24: LoadField: d0 = r0->field_8b
    //     0x650c24: ldur            d0, [x0, #0x8b]
    // 0x650c28: stur            d0, [fp, #-0x10]
    // 0x650c2c: SaveReg r0
    //     0x650c2c: str             x0, [SP, #-8]!
    // 0x650c30: r0 = _semanticActionUnit()
    //     0x650c30: bl              #0x650a08  ; [package:flutter/src/material/slider.dart] _RenderSlider::_semanticActionUnit
    // 0x650c34: add             SP, SP, #8
    // 0x650c38: mov             v1.16b, v0.16b
    // 0x650c3c: ldur            d0, [fp, #-0x10]
    // 0x650c40: fadd            d2, d0, d1
    // 0x650c44: d0 = 0.000000
    //     0x650c44: eor             v0.16b, v0.16b, v0.16b
    // 0x650c48: fcmp            d2, d0
    // 0x650c4c: b.vs            #0x650c5c
    // 0x650c50: b.ge            #0x650c5c
    // 0x650c54: d0 = 0.000000
    //     0x650c54: eor             v0.16b, v0.16b, v0.16b
    // 0x650c58: b               #0x650c88
    // 0x650c5c: d0 = 1.000000
    //     0x650c5c: fmov            d0, #1.00000000
    // 0x650c60: fcmp            d2, d0
    // 0x650c64: b.vs            #0x650c74
    // 0x650c68: b.le            #0x650c74
    // 0x650c6c: d0 = 1.000000
    //     0x650c6c: fmov            d0, #1.00000000
    // 0x650c70: b               #0x650c88
    // 0x650c74: fcmp            d2, d2
    // 0x650c78: b.vc            #0x650c84
    // 0x650c7c: d0 = 1.000000
    //     0x650c7c: fmov            d0, #1.00000000
    // 0x650c80: b               #0x650c88
    // 0x650c84: mov             v0.16b, v2.16b
    // 0x650c88: r0 = inline_Allocate_Double()
    //     0x650c88: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x650c8c: add             x0, x0, #0x10
    //     0x650c90: cmp             x1, x0
    //     0x650c94: b.ls            #0x650ce8
    //     0x650c98: str             x0, [THR, #0x60]  ; THR::top
    //     0x650c9c: sub             x0, x0, #0xf
    //     0x650ca0: mov             x1, #0xd108
    //     0x650ca4: movk            x1, #3, lsl #16
    //     0x650ca8: stur            x1, [x0, #-1]
    // 0x650cac: StoreField: r0->field_7 = d0
    //     0x650cac: stur            d0, [x0, #7]
    // 0x650cb0: ldur            x16, [fp, #-8]
    // 0x650cb4: stp             x0, x16, [SP, #-0x10]!
    // 0x650cb8: ldur            x0, [fp, #-8]
    // 0x650cbc: ClosureCall
    //     0x650cbc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x650cc0: ldur            x2, [x0, #0x1f]
    //     0x650cc4: blr             x2
    // 0x650cc8: add             SP, SP, #0x10
    // 0x650ccc: r0 = Null
    //     0x650ccc: mov             x0, NULL
    // 0x650cd0: LeaveFrame
    //     0x650cd0: mov             SP, fp
    //     0x650cd4: ldp             fp, lr, [SP], #0x10
    // 0x650cd8: ret
    //     0x650cd8: ret             
    // 0x650cdc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x650cdc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x650ce0: b               #0x650bf8
    // 0x650ce4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x650ce4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x650ce8: SaveReg d0
    //     0x650ce8: str             q0, [SP, #-0x10]!
    // 0x650cec: r0 = AllocateDouble()
    //     0x650cec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x650cf0: RestoreReg d0
    //     0x650cf0: ldr             q0, [SP], #0x10
    // 0x650cf4: b               #0x650cac
  }
  _ dispose(/* No info */) {
    // ** addr: 0x652fe8, size: 0x54
    // 0x652fe8: EnterFrame
    //     0x652fe8: stp             fp, lr, [SP, #-0x10]!
    //     0x652fec: mov             fp, SP
    // 0x652ff0: CheckStackOverflow
    //     0x652ff0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x652ff4: cmp             SP, x16
    //     0x652ff8: b.ls            #0x653034
    // 0x652ffc: ldr             x0, [fp, #0x10]
    // 0x653000: LoadField: r1 = r0->field_6f
    //     0x653000: ldur            w1, [x0, #0x6f]
    // 0x653004: DecompressPointer r1
    //     0x653004: add             x1, x1, HEAP, lsl #32
    // 0x653008: SaveReg r1
    //     0x653008: str             x1, [SP, #-8]!
    // 0x65300c: r0 = dispose()
    //     0x65300c: bl              #0x652680  ; [package:flutter/src/painting/text_painter.dart] TextPainter::dispose
    // 0x653010: add             SP, SP, #8
    // 0x653014: ldr             x16, [fp, #0x10]
    // 0x653018: SaveReg r16
    //     0x653018: str             x16, [SP, #-8]!
    // 0x65301c: r0 = dispose()
    //     0x65301c: bl              #0x65378c  ; [package:flutter/src/rendering/object.dart] RenderObject::dispose
    // 0x653020: add             SP, SP, #8
    // 0x653024: r0 = Null
    //     0x653024: mov             x0, NULL
    // 0x653028: LeaveFrame
    //     0x653028: mov             SP, fp
    //     0x65302c: ldp             fp, lr, [SP], #0x10
    // 0x653030: ret
    //     0x653030: ret             
    // 0x653034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x653034: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x653038: b               #0x652ffc
  }
  _ paint(/* No info */) {
    // ** addr: 0x66b764, size: 0x42c
    // 0x66b764: EnterFrame
    //     0x66b764: stp             fp, lr, [SP, #-0x10]!
    //     0x66b768: mov             fp, SP
    // 0x66b76c: AllocStack(0x28)
    //     0x66b76c: sub             SP, SP, #0x28
    // 0x66b770: CheckStackOverflow
    //     0x66b770: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66b774: cmp             SP, x16
    //     0x66b778: b.ls            #0x66bb2c
    // 0x66b77c: ldr             x0, [fp, #0x20]
    // 0x66b780: LoadField: r1 = r0->field_5f
    //     0x66b780: ldur            w1, [x0, #0x5f]
    // 0x66b784: DecompressPointer r1
    //     0x66b784: add             x1, x1, HEAP, lsl #32
    // 0x66b788: LoadField: r2 = r1->field_27
    //     0x66b788: ldur            w2, [x1, #0x27]
    // 0x66b78c: DecompressPointer r2
    //     0x66b78c: add             x2, x2, HEAP, lsl #32
    // 0x66b790: r16 = Sentinel
    //     0x66b790: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66b794: cmp             w2, w16
    // 0x66b798: b.eq            #0x66bb34
    // 0x66b79c: LoadField: r1 = r2->field_37
    //     0x66b79c: ldur            w1, [x2, #0x37]
    // 0x66b7a0: DecompressPointer r1
    //     0x66b7a0: add             x1, x1, HEAP, lsl #32
    // 0x66b7a4: r16 = Sentinel
    //     0x66b7a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66b7a8: cmp             w1, w16
    // 0x66b7ac: b.eq            #0x66bb40
    // 0x66b7b0: LoadField: r2 = r0->field_c3
    //     0x66b7b0: ldur            w2, [x0, #0xc3]
    // 0x66b7b4: DecompressPointer r2
    //     0x66b7b4: add             x2, x2, HEAP, lsl #32
    // 0x66b7b8: LoadField: r3 = r2->field_7
    //     0x66b7b8: ldur            x3, [x2, #7]
    // 0x66b7bc: cmp             x3, #0
    // 0x66b7c0: b.gt            #0x66b7d8
    // 0x66b7c4: d0 = 1.000000
    //     0x66b7c4: fmov            d0, #1.00000000
    // 0x66b7c8: LoadField: d1 = r1->field_7
    //     0x66b7c8: ldur            d1, [x1, #7]
    // 0x66b7cc: fsub            d2, d0, d1
    // 0x66b7d0: mov             v0.16b, v2.16b
    // 0x66b7d4: b               #0x66b7dc
    // 0x66b7d8: LoadField: d0 = r1->field_7
    //     0x66b7d8: ldur            d0, [x1, #7]
    // 0x66b7dc: stur            d0, [fp, #-0x20]
    // 0x66b7e0: LoadField: r1 = r0->field_a7
    //     0x66b7e0: ldur            w1, [x0, #0xa7]
    // 0x66b7e4: DecompressPointer r1
    //     0x66b7e4: add             x1, x1, HEAP, lsl #32
    // 0x66b7e8: LoadField: r2 = r1->field_53
    //     0x66b7e8: ldur            w2, [x1, #0x53]
    // 0x66b7ec: DecompressPointer r2
    //     0x66b7ec: add             x2, x2, HEAP, lsl #32
    // 0x66b7f0: cmp             w2, NULL
    // 0x66b7f4: b.eq            #0x66bb4c
    // 0x66b7f8: stp             x0, x2, [SP, #-0x10]!
    // 0x66b7fc: ldr             x16, [fp, #0x10]
    // 0x66b800: stp             x16, x1, [SP, #-0x10]!
    // 0x66b804: r4 = const [0, 0x4, 0x4, 0x3, offset, 0x3, null]
    //     0x66b804: add             x4, PP, #0x56, lsl #12  ; [pp+0x56c60] List(7) [0, 0x4, 0x4, 0x3, "offset", 0x3, Null]
    //     0x66b808: ldr             x4, [x4, #0xc60]
    // 0x66b80c: r0 = getPreferredRect()
    //     0x66b80c: bl              #0x66c534  ; [package:flutter/src/material/slider_theme.dart] _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x66b810: add             SP, SP, #0x20
    // 0x66b814: LoadField: d0 = r0->field_7
    //     0x66b814: ldur            d0, [x0, #7]
    // 0x66b818: LoadField: d1 = r0->field_17
    //     0x66b818: ldur            d1, [x0, #0x17]
    // 0x66b81c: fsub            d2, d1, d0
    // 0x66b820: ldur            d1, [fp, #-0x20]
    // 0x66b824: fmul            d3, d1, d2
    // 0x66b828: fadd            d1, d0, d3
    // 0x66b82c: stur            d1, [fp, #-0x20]
    // 0x66b830: SaveReg r0
    //     0x66b830: str             x0, [SP, #-8]!
    // 0x66b834: r0 = center()
    //     0x66b834: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x66b838: add             SP, SP, #8
    // 0x66b83c: LoadField: d0 = r0->field_f
    //     0x66b83c: ldur            d0, [x0, #0xf]
    // 0x66b840: stur            d0, [fp, #-0x28]
    // 0x66b844: r0 = Offset()
    //     0x66b844: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66b848: ldur            d0, [fp, #-0x20]
    // 0x66b84c: stur            x0, [fp, #-8]
    // 0x66b850: StoreField: r0->field_7 = d0
    //     0x66b850: stur            d0, [x0, #7]
    // 0x66b854: ldur            d0, [fp, #-0x28]
    // 0x66b858: StoreField: r0->field_f = d0
    //     0x66b858: stur            d0, [x0, #0xf]
    // 0x66b85c: ldr             x1, [fp, #0x20]
    // 0x66b860: LoadField: r2 = r1->field_b7
    //     0x66b860: ldur            w2, [x1, #0xb7]
    // 0x66b864: DecompressPointer r2
    //     0x66b864: add             x2, x2, HEAP, lsl #32
    // 0x66b868: cmp             w2, NULL
    // 0x66b86c: b.eq            #0x66b924
    // 0x66b870: LoadField: r2 = r1->field_a7
    //     0x66b870: ldur            w2, [x1, #0xa7]
    // 0x66b874: DecompressPointer r2
    //     0x66b874: add             x2, x2, HEAP, lsl #32
    // 0x66b878: LoadField: r3 = r2->field_47
    //     0x66b878: ldur            w3, [x2, #0x47]
    // 0x66b87c: DecompressPointer r3
    //     0x66b87c: add             x3, x3, HEAP, lsl #32
    // 0x66b880: cmp             w3, NULL
    // 0x66b884: b.eq            #0x66bb50
    // 0x66b888: r16 = true
    //     0x66b888: add             x16, NULL, #0x20  ; true
    // 0x66b88c: stp             x16, x3, [SP, #-0x10]!
    // 0x66b890: r0 = getPreferredSize()
    //     0x66b890: bl              #0x6314d0  ; [package:flutter/src/material/slider_theme.dart] RoundSliderOverlayShape::getPreferredSize
    // 0x66b894: add             SP, SP, #0x10
    // 0x66b898: LoadField: d0 = r0->field_7
    //     0x66b898: ldur            d0, [x0, #7]
    // 0x66b89c: d1 = 2.000000
    //     0x66b89c: fmov            d1, #2.00000000
    // 0x66b8a0: fdiv            d2, d0, d1
    // 0x66b8a4: fmul            d0, d2, d1
    // 0x66b8a8: stur            d0, [fp, #-0x20]
    // 0x66b8ac: r0 = inline_Allocate_Double()
    //     0x66b8ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x66b8b0: add             x0, x0, #0x10
    //     0x66b8b4: cmp             x1, x0
    //     0x66b8b8: b.ls            #0x66bb54
    //     0x66b8bc: str             x0, [THR, #0x60]  ; THR::top
    //     0x66b8c0: sub             x0, x0, #0xf
    //     0x66b8c4: mov             x1, #0xd108
    //     0x66b8c8: movk            x1, #3, lsl #16
    //     0x66b8cc: stur            x1, [x0, #-1]
    // 0x66b8d0: StoreField: r0->field_7 = d0
    //     0x66b8d0: stur            d0, [x0, #7]
    // 0x66b8d4: stur            x0, [fp, #-0x10]
    // 0x66b8d8: r0 = Rect()
    //     0x66b8d8: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x66b8dc: stur            x0, [fp, #-0x18]
    // 0x66b8e0: ldur            x16, [fp, #-8]
    // 0x66b8e4: stp             x16, x0, [SP, #-0x10]!
    // 0x66b8e8: ldur            x16, [fp, #-0x10]
    // 0x66b8ec: SaveReg r16
    //     0x66b8ec: str             x16, [SP, #-8]!
    // 0x66b8f0: ldur            d0, [fp, #-0x20]
    // 0x66b8f4: SaveReg d0
    //     0x66b8f4: str             d0, [SP, #-8]!
    // 0x66b8f8: r0 = Rect.fromCenter()
    //     0x66b8f8: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x66b8fc: add             SP, SP, #0x20
    // 0x66b900: ldur            x0, [fp, #-0x18]
    // 0x66b904: ldr             x1, [fp, #0x20]
    // 0x66b908: StoreField: r1->field_87 = r0
    //     0x66b908: stur            w0, [x1, #0x87]
    //     0x66b90c: ldurb           w16, [x1, #-1]
    //     0x66b910: ldurb           w17, [x0, #-1]
    //     0x66b914: and             x16, x17, x16, lsr #2
    //     0x66b918: tst             x16, HEAP, lsr #32
    //     0x66b91c: b.eq            #0x66b924
    //     0x66b920: bl              #0xd6826c
    // 0x66b924: LoadField: r0 = r1->field_a7
    //     0x66b924: ldur            w0, [x1, #0xa7]
    // 0x66b928: DecompressPointer r0
    //     0x66b928: add             x0, x0, HEAP, lsl #32
    // 0x66b92c: LoadField: r2 = r0->field_53
    //     0x66b92c: ldur            w2, [x0, #0x53]
    // 0x66b930: DecompressPointer r2
    //     0x66b930: add             x2, x2, HEAP, lsl #32
    // 0x66b934: cmp             w2, NULL
    // 0x66b938: b.eq            #0x66bb64
    // 0x66b93c: LoadField: r3 = r1->field_6b
    //     0x66b93c: ldur            w3, [x1, #0x6b]
    // 0x66b940: DecompressPointer r3
    //     0x66b940: add             x3, x3, HEAP, lsl #32
    // 0x66b944: r16 = Sentinel
    //     0x66b944: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66b948: cmp             w3, w16
    // 0x66b94c: b.eq            #0x66bb68
    // 0x66b950: LoadField: r4 = r1->field_c3
    //     0x66b950: ldur            w4, [x1, #0xc3]
    // 0x66b954: DecompressPointer r4
    //     0x66b954: add             x4, x4, HEAP, lsl #32
    // 0x66b958: LoadField: r5 = r1->field_b7
    //     0x66b958: ldur            w5, [x1, #0xb7]
    // 0x66b95c: DecompressPointer r5
    //     0x66b95c: add             x5, x5, HEAP, lsl #32
    // 0x66b960: cmp             w5, NULL
    // 0x66b964: r16 = true
    //     0x66b964: add             x16, NULL, #0x20  ; true
    // 0x66b968: r17 = false
    //     0x66b968: add             x17, NULL, #0x30  ; false
    // 0x66b96c: csel            x6, x16, x17, ne
    // 0x66b970: ldr             x16, [fp, #0x18]
    // 0x66b974: stp             x16, x2, [SP, #-0x10]!
    // 0x66b978: ldr             x16, [fp, #0x10]
    // 0x66b97c: stp             x3, x16, [SP, #-0x10]!
    // 0x66b980: stp             x1, x6, [SP, #-0x10]!
    // 0x66b984: stp             x0, NULL, [SP, #-0x10]!
    // 0x66b988: ldur            x16, [fp, #-8]
    // 0x66b98c: stp             x16, x4, [SP, #-0x10]!
    // 0x66b990: r0 = paint()
    //     0x66b990: bl              #0x66bbf8  ; [package:flutter/src/material/slider_theme.dart] RoundedRectSliderTrackShape::paint
    // 0x66b994: add             SP, SP, #0x50
    // 0x66b998: ldr             x1, [fp, #0x20]
    // 0x66b99c: LoadField: r0 = r1->field_63
    //     0x66b99c: ldur            w0, [x1, #0x63]
    // 0x66b9a0: DecompressPointer r0
    //     0x66b9a0: add             x0, x0, HEAP, lsl #32
    // 0x66b9a4: r16 = Sentinel
    //     0x66b9a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x66b9a8: cmp             w0, w16
    // 0x66b9ac: b.eq            #0x66bb74
    // 0x66b9b0: LoadField: r2 = r0->field_b
    //     0x66b9b0: ldur            w2, [x0, #0xb]
    // 0x66b9b4: DecompressPointer r2
    //     0x66b9b4: add             x2, x2, HEAP, lsl #32
    // 0x66b9b8: r0 = LoadClassIdInstr(r2)
    //     0x66b9b8: ldur            x0, [x2, #-1]
    //     0x66b9bc: ubfx            x0, x0, #0xc, #0x14
    // 0x66b9c0: SaveReg r2
    //     0x66b9c0: str             x2, [SP, #-8]!
    // 0x66b9c4: r0 = GDT[cid_x0 + 0x376]()
    //     0x66b9c4: add             lr, x0, #0x376
    //     0x66b9c8: ldr             lr, [x21, lr, lsl #3]
    //     0x66b9cc: blr             lr
    // 0x66b9d0: add             SP, SP, #8
    // 0x66b9d4: r16 = Instance_AnimationStatus
    //     0x66b9d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x66b9d8: ldr             x16, [x16, #0xba8]
    // 0x66b9dc: cmp             w0, w16
    // 0x66b9e0: b.eq            #0x66ba80
    // 0x66b9e4: ldr             x0, [fp, #0x20]
    // 0x66b9e8: d0 = 0.000000
    //     0x66b9e8: eor             v0.16b, v0.16b, v0.16b
    // 0x66b9ec: LoadField: r1 = r0->field_a7
    //     0x66b9ec: ldur            w1, [x0, #0xa7]
    // 0x66b9f0: DecompressPointer r1
    //     0x66b9f0: add             x1, x1, HEAP, lsl #32
    // 0x66b9f4: LoadField: r2 = r1->field_47
    //     0x66b9f4: ldur            w2, [x1, #0x47]
    // 0x66b9f8: DecompressPointer r2
    //     0x66b9f8: add             x2, x2, HEAP, lsl #32
    // 0x66b9fc: cmp             w2, NULL
    // 0x66ba00: b.eq            #0x66bb80
    // 0x66ba04: LoadField: r3 = r0->field_63
    //     0x66ba04: ldur            w3, [x0, #0x63]
    // 0x66ba08: DecompressPointer r3
    //     0x66ba08: add             x3, x3, HEAP, lsl #32
    // 0x66ba0c: LoadField: r4 = r0->field_6b
    //     0x66ba0c: ldur            w4, [x0, #0x6b]
    // 0x66ba10: DecompressPointer r4
    //     0x66ba10: add             x4, x4, HEAP, lsl #32
    // 0x66ba14: LoadField: r5 = r0->field_6f
    //     0x66ba14: ldur            w5, [x0, #0x6f]
    // 0x66ba18: DecompressPointer r5
    //     0x66ba18: add             x5, x5, HEAP, lsl #32
    // 0x66ba1c: LoadField: d1 = r0->field_ab
    //     0x66ba1c: ldur            d1, [x0, #0xab]
    // 0x66ba20: LoadField: r6 = r0->field_b3
    //     0x66ba20: ldur            w6, [x0, #0xb3]
    // 0x66ba24: DecompressPointer r6
    //     0x66ba24: add             x6, x6, HEAP, lsl #32
    // 0x66ba28: LoadField: d2 = r6->field_7
    //     0x66ba28: ldur            d2, [x6, #7]
    // 0x66ba2c: fcmp            d2, d0
    // 0x66ba30: b.vs            #0x66ba38
    // 0x66ba34: b.le            #0x66ba48
    // 0x66ba38: LoadField: d2 = r6->field_f
    //     0x66ba38: ldur            d2, [x6, #0xf]
    // 0x66ba3c: fcmp            d2, d0
    // 0x66ba40: b.vs            #0x66ba58
    // 0x66ba44: b.gt            #0x66ba58
    // 0x66ba48: LoadField: r6 = r0->field_57
    //     0x66ba48: ldur            w6, [x0, #0x57]
    // 0x66ba4c: DecompressPointer r6
    //     0x66ba4c: add             x6, x6, HEAP, lsl #32
    // 0x66ba50: cmp             w6, NULL
    // 0x66ba54: b.eq            #0x66bb84
    // 0x66ba58: ldr             x16, [fp, #0x18]
    // 0x66ba5c: stp             x16, x2, [SP, #-0x10]!
    // 0x66ba60: ldur            x16, [fp, #-8]
    // 0x66ba64: stp             x3, x16, [SP, #-0x10]!
    // 0x66ba68: stp             x5, x4, [SP, #-0x10]!
    // 0x66ba6c: stp             x6, x0, [SP, #-0x10]!
    // 0x66ba70: SaveReg r1
    //     0x66ba70: str             x1, [SP, #-8]!
    // 0x66ba74: SaveReg d1
    //     0x66ba74: str             d1, [SP, #-8]!
    // 0x66ba78: r0 = paint()
    //     0x66ba78: bl              #0xcbcb50  ; [package:flutter/src/material/slider_theme.dart] RoundSliderOverlayShape::paint
    // 0x66ba7c: add             SP, SP, #0x50
    // 0x66ba80: ldr             x0, [fp, #0x20]
    // 0x66ba84: d0 = 0.000000
    //     0x66ba84: eor             v0.16b, v0.16b, v0.16b
    // 0x66ba88: LoadField: r1 = r0->field_a7
    //     0x66ba88: ldur            w1, [x0, #0xa7]
    // 0x66ba8c: DecompressPointer r1
    //     0x66ba8c: add             x1, x1, HEAP, lsl #32
    // 0x66ba90: LoadField: r2 = r1->field_4f
    //     0x66ba90: ldur            w2, [x1, #0x4f]
    // 0x66ba94: DecompressPointer r2
    //     0x66ba94: add             x2, x2, HEAP, lsl #32
    // 0x66ba98: cmp             w2, NULL
    // 0x66ba9c: b.eq            #0x66bb88
    // 0x66baa0: LoadField: r3 = r0->field_63
    //     0x66baa0: ldur            w3, [x0, #0x63]
    // 0x66baa4: DecompressPointer r3
    //     0x66baa4: add             x3, x3, HEAP, lsl #32
    // 0x66baa8: LoadField: r4 = r0->field_6b
    //     0x66baa8: ldur            w4, [x0, #0x6b]
    // 0x66baac: DecompressPointer r4
    //     0x66baac: add             x4, x4, HEAP, lsl #32
    // 0x66bab0: LoadField: r5 = r0->field_6f
    //     0x66bab0: ldur            w5, [x0, #0x6f]
    // 0x66bab4: DecompressPointer r5
    //     0x66bab4: add             x5, x5, HEAP, lsl #32
    // 0x66bab8: LoadField: d1 = r0->field_ab
    //     0x66bab8: ldur            d1, [x0, #0xab]
    // 0x66babc: LoadField: r6 = r0->field_b3
    //     0x66babc: ldur            w6, [x0, #0xb3]
    // 0x66bac0: DecompressPointer r6
    //     0x66bac0: add             x6, x6, HEAP, lsl #32
    // 0x66bac4: LoadField: d2 = r6->field_7
    //     0x66bac4: ldur            d2, [x6, #7]
    // 0x66bac8: fcmp            d2, d0
    // 0x66bacc: b.vs            #0x66bad4
    // 0x66bad0: b.le            #0x66bae4
    // 0x66bad4: LoadField: d2 = r6->field_f
    //     0x66bad4: ldur            d2, [x6, #0xf]
    // 0x66bad8: fcmp            d2, d0
    // 0x66badc: b.vs            #0x66baf4
    // 0x66bae0: b.gt            #0x66baf4
    // 0x66bae4: LoadField: r6 = r0->field_57
    //     0x66bae4: ldur            w6, [x0, #0x57]
    // 0x66bae8: DecompressPointer r6
    //     0x66bae8: add             x6, x6, HEAP, lsl #32
    // 0x66baec: cmp             w6, NULL
    // 0x66baf0: b.eq            #0x66bb8c
    // 0x66baf4: ldr             x16, [fp, #0x18]
    // 0x66baf8: stp             x16, x2, [SP, #-0x10]!
    // 0x66bafc: ldur            x16, [fp, #-8]
    // 0x66bb00: stp             x3, x16, [SP, #-0x10]!
    // 0x66bb04: stp             x5, x4, [SP, #-0x10]!
    // 0x66bb08: stp             x6, x0, [SP, #-0x10]!
    // 0x66bb0c: SaveReg r1
    //     0x66bb0c: str             x1, [SP, #-8]!
    // 0x66bb10: SaveReg d1
    //     0x66bb10: str             d1, [SP, #-8]!
    // 0x66bb14: r0 = paint()
    //     0x66bb14: bl              #0xcbc560  ; [package:flutter/src/material/slider_theme.dart] RoundSliderThumbShape::paint
    // 0x66bb18: add             SP, SP, #0x50
    // 0x66bb1c: r0 = Null
    //     0x66bb1c: mov             x0, NULL
    // 0x66bb20: LeaveFrame
    //     0x66bb20: mov             SP, fp
    //     0x66bb24: ldp             fp, lr, [SP], #0x10
    // 0x66bb28: ret
    //     0x66bb28: ret             
    // 0x66bb2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66bb2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66bb30: b               #0x66b77c
    // 0x66bb34: r9 = positionController
    //     0x66bb34: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0x66bb38: ldr             x9, [x9, #0x838]
    // 0x66bb3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x66bb3c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66bb40: r9 = _value
    //     0x66bb40: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x66bb44: ldr             x9, [x9, #0xbb0]
    // 0x66bb48: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x66bb48: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66bb4c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66bb4c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66bb50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66bb50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66bb54: SaveReg d0
    //     0x66bb54: str             q0, [SP, #-0x10]!
    // 0x66bb58: r0 = AllocateDouble()
    //     0x66bb58: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x66bb5c: RestoreReg d0
    //     0x66bb5c: ldr             q0, [SP], #0x10
    // 0x66bb60: b               #0x66b8d0
    // 0x66bb64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66bb64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x66bb68: r9 = _enableAnimation
    //     0x66bb68: add             x9, PP, #0x56, lsl #12  ; [pp+0x56c68] Field <_RenderSlider@810231897._enableAnimation@810231897>: late (offset: 0x6c)
    //     0x66bb6c: ldr             x9, [x9, #0xc68]
    // 0x66bb70: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x66bb70: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66bb74: r9 = _overlayAnimation
    //     0x66bb74: add             x9, PP, #0x56, lsl #12  ; [pp+0x56c70] Field <_RenderSlider@810231897._overlayAnimation@810231897>: late (offset: 0x64)
    //     0x66bb78: ldr             x9, [x9, #0xc70]
    // 0x66bb7c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x66bb7c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x66bb80: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66bb80: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66bb84: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66bb84: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66bb88: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66bb88: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x66bb8c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x66bb8c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ gestureSettings=(/* No info */) {
    // ** addr: 0x6cb67c, size: 0x9c
    // 0x6cb67c: EnterFrame
    //     0x6cb67c: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb680: mov             fp, SP
    // 0x6cb684: ldr             x1, [fp, #0x18]
    // 0x6cb688: LoadField: r2 = r1->field_73
    //     0x6cb688: ldur            w2, [x1, #0x73]
    // 0x6cb68c: DecompressPointer r2
    //     0x6cb68c: add             x2, x2, HEAP, lsl #32
    // 0x6cb690: r16 = Sentinel
    //     0x6cb690: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb694: cmp             w2, w16
    // 0x6cb698: b.eq            #0x6cb700
    // 0x6cb69c: ldr             x0, [fp, #0x10]
    // 0x6cb6a0: StoreField: r2->field_7 = r0
    //     0x6cb6a0: stur            w0, [x2, #7]
    //     0x6cb6a4: ldurb           w16, [x2, #-1]
    //     0x6cb6a8: ldurb           w17, [x0, #-1]
    //     0x6cb6ac: and             x16, x17, x16, lsr #2
    //     0x6cb6b0: tst             x16, HEAP, lsr #32
    //     0x6cb6b4: b.eq            #0x6cb6bc
    //     0x6cb6b8: bl              #0xd6828c
    // 0x6cb6bc: LoadField: r2 = r1->field_77
    //     0x6cb6bc: ldur            w2, [x1, #0x77]
    // 0x6cb6c0: DecompressPointer r2
    //     0x6cb6c0: add             x2, x2, HEAP, lsl #32
    // 0x6cb6c4: r16 = Sentinel
    //     0x6cb6c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb6c8: cmp             w2, w16
    // 0x6cb6cc: b.eq            #0x6cb70c
    // 0x6cb6d0: ldr             x0, [fp, #0x10]
    // 0x6cb6d4: StoreField: r2->field_7 = r0
    //     0x6cb6d4: stur            w0, [x2, #7]
    //     0x6cb6d8: ldurb           w16, [x2, #-1]
    //     0x6cb6dc: ldurb           w17, [x0, #-1]
    //     0x6cb6e0: and             x16, x17, x16, lsr #2
    //     0x6cb6e4: tst             x16, HEAP, lsr #32
    //     0x6cb6e8: b.eq            #0x6cb6f0
    //     0x6cb6ec: bl              #0xd6828c
    // 0x6cb6f0: r0 = Null
    //     0x6cb6f0: mov             x0, NULL
    // 0x6cb6f4: LeaveFrame
    //     0x6cb6f4: mov             SP, fp
    //     0x6cb6f8: ldp             fp, lr, [SP], #0x10
    // 0x6cb6fc: ret
    //     0x6cb6fc: ret             
    // 0x6cb700: r9 = _drag
    //     0x6cb700: add             x9, PP, #0x56, lsl #12  ; [pp+0x56420] Field <_RenderSlider@810231897._drag@810231897>: late (offset: 0x74)
    //     0x6cb704: ldr             x9, [x9, #0x420]
    // 0x6cb708: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cb708: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6cb70c: r9 = _tap
    //     0x6cb70c: add             x9, PP, #0x56, lsl #12  ; [pp+0x56428] Field <_RenderSlider@810231897._tap@810231897>: late (offset: 0x78)
    //     0x6cb710: ldr             x9, [x9, #0x428]
    // 0x6cb714: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cb714: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ hovering=(/* No info */) {
    // ** addr: 0x6cb718, size: 0x64
    // 0x6cb718: EnterFrame
    //     0x6cb718: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb71c: mov             fp, SP
    // 0x6cb720: CheckStackOverflow
    //     0x6cb720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb724: cmp             SP, x16
    //     0x6cb728: b.ls            #0x6cb774
    // 0x6cb72c: ldr             x0, [fp, #0x18]
    // 0x6cb730: LoadField: r1 = r0->field_cb
    //     0x6cb730: ldur            w1, [x0, #0xcb]
    // 0x6cb734: DecompressPointer r1
    //     0x6cb734: add             x1, x1, HEAP, lsl #32
    // 0x6cb738: ldr             x2, [fp, #0x10]
    // 0x6cb73c: cmp             w2, w1
    // 0x6cb740: b.ne            #0x6cb754
    // 0x6cb744: r0 = Null
    //     0x6cb744: mov             x0, NULL
    // 0x6cb748: LeaveFrame
    //     0x6cb748: mov             SP, fp
    //     0x6cb74c: ldp             fp, lr, [SP], #0x10
    // 0x6cb750: ret
    //     0x6cb750: ret             
    // 0x6cb754: StoreField: r0->field_cb = r2
    //     0x6cb754: stur            w2, [x0, #0xcb]
    // 0x6cb758: stp             x2, x0, [SP, #-0x10]!
    // 0x6cb75c: r0 = _updateForHover()
    //     0x6cb75c: bl              #0x6cb77c  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateForHover
    // 0x6cb760: add             SP, SP, #0x10
    // 0x6cb764: r0 = Null
    //     0x6cb764: mov             x0, NULL
    // 0x6cb768: LeaveFrame
    //     0x6cb768: mov             SP, fp
    //     0x6cb76c: ldp             fp, lr, [SP], #0x10
    // 0x6cb770: ret
    //     0x6cb770: ret             
    // 0x6cb774: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb774: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb778: b               #0x6cb72c
  }
  _ _updateForHover(/* No info */) {
    // ** addr: 0x6cb77c, size: 0xc8
    // 0x6cb77c: EnterFrame
    //     0x6cb77c: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb780: mov             fp, SP
    // 0x6cb784: CheckStackOverflow
    //     0x6cb784: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb788: cmp             SP, x16
    //     0x6cb78c: b.ls            #0x6cb824
    // 0x6cb790: ldr             x0, [fp, #0x10]
    // 0x6cb794: tbnz            w0, #4, #0x6cb7d8
    // 0x6cb798: ldr             x0, [fp, #0x18]
    // 0x6cb79c: LoadField: r1 = r0->field_cf
    //     0x6cb79c: ldur            w1, [x0, #0xcf]
    // 0x6cb7a0: DecompressPointer r1
    //     0x6cb7a0: add             x1, x1, HEAP, lsl #32
    // 0x6cb7a4: tbnz            w1, #4, #0x6cb7dc
    // 0x6cb7a8: LoadField: r1 = r0->field_5f
    //     0x6cb7a8: ldur            w1, [x0, #0x5f]
    // 0x6cb7ac: DecompressPointer r1
    //     0x6cb7ac: add             x1, x1, HEAP, lsl #32
    // 0x6cb7b0: LoadField: r0 = r1->field_1b
    //     0x6cb7b0: ldur            w0, [x1, #0x1b]
    // 0x6cb7b4: DecompressPointer r0
    //     0x6cb7b4: add             x0, x0, HEAP, lsl #32
    // 0x6cb7b8: r16 = Sentinel
    //     0x6cb7b8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb7bc: cmp             w0, w16
    // 0x6cb7c0: b.eq            #0x6cb82c
    // 0x6cb7c4: SaveReg r0
    //     0x6cb7c4: str             x0, [SP, #-8]!
    // 0x6cb7c8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6cb7c8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6cb7cc: r0 = forward()
    //     0x6cb7cc: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x6cb7d0: add             SP, SP, #8
    // 0x6cb7d4: b               #0x6cb814
    // 0x6cb7d8: ldr             x0, [fp, #0x18]
    // 0x6cb7dc: LoadField: r1 = r0->field_c7
    //     0x6cb7dc: ldur            w1, [x0, #0xc7]
    // 0x6cb7e0: DecompressPointer r1
    //     0x6cb7e0: add             x1, x1, HEAP, lsl #32
    // 0x6cb7e4: tbz             w1, #4, #0x6cb814
    // 0x6cb7e8: LoadField: r1 = r0->field_5f
    //     0x6cb7e8: ldur            w1, [x0, #0x5f]
    // 0x6cb7ec: DecompressPointer r1
    //     0x6cb7ec: add             x1, x1, HEAP, lsl #32
    // 0x6cb7f0: LoadField: r0 = r1->field_1b
    //     0x6cb7f0: ldur            w0, [x1, #0x1b]
    // 0x6cb7f4: DecompressPointer r0
    //     0x6cb7f4: add             x0, x0, HEAP, lsl #32
    // 0x6cb7f8: r16 = Sentinel
    //     0x6cb7f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb7fc: cmp             w0, w16
    // 0x6cb800: b.eq            #0x6cb838
    // 0x6cb804: SaveReg r0
    //     0x6cb804: str             x0, [SP, #-8]!
    // 0x6cb808: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6cb808: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6cb80c: r0 = reverse()
    //     0x6cb80c: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6cb810: add             SP, SP, #8
    // 0x6cb814: r0 = Null
    //     0x6cb814: mov             x0, NULL
    // 0x6cb818: LeaveFrame
    //     0x6cb818: mov             SP, fp
    //     0x6cb81c: ldp             fp, lr, [SP], #0x10
    // 0x6cb820: ret
    //     0x6cb820: ret             
    // 0x6cb824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb828: b               #0x6cb790
    // 0x6cb82c: r9 = overlayController
    //     0x6cb82c: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6cb830: ldr             x9, [x9, #0x820]
    // 0x6cb834: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cb834: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6cb838: r9 = overlayController
    //     0x6cb838: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6cb83c: ldr             x9, [x9, #0x820]
    // 0x6cb840: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cb840: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ hasFocus=(/* No info */) {
    // ** addr: 0x6cb844, size: 0x74
    // 0x6cb844: EnterFrame
    //     0x6cb844: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb848: mov             fp, SP
    // 0x6cb84c: CheckStackOverflow
    //     0x6cb84c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb850: cmp             SP, x16
    //     0x6cb854: b.ls            #0x6cb8b0
    // 0x6cb858: ldr             x0, [fp, #0x18]
    // 0x6cb85c: LoadField: r1 = r0->field_c7
    //     0x6cb85c: ldur            w1, [x0, #0xc7]
    // 0x6cb860: DecompressPointer r1
    //     0x6cb860: add             x1, x1, HEAP, lsl #32
    // 0x6cb864: ldr             x2, [fp, #0x10]
    // 0x6cb868: cmp             w2, w1
    // 0x6cb86c: b.ne            #0x6cb880
    // 0x6cb870: r0 = Null
    //     0x6cb870: mov             x0, NULL
    // 0x6cb874: LeaveFrame
    //     0x6cb874: mov             SP, fp
    //     0x6cb878: ldp             fp, lr, [SP], #0x10
    // 0x6cb87c: ret
    //     0x6cb87c: ret             
    // 0x6cb880: StoreField: r0->field_c7 = r2
    //     0x6cb880: stur            w2, [x0, #0xc7]
    // 0x6cb884: stp             x2, x0, [SP, #-0x10]!
    // 0x6cb888: r0 = _updateForFocus()
    //     0x6cb888: bl              #0x6cb8b8  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateForFocus
    // 0x6cb88c: add             SP, SP, #0x10
    // 0x6cb890: ldr             x16, [fp, #0x18]
    // 0x6cb894: SaveReg r16
    //     0x6cb894: str             x16, [SP, #-8]!
    // 0x6cb898: r0 = markNeedsSemanticsUpdate()
    //     0x6cb898: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6cb89c: add             SP, SP, #8
    // 0x6cb8a0: r0 = Null
    //     0x6cb8a0: mov             x0, NULL
    // 0x6cb8a4: LeaveFrame
    //     0x6cb8a4: mov             SP, fp
    //     0x6cb8a8: ldp             fp, lr, [SP], #0x10
    // 0x6cb8ac: ret
    //     0x6cb8ac: ret             
    // 0x6cb8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb8b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb8b4: b               #0x6cb858
  }
  _ _updateForFocus(/* No info */) {
    // ** addr: 0x6cb8b8, size: 0x174
    // 0x6cb8b8: EnterFrame
    //     0x6cb8b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb8bc: mov             fp, SP
    // 0x6cb8c0: AllocStack(0x10)
    //     0x6cb8c0: sub             SP, SP, #0x10
    // 0x6cb8c4: CheckStackOverflow
    //     0x6cb8c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb8c8: cmp             SP, x16
    //     0x6cb8cc: b.ls            #0x6cb9f4
    // 0x6cb8d0: ldr             x0, [fp, #0x10]
    // 0x6cb8d4: tbnz            w0, #4, #0x6cb960
    // 0x6cb8d8: ldr             x0, [fp, #0x18]
    // 0x6cb8dc: LoadField: r1 = r0->field_5f
    //     0x6cb8dc: ldur            w1, [x0, #0x5f]
    // 0x6cb8e0: DecompressPointer r1
    //     0x6cb8e0: add             x1, x1, HEAP, lsl #32
    // 0x6cb8e4: stur            x1, [fp, #-8]
    // 0x6cb8e8: LoadField: r2 = r1->field_1b
    //     0x6cb8e8: ldur            w2, [x1, #0x1b]
    // 0x6cb8ec: DecompressPointer r2
    //     0x6cb8ec: add             x2, x2, HEAP, lsl #32
    // 0x6cb8f0: r16 = Sentinel
    //     0x6cb8f0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb8f4: cmp             w2, w16
    // 0x6cb8f8: b.eq            #0x6cb9fc
    // 0x6cb8fc: SaveReg r2
    //     0x6cb8fc: str             x2, [SP, #-8]!
    // 0x6cb900: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6cb900: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6cb904: r0 = forward()
    //     0x6cb904: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x6cb908: add             SP, SP, #8
    // 0x6cb90c: ldr             x16, [fp, #0x18]
    // 0x6cb910: SaveReg r16
    //     0x6cb910: str             x16, [SP, #-8]!
    // 0x6cb914: r0 = showValueIndicator()
    //     0x6cb914: bl              #0x6cba2c  ; [package:flutter/src/material/slider.dart] _RenderSlider::showValueIndicator
    // 0x6cb918: add             SP, SP, #8
    // 0x6cb91c: mov             x1, x0
    // 0x6cb920: stur            x1, [fp, #-0x10]
    // 0x6cb924: tbnz            w0, #5, #0x6cb92c
    // 0x6cb928: r0 = AssertBoolean()
    //     0x6cb928: bl              #0xd67df0  ; AssertBooleanStub
    // 0x6cb92c: ldur            x0, [fp, #-0x10]
    // 0x6cb930: tbnz            w0, #4, #0x6cb9e4
    // 0x6cb934: ldur            x0, [fp, #-8]
    // 0x6cb938: LoadField: r1 = r0->field_1f
    //     0x6cb938: ldur            w1, [x0, #0x1f]
    // 0x6cb93c: DecompressPointer r1
    //     0x6cb93c: add             x1, x1, HEAP, lsl #32
    // 0x6cb940: r16 = Sentinel
    //     0x6cb940: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb944: cmp             w1, w16
    // 0x6cb948: b.eq            #0x6cba08
    // 0x6cb94c: SaveReg r1
    //     0x6cb94c: str             x1, [SP, #-8]!
    // 0x6cb950: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6cb950: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6cb954: r0 = forward()
    //     0x6cb954: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x6cb958: add             SP, SP, #8
    // 0x6cb95c: b               #0x6cb9e4
    // 0x6cb960: ldr             x0, [fp, #0x18]
    // 0x6cb964: LoadField: r1 = r0->field_5f
    //     0x6cb964: ldur            w1, [x0, #0x5f]
    // 0x6cb968: DecompressPointer r1
    //     0x6cb968: add             x1, x1, HEAP, lsl #32
    // 0x6cb96c: stur            x1, [fp, #-8]
    // 0x6cb970: LoadField: r2 = r1->field_1b
    //     0x6cb970: ldur            w2, [x1, #0x1b]
    // 0x6cb974: DecompressPointer r2
    //     0x6cb974: add             x2, x2, HEAP, lsl #32
    // 0x6cb978: r16 = Sentinel
    //     0x6cb978: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb97c: cmp             w2, w16
    // 0x6cb980: b.eq            #0x6cba14
    // 0x6cb984: SaveReg r2
    //     0x6cb984: str             x2, [SP, #-8]!
    // 0x6cb988: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6cb988: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6cb98c: r0 = reverse()
    //     0x6cb98c: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6cb990: add             SP, SP, #8
    // 0x6cb994: ldr             x16, [fp, #0x18]
    // 0x6cb998: SaveReg r16
    //     0x6cb998: str             x16, [SP, #-8]!
    // 0x6cb99c: r0 = showValueIndicator()
    //     0x6cb99c: bl              #0x6cba2c  ; [package:flutter/src/material/slider.dart] _RenderSlider::showValueIndicator
    // 0x6cb9a0: add             SP, SP, #8
    // 0x6cb9a4: mov             x1, x0
    // 0x6cb9a8: stur            x1, [fp, #-0x10]
    // 0x6cb9ac: tbnz            w0, #5, #0x6cb9b4
    // 0x6cb9b0: r0 = AssertBoolean()
    //     0x6cb9b0: bl              #0xd67df0  ; AssertBooleanStub
    // 0x6cb9b4: ldur            x0, [fp, #-0x10]
    // 0x6cb9b8: tbnz            w0, #4, #0x6cb9e4
    // 0x6cb9bc: ldur            x0, [fp, #-8]
    // 0x6cb9c0: LoadField: r1 = r0->field_1f
    //     0x6cb9c0: ldur            w1, [x0, #0x1f]
    // 0x6cb9c4: DecompressPointer r1
    //     0x6cb9c4: add             x1, x1, HEAP, lsl #32
    // 0x6cb9c8: r16 = Sentinel
    //     0x6cb9c8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb9cc: cmp             w1, w16
    // 0x6cb9d0: b.eq            #0x6cba20
    // 0x6cb9d4: SaveReg r1
    //     0x6cb9d4: str             x1, [SP, #-8]!
    // 0x6cb9d8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6cb9d8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6cb9dc: r0 = reverse()
    //     0x6cb9dc: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6cb9e0: add             SP, SP, #8
    // 0x6cb9e4: r0 = Null
    //     0x6cb9e4: mov             x0, NULL
    // 0x6cb9e8: LeaveFrame
    //     0x6cb9e8: mov             SP, fp
    //     0x6cb9ec: ldp             fp, lr, [SP], #0x10
    // 0x6cb9f0: ret
    //     0x6cb9f0: ret             
    // 0x6cb9f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb9f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb9f8: b               #0x6cb8d0
    // 0x6cb9fc: r9 = overlayController
    //     0x6cb9fc: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6cba00: ldr             x9, [x9, #0x820]
    // 0x6cba04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cba04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6cba08: r9 = valueIndicatorController
    //     0x6cba08: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6cba0c: ldr             x9, [x9, #0x828]
    // 0x6cba10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cba10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6cba14: r9 = overlayController
    //     0x6cba14: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6cba18: ldr             x9, [x9, #0x820]
    // 0x6cba1c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cba1c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6cba20: r9 = valueIndicatorController
    //     0x6cba20: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6cba24: ldr             x9, [x9, #0x828]
    // 0x6cba28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6cba28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ showValueIndicator(/* No info */) {
    // ** addr: 0x6cba2c, size: 0x84
    // 0x6cba2c: EnterFrame
    //     0x6cba2c: stp             fp, lr, [SP, #-0x10]!
    //     0x6cba30: mov             fp, SP
    // 0x6cba34: ldr             x1, [fp, #0x10]
    // 0x6cba38: LoadField: r2 = r1->field_a7
    //     0x6cba38: ldur            w2, [x1, #0xa7]
    // 0x6cba3c: DecompressPointer r2
    //     0x6cba3c: add             x2, x2, HEAP, lsl #32
    // 0x6cba40: LoadField: r1 = r2->field_6b
    //     0x6cba40: ldur            w1, [x2, #0x6b]
    // 0x6cba44: DecompressPointer r1
    //     0x6cba44: add             x1, x1, HEAP, lsl #32
    // 0x6cba48: cmp             w1, NULL
    // 0x6cba4c: b.eq            #0x6cbaac
    // 0x6cba50: LoadField: r2 = r1->field_7
    //     0x6cba50: ldur            x2, [x1, #7]
    // 0x6cba54: cmp             x2, #1
    // 0x6cba58: b.gt            #0x6cba84
    // 0x6cba5c: cmp             x2, #0
    // 0x6cba60: b.gt            #0x6cba74
    // 0x6cba64: r0 = false
    //     0x6cba64: add             x0, NULL, #0x30  ; false
    // 0x6cba68: LeaveFrame
    //     0x6cba68: mov             SP, fp
    //     0x6cba6c: ldp             fp, lr, [SP], #0x10
    // 0x6cba70: ret
    //     0x6cba70: ret             
    // 0x6cba74: r0 = true
    //     0x6cba74: add             x0, NULL, #0x20  ; true
    // 0x6cba78: LeaveFrame
    //     0x6cba78: mov             SP, fp
    //     0x6cba7c: ldp             fp, lr, [SP], #0x10
    // 0x6cba80: ret
    //     0x6cba80: ret             
    // 0x6cba84: cmp             x2, #2
    // 0x6cba88: b.gt            #0x6cba9c
    // 0x6cba8c: r0 = true
    //     0x6cba8c: add             x0, NULL, #0x20  ; true
    // 0x6cba90: LeaveFrame
    //     0x6cba90: mov             SP, fp
    //     0x6cba94: ldp             fp, lr, [SP], #0x10
    // 0x6cba98: ret
    //     0x6cba98: ret             
    // 0x6cba9c: r0 = false
    //     0x6cba9c: add             x0, NULL, #0x30  ; false
    // 0x6cbaa0: LeaveFrame
    //     0x6cbaa0: mov             SP, fp
    //     0x6cbaa4: ldp             fp, lr, [SP], #0x10
    // 0x6cbaa8: ret
    //     0x6cbaa8: ret             
    // 0x6cbaac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6cbaac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ platform=(/* No info */) {
    // ** addr: 0x6cbab0, size: 0x80
    // 0x6cbab0: EnterFrame
    //     0x6cbab0: stp             fp, lr, [SP, #-0x10]!
    //     0x6cbab4: mov             fp, SP
    // 0x6cbab8: CheckStackOverflow
    //     0x6cbab8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cbabc: cmp             SP, x16
    //     0x6cbac0: b.ls            #0x6cbb28
    // 0x6cbac4: ldr             x1, [fp, #0x18]
    // 0x6cbac8: LoadField: r0 = r1->field_97
    //     0x6cbac8: ldur            w0, [x1, #0x97]
    // 0x6cbacc: DecompressPointer r0
    //     0x6cbacc: add             x0, x0, HEAP, lsl #32
    // 0x6cbad0: ldr             x2, [fp, #0x10]
    // 0x6cbad4: cmp             w0, w2
    // 0x6cbad8: b.ne            #0x6cbaec
    // 0x6cbadc: r0 = Null
    //     0x6cbadc: mov             x0, NULL
    // 0x6cbae0: LeaveFrame
    //     0x6cbae0: mov             SP, fp
    //     0x6cbae4: ldp             fp, lr, [SP], #0x10
    // 0x6cbae8: ret
    //     0x6cbae8: ret             
    // 0x6cbaec: mov             x0, x2
    // 0x6cbaf0: StoreField: r1->field_97 = r0
    //     0x6cbaf0: stur            w0, [x1, #0x97]
    //     0x6cbaf4: ldurb           w16, [x1, #-1]
    //     0x6cbaf8: ldurb           w17, [x0, #-1]
    //     0x6cbafc: and             x16, x17, x16, lsr #2
    //     0x6cbb00: tst             x16, HEAP, lsr #32
    //     0x6cbb04: b.eq            #0x6cbb0c
    //     0x6cbb08: bl              #0xd6826c
    // 0x6cbb0c: SaveReg r1
    //     0x6cbb0c: str             x1, [SP, #-8]!
    // 0x6cbb10: r0 = markNeedsSemanticsUpdate()
    //     0x6cbb10: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6cbb14: add             SP, SP, #8
    // 0x6cbb18: r0 = Null
    //     0x6cbb18: mov             x0, NULL
    // 0x6cbb1c: LeaveFrame
    //     0x6cbb1c: mov             SP, fp
    //     0x6cbb20: ldp             fp, lr, [SP], #0x10
    // 0x6cbb24: ret
    //     0x6cbb24: ret             
    // 0x6cbb28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cbb28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cbb2c: b               #0x6cbac4
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6d2ea8, size: 0x80
    // 0x6d2ea8: EnterFrame
    //     0x6d2ea8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d2eac: mov             fp, SP
    // 0x6d2eb0: CheckStackOverflow
    //     0x6d2eb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d2eb4: cmp             SP, x16
    //     0x6d2eb8: b.ls            #0x6d2f20
    // 0x6d2ebc: ldr             x1, [fp, #0x18]
    // 0x6d2ec0: LoadField: r0 = r1->field_c3
    //     0x6d2ec0: ldur            w0, [x1, #0xc3]
    // 0x6d2ec4: DecompressPointer r0
    //     0x6d2ec4: add             x0, x0, HEAP, lsl #32
    // 0x6d2ec8: ldr             x2, [fp, #0x10]
    // 0x6d2ecc: cmp             w2, w0
    // 0x6d2ed0: b.ne            #0x6d2ee4
    // 0x6d2ed4: r0 = Null
    //     0x6d2ed4: mov             x0, NULL
    // 0x6d2ed8: LeaveFrame
    //     0x6d2ed8: mov             SP, fp
    //     0x6d2edc: ldp             fp, lr, [SP], #0x10
    // 0x6d2ee0: ret
    //     0x6d2ee0: ret             
    // 0x6d2ee4: mov             x0, x2
    // 0x6d2ee8: StoreField: r1->field_c3 = r0
    //     0x6d2ee8: stur            w0, [x1, #0xc3]
    //     0x6d2eec: ldurb           w16, [x1, #-1]
    //     0x6d2ef0: ldurb           w17, [x0, #-1]
    //     0x6d2ef4: and             x16, x17, x16, lsr #2
    //     0x6d2ef8: tst             x16, HEAP, lsr #32
    //     0x6d2efc: b.eq            #0x6d2f04
    //     0x6d2f00: bl              #0xd6826c
    // 0x6d2f04: SaveReg r1
    //     0x6d2f04: str             x1, [SP, #-8]!
    // 0x6d2f08: r0 = _updateLabelPainter()
    //     0x6d2f08: bl              #0x6d2f28  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0x6d2f0c: add             SP, SP, #8
    // 0x6d2f10: r0 = Null
    //     0x6d2f10: mov             x0, NULL
    // 0x6d2f14: LeaveFrame
    //     0x6d2f14: mov             SP, fp
    //     0x6d2f18: ldp             fp, lr, [SP], #0x10
    // 0x6d2f1c: ret
    //     0x6d2f1c: ret             
    // 0x6d2f20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d2f20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d2f24: b               #0x6d2ebc
  }
  _ _updateLabelPainter(/* No info */) {
    // ** addr: 0x6d2f28, size: 0x54
    // 0x6d2f28: EnterFrame
    //     0x6d2f28: stp             fp, lr, [SP, #-0x10]!
    //     0x6d2f2c: mov             fp, SP
    // 0x6d2f30: CheckStackOverflow
    //     0x6d2f30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d2f34: cmp             SP, x16
    //     0x6d2f38: b.ls            #0x6d2f74
    // 0x6d2f3c: ldr             x0, [fp, #0x10]
    // 0x6d2f40: LoadField: r1 = r0->field_6f
    //     0x6d2f40: ldur            w1, [x0, #0x6f]
    // 0x6d2f44: DecompressPointer r1
    //     0x6d2f44: add             x1, x1, HEAP, lsl #32
    // 0x6d2f48: stp             NULL, x1, [SP, #-0x10]!
    // 0x6d2f4c: r0 = text=()
    //     0x6d2f4c: bl              #0x673330  ; [package:flutter/src/painting/text_painter.dart] TextPainter::text=
    // 0x6d2f50: add             SP, SP, #0x10
    // 0x6d2f54: ldr             x16, [fp, #0x10]
    // 0x6d2f58: SaveReg r16
    //     0x6d2f58: str             x16, [SP, #-8]!
    // 0x6d2f5c: r0 = markNeedsLayout()
    //     0x6d2f5c: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6d2f60: add             SP, SP, #8
    // 0x6d2f64: r0 = Null
    //     0x6d2f64: mov             x0, NULL
    // 0x6d2f68: LeaveFrame
    //     0x6d2f68: mov             SP, fp
    //     0x6d2f6c: ldp             fp, lr, [SP], #0x10
    // 0x6d2f70: ret
    //     0x6d2f70: ret             
    // 0x6d2f74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d2f74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d2f78: b               #0x6d2f3c
  }
  set _ onChanged=(/* No info */) {
    // ** addr: 0x6d2f7c, size: 0x168
    // 0x6d2f7c: EnterFrame
    //     0x6d2f7c: stp             fp, lr, [SP, #-0x10]!
    //     0x6d2f80: mov             fp, SP
    // 0x6d2f84: CheckStackOverflow
    //     0x6d2f84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d2f88: cmp             SP, x16
    //     0x6d2f8c: b.ls            #0x6d30c4
    // 0x6d2f90: ldr             x1, [fp, #0x18]
    // 0x6d2f94: LoadField: r0 = r1->field_b7
    //     0x6d2f94: ldur            w0, [x1, #0xb7]
    // 0x6d2f98: DecompressPointer r0
    //     0x6d2f98: add             x0, x0, HEAP, lsl #32
    // 0x6d2f9c: ldr             x2, [fp, #0x10]
    // 0x6d2fa0: r3 = LoadClassIdInstr(r2)
    //     0x6d2fa0: ldur            x3, [x2, #-1]
    //     0x6d2fa4: ubfx            x3, x3, #0xc, #0x14
    // 0x6d2fa8: stp             x0, x2, [SP, #-0x10]!
    // 0x6d2fac: mov             x0, x3
    // 0x6d2fb0: mov             lr, x0
    // 0x6d2fb4: ldr             lr, [x21, lr, lsl #3]
    // 0x6d2fb8: blr             lr
    // 0x6d2fbc: add             SP, SP, #0x10
    // 0x6d2fc0: tbnz            w0, #4, #0x6d2fd4
    // 0x6d2fc4: r0 = Null
    //     0x6d2fc4: mov             x0, NULL
    // 0x6d2fc8: LeaveFrame
    //     0x6d2fc8: mov             SP, fp
    //     0x6d2fcc: ldp             fp, lr, [SP], #0x10
    // 0x6d2fd0: ret
    //     0x6d2fd0: ret             
    // 0x6d2fd4: ldr             x1, [fp, #0x18]
    // 0x6d2fd8: ldr             x2, [fp, #0x10]
    // 0x6d2fdc: LoadField: r0 = r1->field_b7
    //     0x6d2fdc: ldur            w0, [x1, #0xb7]
    // 0x6d2fe0: DecompressPointer r0
    //     0x6d2fe0: add             x0, x0, HEAP, lsl #32
    // 0x6d2fe4: cmp             w0, NULL
    // 0x6d2fe8: r16 = true
    //     0x6d2fe8: add             x16, NULL, #0x20  ; true
    // 0x6d2fec: r17 = false
    //     0x6d2fec: add             x17, NULL, #0x30  ; false
    // 0x6d2ff0: csel            x3, x16, x17, ne
    // 0x6d2ff4: mov             x0, x2
    // 0x6d2ff8: StoreField: r1->field_b7 = r0
    //     0x6d2ff8: stur            w0, [x1, #0xb7]
    //     0x6d2ffc: ldurb           w16, [x1, #-1]
    //     0x6d3000: ldurb           w17, [x0, #-1]
    //     0x6d3004: and             x16, x17, x16, lsr #2
    //     0x6d3008: tst             x16, HEAP, lsr #32
    //     0x6d300c: b.eq            #0x6d3014
    //     0x6d3010: bl              #0xd6826c
    // 0x6d3014: cmp             w2, NULL
    // 0x6d3018: r16 = true
    //     0x6d3018: add             x16, NULL, #0x20  ; true
    // 0x6d301c: r17 = false
    //     0x6d301c: add             x17, NULL, #0x30  ; false
    // 0x6d3020: csel            x0, x16, x17, ne
    // 0x6d3024: cmp             w3, w0
    // 0x6d3028: b.eq            #0x6d30b4
    // 0x6d302c: cmp             w2, NULL
    // 0x6d3030: b.eq            #0x6d3064
    // 0x6d3034: LoadField: r0 = r1->field_5f
    //     0x6d3034: ldur            w0, [x1, #0x5f]
    // 0x6d3038: DecompressPointer r0
    //     0x6d3038: add             x0, x0, HEAP, lsl #32
    // 0x6d303c: LoadField: r2 = r0->field_23
    //     0x6d303c: ldur            w2, [x0, #0x23]
    // 0x6d3040: DecompressPointer r2
    //     0x6d3040: add             x2, x2, HEAP, lsl #32
    // 0x6d3044: r16 = Sentinel
    //     0x6d3044: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6d3048: cmp             w2, w16
    // 0x6d304c: b.eq            #0x6d30cc
    // 0x6d3050: SaveReg r2
    //     0x6d3050: str             x2, [SP, #-8]!
    // 0x6d3054: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6d3054: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6d3058: r0 = forward()
    //     0x6d3058: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x6d305c: add             SP, SP, #8
    // 0x6d3060: b               #0x6d3094
    // 0x6d3064: mov             x0, x1
    // 0x6d3068: LoadField: r1 = r0->field_5f
    //     0x6d3068: ldur            w1, [x0, #0x5f]
    // 0x6d306c: DecompressPointer r1
    //     0x6d306c: add             x1, x1, HEAP, lsl #32
    // 0x6d3070: LoadField: r2 = r1->field_23
    //     0x6d3070: ldur            w2, [x1, #0x23]
    // 0x6d3074: DecompressPointer r2
    //     0x6d3074: add             x2, x2, HEAP, lsl #32
    // 0x6d3078: r16 = Sentinel
    //     0x6d3078: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6d307c: cmp             w2, w16
    // 0x6d3080: b.eq            #0x6d30d8
    // 0x6d3084: SaveReg r2
    //     0x6d3084: str             x2, [SP, #-8]!
    // 0x6d3088: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6d3088: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6d308c: r0 = reverse()
    //     0x6d308c: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6d3090: add             SP, SP, #8
    // 0x6d3094: ldr             x16, [fp, #0x18]
    // 0x6d3098: SaveReg r16
    //     0x6d3098: str             x16, [SP, #-8]!
    // 0x6d309c: r0 = markNeedsPaint()
    //     0x6d309c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d30a0: add             SP, SP, #8
    // 0x6d30a4: ldr             x16, [fp, #0x18]
    // 0x6d30a8: SaveReg r16
    //     0x6d30a8: str             x16, [SP, #-8]!
    // 0x6d30ac: r0 = markNeedsSemanticsUpdate()
    //     0x6d30ac: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6d30b0: add             SP, SP, #8
    // 0x6d30b4: r0 = Null
    //     0x6d30b4: mov             x0, NULL
    // 0x6d30b8: LeaveFrame
    //     0x6d30b8: mov             SP, fp
    //     0x6d30bc: ldp             fp, lr, [SP], #0x10
    // 0x6d30c0: ret
    //     0x6d30c0: ret             
    // 0x6d30c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d30c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d30c8: b               #0x6d2f90
    // 0x6d30cc: r9 = enableController
    //     0x6d30cc: add             x9, PP, #0x55, lsl #12  ; [pp+0x55830] Field <_SliderState@810231897.enableController>: late (offset: 0x24)
    //     0x6d30d0: ldr             x9, [x9, #0x830]
    // 0x6d30d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6d30d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6d30d8: r9 = enableController
    //     0x6d30d8: add             x9, PP, #0x55, lsl #12  ; [pp+0x55830] Field <_SliderState@810231897.enableController>: late (offset: 0x24)
    //     0x6d30dc: ldr             x9, [x9, #0x830]
    // 0x6d30e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6d30e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ screenSize=(/* No info */) {
    // ** addr: 0x6d30e4, size: 0xa0
    // 0x6d30e4: EnterFrame
    //     0x6d30e4: stp             fp, lr, [SP, #-0x10]!
    //     0x6d30e8: mov             fp, SP
    // 0x6d30ec: CheckStackOverflow
    //     0x6d30ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d30f0: cmp             SP, x16
    //     0x6d30f4: b.ls            #0x6d317c
    // 0x6d30f8: ldr             x1, [fp, #0x18]
    // 0x6d30fc: LoadField: r0 = r1->field_b3
    //     0x6d30fc: ldur            w0, [x1, #0xb3]
    // 0x6d3100: DecompressPointer r0
    //     0x6d3100: add             x0, x0, HEAP, lsl #32
    // 0x6d3104: LoadField: d0 = r0->field_7
    //     0x6d3104: ldur            d0, [x0, #7]
    // 0x6d3108: ldr             x2, [fp, #0x10]
    // 0x6d310c: LoadField: d1 = r2->field_7
    //     0x6d310c: ldur            d1, [x2, #7]
    // 0x6d3110: fcmp            d0, d1
    // 0x6d3114: b.vs            #0x6d3140
    // 0x6d3118: b.ne            #0x6d3140
    // 0x6d311c: LoadField: d0 = r0->field_f
    //     0x6d311c: ldur            d0, [x0, #0xf]
    // 0x6d3120: LoadField: d1 = r2->field_f
    //     0x6d3120: ldur            d1, [x2, #0xf]
    // 0x6d3124: fcmp            d0, d1
    // 0x6d3128: b.vs            #0x6d3140
    // 0x6d312c: b.ne            #0x6d3140
    // 0x6d3130: r0 = Null
    //     0x6d3130: mov             x0, NULL
    // 0x6d3134: LeaveFrame
    //     0x6d3134: mov             SP, fp
    //     0x6d3138: ldp             fp, lr, [SP], #0x10
    // 0x6d313c: ret
    //     0x6d313c: ret             
    // 0x6d3140: mov             x0, x2
    // 0x6d3144: StoreField: r1->field_b3 = r0
    //     0x6d3144: stur            w0, [x1, #0xb3]
    //     0x6d3148: ldurb           w16, [x1, #-1]
    //     0x6d314c: ldurb           w17, [x0, #-1]
    //     0x6d3150: and             x16, x17, x16, lsr #2
    //     0x6d3154: tst             x16, HEAP, lsr #32
    //     0x6d3158: b.eq            #0x6d3160
    //     0x6d315c: bl              #0xd6826c
    // 0x6d3160: SaveReg r1
    //     0x6d3160: str             x1, [SP, #-8]!
    // 0x6d3164: r0 = markNeedsPaint()
    //     0x6d3164: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d3168: add             SP, SP, #8
    // 0x6d316c: r0 = Null
    //     0x6d316c: mov             x0, NULL
    // 0x6d3170: LeaveFrame
    //     0x6d3170: mov             SP, fp
    //     0x6d3174: ldp             fp, lr, [SP], #0x10
    // 0x6d3178: ret
    //     0x6d3178: ret             
    // 0x6d317c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d317c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3180: b               #0x6d30f8
  }
  set _ textScaleFactor=(/* No info */) {
    // ** addr: 0x6d3184, size: 0x64
    // 0x6d3184: EnterFrame
    //     0x6d3184: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3188: mov             fp, SP
    // 0x6d318c: CheckStackOverflow
    //     0x6d318c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3190: cmp             SP, x16
    //     0x6d3194: b.ls            #0x6d31e0
    // 0x6d3198: ldr             x0, [fp, #0x18]
    // 0x6d319c: LoadField: d0 = r0->field_ab
    //     0x6d319c: ldur            d0, [x0, #0xab]
    // 0x6d31a0: ldr             d1, [fp, #0x10]
    // 0x6d31a4: fcmp            d1, d0
    // 0x6d31a8: b.vs            #0x6d31c0
    // 0x6d31ac: b.ne            #0x6d31c0
    // 0x6d31b0: r0 = Null
    //     0x6d31b0: mov             x0, NULL
    // 0x6d31b4: LeaveFrame
    //     0x6d31b4: mov             SP, fp
    //     0x6d31b8: ldp             fp, lr, [SP], #0x10
    // 0x6d31bc: ret
    //     0x6d31bc: ret             
    // 0x6d31c0: StoreField: r0->field_ab = d1
    //     0x6d31c0: stur            d1, [x0, #0xab]
    // 0x6d31c4: SaveReg r0
    //     0x6d31c4: str             x0, [SP, #-8]!
    // 0x6d31c8: r0 = _updateLabelPainter()
    //     0x6d31c8: bl              #0x6d2f28  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0x6d31cc: add             SP, SP, #8
    // 0x6d31d0: r0 = Null
    //     0x6d31d0: mov             x0, NULL
    // 0x6d31d4: LeaveFrame
    //     0x6d31d4: mov             SP, fp
    //     0x6d31d8: ldp             fp, lr, [SP], #0x10
    // 0x6d31dc: ret
    //     0x6d31dc: ret             
    // 0x6d31e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d31e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d31e4: b               #0x6d3198
  }
  set _ sliderTheme=(/* No info */) {
    // ** addr: 0x6d31e8, size: 0x8c
    // 0x6d31e8: EnterFrame
    //     0x6d31e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6d31ec: mov             fp, SP
    // 0x6d31f0: CheckStackOverflow
    //     0x6d31f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d31f4: cmp             SP, x16
    //     0x6d31f8: b.ls            #0x6d326c
    // 0x6d31fc: ldr             x0, [fp, #0x18]
    // 0x6d3200: LoadField: r1 = r0->field_a7
    //     0x6d3200: ldur            w1, [x0, #0xa7]
    // 0x6d3204: DecompressPointer r1
    //     0x6d3204: add             x1, x1, HEAP, lsl #32
    // 0x6d3208: ldr             x16, [fp, #0x10]
    // 0x6d320c: stp             x1, x16, [SP, #-0x10]!
    // 0x6d3210: r0 = ==()
    //     0x6d3210: bl              #0xc8d930  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::==
    // 0x6d3214: add             SP, SP, #0x10
    // 0x6d3218: tbnz            w0, #4, #0x6d322c
    // 0x6d321c: r0 = Null
    //     0x6d321c: mov             x0, NULL
    // 0x6d3220: LeaveFrame
    //     0x6d3220: mov             SP, fp
    //     0x6d3224: ldp             fp, lr, [SP], #0x10
    // 0x6d3228: ret
    //     0x6d3228: ret             
    // 0x6d322c: ldr             x1, [fp, #0x18]
    // 0x6d3230: ldr             x0, [fp, #0x10]
    // 0x6d3234: StoreField: r1->field_a7 = r0
    //     0x6d3234: stur            w0, [x1, #0xa7]
    //     0x6d3238: ldurb           w16, [x1, #-1]
    //     0x6d323c: ldurb           w17, [x0, #-1]
    //     0x6d3240: and             x16, x17, x16, lsr #2
    //     0x6d3244: tst             x16, HEAP, lsr #32
    //     0x6d3248: b.eq            #0x6d3250
    //     0x6d324c: bl              #0xd6826c
    // 0x6d3250: SaveReg r1
    //     0x6d3250: str             x1, [SP, #-8]!
    // 0x6d3254: r0 = markNeedsPaint()
    //     0x6d3254: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6d3258: add             SP, SP, #8
    // 0x6d325c: r0 = Null
    //     0x6d325c: mov             x0, NULL
    // 0x6d3260: LeaveFrame
    //     0x6d3260: mov             SP, fp
    //     0x6d3264: ldp             fp, lr, [SP], #0x10
    // 0x6d3268: ret
    //     0x6d3268: ret             
    // 0x6d326c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d326c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3270: b               #0x6d31fc
  }
  set _ value=(/* No info */) {
    // ** addr: 0x6d3274, size: 0xa0
    // 0x6d3274: EnterFrame
    //     0x6d3274: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3278: mov             fp, SP
    // 0x6d327c: CheckStackOverflow
    //     0x6d327c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6d3280: cmp             SP, x16
    //     0x6d3284: b.ls            #0x6d3300
    // 0x6d3288: ldr             x0, [fp, #0x18]
    // 0x6d328c: LoadField: d0 = r0->field_8b
    //     0x6d328c: ldur            d0, [x0, #0x8b]
    // 0x6d3290: ldr             d1, [fp, #0x10]
    // 0x6d3294: fcmp            d1, d0
    // 0x6d3298: b.vs            #0x6d32b0
    // 0x6d329c: b.ne            #0x6d32b0
    // 0x6d32a0: r0 = Null
    //     0x6d32a0: mov             x0, NULL
    // 0x6d32a4: LeaveFrame
    //     0x6d32a4: mov             SP, fp
    //     0x6d32a8: ldp             fp, lr, [SP], #0x10
    // 0x6d32ac: ret
    //     0x6d32ac: ret             
    // 0x6d32b0: StoreField: r0->field_8b = d1
    //     0x6d32b0: stur            d1, [x0, #0x8b]
    // 0x6d32b4: LoadField: r1 = r0->field_5f
    //     0x6d32b4: ldur            w1, [x0, #0x5f]
    // 0x6d32b8: DecompressPointer r1
    //     0x6d32b8: add             x1, x1, HEAP, lsl #32
    // 0x6d32bc: LoadField: r2 = r1->field_27
    //     0x6d32bc: ldur            w2, [x1, #0x27]
    // 0x6d32c0: DecompressPointer r2
    //     0x6d32c0: add             x2, x2, HEAP, lsl #32
    // 0x6d32c4: r16 = Sentinel
    //     0x6d32c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6d32c8: cmp             w2, w16
    // 0x6d32cc: b.eq            #0x6d3308
    // 0x6d32d0: SaveReg r2
    //     0x6d32d0: str             x2, [SP, #-8]!
    // 0x6d32d4: SaveReg d1
    //     0x6d32d4: str             d1, [SP, #-8]!
    // 0x6d32d8: r0 = value=()
    //     0x6d32d8: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x6d32dc: add             SP, SP, #0x10
    // 0x6d32e0: ldr             x16, [fp, #0x18]
    // 0x6d32e4: SaveReg r16
    //     0x6d32e4: str             x16, [SP, #-8]!
    // 0x6d32e8: r0 = markNeedsSemanticsUpdate()
    //     0x6d32e8: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6d32ec: add             SP, SP, #8
    // 0x6d32f0: r0 = Null
    //     0x6d32f0: mov             x0, NULL
    // 0x6d32f4: LeaveFrame
    //     0x6d32f4: mov             SP, fp
    //     0x6d32f8: ldp             fp, lr, [SP], #0x10
    // 0x6d32fc: ret
    //     0x6d32fc: ret             
    // 0x6d3300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6d3300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6d3304: b               #0x6d3288
    // 0x6d3308: r9 = positionController
    //     0x6d3308: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0x6d330c: ldr             x9, [x9, #0x838]
    // 0x6d3310: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6d3310: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _RenderSlider(/* No info */) {
    // ** addr: 0x6eebf8, size: 0x674
    // 0x6eebf8: EnterFrame
    //     0x6eebf8: stp             fp, lr, [SP, #-0x10]!
    //     0x6eebfc: mov             fp, SP
    // 0x6eec00: AllocStack(0x18)
    //     0x6eec00: sub             SP, SP, #0x18
    // 0x6eec04: CheckStackOverflow
    //     0x6eec04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eec08: cmp             SP, x16
    //     0x6eec0c: b.ls            #0x6ef240
    // 0x6eec10: r1 = 1
    //     0x6eec10: mov             x1, #1
    // 0x6eec14: r0 = AllocateContext()
    //     0x6eec14: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6eec18: mov             x1, x0
    // 0x6eec1c: ldr             x0, [fp, #0x78]
    // 0x6eec20: stur            x1, [fp, #-8]
    // 0x6eec24: StoreField: r1->field_f = r0
    //     0x6eec24: stur            w0, [x1, #0xf]
    // 0x6eec28: r2 = Sentinel
    //     0x6eec28: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6eec2c: StoreField: r0->field_63 = r2
    //     0x6eec2c: stur            w2, [x0, #0x63]
    // 0x6eec30: StoreField: r0->field_67 = r2
    //     0x6eec30: stur            w2, [x0, #0x67]
    // 0x6eec34: StoreField: r0->field_6b = r2
    //     0x6eec34: stur            w2, [x0, #0x6b]
    // 0x6eec38: StoreField: r0->field_73 = r2
    //     0x6eec38: stur            w2, [x0, #0x73]
    // 0x6eec3c: StoreField: r0->field_77 = r2
    //     0x6eec3c: stur            w2, [x0, #0x77]
    // 0x6eec40: r3 = false
    //     0x6eec40: add             x3, NULL, #0x30  ; false
    // 0x6eec44: StoreField: r0->field_7b = r3
    //     0x6eec44: stur            w3, [x0, #0x7b]
    // 0x6eec48: d0 = 0.000000
    //     0x6eec48: eor             v0.16b, v0.16b, v0.16b
    // 0x6eec4c: StoreField: r0->field_7f = d0
    //     0x6eec4c: stur            d0, [x0, #0x7f]
    // 0x6eec50: StoreField: r0->field_cf = r3
    //     0x6eec50: stur            w3, [x0, #0xcf]
    // 0x6eec54: r0 = TextPainter()
    //     0x6eec54: bl              #0x68dbc4  ; AllocateTextPainterStub -> TextPainter (size=0x68)
    // 0x6eec58: mov             x1, x0
    // 0x6eec5c: r0 = true
    //     0x6eec5c: add             x0, NULL, #0x20  ; true
    // 0x6eec60: StoreField: r1->field_b = r0
    //     0x6eec60: stur            w0, [x1, #0xb]
    // 0x6eec64: r0 = Sentinel
    //     0x6eec64: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6eec68: StoreField: r1->field_57 = r0
    //     0x6eec68: stur            w0, [x1, #0x57]
    // 0x6eec6c: r0 = Instance_TextAlign
    //     0x6eec6c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14fe8] Obj!TextAlign@b66f71
    //     0x6eec70: ldr             x0, [x0, #0xfe8]
    // 0x6eec74: StoreField: r1->field_17 = r0
    //     0x6eec74: stur            w0, [x1, #0x17]
    // 0x6eec78: d0 = 1.000000
    //     0x6eec78: fmov            d0, #1.00000000
    // 0x6eec7c: StoreField: r1->field_1f = d0
    //     0x6eec7c: stur            d0, [x1, #0x1f]
    // 0x6eec80: r0 = Instance_TextWidthBasis
    //     0x6eec80: add             x0, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x6eec84: ldr             x0, [x0, #0x148]
    // 0x6eec88: StoreField: r1->field_37 = r0
    //     0x6eec88: stur            w0, [x1, #0x37]
    // 0x6eec8c: mov             x0, x1
    // 0x6eec90: ldr             x1, [fp, #0x78]
    // 0x6eec94: StoreField: r1->field_6f = r0
    //     0x6eec94: stur            w0, [x1, #0x6f]
    //     0x6eec98: ldurb           w16, [x1, #-1]
    //     0x6eec9c: ldurb           w17, [x0, #-1]
    //     0x6eeca0: and             x16, x17, x16, lsr #2
    //     0x6eeca4: tst             x16, HEAP, lsr #32
    //     0x6eeca8: b.eq            #0x6eecb0
    //     0x6eecac: bl              #0xd6826c
    // 0x6eecb0: ldr             x0, [fp, #0x50]
    // 0x6eecb4: StoreField: r1->field_bb = r0
    //     0x6eecb4: stur            w0, [x1, #0xbb]
    //     0x6eecb8: ldurb           w16, [x1, #-1]
    //     0x6eecbc: ldurb           w17, [x0, #-1]
    //     0x6eecc0: and             x16, x17, x16, lsr #2
    //     0x6eecc4: tst             x16, HEAP, lsr #32
    //     0x6eecc8: b.eq            #0x6eecd0
    //     0x6eeccc: bl              #0xd6826c
    // 0x6eecd0: ldr             x0, [fp, #0x58]
    // 0x6eecd4: StoreField: r1->field_bf = r0
    //     0x6eecd4: stur            w0, [x1, #0xbf]
    //     0x6eecd8: ldurb           w16, [x1, #-1]
    //     0x6eecdc: ldurb           w17, [x0, #-1]
    //     0x6eece0: and             x16, x17, x16, lsr #2
    //     0x6eece4: tst             x16, HEAP, lsr #32
    //     0x6eece8: b.eq            #0x6eecf0
    //     0x6eecec: bl              #0xd6826c
    // 0x6eecf0: ldr             x0, [fp, #0x40]
    // 0x6eecf4: StoreField: r1->field_97 = r0
    //     0x6eecf4: stur            w0, [x1, #0x97]
    //     0x6eecf8: ldurb           w16, [x1, #-1]
    //     0x6eecfc: ldurb           w17, [x0, #-1]
    //     0x6eed00: and             x16, x17, x16, lsr #2
    //     0x6eed04: tst             x16, HEAP, lsr #32
    //     0x6eed08: b.eq            #0x6eed10
    //     0x6eed0c: bl              #0xd6826c
    // 0x6eed10: ldr             d0, [fp, #0x10]
    // 0x6eed14: StoreField: r1->field_8b = d0
    //     0x6eed14: stur            d0, [x1, #0x8b]
    // 0x6eed18: ldr             x0, [fp, #0x30]
    // 0x6eed1c: StoreField: r1->field_a7 = r0
    //     0x6eed1c: stur            w0, [x1, #0xa7]
    //     0x6eed20: ldurb           w16, [x1, #-1]
    //     0x6eed24: ldurb           w17, [x0, #-1]
    //     0x6eed28: and             x16, x17, x16, lsr #2
    //     0x6eed2c: tst             x16, HEAP, lsr #32
    //     0x6eed30: b.eq            #0x6eed38
    //     0x6eed34: bl              #0xd6826c
    // 0x6eed38: ldr             x0, [fp, #0x18]
    // 0x6eed3c: LoadField: d0 = r0->field_7
    //     0x6eed3c: ldur            d0, [x0, #7]
    // 0x6eed40: StoreField: r1->field_ab = d0
    //     0x6eed40: stur            d0, [x1, #0xab]
    // 0x6eed44: ldr             x0, [fp, #0x38]
    // 0x6eed48: StoreField: r1->field_b3 = r0
    //     0x6eed48: stur            w0, [x1, #0xb3]
    //     0x6eed4c: ldurb           w16, [x1, #-1]
    //     0x6eed50: ldurb           w17, [x0, #-1]
    //     0x6eed54: and             x16, x17, x16, lsr #2
    //     0x6eed58: tst             x16, HEAP, lsr #32
    //     0x6eed5c: b.eq            #0x6eed64
    //     0x6eed60: bl              #0xd6826c
    // 0x6eed64: ldr             x0, [fp, #0x48]
    // 0x6eed68: StoreField: r1->field_b7 = r0
    //     0x6eed68: stur            w0, [x1, #0xb7]
    //     0x6eed6c: ldurb           w16, [x1, #-1]
    //     0x6eed70: ldurb           w17, [x0, #-1]
    //     0x6eed74: and             x16, x17, x16, lsr #2
    //     0x6eed78: tst             x16, HEAP, lsr #32
    //     0x6eed7c: b.eq            #0x6eed84
    //     0x6eed80: bl              #0xd6826c
    // 0x6eed84: ldr             x0, [fp, #0x28]
    // 0x6eed88: StoreField: r1->field_5f = r0
    //     0x6eed88: stur            w0, [x1, #0x5f]
    //     0x6eed8c: ldurb           w16, [x1, #-1]
    //     0x6eed90: ldurb           w17, [x0, #-1]
    //     0x6eed94: and             x16, x17, x16, lsr #2
    //     0x6eed98: tst             x16, HEAP, lsr #32
    //     0x6eed9c: b.eq            #0x6eeda4
    //     0x6eeda0: bl              #0xd6826c
    // 0x6eeda4: ldr             x0, [fp, #0x20]
    // 0x6eeda8: StoreField: r1->field_c3 = r0
    //     0x6eeda8: stur            w0, [x1, #0xc3]
    //     0x6eedac: ldurb           w16, [x1, #-1]
    //     0x6eedb0: ldurb           w17, [x0, #-1]
    //     0x6eedb4: and             x16, x17, x16, lsr #2
    //     0x6eedb8: tst             x16, HEAP, lsr #32
    //     0x6eedbc: b.eq            #0x6eedc4
    //     0x6eedc0: bl              #0xd6826c
    // 0x6eedc4: ldr             x0, [fp, #0x68]
    // 0x6eedc8: StoreField: r1->field_c7 = r0
    //     0x6eedc8: stur            w0, [x1, #0xc7]
    // 0x6eedcc: ldr             x0, [fp, #0x60]
    // 0x6eedd0: StoreField: r1->field_cb = r0
    //     0x6eedd0: stur            w0, [x1, #0xcb]
    // 0x6eedd4: SaveReg r1
    //     0x6eedd4: str             x1, [SP, #-8]!
    // 0x6eedd8: r0 = RenderObject()
    //     0x6eedd8: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6eeddc: add             SP, SP, #8
    // 0x6eede0: ldr             x16, [fp, #0x78]
    // 0x6eede4: SaveReg r16
    //     0x6eede4: str             x16, [SP, #-8]!
    // 0x6eede8: r0 = _updateLabelPainter()
    //     0x6eede8: bl              #0x6d2f28  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0x6eedec: add             SP, SP, #8
    // 0x6eedf0: r16 = <int, _CombiningGestureArenaMember>
    //     0x6eedf0: add             x16, PP, #0x49, lsl #12  ; [pp+0x49938] TypeArguments: <int, _CombiningGestureArenaMember>
    //     0x6eedf4: ldr             x16, [x16, #0x938]
    // 0x6eedf8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6eedfc: stp             lr, x16, [SP, #-0x10]!
    // 0x6eee00: r0 = Map._fromLiteral()
    //     0x6eee00: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6eee04: add             SP, SP, #0x10
    // 0x6eee08: stur            x0, [fp, #-0x10]
    // 0x6eee0c: r0 = GestureArenaTeam()
    //     0x6eee0c: bl              #0x6d3ee8  ; AllocateGestureArenaTeamStub -> GestureArenaTeam (size=0x10)
    // 0x6eee10: mov             x1, x0
    // 0x6eee14: ldur            x0, [fp, #-0x10]
    // 0x6eee18: stur            x1, [fp, #-0x18]
    // 0x6eee1c: StoreField: r1->field_7 = r0
    //     0x6eee1c: stur            w0, [x1, #7]
    // 0x6eee20: r0 = HorizontalDragGestureRecognizer()
    //     0x6eee20: bl              #0x6ee4e8  ; AllocateHorizontalDragGestureRecognizerStub -> HorizontalDragGestureRecognizer (size=0x6c)
    // 0x6eee24: stur            x0, [fp, #-0x10]
    // 0x6eee28: stp             NULL, x0, [SP, #-0x10]!
    // 0x6eee2c: r0 = DragGestureRecognizer()
    //     0x6eee2c: bl              #0x6ee278  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0x6eee30: add             SP, SP, #0x10
    // 0x6eee34: ldur            x0, [fp, #-0x18]
    // 0x6eee38: ldur            x1, [fp, #-0x10]
    // 0x6eee3c: StoreField: r1->field_1b = r0
    //     0x6eee3c: stur            w0, [x1, #0x1b]
    //     0x6eee40: ldurb           w16, [x1, #-1]
    //     0x6eee44: ldurb           w17, [x0, #-1]
    //     0x6eee48: and             x16, x17, x16, lsr #2
    //     0x6eee4c: tst             x16, HEAP, lsr #32
    //     0x6eee50: b.eq            #0x6eee58
    //     0x6eee54: bl              #0xd6826c
    // 0x6eee58: r1 = 1
    //     0x6eee58: mov             x1, #1
    // 0x6eee5c: r0 = AllocateContext()
    //     0x6eee5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6eee60: mov             x1, x0
    // 0x6eee64: ldr             x0, [fp, #0x78]
    // 0x6eee68: StoreField: r1->field_f = r0
    //     0x6eee68: stur            w0, [x1, #0xf]
    // 0x6eee6c: mov             x2, x1
    // 0x6eee70: r1 = Function '_handleDragStart@810231897':.
    //     0x6eee70: add             x1, PP, #0x56, lsl #12  ; [pp+0x56430] AnonymousClosure: (0x6f0058), in [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragStart (0x6f00a4)
    //     0x6eee74: ldr             x1, [x1, #0x430]
    // 0x6eee78: r0 = AllocateClosure()
    //     0x6eee78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6eee7c: ldur            x1, [fp, #-0x10]
    // 0x6eee80: StoreField: r1->field_27 = r0
    //     0x6eee80: stur            w0, [x1, #0x27]
    //     0x6eee84: ldurb           w16, [x1, #-1]
    //     0x6eee88: ldurb           w17, [x0, #-1]
    //     0x6eee8c: and             x16, x17, x16, lsr #2
    //     0x6eee90: tst             x16, HEAP, lsr #32
    //     0x6eee94: b.eq            #0x6eee9c
    //     0x6eee98: bl              #0xd6826c
    // 0x6eee9c: r1 = 1
    //     0x6eee9c: mov             x1, #1
    // 0x6eeea0: r0 = AllocateContext()
    //     0x6eeea0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6eeea4: mov             x1, x0
    // 0x6eeea8: ldr             x0, [fp, #0x78]
    // 0x6eeeac: StoreField: r1->field_f = r0
    //     0x6eeeac: stur            w0, [x1, #0xf]
    // 0x6eeeb0: mov             x2, x1
    // 0x6eeeb4: r1 = Function '_handleDragUpdate@810231897':.
    //     0x6eeeb4: add             x1, PP, #0x56, lsl #12  ; [pp+0x56438] AnonymousClosure: (0x6efe84), in [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragUpdate (0x6efed0)
    //     0x6eeeb8: ldr             x1, [x1, #0x438]
    // 0x6eeebc: r0 = AllocateClosure()
    //     0x6eeebc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6eeec0: ldur            x1, [fp, #-0x10]
    // 0x6eeec4: StoreField: r1->field_2b = r0
    //     0x6eeec4: stur            w0, [x1, #0x2b]
    //     0x6eeec8: ldurb           w16, [x1, #-1]
    //     0x6eeecc: ldurb           w17, [x0, #-1]
    //     0x6eeed0: and             x16, x17, x16, lsr #2
    //     0x6eeed4: tst             x16, HEAP, lsr #32
    //     0x6eeed8: b.eq            #0x6eeee0
    //     0x6eeedc: bl              #0xd6826c
    // 0x6eeee0: r1 = 1
    //     0x6eeee0: mov             x1, #1
    // 0x6eeee4: r0 = AllocateContext()
    //     0x6eeee4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6eeee8: mov             x1, x0
    // 0x6eeeec: ldr             x0, [fp, #0x78]
    // 0x6eeef0: StoreField: r1->field_f = r0
    //     0x6eeef0: stur            w0, [x1, #0xf]
    // 0x6eeef4: mov             x2, x1
    // 0x6eeef8: r1 = Function '_handleDragEnd@810231897':.
    //     0x6eeef8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56440] AnonymousClosure: (0x6ef460), of [package:flutter/src/material/slider.dart] _RenderSlider
    //     0x6eeefc: ldr             x1, [x1, #0x440]
    // 0x6eef00: r0 = AllocateClosure()
    //     0x6eef00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6eef04: ldur            x1, [fp, #-0x10]
    // 0x6eef08: StoreField: r1->field_2f = r0
    //     0x6eef08: stur            w0, [x1, #0x2f]
    //     0x6eef0c: ldurb           w16, [x1, #-1]
    //     0x6eef10: ldurb           w17, [x0, #-1]
    //     0x6eef14: and             x16, x17, x16, lsr #2
    //     0x6eef18: tst             x16, HEAP, lsr #32
    //     0x6eef1c: b.eq            #0x6eef24
    //     0x6eef20: bl              #0xd6826c
    // 0x6eef24: r1 = 1
    //     0x6eef24: mov             x1, #1
    // 0x6eef28: r0 = AllocateContext()
    //     0x6eef28: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6eef2c: mov             x1, x0
    // 0x6eef30: ldr             x0, [fp, #0x78]
    // 0x6eef34: StoreField: r1->field_f = r0
    //     0x6eef34: stur            w0, [x1, #0xf]
    // 0x6eef38: mov             x2, x1
    // 0x6eef3c: r1 = Function '_endInteraction@810231897':.
    //     0x6eef3c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56448] AnonymousClosure: (0x6efe3c), in [package:flutter/src/material/slider.dart] _RenderSlider::_endInteraction (0x6ef4ac)
    //     0x6eef40: ldr             x1, [x1, #0x448]
    // 0x6eef44: r0 = AllocateClosure()
    //     0x6eef44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6eef48: ldur            x1, [fp, #-0x10]
    // 0x6eef4c: StoreField: r1->field_33 = r0
    //     0x6eef4c: stur            w0, [x1, #0x33]
    //     0x6eef50: ldurb           w16, [x1, #-1]
    //     0x6eef54: ldurb           w17, [x0, #-1]
    //     0x6eef58: and             x16, x17, x16, lsr #2
    //     0x6eef5c: tst             x16, HEAP, lsr #32
    //     0x6eef60: b.eq            #0x6eef68
    //     0x6eef64: bl              #0xd6826c
    // 0x6eef68: ldr             x0, [fp, #0x70]
    // 0x6eef6c: StoreField: r1->field_7 = r0
    //     0x6eef6c: stur            w0, [x1, #7]
    //     0x6eef70: ldurb           w16, [x1, #-1]
    //     0x6eef74: ldurb           w17, [x0, #-1]
    //     0x6eef78: and             x16, x17, x16, lsr #2
    //     0x6eef7c: tst             x16, HEAP, lsr #32
    //     0x6eef80: b.eq            #0x6eef88
    //     0x6eef84: bl              #0xd6826c
    // 0x6eef88: mov             x0, x1
    // 0x6eef8c: ldr             x1, [fp, #0x78]
    // 0x6eef90: StoreField: r1->field_73 = r0
    //     0x6eef90: stur            w0, [x1, #0x73]
    //     0x6eef94: ldurb           w16, [x1, #-1]
    //     0x6eef98: ldurb           w17, [x0, #-1]
    //     0x6eef9c: and             x16, x17, x16, lsr #2
    //     0x6eefa0: tst             x16, HEAP, lsr #32
    //     0x6eefa4: b.eq            #0x6eefac
    //     0x6eefa8: bl              #0xd6826c
    // 0x6eefac: r0 = TapGestureRecognizer()
    //     0x6eefac: bl              #0x6ef3bc  ; AllocateTapGestureRecognizerStub -> TapGestureRecognizer (size=0x80)
    // 0x6eefb0: mov             x1, x0
    // 0x6eefb4: r0 = false
    //     0x6eefb4: add             x0, NULL, #0x30  ; false
    // 0x6eefb8: stur            x1, [fp, #-0x10]
    // 0x6eefbc: StoreField: r1->field_43 = r0
    //     0x6eefbc: stur            w0, [x1, #0x43]
    // 0x6eefc0: StoreField: r1->field_47 = r0
    //     0x6eefc0: stur            w0, [x1, #0x47]
    // 0x6eefc4: r16 = Instance_Duration
    //     0x6eefc4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x6eefc8: ldr             x16, [x16, #0x9f0]
    // 0x6eefcc: stp             x16, x1, [SP, #-0x10]!
    // 0x6eefd0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6eefd0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6eefd4: r0 = PrimaryPointerGestureRecognizer()
    //     0x6eefd4: bl              #0x6ef26c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::PrimaryPointerGestureRecognizer
    // 0x6eefd8: add             SP, SP, #0x10
    // 0x6eefdc: ldur            x0, [fp, #-0x18]
    // 0x6eefe0: ldur            x1, [fp, #-0x10]
    // 0x6eefe4: StoreField: r1->field_1b = r0
    //     0x6eefe4: stur            w0, [x1, #0x1b]
    //     0x6eefe8: ldurb           w16, [x1, #-1]
    //     0x6eefec: ldurb           w17, [x0, #-1]
    //     0x6eeff0: and             x16, x17, x16, lsr #2
    //     0x6eeff4: tst             x16, HEAP, lsr #32
    //     0x6eeff8: b.eq            #0x6ef000
    //     0x6eeffc: bl              #0xd6826c
    // 0x6ef000: r1 = 1
    //     0x6ef000: mov             x1, #1
    // 0x6ef004: r0 = AllocateContext()
    //     0x6ef004: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ef008: mov             x1, x0
    // 0x6ef00c: ldr             x0, [fp, #0x78]
    // 0x6ef010: StoreField: r1->field_f = r0
    //     0x6ef010: stur            w0, [x1, #0xf]
    // 0x6ef014: mov             x2, x1
    // 0x6ef018: r1 = Function '_handleTapDown@810231897':.
    //     0x6ef018: add             x1, PP, #0x56, lsl #12  ; [pp+0x56450] AnonymousClosure: (0x6ef6a0), in [package:flutter/src/material/slider.dart] _RenderSlider::_handleTapDown (0x6ef6ec)
    //     0x6ef01c: ldr             x1, [x1, #0x450]
    // 0x6ef020: r0 = AllocateClosure()
    //     0x6ef020: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ef024: ldur            x1, [fp, #-0x10]
    // 0x6ef028: StoreField: r1->field_53 = r0
    //     0x6ef028: stur            w0, [x1, #0x53]
    //     0x6ef02c: ldurb           w16, [x1, #-1]
    //     0x6ef030: ldurb           w17, [x0, #-1]
    //     0x6ef034: and             x16, x17, x16, lsr #2
    //     0x6ef038: tst             x16, HEAP, lsr #32
    //     0x6ef03c: b.eq            #0x6ef044
    //     0x6ef040: bl              #0xd6826c
    // 0x6ef044: r1 = 1
    //     0x6ef044: mov             x1, #1
    // 0x6ef048: r0 = AllocateContext()
    //     0x6ef048: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ef04c: mov             x1, x0
    // 0x6ef050: ldr             x0, [fp, #0x78]
    // 0x6ef054: StoreField: r1->field_f = r0
    //     0x6ef054: stur            w0, [x1, #0xf]
    // 0x6ef058: mov             x2, x1
    // 0x6ef05c: r1 = Function '_handleTapUp@810231897':.
    //     0x6ef05c: add             x1, PP, #0x56, lsl #12  ; [pp+0x56458] AnonymousClosure: (0x6ef460), of [package:flutter/src/material/slider.dart] _RenderSlider
    //     0x6ef060: ldr             x1, [x1, #0x458]
    // 0x6ef064: r0 = AllocateClosure()
    //     0x6ef064: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ef068: ldur            x1, [fp, #-0x10]
    // 0x6ef06c: StoreField: r1->field_57 = r0
    //     0x6ef06c: stur            w0, [x1, #0x57]
    //     0x6ef070: ldurb           w16, [x1, #-1]
    //     0x6ef074: ldurb           w17, [x0, #-1]
    //     0x6ef078: and             x16, x17, x16, lsr #2
    //     0x6ef07c: tst             x16, HEAP, lsr #32
    //     0x6ef080: b.eq            #0x6ef088
    //     0x6ef084: bl              #0xd6826c
    // 0x6ef088: ldr             x0, [fp, #0x70]
    // 0x6ef08c: StoreField: r1->field_7 = r0
    //     0x6ef08c: stur            w0, [x1, #7]
    //     0x6ef090: ldurb           w16, [x1, #-1]
    //     0x6ef094: ldurb           w17, [x0, #-1]
    //     0x6ef098: and             x16, x17, x16, lsr #2
    //     0x6ef09c: tst             x16, HEAP, lsr #32
    //     0x6ef0a0: b.eq            #0x6ef0a8
    //     0x6ef0a4: bl              #0xd6826c
    // 0x6ef0a8: mov             x0, x1
    // 0x6ef0ac: ldr             x2, [fp, #0x78]
    // 0x6ef0b0: StoreField: r2->field_77 = r0
    //     0x6ef0b0: stur            w0, [x2, #0x77]
    //     0x6ef0b4: ldurb           w16, [x2, #-1]
    //     0x6ef0b8: ldurb           w17, [x0, #-1]
    //     0x6ef0bc: and             x16, x17, x16, lsr #2
    //     0x6ef0c0: tst             x16, HEAP, lsr #32
    //     0x6ef0c4: b.eq            #0x6ef0cc
    //     0x6ef0c8: bl              #0xd6828c
    // 0x6ef0cc: ldr             x0, [fp, #0x28]
    // 0x6ef0d0: LoadField: r3 = r0->field_1b
    //     0x6ef0d0: ldur            w3, [x0, #0x1b]
    // 0x6ef0d4: DecompressPointer r3
    //     0x6ef0d4: add             x3, x3, HEAP, lsl #32
    // 0x6ef0d8: r16 = Sentinel
    //     0x6ef0d8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef0dc: cmp             w3, w16
    // 0x6ef0e0: b.eq            #0x6ef248
    // 0x6ef0e4: stur            x3, [fp, #-0x10]
    // 0x6ef0e8: r1 = <double>
    //     0x6ef0e8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6ef0ec: r0 = CurvedAnimation()
    //     0x6ef0ec: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6ef0f0: stur            x0, [fp, #-0x18]
    // 0x6ef0f4: r16 = Instance_Cubic
    //     0x6ef0f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x6ef0f8: ldr             x16, [x16, #0x2c8]
    // 0x6ef0fc: stp             x16, x0, [SP, #-0x10]!
    // 0x6ef100: ldur            x16, [fp, #-0x10]
    // 0x6ef104: SaveReg r16
    //     0x6ef104: str             x16, [SP, #-8]!
    // 0x6ef108: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6ef108: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6ef10c: r0 = CurvedAnimation()
    //     0x6ef10c: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6ef110: add             SP, SP, #0x18
    // 0x6ef114: ldur            x0, [fp, #-0x18]
    // 0x6ef118: ldr             x2, [fp, #0x78]
    // 0x6ef11c: StoreField: r2->field_63 = r0
    //     0x6ef11c: stur            w0, [x2, #0x63]
    //     0x6ef120: ldurb           w16, [x2, #-1]
    //     0x6ef124: ldurb           w17, [x0, #-1]
    //     0x6ef128: and             x16, x17, x16, lsr #2
    //     0x6ef12c: tst             x16, HEAP, lsr #32
    //     0x6ef130: b.eq            #0x6ef138
    //     0x6ef134: bl              #0xd6828c
    // 0x6ef138: ldr             x0, [fp, #0x28]
    // 0x6ef13c: LoadField: r3 = r0->field_1f
    //     0x6ef13c: ldur            w3, [x0, #0x1f]
    // 0x6ef140: DecompressPointer r3
    //     0x6ef140: add             x3, x3, HEAP, lsl #32
    // 0x6ef144: r16 = Sentinel
    //     0x6ef144: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef148: cmp             w3, w16
    // 0x6ef14c: b.eq            #0x6ef254
    // 0x6ef150: stur            x3, [fp, #-0x10]
    // 0x6ef154: r1 = <double>
    //     0x6ef154: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6ef158: r0 = CurvedAnimation()
    //     0x6ef158: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6ef15c: stur            x0, [fp, #-0x18]
    // 0x6ef160: r16 = Instance_Cubic
    //     0x6ef160: add             x16, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x6ef164: ldr             x16, [x16, #0x2c8]
    // 0x6ef168: stp             x16, x0, [SP, #-0x10]!
    // 0x6ef16c: ldur            x16, [fp, #-0x10]
    // 0x6ef170: SaveReg r16
    //     0x6ef170: str             x16, [SP, #-8]!
    // 0x6ef174: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6ef174: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6ef178: r0 = CurvedAnimation()
    //     0x6ef178: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6ef17c: add             SP, SP, #0x18
    // 0x6ef180: ldur            x2, [fp, #-8]
    // 0x6ef184: r1 = Function '<anonymous closure>':.
    //     0x6ef184: add             x1, PP, #0x56, lsl #12  ; [pp+0x56460] AnonymousClosure: (0x6ef3c8), in [package:flutter/src/material/slider.dart] _RenderSlider::_RenderSlider (0x6eebf8)
    //     0x6ef188: ldr             x1, [x1, #0x460]
    // 0x6ef18c: r0 = AllocateClosure()
    //     0x6ef18c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ef190: ldur            x16, [fp, #-0x18]
    // 0x6ef194: stp             x0, x16, [SP, #-0x10]!
    // 0x6ef198: r0 = addStatusListener()
    //     0x6ef198: bl              #0xc52944  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addStatusListener
    // 0x6ef19c: add             SP, SP, #0x10
    // 0x6ef1a0: ldur            x0, [fp, #-0x18]
    // 0x6ef1a4: ldr             x2, [fp, #0x78]
    // 0x6ef1a8: StoreField: r2->field_67 = r0
    //     0x6ef1a8: stur            w0, [x2, #0x67]
    //     0x6ef1ac: ldurb           w16, [x2, #-1]
    //     0x6ef1b0: ldurb           w17, [x0, #-1]
    //     0x6ef1b4: and             x16, x17, x16, lsr #2
    //     0x6ef1b8: tst             x16, HEAP, lsr #32
    //     0x6ef1bc: b.eq            #0x6ef1c4
    //     0x6ef1c0: bl              #0xd6828c
    // 0x6ef1c4: ldr             x0, [fp, #0x28]
    // 0x6ef1c8: LoadField: r3 = r0->field_23
    //     0x6ef1c8: ldur            w3, [x0, #0x23]
    // 0x6ef1cc: DecompressPointer r3
    //     0x6ef1cc: add             x3, x3, HEAP, lsl #32
    // 0x6ef1d0: r16 = Sentinel
    //     0x6ef1d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef1d4: cmp             w3, w16
    // 0x6ef1d8: b.eq            #0x6ef260
    // 0x6ef1dc: stur            x3, [fp, #-8]
    // 0x6ef1e0: r1 = <double>
    //     0x6ef1e0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6ef1e4: r0 = CurvedAnimation()
    //     0x6ef1e4: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x6ef1e8: stur            x0, [fp, #-0x10]
    // 0x6ef1ec: r16 = Instance_Cubic
    //     0x6ef1ec: add             x16, PP, #0x20, lsl #12  ; [pp+0x20770] Obj!Cubic<double>@b4f371
    //     0x6ef1f0: ldr             x16, [x16, #0x770]
    // 0x6ef1f4: stp             x16, x0, [SP, #-0x10]!
    // 0x6ef1f8: ldur            x16, [fp, #-8]
    // 0x6ef1fc: SaveReg r16
    //     0x6ef1fc: str             x16, [SP, #-8]!
    // 0x6ef200: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6ef200: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6ef204: r0 = CurvedAnimation()
    //     0x6ef204: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x6ef208: add             SP, SP, #0x18
    // 0x6ef20c: ldur            x0, [fp, #-0x10]
    // 0x6ef210: ldr             x1, [fp, #0x78]
    // 0x6ef214: StoreField: r1->field_6b = r0
    //     0x6ef214: stur            w0, [x1, #0x6b]
    //     0x6ef218: ldurb           w16, [x1, #-1]
    //     0x6ef21c: ldurb           w17, [x0, #-1]
    //     0x6ef220: and             x16, x17, x16, lsr #2
    //     0x6ef224: tst             x16, HEAP, lsr #32
    //     0x6ef228: b.eq            #0x6ef230
    //     0x6ef22c: bl              #0xd6826c
    // 0x6ef230: r0 = Null
    //     0x6ef230: mov             x0, NULL
    // 0x6ef234: LeaveFrame
    //     0x6ef234: mov             SP, fp
    //     0x6ef238: ldp             fp, lr, [SP], #0x10
    // 0x6ef23c: ret
    //     0x6ef23c: ret             
    // 0x6ef240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef244: b               #0x6eec10
    // 0x6ef248: r9 = overlayController
    //     0x6ef248: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6ef24c: ldr             x9, [x9, #0x820]
    // 0x6ef250: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef250: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6ef254: r9 = valueIndicatorController
    //     0x6ef254: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6ef258: ldr             x9, [x9, #0x828]
    // 0x6ef25c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef25c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6ef260: r9 = enableController
    //     0x6ef260: add             x9, PP, #0x55, lsl #12  ; [pp+0x55830] Field <_SliderState@810231897.enableController>: late (offset: 0x24)
    //     0x6ef264: ldr             x9, [x9, #0x830]
    // 0x6ef268: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef268: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, AnimationStatus) {
    // ** addr: 0x6ef3c8, size: 0x98
    // 0x6ef3c8: EnterFrame
    //     0x6ef3c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef3cc: mov             fp, SP
    // 0x6ef3d0: AllocStack(0x8)
    //     0x6ef3d0: sub             SP, SP, #8
    // 0x6ef3d4: SetupParameters()
    //     0x6ef3d4: ldr             x0, [fp, #0x18]
    //     0x6ef3d8: ldur            w1, [x0, #0x17]
    //     0x6ef3dc: add             x1, x1, HEAP, lsl #32
    //     0x6ef3e0: stur            x1, [fp, #-8]
    // 0x6ef3e4: CheckStackOverflow
    //     0x6ef3e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef3e8: cmp             SP, x16
    //     0x6ef3ec: b.ls            #0x6ef458
    // 0x6ef3f0: ldr             x0, [fp, #0x10]
    // 0x6ef3f4: r16 = Instance_AnimationStatus
    //     0x6ef3f4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x6ef3f8: ldr             x16, [x16, #0xba8]
    // 0x6ef3fc: cmp             w0, w16
    // 0x6ef400: b.ne            #0x6ef448
    // 0x6ef404: LoadField: r0 = r1->field_f
    //     0x6ef404: ldur            w0, [x1, #0xf]
    // 0x6ef408: DecompressPointer r0
    //     0x6ef408: add             x0, x0, HEAP, lsl #32
    // 0x6ef40c: LoadField: r2 = r0->field_5f
    //     0x6ef40c: ldur            w2, [x0, #0x5f]
    // 0x6ef410: DecompressPointer r2
    //     0x6ef410: add             x2, x2, HEAP, lsl #32
    // 0x6ef414: LoadField: r0 = r2->field_4f
    //     0x6ef414: ldur            w0, [x2, #0x4f]
    // 0x6ef418: DecompressPointer r0
    //     0x6ef418: add             x0, x0, HEAP, lsl #32
    // 0x6ef41c: cmp             w0, NULL
    // 0x6ef420: b.eq            #0x6ef448
    // 0x6ef424: SaveReg r0
    //     0x6ef424: str             x0, [SP, #-8]!
    // 0x6ef428: r0 = remove()
    //     0x6ef428: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x6ef42c: add             SP, SP, #8
    // 0x6ef430: ldur            x1, [fp, #-8]
    // 0x6ef434: LoadField: r2 = r1->field_f
    //     0x6ef434: ldur            w2, [x1, #0xf]
    // 0x6ef438: DecompressPointer r2
    //     0x6ef438: add             x2, x2, HEAP, lsl #32
    // 0x6ef43c: LoadField: r1 = r2->field_5f
    //     0x6ef43c: ldur            w1, [x2, #0x5f]
    // 0x6ef440: DecompressPointer r1
    //     0x6ef440: add             x1, x1, HEAP, lsl #32
    // 0x6ef444: StoreField: r1->field_4f = rNULL
    //     0x6ef444: stur            NULL, [x1, #0x4f]
    // 0x6ef448: r0 = Null
    //     0x6ef448: mov             x0, NULL
    // 0x6ef44c: LeaveFrame
    //     0x6ef44c: mov             SP, fp
    //     0x6ef450: ldp             fp, lr, [SP], #0x10
    // 0x6ef454: ret
    //     0x6ef454: ret             
    // 0x6ef458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef45c: b               #0x6ef3f0
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x6ef460, size: 0x4c
    // 0x6ef460: EnterFrame
    //     0x6ef460: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef464: mov             fp, SP
    // 0x6ef468: ldr             x0, [fp, #0x18]
    // 0x6ef46c: LoadField: r1 = r0->field_17
    //     0x6ef46c: ldur            w1, [x0, #0x17]
    // 0x6ef470: DecompressPointer r1
    //     0x6ef470: add             x1, x1, HEAP, lsl #32
    // 0x6ef474: CheckStackOverflow
    //     0x6ef474: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef478: cmp             SP, x16
    //     0x6ef47c: b.ls            #0x6ef4a4
    // 0x6ef480: LoadField: r0 = r1->field_f
    //     0x6ef480: ldur            w0, [x1, #0xf]
    // 0x6ef484: DecompressPointer r0
    //     0x6ef484: add             x0, x0, HEAP, lsl #32
    // 0x6ef488: SaveReg r0
    //     0x6ef488: str             x0, [SP, #-8]!
    // 0x6ef48c: r0 = _endInteraction()
    //     0x6ef48c: bl              #0x6ef4ac  ; [package:flutter/src/material/slider.dart] _RenderSlider::_endInteraction
    // 0x6ef490: add             SP, SP, #8
    // 0x6ef494: r0 = Null
    //     0x6ef494: mov             x0, NULL
    // 0x6ef498: LeaveFrame
    //     0x6ef498: mov             SP, fp
    //     0x6ef49c: ldp             fp, lr, [SP], #0x10
    // 0x6ef4a0: ret
    //     0x6ef4a0: ret             
    // 0x6ef4a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef4a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef4a8: b               #0x6ef480
  }
  _ _endInteraction(/* No info */) {
    // ** addr: 0x6ef4ac, size: 0x1a8
    // 0x6ef4ac: EnterFrame
    //     0x6ef4ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef4b0: mov             fp, SP
    // 0x6ef4b4: AllocStack(0x10)
    //     0x6ef4b4: sub             SP, SP, #0x10
    // 0x6ef4b8: CheckStackOverflow
    //     0x6ef4b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef4bc: cmp             SP, x16
    //     0x6ef4c0: b.ls            #0x6ef624
    // 0x6ef4c4: ldr             x0, [fp, #0x10]
    // 0x6ef4c8: LoadField: r1 = r0->field_5f
    //     0x6ef4c8: ldur            w1, [x0, #0x5f]
    // 0x6ef4cc: DecompressPointer r1
    //     0x6ef4cc: add             x1, x1, HEAP, lsl #32
    // 0x6ef4d0: stur            x1, [fp, #-0x10]
    // 0x6ef4d4: LoadField: r2 = r1->field_f
    //     0x6ef4d4: ldur            w2, [x1, #0xf]
    // 0x6ef4d8: DecompressPointer r2
    //     0x6ef4d8: add             x2, x2, HEAP, lsl #32
    // 0x6ef4dc: cmp             w2, NULL
    // 0x6ef4e0: b.ne            #0x6ef4f4
    // 0x6ef4e4: r0 = Null
    //     0x6ef4e4: mov             x0, NULL
    // 0x6ef4e8: LeaveFrame
    //     0x6ef4e8: mov             SP, fp
    //     0x6ef4ec: ldp             fp, lr, [SP], #0x10
    // 0x6ef4f0: ret
    //     0x6ef4f0: ret             
    // 0x6ef4f4: LoadField: r2 = r0->field_7b
    //     0x6ef4f4: ldur            w2, [x0, #0x7b]
    // 0x6ef4f8: DecompressPointer r2
    //     0x6ef4f8: add             x2, x2, HEAP, lsl #32
    // 0x6ef4fc: tbnz            w2, #4, #0x6ef614
    // 0x6ef500: LoadField: r2 = r0->field_bf
    //     0x6ef500: ldur            w2, [x0, #0xbf]
    // 0x6ef504: DecompressPointer r2
    //     0x6ef504: add             x2, x2, HEAP, lsl #32
    // 0x6ef508: stur            x2, [fp, #-8]
    // 0x6ef50c: cmp             w2, NULL
    // 0x6ef510: b.eq            #0x6ef570
    // 0x6ef514: LoadField: d0 = r0->field_7f
    //     0x6ef514: ldur            d0, [x0, #0x7f]
    // 0x6ef518: SaveReg r0
    //     0x6ef518: str             x0, [SP, #-8]!
    // 0x6ef51c: SaveReg d0
    //     0x6ef51c: str             d0, [SP, #-8]!
    // 0x6ef520: r0 = _discretize()
    //     0x6ef520: bl              #0x6ef654  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x6ef524: add             SP, SP, #0x10
    // 0x6ef528: r0 = inline_Allocate_Double()
    //     0x6ef528: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6ef52c: add             x0, x0, #0x10
    //     0x6ef530: cmp             x1, x0
    //     0x6ef534: b.ls            #0x6ef62c
    //     0x6ef538: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ef53c: sub             x0, x0, #0xf
    //     0x6ef540: mov             x1, #0xd108
    //     0x6ef544: movk            x1, #3, lsl #16
    //     0x6ef548: stur            x1, [x0, #-1]
    // 0x6ef54c: StoreField: r0->field_7 = d0
    //     0x6ef54c: stur            d0, [x0, #7]
    // 0x6ef550: ldur            x16, [fp, #-8]
    // 0x6ef554: stp             x0, x16, [SP, #-0x10]!
    // 0x6ef558: ldur            x0, [fp, #-8]
    // 0x6ef55c: ClosureCall
    //     0x6ef55c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ef560: ldur            x2, [x0, #0x1f]
    //     0x6ef564: blr             x2
    // 0x6ef568: add             SP, SP, #0x10
    // 0x6ef56c: ldr             x0, [fp, #0x10]
    // 0x6ef570: r1 = false
    //     0x6ef570: add             x1, NULL, #0x30  ; false
    // 0x6ef574: d0 = 0.000000
    //     0x6ef574: eor             v0.16b, v0.16b, v0.16b
    // 0x6ef578: StoreField: r0->field_7b = r1
    //     0x6ef578: stur            w1, [x0, #0x7b]
    // 0x6ef57c: StoreField: r0->field_7f = d0
    //     0x6ef57c: stur            d0, [x0, #0x7f]
    // 0x6ef580: LoadField: r1 = r0->field_c7
    //     0x6ef580: ldur            w1, [x0, #0xc7]
    // 0x6ef584: DecompressPointer r1
    //     0x6ef584: add             x1, x1, HEAP, lsl #32
    // 0x6ef588: tbz             w1, #4, #0x6ef5b4
    // 0x6ef58c: ldur            x1, [fp, #-0x10]
    // 0x6ef590: LoadField: r2 = r1->field_1b
    //     0x6ef590: ldur            w2, [x1, #0x1b]
    // 0x6ef594: DecompressPointer r2
    //     0x6ef594: add             x2, x2, HEAP, lsl #32
    // 0x6ef598: r16 = Sentinel
    //     0x6ef598: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef59c: cmp             w2, w16
    // 0x6ef5a0: b.eq            #0x6ef63c
    // 0x6ef5a4: SaveReg r2
    //     0x6ef5a4: str             x2, [SP, #-8]!
    // 0x6ef5a8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ef5a8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ef5ac: r0 = reverse()
    //     0x6ef5ac: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6ef5b0: add             SP, SP, #8
    // 0x6ef5b4: ldr             x16, [fp, #0x10]
    // 0x6ef5b8: SaveReg r16
    //     0x6ef5b8: str             x16, [SP, #-8]!
    // 0x6ef5bc: r0 = showValueIndicator()
    //     0x6ef5bc: bl              #0x6cba2c  ; [package:flutter/src/material/slider.dart] _RenderSlider::showValueIndicator
    // 0x6ef5c0: add             SP, SP, #8
    // 0x6ef5c4: mov             x1, x0
    // 0x6ef5c8: stur            x1, [fp, #-8]
    // 0x6ef5cc: tbnz            w0, #5, #0x6ef5d4
    // 0x6ef5d0: r0 = AssertBoolean()
    //     0x6ef5d0: bl              #0xd67df0  ; AssertBooleanStub
    // 0x6ef5d4: ldur            x0, [fp, #-8]
    // 0x6ef5d8: tbnz            w0, #4, #0x6ef614
    // 0x6ef5dc: ldur            x0, [fp, #-0x10]
    // 0x6ef5e0: LoadField: r1 = r0->field_2b
    //     0x6ef5e0: ldur            w1, [x0, #0x2b]
    // 0x6ef5e4: DecompressPointer r1
    //     0x6ef5e4: add             x1, x1, HEAP, lsl #32
    // 0x6ef5e8: cmp             w1, NULL
    // 0x6ef5ec: b.ne            #0x6ef614
    // 0x6ef5f0: LoadField: r1 = r0->field_1f
    //     0x6ef5f0: ldur            w1, [x0, #0x1f]
    // 0x6ef5f4: DecompressPointer r1
    //     0x6ef5f4: add             x1, x1, HEAP, lsl #32
    // 0x6ef5f8: r16 = Sentinel
    //     0x6ef5f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef5fc: cmp             w1, w16
    // 0x6ef600: b.eq            #0x6ef648
    // 0x6ef604: SaveReg r1
    //     0x6ef604: str             x1, [SP, #-8]!
    // 0x6ef608: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ef608: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ef60c: r0 = reverse()
    //     0x6ef60c: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6ef610: add             SP, SP, #8
    // 0x6ef614: r0 = Null
    //     0x6ef614: mov             x0, NULL
    // 0x6ef618: LeaveFrame
    //     0x6ef618: mov             SP, fp
    //     0x6ef61c: ldp             fp, lr, [SP], #0x10
    // 0x6ef620: ret
    //     0x6ef620: ret             
    // 0x6ef624: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef624: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef628: b               #0x6ef4c4
    // 0x6ef62c: SaveReg d0
    //     0x6ef62c: str             q0, [SP, #-0x10]!
    // 0x6ef630: r0 = AllocateDouble()
    //     0x6ef630: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6ef634: RestoreReg d0
    //     0x6ef634: ldr             q0, [SP], #0x10
    // 0x6ef638: b               #0x6ef54c
    // 0x6ef63c: r9 = overlayController
    //     0x6ef63c: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6ef640: ldr             x9, [x9, #0x820]
    // 0x6ef644: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef644: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6ef648: r9 = valueIndicatorController
    //     0x6ef648: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6ef64c: ldr             x9, [x9, #0x828]
    // 0x6ef650: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef650: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _discretize(/* No info */) {
    // ** addr: 0x6ef654, size: 0x4c
    // 0x6ef654: d1 = 0.000000
    //     0x6ef654: eor             v1.16b, v1.16b, v1.16b
    // 0x6ef658: ldr             d2, [SP]
    // 0x6ef65c: fcmp            d2, d1
    // 0x6ef660: b.vs            #0x6ef670
    // 0x6ef664: b.ge            #0x6ef670
    // 0x6ef668: d0 = 0.000000
    //     0x6ef668: eor             v0.16b, v0.16b, v0.16b
    // 0x6ef66c: b               #0x6ef69c
    // 0x6ef670: d1 = 1.000000
    //     0x6ef670: fmov            d1, #1.00000000
    // 0x6ef674: fcmp            d2, d1
    // 0x6ef678: b.vs            #0x6ef688
    // 0x6ef67c: b.le            #0x6ef688
    // 0x6ef680: d0 = 1.000000
    //     0x6ef680: fmov            d0, #1.00000000
    // 0x6ef684: b               #0x6ef69c
    // 0x6ef688: fcmp            d2, d2
    // 0x6ef68c: b.vc            #0x6ef698
    // 0x6ef690: d0 = 1.000000
    //     0x6ef690: fmov            d0, #1.00000000
    // 0x6ef694: b               #0x6ef69c
    // 0x6ef698: mov             v0.16b, v2.16b
    // 0x6ef69c: ret
    //     0x6ef69c: ret             
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x6ef6a0, size: 0x4c
    // 0x6ef6a0: EnterFrame
    //     0x6ef6a0: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef6a4: mov             fp, SP
    // 0x6ef6a8: ldr             x0, [fp, #0x18]
    // 0x6ef6ac: LoadField: r1 = r0->field_17
    //     0x6ef6ac: ldur            w1, [x0, #0x17]
    // 0x6ef6b0: DecompressPointer r1
    //     0x6ef6b0: add             x1, x1, HEAP, lsl #32
    // 0x6ef6b4: CheckStackOverflow
    //     0x6ef6b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef6b8: cmp             SP, x16
    //     0x6ef6bc: b.ls            #0x6ef6e4
    // 0x6ef6c0: LoadField: r0 = r1->field_f
    //     0x6ef6c0: ldur            w0, [x1, #0xf]
    // 0x6ef6c4: DecompressPointer r0
    //     0x6ef6c4: add             x0, x0, HEAP, lsl #32
    // 0x6ef6c8: ldr             x16, [fp, #0x10]
    // 0x6ef6cc: stp             x16, x0, [SP, #-0x10]!
    // 0x6ef6d0: r0 = _handleTapDown()
    //     0x6ef6d0: bl              #0x6ef6ec  ; [package:flutter/src/material/slider.dart] _RenderSlider::_handleTapDown
    // 0x6ef6d4: add             SP, SP, #0x10
    // 0x6ef6d8: LeaveFrame
    //     0x6ef6d8: mov             SP, fp
    //     0x6ef6dc: ldp             fp, lr, [SP], #0x10
    // 0x6ef6e0: ret
    //     0x6ef6e0: ret             
    // 0x6ef6e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef6e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef6e8: b               #0x6ef6c0
  }
  _ _handleTapDown(/* No info */) {
    // ** addr: 0x6ef6ec, size: 0x48
    // 0x6ef6ec: EnterFrame
    //     0x6ef6ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef6f0: mov             fp, SP
    // 0x6ef6f4: CheckStackOverflow
    //     0x6ef6f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef6f8: cmp             SP, x16
    //     0x6ef6fc: b.ls            #0x6ef72c
    // 0x6ef700: ldr             x0, [fp, #0x10]
    // 0x6ef704: LoadField: r1 = r0->field_7
    //     0x6ef704: ldur            w1, [x0, #7]
    // 0x6ef708: DecompressPointer r1
    //     0x6ef708: add             x1, x1, HEAP, lsl #32
    // 0x6ef70c: ldr             x16, [fp, #0x18]
    // 0x6ef710: stp             x1, x16, [SP, #-0x10]!
    // 0x6ef714: r0 = _startInteraction()
    //     0x6ef714: bl              #0x6ef734  ; [package:flutter/src/material/slider.dart] _RenderSlider::_startInteraction
    // 0x6ef718: add             SP, SP, #0x10
    // 0x6ef71c: r0 = Null
    //     0x6ef71c: mov             x0, NULL
    // 0x6ef720: LeaveFrame
    //     0x6ef720: mov             SP, fp
    //     0x6ef724: ldp             fp, lr, [SP], #0x10
    // 0x6ef728: ret
    //     0x6ef728: ret             
    // 0x6ef72c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef72c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef730: b               #0x6ef700
  }
  _ _startInteraction(/* No info */) {
    // ** addr: 0x6ef734, size: 0x2b8
    // 0x6ef734: EnterFrame
    //     0x6ef734: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef738: mov             fp, SP
    // 0x6ef73c: AllocStack(0x18)
    //     0x6ef73c: sub             SP, SP, #0x18
    // 0x6ef740: CheckStackOverflow
    //     0x6ef740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef744: cmp             SP, x16
    //     0x6ef748: b.ls            #0x6ef9a8
    // 0x6ef74c: r1 = 1
    //     0x6ef74c: mov             x1, #1
    // 0x6ef750: r0 = AllocateContext()
    //     0x6ef750: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ef754: mov             x1, x0
    // 0x6ef758: ldr             x0, [fp, #0x18]
    // 0x6ef75c: stur            x1, [fp, #-0x10]
    // 0x6ef760: StoreField: r1->field_f = r0
    //     0x6ef760: stur            w0, [x1, #0xf]
    // 0x6ef764: LoadField: r2 = r0->field_5f
    //     0x6ef764: ldur            w2, [x0, #0x5f]
    // 0x6ef768: DecompressPointer r2
    //     0x6ef768: add             x2, x2, HEAP, lsl #32
    // 0x6ef76c: stur            x2, [fp, #-8]
    // 0x6ef770: SaveReg r2
    //     0x6ef770: str             x2, [SP, #-8]!
    // 0x6ef774: r0 = showValueIndicator()
    //     0x6ef774: bl              #0x6efbc4  ; [package:flutter/src/material/slider.dart] _SliderState::showValueIndicator
    // 0x6ef778: add             SP, SP, #8
    // 0x6ef77c: ldr             x0, [fp, #0x18]
    // 0x6ef780: LoadField: r1 = r0->field_7b
    //     0x6ef780: ldur            w1, [x0, #0x7b]
    // 0x6ef784: DecompressPointer r1
    //     0x6ef784: add             x1, x1, HEAP, lsl #32
    // 0x6ef788: tbz             w1, #4, #0x6ef998
    // 0x6ef78c: LoadField: r1 = r0->field_b7
    //     0x6ef78c: ldur            w1, [x0, #0xb7]
    // 0x6ef790: DecompressPointer r1
    //     0x6ef790: add             x1, x1, HEAP, lsl #32
    // 0x6ef794: cmp             w1, NULL
    // 0x6ef798: b.eq            #0x6ef998
    // 0x6ef79c: r1 = true
    //     0x6ef79c: add             x1, NULL, #0x20  ; true
    // 0x6ef7a0: StoreField: r0->field_7b = r1
    //     0x6ef7a0: stur            w1, [x0, #0x7b]
    // 0x6ef7a4: LoadField: r1 = r0->field_bb
    //     0x6ef7a4: ldur            w1, [x0, #0xbb]
    // 0x6ef7a8: DecompressPointer r1
    //     0x6ef7a8: add             x1, x1, HEAP, lsl #32
    // 0x6ef7ac: stur            x1, [fp, #-0x18]
    // 0x6ef7b0: cmp             w1, NULL
    // 0x6ef7b4: b.eq            #0x6ef814
    // 0x6ef7b8: LoadField: d0 = r0->field_8b
    //     0x6ef7b8: ldur            d0, [x0, #0x8b]
    // 0x6ef7bc: SaveReg r0
    //     0x6ef7bc: str             x0, [SP, #-8]!
    // 0x6ef7c0: SaveReg d0
    //     0x6ef7c0: str             d0, [SP, #-8]!
    // 0x6ef7c4: r0 = _discretize()
    //     0x6ef7c4: bl              #0x6ef654  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x6ef7c8: add             SP, SP, #0x10
    // 0x6ef7cc: r0 = inline_Allocate_Double()
    //     0x6ef7cc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6ef7d0: add             x0, x0, #0x10
    //     0x6ef7d4: cmp             x1, x0
    //     0x6ef7d8: b.ls            #0x6ef9b0
    //     0x6ef7dc: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ef7e0: sub             x0, x0, #0xf
    //     0x6ef7e4: mov             x1, #0xd108
    //     0x6ef7e8: movk            x1, #3, lsl #16
    //     0x6ef7ec: stur            x1, [x0, #-1]
    // 0x6ef7f0: StoreField: r0->field_7 = d0
    //     0x6ef7f0: stur            d0, [x0, #7]
    // 0x6ef7f4: ldur            x16, [fp, #-0x18]
    // 0x6ef7f8: stp             x0, x16, [SP, #-0x10]!
    // 0x6ef7fc: ldur            x0, [fp, #-0x18]
    // 0x6ef800: ClosureCall
    //     0x6ef800: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ef804: ldur            x2, [x0, #0x1f]
    //     0x6ef808: blr             x2
    // 0x6ef80c: add             SP, SP, #0x10
    // 0x6ef810: ldr             x0, [fp, #0x18]
    // 0x6ef814: ldur            x1, [fp, #-8]
    // 0x6ef818: ldr             x16, [fp, #0x10]
    // 0x6ef81c: stp             x16, x0, [SP, #-0x10]!
    // 0x6ef820: r0 = _getValueFromGlobalPosition()
    //     0x6ef820: bl              #0x6ef9ec  ; [package:flutter/src/material/slider.dart] _RenderSlider::_getValueFromGlobalPosition
    // 0x6ef824: add             SP, SP, #0x10
    // 0x6ef828: LoadField: d0 = r0->field_7
    //     0x6ef828: ldur            d0, [x0, #7]
    // 0x6ef82c: ldr             x0, [fp, #0x18]
    // 0x6ef830: StoreField: r0->field_7f = d0
    //     0x6ef830: stur            d0, [x0, #0x7f]
    // 0x6ef834: LoadField: r1 = r0->field_b7
    //     0x6ef834: ldur            w1, [x0, #0xb7]
    // 0x6ef838: DecompressPointer r1
    //     0x6ef838: add             x1, x1, HEAP, lsl #32
    // 0x6ef83c: stur            x1, [fp, #-0x18]
    // 0x6ef840: cmp             w1, NULL
    // 0x6ef844: b.eq            #0x6ef9c0
    // 0x6ef848: SaveReg r0
    //     0x6ef848: str             x0, [SP, #-8]!
    // 0x6ef84c: SaveReg d0
    //     0x6ef84c: str             d0, [SP, #-8]!
    // 0x6ef850: r0 = _discretize()
    //     0x6ef850: bl              #0x6ef654  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x6ef854: add             SP, SP, #0x10
    // 0x6ef858: r0 = inline_Allocate_Double()
    //     0x6ef858: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6ef85c: add             x0, x0, #0x10
    //     0x6ef860: cmp             x1, x0
    //     0x6ef864: b.ls            #0x6ef9c4
    //     0x6ef868: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ef86c: sub             x0, x0, #0xf
    //     0x6ef870: mov             x1, #0xd108
    //     0x6ef874: movk            x1, #3, lsl #16
    //     0x6ef878: stur            x1, [x0, #-1]
    // 0x6ef87c: StoreField: r0->field_7 = d0
    //     0x6ef87c: stur            d0, [x0, #7]
    // 0x6ef880: ldur            x16, [fp, #-0x18]
    // 0x6ef884: stp             x0, x16, [SP, #-0x10]!
    // 0x6ef888: ldur            x0, [fp, #-0x18]
    // 0x6ef88c: ClosureCall
    //     0x6ef88c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ef890: ldur            x2, [x0, #0x1f]
    //     0x6ef894: blr             x2
    // 0x6ef898: add             SP, SP, #0x10
    // 0x6ef89c: ldur            x0, [fp, #-8]
    // 0x6ef8a0: LoadField: r1 = r0->field_1b
    //     0x6ef8a0: ldur            w1, [x0, #0x1b]
    // 0x6ef8a4: DecompressPointer r1
    //     0x6ef8a4: add             x1, x1, HEAP, lsl #32
    // 0x6ef8a8: r16 = Sentinel
    //     0x6ef8a8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef8ac: cmp             w1, w16
    // 0x6ef8b0: b.eq            #0x6ef9d4
    // 0x6ef8b4: SaveReg r1
    //     0x6ef8b4: str             x1, [SP, #-8]!
    // 0x6ef8b8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ef8b8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ef8bc: r0 = forward()
    //     0x6ef8bc: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x6ef8c0: add             SP, SP, #8
    // 0x6ef8c4: ldr             x16, [fp, #0x18]
    // 0x6ef8c8: SaveReg r16
    //     0x6ef8c8: str             x16, [SP, #-8]!
    // 0x6ef8cc: r0 = showValueIndicator()
    //     0x6ef8cc: bl              #0x6cba2c  ; [package:flutter/src/material/slider.dart] _RenderSlider::showValueIndicator
    // 0x6ef8d0: add             SP, SP, #8
    // 0x6ef8d4: mov             x1, x0
    // 0x6ef8d8: stur            x1, [fp, #-0x18]
    // 0x6ef8dc: tbnz            w0, #5, #0x6ef8e4
    // 0x6ef8e0: r0 = AssertBoolean()
    //     0x6ef8e0: bl              #0xd67df0  ; AssertBooleanStub
    // 0x6ef8e4: ldur            x0, [fp, #-0x18]
    // 0x6ef8e8: tbnz            w0, #4, #0x6ef998
    // 0x6ef8ec: ldur            x0, [fp, #-8]
    // 0x6ef8f0: LoadField: r1 = r0->field_1f
    //     0x6ef8f0: ldur            w1, [x0, #0x1f]
    // 0x6ef8f4: DecompressPointer r1
    //     0x6ef8f4: add             x1, x1, HEAP, lsl #32
    // 0x6ef8f8: r16 = Sentinel
    //     0x6ef8f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6ef8fc: cmp             w1, w16
    // 0x6ef900: b.eq            #0x6ef9e0
    // 0x6ef904: SaveReg r1
    //     0x6ef904: str             x1, [SP, #-8]!
    // 0x6ef908: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6ef908: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6ef90c: r0 = forward()
    //     0x6ef90c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x6ef910: add             SP, SP, #8
    // 0x6ef914: ldur            x0, [fp, #-8]
    // 0x6ef918: LoadField: r1 = r0->field_2b
    //     0x6ef918: ldur            w1, [x0, #0x2b]
    // 0x6ef91c: DecompressPointer r1
    //     0x6ef91c: add             x1, x1, HEAP, lsl #32
    // 0x6ef920: cmp             w1, NULL
    // 0x6ef924: b.eq            #0x6ef938
    // 0x6ef928: SaveReg r1
    //     0x6ef928: str             x1, [SP, #-8]!
    // 0x6ef92c: r0 = cancel()
    //     0x6ef92c: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0x6ef930: add             SP, SP, #8
    // 0x6ef934: ldur            x0, [fp, #-8]
    // 0x6ef938: r16 = Instance_Duration
    //     0x6ef938: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x6ef93c: ldr             x16, [x16, #0x718]
    // 0x6ef940: r30 = 1.000000
    //     0x6ef940: ldr             lr, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x6ef944: stp             lr, x16, [SP, #-0x10]!
    // 0x6ef948: r0 = *()
    //     0x6ef948: bl              #0x4b52d4  ; [dart:core] Duration::*
    // 0x6ef94c: add             SP, SP, #0x10
    // 0x6ef950: ldur            x2, [fp, #-0x10]
    // 0x6ef954: r1 = Function '<anonymous closure>':.
    //     0x6ef954: add             x1, PP, #0x56, lsl #12  ; [pp+0x56468] AnonymousClosure: (0x6efd78), in [package:flutter/src/material/slider.dart] _RenderSlider::_startInteraction (0x6ef734)
    //     0x6ef958: ldr             x1, [x1, #0x468]
    // 0x6ef95c: stur            x0, [fp, #-0x10]
    // 0x6ef960: r0 = AllocateClosure()
    //     0x6ef960: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ef964: ldur            x16, [fp, #-0x10]
    // 0x6ef968: stp             x16, NULL, [SP, #-0x10]!
    // 0x6ef96c: SaveReg r0
    //     0x6ef96c: str             x0, [SP, #-8]!
    // 0x6ef970: r0 = Timer()
    //     0x6ef970: bl              #0x4b5878  ; [dart:async] Timer::Timer
    // 0x6ef974: add             SP, SP, #0x18
    // 0x6ef978: ldur            x1, [fp, #-8]
    // 0x6ef97c: StoreField: r1->field_2b = r0
    //     0x6ef97c: stur            w0, [x1, #0x2b]
    //     0x6ef980: ldurb           w16, [x1, #-1]
    //     0x6ef984: ldurb           w17, [x0, #-1]
    //     0x6ef988: and             x16, x17, x16, lsr #2
    //     0x6ef98c: tst             x16, HEAP, lsr #32
    //     0x6ef990: b.eq            #0x6ef998
    //     0x6ef994: bl              #0xd6826c
    // 0x6ef998: r0 = Null
    //     0x6ef998: mov             x0, NULL
    // 0x6ef99c: LeaveFrame
    //     0x6ef99c: mov             SP, fp
    //     0x6ef9a0: ldp             fp, lr, [SP], #0x10
    // 0x6ef9a4: ret
    //     0x6ef9a4: ret             
    // 0x6ef9a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ef9a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ef9ac: b               #0x6ef74c
    // 0x6ef9b0: SaveReg d0
    //     0x6ef9b0: str             q0, [SP, #-0x10]!
    // 0x6ef9b4: r0 = AllocateDouble()
    //     0x6ef9b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6ef9b8: RestoreReg d0
    //     0x6ef9b8: ldr             q0, [SP], #0x10
    // 0x6ef9bc: b               #0x6ef7f0
    // 0x6ef9c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6ef9c0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6ef9c4: SaveReg d0
    //     0x6ef9c4: str             q0, [SP, #-0x10]!
    // 0x6ef9c8: r0 = AllocateDouble()
    //     0x6ef9c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6ef9cc: RestoreReg d0
    //     0x6ef9cc: ldr             q0, [SP], #0x10
    // 0x6ef9d0: b               #0x6ef87c
    // 0x6ef9d4: r9 = overlayController
    //     0x6ef9d4: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0x6ef9d8: ldr             x9, [x9, #0x820]
    // 0x6ef9dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef9dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6ef9e0: r9 = valueIndicatorController
    //     0x6ef9e0: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6ef9e4: ldr             x9, [x9, #0x828]
    // 0x6ef9e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6ef9e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _getValueFromGlobalPosition(/* No info */) {
    // ** addr: 0x6ef9ec, size: 0xc4
    // 0x6ef9ec: EnterFrame
    //     0x6ef9ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6ef9f0: mov             fp, SP
    // 0x6ef9f4: AllocStack(0x10)
    //     0x6ef9f4: sub             SP, SP, #0x10
    // 0x6ef9f8: CheckStackOverflow
    //     0x6ef9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ef9fc: cmp             SP, x16
    //     0x6efa00: b.ls            #0x6efaa4
    // 0x6efa04: ldr             x16, [fp, #0x18]
    // 0x6efa08: ldr             lr, [fp, #0x10]
    // 0x6efa0c: stp             lr, x16, [SP, #-0x10]!
    // 0x6efa10: r0 = globalToLocal()
    //     0x6efa10: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x6efa14: add             SP, SP, #0x10
    // 0x6efa18: LoadField: d0 = r0->field_7
    //     0x6efa18: ldur            d0, [x0, #7]
    // 0x6efa1c: stur            d0, [fp, #-8]
    // 0x6efa20: ldr             x16, [fp, #0x18]
    // 0x6efa24: SaveReg r16
    //     0x6efa24: str             x16, [SP, #-8]!
    // 0x6efa28: r0 = _trackRect()
    //     0x6efa28: bl              #0x6efb68  ; [package:flutter/src/material/slider.dart] _RenderSlider::_trackRect
    // 0x6efa2c: add             SP, SP, #8
    // 0x6efa30: LoadField: d0 = r0->field_7
    //     0x6efa30: ldur            d0, [x0, #7]
    // 0x6efa34: ldur            d1, [fp, #-8]
    // 0x6efa38: fsub            d2, d1, d0
    // 0x6efa3c: ldr             x0, [fp, #0x18]
    // 0x6efa40: stur            d2, [fp, #-0x10]
    // 0x6efa44: LoadField: r1 = r0->field_a7
    //     0x6efa44: ldur            w1, [x0, #0xa7]
    // 0x6efa48: DecompressPointer r1
    //     0x6efa48: add             x1, x1, HEAP, lsl #32
    // 0x6efa4c: LoadField: r2 = r1->field_53
    //     0x6efa4c: ldur            w2, [x1, #0x53]
    // 0x6efa50: DecompressPointer r2
    //     0x6efa50: add             x2, x2, HEAP, lsl #32
    // 0x6efa54: cmp             w2, NULL
    // 0x6efa58: b.eq            #0x6efaac
    // 0x6efa5c: stp             x0, x2, [SP, #-0x10]!
    // 0x6efa60: SaveReg r1
    //     0x6efa60: str             x1, [SP, #-8]!
    // 0x6efa64: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6efa64: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6efa68: r0 = getPreferredRect()
    //     0x6efa68: bl              #0x66c534  ; [package:flutter/src/material/slider_theme.dart] _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x6efa6c: add             SP, SP, #0x18
    // 0x6efa70: LoadField: d0 = r0->field_17
    //     0x6efa70: ldur            d0, [x0, #0x17]
    // 0x6efa74: LoadField: d1 = r0->field_7
    //     0x6efa74: ldur            d1, [x0, #7]
    // 0x6efa78: fsub            d2, d0, d1
    // 0x6efa7c: ldur            d0, [fp, #-0x10]
    // 0x6efa80: fdiv            d1, d0, d2
    // 0x6efa84: ldr             x16, [fp, #0x18]
    // 0x6efa88: SaveReg r16
    //     0x6efa88: str             x16, [SP, #-8]!
    // 0x6efa8c: SaveReg d1
    //     0x6efa8c: str             d1, [SP, #-8]!
    // 0x6efa90: r0 = _getValueFromVisualPosition()
    //     0x6efa90: bl              #0x6efab0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_getValueFromVisualPosition
    // 0x6efa94: add             SP, SP, #0x10
    // 0x6efa98: LeaveFrame
    //     0x6efa98: mov             SP, fp
    //     0x6efa9c: ldp             fp, lr, [SP], #0x10
    // 0x6efaa0: ret
    //     0x6efaa0: ret             
    // 0x6efaa4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6efaa4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6efaa8: b               #0x6efa04
    // 0x6efaac: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6efaac: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _getValueFromVisualPosition(/* No info */) {
    // ** addr: 0x6efab0, size: 0xb8
    // 0x6efab0: EnterFrame
    //     0x6efab0: stp             fp, lr, [SP, #-0x10]!
    //     0x6efab4: mov             fp, SP
    // 0x6efab8: ldr             x1, [fp, #0x18]
    // 0x6efabc: LoadField: r2 = r1->field_c3
    //     0x6efabc: ldur            w2, [x1, #0xc3]
    // 0x6efac0: DecompressPointer r2
    //     0x6efac0: add             x2, x2, HEAP, lsl #32
    // 0x6efac4: LoadField: r1 = r2->field_7
    //     0x6efac4: ldur            x1, [x2, #7]
    // 0x6efac8: cmp             x1, #0
    // 0x6efacc: b.gt            #0x6efb10
    // 0x6efad0: ldr             d1, [fp, #0x10]
    // 0x6efad4: d0 = 1.000000
    //     0x6efad4: fmov            d0, #1.00000000
    // 0x6efad8: fsub            d2, d0, d1
    // 0x6efadc: r0 = inline_Allocate_Double()
    //     0x6efadc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6efae0: add             x0, x0, #0x10
    //     0x6efae4: cmp             x1, x0
    //     0x6efae8: b.ls            #0x6efb48
    //     0x6efaec: str             x0, [THR, #0x60]  ; THR::top
    //     0x6efaf0: sub             x0, x0, #0xf
    //     0x6efaf4: mov             x1, #0xd108
    //     0x6efaf8: movk            x1, #3, lsl #16
    //     0x6efafc: stur            x1, [x0, #-1]
    // 0x6efb00: StoreField: r0->field_7 = d2
    //     0x6efb00: stur            d2, [x0, #7]
    // 0x6efb04: LeaveFrame
    //     0x6efb04: mov             SP, fp
    //     0x6efb08: ldp             fp, lr, [SP], #0x10
    // 0x6efb0c: ret
    //     0x6efb0c: ret             
    // 0x6efb10: ldr             d1, [fp, #0x10]
    // 0x6efb14: r0 = inline_Allocate_Double()
    //     0x6efb14: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6efb18: add             x0, x0, #0x10
    //     0x6efb1c: cmp             x1, x0
    //     0x6efb20: b.ls            #0x6efb58
    //     0x6efb24: str             x0, [THR, #0x60]  ; THR::top
    //     0x6efb28: sub             x0, x0, #0xf
    //     0x6efb2c: mov             x1, #0xd108
    //     0x6efb30: movk            x1, #3, lsl #16
    //     0x6efb34: stur            x1, [x0, #-1]
    // 0x6efb38: StoreField: r0->field_7 = d1
    //     0x6efb38: stur            d1, [x0, #7]
    // 0x6efb3c: LeaveFrame
    //     0x6efb3c: mov             SP, fp
    //     0x6efb40: ldp             fp, lr, [SP], #0x10
    // 0x6efb44: ret
    //     0x6efb44: ret             
    // 0x6efb48: SaveReg d2
    //     0x6efb48: str             q2, [SP, #-0x10]!
    // 0x6efb4c: r0 = AllocateDouble()
    //     0x6efb4c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6efb50: RestoreReg d2
    //     0x6efb50: ldr             q2, [SP], #0x10
    // 0x6efb54: b               #0x6efb00
    // 0x6efb58: SaveReg d1
    //     0x6efb58: str             q1, [SP, #-0x10]!
    // 0x6efb5c: r0 = AllocateDouble()
    //     0x6efb5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6efb60: RestoreReg d1
    //     0x6efb60: ldr             q1, [SP], #0x10
    // 0x6efb64: b               #0x6efb38
  }
  get _ _trackRect(/* No info */) {
    // ** addr: 0x6efb68, size: 0x5c
    // 0x6efb68: EnterFrame
    //     0x6efb68: stp             fp, lr, [SP, #-0x10]!
    //     0x6efb6c: mov             fp, SP
    // 0x6efb70: CheckStackOverflow
    //     0x6efb70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6efb74: cmp             SP, x16
    //     0x6efb78: b.ls            #0x6efbb8
    // 0x6efb7c: ldr             x0, [fp, #0x10]
    // 0x6efb80: LoadField: r1 = r0->field_a7
    //     0x6efb80: ldur            w1, [x0, #0xa7]
    // 0x6efb84: DecompressPointer r1
    //     0x6efb84: add             x1, x1, HEAP, lsl #32
    // 0x6efb88: LoadField: r2 = r1->field_53
    //     0x6efb88: ldur            w2, [x1, #0x53]
    // 0x6efb8c: DecompressPointer r2
    //     0x6efb8c: add             x2, x2, HEAP, lsl #32
    // 0x6efb90: cmp             w2, NULL
    // 0x6efb94: b.eq            #0x6efbc0
    // 0x6efb98: stp             x0, x2, [SP, #-0x10]!
    // 0x6efb9c: SaveReg r1
    //     0x6efb9c: str             x1, [SP, #-8]!
    // 0x6efba0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6efba0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6efba4: r0 = getPreferredRect()
    //     0x6efba4: bl              #0x66c534  ; [package:flutter/src/material/slider_theme.dart] _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x6efba8: add             SP, SP, #0x18
    // 0x6efbac: LeaveFrame
    //     0x6efbac: mov             SP, fp
    //     0x6efbb0: ldp             fp, lr, [SP], #0x10
    // 0x6efbb4: ret
    //     0x6efbb4: ret             
    // 0x6efbb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6efbb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6efbbc: b               #0x6efb7c
    // 0x6efbc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6efbc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x6efd78, size: 0xc4
    // 0x6efd78: EnterFrame
    //     0x6efd78: stp             fp, lr, [SP, #-0x10]!
    //     0x6efd7c: mov             fp, SP
    // 0x6efd80: ldr             x0, [fp, #0x10]
    // 0x6efd84: LoadField: r1 = r0->field_17
    //     0x6efd84: ldur            w1, [x0, #0x17]
    // 0x6efd88: DecompressPointer r1
    //     0x6efd88: add             x1, x1, HEAP, lsl #32
    // 0x6efd8c: CheckStackOverflow
    //     0x6efd8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6efd90: cmp             SP, x16
    //     0x6efd94: b.ls            #0x6efe1c
    // 0x6efd98: LoadField: r0 = r1->field_f
    //     0x6efd98: ldur            w0, [x1, #0xf]
    // 0x6efd9c: DecompressPointer r0
    //     0x6efd9c: add             x0, x0, HEAP, lsl #32
    // 0x6efda0: LoadField: r1 = r0->field_5f
    //     0x6efda0: ldur            w1, [x0, #0x5f]
    // 0x6efda4: DecompressPointer r1
    //     0x6efda4: add             x1, x1, HEAP, lsl #32
    // 0x6efda8: StoreField: r1->field_2b = rNULL
    //     0x6efda8: stur            NULL, [x1, #0x2b]
    // 0x6efdac: LoadField: r2 = r0->field_7b
    //     0x6efdac: ldur            w2, [x0, #0x7b]
    // 0x6efdb0: DecompressPointer r2
    //     0x6efdb0: add             x2, x2, HEAP, lsl #32
    // 0x6efdb4: tbz             w2, #4, #0x6efe0c
    // 0x6efdb8: LoadField: r2 = r0->field_c7
    //     0x6efdb8: ldur            w2, [x0, #0xc7]
    // 0x6efdbc: DecompressPointer r2
    //     0x6efdbc: add             x2, x2, HEAP, lsl #32
    // 0x6efdc0: tbz             w2, #4, #0x6efe0c
    // 0x6efdc4: LoadField: r0 = r1->field_1f
    //     0x6efdc4: ldur            w0, [x1, #0x1f]
    // 0x6efdc8: DecompressPointer r0
    //     0x6efdc8: add             x0, x0, HEAP, lsl #32
    // 0x6efdcc: r16 = Sentinel
    //     0x6efdcc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6efdd0: cmp             w0, w16
    // 0x6efdd4: b.eq            #0x6efe24
    // 0x6efdd8: LoadField: r1 = r0->field_43
    //     0x6efdd8: ldur            w1, [x0, #0x43]
    // 0x6efddc: DecompressPointer r1
    //     0x6efddc: add             x1, x1, HEAP, lsl #32
    // 0x6efde0: r16 = Sentinel
    //     0x6efde0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6efde4: cmp             w1, w16
    // 0x6efde8: b.eq            #0x6efe30
    // 0x6efdec: r16 = Instance_AnimationStatus
    //     0x6efdec: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x6efdf0: ldr             x16, [x16, #0xba0]
    // 0x6efdf4: cmp             w1, w16
    // 0x6efdf8: b.ne            #0x6efe0c
    // 0x6efdfc: SaveReg r0
    //     0x6efdfc: str             x0, [SP, #-8]!
    // 0x6efe00: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6efe00: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6efe04: r0 = reverse()
    //     0x6efe04: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x6efe08: add             SP, SP, #8
    // 0x6efe0c: r0 = Null
    //     0x6efe0c: mov             x0, NULL
    // 0x6efe10: LeaveFrame
    //     0x6efe10: mov             SP, fp
    //     0x6efe14: ldp             fp, lr, [SP], #0x10
    // 0x6efe18: ret
    //     0x6efe18: ret             
    // 0x6efe1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6efe1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6efe20: b               #0x6efd98
    // 0x6efe24: r9 = valueIndicatorController
    //     0x6efe24: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0x6efe28: ldr             x9, [x9, #0x828]
    // 0x6efe2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6efe2c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6efe30: r9 = _status
    //     0x6efe30: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbe0] Field <AnimationController._status@575066280>: late (offset: 0x44)
    //     0x6efe34: ldr             x9, [x9, #0xbe0]
    // 0x6efe38: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6efe38: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _endInteraction(dynamic) {
    // ** addr: 0x6efe3c, size: 0x48
    // 0x6efe3c: EnterFrame
    //     0x6efe3c: stp             fp, lr, [SP, #-0x10]!
    //     0x6efe40: mov             fp, SP
    // 0x6efe44: ldr             x0, [fp, #0x10]
    // 0x6efe48: LoadField: r1 = r0->field_17
    //     0x6efe48: ldur            w1, [x0, #0x17]
    // 0x6efe4c: DecompressPointer r1
    //     0x6efe4c: add             x1, x1, HEAP, lsl #32
    // 0x6efe50: CheckStackOverflow
    //     0x6efe50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6efe54: cmp             SP, x16
    //     0x6efe58: b.ls            #0x6efe7c
    // 0x6efe5c: LoadField: r0 = r1->field_f
    //     0x6efe5c: ldur            w0, [x1, #0xf]
    // 0x6efe60: DecompressPointer r0
    //     0x6efe60: add             x0, x0, HEAP, lsl #32
    // 0x6efe64: SaveReg r0
    //     0x6efe64: str             x0, [SP, #-8]!
    // 0x6efe68: r0 = _endInteraction()
    //     0x6efe68: bl              #0x6ef4ac  ; [package:flutter/src/material/slider.dart] _RenderSlider::_endInteraction
    // 0x6efe6c: add             SP, SP, #8
    // 0x6efe70: LeaveFrame
    //     0x6efe70: mov             SP, fp
    //     0x6efe74: ldp             fp, lr, [SP], #0x10
    // 0x6efe78: ret
    //     0x6efe78: ret             
    // 0x6efe7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6efe7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6efe80: b               #0x6efe5c
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x6efe84, size: 0x4c
    // 0x6efe84: EnterFrame
    //     0x6efe84: stp             fp, lr, [SP, #-0x10]!
    //     0x6efe88: mov             fp, SP
    // 0x6efe8c: ldr             x0, [fp, #0x18]
    // 0x6efe90: LoadField: r1 = r0->field_17
    //     0x6efe90: ldur            w1, [x0, #0x17]
    // 0x6efe94: DecompressPointer r1
    //     0x6efe94: add             x1, x1, HEAP, lsl #32
    // 0x6efe98: CheckStackOverflow
    //     0x6efe98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6efe9c: cmp             SP, x16
    //     0x6efea0: b.ls            #0x6efec8
    // 0x6efea4: LoadField: r0 = r1->field_f
    //     0x6efea4: ldur            w0, [x1, #0xf]
    // 0x6efea8: DecompressPointer r0
    //     0x6efea8: add             x0, x0, HEAP, lsl #32
    // 0x6efeac: ldr             x16, [fp, #0x10]
    // 0x6efeb0: stp             x16, x0, [SP, #-0x10]!
    // 0x6efeb4: r0 = _handleDragUpdate()
    //     0x6efeb4: bl              #0x6efed0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragUpdate
    // 0x6efeb8: add             SP, SP, #0x10
    // 0x6efebc: LeaveFrame
    //     0x6efebc: mov             SP, fp
    //     0x6efec0: ldp             fp, lr, [SP], #0x10
    // 0x6efec4: ret
    //     0x6efec4: ret             
    // 0x6efec8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6efec8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6efecc: b               #0x6efea4
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0x6efed0, size: 0x188
    // 0x6efed0: EnterFrame
    //     0x6efed0: stp             fp, lr, [SP, #-0x10]!
    //     0x6efed4: mov             fp, SP
    // 0x6efed8: AllocStack(0x8)
    //     0x6efed8: sub             SP, SP, #8
    // 0x6efedc: CheckStackOverflow
    //     0x6efedc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6efee0: cmp             SP, x16
    //     0x6efee4: b.ls            #0x6f0034
    // 0x6efee8: ldr             x0, [fp, #0x18]
    // 0x6efeec: LoadField: r1 = r0->field_5f
    //     0x6efeec: ldur            w1, [x0, #0x5f]
    // 0x6efef0: DecompressPointer r1
    //     0x6efef0: add             x1, x1, HEAP, lsl #32
    // 0x6efef4: LoadField: r2 = r1->field_f
    //     0x6efef4: ldur            w2, [x1, #0xf]
    // 0x6efef8: DecompressPointer r2
    //     0x6efef8: add             x2, x2, HEAP, lsl #32
    // 0x6efefc: cmp             w2, NULL
    // 0x6eff00: b.ne            #0x6eff14
    // 0x6eff04: r0 = Null
    //     0x6eff04: mov             x0, NULL
    // 0x6eff08: LeaveFrame
    //     0x6eff08: mov             SP, fp
    //     0x6eff0c: ldp             fp, lr, [SP], #0x10
    // 0x6eff10: ret
    //     0x6eff10: ret             
    // 0x6eff14: LoadField: r1 = r0->field_b7
    //     0x6eff14: ldur            w1, [x0, #0xb7]
    // 0x6eff18: DecompressPointer r1
    //     0x6eff18: add             x1, x1, HEAP, lsl #32
    // 0x6eff1c: cmp             w1, NULL
    // 0x6eff20: b.eq            #0x6f0024
    // 0x6eff24: ldr             x1, [fp, #0x10]
    // 0x6eff28: LoadField: r2 = r1->field_f
    //     0x6eff28: ldur            w2, [x1, #0xf]
    // 0x6eff2c: DecompressPointer r2
    //     0x6eff2c: add             x2, x2, HEAP, lsl #32
    // 0x6eff30: stur            x2, [fp, #-8]
    // 0x6eff34: cmp             w2, NULL
    // 0x6eff38: b.eq            #0x6f003c
    // 0x6eff3c: LoadField: r1 = r0->field_a7
    //     0x6eff3c: ldur            w1, [x0, #0xa7]
    // 0x6eff40: DecompressPointer r1
    //     0x6eff40: add             x1, x1, HEAP, lsl #32
    // 0x6eff44: LoadField: r3 = r1->field_53
    //     0x6eff44: ldur            w3, [x1, #0x53]
    // 0x6eff48: DecompressPointer r3
    //     0x6eff48: add             x3, x3, HEAP, lsl #32
    // 0x6eff4c: cmp             w3, NULL
    // 0x6eff50: b.eq            #0x6f0040
    // 0x6eff54: stp             x0, x3, [SP, #-0x10]!
    // 0x6eff58: SaveReg r1
    //     0x6eff58: str             x1, [SP, #-8]!
    // 0x6eff5c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x6eff5c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x6eff60: r0 = getPreferredRect()
    //     0x6eff60: bl              #0x66c534  ; [package:flutter/src/material/slider_theme.dart] _RectangularSliderTrackShape&SliderTrackShape&BaseSliderTrackShape::getPreferredRect
    // 0x6eff64: add             SP, SP, #0x18
    // 0x6eff68: LoadField: d0 = r0->field_17
    //     0x6eff68: ldur            d0, [x0, #0x17]
    // 0x6eff6c: LoadField: d1 = r0->field_7
    //     0x6eff6c: ldur            d1, [x0, #7]
    // 0x6eff70: fsub            d2, d0, d1
    // 0x6eff74: ldur            x0, [fp, #-8]
    // 0x6eff78: LoadField: d0 = r0->field_7
    //     0x6eff78: ldur            d0, [x0, #7]
    // 0x6eff7c: fdiv            d1, d0, d2
    // 0x6eff80: ldr             x0, [fp, #0x18]
    // 0x6eff84: LoadField: r1 = r0->field_c3
    //     0x6eff84: ldur            w1, [x0, #0xc3]
    // 0x6eff88: DecompressPointer r1
    //     0x6eff88: add             x1, x1, HEAP, lsl #32
    // 0x6eff8c: LoadField: r2 = r1->field_7
    //     0x6eff8c: ldur            x2, [x1, #7]
    // 0x6eff90: cmp             x2, #0
    // 0x6eff94: b.gt            #0x6effac
    // 0x6eff98: LoadField: d0 = r0->field_7f
    //     0x6eff98: ldur            d0, [x0, #0x7f]
    // 0x6eff9c: fsub            d2, d0, d1
    // 0x6effa0: StoreField: r0->field_7f = d2
    //     0x6effa0: stur            d2, [x0, #0x7f]
    // 0x6effa4: mov             v0.16b, v2.16b
    // 0x6effa8: b               #0x6effbc
    // 0x6effac: LoadField: d0 = r0->field_7f
    //     0x6effac: ldur            d0, [x0, #0x7f]
    // 0x6effb0: fadd            d2, d0, d1
    // 0x6effb4: StoreField: r0->field_7f = d2
    //     0x6effb4: stur            d2, [x0, #0x7f]
    // 0x6effb8: mov             v0.16b, v2.16b
    // 0x6effbc: LoadField: r1 = r0->field_b7
    //     0x6effbc: ldur            w1, [x0, #0xb7]
    // 0x6effc0: DecompressPointer r1
    //     0x6effc0: add             x1, x1, HEAP, lsl #32
    // 0x6effc4: stur            x1, [fp, #-8]
    // 0x6effc8: cmp             w1, NULL
    // 0x6effcc: b.eq            #0x6f0044
    // 0x6effd0: SaveReg r0
    //     0x6effd0: str             x0, [SP, #-8]!
    // 0x6effd4: SaveReg d0
    //     0x6effd4: str             d0, [SP, #-8]!
    // 0x6effd8: r0 = _discretize()
    //     0x6effd8: bl              #0x6ef654  ; [package:flutter/src/material/slider.dart] _RenderSlider::_discretize
    // 0x6effdc: add             SP, SP, #0x10
    // 0x6effe0: r0 = inline_Allocate_Double()
    //     0x6effe0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6effe4: add             x0, x0, #0x10
    //     0x6effe8: cmp             x1, x0
    //     0x6effec: b.ls            #0x6f0048
    //     0x6efff0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6efff4: sub             x0, x0, #0xf
    //     0x6efff8: mov             x1, #0xd108
    //     0x6efffc: movk            x1, #3, lsl #16
    //     0x6f0000: stur            x1, [x0, #-1]
    // 0x6f0004: StoreField: r0->field_7 = d0
    //     0x6f0004: stur            d0, [x0, #7]
    // 0x6f0008: ldur            x16, [fp, #-8]
    // 0x6f000c: stp             x0, x16, [SP, #-0x10]!
    // 0x6f0010: ldur            x0, [fp, #-8]
    // 0x6f0014: ClosureCall
    //     0x6f0014: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6f0018: ldur            x2, [x0, #0x1f]
    //     0x6f001c: blr             x2
    // 0x6f0020: add             SP, SP, #0x10
    // 0x6f0024: r0 = Null
    //     0x6f0024: mov             x0, NULL
    // 0x6f0028: LeaveFrame
    //     0x6f0028: mov             SP, fp
    //     0x6f002c: ldp             fp, lr, [SP], #0x10
    // 0x6f0030: ret
    //     0x6f0030: ret             
    // 0x6f0034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f0034: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f0038: b               #0x6efee8
    // 0x6f003c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f003c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6f0040: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6f0040: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6f0044: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6f0044: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6f0048: SaveReg d0
    //     0x6f0048: str             q0, [SP, #-0x10]!
    // 0x6f004c: r0 = AllocateDouble()
    //     0x6f004c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6f0050: RestoreReg d0
    //     0x6f0050: ldr             q0, [SP], #0x10
    // 0x6f0054: b               #0x6f0004
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x6f0058, size: 0x4c
    // 0x6f0058: EnterFrame
    //     0x6f0058: stp             fp, lr, [SP, #-0x10]!
    //     0x6f005c: mov             fp, SP
    // 0x6f0060: ldr             x0, [fp, #0x18]
    // 0x6f0064: LoadField: r1 = r0->field_17
    //     0x6f0064: ldur            w1, [x0, #0x17]
    // 0x6f0068: DecompressPointer r1
    //     0x6f0068: add             x1, x1, HEAP, lsl #32
    // 0x6f006c: CheckStackOverflow
    //     0x6f006c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0070: cmp             SP, x16
    //     0x6f0074: b.ls            #0x6f009c
    // 0x6f0078: LoadField: r0 = r1->field_f
    //     0x6f0078: ldur            w0, [x1, #0xf]
    // 0x6f007c: DecompressPointer r0
    //     0x6f007c: add             x0, x0, HEAP, lsl #32
    // 0x6f0080: ldr             x16, [fp, #0x10]
    // 0x6f0084: stp             x16, x0, [SP, #-0x10]!
    // 0x6f0088: r0 = _handleDragStart()
    //     0x6f0088: bl              #0x6f00a4  ; [package:flutter/src/material/slider.dart] _RenderSlider::_handleDragStart
    // 0x6f008c: add             SP, SP, #0x10
    // 0x6f0090: LeaveFrame
    //     0x6f0090: mov             SP, fp
    //     0x6f0094: ldp             fp, lr, [SP], #0x10
    // 0x6f0098: ret
    //     0x6f0098: ret             
    // 0x6f009c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f009c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f00a0: b               #0x6f0078
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0x6f00a4, size: 0x48
    // 0x6f00a4: EnterFrame
    //     0x6f00a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6f00a8: mov             fp, SP
    // 0x6f00ac: CheckStackOverflow
    //     0x6f00ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f00b0: cmp             SP, x16
    //     0x6f00b4: b.ls            #0x6f00e4
    // 0x6f00b8: ldr             x0, [fp, #0x10]
    // 0x6f00bc: LoadField: r1 = r0->field_b
    //     0x6f00bc: ldur            w1, [x0, #0xb]
    // 0x6f00c0: DecompressPointer r1
    //     0x6f00c0: add             x1, x1, HEAP, lsl #32
    // 0x6f00c4: ldr             x16, [fp, #0x18]
    // 0x6f00c8: stp             x1, x16, [SP, #-0x10]!
    // 0x6f00cc: r0 = _startInteraction()
    //     0x6f00cc: bl              #0x6ef734  ; [package:flutter/src/material/slider.dart] _RenderSlider::_startInteraction
    // 0x6f00d0: add             SP, SP, #0x10
    // 0x6f00d4: r0 = Null
    //     0x6f00d4: mov             x0, NULL
    // 0x6f00d8: LeaveFrame
    //     0x6f00d8: mov             SP, fp
    //     0x6f00dc: ldp             fp, lr, [SP], #0x10
    // 0x6f00e0: ret
    //     0x6f00e0: ret             
    // 0x6f00e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f00e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f00e8: b               #0x6f00b8
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x716bd0, size: 0x190
    // 0x716bd0: EnterFrame
    //     0x716bd0: stp             fp, lr, [SP, #-0x10]!
    //     0x716bd4: mov             fp, SP
    // 0x716bd8: AllocStack(0x8)
    //     0x716bd8: sub             SP, SP, #8
    // 0x716bdc: CheckStackOverflow
    //     0x716bdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x716be0: cmp             SP, x16
    //     0x716be4: b.ls            #0x716d40
    // 0x716be8: ldr             x0, [fp, #0x10]
    // 0x716bec: r2 = Null
    //     0x716bec: mov             x2, NULL
    // 0x716bf0: r1 = Null
    //     0x716bf0: mov             x1, NULL
    // 0x716bf4: r4 = 59
    //     0x716bf4: mov             x4, #0x3b
    // 0x716bf8: branchIfSmi(r0, 0x716c04)
    //     0x716bf8: tbz             w0, #0, #0x716c04
    // 0x716bfc: r4 = LoadClassIdInstr(r0)
    //     0x716bfc: ldur            x4, [x0, #-1]
    //     0x716c00: ubfx            x4, x4, #0xc, #0x14
    // 0x716c04: cmp             x4, #0x8f0
    // 0x716c08: b.eq            #0x716c20
    // 0x716c0c: r8 = BoxHitTestEntry<RenderBox>
    //     0x716c0c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb198] Type: BoxHitTestEntry<RenderBox>
    //     0x716c10: ldr             x8, [x8, #0x198]
    // 0x716c14: r3 = Null
    //     0x716c14: add             x3, PP, #0x56, lsl #12  ; [pp+0x56ca8] Null
    //     0x716c18: ldr             x3, [x3, #0xca8]
    // 0x716c1c: r0 = DefaultTypeTest()
    //     0x716c1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x716c20: ldr             x0, [fp, #0x18]
    // 0x716c24: r2 = Null
    //     0x716c24: mov             x2, NULL
    // 0x716c28: r1 = Null
    //     0x716c28: mov             x1, NULL
    // 0x716c2c: cmp             w0, NULL
    // 0x716c30: b.eq            #0x716c50
    // 0x716c34: branchIfSmi(r0, 0x716c50)
    //     0x716c34: tbz             w0, #0, #0x716c50
    // 0x716c38: r3 = LoadClassIdInstr(r0)
    //     0x716c38: ldur            x3, [x0, #-1]
    //     0x716c3c: ubfx            x3, x3, #0xc, #0x14
    // 0x716c40: cmp             x3, #0x90a
    // 0x716c44: b.eq            #0x716c58
    // 0x716c48: cmp             x3, #0xb41
    // 0x716c4c: b.eq            #0x716c58
    // 0x716c50: r0 = false
    //     0x716c50: add             x0, NULL, #0x30  ; false
    // 0x716c54: b               #0x716c5c
    // 0x716c58: r0 = true
    //     0x716c58: add             x0, NULL, #0x20  ; true
    // 0x716c5c: tbnz            w0, #4, #0x716cc0
    // 0x716c60: ldr             x0, [fp, #0x20]
    // 0x716c64: LoadField: r1 = r0->field_b7
    //     0x716c64: ldur            w1, [x0, #0xb7]
    // 0x716c68: DecompressPointer r1
    //     0x716c68: add             x1, x1, HEAP, lsl #32
    // 0x716c6c: cmp             w1, NULL
    // 0x716c70: b.eq            #0x716cc0
    // 0x716c74: LoadField: r1 = r0->field_73
    //     0x716c74: ldur            w1, [x0, #0x73]
    // 0x716c78: DecompressPointer r1
    //     0x716c78: add             x1, x1, HEAP, lsl #32
    // 0x716c7c: r16 = Sentinel
    //     0x716c7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x716c80: cmp             w1, w16
    // 0x716c84: b.eq            #0x716d48
    // 0x716c88: ldr             x16, [fp, #0x18]
    // 0x716c8c: stp             x16, x1, [SP, #-0x10]!
    // 0x716c90: r0 = addPointer()
    //     0x716c90: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x716c94: add             SP, SP, #0x10
    // 0x716c98: ldr             x0, [fp, #0x20]
    // 0x716c9c: LoadField: r1 = r0->field_77
    //     0x716c9c: ldur            w1, [x0, #0x77]
    // 0x716ca0: DecompressPointer r1
    //     0x716ca0: add             x1, x1, HEAP, lsl #32
    // 0x716ca4: r16 = Sentinel
    //     0x716ca4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x716ca8: cmp             w1, w16
    // 0x716cac: b.eq            #0x716d54
    // 0x716cb0: ldr             x16, [fp, #0x18]
    // 0x716cb4: stp             x16, x1, [SP, #-0x10]!
    // 0x716cb8: r0 = addPointer()
    //     0x716cb8: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x716cbc: add             SP, SP, #0x10
    // 0x716cc0: ldr             x1, [fp, #0x20]
    // 0x716cc4: LoadField: r0 = r1->field_b7
    //     0x716cc4: ldur            w0, [x1, #0xb7]
    // 0x716cc8: DecompressPointer r0
    //     0x716cc8: add             x0, x0, HEAP, lsl #32
    // 0x716ccc: cmp             w0, NULL
    // 0x716cd0: b.eq            #0x716d30
    // 0x716cd4: LoadField: r2 = r1->field_87
    //     0x716cd4: ldur            w2, [x1, #0x87]
    // 0x716cd8: DecompressPointer r2
    //     0x716cd8: add             x2, x2, HEAP, lsl #32
    // 0x716cdc: stur            x2, [fp, #-8]
    // 0x716ce0: cmp             w2, NULL
    // 0x716ce4: b.eq            #0x716d30
    // 0x716ce8: ldr             x0, [fp, #0x18]
    // 0x716cec: r3 = LoadClassIdInstr(r0)
    //     0x716cec: ldur            x3, [x0, #-1]
    //     0x716cf0: ubfx            x3, x3, #0xc, #0x14
    // 0x716cf4: SaveReg r0
    //     0x716cf4: str             x0, [SP, #-8]!
    // 0x716cf8: mov             x0, x3
    // 0x716cfc: r0 = GDT[cid_x0 + 0x57c0]()
    //     0x716cfc: mov             x17, #0x57c0
    //     0x716d00: add             lr, x0, x17
    //     0x716d04: ldr             lr, [x21, lr, lsl #3]
    //     0x716d08: blr             lr
    // 0x716d0c: add             SP, SP, #8
    // 0x716d10: ldur            x16, [fp, #-8]
    // 0x716d14: stp             x0, x16, [SP, #-0x10]!
    // 0x716d18: r0 = contains()
    //     0x716d18: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0x716d1c: add             SP, SP, #0x10
    // 0x716d20: ldr             x16, [fp, #0x20]
    // 0x716d24: stp             x0, x16, [SP, #-0x10]!
    // 0x716d28: r0 = hoveringThumb=()
    //     0x716d28: bl              #0x716d60  ; [package:flutter/src/material/slider.dart] _RenderSlider::hoveringThumb=
    // 0x716d2c: add             SP, SP, #0x10
    // 0x716d30: r0 = Null
    //     0x716d30: mov             x0, NULL
    // 0x716d34: LeaveFrame
    //     0x716d34: mov             SP, fp
    //     0x716d38: ldp             fp, lr, [SP], #0x10
    // 0x716d3c: ret
    //     0x716d3c: ret             
    // 0x716d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x716d40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x716d44: b               #0x716be8
    // 0x716d48: r9 = _drag
    //     0x716d48: add             x9, PP, #0x56, lsl #12  ; [pp+0x56420] Field <_RenderSlider@810231897._drag@810231897>: late (offset: 0x74)
    //     0x716d4c: ldr             x9, [x9, #0x420]
    // 0x716d50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x716d50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x716d54: r9 = _tap
    //     0x716d54: add             x9, PP, #0x56, lsl #12  ; [pp+0x56428] Field <_RenderSlider@810231897._tap@810231897>: late (offset: 0x78)
    //     0x716d58: ldr             x9, [x9, #0x428]
    // 0x716d5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x716d5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  set _ hoveringThumb=(/* No info */) {
    // ** addr: 0x716d60, size: 0x6c
    // 0x716d60: EnterFrame
    //     0x716d60: stp             fp, lr, [SP, #-0x10]!
    //     0x716d64: mov             fp, SP
    // 0x716d68: CheckStackOverflow
    //     0x716d68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x716d6c: cmp             SP, x16
    //     0x716d70: b.ls            #0x716dc4
    // 0x716d74: ldr             x0, [fp, #0x18]
    // 0x716d78: LoadField: r1 = r0->field_cf
    //     0x716d78: ldur            w1, [x0, #0xcf]
    // 0x716d7c: DecompressPointer r1
    //     0x716d7c: add             x1, x1, HEAP, lsl #32
    // 0x716d80: ldr             x2, [fp, #0x10]
    // 0x716d84: cmp             w2, w1
    // 0x716d88: b.ne            #0x716d9c
    // 0x716d8c: r0 = Null
    //     0x716d8c: mov             x0, NULL
    // 0x716d90: LeaveFrame
    //     0x716d90: mov             SP, fp
    //     0x716d94: ldp             fp, lr, [SP], #0x10
    // 0x716d98: ret
    //     0x716d98: ret             
    // 0x716d9c: StoreField: r0->field_cf = r2
    //     0x716d9c: stur            w2, [x0, #0xcf]
    // 0x716da0: LoadField: r1 = r0->field_cb
    //     0x716da0: ldur            w1, [x0, #0xcb]
    // 0x716da4: DecompressPointer r1
    //     0x716da4: add             x1, x1, HEAP, lsl #32
    // 0x716da8: stp             x1, x0, [SP, #-0x10]!
    // 0x716dac: r0 = _updateForHover()
    //     0x716dac: bl              #0x6cb77c  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateForHover
    // 0x716db0: add             SP, SP, #0x10
    // 0x716db4: r0 = Null
    //     0x716db4: mov             x0, NULL
    // 0x716db8: LeaveFrame
    //     0x716db8: mov             SP, fp
    //     0x716dbc: ldp             fp, lr, [SP], #0x10
    // 0x716dc0: ret
    //     0x716dc0: ret             
    // 0x716dc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x716dc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x716dc8: b               #0x716d74
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bde2c, size: 0x1f0
    // 0x9bde2c: EnterFrame
    //     0x9bde2c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bde30: mov             fp, SP
    // 0x9bde34: AllocStack(0x8)
    //     0x9bde34: sub             SP, SP, #8
    // 0x9bde38: CheckStackOverflow
    //     0x9bde38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bde3c: cmp             SP, x16
    //     0x9bde40: b.ls            #0x9bdfe4
    // 0x9bde44: ldr             x0, [fp, #0x10]
    // 0x9bde48: r2 = Null
    //     0x9bde48: mov             x2, NULL
    // 0x9bde4c: r1 = Null
    //     0x9bde4c: mov             x1, NULL
    // 0x9bde50: r4 = 59
    //     0x9bde50: mov             x4, #0x3b
    // 0x9bde54: branchIfSmi(r0, 0x9bde60)
    //     0x9bde54: tbz             w0, #0, #0x9bde60
    // 0x9bde58: r4 = LoadClassIdInstr(r0)
    //     0x9bde58: ldur            x4, [x0, #-1]
    //     0x9bde5c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bde60: cmp             x4, #0x7e6
    // 0x9bde64: b.eq            #0x9bde78
    // 0x9bde68: r8 = PipelineOwner
    //     0x9bde68: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bde6c: r3 = Null
    //     0x9bde6c: add             x3, PP, #0x56, lsl #12  ; [pp+0x56cc0] Null
    //     0x9bde70: ldr             x3, [x3, #0xcc0]
    // 0x9bde74: r0 = DefaultTypeTest()
    //     0x9bde74: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bde78: ldr             x16, [fp, #0x18]
    // 0x9bde7c: ldr             lr, [fp, #0x10]
    // 0x9bde80: stp             lr, x16, [SP, #-0x10]!
    // 0x9bde84: r0 = attach()
    //     0x9bde84: bl              #0x9be01c  ; [package:flutter/src/material/range_slider.dart] __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin::attach
    // 0x9bde88: add             SP, SP, #0x10
    // 0x9bde8c: ldr             x0, [fp, #0x18]
    // 0x9bde90: LoadField: r1 = r0->field_63
    //     0x9bde90: ldur            w1, [x0, #0x63]
    // 0x9bde94: DecompressPointer r1
    //     0x9bde94: add             x1, x1, HEAP, lsl #32
    // 0x9bde98: r16 = Sentinel
    //     0x9bde98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9bde9c: cmp             w1, w16
    // 0x9bdea0: b.eq            #0x9bdfec
    // 0x9bdea4: stur            x1, [fp, #-8]
    // 0x9bdea8: r1 = 1
    //     0x9bdea8: mov             x1, #1
    // 0x9bdeac: r0 = AllocateContext()
    //     0x9bdeac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bdeb0: mov             x1, x0
    // 0x9bdeb4: ldr             x0, [fp, #0x18]
    // 0x9bdeb8: StoreField: r1->field_f = r0
    //     0x9bdeb8: stur            w0, [x1, #0xf]
    // 0x9bdebc: mov             x2, x1
    // 0x9bdec0: r1 = Function 'markNeedsPaint':.
    //     0x9bdec0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bdec4: ldr             x1, [x1, #0xf60]
    // 0x9bdec8: r0 = AllocateClosure()
    //     0x9bdec8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bdecc: ldur            x16, [fp, #-8]
    // 0x9bded0: stp             x0, x16, [SP, #-0x10]!
    // 0x9bded4: r0 = addListener()
    //     0x9bded4: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x9bded8: add             SP, SP, #0x10
    // 0x9bdedc: ldr             x0, [fp, #0x18]
    // 0x9bdee0: LoadField: r1 = r0->field_67
    //     0x9bdee0: ldur            w1, [x0, #0x67]
    // 0x9bdee4: DecompressPointer r1
    //     0x9bdee4: add             x1, x1, HEAP, lsl #32
    // 0x9bdee8: r16 = Sentinel
    //     0x9bdee8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9bdeec: cmp             w1, w16
    // 0x9bdef0: b.eq            #0x9bdff8
    // 0x9bdef4: stur            x1, [fp, #-8]
    // 0x9bdef8: r1 = 1
    //     0x9bdef8: mov             x1, #1
    // 0x9bdefc: r0 = AllocateContext()
    //     0x9bdefc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bdf00: mov             x1, x0
    // 0x9bdf04: ldr             x0, [fp, #0x18]
    // 0x9bdf08: StoreField: r1->field_f = r0
    //     0x9bdf08: stur            w0, [x1, #0xf]
    // 0x9bdf0c: mov             x2, x1
    // 0x9bdf10: r1 = Function 'markNeedsPaint':.
    //     0x9bdf10: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bdf14: ldr             x1, [x1, #0xf60]
    // 0x9bdf18: r0 = AllocateClosure()
    //     0x9bdf18: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bdf1c: ldur            x16, [fp, #-8]
    // 0x9bdf20: stp             x0, x16, [SP, #-0x10]!
    // 0x9bdf24: r0 = addListener()
    //     0x9bdf24: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x9bdf28: add             SP, SP, #0x10
    // 0x9bdf2c: ldr             x0, [fp, #0x18]
    // 0x9bdf30: LoadField: r1 = r0->field_6b
    //     0x9bdf30: ldur            w1, [x0, #0x6b]
    // 0x9bdf34: DecompressPointer r1
    //     0x9bdf34: add             x1, x1, HEAP, lsl #32
    // 0x9bdf38: r16 = Sentinel
    //     0x9bdf38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9bdf3c: cmp             w1, w16
    // 0x9bdf40: b.eq            #0x9be004
    // 0x9bdf44: stur            x1, [fp, #-8]
    // 0x9bdf48: r1 = 1
    //     0x9bdf48: mov             x1, #1
    // 0x9bdf4c: r0 = AllocateContext()
    //     0x9bdf4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bdf50: mov             x1, x0
    // 0x9bdf54: ldr             x0, [fp, #0x18]
    // 0x9bdf58: StoreField: r1->field_f = r0
    //     0x9bdf58: stur            w0, [x1, #0xf]
    // 0x9bdf5c: mov             x2, x1
    // 0x9bdf60: r1 = Function 'markNeedsPaint':.
    //     0x9bdf60: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bdf64: ldr             x1, [x1, #0xf60]
    // 0x9bdf68: r0 = AllocateClosure()
    //     0x9bdf68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bdf6c: ldur            x16, [fp, #-8]
    // 0x9bdf70: stp             x0, x16, [SP, #-0x10]!
    // 0x9bdf74: r0 = addListener()
    //     0x9bdf74: bl              #0x6e88f0  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::addListener
    // 0x9bdf78: add             SP, SP, #0x10
    // 0x9bdf7c: ldr             x0, [fp, #0x18]
    // 0x9bdf80: LoadField: r1 = r0->field_5f
    //     0x9bdf80: ldur            w1, [x0, #0x5f]
    // 0x9bdf84: DecompressPointer r1
    //     0x9bdf84: add             x1, x1, HEAP, lsl #32
    // 0x9bdf88: LoadField: r2 = r1->field_27
    //     0x9bdf88: ldur            w2, [x1, #0x27]
    // 0x9bdf8c: DecompressPointer r2
    //     0x9bdf8c: add             x2, x2, HEAP, lsl #32
    // 0x9bdf90: r16 = Sentinel
    //     0x9bdf90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9bdf94: cmp             w2, w16
    // 0x9bdf98: b.eq            #0x9be010
    // 0x9bdf9c: stur            x2, [fp, #-8]
    // 0x9bdfa0: r1 = 1
    //     0x9bdfa0: mov             x1, #1
    // 0x9bdfa4: r0 = AllocateContext()
    //     0x9bdfa4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bdfa8: mov             x1, x0
    // 0x9bdfac: ldr             x0, [fp, #0x18]
    // 0x9bdfb0: StoreField: r1->field_f = r0
    //     0x9bdfb0: stur            w0, [x1, #0xf]
    // 0x9bdfb4: mov             x2, x1
    // 0x9bdfb8: r1 = Function 'markNeedsPaint':.
    //     0x9bdfb8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x9bdfbc: ldr             x1, [x1, #0xf60]
    // 0x9bdfc0: r0 = AllocateClosure()
    //     0x9bdfc0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bdfc4: ldur            x16, [fp, #-8]
    // 0x9bdfc8: stp             x0, x16, [SP, #-0x10]!
    // 0x9bdfcc: r0 = addActionListener()
    //     0x9bdfcc: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9bdfd0: add             SP, SP, #0x10
    // 0x9bdfd4: r0 = Null
    //     0x9bdfd4: mov             x0, NULL
    // 0x9bdfd8: LeaveFrame
    //     0x9bdfd8: mov             SP, fp
    //     0x9bdfdc: ldp             fp, lr, [SP], #0x10
    // 0x9bdfe0: ret
    //     0x9bdfe0: ret             
    // 0x9bdfe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bdfe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bdfe8: b               #0x9bde44
    // 0x9bdfec: r9 = _overlayAnimation
    //     0x9bdfec: add             x9, PP, #0x56, lsl #12  ; [pp+0x56c70] Field <_RenderSlider@810231897._overlayAnimation@810231897>: late (offset: 0x64)
    //     0x9bdff0: ldr             x9, [x9, #0xc70]
    // 0x9bdff4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9bdff4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9bdff8: r9 = _valueIndicatorAnimation
    //     0x9bdff8: add             x9, PP, #0x56, lsl #12  ; [pp+0x56cb8] Field <_RenderSlider@810231897._valueIndicatorAnimation@810231897>: late (offset: 0x68)
    //     0x9bdffc: ldr             x9, [x9, #0xcb8]
    // 0x9be000: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9be000: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9be004: r9 = _enableAnimation
    //     0x9be004: add             x9, PP, #0x56, lsl #12  ; [pp+0x56c68] Field <_RenderSlider@810231897._enableAnimation@810231897>: late (offset: 0x6c)
    //     0x9be008: ldr             x9, [x9, #0xc68]
    // 0x9be00c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9be00c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9be010: r9 = positionController
    //     0x9be010: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0x9be014: ldr             x9, [x9, #0x838]
    // 0x9be018: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9be018: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void systemFontsDidChange(dynamic) {
    // ** addr: 0x9be12c, size: 0x48
    // 0x9be12c: EnterFrame
    //     0x9be12c: stp             fp, lr, [SP, #-0x10]!
    //     0x9be130: mov             fp, SP
    // 0x9be134: ldr             x0, [fp, #0x10]
    // 0x9be138: LoadField: r1 = r0->field_17
    //     0x9be138: ldur            w1, [x0, #0x17]
    // 0x9be13c: DecompressPointer r1
    //     0x9be13c: add             x1, x1, HEAP, lsl #32
    // 0x9be140: CheckStackOverflow
    //     0x9be140: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9be144: cmp             SP, x16
    //     0x9be148: b.ls            #0x9be16c
    // 0x9be14c: LoadField: r0 = r1->field_f
    //     0x9be14c: ldur            w0, [x1, #0xf]
    // 0x9be150: DecompressPointer r0
    //     0x9be150: add             x0, x0, HEAP, lsl #32
    // 0x9be154: SaveReg r0
    //     0x9be154: str             x0, [SP, #-8]!
    // 0x9be158: r0 = systemFontsDidChange()
    //     0x9be158: bl              #0x9be174  ; [package:flutter/src/material/slider.dart] _RenderSlider::systemFontsDidChange
    // 0x9be15c: add             SP, SP, #8
    // 0x9be160: LeaveFrame
    //     0x9be160: mov             SP, fp
    //     0x9be164: ldp             fp, lr, [SP], #0x10
    // 0x9be168: ret
    //     0x9be168: ret             
    // 0x9be16c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9be16c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9be170: b               #0x9be14c
  }
  _ systemFontsDidChange(/* No info */) {
    // ** addr: 0x9be174, size: 0x64
    // 0x9be174: EnterFrame
    //     0x9be174: stp             fp, lr, [SP, #-0x10]!
    //     0x9be178: mov             fp, SP
    // 0x9be17c: CheckStackOverflow
    //     0x9be17c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9be180: cmp             SP, x16
    //     0x9be184: b.ls            #0x9be1d0
    // 0x9be188: ldr             x16, [fp, #0x10]
    // 0x9be18c: SaveReg r16
    //     0x9be18c: str             x16, [SP, #-8]!
    // 0x9be190: r0 = markNeedsLayout()
    //     0x9be190: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x9be194: add             SP, SP, #8
    // 0x9be198: ldr             x0, [fp, #0x10]
    // 0x9be19c: LoadField: r1 = r0->field_6f
    //     0x9be19c: ldur            w1, [x0, #0x6f]
    // 0x9be1a0: DecompressPointer r1
    //     0x9be1a0: add             x1, x1, HEAP, lsl #32
    // 0x9be1a4: SaveReg r1
    //     0x9be1a4: str             x1, [SP, #-8]!
    // 0x9be1a8: r0 = markNeedsLayout()
    //     0x9be1a8: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x9be1ac: add             SP, SP, #8
    // 0x9be1b0: ldr             x16, [fp, #0x10]
    // 0x9be1b4: SaveReg r16
    //     0x9be1b4: str             x16, [SP, #-8]!
    // 0x9be1b8: r0 = _updateLabelPainter()
    //     0x9be1b8: bl              #0x6d2f28  ; [package:flutter/src/material/slider.dart] _RenderSlider::_updateLabelPainter
    // 0x9be1bc: add             SP, SP, #8
    // 0x9be1c0: r0 = Null
    //     0x9be1c0: mov             x0, NULL
    // 0x9be1c4: LeaveFrame
    //     0x9be1c4: mov             SP, fp
    //     0x9be1c8: ldp             fp, lr, [SP], #0x10
    // 0x9be1cc: ret
    //     0x9be1cc: ret             
    // 0x9be1d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9be1d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9be1d4: b               #0x9be188
  }
  _ computeDryLayout(/* No info */) {
    // ** addr: 0xa5e710, size: 0x130
    // 0xa5e710: EnterFrame
    //     0xa5e710: stp             fp, lr, [SP, #-0x10]!
    //     0xa5e714: mov             fp, SP
    // 0xa5e718: AllocStack(0x18)
    //     0xa5e718: sub             SP, SP, #0x18
    // 0xa5e71c: d0 = inf
    //     0xa5e71c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e720: CheckStackOverflow
    //     0xa5e720: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5e724: cmp             SP, x16
    //     0xa5e728: b.ls            #0xa5e834
    // 0xa5e72c: ldr             x0, [fp, #0x10]
    // 0xa5e730: LoadField: d1 = r0->field_f
    //     0xa5e730: ldur            d1, [x0, #0xf]
    // 0xa5e734: fcmp            d1, d0
    // 0xa5e738: b.vs            #0xa5e740
    // 0xa5e73c: b.lt            #0xa5e76c
    // 0xa5e740: ldr             x16, [fp, #0x18]
    // 0xa5e744: SaveReg r16
    //     0xa5e744: str             x16, [SP, #-8]!
    // 0xa5e748: r0 = _maxSliderPartWidth()
    //     0xa5e748: bl              #0x636b9c  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartWidth
    // 0xa5e74c: add             SP, SP, #8
    // 0xa5e750: mov             v1.16b, v0.16b
    // 0xa5e754: d0 = 144.000000
    //     0xa5e754: add             x17, PP, #0x56, lsl #12  ; [pp+0x56c38] IMM: double(144) from 0x4062000000000000
    //     0xa5e758: ldr             d0, [x17, #0xc38]
    // 0xa5e75c: fadd            d2, d0, d1
    // 0xa5e760: mov             v1.16b, v2.16b
    // 0xa5e764: ldr             x0, [fp, #0x10]
    // 0xa5e768: d0 = inf
    //     0xa5e768: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0xa5e76c: stur            d1, [fp, #-0x10]
    // 0xa5e770: LoadField: d2 = r0->field_1f
    //     0xa5e770: ldur            d2, [x0, #0x1f]
    // 0xa5e774: fcmp            d2, d0
    // 0xa5e778: b.vs            #0xa5e78c
    // 0xa5e77c: b.ge            #0xa5e78c
    // 0xa5e780: mov             v0.16b, v1.16b
    // 0xa5e784: mov             v1.16b, v2.16b
    // 0xa5e788: b               #0xa5e810
    // 0xa5e78c: ldr             x0, [fp, #0x18]
    // 0xa5e790: LoadField: r1 = r0->field_a7
    //     0xa5e790: ldur            w1, [x0, #0xa7]
    // 0xa5e794: DecompressPointer r1
    //     0xa5e794: add             x1, x1, HEAP, lsl #32
    // 0xa5e798: LoadField: r2 = r1->field_7
    //     0xa5e798: ldur            w2, [x1, #7]
    // 0xa5e79c: DecompressPointer r2
    //     0xa5e79c: add             x2, x2, HEAP, lsl #32
    // 0xa5e7a0: stur            x2, [fp, #-8]
    // 0xa5e7a4: cmp             w2, NULL
    // 0xa5e7a8: b.eq            #0xa5e83c
    // 0xa5e7ac: SaveReg r0
    //     0xa5e7ac: str             x0, [SP, #-8]!
    // 0xa5e7b0: r0 = _maxSliderPartHeight()
    //     0xa5e7b0: bl              #0x6310a0  ; [package:flutter/src/material/slider.dart] _RenderSlider::_maxSliderPartHeight
    // 0xa5e7b4: add             SP, SP, #8
    // 0xa5e7b8: ldur            x0, [fp, #-8]
    // 0xa5e7bc: LoadField: d1 = r0->field_7
    //     0xa5e7bc: ldur            d1, [x0, #7]
    // 0xa5e7c0: fcmp            d1, d0
    // 0xa5e7c4: b.vs            #0xa5e7d4
    // 0xa5e7c8: b.le            #0xa5e7d4
    // 0xa5e7cc: LoadField: d0 = r0->field_7
    //     0xa5e7cc: ldur            d0, [x0, #7]
    // 0xa5e7d0: b               #0xa5e808
    // 0xa5e7d4: fcmp            d1, d0
    // 0xa5e7d8: b.vs            #0xa5e7e0
    // 0xa5e7dc: b.lt            #0xa5e808
    // 0xa5e7e0: d2 = 0.000000
    //     0xa5e7e0: eor             v2.16b, v2.16b, v2.16b
    // 0xa5e7e4: fcmp            d1, d2
    // 0xa5e7e8: b.vs            #0xa5e7fc
    // 0xa5e7ec: b.ne            #0xa5e7fc
    // 0xa5e7f0: fadd            d2, d1, d0
    // 0xa5e7f4: mov             v0.16b, v2.16b
    // 0xa5e7f8: b               #0xa5e808
    // 0xa5e7fc: fcmp            d0, d0
    // 0xa5e800: b.vs            #0xa5e808
    // 0xa5e804: LoadField: d0 = r0->field_7
    //     0xa5e804: ldur            d0, [x0, #7]
    // 0xa5e808: mov             v1.16b, v0.16b
    // 0xa5e80c: ldur            d0, [fp, #-0x10]
    // 0xa5e810: stur            d1, [fp, #-0x18]
    // 0xa5e814: r0 = Size()
    //     0xa5e814: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xa5e818: ldur            d0, [fp, #-0x10]
    // 0xa5e81c: StoreField: r0->field_7 = d0
    //     0xa5e81c: stur            d0, [x0, #7]
    // 0xa5e820: ldur            d0, [fp, #-0x18]
    // 0xa5e824: StoreField: r0->field_f = d0
    //     0xa5e824: stur            d0, [x0, #0xf]
    // 0xa5e828: LeaveFrame
    //     0xa5e828: mov             SP, fp
    //     0xa5e82c: ldp             fp, lr, [SP], #0x10
    // 0xa5e830: ret
    //     0xa5e830: ret             
    // 0xa5e834: r0 = StackOverflowSharedWithFPURegs()
    //     0xa5e834: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa5e838: b               #0xa5e72c
    // 0xa5e83c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xa5e83c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa69a34, size: 0x1b8
    // 0xa69a34: EnterFrame
    //     0xa69a34: stp             fp, lr, [SP, #-0x10]!
    //     0xa69a38: mov             fp, SP
    // 0xa69a3c: AllocStack(0x8)
    //     0xa69a3c: sub             SP, SP, #8
    // 0xa69a40: CheckStackOverflow
    //     0xa69a40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69a44: cmp             SP, x16
    //     0xa69a48: b.ls            #0xa69bb4
    // 0xa69a4c: ldr             x0, [fp, #0x10]
    // 0xa69a50: LoadField: r1 = r0->field_63
    //     0xa69a50: ldur            w1, [x0, #0x63]
    // 0xa69a54: DecompressPointer r1
    //     0xa69a54: add             x1, x1, HEAP, lsl #32
    // 0xa69a58: r16 = Sentinel
    //     0xa69a58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69a5c: cmp             w1, w16
    // 0xa69a60: b.eq            #0xa69bbc
    // 0xa69a64: stur            x1, [fp, #-8]
    // 0xa69a68: r1 = 1
    //     0xa69a68: mov             x1, #1
    // 0xa69a6c: r0 = AllocateContext()
    //     0xa69a6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69a70: mov             x1, x0
    // 0xa69a74: ldr             x0, [fp, #0x10]
    // 0xa69a78: StoreField: r1->field_f = r0
    //     0xa69a78: stur            w0, [x1, #0xf]
    // 0xa69a7c: mov             x2, x1
    // 0xa69a80: r1 = Function 'markNeedsPaint':.
    //     0xa69a80: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa69a84: ldr             x1, [x1, #0xf60]
    // 0xa69a88: r0 = AllocateClosure()
    //     0xa69a88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69a8c: ldur            x16, [fp, #-8]
    // 0xa69a90: stp             x0, x16, [SP, #-0x10]!
    // 0xa69a94: r0 = removeListener()
    //     0xa69a94: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0xa69a98: add             SP, SP, #0x10
    // 0xa69a9c: ldr             x0, [fp, #0x10]
    // 0xa69aa0: LoadField: r1 = r0->field_67
    //     0xa69aa0: ldur            w1, [x0, #0x67]
    // 0xa69aa4: DecompressPointer r1
    //     0xa69aa4: add             x1, x1, HEAP, lsl #32
    // 0xa69aa8: r16 = Sentinel
    //     0xa69aa8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69aac: cmp             w1, w16
    // 0xa69ab0: b.eq            #0xa69bc8
    // 0xa69ab4: stur            x1, [fp, #-8]
    // 0xa69ab8: r1 = 1
    //     0xa69ab8: mov             x1, #1
    // 0xa69abc: r0 = AllocateContext()
    //     0xa69abc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69ac0: mov             x1, x0
    // 0xa69ac4: ldr             x0, [fp, #0x10]
    // 0xa69ac8: StoreField: r1->field_f = r0
    //     0xa69ac8: stur            w0, [x1, #0xf]
    // 0xa69acc: mov             x2, x1
    // 0xa69ad0: r1 = Function 'markNeedsPaint':.
    //     0xa69ad0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa69ad4: ldr             x1, [x1, #0xf60]
    // 0xa69ad8: r0 = AllocateClosure()
    //     0xa69ad8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69adc: ldur            x16, [fp, #-8]
    // 0xa69ae0: stp             x0, x16, [SP, #-0x10]!
    // 0xa69ae4: r0 = removeListener()
    //     0xa69ae4: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0xa69ae8: add             SP, SP, #0x10
    // 0xa69aec: ldr             x0, [fp, #0x10]
    // 0xa69af0: LoadField: r1 = r0->field_6b
    //     0xa69af0: ldur            w1, [x0, #0x6b]
    // 0xa69af4: DecompressPointer r1
    //     0xa69af4: add             x1, x1, HEAP, lsl #32
    // 0xa69af8: r16 = Sentinel
    //     0xa69af8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69afc: cmp             w1, w16
    // 0xa69b00: b.eq            #0xa69bd4
    // 0xa69b04: stur            x1, [fp, #-8]
    // 0xa69b08: r1 = 1
    //     0xa69b08: mov             x1, #1
    // 0xa69b0c: r0 = AllocateContext()
    //     0xa69b0c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69b10: mov             x1, x0
    // 0xa69b14: ldr             x0, [fp, #0x10]
    // 0xa69b18: StoreField: r1->field_f = r0
    //     0xa69b18: stur            w0, [x1, #0xf]
    // 0xa69b1c: mov             x2, x1
    // 0xa69b20: r1 = Function 'markNeedsPaint':.
    //     0xa69b20: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa69b24: ldr             x1, [x1, #0xf60]
    // 0xa69b28: r0 = AllocateClosure()
    //     0xa69b28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69b2c: ldur            x16, [fp, #-8]
    // 0xa69b30: stp             x0, x16, [SP, #-0x10]!
    // 0xa69b34: r0 = removeListener()
    //     0xa69b34: bl              #0x6f5d64  ; [package:flutter/src/material/tabs.dart] __ChangeAnimation&Animation&AnimationWithParentMixin::removeListener
    // 0xa69b38: add             SP, SP, #0x10
    // 0xa69b3c: ldr             x0, [fp, #0x10]
    // 0xa69b40: LoadField: r1 = r0->field_5f
    //     0xa69b40: ldur            w1, [x0, #0x5f]
    // 0xa69b44: DecompressPointer r1
    //     0xa69b44: add             x1, x1, HEAP, lsl #32
    // 0xa69b48: LoadField: r2 = r1->field_27
    //     0xa69b48: ldur            w2, [x1, #0x27]
    // 0xa69b4c: DecompressPointer r2
    //     0xa69b4c: add             x2, x2, HEAP, lsl #32
    // 0xa69b50: r16 = Sentinel
    //     0xa69b50: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa69b54: cmp             w2, w16
    // 0xa69b58: b.eq            #0xa69be0
    // 0xa69b5c: stur            x2, [fp, #-8]
    // 0xa69b60: r1 = 1
    //     0xa69b60: mov             x1, #1
    // 0xa69b64: r0 = AllocateContext()
    //     0xa69b64: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa69b68: mov             x1, x0
    // 0xa69b6c: ldr             x0, [fp, #0x10]
    // 0xa69b70: StoreField: r1->field_f = r0
    //     0xa69b70: stur            w0, [x1, #0xf]
    // 0xa69b74: mov             x2, x1
    // 0xa69b78: r1 = Function 'markNeedsPaint':.
    //     0xa69b78: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0xa69b7c: ldr             x1, [x1, #0xf60]
    // 0xa69b80: r0 = AllocateClosure()
    //     0xa69b80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa69b84: ldur            x16, [fp, #-8]
    // 0xa69b88: stp             x0, x16, [SP, #-0x10]!
    // 0xa69b8c: r0 = removeListener()
    //     0xa69b8c: bl              #0x6f5e30  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin::removeListener
    // 0xa69b90: add             SP, SP, #0x10
    // 0xa69b94: ldr             x16, [fp, #0x10]
    // 0xa69b98: SaveReg r16
    //     0xa69b98: str             x16, [SP, #-8]!
    // 0xa69b9c: r0 = detach()
    //     0xa69b9c: bl              #0xa69bec  ; [package:flutter/src/material/range_slider.dart] __RenderRangeSlider&RenderBox&RelayoutWhenSystemFontsChangeMixin::detach
    // 0xa69ba0: add             SP, SP, #8
    // 0xa69ba4: r0 = Null
    //     0xa69ba4: mov             x0, NULL
    // 0xa69ba8: LeaveFrame
    //     0xa69ba8: mov             SP, fp
    //     0xa69bac: ldp             fp, lr, [SP], #0x10
    // 0xa69bb0: ret
    //     0xa69bb0: ret             
    // 0xa69bb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa69bb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa69bb8: b               #0xa69a4c
    // 0xa69bbc: r9 = _overlayAnimation
    //     0xa69bbc: add             x9, PP, #0x56, lsl #12  ; [pp+0x56c70] Field <_RenderSlider@810231897._overlayAnimation@810231897>: late (offset: 0x64)
    //     0xa69bc0: ldr             x9, [x9, #0xc70]
    // 0xa69bc4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa69bc4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa69bc8: r9 = _valueIndicatorAnimation
    //     0xa69bc8: add             x9, PP, #0x56, lsl #12  ; [pp+0x56cb8] Field <_RenderSlider@810231897._valueIndicatorAnimation@810231897>: late (offset: 0x68)
    //     0xa69bcc: ldr             x9, [x9, #0xcb8]
    // 0xa69bd0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa69bd0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa69bd4: r9 = _enableAnimation
    //     0xa69bd4: add             x9, PP, #0x56, lsl #12  ; [pp+0x56c68] Field <_RenderSlider@810231897._enableAnimation@810231897>: late (offset: 0x6c)
    //     0xa69bd8: ldr             x9, [x9, #0xc68]
    // 0xa69bdc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa69bdc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa69be0: r9 = positionController
    //     0xa69be0: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0xa69be4: ldr             x9, [x9, #0x838]
    // 0xa69be8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa69be8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] double <anonymous closure>(dynamic, Size) {
    // ** addr: 0xc43158, size: 0x54
    // 0xc43158: EnterFrame
    //     0xc43158: stp             fp, lr, [SP, #-0x10]!
    //     0xc4315c: mov             fp, SP
    // 0xc43160: ldr             x1, [fp, #0x10]
    // 0xc43164: LoadField: d0 = r1->field_7
    //     0xc43164: ldur            d0, [x1, #7]
    // 0xc43168: r0 = inline_Allocate_Double()
    //     0xc43168: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc4316c: add             x0, x0, #0x10
    //     0xc43170: cmp             x1, x0
    //     0xc43174: b.ls            #0xc4319c
    //     0xc43178: str             x0, [THR, #0x60]  ; THR::top
    //     0xc4317c: sub             x0, x0, #0xf
    //     0xc43180: mov             x1, #0xd108
    //     0xc43184: movk            x1, #3, lsl #16
    //     0xc43188: stur            x1, [x0, #-1]
    // 0xc4318c: StoreField: r0->field_7 = d0
    //     0xc4318c: stur            d0, [x0, #7]
    // 0xc43190: LeaveFrame
    //     0xc43190: mov             SP, fp
    //     0xc43194: ldp             fp, lr, [SP], #0x10
    // 0xc43198: ret
    //     0xc43198: ret             
    // 0xc4319c: SaveReg d0
    //     0xc4319c: str             q0, [SP, #-0x10]!
    // 0xc431a0: r0 = AllocateDouble()
    //     0xc431a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc431a4: RestoreReg d0
    //     0xc431a4: ldr             q0, [SP], #0x10
    // 0xc431a8: b               #0xc4318c
  }
}

// class id: 2728, size: 0x88, field offset: 0x80
class _SliderDefaultsM3 extends SliderThemeData {

  [closure] Color <anonymous closure>(dynamic, Set<MaterialState>) {
    // ** addr: 0x868120, size: 0x1a8
    // 0x868120: EnterFrame
    //     0x868120: stp             fp, lr, [SP, #-0x10]!
    //     0x868124: mov             fp, SP
    // 0x868128: AllocStack(0x8)
    //     0x868128: sub             SP, SP, #8
    // 0x86812c: SetupParameters()
    //     0x86812c: ldr             x0, [fp, #0x18]
    //     0x868130: ldur            w1, [x0, #0x17]
    //     0x868134: add             x1, x1, HEAP, lsl #32
    //     0x868138: stur            x1, [fp, #-8]
    // 0x86813c: CheckStackOverflow
    //     0x86813c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x868140: cmp             SP, x16
    //     0x868144: b.ls            #0x8682c0
    // 0x868148: ldr             x2, [fp, #0x10]
    // 0x86814c: r0 = LoadClassIdInstr(r2)
    //     0x86814c: ldur            x0, [x2, #-1]
    //     0x868150: ubfx            x0, x0, #0xc, #0x14
    // 0x868154: r16 = Instance_MaterialState
    //     0x868154: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x868158: ldr             x16, [x16, #0xf78]
    // 0x86815c: stp             x16, x2, [SP, #-0x10]!
    // 0x868160: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x868160: mov             x17, #0xc98a
    //     0x868164: add             lr, x0, x17
    //     0x868168: ldr             lr, [x21, lr, lsl #3]
    //     0x86816c: blr             lr
    // 0x868170: add             SP, SP, #0x10
    // 0x868174: tbnz            w0, #4, #0x8681b8
    // 0x868178: ldur            x1, [fp, #-8]
    // 0x86817c: d0 = 0.080000
    //     0x86817c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0x868180: ldr             d0, [x17, #0xf80]
    // 0x868184: LoadField: r0 = r1->field_f
    //     0x868184: ldur            w0, [x1, #0xf]
    // 0x868188: DecompressPointer r0
    //     0x868188: add             x0, x0, HEAP, lsl #32
    // 0x86818c: LoadField: r1 = r0->field_83
    //     0x86818c: ldur            w1, [x0, #0x83]
    // 0x868190: DecompressPointer r1
    //     0x868190: add             x1, x1, HEAP, lsl #32
    // 0x868194: LoadField: r0 = r1->field_b
    //     0x868194: ldur            w0, [x1, #0xb]
    // 0x868198: DecompressPointer r0
    //     0x868198: add             x0, x0, HEAP, lsl #32
    // 0x86819c: SaveReg r0
    //     0x86819c: str             x0, [SP, #-8]!
    // 0x8681a0: SaveReg d0
    //     0x8681a0: str             d0, [SP, #-8]!
    // 0x8681a4: r0 = withOpacity()
    //     0x8681a4: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8681a8: add             SP, SP, #0x10
    // 0x8681ac: LeaveFrame
    //     0x8681ac: mov             SP, fp
    //     0x8681b0: ldp             fp, lr, [SP], #0x10
    // 0x8681b4: ret
    //     0x8681b4: ret             
    // 0x8681b8: ldr             x2, [fp, #0x10]
    // 0x8681bc: ldur            x1, [fp, #-8]
    // 0x8681c0: r0 = LoadClassIdInstr(r2)
    //     0x8681c0: ldur            x0, [x2, #-1]
    //     0x8681c4: ubfx            x0, x0, #0xc, #0x14
    // 0x8681c8: r16 = Instance_MaterialState
    //     0x8681c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x8681cc: ldr             x16, [x16, #0xf88]
    // 0x8681d0: stp             x16, x2, [SP, #-0x10]!
    // 0x8681d4: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x8681d4: mov             x17, #0xc98a
    //     0x8681d8: add             lr, x0, x17
    //     0x8681dc: ldr             lr, [x21, lr, lsl #3]
    //     0x8681e0: blr             lr
    // 0x8681e4: add             SP, SP, #0x10
    // 0x8681e8: tbnz            w0, #4, #0x86822c
    // 0x8681ec: ldur            x1, [fp, #-8]
    // 0x8681f0: d0 = 0.120000
    //     0x8681f0: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x8681f4: ldr             d0, [x17, #0xf48]
    // 0x8681f8: LoadField: r0 = r1->field_f
    //     0x8681f8: ldur            w0, [x1, #0xf]
    // 0x8681fc: DecompressPointer r0
    //     0x8681fc: add             x0, x0, HEAP, lsl #32
    // 0x868200: LoadField: r1 = r0->field_83
    //     0x868200: ldur            w1, [x0, #0x83]
    // 0x868204: DecompressPointer r1
    //     0x868204: add             x1, x1, HEAP, lsl #32
    // 0x868208: LoadField: r0 = r1->field_b
    //     0x868208: ldur            w0, [x1, #0xb]
    // 0x86820c: DecompressPointer r0
    //     0x86820c: add             x0, x0, HEAP, lsl #32
    // 0x868210: SaveReg r0
    //     0x868210: str             x0, [SP, #-8]!
    // 0x868214: SaveReg d0
    //     0x868214: str             d0, [SP, #-8]!
    // 0x868218: r0 = withOpacity()
    //     0x868218: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86821c: add             SP, SP, #0x10
    // 0x868220: LeaveFrame
    //     0x868220: mov             SP, fp
    //     0x868224: ldp             fp, lr, [SP], #0x10
    // 0x868228: ret
    //     0x868228: ret             
    // 0x86822c: ldr             x0, [fp, #0x10]
    // 0x868230: ldur            x1, [fp, #-8]
    // 0x868234: d0 = 0.120000
    //     0x868234: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x868238: ldr             d0, [x17, #0xf48]
    // 0x86823c: r2 = LoadClassIdInstr(r0)
    //     0x86823c: ldur            x2, [x0, #-1]
    //     0x868240: ubfx            x2, x2, #0xc, #0x14
    // 0x868244: r16 = Instance_MaterialState
    //     0x868244: add             x16, PP, #0xe, lsl #12  ; [pp+0xe170] Obj!MaterialState@b654f1
    //     0x868248: ldr             x16, [x16, #0x170]
    // 0x86824c: stp             x16, x0, [SP, #-0x10]!
    // 0x868250: mov             x0, x2
    // 0x868254: r0 = GDT[cid_x0 + 0xc98a]()
    //     0x868254: mov             x17, #0xc98a
    //     0x868258: add             lr, x0, x17
    //     0x86825c: ldr             lr, [x21, lr, lsl #3]
    //     0x868260: blr             lr
    // 0x868264: add             SP, SP, #0x10
    // 0x868268: tbnz            w0, #4, #0x8682ac
    // 0x86826c: ldur            x0, [fp, #-8]
    // 0x868270: d0 = 0.120000
    //     0x868270: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0x868274: ldr             d0, [x17, #0xf48]
    // 0x868278: LoadField: r1 = r0->field_f
    //     0x868278: ldur            w1, [x0, #0xf]
    // 0x86827c: DecompressPointer r1
    //     0x86827c: add             x1, x1, HEAP, lsl #32
    // 0x868280: LoadField: r0 = r1->field_83
    //     0x868280: ldur            w0, [x1, #0x83]
    // 0x868284: DecompressPointer r0
    //     0x868284: add             x0, x0, HEAP, lsl #32
    // 0x868288: LoadField: r1 = r0->field_b
    //     0x868288: ldur            w1, [x0, #0xb]
    // 0x86828c: DecompressPointer r1
    //     0x86828c: add             x1, x1, HEAP, lsl #32
    // 0x868290: SaveReg r1
    //     0x868290: str             x1, [SP, #-8]!
    // 0x868294: SaveReg d0
    //     0x868294: str             d0, [SP, #-8]!
    // 0x868298: r0 = withOpacity()
    //     0x868298: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x86829c: add             SP, SP, #0x10
    // 0x8682a0: LeaveFrame
    //     0x8682a0: mov             SP, fp
    //     0x8682a4: ldp             fp, lr, [SP], #0x10
    // 0x8682a8: ret
    //     0x8682a8: ret             
    // 0x8682ac: r0 = Instance_Color
    //     0x8682ac: add             x0, PP, #0xc, lsl #12  ; [pp+0xcc08] Obj!Color@b5d661
    //     0x8682b0: ldr             x0, [x0, #0xc08]
    // 0x8682b4: LeaveFrame
    //     0x8682b4: mov             SP, fp
    //     0x8682b8: ldp             fp, lr, [SP], #0x10
    // 0x8682bc: ret
    //     0x8682bc: ret             
    // 0x8682c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8682c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8682c4: b               #0x868148
  }
  get _ valueIndicatorShape(/* No info */) {
    // ** addr: 0xcebd5c, size: 0xc
    // 0xcebd5c: r0 = Instance_DropSliderValueIndicatorShape
    //     0xcebd5c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe158] Obj!DropSliderValueIndicatorShape@b37bf1
    //     0xcebd60: ldr             x0, [x0, #0x158]
    // 0xcebd64: ret
    //     0xcebd64: ret             
  }
  get _ valueIndicatorTextStyle(/* No info */) {
    // ** addr: 0xcebdfc, size: 0x84
    // 0xcebdfc: EnterFrame
    //     0xcebdfc: stp             fp, lr, [SP, #-0x10]!
    //     0xcebe00: mov             fp, SP
    // 0xcebe04: CheckStackOverflow
    //     0xcebe04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebe08: cmp             SP, x16
    //     0xcebe0c: b.ls            #0xcebe74
    // 0xcebe10: ldr             x0, [fp, #0x10]
    // 0xcebe14: LoadField: r1 = r0->field_7f
    //     0xcebe14: ldur            w1, [x0, #0x7f]
    // 0xcebe18: DecompressPointer r1
    //     0xcebe18: add             x1, x1, HEAP, lsl #32
    // 0xcebe1c: SaveReg r1
    //     0xcebe1c: str             x1, [SP, #-8]!
    // 0xcebe20: r0 = of()
    //     0xcebe20: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcebe24: add             SP, SP, #8
    // 0xcebe28: LoadField: r1 = r0->field_93
    //     0xcebe28: ldur            w1, [x0, #0x93]
    // 0xcebe2c: DecompressPointer r1
    //     0xcebe2c: add             x1, x1, HEAP, lsl #32
    // 0xcebe30: LoadField: r0 = r1->field_3b
    //     0xcebe30: ldur            w0, [x1, #0x3b]
    // 0xcebe34: DecompressPointer r0
    //     0xcebe34: add             x0, x0, HEAP, lsl #32
    // 0xcebe38: cmp             w0, NULL
    // 0xcebe3c: b.eq            #0xcebe7c
    // 0xcebe40: ldr             x1, [fp, #0x10]
    // 0xcebe44: LoadField: r2 = r1->field_83
    //     0xcebe44: ldur            w2, [x1, #0x83]
    // 0xcebe48: DecompressPointer r2
    //     0xcebe48: add             x2, x2, HEAP, lsl #32
    // 0xcebe4c: LoadField: r1 = r2->field_f
    //     0xcebe4c: ldur            w1, [x2, #0xf]
    // 0xcebe50: DecompressPointer r1
    //     0xcebe50: add             x1, x1, HEAP, lsl #32
    // 0xcebe54: stp             x1, x0, [SP, #-0x10]!
    // 0xcebe58: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xcebe58: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xcebe5c: ldr             x4, [x4, #0x168]
    // 0xcebe60: r0 = copyWith()
    //     0xcebe60: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xcebe64: add             SP, SP, #0x10
    // 0xcebe68: LeaveFrame
    //     0xcebe68: mov             SP, fp
    //     0xcebe6c: ldp             fp, lr, [SP], #0x10
    // 0xcebe70: ret
    //     0xcebe70: ret             
    // 0xcebe74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcebe74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcebe78: b               #0xcebe10
    // 0xcebe7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcebe7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xcebee4, size: 0x58
    // 0xcebee4: EnterFrame
    //     0xcebee4: stp             fp, lr, [SP, #-0x10]!
    //     0xcebee8: mov             fp, SP
    // 0xcebeec: CheckStackOverflow
    //     0xcebeec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebef0: cmp             SP, x16
    //     0xcebef4: b.ls            #0xcebf34
    // 0xcebef8: r1 = 1
    //     0xcebef8: mov             x1, #1
    // 0xcebefc: r0 = AllocateContext()
    //     0xcebefc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcebf00: mov             x1, x0
    // 0xcebf04: ldr             x0, [fp, #0x10]
    // 0xcebf08: StoreField: r1->field_f = r0
    //     0xcebf08: stur            w0, [x1, #0xf]
    // 0xcebf0c: mov             x2, x1
    // 0xcebf10: r1 = Function '<anonymous closure>':.
    //     0xcebf10: add             x1, PP, #0xe, lsl #12  ; [pp+0xe150] AnonymousClosure: (0x868120), in [package:flutter/src/material/slider.dart] _SliderDefaultsM3::overlayColor (0xcebee4)
    //     0xcebf14: ldr             x1, [x1, #0x150]
    // 0xcebf18: r0 = AllocateClosure()
    //     0xcebf18: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcebf1c: SaveReg r0
    //     0xcebf1c: str             x0, [SP, #-8]!
    // 0xcebf20: r0 = resolveWith()
    //     0xcebf20: bl              #0x85c570  ; [package:flutter/src/material/material_state.dart] MaterialStateColor::resolveWith
    // 0xcebf24: add             SP, SP, #8
    // 0xcebf28: LeaveFrame
    //     0xcebf28: mov             SP, fp
    //     0xcebf2c: ldp             fp, lr, [SP], #0x10
    // 0xcebf30: ret
    //     0xcebf30: ret             
    // 0xcebf34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcebf34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcebf38: b               #0xcebef8
  }
  get _ disabledThumbColor(/* No info */) {
    // ** addr: 0xcebf4c, size: 0x78
    // 0xcebf4c: EnterFrame
    //     0xcebf4c: stp             fp, lr, [SP, #-0x10]!
    //     0xcebf50: mov             fp, SP
    // 0xcebf54: AllocStack(0x8)
    //     0xcebf54: sub             SP, SP, #8
    // 0xcebf58: d0 = 0.380000
    //     0xcebf58: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xcebf5c: ldr             d0, [x17, #0x140]
    // 0xcebf60: CheckStackOverflow
    //     0xcebf60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebf64: cmp             SP, x16
    //     0xcebf68: b.ls            #0xcebfbc
    // 0xcebf6c: ldr             x0, [fp, #0x10]
    // 0xcebf70: LoadField: r1 = r0->field_83
    //     0xcebf70: ldur            w1, [x0, #0x83]
    // 0xcebf74: DecompressPointer r1
    //     0xcebf74: add             x1, x1, HEAP, lsl #32
    // 0xcebf78: stur            x1, [fp, #-8]
    // 0xcebf7c: LoadField: r0 = r1->field_57
    //     0xcebf7c: ldur            w0, [x1, #0x57]
    // 0xcebf80: DecompressPointer r0
    //     0xcebf80: add             x0, x0, HEAP, lsl #32
    // 0xcebf84: SaveReg r0
    //     0xcebf84: str             x0, [SP, #-8]!
    // 0xcebf88: SaveReg d0
    //     0xcebf88: str             d0, [SP, #-8]!
    // 0xcebf8c: r0 = withOpacity()
    //     0xcebf8c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcebf90: add             SP, SP, #0x10
    // 0xcebf94: mov             x1, x0
    // 0xcebf98: ldur            x0, [fp, #-8]
    // 0xcebf9c: LoadField: r2 = r0->field_53
    //     0xcebf9c: ldur            w2, [x0, #0x53]
    // 0xcebfa0: DecompressPointer r2
    //     0xcebfa0: add             x2, x2, HEAP, lsl #32
    // 0xcebfa4: stp             x2, x1, [SP, #-0x10]!
    // 0xcebfa8: r0 = alphaBlend()
    //     0xcebfa8: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0xcebfac: add             SP, SP, #0x10
    // 0xcebfb0: LeaveFrame
    //     0xcebfb0: mov             SP, fp
    //     0xcebfb4: ldp             fp, lr, [SP], #0x10
    // 0xcebfb8: ret
    //     0xcebfb8: ret             
    // 0xcebfbc: r0 = StackOverflowSharedWithFPURegs()
    //     0xcebfbc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcebfc0: b               #0xcebf6c
  }
  get _ inactiveTickMarkColor(/* No info */) {
    // ** addr: 0xcec058, size: 0x64
    // 0xcec058: EnterFrame
    //     0xcec058: stp             fp, lr, [SP, #-0x10]!
    //     0xcec05c: mov             fp, SP
    // 0xcec060: CheckStackOverflow
    //     0xcec060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec064: cmp             SP, x16
    //     0xcec068: b.ls            #0xcec0b4
    // 0xcec06c: ldr             x0, [fp, #0x10]
    // 0xcec070: LoadField: r1 = r0->field_83
    //     0xcec070: ldur            w1, [x0, #0x83]
    // 0xcec074: DecompressPointer r1
    //     0xcec074: add             x1, x1, HEAP, lsl #32
    // 0xcec078: LoadField: r0 = r1->field_5f
    //     0xcec078: ldur            w0, [x1, #0x5f]
    // 0xcec07c: DecompressPointer r0
    //     0xcec07c: add             x0, x0, HEAP, lsl #32
    // 0xcec080: cmp             w0, NULL
    // 0xcec084: b.ne            #0xcec090
    // 0xcec088: LoadField: r0 = r1->field_57
    //     0xcec088: ldur            w0, [x1, #0x57]
    // 0xcec08c: DecompressPointer r0
    //     0xcec08c: add             x0, x0, HEAP, lsl #32
    // 0xcec090: d0 = 0.380000
    //     0xcec090: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xcec094: ldr             d0, [x17, #0x140]
    // 0xcec098: SaveReg r0
    //     0xcec098: str             x0, [SP, #-8]!
    // 0xcec09c: SaveReg d0
    //     0xcec09c: str             d0, [SP, #-8]!
    // 0xcec0a0: r0 = withOpacity()
    //     0xcec0a0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec0a4: add             SP, SP, #0x10
    // 0xcec0a8: LeaveFrame
    //     0xcec0a8: mov             SP, fp
    //     0xcec0ac: ldp             fp, lr, [SP], #0x10
    // 0xcec0b0: ret
    //     0xcec0b0: ret             
    // 0xcec0b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcec0b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcec0b8: b               #0xcec06c
  }
  get _ activeTickMarkColor(/* No info */) {
    // ** addr: 0xcec120, size: 0x54
    // 0xcec120: EnterFrame
    //     0xcec120: stp             fp, lr, [SP, #-0x10]!
    //     0xcec124: mov             fp, SP
    // 0xcec128: d0 = 0.380000
    //     0xcec128: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xcec12c: ldr             d0, [x17, #0x140]
    // 0xcec130: CheckStackOverflow
    //     0xcec130: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec134: cmp             SP, x16
    //     0xcec138: b.ls            #0xcec16c
    // 0xcec13c: ldr             x0, [fp, #0x10]
    // 0xcec140: LoadField: r1 = r0->field_83
    //     0xcec140: ldur            w1, [x0, #0x83]
    // 0xcec144: DecompressPointer r1
    //     0xcec144: add             x1, x1, HEAP, lsl #32
    // 0xcec148: LoadField: r0 = r1->field_f
    //     0xcec148: ldur            w0, [x1, #0xf]
    // 0xcec14c: DecompressPointer r0
    //     0xcec14c: add             x0, x0, HEAP, lsl #32
    // 0xcec150: SaveReg r0
    //     0xcec150: str             x0, [SP, #-8]!
    // 0xcec154: SaveReg d0
    //     0xcec154: str             d0, [SP, #-8]!
    // 0xcec158: r0 = withOpacity()
    //     0xcec158: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec15c: add             SP, SP, #0x10
    // 0xcec160: LeaveFrame
    //     0xcec160: mov             SP, fp
    //     0xcec164: ldp             fp, lr, [SP], #0x10
    // 0xcec168: ret
    //     0xcec168: ret             
    // 0xcec16c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec16c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec170: b               #0xcec13c
  }
  get _ disabledInactiveTrackColor(/* No info */) {
    // ** addr: 0xcec174, size: 0x54
    // 0xcec174: EnterFrame
    //     0xcec174: stp             fp, lr, [SP, #-0x10]!
    //     0xcec178: mov             fp, SP
    // 0xcec17c: d0 = 0.120000
    //     0xcec17c: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xcec180: ldr             d0, [x17, #0xf48]
    // 0xcec184: CheckStackOverflow
    //     0xcec184: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec188: cmp             SP, x16
    //     0xcec18c: b.ls            #0xcec1c0
    // 0xcec190: ldr             x0, [fp, #0x10]
    // 0xcec194: LoadField: r1 = r0->field_83
    //     0xcec194: ldur            w1, [x0, #0x83]
    // 0xcec198: DecompressPointer r1
    //     0xcec198: add             x1, x1, HEAP, lsl #32
    // 0xcec19c: LoadField: r0 = r1->field_57
    //     0xcec19c: ldur            w0, [x1, #0x57]
    // 0xcec1a0: DecompressPointer r0
    //     0xcec1a0: add             x0, x0, HEAP, lsl #32
    // 0xcec1a4: SaveReg r0
    //     0xcec1a4: str             x0, [SP, #-8]!
    // 0xcec1a8: SaveReg d0
    //     0xcec1a8: str             d0, [SP, #-8]!
    // 0xcec1ac: r0 = withOpacity()
    //     0xcec1ac: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec1b0: add             SP, SP, #0x10
    // 0xcec1b4: LeaveFrame
    //     0xcec1b4: mov             SP, fp
    //     0xcec1b8: ldp             fp, lr, [SP], #0x10
    // 0xcec1bc: ret
    //     0xcec1bc: ret             
    // 0xcec1c0: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec1c0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec1c4: b               #0xcec190
  }
  get _ disabledActiveTrackColor(/* No info */) {
    // ** addr: 0xcec22c, size: 0x54
    // 0xcec22c: EnterFrame
    //     0xcec22c: stp             fp, lr, [SP, #-0x10]!
    //     0xcec230: mov             fp, SP
    // 0xcec234: d0 = 0.380000
    //     0xcec234: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xcec238: ldr             d0, [x17, #0x140]
    // 0xcec23c: CheckStackOverflow
    //     0xcec23c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec240: cmp             SP, x16
    //     0xcec244: b.ls            #0xcec278
    // 0xcec248: ldr             x0, [fp, #0x10]
    // 0xcec24c: LoadField: r1 = r0->field_83
    //     0xcec24c: ldur            w1, [x0, #0x83]
    // 0xcec250: DecompressPointer r1
    //     0xcec250: add             x1, x1, HEAP, lsl #32
    // 0xcec254: LoadField: r0 = r1->field_57
    //     0xcec254: ldur            w0, [x1, #0x57]
    // 0xcec258: DecompressPointer r0
    //     0xcec258: add             x0, x0, HEAP, lsl #32
    // 0xcec25c: SaveReg r0
    //     0xcec25c: str             x0, [SP, #-8]!
    // 0xcec260: SaveReg d0
    //     0xcec260: str             d0, [SP, #-8]!
    // 0xcec264: r0 = withOpacity()
    //     0xcec264: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec268: add             SP, SP, #0x10
    // 0xcec26c: LeaveFrame
    //     0xcec26c: mov             SP, fp
    //     0xcec270: ldp             fp, lr, [SP], #0x10
    // 0xcec274: ret
    //     0xcec274: ret             
    // 0xcec278: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec278: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec27c: b               #0xcec248
  }
  get _ secondaryActiveTrackColor(/* No info */) {
    // ** addr: 0xcec290, size: 0x54
    // 0xcec290: EnterFrame
    //     0xcec290: stp             fp, lr, [SP, #-0x10]!
    //     0xcec294: mov             fp, SP
    // 0xcec298: d0 = 0.540000
    //     0xcec298: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xcec29c: ldr             d0, [x17, #0x138]
    // 0xcec2a0: CheckStackOverflow
    //     0xcec2a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec2a4: cmp             SP, x16
    //     0xcec2a8: b.ls            #0xcec2dc
    // 0xcec2ac: ldr             x0, [fp, #0x10]
    // 0xcec2b0: LoadField: r1 = r0->field_83
    //     0xcec2b0: ldur            w1, [x0, #0x83]
    // 0xcec2b4: DecompressPointer r1
    //     0xcec2b4: add             x1, x1, HEAP, lsl #32
    // 0xcec2b8: LoadField: r0 = r1->field_b
    //     0xcec2b8: ldur            w0, [x1, #0xb]
    // 0xcec2bc: DecompressPointer r0
    //     0xcec2bc: add             x0, x0, HEAP, lsl #32
    // 0xcec2c0: SaveReg r0
    //     0xcec2c0: str             x0, [SP, #-8]!
    // 0xcec2c4: SaveReg d0
    //     0xcec2c4: str             d0, [SP, #-8]!
    // 0xcec2c8: r0 = withOpacity()
    //     0xcec2c8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec2cc: add             SP, SP, #0x10
    // 0xcec2d0: LeaveFrame
    //     0xcec2d0: mov             SP, fp
    //     0xcec2d4: ldp             fp, lr, [SP], #0x10
    // 0xcec2d8: ret
    //     0xcec2d8: ret             
    // 0xcec2dc: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec2dc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec2e0: b               #0xcec2ac
  }
  get _ inactiveTrackColor(/* No info */) {
    // ** addr: 0xcec338, size: 0x34
    // 0xcec338: ldr             x1, [SP]
    // 0xcec33c: LoadField: r2 = r1->field_83
    //     0xcec33c: ldur            w2, [x1, #0x83]
    // 0xcec340: DecompressPointer r2
    //     0xcec340: add             x2, x2, HEAP, lsl #32
    // 0xcec344: LoadField: r1 = r2->field_5b
    //     0xcec344: ldur            w1, [x2, #0x5b]
    // 0xcec348: DecompressPointer r1
    //     0xcec348: add             x1, x1, HEAP, lsl #32
    // 0xcec34c: cmp             w1, NULL
    // 0xcec350: b.ne            #0xcec364
    // 0xcec354: LoadField: r3 = r2->field_53
    //     0xcec354: ldur            w3, [x2, #0x53]
    // 0xcec358: DecompressPointer r3
    //     0xcec358: add             x3, x3, HEAP, lsl #32
    // 0xcec35c: mov             x0, x3
    // 0xcec360: b               #0xcec368
    // 0xcec364: mov             x0, x1
    // 0xcec368: ret
    //     0xcec368: ret             
  }
  get _ activeTrackColor(/* No info */) {
    // ** addr: 0xcec36c, size: 0x18
    // 0xcec36c: ldr             x1, [SP]
    // 0xcec370: LoadField: r2 = r1->field_83
    //     0xcec370: ldur            w2, [x1, #0x83]
    // 0xcec374: DecompressPointer r2
    //     0xcec374: add             x2, x2, HEAP, lsl #32
    // 0xcec378: LoadField: r0 = r2->field_b
    //     0xcec378: ldur            w0, [x2, #0xb]
    // 0xcec37c: DecompressPointer r0
    //     0xcec37c: add             x0, x0, HEAP, lsl #32
    // 0xcec380: ret
    //     0xcec380: ret             
  }
}

// class id: 2729, size: 0x88, field offset: 0x80
class _SliderDefaultsM2 extends SliderThemeData {

  get _ valueIndicatorShape(/* No info */) {
    // ** addr: 0xcebd50, size: 0xc
    // 0xcebd50: r0 = Instance_RectangularSliderValueIndicatorShape
    //     0xcebd50: add             x0, PP, #0xe, lsl #12  ; [pp+0xe160] Obj!RectangularSliderValueIndicatorShape@b37c01
    //     0xcebd54: ldr             x0, [x0, #0x160]
    // 0xcebd58: ret
    //     0xcebd58: ret             
  }
  get _ valueIndicatorTextStyle(/* No info */) {
    // ** addr: 0xcebd78, size: 0x84
    // 0xcebd78: EnterFrame
    //     0xcebd78: stp             fp, lr, [SP, #-0x10]!
    //     0xcebd7c: mov             fp, SP
    // 0xcebd80: CheckStackOverflow
    //     0xcebd80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebd84: cmp             SP, x16
    //     0xcebd88: b.ls            #0xcebdf0
    // 0xcebd8c: ldr             x0, [fp, #0x10]
    // 0xcebd90: LoadField: r1 = r0->field_7f
    //     0xcebd90: ldur            w1, [x0, #0x7f]
    // 0xcebd94: DecompressPointer r1
    //     0xcebd94: add             x1, x1, HEAP, lsl #32
    // 0xcebd98: SaveReg r1
    //     0xcebd98: str             x1, [SP, #-8]!
    // 0xcebd9c: r0 = of()
    //     0xcebd9c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xcebda0: add             SP, SP, #8
    // 0xcebda4: LoadField: r1 = r0->field_93
    //     0xcebda4: ldur            w1, [x0, #0x93]
    // 0xcebda8: DecompressPointer r1
    //     0xcebda8: add             x1, x1, HEAP, lsl #32
    // 0xcebdac: LoadField: r0 = r1->field_2b
    //     0xcebdac: ldur            w0, [x1, #0x2b]
    // 0xcebdb0: DecompressPointer r0
    //     0xcebdb0: add             x0, x0, HEAP, lsl #32
    // 0xcebdb4: cmp             w0, NULL
    // 0xcebdb8: b.eq            #0xcebdf8
    // 0xcebdbc: ldr             x1, [fp, #0x10]
    // 0xcebdc0: LoadField: r2 = r1->field_83
    //     0xcebdc0: ldur            w2, [x1, #0x83]
    // 0xcebdc4: DecompressPointer r2
    //     0xcebdc4: add             x2, x2, HEAP, lsl #32
    // 0xcebdc8: LoadField: r1 = r2->field_f
    //     0xcebdc8: ldur            w1, [x2, #0xf]
    // 0xcebdcc: DecompressPointer r1
    //     0xcebdcc: add             x1, x1, HEAP, lsl #32
    // 0xcebdd0: stp             x1, x0, [SP, #-0x10]!
    // 0xcebdd4: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xcebdd4: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xcebdd8: ldr             x4, [x4, #0x168]
    // 0xcebddc: r0 = copyWith()
    //     0xcebddc: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0xcebde0: add             SP, SP, #0x10
    // 0xcebde4: LeaveFrame
    //     0xcebde4: mov             SP, fp
    //     0xcebde8: ldp             fp, lr, [SP], #0x10
    // 0xcebdec: ret
    //     0xcebdec: ret             
    // 0xcebdf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcebdf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcebdf4: b               #0xcebd8c
    // 0xcebdf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcebdf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ overlayColor(/* No info */) {
    // ** addr: 0xcebe90, size: 0x54
    // 0xcebe90: EnterFrame
    //     0xcebe90: stp             fp, lr, [SP, #-0x10]!
    //     0xcebe94: mov             fp, SP
    // 0xcebe98: d0 = 0.120000
    //     0xcebe98: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xcebe9c: ldr             d0, [x17, #0xf48]
    // 0xcebea0: CheckStackOverflow
    //     0xcebea0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcebea4: cmp             SP, x16
    //     0xcebea8: b.ls            #0xcebedc
    // 0xcebeac: ldr             x0, [fp, #0x10]
    // 0xcebeb0: LoadField: r1 = r0->field_83
    //     0xcebeb0: ldur            w1, [x0, #0x83]
    // 0xcebeb4: DecompressPointer r1
    //     0xcebeb4: add             x1, x1, HEAP, lsl #32
    // 0xcebeb8: LoadField: r0 = r1->field_b
    //     0xcebeb8: ldur            w0, [x1, #0xb]
    // 0xcebebc: DecompressPointer r0
    //     0xcebebc: add             x0, x0, HEAP, lsl #32
    // 0xcebec0: SaveReg r0
    //     0xcebec0: str             x0, [SP, #-8]!
    // 0xcebec4: SaveReg d0
    //     0xcebec4: str             d0, [SP, #-8]!
    // 0xcebec8: r0 = withOpacity()
    //     0xcebec8: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcebecc: add             SP, SP, #0x10
    // 0xcebed0: LeaveFrame
    //     0xcebed0: mov             SP, fp
    //     0xcebed4: ldp             fp, lr, [SP], #0x10
    // 0xcebed8: ret
    //     0xcebed8: ret             
    // 0xcebedc: r0 = StackOverflowSharedWithFPURegs()
    //     0xcebedc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcebee0: b               #0xcebeac
  }
  get _ disabledActiveTickMarkColor(/* No info */) {
    // ** addr: 0xcebff4, size: 0x54
    // 0xcebff4: EnterFrame
    //     0xcebff4: stp             fp, lr, [SP, #-0x10]!
    //     0xcebff8: mov             fp, SP
    // 0xcebffc: d0 = 0.120000
    //     0xcebffc: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf48] IMM: double(0.12) from 0x3fbeb851eb851eb8
    //     0xcec000: ldr             d0, [x17, #0xf48]
    // 0xcec004: CheckStackOverflow
    //     0xcec004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec008: cmp             SP, x16
    //     0xcec00c: b.ls            #0xcec040
    // 0xcec010: ldr             x0, [fp, #0x10]
    // 0xcec014: LoadField: r1 = r0->field_83
    //     0xcec014: ldur            w1, [x0, #0x83]
    // 0xcec018: DecompressPointer r1
    //     0xcec018: add             x1, x1, HEAP, lsl #32
    // 0xcec01c: LoadField: r0 = r1->field_f
    //     0xcec01c: ldur            w0, [x1, #0xf]
    // 0xcec020: DecompressPointer r0
    //     0xcec020: add             x0, x0, HEAP, lsl #32
    // 0xcec024: SaveReg r0
    //     0xcec024: str             x0, [SP, #-8]!
    // 0xcec028: SaveReg d0
    //     0xcec028: str             d0, [SP, #-8]!
    // 0xcec02c: r0 = withOpacity()
    //     0xcec02c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec030: add             SP, SP, #0x10
    // 0xcec034: LeaveFrame
    //     0xcec034: mov             SP, fp
    //     0xcec038: ldp             fp, lr, [SP], #0x10
    // 0xcec03c: ret
    //     0xcec03c: ret             
    // 0xcec040: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec040: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec044: b               #0xcec010
  }
  get _ activeTickMarkColor(/* No info */) {
    // ** addr: 0xcec0cc, size: 0x54
    // 0xcec0cc: EnterFrame
    //     0xcec0cc: stp             fp, lr, [SP, #-0x10]!
    //     0xcec0d0: mov             fp, SP
    // 0xcec0d4: d0 = 0.540000
    //     0xcec0d4: add             x17, PP, #0xe, lsl #12  ; [pp+0xe138] IMM: double(0.54) from 0x3fe147ae147ae148
    //     0xcec0d8: ldr             d0, [x17, #0x138]
    // 0xcec0dc: CheckStackOverflow
    //     0xcec0dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec0e0: cmp             SP, x16
    //     0xcec0e4: b.ls            #0xcec118
    // 0xcec0e8: ldr             x0, [fp, #0x10]
    // 0xcec0ec: LoadField: r1 = r0->field_83
    //     0xcec0ec: ldur            w1, [x0, #0x83]
    // 0xcec0f0: DecompressPointer r1
    //     0xcec0f0: add             x1, x1, HEAP, lsl #32
    // 0xcec0f4: LoadField: r0 = r1->field_f
    //     0xcec0f4: ldur            w0, [x1, #0xf]
    // 0xcec0f8: DecompressPointer r0
    //     0xcec0f8: add             x0, x0, HEAP, lsl #32
    // 0xcec0fc: SaveReg r0
    //     0xcec0fc: str             x0, [SP, #-8]!
    // 0xcec100: SaveReg d0
    //     0xcec100: str             d0, [SP, #-8]!
    // 0xcec104: r0 = withOpacity()
    //     0xcec104: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec108: add             SP, SP, #0x10
    // 0xcec10c: LeaveFrame
    //     0xcec10c: mov             SP, fp
    //     0xcec110: ldp             fp, lr, [SP], #0x10
    // 0xcec114: ret
    //     0xcec114: ret             
    // 0xcec118: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec118: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec11c: b               #0xcec0e8
  }
  get _ disabledActiveTrackColor(/* No info */) {
    // ** addr: 0xcec1d8, size: 0x54
    // 0xcec1d8: EnterFrame
    //     0xcec1d8: stp             fp, lr, [SP, #-0x10]!
    //     0xcec1dc: mov             fp, SP
    // 0xcec1e0: d0 = 0.320000
    //     0xcec1e0: add             x17, PP, #0xe, lsl #12  ; [pp+0xe148] IMM: double(0.32) from 0x3fd47ae147ae147b
    //     0xcec1e4: ldr             d0, [x17, #0x148]
    // 0xcec1e8: CheckStackOverflow
    //     0xcec1e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec1ec: cmp             SP, x16
    //     0xcec1f0: b.ls            #0xcec224
    // 0xcec1f4: ldr             x0, [fp, #0x10]
    // 0xcec1f8: LoadField: r1 = r0->field_83
    //     0xcec1f8: ldur            w1, [x0, #0x83]
    // 0xcec1fc: DecompressPointer r1
    //     0xcec1fc: add             x1, x1, HEAP, lsl #32
    // 0xcec200: LoadField: r0 = r1->field_57
    //     0xcec200: ldur            w0, [x1, #0x57]
    // 0xcec204: DecompressPointer r0
    //     0xcec204: add             x0, x0, HEAP, lsl #32
    // 0xcec208: SaveReg r0
    //     0xcec208: str             x0, [SP, #-8]!
    // 0xcec20c: SaveReg d0
    //     0xcec20c: str             d0, [SP, #-8]!
    // 0xcec210: r0 = withOpacity()
    //     0xcec210: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec214: add             SP, SP, #0x10
    // 0xcec218: LeaveFrame
    //     0xcec218: mov             SP, fp
    //     0xcec21c: ldp             fp, lr, [SP], #0x10
    // 0xcec220: ret
    //     0xcec220: ret             
    // 0xcec224: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec224: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec228: b               #0xcec1f4
  }
  get _ inactiveTrackColor(/* No info */) {
    // ** addr: 0xcec2e4, size: 0x54
    // 0xcec2e4: EnterFrame
    //     0xcec2e4: stp             fp, lr, [SP, #-0x10]!
    //     0xcec2e8: mov             fp, SP
    // 0xcec2ec: d0 = 0.240000
    //     0xcec2ec: add             x17, PP, #0xe, lsl #12  ; [pp+0xe130] IMM: double(0.24) from 0x3fceb851eb851eb8
    //     0xcec2f0: ldr             d0, [x17, #0x130]
    // 0xcec2f4: CheckStackOverflow
    //     0xcec2f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcec2f8: cmp             SP, x16
    //     0xcec2fc: b.ls            #0xcec330
    // 0xcec300: ldr             x0, [fp, #0x10]
    // 0xcec304: LoadField: r1 = r0->field_83
    //     0xcec304: ldur            w1, [x0, #0x83]
    // 0xcec308: DecompressPointer r1
    //     0xcec308: add             x1, x1, HEAP, lsl #32
    // 0xcec30c: LoadField: r0 = r1->field_b
    //     0xcec30c: ldur            w0, [x1, #0xb]
    // 0xcec310: DecompressPointer r0
    //     0xcec310: add             x0, x0, HEAP, lsl #32
    // 0xcec314: SaveReg r0
    //     0xcec314: str             x0, [SP, #-8]!
    // 0xcec318: SaveReg d0
    //     0xcec318: str             d0, [SP, #-8]!
    // 0xcec31c: r0 = withOpacity()
    //     0xcec31c: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0xcec320: add             SP, SP, #0x10
    // 0xcec324: LeaveFrame
    //     0xcec324: mov             SP, fp
    //     0xcec328: ldp             fp, lr, [SP], #0x10
    // 0xcec32c: ret
    //     0xcec32c: ret             
    // 0xcec330: r0 = StackOverflowSharedWithFPURegs()
    //     0xcec330: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcec334: b               #0xcec300
  }
}

// class id: 2768, size: 0xc, field offset: 0x8
//   const constructor, 
class _AdjustSliderIntent extends Intent {

  _SliderAdjustmentType field_8;
}

// class id: 3275, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __SliderState&State&TickerProviderStateMixin extends State<Slider>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x618bb8, size: 0x178
    // 0x618bb8: EnterFrame
    //     0x618bb8: stp             fp, lr, [SP, #-0x10]!
    //     0x618bbc: mov             fp, SP
    // 0x618bc0: AllocStack(0x10)
    //     0x618bc0: sub             SP, SP, #0x10
    // 0x618bc4: CheckStackOverflow
    //     0x618bc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618bc8: cmp             SP, x16
    //     0x618bcc: b.ls            #0x618d20
    // 0x618bd0: ldr             x0, [fp, #0x18]
    // 0x618bd4: LoadField: r1 = r0->field_17
    //     0x618bd4: ldur            w1, [x0, #0x17]
    // 0x618bd8: DecompressPointer r1
    //     0x618bd8: add             x1, x1, HEAP, lsl #32
    // 0x618bdc: cmp             w1, NULL
    // 0x618be0: b.ne            #0x618bf0
    // 0x618be4: SaveReg r0
    //     0x618be4: str             x0, [SP, #-8]!
    // 0x618be8: r0 = _updateTickerModeNotifier()
    //     0x618be8: bl              #0x618d54  ; [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x618bec: add             SP, SP, #8
    // 0x618bf0: ldr             x0, [fp, #0x18]
    // 0x618bf4: LoadField: r1 = r0->field_13
    //     0x618bf4: ldur            w1, [x0, #0x13]
    // 0x618bf8: DecompressPointer r1
    //     0x618bf8: add             x1, x1, HEAP, lsl #32
    // 0x618bfc: cmp             w1, NULL
    // 0x618c00: b.ne            #0x618c98
    // 0x618c04: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x618c04: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x618c08: ldr             x0, [x0, #0x598]
    //     0x618c0c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x618c10: cmp             w0, w16
    //     0x618c14: b.ne            #0x618c20
    //     0x618c18: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x618c1c: bl              #0xd67cdc
    // 0x618c20: r1 = <_WidgetTicker>
    //     0x618c20: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x618c24: ldr             x1, [x1, #0x210]
    // 0x618c28: stur            x0, [fp, #-8]
    // 0x618c2c: r0 = _Set()
    //     0x618c2c: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x618c30: mov             x1, x0
    // 0x618c34: ldur            x0, [fp, #-8]
    // 0x618c38: stur            x1, [fp, #-0x10]
    // 0x618c3c: StoreField: r1->field_1b = r0
    //     0x618c3c: stur            w0, [x1, #0x1b]
    // 0x618c40: StoreField: r1->field_b = rZR
    //     0x618c40: stur            wzr, [x1, #0xb]
    // 0x618c44: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x618c44: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x618c48: ldr             x0, [x0, #0x5a0]
    //     0x618c4c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x618c50: cmp             w0, w16
    //     0x618c54: b.ne            #0x618c60
    //     0x618c58: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x618c5c: bl              #0xd67cdc
    // 0x618c60: mov             x1, x0
    // 0x618c64: ldur            x0, [fp, #-0x10]
    // 0x618c68: StoreField: r0->field_f = r1
    //     0x618c68: stur            w1, [x0, #0xf]
    // 0x618c6c: StoreField: r0->field_13 = rZR
    //     0x618c6c: stur            wzr, [x0, #0x13]
    // 0x618c70: StoreField: r0->field_17 = rZR
    //     0x618c70: stur            wzr, [x0, #0x17]
    // 0x618c74: ldr             x1, [fp, #0x18]
    // 0x618c78: StoreField: r1->field_13 = r0
    //     0x618c78: stur            w0, [x1, #0x13]
    //     0x618c7c: ldurb           w16, [x1, #-1]
    //     0x618c80: ldurb           w17, [x0, #-1]
    //     0x618c84: and             x16, x17, x16, lsr #2
    //     0x618c88: tst             x16, HEAP, lsr #32
    //     0x618c8c: b.eq            #0x618c94
    //     0x618c90: bl              #0xd6826c
    // 0x618c94: b               #0x618c9c
    // 0x618c98: mov             x1, x0
    // 0x618c9c: ldr             x0, [fp, #0x10]
    // 0x618ca0: r0 = _WidgetTicker()
    //     0x618ca0: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x618ca4: mov             x1, x0
    // 0x618ca8: ldr             x0, [fp, #0x18]
    // 0x618cac: stur            x1, [fp, #-8]
    // 0x618cb0: StoreField: r1->field_1b = r0
    //     0x618cb0: stur            w0, [x1, #0x1b]
    // 0x618cb4: r2 = false
    //     0x618cb4: add             x2, NULL, #0x30  ; false
    // 0x618cb8: StoreField: r1->field_b = r2
    //     0x618cb8: stur            w2, [x1, #0xb]
    // 0x618cbc: ldr             x2, [fp, #0x10]
    // 0x618cc0: StoreField: r1->field_13 = r2
    //     0x618cc0: stur            w2, [x1, #0x13]
    // 0x618cc4: LoadField: r2 = r0->field_17
    //     0x618cc4: ldur            w2, [x0, #0x17]
    // 0x618cc8: DecompressPointer r2
    //     0x618cc8: add             x2, x2, HEAP, lsl #32
    // 0x618ccc: cmp             w2, NULL
    // 0x618cd0: b.eq            #0x618d28
    // 0x618cd4: LoadField: r3 = r2->field_27
    //     0x618cd4: ldur            w3, [x2, #0x27]
    // 0x618cd8: DecompressPointer r3
    //     0x618cd8: add             x3, x3, HEAP, lsl #32
    // 0x618cdc: eor             x2, x3, #0x10
    // 0x618ce0: stp             x2, x1, [SP, #-0x10]!
    // 0x618ce4: r0 = muted=()
    //     0x618ce4: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x618ce8: add             SP, SP, #0x10
    // 0x618cec: ldr             x0, [fp, #0x18]
    // 0x618cf0: LoadField: r1 = r0->field_13
    //     0x618cf0: ldur            w1, [x0, #0x13]
    // 0x618cf4: DecompressPointer r1
    //     0x618cf4: add             x1, x1, HEAP, lsl #32
    // 0x618cf8: cmp             w1, NULL
    // 0x618cfc: b.eq            #0x618d2c
    // 0x618d00: ldur            x16, [fp, #-8]
    // 0x618d04: stp             x16, x1, [SP, #-0x10]!
    // 0x618d08: r0 = add()
    //     0x618d08: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x618d0c: add             SP, SP, #0x10
    // 0x618d10: ldur            x0, [fp, #-8]
    // 0x618d14: LeaveFrame
    //     0x618d14: mov             SP, fp
    //     0x618d18: ldp             fp, lr, [SP], #0x10
    // 0x618d1c: ret
    //     0x618d1c: ret             
    // 0x618d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618d24: b               #0x618bd0
    // 0x618d28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618d28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x618d2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618d2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x618d54, size: 0x11c
    // 0x618d54: EnterFrame
    //     0x618d54: stp             fp, lr, [SP, #-0x10]!
    //     0x618d58: mov             fp, SP
    // 0x618d5c: AllocStack(0x10)
    //     0x618d5c: sub             SP, SP, #0x10
    // 0x618d60: CheckStackOverflow
    //     0x618d60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618d64: cmp             SP, x16
    //     0x618d68: b.ls            #0x618e64
    // 0x618d6c: ldr             x0, [fp, #0x10]
    // 0x618d70: LoadField: r1 = r0->field_f
    //     0x618d70: ldur            w1, [x0, #0xf]
    // 0x618d74: DecompressPointer r1
    //     0x618d74: add             x1, x1, HEAP, lsl #32
    // 0x618d78: cmp             w1, NULL
    // 0x618d7c: b.eq            #0x618e6c
    // 0x618d80: SaveReg r1
    //     0x618d80: str             x1, [SP, #-8]!
    // 0x618d84: r0 = getNotifier()
    //     0x618d84: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x618d88: add             SP, SP, #8
    // 0x618d8c: mov             x1, x0
    // 0x618d90: ldr             x0, [fp, #0x10]
    // 0x618d94: stur            x1, [fp, #-0x10]
    // 0x618d98: LoadField: r2 = r0->field_17
    //     0x618d98: ldur            w2, [x0, #0x17]
    // 0x618d9c: DecompressPointer r2
    //     0x618d9c: add             x2, x2, HEAP, lsl #32
    // 0x618da0: stur            x2, [fp, #-8]
    // 0x618da4: cmp             w1, w2
    // 0x618da8: b.ne            #0x618dbc
    // 0x618dac: r0 = Null
    //     0x618dac: mov             x0, NULL
    // 0x618db0: LeaveFrame
    //     0x618db0: mov             SP, fp
    //     0x618db4: ldp             fp, lr, [SP], #0x10
    // 0x618db8: ret
    //     0x618db8: ret             
    // 0x618dbc: cmp             w2, NULL
    // 0x618dc0: b.eq            #0x618dfc
    // 0x618dc4: r1 = 1
    //     0x618dc4: mov             x1, #1
    // 0x618dc8: r0 = AllocateContext()
    //     0x618dc8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x618dcc: mov             x1, x0
    // 0x618dd0: ldr             x0, [fp, #0x10]
    // 0x618dd4: StoreField: r1->field_f = r0
    //     0x618dd4: stur            w0, [x1, #0xf]
    // 0x618dd8: mov             x2, x1
    // 0x618ddc: r1 = Function '_updateTickers@156311458':.
    //     0x618ddc: add             x1, PP, #0x55, lsl #12  ; [pp+0x55770] AnonymousClosure: (0x618e70), in [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickers (0x618eb8)
    //     0x618de0: ldr             x1, [x1, #0x770]
    // 0x618de4: r0 = AllocateClosure()
    //     0x618de4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618de8: ldur            x16, [fp, #-8]
    // 0x618dec: stp             x0, x16, [SP, #-0x10]!
    // 0x618df0: r0 = removeListener()
    //     0x618df0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x618df4: add             SP, SP, #0x10
    // 0x618df8: ldr             x0, [fp, #0x10]
    // 0x618dfc: r1 = 1
    //     0x618dfc: mov             x1, #1
    // 0x618e00: r0 = AllocateContext()
    //     0x618e00: bl              #0xd68aa4  ; AllocateContextStub
    // 0x618e04: mov             x1, x0
    // 0x618e08: ldr             x0, [fp, #0x10]
    // 0x618e0c: StoreField: r1->field_f = r0
    //     0x618e0c: stur            w0, [x1, #0xf]
    // 0x618e10: mov             x2, x1
    // 0x618e14: r1 = Function '_updateTickers@156311458':.
    //     0x618e14: add             x1, PP, #0x55, lsl #12  ; [pp+0x55770] AnonymousClosure: (0x618e70), in [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickers (0x618eb8)
    //     0x618e18: ldr             x1, [x1, #0x770]
    // 0x618e1c: r0 = AllocateClosure()
    //     0x618e1c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x618e20: ldur            x16, [fp, #-0x10]
    // 0x618e24: stp             x0, x16, [SP, #-0x10]!
    // 0x618e28: r0 = addListener()
    //     0x618e28: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x618e2c: add             SP, SP, #0x10
    // 0x618e30: ldur            x0, [fp, #-0x10]
    // 0x618e34: ldr             x1, [fp, #0x10]
    // 0x618e38: StoreField: r1->field_17 = r0
    //     0x618e38: stur            w0, [x1, #0x17]
    //     0x618e3c: ldurb           w16, [x1, #-1]
    //     0x618e40: ldurb           w17, [x0, #-1]
    //     0x618e44: and             x16, x17, x16, lsr #2
    //     0x618e48: tst             x16, HEAP, lsr #32
    //     0x618e4c: b.eq            #0x618e54
    //     0x618e50: bl              #0xd6826c
    // 0x618e54: r0 = Null
    //     0x618e54: mov             x0, NULL
    // 0x618e58: LeaveFrame
    //     0x618e58: mov             SP, fp
    //     0x618e5c: ldp             fp, lr, [SP], #0x10
    // 0x618e60: ret
    //     0x618e60: ret             
    // 0x618e64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618e64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618e68: b               #0x618d6c
    // 0x618e6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618e6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x618e70, size: 0x48
    // 0x618e70: EnterFrame
    //     0x618e70: stp             fp, lr, [SP, #-0x10]!
    //     0x618e74: mov             fp, SP
    // 0x618e78: ldr             x0, [fp, #0x10]
    // 0x618e7c: LoadField: r1 = r0->field_17
    //     0x618e7c: ldur            w1, [x0, #0x17]
    // 0x618e80: DecompressPointer r1
    //     0x618e80: add             x1, x1, HEAP, lsl #32
    // 0x618e84: CheckStackOverflow
    //     0x618e84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618e88: cmp             SP, x16
    //     0x618e8c: b.ls            #0x618eb0
    // 0x618e90: LoadField: r0 = r1->field_f
    //     0x618e90: ldur            w0, [x1, #0xf]
    // 0x618e94: DecompressPointer r0
    //     0x618e94: add             x0, x0, HEAP, lsl #32
    // 0x618e98: SaveReg r0
    //     0x618e98: str             x0, [SP, #-8]!
    // 0x618e9c: r0 = _updateTickers()
    //     0x618e9c: bl              #0x618eb8  ; [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickers
    // 0x618ea0: add             SP, SP, #8
    // 0x618ea4: LeaveFrame
    //     0x618ea4: mov             SP, fp
    //     0x618ea8: ldp             fp, lr, [SP], #0x10
    // 0x618eac: ret
    //     0x618eac: ret             
    // 0x618eb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618eb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618eb4: b               #0x618e90
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x618eb8, size: 0x150
    // 0x618eb8: EnterFrame
    //     0x618eb8: stp             fp, lr, [SP, #-0x10]!
    //     0x618ebc: mov             fp, SP
    // 0x618ec0: AllocStack(0x20)
    //     0x618ec0: sub             SP, SP, #0x20
    // 0x618ec4: CheckStackOverflow
    //     0x618ec4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618ec8: cmp             SP, x16
    //     0x618ecc: b.ls            #0x618ff4
    // 0x618ed0: ldr             x0, [fp, #0x10]
    // 0x618ed4: LoadField: r1 = r0->field_13
    //     0x618ed4: ldur            w1, [x0, #0x13]
    // 0x618ed8: DecompressPointer r1
    //     0x618ed8: add             x1, x1, HEAP, lsl #32
    // 0x618edc: cmp             w1, NULL
    // 0x618ee0: b.eq            #0x618fe4
    // 0x618ee4: LoadField: r2 = r0->field_17
    //     0x618ee4: ldur            w2, [x0, #0x17]
    // 0x618ee8: DecompressPointer r2
    //     0x618ee8: add             x2, x2, HEAP, lsl #32
    // 0x618eec: cmp             w2, NULL
    // 0x618ef0: b.eq            #0x618ffc
    // 0x618ef4: LoadField: r0 = r2->field_27
    //     0x618ef4: ldur            w0, [x2, #0x27]
    // 0x618ef8: DecompressPointer r0
    //     0x618ef8: add             x0, x0, HEAP, lsl #32
    // 0x618efc: eor             x2, x0, #0x10
    // 0x618f00: stur            x2, [fp, #-8]
    // 0x618f04: SaveReg r1
    //     0x618f04: str             x1, [SP, #-8]!
    // 0x618f08: r0 = iterator()
    //     0x618f08: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x618f0c: add             SP, SP, #8
    // 0x618f10: stur            x0, [fp, #-0x18]
    // 0x618f14: LoadField: r2 = r0->field_7
    //     0x618f14: ldur            w2, [x0, #7]
    // 0x618f18: DecompressPointer r2
    //     0x618f18: add             x2, x2, HEAP, lsl #32
    // 0x618f1c: stur            x2, [fp, #-0x10]
    // 0x618f20: ldur            x1, [fp, #-8]
    // 0x618f24: CheckStackOverflow
    //     0x618f24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x618f28: cmp             SP, x16
    //     0x618f2c: b.ls            #0x619000
    // 0x618f30: SaveReg r0
    //     0x618f30: str             x0, [SP, #-8]!
    // 0x618f34: r0 = moveNext()
    //     0x618f34: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x618f38: add             SP, SP, #8
    // 0x618f3c: tbnz            w0, #4, #0x618fe4
    // 0x618f40: ldur            x3, [fp, #-0x18]
    // 0x618f44: LoadField: r4 = r3->field_33
    //     0x618f44: ldur            w4, [x3, #0x33]
    // 0x618f48: DecompressPointer r4
    //     0x618f48: add             x4, x4, HEAP, lsl #32
    // 0x618f4c: stur            x4, [fp, #-0x20]
    // 0x618f50: cmp             w4, NULL
    // 0x618f54: b.ne            #0x618f88
    // 0x618f58: mov             x0, x4
    // 0x618f5c: ldur            x2, [fp, #-0x10]
    // 0x618f60: r1 = Null
    //     0x618f60: mov             x1, NULL
    // 0x618f64: cmp             w2, NULL
    // 0x618f68: b.eq            #0x618f88
    // 0x618f6c: LoadField: r4 = r2->field_17
    //     0x618f6c: ldur            w4, [x2, #0x17]
    // 0x618f70: DecompressPointer r4
    //     0x618f70: add             x4, x4, HEAP, lsl #32
    // 0x618f74: r8 = X0
    //     0x618f74: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x618f78: LoadField: r9 = r4->field_7
    //     0x618f78: ldur            x9, [x4, #7]
    // 0x618f7c: r3 = Null
    //     0x618f7c: add             x3, PP, #0x55, lsl #12  ; [pp+0x55760] Null
    //     0x618f80: ldr             x3, [x3, #0x760]
    // 0x618f84: blr             x9
    // 0x618f88: ldur            x1, [fp, #-8]
    // 0x618f8c: ldur            x0, [fp, #-0x20]
    // 0x618f90: LoadField: r2 = r0->field_b
    //     0x618f90: ldur            w2, [x0, #0xb]
    // 0x618f94: DecompressPointer r2
    //     0x618f94: add             x2, x2, HEAP, lsl #32
    // 0x618f98: cmp             w1, w2
    // 0x618f9c: b.eq            #0x618fd8
    // 0x618fa0: StoreField: r0->field_b = r1
    //     0x618fa0: stur            w1, [x0, #0xb]
    // 0x618fa4: tbnz            w1, #4, #0x618fb8
    // 0x618fa8: SaveReg r0
    //     0x618fa8: str             x0, [SP, #-8]!
    // 0x618fac: r0 = unscheduleTick()
    //     0x618fac: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x618fb0: add             SP, SP, #8
    // 0x618fb4: b               #0x618fd8
    // 0x618fb8: SaveReg r0
    //     0x618fb8: str             x0, [SP, #-8]!
    // 0x618fbc: r0 = shouldScheduleTick()
    //     0x618fbc: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x618fc0: add             SP, SP, #8
    // 0x618fc4: tbnz            w0, #4, #0x618fd8
    // 0x618fc8: ldur            x16, [fp, #-0x20]
    // 0x618fcc: SaveReg r16
    //     0x618fcc: str             x16, [SP, #-8]!
    // 0x618fd0: r0 = scheduleTick()
    //     0x618fd0: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x618fd4: add             SP, SP, #8
    // 0x618fd8: ldur            x0, [fp, #-0x18]
    // 0x618fdc: ldur            x2, [fp, #-0x10]
    // 0x618fe0: b               #0x618f20
    // 0x618fe4: r0 = Null
    //     0x618fe4: mov             x0, NULL
    // 0x618fe8: LeaveFrame
    //     0x618fe8: mov             SP, fp
    //     0x618fec: ldp             fp, lr, [SP], #0x10
    // 0x618ff0: ret
    //     0x618ff0: ret             
    // 0x618ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x618ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x618ff8: b               #0x618ed0
    // 0x618ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x618ffc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x619000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x619000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x619004: b               #0x618f30
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f7ec, size: 0x4c
    // 0x81f7ec: EnterFrame
    //     0x81f7ec: stp             fp, lr, [SP, #-0x10]!
    //     0x81f7f0: mov             fp, SP
    // 0x81f7f4: CheckStackOverflow
    //     0x81f7f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f7f8: cmp             SP, x16
    //     0x81f7fc: b.ls            #0x81f830
    // 0x81f800: ldr             x16, [fp, #0x10]
    // 0x81f804: SaveReg r16
    //     0x81f804: str             x16, [SP, #-8]!
    // 0x81f808: r0 = _updateTickerModeNotifier()
    //     0x81f808: bl              #0x618d54  ; [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f80c: add             SP, SP, #8
    // 0x81f810: ldr             x16, [fp, #0x10]
    // 0x81f814: SaveReg r16
    //     0x81f814: str             x16, [SP, #-8]!
    // 0x81f818: r0 = _updateTickers()
    //     0x81f818: bl              #0x618eb8  ; [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f81c: add             SP, SP, #8
    // 0x81f820: r0 = Null
    //     0x81f820: mov             x0, NULL
    // 0x81f824: LeaveFrame
    //     0x81f824: mov             SP, fp
    //     0x81f828: ldp             fp, lr, [SP], #0x10
    // 0x81f82c: ret
    //     0x81f82c: ret             
    // 0x81f830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f834: b               #0x81f800
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52af0, size: 0x8c
    // 0xa52af0: EnterFrame
    //     0xa52af0: stp             fp, lr, [SP, #-0x10]!
    //     0xa52af4: mov             fp, SP
    // 0xa52af8: AllocStack(0x8)
    //     0xa52af8: sub             SP, SP, #8
    // 0xa52afc: CheckStackOverflow
    //     0xa52afc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52b00: cmp             SP, x16
    //     0xa52b04: b.ls            #0xa52b74
    // 0xa52b08: ldr             x0, [fp, #0x10]
    // 0xa52b0c: LoadField: r1 = r0->field_17
    //     0xa52b0c: ldur            w1, [x0, #0x17]
    // 0xa52b10: DecompressPointer r1
    //     0xa52b10: add             x1, x1, HEAP, lsl #32
    // 0xa52b14: stur            x1, [fp, #-8]
    // 0xa52b18: cmp             w1, NULL
    // 0xa52b1c: b.ne            #0xa52b28
    // 0xa52b20: mov             x1, x0
    // 0xa52b24: b               #0xa52b60
    // 0xa52b28: r1 = 1
    //     0xa52b28: mov             x1, #1
    // 0xa52b2c: r0 = AllocateContext()
    //     0xa52b2c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa52b30: mov             x1, x0
    // 0xa52b34: ldr             x0, [fp, #0x10]
    // 0xa52b38: StoreField: r1->field_f = r0
    //     0xa52b38: stur            w0, [x1, #0xf]
    // 0xa52b3c: mov             x2, x1
    // 0xa52b40: r1 = Function '_updateTickers@156311458':.
    //     0xa52b40: add             x1, PP, #0x55, lsl #12  ; [pp+0x55770] AnonymousClosure: (0x618e70), in [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::_updateTickers (0x618eb8)
    //     0xa52b44: ldr             x1, [x1, #0x770]
    // 0xa52b48: r0 = AllocateClosure()
    //     0xa52b48: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa52b4c: ldur            x16, [fp, #-8]
    // 0xa52b50: stp             x0, x16, [SP, #-0x10]!
    // 0xa52b54: r0 = removeListener()
    //     0xa52b54: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa52b58: add             SP, SP, #0x10
    // 0xa52b5c: ldr             x1, [fp, #0x10]
    // 0xa52b60: StoreField: r1->field_17 = rNULL
    //     0xa52b60: stur            NULL, [x1, #0x17]
    // 0xa52b64: r0 = Null
    //     0xa52b64: mov             x0, NULL
    // 0xa52b68: LeaveFrame
    //     0xa52b68: mov             SP, fp
    //     0xa52b6c: ldp             fp, lr, [SP], #0x10
    // 0xa52b70: ret
    //     0xa52b70: ret             
    // 0xa52b74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52b74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52b78: b               #0xa52b08
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa52b7c, size: 0x48
    // 0xa52b7c: EnterFrame
    //     0xa52b7c: stp             fp, lr, [SP, #-0x10]!
    //     0xa52b80: mov             fp, SP
    // 0xa52b84: ldr             x0, [fp, #0x10]
    // 0xa52b88: LoadField: r1 = r0->field_17
    //     0xa52b88: ldur            w1, [x0, #0x17]
    // 0xa52b8c: DecompressPointer r1
    //     0xa52b8c: add             x1, x1, HEAP, lsl #32
    // 0xa52b90: CheckStackOverflow
    //     0xa52b90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa52b94: cmp             SP, x16
    //     0xa52b98: b.ls            #0xa52bbc
    // 0xa52b9c: LoadField: r0 = r1->field_f
    //     0xa52b9c: ldur            w0, [x1, #0xf]
    // 0xa52ba0: DecompressPointer r0
    //     0xa52ba0: add             x0, x0, HEAP, lsl #32
    // 0xa52ba4: SaveReg r0
    //     0xa52ba4: str             x0, [SP, #-8]!
    // 0xa52ba8: r0 = dispose()
    //     0xa52ba8: bl              #0xa52af0  ; [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::dispose
    // 0xa52bac: add             SP, SP, #8
    // 0xa52bb0: LeaveFrame
    //     0xa52bb0: mov             SP, fp
    //     0xa52bb4: ldp             fp, lr, [SP], #0x10
    // 0xa52bb8: ret
    //     0xa52bb8: ret             
    // 0xa52bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52bbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52bc0: b               #0xa52b9c
  }
}

// class id: 3276, size: 0x54, field offset: 0x1c
class _SliderState extends __SliderState&State&TickerProviderStateMixin {

  late Map<Type, Action<Intent>> _actionMap; // offset: 0x34
  late AnimationController overlayController; // offset: 0x1c
  late AnimationController valueIndicatorController; // offset: 0x20
  late AnimationController enableController; // offset: 0x24
  late AnimationController positionController; // offset: 0x28

  _ showValueIndicator(/* No info */) {
    // ** addr: 0x6efbc4, size: 0x10c
    // 0x6efbc4: EnterFrame
    //     0x6efbc4: stp             fp, lr, [SP, #-0x10]!
    //     0x6efbc8: mov             fp, SP
    // 0x6efbcc: AllocStack(0x10)
    //     0x6efbcc: sub             SP, SP, #0x10
    // 0x6efbd0: CheckStackOverflow
    //     0x6efbd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6efbd4: cmp             SP, x16
    //     0x6efbd8: b.ls            #0x6efcbc
    // 0x6efbdc: r1 = 1
    //     0x6efbdc: mov             x1, #1
    // 0x6efbe0: r0 = AllocateContext()
    //     0x6efbe0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6efbe4: mov             x1, x0
    // 0x6efbe8: ldr             x0, [fp, #0x10]
    // 0x6efbec: StoreField: r1->field_f = r0
    //     0x6efbec: stur            w0, [x1, #0xf]
    // 0x6efbf0: LoadField: r2 = r0->field_4f
    //     0x6efbf0: ldur            w2, [x0, #0x4f]
    // 0x6efbf4: DecompressPointer r2
    //     0x6efbf4: add             x2, x2, HEAP, lsl #32
    // 0x6efbf8: cmp             w2, NULL
    // 0x6efbfc: b.ne            #0x6efcac
    // 0x6efc00: mov             x2, x1
    // 0x6efc04: r1 = Function '<anonymous closure>':.
    //     0x6efc04: add             x1, PP, #0x56, lsl #12  ; [pp+0x56478] AnonymousClosure: (0x6efcdc), in [package:flutter/src/material/slider.dart] _SliderState::showValueIndicator (0x6efbc4)
    //     0x6efc08: ldr             x1, [x1, #0x478]
    // 0x6efc0c: r0 = AllocateClosure()
    //     0x6efc0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6efc10: stur            x0, [fp, #-8]
    // 0x6efc14: r0 = OverlayEntry()
    //     0x6efc14: bl              #0x6efcd0  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x24)
    // 0x6efc18: stur            x0, [fp, #-0x10]
    // 0x6efc1c: ldur            x16, [fp, #-8]
    // 0x6efc20: stp             x16, x0, [SP, #-0x10]!
    // 0x6efc24: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6efc24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6efc28: r0 = OverlayEntry()
    //     0x6efc28: bl              #0x594c98  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0x6efc2c: add             SP, SP, #0x10
    // 0x6efc30: ldur            x0, [fp, #-0x10]
    // 0x6efc34: ldr             x1, [fp, #0x10]
    // 0x6efc38: StoreField: r1->field_4f = r0
    //     0x6efc38: stur            w0, [x1, #0x4f]
    //     0x6efc3c: ldurb           w16, [x1, #-1]
    //     0x6efc40: ldurb           w17, [x0, #-1]
    //     0x6efc44: and             x16, x17, x16, lsr #2
    //     0x6efc48: tst             x16, HEAP, lsr #32
    //     0x6efc4c: b.eq            #0x6efc54
    //     0x6efc50: bl              #0xd6826c
    // 0x6efc54: LoadField: r0 = r1->field_f
    //     0x6efc54: ldur            w0, [x1, #0xf]
    // 0x6efc58: DecompressPointer r0
    //     0x6efc58: add             x0, x0, HEAP, lsl #32
    // 0x6efc5c: cmp             w0, NULL
    // 0x6efc60: b.eq            #0x6efcc4
    // 0x6efc64: LoadField: r2 = r1->field_b
    //     0x6efc64: ldur            w2, [x1, #0xb]
    // 0x6efc68: DecompressPointer r2
    //     0x6efc68: add             x2, x2, HEAP, lsl #32
    // 0x6efc6c: cmp             w2, NULL
    // 0x6efc70: b.eq            #0x6efcc8
    // 0x6efc74: SaveReg r0
    //     0x6efc74: str             x0, [SP, #-8]!
    // 0x6efc78: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x6efc78: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x6efc7c: r0 = of()
    //     0x6efc7c: bl              #0x59424c  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x6efc80: add             SP, SP, #8
    // 0x6efc84: mov             x1, x0
    // 0x6efc88: ldr             x0, [fp, #0x10]
    // 0x6efc8c: LoadField: r2 = r0->field_4f
    //     0x6efc8c: ldur            w2, [x0, #0x4f]
    // 0x6efc90: DecompressPointer r2
    //     0x6efc90: add             x2, x2, HEAP, lsl #32
    // 0x6efc94: cmp             w2, NULL
    // 0x6efc98: b.eq            #0x6efccc
    // 0x6efc9c: stp             x2, x1, [SP, #-0x10]!
    // 0x6efca0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x6efca0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x6efca4: r0 = insert()
    //     0x6efca4: bl              #0x594040  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insert
    // 0x6efca8: add             SP, SP, #0x10
    // 0x6efcac: r0 = Null
    //     0x6efcac: mov             x0, NULL
    // 0x6efcb0: LeaveFrame
    //     0x6efcb0: mov             SP, fp
    //     0x6efcb4: ldp             fp, lr, [SP], #0x10
    // 0x6efcb8: ret
    //     0x6efcb8: ret             
    // 0x6efcbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6efcbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6efcc0: b               #0x6efbdc
    // 0x6efcc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6efcc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6efcc8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6efcc8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6efccc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6efccc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] CompositedTransformFollower <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x6efcdc, size: 0x84
    // 0x6efcdc: EnterFrame
    //     0x6efcdc: stp             fp, lr, [SP, #-0x10]!
    //     0x6efce0: mov             fp, SP
    // 0x6efce4: AllocStack(0x18)
    //     0x6efce4: sub             SP, SP, #0x18
    // 0x6efce8: SetupParameters()
    //     0x6efce8: ldr             x0, [fp, #0x18]
    //     0x6efcec: ldur            w1, [x0, #0x17]
    //     0x6efcf0: add             x1, x1, HEAP, lsl #32
    // 0x6efcf4: LoadField: r0 = r1->field_f
    //     0x6efcf4: ldur            w0, [x1, #0xf]
    // 0x6efcf8: DecompressPointer r0
    //     0x6efcf8: add             x0, x0, HEAP, lsl #32
    // 0x6efcfc: stur            x0, [fp, #-0x10]
    // 0x6efd00: LoadField: r1 = r0->field_4b
    //     0x6efd00: ldur            w1, [x0, #0x4b]
    // 0x6efd04: DecompressPointer r1
    //     0x6efd04: add             x1, x1, HEAP, lsl #32
    // 0x6efd08: stur            x1, [fp, #-8]
    // 0x6efd0c: r0 = _ValueIndicatorRenderObjectWidget()
    //     0x6efd0c: bl              #0x6efd6c  ; Allocate_ValueIndicatorRenderObjectWidgetStub -> _ValueIndicatorRenderObjectWidget (size=0x10)
    // 0x6efd10: mov             x1, x0
    // 0x6efd14: ldur            x0, [fp, #-0x10]
    // 0x6efd18: stur            x1, [fp, #-0x18]
    // 0x6efd1c: StoreField: r1->field_b = r0
    //     0x6efd1c: stur            w0, [x1, #0xb]
    // 0x6efd20: r0 = CompositedTransformFollower()
    //     0x6efd20: bl              #0x6efd60  ; AllocateCompositedTransformFollowerStub -> CompositedTransformFollower (size=0x24)
    // 0x6efd24: ldur            x1, [fp, #-8]
    // 0x6efd28: StoreField: r0->field_f = r1
    //     0x6efd28: stur            w1, [x0, #0xf]
    // 0x6efd2c: r1 = true
    //     0x6efd2c: add             x1, NULL, #0x20  ; true
    // 0x6efd30: StoreField: r0->field_13 = r1
    //     0x6efd30: stur            w1, [x0, #0x13]
    // 0x6efd34: r1 = Instance_Offset
    //     0x6efd34: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x6efd38: StoreField: r0->field_1f = r1
    //     0x6efd38: stur            w1, [x0, #0x1f]
    // 0x6efd3c: r1 = Instance_Alignment
    //     0x6efd3c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x6efd40: ldr             x1, [x1, #0xbd0]
    // 0x6efd44: StoreField: r0->field_17 = r1
    //     0x6efd44: stur            w1, [x0, #0x17]
    // 0x6efd48: StoreField: r0->field_1b = r1
    //     0x6efd48: stur            w1, [x0, #0x1b]
    // 0x6efd4c: ldur            x1, [fp, #-0x18]
    // 0x6efd50: StoreField: r0->field_b = r1
    //     0x6efd50: stur            w1, [x0, #0xb]
    // 0x6efd54: LeaveFrame
    //     0x6efd54: mov             SP, fp
    //     0x6efd58: ldp             fp, lr, [SP], #0x10
    // 0x6efd5c: ret
    //     0x6efd5c: ret             
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x84f7ac, size: 0x48
    // 0x84f7ac: ldr             x1, [SP]
    // 0x84f7b0: LoadField: r2 = r1->field_17
    //     0x84f7b0: ldur            w2, [x1, #0x17]
    // 0x84f7b4: DecompressPointer r2
    //     0x84f7b4: add             x2, x2, HEAP, lsl #32
    // 0x84f7b8: LoadField: r1 = r2->field_f
    //     0x84f7b8: ldur            w1, [x2, #0xf]
    // 0x84f7bc: DecompressPointer r1
    //     0x84f7bc: add             x1, x1, HEAP, lsl #32
    // 0x84f7c0: LoadField: r0 = r2->field_13
    //     0x84f7c0: ldur            w0, [x2, #0x13]
    // 0x84f7c4: DecompressPointer r0
    //     0x84f7c4: add             x0, x0, HEAP, lsl #32
    // 0x84f7c8: StoreField: r1->field_43 = r0
    //     0x84f7c8: stur            w0, [x1, #0x43]
    //     0x84f7cc: ldurb           w16, [x1, #-1]
    //     0x84f7d0: ldurb           w17, [x0, #-1]
    //     0x84f7d4: and             x16, x17, x16, lsr #2
    //     0x84f7d8: tst             x16, HEAP, lsr #32
    //     0x84f7dc: b.eq            #0x84f7ec
    //     0x84f7e0: str             lr, [SP, #-8]!
    //     0x84f7e4: bl              #0xd6826c
    //     0x84f7e8: ldr             lr, [SP], #8
    // 0x84f7ec: r0 = Null
    //     0x84f7ec: mov             x0, NULL
    // 0x84f7f0: ret
    //     0x84f7f0: ret             
  }
  _ _handleFocusHighlightChanged(/* No info */) {
    // ** addr: 0x84f7f4, size: 0x78
    // 0x84f7f4: EnterFrame
    //     0x84f7f4: stp             fp, lr, [SP, #-0x10]!
    //     0x84f7f8: mov             fp, SP
    // 0x84f7fc: CheckStackOverflow
    //     0x84f7fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f800: cmp             SP, x16
    //     0x84f804: b.ls            #0x84f864
    // 0x84f808: r1 = 2
    //     0x84f808: mov             x1, #2
    // 0x84f80c: r0 = AllocateContext()
    //     0x84f80c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84f810: mov             x1, x0
    // 0x84f814: ldr             x0, [fp, #0x18]
    // 0x84f818: StoreField: r1->field_f = r0
    //     0x84f818: stur            w0, [x1, #0xf]
    // 0x84f81c: ldr             x2, [fp, #0x10]
    // 0x84f820: StoreField: r1->field_13 = r2
    //     0x84f820: stur            w2, [x1, #0x13]
    // 0x84f824: LoadField: r3 = r0->field_43
    //     0x84f824: ldur            w3, [x0, #0x43]
    // 0x84f828: DecompressPointer r3
    //     0x84f828: add             x3, x3, HEAP, lsl #32
    // 0x84f82c: cmp             w2, w3
    // 0x84f830: b.eq            #0x84f854
    // 0x84f834: mov             x2, x1
    // 0x84f838: r1 = Function '<anonymous closure>':.
    //     0x84f838: add             x1, PP, #0x55, lsl #12  ; [pp+0x557e8] AnonymousClosure: (0x84f7ac), in [package:flutter/src/material/slider.dart] _SliderState::_handleFocusHighlightChanged (0x84f7f4)
    //     0x84f83c: ldr             x1, [x1, #0x7e8]
    // 0x84f840: r0 = AllocateClosure()
    //     0x84f840: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84f844: ldr             x16, [fp, #0x18]
    // 0x84f848: stp             x0, x16, [SP, #-0x10]!
    // 0x84f84c: r0 = setState()
    //     0x84f84c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84f850: add             SP, SP, #0x10
    // 0x84f854: r0 = Null
    //     0x84f854: mov             x0, NULL
    // 0x84f858: LeaveFrame
    //     0x84f858: mov             SP, fp
    //     0x84f85c: ldp             fp, lr, [SP], #0x10
    // 0x84f860: ret
    //     0x84f860: ret             
    // 0x84f864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f864: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f868: b               #0x84f808
  }
  [closure] void _handleFocusHighlightChanged(dynamic, bool) {
    // ** addr: 0x84f86c, size: 0x4c
    // 0x84f86c: EnterFrame
    //     0x84f86c: stp             fp, lr, [SP, #-0x10]!
    //     0x84f870: mov             fp, SP
    // 0x84f874: ldr             x0, [fp, #0x18]
    // 0x84f878: LoadField: r1 = r0->field_17
    //     0x84f878: ldur            w1, [x0, #0x17]
    // 0x84f87c: DecompressPointer r1
    //     0x84f87c: add             x1, x1, HEAP, lsl #32
    // 0x84f880: CheckStackOverflow
    //     0x84f880: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84f884: cmp             SP, x16
    //     0x84f888: b.ls            #0x84f8b0
    // 0x84f88c: LoadField: r0 = r1->field_f
    //     0x84f88c: ldur            w0, [x1, #0xf]
    // 0x84f890: DecompressPointer r0
    //     0x84f890: add             x0, x0, HEAP, lsl #32
    // 0x84f894: ldr             x16, [fp, #0x10]
    // 0x84f898: stp             x16, x0, [SP, #-0x10]!
    // 0x84f89c: r0 = _handleFocusHighlightChanged()
    //     0x84f89c: bl              #0x84f7f4  ; [package:flutter/src/material/slider.dart] _SliderState::_handleFocusHighlightChanged
    // 0x84f8a0: add             SP, SP, #0x10
    // 0x84f8a4: LeaveFrame
    //     0x84f8a4: mov             SP, fp
    //     0x84f8a8: ldp             fp, lr, [SP], #0x10
    // 0x84f8ac: ret
    //     0x84f8ac: ret             
    // 0x84f8b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84f8b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84f8b4: b               #0x84f88c
  }
  _ build(/* No info */) {
    // ** addr: 0x866bd4, size: 0xe0
    // 0x866bd4: EnterFrame
    //     0x866bd4: stp             fp, lr, [SP, #-0x10]!
    //     0x866bd8: mov             fp, SP
    // 0x866bdc: CheckStackOverflow
    //     0x866bdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866be0: cmp             SP, x16
    //     0x866be4: b.ls            #0x866ca8
    // 0x866be8: ldr             x0, [fp, #0x18]
    // 0x866bec: LoadField: r1 = r0->field_b
    //     0x866bec: ldur            w1, [x0, #0xb]
    // 0x866bf0: DecompressPointer r1
    //     0x866bf0: add             x1, x1, HEAP, lsl #32
    // 0x866bf4: cmp             w1, NULL
    // 0x866bf8: b.eq            #0x866cb0
    // 0x866bfc: LoadField: r2 = r1->field_5f
    //     0x866bfc: ldur            w2, [x1, #0x5f]
    // 0x866c00: DecompressPointer r2
    //     0x866c00: add             x2, x2, HEAP, lsl #32
    // 0x866c04: LoadField: r1 = r2->field_7
    //     0x866c04: ldur            x1, [x2, #7]
    // 0x866c08: cmp             x1, #0
    // 0x866c0c: b.gt            #0x866c2c
    // 0x866c10: ldr             x16, [fp, #0x10]
    // 0x866c14: stp             x16, x0, [SP, #-0x10]!
    // 0x866c18: r0 = _buildMaterialSlider()
    //     0x866c18: bl              #0x866d60  ; [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider
    // 0x866c1c: add             SP, SP, #0x10
    // 0x866c20: LeaveFrame
    //     0x866c20: mov             SP, fp
    //     0x866c24: ldp             fp, lr, [SP], #0x10
    // 0x866c28: ret
    //     0x866c28: ret             
    // 0x866c2c: ldr             x16, [fp, #0x10]
    // 0x866c30: SaveReg r16
    //     0x866c30: str             x16, [SP, #-8]!
    // 0x866c34: r0 = of()
    //     0x866c34: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x866c38: add             SP, SP, #8
    // 0x866c3c: LoadField: r1 = r0->field_1f
    //     0x866c3c: ldur            w1, [x0, #0x1f]
    // 0x866c40: DecompressPointer r1
    //     0x866c40: add             x1, x1, HEAP, lsl #32
    // 0x866c44: LoadField: r0 = r1->field_7
    //     0x866c44: ldur            x0, [x1, #7]
    // 0x866c48: cmp             x0, #2
    // 0x866c4c: b.gt            #0x866c5c
    // 0x866c50: cmp             x0, #1
    // 0x866c54: b.gt            #0x866c6c
    // 0x866c58: b               #0x866c88
    // 0x866c5c: cmp             x0, #4
    // 0x866c60: b.gt            #0x866c88
    // 0x866c64: cmp             x0, #3
    // 0x866c68: b.le            #0x866c88
    // 0x866c6c: ldr             x16, [fp, #0x18]
    // 0x866c70: SaveReg r16
    //     0x866c70: str             x16, [SP, #-8]!
    // 0x866c74: r0 = _buildCupertinoSlider()
    //     0x866c74: bl              #0x866cb4  ; [package:flutter/src/material/slider.dart] _SliderState::_buildCupertinoSlider
    // 0x866c78: add             SP, SP, #8
    // 0x866c7c: LeaveFrame
    //     0x866c7c: mov             SP, fp
    //     0x866c80: ldp             fp, lr, [SP], #0x10
    // 0x866c84: ret
    //     0x866c84: ret             
    // 0x866c88: ldr             x16, [fp, #0x18]
    // 0x866c8c: ldr             lr, [fp, #0x10]
    // 0x866c90: stp             lr, x16, [SP, #-0x10]!
    // 0x866c94: r0 = _buildMaterialSlider()
    //     0x866c94: bl              #0x866d60  ; [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider
    // 0x866c98: add             SP, SP, #0x10
    // 0x866c9c: LeaveFrame
    //     0x866c9c: mov             SP, fp
    //     0x866ca0: ldp             fp, lr, [SP], #0x10
    // 0x866ca4: ret
    //     0x866ca4: ret             
    // 0x866ca8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x866ca8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x866cac: b               #0x866be8
    // 0x866cb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866cb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildCupertinoSlider(/* No info */) {
    // ** addr: 0x866cb4, size: 0xa0
    // 0x866cb4: EnterFrame
    //     0x866cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x866cb8: mov             fp, SP
    // 0x866cbc: AllocStack(0x28)
    //     0x866cbc: sub             SP, SP, #0x28
    // 0x866cc0: ldr             x0, [fp, #0x10]
    // 0x866cc4: LoadField: r1 = r0->field_b
    //     0x866cc4: ldur            w1, [x0, #0xb]
    // 0x866cc8: DecompressPointer r1
    //     0x866cc8: add             x1, x1, HEAP, lsl #32
    // 0x866ccc: cmp             w1, NULL
    // 0x866cd0: b.eq            #0x866d50
    // 0x866cd4: LoadField: d0 = r1->field_b
    //     0x866cd4: ldur            d0, [x1, #0xb]
    // 0x866cd8: stur            d0, [fp, #-0x28]
    // 0x866cdc: LoadField: r0 = r1->field_17
    //     0x866cdc: ldur            w0, [x1, #0x17]
    // 0x866ce0: DecompressPointer r0
    //     0x866ce0: add             x0, x0, HEAP, lsl #32
    // 0x866ce4: stur            x0, [fp, #-8]
    // 0x866ce8: LoadField: d1 = r1->field_23
    //     0x866ce8: ldur            d1, [x1, #0x23]
    // 0x866cec: stur            d1, [fp, #-0x20]
    // 0x866cf0: LoadField: d2 = r1->field_2b
    //     0x866cf0: ldur            d2, [x1, #0x2b]
    // 0x866cf4: stur            d2, [fp, #-0x18]
    // 0x866cf8: r0 = CupertinoSlider()
    //     0x866cf8: bl              #0x866d54  ; AllocateCupertinoSliderStub -> CupertinoSlider (size=0x3c)
    // 0x866cfc: ldur            d0, [fp, #-0x28]
    // 0x866d00: stur            x0, [fp, #-0x10]
    // 0x866d04: StoreField: r0->field_b = d0
    //     0x866d04: stur            d0, [x0, #0xb]
    // 0x866d08: ldur            x1, [fp, #-8]
    // 0x866d0c: StoreField: r0->field_13 = r1
    //     0x866d0c: stur            w1, [x0, #0x13]
    // 0x866d10: ldur            d0, [fp, #-0x20]
    // 0x866d14: StoreField: r0->field_1f = d0
    //     0x866d14: stur            d0, [x0, #0x1f]
    // 0x866d18: ldur            d0, [fp, #-0x18]
    // 0x866d1c: StoreField: r0->field_27 = d0
    //     0x866d1c: stur            d0, [x0, #0x27]
    // 0x866d20: r1 = Instance_Color
    //     0x866d20: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x866d24: ldr             x1, [x1, #0xbe8]
    // 0x866d28: StoreField: r0->field_37 = r1
    //     0x866d28: stur            w1, [x0, #0x37]
    // 0x866d2c: r0 = SizedBox()
    //     0x866d2c: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x866d30: r1 = inf
    //     0x866d30: add             x1, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0x866d34: ldr             x1, [x1, #0x218]
    // 0x866d38: StoreField: r0->field_f = r1
    //     0x866d38: stur            w1, [x0, #0xf]
    // 0x866d3c: ldur            x1, [fp, #-0x10]
    // 0x866d40: StoreField: r0->field_b = r1
    //     0x866d40: stur            w1, [x0, #0xb]
    // 0x866d44: LeaveFrame
    //     0x866d44: mov             SP, fp
    //     0x866d48: ldp             fp, lr, [SP], #0x10
    // 0x866d4c: ret
    //     0x866d4c: ret             
    // 0x866d50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x866d50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _buildMaterialSlider(/* No info */) {
    // ** addr: 0x866d60, size: 0x104c
    // 0x866d60: EnterFrame
    //     0x866d60: stp             fp, lr, [SP, #-0x10]!
    //     0x866d64: mov             fp, SP
    // 0x866d68: AllocStack(0xb8)
    //     0x866d68: sub             SP, SP, #0xb8
    // 0x866d6c: CheckStackOverflow
    //     0x866d6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x866d70: cmp             SP, x16
    //     0x866d74: b.ls            #0x867d40
    // 0x866d78: r1 = 5
    //     0x866d78: mov             x1, #5
    // 0x866d7c: r0 = AllocateContext()
    //     0x866d7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x866d80: mov             x1, x0
    // 0x866d84: ldr             x0, [fp, #0x18]
    // 0x866d88: stur            x1, [fp, #-8]
    // 0x866d8c: StoreField: r1->field_f = r0
    //     0x866d8c: stur            w0, [x1, #0xf]
    // 0x866d90: ldr             x2, [fp, #0x10]
    // 0x866d94: StoreField: r1->field_13 = r2
    //     0x866d94: stur            w2, [x1, #0x13]
    // 0x866d98: SaveReg r2
    //     0x866d98: str             x2, [SP, #-8]!
    // 0x866d9c: r0 = of()
    //     0x866d9c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x866da0: add             SP, SP, #8
    // 0x866da4: ldur            x2, [fp, #-8]
    // 0x866da8: stur            x0, [fp, #-0x10]
    // 0x866dac: LoadField: r1 = r2->field_13
    //     0x866dac: ldur            w1, [x2, #0x13]
    // 0x866db0: DecompressPointer r1
    //     0x866db0: add             x1, x1, HEAP, lsl #32
    // 0x866db4: SaveReg r1
    //     0x866db4: str             x1, [SP, #-8]!
    // 0x866db8: r0 = of()
    //     0x866db8: bl              #0x8682e0  ; [package:flutter/src/material/slider_theme.dart] SliderTheme::of
    // 0x866dbc: add             SP, SP, #8
    // 0x866dc0: ldur            x2, [fp, #-8]
    // 0x866dc4: StoreField: r2->field_17 = r0
    //     0x866dc4: stur            w0, [x2, #0x17]
    //     0x866dc8: ldurb           w16, [x2, #-1]
    //     0x866dcc: ldurb           w17, [x0, #-1]
    //     0x866dd0: and             x16, x17, x16, lsr #2
    //     0x866dd4: tst             x16, HEAP, lsr #32
    //     0x866dd8: b.eq            #0x866de0
    //     0x866ddc: bl              #0xd6828c
    // 0x866de0: ldur            x0, [fp, #-0x10]
    // 0x866de4: LoadField: r1 = r0->field_2b
    //     0x866de4: ldur            w1, [x0, #0x2b]
    // 0x866de8: DecompressPointer r1
    //     0x866de8: add             x1, x1, HEAP, lsl #32
    // 0x866dec: stur            x1, [fp, #-0x20]
    // 0x866df0: tbnz            w1, #4, #0x866e60
    // 0x866df4: LoadField: r3 = r2->field_13
    //     0x866df4: ldur            w3, [x2, #0x13]
    // 0x866df8: DecompressPointer r3
    //     0x866df8: add             x3, x3, HEAP, lsl #32
    // 0x866dfc: stur            x3, [fp, #-0x18]
    // 0x866e00: r0 = _SliderDefaultsM3()
    //     0x866e00: bl              #0x8682d4  ; Allocate_SliderDefaultsM3Stub -> _SliderDefaultsM3 (size=0x88)
    // 0x866e04: mov             x1, x0
    // 0x866e08: ldur            x0, [fp, #-0x18]
    // 0x866e0c: stur            x1, [fp, #-0x28]
    // 0x866e10: StoreField: r1->field_7f = r0
    //     0x866e10: stur            w0, [x1, #0x7f]
    // 0x866e14: SaveReg r0
    //     0x866e14: str             x0, [SP, #-8]!
    // 0x866e18: r0 = of()
    //     0x866e18: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x866e1c: add             SP, SP, #8
    // 0x866e20: LoadField: r1 = r0->field_3f
    //     0x866e20: ldur            w1, [x0, #0x3f]
    // 0x866e24: DecompressPointer r1
    //     0x866e24: add             x1, x1, HEAP, lsl #32
    // 0x866e28: mov             x0, x1
    // 0x866e2c: ldur            x1, [fp, #-0x28]
    // 0x866e30: StoreField: r1->field_83 = r0
    //     0x866e30: stur            w0, [x1, #0x83]
    //     0x866e34: ldurb           w16, [x1, #-1]
    //     0x866e38: ldurb           w17, [x0, #-1]
    //     0x866e3c: and             x16, x17, x16, lsr #2
    //     0x866e40: tst             x16, HEAP, lsr #32
    //     0x866e44: b.eq            #0x866e4c
    //     0x866e48: bl              #0xd6826c
    // 0x866e4c: r0 = 4.000000
    //     0x866e4c: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e718] 4
    //     0x866e50: ldr             x0, [x0, #0x718]
    // 0x866e54: StoreField: r1->field_7 = r0
    //     0x866e54: stur            w0, [x1, #7]
    // 0x866e58: mov             x3, x1
    // 0x866e5c: b               #0x866ed0
    // 0x866e60: r0 = 4.000000
    //     0x866e60: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e718] 4
    //     0x866e64: ldr             x0, [x0, #0x718]
    // 0x866e68: LoadField: r1 = r2->field_13
    //     0x866e68: ldur            w1, [x2, #0x13]
    // 0x866e6c: DecompressPointer r1
    //     0x866e6c: add             x1, x1, HEAP, lsl #32
    // 0x866e70: stur            x1, [fp, #-0x18]
    // 0x866e74: r0 = _SliderDefaultsM2()
    //     0x866e74: bl              #0x8682c8  ; Allocate_SliderDefaultsM2Stub -> _SliderDefaultsM2 (size=0x88)
    // 0x866e78: mov             x1, x0
    // 0x866e7c: ldur            x0, [fp, #-0x18]
    // 0x866e80: stur            x1, [fp, #-0x28]
    // 0x866e84: StoreField: r1->field_7f = r0
    //     0x866e84: stur            w0, [x1, #0x7f]
    // 0x866e88: SaveReg r0
    //     0x866e88: str             x0, [SP, #-8]!
    // 0x866e8c: r0 = of()
    //     0x866e8c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x866e90: add             SP, SP, #8
    // 0x866e94: LoadField: r1 = r0->field_3f
    //     0x866e94: ldur            w1, [x0, #0x3f]
    // 0x866e98: DecompressPointer r1
    //     0x866e98: add             x1, x1, HEAP, lsl #32
    // 0x866e9c: mov             x0, x1
    // 0x866ea0: ldur            x1, [fp, #-0x28]
    // 0x866ea4: StoreField: r1->field_83 = r0
    //     0x866ea4: stur            w0, [x1, #0x83]
    //     0x866ea8: ldurb           w16, [x1, #-1]
    //     0x866eac: ldurb           w17, [x0, #-1]
    //     0x866eb0: and             x16, x17, x16, lsr #2
    //     0x866eb4: tst             x16, HEAP, lsr #32
    //     0x866eb8: b.eq            #0x866ec0
    //     0x866ebc: bl              #0xd6826c
    // 0x866ec0: r0 = 4.000000
    //     0x866ec0: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e718] 4
    //     0x866ec4: ldr             x0, [x0, #0x718]
    // 0x866ec8: StoreField: r1->field_7 = r0
    //     0x866ec8: stur            w0, [x1, #7]
    // 0x866ecc: mov             x3, x1
    // 0x866ed0: ldr             x1, [fp, #0x18]
    // 0x866ed4: ldur            x2, [fp, #-8]
    // 0x866ed8: mov             x0, x3
    // 0x866edc: stur            x3, [fp, #-0x18]
    // 0x866ee0: StoreField: r2->field_1b = r0
    //     0x866ee0: stur            w0, [x2, #0x1b]
    //     0x866ee4: ldurb           w16, [x2, #-1]
    //     0x866ee8: ldurb           w17, [x0, #-1]
    //     0x866eec: and             x16, x17, x16, lsr #2
    //     0x866ef0: tst             x16, HEAP, lsr #32
    //     0x866ef4: b.eq            #0x866efc
    //     0x866ef8: bl              #0xd6828c
    // 0x866efc: r0 = LoadClassIdInstr(r3)
    //     0x866efc: ldur            x0, [x3, #-1]
    //     0x866f00: ubfx            x0, x0, #0xc, #0x14
    // 0x866f04: SaveReg r3
    //     0x866f04: str             x3, [SP, #-8]!
    // 0x866f08: r0 = GDT[cid_x0 + -0xfd6]()
    //     0x866f08: sub             lr, x0, #0xfd6
    //     0x866f0c: ldr             lr, [x21, lr, lsl #3]
    //     0x866f10: blr             lr
    // 0x866f14: add             SP, SP, #8
    // 0x866f18: stur            x0, [fp, #-0x28]
    // 0x866f1c: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x866f1c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x866f20: ldr             x0, [x0, #0x598]
    //     0x866f24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x866f28: cmp             w0, w16
    //     0x866f2c: b.ne            #0x866f38
    //     0x866f30: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x866f34: bl              #0xd67cdc
    // 0x866f38: r1 = <MaterialState>
    //     0x866f38: add             x1, PP, #0x2d, lsl #12  ; [pp+0x2dcf0] TypeArguments: <MaterialState>
    //     0x866f3c: ldr             x1, [x1, #0xcf0]
    // 0x866f40: stur            x0, [fp, #-0x30]
    // 0x866f44: r0 = _Set()
    //     0x866f44: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x866f48: mov             x1, x0
    // 0x866f4c: ldur            x0, [fp, #-0x30]
    // 0x866f50: stur            x1, [fp, #-0x38]
    // 0x866f54: StoreField: r1->field_1b = r0
    //     0x866f54: stur            w0, [x1, #0x1b]
    // 0x866f58: StoreField: r1->field_b = rZR
    //     0x866f58: stur            wzr, [x1, #0xb]
    // 0x866f5c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x866f5c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x866f60: ldr             x0, [x0, #0x5a0]
    //     0x866f64: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x866f68: cmp             w0, w16
    //     0x866f6c: b.ne            #0x866f78
    //     0x866f70: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x866f74: bl              #0xd67cdc
    // 0x866f78: mov             x1, x0
    // 0x866f7c: ldur            x0, [fp, #-0x38]
    // 0x866f80: StoreField: r0->field_f = r1
    //     0x866f80: stur            w1, [x0, #0xf]
    // 0x866f84: StoreField: r0->field_13 = rZR
    //     0x866f84: stur            wzr, [x0, #0x13]
    // 0x866f88: StoreField: r0->field_17 = rZR
    //     0x866f88: stur            wzr, [x0, #0x17]
    // 0x866f8c: ldr             x1, [fp, #0x18]
    // 0x866f90: LoadField: r2 = r1->field_b
    //     0x866f90: ldur            w2, [x1, #0xb]
    // 0x866f94: DecompressPointer r2
    //     0x866f94: add             x2, x2, HEAP, lsl #32
    // 0x866f98: cmp             w2, NULL
    // 0x866f9c: b.eq            #0x867d48
    // 0x866fa0: LoadField: r3 = r2->field_17
    //     0x866fa0: ldur            w3, [x2, #0x17]
    // 0x866fa4: DecompressPointer r3
    //     0x866fa4: add             x3, x3, HEAP, lsl #32
    // 0x866fa8: cmp             w3, NULL
    // 0x866fac: b.ne            #0x866fc4
    // 0x866fb0: r16 = Instance_MaterialState
    //     0x866fb0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe2a0] Obj!MaterialState@b65411
    //     0x866fb4: ldr             x16, [x16, #0x2a0]
    // 0x866fb8: stp             x16, x0, [SP, #-0x10]!
    // 0x866fbc: r0 = add()
    //     0x866fbc: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x866fc0: add             SP, SP, #0x10
    // 0x866fc4: ldr             x0, [fp, #0x18]
    // 0x866fc8: LoadField: r1 = r0->field_47
    //     0x866fc8: ldur            w1, [x0, #0x47]
    // 0x866fcc: DecompressPointer r1
    //     0x866fcc: add             x1, x1, HEAP, lsl #32
    // 0x866fd0: tbnz            w1, #4, #0x866fec
    // 0x866fd4: ldur            x16, [fp, #-0x38]
    // 0x866fd8: r30 = Instance_MaterialState
    //     0x866fd8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf78] Obj!MaterialState@b65471
    //     0x866fdc: ldr             lr, [lr, #0xf78]
    // 0x866fe0: stp             lr, x16, [SP, #-0x10]!
    // 0x866fe4: r0 = add()
    //     0x866fe4: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x866fe8: add             SP, SP, #0x10
    // 0x866fec: ldr             x0, [fp, #0x18]
    // 0x866ff0: LoadField: r1 = r0->field_43
    //     0x866ff0: ldur            w1, [x0, #0x43]
    // 0x866ff4: DecompressPointer r1
    //     0x866ff4: add             x1, x1, HEAP, lsl #32
    // 0x866ff8: tbnz            w1, #4, #0x867014
    // 0x866ffc: ldur            x16, [fp, #-0x38]
    // 0x867000: r30 = Instance_MaterialState
    //     0x867000: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf88] Obj!MaterialState@b65451
    //     0x867004: ldr             lr, [lr, #0xf88]
    // 0x867008: stp             lr, x16, [SP, #-0x10]!
    // 0x86700c: r0 = add()
    //     0x86700c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x867010: add             SP, SP, #0x10
    // 0x867014: ldr             x0, [fp, #0x18]
    // 0x867018: LoadField: r1 = r0->field_3b
    //     0x867018: ldur            w1, [x0, #0x3b]
    // 0x86701c: DecompressPointer r1
    //     0x86701c: add             x1, x1, HEAP, lsl #32
    // 0x867020: tbnz            w1, #4, #0x86703c
    // 0x867024: ldur            x16, [fp, #-0x38]
    // 0x867028: r30 = Instance_MaterialState
    //     0x867028: add             lr, PP, #0xe, lsl #12  ; [pp+0xe170] Obj!MaterialState@b654f1
    //     0x86702c: ldr             lr, [lr, #0x170]
    // 0x867030: stp             lr, x16, [SP, #-0x10]!
    // 0x867034: r0 = add()
    //     0x867034: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x867038: add             SP, SP, #0x10
    // 0x86703c: ldur            x2, [fp, #-8]
    // 0x867040: ldur            x0, [fp, #-0x38]
    // 0x867044: StoreField: r2->field_1f = r0
    //     0x867044: stur            w0, [x2, #0x1f]
    //     0x867048: ldurb           w16, [x2, #-1]
    //     0x86704c: ldurb           w17, [x0, #-1]
    //     0x867050: and             x16, x17, x16, lsr #2
    //     0x867054: tst             x16, HEAP, lsr #32
    //     0x867058: b.eq            #0x867060
    //     0x86705c: bl              #0xd6828c
    // 0x867060: LoadField: r0 = r2->field_17
    //     0x867060: ldur            w0, [x2, #0x17]
    // 0x867064: DecompressPointer r0
    //     0x867064: add             x0, x0, HEAP, lsl #32
    // 0x867068: LoadField: r1 = r0->field_57
    //     0x867068: ldur            w1, [x0, #0x57]
    // 0x86706c: DecompressPointer r1
    //     0x86706c: add             x1, x1, HEAP, lsl #32
    // 0x867070: cmp             w1, NULL
    // 0x867074: b.ne            #0x86707c
    // 0x867078: ldur            x1, [fp, #-0x28]
    // 0x86707c: stur            x1, [fp, #-0x30]
    // 0x867080: r3 = LoadClassIdInstr(r1)
    //     0x867080: ldur            x3, [x1, #-1]
    //     0x867084: ubfx            x3, x3, #0xc, #0x14
    // 0x867088: lsl             x3, x3, #1
    // 0x86708c: r17 = 4282
    //     0x86708c: mov             x17, #0x10ba
    // 0x867090: cmp             w3, w17
    // 0x867094: b.ne            #0x86712c
    // 0x867098: LoadField: r3 = r0->field_43
    //     0x867098: ldur            w3, [x0, #0x43]
    // 0x86709c: DecompressPointer r3
    //     0x86709c: add             x3, x3, HEAP, lsl #32
    // 0x8670a0: cmp             w3, NULL
    // 0x8670a4: b.ne            #0x867118
    // 0x8670a8: ldur            x0, [fp, #-0x10]
    // 0x8670ac: d0 = 0.600000
    //     0x8670ac: add             x17, PP, #0xc, lsl #12  ; [pp+0xcf90] IMM: double(0.6) from 0x3fe3333333333333
    //     0x8670b0: ldr             d0, [x17, #0xf90]
    // 0x8670b4: LoadField: r3 = r0->field_3f
    //     0x8670b4: ldur            w3, [x0, #0x3f]
    // 0x8670b8: DecompressPointer r3
    //     0x8670b8: add             x3, x3, HEAP, lsl #32
    // 0x8670bc: stur            x3, [fp, #-0x28]
    // 0x8670c0: LoadField: r4 = r3->field_57
    //     0x8670c0: ldur            w4, [x3, #0x57]
    // 0x8670c4: DecompressPointer r4
    //     0x8670c4: add             x4, x4, HEAP, lsl #32
    // 0x8670c8: SaveReg r4
    //     0x8670c8: str             x4, [SP, #-8]!
    // 0x8670cc: SaveReg d0
    //     0x8670cc: str             d0, [SP, #-8]!
    // 0x8670d0: r0 = withOpacity()
    //     0x8670d0: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x8670d4: add             SP, SP, #0x10
    // 0x8670d8: mov             x1, x0
    // 0x8670dc: ldur            x0, [fp, #-0x28]
    // 0x8670e0: stur            x1, [fp, #-0x40]
    // 0x8670e4: LoadField: r2 = r0->field_53
    //     0x8670e4: ldur            w2, [x0, #0x53]
    // 0x8670e8: DecompressPointer r2
    //     0x8670e8: add             x2, x2, HEAP, lsl #32
    // 0x8670ec: SaveReg r2
    //     0x8670ec: str             x2, [SP, #-8]!
    // 0x8670f0: d0 = 0.900000
    //     0x8670f0: add             x17, PP, #0x3e, lsl #12  ; [pp+0x3e3c0] IMM: double(0.9) from 0x3feccccccccccccd
    //     0x8670f4: ldr             d0, [x17, #0x3c0]
    // 0x8670f8: SaveReg d0
    //     0x8670f8: str             d0, [SP, #-8]!
    // 0x8670fc: r0 = withOpacity()
    //     0x8670fc: bl              #0x595404  ; [dart:ui] Color::withOpacity
    // 0x867100: add             SP, SP, #0x10
    // 0x867104: ldur            x16, [fp, #-0x40]
    // 0x867108: stp             x0, x16, [SP, #-0x10]!
    // 0x86710c: r0 = alphaBlend()
    //     0x86710c: bl              #0x85e638  ; [dart:ui] Color::alphaBlend
    // 0x867110: add             SP, SP, #0x10
    // 0x867114: b               #0x86711c
    // 0x867118: mov             x0, x3
    // 0x86711c: mov             x5, x0
    // 0x867120: ldr             x3, [fp, #0x18]
    // 0x867124: ldur            x0, [fp, #-0x10]
    // 0x867128: b               #0x867174
    // 0x86712c: ldr             x3, [fp, #0x18]
    // 0x867130: LoadField: r1 = r3->field_b
    //     0x867130: ldur            w1, [x3, #0xb]
    // 0x867134: DecompressPointer r1
    //     0x867134: add             x1, x1, HEAP, lsl #32
    // 0x867138: cmp             w1, NULL
    // 0x86713c: b.eq            #0x867d4c
    // 0x867140: LoadField: r1 = r0->field_43
    //     0x867140: ldur            w1, [x0, #0x43]
    // 0x867144: DecompressPointer r1
    //     0x867144: add             x1, x1, HEAP, lsl #32
    // 0x867148: cmp             w1, NULL
    // 0x86714c: b.ne            #0x86716c
    // 0x867150: ldur            x0, [fp, #-0x10]
    // 0x867154: LoadField: r1 = r0->field_3f
    //     0x867154: ldur            w1, [x0, #0x3f]
    // 0x867158: DecompressPointer r1
    //     0x867158: add             x1, x1, HEAP, lsl #32
    // 0x86715c: LoadField: r2 = r1->field_b
    //     0x86715c: ldur            w2, [x1, #0xb]
    // 0x867160: DecompressPointer r2
    //     0x867160: add             x2, x2, HEAP, lsl #32
    // 0x867164: mov             x1, x2
    // 0x867168: b               #0x867170
    // 0x86716c: ldur            x0, [fp, #-0x10]
    // 0x867170: mov             x5, x1
    // 0x867174: ldur            x4, [fp, #-8]
    // 0x867178: mov             x2, x4
    // 0x86717c: stur            x5, [fp, #-0x28]
    // 0x867180: r1 = Function 'effectiveOverlayColor':.
    //     0x867180: add             x1, PP, #0x55, lsl #12  ; [pp+0x55780] AnonymousClosure: (0x8687e4), in [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider (0x866d60)
    //     0x867184: ldr             x1, [x1, #0x780]
    // 0x867188: r0 = AllocateClosure()
    //     0x867188: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x86718c: mov             x1, x0
    // 0x867190: ldur            x2, [fp, #-8]
    // 0x867194: stur            x1, [fp, #-0x48]
    // 0x867198: LoadField: r3 = r2->field_17
    //     0x867198: ldur            w3, [x2, #0x17]
    // 0x86719c: DecompressPointer r3
    //     0x86719c: add             x3, x3, HEAP, lsl #32
    // 0x8671a0: stur            x3, [fp, #-0x40]
    // 0x8671a4: LoadField: r0 = r3->field_7
    //     0x8671a4: ldur            w0, [x3, #7]
    // 0x8671a8: DecompressPointer r0
    //     0x8671a8: add             x0, x0, HEAP, lsl #32
    // 0x8671ac: cmp             w0, NULL
    // 0x8671b0: b.ne            #0x8671bc
    // 0x8671b4: d0 = 4.000000
    //     0x8671b4: fmov            d0, #4.00000000
    // 0x8671b8: b               #0x8671c0
    // 0x8671bc: LoadField: d0 = r0->field_7
    //     0x8671bc: ldur            d0, [x0, #7]
    // 0x8671c0: ldr             x4, [fp, #0x18]
    // 0x8671c4: stur            d0, [fp, #-0xb0]
    // 0x8671c8: LoadField: r0 = r4->field_b
    //     0x8671c8: ldur            w0, [x4, #0xb]
    // 0x8671cc: DecompressPointer r0
    //     0x8671cc: add             x0, x0, HEAP, lsl #32
    // 0x8671d0: cmp             w0, NULL
    // 0x8671d4: b.eq            #0x867d50
    // 0x8671d8: r0 = LoadClassIdInstr(r3)
    //     0x8671d8: ldur            x0, [x3, #-1]
    //     0x8671dc: ubfx            x0, x0, #0xc, #0x14
    // 0x8671e0: SaveReg r3
    //     0x8671e0: str             x3, [SP, #-8]!
    // 0x8671e4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8671e4: sub             lr, x0, #1, lsl #12
    //     0x8671e8: ldr             lr, [x21, lr, lsl #3]
    //     0x8671ec: blr             lr
    // 0x8671f0: add             SP, SP, #8
    // 0x8671f4: cmp             w0, NULL
    // 0x8671f8: b.ne            #0x867224
    // 0x8671fc: ldur            x1, [fp, #-0x18]
    // 0x867200: r0 = LoadClassIdInstr(r1)
    //     0x867200: ldur            x0, [x1, #-1]
    //     0x867204: ubfx            x0, x0, #0xc, #0x14
    // 0x867208: SaveReg r1
    //     0x867208: str             x1, [SP, #-8]!
    // 0x86720c: r0 = GDT[cid_x0 + -0x1000]()
    //     0x86720c: sub             lr, x0, #1, lsl #12
    //     0x867210: ldr             lr, [x21, lr, lsl #3]
    //     0x867214: blr             lr
    // 0x867218: add             SP, SP, #8
    // 0x86721c: mov             x3, x0
    // 0x867220: b               #0x867228
    // 0x867224: mov             x3, x0
    // 0x867228: ldr             x1, [fp, #0x18]
    // 0x86722c: ldur            x2, [fp, #-8]
    // 0x867230: stur            x3, [fp, #-0x50]
    // 0x867234: LoadField: r0 = r1->field_b
    //     0x867234: ldur            w0, [x1, #0xb]
    // 0x867238: DecompressPointer r0
    //     0x867238: add             x0, x0, HEAP, lsl #32
    // 0x86723c: cmp             w0, NULL
    // 0x867240: b.eq            #0x867d54
    // 0x867244: LoadField: r0 = r2->field_17
    //     0x867244: ldur            w0, [x2, #0x17]
    // 0x867248: DecompressPointer r0
    //     0x867248: add             x0, x0, HEAP, lsl #32
    // 0x86724c: r4 = LoadClassIdInstr(r0)
    //     0x86724c: ldur            x4, [x0, #-1]
    //     0x867250: ubfx            x4, x4, #0xc, #0x14
    // 0x867254: SaveReg r0
    //     0x867254: str             x0, [SP, #-8]!
    // 0x867258: mov             x0, x4
    // 0x86725c: r0 = GDT[cid_x0 + -0xffd]()
    //     0x86725c: sub             lr, x0, #0xffd
    //     0x867260: ldr             lr, [x21, lr, lsl #3]
    //     0x867264: blr             lr
    // 0x867268: add             SP, SP, #8
    // 0x86726c: cmp             w0, NULL
    // 0x867270: b.ne            #0x86729c
    // 0x867274: ldur            x1, [fp, #-0x18]
    // 0x867278: r0 = LoadClassIdInstr(r1)
    //     0x867278: ldur            x0, [x1, #-1]
    //     0x86727c: ubfx            x0, x0, #0xc, #0x14
    // 0x867280: SaveReg r1
    //     0x867280: str             x1, [SP, #-8]!
    // 0x867284: r0 = GDT[cid_x0 + -0xffd]()
    //     0x867284: sub             lr, x0, #0xffd
    //     0x867288: ldr             lr, [x21, lr, lsl #3]
    //     0x86728c: blr             lr
    // 0x867290: add             SP, SP, #8
    // 0x867294: mov             x3, x0
    // 0x867298: b               #0x8672a0
    // 0x86729c: mov             x3, x0
    // 0x8672a0: ldr             x1, [fp, #0x18]
    // 0x8672a4: ldur            x2, [fp, #-8]
    // 0x8672a8: stur            x3, [fp, #-0x58]
    // 0x8672ac: LoadField: r0 = r1->field_b
    //     0x8672ac: ldur            w0, [x1, #0xb]
    // 0x8672b0: DecompressPointer r0
    //     0x8672b0: add             x0, x0, HEAP, lsl #32
    // 0x8672b4: cmp             w0, NULL
    // 0x8672b8: b.eq            #0x867d58
    // 0x8672bc: LoadField: r0 = r2->field_17
    //     0x8672bc: ldur            w0, [x2, #0x17]
    // 0x8672c0: DecompressPointer r0
    //     0x8672c0: add             x0, x0, HEAP, lsl #32
    // 0x8672c4: r4 = LoadClassIdInstr(r0)
    //     0x8672c4: ldur            x4, [x0, #-1]
    //     0x8672c8: ubfx            x4, x4, #0xc, #0x14
    // 0x8672cc: SaveReg r0
    //     0x8672cc: str             x0, [SP, #-8]!
    // 0x8672d0: mov             x0, x4
    // 0x8672d4: r0 = GDT[cid_x0 + -0xffa]()
    //     0x8672d4: sub             lr, x0, #0xffa
    //     0x8672d8: ldr             lr, [x21, lr, lsl #3]
    //     0x8672dc: blr             lr
    // 0x8672e0: add             SP, SP, #8
    // 0x8672e4: cmp             w0, NULL
    // 0x8672e8: b.ne            #0x867314
    // 0x8672ec: ldur            x1, [fp, #-0x18]
    // 0x8672f0: r0 = LoadClassIdInstr(r1)
    //     0x8672f0: ldur            x0, [x1, #-1]
    //     0x8672f4: ubfx            x0, x0, #0xc, #0x14
    // 0x8672f8: SaveReg r1
    //     0x8672f8: str             x1, [SP, #-8]!
    // 0x8672fc: r0 = GDT[cid_x0 + -0xffa]()
    //     0x8672fc: sub             lr, x0, #0xffa
    //     0x867300: ldr             lr, [x21, lr, lsl #3]
    //     0x867304: blr             lr
    // 0x867308: add             SP, SP, #8
    // 0x86730c: mov             x1, x0
    // 0x867310: b               #0x867318
    // 0x867314: mov             x1, x0
    // 0x867318: ldur            x2, [fp, #-8]
    // 0x86731c: stur            x1, [fp, #-0x60]
    // 0x867320: LoadField: r0 = r2->field_17
    //     0x867320: ldur            w0, [x2, #0x17]
    // 0x867324: DecompressPointer r0
    //     0x867324: add             x0, x0, HEAP, lsl #32
    // 0x867328: r3 = LoadClassIdInstr(r0)
    //     0x867328: ldur            x3, [x0, #-1]
    //     0x86732c: ubfx            x3, x3, #0xc, #0x14
    // 0x867330: SaveReg r0
    //     0x867330: str             x0, [SP, #-8]!
    // 0x867334: mov             x0, x3
    // 0x867338: r0 = GDT[cid_x0 + -0xff7]()
    //     0x867338: sub             lr, x0, #0xff7
    //     0x86733c: ldr             lr, [x21, lr, lsl #3]
    //     0x867340: blr             lr
    // 0x867344: add             SP, SP, #8
    // 0x867348: cmp             w0, NULL
    // 0x86734c: b.ne            #0x867378
    // 0x867350: ldur            x1, [fp, #-0x18]
    // 0x867354: r0 = LoadClassIdInstr(r1)
    //     0x867354: ldur            x0, [x1, #-1]
    //     0x867358: ubfx            x0, x0, #0xc, #0x14
    // 0x86735c: SaveReg r1
    //     0x86735c: str             x1, [SP, #-8]!
    // 0x867360: r0 = GDT[cid_x0 + -0xff7]()
    //     0x867360: sub             lr, x0, #0xff7
    //     0x867364: ldr             lr, [x21, lr, lsl #3]
    //     0x867368: blr             lr
    // 0x86736c: add             SP, SP, #8
    // 0x867370: mov             x1, x0
    // 0x867374: b               #0x86737c
    // 0x867378: mov             x1, x0
    // 0x86737c: ldur            x2, [fp, #-8]
    // 0x867380: stur            x1, [fp, #-0x68]
    // 0x867384: LoadField: r0 = r2->field_17
    //     0x867384: ldur            w0, [x2, #0x17]
    // 0x867388: DecompressPointer r0
    //     0x867388: add             x0, x0, HEAP, lsl #32
    // 0x86738c: r3 = LoadClassIdInstr(r0)
    //     0x86738c: ldur            x3, [x0, #-1]
    //     0x867390: ubfx            x3, x3, #0xc, #0x14
    // 0x867394: SaveReg r0
    //     0x867394: str             x0, [SP, #-8]!
    // 0x867398: mov             x0, x3
    // 0x86739c: r0 = GDT[cid_x0 + -0xff4]()
    //     0x86739c: sub             lr, x0, #0xff4
    //     0x8673a0: ldr             lr, [x21, lr, lsl #3]
    //     0x8673a4: blr             lr
    // 0x8673a8: add             SP, SP, #8
    // 0x8673ac: cmp             w0, NULL
    // 0x8673b0: b.ne            #0x8673dc
    // 0x8673b4: ldur            x1, [fp, #-0x18]
    // 0x8673b8: r0 = LoadClassIdInstr(r1)
    //     0x8673b8: ldur            x0, [x1, #-1]
    //     0x8673bc: ubfx            x0, x0, #0xc, #0x14
    // 0x8673c0: SaveReg r1
    //     0x8673c0: str             x1, [SP, #-8]!
    // 0x8673c4: r0 = GDT[cid_x0 + -0xff4]()
    //     0x8673c4: sub             lr, x0, #0xff4
    //     0x8673c8: ldr             lr, [x21, lr, lsl #3]
    //     0x8673cc: blr             lr
    // 0x8673d0: add             SP, SP, #8
    // 0x8673d4: mov             x1, x0
    // 0x8673d8: b               #0x8673e0
    // 0x8673dc: mov             x1, x0
    // 0x8673e0: ldur            x2, [fp, #-8]
    // 0x8673e4: stur            x1, [fp, #-0x70]
    // 0x8673e8: LoadField: r0 = r2->field_17
    //     0x8673e8: ldur            w0, [x2, #0x17]
    // 0x8673ec: DecompressPointer r0
    //     0x8673ec: add             x0, x0, HEAP, lsl #32
    // 0x8673f0: r3 = LoadClassIdInstr(r0)
    //     0x8673f0: ldur            x3, [x0, #-1]
    //     0x8673f4: ubfx            x3, x3, #0xc, #0x14
    // 0x8673f8: SaveReg r0
    //     0x8673f8: str             x0, [SP, #-8]!
    // 0x8673fc: mov             x0, x3
    // 0x867400: r0 = GDT[cid_x0 + -0xff1]()
    //     0x867400: sub             lr, x0, #0xff1
    //     0x867404: ldr             lr, [x21, lr, lsl #3]
    //     0x867408: blr             lr
    // 0x86740c: add             SP, SP, #8
    // 0x867410: cmp             w0, NULL
    // 0x867414: b.ne            #0x867440
    // 0x867418: ldur            x1, [fp, #-0x18]
    // 0x86741c: r0 = LoadClassIdInstr(r1)
    //     0x86741c: ldur            x0, [x1, #-1]
    //     0x867420: ubfx            x0, x0, #0xc, #0x14
    // 0x867424: SaveReg r1
    //     0x867424: str             x1, [SP, #-8]!
    // 0x867428: r0 = GDT[cid_x0 + -0xff1]()
    //     0x867428: sub             lr, x0, #0xff1
    //     0x86742c: ldr             lr, [x21, lr, lsl #3]
    //     0x867430: blr             lr
    // 0x867434: add             SP, SP, #8
    // 0x867438: mov             x3, x0
    // 0x86743c: b               #0x867444
    // 0x867440: mov             x3, x0
    // 0x867444: ldr             x1, [fp, #0x18]
    // 0x867448: ldur            x2, [fp, #-8]
    // 0x86744c: stur            x3, [fp, #-0x78]
    // 0x867450: LoadField: r0 = r1->field_b
    //     0x867450: ldur            w0, [x1, #0xb]
    // 0x867454: DecompressPointer r0
    //     0x867454: add             x0, x0, HEAP, lsl #32
    // 0x867458: cmp             w0, NULL
    // 0x86745c: b.eq            #0x867d5c
    // 0x867460: LoadField: r0 = r2->field_17
    //     0x867460: ldur            w0, [x2, #0x17]
    // 0x867464: DecompressPointer r0
    //     0x867464: add             x0, x0, HEAP, lsl #32
    // 0x867468: r4 = LoadClassIdInstr(r0)
    //     0x867468: ldur            x4, [x0, #-1]
    //     0x86746c: ubfx            x4, x4, #0xc, #0x14
    // 0x867470: SaveReg r0
    //     0x867470: str             x0, [SP, #-8]!
    // 0x867474: mov             x0, x4
    // 0x867478: r0 = GDT[cid_x0 + -0xfee]()
    //     0x867478: sub             lr, x0, #0xfee
    //     0x86747c: ldr             lr, [x21, lr, lsl #3]
    //     0x867480: blr             lr
    // 0x867484: add             SP, SP, #8
    // 0x867488: cmp             w0, NULL
    // 0x86748c: b.ne            #0x8674b8
    // 0x867490: ldur            x1, [fp, #-0x18]
    // 0x867494: r0 = LoadClassIdInstr(r1)
    //     0x867494: ldur            x0, [x1, #-1]
    //     0x867498: ubfx            x0, x0, #0xc, #0x14
    // 0x86749c: SaveReg r1
    //     0x86749c: str             x1, [SP, #-8]!
    // 0x8674a0: r0 = GDT[cid_x0 + -0xfee]()
    //     0x8674a0: sub             lr, x0, #0xfee
    //     0x8674a4: ldr             lr, [x21, lr, lsl #3]
    //     0x8674a8: blr             lr
    // 0x8674ac: add             SP, SP, #8
    // 0x8674b0: mov             x3, x0
    // 0x8674b4: b               #0x8674bc
    // 0x8674b8: mov             x3, x0
    // 0x8674bc: ldr             x1, [fp, #0x18]
    // 0x8674c0: ldur            x2, [fp, #-8]
    // 0x8674c4: stur            x3, [fp, #-0x80]
    // 0x8674c8: LoadField: r0 = r1->field_b
    //     0x8674c8: ldur            w0, [x1, #0xb]
    // 0x8674cc: DecompressPointer r0
    //     0x8674cc: add             x0, x0, HEAP, lsl #32
    // 0x8674d0: cmp             w0, NULL
    // 0x8674d4: b.eq            #0x867d60
    // 0x8674d8: LoadField: r0 = r2->field_17
    //     0x8674d8: ldur            w0, [x2, #0x17]
    // 0x8674dc: DecompressPointer r0
    //     0x8674dc: add             x0, x0, HEAP, lsl #32
    // 0x8674e0: r4 = LoadClassIdInstr(r0)
    //     0x8674e0: ldur            x4, [x0, #-1]
    //     0x8674e4: ubfx            x4, x4, #0xc, #0x14
    // 0x8674e8: SaveReg r0
    //     0x8674e8: str             x0, [SP, #-8]!
    // 0x8674ec: mov             x0, x4
    // 0x8674f0: r0 = GDT[cid_x0 + -0xfeb]()
    //     0x8674f0: sub             lr, x0, #0xfeb
    //     0x8674f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8674f8: blr             lr
    // 0x8674fc: add             SP, SP, #8
    // 0x867500: cmp             w0, NULL
    // 0x867504: b.ne            #0x867530
    // 0x867508: ldur            x1, [fp, #-0x18]
    // 0x86750c: r0 = LoadClassIdInstr(r1)
    //     0x86750c: ldur            x0, [x1, #-1]
    //     0x867510: ubfx            x0, x0, #0xc, #0x14
    // 0x867514: SaveReg r1
    //     0x867514: str             x1, [SP, #-8]!
    // 0x867518: r0 = GDT[cid_x0 + -0xfeb]()
    //     0x867518: sub             lr, x0, #0xfeb
    //     0x86751c: ldr             lr, [x21, lr, lsl #3]
    //     0x867520: blr             lr
    // 0x867524: add             SP, SP, #8
    // 0x867528: mov             x1, x0
    // 0x86752c: b               #0x867534
    // 0x867530: mov             x1, x0
    // 0x867534: ldur            x2, [fp, #-8]
    // 0x867538: stur            x1, [fp, #-0x88]
    // 0x86753c: LoadField: r0 = r2->field_17
    //     0x86753c: ldur            w0, [x2, #0x17]
    // 0x867540: DecompressPointer r0
    //     0x867540: add             x0, x0, HEAP, lsl #32
    // 0x867544: r3 = LoadClassIdInstr(r0)
    //     0x867544: ldur            x3, [x0, #-1]
    //     0x867548: ubfx            x3, x3, #0xc, #0x14
    // 0x86754c: SaveReg r0
    //     0x86754c: str             x0, [SP, #-8]!
    // 0x867550: mov             x0, x3
    // 0x867554: r0 = GDT[cid_x0 + -0xfe8]()
    //     0x867554: sub             lr, x0, #0xfe8
    //     0x867558: ldr             lr, [x21, lr, lsl #3]
    //     0x86755c: blr             lr
    // 0x867560: add             SP, SP, #8
    // 0x867564: cmp             w0, NULL
    // 0x867568: b.ne            #0x867594
    // 0x86756c: ldur            x1, [fp, #-0x18]
    // 0x867570: r0 = LoadClassIdInstr(r1)
    //     0x867570: ldur            x0, [x1, #-1]
    //     0x867574: ubfx            x0, x0, #0xc, #0x14
    // 0x867578: SaveReg r1
    //     0x867578: str             x1, [SP, #-8]!
    // 0x86757c: r0 = GDT[cid_x0 + -0xfe8]()
    //     0x86757c: sub             lr, x0, #0xfe8
    //     0x867580: ldr             lr, [x21, lr, lsl #3]
    //     0x867584: blr             lr
    // 0x867588: add             SP, SP, #8
    // 0x86758c: mov             x1, x0
    // 0x867590: b               #0x867598
    // 0x867594: mov             x1, x0
    // 0x867598: ldur            x2, [fp, #-8]
    // 0x86759c: stur            x1, [fp, #-0x90]
    // 0x8675a0: LoadField: r0 = r2->field_17
    //     0x8675a0: ldur            w0, [x2, #0x17]
    // 0x8675a4: DecompressPointer r0
    //     0x8675a4: add             x0, x0, HEAP, lsl #32
    // 0x8675a8: r3 = LoadClassIdInstr(r0)
    //     0x8675a8: ldur            x3, [x0, #-1]
    //     0x8675ac: ubfx            x3, x3, #0xc, #0x14
    // 0x8675b0: SaveReg r0
    //     0x8675b0: str             x0, [SP, #-8]!
    // 0x8675b4: mov             x0, x3
    // 0x8675b8: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x8675b8: sub             lr, x0, #0xfe5
    //     0x8675bc: ldr             lr, [x21, lr, lsl #3]
    //     0x8675c0: blr             lr
    // 0x8675c4: add             SP, SP, #8
    // 0x8675c8: cmp             w0, NULL
    // 0x8675cc: b.ne            #0x8675f8
    // 0x8675d0: ldur            x1, [fp, #-0x18]
    // 0x8675d4: r0 = LoadClassIdInstr(r1)
    //     0x8675d4: ldur            x0, [x1, #-1]
    //     0x8675d8: ubfx            x0, x0, #0xc, #0x14
    // 0x8675dc: SaveReg r1
    //     0x8675dc: str             x1, [SP, #-8]!
    // 0x8675e0: r0 = GDT[cid_x0 + -0xfe5]()
    //     0x8675e0: sub             lr, x0, #0xfe5
    //     0x8675e4: ldr             lr, [x21, lr, lsl #3]
    //     0x8675e8: blr             lr
    // 0x8675ec: add             SP, SP, #8
    // 0x8675f0: mov             x3, x0
    // 0x8675f4: b               #0x8675fc
    // 0x8675f8: mov             x3, x0
    // 0x8675fc: ldr             x1, [fp, #0x18]
    // 0x867600: ldur            x2, [fp, #-8]
    // 0x867604: stur            x3, [fp, #-0x98]
    // 0x867608: LoadField: r0 = r1->field_b
    //     0x867608: ldur            w0, [x1, #0xb]
    // 0x86760c: DecompressPointer r0
    //     0x86760c: add             x0, x0, HEAP, lsl #32
    // 0x867610: cmp             w0, NULL
    // 0x867614: b.eq            #0x867d64
    // 0x867618: LoadField: r0 = r2->field_17
    //     0x867618: ldur            w0, [x2, #0x17]
    // 0x86761c: DecompressPointer r0
    //     0x86761c: add             x0, x0, HEAP, lsl #32
    // 0x867620: r4 = LoadClassIdInstr(r0)
    //     0x867620: ldur            x4, [x0, #-1]
    //     0x867624: ubfx            x4, x4, #0xc, #0x14
    // 0x867628: SaveReg r0
    //     0x867628: str             x0, [SP, #-8]!
    // 0x86762c: mov             x0, x4
    // 0x867630: r0 = GDT[cid_x0 + -0xfe2]()
    //     0x867630: sub             lr, x0, #0xfe2
    //     0x867634: ldr             lr, [x21, lr, lsl #3]
    //     0x867638: blr             lr
    // 0x86763c: add             SP, SP, #8
    // 0x867640: cmp             w0, NULL
    // 0x867644: b.ne            #0x867670
    // 0x867648: ldur            x1, [fp, #-0x18]
    // 0x86764c: r0 = LoadClassIdInstr(r1)
    //     0x86764c: ldur            x0, [x1, #-1]
    //     0x867650: ubfx            x0, x0, #0xc, #0x14
    // 0x867654: SaveReg r1
    //     0x867654: str             x1, [SP, #-8]!
    // 0x867658: r0 = GDT[cid_x0 + -0xfe2]()
    //     0x867658: sub             lr, x0, #0xfe2
    //     0x86765c: ldr             lr, [x21, lr, lsl #3]
    //     0x867660: blr             lr
    // 0x867664: add             SP, SP, #8
    // 0x867668: mov             x1, x0
    // 0x86766c: b               #0x867674
    // 0x867670: mov             x1, x0
    // 0x867674: ldur            x2, [fp, #-8]
    // 0x867678: stur            x1, [fp, #-0xa0]
    // 0x86767c: LoadField: r0 = r2->field_17
    //     0x86767c: ldur            w0, [x2, #0x17]
    // 0x867680: DecompressPointer r0
    //     0x867680: add             x0, x0, HEAP, lsl #32
    // 0x867684: r3 = LoadClassIdInstr(r0)
    //     0x867684: ldur            x3, [x0, #-1]
    //     0x867688: ubfx            x3, x3, #0xc, #0x14
    // 0x86768c: SaveReg r0
    //     0x86768c: str             x0, [SP, #-8]!
    // 0x867690: mov             x0, x3
    // 0x867694: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x867694: sub             lr, x0, #0xfdf
    //     0x867698: ldr             lr, [x21, lr, lsl #3]
    //     0x86769c: blr             lr
    // 0x8676a0: add             SP, SP, #8
    // 0x8676a4: cmp             w0, NULL
    // 0x8676a8: b.ne            #0x8676d4
    // 0x8676ac: ldur            x1, [fp, #-0x18]
    // 0x8676b0: r0 = LoadClassIdInstr(r1)
    //     0x8676b0: ldur            x0, [x1, #-1]
    //     0x8676b4: ubfx            x0, x0, #0xc, #0x14
    // 0x8676b8: SaveReg r1
    //     0x8676b8: str             x1, [SP, #-8]!
    // 0x8676bc: r0 = GDT[cid_x0 + -0xfdf]()
    //     0x8676bc: sub             lr, x0, #0xfdf
    //     0x8676c0: ldr             lr, [x21, lr, lsl #3]
    //     0x8676c4: blr             lr
    // 0x8676c8: add             SP, SP, #8
    // 0x8676cc: mov             x1, x0
    // 0x8676d0: b               #0x8676d8
    // 0x8676d4: mov             x1, x0
    // 0x8676d8: ldur            x2, [fp, #-8]
    // 0x8676dc: stur            x1, [fp, #-0xa8]
    // 0x8676e0: ldur            x16, [fp, #-0x48]
    // 0x8676e4: SaveReg r16
    //     0x8676e4: str             x16, [SP, #-8]!
    // 0x8676e8: ldur            x0, [fp, #-0x48]
    // 0x8676ec: ClosureCall
    //     0x8676ec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x8676f0: ldur            x2, [x0, #0x1f]
    //     0x8676f4: blr             x2
    // 0x8676f8: add             SP, SP, #8
    // 0x8676fc: mov             x1, x0
    // 0x867700: ldur            x2, [fp, #-8]
    // 0x867704: stur            x1, [fp, #-0x48]
    // 0x867708: LoadField: r0 = r2->field_17
    //     0x867708: ldur            w0, [x2, #0x17]
    // 0x86770c: DecompressPointer r0
    //     0x86770c: add             x0, x0, HEAP, lsl #32
    // 0x867710: r3 = LoadClassIdInstr(r0)
    //     0x867710: ldur            x3, [x0, #-1]
    //     0x867714: ubfx            x3, x3, #0xc, #0x14
    // 0x867718: SaveReg r0
    //     0x867718: str             x0, [SP, #-8]!
    // 0x86771c: mov             x0, x3
    // 0x867720: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x867720: sub             lr, x0, #0xfd9
    //     0x867724: ldr             lr, [x21, lr, lsl #3]
    //     0x867728: blr             lr
    // 0x86772c: add             SP, SP, #8
    // 0x867730: cmp             w0, NULL
    // 0x867734: b.ne            #0x867764
    // 0x867738: ldur            x0, [fp, #-0x18]
    // 0x86773c: r1 = LoadClassIdInstr(r0)
    //     0x86773c: ldur            x1, [x0, #-1]
    //     0x867740: ubfx            x1, x1, #0xc, #0x14
    // 0x867744: SaveReg r0
    //     0x867744: str             x0, [SP, #-8]!
    // 0x867748: mov             x0, x1
    // 0x86774c: r0 = GDT[cid_x0 + -0xfd9]()
    //     0x86774c: sub             lr, x0, #0xfd9
    //     0x867750: ldr             lr, [x21, lr, lsl #3]
    //     0x867754: blr             lr
    // 0x867758: add             SP, SP, #8
    // 0x86775c: mov             x3, x0
    // 0x867760: b               #0x867768
    // 0x867764: mov             x3, x0
    // 0x867768: ldr             x0, [fp, #0x18]
    // 0x86776c: ldur            x2, [fp, #-8]
    // 0x867770: ldur            x1, [fp, #-0x10]
    // 0x867774: ldur            d0, [fp, #-0xb0]
    // 0x867778: r4 = inline_Allocate_Double()
    //     0x867778: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x86777c: add             x4, x4, #0x10
    //     0x867780: cmp             x5, x4
    //     0x867784: b.ls            #0x867d68
    //     0x867788: str             x4, [THR, #0x60]  ; THR::top
    //     0x86778c: sub             x4, x4, #0xf
    //     0x867790: mov             x5, #0xd108
    //     0x867794: movk            x5, #3, lsl #16
    //     0x867798: stur            x5, [x4, #-1]
    // 0x86779c: StoreField: r4->field_7 = d0
    //     0x86779c: stur            d0, [x4, #7]
    // 0x8677a0: ldur            x16, [fp, #-0x40]
    // 0x8677a4: ldur            lr, [fp, #-0x80]
    // 0x8677a8: stp             lr, x16, [SP, #-0x10]!
    // 0x8677ac: ldur            x16, [fp, #-0x50]
    // 0x8677b0: ldur            lr, [fp, #-0x90]
    // 0x8677b4: stp             lr, x16, [SP, #-0x10]!
    // 0x8677b8: ldur            x16, [fp, #-0x68]
    // 0x8677bc: ldur            lr, [fp, #-0x98]
    // 0x8677c0: stp             lr, x16, [SP, #-0x10]!
    // 0x8677c4: ldur            x16, [fp, #-0x70]
    // 0x8677c8: ldur            lr, [fp, #-0x78]
    // 0x8677cc: stp             lr, x16, [SP, #-0x10]!
    // 0x8677d0: ldur            x16, [fp, #-0xa8]
    // 0x8677d4: ldur            lr, [fp, #-0x88]
    // 0x8677d8: stp             lr, x16, [SP, #-0x10]!
    // 0x8677dc: ldur            x16, [fp, #-0x58]
    // 0x8677e0: ldur            lr, [fp, #-0x48]
    // 0x8677e4: stp             lr, x16, [SP, #-0x10]!
    // 0x8677e8: ldur            x16, [fp, #-0x60]
    // 0x8677ec: ldur            lr, [fp, #-0xa0]
    // 0x8677f0: stp             lr, x16, [SP, #-0x10]!
    // 0x8677f4: ldur            x16, [fp, #-0x28]
    // 0x8677f8: stp             x16, x4, [SP, #-0x10]!
    // 0x8677fc: ldur            x16, [fp, #-0x30]
    // 0x867800: stp             x3, x16, [SP, #-0x10]!
    // 0x867804: r0 = copyWith()
    //     0x867804: bl              #0x867ef0  ; [package:flutter/src/material/slider_theme.dart] SliderThemeData::copyWith
    // 0x867808: add             SP, SP, #0x90
    // 0x86780c: ldur            x2, [fp, #-8]
    // 0x867810: StoreField: r2->field_17 = r0
    //     0x867810: stur            w0, [x2, #0x17]
    //     0x867814: ldurb           w16, [x2, #-1]
    //     0x867818: ldurb           w17, [x0, #-1]
    //     0x86781c: and             x16, x17, x16, lsr #2
    //     0x867820: tst             x16, HEAP, lsr #32
    //     0x867824: b.eq            #0x86782c
    //     0x867828: bl              #0xd6828c
    // 0x86782c: ldr             x0, [fp, #0x18]
    // 0x867830: LoadField: r1 = r0->field_b
    //     0x867830: ldur            w1, [x0, #0xb]
    // 0x867834: DecompressPointer r1
    //     0x867834: add             x1, x1, HEAP, lsl #32
    // 0x867838: cmp             w1, NULL
    // 0x86783c: b.eq            #0x867d8c
    // 0x867840: r16 = <MouseCursor?>
    //     0x867840: add             x16, PP, #0x26, lsl #12  ; [pp+0x268b8] TypeArguments: <MouseCursor?>
    //     0x867844: ldr             x16, [x16, #0x8b8]
    // 0x867848: stp             NULL, x16, [SP, #-0x10]!
    // 0x86784c: ldur            x16, [fp, #-0x38]
    // 0x867850: SaveReg r16
    //     0x867850: str             x16, [SP, #-8]!
    // 0x867854: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x867854: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x867858: r0 = resolveAs()
    //     0x867858: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x86785c: add             SP, SP, #0x18
    // 0x867860: r16 = Instance__EnabledAndDisabledMouseCursor
    //     0x867860: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e208] Obj!_EnabledAndDisabledMouseCursor@b489f1
    //     0x867864: ldr             x16, [x16, #0x208]
    // 0x867868: ldur            lr, [fp, #-0x38]
    // 0x86786c: stp             lr, x16, [SP, #-0x10]!
    // 0x867870: r0 = resolve()
    //     0x867870: bl              #0x5a6cbc  ; [package:flutter/src/material/material_state.dart] _EnabledAndDisabledMouseCursor::resolve
    // 0x867874: add             SP, SP, #0x10
    // 0x867878: mov             x3, x0
    // 0x86787c: ldur            x0, [fp, #-0x10]
    // 0x867880: stur            x3, [fp, #-0x18]
    // 0x867884: LoadField: r1 = r0->field_1f
    //     0x867884: ldur            w1, [x0, #0x1f]
    // 0x867888: DecompressPointer r1
    //     0x867888: add             x1, x1, HEAP, lsl #32
    // 0x86788c: LoadField: r0 = r1->field_7
    //     0x86788c: ldur            x0, [x1, #7]
    // 0x867890: cmp             x0, #2
    // 0x867894: b.le            #0x8678a0
    // 0x867898: cmp             x0, #4
    // 0x86789c: b.gt            #0x8678a8
    // 0x8678a0: r1 = Null
    //     0x8678a0: mov             x1, NULL
    // 0x8678a4: b               #0x8678bc
    // 0x8678a8: ldur            x2, [fp, #-8]
    // 0x8678ac: r1 = Function '<anonymous closure>':.
    //     0x8678ac: add             x1, PP, #0x55, lsl #12  ; [pp+0x55788] AnonymousClosure: (0x8686dc), in [package:flutter/src/material/slider.dart] _SliderState::_buildMaterialSlider (0x866d60)
    //     0x8678b0: ldr             x1, [x1, #0x788]
    // 0x8678b4: r0 = AllocateClosure()
    //     0x8678b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8678b8: mov             x1, x0
    // 0x8678bc: ldur            x0, [fp, #-8]
    // 0x8678c0: stur            x1, [fp, #-0x10]
    // 0x8678c4: LoadField: r2 = r0->field_13
    //     0x8678c4: ldur            w2, [x0, #0x13]
    // 0x8678c8: DecompressPointer r2
    //     0x8678c8: add             x2, x2, HEAP, lsl #32
    // 0x8678cc: SaveReg r2
    //     0x8678cc: str             x2, [SP, #-8]!
    // 0x8678d0: r0 = of()
    //     0x8678d0: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x8678d4: add             SP, SP, #8
    // 0x8678d8: LoadField: r1 = r0->field_47
    //     0x8678d8: ldur            w1, [x0, #0x47]
    // 0x8678dc: DecompressPointer r1
    //     0x8678dc: add             x1, x1, HEAP, lsl #32
    // 0x8678e0: LoadField: r0 = r1->field_7
    //     0x8678e0: ldur            x0, [x1, #7]
    // 0x8678e4: cmp             x0, #0
    // 0x8678e8: b.gt            #0x8678f8
    // 0x8678ec: r1 = _ConstMap len:4
    //     0x8678ec: add             x1, PP, #0x55, lsl #12  ; [pp+0x55790] Map<ShortcutActivator, Intent>(4)
    //     0x8678f0: ldr             x1, [x1, #0x790]
    // 0x8678f4: b               #0x867900
    // 0x8678f8: r1 = _ConstMap len:2
    //     0x8678f8: add             x1, PP, #0x55, lsl #12  ; [pp+0x55798] Map<ShortcutActivator, Intent>(2)
    //     0x8678fc: ldr             x1, [x1, #0x798]
    // 0x867900: ldur            x0, [fp, #-0x20]
    // 0x867904: stur            x1, [fp, #-0x28]
    // 0x867908: tbnz            w0, #4, #0x8679b8
    // 0x86790c: ldur            x0, [fp, #-8]
    // 0x867910: LoadField: r2 = r0->field_13
    //     0x867910: ldur            w2, [x0, #0x13]
    // 0x867914: DecompressPointer r2
    //     0x867914: add             x2, x2, HEAP, lsl #32
    // 0x867918: SaveReg r2
    //     0x867918: str             x2, [SP, #-8]!
    // 0x86791c: r0 = of()
    //     0x86791c: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x867920: add             SP, SP, #8
    // 0x867924: LoadField: d0 = r0->field_13
    //     0x867924: ldur            d0, [x0, #0x13]
    // 0x867928: stur            d0, [fp, #-0xb0]
    // 0x86792c: d1 = 1.300000
    //     0x86792c: add             x17, PP, #0x41, lsl #12  ; [pp+0x41fc0] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0x867930: ldr             d1, [x17, #0xfc0]
    // 0x867934: fcmp            d0, d1
    // 0x867938: b.vs            #0x86794c
    // 0x86793c: b.le            #0x86794c
    // 0x867940: d0 = 1.300000
    //     0x867940: add             x17, PP, #0x41, lsl #12  ; [pp+0x41fc0] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0x867944: ldr             d0, [x17, #0xfc0]
    // 0x867948: b               #0x8679d4
    // 0x86794c: fcmp            d0, d1
    // 0x867950: b.vs            #0x867958
    // 0x867954: b.lt            #0x8679d4
    // 0x867958: d2 = 0.000000
    //     0x867958: eor             v2.16b, v2.16b, v2.16b
    // 0x86795c: fcmp            d0, d2
    // 0x867960: b.vs            #0x867968
    // 0x867964: b.eq            #0x867970
    // 0x867968: r0 = false
    //     0x867968: add             x0, NULL, #0x30  ; false
    // 0x86796c: b               #0x867974
    // 0x867970: r0 = true
    //     0x867970: add             x0, NULL, #0x20  ; true
    // 0x867974: tbnz            w0, #4, #0x867988
    // 0x867978: fadd            d2, d0, d1
    // 0x86797c: fmul            d3, d2, d0
    // 0x867980: fmul            d0, d3, d1
    // 0x867984: b               #0x8679d4
    // 0x867988: tbnz            w0, #4, #0x8679b0
    // 0x86798c: r16 = 1.300000
    //     0x86798c: add             x16, PP, #0x55, lsl #12  ; [pp+0x557a0] 1.3
    //     0x867990: ldr             x16, [x16, #0x7a0]
    // 0x867994: SaveReg r16
    //     0x867994: str             x16, [SP, #-8]!
    // 0x867998: r0 = isNegative()
    //     0x867998: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x86799c: add             SP, SP, #8
    // 0x8679a0: tbnz            w0, #4, #0x8679b0
    // 0x8679a4: d0 = 1.300000
    //     0x8679a4: add             x17, PP, #0x41, lsl #12  ; [pp+0x41fc0] IMM: double(1.3) from 0x3ff4cccccccccccd
    //     0x8679a8: ldr             d0, [x17, #0xfc0]
    // 0x8679ac: b               #0x8679d4
    // 0x8679b0: ldur            d0, [fp, #-0xb0]
    // 0x8679b4: b               #0x8679d4
    // 0x8679b8: ldur            x0, [fp, #-8]
    // 0x8679bc: LoadField: r1 = r0->field_13
    //     0x8679bc: ldur            w1, [x0, #0x13]
    // 0x8679c0: DecompressPointer r1
    //     0x8679c0: add             x1, x1, HEAP, lsl #32
    // 0x8679c4: SaveReg r1
    //     0x8679c4: str             x1, [SP, #-8]!
    // 0x8679c8: r0 = of()
    //     0x8679c8: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x8679cc: add             SP, SP, #8
    // 0x8679d0: LoadField: d0 = r0->field_13
    //     0x8679d0: ldur            d0, [x0, #0x13]
    // 0x8679d4: ldr             x1, [fp, #0x18]
    // 0x8679d8: ldur            x0, [fp, #-8]
    // 0x8679dc: stur            d0, [fp, #-0xb0]
    // 0x8679e0: LoadField: r2 = r1->field_33
    //     0x8679e0: ldur            w2, [x1, #0x33]
    // 0x8679e4: DecompressPointer r2
    //     0x8679e4: add             x2, x2, HEAP, lsl #32
    // 0x8679e8: r16 = Sentinel
    //     0x8679e8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8679ec: cmp             w2, w16
    // 0x8679f0: b.eq            #0x867d90
    // 0x8679f4: stur            x2, [fp, #-0x20]
    // 0x8679f8: SaveReg r1
    //     0x8679f8: str             x1, [SP, #-8]!
    // 0x8679fc: r0 = focusNode()
    //     0x8679fc: bl              #0x867eb0  ; [package:flutter/src/material/slider.dart] _SliderState::focusNode
    // 0x867a00: add             SP, SP, #8
    // 0x867a04: mov             x1, x0
    // 0x867a08: ldr             x0, [fp, #0x18]
    // 0x867a0c: stur            x1, [fp, #-0x30]
    // 0x867a10: LoadField: r2 = r0->field_b
    //     0x867a10: ldur            w2, [x0, #0xb]
    // 0x867a14: DecompressPointer r2
    //     0x867a14: add             x2, x2, HEAP, lsl #32
    // 0x867a18: cmp             w2, NULL
    // 0x867a1c: b.eq            #0x867d9c
    // 0x867a20: SaveReg r0
    //     0x867a20: str             x0, [SP, #-8]!
    // 0x867a24: r0 = _enabled()
    //     0x867a24: bl              #0x867e6c  ; [package:flutter/src/material/slider.dart] _SliderState::_enabled
    // 0x867a28: add             SP, SP, #8
    // 0x867a2c: stur            x0, [fp, #-0x38]
    // 0x867a30: r1 = 1
    //     0x867a30: mov             x1, #1
    // 0x867a34: r0 = AllocateContext()
    //     0x867a34: bl              #0xd68aa4  ; AllocateContextStub
    // 0x867a38: mov             x1, x0
    // 0x867a3c: ldr             x0, [fp, #0x18]
    // 0x867a40: stur            x1, [fp, #-0x40]
    // 0x867a44: StoreField: r1->field_f = r0
    //     0x867a44: stur            w0, [x1, #0xf]
    // 0x867a48: r1 = 1
    //     0x867a48: mov             x1, #1
    // 0x867a4c: r0 = AllocateContext()
    //     0x867a4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x867a50: mov             x1, x0
    // 0x867a54: ldr             x0, [fp, #0x18]
    // 0x867a58: stur            x1, [fp, #-0x58]
    // 0x867a5c: StoreField: r1->field_f = r0
    //     0x867a5c: stur            w0, [x1, #0xf]
    // 0x867a60: LoadField: r2 = r0->field_4b
    //     0x867a60: ldur            w2, [x0, #0x4b]
    // 0x867a64: DecompressPointer r2
    //     0x867a64: add             x2, x2, HEAP, lsl #32
    // 0x867a68: stur            x2, [fp, #-0x50]
    // 0x867a6c: LoadField: r3 = r0->field_2f
    //     0x867a6c: ldur            w3, [x0, #0x2f]
    // 0x867a70: DecompressPointer r3
    //     0x867a70: add             x3, x3, HEAP, lsl #32
    // 0x867a74: stur            x3, [fp, #-0x48]
    // 0x867a78: LoadField: r4 = r0->field_b
    //     0x867a78: ldur            w4, [x0, #0xb]
    // 0x867a7c: DecompressPointer r4
    //     0x867a7c: add             x4, x4, HEAP, lsl #32
    // 0x867a80: cmp             w4, NULL
    // 0x867a84: b.eq            #0x867da0
    // 0x867a88: LoadField: d0 = r4->field_b
    //     0x867a88: ldur            d0, [x4, #0xb]
    // 0x867a8c: SaveReg r0
    //     0x867a8c: str             x0, [SP, #-8]!
    // 0x867a90: SaveReg d0
    //     0x867a90: str             d0, [SP, #-8]!
    // 0x867a94: r0 = _convert()
    //     0x867a94: bl              #0x867db8  ; [package:flutter/src/material/slider.dart] _SliderState::_convert
    // 0x867a98: add             SP, SP, #0x10
    // 0x867a9c: ldr             x0, [fp, #0x18]
    // 0x867aa0: stur            d0, [fp, #-0xb8]
    // 0x867aa4: LoadField: r1 = r0->field_b
    //     0x867aa4: ldur            w1, [x0, #0xb]
    // 0x867aa8: DecompressPointer r1
    //     0x867aa8: add             x1, x1, HEAP, lsl #32
    // 0x867aac: cmp             w1, NULL
    // 0x867ab0: b.eq            #0x867da4
    // 0x867ab4: ldur            x1, [fp, #-8]
    // 0x867ab8: LoadField: r2 = r1->field_17
    //     0x867ab8: ldur            w2, [x1, #0x17]
    // 0x867abc: DecompressPointer r2
    //     0x867abc: add             x2, x2, HEAP, lsl #32
    // 0x867ac0: stur            x2, [fp, #-0x60]
    // 0x867ac4: LoadField: r3 = r1->field_13
    //     0x867ac4: ldur            w3, [x1, #0x13]
    // 0x867ac8: DecompressPointer r3
    //     0x867ac8: add             x3, x3, HEAP, lsl #32
    // 0x867acc: SaveReg r3
    //     0x867acc: str             x3, [SP, #-8]!
    // 0x867ad0: r0 = of()
    //     0x867ad0: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x867ad4: add             SP, SP, #8
    // 0x867ad8: LoadField: r1 = r0->field_7
    //     0x867ad8: ldur            w1, [x0, #7]
    // 0x867adc: DecompressPointer r1
    //     0x867adc: add             x1, x1, HEAP, lsl #32
    // 0x867ae0: ldr             x0, [fp, #0x18]
    // 0x867ae4: stur            x1, [fp, #-8]
    // 0x867ae8: LoadField: r2 = r0->field_b
    //     0x867ae8: ldur            w2, [x0, #0xb]
    // 0x867aec: DecompressPointer r2
    //     0x867aec: add             x2, x2, HEAP, lsl #32
    // 0x867af0: cmp             w2, NULL
    // 0x867af4: b.eq            #0x867da8
    // 0x867af8: LoadField: r3 = r2->field_17
    //     0x867af8: ldur            w3, [x2, #0x17]
    // 0x867afc: DecompressPointer r3
    //     0x867afc: add             x3, x3, HEAP, lsl #32
    // 0x867b00: cmp             w3, NULL
    // 0x867b04: b.eq            #0x867b48
    // 0x867b08: LoadField: d0 = r2->field_2b
    //     0x867b08: ldur            d0, [x2, #0x2b]
    // 0x867b0c: LoadField: d1 = r2->field_23
    //     0x867b0c: ldur            d1, [x2, #0x23]
    // 0x867b10: fcmp            d0, d1
    // 0x867b14: b.vs            #0x867b48
    // 0x867b18: b.le            #0x867b48
    // 0x867b1c: r1 = 1
    //     0x867b1c: mov             x1, #1
    // 0x867b20: r0 = AllocateContext()
    //     0x867b20: bl              #0xd68aa4  ; AllocateContextStub
    // 0x867b24: mov             x1, x0
    // 0x867b28: ldr             x0, [fp, #0x18]
    // 0x867b2c: StoreField: r1->field_f = r0
    //     0x867b2c: stur            w0, [x1, #0xf]
    // 0x867b30: mov             x2, x1
    // 0x867b34: r1 = Function '_handleChanged@810231897':.
    //     0x867b34: add             x1, PP, #0x55, lsl #12  ; [pp+0x557a8] AnonymousClosure: (0x868510), in [package:flutter/src/material/slider.dart] _SliderState::_handleChanged (0x86855c)
    //     0x867b38: ldr             x1, [x1, #0x7a8]
    // 0x867b3c: r0 = AllocateClosure()
    //     0x867b3c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x867b40: mov             x10, x0
    // 0x867b44: b               #0x867b4c
    // 0x867b48: r10 = Null
    //     0x867b48: mov             x10, NULL
    // 0x867b4c: ldr             x0, [fp, #0x18]
    // 0x867b50: ldur            x9, [fp, #-0x18]
    // 0x867b54: ldur            x8, [fp, #-0x28]
    // 0x867b58: ldur            d1, [fp, #-0xb0]
    // 0x867b5c: ldur            x6, [fp, #-0x30]
    // 0x867b60: ldur            x5, [fp, #-0x38]
    // 0x867b64: ldur            x3, [fp, #-0x50]
    // 0x867b68: ldur            x4, [fp, #-0x48]
    // 0x867b6c: ldur            d0, [fp, #-0xb8]
    // 0x867b70: ldur            x2, [fp, #-0x60]
    // 0x867b74: ldur            x7, [fp, #-0x20]
    // 0x867b78: ldur            x1, [fp, #-8]
    // 0x867b7c: stur            x10, [fp, #-0x68]
    // 0x867b80: r1 = 1
    //     0x867b80: mov             x1, #1
    // 0x867b84: r0 = AllocateContext()
    //     0x867b84: bl              #0xd68aa4  ; AllocateContextStub
    // 0x867b88: mov             x1, x0
    // 0x867b8c: ldr             x0, [fp, #0x18]
    // 0x867b90: stur            x1, [fp, #-0x70]
    // 0x867b94: StoreField: r1->field_f = r0
    //     0x867b94: stur            w0, [x1, #0xf]
    // 0x867b98: r1 = 1
    //     0x867b98: mov             x1, #1
    // 0x867b9c: r0 = AllocateContext()
    //     0x867b9c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x867ba0: mov             x1, x0
    // 0x867ba4: ldr             x0, [fp, #0x18]
    // 0x867ba8: stur            x1, [fp, #-0x88]
    // 0x867bac: StoreField: r1->field_f = r0
    //     0x867bac: stur            w0, [x1, #0xf]
    // 0x867bb0: LoadField: r2 = r0->field_43
    //     0x867bb0: ldur            w2, [x0, #0x43]
    // 0x867bb4: DecompressPointer r2
    //     0x867bb4: add             x2, x2, HEAP, lsl #32
    // 0x867bb8: stur            x2, [fp, #-0x80]
    // 0x867bbc: LoadField: r3 = r0->field_47
    //     0x867bbc: ldur            w3, [x0, #0x47]
    // 0x867bc0: DecompressPointer r3
    //     0x867bc0: add             x3, x3, HEAP, lsl #32
    // 0x867bc4: stur            x3, [fp, #-0x78]
    // 0x867bc8: r0 = _SliderRenderObjectWidget()
    //     0x867bc8: bl              #0x867dac  ; Allocate_SliderRenderObjectWidgetStub -> _SliderRenderObjectWidget (size=0x4c)
    // 0x867bcc: ldur            d0, [fp, #-0xb8]
    // 0x867bd0: stur            x0, [fp, #-0x90]
    // 0x867bd4: StoreField: r0->field_b = d0
    //     0x867bd4: stur            d0, [x0, #0xb]
    // 0x867bd8: ldur            x1, [fp, #-0x60]
    // 0x867bdc: StoreField: r0->field_1f = r1
    //     0x867bdc: stur            w1, [x0, #0x1f]
    // 0x867be0: ldur            d0, [fp, #-0xb0]
    // 0x867be4: StoreField: r0->field_23 = d0
    //     0x867be4: stur            d0, [x0, #0x23]
    // 0x867be8: ldur            x1, [fp, #-8]
    // 0x867bec: StoreField: r0->field_2b = r1
    //     0x867bec: stur            w1, [x0, #0x2b]
    // 0x867bf0: ldur            x1, [fp, #-0x68]
    // 0x867bf4: StoreField: r0->field_2f = r1
    //     0x867bf4: stur            w1, [x0, #0x2f]
    // 0x867bf8: ldur            x2, [fp, #-0x70]
    // 0x867bfc: r1 = Function '_handleDragStart@810231897':.
    //     0x867bfc: add             x1, PP, #0x55, lsl #12  ; [pp+0x557b0] AnonymousClosure: (0x86848c), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart (0x8684d8)
    //     0x867c00: ldr             x1, [x1, #0x7b0]
    // 0x867c04: r0 = AllocateClosure()
    //     0x867c04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x867c08: mov             x1, x0
    // 0x867c0c: ldur            x0, [fp, #-0x90]
    // 0x867c10: StoreField: r0->field_33 = r1
    //     0x867c10: stur            w1, [x0, #0x33]
    // 0x867c14: ldur            x2, [fp, #-0x88]
    // 0x867c18: r1 = Function '_handleDragEnd@810231897':.
    //     0x867c18: add             x1, PP, #0x55, lsl #12  ; [pp+0x557b8] AnonymousClosure: (0x868408), in [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd (0x868454)
    //     0x867c1c: ldr             x1, [x1, #0x7b8]
    // 0x867c20: r0 = AllocateClosure()
    //     0x867c20: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x867c24: mov             x1, x0
    // 0x867c28: ldur            x0, [fp, #-0x90]
    // 0x867c2c: StoreField: r0->field_37 = r1
    //     0x867c2c: stur            w1, [x0, #0x37]
    // 0x867c30: ldr             x1, [fp, #0x18]
    // 0x867c34: StoreField: r0->field_3f = r1
    //     0x867c34: stur            w1, [x0, #0x3f]
    // 0x867c38: ldur            x1, [fp, #-0x80]
    // 0x867c3c: StoreField: r0->field_43 = r1
    //     0x867c3c: stur            w1, [x0, #0x43]
    // 0x867c40: ldur            x1, [fp, #-0x78]
    // 0x867c44: StoreField: r0->field_47 = r1
    //     0x867c44: stur            w1, [x0, #0x47]
    // 0x867c48: ldur            x1, [fp, #-0x48]
    // 0x867c4c: StoreField: r0->field_7 = r1
    //     0x867c4c: stur            w1, [x0, #7]
    // 0x867c50: r0 = CompositedTransformTarget()
    //     0x867c50: bl              #0x834c68  ; AllocateCompositedTransformTargetStub -> CompositedTransformTarget (size=0x14)
    // 0x867c54: mov             x1, x0
    // 0x867c58: ldur            x0, [fp, #-0x50]
    // 0x867c5c: stur            x1, [fp, #-8]
    // 0x867c60: StoreField: r1->field_f = r0
    //     0x867c60: stur            w0, [x1, #0xf]
    // 0x867c64: ldur            x0, [fp, #-0x90]
    // 0x867c68: StoreField: r1->field_b = r0
    //     0x867c68: stur            w0, [x1, #0xb]
    // 0x867c6c: r0 = FocusableActionDetector()
    //     0x867c6c: bl              #0x84f3c0  ; AllocateFocusableActionDetectorStub -> FocusableActionDetector (size=0x40)
    // 0x867c70: mov             x3, x0
    // 0x867c74: ldur            x0, [fp, #-0x38]
    // 0x867c78: stur            x3, [fp, #-0x48]
    // 0x867c7c: StoreField: r3->field_b = r0
    //     0x867c7c: stur            w0, [x3, #0xb]
    // 0x867c80: ldur            x0, [fp, #-0x30]
    // 0x867c84: StoreField: r3->field_f = r0
    //     0x867c84: stur            w0, [x3, #0xf]
    // 0x867c88: r0 = false
    //     0x867c88: add             x0, NULL, #0x30  ; false
    // 0x867c8c: StoreField: r3->field_13 = r0
    //     0x867c8c: stur            w0, [x3, #0x13]
    // 0x867c90: r0 = true
    //     0x867c90: add             x0, NULL, #0x20  ; true
    // 0x867c94: StoreField: r3->field_17 = r0
    //     0x867c94: stur            w0, [x3, #0x17]
    // 0x867c98: StoreField: r3->field_1b = r0
    //     0x867c98: stur            w0, [x3, #0x1b]
    // 0x867c9c: ldur            x1, [fp, #-0x28]
    // 0x867ca0: StoreField: r3->field_23 = r1
    //     0x867ca0: stur            w1, [x3, #0x23]
    // 0x867ca4: ldur            x1, [fp, #-0x20]
    // 0x867ca8: StoreField: r3->field_1f = r1
    //     0x867ca8: stur            w1, [x3, #0x1f]
    // 0x867cac: ldur            x2, [fp, #-0x40]
    // 0x867cb0: r1 = Function '_handleFocusHighlightChanged@810231897':.
    //     0x867cb0: add             x1, PP, #0x55, lsl #12  ; [pp+0x557c0] AnonymousClosure: (0x84f86c), in [package:flutter/src/material/slider.dart] _SliderState::_handleFocusHighlightChanged (0x84f7f4)
    //     0x867cb4: ldr             x1, [x1, #0x7c0]
    // 0x867cb8: r0 = AllocateClosure()
    //     0x867cb8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x867cbc: mov             x1, x0
    // 0x867cc0: ldur            x0, [fp, #-0x48]
    // 0x867cc4: StoreField: r0->field_27 = r1
    //     0x867cc4: stur            w1, [x0, #0x27]
    // 0x867cc8: ldur            x2, [fp, #-0x58]
    // 0x867ccc: r1 = Function '_handleHoverChanged@810231897':.
    //     0x867ccc: add             x1, PP, #0x55, lsl #12  ; [pp+0x557c8] AnonymousClosure: (0x868344), in [package:flutter/src/material/slider.dart] _SliderState::_handleHoverChanged (0x868390)
    //     0x867cd0: ldr             x1, [x1, #0x7c8]
    // 0x867cd4: r0 = AllocateClosure()
    //     0x867cd4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x867cd8: mov             x1, x0
    // 0x867cdc: ldur            x0, [fp, #-0x48]
    // 0x867ce0: StoreField: r0->field_2b = r1
    //     0x867ce0: stur            w1, [x0, #0x2b]
    // 0x867ce4: ldur            x1, [fp, #-0x18]
    // 0x867ce8: StoreField: r0->field_33 = r1
    //     0x867ce8: stur            w1, [x0, #0x33]
    // 0x867cec: r1 = true
    //     0x867cec: add             x1, NULL, #0x20  ; true
    // 0x867cf0: StoreField: r0->field_37 = r1
    //     0x867cf0: stur            w1, [x0, #0x37]
    // 0x867cf4: ldur            x1, [fp, #-8]
    // 0x867cf8: StoreField: r0->field_3b = r1
    //     0x867cf8: stur            w1, [x0, #0x3b]
    // 0x867cfc: r0 = Semantics()
    //     0x867cfc: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x867d00: stur            x0, [fp, #-8]
    // 0x867d04: r16 = true
    //     0x867d04: add             x16, NULL, #0x20  ; true
    // 0x867d08: stp             x16, x0, [SP, #-0x10]!
    // 0x867d0c: r16 = true
    //     0x867d0c: add             x16, NULL, #0x20  ; true
    // 0x867d10: ldur            lr, [fp, #-0x10]
    // 0x867d14: stp             lr, x16, [SP, #-0x10]!
    // 0x867d18: ldur            x16, [fp, #-0x48]
    // 0x867d1c: SaveReg r16
    //     0x867d1c: str             x16, [SP, #-8]!
    // 0x867d20: r4 = const [0, 0x5, 0x5, 0x1, child, 0x4, container, 0x1, onDidGainAccessibilityFocus, 0x3, slider, 0x2, null]
    //     0x867d20: add             x4, PP, #0x55, lsl #12  ; [pp+0x557d0] List(13) [0, 0x5, 0x5, 0x1, "child", 0x4, "container", 0x1, "onDidGainAccessibilityFocus", 0x3, "slider", 0x2, Null]
    //     0x867d24: ldr             x4, [x4, #0x7d0]
    // 0x867d28: r0 = Semantics()
    //     0x867d28: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x867d2c: add             SP, SP, #0x28
    // 0x867d30: ldur            x0, [fp, #-8]
    // 0x867d34: LeaveFrame
    //     0x867d34: mov             SP, fp
    //     0x867d38: ldp             fp, lr, [SP], #0x10
    // 0x867d3c: ret
    //     0x867d3c: ret             
    // 0x867d40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x867d40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x867d44: b               #0x866d78
    // 0x867d48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d50: r0 = NullCastErrorSharedWithFPURegs()
    //     0x867d50: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x867d54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d68: SaveReg d0
    //     0x867d68: str             q0, [SP, #-0x10]!
    // 0x867d6c: stp             x2, x3, [SP, #-0x10]!
    // 0x867d70: stp             x0, x1, [SP, #-0x10]!
    // 0x867d74: r0 = AllocateDouble()
    //     0x867d74: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x867d78: mov             x4, x0
    // 0x867d7c: ldp             x0, x1, [SP], #0x10
    // 0x867d80: ldp             x2, x3, [SP], #0x10
    // 0x867d84: RestoreReg d0
    //     0x867d84: ldr             q0, [SP], #0x10
    // 0x867d88: b               #0x86779c
    // 0x867d8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867d90: r9 = _actionMap
    //     0x867d90: add             x9, PP, #0x55, lsl #12  ; [pp+0x557d8] Field <_SliderState@810231897._actionMap@810231897>: late (offset: 0x34)
    //     0x867d94: ldr             x9, [x9, #0x7d8]
    // 0x867d98: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x867d98: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x867d9c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867d9c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867da0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867da0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867da4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x867da4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x867da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _convert(/* No info */) {
    // ** addr: 0x867db8, size: 0x58
    // 0x867db8: EnterFrame
    //     0x867db8: stp             fp, lr, [SP, #-0x10]!
    //     0x867dbc: mov             fp, SP
    // 0x867dc0: CheckStackOverflow
    //     0x867dc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x867dc4: cmp             SP, x16
    //     0x867dc8: b.ls            #0x867e04
    // 0x867dcc: ldr             x16, [fp, #0x18]
    // 0x867dd0: SaveReg r16
    //     0x867dd0: str             x16, [SP, #-8]!
    // 0x867dd4: ldr             d0, [fp, #0x10]
    // 0x867dd8: SaveReg d0
    //     0x867dd8: str             d0, [SP, #-8]!
    // 0x867ddc: r0 = _unlerp()
    //     0x867ddc: bl              #0x867e10  ; [package:flutter/src/material/slider.dart] _SliderState::_unlerp
    // 0x867de0: add             SP, SP, #0x10
    // 0x867de4: ldr             x0, [fp, #0x18]
    // 0x867de8: LoadField: r1 = r0->field_b
    //     0x867de8: ldur            w1, [x0, #0xb]
    // 0x867dec: DecompressPointer r1
    //     0x867dec: add             x1, x1, HEAP, lsl #32
    // 0x867df0: cmp             w1, NULL
    // 0x867df4: b.eq            #0x867e0c
    // 0x867df8: LeaveFrame
    //     0x867df8: mov             SP, fp
    //     0x867dfc: ldp             fp, lr, [SP], #0x10
    // 0x867e00: ret
    //     0x867e00: ret             
    // 0x867e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x867e04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x867e08: b               #0x867dcc
    // 0x867e0c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x867e0c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ _unlerp(/* No info */) {
    // ** addr: 0x867e10, size: 0x5c
    // 0x867e10: EnterFrame
    //     0x867e10: stp             fp, lr, [SP, #-0x10]!
    //     0x867e14: mov             fp, SP
    // 0x867e18: ldr             x0, [fp, #0x18]
    // 0x867e1c: LoadField: r1 = r0->field_b
    //     0x867e1c: ldur            w1, [x0, #0xb]
    // 0x867e20: DecompressPointer r1
    //     0x867e20: add             x1, x1, HEAP, lsl #32
    // 0x867e24: cmp             w1, NULL
    // 0x867e28: b.eq            #0x867e68
    // 0x867e2c: LoadField: d1 = r1->field_2b
    //     0x867e2c: ldur            d1, [x1, #0x2b]
    // 0x867e30: LoadField: d2 = r1->field_23
    //     0x867e30: ldur            d2, [x1, #0x23]
    // 0x867e34: fcmp            d1, d2
    // 0x867e38: b.vs            #0x867e58
    // 0x867e3c: b.le            #0x867e58
    // 0x867e40: ldr             d3, [fp, #0x10]
    // 0x867e44: fsub            d4, d3, d2
    // 0x867e48: fsub            d3, d1, d2
    // 0x867e4c: fdiv            d1, d4, d3
    // 0x867e50: mov             v0.16b, v1.16b
    // 0x867e54: b               #0x867e5c
    // 0x867e58: d0 = 0.000000
    //     0x867e58: eor             v0.16b, v0.16b, v0.16b
    // 0x867e5c: LeaveFrame
    //     0x867e5c: mov             SP, fp
    //     0x867e60: ldp             fp, lr, [SP], #0x10
    // 0x867e64: ret
    //     0x867e64: ret             
    // 0x867e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867e68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _enabled(/* No info */) {
    // ** addr: 0x867e6c, size: 0x44
    // 0x867e6c: EnterFrame
    //     0x867e6c: stp             fp, lr, [SP, #-0x10]!
    //     0x867e70: mov             fp, SP
    // 0x867e74: ldr             x1, [fp, #0x10]
    // 0x867e78: LoadField: r2 = r1->field_b
    //     0x867e78: ldur            w2, [x1, #0xb]
    // 0x867e7c: DecompressPointer r2
    //     0x867e7c: add             x2, x2, HEAP, lsl #32
    // 0x867e80: cmp             w2, NULL
    // 0x867e84: b.eq            #0x867eac
    // 0x867e88: LoadField: r1 = r2->field_17
    //     0x867e88: ldur            w1, [x2, #0x17]
    // 0x867e8c: DecompressPointer r1
    //     0x867e8c: add             x1, x1, HEAP, lsl #32
    // 0x867e90: cmp             w1, NULL
    // 0x867e94: r16 = true
    //     0x867e94: add             x16, NULL, #0x20  ; true
    // 0x867e98: r17 = false
    //     0x867e98: add             x17, NULL, #0x30  ; false
    // 0x867e9c: csel            x0, x16, x17, ne
    // 0x867ea0: LeaveFrame
    //     0x867ea0: mov             SP, fp
    //     0x867ea4: ldp             fp, lr, [SP], #0x10
    // 0x867ea8: ret
    //     0x867ea8: ret             
    // 0x867eac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867eac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ focusNode(/* No info */) {
    // ** addr: 0x867eb0, size: 0x40
    // 0x867eb0: EnterFrame
    //     0x867eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x867eb4: mov             fp, SP
    // 0x867eb8: ldr             x1, [fp, #0x10]
    // 0x867ebc: LoadField: r2 = r1->field_b
    //     0x867ebc: ldur            w2, [x1, #0xb]
    // 0x867ec0: DecompressPointer r2
    //     0x867ec0: add             x2, x2, HEAP, lsl #32
    // 0x867ec4: cmp             w2, NULL
    // 0x867ec8: b.eq            #0x867ee8
    // 0x867ecc: LoadField: r0 = r1->field_3f
    //     0x867ecc: ldur            w0, [x1, #0x3f]
    // 0x867ed0: DecompressPointer r0
    //     0x867ed0: add             x0, x0, HEAP, lsl #32
    // 0x867ed4: cmp             w0, NULL
    // 0x867ed8: b.eq            #0x867eec
    // 0x867edc: LeaveFrame
    //     0x867edc: mov             SP, fp
    //     0x867ee0: ldp             fp, lr, [SP], #0x10
    // 0x867ee4: ret
    //     0x867ee4: ret             
    // 0x867ee8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867ee8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x867eec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x867eec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleHoverChanged(dynamic, bool) {
    // ** addr: 0x868344, size: 0x4c
    // 0x868344: EnterFrame
    //     0x868344: stp             fp, lr, [SP, #-0x10]!
    //     0x868348: mov             fp, SP
    // 0x86834c: ldr             x0, [fp, #0x18]
    // 0x868350: LoadField: r1 = r0->field_17
    //     0x868350: ldur            w1, [x0, #0x17]
    // 0x868354: DecompressPointer r1
    //     0x868354: add             x1, x1, HEAP, lsl #32
    // 0x868358: CheckStackOverflow
    //     0x868358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86835c: cmp             SP, x16
    //     0x868360: b.ls            #0x868388
    // 0x868364: LoadField: r0 = r1->field_f
    //     0x868364: ldur            w0, [x1, #0xf]
    // 0x868368: DecompressPointer r0
    //     0x868368: add             x0, x0, HEAP, lsl #32
    // 0x86836c: ldr             x16, [fp, #0x10]
    // 0x868370: stp             x16, x0, [SP, #-0x10]!
    // 0x868374: r0 = _handleHoverChanged()
    //     0x868374: bl              #0x868390  ; [package:flutter/src/material/slider.dart] _SliderState::_handleHoverChanged
    // 0x868378: add             SP, SP, #0x10
    // 0x86837c: LeaveFrame
    //     0x86837c: mov             SP, fp
    //     0x868380: ldp             fp, lr, [SP], #0x10
    // 0x868384: ret
    //     0x868384: ret             
    // 0x868388: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x868388: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86838c: b               #0x868364
  }
  _ _handleHoverChanged(/* No info */) {
    // ** addr: 0x868390, size: 0x78
    // 0x868390: EnterFrame
    //     0x868390: stp             fp, lr, [SP, #-0x10]!
    //     0x868394: mov             fp, SP
    // 0x868398: CheckStackOverflow
    //     0x868398: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86839c: cmp             SP, x16
    //     0x8683a0: b.ls            #0x868400
    // 0x8683a4: r1 = 2
    //     0x8683a4: mov             x1, #2
    // 0x8683a8: r0 = AllocateContext()
    //     0x8683a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8683ac: mov             x1, x0
    // 0x8683b0: ldr             x0, [fp, #0x18]
    // 0x8683b4: StoreField: r1->field_f = r0
    //     0x8683b4: stur            w0, [x1, #0xf]
    // 0x8683b8: ldr             x2, [fp, #0x10]
    // 0x8683bc: StoreField: r1->field_13 = r2
    //     0x8683bc: stur            w2, [x1, #0x13]
    // 0x8683c0: LoadField: r3 = r0->field_47
    //     0x8683c0: ldur            w3, [x0, #0x47]
    // 0x8683c4: DecompressPointer r3
    //     0x8683c4: add             x3, x3, HEAP, lsl #32
    // 0x8683c8: cmp             w2, w3
    // 0x8683cc: b.eq            #0x8683f0
    // 0x8683d0: mov             x2, x1
    // 0x8683d4: r1 = Function '<anonymous closure>':.
    //     0x8683d4: add             x1, PP, #0x55, lsl #12  ; [pp+0x557e0] AnonymousClosure: (0x84f528), in [package:flutter/src/material/scaffold.dart] ScaffoldState::_updateSnackBar (0x84f570)
    //     0x8683d8: ldr             x1, [x1, #0x7e0]
    // 0x8683dc: r0 = AllocateClosure()
    //     0x8683dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8683e0: ldr             x16, [fp, #0x18]
    // 0x8683e4: stp             x0, x16, [SP, #-0x10]!
    // 0x8683e8: r0 = setState()
    //     0x8683e8: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x8683ec: add             SP, SP, #0x10
    // 0x8683f0: r0 = Null
    //     0x8683f0: mov             x0, NULL
    // 0x8683f4: LeaveFrame
    //     0x8683f4: mov             SP, fp
    //     0x8683f8: ldp             fp, lr, [SP], #0x10
    // 0x8683fc: ret
    //     0x8683fc: ret             
    // 0x868400: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x868400: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868404: b               #0x8683a4
  }
  [closure] void _handleDragEnd(dynamic, double) {
    // ** addr: 0x868408, size: 0x4c
    // 0x868408: EnterFrame
    //     0x868408: stp             fp, lr, [SP, #-0x10]!
    //     0x86840c: mov             fp, SP
    // 0x868410: ldr             x0, [fp, #0x18]
    // 0x868414: LoadField: r1 = r0->field_17
    //     0x868414: ldur            w1, [x0, #0x17]
    // 0x868418: DecompressPointer r1
    //     0x868418: add             x1, x1, HEAP, lsl #32
    // 0x86841c: CheckStackOverflow
    //     0x86841c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x868420: cmp             SP, x16
    //     0x868424: b.ls            #0x86844c
    // 0x868428: LoadField: r0 = r1->field_f
    //     0x868428: ldur            w0, [x1, #0xf]
    // 0x86842c: DecompressPointer r0
    //     0x86842c: add             x0, x0, HEAP, lsl #32
    // 0x868430: ldr             x16, [fp, #0x10]
    // 0x868434: stp             x16, x0, [SP, #-0x10]!
    // 0x868438: r0 = _handleDragEnd()
    //     0x868438: bl              #0x868454  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragEnd
    // 0x86843c: add             SP, SP, #0x10
    // 0x868440: LeaveFrame
    //     0x868440: mov             SP, fp
    //     0x868444: ldp             fp, lr, [SP], #0x10
    // 0x868448: ret
    //     0x868448: ret             
    // 0x86844c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86844c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868450: b               #0x868428
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0x868454, size: 0x38
    // 0x868454: EnterFrame
    //     0x868454: stp             fp, lr, [SP, #-0x10]!
    //     0x868458: mov             fp, SP
    // 0x86845c: r1 = false
    //     0x86845c: add             x1, NULL, #0x30  ; false
    // 0x868460: ldr             x2, [fp, #0x18]
    // 0x868464: StoreField: r2->field_3b = r1
    //     0x868464: stur            w1, [x2, #0x3b]
    // 0x868468: LoadField: r1 = r2->field_b
    //     0x868468: ldur            w1, [x2, #0xb]
    // 0x86846c: DecompressPointer r1
    //     0x86846c: add             x1, x1, HEAP, lsl #32
    // 0x868470: cmp             w1, NULL
    // 0x868474: b.eq            #0x868488
    // 0x868478: r0 = Null
    //     0x868478: mov             x0, NULL
    // 0x86847c: LeaveFrame
    //     0x86847c: mov             SP, fp
    //     0x868480: ldp             fp, lr, [SP], #0x10
    // 0x868484: ret
    //     0x868484: ret             
    // 0x868488: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x868488: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragStart(dynamic, double) {
    // ** addr: 0x86848c, size: 0x4c
    // 0x86848c: EnterFrame
    //     0x86848c: stp             fp, lr, [SP, #-0x10]!
    //     0x868490: mov             fp, SP
    // 0x868494: ldr             x0, [fp, #0x18]
    // 0x868498: LoadField: r1 = r0->field_17
    //     0x868498: ldur            w1, [x0, #0x17]
    // 0x86849c: DecompressPointer r1
    //     0x86849c: add             x1, x1, HEAP, lsl #32
    // 0x8684a0: CheckStackOverflow
    //     0x8684a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8684a4: cmp             SP, x16
    //     0x8684a8: b.ls            #0x8684d0
    // 0x8684ac: LoadField: r0 = r1->field_f
    //     0x8684ac: ldur            w0, [x1, #0xf]
    // 0x8684b0: DecompressPointer r0
    //     0x8684b0: add             x0, x0, HEAP, lsl #32
    // 0x8684b4: ldr             x16, [fp, #0x10]
    // 0x8684b8: stp             x16, x0, [SP, #-0x10]!
    // 0x8684bc: r0 = _handleDragStart()
    //     0x8684bc: bl              #0x8684d8  ; [package:flutter/src/material/slider.dart] _SliderState::_handleDragStart
    // 0x8684c0: add             SP, SP, #0x10
    // 0x8684c4: LeaveFrame
    //     0x8684c4: mov             SP, fp
    //     0x8684c8: ldp             fp, lr, [SP], #0x10
    // 0x8684cc: ret
    //     0x8684cc: ret             
    // 0x8684d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8684d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8684d4: b               #0x8684ac
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0x8684d8, size: 0x38
    // 0x8684d8: EnterFrame
    //     0x8684d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8684dc: mov             fp, SP
    // 0x8684e0: r1 = true
    //     0x8684e0: add             x1, NULL, #0x20  ; true
    // 0x8684e4: ldr             x2, [fp, #0x18]
    // 0x8684e8: StoreField: r2->field_3b = r1
    //     0x8684e8: stur            w1, [x2, #0x3b]
    // 0x8684ec: LoadField: r1 = r2->field_b
    //     0x8684ec: ldur            w1, [x2, #0xb]
    // 0x8684f0: DecompressPointer r1
    //     0x8684f0: add             x1, x1, HEAP, lsl #32
    // 0x8684f4: cmp             w1, NULL
    // 0x8684f8: b.eq            #0x86850c
    // 0x8684fc: r0 = Null
    //     0x8684fc: mov             x0, NULL
    // 0x868500: LeaveFrame
    //     0x868500: mov             SP, fp
    //     0x868504: ldp             fp, lr, [SP], #0x10
    // 0x868508: ret
    //     0x868508: ret             
    // 0x86850c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x86850c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleChanged(dynamic, double) {
    // ** addr: 0x868510, size: 0x4c
    // 0x868510: EnterFrame
    //     0x868510: stp             fp, lr, [SP, #-0x10]!
    //     0x868514: mov             fp, SP
    // 0x868518: ldr             x0, [fp, #0x18]
    // 0x86851c: LoadField: r1 = r0->field_17
    //     0x86851c: ldur            w1, [x0, #0x17]
    // 0x868520: DecompressPointer r1
    //     0x868520: add             x1, x1, HEAP, lsl #32
    // 0x868524: CheckStackOverflow
    //     0x868524: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x868528: cmp             SP, x16
    //     0x86852c: b.ls            #0x868554
    // 0x868530: LoadField: r0 = r1->field_f
    //     0x868530: ldur            w0, [x1, #0xf]
    // 0x868534: DecompressPointer r0
    //     0x868534: add             x0, x0, HEAP, lsl #32
    // 0x868538: ldr             x16, [fp, #0x10]
    // 0x86853c: stp             x16, x0, [SP, #-0x10]!
    // 0x868540: r0 = _handleChanged()
    //     0x868540: bl              #0x86855c  ; [package:flutter/src/material/slider.dart] _SliderState::_handleChanged
    // 0x868544: add             SP, SP, #0x10
    // 0x868548: LeaveFrame
    //     0x868548: mov             SP, fp
    //     0x86854c: ldp             fp, lr, [SP], #0x10
    // 0x868550: ret
    //     0x868550: ret             
    // 0x868554: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x868554: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868558: b               #0x868530
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0x86855c, size: 0xfc
    // 0x86855c: EnterFrame
    //     0x86855c: stp             fp, lr, [SP, #-0x10]!
    //     0x868560: mov             fp, SP
    // 0x868564: CheckStackOverflow
    //     0x868564: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x868568: cmp             SP, x16
    //     0x86856c: b.ls            #0x868630
    // 0x868570: ldr             x0, [fp, #0x10]
    // 0x868574: LoadField: d0 = r0->field_7
    //     0x868574: ldur            d0, [x0, #7]
    // 0x868578: ldr             x16, [fp, #0x18]
    // 0x86857c: SaveReg r16
    //     0x86857c: str             x16, [SP, #-8]!
    // 0x868580: SaveReg d0
    //     0x868580: str             d0, [SP, #-8]!
    // 0x868584: r0 = _lerp()
    //     0x868584: bl              #0x868658  ; [package:flutter/src/material/slider.dart] _SliderState::_lerp
    // 0x868588: add             SP, SP, #0x10
    // 0x86858c: ldr             x1, [fp, #0x18]
    // 0x868590: LoadField: r0 = r1->field_b
    //     0x868590: ldur            w0, [x1, #0xb]
    // 0x868594: DecompressPointer r0
    //     0x868594: add             x0, x0, HEAP, lsl #32
    // 0x868598: cmp             w0, NULL
    // 0x86859c: b.eq            #0x868638
    // 0x8685a0: LoadField: d1 = r0->field_b
    //     0x8685a0: ldur            d1, [x0, #0xb]
    // 0x8685a4: fcmp            d0, d1
    // 0x8685a8: b.eq            #0x868620
    // 0x8685ac: LoadField: r2 = r0->field_17
    //     0x8685ac: ldur            w2, [x0, #0x17]
    // 0x8685b0: DecompressPointer r2
    //     0x8685b0: add             x2, x2, HEAP, lsl #32
    // 0x8685b4: cmp             w2, NULL
    // 0x8685b8: b.eq            #0x86863c
    // 0x8685bc: r0 = inline_Allocate_Double()
    //     0x8685bc: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x8685c0: add             x0, x0, #0x10
    //     0x8685c4: cmp             x3, x0
    //     0x8685c8: b.ls            #0x868640
    //     0x8685cc: str             x0, [THR, #0x60]  ; THR::top
    //     0x8685d0: sub             x0, x0, #0xf
    //     0x8685d4: mov             x3, #0xd108
    //     0x8685d8: movk            x3, #3, lsl #16
    //     0x8685dc: stur            x3, [x0, #-1]
    // 0x8685e0: StoreField: r0->field_7 = d0
    //     0x8685e0: stur            d0, [x0, #7]
    // 0x8685e4: stp             x0, x2, [SP, #-0x10]!
    // 0x8685e8: mov             x0, x2
    // 0x8685ec: ClosureCall
    //     0x8685ec: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x8685f0: ldur            x2, [x0, #0x1f]
    //     0x8685f4: blr             x2
    // 0x8685f8: add             SP, SP, #0x10
    // 0x8685fc: ldr             x0, [fp, #0x18]
    // 0x868600: LoadField: r1 = r0->field_3f
    //     0x868600: ldur            w1, [x0, #0x3f]
    // 0x868604: DecompressPointer r1
    //     0x868604: add             x1, x1, HEAP, lsl #32
    // 0x868608: cmp             w1, NULL
    // 0x86860c: b.eq            #0x868620
    // 0x868610: SaveReg r1
    //     0x868610: str             x1, [SP, #-8]!
    // 0x868614: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x868614: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x868618: r0 = requestFocus()
    //     0x868618: bl              #0x6fed6c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0x86861c: add             SP, SP, #8
    // 0x868620: r0 = Null
    //     0x868620: mov             x0, NULL
    // 0x868624: LeaveFrame
    //     0x868624: mov             SP, fp
    //     0x868628: ldp             fp, lr, [SP], #0x10
    // 0x86862c: ret
    //     0x86862c: ret             
    // 0x868630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x868630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x868634: b               #0x868570
    // 0x868638: r0 = NullCastErrorSharedWithFPURegs()
    //     0x868638: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x86863c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x86863c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x868640: SaveReg d0
    //     0x868640: str             q0, [SP, #-0x10]!
    // 0x868644: stp             x1, x2, [SP, #-0x10]!
    // 0x868648: r0 = AllocateDouble()
    //     0x868648: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x86864c: ldp             x1, x2, [SP], #0x10
    // 0x868650: RestoreReg d0
    //     0x868650: ldr             q0, [SP], #0x10
    // 0x868654: b               #0x8685e0
  }
  _ _lerp(/* No info */) {
    // ** addr: 0x868658, size: 0x44
    // 0x868658: EnterFrame
    //     0x868658: stp             fp, lr, [SP, #-0x10]!
    //     0x86865c: mov             fp, SP
    // 0x868660: ldr             x0, [fp, #0x18]
    // 0x868664: LoadField: r1 = r0->field_b
    //     0x868664: ldur            w1, [x0, #0xb]
    // 0x868668: DecompressPointer r1
    //     0x868668: add             x1, x1, HEAP, lsl #32
    // 0x86866c: cmp             w1, NULL
    // 0x868670: b.eq            #0x868698
    // 0x868674: LoadField: d1 = r1->field_2b
    //     0x868674: ldur            d1, [x1, #0x2b]
    // 0x868678: LoadField: d2 = r1->field_23
    //     0x868678: ldur            d2, [x1, #0x23]
    // 0x86867c: fsub            d3, d1, d2
    // 0x868680: ldr             d1, [fp, #0x10]
    // 0x868684: fmul            d4, d1, d3
    // 0x868688: fadd            d0, d4, d2
    // 0x86868c: LeaveFrame
    //     0x86868c: mov             SP, fp
    //     0x868690: ldp             fp, lr, [SP], #0x10
    // 0x868694: ret
    //     0x868694: ret             
    // 0x868698: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x868698: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x8686dc, size: 0x108
    // 0x8686dc: EnterFrame
    //     0x8686dc: stp             fp, lr, [SP, #-0x10]!
    //     0x8686e0: mov             fp, SP
    // 0x8686e4: AllocStack(0x8)
    //     0x8686e4: sub             SP, SP, #8
    // 0x8686e8: SetupParameters()
    //     0x8686e8: ldr             x0, [fp, #0x10]
    //     0x8686ec: ldur            w1, [x0, #0x17]
    //     0x8686f0: add             x1, x1, HEAP, lsl #32
    //     0x8686f4: stur            x1, [fp, #-8]
    // 0x8686f8: CheckStackOverflow
    //     0x8686f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8686fc: cmp             SP, x16
    //     0x868700: b.ls            #0x8687c4
    // 0x868704: LoadField: r0 = r1->field_f
    //     0x868704: ldur            w0, [x1, #0xf]
    // 0x868708: DecompressPointer r0
    //     0x868708: add             x0, x0, HEAP, lsl #32
    // 0x86870c: LoadField: r2 = r0->field_b
    //     0x86870c: ldur            w2, [x0, #0xb]
    // 0x868710: DecompressPointer r2
    //     0x868710: add             x2, x2, HEAP, lsl #32
    // 0x868714: cmp             w2, NULL
    // 0x868718: b.eq            #0x8687cc
    // 0x86871c: LoadField: r2 = r0->field_3f
    //     0x86871c: ldur            w2, [x0, #0x3f]
    // 0x868720: DecompressPointer r2
    //     0x868720: add             x2, x2, HEAP, lsl #32
    // 0x868724: cmp             w2, NULL
    // 0x868728: b.eq            #0x8687d0
    // 0x86872c: SaveReg r2
    //     0x86872c: str             x2, [SP, #-8]!
    // 0x868730: r0 = hasFocus()
    //     0x868730: bl              #0x6f8fe4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::hasFocus
    // 0x868734: add             SP, SP, #8
    // 0x868738: tbz             w0, #4, #0x8687b4
    // 0x86873c: ldur            x0, [fp, #-8]
    // 0x868740: LoadField: r1 = r0->field_f
    //     0x868740: ldur            w1, [x0, #0xf]
    // 0x868744: DecompressPointer r1
    //     0x868744: add             x1, x1, HEAP, lsl #32
    // 0x868748: LoadField: r2 = r1->field_b
    //     0x868748: ldur            w2, [x1, #0xb]
    // 0x86874c: DecompressPointer r2
    //     0x86874c: add             x2, x2, HEAP, lsl #32
    // 0x868750: cmp             w2, NULL
    // 0x868754: b.eq            #0x8687d4
    // 0x868758: LoadField: r2 = r1->field_3f
    //     0x868758: ldur            w2, [x1, #0x3f]
    // 0x86875c: DecompressPointer r2
    //     0x86875c: add             x2, x2, HEAP, lsl #32
    // 0x868760: cmp             w2, NULL
    // 0x868764: b.eq            #0x8687d8
    // 0x868768: SaveReg r2
    //     0x868768: str             x2, [SP, #-8]!
    // 0x86876c: r0 = canRequestFocus()
    //     0x86876c: bl              #0x7ae250  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::canRequestFocus
    // 0x868770: add             SP, SP, #8
    // 0x868774: tbnz            w0, #4, #0x8687b4
    // 0x868778: ldur            x0, [fp, #-8]
    // 0x86877c: LoadField: r1 = r0->field_f
    //     0x86877c: ldur            w1, [x0, #0xf]
    // 0x868780: DecompressPointer r1
    //     0x868780: add             x1, x1, HEAP, lsl #32
    // 0x868784: LoadField: r0 = r1->field_b
    //     0x868784: ldur            w0, [x1, #0xb]
    // 0x868788: DecompressPointer r0
    //     0x868788: add             x0, x0, HEAP, lsl #32
    // 0x86878c: cmp             w0, NULL
    // 0x868790: b.eq            #0x8687dc
    // 0x868794: LoadField: r0 = r1->field_3f
    //     0x868794: ldur            w0, [x1, #0x3f]
    // 0x868798: DecompressPointer r0
    //     0x868798: add             x0, x0, HEAP, lsl #32
    // 0x86879c: cmp             w0, NULL
    // 0x8687a0: b.eq            #0x8687e0
    // 0x8687a4: SaveReg r0
    //     0x8687a4: str             x0, [SP, #-8]!
    // 0x8687a8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8687a8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8687ac: r0 = requestFocus()
    //     0x8687ac: bl              #0x6fed6c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0x8687b0: add             SP, SP, #8
    // 0x8687b4: r0 = Null
    //     0x8687b4: mov             x0, NULL
    // 0x8687b8: LeaveFrame
    //     0x8687b8: mov             SP, fp
    //     0x8687bc: ldp             fp, lr, [SP], #0x10
    // 0x8687c0: ret
    //     0x8687c0: ret             
    // 0x8687c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8687c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8687c8: b               #0x868704
    // 0x8687cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8687cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8687d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8687d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8687d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8687d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8687d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8687d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8687dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8687dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8687e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8687e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Color? effectiveOverlayColor(dynamic) {
    // ** addr: 0x8687e4, size: 0xe0
    // 0x8687e4: EnterFrame
    //     0x8687e4: stp             fp, lr, [SP, #-0x10]!
    //     0x8687e8: mov             fp, SP
    // 0x8687ec: AllocStack(0x10)
    //     0x8687ec: sub             SP, SP, #0x10
    // 0x8687f0: SetupParameters()
    //     0x8687f0: ldr             x0, [fp, #0x10]
    //     0x8687f4: ldur            w1, [x0, #0x17]
    //     0x8687f8: add             x1, x1, HEAP, lsl #32
    //     0x8687fc: stur            x1, [fp, #-0x10]
    // 0x868800: CheckStackOverflow
    //     0x868800: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x868804: cmp             SP, x16
    //     0x868808: b.ls            #0x8688b8
    // 0x86880c: LoadField: r0 = r1->field_f
    //     0x86880c: ldur            w0, [x1, #0xf]
    // 0x868810: DecompressPointer r0
    //     0x868810: add             x0, x0, HEAP, lsl #32
    // 0x868814: LoadField: r2 = r0->field_b
    //     0x868814: ldur            w2, [x0, #0xb]
    // 0x868818: DecompressPointer r2
    //     0x868818: add             x2, x2, HEAP, lsl #32
    // 0x86881c: cmp             w2, NULL
    // 0x868820: b.eq            #0x8688c0
    // 0x868824: LoadField: r0 = r1->field_17
    //     0x868824: ldur            w0, [x1, #0x17]
    // 0x868828: DecompressPointer r0
    //     0x868828: add             x0, x0, HEAP, lsl #32
    // 0x86882c: LoadField: r2 = r0->field_3f
    //     0x86882c: ldur            w2, [x0, #0x3f]
    // 0x868830: DecompressPointer r2
    //     0x868830: add             x2, x2, HEAP, lsl #32
    // 0x868834: LoadField: r0 = r1->field_1f
    //     0x868834: ldur            w0, [x1, #0x1f]
    // 0x868838: DecompressPointer r0
    //     0x868838: add             x0, x0, HEAP, lsl #32
    // 0x86883c: stur            x0, [fp, #-8]
    // 0x868840: r16 = <Color?>
    //     0x868840: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x868844: ldr             x16, [x16, #0xf68]
    // 0x868848: stp             x2, x16, [SP, #-0x10]!
    // 0x86884c: SaveReg r0
    //     0x86884c: str             x0, [SP, #-8]!
    // 0x868850: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x868850: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x868854: r0 = resolveAs()
    //     0x868854: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x868858: add             SP, SP, #0x18
    // 0x86885c: cmp             w0, NULL
    // 0x868860: b.ne            #0x8688ac
    // 0x868864: ldur            x0, [fp, #-0x10]
    // 0x868868: LoadField: r1 = r0->field_1b
    //     0x868868: ldur            w1, [x0, #0x1b]
    // 0x86886c: DecompressPointer r1
    //     0x86886c: add             x1, x1, HEAP, lsl #32
    // 0x868870: r0 = LoadClassIdInstr(r1)
    //     0x868870: ldur            x0, [x1, #-1]
    //     0x868874: ubfx            x0, x0, #0xc, #0x14
    // 0x868878: SaveReg r1
    //     0x868878: str             x1, [SP, #-8]!
    // 0x86887c: r0 = GDT[cid_x0 + -0xfdc]()
    //     0x86887c: sub             lr, x0, #0xfdc
    //     0x868880: ldr             lr, [x21, lr, lsl #3]
    //     0x868884: blr             lr
    // 0x868888: add             SP, SP, #8
    // 0x86888c: r16 = <Color?>
    //     0x86888c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf68] TypeArguments: <Color?>
    //     0x868890: ldr             x16, [x16, #0xf68]
    // 0x868894: stp             x0, x16, [SP, #-0x10]!
    // 0x868898: ldur            x16, [fp, #-8]
    // 0x86889c: SaveReg r16
    //     0x86889c: str             x16, [SP, #-8]!
    // 0x8688a0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8688a0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8688a4: r0 = resolveAs()
    //     0x8688a4: bl              #0x5a6b88  ; [package:flutter/src/material/material_state.dart] MaterialStateProperty::resolveAs
    // 0x8688a8: add             SP, SP, #0x18
    // 0x8688ac: LeaveFrame
    //     0x8688ac: mov             SP, fp
    //     0x8688b0: ldp             fp, lr, [SP], #0x10
    // 0x8688b4: ret
    //     0x8688b4: ret             
    // 0x8688b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8688b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8688bc: b               #0x86880c
    // 0x8688c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8688c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9db708, size: 0x3b4
    // 0x9db708: EnterFrame
    //     0x9db708: stp             fp, lr, [SP, #-0x10]!
    //     0x9db70c: mov             fp, SP
    // 0x9db710: AllocStack(0x18)
    //     0x9db710: sub             SP, SP, #0x18
    // 0x9db714: CheckStackOverflow
    //     0x9db714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9db718: cmp             SP, x16
    //     0x9db71c: b.ls            #0x9dbaa8
    // 0x9db720: r1 = <double>
    //     0x9db720: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db724: r0 = AnimationController()
    //     0x9db724: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db728: stur            x0, [fp, #-8]
    // 0x9db72c: ldr             x16, [fp, #0x10]
    // 0x9db730: stp             x16, x0, [SP, #-0x10]!
    // 0x9db734: r16 = Instance_Duration
    //     0x9db734: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x9db738: ldr             x16, [x16, #0x9f0]
    // 0x9db73c: SaveReg r16
    //     0x9db73c: str             x16, [SP, #-8]!
    // 0x9db740: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db740: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db744: ldr             x4, [x4, #0xa0]
    // 0x9db748: r0 = AnimationController()
    //     0x9db748: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db74c: add             SP, SP, #0x18
    // 0x9db750: ldur            x0, [fp, #-8]
    // 0x9db754: ldr             x2, [fp, #0x10]
    // 0x9db758: StoreField: r2->field_1b = r0
    //     0x9db758: stur            w0, [x2, #0x1b]
    //     0x9db75c: ldurb           w16, [x2, #-1]
    //     0x9db760: ldurb           w17, [x0, #-1]
    //     0x9db764: and             x16, x17, x16, lsr #2
    //     0x9db768: tst             x16, HEAP, lsr #32
    //     0x9db76c: b.eq            #0x9db774
    //     0x9db770: bl              #0xd6828c
    // 0x9db774: r1 = <double>
    //     0x9db774: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db778: r0 = AnimationController()
    //     0x9db778: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db77c: stur            x0, [fp, #-8]
    // 0x9db780: ldr             x16, [fp, #0x10]
    // 0x9db784: stp             x16, x0, [SP, #-0x10]!
    // 0x9db788: r16 = Instance_Duration
    //     0x9db788: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x9db78c: ldr             x16, [x16, #0x9f0]
    // 0x9db790: SaveReg r16
    //     0x9db790: str             x16, [SP, #-8]!
    // 0x9db794: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db794: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db798: ldr             x4, [x4, #0xa0]
    // 0x9db79c: r0 = AnimationController()
    //     0x9db79c: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db7a0: add             SP, SP, #0x18
    // 0x9db7a4: ldur            x0, [fp, #-8]
    // 0x9db7a8: ldr             x2, [fp, #0x10]
    // 0x9db7ac: StoreField: r2->field_1f = r0
    //     0x9db7ac: stur            w0, [x2, #0x1f]
    //     0x9db7b0: ldurb           w16, [x2, #-1]
    //     0x9db7b4: ldurb           w17, [x0, #-1]
    //     0x9db7b8: and             x16, x17, x16, lsr #2
    //     0x9db7bc: tst             x16, HEAP, lsr #32
    //     0x9db7c0: b.eq            #0x9db7c8
    //     0x9db7c4: bl              #0xd6828c
    // 0x9db7c8: r1 = <double>
    //     0x9db7c8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db7cc: r0 = AnimationController()
    //     0x9db7cc: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db7d0: stur            x0, [fp, #-8]
    // 0x9db7d4: ldr             x16, [fp, #0x10]
    // 0x9db7d8: stp             x16, x0, [SP, #-0x10]!
    // 0x9db7dc: r16 = Instance_Duration
    //     0x9db7dc: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e300] Obj!Duration@b67bc1
    //     0x9db7e0: ldr             x16, [x16, #0x300]
    // 0x9db7e4: SaveReg r16
    //     0x9db7e4: str             x16, [SP, #-8]!
    // 0x9db7e8: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db7e8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db7ec: ldr             x4, [x4, #0xa0]
    // 0x9db7f0: r0 = AnimationController()
    //     0x9db7f0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db7f4: add             SP, SP, #0x18
    // 0x9db7f8: ldur            x0, [fp, #-8]
    // 0x9db7fc: ldr             x2, [fp, #0x10]
    // 0x9db800: StoreField: r2->field_23 = r0
    //     0x9db800: stur            w0, [x2, #0x23]
    //     0x9db804: ldurb           w16, [x2, #-1]
    //     0x9db808: ldurb           w17, [x0, #-1]
    //     0x9db80c: and             x16, x17, x16, lsr #2
    //     0x9db810: tst             x16, HEAP, lsr #32
    //     0x9db814: b.eq            #0x9db81c
    //     0x9db818: bl              #0xd6828c
    // 0x9db81c: r1 = <double>
    //     0x9db81c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9db820: r0 = AnimationController()
    //     0x9db820: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9db824: stur            x0, [fp, #-8]
    // 0x9db828: ldr             x16, [fp, #0x10]
    // 0x9db82c: stp             x16, x0, [SP, #-0x10]!
    // 0x9db830: r16 = Instance_Duration
    //     0x9db830: ldr             x16, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x9db834: SaveReg r16
    //     0x9db834: str             x16, [SP, #-8]!
    // 0x9db838: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9db838: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9db83c: ldr             x4, [x4, #0xa0]
    // 0x9db840: r0 = AnimationController()
    //     0x9db840: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9db844: add             SP, SP, #0x18
    // 0x9db848: ldur            x0, [fp, #-8]
    // 0x9db84c: ldr             x1, [fp, #0x10]
    // 0x9db850: StoreField: r1->field_27 = r0
    //     0x9db850: stur            w0, [x1, #0x27]
    //     0x9db854: ldurb           w16, [x1, #-1]
    //     0x9db858: ldurb           w17, [x0, #-1]
    //     0x9db85c: and             x16, x17, x16, lsr #2
    //     0x9db860: tst             x16, HEAP, lsr #32
    //     0x9db864: b.eq            #0x9db86c
    //     0x9db868: bl              #0xd6826c
    // 0x9db86c: LoadField: r0 = r1->field_23
    //     0x9db86c: ldur            w0, [x1, #0x23]
    // 0x9db870: DecompressPointer r0
    //     0x9db870: add             x0, x0, HEAP, lsl #32
    // 0x9db874: LoadField: r2 = r1->field_b
    //     0x9db874: ldur            w2, [x1, #0xb]
    // 0x9db878: DecompressPointer r2
    //     0x9db878: add             x2, x2, HEAP, lsl #32
    // 0x9db87c: cmp             w2, NULL
    // 0x9db880: b.eq            #0x9dbab0
    // 0x9db884: LoadField: r3 = r2->field_17
    //     0x9db884: ldur            w3, [x2, #0x17]
    // 0x9db888: DecompressPointer r3
    //     0x9db888: add             x3, x3, HEAP, lsl #32
    // 0x9db88c: cmp             w3, NULL
    // 0x9db890: b.eq            #0x9db89c
    // 0x9db894: d0 = 1.000000
    //     0x9db894: fmov            d0, #1.00000000
    // 0x9db898: b               #0x9db8a0
    // 0x9db89c: d0 = 0.000000
    //     0x9db89c: eor             v0.16b, v0.16b, v0.16b
    // 0x9db8a0: SaveReg r0
    //     0x9db8a0: str             x0, [SP, #-8]!
    // 0x9db8a4: SaveReg d0
    //     0x9db8a4: str             d0, [SP, #-8]!
    // 0x9db8a8: r0 = value=()
    //     0x9db8a8: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x9db8ac: add             SP, SP, #0x10
    // 0x9db8b0: ldr             x0, [fp, #0x10]
    // 0x9db8b4: LoadField: r1 = r0->field_27
    //     0x9db8b4: ldur            w1, [x0, #0x27]
    // 0x9db8b8: DecompressPointer r1
    //     0x9db8b8: add             x1, x1, HEAP, lsl #32
    // 0x9db8bc: stur            x1, [fp, #-8]
    // 0x9db8c0: LoadField: r2 = r0->field_b
    //     0x9db8c0: ldur            w2, [x0, #0xb]
    // 0x9db8c4: DecompressPointer r2
    //     0x9db8c4: add             x2, x2, HEAP, lsl #32
    // 0x9db8c8: cmp             w2, NULL
    // 0x9db8cc: b.eq            #0x9dbab4
    // 0x9db8d0: LoadField: d0 = r2->field_b
    //     0x9db8d0: ldur            d0, [x2, #0xb]
    // 0x9db8d4: SaveReg r0
    //     0x9db8d4: str             x0, [SP, #-8]!
    // 0x9db8d8: SaveReg d0
    //     0x9db8d8: str             d0, [SP, #-8]!
    // 0x9db8dc: r0 = _convert()
    //     0x9db8dc: bl              #0x867db8  ; [package:flutter/src/material/slider.dart] _SliderState::_convert
    // 0x9db8e0: add             SP, SP, #0x10
    // 0x9db8e4: ldur            x16, [fp, #-8]
    // 0x9db8e8: SaveReg r16
    //     0x9db8e8: str             x16, [SP, #-8]!
    // 0x9db8ec: SaveReg d0
    //     0x9db8ec: str             d0, [SP, #-8]!
    // 0x9db8f0: r0 = value=()
    //     0x9db8f0: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x9db8f4: add             SP, SP, #0x10
    // 0x9db8f8: r1 = Null
    //     0x9db8f8: mov             x1, NULL
    // 0x9db8fc: r2 = 4
    //     0x9db8fc: mov             x2, #4
    // 0x9db900: r0 = AllocateArray()
    //     0x9db900: bl              #0xd6987c  ; AllocateArrayStub
    // 0x9db904: stur            x0, [fp, #-8]
    // 0x9db908: r17 = _AdjustSliderIntent
    //     0x9db908: add             x17, PP, #0x55, lsl #12  ; [pp+0x55840] Type: _AdjustSliderIntent
    //     0x9db90c: ldr             x17, [x17, #0x840]
    // 0x9db910: StoreField: r0->field_f = r17
    //     0x9db910: stur            w17, [x0, #0xf]
    // 0x9db914: r1 = 1
    //     0x9db914: mov             x1, #1
    // 0x9db918: r0 = AllocateContext()
    //     0x9db918: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9db91c: mov             x1, x0
    // 0x9db920: ldr             x0, [fp, #0x10]
    // 0x9db924: StoreField: r1->field_f = r0
    //     0x9db924: stur            w0, [x1, #0xf]
    // 0x9db928: mov             x2, x1
    // 0x9db92c: r1 = Function '_actionHandler@810231897':.
    //     0x9db92c: add             x1, PP, #0x55, lsl #12  ; [pp+0x55848] AnonymousClosure: (0x9dbabc), in [package:flutter/src/material/slider.dart] _SliderState::_actionHandler (0x9dbb08)
    //     0x9db930: ldr             x1, [x1, #0x848]
    // 0x9db934: r0 = AllocateClosure()
    //     0x9db934: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9db938: r1 = <_AdjustSliderIntent>
    //     0x9db938: add             x1, PP, #0x55, lsl #12  ; [pp+0x55850] TypeArguments: <_AdjustSliderIntent>
    //     0x9db93c: ldr             x1, [x1, #0x850]
    // 0x9db940: stur            x0, [fp, #-0x10]
    // 0x9db944: r0 = CallbackAction()
    //     0x9db944: bl              #0x837e0c  ; AllocateCallbackActionStub -> CallbackAction<X0 bound Intent> (size=0x18)
    // 0x9db948: mov             x2, x0
    // 0x9db94c: ldur            x0, [fp, #-0x10]
    // 0x9db950: stur            x2, [fp, #-0x18]
    // 0x9db954: StoreField: r2->field_13 = r0
    //     0x9db954: stur            w0, [x2, #0x13]
    // 0x9db958: r1 = <(dynamic this, Action<Intent>) => void?>
    //     0x9db958: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x9db95c: ldr             x1, [x1, #0xcc0]
    // 0x9db960: r0 = ObserverList()
    //     0x9db960: bl              #0x5a0e00  ; AllocateObserverListStub -> ObserverList<X0> (size=0x18)
    // 0x9db964: mov             x1, x0
    // 0x9db968: r0 = false
    //     0x9db968: add             x0, NULL, #0x30  ; false
    // 0x9db96c: stur            x1, [fp, #-0x10]
    // 0x9db970: StoreField: r1->field_f = r0
    //     0x9db970: stur            w0, [x1, #0xf]
    // 0x9db974: r0 = Sentinel
    //     0x9db974: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9db978: StoreField: r1->field_13 = r0
    //     0x9db978: stur            w0, [x1, #0x13]
    // 0x9db97c: r16 = <(dynamic this, Action<Intent>) => void?>
    //     0x9db97c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fcc0] TypeArguments: <(dynamic this, Action<Intent>) => void?>
    //     0x9db980: ldr             x16, [x16, #0xcc0]
    // 0x9db984: stp             xzr, x16, [SP, #-0x10]!
    // 0x9db988: r0 = _GrowableList()
    //     0x9db988: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x9db98c: add             SP, SP, #0x10
    // 0x9db990: ldur            x1, [fp, #-0x10]
    // 0x9db994: StoreField: r1->field_b = r0
    //     0x9db994: stur            w0, [x1, #0xb]
    //     0x9db998: ldurb           w16, [x1, #-1]
    //     0x9db99c: ldurb           w17, [x0, #-1]
    //     0x9db9a0: and             x16, x17, x16, lsr #2
    //     0x9db9a4: tst             x16, HEAP, lsr #32
    //     0x9db9a8: b.eq            #0x9db9b0
    //     0x9db9ac: bl              #0xd6826c
    // 0x9db9b0: mov             x0, x1
    // 0x9db9b4: ldur            x1, [fp, #-0x18]
    // 0x9db9b8: StoreField: r1->field_b = r0
    //     0x9db9b8: stur            w0, [x1, #0xb]
    //     0x9db9bc: ldurb           w16, [x1, #-1]
    //     0x9db9c0: ldurb           w17, [x0, #-1]
    //     0x9db9c4: and             x16, x17, x16, lsr #2
    //     0x9db9c8: tst             x16, HEAP, lsr #32
    //     0x9db9cc: b.eq            #0x9db9d4
    //     0x9db9d0: bl              #0xd6826c
    // 0x9db9d4: mov             x0, x1
    // 0x9db9d8: ldur            x1, [fp, #-8]
    // 0x9db9dc: ArrayStore: r1[1] = r0  ; List_4
    //     0x9db9dc: add             x25, x1, #0x13
    //     0x9db9e0: str             w0, [x25]
    //     0x9db9e4: tbz             w0, #0, #0x9dba00
    //     0x9db9e8: ldurb           w16, [x1, #-1]
    //     0x9db9ec: ldurb           w17, [x0, #-1]
    //     0x9db9f0: and             x16, x17, x16, lsr #2
    //     0x9db9f4: tst             x16, HEAP, lsr #32
    //     0x9db9f8: b.eq            #0x9dba00
    //     0x9db9fc: bl              #0xd67e5c
    // 0x9dba00: r16 = <Type, Action<Intent>>
    //     0x9dba00: add             x16, PP, #0x21, lsl #12  ; [pp+0x21e40] TypeArguments: <Type, Action<Intent>>
    //     0x9dba04: ldr             x16, [x16, #0xe40]
    // 0x9dba08: ldur            lr, [fp, #-8]
    // 0x9dba0c: stp             lr, x16, [SP, #-0x10]!
    // 0x9dba10: r0 = Map._fromLiteral()
    //     0x9dba10: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x9dba14: add             SP, SP, #0x10
    // 0x9dba18: ldr             x1, [fp, #0x10]
    // 0x9dba1c: StoreField: r1->field_33 = r0
    //     0x9dba1c: stur            w0, [x1, #0x33]
    //     0x9dba20: tbz             w0, #0, #0x9dba3c
    //     0x9dba24: ldurb           w16, [x1, #-1]
    //     0x9dba28: ldurb           w17, [x0, #-1]
    //     0x9dba2c: and             x16, x17, x16, lsr #2
    //     0x9dba30: tst             x16, HEAP, lsr #32
    //     0x9dba34: b.eq            #0x9dba3c
    //     0x9dba38: bl              #0xd6826c
    // 0x9dba3c: LoadField: r0 = r1->field_b
    //     0x9dba3c: ldur            w0, [x1, #0xb]
    // 0x9dba40: DecompressPointer r0
    //     0x9dba40: add             x0, x0, HEAP, lsl #32
    // 0x9dba44: cmp             w0, NULL
    // 0x9dba48: b.eq            #0x9dbab8
    // 0x9dba4c: LoadField: r0 = r1->field_3f
    //     0x9dba4c: ldur            w0, [x1, #0x3f]
    // 0x9dba50: DecompressPointer r0
    //     0x9dba50: add             x0, x0, HEAP, lsl #32
    // 0x9dba54: cmp             w0, NULL
    // 0x9dba58: b.ne            #0x9dba98
    // 0x9dba5c: r0 = FocusNode()
    //     0x9dba5c: bl              #0x7ae5a8  ; AllocateFocusNodeStub -> FocusNode (size=0x64)
    // 0x9dba60: stur            x0, [fp, #-8]
    // 0x9dba64: SaveReg r0
    //     0x9dba64: str             x0, [SP, #-8]!
    // 0x9dba68: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9dba68: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9dba6c: r0 = FocusNode()
    //     0x9dba6c: bl              #0x5bac08  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::FocusNode
    // 0x9dba70: add             SP, SP, #8
    // 0x9dba74: ldur            x0, [fp, #-8]
    // 0x9dba78: ldr             x1, [fp, #0x10]
    // 0x9dba7c: StoreField: r1->field_3f = r0
    //     0x9dba7c: stur            w0, [x1, #0x3f]
    //     0x9dba80: ldurb           w16, [x1, #-1]
    //     0x9dba84: ldurb           w17, [x0, #-1]
    //     0x9dba88: and             x16, x17, x16, lsr #2
    //     0x9dba8c: tst             x16, HEAP, lsr #32
    //     0x9dba90: b.eq            #0x9dba98
    //     0x9dba94: bl              #0xd6826c
    // 0x9dba98: r0 = Null
    //     0x9dba98: mov             x0, NULL
    // 0x9dba9c: LeaveFrame
    //     0x9dba9c: mov             SP, fp
    //     0x9dbaa0: ldp             fp, lr, [SP], #0x10
    // 0x9dbaa4: ret
    //     0x9dbaa4: ret             
    // 0x9dbaa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbaa8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbaac: b               #0x9db720
    // 0x9dbab0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbab0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dbab4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbab4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dbab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbab8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _actionHandler(dynamic, _AdjustSliderIntent) {
    // ** addr: 0x9dbabc, size: 0x4c
    // 0x9dbabc: EnterFrame
    //     0x9dbabc: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbac0: mov             fp, SP
    // 0x9dbac4: ldr             x0, [fp, #0x18]
    // 0x9dbac8: LoadField: r1 = r0->field_17
    //     0x9dbac8: ldur            w1, [x0, #0x17]
    // 0x9dbacc: DecompressPointer r1
    //     0x9dbacc: add             x1, x1, HEAP, lsl #32
    // 0x9dbad0: CheckStackOverflow
    //     0x9dbad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbad4: cmp             SP, x16
    //     0x9dbad8: b.ls            #0x9dbb00
    // 0x9dbadc: LoadField: r0 = r1->field_f
    //     0x9dbadc: ldur            w0, [x1, #0xf]
    // 0x9dbae0: DecompressPointer r0
    //     0x9dbae0: add             x0, x0, HEAP, lsl #32
    // 0x9dbae4: ldr             x16, [fp, #0x10]
    // 0x9dbae8: stp             x16, x0, [SP, #-0x10]!
    // 0x9dbaec: r0 = _actionHandler()
    //     0x9dbaec: bl              #0x9dbb08  ; [package:flutter/src/material/slider.dart] _SliderState::_actionHandler
    // 0x9dbaf0: add             SP, SP, #0x10
    // 0x9dbaf4: LeaveFrame
    //     0x9dbaf4: mov             SP, fp
    //     0x9dbaf8: ldp             fp, lr, [SP], #0x10
    // 0x9dbafc: ret
    //     0x9dbafc: ret             
    // 0x9dbb00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbb00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbb04: b               #0x9dbadc
  }
  _ _actionHandler(/* No info */) {
    // ** addr: 0x9dbb08, size: 0x188
    // 0x9dbb08: EnterFrame
    //     0x9dbb08: stp             fp, lr, [SP, #-0x10]!
    //     0x9dbb0c: mov             fp, SP
    // 0x9dbb10: AllocStack(0x10)
    //     0x9dbb10: sub             SP, SP, #0x10
    // 0x9dbb14: CheckStackOverflow
    //     0x9dbb14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dbb18: cmp             SP, x16
    //     0x9dbb1c: b.ls            #0x9dbc7c
    // 0x9dbb20: ldr             x0, [fp, #0x18]
    // 0x9dbb24: LoadField: r1 = r0->field_2f
    //     0x9dbb24: ldur            w1, [x0, #0x2f]
    // 0x9dbb28: DecompressPointer r1
    //     0x9dbb28: add             x1, x1, HEAP, lsl #32
    // 0x9dbb2c: stur            x1, [fp, #-8]
    // 0x9dbb30: SaveReg r1
    //     0x9dbb30: str             x1, [SP, #-8]!
    // 0x9dbb34: r0 = _currentElement()
    //     0x9dbb34: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x9dbb38: add             SP, SP, #8
    // 0x9dbb3c: cmp             w0, NULL
    // 0x9dbb40: b.eq            #0x9dbc84
    // 0x9dbb44: SaveReg r0
    //     0x9dbb44: str             x0, [SP, #-8]!
    // 0x9dbb48: r0 = findRenderObject()
    //     0x9dbb48: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0x9dbb4c: add             SP, SP, #8
    // 0x9dbb50: mov             x3, x0
    // 0x9dbb54: stur            x3, [fp, #-0x10]
    // 0x9dbb58: cmp             w3, NULL
    // 0x9dbb5c: b.eq            #0x9dbc88
    // 0x9dbb60: mov             x0, x3
    // 0x9dbb64: r2 = Null
    //     0x9dbb64: mov             x2, NULL
    // 0x9dbb68: r1 = Null
    //     0x9dbb68: mov             x1, NULL
    // 0x9dbb6c: r4 = LoadClassIdInstr(r0)
    //     0x9dbb6c: ldur            x4, [x0, #-1]
    //     0x9dbb70: ubfx            x4, x4, #0xc, #0x14
    // 0x9dbb74: cmp             x4, #0x98b
    // 0x9dbb78: b.eq            #0x9dbb90
    // 0x9dbb7c: r8 = _RenderSlider
    //     0x9dbb7c: add             x8, PP, #0x55, lsl #12  ; [pp+0x55858] Type: _RenderSlider
    //     0x9dbb80: ldr             x8, [x8, #0x858]
    // 0x9dbb84: r3 = Null
    //     0x9dbb84: add             x3, PP, #0x55, lsl #12  ; [pp+0x55860] Null
    //     0x9dbb88: ldr             x3, [x3, #0x860]
    // 0x9dbb8c: r0 = DefaultTypeTest()
    //     0x9dbb8c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9dbb90: ldur            x16, [fp, #-8]
    // 0x9dbb94: SaveReg r16
    //     0x9dbb94: str             x16, [SP, #-8]!
    // 0x9dbb98: r0 = _currentElement()
    //     0x9dbb98: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0x9dbb9c: add             SP, SP, #8
    // 0x9dbba0: cmp             w0, NULL
    // 0x9dbba4: b.eq            #0x9dbc8c
    // 0x9dbba8: SaveReg r0
    //     0x9dbba8: str             x0, [SP, #-8]!
    // 0x9dbbac: r0 = of()
    //     0x9dbbac: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x9dbbb0: add             SP, SP, #8
    // 0x9dbbb4: mov             x1, x0
    // 0x9dbbb8: ldr             x0, [fp, #0x10]
    // 0x9dbbbc: LoadField: r2 = r0->field_7
    //     0x9dbbbc: ldur            w2, [x0, #7]
    // 0x9dbbc0: DecompressPointer r2
    //     0x9dbbc0: add             x2, x2, HEAP, lsl #32
    // 0x9dbbc4: LoadField: r0 = r2->field_7
    //     0x9dbbc4: ldur            x0, [x2, #7]
    // 0x9dbbc8: cmp             x0, #1
    // 0x9dbbcc: b.gt            #0x9dbc40
    // 0x9dbbd0: cmp             x0, #0
    // 0x9dbbd4: b.gt            #0x9dbc0c
    // 0x9dbbd8: LoadField: r0 = r1->field_7
    //     0x9dbbd8: ldur            x0, [x1, #7]
    // 0x9dbbdc: cmp             x0, #0
    // 0x9dbbe0: b.gt            #0x9dbbf8
    // 0x9dbbe4: ldur            x16, [fp, #-0x10]
    // 0x9dbbe8: SaveReg r16
    //     0x9dbbe8: str             x16, [SP, #-8]!
    // 0x9dbbec: r0 = decreaseAction()
    //     0x9dbbec: bl              #0x650a98  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction
    // 0x9dbbf0: add             SP, SP, #8
    // 0x9dbbf4: b               #0x9dbc6c
    // 0x9dbbf8: ldur            x16, [fp, #-0x10]
    // 0x9dbbfc: SaveReg r16
    //     0x9dbbfc: str             x16, [SP, #-8]!
    // 0x9dbc00: r0 = increaseAction()
    //     0x9dbc00: bl              #0x650be0  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction
    // 0x9dbc04: add             SP, SP, #8
    // 0x9dbc08: b               #0x9dbc6c
    // 0x9dbc0c: LoadField: r0 = r1->field_7
    //     0x9dbc0c: ldur            x0, [x1, #7]
    // 0x9dbc10: cmp             x0, #0
    // 0x9dbc14: b.gt            #0x9dbc2c
    // 0x9dbc18: ldur            x16, [fp, #-0x10]
    // 0x9dbc1c: SaveReg r16
    //     0x9dbc1c: str             x16, [SP, #-8]!
    // 0x9dbc20: r0 = increaseAction()
    //     0x9dbc20: bl              #0x650be0  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction
    // 0x9dbc24: add             SP, SP, #8
    // 0x9dbc28: b               #0x9dbc6c
    // 0x9dbc2c: ldur            x16, [fp, #-0x10]
    // 0x9dbc30: SaveReg r16
    //     0x9dbc30: str             x16, [SP, #-8]!
    // 0x9dbc34: r0 = decreaseAction()
    //     0x9dbc34: bl              #0x650a98  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction
    // 0x9dbc38: add             SP, SP, #8
    // 0x9dbc3c: b               #0x9dbc6c
    // 0x9dbc40: cmp             x0, #2
    // 0x9dbc44: b.gt            #0x9dbc5c
    // 0x9dbc48: ldur            x16, [fp, #-0x10]
    // 0x9dbc4c: SaveReg r16
    //     0x9dbc4c: str             x16, [SP, #-8]!
    // 0x9dbc50: r0 = increaseAction()
    //     0x9dbc50: bl              #0x650be0  ; [package:flutter/src/material/slider.dart] _RenderSlider::increaseAction
    // 0x9dbc54: add             SP, SP, #8
    // 0x9dbc58: b               #0x9dbc6c
    // 0x9dbc5c: ldur            x16, [fp, #-0x10]
    // 0x9dbc60: SaveReg r16
    //     0x9dbc60: str             x16, [SP, #-8]!
    // 0x9dbc64: r0 = decreaseAction()
    //     0x9dbc64: bl              #0x650a98  ; [package:flutter/src/material/slider.dart] _RenderSlider::decreaseAction
    // 0x9dbc68: add             SP, SP, #8
    // 0x9dbc6c: r0 = Null
    //     0x9dbc6c: mov             x0, NULL
    // 0x9dbc70: LeaveFrame
    //     0x9dbc70: mov             SP, fp
    //     0x9dbc74: ldp             fp, lr, [SP], #0x10
    // 0x9dbc78: ret
    //     0x9dbc78: ret             
    // 0x9dbc7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dbc7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dbc80: b               #0x9dbb20
    // 0x9dbc84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbc84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dbc88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbc88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9dbc8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dbc8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _SliderState(/* No info */) {
    // ** addr: 0xa41630, size: 0x90
    // 0xa41630: EnterFrame
    //     0xa41630: stp             fp, lr, [SP, #-0x10]!
    //     0xa41634: mov             fp, SP
    // 0xa41638: r1 = Sentinel
    //     0xa41638: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4163c: r0 = false
    //     0xa4163c: add             x0, NULL, #0x30  ; false
    // 0xa41640: ldr             x2, [fp, #0x10]
    // 0xa41644: StoreField: r2->field_1b = r1
    //     0xa41644: stur            w1, [x2, #0x1b]
    // 0xa41648: StoreField: r2->field_1f = r1
    //     0xa41648: stur            w1, [x2, #0x1f]
    // 0xa4164c: StoreField: r2->field_23 = r1
    //     0xa4164c: stur            w1, [x2, #0x23]
    // 0xa41650: StoreField: r2->field_27 = r1
    //     0xa41650: stur            w1, [x2, #0x27]
    // 0xa41654: StoreField: r2->field_33 = r1
    //     0xa41654: stur            w1, [x2, #0x33]
    // 0xa41658: StoreField: r2->field_3b = r0
    //     0xa41658: stur            w0, [x2, #0x3b]
    // 0xa4165c: StoreField: r2->field_43 = r0
    //     0xa4165c: stur            w0, [x2, #0x43]
    // 0xa41660: StoreField: r2->field_47 = r0
    //     0xa41660: stur            w0, [x2, #0x47]
    // 0xa41664: r1 = <State<StatefulWidget>>
    //     0xa41664: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa41668: r0 = LabeledGlobalKey()
    //     0xa41668: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa4166c: ldr             x1, [fp, #0x10]
    // 0xa41670: StoreField: r1->field_2f = r0
    //     0xa41670: stur            w0, [x1, #0x2f]
    //     0xa41674: ldurb           w16, [x1, #-1]
    //     0xa41678: ldurb           w17, [x0, #-1]
    //     0xa4167c: and             x16, x17, x16, lsr #2
    //     0xa41680: tst             x16, HEAP, lsr #32
    //     0xa41684: b.eq            #0xa4168c
    //     0xa41688: bl              #0xd6826c
    // 0xa4168c: r0 = LayerLink()
    //     0xa4168c: bl              #0xa39584  ; AllocateLayerLinkStub -> LayerLink (size=0x10)
    // 0xa41690: ldr             x1, [fp, #0x10]
    // 0xa41694: StoreField: r1->field_4b = r0
    //     0xa41694: stur            w0, [x1, #0x4b]
    //     0xa41698: ldurb           w16, [x1, #-1]
    //     0xa4169c: ldurb           w17, [x0, #-1]
    //     0xa416a0: and             x16, x17, x16, lsr #2
    //     0xa416a4: tst             x16, HEAP, lsr #32
    //     0xa416a8: b.eq            #0xa416b0
    //     0xa416ac: bl              #0xd6826c
    // 0xa416b0: r0 = Null
    //     0xa416b0: mov             x0, NULL
    // 0xa416b4: LeaveFrame
    //     0xa416b4: mov             SP, fp
    //     0xa416b8: ldp             fp, lr, [SP], #0x10
    // 0xa416bc: ret
    //     0xa416bc: ret             
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b188, size: 0x18
    // 0xa4b188: r4 = 7
    //     0xa4b188: mov             x4, #7
    // 0xa4b18c: r1 = Function 'dispose':.
    //     0xa4b18c: add             x17, PP, #0x55, lsl #12  ; [pp+0x55778] AnonymousClosure: (0xa4b1a0), in [package:flutter/src/material/slider.dart] _SliderState::dispose (0xa52990)
    //     0xa4b190: ldr             x1, [x17, #0x778]
    // 0xa4b194: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b194: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b198: LoadField: r0 = r24->field_17
    //     0xa4b198: ldur            x0, [x24, #0x17]
    // 0xa4b19c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b1a0, size: 0x48
    // 0xa4b1a0: EnterFrame
    //     0xa4b1a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b1a4: mov             fp, SP
    // 0xa4b1a8: ldr             x0, [fp, #0x10]
    // 0xa4b1ac: LoadField: r1 = r0->field_17
    //     0xa4b1ac: ldur            w1, [x0, #0x17]
    // 0xa4b1b0: DecompressPointer r1
    //     0xa4b1b0: add             x1, x1, HEAP, lsl #32
    // 0xa4b1b4: CheckStackOverflow
    //     0xa4b1b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b1b8: cmp             SP, x16
    //     0xa4b1bc: b.ls            #0xa4b1e0
    // 0xa4b1c0: LoadField: r0 = r1->field_f
    //     0xa4b1c0: ldur            w0, [x1, #0xf]
    // 0xa4b1c4: DecompressPointer r0
    //     0xa4b1c4: add             x0, x0, HEAP, lsl #32
    // 0xa4b1c8: SaveReg r0
    //     0xa4b1c8: str             x0, [SP, #-8]!
    // 0xa4b1cc: r0 = dispose()
    //     0xa4b1cc: bl              #0xa52990  ; [package:flutter/src/material/slider.dart] _SliderState::dispose
    // 0xa4b1d0: add             SP, SP, #8
    // 0xa4b1d4: LeaveFrame
    //     0xa4b1d4: mov             SP, fp
    //     0xa4b1d8: ldp             fp, lr, [SP], #0x10
    // 0xa4b1dc: ret
    //     0xa4b1dc: ret             
    // 0xa4b1e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b1e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b1e4: b               #0xa4b1c0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa52990, size: 0x160
    // 0xa52990: EnterFrame
    //     0xa52990: stp             fp, lr, [SP, #-0x10]!
    //     0xa52994: mov             fp, SP
    // 0xa52998: CheckStackOverflow
    //     0xa52998: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa5299c: cmp             SP, x16
    //     0xa529a0: b.ls            #0xa52ab8
    // 0xa529a4: ldr             x0, [fp, #0x10]
    // 0xa529a8: LoadField: r1 = r0->field_2b
    //     0xa529a8: ldur            w1, [x0, #0x2b]
    // 0xa529ac: DecompressPointer r1
    //     0xa529ac: add             x1, x1, HEAP, lsl #32
    // 0xa529b0: cmp             w1, NULL
    // 0xa529b4: b.eq            #0xa529c8
    // 0xa529b8: SaveReg r1
    //     0xa529b8: str             x1, [SP, #-8]!
    // 0xa529bc: r0 = cancel()
    //     0xa529bc: bl              #0x50f4b4  ; [dart:isolate] _Timer::cancel
    // 0xa529c0: add             SP, SP, #8
    // 0xa529c4: ldr             x0, [fp, #0x10]
    // 0xa529c8: LoadField: r1 = r0->field_1b
    //     0xa529c8: ldur            w1, [x0, #0x1b]
    // 0xa529cc: DecompressPointer r1
    //     0xa529cc: add             x1, x1, HEAP, lsl #32
    // 0xa529d0: r16 = Sentinel
    //     0xa529d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa529d4: cmp             w1, w16
    // 0xa529d8: b.eq            #0xa52ac0
    // 0xa529dc: SaveReg r1
    //     0xa529dc: str             x1, [SP, #-8]!
    // 0xa529e0: r0 = dispose()
    //     0xa529e0: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa529e4: add             SP, SP, #8
    // 0xa529e8: ldr             x0, [fp, #0x10]
    // 0xa529ec: LoadField: r1 = r0->field_1f
    //     0xa529ec: ldur            w1, [x0, #0x1f]
    // 0xa529f0: DecompressPointer r1
    //     0xa529f0: add             x1, x1, HEAP, lsl #32
    // 0xa529f4: r16 = Sentinel
    //     0xa529f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa529f8: cmp             w1, w16
    // 0xa529fc: b.eq            #0xa52acc
    // 0xa52a00: SaveReg r1
    //     0xa52a00: str             x1, [SP, #-8]!
    // 0xa52a04: r0 = dispose()
    //     0xa52a04: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa52a08: add             SP, SP, #8
    // 0xa52a0c: ldr             x0, [fp, #0x10]
    // 0xa52a10: LoadField: r1 = r0->field_23
    //     0xa52a10: ldur            w1, [x0, #0x23]
    // 0xa52a14: DecompressPointer r1
    //     0xa52a14: add             x1, x1, HEAP, lsl #32
    // 0xa52a18: r16 = Sentinel
    //     0xa52a18: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52a1c: cmp             w1, w16
    // 0xa52a20: b.eq            #0xa52ad8
    // 0xa52a24: SaveReg r1
    //     0xa52a24: str             x1, [SP, #-8]!
    // 0xa52a28: r0 = dispose()
    //     0xa52a28: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa52a2c: add             SP, SP, #8
    // 0xa52a30: ldr             x0, [fp, #0x10]
    // 0xa52a34: LoadField: r1 = r0->field_27
    //     0xa52a34: ldur            w1, [x0, #0x27]
    // 0xa52a38: DecompressPointer r1
    //     0xa52a38: add             x1, x1, HEAP, lsl #32
    // 0xa52a3c: r16 = Sentinel
    //     0xa52a3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa52a40: cmp             w1, w16
    // 0xa52a44: b.eq            #0xa52ae4
    // 0xa52a48: SaveReg r1
    //     0xa52a48: str             x1, [SP, #-8]!
    // 0xa52a4c: r0 = dispose()
    //     0xa52a4c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa52a50: add             SP, SP, #8
    // 0xa52a54: ldr             x0, [fp, #0x10]
    // 0xa52a58: LoadField: r1 = r0->field_4f
    //     0xa52a58: ldur            w1, [x0, #0x4f]
    // 0xa52a5c: DecompressPointer r1
    //     0xa52a5c: add             x1, x1, HEAP, lsl #32
    // 0xa52a60: cmp             w1, NULL
    // 0xa52a64: b.eq            #0xa52a7c
    // 0xa52a68: SaveReg r1
    //     0xa52a68: str             x1, [SP, #-8]!
    // 0xa52a6c: r0 = remove()
    //     0xa52a6c: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0xa52a70: add             SP, SP, #8
    // 0xa52a74: ldr             x0, [fp, #0x10]
    // 0xa52a78: StoreField: r0->field_4f = rNULL
    //     0xa52a78: stur            NULL, [x0, #0x4f]
    // 0xa52a7c: LoadField: r1 = r0->field_3f
    //     0xa52a7c: ldur            w1, [x0, #0x3f]
    // 0xa52a80: DecompressPointer r1
    //     0xa52a80: add             x1, x1, HEAP, lsl #32
    // 0xa52a84: cmp             w1, NULL
    // 0xa52a88: b.eq            #0xa52a98
    // 0xa52a8c: SaveReg r1
    //     0xa52a8c: str             x1, [SP, #-8]!
    // 0xa52a90: r0 = dispose()
    //     0xa52a90: bl              #0xa6b1e4  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::dispose
    // 0xa52a94: add             SP, SP, #8
    // 0xa52a98: ldr             x16, [fp, #0x10]
    // 0xa52a9c: SaveReg r16
    //     0xa52a9c: str             x16, [SP, #-8]!
    // 0xa52aa0: r0 = dispose()
    //     0xa52aa0: bl              #0xa52af0  ; [package:flutter/src/material/slider.dart] __SliderState&State&TickerProviderStateMixin::dispose
    // 0xa52aa4: add             SP, SP, #8
    // 0xa52aa8: r0 = Null
    //     0xa52aa8: mov             x0, NULL
    // 0xa52aac: LeaveFrame
    //     0xa52aac: mov             SP, fp
    //     0xa52ab0: ldp             fp, lr, [SP], #0x10
    // 0xa52ab4: ret
    //     0xa52ab4: ret             
    // 0xa52ab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa52ab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa52abc: b               #0xa529a4
    // 0xa52ac0: r9 = overlayController
    //     0xa52ac0: add             x9, PP, #0x55, lsl #12  ; [pp+0x55820] Field <_SliderState@810231897.overlayController>: late (offset: 0x1c)
    //     0xa52ac4: ldr             x9, [x9, #0x820]
    // 0xa52ac8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52ac8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa52acc: r9 = valueIndicatorController
    //     0xa52acc: add             x9, PP, #0x55, lsl #12  ; [pp+0x55828] Field <_SliderState@810231897.valueIndicatorController>: late (offset: 0x20)
    //     0xa52ad0: ldr             x9, [x9, #0x828]
    // 0xa52ad4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52ad4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa52ad8: r9 = enableController
    //     0xa52ad8: add             x9, PP, #0x55, lsl #12  ; [pp+0x55830] Field <_SliderState@810231897.enableController>: late (offset: 0x24)
    //     0xa52adc: ldr             x9, [x9, #0x830]
    // 0xa52ae0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52ae0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa52ae4: r9 = positionController
    //     0xa52ae4: add             x9, PP, #0x55, lsl #12  ; [pp+0x55838] Field <_SliderState@810231897.positionController>: late (offset: 0x28)
    //     0xa52ae8: ldr             x9, [x9, #0x838]
    // 0xa52aec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa52aec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3602, size: 0x10, field offset: 0xc
//   const constructor, 
class _ValueIndicatorRenderObjectWidget extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6d3314, size: 0x7c
    // 0x6d3314: EnterFrame
    //     0x6d3314: stp             fp, lr, [SP, #-0x10]!
    //     0x6d3318: mov             fp, SP
    // 0x6d331c: ldr             x0, [fp, #0x10]
    // 0x6d3320: r2 = Null
    //     0x6d3320: mov             x2, NULL
    // 0x6d3324: r1 = Null
    //     0x6d3324: mov             x1, NULL
    // 0x6d3328: r4 = 59
    //     0x6d3328: mov             x4, #0x3b
    // 0x6d332c: branchIfSmi(r0, 0x6d3338)
    //     0x6d332c: tbz             w0, #0, #0x6d3338
    // 0x6d3330: r4 = LoadClassIdInstr(r0)
    //     0x6d3330: ldur            x4, [x0, #-1]
    //     0x6d3334: ubfx            x4, x4, #0xc, #0x14
    // 0x6d3338: cmp             x4, #0x98a
    // 0x6d333c: b.eq            #0x6d3354
    // 0x6d3340: r8 = _RenderValueIndicator
    //     0x6d3340: add             x8, PP, #0x56, lsl #12  ; [pp+0x56c00] Type: _RenderValueIndicator
    //     0x6d3344: ldr             x8, [x8, #0xc00]
    // 0x6d3348: r3 = Null
    //     0x6d3348: add             x3, PP, #0x56, lsl #12  ; [pp+0x56c08] Null
    //     0x6d334c: ldr             x3, [x3, #0xc08]
    // 0x6d3350: r0 = DefaultTypeTest()
    //     0x6d3350: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6d3354: ldr             x1, [fp, #0x20]
    // 0x6d3358: LoadField: r0 = r1->field_b
    //     0x6d3358: ldur            w0, [x1, #0xb]
    // 0x6d335c: DecompressPointer r0
    //     0x6d335c: add             x0, x0, HEAP, lsl #32
    // 0x6d3360: ldr             x1, [fp, #0x10]
    // 0x6d3364: StoreField: r1->field_63 = r0
    //     0x6d3364: stur            w0, [x1, #0x63]
    //     0x6d3368: ldurb           w16, [x1, #-1]
    //     0x6d336c: ldurb           w17, [x0, #-1]
    //     0x6d3370: and             x16, x17, x16, lsr #2
    //     0x6d3374: tst             x16, HEAP, lsr #32
    //     0x6d3378: b.eq            #0x6d3380
    //     0x6d337c: bl              #0xd6826c
    // 0x6d3380: r0 = Null
    //     0x6d3380: mov             x0, NULL
    // 0x6d3384: LeaveFrame
    //     0x6d3384: mov             SP, fp
    //     0x6d3388: ldp             fp, lr, [SP], #0x10
    // 0x6d338c: ret
    //     0x6d338c: ret             
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6f00f8, size: 0x58
    // 0x6f00f8: EnterFrame
    //     0x6f00f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6f00fc: mov             fp, SP
    // 0x6f0100: AllocStack(0x10)
    //     0x6f0100: sub             SP, SP, #0x10
    // 0x6f0104: CheckStackOverflow
    //     0x6f0104: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f0108: cmp             SP, x16
    //     0x6f010c: b.ls            #0x6f0148
    // 0x6f0110: ldr             x0, [fp, #0x18]
    // 0x6f0114: LoadField: r1 = r0->field_b
    //     0x6f0114: ldur            w1, [x0, #0xb]
    // 0x6f0118: DecompressPointer r1
    //     0x6f0118: add             x1, x1, HEAP, lsl #32
    // 0x6f011c: stur            x1, [fp, #-8]
    // 0x6f0120: r0 = _RenderValueIndicator()
    //     0x6f0120: bl              #0x6f0238  ; Allocate_RenderValueIndicatorStub -> _RenderValueIndicator (size=0x68)
    // 0x6f0124: stur            x0, [fp, #-0x10]
    // 0x6f0128: ldur            x16, [fp, #-8]
    // 0x6f012c: stp             x16, x0, [SP, #-0x10]!
    // 0x6f0130: r0 = _RenderValueIndicator()
    //     0x6f0130: bl              #0x6f0150  ; [package:flutter/src/material/slider.dart] _RenderValueIndicator::_RenderValueIndicator
    // 0x6f0134: add             SP, SP, #0x10
    // 0x6f0138: ldur            x0, [fp, #-0x10]
    // 0x6f013c: LeaveFrame
    //     0x6f013c: mov             SP, fp
    //     0x6f0140: ldp             fp, lr, [SP], #0x10
    // 0x6f0144: ret
    //     0x6f0144: ret             
    // 0x6f0148: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f0148: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f014c: b               #0x6f0110
  }
}

// class id: 3603, size: 0x4c, field offset: 0xc
//   const constructor, 
class _SliderRenderObjectWidget extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6cb454, size: 0x228
    // 0x6cb454: EnterFrame
    //     0x6cb454: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb458: mov             fp, SP
    // 0x6cb45c: CheckStackOverflow
    //     0x6cb45c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb460: cmp             SP, x16
    //     0x6cb464: b.ls            #0x6cb674
    // 0x6cb468: ldr             x0, [fp, #0x10]
    // 0x6cb46c: r2 = Null
    //     0x6cb46c: mov             x2, NULL
    // 0x6cb470: r1 = Null
    //     0x6cb470: mov             x1, NULL
    // 0x6cb474: r4 = 59
    //     0x6cb474: mov             x4, #0x3b
    // 0x6cb478: branchIfSmi(r0, 0x6cb484)
    //     0x6cb478: tbz             w0, #0, #0x6cb484
    // 0x6cb47c: r4 = LoadClassIdInstr(r0)
    //     0x6cb47c: ldur            x4, [x0, #-1]
    //     0x6cb480: ubfx            x4, x4, #0xc, #0x14
    // 0x6cb484: cmp             x4, #0x98b
    // 0x6cb488: b.eq            #0x6cb4a0
    // 0x6cb48c: r8 = _RenderSlider
    //     0x6cb48c: add             x8, PP, #0x55, lsl #12  ; [pp+0x55858] Type: _RenderSlider
    //     0x6cb490: ldr             x8, [x8, #0x858]
    // 0x6cb494: r3 = Null
    //     0x6cb494: add             x3, PP, #0x56, lsl #12  ; [pp+0x56410] Null
    //     0x6cb498: ldr             x3, [x3, #0x410]
    // 0x6cb49c: r0 = DefaultTypeTest()
    //     0x6cb49c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6cb4a0: ldr             x16, [fp, #0x10]
    // 0x6cb4a4: stp             NULL, x16, [SP, #-0x10]!
    // 0x6cb4a8: r0 = Shader._()
    //     0x6cb4a8: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6cb4ac: add             SP, SP, #0x10
    // 0x6cb4b0: ldr             x0, [fp, #0x20]
    // 0x6cb4b4: LoadField: d0 = r0->field_b
    //     0x6cb4b4: ldur            d0, [x0, #0xb]
    // 0x6cb4b8: ldr             x16, [fp, #0x10]
    // 0x6cb4bc: SaveReg r16
    //     0x6cb4bc: str             x16, [SP, #-8]!
    // 0x6cb4c0: SaveReg d0
    //     0x6cb4c0: str             d0, [SP, #-8]!
    // 0x6cb4c4: r0 = value=()
    //     0x6cb4c4: bl              #0x6d3274  ; [package:flutter/src/material/slider.dart] _RenderSlider::value=
    // 0x6cb4c8: add             SP, SP, #0x10
    // 0x6cb4cc: ldr             x16, [fp, #0x10]
    // 0x6cb4d0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6cb4d4: r0 = Shader._()
    //     0x6cb4d4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6cb4d8: add             SP, SP, #0x10
    // 0x6cb4dc: ldr             x16, [fp, #0x10]
    // 0x6cb4e0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6cb4e4: r0 = Shader._()
    //     0x6cb4e4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6cb4e8: add             SP, SP, #0x10
    // 0x6cb4ec: ldr             x0, [fp, #0x20]
    // 0x6cb4f0: LoadField: r1 = r0->field_1f
    //     0x6cb4f0: ldur            w1, [x0, #0x1f]
    // 0x6cb4f4: DecompressPointer r1
    //     0x6cb4f4: add             x1, x1, HEAP, lsl #32
    // 0x6cb4f8: ldr             x16, [fp, #0x10]
    // 0x6cb4fc: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb500: r0 = sliderTheme=()
    //     0x6cb500: bl              #0x6d31e8  ; [package:flutter/src/material/slider.dart] _RenderSlider::sliderTheme=
    // 0x6cb504: add             SP, SP, #0x10
    // 0x6cb508: ldr             x0, [fp, #0x20]
    // 0x6cb50c: LoadField: d0 = r0->field_23
    //     0x6cb50c: ldur            d0, [x0, #0x23]
    // 0x6cb510: ldr             x16, [fp, #0x10]
    // 0x6cb514: SaveReg r16
    //     0x6cb514: str             x16, [SP, #-8]!
    // 0x6cb518: SaveReg d0
    //     0x6cb518: str             d0, [SP, #-8]!
    // 0x6cb51c: r0 = textScaleFactor=()
    //     0x6cb51c: bl              #0x6d3184  ; [package:flutter/src/material/slider.dart] _RenderSlider::textScaleFactor=
    // 0x6cb520: add             SP, SP, #0x10
    // 0x6cb524: ldr             x0, [fp, #0x20]
    // 0x6cb528: LoadField: r1 = r0->field_2b
    //     0x6cb528: ldur            w1, [x0, #0x2b]
    // 0x6cb52c: DecompressPointer r1
    //     0x6cb52c: add             x1, x1, HEAP, lsl #32
    // 0x6cb530: ldr             x16, [fp, #0x10]
    // 0x6cb534: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb538: r0 = screenSize=()
    //     0x6cb538: bl              #0x6d30e4  ; [package:flutter/src/material/slider.dart] _RenderSlider::screenSize=
    // 0x6cb53c: add             SP, SP, #0x10
    // 0x6cb540: ldr             x0, [fp, #0x20]
    // 0x6cb544: LoadField: r1 = r0->field_2f
    //     0x6cb544: ldur            w1, [x0, #0x2f]
    // 0x6cb548: DecompressPointer r1
    //     0x6cb548: add             x1, x1, HEAP, lsl #32
    // 0x6cb54c: ldr             x16, [fp, #0x10]
    // 0x6cb550: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb554: r0 = onChanged=()
    //     0x6cb554: bl              #0x6d2f7c  ; [package:flutter/src/material/slider.dart] _RenderSlider::onChanged=
    // 0x6cb558: add             SP, SP, #0x10
    // 0x6cb55c: ldr             x1, [fp, #0x20]
    // 0x6cb560: LoadField: r0 = r1->field_33
    //     0x6cb560: ldur            w0, [x1, #0x33]
    // 0x6cb564: DecompressPointer r0
    //     0x6cb564: add             x0, x0, HEAP, lsl #32
    // 0x6cb568: ldr             x2, [fp, #0x10]
    // 0x6cb56c: StoreField: r2->field_bb = r0
    //     0x6cb56c: stur            w0, [x2, #0xbb]
    //     0x6cb570: ldurb           w16, [x2, #-1]
    //     0x6cb574: ldurb           w17, [x0, #-1]
    //     0x6cb578: and             x16, x17, x16, lsr #2
    //     0x6cb57c: tst             x16, HEAP, lsr #32
    //     0x6cb580: b.eq            #0x6cb588
    //     0x6cb584: bl              #0xd6828c
    // 0x6cb588: LoadField: r0 = r1->field_37
    //     0x6cb588: ldur            w0, [x1, #0x37]
    // 0x6cb58c: DecompressPointer r0
    //     0x6cb58c: add             x0, x0, HEAP, lsl #32
    // 0x6cb590: StoreField: r2->field_bf = r0
    //     0x6cb590: stur            w0, [x2, #0xbf]
    //     0x6cb594: ldurb           w16, [x2, #-1]
    //     0x6cb598: ldurb           w17, [x0, #-1]
    //     0x6cb59c: and             x16, x17, x16, lsr #2
    //     0x6cb5a0: tst             x16, HEAP, lsr #32
    //     0x6cb5a4: b.eq            #0x6cb5ac
    //     0x6cb5a8: bl              #0xd6828c
    // 0x6cb5ac: ldr             x16, [fp, #0x18]
    // 0x6cb5b0: SaveReg r16
    //     0x6cb5b0: str             x16, [SP, #-8]!
    // 0x6cb5b4: r0 = of()
    //     0x6cb5b4: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6cb5b8: add             SP, SP, #8
    // 0x6cb5bc: ldr             x16, [fp, #0x10]
    // 0x6cb5c0: stp             x0, x16, [SP, #-0x10]!
    // 0x6cb5c4: r0 = textDirection=()
    //     0x6cb5c4: bl              #0x6d2ea8  ; [package:flutter/src/material/slider.dart] _RenderSlider::textDirection=
    // 0x6cb5c8: add             SP, SP, #0x10
    // 0x6cb5cc: ldr             x16, [fp, #0x10]
    // 0x6cb5d0: stp             NULL, x16, [SP, #-0x10]!
    // 0x6cb5d4: r0 = Shader._()
    //     0x6cb5d4: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6cb5d8: add             SP, SP, #0x10
    // 0x6cb5dc: ldr             x16, [fp, #0x18]
    // 0x6cb5e0: SaveReg r16
    //     0x6cb5e0: str             x16, [SP, #-8]!
    // 0x6cb5e4: r0 = of()
    //     0x6cb5e4: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x6cb5e8: add             SP, SP, #8
    // 0x6cb5ec: LoadField: r1 = r0->field_1f
    //     0x6cb5ec: ldur            w1, [x0, #0x1f]
    // 0x6cb5f0: DecompressPointer r1
    //     0x6cb5f0: add             x1, x1, HEAP, lsl #32
    // 0x6cb5f4: ldr             x16, [fp, #0x10]
    // 0x6cb5f8: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb5fc: r0 = platform=()
    //     0x6cb5fc: bl              #0x6cbab0  ; [package:flutter/src/material/slider.dart] _RenderSlider::platform=
    // 0x6cb600: add             SP, SP, #0x10
    // 0x6cb604: ldr             x0, [fp, #0x20]
    // 0x6cb608: LoadField: r1 = r0->field_43
    //     0x6cb608: ldur            w1, [x0, #0x43]
    // 0x6cb60c: DecompressPointer r1
    //     0x6cb60c: add             x1, x1, HEAP, lsl #32
    // 0x6cb610: ldr             x16, [fp, #0x10]
    // 0x6cb614: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb618: r0 = hasFocus=()
    //     0x6cb618: bl              #0x6cb844  ; [package:flutter/src/material/slider.dart] _RenderSlider::hasFocus=
    // 0x6cb61c: add             SP, SP, #0x10
    // 0x6cb620: ldr             x0, [fp, #0x20]
    // 0x6cb624: LoadField: r1 = r0->field_47
    //     0x6cb624: ldur            w1, [x0, #0x47]
    // 0x6cb628: DecompressPointer r1
    //     0x6cb628: add             x1, x1, HEAP, lsl #32
    // 0x6cb62c: ldr             x16, [fp, #0x10]
    // 0x6cb630: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb634: r0 = hovering=()
    //     0x6cb634: bl              #0x6cb718  ; [package:flutter/src/material/slider.dart] _RenderSlider::hovering=
    // 0x6cb638: add             SP, SP, #0x10
    // 0x6cb63c: ldr             x16, [fp, #0x18]
    // 0x6cb640: SaveReg r16
    //     0x6cb640: str             x16, [SP, #-8]!
    // 0x6cb644: r0 = of()
    //     0x6cb644: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x6cb648: add             SP, SP, #8
    // 0x6cb64c: LoadField: r1 = r0->field_4b
    //     0x6cb64c: ldur            w1, [x0, #0x4b]
    // 0x6cb650: DecompressPointer r1
    //     0x6cb650: add             x1, x1, HEAP, lsl #32
    // 0x6cb654: ldr             x16, [fp, #0x10]
    // 0x6cb658: stp             x1, x16, [SP, #-0x10]!
    // 0x6cb65c: r0 = gestureSettings=()
    //     0x6cb65c: bl              #0x6cb67c  ; [package:flutter/src/material/slider.dart] _RenderSlider::gestureSettings=
    // 0x6cb660: add             SP, SP, #0x10
    // 0x6cb664: r0 = Null
    //     0x6cb664: mov             x0, NULL
    // 0x6cb668: LeaveFrame
    //     0x6cb668: mov             SP, fp
    //     0x6cb66c: ldp             fp, lr, [SP], #0x10
    // 0x6cb670: ret
    //     0x6cb670: ret             
    // 0x6cb674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb678: b               #0x6cb468
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6eea58, size: 0x1a0
    // 0x6eea58: EnterFrame
    //     0x6eea58: stp             fp, lr, [SP, #-0x10]!
    //     0x6eea5c: mov             fp, SP
    // 0x6eea60: AllocStack(0x78)
    //     0x6eea60: sub             SP, SP, #0x78
    // 0x6eea64: CheckStackOverflow
    //     0x6eea64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6eea68: cmp             SP, x16
    //     0x6eea6c: b.ls            #0x6eebd8
    // 0x6eea70: ldr             x0, [fp, #0x18]
    // 0x6eea74: LoadField: d0 = r0->field_b
    //     0x6eea74: ldur            d0, [x0, #0xb]
    // 0x6eea78: stur            d0, [fp, #-0x78]
    // 0x6eea7c: LoadField: r1 = r0->field_1f
    //     0x6eea7c: ldur            w1, [x0, #0x1f]
    // 0x6eea80: DecompressPointer r1
    //     0x6eea80: add             x1, x1, HEAP, lsl #32
    // 0x6eea84: stur            x1, [fp, #-0x30]
    // 0x6eea88: LoadField: d1 = r0->field_23
    //     0x6eea88: ldur            d1, [x0, #0x23]
    // 0x6eea8c: stur            d1, [fp, #-0x70]
    // 0x6eea90: LoadField: r2 = r0->field_2b
    //     0x6eea90: ldur            w2, [x0, #0x2b]
    // 0x6eea94: DecompressPointer r2
    //     0x6eea94: add             x2, x2, HEAP, lsl #32
    // 0x6eea98: stur            x2, [fp, #-0x28]
    // 0x6eea9c: LoadField: r3 = r0->field_2f
    //     0x6eea9c: ldur            w3, [x0, #0x2f]
    // 0x6eeaa0: DecompressPointer r3
    //     0x6eeaa0: add             x3, x3, HEAP, lsl #32
    // 0x6eeaa4: stur            x3, [fp, #-0x20]
    // 0x6eeaa8: LoadField: r4 = r0->field_33
    //     0x6eeaa8: ldur            w4, [x0, #0x33]
    // 0x6eeaac: DecompressPointer r4
    //     0x6eeaac: add             x4, x4, HEAP, lsl #32
    // 0x6eeab0: stur            x4, [fp, #-0x18]
    // 0x6eeab4: LoadField: r5 = r0->field_37
    //     0x6eeab4: ldur            w5, [x0, #0x37]
    // 0x6eeab8: DecompressPointer r5
    //     0x6eeab8: add             x5, x5, HEAP, lsl #32
    // 0x6eeabc: stur            x5, [fp, #-0x10]
    // 0x6eeac0: LoadField: r6 = r0->field_3f
    //     0x6eeac0: ldur            w6, [x0, #0x3f]
    // 0x6eeac4: DecompressPointer r6
    //     0x6eeac4: add             x6, x6, HEAP, lsl #32
    // 0x6eeac8: stur            x6, [fp, #-8]
    // 0x6eeacc: ldr             x16, [fp, #0x10]
    // 0x6eead0: SaveReg r16
    //     0x6eead0: str             x16, [SP, #-8]!
    // 0x6eead4: r0 = of()
    //     0x6eead4: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6eead8: add             SP, SP, #8
    // 0x6eeadc: stur            x0, [fp, #-0x38]
    // 0x6eeae0: ldr             x16, [fp, #0x10]
    // 0x6eeae4: SaveReg r16
    //     0x6eeae4: str             x16, [SP, #-8]!
    // 0x6eeae8: r0 = of()
    //     0x6eeae8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x6eeaec: add             SP, SP, #8
    // 0x6eeaf0: LoadField: r1 = r0->field_1f
    //     0x6eeaf0: ldur            w1, [x0, #0x1f]
    // 0x6eeaf4: DecompressPointer r1
    //     0x6eeaf4: add             x1, x1, HEAP, lsl #32
    // 0x6eeaf8: ldr             x0, [fp, #0x18]
    // 0x6eeafc: stur            x1, [fp, #-0x50]
    // 0x6eeb00: LoadField: r2 = r0->field_43
    //     0x6eeb00: ldur            w2, [x0, #0x43]
    // 0x6eeb04: DecompressPointer r2
    //     0x6eeb04: add             x2, x2, HEAP, lsl #32
    // 0x6eeb08: stur            x2, [fp, #-0x48]
    // 0x6eeb0c: LoadField: r3 = r0->field_47
    //     0x6eeb0c: ldur            w3, [x0, #0x47]
    // 0x6eeb10: DecompressPointer r3
    //     0x6eeb10: add             x3, x3, HEAP, lsl #32
    // 0x6eeb14: stur            x3, [fp, #-0x40]
    // 0x6eeb18: ldr             x16, [fp, #0x10]
    // 0x6eeb1c: SaveReg r16
    //     0x6eeb1c: str             x16, [SP, #-8]!
    // 0x6eeb20: r0 = of()
    //     0x6eeb20: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x6eeb24: add             SP, SP, #8
    // 0x6eeb28: LoadField: r1 = r0->field_4b
    //     0x6eeb28: ldur            w1, [x0, #0x4b]
    // 0x6eeb2c: DecompressPointer r1
    //     0x6eeb2c: add             x1, x1, HEAP, lsl #32
    // 0x6eeb30: ldur            d0, [fp, #-0x70]
    // 0x6eeb34: stur            x1, [fp, #-0x60]
    // 0x6eeb38: r0 = inline_Allocate_Double()
    //     0x6eeb38: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6eeb3c: add             x0, x0, #0x10
    //     0x6eeb40: cmp             x2, x0
    //     0x6eeb44: b.ls            #0x6eebe0
    //     0x6eeb48: str             x0, [THR, #0x60]  ; THR::top
    //     0x6eeb4c: sub             x0, x0, #0xf
    //     0x6eeb50: mov             x2, #0xd108
    //     0x6eeb54: movk            x2, #3, lsl #16
    //     0x6eeb58: stur            x2, [x0, #-1]
    // 0x6eeb5c: StoreField: r0->field_7 = d0
    //     0x6eeb5c: stur            d0, [x0, #7]
    // 0x6eeb60: stur            x0, [fp, #-0x58]
    // 0x6eeb64: r0 = _RenderSlider()
    //     0x6eeb64: bl              #0x6f00ec  ; Allocate_RenderSliderStub -> _RenderSlider (size=0xd4)
    // 0x6eeb68: stur            x0, [fp, #-0x68]
    // 0x6eeb6c: ldur            x16, [fp, #-0x60]
    // 0x6eeb70: stp             x16, x0, [SP, #-0x10]!
    // 0x6eeb74: ldur            x16, [fp, #-0x48]
    // 0x6eeb78: ldur            lr, [fp, #-0x40]
    // 0x6eeb7c: stp             lr, x16, [SP, #-0x10]!
    // 0x6eeb80: ldur            x16, [fp, #-0x10]
    // 0x6eeb84: ldur            lr, [fp, #-0x18]
    // 0x6eeb88: stp             lr, x16, [SP, #-0x10]!
    // 0x6eeb8c: ldur            x16, [fp, #-0x20]
    // 0x6eeb90: ldur            lr, [fp, #-0x50]
    // 0x6eeb94: stp             lr, x16, [SP, #-0x10]!
    // 0x6eeb98: ldur            x16, [fp, #-0x28]
    // 0x6eeb9c: ldur            lr, [fp, #-0x30]
    // 0x6eeba0: stp             lr, x16, [SP, #-0x10]!
    // 0x6eeba4: ldur            x16, [fp, #-8]
    // 0x6eeba8: ldur            lr, [fp, #-0x38]
    // 0x6eebac: stp             lr, x16, [SP, #-0x10]!
    // 0x6eebb0: ldur            x16, [fp, #-0x58]
    // 0x6eebb4: SaveReg r16
    //     0x6eebb4: str             x16, [SP, #-8]!
    // 0x6eebb8: ldur            d0, [fp, #-0x78]
    // 0x6eebbc: SaveReg d0
    //     0x6eebbc: str             d0, [SP, #-8]!
    // 0x6eebc0: r0 = _RenderSlider()
    //     0x6eebc0: bl              #0x6eebf8  ; [package:flutter/src/material/slider.dart] _RenderSlider::_RenderSlider
    // 0x6eebc4: add             SP, SP, #0x70
    // 0x6eebc8: ldur            x0, [fp, #-0x68]
    // 0x6eebcc: LeaveFrame
    //     0x6eebcc: mov             SP, fp
    //     0x6eebd0: ldp             fp, lr, [SP], #0x10
    // 0x6eebd4: ret
    //     0x6eebd4: ret             
    // 0x6eebd8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eebd8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eebdc: b               #0x6eea70
    // 0x6eebe0: SaveReg d0
    //     0x6eebe0: str             q0, [SP, #-0x10]!
    // 0x6eebe4: SaveReg r1
    //     0x6eebe4: str             x1, [SP, #-8]!
    // 0x6eebe8: r0 = AllocateDouble()
    //     0x6eebe8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6eebec: RestoreReg r1
    //     0x6eebec: ldr             x1, [SP], #8
    // 0x6eebf0: RestoreReg d0
    //     0x6eebf0: ldr             q0, [SP], #0x10
    // 0x6eebf4: b               #0x6eeb5c
  }
}

// class id: 4121, size: 0x64, field offset: 0xc
//   const constructor, 
class Slider extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa415e4, size: 0x4c
    // 0xa415e4: EnterFrame
    //     0xa415e4: stp             fp, lr, [SP, #-0x10]!
    //     0xa415e8: mov             fp, SP
    // 0xa415ec: AllocStack(0x8)
    //     0xa415ec: sub             SP, SP, #8
    // 0xa415f0: CheckStackOverflow
    //     0xa415f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa415f4: cmp             SP, x16
    //     0xa415f8: b.ls            #0xa41628
    // 0xa415fc: r1 = <Slider>
    //     0xa415fc: add             x1, PP, #0x53, lsl #12  ; [pp+0x53038] TypeArguments: <Slider>
    //     0xa41600: ldr             x1, [x1, #0x38]
    // 0xa41604: r0 = _SliderState()
    //     0xa41604: bl              #0xa416c0  ; Allocate_SliderStateStub -> _SliderState (size=0x54)
    // 0xa41608: stur            x0, [fp, #-8]
    // 0xa4160c: SaveReg r0
    //     0xa4160c: str             x0, [SP, #-8]!
    // 0xa41610: r0 = _SliderState()
    //     0xa41610: bl              #0xa41630  ; [package:flutter/src/material/slider.dart] _SliderState::_SliderState
    // 0xa41614: add             SP, SP, #8
    // 0xa41618: ldur            x0, [fp, #-8]
    // 0xa4161c: LeaveFrame
    //     0xa4161c: mov             SP, fp
    //     0xa41620: ldp             fp, lr, [SP], #0x10
    // 0xa41624: ret
    //     0xa41624: ret             
    // 0xa41628: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa41628: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4162c: b               #0xa415fc
  }
}

// class id: 5950, size: 0x14, field offset: 0x14
enum _SliderAdjustmentType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1652c, size: 0x5c
    // 0xb1652c: EnterFrame
    //     0xb1652c: stp             fp, lr, [SP, #-0x10]!
    //     0xb16530: mov             fp, SP
    // 0xb16534: CheckStackOverflow
    //     0xb16534: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb16538: cmp             SP, x16
    //     0xb1653c: b.ls            #0xb16580
    // 0xb16540: r1 = Null
    //     0xb16540: mov             x1, NULL
    // 0xb16544: r2 = 4
    //     0xb16544: mov             x2, #4
    // 0xb16548: r0 = AllocateArray()
    //     0xb16548: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1654c: r17 = "_SliderAdjustmentType."
    //     0xb1654c: add             x17, PP, #0x56, lsl #12  ; [pp+0x56408] "_SliderAdjustmentType."
    //     0xb16550: ldr             x17, [x17, #0x408]
    // 0xb16554: StoreField: r0->field_f = r17
    //     0xb16554: stur            w17, [x0, #0xf]
    // 0xb16558: ldr             x1, [fp, #0x10]
    // 0xb1655c: LoadField: r2 = r1->field_f
    //     0xb1655c: ldur            w2, [x1, #0xf]
    // 0xb16560: DecompressPointer r2
    //     0xb16560: add             x2, x2, HEAP, lsl #32
    // 0xb16564: StoreField: r0->field_13 = r2
    //     0xb16564: stur            w2, [x0, #0x13]
    // 0xb16568: SaveReg r0
    //     0xb16568: str             x0, [SP, #-8]!
    // 0xb1656c: r0 = _interpolate()
    //     0xb1656c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16570: add             SP, SP, #8
    // 0xb16574: LeaveFrame
    //     0xb16574: mov             SP, fp
    //     0xb16578: ldp             fp, lr, [SP], #0x10
    // 0xb1657c: ret
    //     0xb1657c: ret             
    // 0xb16580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16584: b               #0xb16540
  }
}

// class id: 5951, size: 0x14, field offset: 0x14
enum _SliderType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb164d0, size: 0x5c
    // 0xb164d0: EnterFrame
    //     0xb164d0: stp             fp, lr, [SP, #-0x10]!
    //     0xb164d4: mov             fp, SP
    // 0xb164d8: CheckStackOverflow
    //     0xb164d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb164dc: cmp             SP, x16
    //     0xb164e0: b.ls            #0xb16524
    // 0xb164e4: r1 = Null
    //     0xb164e4: mov             x1, NULL
    // 0xb164e8: r2 = 4
    //     0xb164e8: mov             x2, #4
    // 0xb164ec: r0 = AllocateArray()
    //     0xb164ec: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb164f0: r17 = "_SliderType."
    //     0xb164f0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53040] "_SliderType."
    //     0xb164f4: ldr             x17, [x17, #0x40]
    // 0xb164f8: StoreField: r0->field_f = r17
    //     0xb164f8: stur            w17, [x0, #0xf]
    // 0xb164fc: ldr             x1, [fp, #0x10]
    // 0xb16500: LoadField: r2 = r1->field_f
    //     0xb16500: ldur            w2, [x1, #0xf]
    // 0xb16504: DecompressPointer r2
    //     0xb16504: add             x2, x2, HEAP, lsl #32
    // 0xb16508: StoreField: r0->field_13 = r2
    //     0xb16508: stur            w2, [x0, #0x13]
    // 0xb1650c: SaveReg r0
    //     0xb1650c: str             x0, [SP, #-8]!
    // 0xb16510: r0 = _interpolate()
    //     0xb16510: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb16514: add             SP, SP, #8
    // 0xb16518: LeaveFrame
    //     0xb16518: mov             SP, fp
    //     0xb1651c: ldp             fp, lr, [SP], #0x10
    // 0xb16520: ret
    //     0xb16520: ret             
    // 0xb16524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb16524: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb16528: b               #0xb164e4
  }
}

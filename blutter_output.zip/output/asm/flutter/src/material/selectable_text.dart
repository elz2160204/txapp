// lib: , url: package:flutter/src/material/selectable_text.dart

// class id: 1049306, size: 0x8
class :: {
}

// class id: 2147, size: 0x2c, field offset: 0x28
class _SelectableTextSelectionGestureDetectorBuilder extends TextSelectionGestureDetectorBuilder {

  [closure] void onSingleLongTapMoveUpdate(dynamic, LongPressMoveUpdateDetails) {
    // ** addr: 0x86f958, size: 0x4c
    // 0x86f958: EnterFrame
    //     0x86f958: stp             fp, lr, [SP, #-0x10]!
    //     0x86f95c: mov             fp, SP
    // 0x86f960: ldr             x0, [fp, #0x18]
    // 0x86f964: LoadField: r1 = r0->field_17
    //     0x86f964: ldur            w1, [x0, #0x17]
    // 0x86f968: DecompressPointer r1
    //     0x86f968: add             x1, x1, HEAP, lsl #32
    // 0x86f96c: CheckStackOverflow
    //     0x86f96c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86f970: cmp             SP, x16
    //     0x86f974: b.ls            #0x86f99c
    // 0x86f978: LoadField: r0 = r1->field_f
    //     0x86f978: ldur            w0, [x1, #0xf]
    // 0x86f97c: DecompressPointer r0
    //     0x86f97c: add             x0, x0, HEAP, lsl #32
    // 0x86f980: ldr             x16, [fp, #0x10]
    // 0x86f984: stp             x16, x0, [SP, #-0x10]!
    // 0x86f988: r0 = onSingleLongTapMoveUpdate()
    //     0x86f988: bl              #0x86f9a4  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextSelectionGestureDetectorBuilder::onSingleLongTapMoveUpdate
    // 0x86f98c: add             SP, SP, #0x10
    // 0x86f990: LeaveFrame
    //     0x86f990: mov             SP, fp
    //     0x86f994: ldp             fp, lr, [SP], #0x10
    // 0x86f998: ret
    //     0x86f998: ret             
    // 0x86f99c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86f99c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86f9a0: b               #0x86f978
  }
  _ onSingleLongTapMoveUpdate(/* No info */) {
    // ** addr: 0x86f9a4, size: 0xc8
    // 0x86f9a4: EnterFrame
    //     0x86f9a4: stp             fp, lr, [SP, #-0x10]!
    //     0x86f9a8: mov             fp, SP
    // 0x86f9ac: AllocStack(0x10)
    //     0x86f9ac: sub             SP, SP, #0x10
    // 0x86f9b0: CheckStackOverflow
    //     0x86f9b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x86f9b4: cmp             SP, x16
    //     0x86f9b8: b.ls            #0x86fa64
    // 0x86f9bc: ldr             x1, [fp, #0x18]
    // 0x86f9c0: LoadField: r0 = r1->field_7
    //     0x86f9c0: ldur            w0, [x1, #7]
    // 0x86f9c4: DecompressPointer r0
    //     0x86f9c4: add             x0, x0, HEAP, lsl #32
    // 0x86f9c8: r2 = LoadClassIdInstr(r0)
    //     0x86f9c8: ldur            x2, [x0, #-1]
    //     0x86f9cc: ubfx            x2, x2, #0xc, #0x14
    // 0x86f9d0: SaveReg r0
    //     0x86f9d0: str             x0, [SP, #-8]!
    // 0x86f9d4: mov             x0, x2
    // 0x86f9d8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x86f9d8: sub             lr, x0, #1, lsl #12
    //     0x86f9dc: ldr             lr, [x21, lr, lsl #3]
    //     0x86f9e0: blr             lr
    // 0x86f9e4: add             SP, SP, #8
    // 0x86f9e8: tbnz            w0, #4, #0x86fa54
    // 0x86f9ec: ldr             x0, [fp, #0x10]
    // 0x86f9f0: ldr             x16, [fp, #0x18]
    // 0x86f9f4: SaveReg r16
    //     0x86f9f4: str             x16, [SP, #-8]!
    // 0x86f9f8: r0 = renderEditable()
    //     0x86f9f8: bl              #0x86cf28  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::renderEditable
    // 0x86f9fc: add             SP, SP, #8
    // 0x86fa00: mov             x1, x0
    // 0x86fa04: ldr             x0, [fp, #0x10]
    // 0x86fa08: stur            x1, [fp, #-0x10]
    // 0x86fa0c: LoadField: r2 = r0->field_7
    //     0x86fa0c: ldur            w2, [x0, #7]
    // 0x86fa10: DecompressPointer r2
    //     0x86fa10: add             x2, x2, HEAP, lsl #32
    // 0x86fa14: stur            x2, [fp, #-8]
    // 0x86fa18: LoadField: r3 = r0->field_f
    //     0x86fa18: ldur            w3, [x0, #0xf]
    // 0x86fa1c: DecompressPointer r3
    //     0x86fa1c: add             x3, x3, HEAP, lsl #32
    // 0x86fa20: stp             x3, x2, [SP, #-0x10]!
    // 0x86fa24: r0 = -()
    //     0x86fa24: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x86fa28: add             SP, SP, #0x10
    // 0x86fa2c: ldur            x16, [fp, #-0x10]
    // 0x86fa30: r30 = Instance_SelectionChangedCause
    //     0x86fa30: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x86fa34: ldr             lr, [lr, #0x6b0]
    // 0x86fa38: stp             lr, x16, [SP, #-0x10]!
    // 0x86fa3c: ldur            x16, [fp, #-8]
    // 0x86fa40: stp             x16, x0, [SP, #-0x10]!
    // 0x86fa44: r4 = const [0, 0x4, 0x4, 0x3, to, 0x3, null]
    //     0x86fa44: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2de10] List(7) [0, 0x4, 0x4, 0x3, "to", 0x3, Null]
    //     0x86fa48: ldr             x4, [x4, #0xe10]
    // 0x86fa4c: r0 = selectWordsInRange()
    //     0x86fa4c: bl              #0x86df44  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectWordsInRange
    // 0x86fa50: add             SP, SP, #0x20
    // 0x86fa54: r0 = Null
    //     0x86fa54: mov             x0, NULL
    // 0x86fa58: LeaveFrame
    //     0x86fa58: mov             SP, fp
    //     0x86fa5c: ldp             fp, lr, [SP], #0x10
    // 0x86fa60: ret
    //     0x86fa60: ret             
    // 0x86fa64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x86fa64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x86fa68: b               #0x86f9bc
  }
  [closure] void onSingleLongTapStart(dynamic, LongPressStartDetails) {
    // ** addr: 0x86fff8, size: 0x4c
    // 0x86fff8: EnterFrame
    //     0x86fff8: stp             fp, lr, [SP, #-0x10]!
    //     0x86fffc: mov             fp, SP
    // 0x870000: ldr             x0, [fp, #0x18]
    // 0x870004: LoadField: r1 = r0->field_17
    //     0x870004: ldur            w1, [x0, #0x17]
    // 0x870008: DecompressPointer r1
    //     0x870008: add             x1, x1, HEAP, lsl #32
    // 0x87000c: CheckStackOverflow
    //     0x87000c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870010: cmp             SP, x16
    //     0x870014: b.ls            #0x87003c
    // 0x870018: LoadField: r0 = r1->field_f
    //     0x870018: ldur            w0, [x1, #0xf]
    // 0x87001c: DecompressPointer r0
    //     0x87001c: add             x0, x0, HEAP, lsl #32
    // 0x870020: ldr             x16, [fp, #0x10]
    // 0x870024: stp             x16, x0, [SP, #-0x10]!
    // 0x870028: r0 = onSingleLongTapStart()
    //     0x870028: bl              #0x870044  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextSelectionGestureDetectorBuilder::onSingleLongTapStart
    // 0x87002c: add             SP, SP, #0x10
    // 0x870030: LeaveFrame
    //     0x870030: mov             SP, fp
    //     0x870034: ldp             fp, lr, [SP], #0x10
    // 0x870038: ret
    //     0x870038: ret             
    // 0x87003c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x87003c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870040: b               #0x870018
  }
  _ onSingleLongTapStart(/* No info */) {
    // ** addr: 0x870044, size: 0xac
    // 0x870044: EnterFrame
    //     0x870044: stp             fp, lr, [SP, #-0x10]!
    //     0x870048: mov             fp, SP
    // 0x87004c: CheckStackOverflow
    //     0x87004c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870050: cmp             SP, x16
    //     0x870054: b.ls            #0x8700e4
    // 0x870058: ldr             x1, [fp, #0x18]
    // 0x87005c: LoadField: r0 = r1->field_7
    //     0x87005c: ldur            w0, [x1, #7]
    // 0x870060: DecompressPointer r0
    //     0x870060: add             x0, x0, HEAP, lsl #32
    // 0x870064: r2 = LoadClassIdInstr(r0)
    //     0x870064: ldur            x2, [x0, #-1]
    //     0x870068: ubfx            x2, x2, #0xc, #0x14
    // 0x87006c: SaveReg r0
    //     0x87006c: str             x0, [SP, #-8]!
    // 0x870070: mov             x0, x2
    // 0x870074: r0 = GDT[cid_x0 + -0x1000]()
    //     0x870074: sub             lr, x0, #1, lsl #12
    //     0x870078: ldr             lr, [x21, lr, lsl #3]
    //     0x87007c: blr             lr
    // 0x870080: add             SP, SP, #8
    // 0x870084: tbnz            w0, #4, #0x8700d4
    // 0x870088: ldr             x0, [fp, #0x18]
    // 0x87008c: SaveReg r0
    //     0x87008c: str             x0, [SP, #-8]!
    // 0x870090: r0 = renderEditable()
    //     0x870090: bl              #0x86cf28  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::renderEditable
    // 0x870094: add             SP, SP, #8
    // 0x870098: r16 = Instance_SelectionChangedCause
    //     0x870098: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x87009c: ldr             x16, [x16, #0x6b0]
    // 0x8700a0: stp             x16, x0, [SP, #-0x10]!
    // 0x8700a4: r0 = selectWord()
    //     0x8700a4: bl              #0x86dee4  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectWord
    // 0x8700a8: add             SP, SP, #0x10
    // 0x8700ac: ldr             x0, [fp, #0x18]
    // 0x8700b0: LoadField: r1 = r0->field_27
    //     0x8700b0: ldur            w1, [x0, #0x27]
    // 0x8700b4: DecompressPointer r1
    //     0x8700b4: add             x1, x1, HEAP, lsl #32
    // 0x8700b8: LoadField: r0 = r1->field_f
    //     0x8700b8: ldur            w0, [x1, #0xf]
    // 0x8700bc: DecompressPointer r0
    //     0x8700bc: add             x0, x0, HEAP, lsl #32
    // 0x8700c0: cmp             w0, NULL
    // 0x8700c4: b.eq            #0x8700ec
    // 0x8700c8: SaveReg r0
    //     0x8700c8: str             x0, [SP, #-8]!
    // 0x8700cc: r0 = forLongPress()
    //     0x8700cc: bl              #0x83bf00  ; [package:flutter/src/material/feedback.dart] Feedback::forLongPress
    // 0x8700d0: add             SP, SP, #8
    // 0x8700d4: r0 = Null
    //     0x8700d4: mov             x0, NULL
    // 0x8700d8: LeaveFrame
    //     0x8700d8: mov             SP, fp
    //     0x8700dc: ldp             fp, lr, [SP], #0x10
    // 0x8700e0: ret
    //     0x8700e0: ret             
    // 0x8700e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8700e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8700e8: b               #0x870058
    // 0x8700ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8700ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onSingleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0x8703ec, size: 0x4c
    // 0x8703ec: EnterFrame
    //     0x8703ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8703f0: mov             fp, SP
    // 0x8703f4: ldr             x0, [fp, #0x18]
    // 0x8703f8: LoadField: r1 = r0->field_17
    //     0x8703f8: ldur            w1, [x0, #0x17]
    // 0x8703fc: DecompressPointer r1
    //     0x8703fc: add             x1, x1, HEAP, lsl #32
    // 0x870400: CheckStackOverflow
    //     0x870400: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870404: cmp             SP, x16
    //     0x870408: b.ls            #0x870430
    // 0x87040c: LoadField: r0 = r1->field_f
    //     0x87040c: ldur            w0, [x1, #0xf]
    // 0x870410: DecompressPointer r0
    //     0x870410: add             x0, x0, HEAP, lsl #32
    // 0x870414: ldr             x16, [fp, #0x10]
    // 0x870418: stp             x16, x0, [SP, #-0x10]!
    // 0x87041c: r0 = onSingleTapUp()
    //     0x87041c: bl              #0x870438  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextSelectionGestureDetectorBuilder::onSingleTapUp
    // 0x870420: add             SP, SP, #0x10
    // 0x870424: LeaveFrame
    //     0x870424: mov             SP, fp
    //     0x870428: ldp             fp, lr, [SP], #0x10
    // 0x87042c: ret
    //     0x87042c: ret             
    // 0x870430: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870430: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870434: b               #0x87040c
  }
  _ onSingleTapUp(/* No info */) {
    // ** addr: 0x870438, size: 0x164
    // 0x870438: EnterFrame
    //     0x870438: stp             fp, lr, [SP, #-0x10]!
    //     0x87043c: mov             fp, SP
    // 0x870440: AllocStack(0x8)
    //     0x870440: sub             SP, SP, #8
    // 0x870444: CheckStackOverflow
    //     0x870444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870448: cmp             SP, x16
    //     0x87044c: b.ls            #0x870588
    // 0x870450: ldr             x1, [fp, #0x18]
    // 0x870454: LoadField: r2 = r1->field_7
    //     0x870454: ldur            w2, [x1, #7]
    // 0x870458: DecompressPointer r2
    //     0x870458: add             x2, x2, HEAP, lsl #32
    // 0x87045c: stur            x2, [fp, #-8]
    // 0x870460: r0 = LoadClassIdInstr(r2)
    //     0x870460: ldur            x0, [x2, #-1]
    //     0x870464: ubfx            x0, x0, #0xc, #0x14
    // 0x870468: SaveReg r2
    //     0x870468: str             x2, [SP, #-8]!
    // 0x87046c: r0 = GDT[cid_x0 + -0xffb]()
    //     0x87046c: sub             lr, x0, #0xffb
    //     0x870470: ldr             lr, [x21, lr, lsl #3]
    //     0x870474: blr             lr
    // 0x870478: add             SP, SP, #8
    // 0x87047c: SaveReg r0
    //     0x87047c: str             x0, [SP, #-8]!
    // 0x870480: r0 = currentState()
    //     0x870480: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x870484: add             SP, SP, #8
    // 0x870488: cmp             w0, NULL
    // 0x87048c: b.eq            #0x870590
    // 0x870490: SaveReg r0
    //     0x870490: str             x0, [SP, #-8]!
    // 0x870494: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x870494: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x870498: r0 = hideToolbar()
    //     0x870498: bl              #0x83e778  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::hideToolbar
    // 0x87049c: add             SP, SP, #8
    // 0x8704a0: ldur            x0, [fp, #-8]
    // 0x8704a4: r1 = LoadClassIdInstr(r0)
    //     0x8704a4: ldur            x1, [x0, #-1]
    //     0x8704a8: ubfx            x1, x1, #0xc, #0x14
    // 0x8704ac: SaveReg r0
    //     0x8704ac: str             x0, [SP, #-8]!
    // 0x8704b0: mov             x0, x1
    // 0x8704b4: r0 = GDT[cid_x0 + -0x1000]()
    //     0x8704b4: sub             lr, x0, #1, lsl #12
    //     0x8704b8: ldr             lr, [x21, lr, lsl #3]
    //     0x8704bc: blr             lr
    // 0x8704c0: add             SP, SP, #8
    // 0x8704c4: tbnz            w0, #4, #0x87055c
    // 0x8704c8: ldr             x0, [fp, #0x18]
    // 0x8704cc: LoadField: r1 = r0->field_27
    //     0x8704cc: ldur            w1, [x0, #0x27]
    // 0x8704d0: DecompressPointer r1
    //     0x8704d0: add             x1, x1, HEAP, lsl #32
    // 0x8704d4: LoadField: r2 = r1->field_f
    //     0x8704d4: ldur            w2, [x1, #0xf]
    // 0x8704d8: DecompressPointer r2
    //     0x8704d8: add             x2, x2, HEAP, lsl #32
    // 0x8704dc: cmp             w2, NULL
    // 0x8704e0: b.eq            #0x870594
    // 0x8704e4: SaveReg r2
    //     0x8704e4: str             x2, [SP, #-8]!
    // 0x8704e8: r0 = of()
    //     0x8704e8: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x8704ec: add             SP, SP, #8
    // 0x8704f0: LoadField: r1 = r0->field_1f
    //     0x8704f0: ldur            w1, [x0, #0x1f]
    // 0x8704f4: DecompressPointer r1
    //     0x8704f4: add             x1, x1, HEAP, lsl #32
    // 0x8704f8: LoadField: r0 = r1->field_7
    //     0x8704f8: ldur            x0, [x1, #7]
    // 0x8704fc: cmp             x0, #2
    // 0x870500: b.gt            #0x870510
    // 0x870504: cmp             x0, #1
    // 0x870508: b.gt            #0x870520
    // 0x87050c: b               #0x870540
    // 0x870510: cmp             x0, #4
    // 0x870514: b.gt            #0x870540
    // 0x870518: cmp             x0, #3
    // 0x87051c: b.le            #0x870540
    // 0x870520: ldr             x16, [fp, #0x18]
    // 0x870524: SaveReg r16
    //     0x870524: str             x16, [SP, #-8]!
    // 0x870528: r0 = renderEditable()
    //     0x870528: bl              #0x86cf28  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::renderEditable
    // 0x87052c: add             SP, SP, #8
    // 0x870530: SaveReg r0
    //     0x870530: str             x0, [SP, #-8]!
    // 0x870534: r0 = selectWordEdge()
    //     0x870534: bl              #0x87059c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectWordEdge
    // 0x870538: add             SP, SP, #8
    // 0x87053c: b               #0x87055c
    // 0x870540: ldr             x16, [fp, #0x18]
    // 0x870544: SaveReg r16
    //     0x870544: str             x16, [SP, #-8]!
    // 0x870548: r0 = renderEditable()
    //     0x870548: bl              #0x86cf28  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::renderEditable
    // 0x87054c: add             SP, SP, #8
    // 0x870550: SaveReg r0
    //     0x870550: str             x0, [SP, #-8]!
    // 0x870554: r0 = selectPosition()
    //     0x870554: bl              #0x86f518  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectPosition
    // 0x870558: add             SP, SP, #8
    // 0x87055c: ldr             x1, [fp, #0x18]
    // 0x870560: LoadField: r2 = r1->field_27
    //     0x870560: ldur            w2, [x1, #0x27]
    // 0x870564: DecompressPointer r2
    //     0x870564: add             x2, x2, HEAP, lsl #32
    // 0x870568: LoadField: r1 = r2->field_b
    //     0x870568: ldur            w1, [x2, #0xb]
    // 0x87056c: DecompressPointer r1
    //     0x87056c: add             x1, x1, HEAP, lsl #32
    // 0x870570: cmp             w1, NULL
    // 0x870574: b.eq            #0x870598
    // 0x870578: r0 = Null
    //     0x870578: mov             x0, NULL
    // 0x87057c: LeaveFrame
    //     0x87057c: mov             SP, fp
    //     0x870580: ldp             fp, lr, [SP], #0x10
    // 0x870584: ret
    //     0x870584: ret             
    // 0x870588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870588: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x87058c: b               #0x870450
    // 0x870590: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x870590: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x870594: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x870594: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x870598: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x870598: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onForcePressStart(dynamic, ForcePressDetails) {
    // ** addr: 0x870e5c, size: 0x4c
    // 0x870e5c: EnterFrame
    //     0x870e5c: stp             fp, lr, [SP, #-0x10]!
    //     0x870e60: mov             fp, SP
    // 0x870e64: ldr             x0, [fp, #0x18]
    // 0x870e68: LoadField: r1 = r0->field_17
    //     0x870e68: ldur            w1, [x0, #0x17]
    // 0x870e6c: DecompressPointer r1
    //     0x870e6c: add             x1, x1, HEAP, lsl #32
    // 0x870e70: CheckStackOverflow
    //     0x870e70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870e74: cmp             SP, x16
    //     0x870e78: b.ls            #0x870ea0
    // 0x870e7c: LoadField: r0 = r1->field_f
    //     0x870e7c: ldur            w0, [x1, #0xf]
    // 0x870e80: DecompressPointer r0
    //     0x870e80: add             x0, x0, HEAP, lsl #32
    // 0x870e84: ldr             x16, [fp, #0x10]
    // 0x870e88: stp             x16, x0, [SP, #-0x10]!
    // 0x870e8c: r0 = onForcePressStart()
    //     0x870e8c: bl              #0x870ea8  ; [package:flutter/src/material/selectable_text.dart] _SelectableTextSelectionGestureDetectorBuilder::onForcePressStart
    // 0x870e90: add             SP, SP, #0x10
    // 0x870e94: LeaveFrame
    //     0x870e94: mov             SP, fp
    //     0x870e98: ldp             fp, lr, [SP], #0x10
    // 0x870e9c: ret
    //     0x870e9c: ret             
    // 0x870ea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870ea0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870ea4: b               #0x870e7c
  }
  _ onForcePressStart(/* No info */) {
    // ** addr: 0x870ea8, size: 0xcc
    // 0x870ea8: EnterFrame
    //     0x870ea8: stp             fp, lr, [SP, #-0x10]!
    //     0x870eac: mov             fp, SP
    // 0x870eb0: AllocStack(0x8)
    //     0x870eb0: sub             SP, SP, #8
    // 0x870eb4: CheckStackOverflow
    //     0x870eb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x870eb8: cmp             SP, x16
    //     0x870ebc: b.ls            #0x870f68
    // 0x870ec0: ldr             x16, [fp, #0x18]
    // 0x870ec4: ldr             lr, [fp, #0x10]
    // 0x870ec8: stp             lr, x16, [SP, #-0x10]!
    // 0x870ecc: r0 = onForcePressStart()
    //     0x870ecc: bl              #0x870f74  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionGestureDetectorBuilder::onForcePressStart
    // 0x870ed0: add             SP, SP, #0x10
    // 0x870ed4: ldr             x1, [fp, #0x18]
    // 0x870ed8: LoadField: r2 = r1->field_7
    //     0x870ed8: ldur            w2, [x1, #7]
    // 0x870edc: DecompressPointer r2
    //     0x870edc: add             x2, x2, HEAP, lsl #32
    // 0x870ee0: stur            x2, [fp, #-8]
    // 0x870ee4: r0 = LoadClassIdInstr(r2)
    //     0x870ee4: ldur            x0, [x2, #-1]
    //     0x870ee8: ubfx            x0, x0, #0xc, #0x14
    // 0x870eec: SaveReg r2
    //     0x870eec: str             x2, [SP, #-8]!
    // 0x870ef0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x870ef0: sub             lr, x0, #1, lsl #12
    //     0x870ef4: ldr             lr, [x21, lr, lsl #3]
    //     0x870ef8: blr             lr
    // 0x870efc: add             SP, SP, #8
    // 0x870f00: tbnz            w0, #4, #0x870f58
    // 0x870f04: ldr             x0, [fp, #0x18]
    // 0x870f08: LoadField: r1 = r0->field_b
    //     0x870f08: ldur            w1, [x0, #0xb]
    // 0x870f0c: DecompressPointer r1
    //     0x870f0c: add             x1, x1, HEAP, lsl #32
    // 0x870f10: tbnz            w1, #4, #0x870f58
    // 0x870f14: ldur            x0, [fp, #-8]
    // 0x870f18: r1 = LoadClassIdInstr(r0)
    //     0x870f18: ldur            x1, [x0, #-1]
    //     0x870f1c: ubfx            x1, x1, #0xc, #0x14
    // 0x870f20: SaveReg r0
    //     0x870f20: str             x0, [SP, #-8]!
    // 0x870f24: mov             x0, x1
    // 0x870f28: r0 = GDT[cid_x0 + -0xffb]()
    //     0x870f28: sub             lr, x0, #0xffb
    //     0x870f2c: ldr             lr, [x21, lr, lsl #3]
    //     0x870f30: blr             lr
    // 0x870f34: add             SP, SP, #8
    // 0x870f38: SaveReg r0
    //     0x870f38: str             x0, [SP, #-8]!
    // 0x870f3c: r0 = currentState()
    //     0x870f3c: bl              #0x515598  ; [package:flutter/src/widgets/framework.dart] GlobalKey::currentState
    // 0x870f40: add             SP, SP, #8
    // 0x870f44: cmp             w0, NULL
    // 0x870f48: b.eq            #0x870f70
    // 0x870f4c: SaveReg r0
    //     0x870f4c: str             x0, [SP, #-8]!
    // 0x870f50: r0 = showToolbar()
    //     0x870f50: bl              #0xcd92fc  ; [package:flutter/src/widgets/editable_text.dart] EditableTextState::showToolbar
    // 0x870f54: add             SP, SP, #8
    // 0x870f58: r0 = Null
    //     0x870f58: mov             x0, NULL
    // 0x870f5c: LeaveFrame
    //     0x870f5c: mov             SP, fp
    //     0x870f60: ldp             fp, lr, [SP], #0x10
    // 0x870f64: ret
    //     0x870f64: ret             
    // 0x870f68: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x870f68: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x870f6c: b               #0x870ec0
    // 0x870f70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x870f70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4873, size: 0x30, field offset: 0x2c
class _TextSpanEditingController extends TextEditingController {
}

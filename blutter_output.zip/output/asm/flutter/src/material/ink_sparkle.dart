// lib: , url: package:flutter/src/material/ink_sparkle.dart

// class id: 1049257, size: 0x8
class :: {
}

// class id: 2192, size: 0xc, field offset: 0x8
//   const constructor, 
class _InkSparkleFactory extends InteractiveInkFeatureFactory {

  static void initializeShader() {
    // ** addr: 0x858844, size: 0x7c
    // 0x858844: EnterFrame
    //     0x858844: stp             fp, lr, [SP, #-0x10]!
    //     0x858848: mov             fp, SP
    // 0x85884c: AllocStack(0x8)
    //     0x85884c: sub             SP, SP, #8
    // 0x858850: CheckStackOverflow
    //     0x858850: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x858854: cmp             SP, x16
    //     0x858858: b.ls            #0x8588b8
    // 0x85885c: r0 = LoadStaticField(0xda8)
    //     0x85885c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x858860: ldr             x0, [x0, #0x1b50]
    // 0x858864: tbz             w0, #4, #0x8588a8
    // 0x858868: r0 = fromAsset()
    //     0x858868: bl              #0x8588c0  ; [dart:ui] FragmentProgram::fromAsset
    // 0x85886c: r1 = Function '<anonymous closure>': static.
    //     0x85886c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e410] AnonymousClosure: static (0x858d5c), in [package:flutter/src/material/ink_sparkle.dart] _InkSparkleFactory::initializeShader (0x858844)
    //     0x858870: ldr             x1, [x1, #0x410]
    // 0x858874: r2 = Null
    //     0x858874: mov             x2, NULL
    // 0x858878: stur            x0, [fp, #-8]
    // 0x85887c: r0 = AllocateClosure()
    //     0x85887c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x858880: r16 = <Null?>
    //     0x858880: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0x858884: ldur            lr, [fp, #-8]
    // 0x858888: stp             lr, x16, [SP, #-0x10]!
    // 0x85888c: SaveReg r0
    //     0x85888c: str             x0, [SP, #-8]!
    // 0x858890: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x858890: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x858894: r0 = then()
    //     0x858894: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x858898: add             SP, SP, #0x18
    // 0x85889c: r1 = true
    //     0x85889c: add             x1, NULL, #0x20  ; true
    // 0x8588a0: StoreStaticField(0xda8, r1)
    //     0x8588a0: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x8588a4: str             x1, [x2, #0x1b50]
    // 0x8588a8: r0 = Null
    //     0x8588a8: mov             x0, NULL
    // 0x8588ac: LeaveFrame
    //     0x8588ac: mov             SP, fp
    //     0x8588b0: ldp             fp, lr, [SP], #0x10
    // 0x8588b4: ret
    //     0x8588b4: ret             
    // 0x8588b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8588b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8588bc: b               #0x85885c
  }
  [closure] static Null <anonymous closure>(dynamic, FragmentProgram) {
    // ** addr: 0x858d5c, size: 0x14
    // 0x858d5c: ldr             x1, [SP]
    // 0x858d60: StoreStaticField(0xdac, r1)
    //     0x858d60: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0x858d64: str             x1, [x2, #0x1b58]
    // 0x858d68: r0 = Null
    //     0x858d68: mov             x0, NULL
    // 0x858d6c: ret
    //     0x858d6c: ret             
  }
}

// class id: 2197, size: 0x58, field offset: 0x18
class InkSparkle extends InteractiveInkFeature {

  late AnimationController _animationController; // offset: 0x18
  late final FragmentShader _fragmentShader; // offset: 0x50
  late double _turbulenceSeed; // offset: 0x2c
  late Animation<double> _radiusScale; // offset: 0x20
  late Animation<double> _alpha; // offset: 0x24
  late Animation<double> _sparkleAlpha; // offset: 0x28
  late Animation<Vector2> _center; // offset: 0x1c

  _ InkSparkle(/* No info */) {
    // ** addr: 0x857410, size: 0xb04
    // 0x857410: EnterFrame
    //     0x857410: stp             fp, lr, [SP, #-0x10]!
    //     0x857414: mov             fp, SP
    // 0x857418: AllocStack(0x28)
    //     0x857418: sub             SP, SP, #0x28
    // 0x85741c: r1 = Sentinel
    //     0x85741c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x857420: r0 = false
    //     0x857420: add             x0, NULL, #0x30  ; false
    // 0x857424: CheckStackOverflow
    //     0x857424: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x857428: cmp             SP, x16
    //     0x85742c: b.ls            #0x857e98
    // 0x857430: ldr             x2, [fp, #0x68]
    // 0x857434: StoreField: r2->field_17 = r1
    //     0x857434: stur            w1, [x2, #0x17]
    // 0x857438: StoreField: r2->field_1b = r1
    //     0x857438: stur            w1, [x2, #0x1b]
    // 0x85743c: StoreField: r2->field_1f = r1
    //     0x85743c: stur            w1, [x2, #0x1f]
    // 0x857440: StoreField: r2->field_23 = r1
    //     0x857440: stur            w1, [x2, #0x23]
    // 0x857444: StoreField: r2->field_27 = r1
    //     0x857444: stur            w1, [x2, #0x27]
    // 0x857448: StoreField: r2->field_2b = r1
    //     0x857448: stur            w1, [x2, #0x2b]
    // 0x85744c: StoreField: r2->field_4f = r1
    //     0x85744c: stur            w1, [x2, #0x4f]
    // 0x857450: StoreField: r2->field_53 = r0
    //     0x857450: stur            w0, [x2, #0x53]
    // 0x857454: ldr             x0, [fp, #0x58]
    // 0x857458: StoreField: r2->field_2f = r0
    //     0x857458: stur            w0, [x2, #0x2f]
    //     0x85745c: ldurb           w16, [x2, #-1]
    //     0x857460: ldurb           w17, [x0, #-1]
    //     0x857464: and             x16, x17, x16, lsr #2
    //     0x857468: tst             x16, HEAP, lsr #32
    //     0x85746c: b.eq            #0x857474
    //     0x857470: bl              #0xd6828c
    // 0x857474: ldr             x0, [fp, #0x30]
    // 0x857478: StoreField: r2->field_33 = r0
    //     0x857478: stur            w0, [x2, #0x33]
    //     0x85747c: ldurb           w16, [x2, #-1]
    //     0x857480: ldurb           w17, [x0, #-1]
    //     0x857484: and             x16, x17, x16, lsr #2
    //     0x857488: tst             x16, HEAP, lsr #32
    //     0x85748c: b.eq            #0x857494
    //     0x857490: bl              #0xd6828c
    // 0x857494: ldr             x0, [fp, #0x60]
    // 0x857498: cmp             w0, NULL
    // 0x85749c: b.ne            #0x8574a8
    // 0x8574a0: r0 = Instance_BorderRadius
    //     0x8574a0: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0x8574a4: ldr             x0, [x0, #0x2c0]
    // 0x8574a8: ldr             x1, [fp, #0x28]
    // 0x8574ac: StoreField: r2->field_37 = r0
    //     0x8574ac: stur            w0, [x2, #0x37]
    //     0x8574b0: ldurb           w16, [x2, #-1]
    //     0x8574b4: ldurb           w17, [x0, #-1]
    //     0x8574b8: and             x16, x17, x16, lsr #2
    //     0x8574bc: tst             x16, HEAP, lsr #32
    //     0x8574c0: b.eq            #0x8574c8
    //     0x8574c4: bl              #0xd6828c
    // 0x8574c8: ldr             x0, [fp, #0x40]
    // 0x8574cc: StoreField: r2->field_3b = r0
    //     0x8574cc: stur            w0, [x2, #0x3b]
    //     0x8574d0: ldurb           w16, [x2, #-1]
    //     0x8574d4: ldurb           w17, [x0, #-1]
    //     0x8574d8: and             x16, x17, x16, lsr #2
    //     0x8574dc: tst             x16, HEAP, lsr #32
    //     0x8574e0: b.eq            #0x8574e8
    //     0x8574e4: bl              #0xd6828c
    // 0x8574e8: ldr             x0, [fp, #0x10]
    // 0x8574ec: StoreField: r2->field_4b = r0
    //     0x8574ec: stur            w0, [x2, #0x4b]
    //     0x8574f0: ldurb           w16, [x2, #-1]
    //     0x8574f4: ldurb           w17, [x0, #-1]
    //     0x8574f8: and             x16, x17, x16, lsr #2
    //     0x8574fc: tst             x16, HEAP, lsr #32
    //     0x857500: b.eq            #0x857508
    //     0x857504: bl              #0xd6828c
    // 0x857508: cmp             w1, NULL
    // 0x85750c: b.ne            #0x85752c
    // 0x857510: ldr             x16, [fp, #0x18]
    // 0x857514: ldr             lr, [fp, #0x20]
    // 0x857518: stp             lr, x16, [SP, #-0x10]!
    // 0x85751c: r0 = _getTargetRadius()
    //     0x85751c: bl              #0x857088  ; [package:flutter/src/material/ink_ripple.dart] ::_getTargetRadius
    // 0x857520: add             SP, SP, #0x10
    // 0x857524: mov             v1.16b, v0.16b
    // 0x857528: b               #0x857534
    // 0x85752c: LoadField: d0 = r1->field_7
    //     0x85752c: ldur            d0, [x1, #7]
    // 0x857530: mov             v1.16b, v0.16b
    // 0x857534: ldr             x0, [fp, #0x68]
    // 0x857538: ldr             x2, [fp, #0x20]
    // 0x85753c: ldr             x1, [fp, #0x18]
    // 0x857540: d0 = 2.300000
    //     0x857540: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e378] IMM: double(2.3) from 0x4002666666666666
    //     0x857544: ldr             d0, [x17, #0x378]
    // 0x857548: fmul            d2, d1, d0
    // 0x85754c: StoreField: r0->field_3f = d2
    //     0x85754c: stur            d2, [x0, #0x3f]
    // 0x857550: r1 = 1
    //     0x857550: mov             x1, #1
    // 0x857554: r0 = AllocateContext()
    //     0x857554: bl              #0xd68aa4  ; AllocateContextStub
    // 0x857558: mov             x1, x0
    // 0x85755c: ldr             x0, [fp, #0x18]
    // 0x857560: StoreField: r1->field_f = r0
    //     0x857560: stur            w0, [x1, #0xf]
    // 0x857564: ldr             x2, [fp, #0x20]
    // 0x857568: cmp             w2, NULL
    // 0x85756c: b.eq            #0x85757c
    // 0x857570: mov             x1, x0
    // 0x857574: mov             x0, x2
    // 0x857578: b               #0x8575a4
    // 0x85757c: ldr             x2, [fp, #0x50]
    // 0x857580: tbnz            w2, #4, #0x85759c
    // 0x857584: mov             x2, x1
    // 0x857588: r1 = Function '<anonymous closure>': static.
    //     0x857588: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e380] AnonymousClosure: static (0x8573a4), of [package:flutter/src/material/ink_ripple.dart] 
    //     0x85758c: ldr             x1, [x1, #0x380]
    // 0x857590: r0 = AllocateClosure()
    //     0x857590: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x857594: ldr             x1, [fp, #0x18]
    // 0x857598: b               #0x8575a4
    // 0x85759c: ldr             x1, [fp, #0x18]
    // 0x8575a0: r0 = Null
    //     0x8575a0: mov             x0, NULL
    // 0x8575a4: ldr             x2, [fp, #0x68]
    // 0x8575a8: ldr             x4, [fp, #0x48]
    // 0x8575ac: ldr             x3, [fp, #0x30]
    // 0x8575b0: StoreField: r2->field_47 = r0
    //     0x8575b0: stur            w0, [x2, #0x47]
    //     0x8575b4: tbz             w0, #0, #0x8575d0
    //     0x8575b8: ldurb           w16, [x2, #-1]
    //     0x8575bc: ldurb           w17, [x0, #-1]
    //     0x8575c0: and             x16, x17, x16, lsr #2
    //     0x8575c4: tst             x16, HEAP, lsr #32
    //     0x8575c8: b.eq            #0x8575d0
    //     0x8575cc: bl              #0xd6828c
    // 0x8575d0: ldr             x0, [fp, #0x58]
    // 0x8575d4: StoreField: r2->field_13 = r0
    //     0x8575d4: stur            w0, [x2, #0x13]
    //     0x8575d8: ldurb           w16, [x2, #-1]
    //     0x8575dc: ldurb           w17, [x0, #-1]
    //     0x8575e0: and             x16, x17, x16, lsr #2
    //     0x8575e4: tst             x16, HEAP, lsr #32
    //     0x8575e8: b.eq            #0x8575f0
    //     0x8575ec: bl              #0xd6828c
    // 0x8575f0: mov             x0, x1
    // 0x8575f4: StoreField: r2->field_b = r0
    //     0x8575f4: stur            w0, [x2, #0xb]
    //     0x8575f8: ldurb           w16, [x2, #-1]
    //     0x8575fc: ldurb           w17, [x0, #-1]
    //     0x857600: and             x16, x17, x16, lsr #2
    //     0x857604: tst             x16, HEAP, lsr #32
    //     0x857608: b.eq            #0x857610
    //     0x85760c: bl              #0xd6828c
    // 0x857610: ldr             x0, [fp, #0x38]
    // 0x857614: StoreField: r2->field_f = r0
    //     0x857614: stur            w0, [x2, #0xf]
    //     0x857618: ldurb           w16, [x2, #-1]
    //     0x85761c: ldurb           w17, [x0, #-1]
    //     0x857620: and             x16, x17, x16, lsr #2
    //     0x857624: tst             x16, HEAP, lsr #32
    //     0x857628: b.eq            #0x857630
    //     0x85762c: bl              #0xd6828c
    // 0x857630: mov             x0, x4
    // 0x857634: StoreField: r2->field_7 = r0
    //     0x857634: stur            w0, [x2, #7]
    //     0x857638: ldurb           w16, [x2, #-1]
    //     0x85763c: ldurb           w17, [x0, #-1]
    //     0x857640: and             x16, x17, x16, lsr #2
    //     0x857644: tst             x16, HEAP, lsr #32
    //     0x857648: b.eq            #0x857650
    //     0x85764c: bl              #0xd6828c
    // 0x857650: r0 = initializeShader()
    //     0x857650: bl              #0x858844  ; [package:flutter/src/material/ink_sparkle.dart] _InkSparkleFactory::initializeShader
    // 0x857654: ldr             x16, [fp, #0x48]
    // 0x857658: ldr             lr, [fp, #0x68]
    // 0x85765c: stp             lr, x16, [SP, #-0x10]!
    // 0x857660: r0 = addInkFeature()
    //     0x857660: bl              #0x7b266c  ; [package:flutter/src/material/material.dart] _RenderInkFeatures::addInkFeature
    // 0x857664: add             SP, SP, #0x10
    // 0x857668: ldr             x0, [fp, #0x48]
    // 0x85766c: LoadField: r2 = r0->field_63
    //     0x85766c: ldur            w2, [x0, #0x63]
    // 0x857670: DecompressPointer r2
    //     0x857670: add             x2, x2, HEAP, lsl #32
    // 0x857674: stur            x2, [fp, #-8]
    // 0x857678: r1 = <double>
    //     0x857678: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x85767c: r0 = AnimationController()
    //     0x85767c: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x857680: stur            x0, [fp, #-0x10]
    // 0x857684: ldur            x16, [fp, #-8]
    // 0x857688: stp             x16, x0, [SP, #-0x10]!
    // 0x85768c: r16 = Instance_Duration
    //     0x85768c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e388] Obj!Duration@b67bd1
    //     0x857690: ldr             x16, [x16, #0x388]
    // 0x857694: SaveReg r16
    //     0x857694: str             x16, [SP, #-8]!
    // 0x857698: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x857698: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x85769c: ldr             x4, [x4, #0xa0]
    // 0x8576a0: r0 = AnimationController()
    //     0x8576a0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x8576a4: add             SP, SP, #0x18
    // 0x8576a8: r1 = 1
    //     0x8576a8: mov             x1, #1
    // 0x8576ac: r0 = AllocateContext()
    //     0x8576ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8576b0: mov             x1, x0
    // 0x8576b4: ldr             x0, [fp, #0x48]
    // 0x8576b8: StoreField: r1->field_f = r0
    //     0x8576b8: stur            w0, [x1, #0xf]
    // 0x8576bc: mov             x2, x1
    // 0x8576c0: r1 = Function 'markNeedsPaint':.
    //     0x8576c0: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x8576c4: ldr             x1, [x1, #0xf60]
    // 0x8576c8: r0 = AllocateClosure()
    //     0x8576c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8576cc: ldur            x16, [fp, #-0x10]
    // 0x8576d0: stp             x0, x16, [SP, #-0x10]!
    // 0x8576d4: r0 = addActionListener()
    //     0x8576d4: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x8576d8: add             SP, SP, #0x10
    // 0x8576dc: r1 = 1
    //     0x8576dc: mov             x1, #1
    // 0x8576e0: r0 = AllocateContext()
    //     0x8576e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8576e4: mov             x1, x0
    // 0x8576e8: ldr             x0, [fp, #0x68]
    // 0x8576ec: StoreField: r1->field_f = r0
    //     0x8576ec: stur            w0, [x1, #0xf]
    // 0x8576f0: mov             x2, x1
    // 0x8576f4: r1 = Function '_handleStatusChanged@758321118':.
    //     0x8576f4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e390] AnonymousClosure: (0x858d70), in [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_handleStatusChanged (0x858dbc)
    //     0x8576f8: ldr             x1, [x1, #0x390]
    // 0x8576fc: r0 = AllocateClosure()
    //     0x8576fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x857700: ldur            x16, [fp, #-0x10]
    // 0x857704: stp             x0, x16, [SP, #-0x10]!
    // 0x857708: r0 = addStatusListener()
    //     0x857708: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x85770c: add             SP, SP, #0x10
    // 0x857710: ldur            x16, [fp, #-0x10]
    // 0x857714: SaveReg r16
    //     0x857714: str             x16, [SP, #-8]!
    // 0x857718: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x857718: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x85771c: r0 = forward()
    //     0x85771c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x857720: add             SP, SP, #8
    // 0x857724: ldur            x0, [fp, #-0x10]
    // 0x857728: ldr             x2, [fp, #0x68]
    // 0x85772c: StoreField: r2->field_17 = r0
    //     0x85772c: stur            w0, [x2, #0x17]
    //     0x857730: ldurb           w16, [x2, #-1]
    //     0x857734: ldurb           w17, [x0, #-1]
    //     0x857738: and             x16, x17, x16, lsr #2
    //     0x85773c: tst             x16, HEAP, lsr #32
    //     0x857740: b.eq            #0x857748
    //     0x857744: bl              #0xd6828c
    // 0x857748: r1 = <double>
    //     0x857748: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x85774c: r0 = CurveTween()
    //     0x85774c: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x857750: mov             x2, x0
    // 0x857754: r0 = Instance_Cubic
    //     0x857754: add             x0, PP, #0x15, lsl #12  ; [pp+0x152c8] Obj!Cubic<double>@b4f311
    //     0x857758: ldr             x0, [x0, #0x2c8]
    // 0x85775c: stur            x2, [fp, #-8]
    // 0x857760: StoreField: r2->field_b = r0
    //     0x857760: stur            w0, [x2, #0xb]
    // 0x857764: r1 = <double>
    //     0x857764: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857768: r0 = TweenSequenceItem()
    //     0x857768: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x85776c: mov             x2, x0
    // 0x857770: ldur            x0, [fp, #-8]
    // 0x857774: stur            x2, [fp, #-0x10]
    // 0x857778: StoreField: r2->field_b = r0
    //     0x857778: stur            w0, [x2, #0xb]
    // 0x85777c: d0 = 75.000000
    //     0x85777c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e398] IMM: double(75) from 0x4052c00000000000
    //     0x857780: ldr             d0, [x17, #0x398]
    // 0x857784: StoreField: r2->field_f = d0
    //     0x857784: stur            d0, [x2, #0xf]
    // 0x857788: r1 = <double>
    //     0x857788: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x85778c: r0 = ConstantTween()
    //     0x85778c: bl              #0x858838  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0x857790: mov             x2, x0
    // 0x857794: r0 = 1.000000
    //     0x857794: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857798: stur            x2, [fp, #-8]
    // 0x85779c: StoreField: r2->field_b = r0
    //     0x85779c: stur            w0, [x2, #0xb]
    // 0x8577a0: StoreField: r2->field_f = r0
    //     0x8577a0: stur            w0, [x2, #0xf]
    // 0x8577a4: r1 = <double>
    //     0x8577a4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8577a8: r0 = TweenSequenceItem()
    //     0x8577a8: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x8577ac: mov             x3, x0
    // 0x8577b0: ldur            x0, [fp, #-8]
    // 0x8577b4: stur            x3, [fp, #-0x18]
    // 0x8577b8: StoreField: r3->field_b = r0
    //     0x8577b8: stur            w0, [x3, #0xb]
    // 0x8577bc: d0 = 25.000000
    //     0x8577bc: fmov            d0, #25.00000000
    // 0x8577c0: StoreField: r3->field_f = d0
    //     0x8577c0: stur            d0, [x3, #0xf]
    // 0x8577c4: r1 = Null
    //     0x8577c4: mov             x1, NULL
    // 0x8577c8: r2 = 4
    //     0x8577c8: mov             x2, #4
    // 0x8577cc: r0 = AllocateArray()
    //     0x8577cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8577d0: mov             x2, x0
    // 0x8577d4: ldur            x0, [fp, #-0x10]
    // 0x8577d8: stur            x2, [fp, #-8]
    // 0x8577dc: StoreField: r2->field_f = r0
    //     0x8577dc: stur            w0, [x2, #0xf]
    // 0x8577e0: ldur            x0, [fp, #-0x18]
    // 0x8577e4: StoreField: r2->field_13 = r0
    //     0x8577e4: stur            w0, [x2, #0x13]
    // 0x8577e8: r1 = <TweenSequenceItem<double>>
    //     0x8577e8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a0] TypeArguments: <TweenSequenceItem<double>>
    //     0x8577ec: ldr             x1, [x1, #0x3a0]
    // 0x8577f0: r0 = AllocateGrowableArray()
    //     0x8577f0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x8577f4: mov             x2, x0
    // 0x8577f8: ldur            x0, [fp, #-8]
    // 0x8577fc: stur            x2, [fp, #-0x10]
    // 0x857800: StoreField: r2->field_f = r0
    //     0x857800: stur            w0, [x2, #0xf]
    // 0x857804: r0 = 4
    //     0x857804: mov             x0, #4
    // 0x857808: StoreField: r2->field_b = r0
    //     0x857808: stur            w0, [x2, #0xb]
    // 0x85780c: r1 = <double>
    //     0x85780c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857810: r0 = TweenSequence()
    //     0x857810: bl              #0x7b7b18  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0x857814: stur            x0, [fp, #-8]
    // 0x857818: ldur            x16, [fp, #-0x10]
    // 0x85781c: stp             x16, x0, [SP, #-0x10]!
    // 0x857820: r0 = TweenSequence()
    //     0x857820: bl              #0x7b7778  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0x857824: add             SP, SP, #0x10
    // 0x857828: ldr             x0, [fp, #0x68]
    // 0x85782c: LoadField: r1 = r0->field_17
    //     0x85782c: ldur            w1, [x0, #0x17]
    // 0x857830: DecompressPointer r1
    //     0x857830: add             x1, x1, HEAP, lsl #32
    // 0x857834: ldur            x16, [fp, #-8]
    // 0x857838: stp             x1, x16, [SP, #-0x10]!
    // 0x85783c: r0 = animate()
    //     0x85783c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x857840: add             SP, SP, #0x10
    // 0x857844: ldr             x3, [fp, #0x68]
    // 0x857848: StoreField: r3->field_1f = r0
    //     0x857848: stur            w0, [x3, #0x1f]
    //     0x85784c: ldurb           w16, [x3, #-1]
    //     0x857850: ldurb           w17, [x0, #-1]
    //     0x857854: and             x16, x17, x16, lsr #2
    //     0x857858: tst             x16, HEAP, lsr #32
    //     0x85785c: b.eq            #0x857864
    //     0x857860: bl              #0xd682ac
    // 0x857864: ldr             x0, [fp, #0x30]
    // 0x857868: LoadField: d0 = r0->field_7
    //     0x857868: ldur            d0, [x0, #7]
    // 0x85786c: LoadField: d1 = r0->field_f
    //     0x85786c: ldur            d1, [x0, #0xf]
    // 0x857870: stur            d1, [fp, #-0x28]
    // 0x857874: r0 = inline_Allocate_Double()
    //     0x857874: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x857878: add             x0, x0, #0x10
    //     0x85787c: cmp             x1, x0
    //     0x857880: b.ls            #0x857ea0
    //     0x857884: str             x0, [THR, #0x60]  ; THR::top
    //     0x857888: sub             x0, x0, #0xf
    //     0x85788c: mov             x1, #0xd108
    //     0x857890: movk            x1, #3, lsl #16
    //     0x857894: stur            x1, [x0, #-1]
    // 0x857898: StoreField: r0->field_7 = d0
    //     0x857898: stur            d0, [x0, #7]
    // 0x85789c: stur            x0, [fp, #-8]
    // 0x8578a0: r1 = Null
    //     0x8578a0: mov             x1, NULL
    // 0x8578a4: r2 = 4
    //     0x8578a4: mov             x2, #4
    // 0x8578a8: r0 = AllocateArray()
    //     0x8578a8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8578ac: mov             x2, x0
    // 0x8578b0: ldur            x0, [fp, #-8]
    // 0x8578b4: stur            x2, [fp, #-0x10]
    // 0x8578b8: StoreField: r2->field_f = r0
    //     0x8578b8: stur            w0, [x2, #0xf]
    // 0x8578bc: ldur            d0, [fp, #-0x28]
    // 0x8578c0: r0 = inline_Allocate_Double()
    //     0x8578c0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8578c4: add             x0, x0, #0x10
    //     0x8578c8: cmp             x1, x0
    //     0x8578cc: b.ls            #0x857eb8
    //     0x8578d0: str             x0, [THR, #0x60]  ; THR::top
    //     0x8578d4: sub             x0, x0, #0xf
    //     0x8578d8: mov             x1, #0xd108
    //     0x8578dc: movk            x1, #3, lsl #16
    //     0x8578e0: stur            x1, [x0, #-1]
    // 0x8578e4: StoreField: r0->field_7 = d0
    //     0x8578e4: stur            d0, [x0, #7]
    // 0x8578e8: StoreField: r2->field_13 = r0
    //     0x8578e8: stur            w0, [x2, #0x13]
    // 0x8578ec: r1 = <double>
    //     0x8578ec: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8578f0: r0 = AllocateGrowableArray()
    //     0x8578f0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x8578f4: mov             x1, x0
    // 0x8578f8: ldur            x0, [fp, #-0x10]
    // 0x8578fc: StoreField: r1->field_f = r0
    //     0x8578fc: stur            w0, [x1, #0xf]
    // 0x857900: r2 = 4
    //     0x857900: mov             x2, #4
    // 0x857904: StoreField: r1->field_b = r2
    //     0x857904: stur            w2, [x1, #0xb]
    // 0x857908: stp             x1, NULL, [SP, #-0x10]!
    // 0x85790c: r0 = Vector2.array()
    //     0x85790c: bl              #0x857f94  ; [package:vector_math/vector_math_64.dart] Vector2::Vector2.array
    // 0x857910: add             SP, SP, #0x10
    // 0x857914: mov             x3, x0
    // 0x857918: ldr             x0, [fp, #0x18]
    // 0x85791c: stur            x3, [fp, #-0x10]
    // 0x857920: LoadField: r1 = r0->field_57
    //     0x857920: ldur            w1, [x0, #0x57]
    // 0x857924: DecompressPointer r1
    //     0x857924: add             x1, x1, HEAP, lsl #32
    // 0x857928: cmp             w1, NULL
    // 0x85792c: b.eq            #0x857ed0
    // 0x857930: LoadField: d0 = r1->field_7
    //     0x857930: ldur            d0, [x1, #7]
    // 0x857934: d1 = 2.000000
    //     0x857934: fmov            d1, #2.00000000
    // 0x857938: fdiv            d2, d0, d1
    // 0x85793c: LoadField: d0 = r1->field_f
    //     0x85793c: ldur            d0, [x1, #0xf]
    // 0x857940: fdiv            d3, d0, d1
    // 0x857944: stur            d3, [fp, #-0x28]
    // 0x857948: r0 = inline_Allocate_Double()
    //     0x857948: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x85794c: add             x0, x0, #0x10
    //     0x857950: cmp             x1, x0
    //     0x857954: b.ls            #0x857ed4
    //     0x857958: str             x0, [THR, #0x60]  ; THR::top
    //     0x85795c: sub             x0, x0, #0xf
    //     0x857960: mov             x1, #0xd108
    //     0x857964: movk            x1, #3, lsl #16
    //     0x857968: stur            x1, [x0, #-1]
    // 0x85796c: StoreField: r0->field_7 = d2
    //     0x85796c: stur            d2, [x0, #7]
    // 0x857970: stur            x0, [fp, #-8]
    // 0x857974: r1 = Null
    //     0x857974: mov             x1, NULL
    // 0x857978: r2 = 4
    //     0x857978: mov             x2, #4
    // 0x85797c: r0 = AllocateArray()
    //     0x85797c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x857980: mov             x2, x0
    // 0x857984: ldur            x0, [fp, #-8]
    // 0x857988: stur            x2, [fp, #-0x18]
    // 0x85798c: StoreField: r2->field_f = r0
    //     0x85798c: stur            w0, [x2, #0xf]
    // 0x857990: ldur            d0, [fp, #-0x28]
    // 0x857994: r0 = inline_Allocate_Double()
    //     0x857994: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x857998: add             x0, x0, #0x10
    //     0x85799c: cmp             x1, x0
    //     0x8579a0: b.ls            #0x857eec
    //     0x8579a4: str             x0, [THR, #0x60]  ; THR::top
    //     0x8579a8: sub             x0, x0, #0xf
    //     0x8579ac: mov             x1, #0xd108
    //     0x8579b0: movk            x1, #3, lsl #16
    //     0x8579b4: stur            x1, [x0, #-1]
    // 0x8579b8: StoreField: r0->field_7 = d0
    //     0x8579b8: stur            d0, [x0, #7]
    // 0x8579bc: StoreField: r2->field_13 = r0
    //     0x8579bc: stur            w0, [x2, #0x13]
    // 0x8579c0: r1 = <double>
    //     0x8579c0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x8579c4: r0 = AllocateGrowableArray()
    //     0x8579c4: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x8579c8: mov             x1, x0
    // 0x8579cc: ldur            x0, [fp, #-0x18]
    // 0x8579d0: StoreField: r1->field_f = r0
    //     0x8579d0: stur            w0, [x1, #0xf]
    // 0x8579d4: r2 = 4
    //     0x8579d4: mov             x2, #4
    // 0x8579d8: StoreField: r1->field_b = r2
    //     0x8579d8: stur            w2, [x1, #0xb]
    // 0x8579dc: stp             x1, NULL, [SP, #-0x10]!
    // 0x8579e0: r0 = Vector2.array()
    //     0x8579e0: bl              #0x857f94  ; [package:vector_math/vector_math_64.dart] Vector2::Vector2.array
    // 0x8579e4: add             SP, SP, #0x10
    // 0x8579e8: r1 = <Vector2>
    //     0x8579e8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a8] TypeArguments: <Vector2>
    //     0x8579ec: ldr             x1, [x1, #0x3a8]
    // 0x8579f0: stur            x0, [fp, #-8]
    // 0x8579f4: r0 = Tween()
    //     0x8579f4: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x8579f8: mov             x2, x0
    // 0x8579fc: ldur            x0, [fp, #-0x10]
    // 0x857a00: stur            x2, [fp, #-0x18]
    // 0x857a04: StoreField: r2->field_b = r0
    //     0x857a04: stur            w0, [x2, #0xb]
    // 0x857a08: ldur            x0, [fp, #-8]
    // 0x857a0c: StoreField: r2->field_f = r0
    //     0x857a0c: stur            w0, [x2, #0xf]
    // 0x857a10: r1 = <double>
    //     0x857a10: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857a14: r0 = Tween()
    //     0x857a14: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x857a18: mov             x2, x0
    // 0x857a1c: r0 = 0.000000
    //     0x857a1c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x857a20: stur            x2, [fp, #-8]
    // 0x857a24: StoreField: r2->field_b = r0
    //     0x857a24: stur            w0, [x2, #0xb]
    // 0x857a28: r3 = 1.000000
    //     0x857a28: ldr             x3, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857a2c: StoreField: r2->field_f = r3
    //     0x857a2c: stur            w3, [x2, #0xf]
    // 0x857a30: r1 = <double>
    //     0x857a30: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857a34: r0 = TweenSequenceItem()
    //     0x857a34: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857a38: mov             x2, x0
    // 0x857a3c: ldur            x0, [fp, #-8]
    // 0x857a40: stur            x2, [fp, #-0x10]
    // 0x857a44: StoreField: r2->field_b = r0
    //     0x857a44: stur            w0, [x2, #0xb]
    // 0x857a48: d0 = 50.000000
    //     0x857a48: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0x857a4c: ldr             d0, [x17, #0x980]
    // 0x857a50: StoreField: r2->field_f = d0
    //     0x857a50: stur            d0, [x2, #0xf]
    // 0x857a54: r1 = <double>
    //     0x857a54: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857a58: r0 = ConstantTween()
    //     0x857a58: bl              #0x858838  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0x857a5c: mov             x2, x0
    // 0x857a60: r0 = 1.000000
    //     0x857a60: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857a64: stur            x2, [fp, #-8]
    // 0x857a68: StoreField: r2->field_b = r0
    //     0x857a68: stur            w0, [x2, #0xb]
    // 0x857a6c: StoreField: r2->field_f = r0
    //     0x857a6c: stur            w0, [x2, #0xf]
    // 0x857a70: r1 = <double>
    //     0x857a70: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857a74: r0 = TweenSequenceItem()
    //     0x857a74: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857a78: mov             x3, x0
    // 0x857a7c: ldur            x0, [fp, #-8]
    // 0x857a80: stur            x3, [fp, #-0x20]
    // 0x857a84: StoreField: r3->field_b = r0
    //     0x857a84: stur            w0, [x3, #0xb]
    // 0x857a88: d0 = 50.000000
    //     0x857a88: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0x857a8c: ldr             d0, [x17, #0x980]
    // 0x857a90: StoreField: r3->field_f = d0
    //     0x857a90: stur            d0, [x3, #0xf]
    // 0x857a94: r1 = Null
    //     0x857a94: mov             x1, NULL
    // 0x857a98: r2 = 4
    //     0x857a98: mov             x2, #4
    // 0x857a9c: r0 = AllocateArray()
    //     0x857a9c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x857aa0: mov             x2, x0
    // 0x857aa4: ldur            x0, [fp, #-0x10]
    // 0x857aa8: stur            x2, [fp, #-8]
    // 0x857aac: StoreField: r2->field_f = r0
    //     0x857aac: stur            w0, [x2, #0xf]
    // 0x857ab0: ldur            x0, [fp, #-0x20]
    // 0x857ab4: StoreField: r2->field_13 = r0
    //     0x857ab4: stur            w0, [x2, #0x13]
    // 0x857ab8: r1 = <TweenSequenceItem<double>>
    //     0x857ab8: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a0] TypeArguments: <TweenSequenceItem<double>>
    //     0x857abc: ldr             x1, [x1, #0x3a0]
    // 0x857ac0: r0 = AllocateGrowableArray()
    //     0x857ac0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x857ac4: mov             x2, x0
    // 0x857ac8: ldur            x0, [fp, #-8]
    // 0x857acc: stur            x2, [fp, #-0x10]
    // 0x857ad0: StoreField: r2->field_f = r0
    //     0x857ad0: stur            w0, [x2, #0xf]
    // 0x857ad4: r0 = 4
    //     0x857ad4: mov             x0, #4
    // 0x857ad8: StoreField: r2->field_b = r0
    //     0x857ad8: stur            w0, [x2, #0xb]
    // 0x857adc: r1 = <double>
    //     0x857adc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857ae0: r0 = TweenSequence()
    //     0x857ae0: bl              #0x7b7b18  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0x857ae4: stur            x0, [fp, #-8]
    // 0x857ae8: ldur            x16, [fp, #-0x10]
    // 0x857aec: stp             x16, x0, [SP, #-0x10]!
    // 0x857af0: r0 = TweenSequence()
    //     0x857af0: bl              #0x7b7778  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0x857af4: add             SP, SP, #0x10
    // 0x857af8: ldr             x0, [fp, #0x68]
    // 0x857afc: LoadField: r1 = r0->field_1f
    //     0x857afc: ldur            w1, [x0, #0x1f]
    // 0x857b00: DecompressPointer r1
    //     0x857b00: add             x1, x1, HEAP, lsl #32
    // 0x857b04: ldur            x16, [fp, #-8]
    // 0x857b08: stp             x1, x16, [SP, #-0x10]!
    // 0x857b0c: r0 = animate()
    //     0x857b0c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x857b10: add             SP, SP, #0x10
    // 0x857b14: ldur            x16, [fp, #-0x18]
    // 0x857b18: stp             x0, x16, [SP, #-0x10]!
    // 0x857b1c: r0 = animate()
    //     0x857b1c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x857b20: add             SP, SP, #0x10
    // 0x857b24: ldr             x2, [fp, #0x68]
    // 0x857b28: StoreField: r2->field_1b = r0
    //     0x857b28: stur            w0, [x2, #0x1b]
    //     0x857b2c: ldurb           w16, [x2, #-1]
    //     0x857b30: ldurb           w17, [x0, #-1]
    //     0x857b34: and             x16, x17, x16, lsr #2
    //     0x857b38: tst             x16, HEAP, lsr #32
    //     0x857b3c: b.eq            #0x857b44
    //     0x857b40: bl              #0xd6828c
    // 0x857b44: r1 = <double>
    //     0x857b44: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857b48: r0 = Tween()
    //     0x857b48: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x857b4c: mov             x2, x0
    // 0x857b50: r0 = 0.000000
    //     0x857b50: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x857b54: stur            x2, [fp, #-8]
    // 0x857b58: StoreField: r2->field_b = r0
    //     0x857b58: stur            w0, [x2, #0xb]
    // 0x857b5c: r3 = 1.000000
    //     0x857b5c: ldr             x3, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857b60: StoreField: r2->field_f = r3
    //     0x857b60: stur            w3, [x2, #0xf]
    // 0x857b64: r1 = <double>
    //     0x857b64: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857b68: r0 = TweenSequenceItem()
    //     0x857b68: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857b6c: mov             x2, x0
    // 0x857b70: ldur            x0, [fp, #-8]
    // 0x857b74: stur            x2, [fp, #-0x10]
    // 0x857b78: StoreField: r2->field_b = r0
    //     0x857b78: stur            w0, [x2, #0xb]
    // 0x857b7c: d0 = 13.000000
    //     0x857b7c: fmov            d0, #13.00000000
    // 0x857b80: StoreField: r2->field_f = d0
    //     0x857b80: stur            d0, [x2, #0xf]
    // 0x857b84: r1 = <double>
    //     0x857b84: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857b88: r0 = ConstantTween()
    //     0x857b88: bl              #0x858838  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0x857b8c: mov             x2, x0
    // 0x857b90: r0 = 1.000000
    //     0x857b90: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857b94: stur            x2, [fp, #-8]
    // 0x857b98: StoreField: r2->field_b = r0
    //     0x857b98: stur            w0, [x2, #0xb]
    // 0x857b9c: StoreField: r2->field_f = r0
    //     0x857b9c: stur            w0, [x2, #0xf]
    // 0x857ba0: r1 = <double>
    //     0x857ba0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857ba4: r0 = TweenSequenceItem()
    //     0x857ba4: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857ba8: mov             x2, x0
    // 0x857bac: ldur            x0, [fp, #-8]
    // 0x857bb0: stur            x2, [fp, #-0x18]
    // 0x857bb4: StoreField: r2->field_b = r0
    //     0x857bb4: stur            w0, [x2, #0xb]
    // 0x857bb8: d0 = 27.000000
    //     0x857bb8: fmov            d0, #27.00000000
    // 0x857bbc: StoreField: r2->field_f = d0
    //     0x857bbc: stur            d0, [x2, #0xf]
    // 0x857bc0: r1 = <double>
    //     0x857bc0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857bc4: r0 = Tween()
    //     0x857bc4: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x857bc8: mov             x2, x0
    // 0x857bcc: r0 = 1.000000
    //     0x857bcc: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857bd0: stur            x2, [fp, #-8]
    // 0x857bd4: StoreField: r2->field_b = r0
    //     0x857bd4: stur            w0, [x2, #0xb]
    // 0x857bd8: r3 = 0.000000
    //     0x857bd8: ldr             x3, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x857bdc: StoreField: r2->field_f = r3
    //     0x857bdc: stur            w3, [x2, #0xf]
    // 0x857be0: r1 = <double>
    //     0x857be0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857be4: r0 = TweenSequenceItem()
    //     0x857be4: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857be8: mov             x3, x0
    // 0x857bec: ldur            x0, [fp, #-8]
    // 0x857bf0: stur            x3, [fp, #-0x20]
    // 0x857bf4: StoreField: r3->field_b = r0
    //     0x857bf4: stur            w0, [x3, #0xb]
    // 0x857bf8: d0 = 60.000000
    //     0x857bf8: add             x17, PP, #0x2a, lsl #12  ; [pp+0x2a8c8] IMM: double(60) from 0x404e000000000000
    //     0x857bfc: ldr             d0, [x17, #0x8c8]
    // 0x857c00: StoreField: r3->field_f = d0
    //     0x857c00: stur            d0, [x3, #0xf]
    // 0x857c04: r1 = Null
    //     0x857c04: mov             x1, NULL
    // 0x857c08: r2 = 6
    //     0x857c08: mov             x2, #6
    // 0x857c0c: r0 = AllocateArray()
    //     0x857c0c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x857c10: mov             x2, x0
    // 0x857c14: ldur            x0, [fp, #-0x10]
    // 0x857c18: stur            x2, [fp, #-8]
    // 0x857c1c: StoreField: r2->field_f = r0
    //     0x857c1c: stur            w0, [x2, #0xf]
    // 0x857c20: ldur            x0, [fp, #-0x18]
    // 0x857c24: StoreField: r2->field_13 = r0
    //     0x857c24: stur            w0, [x2, #0x13]
    // 0x857c28: ldur            x0, [fp, #-0x20]
    // 0x857c2c: StoreField: r2->field_17 = r0
    //     0x857c2c: stur            w0, [x2, #0x17]
    // 0x857c30: r1 = <TweenSequenceItem<double>>
    //     0x857c30: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a0] TypeArguments: <TweenSequenceItem<double>>
    //     0x857c34: ldr             x1, [x1, #0x3a0]
    // 0x857c38: r0 = AllocateGrowableArray()
    //     0x857c38: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x857c3c: mov             x2, x0
    // 0x857c40: ldur            x0, [fp, #-8]
    // 0x857c44: stur            x2, [fp, #-0x10]
    // 0x857c48: StoreField: r2->field_f = r0
    //     0x857c48: stur            w0, [x2, #0xf]
    // 0x857c4c: r0 = 6
    //     0x857c4c: mov             x0, #6
    // 0x857c50: StoreField: r2->field_b = r0
    //     0x857c50: stur            w0, [x2, #0xb]
    // 0x857c54: r1 = <double>
    //     0x857c54: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857c58: r0 = TweenSequence()
    //     0x857c58: bl              #0x7b7b18  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0x857c5c: stur            x0, [fp, #-8]
    // 0x857c60: ldur            x16, [fp, #-0x10]
    // 0x857c64: stp             x16, x0, [SP, #-0x10]!
    // 0x857c68: r0 = TweenSequence()
    //     0x857c68: bl              #0x7b7778  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0x857c6c: add             SP, SP, #0x10
    // 0x857c70: ldr             x0, [fp, #0x68]
    // 0x857c74: LoadField: r1 = r0->field_17
    //     0x857c74: ldur            w1, [x0, #0x17]
    // 0x857c78: DecompressPointer r1
    //     0x857c78: add             x1, x1, HEAP, lsl #32
    // 0x857c7c: ldur            x16, [fp, #-8]
    // 0x857c80: stp             x1, x16, [SP, #-0x10]!
    // 0x857c84: r0 = animate()
    //     0x857c84: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x857c88: add             SP, SP, #0x10
    // 0x857c8c: ldr             x2, [fp, #0x68]
    // 0x857c90: StoreField: r2->field_23 = r0
    //     0x857c90: stur            w0, [x2, #0x23]
    //     0x857c94: ldurb           w16, [x2, #-1]
    //     0x857c98: ldurb           w17, [x0, #-1]
    //     0x857c9c: and             x16, x17, x16, lsr #2
    //     0x857ca0: tst             x16, HEAP, lsr #32
    //     0x857ca4: b.eq            #0x857cac
    //     0x857ca8: bl              #0xd6828c
    // 0x857cac: r1 = <double>
    //     0x857cac: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857cb0: r0 = Tween()
    //     0x857cb0: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x857cb4: mov             x2, x0
    // 0x857cb8: r0 = 0.000000
    //     0x857cb8: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x857cbc: stur            x2, [fp, #-8]
    // 0x857cc0: StoreField: r2->field_b = r0
    //     0x857cc0: stur            w0, [x2, #0xb]
    // 0x857cc4: r3 = 1.000000
    //     0x857cc4: ldr             x3, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857cc8: StoreField: r2->field_f = r3
    //     0x857cc8: stur            w3, [x2, #0xf]
    // 0x857ccc: r1 = <double>
    //     0x857ccc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857cd0: r0 = TweenSequenceItem()
    //     0x857cd0: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857cd4: mov             x2, x0
    // 0x857cd8: ldur            x0, [fp, #-8]
    // 0x857cdc: stur            x2, [fp, #-0x10]
    // 0x857ce0: StoreField: r2->field_b = r0
    //     0x857ce0: stur            w0, [x2, #0xb]
    // 0x857ce4: d0 = 13.000000
    //     0x857ce4: fmov            d0, #13.00000000
    // 0x857ce8: StoreField: r2->field_f = d0
    //     0x857ce8: stur            d0, [x2, #0xf]
    // 0x857cec: r1 = <double>
    //     0x857cec: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857cf0: r0 = ConstantTween()
    //     0x857cf0: bl              #0x858838  ; AllocateConstantTweenStub -> ConstantTween<X0> (size=0x14)
    // 0x857cf4: mov             x2, x0
    // 0x857cf8: r0 = 1.000000
    //     0x857cf8: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857cfc: stur            x2, [fp, #-8]
    // 0x857d00: StoreField: r2->field_b = r0
    //     0x857d00: stur            w0, [x2, #0xb]
    // 0x857d04: StoreField: r2->field_f = r0
    //     0x857d04: stur            w0, [x2, #0xf]
    // 0x857d08: r1 = <double>
    //     0x857d08: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857d0c: r0 = TweenSequenceItem()
    //     0x857d0c: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857d10: mov             x2, x0
    // 0x857d14: ldur            x0, [fp, #-8]
    // 0x857d18: stur            x2, [fp, #-0x18]
    // 0x857d1c: StoreField: r2->field_b = r0
    //     0x857d1c: stur            w0, [x2, #0xb]
    // 0x857d20: d0 = 27.000000
    //     0x857d20: fmov            d0, #27.00000000
    // 0x857d24: StoreField: r2->field_f = d0
    //     0x857d24: stur            d0, [x2, #0xf]
    // 0x857d28: r1 = <double>
    //     0x857d28: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857d2c: r0 = Tween()
    //     0x857d2c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x857d30: mov             x2, x0
    // 0x857d34: r0 = 1.000000
    //     0x857d34: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x857d38: stur            x2, [fp, #-8]
    // 0x857d3c: StoreField: r2->field_b = r0
    //     0x857d3c: stur            w0, [x2, #0xb]
    // 0x857d40: r0 = 0.000000
    //     0x857d40: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x857d44: StoreField: r2->field_f = r0
    //     0x857d44: stur            w0, [x2, #0xf]
    // 0x857d48: r1 = <double>
    //     0x857d48: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857d4c: r0 = TweenSequenceItem()
    //     0x857d4c: bl              #0x7b7c78  ; AllocateTweenSequenceItemStub -> TweenSequenceItem<X0> (size=0x18)
    // 0x857d50: mov             x3, x0
    // 0x857d54: ldur            x0, [fp, #-8]
    // 0x857d58: stur            x3, [fp, #-0x20]
    // 0x857d5c: StoreField: r3->field_b = r0
    //     0x857d5c: stur            w0, [x3, #0xb]
    // 0x857d60: d0 = 50.000000
    //     0x857d60: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0x857d64: ldr             d0, [x17, #0x980]
    // 0x857d68: StoreField: r3->field_f = d0
    //     0x857d68: stur            d0, [x3, #0xf]
    // 0x857d6c: r1 = Null
    //     0x857d6c: mov             x1, NULL
    // 0x857d70: r2 = 6
    //     0x857d70: mov             x2, #6
    // 0x857d74: r0 = AllocateArray()
    //     0x857d74: bl              #0xd6987c  ; AllocateArrayStub
    // 0x857d78: mov             x2, x0
    // 0x857d7c: ldur            x0, [fp, #-0x10]
    // 0x857d80: stur            x2, [fp, #-8]
    // 0x857d84: StoreField: r2->field_f = r0
    //     0x857d84: stur            w0, [x2, #0xf]
    // 0x857d88: ldur            x0, [fp, #-0x18]
    // 0x857d8c: StoreField: r2->field_13 = r0
    //     0x857d8c: stur            w0, [x2, #0x13]
    // 0x857d90: ldur            x0, [fp, #-0x20]
    // 0x857d94: StoreField: r2->field_17 = r0
    //     0x857d94: stur            w0, [x2, #0x17]
    // 0x857d98: r1 = <TweenSequenceItem<double>>
    //     0x857d98: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e3a0] TypeArguments: <TweenSequenceItem<double>>
    //     0x857d9c: ldr             x1, [x1, #0x3a0]
    // 0x857da0: r0 = AllocateGrowableArray()
    //     0x857da0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x857da4: mov             x2, x0
    // 0x857da8: ldur            x0, [fp, #-8]
    // 0x857dac: stur            x2, [fp, #-0x10]
    // 0x857db0: StoreField: r2->field_f = r0
    //     0x857db0: stur            w0, [x2, #0xf]
    // 0x857db4: r0 = 6
    //     0x857db4: mov             x0, #6
    // 0x857db8: StoreField: r2->field_b = r0
    //     0x857db8: stur            w0, [x2, #0xb]
    // 0x857dbc: r1 = <double>
    //     0x857dbc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x857dc0: r0 = TweenSequence()
    //     0x857dc0: bl              #0x7b7b18  ; AllocateTweenSequenceStub -> TweenSequence<X0> (size=0x14)
    // 0x857dc4: stur            x0, [fp, #-8]
    // 0x857dc8: ldur            x16, [fp, #-0x10]
    // 0x857dcc: stp             x16, x0, [SP, #-0x10]!
    // 0x857dd0: r0 = TweenSequence()
    //     0x857dd0: bl              #0x7b7778  ; [package:flutter/src/animation/tween_sequence.dart] TweenSequence::TweenSequence
    // 0x857dd4: add             SP, SP, #0x10
    // 0x857dd8: ldr             x0, [fp, #0x68]
    // 0x857ddc: LoadField: r1 = r0->field_17
    //     0x857ddc: ldur            w1, [x0, #0x17]
    // 0x857de0: DecompressPointer r1
    //     0x857de0: add             x1, x1, HEAP, lsl #32
    // 0x857de4: ldur            x16, [fp, #-8]
    // 0x857de8: stp             x1, x16, [SP, #-0x10]!
    // 0x857dec: r0 = animate()
    //     0x857dec: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x857df0: add             SP, SP, #0x10
    // 0x857df4: ldr             x1, [fp, #0x68]
    // 0x857df8: StoreField: r1->field_27 = r0
    //     0x857df8: stur            w0, [x1, #0x27]
    //     0x857dfc: ldurb           w16, [x1, #-1]
    //     0x857e00: ldurb           w17, [x0, #-1]
    //     0x857e04: and             x16, x17, x16, lsr #2
    //     0x857e08: tst             x16, HEAP, lsr #32
    //     0x857e0c: b.eq            #0x857e14
    //     0x857e10: bl              #0xd6826c
    // 0x857e14: SaveReg rNULL
    //     0x857e14: str             NULL, [SP, #-8]!
    // 0x857e18: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x857e18: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x857e1c: r0 = Random()
    //     0x857e1c: bl              #0x58977c  ; [dart:math] Random::Random
    // 0x857e20: add             SP, SP, #8
    // 0x857e24: SaveReg r0
    //     0x857e24: str             x0, [SP, #-8]!
    // 0x857e28: r0 = nextDouble()
    //     0x857e28: bl              #0x857f14  ; [dart:math] _Random::nextDouble
    // 0x857e2c: add             SP, SP, #8
    // 0x857e30: mov             v1.16b, v0.16b
    // 0x857e34: d0 = 1000.000000
    //     0x857e34: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0x857e38: ldr             d0, [x17, #0x3b0]
    // 0x857e3c: fmul            d2, d1, d0
    // 0x857e40: r0 = inline_Allocate_Double()
    //     0x857e40: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x857e44: add             x0, x0, #0x10
    //     0x857e48: cmp             x1, x0
    //     0x857e4c: b.ls            #0x857f04
    //     0x857e50: str             x0, [THR, #0x60]  ; THR::top
    //     0x857e54: sub             x0, x0, #0xf
    //     0x857e58: mov             x1, #0xd108
    //     0x857e5c: movk            x1, #3, lsl #16
    //     0x857e60: stur            x1, [x0, #-1]
    // 0x857e64: StoreField: r0->field_7 = d2
    //     0x857e64: stur            d2, [x0, #7]
    // 0x857e68: ldr             x1, [fp, #0x68]
    // 0x857e6c: StoreField: r1->field_2b = r0
    //     0x857e6c: stur            w0, [x1, #0x2b]
    //     0x857e70: ldurb           w16, [x1, #-1]
    //     0x857e74: ldurb           w17, [x0, #-1]
    //     0x857e78: and             x16, x17, x16, lsr #2
    //     0x857e7c: tst             x16, HEAP, lsr #32
    //     0x857e80: b.eq            #0x857e88
    //     0x857e84: bl              #0xd6826c
    // 0x857e88: r0 = Null
    //     0x857e88: mov             x0, NULL
    // 0x857e8c: LeaveFrame
    //     0x857e8c: mov             SP, fp
    //     0x857e90: ldp             fp, lr, [SP], #0x10
    // 0x857e94: ret
    //     0x857e94: ret             
    // 0x857e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x857e98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x857e9c: b               #0x857430
    // 0x857ea0: stp             q0, q1, [SP, #-0x20]!
    // 0x857ea4: SaveReg r3
    //     0x857ea4: str             x3, [SP, #-8]!
    // 0x857ea8: r0 = AllocateDouble()
    //     0x857ea8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x857eac: RestoreReg r3
    //     0x857eac: ldr             x3, [SP], #8
    // 0x857eb0: ldp             q0, q1, [SP], #0x20
    // 0x857eb4: b               #0x857898
    // 0x857eb8: SaveReg d0
    //     0x857eb8: str             q0, [SP, #-0x10]!
    // 0x857ebc: SaveReg r2
    //     0x857ebc: str             x2, [SP, #-8]!
    // 0x857ec0: r0 = AllocateDouble()
    //     0x857ec0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x857ec4: RestoreReg r2
    //     0x857ec4: ldr             x2, [SP], #8
    // 0x857ec8: RestoreReg d0
    //     0x857ec8: ldr             q0, [SP], #0x10
    // 0x857ecc: b               #0x8578e4
    // 0x857ed0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x857ed0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x857ed4: stp             q2, q3, [SP, #-0x20]!
    // 0x857ed8: SaveReg r3
    //     0x857ed8: str             x3, [SP, #-8]!
    // 0x857edc: r0 = AllocateDouble()
    //     0x857edc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x857ee0: RestoreReg r3
    //     0x857ee0: ldr             x3, [SP], #8
    // 0x857ee4: ldp             q2, q3, [SP], #0x20
    // 0x857ee8: b               #0x85796c
    // 0x857eec: SaveReg d0
    //     0x857eec: str             q0, [SP, #-0x10]!
    // 0x857ef0: SaveReg r2
    //     0x857ef0: str             x2, [SP, #-8]!
    // 0x857ef4: r0 = AllocateDouble()
    //     0x857ef4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x857ef8: RestoreReg r2
    //     0x857ef8: ldr             x2, [SP], #8
    // 0x857efc: RestoreReg d0
    //     0x857efc: ldr             q0, [SP], #0x10
    // 0x857f00: b               #0x8579b8
    // 0x857f04: SaveReg d2
    //     0x857f04: str             q2, [SP, #-0x10]!
    // 0x857f08: r0 = AllocateDouble()
    //     0x857f08: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x857f0c: RestoreReg d2
    //     0x857f0c: ldr             q2, [SP], #0x10
    // 0x857f10: b               #0x857e64
  }
  [closure] void _handleStatusChanged(dynamic, AnimationStatus) {
    // ** addr: 0x858d70, size: 0x4c
    // 0x858d70: EnterFrame
    //     0x858d70: stp             fp, lr, [SP, #-0x10]!
    //     0x858d74: mov             fp, SP
    // 0x858d78: ldr             x0, [fp, #0x18]
    // 0x858d7c: LoadField: r1 = r0->field_17
    //     0x858d7c: ldur            w1, [x0, #0x17]
    // 0x858d80: DecompressPointer r1
    //     0x858d80: add             x1, x1, HEAP, lsl #32
    // 0x858d84: CheckStackOverflow
    //     0x858d84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x858d88: cmp             SP, x16
    //     0x858d8c: b.ls            #0x858db4
    // 0x858d90: LoadField: r0 = r1->field_f
    //     0x858d90: ldur            w0, [x1, #0xf]
    // 0x858d94: DecompressPointer r0
    //     0x858d94: add             x0, x0, HEAP, lsl #32
    // 0x858d98: ldr             x16, [fp, #0x10]
    // 0x858d9c: stp             x16, x0, [SP, #-0x10]!
    // 0x858da0: r0 = _handleStatusChanged()
    //     0x858da0: bl              #0x858dbc  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_handleStatusChanged
    // 0x858da4: add             SP, SP, #0x10
    // 0x858da8: LeaveFrame
    //     0x858da8: mov             SP, fp
    //     0x858dac: ldp             fp, lr, [SP], #0x10
    // 0x858db0: ret
    //     0x858db0: ret             
    // 0x858db4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858db4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858db8: b               #0x858d90
  }
  _ _handleStatusChanged(/* No info */) {
    // ** addr: 0x858dbc, size: 0x50
    // 0x858dbc: EnterFrame
    //     0x858dbc: stp             fp, lr, [SP, #-0x10]!
    //     0x858dc0: mov             fp, SP
    // 0x858dc4: CheckStackOverflow
    //     0x858dc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x858dc8: cmp             SP, x16
    //     0x858dcc: b.ls            #0x858e04
    // 0x858dd0: ldr             x0, [fp, #0x10]
    // 0x858dd4: r16 = Instance_AnimationStatus
    //     0x858dd4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0x858dd8: ldr             x16, [x16, #0xba0]
    // 0x858ddc: cmp             w0, w16
    // 0x858de0: b.ne            #0x858df4
    // 0x858de4: ldr             x16, [fp, #0x18]
    // 0x858de8: SaveReg r16
    //     0x858de8: str             x16, [SP, #-8]!
    // 0x858dec: r0 = dispose()
    //     0x858dec: bl              #0xbfeb9c  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::dispose
    // 0x858df0: add             SP, SP, #8
    // 0x858df4: r0 = Null
    //     0x858df4: mov             x0, NULL
    // 0x858df8: LeaveFrame
    //     0x858df8: mov             SP, fp
    //     0x858dfc: ldp             fp, lr, [SP], #0x10
    // 0x858e00: ret
    //     0x858e00: ret             
    // 0x858e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x858e04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x858e08: b               #0x858dd0
  }
  _ paintFeature(/* No info */) {
    // ** addr: 0xbe4d14, size: 0x248
    // 0xbe4d14: EnterFrame
    //     0xbe4d14: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4d18: mov             fp, SP
    // 0xbe4d1c: AllocStack(0x18)
    //     0xbe4d1c: sub             SP, SP, #0x18
    // 0xbe4d20: CheckStackOverflow
    //     0xbe4d20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe4d24: cmp             SP, x16
    //     0xbe4d28: b.ls            #0xbe4f48
    // 0xbe4d2c: r0 = LoadStaticField(0xdac)
    //     0xbe4d2c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xbe4d30: ldr             x0, [x0, #0x1b58]
    // 0xbe4d34: cmp             w0, NULL
    // 0xbe4d38: b.ne            #0xbe4d4c
    // 0xbe4d3c: r0 = Null
    //     0xbe4d3c: mov             x0, NULL
    // 0xbe4d40: LeaveFrame
    //     0xbe4d40: mov             SP, fp
    //     0xbe4d44: ldp             fp, lr, [SP], #0x10
    // 0xbe4d48: ret
    //     0xbe4d48: ret             
    // 0xbe4d4c: ldr             x1, [fp, #0x20]
    // 0xbe4d50: LoadField: r2 = r1->field_53
    //     0xbe4d50: ldur            w2, [x1, #0x53]
    // 0xbe4d54: DecompressPointer r2
    //     0xbe4d54: add             x2, x2, HEAP, lsl #32
    // 0xbe4d58: tbz             w2, #4, #0xbe4dd0
    // 0xbe4d5c: SaveReg r0
    //     0xbe4d5c: str             x0, [SP, #-8]!
    // 0xbe4d60: r0 = fragmentShader()
    //     0xbe4d60: bl              #0xbe5d04  ; [dart:ui] FragmentProgram::fragmentShader
    // 0xbe4d64: add             SP, SP, #8
    // 0xbe4d68: mov             x1, x0
    // 0xbe4d6c: ldr             x0, [fp, #0x20]
    // 0xbe4d70: stur            x1, [fp, #-8]
    // 0xbe4d74: LoadField: r2 = r0->field_4f
    //     0xbe4d74: ldur            w2, [x0, #0x4f]
    // 0xbe4d78: DecompressPointer r2
    //     0xbe4d78: add             x2, x2, HEAP, lsl #32
    // 0xbe4d7c: r16 = Sentinel
    //     0xbe4d7c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4d80: cmp             w2, w16
    // 0xbe4d84: b.ne            #0xbe4d90
    // 0xbe4d88: mov             x1, x0
    // 0xbe4d8c: b               #0xbe4da8
    // 0xbe4d90: r16 = "_fragmentShader@758321118"
    //     0xbe4d90: add             x16, PP, #0x37, lsl #12  ; [pp+0x37828] "_fragmentShader@758321118"
    //     0xbe4d94: ldr             x16, [x16, #0x828]
    // 0xbe4d98: SaveReg r16
    //     0xbe4d98: str             x16, [SP, #-8]!
    // 0xbe4d9c: r0 = _throwFieldAlreadyInitialized()
    //     0xbe4d9c: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0xbe4da0: add             SP, SP, #8
    // 0xbe4da4: ldr             x1, [fp, #0x20]
    // 0xbe4da8: r2 = true
    //     0xbe4da8: add             x2, NULL, #0x20  ; true
    // 0xbe4dac: ldur            x0, [fp, #-8]
    // 0xbe4db0: StoreField: r1->field_4f = r0
    //     0xbe4db0: stur            w0, [x1, #0x4f]
    //     0xbe4db4: ldurb           w16, [x1, #-1]
    //     0xbe4db8: ldurb           w17, [x0, #-1]
    //     0xbe4dbc: and             x16, x17, x16, lsr #2
    //     0xbe4dc0: tst             x16, HEAP, lsr #32
    //     0xbe4dc4: b.eq            #0xbe4dcc
    //     0xbe4dc8: bl              #0xd6826c
    // 0xbe4dcc: StoreField: r1->field_53 = r2
    //     0xbe4dcc: stur            w2, [x1, #0x53]
    // 0xbe4dd0: ldr             x16, [fp, #0x18]
    // 0xbe4dd4: SaveReg r16
    //     0xbe4dd4: str             x16, [SP, #-8]!
    // 0xbe4dd8: r0 = save()
    //     0xbe4dd8: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xbe4ddc: add             SP, SP, #8
    // 0xbe4de0: ldr             x16, [fp, #0x20]
    // 0xbe4de4: ldr             lr, [fp, #0x18]
    // 0xbe4de8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4dec: ldr             x16, [fp, #0x10]
    // 0xbe4df0: SaveReg r16
    //     0xbe4df0: str             x16, [SP, #-8]!
    // 0xbe4df4: r0 = _transformCanvas()
    //     0xbe4df4: bl              #0xbe5c4c  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_transformCanvas
    // 0xbe4df8: add             SP, SP, #0x18
    // 0xbe4dfc: ldr             x0, [fp, #0x20]
    // 0xbe4e00: LoadField: r1 = r0->field_47
    //     0xbe4e00: ldur            w1, [x0, #0x47]
    // 0xbe4e04: DecompressPointer r1
    //     0xbe4e04: add             x1, x1, HEAP, lsl #32
    // 0xbe4e08: stur            x1, [fp, #-8]
    // 0xbe4e0c: cmp             w1, NULL
    // 0xbe4e10: b.eq            #0xbe4e44
    // 0xbe4e14: LoadField: r2 = r0->field_4b
    //     0xbe4e14: ldur            w2, [x0, #0x4b]
    // 0xbe4e18: DecompressPointer r2
    //     0xbe4e18: add             x2, x2, HEAP, lsl #32
    // 0xbe4e1c: LoadField: r3 = r0->field_3b
    //     0xbe4e1c: ldur            w3, [x0, #0x3b]
    // 0xbe4e20: DecompressPointer r3
    //     0xbe4e20: add             x3, x3, HEAP, lsl #32
    // 0xbe4e24: LoadField: r4 = r0->field_37
    //     0xbe4e24: ldur            w4, [x0, #0x37]
    // 0xbe4e28: DecompressPointer r4
    //     0xbe4e28: add             x4, x4, HEAP, lsl #32
    // 0xbe4e2c: stp             x4, x0, [SP, #-0x10]!
    // 0xbe4e30: ldr             x16, [fp, #0x18]
    // 0xbe4e34: stp             x1, x16, [SP, #-0x10]!
    // 0xbe4e38: stp             x2, x3, [SP, #-0x10]!
    // 0xbe4e3c: r0 = _clipCanvas()
    //     0xbe4e3c: bl              #0xbe5ae8  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_clipCanvas
    // 0xbe4e40: add             SP, SP, #0x30
    // 0xbe4e44: ldr             x0, [fp, #0x20]
    // 0xbe4e48: ldur            x1, [fp, #-8]
    // 0xbe4e4c: SaveReg r0
    //     0xbe4e4c: str             x0, [SP, #-8]!
    // 0xbe4e50: r0 = _updateFragmentShader()
    //     0xbe4e50: bl              #0xbe4f5c  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_updateFragmentShader
    // 0xbe4e54: add             SP, SP, #8
    // 0xbe4e58: r16 = 112
    //     0xbe4e58: mov             x16, #0x70
    // 0xbe4e5c: stp             x16, NULL, [SP, #-0x10]!
    // 0xbe4e60: r0 = ByteData()
    //     0xbe4e60: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xbe4e64: add             SP, SP, #0x10
    // 0xbe4e68: stur            x0, [fp, #-0x10]
    // 0xbe4e6c: r0 = Paint()
    //     0xbe4e6c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xbe4e70: mov             x1, x0
    // 0xbe4e74: ldur            x0, [fp, #-0x10]
    // 0xbe4e78: stur            x1, [fp, #-0x18]
    // 0xbe4e7c: StoreField: r1->field_7 = r0
    //     0xbe4e7c: stur            w0, [x1, #7]
    // 0xbe4e80: ldr             x0, [fp, #0x20]
    // 0xbe4e84: LoadField: r2 = r0->field_4f
    //     0xbe4e84: ldur            w2, [x0, #0x4f]
    // 0xbe4e88: DecompressPointer r2
    //     0xbe4e88: add             x2, x2, HEAP, lsl #32
    // 0xbe4e8c: r16 = Sentinel
    //     0xbe4e8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4e90: cmp             w2, w16
    // 0xbe4e94: b.eq            #0xbe4f50
    // 0xbe4e98: stur            x2, [fp, #-0x10]
    // 0xbe4e9c: SaveReg r1
    //     0xbe4e9c: str             x1, [SP, #-8]!
    // 0xbe4ea0: r0 = _ensureObjectsInitialized()
    //     0xbe4ea0: bl              #0x65ebd8  ; [dart:ui] Paint::_ensureObjectsInitialized
    // 0xbe4ea4: add             SP, SP, #8
    // 0xbe4ea8: r1 = LoadClassIdInstr(r0)
    //     0xbe4ea8: ldur            x1, [x0, #-1]
    //     0xbe4eac: ubfx            x1, x1, #0xc, #0x14
    // 0xbe4eb0: stp             xzr, x0, [SP, #-0x10]!
    // 0xbe4eb4: ldur            x16, [fp, #-0x10]
    // 0xbe4eb8: SaveReg r16
    //     0xbe4eb8: str             x16, [SP, #-8]!
    // 0xbe4ebc: mov             x0, x1
    // 0xbe4ec0: r0 = GDT[cid_x0 + 0x1015e]()
    //     0xbe4ec0: mov             x17, #0x15e
    //     0xbe4ec4: movk            x17, #1, lsl #16
    //     0xbe4ec8: add             lr, x0, x17
    //     0xbe4ecc: ldr             lr, [x21, lr, lsl #3]
    //     0xbe4ed0: blr             lr
    // 0xbe4ed4: add             SP, SP, #0x18
    // 0xbe4ed8: ldur            x0, [fp, #-8]
    // 0xbe4edc: cmp             w0, NULL
    // 0xbe4ee0: b.eq            #0xbe4f14
    // 0xbe4ee4: SaveReg r0
    //     0xbe4ee4: str             x0, [SP, #-8]!
    // 0xbe4ee8: ClosureCall
    //     0xbe4ee8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe4eec: ldur            x2, [x0, #0x1f]
    //     0xbe4ef0: blr             x2
    // 0xbe4ef4: add             SP, SP, #8
    // 0xbe4ef8: ldr             x16, [fp, #0x18]
    // 0xbe4efc: stp             x0, x16, [SP, #-0x10]!
    // 0xbe4f00: ldur            x16, [fp, #-0x18]
    // 0xbe4f04: SaveReg r16
    //     0xbe4f04: str             x16, [SP, #-8]!
    // 0xbe4f08: r0 = drawRect()
    //     0xbe4f08: bl              #0x65e610  ; [dart:ui] Canvas::drawRect
    // 0xbe4f0c: add             SP, SP, #0x18
    // 0xbe4f10: b               #0xbe4f28
    // 0xbe4f14: ldr             x16, [fp, #0x18]
    // 0xbe4f18: ldur            lr, [fp, #-0x18]
    // 0xbe4f1c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe4f20: r0 = drawPaint()
    //     0xbe4f20: bl              #0x66465c  ; [dart:ui] Canvas::drawPaint
    // 0xbe4f24: add             SP, SP, #0x10
    // 0xbe4f28: ldr             x16, [fp, #0x18]
    // 0xbe4f2c: SaveReg r16
    //     0xbe4f2c: str             x16, [SP, #-8]!
    // 0xbe4f30: r0 = restore()
    //     0xbe4f30: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xbe4f34: add             SP, SP, #8
    // 0xbe4f38: r0 = Null
    //     0xbe4f38: mov             x0, NULL
    // 0xbe4f3c: LeaveFrame
    //     0xbe4f3c: mov             SP, fp
    //     0xbe4f40: ldp             fp, lr, [SP], #0x10
    // 0xbe4f44: ret
    //     0xbe4f44: ret             
    // 0xbe4f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe4f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe4f4c: b               #0xbe4d2c
    // 0xbe4f50: r9 = _fragmentShader
    //     0xbe4f50: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e3c0] Field <InkSparkle._fragmentShader@758321118>: late final (offset: 0x50)
    //     0xbe4f54: ldr             x9, [x9, #0x3c0]
    // 0xbe4f58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe4f58: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _updateFragmentShader(/* No info */) {
    // ** addr: 0xbe4f5c, size: 0xaa0
    // 0xbe4f5c: EnterFrame
    //     0xbe4f5c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe4f60: mov             fp, SP
    // 0xbe4f64: AllocStack(0x38)
    //     0xbe4f64: sub             SP, SP, #0x38
    // 0xbe4f68: CheckStackOverflow
    //     0xbe4f68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe4f6c: cmp             SP, x16
    //     0xbe4f70: b.ls            #0xbe599c
    // 0xbe4f74: ldr             x0, [fp, #0x10]
    // 0xbe4f78: LoadField: r1 = r0->field_2b
    //     0xbe4f78: ldur            w1, [x0, #0x2b]
    // 0xbe4f7c: DecompressPointer r1
    //     0xbe4f7c: add             x1, x1, HEAP, lsl #32
    // 0xbe4f80: r16 = Sentinel
    //     0xbe4f80: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4f84: cmp             w1, w16
    // 0xbe4f88: b.eq            #0xbe59a4
    // 0xbe4f8c: stur            x1, [fp, #-8]
    // 0xbe4f90: LoadField: r2 = r0->field_1f
    //     0xbe4f90: ldur            w2, [x0, #0x1f]
    // 0xbe4f94: DecompressPointer r2
    //     0xbe4f94: add             x2, x2, HEAP, lsl #32
    // 0xbe4f98: r16 = Sentinel
    //     0xbe4f98: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe4f9c: cmp             w2, w16
    // 0xbe4fa0: b.eq            #0xbe59b0
    // 0xbe4fa4: LoadField: r3 = r2->field_f
    //     0xbe4fa4: ldur            w3, [x2, #0xf]
    // 0xbe4fa8: DecompressPointer r3
    //     0xbe4fa8: add             x3, x3, HEAP, lsl #32
    // 0xbe4fac: LoadField: r4 = r2->field_b
    //     0xbe4fac: ldur            w4, [x2, #0xb]
    // 0xbe4fb0: DecompressPointer r4
    //     0xbe4fb0: add             x4, x4, HEAP, lsl #32
    // 0xbe4fb4: stp             x4, x3, [SP, #-0x10]!
    // 0xbe4fb8: r0 = evaluate()
    //     0xbe4fb8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe4fbc: add             SP, SP, #0x10
    // 0xbe4fc0: mov             x1, x0
    // 0xbe4fc4: ldur            x0, [fp, #-8]
    // 0xbe4fc8: LoadField: d0 = r0->field_7
    //     0xbe4fc8: ldur            d0, [x0, #7]
    // 0xbe4fcc: LoadField: d1 = r1->field_7
    //     0xbe4fcc: ldur            d1, [x1, #7]
    // 0xbe4fd0: fadd            d2, d0, d1
    // 0xbe4fd4: stur            d2, [fp, #-0x30]
    // 0xbe4fd8: d0 = 0.024544
    //     0xbe4fd8: add             x17, PP, #0x37, lsl #12  ; [pp+0x37830] IMM: double(0.02454369260617026) from 0x3f9921fb54442d18
    //     0xbe4fdc: ldr             d0, [x17, #0x830]
    // 0xbe4fe0: fmul            d1, d2, d0
    // 0xbe4fe4: d0 = 5.340708
    //     0xbe4fe4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37838] IMM: double(5.340707511102648) from 0x40155ce26e06bfee
    //     0xbe4fe8: ldr             d0, [x17, #0x838]
    // 0xbe4fec: fadd            d3, d1, d0
    // 0xbe4ff0: stur            d3, [fp, #-0x28]
    // 0xbe4ff4: d0 = -0.024544
    //     0xbe4ff4: add             x17, PP, #0x37, lsl #12  ; [pp+0x37840] IMM: double(-0.02454369260617026) from 0xbf9921fb54442d18
    //     0xbe4ff8: ldr             d0, [x17, #0x840]
    // 0xbe4ffc: fmul            d4, d2, d0
    // 0xbe5000: d0 = 6.283185
    //     0xbe5000: add             x17, PP, #0x37, lsl #12  ; [pp+0x37848] IMM: double(6.283185307179586) from 0x401921fb54442d18
    //     0xbe5004: ldr             d0, [x17, #0x848]
    // 0xbe5008: fadd            d5, d4, d0
    // 0xbe500c: stur            d5, [fp, #-0x20]
    // 0xbe5010: d0 = 8.639380
    //     0xbe5010: add             x17, PP, #0x37, lsl #12  ; [pp+0x37850] IMM: double(8.63937979737193) from 0x4021475cc9eedf00
    //     0xbe5014: ldr             d0, [x17, #0x850]
    // 0xbe5018: fadd            d4, d1, d0
    // 0xbe501c: ldr             x0, [fp, #0x10]
    // 0xbe5020: stur            d4, [fp, #-0x18]
    // 0xbe5024: LoadField: r1 = r0->field_4f
    //     0xbe5024: ldur            w1, [x0, #0x4f]
    // 0xbe5028: DecompressPointer r1
    //     0xbe5028: add             x1, x1, HEAP, lsl #32
    // 0xbe502c: r16 = Sentinel
    //     0xbe502c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe5030: cmp             w1, w16
    // 0xbe5034: b.eq            #0xbe59bc
    // 0xbe5038: stur            x1, [fp, #-0x10]
    // 0xbe503c: LoadField: r2 = r0->field_2f
    //     0xbe503c: ldur            w2, [x0, #0x2f]
    // 0xbe5040: DecompressPointer r2
    //     0xbe5040: add             x2, x2, HEAP, lsl #32
    // 0xbe5044: stur            x2, [fp, #-8]
    // 0xbe5048: SaveReg r2
    //     0xbe5048: str             x2, [SP, #-8]!
    // 0xbe504c: r0 = red()
    //     0xbe504c: bl              #0x595684  ; [dart:ui] Color::red
    // 0xbe5050: add             SP, SP, #8
    // 0xbe5054: scvtf           d0, x0
    // 0xbe5058: d1 = 255.000000
    //     0xbe5058: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xbe505c: ldr             d1, [x17, #0x200]
    // 0xbe5060: fdiv            d2, d0, d1
    // 0xbe5064: ldur            x16, [fp, #-0x10]
    // 0xbe5068: stp             xzr, x16, [SP, #-0x10]!
    // 0xbe506c: SaveReg d2
    //     0xbe506c: str             d2, [SP, #-8]!
    // 0xbe5070: r0 = setFloat()
    //     0xbe5070: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5074: add             SP, SP, #0x18
    // 0xbe5078: ldur            x16, [fp, #-8]
    // 0xbe507c: SaveReg r16
    //     0xbe507c: str             x16, [SP, #-8]!
    // 0xbe5080: r0 = green()
    //     0xbe5080: bl              #0x595604  ; [dart:ui] Color::green
    // 0xbe5084: add             SP, SP, #8
    // 0xbe5088: scvtf           d0, x0
    // 0xbe508c: d1 = 255.000000
    //     0xbe508c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xbe5090: ldr             d1, [x17, #0x200]
    // 0xbe5094: fdiv            d2, d0, d1
    // 0xbe5098: ldur            x16, [fp, #-0x10]
    // 0xbe509c: r30 = 2
    //     0xbe509c: mov             lr, #2
    // 0xbe50a0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe50a4: SaveReg d2
    //     0xbe50a4: str             d2, [SP, #-8]!
    // 0xbe50a8: r0 = setFloat()
    //     0xbe50a8: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe50ac: add             SP, SP, #0x18
    // 0xbe50b0: ldur            x16, [fp, #-8]
    // 0xbe50b4: SaveReg r16
    //     0xbe50b4: str             x16, [SP, #-8]!
    // 0xbe50b8: r0 = blue()
    //     0xbe50b8: bl              #0x595594  ; [dart:ui] Color::blue
    // 0xbe50bc: add             SP, SP, #8
    // 0xbe50c0: scvtf           d0, x0
    // 0xbe50c4: d1 = 255.000000
    //     0xbe50c4: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xbe50c8: ldr             d1, [x17, #0x200]
    // 0xbe50cc: fdiv            d2, d0, d1
    // 0xbe50d0: ldur            x16, [fp, #-0x10]
    // 0xbe50d4: r30 = 4
    //     0xbe50d4: mov             lr, #4
    // 0xbe50d8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe50dc: SaveReg d2
    //     0xbe50dc: str             d2, [SP, #-8]!
    // 0xbe50e0: r0 = setFloat()
    //     0xbe50e0: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe50e4: add             SP, SP, #0x18
    // 0xbe50e8: ldur            x0, [fp, #-8]
    // 0xbe50ec: r1 = LoadClassIdInstr(r0)
    //     0xbe50ec: ldur            x1, [x0, #-1]
    //     0xbe50f0: ubfx            x1, x1, #0xc, #0x14
    // 0xbe50f4: lsl             x1, x1, #1
    // 0xbe50f8: r17 = 10124
    //     0xbe50f8: mov             x17, #0x278c
    // 0xbe50fc: cmp             w1, w17
    // 0xbe5100: b.gt            #0xbe5110
    // 0xbe5104: r17 = 10122
    //     0xbe5104: mov             x17, #0x278a
    // 0xbe5108: cmp             w1, w17
    // 0xbe510c: b.ge            #0xbe5128
    // 0xbe5110: r17 = 10114
    //     0xbe5110: mov             x17, #0x2782
    // 0xbe5114: cmp             w1, w17
    // 0xbe5118: b.eq            #0xbe5128
    // 0xbe511c: r17 = 10118
    //     0xbe511c: mov             x17, #0x2786
    // 0xbe5120: cmp             w1, w17
    // 0xbe5124: b.ne            #0xbe5134
    // 0xbe5128: LoadField: r1 = r0->field_7
    //     0xbe5128: ldur            x1, [x0, #7]
    // 0xbe512c: mov             x2, x1
    // 0xbe5130: b               #0xbe5144
    // 0xbe5134: LoadField: r1 = r0->field_f
    //     0xbe5134: ldur            w1, [x0, #0xf]
    // 0xbe5138: DecompressPointer r1
    //     0xbe5138: add             x1, x1, HEAP, lsl #32
    // 0xbe513c: LoadField: r0 = r1->field_7
    //     0xbe513c: ldur            x0, [x1, #7]
    // 0xbe5140: mov             x2, x0
    // 0xbe5144: ldr             x0, [fp, #0x10]
    // 0xbe5148: ldur            d1, [fp, #-0x30]
    // 0xbe514c: d0 = 255.000000
    //     0xbe514c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd200] IMM: double(255) from 0x406fe00000000000
    //     0xbe5150: ldr             d0, [x17, #0x200]
    // 0xbe5154: r1 = 4278190080
    //     0xbe5154: mov             x1, #0xff000000
    // 0xbe5158: ubfx            x2, x2, #0, #0x20
    // 0xbe515c: and             x3, x2, x1
    // 0xbe5160: ubfx            x3, x3, #0, #0x20
    // 0xbe5164: asr             x1, x3, #0x18
    // 0xbe5168: scvtf           d2, x1
    // 0xbe516c: fdiv            d3, d2, d0
    // 0xbe5170: ldur            x16, [fp, #-0x10]
    // 0xbe5174: r30 = 6
    //     0xbe5174: mov             lr, #6
    // 0xbe5178: stp             lr, x16, [SP, #-0x10]!
    // 0xbe517c: SaveReg d3
    //     0xbe517c: str             d3, [SP, #-8]!
    // 0xbe5180: r0 = setFloat()
    //     0xbe5180: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5184: add             SP, SP, #0x18
    // 0xbe5188: ldr             x0, [fp, #0x10]
    // 0xbe518c: LoadField: r1 = r0->field_23
    //     0xbe518c: ldur            w1, [x0, #0x23]
    // 0xbe5190: DecompressPointer r1
    //     0xbe5190: add             x1, x1, HEAP, lsl #32
    // 0xbe5194: r16 = Sentinel
    //     0xbe5194: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe5198: cmp             w1, w16
    // 0xbe519c: b.eq            #0xbe59c8
    // 0xbe51a0: LoadField: r2 = r1->field_f
    //     0xbe51a0: ldur            w2, [x1, #0xf]
    // 0xbe51a4: DecompressPointer r2
    //     0xbe51a4: add             x2, x2, HEAP, lsl #32
    // 0xbe51a8: LoadField: r3 = r1->field_b
    //     0xbe51a8: ldur            w3, [x1, #0xb]
    // 0xbe51ac: DecompressPointer r3
    //     0xbe51ac: add             x3, x3, HEAP, lsl #32
    // 0xbe51b0: stp             x3, x2, [SP, #-0x10]!
    // 0xbe51b4: r0 = evaluate()
    //     0xbe51b4: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe51b8: add             SP, SP, #0x10
    // 0xbe51bc: LoadField: d0 = r0->field_7
    //     0xbe51bc: ldur            d0, [x0, #7]
    // 0xbe51c0: ldur            x16, [fp, #-0x10]
    // 0xbe51c4: r30 = 8
    //     0xbe51c4: mov             lr, #8
    // 0xbe51c8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe51cc: SaveReg d0
    //     0xbe51cc: str             d0, [SP, #-8]!
    // 0xbe51d0: r0 = setFloat()
    //     0xbe51d0: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe51d4: add             SP, SP, #0x18
    // 0xbe51d8: ldur            x16, [fp, #-0x10]
    // 0xbe51dc: r30 = 10
    //     0xbe51dc: mov             lr, #0xa
    // 0xbe51e0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe51e4: d0 = 1.000000
    //     0xbe51e4: fmov            d0, #1.00000000
    // 0xbe51e8: SaveReg d0
    //     0xbe51e8: str             d0, [SP, #-8]!
    // 0xbe51ec: r0 = setFloat()
    //     0xbe51ec: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe51f0: add             SP, SP, #0x18
    // 0xbe51f4: ldur            x16, [fp, #-0x10]
    // 0xbe51f8: r30 = 12
    //     0xbe51f8: mov             lr, #0xc
    // 0xbe51fc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5200: d0 = 1.000000
    //     0xbe5200: fmov            d0, #1.00000000
    // 0xbe5204: SaveReg d0
    //     0xbe5204: str             d0, [SP, #-8]!
    // 0xbe5208: r0 = setFloat()
    //     0xbe5208: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe520c: add             SP, SP, #0x18
    // 0xbe5210: ldur            x16, [fp, #-0x10]
    // 0xbe5214: r30 = 14
    //     0xbe5214: mov             lr, #0xe
    // 0xbe5218: stp             lr, x16, [SP, #-0x10]!
    // 0xbe521c: d0 = 1.000000
    //     0xbe521c: fmov            d0, #1.00000000
    // 0xbe5220: SaveReg d0
    //     0xbe5220: str             d0, [SP, #-8]!
    // 0xbe5224: r0 = setFloat()
    //     0xbe5224: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5228: add             SP, SP, #0x18
    // 0xbe522c: ldur            x16, [fp, #-0x10]
    // 0xbe5230: r30 = 16
    //     0xbe5230: mov             lr, #0x10
    // 0xbe5234: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5238: d0 = 1.000000
    //     0xbe5238: fmov            d0, #1.00000000
    // 0xbe523c: SaveReg d0
    //     0xbe523c: str             d0, [SP, #-8]!
    // 0xbe5240: r0 = setFloat()
    //     0xbe5240: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5244: add             SP, SP, #0x18
    // 0xbe5248: ldr             x0, [fp, #0x10]
    // 0xbe524c: LoadField: r1 = r0->field_27
    //     0xbe524c: ldur            w1, [x0, #0x27]
    // 0xbe5250: DecompressPointer r1
    //     0xbe5250: add             x1, x1, HEAP, lsl #32
    // 0xbe5254: r16 = Sentinel
    //     0xbe5254: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe5258: cmp             w1, w16
    // 0xbe525c: b.eq            #0xbe59d4
    // 0xbe5260: LoadField: r2 = r1->field_f
    //     0xbe5260: ldur            w2, [x1, #0xf]
    // 0xbe5264: DecompressPointer r2
    //     0xbe5264: add             x2, x2, HEAP, lsl #32
    // 0xbe5268: LoadField: r3 = r1->field_b
    //     0xbe5268: ldur            w3, [x1, #0xb]
    // 0xbe526c: DecompressPointer r3
    //     0xbe526c: add             x3, x3, HEAP, lsl #32
    // 0xbe5270: stp             x3, x2, [SP, #-0x10]!
    // 0xbe5274: r0 = evaluate()
    //     0xbe5274: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe5278: add             SP, SP, #0x10
    // 0xbe527c: LoadField: d0 = r0->field_7
    //     0xbe527c: ldur            d0, [x0, #7]
    // 0xbe5280: ldur            x16, [fp, #-0x10]
    // 0xbe5284: r30 = 18
    //     0xbe5284: mov             lr, #0x12
    // 0xbe5288: stp             lr, x16, [SP, #-0x10]!
    // 0xbe528c: SaveReg d0
    //     0xbe528c: str             d0, [SP, #-8]!
    // 0xbe5290: r0 = setFloat()
    //     0xbe5290: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5294: add             SP, SP, #0x18
    // 0xbe5298: ldur            x16, [fp, #-0x10]
    // 0xbe529c: r30 = 20
    //     0xbe529c: mov             lr, #0x14
    // 0xbe52a0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe52a4: d0 = 1.000000
    //     0xbe52a4: fmov            d0, #1.00000000
    // 0xbe52a8: SaveReg d0
    //     0xbe52a8: str             d0, [SP, #-8]!
    // 0xbe52ac: r0 = setFloat()
    //     0xbe52ac: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe52b0: add             SP, SP, #0x18
    // 0xbe52b4: ldr             x0, [fp, #0x10]
    // 0xbe52b8: LoadField: r1 = r0->field_1b
    //     0xbe52b8: ldur            w1, [x0, #0x1b]
    // 0xbe52bc: DecompressPointer r1
    //     0xbe52bc: add             x1, x1, HEAP, lsl #32
    // 0xbe52c0: r16 = Sentinel
    //     0xbe52c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbe52c4: cmp             w1, w16
    // 0xbe52c8: b.eq            #0xbe59e0
    // 0xbe52cc: LoadField: r2 = r1->field_f
    //     0xbe52cc: ldur            w2, [x1, #0xf]
    // 0xbe52d0: DecompressPointer r2
    //     0xbe52d0: add             x2, x2, HEAP, lsl #32
    // 0xbe52d4: LoadField: r3 = r1->field_b
    //     0xbe52d4: ldur            w3, [x1, #0xb]
    // 0xbe52d8: DecompressPointer r3
    //     0xbe52d8: add             x3, x3, HEAP, lsl #32
    // 0xbe52dc: stp             x3, x2, [SP, #-0x10]!
    // 0xbe52e0: r0 = evaluate()
    //     0xbe52e0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe52e4: add             SP, SP, #0x10
    // 0xbe52e8: LoadField: r2 = r0->field_7
    //     0xbe52e8: ldur            w2, [x0, #7]
    // 0xbe52ec: DecompressPointer r2
    //     0xbe52ec: add             x2, x2, HEAP, lsl #32
    // 0xbe52f0: LoadField: r0 = r2->field_13
    //     0xbe52f0: ldur            w0, [x2, #0x13]
    // 0xbe52f4: DecompressPointer r0
    //     0xbe52f4: add             x0, x0, HEAP, lsl #32
    // 0xbe52f8: r1 = LoadInt32Instr(r0)
    //     0xbe52f8: sbfx            x1, x0, #1, #0x1f
    // 0xbe52fc: mov             x0, x1
    // 0xbe5300: r1 = 0
    //     0xbe5300: mov             x1, #0
    // 0xbe5304: cmp             x1, x0
    // 0xbe5308: b.hs            #0xbe59ec
    // 0xbe530c: LoadField: d0 = r2->field_17
    //     0xbe530c: ldur            d0, [x2, #0x17]
    // 0xbe5310: ldur            x16, [fp, #-0x10]
    // 0xbe5314: r30 = 22
    //     0xbe5314: mov             lr, #0x16
    // 0xbe5318: stp             lr, x16, [SP, #-0x10]!
    // 0xbe531c: SaveReg d0
    //     0xbe531c: str             d0, [SP, #-8]!
    // 0xbe5320: r0 = setFloat()
    //     0xbe5320: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5324: add             SP, SP, #0x18
    // 0xbe5328: ldr             x0, [fp, #0x10]
    // 0xbe532c: LoadField: r1 = r0->field_1b
    //     0xbe532c: ldur            w1, [x0, #0x1b]
    // 0xbe5330: DecompressPointer r1
    //     0xbe5330: add             x1, x1, HEAP, lsl #32
    // 0xbe5334: LoadField: r2 = r1->field_f
    //     0xbe5334: ldur            w2, [x1, #0xf]
    // 0xbe5338: DecompressPointer r2
    //     0xbe5338: add             x2, x2, HEAP, lsl #32
    // 0xbe533c: LoadField: r3 = r1->field_b
    //     0xbe533c: ldur            w3, [x1, #0xb]
    // 0xbe5340: DecompressPointer r3
    //     0xbe5340: add             x3, x3, HEAP, lsl #32
    // 0xbe5344: stp             x3, x2, [SP, #-0x10]!
    // 0xbe5348: r0 = evaluate()
    //     0xbe5348: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe534c: add             SP, SP, #0x10
    // 0xbe5350: LoadField: r2 = r0->field_7
    //     0xbe5350: ldur            w2, [x0, #7]
    // 0xbe5354: DecompressPointer r2
    //     0xbe5354: add             x2, x2, HEAP, lsl #32
    // 0xbe5358: LoadField: r0 = r2->field_13
    //     0xbe5358: ldur            w0, [x2, #0x13]
    // 0xbe535c: DecompressPointer r0
    //     0xbe535c: add             x0, x0, HEAP, lsl #32
    // 0xbe5360: r1 = LoadInt32Instr(r0)
    //     0xbe5360: sbfx            x1, x0, #1, #0x1f
    // 0xbe5364: mov             x0, x1
    // 0xbe5368: r1 = 1
    //     0xbe5368: mov             x1, #1
    // 0xbe536c: cmp             x1, x0
    // 0xbe5370: b.hs            #0xbe59f0
    // 0xbe5374: LoadField: d0 = r2->field_1f
    //     0xbe5374: ldur            d0, [x2, #0x1f]
    // 0xbe5378: ldur            x16, [fp, #-0x10]
    // 0xbe537c: r30 = 24
    //     0xbe537c: mov             lr, #0x18
    // 0xbe5380: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5384: SaveReg d0
    //     0xbe5384: str             d0, [SP, #-8]!
    // 0xbe5388: r0 = setFloat()
    //     0xbe5388: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe538c: add             SP, SP, #0x18
    // 0xbe5390: ldr             x0, [fp, #0x10]
    // 0xbe5394: LoadField: r1 = r0->field_1f
    //     0xbe5394: ldur            w1, [x0, #0x1f]
    // 0xbe5398: DecompressPointer r1
    //     0xbe5398: add             x1, x1, HEAP, lsl #32
    // 0xbe539c: LoadField: r2 = r1->field_f
    //     0xbe539c: ldur            w2, [x1, #0xf]
    // 0xbe53a0: DecompressPointer r2
    //     0xbe53a0: add             x2, x2, HEAP, lsl #32
    // 0xbe53a4: LoadField: r3 = r1->field_b
    //     0xbe53a4: ldur            w3, [x1, #0xb]
    // 0xbe53a8: DecompressPointer r3
    //     0xbe53a8: add             x3, x3, HEAP, lsl #32
    // 0xbe53ac: stp             x3, x2, [SP, #-0x10]!
    // 0xbe53b0: r0 = evaluate()
    //     0xbe53b0: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xbe53b4: add             SP, SP, #0x10
    // 0xbe53b8: LoadField: d0 = r0->field_7
    //     0xbe53b8: ldur            d0, [x0, #7]
    // 0xbe53bc: ldur            x16, [fp, #-0x10]
    // 0xbe53c0: r30 = 26
    //     0xbe53c0: mov             lr, #0x1a
    // 0xbe53c4: stp             lr, x16, [SP, #-0x10]!
    // 0xbe53c8: SaveReg d0
    //     0xbe53c8: str             d0, [SP, #-8]!
    // 0xbe53cc: r0 = setFloat()
    //     0xbe53cc: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe53d0: add             SP, SP, #0x18
    // 0xbe53d4: ldr             x0, [fp, #0x10]
    // 0xbe53d8: LoadField: d0 = r0->field_3f
    //     0xbe53d8: ldur            d0, [x0, #0x3f]
    // 0xbe53dc: ldur            x16, [fp, #-0x10]
    // 0xbe53e0: r30 = 28
    //     0xbe53e0: mov             lr, #0x1c
    // 0xbe53e4: stp             lr, x16, [SP, #-0x10]!
    // 0xbe53e8: SaveReg d0
    //     0xbe53e8: str             d0, [SP, #-8]!
    // 0xbe53ec: r0 = setFloat()
    //     0xbe53ec: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe53f0: add             SP, SP, #0x18
    // 0xbe53f4: ldr             x16, [fp, #0x10]
    // 0xbe53f8: SaveReg r16
    //     0xbe53f8: str             x16, [SP, #-8]!
    // 0xbe53fc: r0 = _width()
    //     0xbe53fc: bl              #0xbe5a34  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_width
    // 0xbe5400: add             SP, SP, #8
    // 0xbe5404: mov             v1.16b, v0.16b
    // 0xbe5408: d0 = 1.000000
    //     0xbe5408: fmov            d0, #1.00000000
    // 0xbe540c: fdiv            d2, d0, d1
    // 0xbe5410: ldur            x16, [fp, #-0x10]
    // 0xbe5414: r30 = 30
    //     0xbe5414: mov             lr, #0x1e
    // 0xbe5418: stp             lr, x16, [SP, #-0x10]!
    // 0xbe541c: SaveReg d2
    //     0xbe541c: str             d2, [SP, #-8]!
    // 0xbe5420: r0 = setFloat()
    //     0xbe5420: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5424: add             SP, SP, #0x18
    // 0xbe5428: ldr             x16, [fp, #0x10]
    // 0xbe542c: SaveReg r16
    //     0xbe542c: str             x16, [SP, #-8]!
    // 0xbe5430: r0 = _height()
    //     0xbe5430: bl              #0xbe59fc  ; [package:flutter/src/material/ink_sparkle.dart] InkSparkle::_height
    // 0xbe5434: add             SP, SP, #8
    // 0xbe5438: mov             v1.16b, v0.16b
    // 0xbe543c: d0 = 1.000000
    //     0xbe543c: fmov            d0, #1.00000000
    // 0xbe5440: fdiv            d2, d0, d1
    // 0xbe5444: ldur            x16, [fp, #-0x10]
    // 0xbe5448: r30 = 32
    //     0xbe5448: mov             lr, #0x20
    // 0xbe544c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5450: SaveReg d2
    //     0xbe5450: str             d2, [SP, #-8]!
    // 0xbe5454: r0 = setFloat()
    //     0xbe5454: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5458: add             SP, SP, #0x18
    // 0xbe545c: ldr             x0, [fp, #0x10]
    // 0xbe5460: LoadField: r1 = r0->field_b
    //     0xbe5460: ldur            w1, [x0, #0xb]
    // 0xbe5464: DecompressPointer r1
    //     0xbe5464: add             x1, x1, HEAP, lsl #32
    // 0xbe5468: stur            x1, [fp, #-8]
    // 0xbe546c: LoadField: r0 = r1->field_57
    //     0xbe546c: ldur            w0, [x1, #0x57]
    // 0xbe5470: DecompressPointer r0
    //     0xbe5470: add             x0, x0, HEAP, lsl #32
    // 0xbe5474: cmp             w0, NULL
    // 0xbe5478: b.eq            #0xbe59f4
    // 0xbe547c: LoadField: d0 = r0->field_7
    //     0xbe547c: ldur            d0, [x0, #7]
    // 0xbe5480: d1 = 2.100000
    //     0xbe5480: add             x17, PP, #0x37, lsl #12  ; [pp+0x37858] IMM: double(2.1) from 0x4000cccccccccccd
    //     0xbe5484: ldr             d1, [x17, #0x858]
    // 0xbe5488: fdiv            d2, d1, d0
    // 0xbe548c: ldur            x16, [fp, #-0x10]
    // 0xbe5490: r30 = 34
    //     0xbe5490: mov             lr, #0x22
    // 0xbe5494: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5498: SaveReg d2
    //     0xbe5498: str             d2, [SP, #-8]!
    // 0xbe549c: r0 = setFloat()
    //     0xbe549c: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe54a0: add             SP, SP, #0x18
    // 0xbe54a4: ldur            x0, [fp, #-8]
    // 0xbe54a8: LoadField: r1 = r0->field_57
    //     0xbe54a8: ldur            w1, [x0, #0x57]
    // 0xbe54ac: DecompressPointer r1
    //     0xbe54ac: add             x1, x1, HEAP, lsl #32
    // 0xbe54b0: cmp             w1, NULL
    // 0xbe54b4: b.eq            #0xbe59f8
    // 0xbe54b8: LoadField: d0 = r1->field_f
    //     0xbe54b8: ldur            d0, [x1, #0xf]
    // 0xbe54bc: d1 = 2.100000
    //     0xbe54bc: add             x17, PP, #0x37, lsl #12  ; [pp+0x37858] IMM: double(2.1) from 0x4000cccccccccccd
    //     0xbe54c0: ldr             d1, [x17, #0x858]
    // 0xbe54c4: fdiv            d2, d1, d0
    // 0xbe54c8: ldur            x16, [fp, #-0x10]
    // 0xbe54cc: r30 = 36
    //     0xbe54cc: mov             lr, #0x24
    // 0xbe54d0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe54d4: SaveReg d2
    //     0xbe54d4: str             d2, [SP, #-8]!
    // 0xbe54d8: r0 = setFloat()
    //     0xbe54d8: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe54dc: add             SP, SP, #0x18
    // 0xbe54e0: ldur            d0, [fp, #-0x30]
    // 0xbe54e4: d1 = 1000.000000
    //     0xbe54e4: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e3b0] IMM: double(1000) from 0x408f400000000000
    //     0xbe54e8: ldr             d1, [x17, #0x3b0]
    // 0xbe54ec: fdiv            d2, d0, d1
    // 0xbe54f0: ldur            x16, [fp, #-0x10]
    // 0xbe54f4: r30 = 38
    //     0xbe54f4: mov             lr, #0x26
    // 0xbe54f8: stp             lr, x16, [SP, #-0x10]!
    // 0xbe54fc: SaveReg d2
    //     0xbe54fc: str             d2, [SP, #-8]!
    // 0xbe5500: r0 = setFloat()
    //     0xbe5500: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5504: add             SP, SP, #0x18
    // 0xbe5508: ldur            d1, [fp, #-0x30]
    // 0xbe550c: d0 = 0.010000
    //     0xbe550c: add             x17, PP, #0x31, lsl #12  ; [pp+0x31dc8] IMM: double(0.01) from 0x3f847ae147ae147b
    //     0xbe5510: ldr             d0, [x17, #0xdc8]
    // 0xbe5514: fmul            d2, d1, d0
    // 0xbe5518: stur            d2, [fp, #-0x38]
    // 0xbe551c: d0 = 0.825000
    //     0xbe551c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37860] IMM: double(0.8250000000000001) from 0x3fea666666666667
    //     0xbe5520: ldr             d0, [x17, #0x860]
    // 0xbe5524: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5528: mov             fp, SP
    // 0xbe552c: CallRuntime_LibcCos(double) -> double
    //     0xbe552c: and             SP, SP, #0xfffffffffffffff0
    //     0xbe5530: mov             sp, SP
    //     0xbe5534: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbe5538: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe553c: blr             x16
    //     0xbe5540: mov             x16, #8
    //     0xbe5544: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5548: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe554c: sub             sp, x16, #1, lsl #12
    //     0xbe5550: mov             SP, fp
    //     0xbe5554: ldp             fp, lr, [SP], #0x10
    // 0xbe5558: mov             v1.16b, v0.16b
    // 0xbe555c: ldur            d0, [fp, #-0x38]
    // 0xbe5560: fmul            d2, d0, d1
    // 0xbe5564: d1 = 0.750000
    //     0xbe5564: fmov            d1, #0.75000000
    // 0xbe5568: fadd            d3, d1, d2
    // 0xbe556c: ldur            x16, [fp, #-0x10]
    // 0xbe5570: r30 = 40
    //     0xbe5570: mov             lr, #0x28
    // 0xbe5574: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5578: SaveReg d3
    //     0xbe5578: str             d3, [SP, #-8]!
    // 0xbe557c: r0 = setFloat()
    //     0xbe557c: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5580: add             SP, SP, #0x18
    // 0xbe5584: d0 = 0.825000
    //     0xbe5584: add             x17, PP, #0x37, lsl #12  ; [pp+0x37860] IMM: double(0.8250000000000001) from 0x3fea666666666667
    //     0xbe5588: ldr             d0, [x17, #0x860]
    // 0xbe558c: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5590: mov             fp, SP
    // 0xbe5594: CallRuntime_LibcSin(double) -> double
    //     0xbe5594: and             SP, SP, #0xfffffffffffffff0
    //     0xbe5598: mov             sp, SP
    //     0xbe559c: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbe55a0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe55a4: blr             x16
    //     0xbe55a8: mov             x16, #8
    //     0xbe55ac: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe55b0: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe55b4: sub             sp, x16, #1, lsl #12
    //     0xbe55b8: mov             SP, fp
    //     0xbe55bc: ldp             fp, lr, [SP], #0x10
    // 0xbe55c0: mov             v1.16b, v0.16b
    // 0xbe55c4: ldur            d0, [fp, #-0x38]
    // 0xbe55c8: fmul            d2, d0, d1
    // 0xbe55cc: d0 = 0.750000
    //     0xbe55cc: fmov            d0, #0.75000000
    // 0xbe55d0: fadd            d1, d0, d2
    // 0xbe55d4: ldur            x16, [fp, #-0x10]
    // 0xbe55d8: r30 = 42
    //     0xbe55d8: mov             lr, #0x2a
    // 0xbe55dc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe55e0: SaveReg d1
    //     0xbe55e0: str             d1, [SP, #-8]!
    // 0xbe55e4: r0 = setFloat()
    //     0xbe55e4: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe55e8: add             SP, SP, #0x18
    // 0xbe55ec: d0 = 0.006600
    //     0xbe55ec: add             x17, PP, #0x37, lsl #12  ; [pp+0x37868] IMM: double(0.0066) from 0x3f7b089a02752546
    //     0xbe55f0: ldr             d0, [x17, #0x868]
    // 0xbe55f4: fneg            d1, d0
    // 0xbe55f8: ldur            d0, [fp, #-0x30]
    // 0xbe55fc: fmul            d2, d0, d1
    // 0xbe5600: stur            d2, [fp, #-0x38]
    // 0xbe5604: d0 = 0.675000
    //     0xbe5604: add             x17, PP, #0x37, lsl #12  ; [pp+0x37870] IMM: double(0.675) from 0x3fe599999999999a
    //     0xbe5608: ldr             d0, [x17, #0x870]
    // 0xbe560c: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5610: mov             fp, SP
    // 0xbe5614: CallRuntime_LibcCos(double) -> double
    //     0xbe5614: and             SP, SP, #0xfffffffffffffff0
    //     0xbe5618: mov             sp, SP
    //     0xbe561c: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbe5620: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5624: blr             x16
    //     0xbe5628: mov             x16, #8
    //     0xbe562c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5630: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe5634: sub             sp, x16, #1, lsl #12
    //     0xbe5638: mov             SP, fp
    //     0xbe563c: ldp             fp, lr, [SP], #0x10
    // 0xbe5640: mov             v1.16b, v0.16b
    // 0xbe5644: ldur            d0, [fp, #-0x38]
    // 0xbe5648: fmul            d2, d0, d1
    // 0xbe564c: d1 = 0.300000
    //     0xbe564c: add             x17, PP, #0x37, lsl #12  ; [pp+0x37878] IMM: double(0.30000000000000004) from 0x3fd3333333333334
    //     0xbe5650: ldr             d1, [x17, #0x878]
    // 0xbe5654: fadd            d3, d1, d2
    // 0xbe5658: ldur            x16, [fp, #-0x10]
    // 0xbe565c: r30 = 44
    //     0xbe565c: mov             lr, #0x2c
    // 0xbe5660: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5664: SaveReg d3
    //     0xbe5664: str             d3, [SP, #-8]!
    // 0xbe5668: r0 = setFloat()
    //     0xbe5668: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe566c: add             SP, SP, #0x18
    // 0xbe5670: d0 = 0.675000
    //     0xbe5670: add             x17, PP, #0x37, lsl #12  ; [pp+0x37870] IMM: double(0.675) from 0x3fe599999999999a
    //     0xbe5674: ldr             d0, [x17, #0x870]
    // 0xbe5678: stp             fp, lr, [SP, #-0x10]!
    // 0xbe567c: mov             fp, SP
    // 0xbe5680: CallRuntime_LibcSin(double) -> double
    //     0xbe5680: and             SP, SP, #0xfffffffffffffff0
    //     0xbe5684: mov             sp, SP
    //     0xbe5688: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbe568c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5690: blr             x16
    //     0xbe5694: mov             x16, #8
    //     0xbe5698: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe569c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe56a0: sub             sp, x16, #1, lsl #12
    //     0xbe56a4: mov             SP, fp
    //     0xbe56a8: ldp             fp, lr, [SP], #0x10
    // 0xbe56ac: mov             v1.16b, v0.16b
    // 0xbe56b0: ldur            d0, [fp, #-0x38]
    // 0xbe56b4: fmul            d2, d0, d1
    // 0xbe56b8: d1 = 0.300000
    //     0xbe56b8: add             x17, PP, #0x37, lsl #12  ; [pp+0x37878] IMM: double(0.30000000000000004) from 0x3fd3333333333334
    //     0xbe56bc: ldr             d1, [x17, #0x878]
    // 0xbe56c0: fadd            d3, d1, d2
    // 0xbe56c4: ldur            x16, [fp, #-0x10]
    // 0xbe56c8: r30 = 46
    //     0xbe56c8: mov             lr, #0x2e
    // 0xbe56cc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe56d0: SaveReg d3
    //     0xbe56d0: str             d3, [SP, #-8]!
    // 0xbe56d4: r0 = setFloat()
    //     0xbe56d4: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe56d8: add             SP, SP, #0x18
    // 0xbe56dc: d0 = 0.525000
    //     0xbe56dc: add             x17, PP, #0x37, lsl #12  ; [pp+0x37880] IMM: double(0.5249999999999999) from 0x3fe0cccccccccccc
    //     0xbe56e0: ldr             d0, [x17, #0x880]
    // 0xbe56e4: stp             fp, lr, [SP, #-0x10]!
    // 0xbe56e8: mov             fp, SP
    // 0xbe56ec: CallRuntime_LibcCos(double) -> double
    //     0xbe56ec: and             SP, SP, #0xfffffffffffffff0
    //     0xbe56f0: mov             sp, SP
    //     0xbe56f4: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbe56f8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe56fc: blr             x16
    //     0xbe5700: mov             x16, #8
    //     0xbe5704: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5708: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe570c: sub             sp, x16, #1, lsl #12
    //     0xbe5710: mov             SP, fp
    //     0xbe5714: ldp             fp, lr, [SP], #0x10
    // 0xbe5718: mov             v1.16b, v0.16b
    // 0xbe571c: ldur            d0, [fp, #-0x38]
    // 0xbe5720: fmul            d2, d0, d1
    // 0xbe5724: d1 = 1.500000
    //     0xbe5724: fmov            d1, #1.50000000
    // 0xbe5728: fadd            d3, d1, d2
    // 0xbe572c: ldur            x16, [fp, #-0x10]
    // 0xbe5730: r30 = 48
    //     0xbe5730: mov             lr, #0x30
    // 0xbe5734: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5738: SaveReg d3
    //     0xbe5738: str             d3, [SP, #-8]!
    // 0xbe573c: r0 = setFloat()
    //     0xbe573c: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5740: add             SP, SP, #0x18
    // 0xbe5744: d0 = 0.525000
    //     0xbe5744: add             x17, PP, #0x37, lsl #12  ; [pp+0x37880] IMM: double(0.5249999999999999) from 0x3fe0cccccccccccc
    //     0xbe5748: ldr             d0, [x17, #0x880]
    // 0xbe574c: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5750: mov             fp, SP
    // 0xbe5754: CallRuntime_LibcSin(double) -> double
    //     0xbe5754: and             SP, SP, #0xfffffffffffffff0
    //     0xbe5758: mov             sp, SP
    //     0xbe575c: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbe5760: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5764: blr             x16
    //     0xbe5768: mov             x16, #8
    //     0xbe576c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5770: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe5774: sub             sp, x16, #1, lsl #12
    //     0xbe5778: mov             SP, fp
    //     0xbe577c: ldp             fp, lr, [SP], #0x10
    // 0xbe5780: mov             v1.16b, v0.16b
    // 0xbe5784: ldur            d0, [fp, #-0x38]
    // 0xbe5788: fmul            d2, d0, d1
    // 0xbe578c: d0 = 1.500000
    //     0xbe578c: fmov            d0, #1.50000000
    // 0xbe5790: fadd            d1, d0, d2
    // 0xbe5794: ldur            x16, [fp, #-0x10]
    // 0xbe5798: r30 = 50
    //     0xbe5798: mov             lr, #0x32
    // 0xbe579c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe57a0: SaveReg d1
    //     0xbe57a0: str             d1, [SP, #-8]!
    // 0xbe57a4: r0 = setFloat()
    //     0xbe57a4: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe57a8: add             SP, SP, #0x18
    // 0xbe57ac: ldur            d0, [fp, #-0x28]
    // 0xbe57b0: stp             fp, lr, [SP, #-0x10]!
    // 0xbe57b4: mov             fp, SP
    // 0xbe57b8: CallRuntime_LibcCos(double) -> double
    //     0xbe57b8: and             SP, SP, #0xfffffffffffffff0
    //     0xbe57bc: mov             sp, SP
    //     0xbe57c0: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbe57c4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe57c8: blr             x16
    //     0xbe57cc: mov             x16, #8
    //     0xbe57d0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe57d4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe57d8: sub             sp, x16, #1, lsl #12
    //     0xbe57dc: mov             SP, fp
    //     0xbe57e0: ldp             fp, lr, [SP], #0x10
    // 0xbe57e4: ldur            x16, [fp, #-0x10]
    // 0xbe57e8: r30 = 52
    //     0xbe57e8: mov             lr, #0x34
    // 0xbe57ec: stp             lr, x16, [SP, #-0x10]!
    // 0xbe57f0: SaveReg d0
    //     0xbe57f0: str             d0, [SP, #-8]!
    // 0xbe57f4: r0 = setFloat()
    //     0xbe57f4: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe57f8: add             SP, SP, #0x18
    // 0xbe57fc: ldur            d0, [fp, #-0x28]
    // 0xbe5800: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5804: mov             fp, SP
    // 0xbe5808: CallRuntime_LibcSin(double) -> double
    //     0xbe5808: and             SP, SP, #0xfffffffffffffff0
    //     0xbe580c: mov             sp, SP
    //     0xbe5810: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbe5814: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5818: blr             x16
    //     0xbe581c: mov             x16, #8
    //     0xbe5820: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5824: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe5828: sub             sp, x16, #1, lsl #12
    //     0xbe582c: mov             SP, fp
    //     0xbe5830: ldp             fp, lr, [SP], #0x10
    // 0xbe5834: ldur            x16, [fp, #-0x10]
    // 0xbe5838: r30 = 54
    //     0xbe5838: mov             lr, #0x36
    // 0xbe583c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5840: SaveReg d0
    //     0xbe5840: str             d0, [SP, #-8]!
    // 0xbe5844: r0 = setFloat()
    //     0xbe5844: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5848: add             SP, SP, #0x18
    // 0xbe584c: ldur            d0, [fp, #-0x20]
    // 0xbe5850: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5854: mov             fp, SP
    // 0xbe5858: CallRuntime_LibcCos(double) -> double
    //     0xbe5858: and             SP, SP, #0xfffffffffffffff0
    //     0xbe585c: mov             sp, SP
    //     0xbe5860: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbe5864: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5868: blr             x16
    //     0xbe586c: mov             x16, #8
    //     0xbe5870: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5874: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe5878: sub             sp, x16, #1, lsl #12
    //     0xbe587c: mov             SP, fp
    //     0xbe5880: ldp             fp, lr, [SP], #0x10
    // 0xbe5884: ldur            x16, [fp, #-0x10]
    // 0xbe5888: r30 = 56
    //     0xbe5888: mov             lr, #0x38
    // 0xbe588c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5890: SaveReg d0
    //     0xbe5890: str             d0, [SP, #-8]!
    // 0xbe5894: r0 = setFloat()
    //     0xbe5894: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5898: add             SP, SP, #0x18
    // 0xbe589c: ldur            d0, [fp, #-0x20]
    // 0xbe58a0: stp             fp, lr, [SP, #-0x10]!
    // 0xbe58a4: mov             fp, SP
    // 0xbe58a8: CallRuntime_LibcSin(double) -> double
    //     0xbe58a8: and             SP, SP, #0xfffffffffffffff0
    //     0xbe58ac: mov             sp, SP
    //     0xbe58b0: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbe58b4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe58b8: blr             x16
    //     0xbe58bc: mov             x16, #8
    //     0xbe58c0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe58c4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe58c8: sub             sp, x16, #1, lsl #12
    //     0xbe58cc: mov             SP, fp
    //     0xbe58d0: ldp             fp, lr, [SP], #0x10
    // 0xbe58d4: ldur            x16, [fp, #-0x10]
    // 0xbe58d8: r30 = 58
    //     0xbe58d8: mov             lr, #0x3a
    // 0xbe58dc: stp             lr, x16, [SP, #-0x10]!
    // 0xbe58e0: SaveReg d0
    //     0xbe58e0: str             d0, [SP, #-8]!
    // 0xbe58e4: r0 = setFloat()
    //     0xbe58e4: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe58e8: add             SP, SP, #0x18
    // 0xbe58ec: ldur            d0, [fp, #-0x18]
    // 0xbe58f0: stp             fp, lr, [SP, #-0x10]!
    // 0xbe58f4: mov             fp, SP
    // 0xbe58f8: CallRuntime_LibcCos(double) -> double
    //     0xbe58f8: and             SP, SP, #0xfffffffffffffff0
    //     0xbe58fc: mov             sp, SP
    //     0xbe5900: ldr             x16, [THR, #0x580]  ; THR::LibcCos
    //     0xbe5904: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5908: blr             x16
    //     0xbe590c: mov             x16, #8
    //     0xbe5910: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5914: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe5918: sub             sp, x16, #1, lsl #12
    //     0xbe591c: mov             SP, fp
    //     0xbe5920: ldp             fp, lr, [SP], #0x10
    // 0xbe5924: ldur            x16, [fp, #-0x10]
    // 0xbe5928: r30 = 60
    //     0xbe5928: mov             lr, #0x3c
    // 0xbe592c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5930: SaveReg d0
    //     0xbe5930: str             d0, [SP, #-8]!
    // 0xbe5934: r0 = setFloat()
    //     0xbe5934: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5938: add             SP, SP, #0x18
    // 0xbe593c: ldur            d0, [fp, #-0x18]
    // 0xbe5940: stp             fp, lr, [SP, #-0x10]!
    // 0xbe5944: mov             fp, SP
    // 0xbe5948: CallRuntime_LibcSin(double) -> double
    //     0xbe5948: and             SP, SP, #0xfffffffffffffff0
    //     0xbe594c: mov             sp, SP
    //     0xbe5950: ldr             x16, [THR, #0x588]  ; THR::LibcSin
    //     0xbe5954: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5958: blr             x16
    //     0xbe595c: mov             x16, #8
    //     0xbe5960: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xbe5964: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xbe5968: sub             sp, x16, #1, lsl #12
    //     0xbe596c: mov             SP, fp
    //     0xbe5970: ldp             fp, lr, [SP], #0x10
    // 0xbe5974: ldur            x16, [fp, #-0x10]
    // 0xbe5978: r30 = 62
    //     0xbe5978: mov             lr, #0x3e
    // 0xbe597c: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5980: SaveReg d0
    //     0xbe5980: str             d0, [SP, #-8]!
    // 0xbe5984: r0 = setFloat()
    //     0xbe5984: bl              #0xbe5a6c  ; [dart:ui] FragmentShader::setFloat
    // 0xbe5988: add             SP, SP, #0x18
    // 0xbe598c: r0 = Null
    //     0xbe598c: mov             x0, NULL
    // 0xbe5990: LeaveFrame
    //     0xbe5990: mov             SP, fp
    //     0xbe5994: ldp             fp, lr, [SP], #0x10
    // 0xbe5998: ret
    //     0xbe5998: ret             
    // 0xbe599c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe599c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe59a0: b               #0xbe4f74
    // 0xbe59a4: r9 = _turbulenceSeed
    //     0xbe59a4: add             x9, PP, #0x37, lsl #12  ; [pp+0x37888] Field <InkSparkle._turbulenceSeed@758321118>: late (offset: 0x2c)
    //     0xbe59a8: ldr             x9, [x9, #0x888]
    // 0xbe59ac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe59ac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe59b0: r9 = _radiusScale
    //     0xbe59b0: add             x9, PP, #0x37, lsl #12  ; [pp+0x37890] Field <InkSparkle._radiusScale@758321118>: late (offset: 0x20)
    //     0xbe59b4: ldr             x9, [x9, #0x890]
    // 0xbe59b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe59b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe59bc: r9 = _fragmentShader
    //     0xbe59bc: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e3c0] Field <InkSparkle._fragmentShader@758321118>: late final (offset: 0x50)
    //     0xbe59c0: ldr             x9, [x9, #0x3c0]
    // 0xbe59c4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xbe59c4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xbe59c8: r9 = _alpha
    //     0xbe59c8: add             x9, PP, #0x37, lsl #12  ; [pp+0x37898] Field <InkSparkle._alpha@758321118>: late (offset: 0x24)
    //     0xbe59cc: ldr             x9, [x9, #0x898]
    // 0xbe59d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe59d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe59d4: r9 = _sparkleAlpha
    //     0xbe59d4: add             x9, PP, #0x37, lsl #12  ; [pp+0x378a0] Field <InkSparkle._sparkleAlpha@758321118>: late (offset: 0x28)
    //     0xbe59d8: ldr             x9, [x9, #0x8a0]
    // 0xbe59dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe59dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe59e0: r9 = _center
    //     0xbe59e0: add             x9, PP, #0x37, lsl #12  ; [pp+0x378a8] Field <InkSparkle._center@758321118>: late (offset: 0x1c)
    //     0xbe59e4: ldr             x9, [x9, #0x8a8]
    // 0xbe59e8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbe59e8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbe59ec: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe59ec: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe59f0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xbe59f0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xbe59f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe59f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xbe59f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe59f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _height(/* No info */) {
    // ** addr: 0xbe59fc, size: 0x38
    // 0xbe59fc: EnterFrame
    //     0xbe59fc: stp             fp, lr, [SP, #-0x10]!
    //     0xbe5a00: mov             fp, SP
    // 0xbe5a04: ldr             x0, [fp, #0x10]
    // 0xbe5a08: LoadField: r1 = r0->field_b
    //     0xbe5a08: ldur            w1, [x0, #0xb]
    // 0xbe5a0c: DecompressPointer r1
    //     0xbe5a0c: add             x1, x1, HEAP, lsl #32
    // 0xbe5a10: LoadField: r0 = r1->field_57
    //     0xbe5a10: ldur            w0, [x1, #0x57]
    // 0xbe5a14: DecompressPointer r0
    //     0xbe5a14: add             x0, x0, HEAP, lsl #32
    // 0xbe5a18: cmp             w0, NULL
    // 0xbe5a1c: b.eq            #0xbe5a30
    // 0xbe5a20: LoadField: d0 = r0->field_f
    //     0xbe5a20: ldur            d0, [x0, #0xf]
    // 0xbe5a24: LeaveFrame
    //     0xbe5a24: mov             SP, fp
    //     0xbe5a28: ldp             fp, lr, [SP], #0x10
    // 0xbe5a2c: ret
    //     0xbe5a2c: ret             
    // 0xbe5a30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5a30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _width(/* No info */) {
    // ** addr: 0xbe5a34, size: 0x38
    // 0xbe5a34: EnterFrame
    //     0xbe5a34: stp             fp, lr, [SP, #-0x10]!
    //     0xbe5a38: mov             fp, SP
    // 0xbe5a3c: ldr             x0, [fp, #0x10]
    // 0xbe5a40: LoadField: r1 = r0->field_b
    //     0xbe5a40: ldur            w1, [x0, #0xb]
    // 0xbe5a44: DecompressPointer r1
    //     0xbe5a44: add             x1, x1, HEAP, lsl #32
    // 0xbe5a48: LoadField: r0 = r1->field_57
    //     0xbe5a48: ldur            w0, [x1, #0x57]
    // 0xbe5a4c: DecompressPointer r0
    //     0xbe5a4c: add             x0, x0, HEAP, lsl #32
    // 0xbe5a50: cmp             w0, NULL
    // 0xbe5a54: b.eq            #0xbe5a68
    // 0xbe5a58: LoadField: d0 = r0->field_7
    //     0xbe5a58: ldur            d0, [x0, #7]
    // 0xbe5a5c: LeaveFrame
    //     0xbe5a5c: mov             SP, fp
    //     0xbe5a60: ldp             fp, lr, [SP], #0x10
    // 0xbe5a64: ret
    //     0xbe5a64: ret             
    // 0xbe5a68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xbe5a68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _clipCanvas(/* No info */) {
    // ** addr: 0xbe5ae8, size: 0x164
    // 0xbe5ae8: EnterFrame
    //     0xbe5ae8: stp             fp, lr, [SP, #-0x10]!
    //     0xbe5aec: mov             fp, SP
    // 0xbe5af0: AllocStack(0x30)
    //     0xbe5af0: sub             SP, SP, #0x30
    // 0xbe5af4: CheckStackOverflow
    //     0xbe5af4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe5af8: cmp             SP, x16
    //     0xbe5afc: b.ls            #0xbe5c44
    // 0xbe5b00: ldr             x16, [fp, #0x20]
    // 0xbe5b04: SaveReg r16
    //     0xbe5b04: str             x16, [SP, #-8]!
    // 0xbe5b08: ldr             x0, [fp, #0x20]
    // 0xbe5b0c: ClosureCall
    //     0xbe5b0c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xbe5b10: ldur            x2, [x0, #0x1f]
    //     0xbe5b14: blr             x2
    // 0xbe5b18: add             SP, SP, #8
    // 0xbe5b1c: mov             x1, x0
    // 0xbe5b20: ldr             x0, [fp, #0x18]
    // 0xbe5b24: stur            x1, [fp, #-8]
    // 0xbe5b28: cmp             w0, NULL
    // 0xbe5b2c: b.eq            #0xbe5b78
    // 0xbe5b30: r2 = LoadClassIdInstr(r0)
    //     0xbe5b30: ldur            x2, [x0, #-1]
    //     0xbe5b34: ubfx            x2, x2, #0xc, #0x14
    // 0xbe5b38: stp             x1, x0, [SP, #-0x10]!
    // 0xbe5b3c: ldr             x16, [fp, #0x10]
    // 0xbe5b40: SaveReg r16
    //     0xbe5b40: str             x16, [SP, #-8]!
    // 0xbe5b44: mov             x0, x2
    // 0xbe5b48: r4 = const [0, 0x3, 0x3, 0x2, textDirection, 0x2, null]
    //     0xbe5b48: add             x4, PP, #0x28, lsl #12  ; [pp+0x285b8] List(7) [0, 0x3, 0x3, 0x2, "textDirection", 0x2, Null]
    //     0xbe5b4c: ldr             x4, [x4, #0x5b8]
    // 0xbe5b50: r0 = GDT[cid_x0 + -0xfde]()
    //     0xbe5b50: sub             lr, x0, #0xfde
    //     0xbe5b54: ldr             lr, [x21, lr, lsl #3]
    //     0xbe5b58: blr             lr
    // 0xbe5b5c: add             SP, SP, #0x18
    // 0xbe5b60: ldr             x16, [fp, #0x28]
    // 0xbe5b64: stp             x0, x16, [SP, #-0x10]!
    // 0xbe5b68: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe5b68: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe5b6c: r0 = clipPath()
    //     0xbe5b6c: bl              #0x6629f4  ; [dart:ui] Canvas::clipPath
    // 0xbe5b70: add             SP, SP, #0x10
    // 0xbe5b74: b               #0xbe5c34
    // 0xbe5b78: ldr             x16, [fp, #0x30]
    // 0xbe5b7c: r30 = Instance_BorderRadius
    //     0xbe5b7c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152c0] Obj!BorderRadius@b37471
    //     0xbe5b80: ldr             lr, [lr, #0x2c0]
    // 0xbe5b84: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5b88: r0 = ==()
    //     0xbe5b88: bl              #0xc9c94c  ; [package:flutter/src/painting/border_radius.dart] BorderRadiusGeometry::==
    // 0xbe5b8c: add             SP, SP, #0x10
    // 0xbe5b90: tbz             w0, #4, #0xbe5c1c
    // 0xbe5b94: ldr             x0, [fp, #0x30]
    // 0xbe5b98: LoadField: r1 = r0->field_7
    //     0xbe5b98: ldur            w1, [x0, #7]
    // 0xbe5b9c: DecompressPointer r1
    //     0xbe5b9c: add             x1, x1, HEAP, lsl #32
    // 0xbe5ba0: stur            x1, [fp, #-0x28]
    // 0xbe5ba4: LoadField: r2 = r0->field_b
    //     0xbe5ba4: ldur            w2, [x0, #0xb]
    // 0xbe5ba8: DecompressPointer r2
    //     0xbe5ba8: add             x2, x2, HEAP, lsl #32
    // 0xbe5bac: stur            x2, [fp, #-0x20]
    // 0xbe5bb0: LoadField: r3 = r0->field_f
    //     0xbe5bb0: ldur            w3, [x0, #0xf]
    // 0xbe5bb4: DecompressPointer r3
    //     0xbe5bb4: add             x3, x3, HEAP, lsl #32
    // 0xbe5bb8: stur            x3, [fp, #-0x18]
    // 0xbe5bbc: LoadField: r4 = r0->field_13
    //     0xbe5bbc: ldur            w4, [x0, #0x13]
    // 0xbe5bc0: DecompressPointer r4
    //     0xbe5bc0: add             x4, x4, HEAP, lsl #32
    // 0xbe5bc4: stur            x4, [fp, #-0x10]
    // 0xbe5bc8: r0 = RRect()
    //     0xbe5bc8: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0xbe5bcc: stur            x0, [fp, #-0x30]
    // 0xbe5bd0: ldur            x16, [fp, #-8]
    // 0xbe5bd4: stp             x16, x0, [SP, #-0x10]!
    // 0xbe5bd8: ldur            x16, [fp, #-0x28]
    // 0xbe5bdc: ldur            lr, [fp, #-0x20]
    // 0xbe5be0: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5be4: ldur            x16, [fp, #-0x18]
    // 0xbe5be8: ldur            lr, [fp, #-0x10]
    // 0xbe5bec: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5bf0: r4 = const [0, 0x6, 0x6, 0x2, bottomLeft, 0x4, bottomRight, 0x5, topLeft, 0x2, topRight, 0x3, null]
    //     0xbe5bf0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21d00] List(13) [0, 0x6, 0x6, 0x2, "bottomLeft", 0x4, "bottomRight", 0x5, "topLeft", 0x2, "topRight", 0x3, Null]
    //     0xbe5bf4: ldr             x4, [x4, #0xd00]
    // 0xbe5bf8: r0 = RRect.fromRectAndCorners()
    //     0xbe5bf8: bl              #0x6706f4  ; [dart:ui] RRect::RRect.fromRectAndCorners
    // 0xbe5bfc: add             SP, SP, #0x30
    // 0xbe5c00: ldr             x16, [fp, #0x28]
    // 0xbe5c04: ldur            lr, [fp, #-0x30]
    // 0xbe5c08: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5c0c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe5c0c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe5c10: r0 = clipRRect()
    //     0xbe5c10: bl              #0x662040  ; [dart:ui] Canvas::clipRRect
    // 0xbe5c14: add             SP, SP, #0x10
    // 0xbe5c18: b               #0xbe5c34
    // 0xbe5c1c: ldr             x16, [fp, #0x28]
    // 0xbe5c20: ldur            lr, [fp, #-8]
    // 0xbe5c24: stp             lr, x16, [SP, #-0x10]!
    // 0xbe5c28: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xbe5c28: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xbe5c2c: r0 = clipRect()
    //     0xbe5c2c: bl              #0x6590f4  ; [dart:ui] Canvas::clipRect
    // 0xbe5c30: add             SP, SP, #0x10
    // 0xbe5c34: r0 = Null
    //     0xbe5c34: mov             x0, NULL
    // 0xbe5c38: LeaveFrame
    //     0xbe5c38: mov             SP, fp
    //     0xbe5c3c: ldp             fp, lr, [SP], #0x10
    // 0xbe5c40: ret
    //     0xbe5c40: ret             
    // 0xbe5c44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe5c44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe5c48: b               #0xbe5b00
  }
  _ _transformCanvas(/* No info */) {
    // ** addr: 0xbe5c4c, size: 0xb8
    // 0xbe5c4c: EnterFrame
    //     0xbe5c4c: stp             fp, lr, [SP, #-0x10]!
    //     0xbe5c50: mov             fp, SP
    // 0xbe5c54: CheckStackOverflow
    //     0xbe5c54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbe5c58: cmp             SP, x16
    //     0xbe5c5c: b.ls            #0xbe5cec
    // 0xbe5c60: ldr             x16, [fp, #0x10]
    // 0xbe5c64: SaveReg r16
    //     0xbe5c64: str             x16, [SP, #-8]!
    // 0xbe5c68: r0 = getAsTranslation()
    //     0xbe5c68: bl              #0x665a04  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::getAsTranslation
    // 0xbe5c6c: add             SP, SP, #8
    // 0xbe5c70: cmp             w0, NULL
    // 0xbe5c74: b.ne            #0xbe5c98
    // 0xbe5c78: ldr             x0, [fp, #0x10]
    // 0xbe5c7c: LoadField: r1 = r0->field_7
    //     0xbe5c7c: ldur            w1, [x0, #7]
    // 0xbe5c80: DecompressPointer r1
    //     0xbe5c80: add             x1, x1, HEAP, lsl #32
    // 0xbe5c84: ldr             x16, [fp, #0x18]
    // 0xbe5c88: stp             x1, x16, [SP, #-0x10]!
    // 0xbe5c8c: r0 = transform()
    //     0xbe5c8c: bl              #0x656f48  ; [dart:ui] Canvas::transform
    // 0xbe5c90: add             SP, SP, #0x10
    // 0xbe5c94: b               #0xbe5cdc
    // 0xbe5c98: LoadField: d0 = r0->field_7
    //     0xbe5c98: ldur            d0, [x0, #7]
    // 0xbe5c9c: LoadField: d1 = r0->field_f
    //     0xbe5c9c: ldur            d1, [x0, #0xf]
    // 0xbe5ca0: r0 = inline_Allocate_Double()
    //     0xbe5ca0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xbe5ca4: add             x0, x0, #0x10
    //     0xbe5ca8: cmp             x1, x0
    //     0xbe5cac: b.ls            #0xbe5cf4
    //     0xbe5cb0: str             x0, [THR, #0x60]  ; THR::top
    //     0xbe5cb4: sub             x0, x0, #0xf
    //     0xbe5cb8: mov             x1, #0xd108
    //     0xbe5cbc: movk            x1, #3, lsl #16
    //     0xbe5cc0: stur            x1, [x0, #-1]
    // 0xbe5cc4: StoreField: r0->field_7 = d0
    //     0xbe5cc4: stur            d0, [x0, #7]
    // 0xbe5cc8: ldr             x16, [fp, #0x18]
    // 0xbe5ccc: stp             x0, x16, [SP, #-0x10]!
    // 0xbe5cd0: SaveReg d1
    //     0xbe5cd0: str             d1, [SP, #-8]!
    // 0xbe5cd4: r0 = translate()
    //     0xbe5cd4: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0xbe5cd8: add             SP, SP, #0x18
    // 0xbe5cdc: r0 = Null
    //     0xbe5cdc: mov             x0, NULL
    // 0xbe5ce0: LeaveFrame
    //     0xbe5ce0: mov             SP, fp
    //     0xbe5ce4: ldp             fp, lr, [SP], #0x10
    // 0xbe5ce8: ret
    //     0xbe5ce8: ret             
    // 0xbe5cec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbe5cec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbe5cf0: b               #0xbe5c60
    // 0xbe5cf4: stp             q0, q1, [SP, #-0x20]!
    // 0xbe5cf8: r0 = AllocateDouble()
    //     0xbe5cf8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xbe5cfc: ldp             q0, q1, [SP], #0x20
    // 0xbe5d00: b               #0xbe5cc4
  }
  _ dispose(/* No info */) {
    // ** addr: 0xbfeb9c, size: 0xc4
    // 0xbfeb9c: EnterFrame
    //     0xbfeb9c: stp             fp, lr, [SP, #-0x10]!
    //     0xbfeba0: mov             fp, SP
    // 0xbfeba4: CheckStackOverflow
    //     0xbfeba4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xbfeba8: cmp             SP, x16
    //     0xbfebac: b.ls            #0xbfec40
    // 0xbfebb0: ldr             x0, [fp, #0x10]
    // 0xbfebb4: LoadField: r1 = r0->field_17
    //     0xbfebb4: ldur            w1, [x0, #0x17]
    // 0xbfebb8: DecompressPointer r1
    //     0xbfebb8: add             x1, x1, HEAP, lsl #32
    // 0xbfebbc: r16 = Sentinel
    //     0xbfebbc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfebc0: cmp             w1, w16
    // 0xbfebc4: b.eq            #0xbfec48
    // 0xbfebc8: SaveReg r1
    //     0xbfebc8: str             x1, [SP, #-8]!
    // 0xbfebcc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xbfebcc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xbfebd0: r0 = stop()
    //     0xbfebd0: bl              #0x593468  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::stop
    // 0xbfebd4: add             SP, SP, #8
    // 0xbfebd8: ldr             x0, [fp, #0x10]
    // 0xbfebdc: LoadField: r1 = r0->field_17
    //     0xbfebdc: ldur            w1, [x0, #0x17]
    // 0xbfebe0: DecompressPointer r1
    //     0xbfebe0: add             x1, x1, HEAP, lsl #32
    // 0xbfebe4: SaveReg r1
    //     0xbfebe4: str             x1, [SP, #-8]!
    // 0xbfebe8: r0 = dispose()
    //     0xbfebe8: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xbfebec: add             SP, SP, #8
    // 0xbfebf0: ldr             x0, [fp, #0x10]
    // 0xbfebf4: LoadField: r1 = r0->field_53
    //     0xbfebf4: ldur            w1, [x0, #0x53]
    // 0xbfebf8: DecompressPointer r1
    //     0xbfebf8: add             x1, x1, HEAP, lsl #32
    // 0xbfebfc: tbnz            w1, #4, #0xbfec20
    // 0xbfec00: LoadField: r1 = r0->field_4f
    //     0xbfec00: ldur            w1, [x0, #0x4f]
    // 0xbfec04: DecompressPointer r1
    //     0xbfec04: add             x1, x1, HEAP, lsl #32
    // 0xbfec08: r16 = Sentinel
    //     0xbfec08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xbfec0c: cmp             w1, w16
    // 0xbfec10: b.eq            #0xbfec54
    // 0xbfec14: SaveReg r1
    //     0xbfec14: str             x1, [SP, #-8]!
    // 0xbfec18: r0 = dispose()
    //     0xbfec18: bl              #0xbfec60  ; [dart:ui] FragmentShader::dispose
    // 0xbfec1c: add             SP, SP, #8
    // 0xbfec20: ldr             x16, [fp, #0x10]
    // 0xbfec24: SaveReg r16
    //     0xbfec24: str             x16, [SP, #-8]!
    // 0xbfec28: r0 = dispose()
    //     0xbfec28: bl              #0x795b14  ; [package:flutter/src/material/material.dart] InkFeature::dispose
    // 0xbfec2c: add             SP, SP, #8
    // 0xbfec30: r0 = Null
    //     0xbfec30: mov             x0, NULL
    // 0xbfec34: LeaveFrame
    //     0xbfec34: mov             SP, fp
    //     0xbfec38: ldp             fp, lr, [SP], #0x10
    // 0xbfec3c: ret
    //     0xbfec3c: ret             
    // 0xbfec40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xbfec40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xbfec44: b               #0xbfebb0
    // 0xbfec48: r9 = _animationController
    //     0xbfec48: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e3b8] Field <InkSparkle._animationController@758321118>: late (offset: 0x18)
    //     0xbfec4c: ldr             x9, [x9, #0x3b8]
    // 0xbfec50: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfec50: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xbfec54: r9 = _fragmentShader
    //     0xbfec54: add             x9, PP, #0x2e, lsl #12  ; [pp+0x2e3c0] Field <InkSparkle._fragmentShader@758321118>: late final (offset: 0x50)
    //     0xbfec58: ldr             x9, [x9, #0x3c0]
    // 0xbfec5c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xbfec5c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

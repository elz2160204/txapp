// lib: , url: package:flutter/src/material/text_selection.dart

// class id: 1049325, size: 0x8
class :: {

  static late final TextSelectionControls materialTextSelectionHandleControls; // offset: 0xe34
  static late final TextSelectionControls materialTextSelectionControls; // offset: 0xe38

  static TextSelectionControls materialTextSelectionControls() {
    // ** addr: 0x83ec94, size: 0x18
    // 0x83ec94: EnterFrame
    //     0x83ec94: stp             fp, lr, [SP, #-0x10]!
    //     0x83ec98: mov             fp, SP
    // 0x83ec9c: r0 = MaterialTextSelectionControls()
    //     0x83ec9c: bl              #0x83ecac  ; AllocateMaterialTextSelectionControlsStub -> MaterialTextSelectionControls (size=0x8)
    // 0x83eca0: LeaveFrame
    //     0x83eca0: mov             SP, fp
    //     0x83eca4: ldp             fp, lr, [SP], #0x10
    // 0x83eca8: ret
    //     0x83eca8: ret             
  }
  static TextSelectionControls materialTextSelectionHandleControls() {
    // ** addr: 0x872e18, size: 0x18
    // 0x872e18: EnterFrame
    //     0x872e18: stp             fp, lr, [SP, #-0x10]!
    //     0x872e1c: mov             fp, SP
    // 0x872e20: r0 = MaterialTextSelectionHandleControls()
    //     0x872e20: bl              #0x872e30  ; AllocateMaterialTextSelectionHandleControlsStub -> MaterialTextSelectionHandleControls (size=0x8)
    // 0x872e24: LeaveFrame
    //     0x872e24: mov             SP, fp
    //     0x872e28: ldp             fp, lr, [SP], #0x10
    // 0x872e2c: ret
    //     0x872e2c: ret             
  }
}

// class id: 2125, size: 0x10, field offset: 0x8
//   const constructor, 
class _TextSelectionToolbarItemData extends Object {
}

// class id: 3264, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __TextSelectionControlsToolbarState&State&TickerProviderStateMixin extends State<_TextSelectionControlsToolbar>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ activate(/* No info */) {
    // ** addr: 0x81f884, size: 0x3c
    // 0x81f884: EnterFrame
    //     0x81f884: stp             fp, lr, [SP, #-0x10]!
    //     0x81f888: mov             fp, SP
    // 0x81f88c: CheckStackOverflow
    //     0x81f88c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f890: cmp             SP, x16
    //     0x81f894: b.ls            #0x81f8b8
    // 0x81f898: ldr             x16, [fp, #0x10]
    // 0x81f89c: SaveReg r16
    //     0x81f89c: str             x16, [SP, #-8]!
    // 0x81f8a0: r0 = _updateTickerModeNotifier()
    //     0x81f8a0: bl              #0x81f8c0  ; [package:flutter/src/material/text_selection.dart] __TextSelectionControlsToolbarState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f8a4: add             SP, SP, #8
    // 0x81f8a8: r0 = Null
    //     0x81f8a8: mov             x0, NULL
    // 0x81f8ac: LeaveFrame
    //     0x81f8ac: mov             SP, fp
    //     0x81f8b0: ldp             fp, lr, [SP], #0x10
    // 0x81f8b4: ret
    //     0x81f8b4: ret             
    // 0x81f8b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f8b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f8bc: b               #0x81f898
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x81f8c0, size: 0x11c
    // 0x81f8c0: EnterFrame
    //     0x81f8c0: stp             fp, lr, [SP, #-0x10]!
    //     0x81f8c4: mov             fp, SP
    // 0x81f8c8: AllocStack(0x10)
    //     0x81f8c8: sub             SP, SP, #0x10
    // 0x81f8cc: CheckStackOverflow
    //     0x81f8cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f8d0: cmp             SP, x16
    //     0x81f8d4: b.ls            #0x81f9d0
    // 0x81f8d8: ldr             x0, [fp, #0x10]
    // 0x81f8dc: LoadField: r1 = r0->field_f
    //     0x81f8dc: ldur            w1, [x0, #0xf]
    // 0x81f8e0: DecompressPointer r1
    //     0x81f8e0: add             x1, x1, HEAP, lsl #32
    // 0x81f8e4: cmp             w1, NULL
    // 0x81f8e8: b.eq            #0x81f9d8
    // 0x81f8ec: SaveReg r1
    //     0x81f8ec: str             x1, [SP, #-8]!
    // 0x81f8f0: r0 = getNotifier()
    //     0x81f8f0: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x81f8f4: add             SP, SP, #8
    // 0x81f8f8: mov             x1, x0
    // 0x81f8fc: ldr             x0, [fp, #0x10]
    // 0x81f900: stur            x1, [fp, #-0x10]
    // 0x81f904: LoadField: r2 = r0->field_17
    //     0x81f904: ldur            w2, [x0, #0x17]
    // 0x81f908: DecompressPointer r2
    //     0x81f908: add             x2, x2, HEAP, lsl #32
    // 0x81f90c: stur            x2, [fp, #-8]
    // 0x81f910: cmp             w1, w2
    // 0x81f914: b.ne            #0x81f928
    // 0x81f918: r0 = Null
    //     0x81f918: mov             x0, NULL
    // 0x81f91c: LeaveFrame
    //     0x81f91c: mov             SP, fp
    //     0x81f920: ldp             fp, lr, [SP], #0x10
    // 0x81f924: ret
    //     0x81f924: ret             
    // 0x81f928: cmp             w2, NULL
    // 0x81f92c: b.eq            #0x81f968
    // 0x81f930: r1 = 1
    //     0x81f930: mov             x1, #1
    // 0x81f934: r0 = AllocateContext()
    //     0x81f934: bl              #0xd68aa4  ; AllocateContextStub
    // 0x81f938: mov             x1, x0
    // 0x81f93c: ldr             x0, [fp, #0x10]
    // 0x81f940: StoreField: r1->field_f = r0
    //     0x81f940: stur            w0, [x1, #0xf]
    // 0x81f944: mov             x2, x1
    // 0x81f948: r1 = Function '_updateTickers@156311458':.
    //     0x81f948: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b4f0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x81f94c: ldr             x1, [x1, #0x4f0]
    // 0x81f950: r0 = AllocateClosure()
    //     0x81f950: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x81f954: ldur            x16, [fp, #-8]
    // 0x81f958: stp             x0, x16, [SP, #-0x10]!
    // 0x81f95c: r0 = removeListener()
    //     0x81f95c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x81f960: add             SP, SP, #0x10
    // 0x81f964: ldr             x0, [fp, #0x10]
    // 0x81f968: r1 = 1
    //     0x81f968: mov             x1, #1
    // 0x81f96c: r0 = AllocateContext()
    //     0x81f96c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x81f970: mov             x1, x0
    // 0x81f974: ldr             x0, [fp, #0x10]
    // 0x81f978: StoreField: r1->field_f = r0
    //     0x81f978: stur            w0, [x1, #0xf]
    // 0x81f97c: mov             x2, x1
    // 0x81f980: r1 = Function '_updateTickers@156311458':.
    //     0x81f980: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b4f0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x81f984: ldr             x1, [x1, #0x4f0]
    // 0x81f988: r0 = AllocateClosure()
    //     0x81f988: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x81f98c: ldur            x16, [fp, #-0x10]
    // 0x81f990: stp             x0, x16, [SP, #-0x10]!
    // 0x81f994: r0 = addListener()
    //     0x81f994: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x81f998: add             SP, SP, #0x10
    // 0x81f99c: ldur            x0, [fp, #-0x10]
    // 0x81f9a0: ldr             x1, [fp, #0x10]
    // 0x81f9a4: StoreField: r1->field_17 = r0
    //     0x81f9a4: stur            w0, [x1, #0x17]
    //     0x81f9a8: ldurb           w16, [x1, #-1]
    //     0x81f9ac: ldurb           w17, [x0, #-1]
    //     0x81f9b0: and             x16, x17, x16, lsr #2
    //     0x81f9b4: tst             x16, HEAP, lsr #32
    //     0x81f9b8: b.eq            #0x81f9c0
    //     0x81f9bc: bl              #0xd6826c
    // 0x81f9c0: r0 = Null
    //     0x81f9c0: mov             x0, NULL
    // 0x81f9c4: LeaveFrame
    //     0x81f9c4: mov             SP, fp
    //     0x81f9c8: ldp             fp, lr, [SP], #0x10
    // 0x81f9cc: ret
    //     0x81f9cc: ret             
    // 0x81f9d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f9d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f9d4: b               #0x81f8d8
    // 0x81f9d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x81f9d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa53280, size: 0x8c
    // 0xa53280: EnterFrame
    //     0xa53280: stp             fp, lr, [SP, #-0x10]!
    //     0xa53284: mov             fp, SP
    // 0xa53288: AllocStack(0x8)
    //     0xa53288: sub             SP, SP, #8
    // 0xa5328c: CheckStackOverflow
    //     0xa5328c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa53290: cmp             SP, x16
    //     0xa53294: b.ls            #0xa53304
    // 0xa53298: ldr             x0, [fp, #0x10]
    // 0xa5329c: LoadField: r1 = r0->field_17
    //     0xa5329c: ldur            w1, [x0, #0x17]
    // 0xa532a0: DecompressPointer r1
    //     0xa532a0: add             x1, x1, HEAP, lsl #32
    // 0xa532a4: stur            x1, [fp, #-8]
    // 0xa532a8: cmp             w1, NULL
    // 0xa532ac: b.ne            #0xa532b8
    // 0xa532b0: mov             x1, x0
    // 0xa532b4: b               #0xa532f0
    // 0xa532b8: r1 = 1
    //     0xa532b8: mov             x1, #1
    // 0xa532bc: r0 = AllocateContext()
    //     0xa532bc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa532c0: mov             x1, x0
    // 0xa532c4: ldr             x0, [fp, #0x10]
    // 0xa532c8: StoreField: r1->field_f = r0
    //     0xa532c8: stur            w0, [x1, #0xf]
    // 0xa532cc: mov             x2, x1
    // 0xa532d0: r1 = Function '_updateTickers@156311458':.
    //     0xa532d0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b4f0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xa532d4: ldr             x1, [x1, #0x4f0]
    // 0xa532d8: r0 = AllocateClosure()
    //     0xa532d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa532dc: ldur            x16, [fp, #-8]
    // 0xa532e0: stp             x0, x16, [SP, #-0x10]!
    // 0xa532e4: r0 = removeListener()
    //     0xa532e4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa532e8: add             SP, SP, #0x10
    // 0xa532ec: ldr             x1, [fp, #0x10]
    // 0xa532f0: StoreField: r1->field_17 = rNULL
    //     0xa532f0: stur            NULL, [x1, #0x17]
    // 0xa532f4: r0 = Null
    //     0xa532f4: mov             x0, NULL
    // 0xa532f8: LeaveFrame
    //     0xa532f8: mov             SP, fp
    //     0xa532fc: ldp             fp, lr, [SP], #0x10
    // 0xa53300: ret
    //     0xa53300: ret             
    // 0xa53304: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53304: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa53308: b               #0xa53298
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa5330c, size: 0x48
    // 0xa5330c: EnterFrame
    //     0xa5330c: stp             fp, lr, [SP, #-0x10]!
    //     0xa53310: mov             fp, SP
    // 0xa53314: ldr             x0, [fp, #0x10]
    // 0xa53318: LoadField: r1 = r0->field_17
    //     0xa53318: ldur            w1, [x0, #0x17]
    // 0xa5331c: DecompressPointer r1
    //     0xa5331c: add             x1, x1, HEAP, lsl #32
    // 0xa53320: CheckStackOverflow
    //     0xa53320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa53324: cmp             SP, x16
    //     0xa53328: b.ls            #0xa5334c
    // 0xa5332c: LoadField: r0 = r1->field_f
    //     0xa5332c: ldur            w0, [x1, #0xf]
    // 0xa53330: DecompressPointer r0
    //     0xa53330: add             x0, x0, HEAP, lsl #32
    // 0xa53334: SaveReg r0
    //     0xa53334: str             x0, [SP, #-8]!
    // 0xa53338: r0 = dispose()
    //     0xa53338: bl              #0xa53280  ; [package:flutter/src/material/text_selection.dart] __TextSelectionControlsToolbarState&State&TickerProviderStateMixin::dispose
    // 0xa5333c: add             SP, SP, #8
    // 0xa53340: LeaveFrame
    //     0xa53340: mov             SP, fp
    //     0xa53344: ldp             fp, lr, [SP], #0x10
    // 0xa53348: ret
    //     0xa53348: ret             
    // 0xa5334c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5334c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa53350: b               #0xa5332c
  }
}

// class id: 3265, size: 0x1c, field offset: 0x1c
class _TextSelectionControlsToolbarState extends __TextSelectionControlsToolbarState&State&TickerProviderStateMixin {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7bf78c, size: 0x16c
    // 0x7bf78c: EnterFrame
    //     0x7bf78c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf790: mov             fp, SP
    // 0x7bf794: AllocStack(0x10)
    //     0x7bf794: sub             SP, SP, #0x10
    // 0x7bf798: CheckStackOverflow
    //     0x7bf798: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf79c: cmp             SP, x16
    //     0x7bf7a0: b.ls            #0x7bf8ec
    // 0x7bf7a4: ldr             x0, [fp, #0x10]
    // 0x7bf7a8: r2 = Null
    //     0x7bf7a8: mov             x2, NULL
    // 0x7bf7ac: r1 = Null
    //     0x7bf7ac: mov             x1, NULL
    // 0x7bf7b0: r4 = 59
    //     0x7bf7b0: mov             x4, #0x3b
    // 0x7bf7b4: branchIfSmi(r0, 0x7bf7c0)
    //     0x7bf7b4: tbz             w0, #0, #0x7bf7c0
    // 0x7bf7b8: r4 = LoadClassIdInstr(r0)
    //     0x7bf7b8: ldur            x4, [x0, #-1]
    //     0x7bf7bc: ubfx            x4, x4, #0xc, #0x14
    // 0x7bf7c0: r17 = 4112
    //     0x7bf7c0: mov             x17, #0x1010
    // 0x7bf7c4: cmp             x4, x17
    // 0x7bf7c8: b.eq            #0x7bf7e0
    // 0x7bf7cc: r8 = _TextSelectionControlsToolbar
    //     0x7bf7cc: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4b530] Type: _TextSelectionControlsToolbar
    //     0x7bf7d0: ldr             x8, [x8, #0x530]
    // 0x7bf7d4: r3 = Null
    //     0x7bf7d4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b538] Null
    //     0x7bf7d8: ldr             x3, [x3, #0x538]
    // 0x7bf7dc: r0 = _TextSelectionControlsToolbar()
    //     0x7bf7dc: bl              #0x7bf8f8  ; IsType__TextSelectionControlsToolbar_Stub
    // 0x7bf7e0: ldr             x3, [fp, #0x18]
    // 0x7bf7e4: LoadField: r2 = r3->field_7
    //     0x7bf7e4: ldur            w2, [x3, #7]
    // 0x7bf7e8: DecompressPointer r2
    //     0x7bf7e8: add             x2, x2, HEAP, lsl #32
    // 0x7bf7ec: ldr             x0, [fp, #0x10]
    // 0x7bf7f0: r1 = Null
    //     0x7bf7f0: mov             x1, NULL
    // 0x7bf7f4: cmp             w2, NULL
    // 0x7bf7f8: b.eq            #0x7bf81c
    // 0x7bf7fc: LoadField: r4 = r2->field_17
    //     0x7bf7fc: ldur            w4, [x2, #0x17]
    // 0x7bf800: DecompressPointer r4
    //     0x7bf800: add             x4, x4, HEAP, lsl #32
    // 0x7bf804: r8 = X0 bound StatefulWidget
    //     0x7bf804: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7bf808: ldr             x8, [x8, #0x858]
    // 0x7bf80c: LoadField: r9 = r4->field_7
    //     0x7bf80c: ldur            x9, [x4, #7]
    // 0x7bf810: r3 = Null
    //     0x7bf810: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4b548] Null
    //     0x7bf814: ldr             x3, [x3, #0x548]
    // 0x7bf818: blr             x9
    // 0x7bf81c: ldr             x0, [fp, #0x18]
    // 0x7bf820: LoadField: r1 = r0->field_b
    //     0x7bf820: ldur            w1, [x0, #0xb]
    // 0x7bf824: DecompressPointer r1
    //     0x7bf824: add             x1, x1, HEAP, lsl #32
    // 0x7bf828: cmp             w1, NULL
    // 0x7bf82c: b.eq            #0x7bf8f4
    // 0x7bf830: LoadField: r2 = r1->field_b
    //     0x7bf830: ldur            w2, [x1, #0xb]
    // 0x7bf834: DecompressPointer r2
    //     0x7bf834: add             x2, x2, HEAP, lsl #32
    // 0x7bf838: ldr             x1, [fp, #0x10]
    // 0x7bf83c: stur            x2, [fp, #-0x10]
    // 0x7bf840: LoadField: r3 = r1->field_b
    //     0x7bf840: ldur            w3, [x1, #0xb]
    // 0x7bf844: DecompressPointer r3
    //     0x7bf844: add             x3, x3, HEAP, lsl #32
    // 0x7bf848: stur            x3, [fp, #-8]
    // 0x7bf84c: cmp             w2, w3
    // 0x7bf850: b.eq            #0x7bf8dc
    // 0x7bf854: cmp             w2, NULL
    // 0x7bf858: b.ne            #0x7bf864
    // 0x7bf85c: mov             x0, x3
    // 0x7bf860: b               #0x7bf89c
    // 0x7bf864: r1 = 1
    //     0x7bf864: mov             x1, #1
    // 0x7bf868: r0 = AllocateContext()
    //     0x7bf868: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bf86c: mov             x1, x0
    // 0x7bf870: ldr             x0, [fp, #0x18]
    // 0x7bf874: StoreField: r1->field_f = r0
    //     0x7bf874: stur            w0, [x1, #0xf]
    // 0x7bf878: mov             x2, x1
    // 0x7bf87c: r1 = Function '_onChangedClipboardStatus@825283233':.
    //     0x7bf87c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b520] AnonymousClosure: (0x7bf91c), in [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7bf964)
    //     0x7bf880: ldr             x1, [x1, #0x520]
    // 0x7bf884: r0 = AllocateClosure()
    //     0x7bf884: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bf888: ldur            x16, [fp, #-0x10]
    // 0x7bf88c: stp             x0, x16, [SP, #-0x10]!
    // 0x7bf890: r0 = addListener()
    //     0x7bf890: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x7bf894: add             SP, SP, #0x10
    // 0x7bf898: ldur            x0, [fp, #-8]
    // 0x7bf89c: cmp             w0, NULL
    // 0x7bf8a0: b.eq            #0x7bf8dc
    // 0x7bf8a4: ldr             x1, [fp, #0x18]
    // 0x7bf8a8: r1 = 1
    //     0x7bf8a8: mov             x1, #1
    // 0x7bf8ac: r0 = AllocateContext()
    //     0x7bf8ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7bf8b0: mov             x1, x0
    // 0x7bf8b4: ldr             x0, [fp, #0x18]
    // 0x7bf8b8: StoreField: r1->field_f = r0
    //     0x7bf8b8: stur            w0, [x1, #0xf]
    // 0x7bf8bc: mov             x2, x1
    // 0x7bf8c0: r1 = Function '_onChangedClipboardStatus@825283233':.
    //     0x7bf8c0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b520] AnonymousClosure: (0x7bf91c), in [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7bf964)
    //     0x7bf8c4: ldr             x1, [x1, #0x520]
    // 0x7bf8c8: r0 = AllocateClosure()
    //     0x7bf8c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bf8cc: ldur            x16, [fp, #-8]
    // 0x7bf8d0: stp             x0, x16, [SP, #-0x10]!
    // 0x7bf8d4: r0 = removeListener()
    //     0x7bf8d4: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0x7bf8d8: add             SP, SP, #0x10
    // 0x7bf8dc: r0 = Null
    //     0x7bf8dc: mov             x0, NULL
    // 0x7bf8e0: LeaveFrame
    //     0x7bf8e0: mov             SP, fp
    //     0x7bf8e4: ldp             fp, lr, [SP], #0x10
    // 0x7bf8e8: ret
    //     0x7bf8e8: ret             
    // 0x7bf8ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf8ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf8f0: b               #0x7bf7a4
    // 0x7bf8f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7bf8f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onChangedClipboardStatus(dynamic) {
    // ** addr: 0x7bf91c, size: 0x48
    // 0x7bf91c: EnterFrame
    //     0x7bf91c: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf920: mov             fp, SP
    // 0x7bf924: ldr             x0, [fp, #0x10]
    // 0x7bf928: LoadField: r1 = r0->field_17
    //     0x7bf928: ldur            w1, [x0, #0x17]
    // 0x7bf92c: DecompressPointer r1
    //     0x7bf92c: add             x1, x1, HEAP, lsl #32
    // 0x7bf930: CheckStackOverflow
    //     0x7bf930: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf934: cmp             SP, x16
    //     0x7bf938: b.ls            #0x7bf95c
    // 0x7bf93c: LoadField: r0 = r1->field_f
    //     0x7bf93c: ldur            w0, [x1, #0xf]
    // 0x7bf940: DecompressPointer r0
    //     0x7bf940: add             x0, x0, HEAP, lsl #32
    // 0x7bf944: SaveReg r0
    //     0x7bf944: str             x0, [SP, #-8]!
    // 0x7bf948: r0 = _onChangedClipboardStatus()
    //     0x7bf948: bl              #0x7bf964  ; [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::_onChangedClipboardStatus
    // 0x7bf94c: add             SP, SP, #8
    // 0x7bf950: LeaveFrame
    //     0x7bf950: mov             SP, fp
    //     0x7bf954: ldp             fp, lr, [SP], #0x10
    // 0x7bf958: ret
    //     0x7bf958: ret             
    // 0x7bf95c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf95c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf960: b               #0x7bf93c
  }
  _ _onChangedClipboardStatus(/* No info */) {
    // ** addr: 0x7bf964, size: 0x4c
    // 0x7bf964: EnterFrame
    //     0x7bf964: stp             fp, lr, [SP, #-0x10]!
    //     0x7bf968: mov             fp, SP
    // 0x7bf96c: CheckStackOverflow
    //     0x7bf96c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7bf970: cmp             SP, x16
    //     0x7bf974: b.ls            #0x7bf9a8
    // 0x7bf978: r1 = Function '<anonymous closure>':.
    //     0x7bf978: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b528] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7bf97c: ldr             x1, [x1, #0x528]
    // 0x7bf980: r2 = Null
    //     0x7bf980: mov             x2, NULL
    // 0x7bf984: r0 = AllocateClosure()
    //     0x7bf984: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7bf988: ldr             x16, [fp, #0x10]
    // 0x7bf98c: stp             x0, x16, [SP, #-0x10]!
    // 0x7bf990: r0 = setState()
    //     0x7bf990: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7bf994: add             SP, SP, #0x10
    // 0x7bf998: r0 = Null
    //     0x7bf998: mov             x0, NULL
    // 0x7bf99c: LeaveFrame
    //     0x7bf99c: mov             SP, fp
    //     0x7bf9a0: ldp             fp, lr, [SP], #0x10
    // 0x7bf9a4: ret
    //     0x7bf9a4: ret             
    // 0x7bf9a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7bf9a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7bf9ac: b               #0x7bf978
  }
  _ build(/* No info */) {
    // ** addr: 0x872ffc, size: 0x8d4
    // 0x872ffc: EnterFrame
    //     0x872ffc: stp             fp, lr, [SP, #-0x10]!
    //     0x873000: mov             fp, SP
    // 0x873004: AllocStack(0x38)
    //     0x873004: sub             SP, SP, #0x38
    // 0x873008: CheckStackOverflow
    //     0x873008: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x87300c: cmp             SP, x16
    //     0x873010: b.ls            #0x873830
    // 0x873014: ldr             x1, [fp, #0x18]
    // 0x873018: LoadField: r0 = r1->field_b
    //     0x873018: ldur            w0, [x1, #0xb]
    // 0x87301c: DecompressPointer r0
    //     0x87301c: add             x0, x0, HEAP, lsl #32
    // 0x873020: cmp             w0, NULL
    // 0x873024: b.eq            #0x873838
    // 0x873028: LoadField: r2 = r0->field_17
    //     0x873028: ldur            w2, [x0, #0x17]
    // 0x87302c: DecompressPointer r2
    //     0x87302c: add             x2, x2, HEAP, lsl #32
    // 0x873030: cmp             w2, NULL
    // 0x873034: b.ne            #0x87307c
    // 0x873038: LoadField: r2 = r0->field_1b
    //     0x873038: ldur            w2, [x0, #0x1b]
    // 0x87303c: DecompressPointer r2
    //     0x87303c: add             x2, x2, HEAP, lsl #32
    // 0x873040: cmp             w2, NULL
    // 0x873044: b.ne            #0x87307c
    // 0x873048: LoadField: r2 = r0->field_1f
    //     0x873048: ldur            w2, [x0, #0x1f]
    // 0x87304c: DecompressPointer r2
    //     0x87304c: add             x2, x2, HEAP, lsl #32
    // 0x873050: cmp             w2, NULL
    // 0x873054: b.ne            #0x87307c
    // 0x873058: LoadField: r2 = r0->field_23
    //     0x873058: ldur            w2, [x0, #0x23]
    // 0x87305c: DecompressPointer r2
    //     0x87305c: add             x2, x2, HEAP, lsl #32
    // 0x873060: cmp             w2, NULL
    // 0x873064: b.ne            #0x87307c
    // 0x873068: r0 = Instance_SizedBox
    //     0x873068: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x87306c: ldr             x0, [x0, #0x738]
    // 0x873070: LeaveFrame
    //     0x873070: mov             SP, fp
    //     0x873074: ldp             fp, lr, [SP], #0x10
    // 0x873078: ret
    //     0x873078: ret             
    // 0x87307c: LoadField: r2 = r0->field_1f
    //     0x87307c: ldur            w2, [x0, #0x1f]
    // 0x873080: DecompressPointer r2
    //     0x873080: add             x2, x2, HEAP, lsl #32
    // 0x873084: cmp             w2, NULL
    // 0x873088: b.eq            #0x8730c8
    // 0x87308c: LoadField: r2 = r0->field_b
    //     0x87308c: ldur            w2, [x0, #0xb]
    // 0x873090: DecompressPointer r2
    //     0x873090: add             x2, x2, HEAP, lsl #32
    // 0x873094: cmp             w2, NULL
    // 0x873098: b.eq            #0x8730c8
    // 0x87309c: LoadField: r3 = r2->field_27
    //     0x87309c: ldur            w3, [x2, #0x27]
    // 0x8730a0: DecompressPointer r3
    //     0x8730a0: add             x3, x3, HEAP, lsl #32
    // 0x8730a4: r16 = Instance_ClipboardStatus
    //     0x8730a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc88] Obj!ClipboardStatus@b63451
    //     0x8730a8: ldr             x16, [x16, #0xc88]
    // 0x8730ac: cmp             w3, w16
    // 0x8730b0: b.ne            #0x8730c8
    // 0x8730b4: r0 = Instance_SizedBox
    //     0x8730b4: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x8730b8: ldr             x0, [x0, #0x738]
    // 0x8730bc: LeaveFrame
    //     0x8730bc: mov             SP, fp
    //     0x8730c0: ldp             fp, lr, [SP], #0x10
    // 0x8730c4: ret
    //     0x8730c4: ret             
    // 0x8730c8: LoadField: r2 = r0->field_f
    //     0x8730c8: ldur            w2, [x0, #0xf]
    // 0x8730cc: DecompressPointer r2
    //     0x8730cc: add             x2, x2, HEAP, lsl #32
    // 0x8730d0: r0 = LoadClassIdInstr(r2)
    //     0x8730d0: ldur            x0, [x2, #-1]
    //     0x8730d4: ubfx            x0, x0, #0xc, #0x14
    // 0x8730d8: stp             xzr, x2, [SP, #-0x10]!
    // 0x8730dc: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8730dc: sub             lr, x0, #0xd83
    //     0x8730e0: ldr             lr, [x21, lr, lsl #3]
    //     0x8730e4: blr             lr
    // 0x8730e8: add             SP, SP, #0x10
    // 0x8730ec: mov             x2, x0
    // 0x8730f0: ldr             x1, [fp, #0x18]
    // 0x8730f4: stur            x2, [fp, #-8]
    // 0x8730f8: LoadField: r0 = r1->field_b
    //     0x8730f8: ldur            w0, [x1, #0xb]
    // 0x8730fc: DecompressPointer r0
    //     0x8730fc: add             x0, x0, HEAP, lsl #32
    // 0x873100: cmp             w0, NULL
    // 0x873104: b.eq            #0x87383c
    // 0x873108: LoadField: r3 = r0->field_f
    //     0x873108: ldur            w3, [x0, #0xf]
    // 0x87310c: DecompressPointer r3
    //     0x87310c: add             x3, x3, HEAP, lsl #32
    // 0x873110: r0 = LoadClassIdInstr(r3)
    //     0x873110: ldur            x0, [x3, #-1]
    //     0x873114: ubfx            x0, x0, #0xc, #0x14
    // 0x873118: SaveReg r3
    //     0x873118: str             x3, [SP, #-8]!
    // 0x87311c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x87311c: mov             x17, #0xb8ea
    //     0x873120: add             lr, x0, x17
    //     0x873124: ldr             lr, [x21, lr, lsl #3]
    //     0x873128: blr             lr
    // 0x87312c: add             SP, SP, #8
    // 0x873130: r1 = LoadInt32Instr(r0)
    //     0x873130: sbfx            x1, x0, #1, #0x1f
    // 0x873134: cmp             x1, #1
    // 0x873138: b.le            #0x873180
    // 0x87313c: ldr             x1, [fp, #0x18]
    // 0x873140: LoadField: r0 = r1->field_b
    //     0x873140: ldur            w0, [x1, #0xb]
    // 0x873144: DecompressPointer r0
    //     0x873144: add             x0, x0, HEAP, lsl #32
    // 0x873148: cmp             w0, NULL
    // 0x87314c: b.eq            #0x873840
    // 0x873150: LoadField: r2 = r0->field_f
    //     0x873150: ldur            w2, [x0, #0xf]
    // 0x873154: DecompressPointer r2
    //     0x873154: add             x2, x2, HEAP, lsl #32
    // 0x873158: r0 = LoadClassIdInstr(r2)
    //     0x873158: ldur            x0, [x2, #-1]
    //     0x87315c: ubfx            x0, x0, #0xc, #0x14
    // 0x873160: r16 = 2
    //     0x873160: mov             x16, #2
    // 0x873164: stp             x16, x2, [SP, #-0x10]!
    // 0x873168: r0 = GDT[cid_x0 + -0xd83]()
    //     0x873168: sub             lr, x0, #0xd83
    //     0x87316c: ldr             lr, [x21, lr, lsl #3]
    //     0x873170: blr             lr
    // 0x873174: add             SP, SP, #0x10
    // 0x873178: mov             x2, x0
    // 0x87317c: b               #0x8731bc
    // 0x873180: ldr             x1, [fp, #0x18]
    // 0x873184: LoadField: r0 = r1->field_b
    //     0x873184: ldur            w0, [x1, #0xb]
    // 0x873188: DecompressPointer r0
    //     0x873188: add             x0, x0, HEAP, lsl #32
    // 0x87318c: cmp             w0, NULL
    // 0x873190: b.eq            #0x873844
    // 0x873194: LoadField: r2 = r0->field_f
    //     0x873194: ldur            w2, [x0, #0xf]
    // 0x873198: DecompressPointer r2
    //     0x873198: add             x2, x2, HEAP, lsl #32
    // 0x87319c: r0 = LoadClassIdInstr(r2)
    //     0x87319c: ldur            x0, [x2, #-1]
    //     0x8731a0: ubfx            x0, x0, #0xc, #0x14
    // 0x8731a4: stp             xzr, x2, [SP, #-0x10]!
    // 0x8731a8: r0 = GDT[cid_x0 + -0xd83]()
    //     0x8731a8: sub             lr, x0, #0xd83
    //     0x8731ac: ldr             lr, [x21, lr, lsl #3]
    //     0x8731b0: blr             lr
    // 0x8731b4: add             SP, SP, #0x10
    // 0x8731b8: mov             x2, x0
    // 0x8731bc: ldr             x0, [fp, #0x18]
    // 0x8731c0: ldur            x1, [fp, #-8]
    // 0x8731c4: d0 = 0.000000
    //     0x8731c4: eor             v0.16b, v0.16b, v0.16b
    // 0x8731c8: stur            x2, [fp, #-0x10]
    // 0x8731cc: LoadField: r3 = r1->field_7
    //     0x8731cc: ldur            w3, [x1, #7]
    // 0x8731d0: DecompressPointer r3
    //     0x8731d0: add             x3, x3, HEAP, lsl #32
    // 0x8731d4: LoadField: d1 = r3->field_f
    //     0x8731d4: ldur            d1, [x3, #0xf]
    // 0x8731d8: LoadField: r1 = r0->field_b
    //     0x8731d8: ldur            w1, [x0, #0xb]
    // 0x8731dc: DecompressPointer r1
    //     0x8731dc: add             x1, x1, HEAP, lsl #32
    // 0x8731e0: cmp             w1, NULL
    // 0x8731e4: b.eq            #0x873848
    // 0x8731e8: LoadField: d2 = r1->field_2b
    //     0x8731e8: ldur            d2, [x1, #0x2b]
    // 0x8731ec: fsub            d3, d1, d2
    // 0x8731f0: fcmp            d3, d0
    // 0x8731f4: b.vs            #0x873234
    // 0x8731f8: b.le            #0x873234
    // 0x8731fc: r1 = inline_Allocate_Double()
    //     0x8731fc: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x873200: add             x1, x1, #0x10
    //     0x873204: cmp             x3, x1
    //     0x873208: b.ls            #0x87384c
    //     0x87320c: str             x1, [THR, #0x60]  ; THR::top
    //     0x873210: sub             x1, x1, #0xf
    //     0x873214: mov             x3, #0xd108
    //     0x873218: movk            x3, #3, lsl #16
    //     0x87321c: stur            x3, [x1, #-1]
    // 0x873220: StoreField: r1->field_7 = d3
    //     0x873220: stur            d3, [x1, #7]
    // 0x873224: mov             x16, x0
    // 0x873228: mov             x0, x1
    // 0x87322c: mov             x1, x16
    // 0x873230: b               #0x8732a4
    // 0x873234: fcmp            d3, d0
    // 0x873238: b.vs            #0x87324c
    // 0x87323c: b.ge            #0x87324c
    // 0x873240: mov             x1, x0
    // 0x873244: r0 = 0
    //     0x873244: mov             x0, #0
    // 0x873248: b               #0x8732a4
    // 0x87324c: r1 = inline_Allocate_Double()
    //     0x87324c: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0x873250: add             x1, x1, #0x10
    //     0x873254: cmp             x3, x1
    //     0x873258: b.ls            #0x873868
    //     0x87325c: str             x1, [THR, #0x60]  ; THR::top
    //     0x873260: sub             x1, x1, #0xf
    //     0x873264: mov             x3, #0xd108
    //     0x873268: movk            x3, #3, lsl #16
    //     0x87326c: stur            x3, [x1, #-1]
    // 0x873270: StoreField: r1->field_7 = d3
    //     0x873270: stur            d3, [x1, #7]
    // 0x873274: stur            x1, [fp, #-8]
    // 0x873278: SaveReg r1
    //     0x873278: str             x1, [SP, #-8]!
    // 0x87327c: r0 = isNegative()
    //     0x87327c: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x873280: add             SP, SP, #8
    // 0x873284: tbnz            w0, #4, #0x873298
    // 0x873288: ldr             x1, [fp, #0x18]
    // 0x87328c: ldur            x2, [fp, #-0x10]
    // 0x873290: r0 = 0
    //     0x873290: mov             x0, #0
    // 0x873294: b               #0x8732a4
    // 0x873298: ldur            x0, [fp, #-8]
    // 0x87329c: ldr             x1, [fp, #0x18]
    // 0x8732a0: ldur            x2, [fp, #-0x10]
    // 0x8732a4: LoadField: r3 = r1->field_b
    //     0x8732a4: ldur            w3, [x1, #0xb]
    // 0x8732a8: DecompressPointer r3
    //     0x8732a8: add             x3, x3, HEAP, lsl #32
    // 0x8732ac: cmp             w3, NULL
    // 0x8732b0: b.eq            #0x873884
    // 0x8732b4: LoadField: r4 = r3->field_13
    //     0x8732b4: ldur            w4, [x3, #0x13]
    // 0x8732b8: DecompressPointer r4
    //     0x8732b8: add             x4, x4, HEAP, lsl #32
    // 0x8732bc: LoadField: d0 = r4->field_f
    //     0x8732bc: ldur            d0, [x4, #0xf]
    // 0x8732c0: r3 = inline_Allocate_Double()
    //     0x8732c0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x8732c4: add             x3, x3, #0x10
    //     0x8732c8: cmp             x4, x3
    //     0x8732cc: b.ls            #0x873888
    //     0x8732d0: str             x3, [THR, #0x60]  ; THR::top
    //     0x8732d4: sub             x3, x3, #0xf
    //     0x8732d8: mov             x4, #0xd108
    //     0x8732dc: movk            x4, #3, lsl #16
    //     0x8732e0: stur            x4, [x3, #-1]
    // 0x8732e4: StoreField: r3->field_7 = d0
    //     0x8732e4: stur            d0, [x3, #7]
    // 0x8732e8: r4 = 59
    //     0x8732e8: mov             x4, #0x3b
    // 0x8732ec: branchIfSmi(r0, 0x8732f8)
    //     0x8732ec: tbz             w0, #0, #0x8732f8
    // 0x8732f0: r4 = LoadClassIdInstr(r0)
    //     0x8732f0: ldur            x4, [x0, #-1]
    //     0x8732f4: ubfx            x4, x4, #0xc, #0x14
    // 0x8732f8: stp             x3, x0, [SP, #-0x10]!
    // 0x8732fc: mov             x0, x4
    // 0x873300: r0 = GDT[cid_x0 + -0xff3]()
    //     0x873300: sub             lr, x0, #0xff3
    //     0x873304: ldr             lr, [x21, lr, lsl #3]
    //     0x873308: blr             lr
    // 0x87330c: add             SP, SP, #0x10
    // 0x873310: LoadField: d0 = r0->field_7
    //     0x873310: ldur            d0, [x0, #7]
    // 0x873314: d1 = 8.000000
    //     0x873314: fmov            d1, #8.00000000
    // 0x873318: fsub            d2, d0, d1
    // 0x87331c: ldr             x0, [fp, #0x18]
    // 0x873320: stur            d2, [fp, #-0x38]
    // 0x873324: LoadField: r1 = r0->field_b
    //     0x873324: ldur            w1, [x0, #0xb]
    // 0x873328: DecompressPointer r1
    //     0x873328: add             x1, x1, HEAP, lsl #32
    // 0x87332c: cmp             w1, NULL
    // 0x873330: b.eq            #0x8738ac
    // 0x873334: LoadField: r2 = r1->field_13
    //     0x873334: ldur            w2, [x1, #0x13]
    // 0x873338: DecompressPointer r2
    //     0x873338: add             x2, x2, HEAP, lsl #32
    // 0x87333c: stur            x2, [fp, #-8]
    // 0x873340: LoadField: d0 = r2->field_7
    //     0x873340: ldur            d0, [x2, #7]
    // 0x873344: LoadField: r3 = r1->field_27
    //     0x873344: ldur            w3, [x1, #0x27]
    // 0x873348: DecompressPointer r3
    //     0x873348: add             x3, x3, HEAP, lsl #32
    // 0x87334c: LoadField: d1 = r3->field_7
    //     0x87334c: ldur            d1, [x3, #7]
    // 0x873350: fadd            d3, d0, d1
    // 0x873354: stur            d3, [fp, #-0x30]
    // 0x873358: r0 = Offset()
    //     0x873358: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x87335c: ldur            d0, [fp, #-0x30]
    // 0x873360: stur            x0, [fp, #-0x18]
    // 0x873364: StoreField: r0->field_7 = d0
    //     0x873364: stur            d0, [x0, #7]
    // 0x873368: ldur            d1, [fp, #-0x38]
    // 0x87336c: StoreField: r0->field_f = d1
    //     0x87336c: stur            d1, [x0, #0xf]
    // 0x873370: ldur            x1, [fp, #-8]
    // 0x873374: LoadField: d1 = r1->field_f
    //     0x873374: ldur            d1, [x1, #0xf]
    // 0x873378: ldur            x1, [fp, #-0x10]
    // 0x87337c: LoadField: r2 = r1->field_7
    //     0x87337c: ldur            w2, [x1, #7]
    // 0x873380: DecompressPointer r2
    //     0x873380: add             x2, x2, HEAP, lsl #32
    // 0x873384: LoadField: d2 = r2->field_f
    //     0x873384: ldur            d2, [x2, #0xf]
    // 0x873388: fadd            d3, d1, d2
    // 0x87338c: d1 = 20.000000
    //     0x87338c: fmov            d1, #20.00000000
    // 0x873390: fadd            d2, d3, d1
    // 0x873394: stur            d2, [fp, #-0x38]
    // 0x873398: r0 = Offset()
    //     0x873398: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x87339c: ldur            d0, [fp, #-0x30]
    // 0x8733a0: stur            x0, [fp, #-8]
    // 0x8733a4: StoreField: r0->field_7 = d0
    //     0x8733a4: stur            d0, [x0, #7]
    // 0x8733a8: ldur            d0, [fp, #-0x38]
    // 0x8733ac: StoreField: r0->field_f = d0
    //     0x8733ac: stur            d0, [x0, #0xf]
    // 0x8733b0: ldr             x16, [fp, #0x10]
    // 0x8733b4: SaveReg r16
    //     0x8733b4: str             x16, [SP, #-8]!
    // 0x8733b8: r0 = of()
    //     0x8733b8: bl              #0x832f90  ; [package:flutter/src/material/material_localizations.dart] MaterialLocalizations::of
    // 0x8733bc: add             SP, SP, #8
    // 0x8733c0: r16 = <_TextSelectionToolbarItemData>
    //     0x8733c0: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b500] TypeArguments: <_TextSelectionToolbarItemData>
    //     0x8733c4: ldr             x16, [x16, #0x500]
    // 0x8733c8: stp             xzr, x16, [SP, #-0x10]!
    // 0x8733cc: r0 = _GrowableList()
    //     0x8733cc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x8733d0: add             SP, SP, #0x10
    // 0x8733d4: mov             x1, x0
    // 0x8733d8: ldr             x0, [fp, #0x18]
    // 0x8733dc: stur            x1, [fp, #-0x20]
    // 0x8733e0: LoadField: r2 = r0->field_b
    //     0x8733e0: ldur            w2, [x0, #0xb]
    // 0x8733e4: DecompressPointer r2
    //     0x8733e4: add             x2, x2, HEAP, lsl #32
    // 0x8733e8: cmp             w2, NULL
    // 0x8733ec: b.eq            #0x8738b0
    // 0x8733f0: LoadField: r3 = r2->field_17
    //     0x8733f0: ldur            w3, [x2, #0x17]
    // 0x8733f4: DecompressPointer r3
    //     0x8733f4: add             x3, x3, HEAP, lsl #32
    // 0x8733f8: stur            x3, [fp, #-0x10]
    // 0x8733fc: cmp             w3, NULL
    // 0x873400: b.eq            #0x8734b4
    // 0x873404: r0 = _TextSelectionToolbarItemData()
    //     0x873404: bl              #0x8738dc  ; Allocate_TextSelectionToolbarItemDataStub -> _TextSelectionToolbarItemData (size=0x10)
    // 0x873408: mov             x1, x0
    // 0x87340c: r0 = "Cut"
    //     0x87340c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Cut"
    //     0x873410: ldr             x0, [x0, #0xdd0]
    // 0x873414: stur            x1, [fp, #-0x28]
    // 0x873418: StoreField: r1->field_7 = r0
    //     0x873418: stur            w0, [x1, #7]
    // 0x87341c: ldur            x0, [fp, #-0x10]
    // 0x873420: StoreField: r1->field_b = r0
    //     0x873420: stur            w0, [x1, #0xb]
    // 0x873424: ldur            x0, [fp, #-0x20]
    // 0x873428: LoadField: r2 = r0->field_b
    //     0x873428: ldur            w2, [x0, #0xb]
    // 0x87342c: DecompressPointer r2
    //     0x87342c: add             x2, x2, HEAP, lsl #32
    // 0x873430: stur            x2, [fp, #-0x10]
    // 0x873434: LoadField: r3 = r0->field_f
    //     0x873434: ldur            w3, [x0, #0xf]
    // 0x873438: DecompressPointer r3
    //     0x873438: add             x3, x3, HEAP, lsl #32
    // 0x87343c: LoadField: r4 = r3->field_b
    //     0x87343c: ldur            w4, [x3, #0xb]
    // 0x873440: DecompressPointer r4
    //     0x873440: add             x4, x4, HEAP, lsl #32
    // 0x873444: cmp             w2, w4
    // 0x873448: b.ne            #0x873458
    // 0x87344c: SaveReg r0
    //     0x87344c: str             x0, [SP, #-8]!
    // 0x873450: r0 = _growToNextCapacity()
    //     0x873450: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x873454: add             SP, SP, #8
    // 0x873458: ldur            x2, [fp, #-0x20]
    // 0x87345c: ldur            x0, [fp, #-0x10]
    // 0x873460: r3 = LoadInt32Instr(r0)
    //     0x873460: sbfx            x3, x0, #1, #0x1f
    // 0x873464: add             x0, x3, #1
    // 0x873468: lsl             x1, x0, #1
    // 0x87346c: StoreField: r2->field_b = r1
    //     0x87346c: stur            w1, [x2, #0xb]
    // 0x873470: mov             x1, x3
    // 0x873474: cmp             x1, x0
    // 0x873478: b.hs            #0x8738b4
    // 0x87347c: LoadField: r1 = r2->field_f
    //     0x87347c: ldur            w1, [x2, #0xf]
    // 0x873480: DecompressPointer r1
    //     0x873480: add             x1, x1, HEAP, lsl #32
    // 0x873484: ldur            x0, [fp, #-0x28]
    // 0x873488: ArrayStore: r1[r3] = r0  ; List_4
    //     0x873488: add             x25, x1, x3, lsl #2
    //     0x87348c: add             x25, x25, #0xf
    //     0x873490: str             w0, [x25]
    //     0x873494: tbz             w0, #0, #0x8734b0
    //     0x873498: ldurb           w16, [x1, #-1]
    //     0x87349c: ldurb           w17, [x0, #-1]
    //     0x8734a0: and             x16, x17, x16, lsr #2
    //     0x8734a4: tst             x16, HEAP, lsr #32
    //     0x8734a8: b.eq            #0x8734b0
    //     0x8734ac: bl              #0xd67e5c
    // 0x8734b0: b               #0x8734b8
    // 0x8734b4: mov             x2, x1
    // 0x8734b8: ldr             x0, [fp, #0x18]
    // 0x8734bc: LoadField: r1 = r0->field_b
    //     0x8734bc: ldur            w1, [x0, #0xb]
    // 0x8734c0: DecompressPointer r1
    //     0x8734c0: add             x1, x1, HEAP, lsl #32
    // 0x8734c4: cmp             w1, NULL
    // 0x8734c8: b.eq            #0x8738b8
    // 0x8734cc: LoadField: r3 = r1->field_1b
    //     0x8734cc: ldur            w3, [x1, #0x1b]
    // 0x8734d0: DecompressPointer r3
    //     0x8734d0: add             x3, x3, HEAP, lsl #32
    // 0x8734d4: stur            x3, [fp, #-0x10]
    // 0x8734d8: cmp             w3, NULL
    // 0x8734dc: b.eq            #0x87358c
    // 0x8734e0: r0 = _TextSelectionToolbarItemData()
    //     0x8734e0: bl              #0x8738dc  ; Allocate_TextSelectionToolbarItemDataStub -> _TextSelectionToolbarItemData (size=0x10)
    // 0x8734e4: mov             x1, x0
    // 0x8734e8: r0 = "Copy"
    //     0x8734e8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Copy"
    //     0x8734ec: ldr             x0, [x0, #0xdd8]
    // 0x8734f0: stur            x1, [fp, #-0x28]
    // 0x8734f4: StoreField: r1->field_7 = r0
    //     0x8734f4: stur            w0, [x1, #7]
    // 0x8734f8: ldur            x0, [fp, #-0x10]
    // 0x8734fc: StoreField: r1->field_b = r0
    //     0x8734fc: stur            w0, [x1, #0xb]
    // 0x873500: ldur            x0, [fp, #-0x20]
    // 0x873504: LoadField: r2 = r0->field_b
    //     0x873504: ldur            w2, [x0, #0xb]
    // 0x873508: DecompressPointer r2
    //     0x873508: add             x2, x2, HEAP, lsl #32
    // 0x87350c: stur            x2, [fp, #-0x10]
    // 0x873510: LoadField: r3 = r0->field_f
    //     0x873510: ldur            w3, [x0, #0xf]
    // 0x873514: DecompressPointer r3
    //     0x873514: add             x3, x3, HEAP, lsl #32
    // 0x873518: LoadField: r4 = r3->field_b
    //     0x873518: ldur            w4, [x3, #0xb]
    // 0x87351c: DecompressPointer r4
    //     0x87351c: add             x4, x4, HEAP, lsl #32
    // 0x873520: cmp             w2, w4
    // 0x873524: b.ne            #0x873534
    // 0x873528: SaveReg r0
    //     0x873528: str             x0, [SP, #-8]!
    // 0x87352c: r0 = _growToNextCapacity()
    //     0x87352c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x873530: add             SP, SP, #8
    // 0x873534: ldur            x2, [fp, #-0x20]
    // 0x873538: ldur            x0, [fp, #-0x10]
    // 0x87353c: r3 = LoadInt32Instr(r0)
    //     0x87353c: sbfx            x3, x0, #1, #0x1f
    // 0x873540: add             x0, x3, #1
    // 0x873544: lsl             x1, x0, #1
    // 0x873548: StoreField: r2->field_b = r1
    //     0x873548: stur            w1, [x2, #0xb]
    // 0x87354c: mov             x1, x3
    // 0x873550: cmp             x1, x0
    // 0x873554: b.hs            #0x8738bc
    // 0x873558: LoadField: r1 = r2->field_f
    //     0x873558: ldur            w1, [x2, #0xf]
    // 0x87355c: DecompressPointer r1
    //     0x87355c: add             x1, x1, HEAP, lsl #32
    // 0x873560: ldur            x0, [fp, #-0x28]
    // 0x873564: ArrayStore: r1[r3] = r0  ; List_4
    //     0x873564: add             x25, x1, x3, lsl #2
    //     0x873568: add             x25, x25, #0xf
    //     0x87356c: str             w0, [x25]
    //     0x873570: tbz             w0, #0, #0x87358c
    //     0x873574: ldurb           w16, [x1, #-1]
    //     0x873578: ldurb           w17, [x0, #-1]
    //     0x87357c: and             x16, x17, x16, lsr #2
    //     0x873580: tst             x16, HEAP, lsr #32
    //     0x873584: b.eq            #0x87358c
    //     0x873588: bl              #0xd67e5c
    // 0x87358c: ldr             x0, [fp, #0x18]
    // 0x873590: LoadField: r1 = r0->field_b
    //     0x873590: ldur            w1, [x0, #0xb]
    // 0x873594: DecompressPointer r1
    //     0x873594: add             x1, x1, HEAP, lsl #32
    // 0x873598: cmp             w1, NULL
    // 0x87359c: b.eq            #0x8738c0
    // 0x8735a0: LoadField: r3 = r1->field_1f
    //     0x8735a0: ldur            w3, [x1, #0x1f]
    // 0x8735a4: DecompressPointer r3
    //     0x8735a4: add             x3, x3, HEAP, lsl #32
    // 0x8735a8: stur            x3, [fp, #-0x10]
    // 0x8735ac: cmp             w3, NULL
    // 0x8735b0: b.eq            #0x873688
    // 0x8735b4: LoadField: r4 = r1->field_b
    //     0x8735b4: ldur            w4, [x1, #0xb]
    // 0x8735b8: DecompressPointer r4
    //     0x8735b8: add             x4, x4, HEAP, lsl #32
    // 0x8735bc: cmp             w4, NULL
    // 0x8735c0: b.eq            #0x873688
    // 0x8735c4: LoadField: r1 = r4->field_27
    //     0x8735c4: ldur            w1, [x4, #0x27]
    // 0x8735c8: DecompressPointer r1
    //     0x8735c8: add             x1, x1, HEAP, lsl #32
    // 0x8735cc: r16 = Instance_ClipboardStatus
    //     0x8735cc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc68] Obj!ClipboardStatus@b63491
    //     0x8735d0: ldr             x16, [x16, #0xc68]
    // 0x8735d4: cmp             w1, w16
    // 0x8735d8: b.ne            #0x873688
    // 0x8735dc: r0 = _TextSelectionToolbarItemData()
    //     0x8735dc: bl              #0x8738dc  ; Allocate_TextSelectionToolbarItemDataStub -> _TextSelectionToolbarItemData (size=0x10)
    // 0x8735e0: mov             x1, x0
    // 0x8735e4: r0 = "Paste"
    //     0x8735e4: add             x0, PP, #0x28, lsl #12  ; [pp+0x28de0] "Paste"
    //     0x8735e8: ldr             x0, [x0, #0xde0]
    // 0x8735ec: stur            x1, [fp, #-0x28]
    // 0x8735f0: StoreField: r1->field_7 = r0
    //     0x8735f0: stur            w0, [x1, #7]
    // 0x8735f4: ldur            x0, [fp, #-0x10]
    // 0x8735f8: StoreField: r1->field_b = r0
    //     0x8735f8: stur            w0, [x1, #0xb]
    // 0x8735fc: ldur            x0, [fp, #-0x20]
    // 0x873600: LoadField: r2 = r0->field_b
    //     0x873600: ldur            w2, [x0, #0xb]
    // 0x873604: DecompressPointer r2
    //     0x873604: add             x2, x2, HEAP, lsl #32
    // 0x873608: stur            x2, [fp, #-0x10]
    // 0x87360c: LoadField: r3 = r0->field_f
    //     0x87360c: ldur            w3, [x0, #0xf]
    // 0x873610: DecompressPointer r3
    //     0x873610: add             x3, x3, HEAP, lsl #32
    // 0x873614: LoadField: r4 = r3->field_b
    //     0x873614: ldur            w4, [x3, #0xb]
    // 0x873618: DecompressPointer r4
    //     0x873618: add             x4, x4, HEAP, lsl #32
    // 0x87361c: cmp             w2, w4
    // 0x873620: b.ne            #0x873630
    // 0x873624: SaveReg r0
    //     0x873624: str             x0, [SP, #-8]!
    // 0x873628: r0 = _growToNextCapacity()
    //     0x873628: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x87362c: add             SP, SP, #8
    // 0x873630: ldur            x2, [fp, #-0x20]
    // 0x873634: ldur            x0, [fp, #-0x10]
    // 0x873638: r3 = LoadInt32Instr(r0)
    //     0x873638: sbfx            x3, x0, #1, #0x1f
    // 0x87363c: add             x0, x3, #1
    // 0x873640: lsl             x1, x0, #1
    // 0x873644: StoreField: r2->field_b = r1
    //     0x873644: stur            w1, [x2, #0xb]
    // 0x873648: mov             x1, x3
    // 0x87364c: cmp             x1, x0
    // 0x873650: b.hs            #0x8738c4
    // 0x873654: LoadField: r1 = r2->field_f
    //     0x873654: ldur            w1, [x2, #0xf]
    // 0x873658: DecompressPointer r1
    //     0x873658: add             x1, x1, HEAP, lsl #32
    // 0x87365c: ldur            x0, [fp, #-0x28]
    // 0x873660: ArrayStore: r1[r3] = r0  ; List_4
    //     0x873660: add             x25, x1, x3, lsl #2
    //     0x873664: add             x25, x25, #0xf
    //     0x873668: str             w0, [x25]
    //     0x87366c: tbz             w0, #0, #0x873688
    //     0x873670: ldurb           w16, [x1, #-1]
    //     0x873674: ldurb           w17, [x0, #-1]
    //     0x873678: and             x16, x17, x16, lsr #2
    //     0x87367c: tst             x16, HEAP, lsr #32
    //     0x873680: b.eq            #0x873688
    //     0x873684: bl              #0xd67e5c
    // 0x873688: ldr             x0, [fp, #0x18]
    // 0x87368c: LoadField: r1 = r0->field_b
    //     0x87368c: ldur            w1, [x0, #0xb]
    // 0x873690: DecompressPointer r1
    //     0x873690: add             x1, x1, HEAP, lsl #32
    // 0x873694: cmp             w1, NULL
    // 0x873698: b.eq            #0x8738c8
    // 0x87369c: LoadField: r0 = r1->field_23
    //     0x87369c: ldur            w0, [x1, #0x23]
    // 0x8736a0: DecompressPointer r0
    //     0x8736a0: add             x0, x0, HEAP, lsl #32
    // 0x8736a4: stur            x0, [fp, #-0x10]
    // 0x8736a8: cmp             w0, NULL
    // 0x8736ac: b.eq            #0x87375c
    // 0x8736b0: r0 = _TextSelectionToolbarItemData()
    //     0x8736b0: bl              #0x8738dc  ; Allocate_TextSelectionToolbarItemDataStub -> _TextSelectionToolbarItemData (size=0x10)
    // 0x8736b4: mov             x1, x0
    // 0x8736b8: r0 = "Select all"
    //     0x8736b8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28de8] "Select all"
    //     0x8736bc: ldr             x0, [x0, #0xde8]
    // 0x8736c0: stur            x1, [fp, #-0x28]
    // 0x8736c4: StoreField: r1->field_7 = r0
    //     0x8736c4: stur            w0, [x1, #7]
    // 0x8736c8: ldur            x0, [fp, #-0x10]
    // 0x8736cc: StoreField: r1->field_b = r0
    //     0x8736cc: stur            w0, [x1, #0xb]
    // 0x8736d0: ldur            x0, [fp, #-0x20]
    // 0x8736d4: LoadField: r2 = r0->field_b
    //     0x8736d4: ldur            w2, [x0, #0xb]
    // 0x8736d8: DecompressPointer r2
    //     0x8736d8: add             x2, x2, HEAP, lsl #32
    // 0x8736dc: stur            x2, [fp, #-0x10]
    // 0x8736e0: LoadField: r3 = r0->field_f
    //     0x8736e0: ldur            w3, [x0, #0xf]
    // 0x8736e4: DecompressPointer r3
    //     0x8736e4: add             x3, x3, HEAP, lsl #32
    // 0x8736e8: LoadField: r4 = r3->field_b
    //     0x8736e8: ldur            w4, [x3, #0xb]
    // 0x8736ec: DecompressPointer r4
    //     0x8736ec: add             x4, x4, HEAP, lsl #32
    // 0x8736f0: cmp             w2, w4
    // 0x8736f4: b.ne            #0x873704
    // 0x8736f8: SaveReg r0
    //     0x8736f8: str             x0, [SP, #-8]!
    // 0x8736fc: r0 = _growToNextCapacity()
    //     0x8736fc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x873700: add             SP, SP, #8
    // 0x873704: ldur            x2, [fp, #-0x20]
    // 0x873708: ldur            x0, [fp, #-0x10]
    // 0x87370c: r3 = LoadInt32Instr(r0)
    //     0x87370c: sbfx            x3, x0, #1, #0x1f
    // 0x873710: add             x0, x3, #1
    // 0x873714: lsl             x1, x0, #1
    // 0x873718: StoreField: r2->field_b = r1
    //     0x873718: stur            w1, [x2, #0xb]
    // 0x87371c: mov             x1, x3
    // 0x873720: cmp             x1, x0
    // 0x873724: b.hs            #0x8738cc
    // 0x873728: LoadField: r1 = r2->field_f
    //     0x873728: ldur            w1, [x2, #0xf]
    // 0x87372c: DecompressPointer r1
    //     0x87372c: add             x1, x1, HEAP, lsl #32
    // 0x873730: ldur            x0, [fp, #-0x28]
    // 0x873734: ArrayStore: r1[r3] = r0  ; List_4
    //     0x873734: add             x25, x1, x3, lsl #2
    //     0x873738: add             x25, x25, #0xf
    //     0x87373c: str             w0, [x25]
    //     0x873740: tbz             w0, #0, #0x87375c
    //     0x873744: ldurb           w16, [x1, #-1]
    //     0x873748: ldurb           w17, [x0, #-1]
    //     0x87374c: and             x16, x17, x16, lsr #2
    //     0x873750: tst             x16, HEAP, lsr #32
    //     0x873754: b.eq            #0x87375c
    //     0x873758: bl              #0xd67e5c
    // 0x87375c: r1 = 1
    //     0x87375c: mov             x1, #1
    // 0x873760: r0 = AllocateContext()
    //     0x873760: bl              #0xd68aa4  ; AllocateContextStub
    // 0x873764: mov             x1, x0
    // 0x873768: ldur            x0, [fp, #-0x20]
    // 0x87376c: stur            x1, [fp, #-0x10]
    // 0x873770: StoreField: r1->field_f = r0
    //     0x873770: stur            w0, [x1, #0xf]
    // 0x873774: LoadField: r2 = r0->field_b
    //     0x873774: ldur            w2, [x0, #0xb]
    // 0x873778: DecompressPointer r2
    //     0x873778: add             x2, x2, HEAP, lsl #32
    // 0x87377c: cbnz            w2, #0x873794
    // 0x873780: r0 = Instance_SizedBox
    //     0x873780: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x873784: ldr             x0, [x0, #0x738]
    // 0x873788: LeaveFrame
    //     0x873788: mov             SP, fp
    //     0x87378c: ldp             fp, lr, [SP], #0x10
    // 0x873790: ret
    //     0x873790: ret             
    // 0x873794: ldur            x3, [fp, #-0x18]
    // 0x873798: ldur            x2, [fp, #-8]
    // 0x87379c: SaveReg r0
    //     0x87379c: str             x0, [SP, #-8]!
    // 0x8737a0: r0 = asMap()
    //     0x8737a0: bl              #0x5eb608  ; [dart:collection] _ListBase&Object&ListMixin::asMap
    // 0x8737a4: add             SP, SP, #8
    // 0x8737a8: SaveReg r0
    //     0x8737a8: str             x0, [SP, #-8]!
    // 0x8737ac: r0 = entries()
    //     0x8737ac: bl              #0xbd7428  ; [dart:collection] MapMixin::entries
    // 0x8737b0: add             SP, SP, #8
    // 0x8737b4: ldur            x2, [fp, #-0x10]
    // 0x8737b8: r1 = Function '<anonymous closure>':.
    //     0x8737b8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b508] AnonymousClosure: (0x873908), in [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::build (0x872ffc)
    //     0x8737bc: ldr             x1, [x1, #0x508]
    // 0x8737c0: stur            x0, [fp, #-0x10]
    // 0x8737c4: r0 = AllocateClosure()
    //     0x8737c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8737c8: r16 = <TextSelectionToolbarTextButton>
    //     0x8737c8: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4b510] TypeArguments: <TextSelectionToolbarTextButton>
    //     0x8737cc: ldr             x16, [x16, #0x510]
    // 0x8737d0: ldur            lr, [fp, #-0x10]
    // 0x8737d4: stp             lr, x16, [SP, #-0x10]!
    // 0x8737d8: SaveReg r0
    //     0x8737d8: str             x0, [SP, #-8]!
    // 0x8737dc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8737dc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x8737e0: r0 = map()
    //     0x8737e0: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x8737e4: add             SP, SP, #0x18
    // 0x8737e8: SaveReg r0
    //     0x8737e8: str             x0, [SP, #-8]!
    // 0x8737ec: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x8737ec: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x8737f0: r0 = toList()
    //     0x8737f0: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x8737f4: add             SP, SP, #8
    // 0x8737f8: stur            x0, [fp, #-0x10]
    // 0x8737fc: r0 = TextSelectionToolbar()
    //     0x8737fc: bl              #0x8738d0  ; AllocateTextSelectionToolbarStub -> TextSelectionToolbar (size=0x1c)
    // 0x873800: ldur            x1, [fp, #-0x18]
    // 0x873804: StoreField: r0->field_b = r1
    //     0x873804: stur            w1, [x0, #0xb]
    // 0x873808: ldur            x1, [fp, #-8]
    // 0x87380c: StoreField: r0->field_f = r1
    //     0x87380c: stur            w1, [x0, #0xf]
    // 0x873810: r1 = Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@827142888': static.
    //     0x873810: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d50] Closure: (BuildContext, Widget) => Widget from Function '_defaultToolbarBuilder@827142888': static. (0x7fe6e2073b3c)
    //     0x873814: ldr             x1, [x1, #0xd50]
    // 0x873818: StoreField: r0->field_17 = r1
    //     0x873818: stur            w1, [x0, #0x17]
    // 0x87381c: ldur            x1, [fp, #-0x10]
    // 0x873820: StoreField: r0->field_13 = r1
    //     0x873820: stur            w1, [x0, #0x13]
    // 0x873824: LeaveFrame
    //     0x873824: mov             SP, fp
    //     0x873828: ldp             fp, lr, [SP], #0x10
    // 0x87382c: ret
    //     0x87382c: ret             
    // 0x873830: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873830: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873834: b               #0x873014
    // 0x873838: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x873838: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x87383c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x87383c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x873840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x873840: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x873844: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x873844: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x873848: r0 = NullCastErrorSharedWithFPURegs()
    //     0x873848: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x87384c: SaveReg d3
    //     0x87384c: str             q3, [SP, #-0x10]!
    // 0x873850: stp             x0, x2, [SP, #-0x10]!
    // 0x873854: r0 = AllocateDouble()
    //     0x873854: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x873858: mov             x1, x0
    // 0x87385c: ldp             x0, x2, [SP], #0x10
    // 0x873860: RestoreReg d3
    //     0x873860: ldr             q3, [SP], #0x10
    // 0x873864: b               #0x873220
    // 0x873868: SaveReg d3
    //     0x873868: str             q3, [SP, #-0x10]!
    // 0x87386c: stp             x0, x2, [SP, #-0x10]!
    // 0x873870: r0 = AllocateDouble()
    //     0x873870: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x873874: mov             x1, x0
    // 0x873878: ldp             x0, x2, [SP], #0x10
    // 0x87387c: RestoreReg d3
    //     0x87387c: ldr             q3, [SP], #0x10
    // 0x873880: b               #0x873270
    // 0x873884: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x873884: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x873888: SaveReg d0
    //     0x873888: str             q0, [SP, #-0x10]!
    // 0x87388c: stp             x1, x2, [SP, #-0x10]!
    // 0x873890: SaveReg r0
    //     0x873890: str             x0, [SP, #-8]!
    // 0x873894: r0 = AllocateDouble()
    //     0x873894: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x873898: mov             x3, x0
    // 0x87389c: RestoreReg r0
    //     0x87389c: ldr             x0, [SP], #8
    // 0x8738a0: ldp             x1, x2, [SP], #0x10
    // 0x8738a4: RestoreReg d0
    //     0x8738a4: ldr             q0, [SP], #0x10
    // 0x8738a8: b               #0x8732e4
    // 0x8738ac: r0 = NullCastErrorSharedWithFPURegs()
    //     0x8738ac: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x8738b0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8738b0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8738b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8738b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8738b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8738b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8738bc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8738bc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8738c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8738c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8738c4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8738c4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x8738c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8738c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8738cc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x8738cc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] TextSelectionToolbarTextButton <anonymous closure>(dynamic, MapEntry<int, _TextSelectionToolbarItemData>) {
    // ** addr: 0x873908, size: 0x130
    // 0x873908: EnterFrame
    //     0x873908: stp             fp, lr, [SP, #-0x10]!
    //     0x87390c: mov             fp, SP
    // 0x873910: AllocStack(0x20)
    //     0x873910: sub             SP, SP, #0x20
    // 0x873914: SetupParameters()
    //     0x873914: ldr             x0, [fp, #0x18]
    //     0x873918: ldur            w1, [x0, #0x17]
    //     0x87391c: add             x1, x1, HEAP, lsl #32
    //     0x873920: stur            x1, [fp, #-8]
    // 0x873924: CheckStackOverflow
    //     0x873924: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x873928: cmp             SP, x16
    //     0x87392c: b.ls            #0x873a28
    // 0x873930: ldr             x2, [fp, #0x10]
    // 0x873934: r0 = LoadClassIdInstr(r2)
    //     0x873934: ldur            x0, [x2, #-1]
    //     0x873938: ubfx            x0, x0, #0xc, #0x14
    // 0x87393c: SaveReg r2
    //     0x87393c: str             x2, [SP, #-8]!
    // 0x873940: r0 = GDT[cid_x0 + -0xfba]()
    //     0x873940: sub             lr, x0, #0xfba
    //     0x873944: ldr             lr, [x21, lr, lsl #3]
    //     0x873948: blr             lr
    // 0x87394c: add             SP, SP, #8
    // 0x873950: mov             x1, x0
    // 0x873954: ldur            x0, [fp, #-8]
    // 0x873958: LoadField: r2 = r0->field_f
    //     0x873958: ldur            w2, [x0, #0xf]
    // 0x87395c: DecompressPointer r2
    //     0x87395c: add             x2, x2, HEAP, lsl #32
    // 0x873960: LoadField: r0 = r2->field_b
    //     0x873960: ldur            w0, [x2, #0xb]
    // 0x873964: DecompressPointer r0
    //     0x873964: add             x0, x0, HEAP, lsl #32
    // 0x873968: r2 = LoadInt32Instr(r0)
    //     0x873968: sbfx            x2, x0, #1, #0x1f
    // 0x87396c: stp             x2, x1, [SP, #-0x10]!
    // 0x873970: r0 = getPadding()
    //     0x873970: bl              #0x873a44  ; [package:flutter/src/material/text_selection_toolbar_text_button.dart] TextSelectionToolbarTextButton::getPadding
    // 0x873974: add             SP, SP, #0x10
    // 0x873978: mov             x2, x0
    // 0x87397c: ldr             x1, [fp, #0x10]
    // 0x873980: stur            x2, [fp, #-8]
    // 0x873984: r0 = LoadClassIdInstr(r1)
    //     0x873984: ldur            x0, [x1, #-1]
    //     0x873988: ubfx            x0, x0, #0xc, #0x14
    // 0x87398c: SaveReg r1
    //     0x87398c: str             x1, [SP, #-8]!
    // 0x873990: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x873990: sub             lr, x0, #0xfc4
    //     0x873994: ldr             lr, [x21, lr, lsl #3]
    //     0x873998: blr             lr
    // 0x87399c: add             SP, SP, #8
    // 0x8739a0: cmp             w0, NULL
    // 0x8739a4: b.eq            #0x873a30
    // 0x8739a8: LoadField: r1 = r0->field_b
    //     0x8739a8: ldur            w1, [x0, #0xb]
    // 0x8739ac: DecompressPointer r1
    //     0x8739ac: add             x1, x1, HEAP, lsl #32
    // 0x8739b0: ldr             x0, [fp, #0x10]
    // 0x8739b4: stur            x1, [fp, #-0x10]
    // 0x8739b8: r2 = LoadClassIdInstr(r0)
    //     0x8739b8: ldur            x2, [x0, #-1]
    //     0x8739bc: ubfx            x2, x2, #0xc, #0x14
    // 0x8739c0: SaveReg r0
    //     0x8739c0: str             x0, [SP, #-8]!
    // 0x8739c4: mov             x0, x2
    // 0x8739c8: r0 = GDT[cid_x0 + -0xfc4]()
    //     0x8739c8: sub             lr, x0, #0xfc4
    //     0x8739cc: ldr             lr, [x21, lr, lsl #3]
    //     0x8739d0: blr             lr
    // 0x8739d4: add             SP, SP, #8
    // 0x8739d8: cmp             w0, NULL
    // 0x8739dc: b.eq            #0x873a34
    // 0x8739e0: LoadField: r1 = r0->field_7
    //     0x8739e0: ldur            w1, [x0, #7]
    // 0x8739e4: DecompressPointer r1
    //     0x8739e4: add             x1, x1, HEAP, lsl #32
    // 0x8739e8: stur            x1, [fp, #-0x18]
    // 0x8739ec: r0 = Text()
    //     0x8739ec: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0x8739f0: mov             x1, x0
    // 0x8739f4: ldur            x0, [fp, #-0x18]
    // 0x8739f8: stur            x1, [fp, #-0x20]
    // 0x8739fc: StoreField: r1->field_b = r0
    //     0x8739fc: stur            w0, [x1, #0xb]
    // 0x873a00: r0 = TextSelectionToolbarTextButton()
    //     0x873a00: bl              #0x873a38  ; AllocateTextSelectionToolbarTextButtonStub -> TextSelectionToolbarTextButton (size=0x18)
    // 0x873a04: ldur            x1, [fp, #-0x20]
    // 0x873a08: StoreField: r0->field_b = r1
    //     0x873a08: stur            w1, [x0, #0xb]
    // 0x873a0c: ldur            x1, [fp, #-8]
    // 0x873a10: StoreField: r0->field_13 = r1
    //     0x873a10: stur            w1, [x0, #0x13]
    // 0x873a14: ldur            x1, [fp, #-0x10]
    // 0x873a18: StoreField: r0->field_f = r1
    //     0x873a18: stur            w1, [x0, #0xf]
    // 0x873a1c: LeaveFrame
    //     0x873a1c: mov             SP, fp
    //     0x873a20: ldp             fp, lr, [SP], #0x10
    // 0x873a24: ret
    //     0x873a24: ret             
    // 0x873a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x873a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x873a2c: b               #0x873930
    // 0x873a30: r0 = NullErrorSharedWithoutFPURegs()
    //     0x873a30: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x873a34: r0 = NullErrorSharedWithoutFPURegs()
    //     0x873a34: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9dc07c, size: 0x90
    // 0x9dc07c: EnterFrame
    //     0x9dc07c: stp             fp, lr, [SP, #-0x10]!
    //     0x9dc080: mov             fp, SP
    // 0x9dc084: AllocStack(0x8)
    //     0x9dc084: sub             SP, SP, #8
    // 0x9dc088: CheckStackOverflow
    //     0x9dc088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9dc08c: cmp             SP, x16
    //     0x9dc090: b.ls            #0x9dc100
    // 0x9dc094: ldr             x0, [fp, #0x10]
    // 0x9dc098: LoadField: r1 = r0->field_b
    //     0x9dc098: ldur            w1, [x0, #0xb]
    // 0x9dc09c: DecompressPointer r1
    //     0x9dc09c: add             x1, x1, HEAP, lsl #32
    // 0x9dc0a0: cmp             w1, NULL
    // 0x9dc0a4: b.eq            #0x9dc108
    // 0x9dc0a8: LoadField: r2 = r1->field_b
    //     0x9dc0a8: ldur            w2, [x1, #0xb]
    // 0x9dc0ac: DecompressPointer r2
    //     0x9dc0ac: add             x2, x2, HEAP, lsl #32
    // 0x9dc0b0: stur            x2, [fp, #-8]
    // 0x9dc0b4: cmp             w2, NULL
    // 0x9dc0b8: b.eq            #0x9dc0f0
    // 0x9dc0bc: r1 = 1
    //     0x9dc0bc: mov             x1, #1
    // 0x9dc0c0: r0 = AllocateContext()
    //     0x9dc0c0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9dc0c4: mov             x1, x0
    // 0x9dc0c8: ldr             x0, [fp, #0x10]
    // 0x9dc0cc: StoreField: r1->field_f = r0
    //     0x9dc0cc: stur            w0, [x1, #0xf]
    // 0x9dc0d0: mov             x2, x1
    // 0x9dc0d4: r1 = Function '_onChangedClipboardStatus@825283233':.
    //     0x9dc0d4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b520] AnonymousClosure: (0x7bf91c), in [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7bf964)
    //     0x9dc0d8: ldr             x1, [x1, #0x520]
    // 0x9dc0dc: r0 = AllocateClosure()
    //     0x9dc0dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9dc0e0: ldur            x16, [fp, #-8]
    // 0x9dc0e4: stp             x0, x16, [SP, #-0x10]!
    // 0x9dc0e8: r0 = addListener()
    //     0x9dc0e8: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x9dc0ec: add             SP, SP, #0x10
    // 0x9dc0f0: r0 = Null
    //     0x9dc0f0: mov             x0, NULL
    // 0x9dc0f4: LeaveFrame
    //     0x9dc0f4: mov             SP, fp
    //     0x9dc0f8: ldp             fp, lr, [SP], #0x10
    // 0x9dc0fc: ret
    //     0x9dc0fc: ret             
    // 0x9dc100: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9dc100: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9dc104: b               #0x9dc094
    // 0x9dc108: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9dc108: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4b3c8, size: 0x18
    // 0xa4b3c8: r4 = 7
    //     0xa4b3c8: mov             x4, #7
    // 0xa4b3cc: r1 = Function 'dispose':.
    //     0xa4b3cc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4b4f8] AnonymousClosure: (0xa4b3e0), in [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::dispose (0xa531e0)
    //     0xa4b3d0: ldr             x1, [x17, #0x4f8]
    // 0xa4b3d4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4b3d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4b3d8: LoadField: r0 = r24->field_17
    //     0xa4b3d8: ldur            x0, [x24, #0x17]
    // 0xa4b3dc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4b3e0, size: 0x48
    // 0xa4b3e0: EnterFrame
    //     0xa4b3e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4b3e4: mov             fp, SP
    // 0xa4b3e8: ldr             x0, [fp, #0x10]
    // 0xa4b3ec: LoadField: r1 = r0->field_17
    //     0xa4b3ec: ldur            w1, [x0, #0x17]
    // 0xa4b3f0: DecompressPointer r1
    //     0xa4b3f0: add             x1, x1, HEAP, lsl #32
    // 0xa4b3f4: CheckStackOverflow
    //     0xa4b3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4b3f8: cmp             SP, x16
    //     0xa4b3fc: b.ls            #0xa4b420
    // 0xa4b400: LoadField: r0 = r1->field_f
    //     0xa4b400: ldur            w0, [x1, #0xf]
    // 0xa4b404: DecompressPointer r0
    //     0xa4b404: add             x0, x0, HEAP, lsl #32
    // 0xa4b408: SaveReg r0
    //     0xa4b408: str             x0, [SP, #-8]!
    // 0xa4b40c: r0 = dispose()
    //     0xa4b40c: bl              #0xa531e0  ; [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::dispose
    // 0xa4b410: add             SP, SP, #8
    // 0xa4b414: LeaveFrame
    //     0xa4b414: mov             SP, fp
    //     0xa4b418: ldp             fp, lr, [SP], #0x10
    // 0xa4b41c: ret
    //     0xa4b41c: ret             
    // 0xa4b420: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4b420: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4b424: b               #0xa4b400
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa531e0, size: 0xa0
    // 0xa531e0: EnterFrame
    //     0xa531e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa531e4: mov             fp, SP
    // 0xa531e8: AllocStack(0x8)
    //     0xa531e8: sub             SP, SP, #8
    // 0xa531ec: CheckStackOverflow
    //     0xa531ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa531f0: cmp             SP, x16
    //     0xa531f4: b.ls            #0xa53274
    // 0xa531f8: ldr             x0, [fp, #0x10]
    // 0xa531fc: LoadField: r1 = r0->field_b
    //     0xa531fc: ldur            w1, [x0, #0xb]
    // 0xa53200: DecompressPointer r1
    //     0xa53200: add             x1, x1, HEAP, lsl #32
    // 0xa53204: cmp             w1, NULL
    // 0xa53208: b.eq            #0xa5327c
    // 0xa5320c: LoadField: r2 = r1->field_b
    //     0xa5320c: ldur            w2, [x1, #0xb]
    // 0xa53210: DecompressPointer r2
    //     0xa53210: add             x2, x2, HEAP, lsl #32
    // 0xa53214: stur            x2, [fp, #-8]
    // 0xa53218: cmp             w2, NULL
    // 0xa5321c: b.eq            #0xa53254
    // 0xa53220: r1 = 1
    //     0xa53220: mov             x1, #1
    // 0xa53224: r0 = AllocateContext()
    //     0xa53224: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa53228: mov             x1, x0
    // 0xa5322c: ldr             x0, [fp, #0x10]
    // 0xa53230: StoreField: r1->field_f = r0
    //     0xa53230: stur            w0, [x1, #0xf]
    // 0xa53234: mov             x2, x1
    // 0xa53238: r1 = Function '_onChangedClipboardStatus@825283233':.
    //     0xa53238: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4b520] AnonymousClosure: (0x7bf91c), in [package:flutter/src/material/text_selection.dart] _TextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7bf964)
    //     0xa5323c: ldr             x1, [x1, #0x520]
    // 0xa53240: r0 = AllocateClosure()
    //     0xa53240: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa53244: ldur            x16, [fp, #-8]
    // 0xa53248: stp             x0, x16, [SP, #-0x10]!
    // 0xa5324c: r0 = removeListener()
    //     0xa5324c: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0xa53250: add             SP, SP, #0x10
    // 0xa53254: ldr             x16, [fp, #0x10]
    // 0xa53258: SaveReg r16
    //     0xa53258: str             x16, [SP, #-8]!
    // 0xa5325c: r0 = dispose()
    //     0xa5325c: bl              #0xa53280  ; [package:flutter/src/material/text_selection.dart] __TextSelectionControlsToolbarState&State&TickerProviderStateMixin::dispose
    // 0xa53260: add             SP, SP, #8
    // 0xa53264: r0 = Null
    //     0xa53264: mov             x0, NULL
    // 0xa53268: LeaveFrame
    //     0xa53268: mov             SP, fp
    //     0xa5326c: ldp             fp, lr, [SP], #0x10
    // 0xa53270: ret
    //     0xa53270: ret             
    // 0xa53274: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa53274: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa53278: b               #0xa531f8
    // 0xa5327c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa5327c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4112, size: 0x34, field offset: 0xc
//   const constructor, 
class _TextSelectionControlsToolbar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa41a38, size: 0x20
    // 0xa41a38: EnterFrame
    //     0xa41a38: stp             fp, lr, [SP, #-0x10]!
    //     0xa41a3c: mov             fp, SP
    // 0xa41a40: r1 = <_TextSelectionControlsToolbar>
    //     0xa41a40: add             x1, PP, #0x3f, lsl #12  ; [pp+0x3fec8] TypeArguments: <_TextSelectionControlsToolbar>
    //     0xa41a44: ldr             x1, [x1, #0xec8]
    // 0xa41a48: r0 = _TextSelectionControlsToolbarState()
    //     0xa41a48: bl              #0xa41a58  ; Allocate_TextSelectionControlsToolbarStateStub -> _TextSelectionControlsToolbarState (size=0x1c)
    // 0xa41a4c: LeaveFrame
    //     0xa41a4c: mov             SP, fp
    //     0xa41a50: ldp             fp, lr, [SP], #0x10
    // 0xa41a54: ret
    //     0xa41a54: ret             
  }
}

// class id: 4238, size: 0x8, field offset: 0x8
class MaterialTextSelectionControls extends TextSelectionControls {

  _ buildHandle(/* No info */) {
    // ** addr: 0xc37200, size: 0x244
    // 0xc37200: EnterFrame
    //     0xc37200: stp             fp, lr, [SP, #-0x10]!
    //     0xc37204: mov             fp, SP
    // 0xc37208: AllocStack(0x18)
    //     0xc37208: sub             SP, SP, #0x18
    // 0xc3720c: CheckStackOverflow
    //     0xc3720c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc37210: cmp             SP, x16
    //     0xc37214: b.ls            #0xc3743c
    // 0xc37218: ldr             x16, [fp, #0x28]
    // 0xc3721c: SaveReg r16
    //     0xc3721c: str             x16, [SP, #-8]!
    // 0xc37220: r0 = of()
    //     0xc37220: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0xc37224: add             SP, SP, #8
    // 0xc37228: stur            x0, [fp, #-8]
    // 0xc3722c: ldr             x16, [fp, #0x28]
    // 0xc37230: SaveReg r16
    //     0xc37230: str             x16, [SP, #-8]!
    // 0xc37234: r0 = of()
    //     0xc37234: bl              #0x83d55c  ; [package:flutter/src/material/text_selection_theme.dart] TextSelectionTheme::of
    // 0xc37238: add             SP, SP, #8
    // 0xc3723c: LoadField: r1 = r0->field_f
    //     0xc3723c: ldur            w1, [x0, #0xf]
    // 0xc37240: DecompressPointer r1
    //     0xc37240: add             x1, x1, HEAP, lsl #32
    // 0xc37244: cmp             w1, NULL
    // 0xc37248: b.ne            #0xc37264
    // 0xc3724c: ldur            x0, [fp, #-8]
    // 0xc37250: LoadField: r1 = r0->field_3f
    //     0xc37250: ldur            w1, [x0, #0x3f]
    // 0xc37254: DecompressPointer r1
    //     0xc37254: add             x1, x1, HEAP, lsl #32
    // 0xc37258: LoadField: r0 = r1->field_b
    //     0xc37258: ldur            w0, [x1, #0xb]
    // 0xc3725c: DecompressPointer r0
    //     0xc3725c: add             x0, x0, HEAP, lsl #32
    // 0xc37260: mov             x1, x0
    // 0xc37264: ldr             x0, [fp, #0x20]
    // 0xc37268: stur            x1, [fp, #-8]
    // 0xc3726c: r0 = _TextSelectionHandlePainter()
    //     0xc3726c: bl              #0xc37444  ; Allocate_TextSelectionHandlePainterStub -> _TextSelectionHandlePainter (size=0x10)
    // 0xc37270: mov             x1, x0
    // 0xc37274: ldur            x0, [fp, #-8]
    // 0xc37278: stur            x1, [fp, #-0x10]
    // 0xc3727c: StoreField: r1->field_b = r0
    //     0xc3727c: stur            w0, [x1, #0xb]
    // 0xc37280: r0 = GestureDetector()
    //     0xc37280: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0xc37284: stur            x0, [fp, #-8]
    // 0xc37288: ldr             x16, [fp, #0x10]
    // 0xc3728c: stp             x16, x0, [SP, #-0x10]!
    // 0xc37290: r16 = Instance_HitTestBehavior
    //     0xc37290: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0xc37294: ldr             x16, [x16, #0xed0]
    // 0xc37298: SaveReg r16
    //     0xc37298: str             x16, [SP, #-8]!
    // 0xc3729c: r4 = const [0, 0x3, 0x3, 0x1, behavior, 0x2, onTap, 0x1, null]
    //     0xc3729c: add             x4, PP, #0x37, lsl #12  ; [pp+0x372c8] List(9) [0, 0x3, 0x3, 0x1, "behavior", 0x2, "onTap", 0x1, Null]
    //     0xc372a0: ldr             x4, [x4, #0x2c8]
    // 0xc372a4: r0 = GestureDetector()
    //     0xc372a4: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0xc372a8: add             SP, SP, #0x18
    // 0xc372ac: r0 = CustomPaint()
    //     0xc372ac: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xc372b0: mov             x1, x0
    // 0xc372b4: ldur            x0, [fp, #-0x10]
    // 0xc372b8: stur            x1, [fp, #-0x18]
    // 0xc372bc: StoreField: r1->field_f = r0
    //     0xc372bc: stur            w0, [x1, #0xf]
    // 0xc372c0: r0 = Instance_Size
    //     0xc372c0: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xc372c4: StoreField: r1->field_17 = r0
    //     0xc372c4: stur            w0, [x1, #0x17]
    // 0xc372c8: r0 = false
    //     0xc372c8: add             x0, NULL, #0x30  ; false
    // 0xc372cc: StoreField: r1->field_1b = r0
    //     0xc372cc: stur            w0, [x1, #0x1b]
    // 0xc372d0: StoreField: r1->field_1f = r0
    //     0xc372d0: stur            w0, [x1, #0x1f]
    // 0xc372d4: ldur            x0, [fp, #-8]
    // 0xc372d8: StoreField: r1->field_b = r0
    //     0xc372d8: stur            w0, [x1, #0xb]
    // 0xc372dc: r0 = SizedBox()
    //     0xc372dc: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xc372e0: mov             x1, x0
    // 0xc372e4: r0 = 22.000000
    //     0xc372e4: add             x0, PP, #0x30, lsl #12  ; [pp+0x30590] 22
    //     0xc372e8: ldr             x0, [x0, #0x590]
    // 0xc372ec: stur            x1, [fp, #-8]
    // 0xc372f0: StoreField: r1->field_f = r0
    //     0xc372f0: stur            w0, [x1, #0xf]
    // 0xc372f4: StoreField: r1->field_13 = r0
    //     0xc372f4: stur            w0, [x1, #0x13]
    // 0xc372f8: ldur            x0, [fp, #-0x18]
    // 0xc372fc: StoreField: r1->field_b = r0
    //     0xc372fc: stur            w0, [x1, #0xb]
    // 0xc37300: ldr             x0, [fp, #0x20]
    // 0xc37304: LoadField: r2 = r0->field_7
    //     0xc37304: ldur            x2, [x0, #7]
    // 0xc37308: cmp             x2, #1
    // 0xc3730c: b.gt            #0xc373ac
    // 0xc37310: cmp             x2, #0
    // 0xc37314: b.gt            #0xc3739c
    // 0xc37318: r0 = Transform()
    //     0xc37318: bl              #0x8636cc  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xc3731c: mov             x1, x0
    // 0xc37320: r0 = Instance_Alignment
    //     0xc37320: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc37324: ldr             x0, [x0, #0xc70]
    // 0xc37328: stur            x1, [fp, #-0x10]
    // 0xc3732c: StoreField: r1->field_17 = r0
    //     0xc3732c: stur            w0, [x1, #0x17]
    // 0xc37330: r2 = true
    //     0xc37330: add             x2, NULL, #0x20  ; true
    // 0xc37334: StoreField: r1->field_1b = r2
    //     0xc37334: stur            w2, [x1, #0x1b]
    // 0xc37338: d0 = 1.570796
    //     0xc37338: add             x17, PP, #0x28, lsl #12  ; [pp+0x28d00] IMM: double(1.5707963267948966) from 0x3ff921fb54442d18
    //     0xc3733c: ldr             d0, [x17, #0xd00]
    // 0xc37340: SaveReg d0
    //     0xc37340: str             d0, [SP, #-8]!
    // 0xc37344: r0 = _computeRotation()
    //     0xc37344: bl              #0x863468  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0xc37348: add             SP, SP, #8
    // 0xc3734c: ldur            x1, [fp, #-0x10]
    // 0xc37350: StoreField: r1->field_f = r0
    //     0xc37350: stur            w0, [x1, #0xf]
    //     0xc37354: ldurb           w16, [x1, #-1]
    //     0xc37358: ldurb           w17, [x0, #-1]
    //     0xc3735c: and             x16, x17, x16, lsr #2
    //     0xc37360: tst             x16, HEAP, lsr #32
    //     0xc37364: b.eq            #0xc3736c
    //     0xc37368: bl              #0xd6826c
    // 0xc3736c: ldur            x0, [fp, #-8]
    // 0xc37370: StoreField: r1->field_b = r0
    //     0xc37370: stur            w0, [x1, #0xb]
    //     0xc37374: ldurb           w16, [x1, #-1]
    //     0xc37378: ldurb           w17, [x0, #-1]
    //     0xc3737c: and             x16, x17, x16, lsr #2
    //     0xc37380: tst             x16, HEAP, lsr #32
    //     0xc37384: b.eq            #0xc3738c
    //     0xc37388: bl              #0xd6826c
    // 0xc3738c: mov             x0, x1
    // 0xc37390: LeaveFrame
    //     0xc37390: mov             SP, fp
    //     0xc37394: ldp             fp, lr, [SP], #0x10
    // 0xc37398: ret
    //     0xc37398: ret             
    // 0xc3739c: ldur            x0, [fp, #-8]
    // 0xc373a0: LeaveFrame
    //     0xc373a0: mov             SP, fp
    //     0xc373a4: ldp             fp, lr, [SP], #0x10
    // 0xc373a8: ret
    //     0xc373a8: ret             
    // 0xc373ac: r2 = true
    //     0xc373ac: add             x2, NULL, #0x20  ; true
    // 0xc373b0: r0 = Instance_Alignment
    //     0xc373b0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc373b4: ldr             x0, [x0, #0xc70]
    // 0xc373b8: r0 = Transform()
    //     0xc373b8: bl              #0x8636cc  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xc373bc: mov             x1, x0
    // 0xc373c0: r0 = Instance_Alignment
    //     0xc373c0: add             x0, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xc373c4: ldr             x0, [x0, #0xc70]
    // 0xc373c8: stur            x1, [fp, #-0x10]
    // 0xc373cc: StoreField: r1->field_17 = r0
    //     0xc373cc: stur            w0, [x1, #0x17]
    // 0xc373d0: r0 = true
    //     0xc373d0: add             x0, NULL, #0x20  ; true
    // 0xc373d4: StoreField: r1->field_1b = r0
    //     0xc373d4: stur            w0, [x1, #0x1b]
    // 0xc373d8: d0 = 0.785398
    //     0xc373d8: add             x17, PP, #0x37, lsl #12  ; [pp+0x372d0] IMM: double(0.7853981633974483) from 0x3fe921fb54442d18
    //     0xc373dc: ldr             d0, [x17, #0x2d0]
    // 0xc373e0: SaveReg d0
    //     0xc373e0: str             d0, [SP, #-8]!
    // 0xc373e4: r0 = _computeRotation()
    //     0xc373e4: bl              #0x863468  ; [package:flutter/src/widgets/basic.dart] Transform::_computeRotation
    // 0xc373e8: add             SP, SP, #8
    // 0xc373ec: ldur            x1, [fp, #-0x10]
    // 0xc373f0: StoreField: r1->field_f = r0
    //     0xc373f0: stur            w0, [x1, #0xf]
    //     0xc373f4: ldurb           w16, [x1, #-1]
    //     0xc373f8: ldurb           w17, [x0, #-1]
    //     0xc373fc: and             x16, x17, x16, lsr #2
    //     0xc37400: tst             x16, HEAP, lsr #32
    //     0xc37404: b.eq            #0xc3740c
    //     0xc37408: bl              #0xd6826c
    // 0xc3740c: ldur            x0, [fp, #-8]
    // 0xc37410: StoreField: r1->field_b = r0
    //     0xc37410: stur            w0, [x1, #0xb]
    //     0xc37414: ldurb           w16, [x1, #-1]
    //     0xc37418: ldurb           w17, [x0, #-1]
    //     0xc3741c: and             x16, x17, x16, lsr #2
    //     0xc37420: tst             x16, HEAP, lsr #32
    //     0xc37424: b.eq            #0xc3742c
    //     0xc37428: bl              #0xd6826c
    // 0xc3742c: mov             x0, x1
    // 0xc37430: LeaveFrame
    //     0xc37430: mov             SP, fp
    //     0xc37434: ldp             fp, lr, [SP], #0x10
    // 0xc37438: ret
    //     0xc37438: ret             
    // 0xc3743c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3743c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc37440: b               #0xc37218
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc391c4, size: 0x50
    // 0xc391c4: EnterFrame
    //     0xc391c4: stp             fp, lr, [SP, #-0x10]!
    //     0xc391c8: mov             fp, SP
    // 0xc391cc: ldr             x0, [fp, #0x10]
    // 0xc391d0: LoadField: r1 = r0->field_17
    //     0xc391d0: ldur            w1, [x0, #0x17]
    // 0xc391d4: DecompressPointer r1
    //     0xc391d4: add             x1, x1, HEAP, lsl #32
    // 0xc391d8: CheckStackOverflow
    //     0xc391d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc391dc: cmp             SP, x16
    //     0xc391e0: b.ls            #0xc3920c
    // 0xc391e4: LoadField: r0 = r1->field_f
    //     0xc391e4: ldur            w0, [x1, #0xf]
    // 0xc391e8: DecompressPointer r0
    //     0xc391e8: add             x0, x0, HEAP, lsl #32
    // 0xc391ec: LoadField: r2 = r1->field_13
    //     0xc391ec: ldur            w2, [x1, #0x13]
    // 0xc391f0: DecompressPointer r2
    //     0xc391f0: add             x2, x2, HEAP, lsl #32
    // 0xc391f4: stp             x2, x0, [SP, #-0x10]!
    // 0xc391f8: r0 = handlePaste()
    //     0xc391f8: bl              #0xc03404  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::handlePaste
    // 0xc391fc: add             SP, SP, #0x10
    // 0xc39200: LeaveFrame
    //     0xc39200: mov             SP, fp
    //     0xc39204: ldp             fp, lr, [SP], #0x10
    // 0xc39208: ret
    //     0xc39208: ret             
    // 0xc3920c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3920c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc39210: b               #0xc391e4
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc39214, size: 0x54
    // 0xc39214: EnterFrame
    //     0xc39214: stp             fp, lr, [SP, #-0x10]!
    //     0xc39218: mov             fp, SP
    // 0xc3921c: ldr             x0, [fp, #0x10]
    // 0xc39220: LoadField: r1 = r0->field_17
    //     0xc39220: ldur            w1, [x0, #0x17]
    // 0xc39224: DecompressPointer r1
    //     0xc39224: add             x1, x1, HEAP, lsl #32
    // 0xc39228: CheckStackOverflow
    //     0xc39228: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3922c: cmp             SP, x16
    //     0xc39230: b.ls            #0xc39260
    // 0xc39234: LoadField: r0 = r1->field_13
    //     0xc39234: ldur            w0, [x1, #0x13]
    // 0xc39238: DecompressPointer r0
    //     0xc39238: add             x0, x0, HEAP, lsl #32
    // 0xc3923c: r16 = Instance_SelectionChangedCause
    //     0xc3923c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f638] Obj!SelectionChangedCause@b63f51
    //     0xc39240: ldr             x16, [x16, #0x638]
    // 0xc39244: stp             x16, x0, [SP, #-0x10]!
    // 0xc39248: r0 = copySelection()
    //     0xc39248: bl              #0x836cac  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::copySelection
    // 0xc3924c: add             SP, SP, #0x10
    // 0xc39250: r0 = Null
    //     0xc39250: mov             x0, NULL
    // 0xc39254: LeaveFrame
    //     0xc39254: mov             SP, fp
    //     0xc39258: ldp             fp, lr, [SP], #0x10
    // 0xc3925c: ret
    //     0xc3925c: ret             
    // 0xc39260: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc39260: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc39264: b               #0xc39234
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc39268, size: 0x54
    // 0xc39268: EnterFrame
    //     0xc39268: stp             fp, lr, [SP, #-0x10]!
    //     0xc3926c: mov             fp, SP
    // 0xc39270: ldr             x0, [fp, #0x10]
    // 0xc39274: LoadField: r1 = r0->field_17
    //     0xc39274: ldur            w1, [x0, #0x17]
    // 0xc39278: DecompressPointer r1
    //     0xc39278: add             x1, x1, HEAP, lsl #32
    // 0xc3927c: CheckStackOverflow
    //     0xc3927c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc39280: cmp             SP, x16
    //     0xc39284: b.ls            #0xc392b4
    // 0xc39288: LoadField: r0 = r1->field_13
    //     0xc39288: ldur            w0, [x1, #0x13]
    // 0xc3928c: DecompressPointer r0
    //     0xc3928c: add             x0, x0, HEAP, lsl #32
    // 0xc39290: r16 = Instance_SelectionChangedCause
    //     0xc39290: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f638] Obj!SelectionChangedCause@b63f51
    //     0xc39294: ldr             x16, [x16, #0x638]
    // 0xc39298: stp             x16, x0, [SP, #-0x10]!
    // 0xc3929c: r0 = cutSelection()
    //     0xc3929c: bl              #0x836284  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::cutSelection
    // 0xc392a0: add             SP, SP, #0x10
    // 0xc392a4: r0 = Null
    //     0xc392a4: mov             x0, NULL
    // 0xc392a8: LeaveFrame
    //     0xc392a8: mov             SP, fp
    //     0xc392ac: ldp             fp, lr, [SP], #0x10
    // 0xc392b0: ret
    //     0xc392b0: ret             
    // 0xc392b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc392b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc392b8: b               #0xc39288
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc39460, size: 0x54
    // 0xc39460: EnterFrame
    //     0xc39460: stp             fp, lr, [SP, #-0x10]!
    //     0xc39464: mov             fp, SP
    // 0xc39468: ldr             x0, [fp, #0x10]
    // 0xc3946c: LoadField: r1 = r0->field_17
    //     0xc3946c: ldur            w1, [x0, #0x17]
    // 0xc39470: DecompressPointer r1
    //     0xc39470: add             x1, x1, HEAP, lsl #32
    // 0xc39474: CheckStackOverflow
    //     0xc39474: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc39478: cmp             SP, x16
    //     0xc3947c: b.ls            #0xc394ac
    // 0xc39480: LoadField: r0 = r1->field_13
    //     0xc39480: ldur            w0, [x1, #0x13]
    // 0xc39484: DecompressPointer r0
    //     0xc39484: add             x0, x0, HEAP, lsl #32
    // 0xc39488: r16 = Instance_SelectionChangedCause
    //     0xc39488: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f638] Obj!SelectionChangedCause@b63f51
    //     0xc3948c: ldr             x16, [x16, #0x638]
    // 0xc39490: stp             x16, x0, [SP, #-0x10]!
    // 0xc39494: r0 = selectAll()
    //     0xc39494: bl              #0xc39088  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::selectAll
    // 0xc39498: add             SP, SP, #0x10
    // 0xc3949c: r0 = Null
    //     0xc3949c: mov             x0, NULL
    // 0xc394a0: LeaveFrame
    //     0xc394a0: mov             SP, fp
    //     0xc394a4: ldp             fp, lr, [SP], #0x10
    // 0xc394a8: ret
    //     0xc394a8: ret             
    // 0xc394ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc394ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc394b0: b               #0xc39480
  }
  _ buildToolbar(/* No info */) {
    // ** addr: 0xc39748, size: 0x198
    // 0xc39748: EnterFrame
    //     0xc39748: stp             fp, lr, [SP, #-0x10]!
    //     0xc3974c: mov             fp, SP
    // 0xc39750: AllocStack(0x20)
    //     0xc39750: sub             SP, SP, #0x20
    // 0xc39754: CheckStackOverflow
    //     0xc39754: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc39758: cmp             SP, x16
    //     0xc3975c: b.ls            #0xc398d8
    // 0xc39760: r1 = 2
    //     0xc39760: mov             x1, #2
    // 0xc39764: r0 = AllocateContext()
    //     0xc39764: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc39768: mov             x1, x0
    // 0xc3976c: ldr             x0, [fp, #0x48]
    // 0xc39770: stur            x1, [fp, #-8]
    // 0xc39774: StoreField: r1->field_f = r0
    //     0xc39774: stur            w0, [x1, #0xf]
    // 0xc39778: ldr             x2, [fp, #0x20]
    // 0xc3977c: StoreField: r1->field_13 = r2
    //     0xc3977c: stur            w2, [x1, #0x13]
    // 0xc39780: stp             x2, x0, [SP, #-0x10]!
    // 0xc39784: r0 = canCut()
    //     0xc39784: bl              #0xc0a7ac  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCut
    // 0xc39788: add             SP, SP, #0x10
    // 0xc3978c: tbnz            w0, #4, #0xc397a4
    // 0xc39790: ldur            x2, [fp, #-8]
    // 0xc39794: r1 = Function '<anonymous closure>':.
    //     0xc39794: add             x1, PP, #0x37, lsl #12  ; [pp+0x372e0] AnonymousClosure: (0xc39268), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39798: ldr             x1, [x1, #0x2e0]
    // 0xc3979c: r0 = AllocateClosure()
    //     0xc3979c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc397a0: b               #0xc397a8
    // 0xc397a4: r0 = Null
    //     0xc397a4: mov             x0, NULL
    // 0xc397a8: ldur            x2, [fp, #-8]
    // 0xc397ac: stur            x0, [fp, #-0x10]
    // 0xc397b0: LoadField: r1 = r2->field_13
    //     0xc397b0: ldur            w1, [x2, #0x13]
    // 0xc397b4: DecompressPointer r1
    //     0xc397b4: add             x1, x1, HEAP, lsl #32
    // 0xc397b8: ldr             x16, [fp, #0x48]
    // 0xc397bc: stp             x1, x16, [SP, #-0x10]!
    // 0xc397c0: r0 = canCopy()
    //     0xc397c0: bl              #0xc035f0  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCopy
    // 0xc397c4: add             SP, SP, #0x10
    // 0xc397c8: tbnz            w0, #4, #0xc397e0
    // 0xc397cc: ldur            x2, [fp, #-8]
    // 0xc397d0: r1 = Function '<anonymous closure>':.
    //     0xc397d0: add             x1, PP, #0x37, lsl #12  ; [pp+0x372e8] AnonymousClosure: (0xc39214), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc397d4: ldr             x1, [x1, #0x2e8]
    // 0xc397d8: r0 = AllocateClosure()
    //     0xc397d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc397dc: b               #0xc397e4
    // 0xc397e0: r0 = Null
    //     0xc397e0: mov             x0, NULL
    // 0xc397e4: ldur            x2, [fp, #-8]
    // 0xc397e8: stur            x0, [fp, #-0x18]
    // 0xc397ec: LoadField: r1 = r2->field_13
    //     0xc397ec: ldur            w1, [x2, #0x13]
    // 0xc397f0: DecompressPointer r1
    //     0xc397f0: add             x1, x1, HEAP, lsl #32
    // 0xc397f4: SaveReg r1
    //     0xc397f4: str             x1, [SP, #-8]!
    // 0xc397f8: r0 = pasteEnabled()
    //     0xc397f8: bl              #0x7a2b88  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::pasteEnabled
    // 0xc397fc: add             SP, SP, #8
    // 0xc39800: tbnz            w0, #4, #0xc39818
    // 0xc39804: ldur            x2, [fp, #-8]
    // 0xc39808: r1 = Function '<anonymous closure>':.
    //     0xc39808: add             x1, PP, #0x37, lsl #12  ; [pp+0x372f0] AnonymousClosure: (0xc391c4), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc3980c: ldr             x1, [x1, #0x2f0]
    // 0xc39810: r0 = AllocateClosure()
    //     0xc39810: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39814: b               #0xc3981c
    // 0xc39818: r0 = Null
    //     0xc39818: mov             x0, NULL
    // 0xc3981c: ldur            x2, [fp, #-8]
    // 0xc39820: stur            x0, [fp, #-0x20]
    // 0xc39824: LoadField: r1 = r2->field_13
    //     0xc39824: ldur            w1, [x2, #0x13]
    // 0xc39828: DecompressPointer r1
    //     0xc39828: add             x1, x1, HEAP, lsl #32
    // 0xc3982c: ldr             x16, [fp, #0x48]
    // 0xc39830: stp             x1, x16, [SP, #-0x10]!
    // 0xc39834: r0 = canSelectAll()
    //     0xc39834: bl              #0xc398ec  ; [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::canSelectAll
    // 0xc39838: add             SP, SP, #0x10
    // 0xc3983c: tbnz            w0, #4, #0xc39858
    // 0xc39840: ldur            x2, [fp, #-8]
    // 0xc39844: r1 = Function '<anonymous closure>':.
    //     0xc39844: add             x1, PP, #0x37, lsl #12  ; [pp+0x372f8] AnonymousClosure: (0xc39460), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39848: ldr             x1, [x1, #0x2f8]
    // 0xc3984c: r0 = AllocateClosure()
    //     0xc3984c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39850: mov             x7, x0
    // 0xc39854: b               #0xc3985c
    // 0xc39858: r7 = Null
    //     0xc39858: mov             x7, NULL
    // 0xc3985c: ldr             x6, [fp, #0x40]
    // 0xc39860: ldr             d0, [fp, #0x38]
    // 0xc39864: ldr             x5, [fp, #0x30]
    // 0xc39868: ldr             x4, [fp, #0x28]
    // 0xc3986c: ldr             x3, [fp, #0x18]
    // 0xc39870: ldur            x2, [fp, #-0x10]
    // 0xc39874: ldur            x1, [fp, #-0x18]
    // 0xc39878: ldur            x0, [fp, #-0x20]
    // 0xc3987c: stur            x7, [fp, #-8]
    // 0xc39880: r0 = _TextSelectionControlsToolbar()
    //     0xc39880: bl              #0xc398e0  ; Allocate_TextSelectionControlsToolbarStub -> _TextSelectionControlsToolbar (size=0x34)
    // 0xc39884: ldr             x1, [fp, #0x18]
    // 0xc39888: StoreField: r0->field_b = r1
    //     0xc39888: stur            w1, [x0, #0xb]
    // 0xc3988c: ldr             x1, [fp, #0x28]
    // 0xc39890: StoreField: r0->field_f = r1
    //     0xc39890: stur            w1, [x0, #0xf]
    // 0xc39894: ldr             x1, [fp, #0x40]
    // 0xc39898: StoreField: r0->field_13 = r1
    //     0xc39898: stur            w1, [x0, #0x13]
    // 0xc3989c: ldur            x1, [fp, #-0x10]
    // 0xc398a0: StoreField: r0->field_17 = r1
    //     0xc398a0: stur            w1, [x0, #0x17]
    // 0xc398a4: ldur            x1, [fp, #-0x18]
    // 0xc398a8: StoreField: r0->field_1b = r1
    //     0xc398a8: stur            w1, [x0, #0x1b]
    // 0xc398ac: ldur            x1, [fp, #-0x20]
    // 0xc398b0: StoreField: r0->field_1f = r1
    //     0xc398b0: stur            w1, [x0, #0x1f]
    // 0xc398b4: ldur            x1, [fp, #-8]
    // 0xc398b8: StoreField: r0->field_23 = r1
    //     0xc398b8: stur            w1, [x0, #0x23]
    // 0xc398bc: ldr             x1, [fp, #0x30]
    // 0xc398c0: StoreField: r0->field_27 = r1
    //     0xc398c0: stur            w1, [x0, #0x27]
    // 0xc398c4: ldr             d0, [fp, #0x38]
    // 0xc398c8: StoreField: r0->field_2b = d0
    //     0xc398c8: stur            d0, [x0, #0x2b]
    // 0xc398cc: LeaveFrame
    //     0xc398cc: mov             SP, fp
    //     0xc398d0: ldp             fp, lr, [SP], #0x10
    // 0xc398d4: ret
    //     0xc398d4: ret             
    // 0xc398d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc398d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc398dc: b               #0xc39760
  }
  _ canSelectAll(/* No info */) {
    // ** addr: 0xc398ec, size: 0xbc
    // 0xc398ec: EnterFrame
    //     0xc398ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc398f0: mov             fp, SP
    // 0xc398f4: AllocStack(0x8)
    //     0xc398f4: sub             SP, SP, #8
    // 0xc398f8: CheckStackOverflow
    //     0xc398f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc398fc: cmp             SP, x16
    //     0xc39900: b.ls            #0xc3999c
    // 0xc39904: ldr             x0, [fp, #0x10]
    // 0xc39908: LoadField: r1 = r0->field_b
    //     0xc39908: ldur            w1, [x0, #0xb]
    // 0xc3990c: DecompressPointer r1
    //     0xc3990c: add             x1, x1, HEAP, lsl #32
    // 0xc39910: cmp             w1, NULL
    // 0xc39914: b.eq            #0xc399a4
    // 0xc39918: LoadField: r2 = r1->field_13
    //     0xc39918: ldur            w2, [x1, #0x13]
    // 0xc3991c: DecompressPointer r2
    //     0xc3991c: add             x2, x2, HEAP, lsl #32
    // 0xc39920: LoadField: r1 = r2->field_27
    //     0xc39920: ldur            w1, [x2, #0x27]
    // 0xc39924: DecompressPointer r1
    //     0xc39924: add             x1, x1, HEAP, lsl #32
    // 0xc39928: stur            x1, [fp, #-8]
    // 0xc3992c: SaveReg r0
    //     0xc3992c: str             x0, [SP, #-8]!
    // 0xc39930: r0 = selectAllEnabled()
    //     0xc39930: bl              #0xc38fa4  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::selectAllEnabled
    // 0xc39934: add             SP, SP, #8
    // 0xc39938: tbnz            w0, #4, #0xc3998c
    // 0xc3993c: ldur            x1, [fp, #-8]
    // 0xc39940: LoadField: r2 = r1->field_7
    //     0xc39940: ldur            w2, [x1, #7]
    // 0xc39944: DecompressPointer r2
    //     0xc39944: add             x2, x2, HEAP, lsl #32
    // 0xc39948: LoadField: r3 = r2->field_7
    //     0xc39948: ldur            w3, [x2, #7]
    // 0xc3994c: DecompressPointer r3
    //     0xc3994c: add             x3, x3, HEAP, lsl #32
    // 0xc39950: cbz             w3, #0xc3998c
    // 0xc39954: LoadField: r2 = r1->field_b
    //     0xc39954: ldur            w2, [x1, #0xb]
    // 0xc39958: DecompressPointer r2
    //     0xc39958: add             x2, x2, HEAP, lsl #32
    // 0xc3995c: LoadField: r1 = r2->field_7
    //     0xc3995c: ldur            x1, [x2, #7]
    // 0xc39960: cbnz            x1, #0xc39984
    // 0xc39964: LoadField: r1 = r2->field_f
    //     0xc39964: ldur            x1, [x2, #0xf]
    // 0xc39968: r2 = LoadInt32Instr(r3)
    //     0xc39968: sbfx            x2, x3, #1, #0x1f
    // 0xc3996c: cmp             x1, x2
    // 0xc39970: r16 = true
    //     0xc39970: add             x16, NULL, #0x20  ; true
    // 0xc39974: r17 = false
    //     0xc39974: add             x17, NULL, #0x30  ; false
    // 0xc39978: csel            x3, x16, x17, ne
    // 0xc3997c: mov             x0, x3
    // 0xc39980: b               #0xc39990
    // 0xc39984: r0 = true
    //     0xc39984: add             x0, NULL, #0x20  ; true
    // 0xc39988: b               #0xc39990
    // 0xc3998c: r0 = false
    //     0xc3998c: add             x0, NULL, #0x30  ; false
    // 0xc39990: LeaveFrame
    //     0xc39990: mov             SP, fp
    //     0xc39994: ldp             fp, lr, [SP], #0x10
    // 0xc39998: ret
    //     0xc39998: ret             
    // 0xc3999c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3999c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc399a0: b               #0xc39904
    // 0xc399a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc399a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getHandleAnchor(/* No info */) {
    // ** addr: 0xc527ec, size: 0x38
    // 0xc527ec: ldr             x1, [SP, #8]
    // 0xc527f0: LoadField: r2 = r1->field_7
    //     0xc527f0: ldur            x2, [x1, #7]
    // 0xc527f4: cmp             x2, #1
    // 0xc527f8: b.gt            #0xc52818
    // 0xc527fc: cmp             x2, #0
    // 0xc52800: b.gt            #0xc52810
    // 0xc52804: r0 = Instance_Offset
    //     0xc52804: add             x0, PP, #0x37, lsl #12  ; [pp+0x372b8] Obj!Offset@b5f351
    //     0xc52808: ldr             x0, [x0, #0x2b8]
    // 0xc5280c: ret
    //     0xc5280c: ret             
    // 0xc52810: r0 = Instance_Offset
    //     0xc52810: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xc52814: ret
    //     0xc52814: ret             
    // 0xc52818: r0 = Instance_Offset
    //     0xc52818: add             x0, PP, #0x37, lsl #12  ; [pp+0x372c0] Obj!Offset@b5f331
    //     0xc5281c: ldr             x0, [x0, #0x2c0]
    // 0xc52820: ret
    //     0xc52820: ret             
  }
  _ getHandleSize(/* No info */) {
    // ** addr: 0xcbab68, size: 0xc
    // 0xcbab68: r0 = Instance_Size
    //     0xcbab68: add             x0, PP, #0x37, lsl #12  ; [pp+0x376b8] Obj!Size@b5ee91
    //     0xcbab6c: ldr             x0, [x0, #0x6b8]
    // 0xcbab70: ret
    //     0xcbab70: ret             
  }
}

// class id: 4239, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class _MaterialTextSelectionHandleControls&MaterialTextSelectionControls&TextSelectionHandleControls extends MaterialTextSelectionControls
     with TextSelectionHandleControls {
}

// class id: 4240, size: 0x8, field offset: 0x8
class MaterialTextSelectionHandleControls extends _MaterialTextSelectionHandleControls&MaterialTextSelectionControls&TextSelectionHandleControls {
}

// class id: 4371, size: 0x10, field offset: 0xc
class _TextSelectionHandlePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa70f94, size: 0x1fc
    // 0xa70f94: EnterFrame
    //     0xa70f94: stp             fp, lr, [SP, #-0x10]!
    //     0xa70f98: mov             fp, SP
    // 0xa70f9c: AllocStack(0x30)
    //     0xa70f9c: sub             SP, SP, #0x30
    // 0xa70fa0: CheckStackOverflow
    //     0xa70fa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa70fa4: cmp             SP, x16
    //     0xa70fa8: b.ls            #0xa7116c
    // 0xa70fac: r16 = 112
    //     0xa70fac: mov             x16, #0x70
    // 0xa70fb0: stp             x16, NULL, [SP, #-0x10]!
    // 0xa70fb4: r0 = ByteData()
    //     0xa70fb4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa70fb8: add             SP, SP, #0x10
    // 0xa70fbc: stur            x0, [fp, #-8]
    // 0xa70fc0: r0 = Paint()
    //     0xa70fc0: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa70fc4: mov             x1, x0
    // 0xa70fc8: ldur            x0, [fp, #-8]
    // 0xa70fcc: stur            x1, [fp, #-0x10]
    // 0xa70fd0: StoreField: r1->field_7 = r0
    //     0xa70fd0: stur            w0, [x1, #7]
    // 0xa70fd4: ldr             x2, [fp, #0x20]
    // 0xa70fd8: LoadField: r3 = r2->field_b
    //     0xa70fd8: ldur            w3, [x2, #0xb]
    // 0xa70fdc: DecompressPointer r3
    //     0xa70fdc: add             x3, x3, HEAP, lsl #32
    // 0xa70fe0: r2 = LoadClassIdInstr(r3)
    //     0xa70fe0: ldur            x2, [x3, #-1]
    //     0xa70fe4: ubfx            x2, x2, #0xc, #0x14
    // 0xa70fe8: lsl             x2, x2, #1
    // 0xa70fec: r17 = 10124
    //     0xa70fec: mov             x17, #0x278c
    // 0xa70ff0: cmp             w2, w17
    // 0xa70ff4: b.gt            #0xa71004
    // 0xa70ff8: r17 = 10122
    //     0xa70ff8: mov             x17, #0x278a
    // 0xa70ffc: cmp             w2, w17
    // 0xa71000: b.ge            #0xa7101c
    // 0xa71004: r17 = 10114
    //     0xa71004: mov             x17, #0x2782
    // 0xa71008: cmp             w2, w17
    // 0xa7100c: b.eq            #0xa7101c
    // 0xa71010: r17 = 10118
    //     0xa71010: mov             x17, #0x2786
    // 0xa71014: cmp             w2, w17
    // 0xa71018: b.ne            #0xa71028
    // 0xa7101c: LoadField: r2 = r3->field_7
    //     0xa7101c: ldur            x2, [x3, #7]
    // 0xa71020: mov             x3, x2
    // 0xa71024: b               #0xa71034
    // 0xa71028: LoadField: r2 = r3->field_f
    //     0xa71028: ldur            w2, [x3, #0xf]
    // 0xa7102c: DecompressPointer r2
    //     0xa7102c: add             x2, x2, HEAP, lsl #32
    // 0xa71030: LoadField: r3 = r2->field_7
    //     0xa71030: ldur            x3, [x2, #7]
    // 0xa71034: ldr             x2, [fp, #0x10]
    // 0xa71038: d0 = 2.000000
    //     0xa71038: fmov            d0, #2.00000000
    // 0xa7103c: eor             x4, x3, #0xff000000
    // 0xa71040: LoadField: r3 = r0->field_17
    //     0xa71040: ldur            w3, [x0, #0x17]
    // 0xa71044: DecompressPointer r3
    //     0xa71044: add             x3, x3, HEAP, lsl #32
    // 0xa71048: sxtw            x4, w4
    // 0xa7104c: LoadField: r0 = r3->field_7
    //     0xa7104c: ldur            x0, [x3, #7]
    // 0xa71050: str             w4, [x0, #4]
    // 0xa71054: LoadField: d1 = r2->field_7
    //     0xa71054: ldur            d1, [x2, #7]
    // 0xa71058: fdiv            d2, d1, d0
    // 0xa7105c: stur            d2, [fp, #-0x28]
    // 0xa71060: r0 = Offset()
    //     0xa71060: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa71064: ldur            d0, [fp, #-0x28]
    // 0xa71068: stur            x0, [fp, #-0x18]
    // 0xa7106c: StoreField: r0->field_7 = d0
    //     0xa7106c: stur            d0, [x0, #7]
    // 0xa71070: StoreField: r0->field_f = d0
    //     0xa71070: stur            d0, [x0, #0xf]
    // 0xa71074: d1 = 2.000000
    //     0xa71074: fmov            d1, #2.00000000
    // 0xa71078: fmul            d2, d0, d1
    // 0xa7107c: stur            d2, [fp, #-0x30]
    // 0xa71080: r1 = inline_Allocate_Double()
    //     0xa71080: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xa71084: add             x1, x1, #0x10
    //     0xa71088: cmp             x2, x1
    //     0xa7108c: b.ls            #0xa71174
    //     0xa71090: str             x1, [THR, #0x60]  ; THR::top
    //     0xa71094: sub             x1, x1, #0xf
    //     0xa71098: mov             x2, #0xd108
    //     0xa7109c: movk            x2, #3, lsl #16
    //     0xa710a0: stur            x2, [x1, #-1]
    // 0xa710a4: StoreField: r1->field_7 = d2
    //     0xa710a4: stur            d2, [x1, #7]
    // 0xa710a8: stur            x1, [fp, #-8]
    // 0xa710ac: r0 = Rect()
    //     0xa710ac: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa710b0: stur            x0, [fp, #-0x20]
    // 0xa710b4: ldur            x16, [fp, #-0x18]
    // 0xa710b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa710bc: ldur            x16, [fp, #-8]
    // 0xa710c0: SaveReg r16
    //     0xa710c0: str             x16, [SP, #-8]!
    // 0xa710c4: ldur            d0, [fp, #-0x30]
    // 0xa710c8: SaveReg d0
    //     0xa710c8: str             d0, [SP, #-8]!
    // 0xa710cc: r0 = Rect.fromCenter()
    //     0xa710cc: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0xa710d0: add             SP, SP, #0x20
    // 0xa710d4: ldur            d0, [fp, #-0x28]
    // 0xa710d8: d1 = 0.000000
    //     0xa710d8: eor             v1.16b, v1.16b, v1.16b
    // 0xa710dc: fadd            d2, d1, d0
    // 0xa710e0: stur            d2, [fp, #-0x30]
    // 0xa710e4: r0 = Rect()
    //     0xa710e4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa710e8: d0 = 0.000000
    //     0xa710e8: eor             v0.16b, v0.16b, v0.16b
    // 0xa710ec: stur            x0, [fp, #-8]
    // 0xa710f0: StoreField: r0->field_7 = d0
    //     0xa710f0: stur            d0, [x0, #7]
    // 0xa710f4: StoreField: r0->field_f = d0
    //     0xa710f4: stur            d0, [x0, #0xf]
    // 0xa710f8: ldur            d0, [fp, #-0x30]
    // 0xa710fc: StoreField: r0->field_17 = d0
    //     0xa710fc: stur            d0, [x0, #0x17]
    // 0xa71100: StoreField: r0->field_1f = d0
    //     0xa71100: stur            d0, [x0, #0x1f]
    // 0xa71104: r0 = Path()
    //     0xa71104: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa71108: stur            x0, [fp, #-0x18]
    // 0xa7110c: SaveReg r0
    //     0xa7110c: str             x0, [SP, #-8]!
    // 0xa71110: r0 = _constructor()
    //     0xa71110: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa71114: add             SP, SP, #8
    // 0xa71118: ldur            x16, [fp, #-0x18]
    // 0xa7111c: ldur            lr, [fp, #-0x20]
    // 0xa71120: stp             lr, x16, [SP, #-0x10]!
    // 0xa71124: r0 = addOval()
    //     0xa71124: bl              #0x6633ac  ; [dart:ui] Path::addOval
    // 0xa71128: add             SP, SP, #0x10
    // 0xa7112c: ldur            x16, [fp, #-0x18]
    // 0xa71130: ldur            lr, [fp, #-8]
    // 0xa71134: stp             lr, x16, [SP, #-0x10]!
    // 0xa71138: r0 = addRect()
    //     0xa71138: bl              #0x71a7b0  ; [dart:ui] Path::addRect
    // 0xa7113c: add             SP, SP, #0x10
    // 0xa71140: ldr             x16, [fp, #0x18]
    // 0xa71144: ldur            lr, [fp, #-0x18]
    // 0xa71148: stp             lr, x16, [SP, #-0x10]!
    // 0xa7114c: ldur            x16, [fp, #-0x10]
    // 0xa71150: SaveReg r16
    //     0xa71150: str             x16, [SP, #-8]!
    // 0xa71154: r0 = drawPath()
    //     0xa71154: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa71158: add             SP, SP, #0x18
    // 0xa7115c: r0 = Null
    //     0xa7115c: mov             x0, NULL
    // 0xa71160: LeaveFrame
    //     0xa71160: mov             SP, fp
    //     0xa71164: ldp             fp, lr, [SP], #0x10
    // 0xa71168: ret
    //     0xa71168: ret             
    // 0xa7116c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa7116c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa71170: b               #0xa70fac
    // 0xa71174: stp             q0, q2, [SP, #-0x20]!
    // 0xa71178: SaveReg r0
    //     0xa71178: str             x0, [SP, #-8]!
    // 0xa7117c: r0 = AllocateDouble()
    //     0xa7117c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa71180: mov             x1, x0
    // 0xa71184: RestoreReg r0
    //     0xa71184: ldr             x0, [SP], #8
    // 0xa71188: ldp             q0, q2, [SP], #0x20
    // 0xa7118c: b               #0xa710a4
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa7a510, size: 0x1cc
    // 0xa7a510: EnterFrame
    //     0xa7a510: stp             fp, lr, [SP, #-0x10]!
    //     0xa7a514: mov             fp, SP
    // 0xa7a518: AllocStack(0x18)
    //     0xa7a518: sub             SP, SP, #0x18
    // 0xa7a51c: CheckStackOverflow
    //     0xa7a51c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa7a520: cmp             SP, x16
    //     0xa7a524: b.ls            #0xa7a6d4
    // 0xa7a528: ldr             x0, [fp, #0x10]
    // 0xa7a52c: r2 = Null
    //     0xa7a52c: mov             x2, NULL
    // 0xa7a530: r1 = Null
    //     0xa7a530: mov             x1, NULL
    // 0xa7a534: r4 = 59
    //     0xa7a534: mov             x4, #0x3b
    // 0xa7a538: branchIfSmi(r0, 0xa7a544)
    //     0xa7a538: tbz             w0, #0, #0xa7a544
    // 0xa7a53c: r4 = LoadClassIdInstr(r0)
    //     0xa7a53c: ldur            x4, [x0, #-1]
    //     0xa7a540: ubfx            x4, x4, #0xc, #0x14
    // 0xa7a544: r17 = 4371
    //     0xa7a544: mov             x17, #0x1113
    // 0xa7a548: cmp             x4, x17
    // 0xa7a54c: b.eq            #0xa7a564
    // 0xa7a550: r8 = _TextSelectionHandlePainter
    //     0xa7a550: add             x8, PP, #0x3f, lsl #12  ; [pp+0x3fed0] Type: _TextSelectionHandlePainter
    //     0xa7a554: ldr             x8, [x8, #0xed0]
    // 0xa7a558: r3 = Null
    //     0xa7a558: add             x3, PP, #0x3f, lsl #12  ; [pp+0x3fed8] Null
    //     0xa7a55c: ldr             x3, [x3, #0xed8]
    // 0xa7a560: r0 = DefaultTypeTest()
    //     0xa7a560: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa7a564: ldr             x0, [fp, #0x18]
    // 0xa7a568: LoadField: r1 = r0->field_b
    //     0xa7a568: ldur            w1, [x0, #0xb]
    // 0xa7a56c: DecompressPointer r1
    //     0xa7a56c: add             x1, x1, HEAP, lsl #32
    // 0xa7a570: ldr             x0, [fp, #0x10]
    // 0xa7a574: stur            x1, [fp, #-0x18]
    // 0xa7a578: LoadField: r2 = r0->field_b
    //     0xa7a578: ldur            w2, [x0, #0xb]
    // 0xa7a57c: DecompressPointer r2
    //     0xa7a57c: add             x2, x2, HEAP, lsl #32
    // 0xa7a580: stur            x2, [fp, #-0x10]
    // 0xa7a584: r0 = LoadClassIdInstr(r1)
    //     0xa7a584: ldur            x0, [x1, #-1]
    //     0xa7a588: ubfx            x0, x0, #0xc, #0x14
    // 0xa7a58c: lsl             x0, x0, #1
    // 0xa7a590: stur            x0, [fp, #-8]
    // 0xa7a594: r17 = 10114
    //     0xa7a594: mov             x17, #0x2782
    // 0xa7a598: cmp             w0, w17
    // 0xa7a59c: b.eq            #0xa7a5ac
    // 0xa7a5a0: r17 = 10118
    //     0xa7a5a0: mov             x17, #0x2786
    // 0xa7a5a4: cmp             w0, w17
    // 0xa7a5a8: b.ne            #0xa7a698
    // 0xa7a5ac: cmp             w1, w2
    // 0xa7a5b0: b.ne            #0xa7a5bc
    // 0xa7a5b4: r1 = true
    //     0xa7a5b4: add             x1, NULL, #0x20  ; true
    // 0xa7a5b8: b               #0xa7a6c4
    // 0xa7a5bc: stp             x1, x2, [SP, #-0x10]!
    // 0xa7a5c0: r0 = _haveSameRuntimeType()
    //     0xa7a5c0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa7a5c4: add             SP, SP, #0x10
    // 0xa7a5c8: tbz             w0, #4, #0xa7a5d4
    // 0xa7a5cc: r1 = false
    //     0xa7a5cc: add             x1, NULL, #0x30  ; false
    // 0xa7a5d0: b               #0xa7a6c4
    // 0xa7a5d4: ldur            x0, [fp, #-0x10]
    // 0xa7a5d8: r1 = LoadClassIdInstr(r0)
    //     0xa7a5d8: ldur            x1, [x0, #-1]
    //     0xa7a5dc: ubfx            x1, x1, #0xc, #0x14
    // 0xa7a5e0: lsl             x1, x1, #1
    // 0xa7a5e4: r17 = 10124
    //     0xa7a5e4: mov             x17, #0x278c
    // 0xa7a5e8: cmp             w1, w17
    // 0xa7a5ec: b.gt            #0xa7a5fc
    // 0xa7a5f0: r17 = 10122
    //     0xa7a5f0: mov             x17, #0x278a
    // 0xa7a5f4: cmp             w1, w17
    // 0xa7a5f8: b.ge            #0xa7a614
    // 0xa7a5fc: r17 = 10114
    //     0xa7a5fc: mov             x17, #0x2782
    // 0xa7a600: cmp             w1, w17
    // 0xa7a604: b.eq            #0xa7a614
    // 0xa7a608: r17 = 10118
    //     0xa7a608: mov             x17, #0x2786
    // 0xa7a60c: cmp             w1, w17
    // 0xa7a610: b.ne            #0xa7a61c
    // 0xa7a614: LoadField: r1 = r0->field_7
    //     0xa7a614: ldur            x1, [x0, #7]
    // 0xa7a618: b               #0xa7a62c
    // 0xa7a61c: LoadField: r1 = r0->field_f
    //     0xa7a61c: ldur            w1, [x0, #0xf]
    // 0xa7a620: DecompressPointer r1
    //     0xa7a620: add             x1, x1, HEAP, lsl #32
    // 0xa7a624: LoadField: r0 = r1->field_7
    //     0xa7a624: ldur            x0, [x1, #7]
    // 0xa7a628: mov             x1, x0
    // 0xa7a62c: ldur            x0, [fp, #-8]
    // 0xa7a630: r17 = 10124
    //     0xa7a630: mov             x17, #0x278c
    // 0xa7a634: cmp             w0, w17
    // 0xa7a638: b.gt            #0xa7a648
    // 0xa7a63c: r17 = 10122
    //     0xa7a63c: mov             x17, #0x278a
    // 0xa7a640: cmp             w0, w17
    // 0xa7a644: b.ge            #0xa7a660
    // 0xa7a648: r17 = 10114
    //     0xa7a648: mov             x17, #0x2782
    // 0xa7a64c: cmp             w0, w17
    // 0xa7a650: b.eq            #0xa7a660
    // 0xa7a654: r17 = 10118
    //     0xa7a654: mov             x17, #0x2786
    // 0xa7a658: cmp             w0, w17
    // 0xa7a65c: b.ne            #0xa7a66c
    // 0xa7a660: ldur            x2, [fp, #-0x18]
    // 0xa7a664: LoadField: r0 = r2->field_7
    //     0xa7a664: ldur            x0, [x2, #7]
    // 0xa7a668: b               #0xa7a680
    // 0xa7a66c: ldur            x2, [fp, #-0x18]
    // 0xa7a670: LoadField: r0 = r2->field_f
    //     0xa7a670: ldur            w0, [x2, #0xf]
    // 0xa7a674: DecompressPointer r0
    //     0xa7a674: add             x0, x0, HEAP, lsl #32
    // 0xa7a678: LoadField: r2 = r0->field_7
    //     0xa7a678: ldur            x2, [x0, #7]
    // 0xa7a67c: mov             x0, x2
    // 0xa7a680: cmp             x1, x0
    // 0xa7a684: r16 = true
    //     0xa7a684: add             x16, NULL, #0x20  ; true
    // 0xa7a688: r17 = false
    //     0xa7a688: add             x17, NULL, #0x30  ; false
    // 0xa7a68c: csel            x2, x16, x17, eq
    // 0xa7a690: mov             x1, x2
    // 0xa7a694: b               #0xa7a6c4
    // 0xa7a698: mov             x0, x2
    // 0xa7a69c: mov             x2, x1
    // 0xa7a6a0: r1 = LoadClassIdInstr(r2)
    //     0xa7a6a0: ldur            x1, [x2, #-1]
    //     0xa7a6a4: ubfx            x1, x1, #0xc, #0x14
    // 0xa7a6a8: stp             x0, x2, [SP, #-0x10]!
    // 0xa7a6ac: mov             x0, x1
    // 0xa7a6b0: mov             lr, x0
    // 0xa7a6b4: ldr             lr, [x21, lr, lsl #3]
    // 0xa7a6b8: blr             lr
    // 0xa7a6bc: add             SP, SP, #0x10
    // 0xa7a6c0: mov             x1, x0
    // 0xa7a6c4: eor             x0, x1, #0x10
    // 0xa7a6c8: LeaveFrame
    //     0xa7a6c8: mov             SP, fp
    //     0xa7a6cc: ldp             fp, lr, [SP], #0x10
    // 0xa7a6d0: ret
    //     0xa7a6d0: ret             
    // 0xa7a6d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa7a6d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa7a6d8: b               #0xa7a528
  }
}

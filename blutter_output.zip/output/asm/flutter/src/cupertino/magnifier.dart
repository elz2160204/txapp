// lib: , url: package:flutter/src/cupertino/magnifier.dart

// class id: 1049096, size: 0x8
class :: {
}

// class id: 3354, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CupertinoTextMagnifierState&State&SingleTickerProviderStateMixin extends State<CupertinoTextMagnifier>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x614f78, size: 0x98
    // 0x614f78: EnterFrame
    //     0x614f78: stp             fp, lr, [SP, #-0x10]!
    //     0x614f7c: mov             fp, SP
    // 0x614f80: CheckStackOverflow
    //     0x614f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614f84: cmp             SP, x16
    //     0x614f88: b.ls            #0x615004
    // 0x614f8c: r0 = Ticker()
    //     0x614f8c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x614f90: mov             x1, x0
    // 0x614f94: r0 = false
    //     0x614f94: add             x0, NULL, #0x30  ; false
    // 0x614f98: StoreField: r1->field_b = r0
    //     0x614f98: stur            w0, [x1, #0xb]
    // 0x614f9c: ldr             x0, [fp, #0x10]
    // 0x614fa0: StoreField: r1->field_13 = r0
    //     0x614fa0: stur            w0, [x1, #0x13]
    // 0x614fa4: mov             x0, x1
    // 0x614fa8: ldr             x1, [fp, #0x18]
    // 0x614fac: StoreField: r1->field_13 = r0
    //     0x614fac: stur            w0, [x1, #0x13]
    //     0x614fb0: ldurb           w16, [x1, #-1]
    //     0x614fb4: ldurb           w17, [x0, #-1]
    //     0x614fb8: and             x16, x17, x16, lsr #2
    //     0x614fbc: tst             x16, HEAP, lsr #32
    //     0x614fc0: b.eq            #0x614fc8
    //     0x614fc4: bl              #0xd6826c
    // 0x614fc8: SaveReg r1
    //     0x614fc8: str             x1, [SP, #-8]!
    // 0x614fcc: r0 = _updateTickerModeNotifier()
    //     0x614fcc: bl              #0x615034  ; [package:flutter/src/cupertino/magnifier.dart] __CupertinoTextMagnifierState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x614fd0: add             SP, SP, #8
    // 0x614fd4: ldr             x16, [fp, #0x18]
    // 0x614fd8: SaveReg r16
    //     0x614fd8: str             x16, [SP, #-8]!
    // 0x614fdc: r0 = _updateTicker()
    //     0x614fdc: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614fe0: add             SP, SP, #8
    // 0x614fe4: ldr             x1, [fp, #0x18]
    // 0x614fe8: LoadField: r0 = r1->field_13
    //     0x614fe8: ldur            w0, [x1, #0x13]
    // 0x614fec: DecompressPointer r0
    //     0x614fec: add             x0, x0, HEAP, lsl #32
    // 0x614ff0: cmp             w0, NULL
    // 0x614ff4: b.eq            #0x61500c
    // 0x614ff8: LeaveFrame
    //     0x614ff8: mov             SP, fp
    //     0x614ffc: ldp             fp, lr, [SP], #0x10
    // 0x615000: ret
    //     0x615000: ret             
    // 0x615004: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615004: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615008: b               #0x614f8c
    // 0x61500c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61500c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x615034, size: 0x11c
    // 0x615034: EnterFrame
    //     0x615034: stp             fp, lr, [SP, #-0x10]!
    //     0x615038: mov             fp, SP
    // 0x61503c: AllocStack(0x10)
    //     0x61503c: sub             SP, SP, #0x10
    // 0x615040: CheckStackOverflow
    //     0x615040: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615044: cmp             SP, x16
    //     0x615048: b.ls            #0x615144
    // 0x61504c: ldr             x0, [fp, #0x10]
    // 0x615050: LoadField: r1 = r0->field_f
    //     0x615050: ldur            w1, [x0, #0xf]
    // 0x615054: DecompressPointer r1
    //     0x615054: add             x1, x1, HEAP, lsl #32
    // 0x615058: cmp             w1, NULL
    // 0x61505c: b.eq            #0x61514c
    // 0x615060: SaveReg r1
    //     0x615060: str             x1, [SP, #-8]!
    // 0x615064: r0 = getNotifier()
    //     0x615064: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x615068: add             SP, SP, #8
    // 0x61506c: mov             x1, x0
    // 0x615070: ldr             x0, [fp, #0x10]
    // 0x615074: stur            x1, [fp, #-0x10]
    // 0x615078: LoadField: r2 = r0->field_17
    //     0x615078: ldur            w2, [x0, #0x17]
    // 0x61507c: DecompressPointer r2
    //     0x61507c: add             x2, x2, HEAP, lsl #32
    // 0x615080: stur            x2, [fp, #-8]
    // 0x615084: cmp             w1, w2
    // 0x615088: b.ne            #0x61509c
    // 0x61508c: r0 = Null
    //     0x61508c: mov             x0, NULL
    // 0x615090: LeaveFrame
    //     0x615090: mov             SP, fp
    //     0x615094: ldp             fp, lr, [SP], #0x10
    // 0x615098: ret
    //     0x615098: ret             
    // 0x61509c: cmp             w2, NULL
    // 0x6150a0: b.eq            #0x6150dc
    // 0x6150a4: r1 = 1
    //     0x6150a4: mov             x1, #1
    // 0x6150a8: r0 = AllocateContext()
    //     0x6150a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6150ac: mov             x1, x0
    // 0x6150b0: ldr             x0, [fp, #0x10]
    // 0x6150b4: StoreField: r1->field_f = r0
    //     0x6150b4: stur            w0, [x1, #0xf]
    // 0x6150b8: mov             x2, x1
    // 0x6150bc: r1 = Function '_updateTicker@156311458':.
    //     0x6150bc: add             x1, PP, #0x40, lsl #12  ; [pp+0x40410] AnonymousClosure: (0x615150), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x6150c0: ldr             x1, [x1, #0x410]
    // 0x6150c4: r0 = AllocateClosure()
    //     0x6150c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6150c8: ldur            x16, [fp, #-8]
    // 0x6150cc: stp             x0, x16, [SP, #-0x10]!
    // 0x6150d0: r0 = removeListener()
    //     0x6150d0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x6150d4: add             SP, SP, #0x10
    // 0x6150d8: ldr             x0, [fp, #0x10]
    // 0x6150dc: r1 = 1
    //     0x6150dc: mov             x1, #1
    // 0x6150e0: r0 = AllocateContext()
    //     0x6150e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6150e4: mov             x1, x0
    // 0x6150e8: ldr             x0, [fp, #0x10]
    // 0x6150ec: StoreField: r1->field_f = r0
    //     0x6150ec: stur            w0, [x1, #0xf]
    // 0x6150f0: mov             x2, x1
    // 0x6150f4: r1 = Function '_updateTicker@156311458':.
    //     0x6150f4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40410] AnonymousClosure: (0x615150), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x6150f8: ldr             x1, [x1, #0x410]
    // 0x6150fc: r0 = AllocateClosure()
    //     0x6150fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x615100: ldur            x16, [fp, #-0x10]
    // 0x615104: stp             x0, x16, [SP, #-0x10]!
    // 0x615108: r0 = addListener()
    //     0x615108: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x61510c: add             SP, SP, #0x10
    // 0x615110: ldur            x0, [fp, #-0x10]
    // 0x615114: ldr             x1, [fp, #0x10]
    // 0x615118: StoreField: r1->field_17 = r0
    //     0x615118: stur            w0, [x1, #0x17]
    //     0x61511c: ldurb           w16, [x1, #-1]
    //     0x615120: ldurb           w17, [x0, #-1]
    //     0x615124: and             x16, x17, x16, lsr #2
    //     0x615128: tst             x16, HEAP, lsr #32
    //     0x61512c: b.eq            #0x615134
    //     0x615130: bl              #0xd6826c
    // 0x615134: r0 = Null
    //     0x615134: mov             x0, NULL
    // 0x615138: LeaveFrame
    //     0x615138: mov             SP, fp
    //     0x61513c: ldp             fp, lr, [SP], #0x10
    // 0x615140: ret
    //     0x615140: ret             
    // 0x615144: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615144: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615148: b               #0x61504c
    // 0x61514c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61514c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x615150, size: 0x48
    // 0x615150: EnterFrame
    //     0x615150: stp             fp, lr, [SP, #-0x10]!
    //     0x615154: mov             fp, SP
    // 0x615158: ldr             x0, [fp, #0x10]
    // 0x61515c: LoadField: r1 = r0->field_17
    //     0x61515c: ldur            w1, [x0, #0x17]
    // 0x615160: DecompressPointer r1
    //     0x615160: add             x1, x1, HEAP, lsl #32
    // 0x615164: CheckStackOverflow
    //     0x615164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615168: cmp             SP, x16
    //     0x61516c: b.ls            #0x615190
    // 0x615170: LoadField: r0 = r1->field_f
    //     0x615170: ldur            w0, [x1, #0xf]
    // 0x615174: DecompressPointer r0
    //     0x615174: add             x0, x0, HEAP, lsl #32
    // 0x615178: SaveReg r0
    //     0x615178: str             x0, [SP, #-8]!
    // 0x61517c: r0 = _updateTicker()
    //     0x61517c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x615180: add             SP, SP, #8
    // 0x615184: LeaveFrame
    //     0x615184: mov             SP, fp
    //     0x615188: ldp             fp, lr, [SP], #0x10
    // 0x61518c: ret
    //     0x61518c: ret             
    // 0x615190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615194: b               #0x615170
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f164, size: 0x4c
    // 0x81f164: EnterFrame
    //     0x81f164: stp             fp, lr, [SP, #-0x10]!
    //     0x81f168: mov             fp, SP
    // 0x81f16c: CheckStackOverflow
    //     0x81f16c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f170: cmp             SP, x16
    //     0x81f174: b.ls            #0x81f1a8
    // 0x81f178: ldr             x16, [fp, #0x10]
    // 0x81f17c: SaveReg r16
    //     0x81f17c: str             x16, [SP, #-8]!
    // 0x81f180: r0 = _updateTickerModeNotifier()
    //     0x81f180: bl              #0x615034  ; [package:flutter/src/cupertino/magnifier.dart] __CupertinoTextMagnifierState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f184: add             SP, SP, #8
    // 0x81f188: ldr             x16, [fp, #0x10]
    // 0x81f18c: SaveReg r16
    //     0x81f18c: str             x16, [SP, #-8]!
    // 0x81f190: r0 = _updateTicker()
    //     0x81f190: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f194: add             SP, SP, #8
    // 0x81f198: r0 = Null
    //     0x81f198: mov             x0, NULL
    // 0x81f19c: LeaveFrame
    //     0x81f19c: mov             SP, fp
    //     0x81f1a0: ldp             fp, lr, [SP], #0x10
    // 0x81f1a4: ret
    //     0x81f1a4: ret             
    // 0x81f1a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f1a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f1ac: b               #0x81f178
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50608, size: 0x8c
    // 0xa50608: EnterFrame
    //     0xa50608: stp             fp, lr, [SP, #-0x10]!
    //     0xa5060c: mov             fp, SP
    // 0xa50610: AllocStack(0x8)
    //     0xa50610: sub             SP, SP, #8
    // 0xa50614: CheckStackOverflow
    //     0xa50614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50618: cmp             SP, x16
    //     0xa5061c: b.ls            #0xa5068c
    // 0xa50620: ldr             x0, [fp, #0x10]
    // 0xa50624: LoadField: r1 = r0->field_17
    //     0xa50624: ldur            w1, [x0, #0x17]
    // 0xa50628: DecompressPointer r1
    //     0xa50628: add             x1, x1, HEAP, lsl #32
    // 0xa5062c: stur            x1, [fp, #-8]
    // 0xa50630: cmp             w1, NULL
    // 0xa50634: b.ne            #0xa50640
    // 0xa50638: mov             x1, x0
    // 0xa5063c: b               #0xa50678
    // 0xa50640: r1 = 1
    //     0xa50640: mov             x1, #1
    // 0xa50644: r0 = AllocateContext()
    //     0xa50644: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50648: mov             x1, x0
    // 0xa5064c: ldr             x0, [fp, #0x10]
    // 0xa50650: StoreField: r1->field_f = r0
    //     0xa50650: stur            w0, [x1, #0xf]
    // 0xa50654: mov             x2, x1
    // 0xa50658: r1 = Function '_updateTicker@156311458':.
    //     0xa50658: add             x1, PP, #0x40, lsl #12  ; [pp+0x40410] AnonymousClosure: (0x615150), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa5065c: ldr             x1, [x1, #0x410]
    // 0xa50660: r0 = AllocateClosure()
    //     0xa50660: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa50664: ldur            x16, [fp, #-8]
    // 0xa50668: stp             x0, x16, [SP, #-0x10]!
    // 0xa5066c: r0 = removeListener()
    //     0xa5066c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa50670: add             SP, SP, #0x10
    // 0xa50674: ldr             x1, [fp, #0x10]
    // 0xa50678: StoreField: r1->field_17 = rNULL
    //     0xa50678: stur            NULL, [x1, #0x17]
    // 0xa5067c: r0 = Null
    //     0xa5067c: mov             x0, NULL
    // 0xa50680: LeaveFrame
    //     0xa50680: mov             SP, fp
    //     0xa50684: ldp             fp, lr, [SP], #0x10
    // 0xa50688: ret
    //     0xa50688: ret             
    // 0xa5068c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5068c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50690: b               #0xa50620
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa50694, size: 0x48
    // 0xa50694: EnterFrame
    //     0xa50694: stp             fp, lr, [SP, #-0x10]!
    //     0xa50698: mov             fp, SP
    // 0xa5069c: ldr             x0, [fp, #0x10]
    // 0xa506a0: LoadField: r1 = r0->field_17
    //     0xa506a0: ldur            w1, [x0, #0x17]
    // 0xa506a4: DecompressPointer r1
    //     0xa506a4: add             x1, x1, HEAP, lsl #32
    // 0xa506a8: CheckStackOverflow
    //     0xa506a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa506ac: cmp             SP, x16
    //     0xa506b0: b.ls            #0xa506d4
    // 0xa506b4: LoadField: r0 = r1->field_f
    //     0xa506b4: ldur            w0, [x1, #0xf]
    // 0xa506b8: DecompressPointer r0
    //     0xa506b8: add             x0, x0, HEAP, lsl #32
    // 0xa506bc: SaveReg r0
    //     0xa506bc: str             x0, [SP, #-8]!
    // 0xa506c0: r0 = dispose()
    //     0xa506c0: bl              #0xa50608  ; [package:flutter/src/cupertino/magnifier.dart] __CupertinoTextMagnifierState&State&SingleTickerProviderStateMixin::dispose
    // 0xa506c4: add             SP, SP, #8
    // 0xa506c8: LeaveFrame
    //     0xa506c8: mov             SP, fp
    //     0xa506cc: ldp             fp, lr, [SP], #0x10
    // 0xa506d0: ret
    //     0xa506d0: ret             
    // 0xa506d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa506d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa506d8: b               #0xa506b4
  }
}

// class id: 3355, size: 0x30, field offset: 0x1c
class _CupertinoTextMagnifierState extends __CupertinoTextMagnifierState&State&SingleTickerProviderStateMixin {

  late Animation<double> _ioAnimation; // offset: 0x2c
  late AnimationController _ioAnimationController; // offset: 0x28

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7af0d0, size: 0x1a4
    // 0x7af0d0: EnterFrame
    //     0x7af0d0: stp             fp, lr, [SP, #-0x10]!
    //     0x7af0d4: mov             fp, SP
    // 0x7af0d8: AllocStack(0x8)
    //     0x7af0d8: sub             SP, SP, #8
    // 0x7af0dc: CheckStackOverflow
    //     0x7af0dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7af0e0: cmp             SP, x16
    //     0x7af0e4: b.ls            #0x7af264
    // 0x7af0e8: ldr             x0, [fp, #0x10]
    // 0x7af0ec: r2 = Null
    //     0x7af0ec: mov             x2, NULL
    // 0x7af0f0: r1 = Null
    //     0x7af0f0: mov             x1, NULL
    // 0x7af0f4: r4 = 59
    //     0x7af0f4: mov             x4, #0x3b
    // 0x7af0f8: branchIfSmi(r0, 0x7af104)
    //     0x7af0f8: tbz             w0, #0, #0x7af104
    // 0x7af0fc: r4 = LoadClassIdInstr(r0)
    //     0x7af0fc: ldur            x4, [x0, #-1]
    //     0x7af100: ubfx            x4, x4, #0xc, #0x14
    // 0x7af104: r17 = 4180
    //     0x7af104: mov             x17, #0x1054
    // 0x7af108: cmp             x4, x17
    // 0x7af10c: b.eq            #0x7af124
    // 0x7af110: r8 = CupertinoTextMagnifier
    //     0x7af110: add             x8, PP, #0x40, lsl #12  ; [pp+0x40470] Type: CupertinoTextMagnifier
    //     0x7af114: ldr             x8, [x8, #0x470]
    // 0x7af118: r3 = Null
    //     0x7af118: add             x3, PP, #0x40, lsl #12  ; [pp+0x40478] Null
    //     0x7af11c: ldr             x3, [x3, #0x478]
    // 0x7af120: r0 = CupertinoTextMagnifier()
    //     0x7af120: bl              #0x615010  ; IsType_CupertinoTextMagnifier_Stub
    // 0x7af124: ldr             x0, [fp, #0x10]
    // 0x7af128: LoadField: r1 = r0->field_2b
    //     0x7af128: ldur            w1, [x0, #0x2b]
    // 0x7af12c: DecompressPointer r1
    //     0x7af12c: add             x1, x1, HEAP, lsl #32
    // 0x7af130: ldr             x2, [fp, #0x18]
    // 0x7af134: stur            x1, [fp, #-8]
    // 0x7af138: LoadField: r3 = r2->field_b
    //     0x7af138: ldur            w3, [x2, #0xb]
    // 0x7af13c: DecompressPointer r3
    //     0x7af13c: add             x3, x3, HEAP, lsl #32
    // 0x7af140: cmp             w3, NULL
    // 0x7af144: b.eq            #0x7af26c
    // 0x7af148: LoadField: r4 = r3->field_2b
    //     0x7af148: ldur            w4, [x3, #0x2b]
    // 0x7af14c: DecompressPointer r4
    //     0x7af14c: add             x4, x4, HEAP, lsl #32
    // 0x7af150: cmp             w1, w4
    // 0x7af154: b.eq            #0x7af218
    // 0x7af158: r1 = 1
    //     0x7af158: mov             x1, #1
    // 0x7af15c: r0 = AllocateContext()
    //     0x7af15c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7af160: mov             x1, x0
    // 0x7af164: ldr             x0, [fp, #0x18]
    // 0x7af168: StoreField: r1->field_f = r0
    //     0x7af168: stur            w0, [x1, #0xf]
    // 0x7af16c: mov             x2, x1
    // 0x7af170: r1 = Function '_determineMagnifierPositionAndFocalPoint@604348274':.
    //     0x7af170: add             x1, PP, #0x40, lsl #12  ; [pp+0x40488] AnonymousClosure: (0x7af274), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7af2bc)
    //     0x7af174: ldr             x1, [x1, #0x488]
    // 0x7af178: r0 = AllocateClosure()
    //     0x7af178: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7af17c: mov             x1, x0
    // 0x7af180: ldur            x0, [fp, #-8]
    // 0x7af184: r2 = LoadClassIdInstr(r0)
    //     0x7af184: ldur            x2, [x0, #-1]
    //     0x7af188: ubfx            x2, x2, #0xc, #0x14
    // 0x7af18c: stp             x1, x0, [SP, #-0x10]!
    // 0x7af190: mov             x0, x2
    // 0x7af194: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0x7af194: mov             x17, #0xc2d6
    //     0x7af198: add             lr, x0, x17
    //     0x7af19c: ldr             lr, [x21, lr, lsl #3]
    //     0x7af1a0: blr             lr
    // 0x7af1a4: add             SP, SP, #0x10
    // 0x7af1a8: ldr             x0, [fp, #0x18]
    // 0x7af1ac: LoadField: r1 = r0->field_b
    //     0x7af1ac: ldur            w1, [x0, #0xb]
    // 0x7af1b0: DecompressPointer r1
    //     0x7af1b0: add             x1, x1, HEAP, lsl #32
    // 0x7af1b4: cmp             w1, NULL
    // 0x7af1b8: b.eq            #0x7af270
    // 0x7af1bc: LoadField: r2 = r1->field_2b
    //     0x7af1bc: ldur            w2, [x1, #0x2b]
    // 0x7af1c0: DecompressPointer r2
    //     0x7af1c0: add             x2, x2, HEAP, lsl #32
    // 0x7af1c4: stur            x2, [fp, #-8]
    // 0x7af1c8: r1 = 1
    //     0x7af1c8: mov             x1, #1
    // 0x7af1cc: r0 = AllocateContext()
    //     0x7af1cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7af1d0: mov             x1, x0
    // 0x7af1d4: ldr             x0, [fp, #0x18]
    // 0x7af1d8: StoreField: r1->field_f = r0
    //     0x7af1d8: stur            w0, [x1, #0xf]
    // 0x7af1dc: mov             x2, x1
    // 0x7af1e0: r1 = Function '_determineMagnifierPositionAndFocalPoint@604348274':.
    //     0x7af1e0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40488] AnonymousClosure: (0x7af274), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7af2bc)
    //     0x7af1e4: ldr             x1, [x1, #0x488]
    // 0x7af1e8: r0 = AllocateClosure()
    //     0x7af1e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7af1ec: mov             x1, x0
    // 0x7af1f0: ldur            x0, [fp, #-8]
    // 0x7af1f4: r2 = LoadClassIdInstr(r0)
    //     0x7af1f4: ldur            x2, [x0, #-1]
    //     0x7af1f8: ubfx            x2, x2, #0xc, #0x14
    // 0x7af1fc: stp             x1, x0, [SP, #-0x10]!
    // 0x7af200: mov             x0, x2
    // 0x7af204: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x7af204: mov             x17, #0xc3ab
    //     0x7af208: add             lr, x0, x17
    //     0x7af20c: ldr             lr, [x21, lr, lsl #3]
    //     0x7af210: blr             lr
    // 0x7af214: add             SP, SP, #0x10
    // 0x7af218: ldr             x0, [fp, #0x18]
    // 0x7af21c: LoadField: r2 = r0->field_7
    //     0x7af21c: ldur            w2, [x0, #7]
    // 0x7af220: DecompressPointer r2
    //     0x7af220: add             x2, x2, HEAP, lsl #32
    // 0x7af224: ldr             x0, [fp, #0x10]
    // 0x7af228: r1 = Null
    //     0x7af228: mov             x1, NULL
    // 0x7af22c: cmp             w2, NULL
    // 0x7af230: b.eq            #0x7af254
    // 0x7af234: LoadField: r4 = r2->field_17
    //     0x7af234: ldur            w4, [x2, #0x17]
    // 0x7af238: DecompressPointer r4
    //     0x7af238: add             x4, x4, HEAP, lsl #32
    // 0x7af23c: r8 = X0 bound StatefulWidget
    //     0x7af23c: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7af240: ldr             x8, [x8, #0x858]
    // 0x7af244: LoadField: r9 = r4->field_7
    //     0x7af244: ldur            x9, [x4, #7]
    // 0x7af248: r3 = Null
    //     0x7af248: add             x3, PP, #0x40, lsl #12  ; [pp+0x40490] Null
    //     0x7af24c: ldr             x3, [x3, #0x490]
    // 0x7af250: blr             x9
    // 0x7af254: r0 = Null
    //     0x7af254: mov             x0, NULL
    // 0x7af258: LeaveFrame
    //     0x7af258: mov             SP, fp
    //     0x7af25c: ldp             fp, lr, [SP], #0x10
    // 0x7af260: ret
    //     0x7af260: ret             
    // 0x7af264: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7af264: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7af268: b               #0x7af0e8
    // 0x7af26c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af26c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7af270: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af270: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _determineMagnifierPositionAndFocalPoint(dynamic) {
    // ** addr: 0x7af274, size: 0x48
    // 0x7af274: EnterFrame
    //     0x7af274: stp             fp, lr, [SP, #-0x10]!
    //     0x7af278: mov             fp, SP
    // 0x7af27c: ldr             x0, [fp, #0x10]
    // 0x7af280: LoadField: r1 = r0->field_17
    //     0x7af280: ldur            w1, [x0, #0x17]
    // 0x7af284: DecompressPointer r1
    //     0x7af284: add             x1, x1, HEAP, lsl #32
    // 0x7af288: CheckStackOverflow
    //     0x7af288: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7af28c: cmp             SP, x16
    //     0x7af290: b.ls            #0x7af2b4
    // 0x7af294: LoadField: r0 = r1->field_f
    //     0x7af294: ldur            w0, [x1, #0xf]
    // 0x7af298: DecompressPointer r0
    //     0x7af298: add             x0, x0, HEAP, lsl #32
    // 0x7af29c: SaveReg r0
    //     0x7af29c: str             x0, [SP, #-8]!
    // 0x7af2a0: r0 = _determineMagnifierPositionAndFocalPoint()
    //     0x7af2a0: bl              #0x7af2bc  ; [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint
    // 0x7af2a4: add             SP, SP, #8
    // 0x7af2a8: LeaveFrame
    //     0x7af2a8: mov             SP, fp
    //     0x7af2ac: ldp             fp, lr, [SP], #0x10
    // 0x7af2b0: ret
    //     0x7af2b0: ret             
    // 0x7af2b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7af2b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7af2b8: b               #0x7af294
  }
  _ _determineMagnifierPositionAndFocalPoint(/* No info */) {
    // ** addr: 0x7af2bc, size: 0x44c
    // 0x7af2bc: EnterFrame
    //     0x7af2bc: stp             fp, lr, [SP, #-0x10]!
    //     0x7af2c0: mov             fp, SP
    // 0x7af2c4: AllocStack(0x38)
    //     0x7af2c4: sub             SP, SP, #0x38
    // 0x7af2c8: CheckStackOverflow
    //     0x7af2c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7af2cc: cmp             SP, x16
    //     0x7af2d0: b.ls            #0x7af6a4
    // 0x7af2d4: r1 = 4
    //     0x7af2d4: mov             x1, #4
    // 0x7af2d8: r0 = AllocateContext()
    //     0x7af2d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7af2dc: mov             x1, x0
    // 0x7af2e0: ldr             x0, [fp, #0x10]
    // 0x7af2e4: stur            x1, [fp, #-0x10]
    // 0x7af2e8: StoreField: r1->field_f = r0
    //     0x7af2e8: stur            w0, [x1, #0xf]
    // 0x7af2ec: LoadField: r2 = r0->field_b
    //     0x7af2ec: ldur            w2, [x0, #0xb]
    // 0x7af2f0: DecompressPointer r2
    //     0x7af2f0: add             x2, x2, HEAP, lsl #32
    // 0x7af2f4: cmp             w2, NULL
    // 0x7af2f8: b.eq            #0x7af6ac
    // 0x7af2fc: LoadField: r3 = r2->field_2b
    //     0x7af2fc: ldur            w3, [x2, #0x2b]
    // 0x7af300: DecompressPointer r3
    //     0x7af300: add             x3, x3, HEAP, lsl #32
    // 0x7af304: LoadField: r2 = r3->field_27
    //     0x7af304: ldur            w2, [x3, #0x27]
    // 0x7af308: DecompressPointer r2
    //     0x7af308: add             x2, x2, HEAP, lsl #32
    // 0x7af30c: stur            x2, [fp, #-8]
    // 0x7af310: LoadField: r3 = r2->field_f
    //     0x7af310: ldur            w3, [x2, #0xf]
    // 0x7af314: DecompressPointer r3
    //     0x7af314: add             x3, x3, HEAP, lsl #32
    // 0x7af318: SaveReg r3
    //     0x7af318: str             x3, [SP, #-8]!
    // 0x7af31c: r0 = center()
    //     0x7af31c: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x7af320: add             SP, SP, #8
    // 0x7af324: LoadField: d0 = r0->field_f
    //     0x7af324: ldur            d0, [x0, #0xf]
    // 0x7af328: stur            d0, [fp, #-0x28]
    // 0x7af32c: r0 = inline_Allocate_Double()
    //     0x7af32c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x7af330: add             x0, x0, #0x10
    //     0x7af334: cmp             x1, x0
    //     0x7af338: b.ls            #0x7af6b0
    //     0x7af33c: str             x0, [THR, #0x60]  ; THR::top
    //     0x7af340: sub             x0, x0, #0xf
    //     0x7af344: mov             x1, #0xd108
    //     0x7af348: movk            x1, #3, lsl #16
    //     0x7af34c: stur            x1, [x0, #-1]
    // 0x7af350: StoreField: r0->field_7 = d0
    //     0x7af350: stur            d0, [x0, #7]
    // 0x7af354: ldur            x2, [fp, #-0x10]
    // 0x7af358: StoreField: r2->field_13 = r0
    //     0x7af358: stur            w0, [x2, #0x13]
    //     0x7af35c: ldurb           w16, [x2, #-1]
    //     0x7af360: ldurb           w17, [x0, #-1]
    //     0x7af364: and             x16, x17, x16, lsr #2
    //     0x7af368: tst             x16, HEAP, lsr #32
    //     0x7af36c: b.eq            #0x7af374
    //     0x7af370: bl              #0xd6828c
    // 0x7af374: ldur            x0, [fp, #-8]
    // 0x7af378: LoadField: r1 = r0->field_7
    //     0x7af378: ldur            w1, [x0, #7]
    // 0x7af37c: DecompressPointer r1
    //     0x7af37c: add             x1, x1, HEAP, lsl #32
    // 0x7af380: stur            x1, [fp, #-0x18]
    // 0x7af384: LoadField: d1 = r1->field_f
    //     0x7af384: ldur            d1, [x1, #0xf]
    // 0x7af388: fsub            d2, d0, d1
    // 0x7af38c: ldr             x0, [fp, #0x10]
    // 0x7af390: stur            d2, [fp, #-0x20]
    // 0x7af394: LoadField: r3 = r0->field_b
    //     0x7af394: ldur            w3, [x0, #0xb]
    // 0x7af398: DecompressPointer r3
    //     0x7af398: add             x3, x3, HEAP, lsl #32
    // 0x7af39c: cmp             w3, NULL
    // 0x7af3a0: b.eq            #0x7af6c0
    // 0x7af3a4: d1 = 48.000000
    //     0x7af3a4: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0x7af3a8: ldr             d1, [x17, #0xbd0]
    // 0x7af3ac: fneg            d3, d1
    // 0x7af3b0: fcmp            d2, d3
    // 0x7af3b4: b.vs            #0x7af418
    // 0x7af3b8: b.ge            #0x7af418
    // 0x7af3bc: LoadField: r1 = r3->field_f
    //     0x7af3bc: ldur            w1, [x3, #0xf]
    // 0x7af3c0: DecompressPointer r1
    //     0x7af3c0: add             x1, x1, HEAP, lsl #32
    // 0x7af3c4: SaveReg r1
    //     0x7af3c4: str             x1, [SP, #-8]!
    // 0x7af3c8: r0 = shown()
    //     0x7af3c8: bl              #0x7af9c0  ; [package:flutter/src/widgets/magnifier.dart] MagnifierController::shown
    // 0x7af3cc: add             SP, SP, #8
    // 0x7af3d0: tbnz            w0, #4, #0x7af408
    // 0x7af3d4: ldr             x0, [fp, #0x10]
    // 0x7af3d8: LoadField: r1 = r0->field_b
    //     0x7af3d8: ldur            w1, [x0, #0xb]
    // 0x7af3dc: DecompressPointer r1
    //     0x7af3dc: add             x1, x1, HEAP, lsl #32
    // 0x7af3e0: cmp             w1, NULL
    // 0x7af3e4: b.eq            #0x7af6c4
    // 0x7af3e8: LoadField: r0 = r1->field_f
    //     0x7af3e8: ldur            w0, [x1, #0xf]
    // 0x7af3ec: DecompressPointer r0
    //     0x7af3ec: add             x0, x0, HEAP, lsl #32
    // 0x7af3f0: r16 = false
    //     0x7af3f0: add             x16, NULL, #0x30  ; false
    // 0x7af3f4: stp             x16, x0, [SP, #-0x10]!
    // 0x7af3f8: r4 = const [0, 0x2, 0x2, 0x1, removeFromOverlay, 0x1, null]
    //     0x7af3f8: add             x4, PP, #0x40, lsl #12  ; [pp+0x40448] List(7) [0, 0x2, 0x2, 0x1, "removeFromOverlay", 0x1, Null]
    //     0x7af3fc: ldr             x4, [x4, #0x448]
    // 0x7af400: r0 = hide()
    //     0x7af400: bl              #0x7af87c  ; [package:flutter/src/widgets/magnifier.dart] MagnifierController::hide
    // 0x7af404: add             SP, SP, #0x10
    // 0x7af408: r0 = Null
    //     0x7af408: mov             x0, NULL
    // 0x7af40c: LeaveFrame
    //     0x7af40c: mov             SP, fp
    //     0x7af410: ldp             fp, lr, [SP], #0x10
    // 0x7af414: ret
    //     0x7af414: ret             
    // 0x7af418: LoadField: r4 = r3->field_f
    //     0x7af418: ldur            w4, [x3, #0xf]
    // 0x7af41c: DecompressPointer r4
    //     0x7af41c: add             x4, x4, HEAP, lsl #32
    // 0x7af420: SaveReg r4
    //     0x7af420: str             x4, [SP, #-8]!
    // 0x7af424: r0 = shown()
    //     0x7af424: bl              #0x7af9c0  ; [package:flutter/src/widgets/magnifier.dart] MagnifierController::shown
    // 0x7af428: add             SP, SP, #8
    // 0x7af42c: tbz             w0, #4, #0x7af458
    // 0x7af430: ldr             x0, [fp, #0x10]
    // 0x7af434: LoadField: r1 = r0->field_27
    //     0x7af434: ldur            w1, [x0, #0x27]
    // 0x7af438: DecompressPointer r1
    //     0x7af438: add             x1, x1, HEAP, lsl #32
    // 0x7af43c: r16 = Sentinel
    //     0x7af43c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7af440: cmp             w1, w16
    // 0x7af444: b.eq            #0x7af6c8
    // 0x7af448: SaveReg r1
    //     0x7af448: str             x1, [SP, #-8]!
    // 0x7af44c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7af44c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7af450: r0 = forward()
    //     0x7af450: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7af454: add             SP, SP, #8
    // 0x7af458: ldr             x1, [fp, #0x10]
    // 0x7af45c: ldur            d1, [fp, #-0x20]
    // 0x7af460: ldur            d0, [fp, #-0x28]
    // 0x7af464: d2 = 10.000000
    //     0x7af464: fmov            d2, #10.00000000
    // 0x7af468: LoadField: r0 = r1->field_b
    //     0x7af468: ldur            w0, [x1, #0xb]
    // 0x7af46c: DecompressPointer r0
    //     0x7af46c: add             x0, x0, HEAP, lsl #32
    // 0x7af470: cmp             w0, NULL
    // 0x7af474: b.eq            #0x7af6d4
    // 0x7af478: fdiv            d3, d1, d2
    // 0x7af47c: fsub            d1, d0, d3
    // 0x7af480: fcmp            d0, d1
    // 0x7af484: b.vs            #0x7af494
    // 0x7af488: b.le            #0x7af494
    // 0x7af48c: mov             v3.16b, v0.16b
    // 0x7af490: b               #0x7af4d4
    // 0x7af494: fcmp            d0, d1
    // 0x7af498: b.vs            #0x7af4a8
    // 0x7af49c: b.ge            #0x7af4a8
    // 0x7af4a0: mov             v3.16b, v1.16b
    // 0x7af4a4: b               #0x7af4d4
    // 0x7af4a8: d3 = 0.000000
    //     0x7af4a8: eor             v3.16b, v3.16b, v3.16b
    // 0x7af4ac: fcmp            d0, d3
    // 0x7af4b0: b.vs            #0x7af4c0
    // 0x7af4b4: b.ne            #0x7af4c0
    // 0x7af4b8: fadd            d3, d0, d1
    // 0x7af4bc: b               #0x7af4d4
    // 0x7af4c0: fcmp            d1, d1
    // 0x7af4c4: b.vc            #0x7af4d0
    // 0x7af4c8: mov             v3.16b, v1.16b
    // 0x7af4cc: b               #0x7af4d4
    // 0x7af4d0: mov             v3.16b, v0.16b
    // 0x7af4d4: ldur            x2, [fp, #-0x10]
    // 0x7af4d8: ldur            x3, [fp, #-0x18]
    // 0x7af4dc: d1 = 40.000000
    //     0x7af4dc: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fdc0] IMM: double(40) from 0x4044000000000000
    //     0x7af4e0: ldr             d1, [x17, #0xdc0]
    // 0x7af4e4: d0 = 73.500000
    //     0x7af4e4: add             x17, PP, #0x40, lsl #12  ; [pp+0x40450] IMM: double(73.5) from 0x4052600000000000
    //     0x7af4e8: ldr             d0, [x17, #0x450]
    // 0x7af4ec: r0 = inline_Allocate_Double()
    //     0x7af4ec: ldp             x0, x4, [THR, #0x60]  ; THR::top
    //     0x7af4f0: add             x0, x0, #0x10
    //     0x7af4f4: cmp             x4, x0
    //     0x7af4f8: b.ls            #0x7af6d8
    //     0x7af4fc: str             x0, [THR, #0x60]  ; THR::top
    //     0x7af500: sub             x0, x0, #0xf
    //     0x7af504: mov             x4, #0xd108
    //     0x7af508: movk            x4, #3, lsl #16
    //     0x7af50c: stur            x4, [x0, #-1]
    // 0x7af510: StoreField: r0->field_7 = d3
    //     0x7af510: stur            d3, [x0, #7]
    // 0x7af514: StoreField: r2->field_17 = r0
    //     0x7af514: stur            w0, [x2, #0x17]
    //     0x7af518: ldurb           w16, [x2, #-1]
    //     0x7af51c: ldurb           w17, [x0, #-1]
    //     0x7af520: and             x16, x17, x16, lsr #2
    //     0x7af524: tst             x16, HEAP, lsr #32
    //     0x7af528: b.eq            #0x7af530
    //     0x7af52c: bl              #0xd6828c
    // 0x7af530: LoadField: d4 = r3->field_7
    //     0x7af530: ldur            d4, [x3, #7]
    // 0x7af534: fsub            d5, d4, d1
    // 0x7af538: stur            d5, [fp, #-0x28]
    // 0x7af53c: fsub            d1, d3, d0
    // 0x7af540: stur            d1, [fp, #-0x20]
    // 0x7af544: r0 = Offset()
    //     0x7af544: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7af548: ldur            d0, [fp, #-0x28]
    // 0x7af54c: stur            x0, [fp, #-8]
    // 0x7af550: StoreField: r0->field_7 = d0
    //     0x7af550: stur            d0, [x0, #7]
    // 0x7af554: ldur            d0, [fp, #-0x20]
    // 0x7af558: StoreField: r0->field_f = d0
    //     0x7af558: stur            d0, [x0, #0xf]
    // 0x7af55c: ldr             x1, [fp, #0x10]
    // 0x7af560: LoadField: r2 = r1->field_f
    //     0x7af560: ldur            w2, [x1, #0xf]
    // 0x7af564: DecompressPointer r2
    //     0x7af564: add             x2, x2, HEAP, lsl #32
    // 0x7af568: cmp             w2, NULL
    // 0x7af56c: b.eq            #0x7af700
    // 0x7af570: SaveReg r2
    //     0x7af570: str             x2, [SP, #-8]!
    // 0x7af574: r0 = of()
    //     0x7af574: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x7af578: add             SP, SP, #8
    // 0x7af57c: LoadField: r1 = r0->field_7
    //     0x7af57c: ldur            w1, [x0, #7]
    // 0x7af580: DecompressPointer r1
    //     0x7af580: add             x1, x1, HEAP, lsl #32
    // 0x7af584: r16 = Instance_Offset
    //     0x7af584: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x7af588: stp             x1, x16, [SP, #-0x10]!
    // 0x7af58c: r0 = &()
    //     0x7af58c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x7af590: add             SP, SP, #0x10
    // 0x7af594: LoadField: d0 = r0->field_7
    //     0x7af594: ldur            d0, [x0, #7]
    // 0x7af598: ldr             x1, [fp, #0x10]
    // 0x7af59c: LoadField: r2 = r1->field_b
    //     0x7af59c: ldur            w2, [x1, #0xb]
    // 0x7af5a0: DecompressPointer r2
    //     0x7af5a0: add             x2, x2, HEAP, lsl #32
    // 0x7af5a4: cmp             w2, NULL
    // 0x7af5a8: b.eq            #0x7af704
    // 0x7af5ac: d1 = 10.000000
    //     0x7af5ac: fmov            d1, #10.00000000
    // 0x7af5b0: fadd            d2, d0, d1
    // 0x7af5b4: stur            d2, [fp, #-0x38]
    // 0x7af5b8: LoadField: d0 = r0->field_f
    //     0x7af5b8: ldur            d0, [x0, #0xf]
    // 0x7af5bc: d3 = 21.500000
    //     0x7af5bc: add             x17, PP, #0x40, lsl #12  ; [pp+0x40458] IMM: double(21.5) from 0x4035800000000000
    //     0x7af5c0: ldr             d3, [x17, #0x458]
    // 0x7af5c4: fsub            d4, d0, d3
    // 0x7af5c8: stur            d4, [fp, #-0x30]
    // 0x7af5cc: LoadField: d0 = r0->field_17
    //     0x7af5cc: ldur            d0, [x0, #0x17]
    // 0x7af5d0: fsub            d5, d0, d1
    // 0x7af5d4: stur            d5, [fp, #-0x28]
    // 0x7af5d8: LoadField: d0 = r0->field_1f
    //     0x7af5d8: ldur            d0, [x0, #0x1f]
    // 0x7af5dc: fadd            d1, d0, d3
    // 0x7af5e0: stur            d1, [fp, #-0x20]
    // 0x7af5e4: r0 = Rect()
    //     0x7af5e4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x7af5e8: ldur            d0, [fp, #-0x38]
    // 0x7af5ec: stur            x0, [fp, #-0x18]
    // 0x7af5f0: StoreField: r0->field_7 = d0
    //     0x7af5f0: stur            d0, [x0, #7]
    // 0x7af5f4: ldur            d0, [fp, #-0x30]
    // 0x7af5f8: StoreField: r0->field_f = d0
    //     0x7af5f8: stur            d0, [x0, #0xf]
    // 0x7af5fc: ldur            d0, [fp, #-0x28]
    // 0x7af600: StoreField: r0->field_17 = d0
    //     0x7af600: stur            d0, [x0, #0x17]
    // 0x7af604: ldur            d0, [fp, #-0x20]
    // 0x7af608: StoreField: r0->field_1f = d0
    //     0x7af608: stur            d0, [x0, #0x1f]
    // 0x7af60c: ldur            x16, [fp, #-8]
    // 0x7af610: r30 = Instance_Size
    //     0x7af610: add             lr, PP, #0x40, lsl #12  ; [pp+0x40418] Obj!Size@b5ecd1
    //     0x7af614: ldr             lr, [lr, #0x418]
    // 0x7af618: stp             lr, x16, [SP, #-0x10]!
    // 0x7af61c: r0 = &()
    //     0x7af61c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x7af620: add             SP, SP, #0x10
    // 0x7af624: ldur            x16, [fp, #-0x18]
    // 0x7af628: stp             x0, x16, [SP, #-0x10]!
    // 0x7af62c: r0 = shiftWithinBounds()
    //     0x7af62c: bl              #0x7af708  ; [package:flutter/src/widgets/magnifier.dart] MagnifierController::shiftWithinBounds
    // 0x7af630: add             SP, SP, #0x10
    // 0x7af634: LoadField: d0 = r0->field_7
    //     0x7af634: ldur            d0, [x0, #7]
    // 0x7af638: stur            d0, [fp, #-0x28]
    // 0x7af63c: LoadField: d1 = r0->field_f
    //     0x7af63c: ldur            d1, [x0, #0xf]
    // 0x7af640: stur            d1, [fp, #-0x20]
    // 0x7af644: r0 = Offset()
    //     0x7af644: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7af648: ldur            d0, [fp, #-0x28]
    // 0x7af64c: StoreField: r0->field_7 = d0
    //     0x7af64c: stur            d0, [x0, #7]
    // 0x7af650: ldur            d0, [fp, #-0x20]
    // 0x7af654: StoreField: r0->field_f = d0
    //     0x7af654: stur            d0, [x0, #0xf]
    // 0x7af658: ldur            x2, [fp, #-0x10]
    // 0x7af65c: StoreField: r2->field_1b = r0
    //     0x7af65c: stur            w0, [x2, #0x1b]
    //     0x7af660: ldurb           w16, [x2, #-1]
    //     0x7af664: ldurb           w17, [x0, #-1]
    //     0x7af668: and             x16, x17, x16, lsr #2
    //     0x7af66c: tst             x16, HEAP, lsr #32
    //     0x7af670: b.eq            #0x7af678
    //     0x7af674: bl              #0xd6828c
    // 0x7af678: r1 = Function '<anonymous closure>':.
    //     0x7af678: add             x1, PP, #0x40, lsl #12  ; [pp+0x40460] AnonymousClosure: (0x7afa6c), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7af2bc)
    //     0x7af67c: ldr             x1, [x1, #0x460]
    // 0x7af680: r0 = AllocateClosure()
    //     0x7af680: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7af684: ldr             x16, [fp, #0x10]
    // 0x7af688: stp             x0, x16, [SP, #-0x10]!
    // 0x7af68c: r0 = setState()
    //     0x7af68c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7af690: add             SP, SP, #0x10
    // 0x7af694: r0 = Null
    //     0x7af694: mov             x0, NULL
    // 0x7af698: LeaveFrame
    //     0x7af698: mov             SP, fp
    //     0x7af69c: ldp             fp, lr, [SP], #0x10
    // 0x7af6a0: ret
    //     0x7af6a0: ret             
    // 0x7af6a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7af6a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7af6a8: b               #0x7af2d4
    // 0x7af6ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af6ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7af6b0: SaveReg d0
    //     0x7af6b0: str             q0, [SP, #-0x10]!
    // 0x7af6b4: r0 = AllocateDouble()
    //     0x7af6b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7af6b8: RestoreReg d0
    //     0x7af6b8: ldr             q0, [SP], #0x10
    // 0x7af6bc: b               #0x7af350
    // 0x7af6c0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7af6c0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7af6c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af6c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7af6c8: r9 = _ioAnimationController
    //     0x7af6c8: add             x9, PP, #0x40, lsl #12  ; [pp+0x40468] Field <_CupertinoTextMagnifierState@604348274._ioAnimationController@604348274>: late (offset: 0x28)
    //     0x7af6cc: ldr             x9, [x9, #0x468]
    // 0x7af6d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7af6d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7af6d4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7af6d4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x7af6d8: stp             q2, q3, [SP, #-0x20]!
    // 0x7af6dc: stp             q0, q1, [SP, #-0x20]!
    // 0x7af6e0: stp             x2, x3, [SP, #-0x10]!
    // 0x7af6e4: SaveReg r1
    //     0x7af6e4: str             x1, [SP, #-8]!
    // 0x7af6e8: r0 = AllocateDouble()
    //     0x7af6e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7af6ec: RestoreReg r1
    //     0x7af6ec: ldr             x1, [SP], #8
    // 0x7af6f0: ldp             x2, x3, [SP], #0x10
    // 0x7af6f4: ldp             q0, q1, [SP], #0x20
    // 0x7af6f8: ldp             q2, q3, [SP], #0x20
    // 0x7af6fc: b               #0x7af510
    // 0x7af700: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af700: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7af704: r0 = NullCastErrorSharedWithFPURegs()
    //     0x7af704: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7afa6c, size: 0x88
    // 0x7afa6c: EnterFrame
    //     0x7afa6c: stp             fp, lr, [SP, #-0x10]!
    //     0x7afa70: mov             fp, SP
    // 0x7afa74: ldr             x1, [fp, #0x10]
    // 0x7afa78: LoadField: r2 = r1->field_17
    //     0x7afa78: ldur            w2, [x1, #0x17]
    // 0x7afa7c: DecompressPointer r2
    //     0x7afa7c: add             x2, x2, HEAP, lsl #32
    // 0x7afa80: LoadField: r1 = r2->field_f
    //     0x7afa80: ldur            w1, [x2, #0xf]
    // 0x7afa84: DecompressPointer r1
    //     0x7afa84: add             x1, x1, HEAP, lsl #32
    // 0x7afa88: LoadField: r0 = r2->field_1b
    //     0x7afa88: ldur            w0, [x2, #0x1b]
    // 0x7afa8c: DecompressPointer r0
    //     0x7afa8c: add             x0, x0, HEAP, lsl #32
    // 0x7afa90: StoreField: r1->field_1b = r0
    //     0x7afa90: stur            w0, [x1, #0x1b]
    //     0x7afa94: ldurb           w16, [x1, #-1]
    //     0x7afa98: ldurb           w17, [x0, #-1]
    //     0x7afa9c: and             x16, x17, x16, lsr #2
    //     0x7afaa0: tst             x16, HEAP, lsr #32
    //     0x7afaa4: b.eq            #0x7afaac
    //     0x7afaa8: bl              #0xd6826c
    // 0x7afaac: LoadField: r3 = r2->field_13
    //     0x7afaac: ldur            w3, [x2, #0x13]
    // 0x7afab0: DecompressPointer r3
    //     0x7afab0: add             x3, x3, HEAP, lsl #32
    // 0x7afab4: LoadField: r4 = r2->field_17
    //     0x7afab4: ldur            w4, [x2, #0x17]
    // 0x7afab8: DecompressPointer r4
    //     0x7afab8: add             x4, x4, HEAP, lsl #32
    // 0x7afabc: cmp             w3, NULL
    // 0x7afac0: b.eq            #0x7afaec
    // 0x7afac4: cmp             w4, NULL
    // 0x7afac8: b.eq            #0x7afaf0
    // 0x7afacc: LoadField: d0 = r3->field_7
    //     0x7afacc: ldur            d0, [x3, #7]
    // 0x7afad0: LoadField: d1 = r4->field_7
    //     0x7afad0: ldur            d1, [x4, #7]
    // 0x7afad4: fsub            d2, d0, d1
    // 0x7afad8: StoreField: r1->field_1f = d2
    //     0x7afad8: stur            d2, [x1, #0x1f]
    // 0x7afadc: r0 = Null
    //     0x7afadc: mov             x0, NULL
    // 0x7afae0: LeaveFrame
    //     0x7afae0: mov             SP, fp
    //     0x7afae4: ldp             fp, lr, [SP], #0x10
    // 0x7afae8: ret
    //     0x7afae8: ret             
    // 0x7afaec: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7afaec: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x7afaf0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7afaf0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x84108c, size: 0x194
    // 0x84108c: EnterFrame
    //     0x84108c: stp             fp, lr, [SP, #-0x10]!
    //     0x841090: mov             fp, SP
    // 0x841094: AllocStack(0x30)
    //     0x841094: sub             SP, SP, #0x30
    // 0x841098: ldr             x0, [fp, #0x18]
    // 0x84109c: LoadField: r1 = r0->field_b
    //     0x84109c: ldur            w1, [x0, #0xb]
    // 0x8410a0: DecompressPointer r1
    //     0x8410a0: add             x1, x1, HEAP, lsl #32
    // 0x8410a4: cmp             w1, NULL
    // 0x8410a8: b.eq            #0x8411d8
    // 0x8410ac: LoadField: r1 = r0->field_1b
    //     0x8410ac: ldur            w1, [x0, #0x1b]
    // 0x8410b0: DecompressPointer r1
    //     0x8410b0: add             x1, x1, HEAP, lsl #32
    // 0x8410b4: LoadField: d0 = r1->field_7
    //     0x8410b4: ldur            d0, [x1, #7]
    // 0x8410b8: stur            d0, [fp, #-0x30]
    // 0x8410bc: LoadField: d1 = r1->field_f
    //     0x8410bc: ldur            d1, [x1, #0xf]
    // 0x8410c0: stur            d1, [fp, #-0x28]
    // 0x8410c4: LoadField: r1 = r0->field_2b
    //     0x8410c4: ldur            w1, [x0, #0x2b]
    // 0x8410c8: DecompressPointer r1
    //     0x8410c8: add             x1, x1, HEAP, lsl #32
    // 0x8410cc: r16 = Sentinel
    //     0x8410cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8410d0: cmp             w1, w16
    // 0x8410d4: b.eq            #0x8411dc
    // 0x8410d8: stur            x1, [fp, #-8]
    // 0x8410dc: LoadField: d2 = r0->field_1f
    //     0x8410dc: ldur            d2, [x0, #0x1f]
    // 0x8410e0: stur            d2, [fp, #-0x20]
    // 0x8410e4: r0 = Offset()
    //     0x8410e4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8410e8: d0 = 0.000000
    //     0x8410e8: eor             v0.16b, v0.16b, v0.16b
    // 0x8410ec: stur            x0, [fp, #-0x10]
    // 0x8410f0: StoreField: r0->field_7 = d0
    //     0x8410f0: stur            d0, [x0, #7]
    // 0x8410f4: ldur            d0, [fp, #-0x20]
    // 0x8410f8: StoreField: r0->field_f = d0
    //     0x8410f8: stur            d0, [x0, #0xf]
    // 0x8410fc: r0 = CupertinoMagnifier()
    //     0x8410fc: bl              #0x841250  ; AllocateCupertinoMagnifierStub -> CupertinoMagnifier (size=0x24)
    // 0x841100: mov             x1, x0
    // 0x841104: r0 = Instance_Size
    //     0x841104: add             x0, PP, #0x40, lsl #12  ; [pp+0x40418] Obj!Size@b5ecd1
    //     0x841108: ldr             x0, [x0, #0x418]
    // 0x84110c: stur            x1, [fp, #-0x18]
    // 0x841110: StoreField: r1->field_13 = r0
    //     0x841110: stur            w0, [x1, #0x13]
    // 0x841114: r0 = Instance_BorderRadius
    //     0x841114: add             x0, PP, #0x40, lsl #12  ; [pp+0x40420] Obj!BorderRadius@b374b1
    //     0x841118: ldr             x0, [x0, #0x420]
    // 0x84111c: StoreField: r1->field_17 = r0
    //     0x84111c: stur            w0, [x1, #0x17]
    // 0x841120: ldur            x0, [fp, #-0x10]
    // 0x841124: StoreField: r1->field_1f = r0
    //     0x841124: stur            w0, [x1, #0x1f]
    // 0x841128: r0 = const [Instance of 'BoxShadow']
    //     0x841128: add             x0, PP, #0x40, lsl #12  ; [pp+0x40428] List<BoxShadow>(1)
    //     0x84112c: ldr             x0, [x0, #0x428]
    // 0x841130: StoreField: r1->field_b = r0
    //     0x841130: stur            w0, [x1, #0xb]
    // 0x841134: r0 = Instance_BorderSide
    //     0x841134: add             x0, PP, #0x40, lsl #12  ; [pp+0x40430] Obj!BorderSide@b48471
    //     0x841138: ldr             x0, [x0, #0x430]
    // 0x84113c: StoreField: r1->field_f = r0
    //     0x84113c: stur            w0, [x1, #0xf]
    // 0x841140: ldur            x0, [fp, #-8]
    // 0x841144: StoreField: r1->field_1b = r0
    //     0x841144: stur            w0, [x1, #0x1b]
    // 0x841148: r0 = AnimatedPositioned()
    //     0x841148: bl              #0x841220  ; AllocateAnimatedPositionedStub -> AnimatedPositioned (size=0x34)
    // 0x84114c: ldur            x1, [fp, #-0x18]
    // 0x841150: StoreField: r0->field_17 = r1
    //     0x841150: stur            w1, [x0, #0x17]
    // 0x841154: ldur            d0, [fp, #-0x30]
    // 0x841158: r1 = inline_Allocate_Double()
    //     0x841158: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84115c: add             x1, x1, #0x10
    //     0x841160: cmp             x2, x1
    //     0x841164: b.ls            #0x8411e8
    //     0x841168: str             x1, [THR, #0x60]  ; THR::top
    //     0x84116c: sub             x1, x1, #0xf
    //     0x841170: mov             x2, #0xd108
    //     0x841174: movk            x2, #3, lsl #16
    //     0x841178: stur            x2, [x1, #-1]
    // 0x84117c: StoreField: r1->field_7 = d0
    //     0x84117c: stur            d0, [x1, #7]
    // 0x841180: StoreField: r0->field_1b = r1
    //     0x841180: stur            w1, [x0, #0x1b]
    // 0x841184: ldur            d0, [fp, #-0x28]
    // 0x841188: r1 = inline_Allocate_Double()
    //     0x841188: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84118c: add             x1, x1, #0x10
    //     0x841190: cmp             x2, x1
    //     0x841194: b.ls            #0x841204
    //     0x841198: str             x1, [THR, #0x60]  ; THR::top
    //     0x84119c: sub             x1, x1, #0xf
    //     0x8411a0: mov             x2, #0xd108
    //     0x8411a4: movk            x2, #3, lsl #16
    //     0x8411a8: stur            x2, [x1, #-1]
    // 0x8411ac: StoreField: r1->field_7 = d0
    //     0x8411ac: stur            d0, [x1, #7]
    // 0x8411b0: StoreField: r0->field_1f = r1
    //     0x8411b0: stur            w1, [x0, #0x1f]
    // 0x8411b4: r1 = Instance_Cubic
    //     0x8411b4: add             x1, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0x8411b8: ldr             x1, [x1, #0x970]
    // 0x8411bc: StoreField: r0->field_b = r1
    //     0x8411bc: stur            w1, [x0, #0xb]
    // 0x8411c0: r1 = Instance_Duration
    //     0x8411c0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40438] Obj!Duration@b67b91
    //     0x8411c4: ldr             x1, [x1, #0x438]
    // 0x8411c8: StoreField: r0->field_f = r1
    //     0x8411c8: stur            w1, [x0, #0xf]
    // 0x8411cc: LeaveFrame
    //     0x8411cc: mov             SP, fp
    //     0x8411d0: ldp             fp, lr, [SP], #0x10
    // 0x8411d4: ret
    //     0x8411d4: ret             
    // 0x8411d8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8411d8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8411dc: r9 = _ioAnimation
    //     0x8411dc: add             x9, PP, #0x40, lsl #12  ; [pp+0x40440] Field <_CupertinoTextMagnifierState@604348274._ioAnimation@604348274>: late (offset: 0x2c)
    //     0x8411e0: ldr             x9, [x9, #0x440]
    // 0x8411e4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x8411e4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x8411e8: SaveReg d0
    //     0x8411e8: str             q0, [SP, #-0x10]!
    // 0x8411ec: SaveReg r0
    //     0x8411ec: str             x0, [SP, #-8]!
    // 0x8411f0: r0 = AllocateDouble()
    //     0x8411f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8411f4: mov             x1, x0
    // 0x8411f8: RestoreReg r0
    //     0x8411f8: ldr             x0, [SP], #8
    // 0x8411fc: RestoreReg d0
    //     0x8411fc: ldr             q0, [SP], #0x10
    // 0x841200: b               #0x84117c
    // 0x841204: SaveReg d0
    //     0x841204: str             q0, [SP, #-0x10]!
    // 0x841208: SaveReg r0
    //     0x841208: str             x0, [SP, #-8]!
    // 0x84120c: r0 = AllocateDouble()
    //     0x84120c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x841210: mov             x1, x0
    // 0x841214: RestoreReg r0
    //     0x841214: ldr             x0, [SP], #8
    // 0x841218: RestoreReg d0
    //     0x841218: ldr             q0, [SP], #0x10
    // 0x84121c: b               #0x8411ac
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d76f4, size: 0x1fc
    // 0x9d76f4: EnterFrame
    //     0x9d76f4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d76f8: mov             fp, SP
    // 0x9d76fc: AllocStack(0x18)
    //     0x9d76fc: sub             SP, SP, #0x18
    // 0x9d7700: CheckStackOverflow
    //     0x9d7700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7704: cmp             SP, x16
    //     0x9d7708: b.ls            #0x9d78e0
    // 0x9d770c: r1 = 1
    //     0x9d770c: mov             x1, #1
    // 0x9d7710: r0 = AllocateContext()
    //     0x9d7710: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7714: mov             x2, x0
    // 0x9d7718: ldr             x0, [fp, #0x10]
    // 0x9d771c: stur            x2, [fp, #-8]
    // 0x9d7720: StoreField: r2->field_f = r0
    //     0x9d7720: stur            w0, [x2, #0xf]
    // 0x9d7724: r1 = <double>
    //     0x9d7724: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d7728: r0 = AnimationController()
    //     0x9d7728: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d772c: stur            x0, [fp, #-0x10]
    // 0x9d7730: ldr             x16, [fp, #0x10]
    // 0x9d7734: stp             x16, x0, [SP, #-0x10]!
    // 0x9d7738: r16 = 0.000000
    //     0x9d7738: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x9d773c: r30 = Instance_Duration
    //     0x9d773c: add             lr, PP, #0x20, lsl #12  ; [pp+0x20968] Obj!Duration@b67b41
    //     0x9d7740: ldr             lr, [lr, #0x968]
    // 0x9d7744: stp             lr, x16, [SP, #-0x10]!
    // 0x9d7748: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x3, value, 0x2, null]
    //     0x9d7748: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ff8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0x9d774c: ldr             x4, [x4, #0xff8]
    // 0x9d7750: r0 = AnimationController()
    //     0x9d7750: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d7754: add             SP, SP, #0x20
    // 0x9d7758: ldur            x2, [fp, #-8]
    // 0x9d775c: r1 = Function '<anonymous closure>':.
    //     0x9d775c: add             x1, PP, #0x40, lsl #12  ; [pp+0x404a0] AnonymousClosure: (0x9d78f0), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::initState (0x9d76f4)
    //     0x9d7760: ldr             x1, [x1, #0x4a0]
    // 0x9d7764: r0 = AllocateClosure()
    //     0x9d7764: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7768: ldur            x16, [fp, #-0x10]
    // 0x9d776c: stp             x0, x16, [SP, #-0x10]!
    // 0x9d7770: r0 = addActionListener()
    //     0x9d7770: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9d7774: add             SP, SP, #0x10
    // 0x9d7778: ldur            x0, [fp, #-0x10]
    // 0x9d777c: ldr             x1, [fp, #0x10]
    // 0x9d7780: StoreField: r1->field_27 = r0
    //     0x9d7780: stur            w0, [x1, #0x27]
    //     0x9d7784: ldurb           w16, [x1, #-1]
    //     0x9d7788: ldurb           w17, [x0, #-1]
    //     0x9d778c: and             x16, x17, x16, lsr #2
    //     0x9d7790: tst             x16, HEAP, lsr #32
    //     0x9d7794: b.eq            #0x9d779c
    //     0x9d7798: bl              #0xd6826c
    // 0x9d779c: LoadField: r2 = r1->field_b
    //     0x9d779c: ldur            w2, [x1, #0xb]
    // 0x9d77a0: DecompressPointer r2
    //     0x9d77a0: add             x2, x2, HEAP, lsl #32
    // 0x9d77a4: cmp             w2, NULL
    // 0x9d77a8: b.eq            #0x9d78e8
    // 0x9d77ac: LoadField: r3 = r2->field_f
    //     0x9d77ac: ldur            w3, [x2, #0xf]
    // 0x9d77b0: DecompressPointer r3
    //     0x9d77b0: add             x3, x3, HEAP, lsl #32
    // 0x9d77b4: ldur            x0, [fp, #-0x10]
    // 0x9d77b8: StoreField: r3->field_7 = r0
    //     0x9d77b8: stur            w0, [x3, #7]
    //     0x9d77bc: ldurb           w16, [x3, #-1]
    //     0x9d77c0: ldurb           w17, [x0, #-1]
    //     0x9d77c4: and             x16, x17, x16, lsr #2
    //     0x9d77c8: tst             x16, HEAP, lsr #32
    //     0x9d77cc: b.eq            #0x9d77d4
    //     0x9d77d0: bl              #0xd682ac
    // 0x9d77d4: LoadField: r0 = r2->field_2b
    //     0x9d77d4: ldur            w0, [x2, #0x2b]
    // 0x9d77d8: DecompressPointer r0
    //     0x9d77d8: add             x0, x0, HEAP, lsl #32
    // 0x9d77dc: stur            x0, [fp, #-8]
    // 0x9d77e0: r1 = 1
    //     0x9d77e0: mov             x1, #1
    // 0x9d77e4: r0 = AllocateContext()
    //     0x9d77e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d77e8: mov             x1, x0
    // 0x9d77ec: ldr             x0, [fp, #0x10]
    // 0x9d77f0: StoreField: r1->field_f = r0
    //     0x9d77f0: stur            w0, [x1, #0xf]
    // 0x9d77f4: mov             x2, x1
    // 0x9d77f8: r1 = Function '_determineMagnifierPositionAndFocalPoint@604348274':.
    //     0x9d77f8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40488] AnonymousClosure: (0x7af274), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7af2bc)
    //     0x9d77fc: ldr             x1, [x1, #0x488]
    // 0x9d7800: r0 = AllocateClosure()
    //     0x9d7800: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7804: mov             x1, x0
    // 0x9d7808: ldur            x0, [fp, #-8]
    // 0x9d780c: r2 = LoadClassIdInstr(r0)
    //     0x9d780c: ldur            x2, [x0, #-1]
    //     0x9d7810: ubfx            x2, x2, #0xc, #0x14
    // 0x9d7814: stp             x1, x0, [SP, #-0x10]!
    // 0x9d7818: mov             x0, x2
    // 0x9d781c: r0 = GDT[cid_x0 + 0xc3ab]()
    //     0x9d781c: mov             x17, #0xc3ab
    //     0x9d7820: add             lr, x0, x17
    //     0x9d7824: ldr             lr, [x21, lr, lsl #3]
    //     0x9d7828: blr             lr
    // 0x9d782c: add             SP, SP, #0x10
    // 0x9d7830: r1 = <double>
    //     0x9d7830: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d7834: r0 = Tween()
    //     0x9d7834: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x9d7838: mov             x2, x0
    // 0x9d783c: r0 = 0.000000
    //     0x9d783c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x9d7840: stur            x2, [fp, #-0x10]
    // 0x9d7844: StoreField: r2->field_b = r0
    //     0x9d7844: stur            w0, [x2, #0xb]
    // 0x9d7848: r0 = 1.000000
    //     0x9d7848: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x9d784c: StoreField: r2->field_f = r0
    //     0x9d784c: stur            w0, [x2, #0xf]
    // 0x9d7850: ldr             x0, [fp, #0x10]
    // 0x9d7854: LoadField: r3 = r0->field_27
    //     0x9d7854: ldur            w3, [x0, #0x27]
    // 0x9d7858: DecompressPointer r3
    //     0x9d7858: add             x3, x3, HEAP, lsl #32
    // 0x9d785c: stur            x3, [fp, #-8]
    // 0x9d7860: LoadField: r1 = r0->field_b
    //     0x9d7860: ldur            w1, [x0, #0xb]
    // 0x9d7864: DecompressPointer r1
    //     0x9d7864: add             x1, x1, HEAP, lsl #32
    // 0x9d7868: cmp             w1, NULL
    // 0x9d786c: b.eq            #0x9d78ec
    // 0x9d7870: r1 = <double>
    //     0x9d7870: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d7874: r0 = CurvedAnimation()
    //     0x9d7874: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9d7878: stur            x0, [fp, #-0x18]
    // 0x9d787c: r16 = Instance_Cubic
    //     0x9d787c: add             x16, PP, #0x20, lsl #12  ; [pp+0x20970] Obj!Cubic<double>@b4f3a1
    //     0x9d7880: ldr             x16, [x16, #0x970]
    // 0x9d7884: stp             x16, x0, [SP, #-0x10]!
    // 0x9d7888: ldur            x16, [fp, #-8]
    // 0x9d788c: SaveReg r16
    //     0x9d788c: str             x16, [SP, #-8]!
    // 0x9d7890: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9d7890: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9d7894: r0 = CurvedAnimation()
    //     0x9d7894: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9d7898: add             SP, SP, #0x18
    // 0x9d789c: ldur            x16, [fp, #-0x10]
    // 0x9d78a0: ldur            lr, [fp, #-0x18]
    // 0x9d78a4: stp             lr, x16, [SP, #-0x10]!
    // 0x9d78a8: r0 = animate()
    //     0x9d78a8: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d78ac: add             SP, SP, #0x10
    // 0x9d78b0: ldr             x1, [fp, #0x10]
    // 0x9d78b4: StoreField: r1->field_2b = r0
    //     0x9d78b4: stur            w0, [x1, #0x2b]
    //     0x9d78b8: ldurb           w16, [x1, #-1]
    //     0x9d78bc: ldurb           w17, [x0, #-1]
    //     0x9d78c0: and             x16, x17, x16, lsr #2
    //     0x9d78c4: tst             x16, HEAP, lsr #32
    //     0x9d78c8: b.eq            #0x9d78d0
    //     0x9d78cc: bl              #0xd6826c
    // 0x9d78d0: r0 = Null
    //     0x9d78d0: mov             x0, NULL
    // 0x9d78d4: LeaveFrame
    //     0x9d78d4: mov             SP, fp
    //     0x9d78d8: ldp             fp, lr, [SP], #0x10
    // 0x9d78dc: ret
    //     0x9d78dc: ret             
    // 0x9d78e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d78e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d78e4: b               #0x9d770c
    // 0x9d78e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d78e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d78ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d78ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9d78f0, size: 0x64
    // 0x9d78f0: EnterFrame
    //     0x9d78f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d78f4: mov             fp, SP
    // 0x9d78f8: AllocStack(0x8)
    //     0x9d78f8: sub             SP, SP, #8
    // 0x9d78fc: SetupParameters()
    //     0x9d78fc: ldr             x0, [fp, #0x10]
    //     0x9d7900: ldur            w1, [x0, #0x17]
    //     0x9d7904: add             x1, x1, HEAP, lsl #32
    // 0x9d7908: CheckStackOverflow
    //     0x9d7908: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d790c: cmp             SP, x16
    //     0x9d7910: b.ls            #0x9d794c
    // 0x9d7914: LoadField: r0 = r1->field_f
    //     0x9d7914: ldur            w0, [x1, #0xf]
    // 0x9d7918: DecompressPointer r0
    //     0x9d7918: add             x0, x0, HEAP, lsl #32
    // 0x9d791c: stur            x0, [fp, #-8]
    // 0x9d7920: r1 = Function '<anonymous closure>':.
    //     0x9d7920: add             x1, PP, #0x40, lsl #12  ; [pp+0x404a8] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x9d7924: ldr             x1, [x1, #0x4a8]
    // 0x9d7928: r2 = Null
    //     0x9d7928: mov             x2, NULL
    // 0x9d792c: r0 = AllocateClosure()
    //     0x9d792c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7930: ldur            x16, [fp, #-8]
    // 0x9d7934: stp             x0, x16, [SP, #-0x10]!
    // 0x9d7938: r0 = setState()
    //     0x9d7938: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x9d793c: add             SP, SP, #0x10
    // 0x9d7940: LeaveFrame
    //     0x9d7940: mov             SP, fp
    //     0x9d7944: ldp             fp, lr, [SP], #0x10
    // 0x9d7948: ret
    //     0x9d7948: ret             
    // 0x9d794c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d794c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7950: b               #0x9d7914
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a6a8, size: 0x18
    // 0xa4a6a8: r4 = 7
    //     0xa4a6a8: mov             x4, #7
    // 0xa4a6ac: r1 = Function 'dispose':.
    //     0xa4a6ac: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bb18] AnonymousClosure: (0xa4a6c0), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::dispose (0xa50504)
    //     0xa4a6b0: ldr             x1, [x17, #0xb18]
    // 0xa4a6b4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a6b4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a6b8: LoadField: r0 = r24->field_17
    //     0xa4a6b8: ldur            x0, [x24, #0x17]
    // 0xa4a6bc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a6c0, size: 0x48
    // 0xa4a6c0: EnterFrame
    //     0xa4a6c0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a6c4: mov             fp, SP
    // 0xa4a6c8: ldr             x0, [fp, #0x10]
    // 0xa4a6cc: LoadField: r1 = r0->field_17
    //     0xa4a6cc: ldur            w1, [x0, #0x17]
    // 0xa4a6d0: DecompressPointer r1
    //     0xa4a6d0: add             x1, x1, HEAP, lsl #32
    // 0xa4a6d4: CheckStackOverflow
    //     0xa4a6d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a6d8: cmp             SP, x16
    //     0xa4a6dc: b.ls            #0xa4a700
    // 0xa4a6e0: LoadField: r0 = r1->field_f
    //     0xa4a6e0: ldur            w0, [x1, #0xf]
    // 0xa4a6e4: DecompressPointer r0
    //     0xa4a6e4: add             x0, x0, HEAP, lsl #32
    // 0xa4a6e8: SaveReg r0
    //     0xa4a6e8: str             x0, [SP, #-8]!
    // 0xa4a6ec: r0 = dispose()
    //     0xa4a6ec: bl              #0xa50504  ; [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::dispose
    // 0xa4a6f0: add             SP, SP, #8
    // 0xa4a6f4: LeaveFrame
    //     0xa4a6f4: mov             SP, fp
    //     0xa4a6f8: ldp             fp, lr, [SP], #0x10
    // 0xa4a6fc: ret
    //     0xa4a6fc: ret             
    // 0xa4a700: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a700: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a704: b               #0xa4a6e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50504, size: 0x104
    // 0xa50504: EnterFrame
    //     0xa50504: stp             fp, lr, [SP, #-0x10]!
    //     0xa50508: mov             fp, SP
    // 0xa5050c: AllocStack(0x8)
    //     0xa5050c: sub             SP, SP, #8
    // 0xa50510: CheckStackOverflow
    //     0xa50510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50514: cmp             SP, x16
    //     0xa50518: b.ls            #0xa505ec
    // 0xa5051c: ldr             x0, [fp, #0x10]
    // 0xa50520: LoadField: r1 = r0->field_b
    //     0xa50520: ldur            w1, [x0, #0xb]
    // 0xa50524: DecompressPointer r1
    //     0xa50524: add             x1, x1, HEAP, lsl #32
    // 0xa50528: cmp             w1, NULL
    // 0xa5052c: b.eq            #0xa505f4
    // 0xa50530: LoadField: r2 = r1->field_f
    //     0xa50530: ldur            w2, [x1, #0xf]
    // 0xa50534: DecompressPointer r2
    //     0xa50534: add             x2, x2, HEAP, lsl #32
    // 0xa50538: StoreField: r2->field_7 = rNULL
    //     0xa50538: stur            NULL, [x2, #7]
    // 0xa5053c: LoadField: r1 = r0->field_27
    //     0xa5053c: ldur            w1, [x0, #0x27]
    // 0xa50540: DecompressPointer r1
    //     0xa50540: add             x1, x1, HEAP, lsl #32
    // 0xa50544: r16 = Sentinel
    //     0xa50544: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa50548: cmp             w1, w16
    // 0xa5054c: b.eq            #0xa505f8
    // 0xa50550: SaveReg r1
    //     0xa50550: str             x1, [SP, #-8]!
    // 0xa50554: r0 = dispose()
    //     0xa50554: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa50558: add             SP, SP, #8
    // 0xa5055c: ldr             x0, [fp, #0x10]
    // 0xa50560: LoadField: r1 = r0->field_b
    //     0xa50560: ldur            w1, [x0, #0xb]
    // 0xa50564: DecompressPointer r1
    //     0xa50564: add             x1, x1, HEAP, lsl #32
    // 0xa50568: cmp             w1, NULL
    // 0xa5056c: b.eq            #0xa50604
    // 0xa50570: LoadField: r2 = r1->field_2b
    //     0xa50570: ldur            w2, [x1, #0x2b]
    // 0xa50574: DecompressPointer r2
    //     0xa50574: add             x2, x2, HEAP, lsl #32
    // 0xa50578: stur            x2, [fp, #-8]
    // 0xa5057c: r1 = 1
    //     0xa5057c: mov             x1, #1
    // 0xa50580: r0 = AllocateContext()
    //     0xa50580: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50584: mov             x1, x0
    // 0xa50588: ldr             x0, [fp, #0x10]
    // 0xa5058c: StoreField: r1->field_f = r0
    //     0xa5058c: stur            w0, [x1, #0xf]
    // 0xa50590: mov             x2, x1
    // 0xa50594: r1 = Function '_determineMagnifierPositionAndFocalPoint@604348274':.
    //     0xa50594: add             x1, PP, #0x40, lsl #12  ; [pp+0x40488] AnonymousClosure: (0x7af274), in [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint (0x7af2bc)
    //     0xa50598: ldr             x1, [x1, #0x488]
    // 0xa5059c: r0 = AllocateClosure()
    //     0xa5059c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa505a0: mov             x1, x0
    // 0xa505a4: ldur            x0, [fp, #-8]
    // 0xa505a8: r2 = LoadClassIdInstr(r0)
    //     0xa505a8: ldur            x2, [x0, #-1]
    //     0xa505ac: ubfx            x2, x2, #0xc, #0x14
    // 0xa505b0: stp             x1, x0, [SP, #-0x10]!
    // 0xa505b4: mov             x0, x2
    // 0xa505b8: r0 = GDT[cid_x0 + 0xc2d6]()
    //     0xa505b8: mov             x17, #0xc2d6
    //     0xa505bc: add             lr, x0, x17
    //     0xa505c0: ldr             lr, [x21, lr, lsl #3]
    //     0xa505c4: blr             lr
    // 0xa505c8: add             SP, SP, #0x10
    // 0xa505cc: ldr             x16, [fp, #0x10]
    // 0xa505d0: SaveReg r16
    //     0xa505d0: str             x16, [SP, #-8]!
    // 0xa505d4: r0 = dispose()
    //     0xa505d4: bl              #0xa50608  ; [package:flutter/src/cupertino/magnifier.dart] __CupertinoTextMagnifierState&State&SingleTickerProviderStateMixin::dispose
    // 0xa505d8: add             SP, SP, #8
    // 0xa505dc: r0 = Null
    //     0xa505dc: mov             x0, NULL
    // 0xa505e0: LeaveFrame
    //     0xa505e0: mov             SP, fp
    //     0xa505e4: ldp             fp, lr, [SP], #0x10
    // 0xa505e8: ret
    //     0xa505e8: ret             
    // 0xa505ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa505ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa505f0: b               #0xa5051c
    // 0xa505f4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa505f4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa505f8: r9 = _ioAnimationController
    //     0xa505f8: add             x9, PP, #0x40, lsl #12  ; [pp+0x40468] Field <_CupertinoTextMagnifierState@604348274._ioAnimationController@604348274>: late (offset: 0x28)
    //     0xa505fc: ldr             x9, [x9, #0x468]
    // 0xa50600: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa50600: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa50604: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa50604: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ didChangeDependencies(/* No info */) {
    // ** addr: 0xa60df0, size: 0x3c
    // 0xa60df0: EnterFrame
    //     0xa60df0: stp             fp, lr, [SP, #-0x10]!
    //     0xa60df4: mov             fp, SP
    // 0xa60df8: CheckStackOverflow
    //     0xa60df8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa60dfc: cmp             SP, x16
    //     0xa60e00: b.ls            #0xa60e24
    // 0xa60e04: ldr             x16, [fp, #0x10]
    // 0xa60e08: SaveReg r16
    //     0xa60e08: str             x16, [SP, #-8]!
    // 0xa60e0c: r0 = _determineMagnifierPositionAndFocalPoint()
    //     0xa60e0c: bl              #0x7af2bc  ; [package:flutter/src/cupertino/magnifier.dart] _CupertinoTextMagnifierState::_determineMagnifierPositionAndFocalPoint
    // 0xa60e10: add             SP, SP, #8
    // 0xa60e14: r0 = Null
    //     0xa60e14: mov             x0, NULL
    // 0xa60e18: LeaveFrame
    //     0xa60e18: mov             SP, fp
    //     0xa60e1c: ldp             fp, lr, [SP], #0x10
    // 0xa60e20: ret
    //     0xa60e20: ret             
    // 0xa60e24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa60e24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa60e28: b               #0xa60e04
  }
}

// class id: 3872, size: 0x24, field offset: 0xc
//   const constructor, 
class CupertinoMagnifier extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1cd2c, size: 0x1bc
    // 0xb1cd2c: EnterFrame
    //     0xb1cd2c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cd30: mov             fp, SP
    // 0xb1cd34: AllocStack(0x28)
    //     0xb1cd34: sub             SP, SP, #0x28
    // 0xb1cd38: CheckStackOverflow
    //     0xb1cd38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1cd3c: cmp             SP, x16
    //     0xb1cd40: b.ls            #0xb1cedc
    // 0xb1cd44: r0 = Offset()
    //     0xb1cd44: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb1cd48: d0 = 0.000000
    //     0xb1cd48: eor             v0.16b, v0.16b, v0.16b
    // 0xb1cd4c: stur            x0, [fp, #-0x18]
    // 0xb1cd50: StoreField: r0->field_7 = d0
    //     0xb1cd50: stur            d0, [x0, #7]
    // 0xb1cd54: d0 = 49.750000
    //     0xb1cd54: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bb00] IMM: double(49.75) from 0x4048e00000000000
    //     0xb1cd58: ldr             d0, [x17, #0xb00]
    // 0xb1cd5c: StoreField: r0->field_f = d0
    //     0xb1cd5c: stur            d0, [x0, #0xf]
    // 0xb1cd60: ldr             x1, [fp, #0x18]
    // 0xb1cd64: LoadField: r2 = r1->field_1b
    //     0xb1cd64: ldur            w2, [x1, #0x1b]
    // 0xb1cd68: DecompressPointer r2
    //     0xb1cd68: add             x2, x2, HEAP, lsl #32
    // 0xb1cd6c: LoadField: r3 = r2->field_f
    //     0xb1cd6c: ldur            w3, [x2, #0xf]
    // 0xb1cd70: DecompressPointer r3
    //     0xb1cd70: add             x3, x3, HEAP, lsl #32
    // 0xb1cd74: stur            x3, [fp, #-0x10]
    // 0xb1cd78: LoadField: r4 = r2->field_b
    //     0xb1cd78: ldur            w4, [x2, #0xb]
    // 0xb1cd7c: DecompressPointer r4
    //     0xb1cd7c: add             x4, x4, HEAP, lsl #32
    // 0xb1cd80: stur            x4, [fp, #-8]
    // 0xb1cd84: stp             x4, x3, [SP, #-0x10]!
    // 0xb1cd88: r0 = evaluate()
    //     0xb1cd88: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb1cd8c: add             SP, SP, #0x10
    // 0xb1cd90: LoadField: d0 = r0->field_7
    //     0xb1cd90: ldur            d0, [x0, #7]
    // 0xb1cd94: ldur            x16, [fp, #-0x18]
    // 0xb1cd98: r30 = 1.000000
    //     0xb1cd98: ldr             lr, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xb1cd9c: stp             lr, x16, [SP, #-0x10]!
    // 0xb1cda0: SaveReg d0
    //     0xb1cda0: str             d0, [SP, #-8]!
    // 0xb1cda4: r0 = scale()
    //     0xb1cda4: bl              #0x9b587c  ; [dart:ui] Offset::scale
    // 0xb1cda8: add             SP, SP, #0x18
    // 0xb1cdac: ldr             x0, [fp, #0x18]
    // 0xb1cdb0: LoadField: r1 = r0->field_1f
    //     0xb1cdb0: ldur            w1, [x0, #0x1f]
    // 0xb1cdb4: DecompressPointer r1
    //     0xb1cdb4: add             x1, x1, HEAP, lsl #32
    // 0xb1cdb8: ldur            x16, [fp, #-0x18]
    // 0xb1cdbc: stp             x1, x16, [SP, #-0x10]!
    // 0xb1cdc0: r0 = +()
    //     0xb1cdc0: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0xb1cdc4: add             SP, SP, #0x10
    // 0xb1cdc8: stur            x0, [fp, #-0x18]
    // 0xb1cdcc: ldur            x16, [fp, #-0x10]
    // 0xb1cdd0: ldur            lr, [fp, #-8]
    // 0xb1cdd4: stp             lr, x16, [SP, #-0x10]!
    // 0xb1cdd8: r0 = evaluate()
    //     0xb1cdd8: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb1cddc: add             SP, SP, #0x10
    // 0xb1cde0: LoadField: d0 = r0->field_7
    //     0xb1cde0: ldur            d0, [x0, #7]
    // 0xb1cde4: r16 = Instance_Offset
    //     0xb1cde4: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4bb08] Obj!Offset@b5f2b1
    //     0xb1cde8: ldr             x16, [x16, #0xb08]
    // 0xb1cdec: r30 = Instance_Offset
    //     0xb1cdec: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xb1cdf0: stp             lr, x16, [SP, #-0x10]!
    // 0xb1cdf4: SaveReg d0
    //     0xb1cdf4: str             d0, [SP, #-8]!
    // 0xb1cdf8: r0 = lerp()
    //     0xb1cdf8: bl              #0x9963f8  ; [dart:ui] Offset::lerp
    // 0xb1cdfc: add             SP, SP, #0x18
    // 0xb1ce00: stur            x0, [fp, #-0x20]
    // 0xb1ce04: cmp             w0, NULL
    // 0xb1ce08: b.eq            #0xb1cee4
    // 0xb1ce0c: ldur            x16, [fp, #-0x10]
    // 0xb1ce10: ldur            lr, [fp, #-8]
    // 0xb1ce14: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ce18: r0 = evaluate()
    //     0xb1ce18: bl              #0x66c4b0  ; [package:flutter/src/animation/tween.dart] Animatable::evaluate
    // 0xb1ce1c: add             SP, SP, #0x10
    // 0xb1ce20: stur            x0, [fp, #-8]
    // 0xb1ce24: r0 = RoundedRectangleBorder()
    //     0xb1ce24: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0xb1ce28: mov             x1, x0
    // 0xb1ce2c: r0 = Instance_BorderRadius
    //     0xb1ce2c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40420] Obj!BorderRadius@b374b1
    //     0xb1ce30: ldr             x0, [x0, #0x420]
    // 0xb1ce34: stur            x1, [fp, #-0x10]
    // 0xb1ce38: StoreField: r1->field_b = r0
    //     0xb1ce38: stur            w0, [x1, #0xb]
    // 0xb1ce3c: r0 = Instance_BorderSide
    //     0xb1ce3c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40430] Obj!BorderSide@b48471
    //     0xb1ce40: ldr             x0, [x0, #0x430]
    // 0xb1ce44: StoreField: r1->field_7 = r0
    //     0xb1ce44: stur            w0, [x1, #7]
    // 0xb1ce48: ldur            x0, [fp, #-8]
    // 0xb1ce4c: LoadField: d0 = r0->field_7
    //     0xb1ce4c: ldur            d0, [x0, #7]
    // 0xb1ce50: stur            d0, [fp, #-0x28]
    // 0xb1ce54: r0 = MagnifierDecoration()
    //     0xb1ce54: bl              #0xb1cef4  ; AllocateMagnifierDecorationStub -> MagnifierDecoration (size=0x24)
    // 0xb1ce58: ldur            d0, [fp, #-0x28]
    // 0xb1ce5c: stur            x0, [fp, #-8]
    // 0xb1ce60: StoreField: r0->field_1b = d0
    //     0xb1ce60: stur            d0, [x0, #0x1b]
    // 0xb1ce64: r1 = const [Instance of 'BoxShadow']
    //     0xb1ce64: add             x1, PP, #0x40, lsl #12  ; [pp+0x40428] List<BoxShadow>(1)
    //     0xb1ce68: ldr             x1, [x1, #0x428]
    // 0xb1ce6c: StoreField: r0->field_13 = r1
    //     0xb1ce6c: stur            w1, [x0, #0x13]
    // 0xb1ce70: ldur            x1, [fp, #-0x10]
    // 0xb1ce74: StoreField: r0->field_17 = r1
    //     0xb1ce74: stur            w1, [x0, #0x17]
    // 0xb1ce78: r0 = RawMagnifier()
    //     0xb1ce78: bl              #0xb1cee8  ; AllocateRawMagnifierStub -> RawMagnifier (size=0x24)
    // 0xb1ce7c: mov             x1, x0
    // 0xb1ce80: ldur            x0, [fp, #-8]
    // 0xb1ce84: stur            x1, [fp, #-0x10]
    // 0xb1ce88: StoreField: r1->field_f = r0
    //     0xb1ce88: stur            w0, [x1, #0xf]
    // 0xb1ce8c: ldur            x0, [fp, #-0x18]
    // 0xb1ce90: StoreField: r1->field_13 = r0
    //     0xb1ce90: stur            w0, [x1, #0x13]
    // 0xb1ce94: d0 = 1.000000
    //     0xb1ce94: fmov            d0, #1.00000000
    // 0xb1ce98: StoreField: r1->field_17 = d0
    //     0xb1ce98: stur            d0, [x1, #0x17]
    // 0xb1ce9c: r0 = Instance_Size
    //     0xb1ce9c: add             x0, PP, #0x40, lsl #12  ; [pp+0x40418] Obj!Size@b5ecd1
    //     0xb1cea0: ldr             x0, [x0, #0x418]
    // 0xb1cea4: StoreField: r1->field_1f = r0
    //     0xb1cea4: stur            w0, [x1, #0x1f]
    // 0xb1cea8: r0 = Transform()
    //     0xb1cea8: bl              #0x8636cc  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xb1ceac: stur            x0, [fp, #-8]
    // 0xb1ceb0: ldur            x16, [fp, #-0x10]
    // 0xb1ceb4: stp             x16, x0, [SP, #-0x10]!
    // 0xb1ceb8: ldur            x16, [fp, #-0x20]
    // 0xb1cebc: SaveReg r16
    //     0xb1cebc: str             x16, [SP, #-8]!
    // 0xb1cec0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xb1cec0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xb1cec4: r0 = Transform.translate()
    //     0xb1cec4: bl              #0x97dcb4  ; [package:flutter/src/widgets/basic.dart] Transform::Transform.translate
    // 0xb1cec8: add             SP, SP, #0x18
    // 0xb1cecc: ldur            x0, [fp, #-8]
    // 0xb1ced0: LeaveFrame
    //     0xb1ced0: mov             SP, fp
    //     0xb1ced4: ldp             fp, lr, [SP], #0x10
    // 0xb1ced8: ret
    //     0xb1ced8: ret             
    // 0xb1cedc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cedc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cee0: b               #0xb1cd44
    // 0xb1cee4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xb1cee4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4180, size: 0x30, field offset: 0xc
//   const constructor, 
class CupertinoTextMagnifier extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fda8, size: 0x3c
    // 0xa3fda8: EnterFrame
    //     0xa3fda8: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fdac: mov             fp, SP
    // 0xa3fdb0: r1 = <CupertinoTextMagnifier>
    //     0xa3fdb0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37cc8] TypeArguments: <CupertinoTextMagnifier>
    //     0xa3fdb4: ldr             x1, [x1, #0xcc8]
    // 0xa3fdb8: r0 = _CupertinoTextMagnifierState()
    //     0xa3fdb8: bl              #0xa3fde4  ; Allocate_CupertinoTextMagnifierStateStub -> _CupertinoTextMagnifierState (size=0x30)
    // 0xa3fdbc: r1 = Instance_Offset
    //     0xa3fdbc: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa3fdc0: StoreField: r0->field_1b = r1
    //     0xa3fdc0: stur            w1, [x0, #0x1b]
    // 0xa3fdc4: d0 = 0.000000
    //     0xa3fdc4: eor             v0.16b, v0.16b, v0.16b
    // 0xa3fdc8: StoreField: r0->field_1f = d0
    //     0xa3fdc8: stur            d0, [x0, #0x1f]
    // 0xa3fdcc: r1 = Sentinel
    //     0xa3fdcc: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fdd0: StoreField: r0->field_27 = r1
    //     0xa3fdd0: stur            w1, [x0, #0x27]
    // 0xa3fdd4: StoreField: r0->field_2b = r1
    //     0xa3fdd4: stur            w1, [x0, #0x2b]
    // 0xa3fdd8: LeaveFrame
    //     0xa3fdd8: mov             SP, fp
    //     0xa3fddc: ldp             fp, lr, [SP], #0x10
    // 0xa3fde0: ret
    //     0xa3fde0: ret             
  }
}

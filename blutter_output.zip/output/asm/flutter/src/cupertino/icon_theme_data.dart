// lib: , url: package:flutter/src/cupertino/icon_theme_data.dart

// class id: 1049090, size: 0x8
class :: {
}

// class id: 2899, size: 0x28, field offset: 0x28
//   const constructor, transformed mixin,
abstract class _CupertinoIconThemeData&IconThemeData&Diagnosticable extends IconThemeData
     with Diagnosticable {
}

// class id: 2900, size: 0x28, field offset: 0x28
//   const constructor, 
class CupertinoIconThemeData extends _CupertinoIconThemeData&IconThemeData&Diagnosticable {

  _ copyWith(/* No info */) {
    // ** addr: 0xceb3e0, size: 0x444
    // 0xceb3e0: EnterFrame
    //     0xceb3e0: stp             fp, lr, [SP, #-0x10]!
    //     0xceb3e4: mov             fp, SP
    // 0xceb3e8: AllocStack(0x48)
    //     0xceb3e8: sub             SP, SP, #0x48
    // 0xceb3ec: SetupParameters(CupertinoIconThemeData this /* r3, fp-0x40 */, {dynamic color = Null /* r4 */, dynamic fill = Null /* r5 */, dynamic grade = Null /* r6 */, dynamic opacity = Null /* r7 */, dynamic opticalSize = Null /* r8 */, dynamic shadows = Null /* r9, fp-0x38 */, dynamic size = Null /* r10 */, dynamic weight = Null /* r0 */})
    //     0xceb3ec: mov             x0, x4
    //     0xceb3f0: ldur            w1, [x0, #0x13]
    //     0xceb3f4: add             x1, x1, HEAP, lsl #32
    //     0xceb3f8: sub             x2, x1, #2
    //     0xceb3fc: add             x3, fp, w2, sxtw #2
    //     0xceb400: ldr             x3, [x3, #0x10]
    //     0xceb404: stur            x3, [fp, #-0x40]
    //     0xceb408: ldur            w2, [x0, #0x1f]
    //     0xceb40c: add             x2, x2, HEAP, lsl #32
    //     0xceb410: add             x16, PP, #0xd, lsl #12  ; [pp+0xdae8] "color"
    //     0xceb414: ldr             x16, [x16, #0xae8]
    //     0xceb418: cmp             w2, w16
    //     0xceb41c: b.ne            #0xceb440
    //     0xceb420: ldur            w2, [x0, #0x23]
    //     0xceb424: add             x2, x2, HEAP, lsl #32
    //     0xceb428: sub             w4, w1, w2
    //     0xceb42c: add             x2, fp, w4, sxtw #2
    //     0xceb430: ldr             x2, [x2, #8]
    //     0xceb434: mov             x4, x2
    //     0xceb438: mov             x2, #1
    //     0xceb43c: b               #0xceb448
    //     0xceb440: mov             x4, NULL
    //     0xceb444: mov             x2, #0
    //     0xceb448: lsl             x5, x2, #1
    //     0xceb44c: lsl             w6, w5, #1
    //     0xceb450: add             w7, w6, #8
    //     0xceb454: add             x16, x0, w7, sxtw #1
    //     0xceb458: ldur            w8, [x16, #0xf]
    //     0xceb45c: add             x8, x8, HEAP, lsl #32
    //     0xceb460: add             x16, PP, #0x27, lsl #12  ; [pp+0x27d98] "fill"
    //     0xceb464: ldr             x16, [x16, #0xd98]
    //     0xceb468: cmp             w8, w16
    //     0xceb46c: b.ne            #0xceb4a0
    //     0xceb470: add             w2, w6, #0xa
    //     0xceb474: add             x16, x0, w2, sxtw #1
    //     0xceb478: ldur            w6, [x16, #0xf]
    //     0xceb47c: add             x6, x6, HEAP, lsl #32
    //     0xceb480: sub             w2, w1, w6
    //     0xceb484: add             x6, fp, w2, sxtw #2
    //     0xceb488: ldr             x6, [x6, #8]
    //     0xceb48c: add             w2, w5, #2
    //     0xceb490: sbfx            x5, x2, #1, #0x1f
    //     0xceb494: mov             x2, x5
    //     0xceb498: mov             x5, x6
    //     0xceb49c: b               #0xceb4a4
    //     0xceb4a0: mov             x5, NULL
    //     0xceb4a4: lsl             x6, x2, #1
    //     0xceb4a8: lsl             w7, w6, #1
    //     0xceb4ac: add             w8, w7, #8
    //     0xceb4b0: add             x16, x0, w8, sxtw #1
    //     0xceb4b4: ldur            w9, [x16, #0xf]
    //     0xceb4b8: add             x9, x9, HEAP, lsl #32
    //     0xceb4bc: add             x16, PP, #0x27, lsl #12  ; [pp+0x27da0] "grade"
    //     0xceb4c0: ldr             x16, [x16, #0xda0]
    //     0xceb4c4: cmp             w9, w16
    //     0xceb4c8: b.ne            #0xceb4fc
    //     0xceb4cc: add             w2, w7, #0xa
    //     0xceb4d0: add             x16, x0, w2, sxtw #1
    //     0xceb4d4: ldur            w7, [x16, #0xf]
    //     0xceb4d8: add             x7, x7, HEAP, lsl #32
    //     0xceb4dc: sub             w2, w1, w7
    //     0xceb4e0: add             x7, fp, w2, sxtw #2
    //     0xceb4e4: ldr             x7, [x7, #8]
    //     0xceb4e8: add             w2, w6, #2
    //     0xceb4ec: sbfx            x6, x2, #1, #0x1f
    //     0xceb4f0: mov             x2, x6
    //     0xceb4f4: mov             x6, x7
    //     0xceb4f8: b               #0xceb500
    //     0xceb4fc: mov             x6, NULL
    //     0xceb500: lsl             x7, x2, #1
    //     0xceb504: lsl             w8, w7, #1
    //     0xceb508: add             w9, w8, #8
    //     0xceb50c: add             x16, x0, w9, sxtw #1
    //     0xceb510: ldur            w10, [x16, #0xf]
    //     0xceb514: add             x10, x10, HEAP, lsl #32
    //     0xceb518: add             x16, PP, #0x27, lsl #12  ; [pp+0x27da8] "opacity"
    //     0xceb51c: ldr             x16, [x16, #0xda8]
    //     0xceb520: cmp             w10, w16
    //     0xceb524: b.ne            #0xceb558
    //     0xceb528: add             w2, w8, #0xa
    //     0xceb52c: add             x16, x0, w2, sxtw #1
    //     0xceb530: ldur            w8, [x16, #0xf]
    //     0xceb534: add             x8, x8, HEAP, lsl #32
    //     0xceb538: sub             w2, w1, w8
    //     0xceb53c: add             x8, fp, w2, sxtw #2
    //     0xceb540: ldr             x8, [x8, #8]
    //     0xceb544: add             w2, w7, #2
    //     0xceb548: sbfx            x7, x2, #1, #0x1f
    //     0xceb54c: mov             x2, x7
    //     0xceb550: mov             x7, x8
    //     0xceb554: b               #0xceb55c
    //     0xceb558: mov             x7, NULL
    //     0xceb55c: lsl             x8, x2, #1
    //     0xceb560: lsl             w9, w8, #1
    //     0xceb564: add             w10, w9, #8
    //     0xceb568: add             x16, x0, w10, sxtw #1
    //     0xceb56c: ldur            w11, [x16, #0xf]
    //     0xceb570: add             x11, x11, HEAP, lsl #32
    //     0xceb574: add             x16, PP, #0x27, lsl #12  ; [pp+0x27db0] "opticalSize"
    //     0xceb578: ldr             x16, [x16, #0xdb0]
    //     0xceb57c: cmp             w11, w16
    //     0xceb580: b.ne            #0xceb5b4
    //     0xceb584: add             w2, w9, #0xa
    //     0xceb588: add             x16, x0, w2, sxtw #1
    //     0xceb58c: ldur            w9, [x16, #0xf]
    //     0xceb590: add             x9, x9, HEAP, lsl #32
    //     0xceb594: sub             w2, w1, w9
    //     0xceb598: add             x9, fp, w2, sxtw #2
    //     0xceb59c: ldr             x9, [x9, #8]
    //     0xceb5a0: add             w2, w8, #2
    //     0xceb5a4: sbfx            x8, x2, #1, #0x1f
    //     0xceb5a8: mov             x2, x8
    //     0xceb5ac: mov             x8, x9
    //     0xceb5b0: b               #0xceb5b8
    //     0xceb5b4: mov             x8, NULL
    //     0xceb5b8: lsl             x9, x2, #1
    //     0xceb5bc: lsl             w10, w9, #1
    //     0xceb5c0: add             w11, w10, #8
    //     0xceb5c4: add             x16, x0, w11, sxtw #1
    //     0xceb5c8: ldur            w12, [x16, #0xf]
    //     0xceb5cc: add             x12, x12, HEAP, lsl #32
    //     0xceb5d0: add             x16, PP, #0xe, lsl #12  ; [pp+0xe050] "shadows"
    //     0xceb5d4: ldr             x16, [x16, #0x50]
    //     0xceb5d8: cmp             w12, w16
    //     0xceb5dc: b.ne            #0xceb610
    //     0xceb5e0: add             w2, w10, #0xa
    //     0xceb5e4: add             x16, x0, w2, sxtw #1
    //     0xceb5e8: ldur            w10, [x16, #0xf]
    //     0xceb5ec: add             x10, x10, HEAP, lsl #32
    //     0xceb5f0: sub             w2, w1, w10
    //     0xceb5f4: add             x10, fp, w2, sxtw #2
    //     0xceb5f8: ldr             x10, [x10, #8]
    //     0xceb5fc: add             w2, w9, #2
    //     0xceb600: sbfx            x9, x2, #1, #0x1f
    //     0xceb604: mov             x2, x9
    //     0xceb608: mov             x9, x10
    //     0xceb60c: b               #0xceb614
    //     0xceb610: mov             x9, NULL
    //     0xceb614: stur            x9, [fp, #-0x38]
    //     0xceb618: lsl             x10, x2, #1
    //     0xceb61c: lsl             w11, w10, #1
    //     0xceb620: add             w12, w11, #8
    //     0xceb624: add             x16, x0, w12, sxtw #1
    //     0xceb628: ldur            w13, [x16, #0xf]
    //     0xceb62c: add             x13, x13, HEAP, lsl #32
    //     0xceb630: add             x16, PP, #0x14, lsl #12  ; [pp+0x14fc0] "size"
    //     0xceb634: ldr             x16, [x16, #0xfc0]
    //     0xceb638: cmp             w13, w16
    //     0xceb63c: b.ne            #0xceb670
    //     0xceb640: add             w2, w11, #0xa
    //     0xceb644: add             x16, x0, w2, sxtw #1
    //     0xceb648: ldur            w11, [x16, #0xf]
    //     0xceb64c: add             x11, x11, HEAP, lsl #32
    //     0xceb650: sub             w2, w1, w11
    //     0xceb654: add             x11, fp, w2, sxtw #2
    //     0xceb658: ldr             x11, [x11, #8]
    //     0xceb65c: add             w2, w10, #2
    //     0xceb660: sbfx            x10, x2, #1, #0x1f
    //     0xceb664: mov             x2, x10
    //     0xceb668: mov             x10, x11
    //     0xceb66c: b               #0xceb674
    //     0xceb670: mov             x10, NULL
    //     0xceb674: lsl             x11, x2, #1
    //     0xceb678: lsl             w2, w11, #1
    //     0xceb67c: add             w11, w2, #8
    //     0xceb680: add             x16, x0, w11, sxtw #1
    //     0xceb684: ldur            w12, [x16, #0xf]
    //     0xceb688: add             x12, x12, HEAP, lsl #32
    //     0xceb68c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27db8] "weight"
    //     0xceb690: ldr             x16, [x16, #0xdb8]
    //     0xceb694: cmp             w12, w16
    //     0xceb698: b.ne            #0xceb6c0
    //     0xceb69c: add             w11, w2, #0xa
    //     0xceb6a0: add             x16, x0, w11, sxtw #1
    //     0xceb6a4: ldur            w2, [x16, #0xf]
    //     0xceb6a8: add             x2, x2, HEAP, lsl #32
    //     0xceb6ac: sub             w0, w1, w2
    //     0xceb6b0: add             x1, fp, w0, sxtw #2
    //     0xceb6b4: ldr             x1, [x1, #8]
    //     0xceb6b8: mov             x0, x1
    //     0xceb6bc: b               #0xceb6c4
    //     0xceb6c0: mov             x0, NULL
    // 0xceb6c4: CheckStackOverflow
    //     0xceb6c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xceb6c8: cmp             SP, x16
    //     0xceb6cc: b.ls            #0xceb81c
    // 0xceb6d0: cmp             w10, NULL
    // 0xceb6d4: b.ne            #0xceb6e4
    // 0xceb6d8: LoadField: r1 = r3->field_7
    //     0xceb6d8: ldur            w1, [x3, #7]
    // 0xceb6dc: DecompressPointer r1
    //     0xceb6dc: add             x1, x1, HEAP, lsl #32
    // 0xceb6e0: b               #0xceb6e8
    // 0xceb6e4: mov             x1, x10
    // 0xceb6e8: stur            x1, [fp, #-0x30]
    // 0xceb6ec: cmp             w5, NULL
    // 0xceb6f0: b.ne            #0xceb700
    // 0xceb6f4: LoadField: r2 = r3->field_b
    //     0xceb6f4: ldur            w2, [x3, #0xb]
    // 0xceb6f8: DecompressPointer r2
    //     0xceb6f8: add             x2, x2, HEAP, lsl #32
    // 0xceb6fc: b               #0xceb704
    // 0xceb700: mov             x2, x5
    // 0xceb704: stur            x2, [fp, #-0x28]
    // 0xceb708: cmp             w0, NULL
    // 0xceb70c: b.ne            #0xceb718
    // 0xceb710: LoadField: r0 = r3->field_f
    //     0xceb710: ldur            w0, [x3, #0xf]
    // 0xceb714: DecompressPointer r0
    //     0xceb714: add             x0, x0, HEAP, lsl #32
    // 0xceb718: stur            x0, [fp, #-0x20]
    // 0xceb71c: cmp             w6, NULL
    // 0xceb720: b.ne            #0xceb730
    // 0xceb724: LoadField: r5 = r3->field_13
    //     0xceb724: ldur            w5, [x3, #0x13]
    // 0xceb728: DecompressPointer r5
    //     0xceb728: add             x5, x5, HEAP, lsl #32
    // 0xceb72c: b               #0xceb734
    // 0xceb730: mov             x5, x6
    // 0xceb734: stur            x5, [fp, #-0x18]
    // 0xceb738: cmp             w8, NULL
    // 0xceb73c: b.ne            #0xceb74c
    // 0xceb740: LoadField: r6 = r3->field_17
    //     0xceb740: ldur            w6, [x3, #0x17]
    // 0xceb744: DecompressPointer r6
    //     0xceb744: add             x6, x6, HEAP, lsl #32
    // 0xceb748: b               #0xceb750
    // 0xceb74c: mov             x6, x8
    // 0xceb750: stur            x6, [fp, #-0x10]
    // 0xceb754: cmp             w4, NULL
    // 0xceb758: b.ne            #0xceb764
    // 0xceb75c: LoadField: r4 = r3->field_1b
    //     0xceb75c: ldur            w4, [x3, #0x1b]
    // 0xceb760: DecompressPointer r4
    //     0xceb760: add             x4, x4, HEAP, lsl #32
    // 0xceb764: stur            x4, [fp, #-8]
    // 0xceb768: cmp             w7, NULL
    // 0xceb76c: b.ne            #0xceb784
    // 0xceb770: SaveReg r3
    //     0xceb770: str             x3, [SP, #-8]!
    // 0xceb774: r0 = opacity()
    //     0xceb774: bl              #0x848618  ; [package:flutter/src/widgets/icon_theme_data.dart] IconThemeData::opacity
    // 0xceb778: add             SP, SP, #8
    // 0xceb77c: mov             x1, x0
    // 0xceb780: b               #0xceb788
    // 0xceb784: mov             x1, x7
    // 0xceb788: ldur            x0, [fp, #-0x38]
    // 0xceb78c: stur            x1, [fp, #-0x48]
    // 0xceb790: cmp             w0, NULL
    // 0xceb794: b.ne            #0xceb7ac
    // 0xceb798: ldur            x0, [fp, #-0x40]
    // 0xceb79c: LoadField: r2 = r0->field_23
    //     0xceb79c: ldur            w2, [x0, #0x23]
    // 0xceb7a0: DecompressPointer r2
    //     0xceb7a0: add             x2, x2, HEAP, lsl #32
    // 0xceb7a4: mov             x7, x2
    // 0xceb7a8: b               #0xceb7b0
    // 0xceb7ac: mov             x7, x0
    // 0xceb7b0: ldur            x0, [fp, #-0x30]
    // 0xceb7b4: ldur            x2, [fp, #-0x28]
    // 0xceb7b8: ldur            x3, [fp, #-0x20]
    // 0xceb7bc: ldur            x4, [fp, #-0x18]
    // 0xceb7c0: ldur            x5, [fp, #-0x10]
    // 0xceb7c4: ldur            x6, [fp, #-8]
    // 0xceb7c8: stur            x7, [fp, #-0x38]
    // 0xceb7cc: r0 = CupertinoIconThemeData()
    //     0xceb7cc: bl              #0xb1d714  ; AllocateCupertinoIconThemeDataStub -> CupertinoIconThemeData (size=0x28)
    // 0xceb7d0: ldur            x1, [fp, #-0x30]
    // 0xceb7d4: StoreField: r0->field_7 = r1
    //     0xceb7d4: stur            w1, [x0, #7]
    // 0xceb7d8: ldur            x1, [fp, #-0x28]
    // 0xceb7dc: StoreField: r0->field_b = r1
    //     0xceb7dc: stur            w1, [x0, #0xb]
    // 0xceb7e0: ldur            x1, [fp, #-0x20]
    // 0xceb7e4: StoreField: r0->field_f = r1
    //     0xceb7e4: stur            w1, [x0, #0xf]
    // 0xceb7e8: ldur            x1, [fp, #-0x18]
    // 0xceb7ec: StoreField: r0->field_13 = r1
    //     0xceb7ec: stur            w1, [x0, #0x13]
    // 0xceb7f0: ldur            x1, [fp, #-0x10]
    // 0xceb7f4: StoreField: r0->field_17 = r1
    //     0xceb7f4: stur            w1, [x0, #0x17]
    // 0xceb7f8: ldur            x1, [fp, #-8]
    // 0xceb7fc: StoreField: r0->field_1b = r1
    //     0xceb7fc: stur            w1, [x0, #0x1b]
    // 0xceb800: ldur            x1, [fp, #-0x38]
    // 0xceb804: StoreField: r0->field_23 = r1
    //     0xceb804: stur            w1, [x0, #0x23]
    // 0xceb808: ldur            x1, [fp, #-0x48]
    // 0xceb80c: StoreField: r0->field_1f = r1
    //     0xceb80c: stur            w1, [x0, #0x1f]
    // 0xceb810: LeaveFrame
    //     0xceb810: mov             SP, fp
    //     0xceb814: ldp             fp, lr, [SP], #0x10
    // 0xceb818: ret
    //     0xceb818: ret             
    // 0xceb81c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xceb81c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xceb820: b               #0xceb6d0
  }
}

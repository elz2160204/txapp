// lib: , url: package:flutter/src/cupertino/interface_level.dart

// class id: 1049092, size: 0x8
class :: {
}

// class id: 3552, size: 0x10, field offset: 0x10
//   const constructor, 
abstract class CupertinoUserInterfaceLevel extends InheritedWidget {

  static _ maybeOf(/* No info */) {
    // ** addr: 0x6cab88, size: 0x48
    // 0x6cab88: EnterFrame
    //     0x6cab88: stp             fp, lr, [SP, #-0x10]!
    //     0x6cab8c: mov             fp, SP
    // 0x6cab90: CheckStackOverflow
    //     0x6cab90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cab94: cmp             SP, x16
    //     0x6cab98: b.ls            #0x6cabc8
    // 0x6cab9c: r16 = <CupertinoUserInterfaceLevel>
    //     0x6cab9c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27dc0] TypeArguments: <CupertinoUserInterfaceLevel>
    //     0x6caba0: ldr             x16, [x16, #0xdc0]
    // 0x6caba4: ldr             lr, [fp, #0x10]
    // 0x6caba8: stp             lr, x16, [SP, #-0x10]!
    // 0x6cabac: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6cabac: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6cabb0: r0 = dependOnInheritedWidgetOfExactType()
    //     0x6cabb0: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x6cabb4: add             SP, SP, #0x10
    // 0x6cabb8: r0 = Null
    //     0x6cabb8: mov             x0, NULL
    // 0x6cabbc: LeaveFrame
    //     0x6cabbc: mov             SP, fp
    //     0x6cabc0: ldp             fp, lr, [SP], #0x10
    // 0x6cabc4: ret
    //     0x6cabc4: ret             
    // 0x6cabc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cabc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cabcc: b               #0x6cab9c
  }
}

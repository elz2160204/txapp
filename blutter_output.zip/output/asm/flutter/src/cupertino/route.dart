// lib: , url: package:flutter/src/cupertino/route.dart

// class id: 1049101, size: 0x8
class :: {

  static late final Animatable<Offset> _kRightMiddleTween; // offset: 0xcd8
  static late final Animatable<Offset> _kMiddleLeftTween; // offset: 0xcdc

  static Animatable<Offset> _kMiddleLeftTween() {
    // ** addr: 0xa8a440, size: 0x34
    // 0xa8a440: EnterFrame
    //     0xa8a440: stp             fp, lr, [SP, #-0x10]!
    //     0xa8a444: mov             fp, SP
    // 0xa8a448: r1 = <Offset>
    //     0xa8a448: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0xa8a44c: ldr             x1, [x1, #0x7f8]
    // 0xa8a450: r0 = Tween()
    //     0xa8a450: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xa8a454: r1 = Instance_Offset
    //     0xa8a454: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa8a458: StoreField: r0->field_b = r1
    //     0xa8a458: stur            w1, [x0, #0xb]
    // 0xa8a45c: r1 = Instance_Offset
    //     0xa8a45c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aae8] Obj!Offset@b5f271
    //     0xa8a460: ldr             x1, [x1, #0xae8]
    // 0xa8a464: StoreField: r0->field_f = r1
    //     0xa8a464: stur            w1, [x0, #0xf]
    // 0xa8a468: LeaveFrame
    //     0xa8a468: mov             SP, fp
    //     0xa8a46c: ldp             fp, lr, [SP], #0x10
    // 0xa8a470: ret
    //     0xa8a470: ret             
  }
  static Animatable<Offset> _kRightMiddleTween() {
    // ** addr: 0xa8a474, size: 0x34
    // 0xa8a474: EnterFrame
    //     0xa8a474: stp             fp, lr, [SP, #-0x10]!
    //     0xa8a478: mov             fp, SP
    // 0xa8a47c: r1 = <Offset>
    //     0xa8a47c: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0xa8a480: ldr             x1, [x1, #0x7f8]
    // 0xa8a484: r0 = Tween()
    //     0xa8a484: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xa8a488: r1 = Instance_Offset
    //     0xa8a488: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f660] Obj!Offset@b5ef71
    //     0xa8a48c: ldr             x1, [x1, #0x660]
    // 0xa8a490: StoreField: r0->field_b = r1
    //     0xa8a490: stur            w1, [x0, #0xb]
    // 0xa8a494: r1 = Instance_Offset
    //     0xa8a494: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xa8a498: StoreField: r0->field_f = r1
    //     0xa8a498: stur            w1, [x0, #0xf]
    // 0xa8a49c: LeaveFrame
    //     0xa8a49c: mov             SP, fp
    //     0xa8a4a0: ldp             fp, lr, [SP], #0x10
    // 0xa8a4a4: ret
    //     0xa8a4a4: ret             
  }
}

// class id: 2939, size: 0xc, field offset: 0x8
//   const constructor, 
class _CupertinoEdgeShadowDecoration extends Decoration {

  static late DecorationTween kTween; // offset: 0xcd4
  _ImmutableList<Color> field_8;

  static DecorationTween kTween() {
    // ** addr: 0xa8a3fc, size: 0x38
    // 0xa8a3fc: EnterFrame
    //     0xa8a3fc: stp             fp, lr, [SP, #-0x10]!
    //     0xa8a400: mov             fp, SP
    // 0xa8a404: r1 = <Decoration>
    //     0xa8a404: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aad0] TypeArguments: <Decoration>
    //     0xa8a408: ldr             x1, [x1, #0xad0]
    // 0xa8a40c: r0 = DecorationTween()
    //     0xa8a40c: bl              #0xa8a434  ; AllocateDecorationTweenStub -> DecorationTween (size=0x14)
    // 0xa8a410: r1 = Instance__CupertinoEdgeShadowDecoration
    //     0xa8a410: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aad8] Obj!_CupertinoEdgeShadowDecoration@b49711
    //     0xa8a414: ldr             x1, [x1, #0xad8]
    // 0xa8a418: StoreField: r0->field_b = r1
    //     0xa8a418: stur            w1, [x0, #0xb]
    // 0xa8a41c: r1 = Instance__CupertinoEdgeShadowDecoration
    //     0xa8a41c: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2aae0] Obj!_CupertinoEdgeShadowDecoration@b49701
    //     0xa8a420: ldr             x1, [x1, #0xae0]
    // 0xa8a424: StoreField: r0->field_f = r1
    //     0xa8a424: stur            w1, [x0, #0xf]
    // 0xa8a428: LeaveFrame
    //     0xa8a428: mov             SP, fp
    //     0xa8a42c: ldp             fp, lr, [SP], #0x10
    // 0xa8a430: ret
    //     0xa8a430: ret             
  }
  _ ==(/* No info */) {
    // ** addr: 0xc808fc, size: 0x108
    // 0xc808fc: EnterFrame
    //     0xc808fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc80900: mov             fp, SP
    // 0xc80904: CheckStackOverflow
    //     0xc80904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc80908: cmp             SP, x16
    //     0xc8090c: b.ls            #0xc809fc
    // 0xc80910: ldr             x1, [fp, #0x10]
    // 0xc80914: cmp             w1, NULL
    // 0xc80918: b.ne            #0xc8092c
    // 0xc8091c: r0 = false
    //     0xc8091c: add             x0, NULL, #0x30  ; false
    // 0xc80920: LeaveFrame
    //     0xc80920: mov             SP, fp
    //     0xc80924: ldp             fp, lr, [SP], #0x10
    // 0xc80928: ret
    //     0xc80928: ret             
    // 0xc8092c: r0 = 59
    //     0xc8092c: mov             x0, #0x3b
    // 0xc80930: branchIfSmi(r1, 0xc8093c)
    //     0xc80930: tbz             w1, #0, #0xc8093c
    // 0xc80934: r0 = LoadClassIdInstr(r1)
    //     0xc80934: ldur            x0, [x1, #-1]
    //     0xc80938: ubfx            x0, x0, #0xc, #0x14
    // 0xc8093c: SaveReg r1
    //     0xc8093c: str             x1, [SP, #-8]!
    // 0xc80940: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc80940: mov             x17, #0x57c5
    //     0xc80944: add             lr, x0, x17
    //     0xc80948: ldr             lr, [x21, lr, lsl #3]
    //     0xc8094c: blr             lr
    // 0xc80950: add             SP, SP, #8
    // 0xc80954: r1 = LoadClassIdInstr(r0)
    //     0xc80954: ldur            x1, [x0, #-1]
    //     0xc80958: ubfx            x1, x1, #0xc, #0x14
    // 0xc8095c: r16 = _CupertinoEdgeShadowDecoration
    //     0xc8095c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37cb0] Type: _CupertinoEdgeShadowDecoration
    //     0xc80960: ldr             x16, [x16, #0xcb0]
    // 0xc80964: stp             x16, x0, [SP, #-0x10]!
    // 0xc80968: mov             x0, x1
    // 0xc8096c: mov             lr, x0
    // 0xc80970: ldr             lr, [x21, lr, lsl #3]
    // 0xc80974: blr             lr
    // 0xc80978: add             SP, SP, #0x10
    // 0xc8097c: tbz             w0, #4, #0xc80990
    // 0xc80980: r0 = false
    //     0xc80980: add             x0, NULL, #0x30  ; false
    // 0xc80984: LeaveFrame
    //     0xc80984: mov             SP, fp
    //     0xc80988: ldp             fp, lr, [SP], #0x10
    // 0xc8098c: ret
    //     0xc8098c: ret             
    // 0xc80990: ldr             x0, [fp, #0x10]
    // 0xc80994: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc80994: mov             x1, #0x76
    //     0xc80998: tbz             w0, #0, #0xc809a8
    //     0xc8099c: ldur            x1, [x0, #-1]
    //     0xc809a0: ubfx            x1, x1, #0xc, #0x14
    //     0xc809a4: lsl             x1, x1, #1
    // 0xc809a8: r17 = 5878
    //     0xc809a8: mov             x17, #0x16f6
    // 0xc809ac: cmp             w1, w17
    // 0xc809b0: b.ne            #0xc809ec
    // 0xc809b4: ldr             x1, [fp, #0x18]
    // 0xc809b8: LoadField: r2 = r0->field_7
    //     0xc809b8: ldur            w2, [x0, #7]
    // 0xc809bc: DecompressPointer r2
    //     0xc809bc: add             x2, x2, HEAP, lsl #32
    // 0xc809c0: LoadField: r0 = r1->field_7
    //     0xc809c0: ldur            w0, [x1, #7]
    // 0xc809c4: DecompressPointer r0
    //     0xc809c4: add             x0, x0, HEAP, lsl #32
    // 0xc809c8: r1 = LoadClassIdInstr(r2)
    //     0xc809c8: ldur            x1, [x2, #-1]
    //     0xc809cc: ubfx            x1, x1, #0xc, #0x14
    // 0xc809d0: stp             x0, x2, [SP, #-0x10]!
    // 0xc809d4: mov             x0, x1
    // 0xc809d8: mov             lr, x0
    // 0xc809dc: ldr             lr, [x21, lr, lsl #3]
    // 0xc809e0: blr             lr
    // 0xc809e4: add             SP, SP, #0x10
    // 0xc809e8: b               #0xc809f0
    // 0xc809ec: r0 = false
    //     0xc809ec: add             x0, NULL, #0x30  ; false
    // 0xc809f0: LeaveFrame
    //     0xc809f0: mov             SP, fp
    //     0xc809f4: ldp             fp, lr, [SP], #0x10
    // 0xc809f8: ret
    //     0xc809f8: ret             
    // 0xc809fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc809fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc80a00: b               #0xc80910
  }
  _ createBoxPainter(/* No info */) {
    // ** addr: 0xccf4f4, size: 0x28
    // 0xccf4f4: EnterFrame
    //     0xccf4f4: stp             fp, lr, [SP, #-0x10]!
    //     0xccf4f8: mov             fp, SP
    // 0xccf4fc: r0 = _CupertinoEdgeShadowPainter()
    //     0xccf4fc: bl              #0xccf51c  ; Allocate_CupertinoEdgeShadowPainterStub -> _CupertinoEdgeShadowPainter (size=0x10)
    // 0xccf500: ldr             x1, [fp, #0x18]
    // 0xccf504: StoreField: r0->field_b = r1
    //     0xccf504: stur            w1, [x0, #0xb]
    // 0xccf508: ldr             x1, [fp, #0x10]
    // 0xccf50c: StoreField: r0->field_7 = r1
    //     0xccf50c: stur            w1, [x0, #7]
    // 0xccf510: LeaveFrame
    //     0xccf510: mov             SP, fp
    //     0xccf514: ldp             fp, lr, [SP], #0x10
    // 0xccf518: ret
    //     0xccf518: ret             
  }
  _ lerpTo(/* No info */) {
    // ** addr: 0xcd4b20, size: 0x98
    // 0xcd4b20: EnterFrame
    //     0xcd4b20: stp             fp, lr, [SP, #-0x10]!
    //     0xcd4b24: mov             fp, SP
    // 0xcd4b28: CheckStackOverflow
    //     0xcd4b28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd4b2c: cmp             SP, x16
    //     0xcd4b30: b.ls            #0xcd4ba8
    // 0xcd4b34: ldr             x0, [fp, #0x18]
    // 0xcd4b38: r1 = LoadClassIdInstr(r0)
    //     0xcd4b38: ldur            x1, [x0, #-1]
    //     0xcd4b3c: ubfx            x1, x1, #0xc, #0x14
    // 0xcd4b40: lsl             x1, x1, #1
    // 0xcd4b44: r17 = 5878
    //     0xcd4b44: mov             x17, #0x16f6
    // 0xcd4b48: cmp             w1, w17
    // 0xcd4b4c: b.ne            #0xcd4b7c
    // 0xcd4b50: ldr             d0, [fp, #0x10]
    // 0xcd4b54: ldr             x16, [fp, #0x20]
    // 0xcd4b58: stp             x0, x16, [SP, #-0x10]!
    // 0xcd4b5c: SaveReg d0
    //     0xcd4b5c: str             d0, [SP, #-8]!
    // 0xcd4b60: r0 = lerp()
    //     0xcd4b60: bl              #0xcd4bb8  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0xcd4b64: add             SP, SP, #0x18
    // 0xcd4b68: cmp             w0, NULL
    // 0xcd4b6c: b.eq            #0xcd4bb0
    // 0xcd4b70: LeaveFrame
    //     0xcd4b70: mov             SP, fp
    //     0xcd4b74: ldp             fp, lr, [SP], #0x10
    // 0xcd4b78: ret
    //     0xcd4b78: ret             
    // 0xcd4b7c: ldr             d0, [fp, #0x10]
    // 0xcd4b80: ldr             x16, [fp, #0x20]
    // 0xcd4b84: stp             NULL, x16, [SP, #-0x10]!
    // 0xcd4b88: SaveReg d0
    //     0xcd4b88: str             d0, [SP, #-8]!
    // 0xcd4b8c: r0 = lerp()
    //     0xcd4b8c: bl              #0xcd4bb8  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0xcd4b90: add             SP, SP, #0x18
    // 0xcd4b94: cmp             w0, NULL
    // 0xcd4b98: b.eq            #0xcd4bb4
    // 0xcd4b9c: LeaveFrame
    //     0xcd4b9c: mov             SP, fp
    //     0xcd4ba0: ldp             fp, lr, [SP], #0x10
    // 0xcd4ba4: ret
    //     0xcd4ba4: ret             
    // 0xcd4ba8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd4ba8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd4bac: b               #0xcd4b34
    // 0xcd4bb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd4bb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd4bb4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd4bb4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ lerp(/* No info */) {
    // ** addr: 0xcd4bb8, size: 0x3dc
    // 0xcd4bb8: EnterFrame
    //     0xcd4bb8: stp             fp, lr, [SP, #-0x10]!
    //     0xcd4bbc: mov             fp, SP
    // 0xcd4bc0: AllocStack(0x38)
    //     0xcd4bc0: sub             SP, SP, #0x38
    // 0xcd4bc4: CheckStackOverflow
    //     0xcd4bc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd4bc8: cmp             SP, x16
    //     0xcd4bcc: b.ls            #0xcd4f64
    // 0xcd4bd0: ldr             d0, [fp, #0x10]
    // 0xcd4bd4: r0 = inline_Allocate_Double()
    //     0xcd4bd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd4bd8: add             x0, x0, #0x10
    //     0xcd4bdc: cmp             x1, x0
    //     0xcd4be0: b.ls            #0xcd4f6c
    //     0xcd4be4: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd4be8: sub             x0, x0, #0xf
    //     0xcd4bec: mov             x1, #0xd108
    //     0xcd4bf0: movk            x1, #3, lsl #16
    //     0xcd4bf4: stur            x1, [x0, #-1]
    // 0xcd4bf8: StoreField: r0->field_7 = d0
    //     0xcd4bf8: stur            d0, [x0, #7]
    // 0xcd4bfc: stur            x0, [fp, #-8]
    // 0xcd4c00: r1 = 1
    //     0xcd4c00: mov             x1, #1
    // 0xcd4c04: r0 = AllocateContext()
    //     0xcd4c04: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd4c08: mov             x1, x0
    // 0xcd4c0c: ldur            x0, [fp, #-8]
    // 0xcd4c10: stur            x1, [fp, #-0x10]
    // 0xcd4c14: StoreField: r1->field_f = r0
    //     0xcd4c14: stur            w0, [x1, #0xf]
    // 0xcd4c18: ldr             x0, [fp, #0x20]
    // 0xcd4c1c: cmp             w0, NULL
    // 0xcd4c20: b.ne            #0xcd4c40
    // 0xcd4c24: ldr             x2, [fp, #0x18]
    // 0xcd4c28: cmp             w2, NULL
    // 0xcd4c2c: b.ne            #0xcd4c44
    // 0xcd4c30: r0 = Null
    //     0xcd4c30: mov             x0, NULL
    // 0xcd4c34: LeaveFrame
    //     0xcd4c34: mov             SP, fp
    //     0xcd4c38: ldp             fp, lr, [SP], #0x10
    // 0xcd4c3c: ret
    //     0xcd4c3c: ret             
    // 0xcd4c40: ldr             x2, [fp, #0x18]
    // 0xcd4c44: cmp             w0, NULL
    // 0xcd4c48: b.ne            #0xcd4cd4
    // 0xcd4c4c: cmp             w2, NULL
    // 0xcd4c50: b.eq            #0xcd4f7c
    // 0xcd4c54: LoadField: r0 = r2->field_7
    //     0xcd4c54: ldur            w0, [x2, #7]
    // 0xcd4c58: DecompressPointer r0
    //     0xcd4c58: add             x0, x0, HEAP, lsl #32
    // 0xcd4c5c: stur            x0, [fp, #-8]
    // 0xcd4c60: cmp             w0, NULL
    // 0xcd4c64: b.ne            #0xcd4c70
    // 0xcd4c68: mov             x0, x2
    // 0xcd4c6c: b               #0xcd4cc8
    // 0xcd4c70: mov             x2, x1
    // 0xcd4c74: r1 = Function '<anonymous closure>': static.
    //     0xcd4c74: add             x1, PP, #0x37, lsl #12  ; [pp+0x37cb8] AnonymousClosure: (0xcd504c), in [package:flutter/src/painting/gradient.dart] LinearGradient::scale (0xcd50a8)
    //     0xcd4c78: ldr             x1, [x1, #0xcb8]
    // 0xcd4c7c: r0 = AllocateClosure()
    //     0xcd4c7c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd4c80: r16 = <Color>
    //     0xcd4c80: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd4c84: ldr             x16, [x16, #0x3f8]
    // 0xcd4c88: ldur            lr, [fp, #-8]
    // 0xcd4c8c: stp             lr, x16, [SP, #-0x10]!
    // 0xcd4c90: SaveReg r0
    //     0xcd4c90: str             x0, [SP, #-8]!
    // 0xcd4c94: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcd4c94: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcd4c98: r0 = map()
    //     0xcd4c98: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xcd4c9c: add             SP, SP, #0x18
    // 0xcd4ca0: SaveReg r0
    //     0xcd4ca0: str             x0, [SP, #-8]!
    // 0xcd4ca4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcd4ca4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcd4ca8: r0 = toList()
    //     0xcd4ca8: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xcd4cac: add             SP, SP, #8
    // 0xcd4cb0: stur            x0, [fp, #-8]
    // 0xcd4cb4: r0 = _CupertinoEdgeShadowDecoration()
    //     0xcd4cb4: bl              #0xcd4f94  ; Allocate_CupertinoEdgeShadowDecorationStub -> _CupertinoEdgeShadowDecoration (size=0xc)
    // 0xcd4cb8: mov             x1, x0
    // 0xcd4cbc: ldur            x0, [fp, #-8]
    // 0xcd4cc0: StoreField: r1->field_7 = r0
    //     0xcd4cc0: stur            w0, [x1, #7]
    // 0xcd4cc4: mov             x0, x1
    // 0xcd4cc8: LeaveFrame
    //     0xcd4cc8: mov             SP, fp
    //     0xcd4ccc: ldp             fp, lr, [SP], #0x10
    // 0xcd4cd0: ret
    //     0xcd4cd0: ret             
    // 0xcd4cd4: cmp             w2, NULL
    // 0xcd4cd8: b.ne            #0xcd4d54
    // 0xcd4cdc: LoadField: r3 = r0->field_7
    //     0xcd4cdc: ldur            w3, [x0, #7]
    // 0xcd4ce0: DecompressPointer r3
    //     0xcd4ce0: add             x3, x3, HEAP, lsl #32
    // 0xcd4ce4: stur            x3, [fp, #-8]
    // 0xcd4ce8: cmp             w3, NULL
    // 0xcd4cec: b.eq            #0xcd4d48
    // 0xcd4cf0: mov             x2, x1
    // 0xcd4cf4: r1 = Function '<anonymous closure>': static.
    //     0xcd4cf4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37cc0] AnonymousClosure: static (0xcd4fa0), in [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp (0xcd4bb8)
    //     0xcd4cf8: ldr             x1, [x1, #0xcc0]
    // 0xcd4cfc: r0 = AllocateClosure()
    //     0xcd4cfc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd4d00: r16 = <Color>
    //     0xcd4d00: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd4d04: ldr             x16, [x16, #0x3f8]
    // 0xcd4d08: ldur            lr, [fp, #-8]
    // 0xcd4d0c: stp             lr, x16, [SP, #-0x10]!
    // 0xcd4d10: SaveReg r0
    //     0xcd4d10: str             x0, [SP, #-8]!
    // 0xcd4d14: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xcd4d14: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xcd4d18: r0 = map()
    //     0xcd4d18: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0xcd4d1c: add             SP, SP, #0x18
    // 0xcd4d20: SaveReg r0
    //     0xcd4d20: str             x0, [SP, #-8]!
    // 0xcd4d24: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcd4d24: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcd4d28: r0 = toList()
    //     0xcd4d28: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0xcd4d2c: add             SP, SP, #8
    // 0xcd4d30: stur            x0, [fp, #-8]
    // 0xcd4d34: r0 = _CupertinoEdgeShadowDecoration()
    //     0xcd4d34: bl              #0xcd4f94  ; Allocate_CupertinoEdgeShadowDecorationStub -> _CupertinoEdgeShadowDecoration (size=0xc)
    // 0xcd4d38: mov             x1, x0
    // 0xcd4d3c: ldur            x0, [fp, #-8]
    // 0xcd4d40: StoreField: r1->field_7 = r0
    //     0xcd4d40: stur            w0, [x1, #7]
    // 0xcd4d44: mov             x0, x1
    // 0xcd4d48: LeaveFrame
    //     0xcd4d48: mov             SP, fp
    //     0xcd4d4c: ldp             fp, lr, [SP], #0x10
    // 0xcd4d50: ret
    //     0xcd4d50: ret             
    // 0xcd4d54: r16 = <Color>
    //     0xcd4d54: add             x16, PP, #0xe, lsl #12  ; [pp+0xe3f8] TypeArguments: <Color>
    //     0xcd4d58: ldr             x16, [x16, #0x3f8]
    // 0xcd4d5c: stp             xzr, x16, [SP, #-0x10]!
    // 0xcd4d60: r0 = _GrowableList()
    //     0xcd4d60: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xcd4d64: add             SP, SP, #0x10
    // 0xcd4d68: mov             x1, x0
    // 0xcd4d6c: ldr             x0, [fp, #0x18]
    // 0xcd4d70: stur            x1, [fp, #-0x28]
    // 0xcd4d74: LoadField: r2 = r0->field_7
    //     0xcd4d74: ldur            w2, [x0, #7]
    // 0xcd4d78: DecompressPointer r2
    //     0xcd4d78: add             x2, x2, HEAP, lsl #32
    // 0xcd4d7c: stur            x2, [fp, #-0x20]
    // 0xcd4d80: cmp             w2, NULL
    // 0xcd4d84: b.eq            #0xcd4f80
    // 0xcd4d88: ldr             x0, [fp, #0x20]
    // 0xcd4d8c: LoadField: r3 = r0->field_7
    //     0xcd4d8c: ldur            w3, [x0, #7]
    // 0xcd4d90: DecompressPointer r3
    //     0xcd4d90: add             x3, x3, HEAP, lsl #32
    // 0xcd4d94: stur            x3, [fp, #-8]
    // 0xcd4d98: r5 = 0
    //     0xcd4d98: mov             x5, #0
    // 0xcd4d9c: ldur            x4, [fp, #-0x10]
    // 0xcd4da0: stur            x5, [fp, #-0x18]
    // 0xcd4da4: CheckStackOverflow
    //     0xcd4da4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd4da8: cmp             SP, x16
    //     0xcd4dac: b.ls            #0xcd4f84
    // 0xcd4db0: r0 = LoadClassIdInstr(r2)
    //     0xcd4db0: ldur            x0, [x2, #-1]
    //     0xcd4db4: ubfx            x0, x0, #0xc, #0x14
    // 0xcd4db8: SaveReg r2
    //     0xcd4db8: str             x2, [SP, #-8]!
    // 0xcd4dbc: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xcd4dbc: mov             x17, #0xb8ea
    //     0xcd4dc0: add             lr, x0, x17
    //     0xcd4dc4: ldr             lr, [x21, lr, lsl #3]
    //     0xcd4dc8: blr             lr
    // 0xcd4dcc: add             SP, SP, #8
    // 0xcd4dd0: r1 = LoadInt32Instr(r0)
    //     0xcd4dd0: sbfx            x1, x0, #1, #0x1f
    // 0xcd4dd4: ldur            x2, [fp, #-0x18]
    // 0xcd4dd8: cmp             x2, x1
    // 0xcd4ddc: b.ge            #0xcd4f48
    // 0xcd4de0: ldur            x3, [fp, #-8]
    // 0xcd4de4: cmp             w3, NULL
    // 0xcd4de8: b.ne            #0xcd4df4
    // 0xcd4dec: r6 = Null
    //     0xcd4dec: mov             x6, NULL
    // 0xcd4df0: b               #0xcd4e30
    // 0xcd4df4: r0 = BoxInt64Instr(r2)
    //     0xcd4df4: sbfiz           x0, x2, #1, #0x1f
    //     0xcd4df8: cmp             x2, x0, asr #1
    //     0xcd4dfc: b.eq            #0xcd4e08
    //     0xcd4e00: bl              #0xd69bb8
    //     0xcd4e04: stur            x2, [x0, #7]
    // 0xcd4e08: r1 = LoadClassIdInstr(r3)
    //     0xcd4e08: ldur            x1, [x3, #-1]
    //     0xcd4e0c: ubfx            x1, x1, #0xc, #0x14
    // 0xcd4e10: stp             x0, x3, [SP, #-0x10]!
    // 0xcd4e14: mov             x0, x1
    // 0xcd4e18: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd4e18: sub             lr, x0, #0xd83
    //     0xcd4e1c: ldr             lr, [x21, lr, lsl #3]
    //     0xcd4e20: blr             lr
    // 0xcd4e24: add             SP, SP, #0x10
    // 0xcd4e28: mov             x6, x0
    // 0xcd4e2c: ldur            x2, [fp, #-0x18]
    // 0xcd4e30: ldur            x5, [fp, #-0x10]
    // 0xcd4e34: ldur            x3, [fp, #-0x28]
    // 0xcd4e38: ldur            x4, [fp, #-0x20]
    // 0xcd4e3c: stur            x6, [fp, #-0x30]
    // 0xcd4e40: r0 = BoxInt64Instr(r2)
    //     0xcd4e40: sbfiz           x0, x2, #1, #0x1f
    //     0xcd4e44: cmp             x2, x0, asr #1
    //     0xcd4e48: b.eq            #0xcd4e54
    //     0xcd4e4c: bl              #0xd69bb8
    //     0xcd4e50: stur            x2, [x0, #7]
    // 0xcd4e54: r1 = LoadClassIdInstr(r4)
    //     0xcd4e54: ldur            x1, [x4, #-1]
    //     0xcd4e58: ubfx            x1, x1, #0xc, #0x14
    // 0xcd4e5c: stp             x0, x4, [SP, #-0x10]!
    // 0xcd4e60: mov             x0, x1
    // 0xcd4e64: r0 = GDT[cid_x0 + -0xd83]()
    //     0xcd4e64: sub             lr, x0, #0xd83
    //     0xcd4e68: ldr             lr, [x21, lr, lsl #3]
    //     0xcd4e6c: blr             lr
    // 0xcd4e70: add             SP, SP, #0x10
    // 0xcd4e74: mov             x1, x0
    // 0xcd4e78: ldur            x0, [fp, #-0x10]
    // 0xcd4e7c: LoadField: r2 = r0->field_f
    //     0xcd4e7c: ldur            w2, [x0, #0xf]
    // 0xcd4e80: DecompressPointer r2
    //     0xcd4e80: add             x2, x2, HEAP, lsl #32
    // 0xcd4e84: ldur            x16, [fp, #-0x30]
    // 0xcd4e88: stp             x1, x16, [SP, #-0x10]!
    // 0xcd4e8c: SaveReg r2
    //     0xcd4e8c: str             x2, [SP, #-8]!
    // 0xcd4e90: r0 = lerp()
    //     0xcd4e90: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd4e94: add             SP, SP, #0x18
    // 0xcd4e98: stur            x0, [fp, #-0x38]
    // 0xcd4e9c: cmp             w0, NULL
    // 0xcd4ea0: b.eq            #0xcd4f8c
    // 0xcd4ea4: ldur            x1, [fp, #-0x28]
    // 0xcd4ea8: LoadField: r2 = r1->field_b
    //     0xcd4ea8: ldur            w2, [x1, #0xb]
    // 0xcd4eac: DecompressPointer r2
    //     0xcd4eac: add             x2, x2, HEAP, lsl #32
    // 0xcd4eb0: stur            x2, [fp, #-0x30]
    // 0xcd4eb4: LoadField: r3 = r1->field_f
    //     0xcd4eb4: ldur            w3, [x1, #0xf]
    // 0xcd4eb8: DecompressPointer r3
    //     0xcd4eb8: add             x3, x3, HEAP, lsl #32
    // 0xcd4ebc: LoadField: r4 = r3->field_b
    //     0xcd4ebc: ldur            w4, [x3, #0xb]
    // 0xcd4ec0: DecompressPointer r4
    //     0xcd4ec0: add             x4, x4, HEAP, lsl #32
    // 0xcd4ec4: cmp             w2, w4
    // 0xcd4ec8: b.ne            #0xcd4ed8
    // 0xcd4ecc: SaveReg r1
    //     0xcd4ecc: str             x1, [SP, #-8]!
    // 0xcd4ed0: r0 = _growToNextCapacity()
    //     0xcd4ed0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xcd4ed4: add             SP, SP, #8
    // 0xcd4ed8: ldur            x2, [fp, #-0x28]
    // 0xcd4edc: ldur            x3, [fp, #-0x18]
    // 0xcd4ee0: ldur            x0, [fp, #-0x30]
    // 0xcd4ee4: r4 = LoadInt32Instr(r0)
    //     0xcd4ee4: sbfx            x4, x0, #1, #0x1f
    // 0xcd4ee8: add             x0, x4, #1
    // 0xcd4eec: lsl             x1, x0, #1
    // 0xcd4ef0: StoreField: r2->field_b = r1
    //     0xcd4ef0: stur            w1, [x2, #0xb]
    // 0xcd4ef4: mov             x1, x4
    // 0xcd4ef8: cmp             x1, x0
    // 0xcd4efc: b.hs            #0xcd4f90
    // 0xcd4f00: LoadField: r1 = r2->field_f
    //     0xcd4f00: ldur            w1, [x2, #0xf]
    // 0xcd4f04: DecompressPointer r1
    //     0xcd4f04: add             x1, x1, HEAP, lsl #32
    // 0xcd4f08: ldur            x0, [fp, #-0x38]
    // 0xcd4f0c: ArrayStore: r1[r4] = r0  ; List_4
    //     0xcd4f0c: add             x25, x1, x4, lsl #2
    //     0xcd4f10: add             x25, x25, #0xf
    //     0xcd4f14: str             w0, [x25]
    //     0xcd4f18: tbz             w0, #0, #0xcd4f34
    //     0xcd4f1c: ldurb           w16, [x1, #-1]
    //     0xcd4f20: ldurb           w17, [x0, #-1]
    //     0xcd4f24: and             x16, x17, x16, lsr #2
    //     0xcd4f28: tst             x16, HEAP, lsr #32
    //     0xcd4f2c: b.eq            #0xcd4f34
    //     0xcd4f30: bl              #0xd67e5c
    // 0xcd4f34: add             x5, x3, #1
    // 0xcd4f38: mov             x1, x2
    // 0xcd4f3c: ldur            x2, [fp, #-0x20]
    // 0xcd4f40: ldur            x3, [fp, #-8]
    // 0xcd4f44: b               #0xcd4d9c
    // 0xcd4f48: ldur            x2, [fp, #-0x28]
    // 0xcd4f4c: r0 = _CupertinoEdgeShadowDecoration()
    //     0xcd4f4c: bl              #0xcd4f94  ; Allocate_CupertinoEdgeShadowDecorationStub -> _CupertinoEdgeShadowDecoration (size=0xc)
    // 0xcd4f50: ldur            x1, [fp, #-0x28]
    // 0xcd4f54: StoreField: r0->field_7 = r1
    //     0xcd4f54: stur            w1, [x0, #7]
    // 0xcd4f58: LeaveFrame
    //     0xcd4f58: mov             SP, fp
    //     0xcd4f5c: ldp             fp, lr, [SP], #0x10
    // 0xcd4f60: ret
    //     0xcd4f60: ret             
    // 0xcd4f64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd4f64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd4f68: b               #0xcd4bd0
    // 0xcd4f6c: SaveReg d0
    //     0xcd4f6c: str             q0, [SP, #-0x10]!
    // 0xcd4f70: r0 = AllocateDouble()
    //     0xcd4f70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd4f74: RestoreReg d0
    //     0xcd4f74: ldr             q0, [SP], #0x10
    // 0xcd4f78: b               #0xcd4bf8
    // 0xcd4f7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd4f7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd4f80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd4f80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd4f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd4f84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd4f88: b               #0xcd4db0
    // 0xcd4f8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd4f8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd4f90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xcd4f90: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] static Color <anonymous closure>(dynamic, Color) {
    // ** addr: 0xcd4fa0, size: 0xac
    // 0xcd4fa0: EnterFrame
    //     0xcd4fa0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd4fa4: mov             fp, SP
    // 0xcd4fa8: d0 = 1.000000
    //     0xcd4fa8: fmov            d0, #1.00000000
    // 0xcd4fac: ldr             x0, [fp, #0x18]
    // 0xcd4fb0: LoadField: r1 = r0->field_17
    //     0xcd4fb0: ldur            w1, [x0, #0x17]
    // 0xcd4fb4: DecompressPointer r1
    //     0xcd4fb4: add             x1, x1, HEAP, lsl #32
    // 0xcd4fb8: CheckStackOverflow
    //     0xcd4fb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd4fbc: cmp             SP, x16
    //     0xcd4fc0: b.ls            #0xcd502c
    // 0xcd4fc4: LoadField: r0 = r1->field_f
    //     0xcd4fc4: ldur            w0, [x1, #0xf]
    // 0xcd4fc8: DecompressPointer r0
    //     0xcd4fc8: add             x0, x0, HEAP, lsl #32
    // 0xcd4fcc: cmp             w0, NULL
    // 0xcd4fd0: b.eq            #0xcd5034
    // 0xcd4fd4: LoadField: d1 = r0->field_7
    //     0xcd4fd4: ldur            d1, [x0, #7]
    // 0xcd4fd8: fsub            d2, d0, d1
    // 0xcd4fdc: r0 = inline_Allocate_Double()
    //     0xcd4fdc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xcd4fe0: add             x0, x0, #0x10
    //     0xcd4fe4: cmp             x1, x0
    //     0xcd4fe8: b.ls            #0xcd5038
    //     0xcd4fec: str             x0, [THR, #0x60]  ; THR::top
    //     0xcd4ff0: sub             x0, x0, #0xf
    //     0xcd4ff4: mov             x1, #0xd108
    //     0xcd4ff8: movk            x1, #3, lsl #16
    //     0xcd4ffc: stur            x1, [x0, #-1]
    // 0xcd5000: StoreField: r0->field_7 = d2
    //     0xcd5000: stur            d2, [x0, #7]
    // 0xcd5004: ldr             x16, [fp, #0x10]
    // 0xcd5008: stp             x16, NULL, [SP, #-0x10]!
    // 0xcd500c: SaveReg r0
    //     0xcd500c: str             x0, [SP, #-8]!
    // 0xcd5010: r0 = lerp()
    //     0xcd5010: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xcd5014: add             SP, SP, #0x18
    // 0xcd5018: cmp             w0, NULL
    // 0xcd501c: b.eq            #0xcd5048
    // 0xcd5020: LeaveFrame
    //     0xcd5020: mov             SP, fp
    //     0xcd5024: ldp             fp, lr, [SP], #0x10
    // 0xcd5028: ret
    //     0xcd5028: ret             
    // 0xcd502c: r0 = StackOverflowSharedWithFPURegs()
    //     0xcd502c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xcd5030: b               #0xcd4fc4
    // 0xcd5034: r0 = NullErrorSharedWithFPURegs()
    //     0xcd5034: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0xcd5038: SaveReg d2
    //     0xcd5038: str             q2, [SP, #-0x10]!
    // 0xcd503c: r0 = AllocateDouble()
    //     0xcd503c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xcd5040: RestoreReg d2
    //     0xcd5040: ldr             q2, [SP], #0x10
    // 0xcd5044: b               #0xcd5000
    // 0xcd5048: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd5048: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ lerpFrom(/* No info */) {
    // ** addr: 0xcd7110, size: 0x98
    // 0xcd7110: EnterFrame
    //     0xcd7110: stp             fp, lr, [SP, #-0x10]!
    //     0xcd7114: mov             fp, SP
    // 0xcd7118: CheckStackOverflow
    //     0xcd7118: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd711c: cmp             SP, x16
    //     0xcd7120: b.ls            #0xcd7198
    // 0xcd7124: ldr             x0, [fp, #0x18]
    // 0xcd7128: r1 = LoadClassIdInstr(r0)
    //     0xcd7128: ldur            x1, [x0, #-1]
    //     0xcd712c: ubfx            x1, x1, #0xc, #0x14
    // 0xcd7130: lsl             x1, x1, #1
    // 0xcd7134: r17 = 5878
    //     0xcd7134: mov             x17, #0x16f6
    // 0xcd7138: cmp             w1, w17
    // 0xcd713c: b.ne            #0xcd716c
    // 0xcd7140: ldr             d0, [fp, #0x10]
    // 0xcd7144: ldr             x16, [fp, #0x20]
    // 0xcd7148: stp             x16, x0, [SP, #-0x10]!
    // 0xcd714c: SaveReg d0
    //     0xcd714c: str             d0, [SP, #-8]!
    // 0xcd7150: r0 = lerp()
    //     0xcd7150: bl              #0xcd4bb8  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0xcd7154: add             SP, SP, #0x18
    // 0xcd7158: cmp             w0, NULL
    // 0xcd715c: b.eq            #0xcd71a0
    // 0xcd7160: LeaveFrame
    //     0xcd7160: mov             SP, fp
    //     0xcd7164: ldp             fp, lr, [SP], #0x10
    // 0xcd7168: ret
    //     0xcd7168: ret             
    // 0xcd716c: ldr             d0, [fp, #0x10]
    // 0xcd7170: ldr             x16, [fp, #0x20]
    // 0xcd7174: stp             x16, NULL, [SP, #-0x10]!
    // 0xcd7178: SaveReg d0
    //     0xcd7178: str             d0, [SP, #-8]!
    // 0xcd717c: r0 = lerp()
    //     0xcd717c: bl              #0xcd4bb8  ; [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::lerp
    // 0xcd7180: add             SP, SP, #0x18
    // 0xcd7184: cmp             w0, NULL
    // 0xcd7188: b.eq            #0xcd71a4
    // 0xcd718c: LeaveFrame
    //     0xcd718c: mov             SP, fp
    //     0xcd7190: ldp             fp, lr, [SP], #0x10
    // 0xcd7194: ret
    //     0xcd7194: ret             
    // 0xcd7198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd7198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd719c: b               #0xcd7124
    // 0xcd71a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd71a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd71a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd71a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3353, size: 0x1c, field offset: 0x14
class _CupertinoBackGestureDetectorState<_CupertinoBackGestureDetector<C1X0>> extends State<_CupertinoBackGestureDetector<C1X0>> {

  late HorizontalDragGestureRecognizer _recognizer; // offset: 0x18

  _ build(/* No info */) {
    // ** addr: 0x84125c, size: 0x22c
    // 0x84125c: EnterFrame
    //     0x84125c: stp             fp, lr, [SP, #-0x10]!
    //     0x841260: mov             fp, SP
    // 0x841264: AllocStack(0x20)
    //     0x841264: sub             SP, SP, #0x20
    // 0x841268: CheckStackOverflow
    //     0x841268: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x84126c: cmp             SP, x16
    //     0x841270: b.ls            #0x841464
    // 0x841274: ldr             x16, [fp, #0x10]
    // 0x841278: SaveReg r16
    //     0x841278: str             x16, [SP, #-8]!
    // 0x84127c: r0 = of()
    //     0x84127c: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x841280: add             SP, SP, #8
    // 0x841284: r16 = Instance_TextDirection
    //     0x841284: ldr             x16, [PP, #0x4808]  ; [pp+0x4808] Obj!TextDirection@b66e31
    // 0x841288: cmp             w0, w16
    // 0x84128c: b.ne            #0x8412b4
    // 0x841290: ldr             x16, [fp, #0x10]
    // 0x841294: SaveReg r16
    //     0x841294: str             x16, [SP, #-8]!
    // 0x841298: r0 = of()
    //     0x841298: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x84129c: add             SP, SP, #8
    // 0x8412a0: LoadField: r1 = r0->field_23
    //     0x8412a0: ldur            w1, [x0, #0x23]
    // 0x8412a4: DecompressPointer r1
    //     0x8412a4: add             x1, x1, HEAP, lsl #32
    // 0x8412a8: LoadField: d0 = r1->field_7
    //     0x8412a8: ldur            d0, [x1, #7]
    // 0x8412ac: mov             v1.16b, v0.16b
    // 0x8412b0: b               #0x8412d4
    // 0x8412b4: ldr             x16, [fp, #0x10]
    // 0x8412b8: SaveReg r16
    //     0x8412b8: str             x16, [SP, #-8]!
    // 0x8412bc: r0 = of()
    //     0x8412bc: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x8412c0: add             SP, SP, #8
    // 0x8412c4: LoadField: r1 = r0->field_23
    //     0x8412c4: ldur            w1, [x0, #0x23]
    // 0x8412c8: DecompressPointer r1
    //     0x8412c8: add             x1, x1, HEAP, lsl #32
    // 0x8412cc: LoadField: d0 = r1->field_17
    //     0x8412cc: ldur            d0, [x1, #0x17]
    // 0x8412d0: mov             v1.16b, v0.16b
    // 0x8412d4: d0 = 20.000000
    //     0x8412d4: fmov            d0, #20.00000000
    // 0x8412d8: fcmp            d1, d0
    // 0x8412dc: b.vs            #0x8412ec
    // 0x8412e0: b.le            #0x8412ec
    // 0x8412e4: mov             v0.16b, v1.16b
    // 0x8412e8: b               #0x841320
    // 0x8412ec: fcmp            d1, d0
    // 0x8412f0: b.vs            #0x841300
    // 0x8412f4: b.ge            #0x841300
    // 0x8412f8: d0 = 20.000000
    //     0x8412f8: fmov            d0, #20.00000000
    // 0x8412fc: b               #0x841320
    // 0x841300: d2 = 0.000000
    //     0x841300: eor             v2.16b, v2.16b, v2.16b
    // 0x841304: fcmp            d1, d2
    // 0x841308: b.vs            #0x84131c
    // 0x84130c: b.ne            #0x84131c
    // 0x841310: fadd            d2, d1, d0
    // 0x841314: mov             v0.16b, v2.16b
    // 0x841318: b               #0x841320
    // 0x84131c: mov             v0.16b, v1.16b
    // 0x841320: ldr             x0, [fp, #0x18]
    // 0x841324: stur            d0, [fp, #-0x20]
    // 0x841328: LoadField: r1 = r0->field_b
    //     0x841328: ldur            w1, [x0, #0xb]
    // 0x84132c: DecompressPointer r1
    //     0x84132c: add             x1, x1, HEAP, lsl #32
    // 0x841330: cmp             w1, NULL
    // 0x841334: b.eq            #0x84146c
    // 0x841338: LoadField: r2 = r1->field_f
    //     0x841338: ldur            w2, [x1, #0xf]
    // 0x84133c: DecompressPointer r2
    //     0x84133c: add             x2, x2, HEAP, lsl #32
    // 0x841340: stur            x2, [fp, #-8]
    // 0x841344: r1 = 1
    //     0x841344: mov             x1, #1
    // 0x841348: r0 = AllocateContext()
    //     0x841348: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84134c: mov             x1, x0
    // 0x841350: ldr             x0, [fp, #0x18]
    // 0x841354: stur            x1, [fp, #-0x10]
    // 0x841358: StoreField: r1->field_f = r0
    //     0x841358: stur            w0, [x1, #0xf]
    // 0x84135c: r0 = Listener()
    //     0x84135c: bl              #0x82af60  ; AllocateListenerStub -> Listener (size=0x38)
    // 0x841360: ldur            x2, [fp, #-0x10]
    // 0x841364: r1 = Function '_handlePointerDown@609053933':.
    //     0x841364: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bac8] AnonymousClosure: (0x841494), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handlePointerDown (0x8414e0)
    //     0x841368: ldr             x1, [x1, #0xac8]
    // 0x84136c: stur            x0, [fp, #-0x10]
    // 0x841370: r0 = AllocateClosure()
    //     0x841370: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x841374: mov             x1, x0
    // 0x841378: ldur            x0, [fp, #-0x10]
    // 0x84137c: StoreField: r0->field_f = r1
    //     0x84137c: stur            w1, [x0, #0xf]
    // 0x841380: r1 = Instance_HitTestBehavior
    //     0x841380: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x841384: ldr             x1, [x1, #0xed0]
    // 0x841388: StoreField: r0->field_33 = r1
    //     0x841388: stur            w1, [x0, #0x33]
    // 0x84138c: r0 = PositionedDirectional()
    //     0x84138c: bl              #0x841488  ; AllocatePositionedDirectionalStub -> PositionedDirectional (size=0x28)
    // 0x841390: mov             x3, x0
    // 0x841394: r0 = 0.000000
    //     0x841394: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x841398: stur            x3, [fp, #-0x18]
    // 0x84139c: StoreField: r3->field_b = r0
    //     0x84139c: stur            w0, [x3, #0xb]
    // 0x8413a0: StoreField: r3->field_f = r0
    //     0x8413a0: stur            w0, [x3, #0xf]
    // 0x8413a4: StoreField: r3->field_17 = r0
    //     0x8413a4: stur            w0, [x3, #0x17]
    // 0x8413a8: ldur            d0, [fp, #-0x20]
    // 0x8413ac: r0 = inline_Allocate_Double()
    //     0x8413ac: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x8413b0: add             x0, x0, #0x10
    //     0x8413b4: cmp             x1, x0
    //     0x8413b8: b.ls            #0x841470
    //     0x8413bc: str             x0, [THR, #0x60]  ; THR::top
    //     0x8413c0: sub             x0, x0, #0xf
    //     0x8413c4: mov             x1, #0xd108
    //     0x8413c8: movk            x1, #3, lsl #16
    //     0x8413cc: stur            x1, [x0, #-1]
    // 0x8413d0: StoreField: r0->field_7 = d0
    //     0x8413d0: stur            d0, [x0, #7]
    // 0x8413d4: StoreField: r3->field_1b = r0
    //     0x8413d4: stur            w0, [x3, #0x1b]
    // 0x8413d8: ldur            x0, [fp, #-0x10]
    // 0x8413dc: StoreField: r3->field_23 = r0
    //     0x8413dc: stur            w0, [x3, #0x23]
    // 0x8413e0: r1 = Null
    //     0x8413e0: mov             x1, NULL
    // 0x8413e4: r2 = 4
    //     0x8413e4: mov             x2, #4
    // 0x8413e8: r0 = AllocateArray()
    //     0x8413e8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8413ec: mov             x2, x0
    // 0x8413f0: ldur            x0, [fp, #-8]
    // 0x8413f4: stur            x2, [fp, #-0x10]
    // 0x8413f8: StoreField: r2->field_f = r0
    //     0x8413f8: stur            w0, [x2, #0xf]
    // 0x8413fc: ldur            x0, [fp, #-0x18]
    // 0x841400: StoreField: r2->field_13 = r0
    //     0x841400: stur            w0, [x2, #0x13]
    // 0x841404: r1 = <Widget>
    //     0x841404: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x841408: ldr             x1, [x1, #0xea8]
    // 0x84140c: r0 = AllocateGrowableArray()
    //     0x84140c: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x841410: mov             x1, x0
    // 0x841414: ldur            x0, [fp, #-0x10]
    // 0x841418: stur            x1, [fp, #-8]
    // 0x84141c: StoreField: r1->field_f = r0
    //     0x84141c: stur            w0, [x1, #0xf]
    // 0x841420: r0 = 4
    //     0x841420: mov             x0, #4
    // 0x841424: StoreField: r1->field_b = r0
    //     0x841424: stur            w0, [x1, #0xb]
    // 0x841428: r0 = Stack()
    //     0x841428: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x84142c: r1 = Instance_AlignmentDirectional
    //     0x84142c: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x841430: ldr             x1, [x1, #0xf70]
    // 0x841434: StoreField: r0->field_f = r1
    //     0x841434: stur            w1, [x0, #0xf]
    // 0x841438: r1 = Instance_StackFit
    //     0x841438: add             x1, PP, #0x2f, lsl #12  ; [pp+0x2f8f0] Obj!StackFit@b64791
    //     0x84143c: ldr             x1, [x1, #0x8f0]
    // 0x841440: StoreField: r0->field_17 = r1
    //     0x841440: stur            w1, [x0, #0x17]
    // 0x841444: r1 = Instance_Clip
    //     0x841444: add             x1, PP, #0xe, lsl #12  ; [pp+0xe678] Obj!Clip@b67691
    //     0x841448: ldr             x1, [x1, #0x678]
    // 0x84144c: StoreField: r0->field_1b = r1
    //     0x84144c: stur            w1, [x0, #0x1b]
    // 0x841450: ldur            x1, [fp, #-8]
    // 0x841454: StoreField: r0->field_b = r1
    //     0x841454: stur            w1, [x0, #0xb]
    // 0x841458: LeaveFrame
    //     0x841458: mov             SP, fp
    //     0x84145c: ldp             fp, lr, [SP], #0x10
    // 0x841460: ret
    //     0x841460: ret             
    // 0x841464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x841464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841468: b               #0x841274
    // 0x84146c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x84146c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x841470: SaveReg d0
    //     0x841470: str             q0, [SP, #-0x10]!
    // 0x841474: SaveReg r3
    //     0x841474: str             x3, [SP, #-8]!
    // 0x841478: r0 = AllocateDouble()
    //     0x841478: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x84147c: RestoreReg r3
    //     0x84147c: ldr             x3, [SP], #8
    // 0x841480: RestoreReg d0
    //     0x841480: ldr             q0, [SP], #0x10
    // 0x841484: b               #0x8413d0
  }
  [closure] void _handlePointerDown(dynamic, PointerDownEvent) {
    // ** addr: 0x841494, size: 0x4c
    // 0x841494: EnterFrame
    //     0x841494: stp             fp, lr, [SP, #-0x10]!
    //     0x841498: mov             fp, SP
    // 0x84149c: ldr             x0, [fp, #0x18]
    // 0x8414a0: LoadField: r1 = r0->field_17
    //     0x8414a0: ldur            w1, [x0, #0x17]
    // 0x8414a4: DecompressPointer r1
    //     0x8414a4: add             x1, x1, HEAP, lsl #32
    // 0x8414a8: CheckStackOverflow
    //     0x8414a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8414ac: cmp             SP, x16
    //     0x8414b0: b.ls            #0x8414d8
    // 0x8414b4: LoadField: r0 = r1->field_f
    //     0x8414b4: ldur            w0, [x1, #0xf]
    // 0x8414b8: DecompressPointer r0
    //     0x8414b8: add             x0, x0, HEAP, lsl #32
    // 0x8414bc: ldr             x16, [fp, #0x10]
    // 0x8414c0: stp             x16, x0, [SP, #-0x10]!
    // 0x8414c4: r0 = _handlePointerDown()
    //     0x8414c4: bl              #0x8414e0  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handlePointerDown
    // 0x8414c8: add             SP, SP, #0x10
    // 0x8414cc: LeaveFrame
    //     0x8414cc: mov             SP, fp
    //     0x8414d0: ldp             fp, lr, [SP], #0x10
    // 0x8414d4: ret
    //     0x8414d4: ret             
    // 0x8414d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8414d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8414dc: b               #0x8414b4
  }
  _ _handlePointerDown(/* No info */) {
    // ** addr: 0x8414e0, size: 0xb4
    // 0x8414e0: EnterFrame
    //     0x8414e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8414e4: mov             fp, SP
    // 0x8414e8: AllocStack(0x8)
    //     0x8414e8: sub             SP, SP, #8
    // 0x8414ec: CheckStackOverflow
    //     0x8414ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8414f0: cmp             SP, x16
    //     0x8414f4: b.ls            #0x84157c
    // 0x8414f8: ldr             x1, [fp, #0x18]
    // 0x8414fc: LoadField: r0 = r1->field_b
    //     0x8414fc: ldur            w0, [x1, #0xb]
    // 0x841500: DecompressPointer r0
    //     0x841500: add             x0, x0, HEAP, lsl #32
    // 0x841504: cmp             w0, NULL
    // 0x841508: b.eq            #0x841584
    // 0x84150c: LoadField: r2 = r0->field_13
    //     0x84150c: ldur            w2, [x0, #0x13]
    // 0x841510: DecompressPointer r2
    //     0x841510: add             x2, x2, HEAP, lsl #32
    // 0x841514: SaveReg r2
    //     0x841514: str             x2, [SP, #-8]!
    // 0x841518: mov             x0, x2
    // 0x84151c: ClosureCall
    //     0x84151c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x841520: ldur            x2, [x0, #0x1f]
    //     0x841524: blr             x2
    // 0x841528: add             SP, SP, #8
    // 0x84152c: mov             x1, x0
    // 0x841530: stur            x1, [fp, #-8]
    // 0x841534: tbnz            w0, #5, #0x84153c
    // 0x841538: r0 = AssertBoolean()
    //     0x841538: bl              #0xd67df0  ; AssertBooleanStub
    // 0x84153c: ldur            x0, [fp, #-8]
    // 0x841540: tbnz            w0, #4, #0x84156c
    // 0x841544: ldr             x0, [fp, #0x18]
    // 0x841548: LoadField: r1 = r0->field_17
    //     0x841548: ldur            w1, [x0, #0x17]
    // 0x84154c: DecompressPointer r1
    //     0x84154c: add             x1, x1, HEAP, lsl #32
    // 0x841550: r16 = Sentinel
    //     0x841550: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x841554: cmp             w1, w16
    // 0x841558: b.eq            #0x841588
    // 0x84155c: ldr             x16, [fp, #0x10]
    // 0x841560: stp             x16, x1, [SP, #-0x10]!
    // 0x841564: r0 = addPointer()
    //     0x841564: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x841568: add             SP, SP, #0x10
    // 0x84156c: r0 = Null
    //     0x84156c: mov             x0, NULL
    // 0x841570: LeaveFrame
    //     0x841570: mov             SP, fp
    //     0x841574: ldp             fp, lr, [SP], #0x10
    // 0x841578: ret
    //     0x841578: ret             
    // 0x84157c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x84157c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841580: b               #0x8414f8
    // 0x841584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x841584: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x841588: r9 = _recognizer
    //     0x841588: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bad0] Field <_CupertinoBackGestureDetectorState@609053933._recognizer@609053933>: late (offset: 0x18)
    //     0x84158c: ldr             x9, [x9, #0xad0]
    // 0x841590: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x841590: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d7954, size: 0x178
    // 0x9d7954: EnterFrame
    //     0x9d7954: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7958: mov             fp, SP
    // 0x9d795c: AllocStack(0x8)
    //     0x9d795c: sub             SP, SP, #8
    // 0x9d7960: CheckStackOverflow
    //     0x9d7960: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7964: cmp             SP, x16
    //     0x9d7968: b.ls            #0x9d7ac4
    // 0x9d796c: r0 = HorizontalDragGestureRecognizer()
    //     0x9d796c: bl              #0x6ee4e8  ; AllocateHorizontalDragGestureRecognizerStub -> HorizontalDragGestureRecognizer (size=0x6c)
    // 0x9d7970: stur            x0, [fp, #-8]
    // 0x9d7974: stp             NULL, x0, [SP, #-0x10]!
    // 0x9d7978: r0 = DragGestureRecognizer()
    //     0x9d7978: bl              #0x6ee278  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0x9d797c: add             SP, SP, #0x10
    // 0x9d7980: r1 = 1
    //     0x9d7980: mov             x1, #1
    // 0x9d7984: r0 = AllocateContext()
    //     0x9d7984: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7988: mov             x1, x0
    // 0x9d798c: ldr             x0, [fp, #0x10]
    // 0x9d7990: StoreField: r1->field_f = r0
    //     0x9d7990: stur            w0, [x1, #0xf]
    // 0x9d7994: mov             x2, x1
    // 0x9d7998: r1 = Function '_handleDragStart@609053933':.
    //     0x9d7998: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bad8] AnonymousClosure: (0x9d8990), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragStart (0x9d89dc)
    //     0x9d799c: ldr             x1, [x1, #0xad8]
    // 0x9d79a0: r0 = AllocateClosure()
    //     0x9d79a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d79a4: ldur            x1, [fp, #-8]
    // 0x9d79a8: StoreField: r1->field_27 = r0
    //     0x9d79a8: stur            w0, [x1, #0x27]
    //     0x9d79ac: ldurb           w16, [x1, #-1]
    //     0x9d79b0: ldurb           w17, [x0, #-1]
    //     0x9d79b4: and             x16, x17, x16, lsr #2
    //     0x9d79b8: tst             x16, HEAP, lsr #32
    //     0x9d79bc: b.eq            #0x9d79c4
    //     0x9d79c0: bl              #0xd6826c
    // 0x9d79c4: r1 = 1
    //     0x9d79c4: mov             x1, #1
    // 0x9d79c8: r0 = AllocateContext()
    //     0x9d79c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d79cc: mov             x1, x0
    // 0x9d79d0: ldr             x0, [fp, #0x10]
    // 0x9d79d4: StoreField: r1->field_f = r0
    //     0x9d79d4: stur            w0, [x1, #0xf]
    // 0x9d79d8: mov             x2, x1
    // 0x9d79dc: r1 = Function '_handleDragUpdate@609053933':.
    //     0x9d79dc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bae0] AnonymousClosure: (0x9d87f8), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragUpdate (0x9d8844)
    //     0x9d79e0: ldr             x1, [x1, #0xae0]
    // 0x9d79e4: r0 = AllocateClosure()
    //     0x9d79e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d79e8: ldur            x1, [fp, #-8]
    // 0x9d79ec: StoreField: r1->field_2b = r0
    //     0x9d79ec: stur            w0, [x1, #0x2b]
    //     0x9d79f0: ldurb           w16, [x1, #-1]
    //     0x9d79f4: ldurb           w17, [x0, #-1]
    //     0x9d79f8: and             x16, x17, x16, lsr #2
    //     0x9d79fc: tst             x16, HEAP, lsr #32
    //     0x9d7a00: b.eq            #0x9d7a08
    //     0x9d7a04: bl              #0xd6826c
    // 0x9d7a08: r1 = 1
    //     0x9d7a08: mov             x1, #1
    // 0x9d7a0c: r0 = AllocateContext()
    //     0x9d7a0c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7a10: mov             x1, x0
    // 0x9d7a14: ldr             x0, [fp, #0x10]
    // 0x9d7a18: StoreField: r1->field_f = r0
    //     0x9d7a18: stur            w0, [x1, #0xf]
    // 0x9d7a1c: mov             x2, x1
    // 0x9d7a20: r1 = Function '_handleDragEnd@609053933':.
    //     0x9d7a20: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bae8] AnonymousClosure: (0x9d8580), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragEnd (0x9d85cc)
    //     0x9d7a24: ldr             x1, [x1, #0xae8]
    // 0x9d7a28: r0 = AllocateClosure()
    //     0x9d7a28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7a2c: ldur            x1, [fp, #-8]
    // 0x9d7a30: StoreField: r1->field_2f = r0
    //     0x9d7a30: stur            w0, [x1, #0x2f]
    //     0x9d7a34: ldurb           w16, [x1, #-1]
    //     0x9d7a38: ldurb           w17, [x0, #-1]
    //     0x9d7a3c: and             x16, x17, x16, lsr #2
    //     0x9d7a40: tst             x16, HEAP, lsr #32
    //     0x9d7a44: b.eq            #0x9d7a4c
    //     0x9d7a48: bl              #0xd6826c
    // 0x9d7a4c: r1 = 1
    //     0x9d7a4c: mov             x1, #1
    // 0x9d7a50: r0 = AllocateContext()
    //     0x9d7a50: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7a54: mov             x1, x0
    // 0x9d7a58: ldr             x0, [fp, #0x10]
    // 0x9d7a5c: StoreField: r1->field_f = r0
    //     0x9d7a5c: stur            w0, [x1, #0xf]
    // 0x9d7a60: mov             x2, x1
    // 0x9d7a64: r1 = Function '_handleDragCancel@609053933':.
    //     0x9d7a64: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4baf0] AnonymousClosure: (0x9d7acc), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragCancel (0x9d7b14)
    //     0x9d7a68: ldr             x1, [x1, #0xaf0]
    // 0x9d7a6c: r0 = AllocateClosure()
    //     0x9d7a6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7a70: ldur            x1, [fp, #-8]
    // 0x9d7a74: StoreField: r1->field_33 = r0
    //     0x9d7a74: stur            w0, [x1, #0x33]
    //     0x9d7a78: ldurb           w16, [x1, #-1]
    //     0x9d7a7c: ldurb           w17, [x0, #-1]
    //     0x9d7a80: and             x16, x17, x16, lsr #2
    //     0x9d7a84: tst             x16, HEAP, lsr #32
    //     0x9d7a88: b.eq            #0x9d7a90
    //     0x9d7a8c: bl              #0xd6826c
    // 0x9d7a90: mov             x0, x1
    // 0x9d7a94: ldr             x1, [fp, #0x10]
    // 0x9d7a98: StoreField: r1->field_17 = r0
    //     0x9d7a98: stur            w0, [x1, #0x17]
    //     0x9d7a9c: ldurb           w16, [x1, #-1]
    //     0x9d7aa0: ldurb           w17, [x0, #-1]
    //     0x9d7aa4: and             x16, x17, x16, lsr #2
    //     0x9d7aa8: tst             x16, HEAP, lsr #32
    //     0x9d7aac: b.eq            #0x9d7ab4
    //     0x9d7ab0: bl              #0xd6826c
    // 0x9d7ab4: r0 = Null
    //     0x9d7ab4: mov             x0, NULL
    // 0x9d7ab8: LeaveFrame
    //     0x9d7ab8: mov             SP, fp
    //     0x9d7abc: ldp             fp, lr, [SP], #0x10
    // 0x9d7ac0: ret
    //     0x9d7ac0: ret             
    // 0x9d7ac4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7ac4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7ac8: b               #0x9d796c
  }
  [closure] void _handleDragCancel(dynamic) {
    // ** addr: 0x9d7acc, size: 0x48
    // 0x9d7acc: EnterFrame
    //     0x9d7acc: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7ad0: mov             fp, SP
    // 0x9d7ad4: ldr             x0, [fp, #0x10]
    // 0x9d7ad8: LoadField: r1 = r0->field_17
    //     0x9d7ad8: ldur            w1, [x0, #0x17]
    // 0x9d7adc: DecompressPointer r1
    //     0x9d7adc: add             x1, x1, HEAP, lsl #32
    // 0x9d7ae0: CheckStackOverflow
    //     0x9d7ae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7ae4: cmp             SP, x16
    //     0x9d7ae8: b.ls            #0x9d7b0c
    // 0x9d7aec: LoadField: r0 = r1->field_f
    //     0x9d7aec: ldur            w0, [x1, #0xf]
    // 0x9d7af0: DecompressPointer r0
    //     0x9d7af0: add             x0, x0, HEAP, lsl #32
    // 0x9d7af4: SaveReg r0
    //     0x9d7af4: str             x0, [SP, #-8]!
    // 0x9d7af8: r0 = _handleDragCancel()
    //     0x9d7af8: bl              #0x9d7b14  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragCancel
    // 0x9d7afc: add             SP, SP, #8
    // 0x9d7b00: LeaveFrame
    //     0x9d7b00: mov             SP, fp
    //     0x9d7b04: ldp             fp, lr, [SP], #0x10
    // 0x9d7b08: ret
    //     0x9d7b08: ret             
    // 0x9d7b0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7b0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7b10: b               #0x9d7aec
  }
  _ _handleDragCancel(/* No info */) {
    // ** addr: 0x9d7b14, size: 0x60
    // 0x9d7b14: EnterFrame
    //     0x9d7b14: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7b18: mov             fp, SP
    // 0x9d7b1c: CheckStackOverflow
    //     0x9d7b1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7b20: cmp             SP, x16
    //     0x9d7b24: b.ls            #0x9d7b6c
    // 0x9d7b28: ldr             x0, [fp, #0x10]
    // 0x9d7b2c: LoadField: r1 = r0->field_13
    //     0x9d7b2c: ldur            w1, [x0, #0x13]
    // 0x9d7b30: DecompressPointer r1
    //     0x9d7b30: add             x1, x1, HEAP, lsl #32
    // 0x9d7b34: cmp             w1, NULL
    // 0x9d7b38: b.ne            #0x9d7b44
    // 0x9d7b3c: mov             x1, x0
    // 0x9d7b40: b               #0x9d7b58
    // 0x9d7b44: r16 = 0.000000
    //     0x9d7b44: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x9d7b48: stp             x16, x1, [SP, #-0x10]!
    // 0x9d7b4c: r0 = dragEnd()
    //     0x9d7b4c: bl              #0x9d7b74  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureController::dragEnd
    // 0x9d7b50: add             SP, SP, #0x10
    // 0x9d7b54: ldr             x1, [fp, #0x10]
    // 0x9d7b58: StoreField: r1->field_13 = rNULL
    //     0x9d7b58: stur            NULL, [x1, #0x13]
    // 0x9d7b5c: r0 = Null
    //     0x9d7b5c: mov             x0, NULL
    // 0x9d7b60: LeaveFrame
    //     0x9d7b60: mov             SP, fp
    //     0x9d7b64: ldp             fp, lr, [SP], #0x10
    // 0x9d7b68: ret
    //     0x9d7b68: ret             
    // 0x9d7b6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7b6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7b70: b               #0x9d7b28
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x9d8580, size: 0x4c
    // 0x9d8580: EnterFrame
    //     0x9d8580: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8584: mov             fp, SP
    // 0x9d8588: ldr             x0, [fp, #0x18]
    // 0x9d858c: LoadField: r1 = r0->field_17
    //     0x9d858c: ldur            w1, [x0, #0x17]
    // 0x9d8590: DecompressPointer r1
    //     0x9d8590: add             x1, x1, HEAP, lsl #32
    // 0x9d8594: CheckStackOverflow
    //     0x9d8594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8598: cmp             SP, x16
    //     0x9d859c: b.ls            #0x9d85c4
    // 0x9d85a0: LoadField: r0 = r1->field_f
    //     0x9d85a0: ldur            w0, [x1, #0xf]
    // 0x9d85a4: DecompressPointer r0
    //     0x9d85a4: add             x0, x0, HEAP, lsl #32
    // 0x9d85a8: ldr             x16, [fp, #0x10]
    // 0x9d85ac: stp             x16, x0, [SP, #-0x10]!
    // 0x9d85b0: r0 = _handleDragEnd()
    //     0x9d85b0: bl              #0x9d85cc  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragEnd
    // 0x9d85b4: add             SP, SP, #0x10
    // 0x9d85b8: LeaveFrame
    //     0x9d85b8: mov             SP, fp
    //     0x9d85bc: ldp             fp, lr, [SP], #0x10
    // 0x9d85c0: ret
    //     0x9d85c0: ret             
    // 0x9d85c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d85c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d85c8: b               #0x9d85a0
  }
  _ _handleDragEnd(/* No info */) {
    // ** addr: 0x9d85cc, size: 0xcc
    // 0x9d85cc: EnterFrame
    //     0x9d85cc: stp             fp, lr, [SP, #-0x10]!
    //     0x9d85d0: mov             fp, SP
    // 0x9d85d4: AllocStack(0x10)
    //     0x9d85d4: sub             SP, SP, #0x10
    // 0x9d85d8: CheckStackOverflow
    //     0x9d85d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d85dc: cmp             SP, x16
    //     0x9d85e0: b.ls            #0x9d8684
    // 0x9d85e4: ldr             x0, [fp, #0x18]
    // 0x9d85e8: LoadField: r1 = r0->field_13
    //     0x9d85e8: ldur            w1, [x0, #0x13]
    // 0x9d85ec: DecompressPointer r1
    //     0x9d85ec: add             x1, x1, HEAP, lsl #32
    // 0x9d85f0: stur            x1, [fp, #-8]
    // 0x9d85f4: cmp             w1, NULL
    // 0x9d85f8: b.eq            #0x9d868c
    // 0x9d85fc: ldr             x2, [fp, #0x10]
    // 0x9d8600: LoadField: r3 = r2->field_7
    //     0x9d8600: ldur            w3, [x2, #7]
    // 0x9d8604: DecompressPointer r3
    //     0x9d8604: add             x3, x3, HEAP, lsl #32
    // 0x9d8608: LoadField: r2 = r3->field_7
    //     0x9d8608: ldur            w2, [x3, #7]
    // 0x9d860c: DecompressPointer r2
    //     0x9d860c: add             x2, x2, HEAP, lsl #32
    // 0x9d8610: LoadField: d0 = r2->field_7
    //     0x9d8610: ldur            d0, [x2, #7]
    // 0x9d8614: stur            d0, [fp, #-0x10]
    // 0x9d8618: LoadField: r2 = r0->field_f
    //     0x9d8618: ldur            w2, [x0, #0xf]
    // 0x9d861c: DecompressPointer r2
    //     0x9d861c: add             x2, x2, HEAP, lsl #32
    // 0x9d8620: cmp             w2, NULL
    // 0x9d8624: b.eq            #0x9d8690
    // 0x9d8628: SaveReg r2
    //     0x9d8628: str             x2, [SP, #-8]!
    // 0x9d862c: r0 = size()
    //     0x9d862c: bl              #0x9d8778  ; [package:flutter/src/widgets/framework.dart] Element::size
    // 0x9d8630: add             SP, SP, #8
    // 0x9d8634: cmp             w0, NULL
    // 0x9d8638: b.eq            #0x9d8694
    // 0x9d863c: LoadField: d0 = r0->field_7
    //     0x9d863c: ldur            d0, [x0, #7]
    // 0x9d8640: ldur            d1, [fp, #-0x10]
    // 0x9d8644: fdiv            d2, d1, d0
    // 0x9d8648: ldr             x16, [fp, #0x18]
    // 0x9d864c: SaveReg r16
    //     0x9d864c: str             x16, [SP, #-8]!
    // 0x9d8650: SaveReg d2
    //     0x9d8650: str             d2, [SP, #-8]!
    // 0x9d8654: r0 = _convertToLogical()
    //     0x9d8654: bl              #0x9d8698  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_convertToLogical
    // 0x9d8658: add             SP, SP, #0x10
    // 0x9d865c: ldur            x16, [fp, #-8]
    // 0x9d8660: stp             x0, x16, [SP, #-0x10]!
    // 0x9d8664: r0 = dragEnd()
    //     0x9d8664: bl              #0x9d7b74  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureController::dragEnd
    // 0x9d8668: add             SP, SP, #0x10
    // 0x9d866c: ldr             x1, [fp, #0x18]
    // 0x9d8670: StoreField: r1->field_13 = rNULL
    //     0x9d8670: stur            NULL, [x1, #0x13]
    // 0x9d8674: r0 = Null
    //     0x9d8674: mov             x0, NULL
    // 0x9d8678: LeaveFrame
    //     0x9d8678: mov             SP, fp
    //     0x9d867c: ldp             fp, lr, [SP], #0x10
    // 0x9d8680: ret
    //     0x9d8680: ret             
    // 0x9d8684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8684: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8688: b               #0x9d85e4
    // 0x9d868c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d868c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d8690: r0 = NullCastErrorSharedWithFPURegs()
    //     0x9d8690: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x9d8694: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d8694: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _convertToLogical(/* No info */) {
    // ** addr: 0x9d8698, size: 0xe0
    // 0x9d8698: EnterFrame
    //     0x9d8698: stp             fp, lr, [SP, #-0x10]!
    //     0x9d869c: mov             fp, SP
    // 0x9d86a0: CheckStackOverflow
    //     0x9d86a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d86a4: cmp             SP, x16
    //     0x9d86a8: b.ls            #0x9d874c
    // 0x9d86ac: ldr             x0, [fp, #0x18]
    // 0x9d86b0: LoadField: r1 = r0->field_f
    //     0x9d86b0: ldur            w1, [x0, #0xf]
    // 0x9d86b4: DecompressPointer r1
    //     0x9d86b4: add             x1, x1, HEAP, lsl #32
    // 0x9d86b8: cmp             w1, NULL
    // 0x9d86bc: b.eq            #0x9d8754
    // 0x9d86c0: SaveReg r1
    //     0x9d86c0: str             x1, [SP, #-8]!
    // 0x9d86c4: r0 = of()
    //     0x9d86c4: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x9d86c8: add             SP, SP, #8
    // 0x9d86cc: LoadField: r1 = r0->field_7
    //     0x9d86cc: ldur            x1, [x0, #7]
    // 0x9d86d0: cmp             x1, #0
    // 0x9d86d4: b.gt            #0x9d8714
    // 0x9d86d8: ldr             d0, [fp, #0x10]
    // 0x9d86dc: fneg            d1, d0
    // 0x9d86e0: r0 = inline_Allocate_Double()
    //     0x9d86e0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9d86e4: add             x0, x0, #0x10
    //     0x9d86e8: cmp             x1, x0
    //     0x9d86ec: b.ls            #0x9d8758
    //     0x9d86f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x9d86f4: sub             x0, x0, #0xf
    //     0x9d86f8: mov             x1, #0xd108
    //     0x9d86fc: movk            x1, #3, lsl #16
    //     0x9d8700: stur            x1, [x0, #-1]
    // 0x9d8704: StoreField: r0->field_7 = d1
    //     0x9d8704: stur            d1, [x0, #7]
    // 0x9d8708: LeaveFrame
    //     0x9d8708: mov             SP, fp
    //     0x9d870c: ldp             fp, lr, [SP], #0x10
    // 0x9d8710: ret
    //     0x9d8710: ret             
    // 0x9d8714: ldr             d0, [fp, #0x10]
    // 0x9d8718: r0 = inline_Allocate_Double()
    //     0x9d8718: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x9d871c: add             x0, x0, #0x10
    //     0x9d8720: cmp             x1, x0
    //     0x9d8724: b.ls            #0x9d8768
    //     0x9d8728: str             x0, [THR, #0x60]  ; THR::top
    //     0x9d872c: sub             x0, x0, #0xf
    //     0x9d8730: mov             x1, #0xd108
    //     0x9d8734: movk            x1, #3, lsl #16
    //     0x9d8738: stur            x1, [x0, #-1]
    // 0x9d873c: StoreField: r0->field_7 = d0
    //     0x9d873c: stur            d0, [x0, #7]
    // 0x9d8740: LeaveFrame
    //     0x9d8740: mov             SP, fp
    //     0x9d8744: ldp             fp, lr, [SP], #0x10
    // 0x9d8748: ret
    //     0x9d8748: ret             
    // 0x9d874c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d874c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8750: b               #0x9d86ac
    // 0x9d8754: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d8754: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d8758: SaveReg d1
    //     0x9d8758: str             q1, [SP, #-0x10]!
    // 0x9d875c: r0 = AllocateDouble()
    //     0x9d875c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x9d8760: RestoreReg d1
    //     0x9d8760: ldr             q1, [SP], #0x10
    // 0x9d8764: b               #0x9d8704
    // 0x9d8768: SaveReg d0
    //     0x9d8768: str             q0, [SP, #-0x10]!
    // 0x9d876c: r0 = AllocateDouble()
    //     0x9d876c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x9d8770: RestoreReg d0
    //     0x9d8770: ldr             q0, [SP], #0x10
    // 0x9d8774: b               #0x9d873c
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x9d87f8, size: 0x4c
    // 0x9d87f8: EnterFrame
    //     0x9d87f8: stp             fp, lr, [SP, #-0x10]!
    //     0x9d87fc: mov             fp, SP
    // 0x9d8800: ldr             x0, [fp, #0x18]
    // 0x9d8804: LoadField: r1 = r0->field_17
    //     0x9d8804: ldur            w1, [x0, #0x17]
    // 0x9d8808: DecompressPointer r1
    //     0x9d8808: add             x1, x1, HEAP, lsl #32
    // 0x9d880c: CheckStackOverflow
    //     0x9d880c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8810: cmp             SP, x16
    //     0x9d8814: b.ls            #0x9d883c
    // 0x9d8818: LoadField: r0 = r1->field_f
    //     0x9d8818: ldur            w0, [x1, #0xf]
    // 0x9d881c: DecompressPointer r0
    //     0x9d881c: add             x0, x0, HEAP, lsl #32
    // 0x9d8820: ldr             x16, [fp, #0x10]
    // 0x9d8824: stp             x16, x0, [SP, #-0x10]!
    // 0x9d8828: r0 = _handleDragUpdate()
    //     0x9d8828: bl              #0x9d8844  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragUpdate
    // 0x9d882c: add             SP, SP, #0x10
    // 0x9d8830: LeaveFrame
    //     0x9d8830: mov             SP, fp
    //     0x9d8834: ldp             fp, lr, [SP], #0x10
    // 0x9d8838: ret
    //     0x9d8838: ret             
    // 0x9d883c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d883c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8840: b               #0x9d8818
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0x9d8844, size: 0xc8
    // 0x9d8844: EnterFrame
    //     0x9d8844: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8848: mov             fp, SP
    // 0x9d884c: AllocStack(0x10)
    //     0x9d884c: sub             SP, SP, #0x10
    // 0x9d8850: CheckStackOverflow
    //     0x9d8850: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8854: cmp             SP, x16
    //     0x9d8858: b.ls            #0x9d88f4
    // 0x9d885c: ldr             x0, [fp, #0x18]
    // 0x9d8860: LoadField: r1 = r0->field_13
    //     0x9d8860: ldur            w1, [x0, #0x13]
    // 0x9d8864: DecompressPointer r1
    //     0x9d8864: add             x1, x1, HEAP, lsl #32
    // 0x9d8868: stur            x1, [fp, #-0x10]
    // 0x9d886c: cmp             w1, NULL
    // 0x9d8870: b.eq            #0x9d88fc
    // 0x9d8874: ldr             x2, [fp, #0x10]
    // 0x9d8878: LoadField: r3 = r2->field_f
    //     0x9d8878: ldur            w3, [x2, #0xf]
    // 0x9d887c: DecompressPointer r3
    //     0x9d887c: add             x3, x3, HEAP, lsl #32
    // 0x9d8880: stur            x3, [fp, #-8]
    // 0x9d8884: cmp             w3, NULL
    // 0x9d8888: b.eq            #0x9d8900
    // 0x9d888c: LoadField: r2 = r0->field_f
    //     0x9d888c: ldur            w2, [x0, #0xf]
    // 0x9d8890: DecompressPointer r2
    //     0x9d8890: add             x2, x2, HEAP, lsl #32
    // 0x9d8894: cmp             w2, NULL
    // 0x9d8898: b.eq            #0x9d8904
    // 0x9d889c: SaveReg r2
    //     0x9d889c: str             x2, [SP, #-8]!
    // 0x9d88a0: r0 = size()
    //     0x9d88a0: bl              #0x9d8778  ; [package:flutter/src/widgets/framework.dart] Element::size
    // 0x9d88a4: add             SP, SP, #8
    // 0x9d88a8: cmp             w0, NULL
    // 0x9d88ac: b.eq            #0x9d8908
    // 0x9d88b0: LoadField: d0 = r0->field_7
    //     0x9d88b0: ldur            d0, [x0, #7]
    // 0x9d88b4: ldur            x0, [fp, #-8]
    // 0x9d88b8: LoadField: d1 = r0->field_7
    //     0x9d88b8: ldur            d1, [x0, #7]
    // 0x9d88bc: fdiv            d2, d1, d0
    // 0x9d88c0: ldr             x16, [fp, #0x18]
    // 0x9d88c4: SaveReg r16
    //     0x9d88c4: str             x16, [SP, #-8]!
    // 0x9d88c8: SaveReg d2
    //     0x9d88c8: str             d2, [SP, #-8]!
    // 0x9d88cc: r0 = _convertToLogical()
    //     0x9d88cc: bl              #0x9d8698  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_convertToLogical
    // 0x9d88d0: add             SP, SP, #0x10
    // 0x9d88d4: ldur            x16, [fp, #-0x10]
    // 0x9d88d8: stp             x0, x16, [SP, #-0x10]!
    // 0x9d88dc: r0 = dragUpdate()
    //     0x9d88dc: bl              #0x9d890c  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureController::dragUpdate
    // 0x9d88e0: add             SP, SP, #0x10
    // 0x9d88e4: r0 = Null
    //     0x9d88e4: mov             x0, NULL
    // 0x9d88e8: LeaveFrame
    //     0x9d88e8: mov             SP, fp
    //     0x9d88ec: ldp             fp, lr, [SP], #0x10
    // 0x9d88f0: ret
    //     0x9d88f0: ret             
    // 0x9d88f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d88f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d88f8: b               #0x9d885c
    // 0x9d88fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d88fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d8900: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d8900: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d8904: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d8904: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d8908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d8908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x9d8990, size: 0x4c
    // 0x9d8990: EnterFrame
    //     0x9d8990: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8994: mov             fp, SP
    // 0x9d8998: ldr             x0, [fp, #0x18]
    // 0x9d899c: LoadField: r1 = r0->field_17
    //     0x9d899c: ldur            w1, [x0, #0x17]
    // 0x9d89a0: DecompressPointer r1
    //     0x9d89a0: add             x1, x1, HEAP, lsl #32
    // 0x9d89a4: CheckStackOverflow
    //     0x9d89a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d89a8: cmp             SP, x16
    //     0x9d89ac: b.ls            #0x9d89d4
    // 0x9d89b0: LoadField: r0 = r1->field_f
    //     0x9d89b0: ldur            w0, [x1, #0xf]
    // 0x9d89b4: DecompressPointer r0
    //     0x9d89b4: add             x0, x0, HEAP, lsl #32
    // 0x9d89b8: ldr             x16, [fp, #0x10]
    // 0x9d89bc: stp             x16, x0, [SP, #-0x10]!
    // 0x9d89c0: r0 = _handleDragStart()
    //     0x9d89c0: bl              #0x9d89dc  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::_handleDragStart
    // 0x9d89c4: add             SP, SP, #0x10
    // 0x9d89c8: LeaveFrame
    //     0x9d89c8: mov             SP, fp
    //     0x9d89cc: ldp             fp, lr, [SP], #0x10
    // 0x9d89d0: ret
    //     0x9d89d0: ret             
    // 0x9d89d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d89d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d89d8: b               #0x9d89b0
  }
  _ _handleDragStart(/* No info */) {
    // ** addr: 0x9d89dc, size: 0x88
    // 0x9d89dc: EnterFrame
    //     0x9d89dc: stp             fp, lr, [SP, #-0x10]!
    //     0x9d89e0: mov             fp, SP
    // 0x9d89e4: CheckStackOverflow
    //     0x9d89e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d89e8: cmp             SP, x16
    //     0x9d89ec: b.ls            #0x9d8a58
    // 0x9d89f0: ldr             x1, [fp, #0x18]
    // 0x9d89f4: LoadField: r0 = r1->field_b
    //     0x9d89f4: ldur            w0, [x1, #0xb]
    // 0x9d89f8: DecompressPointer r0
    //     0x9d89f8: add             x0, x0, HEAP, lsl #32
    // 0x9d89fc: cmp             w0, NULL
    // 0x9d8a00: b.eq            #0x9d8a60
    // 0x9d8a04: LoadField: r2 = r0->field_17
    //     0x9d8a04: ldur            w2, [x0, #0x17]
    // 0x9d8a08: DecompressPointer r2
    //     0x9d8a08: add             x2, x2, HEAP, lsl #32
    // 0x9d8a0c: SaveReg r2
    //     0x9d8a0c: str             x2, [SP, #-8]!
    // 0x9d8a10: mov             x0, x2
    // 0x9d8a14: ClosureCall
    //     0x9d8a14: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x9d8a18: ldur            x2, [x0, #0x1f]
    //     0x9d8a1c: blr             x2
    // 0x9d8a20: add             SP, SP, #8
    // 0x9d8a24: ldr             x1, [fp, #0x18]
    // 0x9d8a28: StoreField: r1->field_13 = r0
    //     0x9d8a28: stur            w0, [x1, #0x13]
    //     0x9d8a2c: tbz             w0, #0, #0x9d8a48
    //     0x9d8a30: ldurb           w16, [x1, #-1]
    //     0x9d8a34: ldurb           w17, [x0, #-1]
    //     0x9d8a38: and             x16, x17, x16, lsr #2
    //     0x9d8a3c: tst             x16, HEAP, lsr #32
    //     0x9d8a40: b.eq            #0x9d8a48
    //     0x9d8a44: bl              #0xd6826c
    // 0x9d8a48: r0 = Null
    //     0x9d8a48: mov             x0, NULL
    // 0x9d8a4c: LeaveFrame
    //     0x9d8a4c: mov             SP, fp
    //     0x9d8a50: ldp             fp, lr, [SP], #0x10
    // 0x9d8a54: ret
    //     0x9d8a54: ret             
    // 0x9d8a58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8a58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8a5c: b               #0x9d89f0
    // 0x9d8a60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d8a60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a708, size: 0x18
    // 0xa4a708: r4 = 7
    //     0xa4a708: mov             x4, #7
    // 0xa4a70c: r1 = Function 'dispose':.
    //     0xa4a70c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bac0] AnonymousClosure: (0xa4a720), in [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::dispose (0xa506dc)
    //     0xa4a710: ldr             x1, [x17, #0xac0]
    // 0xa4a714: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a714: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a718: LoadField: r0 = r24->field_17
    //     0xa4a718: ldur            x0, [x24, #0x17]
    // 0xa4a71c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a720, size: 0x48
    // 0xa4a720: EnterFrame
    //     0xa4a720: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a724: mov             fp, SP
    // 0xa4a728: ldr             x0, [fp, #0x10]
    // 0xa4a72c: LoadField: r1 = r0->field_17
    //     0xa4a72c: ldur            w1, [x0, #0x17]
    // 0xa4a730: DecompressPointer r1
    //     0xa4a730: add             x1, x1, HEAP, lsl #32
    // 0xa4a734: CheckStackOverflow
    //     0xa4a734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a738: cmp             SP, x16
    //     0xa4a73c: b.ls            #0xa4a760
    // 0xa4a740: LoadField: r0 = r1->field_f
    //     0xa4a740: ldur            w0, [x1, #0xf]
    // 0xa4a744: DecompressPointer r0
    //     0xa4a744: add             x0, x0, HEAP, lsl #32
    // 0xa4a748: SaveReg r0
    //     0xa4a748: str             x0, [SP, #-8]!
    // 0xa4a74c: r0 = dispose()
    //     0xa4a74c: bl              #0xa506dc  ; [package:flutter/src/cupertino/route.dart] _CupertinoBackGestureDetectorState::dispose
    // 0xa4a750: add             SP, SP, #8
    // 0xa4a754: LeaveFrame
    //     0xa4a754: mov             SP, fp
    //     0xa4a758: ldp             fp, lr, [SP], #0x10
    // 0xa4a75c: ret
    //     0xa4a75c: ret             
    // 0xa4a760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a764: b               #0xa4a740
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa506dc, size: 0x5c
    // 0xa506dc: EnterFrame
    //     0xa506dc: stp             fp, lr, [SP, #-0x10]!
    //     0xa506e0: mov             fp, SP
    // 0xa506e4: CheckStackOverflow
    //     0xa506e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa506e8: cmp             SP, x16
    //     0xa506ec: b.ls            #0xa50724
    // 0xa506f0: ldr             x0, [fp, #0x10]
    // 0xa506f4: LoadField: r1 = r0->field_17
    //     0xa506f4: ldur            w1, [x0, #0x17]
    // 0xa506f8: DecompressPointer r1
    //     0xa506f8: add             x1, x1, HEAP, lsl #32
    // 0xa506fc: r16 = Sentinel
    //     0xa506fc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa50700: cmp             w1, w16
    // 0xa50704: b.eq            #0xa5072c
    // 0xa50708: SaveReg r1
    //     0xa50708: str             x1, [SP, #-8]!
    // 0xa5070c: r0 = dispose()
    //     0xa5070c: bl              #0xbd92fc  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::dispose
    // 0xa50710: add             SP, SP, #8
    // 0xa50714: r0 = Null
    //     0xa50714: mov             x0, NULL
    // 0xa50718: LeaveFrame
    //     0xa50718: mov             SP, fp
    //     0xa5071c: ldp             fp, lr, [SP], #0x10
    // 0xa50720: ret
    //     0xa50720: ret             
    // 0xa50724: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50724: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50728: b               #0xa506f0
    // 0xa5072c: r9 = _recognizer
    //     0xa5072c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bad0] Field <_CupertinoBackGestureDetectorState@609053933._recognizer@609053933>: late (offset: 0x18)
    //     0xa50730: ldr             x9, [x9, #0xad0]
    // 0xa50734: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa50734: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3871, size: 0x1c, field offset: 0xc
class CupertinoPageTransition extends StatelessWidget {

  _ CupertinoPageTransition(/* No info */) {
    // ** addr: 0xa8a170, size: 0x28c
    // 0xa8a170: EnterFrame
    //     0xa8a170: stp             fp, lr, [SP, #-0x10]!
    //     0xa8a174: mov             fp, SP
    // 0xa8a178: AllocStack(0x10)
    //     0xa8a178: sub             SP, SP, #0x10
    // 0xa8a17c: CheckStackOverflow
    //     0xa8a17c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa8a180: cmp             SP, x16
    //     0xa8a184: b.ls            #0xa8a3f4
    // 0xa8a188: ldr             x0, [fp, #0x28]
    // 0xa8a18c: ldr             x2, [fp, #0x30]
    // 0xa8a190: StoreField: r2->field_17 = r0
    //     0xa8a190: stur            w0, [x2, #0x17]
    //     0xa8a194: ldurb           w16, [x2, #-1]
    //     0xa8a198: ldurb           w17, [x0, #-1]
    //     0xa8a19c: and             x16, x17, x16, lsr #2
    //     0xa8a1a0: tst             x16, HEAP, lsr #32
    //     0xa8a1a4: b.eq            #0xa8a1ac
    //     0xa8a1a8: bl              #0xd6828c
    // 0xa8a1ac: ldr             x0, [fp, #0x20]
    // 0xa8a1b0: tbnz            w0, #4, #0xa8a1c8
    // 0xa8a1b4: ldr             x3, [fp, #0x18]
    // 0xa8a1b8: mov             x1, x0
    // 0xa8a1bc: mov             x0, x2
    // 0xa8a1c0: mov             x2, x3
    // 0xa8a1c4: b               #0xa8a210
    // 0xa8a1c8: ldr             x3, [fp, #0x18]
    // 0xa8a1cc: r1 = <double>
    //     0xa8a1cc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa8a1d0: r0 = CurvedAnimation()
    //     0xa8a1d0: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xa8a1d4: stur            x0, [fp, #-8]
    // 0xa8a1d8: r16 = Instance_Cubic
    //     0xa8a1d8: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2aa90] Obj!Cubic<double>@b4f6a1
    //     0xa8a1dc: ldr             x16, [x16, #0xa90]
    // 0xa8a1e0: stp             x16, x0, [SP, #-0x10]!
    // 0xa8a1e4: ldr             x16, [fp, #0x18]
    // 0xa8a1e8: r30 = Instance_Cubic
    //     0xa8a1e8: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2aa98] Obj!Cubic<double>@b4f671
    //     0xa8a1ec: ldr             lr, [lr, #0xa98]
    // 0xa8a1f0: stp             lr, x16, [SP, #-0x10]!
    // 0xa8a1f4: r4 = const [0, 0x4, 0x4, 0x3, reverseCurve, 0x3, null]
    //     0xa8a1f4: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cb40] List(7) [0, 0x4, 0x4, 0x3, "reverseCurve", 0x3, Null]
    //     0xa8a1f8: ldr             x4, [x4, #0xb40]
    // 0xa8a1fc: r0 = CurvedAnimation()
    //     0xa8a1fc: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xa8a200: add             SP, SP, #0x20
    // 0xa8a204: ldur            x2, [fp, #-8]
    // 0xa8a208: ldr             x0, [fp, #0x30]
    // 0xa8a20c: ldr             x1, [fp, #0x20]
    // 0xa8a210: stur            x2, [fp, #-8]
    // 0xa8a214: r0 = InitLateStaticField(0xcd8) // [package:flutter/src/cupertino/route.dart] ::_kRightMiddleTween
    //     0xa8a214: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa8a218: ldr             x0, [x0, #0x19b0]
    //     0xa8a21c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa8a220: cmp             w0, w16
    //     0xa8a224: b.ne            #0xa8a234
    //     0xa8a228: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2aaa0] Field <::._kRightMiddleTween@609053933>: static late final (offset: 0xcd8)
    //     0xa8a22c: ldr             x2, [x2, #0xaa0]
    //     0xa8a230: bl              #0xd67cdc
    // 0xa8a234: ldur            x16, [fp, #-8]
    // 0xa8a238: stp             x16, x0, [SP, #-0x10]!
    // 0xa8a23c: r0 = animate()
    //     0xa8a23c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xa8a240: add             SP, SP, #0x10
    // 0xa8a244: ldr             x2, [fp, #0x30]
    // 0xa8a248: StoreField: r2->field_b = r0
    //     0xa8a248: stur            w0, [x2, #0xb]
    //     0xa8a24c: ldurb           w16, [x2, #-1]
    //     0xa8a250: ldurb           w17, [x0, #-1]
    //     0xa8a254: and             x16, x17, x16, lsr #2
    //     0xa8a258: tst             x16, HEAP, lsr #32
    //     0xa8a25c: b.eq            #0xa8a264
    //     0xa8a260: bl              #0xd6828c
    // 0xa8a264: ldr             x0, [fp, #0x20]
    // 0xa8a268: tbnz            w0, #4, #0xa8a280
    // 0xa8a26c: ldr             x3, [fp, #0x10]
    // 0xa8a270: mov             x1, x0
    // 0xa8a274: mov             x0, x2
    // 0xa8a278: mov             x2, x3
    // 0xa8a27c: b               #0xa8a2c8
    // 0xa8a280: ldr             x3, [fp, #0x10]
    // 0xa8a284: r1 = <double>
    //     0xa8a284: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa8a288: r0 = CurvedAnimation()
    //     0xa8a288: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xa8a28c: stur            x0, [fp, #-8]
    // 0xa8a290: r16 = Instance_Cubic
    //     0xa8a290: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2aa90] Obj!Cubic<double>@b4f6a1
    //     0xa8a294: ldr             x16, [x16, #0xa90]
    // 0xa8a298: stp             x16, x0, [SP, #-0x10]!
    // 0xa8a29c: ldr             x16, [fp, #0x10]
    // 0xa8a2a0: r30 = Instance_Cubic
    //     0xa8a2a0: add             lr, PP, #0x2a, lsl #12  ; [pp+0x2aa98] Obj!Cubic<double>@b4f671
    //     0xa8a2a4: ldr             lr, [lr, #0xa98]
    // 0xa8a2a8: stp             lr, x16, [SP, #-0x10]!
    // 0xa8a2ac: r4 = const [0, 0x4, 0x4, 0x3, reverseCurve, 0x3, null]
    //     0xa8a2ac: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1cb40] List(7) [0, 0x4, 0x4, 0x3, "reverseCurve", 0x3, Null]
    //     0xa8a2b0: ldr             x4, [x4, #0xb40]
    // 0xa8a2b4: r0 = CurvedAnimation()
    //     0xa8a2b4: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xa8a2b8: add             SP, SP, #0x20
    // 0xa8a2bc: ldur            x2, [fp, #-8]
    // 0xa8a2c0: ldr             x0, [fp, #0x30]
    // 0xa8a2c4: ldr             x1, [fp, #0x20]
    // 0xa8a2c8: stur            x2, [fp, #-8]
    // 0xa8a2cc: r0 = InitLateStaticField(0xcdc) // [package:flutter/src/cupertino/route.dart] ::_kMiddleLeftTween
    //     0xa8a2cc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa8a2d0: ldr             x0, [x0, #0x19b8]
    //     0xa8a2d4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa8a2d8: cmp             w0, w16
    //     0xa8a2dc: b.ne            #0xa8a2ec
    //     0xa8a2e0: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2aaa8] Field <::._kMiddleLeftTween@609053933>: static late final (offset: 0xcdc)
    //     0xa8a2e4: ldr             x2, [x2, #0xaa8]
    //     0xa8a2e8: bl              #0xd67cdc
    // 0xa8a2ec: mov             x3, x0
    // 0xa8a2f0: ldur            x0, [fp, #-8]
    // 0xa8a2f4: r2 = Null
    //     0xa8a2f4: mov             x2, NULL
    // 0xa8a2f8: r1 = Null
    //     0xa8a2f8: mov             x1, NULL
    // 0xa8a2fc: stur            x3, [fp, #-0x10]
    // 0xa8a300: r8 = Animation<double>
    //     0xa8a300: add             x8, PP, #0x2a, lsl #12  ; [pp+0x2aab0] Type: Animation<double>
    //     0xa8a304: ldr             x8, [x8, #0xab0]
    // 0xa8a308: r3 = Null
    //     0xa8a308: add             x3, PP, #0x2a, lsl #12  ; [pp+0x2aab8] Null
    //     0xa8a30c: ldr             x3, [x3, #0xab8]
    // 0xa8a310: r0 = Animation<double>()
    //     0xa8a310: bl              #0x5912f0  ; IsType_Animation<double>_Stub
    // 0xa8a314: ldur            x16, [fp, #-0x10]
    // 0xa8a318: ldur            lr, [fp, #-8]
    // 0xa8a31c: stp             lr, x16, [SP, #-0x10]!
    // 0xa8a320: r0 = animate()
    //     0xa8a320: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xa8a324: add             SP, SP, #0x10
    // 0xa8a328: ldr             x2, [fp, #0x30]
    // 0xa8a32c: StoreField: r2->field_f = r0
    //     0xa8a32c: stur            w0, [x2, #0xf]
    //     0xa8a330: ldurb           w16, [x2, #-1]
    //     0xa8a334: ldurb           w17, [x0, #-1]
    //     0xa8a338: and             x16, x17, x16, lsr #2
    //     0xa8a33c: tst             x16, HEAP, lsr #32
    //     0xa8a340: b.eq            #0xa8a348
    //     0xa8a344: bl              #0xd6828c
    // 0xa8a348: ldr             x0, [fp, #0x20]
    // 0xa8a34c: tbnz            w0, #4, #0xa8a35c
    // 0xa8a350: ldr             x1, [fp, #0x18]
    // 0xa8a354: mov             x0, x2
    // 0xa8a358: b               #0xa8a390
    // 0xa8a35c: r1 = <double>
    //     0xa8a35c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa8a360: r0 = CurvedAnimation()
    //     0xa8a360: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0xa8a364: stur            x0, [fp, #-8]
    // 0xa8a368: r16 = Instance_Cubic
    //     0xa8a368: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2aa90] Obj!Cubic<double>@b4f6a1
    //     0xa8a36c: ldr             x16, [x16, #0xa90]
    // 0xa8a370: stp             x16, x0, [SP, #-0x10]!
    // 0xa8a374: ldr             x16, [fp, #0x18]
    // 0xa8a378: SaveReg r16
    //     0xa8a378: str             x16, [SP, #-8]!
    // 0xa8a37c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xa8a37c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xa8a380: r0 = CurvedAnimation()
    //     0xa8a380: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0xa8a384: add             SP, SP, #0x18
    // 0xa8a388: ldur            x1, [fp, #-8]
    // 0xa8a38c: ldr             x0, [fp, #0x30]
    // 0xa8a390: stur            x1, [fp, #-8]
    // 0xa8a394: r0 = InitLateStaticField(0xcd4) // [package:flutter/src/cupertino/route.dart] _CupertinoEdgeShadowDecoration::kTween
    //     0xa8a394: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa8a398: ldr             x0, [x0, #0x19a8]
    //     0xa8a39c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa8a3a0: cmp             w0, w16
    //     0xa8a3a4: b.ne            #0xa8a3b4
    //     0xa8a3a8: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2aac8] Field <_CupertinoEdgeShadowDecoration@609053933.kTween>: static late (offset: 0xcd4)
    //     0xa8a3ac: ldr             x2, [x2, #0xac8]
    //     0xa8a3b0: bl              #0xd67d44
    // 0xa8a3b4: ldur            x16, [fp, #-8]
    // 0xa8a3b8: stp             x16, x0, [SP, #-0x10]!
    // 0xa8a3bc: r0 = animate()
    //     0xa8a3bc: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0xa8a3c0: add             SP, SP, #0x10
    // 0xa8a3c4: ldr             x1, [fp, #0x30]
    // 0xa8a3c8: StoreField: r1->field_13 = r0
    //     0xa8a3c8: stur            w0, [x1, #0x13]
    //     0xa8a3cc: ldurb           w16, [x1, #-1]
    //     0xa8a3d0: ldurb           w17, [x0, #-1]
    //     0xa8a3d4: and             x16, x17, x16, lsr #2
    //     0xa8a3d8: tst             x16, HEAP, lsr #32
    //     0xa8a3dc: b.eq            #0xa8a3e4
    //     0xa8a3e0: bl              #0xd6826c
    // 0xa8a3e4: r0 = Null
    //     0xa8a3e4: mov             x0, NULL
    // 0xa8a3e8: LeaveFrame
    //     0xa8a3e8: mov             SP, fp
    //     0xa8a3ec: ldp             fp, lr, [SP], #0x10
    // 0xa8a3f0: ret
    //     0xa8a3f0: ret             
    // 0xa8a3f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa8a3f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa8a3f8: b               #0xa8a188
  }
  _ build(/* No info */) {
    // ** addr: 0xb1cf00, size: 0xf4
    // 0xb1cf00: EnterFrame
    //     0xb1cf00: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cf04: mov             fp, SP
    // 0xb1cf08: AllocStack(0x30)
    //     0xb1cf08: sub             SP, SP, #0x30
    // 0xb1cf0c: CheckStackOverflow
    //     0xb1cf0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1cf10: cmp             SP, x16
    //     0xb1cf14: b.ls            #0xb1cfec
    // 0xb1cf18: ldr             x16, [fp, #0x10]
    // 0xb1cf1c: SaveReg r16
    //     0xb1cf1c: str             x16, [SP, #-8]!
    // 0xb1cf20: r0 = of()
    //     0xb1cf20: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xb1cf24: add             SP, SP, #8
    // 0xb1cf28: mov             x1, x0
    // 0xb1cf2c: ldr             x0, [fp, #0x18]
    // 0xb1cf30: stur            x1, [fp, #-0x28]
    // 0xb1cf34: LoadField: r2 = r0->field_f
    //     0xb1cf34: ldur            w2, [x0, #0xf]
    // 0xb1cf38: DecompressPointer r2
    //     0xb1cf38: add             x2, x2, HEAP, lsl #32
    // 0xb1cf3c: stur            x2, [fp, #-0x20]
    // 0xb1cf40: LoadField: r3 = r0->field_b
    //     0xb1cf40: ldur            w3, [x0, #0xb]
    // 0xb1cf44: DecompressPointer r3
    //     0xb1cf44: add             x3, x3, HEAP, lsl #32
    // 0xb1cf48: stur            x3, [fp, #-0x18]
    // 0xb1cf4c: LoadField: r4 = r0->field_13
    //     0xb1cf4c: ldur            w4, [x0, #0x13]
    // 0xb1cf50: DecompressPointer r4
    //     0xb1cf50: add             x4, x4, HEAP, lsl #32
    // 0xb1cf54: stur            x4, [fp, #-0x10]
    // 0xb1cf58: LoadField: r5 = r0->field_17
    //     0xb1cf58: ldur            w5, [x0, #0x17]
    // 0xb1cf5c: DecompressPointer r5
    //     0xb1cf5c: add             x5, x5, HEAP, lsl #32
    // 0xb1cf60: stur            x5, [fp, #-8]
    // 0xb1cf64: r0 = DecoratedBoxTransition()
    //     0xb1cf64: bl              #0xb1cff4  ; AllocateDecoratedBoxTransitionStub -> DecoratedBoxTransition (size=0x1c)
    // 0xb1cf68: mov             x1, x0
    // 0xb1cf6c: ldur            x0, [fp, #-0x10]
    // 0xb1cf70: stur            x1, [fp, #-0x30]
    // 0xb1cf74: StoreField: r1->field_f = r0
    //     0xb1cf74: stur            w0, [x1, #0xf]
    // 0xb1cf78: r2 = Instance_DecorationPosition
    //     0xb1cf78: add             x2, PP, #0xf, lsl #12  ; [pp+0xf1b0] Obj!DecorationPosition@b648d1
    //     0xb1cf7c: ldr             x2, [x2, #0x1b0]
    // 0xb1cf80: StoreField: r1->field_13 = r2
    //     0xb1cf80: stur            w2, [x1, #0x13]
    // 0xb1cf84: ldur            x2, [fp, #-8]
    // 0xb1cf88: StoreField: r1->field_17 = r2
    //     0xb1cf88: stur            w2, [x1, #0x17]
    // 0xb1cf8c: StoreField: r1->field_b = r0
    //     0xb1cf8c: stur            w0, [x1, #0xb]
    // 0xb1cf90: r0 = SlideTransition()
    //     0xb1cf90: bl              #0x5a122c  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xb1cf94: mov             x1, x0
    // 0xb1cf98: r0 = true
    //     0xb1cf98: add             x0, NULL, #0x20  ; true
    // 0xb1cf9c: stur            x1, [fp, #-8]
    // 0xb1cfa0: StoreField: r1->field_13 = r0
    //     0xb1cfa0: stur            w0, [x1, #0x13]
    // 0xb1cfa4: ldur            x0, [fp, #-0x28]
    // 0xb1cfa8: StoreField: r1->field_f = r0
    //     0xb1cfa8: stur            w0, [x1, #0xf]
    // 0xb1cfac: ldur            x2, [fp, #-0x30]
    // 0xb1cfb0: StoreField: r1->field_17 = r2
    //     0xb1cfb0: stur            w2, [x1, #0x17]
    // 0xb1cfb4: ldur            x2, [fp, #-0x18]
    // 0xb1cfb8: StoreField: r1->field_b = r2
    //     0xb1cfb8: stur            w2, [x1, #0xb]
    // 0xb1cfbc: r0 = SlideTransition()
    //     0xb1cfbc: bl              #0x5a122c  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0xb1cfc0: r1 = false
    //     0xb1cfc0: add             x1, NULL, #0x30  ; false
    // 0xb1cfc4: StoreField: r0->field_13 = r1
    //     0xb1cfc4: stur            w1, [x0, #0x13]
    // 0xb1cfc8: ldur            x1, [fp, #-0x28]
    // 0xb1cfcc: StoreField: r0->field_f = r1
    //     0xb1cfcc: stur            w1, [x0, #0xf]
    // 0xb1cfd0: ldur            x1, [fp, #-8]
    // 0xb1cfd4: StoreField: r0->field_17 = r1
    //     0xb1cfd4: stur            w1, [x0, #0x17]
    // 0xb1cfd8: ldur            x1, [fp, #-0x20]
    // 0xb1cfdc: StoreField: r0->field_b = r1
    //     0xb1cfdc: stur            w1, [x0, #0xb]
    // 0xb1cfe0: LeaveFrame
    //     0xb1cfe0: mov             SP, fp
    //     0xb1cfe4: ldp             fp, lr, [SP], #0x10
    // 0xb1cfe8: ret
    //     0xb1cfe8: ret             
    // 0xb1cfec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cfec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cff0: b               #0xb1cf18
  }
}

// class id: 4179, size: 0x1c, field offset: 0xc
//   const constructor, 
class _CupertinoBackGestureDetector<X0> extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fdf0, size: 0x48
    // 0xa3fdf0: EnterFrame
    //     0xa3fdf0: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fdf4: mov             fp, SP
    // 0xa3fdf8: ldr             x0, [fp, #0x10]
    // 0xa3fdfc: LoadField: r2 = r0->field_b
    //     0xa3fdfc: ldur            w2, [x0, #0xb]
    // 0xa3fe00: DecompressPointer r2
    //     0xa3fe00: add             x2, x2, HEAP, lsl #32
    // 0xa3fe04: r1 = Null
    //     0xa3fe04: mov             x1, NULL
    // 0xa3fe08: r3 = <_CupertinoBackGestureDetector<X0>, X0>
    //     0xa3fe08: add             x3, PP, #0x40, lsl #12  ; [pp+0x40408] TypeArguments: <_CupertinoBackGestureDetector<X0>, X0>
    //     0xa3fe0c: ldr             x3, [x3, #0x408]
    // 0xa3fe10: r24 = InstantiateTypeArgumentsStub
    //     0xa3fe10: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0xa3fe14: LoadField: r30 = r24->field_7
    //     0xa3fe14: ldur            lr, [x24, #7]
    // 0xa3fe18: blr             lr
    // 0xa3fe1c: mov             x1, x0
    // 0xa3fe20: r0 = _CupertinoBackGestureDetectorState()
    //     0xa3fe20: bl              #0xa3fe38  ; Allocate_CupertinoBackGestureDetectorStateStub -> _CupertinoBackGestureDetectorState<_CupertinoBackGestureDetector<C1X0>> (size=0x1c)
    // 0xa3fe24: r1 = Sentinel
    //     0xa3fe24: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fe28: StoreField: r0->field_17 = r1
    //     0xa3fe28: stur            w1, [x0, #0x17]
    // 0xa3fe2c: LeaveFrame
    //     0xa3fe2c: mov             SP, fp
    //     0xa3fe30: ldp             fp, lr, [SP], #0x10
    // 0xa3fe34: ret
    //     0xa3fe34: ret             
  }
}

// class id: 4228, size: 0x14, field offset: 0x8
class _CupertinoBackGestureController<X0> extends Object {

  _ dragEnd(/* No info */) {
    // ** addr: 0x9d7b74, size: 0x3b4
    // 0x9d7b74: EnterFrame
    //     0x9d7b74: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7b78: mov             fp, SP
    // 0x9d7b7c: AllocStack(0x18)
    //     0x9d7b7c: sub             SP, SP, #0x18
    // 0x9d7b80: CheckStackOverflow
    //     0x9d7b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7b84: cmp             SP, x16
    //     0x9d7b88: b.ls            #0x9d7eb4
    // 0x9d7b8c: r1 = 2
    //     0x9d7b8c: mov             x1, #2
    // 0x9d7b90: r0 = AllocateContext()
    //     0x9d7b90: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7b94: mov             x1, x0
    // 0x9d7b98: ldr             x0, [fp, #0x18]
    // 0x9d7b9c: stur            x1, [fp, #-8]
    // 0x9d7ba0: StoreField: r1->field_f = r0
    //     0x9d7ba0: stur            w0, [x1, #0xf]
    // 0x9d7ba4: ldr             x16, [fp, #0x10]
    // 0x9d7ba8: r30 = 0.000000
    //     0x9d7ba8: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x9d7bac: stp             lr, x16, [SP, #-0x10]!
    // 0x9d7bb0: r0 = ==()
    //     0x9d7bb0: bl              #0xcbbae4  ; [dart:core] _Double::==
    // 0x9d7bb4: add             SP, SP, #0x10
    // 0x9d7bb8: tbnz            w0, #4, #0x9d7bcc
    // 0x9d7bbc: ldr             x0, [fp, #0x10]
    // 0x9d7bc0: d2 = 0.000000
    //     0x9d7bc0: eor             v2.16b, v2.16b, v2.16b
    // 0x9d7bc4: d0 = 0.000000
    //     0x9d7bc4: eor             v0.16b, v0.16b, v0.16b
    // 0x9d7bc8: b               #0x9d7bf8
    // 0x9d7bcc: ldr             x0, [fp, #0x10]
    // 0x9d7bd0: d0 = 0.000000
    //     0x9d7bd0: eor             v0.16b, v0.16b, v0.16b
    // 0x9d7bd4: cmp             w0, NULL
    // 0x9d7bd8: b.eq            #0x9d7ebc
    // 0x9d7bdc: LoadField: d1 = r0->field_7
    //     0x9d7bdc: ldur            d1, [x0, #7]
    // 0x9d7be0: fcmp            d1, d0
    // 0x9d7be4: b.vs            #0x9d7bf4
    // 0x9d7be8: b.ge            #0x9d7bf4
    // 0x9d7bec: fneg            d2, d1
    // 0x9d7bf0: mov             v1.16b, v2.16b
    // 0x9d7bf4: mov             v2.16b, v1.16b
    // 0x9d7bf8: d1 = 1.000000
    //     0x9d7bf8: fmov            d1, #1.00000000
    // 0x9d7bfc: fcmp            d2, d1
    // 0x9d7c00: b.vs            #0x9d7c28
    // 0x9d7c04: b.lt            #0x9d7c28
    // 0x9d7c08: cmp             w0, NULL
    // 0x9d7c0c: b.eq            #0x9d7ec0
    // 0x9d7c10: LoadField: d2 = r0->field_7
    //     0x9d7c10: ldur            d2, [x0, #7]
    // 0x9d7c14: fcmp            d2, d0
    // 0x9d7c18: b.vs            #0x9d7d38
    // 0x9d7c1c: b.gt            #0x9d7d38
    // 0x9d7c20: ldr             x0, [fp, #0x18]
    // 0x9d7c24: b               #0x9d7c5c
    // 0x9d7c28: ldr             x0, [fp, #0x18]
    // 0x9d7c2c: d0 = 0.500000
    //     0x9d7c2c: fmov            d0, #0.50000000
    // 0x9d7c30: LoadField: r1 = r0->field_b
    //     0x9d7c30: ldur            w1, [x0, #0xb]
    // 0x9d7c34: DecompressPointer r1
    //     0x9d7c34: add             x1, x1, HEAP, lsl #32
    // 0x9d7c38: LoadField: r2 = r1->field_37
    //     0x9d7c38: ldur            w2, [x1, #0x37]
    // 0x9d7c3c: DecompressPointer r2
    //     0x9d7c3c: add             x2, x2, HEAP, lsl #32
    // 0x9d7c40: r16 = Sentinel
    //     0x9d7c40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d7c44: cmp             w2, w16
    // 0x9d7c48: b.eq            #0x9d7ec4
    // 0x9d7c4c: LoadField: d2 = r2->field_7
    //     0x9d7c4c: ldur            d2, [x2, #7]
    // 0x9d7c50: fcmp            d2, d0
    // 0x9d7c54: b.vs            #0x9d7d38
    // 0x9d7c58: b.le            #0x9d7d38
    // 0x9d7c5c: LoadField: r1 = r0->field_b
    //     0x9d7c5c: ldur            w1, [x0, #0xb]
    // 0x9d7c60: DecompressPointer r1
    //     0x9d7c60: add             x1, x1, HEAP, lsl #32
    // 0x9d7c64: stur            x1, [fp, #-0x10]
    // 0x9d7c68: LoadField: r2 = r1->field_37
    //     0x9d7c68: ldur            w2, [x1, #0x37]
    // 0x9d7c6c: DecompressPointer r2
    //     0x9d7c6c: add             x2, x2, HEAP, lsl #32
    // 0x9d7c70: r16 = Sentinel
    //     0x9d7c70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d7c74: cmp             w2, w16
    // 0x9d7c78: b.eq            #0x9d7ed0
    // 0x9d7c7c: r16 = 1600
    //     0x9d7c7c: mov             x16, #0x640
    // 0x9d7c80: stp             xzr, x16, [SP, #-0x10]!
    // 0x9d7c84: SaveReg r2
    //     0x9d7c84: str             x2, [SP, #-8]!
    // 0x9d7c88: r0 = lerpDouble()
    //     0x9d7c88: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x9d7c8c: add             SP, SP, #0x18
    // 0x9d7c90: cmp             w0, NULL
    // 0x9d7c94: b.eq            #0x9d7edc
    // 0x9d7c98: LoadField: d0 = r0->field_7
    //     0x9d7c98: ldur            d0, [x0, #7]
    // 0x9d7c9c: fcmp            d0, d0
    // 0x9d7ca0: b.vs            #0x9d7ee0
    // 0x9d7ca4: fcvtms          x0, d0
    // 0x9d7ca8: asr             x16, x0, #0x1e
    // 0x9d7cac: cmp             x16, x0, asr #63
    // 0x9d7cb0: b.ne            #0x9d7ee0
    // 0x9d7cb4: lsl             x0, x0, #1
    // 0x9d7cb8: r1 = LoadInt32Instr(r0)
    //     0x9d7cb8: sbfx            x1, x0, #1, #0x1f
    //     0x9d7cbc: tbz             w0, #0, #0x9d7cc4
    //     0x9d7cc0: ldur            x1, [x0, #7]
    // 0x9d7cc4: cmp             x1, #0x12c
    // 0x9d7cc8: b.le            #0x9d7cd4
    // 0x9d7ccc: r0 = 300
    //     0x9d7ccc: mov             x0, #0x12c
    // 0x9d7cd0: b               #0x9d7ce8
    // 0x9d7cd4: cmp             x1, #0x12c
    // 0x9d7cd8: b.ge            #0x9d7ce4
    // 0x9d7cdc: mov             x0, x1
    // 0x9d7ce0: b               #0x9d7ce8
    // 0x9d7ce4: mov             x0, x1
    // 0x9d7ce8: r16 = 1000
    //     0x9d7ce8: mov             x16, #0x3e8
    // 0x9d7cec: mul             x1, x0, x16
    // 0x9d7cf0: stur            x1, [fp, #-0x18]
    // 0x9d7cf4: r0 = Duration()
    //     0x9d7cf4: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x9d7cf8: mov             x1, x0
    // 0x9d7cfc: ldur            x0, [fp, #-0x18]
    // 0x9d7d00: StoreField: r1->field_7 = r0
    //     0x9d7d00: stur            x0, [x1, #7]
    // 0x9d7d04: ldur            x16, [fp, #-0x10]
    // 0x9d7d08: SaveReg r16
    //     0x9d7d08: str             x16, [SP, #-8]!
    // 0x9d7d0c: d0 = 1.000000
    //     0x9d7d0c: fmov            d0, #1.00000000
    // 0x9d7d10: SaveReg d0
    //     0x9d7d10: str             d0, [SP, #-8]!
    // 0x9d7d14: r16 = Instance_Cubic
    //     0x9d7d14: add             x16, PP, #0x3b, lsl #12  ; [pp+0x3bc30] Obj!Cubic<double>@b4f581
    //     0x9d7d18: ldr             x16, [x16, #0xc30]
    // 0x9d7d1c: stp             x16, x1, [SP, #-0x10]!
    // 0x9d7d20: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x9d7d20: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x9d7d24: ldr             x4, [x4, #0x2a0]
    // 0x9d7d28: r0 = animateTo()
    //     0x9d7d28: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x9d7d2c: add             SP, SP, #0x20
    // 0x9d7d30: ldur            x0, [fp, #-0x10]
    // 0x9d7d34: b               #0x9d7e14
    // 0x9d7d38: ldr             x0, [fp, #0x18]
    // 0x9d7d3c: LoadField: r1 = r0->field_f
    //     0x9d7d3c: ldur            w1, [x0, #0xf]
    // 0x9d7d40: DecompressPointer r1
    //     0x9d7d40: add             x1, x1, HEAP, lsl #32
    // 0x9d7d44: r16 = <Object?>
    //     0x9d7d44: ldr             x16, [PP, #0xa08]  ; [pp+0xa08] TypeArguments: <Object?>
    // 0x9d7d48: stp             x1, x16, [SP, #-0x10]!
    // 0x9d7d4c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x9d7d4c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x9d7d50: r0 = pop()
    //     0x9d7d50: bl              #0x516334  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::pop
    // 0x9d7d54: add             SP, SP, #0x10
    // 0x9d7d58: ldr             x0, [fp, #0x18]
    // 0x9d7d5c: LoadField: r1 = r0->field_b
    //     0x9d7d5c: ldur            w1, [x0, #0xb]
    // 0x9d7d60: DecompressPointer r1
    //     0x9d7d60: add             x1, x1, HEAP, lsl #32
    // 0x9d7d64: stur            x1, [fp, #-0x10]
    // 0x9d7d68: LoadField: r2 = r1->field_2f
    //     0x9d7d68: ldur            w2, [x1, #0x2f]
    // 0x9d7d6c: DecompressPointer r2
    //     0x9d7d6c: add             x2, x2, HEAP, lsl #32
    // 0x9d7d70: cmp             w2, NULL
    // 0x9d7d74: b.eq            #0x9d7e10
    // 0x9d7d78: LoadField: r3 = r2->field_7
    //     0x9d7d78: ldur            w3, [x2, #7]
    // 0x9d7d7c: DecompressPointer r3
    //     0x9d7d7c: add             x3, x3, HEAP, lsl #32
    // 0x9d7d80: cmp             w3, NULL
    // 0x9d7d84: b.eq            #0x9d7e10
    // 0x9d7d88: LoadField: r2 = r1->field_37
    //     0x9d7d88: ldur            w2, [x1, #0x37]
    // 0x9d7d8c: DecompressPointer r2
    //     0x9d7d8c: add             x2, x2, HEAP, lsl #32
    // 0x9d7d90: r16 = Sentinel
    //     0x9d7d90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d7d94: cmp             w2, w16
    // 0x9d7d98: b.eq            #0x9d7efc
    // 0x9d7d9c: r16 = 1600
    //     0x9d7d9c: mov             x16, #0x640
    // 0x9d7da0: stp             x16, xzr, [SP, #-0x10]!
    // 0x9d7da4: SaveReg r2
    //     0x9d7da4: str             x2, [SP, #-8]!
    // 0x9d7da8: r0 = lerpDouble()
    //     0x9d7da8: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x9d7dac: add             SP, SP, #0x18
    // 0x9d7db0: cmp             w0, NULL
    // 0x9d7db4: b.eq            #0x9d7f08
    // 0x9d7db8: LoadField: d0 = r0->field_7
    //     0x9d7db8: ldur            d0, [x0, #7]
    // 0x9d7dbc: fcmp            d0, d0
    // 0x9d7dc0: b.vs            #0x9d7f0c
    // 0x9d7dc4: fcvtms          x0, d0
    // 0x9d7dc8: asr             x16, x0, #0x1e
    // 0x9d7dcc: cmp             x16, x0, asr #63
    // 0x9d7dd0: b.ne            #0x9d7f0c
    // 0x9d7dd4: lsl             x0, x0, #1
    // 0x9d7dd8: r1 = LoadInt32Instr(r0)
    //     0x9d7dd8: sbfx            x1, x0, #1, #0x1f
    //     0x9d7ddc: tbz             w0, #0, #0x9d7de4
    //     0x9d7de0: ldur            x1, [x0, #7]
    // 0x9d7de4: r16 = 1000
    //     0x9d7de4: mov             x16, #0x3e8
    // 0x9d7de8: mul             x0, x1, x16
    // 0x9d7dec: stur            x0, [fp, #-0x18]
    // 0x9d7df0: r0 = Duration()
    //     0x9d7df0: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x9d7df4: mov             x1, x0
    // 0x9d7df8: ldur            x0, [fp, #-0x18]
    // 0x9d7dfc: StoreField: r1->field_7 = r0
    //     0x9d7dfc: stur            x0, [x1, #7]
    // 0x9d7e00: ldur            x16, [fp, #-0x10]
    // 0x9d7e04: stp             x1, x16, [SP, #-0x10]!
    // 0x9d7e08: r0 = animateBack()
    //     0x9d7e08: bl              #0x9d80b8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateBack
    // 0x9d7e0c: add             SP, SP, #0x10
    // 0x9d7e10: ldur            x0, [fp, #-0x10]
    // 0x9d7e14: stur            x0, [fp, #-0x10]
    // 0x9d7e18: LoadField: r1 = r0->field_2f
    //     0x9d7e18: ldur            w1, [x0, #0x2f]
    // 0x9d7e1c: DecompressPointer r1
    //     0x9d7e1c: add             x1, x1, HEAP, lsl #32
    // 0x9d7e20: cmp             w1, NULL
    // 0x9d7e24: b.eq            #0x9d7e8c
    // 0x9d7e28: LoadField: r2 = r1->field_7
    //     0x9d7e28: ldur            w2, [x1, #7]
    // 0x9d7e2c: DecompressPointer r2
    //     0x9d7e2c: add             x2, x2, HEAP, lsl #32
    // 0x9d7e30: cmp             w2, NULL
    // 0x9d7e34: b.eq            #0x9d7e8c
    // 0x9d7e38: ldur            x3, [fp, #-8]
    // 0x9d7e3c: r1 = Sentinel
    //     0x9d7e3c: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d7e40: StoreField: r3->field_13 = r1
    //     0x9d7e40: stur            w1, [x3, #0x13]
    // 0x9d7e44: mov             x2, x3
    // 0x9d7e48: r1 = Function '<anonymous closure>':.
    //     0x9d7e48: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4baf8] AnonymousClosure: (0x9d8114), in [package:get/get_navigation/src/routes/get_transition_mixin.dart] CupertinoBackGestureController::dragEnd (0x9d81cc)
    //     0x9d7e4c: ldr             x1, [x1, #0xaf8]
    // 0x9d7e50: r0 = AllocateClosure()
    //     0x9d7e50: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7e54: mov             x2, x0
    // 0x9d7e58: ldur            x1, [fp, #-8]
    // 0x9d7e5c: StoreField: r1->field_13 = r0
    //     0x9d7e5c: stur            w0, [x1, #0x13]
    //     0x9d7e60: ldurb           w16, [x1, #-1]
    //     0x9d7e64: ldurb           w17, [x0, #-1]
    //     0x9d7e68: and             x16, x17, x16, lsr #2
    //     0x9d7e6c: tst             x16, HEAP, lsr #32
    //     0x9d7e70: b.eq            #0x9d7e78
    //     0x9d7e74: bl              #0xd6826c
    // 0x9d7e78: ldur            x16, [fp, #-0x10]
    // 0x9d7e7c: stp             x2, x16, [SP, #-0x10]!
    // 0x9d7e80: r0 = addStatusListener()
    //     0x9d7e80: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x9d7e84: add             SP, SP, #0x10
    // 0x9d7e88: b               #0x9d7ea4
    // 0x9d7e8c: ldr             x0, [fp, #0x18]
    // 0x9d7e90: LoadField: r1 = r0->field_f
    //     0x9d7e90: ldur            w1, [x0, #0xf]
    // 0x9d7e94: DecompressPointer r1
    //     0x9d7e94: add             x1, x1, HEAP, lsl #32
    // 0x9d7e98: SaveReg r1
    //     0x9d7e98: str             x1, [SP, #-8]!
    // 0x9d7e9c: r0 = didStopUserGesture()
    //     0x9d7e9c: bl              #0x9d7f28  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::didStopUserGesture
    // 0x9d7ea0: add             SP, SP, #8
    // 0x9d7ea4: r0 = Null
    //     0x9d7ea4: mov             x0, NULL
    // 0x9d7ea8: LeaveFrame
    //     0x9d7ea8: mov             SP, fp
    //     0x9d7eac: ldp             fp, lr, [SP], #0x10
    // 0x9d7eb0: ret
    //     0x9d7eb0: ret             
    // 0x9d7eb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7eb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7eb8: b               #0x9d7b8c
    // 0x9d7ebc: r0 = NullErrorSharedWithFPURegs()
    //     0x9d7ebc: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x9d7ec0: r0 = NullErrorSharedWithFPURegs()
    //     0x9d7ec0: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x9d7ec4: r9 = _value
    //     0x9d7ec4: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x9d7ec8: ldr             x9, [x9, #0xbb0]
    // 0x9d7ecc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x9d7ecc: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x9d7ed0: r9 = _value
    //     0x9d7ed0: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x9d7ed4: ldr             x9, [x9, #0xbb0]
    // 0x9d7ed8: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x9d7ed8: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x9d7edc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7edc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d7ee0: SaveReg d0
    //     0x9d7ee0: str             q0, [SP, #-0x10]!
    // 0x9d7ee4: r0 = 212
    //     0x9d7ee4: mov             x0, #0xd4
    // 0x9d7ee8: r24 = DoubleToIntegerStub
    //     0x9d7ee8: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x9d7eec: LoadField: r30 = r24->field_7
    //     0x9d7eec: ldur            lr, [x24, #7]
    // 0x9d7ef0: blr             lr
    // 0x9d7ef4: RestoreReg d0
    //     0x9d7ef4: ldr             q0, [SP], #0x10
    // 0x9d7ef8: b               #0x9d7cb8
    // 0x9d7efc: r9 = _value
    //     0x9d7efc: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x9d7f00: ldr             x9, [x9, #0xbb0]
    // 0x9d7f04: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9d7f04: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9d7f08: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7f08: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d7f0c: SaveReg d0
    //     0x9d7f0c: str             q0, [SP, #-0x10]!
    // 0x9d7f10: r0 = 212
    //     0x9d7f10: mov             x0, #0xd4
    // 0x9d7f14: r24 = DoubleToIntegerStub
    //     0x9d7f14: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x9d7f18: LoadField: r30 = r24->field_7
    //     0x9d7f18: ldur            lr, [x24, #7]
    // 0x9d7f1c: blr             lr
    // 0x9d7f20: RestoreReg d0
    //     0x9d7f20: ldr             q0, [SP], #0x10
    // 0x9d7f24: b               #0x9d7dd8
  }
  _ dragUpdate(/* No info */) {
    // ** addr: 0x9d890c, size: 0x84
    // 0x9d890c: EnterFrame
    //     0x9d890c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8910: mov             fp, SP
    // 0x9d8914: CheckStackOverflow
    //     0x9d8914: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8918: cmp             SP, x16
    //     0x9d891c: b.ls            #0x9d8978
    // 0x9d8920: ldr             x0, [fp, #0x18]
    // 0x9d8924: LoadField: r1 = r0->field_b
    //     0x9d8924: ldur            w1, [x0, #0xb]
    // 0x9d8928: DecompressPointer r1
    //     0x9d8928: add             x1, x1, HEAP, lsl #32
    // 0x9d892c: LoadField: r0 = r1->field_37
    //     0x9d892c: ldur            w0, [x1, #0x37]
    // 0x9d8930: DecompressPointer r0
    //     0x9d8930: add             x0, x0, HEAP, lsl #32
    // 0x9d8934: r16 = Sentinel
    //     0x9d8934: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x9d8938: cmp             w0, w16
    // 0x9d893c: b.eq            #0x9d8980
    // 0x9d8940: ldr             x2, [fp, #0x10]
    // 0x9d8944: cmp             w2, NULL
    // 0x9d8948: b.eq            #0x9d898c
    // 0x9d894c: LoadField: d0 = r0->field_7
    //     0x9d894c: ldur            d0, [x0, #7]
    // 0x9d8950: LoadField: d1 = r2->field_7
    //     0x9d8950: ldur            d1, [x2, #7]
    // 0x9d8954: fsub            d2, d0, d1
    // 0x9d8958: SaveReg r1
    //     0x9d8958: str             x1, [SP, #-8]!
    // 0x9d895c: SaveReg d2
    //     0x9d895c: str             d2, [SP, #-8]!
    // 0x9d8960: r0 = value=()
    //     0x9d8960: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x9d8964: add             SP, SP, #0x10
    // 0x9d8968: r0 = Null
    //     0x9d8968: mov             x0, NULL
    // 0x9d896c: LeaveFrame
    //     0x9d896c: mov             SP, fp
    //     0x9d8970: ldp             fp, lr, [SP], #0x10
    // 0x9d8974: ret
    //     0x9d8974: ret             
    // 0x9d8978: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8978: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d897c: b               #0x9d8920
    // 0x9d8980: r9 = _value
    //     0x9d8980: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x9d8984: ldr             x9, [x9, #0xbb0]
    // 0x9d8988: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x9d8988: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x9d898c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x9d898c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

// class id: 4229, size: 0x8, field offset: 0x8
abstract class CupertinoRouteTransitionMixin extends Object {

  static _ isPopGestureInProgress(/* No info */) {
    // ** addr: 0xa88d7c, size: 0x3c
    // 0xa88d7c: EnterFrame
    //     0xa88d7c: stp             fp, lr, [SP, #-0x10]!
    //     0xa88d80: mov             fp, SP
    // 0xa88d84: ldr             x1, [fp, #0x10]
    // 0xa88d88: LoadField: r2 = r1->field_b
    //     0xa88d88: ldur            w2, [x1, #0xb]
    // 0xa88d8c: DecompressPointer r2
    //     0xa88d8c: add             x2, x2, HEAP, lsl #32
    // 0xa88d90: cmp             w2, NULL
    // 0xa88d94: b.eq            #0xa88db4
    // 0xa88d98: LoadField: r1 = r2->field_5f
    //     0xa88d98: ldur            w1, [x2, #0x5f]
    // 0xa88d9c: DecompressPointer r1
    //     0xa88d9c: add             x1, x1, HEAP, lsl #32
    // 0xa88da0: LoadField: r0 = r1->field_27
    //     0xa88da0: ldur            w0, [x1, #0x27]
    // 0xa88da4: DecompressPointer r0
    //     0xa88da4: add             x0, x0, HEAP, lsl #32
    // 0xa88da8: LeaveFrame
    //     0xa88da8: mov             SP, fp
    //     0xa88dac: ldp             fp, lr, [SP], #0x10
    // 0xa88db0: ret
    //     0xa88db0: ret             
    // 0xa88db4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa88db4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ buildPageTransitions(/* No info */) {
    // ** addr: 0xcf4e58, size: 0x11c
    // 0xcf4e58: EnterFrame
    //     0xcf4e58: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4e5c: mov             fp, SP
    // 0xcf4e60: AllocStack(0x20)
    //     0xcf4e60: sub             SP, SP, #0x20
    // 0xcf4e64: SetupParameters()
    //     0xcf4e64: mov             x0, x4
    //     0xcf4e68: ldur            w1, [x0, #0xf]
    //     0xcf4e6c: add             x1, x1, HEAP, lsl #32
    //     0xcf4e70: cbnz            w1, #0xcf4e7c
    //     0xcf4e74: mov             x2, NULL
    //     0xcf4e78: b               #0xcf4e90
    //     0xcf4e7c: ldur            w1, [x0, #0x17]
    //     0xcf4e80: add             x1, x1, HEAP, lsl #32
    //     0xcf4e84: add             x0, fp, w1, sxtw #2
    //     0xcf4e88: ldr             x0, [x0, #0x10]
    //     0xcf4e8c: mov             x2, x0
    //     0xcf4e90: ldr             x1, [fp, #0x28]
    //     0xcf4e94: ldr             x0, [fp, #0x10]
    //     0xcf4e98: stur            x2, [fp, #-8]
    // 0xcf4e9c: CheckStackOverflow
    //     0xcf4e9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf4ea0: cmp             SP, x16
    //     0xcf4ea4: b.ls            #0xcf4f6c
    // 0xcf4ea8: r1 = 1
    //     0xcf4ea8: mov             x1, #1
    // 0xcf4eac: r0 = AllocateContext()
    //     0xcf4eac: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcf4eb0: mov             x1, x0
    // 0xcf4eb4: ldr             x0, [fp, #0x28]
    // 0xcf4eb8: stur            x1, [fp, #-0x10]
    // 0xcf4ebc: StoreField: r1->field_f = r0
    //     0xcf4ebc: stur            w0, [x1, #0xf]
    // 0xcf4ec0: SaveReg r0
    //     0xcf4ec0: str             x0, [SP, #-8]!
    // 0xcf4ec4: r0 = isPopGestureInProgress()
    //     0xcf4ec4: bl              #0xa88d7c  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::isPopGestureInProgress
    // 0xcf4ec8: add             SP, SP, #8
    // 0xcf4ecc: ldur            x2, [fp, #-0x10]
    // 0xcf4ed0: r1 = Function '<anonymous closure>': static.
    //     0xcf4ed0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37790] AnonymousClosure: static (0xcf5098), in [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::buildPageTransitions (0xcf4e58)
    //     0xcf4ed4: ldr             x1, [x1, #0x790]
    // 0xcf4ed8: stur            x0, [fp, #-0x18]
    // 0xcf4edc: r0 = AllocateClosure()
    //     0xcf4edc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcf4ee0: mov             x3, x0
    // 0xcf4ee4: ldur            x0, [fp, #-8]
    // 0xcf4ee8: stur            x3, [fp, #-0x20]
    // 0xcf4eec: StoreField: r3->field_b = r0
    //     0xcf4eec: stur            w0, [x3, #0xb]
    // 0xcf4ef0: ldur            x2, [fp, #-0x10]
    // 0xcf4ef4: r1 = Function '<anonymous closure>': static.
    //     0xcf4ef4: add             x1, PP, #0x37, lsl #12  ; [pp+0x37798] AnonymousClosure: static (0xcf4f80), in [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::buildPageTransitions (0xcf4e58)
    //     0xcf4ef8: ldr             x1, [x1, #0x798]
    // 0xcf4efc: r0 = AllocateClosure()
    //     0xcf4efc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcf4f00: ldur            x1, [fp, #-8]
    // 0xcf4f04: stur            x0, [fp, #-0x10]
    // 0xcf4f08: StoreField: r0->field_b = r1
    //     0xcf4f08: stur            w1, [x0, #0xb]
    // 0xcf4f0c: r0 = _CupertinoBackGestureDetector()
    //     0xcf4f0c: bl              #0xcf4f74  ; Allocate_CupertinoBackGestureDetectorStub -> _CupertinoBackGestureDetector<X0> (size=0x1c)
    // 0xcf4f10: mov             x1, x0
    // 0xcf4f14: ldur            x0, [fp, #-0x20]
    // 0xcf4f18: stur            x1, [fp, #-8]
    // 0xcf4f1c: StoreField: r1->field_13 = r0
    //     0xcf4f1c: stur            w0, [x1, #0x13]
    // 0xcf4f20: ldur            x0, [fp, #-0x10]
    // 0xcf4f24: StoreField: r1->field_17 = r0
    //     0xcf4f24: stur            w0, [x1, #0x17]
    // 0xcf4f28: ldr             x0, [fp, #0x10]
    // 0xcf4f2c: StoreField: r1->field_f = r0
    //     0xcf4f2c: stur            w0, [x1, #0xf]
    // 0xcf4f30: r0 = CupertinoPageTransition()
    //     0xcf4f30: bl              #0xa8a4a8  ; AllocateCupertinoPageTransitionStub -> CupertinoPageTransition (size=0x1c)
    // 0xcf4f34: stur            x0, [fp, #-0x10]
    // 0xcf4f38: ldur            x16, [fp, #-8]
    // 0xcf4f3c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf4f40: ldur            x16, [fp, #-0x18]
    // 0xcf4f44: ldr             lr, [fp, #0x20]
    // 0xcf4f48: stp             lr, x16, [SP, #-0x10]!
    // 0xcf4f4c: ldr             x16, [fp, #0x18]
    // 0xcf4f50: SaveReg r16
    //     0xcf4f50: str             x16, [SP, #-8]!
    // 0xcf4f54: r0 = CupertinoPageTransition()
    //     0xcf4f54: bl              #0xa8a170  ; [package:flutter/src/cupertino/route.dart] CupertinoPageTransition::CupertinoPageTransition
    // 0xcf4f58: add             SP, SP, #0x28
    // 0xcf4f5c: ldur            x0, [fp, #-0x10]
    // 0xcf4f60: LeaveFrame
    //     0xcf4f60: mov             SP, fp
    //     0xcf4f64: ldp             fp, lr, [SP], #0x10
    // 0xcf4f68: ret
    //     0xcf4f68: ret             
    // 0xcf4f6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4f6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4f70: b               #0xcf4ea8
  }
  [closure] static _CupertinoBackGestureController<Y0> <anonymous closure>(dynamic) {
    // ** addr: 0xcf4f80, size: 0x54
    // 0xcf4f80: EnterFrame
    //     0xcf4f80: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4f84: mov             fp, SP
    // 0xcf4f88: ldr             x0, [fp, #0x10]
    // 0xcf4f8c: LoadField: r1 = r0->field_17
    //     0xcf4f8c: ldur            w1, [x0, #0x17]
    // 0xcf4f90: DecompressPointer r1
    //     0xcf4f90: add             x1, x1, HEAP, lsl #32
    // 0xcf4f94: CheckStackOverflow
    //     0xcf4f94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf4f98: cmp             SP, x16
    //     0xcf4f9c: b.ls            #0xcf4fcc
    // 0xcf4fa0: LoadField: r2 = r0->field_b
    //     0xcf4fa0: ldur            w2, [x0, #0xb]
    // 0xcf4fa4: DecompressPointer r2
    //     0xcf4fa4: add             x2, x2, HEAP, lsl #32
    // 0xcf4fa8: LoadField: r0 = r1->field_f
    //     0xcf4fa8: ldur            w0, [x1, #0xf]
    // 0xcf4fac: DecompressPointer r0
    //     0xcf4fac: add             x0, x0, HEAP, lsl #32
    // 0xcf4fb0: stp             x0, x2, [SP, #-0x10]!
    // 0xcf4fb4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcf4fb4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcf4fb8: r0 = _startPopGesture()
    //     0xcf4fb8: bl              #0xcf4fd4  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::_startPopGesture
    // 0xcf4fbc: add             SP, SP, #0x10
    // 0xcf4fc0: LeaveFrame
    //     0xcf4fc0: mov             SP, fp
    //     0xcf4fc4: ldp             fp, lr, [SP], #0x10
    // 0xcf4fc8: ret
    //     0xcf4fc8: ret             
    // 0xcf4fcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf4fcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf4fd0: b               #0xcf4fa0
  }
  static _ _startPopGesture(/* No info */) {
    // ** addr: 0xcf4fd4, size: 0xb8
    // 0xcf4fd4: EnterFrame
    //     0xcf4fd4: stp             fp, lr, [SP, #-0x10]!
    //     0xcf4fd8: mov             fp, SP
    // 0xcf4fdc: AllocStack(0x18)
    //     0xcf4fdc: sub             SP, SP, #0x18
    // 0xcf4fe0: SetupParameters()
    //     0xcf4fe0: mov             x0, x4
    //     0xcf4fe4: ldur            w1, [x0, #0xf]
    //     0xcf4fe8: add             x1, x1, HEAP, lsl #32
    //     0xcf4fec: cbnz            w1, #0xcf4ff8
    //     0xcf4ff0: mov             x1, NULL
    //     0xcf4ff4: b               #0xcf500c
    //     0xcf4ff8: ldur            w1, [x0, #0x17]
    //     0xcf4ffc: add             x1, x1, HEAP, lsl #32
    //     0xcf5000: add             x0, fp, w1, sxtw #2
    //     0xcf5004: ldr             x0, [x0, #0x10]
    //     0xcf5008: mov             x1, x0
    //     0xcf500c: ldr             x0, [fp, #0x10]
    // 0xcf5010: CheckStackOverflow
    //     0xcf5010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf5014: cmp             SP, x16
    //     0xcf5018: b.ls            #0xcf507c
    // 0xcf501c: LoadField: r2 = r0->field_b
    //     0xcf501c: ldur            w2, [x0, #0xb]
    // 0xcf5020: DecompressPointer r2
    //     0xcf5020: add             x2, x2, HEAP, lsl #32
    // 0xcf5024: stur            x2, [fp, #-0x10]
    // 0xcf5028: cmp             w2, NULL
    // 0xcf502c: b.eq            #0xcf5084
    // 0xcf5030: LoadField: r3 = r0->field_2f
    //     0xcf5030: ldur            w3, [x0, #0x2f]
    // 0xcf5034: DecompressPointer r3
    //     0xcf5034: add             x3, x3, HEAP, lsl #32
    // 0xcf5038: stur            x3, [fp, #-8]
    // 0xcf503c: cmp             w3, NULL
    // 0xcf5040: b.eq            #0xcf5088
    // 0xcf5044: r0 = _CupertinoBackGestureController()
    //     0xcf5044: bl              #0xcf508c  ; Allocate_CupertinoBackGestureControllerStub -> _CupertinoBackGestureController<X0> (size=0x14)
    // 0xcf5048: mov             x1, x0
    // 0xcf504c: ldur            x0, [fp, #-0x10]
    // 0xcf5050: stur            x1, [fp, #-0x18]
    // 0xcf5054: StoreField: r1->field_f = r0
    //     0xcf5054: stur            w0, [x1, #0xf]
    // 0xcf5058: ldur            x2, [fp, #-8]
    // 0xcf505c: StoreField: r1->field_b = r2
    //     0xcf505c: stur            w2, [x1, #0xb]
    // 0xcf5060: SaveReg r0
    //     0xcf5060: str             x0, [SP, #-8]!
    // 0xcf5064: r0 = didStartUserGesture()
    //     0xcf5064: bl              #0xa8ac94  ; [package:flutter/src/widgets/navigator.dart] NavigatorState::didStartUserGesture
    // 0xcf5068: add             SP, SP, #8
    // 0xcf506c: ldur            x0, [fp, #-0x18]
    // 0xcf5070: LeaveFrame
    //     0xcf5070: mov             SP, fp
    //     0xcf5074: ldp             fp, lr, [SP], #0x10
    // 0xcf5078: ret
    //     0xcf5078: ret             
    // 0xcf507c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf507c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf5080: b               #0xcf501c
    // 0xcf5084: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf5084: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf5088: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf5088: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic) {
    // ** addr: 0xcf5098, size: 0x54
    // 0xcf5098: EnterFrame
    //     0xcf5098: stp             fp, lr, [SP, #-0x10]!
    //     0xcf509c: mov             fp, SP
    // 0xcf50a0: ldr             x0, [fp, #0x10]
    // 0xcf50a4: LoadField: r1 = r0->field_17
    //     0xcf50a4: ldur            w1, [x0, #0x17]
    // 0xcf50a8: DecompressPointer r1
    //     0xcf50a8: add             x1, x1, HEAP, lsl #32
    // 0xcf50ac: CheckStackOverflow
    //     0xcf50ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf50b0: cmp             SP, x16
    //     0xcf50b4: b.ls            #0xcf50e4
    // 0xcf50b8: LoadField: r2 = r0->field_b
    //     0xcf50b8: ldur            w2, [x0, #0xb]
    // 0xcf50bc: DecompressPointer r2
    //     0xcf50bc: add             x2, x2, HEAP, lsl #32
    // 0xcf50c0: LoadField: r0 = r1->field_f
    //     0xcf50c0: ldur            w0, [x1, #0xf]
    // 0xcf50c4: DecompressPointer r0
    //     0xcf50c4: add             x0, x0, HEAP, lsl #32
    // 0xcf50c8: stp             x0, x2, [SP, #-0x10]!
    // 0xcf50cc: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xcf50cc: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xcf50d0: r0 = _isPopGestureEnabled()
    //     0xcf50d0: bl              #0xcf50ec  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::_isPopGestureEnabled
    // 0xcf50d4: add             SP, SP, #0x10
    // 0xcf50d8: LeaveFrame
    //     0xcf50d8: mov             SP, fp
    //     0xcf50dc: ldp             fp, lr, [SP], #0x10
    // 0xcf50e0: ret
    //     0xcf50e0: ret             
    // 0xcf50e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf50e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf50e8: b               #0xcf50b8
  }
  static _ _isPopGestureEnabled(/* No info */) {
    // ** addr: 0xcf50ec, size: 0x14c
    // 0xcf50ec: EnterFrame
    //     0xcf50ec: stp             fp, lr, [SP, #-0x10]!
    //     0xcf50f0: mov             fp, SP
    // 0xcf50f4: CheckStackOverflow
    //     0xcf50f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf50f8: cmp             SP, x16
    //     0xcf50fc: b.ls            #0xcf5228
    // 0xcf5100: ldr             x16, [fp, #0x10]
    // 0xcf5104: SaveReg r16
    //     0xcf5104: str             x16, [SP, #-8]!
    // 0xcf5108: r0 = isFirst()
    //     0xcf5108: bl              #0x6fd248  ; [package:flutter/src/widgets/navigator.dart] Route::isFirst
    // 0xcf510c: add             SP, SP, #8
    // 0xcf5110: tbnz            w0, #4, #0xcf5124
    // 0xcf5114: r0 = false
    //     0xcf5114: add             x0, NULL, #0x30  ; false
    // 0xcf5118: LeaveFrame
    //     0xcf5118: mov             SP, fp
    //     0xcf511c: ldp             fp, lr, [SP], #0x10
    // 0xcf5120: ret
    //     0xcf5120: ret             
    // 0xcf5124: ldr             x0, [fp, #0x10]
    // 0xcf5128: LoadField: r1 = r0->field_43
    //     0xcf5128: ldur            w1, [x0, #0x43]
    // 0xcf512c: DecompressPointer r1
    //     0xcf512c: add             x1, x1, HEAP, lsl #32
    // 0xcf5130: cmp             w1, NULL
    // 0xcf5134: b.eq            #0xcf5154
    // 0xcf5138: LoadField: r2 = r1->field_b
    //     0xcf5138: ldur            w2, [x1, #0xb]
    // 0xcf513c: DecompressPointer r2
    //     0xcf513c: add             x2, x2, HEAP, lsl #32
    // 0xcf5140: cbz             w2, #0xcf5154
    // 0xcf5144: r0 = false
    //     0xcf5144: add             x0, NULL, #0x30  ; false
    // 0xcf5148: LeaveFrame
    //     0xcf5148: mov             SP, fp
    //     0xcf514c: ldp             fp, lr, [SP], #0x10
    // 0xcf5150: ret
    //     0xcf5150: ret             
    // 0xcf5154: LoadField: r1 = r0->field_5f
    //     0xcf5154: ldur            w1, [x0, #0x5f]
    // 0xcf5158: DecompressPointer r1
    //     0xcf5158: add             x1, x1, HEAP, lsl #32
    // 0xcf515c: LoadField: r2 = r1->field_b
    //     0xcf515c: ldur            w2, [x1, #0xb]
    // 0xcf5160: DecompressPointer r2
    //     0xcf5160: add             x2, x2, HEAP, lsl #32
    // 0xcf5164: cbz             w2, #0xcf5178
    // 0xcf5168: r0 = false
    //     0xcf5168: add             x0, NULL, #0x30  ; false
    // 0xcf516c: LeaveFrame
    //     0xcf516c: mov             SP, fp
    //     0xcf5170: ldp             fp, lr, [SP], #0x10
    // 0xcf5174: ret
    //     0xcf5174: ret             
    // 0xcf5178: LoadField: r1 = r0->field_57
    //     0xcf5178: ldur            w1, [x0, #0x57]
    // 0xcf517c: DecompressPointer r1
    //     0xcf517c: add             x1, x1, HEAP, lsl #32
    // 0xcf5180: cmp             w1, NULL
    // 0xcf5184: b.eq            #0xcf5230
    // 0xcf5188: SaveReg r1
    //     0xcf5188: str             x1, [SP, #-8]!
    // 0xcf518c: r0 = status()
    //     0xcf518c: bl              #0xc6476c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::status
    // 0xcf5190: add             SP, SP, #8
    // 0xcf5194: r16 = Instance_AnimationStatus
    //     0xcf5194: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba0] Obj!AnimationStatus@b65f71
    //     0xcf5198: ldr             x16, [x16, #0xba0]
    // 0xcf519c: cmp             w0, w16
    // 0xcf51a0: b.eq            #0xcf51b4
    // 0xcf51a4: r0 = false
    //     0xcf51a4: add             x0, NULL, #0x30  ; false
    // 0xcf51a8: LeaveFrame
    //     0xcf51a8: mov             SP, fp
    //     0xcf51ac: ldp             fp, lr, [SP], #0x10
    // 0xcf51b0: ret
    //     0xcf51b0: ret             
    // 0xcf51b4: ldr             x0, [fp, #0x10]
    // 0xcf51b8: LoadField: r1 = r0->field_5b
    //     0xcf51b8: ldur            w1, [x0, #0x5b]
    // 0xcf51bc: DecompressPointer r1
    //     0xcf51bc: add             x1, x1, HEAP, lsl #32
    // 0xcf51c0: cmp             w1, NULL
    // 0xcf51c4: b.eq            #0xcf5234
    // 0xcf51c8: SaveReg r1
    //     0xcf51c8: str             x1, [SP, #-8]!
    // 0xcf51cc: r0 = status()
    //     0xcf51cc: bl              #0xc6476c  ; [package:flutter/src/animation/animations.dart] ProxyAnimation::status
    // 0xcf51d0: add             SP, SP, #8
    // 0xcf51d4: r16 = Instance_AnimationStatus
    //     0xcf51d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0xcf51d8: ldr             x16, [x16, #0xba8]
    // 0xcf51dc: cmp             w0, w16
    // 0xcf51e0: b.eq            #0xcf51f4
    // 0xcf51e4: r0 = false
    //     0xcf51e4: add             x0, NULL, #0x30  ; false
    // 0xcf51e8: LeaveFrame
    //     0xcf51e8: mov             SP, fp
    //     0xcf51ec: ldp             fp, lr, [SP], #0x10
    // 0xcf51f0: ret
    //     0xcf51f0: ret             
    // 0xcf51f4: ldr             x16, [fp, #0x10]
    // 0xcf51f8: SaveReg r16
    //     0xcf51f8: str             x16, [SP, #-8]!
    // 0xcf51fc: r0 = isPopGestureInProgress()
    //     0xcf51fc: bl              #0xa88d7c  ; [package:flutter/src/cupertino/route.dart] CupertinoRouteTransitionMixin::isPopGestureInProgress
    // 0xcf5200: add             SP, SP, #8
    // 0xcf5204: tbnz            w0, #4, #0xcf5218
    // 0xcf5208: r0 = false
    //     0xcf5208: add             x0, NULL, #0x30  ; false
    // 0xcf520c: LeaveFrame
    //     0xcf520c: mov             SP, fp
    //     0xcf5210: ldp             fp, lr, [SP], #0x10
    // 0xcf5214: ret
    //     0xcf5214: ret             
    // 0xcf5218: r0 = true
    //     0xcf5218: add             x0, NULL, #0x20  ; true
    // 0xcf521c: LeaveFrame
    //     0xcf521c: mov             SP, fp
    //     0xcf5220: ldp             fp, lr, [SP], #0x10
    // 0xcf5224: ret
    //     0xcf5224: ret             
    // 0xcf5228: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf5228: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf522c: b               #0xcf5100
    // 0xcf5230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf5230: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcf5234: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcf5234: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4512, size: 0x10, field offset: 0xc
class _CupertinoEdgeShadowPainter extends BoxPainter {

  _ paint(/* No info */) {
    // ** addr: 0xc70350, size: 0x4d4
    // 0xc70350: EnterFrame
    //     0xc70350: stp             fp, lr, [SP, #-0x10]!
    //     0xc70354: mov             fp, SP
    // 0xc70358: AllocStack(0x78)
    //     0xc70358: sub             SP, SP, #0x78
    // 0xc7035c: CheckStackOverflow
    //     0xc7035c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc70360: cmp             SP, x16
    //     0xc70364: b.ls            #0xc70754
    // 0xc70368: ldr             x0, [fp, #0x28]
    // 0xc7036c: LoadField: r1 = r0->field_b
    //     0xc7036c: ldur            w1, [x0, #0xb]
    // 0xc70370: DecompressPointer r1
    //     0xc70370: add             x1, x1, HEAP, lsl #32
    // 0xc70374: LoadField: r2 = r1->field_7
    //     0xc70374: ldur            w2, [x1, #7]
    // 0xc70378: DecompressPointer r2
    //     0xc70378: add             x2, x2, HEAP, lsl #32
    // 0xc7037c: stur            x2, [fp, #-8]
    // 0xc70380: cmp             w2, NULL
    // 0xc70384: b.ne            #0xc70398
    // 0xc70388: r0 = Null
    //     0xc70388: mov             x0, NULL
    // 0xc7038c: LeaveFrame
    //     0xc7038c: mov             SP, fp
    //     0xc70390: ldp             fp, lr, [SP], #0x10
    // 0xc70394: ret
    //     0xc70394: ret             
    // 0xc70398: ldr             x1, [fp, #0x10]
    // 0xc7039c: d0 = 0.050000
    //     0xc7039c: add             x17, PP, #0xd, lsl #12  ; [pp+0xd208] IMM: double(0.05) from 0x3fa999999999999a
    //     0xc703a0: ldr             d0, [x17, #0x208]
    // 0xc703a4: LoadField: r0 = r1->field_17
    //     0xc703a4: ldur            w0, [x1, #0x17]
    // 0xc703a8: DecompressPointer r0
    //     0xc703a8: add             x0, x0, HEAP, lsl #32
    // 0xc703ac: cmp             w0, NULL
    // 0xc703b0: b.eq            #0xc7075c
    // 0xc703b4: LoadField: d1 = r0->field_7
    //     0xc703b4: ldur            d1, [x0, #7]
    // 0xc703b8: stur            d1, [fp, #-0x60]
    // 0xc703bc: fmul            d2, d0, d1
    // 0xc703c0: stur            d2, [fp, #-0x58]
    // 0xc703c4: LoadField: d0 = r0->field_f
    //     0xc703c4: ldur            d0, [x0, #0xf]
    // 0xc703c8: stur            d0, [fp, #-0x50]
    // 0xc703cc: r0 = LoadClassIdInstr(r2)
    //     0xc703cc: ldur            x0, [x2, #-1]
    //     0xc703d0: ubfx            x0, x0, #0xc, #0x14
    // 0xc703d4: SaveReg r2
    //     0xc703d4: str             x2, [SP, #-8]!
    // 0xc703d8: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc703d8: mov             x17, #0xb8ea
    //     0xc703dc: add             lr, x0, x17
    //     0xc703e0: ldr             lr, [x21, lr, lsl #3]
    //     0xc703e4: blr             lr
    // 0xc703e8: add             SP, SP, #8
    // 0xc703ec: r1 = LoadInt32Instr(r0)
    //     0xc703ec: sbfx            x1, x0, #1, #0x1f
    // 0xc703f0: sub             x0, x1, #1
    // 0xc703f4: scvtf           d0, x0
    // 0xc703f8: ldur            d1, [fp, #-0x58]
    // 0xc703fc: fdiv            d2, d1, d0
    // 0xc70400: ldr             x0, [fp, #0x10]
    // 0xc70404: stur            d2, [fp, #-0x78]
    // 0xc70408: LoadField: r1 = r0->field_13
    //     0xc70408: ldur            w1, [x0, #0x13]
    // 0xc7040c: DecompressPointer r1
    //     0xc7040c: add             x1, x1, HEAP, lsl #32
    // 0xc70410: cmp             w1, NULL
    // 0xc70414: b.eq            #0xc70760
    // 0xc70418: LoadField: r0 = r1->field_7
    //     0xc70418: ldur            x0, [x1, #7]
    // 0xc7041c: cmp             x0, #0
    // 0xc70420: b.gt            #0xc7043c
    // 0xc70424: ldr             x0, [fp, #0x18]
    // 0xc70428: ldur            d0, [fp, #-0x60]
    // 0xc7042c: LoadField: d3 = r0->field_7
    //     0xc7042c: ldur            d3, [x0, #7]
    // 0xc70430: fadd            d4, d3, d0
    // 0xc70434: d3 = 1.000000
    //     0xc70434: fmov            d3, #1.00000000
    // 0xc70438: b               #0xc7044c
    // 0xc7043c: ldr             x0, [fp, #0x18]
    // 0xc70440: LoadField: d0 = r0->field_7
    //     0xc70440: ldur            d0, [x0, #7]
    // 0xc70444: mov             v4.16b, v0.16b
    // 0xc70448: d3 = -1.000000
    //     0xc70448: fmov            d3, #-1.00000000
    // 0xc7044c: ldur            d0, [fp, #-0x50]
    // 0xc70450: stur            d4, [fp, #-0x68]
    // 0xc70454: stur            d3, [fp, #-0x70]
    // 0xc70458: r2 = inline_Allocate_Double()
    //     0xc70458: ldp             x2, x1, [THR, #0x60]  ; THR::top
    //     0xc7045c: add             x2, x2, #0x10
    //     0xc70460: cmp             x1, x2
    //     0xc70464: b.ls            #0xc70764
    //     0xc70468: str             x2, [THR, #0x60]  ; THR::top
    //     0xc7046c: sub             x2, x2, #0xf
    //     0xc70470: mov             x1, #0xd108
    //     0xc70474: movk            x1, #3, lsl #16
    //     0xc70478: stur            x1, [x2, #-1]
    // 0xc7047c: StoreField: r2->field_7 = d2
    //     0xc7047c: stur            d2, [x2, #7]
    // 0xc70480: stur            x2, [fp, #-0x30]
    // 0xc70484: LoadField: d5 = r0->field_f
    //     0xc70484: ldur            d5, [x0, #0xf]
    // 0xc70488: fadd            d6, d5, d0
    // 0xc7048c: stur            d6, [fp, #-0x60]
    // 0xc70490: r3 = inline_Allocate_Double()
    //     0xc70490: ldp             x3, x0, [THR, #0x60]  ; THR::top
    //     0xc70494: add             x3, x3, #0x10
    //     0xc70498: cmp             x0, x3
    //     0xc7049c: b.ls            #0xc70790
    //     0xc704a0: str             x3, [THR, #0x60]  ; THR::top
    //     0xc704a4: sub             x3, x3, #0xf
    //     0xc704a8: mov             x0, #0xd108
    //     0xc704ac: movk            x0, #3, lsl #16
    //     0xc704b0: stur            x0, [x3, #-1]
    // 0xc704b4: StoreField: r3->field_7 = d5
    //     0xc704b4: stur            d5, [x3, #7]
    // 0xc704b8: stur            x3, [fp, #-0x28]
    // 0xc704bc: r6 = 0
    //     0xc704bc: mov             x6, #0
    // 0xc704c0: r5 = 0
    //     0xc704c0: mov             x5, #0
    // 0xc704c4: ldur            x4, [fp, #-8]
    // 0xc704c8: stur            x6, [fp, #-0x18]
    // 0xc704cc: stur            x5, [fp, #-0x20]
    // 0xc704d0: CheckStackOverflow
    //     0xc704d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc704d4: cmp             SP, x16
    //     0xc704d8: b.ls            #0xc707bc
    // 0xc704dc: scvtf           d0, x5
    // 0xc704e0: stur            d0, [fp, #-0x50]
    // 0xc704e4: fcmp            d0, d1
    // 0xc704e8: b.vs            #0xc70744
    // 0xc704ec: b.ge            #0xc70744
    // 0xc704f0: r0 = BoxInt64Instr(r5)
    //     0xc704f0: sbfiz           x0, x5, #1, #0x1f
    //     0xc704f4: cmp             x5, x0, asr #1
    //     0xc704f8: b.eq            #0xc70504
    //     0xc704fc: bl              #0xd69c6c
    //     0xc70500: stur            x5, [x0, #7]
    // 0xc70504: stur            x0, [fp, #-0x10]
    // 0xc70508: stp             x2, x0, [SP, #-0x10]!
    // 0xc7050c: r0 = ~/()
    //     0xc7050c: bl              #0x9e69d8  ; [dart:core] _IntegerImplementation::~/
    // 0xc70510: add             SP, SP, #0x10
    // 0xc70514: r1 = LoadInt32Instr(r0)
    //     0xc70514: sbfx            x1, x0, #1, #0x1f
    //     0xc70518: tbz             w0, #0, #0xc70520
    //     0xc7051c: ldur            x1, [x0, #7]
    // 0xc70520: ldur            x0, [fp, #-0x18]
    // 0xc70524: cmp             x1, x0
    // 0xc70528: b.eq            #0xc70538
    // 0xc7052c: add             x1, x0, #1
    // 0xc70530: mov             x6, x1
    // 0xc70534: b               #0xc7053c
    // 0xc70538: mov             x6, x0
    // 0xc7053c: ldur            x0, [fp, #-8]
    // 0xc70540: ldur            d0, [fp, #-0x78]
    // 0xc70544: ldur            d2, [fp, #-0x68]
    // 0xc70548: ldur            d1, [fp, #-0x70]
    // 0xc7054c: ldur            x1, [fp, #-0x20]
    // 0xc70550: ldur            d4, [fp, #-0x50]
    // 0xc70554: ldur            d3, [fp, #-0x60]
    // 0xc70558: stur            x6, [fp, #-0x18]
    // 0xc7055c: r16 = 112
    //     0xc7055c: mov             x16, #0x70
    // 0xc70560: stp             x16, NULL, [SP, #-0x10]!
    // 0xc70564: r0 = ByteData()
    //     0xc70564: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xc70568: add             SP, SP, #0x10
    // 0xc7056c: mov             x2, x0
    // 0xc70570: ldur            x6, [fp, #-0x18]
    // 0xc70574: stur            x2, [fp, #-0x38]
    // 0xc70578: r0 = BoxInt64Instr(r6)
    //     0xc70578: sbfiz           x0, x6, #1, #0x1f
    //     0xc7057c: cmp             x6, x0, asr #1
    //     0xc70580: b.eq            #0xc7058c
    //     0xc70584: bl              #0xd69bb8
    //     0xc70588: stur            x6, [x0, #7]
    // 0xc7058c: ldur            x1, [fp, #-8]
    // 0xc70590: r3 = LoadClassIdInstr(r1)
    //     0xc70590: ldur            x3, [x1, #-1]
    //     0xc70594: ubfx            x3, x3, #0xc, #0x14
    // 0xc70598: stp             x0, x1, [SP, #-0x10]!
    // 0xc7059c: mov             x0, x3
    // 0xc705a0: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc705a0: sub             lr, x0, #0xd83
    //     0xc705a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc705a8: blr             lr
    // 0xc705ac: add             SP, SP, #0x10
    // 0xc705b0: mov             x2, x0
    // 0xc705b4: ldur            x6, [fp, #-0x18]
    // 0xc705b8: stur            x2, [fp, #-0x40]
    // 0xc705bc: add             x3, x6, #1
    // 0xc705c0: r0 = BoxInt64Instr(r3)
    //     0xc705c0: sbfiz           x0, x3, #1, #0x1f
    //     0xc705c4: cmp             x3, x0, asr #1
    //     0xc705c8: b.eq            #0xc705d4
    //     0xc705cc: bl              #0xd69bb8
    //     0xc705d0: stur            x3, [x0, #7]
    // 0xc705d4: ldur            x1, [fp, #-8]
    // 0xc705d8: r3 = LoadClassIdInstr(r1)
    //     0xc705d8: ldur            x3, [x1, #-1]
    //     0xc705dc: ubfx            x3, x3, #0xc, #0x14
    // 0xc705e0: stp             x0, x1, [SP, #-0x10]!
    // 0xc705e4: mov             x0, x3
    // 0xc705e8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xc705e8: sub             lr, x0, #0xd83
    //     0xc705ec: ldr             lr, [x21, lr, lsl #3]
    //     0xc705f0: blr             lr
    // 0xc705f4: add             SP, SP, #0x10
    // 0xc705f8: stur            x0, [fp, #-0x48]
    // 0xc705fc: ldur            x16, [fp, #-0x10]
    // 0xc70600: ldur            lr, [fp, #-0x30]
    // 0xc70604: stp             lr, x16, [SP, #-0x10]!
    // 0xc70608: r0 = %()
    //     0xc70608: bl              #0x8dd970  ; [dart:core] _IntegerImplementation::%
    // 0xc7060c: add             SP, SP, #0x10
    // 0xc70610: LoadField: d0 = r0->field_7
    //     0xc70610: ldur            d0, [x0, #7]
    // 0xc70614: ldur            d1, [fp, #-0x78]
    // 0xc70618: fdiv            d2, d0, d1
    // 0xc7061c: r0 = inline_Allocate_Double()
    //     0xc7061c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc70620: add             x0, x0, #0x10
    //     0xc70624: cmp             x1, x0
    //     0xc70628: b.ls            #0xc707c4
    //     0xc7062c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc70630: sub             x0, x0, #0xf
    //     0xc70634: mov             x1, #0xd108
    //     0xc70638: movk            x1, #3, lsl #16
    //     0xc7063c: stur            x1, [x0, #-1]
    // 0xc70640: StoreField: r0->field_7 = d2
    //     0xc70640: stur            d2, [x0, #7]
    // 0xc70644: ldur            x16, [fp, #-0x40]
    // 0xc70648: ldur            lr, [fp, #-0x48]
    // 0xc7064c: stp             lr, x16, [SP, #-0x10]!
    // 0xc70650: SaveReg r0
    //     0xc70650: str             x0, [SP, #-8]!
    // 0xc70654: r0 = lerp()
    //     0xc70654: bl              #0x5b4cf0  ; [dart:ui] Color::lerp
    // 0xc70658: add             SP, SP, #0x18
    // 0xc7065c: cmp             w0, NULL
    // 0xc70660: b.eq            #0xc707d4
    // 0xc70664: LoadField: r1 = r0->field_7
    //     0xc70664: ldur            x1, [x0, #7]
    // 0xc70668: eor             x0, x1, #0xff000000
    // 0xc7066c: ldur            x1, [fp, #-0x38]
    // 0xc70670: LoadField: r2 = r1->field_17
    //     0xc70670: ldur            w2, [x1, #0x17]
    // 0xc70674: DecompressPointer r2
    //     0xc70674: add             x2, x2, HEAP, lsl #32
    // 0xc70678: sxtw            x0, w0
    // 0xc7067c: LoadField: r3 = r2->field_7
    //     0xc7067c: ldur            x3, [x2, #7]
    // 0xc70680: str             w0, [x3, #4]
    // 0xc70684: ldur            d0, [fp, #-0x70]
    // 0xc70688: ldur            d1, [fp, #-0x50]
    // 0xc7068c: fmul            d2, d0, d1
    // 0xc70690: ldur            d1, [fp, #-0x68]
    // 0xc70694: fadd            d3, d1, d2
    // 0xc70698: d2 = 1.000000
    //     0xc70698: fmov            d2, #1.00000000
    // 0xc7069c: fsub            d4, d3, d2
    // 0xc706a0: fadd            d3, d4, d2
    // 0xc706a4: r0 = inline_Allocate_Double()
    //     0xc706a4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xc706a8: add             x0, x0, #0x10
    //     0xc706ac: cmp             x2, x0
    //     0xc706b0: b.ls            #0xc707d8
    //     0xc706b4: str             x0, [THR, #0x60]  ; THR::top
    //     0xc706b8: sub             x0, x0, #0xf
    //     0xc706bc: mov             x2, #0xd108
    //     0xc706c0: movk            x2, #3, lsl #16
    //     0xc706c4: stur            x2, [x0, #-1]
    // 0xc706c8: StoreField: r0->field_7 = d4
    //     0xc706c8: stur            d4, [x0, #7]
    // 0xc706cc: r2 = inline_Allocate_Double()
    //     0xc706cc: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xc706d0: add             x2, x2, #0x10
    //     0xc706d4: cmp             x3, x2
    //     0xc706d8: b.ls            #0xc70800
    //     0xc706dc: str             x2, [THR, #0x60]  ; THR::top
    //     0xc706e0: sub             x2, x2, #0xf
    //     0xc706e4: mov             x3, #0xd108
    //     0xc706e8: movk            x3, #3, lsl #16
    //     0xc706ec: stur            x3, [x2, #-1]
    // 0xc706f0: StoreField: r2->field_7 = d3
    //     0xc706f0: stur            d3, [x2, #7]
    // 0xc706f4: ldr             x16, [fp, #0x20]
    // 0xc706f8: stp             x0, x16, [SP, #-0x10]!
    // 0xc706fc: ldur            x16, [fp, #-0x28]
    // 0xc70700: stp             x2, x16, [SP, #-0x10]!
    // 0xc70704: ldur            d3, [fp, #-0x60]
    // 0xc70708: SaveReg d3
    //     0xc70708: str             d3, [SP, #-8]!
    // 0xc7070c: stp             x1, NULL, [SP, #-0x10]!
    // 0xc70710: r0 = _drawRect()
    //     0xc70710: bl              #0x65e768  ; [dart:ui] Canvas::_drawRect
    // 0xc70714: add             SP, SP, #0x38
    // 0xc70718: ldur            x1, [fp, #-0x20]
    // 0xc7071c: add             x5, x1, #1
    // 0xc70720: ldur            x6, [fp, #-0x18]
    // 0xc70724: ldur            d1, [fp, #-0x58]
    // 0xc70728: ldur            d2, [fp, #-0x78]
    // 0xc7072c: ldur            d4, [fp, #-0x68]
    // 0xc70730: ldur            d3, [fp, #-0x70]
    // 0xc70734: ldur            d6, [fp, #-0x60]
    // 0xc70738: ldur            x2, [fp, #-0x30]
    // 0xc7073c: ldur            x3, [fp, #-0x28]
    // 0xc70740: b               #0xc704c4
    // 0xc70744: r0 = Null
    //     0xc70744: mov             x0, NULL
    // 0xc70748: LeaveFrame
    //     0xc70748: mov             SP, fp
    //     0xc7074c: ldp             fp, lr, [SP], #0x10
    // 0xc70750: ret
    //     0xc70750: ret             
    // 0xc70754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc70754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc70758: b               #0xc70368
    // 0xc7075c: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc7075c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc70760: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc70760: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc70764: stp             q3, q4, [SP, #-0x20]!
    // 0xc70768: stp             q1, q2, [SP, #-0x20]!
    // 0xc7076c: SaveReg d0
    //     0xc7076c: str             q0, [SP, #-0x10]!
    // 0xc70770: SaveReg r0
    //     0xc70770: str             x0, [SP, #-8]!
    // 0xc70774: r0 = AllocateDouble()
    //     0xc70774: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc70778: mov             x2, x0
    // 0xc7077c: RestoreReg r0
    //     0xc7077c: ldr             x0, [SP], #8
    // 0xc70780: RestoreReg d0
    //     0xc70780: ldr             q0, [SP], #0x10
    // 0xc70784: ldp             q1, q2, [SP], #0x20
    // 0xc70788: ldp             q3, q4, [SP], #0x20
    // 0xc7078c: b               #0xc7047c
    // 0xc70790: stp             q5, q6, [SP, #-0x20]!
    // 0xc70794: stp             q3, q4, [SP, #-0x20]!
    // 0xc70798: stp             q1, q2, [SP, #-0x20]!
    // 0xc7079c: SaveReg r2
    //     0xc7079c: str             x2, [SP, #-8]!
    // 0xc707a0: r0 = AllocateDouble()
    //     0xc707a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc707a4: mov             x3, x0
    // 0xc707a8: RestoreReg r2
    //     0xc707a8: ldr             x2, [SP], #8
    // 0xc707ac: ldp             q1, q2, [SP], #0x20
    // 0xc707b0: ldp             q3, q4, [SP], #0x20
    // 0xc707b4: ldp             q5, q6, [SP], #0x20
    // 0xc707b8: b               #0xc704b4
    // 0xc707bc: r0 = StackOverflowSharedWithFPURegs()
    //     0xc707bc: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc707c0: b               #0xc704dc
    // 0xc707c4: stp             q1, q2, [SP, #-0x20]!
    // 0xc707c8: r0 = AllocateDouble()
    //     0xc707c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc707cc: ldp             q1, q2, [SP], #0x20
    // 0xc707d0: b               #0xc70640
    // 0xc707d4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc707d4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc707d8: stp             q3, q4, [SP, #-0x20]!
    // 0xc707dc: stp             q1, q2, [SP, #-0x20]!
    // 0xc707e0: SaveReg d0
    //     0xc707e0: str             q0, [SP, #-0x10]!
    // 0xc707e4: SaveReg r1
    //     0xc707e4: str             x1, [SP, #-8]!
    // 0xc707e8: r0 = AllocateDouble()
    //     0xc707e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc707ec: RestoreReg r1
    //     0xc707ec: ldr             x1, [SP], #8
    // 0xc707f0: RestoreReg d0
    //     0xc707f0: ldr             q0, [SP], #0x10
    // 0xc707f4: ldp             q1, q2, [SP], #0x20
    // 0xc707f8: ldp             q3, q4, [SP], #0x20
    // 0xc707fc: b               #0xc706c8
    // 0xc70800: stp             q2, q3, [SP, #-0x20]!
    // 0xc70804: stp             q0, q1, [SP, #-0x20]!
    // 0xc70808: stp             x0, x1, [SP, #-0x10]!
    // 0xc7080c: r0 = AllocateDouble()
    //     0xc7080c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc70810: mov             x2, x0
    // 0xc70814: ldp             x0, x1, [SP], #0x10
    // 0xc70818: ldp             q0, q1, [SP], #0x20
    // 0xc7081c: ldp             q2, q3, [SP], #0x20
    // 0xc70820: b               #0xc706f0
  }
}

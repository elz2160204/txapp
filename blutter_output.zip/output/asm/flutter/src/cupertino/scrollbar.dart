// lib: , url: package:flutter/src/cupertino/scrollbar.dart

// class id: 1049102, size: 0x8
class :: {
}

// class id: 3352, size: 0x54, field offset: 0x48
class _CupertinoScrollbarState extends RawScrollbarState<CupertinoScrollbar> {

  late AnimationController _thicknessAnimationController; // offset: 0x48

  _ initState(/* No info */) {
    // ** addr: 0x9d8a64, size: 0xc8
    // 0x9d8a64: EnterFrame
    //     0x9d8a64: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8a68: mov             fp, SP
    // 0x9d8a6c: AllocStack(0x10)
    //     0x9d8a6c: sub             SP, SP, #0x10
    // 0x9d8a70: CheckStackOverflow
    //     0x9d8a70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8a74: cmp             SP, x16
    //     0x9d8a78: b.ls            #0x9d8b24
    // 0x9d8a7c: r1 = 1
    //     0x9d8a7c: mov             x1, #1
    // 0x9d8a80: r0 = AllocateContext()
    //     0x9d8a80: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d8a84: mov             x1, x0
    // 0x9d8a88: ldr             x0, [fp, #0x10]
    // 0x9d8a8c: stur            x1, [fp, #-8]
    // 0x9d8a90: StoreField: r1->field_f = r0
    //     0x9d8a90: stur            w0, [x1, #0xf]
    // 0x9d8a94: SaveReg r0
    //     0x9d8a94: str             x0, [SP, #-8]!
    // 0x9d8a98: r0 = initState()
    //     0x9d8a98: bl              #0x9d8cb0  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::initState
    // 0x9d8a9c: add             SP, SP, #8
    // 0x9d8aa0: r1 = <double>
    //     0x9d8aa0: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d8aa4: r0 = AnimationController()
    //     0x9d8aa4: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d8aa8: stur            x0, [fp, #-0x10]
    // 0x9d8aac: ldr             x16, [fp, #0x10]
    // 0x9d8ab0: stp             x16, x0, [SP, #-0x10]!
    // 0x9d8ab4: r16 = Instance_Duration
    //     0x9d8ab4: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x9d8ab8: ldr             x16, [x16, #0x9f0]
    // 0x9d8abc: SaveReg r16
    //     0x9d8abc: str             x16, [SP, #-8]!
    // 0x9d8ac0: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d8ac0: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d8ac4: ldr             x4, [x4, #0xa0]
    // 0x9d8ac8: r0 = AnimationController()
    //     0x9d8ac8: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d8acc: add             SP, SP, #0x18
    // 0x9d8ad0: ldur            x0, [fp, #-0x10]
    // 0x9d8ad4: ldr             x1, [fp, #0x10]
    // 0x9d8ad8: StoreField: r1->field_47 = r0
    //     0x9d8ad8: stur            w0, [x1, #0x47]
    //     0x9d8adc: ldurb           w16, [x1, #-1]
    //     0x9d8ae0: ldurb           w17, [x0, #-1]
    //     0x9d8ae4: and             x16, x17, x16, lsr #2
    //     0x9d8ae8: tst             x16, HEAP, lsr #32
    //     0x9d8aec: b.eq            #0x9d8af4
    //     0x9d8af0: bl              #0xd6826c
    // 0x9d8af4: ldur            x2, [fp, #-8]
    // 0x9d8af8: r1 = Function '<anonymous closure>':.
    //     0x9d8af8: add             x1, PP, #0x51, lsl #12  ; [pp+0x51098] AnonymousClosure: (0x9d8b50), in [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::initState (0x9d8a64)
    //     0x9d8afc: ldr             x1, [x1, #0x98]
    // 0x9d8b00: r0 = AllocateClosure()
    //     0x9d8b00: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d8b04: ldur            x16, [fp, #-0x10]
    // 0x9d8b08: stp             x0, x16, [SP, #-0x10]!
    // 0x9d8b0c: r0 = addActionListener()
    //     0x9d8b0c: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x9d8b10: add             SP, SP, #0x10
    // 0x9d8b14: r0 = Null
    //     0x9d8b14: mov             x0, NULL
    // 0x9d8b18: LeaveFrame
    //     0x9d8b18: mov             SP, fp
    //     0x9d8b1c: ldp             fp, lr, [SP], #0x10
    // 0x9d8b20: ret
    //     0x9d8b20: ret             
    // 0x9d8b24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8b24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8b28: b               #0x9d8a7c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x9d8b50, size: 0x4c
    // 0x9d8b50: EnterFrame
    //     0x9d8b50: stp             fp, lr, [SP, #-0x10]!
    //     0x9d8b54: mov             fp, SP
    // 0x9d8b58: ldr             x0, [fp, #0x10]
    // 0x9d8b5c: LoadField: r1 = r0->field_17
    //     0x9d8b5c: ldur            w1, [x0, #0x17]
    // 0x9d8b60: DecompressPointer r1
    //     0x9d8b60: add             x1, x1, HEAP, lsl #32
    // 0x9d8b64: CheckStackOverflow
    //     0x9d8b64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d8b68: cmp             SP, x16
    //     0x9d8b6c: b.ls            #0x9d8b94
    // 0x9d8b70: LoadField: r0 = r1->field_f
    //     0x9d8b70: ldur            w0, [x1, #0xf]
    // 0x9d8b74: DecompressPointer r0
    //     0x9d8b74: add             x0, x0, HEAP, lsl #32
    // 0x9d8b78: SaveReg r0
    //     0x9d8b78: str             x0, [SP, #-8]!
    // 0x9d8b7c: r0 = updateScrollbarPainter()
    //     0x9d8b7c: bl              #0xcd26ac  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::updateScrollbarPainter
    // 0x9d8b80: add             SP, SP, #8
    // 0x9d8b84: r0 = Null
    //     0x9d8b84: mov             x0, NULL
    // 0x9d8b88: LeaveFrame
    //     0x9d8b88: mov             SP, fp
    //     0x9d8b8c: ldp             fp, lr, [SP], #0x10
    // 0x9d8b90: ret
    //     0x9d8b90: ret             
    // 0x9d8b94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d8b94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d8b98: b               #0x9d8b70
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a768, size: 0x18
    // 0xa4a768: r4 = 7
    //     0xa4a768: mov             x4, #7
    // 0xa4a76c: r1 = Function 'dispose':.
    //     0xa4a76c: add             x17, PP, #0x51, lsl #12  ; [pp+0x51088] AnonymousClosure: (0xa4a780), in [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::dispose (0xa50738)
    //     0xa4a770: ldr             x1, [x17, #0x88]
    // 0xa4a774: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a774: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a778: LoadField: r0 = r24->field_17
    //     0xa4a778: ldur            x0, [x24, #0x17]
    // 0xa4a77c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a780, size: 0x48
    // 0xa4a780: EnterFrame
    //     0xa4a780: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a784: mov             fp, SP
    // 0xa4a788: ldr             x0, [fp, #0x10]
    // 0xa4a78c: LoadField: r1 = r0->field_17
    //     0xa4a78c: ldur            w1, [x0, #0x17]
    // 0xa4a790: DecompressPointer r1
    //     0xa4a790: add             x1, x1, HEAP, lsl #32
    // 0xa4a794: CheckStackOverflow
    //     0xa4a794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a798: cmp             SP, x16
    //     0xa4a79c: b.ls            #0xa4a7c0
    // 0xa4a7a0: LoadField: r0 = r1->field_f
    //     0xa4a7a0: ldur            w0, [x1, #0xf]
    // 0xa4a7a4: DecompressPointer r0
    //     0xa4a7a4: add             x0, x0, HEAP, lsl #32
    // 0xa4a7a8: SaveReg r0
    //     0xa4a7a8: str             x0, [SP, #-8]!
    // 0xa4a7ac: r0 = dispose()
    //     0xa4a7ac: bl              #0xa50738  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::dispose
    // 0xa4a7b0: add             SP, SP, #8
    // 0xa4a7b4: LeaveFrame
    //     0xa4a7b4: mov             SP, fp
    //     0xa4a7b8: ldp             fp, lr, [SP], #0x10
    // 0xa4a7bc: ret
    //     0xa4a7bc: ret             
    // 0xa4a7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a7c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a7c4: b               #0xa4a7a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50738, size: 0x6c
    // 0xa50738: EnterFrame
    //     0xa50738: stp             fp, lr, [SP, #-0x10]!
    //     0xa5073c: mov             fp, SP
    // 0xa50740: CheckStackOverflow
    //     0xa50740: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50744: cmp             SP, x16
    //     0xa50748: b.ls            #0xa50790
    // 0xa5074c: ldr             x0, [fp, #0x10]
    // 0xa50750: LoadField: r1 = r0->field_47
    //     0xa50750: ldur            w1, [x0, #0x47]
    // 0xa50754: DecompressPointer r1
    //     0xa50754: add             x1, x1, HEAP, lsl #32
    // 0xa50758: r16 = Sentinel
    //     0xa50758: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa5075c: cmp             w1, w16
    // 0xa50760: b.eq            #0xa50798
    // 0xa50764: SaveReg r1
    //     0xa50764: str             x1, [SP, #-8]!
    // 0xa50768: r0 = dispose()
    //     0xa50768: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa5076c: add             SP, SP, #8
    // 0xa50770: ldr             x16, [fp, #0x10]
    // 0xa50774: SaveReg r16
    //     0xa50774: str             x16, [SP, #-8]!
    // 0xa50778: r0 = dispose()
    //     0xa50778: bl              #0xa50810  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::dispose
    // 0xa5077c: add             SP, SP, #8
    // 0xa50780: r0 = Null
    //     0xa50780: mov             x0, NULL
    // 0xa50784: LeaveFrame
    //     0xa50784: mov             SP, fp
    //     0xa50788: ldp             fp, lr, [SP], #0x10
    // 0xa5078c: ret
    //     0xa5078c: ret             
    // 0xa50790: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50790: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50794: b               #0xa5074c
    // 0xa50798: r9 = _thicknessAnimationController
    //     0xa50798: add             x9, PP, #0x51, lsl #12  ; [pp+0x51090] Field <_CupertinoScrollbarState@610305104._thicknessAnimationController@610305104>: late (offset: 0x48)
    //     0xa5079c: ldr             x9, [x9, #0x90]
    // 0xa507a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa507a0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  dynamic handleThumbPress(dynamic) {
    // ** addr: 0xccb838, size: 0x18
    // 0xccb838: r4 = 7
    //     0xccb838: mov             x4, #7
    // 0xccb83c: r1 = Function 'handleThumbPress':.
    //     0xccb83c: add             x17, PP, #0x53, lsl #12  ; [pp+0x532e0] AnonymousClosure: (0xccb850), in [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::handleThumbPress (0xccb898)
    //     0xccb840: ldr             x1, [x17, #0x2e0]
    // 0xccb844: r24 = BuildNonGenericMethodExtractorStub
    //     0xccb844: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xccb848: LoadField: r0 = r24->field_17
    //     0xccb848: ldur            x0, [x24, #0x17]
    // 0xccb84c: br              x0
  }
  [closure] void handleThumbPress(dynamic) {
    // ** addr: 0xccb850, size: 0x48
    // 0xccb850: EnterFrame
    //     0xccb850: stp             fp, lr, [SP, #-0x10]!
    //     0xccb854: mov             fp, SP
    // 0xccb858: ldr             x0, [fp, #0x10]
    // 0xccb85c: LoadField: r1 = r0->field_17
    //     0xccb85c: ldur            w1, [x0, #0x17]
    // 0xccb860: DecompressPointer r1
    //     0xccb860: add             x1, x1, HEAP, lsl #32
    // 0xccb864: CheckStackOverflow
    //     0xccb864: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccb868: cmp             SP, x16
    //     0xccb86c: b.ls            #0xccb890
    // 0xccb870: LoadField: r0 = r1->field_f
    //     0xccb870: ldur            w0, [x1, #0xf]
    // 0xccb874: DecompressPointer r0
    //     0xccb874: add             x0, x0, HEAP, lsl #32
    // 0xccb878: SaveReg r0
    //     0xccb878: str             x0, [SP, #-8]!
    // 0xccb87c: r0 = handleThumbPress()
    //     0xccb87c: bl              #0xccb898  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::handleThumbPress
    // 0xccb880: add             SP, SP, #8
    // 0xccb884: LeaveFrame
    //     0xccb884: mov             SP, fp
    //     0xccb888: ldp             fp, lr, [SP], #0x10
    // 0xccb88c: ret
    //     0xccb88c: ret             
    // 0xccb890: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccb890: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccb894: b               #0xccb870
  }
  _ handleThumbPress(/* No info */) {
    // ** addr: 0xccb898, size: 0xcc
    // 0xccb898: EnterFrame
    //     0xccb898: stp             fp, lr, [SP, #-0x10]!
    //     0xccb89c: mov             fp, SP
    // 0xccb8a0: AllocStack(0x8)
    //     0xccb8a0: sub             SP, SP, #8
    // 0xccb8a4: CheckStackOverflow
    //     0xccb8a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccb8a8: cmp             SP, x16
    //     0xccb8ac: b.ls            #0xccb950
    // 0xccb8b0: ldr             x16, [fp, #0x10]
    // 0xccb8b4: SaveReg r16
    //     0xccb8b4: str             x16, [SP, #-8]!
    // 0xccb8b8: r0 = getScrollbarDirection()
    //     0xccb8b8: bl              #0x8424d4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::getScrollbarDirection
    // 0xccb8bc: add             SP, SP, #8
    // 0xccb8c0: cmp             w0, NULL
    // 0xccb8c4: b.ne            #0xccb8d8
    // 0xccb8c8: r0 = Null
    //     0xccb8c8: mov             x0, NULL
    // 0xccb8cc: LeaveFrame
    //     0xccb8cc: mov             SP, fp
    //     0xccb8d0: ldp             fp, lr, [SP], #0x10
    // 0xccb8d4: ret
    //     0xccb8d4: ret             
    // 0xccb8d8: ldr             x0, [fp, #0x10]
    // 0xccb8dc: SaveReg r0
    //     0xccb8dc: str             x0, [SP, #-8]!
    // 0xccb8e0: r0 = handleThumbPress()
    //     0xccb8e0: bl              #0xccb964  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPress
    // 0xccb8e4: add             SP, SP, #8
    // 0xccb8e8: ldr             x0, [fp, #0x10]
    // 0xccb8ec: LoadField: r1 = r0->field_47
    //     0xccb8ec: ldur            w1, [x0, #0x47]
    // 0xccb8f0: DecompressPointer r1
    //     0xccb8f0: add             x1, x1, HEAP, lsl #32
    // 0xccb8f4: r16 = Sentinel
    //     0xccb8f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccb8f8: cmp             w1, w16
    // 0xccb8fc: b.eq            #0xccb958
    // 0xccb900: SaveReg r1
    //     0xccb900: str             x1, [SP, #-8]!
    // 0xccb904: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xccb904: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xccb908: r0 = forward()
    //     0xccb908: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0xccb90c: add             SP, SP, #8
    // 0xccb910: r1 = Function '<anonymous closure>':.
    //     0xccb910: add             x1, PP, #0x53, lsl #12  ; [pp+0x532e8] AnonymousClosure: (0xccba20), in [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::handleThumbPress (0xccb898)
    //     0xccb914: ldr             x1, [x1, #0x2e8]
    // 0xccb918: r2 = Null
    //     0xccb918: mov             x2, NULL
    // 0xccb91c: stur            x0, [fp, #-8]
    // 0xccb920: r0 = AllocateClosure()
    //     0xccb920: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xccb924: r16 = <void?>
    //     0xccb924: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xccb928: ldur            lr, [fp, #-8]
    // 0xccb92c: stp             lr, x16, [SP, #-0x10]!
    // 0xccb930: SaveReg r0
    //     0xccb930: str             x0, [SP, #-8]!
    // 0xccb934: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xccb934: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xccb938: r0 = then()
    //     0xccb938: bl              #0xd0444c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0xccb93c: add             SP, SP, #0x18
    // 0xccb940: r0 = Null
    //     0xccb940: mov             x0, NULL
    // 0xccb944: LeaveFrame
    //     0xccb944: mov             SP, fp
    //     0xccb948: ldp             fp, lr, [SP], #0x10
    // 0xccb94c: ret
    //     0xccb94c: ret             
    // 0xccb950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccb950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccb954: b               #0xccb8b0
    // 0xccb958: r9 = _thicknessAnimationController
    //     0xccb958: add             x9, PP, #0x51, lsl #12  ; [pp+0x51090] Field <_CupertinoScrollbarState@610305104._thicknessAnimationController@610305104>: late (offset: 0x48)
    //     0xccb95c: ldr             x9, [x9, #0x90]
    // 0xccb960: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xccb960: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, void) {
    // ** addr: 0xccba20, size: 0x2c
    // 0xccba20: EnterFrame
    //     0xccba20: stp             fp, lr, [SP, #-0x10]!
    //     0xccba24: mov             fp, SP
    // 0xccba28: CheckStackOverflow
    //     0xccba28: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccba2c: cmp             SP, x16
    //     0xccba30: b.ls            #0xccba44
    // 0xccba34: r0 = mediumImpact()
    //     0xccba34: bl              #0xccba4c  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::mediumImpact
    // 0xccba38: LeaveFrame
    //     0xccba38: mov             SP, fp
    //     0xccba3c: ldp             fp, lr, [SP], #0x10
    // 0xccba40: ret
    //     0xccba40: ret             
    // 0xccba44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccba44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccba48: b               #0xccba34
  }
  _ handleThumbPressEnd(/* No info */) {
    // ** addr: 0xccd414, size: 0x1fc
    // 0xccd414: EnterFrame
    //     0xccd414: stp             fp, lr, [SP, #-0x10]!
    //     0xccd418: mov             fp, SP
    // 0xccd41c: AllocStack(0x8)
    //     0xccd41c: sub             SP, SP, #8
    // 0xccd420: CheckStackOverflow
    //     0xccd420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccd424: cmp             SP, x16
    //     0xccd428: b.ls            #0xccd5fc
    // 0xccd42c: ldr             x16, [fp, #0x20]
    // 0xccd430: SaveReg r16
    //     0xccd430: str             x16, [SP, #-8]!
    // 0xccd434: r0 = getScrollbarDirection()
    //     0xccd434: bl              #0x8424d4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::getScrollbarDirection
    // 0xccd438: add             SP, SP, #8
    // 0xccd43c: stur            x0, [fp, #-8]
    // 0xccd440: cmp             w0, NULL
    // 0xccd444: b.ne            #0xccd458
    // 0xccd448: r0 = Null
    //     0xccd448: mov             x0, NULL
    // 0xccd44c: LeaveFrame
    //     0xccd44c: mov             SP, fp
    //     0xccd450: ldp             fp, lr, [SP], #0x10
    // 0xccd454: ret
    //     0xccd454: ret             
    // 0xccd458: ldr             x1, [fp, #0x20]
    // 0xccd45c: LoadField: r2 = r1->field_47
    //     0xccd45c: ldur            w2, [x1, #0x47]
    // 0xccd460: DecompressPointer r2
    //     0xccd460: add             x2, x2, HEAP, lsl #32
    // 0xccd464: r16 = Sentinel
    //     0xccd464: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccd468: cmp             w2, w16
    // 0xccd46c: b.eq            #0xccd604
    // 0xccd470: SaveReg r2
    //     0xccd470: str             x2, [SP, #-8]!
    // 0xccd474: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xccd474: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xccd478: r0 = reverse()
    //     0xccd478: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0xccd47c: add             SP, SP, #8
    // 0xccd480: ldr             x16, [fp, #0x20]
    // 0xccd484: ldr             lr, [fp, #0x18]
    // 0xccd488: stp             lr, x16, [SP, #-0x10]!
    // 0xccd48c: ldr             x16, [fp, #0x10]
    // 0xccd490: SaveReg r16
    //     0xccd490: str             x16, [SP, #-8]!
    // 0xccd494: r0 = handleThumbPressEnd()
    //     0xccd494: bl              #0xccd6b4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressEnd
    // 0xccd498: add             SP, SP, #0x18
    // 0xccd49c: ldur            x0, [fp, #-8]
    // 0xccd4a0: LoadField: r1 = r0->field_7
    //     0xccd4a0: ldur            x1, [x0, #7]
    // 0xccd4a4: cmp             x1, #0
    // 0xccd4a8: b.gt            #0xccd550
    // 0xccd4ac: ldr             x0, [fp, #0x10]
    // 0xccd4b0: d0 = 0.000000
    //     0xccd4b0: eor             v0.16b, v0.16b, v0.16b
    // 0xccd4b4: LoadField: r1 = r0->field_7
    //     0xccd4b4: ldur            w1, [x0, #7]
    // 0xccd4b8: DecompressPointer r1
    //     0xccd4b8: add             x1, x1, HEAP, lsl #32
    // 0xccd4bc: LoadField: d1 = r1->field_7
    //     0xccd4bc: ldur            d1, [x1, #7]
    // 0xccd4c0: fcmp            d1, d0
    // 0xccd4c4: b.vs            #0xccd4d4
    // 0xccd4c8: b.ne            #0xccd4d4
    // 0xccd4cc: d2 = 0.000000
    //     0xccd4cc: eor             v2.16b, v2.16b, v2.16b
    // 0xccd4d0: b               #0xccd4ec
    // 0xccd4d4: fcmp            d1, d0
    // 0xccd4d8: b.vs            #0xccd4e8
    // 0xccd4dc: b.ge            #0xccd4e8
    // 0xccd4e0: fneg            d2, d1
    // 0xccd4e4: mov             v1.16b, v2.16b
    // 0xccd4e8: mov             v2.16b, v1.16b
    // 0xccd4ec: d1 = 10.000000
    //     0xccd4ec: fmov            d1, #10.00000000
    // 0xccd4f0: fcmp            d2, d1
    // 0xccd4f4: b.vs            #0xccd5ec
    // 0xccd4f8: b.ge            #0xccd5ec
    // 0xccd4fc: ldr             x1, [fp, #0x20]
    // 0xccd500: ldr             x2, [fp, #0x18]
    // 0xccd504: LoadField: d1 = r2->field_7
    //     0xccd504: ldur            d1, [x2, #7]
    // 0xccd508: LoadField: d2 = r1->field_4b
    //     0xccd508: ldur            d2, [x1, #0x4b]
    // 0xccd50c: fsub            d3, d1, d2
    // 0xccd510: fcmp            d3, d0
    // 0xccd514: b.vs            #0xccd524
    // 0xccd518: b.ne            #0xccd524
    // 0xccd51c: d1 = 0.000000
    //     0xccd51c: eor             v1.16b, v1.16b, v1.16b
    // 0xccd520: b               #0xccd53c
    // 0xccd524: fcmp            d3, d0
    // 0xccd528: b.vs            #0xccd538
    // 0xccd52c: b.ge            #0xccd538
    // 0xccd530: fneg            d1, d3
    // 0xccd534: b               #0xccd53c
    // 0xccd538: mov             v1.16b, v3.16b
    // 0xccd53c: fcmp            d1, d0
    // 0xccd540: b.vs            #0xccd5ec
    // 0xccd544: b.le            #0xccd5ec
    // 0xccd548: r0 = mediumImpact()
    //     0xccd548: bl              #0xccba4c  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::mediumImpact
    // 0xccd54c: b               #0xccd5ec
    // 0xccd550: ldr             x1, [fp, #0x20]
    // 0xccd554: ldr             x2, [fp, #0x18]
    // 0xccd558: ldr             x0, [fp, #0x10]
    // 0xccd55c: d1 = 10.000000
    //     0xccd55c: fmov            d1, #10.00000000
    // 0xccd560: d0 = 0.000000
    //     0xccd560: eor             v0.16b, v0.16b, v0.16b
    // 0xccd564: LoadField: r3 = r0->field_7
    //     0xccd564: ldur            w3, [x0, #7]
    // 0xccd568: DecompressPointer r3
    //     0xccd568: add             x3, x3, HEAP, lsl #32
    // 0xccd56c: LoadField: d2 = r3->field_f
    //     0xccd56c: ldur            d2, [x3, #0xf]
    // 0xccd570: fcmp            d2, d0
    // 0xccd574: b.vs            #0xccd584
    // 0xccd578: b.ne            #0xccd584
    // 0xccd57c: d2 = 0.000000
    //     0xccd57c: eor             v2.16b, v2.16b, v2.16b
    // 0xccd580: b               #0xccd598
    // 0xccd584: fcmp            d2, d0
    // 0xccd588: b.vs            #0xccd598
    // 0xccd58c: b.ge            #0xccd598
    // 0xccd590: fneg            d3, d2
    // 0xccd594: mov             v2.16b, v3.16b
    // 0xccd598: fcmp            d2, d1
    // 0xccd59c: b.vs            #0xccd5ec
    // 0xccd5a0: b.ge            #0xccd5ec
    // 0xccd5a4: LoadField: d1 = r2->field_f
    //     0xccd5a4: ldur            d1, [x2, #0xf]
    // 0xccd5a8: LoadField: d2 = r1->field_4b
    //     0xccd5a8: ldur            d2, [x1, #0x4b]
    // 0xccd5ac: fsub            d3, d1, d2
    // 0xccd5b0: fcmp            d3, d0
    // 0xccd5b4: b.vs            #0xccd5c4
    // 0xccd5b8: b.ne            #0xccd5c4
    // 0xccd5bc: d1 = 0.000000
    //     0xccd5bc: eor             v1.16b, v1.16b, v1.16b
    // 0xccd5c0: b               #0xccd5dc
    // 0xccd5c4: fcmp            d3, d0
    // 0xccd5c8: b.vs            #0xccd5d8
    // 0xccd5cc: b.ge            #0xccd5d8
    // 0xccd5d0: fneg            d1, d3
    // 0xccd5d4: b               #0xccd5dc
    // 0xccd5d8: mov             v1.16b, v3.16b
    // 0xccd5dc: fcmp            d1, d0
    // 0xccd5e0: b.vs            #0xccd5ec
    // 0xccd5e4: b.le            #0xccd5ec
    // 0xccd5e8: r0 = mediumImpact()
    //     0xccd5e8: bl              #0xccba4c  ; [package:flutter/src/services/haptic_feedback.dart] HapticFeedback::mediumImpact
    // 0xccd5ec: r0 = Null
    //     0xccd5ec: mov             x0, NULL
    // 0xccd5f0: LeaveFrame
    //     0xccd5f0: mov             SP, fp
    //     0xccd5f4: ldp             fp, lr, [SP], #0x10
    // 0xccd5f8: ret
    //     0xccd5f8: ret             
    // 0xccd5fc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccd5fc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccd600: b               #0xccd42c
    // 0xccd604: r9 = _thicknessAnimationController
    //     0xccd604: add             x9, PP, #0x51, lsl #12  ; [pp+0x51090] Field <_CupertinoScrollbarState@610305104._thicknessAnimationController@610305104>: late (offset: 0x48)
    //     0xccd608: ldr             x9, [x9, #0x90]
    // 0xccd60c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xccd60c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ handleThumbPressStart(/* No info */) {
    // ** addr: 0xccd858, size: 0x98
    // 0xccd858: EnterFrame
    //     0xccd858: stp             fp, lr, [SP, #-0x10]!
    //     0xccd85c: mov             fp, SP
    // 0xccd860: CheckStackOverflow
    //     0xccd860: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccd864: cmp             SP, x16
    //     0xccd868: b.ls            #0xccd8e8
    // 0xccd86c: ldr             x16, [fp, #0x18]
    // 0xccd870: ldr             lr, [fp, #0x10]
    // 0xccd874: stp             lr, x16, [SP, #-0x10]!
    // 0xccd878: r0 = handleThumbPressStart()
    //     0xccd878: bl              #0xccd98c  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::handleThumbPressStart
    // 0xccd87c: add             SP, SP, #0x10
    // 0xccd880: ldr             x16, [fp, #0x18]
    // 0xccd884: SaveReg r16
    //     0xccd884: str             x16, [SP, #-8]!
    // 0xccd888: r0 = getScrollbarDirection()
    //     0xccd888: bl              #0x8424d4  ; [package:flutter/src/widgets/scrollbar.dart] RawScrollbarState::getScrollbarDirection
    // 0xccd88c: add             SP, SP, #8
    // 0xccd890: cmp             w0, NULL
    // 0xccd894: b.ne            #0xccd8a8
    // 0xccd898: r0 = Null
    //     0xccd898: mov             x0, NULL
    // 0xccd89c: LeaveFrame
    //     0xccd89c: mov             SP, fp
    //     0xccd8a0: ldp             fp, lr, [SP], #0x10
    // 0xccd8a4: ret
    //     0xccd8a4: ret             
    // 0xccd8a8: LoadField: r1 = r0->field_7
    //     0xccd8a8: ldur            x1, [x0, #7]
    // 0xccd8ac: cmp             x1, #0
    // 0xccd8b0: b.gt            #0xccd8c8
    // 0xccd8b4: ldr             x2, [fp, #0x18]
    // 0xccd8b8: ldr             x1, [fp, #0x10]
    // 0xccd8bc: LoadField: d0 = r1->field_7
    //     0xccd8bc: ldur            d0, [x1, #7]
    // 0xccd8c0: StoreField: r2->field_4b = d0
    //     0xccd8c0: stur            d0, [x2, #0x4b]
    // 0xccd8c4: b               #0xccd8d8
    // 0xccd8c8: ldr             x2, [fp, #0x18]
    // 0xccd8cc: ldr             x1, [fp, #0x10]
    // 0xccd8d0: LoadField: d0 = r1->field_f
    //     0xccd8d0: ldur            d0, [x1, #0xf]
    // 0xccd8d4: StoreField: r2->field_4b = d0
    //     0xccd8d4: stur            d0, [x2, #0x4b]
    // 0xccd8d8: r0 = Null
    //     0xccd8d8: mov             x0, NULL
    // 0xccd8dc: LeaveFrame
    //     0xccd8dc: mov             SP, fp
    //     0xccd8e0: ldp             fp, lr, [SP], #0x10
    // 0xccd8e4: ret
    //     0xccd8e4: ret             
    // 0xccd8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccd8e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccd8ec: b               #0xccd86c
  }
  _ updateScrollbarPainter(/* No info */) {
    // ** addr: 0xcd26ac, size: 0x240
    // 0xcd26ac: EnterFrame
    //     0xcd26ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcd26b0: mov             fp, SP
    // 0xcd26b4: AllocStack(0x8)
    //     0xcd26b4: sub             SP, SP, #8
    // 0xcd26b8: CheckStackOverflow
    //     0xcd26b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd26bc: cmp             SP, x16
    //     0xcd26c0: b.ls            #0xcd28c8
    // 0xcd26c4: ldr             x0, [fp, #0x10]
    // 0xcd26c8: LoadField: r1 = r0->field_43
    //     0xcd26c8: ldur            w1, [x0, #0x43]
    // 0xcd26cc: DecompressPointer r1
    //     0xcd26cc: add             x1, x1, HEAP, lsl #32
    // 0xcd26d0: r16 = Sentinel
    //     0xcd26d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd26d4: cmp             w1, w16
    // 0xcd26d8: b.eq            #0xcd28d0
    // 0xcd26dc: stur            x1, [fp, #-8]
    // 0xcd26e0: LoadField: r2 = r0->field_f
    //     0xcd26e0: ldur            w2, [x0, #0xf]
    // 0xcd26e4: DecompressPointer r2
    //     0xcd26e4: add             x2, x2, HEAP, lsl #32
    // 0xcd26e8: cmp             w2, NULL
    // 0xcd26ec: b.eq            #0xcd28dc
    // 0xcd26f0: r16 = Instance_CupertinoDynamicColor
    //     0xcd26f0: add             x16, PP, #0x51, lsl #12  ; [pp+0x510a0] Obj!CupertinoDynamicColor@b5e7b1
    //     0xcd26f4: ldr             x16, [x16, #0xa0]
    // 0xcd26f8: stp             x2, x16, [SP, #-0x10]!
    // 0xcd26fc: r0 = resolveFrom()
    //     0xcd26fc: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xcd2700: add             SP, SP, #0x10
    // 0xcd2704: ldur            x16, [fp, #-8]
    // 0xcd2708: stp             x0, x16, [SP, #-0x10]!
    // 0xcd270c: r0 = color=()
    //     0xcd270c: bl              #0xcd2dd4  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::color=
    // 0xcd2710: add             SP, SP, #0x10
    // 0xcd2714: ldr             x0, [fp, #0x10]
    // 0xcd2718: LoadField: r1 = r0->field_f
    //     0xcd2718: ldur            w1, [x0, #0xf]
    // 0xcd271c: DecompressPointer r1
    //     0xcd271c: add             x1, x1, HEAP, lsl #32
    // 0xcd2720: cmp             w1, NULL
    // 0xcd2724: b.eq            #0xcd28e0
    // 0xcd2728: SaveReg r1
    //     0xcd2728: str             x1, [SP, #-8]!
    // 0xcd272c: r0 = of()
    //     0xcd272c: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcd2730: add             SP, SP, #8
    // 0xcd2734: ldur            x1, [fp, #-8]
    // 0xcd2738: LoadField: r2 = r1->field_33
    //     0xcd2738: ldur            w2, [x1, #0x33]
    // 0xcd273c: DecompressPointer r2
    //     0xcd273c: add             x2, x2, HEAP, lsl #32
    // 0xcd2740: cmp             w2, w0
    // 0xcd2744: b.ne            #0xcd2750
    // 0xcd2748: mov             x0, x1
    // 0xcd274c: b               #0xcd277c
    // 0xcd2750: StoreField: r1->field_33 = r0
    //     0xcd2750: stur            w0, [x1, #0x33]
    //     0xcd2754: ldurb           w16, [x1, #-1]
    //     0xcd2758: ldurb           w17, [x0, #-1]
    //     0xcd275c: and             x16, x17, x16, lsr #2
    //     0xcd2760: tst             x16, HEAP, lsr #32
    //     0xcd2764: b.eq            #0xcd276c
    //     0xcd2768: bl              #0xd6826c
    // 0xcd276c: SaveReg r1
    //     0xcd276c: str             x1, [SP, #-8]!
    // 0xcd2770: r0 = notifyListeners()
    //     0xcd2770: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcd2774: add             SP, SP, #8
    // 0xcd2778: ldur            x0, [fp, #-8]
    // 0xcd277c: ldr             x16, [fp, #0x10]
    // 0xcd2780: SaveReg r16
    //     0xcd2780: str             x16, [SP, #-8]!
    // 0xcd2784: r0 = _thickness()
    //     0xcd2784: bl              #0xcd2d3c  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::_thickness
    // 0xcd2788: add             SP, SP, #8
    // 0xcd278c: ldur            x0, [fp, #-8]
    // 0xcd2790: LoadField: d1 = r0->field_37
    //     0xcd2790: ldur            d1, [x0, #0x37]
    // 0xcd2794: fcmp            d1, d0
    // 0xcd2798: b.vs            #0xcd27a0
    // 0xcd279c: b.eq            #0xcd27b4
    // 0xcd27a0: StoreField: r0->field_37 = d0
    //     0xcd27a0: stur            d0, [x0, #0x37]
    // 0xcd27a4: SaveReg r0
    //     0xcd27a4: str             x0, [SP, #-8]!
    // 0xcd27a8: r0 = notifyListeners()
    //     0xcd27a8: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcd27ac: add             SP, SP, #8
    // 0xcd27b0: ldur            x0, [fp, #-8]
    // 0xcd27b4: d0 = 3.000000
    //     0xcd27b4: fmov            d0, #3.00000000
    // 0xcd27b8: LoadField: d1 = r0->field_43
    //     0xcd27b8: ldur            d1, [x0, #0x43]
    // 0xcd27bc: fcmp            d1, d0
    // 0xcd27c0: b.vs            #0xcd27c8
    // 0xcd27c4: b.eq            #0xcd27e0
    // 0xcd27c8: StoreField: r0->field_43 = d0
    //     0xcd27c8: stur            d0, [x0, #0x43]
    // 0xcd27cc: SaveReg r0
    //     0xcd27cc: str             x0, [SP, #-8]!
    // 0xcd27d0: r0 = notifyListeners()
    //     0xcd27d0: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcd27d4: add             SP, SP, #8
    // 0xcd27d8: ldur            x0, [fp, #-8]
    // 0xcd27dc: d0 = 3.000000
    //     0xcd27dc: fmov            d0, #3.00000000
    // 0xcd27e0: LoadField: d1 = r0->field_4b
    //     0xcd27e0: ldur            d1, [x0, #0x4b]
    // 0xcd27e4: fcmp            d1, d0
    // 0xcd27e8: b.vs            #0xcd27f0
    // 0xcd27ec: b.eq            #0xcd2804
    // 0xcd27f0: StoreField: r0->field_4b = d0
    //     0xcd27f0: stur            d0, [x0, #0x4b]
    // 0xcd27f4: SaveReg r0
    //     0xcd27f4: str             x0, [SP, #-8]!
    // 0xcd27f8: r0 = notifyListeners()
    //     0xcd27f8: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcd27fc: add             SP, SP, #8
    // 0xcd2800: ldur            x0, [fp, #-8]
    // 0xcd2804: ldr             x1, [fp, #0x10]
    // 0xcd2808: SaveReg r1
    //     0xcd2808: str             x1, [SP, #-8]!
    // 0xcd280c: r0 = _radius()
    //     0xcd280c: bl              #0xcd2c8c  ; [package:flutter/src/cupertino/scrollbar.dart] _CupertinoScrollbarState::_radius
    // 0xcd2810: add             SP, SP, #8
    // 0xcd2814: ldur            x16, [fp, #-8]
    // 0xcd2818: stp             x0, x16, [SP, #-0x10]!
    // 0xcd281c: r0 = radius=()
    //     0xcd281c: bl              #0xcd2bec  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::radius=
    // 0xcd2820: add             SP, SP, #0x10
    // 0xcd2824: ldr             x0, [fp, #0x10]
    // 0xcd2828: LoadField: r1 = r0->field_f
    //     0xcd2828: ldur            w1, [x0, #0xf]
    // 0xcd282c: DecompressPointer r1
    //     0xcd282c: add             x1, x1, HEAP, lsl #32
    // 0xcd2830: cmp             w1, NULL
    // 0xcd2834: b.eq            #0xcd28e4
    // 0xcd2838: SaveReg r1
    //     0xcd2838: str             x1, [SP, #-8]!
    // 0xcd283c: r0 = of()
    //     0xcd283c: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xcd2840: add             SP, SP, #8
    // 0xcd2844: LoadField: r1 = r0->field_23
    //     0xcd2844: ldur            w1, [x0, #0x23]
    // 0xcd2848: DecompressPointer r1
    //     0xcd2848: add             x1, x1, HEAP, lsl #32
    // 0xcd284c: ldur            x16, [fp, #-8]
    // 0xcd2850: stp             x1, x16, [SP, #-0x10]!
    // 0xcd2854: r0 = padding=()
    //     0xcd2854: bl              #0xcd2b60  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::padding=
    // 0xcd2858: add             SP, SP, #0x10
    // 0xcd285c: ldur            x0, [fp, #-8]
    // 0xcd2860: LoadField: d0 = r0->field_5f
    //     0xcd2860: ldur            d0, [x0, #0x5f]
    // 0xcd2864: d1 = 36.000000
    //     0xcd2864: add             x17, PP, #0xc, lsl #12  ; [pp+0xcfa8] IMM: double(36) from 0x4042000000000000
    //     0xcd2868: ldr             d1, [x17, #0xfa8]
    // 0xcd286c: fcmp            d0, d1
    // 0xcd2870: b.vs            #0xcd2878
    // 0xcd2874: b.eq            #0xcd2888
    // 0xcd2878: StoreField: r0->field_5f = d1
    //     0xcd2878: stur            d1, [x0, #0x5f]
    // 0xcd287c: SaveReg r0
    //     0xcd287c: str             x0, [SP, #-8]!
    // 0xcd2880: r0 = notifyListeners()
    //     0xcd2880: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0xcd2884: add             SP, SP, #8
    // 0xcd2888: ldr             x0, [fp, #0x10]
    // 0xcd288c: d0 = 8.000000
    //     0xcd288c: fmov            d0, #8.00000000
    // 0xcd2890: ldur            x16, [fp, #-8]
    // 0xcd2894: SaveReg r16
    //     0xcd2894: str             x16, [SP, #-8]!
    // 0xcd2898: SaveReg d0
    //     0xcd2898: str             d0, [SP, #-8]!
    // 0xcd289c: r0 = minOverscrollLength=()
    //     0xcd289c: bl              #0xcd2afc  ; [package:flutter/src/widgets/scrollbar.dart] ScrollbarPainter::minOverscrollLength=
    // 0xcd28a0: add             SP, SP, #0x10
    // 0xcd28a4: ldr             x1, [fp, #0x10]
    // 0xcd28a8: LoadField: r2 = r1->field_b
    //     0xcd28a8: ldur            w2, [x1, #0xb]
    // 0xcd28ac: DecompressPointer r2
    //     0xcd28ac: add             x2, x2, HEAP, lsl #32
    // 0xcd28b0: cmp             w2, NULL
    // 0xcd28b4: b.eq            #0xcd28e8
    // 0xcd28b8: r0 = Null
    //     0xcd28b8: mov             x0, NULL
    // 0xcd28bc: LeaveFrame
    //     0xcd28bc: mov             SP, fp
    //     0xcd28c0: ldp             fp, lr, [SP], #0x10
    // 0xcd28c4: ret
    //     0xcd28c4: ret             
    // 0xcd28c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd28c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd28cc: b               #0xcd26c4
    // 0xcd28d0: r9 = scrollbarPainter
    //     0xcd28d0: add             x9, PP, #0x4f, lsl #12  ; [pp+0x4f748] Field <RawScrollbarState.scrollbarPainter>: late final (offset: 0x44)
    //     0xcd28d4: ldr             x9, [x9, #0x748]
    // 0xcd28d8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd28d8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd28dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd28dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd28e0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd28e0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd28e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd28e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd28e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd28e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _radius(/* No info */) {
    // ** addr: 0xcd2c8c, size: 0xb0
    // 0xcd2c8c: EnterFrame
    //     0xcd2c8c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd2c90: mov             fp, SP
    // 0xcd2c94: CheckStackOverflow
    //     0xcd2c94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd2c98: cmp             SP, x16
    //     0xcd2c9c: b.ls            #0xcd2d14
    // 0xcd2ca0: ldr             x0, [fp, #0x10]
    // 0xcd2ca4: LoadField: r1 = r0->field_b
    //     0xcd2ca4: ldur            w1, [x0, #0xb]
    // 0xcd2ca8: DecompressPointer r1
    //     0xcd2ca8: add             x1, x1, HEAP, lsl #32
    // 0xcd2cac: cmp             w1, NULL
    // 0xcd2cb0: b.eq            #0xcd2d1c
    // 0xcd2cb4: LoadField: r2 = r1->field_1f
    //     0xcd2cb4: ldur            w2, [x1, #0x1f]
    // 0xcd2cb8: DecompressPointer r2
    //     0xcd2cb8: add             x2, x2, HEAP, lsl #32
    // 0xcd2cbc: LoadField: r1 = r0->field_47
    //     0xcd2cbc: ldur            w1, [x0, #0x47]
    // 0xcd2cc0: DecompressPointer r1
    //     0xcd2cc0: add             x1, x1, HEAP, lsl #32
    // 0xcd2cc4: r16 = Sentinel
    //     0xcd2cc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd2cc8: cmp             w1, w16
    // 0xcd2ccc: b.eq            #0xcd2d20
    // 0xcd2cd0: LoadField: r0 = r1->field_37
    //     0xcd2cd0: ldur            w0, [x1, #0x37]
    // 0xcd2cd4: DecompressPointer r0
    //     0xcd2cd4: add             x0, x0, HEAP, lsl #32
    // 0xcd2cd8: r16 = Sentinel
    //     0xcd2cd8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd2cdc: cmp             w0, w16
    // 0xcd2ce0: b.eq            #0xcd2d2c
    // 0xcd2ce4: LoadField: d0 = r0->field_7
    //     0xcd2ce4: ldur            d0, [x0, #7]
    // 0xcd2ce8: r16 = Instance_Radius
    //     0xcd2ce8: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3ffa0] Obj!Radius@b5e861
    //     0xcd2cec: ldr             x16, [x16, #0xfa0]
    // 0xcd2cf0: stp             x16, x2, [SP, #-0x10]!
    // 0xcd2cf4: SaveReg d0
    //     0xcd2cf4: str             d0, [SP, #-8]!
    // 0xcd2cf8: r0 = lerp()
    //     0xcd2cf8: bl              #0x70e43c  ; [dart:ui] Radius::lerp
    // 0xcd2cfc: add             SP, SP, #0x18
    // 0xcd2d00: cmp             w0, NULL
    // 0xcd2d04: b.eq            #0xcd2d38
    // 0xcd2d08: LeaveFrame
    //     0xcd2d08: mov             SP, fp
    //     0xcd2d0c: ldp             fp, lr, [SP], #0x10
    // 0xcd2d10: ret
    //     0xcd2d10: ret             
    // 0xcd2d14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd2d14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd2d18: b               #0xcd2ca0
    // 0xcd2d1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd2d1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcd2d20: r9 = _thicknessAnimationController
    //     0xcd2d20: add             x9, PP, #0x51, lsl #12  ; [pp+0x51090] Field <_CupertinoScrollbarState@610305104._thicknessAnimationController@610305104>: late (offset: 0x48)
    //     0xcd2d24: ldr             x9, [x9, #0x90]
    // 0xcd2d28: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd2d28: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd2d2c: r9 = _value
    //     0xcd2d2c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xcd2d30: ldr             x9, [x9, #0xbb0]
    // 0xcd2d34: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcd2d34: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xcd2d38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcd2d38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _thickness(/* No info */) {
    // ** addr: 0xcd2d3c, size: 0x98
    // 0xcd2d3c: EnterFrame
    //     0xcd2d3c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd2d40: mov             fp, SP
    // 0xcd2d44: d1 = 8.000000
    //     0xcd2d44: fmov            d1, #8.00000000
    // 0xcd2d48: ldr             x0, [fp, #0x10]
    // 0xcd2d4c: LoadField: r1 = r0->field_b
    //     0xcd2d4c: ldur            w1, [x0, #0xb]
    // 0xcd2d50: DecompressPointer r1
    //     0xcd2d50: add             x1, x1, HEAP, lsl #32
    // 0xcd2d54: cmp             w1, NULL
    // 0xcd2d58: b.eq            #0xcd2db4
    // 0xcd2d5c: LoadField: r2 = r1->field_23
    //     0xcd2d5c: ldur            w2, [x1, #0x23]
    // 0xcd2d60: DecompressPointer r2
    //     0xcd2d60: add             x2, x2, HEAP, lsl #32
    // 0xcd2d64: cmp             w2, NULL
    // 0xcd2d68: b.eq            #0xcd2db8
    // 0xcd2d6c: LoadField: r1 = r0->field_47
    //     0xcd2d6c: ldur            w1, [x0, #0x47]
    // 0xcd2d70: DecompressPointer r1
    //     0xcd2d70: add             x1, x1, HEAP, lsl #32
    // 0xcd2d74: r16 = Sentinel
    //     0xcd2d74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd2d78: cmp             w1, w16
    // 0xcd2d7c: b.eq            #0xcd2dbc
    // 0xcd2d80: LoadField: r0 = r1->field_37
    //     0xcd2d80: ldur            w0, [x1, #0x37]
    // 0xcd2d84: DecompressPointer r0
    //     0xcd2d84: add             x0, x0, HEAP, lsl #32
    // 0xcd2d88: r16 = Sentinel
    //     0xcd2d88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcd2d8c: cmp             w0, w16
    // 0xcd2d90: b.eq            #0xcd2dc8
    // 0xcd2d94: LoadField: d2 = r2->field_7
    //     0xcd2d94: ldur            d2, [x2, #7]
    // 0xcd2d98: fsub            d3, d1, d2
    // 0xcd2d9c: LoadField: d1 = r0->field_7
    //     0xcd2d9c: ldur            d1, [x0, #7]
    // 0xcd2da0: fmul            d4, d1, d3
    // 0xcd2da4: fadd            d0, d2, d4
    // 0xcd2da8: LeaveFrame
    //     0xcd2da8: mov             SP, fp
    //     0xcd2dac: ldp             fp, lr, [SP], #0x10
    // 0xcd2db0: ret
    //     0xcd2db0: ret             
    // 0xcd2db4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd2db4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd2db8: r0 = NullCastErrorSharedWithFPURegs()
    //     0xcd2db8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xcd2dbc: r9 = _thicknessAnimationController
    //     0xcd2dbc: add             x9, PP, #0x51, lsl #12  ; [pp+0x51090] Field <_CupertinoScrollbarState@610305104._thicknessAnimationController@610305104>: late (offset: 0x48)
    //     0xcd2dc0: ldr             x9, [x9, #0x90]
    // 0xcd2dc4: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xcd2dc4: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0xcd2dc8: r9 = _value
    //     0xcd2dc8: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xcd2dcc: ldr             x9, [x9, #0xbb0]
    // 0xcd2dd0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0xcd2dd0: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
}

// class id: 4178, size: 0x80, field offset: 0x74
//   const constructor, 
class CupertinoScrollbar extends RawScrollbar {

  _ createState(/* No info */) {
    // ** addr: 0xa3fe44, size: 0x68
    // 0xa3fe44: EnterFrame
    //     0xa3fe44: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fe48: mov             fp, SP
    // 0xa3fe4c: AllocStack(0x8)
    //     0xa3fe4c: sub             SP, SP, #8
    // 0xa3fe50: r1 = <CupertinoScrollbar>
    //     0xa3fe50: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bab8] TypeArguments: <CupertinoScrollbar>
    //     0xa3fe54: ldr             x1, [x1, #0xab8]
    // 0xa3fe58: r0 = _CupertinoScrollbarState()
    //     0xa3fe58: bl              #0xa3ff0c  ; Allocate_CupertinoScrollbarStateStub -> _CupertinoScrollbarState (size=0x54)
    // 0xa3fe5c: mov             x2, x0
    // 0xa3fe60: r0 = Sentinel
    //     0xa3fe60: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fe64: stur            x2, [fp, #-8]
    // 0xa3fe68: StoreField: r2->field_47 = r0
    //     0xa3fe68: stur            w0, [x2, #0x47]
    // 0xa3fe6c: d0 = 0.000000
    //     0xa3fe6c: eor             v0.16b, v0.16b, v0.16b
    // 0xa3fe70: StoreField: r2->field_4b = d0
    //     0xa3fe70: stur            d0, [x2, #0x4b]
    // 0xa3fe74: StoreField: r2->field_2f = r0
    //     0xa3fe74: stur            w0, [x2, #0x2f]
    // 0xa3fe78: StoreField: r2->field_33 = r0
    //     0xa3fe78: stur            w0, [x2, #0x33]
    // 0xa3fe7c: r1 = false
    //     0xa3fe7c: add             x1, NULL, #0x30  ; false
    // 0xa3fe80: StoreField: r2->field_3b = r1
    //     0xa3fe80: stur            w1, [x2, #0x3b]
    // 0xa3fe84: StoreField: r2->field_3f = r1
    //     0xa3fe84: stur            w1, [x2, #0x3f]
    // 0xa3fe88: StoreField: r2->field_43 = r0
    //     0xa3fe88: stur            w0, [x2, #0x43]
    // 0xa3fe8c: r1 = <State<StatefulWidget>>
    //     0xa3fe8c: ldr             x1, [PP, #0x3b30]  ; [pp+0x3b30] TypeArguments: <State<StatefulWidget>>
    // 0xa3fe90: r0 = LabeledGlobalKey()
    //     0xa3fe90: bl              #0x594e78  ; AllocateLabeledGlobalKeyStub -> LabeledGlobalKey<X0 bound State<StatefulWidget>> (size=0x10)
    // 0xa3fe94: mov             x1, x0
    // 0xa3fe98: ldur            x0, [fp, #-8]
    // 0xa3fe9c: StoreField: r0->field_37 = r1
    //     0xa3fe9c: stur            w1, [x0, #0x37]
    // 0xa3fea0: LeaveFrame
    //     0xa3fea0: mov             SP, fp
    //     0xa3fea4: ldp             fp, lr, [SP], #0x10
    // 0xa3fea8: ret
    //     0xa3fea8: ret             
  }
}

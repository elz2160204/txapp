// lib: , url: package:flutter/src/cupertino/text_theme.dart

// class id: 1049115, size: 0x8
class :: {
}

// class id: 2663, size: 0x10, field offset: 0x8
//   const constructor, 
class _TextThemeDefaultsBuilder extends Object {

  CupertinoDynamicColor field_8;
  CupertinoDynamicColor field_c;

  static TextStyle _applyLabelColor() {
    // ** addr: 0x83fdd0, size: 0x78
    // 0x83fdd0: EnterFrame
    //     0x83fdd0: stp             fp, lr, [SP, #-0x10]!
    //     0x83fdd4: mov             fp, SP
    // 0x83fdd8: CheckStackOverflow
    //     0x83fdd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83fddc: cmp             SP, x16
    //     0x83fde0: b.ls            #0x83fe40
    // 0x83fde4: r16 = Instance_CupertinoDynamicColor
    //     0x83fde4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40540] Obj!CupertinoDynamicColor@b5e531
    //     0x83fde8: ldr             x16, [x16, #0x540]
    // 0x83fdec: r30 = Instance_CupertinoDynamicColor
    //     0x83fdec: add             lr, PP, #0x40, lsl #12  ; [pp+0x40540] Obj!CupertinoDynamicColor@b5e531
    //     0x83fdf0: ldr             lr, [lr, #0x540]
    // 0x83fdf4: stp             lr, x16, [SP, #-0x10]!
    // 0x83fdf8: r0 = ==()
    //     0x83fdf8: bl              #0xc664cc  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x83fdfc: add             SP, SP, #0x10
    // 0x83fe00: tbnz            w0, #4, #0x83fe10
    // 0x83fe04: r0 = Instance_TextStyle
    //     0x83fe04: add             x0, PP, #0x40, lsl #12  ; [pp+0x40548] Obj!TextStyle@b43ad1
    //     0x83fe08: ldr             x0, [x0, #0x548]
    // 0x83fe0c: b               #0x83fe34
    // 0x83fe10: r16 = Instance_TextStyle
    //     0x83fe10: add             x16, PP, #0x40, lsl #12  ; [pp+0x40548] Obj!TextStyle@b43ad1
    //     0x83fe14: ldr             x16, [x16, #0x548]
    // 0x83fe18: r30 = Instance_CupertinoDynamicColor
    //     0x83fe18: add             lr, PP, #0x40, lsl #12  ; [pp+0x40540] Obj!CupertinoDynamicColor@b5e531
    //     0x83fe1c: ldr             lr, [lr, #0x540]
    // 0x83fe20: stp             lr, x16, [SP, #-0x10]!
    // 0x83fe24: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x83fe24: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x83fe28: ldr             x4, [x4, #0x168]
    // 0x83fe2c: r0 = copyWith()
    //     0x83fe2c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x83fe30: add             SP, SP, #0x10
    // 0x83fe34: LeaveFrame
    //     0x83fe34: mov             SP, fp
    //     0x83fe38: ldp             fp, lr, [SP], #0x10
    // 0x83fe3c: ret
    //     0x83fe3c: ret             
    // 0x83fe40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83fe40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83fe44: b               #0x83fde4
  }
}

// class id: 2896, size: 0x10, field offset: 0x8
//   const constructor, 
class CupertinoTextThemeData extends _DiagnosticableTree&Object&Diagnosticable {

  get _ textStyle(/* No info */) {
    // ** addr: 0x83fda4, size: 0x2c
    // 0x83fda4: EnterFrame
    //     0x83fda4: stp             fp, lr, [SP, #-0x10]!
    //     0x83fda8: mov             fp, SP
    // 0x83fdac: CheckStackOverflow
    //     0x83fdac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83fdb0: cmp             SP, x16
    //     0x83fdb4: b.ls            #0x83fdc8
    // 0x83fdb8: r0 = _applyLabelColor()
    //     0x83fdb8: bl              #0x83fdd0  ; [package:flutter/src/cupertino/text_theme.dart] _TextThemeDefaultsBuilder::_applyLabelColor
    // 0x83fdbc: LeaveFrame
    //     0x83fdbc: mov             SP, fp
    //     0x83fdc0: ldp             fp, lr, [SP], #0x10
    // 0x83fdc4: ret
    //     0x83fdc4: ret             
    // 0x83fdc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83fdc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83fdcc: b               #0x83fdb8
  }
}

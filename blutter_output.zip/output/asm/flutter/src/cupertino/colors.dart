// lib: , url: package:flutter/src/cupertino/colors.dart

// class id: 1049078, size: 0x8
class :: {
}

// class id: 5063, size: 0x10, field offset: 0x10
//   const constructor, transformed mixin,
abstract class _CupertinoDynamicColor&Color&Diagnosticable extends Color
     with Diagnosticable {
}

// class id: 5064, size: 0x3c, field offset: 0x10
//   const constructor, 
class CupertinoDynamicColor extends _CupertinoDynamicColor&Color&Diagnosticable {

  _Mint field_8;
  Color field_10;
  Color field_1c;
  Color field_20;
  Color field_24;
  Color field_28;
  Color field_2c;
  Color field_30;
  Color field_34;
  Color field_38;
  _OneByteString field_14;

  static _ resolve(/* No info */) {
    // ** addr: 0x6ca720, size: 0x54
    // 0x6ca720: EnterFrame
    //     0x6ca720: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca724: mov             fp, SP
    // 0x6ca728: CheckStackOverflow
    //     0x6ca728: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca72c: cmp             SP, x16
    //     0x6ca730: b.ls            #0x6ca76c
    // 0x6ca734: ldr             x0, [fp, #0x18]
    // 0x6ca738: r1 = LoadClassIdInstr(r0)
    //     0x6ca738: ldur            x1, [x0, #-1]
    //     0x6ca73c: ubfx            x1, x1, #0xc, #0x14
    // 0x6ca740: lsl             x1, x1, #1
    // 0x6ca744: r17 = 10128
    //     0x6ca744: mov             x17, #0x2790
    // 0x6ca748: cmp             w1, w17
    // 0x6ca74c: b.ne            #0x6ca760
    // 0x6ca750: ldr             x16, [fp, #0x10]
    // 0x6ca754: stp             x16, x0, [SP, #-0x10]!
    // 0x6ca758: r0 = resolveFrom()
    //     0x6ca758: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x6ca75c: add             SP, SP, #0x10
    // 0x6ca760: LeaveFrame
    //     0x6ca760: mov             SP, fp
    //     0x6ca764: ldp             fp, lr, [SP], #0x10
    // 0x6ca768: ret
    //     0x6ca768: ret             
    // 0x6ca76c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca76c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca770: b               #0x6ca734
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0x6ca974, size: 0x208
    // 0x6ca974: EnterFrame
    //     0x6ca974: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca978: mov             fp, SP
    // 0x6ca97c: AllocStack(0x50)
    //     0x6ca97c: sub             SP, SP, #0x50
    // 0x6ca980: CheckStackOverflow
    //     0x6ca980: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca984: cmp             SP, x16
    //     0x6ca988: b.ls            #0x6cab74
    // 0x6ca98c: ldr             x16, [fp, #0x18]
    // 0x6ca990: SaveReg r16
    //     0x6ca990: str             x16, [SP, #-8]!
    // 0x6ca994: r0 = _isPlatformBrightnessDependent()
    //     0x6ca994: bl              #0x6cb054  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isPlatformBrightnessDependent
    // 0x6ca998: add             SP, SP, #8
    // 0x6ca99c: tbnz            w0, #4, #0x6ca9c0
    // 0x6ca9a0: ldr             x16, [fp, #0x10]
    // 0x6ca9a4: SaveReg r16
    //     0x6ca9a4: str             x16, [SP, #-8]!
    // 0x6ca9a8: r0 = maybeBrightnessOf()
    //     0x6ca9a8: bl              #0x6caf58  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::maybeBrightnessOf
    // 0x6ca9ac: add             SP, SP, #8
    // 0x6ca9b0: cmp             w0, NULL
    // 0x6ca9b4: b.ne            #0x6ca9c4
    // 0x6ca9b8: r0 = Instance_Brightness
    //     0x6ca9b8: ldr             x0, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6ca9bc: b               #0x6ca9c4
    // 0x6ca9c0: r0 = Instance_Brightness
    //     0x6ca9c0: ldr             x0, [PP, #0x2140]  ; [pp+0x2140] Obj!Brightness@b66cd1
    // 0x6ca9c4: stur            x0, [fp, #-8]
    // 0x6ca9c8: ldr             x16, [fp, #0x18]
    // 0x6ca9cc: SaveReg r16
    //     0x6ca9cc: str             x16, [SP, #-8]!
    // 0x6ca9d0: r0 = _isHighContrastDependent()
    //     0x6ca9d0: bl              #0x6cad94  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isHighContrastDependent
    // 0x6ca9d4: add             SP, SP, #8
    // 0x6ca9d8: tbnz            w0, #4, #0x6caa18
    // 0x6ca9dc: ldr             x16, [fp, #0x10]
    // 0x6ca9e0: SaveReg r16
    //     0x6ca9e0: str             x16, [SP, #-8]!
    // 0x6ca9e4: r0 = maybeOf()
    //     0x6ca9e4: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x6ca9e8: add             SP, SP, #8
    // 0x6ca9ec: cmp             w0, NULL
    // 0x6ca9f0: b.ne            #0x6ca9fc
    // 0x6ca9f4: r0 = Null
    //     0x6ca9f4: mov             x0, NULL
    // 0x6ca9f8: b               #0x6caa08
    // 0x6ca9fc: LoadField: r1 = r0->field_3b
    //     0x6ca9fc: ldur            w1, [x0, #0x3b]
    // 0x6caa00: DecompressPointer r1
    //     0x6caa00: add             x1, x1, HEAP, lsl #32
    // 0x6caa04: mov             x0, x1
    // 0x6caa08: cmp             w0, NULL
    // 0x6caa0c: b.ne            #0x6caa1c
    // 0x6caa10: r0 = false
    //     0x6caa10: add             x0, NULL, #0x30  ; false
    // 0x6caa14: b               #0x6caa1c
    // 0x6caa18: r0 = false
    //     0x6caa18: add             x0, NULL, #0x30  ; false
    // 0x6caa1c: stur            x0, [fp, #-0x10]
    // 0x6caa20: ldr             x16, [fp, #0x18]
    // 0x6caa24: SaveReg r16
    //     0x6caa24: str             x16, [SP, #-8]!
    // 0x6caa28: r0 = _isInterfaceElevationDependent()
    //     0x6caa28: bl              #0x6cabd0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isInterfaceElevationDependent
    // 0x6caa2c: add             SP, SP, #8
    // 0x6caa30: tbnz            w0, #4, #0x6caa44
    // 0x6caa34: ldr             x16, [fp, #0x10]
    // 0x6caa38: SaveReg r16
    //     0x6caa38: str             x16, [SP, #-8]!
    // 0x6caa3c: r0 = maybeOf()
    //     0x6caa3c: bl              #0x6cab88  ; [package:flutter/src/cupertino/interface_level.dart] CupertinoUserInterfaceLevel::maybeOf
    // 0x6caa40: add             SP, SP, #8
    // 0x6caa44: ldur            x0, [fp, #-8]
    // 0x6caa48: LoadField: r1 = r0->field_7
    //     0x6caa48: ldur            x1, [x0, #7]
    // 0x6caa4c: cmp             x1, #0
    // 0x6caa50: b.gt            #0x6caa7c
    // 0x6caa54: ldur            x0, [fp, #-0x10]
    // 0x6caa58: tbnz            w0, #4, #0x6caa6c
    // 0x6caa5c: ldr             x1, [fp, #0x18]
    // 0x6caa60: LoadField: r0 = r1->field_27
    //     0x6caa60: ldur            w0, [x1, #0x27]
    // 0x6caa64: DecompressPointer r0
    //     0x6caa64: add             x0, x0, HEAP, lsl #32
    // 0x6caa68: b               #0x6caa9c
    // 0x6caa6c: ldr             x1, [fp, #0x18]
    // 0x6caa70: LoadField: r0 = r1->field_1f
    //     0x6caa70: ldur            w0, [x1, #0x1f]
    // 0x6caa74: DecompressPointer r0
    //     0x6caa74: add             x0, x0, HEAP, lsl #32
    // 0x6caa78: b               #0x6caa9c
    // 0x6caa7c: ldr             x1, [fp, #0x18]
    // 0x6caa80: ldur            x0, [fp, #-0x10]
    // 0x6caa84: tbnz            w0, #4, #0x6caa94
    // 0x6caa88: LoadField: r0 = r1->field_23
    //     0x6caa88: ldur            w0, [x1, #0x23]
    // 0x6caa8c: DecompressPointer r0
    //     0x6caa8c: add             x0, x0, HEAP, lsl #32
    // 0x6caa90: b               #0x6caa9c
    // 0x6caa94: LoadField: r0 = r1->field_1b
    //     0x6caa94: ldur            w0, [x1, #0x1b]
    // 0x6caa98: DecompressPointer r0
    //     0x6caa98: add             x0, x0, HEAP, lsl #32
    // 0x6caa9c: stur            x0, [fp, #-0x50]
    // 0x6caaa0: LoadField: r2 = r1->field_1b
    //     0x6caaa0: ldur            w2, [x1, #0x1b]
    // 0x6caaa4: DecompressPointer r2
    //     0x6caaa4: add             x2, x2, HEAP, lsl #32
    // 0x6caaa8: stur            x2, [fp, #-0x48]
    // 0x6caaac: LoadField: r3 = r1->field_1f
    //     0x6caaac: ldur            w3, [x1, #0x1f]
    // 0x6caab0: DecompressPointer r3
    //     0x6caab0: add             x3, x3, HEAP, lsl #32
    // 0x6caab4: stur            x3, [fp, #-0x40]
    // 0x6caab8: LoadField: r4 = r1->field_23
    //     0x6caab8: ldur            w4, [x1, #0x23]
    // 0x6caabc: DecompressPointer r4
    //     0x6caabc: add             x4, x4, HEAP, lsl #32
    // 0x6caac0: stur            x4, [fp, #-0x38]
    // 0x6caac4: LoadField: r5 = r1->field_27
    //     0x6caac4: ldur            w5, [x1, #0x27]
    // 0x6caac8: DecompressPointer r5
    //     0x6caac8: add             x5, x5, HEAP, lsl #32
    // 0x6caacc: stur            x5, [fp, #-0x30]
    // 0x6caad0: LoadField: r6 = r1->field_2b
    //     0x6caad0: ldur            w6, [x1, #0x2b]
    // 0x6caad4: DecompressPointer r6
    //     0x6caad4: add             x6, x6, HEAP, lsl #32
    // 0x6caad8: stur            x6, [fp, #-0x28]
    // 0x6caadc: LoadField: r7 = r1->field_2f
    //     0x6caadc: ldur            w7, [x1, #0x2f]
    // 0x6caae0: DecompressPointer r7
    //     0x6caae0: add             x7, x7, HEAP, lsl #32
    // 0x6caae4: stur            x7, [fp, #-0x20]
    // 0x6caae8: LoadField: r8 = r1->field_33
    //     0x6caae8: ldur            w8, [x1, #0x33]
    // 0x6caaec: DecompressPointer r8
    //     0x6caaec: add             x8, x8, HEAP, lsl #32
    // 0x6caaf0: stur            x8, [fp, #-0x18]
    // 0x6caaf4: LoadField: r9 = r1->field_37
    //     0x6caaf4: ldur            w9, [x1, #0x37]
    // 0x6caaf8: DecompressPointer r9
    //     0x6caaf8: add             x9, x9, HEAP, lsl #32
    // 0x6caafc: stur            x9, [fp, #-0x10]
    // 0x6cab00: LoadField: r10 = r1->field_13
    //     0x6cab00: ldur            w10, [x1, #0x13]
    // 0x6cab04: DecompressPointer r10
    //     0x6cab04: add             x10, x10, HEAP, lsl #32
    // 0x6cab08: stur            x10, [fp, #-8]
    // 0x6cab0c: r0 = CupertinoDynamicColor()
    //     0x6cab0c: bl              #0x6cab7c  ; AllocateCupertinoDynamicColorStub -> CupertinoDynamicColor (size=0x3c)
    // 0x6cab10: ldur            x1, [fp, #-0x50]
    // 0x6cab14: StoreField: r0->field_f = r1
    //     0x6cab14: stur            w1, [x0, #0xf]
    // 0x6cab18: ldur            x1, [fp, #-0x48]
    // 0x6cab1c: StoreField: r0->field_1b = r1
    //     0x6cab1c: stur            w1, [x0, #0x1b]
    // 0x6cab20: ldur            x1, [fp, #-0x40]
    // 0x6cab24: StoreField: r0->field_1f = r1
    //     0x6cab24: stur            w1, [x0, #0x1f]
    // 0x6cab28: ldur            x1, [fp, #-0x38]
    // 0x6cab2c: StoreField: r0->field_23 = r1
    //     0x6cab2c: stur            w1, [x0, #0x23]
    // 0x6cab30: ldur            x1, [fp, #-0x30]
    // 0x6cab34: StoreField: r0->field_27 = r1
    //     0x6cab34: stur            w1, [x0, #0x27]
    // 0x6cab38: ldur            x1, [fp, #-0x28]
    // 0x6cab3c: StoreField: r0->field_2b = r1
    //     0x6cab3c: stur            w1, [x0, #0x2b]
    // 0x6cab40: ldur            x1, [fp, #-0x20]
    // 0x6cab44: StoreField: r0->field_2f = r1
    //     0x6cab44: stur            w1, [x0, #0x2f]
    // 0x6cab48: ldur            x1, [fp, #-0x18]
    // 0x6cab4c: StoreField: r0->field_33 = r1
    //     0x6cab4c: stur            w1, [x0, #0x33]
    // 0x6cab50: ldur            x1, [fp, #-0x10]
    // 0x6cab54: StoreField: r0->field_37 = r1
    //     0x6cab54: stur            w1, [x0, #0x37]
    // 0x6cab58: ldur            x1, [fp, #-8]
    // 0x6cab5c: StoreField: r0->field_13 = r1
    //     0x6cab5c: stur            w1, [x0, #0x13]
    // 0x6cab60: r1 = 0
    //     0x6cab60: mov             x1, #0
    // 0x6cab64: StoreField: r0->field_7 = r1
    //     0x6cab64: stur            x1, [x0, #7]
    // 0x6cab68: LeaveFrame
    //     0x6cab68: mov             SP, fp
    //     0x6cab6c: ldp             fp, lr, [SP], #0x10
    // 0x6cab70: ret
    //     0x6cab70: ret             
    // 0x6cab74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cab74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cab78: b               #0x6ca98c
  }
  get _ _isInterfaceElevationDependent(/* No info */) {
    // ** addr: 0x6cabd0, size: 0x1c4
    // 0x6cabd0: EnterFrame
    //     0x6cabd0: stp             fp, lr, [SP, #-0x10]!
    //     0x6cabd4: mov             fp, SP
    // 0x6cabd8: AllocStack(0x10)
    //     0x6cabd8: sub             SP, SP, #0x10
    // 0x6cabdc: CheckStackOverflow
    //     0x6cabdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cabe0: cmp             SP, x16
    //     0x6cabe4: b.ls            #0x6cad8c
    // 0x6cabe8: ldr             x0, [fp, #0x10]
    // 0x6cabec: LoadField: r1 = r0->field_1b
    //     0x6cabec: ldur            w1, [x0, #0x1b]
    // 0x6cabf0: DecompressPointer r1
    //     0x6cabf0: add             x1, x1, HEAP, lsl #32
    // 0x6cabf4: stur            x1, [fp, #-0x10]
    // 0x6cabf8: LoadField: r2 = r0->field_2b
    //     0x6cabf8: ldur            w2, [x0, #0x2b]
    // 0x6cabfc: DecompressPointer r2
    //     0x6cabfc: add             x2, x2, HEAP, lsl #32
    // 0x6cac00: stur            x2, [fp, #-8]
    // 0x6cac04: cmp             w1, w2
    // 0x6cac08: b.eq            #0x6cac48
    // 0x6cac0c: r16 = Color
    //     0x6cac0c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cac10: ldr             x16, [x16, #0xf18]
    // 0x6cac14: r30 = Color
    //     0x6cac14: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cac18: ldr             lr, [lr, #0xf18]
    // 0x6cac1c: stp             lr, x16, [SP, #-0x10]!
    // 0x6cac20: r0 = ==()
    //     0x6cac20: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cac24: add             SP, SP, #0x10
    // 0x6cac28: tbnz            w0, #4, #0x6cacfc
    // 0x6cac2c: ldur            x0, [fp, #-0x10]
    // 0x6cac30: ldur            x1, [fp, #-8]
    // 0x6cac34: LoadField: r2 = r1->field_7
    //     0x6cac34: ldur            x2, [x1, #7]
    // 0x6cac38: LoadField: r1 = r0->field_7
    //     0x6cac38: ldur            x1, [x0, #7]
    // 0x6cac3c: cmp             x2, x1
    // 0x6cac40: b.ne            #0x6cacfc
    // 0x6cac44: ldr             x0, [fp, #0x10]
    // 0x6cac48: LoadField: r1 = r0->field_1f
    //     0x6cac48: ldur            w1, [x0, #0x1f]
    // 0x6cac4c: DecompressPointer r1
    //     0x6cac4c: add             x1, x1, HEAP, lsl #32
    // 0x6cac50: stur            x1, [fp, #-0x10]
    // 0x6cac54: LoadField: r2 = r0->field_2f
    //     0x6cac54: ldur            w2, [x0, #0x2f]
    // 0x6cac58: DecompressPointer r2
    //     0x6cac58: add             x2, x2, HEAP, lsl #32
    // 0x6cac5c: stur            x2, [fp, #-8]
    // 0x6cac60: cmp             w1, w2
    // 0x6cac64: b.eq            #0x6caca4
    // 0x6cac68: r16 = Color
    //     0x6cac68: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cac6c: ldr             x16, [x16, #0xf18]
    // 0x6cac70: r30 = Color
    //     0x6cac70: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cac74: ldr             lr, [lr, #0xf18]
    // 0x6cac78: stp             lr, x16, [SP, #-0x10]!
    // 0x6cac7c: r0 = ==()
    //     0x6cac7c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cac80: add             SP, SP, #0x10
    // 0x6cac84: tbnz            w0, #4, #0x6cacfc
    // 0x6cac88: ldur            x0, [fp, #-0x10]
    // 0x6cac8c: ldur            x1, [fp, #-8]
    // 0x6cac90: LoadField: r2 = r1->field_7
    //     0x6cac90: ldur            x2, [x1, #7]
    // 0x6cac94: LoadField: r1 = r0->field_7
    //     0x6cac94: ldur            x1, [x0, #7]
    // 0x6cac98: cmp             x2, x1
    // 0x6cac9c: b.ne            #0x6cacfc
    // 0x6caca0: ldr             x0, [fp, #0x10]
    // 0x6caca4: LoadField: r1 = r0->field_23
    //     0x6caca4: ldur            w1, [x0, #0x23]
    // 0x6caca8: DecompressPointer r1
    //     0x6caca8: add             x1, x1, HEAP, lsl #32
    // 0x6cacac: stur            x1, [fp, #-0x10]
    // 0x6cacb0: LoadField: r2 = r0->field_33
    //     0x6cacb0: ldur            w2, [x0, #0x33]
    // 0x6cacb4: DecompressPointer r2
    //     0x6cacb4: add             x2, x2, HEAP, lsl #32
    // 0x6cacb8: stur            x2, [fp, #-8]
    // 0x6cacbc: cmp             w1, w2
    // 0x6cacc0: b.eq            #0x6cad08
    // 0x6cacc4: r16 = Color
    //     0x6cacc4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cacc8: ldr             x16, [x16, #0xf18]
    // 0x6caccc: r30 = Color
    //     0x6caccc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cacd0: ldr             lr, [lr, #0xf18]
    // 0x6cacd4: stp             lr, x16, [SP, #-0x10]!
    // 0x6cacd8: r0 = ==()
    //     0x6cacd8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cacdc: add             SP, SP, #0x10
    // 0x6cace0: tbnz            w0, #4, #0x6cacfc
    // 0x6cace4: ldur            x0, [fp, #-0x10]
    // 0x6cace8: ldur            x1, [fp, #-8]
    // 0x6cacec: LoadField: r2 = r1->field_7
    //     0x6cacec: ldur            x2, [x1, #7]
    // 0x6cacf0: LoadField: r1 = r0->field_7
    //     0x6cacf0: ldur            x1, [x0, #7]
    // 0x6cacf4: cmp             x2, x1
    // 0x6cacf8: b.eq            #0x6cad04
    // 0x6cacfc: r0 = true
    //     0x6cacfc: add             x0, NULL, #0x20  ; true
    // 0x6cad00: b               #0x6cad80
    // 0x6cad04: ldr             x0, [fp, #0x10]
    // 0x6cad08: LoadField: r1 = r0->field_27
    //     0x6cad08: ldur            w1, [x0, #0x27]
    // 0x6cad0c: DecompressPointer r1
    //     0x6cad0c: add             x1, x1, HEAP, lsl #32
    // 0x6cad10: stur            x1, [fp, #-0x10]
    // 0x6cad14: LoadField: r2 = r0->field_37
    //     0x6cad14: ldur            w2, [x0, #0x37]
    // 0x6cad18: DecompressPointer r2
    //     0x6cad18: add             x2, x2, HEAP, lsl #32
    // 0x6cad1c: stur            x2, [fp, #-8]
    // 0x6cad20: cmp             w1, w2
    // 0x6cad24: b.ne            #0x6cad30
    // 0x6cad28: r1 = true
    //     0x6cad28: add             x1, NULL, #0x20  ; true
    // 0x6cad2c: b               #0x6cad78
    // 0x6cad30: r16 = Color
    //     0x6cad30: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cad34: ldr             x16, [x16, #0xf18]
    // 0x6cad38: r30 = Color
    //     0x6cad38: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cad3c: ldr             lr, [lr, #0xf18]
    // 0x6cad40: stp             lr, x16, [SP, #-0x10]!
    // 0x6cad44: r0 = ==()
    //     0x6cad44: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cad48: add             SP, SP, #0x10
    // 0x6cad4c: tbz             w0, #4, #0x6cad58
    // 0x6cad50: r1 = false
    //     0x6cad50: add             x1, NULL, #0x30  ; false
    // 0x6cad54: b               #0x6cad78
    // 0x6cad58: ldur            x1, [fp, #-0x10]
    // 0x6cad5c: ldur            x2, [fp, #-8]
    // 0x6cad60: LoadField: r3 = r2->field_7
    //     0x6cad60: ldur            x3, [x2, #7]
    // 0x6cad64: LoadField: r2 = r1->field_7
    //     0x6cad64: ldur            x2, [x1, #7]
    // 0x6cad68: cmp             x3, x2
    // 0x6cad6c: r16 = true
    //     0x6cad6c: add             x16, NULL, #0x20  ; true
    // 0x6cad70: r17 = false
    //     0x6cad70: add             x17, NULL, #0x30  ; false
    // 0x6cad74: csel            x1, x16, x17, eq
    // 0x6cad78: eor             x2, x1, #0x10
    // 0x6cad7c: mov             x0, x2
    // 0x6cad80: LeaveFrame
    //     0x6cad80: mov             SP, fp
    //     0x6cad84: ldp             fp, lr, [SP], #0x10
    // 0x6cad88: ret
    //     0x6cad88: ret             
    // 0x6cad8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cad8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cad90: b               #0x6cabe8
  }
  get _ _isHighContrastDependent(/* No info */) {
    // ** addr: 0x6cad94, size: 0x1c4
    // 0x6cad94: EnterFrame
    //     0x6cad94: stp             fp, lr, [SP, #-0x10]!
    //     0x6cad98: mov             fp, SP
    // 0x6cad9c: AllocStack(0x10)
    //     0x6cad9c: sub             SP, SP, #0x10
    // 0x6cada0: CheckStackOverflow
    //     0x6cada0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cada4: cmp             SP, x16
    //     0x6cada8: b.ls            #0x6caf50
    // 0x6cadac: ldr             x0, [fp, #0x10]
    // 0x6cadb0: LoadField: r1 = r0->field_1b
    //     0x6cadb0: ldur            w1, [x0, #0x1b]
    // 0x6cadb4: DecompressPointer r1
    //     0x6cadb4: add             x1, x1, HEAP, lsl #32
    // 0x6cadb8: stur            x1, [fp, #-0x10]
    // 0x6cadbc: LoadField: r2 = r0->field_23
    //     0x6cadbc: ldur            w2, [x0, #0x23]
    // 0x6cadc0: DecompressPointer r2
    //     0x6cadc0: add             x2, x2, HEAP, lsl #32
    // 0x6cadc4: stur            x2, [fp, #-8]
    // 0x6cadc8: cmp             w1, w2
    // 0x6cadcc: b.eq            #0x6cae0c
    // 0x6cadd0: r16 = Color
    //     0x6cadd0: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cadd4: ldr             x16, [x16, #0xf18]
    // 0x6cadd8: r30 = Color
    //     0x6cadd8: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6caddc: ldr             lr, [lr, #0xf18]
    // 0x6cade0: stp             lr, x16, [SP, #-0x10]!
    // 0x6cade4: r0 = ==()
    //     0x6cade4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cade8: add             SP, SP, #0x10
    // 0x6cadec: tbnz            w0, #4, #0x6caec0
    // 0x6cadf0: ldur            x0, [fp, #-0x10]
    // 0x6cadf4: ldur            x1, [fp, #-8]
    // 0x6cadf8: LoadField: r2 = r1->field_7
    //     0x6cadf8: ldur            x2, [x1, #7]
    // 0x6cadfc: LoadField: r1 = r0->field_7
    //     0x6cadfc: ldur            x1, [x0, #7]
    // 0x6cae00: cmp             x2, x1
    // 0x6cae04: b.ne            #0x6caec0
    // 0x6cae08: ldr             x0, [fp, #0x10]
    // 0x6cae0c: LoadField: r1 = r0->field_1f
    //     0x6cae0c: ldur            w1, [x0, #0x1f]
    // 0x6cae10: DecompressPointer r1
    //     0x6cae10: add             x1, x1, HEAP, lsl #32
    // 0x6cae14: stur            x1, [fp, #-0x10]
    // 0x6cae18: LoadField: r2 = r0->field_27
    //     0x6cae18: ldur            w2, [x0, #0x27]
    // 0x6cae1c: DecompressPointer r2
    //     0x6cae1c: add             x2, x2, HEAP, lsl #32
    // 0x6cae20: stur            x2, [fp, #-8]
    // 0x6cae24: cmp             w1, w2
    // 0x6cae28: b.eq            #0x6cae68
    // 0x6cae2c: r16 = Color
    //     0x6cae2c: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cae30: ldr             x16, [x16, #0xf18]
    // 0x6cae34: r30 = Color
    //     0x6cae34: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cae38: ldr             lr, [lr, #0xf18]
    // 0x6cae3c: stp             lr, x16, [SP, #-0x10]!
    // 0x6cae40: r0 = ==()
    //     0x6cae40: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cae44: add             SP, SP, #0x10
    // 0x6cae48: tbnz            w0, #4, #0x6caec0
    // 0x6cae4c: ldur            x0, [fp, #-0x10]
    // 0x6cae50: ldur            x1, [fp, #-8]
    // 0x6cae54: LoadField: r2 = r1->field_7
    //     0x6cae54: ldur            x2, [x1, #7]
    // 0x6cae58: LoadField: r1 = r0->field_7
    //     0x6cae58: ldur            x1, [x0, #7]
    // 0x6cae5c: cmp             x2, x1
    // 0x6cae60: b.ne            #0x6caec0
    // 0x6cae64: ldr             x0, [fp, #0x10]
    // 0x6cae68: LoadField: r1 = r0->field_2b
    //     0x6cae68: ldur            w1, [x0, #0x2b]
    // 0x6cae6c: DecompressPointer r1
    //     0x6cae6c: add             x1, x1, HEAP, lsl #32
    // 0x6cae70: stur            x1, [fp, #-0x10]
    // 0x6cae74: LoadField: r2 = r0->field_33
    //     0x6cae74: ldur            w2, [x0, #0x33]
    // 0x6cae78: DecompressPointer r2
    //     0x6cae78: add             x2, x2, HEAP, lsl #32
    // 0x6cae7c: stur            x2, [fp, #-8]
    // 0x6cae80: cmp             w1, w2
    // 0x6cae84: b.eq            #0x6caecc
    // 0x6cae88: r16 = Color
    //     0x6cae88: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cae8c: ldr             x16, [x16, #0xf18]
    // 0x6cae90: r30 = Color
    //     0x6cae90: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cae94: ldr             lr, [lr, #0xf18]
    // 0x6cae98: stp             lr, x16, [SP, #-0x10]!
    // 0x6cae9c: r0 = ==()
    //     0x6cae9c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6caea0: add             SP, SP, #0x10
    // 0x6caea4: tbnz            w0, #4, #0x6caec0
    // 0x6caea8: ldur            x0, [fp, #-0x10]
    // 0x6caeac: ldur            x1, [fp, #-8]
    // 0x6caeb0: LoadField: r2 = r1->field_7
    //     0x6caeb0: ldur            x2, [x1, #7]
    // 0x6caeb4: LoadField: r1 = r0->field_7
    //     0x6caeb4: ldur            x1, [x0, #7]
    // 0x6caeb8: cmp             x2, x1
    // 0x6caebc: b.eq            #0x6caec8
    // 0x6caec0: r0 = true
    //     0x6caec0: add             x0, NULL, #0x20  ; true
    // 0x6caec4: b               #0x6caf44
    // 0x6caec8: ldr             x0, [fp, #0x10]
    // 0x6caecc: LoadField: r1 = r0->field_2f
    //     0x6caecc: ldur            w1, [x0, #0x2f]
    // 0x6caed0: DecompressPointer r1
    //     0x6caed0: add             x1, x1, HEAP, lsl #32
    // 0x6caed4: stur            x1, [fp, #-0x10]
    // 0x6caed8: LoadField: r2 = r0->field_37
    //     0x6caed8: ldur            w2, [x0, #0x37]
    // 0x6caedc: DecompressPointer r2
    //     0x6caedc: add             x2, x2, HEAP, lsl #32
    // 0x6caee0: stur            x2, [fp, #-8]
    // 0x6caee4: cmp             w1, w2
    // 0x6caee8: b.ne            #0x6caef4
    // 0x6caeec: r1 = true
    //     0x6caeec: add             x1, NULL, #0x20  ; true
    // 0x6caef0: b               #0x6caf3c
    // 0x6caef4: r16 = Color
    //     0x6caef4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6caef8: ldr             x16, [x16, #0xf18]
    // 0x6caefc: r30 = Color
    //     0x6caefc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6caf00: ldr             lr, [lr, #0xf18]
    // 0x6caf04: stp             lr, x16, [SP, #-0x10]!
    // 0x6caf08: r0 = ==()
    //     0x6caf08: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6caf0c: add             SP, SP, #0x10
    // 0x6caf10: tbz             w0, #4, #0x6caf1c
    // 0x6caf14: r1 = false
    //     0x6caf14: add             x1, NULL, #0x30  ; false
    // 0x6caf18: b               #0x6caf3c
    // 0x6caf1c: ldur            x1, [fp, #-0x10]
    // 0x6caf20: ldur            x2, [fp, #-8]
    // 0x6caf24: LoadField: r3 = r2->field_7
    //     0x6caf24: ldur            x3, [x2, #7]
    // 0x6caf28: LoadField: r2 = r1->field_7
    //     0x6caf28: ldur            x2, [x1, #7]
    // 0x6caf2c: cmp             x3, x2
    // 0x6caf30: r16 = true
    //     0x6caf30: add             x16, NULL, #0x20  ; true
    // 0x6caf34: r17 = false
    //     0x6caf34: add             x17, NULL, #0x30  ; false
    // 0x6caf38: csel            x1, x16, x17, eq
    // 0x6caf3c: eor             x2, x1, #0x10
    // 0x6caf40: mov             x0, x2
    // 0x6caf44: LeaveFrame
    //     0x6caf44: mov             SP, fp
    //     0x6caf48: ldp             fp, lr, [SP], #0x10
    // 0x6caf4c: ret
    //     0x6caf4c: ret             
    // 0x6caf50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6caf50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6caf54: b               #0x6cadac
  }
  get _ _isPlatformBrightnessDependent(/* No info */) {
    // ** addr: 0x6cb054, size: 0x1c4
    // 0x6cb054: EnterFrame
    //     0x6cb054: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb058: mov             fp, SP
    // 0x6cb05c: AllocStack(0x10)
    //     0x6cb05c: sub             SP, SP, #0x10
    // 0x6cb060: CheckStackOverflow
    //     0x6cb060: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb064: cmp             SP, x16
    //     0x6cb068: b.ls            #0x6cb210
    // 0x6cb06c: ldr             x0, [fp, #0x10]
    // 0x6cb070: LoadField: r1 = r0->field_1b
    //     0x6cb070: ldur            w1, [x0, #0x1b]
    // 0x6cb074: DecompressPointer r1
    //     0x6cb074: add             x1, x1, HEAP, lsl #32
    // 0x6cb078: stur            x1, [fp, #-0x10]
    // 0x6cb07c: LoadField: r2 = r0->field_1f
    //     0x6cb07c: ldur            w2, [x0, #0x1f]
    // 0x6cb080: DecompressPointer r2
    //     0x6cb080: add             x2, x2, HEAP, lsl #32
    // 0x6cb084: stur            x2, [fp, #-8]
    // 0x6cb088: cmp             w1, w2
    // 0x6cb08c: b.eq            #0x6cb0cc
    // 0x6cb090: r16 = Color
    //     0x6cb090: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb094: ldr             x16, [x16, #0xf18]
    // 0x6cb098: r30 = Color
    //     0x6cb098: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb09c: ldr             lr, [lr, #0xf18]
    // 0x6cb0a0: stp             lr, x16, [SP, #-0x10]!
    // 0x6cb0a4: r0 = ==()
    //     0x6cb0a4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cb0a8: add             SP, SP, #0x10
    // 0x6cb0ac: tbnz            w0, #4, #0x6cb180
    // 0x6cb0b0: ldur            x0, [fp, #-0x10]
    // 0x6cb0b4: ldur            x1, [fp, #-8]
    // 0x6cb0b8: LoadField: r2 = r1->field_7
    //     0x6cb0b8: ldur            x2, [x1, #7]
    // 0x6cb0bc: LoadField: r1 = r0->field_7
    //     0x6cb0bc: ldur            x1, [x0, #7]
    // 0x6cb0c0: cmp             x2, x1
    // 0x6cb0c4: b.ne            #0x6cb180
    // 0x6cb0c8: ldr             x0, [fp, #0x10]
    // 0x6cb0cc: LoadField: r1 = r0->field_2b
    //     0x6cb0cc: ldur            w1, [x0, #0x2b]
    // 0x6cb0d0: DecompressPointer r1
    //     0x6cb0d0: add             x1, x1, HEAP, lsl #32
    // 0x6cb0d4: stur            x1, [fp, #-0x10]
    // 0x6cb0d8: LoadField: r2 = r0->field_2f
    //     0x6cb0d8: ldur            w2, [x0, #0x2f]
    // 0x6cb0dc: DecompressPointer r2
    //     0x6cb0dc: add             x2, x2, HEAP, lsl #32
    // 0x6cb0e0: stur            x2, [fp, #-8]
    // 0x6cb0e4: cmp             w1, w2
    // 0x6cb0e8: b.eq            #0x6cb128
    // 0x6cb0ec: r16 = Color
    //     0x6cb0ec: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb0f0: ldr             x16, [x16, #0xf18]
    // 0x6cb0f4: r30 = Color
    //     0x6cb0f4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb0f8: ldr             lr, [lr, #0xf18]
    // 0x6cb0fc: stp             lr, x16, [SP, #-0x10]!
    // 0x6cb100: r0 = ==()
    //     0x6cb100: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cb104: add             SP, SP, #0x10
    // 0x6cb108: tbnz            w0, #4, #0x6cb180
    // 0x6cb10c: ldur            x0, [fp, #-0x10]
    // 0x6cb110: ldur            x1, [fp, #-8]
    // 0x6cb114: LoadField: r2 = r1->field_7
    //     0x6cb114: ldur            x2, [x1, #7]
    // 0x6cb118: LoadField: r1 = r0->field_7
    //     0x6cb118: ldur            x1, [x0, #7]
    // 0x6cb11c: cmp             x2, x1
    // 0x6cb120: b.ne            #0x6cb180
    // 0x6cb124: ldr             x0, [fp, #0x10]
    // 0x6cb128: LoadField: r1 = r0->field_23
    //     0x6cb128: ldur            w1, [x0, #0x23]
    // 0x6cb12c: DecompressPointer r1
    //     0x6cb12c: add             x1, x1, HEAP, lsl #32
    // 0x6cb130: stur            x1, [fp, #-0x10]
    // 0x6cb134: LoadField: r2 = r0->field_27
    //     0x6cb134: ldur            w2, [x0, #0x27]
    // 0x6cb138: DecompressPointer r2
    //     0x6cb138: add             x2, x2, HEAP, lsl #32
    // 0x6cb13c: stur            x2, [fp, #-8]
    // 0x6cb140: cmp             w1, w2
    // 0x6cb144: b.eq            #0x6cb18c
    // 0x6cb148: r16 = Color
    //     0x6cb148: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb14c: ldr             x16, [x16, #0xf18]
    // 0x6cb150: r30 = Color
    //     0x6cb150: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb154: ldr             lr, [lr, #0xf18]
    // 0x6cb158: stp             lr, x16, [SP, #-0x10]!
    // 0x6cb15c: r0 = ==()
    //     0x6cb15c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cb160: add             SP, SP, #0x10
    // 0x6cb164: tbnz            w0, #4, #0x6cb180
    // 0x6cb168: ldur            x0, [fp, #-0x10]
    // 0x6cb16c: ldur            x1, [fp, #-8]
    // 0x6cb170: LoadField: r2 = r1->field_7
    //     0x6cb170: ldur            x2, [x1, #7]
    // 0x6cb174: LoadField: r1 = r0->field_7
    //     0x6cb174: ldur            x1, [x0, #7]
    // 0x6cb178: cmp             x2, x1
    // 0x6cb17c: b.eq            #0x6cb188
    // 0x6cb180: r0 = true
    //     0x6cb180: add             x0, NULL, #0x20  ; true
    // 0x6cb184: b               #0x6cb204
    // 0x6cb188: ldr             x0, [fp, #0x10]
    // 0x6cb18c: LoadField: r1 = r0->field_33
    //     0x6cb18c: ldur            w1, [x0, #0x33]
    // 0x6cb190: DecompressPointer r1
    //     0x6cb190: add             x1, x1, HEAP, lsl #32
    // 0x6cb194: stur            x1, [fp, #-0x10]
    // 0x6cb198: LoadField: r2 = r0->field_37
    //     0x6cb198: ldur            w2, [x0, #0x37]
    // 0x6cb19c: DecompressPointer r2
    //     0x6cb19c: add             x2, x2, HEAP, lsl #32
    // 0x6cb1a0: stur            x2, [fp, #-8]
    // 0x6cb1a4: cmp             w1, w2
    // 0x6cb1a8: b.ne            #0x6cb1b4
    // 0x6cb1ac: r1 = true
    //     0x6cb1ac: add             x1, NULL, #0x20  ; true
    // 0x6cb1b0: b               #0x6cb1fc
    // 0x6cb1b4: r16 = Color
    //     0x6cb1b4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb1b8: ldr             x16, [x16, #0xf18]
    // 0x6cb1bc: r30 = Color
    //     0x6cb1bc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0x6cb1c0: ldr             lr, [lr, #0xf18]
    // 0x6cb1c4: stp             lr, x16, [SP, #-0x10]!
    // 0x6cb1c8: r0 = ==()
    //     0x6cb1c8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x6cb1cc: add             SP, SP, #0x10
    // 0x6cb1d0: tbz             w0, #4, #0x6cb1dc
    // 0x6cb1d4: r1 = false
    //     0x6cb1d4: add             x1, NULL, #0x30  ; false
    // 0x6cb1d8: b               #0x6cb1fc
    // 0x6cb1dc: ldur            x1, [fp, #-0x10]
    // 0x6cb1e0: ldur            x2, [fp, #-8]
    // 0x6cb1e4: LoadField: r3 = r2->field_7
    //     0x6cb1e4: ldur            x3, [x2, #7]
    // 0x6cb1e8: LoadField: r2 = r1->field_7
    //     0x6cb1e8: ldur            x2, [x1, #7]
    // 0x6cb1ec: cmp             x3, x2
    // 0x6cb1f0: r16 = true
    //     0x6cb1f0: add             x16, NULL, #0x20  ; true
    // 0x6cb1f4: r17 = false
    //     0x6cb1f4: add             x17, NULL, #0x30  ; false
    // 0x6cb1f8: csel            x1, x16, x17, eq
    // 0x6cb1fc: eor             x2, x1, #0x10
    // 0x6cb200: mov             x0, x2
    // 0x6cb204: LeaveFrame
    //     0x6cb204: mov             SP, fp
    //     0x6cb208: ldp             fp, lr, [SP], #0x10
    // 0x6cb20c: ret
    //     0x6cb20c: ret             
    // 0x6cb210: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb210: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb214: b               #0x6cb06c
  }
  static _ maybeResolve(/* No info */) {
    // ** addr: 0x83fef4, size: 0x6c
    // 0x83fef4: EnterFrame
    //     0x83fef4: stp             fp, lr, [SP, #-0x10]!
    //     0x83fef8: mov             fp, SP
    // 0x83fefc: CheckStackOverflow
    //     0x83fefc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83ff00: cmp             SP, x16
    //     0x83ff04: b.ls            #0x83ff58
    // 0x83ff08: ldr             x0, [fp, #0x18]
    // 0x83ff0c: cmp             w0, NULL
    // 0x83ff10: b.ne            #0x83ff24
    // 0x83ff14: r0 = Null
    //     0x83ff14: mov             x0, NULL
    // 0x83ff18: LeaveFrame
    //     0x83ff18: mov             SP, fp
    //     0x83ff1c: ldp             fp, lr, [SP], #0x10
    // 0x83ff20: ret
    //     0x83ff20: ret             
    // 0x83ff24: r1 = LoadClassIdInstr(r0)
    //     0x83ff24: ldur            x1, [x0, #-1]
    //     0x83ff28: ubfx            x1, x1, #0xc, #0x14
    // 0x83ff2c: lsl             x1, x1, #1
    // 0x83ff30: r17 = 10128
    //     0x83ff30: mov             x17, #0x2790
    // 0x83ff34: cmp             w1, w17
    // 0x83ff38: b.ne            #0x83ff4c
    // 0x83ff3c: ldr             x16, [fp, #0x10]
    // 0x83ff40: stp             x16, x0, [SP, #-0x10]!
    // 0x83ff44: r0 = resolveFrom()
    //     0x83ff44: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x83ff48: add             SP, SP, #0x10
    // 0x83ff4c: LeaveFrame
    //     0x83ff4c: mov             SP, fp
    //     0x83ff50: ldp             fp, lr, [SP], #0x10
    // 0x83ff54: ret
    //     0x83ff54: ret             
    // 0x83ff58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ff58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83ff5c: b               #0x83ff08
  }
  _ toString(/* No info */) {
    // ** addr: 0xabeed4, size: 0xcd8
    // 0xabeed4: EnterFrame
    //     0xabeed4: stp             fp, lr, [SP, #-0x10]!
    //     0xabeed8: mov             fp, SP
    // 0xabeedc: AllocStack(0x28)
    //     0xabeedc: sub             SP, SP, #0x28
    // 0xabeee0: SetupParameters(CupertinoDynamicColor this /* r1, fp-0x18 */)
    //     0xabeee0: mov             x0, x4
    //     0xabeee4: ldur            w1, [x0, #0x13]
    //     0xabeee8: add             x1, x1, HEAP, lsl #32
    //     0xabeeec: sub             x0, x1, #2
    //     0xabeef0: add             x1, fp, w0, sxtw #2
    //     0xabeef4: ldr             x1, [x1, #0x10]
    //     0xabeef8: stur            x1, [fp, #-0x18]
    // 0xabeefc: CheckStackOverflow
    //     0xabeefc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xabef00: cmp             SP, x16
    //     0xabef04: b.ls            #0xabfb88
    // 0xabef08: LoadField: r0 = r1->field_1b
    //     0xabef08: ldur            w0, [x1, #0x1b]
    // 0xabef0c: DecompressPointer r0
    //     0xabef0c: add             x0, x0, HEAP, lsl #32
    // 0xabef10: stur            x0, [fp, #-0x10]
    // 0xabef14: LoadField: r2 = r1->field_f
    //     0xabef14: ldur            w2, [x1, #0xf]
    // 0xabef18: DecompressPointer r2
    //     0xabef18: add             x2, x2, HEAP, lsl #32
    // 0xabef1c: stur            x2, [fp, #-8]
    // 0xabef20: cmp             w0, w2
    // 0xabef24: b.ne            #0xabef30
    // 0xabef28: mov             x3, x2
    // 0xabef2c: b               #0xabef74
    // 0xabef30: r16 = Color
    //     0xabef30: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabef34: ldr             x16, [x16, #0xf18]
    // 0xabef38: r30 = Color
    //     0xabef38: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabef3c: ldr             lr, [lr, #0xf18]
    // 0xabef40: stp             lr, x16, [SP, #-0x10]!
    // 0xabef44: r0 = ==()
    //     0xabef44: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabef48: add             SP, SP, #0x10
    // 0xabef4c: tbz             w0, #4, #0xabef5c
    // 0xabef50: ldur            x0, [fp, #-0x10]
    // 0xabef54: ldur            x3, [fp, #-8]
    // 0xabef58: b               #0xabef7c
    // 0xabef5c: ldur            x0, [fp, #-0x10]
    // 0xabef60: ldur            x3, [fp, #-8]
    // 0xabef64: LoadField: r1 = r3->field_7
    //     0xabef64: ldur            x1, [x3, #7]
    // 0xabef68: LoadField: r2 = r0->field_7
    //     0xabef68: ldur            x2, [x0, #7]
    // 0xabef6c: cmp             x1, x2
    // 0xabef70: b.ne            #0xabef7c
    // 0xabef74: r4 = "*"
    //     0xabef74: ldr             x4, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabef78: b               #0xabef80
    // 0xabef7c: r4 = ""
    //     0xabef7c: ldr             x4, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabef80: stur            x4, [fp, #-0x20]
    // 0xabef84: r1 = Null
    //     0xabef84: mov             x1, NULL
    // 0xabef88: r2 = 10
    //     0xabef88: mov             x2, #0xa
    // 0xabef8c: r0 = AllocateArray()
    //     0xabef8c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabef90: mov             x1, x0
    // 0xabef94: ldur            x0, [fp, #-0x20]
    // 0xabef98: StoreField: r1->field_f = r0
    //     0xabef98: stur            w0, [x1, #0xf]
    // 0xabef9c: r17 = "color"
    //     0xabef9c: add             x17, PP, #0xd, lsl #12  ; [pp+0xdae8] "color"
    //     0xabefa0: ldr             x17, [x17, #0xae8]
    // 0xabefa4: StoreField: r1->field_13 = r17
    //     0xabefa4: stur            w17, [x1, #0x13]
    // 0xabefa8: r17 = " = "
    //     0xabefa8: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabefac: ldr             x17, [x17, #0x800]
    // 0xabefb0: StoreField: r1->field_17 = r17
    //     0xabefb0: stur            w17, [x1, #0x17]
    // 0xabefb4: ldur            x2, [fp, #-0x10]
    // 0xabefb8: StoreField: r1->field_1b = r2
    //     0xabefb8: stur            w2, [x1, #0x1b]
    // 0xabefbc: StoreField: r1->field_1f = r0
    //     0xabefbc: stur            w0, [x1, #0x1f]
    // 0xabefc0: SaveReg r1
    //     0xabefc0: str             x1, [SP, #-8]!
    // 0xabefc4: r0 = _interpolate()
    //     0xabefc4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabefc8: add             SP, SP, #8
    // 0xabefcc: r1 = Null
    //     0xabefcc: mov             x1, NULL
    // 0xabefd0: r2 = 2
    //     0xabefd0: mov             x2, #2
    // 0xabefd4: stur            x0, [fp, #-0x10]
    // 0xabefd8: r0 = AllocateArray()
    //     0xabefd8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabefdc: mov             x2, x0
    // 0xabefe0: ldur            x0, [fp, #-0x10]
    // 0xabefe4: stur            x2, [fp, #-0x20]
    // 0xabefe8: StoreField: r2->field_f = r0
    //     0xabefe8: stur            w0, [x2, #0xf]
    // 0xabefec: r1 = <String>
    //     0xabefec: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xabeff0: r0 = AllocateGrowableArray()
    //     0xabeff0: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0xabeff4: mov             x1, x0
    // 0xabeff8: ldur            x0, [fp, #-0x20]
    // 0xabeffc: stur            x1, [fp, #-0x10]
    // 0xabf000: StoreField: r1->field_f = r0
    //     0xabf000: stur            w0, [x1, #0xf]
    // 0xabf004: r0 = 2
    //     0xabf004: mov             x0, #2
    // 0xabf008: StoreField: r1->field_b = r0
    //     0xabf008: stur            w0, [x1, #0xb]
    // 0xabf00c: ldur            x16, [fp, #-0x18]
    // 0xabf010: SaveReg r16
    //     0xabf010: str             x16, [SP, #-8]!
    // 0xabf014: r0 = _isPlatformBrightnessDependent()
    //     0xabf014: bl              #0x6cb054  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isPlatformBrightnessDependent
    // 0xabf018: add             SP, SP, #8
    // 0xabf01c: tbnz            w0, #4, #0xabf17c
    // 0xabf020: ldur            x1, [fp, #-0x18]
    // 0xabf024: ldur            x0, [fp, #-8]
    // 0xabf028: LoadField: r2 = r1->field_1f
    //     0xabf028: ldur            w2, [x1, #0x1f]
    // 0xabf02c: DecompressPointer r2
    //     0xabf02c: add             x2, x2, HEAP, lsl #32
    // 0xabf030: stur            x2, [fp, #-0x20]
    // 0xabf034: cmp             w2, w0
    // 0xabf038: b.ne            #0xabf044
    // 0xabf03c: mov             x3, x2
    // 0xabf040: b               #0xabf088
    // 0xabf044: r16 = Color
    //     0xabf044: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf048: ldr             x16, [x16, #0xf18]
    // 0xabf04c: r30 = Color
    //     0xabf04c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf050: ldr             lr, [lr, #0xf18]
    // 0xabf054: stp             lr, x16, [SP, #-0x10]!
    // 0xabf058: r0 = ==()
    //     0xabf058: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf05c: add             SP, SP, #0x10
    // 0xabf060: tbz             w0, #4, #0xabf070
    // 0xabf064: ldur            x3, [fp, #-0x20]
    // 0xabf068: ldur            x0, [fp, #-8]
    // 0xabf06c: b               #0xabf090
    // 0xabf070: ldur            x3, [fp, #-0x20]
    // 0xabf074: ldur            x0, [fp, #-8]
    // 0xabf078: LoadField: r1 = r0->field_7
    //     0xabf078: ldur            x1, [x0, #7]
    // 0xabf07c: LoadField: r2 = r3->field_7
    //     0xabf07c: ldur            x2, [x3, #7]
    // 0xabf080: cmp             x1, x2
    // 0xabf084: b.ne            #0xabf090
    // 0xabf088: r5 = "*"
    //     0xabf088: ldr             x5, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf08c: b               #0xabf094
    // 0xabf090: r5 = ""
    //     0xabf090: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf094: ldur            x4, [fp, #-0x10]
    // 0xabf098: stur            x5, [fp, #-0x28]
    // 0xabf09c: r1 = Null
    //     0xabf09c: mov             x1, NULL
    // 0xabf0a0: r2 = 10
    //     0xabf0a0: mov             x2, #0xa
    // 0xabf0a4: r0 = AllocateArray()
    //     0xabf0a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf0a8: mov             x1, x0
    // 0xabf0ac: ldur            x0, [fp, #-0x28]
    // 0xabf0b0: StoreField: r1->field_f = r0
    //     0xabf0b0: stur            w0, [x1, #0xf]
    // 0xabf0b4: r17 = "darkColor"
    //     0xabf0b4: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebb8] "darkColor"
    //     0xabf0b8: ldr             x17, [x17, #0xbb8]
    // 0xabf0bc: StoreField: r1->field_13 = r17
    //     0xabf0bc: stur            w17, [x1, #0x13]
    // 0xabf0c0: r17 = " = "
    //     0xabf0c0: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf0c4: ldr             x17, [x17, #0x800]
    // 0xabf0c8: StoreField: r1->field_17 = r17
    //     0xabf0c8: stur            w17, [x1, #0x17]
    // 0xabf0cc: ldur            x2, [fp, #-0x20]
    // 0xabf0d0: StoreField: r1->field_1b = r2
    //     0xabf0d0: stur            w2, [x1, #0x1b]
    // 0xabf0d4: StoreField: r1->field_1f = r0
    //     0xabf0d4: stur            w0, [x1, #0x1f]
    // 0xabf0d8: SaveReg r1
    //     0xabf0d8: str             x1, [SP, #-8]!
    // 0xabf0dc: r0 = _interpolate()
    //     0xabf0dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabf0e0: add             SP, SP, #8
    // 0xabf0e4: mov             x1, x0
    // 0xabf0e8: ldur            x0, [fp, #-0x10]
    // 0xabf0ec: stur            x1, [fp, #-0x28]
    // 0xabf0f0: LoadField: r2 = r0->field_b
    //     0xabf0f0: ldur            w2, [x0, #0xb]
    // 0xabf0f4: DecompressPointer r2
    //     0xabf0f4: add             x2, x2, HEAP, lsl #32
    // 0xabf0f8: stur            x2, [fp, #-0x20]
    // 0xabf0fc: LoadField: r3 = r0->field_f
    //     0xabf0fc: ldur            w3, [x0, #0xf]
    // 0xabf100: DecompressPointer r3
    //     0xabf100: add             x3, x3, HEAP, lsl #32
    // 0xabf104: LoadField: r4 = r3->field_b
    //     0xabf104: ldur            w4, [x3, #0xb]
    // 0xabf108: DecompressPointer r4
    //     0xabf108: add             x4, x4, HEAP, lsl #32
    // 0xabf10c: cmp             w2, w4
    // 0xabf110: b.ne            #0xabf120
    // 0xabf114: SaveReg r0
    //     0xabf114: str             x0, [SP, #-8]!
    // 0xabf118: r0 = _growToNextCapacity()
    //     0xabf118: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabf11c: add             SP, SP, #8
    // 0xabf120: ldur            x0, [fp, #-0x20]
    // 0xabf124: ldur            x2, [fp, #-0x10]
    // 0xabf128: r3 = LoadInt32Instr(r0)
    //     0xabf128: sbfx            x3, x0, #1, #0x1f
    // 0xabf12c: add             x0, x3, #1
    // 0xabf130: lsl             x1, x0, #1
    // 0xabf134: StoreField: r2->field_b = r1
    //     0xabf134: stur            w1, [x2, #0xb]
    // 0xabf138: mov             x1, x3
    // 0xabf13c: cmp             x1, x0
    // 0xabf140: b.hs            #0xabfb90
    // 0xabf144: LoadField: r1 = r2->field_f
    //     0xabf144: ldur            w1, [x2, #0xf]
    // 0xabf148: DecompressPointer r1
    //     0xabf148: add             x1, x1, HEAP, lsl #32
    // 0xabf14c: ldur            x0, [fp, #-0x28]
    // 0xabf150: ArrayStore: r1[r3] = r0  ; List_4
    //     0xabf150: add             x25, x1, x3, lsl #2
    //     0xabf154: add             x25, x25, #0xf
    //     0xabf158: str             w0, [x25]
    //     0xabf15c: tbz             w0, #0, #0xabf178
    //     0xabf160: ldurb           w16, [x1, #-1]
    //     0xabf164: ldurb           w17, [x0, #-1]
    //     0xabf168: and             x16, x17, x16, lsr #2
    //     0xabf16c: tst             x16, HEAP, lsr #32
    //     0xabf170: b.eq            #0xabf178
    //     0xabf174: bl              #0xd67e5c
    // 0xabf178: b               #0xabf180
    // 0xabf17c: ldur            x2, [fp, #-0x10]
    // 0xabf180: ldur            x16, [fp, #-0x18]
    // 0xabf184: SaveReg r16
    //     0xabf184: str             x16, [SP, #-8]!
    // 0xabf188: r0 = _isHighContrastDependent()
    //     0xabf188: bl              #0x6cad94  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isHighContrastDependent
    // 0xabf18c: add             SP, SP, #8
    // 0xabf190: tbnz            w0, #4, #0xabf2f0
    // 0xabf194: ldur            x1, [fp, #-0x18]
    // 0xabf198: ldur            x0, [fp, #-8]
    // 0xabf19c: LoadField: r2 = r1->field_23
    //     0xabf19c: ldur            w2, [x1, #0x23]
    // 0xabf1a0: DecompressPointer r2
    //     0xabf1a0: add             x2, x2, HEAP, lsl #32
    // 0xabf1a4: stur            x2, [fp, #-0x20]
    // 0xabf1a8: cmp             w2, w0
    // 0xabf1ac: b.ne            #0xabf1b8
    // 0xabf1b0: mov             x3, x2
    // 0xabf1b4: b               #0xabf1fc
    // 0xabf1b8: r16 = Color
    //     0xabf1b8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf1bc: ldr             x16, [x16, #0xf18]
    // 0xabf1c0: r30 = Color
    //     0xabf1c0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf1c4: ldr             lr, [lr, #0xf18]
    // 0xabf1c8: stp             lr, x16, [SP, #-0x10]!
    // 0xabf1cc: r0 = ==()
    //     0xabf1cc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf1d0: add             SP, SP, #0x10
    // 0xabf1d4: tbz             w0, #4, #0xabf1e4
    // 0xabf1d8: ldur            x3, [fp, #-0x20]
    // 0xabf1dc: ldur            x0, [fp, #-8]
    // 0xabf1e0: b               #0xabf204
    // 0xabf1e4: ldur            x3, [fp, #-0x20]
    // 0xabf1e8: ldur            x0, [fp, #-8]
    // 0xabf1ec: LoadField: r1 = r0->field_7
    //     0xabf1ec: ldur            x1, [x0, #7]
    // 0xabf1f0: LoadField: r2 = r3->field_7
    //     0xabf1f0: ldur            x2, [x3, #7]
    // 0xabf1f4: cmp             x1, x2
    // 0xabf1f8: b.ne            #0xabf204
    // 0xabf1fc: r5 = "*"
    //     0xabf1fc: ldr             x5, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf200: b               #0xabf208
    // 0xabf204: r5 = ""
    //     0xabf204: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf208: ldur            x4, [fp, #-0x10]
    // 0xabf20c: stur            x5, [fp, #-0x28]
    // 0xabf210: r1 = Null
    //     0xabf210: mov             x1, NULL
    // 0xabf214: r2 = 10
    //     0xabf214: mov             x2, #0xa
    // 0xabf218: r0 = AllocateArray()
    //     0xabf218: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf21c: mov             x1, x0
    // 0xabf220: ldur            x0, [fp, #-0x28]
    // 0xabf224: StoreField: r1->field_f = r0
    //     0xabf224: stur            w0, [x1, #0xf]
    // 0xabf228: r17 = "highContrastColor"
    //     0xabf228: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebc0] "highContrastColor"
    //     0xabf22c: ldr             x17, [x17, #0xbc0]
    // 0xabf230: StoreField: r1->field_13 = r17
    //     0xabf230: stur            w17, [x1, #0x13]
    // 0xabf234: r17 = " = "
    //     0xabf234: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf238: ldr             x17, [x17, #0x800]
    // 0xabf23c: StoreField: r1->field_17 = r17
    //     0xabf23c: stur            w17, [x1, #0x17]
    // 0xabf240: ldur            x2, [fp, #-0x20]
    // 0xabf244: StoreField: r1->field_1b = r2
    //     0xabf244: stur            w2, [x1, #0x1b]
    // 0xabf248: StoreField: r1->field_1f = r0
    //     0xabf248: stur            w0, [x1, #0x1f]
    // 0xabf24c: SaveReg r1
    //     0xabf24c: str             x1, [SP, #-8]!
    // 0xabf250: r0 = _interpolate()
    //     0xabf250: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabf254: add             SP, SP, #8
    // 0xabf258: mov             x1, x0
    // 0xabf25c: ldur            x0, [fp, #-0x10]
    // 0xabf260: stur            x1, [fp, #-0x28]
    // 0xabf264: LoadField: r2 = r0->field_b
    //     0xabf264: ldur            w2, [x0, #0xb]
    // 0xabf268: DecompressPointer r2
    //     0xabf268: add             x2, x2, HEAP, lsl #32
    // 0xabf26c: stur            x2, [fp, #-0x20]
    // 0xabf270: LoadField: r3 = r0->field_f
    //     0xabf270: ldur            w3, [x0, #0xf]
    // 0xabf274: DecompressPointer r3
    //     0xabf274: add             x3, x3, HEAP, lsl #32
    // 0xabf278: LoadField: r4 = r3->field_b
    //     0xabf278: ldur            w4, [x3, #0xb]
    // 0xabf27c: DecompressPointer r4
    //     0xabf27c: add             x4, x4, HEAP, lsl #32
    // 0xabf280: cmp             w2, w4
    // 0xabf284: b.ne            #0xabf294
    // 0xabf288: SaveReg r0
    //     0xabf288: str             x0, [SP, #-8]!
    // 0xabf28c: r0 = _growToNextCapacity()
    //     0xabf28c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabf290: add             SP, SP, #8
    // 0xabf294: ldur            x0, [fp, #-0x20]
    // 0xabf298: ldur            x2, [fp, #-0x10]
    // 0xabf29c: r3 = LoadInt32Instr(r0)
    //     0xabf29c: sbfx            x3, x0, #1, #0x1f
    // 0xabf2a0: add             x0, x3, #1
    // 0xabf2a4: lsl             x1, x0, #1
    // 0xabf2a8: StoreField: r2->field_b = r1
    //     0xabf2a8: stur            w1, [x2, #0xb]
    // 0xabf2ac: mov             x1, x3
    // 0xabf2b0: cmp             x1, x0
    // 0xabf2b4: b.hs            #0xabfb94
    // 0xabf2b8: LoadField: r1 = r2->field_f
    //     0xabf2b8: ldur            w1, [x2, #0xf]
    // 0xabf2bc: DecompressPointer r1
    //     0xabf2bc: add             x1, x1, HEAP, lsl #32
    // 0xabf2c0: ldur            x0, [fp, #-0x28]
    // 0xabf2c4: ArrayStore: r1[r3] = r0  ; List_4
    //     0xabf2c4: add             x25, x1, x3, lsl #2
    //     0xabf2c8: add             x25, x25, #0xf
    //     0xabf2cc: str             w0, [x25]
    //     0xabf2d0: tbz             w0, #0, #0xabf2ec
    //     0xabf2d4: ldurb           w16, [x1, #-1]
    //     0xabf2d8: ldurb           w17, [x0, #-1]
    //     0xabf2dc: and             x16, x17, x16, lsr #2
    //     0xabf2e0: tst             x16, HEAP, lsr #32
    //     0xabf2e4: b.eq            #0xabf2ec
    //     0xabf2e8: bl              #0xd67e5c
    // 0xabf2ec: b               #0xabf2f4
    // 0xabf2f0: ldur            x2, [fp, #-0x10]
    // 0xabf2f4: ldur            x16, [fp, #-0x18]
    // 0xabf2f8: SaveReg r16
    //     0xabf2f8: str             x16, [SP, #-8]!
    // 0xabf2fc: r0 = _isPlatformBrightnessDependent()
    //     0xabf2fc: bl              #0x6cb054  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isPlatformBrightnessDependent
    // 0xabf300: add             SP, SP, #8
    // 0xabf304: tbnz            w0, #4, #0xabf480
    // 0xabf308: ldur            x16, [fp, #-0x18]
    // 0xabf30c: SaveReg r16
    //     0xabf30c: str             x16, [SP, #-8]!
    // 0xabf310: r0 = _isHighContrastDependent()
    //     0xabf310: bl              #0x6cad94  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isHighContrastDependent
    // 0xabf314: add             SP, SP, #8
    // 0xabf318: tbnz            w0, #4, #0xabf478
    // 0xabf31c: ldur            x1, [fp, #-0x18]
    // 0xabf320: ldur            x0, [fp, #-8]
    // 0xabf324: LoadField: r2 = r1->field_27
    //     0xabf324: ldur            w2, [x1, #0x27]
    // 0xabf328: DecompressPointer r2
    //     0xabf328: add             x2, x2, HEAP, lsl #32
    // 0xabf32c: stur            x2, [fp, #-0x20]
    // 0xabf330: cmp             w2, w0
    // 0xabf334: b.ne            #0xabf340
    // 0xabf338: mov             x3, x2
    // 0xabf33c: b               #0xabf384
    // 0xabf340: r16 = Color
    //     0xabf340: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf344: ldr             x16, [x16, #0xf18]
    // 0xabf348: r30 = Color
    //     0xabf348: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf34c: ldr             lr, [lr, #0xf18]
    // 0xabf350: stp             lr, x16, [SP, #-0x10]!
    // 0xabf354: r0 = ==()
    //     0xabf354: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf358: add             SP, SP, #0x10
    // 0xabf35c: tbz             w0, #4, #0xabf36c
    // 0xabf360: ldur            x3, [fp, #-0x20]
    // 0xabf364: ldur            x0, [fp, #-8]
    // 0xabf368: b               #0xabf38c
    // 0xabf36c: ldur            x3, [fp, #-0x20]
    // 0xabf370: ldur            x0, [fp, #-8]
    // 0xabf374: LoadField: r1 = r0->field_7
    //     0xabf374: ldur            x1, [x0, #7]
    // 0xabf378: LoadField: r2 = r3->field_7
    //     0xabf378: ldur            x2, [x3, #7]
    // 0xabf37c: cmp             x1, x2
    // 0xabf380: b.ne            #0xabf38c
    // 0xabf384: r5 = "*"
    //     0xabf384: ldr             x5, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf388: b               #0xabf390
    // 0xabf38c: r5 = ""
    //     0xabf38c: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf390: ldur            x4, [fp, #-0x10]
    // 0xabf394: stur            x5, [fp, #-0x28]
    // 0xabf398: r1 = Null
    //     0xabf398: mov             x1, NULL
    // 0xabf39c: r2 = 10
    //     0xabf39c: mov             x2, #0xa
    // 0xabf3a0: r0 = AllocateArray()
    //     0xabf3a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf3a4: mov             x1, x0
    // 0xabf3a8: ldur            x0, [fp, #-0x28]
    // 0xabf3ac: StoreField: r1->field_f = r0
    //     0xabf3ac: stur            w0, [x1, #0xf]
    // 0xabf3b0: r17 = "darkHighContrastColor"
    //     0xabf3b0: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebc8] "darkHighContrastColor"
    //     0xabf3b4: ldr             x17, [x17, #0xbc8]
    // 0xabf3b8: StoreField: r1->field_13 = r17
    //     0xabf3b8: stur            w17, [x1, #0x13]
    // 0xabf3bc: r17 = " = "
    //     0xabf3bc: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf3c0: ldr             x17, [x17, #0x800]
    // 0xabf3c4: StoreField: r1->field_17 = r17
    //     0xabf3c4: stur            w17, [x1, #0x17]
    // 0xabf3c8: ldur            x2, [fp, #-0x20]
    // 0xabf3cc: StoreField: r1->field_1b = r2
    //     0xabf3cc: stur            w2, [x1, #0x1b]
    // 0xabf3d0: StoreField: r1->field_1f = r0
    //     0xabf3d0: stur            w0, [x1, #0x1f]
    // 0xabf3d4: SaveReg r1
    //     0xabf3d4: str             x1, [SP, #-8]!
    // 0xabf3d8: r0 = _interpolate()
    //     0xabf3d8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabf3dc: add             SP, SP, #8
    // 0xabf3e0: mov             x1, x0
    // 0xabf3e4: ldur            x0, [fp, #-0x10]
    // 0xabf3e8: stur            x1, [fp, #-0x28]
    // 0xabf3ec: LoadField: r2 = r0->field_b
    //     0xabf3ec: ldur            w2, [x0, #0xb]
    // 0xabf3f0: DecompressPointer r2
    //     0xabf3f0: add             x2, x2, HEAP, lsl #32
    // 0xabf3f4: stur            x2, [fp, #-0x20]
    // 0xabf3f8: LoadField: r3 = r0->field_f
    //     0xabf3f8: ldur            w3, [x0, #0xf]
    // 0xabf3fc: DecompressPointer r3
    //     0xabf3fc: add             x3, x3, HEAP, lsl #32
    // 0xabf400: LoadField: r4 = r3->field_b
    //     0xabf400: ldur            w4, [x3, #0xb]
    // 0xabf404: DecompressPointer r4
    //     0xabf404: add             x4, x4, HEAP, lsl #32
    // 0xabf408: cmp             w2, w4
    // 0xabf40c: b.ne            #0xabf41c
    // 0xabf410: SaveReg r0
    //     0xabf410: str             x0, [SP, #-8]!
    // 0xabf414: r0 = _growToNextCapacity()
    //     0xabf414: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabf418: add             SP, SP, #8
    // 0xabf41c: ldur            x0, [fp, #-0x20]
    // 0xabf420: ldur            x2, [fp, #-0x10]
    // 0xabf424: r3 = LoadInt32Instr(r0)
    //     0xabf424: sbfx            x3, x0, #1, #0x1f
    // 0xabf428: add             x0, x3, #1
    // 0xabf42c: lsl             x1, x0, #1
    // 0xabf430: StoreField: r2->field_b = r1
    //     0xabf430: stur            w1, [x2, #0xb]
    // 0xabf434: mov             x1, x3
    // 0xabf438: cmp             x1, x0
    // 0xabf43c: b.hs            #0xabfb98
    // 0xabf440: LoadField: r1 = r2->field_f
    //     0xabf440: ldur            w1, [x2, #0xf]
    // 0xabf444: DecompressPointer r1
    //     0xabf444: add             x1, x1, HEAP, lsl #32
    // 0xabf448: ldur            x0, [fp, #-0x28]
    // 0xabf44c: ArrayStore: r1[r3] = r0  ; List_4
    //     0xabf44c: add             x25, x1, x3, lsl #2
    //     0xabf450: add             x25, x25, #0xf
    //     0xabf454: str             w0, [x25]
    //     0xabf458: tbz             w0, #0, #0xabf474
    //     0xabf45c: ldurb           w16, [x1, #-1]
    //     0xabf460: ldurb           w17, [x0, #-1]
    //     0xabf464: and             x16, x17, x16, lsr #2
    //     0xabf468: tst             x16, HEAP, lsr #32
    //     0xabf46c: b.eq            #0xabf474
    //     0xabf470: bl              #0xd67e5c
    // 0xabf474: b               #0xabf484
    // 0xabf478: ldur            x2, [fp, #-0x10]
    // 0xabf47c: b               #0xabf484
    // 0xabf480: ldur            x2, [fp, #-0x10]
    // 0xabf484: ldur            x16, [fp, #-0x18]
    // 0xabf488: SaveReg r16
    //     0xabf488: str             x16, [SP, #-8]!
    // 0xabf48c: r0 = _isInterfaceElevationDependent()
    //     0xabf48c: bl              #0x6cabd0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isInterfaceElevationDependent
    // 0xabf490: add             SP, SP, #8
    // 0xabf494: tbnz            w0, #4, #0xabf5f4
    // 0xabf498: ldur            x1, [fp, #-0x18]
    // 0xabf49c: ldur            x0, [fp, #-8]
    // 0xabf4a0: LoadField: r2 = r1->field_2b
    //     0xabf4a0: ldur            w2, [x1, #0x2b]
    // 0xabf4a4: DecompressPointer r2
    //     0xabf4a4: add             x2, x2, HEAP, lsl #32
    // 0xabf4a8: stur            x2, [fp, #-0x20]
    // 0xabf4ac: cmp             w2, w0
    // 0xabf4b0: b.ne            #0xabf4bc
    // 0xabf4b4: mov             x3, x2
    // 0xabf4b8: b               #0xabf500
    // 0xabf4bc: r16 = Color
    //     0xabf4bc: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf4c0: ldr             x16, [x16, #0xf18]
    // 0xabf4c4: r30 = Color
    //     0xabf4c4: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf4c8: ldr             lr, [lr, #0xf18]
    // 0xabf4cc: stp             lr, x16, [SP, #-0x10]!
    // 0xabf4d0: r0 = ==()
    //     0xabf4d0: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf4d4: add             SP, SP, #0x10
    // 0xabf4d8: tbz             w0, #4, #0xabf4e8
    // 0xabf4dc: ldur            x3, [fp, #-0x20]
    // 0xabf4e0: ldur            x0, [fp, #-8]
    // 0xabf4e4: b               #0xabf508
    // 0xabf4e8: ldur            x3, [fp, #-0x20]
    // 0xabf4ec: ldur            x0, [fp, #-8]
    // 0xabf4f0: LoadField: r1 = r0->field_7
    //     0xabf4f0: ldur            x1, [x0, #7]
    // 0xabf4f4: LoadField: r2 = r3->field_7
    //     0xabf4f4: ldur            x2, [x3, #7]
    // 0xabf4f8: cmp             x1, x2
    // 0xabf4fc: b.ne            #0xabf508
    // 0xabf500: r5 = "*"
    //     0xabf500: ldr             x5, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf504: b               #0xabf50c
    // 0xabf508: r5 = ""
    //     0xabf508: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf50c: ldur            x4, [fp, #-0x10]
    // 0xabf510: stur            x5, [fp, #-0x28]
    // 0xabf514: r1 = Null
    //     0xabf514: mov             x1, NULL
    // 0xabf518: r2 = 10
    //     0xabf518: mov             x2, #0xa
    // 0xabf51c: r0 = AllocateArray()
    //     0xabf51c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf520: mov             x1, x0
    // 0xabf524: ldur            x0, [fp, #-0x28]
    // 0xabf528: StoreField: r1->field_f = r0
    //     0xabf528: stur            w0, [x1, #0xf]
    // 0xabf52c: r17 = "elevatedColor"
    //     0xabf52c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebd0] "elevatedColor"
    //     0xabf530: ldr             x17, [x17, #0xbd0]
    // 0xabf534: StoreField: r1->field_13 = r17
    //     0xabf534: stur            w17, [x1, #0x13]
    // 0xabf538: r17 = " = "
    //     0xabf538: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf53c: ldr             x17, [x17, #0x800]
    // 0xabf540: StoreField: r1->field_17 = r17
    //     0xabf540: stur            w17, [x1, #0x17]
    // 0xabf544: ldur            x2, [fp, #-0x20]
    // 0xabf548: StoreField: r1->field_1b = r2
    //     0xabf548: stur            w2, [x1, #0x1b]
    // 0xabf54c: StoreField: r1->field_1f = r0
    //     0xabf54c: stur            w0, [x1, #0x1f]
    // 0xabf550: SaveReg r1
    //     0xabf550: str             x1, [SP, #-8]!
    // 0xabf554: r0 = _interpolate()
    //     0xabf554: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabf558: add             SP, SP, #8
    // 0xabf55c: mov             x1, x0
    // 0xabf560: ldur            x0, [fp, #-0x10]
    // 0xabf564: stur            x1, [fp, #-0x28]
    // 0xabf568: LoadField: r2 = r0->field_b
    //     0xabf568: ldur            w2, [x0, #0xb]
    // 0xabf56c: DecompressPointer r2
    //     0xabf56c: add             x2, x2, HEAP, lsl #32
    // 0xabf570: stur            x2, [fp, #-0x20]
    // 0xabf574: LoadField: r3 = r0->field_f
    //     0xabf574: ldur            w3, [x0, #0xf]
    // 0xabf578: DecompressPointer r3
    //     0xabf578: add             x3, x3, HEAP, lsl #32
    // 0xabf57c: LoadField: r4 = r3->field_b
    //     0xabf57c: ldur            w4, [x3, #0xb]
    // 0xabf580: DecompressPointer r4
    //     0xabf580: add             x4, x4, HEAP, lsl #32
    // 0xabf584: cmp             w2, w4
    // 0xabf588: b.ne            #0xabf598
    // 0xabf58c: SaveReg r0
    //     0xabf58c: str             x0, [SP, #-8]!
    // 0xabf590: r0 = _growToNextCapacity()
    //     0xabf590: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabf594: add             SP, SP, #8
    // 0xabf598: ldur            x0, [fp, #-0x20]
    // 0xabf59c: ldur            x2, [fp, #-0x10]
    // 0xabf5a0: r3 = LoadInt32Instr(r0)
    //     0xabf5a0: sbfx            x3, x0, #1, #0x1f
    // 0xabf5a4: add             x0, x3, #1
    // 0xabf5a8: lsl             x1, x0, #1
    // 0xabf5ac: StoreField: r2->field_b = r1
    //     0xabf5ac: stur            w1, [x2, #0xb]
    // 0xabf5b0: mov             x1, x3
    // 0xabf5b4: cmp             x1, x0
    // 0xabf5b8: b.hs            #0xabfb9c
    // 0xabf5bc: LoadField: r1 = r2->field_f
    //     0xabf5bc: ldur            w1, [x2, #0xf]
    // 0xabf5c0: DecompressPointer r1
    //     0xabf5c0: add             x1, x1, HEAP, lsl #32
    // 0xabf5c4: ldur            x0, [fp, #-0x28]
    // 0xabf5c8: ArrayStore: r1[r3] = r0  ; List_4
    //     0xabf5c8: add             x25, x1, x3, lsl #2
    //     0xabf5cc: add             x25, x25, #0xf
    //     0xabf5d0: str             w0, [x25]
    //     0xabf5d4: tbz             w0, #0, #0xabf5f0
    //     0xabf5d8: ldurb           w16, [x1, #-1]
    //     0xabf5dc: ldurb           w17, [x0, #-1]
    //     0xabf5e0: and             x16, x17, x16, lsr #2
    //     0xabf5e4: tst             x16, HEAP, lsr #32
    //     0xabf5e8: b.eq            #0xabf5f0
    //     0xabf5ec: bl              #0xd67e5c
    // 0xabf5f0: b               #0xabf5f8
    // 0xabf5f4: ldur            x2, [fp, #-0x10]
    // 0xabf5f8: ldur            x16, [fp, #-0x18]
    // 0xabf5fc: SaveReg r16
    //     0xabf5fc: str             x16, [SP, #-8]!
    // 0xabf600: r0 = _isPlatformBrightnessDependent()
    //     0xabf600: bl              #0x6cb054  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isPlatformBrightnessDependent
    // 0xabf604: add             SP, SP, #8
    // 0xabf608: tbnz            w0, #4, #0xabf784
    // 0xabf60c: ldur            x16, [fp, #-0x18]
    // 0xabf610: SaveReg r16
    //     0xabf610: str             x16, [SP, #-8]!
    // 0xabf614: r0 = _isInterfaceElevationDependent()
    //     0xabf614: bl              #0x6cabd0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isInterfaceElevationDependent
    // 0xabf618: add             SP, SP, #8
    // 0xabf61c: tbnz            w0, #4, #0xabf77c
    // 0xabf620: ldur            x1, [fp, #-0x18]
    // 0xabf624: ldur            x0, [fp, #-8]
    // 0xabf628: LoadField: r2 = r1->field_2f
    //     0xabf628: ldur            w2, [x1, #0x2f]
    // 0xabf62c: DecompressPointer r2
    //     0xabf62c: add             x2, x2, HEAP, lsl #32
    // 0xabf630: stur            x2, [fp, #-0x20]
    // 0xabf634: cmp             w2, w0
    // 0xabf638: b.ne            #0xabf644
    // 0xabf63c: mov             x3, x2
    // 0xabf640: b               #0xabf688
    // 0xabf644: r16 = Color
    //     0xabf644: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf648: ldr             x16, [x16, #0xf18]
    // 0xabf64c: r30 = Color
    //     0xabf64c: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf650: ldr             lr, [lr, #0xf18]
    // 0xabf654: stp             lr, x16, [SP, #-0x10]!
    // 0xabf658: r0 = ==()
    //     0xabf658: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf65c: add             SP, SP, #0x10
    // 0xabf660: tbz             w0, #4, #0xabf670
    // 0xabf664: ldur            x3, [fp, #-0x20]
    // 0xabf668: ldur            x0, [fp, #-8]
    // 0xabf66c: b               #0xabf690
    // 0xabf670: ldur            x3, [fp, #-0x20]
    // 0xabf674: ldur            x0, [fp, #-8]
    // 0xabf678: LoadField: r1 = r0->field_7
    //     0xabf678: ldur            x1, [x0, #7]
    // 0xabf67c: LoadField: r2 = r3->field_7
    //     0xabf67c: ldur            x2, [x3, #7]
    // 0xabf680: cmp             x1, x2
    // 0xabf684: b.ne            #0xabf690
    // 0xabf688: r5 = "*"
    //     0xabf688: ldr             x5, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf68c: b               #0xabf694
    // 0xabf690: r5 = ""
    //     0xabf690: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf694: ldur            x4, [fp, #-0x10]
    // 0xabf698: stur            x5, [fp, #-0x28]
    // 0xabf69c: r1 = Null
    //     0xabf69c: mov             x1, NULL
    // 0xabf6a0: r2 = 10
    //     0xabf6a0: mov             x2, #0xa
    // 0xabf6a4: r0 = AllocateArray()
    //     0xabf6a4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf6a8: mov             x1, x0
    // 0xabf6ac: ldur            x0, [fp, #-0x28]
    // 0xabf6b0: StoreField: r1->field_f = r0
    //     0xabf6b0: stur            w0, [x1, #0xf]
    // 0xabf6b4: r17 = "darkElevatedColor"
    //     0xabf6b4: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebd8] "darkElevatedColor"
    //     0xabf6b8: ldr             x17, [x17, #0xbd8]
    // 0xabf6bc: StoreField: r1->field_13 = r17
    //     0xabf6bc: stur            w17, [x1, #0x13]
    // 0xabf6c0: r17 = " = "
    //     0xabf6c0: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf6c4: ldr             x17, [x17, #0x800]
    // 0xabf6c8: StoreField: r1->field_17 = r17
    //     0xabf6c8: stur            w17, [x1, #0x17]
    // 0xabf6cc: ldur            x2, [fp, #-0x20]
    // 0xabf6d0: StoreField: r1->field_1b = r2
    //     0xabf6d0: stur            w2, [x1, #0x1b]
    // 0xabf6d4: StoreField: r1->field_1f = r0
    //     0xabf6d4: stur            w0, [x1, #0x1f]
    // 0xabf6d8: SaveReg r1
    //     0xabf6d8: str             x1, [SP, #-8]!
    // 0xabf6dc: r0 = _interpolate()
    //     0xabf6dc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabf6e0: add             SP, SP, #8
    // 0xabf6e4: mov             x1, x0
    // 0xabf6e8: ldur            x0, [fp, #-0x10]
    // 0xabf6ec: stur            x1, [fp, #-0x28]
    // 0xabf6f0: LoadField: r2 = r0->field_b
    //     0xabf6f0: ldur            w2, [x0, #0xb]
    // 0xabf6f4: DecompressPointer r2
    //     0xabf6f4: add             x2, x2, HEAP, lsl #32
    // 0xabf6f8: stur            x2, [fp, #-0x20]
    // 0xabf6fc: LoadField: r3 = r0->field_f
    //     0xabf6fc: ldur            w3, [x0, #0xf]
    // 0xabf700: DecompressPointer r3
    //     0xabf700: add             x3, x3, HEAP, lsl #32
    // 0xabf704: LoadField: r4 = r3->field_b
    //     0xabf704: ldur            w4, [x3, #0xb]
    // 0xabf708: DecompressPointer r4
    //     0xabf708: add             x4, x4, HEAP, lsl #32
    // 0xabf70c: cmp             w2, w4
    // 0xabf710: b.ne            #0xabf720
    // 0xabf714: SaveReg r0
    //     0xabf714: str             x0, [SP, #-8]!
    // 0xabf718: r0 = _growToNextCapacity()
    //     0xabf718: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabf71c: add             SP, SP, #8
    // 0xabf720: ldur            x0, [fp, #-0x20]
    // 0xabf724: ldur            x2, [fp, #-0x10]
    // 0xabf728: r3 = LoadInt32Instr(r0)
    //     0xabf728: sbfx            x3, x0, #1, #0x1f
    // 0xabf72c: add             x0, x3, #1
    // 0xabf730: lsl             x1, x0, #1
    // 0xabf734: StoreField: r2->field_b = r1
    //     0xabf734: stur            w1, [x2, #0xb]
    // 0xabf738: mov             x1, x3
    // 0xabf73c: cmp             x1, x0
    // 0xabf740: b.hs            #0xabfba0
    // 0xabf744: LoadField: r1 = r2->field_f
    //     0xabf744: ldur            w1, [x2, #0xf]
    // 0xabf748: DecompressPointer r1
    //     0xabf748: add             x1, x1, HEAP, lsl #32
    // 0xabf74c: ldur            x0, [fp, #-0x28]
    // 0xabf750: ArrayStore: r1[r3] = r0  ; List_4
    //     0xabf750: add             x25, x1, x3, lsl #2
    //     0xabf754: add             x25, x25, #0xf
    //     0xabf758: str             w0, [x25]
    //     0xabf75c: tbz             w0, #0, #0xabf778
    //     0xabf760: ldurb           w16, [x1, #-1]
    //     0xabf764: ldurb           w17, [x0, #-1]
    //     0xabf768: and             x16, x17, x16, lsr #2
    //     0xabf76c: tst             x16, HEAP, lsr #32
    //     0xabf770: b.eq            #0xabf778
    //     0xabf774: bl              #0xd67e5c
    // 0xabf778: b               #0xabf788
    // 0xabf77c: ldur            x2, [fp, #-0x10]
    // 0xabf780: b               #0xabf788
    // 0xabf784: ldur            x2, [fp, #-0x10]
    // 0xabf788: ldur            x16, [fp, #-0x18]
    // 0xabf78c: SaveReg r16
    //     0xabf78c: str             x16, [SP, #-8]!
    // 0xabf790: r0 = _isHighContrastDependent()
    //     0xabf790: bl              #0x6cad94  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isHighContrastDependent
    // 0xabf794: add             SP, SP, #8
    // 0xabf798: tbnz            w0, #4, #0xabf914
    // 0xabf79c: ldur            x16, [fp, #-0x18]
    // 0xabf7a0: SaveReg r16
    //     0xabf7a0: str             x16, [SP, #-8]!
    // 0xabf7a4: r0 = _isInterfaceElevationDependent()
    //     0xabf7a4: bl              #0x6cabd0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isInterfaceElevationDependent
    // 0xabf7a8: add             SP, SP, #8
    // 0xabf7ac: tbnz            w0, #4, #0xabf90c
    // 0xabf7b0: ldur            x1, [fp, #-0x18]
    // 0xabf7b4: ldur            x0, [fp, #-8]
    // 0xabf7b8: LoadField: r2 = r1->field_33
    //     0xabf7b8: ldur            w2, [x1, #0x33]
    // 0xabf7bc: DecompressPointer r2
    //     0xabf7bc: add             x2, x2, HEAP, lsl #32
    // 0xabf7c0: stur            x2, [fp, #-0x20]
    // 0xabf7c4: cmp             w2, w0
    // 0xabf7c8: b.ne            #0xabf7d4
    // 0xabf7cc: mov             x3, x2
    // 0xabf7d0: b               #0xabf818
    // 0xabf7d4: r16 = Color
    //     0xabf7d4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf7d8: ldr             x16, [x16, #0xf18]
    // 0xabf7dc: r30 = Color
    //     0xabf7dc: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf7e0: ldr             lr, [lr, #0xf18]
    // 0xabf7e4: stp             lr, x16, [SP, #-0x10]!
    // 0xabf7e8: r0 = ==()
    //     0xabf7e8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf7ec: add             SP, SP, #0x10
    // 0xabf7f0: tbz             w0, #4, #0xabf800
    // 0xabf7f4: ldur            x3, [fp, #-0x20]
    // 0xabf7f8: ldur            x0, [fp, #-8]
    // 0xabf7fc: b               #0xabf820
    // 0xabf800: ldur            x3, [fp, #-0x20]
    // 0xabf804: ldur            x0, [fp, #-8]
    // 0xabf808: LoadField: r1 = r0->field_7
    //     0xabf808: ldur            x1, [x0, #7]
    // 0xabf80c: LoadField: r2 = r3->field_7
    //     0xabf80c: ldur            x2, [x3, #7]
    // 0xabf810: cmp             x1, x2
    // 0xabf814: b.ne            #0xabf820
    // 0xabf818: r5 = "*"
    //     0xabf818: ldr             x5, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf81c: b               #0xabf824
    // 0xabf820: r5 = ""
    //     0xabf820: ldr             x5, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf824: ldur            x4, [fp, #-0x10]
    // 0xabf828: stur            x5, [fp, #-0x28]
    // 0xabf82c: r1 = Null
    //     0xabf82c: mov             x1, NULL
    // 0xabf830: r2 = 10
    //     0xabf830: mov             x2, #0xa
    // 0xabf834: r0 = AllocateArray()
    //     0xabf834: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf838: mov             x1, x0
    // 0xabf83c: ldur            x0, [fp, #-0x28]
    // 0xabf840: StoreField: r1->field_f = r0
    //     0xabf840: stur            w0, [x1, #0xf]
    // 0xabf844: r17 = "highContrastElevatedColor"
    //     0xabf844: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebe0] "highContrastElevatedColor"
    //     0xabf848: ldr             x17, [x17, #0xbe0]
    // 0xabf84c: StoreField: r1->field_13 = r17
    //     0xabf84c: stur            w17, [x1, #0x13]
    // 0xabf850: r17 = " = "
    //     0xabf850: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf854: ldr             x17, [x17, #0x800]
    // 0xabf858: StoreField: r1->field_17 = r17
    //     0xabf858: stur            w17, [x1, #0x17]
    // 0xabf85c: ldur            x2, [fp, #-0x20]
    // 0xabf860: StoreField: r1->field_1b = r2
    //     0xabf860: stur            w2, [x1, #0x1b]
    // 0xabf864: StoreField: r1->field_1f = r0
    //     0xabf864: stur            w0, [x1, #0x1f]
    // 0xabf868: SaveReg r1
    //     0xabf868: str             x1, [SP, #-8]!
    // 0xabf86c: r0 = _interpolate()
    //     0xabf86c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabf870: add             SP, SP, #8
    // 0xabf874: mov             x1, x0
    // 0xabf878: ldur            x0, [fp, #-0x10]
    // 0xabf87c: stur            x1, [fp, #-0x28]
    // 0xabf880: LoadField: r2 = r0->field_b
    //     0xabf880: ldur            w2, [x0, #0xb]
    // 0xabf884: DecompressPointer r2
    //     0xabf884: add             x2, x2, HEAP, lsl #32
    // 0xabf888: stur            x2, [fp, #-0x20]
    // 0xabf88c: LoadField: r3 = r0->field_f
    //     0xabf88c: ldur            w3, [x0, #0xf]
    // 0xabf890: DecompressPointer r3
    //     0xabf890: add             x3, x3, HEAP, lsl #32
    // 0xabf894: LoadField: r4 = r3->field_b
    //     0xabf894: ldur            w4, [x3, #0xb]
    // 0xabf898: DecompressPointer r4
    //     0xabf898: add             x4, x4, HEAP, lsl #32
    // 0xabf89c: cmp             w2, w4
    // 0xabf8a0: b.ne            #0xabf8b0
    // 0xabf8a4: SaveReg r0
    //     0xabf8a4: str             x0, [SP, #-8]!
    // 0xabf8a8: r0 = _growToNextCapacity()
    //     0xabf8a8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabf8ac: add             SP, SP, #8
    // 0xabf8b0: ldur            x0, [fp, #-0x20]
    // 0xabf8b4: ldur            x2, [fp, #-0x10]
    // 0xabf8b8: r3 = LoadInt32Instr(r0)
    //     0xabf8b8: sbfx            x3, x0, #1, #0x1f
    // 0xabf8bc: add             x0, x3, #1
    // 0xabf8c0: lsl             x1, x0, #1
    // 0xabf8c4: StoreField: r2->field_b = r1
    //     0xabf8c4: stur            w1, [x2, #0xb]
    // 0xabf8c8: mov             x1, x3
    // 0xabf8cc: cmp             x1, x0
    // 0xabf8d0: b.hs            #0xabfba4
    // 0xabf8d4: LoadField: r1 = r2->field_f
    //     0xabf8d4: ldur            w1, [x2, #0xf]
    // 0xabf8d8: DecompressPointer r1
    //     0xabf8d8: add             x1, x1, HEAP, lsl #32
    // 0xabf8dc: ldur            x0, [fp, #-0x28]
    // 0xabf8e0: ArrayStore: r1[r3] = r0  ; List_4
    //     0xabf8e0: add             x25, x1, x3, lsl #2
    //     0xabf8e4: add             x25, x25, #0xf
    //     0xabf8e8: str             w0, [x25]
    //     0xabf8ec: tbz             w0, #0, #0xabf908
    //     0xabf8f0: ldurb           w16, [x1, #-1]
    //     0xabf8f4: ldurb           w17, [x0, #-1]
    //     0xabf8f8: and             x16, x17, x16, lsr #2
    //     0xabf8fc: tst             x16, HEAP, lsr #32
    //     0xabf900: b.eq            #0xabf908
    //     0xabf904: bl              #0xd67e5c
    // 0xabf908: b               #0xabf918
    // 0xabf90c: ldur            x2, [fp, #-0x10]
    // 0xabf910: b               #0xabf918
    // 0xabf914: ldur            x2, [fp, #-0x10]
    // 0xabf918: ldur            x16, [fp, #-0x18]
    // 0xabf91c: SaveReg r16
    //     0xabf91c: str             x16, [SP, #-8]!
    // 0xabf920: r0 = _isPlatformBrightnessDependent()
    //     0xabf920: bl              #0x6cb054  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isPlatformBrightnessDependent
    // 0xabf924: add             SP, SP, #8
    // 0xabf928: tbnz            w0, #4, #0xabfabc
    // 0xabf92c: ldur            x16, [fp, #-0x18]
    // 0xabf930: SaveReg r16
    //     0xabf930: str             x16, [SP, #-8]!
    // 0xabf934: r0 = _isHighContrastDependent()
    //     0xabf934: bl              #0x6cad94  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isHighContrastDependent
    // 0xabf938: add             SP, SP, #8
    // 0xabf93c: tbnz            w0, #4, #0xabfab4
    // 0xabf940: ldur            x16, [fp, #-0x18]
    // 0xabf944: SaveReg r16
    //     0xabf944: str             x16, [SP, #-8]!
    // 0xabf948: r0 = _isInterfaceElevationDependent()
    //     0xabf948: bl              #0x6cabd0  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::_isInterfaceElevationDependent
    // 0xabf94c: add             SP, SP, #8
    // 0xabf950: tbnz            w0, #4, #0xabfaac
    // 0xabf954: ldur            x1, [fp, #-0x18]
    // 0xabf958: ldur            x0, [fp, #-8]
    // 0xabf95c: LoadField: r2 = r1->field_37
    //     0xabf95c: ldur            w2, [x1, #0x37]
    // 0xabf960: DecompressPointer r2
    //     0xabf960: add             x2, x2, HEAP, lsl #32
    // 0xabf964: stur            x2, [fp, #-0x20]
    // 0xabf968: cmp             w2, w0
    // 0xabf96c: b.ne            #0xabf978
    // 0xabf970: mov             x3, x2
    // 0xabf974: b               #0xabf9b8
    // 0xabf978: r16 = Color
    //     0xabf978: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf97c: ldr             x16, [x16, #0xf18]
    // 0xabf980: r30 = Color
    //     0xabf980: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xabf984: ldr             lr, [lr, #0xf18]
    // 0xabf988: stp             lr, x16, [SP, #-0x10]!
    // 0xabf98c: r0 = ==()
    //     0xabf98c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xabf990: add             SP, SP, #0x10
    // 0xabf994: tbz             w0, #4, #0xabf9a0
    // 0xabf998: ldur            x3, [fp, #-0x20]
    // 0xabf99c: b               #0xabf9c0
    // 0xabf9a0: ldur            x3, [fp, #-0x20]
    // 0xabf9a4: ldur            x0, [fp, #-8]
    // 0xabf9a8: LoadField: r1 = r0->field_7
    //     0xabf9a8: ldur            x1, [x0, #7]
    // 0xabf9ac: LoadField: r0 = r3->field_7
    //     0xabf9ac: ldur            x0, [x3, #7]
    // 0xabf9b0: cmp             x1, x0
    // 0xabf9b4: b.ne            #0xabf9c0
    // 0xabf9b8: r4 = "*"
    //     0xabf9b8: ldr             x4, [PP, #0x6f68]  ; [pp+0x6f68] "*"
    // 0xabf9bc: b               #0xabf9c4
    // 0xabf9c0: r4 = ""
    //     0xabf9c0: ldr             x4, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xabf9c4: ldur            x0, [fp, #-0x10]
    // 0xabf9c8: stur            x4, [fp, #-8]
    // 0xabf9cc: r1 = Null
    //     0xabf9cc: mov             x1, NULL
    // 0xabf9d0: r2 = 10
    //     0xabf9d0: mov             x2, #0xa
    // 0xabf9d4: r0 = AllocateArray()
    //     0xabf9d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabf9d8: mov             x1, x0
    // 0xabf9dc: ldur            x0, [fp, #-8]
    // 0xabf9e0: StoreField: r1->field_f = r0
    //     0xabf9e0: stur            w0, [x1, #0xf]
    // 0xabf9e4: r17 = "darkHighContrastElevatedColor"
    //     0xabf9e4: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebe8] "darkHighContrastElevatedColor"
    //     0xabf9e8: ldr             x17, [x17, #0xbe8]
    // 0xabf9ec: StoreField: r1->field_13 = r17
    //     0xabf9ec: stur            w17, [x1, #0x13]
    // 0xabf9f0: r17 = " = "
    //     0xabf9f0: add             x17, PP, #0xa, lsl #12  ; [pp+0xa800] " = "
    //     0xabf9f4: ldr             x17, [x17, #0x800]
    // 0xabf9f8: StoreField: r1->field_17 = r17
    //     0xabf9f8: stur            w17, [x1, #0x17]
    // 0xabf9fc: ldur            x2, [fp, #-0x20]
    // 0xabfa00: StoreField: r1->field_1b = r2
    //     0xabfa00: stur            w2, [x1, #0x1b]
    // 0xabfa04: StoreField: r1->field_1f = r0
    //     0xabfa04: stur            w0, [x1, #0x1f]
    // 0xabfa08: SaveReg r1
    //     0xabfa08: str             x1, [SP, #-8]!
    // 0xabfa0c: r0 = _interpolate()
    //     0xabfa0c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabfa10: add             SP, SP, #8
    // 0xabfa14: mov             x1, x0
    // 0xabfa18: ldur            x0, [fp, #-0x10]
    // 0xabfa1c: stur            x1, [fp, #-0x20]
    // 0xabfa20: LoadField: r2 = r0->field_b
    //     0xabfa20: ldur            w2, [x0, #0xb]
    // 0xabfa24: DecompressPointer r2
    //     0xabfa24: add             x2, x2, HEAP, lsl #32
    // 0xabfa28: stur            x2, [fp, #-8]
    // 0xabfa2c: LoadField: r3 = r0->field_f
    //     0xabfa2c: ldur            w3, [x0, #0xf]
    // 0xabfa30: DecompressPointer r3
    //     0xabfa30: add             x3, x3, HEAP, lsl #32
    // 0xabfa34: LoadField: r4 = r3->field_b
    //     0xabfa34: ldur            w4, [x3, #0xb]
    // 0xabfa38: DecompressPointer r4
    //     0xabfa38: add             x4, x4, HEAP, lsl #32
    // 0xabfa3c: cmp             w2, w4
    // 0xabfa40: b.ne            #0xabfa50
    // 0xabfa44: SaveReg r0
    //     0xabfa44: str             x0, [SP, #-8]!
    // 0xabfa48: r0 = _growToNextCapacity()
    //     0xabfa48: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xabfa4c: add             SP, SP, #8
    // 0xabfa50: ldur            x0, [fp, #-8]
    // 0xabfa54: ldur            x3, [fp, #-0x10]
    // 0xabfa58: r2 = LoadInt32Instr(r0)
    //     0xabfa58: sbfx            x2, x0, #1, #0x1f
    // 0xabfa5c: add             x0, x2, #1
    // 0xabfa60: lsl             x1, x0, #1
    // 0xabfa64: StoreField: r3->field_b = r1
    //     0xabfa64: stur            w1, [x3, #0xb]
    // 0xabfa68: mov             x1, x2
    // 0xabfa6c: cmp             x1, x0
    // 0xabfa70: b.hs            #0xabfba8
    // 0xabfa74: LoadField: r1 = r3->field_f
    //     0xabfa74: ldur            w1, [x3, #0xf]
    // 0xabfa78: DecompressPointer r1
    //     0xabfa78: add             x1, x1, HEAP, lsl #32
    // 0xabfa7c: ldur            x0, [fp, #-0x20]
    // 0xabfa80: ArrayStore: r1[r2] = r0  ; List_4
    //     0xabfa80: add             x25, x1, x2, lsl #2
    //     0xabfa84: add             x25, x25, #0xf
    //     0xabfa88: str             w0, [x25]
    //     0xabfa8c: tbz             w0, #0, #0xabfaa8
    //     0xabfa90: ldurb           w16, [x1, #-1]
    //     0xabfa94: ldurb           w17, [x0, #-1]
    //     0xabfa98: and             x16, x17, x16, lsr #2
    //     0xabfa9c: tst             x16, HEAP, lsr #32
    //     0xabfaa0: b.eq            #0xabfaa8
    //     0xabfaa4: bl              #0xd67e5c
    // 0xabfaa8: b               #0xabfac0
    // 0xabfaac: ldur            x3, [fp, #-0x10]
    // 0xabfab0: b               #0xabfac0
    // 0xabfab4: ldur            x3, [fp, #-0x10]
    // 0xabfab8: b               #0xabfac0
    // 0xabfabc: ldur            x3, [fp, #-0x10]
    // 0xabfac0: ldur            x0, [fp, #-0x18]
    // 0xabfac4: LoadField: r1 = r0->field_13
    //     0xabfac4: ldur            w1, [x0, #0x13]
    // 0xabfac8: DecompressPointer r1
    //     0xabfac8: add             x1, x1, HEAP, lsl #32
    // 0xabfacc: cmp             w1, NULL
    // 0xabfad0: b.ne            #0xabfae0
    // 0xabfad4: r0 = "CupertinoDynamicColor"
    //     0xabfad4: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2ebf0] "CupertinoDynamicColor"
    //     0xabfad8: ldr             x0, [x0, #0xbf0]
    // 0xabfadc: b               #0xabfae4
    // 0xabfae0: mov             x0, x1
    // 0xabfae4: stur            x0, [fp, #-8]
    // 0xabfae8: r1 = Null
    //     0xabfae8: mov             x1, NULL
    // 0xabfaec: r2 = 12
    //     0xabfaec: mov             x2, #0xc
    // 0xabfaf0: r0 = AllocateArray()
    //     0xabfaf0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xabfaf4: mov             x1, x0
    // 0xabfaf8: ldur            x0, [fp, #-8]
    // 0xabfafc: stur            x1, [fp, #-0x18]
    // 0xabfb00: StoreField: r1->field_f = r0
    //     0xabfb00: stur            w0, [x1, #0xf]
    // 0xabfb04: r17 = "("
    //     0xabfb04: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xabfb08: StoreField: r1->field_13 = r17
    //     0xabfb08: stur            w17, [x1, #0x13]
    // 0xabfb0c: ldur            x16, [fp, #-0x10]
    // 0xabfb10: r30 = ", "
    //     0xabfb10: ldr             lr, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xabfb14: stp             lr, x16, [SP, #-0x10]!
    // 0xabfb18: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xabfb18: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xabfb1c: r0 = join()
    //     0xabfb1c: bl              #0x6fddb0  ; [dart:core] _GrowableList::join
    // 0xabfb20: add             SP, SP, #0x10
    // 0xabfb24: ldur            x1, [fp, #-0x18]
    // 0xabfb28: ArrayStore: r1[2] = r0  ; List_4
    //     0xabfb28: add             x25, x1, #0x17
    //     0xabfb2c: str             w0, [x25]
    //     0xabfb30: tbz             w0, #0, #0xabfb4c
    //     0xabfb34: ldurb           w16, [x1, #-1]
    //     0xabfb38: ldurb           w17, [x0, #-1]
    //     0xabfb3c: and             x16, x17, x16, lsr #2
    //     0xabfb40: tst             x16, HEAP, lsr #32
    //     0xabfb44: b.eq            #0xabfb4c
    //     0xabfb48: bl              #0xd67e5c
    // 0xabfb4c: ldur            x0, [fp, #-0x18]
    // 0xabfb50: r17 = ", resolved by: "
    //     0xabfb50: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ebf8] ", resolved by: "
    //     0xabfb54: ldr             x17, [x17, #0xbf8]
    // 0xabfb58: StoreField: r0->field_1b = r17
    //     0xabfb58: stur            w17, [x0, #0x1b]
    // 0xabfb5c: r17 = "UNRESOLVED"
    //     0xabfb5c: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2ec00] "UNRESOLVED"
    //     0xabfb60: ldr             x17, [x17, #0xc00]
    // 0xabfb64: StoreField: r0->field_1f = r17
    //     0xabfb64: stur            w17, [x0, #0x1f]
    // 0xabfb68: r17 = ")"
    //     0xabfb68: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xabfb6c: StoreField: r0->field_23 = r17
    //     0xabfb6c: stur            w17, [x0, #0x23]
    // 0xabfb70: SaveReg r0
    //     0xabfb70: str             x0, [SP, #-8]!
    // 0xabfb74: r0 = _interpolate()
    //     0xabfb74: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xabfb78: add             SP, SP, #8
    // 0xabfb7c: LeaveFrame
    //     0xabfb7c: mov             SP, fp
    //     0xabfb80: ldp             fp, lr, [SP], #0x10
    // 0xabfb84: ret
    //     0xabfb84: ret             
    // 0xabfb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xabfb88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xabfb8c: b               #0xabef08
    // 0xabfb90: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfb90: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xabfb94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfb94: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xabfb98: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfb98: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xabfb9c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfb9c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xabfba0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfba0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xabfba4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfba4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xabfba8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xabfba8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xaf8bd4, size: 0xc8
    // 0xaf8bd4: EnterFrame
    //     0xaf8bd4: stp             fp, lr, [SP, #-0x10]!
    //     0xaf8bd8: mov             fp, SP
    // 0xaf8bdc: CheckStackOverflow
    //     0xaf8bdc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaf8be0: cmp             SP, x16
    //     0xaf8be4: b.ls            #0xaf8c94
    // 0xaf8be8: ldr             x0, [fp, #0x10]
    // 0xaf8bec: LoadField: r1 = r0->field_f
    //     0xaf8bec: ldur            w1, [x0, #0xf]
    // 0xaf8bf0: DecompressPointer r1
    //     0xaf8bf0: add             x1, x1, HEAP, lsl #32
    // 0xaf8bf4: LoadField: r2 = r1->field_7
    //     0xaf8bf4: ldur            x2, [x1, #7]
    // 0xaf8bf8: LoadField: r3 = r0->field_1b
    //     0xaf8bf8: ldur            w3, [x0, #0x1b]
    // 0xaf8bfc: DecompressPointer r3
    //     0xaf8bfc: add             x3, x3, HEAP, lsl #32
    // 0xaf8c00: LoadField: r4 = r0->field_1f
    //     0xaf8c00: ldur            w4, [x0, #0x1f]
    // 0xaf8c04: DecompressPointer r4
    //     0xaf8c04: add             x4, x4, HEAP, lsl #32
    // 0xaf8c08: LoadField: r5 = r0->field_23
    //     0xaf8c08: ldur            w5, [x0, #0x23]
    // 0xaf8c0c: DecompressPointer r5
    //     0xaf8c0c: add             x5, x5, HEAP, lsl #32
    // 0xaf8c10: LoadField: r6 = r0->field_2b
    //     0xaf8c10: ldur            w6, [x0, #0x2b]
    // 0xaf8c14: DecompressPointer r6
    //     0xaf8c14: add             x6, x6, HEAP, lsl #32
    // 0xaf8c18: LoadField: r7 = r0->field_2f
    //     0xaf8c18: ldur            w7, [x0, #0x2f]
    // 0xaf8c1c: DecompressPointer r7
    //     0xaf8c1c: add             x7, x7, HEAP, lsl #32
    // 0xaf8c20: LoadField: r8 = r0->field_27
    //     0xaf8c20: ldur            w8, [x0, #0x27]
    // 0xaf8c24: DecompressPointer r8
    //     0xaf8c24: add             x8, x8, HEAP, lsl #32
    // 0xaf8c28: LoadField: r9 = r0->field_37
    //     0xaf8c28: ldur            w9, [x0, #0x37]
    // 0xaf8c2c: DecompressPointer r9
    //     0xaf8c2c: add             x9, x9, HEAP, lsl #32
    // 0xaf8c30: LoadField: r10 = r0->field_33
    //     0xaf8c30: ldur            w10, [x0, #0x33]
    // 0xaf8c34: DecompressPointer r10
    //     0xaf8c34: add             x10, x10, HEAP, lsl #32
    // 0xaf8c38: r0 = BoxInt64Instr(r2)
    //     0xaf8c38: sbfiz           x0, x2, #1, #0x1f
    //     0xaf8c3c: cmp             x2, x0, asr #1
    //     0xaf8c40: b.eq            #0xaf8c4c
    //     0xaf8c44: bl              #0xd69bb8
    //     0xaf8c48: stur            x2, [x0, #7]
    // 0xaf8c4c: stp             x3, x0, [SP, #-0x10]!
    // 0xaf8c50: stp             x5, x4, [SP, #-0x10]!
    // 0xaf8c54: stp             x7, x6, [SP, #-0x10]!
    // 0xaf8c58: stp             x9, x8, [SP, #-0x10]!
    // 0xaf8c5c: SaveReg r10
    //     0xaf8c5c: str             x10, [SP, #-8]!
    // 0xaf8c60: r4 = const [0, 0x9, 0x9, 0x9, null]
    //     0xaf8c60: add             x4, PP, #0xe, lsl #12  ; [pp+0xe428] List(5) [0, 0x9, 0x9, 0x9, Null]
    //     0xaf8c64: ldr             x4, [x4, #0x428]
    // 0xaf8c68: r0 = hash()
    //     0xaf8c68: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaf8c6c: add             SP, SP, #0x48
    // 0xaf8c70: mov             x2, x0
    // 0xaf8c74: r0 = BoxInt64Instr(r2)
    //     0xaf8c74: sbfiz           x0, x2, #1, #0x1f
    //     0xaf8c78: cmp             x2, x0, asr #1
    //     0xaf8c7c: b.eq            #0xaf8c88
    //     0xaf8c80: bl              #0xd69bb8
    //     0xaf8c84: stur            x2, [x0, #7]
    // 0xaf8c88: LeaveFrame
    //     0xaf8c88: mov             SP, fp
    //     0xaf8c8c: ldp             fp, lr, [SP], #0x10
    // 0xaf8c90: ret
    //     0xaf8c90: ret             
    // 0xaf8c94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf8c94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf8c98: b               #0xaf8be8
  }
  _ ==(/* No info */) {
    // ** addr: 0xc664cc, size: 0x42c
    // 0xc664cc: EnterFrame
    //     0xc664cc: stp             fp, lr, [SP, #-0x10]!
    //     0xc664d0: mov             fp, SP
    // 0xc664d4: AllocStack(0x10)
    //     0xc664d4: sub             SP, SP, #0x10
    // 0xc664d8: CheckStackOverflow
    //     0xc664d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc664dc: cmp             SP, x16
    //     0xc664e0: b.ls            #0xc668f0
    // 0xc664e4: ldr             x1, [fp, #0x10]
    // 0xc664e8: cmp             w1, NULL
    // 0xc664ec: b.ne            #0xc66500
    // 0xc664f0: r0 = false
    //     0xc664f0: add             x0, NULL, #0x30  ; false
    // 0xc664f4: LeaveFrame
    //     0xc664f4: mov             SP, fp
    //     0xc664f8: ldp             fp, lr, [SP], #0x10
    // 0xc664fc: ret
    //     0xc664fc: ret             
    // 0xc66500: ldr             x2, [fp, #0x18]
    // 0xc66504: cmp             w2, w1
    // 0xc66508: b.ne            #0xc6651c
    // 0xc6650c: r0 = true
    //     0xc6650c: add             x0, NULL, #0x20  ; true
    // 0xc66510: LeaveFrame
    //     0xc66510: mov             SP, fp
    //     0xc66514: ldp             fp, lr, [SP], #0x10
    // 0xc66518: ret
    //     0xc66518: ret             
    // 0xc6651c: r0 = 59
    //     0xc6651c: mov             x0, #0x3b
    // 0xc66520: branchIfSmi(r1, 0xc6652c)
    //     0xc66520: tbz             w1, #0, #0xc6652c
    // 0xc66524: r0 = LoadClassIdInstr(r1)
    //     0xc66524: ldur            x0, [x1, #-1]
    //     0xc66528: ubfx            x0, x0, #0xc, #0x14
    // 0xc6652c: SaveReg r1
    //     0xc6652c: str             x1, [SP, #-8]!
    // 0xc66530: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc66530: mov             x17, #0x57c5
    //     0xc66534: add             lr, x0, x17
    //     0xc66538: ldr             lr, [x21, lr, lsl #3]
    //     0xc6653c: blr             lr
    // 0xc66540: add             SP, SP, #8
    // 0xc66544: r1 = LoadClassIdInstr(r0)
    //     0xc66544: ldur            x1, [x0, #-1]
    //     0xc66548: ubfx            x1, x1, #0xc, #0x14
    // 0xc6654c: r16 = CupertinoDynamicColor
    //     0xc6654c: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2ec08] Type: CupertinoDynamicColor
    //     0xc66550: ldr             x16, [x16, #0xc08]
    // 0xc66554: stp             x16, x0, [SP, #-0x10]!
    // 0xc66558: mov             x0, x1
    // 0xc6655c: mov             lr, x0
    // 0xc66560: ldr             lr, [x21, lr, lsl #3]
    // 0xc66564: blr             lr
    // 0xc66568: add             SP, SP, #0x10
    // 0xc6656c: tbz             w0, #4, #0xc66580
    // 0xc66570: r0 = false
    //     0xc66570: add             x0, NULL, #0x30  ; false
    // 0xc66574: LeaveFrame
    //     0xc66574: mov             SP, fp
    //     0xc66578: ldp             fp, lr, [SP], #0x10
    // 0xc6657c: ret
    //     0xc6657c: ret             
    // 0xc66580: ldr             x0, [fp, #0x10]
    // 0xc66584: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc66584: mov             x1, #0x76
    //     0xc66588: tbz             w0, #0, #0xc66598
    //     0xc6658c: ldur            x1, [x0, #-1]
    //     0xc66590: ubfx            x1, x1, #0xc, #0x14
    //     0xc66594: lsl             x1, x1, #1
    // 0xc66598: r17 = 10128
    //     0xc66598: mov             x17, #0x2790
    // 0xc6659c: cmp             w1, w17
    // 0xc665a0: b.ne            #0xc668e0
    // 0xc665a4: ldr             x1, [fp, #0x18]
    // 0xc665a8: LoadField: r2 = r0->field_f
    //     0xc665a8: ldur            w2, [x0, #0xf]
    // 0xc665ac: DecompressPointer r2
    //     0xc665ac: add             x2, x2, HEAP, lsl #32
    // 0xc665b0: LoadField: r3 = r2->field_7
    //     0xc665b0: ldur            x3, [x2, #7]
    // 0xc665b4: LoadField: r2 = r1->field_f
    //     0xc665b4: ldur            w2, [x1, #0xf]
    // 0xc665b8: DecompressPointer r2
    //     0xc665b8: add             x2, x2, HEAP, lsl #32
    // 0xc665bc: LoadField: r4 = r2->field_7
    //     0xc665bc: ldur            x4, [x2, #7]
    // 0xc665c0: cmp             x3, x4
    // 0xc665c4: b.ne            #0xc668e0
    // 0xc665c8: LoadField: r2 = r0->field_1b
    //     0xc665c8: ldur            w2, [x0, #0x1b]
    // 0xc665cc: DecompressPointer r2
    //     0xc665cc: add             x2, x2, HEAP, lsl #32
    // 0xc665d0: stur            x2, [fp, #-0x10]
    // 0xc665d4: LoadField: r3 = r1->field_1b
    //     0xc665d4: ldur            w3, [x1, #0x1b]
    // 0xc665d8: DecompressPointer r3
    //     0xc665d8: add             x3, x3, HEAP, lsl #32
    // 0xc665dc: stur            x3, [fp, #-8]
    // 0xc665e0: cmp             w2, w3
    // 0xc665e4: b.eq            #0xc66628
    // 0xc665e8: r16 = Color
    //     0xc665e8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc665ec: ldr             x16, [x16, #0xf18]
    // 0xc665f0: r30 = Color
    //     0xc665f0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc665f4: ldr             lr, [lr, #0xf18]
    // 0xc665f8: stp             lr, x16, [SP, #-0x10]!
    // 0xc665fc: r0 = ==()
    //     0xc665fc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc66600: add             SP, SP, #0x10
    // 0xc66604: tbnz            w0, #4, #0xc668e0
    // 0xc66608: ldur            x0, [fp, #-0x10]
    // 0xc6660c: ldur            x1, [fp, #-8]
    // 0xc66610: LoadField: r2 = r1->field_7
    //     0xc66610: ldur            x2, [x1, #7]
    // 0xc66614: LoadField: r1 = r0->field_7
    //     0xc66614: ldur            x1, [x0, #7]
    // 0xc66618: cmp             x2, x1
    // 0xc6661c: b.ne            #0xc668e0
    // 0xc66620: ldr             x1, [fp, #0x18]
    // 0xc66624: ldr             x0, [fp, #0x10]
    // 0xc66628: LoadField: r2 = r0->field_1f
    //     0xc66628: ldur            w2, [x0, #0x1f]
    // 0xc6662c: DecompressPointer r2
    //     0xc6662c: add             x2, x2, HEAP, lsl #32
    // 0xc66630: stur            x2, [fp, #-0x10]
    // 0xc66634: LoadField: r3 = r1->field_1f
    //     0xc66634: ldur            w3, [x1, #0x1f]
    // 0xc66638: DecompressPointer r3
    //     0xc66638: add             x3, x3, HEAP, lsl #32
    // 0xc6663c: stur            x3, [fp, #-8]
    // 0xc66640: cmp             w2, w3
    // 0xc66644: b.eq            #0xc66688
    // 0xc66648: r16 = Color
    //     0xc66648: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6664c: ldr             x16, [x16, #0xf18]
    // 0xc66650: r30 = Color
    //     0xc66650: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc66654: ldr             lr, [lr, #0xf18]
    // 0xc66658: stp             lr, x16, [SP, #-0x10]!
    // 0xc6665c: r0 = ==()
    //     0xc6665c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc66660: add             SP, SP, #0x10
    // 0xc66664: tbnz            w0, #4, #0xc668e0
    // 0xc66668: ldur            x0, [fp, #-0x10]
    // 0xc6666c: ldur            x1, [fp, #-8]
    // 0xc66670: LoadField: r2 = r1->field_7
    //     0xc66670: ldur            x2, [x1, #7]
    // 0xc66674: LoadField: r1 = r0->field_7
    //     0xc66674: ldur            x1, [x0, #7]
    // 0xc66678: cmp             x2, x1
    // 0xc6667c: b.ne            #0xc668e0
    // 0xc66680: ldr             x1, [fp, #0x18]
    // 0xc66684: ldr             x0, [fp, #0x10]
    // 0xc66688: LoadField: r2 = r0->field_23
    //     0xc66688: ldur            w2, [x0, #0x23]
    // 0xc6668c: DecompressPointer r2
    //     0xc6668c: add             x2, x2, HEAP, lsl #32
    // 0xc66690: stur            x2, [fp, #-0x10]
    // 0xc66694: LoadField: r3 = r1->field_23
    //     0xc66694: ldur            w3, [x1, #0x23]
    // 0xc66698: DecompressPointer r3
    //     0xc66698: add             x3, x3, HEAP, lsl #32
    // 0xc6669c: stur            x3, [fp, #-8]
    // 0xc666a0: cmp             w2, w3
    // 0xc666a4: b.eq            #0xc666e8
    // 0xc666a8: r16 = Color
    //     0xc666a8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc666ac: ldr             x16, [x16, #0xf18]
    // 0xc666b0: r30 = Color
    //     0xc666b0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc666b4: ldr             lr, [lr, #0xf18]
    // 0xc666b8: stp             lr, x16, [SP, #-0x10]!
    // 0xc666bc: r0 = ==()
    //     0xc666bc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc666c0: add             SP, SP, #0x10
    // 0xc666c4: tbnz            w0, #4, #0xc668e0
    // 0xc666c8: ldur            x0, [fp, #-0x10]
    // 0xc666cc: ldur            x1, [fp, #-8]
    // 0xc666d0: LoadField: r2 = r1->field_7
    //     0xc666d0: ldur            x2, [x1, #7]
    // 0xc666d4: LoadField: r1 = r0->field_7
    //     0xc666d4: ldur            x1, [x0, #7]
    // 0xc666d8: cmp             x2, x1
    // 0xc666dc: b.ne            #0xc668e0
    // 0xc666e0: ldr             x1, [fp, #0x18]
    // 0xc666e4: ldr             x0, [fp, #0x10]
    // 0xc666e8: LoadField: r2 = r0->field_27
    //     0xc666e8: ldur            w2, [x0, #0x27]
    // 0xc666ec: DecompressPointer r2
    //     0xc666ec: add             x2, x2, HEAP, lsl #32
    // 0xc666f0: stur            x2, [fp, #-0x10]
    // 0xc666f4: LoadField: r3 = r1->field_27
    //     0xc666f4: ldur            w3, [x1, #0x27]
    // 0xc666f8: DecompressPointer r3
    //     0xc666f8: add             x3, x3, HEAP, lsl #32
    // 0xc666fc: stur            x3, [fp, #-8]
    // 0xc66700: cmp             w2, w3
    // 0xc66704: b.eq            #0xc66748
    // 0xc66708: r16 = Color
    //     0xc66708: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6670c: ldr             x16, [x16, #0xf18]
    // 0xc66710: r30 = Color
    //     0xc66710: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc66714: ldr             lr, [lr, #0xf18]
    // 0xc66718: stp             lr, x16, [SP, #-0x10]!
    // 0xc6671c: r0 = ==()
    //     0xc6671c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc66720: add             SP, SP, #0x10
    // 0xc66724: tbnz            w0, #4, #0xc668e0
    // 0xc66728: ldur            x0, [fp, #-0x10]
    // 0xc6672c: ldur            x1, [fp, #-8]
    // 0xc66730: LoadField: r2 = r1->field_7
    //     0xc66730: ldur            x2, [x1, #7]
    // 0xc66734: LoadField: r1 = r0->field_7
    //     0xc66734: ldur            x1, [x0, #7]
    // 0xc66738: cmp             x2, x1
    // 0xc6673c: b.ne            #0xc668e0
    // 0xc66740: ldr             x1, [fp, #0x18]
    // 0xc66744: ldr             x0, [fp, #0x10]
    // 0xc66748: LoadField: r2 = r0->field_2b
    //     0xc66748: ldur            w2, [x0, #0x2b]
    // 0xc6674c: DecompressPointer r2
    //     0xc6674c: add             x2, x2, HEAP, lsl #32
    // 0xc66750: stur            x2, [fp, #-0x10]
    // 0xc66754: LoadField: r3 = r1->field_2b
    //     0xc66754: ldur            w3, [x1, #0x2b]
    // 0xc66758: DecompressPointer r3
    //     0xc66758: add             x3, x3, HEAP, lsl #32
    // 0xc6675c: stur            x3, [fp, #-8]
    // 0xc66760: cmp             w2, w3
    // 0xc66764: b.eq            #0xc667a8
    // 0xc66768: r16 = Color
    //     0xc66768: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6676c: ldr             x16, [x16, #0xf18]
    // 0xc66770: r30 = Color
    //     0xc66770: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc66774: ldr             lr, [lr, #0xf18]
    // 0xc66778: stp             lr, x16, [SP, #-0x10]!
    // 0xc6677c: r0 = ==()
    //     0xc6677c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc66780: add             SP, SP, #0x10
    // 0xc66784: tbnz            w0, #4, #0xc668e0
    // 0xc66788: ldur            x0, [fp, #-0x10]
    // 0xc6678c: ldur            x1, [fp, #-8]
    // 0xc66790: LoadField: r2 = r1->field_7
    //     0xc66790: ldur            x2, [x1, #7]
    // 0xc66794: LoadField: r1 = r0->field_7
    //     0xc66794: ldur            x1, [x0, #7]
    // 0xc66798: cmp             x2, x1
    // 0xc6679c: b.ne            #0xc668e0
    // 0xc667a0: ldr             x1, [fp, #0x18]
    // 0xc667a4: ldr             x0, [fp, #0x10]
    // 0xc667a8: LoadField: r2 = r0->field_2f
    //     0xc667a8: ldur            w2, [x0, #0x2f]
    // 0xc667ac: DecompressPointer r2
    //     0xc667ac: add             x2, x2, HEAP, lsl #32
    // 0xc667b0: stur            x2, [fp, #-0x10]
    // 0xc667b4: LoadField: r3 = r1->field_2f
    //     0xc667b4: ldur            w3, [x1, #0x2f]
    // 0xc667b8: DecompressPointer r3
    //     0xc667b8: add             x3, x3, HEAP, lsl #32
    // 0xc667bc: stur            x3, [fp, #-8]
    // 0xc667c0: cmp             w2, w3
    // 0xc667c4: b.eq            #0xc66808
    // 0xc667c8: r16 = Color
    //     0xc667c8: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc667cc: ldr             x16, [x16, #0xf18]
    // 0xc667d0: r30 = Color
    //     0xc667d0: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc667d4: ldr             lr, [lr, #0xf18]
    // 0xc667d8: stp             lr, x16, [SP, #-0x10]!
    // 0xc667dc: r0 = ==()
    //     0xc667dc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc667e0: add             SP, SP, #0x10
    // 0xc667e4: tbnz            w0, #4, #0xc668e0
    // 0xc667e8: ldur            x0, [fp, #-0x10]
    // 0xc667ec: ldur            x1, [fp, #-8]
    // 0xc667f0: LoadField: r2 = r1->field_7
    //     0xc667f0: ldur            x2, [x1, #7]
    // 0xc667f4: LoadField: r1 = r0->field_7
    //     0xc667f4: ldur            x1, [x0, #7]
    // 0xc667f8: cmp             x2, x1
    // 0xc667fc: b.ne            #0xc668e0
    // 0xc66800: ldr             x1, [fp, #0x18]
    // 0xc66804: ldr             x0, [fp, #0x10]
    // 0xc66808: LoadField: r2 = r0->field_33
    //     0xc66808: ldur            w2, [x0, #0x33]
    // 0xc6680c: DecompressPointer r2
    //     0xc6680c: add             x2, x2, HEAP, lsl #32
    // 0xc66810: stur            x2, [fp, #-0x10]
    // 0xc66814: LoadField: r3 = r1->field_33
    //     0xc66814: ldur            w3, [x1, #0x33]
    // 0xc66818: DecompressPointer r3
    //     0xc66818: add             x3, x3, HEAP, lsl #32
    // 0xc6681c: stur            x3, [fp, #-8]
    // 0xc66820: cmp             w2, w3
    // 0xc66824: b.eq            #0xc66868
    // 0xc66828: r16 = Color
    //     0xc66828: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6682c: ldr             x16, [x16, #0xf18]
    // 0xc66830: r30 = Color
    //     0xc66830: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc66834: ldr             lr, [lr, #0xf18]
    // 0xc66838: stp             lr, x16, [SP, #-0x10]!
    // 0xc6683c: r0 = ==()
    //     0xc6683c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc66840: add             SP, SP, #0x10
    // 0xc66844: tbnz            w0, #4, #0xc668e0
    // 0xc66848: ldur            x0, [fp, #-0x10]
    // 0xc6684c: ldur            x1, [fp, #-8]
    // 0xc66850: LoadField: r2 = r1->field_7
    //     0xc66850: ldur            x2, [x1, #7]
    // 0xc66854: LoadField: r1 = r0->field_7
    //     0xc66854: ldur            x1, [x0, #7]
    // 0xc66858: cmp             x2, x1
    // 0xc6685c: b.ne            #0xc668e0
    // 0xc66860: ldr             x1, [fp, #0x18]
    // 0xc66864: ldr             x0, [fp, #0x10]
    // 0xc66868: LoadField: r2 = r0->field_37
    //     0xc66868: ldur            w2, [x0, #0x37]
    // 0xc6686c: DecompressPointer r2
    //     0xc6686c: add             x2, x2, HEAP, lsl #32
    // 0xc66870: stur            x2, [fp, #-0x10]
    // 0xc66874: LoadField: r0 = r1->field_37
    //     0xc66874: ldur            w0, [x1, #0x37]
    // 0xc66878: DecompressPointer r0
    //     0xc66878: add             x0, x0, HEAP, lsl #32
    // 0xc6687c: stur            x0, [fp, #-8]
    // 0xc66880: cmp             w2, w0
    // 0xc66884: b.ne            #0xc66890
    // 0xc66888: r1 = true
    //     0xc66888: add             x1, NULL, #0x20  ; true
    // 0xc6688c: b               #0xc668d8
    // 0xc66890: r16 = Color
    //     0xc66890: add             x16, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc66894: ldr             x16, [x16, #0xf18]
    // 0xc66898: r30 = Color
    //     0xc66898: add             lr, PP, #0xd, lsl #12  ; [pp+0xdf18] Type: Color
    //     0xc6689c: ldr             lr, [lr, #0xf18]
    // 0xc668a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc668a4: r0 = ==()
    //     0xc668a4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc668a8: add             SP, SP, #0x10
    // 0xc668ac: tbz             w0, #4, #0xc668b8
    // 0xc668b0: r1 = false
    //     0xc668b0: add             x1, NULL, #0x30  ; false
    // 0xc668b4: b               #0xc668d8
    // 0xc668b8: ldur            x1, [fp, #-0x10]
    // 0xc668bc: ldur            x2, [fp, #-8]
    // 0xc668c0: LoadField: r3 = r2->field_7
    //     0xc668c0: ldur            x3, [x2, #7]
    // 0xc668c4: LoadField: r2 = r1->field_7
    //     0xc668c4: ldur            x2, [x1, #7]
    // 0xc668c8: cmp             x3, x2
    // 0xc668cc: r16 = true
    //     0xc668cc: add             x16, NULL, #0x20  ; true
    // 0xc668d0: r17 = false
    //     0xc668d0: add             x17, NULL, #0x30  ; false
    // 0xc668d4: csel            x1, x16, x17, eq
    // 0xc668d8: mov             x0, x1
    // 0xc668dc: b               #0xc668e4
    // 0xc668e0: r0 = false
    //     0xc668e0: add             x0, NULL, #0x30  ; false
    // 0xc668e4: LeaveFrame
    //     0xc668e4: mov             SP, fp
    //     0xc668e8: ldp             fp, lr, [SP], #0x10
    // 0xc668ec: ret
    //     0xc668ec: ret             
    // 0xc668f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc668f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc668f4: b               #0xc664e4
  }
  get _ value(/* No info */) {
    // ** addr: 0xcad884, size: 0x14
    // 0xcad884: ldr             x1, [SP]
    // 0xcad888: LoadField: r2 = r1->field_f
    //     0xcad888: ldur            w2, [x1, #0xf]
    // 0xcad88c: DecompressPointer r2
    //     0xcad88c: add             x2, x2, HEAP, lsl #32
    // 0xcad890: LoadField: r0 = r2->field_7
    //     0xcad890: ldur            x0, [x2, #7]
    // 0xcad894: ret
    //     0xcad894: ret             
  }
}

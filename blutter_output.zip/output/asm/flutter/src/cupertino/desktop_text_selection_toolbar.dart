// lib: , url: package:flutter/src/cupertino/desktop_text_selection_toolbar.dart

// class id: 1049085, size: 0x8
class :: {
}

// class id: 3873, size: 0x14, field offset: 0xc
//   const constructor, 
class CupertinoDesktopTextSelectionToolbar extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1cadc, size: 0x144
    // 0xb1cadc: EnterFrame
    //     0xb1cadc: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cae0: mov             fp, SP
    // 0xb1cae4: AllocStack(0x28)
    //     0xb1cae4: sub             SP, SP, #0x28
    // 0xb1cae8: CheckStackOverflow
    //     0xb1cae8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1caec: cmp             SP, x16
    //     0xb1caf0: b.ls            #0xb1cc18
    // 0xb1caf4: ldr             x16, [fp, #0x10]
    // 0xb1caf8: SaveReg r16
    //     0xb1caf8: str             x16, [SP, #-8]!
    // 0xb1cafc: r0 = of()
    //     0xb1cafc: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb1cb00: add             SP, SP, #8
    // 0xb1cb04: LoadField: r1 = r0->field_23
    //     0xb1cb04: ldur            w1, [x0, #0x23]
    // 0xb1cb08: DecompressPointer r1
    //     0xb1cb08: add             x1, x1, HEAP, lsl #32
    // 0xb1cb0c: LoadField: d0 = r1->field_f
    //     0xb1cb0c: ldur            d0, [x1, #0xf]
    // 0xb1cb10: d1 = 8.000000
    //     0xb1cb10: fmov            d1, #8.00000000
    // 0xb1cb14: fadd            d2, d0, d1
    // 0xb1cb18: stur            d2, [fp, #-0x28]
    // 0xb1cb1c: r0 = Offset()
    //     0xb1cb1c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb1cb20: d0 = 8.000000
    //     0xb1cb20: fmov            d0, #8.00000000
    // 0xb1cb24: stur            x0, [fp, #-8]
    // 0xb1cb28: StoreField: r0->field_7 = d0
    //     0xb1cb28: stur            d0, [x0, #7]
    // 0xb1cb2c: ldur            d1, [fp, #-0x28]
    // 0xb1cb30: StoreField: r0->field_f = d1
    //     0xb1cb30: stur            d1, [x0, #0xf]
    // 0xb1cb34: r0 = EdgeInsets()
    //     0xb1cb34: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1cb38: d0 = 8.000000
    //     0xb1cb38: fmov            d0, #8.00000000
    // 0xb1cb3c: stur            x0, [fp, #-0x10]
    // 0xb1cb40: StoreField: r0->field_7 = d0
    //     0xb1cb40: stur            d0, [x0, #7]
    // 0xb1cb44: ldur            d1, [fp, #-0x28]
    // 0xb1cb48: StoreField: r0->field_f = d1
    //     0xb1cb48: stur            d1, [x0, #0xf]
    // 0xb1cb4c: StoreField: r0->field_17 = d0
    //     0xb1cb4c: stur            d0, [x0, #0x17]
    // 0xb1cb50: StoreField: r0->field_1f = d0
    //     0xb1cb50: stur            d0, [x0, #0x1f]
    // 0xb1cb54: ldr             x1, [fp, #0x18]
    // 0xb1cb58: LoadField: r2 = r1->field_b
    //     0xb1cb58: ldur            w2, [x1, #0xb]
    // 0xb1cb5c: DecompressPointer r2
    //     0xb1cb5c: add             x2, x2, HEAP, lsl #32
    // 0xb1cb60: ldur            x16, [fp, #-8]
    // 0xb1cb64: stp             x16, x2, [SP, #-0x10]!
    // 0xb1cb68: r0 = -()
    //     0xb1cb68: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0xb1cb6c: add             SP, SP, #0x10
    // 0xb1cb70: stur            x0, [fp, #-8]
    // 0xb1cb74: r0 = DesktopTextSelectionToolbarLayoutDelegate()
    //     0xb1cb74: bl              #0xb1cd20  ; AllocateDesktopTextSelectionToolbarLayoutDelegateStub -> DesktopTextSelectionToolbarLayoutDelegate (size=0x10)
    // 0xb1cb78: mov             x1, x0
    // 0xb1cb7c: ldur            x0, [fp, #-8]
    // 0xb1cb80: stur            x1, [fp, #-0x18]
    // 0xb1cb84: StoreField: r1->field_b = r0
    //     0xb1cb84: stur            w0, [x1, #0xb]
    // 0xb1cb88: ldr             x0, [fp, #0x18]
    // 0xb1cb8c: LoadField: r2 = r0->field_f
    //     0xb1cb8c: ldur            w2, [x0, #0xf]
    // 0xb1cb90: DecompressPointer r2
    //     0xb1cb90: add             x2, x2, HEAP, lsl #32
    // 0xb1cb94: stur            x2, [fp, #-8]
    // 0xb1cb98: r0 = Column()
    //     0xb1cb98: bl              #0x825234  ; AllocateColumnStub -> Column (size=0x30)
    // 0xb1cb9c: stur            x0, [fp, #-0x20]
    // 0xb1cba0: ldur            x16, [fp, #-8]
    // 0xb1cba4: stp             x16, x0, [SP, #-0x10]!
    // 0xb1cba8: r16 = Instance_MainAxisSize
    //     0xb1cba8: add             x16, PP, #0xe, lsl #12  ; [pp+0xeeb0] Obj!MainAxisSize@b64b71
    //     0xb1cbac: ldr             x16, [x16, #0xeb0]
    // 0xb1cbb0: SaveReg r16
    //     0xb1cbb0: str             x16, [SP, #-8]!
    // 0xb1cbb4: r4 = const [0, 0x3, 0x3, 0x2, mainAxisSize, 0x2, null]
    //     0xb1cbb4: add             x4, PP, #0xe, lsl #12  ; [pp+0xeeb8] List(7) [0, 0x3, 0x3, 0x2, "mainAxisSize", 0x2, Null]
    //     0xb1cbb8: ldr             x4, [x4, #0xeb8]
    // 0xb1cbbc: r0 = Column()
    //     0xb1cbbc: bl              #0x8250c8  ; [package:flutter/src/widgets/basic.dart] Column::Column
    // 0xb1cbc0: add             SP, SP, #0x18
    // 0xb1cbc4: ldr             x16, [fp, #0x10]
    // 0xb1cbc8: ldur            lr, [fp, #-0x20]
    // 0xb1cbcc: stp             lr, x16, [SP, #-0x10]!
    // 0xb1cbd0: r0 = _defaultToolbarBuilder()
    //     0xb1cbd0: bl              #0xb1cc20  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar.dart] CupertinoDesktopTextSelectionToolbar::_defaultToolbarBuilder
    // 0xb1cbd4: add             SP, SP, #0x10
    // 0xb1cbd8: stur            x0, [fp, #-8]
    // 0xb1cbdc: r0 = CustomSingleChildLayout()
    //     0xb1cbdc: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xb1cbe0: mov             x1, x0
    // 0xb1cbe4: ldur            x0, [fp, #-0x18]
    // 0xb1cbe8: stur            x1, [fp, #-0x20]
    // 0xb1cbec: StoreField: r1->field_f = r0
    //     0xb1cbec: stur            w0, [x1, #0xf]
    // 0xb1cbf0: ldur            x0, [fp, #-8]
    // 0xb1cbf4: StoreField: r1->field_b = r0
    //     0xb1cbf4: stur            w0, [x1, #0xb]
    // 0xb1cbf8: r0 = Padding()
    //     0xb1cbf8: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1cbfc: ldur            x1, [fp, #-0x10]
    // 0xb1cc00: StoreField: r0->field_f = r1
    //     0xb1cc00: stur            w1, [x0, #0xf]
    // 0xb1cc04: ldur            x1, [fp, #-0x20]
    // 0xb1cc08: StoreField: r0->field_b = r1
    //     0xb1cc08: stur            w1, [x0, #0xb]
    // 0xb1cc0c: LeaveFrame
    //     0xb1cc0c: mov             SP, fp
    //     0xb1cc10: ldp             fp, lr, [SP], #0x10
    // 0xb1cc14: ret
    //     0xb1cc14: ret             
    // 0xb1cc18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cc18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cc1c: b               #0xb1caf4
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0xb1cc20, size: 0x100
    // 0xb1cc20: EnterFrame
    //     0xb1cc20: stp             fp, lr, [SP, #-0x10]!
    //     0xb1cc24: mov             fp, SP
    // 0xb1cc28: AllocStack(0x18)
    //     0xb1cc28: sub             SP, SP, #0x18
    // 0xb1cc2c: CheckStackOverflow
    //     0xb1cc2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1cc30: cmp             SP, x16
    //     0xb1cc34: b.ls            #0xb1cd18
    // 0xb1cc38: r16 = Instance_CupertinoDynamicColor
    //     0xb1cc38: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2eb98] Obj!CupertinoDynamicColor@b5e771
    //     0xb1cc3c: ldr             x16, [x16, #0xb98]
    // 0xb1cc40: ldr             lr, [fp, #0x18]
    // 0xb1cc44: stp             lr, x16, [SP, #-0x10]!
    // 0xb1cc48: r0 = resolveFrom()
    //     0xb1cc48: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xb1cc4c: add             SP, SP, #0x10
    // 0xb1cc50: stur            x0, [fp, #-8]
    // 0xb1cc54: r16 = Instance_CupertinoDynamicColor
    //     0xb1cc54: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2eba0] Obj!CupertinoDynamicColor@b5e731
    //     0xb1cc58: ldr             x16, [x16, #0xba0]
    // 0xb1cc5c: ldr             lr, [fp, #0x18]
    // 0xb1cc60: stp             lr, x16, [SP, #-0x10]!
    // 0xb1cc64: r0 = resolveFrom()
    //     0xb1cc64: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xb1cc68: add             SP, SP, #0x10
    // 0xb1cc6c: stp             x0, NULL, [SP, #-0x10]!
    // 0xb1cc70: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0xb1cc70: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0xb1cc74: ldr             x4, [x4, #0x168]
    // 0xb1cc78: r0 = Border.all()
    //     0xb1cc78: bl              #0x898df8  ; [package:flutter/src/painting/box_border.dart] Border::Border.all
    // 0xb1cc7c: add             SP, SP, #0x10
    // 0xb1cc80: stur            x0, [fp, #-0x10]
    // 0xb1cc84: r0 = BoxDecoration()
    //     0xb1cc84: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0xb1cc88: mov             x1, x0
    // 0xb1cc8c: ldur            x0, [fp, #-8]
    // 0xb1cc90: stur            x1, [fp, #-0x18]
    // 0xb1cc94: StoreField: r1->field_7 = r0
    //     0xb1cc94: stur            w0, [x1, #7]
    // 0xb1cc98: ldur            x0, [fp, #-0x10]
    // 0xb1cc9c: StoreField: r1->field_f = r0
    //     0xb1cc9c: stur            w0, [x1, #0xf]
    // 0xb1cca0: r0 = Instance_BorderRadius
    //     0xb1cca0: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2eba8] Obj!BorderRadius@b37551
    //     0xb1cca4: ldr             x0, [x0, #0xba8]
    // 0xb1cca8: StoreField: r1->field_13 = r0
    //     0xb1cca8: stur            w0, [x1, #0x13]
    // 0xb1ccac: r0 = Instance_BoxShape
    //     0xb1ccac: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0xb1ccb0: ldr             x0, [x0, #0xe68]
    // 0xb1ccb4: StoreField: r1->field_23 = r0
    //     0xb1ccb4: stur            w0, [x1, #0x23]
    // 0xb1ccb8: r0 = Padding()
    //     0xb1ccb8: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1ccbc: mov             x1, x0
    // 0xb1ccc0: r0 = Instance_EdgeInsets
    //     0xb1ccc0: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2ebb0] Obj!EdgeInsets@b37041
    //     0xb1ccc4: ldr             x0, [x0, #0xbb0]
    // 0xb1ccc8: stur            x1, [fp, #-8]
    // 0xb1cccc: StoreField: r1->field_f = r0
    //     0xb1cccc: stur            w0, [x1, #0xf]
    // 0xb1ccd0: ldr             x0, [fp, #0x10]
    // 0xb1ccd4: StoreField: r1->field_b = r0
    //     0xb1ccd4: stur            w0, [x1, #0xb]
    // 0xb1ccd8: r0 = Container()
    //     0xb1ccd8: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xb1ccdc: stur            x0, [fp, #-0x10]
    // 0xb1cce0: r16 = 222.000000
    //     0xb1cce0: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2e5a8] 222
    //     0xb1cce4: ldr             x16, [x16, #0x5a8]
    // 0xb1cce8: stp             x16, x0, [SP, #-0x10]!
    // 0xb1ccec: ldur            x16, [fp, #-0x18]
    // 0xb1ccf0: ldur            lr, [fp, #-8]
    // 0xb1ccf4: stp             lr, x16, [SP, #-0x10]!
    // 0xb1ccf8: r4 = const [0, 0x4, 0x4, 0x1, child, 0x3, decoration, 0x2, width, 0x1, null]
    //     0xb1ccf8: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2c070] List(11) [0, 0x4, 0x4, 0x1, "child", 0x3, "decoration", 0x2, "width", 0x1, Null]
    //     0xb1ccfc: ldr             x4, [x4, #0x70]
    // 0xb1cd00: r0 = Container()
    //     0xb1cd00: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xb1cd04: add             SP, SP, #0x20
    // 0xb1cd08: ldur            x0, [fp, #-0x10]
    // 0xb1cd0c: LeaveFrame
    //     0xb1cd0c: mov             SP, fp
    //     0xb1cd10: ldp             fp, lr, [SP], #0x10
    // 0xb1cd14: ret
    //     0xb1cd14: ret             
    // 0xb1cd18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1cd18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1cd1c: b               #0xb1cc38
  }
}

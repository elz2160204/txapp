// lib: , url: package:flutter/src/cupertino/dialog.dart

// class id: 1049087, size: 0x8
class :: {
}

// class id: 2527, size: 0x70, field offset: 0x60
//   transformed mixin,
abstract class __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin extends RenderBox
     with ContainerRenderObjectMixin<X0 bound RenderObject, X1 bound ContainerParentDataMixin<X0 bound RenderObject>> {

  _ move(/* No info */) {
    // ** addr: 0x5aeb70, size: 0x170
    // 0x5aeb70: EnterFrame
    //     0x5aeb70: stp             fp, lr, [SP, #-0x10]!
    //     0x5aeb74: mov             fp, SP
    // 0x5aeb78: AllocStack(0x8)
    //     0x5aeb78: sub             SP, SP, #8
    // 0x5aeb7c: CheckStackOverflow
    //     0x5aeb7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5aeb80: cmp             SP, x16
    //     0x5aeb84: b.ls            #0x5aecd4
    // 0x5aeb88: ldr             x0, [fp, #0x18]
    // 0x5aeb8c: r2 = Null
    //     0x5aeb8c: mov             x2, NULL
    // 0x5aeb90: r1 = Null
    //     0x5aeb90: mov             x1, NULL
    // 0x5aeb94: r4 = 59
    //     0x5aeb94: mov             x4, #0x3b
    // 0x5aeb98: branchIfSmi(r0, 0x5aeba4)
    //     0x5aeb98: tbz             w0, #0, #0x5aeba4
    // 0x5aeb9c: r4 = LoadClassIdInstr(r0)
    //     0x5aeb9c: ldur            x4, [x0, #-1]
    //     0x5aeba0: ubfx            x4, x4, #0xc, #0x14
    // 0x5aeba4: sub             x4, x4, #0x965
    // 0x5aeba8: cmp             x4, #0x8b
    // 0x5aebac: b.ls            #0x5aebc4
    // 0x5aebb0: r8 = RenderBox
    //     0x5aebb0: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5aebb4: ldr             x8, [x8, #0xfa0]
    // 0x5aebb8: r3 = Null
    //     0x5aebb8: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea10] Null
    //     0x5aebbc: ldr             x3, [x3, #0xa10]
    // 0x5aebc0: r0 = RenderBox()
    //     0x5aebc0: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5aebc4: ldr             x0, [fp, #0x10]
    // 0x5aebc8: r2 = Null
    //     0x5aebc8: mov             x2, NULL
    // 0x5aebcc: r1 = Null
    //     0x5aebcc: mov             x1, NULL
    // 0x5aebd0: r4 = 59
    //     0x5aebd0: mov             x4, #0x3b
    // 0x5aebd4: branchIfSmi(r0, 0x5aebe0)
    //     0x5aebd4: tbz             w0, #0, #0x5aebe0
    // 0x5aebd8: r4 = LoadClassIdInstr(r0)
    //     0x5aebd8: ldur            x4, [x0, #-1]
    //     0x5aebdc: ubfx            x4, x4, #0xc, #0x14
    // 0x5aebe0: sub             x4, x4, #0x965
    // 0x5aebe4: cmp             x4, #0x8b
    // 0x5aebe8: b.ls            #0x5aebfc
    // 0x5aebec: r8 = RenderBox?
    //     0x5aebec: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5aebf0: r3 = Null
    //     0x5aebf0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea20] Null
    //     0x5aebf4: ldr             x3, [x3, #0xa20]
    // 0x5aebf8: r0 = RenderBox?()
    //     0x5aebf8: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5aebfc: ldr             x3, [fp, #0x18]
    // 0x5aec00: LoadField: r4 = r3->field_17
    //     0x5aec00: ldur            w4, [x3, #0x17]
    // 0x5aec04: DecompressPointer r4
    //     0x5aec04: add             x4, x4, HEAP, lsl #32
    // 0x5aec08: stur            x4, [fp, #-8]
    // 0x5aec0c: cmp             w4, NULL
    // 0x5aec10: b.eq            #0x5aecdc
    // 0x5aec14: mov             x0, x4
    // 0x5aec18: r2 = Null
    //     0x5aec18: mov             x2, NULL
    // 0x5aec1c: r1 = Null
    //     0x5aec1c: mov             x1, NULL
    // 0x5aec20: r4 = LoadClassIdInstr(r0)
    //     0x5aec20: ldur            x4, [x0, #-1]
    //     0x5aec24: ubfx            x4, x4, #0xc, #0x14
    // 0x5aec28: cmp             x4, #0x80a
    // 0x5aec2c: b.eq            #0x5aec44
    // 0x5aec30: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5aec30: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5aec34: ldr             x8, [x8, #0x170]
    // 0x5aec38: r3 = Null
    //     0x5aec38: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea30] Null
    //     0x5aec3c: ldr             x3, [x3, #0xa30]
    // 0x5aec40: r0 = DefaultTypeTest()
    //     0x5aec40: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5aec44: ldur            x0, [fp, #-8]
    // 0x5aec48: LoadField: r1 = r0->field_f
    //     0x5aec48: ldur            w1, [x0, #0xf]
    // 0x5aec4c: DecompressPointer r1
    //     0x5aec4c: add             x1, x1, HEAP, lsl #32
    // 0x5aec50: r0 = LoadClassIdInstr(r1)
    //     0x5aec50: ldur            x0, [x1, #-1]
    //     0x5aec54: ubfx            x0, x0, #0xc, #0x14
    // 0x5aec58: ldr             x16, [fp, #0x10]
    // 0x5aec5c: stp             x16, x1, [SP, #-0x10]!
    // 0x5aec60: mov             lr, x0
    // 0x5aec64: ldr             lr, [x21, lr, lsl #3]
    // 0x5aec68: blr             lr
    // 0x5aec6c: add             SP, SP, #0x10
    // 0x5aec70: tbnz            w0, #4, #0x5aec84
    // 0x5aec74: r0 = Null
    //     0x5aec74: mov             x0, NULL
    // 0x5aec78: LeaveFrame
    //     0x5aec78: mov             SP, fp
    //     0x5aec7c: ldp             fp, lr, [SP], #0x10
    // 0x5aec80: ret
    //     0x5aec80: ret             
    // 0x5aec84: ldr             x16, [fp, #0x20]
    // 0x5aec88: ldr             lr, [fp, #0x18]
    // 0x5aec8c: stp             lr, x16, [SP, #-0x10]!
    // 0x5aec90: r0 = _removeFromChildList()
    //     0x5aec90: bl              #0x5af240  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5aec94: add             SP, SP, #0x10
    // 0x5aec98: ldr             x16, [fp, #0x20]
    // 0x5aec9c: ldr             lr, [fp, #0x18]
    // 0x5aeca0: stp             lr, x16, [SP, #-0x10]!
    // 0x5aeca4: ldr             x16, [fp, #0x10]
    // 0x5aeca8: SaveReg r16
    //     0x5aeca8: str             x16, [SP, #-8]!
    // 0x5aecac: r0 = _insertIntoChildList()
    //     0x5aecac: bl              #0x5aece0  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5aecb0: add             SP, SP, #0x18
    // 0x5aecb4: ldr             x16, [fp, #0x20]
    // 0x5aecb8: SaveReg r16
    //     0x5aecb8: str             x16, [SP, #-8]!
    // 0x5aecbc: r0 = markNeedsLayout()
    //     0x5aecbc: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x5aecc0: add             SP, SP, #8
    // 0x5aecc4: r0 = Null
    //     0x5aecc4: mov             x0, NULL
    // 0x5aecc8: LeaveFrame
    //     0x5aecc8: mov             SP, fp
    //     0x5aeccc: ldp             fp, lr, [SP], #0x10
    // 0x5aecd0: ret
    //     0x5aecd0: ret             
    // 0x5aecd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aecd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5aecd8: b               #0x5aeb88
    // 0x5aecdc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5aecdc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _insertIntoChildList(/* No info */) {
    // ** addr: 0x5aece0, size: 0x560
    // 0x5aece0: EnterFrame
    //     0x5aece0: stp             fp, lr, [SP, #-0x10]!
    //     0x5aece4: mov             fp, SP
    // 0x5aece8: AllocStack(0x20)
    //     0x5aece8: sub             SP, SP, #0x20
    // 0x5aecec: ldr             x3, [fp, #0x18]
    // 0x5aecf0: LoadField: r4 = r3->field_17
    //     0x5aecf0: ldur            w4, [x3, #0x17]
    // 0x5aecf4: DecompressPointer r4
    //     0x5aecf4: add             x4, x4, HEAP, lsl #32
    // 0x5aecf8: stur            x4, [fp, #-8]
    // 0x5aecfc: cmp             w4, NULL
    // 0x5aed00: b.eq            #0x5af230
    // 0x5aed04: mov             x0, x4
    // 0x5aed08: r2 = Null
    //     0x5aed08: mov             x2, NULL
    // 0x5aed0c: r1 = Null
    //     0x5aed0c: mov             x1, NULL
    // 0x5aed10: r4 = LoadClassIdInstr(r0)
    //     0x5aed10: ldur            x4, [x0, #-1]
    //     0x5aed14: ubfx            x4, x4, #0xc, #0x14
    // 0x5aed18: cmp             x4, #0x80a
    // 0x5aed1c: b.eq            #0x5aed34
    // 0x5aed20: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5aed20: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5aed24: ldr             x8, [x8, #0x170]
    // 0x5aed28: r3 = Null
    //     0x5aed28: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea40] Null
    //     0x5aed2c: ldr             x3, [x3, #0xa40]
    // 0x5aed30: r0 = DefaultTypeTest()
    //     0x5aed30: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5aed34: ldr             x3, [fp, #0x20]
    // 0x5aed38: LoadField: r0 = r3->field_5f
    //     0x5aed38: ldur            x0, [x3, #0x5f]
    // 0x5aed3c: add             x1, x0, #1
    // 0x5aed40: StoreField: r3->field_5f = r1
    //     0x5aed40: stur            x1, [x3, #0x5f]
    // 0x5aed44: ldr             x4, [fp, #0x10]
    // 0x5aed48: cmp             w4, NULL
    // 0x5aed4c: b.ne            #0x5aeed4
    // 0x5aed50: ldur            x4, [fp, #-8]
    // 0x5aed54: LoadField: r5 = r3->field_67
    //     0x5aed54: ldur            w5, [x3, #0x67]
    // 0x5aed58: DecompressPointer r5
    //     0x5aed58: add             x5, x5, HEAP, lsl #32
    // 0x5aed5c: stur            x5, [fp, #-0x10]
    // 0x5aed60: LoadField: r2 = r4->field_b
    //     0x5aed60: ldur            w2, [x4, #0xb]
    // 0x5aed64: DecompressPointer r2
    //     0x5aed64: add             x2, x2, HEAP, lsl #32
    // 0x5aed68: mov             x0, x5
    // 0x5aed6c: r1 = Null
    //     0x5aed6c: mov             x1, NULL
    // 0x5aed70: cmp             w0, NULL
    // 0x5aed74: b.eq            #0x5aeda0
    // 0x5aed78: cmp             w2, NULL
    // 0x5aed7c: b.eq            #0x5aeda0
    // 0x5aed80: LoadField: r4 = r2->field_17
    //     0x5aed80: ldur            w4, [x2, #0x17]
    // 0x5aed84: DecompressPointer r4
    //     0x5aed84: add             x4, x4, HEAP, lsl #32
    // 0x5aed88: r8 = X0? bound RenderObject
    //     0x5aed88: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5aed8c: ldr             x8, [x8, #0x6e8]
    // 0x5aed90: LoadField: r9 = r4->field_7
    //     0x5aed90: ldur            x9, [x4, #7]
    // 0x5aed94: r3 = Null
    //     0x5aed94: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea50] Null
    //     0x5aed98: ldr             x3, [x3, #0xa50]
    // 0x5aed9c: blr             x9
    // 0x5aeda0: ldur            x0, [fp, #-0x10]
    // 0x5aeda4: ldur            x3, [fp, #-8]
    // 0x5aeda8: StoreField: r3->field_13 = r0
    //     0x5aeda8: stur            w0, [x3, #0x13]
    //     0x5aedac: ldurb           w16, [x3, #-1]
    //     0x5aedb0: ldurb           w17, [x0, #-1]
    //     0x5aedb4: and             x16, x17, x16, lsr #2
    //     0x5aedb8: tst             x16, HEAP, lsr #32
    //     0x5aedbc: b.eq            #0x5aedc4
    //     0x5aedc0: bl              #0xd682ac
    // 0x5aedc4: ldur            x0, [fp, #-0x10]
    // 0x5aedc8: cmp             w0, NULL
    // 0x5aedcc: b.eq            #0x5aee7c
    // 0x5aedd0: LoadField: r3 = r0->field_17
    //     0x5aedd0: ldur            w3, [x0, #0x17]
    // 0x5aedd4: DecompressPointer r3
    //     0x5aedd4: add             x3, x3, HEAP, lsl #32
    // 0x5aedd8: stur            x3, [fp, #-0x18]
    // 0x5aeddc: cmp             w3, NULL
    // 0x5aede0: b.eq            #0x5af234
    // 0x5aede4: mov             x0, x3
    // 0x5aede8: r2 = Null
    //     0x5aede8: mov             x2, NULL
    // 0x5aedec: r1 = Null
    //     0x5aedec: mov             x1, NULL
    // 0x5aedf0: r4 = LoadClassIdInstr(r0)
    //     0x5aedf0: ldur            x4, [x0, #-1]
    //     0x5aedf4: ubfx            x4, x4, #0xc, #0x14
    // 0x5aedf8: cmp             x4, #0x80a
    // 0x5aedfc: b.eq            #0x5aee14
    // 0x5aee00: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5aee00: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5aee04: ldr             x8, [x8, #0x170]
    // 0x5aee08: r3 = Null
    //     0x5aee08: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea60] Null
    //     0x5aee0c: ldr             x3, [x3, #0xa60]
    // 0x5aee10: r0 = DefaultTypeTest()
    //     0x5aee10: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5aee14: ldur            x3, [fp, #-0x18]
    // 0x5aee18: LoadField: r2 = r3->field_b
    //     0x5aee18: ldur            w2, [x3, #0xb]
    // 0x5aee1c: DecompressPointer r2
    //     0x5aee1c: add             x2, x2, HEAP, lsl #32
    // 0x5aee20: ldr             x0, [fp, #0x18]
    // 0x5aee24: r1 = Null
    //     0x5aee24: mov             x1, NULL
    // 0x5aee28: cmp             w0, NULL
    // 0x5aee2c: b.eq            #0x5aee58
    // 0x5aee30: cmp             w2, NULL
    // 0x5aee34: b.eq            #0x5aee58
    // 0x5aee38: LoadField: r4 = r2->field_17
    //     0x5aee38: ldur            w4, [x2, #0x17]
    // 0x5aee3c: DecompressPointer r4
    //     0x5aee3c: add             x4, x4, HEAP, lsl #32
    // 0x5aee40: r8 = X0? bound RenderObject
    //     0x5aee40: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5aee44: ldr             x8, [x8, #0x6e8]
    // 0x5aee48: LoadField: r9 = r4->field_7
    //     0x5aee48: ldur            x9, [x4, #7]
    // 0x5aee4c: r3 = Null
    //     0x5aee4c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea70] Null
    //     0x5aee50: ldr             x3, [x3, #0xa70]
    // 0x5aee54: blr             x9
    // 0x5aee58: ldr             x0, [fp, #0x18]
    // 0x5aee5c: ldur            x1, [fp, #-0x18]
    // 0x5aee60: StoreField: r1->field_f = r0
    //     0x5aee60: stur            w0, [x1, #0xf]
    //     0x5aee64: ldurb           w16, [x1, #-1]
    //     0x5aee68: ldurb           w17, [x0, #-1]
    //     0x5aee6c: and             x16, x17, x16, lsr #2
    //     0x5aee70: tst             x16, HEAP, lsr #32
    //     0x5aee74: b.eq            #0x5aee7c
    //     0x5aee78: bl              #0xd6826c
    // 0x5aee7c: ldr             x5, [fp, #0x20]
    // 0x5aee80: ldr             x0, [fp, #0x18]
    // 0x5aee84: StoreField: r5->field_67 = r0
    //     0x5aee84: stur            w0, [x5, #0x67]
    //     0x5aee88: ldurb           w16, [x5, #-1]
    //     0x5aee8c: ldurb           w17, [x0, #-1]
    //     0x5aee90: and             x16, x17, x16, lsr #2
    //     0x5aee94: tst             x16, HEAP, lsr #32
    //     0x5aee98: b.eq            #0x5aeea0
    //     0x5aee9c: bl              #0xd682ec
    // 0x5aeea0: LoadField: r0 = r5->field_6b
    //     0x5aeea0: ldur            w0, [x5, #0x6b]
    // 0x5aeea4: DecompressPointer r0
    //     0x5aeea4: add             x0, x0, HEAP, lsl #32
    // 0x5aeea8: cmp             w0, NULL
    // 0x5aeeac: b.ne            #0x5af220
    // 0x5aeeb0: ldr             x0, [fp, #0x18]
    // 0x5aeeb4: StoreField: r5->field_6b = r0
    //     0x5aeeb4: stur            w0, [x5, #0x6b]
    //     0x5aeeb8: ldurb           w16, [x5, #-1]
    //     0x5aeebc: ldurb           w17, [x0, #-1]
    //     0x5aeec0: and             x16, x17, x16, lsr #2
    //     0x5aeec4: tst             x16, HEAP, lsr #32
    //     0x5aeec8: b.eq            #0x5aeed0
    //     0x5aeecc: bl              #0xd682ec
    // 0x5aeed0: b               #0x5af220
    // 0x5aeed4: mov             x5, x3
    // 0x5aeed8: ldur            x3, [fp, #-8]
    // 0x5aeedc: LoadField: r6 = r4->field_17
    //     0x5aeedc: ldur            w6, [x4, #0x17]
    // 0x5aeee0: DecompressPointer r6
    //     0x5aeee0: add             x6, x6, HEAP, lsl #32
    // 0x5aeee4: stur            x6, [fp, #-0x10]
    // 0x5aeee8: cmp             w6, NULL
    // 0x5aeeec: b.eq            #0x5af238
    // 0x5aeef0: mov             x0, x6
    // 0x5aeef4: r2 = Null
    //     0x5aeef4: mov             x2, NULL
    // 0x5aeef8: r1 = Null
    //     0x5aeef8: mov             x1, NULL
    // 0x5aeefc: r4 = LoadClassIdInstr(r0)
    //     0x5aeefc: ldur            x4, [x0, #-1]
    //     0x5aef00: ubfx            x4, x4, #0xc, #0x14
    // 0x5aef04: cmp             x4, #0x80a
    // 0x5aef08: b.eq            #0x5aef20
    // 0x5aef0c: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5aef0c: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5aef10: ldr             x8, [x8, #0x170]
    // 0x5aef14: r3 = Null
    //     0x5aef14: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea80] Null
    //     0x5aef18: ldr             x3, [x3, #0xa80]
    // 0x5aef1c: r0 = DefaultTypeTest()
    //     0x5aef1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5aef20: ldur            x3, [fp, #-0x10]
    // 0x5aef24: LoadField: r4 = r3->field_13
    //     0x5aef24: ldur            w4, [x3, #0x13]
    // 0x5aef28: DecompressPointer r4
    //     0x5aef28: add             x4, x4, HEAP, lsl #32
    // 0x5aef2c: stur            x4, [fp, #-0x20]
    // 0x5aef30: cmp             w4, NULL
    // 0x5aef34: b.ne            #0x5af034
    // 0x5aef38: ldr             x5, [fp, #0x20]
    // 0x5aef3c: ldur            x4, [fp, #-8]
    // 0x5aef40: LoadField: r2 = r4->field_b
    //     0x5aef40: ldur            w2, [x4, #0xb]
    // 0x5aef44: DecompressPointer r2
    //     0x5aef44: add             x2, x2, HEAP, lsl #32
    // 0x5aef48: ldr             x0, [fp, #0x10]
    // 0x5aef4c: r1 = Null
    //     0x5aef4c: mov             x1, NULL
    // 0x5aef50: cmp             w0, NULL
    // 0x5aef54: b.eq            #0x5aef80
    // 0x5aef58: cmp             w2, NULL
    // 0x5aef5c: b.eq            #0x5aef80
    // 0x5aef60: LoadField: r4 = r2->field_17
    //     0x5aef60: ldur            w4, [x2, #0x17]
    // 0x5aef64: DecompressPointer r4
    //     0x5aef64: add             x4, x4, HEAP, lsl #32
    // 0x5aef68: r8 = X0? bound RenderObject
    //     0x5aef68: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5aef6c: ldr             x8, [x8, #0x6e8]
    // 0x5aef70: LoadField: r9 = r4->field_7
    //     0x5aef70: ldur            x9, [x4, #7]
    // 0x5aef74: r3 = Null
    //     0x5aef74: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea90] Null
    //     0x5aef78: ldr             x3, [x3, #0xa90]
    // 0x5aef7c: blr             x9
    // 0x5aef80: ldr             x0, [fp, #0x10]
    // 0x5aef84: ldur            x3, [fp, #-8]
    // 0x5aef88: StoreField: r3->field_f = r0
    //     0x5aef88: stur            w0, [x3, #0xf]
    //     0x5aef8c: ldurb           w16, [x3, #-1]
    //     0x5aef90: ldurb           w17, [x0, #-1]
    //     0x5aef94: and             x16, x17, x16, lsr #2
    //     0x5aef98: tst             x16, HEAP, lsr #32
    //     0x5aef9c: b.eq            #0x5aefa4
    //     0x5aefa0: bl              #0xd682ac
    // 0x5aefa4: ldur            x3, [fp, #-0x10]
    // 0x5aefa8: LoadField: r2 = r3->field_b
    //     0x5aefa8: ldur            w2, [x3, #0xb]
    // 0x5aefac: DecompressPointer r2
    //     0x5aefac: add             x2, x2, HEAP, lsl #32
    // 0x5aefb0: ldr             x0, [fp, #0x18]
    // 0x5aefb4: r1 = Null
    //     0x5aefb4: mov             x1, NULL
    // 0x5aefb8: cmp             w0, NULL
    // 0x5aefbc: b.eq            #0x5aefe8
    // 0x5aefc0: cmp             w2, NULL
    // 0x5aefc4: b.eq            #0x5aefe8
    // 0x5aefc8: LoadField: r4 = r2->field_17
    //     0x5aefc8: ldur            w4, [x2, #0x17]
    // 0x5aefcc: DecompressPointer r4
    //     0x5aefcc: add             x4, x4, HEAP, lsl #32
    // 0x5aefd0: r8 = X0? bound RenderObject
    //     0x5aefd0: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5aefd4: ldr             x8, [x8, #0x6e8]
    // 0x5aefd8: LoadField: r9 = r4->field_7
    //     0x5aefd8: ldur            x9, [x4, #7]
    // 0x5aefdc: r3 = Null
    //     0x5aefdc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eaa0] Null
    //     0x5aefe0: ldr             x3, [x3, #0xaa0]
    // 0x5aefe4: blr             x9
    // 0x5aefe8: ldr             x0, [fp, #0x18]
    // 0x5aefec: ldur            x5, [fp, #-0x10]
    // 0x5aeff0: StoreField: r5->field_13 = r0
    //     0x5aeff0: stur            w0, [x5, #0x13]
    //     0x5aeff4: ldurb           w16, [x5, #-1]
    //     0x5aeff8: ldurb           w17, [x0, #-1]
    //     0x5aeffc: and             x16, x17, x16, lsr #2
    //     0x5af000: tst             x16, HEAP, lsr #32
    //     0x5af004: b.eq            #0x5af00c
    //     0x5af008: bl              #0xd682ec
    // 0x5af00c: ldr             x0, [fp, #0x18]
    // 0x5af010: ldr             x1, [fp, #0x20]
    // 0x5af014: StoreField: r1->field_6b = r0
    //     0x5af014: stur            w0, [x1, #0x6b]
    //     0x5af018: ldurb           w16, [x1, #-1]
    //     0x5af01c: ldurb           w17, [x0, #-1]
    //     0x5af020: and             x16, x17, x16, lsr #2
    //     0x5af024: tst             x16, HEAP, lsr #32
    //     0x5af028: b.eq            #0x5af030
    //     0x5af02c: bl              #0xd6826c
    // 0x5af030: b               #0x5af220
    // 0x5af034: mov             x5, x3
    // 0x5af038: ldur            x3, [fp, #-8]
    // 0x5af03c: LoadField: r6 = r3->field_b
    //     0x5af03c: ldur            w6, [x3, #0xb]
    // 0x5af040: DecompressPointer r6
    //     0x5af040: add             x6, x6, HEAP, lsl #32
    // 0x5af044: mov             x0, x4
    // 0x5af048: mov             x2, x6
    // 0x5af04c: stur            x6, [fp, #-0x18]
    // 0x5af050: r1 = Null
    //     0x5af050: mov             x1, NULL
    // 0x5af054: cmp             w0, NULL
    // 0x5af058: b.eq            #0x5af084
    // 0x5af05c: cmp             w2, NULL
    // 0x5af060: b.eq            #0x5af084
    // 0x5af064: LoadField: r4 = r2->field_17
    //     0x5af064: ldur            w4, [x2, #0x17]
    // 0x5af068: DecompressPointer r4
    //     0x5af068: add             x4, x4, HEAP, lsl #32
    // 0x5af06c: r8 = X0? bound RenderObject
    //     0x5af06c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af070: ldr             x8, [x8, #0x6e8]
    // 0x5af074: LoadField: r9 = r4->field_7
    //     0x5af074: ldur            x9, [x4, #7]
    // 0x5af078: r3 = Null
    //     0x5af078: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eab0] Null
    //     0x5af07c: ldr             x3, [x3, #0xab0]
    // 0x5af080: blr             x9
    // 0x5af084: ldur            x0, [fp, #-0x20]
    // 0x5af088: ldur            x3, [fp, #-8]
    // 0x5af08c: StoreField: r3->field_13 = r0
    //     0x5af08c: stur            w0, [x3, #0x13]
    //     0x5af090: ldurb           w16, [x3, #-1]
    //     0x5af094: ldurb           w17, [x0, #-1]
    //     0x5af098: and             x16, x17, x16, lsr #2
    //     0x5af09c: tst             x16, HEAP, lsr #32
    //     0x5af0a0: b.eq            #0x5af0a8
    //     0x5af0a4: bl              #0xd682ac
    // 0x5af0a8: ldr             x0, [fp, #0x10]
    // 0x5af0ac: ldur            x2, [fp, #-0x18]
    // 0x5af0b0: r1 = Null
    //     0x5af0b0: mov             x1, NULL
    // 0x5af0b4: cmp             w0, NULL
    // 0x5af0b8: b.eq            #0x5af0e4
    // 0x5af0bc: cmp             w2, NULL
    // 0x5af0c0: b.eq            #0x5af0e4
    // 0x5af0c4: LoadField: r4 = r2->field_17
    //     0x5af0c4: ldur            w4, [x2, #0x17]
    // 0x5af0c8: DecompressPointer r4
    //     0x5af0c8: add             x4, x4, HEAP, lsl #32
    // 0x5af0cc: r8 = X0? bound RenderObject
    //     0x5af0cc: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af0d0: ldr             x8, [x8, #0x6e8]
    // 0x5af0d4: LoadField: r9 = r4->field_7
    //     0x5af0d4: ldur            x9, [x4, #7]
    // 0x5af0d8: r3 = Null
    //     0x5af0d8: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eac0] Null
    //     0x5af0dc: ldr             x3, [x3, #0xac0]
    // 0x5af0e0: blr             x9
    // 0x5af0e4: ldr             x0, [fp, #0x10]
    // 0x5af0e8: ldur            x1, [fp, #-8]
    // 0x5af0ec: StoreField: r1->field_f = r0
    //     0x5af0ec: stur            w0, [x1, #0xf]
    //     0x5af0f0: ldurb           w16, [x1, #-1]
    //     0x5af0f4: ldurb           w17, [x0, #-1]
    //     0x5af0f8: and             x16, x17, x16, lsr #2
    //     0x5af0fc: tst             x16, HEAP, lsr #32
    //     0x5af100: b.eq            #0x5af108
    //     0x5af104: bl              #0xd6826c
    // 0x5af108: ldur            x0, [fp, #-0x20]
    // 0x5af10c: LoadField: r3 = r0->field_17
    //     0x5af10c: ldur            w3, [x0, #0x17]
    // 0x5af110: DecompressPointer r3
    //     0x5af110: add             x3, x3, HEAP, lsl #32
    // 0x5af114: stur            x3, [fp, #-8]
    // 0x5af118: cmp             w3, NULL
    // 0x5af11c: b.eq            #0x5af23c
    // 0x5af120: mov             x0, x3
    // 0x5af124: r2 = Null
    //     0x5af124: mov             x2, NULL
    // 0x5af128: r1 = Null
    //     0x5af128: mov             x1, NULL
    // 0x5af12c: r4 = LoadClassIdInstr(r0)
    //     0x5af12c: ldur            x4, [x0, #-1]
    //     0x5af130: ubfx            x4, x4, #0xc, #0x14
    // 0x5af134: cmp             x4, #0x80a
    // 0x5af138: b.eq            #0x5af150
    // 0x5af13c: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5af13c: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5af140: ldr             x8, [x8, #0x170]
    // 0x5af144: r3 = Null
    //     0x5af144: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ead0] Null
    //     0x5af148: ldr             x3, [x3, #0xad0]
    // 0x5af14c: r0 = DefaultTypeTest()
    //     0x5af14c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af150: ldur            x3, [fp, #-0x10]
    // 0x5af154: LoadField: r2 = r3->field_b
    //     0x5af154: ldur            w2, [x3, #0xb]
    // 0x5af158: DecompressPointer r2
    //     0x5af158: add             x2, x2, HEAP, lsl #32
    // 0x5af15c: ldr             x0, [fp, #0x18]
    // 0x5af160: r1 = Null
    //     0x5af160: mov             x1, NULL
    // 0x5af164: cmp             w0, NULL
    // 0x5af168: b.eq            #0x5af194
    // 0x5af16c: cmp             w2, NULL
    // 0x5af170: b.eq            #0x5af194
    // 0x5af174: LoadField: r4 = r2->field_17
    //     0x5af174: ldur            w4, [x2, #0x17]
    // 0x5af178: DecompressPointer r4
    //     0x5af178: add             x4, x4, HEAP, lsl #32
    // 0x5af17c: r8 = X0? bound RenderObject
    //     0x5af17c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af180: ldr             x8, [x8, #0x6e8]
    // 0x5af184: LoadField: r9 = r4->field_7
    //     0x5af184: ldur            x9, [x4, #7]
    // 0x5af188: r3 = Null
    //     0x5af188: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eae0] Null
    //     0x5af18c: ldr             x3, [x3, #0xae0]
    // 0x5af190: blr             x9
    // 0x5af194: ldr             x0, [fp, #0x18]
    // 0x5af198: ldur            x1, [fp, #-0x10]
    // 0x5af19c: StoreField: r1->field_13 = r0
    //     0x5af19c: stur            w0, [x1, #0x13]
    //     0x5af1a0: ldurb           w16, [x1, #-1]
    //     0x5af1a4: ldurb           w17, [x0, #-1]
    //     0x5af1a8: and             x16, x17, x16, lsr #2
    //     0x5af1ac: tst             x16, HEAP, lsr #32
    //     0x5af1b0: b.eq            #0x5af1b8
    //     0x5af1b4: bl              #0xd6826c
    // 0x5af1b8: ldur            x3, [fp, #-8]
    // 0x5af1bc: LoadField: r2 = r3->field_b
    //     0x5af1bc: ldur            w2, [x3, #0xb]
    // 0x5af1c0: DecompressPointer r2
    //     0x5af1c0: add             x2, x2, HEAP, lsl #32
    // 0x5af1c4: ldr             x0, [fp, #0x18]
    // 0x5af1c8: r1 = Null
    //     0x5af1c8: mov             x1, NULL
    // 0x5af1cc: cmp             w0, NULL
    // 0x5af1d0: b.eq            #0x5af1fc
    // 0x5af1d4: cmp             w2, NULL
    // 0x5af1d8: b.eq            #0x5af1fc
    // 0x5af1dc: LoadField: r4 = r2->field_17
    //     0x5af1dc: ldur            w4, [x2, #0x17]
    // 0x5af1e0: DecompressPointer r4
    //     0x5af1e0: add             x4, x4, HEAP, lsl #32
    // 0x5af1e4: r8 = X0? bound RenderObject
    //     0x5af1e4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af1e8: ldr             x8, [x8, #0x6e8]
    // 0x5af1ec: LoadField: r9 = r4->field_7
    //     0x5af1ec: ldur            x9, [x4, #7]
    // 0x5af1f0: r3 = Null
    //     0x5af1f0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eaf0] Null
    //     0x5af1f4: ldr             x3, [x3, #0xaf0]
    // 0x5af1f8: blr             x9
    // 0x5af1fc: ldr             x0, [fp, #0x18]
    // 0x5af200: ldur            x1, [fp, #-8]
    // 0x5af204: StoreField: r1->field_f = r0
    //     0x5af204: stur            w0, [x1, #0xf]
    //     0x5af208: ldurb           w16, [x1, #-1]
    //     0x5af20c: ldurb           w17, [x0, #-1]
    //     0x5af210: and             x16, x17, x16, lsr #2
    //     0x5af214: tst             x16, HEAP, lsr #32
    //     0x5af218: b.eq            #0x5af220
    //     0x5af21c: bl              #0xd6826c
    // 0x5af220: r0 = Null
    //     0x5af220: mov             x0, NULL
    // 0x5af224: LeaveFrame
    //     0x5af224: mov             SP, fp
    //     0x5af228: ldp             fp, lr, [SP], #0x10
    // 0x5af22c: ret
    //     0x5af22c: ret             
    // 0x5af230: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af230: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5af234: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af234: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5af238: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af238: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5af23c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af23c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _removeFromChildList(/* No info */) {
    // ** addr: 0x5af240, size: 0x2c4
    // 0x5af240: EnterFrame
    //     0x5af240: stp             fp, lr, [SP, #-0x10]!
    //     0x5af244: mov             fp, SP
    // 0x5af248: AllocStack(0x20)
    //     0x5af248: sub             SP, SP, #0x20
    // 0x5af24c: ldr             x0, [fp, #0x10]
    // 0x5af250: LoadField: r3 = r0->field_17
    //     0x5af250: ldur            w3, [x0, #0x17]
    // 0x5af254: DecompressPointer r3
    //     0x5af254: add             x3, x3, HEAP, lsl #32
    // 0x5af258: stur            x3, [fp, #-8]
    // 0x5af25c: cmp             w3, NULL
    // 0x5af260: b.eq            #0x5af4f8
    // 0x5af264: mov             x0, x3
    // 0x5af268: r2 = Null
    //     0x5af268: mov             x2, NULL
    // 0x5af26c: r1 = Null
    //     0x5af26c: mov             x1, NULL
    // 0x5af270: r4 = LoadClassIdInstr(r0)
    //     0x5af270: ldur            x4, [x0, #-1]
    //     0x5af274: ubfx            x4, x4, #0xc, #0x14
    // 0x5af278: cmp             x4, #0x80a
    // 0x5af27c: b.eq            #0x5af294
    // 0x5af280: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5af280: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5af284: ldr             x8, [x8, #0x170]
    // 0x5af288: r3 = Null
    //     0x5af288: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb00] Null
    //     0x5af28c: ldr             x3, [x3, #0xb00]
    // 0x5af290: r0 = DefaultTypeTest()
    //     0x5af290: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af294: ldur            x3, [fp, #-8]
    // 0x5af298: LoadField: r4 = r3->field_f
    //     0x5af298: ldur            w4, [x3, #0xf]
    // 0x5af29c: DecompressPointer r4
    //     0x5af29c: add             x4, x4, HEAP, lsl #32
    // 0x5af2a0: stur            x4, [fp, #-0x18]
    // 0x5af2a4: cmp             w4, NULL
    // 0x5af2a8: b.ne            #0x5af2d8
    // 0x5af2ac: ldr             x5, [fp, #0x18]
    // 0x5af2b0: LoadField: r0 = r3->field_13
    //     0x5af2b0: ldur            w0, [x3, #0x13]
    // 0x5af2b4: DecompressPointer r0
    //     0x5af2b4: add             x0, x0, HEAP, lsl #32
    // 0x5af2b8: StoreField: r5->field_67 = r0
    //     0x5af2b8: stur            w0, [x5, #0x67]
    //     0x5af2bc: ldurb           w16, [x5, #-1]
    //     0x5af2c0: ldurb           w17, [x0, #-1]
    //     0x5af2c4: and             x16, x17, x16, lsr #2
    //     0x5af2c8: tst             x16, HEAP, lsr #32
    //     0x5af2cc: b.eq            #0x5af2d4
    //     0x5af2d0: bl              #0xd682ec
    // 0x5af2d4: b               #0x5af39c
    // 0x5af2d8: ldr             x5, [fp, #0x18]
    // 0x5af2dc: LoadField: r6 = r4->field_17
    //     0x5af2dc: ldur            w6, [x4, #0x17]
    // 0x5af2e0: DecompressPointer r6
    //     0x5af2e0: add             x6, x6, HEAP, lsl #32
    // 0x5af2e4: stur            x6, [fp, #-0x10]
    // 0x5af2e8: cmp             w6, NULL
    // 0x5af2ec: b.eq            #0x5af4fc
    // 0x5af2f0: mov             x0, x6
    // 0x5af2f4: r2 = Null
    //     0x5af2f4: mov             x2, NULL
    // 0x5af2f8: r1 = Null
    //     0x5af2f8: mov             x1, NULL
    // 0x5af2fc: r4 = LoadClassIdInstr(r0)
    //     0x5af2fc: ldur            x4, [x0, #-1]
    //     0x5af300: ubfx            x4, x4, #0xc, #0x14
    // 0x5af304: cmp             x4, #0x80a
    // 0x5af308: b.eq            #0x5af320
    // 0x5af30c: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5af30c: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5af310: ldr             x8, [x8, #0x170]
    // 0x5af314: r3 = Null
    //     0x5af314: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb10] Null
    //     0x5af318: ldr             x3, [x3, #0xb10]
    // 0x5af31c: r0 = DefaultTypeTest()
    //     0x5af31c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af320: ldur            x3, [fp, #-8]
    // 0x5af324: LoadField: r4 = r3->field_13
    //     0x5af324: ldur            w4, [x3, #0x13]
    // 0x5af328: DecompressPointer r4
    //     0x5af328: add             x4, x4, HEAP, lsl #32
    // 0x5af32c: ldur            x5, [fp, #-0x10]
    // 0x5af330: stur            x4, [fp, #-0x20]
    // 0x5af334: LoadField: r2 = r5->field_b
    //     0x5af334: ldur            w2, [x5, #0xb]
    // 0x5af338: DecompressPointer r2
    //     0x5af338: add             x2, x2, HEAP, lsl #32
    // 0x5af33c: mov             x0, x4
    // 0x5af340: r1 = Null
    //     0x5af340: mov             x1, NULL
    // 0x5af344: cmp             w0, NULL
    // 0x5af348: b.eq            #0x5af374
    // 0x5af34c: cmp             w2, NULL
    // 0x5af350: b.eq            #0x5af374
    // 0x5af354: LoadField: r4 = r2->field_17
    //     0x5af354: ldur            w4, [x2, #0x17]
    // 0x5af358: DecompressPointer r4
    //     0x5af358: add             x4, x4, HEAP, lsl #32
    // 0x5af35c: r8 = X0? bound RenderObject
    //     0x5af35c: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af360: ldr             x8, [x8, #0x6e8]
    // 0x5af364: LoadField: r9 = r4->field_7
    //     0x5af364: ldur            x9, [x4, #7]
    // 0x5af368: r3 = Null
    //     0x5af368: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb20] Null
    //     0x5af36c: ldr             x3, [x3, #0xb20]
    // 0x5af370: blr             x9
    // 0x5af374: ldur            x0, [fp, #-0x20]
    // 0x5af378: ldur            x1, [fp, #-0x10]
    // 0x5af37c: StoreField: r1->field_13 = r0
    //     0x5af37c: stur            w0, [x1, #0x13]
    //     0x5af380: ldurb           w16, [x1, #-1]
    //     0x5af384: ldurb           w17, [x0, #-1]
    //     0x5af388: and             x16, x17, x16, lsr #2
    //     0x5af38c: tst             x16, HEAP, lsr #32
    //     0x5af390: b.eq            #0x5af398
    //     0x5af394: bl              #0xd6826c
    // 0x5af398: ldur            x3, [fp, #-8]
    // 0x5af39c: LoadField: r0 = r3->field_13
    //     0x5af39c: ldur            w0, [x3, #0x13]
    // 0x5af3a0: DecompressPointer r0
    //     0x5af3a0: add             x0, x0, HEAP, lsl #32
    // 0x5af3a4: cmp             w0, NULL
    // 0x5af3a8: b.ne            #0x5af3d4
    // 0x5af3ac: ldr             x4, [fp, #0x18]
    // 0x5af3b0: ldur            x0, [fp, #-0x18]
    // 0x5af3b4: StoreField: r4->field_6b = r0
    //     0x5af3b4: stur            w0, [x4, #0x6b]
    //     0x5af3b8: ldurb           w16, [x4, #-1]
    //     0x5af3bc: ldurb           w17, [x0, #-1]
    //     0x5af3c0: and             x16, x17, x16, lsr #2
    //     0x5af3c4: tst             x16, HEAP, lsr #32
    //     0x5af3c8: b.eq            #0x5af3d0
    //     0x5af3cc: bl              #0xd682cc
    // 0x5af3d0: b               #0x5af48c
    // 0x5af3d4: ldr             x4, [fp, #0x18]
    // 0x5af3d8: LoadField: r5 = r0->field_17
    //     0x5af3d8: ldur            w5, [x0, #0x17]
    // 0x5af3dc: DecompressPointer r5
    //     0x5af3dc: add             x5, x5, HEAP, lsl #32
    // 0x5af3e0: stur            x5, [fp, #-0x10]
    // 0x5af3e4: cmp             w5, NULL
    // 0x5af3e8: b.eq            #0x5af500
    // 0x5af3ec: mov             x0, x5
    // 0x5af3f0: r2 = Null
    //     0x5af3f0: mov             x2, NULL
    // 0x5af3f4: r1 = Null
    //     0x5af3f4: mov             x1, NULL
    // 0x5af3f8: r4 = LoadClassIdInstr(r0)
    //     0x5af3f8: ldur            x4, [x0, #-1]
    //     0x5af3fc: ubfx            x4, x4, #0xc, #0x14
    // 0x5af400: cmp             x4, #0x80a
    // 0x5af404: b.eq            #0x5af41c
    // 0x5af408: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x5af408: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x5af40c: ldr             x8, [x8, #0x170]
    // 0x5af410: r3 = Null
    //     0x5af410: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb30] Null
    //     0x5af414: ldr             x3, [x3, #0xb30]
    // 0x5af418: r0 = DefaultTypeTest()
    //     0x5af418: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x5af41c: ldur            x3, [fp, #-0x10]
    // 0x5af420: LoadField: r2 = r3->field_b
    //     0x5af420: ldur            w2, [x3, #0xb]
    // 0x5af424: DecompressPointer r2
    //     0x5af424: add             x2, x2, HEAP, lsl #32
    // 0x5af428: ldur            x0, [fp, #-0x18]
    // 0x5af42c: r1 = Null
    //     0x5af42c: mov             x1, NULL
    // 0x5af430: cmp             w0, NULL
    // 0x5af434: b.eq            #0x5af460
    // 0x5af438: cmp             w2, NULL
    // 0x5af43c: b.eq            #0x5af460
    // 0x5af440: LoadField: r4 = r2->field_17
    //     0x5af440: ldur            w4, [x2, #0x17]
    // 0x5af444: DecompressPointer r4
    //     0x5af444: add             x4, x4, HEAP, lsl #32
    // 0x5af448: r8 = X0? bound RenderObject
    //     0x5af448: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af44c: ldr             x8, [x8, #0x6e8]
    // 0x5af450: LoadField: r9 = r4->field_7
    //     0x5af450: ldur            x9, [x4, #7]
    // 0x5af454: r3 = Null
    //     0x5af454: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb40] Null
    //     0x5af458: ldr             x3, [x3, #0xb40]
    // 0x5af45c: blr             x9
    // 0x5af460: ldur            x0, [fp, #-0x18]
    // 0x5af464: ldur            x1, [fp, #-0x10]
    // 0x5af468: StoreField: r1->field_f = r0
    //     0x5af468: stur            w0, [x1, #0xf]
    //     0x5af46c: ldurb           w16, [x1, #-1]
    //     0x5af470: ldurb           w17, [x0, #-1]
    //     0x5af474: and             x16, x17, x16, lsr #2
    //     0x5af478: tst             x16, HEAP, lsr #32
    //     0x5af47c: b.eq            #0x5af484
    //     0x5af480: bl              #0xd6826c
    // 0x5af484: ldr             x4, [fp, #0x18]
    // 0x5af488: ldur            x3, [fp, #-8]
    // 0x5af48c: LoadField: r2 = r3->field_b
    //     0x5af48c: ldur            w2, [x3, #0xb]
    // 0x5af490: DecompressPointer r2
    //     0x5af490: add             x2, x2, HEAP, lsl #32
    // 0x5af494: r0 = Null
    //     0x5af494: mov             x0, NULL
    // 0x5af498: r1 = Null
    //     0x5af498: mov             x1, NULL
    // 0x5af49c: cmp             w0, NULL
    // 0x5af4a0: b.eq            #0x5af4cc
    // 0x5af4a4: cmp             w2, NULL
    // 0x5af4a8: b.eq            #0x5af4cc
    // 0x5af4ac: LoadField: r4 = r2->field_17
    //     0x5af4ac: ldur            w4, [x2, #0x17]
    // 0x5af4b0: DecompressPointer r4
    //     0x5af4b0: add             x4, x4, HEAP, lsl #32
    // 0x5af4b4: r8 = X0? bound RenderObject
    //     0x5af4b4: add             x8, PP, #0x21, lsl #12  ; [pp+0x216e8] TypeParameter: X0? bound RenderObject
    //     0x5af4b8: ldr             x8, [x8, #0x6e8]
    // 0x5af4bc: LoadField: r9 = r4->field_7
    //     0x5af4bc: ldur            x9, [x4, #7]
    // 0x5af4c0: r3 = Null
    //     0x5af4c0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb50] Null
    //     0x5af4c4: ldr             x3, [x3, #0xb50]
    // 0x5af4c8: blr             x9
    // 0x5af4cc: ldur            x1, [fp, #-8]
    // 0x5af4d0: StoreField: r1->field_f = rNULL
    //     0x5af4d0: stur            NULL, [x1, #0xf]
    // 0x5af4d4: StoreField: r1->field_13 = rNULL
    //     0x5af4d4: stur            NULL, [x1, #0x13]
    // 0x5af4d8: ldr             x1, [fp, #0x18]
    // 0x5af4dc: LoadField: r2 = r1->field_5f
    //     0x5af4dc: ldur            x2, [x1, #0x5f]
    // 0x5af4e0: sub             x3, x2, #1
    // 0x5af4e4: StoreField: r1->field_5f = r3
    //     0x5af4e4: stur            x3, [x1, #0x5f]
    // 0x5af4e8: r0 = Null
    //     0x5af4e8: mov             x0, NULL
    // 0x5af4ec: LeaveFrame
    //     0x5af4ec: mov             SP, fp
    //     0x5af4f0: ldp             fp, lr, [SP], #0x10
    // 0x5af4f4: ret
    //     0x5af4f4: ret             
    // 0x5af4f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af4f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5af4fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af4fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x5af500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5af500: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ remove(/* No info */) {
    // ** addr: 0x5e94c0, size: 0x90
    // 0x5e94c0: EnterFrame
    //     0x5e94c0: stp             fp, lr, [SP, #-0x10]!
    //     0x5e94c4: mov             fp, SP
    // 0x5e94c8: CheckStackOverflow
    //     0x5e94c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e94cc: cmp             SP, x16
    //     0x5e94d0: b.ls            #0x5e9548
    // 0x5e94d4: ldr             x0, [fp, #0x10]
    // 0x5e94d8: r2 = Null
    //     0x5e94d8: mov             x2, NULL
    // 0x5e94dc: r1 = Null
    //     0x5e94dc: mov             x1, NULL
    // 0x5e94e0: r4 = 59
    //     0x5e94e0: mov             x4, #0x3b
    // 0x5e94e4: branchIfSmi(r0, 0x5e94f0)
    //     0x5e94e4: tbz             w0, #0, #0x5e94f0
    // 0x5e94e8: r4 = LoadClassIdInstr(r0)
    //     0x5e94e8: ldur            x4, [x0, #-1]
    //     0x5e94ec: ubfx            x4, x4, #0xc, #0x14
    // 0x5e94f0: sub             x4, x4, #0x965
    // 0x5e94f4: cmp             x4, #0x8b
    // 0x5e94f8: b.ls            #0x5e9510
    // 0x5e94fc: r8 = RenderBox
    //     0x5e94fc: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9500: ldr             x8, [x8, #0xfa0]
    // 0x5e9504: r3 = Null
    //     0x5e9504: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb60] Null
    //     0x5e9508: ldr             x3, [x3, #0xb60]
    // 0x5e950c: r0 = RenderBox()
    //     0x5e950c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e9510: ldr             x16, [fp, #0x18]
    // 0x5e9514: ldr             lr, [fp, #0x10]
    // 0x5e9518: stp             lr, x16, [SP, #-0x10]!
    // 0x5e951c: r0 = _removeFromChildList()
    //     0x5e951c: bl              #0x5af240  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin::_removeFromChildList
    // 0x5e9520: add             SP, SP, #0x10
    // 0x5e9524: ldr             x16, [fp, #0x18]
    // 0x5e9528: ldr             lr, [fp, #0x10]
    // 0x5e952c: stp             lr, x16, [SP, #-0x10]!
    // 0x5e9530: r0 = dropChild()
    //     0x5e9530: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x5e9534: add             SP, SP, #0x10
    // 0x5e9538: r0 = Null
    //     0x5e9538: mov             x0, NULL
    // 0x5e953c: LeaveFrame
    //     0x5e953c: mov             SP, fp
    //     0x5e9540: ldp             fp, lr, [SP], #0x10
    // 0x5e9544: ret
    //     0x5e9544: ret             
    // 0x5e9548: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e9548: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e954c: b               #0x5e94d4
  }
  _ insert(/* No info */) {
    // ** addr: 0x5e9620, size: 0xd0
    // 0x5e9620: EnterFrame
    //     0x5e9620: stp             fp, lr, [SP, #-0x10]!
    //     0x5e9624: mov             fp, SP
    // 0x5e9628: CheckStackOverflow
    //     0x5e9628: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5e962c: cmp             SP, x16
    //     0x5e9630: b.ls            #0x5e96e8
    // 0x5e9634: ldr             x0, [fp, #0x18]
    // 0x5e9638: r2 = Null
    //     0x5e9638: mov             x2, NULL
    // 0x5e963c: r1 = Null
    //     0x5e963c: mov             x1, NULL
    // 0x5e9640: r4 = 59
    //     0x5e9640: mov             x4, #0x3b
    // 0x5e9644: branchIfSmi(r0, 0x5e9650)
    //     0x5e9644: tbz             w0, #0, #0x5e9650
    // 0x5e9648: r4 = LoadClassIdInstr(r0)
    //     0x5e9648: ldur            x4, [x0, #-1]
    //     0x5e964c: ubfx            x4, x4, #0xc, #0x14
    // 0x5e9650: sub             x4, x4, #0x965
    // 0x5e9654: cmp             x4, #0x8b
    // 0x5e9658: b.ls            #0x5e9670
    // 0x5e965c: r8 = RenderBox
    //     0x5e965c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x5e9660: ldr             x8, [x8, #0xfa0]
    // 0x5e9664: r3 = Null
    //     0x5e9664: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb70] Null
    //     0x5e9668: ldr             x3, [x3, #0xb70]
    // 0x5e966c: r0 = RenderBox()
    //     0x5e966c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x5e9670: ldr             x0, [fp, #0x10]
    // 0x5e9674: r2 = Null
    //     0x5e9674: mov             x2, NULL
    // 0x5e9678: r1 = Null
    //     0x5e9678: mov             x1, NULL
    // 0x5e967c: r4 = 59
    //     0x5e967c: mov             x4, #0x3b
    // 0x5e9680: branchIfSmi(r0, 0x5e968c)
    //     0x5e9680: tbz             w0, #0, #0x5e968c
    // 0x5e9684: r4 = LoadClassIdInstr(r0)
    //     0x5e9684: ldur            x4, [x0, #-1]
    //     0x5e9688: ubfx            x4, x4, #0xc, #0x14
    // 0x5e968c: sub             x4, x4, #0x965
    // 0x5e9690: cmp             x4, #0x8b
    // 0x5e9694: b.ls            #0x5e96a8
    // 0x5e9698: r8 = RenderBox?
    //     0x5e9698: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x5e969c: r3 = Null
    //     0x5e969c: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2eb80] Null
    //     0x5e96a0: ldr             x3, [x3, #0xb80]
    // 0x5e96a4: r0 = RenderBox?()
    //     0x5e96a4: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x5e96a8: ldr             x16, [fp, #0x20]
    // 0x5e96ac: ldr             lr, [fp, #0x18]
    // 0x5e96b0: stp             lr, x16, [SP, #-0x10]!
    // 0x5e96b4: r0 = adoptChild()
    //     0x5e96b4: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x5e96b8: add             SP, SP, #0x10
    // 0x5e96bc: ldr             x16, [fp, #0x20]
    // 0x5e96c0: ldr             lr, [fp, #0x18]
    // 0x5e96c4: stp             lr, x16, [SP, #-0x10]!
    // 0x5e96c8: ldr             x16, [fp, #0x10]
    // 0x5e96cc: SaveReg r16
    //     0x5e96cc: str             x16, [SP, #-8]!
    // 0x5e96d0: r0 = _insertIntoChildList()
    //     0x5e96d0: bl              #0x5aece0  ; [package:flutter/src/cupertino/dialog.dart] __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin::_insertIntoChildList
    // 0x5e96d4: add             SP, SP, #0x18
    // 0x5e96d8: r0 = Null
    //     0x5e96d8: mov             x0, NULL
    // 0x5e96dc: LeaveFrame
    //     0x5e96dc: mov             SP, fp
    //     0x5e96e0: ldp             fp, lr, [SP], #0x10
    // 0x5e96e4: ret
    //     0x5e96e4: ret             
    // 0x5e96e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5e96e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5e96ec: b               #0x5e9634
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf834, size: 0xd8
    // 0x6bf834: EnterFrame
    //     0x6bf834: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf838: mov             fp, SP
    // 0x6bf83c: AllocStack(0x10)
    //     0x6bf83c: sub             SP, SP, #0x10
    // 0x6bf840: CheckStackOverflow
    //     0x6bf840: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf844: cmp             SP, x16
    //     0x6bf848: b.ls            #0x6bf8f8
    // 0x6bf84c: ldr             x0, [fp, #0x18]
    // 0x6bf850: LoadField: r1 = r0->field_67
    //     0x6bf850: ldur            w1, [x0, #0x67]
    // 0x6bf854: DecompressPointer r1
    //     0x6bf854: add             x1, x1, HEAP, lsl #32
    // 0x6bf858: stur            x1, [fp, #-8]
    // 0x6bf85c: CheckStackOverflow
    //     0x6bf85c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf860: cmp             SP, x16
    //     0x6bf864: b.ls            #0x6bf900
    // 0x6bf868: cmp             w1, NULL
    // 0x6bf86c: b.eq            #0x6bf8e8
    // 0x6bf870: ldr             x16, [fp, #0x10]
    // 0x6bf874: stp             x1, x16, [SP, #-0x10]!
    // 0x6bf878: ldr             x0, [fp, #0x10]
    // 0x6bf87c: ClosureCall
    //     0x6bf87c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf880: ldur            x2, [x0, #0x1f]
    //     0x6bf884: blr             x2
    // 0x6bf888: add             SP, SP, #0x10
    // 0x6bf88c: ldur            x0, [fp, #-8]
    // 0x6bf890: LoadField: r3 = r0->field_17
    //     0x6bf890: ldur            w3, [x0, #0x17]
    // 0x6bf894: DecompressPointer r3
    //     0x6bf894: add             x3, x3, HEAP, lsl #32
    // 0x6bf898: stur            x3, [fp, #-0x10]
    // 0x6bf89c: cmp             w3, NULL
    // 0x6bf8a0: b.eq            #0x6bf908
    // 0x6bf8a4: mov             x0, x3
    // 0x6bf8a8: r2 = Null
    //     0x6bf8a8: mov             x2, NULL
    // 0x6bf8ac: r1 = Null
    //     0x6bf8ac: mov             x1, NULL
    // 0x6bf8b0: r4 = LoadClassIdInstr(r0)
    //     0x6bf8b0: ldur            x4, [x0, #-1]
    //     0x6bf8b4: ubfx            x4, x4, #0xc, #0x14
    // 0x6bf8b8: cmp             x4, #0x80a
    // 0x6bf8bc: b.eq            #0x6bf8d4
    // 0x6bf8c0: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x6bf8c0: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x6bf8c4: ldr             x8, [x8, #0x170]
    // 0x6bf8c8: r3 = Null
    //     0x6bf8c8: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e9d0] Null
    //     0x6bf8cc: ldr             x3, [x3, #0x9d0]
    // 0x6bf8d0: r0 = DefaultTypeTest()
    //     0x6bf8d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bf8d4: ldur            x1, [fp, #-0x10]
    // 0x6bf8d8: LoadField: r0 = r1->field_13
    //     0x6bf8d8: ldur            w0, [x1, #0x13]
    // 0x6bf8dc: DecompressPointer r0
    //     0x6bf8dc: add             x0, x0, HEAP, lsl #32
    // 0x6bf8e0: mov             x1, x0
    // 0x6bf8e4: b               #0x6bf858
    // 0x6bf8e8: r0 = Null
    //     0x6bf8e8: mov             x0, NULL
    // 0x6bf8ec: LeaveFrame
    //     0x6bf8ec: mov             SP, fp
    //     0x6bf8f0: ldp             fp, lr, [SP], #0x10
    // 0x6bf8f4: ret
    //     0x6bf8f4: ret             
    // 0x6bf8f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf8f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf8fc: b               #0x6bf84c
    // 0x6bf900: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bf900: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bf904: b               #0x6bf868
    // 0x6bf908: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bf908: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792b00, size: 0xf8
    // 0x792b00: EnterFrame
    //     0x792b00: stp             fp, lr, [SP, #-0x10]!
    //     0x792b04: mov             fp, SP
    // 0x792b08: AllocStack(0x10)
    //     0x792b08: sub             SP, SP, #0x10
    // 0x792b0c: CheckStackOverflow
    //     0x792b0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792b10: cmp             SP, x16
    //     0x792b14: b.ls            #0x792be4
    // 0x792b18: ldr             x1, [fp, #0x10]
    // 0x792b1c: LoadField: r0 = r1->field_67
    //     0x792b1c: ldur            w0, [x1, #0x67]
    // 0x792b20: DecompressPointer r0
    //     0x792b20: add             x0, x0, HEAP, lsl #32
    // 0x792b24: mov             x2, x0
    // 0x792b28: stur            x2, [fp, #-8]
    // 0x792b2c: CheckStackOverflow
    //     0x792b2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792b30: cmp             SP, x16
    //     0x792b34: b.ls            #0x792bec
    // 0x792b38: cmp             w2, NULL
    // 0x792b3c: b.eq            #0x792bd4
    // 0x792b40: LoadField: r0 = r2->field_7
    //     0x792b40: ldur            x0, [x2, #7]
    // 0x792b44: LoadField: r3 = r1->field_7
    //     0x792b44: ldur            x3, [x1, #7]
    // 0x792b48: cmp             x0, x3
    // 0x792b4c: b.gt            #0x792b78
    // 0x792b50: add             x0, x3, #1
    // 0x792b54: StoreField: r2->field_7 = r0
    //     0x792b54: stur            x0, [x2, #7]
    // 0x792b58: r0 = LoadClassIdInstr(r2)
    //     0x792b58: ldur            x0, [x2, #-1]
    //     0x792b5c: ubfx            x0, x0, #0xc, #0x14
    // 0x792b60: SaveReg r2
    //     0x792b60: str             x2, [SP, #-8]!
    // 0x792b64: r0 = GDT[cid_x0 + 0xbdf1]()
    //     0x792b64: mov             x17, #0xbdf1
    //     0x792b68: add             lr, x0, x17
    //     0x792b6c: ldr             lr, [x21, lr, lsl #3]
    //     0x792b70: blr             lr
    // 0x792b74: add             SP, SP, #8
    // 0x792b78: ldur            x0, [fp, #-8]
    // 0x792b7c: LoadField: r3 = r0->field_17
    //     0x792b7c: ldur            w3, [x0, #0x17]
    // 0x792b80: DecompressPointer r3
    //     0x792b80: add             x3, x3, HEAP, lsl #32
    // 0x792b84: stur            x3, [fp, #-0x10]
    // 0x792b88: cmp             w3, NULL
    // 0x792b8c: b.eq            #0x792bf4
    // 0x792b90: mov             x0, x3
    // 0x792b94: r2 = Null
    //     0x792b94: mov             x2, NULL
    // 0x792b98: r1 = Null
    //     0x792b98: mov             x1, NULL
    // 0x792b9c: r4 = LoadClassIdInstr(r0)
    //     0x792b9c: ldur            x4, [x0, #-1]
    //     0x792ba0: ubfx            x4, x4, #0xc, #0x14
    // 0x792ba4: cmp             x4, #0x80a
    // 0x792ba8: b.eq            #0x792bc0
    // 0x792bac: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x792bac: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x792bb0: ldr             x8, [x8, #0x170]
    // 0x792bb4: r3 = Null
    //     0x792bb4: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e9e0] Null
    //     0x792bb8: ldr             x3, [x3, #0x9e0]
    // 0x792bbc: r0 = DefaultTypeTest()
    //     0x792bbc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x792bc0: ldur            x1, [fp, #-0x10]
    // 0x792bc4: LoadField: r2 = r1->field_13
    //     0x792bc4: ldur            w2, [x1, #0x13]
    // 0x792bc8: DecompressPointer r2
    //     0x792bc8: add             x2, x2, HEAP, lsl #32
    // 0x792bcc: ldr             x1, [fp, #0x10]
    // 0x792bd0: b               #0x792b28
    // 0x792bd4: r0 = Null
    //     0x792bd4: mov             x0, NULL
    // 0x792bd8: LeaveFrame
    //     0x792bd8: mov             SP, fp
    //     0x792bdc: ldp             fp, lr, [SP], #0x10
    // 0x792be0: ret
    //     0x792be0: ret             
    // 0x792be4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792be4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792be8: b               #0x792b18
    // 0x792bec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792bec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792bf0: b               #0x792b38
    // 0x792bf4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x792bf4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd030, size: 0xf4
    // 0x9bd030: EnterFrame
    //     0x9bd030: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd034: mov             fp, SP
    // 0x9bd038: AllocStack(0x10)
    //     0x9bd038: sub             SP, SP, #0x10
    // 0x9bd03c: CheckStackOverflow
    //     0x9bd03c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd040: cmp             SP, x16
    //     0x9bd044: b.ls            #0x9bd110
    // 0x9bd048: ldr             x16, [fp, #0x18]
    // 0x9bd04c: ldr             lr, [fp, #0x10]
    // 0x9bd050: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd054: r0 = attach()
    //     0x9bd054: bl              #0x9bf794  ; [package:flutter/src/rendering/object.dart] RenderObject::attach
    // 0x9bd058: add             SP, SP, #0x10
    // 0x9bd05c: ldr             x0, [fp, #0x18]
    // 0x9bd060: LoadField: r1 = r0->field_67
    //     0x9bd060: ldur            w1, [x0, #0x67]
    // 0x9bd064: DecompressPointer r1
    //     0x9bd064: add             x1, x1, HEAP, lsl #32
    // 0x9bd068: stur            x1, [fp, #-8]
    // 0x9bd06c: CheckStackOverflow
    //     0x9bd06c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd070: cmp             SP, x16
    //     0x9bd074: b.ls            #0x9bd118
    // 0x9bd078: cmp             w1, NULL
    // 0x9bd07c: b.eq            #0x9bd100
    // 0x9bd080: r0 = LoadClassIdInstr(r1)
    //     0x9bd080: ldur            x0, [x1, #-1]
    //     0x9bd084: ubfx            x0, x0, #0xc, #0x14
    // 0x9bd088: ldr             x16, [fp, #0x10]
    // 0x9bd08c: stp             x16, x1, [SP, #-0x10]!
    // 0x9bd090: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bd090: mov             x17, #0xaf1f
    //     0x9bd094: add             lr, x0, x17
    //     0x9bd098: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd09c: blr             lr
    // 0x9bd0a0: add             SP, SP, #0x10
    // 0x9bd0a4: ldur            x0, [fp, #-8]
    // 0x9bd0a8: LoadField: r3 = r0->field_17
    //     0x9bd0a8: ldur            w3, [x0, #0x17]
    // 0x9bd0ac: DecompressPointer r3
    //     0x9bd0ac: add             x3, x3, HEAP, lsl #32
    // 0x9bd0b0: stur            x3, [fp, #-0x10]
    // 0x9bd0b4: cmp             w3, NULL
    // 0x9bd0b8: b.eq            #0x9bd120
    // 0x9bd0bc: mov             x0, x3
    // 0x9bd0c0: r2 = Null
    //     0x9bd0c0: mov             x2, NULL
    // 0x9bd0c4: r1 = Null
    //     0x9bd0c4: mov             x1, NULL
    // 0x9bd0c8: r4 = LoadClassIdInstr(r0)
    //     0x9bd0c8: ldur            x4, [x0, #-1]
    //     0x9bd0cc: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd0d0: cmp             x4, #0x80a
    // 0x9bd0d4: b.eq            #0x9bd0ec
    // 0x9bd0d8: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x9bd0d8: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x9bd0dc: ldr             x8, [x8, #0x170]
    // 0x9bd0e0: r3 = Null
    //     0x9bd0e0: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ea00] Null
    //     0x9bd0e4: ldr             x3, [x3, #0xa00]
    // 0x9bd0e8: r0 = DefaultTypeTest()
    //     0x9bd0e8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd0ec: ldur            x1, [fp, #-0x10]
    // 0x9bd0f0: LoadField: r0 = r1->field_13
    //     0x9bd0f0: ldur            w0, [x1, #0x13]
    // 0x9bd0f4: DecompressPointer r0
    //     0x9bd0f4: add             x0, x0, HEAP, lsl #32
    // 0x9bd0f8: mov             x1, x0
    // 0x9bd0fc: b               #0x9bd068
    // 0x9bd100: r0 = Null
    //     0x9bd100: mov             x0, NULL
    // 0x9bd104: LeaveFrame
    //     0x9bd104: mov             SP, fp
    //     0x9bd108: ldp             fp, lr, [SP], #0x10
    // 0x9bd10c: ret
    //     0x9bd10c: ret             
    // 0x9bd110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd114: b               #0x9bd048
    // 0x9bd118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd11c: b               #0x9bd078
    // 0x9bd120: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bd120: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68e24, size: 0xec
    // 0xa68e24: EnterFrame
    //     0xa68e24: stp             fp, lr, [SP, #-0x10]!
    //     0xa68e28: mov             fp, SP
    // 0xa68e2c: AllocStack(0x10)
    //     0xa68e2c: sub             SP, SP, #0x10
    // 0xa68e30: CheckStackOverflow
    //     0xa68e30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68e34: cmp             SP, x16
    //     0xa68e38: b.ls            #0xa68efc
    // 0xa68e3c: ldr             x16, [fp, #0x10]
    // 0xa68e40: SaveReg r16
    //     0xa68e40: str             x16, [SP, #-8]!
    // 0xa68e44: r0 = detach()
    //     0xa68e44: bl              #0xa6ade0  ; [package:flutter/src/foundation/node.dart] AbstractNode::detach
    // 0xa68e48: add             SP, SP, #8
    // 0xa68e4c: ldr             x0, [fp, #0x10]
    // 0xa68e50: LoadField: r1 = r0->field_67
    //     0xa68e50: ldur            w1, [x0, #0x67]
    // 0xa68e54: DecompressPointer r1
    //     0xa68e54: add             x1, x1, HEAP, lsl #32
    // 0xa68e58: stur            x1, [fp, #-8]
    // 0xa68e5c: CheckStackOverflow
    //     0xa68e5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68e60: cmp             SP, x16
    //     0xa68e64: b.ls            #0xa68f04
    // 0xa68e68: cmp             w1, NULL
    // 0xa68e6c: b.eq            #0xa68eec
    // 0xa68e70: r0 = LoadClassIdInstr(r1)
    //     0xa68e70: ldur            x0, [x1, #-1]
    //     0xa68e74: ubfx            x0, x0, #0xc, #0x14
    // 0xa68e78: SaveReg r1
    //     0xa68e78: str             x1, [SP, #-8]!
    // 0xa68e7c: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa68e7c: mov             x17, #0xa3cc
    //     0xa68e80: add             lr, x0, x17
    //     0xa68e84: ldr             lr, [x21, lr, lsl #3]
    //     0xa68e88: blr             lr
    // 0xa68e8c: add             SP, SP, #8
    // 0xa68e90: ldur            x0, [fp, #-8]
    // 0xa68e94: LoadField: r3 = r0->field_17
    //     0xa68e94: ldur            w3, [x0, #0x17]
    // 0xa68e98: DecompressPointer r3
    //     0xa68e98: add             x3, x3, HEAP, lsl #32
    // 0xa68e9c: stur            x3, [fp, #-0x10]
    // 0xa68ea0: cmp             w3, NULL
    // 0xa68ea4: b.eq            #0xa68f0c
    // 0xa68ea8: mov             x0, x3
    // 0xa68eac: r2 = Null
    //     0xa68eac: mov             x2, NULL
    // 0xa68eb0: r1 = Null
    //     0xa68eb0: mov             x1, NULL
    // 0xa68eb4: r4 = LoadClassIdInstr(r0)
    //     0xa68eb4: ldur            x4, [x0, #-1]
    //     0xa68eb8: ubfx            x4, x4, #0xc, #0x14
    // 0xa68ebc: cmp             x4, #0x80a
    // 0xa68ec0: b.eq            #0xa68ed8
    // 0xa68ec4: r8 = MultiChildLayoutParentData<RenderBox>
    //     0xa68ec4: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0xa68ec8: ldr             x8, [x8, #0x170]
    // 0xa68ecc: r3 = Null
    //     0xa68ecc: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e9f0] Null
    //     0xa68ed0: ldr             x3, [x3, #0x9f0]
    // 0xa68ed4: r0 = DefaultTypeTest()
    //     0xa68ed4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa68ed8: ldur            x1, [fp, #-0x10]
    // 0xa68edc: LoadField: r0 = r1->field_13
    //     0xa68edc: ldur            w0, [x1, #0x13]
    // 0xa68ee0: DecompressPointer r0
    //     0xa68ee0: add             x0, x0, HEAP, lsl #32
    // 0xa68ee4: mov             x1, x0
    // 0xa68ee8: b               #0xa68e58
    // 0xa68eec: r0 = Null
    //     0xa68eec: mov             x0, NULL
    // 0xa68ef0: LeaveFrame
    //     0xa68ef0: mov             SP, fp
    //     0xa68ef4: ldp             fp, lr, [SP], #0x10
    // 0xa68ef8: ret
    //     0xa68ef8: ret             
    // 0xa68efc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68efc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68f00: b               #0xa68e3c
    // 0xa68f04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68f04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68f08: b               #0xa68e68
    // 0xa68f0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa68f0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 2528, size: 0x70, field offset: 0x70
//   transformed mixin,
abstract class __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin extends __RenderCupertinoDialogActions&RenderBox&ContainerRenderObjectMixin
     with RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData<X0 bound RenderBox>> {

  _ defaultHitTestChildren(/* No info */) {
    // ** addr: 0x6251c8, size: 0x15c
    // 0x6251c8: EnterFrame
    //     0x6251c8: stp             fp, lr, [SP, #-0x10]!
    //     0x6251cc: mov             fp, SP
    // 0x6251d0: AllocStack(0x20)
    //     0x6251d0: sub             SP, SP, #0x20
    // 0x6251d4: CheckStackOverflow
    //     0x6251d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6251d8: cmp             SP, x16
    //     0x6251dc: b.ls            #0x625310
    // 0x6251e0: ldr             x0, [fp, #0x20]
    // 0x6251e4: LoadField: r1 = r0->field_6b
    //     0x6251e4: ldur            w1, [x0, #0x6b]
    // 0x6251e8: DecompressPointer r1
    //     0x6251e8: add             x1, x1, HEAP, lsl #32
    // 0x6251ec: mov             x3, x1
    // 0x6251f0: stur            x3, [fp, #-0x10]
    // 0x6251f4: CheckStackOverflow
    //     0x6251f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6251f8: cmp             SP, x16
    //     0x6251fc: b.ls            #0x625318
    // 0x625200: cmp             w3, NULL
    // 0x625204: b.eq            #0x625300
    // 0x625208: LoadField: r4 = r3->field_17
    //     0x625208: ldur            w4, [x3, #0x17]
    // 0x62520c: DecompressPointer r4
    //     0x62520c: add             x4, x4, HEAP, lsl #32
    // 0x625210: stur            x4, [fp, #-8]
    // 0x625214: cmp             w4, NULL
    // 0x625218: b.eq            #0x625320
    // 0x62521c: mov             x0, x4
    // 0x625220: r2 = Null
    //     0x625220: mov             x2, NULL
    // 0x625224: r1 = Null
    //     0x625224: mov             x1, NULL
    // 0x625228: r4 = LoadClassIdInstr(r0)
    //     0x625228: ldur            x4, [x0, #-1]
    //     0x62522c: ubfx            x4, x4, #0xc, #0x14
    // 0x625230: cmp             x4, #0x80a
    // 0x625234: b.eq            #0x62524c
    // 0x625238: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x625238: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x62523c: ldr             x8, [x8, #0x170]
    // 0x625240: r3 = Null
    //     0x625240: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d710] Null
    //     0x625244: ldr             x3, [x3, #0x710]
    // 0x625248: r0 = DefaultTypeTest()
    //     0x625248: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62524c: ldur            x0, [fp, #-8]
    // 0x625250: LoadField: r1 = r0->field_7
    //     0x625250: ldur            w1, [x0, #7]
    // 0x625254: DecompressPointer r1
    //     0x625254: add             x1, x1, HEAP, lsl #32
    // 0x625258: stur            x1, [fp, #-0x18]
    // 0x62525c: ldr             x16, [fp, #0x10]
    // 0x625260: stp             x1, x16, [SP, #-0x10]!
    // 0x625264: r0 = -()
    //     0x625264: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x625268: add             SP, SP, #0x10
    // 0x62526c: stur            x0, [fp, #-0x20]
    // 0x625270: ldur            x16, [fp, #-0x18]
    // 0x625274: SaveReg r16
    //     0x625274: str             x16, [SP, #-8]!
    // 0x625278: r0 = unary-()
    //     0x625278: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x62527c: add             SP, SP, #8
    // 0x625280: ldr             x16, [fp, #0x18]
    // 0x625284: stp             x0, x16, [SP, #-0x10]!
    // 0x625288: r0 = pushOffset()
    //     0x625288: bl              #0x622998  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::pushOffset
    // 0x62528c: add             SP, SP, #0x10
    // 0x625290: ldur            x0, [fp, #-0x10]
    // 0x625294: r1 = LoadClassIdInstr(r0)
    //     0x625294: ldur            x1, [x0, #-1]
    //     0x625298: ubfx            x1, x1, #0xc, #0x14
    // 0x62529c: ldr             x16, [fp, #0x18]
    // 0x6252a0: stp             x16, x0, [SP, #-0x10]!
    // 0x6252a4: ldur            x16, [fp, #-0x20]
    // 0x6252a8: SaveReg r16
    //     0x6252a8: str             x16, [SP, #-8]!
    // 0x6252ac: mov             x0, x1
    // 0x6252b0: r0 = GDT[cid_x0 + 0xefa2]()
    //     0x6252b0: mov             x17, #0xefa2
    //     0x6252b4: add             lr, x0, x17
    //     0x6252b8: ldr             lr, [x21, lr, lsl #3]
    //     0x6252bc: blr             lr
    // 0x6252c0: add             SP, SP, #0x18
    // 0x6252c4: stur            x0, [fp, #-0x10]
    // 0x6252c8: ldr             x16, [fp, #0x18]
    // 0x6252cc: SaveReg r16
    //     0x6252cc: str             x16, [SP, #-8]!
    // 0x6252d0: r0 = popTransform()
    //     0x6252d0: bl              #0x6228f4  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::popTransform
    // 0x6252d4: add             SP, SP, #8
    // 0x6252d8: ldur            x1, [fp, #-0x10]
    // 0x6252dc: tbnz            w1, #4, #0x6252f0
    // 0x6252e0: r0 = true
    //     0x6252e0: add             x0, NULL, #0x20  ; true
    // 0x6252e4: LeaveFrame
    //     0x6252e4: mov             SP, fp
    //     0x6252e8: ldp             fp, lr, [SP], #0x10
    // 0x6252ec: ret
    //     0x6252ec: ret             
    // 0x6252f0: ldur            x1, [fp, #-8]
    // 0x6252f4: LoadField: r3 = r1->field_f
    //     0x6252f4: ldur            w3, [x1, #0xf]
    // 0x6252f8: DecompressPointer r3
    //     0x6252f8: add             x3, x3, HEAP, lsl #32
    // 0x6252fc: b               #0x6251f0
    // 0x625300: r0 = false
    //     0x625300: add             x0, NULL, #0x30  ; false
    // 0x625304: LeaveFrame
    //     0x625304: mov             SP, fp
    //     0x625308: ldp             fp, lr, [SP], #0x10
    // 0x62530c: ret
    //     0x62530c: ret             
    // 0x625310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x625314: b               #0x6251e0
    // 0x625318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x625318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62531c: b               #0x625200
    // 0x625320: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x625320: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ defaultPaint(/* No info */) {
    // ** addr: 0x65ee24, size: 0x12c
    // 0x65ee24: EnterFrame
    //     0x65ee24: stp             fp, lr, [SP, #-0x10]!
    //     0x65ee28: mov             fp, SP
    // 0x65ee2c: AllocStack(0x30)
    //     0x65ee2c: sub             SP, SP, #0x30
    // 0x65ee30: CheckStackOverflow
    //     0x65ee30: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65ee34: cmp             SP, x16
    //     0x65ee38: b.ls            #0x65ef3c
    // 0x65ee3c: ldr             x0, [fp, #0x20]
    // 0x65ee40: LoadField: r1 = r0->field_67
    //     0x65ee40: ldur            w1, [x0, #0x67]
    // 0x65ee44: DecompressPointer r1
    //     0x65ee44: add             x1, x1, HEAP, lsl #32
    // 0x65ee48: ldr             x0, [fp, #0x10]
    // 0x65ee4c: LoadField: d0 = r0->field_7
    //     0x65ee4c: ldur            d0, [x0, #7]
    // 0x65ee50: stur            d0, [fp, #-0x20]
    // 0x65ee54: LoadField: d1 = r0->field_f
    //     0x65ee54: ldur            d1, [x0, #0xf]
    // 0x65ee58: stur            d1, [fp, #-0x18]
    // 0x65ee5c: mov             x3, x1
    // 0x65ee60: stur            x3, [fp, #-0x10]
    // 0x65ee64: CheckStackOverflow
    //     0x65ee64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65ee68: cmp             SP, x16
    //     0x65ee6c: b.ls            #0x65ef44
    // 0x65ee70: cmp             w3, NULL
    // 0x65ee74: b.eq            #0x65ef2c
    // 0x65ee78: LoadField: r4 = r3->field_17
    //     0x65ee78: ldur            w4, [x3, #0x17]
    // 0x65ee7c: DecompressPointer r4
    //     0x65ee7c: add             x4, x4, HEAP, lsl #32
    // 0x65ee80: stur            x4, [fp, #-8]
    // 0x65ee84: cmp             w4, NULL
    // 0x65ee88: b.eq            #0x65ef4c
    // 0x65ee8c: mov             x0, x4
    // 0x65ee90: r2 = Null
    //     0x65ee90: mov             x2, NULL
    // 0x65ee94: r1 = Null
    //     0x65ee94: mov             x1, NULL
    // 0x65ee98: r4 = LoadClassIdInstr(r0)
    //     0x65ee98: ldur            x4, [x0, #-1]
    //     0x65ee9c: ubfx            x4, x4, #0xc, #0x14
    // 0x65eea0: cmp             x4, #0x80a
    // 0x65eea4: b.eq            #0x65eebc
    // 0x65eea8: r8 = MultiChildLayoutParentData<RenderBox>
    //     0x65eea8: add             x8, PP, #0x29, lsl #12  ; [pp+0x29170] Type: MultiChildLayoutParentData<RenderBox>
    //     0x65eeac: ldr             x8, [x8, #0x170]
    // 0x65eeb0: r3 = Null
    //     0x65eeb0: add             x3, PP, #0x2d, lsl #12  ; [pp+0x2d720] Null
    //     0x65eeb4: ldr             x3, [x3, #0x720]
    // 0x65eeb8: r0 = DefaultTypeTest()
    //     0x65eeb8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65eebc: ldur            x0, [fp, #-8]
    // 0x65eec0: LoadField: r1 = r0->field_7
    //     0x65eec0: ldur            w1, [x0, #7]
    // 0x65eec4: DecompressPointer r1
    //     0x65eec4: add             x1, x1, HEAP, lsl #32
    // 0x65eec8: LoadField: d0 = r1->field_7
    //     0x65eec8: ldur            d0, [x1, #7]
    // 0x65eecc: ldur            d1, [fp, #-0x20]
    // 0x65eed0: fadd            d2, d0, d1
    // 0x65eed4: stur            d2, [fp, #-0x30]
    // 0x65eed8: LoadField: d0 = r1->field_f
    //     0x65eed8: ldur            d0, [x1, #0xf]
    // 0x65eedc: ldur            d3, [fp, #-0x18]
    // 0x65eee0: fadd            d4, d0, d3
    // 0x65eee4: stur            d4, [fp, #-0x28]
    // 0x65eee8: r0 = Offset()
    //     0x65eee8: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65eeec: ldur            d0, [fp, #-0x30]
    // 0x65eef0: StoreField: r0->field_7 = d0
    //     0x65eef0: stur            d0, [x0, #7]
    // 0x65eef4: ldur            d0, [fp, #-0x28]
    // 0x65eef8: StoreField: r0->field_f = d0
    //     0x65eef8: stur            d0, [x0, #0xf]
    // 0x65eefc: ldr             x16, [fp, #0x18]
    // 0x65ef00: ldur            lr, [fp, #-0x10]
    // 0x65ef04: stp             lr, x16, [SP, #-0x10]!
    // 0x65ef08: SaveReg r0
    //     0x65ef08: str             x0, [SP, #-8]!
    // 0x65ef0c: r0 = paintChild()
    //     0x65ef0c: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x65ef10: add             SP, SP, #0x18
    // 0x65ef14: ldur            x1, [fp, #-8]
    // 0x65ef18: LoadField: r3 = r1->field_13
    //     0x65ef18: ldur            w3, [x1, #0x13]
    // 0x65ef1c: DecompressPointer r3
    //     0x65ef1c: add             x3, x3, HEAP, lsl #32
    // 0x65ef20: ldur            d0, [fp, #-0x20]
    // 0x65ef24: ldur            d1, [fp, #-0x18]
    // 0x65ef28: b               #0x65ee60
    // 0x65ef2c: r0 = Null
    //     0x65ef2c: mov             x0, NULL
    // 0x65ef30: LeaveFrame
    //     0x65ef30: mov             SP, fp
    //     0x65ef34: ldp             fp, lr, [SP], #0x10
    // 0x65ef38: ret
    //     0x65ef38: ret             
    // 0x65ef3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65ef3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65ef40: b               #0x65ee3c
    // 0x65ef44: r0 = StackOverflowSharedWithFPURegs()
    //     0x65ef44: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65ef48: b               #0x65ee70
    // 0x65ef4c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65ef4c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
}

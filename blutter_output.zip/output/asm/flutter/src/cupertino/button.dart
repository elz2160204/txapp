// lib: , url: package:flutter/src/cupertino/button.dart

// class id: 1049077, size: 0x8
class :: {
}

// class id: 3358, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CupertinoButtonState&State&SingleTickerProviderStateMixin extends State<CupertinoButton>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x614d58, size: 0x98
    // 0x614d58: EnterFrame
    //     0x614d58: stp             fp, lr, [SP, #-0x10]!
    //     0x614d5c: mov             fp, SP
    // 0x614d60: CheckStackOverflow
    //     0x614d60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614d64: cmp             SP, x16
    //     0x614d68: b.ls            #0x614de4
    // 0x614d6c: r0 = Ticker()
    //     0x614d6c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x614d70: mov             x1, x0
    // 0x614d74: r0 = false
    //     0x614d74: add             x0, NULL, #0x30  ; false
    // 0x614d78: StoreField: r1->field_b = r0
    //     0x614d78: stur            w0, [x1, #0xb]
    // 0x614d7c: ldr             x0, [fp, #0x10]
    // 0x614d80: StoreField: r1->field_13 = r0
    //     0x614d80: stur            w0, [x1, #0x13]
    // 0x614d84: mov             x0, x1
    // 0x614d88: ldr             x1, [fp, #0x18]
    // 0x614d8c: StoreField: r1->field_13 = r0
    //     0x614d8c: stur            w0, [x1, #0x13]
    //     0x614d90: ldurb           w16, [x1, #-1]
    //     0x614d94: ldurb           w17, [x0, #-1]
    //     0x614d98: and             x16, x17, x16, lsr #2
    //     0x614d9c: tst             x16, HEAP, lsr #32
    //     0x614da0: b.eq            #0x614da8
    //     0x614da4: bl              #0xd6826c
    // 0x614da8: SaveReg r1
    //     0x614da8: str             x1, [SP, #-8]!
    // 0x614dac: r0 = _updateTickerModeNotifier()
    //     0x614dac: bl              #0x614e14  ; [package:flutter/src/cupertino/button.dart] __CupertinoButtonState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x614db0: add             SP, SP, #8
    // 0x614db4: ldr             x16, [fp, #0x18]
    // 0x614db8: SaveReg r16
    //     0x614db8: str             x16, [SP, #-8]!
    // 0x614dbc: r0 = _updateTicker()
    //     0x614dbc: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614dc0: add             SP, SP, #8
    // 0x614dc4: ldr             x1, [fp, #0x18]
    // 0x614dc8: LoadField: r0 = r1->field_13
    //     0x614dc8: ldur            w0, [x1, #0x13]
    // 0x614dcc: DecompressPointer r0
    //     0x614dcc: add             x0, x0, HEAP, lsl #32
    // 0x614dd0: cmp             w0, NULL
    // 0x614dd4: b.eq            #0x614dec
    // 0x614dd8: LeaveFrame
    //     0x614dd8: mov             SP, fp
    //     0x614ddc: ldp             fp, lr, [SP], #0x10
    // 0x614de0: ret
    //     0x614de0: ret             
    // 0x614de4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614de4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614de8: b               #0x614d6c
    // 0x614dec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x614dec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x614e14, size: 0x11c
    // 0x614e14: EnterFrame
    //     0x614e14: stp             fp, lr, [SP, #-0x10]!
    //     0x614e18: mov             fp, SP
    // 0x614e1c: AllocStack(0x10)
    //     0x614e1c: sub             SP, SP, #0x10
    // 0x614e20: CheckStackOverflow
    //     0x614e20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614e24: cmp             SP, x16
    //     0x614e28: b.ls            #0x614f24
    // 0x614e2c: ldr             x0, [fp, #0x10]
    // 0x614e30: LoadField: r1 = r0->field_f
    //     0x614e30: ldur            w1, [x0, #0xf]
    // 0x614e34: DecompressPointer r1
    //     0x614e34: add             x1, x1, HEAP, lsl #32
    // 0x614e38: cmp             w1, NULL
    // 0x614e3c: b.eq            #0x614f2c
    // 0x614e40: SaveReg r1
    //     0x614e40: str             x1, [SP, #-8]!
    // 0x614e44: r0 = getNotifier()
    //     0x614e44: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x614e48: add             SP, SP, #8
    // 0x614e4c: mov             x1, x0
    // 0x614e50: ldr             x0, [fp, #0x10]
    // 0x614e54: stur            x1, [fp, #-0x10]
    // 0x614e58: LoadField: r2 = r0->field_17
    //     0x614e58: ldur            w2, [x0, #0x17]
    // 0x614e5c: DecompressPointer r2
    //     0x614e5c: add             x2, x2, HEAP, lsl #32
    // 0x614e60: stur            x2, [fp, #-8]
    // 0x614e64: cmp             w1, w2
    // 0x614e68: b.ne            #0x614e7c
    // 0x614e6c: r0 = Null
    //     0x614e6c: mov             x0, NULL
    // 0x614e70: LeaveFrame
    //     0x614e70: mov             SP, fp
    //     0x614e74: ldp             fp, lr, [SP], #0x10
    // 0x614e78: ret
    //     0x614e78: ret             
    // 0x614e7c: cmp             w2, NULL
    // 0x614e80: b.eq            #0x614ebc
    // 0x614e84: r1 = 1
    //     0x614e84: mov             x1, #1
    // 0x614e88: r0 = AllocateContext()
    //     0x614e88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614e8c: mov             x1, x0
    // 0x614e90: ldr             x0, [fp, #0x10]
    // 0x614e94: StoreField: r1->field_f = r0
    //     0x614e94: stur            w0, [x1, #0xf]
    // 0x614e98: mov             x2, x1
    // 0x614e9c: r1 = Function '_updateTicker@156311458':.
    //     0x614e9c: add             x1, PP, #0x40, lsl #12  ; [pp+0x405a0] AnonymousClosure: (0x614f30), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614ea0: ldr             x1, [x1, #0x5a0]
    // 0x614ea4: r0 = AllocateClosure()
    //     0x614ea4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614ea8: ldur            x16, [fp, #-8]
    // 0x614eac: stp             x0, x16, [SP, #-0x10]!
    // 0x614eb0: r0 = removeListener()
    //     0x614eb0: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x614eb4: add             SP, SP, #0x10
    // 0x614eb8: ldr             x0, [fp, #0x10]
    // 0x614ebc: r1 = 1
    //     0x614ebc: mov             x1, #1
    // 0x614ec0: r0 = AllocateContext()
    //     0x614ec0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614ec4: mov             x1, x0
    // 0x614ec8: ldr             x0, [fp, #0x10]
    // 0x614ecc: StoreField: r1->field_f = r0
    //     0x614ecc: stur            w0, [x1, #0xf]
    // 0x614ed0: mov             x2, x1
    // 0x614ed4: r1 = Function '_updateTicker@156311458':.
    //     0x614ed4: add             x1, PP, #0x40, lsl #12  ; [pp+0x405a0] AnonymousClosure: (0x614f30), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614ed8: ldr             x1, [x1, #0x5a0]
    // 0x614edc: r0 = AllocateClosure()
    //     0x614edc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614ee0: ldur            x16, [fp, #-0x10]
    // 0x614ee4: stp             x0, x16, [SP, #-0x10]!
    // 0x614ee8: r0 = addListener()
    //     0x614ee8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x614eec: add             SP, SP, #0x10
    // 0x614ef0: ldur            x0, [fp, #-0x10]
    // 0x614ef4: ldr             x1, [fp, #0x10]
    // 0x614ef8: StoreField: r1->field_17 = r0
    //     0x614ef8: stur            w0, [x1, #0x17]
    //     0x614efc: ldurb           w16, [x1, #-1]
    //     0x614f00: ldurb           w17, [x0, #-1]
    //     0x614f04: and             x16, x17, x16, lsr #2
    //     0x614f08: tst             x16, HEAP, lsr #32
    //     0x614f0c: b.eq            #0x614f14
    //     0x614f10: bl              #0xd6826c
    // 0x614f14: r0 = Null
    //     0x614f14: mov             x0, NULL
    // 0x614f18: LeaveFrame
    //     0x614f18: mov             SP, fp
    //     0x614f1c: ldp             fp, lr, [SP], #0x10
    // 0x614f20: ret
    //     0x614f20: ret             
    // 0x614f24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614f24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614f28: b               #0x614e2c
    // 0x614f2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x614f2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x614f30, size: 0x48
    // 0x614f30: EnterFrame
    //     0x614f30: stp             fp, lr, [SP, #-0x10]!
    //     0x614f34: mov             fp, SP
    // 0x614f38: ldr             x0, [fp, #0x10]
    // 0x614f3c: LoadField: r1 = r0->field_17
    //     0x614f3c: ldur            w1, [x0, #0x17]
    // 0x614f40: DecompressPointer r1
    //     0x614f40: add             x1, x1, HEAP, lsl #32
    // 0x614f44: CheckStackOverflow
    //     0x614f44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614f48: cmp             SP, x16
    //     0x614f4c: b.ls            #0x614f70
    // 0x614f50: LoadField: r0 = r1->field_f
    //     0x614f50: ldur            w0, [x1, #0xf]
    // 0x614f54: DecompressPointer r0
    //     0x614f54: add             x0, x0, HEAP, lsl #32
    // 0x614f58: SaveReg r0
    //     0x614f58: str             x0, [SP, #-8]!
    // 0x614f5c: r0 = _updateTicker()
    //     0x614f5c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614f60: add             SP, SP, #8
    // 0x614f64: LeaveFrame
    //     0x614f64: mov             SP, fp
    //     0x614f68: ldp             fp, lr, [SP], #0x10
    // 0x614f6c: ret
    //     0x614f6c: ret             
    // 0x614f70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614f70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614f74: b               #0x614f50
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f118, size: 0x4c
    // 0x81f118: EnterFrame
    //     0x81f118: stp             fp, lr, [SP, #-0x10]!
    //     0x81f11c: mov             fp, SP
    // 0x81f120: CheckStackOverflow
    //     0x81f120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f124: cmp             SP, x16
    //     0x81f128: b.ls            #0x81f15c
    // 0x81f12c: ldr             x16, [fp, #0x10]
    // 0x81f130: SaveReg r16
    //     0x81f130: str             x16, [SP, #-8]!
    // 0x81f134: r0 = _updateTickerModeNotifier()
    //     0x81f134: bl              #0x614e14  ; [package:flutter/src/cupertino/button.dart] __CupertinoButtonState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f138: add             SP, SP, #8
    // 0x81f13c: ldr             x16, [fp, #0x10]
    // 0x81f140: SaveReg r16
    //     0x81f140: str             x16, [SP, #-8]!
    // 0x81f144: r0 = _updateTicker()
    //     0x81f144: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f148: add             SP, SP, #8
    // 0x81f14c: r0 = Null
    //     0x81f14c: mov             x0, NULL
    // 0x81f150: LeaveFrame
    //     0x81f150: mov             SP, fp
    //     0x81f154: ldp             fp, lr, [SP], #0x10
    // 0x81f158: ret
    //     0x81f158: ret             
    // 0x81f15c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f15c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f160: b               #0x81f12c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa503a0, size: 0x8c
    // 0xa503a0: EnterFrame
    //     0xa503a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa503a4: mov             fp, SP
    // 0xa503a8: AllocStack(0x8)
    //     0xa503a8: sub             SP, SP, #8
    // 0xa503ac: CheckStackOverflow
    //     0xa503ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa503b0: cmp             SP, x16
    //     0xa503b4: b.ls            #0xa50424
    // 0xa503b8: ldr             x0, [fp, #0x10]
    // 0xa503bc: LoadField: r1 = r0->field_17
    //     0xa503bc: ldur            w1, [x0, #0x17]
    // 0xa503c0: DecompressPointer r1
    //     0xa503c0: add             x1, x1, HEAP, lsl #32
    // 0xa503c4: stur            x1, [fp, #-8]
    // 0xa503c8: cmp             w1, NULL
    // 0xa503cc: b.ne            #0xa503d8
    // 0xa503d0: mov             x1, x0
    // 0xa503d4: b               #0xa50410
    // 0xa503d8: r1 = 1
    //     0xa503d8: mov             x1, #1
    // 0xa503dc: r0 = AllocateContext()
    //     0xa503dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa503e0: mov             x1, x0
    // 0xa503e4: ldr             x0, [fp, #0x10]
    // 0xa503e8: StoreField: r1->field_f = r0
    //     0xa503e8: stur            w0, [x1, #0xf]
    // 0xa503ec: mov             x2, x1
    // 0xa503f0: r1 = Function '_updateTicker@156311458':.
    //     0xa503f0: add             x1, PP, #0x40, lsl #12  ; [pp+0x405a0] AnonymousClosure: (0x614f30), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa503f4: ldr             x1, [x1, #0x5a0]
    // 0xa503f8: r0 = AllocateClosure()
    //     0xa503f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa503fc: ldur            x16, [fp, #-8]
    // 0xa50400: stp             x0, x16, [SP, #-0x10]!
    // 0xa50404: r0 = removeListener()
    //     0xa50404: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa50408: add             SP, SP, #0x10
    // 0xa5040c: ldr             x1, [fp, #0x10]
    // 0xa50410: StoreField: r1->field_17 = rNULL
    //     0xa50410: stur            NULL, [x1, #0x17]
    // 0xa50414: r0 = Null
    //     0xa50414: mov             x0, NULL
    // 0xa50418: LeaveFrame
    //     0xa50418: mov             SP, fp
    //     0xa5041c: ldp             fp, lr, [SP], #0x10
    // 0xa50420: ret
    //     0xa50420: ret             
    // 0xa50424: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50424: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50428: b               #0xa503b8
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa5042c, size: 0x48
    // 0xa5042c: EnterFrame
    //     0xa5042c: stp             fp, lr, [SP, #-0x10]!
    //     0xa50430: mov             fp, SP
    // 0xa50434: ldr             x0, [fp, #0x10]
    // 0xa50438: LoadField: r1 = r0->field_17
    //     0xa50438: ldur            w1, [x0, #0x17]
    // 0xa5043c: DecompressPointer r1
    //     0xa5043c: add             x1, x1, HEAP, lsl #32
    // 0xa50440: CheckStackOverflow
    //     0xa50440: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50444: cmp             SP, x16
    //     0xa50448: b.ls            #0xa5046c
    // 0xa5044c: LoadField: r0 = r1->field_f
    //     0xa5044c: ldur            w0, [x1, #0xf]
    // 0xa50450: DecompressPointer r0
    //     0xa50450: add             x0, x0, HEAP, lsl #32
    // 0xa50454: SaveReg r0
    //     0xa50454: str             x0, [SP, #-8]!
    // 0xa50458: r0 = dispose()
    //     0xa50458: bl              #0xa503a0  ; [package:flutter/src/cupertino/button.dart] __CupertinoButtonState&State&SingleTickerProviderStateMixin::dispose
    // 0xa5045c: add             SP, SP, #8
    // 0xa50460: LeaveFrame
    //     0xa50460: mov             SP, fp
    //     0xa50464: ldp             fp, lr, [SP], #0x10
    // 0xa50468: ret
    //     0xa50468: ret             
    // 0xa5046c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5046c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50470: b               #0xa5044c
  }
}

// class id: 3359, size: 0x2c, field offset: 0x1c
class _CupertinoButtonState extends __CupertinoButtonState&State&SingleTickerProviderStateMixin {

  late Animation<double> _opacityAnimation; // offset: 0x24
  late AnimationController _animationController; // offset: 0x20

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7aecfc, size: 0xb4
    // 0x7aecfc: EnterFrame
    //     0x7aecfc: stp             fp, lr, [SP, #-0x10]!
    //     0x7aed00: mov             fp, SP
    // 0x7aed04: CheckStackOverflow
    //     0x7aed04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aed08: cmp             SP, x16
    //     0x7aed0c: b.ls            #0x7aeda8
    // 0x7aed10: ldr             x0, [fp, #0x10]
    // 0x7aed14: r2 = Null
    //     0x7aed14: mov             x2, NULL
    // 0x7aed18: r1 = Null
    //     0x7aed18: mov             x1, NULL
    // 0x7aed1c: r4 = 59
    //     0x7aed1c: mov             x4, #0x3b
    // 0x7aed20: branchIfSmi(r0, 0x7aed2c)
    //     0x7aed20: tbz             w0, #0, #0x7aed2c
    // 0x7aed24: r4 = LoadClassIdInstr(r0)
    //     0x7aed24: ldur            x4, [x0, #-1]
    //     0x7aed28: ubfx            x4, x4, #0xc, #0x14
    // 0x7aed2c: r17 = 4183
    //     0x7aed2c: mov             x17, #0x1057
    // 0x7aed30: cmp             x4, x17
    // 0x7aed34: b.eq            #0x7aed4c
    // 0x7aed38: r8 = CupertinoButton
    //     0x7aed38: add             x8, PP, #0x40, lsl #12  ; [pp+0x40558] Type: CupertinoButton
    //     0x7aed3c: ldr             x8, [x8, #0x558]
    // 0x7aed40: r3 = Null
    //     0x7aed40: add             x3, PP, #0x40, lsl #12  ; [pp+0x40560] Null
    //     0x7aed44: ldr             x3, [x3, #0x560]
    // 0x7aed48: r0 = CupertinoButton()
    //     0x7aed48: bl              #0x614df0  ; IsType_CupertinoButton_Stub
    // 0x7aed4c: ldr             x3, [fp, #0x18]
    // 0x7aed50: LoadField: r2 = r3->field_7
    //     0x7aed50: ldur            w2, [x3, #7]
    // 0x7aed54: DecompressPointer r2
    //     0x7aed54: add             x2, x2, HEAP, lsl #32
    // 0x7aed58: ldr             x0, [fp, #0x10]
    // 0x7aed5c: r1 = Null
    //     0x7aed5c: mov             x1, NULL
    // 0x7aed60: cmp             w2, NULL
    // 0x7aed64: b.eq            #0x7aed88
    // 0x7aed68: LoadField: r4 = r2->field_17
    //     0x7aed68: ldur            w4, [x2, #0x17]
    // 0x7aed6c: DecompressPointer r4
    //     0x7aed6c: add             x4, x4, HEAP, lsl #32
    // 0x7aed70: r8 = X0 bound StatefulWidget
    //     0x7aed70: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7aed74: ldr             x8, [x8, #0x858]
    // 0x7aed78: LoadField: r9 = r4->field_7
    //     0x7aed78: ldur            x9, [x4, #7]
    // 0x7aed7c: r3 = Null
    //     0x7aed7c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40570] Null
    //     0x7aed80: ldr             x3, [x3, #0x570]
    // 0x7aed84: blr             x9
    // 0x7aed88: ldr             x16, [fp, #0x18]
    // 0x7aed8c: SaveReg r16
    //     0x7aed8c: str             x16, [SP, #-8]!
    // 0x7aed90: r0 = _setTween()
    //     0x7aed90: bl              #0x7aedb0  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_setTween
    // 0x7aed94: add             SP, SP, #8
    // 0x7aed98: r0 = Null
    //     0x7aed98: mov             x0, NULL
    // 0x7aed9c: LeaveFrame
    //     0x7aed9c: mov             SP, fp
    //     0x7aeda0: ldp             fp, lr, [SP], #0x10
    // 0x7aeda4: ret
    //     0x7aeda4: ret             
    // 0x7aeda8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aeda8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aedac: b               #0x7aed10
  }
  _ _setTween(/* No info */) {
    // ** addr: 0x7aedb0, size: 0xec
    // 0x7aedb0: EnterFrame
    //     0x7aedb0: stp             fp, lr, [SP, #-0x10]!
    //     0x7aedb4: mov             fp, SP
    // 0x7aedb8: AllocStack(0x10)
    //     0x7aedb8: sub             SP, SP, #0x10
    // 0x7aedbc: ldr             x0, [fp, #0x10]
    // 0x7aedc0: LoadField: r3 = r0->field_1b
    //     0x7aedc0: ldur            w3, [x0, #0x1b]
    // 0x7aedc4: DecompressPointer r3
    //     0x7aedc4: add             x3, x3, HEAP, lsl #32
    // 0x7aedc8: stur            x3, [fp, #-0x10]
    // 0x7aedcc: LoadField: r1 = r0->field_b
    //     0x7aedcc: ldur            w1, [x0, #0xb]
    // 0x7aedd0: DecompressPointer r1
    //     0x7aedd0: add             x1, x1, HEAP, lsl #32
    // 0x7aedd4: cmp             w1, NULL
    // 0x7aedd8: b.eq            #0x7aee7c
    // 0x7aeddc: LoadField: d0 = r1->field_27
    //     0x7aeddc: ldur            d0, [x1, #0x27]
    // 0x7aede0: LoadField: r2 = r3->field_7
    //     0x7aede0: ldur            w2, [x3, #7]
    // 0x7aede4: DecompressPointer r2
    //     0x7aede4: add             x2, x2, HEAP, lsl #32
    // 0x7aede8: r4 = inline_Allocate_Double()
    //     0x7aede8: ldp             x4, x0, [THR, #0x60]  ; THR::top
    //     0x7aedec: add             x4, x4, #0x10
    //     0x7aedf0: cmp             x0, x4
    //     0x7aedf4: b.ls            #0x7aee80
    //     0x7aedf8: str             x4, [THR, #0x60]  ; THR::top
    //     0x7aedfc: sub             x4, x4, #0xf
    //     0x7aee00: mov             x0, #0xd108
    //     0x7aee04: movk            x0, #3, lsl #16
    //     0x7aee08: stur            x0, [x4, #-1]
    // 0x7aee0c: StoreField: r4->field_7 = d0
    //     0x7aee0c: stur            d0, [x4, #7]
    // 0x7aee10: mov             x0, x4
    // 0x7aee14: stur            x4, [fp, #-8]
    // 0x7aee18: r1 = Null
    //     0x7aee18: mov             x1, NULL
    // 0x7aee1c: cmp             w0, NULL
    // 0x7aee20: b.eq            #0x7aee48
    // 0x7aee24: cmp             w2, NULL
    // 0x7aee28: b.eq            #0x7aee48
    // 0x7aee2c: LoadField: r4 = r2->field_17
    //     0x7aee2c: ldur            w4, [x2, #0x17]
    // 0x7aee30: DecompressPointer r4
    //     0x7aee30: add             x4, x4, HEAP, lsl #32
    // 0x7aee34: r8 = X0?
    //     0x7aee34: ldr             x8, [PP, #0x1e8]  ; [pp+0x1e8] TypeParameter: X0?
    // 0x7aee38: LoadField: r9 = r4->field_7
    //     0x7aee38: ldur            x9, [x4, #7]
    // 0x7aee3c: r3 = Null
    //     0x7aee3c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40580] Null
    //     0x7aee40: ldr             x3, [x3, #0x580]
    // 0x7aee44: blr             x9
    // 0x7aee48: ldur            x0, [fp, #-8]
    // 0x7aee4c: ldur            x1, [fp, #-0x10]
    // 0x7aee50: StoreField: r1->field_f = r0
    //     0x7aee50: stur            w0, [x1, #0xf]
    //     0x7aee54: ldurb           w16, [x1, #-1]
    //     0x7aee58: ldurb           w17, [x0, #-1]
    //     0x7aee5c: and             x16, x17, x16, lsr #2
    //     0x7aee60: tst             x16, HEAP, lsr #32
    //     0x7aee64: b.eq            #0x7aee6c
    //     0x7aee68: bl              #0xd6826c
    // 0x7aee6c: r0 = Null
    //     0x7aee6c: mov             x0, NULL
    // 0x7aee70: LeaveFrame
    //     0x7aee70: mov             SP, fp
    //     0x7aee74: ldp             fp, lr, [SP], #0x10
    // 0x7aee78: ret
    //     0x7aee78: ret             
    // 0x7aee7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7aee7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7aee80: SaveReg d0
    //     0x7aee80: str             q0, [SP, #-0x10]!
    // 0x7aee84: stp             x2, x3, [SP, #-0x10]!
    // 0x7aee88: r0 = AllocateDouble()
    //     0x7aee88: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x7aee8c: mov             x4, x0
    // 0x7aee90: ldp             x2, x3, [SP], #0x10
    // 0x7aee94: RestoreReg d0
    //     0x7aee94: ldr             q0, [SP], #0x10
    // 0x7aee98: b               #0x7aee0c
  }
  _ build(/* No info */) {
    // ** addr: 0x83f730, size: 0x5e8
    // 0x83f730: EnterFrame
    //     0x83f730: stp             fp, lr, [SP, #-0x10]!
    //     0x83f734: mov             fp, SP
    // 0x83f738: AllocStack(0x70)
    //     0x83f738: sub             SP, SP, #0x70
    // 0x83f73c: CheckStackOverflow
    //     0x83f73c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83f740: cmp             SP, x16
    //     0x83f744: b.ls            #0x83fcf4
    // 0x83f748: ldr             x0, [fp, #0x18]
    // 0x83f74c: LoadField: r1 = r0->field_b
    //     0x83f74c: ldur            w1, [x0, #0xb]
    // 0x83f750: DecompressPointer r1
    //     0x83f750: add             x1, x1, HEAP, lsl #32
    // 0x83f754: cmp             w1, NULL
    // 0x83f758: b.eq            #0x83fcfc
    // 0x83f75c: LoadField: r2 = r1->field_1b
    //     0x83f75c: ldur            w2, [x1, #0x1b]
    // 0x83f760: DecompressPointer r2
    //     0x83f760: add             x2, x2, HEAP, lsl #32
    // 0x83f764: cmp             w2, NULL
    // 0x83f768: r16 = true
    //     0x83f768: add             x16, NULL, #0x20  ; true
    // 0x83f76c: r17 = false
    //     0x83f76c: add             x17, NULL, #0x30  ; false
    // 0x83f770: csel            x1, x16, x17, ne
    // 0x83f774: stur            x1, [fp, #-8]
    // 0x83f778: ldr             x16, [fp, #0x10]
    // 0x83f77c: SaveReg r16
    //     0x83f77c: str             x16, [SP, #-8]!
    // 0x83f780: r0 = of()
    //     0x83f780: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x83f784: add             SP, SP, #8
    // 0x83f788: stur            x0, [fp, #-0x20]
    // 0x83f78c: r1 = LoadClassIdInstr(r0)
    //     0x83f78c: ldur            x1, [x0, #-1]
    //     0x83f790: ubfx            x1, x1, #0xc, #0x14
    // 0x83f794: lsl             x1, x1, #1
    // 0x83f798: stur            x1, [fp, #-0x18]
    // 0x83f79c: r17 = 5322
    //     0x83f79c: mov             x17, #0x14ca
    // 0x83f7a0: cmp             w1, w17
    // 0x83f7a4: b.ne            #0x83f7d4
    // 0x83f7a8: LoadField: r2 = r0->field_b
    //     0x83f7a8: ldur            w2, [x0, #0xb]
    // 0x83f7ac: DecompressPointer r2
    //     0x83f7ac: add             x2, x2, HEAP, lsl #32
    // 0x83f7b0: cmp             w2, NULL
    // 0x83f7b4: b.ne            #0x83f7cc
    // 0x83f7b8: LoadField: r2 = r0->field_1f
    //     0x83f7b8: ldur            w2, [x0, #0x1f]
    // 0x83f7bc: DecompressPointer r2
    //     0x83f7bc: add             x2, x2, HEAP, lsl #32
    // 0x83f7c0: LoadField: r3 = r2->field_b
    //     0x83f7c0: ldur            w3, [x2, #0xb]
    // 0x83f7c4: DecompressPointer r3
    //     0x83f7c4: add             x3, x3, HEAP, lsl #32
    // 0x83f7c8: mov             x2, x3
    // 0x83f7cc: mov             x3, x2
    // 0x83f7d0: b               #0x83f810
    // 0x83f7d4: LoadField: r2 = r0->field_27
    //     0x83f7d4: ldur            w2, [x0, #0x27]
    // 0x83f7d8: DecompressPointer r2
    //     0x83f7d8: add             x2, x2, HEAP, lsl #32
    // 0x83f7dc: LoadField: r3 = r2->field_b
    //     0x83f7dc: ldur            w3, [x2, #0xb]
    // 0x83f7e0: DecompressPointer r3
    //     0x83f7e0: add             x3, x3, HEAP, lsl #32
    // 0x83f7e4: cmp             w3, NULL
    // 0x83f7e8: b.ne            #0x83f808
    // 0x83f7ec: LoadField: r2 = r0->field_23
    //     0x83f7ec: ldur            w2, [x0, #0x23]
    // 0x83f7f0: DecompressPointer r2
    //     0x83f7f0: add             x2, x2, HEAP, lsl #32
    // 0x83f7f4: LoadField: r3 = r2->field_3f
    //     0x83f7f4: ldur            w3, [x2, #0x3f]
    // 0x83f7f8: DecompressPointer r3
    //     0x83f7f8: add             x3, x3, HEAP, lsl #32
    // 0x83f7fc: LoadField: r2 = r3->field_b
    //     0x83f7fc: ldur            w2, [x3, #0xb]
    // 0x83f800: DecompressPointer r2
    //     0x83f800: add             x2, x2, HEAP, lsl #32
    // 0x83f804: b               #0x83f80c
    // 0x83f808: mov             x2, x3
    // 0x83f80c: mov             x3, x2
    // 0x83f810: ldr             x2, [fp, #0x18]
    // 0x83f814: stur            x3, [fp, #-0x10]
    // 0x83f818: LoadField: r4 = r2->field_b
    //     0x83f818: ldur            w4, [x2, #0xb]
    // 0x83f81c: DecompressPointer r4
    //     0x83f81c: add             x4, x4, HEAP, lsl #32
    // 0x83f820: cmp             w4, NULL
    // 0x83f824: b.eq            #0x83fd00
    // 0x83f828: LoadField: r5 = r4->field_13
    //     0x83f828: ldur            w5, [x4, #0x13]
    // 0x83f82c: DecompressPointer r5
    //     0x83f82c: add             x5, x5, HEAP, lsl #32
    // 0x83f830: cmp             w5, NULL
    // 0x83f834: b.ne            #0x83f840
    // 0x83f838: r0 = Null
    //     0x83f838: mov             x0, NULL
    // 0x83f83c: b               #0x83f850
    // 0x83f840: ldr             x16, [fp, #0x10]
    // 0x83f844: stp             x16, x5, [SP, #-0x10]!
    // 0x83f848: r0 = maybeResolve()
    //     0x83f848: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0x83f84c: add             SP, SP, #0x10
    // 0x83f850: stur            x0, [fp, #-0x28]
    // 0x83f854: cmp             w0, NULL
    // 0x83f858: b.eq            #0x83f8dc
    // 0x83f85c: ldur            x1, [fp, #-0x18]
    // 0x83f860: r17 = 5322
    //     0x83f860: mov             x17, #0x14ca
    // 0x83f864: cmp             w1, w17
    // 0x83f868: b.ne            #0x83f898
    // 0x83f86c: ldur            x1, [fp, #-0x20]
    // 0x83f870: LoadField: r2 = r1->field_f
    //     0x83f870: ldur            w2, [x1, #0xf]
    // 0x83f874: DecompressPointer r2
    //     0x83f874: add             x2, x2, HEAP, lsl #32
    // 0x83f878: cmp             w2, NULL
    // 0x83f87c: b.ne            #0x83f8d4
    // 0x83f880: LoadField: r2 = r1->field_1f
    //     0x83f880: ldur            w2, [x1, #0x1f]
    // 0x83f884: DecompressPointer r2
    //     0x83f884: add             x2, x2, HEAP, lsl #32
    // 0x83f888: LoadField: r3 = r2->field_f
    //     0x83f888: ldur            w3, [x2, #0xf]
    // 0x83f88c: DecompressPointer r3
    //     0x83f88c: add             x3, x3, HEAP, lsl #32
    // 0x83f890: mov             x2, x3
    // 0x83f894: b               #0x83f8d4
    // 0x83f898: ldur            x1, [fp, #-0x20]
    // 0x83f89c: LoadField: r2 = r1->field_27
    //     0x83f89c: ldur            w2, [x1, #0x27]
    // 0x83f8a0: DecompressPointer r2
    //     0x83f8a0: add             x2, x2, HEAP, lsl #32
    // 0x83f8a4: LoadField: r3 = r2->field_f
    //     0x83f8a4: ldur            w3, [x2, #0xf]
    // 0x83f8a8: DecompressPointer r3
    //     0x83f8a8: add             x3, x3, HEAP, lsl #32
    // 0x83f8ac: cmp             w3, NULL
    // 0x83f8b0: b.ne            #0x83f8d0
    // 0x83f8b4: LoadField: r2 = r1->field_23
    //     0x83f8b4: ldur            w2, [x1, #0x23]
    // 0x83f8b8: DecompressPointer r2
    //     0x83f8b8: add             x2, x2, HEAP, lsl #32
    // 0x83f8bc: LoadField: r3 = r2->field_3f
    //     0x83f8bc: ldur            w3, [x2, #0x3f]
    // 0x83f8c0: DecompressPointer r3
    //     0x83f8c0: add             x3, x3, HEAP, lsl #32
    // 0x83f8c4: LoadField: r2 = r3->field_f
    //     0x83f8c4: ldur            w2, [x3, #0xf]
    // 0x83f8c8: DecompressPointer r2
    //     0x83f8c8: add             x2, x2, HEAP, lsl #32
    // 0x83f8cc: b               #0x83f8d4
    // 0x83f8d0: mov             x2, x3
    // 0x83f8d4: mov             x1, x2
    // 0x83f8d8: b               #0x83f90c
    // 0x83f8dc: ldur            x1, [fp, #-0x20]
    // 0x83f8e0: ldur            x2, [fp, #-8]
    // 0x83f8e4: tbnz            w2, #4, #0x83f8f0
    // 0x83f8e8: ldur            x0, [fp, #-0x10]
    // 0x83f8ec: b               #0x83f908
    // 0x83f8f0: r16 = Instance_CupertinoDynamicColor
    //     0x83f8f0: add             x16, PP, #0x40, lsl #12  ; [pp+0x404d8] Obj!CupertinoDynamicColor@b5e671
    //     0x83f8f4: ldr             x16, [x16, #0x4d8]
    // 0x83f8f8: ldr             lr, [fp, #0x10]
    // 0x83f8fc: stp             lr, x16, [SP, #-0x10]!
    // 0x83f900: r0 = resolveFrom()
    //     0x83f900: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x83f904: add             SP, SP, #0x10
    // 0x83f908: mov             x1, x0
    // 0x83f90c: ldur            x0, [fp, #-8]
    // 0x83f910: stur            x1, [fp, #-0x10]
    // 0x83f914: ldur            x16, [fp, #-0x20]
    // 0x83f918: SaveReg r16
    //     0x83f918: str             x16, [SP, #-8]!
    // 0x83f91c: r0 = textTheme()
    //     0x83f91c: bl              #0x83fe48  ; [package:flutter/src/cupertino/theme.dart] CupertinoThemeData::textTheme
    // 0x83f920: add             SP, SP, #8
    // 0x83f924: SaveReg r0
    //     0x83f924: str             x0, [SP, #-8]!
    // 0x83f928: r0 = textStyle()
    //     0x83f928: bl              #0x83fd48  ; [package:flutter/src/cupertino/theme.dart] _DefaultCupertinoTextThemeData::textStyle
    // 0x83f92c: add             SP, SP, #8
    // 0x83f930: ldur            x16, [fp, #-0x10]
    // 0x83f934: stp             x16, x0, [SP, #-0x10]!
    // 0x83f938: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x83f938: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x83f93c: ldr             x4, [x4, #0x168]
    // 0x83f940: r0 = copyWith()
    //     0x83f940: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x83f944: add             SP, SP, #0x10
    // 0x83f948: mov             x1, x0
    // 0x83f94c: ldur            x0, [fp, #-8]
    // 0x83f950: stur            x1, [fp, #-0x18]
    // 0x83f954: tbnz            w0, #4, #0x83f988
    // 0x83f958: ldr             x2, [fp, #0x18]
    // 0x83f95c: r1 = 1
    //     0x83f95c: mov             x1, #1
    // 0x83f960: r0 = AllocateContext()
    //     0x83f960: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83f964: mov             x1, x0
    // 0x83f968: ldr             x0, [fp, #0x18]
    // 0x83f96c: StoreField: r1->field_f = r0
    //     0x83f96c: stur            w0, [x1, #0xf]
    // 0x83f970: mov             x2, x1
    // 0x83f974: r1 = Function '_handleTapDown@585145554':.
    //     0x83f974: add             x1, PP, #0x40, lsl #12  ; [pp+0x404e0] AnonymousClosure: (0x84023c), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapDown (0x840288)
    //     0x83f978: ldr             x1, [x1, #0x4e0]
    // 0x83f97c: r0 = AllocateClosure()
    //     0x83f97c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83f980: mov             x1, x0
    // 0x83f984: b               #0x83f98c
    // 0x83f988: r1 = Null
    //     0x83f988: mov             x1, NULL
    // 0x83f98c: ldur            x0, [fp, #-8]
    // 0x83f990: stur            x1, [fp, #-0x20]
    // 0x83f994: tbnz            w0, #4, #0x83f9c8
    // 0x83f998: ldr             x2, [fp, #0x18]
    // 0x83f99c: r1 = 1
    //     0x83f99c: mov             x1, #1
    // 0x83f9a0: r0 = AllocateContext()
    //     0x83f9a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83f9a4: mov             x1, x0
    // 0x83f9a8: ldr             x0, [fp, #0x18]
    // 0x83f9ac: StoreField: r1->field_f = r0
    //     0x83f9ac: stur            w0, [x1, #0xf]
    // 0x83f9b0: mov             x2, x1
    // 0x83f9b4: r1 = Function '_handleTapUp@585145554':.
    //     0x83f9b4: add             x1, PP, #0x40, lsl #12  ; [pp+0x404e8] AnonymousClosure: (0x8401a0), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapUp (0x8401ec)
    //     0x83f9b8: ldr             x1, [x1, #0x4e8]
    // 0x83f9bc: r0 = AllocateClosure()
    //     0x83f9bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83f9c0: mov             x1, x0
    // 0x83f9c4: b               #0x83f9cc
    // 0x83f9c8: r1 = Null
    //     0x83f9c8: mov             x1, NULL
    // 0x83f9cc: ldur            x0, [fp, #-8]
    // 0x83f9d0: stur            x1, [fp, #-0x30]
    // 0x83f9d4: tbnz            w0, #4, #0x83fa08
    // 0x83f9d8: ldr             x2, [fp, #0x18]
    // 0x83f9dc: r1 = 1
    //     0x83f9dc: mov             x1, #1
    // 0x83f9e0: r0 = AllocateContext()
    //     0x83f9e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83f9e4: mov             x1, x0
    // 0x83f9e8: ldr             x0, [fp, #0x18]
    // 0x83f9ec: StoreField: r1->field_f = r0
    //     0x83f9ec: stur            w0, [x1, #0xf]
    // 0x83f9f0: mov             x2, x1
    // 0x83f9f4: r1 = Function '_handleTapCancel@585145554':.
    //     0x83f9f4: add             x1, PP, #0x40, lsl #12  ; [pp+0x404f0] AnonymousClosure: (0x83ff60), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapCancel (0x83ffa8)
    //     0x83f9f8: ldr             x1, [x1, #0x4f0]
    // 0x83f9fc: r0 = AllocateClosure()
    //     0x83f9fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83fa00: mov             x2, x0
    // 0x83fa04: b               #0x83fa0c
    // 0x83fa08: r2 = Null
    //     0x83fa08: mov             x2, NULL
    // 0x83fa0c: ldr             x0, [fp, #0x18]
    // 0x83fa10: ldur            x1, [fp, #-0x28]
    // 0x83fa14: stur            x2, [fp, #-0x48]
    // 0x83fa18: LoadField: r3 = r0->field_b
    //     0x83fa18: ldur            w3, [x0, #0xb]
    // 0x83fa1c: DecompressPointer r3
    //     0x83fa1c: add             x3, x3, HEAP, lsl #32
    // 0x83fa20: stur            x3, [fp, #-0x40]
    // 0x83fa24: cmp             w3, NULL
    // 0x83fa28: b.eq            #0x83fd04
    // 0x83fa2c: LoadField: r4 = r3->field_1b
    //     0x83fa2c: ldur            w4, [x3, #0x1b]
    // 0x83fa30: DecompressPointer r4
    //     0x83fa30: add             x4, x4, HEAP, lsl #32
    // 0x83fa34: stur            x4, [fp, #-0x38]
    // 0x83fa38: LoadField: d0 = r3->field_1f
    //     0x83fa38: ldur            d0, [x3, #0x1f]
    // 0x83fa3c: stur            d0, [fp, #-0x70]
    // 0x83fa40: r0 = BoxConstraints()
    //     0x83fa40: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x83fa44: ldur            d0, [fp, #-0x70]
    // 0x83fa48: stur            x0, [fp, #-0x60]
    // 0x83fa4c: StoreField: r0->field_7 = d0
    //     0x83fa4c: stur            d0, [x0, #7]
    // 0x83fa50: d1 = inf
    //     0x83fa50: ldr             d1, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x83fa54: StoreField: r0->field_f = d1
    //     0x83fa54: stur            d1, [x0, #0xf]
    // 0x83fa58: StoreField: r0->field_17 = d0
    //     0x83fa58: stur            d0, [x0, #0x17]
    // 0x83fa5c: StoreField: r0->field_1f = d1
    //     0x83fa5c: stur            d1, [x0, #0x1f]
    // 0x83fa60: ldr             x1, [fp, #0x18]
    // 0x83fa64: LoadField: r2 = r1->field_23
    //     0x83fa64: ldur            w2, [x1, #0x23]
    // 0x83fa68: DecompressPointer r2
    //     0x83fa68: add             x2, x2, HEAP, lsl #32
    // 0x83fa6c: r16 = Sentinel
    //     0x83fa6c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x83fa70: cmp             w2, w16
    // 0x83fa74: b.eq            #0x83fd08
    // 0x83fa78: ldur            x3, [fp, #-0x40]
    // 0x83fa7c: stur            x2, [fp, #-0x58]
    // 0x83fa80: LoadField: r4 = r3->field_2f
    //     0x83fa80: ldur            w4, [x3, #0x2f]
    // 0x83fa84: DecompressPointer r4
    //     0x83fa84: add             x4, x4, HEAP, lsl #32
    // 0x83fa88: ldur            x5, [fp, #-0x28]
    // 0x83fa8c: stur            x4, [fp, #-0x50]
    // 0x83fa90: cmp             w5, NULL
    // 0x83fa94: b.eq            #0x83fac0
    // 0x83fa98: ldur            x6, [fp, #-8]
    // 0x83fa9c: tbz             w6, #4, #0x83fac0
    // 0x83faa0: LoadField: r5 = r3->field_17
    //     0x83faa0: ldur            w5, [x3, #0x17]
    // 0x83faa4: DecompressPointer r5
    //     0x83faa4: add             x5, x5, HEAP, lsl #32
    // 0x83faa8: ldr             x16, [fp, #0x10]
    // 0x83faac: stp             x16, x5, [SP, #-0x10]!
    // 0x83fab0: r0 = resolve()
    //     0x83fab0: bl              #0x6ca720  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0x83fab4: add             SP, SP, #0x10
    // 0x83fab8: mov             x6, x0
    // 0x83fabc: b               #0x83fac4
    // 0x83fac0: mov             x6, x5
    // 0x83fac4: ldr             x1, [fp, #0x18]
    // 0x83fac8: ldur            x5, [fp, #-0x10]
    // 0x83facc: ldur            x4, [fp, #-0x18]
    // 0x83fad0: ldur            x0, [fp, #-0x60]
    // 0x83fad4: ldur            x3, [fp, #-0x50]
    // 0x83fad8: ldur            x2, [fp, #-0x58]
    // 0x83fadc: stur            x6, [fp, #-8]
    // 0x83fae0: r0 = BoxDecoration()
    //     0x83fae0: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x83fae4: mov             x1, x0
    // 0x83fae8: ldur            x0, [fp, #-8]
    // 0x83faec: stur            x1, [fp, #-0x68]
    // 0x83faf0: StoreField: r1->field_7 = r0
    //     0x83faf0: stur            w0, [x1, #7]
    // 0x83faf4: ldur            x0, [fp, #-0x50]
    // 0x83faf8: StoreField: r1->field_13 = r0
    //     0x83faf8: stur            w0, [x1, #0x13]
    // 0x83fafc: r0 = Instance_BoxShape
    //     0x83fafc: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x83fb00: ldr             x0, [x0, #0xe68]
    // 0x83fb04: StoreField: r1->field_23 = r0
    //     0x83fb04: stur            w0, [x1, #0x23]
    // 0x83fb08: ldr             x0, [fp, #0x18]
    // 0x83fb0c: LoadField: r2 = r0->field_b
    //     0x83fb0c: ldur            w2, [x0, #0xb]
    // 0x83fb10: DecompressPointer r2
    //     0x83fb10: add             x2, x2, HEAP, lsl #32
    // 0x83fb14: stur            x2, [fp, #-0x40]
    // 0x83fb18: cmp             w2, NULL
    // 0x83fb1c: b.eq            #0x83fd14
    // 0x83fb20: LoadField: r0 = r2->field_f
    //     0x83fb20: ldur            w0, [x2, #0xf]
    // 0x83fb24: DecompressPointer r0
    //     0x83fb24: add             x0, x0, HEAP, lsl #32
    // 0x83fb28: stur            x0, [fp, #-0x28]
    // 0x83fb2c: LoadField: r3 = r2->field_33
    //     0x83fb2c: ldur            w3, [x2, #0x33]
    // 0x83fb30: DecompressPointer r3
    //     0x83fb30: add             x3, x3, HEAP, lsl #32
    // 0x83fb34: stur            x3, [fp, #-8]
    // 0x83fb38: r0 = IconThemeData()
    //     0x83fb38: bl              #0x83fd3c  ; AllocateIconThemeDataStub -> IconThemeData (size=0x28)
    // 0x83fb3c: mov             x1, x0
    // 0x83fb40: ldur            x0, [fp, #-0x10]
    // 0x83fb44: stur            x1, [fp, #-0x50]
    // 0x83fb48: StoreField: r1->field_1b = r0
    //     0x83fb48: stur            w0, [x1, #0x1b]
    // 0x83fb4c: ldur            x0, [fp, #-0x40]
    // 0x83fb50: LoadField: r2 = r0->field_b
    //     0x83fb50: ldur            w2, [x0, #0xb]
    // 0x83fb54: DecompressPointer r2
    //     0x83fb54: add             x2, x2, HEAP, lsl #32
    // 0x83fb58: stur            x2, [fp, #-0x10]
    // 0x83fb5c: r0 = IconTheme()
    //     0x83fb5c: bl              #0x83fd30  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0x83fb60: mov             x1, x0
    // 0x83fb64: ldur            x0, [fp, #-0x50]
    // 0x83fb68: stur            x1, [fp, #-0x40]
    // 0x83fb6c: StoreField: r1->field_f = r0
    //     0x83fb6c: stur            w0, [x1, #0xf]
    // 0x83fb70: ldur            x0, [fp, #-0x10]
    // 0x83fb74: StoreField: r1->field_b = r0
    //     0x83fb74: stur            w0, [x1, #0xb]
    // 0x83fb78: r0 = DefaultTextStyle()
    //     0x83fb78: bl              #0x83fd24  ; AllocateDefaultTextStyleStub -> DefaultTextStyle (size=0x2c)
    // 0x83fb7c: mov             x1, x0
    // 0x83fb80: ldur            x0, [fp, #-0x18]
    // 0x83fb84: stur            x1, [fp, #-0x10]
    // 0x83fb88: StoreField: r1->field_f = r0
    //     0x83fb88: stur            w0, [x1, #0xf]
    // 0x83fb8c: r0 = true
    //     0x83fb8c: add             x0, NULL, #0x20  ; true
    // 0x83fb90: StoreField: r1->field_17 = r0
    //     0x83fb90: stur            w0, [x1, #0x17]
    // 0x83fb94: r2 = Instance_TextOverflow
    //     0x83fb94: add             x2, PP, #0x15, lsl #12  ; [pp+0x15118] Obj!TextOverflow@b64d71
    //     0x83fb98: ldr             x2, [x2, #0x118]
    // 0x83fb9c: StoreField: r1->field_1b = r2
    //     0x83fb9c: stur            w2, [x1, #0x1b]
    // 0x83fba0: r2 = Instance_TextWidthBasis
    //     0x83fba0: add             x2, PP, #0x15, lsl #12  ; [pp+0x15148] Obj!TextWidthBasis@b64d31
    //     0x83fba4: ldr             x2, [x2, #0x148]
    // 0x83fba8: StoreField: r1->field_23 = r2
    //     0x83fba8: stur            w2, [x1, #0x23]
    // 0x83fbac: ldur            x2, [fp, #-0x40]
    // 0x83fbb0: StoreField: r1->field_b = r2
    //     0x83fbb0: stur            w2, [x1, #0xb]
    // 0x83fbb4: r0 = Align()
    //     0x83fbb4: bl              #0x822ffc  ; AllocateAlignStub -> Align (size=0x1c)
    // 0x83fbb8: mov             x1, x0
    // 0x83fbbc: ldur            x0, [fp, #-8]
    // 0x83fbc0: stur            x1, [fp, #-0x18]
    // 0x83fbc4: StoreField: r1->field_f = r0
    //     0x83fbc4: stur            w0, [x1, #0xf]
    // 0x83fbc8: r0 = 1.000000
    //     0x83fbc8: ldr             x0, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x83fbcc: StoreField: r1->field_13 = r0
    //     0x83fbcc: stur            w0, [x1, #0x13]
    // 0x83fbd0: StoreField: r1->field_17 = r0
    //     0x83fbd0: stur            w0, [x1, #0x17]
    // 0x83fbd4: ldur            x0, [fp, #-0x10]
    // 0x83fbd8: StoreField: r1->field_b = r0
    //     0x83fbd8: stur            w0, [x1, #0xb]
    // 0x83fbdc: r0 = Padding()
    //     0x83fbdc: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x83fbe0: mov             x1, x0
    // 0x83fbe4: ldur            x0, [fp, #-0x28]
    // 0x83fbe8: stur            x1, [fp, #-8]
    // 0x83fbec: StoreField: r1->field_f = r0
    //     0x83fbec: stur            w0, [x1, #0xf]
    // 0x83fbf0: ldur            x0, [fp, #-0x18]
    // 0x83fbf4: StoreField: r1->field_b = r0
    //     0x83fbf4: stur            w0, [x1, #0xb]
    // 0x83fbf8: r0 = DecoratedBox()
    //     0x83fbf8: bl              #0x83fd18  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x83fbfc: mov             x1, x0
    // 0x83fc00: ldur            x0, [fp, #-0x68]
    // 0x83fc04: stur            x1, [fp, #-0x10]
    // 0x83fc08: StoreField: r1->field_f = r0
    //     0x83fc08: stur            w0, [x1, #0xf]
    // 0x83fc0c: r0 = Instance_DecorationPosition
    //     0x83fc0c: add             x0, PP, #0xf, lsl #12  ; [pp+0xf1b0] Obj!DecorationPosition@b648d1
    //     0x83fc10: ldr             x0, [x0, #0x1b0]
    // 0x83fc14: StoreField: r1->field_13 = r0
    //     0x83fc14: stur            w0, [x1, #0x13]
    // 0x83fc18: ldur            x0, [fp, #-8]
    // 0x83fc1c: StoreField: r1->field_b = r0
    //     0x83fc1c: stur            w0, [x1, #0xb]
    // 0x83fc20: r0 = FadeTransition()
    //     0x83fc20: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x83fc24: mov             x1, x0
    // 0x83fc28: ldur            x0, [fp, #-0x58]
    // 0x83fc2c: stur            x1, [fp, #-8]
    // 0x83fc30: StoreField: r1->field_f = r0
    //     0x83fc30: stur            w0, [x1, #0xf]
    // 0x83fc34: r0 = false
    //     0x83fc34: add             x0, NULL, #0x30  ; false
    // 0x83fc38: StoreField: r1->field_13 = r0
    //     0x83fc38: stur            w0, [x1, #0x13]
    // 0x83fc3c: ldur            x0, [fp, #-0x10]
    // 0x83fc40: StoreField: r1->field_b = r0
    //     0x83fc40: stur            w0, [x1, #0xb]
    // 0x83fc44: r0 = ConstrainedBox()
    //     0x83fc44: bl              #0x82c3e0  ; AllocateConstrainedBoxStub -> ConstrainedBox (size=0x14)
    // 0x83fc48: mov             x1, x0
    // 0x83fc4c: ldur            x0, [fp, #-0x60]
    // 0x83fc50: stur            x1, [fp, #-0x10]
    // 0x83fc54: StoreField: r1->field_f = r0
    //     0x83fc54: stur            w0, [x1, #0xf]
    // 0x83fc58: ldur            x0, [fp, #-8]
    // 0x83fc5c: StoreField: r1->field_b = r0
    //     0x83fc5c: stur            w0, [x1, #0xb]
    // 0x83fc60: r0 = Semantics()
    //     0x83fc60: bl              #0x7b43d0  ; AllocateSemanticsStub -> Semantics (size=0x20)
    // 0x83fc64: stur            x0, [fp, #-8]
    // 0x83fc68: r16 = true
    //     0x83fc68: add             x16, NULL, #0x20  ; true
    // 0x83fc6c: stp             x16, x0, [SP, #-0x10]!
    // 0x83fc70: ldur            x16, [fp, #-0x10]
    // 0x83fc74: SaveReg r16
    //     0x83fc74: str             x16, [SP, #-8]!
    // 0x83fc78: r4 = const [0, 0x3, 0x3, 0x1, button, 0x1, child, 0x2, null]
    //     0x83fc78: add             x4, PP, #0x40, lsl #12  ; [pp+0x404f8] List(9) [0, 0x3, 0x3, 0x1, "button", 0x1, "child", 0x2, Null]
    //     0x83fc7c: ldr             x4, [x4, #0x4f8]
    // 0x83fc80: r0 = Semantics()
    //     0x83fc80: bl              #0x7b3414  ; [package:flutter/src/widgets/basic.dart] Semantics::Semantics
    // 0x83fc84: add             SP, SP, #0x18
    // 0x83fc88: r0 = GestureDetector()
    //     0x83fc88: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x83fc8c: stur            x0, [fp, #-0x10]
    // 0x83fc90: r16 = Instance_HitTestBehavior
    //     0x83fc90: add             x16, PP, #0x15, lsl #12  ; [pp+0x15408] Obj!HitTestBehavior@b648f1
    //     0x83fc94: ldr             x16, [x16, #0x408]
    // 0x83fc98: stp             x16, x0, [SP, #-0x10]!
    // 0x83fc9c: ldur            x16, [fp, #-0x20]
    // 0x83fca0: ldur            lr, [fp, #-0x30]
    // 0x83fca4: stp             lr, x16, [SP, #-0x10]!
    // 0x83fca8: ldur            x16, [fp, #-0x48]
    // 0x83fcac: ldur            lr, [fp, #-0x38]
    // 0x83fcb0: stp             lr, x16, [SP, #-0x10]!
    // 0x83fcb4: ldur            x16, [fp, #-8]
    // 0x83fcb8: SaveReg r16
    //     0x83fcb8: str             x16, [SP, #-8]!
    // 0x83fcbc: r4 = const [0, 0x7, 0x7, 0x1, behavior, 0x1, child, 0x6, onTap, 0x5, onTapCancel, 0x4, onTapDown, 0x2, onTapUp, 0x3, null]
    //     0x83fcbc: add             x4, PP, #0x40, lsl #12  ; [pp+0x40500] List(17) [0, 0x7, 0x7, 0x1, "behavior", 0x1, "child", 0x6, "onTap", 0x5, "onTapCancel", 0x4, "onTapDown", 0x2, "onTapUp", 0x3, Null]
    //     0x83fcc0: ldr             x4, [x4, #0x500]
    // 0x83fcc4: r0 = GestureDetector()
    //     0x83fcc4: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x83fcc8: add             SP, SP, #0x38
    // 0x83fccc: r0 = MouseRegion()
    //     0x83fccc: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0x83fcd0: r1 = Instance__DeferringMouseCursor
    //     0x83fcd0: ldr             x1, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x83fcd4: StoreField: r0->field_1b = r1
    //     0x83fcd4: stur            w1, [x0, #0x1b]
    // 0x83fcd8: r1 = true
    //     0x83fcd8: add             x1, NULL, #0x20  ; true
    // 0x83fcdc: StoreField: r0->field_1f = r1
    //     0x83fcdc: stur            w1, [x0, #0x1f]
    // 0x83fce0: ldur            x1, [fp, #-0x10]
    // 0x83fce4: StoreField: r0->field_b = r1
    //     0x83fce4: stur            w1, [x0, #0xb]
    // 0x83fce8: LeaveFrame
    //     0x83fce8: mov             SP, fp
    //     0x83fcec: ldp             fp, lr, [SP], #0x10
    // 0x83fcf0: ret
    //     0x83fcf0: ret             
    // 0x83fcf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83fcf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83fcf8: b               #0x83f748
    // 0x83fcfc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83fcfc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83fd00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83fd00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83fd04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83fd04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83fd08: r9 = _opacityAnimation
    //     0x83fd08: add             x9, PP, #0x40, lsl #12  ; [pp+0x40508] Field <_CupertinoButtonState@585145554._opacityAnimation@585145554>: late (offset: 0x24)
    //     0x83fd0c: ldr             x9, [x9, #0x508]
    // 0x83fd10: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83fd10: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x83fd14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83fd14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleTapCancel(dynamic) {
    // ** addr: 0x83ff60, size: 0x48
    // 0x83ff60: EnterFrame
    //     0x83ff60: stp             fp, lr, [SP, #-0x10]!
    //     0x83ff64: mov             fp, SP
    // 0x83ff68: ldr             x0, [fp, #0x10]
    // 0x83ff6c: LoadField: r1 = r0->field_17
    //     0x83ff6c: ldur            w1, [x0, #0x17]
    // 0x83ff70: DecompressPointer r1
    //     0x83ff70: add             x1, x1, HEAP, lsl #32
    // 0x83ff74: CheckStackOverflow
    //     0x83ff74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83ff78: cmp             SP, x16
    //     0x83ff7c: b.ls            #0x83ffa0
    // 0x83ff80: LoadField: r0 = r1->field_f
    //     0x83ff80: ldur            w0, [x1, #0xf]
    // 0x83ff84: DecompressPointer r0
    //     0x83ff84: add             x0, x0, HEAP, lsl #32
    // 0x83ff88: SaveReg r0
    //     0x83ff88: str             x0, [SP, #-8]!
    // 0x83ff8c: r0 = _handleTapCancel()
    //     0x83ff8c: bl              #0x83ffa8  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapCancel
    // 0x83ff90: add             SP, SP, #8
    // 0x83ff94: LeaveFrame
    //     0x83ff94: mov             SP, fp
    //     0x83ff98: ldp             fp, lr, [SP], #0x10
    // 0x83ff9c: ret
    //     0x83ff9c: ret             
    // 0x83ffa0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ffa0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83ffa4: b               #0x83ff80
  }
  _ _handleTapCancel(/* No info */) {
    // ** addr: 0x83ffa8, size: 0x50
    // 0x83ffa8: EnterFrame
    //     0x83ffa8: stp             fp, lr, [SP, #-0x10]!
    //     0x83ffac: mov             fp, SP
    // 0x83ffb0: CheckStackOverflow
    //     0x83ffb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83ffb4: cmp             SP, x16
    //     0x83ffb8: b.ls            #0x83fff0
    // 0x83ffbc: ldr             x0, [fp, #0x10]
    // 0x83ffc0: LoadField: r1 = r0->field_27
    //     0x83ffc0: ldur            w1, [x0, #0x27]
    // 0x83ffc4: DecompressPointer r1
    //     0x83ffc4: add             x1, x1, HEAP, lsl #32
    // 0x83ffc8: tbnz            w1, #4, #0x83ffe0
    // 0x83ffcc: r1 = false
    //     0x83ffcc: add             x1, NULL, #0x30  ; false
    // 0x83ffd0: StoreField: r0->field_27 = r1
    //     0x83ffd0: stur            w1, [x0, #0x27]
    // 0x83ffd4: SaveReg r0
    //     0x83ffd4: str             x0, [SP, #-8]!
    // 0x83ffd8: r0 = _animate()
    //     0x83ffd8: bl              #0x83fff8  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0x83ffdc: add             SP, SP, #8
    // 0x83ffe0: r0 = Null
    //     0x83ffe0: mov             x0, NULL
    // 0x83ffe4: LeaveFrame
    //     0x83ffe4: mov             SP, fp
    //     0x83ffe8: ldp             fp, lr, [SP], #0x10
    // 0x83ffec: ret
    //     0x83ffec: ret             
    // 0x83fff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83fff0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83fff4: b               #0x83ffbc
  }
  _ _animate(/* No info */) {
    // ** addr: 0x83fff8, size: 0x134
    // 0x83fff8: EnterFrame
    //     0x83fff8: stp             fp, lr, [SP, #-0x10]!
    //     0x83fffc: mov             fp, SP
    // 0x840000: AllocStack(0x10)
    //     0x840000: sub             SP, SP, #0x10
    // 0x840004: CheckStackOverflow
    //     0x840004: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840008: cmp             SP, x16
    //     0x84000c: b.ls            #0x840118
    // 0x840010: r1 = 2
    //     0x840010: mov             x1, #2
    // 0x840014: r0 = AllocateContext()
    //     0x840014: bl              #0xd68aa4  ; AllocateContextStub
    // 0x840018: mov             x1, x0
    // 0x84001c: ldr             x0, [fp, #0x10]
    // 0x840020: stur            x1, [fp, #-8]
    // 0x840024: StoreField: r1->field_f = r0
    //     0x840024: stur            w0, [x1, #0xf]
    // 0x840028: LoadField: r2 = r0->field_1f
    //     0x840028: ldur            w2, [x0, #0x1f]
    // 0x84002c: DecompressPointer r2
    //     0x84002c: add             x2, x2, HEAP, lsl #32
    // 0x840030: r16 = Sentinel
    //     0x840030: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x840034: cmp             w2, w16
    // 0x840038: b.eq            #0x840120
    // 0x84003c: LoadField: r3 = r2->field_2f
    //     0x84003c: ldur            w3, [x2, #0x2f]
    // 0x840040: DecompressPointer r3
    //     0x840040: add             x3, x3, HEAP, lsl #32
    // 0x840044: cmp             w3, NULL
    // 0x840048: b.eq            #0x84006c
    // 0x84004c: LoadField: r4 = r3->field_7
    //     0x84004c: ldur            w4, [x3, #7]
    // 0x840050: DecompressPointer r4
    //     0x840050: add             x4, x4, HEAP, lsl #32
    // 0x840054: cmp             w4, NULL
    // 0x840058: b.eq            #0x84006c
    // 0x84005c: r0 = Null
    //     0x84005c: mov             x0, NULL
    // 0x840060: LeaveFrame
    //     0x840060: mov             SP, fp
    //     0x840064: ldp             fp, lr, [SP], #0x10
    // 0x840068: ret
    //     0x840068: ret             
    // 0x84006c: LoadField: r3 = r0->field_27
    //     0x84006c: ldur            w3, [x0, #0x27]
    // 0x840070: DecompressPointer r3
    //     0x840070: add             x3, x3, HEAP, lsl #32
    // 0x840074: StoreField: r1->field_13 = r3
    //     0x840074: stur            w3, [x1, #0x13]
    // 0x840078: tbnz            w3, #4, #0x8400b0
    // 0x84007c: d0 = 1.000000
    //     0x84007c: fmov            d0, #1.00000000
    // 0x840080: SaveReg r2
    //     0x840080: str             x2, [SP, #-8]!
    // 0x840084: SaveReg d0
    //     0x840084: str             d0, [SP, #-8]!
    // 0x840088: r16 = Instance_Duration
    //     0x840088: add             x16, PP, #0x40, lsl #12  ; [pp+0x40510] Obj!Duration@b67b81
    //     0x84008c: ldr             x16, [x16, #0x510]
    // 0x840090: r30 = Instance_ThreePointCubic
    //     0x840090: add             lr, PP, #0x40, lsl #12  ; [pp+0x40518] Obj!ThreePointCubic<double>@b4f2f1
    //     0x840094: ldr             lr, [lr, #0x518]
    // 0x840098: stp             lr, x16, [SP, #-0x10]!
    // 0x84009c: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x84009c: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x8400a0: ldr             x4, [x4, #0x2a0]
    // 0x8400a4: r0 = animateTo()
    //     0x8400a4: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x8400a8: add             SP, SP, #0x20
    // 0x8400ac: b               #0x8400d8
    // 0x8400b0: stp             xzr, x2, [SP, #-0x10]!
    // 0x8400b4: r16 = Instance_Duration
    //     0x8400b4: add             x16, PP, #0x40, lsl #12  ; [pp+0x40520] Obj!Duration@b67b71
    //     0x8400b8: ldr             x16, [x16, #0x520]
    // 0x8400bc: r30 = Instance_Cubic
    //     0x8400bc: add             lr, PP, #0x40, lsl #12  ; [pp+0x40528] Obj!Cubic<double>@b4f461
    //     0x8400c0: ldr             lr, [lr, #0x528]
    // 0x8400c4: stp             lr, x16, [SP, #-0x10]!
    // 0x8400c8: r4 = const [0, 0x4, 0x4, 0x2, curve, 0x3, duration, 0x2, null]
    //     0x8400c8: add             x4, PP, #0x27, lsl #12  ; [pp+0x272a0] List(9) [0, 0x4, 0x4, 0x2, "curve", 0x3, "duration", 0x2, Null]
    //     0x8400cc: ldr             x4, [x4, #0x2a0]
    // 0x8400d0: r0 = animateTo()
    //     0x8400d0: bl              #0x7a8100  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::animateTo
    // 0x8400d4: add             SP, SP, #0x20
    // 0x8400d8: ldur            x2, [fp, #-8]
    // 0x8400dc: stur            x0, [fp, #-0x10]
    // 0x8400e0: r1 = Function '<anonymous closure>':.
    //     0x8400e0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40530] AnonymousClosure: (0x84012c), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate (0x83fff8)
    //     0x8400e4: ldr             x1, [x1, #0x530]
    // 0x8400e8: r0 = AllocateClosure()
    //     0x8400e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8400ec: r16 = <void?>
    //     0x8400ec: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x8400f0: ldur            lr, [fp, #-0x10]
    // 0x8400f4: stp             lr, x16, [SP, #-0x10]!
    // 0x8400f8: SaveReg r0
    //     0x8400f8: str             x0, [SP, #-8]!
    // 0x8400fc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x8400fc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x840100: r0 = then()
    //     0x840100: bl              #0xd0444c  ; [package:flutter/src/scheduler/ticker.dart] TickerFuture::then
    // 0x840104: add             SP, SP, #0x18
    // 0x840108: r0 = Null
    //     0x840108: mov             x0, NULL
    // 0x84010c: LeaveFrame
    //     0x84010c: mov             SP, fp
    //     0x840110: ldp             fp, lr, [SP], #0x10
    // 0x840114: ret
    //     0x840114: ret             
    // 0x840118: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840118: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84011c: b               #0x840010
    // 0x840120: r9 = _animationController
    //     0x840120: add             x9, PP, #0x40, lsl #12  ; [pp+0x40538] Field <_CupertinoButtonState@585145554._animationController@585145554>: late (offset: 0x20)
    //     0x840124: ldr             x9, [x9, #0x538]
    // 0x840128: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x840128: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Null <anonymous closure>(dynamic, void) {
    // ** addr: 0x84012c, size: 0x74
    // 0x84012c: EnterFrame
    //     0x84012c: stp             fp, lr, [SP, #-0x10]!
    //     0x840130: mov             fp, SP
    // 0x840134: ldr             x0, [fp, #0x18]
    // 0x840138: LoadField: r1 = r0->field_17
    //     0x840138: ldur            w1, [x0, #0x17]
    // 0x84013c: DecompressPointer r1
    //     0x84013c: add             x1, x1, HEAP, lsl #32
    // 0x840140: CheckStackOverflow
    //     0x840140: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840144: cmp             SP, x16
    //     0x840148: b.ls            #0x840198
    // 0x84014c: LoadField: r0 = r1->field_f
    //     0x84014c: ldur            w0, [x1, #0xf]
    // 0x840150: DecompressPointer r0
    //     0x840150: add             x0, x0, HEAP, lsl #32
    // 0x840154: LoadField: r2 = r0->field_f
    //     0x840154: ldur            w2, [x0, #0xf]
    // 0x840158: DecompressPointer r2
    //     0x840158: add             x2, x2, HEAP, lsl #32
    // 0x84015c: cmp             w2, NULL
    // 0x840160: b.eq            #0x840188
    // 0x840164: LoadField: r2 = r1->field_13
    //     0x840164: ldur            w2, [x1, #0x13]
    // 0x840168: DecompressPointer r2
    //     0x840168: add             x2, x2, HEAP, lsl #32
    // 0x84016c: LoadField: r1 = r0->field_27
    //     0x84016c: ldur            w1, [x0, #0x27]
    // 0x840170: DecompressPointer r1
    //     0x840170: add             x1, x1, HEAP, lsl #32
    // 0x840174: cmp             w2, w1
    // 0x840178: b.eq            #0x840188
    // 0x84017c: SaveReg r0
    //     0x84017c: str             x0, [SP, #-8]!
    // 0x840180: r0 = _animate()
    //     0x840180: bl              #0x83fff8  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0x840184: add             SP, SP, #8
    // 0x840188: r0 = Null
    //     0x840188: mov             x0, NULL
    // 0x84018c: LeaveFrame
    //     0x84018c: mov             SP, fp
    //     0x840190: ldp             fp, lr, [SP], #0x10
    // 0x840194: ret
    //     0x840194: ret             
    // 0x840198: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840198: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84019c: b               #0x84014c
  }
  [closure] void _handleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0x8401a0, size: 0x4c
    // 0x8401a0: EnterFrame
    //     0x8401a0: stp             fp, lr, [SP, #-0x10]!
    //     0x8401a4: mov             fp, SP
    // 0x8401a8: ldr             x0, [fp, #0x18]
    // 0x8401ac: LoadField: r1 = r0->field_17
    //     0x8401ac: ldur            w1, [x0, #0x17]
    // 0x8401b0: DecompressPointer r1
    //     0x8401b0: add             x1, x1, HEAP, lsl #32
    // 0x8401b4: CheckStackOverflow
    //     0x8401b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8401b8: cmp             SP, x16
    //     0x8401bc: b.ls            #0x8401e4
    // 0x8401c0: LoadField: r0 = r1->field_f
    //     0x8401c0: ldur            w0, [x1, #0xf]
    // 0x8401c4: DecompressPointer r0
    //     0x8401c4: add             x0, x0, HEAP, lsl #32
    // 0x8401c8: ldr             x16, [fp, #0x10]
    // 0x8401cc: stp             x16, x0, [SP, #-0x10]!
    // 0x8401d0: r0 = _handleTapUp()
    //     0x8401d0: bl              #0x8401ec  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapUp
    // 0x8401d4: add             SP, SP, #0x10
    // 0x8401d8: LeaveFrame
    //     0x8401d8: mov             SP, fp
    //     0x8401dc: ldp             fp, lr, [SP], #0x10
    // 0x8401e0: ret
    //     0x8401e0: ret             
    // 0x8401e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8401e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8401e8: b               #0x8401c0
  }
  _ _handleTapUp(/* No info */) {
    // ** addr: 0x8401ec, size: 0x50
    // 0x8401ec: EnterFrame
    //     0x8401ec: stp             fp, lr, [SP, #-0x10]!
    //     0x8401f0: mov             fp, SP
    // 0x8401f4: CheckStackOverflow
    //     0x8401f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8401f8: cmp             SP, x16
    //     0x8401fc: b.ls            #0x840234
    // 0x840200: ldr             x0, [fp, #0x18]
    // 0x840204: LoadField: r1 = r0->field_27
    //     0x840204: ldur            w1, [x0, #0x27]
    // 0x840208: DecompressPointer r1
    //     0x840208: add             x1, x1, HEAP, lsl #32
    // 0x84020c: tbnz            w1, #4, #0x840224
    // 0x840210: r1 = false
    //     0x840210: add             x1, NULL, #0x30  ; false
    // 0x840214: StoreField: r0->field_27 = r1
    //     0x840214: stur            w1, [x0, #0x27]
    // 0x840218: SaveReg r0
    //     0x840218: str             x0, [SP, #-8]!
    // 0x84021c: r0 = _animate()
    //     0x84021c: bl              #0x83fff8  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0x840220: add             SP, SP, #8
    // 0x840224: r0 = Null
    //     0x840224: mov             x0, NULL
    // 0x840228: LeaveFrame
    //     0x840228: mov             SP, fp
    //     0x84022c: ldp             fp, lr, [SP], #0x10
    // 0x840230: ret
    //     0x840230: ret             
    // 0x840234: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840234: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840238: b               #0x840200
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x84023c, size: 0x4c
    // 0x84023c: EnterFrame
    //     0x84023c: stp             fp, lr, [SP, #-0x10]!
    //     0x840240: mov             fp, SP
    // 0x840244: ldr             x0, [fp, #0x18]
    // 0x840248: LoadField: r1 = r0->field_17
    //     0x840248: ldur            w1, [x0, #0x17]
    // 0x84024c: DecompressPointer r1
    //     0x84024c: add             x1, x1, HEAP, lsl #32
    // 0x840250: CheckStackOverflow
    //     0x840250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840254: cmp             SP, x16
    //     0x840258: b.ls            #0x840280
    // 0x84025c: LoadField: r0 = r1->field_f
    //     0x84025c: ldur            w0, [x1, #0xf]
    // 0x840260: DecompressPointer r0
    //     0x840260: add             x0, x0, HEAP, lsl #32
    // 0x840264: ldr             x16, [fp, #0x10]
    // 0x840268: stp             x16, x0, [SP, #-0x10]!
    // 0x84026c: r0 = _handleTapDown()
    //     0x84026c: bl              #0x840288  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_handleTapDown
    // 0x840270: add             SP, SP, #0x10
    // 0x840274: LeaveFrame
    //     0x840274: mov             SP, fp
    //     0x840278: ldp             fp, lr, [SP], #0x10
    // 0x84027c: ret
    //     0x84027c: ret             
    // 0x840280: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840280: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840284: b               #0x84025c
  }
  _ _handleTapDown(/* No info */) {
    // ** addr: 0x840288, size: 0x50
    // 0x840288: EnterFrame
    //     0x840288: stp             fp, lr, [SP, #-0x10]!
    //     0x84028c: mov             fp, SP
    // 0x840290: CheckStackOverflow
    //     0x840290: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840294: cmp             SP, x16
    //     0x840298: b.ls            #0x8402d0
    // 0x84029c: ldr             x0, [fp, #0x18]
    // 0x8402a0: LoadField: r1 = r0->field_27
    //     0x8402a0: ldur            w1, [x0, #0x27]
    // 0x8402a4: DecompressPointer r1
    //     0x8402a4: add             x1, x1, HEAP, lsl #32
    // 0x8402a8: tbz             w1, #4, #0x8402c0
    // 0x8402ac: r1 = true
    //     0x8402ac: add             x1, NULL, #0x20  ; true
    // 0x8402b0: StoreField: r0->field_27 = r1
    //     0x8402b0: stur            w1, [x0, #0x27]
    // 0x8402b4: SaveReg r0
    //     0x8402b4: str             x0, [SP, #-8]!
    // 0x8402b8: r0 = _animate()
    //     0x8402b8: bl              #0x83fff8  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_animate
    // 0x8402bc: add             SP, SP, #8
    // 0x8402c0: r0 = Null
    //     0x8402c0: mov             x0, NULL
    // 0x8402c4: LeaveFrame
    //     0x8402c4: mov             SP, fp
    //     0x8402c8: ldp             fp, lr, [SP], #0x10
    // 0x8402cc: ret
    //     0x8402cc: ret             
    // 0x8402d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8402d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8402d4: b               #0x84029c
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d753c, size: 0x128
    // 0x9d753c: EnterFrame
    //     0x9d753c: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7540: mov             fp, SP
    // 0x9d7544: AllocStack(0x10)
    //     0x9d7544: sub             SP, SP, #0x10
    // 0x9d7548: CheckStackOverflow
    //     0x9d7548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d754c: cmp             SP, x16
    //     0x9d7550: b.ls            #0x9d765c
    // 0x9d7554: r1 = <double>
    //     0x9d7554: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d7558: r0 = AnimationController()
    //     0x9d7558: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d755c: stur            x0, [fp, #-8]
    // 0x9d7560: ldr             x16, [fp, #0x10]
    // 0x9d7564: stp             x16, x0, [SP, #-0x10]!
    // 0x9d7568: r16 = Instance_Duration
    //     0x9d7568: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d756c: ldr             x16, [x16, #0x9e0]
    // 0x9d7570: r30 = 0.000000
    //     0x9d7570: ldr             lr, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x9d7574: stp             lr, x16, [SP, #-0x10]!
    // 0x9d7578: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, value, 0x3, null]
    //     0x9d7578: add             x4, PP, #0x40, lsl #12  ; [pp+0x40158] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "value", 0x3, Null]
    //     0x9d757c: ldr             x4, [x4, #0x158]
    // 0x9d7580: r0 = AnimationController()
    //     0x9d7580: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d7584: add             SP, SP, #0x20
    // 0x9d7588: ldur            x0, [fp, #-8]
    // 0x9d758c: ldr             x2, [fp, #0x10]
    // 0x9d7590: StoreField: r2->field_1f = r0
    //     0x9d7590: stur            w0, [x2, #0x1f]
    //     0x9d7594: ldurb           w16, [x2, #-1]
    //     0x9d7598: ldurb           w17, [x0, #-1]
    //     0x9d759c: and             x16, x17, x16, lsr #2
    //     0x9d75a0: tst             x16, HEAP, lsr #32
    //     0x9d75a4: b.eq            #0x9d75ac
    //     0x9d75a8: bl              #0xd6828c
    // 0x9d75ac: r1 = <double>
    //     0x9d75ac: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d75b0: r0 = CurveTween()
    //     0x9d75b0: bl              #0x7b7c84  ; AllocateCurveTweenStub -> CurveTween (size=0x10)
    // 0x9d75b4: mov             x1, x0
    // 0x9d75b8: r0 = Instance__DecelerateCurve
    //     0x9d75b8: add             x0, PP, #0x28, lsl #12  ; [pp+0x28c60] Obj!_DecelerateCurve<double>@b4f2e1
    //     0x9d75bc: ldr             x0, [x0, #0xc60]
    // 0x9d75c0: StoreField: r1->field_b = r0
    //     0x9d75c0: stur            w0, [x1, #0xb]
    // 0x9d75c4: ldur            x16, [fp, #-8]
    // 0x9d75c8: stp             x16, x1, [SP, #-0x10]!
    // 0x9d75cc: r0 = animate()
    //     0x9d75cc: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d75d0: add             SP, SP, #0x10
    // 0x9d75d4: mov             x4, x0
    // 0x9d75d8: ldr             x3, [fp, #0x10]
    // 0x9d75dc: stur            x4, [fp, #-0x10]
    // 0x9d75e0: LoadField: r5 = r3->field_1b
    //     0x9d75e0: ldur            w5, [x3, #0x1b]
    // 0x9d75e4: DecompressPointer r5
    //     0x9d75e4: add             x5, x5, HEAP, lsl #32
    // 0x9d75e8: mov             x0, x4
    // 0x9d75ec: stur            x5, [fp, #-8]
    // 0x9d75f0: r2 = Null
    //     0x9d75f0: mov             x2, NULL
    // 0x9d75f4: r1 = Null
    //     0x9d75f4: mov             x1, NULL
    // 0x9d75f8: r8 = Animation<double>
    //     0x9d75f8: add             x8, PP, #0x2a, lsl #12  ; [pp+0x2aab0] Type: Animation<double>
    //     0x9d75fc: ldr             x8, [x8, #0xab0]
    // 0x9d7600: r3 = Null
    //     0x9d7600: add             x3, PP, #0x40, lsl #12  ; [pp+0x40590] Null
    //     0x9d7604: ldr             x3, [x3, #0x590]
    // 0x9d7608: r0 = Animation<double>()
    //     0x9d7608: bl              #0x5912f0  ; IsType_Animation<double>_Stub
    // 0x9d760c: ldur            x16, [fp, #-8]
    // 0x9d7610: ldur            lr, [fp, #-0x10]
    // 0x9d7614: stp             lr, x16, [SP, #-0x10]!
    // 0x9d7618: r0 = animate()
    //     0x9d7618: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x9d761c: add             SP, SP, #0x10
    // 0x9d7620: ldr             x1, [fp, #0x10]
    // 0x9d7624: StoreField: r1->field_23 = r0
    //     0x9d7624: stur            w0, [x1, #0x23]
    //     0x9d7628: ldurb           w16, [x1, #-1]
    //     0x9d762c: ldurb           w17, [x0, #-1]
    //     0x9d7630: and             x16, x17, x16, lsr #2
    //     0x9d7634: tst             x16, HEAP, lsr #32
    //     0x9d7638: b.eq            #0x9d7640
    //     0x9d763c: bl              #0xd6826c
    // 0x9d7640: SaveReg r1
    //     0x9d7640: str             x1, [SP, #-8]!
    // 0x9d7644: r0 = _setTween()
    //     0x9d7644: bl              #0x7aedb0  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::_setTween
    // 0x9d7648: add             SP, SP, #8
    // 0x9d764c: r0 = Null
    //     0x9d764c: mov             x0, NULL
    // 0x9d7650: LeaveFrame
    //     0x9d7650: mov             SP, fp
    //     0x9d7654: ldp             fp, lr, [SP], #0x10
    // 0x9d7658: ret
    //     0x9d7658: ret             
    // 0x9d765c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d765c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7660: b               #0x9d7554
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a5e8, size: 0x18
    // 0xa4a5e8: r4 = 7
    //     0xa4a5e8: mov             x4, #7
    // 0xa4a5ec: r1 = Function 'dispose':.
    //     0xa4a5ec: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bb60] AnonymousClosure: (0xa4a600), in [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::dispose (0xa50334)
    //     0xa4a5f0: ldr             x1, [x17, #0xb60]
    // 0xa4a5f4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a5f4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a5f8: LoadField: r0 = r24->field_17
    //     0xa4a5f8: ldur            x0, [x24, #0x17]
    // 0xa4a5fc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a600, size: 0x48
    // 0xa4a600: EnterFrame
    //     0xa4a600: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a604: mov             fp, SP
    // 0xa4a608: ldr             x0, [fp, #0x10]
    // 0xa4a60c: LoadField: r1 = r0->field_17
    //     0xa4a60c: ldur            w1, [x0, #0x17]
    // 0xa4a610: DecompressPointer r1
    //     0xa4a610: add             x1, x1, HEAP, lsl #32
    // 0xa4a614: CheckStackOverflow
    //     0xa4a614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a618: cmp             SP, x16
    //     0xa4a61c: b.ls            #0xa4a640
    // 0xa4a620: LoadField: r0 = r1->field_f
    //     0xa4a620: ldur            w0, [x1, #0xf]
    // 0xa4a624: DecompressPointer r0
    //     0xa4a624: add             x0, x0, HEAP, lsl #32
    // 0xa4a628: SaveReg r0
    //     0xa4a628: str             x0, [SP, #-8]!
    // 0xa4a62c: r0 = dispose()
    //     0xa4a62c: bl              #0xa50334  ; [package:flutter/src/cupertino/button.dart] _CupertinoButtonState::dispose
    // 0xa4a630: add             SP, SP, #8
    // 0xa4a634: LeaveFrame
    //     0xa4a634: mov             SP, fp
    //     0xa4a638: ldp             fp, lr, [SP], #0x10
    // 0xa4a63c: ret
    //     0xa4a63c: ret             
    // 0xa4a640: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a640: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a644: b               #0xa4a620
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50334, size: 0x6c
    // 0xa50334: EnterFrame
    //     0xa50334: stp             fp, lr, [SP, #-0x10]!
    //     0xa50338: mov             fp, SP
    // 0xa5033c: CheckStackOverflow
    //     0xa5033c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50340: cmp             SP, x16
    //     0xa50344: b.ls            #0xa5038c
    // 0xa50348: ldr             x0, [fp, #0x10]
    // 0xa5034c: LoadField: r1 = r0->field_1f
    //     0xa5034c: ldur            w1, [x0, #0x1f]
    // 0xa50350: DecompressPointer r1
    //     0xa50350: add             x1, x1, HEAP, lsl #32
    // 0xa50354: r16 = Sentinel
    //     0xa50354: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa50358: cmp             w1, w16
    // 0xa5035c: b.eq            #0xa50394
    // 0xa50360: SaveReg r1
    //     0xa50360: str             x1, [SP, #-8]!
    // 0xa50364: r0 = dispose()
    //     0xa50364: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa50368: add             SP, SP, #8
    // 0xa5036c: ldr             x16, [fp, #0x10]
    // 0xa50370: SaveReg r16
    //     0xa50370: str             x16, [SP, #-8]!
    // 0xa50374: r0 = dispose()
    //     0xa50374: bl              #0xa503a0  ; [package:flutter/src/cupertino/button.dart] __CupertinoButtonState&State&SingleTickerProviderStateMixin::dispose
    // 0xa50378: add             SP, SP, #8
    // 0xa5037c: r0 = Null
    //     0xa5037c: mov             x0, NULL
    // 0xa50380: LeaveFrame
    //     0xa50380: mov             SP, fp
    //     0xa50384: ldp             fp, lr, [SP], #0x10
    // 0xa50388: ret
    //     0xa50388: ret             
    // 0xa5038c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5038c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50390: b               #0xa50348
    // 0xa50394: r9 = _animationController
    //     0xa50394: add             x9, PP, #0x40, lsl #12  ; [pp+0x40538] Field <_CupertinoButtonState@585145554._animationController@585145554>: late (offset: 0x20)
    //     0xa50398: ldr             x9, [x9, #0x538]
    // 0xa5039c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5039c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4183, size: 0x3c, field offset: 0xc
//   const constructor, 
class CupertinoButton extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fce0, size: 0x5c
    // 0xa3fce0: EnterFrame
    //     0xa3fce0: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fce4: mov             fp, SP
    // 0xa3fce8: AllocStack(0x8)
    //     0xa3fce8: sub             SP, SP, #8
    // 0xa3fcec: r1 = <CupertinoButton>
    //     0xa3fcec: add             x1, PP, #0x37, lsl #12  ; [pp+0x37d18] TypeArguments: <CupertinoButton>
    //     0xa3fcf0: ldr             x1, [x1, #0xd18]
    // 0xa3fcf4: r0 = _CupertinoButtonState()
    //     0xa3fcf4: bl              #0xa3fd3c  ; Allocate_CupertinoButtonStateStub -> _CupertinoButtonState (size=0x2c)
    // 0xa3fcf8: mov             x2, x0
    // 0xa3fcfc: r0 = Sentinel
    //     0xa3fcfc: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fd00: stur            x2, [fp, #-8]
    // 0xa3fd04: StoreField: r2->field_1f = r0
    //     0xa3fd04: stur            w0, [x2, #0x1f]
    // 0xa3fd08: StoreField: r2->field_23 = r0
    //     0xa3fd08: stur            w0, [x2, #0x23]
    // 0xa3fd0c: r0 = false
    //     0xa3fd0c: add             x0, NULL, #0x30  ; false
    // 0xa3fd10: StoreField: r2->field_27 = r0
    //     0xa3fd10: stur            w0, [x2, #0x27]
    // 0xa3fd14: r1 = <double>
    //     0xa3fd14: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xa3fd18: r0 = Tween()
    //     0xa3fd18: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0xa3fd1c: r1 = 1.000000
    //     0xa3fd1c: ldr             x1, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0xa3fd20: StoreField: r0->field_b = r1
    //     0xa3fd20: stur            w1, [x0, #0xb]
    // 0xa3fd24: ldur            x1, [fp, #-8]
    // 0xa3fd28: StoreField: r1->field_1b = r0
    //     0xa3fd28: stur            w0, [x1, #0x1b]
    // 0xa3fd2c: mov             x0, x1
    // 0xa3fd30: LeaveFrame
    //     0xa3fd30: mov             SP, fp
    //     0xa3fd34: ldp             fp, lr, [SP], #0x10
    // 0xa3fd38: ret
    //     0xa3fd38: ret             
  }
}

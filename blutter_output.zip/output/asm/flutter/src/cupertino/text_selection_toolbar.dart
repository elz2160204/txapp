// lib: , url: package:flutter/src/cupertino/text_selection_toolbar.dart

// class id: 1049113, size: 0x8
class :: {
}

// class id: 2451, size: 0x70, field offset: 0x70
//   transformed mixin,
abstract class __RenderCupertinoTextSelectionToolbarItems&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin extends __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin
     with RenderBoxContainerDefaultsMixin<X0 bound RenderBox, X1 bound ContainerBoxParentData<X0 bound RenderBox>> {
}

// class id: 2452, size: 0x90, field offset: 0x70
class _RenderCupertinoTextSelectionToolbarItems extends __RenderCupertinoTextSelectionToolbarItems&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x627a44, size: 0x1fc
    // 0x627a44: EnterFrame
    //     0x627a44: stp             fp, lr, [SP, #-0x10]!
    //     0x627a48: mov             fp, SP
    // 0x627a4c: AllocStack(0x18)
    //     0x627a4c: sub             SP, SP, #0x18
    // 0x627a50: CheckStackOverflow
    //     0x627a50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627a54: cmp             SP, x16
    //     0x627a58: b.ls            #0x627c2c
    // 0x627a5c: ldr             x3, [fp, #0x20]
    // 0x627a60: LoadField: r0 = r3->field_6b
    //     0x627a60: ldur            w0, [x3, #0x6b]
    // 0x627a64: DecompressPointer r0
    //     0x627a64: add             x0, x0, HEAP, lsl #32
    // 0x627a68: mov             x4, x0
    // 0x627a6c: stur            x4, [fp, #-0x10]
    // 0x627a70: CheckStackOverflow
    //     0x627a70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627a74: cmp             SP, x16
    //     0x627a78: b.ls            #0x627c34
    // 0x627a7c: cmp             w4, NULL
    // 0x627a80: b.eq            #0x627b74
    // 0x627a84: LoadField: r5 = r4->field_17
    //     0x627a84: ldur            w5, [x4, #0x17]
    // 0x627a88: DecompressPointer r5
    //     0x627a88: add             x5, x5, HEAP, lsl #32
    // 0x627a8c: stur            x5, [fp, #-8]
    // 0x627a90: cmp             w5, NULL
    // 0x627a94: b.eq            #0x627c3c
    // 0x627a98: mov             x0, x5
    // 0x627a9c: r2 = Null
    //     0x627a9c: mov             x2, NULL
    // 0x627aa0: r1 = Null
    //     0x627aa0: mov             x1, NULL
    // 0x627aa4: r4 = LoadClassIdInstr(r0)
    //     0x627aa4: ldur            x4, [x0, #-1]
    //     0x627aa8: ubfx            x4, x4, #0xc, #0x14
    // 0x627aac: cmp             x4, #0x804
    // 0x627ab0: b.eq            #0x627ac8
    // 0x627ab4: r8 = ToolbarItemsParentData<RenderBox>
    //     0x627ab4: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x627ab8: ldr             x8, [x8, #0x528]
    // 0x627abc: r3 = Null
    //     0x627abc: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f40] Null
    //     0x627ac0: ldr             x3, [x3, #0xf40]
    // 0x627ac4: r0 = DefaultTypeTest()
    //     0x627ac4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x627ac8: ldur            x0, [fp, #-8]
    // 0x627acc: LoadField: r1 = r0->field_17
    //     0x627acc: ldur            w1, [x0, #0x17]
    // 0x627ad0: DecompressPointer r1
    //     0x627ad0: add             x1, x1, HEAP, lsl #32
    // 0x627ad4: stur            x1, [fp, #-0x18]
    // 0x627ad8: tbz             w1, #4, #0x627aec
    // 0x627adc: LoadField: r1 = r0->field_f
    //     0x627adc: ldur            w1, [x0, #0xf]
    // 0x627ae0: DecompressPointer r1
    //     0x627ae0: add             x1, x1, HEAP, lsl #32
    // 0x627ae4: mov             x4, x1
    // 0x627ae8: b               #0x627b6c
    // 0x627aec: ldur            x2, [fp, #-0x10]
    // 0x627af0: r1 = 1
    //     0x627af0: mov             x1, #1
    // 0x627af4: r0 = AllocateContext()
    //     0x627af4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x627af8: mov             x1, x0
    // 0x627afc: ldur            x0, [fp, #-0x10]
    // 0x627b00: StoreField: r1->field_f = r0
    //     0x627b00: stur            w0, [x1, #0xf]
    // 0x627b04: ldur            x0, [fp, #-0x18]
    // 0x627b08: tbnz            w0, #4, #0x627b5c
    // 0x627b0c: ldur            x0, [fp, #-8]
    // 0x627b10: LoadField: r3 = r0->field_7
    //     0x627b10: ldur            w3, [x0, #7]
    // 0x627b14: DecompressPointer r3
    //     0x627b14: add             x3, x3, HEAP, lsl #32
    // 0x627b18: mov             x2, x1
    // 0x627b1c: stur            x3, [fp, #-0x10]
    // 0x627b20: r1 = Function '<anonymous closure>': static.
    //     0x627b20: add             x1, PP, #0x50, lsl #12  ; [pp+0x50f50] AnonymousClosure: (0x624650), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x6275b4)
    //     0x627b24: ldr             x1, [x1, #0xf50]
    // 0x627b28: r0 = AllocateClosure()
    //     0x627b28: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x627b2c: ldr             x16, [fp, #0x18]
    // 0x627b30: stp             x0, x16, [SP, #-0x10]!
    // 0x627b34: ldur            x16, [fp, #-0x10]
    // 0x627b38: ldr             lr, [fp, #0x10]
    // 0x627b3c: stp             lr, x16, [SP, #-0x10]!
    // 0x627b40: r0 = addWithPaintOffset()
    //     0x627b40: bl              #0x622820  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x627b44: add             SP, SP, #0x20
    // 0x627b48: tbnz            w0, #4, #0x627b5c
    // 0x627b4c: r0 = true
    //     0x627b4c: add             x0, NULL, #0x20  ; true
    // 0x627b50: LeaveFrame
    //     0x627b50: mov             SP, fp
    //     0x627b54: ldp             fp, lr, [SP], #0x10
    // 0x627b58: ret
    //     0x627b58: ret             
    // 0x627b5c: ldur            x0, [fp, #-8]
    // 0x627b60: LoadField: r1 = r0->field_f
    //     0x627b60: ldur            w1, [x0, #0xf]
    // 0x627b64: DecompressPointer r1
    //     0x627b64: add             x1, x1, HEAP, lsl #32
    // 0x627b68: mov             x4, x1
    // 0x627b6c: ldr             x3, [fp, #0x20]
    // 0x627b70: b               #0x627a6c
    // 0x627b74: mov             x0, x3
    // 0x627b78: LoadField: r1 = r0->field_83
    //     0x627b78: ldur            w1, [x0, #0x83]
    // 0x627b7c: DecompressPointer r1
    //     0x627b7c: add             x1, x1, HEAP, lsl #32
    // 0x627b80: ldr             x16, [fp, #0x18]
    // 0x627b84: stp             x16, x1, [SP, #-0x10]!
    // 0x627b88: ldr             x16, [fp, #0x10]
    // 0x627b8c: SaveReg r16
    //     0x627b8c: str             x16, [SP, #-8]!
    // 0x627b90: r0 = hitTestChild()
    //     0x627b90: bl              #0x627c40  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::hitTestChild
    // 0x627b94: add             SP, SP, #0x18
    // 0x627b98: tbnz            w0, #4, #0x627bac
    // 0x627b9c: r0 = true
    //     0x627b9c: add             x0, NULL, #0x20  ; true
    // 0x627ba0: LeaveFrame
    //     0x627ba0: mov             SP, fp
    //     0x627ba4: ldp             fp, lr, [SP], #0x10
    // 0x627ba8: ret
    //     0x627ba8: ret             
    // 0x627bac: ldr             x0, [fp, #0x20]
    // 0x627bb0: LoadField: r1 = r0->field_87
    //     0x627bb0: ldur            w1, [x0, #0x87]
    // 0x627bb4: DecompressPointer r1
    //     0x627bb4: add             x1, x1, HEAP, lsl #32
    // 0x627bb8: ldr             x16, [fp, #0x18]
    // 0x627bbc: stp             x16, x1, [SP, #-0x10]!
    // 0x627bc0: ldr             x16, [fp, #0x10]
    // 0x627bc4: SaveReg r16
    //     0x627bc4: str             x16, [SP, #-8]!
    // 0x627bc8: r0 = hitTestChild()
    //     0x627bc8: bl              #0x627c40  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::hitTestChild
    // 0x627bcc: add             SP, SP, #0x18
    // 0x627bd0: tbnz            w0, #4, #0x627be4
    // 0x627bd4: r0 = true
    //     0x627bd4: add             x0, NULL, #0x20  ; true
    // 0x627bd8: LeaveFrame
    //     0x627bd8: mov             SP, fp
    //     0x627bdc: ldp             fp, lr, [SP], #0x10
    // 0x627be0: ret
    //     0x627be0: ret             
    // 0x627be4: ldr             x0, [fp, #0x20]
    // 0x627be8: LoadField: r1 = r0->field_8b
    //     0x627be8: ldur            w1, [x0, #0x8b]
    // 0x627bec: DecompressPointer r1
    //     0x627bec: add             x1, x1, HEAP, lsl #32
    // 0x627bf0: ldr             x16, [fp, #0x18]
    // 0x627bf4: stp             x16, x1, [SP, #-0x10]!
    // 0x627bf8: ldr             x16, [fp, #0x10]
    // 0x627bfc: SaveReg r16
    //     0x627bfc: str             x16, [SP, #-8]!
    // 0x627c00: r0 = hitTestChild()
    //     0x627c00: bl              #0x627c40  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::hitTestChild
    // 0x627c04: add             SP, SP, #0x18
    // 0x627c08: tbnz            w0, #4, #0x627c1c
    // 0x627c0c: r0 = true
    //     0x627c0c: add             x0, NULL, #0x20  ; true
    // 0x627c10: LeaveFrame
    //     0x627c10: mov             SP, fp
    //     0x627c14: ldp             fp, lr, [SP], #0x10
    // 0x627c18: ret
    //     0x627c18: ret             
    // 0x627c1c: r0 = false
    //     0x627c1c: add             x0, NULL, #0x30  ; false
    // 0x627c20: LeaveFrame
    //     0x627c20: mov             SP, fp
    //     0x627c24: ldp             fp, lr, [SP], #0x10
    // 0x627c28: ret
    //     0x627c28: ret             
    // 0x627c2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627c2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627c30: b               #0x627a5c
    // 0x627c34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627c34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627c38: b               #0x627a7c
    // 0x627c3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x627c3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  static _ hitTestChild(/* No info */) {
    // ** addr: 0x627c40, size: 0xfc
    // 0x627c40: EnterFrame
    //     0x627c40: stp             fp, lr, [SP, #-0x10]!
    //     0x627c44: mov             fp, SP
    // 0x627c48: AllocStack(0x18)
    //     0x627c48: sub             SP, SP, #0x18
    // 0x627c4c: CheckStackOverflow
    //     0x627c4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x627c50: cmp             SP, x16
    //     0x627c54: b.ls            #0x627d30
    // 0x627c58: r1 = 1
    //     0x627c58: mov             x1, #1
    // 0x627c5c: r0 = AllocateContext()
    //     0x627c5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x627c60: mov             x3, x0
    // 0x627c64: ldr             x0, [fp, #0x20]
    // 0x627c68: stur            x3, [fp, #-0x10]
    // 0x627c6c: StoreField: r3->field_f = r0
    //     0x627c6c: stur            w0, [x3, #0xf]
    // 0x627c70: cmp             w0, NULL
    // 0x627c74: b.ne            #0x627c88
    // 0x627c78: r0 = false
    //     0x627c78: add             x0, NULL, #0x30  ; false
    // 0x627c7c: LeaveFrame
    //     0x627c7c: mov             SP, fp
    //     0x627c80: ldp             fp, lr, [SP], #0x10
    // 0x627c84: ret
    //     0x627c84: ret             
    // 0x627c88: LoadField: r4 = r0->field_17
    //     0x627c88: ldur            w4, [x0, #0x17]
    // 0x627c8c: DecompressPointer r4
    //     0x627c8c: add             x4, x4, HEAP, lsl #32
    // 0x627c90: stur            x4, [fp, #-8]
    // 0x627c94: cmp             w4, NULL
    // 0x627c98: b.eq            #0x627d38
    // 0x627c9c: mov             x0, x4
    // 0x627ca0: r2 = Null
    //     0x627ca0: mov             x2, NULL
    // 0x627ca4: r1 = Null
    //     0x627ca4: mov             x1, NULL
    // 0x627ca8: r4 = LoadClassIdInstr(r0)
    //     0x627ca8: ldur            x4, [x0, #-1]
    //     0x627cac: ubfx            x4, x4, #0xc, #0x14
    // 0x627cb0: cmp             x4, #0x804
    // 0x627cb4: b.eq            #0x627ccc
    // 0x627cb8: r8 = ToolbarItemsParentData<RenderBox>
    //     0x627cb8: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x627cbc: ldr             x8, [x8, #0x528]
    // 0x627cc0: r3 = Null
    //     0x627cc0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f58] Null
    //     0x627cc4: ldr             x3, [x3, #0xf58]
    // 0x627cc8: r0 = DefaultTypeTest()
    //     0x627cc8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x627ccc: ldur            x0, [fp, #-8]
    // 0x627cd0: LoadField: r1 = r0->field_17
    //     0x627cd0: ldur            w1, [x0, #0x17]
    // 0x627cd4: DecompressPointer r1
    //     0x627cd4: add             x1, x1, HEAP, lsl #32
    // 0x627cd8: tbz             w1, #4, #0x627cec
    // 0x627cdc: r0 = false
    //     0x627cdc: add             x0, NULL, #0x30  ; false
    // 0x627ce0: LeaveFrame
    //     0x627ce0: mov             SP, fp
    //     0x627ce4: ldp             fp, lr, [SP], #0x10
    // 0x627ce8: ret
    //     0x627ce8: ret             
    // 0x627cec: LoadField: r3 = r0->field_7
    //     0x627cec: ldur            w3, [x0, #7]
    // 0x627cf0: DecompressPointer r3
    //     0x627cf0: add             x3, x3, HEAP, lsl #32
    // 0x627cf4: ldur            x2, [fp, #-0x10]
    // 0x627cf8: stur            x3, [fp, #-0x18]
    // 0x627cfc: r1 = Function '<anonymous closure>': static.
    //     0x627cfc: add             x1, PP, #0x50, lsl #12  ; [pp+0x50f50] AnonymousClosure: (0x624650), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x6275b4)
    //     0x627d00: ldr             x1, [x1, #0xf50]
    // 0x627d04: r0 = AllocateClosure()
    //     0x627d04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x627d08: ldr             x16, [fp, #0x18]
    // 0x627d0c: stp             x0, x16, [SP, #-0x10]!
    // 0x627d10: ldur            x16, [fp, #-0x18]
    // 0x627d14: ldr             lr, [fp, #0x10]
    // 0x627d18: stp             lr, x16, [SP, #-0x10]!
    // 0x627d1c: r0 = addWithPaintOffset()
    //     0x627d1c: bl              #0x622820  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintOffset
    // 0x627d20: add             SP, SP, #0x20
    // 0x627d24: LeaveFrame
    //     0x627d24: mov             SP, fp
    //     0x627d28: ldp             fp, lr, [SP], #0x10
    // 0x627d2c: ret
    //     0x627d2c: ret             
    // 0x627d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627d30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627d34: b               #0x627c58
    // 0x627d38: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x627d38: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x66a1c4, size: 0x68
    // 0x66a1c4: EnterFrame
    //     0x66a1c4: stp             fp, lr, [SP, #-0x10]!
    //     0x66a1c8: mov             fp, SP
    // 0x66a1cc: CheckStackOverflow
    //     0x66a1cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66a1d0: cmp             SP, x16
    //     0x66a1d4: b.ls            #0x66a224
    // 0x66a1d8: r1 = 2
    //     0x66a1d8: mov             x1, #2
    // 0x66a1dc: r0 = AllocateContext()
    //     0x66a1dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66a1e0: mov             x1, x0
    // 0x66a1e4: ldr             x0, [fp, #0x18]
    // 0x66a1e8: StoreField: r1->field_f = r0
    //     0x66a1e8: stur            w0, [x1, #0xf]
    // 0x66a1ec: ldr             x0, [fp, #0x10]
    // 0x66a1f0: StoreField: r1->field_13 = r0
    //     0x66a1f0: stur            w0, [x1, #0x13]
    // 0x66a1f4: mov             x2, x1
    // 0x66a1f8: r1 = Function '<anonymous closure>':.
    //     0x66a1f8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50f68] AnonymousClosure: (0x66a22c), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::paint (0x66a1c4)
    //     0x66a1fc: ldr             x1, [x1, #0xf68]
    // 0x66a200: r0 = AllocateClosure()
    //     0x66a200: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x66a204: ldr             x16, [fp, #0x20]
    // 0x66a208: stp             x0, x16, [SP, #-0x10]!
    // 0x66a20c: r0 = visitChildren()
    //     0x66a20c: bl              #0x6bf968  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0x66a210: add             SP, SP, #0x10
    // 0x66a214: r0 = Null
    //     0x66a214: mov             x0, NULL
    // 0x66a218: LeaveFrame
    //     0x66a218: mov             SP, fp
    //     0x66a21c: ldp             fp, lr, [SP], #0x10
    // 0x66a220: ret
    //     0x66a220: ret             
    // 0x66a224: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66a224: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66a228: b               #0x66a1d8
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x66a22c, size: 0x114
    // 0x66a22c: EnterFrame
    //     0x66a22c: stp             fp, lr, [SP, #-0x10]!
    //     0x66a230: mov             fp, SP
    // 0x66a234: AllocStack(0x10)
    //     0x66a234: sub             SP, SP, #0x10
    // 0x66a238: SetupParameters()
    //     0x66a238: ldr             x0, [fp, #0x18]
    //     0x66a23c: ldur            w3, [x0, #0x17]
    //     0x66a240: add             x3, x3, HEAP, lsl #32
    //     0x66a244: stur            x3, [fp, #-8]
    // 0x66a248: CheckStackOverflow
    //     0x66a248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66a24c: cmp             SP, x16
    //     0x66a250: b.ls            #0x66a334
    // 0x66a254: ldr             x0, [fp, #0x10]
    // 0x66a258: r2 = Null
    //     0x66a258: mov             x2, NULL
    // 0x66a25c: r1 = Null
    //     0x66a25c: mov             x1, NULL
    // 0x66a260: r4 = LoadClassIdInstr(r0)
    //     0x66a260: ldur            x4, [x0, #-1]
    //     0x66a264: ubfx            x4, x4, #0xc, #0x14
    // 0x66a268: sub             x4, x4, #0x965
    // 0x66a26c: cmp             x4, #0x8b
    // 0x66a270: b.ls            #0x66a288
    // 0x66a274: r8 = RenderBox
    //     0x66a274: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x66a278: ldr             x8, [x8, #0xfa0]
    // 0x66a27c: r3 = Null
    //     0x66a27c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f70] Null
    //     0x66a280: ldr             x3, [x3, #0xf70]
    // 0x66a284: r0 = RenderBox()
    //     0x66a284: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x66a288: ldr             x3, [fp, #0x10]
    // 0x66a28c: LoadField: r4 = r3->field_17
    //     0x66a28c: ldur            w4, [x3, #0x17]
    // 0x66a290: DecompressPointer r4
    //     0x66a290: add             x4, x4, HEAP, lsl #32
    // 0x66a294: stur            x4, [fp, #-0x10]
    // 0x66a298: cmp             w4, NULL
    // 0x66a29c: b.eq            #0x66a33c
    // 0x66a2a0: mov             x0, x4
    // 0x66a2a4: r2 = Null
    //     0x66a2a4: mov             x2, NULL
    // 0x66a2a8: r1 = Null
    //     0x66a2a8: mov             x1, NULL
    // 0x66a2ac: r4 = LoadClassIdInstr(r0)
    //     0x66a2ac: ldur            x4, [x0, #-1]
    //     0x66a2b0: ubfx            x4, x4, #0xc, #0x14
    // 0x66a2b4: cmp             x4, #0x804
    // 0x66a2b8: b.eq            #0x66a2d0
    // 0x66a2bc: r8 = ToolbarItemsParentData<RenderBox>
    //     0x66a2bc: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x66a2c0: ldr             x8, [x8, #0x528]
    // 0x66a2c4: r3 = Null
    //     0x66a2c4: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f80] Null
    //     0x66a2c8: ldr             x3, [x3, #0xf80]
    // 0x66a2cc: r0 = DefaultTypeTest()
    //     0x66a2cc: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x66a2d0: ldur            x0, [fp, #-0x10]
    // 0x66a2d4: LoadField: r1 = r0->field_17
    //     0x66a2d4: ldur            w1, [x0, #0x17]
    // 0x66a2d8: DecompressPointer r1
    //     0x66a2d8: add             x1, x1, HEAP, lsl #32
    // 0x66a2dc: tbnz            w1, #4, #0x66a324
    // 0x66a2e0: ldur            x1, [fp, #-8]
    // 0x66a2e4: LoadField: r2 = r0->field_7
    //     0x66a2e4: ldur            w2, [x0, #7]
    // 0x66a2e8: DecompressPointer r2
    //     0x66a2e8: add             x2, x2, HEAP, lsl #32
    // 0x66a2ec: LoadField: r0 = r1->field_13
    //     0x66a2ec: ldur            w0, [x1, #0x13]
    // 0x66a2f0: DecompressPointer r0
    //     0x66a2f0: add             x0, x0, HEAP, lsl #32
    // 0x66a2f4: stp             x0, x2, [SP, #-0x10]!
    // 0x66a2f8: r0 = +()
    //     0x66a2f8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x66a2fc: add             SP, SP, #0x10
    // 0x66a300: mov             x1, x0
    // 0x66a304: ldur            x0, [fp, #-8]
    // 0x66a308: LoadField: r2 = r0->field_f
    //     0x66a308: ldur            w2, [x0, #0xf]
    // 0x66a30c: DecompressPointer r2
    //     0x66a30c: add             x2, x2, HEAP, lsl #32
    // 0x66a310: ldr             x16, [fp, #0x10]
    // 0x66a314: stp             x16, x2, [SP, #-0x10]!
    // 0x66a318: SaveReg r1
    //     0x66a318: str             x1, [SP, #-8]!
    // 0x66a31c: r0 = paintChild()
    //     0x66a31c: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x66a320: add             SP, SP, #0x18
    // 0x66a324: r0 = Null
    //     0x66a324: mov             x0, NULL
    // 0x66a328: LeaveFrame
    //     0x66a328: mov             SP, fp
    //     0x66a32c: ldp             fp, lr, [SP], #0x10
    // 0x66a330: ret
    //     0x66a330: ret             
    // 0x66a334: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x66a334: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66a338: b               #0x66a254
    // 0x66a33c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x66a33c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ visitChildrenForSemantics(/* No info */) {
    // ** addr: 0x675ee0, size: 0x60
    // 0x675ee0: EnterFrame
    //     0x675ee0: stp             fp, lr, [SP, #-0x10]!
    //     0x675ee4: mov             fp, SP
    // 0x675ee8: CheckStackOverflow
    //     0x675ee8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675eec: cmp             SP, x16
    //     0x675ef0: b.ls            #0x675f38
    // 0x675ef4: r1 = 1
    //     0x675ef4: mov             x1, #1
    // 0x675ef8: r0 = AllocateContext()
    //     0x675ef8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x675efc: mov             x1, x0
    // 0x675f00: ldr             x0, [fp, #0x10]
    // 0x675f04: StoreField: r1->field_f = r0
    //     0x675f04: stur            w0, [x1, #0xf]
    // 0x675f08: mov             x2, x1
    // 0x675f0c: r1 = Function '<anonymous closure>':.
    //     0x675f0c: add             x1, PP, #0x50, lsl #12  ; [pp+0x50ed0] AnonymousClosure: (0x675f40), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildrenForSemantics (0x675ee0)
    //     0x675f10: ldr             x1, [x1, #0xed0]
    // 0x675f14: r0 = AllocateClosure()
    //     0x675f14: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x675f18: ldr             x16, [fp, #0x18]
    // 0x675f1c: stp             x0, x16, [SP, #-0x10]!
    // 0x675f20: r0 = visitChildren()
    //     0x675f20: bl              #0x6bf968  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0x675f24: add             SP, SP, #0x10
    // 0x675f28: r0 = Null
    //     0x675f28: mov             x0, NULL
    // 0x675f2c: LeaveFrame
    //     0x675f2c: mov             SP, fp
    //     0x675f30: ldp             fp, lr, [SP], #0x10
    // 0x675f34: ret
    //     0x675f34: ret             
    // 0x675f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x675f38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x675f3c: b               #0x675ef4
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x675f40, size: 0x104
    // 0x675f40: EnterFrame
    //     0x675f40: stp             fp, lr, [SP, #-0x10]!
    //     0x675f44: mov             fp, SP
    // 0x675f48: AllocStack(0x10)
    //     0x675f48: sub             SP, SP, #0x10
    // 0x675f4c: SetupParameters()
    //     0x675f4c: ldr             x0, [fp, #0x18]
    //     0x675f50: ldur            w3, [x0, #0x17]
    //     0x675f54: add             x3, x3, HEAP, lsl #32
    //     0x675f58: stur            x3, [fp, #-8]
    // 0x675f5c: CheckStackOverflow
    //     0x675f5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x675f60: cmp             SP, x16
    //     0x675f64: b.ls            #0x676034
    // 0x675f68: ldr             x0, [fp, #0x10]
    // 0x675f6c: r2 = Null
    //     0x675f6c: mov             x2, NULL
    // 0x675f70: r1 = Null
    //     0x675f70: mov             x1, NULL
    // 0x675f74: r4 = LoadClassIdInstr(r0)
    //     0x675f74: ldur            x4, [x0, #-1]
    //     0x675f78: ubfx            x4, x4, #0xc, #0x14
    // 0x675f7c: sub             x4, x4, #0x965
    // 0x675f80: cmp             x4, #0x8b
    // 0x675f84: b.ls            #0x675f9c
    // 0x675f88: r8 = RenderBox
    //     0x675f88: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x675f8c: ldr             x8, [x8, #0xfa0]
    // 0x675f90: r3 = Null
    //     0x675f90: add             x3, PP, #0x50, lsl #12  ; [pp+0x50ed8] Null
    //     0x675f94: ldr             x3, [x3, #0xed8]
    // 0x675f98: r0 = RenderBox()
    //     0x675f98: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x675f9c: ldr             x3, [fp, #0x10]
    // 0x675fa0: LoadField: r4 = r3->field_17
    //     0x675fa0: ldur            w4, [x3, #0x17]
    // 0x675fa4: DecompressPointer r4
    //     0x675fa4: add             x4, x4, HEAP, lsl #32
    // 0x675fa8: stur            x4, [fp, #-0x10]
    // 0x675fac: cmp             w4, NULL
    // 0x675fb0: b.eq            #0x67603c
    // 0x675fb4: mov             x0, x4
    // 0x675fb8: r2 = Null
    //     0x675fb8: mov             x2, NULL
    // 0x675fbc: r1 = Null
    //     0x675fbc: mov             x1, NULL
    // 0x675fc0: r4 = LoadClassIdInstr(r0)
    //     0x675fc0: ldur            x4, [x0, #-1]
    //     0x675fc4: ubfx            x4, x4, #0xc, #0x14
    // 0x675fc8: cmp             x4, #0x804
    // 0x675fcc: b.eq            #0x675fe4
    // 0x675fd0: r8 = ToolbarItemsParentData<RenderBox>
    //     0x675fd0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x675fd4: ldr             x8, [x8, #0x528]
    // 0x675fd8: r3 = Null
    //     0x675fd8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50ee8] Null
    //     0x675fdc: ldr             x3, [x3, #0xee8]
    // 0x675fe0: r0 = DefaultTypeTest()
    //     0x675fe0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x675fe4: ldur            x0, [fp, #-0x10]
    // 0x675fe8: LoadField: r1 = r0->field_17
    //     0x675fe8: ldur            w1, [x0, #0x17]
    // 0x675fec: DecompressPointer r1
    //     0x675fec: add             x1, x1, HEAP, lsl #32
    // 0x675ff0: tbnz            w1, #4, #0x676024
    // 0x675ff4: ldur            x0, [fp, #-8]
    // 0x675ff8: LoadField: r1 = r0->field_f
    //     0x675ff8: ldur            w1, [x0, #0xf]
    // 0x675ffc: DecompressPointer r1
    //     0x675ffc: add             x1, x1, HEAP, lsl #32
    // 0x676000: cmp             w1, NULL
    // 0x676004: b.eq            #0x676040
    // 0x676008: ldr             x16, [fp, #0x10]
    // 0x67600c: stp             x16, x1, [SP, #-0x10]!
    // 0x676010: mov             x0, x1
    // 0x676014: ClosureCall
    //     0x676014: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x676018: ldur            x2, [x0, #0x1f]
    //     0x67601c: blr             x2
    // 0x676020: add             SP, SP, #0x10
    // 0x676024: r0 = Null
    //     0x676024: mov             x0, NULL
    // 0x676028: LeaveFrame
    //     0x676028: mov             SP, fp
    //     0x67602c: ldp             fp, lr, [SP], #0x10
    // 0x676030: ret
    //     0x676030: ret             
    // 0x676034: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x676034: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x676038: b               #0x675f68
    // 0x67603c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x67603c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x676040: r0 = NullErrorSharedWithoutFPURegs()
    //     0x676040: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x69441c, size: 0xaac
    // 0x69441c: EnterFrame
    //     0x69441c: stp             fp, lr, [SP, #-0x10]!
    //     0x694420: mov             fp, SP
    // 0x694424: AllocStack(0x30)
    //     0x694424: sub             SP, SP, #0x30
    // 0x694428: CheckStackOverflow
    //     0x694428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x69442c: cmp             SP, x16
    //     0x694430: b.ls            #0x694e0c
    // 0x694434: r1 = 8
    //     0x694434: mov             x1, #8
    // 0x694438: r0 = AllocateContext()
    //     0x694438: bl              #0xd68aa4  ; AllocateContextStub
    // 0x69443c: mov             x4, x0
    // 0x694440: ldr             x3, [fp, #0x10]
    // 0x694444: stur            x4, [fp, #-0x18]
    // 0x694448: StoreField: r4->field_f = r3
    //     0x694448: stur            w3, [x4, #0xf]
    // 0x69444c: LoadField: r0 = r3->field_67
    //     0x69444c: ldur            w0, [x3, #0x67]
    // 0x694450: DecompressPointer r0
    //     0x694450: add             x0, x0, HEAP, lsl #32
    // 0x694454: cmp             w0, NULL
    // 0x694458: b.ne            #0x6944e4
    // 0x69445c: LoadField: r4 = r3->field_27
    //     0x69445c: ldur            w4, [x3, #0x27]
    // 0x694460: DecompressPointer r4
    //     0x694460: add             x4, x4, HEAP, lsl #32
    // 0x694464: stur            x4, [fp, #-8]
    // 0x694468: cmp             w4, NULL
    // 0x69446c: b.eq            #0x694d84
    // 0x694470: mov             x0, x4
    // 0x694474: r2 = Null
    //     0x694474: mov             x2, NULL
    // 0x694478: r1 = Null
    //     0x694478: mov             x1, NULL
    // 0x69447c: r4 = LoadClassIdInstr(r0)
    //     0x69447c: ldur            x4, [x0, #-1]
    //     0x694480: ubfx            x4, x4, #0xc, #0x14
    // 0x694484: sub             x4, x4, #0x80d
    // 0x694488: cmp             x4, #1
    // 0x69448c: b.ls            #0x6944a4
    // 0x694490: r8 = BoxConstraints
    //     0x694490: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x694494: ldr             x8, [x8, #0x1d0]
    // 0x694498: r3 = Null
    //     0x694498: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f90] Null
    //     0x69449c: ldr             x3, [x3, #0xf90]
    // 0x6944a0: r0 = BoxConstraints()
    //     0x6944a0: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6944a4: ldur            x16, [fp, #-8]
    // 0x6944a8: SaveReg r16
    //     0x6944a8: str             x16, [SP, #-8]!
    // 0x6944ac: r0 = smallest()
    //     0x6944ac: bl              #0x62bd18  ; [package:flutter/src/rendering/box.dart] BoxConstraints::smallest
    // 0x6944b0: add             SP, SP, #8
    // 0x6944b4: ldr             x3, [fp, #0x10]
    // 0x6944b8: StoreField: r3->field_57 = r0
    //     0x6944b8: stur            w0, [x3, #0x57]
    //     0x6944bc: ldurb           w16, [x3, #-1]
    //     0x6944c0: ldurb           w17, [x0, #-1]
    //     0x6944c4: and             x16, x17, x16, lsr #2
    //     0x6944c8: tst             x16, HEAP, lsr #32
    //     0x6944cc: b.eq            #0x6944d4
    //     0x6944d0: bl              #0xd682ac
    // 0x6944d4: r0 = Null
    //     0x6944d4: mov             x0, NULL
    // 0x6944d8: LeaveFrame
    //     0x6944d8: mov             SP, fp
    //     0x6944dc: ldp             fp, lr, [SP], #0x10
    // 0x6944e0: ret
    //     0x6944e0: ret             
    // 0x6944e4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6944e4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6944e8: ldr             x0, [x0, #0x1e8]
    // 0x6944ec: LoadField: r5 = r3->field_83
    //     0x6944ec: ldur            w5, [x3, #0x83]
    // 0x6944f0: DecompressPointer r5
    //     0x6944f0: add             x5, x5, HEAP, lsl #32
    // 0x6944f4: stur            x5, [fp, #-0x10]
    // 0x6944f8: cmp             w5, NULL
    // 0x6944fc: b.eq            #0x694e14
    // 0x694500: LoadField: r6 = r3->field_27
    //     0x694500: ldur            w6, [x3, #0x27]
    // 0x694504: DecompressPointer r6
    //     0x694504: add             x6, x6, HEAP, lsl #32
    // 0x694508: stur            x6, [fp, #-8]
    // 0x69450c: cmp             w6, NULL
    // 0x694510: b.eq            #0x694da4
    // 0x694514: mov             x7, x0
    // 0x694518: mov             x0, x6
    // 0x69451c: r2 = Null
    //     0x69451c: mov             x2, NULL
    // 0x694520: r1 = Null
    //     0x694520: mov             x1, NULL
    // 0x694524: r4 = LoadClassIdInstr(r0)
    //     0x694524: ldur            x4, [x0, #-1]
    //     0x694528: ubfx            x4, x4, #0xc, #0x14
    // 0x69452c: sub             x4, x4, #0x80d
    // 0x694530: cmp             x4, #1
    // 0x694534: b.ls            #0x69454c
    // 0x694538: r8 = BoxConstraints
    //     0x694538: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69453c: ldr             x8, [x8, #0x1d0]
    // 0x694540: r3 = Null
    //     0x694540: add             x3, PP, #0x50, lsl #12  ; [pp+0x50fa0] Null
    //     0x694544: ldr             x3, [x3, #0xfa0]
    // 0x694548: r0 = BoxConstraints()
    //     0x694548: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69454c: ldur            x16, [fp, #-8]
    // 0x694550: SaveReg r16
    //     0x694550: str             x16, [SP, #-8]!
    // 0x694554: r0 = loosen()
    //     0x694554: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x694558: add             SP, SP, #8
    // 0x69455c: mov             x1, x0
    // 0x694560: ldur            x0, [fp, #-0x10]
    // 0x694564: r2 = LoadClassIdInstr(r0)
    //     0x694564: ldur            x2, [x0, #-1]
    //     0x694568: ubfx            x2, x2, #0xc, #0x14
    // 0x69456c: stp             x1, x0, [SP, #-0x10]!
    // 0x694570: r16 = true
    //     0x694570: add             x16, NULL, #0x20  ; true
    // 0x694574: SaveReg r16
    //     0x694574: str             x16, [SP, #-8]!
    // 0x694578: mov             x0, x2
    // 0x69457c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x69457c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x694580: ldr             x4, [x4, #0x1c8]
    // 0x694584: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x694584: mov             x17, #0xcdfb
    //     0x694588: add             lr, x0, x17
    //     0x69458c: ldr             lr, [x21, lr, lsl #3]
    //     0x694590: blr             lr
    // 0x694594: add             SP, SP, #0x18
    // 0x694598: ldr             x3, [fp, #0x10]
    // 0x69459c: LoadField: r4 = r3->field_87
    //     0x69459c: ldur            w4, [x3, #0x87]
    // 0x6945a0: DecompressPointer r4
    //     0x6945a0: add             x4, x4, HEAP, lsl #32
    // 0x6945a4: stur            x4, [fp, #-0x10]
    // 0x6945a8: cmp             w4, NULL
    // 0x6945ac: b.eq            #0x694e18
    // 0x6945b0: LoadField: r5 = r3->field_27
    //     0x6945b0: ldur            w5, [x3, #0x27]
    // 0x6945b4: DecompressPointer r5
    //     0x6945b4: add             x5, x5, HEAP, lsl #32
    // 0x6945b8: stur            x5, [fp, #-8]
    // 0x6945bc: cmp             w5, NULL
    // 0x6945c0: b.eq            #0x694dbc
    // 0x6945c4: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6945c4: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6945c8: ldr             x6, [x6, #0x1e8]
    // 0x6945cc: mov             x0, x5
    // 0x6945d0: r2 = Null
    //     0x6945d0: mov             x2, NULL
    // 0x6945d4: r1 = Null
    //     0x6945d4: mov             x1, NULL
    // 0x6945d8: r4 = LoadClassIdInstr(r0)
    //     0x6945d8: ldur            x4, [x0, #-1]
    //     0x6945dc: ubfx            x4, x4, #0xc, #0x14
    // 0x6945e0: sub             x4, x4, #0x80d
    // 0x6945e4: cmp             x4, #1
    // 0x6945e8: b.ls            #0x694600
    // 0x6945ec: r8 = BoxConstraints
    //     0x6945ec: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6945f0: ldr             x8, [x8, #0x1d0]
    // 0x6945f4: r3 = Null
    //     0x6945f4: add             x3, PP, #0x50, lsl #12  ; [pp+0x50fb0] Null
    //     0x6945f8: ldr             x3, [x3, #0xfb0]
    // 0x6945fc: r0 = BoxConstraints()
    //     0x6945fc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x694600: ldur            x16, [fp, #-8]
    // 0x694604: SaveReg r16
    //     0x694604: str             x16, [SP, #-8]!
    // 0x694608: r0 = loosen()
    //     0x694608: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x69460c: add             SP, SP, #8
    // 0x694610: mov             x1, x0
    // 0x694614: ldur            x0, [fp, #-0x10]
    // 0x694618: r2 = LoadClassIdInstr(r0)
    //     0x694618: ldur            x2, [x0, #-1]
    //     0x69461c: ubfx            x2, x2, #0xc, #0x14
    // 0x694620: stp             x1, x0, [SP, #-0x10]!
    // 0x694624: r16 = true
    //     0x694624: add             x16, NULL, #0x20  ; true
    // 0x694628: SaveReg r16
    //     0x694628: str             x16, [SP, #-8]!
    // 0x69462c: mov             x0, x2
    // 0x694630: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x694630: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x694634: ldr             x4, [x4, #0x1c8]
    // 0x694638: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x694638: mov             x17, #0xcdfb
    //     0x69463c: add             lr, x0, x17
    //     0x694640: ldr             lr, [x21, lr, lsl #3]
    //     0x694644: blr             lr
    // 0x694648: add             SP, SP, #0x18
    // 0x69464c: ldr             x3, [fp, #0x10]
    // 0x694650: LoadField: r4 = r3->field_8b
    //     0x694650: ldur            w4, [x3, #0x8b]
    // 0x694654: DecompressPointer r4
    //     0x694654: add             x4, x4, HEAP, lsl #32
    // 0x694658: stur            x4, [fp, #-0x10]
    // 0x69465c: cmp             w4, NULL
    // 0x694660: b.eq            #0x694e1c
    // 0x694664: LoadField: r5 = r3->field_27
    //     0x694664: ldur            w5, [x3, #0x27]
    // 0x694668: DecompressPointer r5
    //     0x694668: add             x5, x5, HEAP, lsl #32
    // 0x69466c: stur            x5, [fp, #-8]
    // 0x694670: cmp             w5, NULL
    // 0x694674: b.eq            #0x694dd4
    // 0x694678: ldur            x7, [fp, #-0x18]
    // 0x69467c: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x69467c: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x694680: ldr             x6, [x6, #0x1e8]
    // 0x694684: mov             x0, x5
    // 0x694688: r2 = Null
    //     0x694688: mov             x2, NULL
    // 0x69468c: r1 = Null
    //     0x69468c: mov             x1, NULL
    // 0x694690: r4 = LoadClassIdInstr(r0)
    //     0x694690: ldur            x4, [x0, #-1]
    //     0x694694: ubfx            x4, x4, #0xc, #0x14
    // 0x694698: sub             x4, x4, #0x80d
    // 0x69469c: cmp             x4, #1
    // 0x6946a0: b.ls            #0x6946b8
    // 0x6946a4: r8 = BoxConstraints
    //     0x6946a4: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6946a8: ldr             x8, [x8, #0x1d0]
    // 0x6946ac: r3 = Null
    //     0x6946ac: add             x3, PP, #0x50, lsl #12  ; [pp+0x50fc0] Null
    //     0x6946b0: ldr             x3, [x3, #0xfc0]
    // 0x6946b4: r0 = BoxConstraints()
    //     0x6946b4: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x6946b8: ldur            x16, [fp, #-8]
    // 0x6946bc: SaveReg r16
    //     0x6946bc: str             x16, [SP, #-8]!
    // 0x6946c0: r0 = loosen()
    //     0x6946c0: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x6946c4: add             SP, SP, #8
    // 0x6946c8: mov             x1, x0
    // 0x6946cc: ldur            x0, [fp, #-0x10]
    // 0x6946d0: r2 = LoadClassIdInstr(r0)
    //     0x6946d0: ldur            x2, [x0, #-1]
    //     0x6946d4: ubfx            x2, x2, #0xc, #0x14
    // 0x6946d8: stp             x1, x0, [SP, #-0x10]!
    // 0x6946dc: r16 = true
    //     0x6946dc: add             x16, NULL, #0x20  ; true
    // 0x6946e0: SaveReg r16
    //     0x6946e0: str             x16, [SP, #-8]!
    // 0x6946e4: mov             x0, x2
    // 0x6946e8: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x6946e8: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x6946ec: ldr             x4, [x4, #0x1c8]
    // 0x6946f0: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x6946f0: mov             x17, #0xcdfb
    //     0x6946f4: add             lr, x0, x17
    //     0x6946f8: ldr             lr, [x21, lr, lsl #3]
    //     0x6946fc: blr             lr
    // 0x694700: add             SP, SP, #0x18
    // 0x694704: ldr             x3, [fp, #0x10]
    // 0x694708: LoadField: r0 = r3->field_83
    //     0x694708: ldur            w0, [x3, #0x83]
    // 0x69470c: DecompressPointer r0
    //     0x69470c: add             x0, x0, HEAP, lsl #32
    // 0x694710: cmp             w0, NULL
    // 0x694714: b.eq            #0x694e20
    // 0x694718: LoadField: r1 = r0->field_57
    //     0x694718: ldur            w1, [x0, #0x57]
    // 0x69471c: DecompressPointer r1
    //     0x69471c: add             x1, x1, HEAP, lsl #32
    // 0x694720: cmp             w1, NULL
    // 0x694724: b.eq            #0x694e24
    // 0x694728: LoadField: d0 = r1->field_7
    //     0x694728: ldur            d0, [x1, #7]
    // 0x69472c: LoadField: r0 = r3->field_87
    //     0x69472c: ldur            w0, [x3, #0x87]
    // 0x694730: DecompressPointer r0
    //     0x694730: add             x0, x0, HEAP, lsl #32
    // 0x694734: cmp             w0, NULL
    // 0x694738: b.eq            #0x694e28
    // 0x69473c: LoadField: r1 = r0->field_57
    //     0x69473c: ldur            w1, [x0, #0x57]
    // 0x694740: DecompressPointer r1
    //     0x694740: add             x1, x1, HEAP, lsl #32
    // 0x694744: cmp             w1, NULL
    // 0x694748: b.eq            #0x694e2c
    // 0x69474c: LoadField: d1 = r1->field_7
    //     0x69474c: ldur            d1, [x1, #7]
    // 0x694750: fadd            d2, d0, d1
    // 0x694754: r0 = inline_Allocate_Double()
    //     0x694754: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x694758: add             x0, x0, #0x10
    //     0x69475c: cmp             x1, x0
    //     0x694760: b.ls            #0x694e30
    //     0x694764: str             x0, [THR, #0x60]  ; THR::top
    //     0x694768: sub             x0, x0, #0xf
    //     0x69476c: mov             x1, #0xd108
    //     0x694770: movk            x1, #3, lsl #16
    //     0x694774: stur            x1, [x0, #-1]
    // 0x694778: StoreField: r0->field_7 = d2
    //     0x694778: stur            d2, [x0, #7]
    // 0x69477c: ldur            x4, [fp, #-0x18]
    // 0x694780: StoreField: r4->field_13 = r0
    //     0x694780: stur            w0, [x4, #0x13]
    //     0x694784: ldurb           w16, [x4, #-1]
    //     0x694788: ldurb           w17, [x0, #-1]
    //     0x69478c: and             x16, x17, x16, lsr #2
    //     0x694790: tst             x16, HEAP, lsr #32
    //     0x694794: b.eq            #0x69479c
    //     0x694798: bl              #0xd682cc
    // 0x69479c: r0 = 0.000000
    //     0x69479c: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6947a0: StoreField: r4->field_17 = r0
    //     0x6947a0: stur            w0, [x4, #0x17]
    // 0x6947a4: r1 = Sentinel
    //     0x6947a4: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6947a8: StoreField: r4->field_1b = r1
    //     0x6947a8: stur            w1, [x4, #0x1b]
    // 0x6947ac: StoreField: r4->field_1f = r1
    //     0x6947ac: stur            w1, [x4, #0x1f]
    // 0x6947b0: StoreField: r4->field_23 = r1
    //     0x6947b0: stur            w1, [x4, #0x23]
    // 0x6947b4: StoreField: r4->field_27 = rZR
    //     0x6947b4: stur            wzr, [x4, #0x27]
    // 0x6947b8: r1 = -2
    //     0x6947b8: mov             x1, #-2
    // 0x6947bc: StoreField: r4->field_2b = r1
    //     0x6947bc: stur            w1, [x4, #0x2b]
    // 0x6947c0: mov             x2, x4
    // 0x6947c4: r1 = Function '<anonymous closure>':.
    //     0x6947c4: add             x1, PP, #0x50, lsl #12  ; [pp+0x50fd0] AnonymousClosure: (0x694ec8), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::performLayout (0x69441c)
    //     0x6947c8: ldr             x1, [x1, #0xfd0]
    // 0x6947cc: r0 = AllocateClosure()
    //     0x6947cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6947d0: ldr             x16, [fp, #0x10]
    // 0x6947d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6947d8: r0 = visitChildren()
    //     0x6947d8: bl              #0x6bf968  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0x6947dc: add             SP, SP, #0x10
    // 0x6947e0: ldur            x3, [fp, #-0x18]
    // 0x6947e4: LoadField: r4 = r3->field_27
    //     0x6947e4: ldur            w4, [x3, #0x27]
    // 0x6947e8: DecompressPointer r4
    //     0x6947e8: add             x4, x4, HEAP, lsl #32
    // 0x6947ec: stur            x4, [fp, #-0x10]
    // 0x6947f0: cmp             w4, NULL
    // 0x6947f4: b.eq            #0x694e48
    // 0x6947f8: r0 = LoadInt32Instr(r4)
    //     0x6947f8: sbfx            x0, x4, #1, #0x1f
    //     0x6947fc: tbz             w4, #0, #0x694804
    //     0x694800: ldur            x0, [x4, #7]
    // 0x694804: cmp             x0, #0
    // 0x694808: b.le            #0x694c14
    // 0x69480c: ldr             x5, [fp, #0x10]
    // 0x694810: LoadField: r0 = r5->field_87
    //     0x694810: ldur            w0, [x5, #0x87]
    // 0x694814: DecompressPointer r0
    //     0x694814: add             x0, x0, HEAP, lsl #32
    // 0x694818: cmp             w0, NULL
    // 0x69481c: b.eq            #0x694e4c
    // 0x694820: LoadField: r6 = r0->field_17
    //     0x694820: ldur            w6, [x0, #0x17]
    // 0x694824: DecompressPointer r6
    //     0x694824: add             x6, x6, HEAP, lsl #32
    // 0x694828: stur            x6, [fp, #-8]
    // 0x69482c: cmp             w6, NULL
    // 0x694830: b.eq            #0x694e50
    // 0x694834: mov             x0, x6
    // 0x694838: r2 = Null
    //     0x694838: mov             x2, NULL
    // 0x69483c: r1 = Null
    //     0x69483c: mov             x1, NULL
    // 0x694840: r4 = LoadClassIdInstr(r0)
    //     0x694840: ldur            x4, [x0, #-1]
    //     0x694844: ubfx            x4, x4, #0xc, #0x14
    // 0x694848: cmp             x4, #0x804
    // 0x69484c: b.eq            #0x694864
    // 0x694850: r8 = ToolbarItemsParentData<RenderBox>
    //     0x694850: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x694854: ldr             x8, [x8, #0x528]
    // 0x694858: r3 = Null
    //     0x694858: add             x3, PP, #0x50, lsl #12  ; [pp+0x50fd8] Null
    //     0x69485c: ldr             x3, [x3, #0xfd8]
    // 0x694860: r0 = DefaultTypeTest()
    //     0x694860: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x694864: ldr             x3, [fp, #0x10]
    // 0x694868: LoadField: r0 = r3->field_8b
    //     0x694868: ldur            w0, [x3, #0x8b]
    // 0x69486c: DecompressPointer r0
    //     0x69486c: add             x0, x0, HEAP, lsl #32
    // 0x694870: cmp             w0, NULL
    // 0x694874: b.eq            #0x694e54
    // 0x694878: LoadField: r4 = r0->field_17
    //     0x694878: ldur            w4, [x0, #0x17]
    // 0x69487c: DecompressPointer r4
    //     0x69487c: add             x4, x4, HEAP, lsl #32
    // 0x694880: stur            x4, [fp, #-0x20]
    // 0x694884: cmp             w4, NULL
    // 0x694888: b.eq            #0x694e58
    // 0x69488c: mov             x0, x4
    // 0x694890: r2 = Null
    //     0x694890: mov             x2, NULL
    // 0x694894: r1 = Null
    //     0x694894: mov             x1, NULL
    // 0x694898: r4 = LoadClassIdInstr(r0)
    //     0x694898: ldur            x4, [x0, #-1]
    //     0x69489c: ubfx            x4, x4, #0xc, #0x14
    // 0x6948a0: cmp             x4, #0x804
    // 0x6948a4: b.eq            #0x6948bc
    // 0x6948a8: r8 = ToolbarItemsParentData<RenderBox>
    //     0x6948a8: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x6948ac: ldr             x8, [x8, #0x528]
    // 0x6948b0: r3 = Null
    //     0x6948b0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50fe8] Null
    //     0x6948b4: ldr             x3, [x3, #0xfe8]
    // 0x6948b8: r0 = DefaultTypeTest()
    //     0x6948b8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6948bc: ldr             x3, [fp, #0x10]
    // 0x6948c0: LoadField: r0 = r3->field_83
    //     0x6948c0: ldur            w0, [x3, #0x83]
    // 0x6948c4: DecompressPointer r0
    //     0x6948c4: add             x0, x0, HEAP, lsl #32
    // 0x6948c8: cmp             w0, NULL
    // 0x6948cc: b.eq            #0x694e5c
    // 0x6948d0: LoadField: r4 = r0->field_17
    //     0x6948d0: ldur            w4, [x0, #0x17]
    // 0x6948d4: DecompressPointer r4
    //     0x6948d4: add             x4, x4, HEAP, lsl #32
    // 0x6948d8: stur            x4, [fp, #-0x28]
    // 0x6948dc: cmp             w4, NULL
    // 0x6948e0: b.eq            #0x694e60
    // 0x6948e4: mov             x0, x4
    // 0x6948e8: r2 = Null
    //     0x6948e8: mov             x2, NULL
    // 0x6948ec: r1 = Null
    //     0x6948ec: mov             x1, NULL
    // 0x6948f0: r4 = LoadClassIdInstr(r0)
    //     0x6948f0: ldur            x4, [x0, #-1]
    //     0x6948f4: ubfx            x4, x4, #0xc, #0x14
    // 0x6948f8: cmp             x4, #0x804
    // 0x6948fc: b.eq            #0x694914
    // 0x694900: r8 = ToolbarItemsParentData<RenderBox>
    //     0x694900: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x694904: ldr             x8, [x8, #0x528]
    // 0x694908: r3 = Null
    //     0x694908: add             x3, PP, #0x50, lsl #12  ; [pp+0x50ff8] Null
    //     0x69490c: ldr             x3, [x3, #0xff8]
    // 0x694910: r0 = DefaultTypeTest()
    //     0x694910: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x694914: ldr             x2, [fp, #0x10]
    // 0x694918: LoadField: r3 = r2->field_73
    //     0x694918: ldur            x3, [x2, #0x73]
    // 0x69491c: r0 = BoxInt64Instr(r3)
    //     0x69491c: sbfiz           x0, x3, #1, #0x1f
    //     0x694920: cmp             x3, x0, asr #1
    //     0x694924: b.eq            #0x694930
    //     0x694928: bl              #0xd69bb8
    //     0x69492c: stur            x3, [x0, #7]
    // 0x694930: mov             x1, x0
    // 0x694934: ldur            x0, [fp, #-0x10]
    // 0x694938: cmp             w1, w0
    // 0x69493c: b.eq            #0x694978
    // 0x694940: and             w16, w1, w0
    // 0x694944: branchIfSmi(r16, 0x694ab0)
    //     0x694944: tbz             w16, #0, #0x694ab0
    // 0x694948: r16 = LoadClassIdInstr(r1)
    //     0x694948: ldur            x16, [x1, #-1]
    //     0x69494c: ubfx            x16, x16, #0xc, #0x14
    // 0x694950: cmp             x16, #0x3c
    // 0x694954: b.ne            #0x694ab0
    // 0x694958: r16 = LoadClassIdInstr(r0)
    //     0x694958: ldur            x16, [x0, #-1]
    //     0x69495c: ubfx            x16, x16, #0xc, #0x14
    // 0x694960: cmp             x16, #0x3c
    // 0x694964: b.ne            #0x694ab0
    // 0x694968: LoadField: r16 = r1->field_7
    //     0x694968: ldur            x16, [x1, #7]
    // 0x69496c: LoadField: r17 = r0->field_7
    //     0x69496c: ldur            x17, [x0, #7]
    // 0x694970: cmp             x16, x17
    // 0x694974: b.ne            #0x694ab0
    // 0x694978: ldur            x0, [fp, #-0x18]
    // 0x69497c: LoadField: r1 = r0->field_1b
    //     0x69497c: ldur            w1, [x0, #0x1b]
    // 0x694980: DecompressPointer r1
    //     0x694980: add             x1, x1, HEAP, lsl #32
    // 0x694984: r16 = Sentinel
    //     0x694984: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x694988: cmp             w1, w16
    // 0x69498c: b.ne            #0x6949a4
    // 0x694990: r16 = "toolbarWidth"
    //     0x694990: add             x16, PP, #0x51, lsl #12  ; [pp+0x51008] "toolbarWidth"
    //     0x694994: ldr             x16, [x16, #8]
    // 0x694998: SaveReg r16
    //     0x694998: str             x16, [SP, #-8]!
    // 0x69499c: r0 = _throwLocalNotInitialized()
    //     0x69499c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x6949a0: add             SP, SP, #8
    // 0x6949a4: ldur            x0, [fp, #-0x18]
    // 0x6949a8: ldur            x1, [fp, #-0x20]
    // 0x6949ac: LoadField: r2 = r0->field_1b
    //     0x6949ac: ldur            w2, [x0, #0x1b]
    // 0x6949b0: DecompressPointer r2
    //     0x6949b0: add             x2, x2, HEAP, lsl #32
    // 0x6949b4: stur            x2, [fp, #-0x10]
    // 0x6949b8: LoadField: d0 = r2->field_7
    //     0x6949b8: ldur            d0, [x2, #7]
    // 0x6949bc: stur            d0, [fp, #-0x30]
    // 0x6949c0: r0 = Offset()
    //     0x6949c0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6949c4: ldur            d0, [fp, #-0x30]
    // 0x6949c8: StoreField: r0->field_7 = d0
    //     0x6949c8: stur            d0, [x0, #7]
    // 0x6949cc: d0 = 0.000000
    //     0x6949cc: eor             v0.16b, v0.16b, v0.16b
    // 0x6949d0: StoreField: r0->field_f = d0
    //     0x6949d0: stur            d0, [x0, #0xf]
    // 0x6949d4: ldur            x1, [fp, #-0x20]
    // 0x6949d8: StoreField: r1->field_7 = r0
    //     0x6949d8: stur            w0, [x1, #7]
    //     0x6949dc: ldurb           w16, [x1, #-1]
    //     0x6949e0: ldurb           w17, [x0, #-1]
    //     0x6949e4: and             x16, x17, x16, lsr #2
    //     0x6949e8: tst             x16, HEAP, lsr #32
    //     0x6949ec: b.eq            #0x6949f4
    //     0x6949f0: bl              #0xd6826c
    // 0x6949f4: r0 = true
    //     0x6949f4: add             x0, NULL, #0x20  ; true
    // 0x6949f8: StoreField: r1->field_17 = r0
    //     0x6949f8: stur            w0, [x1, #0x17]
    // 0x6949fc: ldur            x1, [fp, #-0x10]
    // 0x694a00: r16 = Sentinel
    //     0x694a00: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x694a04: cmp             w1, w16
    // 0x694a08: b.ne            #0x694a20
    // 0x694a0c: r16 = "toolbarWidth"
    //     0x694a0c: add             x16, PP, #0x51, lsl #12  ; [pp+0x51008] "toolbarWidth"
    //     0x694a10: ldr             x16, [x16, #8]
    // 0x694a14: SaveReg r16
    //     0x694a14: str             x16, [SP, #-8]!
    // 0x694a18: r0 = _throwLocalNotInitialized()
    //     0x694a18: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x694a1c: add             SP, SP, #8
    // 0x694a20: ldr             x2, [fp, #0x10]
    // 0x694a24: ldur            x1, [fp, #-0x18]
    // 0x694a28: LoadField: r0 = r1->field_1b
    //     0x694a28: ldur            w0, [x1, #0x1b]
    // 0x694a2c: DecompressPointer r0
    //     0x694a2c: add             x0, x0, HEAP, lsl #32
    // 0x694a30: LoadField: r3 = r2->field_8b
    //     0x694a30: ldur            w3, [x2, #0x8b]
    // 0x694a34: DecompressPointer r3
    //     0x694a34: add             x3, x3, HEAP, lsl #32
    // 0x694a38: cmp             w3, NULL
    // 0x694a3c: b.eq            #0x694e64
    // 0x694a40: LoadField: r4 = r3->field_57
    //     0x694a40: ldur            w4, [x3, #0x57]
    // 0x694a44: DecompressPointer r4
    //     0x694a44: add             x4, x4, HEAP, lsl #32
    // 0x694a48: cmp             w4, NULL
    // 0x694a4c: b.eq            #0x694e68
    // 0x694a50: LoadField: d0 = r4->field_7
    //     0x694a50: ldur            d0, [x4, #7]
    // 0x694a54: cmp             w0, NULL
    // 0x694a58: b.eq            #0x694e6c
    // 0x694a5c: LoadField: d1 = r0->field_7
    //     0x694a5c: ldur            d1, [x0, #7]
    // 0x694a60: fadd            d2, d1, d0
    // 0x694a64: r0 = inline_Allocate_Double()
    //     0x694a64: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x694a68: add             x0, x0, #0x10
    //     0x694a6c: cmp             x3, x0
    //     0x694a70: b.ls            #0x694e70
    //     0x694a74: str             x0, [THR, #0x60]  ; THR::top
    //     0x694a78: sub             x0, x0, #0xf
    //     0x694a7c: mov             x3, #0xd108
    //     0x694a80: movk            x3, #3, lsl #16
    //     0x694a84: stur            x3, [x0, #-1]
    // 0x694a88: StoreField: r0->field_7 = d2
    //     0x694a88: stur            d2, [x0, #7]
    // 0x694a8c: StoreField: r1->field_1b = r0
    //     0x694a8c: stur            w0, [x1, #0x1b]
    //     0x694a90: ldurb           w16, [x1, #-1]
    //     0x694a94: ldurb           w17, [x0, #-1]
    //     0x694a98: and             x16, x17, x16, lsr #2
    //     0x694a9c: tst             x16, HEAP, lsr #32
    //     0x694aa0: b.eq            #0x694aa8
    //     0x694aa4: bl              #0xd6826c
    // 0x694aa8: mov             v0.16b, v2.16b
    // 0x694aac: b               #0x694be8
    // 0x694ab0: ldur            x1, [fp, #-0x18]
    // 0x694ab4: d0 = 0.000000
    //     0x694ab4: eor             v0.16b, v0.16b, v0.16b
    // 0x694ab8: LoadField: r0 = r1->field_1b
    //     0x694ab8: ldur            w0, [x1, #0x1b]
    // 0x694abc: DecompressPointer r0
    //     0x694abc: add             x0, x0, HEAP, lsl #32
    // 0x694ac0: r16 = Sentinel
    //     0x694ac0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x694ac4: cmp             w0, w16
    // 0x694ac8: b.ne            #0x694ae0
    // 0x694acc: r16 = "toolbarWidth"
    //     0x694acc: add             x16, PP, #0x51, lsl #12  ; [pp+0x51008] "toolbarWidth"
    //     0x694ad0: ldr             x16, [x16, #8]
    // 0x694ad4: SaveReg r16
    //     0x694ad4: str             x16, [SP, #-8]!
    // 0x694ad8: r0 = _throwLocalNotInitialized()
    //     0x694ad8: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x694adc: add             SP, SP, #8
    // 0x694ae0: ldur            x0, [fp, #-0x18]
    // 0x694ae4: ldur            x1, [fp, #-8]
    // 0x694ae8: LoadField: r2 = r0->field_1b
    //     0x694ae8: ldur            w2, [x0, #0x1b]
    // 0x694aec: DecompressPointer r2
    //     0x694aec: add             x2, x2, HEAP, lsl #32
    // 0x694af0: stur            x2, [fp, #-0x10]
    // 0x694af4: LoadField: d0 = r2->field_7
    //     0x694af4: ldur            d0, [x2, #7]
    // 0x694af8: stur            d0, [fp, #-0x30]
    // 0x694afc: r0 = Offset()
    //     0x694afc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x694b00: ldur            d0, [fp, #-0x30]
    // 0x694b04: StoreField: r0->field_7 = d0
    //     0x694b04: stur            d0, [x0, #7]
    // 0x694b08: d0 = 0.000000
    //     0x694b08: eor             v0.16b, v0.16b, v0.16b
    // 0x694b0c: StoreField: r0->field_f = d0
    //     0x694b0c: stur            d0, [x0, #0xf]
    // 0x694b10: ldur            x1, [fp, #-8]
    // 0x694b14: StoreField: r1->field_7 = r0
    //     0x694b14: stur            w0, [x1, #7]
    //     0x694b18: ldurb           w16, [x1, #-1]
    //     0x694b1c: ldurb           w17, [x0, #-1]
    //     0x694b20: and             x16, x17, x16, lsr #2
    //     0x694b24: tst             x16, HEAP, lsr #32
    //     0x694b28: b.eq            #0x694b30
    //     0x694b2c: bl              #0xd6826c
    // 0x694b30: r0 = true
    //     0x694b30: add             x0, NULL, #0x20  ; true
    // 0x694b34: StoreField: r1->field_17 = r0
    //     0x694b34: stur            w0, [x1, #0x17]
    // 0x694b38: ldur            x1, [fp, #-0x10]
    // 0x694b3c: r16 = Sentinel
    //     0x694b3c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x694b40: cmp             w1, w16
    // 0x694b44: b.ne            #0x694b5c
    // 0x694b48: r16 = "toolbarWidth"
    //     0x694b48: add             x16, PP, #0x51, lsl #12  ; [pp+0x51008] "toolbarWidth"
    //     0x694b4c: ldr             x16, [x16, #8]
    // 0x694b50: SaveReg r16
    //     0x694b50: str             x16, [SP, #-8]!
    // 0x694b54: r0 = _throwLocalNotInitialized()
    //     0x694b54: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x694b58: add             SP, SP, #8
    // 0x694b5c: ldr             x2, [fp, #0x10]
    // 0x694b60: ldur            x1, [fp, #-0x18]
    // 0x694b64: LoadField: r0 = r1->field_1b
    //     0x694b64: ldur            w0, [x1, #0x1b]
    // 0x694b68: DecompressPointer r0
    //     0x694b68: add             x0, x0, HEAP, lsl #32
    // 0x694b6c: LoadField: r3 = r2->field_87
    //     0x694b6c: ldur            w3, [x2, #0x87]
    // 0x694b70: DecompressPointer r3
    //     0x694b70: add             x3, x3, HEAP, lsl #32
    // 0x694b74: cmp             w3, NULL
    // 0x694b78: b.eq            #0x694e88
    // 0x694b7c: LoadField: r4 = r3->field_57
    //     0x694b7c: ldur            w4, [x3, #0x57]
    // 0x694b80: DecompressPointer r4
    //     0x694b80: add             x4, x4, HEAP, lsl #32
    // 0x694b84: cmp             w4, NULL
    // 0x694b88: b.eq            #0x694e8c
    // 0x694b8c: LoadField: d0 = r4->field_7
    //     0x694b8c: ldur            d0, [x4, #7]
    // 0x694b90: cmp             w0, NULL
    // 0x694b94: b.eq            #0x694e90
    // 0x694b98: LoadField: d1 = r0->field_7
    //     0x694b98: ldur            d1, [x0, #7]
    // 0x694b9c: fadd            d2, d1, d0
    // 0x694ba0: r0 = inline_Allocate_Double()
    //     0x694ba0: ldp             x0, x3, [THR, #0x60]  ; THR::top
    //     0x694ba4: add             x0, x0, #0x10
    //     0x694ba8: cmp             x3, x0
    //     0x694bac: b.ls            #0x694e94
    //     0x694bb0: str             x0, [THR, #0x60]  ; THR::top
    //     0x694bb4: sub             x0, x0, #0xf
    //     0x694bb8: mov             x3, #0xd108
    //     0x694bbc: movk            x3, #3, lsl #16
    //     0x694bc0: stur            x3, [x0, #-1]
    // 0x694bc4: StoreField: r0->field_7 = d2
    //     0x694bc4: stur            d2, [x0, #7]
    // 0x694bc8: StoreField: r1->field_1b = r0
    //     0x694bc8: stur            w0, [x1, #0x1b]
    //     0x694bcc: ldurb           w16, [x1, #-1]
    //     0x694bd0: ldurb           w17, [x0, #-1]
    //     0x694bd4: and             x16, x17, x16, lsr #2
    //     0x694bd8: tst             x16, HEAP, lsr #32
    //     0x694bdc: b.eq            #0x694be4
    //     0x694be0: bl              #0xd6826c
    // 0x694be4: mov             v0.16b, v2.16b
    // 0x694be8: LoadField: r0 = r2->field_73
    //     0x694be8: ldur            x0, [x2, #0x73]
    // 0x694bec: cmp             x0, #0
    // 0x694bf0: b.le            #0x694c08
    // 0x694bf4: ldur            x3, [fp, #-0x28]
    // 0x694bf8: r0 = true
    //     0x694bf8: add             x0, NULL, #0x20  ; true
    // 0x694bfc: r4 = Instance_Offset
    //     0x694bfc: ldr             x4, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x694c00: StoreField: r3->field_7 = r4
    //     0x694c00: stur            w4, [x3, #7]
    // 0x694c04: StoreField: r3->field_17 = r0
    //     0x694c04: stur            w0, [x3, #0x17]
    // 0x694c08: mov             x4, x2
    // 0x694c0c: mov             x3, x1
    // 0x694c10: b               #0x694cb0
    // 0x694c14: ldr             x2, [fp, #0x10]
    // 0x694c18: mov             x1, x3
    // 0x694c1c: LoadField: r0 = r1->field_1b
    //     0x694c1c: ldur            w0, [x1, #0x1b]
    // 0x694c20: DecompressPointer r0
    //     0x694c20: add             x0, x0, HEAP, lsl #32
    // 0x694c24: r16 = Sentinel
    //     0x694c24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x694c28: cmp             w0, w16
    // 0x694c2c: b.ne            #0x694c44
    // 0x694c30: r16 = "toolbarWidth"
    //     0x694c30: add             x16, PP, #0x51, lsl #12  ; [pp+0x51008] "toolbarWidth"
    //     0x694c34: ldr             x16, [x16, #8]
    // 0x694c38: SaveReg r16
    //     0x694c38: str             x16, [SP, #-8]!
    // 0x694c3c: r0 = _throwLocalNotInitialized()
    //     0x694c3c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x694c40: add             SP, SP, #8
    // 0x694c44: ldr             x4, [fp, #0x10]
    // 0x694c48: ldur            x3, [fp, #-0x18]
    // 0x694c4c: LoadField: r0 = r3->field_1b
    //     0x694c4c: ldur            w0, [x3, #0x1b]
    // 0x694c50: DecompressPointer r0
    //     0x694c50: add             x0, x0, HEAP, lsl #32
    // 0x694c54: LoadField: d0 = r4->field_7b
    //     0x694c54: ldur            d0, [x4, #0x7b]
    // 0x694c58: cmp             w0, NULL
    // 0x694c5c: b.eq            #0x694eac
    // 0x694c60: LoadField: d1 = r0->field_7
    //     0x694c60: ldur            d1, [x0, #7]
    // 0x694c64: fsub            d2, d1, d0
    // 0x694c68: r0 = inline_Allocate_Double()
    //     0x694c68: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x694c6c: add             x0, x0, #0x10
    //     0x694c70: cmp             x1, x0
    //     0x694c74: b.ls            #0x694eb0
    //     0x694c78: str             x0, [THR, #0x60]  ; THR::top
    //     0x694c7c: sub             x0, x0, #0xf
    //     0x694c80: mov             x1, #0xd108
    //     0x694c84: movk            x1, #3, lsl #16
    //     0x694c88: stur            x1, [x0, #-1]
    // 0x694c8c: StoreField: r0->field_7 = d2
    //     0x694c8c: stur            d2, [x0, #7]
    // 0x694c90: StoreField: r3->field_1b = r0
    //     0x694c90: stur            w0, [x3, #0x1b]
    //     0x694c94: ldurb           w16, [x3, #-1]
    //     0x694c98: ldurb           w17, [x0, #-1]
    //     0x694c9c: and             x16, x17, x16, lsr #2
    //     0x694ca0: tst             x16, HEAP, lsr #32
    //     0x694ca4: b.eq            #0x694cac
    //     0x694ca8: bl              #0xd682ac
    // 0x694cac: mov             v0.16b, v2.16b
    // 0x694cb0: stur            d0, [fp, #-0x30]
    // 0x694cb4: LoadField: r5 = r4->field_27
    //     0x694cb4: ldur            w5, [x4, #0x27]
    // 0x694cb8: DecompressPointer r5
    //     0x694cb8: add             x5, x5, HEAP, lsl #32
    // 0x694cbc: stur            x5, [fp, #-8]
    // 0x694cc0: cmp             w5, NULL
    // 0x694cc4: b.eq            #0x694dec
    // 0x694cc8: mov             x0, x5
    // 0x694ccc: r2 = Null
    //     0x694ccc: mov             x2, NULL
    // 0x694cd0: r1 = Null
    //     0x694cd0: mov             x1, NULL
    // 0x694cd4: r4 = LoadClassIdInstr(r0)
    //     0x694cd4: ldur            x4, [x0, #-1]
    //     0x694cd8: ubfx            x4, x4, #0xc, #0x14
    // 0x694cdc: sub             x4, x4, #0x80d
    // 0x694ce0: cmp             x4, #1
    // 0x694ce4: b.ls            #0x694cfc
    // 0x694ce8: r8 = BoxConstraints
    //     0x694ce8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x694cec: ldr             x8, [x8, #0x1d0]
    // 0x694cf0: r3 = Null
    //     0x694cf0: add             x3, PP, #0x51, lsl #12  ; [pp+0x51010] Null
    //     0x694cf4: ldr             x3, [x3, #0x10]
    // 0x694cf8: r0 = BoxConstraints()
    //     0x694cf8: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x694cfc: ldur            x0, [fp, #-0x18]
    // 0x694d00: LoadField: r1 = r0->field_1f
    //     0x694d00: ldur            w1, [x0, #0x1f]
    // 0x694d04: DecompressPointer r1
    //     0x694d04: add             x1, x1, HEAP, lsl #32
    // 0x694d08: r16 = Sentinel
    //     0x694d08: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x694d0c: cmp             w1, w16
    // 0x694d10: b.ne            #0x694d20
    // 0x694d14: r1 = 0.000000
    //     0x694d14: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x694d18: StoreField: r0->field_1f = r1
    //     0x694d18: stur            w1, [x0, #0x1f]
    // 0x694d1c: r1 = 0.000000
    //     0x694d1c: ldr             x1, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x694d20: ldr             x0, [fp, #0x10]
    // 0x694d24: ldur            d0, [fp, #-0x30]
    // 0x694d28: stur            x1, [fp, #-0x10]
    // 0x694d2c: r0 = Size()
    //     0x694d2c: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x694d30: ldur            d0, [fp, #-0x30]
    // 0x694d34: StoreField: r0->field_7 = d0
    //     0x694d34: stur            d0, [x0, #7]
    // 0x694d38: ldur            x1, [fp, #-0x10]
    // 0x694d3c: LoadField: d0 = r1->field_7
    //     0x694d3c: ldur            d0, [x1, #7]
    // 0x694d40: StoreField: r0->field_f = d0
    //     0x694d40: stur            d0, [x0, #0xf]
    // 0x694d44: ldur            x16, [fp, #-8]
    // 0x694d48: stp             x0, x16, [SP, #-0x10]!
    // 0x694d4c: r0 = constrain()
    //     0x694d4c: bl              #0x62e4a8  ; [package:flutter/src/rendering/box.dart] BoxConstraints::constrain
    // 0x694d50: add             SP, SP, #0x10
    // 0x694d54: ldr             x1, [fp, #0x10]
    // 0x694d58: StoreField: r1->field_57 = r0
    //     0x694d58: stur            w0, [x1, #0x57]
    //     0x694d5c: ldurb           w16, [x1, #-1]
    //     0x694d60: ldurb           w17, [x0, #-1]
    //     0x694d64: and             x16, x17, x16, lsr #2
    //     0x694d68: tst             x16, HEAP, lsr #32
    //     0x694d6c: b.eq            #0x694d74
    //     0x694d70: bl              #0xd6826c
    // 0x694d74: r0 = Null
    //     0x694d74: mov             x0, NULL
    // 0x694d78: LeaveFrame
    //     0x694d78: mov             SP, fp
    //     0x694d7c: ldp             fp, lr, [SP], #0x10
    // 0x694d80: ret
    //     0x694d80: ret             
    // 0x694d84: r0 = StateError()
    //     0x694d84: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x694d88: mov             x1, x0
    // 0x694d8c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x694d8c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x694d90: ldr             x0, [x0, #0x1e8]
    // 0x694d94: StoreField: r1->field_b = r0
    //     0x694d94: stur            w0, [x1, #0xb]
    // 0x694d98: mov             x0, x1
    // 0x694d9c: r0 = Throw()
    //     0x694d9c: bl              #0xd67e38  ; ThrowStub
    // 0x694da0: brk             #0
    // 0x694da4: r0 = StateError()
    //     0x694da4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x694da8: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x694da8: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x694dac: ldr             x7, [x7, #0x1e8]
    // 0x694db0: StoreField: r0->field_b = r7
    //     0x694db0: stur            w7, [x0, #0xb]
    // 0x694db4: r0 = Throw()
    //     0x694db4: bl              #0xd67e38  ; ThrowStub
    // 0x694db8: brk             #0
    // 0x694dbc: r0 = StateError()
    //     0x694dbc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x694dc0: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x694dc0: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x694dc4: ldr             x6, [x6, #0x1e8]
    // 0x694dc8: StoreField: r0->field_b = r6
    //     0x694dc8: stur            w6, [x0, #0xb]
    // 0x694dcc: r0 = Throw()
    //     0x694dcc: bl              #0xd67e38  ; ThrowStub
    // 0x694dd0: brk             #0
    // 0x694dd4: r0 = StateError()
    //     0x694dd4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x694dd8: r6 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x694dd8: add             x6, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x694ddc: ldr             x6, [x6, #0x1e8]
    // 0x694de0: StoreField: r0->field_b = r6
    //     0x694de0: stur            w6, [x0, #0xb]
    // 0x694de4: r0 = Throw()
    //     0x694de4: bl              #0xd67e38  ; ThrowStub
    // 0x694de8: brk             #0
    // 0x694dec: r0 = StateError()
    //     0x694dec: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x694df0: mov             x1, x0
    // 0x694df4: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x694df4: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x694df8: ldr             x0, [x0, #0x1e8]
    // 0x694dfc: StoreField: r1->field_b = r0
    //     0x694dfc: stur            w0, [x1, #0xb]
    // 0x694e00: mov             x0, x1
    // 0x694e04: r0 = Throw()
    //     0x694e04: bl              #0xd67e38  ; ThrowStub
    // 0x694e08: brk             #0
    // 0x694e0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x694e0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x694e10: b               #0x694434
    // 0x694e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e20: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e20: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e28: r0 = NullCastErrorSharedWithFPURegs()
    //     0x694e28: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x694e2c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x694e2c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x694e30: SaveReg d2
    //     0x694e30: str             q2, [SP, #-0x10]!
    // 0x694e34: SaveReg r3
    //     0x694e34: str             x3, [SP, #-8]!
    // 0x694e38: r0 = AllocateDouble()
    //     0x694e38: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x694e3c: RestoreReg r3
    //     0x694e3c: ldr             x3, [SP], #8
    // 0x694e40: RestoreReg d2
    //     0x694e40: ldr             q2, [SP], #0x10
    // 0x694e44: b               #0x694778
    // 0x694e48: r0 = NullErrorSharedWithoutFPURegs()
    //     0x694e48: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x694e4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e6c: r0 = NullErrorSharedWithFPURegs()
    //     0x694e6c: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x694e70: SaveReg d2
    //     0x694e70: str             q2, [SP, #-0x10]!
    // 0x694e74: stp             x1, x2, [SP, #-0x10]!
    // 0x694e78: r0 = AllocateDouble()
    //     0x694e78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x694e7c: ldp             x1, x2, [SP], #0x10
    // 0x694e80: RestoreReg d2
    //     0x694e80: ldr             q2, [SP], #0x10
    // 0x694e84: b               #0x694a88
    // 0x694e88: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e88: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x694e8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x694e90: r0 = NullErrorSharedWithFPURegs()
    //     0x694e90: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x694e94: SaveReg d2
    //     0x694e94: str             q2, [SP, #-0x10]!
    // 0x694e98: stp             x1, x2, [SP, #-0x10]!
    // 0x694e9c: r0 = AllocateDouble()
    //     0x694e9c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x694ea0: ldp             x1, x2, [SP], #0x10
    // 0x694ea4: RestoreReg d2
    //     0x694ea4: ldr             q2, [SP], #0x10
    // 0x694ea8: b               #0x694bc4
    // 0x694eac: r0 = NullErrorSharedWithFPURegs()
    //     0x694eac: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x694eb0: SaveReg d2
    //     0x694eb0: str             q2, [SP, #-0x10]!
    // 0x694eb4: stp             x3, x4, [SP, #-0x10]!
    // 0x694eb8: r0 = AllocateDouble()
    //     0x694eb8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x694ebc: ldp             x3, x4, [SP], #0x10
    // 0x694ec0: RestoreReg d2
    //     0x694ec0: ldr             q2, [SP], #0x10
    // 0x694ec4: b               #0x694c8c
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x694ec8, size: 0xa78
    // 0x694ec8: EnterFrame
    //     0x694ec8: stp             fp, lr, [SP, #-0x10]!
    //     0x694ecc: mov             fp, SP
    // 0x694ed0: AllocStack(0x40)
    //     0x694ed0: sub             SP, SP, #0x40
    // 0x694ed4: SetupParameters()
    //     0x694ed4: ldr             x0, [fp, #0x18]
    //     0x694ed8: ldur            w3, [x0, #0x17]
    //     0x694edc: add             x3, x3, HEAP, lsl #32
    //     0x694ee0: stur            x3, [fp, #-0x10]
    // 0x694ee4: CheckStackOverflow
    //     0x694ee4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x694ee8: cmp             SP, x16
    //     0x694eec: b.ls            #0x695834
    // 0x694ef0: LoadField: r0 = r3->field_2b
    //     0x694ef0: ldur            w0, [x3, #0x2b]
    // 0x694ef4: DecompressPointer r0
    //     0x694ef4: add             x0, x0, HEAP, lsl #32
    // 0x694ef8: cmp             w0, NULL
    // 0x694efc: b.eq            #0x69583c
    // 0x694f00: r1 = LoadInt32Instr(r0)
    //     0x694f00: sbfx            x1, x0, #1, #0x1f
    //     0x694f04: tbz             w0, #0, #0x694f0c
    //     0x694f08: ldur            x1, [x0, #7]
    // 0x694f0c: add             x4, x1, #1
    // 0x694f10: stur            x4, [fp, #-8]
    // 0x694f14: r0 = BoxInt64Instr(r4)
    //     0x694f14: sbfiz           x0, x4, #1, #0x1f
    //     0x694f18: cmp             x4, x0, asr #1
    //     0x694f1c: b.eq            #0x694f28
    //     0x694f20: bl              #0xd69bb8
    //     0x694f24: stur            x4, [x0, #7]
    // 0x694f28: StoreField: r3->field_2b = r0
    //     0x694f28: stur            w0, [x3, #0x2b]
    //     0x694f2c: tbz             w0, #0, #0x694f48
    //     0x694f30: ldurb           w16, [x3, #-1]
    //     0x694f34: ldurb           w17, [x0, #-1]
    //     0x694f38: and             x16, x17, x16, lsr #2
    //     0x694f3c: tst             x16, HEAP, lsr #32
    //     0x694f40: b.eq            #0x694f48
    //     0x694f44: bl              #0xd682ac
    // 0x694f48: ldr             x0, [fp, #0x10]
    // 0x694f4c: r2 = Null
    //     0x694f4c: mov             x2, NULL
    // 0x694f50: r1 = Null
    //     0x694f50: mov             x1, NULL
    // 0x694f54: r4 = LoadClassIdInstr(r0)
    //     0x694f54: ldur            x4, [x0, #-1]
    //     0x694f58: ubfx            x4, x4, #0xc, #0x14
    // 0x694f5c: sub             x4, x4, #0x965
    // 0x694f60: cmp             x4, #0x8b
    // 0x694f64: b.ls            #0x694f7c
    // 0x694f68: r8 = RenderBox
    //     0x694f68: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x694f6c: ldr             x8, [x8, #0xfa0]
    // 0x694f70: r3 = Null
    //     0x694f70: add             x3, PP, #0x51, lsl #12  ; [pp+0x51020] Null
    //     0x694f74: ldr             x3, [x3, #0x20]
    // 0x694f78: r0 = RenderBox()
    //     0x694f78: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x694f7c: ldr             x3, [fp, #0x10]
    // 0x694f80: LoadField: r4 = r3->field_17
    //     0x694f80: ldur            w4, [x3, #0x17]
    // 0x694f84: DecompressPointer r4
    //     0x694f84: add             x4, x4, HEAP, lsl #32
    // 0x694f88: stur            x4, [fp, #-0x18]
    // 0x694f8c: cmp             w4, NULL
    // 0x694f90: b.eq            #0x695840
    // 0x694f94: mov             x0, x4
    // 0x694f98: r2 = Null
    //     0x694f98: mov             x2, NULL
    // 0x694f9c: r1 = Null
    //     0x694f9c: mov             x1, NULL
    // 0x694fa0: r4 = LoadClassIdInstr(r0)
    //     0x694fa0: ldur            x4, [x0, #-1]
    //     0x694fa4: ubfx            x4, x4, #0xc, #0x14
    // 0x694fa8: cmp             x4, #0x804
    // 0x694fac: b.eq            #0x694fc4
    // 0x694fb0: r8 = ToolbarItemsParentData<RenderBox>
    //     0x694fb0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50528] Type: ToolbarItemsParentData<RenderBox>
    //     0x694fb4: ldr             x8, [x8, #0x528]
    // 0x694fb8: r3 = Null
    //     0x694fb8: add             x3, PP, #0x51, lsl #12  ; [pp+0x51030] Null
    //     0x694fbc: ldr             x3, [x3, #0x30]
    // 0x694fc0: r0 = DefaultTypeTest()
    //     0x694fc0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x694fc4: ldur            x3, [fp, #-0x18]
    // 0x694fc8: r0 = false
    //     0x694fc8: add             x0, NULL, #0x30  ; false
    // 0x694fcc: StoreField: r3->field_17 = r0
    //     0x694fcc: stur            w0, [x3, #0x17]
    // 0x694fd0: ldur            x4, [fp, #-0x10]
    // 0x694fd4: LoadField: r0 = r4->field_f
    //     0x694fd4: ldur            w0, [x4, #0xf]
    // 0x694fd8: DecompressPointer r0
    //     0x694fd8: add             x0, x0, HEAP, lsl #32
    // 0x694fdc: LoadField: r1 = r0->field_83
    //     0x694fdc: ldur            w1, [x0, #0x83]
    // 0x694fe0: DecompressPointer r1
    //     0x694fe0: add             x1, x1, HEAP, lsl #32
    // 0x694fe4: ldr             x5, [fp, #0x10]
    // 0x694fe8: cmp             w5, w1
    // 0x694fec: b.eq            #0x695038
    // 0x694ff0: LoadField: r1 = r0->field_87
    //     0x694ff0: ldur            w1, [x0, #0x87]
    // 0x694ff4: DecompressPointer r1
    //     0x694ff4: add             x1, x1, HEAP, lsl #32
    // 0x694ff8: cmp             w5, w1
    // 0x694ffc: b.eq            #0x695038
    // 0x695000: LoadField: r2 = r0->field_8b
    //     0x695000: ldur            w2, [x0, #0x8b]
    // 0x695004: DecompressPointer r2
    //     0x695004: add             x2, x2, HEAP, lsl #32
    // 0x695008: cmp             w5, w2
    // 0x69500c: b.eq            #0x695038
    // 0x695010: LoadField: r2 = r4->field_27
    //     0x695010: ldur            w2, [x4, #0x27]
    // 0x695014: DecompressPointer r2
    //     0x695014: add             x2, x2, HEAP, lsl #32
    // 0x695018: LoadField: r6 = r0->field_73
    //     0x695018: ldur            x6, [x0, #0x73]
    // 0x69501c: cmp             w2, NULL
    // 0x695020: b.eq            #0x695844
    // 0x695024: r7 = LoadInt32Instr(r2)
    //     0x695024: sbfx            x7, x2, #1, #0x1f
    //     0x695028: tbz             w2, #0, #0x695030
    //     0x69502c: ldur            x7, [x2, #7]
    // 0x695030: cmp             x7, x6
    // 0x695034: b.le            #0x695048
    // 0x695038: r0 = Null
    //     0x695038: mov             x0, NULL
    // 0x69503c: LeaveFrame
    //     0x69503c: mov             SP, fp
    //     0x695040: ldp             fp, lr, [SP], #0x10
    // 0x695044: ret
    //     0x695044: ret             
    // 0x695048: cbnz            w2, #0x6950b4
    // 0x69504c: ldur            x6, [fp, #-8]
    // 0x695050: LoadField: r7 = r0->field_5f
    //     0x695050: ldur            x7, [x0, #0x5f]
    // 0x695054: sub             x8, x7, #1
    // 0x695058: cmp             x6, x8
    // 0x69505c: b.ne            #0x695068
    // 0x695060: d0 = 0.000000
    //     0x695060: eor             v0.16b, v0.16b, v0.16b
    // 0x695064: b               #0x695084
    // 0x695068: cmp             w1, NULL
    // 0x69506c: b.eq            #0x695848
    // 0x695070: LoadField: r6 = r1->field_57
    //     0x695070: ldur            w6, [x1, #0x57]
    // 0x695074: DecompressPointer r6
    //     0x695074: add             x6, x6, HEAP, lsl #32
    // 0x695078: cmp             w6, NULL
    // 0x69507c: b.eq            #0x69584c
    // 0x695080: LoadField: d0 = r6->field_7
    //     0x695080: ldur            d0, [x6, #7]
    // 0x695084: r1 = inline_Allocate_Double()
    //     0x695084: ldp             x1, x6, [THR, #0x60]  ; THR::top
    //     0x695088: add             x1, x1, #0x10
    //     0x69508c: cmp             x6, x1
    //     0x695090: b.ls            #0x695850
    //     0x695094: str             x1, [THR, #0x60]  ; THR::top
    //     0x695098: sub             x1, x1, #0xf
    //     0x69509c: mov             x6, #0xd108
    //     0x6950a0: movk            x6, #3, lsl #16
    //     0x6950a4: stur            x6, [x1, #-1]
    // 0x6950a8: StoreField: r1->field_7 = d0
    //     0x6950a8: stur            d0, [x1, #7]
    // 0x6950ac: mov             x6, x1
    // 0x6950b0: b               #0x6950c0
    // 0x6950b4: LoadField: r1 = r4->field_13
    //     0x6950b4: ldur            w1, [x4, #0x13]
    // 0x6950b8: DecompressPointer r1
    //     0x6950b8: add             x1, x1, HEAP, lsl #32
    // 0x6950bc: mov             x6, x1
    // 0x6950c0: stur            x6, [fp, #-0x28]
    // 0x6950c4: cbnz            w2, #0x695154
    // 0x6950c8: LoadField: r7 = r0->field_27
    //     0x6950c8: ldur            w7, [x0, #0x27]
    // 0x6950cc: DecompressPointer r7
    //     0x6950cc: add             x7, x7, HEAP, lsl #32
    // 0x6950d0: stur            x7, [fp, #-0x20]
    // 0x6950d4: cmp             w7, NULL
    // 0x6950d8: b.eq            #0x6957cc
    // 0x6950dc: r8 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6950dc: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6950e0: ldr             x8, [x8, #0x1e8]
    // 0x6950e4: mov             x0, x7
    // 0x6950e8: r2 = Null
    //     0x6950e8: mov             x2, NULL
    // 0x6950ec: r1 = Null
    //     0x6950ec: mov             x1, NULL
    // 0x6950f0: r4 = LoadClassIdInstr(r0)
    //     0x6950f0: ldur            x4, [x0, #-1]
    //     0x6950f4: ubfx            x4, x4, #0xc, #0x14
    // 0x6950f8: sub             x4, x4, #0x80d
    // 0x6950fc: cmp             x4, #1
    // 0x695100: b.ls            #0x695118
    // 0x695104: r8 = BoxConstraints
    //     0x695104: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x695108: ldr             x8, [x8, #0x1d0]
    // 0x69510c: r3 = Null
    //     0x69510c: add             x3, PP, #0x51, lsl #12  ; [pp+0x51040] Null
    //     0x695110: ldr             x3, [x3, #0x40]
    // 0x695114: r0 = BoxConstraints()
    //     0x695114: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x695118: ldur            x0, [fp, #-0x20]
    // 0x69511c: LoadField: d0 = r0->field_f
    //     0x69511c: ldur            d0, [x0, #0xf]
    // 0x695120: r0 = inline_Allocate_Double()
    //     0x695120: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x695124: add             x0, x0, #0x10
    //     0x695128: cmp             x1, x0
    //     0x69512c: b.ls            #0x69587c
    //     0x695130: str             x0, [THR, #0x60]  ; THR::top
    //     0x695134: sub             x0, x0, #0xf
    //     0x695138: mov             x1, #0xd108
    //     0x69513c: movk            x1, #3, lsl #16
    //     0x695140: stur            x1, [x0, #-1]
    // 0x695144: StoreField: r0->field_7 = d0
    //     0x695144: stur            d0, [x0, #7]
    // 0x695148: mov             x1, x0
    // 0x69514c: ldur            x3, [fp, #-0x10]
    // 0x695150: b               #0x695190
    // 0x695154: mov             x0, x4
    // 0x695158: LoadField: r1 = r0->field_23
    //     0x695158: ldur            w1, [x0, #0x23]
    // 0x69515c: DecompressPointer r1
    //     0x69515c: add             x1, x1, HEAP, lsl #32
    // 0x695160: r16 = Sentinel
    //     0x695160: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x695164: cmp             w1, w16
    // 0x695168: b.ne            #0x695180
    // 0x69516c: r16 = "firstPageWidth"
    //     0x69516c: add             x16, PP, #0x51, lsl #12  ; [pp+0x51050] "firstPageWidth"
    //     0x695170: ldr             x16, [x16, #0x50]
    // 0x695174: SaveReg r16
    //     0x695174: str             x16, [SP, #-8]!
    // 0x695178: r0 = _throwLocalNotInitialized()
    //     0x695178: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x69517c: add             SP, SP, #8
    // 0x695180: ldur            x3, [fp, #-0x10]
    // 0x695184: LoadField: r0 = r3->field_23
    //     0x695184: ldur            w0, [x3, #0x23]
    // 0x695188: DecompressPointer r0
    //     0x695188: add             x0, x0, HEAP, lsl #32
    // 0x69518c: mov             x1, x0
    // 0x695190: ldur            x0, [fp, #-0x28]
    // 0x695194: cmp             w1, NULL
    // 0x695198: b.eq            #0x69588c
    // 0x69519c: LoadField: d0 = r0->field_7
    //     0x69519c: ldur            d0, [x0, #7]
    // 0x6951a0: stur            d0, [fp, #-0x38]
    // 0x6951a4: LoadField: d1 = r1->field_7
    //     0x6951a4: ldur            d1, [x1, #7]
    // 0x6951a8: fsub            d2, d1, d0
    // 0x6951ac: stur            d2, [fp, #-0x30]
    // 0x6951b0: LoadField: r0 = r3->field_f
    //     0x6951b0: ldur            w0, [x3, #0xf]
    // 0x6951b4: DecompressPointer r0
    //     0x6951b4: add             x0, x0, HEAP, lsl #32
    // 0x6951b8: LoadField: r4 = r0->field_27
    //     0x6951b8: ldur            w4, [x0, #0x27]
    // 0x6951bc: DecompressPointer r4
    //     0x6951bc: add             x4, x4, HEAP, lsl #32
    // 0x6951c0: stur            x4, [fp, #-0x20]
    // 0x6951c4: cmp             w4, NULL
    // 0x6951c8: b.eq            #0x6957e4
    // 0x6951cc: ldr             x6, [fp, #0x10]
    // 0x6951d0: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6951d0: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6951d4: ldr             x5, [x5, #0x1e8]
    // 0x6951d8: mov             x0, x4
    // 0x6951dc: r2 = Null
    //     0x6951dc: mov             x2, NULL
    // 0x6951e0: r1 = Null
    //     0x6951e0: mov             x1, NULL
    // 0x6951e4: r4 = LoadClassIdInstr(r0)
    //     0x6951e4: ldur            x4, [x0, #-1]
    //     0x6951e8: ubfx            x4, x4, #0xc, #0x14
    // 0x6951ec: sub             x4, x4, #0x80d
    // 0x6951f0: cmp             x4, #1
    // 0x6951f4: b.ls            #0x69520c
    // 0x6951f8: r8 = BoxConstraints
    //     0x6951f8: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x6951fc: ldr             x8, [x8, #0x1d0]
    // 0x695200: r3 = Null
    //     0x695200: add             x3, PP, #0x51, lsl #12  ; [pp+0x51058] Null
    //     0x695204: ldr             x3, [x3, #0x58]
    // 0x695208: r0 = BoxConstraints()
    //     0x695208: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69520c: ldur            x0, [fp, #-0x20]
    // 0x695210: LoadField: d0 = r0->field_1f
    //     0x695210: ldur            d0, [x0, #0x1f]
    // 0x695214: stur            d0, [fp, #-0x40]
    // 0x695218: r0 = BoxConstraints()
    //     0x695218: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69521c: d0 = 0.000000
    //     0x69521c: eor             v0.16b, v0.16b, v0.16b
    // 0x695220: StoreField: r0->field_7 = d0
    //     0x695220: stur            d0, [x0, #7]
    // 0x695224: ldur            d1, [fp, #-0x30]
    // 0x695228: StoreField: r0->field_f = d1
    //     0x695228: stur            d1, [x0, #0xf]
    // 0x69522c: StoreField: r0->field_17 = d0
    //     0x69522c: stur            d0, [x0, #0x17]
    // 0x695230: ldur            d1, [fp, #-0x40]
    // 0x695234: StoreField: r0->field_1f = d1
    //     0x695234: stur            d1, [x0, #0x1f]
    // 0x695238: ldr             x1, [fp, #0x10]
    // 0x69523c: r2 = LoadClassIdInstr(r1)
    //     0x69523c: ldur            x2, [x1, #-1]
    //     0x695240: ubfx            x2, x2, #0xc, #0x14
    // 0x695244: stp             x0, x1, [SP, #-0x10]!
    // 0x695248: r16 = true
    //     0x695248: add             x16, NULL, #0x20  ; true
    // 0x69524c: SaveReg r16
    //     0x69524c: str             x16, [SP, #-8]!
    // 0x695250: mov             x0, x2
    // 0x695254: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x695254: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x695258: ldr             x4, [x4, #0x1c8]
    // 0x69525c: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x69525c: mov             x17, #0xcdfb
    //     0x695260: add             lr, x0, x17
    //     0x695264: ldr             lr, [x21, lr, lsl #3]
    //     0x695268: blr             lr
    // 0x69526c: add             SP, SP, #0x18
    // 0x695270: ldr             x3, [fp, #0x10]
    // 0x695274: LoadField: r1 = r3->field_57
    //     0x695274: ldur            w1, [x3, #0x57]
    // 0x695278: DecompressPointer r1
    //     0x695278: add             x1, x1, HEAP, lsl #32
    // 0x69527c: cmp             w1, NULL
    // 0x695280: b.eq            #0x695890
    // 0x695284: LoadField: d0 = r1->field_f
    //     0x695284: ldur            d0, [x1, #0xf]
    // 0x695288: ldur            x4, [fp, #-0x10]
    // 0x69528c: LoadField: r0 = r4->field_1f
    //     0x69528c: ldur            w0, [x4, #0x1f]
    // 0x695290: DecompressPointer r0
    //     0x695290: add             x0, x0, HEAP, lsl #32
    // 0x695294: r16 = Sentinel
    //     0x695294: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x695298: cmp             w0, w16
    // 0x69529c: b.ne            #0x6952ac
    // 0x6952a0: r0 = 0.000000
    //     0x6952a0: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6952a4: StoreField: r4->field_1f = r0
    //     0x6952a4: stur            w0, [x4, #0x1f]
    // 0x6952a8: r0 = 0.000000
    //     0x6952a8: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x6952ac: cmp             w0, NULL
    // 0x6952b0: b.eq            #0x695894
    // 0x6952b4: LoadField: d1 = r0->field_7
    //     0x6952b4: ldur            d1, [x0, #7]
    // 0x6952b8: fcmp            d0, d1
    // 0x6952bc: b.vs            #0x6952ec
    // 0x6952c0: b.le            #0x6952ec
    // 0x6952c4: r0 = inline_Allocate_Double()
    //     0x6952c4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6952c8: add             x0, x0, #0x10
    //     0x6952cc: cmp             x2, x0
    //     0x6952d0: b.ls            #0x695898
    //     0x6952d4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6952d8: sub             x0, x0, #0xf
    //     0x6952dc: mov             x2, #0xd108
    //     0x6952e0: movk            x2, #3, lsl #16
    //     0x6952e4: stur            x2, [x0, #-1]
    // 0x6952e8: StoreField: r0->field_7 = d0
    //     0x6952e8: stur            d0, [x0, #7]
    // 0x6952ec: ldur            d0, [fp, #-0x38]
    // 0x6952f0: StoreField: r4->field_1f = r0
    //     0x6952f0: stur            w0, [x4, #0x1f]
    //     0x6952f4: ldurb           w16, [x4, #-1]
    //     0x6952f8: ldurb           w17, [x0, #-1]
    //     0x6952fc: and             x16, x17, x16, lsr #2
    //     0x695300: tst             x16, HEAP, lsr #32
    //     0x695304: b.eq            #0x69530c
    //     0x695308: bl              #0xd682cc
    // 0x69530c: LoadField: r0 = r4->field_17
    //     0x69530c: ldur            w0, [x4, #0x17]
    // 0x695310: DecompressPointer r0
    //     0x695310: add             x0, x0, HEAP, lsl #32
    // 0x695314: cmp             w0, NULL
    // 0x695318: b.eq            #0x6958b8
    // 0x69531c: LoadField: d1 = r0->field_7
    //     0x69531c: ldur            d1, [x0, #7]
    // 0x695320: fadd            d2, d1, d0
    // 0x695324: LoadField: d0 = r1->field_7
    //     0x695324: ldur            d0, [x1, #7]
    // 0x695328: fadd            d1, d2, d0
    // 0x69532c: stur            d1, [fp, #-0x30]
    // 0x695330: LoadField: r5 = r4->field_f
    //     0x695330: ldur            w5, [x4, #0xf]
    // 0x695334: DecompressPointer r5
    //     0x695334: add             x5, x5, HEAP, lsl #32
    // 0x695338: stur            x5, [fp, #-0x28]
    // 0x69533c: LoadField: r6 = r5->field_27
    //     0x69533c: ldur            w6, [x5, #0x27]
    // 0x695340: DecompressPointer r6
    //     0x695340: add             x6, x6, HEAP, lsl #32
    // 0x695344: stur            x6, [fp, #-0x20]
    // 0x695348: cmp             w6, NULL
    // 0x69534c: b.eq            #0x6957fc
    // 0x695350: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x695350: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x695354: ldr             x7, [x7, #0x1e8]
    // 0x695358: mov             x0, x6
    // 0x69535c: r2 = Null
    //     0x69535c: mov             x2, NULL
    // 0x695360: r1 = Null
    //     0x695360: mov             x1, NULL
    // 0x695364: r4 = LoadClassIdInstr(r0)
    //     0x695364: ldur            x4, [x0, #-1]
    //     0x695368: ubfx            x4, x4, #0xc, #0x14
    // 0x69536c: sub             x4, x4, #0x80d
    // 0x695370: cmp             x4, #1
    // 0x695374: b.ls            #0x69538c
    // 0x695378: r8 = BoxConstraints
    //     0x695378: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69537c: ldr             x8, [x8, #0x1d0]
    // 0x695380: r3 = Null
    //     0x695380: add             x3, PP, #0x51, lsl #12  ; [pp+0x51068] Null
    //     0x695384: ldr             x3, [x3, #0x68]
    // 0x695388: r0 = BoxConstraints()
    //     0x695388: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69538c: ldur            x0, [fp, #-0x20]
    // 0x695390: LoadField: d0 = r0->field_f
    //     0x695390: ldur            d0, [x0, #0xf]
    // 0x695394: ldur            d1, [fp, #-0x30]
    // 0x695398: fcmp            d1, d0
    // 0x69539c: b.vs            #0x6955a0
    // 0x6953a0: b.le            #0x6955a0
    // 0x6953a4: ldur            x2, [fp, #-0x10]
    // 0x6953a8: ldur            x3, [fp, #-0x28]
    // 0x6953ac: LoadField: r0 = r2->field_27
    //     0x6953ac: ldur            w0, [x2, #0x27]
    // 0x6953b0: DecompressPointer r0
    //     0x6953b0: add             x0, x0, HEAP, lsl #32
    // 0x6953b4: cmp             w0, NULL
    // 0x6953b8: b.eq            #0x6958bc
    // 0x6953bc: r1 = LoadInt32Instr(r0)
    //     0x6953bc: sbfx            x1, x0, #1, #0x1f
    //     0x6953c0: tbz             w0, #0, #0x6953c8
    //     0x6953c4: ldur            x1, [x0, #7]
    // 0x6953c8: add             x4, x1, #1
    // 0x6953cc: r0 = BoxInt64Instr(r4)
    //     0x6953cc: sbfiz           x0, x4, #1, #0x1f
    //     0x6953d0: cmp             x4, x0, asr #1
    //     0x6953d4: b.eq            #0x6953e0
    //     0x6953d8: bl              #0xd69bb8
    //     0x6953dc: stur            x4, [x0, #7]
    // 0x6953e0: StoreField: r2->field_27 = r0
    //     0x6953e0: stur            w0, [x2, #0x27]
    //     0x6953e4: tbz             w0, #0, #0x695400
    //     0x6953e8: ldurb           w16, [x2, #-1]
    //     0x6953ec: ldurb           w17, [x0, #-1]
    //     0x6953f0: and             x16, x17, x16, lsr #2
    //     0x6953f4: tst             x16, HEAP, lsr #32
    //     0x6953f8: b.eq            #0x695400
    //     0x6953fc: bl              #0xd6828c
    // 0x695400: LoadField: r0 = r3->field_83
    //     0x695400: ldur            w0, [x3, #0x83]
    // 0x695404: DecompressPointer r0
    //     0x695404: add             x0, x0, HEAP, lsl #32
    // 0x695408: cmp             w0, NULL
    // 0x69540c: b.eq            #0x6958c0
    // 0x695410: LoadField: r1 = r0->field_57
    //     0x695410: ldur            w1, [x0, #0x57]
    // 0x695414: DecompressPointer r1
    //     0x695414: add             x1, x1, HEAP, lsl #32
    // 0x695418: cmp             w1, NULL
    // 0x69541c: b.eq            #0x6958c4
    // 0x695420: LoadField: d0 = r1->field_7
    //     0x695420: ldur            d0, [x1, #7]
    // 0x695424: LoadField: d1 = r3->field_7b
    //     0x695424: ldur            d1, [x3, #0x7b]
    // 0x695428: fadd            d2, d0, d1
    // 0x69542c: r0 = inline_Allocate_Double()
    //     0x69542c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x695430: add             x0, x0, #0x10
    //     0x695434: cmp             x1, x0
    //     0x695438: b.ls            #0x6958c8
    //     0x69543c: str             x0, [THR, #0x60]  ; THR::top
    //     0x695440: sub             x0, x0, #0xf
    //     0x695444: mov             x1, #0xd108
    //     0x695448: movk            x1, #3, lsl #16
    //     0x69544c: stur            x1, [x0, #-1]
    // 0x695450: StoreField: r0->field_7 = d2
    //     0x695450: stur            d2, [x0, #7]
    // 0x695454: StoreField: r2->field_17 = r0
    //     0x695454: stur            w0, [x2, #0x17]
    //     0x695458: ldurb           w16, [x2, #-1]
    //     0x69545c: ldurb           w17, [x0, #-1]
    //     0x695460: and             x16, x17, x16, lsr #2
    //     0x695464: tst             x16, HEAP, lsr #32
    //     0x695468: b.eq            #0x695470
    //     0x69546c: bl              #0xd6828c
    // 0x695470: LoadField: r0 = r3->field_87
    //     0x695470: ldur            w0, [x3, #0x87]
    // 0x695474: DecompressPointer r0
    //     0x695474: add             x0, x0, HEAP, lsl #32
    // 0x695478: cmp             w0, NULL
    // 0x69547c: b.eq            #0x6958e0
    // 0x695480: LoadField: r1 = r0->field_57
    //     0x695480: ldur            w1, [x0, #0x57]
    // 0x695484: DecompressPointer r1
    //     0x695484: add             x1, x1, HEAP, lsl #32
    // 0x695488: cmp             w1, NULL
    // 0x69548c: b.eq            #0x6958e4
    // 0x695490: LoadField: d1 = r1->field_7
    //     0x695490: ldur            d1, [x1, #7]
    // 0x695494: fadd            d2, d0, d1
    // 0x695498: stur            d2, [fp, #-0x30]
    // 0x69549c: LoadField: r0 = r2->field_23
    //     0x69549c: ldur            w0, [x2, #0x23]
    // 0x6954a0: DecompressPointer r0
    //     0x6954a0: add             x0, x0, HEAP, lsl #32
    // 0x6954a4: r16 = Sentinel
    //     0x6954a4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6954a8: cmp             w0, w16
    // 0x6954ac: b.ne            #0x6954c4
    // 0x6954b0: r16 = "firstPageWidth"
    //     0x6954b0: add             x16, PP, #0x51, lsl #12  ; [pp+0x51050] "firstPageWidth"
    //     0x6954b4: ldr             x16, [x16, #0x50]
    // 0x6954b8: SaveReg r16
    //     0x6954b8: str             x16, [SP, #-8]!
    // 0x6954bc: r0 = _throwLocalNotInitialized()
    //     0x6954bc: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x6954c0: add             SP, SP, #8
    // 0x6954c4: ldur            x3, [fp, #-0x10]
    // 0x6954c8: ldur            d0, [fp, #-0x30]
    // 0x6954cc: LoadField: r0 = r3->field_23
    //     0x6954cc: ldur            w0, [x3, #0x23]
    // 0x6954d0: DecompressPointer r0
    //     0x6954d0: add             x0, x0, HEAP, lsl #32
    // 0x6954d4: cmp             w0, NULL
    // 0x6954d8: b.eq            #0x6958e8
    // 0x6954dc: LoadField: d1 = r0->field_7
    //     0x6954dc: ldur            d1, [x0, #7]
    // 0x6954e0: fsub            d2, d1, d0
    // 0x6954e4: stur            d2, [fp, #-0x38]
    // 0x6954e8: LoadField: r0 = r3->field_f
    //     0x6954e8: ldur            w0, [x3, #0xf]
    // 0x6954ec: DecompressPointer r0
    //     0x6954ec: add             x0, x0, HEAP, lsl #32
    // 0x6954f0: LoadField: r4 = r0->field_27
    //     0x6954f0: ldur            w4, [x0, #0x27]
    // 0x6954f4: DecompressPointer r4
    //     0x6954f4: add             x4, x4, HEAP, lsl #32
    // 0x6954f8: stur            x4, [fp, #-0x20]
    // 0x6954fc: cmp             w4, NULL
    // 0x695500: b.eq            #0x695814
    // 0x695504: ldr             x5, [fp, #0x10]
    // 0x695508: mov             x0, x4
    // 0x69550c: r2 = Null
    //     0x69550c: mov             x2, NULL
    // 0x695510: r1 = Null
    //     0x695510: mov             x1, NULL
    // 0x695514: r4 = LoadClassIdInstr(r0)
    //     0x695514: ldur            x4, [x0, #-1]
    //     0x695518: ubfx            x4, x4, #0xc, #0x14
    // 0x69551c: sub             x4, x4, #0x80d
    // 0x695520: cmp             x4, #1
    // 0x695524: b.ls            #0x69553c
    // 0x695528: r8 = BoxConstraints
    //     0x695528: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x69552c: ldr             x8, [x8, #0x1d0]
    // 0x695530: r3 = Null
    //     0x695530: add             x3, PP, #0x51, lsl #12  ; [pp+0x51078] Null
    //     0x695534: ldr             x3, [x3, #0x78]
    // 0x695538: r0 = BoxConstraints()
    //     0x695538: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x69553c: ldur            x0, [fp, #-0x20]
    // 0x695540: LoadField: d0 = r0->field_1f
    //     0x695540: ldur            d0, [x0, #0x1f]
    // 0x695544: stur            d0, [fp, #-0x30]
    // 0x695548: r0 = BoxConstraints()
    //     0x695548: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x69554c: d0 = 0.000000
    //     0x69554c: eor             v0.16b, v0.16b, v0.16b
    // 0x695550: StoreField: r0->field_7 = d0
    //     0x695550: stur            d0, [x0, #7]
    // 0x695554: ldur            d1, [fp, #-0x38]
    // 0x695558: StoreField: r0->field_f = d1
    //     0x695558: stur            d1, [x0, #0xf]
    // 0x69555c: StoreField: r0->field_17 = d0
    //     0x69555c: stur            d0, [x0, #0x17]
    // 0x695560: ldur            d1, [fp, #-0x30]
    // 0x695564: StoreField: r0->field_1f = d1
    //     0x695564: stur            d1, [x0, #0x1f]
    // 0x695568: ldr             x1, [fp, #0x10]
    // 0x69556c: r2 = LoadClassIdInstr(r1)
    //     0x69556c: ldur            x2, [x1, #-1]
    //     0x695570: ubfx            x2, x2, #0xc, #0x14
    // 0x695574: stp             x0, x1, [SP, #-0x10]!
    // 0x695578: r16 = true
    //     0x695578: add             x16, NULL, #0x20  ; true
    // 0x69557c: SaveReg r16
    //     0x69557c: str             x16, [SP, #-8]!
    // 0x695580: mov             x0, x2
    // 0x695584: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x695584: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x695588: ldr             x4, [x4, #0x1c8]
    // 0x69558c: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x69558c: mov             x17, #0xcdfb
    //     0x695590: add             lr, x0, x17
    //     0x695594: ldr             lr, [x21, lr, lsl #3]
    //     0x695598: blr             lr
    // 0x69559c: add             SP, SP, #0x18
    // 0x6955a0: ldr             x0, [fp, #0x10]
    // 0x6955a4: ldur            x1, [fp, #-0x10]
    // 0x6955a8: ldur            x2, [fp, #-0x18]
    // 0x6955ac: LoadField: r3 = r1->field_17
    //     0x6955ac: ldur            w3, [x1, #0x17]
    // 0x6955b0: DecompressPointer r3
    //     0x6955b0: add             x3, x3, HEAP, lsl #32
    // 0x6955b4: stur            x3, [fp, #-0x20]
    // 0x6955b8: LoadField: d0 = r3->field_7
    //     0x6955b8: ldur            d0, [x3, #7]
    // 0x6955bc: stur            d0, [fp, #-0x30]
    // 0x6955c0: r0 = Offset()
    //     0x6955c0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x6955c4: ldur            d0, [fp, #-0x30]
    // 0x6955c8: StoreField: r0->field_7 = d0
    //     0x6955c8: stur            d0, [x0, #7]
    // 0x6955cc: d1 = 0.000000
    //     0x6955cc: eor             v1.16b, v1.16b, v1.16b
    // 0x6955d0: StoreField: r0->field_f = d1
    //     0x6955d0: stur            d1, [x0, #0xf]
    // 0x6955d4: ldur            x2, [fp, #-0x18]
    // 0x6955d8: StoreField: r2->field_7 = r0
    //     0x6955d8: stur            w0, [x2, #7]
    //     0x6955dc: ldurb           w16, [x2, #-1]
    //     0x6955e0: ldurb           w17, [x0, #-1]
    //     0x6955e4: and             x16, x17, x16, lsr #2
    //     0x6955e8: tst             x16, HEAP, lsr #32
    //     0x6955ec: b.eq            #0x6955f4
    //     0x6955f0: bl              #0xd6828c
    // 0x6955f4: ldr             x3, [fp, #0x10]
    // 0x6955f8: LoadField: r4 = r3->field_57
    //     0x6955f8: ldur            w4, [x3, #0x57]
    // 0x6955fc: DecompressPointer r4
    //     0x6955fc: add             x4, x4, HEAP, lsl #32
    // 0x695600: cmp             w4, NULL
    // 0x695604: b.eq            #0x6958ec
    // 0x695608: LoadField: d1 = r4->field_7
    //     0x695608: ldur            d1, [x4, #7]
    // 0x69560c: ldur            x3, [fp, #-0x10]
    // 0x695610: LoadField: r4 = r3->field_f
    //     0x695610: ldur            w4, [x3, #0xf]
    // 0x695614: DecompressPointer r4
    //     0x695614: add             x4, x4, HEAP, lsl #32
    // 0x695618: LoadField: d2 = r4->field_7b
    //     0x695618: ldur            d2, [x4, #0x7b]
    // 0x69561c: fadd            d3, d1, d2
    // 0x695620: ldur            x5, [fp, #-0x20]
    // 0x695624: cmp             w5, NULL
    // 0x695628: b.eq            #0x6958f0
    // 0x69562c: fadd            d1, d0, d3
    // 0x695630: r5 = inline_Allocate_Double()
    //     0x695630: ldp             x5, x6, [THR, #0x60]  ; THR::top
    //     0x695634: add             x5, x5, #0x10
    //     0x695638: cmp             x6, x5
    //     0x69563c: b.ls            #0x6958f4
    //     0x695640: str             x5, [THR, #0x60]  ; THR::top
    //     0x695644: sub             x5, x5, #0xf
    //     0x695648: mov             x6, #0xd108
    //     0x69564c: movk            x6, #3, lsl #16
    //     0x695650: stur            x6, [x5, #-1]
    // 0x695654: StoreField: r5->field_7 = d1
    //     0x695654: stur            d1, [x5, #7]
    // 0x695658: mov             x0, x5
    // 0x69565c: StoreField: r3->field_17 = r0
    //     0x69565c: stur            w0, [x3, #0x17]
    //     0x695660: ldurb           w16, [x3, #-1]
    //     0x695664: ldurb           w17, [x0, #-1]
    //     0x695668: and             x16, x17, x16, lsr #2
    //     0x69566c: tst             x16, HEAP, lsr #32
    //     0x695670: b.eq            #0x695678
    //     0x695674: bl              #0xd682ac
    // 0x695678: LoadField: r6 = r3->field_27
    //     0x695678: ldur            w6, [x3, #0x27]
    // 0x69567c: DecompressPointer r6
    //     0x69567c: add             x6, x6, HEAP, lsl #32
    // 0x695680: LoadField: r7 = r4->field_73
    //     0x695680: ldur            x7, [x4, #0x73]
    // 0x695684: r0 = BoxInt64Instr(r7)
    //     0x695684: sbfiz           x0, x7, #1, #0x1f
    //     0x695688: cmp             x7, x0, asr #1
    //     0x69568c: b.eq            #0x695698
    //     0x695690: bl              #0xd69c6c
    //     0x695694: stur            x7, [x0, #7]
    // 0x695698: mov             x1, x0
    // 0x69569c: cmp             w6, w1
    // 0x6956a0: b.eq            #0x6956e4
    // 0x6956a4: and             w16, w6, w1
    // 0x6956a8: branchIfSmi(r16, 0x6956dc)
    //     0x6956a8: tbz             w16, #0, #0x6956dc
    // 0x6956ac: r16 = LoadClassIdInstr(r6)
    //     0x6956ac: ldur            x16, [x6, #-1]
    //     0x6956b0: ubfx            x16, x16, #0xc, #0x14
    // 0x6956b4: cmp             x16, #0x3c
    // 0x6956b8: b.ne            #0x6956dc
    // 0x6956bc: r16 = LoadClassIdInstr(r1)
    //     0x6956bc: ldur            x16, [x1, #-1]
    //     0x6956c0: ubfx            x16, x16, #0xc, #0x14
    // 0x6956c4: cmp             x16, #0x3c
    // 0x6956c8: b.ne            #0x6956dc
    // 0x6956cc: LoadField: r16 = r6->field_7
    //     0x6956cc: ldur            x16, [x6, #7]
    // 0x6956d0: LoadField: r17 = r1->field_7
    //     0x6956d0: ldur            x17, [x1, #7]
    // 0x6956d4: cmp             x16, x17
    // 0x6956d8: b.eq            #0x6956e4
    // 0x6956dc: r7 = false
    //     0x6956dc: add             x7, NULL, #0x30  ; false
    // 0x6956e0: b               #0x6956e8
    // 0x6956e4: r7 = true
    //     0x6956e4: add             x7, NULL, #0x20  ; true
    // 0x6956e8: StoreField: r2->field_17 = r7
    //     0x6956e8: stur            w7, [x2, #0x17]
    // 0x6956ec: cbnz            w6, #0x69575c
    // 0x6956f0: LoadField: r2 = r4->field_87
    //     0x6956f0: ldur            w2, [x4, #0x87]
    // 0x6956f4: DecompressPointer r2
    //     0x6956f4: add             x2, x2, HEAP, lsl #32
    // 0x6956f8: cmp             w2, NULL
    // 0x6956fc: b.eq            #0x695918
    // 0x695700: LoadField: r4 = r2->field_57
    //     0x695700: ldur            w4, [x2, #0x57]
    // 0x695704: DecompressPointer r4
    //     0x695704: add             x4, x4, HEAP, lsl #32
    // 0x695708: cmp             w4, NULL
    // 0x69570c: b.eq            #0x69591c
    // 0x695710: LoadField: d0 = r4->field_7
    //     0x695710: ldur            d0, [x4, #7]
    // 0x695714: fadd            d2, d1, d0
    // 0x695718: r0 = inline_Allocate_Double()
    //     0x695718: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x69571c: add             x0, x0, #0x10
    //     0x695720: cmp             x2, x0
    //     0x695724: b.ls            #0x695920
    //     0x695728: str             x0, [THR, #0x60]  ; THR::top
    //     0x69572c: sub             x0, x0, #0xf
    //     0x695730: mov             x2, #0xd108
    //     0x695734: movk            x2, #3, lsl #16
    //     0x695738: stur            x2, [x0, #-1]
    // 0x69573c: StoreField: r0->field_7 = d2
    //     0x69573c: stur            d2, [x0, #7]
    // 0x695740: StoreField: r3->field_23 = r0
    //     0x695740: stur            w0, [x3, #0x23]
    //     0x695744: ldurb           w16, [x3, #-1]
    //     0x695748: ldurb           w17, [x0, #-1]
    //     0x69574c: and             x16, x17, x16, lsr #2
    //     0x695750: tst             x16, HEAP, lsr #32
    //     0x695754: b.eq            #0x69575c
    //     0x695758: bl              #0xd682ac
    // 0x69575c: cmp             w6, w1
    // 0x695760: b.eq            #0x69579c
    // 0x695764: and             w16, w6, w1
    // 0x695768: branchIfSmi(r16, 0x6957bc)
    //     0x695768: tbz             w16, #0, #0x6957bc
    // 0x69576c: r16 = LoadClassIdInstr(r6)
    //     0x69576c: ldur            x16, [x6, #-1]
    //     0x695770: ubfx            x16, x16, #0xc, #0x14
    // 0x695774: cmp             x16, #0x3c
    // 0x695778: b.ne            #0x6957bc
    // 0x69577c: r16 = LoadClassIdInstr(r1)
    //     0x69577c: ldur            x16, [x1, #-1]
    //     0x695780: ubfx            x16, x16, #0xc, #0x14
    // 0x695784: cmp             x16, #0x3c
    // 0x695788: b.ne            #0x6957bc
    // 0x69578c: LoadField: r16 = r6->field_7
    //     0x69578c: ldur            x16, [x6, #7]
    // 0x695790: LoadField: r17 = r1->field_7
    //     0x695790: ldur            x17, [x1, #7]
    // 0x695794: cmp             x16, x17
    // 0x695798: b.ne            #0x6957bc
    // 0x69579c: mov             x0, x5
    // 0x6957a0: StoreField: r3->field_1b = r0
    //     0x6957a0: stur            w0, [x3, #0x1b]
    //     0x6957a4: ldurb           w16, [x3, #-1]
    //     0x6957a8: ldurb           w17, [x0, #-1]
    //     0x6957ac: and             x16, x17, x16, lsr #2
    //     0x6957b0: tst             x16, HEAP, lsr #32
    //     0x6957b4: b.eq            #0x6957bc
    //     0x6957b8: bl              #0xd682ac
    // 0x6957bc: r0 = Null
    //     0x6957bc: mov             x0, NULL
    // 0x6957c0: LeaveFrame
    //     0x6957c0: mov             SP, fp
    //     0x6957c4: ldp             fp, lr, [SP], #0x10
    // 0x6957c8: ret
    //     0x6957c8: ret             
    // 0x6957cc: r0 = StateError()
    //     0x6957cc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6957d0: r8 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6957d0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6957d4: ldr             x8, [x8, #0x1e8]
    // 0x6957d8: StoreField: r0->field_b = r8
    //     0x6957d8: stur            w8, [x0, #0xb]
    // 0x6957dc: r0 = Throw()
    //     0x6957dc: bl              #0xd67e38  ; ThrowStub
    // 0x6957e0: brk             #0
    // 0x6957e4: r0 = StateError()
    //     0x6957e4: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x6957e8: r5 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x6957e8: add             x5, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x6957ec: ldr             x5, [x5, #0x1e8]
    // 0x6957f0: StoreField: r0->field_b = r5
    //     0x6957f0: stur            w5, [x0, #0xb]
    // 0x6957f4: r0 = Throw()
    //     0x6957f4: bl              #0xd67e38  ; ThrowStub
    // 0x6957f8: brk             #0
    // 0x6957fc: r0 = StateError()
    //     0x6957fc: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x695800: r7 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x695800: add             x7, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x695804: ldr             x7, [x7, #0x1e8]
    // 0x695808: StoreField: r0->field_b = r7
    //     0x695808: stur            w7, [x0, #0xb]
    // 0x69580c: r0 = Throw()
    //     0x69580c: bl              #0xd67e38  ; ThrowStub
    // 0x695810: brk             #0
    // 0x695814: r0 = StateError()
    //     0x695814: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x695818: mov             x1, x0
    // 0x69581c: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x69581c: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x695820: ldr             x0, [x0, #0x1e8]
    // 0x695824: StoreField: r1->field_b = r0
    //     0x695824: stur            w0, [x1, #0xb]
    // 0x695828: mov             x0, x1
    // 0x69582c: r0 = Throw()
    //     0x69582c: bl              #0xd67e38  ; ThrowStub
    // 0x695830: brk             #0
    // 0x695834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x695834: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x695838: b               #0x694ef0
    // 0x69583c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x69583c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x695840: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695840: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695844: r0 = NullErrorSharedWithoutFPURegs()
    //     0x695844: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x695848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695848: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69584c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69584c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695850: SaveReg d0
    //     0x695850: str             q0, [SP, #-0x10]!
    // 0x695854: stp             x4, x5, [SP, #-0x10]!
    // 0x695858: stp             x2, x3, [SP, #-0x10]!
    // 0x69585c: SaveReg r0
    //     0x69585c: str             x0, [SP, #-8]!
    // 0x695860: r0 = AllocateDouble()
    //     0x695860: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x695864: mov             x1, x0
    // 0x695868: RestoreReg r0
    //     0x695868: ldr             x0, [SP], #8
    // 0x69586c: ldp             x2, x3, [SP], #0x10
    // 0x695870: ldp             x4, x5, [SP], #0x10
    // 0x695874: RestoreReg d0
    //     0x695874: ldr             q0, [SP], #0x10
    // 0x695878: b               #0x6950a8
    // 0x69587c: SaveReg d0
    //     0x69587c: str             q0, [SP, #-0x10]!
    // 0x695880: r0 = AllocateDouble()
    //     0x695880: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x695884: RestoreReg d0
    //     0x695884: ldr             q0, [SP], #0x10
    // 0x695888: b               #0x695144
    // 0x69588c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x69588c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x695890: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x695890: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x695894: r0 = NullErrorSharedWithFPURegs()
    //     0x695894: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x695898: SaveReg d0
    //     0x695898: str             q0, [SP, #-0x10]!
    // 0x69589c: stp             x3, x4, [SP, #-0x10]!
    // 0x6958a0: SaveReg r1
    //     0x6958a0: str             x1, [SP, #-8]!
    // 0x6958a4: r0 = AllocateDouble()
    //     0x6958a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6958a8: RestoreReg r1
    //     0x6958a8: ldr             x1, [SP], #8
    // 0x6958ac: ldp             x3, x4, [SP], #0x10
    // 0x6958b0: RestoreReg d0
    //     0x6958b0: ldr             q0, [SP], #0x10
    // 0x6958b4: b               #0x6952e8
    // 0x6958b8: r0 = NullErrorSharedWithFPURegs()
    //     0x6958b8: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x6958bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x6958bc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x6958c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6958c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6958c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6958c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6958c8: stp             q0, q2, [SP, #-0x20]!
    // 0x6958cc: stp             x2, x3, [SP, #-0x10]!
    // 0x6958d0: r0 = AllocateDouble()
    //     0x6958d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6958d4: ldp             x2, x3, [SP], #0x10
    // 0x6958d8: ldp             q0, q2, [SP], #0x20
    // 0x6958dc: b               #0x695450
    // 0x6958e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6958e0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6958e4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6958e4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6958e8: r0 = NullErrorSharedWithFPURegs()
    //     0x6958e8: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x6958ec: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6958ec: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6958f0: r0 = NullErrorSharedWithFPURegs()
    //     0x6958f0: bl              #0xd6a1dc  ; NullErrorSharedWithFPURegsStub
    // 0x6958f4: SaveReg d1
    //     0x6958f4: str             q1, [SP, #-0x10]!
    // 0x6958f8: stp             x3, x4, [SP, #-0x10]!
    // 0x6958fc: SaveReg r2
    //     0x6958fc: str             x2, [SP, #-8]!
    // 0x695900: r0 = AllocateDouble()
    //     0x695900: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x695904: mov             x5, x0
    // 0x695908: RestoreReg r2
    //     0x695908: ldr             x2, [SP], #8
    // 0x69590c: ldp             x3, x4, [SP], #0x10
    // 0x695910: RestoreReg d1
    //     0x695910: ldr             q1, [SP], #0x10
    // 0x695914: b               #0x695654
    // 0x695918: r0 = NullCastErrorSharedWithFPURegs()
    //     0x695918: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x69591c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x69591c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x695920: SaveReg d2
    //     0x695920: str             q2, [SP, #-0x10]!
    // 0x695924: stp             x5, x6, [SP, #-0x10]!
    // 0x695928: stp             x1, x3, [SP, #-0x10]!
    // 0x69592c: r0 = AllocateDouble()
    //     0x69592c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x695930: ldp             x1, x3, [SP], #0x10
    // 0x695934: ldp             x5, x6, [SP], #0x10
    // 0x695938: RestoreReg d2
    //     0x695938: ldr             q2, [SP], #0x10
    // 0x69593c: b               #0x69573c
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0x6bf968, size: 0xd0
    // 0x6bf968: EnterFrame
    //     0x6bf968: stp             fp, lr, [SP, #-0x10]!
    //     0x6bf96c: mov             fp, SP
    // 0x6bf970: CheckStackOverflow
    //     0x6bf970: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bf974: cmp             SP, x16
    //     0x6bf978: b.ls            #0x6bfa30
    // 0x6bf97c: ldr             x1, [fp, #0x18]
    // 0x6bf980: LoadField: r0 = r1->field_83
    //     0x6bf980: ldur            w0, [x1, #0x83]
    // 0x6bf984: DecompressPointer r0
    //     0x6bf984: add             x0, x0, HEAP, lsl #32
    // 0x6bf988: cmp             w0, NULL
    // 0x6bf98c: b.eq            #0x6bf9ac
    // 0x6bf990: ldr             x16, [fp, #0x10]
    // 0x6bf994: stp             x0, x16, [SP, #-0x10]!
    // 0x6bf998: ldr             x0, [fp, #0x10]
    // 0x6bf99c: ClosureCall
    //     0x6bf99c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf9a0: ldur            x2, [x0, #0x1f]
    //     0x6bf9a4: blr             x2
    // 0x6bf9a8: add             SP, SP, #0x10
    // 0x6bf9ac: ldr             x1, [fp, #0x18]
    // 0x6bf9b0: LoadField: r0 = r1->field_87
    //     0x6bf9b0: ldur            w0, [x1, #0x87]
    // 0x6bf9b4: DecompressPointer r0
    //     0x6bf9b4: add             x0, x0, HEAP, lsl #32
    // 0x6bf9b8: cmp             w0, NULL
    // 0x6bf9bc: b.eq            #0x6bf9dc
    // 0x6bf9c0: ldr             x16, [fp, #0x10]
    // 0x6bf9c4: stp             x0, x16, [SP, #-0x10]!
    // 0x6bf9c8: ldr             x0, [fp, #0x10]
    // 0x6bf9cc: ClosureCall
    //     0x6bf9cc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bf9d0: ldur            x2, [x0, #0x1f]
    //     0x6bf9d4: blr             x2
    // 0x6bf9d8: add             SP, SP, #0x10
    // 0x6bf9dc: ldr             x1, [fp, #0x18]
    // 0x6bf9e0: LoadField: r0 = r1->field_8b
    //     0x6bf9e0: ldur            w0, [x1, #0x8b]
    // 0x6bf9e4: DecompressPointer r0
    //     0x6bf9e4: add             x0, x0, HEAP, lsl #32
    // 0x6bf9e8: cmp             w0, NULL
    // 0x6bf9ec: b.eq            #0x6bfa0c
    // 0x6bf9f0: ldr             x16, [fp, #0x10]
    // 0x6bf9f4: stp             x0, x16, [SP, #-0x10]!
    // 0x6bf9f8: ldr             x0, [fp, #0x10]
    // 0x6bf9fc: ClosureCall
    //     0x6bf9fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6bfa00: ldur            x2, [x0, #0x1f]
    //     0x6bfa04: blr             x2
    // 0x6bfa08: add             SP, SP, #0x10
    // 0x6bfa0c: ldr             x16, [fp, #0x18]
    // 0x6bfa10: ldr             lr, [fp, #0x10]
    // 0x6bfa14: stp             lr, x16, [SP, #-0x10]!
    // 0x6bfa18: r0 = visitChildren()
    //     0x6bfa18: bl              #0x6bfa38  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::visitChildren
    // 0x6bfa1c: add             SP, SP, #0x10
    // 0x6bfa20: r0 = Null
    //     0x6bfa20: mov             x0, NULL
    // 0x6bfa24: LeaveFrame
    //     0x6bfa24: mov             SP, fp
    //     0x6bfa28: ldp             fp, lr, [SP], #0x10
    // 0x6bfa2c: ret
    //     0x6bfa2c: ret             
    // 0x6bfa30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bfa30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bfa34: b               #0x6bf97c
  }
  set _ dividerWidth=(/* No info */) {
    // ** addr: 0x6e5954, size: 0x64
    // 0x6e5954: EnterFrame
    //     0x6e5954: stp             fp, lr, [SP, #-0x10]!
    //     0x6e5958: mov             fp, SP
    // 0x6e595c: CheckStackOverflow
    //     0x6e595c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e5960: cmp             SP, x16
    //     0x6e5964: b.ls            #0x6e59b0
    // 0x6e5968: ldr             x0, [fp, #0x18]
    // 0x6e596c: LoadField: d0 = r0->field_7b
    //     0x6e596c: ldur            d0, [x0, #0x7b]
    // 0x6e5970: ldr             d1, [fp, #0x10]
    // 0x6e5974: fcmp            d1, d0
    // 0x6e5978: b.vs            #0x6e5990
    // 0x6e597c: b.ne            #0x6e5990
    // 0x6e5980: r0 = Null
    //     0x6e5980: mov             x0, NULL
    // 0x6e5984: LeaveFrame
    //     0x6e5984: mov             SP, fp
    //     0x6e5988: ldp             fp, lr, [SP], #0x10
    // 0x6e598c: ret
    //     0x6e598c: ret             
    // 0x6e5990: StoreField: r0->field_7b = d1
    //     0x6e5990: stur            d1, [x0, #0x7b]
    // 0x6e5994: SaveReg r0
    //     0x6e5994: str             x0, [SP, #-8]!
    // 0x6e5998: r0 = markNeedsLayout()
    //     0x6e5998: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e599c: add             SP, SP, #8
    // 0x6e59a0: r0 = Null
    //     0x6e59a0: mov             x0, NULL
    // 0x6e59a4: LeaveFrame
    //     0x6e59a4: mov             SP, fp
    //     0x6e59a8: ldp             fp, lr, [SP], #0x10
    // 0x6e59ac: ret
    //     0x6e59ac: ret             
    // 0x6e59b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e59b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e59b4: b               #0x6e5968
  }
  set _ page=(/* No info */) {
    // ** addr: 0x6e59b8, size: 0x60
    // 0x6e59b8: EnterFrame
    //     0x6e59b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6e59bc: mov             fp, SP
    // 0x6e59c0: CheckStackOverflow
    //     0x6e59c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e59c4: cmp             SP, x16
    //     0x6e59c8: b.ls            #0x6e5a10
    // 0x6e59cc: ldr             x0, [fp, #0x18]
    // 0x6e59d0: LoadField: r1 = r0->field_73
    //     0x6e59d0: ldur            x1, [x0, #0x73]
    // 0x6e59d4: ldr             x2, [fp, #0x10]
    // 0x6e59d8: cmp             x2, x1
    // 0x6e59dc: b.ne            #0x6e59f0
    // 0x6e59e0: r0 = Null
    //     0x6e59e0: mov             x0, NULL
    // 0x6e59e4: LeaveFrame
    //     0x6e59e4: mov             SP, fp
    //     0x6e59e8: ldp             fp, lr, [SP], #0x10
    // 0x6e59ec: ret
    //     0x6e59ec: ret             
    // 0x6e59f0: StoreField: r0->field_73 = r2
    //     0x6e59f0: stur            x2, [x0, #0x73]
    // 0x6e59f4: SaveReg r0
    //     0x6e59f4: str             x0, [SP, #-8]!
    // 0x6e59f8: r0 = markNeedsLayout()
    //     0x6e59f8: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6e59fc: add             SP, SP, #8
    // 0x6e5a00: r0 = Null
    //     0x6e5a00: mov             x0, NULL
    // 0x6e5a04: LeaveFrame
    //     0x6e5a04: mov             SP, fp
    //     0x6e5a08: ldp             fp, lr, [SP], #0x10
    // 0x6e5a0c: ret
    //     0x6e5a0c: ret             
    // 0x6e5a10: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e5a10: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e5a14: b               #0x6e59cc
  }
  _ _RenderCupertinoTextSelectionToolbarItems(/* No info */) {
    // ** addr: 0x6f535c, size: 0x90
    // 0x6f535c: EnterFrame
    //     0x6f535c: stp             fp, lr, [SP, #-0x10]!
    //     0x6f5360: mov             fp, SP
    // 0x6f5364: CheckStackOverflow
    //     0x6f5364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f5368: cmp             SP, x16
    //     0x6f536c: b.ls            #0x6f53e4
    // 0x6f5370: r16 = <_CupertinoTextSelectionToolbarItemsSlot, RenderBox>
    //     0x6f5370: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4ba60] TypeArguments: <_CupertinoTextSelectionToolbarItemsSlot, RenderBox>
    //     0x6f5374: ldr             x16, [x16, #0xa60]
    // 0x6f5378: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x6f537c: stp             lr, x16, [SP, #-0x10]!
    // 0x6f5380: r0 = Map._fromLiteral()
    //     0x6f5380: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x6f5384: add             SP, SP, #0x10
    // 0x6f5388: ldr             x1, [fp, #0x20]
    // 0x6f538c: StoreField: r1->field_6f = r0
    //     0x6f538c: stur            w0, [x1, #0x6f]
    //     0x6f5390: tbz             w0, #0, #0x6f53ac
    //     0x6f5394: ldurb           w16, [x1, #-1]
    //     0x6f5398: ldurb           w17, [x0, #-1]
    //     0x6f539c: and             x16, x17, x16, lsr #2
    //     0x6f53a0: tst             x16, HEAP, lsr #32
    //     0x6f53a4: b.eq            #0x6f53ac
    //     0x6f53a8: bl              #0xd6826c
    // 0x6f53ac: ldr             x0, [fp, #0x18]
    // 0x6f53b0: LoadField: d0 = r0->field_7
    //     0x6f53b0: ldur            d0, [x0, #7]
    // 0x6f53b4: StoreField: r1->field_7b = d0
    //     0x6f53b4: stur            d0, [x1, #0x7b]
    // 0x6f53b8: ldr             x0, [fp, #0x10]
    // 0x6f53bc: StoreField: r1->field_73 = r0
    //     0x6f53bc: stur            x0, [x1, #0x73]
    // 0x6f53c0: r0 = 0
    //     0x6f53c0: mov             x0, #0
    // 0x6f53c4: StoreField: r1->field_5f = r0
    //     0x6f53c4: stur            x0, [x1, #0x5f]
    // 0x6f53c8: SaveReg r1
    //     0x6f53c8: str             x1, [SP, #-8]!
    // 0x6f53cc: r0 = RenderObject()
    //     0x6f53cc: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6f53d0: add             SP, SP, #8
    // 0x6f53d4: r0 = Null
    //     0x6f53d4: mov             x0, NULL
    // 0x6f53d8: LeaveFrame
    //     0x6f53d8: mov             SP, fp
    //     0x6f53dc: ldp             fp, lr, [SP], #0x10
    // 0x6f53e0: ret
    //     0x6f53e0: ret             
    // 0x6f53e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f53e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f53e8: b               #0x6f5370
  }
  set _ nextButtonDisabled=(/* No info */) {
    // ** addr: 0x711d34, size: 0x74
    // 0x711d34: EnterFrame
    //     0x711d34: stp             fp, lr, [SP, #-0x10]!
    //     0x711d38: mov             fp, SP
    // 0x711d3c: CheckStackOverflow
    //     0x711d3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711d40: cmp             SP, x16
    //     0x711d44: b.ls            #0x711da0
    // 0x711d48: ldr             x0, [fp, #0x18]
    // 0x711d4c: LoadField: r1 = r0->field_8b
    //     0x711d4c: ldur            w1, [x0, #0x8b]
    // 0x711d50: DecompressPointer r1
    //     0x711d50: add             x1, x1, HEAP, lsl #32
    // 0x711d54: stp             x1, x0, [SP, #-0x10]!
    // 0x711d58: ldr             x16, [fp, #0x10]
    // 0x711d5c: r30 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x711d5c: add             lr, PP, #0x50, lsl #12  ; [pp+0x50d70] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65df1
    //     0x711d60: ldr             lr, [lr, #0xd70]
    // 0x711d64: stp             lr, x16, [SP, #-0x10]!
    // 0x711d68: r0 = _updateChild()
    //     0x711d68: bl              #0x711da8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_updateChild
    // 0x711d6c: add             SP, SP, #0x20
    // 0x711d70: ldr             x1, [fp, #0x18]
    // 0x711d74: StoreField: r1->field_8b = r0
    //     0x711d74: stur            w0, [x1, #0x8b]
    //     0x711d78: ldurb           w16, [x1, #-1]
    //     0x711d7c: ldurb           w17, [x0, #-1]
    //     0x711d80: and             x16, x17, x16, lsr #2
    //     0x711d84: tst             x16, HEAP, lsr #32
    //     0x711d88: b.eq            #0x711d90
    //     0x711d8c: bl              #0xd6826c
    // 0x711d90: r0 = Null
    //     0x711d90: mov             x0, NULL
    // 0x711d94: LeaveFrame
    //     0x711d94: mov             SP, fp
    //     0x711d98: ldp             fp, lr, [SP], #0x10
    // 0x711d9c: ret
    //     0x711d9c: ret             
    // 0x711da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711da0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711da4: b               #0x711d48
  }
  _ _updateChild(/* No info */) {
    // ** addr: 0x711da8, size: 0xa4
    // 0x711da8: EnterFrame
    //     0x711da8: stp             fp, lr, [SP, #-0x10]!
    //     0x711dac: mov             fp, SP
    // 0x711db0: CheckStackOverflow
    //     0x711db0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711db4: cmp             SP, x16
    //     0x711db8: b.ls            #0x711e44
    // 0x711dbc: ldr             x0, [fp, #0x20]
    // 0x711dc0: cmp             w0, NULL
    // 0x711dc4: b.eq            #0x711df4
    // 0x711dc8: ldr             x1, [fp, #0x28]
    // 0x711dcc: stp             x0, x1, [SP, #-0x10]!
    // 0x711dd0: r0 = dropChild()
    //     0x711dd0: bl              #0x5e5aec  ; [package:flutter/src/rendering/object.dart] RenderObject::dropChild
    // 0x711dd4: add             SP, SP, #0x10
    // 0x711dd8: ldr             x0, [fp, #0x28]
    // 0x711ddc: LoadField: r1 = r0->field_6f
    //     0x711ddc: ldur            w1, [x0, #0x6f]
    // 0x711de0: DecompressPointer r1
    //     0x711de0: add             x1, x1, HEAP, lsl #32
    // 0x711de4: ldr             x16, [fp, #0x10]
    // 0x711de8: stp             x16, x1, [SP, #-0x10]!
    // 0x711dec: r0 = remove()
    //     0x711dec: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x711df0: add             SP, SP, #0x10
    // 0x711df4: ldr             x0, [fp, #0x18]
    // 0x711df8: cmp             w0, NULL
    // 0x711dfc: b.eq            #0x711e34
    // 0x711e00: ldr             x1, [fp, #0x28]
    // 0x711e04: LoadField: r2 = r1->field_6f
    //     0x711e04: ldur            w2, [x1, #0x6f]
    // 0x711e08: DecompressPointer r2
    //     0x711e08: add             x2, x2, HEAP, lsl #32
    // 0x711e0c: ldr             x16, [fp, #0x10]
    // 0x711e10: stp             x16, x2, [SP, #-0x10]!
    // 0x711e14: SaveReg r0
    //     0x711e14: str             x0, [SP, #-8]!
    // 0x711e18: r0 = []=()
    //     0x711e18: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x711e1c: add             SP, SP, #0x18
    // 0x711e20: ldr             x16, [fp, #0x28]
    // 0x711e24: ldr             lr, [fp, #0x18]
    // 0x711e28: stp             lr, x16, [SP, #-0x10]!
    // 0x711e2c: r0 = adoptChild()
    //     0x711e2c: bl              #0x5e61d4  ; [package:flutter/src/rendering/object.dart] RenderObject::adoptChild
    // 0x711e30: add             SP, SP, #0x10
    // 0x711e34: ldr             x0, [fp, #0x18]
    // 0x711e38: LeaveFrame
    //     0x711e38: mov             SP, fp
    //     0x711e3c: ldp             fp, lr, [SP], #0x10
    // 0x711e40: ret
    //     0x711e40: ret             
    // 0x711e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711e48: b               #0x711dbc
  }
  set _ nextButton=(/* No info */) {
    // ** addr: 0x711e4c, size: 0x74
    // 0x711e4c: EnterFrame
    //     0x711e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x711e50: mov             fp, SP
    // 0x711e54: CheckStackOverflow
    //     0x711e54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711e58: cmp             SP, x16
    //     0x711e5c: b.ls            #0x711eb8
    // 0x711e60: ldr             x0, [fp, #0x18]
    // 0x711e64: LoadField: r1 = r0->field_87
    //     0x711e64: ldur            w1, [x0, #0x87]
    // 0x711e68: DecompressPointer r1
    //     0x711e68: add             x1, x1, HEAP, lsl #32
    // 0x711e6c: stp             x1, x0, [SP, #-0x10]!
    // 0x711e70: ldr             x16, [fp, #0x10]
    // 0x711e74: r30 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x711e74: add             lr, PP, #0x50, lsl #12  ; [pp+0x50d68] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65e11
    //     0x711e78: ldr             lr, [lr, #0xd68]
    // 0x711e7c: stp             lr, x16, [SP, #-0x10]!
    // 0x711e80: r0 = _updateChild()
    //     0x711e80: bl              #0x711da8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_updateChild
    // 0x711e84: add             SP, SP, #0x20
    // 0x711e88: ldr             x1, [fp, #0x18]
    // 0x711e8c: StoreField: r1->field_87 = r0
    //     0x711e8c: stur            w0, [x1, #0x87]
    //     0x711e90: ldurb           w16, [x1, #-1]
    //     0x711e94: ldurb           w17, [x0, #-1]
    //     0x711e98: and             x16, x17, x16, lsr #2
    //     0x711e9c: tst             x16, HEAP, lsr #32
    //     0x711ea0: b.eq            #0x711ea8
    //     0x711ea4: bl              #0xd6826c
    // 0x711ea8: r0 = Null
    //     0x711ea8: mov             x0, NULL
    // 0x711eac: LeaveFrame
    //     0x711eac: mov             SP, fp
    //     0x711eb0: ldp             fp, lr, [SP], #0x10
    // 0x711eb4: ret
    //     0x711eb4: ret             
    // 0x711eb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711eb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711ebc: b               #0x711e60
  }
  set _ backButton=(/* No info */) {
    // ** addr: 0x711ec0, size: 0x74
    // 0x711ec0: EnterFrame
    //     0x711ec0: stp             fp, lr, [SP, #-0x10]!
    //     0x711ec4: mov             fp, SP
    // 0x711ec8: CheckStackOverflow
    //     0x711ec8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711ecc: cmp             SP, x16
    //     0x711ed0: b.ls            #0x711f2c
    // 0x711ed4: ldr             x0, [fp, #0x18]
    // 0x711ed8: LoadField: r1 = r0->field_83
    //     0x711ed8: ldur            w1, [x0, #0x83]
    // 0x711edc: DecompressPointer r1
    //     0x711edc: add             x1, x1, HEAP, lsl #32
    // 0x711ee0: stp             x1, x0, [SP, #-0x10]!
    // 0x711ee4: ldr             x16, [fp, #0x10]
    // 0x711ee8: r30 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x711ee8: add             lr, PP, #0x50, lsl #12  ; [pp+0x50d60] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65e31
    //     0x711eec: ldr             lr, [lr, #0xd60]
    // 0x711ef0: stp             lr, x16, [SP, #-0x10]!
    // 0x711ef4: r0 = _updateChild()
    //     0x711ef4: bl              #0x711da8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_updateChild
    // 0x711ef8: add             SP, SP, #0x20
    // 0x711efc: ldr             x1, [fp, #0x18]
    // 0x711f00: StoreField: r1->field_83 = r0
    //     0x711f00: stur            w0, [x1, #0x83]
    //     0x711f04: ldurb           w16, [x1, #-1]
    //     0x711f08: ldurb           w17, [x0, #-1]
    //     0x711f0c: and             x16, x17, x16, lsr #2
    //     0x711f10: tst             x16, HEAP, lsr #32
    //     0x711f14: b.eq            #0x711f1c
    //     0x711f18: bl              #0xd6826c
    // 0x711f1c: r0 = Null
    //     0x711f1c: mov             x0, NULL
    // 0x711f20: LeaveFrame
    //     0x711f20: mov             SP, fp
    //     0x711f24: ldp             fp, lr, [SP], #0x10
    // 0x711f28: ret
    //     0x711f28: ret             
    // 0x711f2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711f2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711f30: b               #0x711ed4
  }
  _ redepthChildren(/* No info */) {
    // ** addr: 0x792c44, size: 0x60
    // 0x792c44: EnterFrame
    //     0x792c44: stp             fp, lr, [SP, #-0x10]!
    //     0x792c48: mov             fp, SP
    // 0x792c4c: CheckStackOverflow
    //     0x792c4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792c50: cmp             SP, x16
    //     0x792c54: b.ls            #0x792c9c
    // 0x792c58: r1 = 1
    //     0x792c58: mov             x1, #1
    // 0x792c5c: r0 = AllocateContext()
    //     0x792c5c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x792c60: mov             x1, x0
    // 0x792c64: ldr             x0, [fp, #0x10]
    // 0x792c68: StoreField: r1->field_f = r0
    //     0x792c68: stur            w0, [x1, #0xf]
    // 0x792c6c: mov             x2, x1
    // 0x792c70: r1 = Function '<anonymous closure>':.
    //     0x792c70: add             x1, PP, #0x50, lsl #12  ; [pp+0x50ef8] AnonymousClosure: (0x792ca4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::redepthChildren (0x792c44)
    //     0x792c74: ldr             x1, [x1, #0xef8]
    // 0x792c78: r0 = AllocateClosure()
    //     0x792c78: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x792c7c: ldr             x16, [fp, #0x10]
    // 0x792c80: stp             x0, x16, [SP, #-0x10]!
    // 0x792c84: r0 = visitChildren()
    //     0x792c84: bl              #0x6bf968  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::visitChildren
    // 0x792c88: add             SP, SP, #0x10
    // 0x792c8c: r0 = Null
    //     0x792c8c: mov             x0, NULL
    // 0x792c90: LeaveFrame
    //     0x792c90: mov             SP, fp
    //     0x792c94: ldp             fp, lr, [SP], #0x10
    // 0x792c98: ret
    //     0x792c98: ret             
    // 0x792c9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792c9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792ca0: b               #0x792c58
  }
  [closure] void <anonymous closure>(dynamic, RenderObject) {
    // ** addr: 0x792ca4, size: 0x90
    // 0x792ca4: EnterFrame
    //     0x792ca4: stp             fp, lr, [SP, #-0x10]!
    //     0x792ca8: mov             fp, SP
    // 0x792cac: AllocStack(0x8)
    //     0x792cac: sub             SP, SP, #8
    // 0x792cb0: SetupParameters()
    //     0x792cb0: ldr             x0, [fp, #0x18]
    //     0x792cb4: ldur            w3, [x0, #0x17]
    //     0x792cb8: add             x3, x3, HEAP, lsl #32
    //     0x792cbc: stur            x3, [fp, #-8]
    // 0x792cc0: CheckStackOverflow
    //     0x792cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x792cc4: cmp             SP, x16
    //     0x792cc8: b.ls            #0x792d2c
    // 0x792ccc: ldr             x0, [fp, #0x10]
    // 0x792cd0: r2 = Null
    //     0x792cd0: mov             x2, NULL
    // 0x792cd4: r1 = Null
    //     0x792cd4: mov             x1, NULL
    // 0x792cd8: r4 = LoadClassIdInstr(r0)
    //     0x792cd8: ldur            x4, [x0, #-1]
    //     0x792cdc: ubfx            x4, x4, #0xc, #0x14
    // 0x792ce0: sub             x4, x4, #0x965
    // 0x792ce4: cmp             x4, #0x8b
    // 0x792ce8: b.ls            #0x792d00
    // 0x792cec: r8 = RenderBox
    //     0x792cec: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x792cf0: ldr             x8, [x8, #0xfa0]
    // 0x792cf4: r3 = Null
    //     0x792cf4: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f00] Null
    //     0x792cf8: ldr             x3, [x3, #0xf00]
    // 0x792cfc: r0 = RenderBox()
    //     0x792cfc: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x792d00: ldur            x0, [fp, #-8]
    // 0x792d04: LoadField: r1 = r0->field_f
    //     0x792d04: ldur            w1, [x0, #0xf]
    // 0x792d08: DecompressPointer r1
    //     0x792d08: add             x1, x1, HEAP, lsl #32
    // 0x792d0c: ldr             x16, [fp, #0x10]
    // 0x792d10: stp             x16, x1, [SP, #-0x10]!
    // 0x792d14: r0 = redepthChild()
    //     0x792d14: bl              #0x5e631c  ; [package:flutter/src/foundation/node.dart] AbstractNode::redepthChild
    // 0x792d18: add             SP, SP, #0x10
    // 0x792d1c: r0 = Null
    //     0x792d1c: mov             x0, NULL
    // 0x792d20: LeaveFrame
    //     0x792d20: mov             SP, fp
    //     0x792d24: ldp             fp, lr, [SP], #0x10
    // 0x792d28: ret
    //     0x792d28: ret             
    // 0x792d2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x792d2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x792d30: b               #0x792ccc
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bd7dc, size: 0x150
    // 0x9bd7dc: EnterFrame
    //     0x9bd7dc: stp             fp, lr, [SP, #-0x10]!
    //     0x9bd7e0: mov             fp, SP
    // 0x9bd7e4: AllocStack(0x18)
    //     0x9bd7e4: sub             SP, SP, #0x18
    // 0x9bd7e8: CheckStackOverflow
    //     0x9bd7e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd7ec: cmp             SP, x16
    //     0x9bd7f0: b.ls            #0x9bd91c
    // 0x9bd7f4: ldr             x0, [fp, #0x10]
    // 0x9bd7f8: r2 = Null
    //     0x9bd7f8: mov             x2, NULL
    // 0x9bd7fc: r1 = Null
    //     0x9bd7fc: mov             x1, NULL
    // 0x9bd800: r4 = 59
    //     0x9bd800: mov             x4, #0x3b
    // 0x9bd804: branchIfSmi(r0, 0x9bd810)
    //     0x9bd804: tbz             w0, #0, #0x9bd810
    // 0x9bd808: r4 = LoadClassIdInstr(r0)
    //     0x9bd808: ldur            x4, [x0, #-1]
    //     0x9bd80c: ubfx            x4, x4, #0xc, #0x14
    // 0x9bd810: cmp             x4, #0x7e6
    // 0x9bd814: b.eq            #0x9bd828
    // 0x9bd818: r8 = PipelineOwner
    //     0x9bd818: ldr             x8, [PP, #0x4da8]  ; [pp+0x4da8] Type: PipelineOwner
    // 0x9bd81c: r3 = Null
    //     0x9bd81c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f20] Null
    //     0x9bd820: ldr             x3, [x3, #0xf20]
    // 0x9bd824: r0 = DefaultTypeTest()
    //     0x9bd824: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bd828: ldr             x16, [fp, #0x18]
    // 0x9bd82c: ldr             lr, [fp, #0x10]
    // 0x9bd830: stp             lr, x16, [SP, #-0x10]!
    // 0x9bd834: r0 = attach()
    //     0x9bd834: bl              #0x9bd92c  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::attach
    // 0x9bd838: add             SP, SP, #0x10
    // 0x9bd83c: ldr             x0, [fp, #0x18]
    // 0x9bd840: LoadField: r1 = r0->field_6f
    //     0x9bd840: ldur            w1, [x0, #0x6f]
    // 0x9bd844: DecompressPointer r1
    //     0x9bd844: add             x1, x1, HEAP, lsl #32
    // 0x9bd848: SaveReg r1
    //     0x9bd848: str             x1, [SP, #-8]!
    // 0x9bd84c: r0 = values()
    //     0x9bd84c: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0x9bd850: add             SP, SP, #8
    // 0x9bd854: SaveReg r0
    //     0x9bd854: str             x0, [SP, #-8]!
    // 0x9bd858: r0 = iterator()
    //     0x9bd858: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x9bd85c: add             SP, SP, #8
    // 0x9bd860: stur            x0, [fp, #-0x10]
    // 0x9bd864: LoadField: r2 = r0->field_7
    //     0x9bd864: ldur            w2, [x0, #7]
    // 0x9bd868: DecompressPointer r2
    //     0x9bd868: add             x2, x2, HEAP, lsl #32
    // 0x9bd86c: stur            x2, [fp, #-8]
    // 0x9bd870: CheckStackOverflow
    //     0x9bd870: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bd874: cmp             SP, x16
    //     0x9bd878: b.ls            #0x9bd924
    // 0x9bd87c: SaveReg r0
    //     0x9bd87c: str             x0, [SP, #-8]!
    // 0x9bd880: r0 = moveNext()
    //     0x9bd880: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x9bd884: add             SP, SP, #8
    // 0x9bd888: tbnz            w0, #4, #0x9bd90c
    // 0x9bd88c: ldur            x3, [fp, #-0x10]
    // 0x9bd890: LoadField: r4 = r3->field_33
    //     0x9bd890: ldur            w4, [x3, #0x33]
    // 0x9bd894: DecompressPointer r4
    //     0x9bd894: add             x4, x4, HEAP, lsl #32
    // 0x9bd898: stur            x4, [fp, #-0x18]
    // 0x9bd89c: cmp             w4, NULL
    // 0x9bd8a0: b.ne            #0x9bd8d4
    // 0x9bd8a4: mov             x0, x4
    // 0x9bd8a8: ldur            x2, [fp, #-8]
    // 0x9bd8ac: r1 = Null
    //     0x9bd8ac: mov             x1, NULL
    // 0x9bd8b0: cmp             w2, NULL
    // 0x9bd8b4: b.eq            #0x9bd8d4
    // 0x9bd8b8: LoadField: r4 = r2->field_17
    //     0x9bd8b8: ldur            w4, [x2, #0x17]
    // 0x9bd8bc: DecompressPointer r4
    //     0x9bd8bc: add             x4, x4, HEAP, lsl #32
    // 0x9bd8c0: r8 = X0
    //     0x9bd8c0: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x9bd8c4: LoadField: r9 = r4->field_7
    //     0x9bd8c4: ldur            x9, [x4, #7]
    // 0x9bd8c8: r3 = Null
    //     0x9bd8c8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f30] Null
    //     0x9bd8cc: ldr             x3, [x3, #0xf30]
    // 0x9bd8d0: blr             x9
    // 0x9bd8d4: ldur            x0, [fp, #-0x18]
    // 0x9bd8d8: r1 = LoadClassIdInstr(r0)
    //     0x9bd8d8: ldur            x1, [x0, #-1]
    //     0x9bd8dc: ubfx            x1, x1, #0xc, #0x14
    // 0x9bd8e0: ldr             x16, [fp, #0x10]
    // 0x9bd8e4: stp             x16, x0, [SP, #-0x10]!
    // 0x9bd8e8: mov             x0, x1
    // 0x9bd8ec: r0 = GDT[cid_x0 + 0xaf1f]()
    //     0x9bd8ec: mov             x17, #0xaf1f
    //     0x9bd8f0: add             lr, x0, x17
    //     0x9bd8f4: ldr             lr, [x21, lr, lsl #3]
    //     0x9bd8f8: blr             lr
    // 0x9bd8fc: add             SP, SP, #0x10
    // 0x9bd900: ldur            x0, [fp, #-0x10]
    // 0x9bd904: ldur            x2, [fp, #-8]
    // 0x9bd908: b               #0x9bd870
    // 0x9bd90c: r0 = Null
    //     0x9bd90c: mov             x0, NULL
    // 0x9bd910: LeaveFrame
    //     0x9bd910: mov             SP, fp
    //     0x9bd914: ldp             fp, lr, [SP], #0x10
    // 0x9bd918: ret
    //     0x9bd918: ret             
    // 0x9bd91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd91c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd920: b               #0x9bd7f4
    // 0x9bd924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bd924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bd928: b               #0x9bd87c
  }
  _ detach(/* No info */) {
    // ** addr: 0xa694d4, size: 0x114
    // 0xa694d4: EnterFrame
    //     0xa694d4: stp             fp, lr, [SP, #-0x10]!
    //     0xa694d8: mov             fp, SP
    // 0xa694dc: AllocStack(0x18)
    //     0xa694dc: sub             SP, SP, #0x18
    // 0xa694e0: CheckStackOverflow
    //     0xa694e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa694e4: cmp             SP, x16
    //     0xa694e8: b.ls            #0xa695d8
    // 0xa694ec: ldr             x16, [fp, #0x10]
    // 0xa694f0: SaveReg r16
    //     0xa694f0: str             x16, [SP, #-8]!
    // 0xa694f4: r0 = detach()
    //     0xa694f4: bl              #0xa695e8  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::detach
    // 0xa694f8: add             SP, SP, #8
    // 0xa694fc: ldr             x0, [fp, #0x10]
    // 0xa69500: LoadField: r1 = r0->field_6f
    //     0xa69500: ldur            w1, [x0, #0x6f]
    // 0xa69504: DecompressPointer r1
    //     0xa69504: add             x1, x1, HEAP, lsl #32
    // 0xa69508: SaveReg r1
    //     0xa69508: str             x1, [SP, #-8]!
    // 0xa6950c: r0 = values()
    //     0xa6950c: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xa69510: add             SP, SP, #8
    // 0xa69514: SaveReg r0
    //     0xa69514: str             x0, [SP, #-8]!
    // 0xa69518: r0 = iterator()
    //     0xa69518: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0xa6951c: add             SP, SP, #8
    // 0xa69520: stur            x0, [fp, #-0x10]
    // 0xa69524: LoadField: r2 = r0->field_7
    //     0xa69524: ldur            w2, [x0, #7]
    // 0xa69528: DecompressPointer r2
    //     0xa69528: add             x2, x2, HEAP, lsl #32
    // 0xa6952c: stur            x2, [fp, #-8]
    // 0xa69530: CheckStackOverflow
    //     0xa69530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa69534: cmp             SP, x16
    //     0xa69538: b.ls            #0xa695e0
    // 0xa6953c: SaveReg r0
    //     0xa6953c: str             x0, [SP, #-8]!
    // 0xa69540: r0 = moveNext()
    //     0xa69540: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0xa69544: add             SP, SP, #8
    // 0xa69548: tbnz            w0, #4, #0xa695c8
    // 0xa6954c: ldur            x3, [fp, #-0x10]
    // 0xa69550: LoadField: r4 = r3->field_33
    //     0xa69550: ldur            w4, [x3, #0x33]
    // 0xa69554: DecompressPointer r4
    //     0xa69554: add             x4, x4, HEAP, lsl #32
    // 0xa69558: stur            x4, [fp, #-0x18]
    // 0xa6955c: cmp             w4, NULL
    // 0xa69560: b.ne            #0xa69594
    // 0xa69564: mov             x0, x4
    // 0xa69568: ldur            x2, [fp, #-8]
    // 0xa6956c: r1 = Null
    //     0xa6956c: mov             x1, NULL
    // 0xa69570: cmp             w2, NULL
    // 0xa69574: b.eq            #0xa69594
    // 0xa69578: LoadField: r4 = r2->field_17
    //     0xa69578: ldur            w4, [x2, #0x17]
    // 0xa6957c: DecompressPointer r4
    //     0xa6957c: add             x4, x4, HEAP, lsl #32
    // 0xa69580: r8 = X0
    //     0xa69580: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xa69584: LoadField: r9 = r4->field_7
    //     0xa69584: ldur            x9, [x4, #7]
    // 0xa69588: r3 = Null
    //     0xa69588: add             x3, PP, #0x50, lsl #12  ; [pp+0x50f10] Null
    //     0xa6958c: ldr             x3, [x3, #0xf10]
    // 0xa69590: blr             x9
    // 0xa69594: ldur            x0, [fp, #-0x18]
    // 0xa69598: r1 = LoadClassIdInstr(r0)
    //     0xa69598: ldur            x1, [x0, #-1]
    //     0xa6959c: ubfx            x1, x1, #0xc, #0x14
    // 0xa695a0: SaveReg r0
    //     0xa695a0: str             x0, [SP, #-8]!
    // 0xa695a4: mov             x0, x1
    // 0xa695a8: r0 = GDT[cid_x0 + 0xa3cc]()
    //     0xa695a8: mov             x17, #0xa3cc
    //     0xa695ac: add             lr, x0, x17
    //     0xa695b0: ldr             lr, [x21, lr, lsl #3]
    //     0xa695b4: blr             lr
    // 0xa695b8: add             SP, SP, #8
    // 0xa695bc: ldur            x0, [fp, #-0x10]
    // 0xa695c0: ldur            x2, [fp, #-8]
    // 0xa695c4: b               #0xa69530
    // 0xa695c8: r0 = Null
    //     0xa695c8: mov             x0, NULL
    // 0xa695cc: LeaveFrame
    //     0xa695cc: mov             SP, fp
    //     0xa695d0: ldp             fp, lr, [SP], #0x10
    // 0xa695d4: ret
    //     0xa695d4: ret             
    // 0xa695d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa695d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa695dc: b               #0xa694ec
    // 0xa695e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa695e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa695e4: b               #0xa6953c
  }
}

// class id: 2472, size: 0x74, field offset: 0x64
class _RenderCupertinoTextSelectionToolbarShape extends RenderShiftedBox {

  _ hitTestChildren(/* No info */) {
    // ** addr: 0x6273ec, size: 0x15c
    // 0x6273ec: EnterFrame
    //     0x6273ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6273f0: mov             fp, SP
    // 0x6273f4: AllocStack(0x30)
    //     0x6273f4: sub             SP, SP, #0x30
    // 0x6273f8: CheckStackOverflow
    //     0x6273f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6273fc: cmp             SP, x16
    //     0x627400: b.ls            #0x627534
    // 0x627404: ldr             x3, [fp, #0x20]
    // 0x627408: LoadField: r4 = r3->field_5f
    //     0x627408: ldur            w4, [x3, #0x5f]
    // 0x62740c: DecompressPointer r4
    //     0x62740c: add             x4, x4, HEAP, lsl #32
    // 0x627410: stur            x4, [fp, #-0x10]
    // 0x627414: cmp             w4, NULL
    // 0x627418: b.eq            #0x62753c
    // 0x62741c: LoadField: r5 = r4->field_17
    //     0x62741c: ldur            w5, [x4, #0x17]
    // 0x627420: DecompressPointer r5
    //     0x627420: add             x5, x5, HEAP, lsl #32
    // 0x627424: stur            x5, [fp, #-8]
    // 0x627428: cmp             w5, NULL
    // 0x62742c: b.eq            #0x627540
    // 0x627430: mov             x0, x5
    // 0x627434: r2 = Null
    //     0x627434: mov             x2, NULL
    // 0x627438: r1 = Null
    //     0x627438: mov             x1, NULL
    // 0x62743c: r4 = LoadClassIdInstr(r0)
    //     0x62743c: ldur            x4, [x0, #-1]
    //     0x627440: ubfx            x4, x4, #0xc, #0x14
    // 0x627444: sub             x4, x4, #0x7ff
    // 0x627448: cmp             x4, #0xb
    // 0x62744c: b.ls            #0x627464
    // 0x627450: r8 = BoxParentData
    //     0x627450: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x627454: ldr             x8, [x8, #0x1b0]
    // 0x627458: r3 = Null
    //     0x627458: add             x3, PP, #0x37, lsl #12  ; [pp+0x37be8] Null
    //     0x62745c: ldr             x3, [x3, #0xbe8]
    // 0x627460: r0 = DefaultTypeTest()
    //     0x627460: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x627464: ldur            x0, [fp, #-8]
    // 0x627468: LoadField: r1 = r0->field_7
    //     0x627468: ldur            w1, [x0, #7]
    // 0x62746c: DecompressPointer r1
    //     0x62746c: add             x1, x1, HEAP, lsl #32
    // 0x627470: LoadField: d0 = r1->field_7
    //     0x627470: ldur            d0, [x1, #7]
    // 0x627474: stur            d0, [fp, #-0x30]
    // 0x627478: LoadField: d1 = r1->field_f
    //     0x627478: ldur            d1, [x1, #0xf]
    // 0x62747c: r0 = Instance_Size
    //     0x62747c: add             x0, PP, #0x37, lsl #12  ; [pp+0x37bf8] Obj!Size@b5ec71
    //     0x627480: ldr             x0, [x0, #0xbf8]
    // 0x627484: LoadField: d2 = r0->field_f
    //     0x627484: ldur            d2, [x0, #0xf]
    // 0x627488: fadd            d3, d1, d2
    // 0x62748c: ldur            x0, [fp, #-0x10]
    // 0x627490: stur            d3, [fp, #-0x28]
    // 0x627494: LoadField: r1 = r0->field_57
    //     0x627494: ldur            w1, [x0, #0x57]
    // 0x627498: DecompressPointer r1
    //     0x627498: add             x1, x1, HEAP, lsl #32
    // 0x62749c: cmp             w1, NULL
    // 0x6274a0: b.eq            #0x627544
    // 0x6274a4: LoadField: d1 = r1->field_7
    //     0x6274a4: ldur            d1, [x1, #7]
    // 0x6274a8: LoadField: d2 = r1->field_f
    //     0x6274a8: ldur            d2, [x1, #0xf]
    // 0x6274ac: d4 = 14.000000
    //     0x6274ac: fmov            d4, #14.00000000
    // 0x6274b0: fsub            d5, d2, d4
    // 0x6274b4: fadd            d2, d0, d1
    // 0x6274b8: stur            d2, [fp, #-0x20]
    // 0x6274bc: fadd            d1, d3, d5
    // 0x6274c0: stur            d1, [fp, #-0x18]
    // 0x6274c4: r0 = Rect()
    //     0x6274c4: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x6274c8: ldur            d0, [fp, #-0x30]
    // 0x6274cc: StoreField: r0->field_7 = d0
    //     0x6274cc: stur            d0, [x0, #7]
    // 0x6274d0: ldur            d0, [fp, #-0x28]
    // 0x6274d4: StoreField: r0->field_f = d0
    //     0x6274d4: stur            d0, [x0, #0xf]
    // 0x6274d8: ldur            d0, [fp, #-0x20]
    // 0x6274dc: StoreField: r0->field_17 = d0
    //     0x6274dc: stur            d0, [x0, #0x17]
    // 0x6274e0: ldur            d0, [fp, #-0x18]
    // 0x6274e4: StoreField: r0->field_1f = d0
    //     0x6274e4: stur            d0, [x0, #0x1f]
    // 0x6274e8: ldr             x16, [fp, #0x10]
    // 0x6274ec: stp             x16, x0, [SP, #-0x10]!
    // 0x6274f0: r0 = contains()
    //     0x6274f0: bl              #0x627548  ; [dart:ui] Rect::contains
    // 0x6274f4: add             SP, SP, #0x10
    // 0x6274f8: tbz             w0, #4, #0x62750c
    // 0x6274fc: r0 = false
    //     0x6274fc: add             x0, NULL, #0x30  ; false
    // 0x627500: LeaveFrame
    //     0x627500: mov             SP, fp
    //     0x627504: ldp             fp, lr, [SP], #0x10
    // 0x627508: ret
    //     0x627508: ret             
    // 0x62750c: ldr             x16, [fp, #0x20]
    // 0x627510: ldr             lr, [fp, #0x18]
    // 0x627514: stp             lr, x16, [SP, #-0x10]!
    // 0x627518: ldr             x16, [fp, #0x10]
    // 0x62751c: SaveReg r16
    //     0x62751c: str             x16, [SP, #-8]!
    // 0x627520: r0 = hitTestChildren()
    //     0x627520: bl              #0x6275b4  ; [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren
    // 0x627524: add             SP, SP, #0x18
    // 0x627528: LeaveFrame
    //     0x627528: mov             SP, fp
    //     0x62752c: ldp             fp, lr, [SP], #0x10
    // 0x627530: ret
    //     0x627530: ret             
    // 0x627534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x627534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x627538: b               #0x627404
    // 0x62753c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62753c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x627540: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x627540: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x627544: r0 = NullCastErrorSharedWithFPURegs()
    //     0x627544: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ paint(/* No info */) {
    // ** addr: 0x66853c, size: 0x1c4
    // 0x66853c: EnterFrame
    //     0x66853c: stp             fp, lr, [SP, #-0x10]!
    //     0x668540: mov             fp, SP
    // 0x668544: AllocStack(0x38)
    //     0x668544: sub             SP, SP, #0x38
    // 0x668548: CheckStackOverflow
    //     0x668548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x66854c: cmp             SP, x16
    //     0x668550: b.ls            #0x6686e4
    // 0x668554: r1 = 1
    //     0x668554: mov             x1, #1
    // 0x668558: r0 = AllocateContext()
    //     0x668558: bl              #0xd68aa4  ; AllocateContextStub
    // 0x66855c: mov             x4, x0
    // 0x668560: ldr             x3, [fp, #0x20]
    // 0x668564: stur            x4, [fp, #-0x10]
    // 0x668568: StoreField: r4->field_f = r3
    //     0x668568: stur            w3, [x4, #0xf]
    // 0x66856c: LoadField: r0 = r3->field_5f
    //     0x66856c: ldur            w0, [x3, #0x5f]
    // 0x668570: DecompressPointer r0
    //     0x668570: add             x0, x0, HEAP, lsl #32
    // 0x668574: cmp             w0, NULL
    // 0x668578: b.ne            #0x66858c
    // 0x66857c: r0 = Null
    //     0x66857c: mov             x0, NULL
    // 0x668580: LeaveFrame
    //     0x668580: mov             SP, fp
    //     0x668584: ldp             fp, lr, [SP], #0x10
    // 0x668588: ret
    //     0x668588: ret             
    // 0x66858c: LoadField: r5 = r0->field_17
    //     0x66858c: ldur            w5, [x0, #0x17]
    // 0x668590: DecompressPointer r5
    //     0x668590: add             x5, x5, HEAP, lsl #32
    // 0x668594: stur            x5, [fp, #-8]
    // 0x668598: cmp             w5, NULL
    // 0x66859c: b.eq            #0x6686ec
    // 0x6685a0: mov             x0, x5
    // 0x6685a4: r2 = Null
    //     0x6685a4: mov             x2, NULL
    // 0x6685a8: r1 = Null
    //     0x6685a8: mov             x1, NULL
    // 0x6685ac: r4 = LoadClassIdInstr(r0)
    //     0x6685ac: ldur            x4, [x0, #-1]
    //     0x6685b0: ubfx            x4, x4, #0xc, #0x14
    // 0x6685b4: sub             x4, x4, #0x7ff
    // 0x6685b8: cmp             x4, #0xb
    // 0x6685bc: b.ls            #0x6685d4
    // 0x6685c0: r8 = BoxParentData
    //     0x6685c0: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x6685c4: ldr             x8, [x8, #0x1b0]
    // 0x6685c8: r3 = Null
    //     0x6685c8: add             x3, PP, #0x37, lsl #12  ; [pp+0x37c00] Null
    //     0x6685cc: ldr             x3, [x3, #0xc00]
    // 0x6685d0: r0 = DefaultTypeTest()
    //     0x6685d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6685d4: ldr             x0, [fp, #0x20]
    // 0x6685d8: LoadField: r1 = r0->field_6f
    //     0x6685d8: ldur            w1, [x0, #0x6f]
    // 0x6685dc: DecompressPointer r1
    //     0x6685dc: add             x1, x1, HEAP, lsl #32
    // 0x6685e0: stur            x1, [fp, #-0x20]
    // 0x6685e4: LoadField: r2 = r0->field_37
    //     0x6685e4: ldur            w2, [x0, #0x37]
    // 0x6685e8: DecompressPointer r2
    //     0x6685e8: add             x2, x2, HEAP, lsl #32
    // 0x6685ec: r16 = Sentinel
    //     0x6685ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6685f0: cmp             w2, w16
    // 0x6685f4: b.eq            #0x6686f0
    // 0x6685f8: ldur            x3, [fp, #-8]
    // 0x6685fc: stur            x2, [fp, #-0x18]
    // 0x668600: LoadField: r4 = r3->field_7
    //     0x668600: ldur            w4, [x3, #7]
    // 0x668604: DecompressPointer r4
    //     0x668604: add             x4, x4, HEAP, lsl #32
    // 0x668608: ldr             x16, [fp, #0x10]
    // 0x66860c: stp             x4, x16, [SP, #-0x10]!
    // 0x668610: r0 = +()
    //     0x668610: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x668614: add             SP, SP, #0x10
    // 0x668618: mov             x1, x0
    // 0x66861c: ldr             x0, [fp, #0x20]
    // 0x668620: stur            x1, [fp, #-8]
    // 0x668624: LoadField: r2 = r0->field_5f
    //     0x668624: ldur            w2, [x0, #0x5f]
    // 0x668628: DecompressPointer r2
    //     0x668628: add             x2, x2, HEAP, lsl #32
    // 0x66862c: cmp             w2, NULL
    // 0x668630: b.eq            #0x6686f8
    // 0x668634: LoadField: r3 = r2->field_57
    //     0x668634: ldur            w3, [x2, #0x57]
    // 0x668638: DecompressPointer r3
    //     0x668638: add             x3, x3, HEAP, lsl #32
    // 0x66863c: cmp             w3, NULL
    // 0x668640: b.eq            #0x6686fc
    // 0x668644: r16 = Instance_Offset
    //     0x668644: ldr             x16, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x668648: stp             x3, x16, [SP, #-0x10]!
    // 0x66864c: r0 = &()
    //     0x66864c: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x668650: add             SP, SP, #0x10
    // 0x668654: stur            x0, [fp, #-0x28]
    // 0x668658: ldr             x16, [fp, #0x20]
    // 0x66865c: SaveReg r16
    //     0x66865c: str             x16, [SP, #-8]!
    // 0x668660: r0 = _clipPath()
    //     0x668660: bl              #0x668700  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_clipPath
    // 0x668664: add             SP, SP, #8
    // 0x668668: mov             x3, x0
    // 0x66866c: ldur            x0, [fp, #-0x20]
    // 0x668670: stur            x3, [fp, #-0x38]
    // 0x668674: LoadField: r4 = r0->field_b
    //     0x668674: ldur            w4, [x0, #0xb]
    // 0x668678: DecompressPointer r4
    //     0x668678: add             x4, x4, HEAP, lsl #32
    // 0x66867c: ldur            x2, [fp, #-0x10]
    // 0x668680: stur            x4, [fp, #-0x30]
    // 0x668684: r1 = Function '<anonymous closure>':.
    //     0x668684: add             x1, PP, #0x37, lsl #12  ; [pp+0x37c10] AnonymousClosure: (0x6697ac), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::paint (0x66853c)
    //     0x668688: ldr             x1, [x1, #0xc10]
    // 0x66868c: r0 = AllocateClosure()
    //     0x66868c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x668690: ldr             x16, [fp, #0x18]
    // 0x668694: ldur            lr, [fp, #-0x18]
    // 0x668698: stp             lr, x16, [SP, #-0x10]!
    // 0x66869c: ldur            x16, [fp, #-8]
    // 0x6686a0: ldur            lr, [fp, #-0x28]
    // 0x6686a4: stp             lr, x16, [SP, #-0x10]!
    // 0x6686a8: ldur            x16, [fp, #-0x38]
    // 0x6686ac: stp             x0, x16, [SP, #-0x10]!
    // 0x6686b0: ldur            x16, [fp, #-0x30]
    // 0x6686b4: SaveReg r16
    //     0x6686b4: str             x16, [SP, #-8]!
    // 0x6686b8: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0x6686b8: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0x6686bc: r0 = pushClipPath()
    //     0x6686bc: bl              #0x6626a0  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushClipPath
    // 0x6686c0: add             SP, SP, #0x38
    // 0x6686c4: ldur            x16, [fp, #-0x20]
    // 0x6686c8: stp             x0, x16, [SP, #-0x10]!
    // 0x6686cc: r0 = layer=()
    //     0x6686cc: bl              #0x5bbc7c  ; [package:flutter/src/rendering/layer.dart] LayerHandle::layer=
    // 0x6686d0: add             SP, SP, #0x10
    // 0x6686d4: r0 = Null
    //     0x6686d4: mov             x0, NULL
    // 0x6686d8: LeaveFrame
    //     0x6686d8: mov             SP, fp
    //     0x6686dc: ldp             fp, lr, [SP], #0x10
    // 0x6686e0: ret
    //     0x6686e0: ret             
    // 0x6686e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6686e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6686e8: b               #0x668554
    // 0x6686ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6686ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6686f0: r9 = _needsCompositing
    //     0x6686f0: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x6686f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6686f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6686f8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6686f8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6686fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6686fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _clipPath(/* No info */) {
    // ** addr: 0x668700, size: 0x37c
    // 0x668700: EnterFrame
    //     0x668700: stp             fp, lr, [SP, #-0x10]!
    //     0x668704: mov             fp, SP
    // 0x668708: AllocStack(0x38)
    //     0x668708: sub             SP, SP, #0x38
    // 0x66870c: CheckStackOverflow
    //     0x66870c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x668710: cmp             SP, x16
    //     0x668714: b.ls            #0x668a24
    // 0x668718: ldr             x3, [fp, #0x10]
    // 0x66871c: LoadField: r0 = r3->field_5f
    //     0x66871c: ldur            w0, [x3, #0x5f]
    // 0x668720: DecompressPointer r0
    //     0x668720: add             x0, x0, HEAP, lsl #32
    // 0x668724: cmp             w0, NULL
    // 0x668728: b.eq            #0x668a2c
    // 0x66872c: LoadField: r4 = r0->field_17
    //     0x66872c: ldur            w4, [x0, #0x17]
    // 0x668730: DecompressPointer r4
    //     0x668730: add             x4, x4, HEAP, lsl #32
    // 0x668734: stur            x4, [fp, #-8]
    // 0x668738: cmp             w4, NULL
    // 0x66873c: b.eq            #0x668a30
    // 0x668740: mov             x0, x4
    // 0x668744: r2 = Null
    //     0x668744: mov             x2, NULL
    // 0x668748: r1 = Null
    //     0x668748: mov             x1, NULL
    // 0x66874c: r4 = LoadClassIdInstr(r0)
    //     0x66874c: ldur            x4, [x0, #-1]
    //     0x668750: ubfx            x4, x4, #0xc, #0x14
    // 0x668754: sub             x4, x4, #0x7ff
    // 0x668758: cmp             x4, #0xb
    // 0x66875c: b.ls            #0x668774
    // 0x668760: r8 = BoxParentData
    //     0x668760: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x668764: ldr             x8, [x8, #0x1b0]
    // 0x668768: r3 = Null
    //     0x668768: add             x3, PP, #0x37, lsl #12  ; [pp+0x37c18] Null
    //     0x66876c: ldr             x3, [x3, #0xc18]
    // 0x668770: r0 = DefaultTypeTest()
    //     0x668770: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x668774: r0 = Path()
    //     0x668774: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x668778: stur            x0, [fp, #-0x10]
    // 0x66877c: SaveReg r0
    //     0x66877c: str             x0, [SP, #-8]!
    // 0x668780: r0 = _constructor()
    //     0x668780: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x668784: add             SP, SP, #8
    // 0x668788: r0 = Instance_Size
    //     0x668788: add             x0, PP, #0x37, lsl #12  ; [pp+0x37bf8] Obj!Size@b5ec71
    //     0x66878c: ldr             x0, [x0, #0xbf8]
    // 0x668790: LoadField: d0 = r0->field_f
    //     0x668790: ldur            d0, [x0, #0xf]
    // 0x668794: stur            d0, [fp, #-0x28]
    // 0x668798: r0 = Offset()
    //     0x668798: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x66879c: d0 = 0.000000
    //     0x66879c: eor             v0.16b, v0.16b, v0.16b
    // 0x6687a0: stur            x0, [fp, #-0x18]
    // 0x6687a4: StoreField: r0->field_7 = d0
    //     0x6687a4: stur            d0, [x0, #7]
    // 0x6687a8: ldur            d0, [fp, #-0x28]
    // 0x6687ac: StoreField: r0->field_f = d0
    //     0x6687ac: stur            d0, [x0, #0xf]
    // 0x6687b0: ldr             x1, [fp, #0x10]
    // 0x6687b4: LoadField: r2 = r1->field_5f
    //     0x6687b4: ldur            w2, [x1, #0x5f]
    // 0x6687b8: DecompressPointer r2
    //     0x6687b8: add             x2, x2, HEAP, lsl #32
    // 0x6687bc: cmp             w2, NULL
    // 0x6687c0: b.eq            #0x668a34
    // 0x6687c4: LoadField: r3 = r2->field_57
    //     0x6687c4: ldur            w3, [x2, #0x57]
    // 0x6687c8: DecompressPointer r3
    //     0x6687c8: add             x3, x3, HEAP, lsl #32
    // 0x6687cc: cmp             w3, NULL
    // 0x6687d0: b.eq            #0x668a38
    // 0x6687d4: LoadField: d1 = r3->field_7
    //     0x6687d4: ldur            d1, [x3, #7]
    // 0x6687d8: stur            d1, [fp, #-0x38]
    // 0x6687dc: LoadField: d2 = r3->field_f
    //     0x6687dc: ldur            d2, [x3, #0xf]
    // 0x6687e0: d3 = 14.000000
    //     0x6687e0: fmov            d3, #14.00000000
    // 0x6687e4: fsub            d4, d2, d3
    // 0x6687e8: stur            d4, [fp, #-0x30]
    // 0x6687ec: r0 = Size()
    //     0x6687ec: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x6687f0: ldur            d0, [fp, #-0x38]
    // 0x6687f4: StoreField: r0->field_7 = d0
    //     0x6687f4: stur            d0, [x0, #7]
    // 0x6687f8: ldur            d0, [fp, #-0x30]
    // 0x6687fc: StoreField: r0->field_f = d0
    //     0x6687fc: stur            d0, [x0, #0xf]
    // 0x668800: ldur            x16, [fp, #-0x18]
    // 0x668804: stp             x0, x16, [SP, #-0x10]!
    // 0x668808: r0 = &()
    //     0x668808: bl              #0x50dfa4  ; [dart:ui] Offset::&
    // 0x66880c: add             SP, SP, #0x10
    // 0x668810: stur            x0, [fp, #-0x18]
    // 0x668814: r0 = RRect()
    //     0x668814: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x668818: stur            x0, [fp, #-0x20]
    // 0x66881c: ldur            x16, [fp, #-0x18]
    // 0x668820: stp             x16, x0, [SP, #-0x10]!
    // 0x668824: r16 = Instance_Radius
    //     0x668824: add             x16, PP, #0x37, lsl #12  ; [pp+0x37c28] Obj!Radius@b5e801
    //     0x668828: ldr             x16, [x16, #0xc28]
    // 0x66882c: SaveReg r16
    //     0x66882c: str             x16, [SP, #-8]!
    // 0x668830: r0 = RRect.fromRectAndRadius()
    //     0x668830: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x668834: add             SP, SP, #0x18
    // 0x668838: ldur            x16, [fp, #-0x10]
    // 0x66883c: ldur            lr, [fp, #-0x20]
    // 0x668840: stp             lr, x16, [SP, #-0x10]!
    // 0x668844: r0 = addRRect()
    //     0x668844: bl              #0x664194  ; [dart:ui] Path::addRRect
    // 0x668848: add             SP, SP, #0x10
    // 0x66884c: ldr             x0, [fp, #0x10]
    // 0x668850: LoadField: r1 = r0->field_63
    //     0x668850: ldur            w1, [x0, #0x63]
    // 0x668854: DecompressPointer r1
    //     0x668854: add             x1, x1, HEAP, lsl #32
    // 0x668858: stp             x1, x0, [SP, #-0x10]!
    // 0x66885c: r0 = globalToLocal()
    //     0x66885c: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x668860: add             SP, SP, #0x10
    // 0x668864: mov             x1, x0
    // 0x668868: ldur            x0, [fp, #-8]
    // 0x66886c: LoadField: r2 = r0->field_7
    //     0x66886c: ldur            w2, [x0, #7]
    // 0x668870: DecompressPointer r2
    //     0x668870: add             x2, x2, HEAP, lsl #32
    // 0x668874: LoadField: d0 = r2->field_7
    //     0x668874: ldur            d0, [x2, #7]
    // 0x668878: ldr             x0, [fp, #0x10]
    // 0x66887c: LoadField: r2 = r0->field_5f
    //     0x66887c: ldur            w2, [x0, #0x5f]
    // 0x668880: DecompressPointer r2
    //     0x668880: add             x2, x2, HEAP, lsl #32
    // 0x668884: cmp             w2, NULL
    // 0x668888: b.eq            #0x668a3c
    // 0x66888c: LoadField: r3 = r2->field_57
    //     0x66888c: ldur            w3, [x2, #0x57]
    // 0x668890: DecompressPointer r3
    //     0x668890: add             x3, x3, HEAP, lsl #32
    // 0x668894: cmp             w3, NULL
    // 0x668898: b.eq            #0x668a40
    // 0x66889c: LoadField: d1 = r3->field_7
    //     0x66889c: ldur            d1, [x3, #7]
    // 0x6688a0: d2 = 2.000000
    //     0x6688a0: fmov            d2, #2.00000000
    // 0x6688a4: fdiv            d3, d1, d2
    // 0x6688a8: fadd            d1, d0, d3
    // 0x6688ac: LoadField: d0 = r1->field_7
    //     0x6688ac: ldur            d0, [x1, #7]
    // 0x6688b0: fsub            d2, d0, d1
    // 0x6688b4: fadd            d0, d3, d2
    // 0x6688b8: stur            d0, [fp, #-0x38]
    // 0x6688bc: LoadField: r1 = r0->field_67
    //     0x6688bc: ldur            w1, [x0, #0x67]
    // 0x6688c0: DecompressPointer r1
    //     0x6688c0: add             x1, x1, HEAP, lsl #32
    // 0x6688c4: tbnz            w1, #4, #0x6688dc
    // 0x6688c8: ldur            d1, [fp, #-0x28]
    // 0x6688cc: LoadField: d2 = r3->field_f
    //     0x6688cc: ldur            d2, [x3, #0xf]
    // 0x6688d0: fsub            d3, d2, d1
    // 0x6688d4: mov             v1.16b, v3.16b
    // 0x6688d8: b               #0x6688e0
    // 0x6688dc: ldur            d1, [fp, #-0x28]
    // 0x6688e0: stur            d1, [fp, #-0x30]
    // 0x6688e4: tbnz            w1, #4, #0x6688f0
    // 0x6688e8: LoadField: d2 = r3->field_f
    //     0x6688e8: ldur            d2, [x3, #0xf]
    // 0x6688ec: b               #0x6688f4
    // 0x6688f0: d2 = 0.000000
    //     0x6688f0: eor             v2.16b, v2.16b, v2.16b
    // 0x6688f4: stur            d2, [fp, #-0x28]
    // 0x6688f8: r0 = Path()
    //     0x6688f8: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0x6688fc: stur            x0, [fp, #-8]
    // 0x668900: SaveReg r0
    //     0x668900: str             x0, [SP, #-8]!
    // 0x668904: r0 = _constructor()
    //     0x668904: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0x668908: add             SP, SP, #8
    // 0x66890c: ldur            d0, [fp, #-0x38]
    // 0x668910: r0 = inline_Allocate_Double()
    //     0x668910: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x668914: add             x0, x0, #0x10
    //     0x668918: cmp             x1, x0
    //     0x66891c: b.ls            #0x668a44
    //     0x668920: str             x0, [THR, #0x60]  ; THR::top
    //     0x668924: sub             x0, x0, #0xf
    //     0x668928: mov             x1, #0xd108
    //     0x66892c: movk            x1, #3, lsl #16
    //     0x668930: stur            x1, [x0, #-1]
    // 0x668934: StoreField: r0->field_7 = d0
    //     0x668934: stur            d0, [x0, #7]
    // 0x668938: ldur            x16, [fp, #-8]
    // 0x66893c: stp             x0, x16, [SP, #-0x10]!
    // 0x668940: ldur            d1, [fp, #-0x28]
    // 0x668944: SaveReg d1
    //     0x668944: str             d1, [SP, #-8]!
    // 0x668948: r0 = moveTo()
    //     0x668948: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0x66894c: add             SP, SP, #0x18
    // 0x668950: ldur            d0, [fp, #-0x38]
    // 0x668954: d1 = 7.000000
    //     0x668954: fmov            d1, #7.00000000
    // 0x668958: fsub            d2, d0, d1
    // 0x66895c: r0 = inline_Allocate_Double()
    //     0x66895c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x668960: add             x0, x0, #0x10
    //     0x668964: cmp             x1, x0
    //     0x668968: b.ls            #0x668a54
    //     0x66896c: str             x0, [THR, #0x60]  ; THR::top
    //     0x668970: sub             x0, x0, #0xf
    //     0x668974: mov             x1, #0xd108
    //     0x668978: movk            x1, #3, lsl #16
    //     0x66897c: stur            x1, [x0, #-1]
    // 0x668980: StoreField: r0->field_7 = d2
    //     0x668980: stur            d2, [x0, #7]
    // 0x668984: ldur            x16, [fp, #-8]
    // 0x668988: stp             x0, x16, [SP, #-0x10]!
    // 0x66898c: ldur            d2, [fp, #-0x30]
    // 0x668990: SaveReg d2
    //     0x668990: str             d2, [SP, #-8]!
    // 0x668994: r0 = lineTo()
    //     0x668994: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x668998: add             SP, SP, #0x18
    // 0x66899c: ldur            d0, [fp, #-0x38]
    // 0x6689a0: d1 = 7.000000
    //     0x6689a0: fmov            d1, #7.00000000
    // 0x6689a4: fadd            d2, d0, d1
    // 0x6689a8: r0 = inline_Allocate_Double()
    //     0x6689a8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6689ac: add             x0, x0, #0x10
    //     0x6689b0: cmp             x1, x0
    //     0x6689b4: b.ls            #0x668a6c
    //     0x6689b8: str             x0, [THR, #0x60]  ; THR::top
    //     0x6689bc: sub             x0, x0, #0xf
    //     0x6689c0: mov             x1, #0xd108
    //     0x6689c4: movk            x1, #3, lsl #16
    //     0x6689c8: stur            x1, [x0, #-1]
    // 0x6689cc: StoreField: r0->field_7 = d2
    //     0x6689cc: stur            d2, [x0, #7]
    // 0x6689d0: ldur            x16, [fp, #-8]
    // 0x6689d4: stp             x0, x16, [SP, #-0x10]!
    // 0x6689d8: ldur            d0, [fp, #-0x30]
    // 0x6689dc: SaveReg d0
    //     0x6689dc: str             d0, [SP, #-8]!
    // 0x6689e0: r0 = lineTo()
    //     0x6689e0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0x6689e4: add             SP, SP, #0x18
    // 0x6689e8: ldur            x16, [fp, #-8]
    // 0x6689ec: SaveReg r16
    //     0x6689ec: str             x16, [SP, #-8]!
    // 0x6689f0: r0 = close()
    //     0x6689f0: bl              #0x668e78  ; [dart:ui] Path::close
    // 0x6689f4: add             SP, SP, #8
    // 0x6689f8: r16 = Instance_PathOperation
    //     0x6689f8: add             x16, PP, #0x37, lsl #12  ; [pp+0x37c30] Obj!PathOperation@b675f1
    //     0x6689fc: ldr             x16, [x16, #0xc30]
    // 0x668a00: ldur            lr, [fp, #-0x10]
    // 0x668a04: stp             lr, x16, [SP, #-0x10]!
    // 0x668a08: ldur            x16, [fp, #-8]
    // 0x668a0c: SaveReg r16
    //     0x668a0c: str             x16, [SP, #-8]!
    // 0x668a10: r0 = combine()
    //     0x668a10: bl              #0x668a7c  ; [dart:ui] Path::combine
    // 0x668a14: add             SP, SP, #0x18
    // 0x668a18: LeaveFrame
    //     0x668a18: mov             SP, fp
    //     0x668a1c: ldp             fp, lr, [SP], #0x10
    // 0x668a20: ret
    //     0x668a20: ret             
    // 0x668a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x668a24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x668a28: b               #0x668718
    // 0x668a2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x668a2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x668a30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x668a30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x668a34: r0 = NullCastErrorSharedWithFPURegs()
    //     0x668a34: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x668a38: r0 = NullCastErrorSharedWithFPURegs()
    //     0x668a38: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x668a3c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x668a3c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x668a40: r0 = NullCastErrorSharedWithFPURegs()
    //     0x668a40: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x668a44: SaveReg d0
    //     0x668a44: str             q0, [SP, #-0x10]!
    // 0x668a48: r0 = AllocateDouble()
    //     0x668a48: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x668a4c: RestoreReg d0
    //     0x668a4c: ldr             q0, [SP], #0x10
    // 0x668a50: b               #0x668934
    // 0x668a54: stp             q1, q2, [SP, #-0x20]!
    // 0x668a58: SaveReg d0
    //     0x668a58: str             q0, [SP, #-0x10]!
    // 0x668a5c: r0 = AllocateDouble()
    //     0x668a5c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x668a60: RestoreReg d0
    //     0x668a60: ldr             q0, [SP], #0x10
    // 0x668a64: ldp             q1, q2, [SP], #0x20
    // 0x668a68: b               #0x668980
    // 0x668a6c: SaveReg d2
    //     0x668a6c: str             q2, [SP, #-0x10]!
    // 0x668a70: r0 = AllocateDouble()
    //     0x668a70: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x668a74: RestoreReg d2
    //     0x668a74: ldr             q2, [SP], #0x10
    // 0x668a78: b               #0x6689cc
  }
  [closure] void <anonymous closure>(dynamic, PaintingContext, Offset) {
    // ** addr: 0x6697ac, size: 0x68
    // 0x6697ac: EnterFrame
    //     0x6697ac: stp             fp, lr, [SP, #-0x10]!
    //     0x6697b0: mov             fp, SP
    // 0x6697b4: ldr             x0, [fp, #0x20]
    // 0x6697b8: LoadField: r1 = r0->field_17
    //     0x6697b8: ldur            w1, [x0, #0x17]
    // 0x6697bc: DecompressPointer r1
    //     0x6697bc: add             x1, x1, HEAP, lsl #32
    // 0x6697c0: CheckStackOverflow
    //     0x6697c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6697c4: cmp             SP, x16
    //     0x6697c8: b.ls            #0x669808
    // 0x6697cc: LoadField: r0 = r1->field_f
    //     0x6697cc: ldur            w0, [x1, #0xf]
    // 0x6697d0: DecompressPointer r0
    //     0x6697d0: add             x0, x0, HEAP, lsl #32
    // 0x6697d4: LoadField: r1 = r0->field_5f
    //     0x6697d4: ldur            w1, [x0, #0x5f]
    // 0x6697d8: DecompressPointer r1
    //     0x6697d8: add             x1, x1, HEAP, lsl #32
    // 0x6697dc: cmp             w1, NULL
    // 0x6697e0: b.eq            #0x669810
    // 0x6697e4: ldr             x16, [fp, #0x18]
    // 0x6697e8: stp             x1, x16, [SP, #-0x10]!
    // 0x6697ec: ldr             x16, [fp, #0x10]
    // 0x6697f0: SaveReg r16
    //     0x6697f0: str             x16, [SP, #-8]!
    // 0x6697f4: r0 = paintChild()
    //     0x6697f4: bl              #0x653fdc  ; [package:flutter/src/rendering/object.dart] PaintingContext::paintChild
    // 0x6697f8: add             SP, SP, #0x18
    // 0x6697fc: LeaveFrame
    //     0x6697fc: mov             SP, fp
    //     0x669800: ldp             fp, lr, [SP], #0x10
    // 0x669804: ret
    //     0x669804: ret             
    // 0x669808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x669808: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x66980c: b               #0x6697cc
    // 0x669810: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x669810: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ performLayout(/* No info */) {
    // ** addr: 0x6901ec, size: 0x284
    // 0x6901ec: EnterFrame
    //     0x6901ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6901f0: mov             fp, SP
    // 0x6901f4: AllocStack(0x20)
    //     0x6901f4: sub             SP, SP, #0x20
    // 0x6901f8: CheckStackOverflow
    //     0x6901f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6901fc: cmp             SP, x16
    //     0x690200: b.ls            #0x690458
    // 0x690204: ldr             x3, [fp, #0x10]
    // 0x690208: LoadField: r0 = r3->field_5f
    //     0x690208: ldur            w0, [x3, #0x5f]
    // 0x69020c: DecompressPointer r0
    //     0x69020c: add             x0, x0, HEAP, lsl #32
    // 0x690210: cmp             w0, NULL
    // 0x690214: b.ne            #0x690228
    // 0x690218: r0 = Null
    //     0x690218: mov             x0, NULL
    // 0x69021c: LeaveFrame
    //     0x69021c: mov             SP, fp
    //     0x690220: ldp             fp, lr, [SP], #0x10
    // 0x690224: ret
    //     0x690224: ret             
    // 0x690228: LoadField: r4 = r3->field_27
    //     0x690228: ldur            w4, [x3, #0x27]
    // 0x69022c: DecompressPointer r4
    //     0x69022c: add             x4, x4, HEAP, lsl #32
    // 0x690230: stur            x4, [fp, #-8]
    // 0x690234: cmp             w4, NULL
    // 0x690238: b.eq            #0x690438
    // 0x69023c: mov             x0, x4
    // 0x690240: r2 = Null
    //     0x690240: mov             x2, NULL
    // 0x690244: r1 = Null
    //     0x690244: mov             x1, NULL
    // 0x690248: r4 = LoadClassIdInstr(r0)
    //     0x690248: ldur            x4, [x0, #-1]
    //     0x69024c: ubfx            x4, x4, #0xc, #0x14
    // 0x690250: sub             x4, x4, #0x80d
    // 0x690254: cmp             x4, #1
    // 0x690258: b.ls            #0x690270
    // 0x69025c: r8 = BoxConstraints
    //     0x69025c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x690260: ldr             x8, [x8, #0x1d0]
    // 0x690264: r3 = Null
    //     0x690264: add             x3, PP, #0x37, lsl #12  ; [pp+0x37c70] Null
    //     0x690268: ldr             x3, [x3, #0xc70]
    // 0x69026c: r0 = BoxConstraints()
    //     0x69026c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x690270: ldur            x16, [fp, #-8]
    // 0x690274: SaveReg r16
    //     0x690274: str             x16, [SP, #-8]!
    // 0x690278: r0 = loosen()
    //     0x690278: bl              #0x68f088  ; [package:flutter/src/rendering/box.dart] BoxConstraints::loosen
    // 0x69027c: add             SP, SP, #8
    // 0x690280: mov             x1, x0
    // 0x690284: ldr             x0, [fp, #0x10]
    // 0x690288: LoadField: r2 = r0->field_5f
    //     0x690288: ldur            w2, [x0, #0x5f]
    // 0x69028c: DecompressPointer r2
    //     0x69028c: add             x2, x2, HEAP, lsl #32
    // 0x690290: stur            x2, [fp, #-8]
    // 0x690294: cmp             w2, NULL
    // 0x690298: b.eq            #0x690460
    // 0x69029c: LoadField: r3 = r0->field_6b
    //     0x69029c: ldur            w3, [x0, #0x6b]
    // 0x6902a0: DecompressPointer r3
    //     0x6902a0: add             x3, x3, HEAP, lsl #32
    // 0x6902a4: stp             x1, x3, [SP, #-0x10]!
    // 0x6902a8: r0 = enforce()
    //     0x6902a8: bl              #0x62bd90  ; [package:flutter/src/rendering/box.dart] BoxConstraints::enforce
    // 0x6902ac: add             SP, SP, #0x10
    // 0x6902b0: mov             x1, x0
    // 0x6902b4: ldur            x0, [fp, #-8]
    // 0x6902b8: r2 = LoadClassIdInstr(r0)
    //     0x6902b8: ldur            x2, [x0, #-1]
    //     0x6902bc: ubfx            x2, x2, #0xc, #0x14
    // 0x6902c0: stp             x1, x0, [SP, #-0x10]!
    // 0x6902c4: r16 = true
    //     0x6902c4: add             x16, NULL, #0x20  ; true
    // 0x6902c8: SaveReg r16
    //     0x6902c8: str             x16, [SP, #-8]!
    // 0x6902cc: mov             x0, x2
    // 0x6902d0: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x6902d0: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x6902d4: ldr             x4, [x4, #0x1c8]
    // 0x6902d8: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x6902d8: mov             x17, #0xcdfb
    //     0x6902dc: add             lr, x0, x17
    //     0x6902e0: ldr             lr, [x21, lr, lsl #3]
    //     0x6902e4: blr             lr
    // 0x6902e8: add             SP, SP, #0x18
    // 0x6902ec: ldr             x3, [fp, #0x10]
    // 0x6902f0: LoadField: r4 = r3->field_5f
    //     0x6902f0: ldur            w4, [x3, #0x5f]
    // 0x6902f4: DecompressPointer r4
    //     0x6902f4: add             x4, x4, HEAP, lsl #32
    // 0x6902f8: stur            x4, [fp, #-0x10]
    // 0x6902fc: cmp             w4, NULL
    // 0x690300: b.eq            #0x690464
    // 0x690304: LoadField: r5 = r4->field_17
    //     0x690304: ldur            w5, [x4, #0x17]
    // 0x690308: DecompressPointer r5
    //     0x690308: add             x5, x5, HEAP, lsl #32
    // 0x69030c: stur            x5, [fp, #-8]
    // 0x690310: cmp             w5, NULL
    // 0x690314: b.eq            #0x690468
    // 0x690318: mov             x0, x5
    // 0x69031c: r2 = Null
    //     0x69031c: mov             x2, NULL
    // 0x690320: r1 = Null
    //     0x690320: mov             x1, NULL
    // 0x690324: r4 = LoadClassIdInstr(r0)
    //     0x690324: ldur            x4, [x0, #-1]
    //     0x690328: ubfx            x4, x4, #0xc, #0x14
    // 0x69032c: sub             x4, x4, #0x7ff
    // 0x690330: cmp             x4, #0xb
    // 0x690334: b.ls            #0x69034c
    // 0x690338: r8 = BoxParentData
    //     0x690338: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1b0] Type: BoxParentData
    //     0x69033c: ldr             x8, [x8, #0x1b0]
    // 0x690340: r3 = Null
    //     0x690340: add             x3, PP, #0x37, lsl #12  ; [pp+0x37c80] Null
    //     0x690344: ldr             x3, [x3, #0xc80]
    // 0x690348: r0 = DefaultTypeTest()
    //     0x690348: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x69034c: ldr             x0, [fp, #0x10]
    // 0x690350: LoadField: r1 = r0->field_67
    //     0x690350: ldur            w1, [x0, #0x67]
    // 0x690354: DecompressPointer r1
    //     0x690354: add             x1, x1, HEAP, lsl #32
    // 0x690358: tbnz            w1, #4, #0x690374
    // 0x69035c: r1 = Instance_Size
    //     0x69035c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37bf8] Obj!Size@b5ec71
    //     0x690360: ldr             x1, [x1, #0xbf8]
    // 0x690364: LoadField: d0 = r1->field_f
    //     0x690364: ldur            d0, [x1, #0xf]
    // 0x690368: fneg            d1, d0
    // 0x69036c: mov             v0.16b, v1.16b
    // 0x690370: b               #0x690380
    // 0x690374: r1 = Instance_Size
    //     0x690374: add             x1, PP, #0x37, lsl #12  ; [pp+0x37bf8] Obj!Size@b5ec71
    //     0x690378: ldr             x1, [x1, #0xbf8]
    // 0x69037c: d0 = 0.000000
    //     0x69037c: eor             v0.16b, v0.16b, v0.16b
    // 0x690380: ldur            x3, [fp, #-8]
    // 0x690384: ldur            x2, [fp, #-0x10]
    // 0x690388: stur            d0, [fp, #-0x18]
    // 0x69038c: r0 = Offset()
    //     0x69038c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x690390: d0 = 0.000000
    //     0x690390: eor             v0.16b, v0.16b, v0.16b
    // 0x690394: StoreField: r0->field_7 = d0
    //     0x690394: stur            d0, [x0, #7]
    // 0x690398: ldur            d0, [fp, #-0x18]
    // 0x69039c: StoreField: r0->field_f = d0
    //     0x69039c: stur            d0, [x0, #0xf]
    // 0x6903a0: ldur            x1, [fp, #-8]
    // 0x6903a4: StoreField: r1->field_7 = r0
    //     0x6903a4: stur            w0, [x1, #7]
    //     0x6903a8: ldurb           w16, [x1, #-1]
    //     0x6903ac: ldurb           w17, [x0, #-1]
    //     0x6903b0: and             x16, x17, x16, lsr #2
    //     0x6903b4: tst             x16, HEAP, lsr #32
    //     0x6903b8: b.eq            #0x6903c0
    //     0x6903bc: bl              #0xd6826c
    // 0x6903c0: ldur            x0, [fp, #-0x10]
    // 0x6903c4: LoadField: r1 = r0->field_57
    //     0x6903c4: ldur            w1, [x0, #0x57]
    // 0x6903c8: DecompressPointer r1
    //     0x6903c8: add             x1, x1, HEAP, lsl #32
    // 0x6903cc: cmp             w1, NULL
    // 0x6903d0: b.eq            #0x69046c
    // 0x6903d4: LoadField: d0 = r1->field_7
    //     0x6903d4: ldur            d0, [x1, #7]
    // 0x6903d8: stur            d0, [fp, #-0x20]
    // 0x6903dc: LoadField: d1 = r1->field_f
    //     0x6903dc: ldur            d1, [x1, #0xf]
    // 0x6903e0: r0 = Instance_Size
    //     0x6903e0: add             x0, PP, #0x37, lsl #12  ; [pp+0x37bf8] Obj!Size@b5ec71
    //     0x6903e4: ldr             x0, [x0, #0xbf8]
    // 0x6903e8: LoadField: d2 = r0->field_f
    //     0x6903e8: ldur            d2, [x0, #0xf]
    // 0x6903ec: fsub            d3, d1, d2
    // 0x6903f0: stur            d3, [fp, #-0x18]
    // 0x6903f4: r0 = Size()
    //     0x6903f4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x6903f8: ldur            d0, [fp, #-0x20]
    // 0x6903fc: StoreField: r0->field_7 = d0
    //     0x6903fc: stur            d0, [x0, #7]
    // 0x690400: ldur            d0, [fp, #-0x18]
    // 0x690404: StoreField: r0->field_f = d0
    //     0x690404: stur            d0, [x0, #0xf]
    // 0x690408: ldr             x1, [fp, #0x10]
    // 0x69040c: StoreField: r1->field_57 = r0
    //     0x69040c: stur            w0, [x1, #0x57]
    //     0x690410: ldurb           w16, [x1, #-1]
    //     0x690414: ldurb           w17, [x0, #-1]
    //     0x690418: and             x16, x17, x16, lsr #2
    //     0x69041c: tst             x16, HEAP, lsr #32
    //     0x690420: b.eq            #0x690428
    //     0x690424: bl              #0xd6826c
    // 0x690428: r0 = Null
    //     0x690428: mov             x0, NULL
    // 0x69042c: LeaveFrame
    //     0x69042c: mov             SP, fp
    //     0x690430: ldp             fp, lr, [SP], #0x10
    // 0x690434: ret
    //     0x690434: ret             
    // 0x690438: r0 = StateError()
    //     0x690438: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x69043c: mov             x1, x0
    // 0x690440: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x690440: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x690444: ldr             x0, [x0, #0x1e8]
    // 0x690448: StoreField: r1->field_b = r0
    //     0x690448: stur            w0, [x1, #0xb]
    // 0x69044c: mov             x0, x1
    // 0x690450: r0 = Throw()
    //     0x690450: bl              #0xd67e38  ; ThrowStub
    // 0x690454: brk             #0
    // 0x690458: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x690458: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x69045c: b               #0x690204
    // 0x690460: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690460: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690464: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690464: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x690468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x690468: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x69046c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x69046c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ isAbove=(/* No info */) {
    // ** addr: 0x6c23dc, size: 0x64
    // 0x6c23dc: EnterFrame
    //     0x6c23dc: stp             fp, lr, [SP, #-0x10]!
    //     0x6c23e0: mov             fp, SP
    // 0x6c23e4: CheckStackOverflow
    //     0x6c23e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c23e8: cmp             SP, x16
    //     0x6c23ec: b.ls            #0x6c2438
    // 0x6c23f0: ldr             x0, [fp, #0x18]
    // 0x6c23f4: LoadField: r1 = r0->field_67
    //     0x6c23f4: ldur            w1, [x0, #0x67]
    // 0x6c23f8: DecompressPointer r1
    //     0x6c23f8: add             x1, x1, HEAP, lsl #32
    // 0x6c23fc: ldr             x2, [fp, #0x10]
    // 0x6c2400: cmp             w1, w2
    // 0x6c2404: b.ne            #0x6c2418
    // 0x6c2408: r0 = Null
    //     0x6c2408: mov             x0, NULL
    // 0x6c240c: LeaveFrame
    //     0x6c240c: mov             SP, fp
    //     0x6c2410: ldp             fp, lr, [SP], #0x10
    // 0x6c2414: ret
    //     0x6c2414: ret             
    // 0x6c2418: StoreField: r0->field_67 = r2
    //     0x6c2418: stur            w2, [x0, #0x67]
    // 0x6c241c: SaveReg r0
    //     0x6c241c: str             x0, [SP, #-8]!
    // 0x6c2420: r0 = markNeedsLayout()
    //     0x6c2420: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c2424: add             SP, SP, #8
    // 0x6c2428: r0 = Null
    //     0x6c2428: mov             x0, NULL
    // 0x6c242c: LeaveFrame
    //     0x6c242c: mov             SP, fp
    //     0x6c2430: ldp             fp, lr, [SP], #0x10
    // 0x6c2434: ret
    //     0x6c2434: ret             
    // 0x6c2438: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c2438: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c243c: b               #0x6c23f0
  }
  set _ anchor=(/* No info */) {
    // ** addr: 0x6c2440, size: 0x8c
    // 0x6c2440: EnterFrame
    //     0x6c2440: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2444: mov             fp, SP
    // 0x6c2448: CheckStackOverflow
    //     0x6c2448: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c244c: cmp             SP, x16
    //     0x6c2450: b.ls            #0x6c24c4
    // 0x6c2454: ldr             x0, [fp, #0x18]
    // 0x6c2458: LoadField: r1 = r0->field_63
    //     0x6c2458: ldur            w1, [x0, #0x63]
    // 0x6c245c: DecompressPointer r1
    //     0x6c245c: add             x1, x1, HEAP, lsl #32
    // 0x6c2460: ldr             x16, [fp, #0x10]
    // 0x6c2464: stp             x1, x16, [SP, #-0x10]!
    // 0x6c2468: r0 = ==()
    //     0x6c2468: bl              #0xc65f90  ; [dart:ui] Offset::==
    // 0x6c246c: add             SP, SP, #0x10
    // 0x6c2470: tbnz            w0, #4, #0x6c2484
    // 0x6c2474: r0 = Null
    //     0x6c2474: mov             x0, NULL
    // 0x6c2478: LeaveFrame
    //     0x6c2478: mov             SP, fp
    //     0x6c247c: ldp             fp, lr, [SP], #0x10
    // 0x6c2480: ret
    //     0x6c2480: ret             
    // 0x6c2484: ldr             x1, [fp, #0x18]
    // 0x6c2488: ldr             x0, [fp, #0x10]
    // 0x6c248c: StoreField: r1->field_63 = r0
    //     0x6c248c: stur            w0, [x1, #0x63]
    //     0x6c2490: ldurb           w16, [x1, #-1]
    //     0x6c2494: ldurb           w17, [x0, #-1]
    //     0x6c2498: and             x16, x17, x16, lsr #2
    //     0x6c249c: tst             x16, HEAP, lsr #32
    //     0x6c24a0: b.eq            #0x6c24a8
    //     0x6c24a4: bl              #0xd6826c
    // 0x6c24a8: SaveReg r1
    //     0x6c24a8: str             x1, [SP, #-8]!
    // 0x6c24ac: r0 = markNeedsLayout()
    //     0x6c24ac: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6c24b0: add             SP, SP, #8
    // 0x6c24b4: r0 = Null
    //     0x6c24b4: mov             x0, NULL
    // 0x6c24b8: LeaveFrame
    //     0x6c24b8: mov             SP, fp
    //     0x6c24bc: ldp             fp, lr, [SP], #0x10
    // 0x6c24c0: ret
    //     0x6c24c0: ret             
    // 0x6c24c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c24c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c24c8: b               #0x6c2454
  }
  _ _RenderCupertinoTextSelectionToolbarShape(/* No info */) {
    // ** addr: 0x6ea02c, size: 0xe0
    // 0x6ea02c: EnterFrame
    //     0x6ea02c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ea030: mov             fp, SP
    // 0x6ea034: CheckStackOverflow
    //     0x6ea034: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ea038: cmp             SP, x16
    //     0x6ea03c: b.ls            #0x6ea104
    // 0x6ea040: r0 = BoxConstraints()
    //     0x6ea040: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x6ea044: d0 = 0.000000
    //     0x6ea044: eor             v0.16b, v0.16b, v0.16b
    // 0x6ea048: StoreField: r0->field_7 = d0
    //     0x6ea048: stur            d0, [x0, #7]
    // 0x6ea04c: d0 = inf
    //     0x6ea04c: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x6ea050: StoreField: r0->field_f = d0
    //     0x6ea050: stur            d0, [x0, #0xf]
    // 0x6ea054: d0 = 50.000000
    //     0x6ea054: add             x17, PP, #0x26, lsl #12  ; [pp+0x26980] IMM: double(50) from 0x4049000000000000
    //     0x6ea058: ldr             d0, [x17, #0x980]
    // 0x6ea05c: StoreField: r0->field_17 = d0
    //     0x6ea05c: stur            d0, [x0, #0x17]
    // 0x6ea060: StoreField: r0->field_1f = d0
    //     0x6ea060: stur            d0, [x0, #0x1f]
    // 0x6ea064: ldr             x2, [fp, #0x20]
    // 0x6ea068: StoreField: r2->field_6b = r0
    //     0x6ea068: stur            w0, [x2, #0x6b]
    //     0x6ea06c: ldurb           w16, [x2, #-1]
    //     0x6ea070: ldurb           w17, [x0, #-1]
    //     0x6ea074: and             x16, x17, x16, lsr #2
    //     0x6ea078: tst             x16, HEAP, lsr #32
    //     0x6ea07c: b.eq            #0x6ea084
    //     0x6ea080: bl              #0xd6828c
    // 0x6ea084: r1 = <ClipPathLayer>
    //     0x6ea084: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e9c0] TypeArguments: <ClipPathLayer>
    //     0x6ea088: ldr             x1, [x1, #0x9c0]
    // 0x6ea08c: r0 = LayerHandle()
    //     0x6ea08c: bl              #0x5bbf28  ; AllocateLayerHandleStub -> LayerHandle<X0 bound Layer> (size=0x10)
    // 0x6ea090: ldr             x1, [fp, #0x20]
    // 0x6ea094: StoreField: r1->field_6f = r0
    //     0x6ea094: stur            w0, [x1, #0x6f]
    //     0x6ea098: ldurb           w16, [x1, #-1]
    //     0x6ea09c: ldurb           w17, [x0, #-1]
    //     0x6ea0a0: and             x16, x17, x16, lsr #2
    //     0x6ea0a4: tst             x16, HEAP, lsr #32
    //     0x6ea0a8: b.eq            #0x6ea0b0
    //     0x6ea0ac: bl              #0xd6826c
    // 0x6ea0b0: ldr             x0, [fp, #0x18]
    // 0x6ea0b4: StoreField: r1->field_63 = r0
    //     0x6ea0b4: stur            w0, [x1, #0x63]
    //     0x6ea0b8: ldurb           w16, [x1, #-1]
    //     0x6ea0bc: ldurb           w17, [x0, #-1]
    //     0x6ea0c0: and             x16, x17, x16, lsr #2
    //     0x6ea0c4: tst             x16, HEAP, lsr #32
    //     0x6ea0c8: b.eq            #0x6ea0d0
    //     0x6ea0cc: bl              #0xd6826c
    // 0x6ea0d0: ldr             x0, [fp, #0x10]
    // 0x6ea0d4: StoreField: r1->field_67 = r0
    //     0x6ea0d4: stur            w0, [x1, #0x67]
    // 0x6ea0d8: SaveReg r1
    //     0x6ea0d8: str             x1, [SP, #-8]!
    // 0x6ea0dc: r0 = RenderObject()
    //     0x6ea0dc: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ea0e0: add             SP, SP, #8
    // 0x6ea0e4: ldr             x16, [fp, #0x20]
    // 0x6ea0e8: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ea0ec: r0 = child=()
    //     0x6ea0ec: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ea0f0: add             SP, SP, #0x10
    // 0x6ea0f4: r0 = Null
    //     0x6ea0f4: mov             x0, NULL
    // 0x6ea0f8: LeaveFrame
    //     0x6ea0f8: mov             SP, fp
    //     0x6ea0fc: ldp             fp, lr, [SP], #0x10
    // 0x6ea100: ret
    //     0x6ea100: ret             
    // 0x6ea104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea104: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea108: b               #0x6ea040
  }
}

// class id: 3344, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin extends State<_CupertinoTextSelectionToolbarContent>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x615a3c, size: 0x178
    // 0x615a3c: EnterFrame
    //     0x615a3c: stp             fp, lr, [SP, #-0x10]!
    //     0x615a40: mov             fp, SP
    // 0x615a44: AllocStack(0x10)
    //     0x615a44: sub             SP, SP, #0x10
    // 0x615a48: CheckStackOverflow
    //     0x615a48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615a4c: cmp             SP, x16
    //     0x615a50: b.ls            #0x615ba4
    // 0x615a54: ldr             x0, [fp, #0x18]
    // 0x615a58: LoadField: r1 = r0->field_17
    //     0x615a58: ldur            w1, [x0, #0x17]
    // 0x615a5c: DecompressPointer r1
    //     0x615a5c: add             x1, x1, HEAP, lsl #32
    // 0x615a60: cmp             w1, NULL
    // 0x615a64: b.ne            #0x615a74
    // 0x615a68: SaveReg r0
    //     0x615a68: str             x0, [SP, #-8]!
    // 0x615a6c: r0 = _updateTickerModeNotifier()
    //     0x615a6c: bl              #0x615bd8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x615a70: add             SP, SP, #8
    // 0x615a74: ldr             x0, [fp, #0x18]
    // 0x615a78: LoadField: r1 = r0->field_13
    //     0x615a78: ldur            w1, [x0, #0x13]
    // 0x615a7c: DecompressPointer r1
    //     0x615a7c: add             x1, x1, HEAP, lsl #32
    // 0x615a80: cmp             w1, NULL
    // 0x615a84: b.ne            #0x615b1c
    // 0x615a88: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x615a88: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x615a8c: ldr             x0, [x0, #0x598]
    //     0x615a90: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x615a94: cmp             w0, w16
    //     0x615a98: b.ne            #0x615aa4
    //     0x615a9c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x615aa0: bl              #0xd67cdc
    // 0x615aa4: r1 = <_WidgetTicker>
    //     0x615aa4: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x615aa8: ldr             x1, [x1, #0x210]
    // 0x615aac: stur            x0, [fp, #-8]
    // 0x615ab0: r0 = _Set()
    //     0x615ab0: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x615ab4: mov             x1, x0
    // 0x615ab8: ldur            x0, [fp, #-8]
    // 0x615abc: stur            x1, [fp, #-0x10]
    // 0x615ac0: StoreField: r1->field_1b = r0
    //     0x615ac0: stur            w0, [x1, #0x1b]
    // 0x615ac4: StoreField: r1->field_b = rZR
    //     0x615ac4: stur            wzr, [x1, #0xb]
    // 0x615ac8: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x615ac8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x615acc: ldr             x0, [x0, #0x5a0]
    //     0x615ad0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x615ad4: cmp             w0, w16
    //     0x615ad8: b.ne            #0x615ae4
    //     0x615adc: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x615ae0: bl              #0xd67cdc
    // 0x615ae4: mov             x1, x0
    // 0x615ae8: ldur            x0, [fp, #-0x10]
    // 0x615aec: StoreField: r0->field_f = r1
    //     0x615aec: stur            w1, [x0, #0xf]
    // 0x615af0: StoreField: r0->field_13 = rZR
    //     0x615af0: stur            wzr, [x0, #0x13]
    // 0x615af4: StoreField: r0->field_17 = rZR
    //     0x615af4: stur            wzr, [x0, #0x17]
    // 0x615af8: ldr             x1, [fp, #0x18]
    // 0x615afc: StoreField: r1->field_13 = r0
    //     0x615afc: stur            w0, [x1, #0x13]
    //     0x615b00: ldurb           w16, [x1, #-1]
    //     0x615b04: ldurb           w17, [x0, #-1]
    //     0x615b08: and             x16, x17, x16, lsr #2
    //     0x615b0c: tst             x16, HEAP, lsr #32
    //     0x615b10: b.eq            #0x615b18
    //     0x615b14: bl              #0xd6826c
    // 0x615b18: b               #0x615b20
    // 0x615b1c: mov             x1, x0
    // 0x615b20: ldr             x0, [fp, #0x10]
    // 0x615b24: r0 = _WidgetTicker()
    //     0x615b24: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x615b28: mov             x1, x0
    // 0x615b2c: ldr             x0, [fp, #0x18]
    // 0x615b30: stur            x1, [fp, #-8]
    // 0x615b34: StoreField: r1->field_1b = r0
    //     0x615b34: stur            w0, [x1, #0x1b]
    // 0x615b38: r2 = false
    //     0x615b38: add             x2, NULL, #0x30  ; false
    // 0x615b3c: StoreField: r1->field_b = r2
    //     0x615b3c: stur            w2, [x1, #0xb]
    // 0x615b40: ldr             x2, [fp, #0x10]
    // 0x615b44: StoreField: r1->field_13 = r2
    //     0x615b44: stur            w2, [x1, #0x13]
    // 0x615b48: LoadField: r2 = r0->field_17
    //     0x615b48: ldur            w2, [x0, #0x17]
    // 0x615b4c: DecompressPointer r2
    //     0x615b4c: add             x2, x2, HEAP, lsl #32
    // 0x615b50: cmp             w2, NULL
    // 0x615b54: b.eq            #0x615bac
    // 0x615b58: LoadField: r3 = r2->field_27
    //     0x615b58: ldur            w3, [x2, #0x27]
    // 0x615b5c: DecompressPointer r3
    //     0x615b5c: add             x3, x3, HEAP, lsl #32
    // 0x615b60: eor             x2, x3, #0x10
    // 0x615b64: stp             x2, x1, [SP, #-0x10]!
    // 0x615b68: r0 = muted=()
    //     0x615b68: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x615b6c: add             SP, SP, #0x10
    // 0x615b70: ldr             x0, [fp, #0x18]
    // 0x615b74: LoadField: r1 = r0->field_13
    //     0x615b74: ldur            w1, [x0, #0x13]
    // 0x615b78: DecompressPointer r1
    //     0x615b78: add             x1, x1, HEAP, lsl #32
    // 0x615b7c: cmp             w1, NULL
    // 0x615b80: b.eq            #0x615bb0
    // 0x615b84: ldur            x16, [fp, #-8]
    // 0x615b88: stp             x16, x1, [SP, #-0x10]!
    // 0x615b8c: r0 = add()
    //     0x615b8c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x615b90: add             SP, SP, #0x10
    // 0x615b94: ldur            x0, [fp, #-8]
    // 0x615b98: LeaveFrame
    //     0x615b98: mov             SP, fp
    //     0x615b9c: ldp             fp, lr, [SP], #0x10
    // 0x615ba0: ret
    //     0x615ba0: ret             
    // 0x615ba4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615ba4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615ba8: b               #0x615a54
    // 0x615bac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615bac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x615bb0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615bb0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x615bd8, size: 0x11c
    // 0x615bd8: EnterFrame
    //     0x615bd8: stp             fp, lr, [SP, #-0x10]!
    //     0x615bdc: mov             fp, SP
    // 0x615be0: AllocStack(0x10)
    //     0x615be0: sub             SP, SP, #0x10
    // 0x615be4: CheckStackOverflow
    //     0x615be4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615be8: cmp             SP, x16
    //     0x615bec: b.ls            #0x615ce8
    // 0x615bf0: ldr             x0, [fp, #0x10]
    // 0x615bf4: LoadField: r1 = r0->field_f
    //     0x615bf4: ldur            w1, [x0, #0xf]
    // 0x615bf8: DecompressPointer r1
    //     0x615bf8: add             x1, x1, HEAP, lsl #32
    // 0x615bfc: cmp             w1, NULL
    // 0x615c00: b.eq            #0x615cf0
    // 0x615c04: SaveReg r1
    //     0x615c04: str             x1, [SP, #-8]!
    // 0x615c08: r0 = getNotifier()
    //     0x615c08: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x615c0c: add             SP, SP, #8
    // 0x615c10: mov             x1, x0
    // 0x615c14: ldr             x0, [fp, #0x10]
    // 0x615c18: stur            x1, [fp, #-0x10]
    // 0x615c1c: LoadField: r2 = r0->field_17
    //     0x615c1c: ldur            w2, [x0, #0x17]
    // 0x615c20: DecompressPointer r2
    //     0x615c20: add             x2, x2, HEAP, lsl #32
    // 0x615c24: stur            x2, [fp, #-8]
    // 0x615c28: cmp             w1, w2
    // 0x615c2c: b.ne            #0x615c40
    // 0x615c30: r0 = Null
    //     0x615c30: mov             x0, NULL
    // 0x615c34: LeaveFrame
    //     0x615c34: mov             SP, fp
    //     0x615c38: ldp             fp, lr, [SP], #0x10
    // 0x615c3c: ret
    //     0x615c3c: ret             
    // 0x615c40: cmp             w2, NULL
    // 0x615c44: b.eq            #0x615c80
    // 0x615c48: r1 = 1
    //     0x615c48: mov             x1, #1
    // 0x615c4c: r0 = AllocateContext()
    //     0x615c4c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x615c50: mov             x1, x0
    // 0x615c54: ldr             x0, [fp, #0x10]
    // 0x615c58: StoreField: r1->field_f = r0
    //     0x615c58: stur            w0, [x1, #0xf]
    // 0x615c5c: mov             x2, x1
    // 0x615c60: r1 = Function '_updateTickers@156311458':.
    //     0x615c60: add             x1, PP, #0x40, lsl #12  ; [pp+0x403d0] AnonymousClosure: (0x615cf4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickers (0x615d3c)
    //     0x615c64: ldr             x1, [x1, #0x3d0]
    // 0x615c68: r0 = AllocateClosure()
    //     0x615c68: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x615c6c: ldur            x16, [fp, #-8]
    // 0x615c70: stp             x0, x16, [SP, #-0x10]!
    // 0x615c74: r0 = removeListener()
    //     0x615c74: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x615c78: add             SP, SP, #0x10
    // 0x615c7c: ldr             x0, [fp, #0x10]
    // 0x615c80: r1 = 1
    //     0x615c80: mov             x1, #1
    // 0x615c84: r0 = AllocateContext()
    //     0x615c84: bl              #0xd68aa4  ; AllocateContextStub
    // 0x615c88: mov             x1, x0
    // 0x615c8c: ldr             x0, [fp, #0x10]
    // 0x615c90: StoreField: r1->field_f = r0
    //     0x615c90: stur            w0, [x1, #0xf]
    // 0x615c94: mov             x2, x1
    // 0x615c98: r1 = Function '_updateTickers@156311458':.
    //     0x615c98: add             x1, PP, #0x40, lsl #12  ; [pp+0x403d0] AnonymousClosure: (0x615cf4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickers (0x615d3c)
    //     0x615c9c: ldr             x1, [x1, #0x3d0]
    // 0x615ca0: r0 = AllocateClosure()
    //     0x615ca0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x615ca4: ldur            x16, [fp, #-0x10]
    // 0x615ca8: stp             x0, x16, [SP, #-0x10]!
    // 0x615cac: r0 = addListener()
    //     0x615cac: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x615cb0: add             SP, SP, #0x10
    // 0x615cb4: ldur            x0, [fp, #-0x10]
    // 0x615cb8: ldr             x1, [fp, #0x10]
    // 0x615cbc: StoreField: r1->field_17 = r0
    //     0x615cbc: stur            w0, [x1, #0x17]
    //     0x615cc0: ldurb           w16, [x1, #-1]
    //     0x615cc4: ldurb           w17, [x0, #-1]
    //     0x615cc8: and             x16, x17, x16, lsr #2
    //     0x615ccc: tst             x16, HEAP, lsr #32
    //     0x615cd0: b.eq            #0x615cd8
    //     0x615cd4: bl              #0xd6826c
    // 0x615cd8: r0 = Null
    //     0x615cd8: mov             x0, NULL
    // 0x615cdc: LeaveFrame
    //     0x615cdc: mov             SP, fp
    //     0x615ce0: ldp             fp, lr, [SP], #0x10
    // 0x615ce4: ret
    //     0x615ce4: ret             
    // 0x615ce8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615ce8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615cec: b               #0x615bf0
    // 0x615cf0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615cf0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x615cf4, size: 0x48
    // 0x615cf4: EnterFrame
    //     0x615cf4: stp             fp, lr, [SP, #-0x10]!
    //     0x615cf8: mov             fp, SP
    // 0x615cfc: ldr             x0, [fp, #0x10]
    // 0x615d00: LoadField: r1 = r0->field_17
    //     0x615d00: ldur            w1, [x0, #0x17]
    // 0x615d04: DecompressPointer r1
    //     0x615d04: add             x1, x1, HEAP, lsl #32
    // 0x615d08: CheckStackOverflow
    //     0x615d08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615d0c: cmp             SP, x16
    //     0x615d10: b.ls            #0x615d34
    // 0x615d14: LoadField: r0 = r1->field_f
    //     0x615d14: ldur            w0, [x1, #0xf]
    // 0x615d18: DecompressPointer r0
    //     0x615d18: add             x0, x0, HEAP, lsl #32
    // 0x615d1c: SaveReg r0
    //     0x615d1c: str             x0, [SP, #-8]!
    // 0x615d20: r0 = _updateTickers()
    //     0x615d20: bl              #0x615d3c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickers
    // 0x615d24: add             SP, SP, #8
    // 0x615d28: LeaveFrame
    //     0x615d28: mov             SP, fp
    //     0x615d2c: ldp             fp, lr, [SP], #0x10
    // 0x615d30: ret
    //     0x615d30: ret             
    // 0x615d34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615d34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615d38: b               #0x615d14
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x615d3c, size: 0x150
    // 0x615d3c: EnterFrame
    //     0x615d3c: stp             fp, lr, [SP, #-0x10]!
    //     0x615d40: mov             fp, SP
    // 0x615d44: AllocStack(0x20)
    //     0x615d44: sub             SP, SP, #0x20
    // 0x615d48: CheckStackOverflow
    //     0x615d48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615d4c: cmp             SP, x16
    //     0x615d50: b.ls            #0x615e78
    // 0x615d54: ldr             x0, [fp, #0x10]
    // 0x615d58: LoadField: r1 = r0->field_13
    //     0x615d58: ldur            w1, [x0, #0x13]
    // 0x615d5c: DecompressPointer r1
    //     0x615d5c: add             x1, x1, HEAP, lsl #32
    // 0x615d60: cmp             w1, NULL
    // 0x615d64: b.eq            #0x615e68
    // 0x615d68: LoadField: r2 = r0->field_17
    //     0x615d68: ldur            w2, [x0, #0x17]
    // 0x615d6c: DecompressPointer r2
    //     0x615d6c: add             x2, x2, HEAP, lsl #32
    // 0x615d70: cmp             w2, NULL
    // 0x615d74: b.eq            #0x615e80
    // 0x615d78: LoadField: r0 = r2->field_27
    //     0x615d78: ldur            w0, [x2, #0x27]
    // 0x615d7c: DecompressPointer r0
    //     0x615d7c: add             x0, x0, HEAP, lsl #32
    // 0x615d80: eor             x2, x0, #0x10
    // 0x615d84: stur            x2, [fp, #-8]
    // 0x615d88: SaveReg r1
    //     0x615d88: str             x1, [SP, #-8]!
    // 0x615d8c: r0 = iterator()
    //     0x615d8c: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x615d90: add             SP, SP, #8
    // 0x615d94: stur            x0, [fp, #-0x18]
    // 0x615d98: LoadField: r2 = r0->field_7
    //     0x615d98: ldur            w2, [x0, #7]
    // 0x615d9c: DecompressPointer r2
    //     0x615d9c: add             x2, x2, HEAP, lsl #32
    // 0x615da0: stur            x2, [fp, #-0x10]
    // 0x615da4: ldur            x1, [fp, #-8]
    // 0x615da8: CheckStackOverflow
    //     0x615da8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615dac: cmp             SP, x16
    //     0x615db0: b.ls            #0x615e84
    // 0x615db4: SaveReg r0
    //     0x615db4: str             x0, [SP, #-8]!
    // 0x615db8: r0 = moveNext()
    //     0x615db8: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x615dbc: add             SP, SP, #8
    // 0x615dc0: tbnz            w0, #4, #0x615e68
    // 0x615dc4: ldur            x3, [fp, #-0x18]
    // 0x615dc8: LoadField: r4 = r3->field_33
    //     0x615dc8: ldur            w4, [x3, #0x33]
    // 0x615dcc: DecompressPointer r4
    //     0x615dcc: add             x4, x4, HEAP, lsl #32
    // 0x615dd0: stur            x4, [fp, #-0x20]
    // 0x615dd4: cmp             w4, NULL
    // 0x615dd8: b.ne            #0x615e0c
    // 0x615ddc: mov             x0, x4
    // 0x615de0: ldur            x2, [fp, #-0x10]
    // 0x615de4: r1 = Null
    //     0x615de4: mov             x1, NULL
    // 0x615de8: cmp             w2, NULL
    // 0x615dec: b.eq            #0x615e0c
    // 0x615df0: LoadField: r4 = r2->field_17
    //     0x615df0: ldur            w4, [x2, #0x17]
    // 0x615df4: DecompressPointer r4
    //     0x615df4: add             x4, x4, HEAP, lsl #32
    // 0x615df8: r8 = X0
    //     0x615df8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x615dfc: LoadField: r9 = r4->field_7
    //     0x615dfc: ldur            x9, [x4, #7]
    // 0x615e00: r3 = Null
    //     0x615e00: add             x3, PP, #0x40, lsl #12  ; [pp+0x403c0] Null
    //     0x615e04: ldr             x3, [x3, #0x3c0]
    // 0x615e08: blr             x9
    // 0x615e0c: ldur            x1, [fp, #-8]
    // 0x615e10: ldur            x0, [fp, #-0x20]
    // 0x615e14: LoadField: r2 = r0->field_b
    //     0x615e14: ldur            w2, [x0, #0xb]
    // 0x615e18: DecompressPointer r2
    //     0x615e18: add             x2, x2, HEAP, lsl #32
    // 0x615e1c: cmp             w1, w2
    // 0x615e20: b.eq            #0x615e5c
    // 0x615e24: StoreField: r0->field_b = r1
    //     0x615e24: stur            w1, [x0, #0xb]
    // 0x615e28: tbnz            w1, #4, #0x615e3c
    // 0x615e2c: SaveReg r0
    //     0x615e2c: str             x0, [SP, #-8]!
    // 0x615e30: r0 = unscheduleTick()
    //     0x615e30: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x615e34: add             SP, SP, #8
    // 0x615e38: b               #0x615e5c
    // 0x615e3c: SaveReg r0
    //     0x615e3c: str             x0, [SP, #-8]!
    // 0x615e40: r0 = shouldScheduleTick()
    //     0x615e40: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x615e44: add             SP, SP, #8
    // 0x615e48: tbnz            w0, #4, #0x615e5c
    // 0x615e4c: ldur            x16, [fp, #-0x20]
    // 0x615e50: SaveReg r16
    //     0x615e50: str             x16, [SP, #-8]!
    // 0x615e54: r0 = scheduleTick()
    //     0x615e54: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x615e58: add             SP, SP, #8
    // 0x615e5c: ldur            x0, [fp, #-0x18]
    // 0x615e60: ldur            x2, [fp, #-0x10]
    // 0x615e64: b               #0x615da4
    // 0x615e68: r0 = Null
    //     0x615e68: mov             x0, NULL
    // 0x615e6c: LeaveFrame
    //     0x615e6c: mov             SP, fp
    //     0x615e70: ldp             fp, lr, [SP], #0x10
    // 0x615e74: ret
    //     0x615e74: ret             
    // 0x615e78: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615e78: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615e7c: b               #0x615d54
    // 0x615e80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615e80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x615e84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615e84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615e88: b               #0x615db4
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f248, size: 0x4c
    // 0x81f248: EnterFrame
    //     0x81f248: stp             fp, lr, [SP, #-0x10]!
    //     0x81f24c: mov             fp, SP
    // 0x81f250: CheckStackOverflow
    //     0x81f250: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f254: cmp             SP, x16
    //     0x81f258: b.ls            #0x81f28c
    // 0x81f25c: ldr             x16, [fp, #0x10]
    // 0x81f260: SaveReg r16
    //     0x81f260: str             x16, [SP, #-8]!
    // 0x81f264: r0 = _updateTickerModeNotifier()
    //     0x81f264: bl              #0x615bd8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f268: add             SP, SP, #8
    // 0x81f26c: ldr             x16, [fp, #0x10]
    // 0x81f270: SaveReg r16
    //     0x81f270: str             x16, [SP, #-8]!
    // 0x81f274: r0 = _updateTickers()
    //     0x81f274: bl              #0x615d3c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f278: add             SP, SP, #8
    // 0x81f27c: r0 = Null
    //     0x81f27c: mov             x0, NULL
    // 0x81f280: LeaveFrame
    //     0x81f280: mov             SP, fp
    //     0x81f284: ldp             fp, lr, [SP], #0x10
    // 0x81f288: ret
    //     0x81f288: ret             
    // 0x81f28c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f28c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f290: b               #0x81f25c
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50b28, size: 0x8c
    // 0xa50b28: EnterFrame
    //     0xa50b28: stp             fp, lr, [SP, #-0x10]!
    //     0xa50b2c: mov             fp, SP
    // 0xa50b30: AllocStack(0x8)
    //     0xa50b30: sub             SP, SP, #8
    // 0xa50b34: CheckStackOverflow
    //     0xa50b34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50b38: cmp             SP, x16
    //     0xa50b3c: b.ls            #0xa50bac
    // 0xa50b40: ldr             x0, [fp, #0x10]
    // 0xa50b44: LoadField: r1 = r0->field_17
    //     0xa50b44: ldur            w1, [x0, #0x17]
    // 0xa50b48: DecompressPointer r1
    //     0xa50b48: add             x1, x1, HEAP, lsl #32
    // 0xa50b4c: stur            x1, [fp, #-8]
    // 0xa50b50: cmp             w1, NULL
    // 0xa50b54: b.ne            #0xa50b60
    // 0xa50b58: mov             x1, x0
    // 0xa50b5c: b               #0xa50b98
    // 0xa50b60: r1 = 1
    //     0xa50b60: mov             x1, #1
    // 0xa50b64: r0 = AllocateContext()
    //     0xa50b64: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50b68: mov             x1, x0
    // 0xa50b6c: ldr             x0, [fp, #0x10]
    // 0xa50b70: StoreField: r1->field_f = r0
    //     0xa50b70: stur            w0, [x1, #0xf]
    // 0xa50b74: mov             x2, x1
    // 0xa50b78: r1 = Function '_updateTickers@156311458':.
    //     0xa50b78: add             x1, PP, #0x40, lsl #12  ; [pp+0x403d0] AnonymousClosure: (0x615cf4), in [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::_updateTickers (0x615d3c)
    //     0xa50b7c: ldr             x1, [x1, #0x3d0]
    // 0xa50b80: r0 = AllocateClosure()
    //     0xa50b80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa50b84: ldur            x16, [fp, #-8]
    // 0xa50b88: stp             x0, x16, [SP, #-0x10]!
    // 0xa50b8c: r0 = removeListener()
    //     0xa50b8c: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa50b90: add             SP, SP, #0x10
    // 0xa50b94: ldr             x1, [fp, #0x10]
    // 0xa50b98: StoreField: r1->field_17 = rNULL
    //     0xa50b98: stur            NULL, [x1, #0x17]
    // 0xa50b9c: r0 = Null
    //     0xa50b9c: mov             x0, NULL
    // 0xa50ba0: LeaveFrame
    //     0xa50ba0: mov             SP, fp
    //     0xa50ba4: ldp             fp, lr, [SP], #0x10
    // 0xa50ba8: ret
    //     0xa50ba8: ret             
    // 0xa50bac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50bac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50bb0: b               #0xa50b40
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa50bb4, size: 0x48
    // 0xa50bb4: EnterFrame
    //     0xa50bb4: stp             fp, lr, [SP, #-0x10]!
    //     0xa50bb8: mov             fp, SP
    // 0xa50bbc: ldr             x0, [fp, #0x10]
    // 0xa50bc0: LoadField: r1 = r0->field_17
    //     0xa50bc0: ldur            w1, [x0, #0x17]
    // 0xa50bc4: DecompressPointer r1
    //     0xa50bc4: add             x1, x1, HEAP, lsl #32
    // 0xa50bc8: CheckStackOverflow
    //     0xa50bc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50bcc: cmp             SP, x16
    //     0xa50bd0: b.ls            #0xa50bf4
    // 0xa50bd4: LoadField: r0 = r1->field_f
    //     0xa50bd4: ldur            w0, [x1, #0xf]
    // 0xa50bd8: DecompressPointer r0
    //     0xa50bd8: add             x0, x0, HEAP, lsl #32
    // 0xa50bdc: SaveReg r0
    //     0xa50bdc: str             x0, [SP, #-8]!
    // 0xa50be0: r0 = dispose()
    //     0xa50be0: bl              #0xa50b28  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::dispose
    // 0xa50be4: add             SP, SP, #8
    // 0xa50be8: LeaveFrame
    //     0xa50be8: mov             SP, fp
    //     0xa50bec: ldp             fp, lr, [SP], #0x10
    // 0xa50bf0: ret
    //     0xa50bf0: ret             
    // 0xa50bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50bf8: b               #0xa50bd4
  }
}

// class id: 3345, size: 0x2c, field offset: 0x1c
class _CupertinoTextSelectionToolbarContentState extends __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7afe9c, size: 0x15c
    // 0x7afe9c: EnterFrame
    //     0x7afe9c: stp             fp, lr, [SP, #-0x10]!
    //     0x7afea0: mov             fp, SP
    // 0x7afea4: AllocStack(0x8)
    //     0x7afea4: sub             SP, SP, #8
    // 0x7afea8: CheckStackOverflow
    //     0x7afea8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7afeac: cmp             SP, x16
    //     0x7afeb0: b.ls            #0x7affe0
    // 0x7afeb4: ldr             x0, [fp, #0x10]
    // 0x7afeb8: r2 = Null
    //     0x7afeb8: mov             x2, NULL
    // 0x7afebc: r1 = Null
    //     0x7afebc: mov             x1, NULL
    // 0x7afec0: r4 = 59
    //     0x7afec0: mov             x4, #0x3b
    // 0x7afec4: branchIfSmi(r0, 0x7afed0)
    //     0x7afec4: tbz             w0, #0, #0x7afed0
    // 0x7afec8: r4 = LoadClassIdInstr(r0)
    //     0x7afec8: ldur            x4, [x0, #-1]
    //     0x7afecc: ubfx            x4, x4, #0xc, #0x14
    // 0x7afed0: r17 = 4173
    //     0x7afed0: mov             x17, #0x104d
    // 0x7afed4: cmp             x4, x17
    // 0x7afed8: b.eq            #0x7afef0
    // 0x7afedc: r8 = _CupertinoTextSelectionToolbarContent
    //     0x7afedc: add             x8, PP, #0x40, lsl #12  ; [pp+0x40398] Type: _CupertinoTextSelectionToolbarContent
    //     0x7afee0: ldr             x8, [x8, #0x398]
    // 0x7afee4: r3 = Null
    //     0x7afee4: add             x3, PP, #0x40, lsl #12  ; [pp+0x403a0] Null
    //     0x7afee8: ldr             x3, [x3, #0x3a0]
    // 0x7afeec: r0 = _CupertinoTextSelectionToolbarContent()
    //     0x7afeec: bl              #0x615bb4  ; IsType__CupertinoTextSelectionToolbarContent_Stub
    // 0x7afef0: ldr             x3, [fp, #0x18]
    // 0x7afef4: LoadField: r2 = r3->field_7
    //     0x7afef4: ldur            w2, [x3, #7]
    // 0x7afef8: DecompressPointer r2
    //     0x7afef8: add             x2, x2, HEAP, lsl #32
    // 0x7afefc: ldr             x0, [fp, #0x10]
    // 0x7aff00: r1 = Null
    //     0x7aff00: mov             x1, NULL
    // 0x7aff04: cmp             w2, NULL
    // 0x7aff08: b.eq            #0x7aff2c
    // 0x7aff0c: LoadField: r4 = r2->field_17
    //     0x7aff0c: ldur            w4, [x2, #0x17]
    // 0x7aff10: DecompressPointer r4
    //     0x7aff10: add             x4, x4, HEAP, lsl #32
    // 0x7aff14: r8 = X0 bound StatefulWidget
    //     0x7aff14: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7aff18: ldr             x8, [x8, #0x858]
    // 0x7aff1c: LoadField: r9 = r4->field_7
    //     0x7aff1c: ldur            x9, [x4, #7]
    // 0x7aff20: r3 = Null
    //     0x7aff20: add             x3, PP, #0x40, lsl #12  ; [pp+0x403b0] Null
    //     0x7aff24: ldr             x3, [x3, #0x3b0]
    // 0x7aff28: blr             x9
    // 0x7aff2c: ldr             x0, [fp, #0x18]
    // 0x7aff30: LoadField: r1 = r0->field_b
    //     0x7aff30: ldur            w1, [x0, #0xb]
    // 0x7aff34: DecompressPointer r1
    //     0x7aff34: add             x1, x1, HEAP, lsl #32
    // 0x7aff38: cmp             w1, NULL
    // 0x7aff3c: b.eq            #0x7affe8
    // 0x7aff40: LoadField: r2 = r1->field_f
    //     0x7aff40: ldur            w2, [x1, #0xf]
    // 0x7aff44: DecompressPointer r2
    //     0x7aff44: add             x2, x2, HEAP, lsl #32
    // 0x7aff48: ldr             x1, [fp, #0x10]
    // 0x7aff4c: LoadField: r3 = r1->field_f
    //     0x7aff4c: ldur            w3, [x1, #0xf]
    // 0x7aff50: DecompressPointer r3
    //     0x7aff50: add             x3, x3, HEAP, lsl #32
    // 0x7aff54: cmp             w2, w3
    // 0x7aff58: b.eq            #0x7affd0
    // 0x7aff5c: r1 = 0
    //     0x7aff5c: mov             x1, #0
    // 0x7aff60: StoreField: r0->field_1f = r1
    //     0x7aff60: stur            x1, [x0, #0x1f]
    // 0x7aff64: StoreField: r0->field_27 = rNULL
    //     0x7aff64: stur            NULL, [x0, #0x27]
    // 0x7aff68: LoadField: r1 = r0->field_1b
    //     0x7aff68: ldur            w1, [x0, #0x1b]
    // 0x7aff6c: DecompressPointer r1
    //     0x7aff6c: add             x1, x1, HEAP, lsl #32
    // 0x7aff70: r16 = Sentinel
    //     0x7aff70: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7aff74: cmp             w1, w16
    // 0x7aff78: b.eq            #0x7affec
    // 0x7aff7c: SaveReg r1
    //     0x7aff7c: str             x1, [SP, #-8]!
    // 0x7aff80: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7aff80: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7aff84: r0 = forward()
    //     0x7aff84: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7aff88: add             SP, SP, #8
    // 0x7aff8c: ldr             x0, [fp, #0x18]
    // 0x7aff90: LoadField: r1 = r0->field_1b
    //     0x7aff90: ldur            w1, [x0, #0x1b]
    // 0x7aff94: DecompressPointer r1
    //     0x7aff94: add             x1, x1, HEAP, lsl #32
    // 0x7aff98: stur            x1, [fp, #-8]
    // 0x7aff9c: r1 = 1
    //     0x7aff9c: mov             x1, #1
    // 0x7affa0: r0 = AllocateContext()
    //     0x7affa0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7affa4: mov             x1, x0
    // 0x7affa8: ldr             x0, [fp, #0x18]
    // 0x7affac: StoreField: r1->field_f = r0
    //     0x7affac: stur            w0, [x1, #0xf]
    // 0x7affb0: mov             x2, x1
    // 0x7affb4: r1 = Function '_statusListener@621408280':.
    //     0x7affb4: add             x1, PP, #0x40, lsl #12  ; [pp+0x40388] AnonymousClosure: (0x7afff8), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0x7b0044)
    //     0x7affb8: ldr             x1, [x1, #0x388]
    // 0x7affbc: r0 = AllocateClosure()
    //     0x7affbc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7affc0: ldur            x16, [fp, #-8]
    // 0x7affc4: stp             x0, x16, [SP, #-0x10]!
    // 0x7affc8: r0 = removeStatusListener()
    //     0x7affc8: bl              #0xc5df14  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0x7affcc: add             SP, SP, #0x10
    // 0x7affd0: r0 = Null
    //     0x7affd0: mov             x0, NULL
    // 0x7affd4: LeaveFrame
    //     0x7affd4: mov             SP, fp
    //     0x7affd8: ldp             fp, lr, [SP], #0x10
    // 0x7affdc: ret
    //     0x7affdc: ret             
    // 0x7affe0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7affe0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7affe4: b               #0x7afeb4
    // 0x7affe8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7affe8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7affec: r9 = _controller
    //     0x7affec: add             x9, PP, #0x40, lsl #12  ; [pp+0x40380] Field <_CupertinoTextSelectionToolbarContentState@621408280._controller@621408280>: late (offset: 0x1c)
    //     0x7afff0: ldr             x9, [x9, #0x380]
    // 0x7afff4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7afff4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _statusListener(dynamic, AnimationStatus) {
    // ** addr: 0x7afff8, size: 0x4c
    // 0x7afff8: EnterFrame
    //     0x7afff8: stp             fp, lr, [SP, #-0x10]!
    //     0x7afffc: mov             fp, SP
    // 0x7b0000: ldr             x0, [fp, #0x18]
    // 0x7b0004: LoadField: r1 = r0->field_17
    //     0x7b0004: ldur            w1, [x0, #0x17]
    // 0x7b0008: DecompressPointer r1
    //     0x7b0008: add             x1, x1, HEAP, lsl #32
    // 0x7b000c: CheckStackOverflow
    //     0x7b000c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0010: cmp             SP, x16
    //     0x7b0014: b.ls            #0x7b003c
    // 0x7b0018: LoadField: r0 = r1->field_f
    //     0x7b0018: ldur            w0, [x1, #0xf]
    // 0x7b001c: DecompressPointer r0
    //     0x7b001c: add             x0, x0, HEAP, lsl #32
    // 0x7b0020: ldr             x16, [fp, #0x10]
    // 0x7b0024: stp             x16, x0, [SP, #-0x10]!
    // 0x7b0028: r0 = _statusListener()
    //     0x7b0028: bl              #0x7b0044  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener
    // 0x7b002c: add             SP, SP, #0x10
    // 0x7b0030: LeaveFrame
    //     0x7b0030: mov             SP, fp
    //     0x7b0034: ldp             fp, lr, [SP], #0x10
    // 0x7b0038: ret
    //     0x7b0038: ret             
    // 0x7b003c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b003c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0040: b               #0x7b0018
  }
  _ _statusListener(/* No info */) {
    // ** addr: 0x7b0044, size: 0x100
    // 0x7b0044: EnterFrame
    //     0x7b0044: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0048: mov             fp, SP
    // 0x7b004c: AllocStack(0x8)
    //     0x7b004c: sub             SP, SP, #8
    // 0x7b0050: CheckStackOverflow
    //     0x7b0050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7b0054: cmp             SP, x16
    //     0x7b0058: b.ls            #0x7b0130
    // 0x7b005c: r1 = 1
    //     0x7b005c: mov             x1, #1
    // 0x7b0060: r0 = AllocateContext()
    //     0x7b0060: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b0064: mov             x1, x0
    // 0x7b0068: ldr             x0, [fp, #0x18]
    // 0x7b006c: StoreField: r1->field_f = r0
    //     0x7b006c: stur            w0, [x1, #0xf]
    // 0x7b0070: ldr             x2, [fp, #0x10]
    // 0x7b0074: r16 = Instance_AnimationStatus
    //     0x7b0074: add             x16, PP, #0xd, lsl #12  ; [pp+0xdba8] Obj!AnimationStatus@b65f51
    //     0x7b0078: ldr             x16, [x16, #0xba8]
    // 0x7b007c: cmp             w2, w16
    // 0x7b0080: b.eq            #0x7b0094
    // 0x7b0084: r0 = Null
    //     0x7b0084: mov             x0, NULL
    // 0x7b0088: LeaveFrame
    //     0x7b0088: mov             SP, fp
    //     0x7b008c: ldp             fp, lr, [SP], #0x10
    // 0x7b0090: ret
    //     0x7b0090: ret             
    // 0x7b0094: mov             x2, x1
    // 0x7b0098: r1 = Function '<anonymous closure>':.
    //     0x7b0098: add             x1, PP, #0x40, lsl #12  ; [pp+0x40390] AnonymousClosure: (0x7b0144), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0x7b0044)
    //     0x7b009c: ldr             x1, [x1, #0x390]
    // 0x7b00a0: r0 = AllocateClosure()
    //     0x7b00a0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b00a4: ldr             x16, [fp, #0x18]
    // 0x7b00a8: stp             x0, x16, [SP, #-0x10]!
    // 0x7b00ac: r0 = setState()
    //     0x7b00ac: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7b00b0: add             SP, SP, #0x10
    // 0x7b00b4: ldr             x0, [fp, #0x18]
    // 0x7b00b8: LoadField: r1 = r0->field_1b
    //     0x7b00b8: ldur            w1, [x0, #0x1b]
    // 0x7b00bc: DecompressPointer r1
    //     0x7b00bc: add             x1, x1, HEAP, lsl #32
    // 0x7b00c0: r16 = Sentinel
    //     0x7b00c0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7b00c4: cmp             w1, w16
    // 0x7b00c8: b.eq            #0x7b0138
    // 0x7b00cc: SaveReg r1
    //     0x7b00cc: str             x1, [SP, #-8]!
    // 0x7b00d0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7b00d0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7b00d4: r0 = forward()
    //     0x7b00d4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7b00d8: add             SP, SP, #8
    // 0x7b00dc: ldr             x0, [fp, #0x18]
    // 0x7b00e0: LoadField: r1 = r0->field_1b
    //     0x7b00e0: ldur            w1, [x0, #0x1b]
    // 0x7b00e4: DecompressPointer r1
    //     0x7b00e4: add             x1, x1, HEAP, lsl #32
    // 0x7b00e8: stur            x1, [fp, #-8]
    // 0x7b00ec: r1 = 1
    //     0x7b00ec: mov             x1, #1
    // 0x7b00f0: r0 = AllocateContext()
    //     0x7b00f0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7b00f4: mov             x1, x0
    // 0x7b00f8: ldr             x0, [fp, #0x18]
    // 0x7b00fc: StoreField: r1->field_f = r0
    //     0x7b00fc: stur            w0, [x1, #0xf]
    // 0x7b0100: mov             x2, x1
    // 0x7b0104: r1 = Function '_statusListener@621408280':.
    //     0x7b0104: add             x1, PP, #0x40, lsl #12  ; [pp+0x40388] AnonymousClosure: (0x7afff8), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0x7b0044)
    //     0x7b0108: ldr             x1, [x1, #0x388]
    // 0x7b010c: r0 = AllocateClosure()
    //     0x7b010c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7b0110: ldur            x16, [fp, #-8]
    // 0x7b0114: stp             x0, x16, [SP, #-0x10]!
    // 0x7b0118: r0 = removeStatusListener()
    //     0x7b0118: bl              #0xc5df14  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::removeStatusListener
    // 0x7b011c: add             SP, SP, #0x10
    // 0x7b0120: r0 = Null
    //     0x7b0120: mov             x0, NULL
    // 0x7b0124: LeaveFrame
    //     0x7b0124: mov             SP, fp
    //     0x7b0128: ldp             fp, lr, [SP], #0x10
    // 0x7b012c: ret
    //     0x7b012c: ret             
    // 0x7b0130: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7b0130: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7b0134: b               #0x7b005c
    // 0x7b0138: r9 = _controller
    //     0x7b0138: add             x9, PP, #0x40, lsl #12  ; [pp+0x40380] Field <_CupertinoTextSelectionToolbarContentState@621408280._controller@621408280>: late (offset: 0x1c)
    //     0x7b013c: ldr             x9, [x9, #0x380]
    // 0x7b0140: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7b0140: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x7b0144, size: 0x54
    // 0x7b0144: EnterFrame
    //     0x7b0144: stp             fp, lr, [SP, #-0x10]!
    //     0x7b0148: mov             fp, SP
    // 0x7b014c: ldr             x1, [fp, #0x10]
    // 0x7b0150: LoadField: r2 = r1->field_17
    //     0x7b0150: ldur            w2, [x1, #0x17]
    // 0x7b0154: DecompressPointer r2
    //     0x7b0154: add             x2, x2, HEAP, lsl #32
    // 0x7b0158: LoadField: r1 = r2->field_f
    //     0x7b0158: ldur            w1, [x2, #0xf]
    // 0x7b015c: DecompressPointer r1
    //     0x7b015c: add             x1, x1, HEAP, lsl #32
    // 0x7b0160: LoadField: r2 = r1->field_27
    //     0x7b0160: ldur            w2, [x1, #0x27]
    // 0x7b0164: DecompressPointer r2
    //     0x7b0164: add             x2, x2, HEAP, lsl #32
    // 0x7b0168: cmp             w2, NULL
    // 0x7b016c: b.eq            #0x7b0194
    // 0x7b0170: r3 = LoadInt32Instr(r2)
    //     0x7b0170: sbfx            x3, x2, #1, #0x1f
    //     0x7b0174: tbz             w2, #0, #0x7b017c
    //     0x7b0178: ldur            x3, [x2, #7]
    // 0x7b017c: StoreField: r1->field_1f = r3
    //     0x7b017c: stur            x3, [x1, #0x1f]
    // 0x7b0180: StoreField: r1->field_27 = rNULL
    //     0x7b0180: stur            NULL, [x1, #0x27]
    // 0x7b0184: r0 = Null
    //     0x7b0184: mov             x0, NULL
    // 0x7b0188: LeaveFrame
    //     0x7b0188: mov             SP, fp
    //     0x7b018c: ldp             fp, lr, [SP], #0x10
    // 0x7b0190: ret
    //     0x7b0190: ret             
    // 0x7b0194: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7b0194: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x844f60, size: 0x22c
    // 0x844f60: EnterFrame
    //     0x844f60: stp             fp, lr, [SP, #-0x10]!
    //     0x844f64: mov             fp, SP
    // 0x844f68: AllocStack(0x58)
    //     0x844f68: sub             SP, SP, #0x58
    // 0x844f6c: CheckStackOverflow
    //     0x844f6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x844f70: cmp             SP, x16
    //     0x844f74: b.ls            #0x845170
    // 0x844f78: ldr             x0, [fp, #0x18]
    // 0x844f7c: LoadField: r1 = r0->field_b
    //     0x844f7c: ldur            w1, [x0, #0xb]
    // 0x844f80: DecompressPointer r1
    //     0x844f80: add             x1, x1, HEAP, lsl #32
    // 0x844f84: stur            x1, [fp, #-0x28]
    // 0x844f88: cmp             w1, NULL
    // 0x844f8c: b.eq            #0x845178
    // 0x844f90: LoadField: r2 = r1->field_b
    //     0x844f90: ldur            w2, [x1, #0xb]
    // 0x844f94: DecompressPointer r2
    //     0x844f94: add             x2, x2, HEAP, lsl #32
    // 0x844f98: stur            x2, [fp, #-0x20]
    // 0x844f9c: LoadField: r3 = r1->field_13
    //     0x844f9c: ldur            w3, [x1, #0x13]
    // 0x844fa0: DecompressPointer r3
    //     0x844fa0: add             x3, x3, HEAP, lsl #32
    // 0x844fa4: stur            x3, [fp, #-0x18]
    // 0x844fa8: LoadField: r4 = r0->field_1b
    //     0x844fa8: ldur            w4, [x0, #0x1b]
    // 0x844fac: DecompressPointer r4
    //     0x844fac: add             x4, x4, HEAP, lsl #32
    // 0x844fb0: r16 = Sentinel
    //     0x844fb0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x844fb4: cmp             w4, w16
    // 0x844fb8: b.eq            #0x84517c
    // 0x844fbc: stur            x4, [fp, #-0x10]
    // 0x844fc0: LoadField: r5 = r0->field_1f
    //     0x844fc0: ldur            x5, [x0, #0x1f]
    // 0x844fc4: stur            x5, [fp, #-8]
    // 0x844fc8: r1 = 1
    //     0x844fc8: mov             x1, #1
    // 0x844fcc: r0 = AllocateContext()
    //     0x844fcc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x844fd0: mov             x1, x0
    // 0x844fd4: ldr             x0, [fp, #0x18]
    // 0x844fd8: stur            x1, [fp, #-0x30]
    // 0x844fdc: StoreField: r1->field_f = r0
    //     0x844fdc: stur            w0, [x1, #0xf]
    // 0x844fe0: r0 = CupertinoTextSelectionToolbarButton()
    //     0x844fe0: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x844fe4: ldur            x2, [fp, #-0x30]
    // 0x844fe8: r1 = Function '_handlePreviousPage@621408280':.
    //     0x844fe8: add             x1, PP, #0x40, lsl #12  ; [pp+0x40370] AnonymousClosure: (0x8452c8), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handlePreviousPage (0x845310)
    //     0x844fec: ldr             x1, [x1, #0x370]
    // 0x844ff0: stur            x0, [fp, #-0x30]
    // 0x844ff4: r0 = AllocateClosure()
    //     0x844ff4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x844ff8: ldur            x16, [fp, #-0x30]
    // 0x844ffc: r30 = "◀"
    //     0x844ffc: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d1c0] "◀"
    //     0x845000: ldr             lr, [lr, #0x1c0]
    // 0x845004: stp             lr, x16, [SP, #-0x10]!
    // 0x845008: SaveReg r0
    //     0x845008: str             x0, [SP, #-8]!
    // 0x84500c: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0x84500c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0x845010: ldr             x4, [x4, #0xdb8]
    // 0x845014: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x845014: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x845018: add             SP, SP, #0x18
    // 0x84501c: ldr             x16, [fp, #0x10]
    // 0x845020: SaveReg r16
    //     0x845020: str             x16, [SP, #-8]!
    // 0x845024: r0 = of()
    //     0x845024: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x845028: add             SP, SP, #8
    // 0x84502c: LoadField: d0 = r0->field_b
    //     0x84502c: ldur            d0, [x0, #0xb]
    // 0x845030: d1 = 1.000000
    //     0x845030: fmov            d1, #1.00000000
    // 0x845034: fdiv            d2, d1, d0
    // 0x845038: stur            d2, [fp, #-0x58]
    // 0x84503c: r1 = 1
    //     0x84503c: mov             x1, #1
    // 0x845040: r0 = AllocateContext()
    //     0x845040: bl              #0xd68aa4  ; AllocateContextStub
    // 0x845044: mov             x1, x0
    // 0x845048: ldr             x0, [fp, #0x18]
    // 0x84504c: stur            x1, [fp, #-0x38]
    // 0x845050: StoreField: r1->field_f = r0
    //     0x845050: stur            w0, [x1, #0xf]
    // 0x845054: r0 = CupertinoTextSelectionToolbarButton()
    //     0x845054: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x845058: ldur            x2, [fp, #-0x38]
    // 0x84505c: r1 = Function '_handleNextPage@621408280':.
    //     0x84505c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40378] AnonymousClosure: (0x845198), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handleNextPage (0x8451e0)
    //     0x845060: ldr             x1, [x1, #0x378]
    // 0x845064: stur            x0, [fp, #-0x38]
    // 0x845068: r0 = AllocateClosure()
    //     0x845068: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x84506c: ldur            x16, [fp, #-0x38]
    // 0x845070: r30 = "▶"
    //     0x845070: add             lr, PP, #0x1d, lsl #12  ; [pp+0x1d1b8] "▶"
    //     0x845074: ldr             lr, [lr, #0x1b8]
    // 0x845078: stp             lr, x16, [SP, #-0x10]!
    // 0x84507c: SaveReg r0
    //     0x84507c: str             x0, [SP, #-8]!
    // 0x845080: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0x845080: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0x845084: ldr             x4, [x4, #0xdb8]
    // 0x845088: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x845088: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x84508c: add             SP, SP, #0x18
    // 0x845090: r0 = CupertinoTextSelectionToolbarButton()
    //     0x845090: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x845094: stur            x0, [fp, #-0x40]
    // 0x845098: r16 = "▶"
    //     0x845098: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d1b8] "▶"
    //     0x84509c: ldr             x16, [x16, #0x1b8]
    // 0x8450a0: stp             x16, x0, [SP, #-0x10]!
    // 0x8450a4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x8450a4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x8450a8: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x8450a8: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x8450ac: add             SP, SP, #0x10
    // 0x8450b0: ldr             x0, [fp, #0x18]
    // 0x8450b4: LoadField: r1 = r0->field_b
    //     0x8450b4: ldur            w1, [x0, #0xb]
    // 0x8450b8: DecompressPointer r1
    //     0x8450b8: add             x1, x1, HEAP, lsl #32
    // 0x8450bc: cmp             w1, NULL
    // 0x8450c0: b.eq            #0x845188
    // 0x8450c4: LoadField: r0 = r1->field_f
    //     0x8450c4: ldur            w0, [x1, #0xf]
    // 0x8450c8: DecompressPointer r0
    //     0x8450c8: add             x0, x0, HEAP, lsl #32
    // 0x8450cc: stur            x0, [fp, #-0x48]
    // 0x8450d0: r0 = _CupertinoTextSelectionToolbarItems()
    //     0x8450d0: bl              #0x84518c  ; Allocate_CupertinoTextSelectionToolbarItemsStub -> _CupertinoTextSelectionToolbarItems (size=0x2c)
    // 0x8450d4: mov             x1, x0
    // 0x8450d8: ldur            x0, [fp, #-8]
    // 0x8450dc: stur            x1, [fp, #-0x50]
    // 0x8450e0: StoreField: r1->field_23 = r0
    //     0x8450e0: stur            x0, [x1, #0x23]
    // 0x8450e4: ldur            x0, [fp, #-0x48]
    // 0x8450e8: StoreField: r1->field_f = r0
    //     0x8450e8: stur            w0, [x1, #0xf]
    // 0x8450ec: ldur            x0, [fp, #-0x30]
    // 0x8450f0: StoreField: r1->field_b = r0
    //     0x8450f0: stur            w0, [x1, #0xb]
    // 0x8450f4: ldur            d0, [fp, #-0x58]
    // 0x8450f8: StoreField: r1->field_13 = d0
    //     0x8450f8: stur            d0, [x1, #0x13]
    // 0x8450fc: ldur            x0, [fp, #-0x38]
    // 0x845100: StoreField: r1->field_1b = r0
    //     0x845100: stur            w0, [x1, #0x1b]
    // 0x845104: ldur            x0, [fp, #-0x40]
    // 0x845108: StoreField: r1->field_1f = r0
    //     0x845108: stur            w0, [x1, #0x1f]
    // 0x84510c: r0 = FadeTransition()
    //     0x84510c: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x845110: mov             x1, x0
    // 0x845114: ldur            x0, [fp, #-0x10]
    // 0x845118: StoreField: r1->field_f = r0
    //     0x845118: stur            w0, [x1, #0xf]
    // 0x84511c: r0 = false
    //     0x84511c: add             x0, NULL, #0x30  ; false
    // 0x845120: StoreField: r1->field_13 = r0
    //     0x845120: stur            w0, [x1, #0x13]
    // 0x845124: ldur            x0, [fp, #-0x50]
    // 0x845128: StoreField: r1->field_b = r0
    //     0x845128: stur            w0, [x1, #0xb]
    // 0x84512c: ldur            x0, [fp, #-0x28]
    // 0x845130: LoadField: r2 = r0->field_17
    //     0x845130: ldur            w2, [x0, #0x17]
    // 0x845134: DecompressPointer r2
    //     0x845134: add             x2, x2, HEAP, lsl #32
    // 0x845138: ldr             x16, [fp, #0x10]
    // 0x84513c: stp             x16, x2, [SP, #-0x10]!
    // 0x845140: ldur            x16, [fp, #-0x20]
    // 0x845144: ldur            lr, [fp, #-0x18]
    // 0x845148: stp             lr, x16, [SP, #-0x10]!
    // 0x84514c: SaveReg r1
    //     0x84514c: str             x1, [SP, #-8]!
    // 0x845150: mov             x0, x2
    // 0x845154: ClosureCall
    //     0x845154: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    //     0x845158: ldur            x2, [x0, #0x1f]
    //     0x84515c: blr             x2
    // 0x845160: add             SP, SP, #0x28
    // 0x845164: LeaveFrame
    //     0x845164: mov             SP, fp
    //     0x845168: ldp             fp, lr, [SP], #0x10
    // 0x84516c: ret
    //     0x84516c: ret             
    // 0x845170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845170: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x845174: b               #0x844f78
    // 0x845178: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845178: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84517c: r9 = _controller
    //     0x84517c: add             x9, PP, #0x40, lsl #12  ; [pp+0x40380] Field <_CupertinoTextSelectionToolbarContentState@621408280._controller@621408280>: late (offset: 0x1c)
    //     0x845180: ldr             x9, [x9, #0x380]
    // 0x845184: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x845184: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x845188: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x845188: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleNextPage(dynamic) {
    // ** addr: 0x845198, size: 0x48
    // 0x845198: EnterFrame
    //     0x845198: stp             fp, lr, [SP, #-0x10]!
    //     0x84519c: mov             fp, SP
    // 0x8451a0: ldr             x0, [fp, #0x10]
    // 0x8451a4: LoadField: r1 = r0->field_17
    //     0x8451a4: ldur            w1, [x0, #0x17]
    // 0x8451a8: DecompressPointer r1
    //     0x8451a8: add             x1, x1, HEAP, lsl #32
    // 0x8451ac: CheckStackOverflow
    //     0x8451ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8451b0: cmp             SP, x16
    //     0x8451b4: b.ls            #0x8451d8
    // 0x8451b8: LoadField: r0 = r1->field_f
    //     0x8451b8: ldur            w0, [x1, #0xf]
    // 0x8451bc: DecompressPointer r0
    //     0x8451bc: add             x0, x0, HEAP, lsl #32
    // 0x8451c0: SaveReg r0
    //     0x8451c0: str             x0, [SP, #-8]!
    // 0x8451c4: r0 = _handleNextPage()
    //     0x8451c4: bl              #0x8451e0  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handleNextPage
    // 0x8451c8: add             SP, SP, #8
    // 0x8451cc: LeaveFrame
    //     0x8451cc: mov             SP, fp
    //     0x8451d0: ldp             fp, lr, [SP], #0x10
    // 0x8451d4: ret
    //     0x8451d4: ret             
    // 0x8451d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8451d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8451dc: b               #0x8451b8
  }
  _ _handleNextPage(/* No info */) {
    // ** addr: 0x8451e0, size: 0xe8
    // 0x8451e0: EnterFrame
    //     0x8451e0: stp             fp, lr, [SP, #-0x10]!
    //     0x8451e4: mov             fp, SP
    // 0x8451e8: AllocStack(0x8)
    //     0x8451e8: sub             SP, SP, #8
    // 0x8451ec: CheckStackOverflow
    //     0x8451ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8451f0: cmp             SP, x16
    //     0x8451f4: b.ls            #0x8452b4
    // 0x8451f8: ldr             x0, [fp, #0x10]
    // 0x8451fc: LoadField: r1 = r0->field_1b
    //     0x8451fc: ldur            w1, [x0, #0x1b]
    // 0x845200: DecompressPointer r1
    //     0x845200: add             x1, x1, HEAP, lsl #32
    // 0x845204: r16 = Sentinel
    //     0x845204: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x845208: cmp             w1, w16
    // 0x84520c: b.eq            #0x8452bc
    // 0x845210: SaveReg r1
    //     0x845210: str             x1, [SP, #-8]!
    // 0x845214: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x845214: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x845218: r0 = reverse()
    //     0x845218: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x84521c: add             SP, SP, #8
    // 0x845220: ldr             x0, [fp, #0x10]
    // 0x845224: LoadField: r1 = r0->field_1b
    //     0x845224: ldur            w1, [x0, #0x1b]
    // 0x845228: DecompressPointer r1
    //     0x845228: add             x1, x1, HEAP, lsl #32
    // 0x84522c: stur            x1, [fp, #-8]
    // 0x845230: r1 = 1
    //     0x845230: mov             x1, #1
    // 0x845234: r0 = AllocateContext()
    //     0x845234: bl              #0xd68aa4  ; AllocateContextStub
    // 0x845238: mov             x1, x0
    // 0x84523c: ldr             x0, [fp, #0x10]
    // 0x845240: StoreField: r1->field_f = r0
    //     0x845240: stur            w0, [x1, #0xf]
    // 0x845244: mov             x2, x1
    // 0x845248: r1 = Function '_statusListener@621408280':.
    //     0x845248: add             x1, PP, #0x40, lsl #12  ; [pp+0x40388] AnonymousClosure: (0x7afff8), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0x7b0044)
    //     0x84524c: ldr             x1, [x1, #0x388]
    // 0x845250: r0 = AllocateClosure()
    //     0x845250: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x845254: ldur            x16, [fp, #-8]
    // 0x845258: stp             x0, x16, [SP, #-0x10]!
    // 0x84525c: r0 = addStatusListener()
    //     0x84525c: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x845260: add             SP, SP, #0x10
    // 0x845264: ldr             x2, [fp, #0x10]
    // 0x845268: LoadField: r3 = r2->field_1f
    //     0x845268: ldur            x3, [x2, #0x1f]
    // 0x84526c: add             x4, x3, #1
    // 0x845270: r0 = BoxInt64Instr(r4)
    //     0x845270: sbfiz           x0, x4, #1, #0x1f
    //     0x845274: cmp             x4, x0, asr #1
    //     0x845278: b.eq            #0x845284
    //     0x84527c: bl              #0xd69bb8
    //     0x845280: stur            x4, [x0, #7]
    // 0x845284: StoreField: r2->field_27 = r0
    //     0x845284: stur            w0, [x2, #0x27]
    //     0x845288: tbz             w0, #0, #0x8452a4
    //     0x84528c: ldurb           w16, [x2, #-1]
    //     0x845290: ldurb           w17, [x0, #-1]
    //     0x845294: and             x16, x17, x16, lsr #2
    //     0x845298: tst             x16, HEAP, lsr #32
    //     0x84529c: b.eq            #0x8452a4
    //     0x8452a0: bl              #0xd6828c
    // 0x8452a4: r0 = Null
    //     0x8452a4: mov             x0, NULL
    // 0x8452a8: LeaveFrame
    //     0x8452a8: mov             SP, fp
    //     0x8452ac: ldp             fp, lr, [SP], #0x10
    // 0x8452b0: ret
    //     0x8452b0: ret             
    // 0x8452b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8452b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8452b8: b               #0x8451f8
    // 0x8452bc: r9 = _controller
    //     0x8452bc: add             x9, PP, #0x40, lsl #12  ; [pp+0x40380] Field <_CupertinoTextSelectionToolbarContentState@621408280._controller@621408280>: late (offset: 0x1c)
    //     0x8452c0: ldr             x9, [x9, #0x380]
    // 0x8452c4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8452c4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handlePreviousPage(dynamic) {
    // ** addr: 0x8452c8, size: 0x48
    // 0x8452c8: EnterFrame
    //     0x8452c8: stp             fp, lr, [SP, #-0x10]!
    //     0x8452cc: mov             fp, SP
    // 0x8452d0: ldr             x0, [fp, #0x10]
    // 0x8452d4: LoadField: r1 = r0->field_17
    //     0x8452d4: ldur            w1, [x0, #0x17]
    // 0x8452d8: DecompressPointer r1
    //     0x8452d8: add             x1, x1, HEAP, lsl #32
    // 0x8452dc: CheckStackOverflow
    //     0x8452dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8452e0: cmp             SP, x16
    //     0x8452e4: b.ls            #0x845308
    // 0x8452e8: LoadField: r0 = r1->field_f
    //     0x8452e8: ldur            w0, [x1, #0xf]
    // 0x8452ec: DecompressPointer r0
    //     0x8452ec: add             x0, x0, HEAP, lsl #32
    // 0x8452f0: SaveReg r0
    //     0x8452f0: str             x0, [SP, #-8]!
    // 0x8452f4: r0 = _handlePreviousPage()
    //     0x8452f4: bl              #0x845310  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_handlePreviousPage
    // 0x8452f8: add             SP, SP, #8
    // 0x8452fc: LeaveFrame
    //     0x8452fc: mov             SP, fp
    //     0x845300: ldp             fp, lr, [SP], #0x10
    // 0x845304: ret
    //     0x845304: ret             
    // 0x845308: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x845308: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x84530c: b               #0x8452e8
  }
  _ _handlePreviousPage(/* No info */) {
    // ** addr: 0x845310, size: 0xe8
    // 0x845310: EnterFrame
    //     0x845310: stp             fp, lr, [SP, #-0x10]!
    //     0x845314: mov             fp, SP
    // 0x845318: AllocStack(0x8)
    //     0x845318: sub             SP, SP, #8
    // 0x84531c: CheckStackOverflow
    //     0x84531c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x845320: cmp             SP, x16
    //     0x845324: b.ls            #0x8453e4
    // 0x845328: ldr             x0, [fp, #0x10]
    // 0x84532c: LoadField: r1 = r0->field_1b
    //     0x84532c: ldur            w1, [x0, #0x1b]
    // 0x845330: DecompressPointer r1
    //     0x845330: add             x1, x1, HEAP, lsl #32
    // 0x845334: r16 = Sentinel
    //     0x845334: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x845338: cmp             w1, w16
    // 0x84533c: b.eq            #0x8453ec
    // 0x845340: SaveReg r1
    //     0x845340: str             x1, [SP, #-8]!
    // 0x845344: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x845344: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x845348: r0 = reverse()
    //     0x845348: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x84534c: add             SP, SP, #8
    // 0x845350: ldr             x0, [fp, #0x10]
    // 0x845354: LoadField: r1 = r0->field_1b
    //     0x845354: ldur            w1, [x0, #0x1b]
    // 0x845358: DecompressPointer r1
    //     0x845358: add             x1, x1, HEAP, lsl #32
    // 0x84535c: stur            x1, [fp, #-8]
    // 0x845360: r1 = 1
    //     0x845360: mov             x1, #1
    // 0x845364: r0 = AllocateContext()
    //     0x845364: bl              #0xd68aa4  ; AllocateContextStub
    // 0x845368: mov             x1, x0
    // 0x84536c: ldr             x0, [fp, #0x10]
    // 0x845370: StoreField: r1->field_f = r0
    //     0x845370: stur            w0, [x1, #0xf]
    // 0x845374: mov             x2, x1
    // 0x845378: r1 = Function '_statusListener@621408280':.
    //     0x845378: add             x1, PP, #0x40, lsl #12  ; [pp+0x40388] AnonymousClosure: (0x7afff8), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::_statusListener (0x7b0044)
    //     0x84537c: ldr             x1, [x1, #0x388]
    // 0x845380: r0 = AllocateClosure()
    //     0x845380: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x845384: ldur            x16, [fp, #-8]
    // 0x845388: stp             x0, x16, [SP, #-0x10]!
    // 0x84538c: r0 = addStatusListener()
    //     0x84538c: bl              #0xc52a20  ; [package:flutter/src/animation/animation_controller.dart] _AnimationController&Animation&AnimationEagerListenerMixin&AnimationLocalListenersMixin&AnimationLocalStatusListenersMixin::addStatusListener
    // 0x845390: add             SP, SP, #0x10
    // 0x845394: ldr             x2, [fp, #0x10]
    // 0x845398: LoadField: r3 = r2->field_1f
    //     0x845398: ldur            x3, [x2, #0x1f]
    // 0x84539c: sub             x4, x3, #1
    // 0x8453a0: r0 = BoxInt64Instr(r4)
    //     0x8453a0: sbfiz           x0, x4, #1, #0x1f
    //     0x8453a4: cmp             x4, x0, asr #1
    //     0x8453a8: b.eq            #0x8453b4
    //     0x8453ac: bl              #0xd69bb8
    //     0x8453b0: stur            x4, [x0, #7]
    // 0x8453b4: StoreField: r2->field_27 = r0
    //     0x8453b4: stur            w0, [x2, #0x27]
    //     0x8453b8: tbz             w0, #0, #0x8453d4
    //     0x8453bc: ldurb           w16, [x2, #-1]
    //     0x8453c0: ldurb           w17, [x0, #-1]
    //     0x8453c4: and             x16, x17, x16, lsr #2
    //     0x8453c8: tst             x16, HEAP, lsr #32
    //     0x8453cc: b.eq            #0x8453d4
    //     0x8453d0: bl              #0xd6828c
    // 0x8453d4: r0 = Null
    //     0x8453d4: mov             x0, NULL
    // 0x8453d8: LeaveFrame
    //     0x8453d8: mov             SP, fp
    //     0x8453dc: ldp             fp, lr, [SP], #0x10
    // 0x8453e0: ret
    //     0x8453e0: ret             
    // 0x8453e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x8453e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x8453e8: b               #0x845328
    // 0x8453ec: r9 = _controller
    //     0x8453ec: add             x9, PP, #0x40, lsl #12  ; [pp+0x40380] Field <_CupertinoTextSelectionToolbarContentState@621408280._controller@621408280>: late (offset: 0x1c)
    //     0x8453f0: ldr             x9, [x9, #0x380]
    // 0x8453f4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8453f4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d91c0, size: 0x88
    // 0x9d91c0: EnterFrame
    //     0x9d91c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9d91c4: mov             fp, SP
    // 0x9d91c8: AllocStack(0x8)
    //     0x9d91c8: sub             SP, SP, #8
    // 0x9d91cc: CheckStackOverflow
    //     0x9d91cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d91d0: cmp             SP, x16
    //     0x9d91d4: b.ls            #0x9d9240
    // 0x9d91d8: r1 = <double>
    //     0x9d91d8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d91dc: r0 = AnimationController()
    //     0x9d91dc: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d91e0: stur            x0, [fp, #-8]
    // 0x9d91e4: ldr             x16, [fp, #0x10]
    // 0x9d91e8: stp             x16, x0, [SP, #-0x10]!
    // 0x9d91ec: r16 = 1.000000
    //     0x9d91ec: ldr             x16, [PP, #0x7448]  ; [pp+0x7448] 1
    // 0x9d91f0: r30 = Instance_Duration
    //     0x9d91f0: add             lr, PP, #0x20, lsl #12  ; [pp+0x20968] Obj!Duration@b67b41
    //     0x9d91f4: ldr             lr, [lr, #0x968]
    // 0x9d91f8: stp             lr, x16, [SP, #-0x10]!
    // 0x9d91fc: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x3, value, 0x2, null]
    //     0x9d91fc: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ff8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0x9d9200: ldr             x4, [x4, #0xff8]
    // 0x9d9204: r0 = AnimationController()
    //     0x9d9204: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d9208: add             SP, SP, #0x20
    // 0x9d920c: ldur            x0, [fp, #-8]
    // 0x9d9210: ldr             x1, [fp, #0x10]
    // 0x9d9214: StoreField: r1->field_1b = r0
    //     0x9d9214: stur            w0, [x1, #0x1b]
    //     0x9d9218: ldurb           w16, [x1, #-1]
    //     0x9d921c: ldurb           w17, [x0, #-1]
    //     0x9d9220: and             x16, x17, x16, lsr #2
    //     0x9d9224: tst             x16, HEAP, lsr #32
    //     0x9d9228: b.eq            #0x9d9230
    //     0x9d922c: bl              #0xd6826c
    // 0x9d9230: r0 = Null
    //     0x9d9230: mov             x0, NULL
    // 0x9d9234: LeaveFrame
    //     0x9d9234: mov             SP, fp
    //     0x9d9238: ldp             fp, lr, [SP], #0x10
    // 0x9d923c: ret
    //     0x9d923c: ret             
    // 0x9d9240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d9240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d9244: b               #0x9d91d8
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a948, size: 0x18
    // 0xa4a948: r4 = 7
    //     0xa4a948: mov             x4, #7
    // 0xa4a94c: r1 = Function 'dispose':.
    //     0xa4a94c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4ba68] AnonymousClosure: (0xa4a960), in [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::dispose (0xa50abc)
    //     0xa4a950: ldr             x1, [x17, #0xa68]
    // 0xa4a954: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a954: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a958: LoadField: r0 = r24->field_17
    //     0xa4a958: ldur            x0, [x24, #0x17]
    // 0xa4a95c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a960, size: 0x48
    // 0xa4a960: EnterFrame
    //     0xa4a960: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a964: mov             fp, SP
    // 0xa4a968: ldr             x0, [fp, #0x10]
    // 0xa4a96c: LoadField: r1 = r0->field_17
    //     0xa4a96c: ldur            w1, [x0, #0x17]
    // 0xa4a970: DecompressPointer r1
    //     0xa4a970: add             x1, x1, HEAP, lsl #32
    // 0xa4a974: CheckStackOverflow
    //     0xa4a974: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a978: cmp             SP, x16
    //     0xa4a97c: b.ls            #0xa4a9a0
    // 0xa4a980: LoadField: r0 = r1->field_f
    //     0xa4a980: ldur            w0, [x1, #0xf]
    // 0xa4a984: DecompressPointer r0
    //     0xa4a984: add             x0, x0, HEAP, lsl #32
    // 0xa4a988: SaveReg r0
    //     0xa4a988: str             x0, [SP, #-8]!
    // 0xa4a98c: r0 = dispose()
    //     0xa4a98c: bl              #0xa50abc  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarContentState::dispose
    // 0xa4a990: add             SP, SP, #8
    // 0xa4a994: LeaveFrame
    //     0xa4a994: mov             SP, fp
    //     0xa4a998: ldp             fp, lr, [SP], #0x10
    // 0xa4a99c: ret
    //     0xa4a99c: ret             
    // 0xa4a9a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a9a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a9a4: b               #0xa4a980
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50abc, size: 0x6c
    // 0xa50abc: EnterFrame
    //     0xa50abc: stp             fp, lr, [SP, #-0x10]!
    //     0xa50ac0: mov             fp, SP
    // 0xa50ac4: CheckStackOverflow
    //     0xa50ac4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50ac8: cmp             SP, x16
    //     0xa50acc: b.ls            #0xa50b14
    // 0xa50ad0: ldr             x0, [fp, #0x10]
    // 0xa50ad4: LoadField: r1 = r0->field_1b
    //     0xa50ad4: ldur            w1, [x0, #0x1b]
    // 0xa50ad8: DecompressPointer r1
    //     0xa50ad8: add             x1, x1, HEAP, lsl #32
    // 0xa50adc: r16 = Sentinel
    //     0xa50adc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa50ae0: cmp             w1, w16
    // 0xa50ae4: b.eq            #0xa50b1c
    // 0xa50ae8: SaveReg r1
    //     0xa50ae8: str             x1, [SP, #-8]!
    // 0xa50aec: r0 = dispose()
    //     0xa50aec: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa50af0: add             SP, SP, #8
    // 0xa50af4: ldr             x16, [fp, #0x10]
    // 0xa50af8: SaveReg r16
    //     0xa50af8: str             x16, [SP, #-8]!
    // 0xa50afc: r0 = dispose()
    //     0xa50afc: bl              #0xa50b28  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] __CupertinoTextSelectionToolbarContentState&State&TickerProviderStateMixin::dispose
    // 0xa50b00: add             SP, SP, #8
    // 0xa50b04: r0 = Null
    //     0xa50b04: mov             x0, NULL
    // 0xa50b08: LeaveFrame
    //     0xa50b08: mov             SP, fp
    //     0xa50b0c: ldp             fp, lr, [SP], #0x10
    // 0xa50b10: ret
    //     0xa50b10: ret             
    // 0xa50b14: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50b14: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50b18: b               #0xa50ad0
    // 0xa50b1c: r9 = _controller
    //     0xa50b1c: add             x9, PP, #0x40, lsl #12  ; [pp+0x40380] Field <_CupertinoTextSelectionToolbarContentState@621408280._controller@621408280>: late (offset: 0x1c)
    //     0xa50b20: ldr             x9, [x9, #0x380]
    // 0xa50b24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa50b24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3449, size: 0x3c, field offset: 0x3c
class _NullElement extends Element {

  static late _NullElement instance; // offset: 0xcf0

  static _NullElement instance() {
    // ** addr: 0x6bd778, size: 0x48
    // 0x6bd778: EnterFrame
    //     0x6bd778: stp             fp, lr, [SP, #-0x10]!
    //     0x6bd77c: mov             fp, SP
    // 0x6bd780: r0 = _NullElement()
    //     0x6bd780: bl              #0x6bd7c0  ; Allocate_NullElementStub -> _NullElement (size=0x3c)
    // 0x6bd784: r1 = Sentinel
    //     0x6bd784: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6bd788: StoreField: r0->field_17 = r1
    //     0x6bd788: stur            w1, [x0, #0x17]
    // 0x6bd78c: r1 = Instance__ElementLifecycle
    //     0x6bd78c: ldr             x1, [PP, #0x3cd0]  ; [pp+0x3cd0] Obj!_ElementLifecycle@b63bb1
    // 0x6bd790: StoreField: r0->field_23 = r1
    //     0x6bd790: stur            w1, [x0, #0x23]
    // 0x6bd794: r1 = false
    //     0x6bd794: add             x1, NULL, #0x30  ; false
    // 0x6bd798: StoreField: r0->field_2f = r1
    //     0x6bd798: stur            w1, [x0, #0x2f]
    // 0x6bd79c: r2 = true
    //     0x6bd79c: add             x2, NULL, #0x20  ; true
    // 0x6bd7a0: StoreField: r0->field_33 = r2
    //     0x6bd7a0: stur            w2, [x0, #0x33]
    // 0x6bd7a4: StoreField: r0->field_37 = r1
    //     0x6bd7a4: stur            w1, [x0, #0x37]
    // 0x6bd7a8: r1 = Instance__NullWidget
    //     0x6bd7a8: add             x1, PP, #0x50, lsl #12  ; [pp+0x50d98] Obj!_NullWidget@b499f1
    //     0x6bd7ac: ldr             x1, [x1, #0xd98]
    // 0x6bd7b0: StoreField: r0->field_1b = r1
    //     0x6bd7b0: stur            w1, [x0, #0x1b]
    // 0x6bd7b4: LeaveFrame
    //     0x6bd7b4: mov             SP, fp
    //     0x6bd7b8: ldp             fp, lr, [SP], #0x10
    // 0x6bd7bc: ret
    //     0x6bd7bc: ret             
  }
}

// class id: 3471, size: 0x50, field offset: 0x44
class _CupertinoTextSelectionToolbarItemsElement extends RenderObjectElement {

  late List<Element> _children; // offset: 0x44

  _ update(/* No info */) {
    // ** addr: 0x6b1c44, size: 0x1c0
    // 0x6b1c44: EnterFrame
    //     0x6b1c44: stp             fp, lr, [SP, #-0x10]!
    //     0x6b1c48: mov             fp, SP
    // 0x6b1c4c: AllocStack(0x8)
    //     0x6b1c4c: sub             SP, SP, #8
    // 0x6b1c50: CheckStackOverflow
    //     0x6b1c50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b1c54: cmp             SP, x16
    //     0x6b1c58: b.ls            #0x6b1dec
    // 0x6b1c5c: ldr             x0, [fp, #0x10]
    // 0x6b1c60: r2 = Null
    //     0x6b1c60: mov             x2, NULL
    // 0x6b1c64: r1 = Null
    //     0x6b1c64: mov             x1, NULL
    // 0x6b1c68: r4 = 59
    //     0x6b1c68: mov             x4, #0x3b
    // 0x6b1c6c: branchIfSmi(r0, 0x6b1c78)
    //     0x6b1c6c: tbz             w0, #0, #0x6b1c78
    // 0x6b1c70: r4 = LoadClassIdInstr(r0)
    //     0x6b1c70: ldur            x4, [x0, #-1]
    //     0x6b1c74: ubfx            x4, x4, #0xc, #0x14
    // 0x6b1c78: cmp             x4, #0xdf1
    // 0x6b1c7c: b.eq            #0x6b1c94
    // 0x6b1c80: r8 = _CupertinoTextSelectionToolbarItems
    //     0x6b1c80: add             x8, PP, #0x50, lsl #12  ; [pp+0x50d38] Type: _CupertinoTextSelectionToolbarItems
    //     0x6b1c84: ldr             x8, [x8, #0xd38]
    // 0x6b1c88: r3 = Null
    //     0x6b1c88: add             x3, PP, #0x50, lsl #12  ; [pp+0x50d40] Null
    //     0x6b1c8c: ldr             x3, [x3, #0xd40]
    // 0x6b1c90: r0 = DefaultTypeTest()
    //     0x6b1c90: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6b1c94: ldr             x16, [fp, #0x18]
    // 0x6b1c98: ldr             lr, [fp, #0x10]
    // 0x6b1c9c: stp             lr, x16, [SP, #-0x10]!
    // 0x6b1ca0: r0 = update()
    //     0x6b1ca0: bl              #0x6b469c  ; [package:flutter/src/widgets/framework.dart] RenderObjectElement::update
    // 0x6b1ca4: add             SP, SP, #0x10
    // 0x6b1ca8: ldr             x3, [fp, #0x18]
    // 0x6b1cac: LoadField: r4 = r3->field_1b
    //     0x6b1cac: ldur            w4, [x3, #0x1b]
    // 0x6b1cb0: DecompressPointer r4
    //     0x6b1cb0: add             x4, x4, HEAP, lsl #32
    // 0x6b1cb4: stur            x4, [fp, #-8]
    // 0x6b1cb8: cmp             w4, NULL
    // 0x6b1cbc: b.eq            #0x6b1df4
    // 0x6b1cc0: mov             x0, x4
    // 0x6b1cc4: r2 = Null
    //     0x6b1cc4: mov             x2, NULL
    // 0x6b1cc8: r1 = Null
    //     0x6b1cc8: mov             x1, NULL
    // 0x6b1ccc: r4 = LoadClassIdInstr(r0)
    //     0x6b1ccc: ldur            x4, [x0, #-1]
    //     0x6b1cd0: ubfx            x4, x4, #0xc, #0x14
    // 0x6b1cd4: cmp             x4, #0xdf1
    // 0x6b1cd8: b.eq            #0x6b1cf0
    // 0x6b1cdc: r8 = _CupertinoTextSelectionToolbarItems
    //     0x6b1cdc: add             x8, PP, #0x50, lsl #12  ; [pp+0x50d38] Type: _CupertinoTextSelectionToolbarItems
    //     0x6b1ce0: ldr             x8, [x8, #0xd38]
    // 0x6b1ce4: r3 = Null
    //     0x6b1ce4: add             x3, PP, #0x50, lsl #12  ; [pp+0x50d50] Null
    //     0x6b1ce8: ldr             x3, [x3, #0xd50]
    // 0x6b1cec: r0 = DefaultTypeTest()
    //     0x6b1cec: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6b1cf0: ldur            x0, [fp, #-8]
    // 0x6b1cf4: LoadField: r1 = r0->field_b
    //     0x6b1cf4: ldur            w1, [x0, #0xb]
    // 0x6b1cf8: DecompressPointer r1
    //     0x6b1cf8: add             x1, x1, HEAP, lsl #32
    // 0x6b1cfc: ldr             x16, [fp, #0x18]
    // 0x6b1d00: stp             x1, x16, [SP, #-0x10]!
    // 0x6b1d04: r16 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x6b1d04: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d60] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65e31
    //     0x6b1d08: ldr             x16, [x16, #0xd60]
    // 0x6b1d0c: SaveReg r16
    //     0x6b1d0c: str             x16, [SP, #-8]!
    // 0x6b1d10: r0 = _mountChild()
    //     0x6b1d10: bl              #0x6b3314  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x6b1d14: add             SP, SP, #0x18
    // 0x6b1d18: ldur            x0, [fp, #-8]
    // 0x6b1d1c: LoadField: r1 = r0->field_1b
    //     0x6b1d1c: ldur            w1, [x0, #0x1b]
    // 0x6b1d20: DecompressPointer r1
    //     0x6b1d20: add             x1, x1, HEAP, lsl #32
    // 0x6b1d24: ldr             x16, [fp, #0x18]
    // 0x6b1d28: stp             x1, x16, [SP, #-0x10]!
    // 0x6b1d2c: r16 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x6b1d2c: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d68] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65e11
    //     0x6b1d30: ldr             x16, [x16, #0xd68]
    // 0x6b1d34: SaveReg r16
    //     0x6b1d34: str             x16, [SP, #-8]!
    // 0x6b1d38: r0 = _mountChild()
    //     0x6b1d38: bl              #0x6b3314  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x6b1d3c: add             SP, SP, #0x18
    // 0x6b1d40: ldur            x0, [fp, #-8]
    // 0x6b1d44: LoadField: r1 = r0->field_1f
    //     0x6b1d44: ldur            w1, [x0, #0x1f]
    // 0x6b1d48: DecompressPointer r1
    //     0x6b1d48: add             x1, x1, HEAP, lsl #32
    // 0x6b1d4c: ldr             x16, [fp, #0x18]
    // 0x6b1d50: stp             x1, x16, [SP, #-0x10]!
    // 0x6b1d54: r16 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x6b1d54: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d70] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65df1
    //     0x6b1d58: ldr             x16, [x16, #0xd70]
    // 0x6b1d5c: SaveReg r16
    //     0x6b1d5c: str             x16, [SP, #-8]!
    // 0x6b1d60: r0 = _mountChild()
    //     0x6b1d60: bl              #0x6b3314  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x6b1d64: add             SP, SP, #0x18
    // 0x6b1d68: ldr             x0, [fp, #0x18]
    // 0x6b1d6c: LoadField: r1 = r0->field_43
    //     0x6b1d6c: ldur            w1, [x0, #0x43]
    // 0x6b1d70: DecompressPointer r1
    //     0x6b1d70: add             x1, x1, HEAP, lsl #32
    // 0x6b1d74: r16 = Sentinel
    //     0x6b1d74: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6b1d78: cmp             w1, w16
    // 0x6b1d7c: b.eq            #0x6b1df8
    // 0x6b1d80: ldur            x2, [fp, #-8]
    // 0x6b1d84: LoadField: r3 = r2->field_f
    //     0x6b1d84: ldur            w3, [x2, #0xf]
    // 0x6b1d88: DecompressPointer r3
    //     0x6b1d88: add             x3, x3, HEAP, lsl #32
    // 0x6b1d8c: LoadField: r2 = r0->field_4b
    //     0x6b1d8c: ldur            w2, [x0, #0x4b]
    // 0x6b1d90: DecompressPointer r2
    //     0x6b1d90: add             x2, x2, HEAP, lsl #32
    // 0x6b1d94: stur            x2, [fp, #-8]
    // 0x6b1d98: stp             x1, x0, [SP, #-0x10]!
    // 0x6b1d9c: stp             x2, x3, [SP, #-0x10]!
    // 0x6b1da0: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x6b1da0: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x6b1da4: r0 = updateChildren()
    //     0x6b1da4: bl              #0x6b1e04  ; [package:flutter/src/widgets/framework.dart] RenderObjectElement::updateChildren
    // 0x6b1da8: add             SP, SP, #0x20
    // 0x6b1dac: ldr             x1, [fp, #0x18]
    // 0x6b1db0: StoreField: r1->field_43 = r0
    //     0x6b1db0: stur            w0, [x1, #0x43]
    //     0x6b1db4: ldurb           w16, [x1, #-1]
    //     0x6b1db8: ldurb           w17, [x0, #-1]
    //     0x6b1dbc: and             x16, x17, x16, lsr #2
    //     0x6b1dc0: tst             x16, HEAP, lsr #32
    //     0x6b1dc4: b.eq            #0x6b1dcc
    //     0x6b1dc8: bl              #0xd6826c
    // 0x6b1dcc: ldur            x16, [fp, #-8]
    // 0x6b1dd0: SaveReg r16
    //     0x6b1dd0: str             x16, [SP, #-8]!
    // 0x6b1dd4: r0 = clear()
    //     0x6b1dd4: bl              #0x592930  ; [dart:collection] _HashSet::clear
    // 0x6b1dd8: add             SP, SP, #8
    // 0x6b1ddc: r0 = Null
    //     0x6b1ddc: mov             x0, NULL
    // 0x6b1de0: LeaveFrame
    //     0x6b1de0: mov             SP, fp
    //     0x6b1de4: ldp             fp, lr, [SP], #0x10
    // 0x6b1de8: ret
    //     0x6b1de8: ret             
    // 0x6b1dec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b1dec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b1df0: b               #0x6b1c5c
    // 0x6b1df4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6b1df4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6b1df8: r9 = _children
    //     0x6b1df8: add             x9, PP, #0x50, lsl #12  ; [pp+0x50d78] Field <_CupertinoTextSelectionToolbarItemsElement@621408280._children@621408280>: late (offset: 0x44)
    //     0x6b1dfc: ldr             x9, [x9, #0xd78]
    // 0x6b1e00: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6b1e00: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ _mountChild(/* No info */) {
    // ** addr: 0x6b3314, size: 0x25c
    // 0x6b3314: EnterFrame
    //     0x6b3314: stp             fp, lr, [SP, #-0x10]!
    //     0x6b3318: mov             fp, SP
    // 0x6b331c: AllocStack(0x18)
    //     0x6b331c: sub             SP, SP, #0x18
    // 0x6b3320: CheckStackOverflow
    //     0x6b3320: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6b3324: cmp             SP, x16
    //     0x6b3328: b.ls            #0x6b3568
    // 0x6b332c: ldr             x0, [fp, #0x20]
    // 0x6b3330: LoadField: r1 = r0->field_47
    //     0x6b3330: ldur            w1, [x0, #0x47]
    // 0x6b3334: DecompressPointer r1
    //     0x6b3334: add             x1, x1, HEAP, lsl #32
    // 0x6b3338: stur            x1, [fp, #-8]
    // 0x6b333c: ldr             x16, [fp, #0x10]
    // 0x6b3340: stp             x16, x1, [SP, #-0x10]!
    // 0x6b3344: r0 = _getValueOrData()
    //     0x6b3344: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0x6b3348: add             SP, SP, #0x10
    // 0x6b334c: ldur            x1, [fp, #-8]
    // 0x6b3350: LoadField: r2 = r1->field_f
    //     0x6b3350: ldur            w2, [x1, #0xf]
    // 0x6b3354: DecompressPointer r2
    //     0x6b3354: add             x2, x2, HEAP, lsl #32
    // 0x6b3358: cmp             w2, w0
    // 0x6b335c: b.ne            #0x6b3368
    // 0x6b3360: r2 = Null
    //     0x6b3360: mov             x2, NULL
    // 0x6b3364: b               #0x6b336c
    // 0x6b3368: mov             x2, x0
    // 0x6b336c: stur            x2, [fp, #-0x10]
    // 0x6b3370: cmp             w2, NULL
    // 0x6b3374: b.eq            #0x6b34f8
    // 0x6b3378: ldr             x3, [fp, #0x18]
    // 0x6b337c: r0 = LoadClassIdInstr(r2)
    //     0x6b337c: ldur            x0, [x2, #-1]
    //     0x6b3380: ubfx            x0, x0, #0xc, #0x14
    // 0x6b3384: SaveReg r2
    //     0x6b3384: str             x2, [SP, #-8]!
    // 0x6b3388: r0 = GDT[cid_x0 + -0xf65]()
    //     0x6b3388: sub             lr, x0, #0xf65
    //     0x6b338c: ldr             lr, [x21, lr, lsl #3]
    //     0x6b3390: blr             lr
    // 0x6b3394: add             SP, SP, #8
    // 0x6b3398: ldr             x1, [fp, #0x18]
    // 0x6b339c: cmp             w0, w1
    // 0x6b33a0: b.ne            #0x6b3404
    // 0x6b33a4: ldur            x1, [fp, #-0x10]
    // 0x6b33a8: LoadField: r0 = r1->field_13
    //     0x6b33a8: ldur            w0, [x1, #0x13]
    // 0x6b33ac: DecompressPointer r0
    //     0x6b33ac: add             x0, x0, HEAP, lsl #32
    // 0x6b33b0: r2 = 59
    //     0x6b33b0: mov             x2, #0x3b
    // 0x6b33b4: branchIfSmi(r0, 0x6b33c0)
    //     0x6b33b4: tbz             w0, #0, #0x6b33c0
    // 0x6b33b8: r2 = LoadClassIdInstr(r0)
    //     0x6b33b8: ldur            x2, [x0, #-1]
    //     0x6b33bc: ubfx            x2, x2, #0xc, #0x14
    // 0x6b33c0: ldr             x16, [fp, #0x10]
    // 0x6b33c4: stp             x16, x0, [SP, #-0x10]!
    // 0x6b33c8: mov             x0, x2
    // 0x6b33cc: mov             lr, x0
    // 0x6b33d0: ldr             lr, [x21, lr, lsl #3]
    // 0x6b33d4: blr             lr
    // 0x6b33d8: add             SP, SP, #0x10
    // 0x6b33dc: tbz             w0, #4, #0x6b33fc
    // 0x6b33e0: ldr             x16, [fp, #0x20]
    // 0x6b33e4: ldur            lr, [fp, #-0x10]
    // 0x6b33e8: stp             lr, x16, [SP, #-0x10]!
    // 0x6b33ec: ldr             x16, [fp, #0x10]
    // 0x6b33f0: SaveReg r16
    //     0x6b33f0: str             x16, [SP, #-8]!
    // 0x6b33f4: r0 = updateSlotForChild()
    //     0x6b33f4: bl              #0x6ac8a8  ; [package:flutter/src/widgets/framework.dart] Element::updateSlotForChild
    // 0x6b33f8: add             SP, SP, #0x18
    // 0x6b33fc: ldur            x0, [fp, #-0x10]
    // 0x6b3400: b               #0x6b34f0
    // 0x6b3404: ldur            x2, [fp, #-0x10]
    // 0x6b3408: r0 = LoadClassIdInstr(r2)
    //     0x6b3408: ldur            x0, [x2, #-1]
    //     0x6b340c: ubfx            x0, x0, #0xc, #0x14
    // 0x6b3410: SaveReg r2
    //     0x6b3410: str             x2, [SP, #-8]!
    // 0x6b3414: r0 = GDT[cid_x0 + -0xf65]()
    //     0x6b3414: sub             lr, x0, #0xf65
    //     0x6b3418: ldr             lr, [x21, lr, lsl #3]
    //     0x6b341c: blr             lr
    // 0x6b3420: add             SP, SP, #8
    // 0x6b3424: ldr             x16, [fp, #0x18]
    // 0x6b3428: stp             x16, x0, [SP, #-0x10]!
    // 0x6b342c: r0 = canUpdate()
    //     0x6b342c: bl              #0x6ac6b4  ; [package:flutter/src/widgets/framework.dart] Widget::canUpdate
    // 0x6b3430: add             SP, SP, #0x10
    // 0x6b3434: tbnz            w0, #4, #0x6b34c0
    // 0x6b3438: ldur            x1, [fp, #-0x10]
    // 0x6b343c: LoadField: r0 = r1->field_13
    //     0x6b343c: ldur            w0, [x1, #0x13]
    // 0x6b3440: DecompressPointer r0
    //     0x6b3440: add             x0, x0, HEAP, lsl #32
    // 0x6b3444: r2 = 59
    //     0x6b3444: mov             x2, #0x3b
    // 0x6b3448: branchIfSmi(r0, 0x6b3454)
    //     0x6b3448: tbz             w0, #0, #0x6b3454
    // 0x6b344c: r2 = LoadClassIdInstr(r0)
    //     0x6b344c: ldur            x2, [x0, #-1]
    //     0x6b3450: ubfx            x2, x2, #0xc, #0x14
    // 0x6b3454: ldr             x16, [fp, #0x10]
    // 0x6b3458: stp             x16, x0, [SP, #-0x10]!
    // 0x6b345c: mov             x0, x2
    // 0x6b3460: mov             lr, x0
    // 0x6b3464: ldr             lr, [x21, lr, lsl #3]
    // 0x6b3468: blr             lr
    // 0x6b346c: add             SP, SP, #0x10
    // 0x6b3470: tbz             w0, #4, #0x6b3490
    // 0x6b3474: ldr             x16, [fp, #0x20]
    // 0x6b3478: ldur            lr, [fp, #-0x10]
    // 0x6b347c: stp             lr, x16, [SP, #-0x10]!
    // 0x6b3480: ldr             x16, [fp, #0x10]
    // 0x6b3484: SaveReg r16
    //     0x6b3484: str             x16, [SP, #-8]!
    // 0x6b3488: r0 = updateSlotForChild()
    //     0x6b3488: bl              #0x6ac8a8  ; [package:flutter/src/widgets/framework.dart] Element::updateSlotForChild
    // 0x6b348c: add             SP, SP, #0x18
    // 0x6b3490: ldur            x1, [fp, #-0x10]
    // 0x6b3494: r0 = LoadClassIdInstr(r1)
    //     0x6b3494: ldur            x0, [x1, #-1]
    //     0x6b3498: ubfx            x0, x0, #0xc, #0x14
    // 0x6b349c: ldr             x16, [fp, #0x18]
    // 0x6b34a0: stp             x16, x1, [SP, #-0x10]!
    // 0x6b34a4: r0 = GDT[cid_x0 + 0xd60f]()
    //     0x6b34a4: mov             x17, #0xd60f
    //     0x6b34a8: add             lr, x0, x17
    //     0x6b34ac: ldr             lr, [x21, lr, lsl #3]
    //     0x6b34b0: blr             lr
    // 0x6b34b4: add             SP, SP, #0x10
    // 0x6b34b8: ldur            x0, [fp, #-0x10]
    // 0x6b34bc: b               #0x6b34f0
    // 0x6b34c0: ldr             x16, [fp, #0x20]
    // 0x6b34c4: ldur            lr, [fp, #-0x10]
    // 0x6b34c8: stp             lr, x16, [SP, #-0x10]!
    // 0x6b34cc: r0 = deactivateChild()
    //     0x6b34cc: bl              #0x6ac9e4  ; [package:flutter/src/widgets/framework.dart] Element::deactivateChild
    // 0x6b34d0: add             SP, SP, #0x10
    // 0x6b34d4: ldr             x16, [fp, #0x20]
    // 0x6b34d8: ldr             lr, [fp, #0x18]
    // 0x6b34dc: stp             lr, x16, [SP, #-0x10]!
    // 0x6b34e0: ldr             x16, [fp, #0x10]
    // 0x6b34e4: SaveReg r16
    //     0x6b34e4: str             x16, [SP, #-8]!
    // 0x6b34e8: r0 = inflateWidget()
    //     0x6b34e8: bl              #0x9d5128  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0x6b34ec: add             SP, SP, #0x18
    // 0x6b34f0: mov             x1, x0
    // 0x6b34f4: b               #0x6b3518
    // 0x6b34f8: ldr             x16, [fp, #0x20]
    // 0x6b34fc: ldr             lr, [fp, #0x18]
    // 0x6b3500: stp             lr, x16, [SP, #-0x10]!
    // 0x6b3504: ldr             x16, [fp, #0x10]
    // 0x6b3508: SaveReg r16
    //     0x6b3508: str             x16, [SP, #-8]!
    // 0x6b350c: r0 = inflateWidget()
    //     0x6b350c: bl              #0x9d5128  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0x6b3510: add             SP, SP, #0x18
    // 0x6b3514: mov             x1, x0
    // 0x6b3518: ldur            x0, [fp, #-0x10]
    // 0x6b351c: stur            x1, [fp, #-0x18]
    // 0x6b3520: cmp             w0, NULL
    // 0x6b3524: b.eq            #0x6b353c
    // 0x6b3528: ldur            x16, [fp, #-8]
    // 0x6b352c: ldr             lr, [fp, #0x10]
    // 0x6b3530: stp             lr, x16, [SP, #-0x10]!
    // 0x6b3534: r0 = remove()
    //     0x6b3534: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6b3538: add             SP, SP, #0x10
    // 0x6b353c: ldur            x16, [fp, #-8]
    // 0x6b3540: ldr             lr, [fp, #0x10]
    // 0x6b3544: stp             lr, x16, [SP, #-0x10]!
    // 0x6b3548: ldur            x16, [fp, #-0x18]
    // 0x6b354c: SaveReg r16
    //     0x6b354c: str             x16, [SP, #-8]!
    // 0x6b3550: r0 = []=()
    //     0x6b3550: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x6b3554: add             SP, SP, #0x18
    // 0x6b3558: r0 = Null
    //     0x6b3558: mov             x0, NULL
    // 0x6b355c: LeaveFrame
    //     0x6b355c: mov             SP, fp
    //     0x6b3560: ldp             fp, lr, [SP], #0x10
    // 0x6b3564: ret
    //     0x6b3564: ret             
    // 0x6b3568: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6b3568: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6b356c: b               #0x6b332c
  }
  _ mount(/* No info */) {
    // ** addr: 0x6bd46c, size: 0x30c
    // 0x6bd46c: EnterFrame
    //     0x6bd46c: stp             fp, lr, [SP, #-0x10]!
    //     0x6bd470: mov             fp, SP
    // 0x6bd474: AllocStack(0x20)
    //     0x6bd474: sub             SP, SP, #0x20
    // 0x6bd478: CheckStackOverflow
    //     0x6bd478: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bd47c: cmp             SP, x16
    //     0x6bd480: b.ls            #0x6bd754
    // 0x6bd484: ldr             x16, [fp, #0x20]
    // 0x6bd488: ldr             lr, [fp, #0x18]
    // 0x6bd48c: stp             lr, x16, [SP, #-0x10]!
    // 0x6bd490: ldr             x16, [fp, #0x10]
    // 0x6bd494: SaveReg r16
    //     0x6bd494: str             x16, [SP, #-8]!
    // 0x6bd498: r0 = mount()
    //     0x6bd498: bl              #0x6bdeb0  ; [package:flutter/src/widgets/framework.dart] RenderObjectElement::mount
    // 0x6bd49c: add             SP, SP, #0x18
    // 0x6bd4a0: ldr             x3, [fp, #0x20]
    // 0x6bd4a4: LoadField: r4 = r3->field_1b
    //     0x6bd4a4: ldur            w4, [x3, #0x1b]
    // 0x6bd4a8: DecompressPointer r4
    //     0x6bd4a8: add             x4, x4, HEAP, lsl #32
    // 0x6bd4ac: stur            x4, [fp, #-8]
    // 0x6bd4b0: cmp             w4, NULL
    // 0x6bd4b4: b.eq            #0x6bd75c
    // 0x6bd4b8: mov             x0, x4
    // 0x6bd4bc: r2 = Null
    //     0x6bd4bc: mov             x2, NULL
    // 0x6bd4c0: r1 = Null
    //     0x6bd4c0: mov             x1, NULL
    // 0x6bd4c4: r4 = LoadClassIdInstr(r0)
    //     0x6bd4c4: ldur            x4, [x0, #-1]
    //     0x6bd4c8: ubfx            x4, x4, #0xc, #0x14
    // 0x6bd4cc: cmp             x4, #0xdf1
    // 0x6bd4d0: b.eq            #0x6bd4e8
    // 0x6bd4d4: r8 = _CupertinoTextSelectionToolbarItems
    //     0x6bd4d4: add             x8, PP, #0x50, lsl #12  ; [pp+0x50d38] Type: _CupertinoTextSelectionToolbarItems
    //     0x6bd4d8: ldr             x8, [x8, #0xd38]
    // 0x6bd4dc: r3 = Null
    //     0x6bd4dc: add             x3, PP, #0x50, lsl #12  ; [pp+0x50d80] Null
    //     0x6bd4e0: ldr             x3, [x3, #0xd80]
    // 0x6bd4e4: r0 = DefaultTypeTest()
    //     0x6bd4e4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6bd4e8: ldur            x0, [fp, #-8]
    // 0x6bd4ec: LoadField: r1 = r0->field_b
    //     0x6bd4ec: ldur            w1, [x0, #0xb]
    // 0x6bd4f0: DecompressPointer r1
    //     0x6bd4f0: add             x1, x1, HEAP, lsl #32
    // 0x6bd4f4: ldr             x16, [fp, #0x20]
    // 0x6bd4f8: stp             x1, x16, [SP, #-0x10]!
    // 0x6bd4fc: r16 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x6bd4fc: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d60] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65e31
    //     0x6bd500: ldr             x16, [x16, #0xd60]
    // 0x6bd504: SaveReg r16
    //     0x6bd504: str             x16, [SP, #-8]!
    // 0x6bd508: r0 = _mountChild()
    //     0x6bd508: bl              #0x6b3314  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x6bd50c: add             SP, SP, #0x18
    // 0x6bd510: ldur            x0, [fp, #-8]
    // 0x6bd514: LoadField: r1 = r0->field_1b
    //     0x6bd514: ldur            w1, [x0, #0x1b]
    // 0x6bd518: DecompressPointer r1
    //     0x6bd518: add             x1, x1, HEAP, lsl #32
    // 0x6bd51c: ldr             x16, [fp, #0x20]
    // 0x6bd520: stp             x1, x16, [SP, #-0x10]!
    // 0x6bd524: r16 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x6bd524: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d68] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65e11
    //     0x6bd528: ldr             x16, [x16, #0xd68]
    // 0x6bd52c: SaveReg r16
    //     0x6bd52c: str             x16, [SP, #-8]!
    // 0x6bd530: r0 = _mountChild()
    //     0x6bd530: bl              #0x6b3314  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x6bd534: add             SP, SP, #0x18
    // 0x6bd538: ldur            x0, [fp, #-8]
    // 0x6bd53c: LoadField: r1 = r0->field_1f
    //     0x6bd53c: ldur            w1, [x0, #0x1f]
    // 0x6bd540: DecompressPointer r1
    //     0x6bd540: add             x1, x1, HEAP, lsl #32
    // 0x6bd544: ldr             x16, [fp, #0x20]
    // 0x6bd548: stp             x1, x16, [SP, #-0x10]!
    // 0x6bd54c: r16 = Instance__CupertinoTextSelectionToolbarItemsSlot
    //     0x6bd54c: add             x16, PP, #0x50, lsl #12  ; [pp+0x50d70] Obj!_CupertinoTextSelectionToolbarItemsSlot@b65df1
    //     0x6bd550: ldr             x16, [x16, #0xd70]
    // 0x6bd554: SaveReg r16
    //     0x6bd554: str             x16, [SP, #-8]!
    // 0x6bd558: r0 = _mountChild()
    //     0x6bd558: bl              #0x6b3314  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_mountChild
    // 0x6bd55c: add             SP, SP, #0x18
    // 0x6bd560: ldur            x0, [fp, #-8]
    // 0x6bd564: LoadField: r1 = r0->field_f
    //     0x6bd564: ldur            w1, [x0, #0xf]
    // 0x6bd568: DecompressPointer r1
    //     0x6bd568: add             x1, x1, HEAP, lsl #32
    // 0x6bd56c: stur            x1, [fp, #-0x10]
    // 0x6bd570: LoadField: r2 = r1->field_b
    //     0x6bd570: ldur            w2, [x1, #0xb]
    // 0x6bd574: DecompressPointer r2
    //     0x6bd574: add             x2, x2, HEAP, lsl #32
    // 0x6bd578: stur            x2, [fp, #-8]
    // 0x6bd57c: r0 = InitLateStaticField(0xcf0) // [package:flutter/src/cupertino/text_selection_toolbar.dart] _NullElement::instance
    //     0x6bd57c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6bd580: ldr             x0, [x0, #0x19e0]
    //     0x6bd584: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6bd588: cmp             w0, w16
    //     0x6bd58c: b.ne            #0x6bd59c
    //     0x6bd590: add             x2, PP, #0x50, lsl #12  ; [pp+0x50d90] Field <_NullElement@621408280.instance>: static late (offset: 0xcf0)
    //     0x6bd594: ldr             x2, [x2, #0xd90]
    //     0x6bd598: bl              #0xd67d44
    // 0x6bd59c: ldur            x2, [fp, #-8]
    // 0x6bd5a0: r1 = <Element>
    //     0x6bd5a0: ldr             x1, [PP, #0x3d40]  ; [pp+0x3d40] TypeArguments: <Element>
    // 0x6bd5a4: stur            x0, [fp, #-0x18]
    // 0x6bd5a8: r0 = AllocateArray()
    //     0x6bd5a8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x6bd5ac: mov             x2, x0
    // 0x6bd5b0: ldur            x0, [fp, #-8]
    // 0x6bd5b4: r3 = LoadInt32Instr(r0)
    //     0x6bd5b4: sbfx            x3, x0, #1, #0x1f
    // 0x6bd5b8: r4 = 0
    //     0x6bd5b8: mov             x4, #0
    // 0x6bd5bc: CheckStackOverflow
    //     0x6bd5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bd5c0: cmp             SP, x16
    //     0x6bd5c4: b.ls            #0x6bd760
    // 0x6bd5c8: cmp             x4, x3
    // 0x6bd5cc: b.ge            #0x6bd60c
    // 0x6bd5d0: mov             x1, x2
    // 0x6bd5d4: ldur            x0, [fp, #-0x18]
    // 0x6bd5d8: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6bd5d8: add             x25, x1, x4, lsl #2
    //     0x6bd5dc: add             x25, x25, #0xf
    //     0x6bd5e0: str             w0, [x25]
    //     0x6bd5e4: tbz             w0, #0, #0x6bd600
    //     0x6bd5e8: ldurb           w16, [x1, #-1]
    //     0x6bd5ec: ldurb           w17, [x0, #-1]
    //     0x6bd5f0: and             x16, x17, x16, lsr #2
    //     0x6bd5f4: tst             x16, HEAP, lsr #32
    //     0x6bd5f8: b.eq            #0x6bd600
    //     0x6bd5fc: bl              #0xd67e5c
    // 0x6bd600: add             x0, x4, #1
    // 0x6bd604: mov             x4, x0
    // 0x6bd608: b               #0x6bd5bc
    // 0x6bd60c: ldr             x3, [fp, #0x20]
    // 0x6bd610: mov             x0, x2
    // 0x6bd614: StoreField: r3->field_43 = r0
    //     0x6bd614: stur            w0, [x3, #0x43]
    //     0x6bd618: ldurb           w16, [x3, #-1]
    //     0x6bd61c: ldurb           w17, [x0, #-1]
    //     0x6bd620: and             x16, x17, x16, lsr #2
    //     0x6bd624: tst             x16, HEAP, lsr #32
    //     0x6bd628: b.eq            #0x6bd630
    //     0x6bd62c: bl              #0xd682ac
    // 0x6bd630: mov             x0, x2
    // 0x6bd634: r5 = Null
    //     0x6bd634: mov             x5, NULL
    // 0x6bd638: r4 = 0
    //     0x6bd638: mov             x4, #0
    // 0x6bd63c: ldur            x2, [fp, #-0x10]
    // 0x6bd640: stur            x5, [fp, #-0x18]
    // 0x6bd644: stur            x4, [fp, #-0x20]
    // 0x6bd648: CheckStackOverflow
    //     0x6bd648: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6bd64c: cmp             SP, x16
    //     0x6bd650: b.ls            #0x6bd768
    // 0x6bd654: LoadField: r1 = r0->field_b
    //     0x6bd654: ldur            w1, [x0, #0xb]
    // 0x6bd658: DecompressPointer r1
    //     0x6bd658: add             x1, x1, HEAP, lsl #32
    // 0x6bd65c: r0 = LoadInt32Instr(r1)
    //     0x6bd65c: sbfx            x0, x1, #1, #0x1f
    // 0x6bd660: cmp             x4, x0
    // 0x6bd664: b.ge            #0x6bd744
    // 0x6bd668: LoadField: r0 = r2->field_b
    //     0x6bd668: ldur            w0, [x2, #0xb]
    // 0x6bd66c: DecompressPointer r0
    //     0x6bd66c: add             x0, x0, HEAP, lsl #32
    // 0x6bd670: r1 = LoadInt32Instr(r0)
    //     0x6bd670: sbfx            x1, x0, #1, #0x1f
    // 0x6bd674: mov             x0, x1
    // 0x6bd678: mov             x1, x4
    // 0x6bd67c: cmp             x1, x0
    // 0x6bd680: b.hs            #0x6bd770
    // 0x6bd684: LoadField: r0 = r2->field_f
    //     0x6bd684: ldur            w0, [x2, #0xf]
    // 0x6bd688: DecompressPointer r0
    //     0x6bd688: add             x0, x0, HEAP, lsl #32
    // 0x6bd68c: ArrayLoad: r6 = r0[r4]  ; Unknown_4
    //     0x6bd68c: add             x16, x0, x4, lsl #2
    //     0x6bd690: ldur            w6, [x16, #0xf]
    // 0x6bd694: DecompressPointer r6
    //     0x6bd694: add             x6, x6, HEAP, lsl #32
    // 0x6bd698: stur            x6, [fp, #-8]
    // 0x6bd69c: r1 = <Element?>
    //     0x6bd69c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d838] TypeArguments: <Element?>
    //     0x6bd6a0: ldr             x1, [x1, #0x838]
    // 0x6bd6a4: r0 = IndexedSlot()
    //     0x6bd6a4: bl              #0x6b32b4  ; AllocateIndexedSlotStub -> IndexedSlot<X0 bound Element?> (size=0x18)
    // 0x6bd6a8: ldur            x1, [fp, #-0x20]
    // 0x6bd6ac: StoreField: r0->field_f = r1
    //     0x6bd6ac: stur            x1, [x0, #0xf]
    // 0x6bd6b0: ldur            x2, [fp, #-0x18]
    // 0x6bd6b4: StoreField: r0->field_b = r2
    //     0x6bd6b4: stur            w2, [x0, #0xb]
    // 0x6bd6b8: ldr             x16, [fp, #0x20]
    // 0x6bd6bc: ldur            lr, [fp, #-8]
    // 0x6bd6c0: stp             lr, x16, [SP, #-0x10]!
    // 0x6bd6c4: SaveReg r0
    //     0x6bd6c4: str             x0, [SP, #-8]!
    // 0x6bd6c8: r0 = inflateWidget()
    //     0x6bd6c8: bl              #0x9d5128  ; [package:flutter/src/widgets/framework.dart] Element::inflateWidget
    // 0x6bd6cc: add             SP, SP, #0x18
    // 0x6bd6d0: mov             x3, x0
    // 0x6bd6d4: ldr             x2, [fp, #0x20]
    // 0x6bd6d8: LoadField: r6 = r2->field_43
    //     0x6bd6d8: ldur            w6, [x2, #0x43]
    // 0x6bd6dc: DecompressPointer r6
    //     0x6bd6dc: add             x6, x6, HEAP, lsl #32
    // 0x6bd6e0: LoadField: r4 = r6->field_b
    //     0x6bd6e0: ldur            w4, [x6, #0xb]
    // 0x6bd6e4: DecompressPointer r4
    //     0x6bd6e4: add             x4, x4, HEAP, lsl #32
    // 0x6bd6e8: r0 = LoadInt32Instr(r4)
    //     0x6bd6e8: sbfx            x0, x4, #1, #0x1f
    // 0x6bd6ec: ldur            x1, [fp, #-0x20]
    // 0x6bd6f0: cmp             x1, x0
    // 0x6bd6f4: b.hs            #0x6bd774
    // 0x6bd6f8: mov             x1, x6
    // 0x6bd6fc: mov             x0, x3
    // 0x6bd700: ldur            x4, [fp, #-0x20]
    // 0x6bd704: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6bd704: add             x25, x1, x4, lsl #2
    //     0x6bd708: add             x25, x25, #0xf
    //     0x6bd70c: str             w0, [x25]
    //     0x6bd710: tbz             w0, #0, #0x6bd72c
    //     0x6bd714: ldurb           w16, [x1, #-1]
    //     0x6bd718: ldurb           w17, [x0, #-1]
    //     0x6bd71c: and             x16, x17, x16, lsr #2
    //     0x6bd720: tst             x16, HEAP, lsr #32
    //     0x6bd724: b.eq            #0x6bd72c
    //     0x6bd728: bl              #0xd67e5c
    // 0x6bd72c: add             x1, x4, #1
    // 0x6bd730: mov             x5, x3
    // 0x6bd734: mov             x4, x1
    // 0x6bd738: mov             x0, x6
    // 0x6bd73c: mov             x3, x2
    // 0x6bd740: b               #0x6bd63c
    // 0x6bd744: r0 = Null
    //     0x6bd744: mov             x0, NULL
    // 0x6bd748: LeaveFrame
    //     0x6bd748: mov             SP, fp
    //     0x6bd74c: ldp             fp, lr, [SP], #0x10
    // 0x6bd750: ret
    //     0x6bd750: ret             
    // 0x6bd754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bd754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bd758: b               #0x6bd484
    // 0x6bd75c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6bd75c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x6bd760: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bd760: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bd764: b               #0x6bd5c8
    // 0x6bd768: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6bd768: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6bd76c: b               #0x6bd654
    // 0x6bd770: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6bd770: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x6bd774: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6bd774: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ forgetChild(/* No info */) {
    // ** addr: 0x6fef7c, size: 0xe8
    // 0x6fef7c: EnterFrame
    //     0x6fef7c: stp             fp, lr, [SP, #-0x10]!
    //     0x6fef80: mov             fp, SP
    // 0x6fef84: AllocStack(0x10)
    //     0x6fef84: sub             SP, SP, #0x10
    // 0x6fef88: CheckStackOverflow
    //     0x6fef88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6fef8c: cmp             SP, x16
    //     0x6fef90: b.ls            #0x6ff058
    // 0x6fef94: ldr             x0, [fp, #0x18]
    // 0x6fef98: LoadField: r1 = r0->field_47
    //     0x6fef98: ldur            w1, [x0, #0x47]
    // 0x6fef9c: DecompressPointer r1
    //     0x6fef9c: add             x1, x1, HEAP, lsl #32
    // 0x6fefa0: ldr             x2, [fp, #0x10]
    // 0x6fefa4: stur            x1, [fp, #-8]
    // 0x6fefa8: LoadField: r3 = r2->field_13
    //     0x6fefa8: ldur            w3, [x2, #0x13]
    // 0x6fefac: DecompressPointer r3
    //     0x6fefac: add             x3, x3, HEAP, lsl #32
    // 0x6fefb0: stp             x3, x1, [SP, #-0x10]!
    // 0x6fefb4: r0 = containsKey()
    //     0x6fefb4: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0x6fefb8: add             SP, SP, #0x10
    // 0x6fefbc: tbnz            w0, #4, #0x6ff02c
    // 0x6fefc0: ldr             x0, [fp, #0x10]
    // 0x6fefc4: LoadField: r3 = r0->field_13
    //     0x6fefc4: ldur            w3, [x0, #0x13]
    // 0x6fefc8: DecompressPointer r3
    //     0x6fefc8: add             x3, x3, HEAP, lsl #32
    // 0x6fefcc: stur            x3, [fp, #-0x10]
    // 0x6fefd0: cmp             w3, NULL
    // 0x6fefd4: b.eq            #0x6ff060
    // 0x6fefd8: mov             x0, x3
    // 0x6fefdc: r2 = Null
    //     0x6fefdc: mov             x2, NULL
    // 0x6fefe0: r1 = Null
    //     0x6fefe0: mov             x1, NULL
    // 0x6fefe4: r4 = 59
    //     0x6fefe4: mov             x4, #0x3b
    // 0x6fefe8: branchIfSmi(r0, 0x6feff4)
    //     0x6fefe8: tbz             w0, #0, #0x6feff4
    // 0x6fefec: r4 = LoadClassIdInstr(r0)
    //     0x6fefec: ldur            x4, [x0, #-1]
    //     0x6feff0: ubfx            x4, x4, #0xc, #0x14
    // 0x6feff4: r17 = 5986
    //     0x6feff4: mov             x17, #0x1762
    // 0x6feff8: cmp             x4, x17
    // 0x6feffc: b.eq            #0x6ff014
    // 0x6ff000: r8 = _CupertinoTextSelectionToolbarItemsSlot
    //     0x6ff000: add             x8, PP, #0x50, lsl #12  ; [pp+0x50da0] Type: _CupertinoTextSelectionToolbarItemsSlot
    //     0x6ff004: ldr             x8, [x8, #0xda0]
    // 0x6ff008: r3 = Null
    //     0x6ff008: add             x3, PP, #0x50, lsl #12  ; [pp+0x50da8] Null
    //     0x6ff00c: ldr             x3, [x3, #0xda8]
    // 0x6ff010: r0 = _CupertinoTextSelectionToolbarItemsSlot()
    //     0x6ff010: bl              #0x6b3618  ; IsType__CupertinoTextSelectionToolbarItemsSlot_Stub
    // 0x6ff014: ldur            x16, [fp, #-8]
    // 0x6ff018: ldur            lr, [fp, #-0x10]
    // 0x6ff01c: stp             lr, x16, [SP, #-0x10]!
    // 0x6ff020: r0 = remove()
    //     0x6ff020: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0x6ff024: add             SP, SP, #0x10
    // 0x6ff028: b               #0x6ff048
    // 0x6ff02c: ldr             x1, [fp, #0x18]
    // 0x6ff030: ldr             x0, [fp, #0x10]
    // 0x6ff034: LoadField: r2 = r1->field_4b
    //     0x6ff034: ldur            w2, [x1, #0x4b]
    // 0x6ff038: DecompressPointer r2
    //     0x6ff038: add             x2, x2, HEAP, lsl #32
    // 0x6ff03c: stp             x0, x2, [SP, #-0x10]!
    // 0x6ff040: r0 = add()
    //     0x6ff040: bl              #0xc4af80  ; [dart:collection] _HashSet::add
    // 0x6ff044: add             SP, SP, #0x10
    // 0x6ff048: r0 = Null
    //     0x6ff048: mov             x0, NULL
    // 0x6ff04c: LeaveFrame
    //     0x6ff04c: mov             SP, fp
    //     0x6ff050: ldp             fp, lr, [SP], #0x10
    // 0x6ff054: ret
    //     0x6ff054: ret             
    // 0x6ff058: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ff058: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ff05c: b               #0x6fef94
    // 0x6ff060: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6ff060: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ removeRenderObjectChild(/* No info */) {
    // ** addr: 0x711aec, size: 0xd8
    // 0x711aec: EnterFrame
    //     0x711aec: stp             fp, lr, [SP, #-0x10]!
    //     0x711af0: mov             fp, SP
    // 0x711af4: AllocStack(0x8)
    //     0x711af4: sub             SP, SP, #8
    // 0x711af8: CheckStackOverflow
    //     0x711af8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711afc: cmp             SP, x16
    //     0x711b00: b.ls            #0x711bbc
    // 0x711b04: ldr             x0, [fp, #0x10]
    // 0x711b08: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0x711b08: mov             x1, #0x76
    //     0x711b0c: tbz             w0, #0, #0x711b1c
    //     0x711b10: ldur            x1, [x0, #-1]
    //     0x711b14: ubfx            x1, x1, #0xc, #0x14
    //     0x711b18: lsl             x1, x1, #1
    // 0x711b1c: r17 = 11972
    //     0x711b1c: mov             x17, #0x2ec4
    // 0x711b20: cmp             w1, w17
    // 0x711b24: b.ne            #0x711b4c
    // 0x711b28: ldr             x16, [fp, #0x20]
    // 0x711b2c: stp             NULL, x16, [SP, #-0x10]!
    // 0x711b30: SaveReg r0
    //     0x711b30: str             x0, [SP, #-8]!
    // 0x711b34: r0 = _updateRenderObject()
    //     0x711b34: bl              #0x711bc4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_updateRenderObject
    // 0x711b38: add             SP, SP, #0x18
    // 0x711b3c: r0 = Null
    //     0x711b3c: mov             x0, NULL
    // 0x711b40: LeaveFrame
    //     0x711b40: mov             SP, fp
    //     0x711b44: ldp             fp, lr, [SP], #0x10
    // 0x711b48: ret
    //     0x711b48: ret             
    // 0x711b4c: ldr             x16, [fp, #0x20]
    // 0x711b50: SaveReg r16
    //     0x711b50: str             x16, [SP, #-8]!
    // 0x711b54: r0 = renderObject()
    //     0x711b54: bl              #0xcdcdec  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::renderObject
    // 0x711b58: add             SP, SP, #8
    // 0x711b5c: mov             x3, x0
    // 0x711b60: ldr             x0, [fp, #0x18]
    // 0x711b64: r2 = Null
    //     0x711b64: mov             x2, NULL
    // 0x711b68: r1 = Null
    //     0x711b68: mov             x1, NULL
    // 0x711b6c: stur            x3, [fp, #-8]
    // 0x711b70: r4 = LoadClassIdInstr(r0)
    //     0x711b70: ldur            x4, [x0, #-1]
    //     0x711b74: ubfx            x4, x4, #0xc, #0x14
    // 0x711b78: sub             x4, x4, #0x965
    // 0x711b7c: cmp             x4, #0x8b
    // 0x711b80: b.ls            #0x711b98
    // 0x711b84: r8 = RenderBox
    //     0x711b84: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x711b88: ldr             x8, [x8, #0xfa0]
    // 0x711b8c: r3 = Null
    //     0x711b8c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50dc8] Null
    //     0x711b90: ldr             x3, [x3, #0xdc8]
    // 0x711b94: r0 = RenderBox()
    //     0x711b94: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x711b98: ldur            x16, [fp, #-8]
    // 0x711b9c: ldr             lr, [fp, #0x18]
    // 0x711ba0: stp             lr, x16, [SP, #-0x10]!
    // 0x711ba4: r0 = remove()
    //     0x711ba4: bl              #0x5e9954  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::remove
    // 0x711ba8: add             SP, SP, #0x10
    // 0x711bac: r0 = Null
    //     0x711bac: mov             x0, NULL
    // 0x711bb0: LeaveFrame
    //     0x711bb0: mov             SP, fp
    //     0x711bb4: ldp             fp, lr, [SP], #0x10
    // 0x711bb8: ret
    //     0x711bb8: ret             
    // 0x711bbc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711bbc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711bc0: b               #0x711b04
  }
  _ _updateRenderObject(/* No info */) {
    // ** addr: 0x711bc4, size: 0x170
    // 0x711bc4: EnterFrame
    //     0x711bc4: stp             fp, lr, [SP, #-0x10]!
    //     0x711bc8: mov             fp, SP
    // 0x711bcc: AllocStack(0x8)
    //     0x711bcc: sub             SP, SP, #8
    // 0x711bd0: CheckStackOverflow
    //     0x711bd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x711bd4: cmp             SP, x16
    //     0x711bd8: b.ls            #0x711d20
    // 0x711bdc: ldr             x0, [fp, #0x10]
    // 0x711be0: LoadField: r1 = r0->field_7
    //     0x711be0: ldur            x1, [x0, #7]
    // 0x711be4: cmp             x1, #1
    // 0x711be8: b.gt            #0x711cb4
    // 0x711bec: cmp             x1, #0
    // 0x711bf0: b.gt            #0x711c54
    // 0x711bf4: ldr             x0, [fp, #0x20]
    // 0x711bf8: LoadField: r3 = r0->field_3b
    //     0x711bf8: ldur            w3, [x0, #0x3b]
    // 0x711bfc: DecompressPointer r3
    //     0x711bfc: add             x3, x3, HEAP, lsl #32
    // 0x711c00: stur            x3, [fp, #-8]
    // 0x711c04: cmp             w3, NULL
    // 0x711c08: b.eq            #0x711d28
    // 0x711c0c: mov             x0, x3
    // 0x711c10: r2 = Null
    //     0x711c10: mov             x2, NULL
    // 0x711c14: r1 = Null
    //     0x711c14: mov             x1, NULL
    // 0x711c18: r4 = LoadClassIdInstr(r0)
    //     0x711c18: ldur            x4, [x0, #-1]
    //     0x711c1c: ubfx            x4, x4, #0xc, #0x14
    // 0x711c20: cmp             x4, #0x994
    // 0x711c24: b.eq            #0x711c3c
    // 0x711c28: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x711c28: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x711c2c: ldr             x8, [x8, #0xa48]
    // 0x711c30: r3 = Null
    //     0x711c30: add             x3, PP, #0x50, lsl #12  ; [pp+0x50dd8] Null
    //     0x711c34: ldr             x3, [x3, #0xdd8]
    // 0x711c38: r0 = DefaultTypeTest()
    //     0x711c38: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x711c3c: ldur            x16, [fp, #-8]
    // 0x711c40: ldr             lr, [fp, #0x18]
    // 0x711c44: stp             lr, x16, [SP, #-0x10]!
    // 0x711c48: r0 = backButton=()
    //     0x711c48: bl              #0x711ec0  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::backButton=
    // 0x711c4c: add             SP, SP, #0x10
    // 0x711c50: b               #0x711d10
    // 0x711c54: ldr             x0, [fp, #0x20]
    // 0x711c58: LoadField: r3 = r0->field_3b
    //     0x711c58: ldur            w3, [x0, #0x3b]
    // 0x711c5c: DecompressPointer r3
    //     0x711c5c: add             x3, x3, HEAP, lsl #32
    // 0x711c60: stur            x3, [fp, #-8]
    // 0x711c64: cmp             w3, NULL
    // 0x711c68: b.eq            #0x711d2c
    // 0x711c6c: mov             x0, x3
    // 0x711c70: r2 = Null
    //     0x711c70: mov             x2, NULL
    // 0x711c74: r1 = Null
    //     0x711c74: mov             x1, NULL
    // 0x711c78: r4 = LoadClassIdInstr(r0)
    //     0x711c78: ldur            x4, [x0, #-1]
    //     0x711c7c: ubfx            x4, x4, #0xc, #0x14
    // 0x711c80: cmp             x4, #0x994
    // 0x711c84: b.eq            #0x711c9c
    // 0x711c88: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x711c88: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x711c8c: ldr             x8, [x8, #0xa48]
    // 0x711c90: r3 = Null
    //     0x711c90: add             x3, PP, #0x50, lsl #12  ; [pp+0x50de8] Null
    //     0x711c94: ldr             x3, [x3, #0xde8]
    // 0x711c98: r0 = DefaultTypeTest()
    //     0x711c98: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x711c9c: ldur            x16, [fp, #-8]
    // 0x711ca0: ldr             lr, [fp, #0x18]
    // 0x711ca4: stp             lr, x16, [SP, #-0x10]!
    // 0x711ca8: r0 = nextButton=()
    //     0x711ca8: bl              #0x711e4c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::nextButton=
    // 0x711cac: add             SP, SP, #0x10
    // 0x711cb0: b               #0x711d10
    // 0x711cb4: ldr             x0, [fp, #0x20]
    // 0x711cb8: LoadField: r3 = r0->field_3b
    //     0x711cb8: ldur            w3, [x0, #0x3b]
    // 0x711cbc: DecompressPointer r3
    //     0x711cbc: add             x3, x3, HEAP, lsl #32
    // 0x711cc0: stur            x3, [fp, #-8]
    // 0x711cc4: cmp             w3, NULL
    // 0x711cc8: b.eq            #0x711d30
    // 0x711ccc: mov             x0, x3
    // 0x711cd0: r2 = Null
    //     0x711cd0: mov             x2, NULL
    // 0x711cd4: r1 = Null
    //     0x711cd4: mov             x1, NULL
    // 0x711cd8: r4 = LoadClassIdInstr(r0)
    //     0x711cd8: ldur            x4, [x0, #-1]
    //     0x711cdc: ubfx            x4, x4, #0xc, #0x14
    // 0x711ce0: cmp             x4, #0x994
    // 0x711ce4: b.eq            #0x711cfc
    // 0x711ce8: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x711ce8: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x711cec: ldr             x8, [x8, #0xa48]
    // 0x711cf0: r3 = Null
    //     0x711cf0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50df8] Null
    //     0x711cf4: ldr             x3, [x3, #0xdf8]
    // 0x711cf8: r0 = DefaultTypeTest()
    //     0x711cf8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x711cfc: ldur            x16, [fp, #-8]
    // 0x711d00: ldr             lr, [fp, #0x18]
    // 0x711d04: stp             lr, x16, [SP, #-0x10]!
    // 0x711d08: r0 = nextButtonDisabled=()
    //     0x711d08: bl              #0x711d34  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::nextButtonDisabled=
    // 0x711d0c: add             SP, SP, #0x10
    // 0x711d10: r0 = Null
    //     0x711d10: mov             x0, NULL
    // 0x711d14: LeaveFrame
    //     0x711d14: mov             SP, fp
    //     0x711d18: ldp             fp, lr, [SP], #0x10
    // 0x711d1c: ret
    //     0x711d1c: ret             
    // 0x711d20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x711d20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x711d24: b               #0x711bdc
    // 0x711d28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x711d28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x711d2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x711d2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x711d30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x711d30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ moveRenderObjectChild(/* No info */) {
    // ** addr: 0x9ba76c, size: 0x168
    // 0x9ba76c: EnterFrame
    //     0x9ba76c: stp             fp, lr, [SP, #-0x10]!
    //     0x9ba770: mov             fp, SP
    // 0x9ba774: AllocStack(0x10)
    //     0x9ba774: sub             SP, SP, #0x10
    // 0x9ba778: CheckStackOverflow
    //     0x9ba778: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9ba77c: cmp             SP, x16
    //     0x9ba780: b.ls            #0x9ba8c8
    // 0x9ba784: ldr             x0, [fp, #0x18]
    // 0x9ba788: r2 = Null
    //     0x9ba788: mov             x2, NULL
    // 0x9ba78c: r1 = Null
    //     0x9ba78c: mov             x1, NULL
    // 0x9ba790: r8 = IndexedSlot<Element>
    //     0x9ba790: add             x8, PP, #0x50, lsl #12  ; [pp+0x50e08] Type: IndexedSlot<Element>
    //     0x9ba794: ldr             x8, [x8, #0xe08]
    // 0x9ba798: r3 = Null
    //     0x9ba798: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e10] Null
    //     0x9ba79c: ldr             x3, [x3, #0xe10]
    // 0x9ba7a0: r0 = IndexedSlot<Element>()
    //     0x9ba7a0: bl              #0x9ba8d4  ; IsType_IndexedSlot<Element>_Stub
    // 0x9ba7a4: ldr             x0, [fp, #0x10]
    // 0x9ba7a8: r2 = Null
    //     0x9ba7a8: mov             x2, NULL
    // 0x9ba7ac: r1 = Null
    //     0x9ba7ac: mov             x1, NULL
    // 0x9ba7b0: r8 = IndexedSlot<Element>
    //     0x9ba7b0: add             x8, PP, #0x50, lsl #12  ; [pp+0x50e08] Type: IndexedSlot<Element>
    //     0x9ba7b4: ldr             x8, [x8, #0xe08]
    // 0x9ba7b8: r3 = Null
    //     0x9ba7b8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e20] Null
    //     0x9ba7bc: ldr             x3, [x3, #0xe20]
    // 0x9ba7c0: r0 = IndexedSlot<Element>()
    //     0x9ba7c0: bl              #0x9ba8d4  ; IsType_IndexedSlot<Element>_Stub
    // 0x9ba7c4: ldr             x0, [fp, #0x28]
    // 0x9ba7c8: LoadField: r3 = r0->field_3b
    //     0x9ba7c8: ldur            w3, [x0, #0x3b]
    // 0x9ba7cc: DecompressPointer r3
    //     0x9ba7cc: add             x3, x3, HEAP, lsl #32
    // 0x9ba7d0: stur            x3, [fp, #-8]
    // 0x9ba7d4: cmp             w3, NULL
    // 0x9ba7d8: b.eq            #0x9ba8d0
    // 0x9ba7dc: mov             x0, x3
    // 0x9ba7e0: r2 = Null
    //     0x9ba7e0: mov             x2, NULL
    // 0x9ba7e4: r1 = Null
    //     0x9ba7e4: mov             x1, NULL
    // 0x9ba7e8: r4 = LoadClassIdInstr(r0)
    //     0x9ba7e8: ldur            x4, [x0, #-1]
    //     0x9ba7ec: ubfx            x4, x4, #0xc, #0x14
    // 0x9ba7f0: cmp             x4, #0x994
    // 0x9ba7f4: b.eq            #0x9ba80c
    // 0x9ba7f8: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x9ba7f8: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x9ba7fc: ldr             x8, [x8, #0xa48]
    // 0x9ba800: r3 = Null
    //     0x9ba800: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e30] Null
    //     0x9ba804: ldr             x3, [x3, #0xe30]
    // 0x9ba808: r0 = DefaultTypeTest()
    //     0x9ba808: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9ba80c: ldr             x0, [fp, #0x20]
    // 0x9ba810: r2 = Null
    //     0x9ba810: mov             x2, NULL
    // 0x9ba814: r1 = Null
    //     0x9ba814: mov             x1, NULL
    // 0x9ba818: r4 = LoadClassIdInstr(r0)
    //     0x9ba818: ldur            x4, [x0, #-1]
    //     0x9ba81c: ubfx            x4, x4, #0xc, #0x14
    // 0x9ba820: sub             x4, x4, #0x965
    // 0x9ba824: cmp             x4, #0x8b
    // 0x9ba828: b.ls            #0x9ba840
    // 0x9ba82c: r8 = RenderBox
    //     0x9ba82c: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x9ba830: ldr             x8, [x8, #0xfa0]
    // 0x9ba834: r3 = Null
    //     0x9ba834: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e40] Null
    //     0x9ba838: ldr             x3, [x3, #0xe40]
    // 0x9ba83c: r0 = RenderBox()
    //     0x9ba83c: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x9ba840: ldr             x0, [fp, #0x10]
    // 0x9ba844: LoadField: r1 = r0->field_b
    //     0x9ba844: ldur            w1, [x0, #0xb]
    // 0x9ba848: DecompressPointer r1
    //     0x9ba848: add             x1, x1, HEAP, lsl #32
    // 0x9ba84c: r0 = LoadClassIdInstr(r1)
    //     0x9ba84c: ldur            x0, [x1, #-1]
    //     0x9ba850: ubfx            x0, x0, #0xc, #0x14
    // 0x9ba854: SaveReg r1
    //     0x9ba854: str             x1, [SP, #-8]!
    // 0x9ba858: r0 = GDT[cid_x0 + -0xf32]()
    //     0x9ba858: sub             lr, x0, #0xf32
    //     0x9ba85c: ldr             lr, [x21, lr, lsl #3]
    //     0x9ba860: blr             lr
    // 0x9ba864: add             SP, SP, #8
    // 0x9ba868: mov             x3, x0
    // 0x9ba86c: r2 = Null
    //     0x9ba86c: mov             x2, NULL
    // 0x9ba870: r1 = Null
    //     0x9ba870: mov             x1, NULL
    // 0x9ba874: stur            x3, [fp, #-0x10]
    // 0x9ba878: r4 = LoadClassIdInstr(r0)
    //     0x9ba878: ldur            x4, [x0, #-1]
    //     0x9ba87c: ubfx            x4, x4, #0xc, #0x14
    // 0x9ba880: sub             x4, x4, #0x965
    // 0x9ba884: cmp             x4, #0x8b
    // 0x9ba888: b.ls            #0x9ba89c
    // 0x9ba88c: r8 = RenderBox?
    //     0x9ba88c: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x9ba890: r3 = Null
    //     0x9ba890: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e50] Null
    //     0x9ba894: ldr             x3, [x3, #0xe50]
    // 0x9ba898: r0 = RenderBox?()
    //     0x9ba898: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x9ba89c: ldur            x16, [fp, #-8]
    // 0x9ba8a0: ldr             lr, [fp, #0x20]
    // 0x9ba8a4: stp             lr, x16, [SP, #-0x10]!
    // 0x9ba8a8: ldur            x16, [fp, #-0x10]
    // 0x9ba8ac: SaveReg r16
    //     0x9ba8ac: str             x16, [SP, #-8]!
    // 0x9ba8b0: r0 = move()
    //     0x9ba8b0: bl              #0x5af504  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::move
    // 0x9ba8b4: add             SP, SP, #0x18
    // 0x9ba8b8: r0 = Null
    //     0x9ba8b8: mov             x0, NULL
    // 0x9ba8bc: LeaveFrame
    //     0x9ba8bc: mov             SP, fp
    //     0x9ba8c0: ldp             fp, lr, [SP], #0x10
    // 0x9ba8c4: ret
    //     0x9ba8c4: ret             
    // 0x9ba8c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9ba8c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9ba8cc: b               #0x9ba784
    // 0x9ba8d0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9ba8d0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ insertRenderObjectChild(/* No info */) {
    // ** addr: 0x9bb224, size: 0x248
    // 0x9bb224: EnterFrame
    //     0x9bb224: stp             fp, lr, [SP, #-0x10]!
    //     0x9bb228: mov             fp, SP
    // 0x9bb22c: AllocStack(0x10)
    //     0x9bb22c: sub             SP, SP, #0x10
    // 0x9bb230: CheckStackOverflow
    //     0x9bb230: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bb234: cmp             SP, x16
    //     0x9bb238: b.ls            #0x9bb460
    // 0x9bb23c: ldr             x3, [fp, #0x10]
    // 0x9bb240: r0 = LoadTaggedClassIdMayBeSmiInstr(r3)
    //     0x9bb240: mov             x0, #0x76
    //     0x9bb244: tbz             w3, #0, #0x9bb254
    //     0x9bb248: ldur            x0, [x3, #-1]
    //     0x9bb24c: ubfx            x0, x0, #0xc, #0x14
    //     0x9bb250: lsl             x0, x0, #1
    // 0x9bb254: r17 = 11972
    //     0x9bb254: mov             x17, #0x2ec4
    // 0x9bb258: cmp             w0, w17
    // 0x9bb25c: b.ne            #0x9bb2c0
    // 0x9bb260: ldr             x0, [fp, #0x18]
    // 0x9bb264: r2 = Null
    //     0x9bb264: mov             x2, NULL
    // 0x9bb268: r1 = Null
    //     0x9bb268: mov             x1, NULL
    // 0x9bb26c: r4 = LoadClassIdInstr(r0)
    //     0x9bb26c: ldur            x4, [x0, #-1]
    //     0x9bb270: ubfx            x4, x4, #0xc, #0x14
    // 0x9bb274: sub             x4, x4, #0x965
    // 0x9bb278: cmp             x4, #0x8b
    // 0x9bb27c: b.ls            #0x9bb294
    // 0x9bb280: r8 = RenderBox
    //     0x9bb280: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x9bb284: ldr             x8, [x8, #0xfa0]
    // 0x9bb288: r3 = Null
    //     0x9bb288: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e60] Null
    //     0x9bb28c: ldr             x3, [x3, #0xe60]
    // 0x9bb290: r0 = RenderBox()
    //     0x9bb290: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x9bb294: ldr             x16, [fp, #0x20]
    // 0x9bb298: ldr             lr, [fp, #0x18]
    // 0x9bb29c: stp             lr, x16, [SP, #-0x10]!
    // 0x9bb2a0: ldr             x16, [fp, #0x10]
    // 0x9bb2a4: SaveReg r16
    //     0x9bb2a4: str             x16, [SP, #-8]!
    // 0x9bb2a8: r0 = _updateRenderObject()
    //     0x9bb2a8: bl              #0x711bc4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_updateRenderObject
    // 0x9bb2ac: add             SP, SP, #0x18
    // 0x9bb2b0: r0 = Null
    //     0x9bb2b0: mov             x0, NULL
    // 0x9bb2b4: LeaveFrame
    //     0x9bb2b4: mov             SP, fp
    //     0x9bb2b8: ldp             fp, lr, [SP], #0x10
    // 0x9bb2bc: ret
    //     0x9bb2bc: ret             
    // 0x9bb2c0: ldr             x0, [fp, #0x10]
    // 0x9bb2c4: r2 = Null
    //     0x9bb2c4: mov             x2, NULL
    // 0x9bb2c8: r1 = Null
    //     0x9bb2c8: mov             x1, NULL
    // 0x9bb2cc: cmp             w0, NULL
    // 0x9bb2d0: b.eq            #0x9bb324
    // 0x9bb2d4: branchIfSmi(r0, 0x9bb324)
    //     0x9bb2d4: tbz             w0, #0, #0x9bb324
    // 0x9bb2d8: r8 = IndexedSlot<Element?>
    //     0x9bb2d8: add             x8, PP, #0x50, lsl #12  ; [pp+0x50e70] Type: IndexedSlot<Element?>
    //     0x9bb2dc: ldr             x8, [x8, #0xe70]
    // 0x9bb2e0: r3 = SubtypeTestCache
    //     0x9bb2e0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e78] SubtypeTestCache
    //     0x9bb2e4: ldr             x3, [x3, #0xe78]
    // 0x9bb2e8: r24 = Subtype3TestCacheStub
    //     0x9bb2e8: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0x9bb2ec: LoadField: r30 = r24->field_7
    //     0x9bb2ec: ldur            lr, [x24, #7]
    // 0x9bb2f0: blr             lr
    // 0x9bb2f4: cmp             w7, NULL
    // 0x9bb2f8: b.eq            #0x9bb304
    // 0x9bb2fc: tbnz            w7, #4, #0x9bb324
    // 0x9bb300: b               #0x9bb32c
    // 0x9bb304: r8 = IndexedSlot<Element?>
    //     0x9bb304: add             x8, PP, #0x50, lsl #12  ; [pp+0x50e80] Type: IndexedSlot<Element?>
    //     0x9bb308: ldr             x8, [x8, #0xe80]
    // 0x9bb30c: r3 = SubtypeTestCache
    //     0x9bb30c: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e88] SubtypeTestCache
    //     0x9bb310: ldr             x3, [x3, #0xe88]
    // 0x9bb314: r24 = InstanceOfStub
    //     0x9bb314: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x9bb318: LoadField: r30 = r24->field_7
    //     0x9bb318: ldur            lr, [x24, #7]
    // 0x9bb31c: blr             lr
    // 0x9bb320: b               #0x9bb330
    // 0x9bb324: r0 = false
    //     0x9bb324: add             x0, NULL, #0x30  ; false
    // 0x9bb328: b               #0x9bb330
    // 0x9bb32c: r0 = true
    //     0x9bb32c: add             x0, NULL, #0x20  ; true
    // 0x9bb330: tbnz            w0, #4, #0x9bb450
    // 0x9bb334: ldr             x0, [fp, #0x20]
    // 0x9bb338: ldr             x3, [fp, #0x10]
    // 0x9bb33c: LoadField: r4 = r0->field_3b
    //     0x9bb33c: ldur            w4, [x0, #0x3b]
    // 0x9bb340: DecompressPointer r4
    //     0x9bb340: add             x4, x4, HEAP, lsl #32
    // 0x9bb344: stur            x4, [fp, #-8]
    // 0x9bb348: cmp             w4, NULL
    // 0x9bb34c: b.eq            #0x9bb468
    // 0x9bb350: mov             x0, x4
    // 0x9bb354: r2 = Null
    //     0x9bb354: mov             x2, NULL
    // 0x9bb358: r1 = Null
    //     0x9bb358: mov             x1, NULL
    // 0x9bb35c: r4 = LoadClassIdInstr(r0)
    //     0x9bb35c: ldur            x4, [x0, #-1]
    //     0x9bb360: ubfx            x4, x4, #0xc, #0x14
    // 0x9bb364: cmp             x4, #0x994
    // 0x9bb368: b.eq            #0x9bb380
    // 0x9bb36c: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x9bb36c: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x9bb370: ldr             x8, [x8, #0xa48]
    // 0x9bb374: r3 = Null
    //     0x9bb374: add             x3, PP, #0x50, lsl #12  ; [pp+0x50e90] Null
    //     0x9bb378: ldr             x3, [x3, #0xe90]
    // 0x9bb37c: r0 = DefaultTypeTest()
    //     0x9bb37c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x9bb380: ldr             x0, [fp, #0x18]
    // 0x9bb384: r2 = Null
    //     0x9bb384: mov             x2, NULL
    // 0x9bb388: r1 = Null
    //     0x9bb388: mov             x1, NULL
    // 0x9bb38c: r4 = LoadClassIdInstr(r0)
    //     0x9bb38c: ldur            x4, [x0, #-1]
    //     0x9bb390: ubfx            x4, x4, #0xc, #0x14
    // 0x9bb394: sub             x4, x4, #0x965
    // 0x9bb398: cmp             x4, #0x8b
    // 0x9bb39c: b.ls            #0x9bb3b4
    // 0x9bb3a0: r8 = RenderBox
    //     0x9bb3a0: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0x9bb3a4: ldr             x8, [x8, #0xfa0]
    // 0x9bb3a8: r3 = Null
    //     0x9bb3a8: add             x3, PP, #0x50, lsl #12  ; [pp+0x50ea0] Null
    //     0x9bb3ac: ldr             x3, [x3, #0xea0]
    // 0x9bb3b0: r0 = RenderBox()
    //     0x9bb3b0: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0x9bb3b4: ldr             x0, [fp, #0x10]
    // 0x9bb3b8: LoadField: r1 = r0->field_b
    //     0x9bb3b8: ldur            w1, [x0, #0xb]
    // 0x9bb3bc: DecompressPointer r1
    //     0x9bb3bc: add             x1, x1, HEAP, lsl #32
    // 0x9bb3c0: cmp             w1, NULL
    // 0x9bb3c4: b.ne            #0x9bb3d0
    // 0x9bb3c8: r3 = Null
    //     0x9bb3c8: mov             x3, NULL
    // 0x9bb3cc: b               #0x9bb3f0
    // 0x9bb3d0: r0 = LoadClassIdInstr(r1)
    //     0x9bb3d0: ldur            x0, [x1, #-1]
    //     0x9bb3d4: ubfx            x0, x0, #0xc, #0x14
    // 0x9bb3d8: SaveReg r1
    //     0x9bb3d8: str             x1, [SP, #-8]!
    // 0x9bb3dc: r0 = GDT[cid_x0 + -0xf32]()
    //     0x9bb3dc: sub             lr, x0, #0xf32
    //     0x9bb3e0: ldr             lr, [x21, lr, lsl #3]
    //     0x9bb3e4: blr             lr
    // 0x9bb3e8: add             SP, SP, #8
    // 0x9bb3ec: mov             x3, x0
    // 0x9bb3f0: mov             x0, x3
    // 0x9bb3f4: stur            x3, [fp, #-0x10]
    // 0x9bb3f8: r2 = Null
    //     0x9bb3f8: mov             x2, NULL
    // 0x9bb3fc: r1 = Null
    //     0x9bb3fc: mov             x1, NULL
    // 0x9bb400: r4 = LoadClassIdInstr(r0)
    //     0x9bb400: ldur            x4, [x0, #-1]
    //     0x9bb404: ubfx            x4, x4, #0xc, #0x14
    // 0x9bb408: sub             x4, x4, #0x965
    // 0x9bb40c: cmp             x4, #0x8b
    // 0x9bb410: b.ls            #0x9bb424
    // 0x9bb414: r8 = RenderBox?
    //     0x9bb414: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0x9bb418: r3 = Null
    //     0x9bb418: add             x3, PP, #0x50, lsl #12  ; [pp+0x50eb0] Null
    //     0x9bb41c: ldr             x3, [x3, #0xeb0]
    // 0x9bb420: r0 = RenderBox?()
    //     0x9bb420: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0x9bb424: ldur            x16, [fp, #-8]
    // 0x9bb428: ldr             lr, [fp, #0x18]
    // 0x9bb42c: stp             lr, x16, [SP, #-0x10]!
    // 0x9bb430: ldur            x16, [fp, #-0x10]
    // 0x9bb434: SaveReg r16
    //     0x9bb434: str             x16, [SP, #-8]!
    // 0x9bb438: r0 = insert()
    //     0x9bb438: bl              #0x5e9a74  ; [package:flutter/src/material/text_selection_toolbar.dart] __RenderTextSelectionToolbarItemsLayout&RenderBox&ContainerRenderObjectMixin::insert
    // 0x9bb43c: add             SP, SP, #0x18
    // 0x9bb440: r0 = Null
    //     0x9bb440: mov             x0, NULL
    // 0x9bb444: LeaveFrame
    //     0x9bb444: mov             SP, fp
    //     0x9bb448: ldp             fp, lr, [SP], #0x10
    // 0x9bb44c: ret
    //     0x9bb44c: ret             
    // 0x9bb450: r0 = Null
    //     0x9bb450: mov             x0, NULL
    // 0x9bb454: LeaveFrame
    //     0x9bb454: mov             SP, fp
    //     0x9bb458: ldp             fp, lr, [SP], #0x10
    // 0x9bb45c: ret
    //     0x9bb45c: ret             
    // 0x9bb460: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bb460: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bb464: b               #0x9bb23c
    // 0x9bb468: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9bb468: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _CupertinoTextSelectionToolbarItemsElement(/* No info */) {
    // ** addr: 0xa76fcc, size: 0xf0
    // 0xa76fcc: EnterFrame
    //     0xa76fcc: stp             fp, lr, [SP, #-0x10]!
    //     0xa76fd0: mov             fp, SP
    // 0xa76fd4: r0 = Sentinel
    //     0xa76fd4: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa76fd8: CheckStackOverflow
    //     0xa76fd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa76fdc: cmp             SP, x16
    //     0xa76fe0: b.ls            #0xa770b4
    // 0xa76fe4: ldr             x1, [fp, #0x18]
    // 0xa76fe8: StoreField: r1->field_43 = r0
    //     0xa76fe8: stur            w0, [x1, #0x43]
    // 0xa76fec: r16 = <_CupertinoTextSelectionToolbarItemsSlot, Element>
    //     0xa76fec: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4ba40] TypeArguments: <_CupertinoTextSelectionToolbarItemsSlot, Element>
    //     0xa76ff0: ldr             x16, [x16, #0xa40]
    // 0xa76ff4: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0xa76ff8: stp             lr, x16, [SP, #-0x10]!
    // 0xa76ffc: r0 = Map._fromLiteral()
    //     0xa76ffc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xa77000: add             SP, SP, #0x10
    // 0xa77004: ldr             x1, [fp, #0x18]
    // 0xa77008: StoreField: r1->field_47 = r0
    //     0xa77008: stur            w0, [x1, #0x47]
    //     0xa7700c: tbz             w0, #0, #0xa77028
    //     0xa77010: ldurb           w16, [x1, #-1]
    //     0xa77014: ldurb           w17, [x0, #-1]
    //     0xa77018: and             x16, x17, x16, lsr #2
    //     0xa7701c: tst             x16, HEAP, lsr #32
    //     0xa77020: b.eq            #0xa77028
    //     0xa77024: bl              #0xd6826c
    // 0xa77028: r16 = <Element>
    //     0xa77028: ldr             x16, [PP, #0x3d40]  ; [pp+0x3d40] TypeArguments: <Element>
    // 0xa7702c: SaveReg r16
    //     0xa7702c: str             x16, [SP, #-8]!
    // 0xa77030: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa77030: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa77034: r0 = HashSet()
    //     0xa77034: bl              #0x5519d0  ; [dart:collection] HashSet::HashSet
    // 0xa77038: add             SP, SP, #8
    // 0xa7703c: ldr             x1, [fp, #0x18]
    // 0xa77040: StoreField: r1->field_4b = r0
    //     0xa77040: stur            w0, [x1, #0x4b]
    //     0xa77044: tbz             w0, #0, #0xa77060
    //     0xa77048: ldurb           w16, [x1, #-1]
    //     0xa7704c: ldurb           w17, [x0, #-1]
    //     0xa77050: and             x16, x17, x16, lsr #2
    //     0xa77054: tst             x16, HEAP, lsr #32
    //     0xa77058: b.eq            #0xa77060
    //     0xa7705c: bl              #0xd6826c
    // 0xa77060: r2 = Sentinel
    //     0xa77060: ldr             x2, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa77064: StoreField: r1->field_17 = r2
    //     0xa77064: stur            w2, [x1, #0x17]
    // 0xa77068: r2 = Instance__ElementLifecycle
    //     0xa77068: ldr             x2, [PP, #0x3cd0]  ; [pp+0x3cd0] Obj!_ElementLifecycle@b63bb1
    // 0xa7706c: StoreField: r1->field_23 = r2
    //     0xa7706c: stur            w2, [x1, #0x23]
    // 0xa77070: r2 = false
    //     0xa77070: add             x2, NULL, #0x30  ; false
    // 0xa77074: StoreField: r1->field_2f = r2
    //     0xa77074: stur            w2, [x1, #0x2f]
    // 0xa77078: r3 = true
    //     0xa77078: add             x3, NULL, #0x20  ; true
    // 0xa7707c: StoreField: r1->field_33 = r3
    //     0xa7707c: stur            w3, [x1, #0x33]
    // 0xa77080: StoreField: r1->field_37 = r2
    //     0xa77080: stur            w2, [x1, #0x37]
    // 0xa77084: ldr             x0, [fp, #0x10]
    // 0xa77088: StoreField: r1->field_1b = r0
    //     0xa77088: stur            w0, [x1, #0x1b]
    //     0xa7708c: ldurb           w16, [x1, #-1]
    //     0xa77090: ldurb           w17, [x0, #-1]
    //     0xa77094: and             x16, x17, x16, lsr #2
    //     0xa77098: tst             x16, HEAP, lsr #32
    //     0xa7709c: b.eq            #0xa770a4
    //     0xa770a0: bl              #0xd6826c
    // 0xa770a4: r0 = Null
    //     0xa770a4: mov             x0, NULL
    // 0xa770a8: LeaveFrame
    //     0xa770a8: mov             SP, fp
    //     0xa770ac: ldp             fp, lr, [SP], #0x10
    // 0xa770b0: ret
    //     0xa770b0: ret             
    // 0xa770b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa770b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa770b8: b               #0xa76fe4
  }
  _ visitChildren(/* No info */) {
    // ** addr: 0xccbad0, size: 0x17c
    // 0xccbad0: EnterFrame
    //     0xccbad0: stp             fp, lr, [SP, #-0x10]!
    //     0xccbad4: mov             fp, SP
    // 0xccbad8: AllocStack(0x30)
    //     0xccbad8: sub             SP, SP, #0x30
    // 0xccbadc: CheckStackOverflow
    //     0xccbadc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccbae0: cmp             SP, x16
    //     0xccbae4: b.ls            #0xccbc30
    // 0xccbae8: ldr             x0, [fp, #0x18]
    // 0xccbaec: LoadField: r1 = r0->field_47
    //     0xccbaec: ldur            w1, [x0, #0x47]
    // 0xccbaf0: DecompressPointer r1
    //     0xccbaf0: add             x1, x1, HEAP, lsl #32
    // 0xccbaf4: SaveReg r1
    //     0xccbaf4: str             x1, [SP, #-8]!
    // 0xccbaf8: r0 = values()
    //     0xccbaf8: bl              #0xc9e734  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::values
    // 0xccbafc: add             SP, SP, #8
    // 0xccbb00: ldr             x16, [fp, #0x10]
    // 0xccbb04: stp             x16, x0, [SP, #-0x10]!
    // 0xccbb08: r0 = forEach()
    //     0xccbb08: bl              #0x6ab958  ; [dart:core] Iterable::forEach
    // 0xccbb0c: add             SP, SP, #0x10
    // 0xccbb10: ldr             x0, [fp, #0x18]
    // 0xccbb14: LoadField: r3 = r0->field_43
    //     0xccbb14: ldur            w3, [x0, #0x43]
    // 0xccbb18: DecompressPointer r3
    //     0xccbb18: add             x3, x3, HEAP, lsl #32
    // 0xccbb1c: r16 = Sentinel
    //     0xccbb1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xccbb20: cmp             w3, w16
    // 0xccbb24: b.eq            #0xccbc38
    // 0xccbb28: stur            x3, [fp, #-0x30]
    // 0xccbb2c: LoadField: r4 = r3->field_7
    //     0xccbb2c: ldur            w4, [x3, #7]
    // 0xccbb30: DecompressPointer r4
    //     0xccbb30: add             x4, x4, HEAP, lsl #32
    // 0xccbb34: stur            x4, [fp, #-0x28]
    // 0xccbb38: LoadField: r1 = r3->field_b
    //     0xccbb38: ldur            w1, [x3, #0xb]
    // 0xccbb3c: DecompressPointer r1
    //     0xccbb3c: add             x1, x1, HEAP, lsl #32
    // 0xccbb40: r5 = LoadInt32Instr(r1)
    //     0xccbb40: sbfx            x5, x1, #1, #0x1f
    // 0xccbb44: stur            x5, [fp, #-0x20]
    // 0xccbb48: LoadField: r6 = r0->field_4b
    //     0xccbb48: ldur            w6, [x0, #0x4b]
    // 0xccbb4c: DecompressPointer r6
    //     0xccbb4c: add             x6, x6, HEAP, lsl #32
    // 0xccbb50: stur            x6, [fp, #-0x18]
    // 0xccbb54: r0 = 0
    //     0xccbb54: mov             x0, #0
    // 0xccbb58: CheckStackOverflow
    //     0xccbb58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccbb5c: cmp             SP, x16
    //     0xccbb60: b.ls            #0xccbc44
    // 0xccbb64: cmp             x0, x5
    // 0xccbb68: b.lt            #0xccbb7c
    // 0xccbb6c: r0 = Null
    //     0xccbb6c: mov             x0, NULL
    // 0xccbb70: LeaveFrame
    //     0xccbb70: mov             SP, fp
    //     0xccbb74: ldp             fp, lr, [SP], #0x10
    // 0xccbb78: ret
    //     0xccbb78: ret             
    // 0xccbb7c: ArrayLoad: r7 = r3[r0]  ; Unknown_4
    //     0xccbb7c: add             x16, x3, x0, lsl #2
    //     0xccbb80: ldur            w7, [x16, #0xf]
    // 0xccbb84: DecompressPointer r7
    //     0xccbb84: add             x7, x7, HEAP, lsl #32
    // 0xccbb88: stur            x7, [fp, #-0x10]
    // 0xccbb8c: add             x8, x0, #1
    // 0xccbb90: stur            x8, [fp, #-8]
    // 0xccbb94: cmp             w7, NULL
    // 0xccbb98: b.ne            #0xccbbcc
    // 0xccbb9c: mov             x0, x7
    // 0xccbba0: mov             x2, x4
    // 0xccbba4: r1 = Null
    //     0xccbba4: mov             x1, NULL
    // 0xccbba8: cmp             w2, NULL
    // 0xccbbac: b.eq            #0xccbbcc
    // 0xccbbb0: LoadField: r4 = r2->field_17
    //     0xccbbb0: ldur            w4, [x2, #0x17]
    // 0xccbbb4: DecompressPointer r4
    //     0xccbbb4: add             x4, x4, HEAP, lsl #32
    // 0xccbbb8: r8 = X0
    //     0xccbbb8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xccbbbc: LoadField: r9 = r4->field_7
    //     0xccbbbc: ldur            x9, [x4, #7]
    // 0xccbbc0: r3 = Null
    //     0xccbbc0: add             x3, PP, #0x50, lsl #12  ; [pp+0x50db8] Null
    //     0xccbbc4: ldr             x3, [x3, #0xdb8]
    // 0xccbbc8: blr             x9
    // 0xccbbcc: ldur            x1, [fp, #-0x18]
    // 0xccbbd0: r0 = LoadClassIdInstr(r1)
    //     0xccbbd0: ldur            x0, [x1, #-1]
    //     0xccbbd4: ubfx            x0, x0, #0xc, #0x14
    // 0xccbbd8: ldur            x16, [fp, #-0x10]
    // 0xccbbdc: stp             x16, x1, [SP, #-0x10]!
    // 0xccbbe0: r0 = GDT[cid_x0 + 0xc98a]()
    //     0xccbbe0: mov             x17, #0xc98a
    //     0xccbbe4: add             lr, x0, x17
    //     0xccbbe8: ldr             lr, [x21, lr, lsl #3]
    //     0xccbbec: blr             lr
    // 0xccbbf0: add             SP, SP, #0x10
    // 0xccbbf4: tbz             w0, #4, #0xccbc18
    // 0xccbbf8: ldr             x16, [fp, #0x10]
    // 0xccbbfc: ldur            lr, [fp, #-0x10]
    // 0xccbc00: stp             lr, x16, [SP, #-0x10]!
    // 0xccbc04: ldr             x0, [fp, #0x10]
    // 0xccbc08: ClosureCall
    //     0xccbc08: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xccbc0c: ldur            x2, [x0, #0x1f]
    //     0xccbc10: blr             x2
    // 0xccbc14: add             SP, SP, #0x10
    // 0xccbc18: ldur            x0, [fp, #-8]
    // 0xccbc1c: ldur            x6, [fp, #-0x18]
    // 0xccbc20: ldur            x3, [fp, #-0x30]
    // 0xccbc24: ldur            x4, [fp, #-0x28]
    // 0xccbc28: ldur            x5, [fp, #-0x20]
    // 0xccbc2c: b               #0xccbb58
    // 0xccbc30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccbc30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccbc34: b               #0xccbae8
    // 0xccbc38: r9 = _children
    //     0xccbc38: add             x9, PP, #0x50, lsl #12  ; [pp+0x50d78] Field <_CupertinoTextSelectionToolbarItemsElement@621408280._children@621408280>: late (offset: 0x44)
    //     0xccbc3c: ldr             x9, [x9, #0xd78]
    // 0xccbc40: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xccbc40: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xccbc44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccbc44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccbc48: b               #0xccbb64
  }
  get _ renderObject(/* No info */) {
    // ** addr: 0xcdcdec, size: 0x68
    // 0xcdcdec: EnterFrame
    //     0xcdcdec: stp             fp, lr, [SP, #-0x10]!
    //     0xcdcdf0: mov             fp, SP
    // 0xcdcdf4: AllocStack(0x8)
    //     0xcdcdf4: sub             SP, SP, #8
    // 0xcdcdf8: ldr             x0, [fp, #0x10]
    // 0xcdcdfc: LoadField: r3 = r0->field_3b
    //     0xcdcdfc: ldur            w3, [x0, #0x3b]
    // 0xcdce00: DecompressPointer r3
    //     0xcdce00: add             x3, x3, HEAP, lsl #32
    // 0xcdce04: stur            x3, [fp, #-8]
    // 0xcdce08: cmp             w3, NULL
    // 0xcdce0c: b.eq            #0xcdce50
    // 0xcdce10: mov             x0, x3
    // 0xcdce14: r2 = Null
    //     0xcdce14: mov             x2, NULL
    // 0xcdce18: r1 = Null
    //     0xcdce18: mov             x1, NULL
    // 0xcdce1c: r4 = LoadClassIdInstr(r0)
    //     0xcdce1c: ldur            x4, [x0, #-1]
    //     0xcdce20: ubfx            x4, x4, #0xc, #0x14
    // 0xcdce24: cmp             x4, #0x994
    // 0xcdce28: b.eq            #0xcdce40
    // 0xcdce2c: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0xcdce2c: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0xcdce30: ldr             x8, [x8, #0xa48]
    // 0xcdce34: r3 = Null
    //     0xcdce34: add             x3, PP, #0x50, lsl #12  ; [pp+0x50ec0] Null
    //     0xcdce38: ldr             x3, [x3, #0xec0]
    // 0xcdce3c: r0 = DefaultTypeTest()
    //     0xcdce3c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcdce40: ldur            x0, [fp, #-8]
    // 0xcdce44: LeaveFrame
    //     0xcdce44: mov             SP, fp
    //     0xcdce48: ldp             fp, lr, [SP], #0x10
    // 0xcdce4c: ret
    //     0xcdce4c: ret             
    // 0xcdce50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcdce50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3482, size: 0xc, field offset: 0xc
//   const constructor, 
class _NullWidget extends Widget {
}

// class id: 3569, size: 0x2c, field offset: 0xc
class _CupertinoTextSelectionToolbarItems extends RenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6e58bc, size: 0x98
    // 0x6e58bc: EnterFrame
    //     0x6e58bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6e58c0: mov             fp, SP
    // 0x6e58c4: CheckStackOverflow
    //     0x6e58c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e58c8: cmp             SP, x16
    //     0x6e58cc: b.ls            #0x6e594c
    // 0x6e58d0: ldr             x0, [fp, #0x10]
    // 0x6e58d4: r2 = Null
    //     0x6e58d4: mov             x2, NULL
    // 0x6e58d8: r1 = Null
    //     0x6e58d8: mov             x1, NULL
    // 0x6e58dc: r4 = 59
    //     0x6e58dc: mov             x4, #0x3b
    // 0x6e58e0: branchIfSmi(r0, 0x6e58ec)
    //     0x6e58e0: tbz             w0, #0, #0x6e58ec
    // 0x6e58e4: r4 = LoadClassIdInstr(r0)
    //     0x6e58e4: ldur            x4, [x0, #-1]
    //     0x6e58e8: ubfx            x4, x4, #0xc, #0x14
    // 0x6e58ec: cmp             x4, #0x994
    // 0x6e58f0: b.eq            #0x6e5908
    // 0x6e58f4: r8 = _RenderCupertinoTextSelectionToolbarItems
    //     0x6e58f4: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba48] Type: _RenderCupertinoTextSelectionToolbarItems
    //     0x6e58f8: ldr             x8, [x8, #0xa48]
    // 0x6e58fc: r3 = Null
    //     0x6e58fc: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4ba50] Null
    //     0x6e5900: ldr             x3, [x3, #0xa50]
    // 0x6e5904: r0 = DefaultTypeTest()
    //     0x6e5904: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6e5908: ldr             x0, [fp, #0x20]
    // 0x6e590c: LoadField: r1 = r0->field_23
    //     0x6e590c: ldur            x1, [x0, #0x23]
    // 0x6e5910: ldr             x16, [fp, #0x10]
    // 0x6e5914: stp             x1, x16, [SP, #-0x10]!
    // 0x6e5918: r0 = page=()
    //     0x6e5918: bl              #0x6e59b8  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::page=
    // 0x6e591c: add             SP, SP, #0x10
    // 0x6e5920: ldr             x0, [fp, #0x20]
    // 0x6e5924: LoadField: d0 = r0->field_13
    //     0x6e5924: ldur            d0, [x0, #0x13]
    // 0x6e5928: ldr             x16, [fp, #0x10]
    // 0x6e592c: SaveReg r16
    //     0x6e592c: str             x16, [SP, #-8]!
    // 0x6e5930: SaveReg d0
    //     0x6e5930: str             d0, [SP, #-8]!
    // 0x6e5934: r0 = dividerWidth=()
    //     0x6e5934: bl              #0x6e5954  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::dividerWidth=
    // 0x6e5938: add             SP, SP, #0x10
    // 0x6e593c: r0 = Null
    //     0x6e593c: mov             x0, NULL
    // 0x6e5940: LeaveFrame
    //     0x6e5940: mov             SP, fp
    //     0x6e5944: ldp             fp, lr, [SP], #0x10
    // 0x6e5948: ret
    //     0x6e5948: ret             
    // 0x6e594c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e594c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e5950: b               #0x6e58d0
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6f52b8, size: 0xa4
    // 0x6f52b8: EnterFrame
    //     0x6f52b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6f52bc: mov             fp, SP
    // 0x6f52c0: AllocStack(0x18)
    //     0x6f52c0: sub             SP, SP, #0x18
    // 0x6f52c4: CheckStackOverflow
    //     0x6f52c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f52c8: cmp             SP, x16
    //     0x6f52cc: b.ls            #0x6f533c
    // 0x6f52d0: ldr             x0, [fp, #0x18]
    // 0x6f52d4: LoadField: d0 = r0->field_13
    //     0x6f52d4: ldur            d0, [x0, #0x13]
    // 0x6f52d8: LoadField: r1 = r0->field_23
    //     0x6f52d8: ldur            x1, [x0, #0x23]
    // 0x6f52dc: stur            x1, [fp, #-0x10]
    // 0x6f52e0: r0 = inline_Allocate_Double()
    //     0x6f52e0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6f52e4: add             x0, x0, #0x10
    //     0x6f52e8: cmp             x2, x0
    //     0x6f52ec: b.ls            #0x6f5344
    //     0x6f52f0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6f52f4: sub             x0, x0, #0xf
    //     0x6f52f8: mov             x2, #0xd108
    //     0x6f52fc: movk            x2, #3, lsl #16
    //     0x6f5300: stur            x2, [x0, #-1]
    // 0x6f5304: StoreField: r0->field_7 = d0
    //     0x6f5304: stur            d0, [x0, #7]
    // 0x6f5308: stur            x0, [fp, #-8]
    // 0x6f530c: r0 = _RenderCupertinoTextSelectionToolbarItems()
    //     0x6f530c: bl              #0x6f53ec  ; Allocate_RenderCupertinoTextSelectionToolbarItemsStub -> _RenderCupertinoTextSelectionToolbarItems (size=0x90)
    // 0x6f5310: stur            x0, [fp, #-0x18]
    // 0x6f5314: ldur            x16, [fp, #-8]
    // 0x6f5318: stp             x16, x0, [SP, #-0x10]!
    // 0x6f531c: ldur            x1, [fp, #-0x10]
    // 0x6f5320: SaveReg r1
    //     0x6f5320: str             x1, [SP, #-8]!
    // 0x6f5324: r0 = _RenderCupertinoTextSelectionToolbarItems()
    //     0x6f5324: bl              #0x6f535c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarItems::_RenderCupertinoTextSelectionToolbarItems
    // 0x6f5328: add             SP, SP, #0x18
    // 0x6f532c: ldur            x0, [fp, #-0x18]
    // 0x6f5330: LeaveFrame
    //     0x6f5330: mov             SP, fp
    //     0x6f5334: ldp             fp, lr, [SP], #0x10
    // 0x6f5338: ret
    //     0x6f5338: ret             
    // 0x6f533c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f533c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f5340: b               #0x6f52d0
    // 0x6f5344: SaveReg d0
    //     0x6f5344: str             q0, [SP, #-0x10]!
    // 0x6f5348: SaveReg r1
    //     0x6f5348: str             x1, [SP, #-8]!
    // 0x6f534c: r0 = AllocateDouble()
    //     0x6f534c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6f5350: RestoreReg r1
    //     0x6f5350: ldr             x1, [SP], #8
    // 0x6f5354: RestoreReg d0
    //     0x6f5354: ldr             q0, [SP], #0x10
    // 0x6f5358: b               #0x6f5304
  }
  _ createElement(/* No info */) {
    // ** addr: 0xa76f84, size: 0x48
    // 0xa76f84: EnterFrame
    //     0xa76f84: stp             fp, lr, [SP, #-0x10]!
    //     0xa76f88: mov             fp, SP
    // 0xa76f8c: AllocStack(0x8)
    //     0xa76f8c: sub             SP, SP, #8
    // 0xa76f90: CheckStackOverflow
    //     0xa76f90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa76f94: cmp             SP, x16
    //     0xa76f98: b.ls            #0xa76fc4
    // 0xa76f9c: r0 = _CupertinoTextSelectionToolbarItemsElement()
    //     0xa76f9c: bl              #0xa770bc  ; Allocate_CupertinoTextSelectionToolbarItemsElementStub -> _CupertinoTextSelectionToolbarItemsElement (size=0x50)
    // 0xa76fa0: stur            x0, [fp, #-8]
    // 0xa76fa4: ldr             x16, [fp, #0x10]
    // 0xa76fa8: stp             x16, x0, [SP, #-0x10]!
    // 0xa76fac: r0 = _CupertinoTextSelectionToolbarItemsElement()
    //     0xa76fac: bl              #0xa76fcc  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _CupertinoTextSelectionToolbarItemsElement::_CupertinoTextSelectionToolbarItemsElement
    // 0xa76fb0: add             SP, SP, #0x10
    // 0xa76fb4: ldur            x0, [fp, #-8]
    // 0xa76fb8: LeaveFrame
    //     0xa76fb8: mov             SP, fp
    //     0xa76fbc: ldp             fp, lr, [SP], #0x10
    // 0xa76fc0: ret
    //     0xa76fc0: ret             
    // 0xa76fc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa76fc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa76fc8: b               #0xa76f9c
  }
}

// class id: 3677, size: 0x18, field offset: 0x10
//   const constructor, 
class _CupertinoTextSelectionToolbarShape extends SingleChildRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6c2340, size: 0x9c
    // 0x6c2340: EnterFrame
    //     0x6c2340: stp             fp, lr, [SP, #-0x10]!
    //     0x6c2344: mov             fp, SP
    // 0x6c2348: CheckStackOverflow
    //     0x6c2348: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6c234c: cmp             SP, x16
    //     0x6c2350: b.ls            #0x6c23d4
    // 0x6c2354: ldr             x0, [fp, #0x10]
    // 0x6c2358: r2 = Null
    //     0x6c2358: mov             x2, NULL
    // 0x6c235c: r1 = Null
    //     0x6c235c: mov             x1, NULL
    // 0x6c2360: r4 = 59
    //     0x6c2360: mov             x4, #0x3b
    // 0x6c2364: branchIfSmi(r0, 0x6c2370)
    //     0x6c2364: tbz             w0, #0, #0x6c2370
    // 0x6c2368: r4 = LoadClassIdInstr(r0)
    //     0x6c2368: ldur            x4, [x0, #-1]
    //     0x6c236c: ubfx            x4, x4, #0xc, #0x14
    // 0x6c2370: cmp             x4, #0x9a8
    // 0x6c2374: b.eq            #0x6c238c
    // 0x6c2378: r8 = _RenderCupertinoTextSelectionToolbarShape
    //     0x6c2378: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2e9a8] Type: _RenderCupertinoTextSelectionToolbarShape
    //     0x6c237c: ldr             x8, [x8, #0x9a8]
    // 0x6c2380: r3 = Null
    //     0x6c2380: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2e9b0] Null
    //     0x6c2384: ldr             x3, [x3, #0x9b0]
    // 0x6c2388: r0 = DefaultTypeTest()
    //     0x6c2388: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6c238c: ldr             x0, [fp, #0x20]
    // 0x6c2390: LoadField: r1 = r0->field_f
    //     0x6c2390: ldur            w1, [x0, #0xf]
    // 0x6c2394: DecompressPointer r1
    //     0x6c2394: add             x1, x1, HEAP, lsl #32
    // 0x6c2398: ldr             x16, [fp, #0x10]
    // 0x6c239c: stp             x1, x16, [SP, #-0x10]!
    // 0x6c23a0: r0 = anchor=()
    //     0x6c23a0: bl              #0x6c2440  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::anchor=
    // 0x6c23a4: add             SP, SP, #0x10
    // 0x6c23a8: ldr             x0, [fp, #0x20]
    // 0x6c23ac: LoadField: r1 = r0->field_13
    //     0x6c23ac: ldur            w1, [x0, #0x13]
    // 0x6c23b0: DecompressPointer r1
    //     0x6c23b0: add             x1, x1, HEAP, lsl #32
    // 0x6c23b4: ldr             x16, [fp, #0x10]
    // 0x6c23b8: stp             x1, x16, [SP, #-0x10]!
    // 0x6c23bc: r0 = isAbove=()
    //     0x6c23bc: bl              #0x6c23dc  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::isAbove=
    // 0x6c23c0: add             SP, SP, #0x10
    // 0x6c23c4: r0 = Null
    //     0x6c23c4: mov             x0, NULL
    // 0x6c23c8: LeaveFrame
    //     0x6c23c8: mov             SP, fp
    //     0x6c23cc: ldp             fp, lr, [SP], #0x10
    // 0x6c23d0: ret
    //     0x6c23d0: ret             
    // 0x6c23d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6c23d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6c23d8: b               #0x6c2354
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6e9fc0, size: 0x6c
    // 0x6e9fc0: EnterFrame
    //     0x6e9fc0: stp             fp, lr, [SP, #-0x10]!
    //     0x6e9fc4: mov             fp, SP
    // 0x6e9fc8: AllocStack(0x18)
    //     0x6e9fc8: sub             SP, SP, #0x18
    // 0x6e9fcc: CheckStackOverflow
    //     0x6e9fcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e9fd0: cmp             SP, x16
    //     0x6e9fd4: b.ls            #0x6ea024
    // 0x6e9fd8: ldr             x0, [fp, #0x18]
    // 0x6e9fdc: LoadField: r1 = r0->field_f
    //     0x6e9fdc: ldur            w1, [x0, #0xf]
    // 0x6e9fe0: DecompressPointer r1
    //     0x6e9fe0: add             x1, x1, HEAP, lsl #32
    // 0x6e9fe4: stur            x1, [fp, #-0x10]
    // 0x6e9fe8: LoadField: r2 = r0->field_13
    //     0x6e9fe8: ldur            w2, [x0, #0x13]
    // 0x6e9fec: DecompressPointer r2
    //     0x6e9fec: add             x2, x2, HEAP, lsl #32
    // 0x6e9ff0: stur            x2, [fp, #-8]
    // 0x6e9ff4: r0 = _RenderCupertinoTextSelectionToolbarShape()
    //     0x6e9ff4: bl              #0x6ea10c  ; Allocate_RenderCupertinoTextSelectionToolbarShapeStub -> _RenderCupertinoTextSelectionToolbarShape (size=0x74)
    // 0x6e9ff8: stur            x0, [fp, #-0x18]
    // 0x6e9ffc: ldur            x16, [fp, #-0x10]
    // 0x6ea000: stp             x16, x0, [SP, #-0x10]!
    // 0x6ea004: ldur            x16, [fp, #-8]
    // 0x6ea008: SaveReg r16
    //     0x6ea008: str             x16, [SP, #-8]!
    // 0x6ea00c: r0 = _RenderCupertinoTextSelectionToolbarShape()
    //     0x6ea00c: bl              #0x6ea02c  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] _RenderCupertinoTextSelectionToolbarShape::_RenderCupertinoTextSelectionToolbarShape
    // 0x6ea010: add             SP, SP, #0x18
    // 0x6ea014: ldur            x0, [fp, #-0x18]
    // 0x6ea018: LeaveFrame
    //     0x6ea018: mov             SP, fp
    //     0x6ea01c: ldp             fp, lr, [SP], #0x10
    // 0x6ea020: ret
    //     0x6ea020: ret             
    // 0x6ea024: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ea024: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ea028: b               #0x6e9fd8
  }
}

// class id: 3868, size: 0x1c, field offset: 0xc
//   const constructor, 
class CupertinoTextSelectionToolbar extends StatelessWidget {

  [closure] static Widget _defaultToolbarBuilder(dynamic, BuildContext, Offset, bool, Widget) {
    // ** addr: 0x844eac, size: 0x48
    // 0x844eac: EnterFrame
    //     0x844eac: stp             fp, lr, [SP, #-0x10]!
    //     0x844eb0: mov             fp, SP
    // 0x844eb4: CheckStackOverflow
    //     0x844eb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x844eb8: cmp             SP, x16
    //     0x844ebc: b.ls            #0x844eec
    // 0x844ec0: ldr             x16, [fp, #0x28]
    // 0x844ec4: ldr             lr, [fp, #0x20]
    // 0x844ec8: stp             lr, x16, [SP, #-0x10]!
    // 0x844ecc: ldr             x16, [fp, #0x18]
    // 0x844ed0: ldr             lr, [fp, #0x10]
    // 0x844ed4: stp             lr, x16, [SP, #-0x10]!
    // 0x844ed8: r0 = _defaultToolbarBuilder()
    //     0x844ed8: bl              #0x844ef4  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] CupertinoTextSelectionToolbar::_defaultToolbarBuilder
    // 0x844edc: add             SP, SP, #0x20
    // 0x844ee0: LeaveFrame
    //     0x844ee0: mov             SP, fp
    //     0x844ee4: ldp             fp, lr, [SP], #0x10
    // 0x844ee8: ret
    //     0x844ee8: ret             
    // 0x844eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844ef0: b               #0x844ec0
  }
  static _ _defaultToolbarBuilder(/* No info */) {
    // ** addr: 0x844ef4, size: 0x60
    // 0x844ef4: EnterFrame
    //     0x844ef4: stp             fp, lr, [SP, #-0x10]!
    //     0x844ef8: mov             fp, SP
    // 0x844efc: AllocStack(0x8)
    //     0x844efc: sub             SP, SP, #8
    // 0x844f00: r0 = DecoratedBox()
    //     0x844f00: bl              #0x83fd18  ; AllocateDecoratedBoxStub -> DecoratedBox (size=0x18)
    // 0x844f04: mov             x1, x0
    // 0x844f08: r0 = Instance_BoxDecoration
    //     0x844f08: add             x0, PP, #0x28, lsl #12  ; [pp+0x28d60] Obj!BoxDecoration@b48cb1
    //     0x844f0c: ldr             x0, [x0, #0xd60]
    // 0x844f10: stur            x1, [fp, #-8]
    // 0x844f14: StoreField: r1->field_f = r0
    //     0x844f14: stur            w0, [x1, #0xf]
    // 0x844f18: r0 = Instance_DecorationPosition
    //     0x844f18: add             x0, PP, #0xf, lsl #12  ; [pp+0xf1b0] Obj!DecorationPosition@b648d1
    //     0x844f1c: ldr             x0, [x0, #0x1b0]
    // 0x844f20: StoreField: r1->field_13 = r0
    //     0x844f20: stur            w0, [x1, #0x13]
    // 0x844f24: ldr             x0, [fp, #0x10]
    // 0x844f28: StoreField: r1->field_b = r0
    //     0x844f28: stur            w0, [x1, #0xb]
    // 0x844f2c: r0 = _CupertinoTextSelectionToolbarShape()
    //     0x844f2c: bl              #0x844f54  ; Allocate_CupertinoTextSelectionToolbarShapeStub -> _CupertinoTextSelectionToolbarShape (size=0x18)
    // 0x844f30: ldr             x1, [fp, #0x20]
    // 0x844f34: StoreField: r0->field_f = r1
    //     0x844f34: stur            w1, [x0, #0xf]
    // 0x844f38: ldr             x1, [fp, #0x18]
    // 0x844f3c: StoreField: r0->field_13 = r1
    //     0x844f3c: stur            w1, [x0, #0x13]
    // 0x844f40: ldur            x1, [fp, #-8]
    // 0x844f44: StoreField: r0->field_b = r1
    //     0x844f44: stur            w1, [x0, #0xb]
    // 0x844f48: LeaveFrame
    //     0x844f48: mov             SP, fp
    //     0x844f4c: ldp             fp, lr, [SP], #0x10
    // 0x844f50: ret
    //     0x844f50: ret             
  }
  _ build(/* No info */) {
    // ** addr: 0xb1d090, size: 0x288
    // 0xb1d090: EnterFrame
    //     0xb1d090: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d094: mov             fp, SP
    // 0xb1d098: AllocStack(0x60)
    //     0xb1d098: sub             SP, SP, #0x60
    // 0xb1d09c: CheckStackOverflow
    //     0xb1d09c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d0a0: cmp             SP, x16
    //     0xb1d0a4: b.ls            #0xb1d310
    // 0xb1d0a8: ldr             x16, [fp, #0x10]
    // 0xb1d0ac: SaveReg r16
    //     0xb1d0ac: str             x16, [SP, #-8]!
    // 0xb1d0b0: r0 = of()
    //     0xb1d0b0: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb1d0b4: add             SP, SP, #8
    // 0xb1d0b8: LoadField: r1 = r0->field_23
    //     0xb1d0b8: ldur            w1, [x0, #0x23]
    // 0xb1d0bc: DecompressPointer r1
    //     0xb1d0bc: add             x1, x1, HEAP, lsl #32
    // 0xb1d0c0: LoadField: d0 = r1->field_f
    //     0xb1d0c0: ldur            d0, [x1, #0xf]
    // 0xb1d0c4: d1 = 8.000000
    //     0xb1d0c4: fmov            d1, #8.00000000
    // 0xb1d0c8: fadd            d2, d0, d1
    // 0xb1d0cc: stur            d2, [fp, #-0x60]
    // 0xb1d0d0: fadd            d0, d2, d1
    // 0xb1d0d4: d3 = 43.000000
    //     0xb1d0d4: add             x17, PP, #0x2e, lsl #12  ; [pp+0x2e9c8] IMM: double(43) from 0x4045800000000000
    //     0xb1d0d8: ldr             d3, [x17, #0x9c8]
    // 0xb1d0dc: fadd            d4, d0, d3
    // 0xb1d0e0: ldr             x2, [fp, #0x18]
    // 0xb1d0e4: LoadField: r3 = r2->field_b
    //     0xb1d0e4: ldur            w3, [x2, #0xb]
    // 0xb1d0e8: DecompressPointer r3
    //     0xb1d0e8: add             x3, x3, HEAP, lsl #32
    // 0xb1d0ec: LoadField: d0 = r3->field_f
    //     0xb1d0ec: ldur            d0, [x3, #0xf]
    // 0xb1d0f0: fcmp            d0, d4
    // 0xb1d0f4: b.vs            #0xb1d0fc
    // 0xb1d0f8: b.ge            #0xb1d104
    // 0xb1d0fc: r4 = false
    //     0xb1d0fc: add             x4, NULL, #0x30  ; false
    // 0xb1d100: b               #0xb1d108
    // 0xb1d104: r4 = true
    //     0xb1d104: add             x4, NULL, #0x20  ; true
    // 0xb1d108: stur            x4, [fp, #-8]
    // 0xb1d10c: LoadField: d3 = r1->field_7
    //     0xb1d10c: ldur            d3, [x1, #7]
    // 0xb1d110: d4 = 26.000000
    //     0xb1d110: fmov            d4, #26.00000000
    // 0xb1d114: fadd            d5, d4, d3
    // 0xb1d118: stur            d5, [fp, #-0x58]
    // 0xb1d11c: LoadField: r5 = r0->field_7
    //     0xb1d11c: ldur            w5, [x0, #7]
    // 0xb1d120: DecompressPointer r5
    //     0xb1d120: add             x5, x5, HEAP, lsl #32
    // 0xb1d124: LoadField: d3 = r5->field_7
    //     0xb1d124: ldur            d3, [x5, #7]
    // 0xb1d128: LoadField: d6 = r1->field_17
    //     0xb1d128: ldur            d6, [x1, #0x17]
    // 0xb1d12c: fsub            d7, d3, d6
    // 0xb1d130: fsub            d3, d7, d4
    // 0xb1d134: stur            d3, [fp, #-0x50]
    // 0xb1d138: LoadField: d4 = r3->field_7
    //     0xb1d138: ldur            d4, [x3, #7]
    // 0xb1d13c: fcmp            d4, d5
    // 0xb1d140: b.vs            #0xb1d150
    // 0xb1d144: b.ge            #0xb1d150
    // 0xb1d148: mov             v4.16b, v5.16b
    // 0xb1d14c: b               #0xb1d170
    // 0xb1d150: fcmp            d4, d3
    // 0xb1d154: b.vs            #0xb1d164
    // 0xb1d158: b.le            #0xb1d164
    // 0xb1d15c: mov             v4.16b, v3.16b
    // 0xb1d160: b               #0xb1d170
    // 0xb1d164: fcmp            d4, d4
    // 0xb1d168: b.vc            #0xb1d170
    // 0xb1d16c: mov             v4.16b, v3.16b
    // 0xb1d170: stur            d4, [fp, #-0x48]
    // 0xb1d174: fsub            d6, d0, d1
    // 0xb1d178: fsub            d0, d6, d2
    // 0xb1d17c: stur            d0, [fp, #-0x40]
    // 0xb1d180: r0 = Offset()
    //     0xb1d180: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb1d184: ldur            d0, [fp, #-0x48]
    // 0xb1d188: stur            x0, [fp, #-0x10]
    // 0xb1d18c: StoreField: r0->field_7 = d0
    //     0xb1d18c: stur            d0, [x0, #7]
    // 0xb1d190: ldur            d0, [fp, #-0x40]
    // 0xb1d194: StoreField: r0->field_f = d0
    //     0xb1d194: stur            d0, [x0, #0xf]
    // 0xb1d198: ldr             x1, [fp, #0x18]
    // 0xb1d19c: LoadField: r2 = r1->field_f
    //     0xb1d19c: ldur            w2, [x1, #0xf]
    // 0xb1d1a0: DecompressPointer r2
    //     0xb1d1a0: add             x2, x2, HEAP, lsl #32
    // 0xb1d1a4: LoadField: d0 = r2->field_7
    //     0xb1d1a4: ldur            d0, [x2, #7]
    // 0xb1d1a8: ldur            d1, [fp, #-0x58]
    // 0xb1d1ac: fcmp            d0, d1
    // 0xb1d1b0: b.vs            #0xb1d1c0
    // 0xb1d1b4: b.ge            #0xb1d1c0
    // 0xb1d1b8: mov             v2.16b, v1.16b
    // 0xb1d1bc: b               #0xb1d1ec
    // 0xb1d1c0: ldur            d1, [fp, #-0x50]
    // 0xb1d1c4: fcmp            d0, d1
    // 0xb1d1c8: b.vs            #0xb1d1d8
    // 0xb1d1cc: b.le            #0xb1d1d8
    // 0xb1d1d0: mov             v2.16b, v1.16b
    // 0xb1d1d4: b               #0xb1d1ec
    // 0xb1d1d8: fcmp            d0, d0
    // 0xb1d1dc: b.vc            #0xb1d1e8
    // 0xb1d1e0: mov             v2.16b, v1.16b
    // 0xb1d1e4: b               #0xb1d1ec
    // 0xb1d1e8: mov             v2.16b, v0.16b
    // 0xb1d1ec: ldur            d1, [fp, #-0x60]
    // 0xb1d1f0: ldur            x3, [fp, #-8]
    // 0xb1d1f4: d0 = 8.000000
    //     0xb1d1f4: fmov            d0, #8.00000000
    // 0xb1d1f8: stur            d2, [fp, #-0x48]
    // 0xb1d1fc: LoadField: d3 = r2->field_f
    //     0xb1d1fc: ldur            d3, [x2, #0xf]
    // 0xb1d200: fadd            d4, d3, d0
    // 0xb1d204: fsub            d3, d4, d1
    // 0xb1d208: stur            d3, [fp, #-0x40]
    // 0xb1d20c: r0 = Offset()
    //     0xb1d20c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xb1d210: ldur            d0, [fp, #-0x48]
    // 0xb1d214: stur            x0, [fp, #-0x18]
    // 0xb1d218: StoreField: r0->field_7 = d0
    //     0xb1d218: stur            d0, [x0, #7]
    // 0xb1d21c: ldur            d0, [fp, #-0x40]
    // 0xb1d220: StoreField: r0->field_f = d0
    //     0xb1d220: stur            d0, [x0, #0xf]
    // 0xb1d224: r0 = EdgeInsets()
    //     0xb1d224: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0xb1d228: d0 = 8.000000
    //     0xb1d228: fmov            d0, #8.00000000
    // 0xb1d22c: stur            x0, [fp, #-0x20]
    // 0xb1d230: StoreField: r0->field_7 = d0
    //     0xb1d230: stur            d0, [x0, #7]
    // 0xb1d234: ldur            d1, [fp, #-0x60]
    // 0xb1d238: StoreField: r0->field_f = d1
    //     0xb1d238: stur            d1, [x0, #0xf]
    // 0xb1d23c: StoreField: r0->field_17 = d0
    //     0xb1d23c: stur            d0, [x0, #0x17]
    // 0xb1d240: StoreField: r0->field_1f = d0
    //     0xb1d240: stur            d0, [x0, #0x1f]
    // 0xb1d244: r0 = TextSelectionToolbarLayoutDelegate()
    //     0xb1d244: bl              #0xb1d558  ; AllocateTextSelectionToolbarLayoutDelegateStub -> TextSelectionToolbarLayoutDelegate (size=0x18)
    // 0xb1d248: mov             x1, x0
    // 0xb1d24c: ldur            x0, [fp, #-0x10]
    // 0xb1d250: stur            x1, [fp, #-0x28]
    // 0xb1d254: StoreField: r1->field_b = r0
    //     0xb1d254: stur            w0, [x1, #0xb]
    // 0xb1d258: ldur            x2, [fp, #-0x18]
    // 0xb1d25c: StoreField: r1->field_f = r2
    //     0xb1d25c: stur            w2, [x1, #0xf]
    // 0xb1d260: ldur            x3, [fp, #-8]
    // 0xb1d264: StoreField: r1->field_13 = r3
    //     0xb1d264: stur            w3, [x1, #0x13]
    // 0xb1d268: tbnz            w3, #4, #0xb1d274
    // 0xb1d26c: mov             x4, x0
    // 0xb1d270: b               #0xb1d278
    // 0xb1d274: mov             x4, x2
    // 0xb1d278: ldr             x2, [fp, #0x18]
    // 0xb1d27c: ldur            x0, [fp, #-0x20]
    // 0xb1d280: stur            x4, [fp, #-0x18]
    // 0xb1d284: LoadField: r5 = r2->field_17
    //     0xb1d284: ldur            w5, [x2, #0x17]
    // 0xb1d288: DecompressPointer r5
    //     0xb1d288: add             x5, x5, HEAP, lsl #32
    // 0xb1d28c: stur            x5, [fp, #-0x10]
    // 0xb1d290: LoadField: r6 = r2->field_13
    //     0xb1d290: ldur            w6, [x2, #0x13]
    // 0xb1d294: DecompressPointer r6
    //     0xb1d294: add             x6, x6, HEAP, lsl #32
    // 0xb1d298: SaveReg r6
    //     0xb1d298: str             x6, [SP, #-8]!
    // 0xb1d29c: r0 = _addChildrenSpacers()
    //     0xb1d29c: bl              #0xb1d324  ; [package:flutter/src/cupertino/text_selection_toolbar.dart] CupertinoTextSelectionToolbar::_addChildrenSpacers
    // 0xb1d2a0: add             SP, SP, #8
    // 0xb1d2a4: stur            x0, [fp, #-0x30]
    // 0xb1d2a8: r0 = _CupertinoTextSelectionToolbarContent()
    //     0xb1d2a8: bl              #0xb1d318  ; Allocate_CupertinoTextSelectionToolbarContentStub -> _CupertinoTextSelectionToolbarContent (size=0x1c)
    // 0xb1d2ac: mov             x1, x0
    // 0xb1d2b0: ldur            x0, [fp, #-0x18]
    // 0xb1d2b4: stur            x1, [fp, #-0x38]
    // 0xb1d2b8: StoreField: r1->field_b = r0
    //     0xb1d2b8: stur            w0, [x1, #0xb]
    // 0xb1d2bc: ldur            x0, [fp, #-8]
    // 0xb1d2c0: StoreField: r1->field_13 = r0
    //     0xb1d2c0: stur            w0, [x1, #0x13]
    // 0xb1d2c4: ldur            x0, [fp, #-0x10]
    // 0xb1d2c8: StoreField: r1->field_17 = r0
    //     0xb1d2c8: stur            w0, [x1, #0x17]
    // 0xb1d2cc: ldur            x0, [fp, #-0x30]
    // 0xb1d2d0: StoreField: r1->field_f = r0
    //     0xb1d2d0: stur            w0, [x1, #0xf]
    // 0xb1d2d4: r0 = CustomSingleChildLayout()
    //     0xb1d2d4: bl              #0x847d64  ; AllocateCustomSingleChildLayoutStub -> CustomSingleChildLayout (size=0x14)
    // 0xb1d2d8: mov             x1, x0
    // 0xb1d2dc: ldur            x0, [fp, #-0x28]
    // 0xb1d2e0: stur            x1, [fp, #-8]
    // 0xb1d2e4: StoreField: r1->field_f = r0
    //     0xb1d2e4: stur            w0, [x1, #0xf]
    // 0xb1d2e8: ldur            x0, [fp, #-0x38]
    // 0xb1d2ec: StoreField: r1->field_b = r0
    //     0xb1d2ec: stur            w0, [x1, #0xb]
    // 0xb1d2f0: r0 = Padding()
    //     0xb1d2f0: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0xb1d2f4: ldur            x1, [fp, #-0x20]
    // 0xb1d2f8: StoreField: r0->field_f = r1
    //     0xb1d2f8: stur            w1, [x0, #0xf]
    // 0xb1d2fc: ldur            x1, [fp, #-8]
    // 0xb1d300: StoreField: r0->field_b = r1
    //     0xb1d300: stur            w1, [x0, #0xb]
    // 0xb1d304: LeaveFrame
    //     0xb1d304: mov             SP, fp
    //     0xb1d308: ldp             fp, lr, [SP], #0x10
    // 0xb1d30c: ret
    //     0xb1d30c: ret             
    // 0xb1d310: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d310: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d314: b               #0xb1d0a8
  }
  static _ _addChildrenSpacers(/* No info */) {
    // ** addr: 0xb1d324, size: 0x228
    // 0xb1d324: EnterFrame
    //     0xb1d324: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d328: mov             fp, SP
    // 0xb1d32c: AllocStack(0x28)
    //     0xb1d32c: sub             SP, SP, #0x28
    // 0xb1d330: CheckStackOverflow
    //     0xb1d330: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d334: cmp             SP, x16
    //     0xb1d338: b.ls            #0xb1d534
    // 0xb1d33c: r16 = <Widget>
    //     0xb1d33c: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0xb1d340: ldr             x16, [x16, #0xea8]
    // 0xb1d344: stp             xzr, x16, [SP, #-0x10]!
    // 0xb1d348: r0 = _GrowableList()
    //     0xb1d348: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xb1d34c: add             SP, SP, #0x10
    // 0xb1d350: mov             x1, x0
    // 0xb1d354: stur            x1, [fp, #-0x10]
    // 0xb1d358: r3 = 0
    //     0xb1d358: mov             x3, #0
    // 0xb1d35c: ldr             x2, [fp, #0x10]
    // 0xb1d360: stur            x3, [fp, #-8]
    // 0xb1d364: CheckStackOverflow
    //     0xb1d364: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d368: cmp             SP, x16
    //     0xb1d36c: b.ls            #0xb1d53c
    // 0xb1d370: r0 = LoadClassIdInstr(r2)
    //     0xb1d370: ldur            x0, [x2, #-1]
    //     0xb1d374: ubfx            x0, x0, #0xc, #0x14
    // 0xb1d378: SaveReg r2
    //     0xb1d378: str             x2, [SP, #-8]!
    // 0xb1d37c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xb1d37c: mov             x17, #0xb8ea
    //     0xb1d380: add             lr, x0, x17
    //     0xb1d384: ldr             lr, [x21, lr, lsl #3]
    //     0xb1d388: blr             lr
    // 0xb1d38c: add             SP, SP, #8
    // 0xb1d390: r1 = LoadInt32Instr(r0)
    //     0xb1d390: sbfx            x1, x0, #1, #0x1f
    // 0xb1d394: ldur            x2, [fp, #-8]
    // 0xb1d398: cmp             x2, x1
    // 0xb1d39c: b.ge            #0xb1d520
    // 0xb1d3a0: ldr             x3, [fp, #0x10]
    // 0xb1d3a4: r0 = BoxInt64Instr(r2)
    //     0xb1d3a4: sbfiz           x0, x2, #1, #0x1f
    //     0xb1d3a8: cmp             x2, x0, asr #1
    //     0xb1d3ac: b.eq            #0xb1d3b8
    //     0xb1d3b0: bl              #0xd69bb8
    //     0xb1d3b4: stur            x2, [x0, #7]
    // 0xb1d3b8: r1 = LoadClassIdInstr(r3)
    //     0xb1d3b8: ldur            x1, [x3, #-1]
    //     0xb1d3bc: ubfx            x1, x1, #0xc, #0x14
    // 0xb1d3c0: stp             x0, x3, [SP, #-0x10]!
    // 0xb1d3c4: mov             x0, x1
    // 0xb1d3c8: r0 = GDT[cid_x0 + -0xd83]()
    //     0xb1d3c8: sub             lr, x0, #0xd83
    //     0xb1d3cc: ldr             lr, [x21, lr, lsl #3]
    //     0xb1d3d0: blr             lr
    // 0xb1d3d4: add             SP, SP, #0x10
    // 0xb1d3d8: mov             x1, x0
    // 0xb1d3dc: ldur            x0, [fp, #-8]
    // 0xb1d3e0: stur            x1, [fp, #-0x20]
    // 0xb1d3e4: cbz             x0, #0xb1d484
    // 0xb1d3e8: ldur            x2, [fp, #-0x10]
    // 0xb1d3ec: LoadField: r3 = r2->field_b
    //     0xb1d3ec: ldur            w3, [x2, #0xb]
    // 0xb1d3f0: DecompressPointer r3
    //     0xb1d3f0: add             x3, x3, HEAP, lsl #32
    // 0xb1d3f4: stur            x3, [fp, #-0x18]
    // 0xb1d3f8: LoadField: r4 = r2->field_f
    //     0xb1d3f8: ldur            w4, [x2, #0xf]
    // 0xb1d3fc: DecompressPointer r4
    //     0xb1d3fc: add             x4, x4, HEAP, lsl #32
    // 0xb1d400: LoadField: r5 = r4->field_b
    //     0xb1d400: ldur            w5, [x4, #0xb]
    // 0xb1d404: DecompressPointer r5
    //     0xb1d404: add             x5, x5, HEAP, lsl #32
    // 0xb1d408: cmp             w3, w5
    // 0xb1d40c: b.ne            #0xb1d41c
    // 0xb1d410: SaveReg r2
    //     0xb1d410: str             x2, [SP, #-8]!
    // 0xb1d414: r0 = _growToNextCapacity()
    //     0xb1d414: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb1d418: add             SP, SP, #8
    // 0xb1d41c: ldur            x2, [fp, #-0x10]
    // 0xb1d420: ldur            x0, [fp, #-0x18]
    // 0xb1d424: r3 = LoadInt32Instr(r0)
    //     0xb1d424: sbfx            x3, x0, #1, #0x1f
    // 0xb1d428: stur            x3, [fp, #-0x28]
    // 0xb1d42c: add             x0, x3, #1
    // 0xb1d430: lsl             x1, x0, #1
    // 0xb1d434: StoreField: r2->field_b = r1
    //     0xb1d434: stur            w1, [x2, #0xb]
    // 0xb1d438: mov             x1, x3
    // 0xb1d43c: cmp             x1, x0
    // 0xb1d440: b.hs            #0xb1d544
    // 0xb1d444: LoadField: r1 = r2->field_f
    //     0xb1d444: ldur            w1, [x2, #0xf]
    // 0xb1d448: DecompressPointer r1
    //     0xb1d448: add             x1, x1, HEAP, lsl #32
    // 0xb1d44c: stur            x1, [fp, #-0x18]
    // 0xb1d450: r0 = _CupertinoToolbarButtonDivider()
    //     0xb1d450: bl              #0xb1d54c  ; Allocate_CupertinoToolbarButtonDividerStub -> _CupertinoToolbarButtonDivider (size=0xc)
    // 0xb1d454: ldur            x1, [fp, #-0x18]
    // 0xb1d458: ldur            x2, [fp, #-0x28]
    // 0xb1d45c: ArrayStore: r1[r2] = r0  ; List_4
    //     0xb1d45c: add             x25, x1, x2, lsl #2
    //     0xb1d460: add             x25, x25, #0xf
    //     0xb1d464: str             w0, [x25]
    //     0xb1d468: tbz             w0, #0, #0xb1d484
    //     0xb1d46c: ldurb           w16, [x1, #-1]
    //     0xb1d470: ldurb           w17, [x0, #-1]
    //     0xb1d474: and             x16, x17, x16, lsr #2
    //     0xb1d478: tst             x16, HEAP, lsr #32
    //     0xb1d47c: b.eq            #0xb1d484
    //     0xb1d480: bl              #0xd67e5c
    // 0xb1d484: ldur            x0, [fp, #-0x10]
    // 0xb1d488: LoadField: r1 = r0->field_b
    //     0xb1d488: ldur            w1, [x0, #0xb]
    // 0xb1d48c: DecompressPointer r1
    //     0xb1d48c: add             x1, x1, HEAP, lsl #32
    // 0xb1d490: stur            x1, [fp, #-0x18]
    // 0xb1d494: LoadField: r2 = r0->field_f
    //     0xb1d494: ldur            w2, [x0, #0xf]
    // 0xb1d498: DecompressPointer r2
    //     0xb1d498: add             x2, x2, HEAP, lsl #32
    // 0xb1d49c: LoadField: r3 = r2->field_b
    //     0xb1d49c: ldur            w3, [x2, #0xb]
    // 0xb1d4a0: DecompressPointer r3
    //     0xb1d4a0: add             x3, x3, HEAP, lsl #32
    // 0xb1d4a4: cmp             w1, w3
    // 0xb1d4a8: b.ne            #0xb1d4b8
    // 0xb1d4ac: SaveReg r0
    //     0xb1d4ac: str             x0, [SP, #-8]!
    // 0xb1d4b0: r0 = _growToNextCapacity()
    //     0xb1d4b0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0xb1d4b4: add             SP, SP, #8
    // 0xb1d4b8: ldur            x2, [fp, #-0x10]
    // 0xb1d4bc: ldur            x4, [fp, #-8]
    // 0xb1d4c0: ldur            x3, [fp, #-0x18]
    // 0xb1d4c4: r5 = LoadInt32Instr(r3)
    //     0xb1d4c4: sbfx            x5, x3, #1, #0x1f
    // 0xb1d4c8: add             x0, x5, #1
    // 0xb1d4cc: lsl             x3, x0, #1
    // 0xb1d4d0: StoreField: r2->field_b = r3
    //     0xb1d4d0: stur            w3, [x2, #0xb]
    // 0xb1d4d4: mov             x1, x5
    // 0xb1d4d8: cmp             x1, x0
    // 0xb1d4dc: b.hs            #0xb1d548
    // 0xb1d4e0: LoadField: r1 = r2->field_f
    //     0xb1d4e0: ldur            w1, [x2, #0xf]
    // 0xb1d4e4: DecompressPointer r1
    //     0xb1d4e4: add             x1, x1, HEAP, lsl #32
    // 0xb1d4e8: ldur            x0, [fp, #-0x20]
    // 0xb1d4ec: ArrayStore: r1[r5] = r0  ; List_4
    //     0xb1d4ec: add             x25, x1, x5, lsl #2
    //     0xb1d4f0: add             x25, x25, #0xf
    //     0xb1d4f4: str             w0, [x25]
    //     0xb1d4f8: tbz             w0, #0, #0xb1d514
    //     0xb1d4fc: ldurb           w16, [x1, #-1]
    //     0xb1d500: ldurb           w17, [x0, #-1]
    //     0xb1d504: and             x16, x17, x16, lsr #2
    //     0xb1d508: tst             x16, HEAP, lsr #32
    //     0xb1d50c: b.eq            #0xb1d514
    //     0xb1d510: bl              #0xd67e5c
    // 0xb1d514: add             x3, x4, #1
    // 0xb1d518: mov             x1, x2
    // 0xb1d51c: b               #0xb1d35c
    // 0xb1d520: ldur            x2, [fp, #-0x10]
    // 0xb1d524: mov             x0, x2
    // 0xb1d528: LeaveFrame
    //     0xb1d528: mov             SP, fp
    //     0xb1d52c: ldp             fp, lr, [SP], #0x10
    // 0xb1d530: ret
    //     0xb1d530: ret             
    // 0xb1d534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d538: b               #0xb1d33c
    // 0xb1d53c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d53c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d540: b               #0xb1d370
    // 0xb1d544: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1d544: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0xb1d548: r0 = RangeErrorSharedWithoutFPURegs()
    //     0xb1d548: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

// class id: 3869, size: 0xc, field offset: 0xc
class _CupertinoToolbarButtonDivider extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1d000, size: 0x90
    // 0xb1d000: EnterFrame
    //     0xb1d000: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d004: mov             fp, SP
    // 0xb1d008: AllocStack(0x8)
    //     0xb1d008: sub             SP, SP, #8
    // 0xb1d00c: CheckStackOverflow
    //     0xb1d00c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1d010: cmp             SP, x16
    //     0xb1d014: b.ls            #0xb1d078
    // 0xb1d018: ldr             x16, [fp, #0x10]
    // 0xb1d01c: SaveReg r16
    //     0xb1d01c: str             x16, [SP, #-8]!
    // 0xb1d020: r0 = of()
    //     0xb1d020: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0xb1d024: add             SP, SP, #8
    // 0xb1d028: LoadField: d0 = r0->field_b
    //     0xb1d028: ldur            d0, [x0, #0xb]
    // 0xb1d02c: d1 = 1.000000
    //     0xb1d02c: fmov            d1, #1.00000000
    // 0xb1d030: fdiv            d2, d1, d0
    // 0xb1d034: r0 = inline_Allocate_Double()
    //     0xb1d034: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xb1d038: add             x0, x0, #0x10
    //     0xb1d03c: cmp             x1, x0
    //     0xb1d040: b.ls            #0xb1d080
    //     0xb1d044: str             x0, [THR, #0x60]  ; THR::top
    //     0xb1d048: sub             x0, x0, #0xf
    //     0xb1d04c: mov             x1, #0xd108
    //     0xb1d050: movk            x1, #3, lsl #16
    //     0xb1d054: stur            x1, [x0, #-1]
    // 0xb1d058: StoreField: r0->field_7 = d2
    //     0xb1d058: stur            d2, [x0, #7]
    // 0xb1d05c: stur            x0, [fp, #-8]
    // 0xb1d060: r0 = SizedBox()
    //     0xb1d060: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xb1d064: ldur            x1, [fp, #-8]
    // 0xb1d068: StoreField: r0->field_f = r1
    //     0xb1d068: stur            w1, [x0, #0xf]
    // 0xb1d06c: LeaveFrame
    //     0xb1d06c: mov             SP, fp
    //     0xb1d070: ldp             fp, lr, [SP], #0x10
    // 0xb1d074: ret
    //     0xb1d074: ret             
    // 0xb1d078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1d078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1d07c: b               #0xb1d018
    // 0xb1d080: SaveReg d2
    //     0xb1d080: str             q2, [SP, #-0x10]!
    // 0xb1d084: r0 = AllocateDouble()
    //     0xb1d084: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xb1d088: RestoreReg d2
    //     0xb1d088: ldr             q2, [SP], #0x10
    // 0xb1d08c: b               #0xb1d058
  }
}

// class id: 4173, size: 0x1c, field offset: 0xc
//   const constructor, 
class _CupertinoTextSelectionToolbarContent extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40098, size: 0x30
    // 0xa40098: EnterFrame
    //     0xa40098: stp             fp, lr, [SP, #-0x10]!
    //     0xa4009c: mov             fp, SP
    // 0xa400a0: r1 = <_CupertinoTextSelectionToolbarContent>
    //     0xa400a0: add             x1, PP, #0x37, lsl #12  ; [pp+0x37be0] TypeArguments: <_CupertinoTextSelectionToolbarContent>
    //     0xa400a4: ldr             x1, [x1, #0xbe0]
    // 0xa400a8: r0 = _CupertinoTextSelectionToolbarContentState()
    //     0xa400a8: bl              #0xa400c8  ; Allocate_CupertinoTextSelectionToolbarContentStateStub -> _CupertinoTextSelectionToolbarContentState (size=0x2c)
    // 0xa400ac: r1 = Sentinel
    //     0xa400ac: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa400b0: StoreField: r0->field_1b = r1
    //     0xa400b0: stur            w1, [x0, #0x1b]
    // 0xa400b4: r1 = 0
    //     0xa400b4: mov             x1, #0
    // 0xa400b8: StoreField: r0->field_1f = r1
    //     0xa400b8: stur            x1, [x0, #0x1f]
    // 0xa400bc: LeaveFrame
    //     0xa400bc: mov             SP, fp
    //     0xa400c0: ldp             fp, lr, [SP], #0x10
    // 0xa400c4: ret
    //     0xa400c4: ret             
  }
}

// class id: 5986, size: 0x14, field offset: 0x14
enum _CupertinoTextSelectionToolbarItemsSlot extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15b78, size: 0x5c
    // 0xb15b78: EnterFrame
    //     0xb15b78: stp             fp, lr, [SP, #-0x10]!
    //     0xb15b7c: mov             fp, SP
    // 0xb15b80: CheckStackOverflow
    //     0xb15b80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15b84: cmp             SP, x16
    //     0xb15b88: b.ls            #0xb15bcc
    // 0xb15b8c: r1 = Null
    //     0xb15b8c: mov             x1, NULL
    // 0xb15b90: r2 = 4
    //     0xb15b90: mov             x2, #4
    // 0xb15b94: r0 = AllocateArray()
    //     0xb15b94: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15b98: r17 = "_CupertinoTextSelectionToolbarItemsSlot."
    //     0xb15b98: add             x17, PP, #0x53, lsl #12  ; [pp+0x532d8] "_CupertinoTextSelectionToolbarItemsSlot."
    //     0xb15b9c: ldr             x17, [x17, #0x2d8]
    // 0xb15ba0: StoreField: r0->field_f = r17
    //     0xb15ba0: stur            w17, [x0, #0xf]
    // 0xb15ba4: ldr             x1, [fp, #0x10]
    // 0xb15ba8: LoadField: r2 = r1->field_f
    //     0xb15ba8: ldur            w2, [x1, #0xf]
    // 0xb15bac: DecompressPointer r2
    //     0xb15bac: add             x2, x2, HEAP, lsl #32
    // 0xb15bb0: StoreField: r0->field_13 = r2
    //     0xb15bb0: stur            w2, [x0, #0x13]
    // 0xb15bb4: SaveReg r0
    //     0xb15bb4: str             x0, [SP, #-8]!
    // 0xb15bb8: r0 = _interpolate()
    //     0xb15bb8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15bbc: add             SP, SP, #8
    // 0xb15bc0: LeaveFrame
    //     0xb15bc0: mov             SP, fp
    //     0xb15bc4: ldp             fp, lr, [SP], #0x10
    // 0xb15bc8: ret
    //     0xb15bc8: ret             
    // 0xb15bcc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15bcc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15bd0: b               #0xb15b8c
  }
}

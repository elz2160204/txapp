// lib: , url: package:flutter/src/cupertino/thumb_painter.dart

// class id: 1049117, size: 0x8
class :: {
}

// class id: 2656, size: 0x10, field offset: 0x8
//   const constructor, 
class CupertinoThumbPainter extends Object {

  _ paint(/* No info */) {
    // ** addr: 0x65f380, size: 0x350
    // 0x65f380: EnterFrame
    //     0x65f380: stp             fp, lr, [SP, #-0x10]!
    //     0x65f384: mov             fp, SP
    // 0x65f388: AllocStack(0x40)
    //     0x65f388: sub             SP, SP, #0x40
    // 0x65f38c: CheckStackOverflow
    //     0x65f38c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65f390: cmp             SP, x16
    //     0x65f394: b.ls            #0x65f6bc
    // 0x65f398: ldr             x16, [fp, #0x10]
    // 0x65f39c: SaveReg r16
    //     0x65f39c: str             x16, [SP, #-8]!
    // 0x65f3a0: r0 = shortestSide()
    //     0x65f3a0: bl              #0x6603dc  ; [dart:ui] Rect::shortestSide
    // 0x65f3a4: add             SP, SP, #8
    // 0x65f3a8: mov             v1.16b, v0.16b
    // 0x65f3ac: d0 = 2.000000
    //     0x65f3ac: fmov            d0, #2.00000000
    // 0x65f3b0: fdiv            d2, d1, d0
    // 0x65f3b4: stur            d2, [fp, #-0x40]
    // 0x65f3b8: r0 = Radius()
    //     0x65f3b8: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0x65f3bc: ldur            d0, [fp, #-0x40]
    // 0x65f3c0: stur            x0, [fp, #-8]
    // 0x65f3c4: StoreField: r0->field_7 = d0
    //     0x65f3c4: stur            d0, [x0, #7]
    // 0x65f3c8: StoreField: r0->field_f = d0
    //     0x65f3c8: stur            d0, [x0, #0xf]
    // 0x65f3cc: r0 = RRect()
    //     0x65f3cc: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x65f3d0: stur            x0, [fp, #-0x10]
    // 0x65f3d4: ldr             x16, [fp, #0x10]
    // 0x65f3d8: stp             x16, x0, [SP, #-0x10]!
    // 0x65f3dc: ldur            x16, [fp, #-8]
    // 0x65f3e0: SaveReg r16
    //     0x65f3e0: str             x16, [SP, #-8]!
    // 0x65f3e4: r0 = RRect.fromRectAndRadius()
    //     0x65f3e4: bl              #0x660380  ; [dart:ui] RRect::RRect.fromRectAndRadius
    // 0x65f3e8: add             SP, SP, #0x18
    // 0x65f3ec: r3 = const [Instance of 'BoxShadow', Instance of 'BoxShadow', Instance of 'BoxShadow']
    //     0x65f3ec: add             x3, PP, #0x57, lsl #12  ; [pp+0x57518] List<BoxShadow>(3)
    //     0x65f3f0: ldr             x3, [x3, #0x518]
    // 0x65f3f4: LoadField: r4 = r3->field_7
    //     0x65f3f4: ldur            w4, [x3, #7]
    // 0x65f3f8: DecompressPointer r4
    //     0x65f3f8: add             x4, x4, HEAP, lsl #32
    // 0x65f3fc: stur            x4, [fp, #-0x30]
    // 0x65f400: r2 = 0
    //     0x65f400: mov             x2, #0
    // 0x65f404: d0 = 0.500000
    //     0x65f404: fmov            d0, #0.50000000
    // 0x65f408: CheckStackOverflow
    //     0x65f408: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65f40c: cmp             SP, x16
    //     0x65f410: b.ls            #0x65f6c4
    // 0x65f414: cmp             x2, #3
    // 0x65f418: b.lt            #0x65f510
    // 0x65f41c: ldur            x16, [fp, #-0x10]
    // 0x65f420: SaveReg r16
    //     0x65f420: str             x16, [SP, #-8]!
    // 0x65f424: SaveReg d0
    //     0x65f424: str             d0, [SP, #-8]!
    // 0x65f428: r0 = inflate()
    //     0x65f428: bl              #0x65ffe4  ; [dart:ui] RRect::inflate
    // 0x65f42c: add             SP, SP, #0x10
    // 0x65f430: stur            x0, [fp, #-8]
    // 0x65f434: r16 = 112
    //     0x65f434: mov             x16, #0x70
    // 0x65f438: stp             x16, NULL, [SP, #-0x10]!
    // 0x65f43c: r0 = ByteData()
    //     0x65f43c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65f440: add             SP, SP, #0x10
    // 0x65f444: stur            x0, [fp, #-0x18]
    // 0x65f448: r0 = Paint()
    //     0x65f448: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65f44c: mov             x1, x0
    // 0x65f450: ldur            x0, [fp, #-0x18]
    // 0x65f454: stur            x1, [fp, #-0x20]
    // 0x65f458: StoreField: r1->field_7 = r0
    //     0x65f458: stur            w0, [x1, #7]
    // 0x65f45c: LoadField: r2 = r0->field_17
    //     0x65f45c: ldur            w2, [x0, #0x17]
    // 0x65f460: DecompressPointer r2
    //     0x65f460: add             x2, x2, HEAP, lsl #32
    // 0x65f464: r16 = 8
    //     0x65f464: mov             x16, #8
    // 0x65f468: stp             x16, x2, [SP, #-0x10]!
    // 0x65f46c: r16 = 4110417920
    //     0x65f46c: add             x16, PP, #0x57, lsl #12  ; [pp+0x57520] 0xf5000000
    //     0x65f470: ldr             x16, [x16, #0x520]
    // 0x65f474: SaveReg r16
    //     0x65f474: str             x16, [SP, #-8]!
    // 0x65f478: r0 = _setInt32()
    //     0x65f478: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0x65f47c: add             SP, SP, #0x18
    // 0x65f480: ldr             x16, [fp, #0x18]
    // 0x65f484: ldur            lr, [fp, #-8]
    // 0x65f488: stp             lr, x16, [SP, #-0x10]!
    // 0x65f48c: ldur            x16, [fp, #-0x20]
    // 0x65f490: SaveReg r16
    //     0x65f490: str             x16, [SP, #-8]!
    // 0x65f494: r0 = drawRRect()
    //     0x65f494: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x65f498: add             SP, SP, #0x18
    // 0x65f49c: r16 = 112
    //     0x65f49c: mov             x16, #0x70
    // 0x65f4a0: stp             x16, NULL, [SP, #-0x10]!
    // 0x65f4a4: r0 = ByteData()
    //     0x65f4a4: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65f4a8: add             SP, SP, #0x10
    // 0x65f4ac: stur            x0, [fp, #-8]
    // 0x65f4b0: r0 = Paint()
    //     0x65f4b0: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65f4b4: mov             x1, x0
    // 0x65f4b8: ldur            x0, [fp, #-8]
    // 0x65f4bc: stur            x1, [fp, #-0x18]
    // 0x65f4c0: StoreField: r1->field_7 = r0
    //     0x65f4c0: stur            w0, [x1, #7]
    // 0x65f4c4: LoadField: r2 = r0->field_17
    //     0x65f4c4: ldur            w2, [x0, #0x17]
    // 0x65f4c8: DecompressPointer r2
    //     0x65f4c8: add             x2, x2, HEAP, lsl #32
    // 0x65f4cc: r16 = 8
    //     0x65f4cc: mov             x16, #8
    // 0x65f4d0: stp             x16, x2, [SP, #-0x10]!
    // 0x65f4d4: r16 = 33554430
    //     0x65f4d4: mov             x16, #0x1fffffe
    // 0x65f4d8: SaveReg r16
    //     0x65f4d8: str             x16, [SP, #-8]!
    // 0x65f4dc: r0 = _setInt32()
    //     0x65f4dc: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0x65f4e0: add             SP, SP, #0x18
    // 0x65f4e4: ldr             x16, [fp, #0x18]
    // 0x65f4e8: ldur            lr, [fp, #-0x10]
    // 0x65f4ec: stp             lr, x16, [SP, #-0x10]!
    // 0x65f4f0: ldur            x16, [fp, #-0x18]
    // 0x65f4f4: SaveReg r16
    //     0x65f4f4: str             x16, [SP, #-8]!
    // 0x65f4f8: r0 = drawRRect()
    //     0x65f4f8: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x65f4fc: add             SP, SP, #0x18
    // 0x65f500: r0 = Null
    //     0x65f500: mov             x0, NULL
    // 0x65f504: LeaveFrame
    //     0x65f504: mov             SP, fp
    //     0x65f508: ldp             fp, lr, [SP], #0x10
    // 0x65f50c: ret
    //     0x65f50c: ret             
    // 0x65f510: mov             x1, x2
    // 0x65f514: r0 = 3
    //     0x65f514: mov             x0, #3
    // 0x65f518: cmp             x1, x0
    // 0x65f51c: b.hs            #0x65f6cc
    // 0x65f520: ArrayLoad: r5 = r3[r2]  ; Unknown_4
    //     0x65f520: add             x16, x3, x2, lsl #2
    //     0x65f524: ldur            w5, [x16, #0xf]
    // 0x65f528: DecompressPointer r5
    //     0x65f528: add             x5, x5, HEAP, lsl #32
    // 0x65f52c: stur            x5, [fp, #-8]
    // 0x65f530: add             x6, x2, #1
    // 0x65f534: stur            x6, [fp, #-0x28]
    // 0x65f538: cmp             w5, NULL
    // 0x65f53c: b.ne            #0x65f570
    // 0x65f540: mov             x0, x5
    // 0x65f544: mov             x2, x4
    // 0x65f548: r1 = Null
    //     0x65f548: mov             x1, NULL
    // 0x65f54c: cmp             w2, NULL
    // 0x65f550: b.eq            #0x65f570
    // 0x65f554: LoadField: r4 = r2->field_17
    //     0x65f554: ldur            w4, [x2, #0x17]
    // 0x65f558: DecompressPointer r4
    //     0x65f558: add             x4, x4, HEAP, lsl #32
    // 0x65f55c: r8 = X0
    //     0x65f55c: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x65f560: LoadField: r9 = r4->field_7
    //     0x65f560: ldur            x9, [x4, #7]
    // 0x65f564: r3 = Null
    //     0x65f564: add             x3, PP, #0x57, lsl #12  ; [pp+0x57528] Null
    //     0x65f568: ldr             x3, [x3, #0x528]
    // 0x65f56c: blr             x9
    // 0x65f570: ldur            x0, [fp, #-8]
    // 0x65f574: LoadField: r1 = r0->field_b
    //     0x65f574: ldur            w1, [x0, #0xb]
    // 0x65f578: DecompressPointer r1
    //     0x65f578: add             x1, x1, HEAP, lsl #32
    // 0x65f57c: ldur            x16, [fp, #-0x10]
    // 0x65f580: stp             x1, x16, [SP, #-0x10]!
    // 0x65f584: r0 = shift()
    //     0x65f584: bl              #0x65fe90  ; [dart:ui] RRect::shift
    // 0x65f588: add             SP, SP, #0x10
    // 0x65f58c: stur            x0, [fp, #-0x18]
    // 0x65f590: r16 = 112
    //     0x65f590: mov             x16, #0x70
    // 0x65f594: stp             x16, NULL, [SP, #-0x10]!
    // 0x65f598: r0 = ByteData()
    //     0x65f598: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65f59c: add             SP, SP, #0x10
    // 0x65f5a0: stur            x0, [fp, #-0x20]
    // 0x65f5a4: r0 = Paint()
    //     0x65f5a4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65f5a8: mov             x3, x0
    // 0x65f5ac: ldur            x2, [fp, #-0x20]
    // 0x65f5b0: stur            x3, [fp, #-0x38]
    // 0x65f5b4: StoreField: r3->field_7 = r2
    //     0x65f5b4: stur            w2, [x3, #7]
    // 0x65f5b8: ldur            x4, [fp, #-8]
    // 0x65f5bc: LoadField: r0 = r4->field_7
    //     0x65f5bc: ldur            w0, [x4, #7]
    // 0x65f5c0: DecompressPointer r0
    //     0x65f5c0: add             x0, x0, HEAP, lsl #32
    // 0x65f5c4: LoadField: r1 = r0->field_7
    //     0x65f5c4: ldur            x1, [x0, #7]
    // 0x65f5c8: eor             x5, x1, #0xff000000
    // 0x65f5cc: LoadField: r6 = r2->field_17
    //     0x65f5cc: ldur            w6, [x2, #0x17]
    // 0x65f5d0: DecompressPointer r6
    //     0x65f5d0: add             x6, x6, HEAP, lsl #32
    // 0x65f5d4: r0 = BoxInt64Instr(r5)
    //     0x65f5d4: sbfiz           x0, x5, #1, #0x1f
    //     0x65f5d8: cmp             x5, x0, asr #1
    //     0x65f5dc: b.eq            #0x65f5e8
    //     0x65f5e0: bl              #0xd69bb8
    //     0x65f5e4: stur            x5, [x0, #7]
    // 0x65f5e8: r16 = 8
    //     0x65f5e8: mov             x16, #8
    // 0x65f5ec: stp             x16, x6, [SP, #-0x10]!
    // 0x65f5f0: SaveReg r0
    //     0x65f5f0: str             x0, [SP, #-8]!
    // 0x65f5f4: r0 = _setInt32()
    //     0x65f5f4: bl              #0x65ff8c  ; [dart:typed_data] _TypedList::_setInt32
    // 0x65f5f8: add             SP, SP, #0x18
    // 0x65f5fc: ldur            x0, [fp, #-8]
    // 0x65f600: LoadField: d0 = r0->field_f
    //     0x65f600: ldur            d0, [x0, #0xf]
    // 0x65f604: d1 = 0.000000
    //     0x65f604: eor             v1.16b, v1.16b, v1.16b
    // 0x65f608: fcmp            d0, d1
    // 0x65f60c: b.vs            #0x65f62c
    // 0x65f610: b.le            #0x65f62c
    // 0x65f614: d3 = 0.500000
    //     0x65f614: fmov            d3, #0.50000000
    // 0x65f618: d2 = 0.577350
    //     0x65f618: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f4f0] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    //     0x65f61c: ldr             d2, [x17, #0x4f0]
    // 0x65f620: fmul            d4, d0, d2
    // 0x65f624: fadd            d0, d4, d3
    // 0x65f628: b               #0x65f63c
    // 0x65f62c: d3 = 0.500000
    //     0x65f62c: fmov            d3, #0.50000000
    // 0x65f630: d2 = 0.577350
    //     0x65f630: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1f4f0] IMM: double(0.57735) from 0x3fe279a6b50b0f28
    //     0x65f634: ldr             d2, [x17, #0x4f0]
    // 0x65f638: d0 = 0.000000
    //     0x65f638: eor             v0.16b, v0.16b, v0.16b
    // 0x65f63c: ldur            x0, [fp, #-0x38]
    // 0x65f640: stur            d0, [fp, #-0x40]
    // 0x65f644: r0 = MaskFilter()
    //     0x65f644: bl              #0x65fe84  ; AllocateMaskFilterStub -> MaskFilter (size=0x14)
    // 0x65f648: mov             x1, x0
    // 0x65f64c: r0 = Instance_BlurStyle
    //     0x65f64c: add             x0, PP, #0x33, lsl #12  ; [pp+0x33660] Obj!BlurStyle@b675d1
    //     0x65f650: ldr             x0, [x0, #0x660]
    // 0x65f654: StoreField: r1->field_7 = r0
    //     0x65f654: stur            w0, [x1, #7]
    // 0x65f658: ldur            d0, [fp, #-0x40]
    // 0x65f65c: StoreField: r1->field_b = d0
    //     0x65f65c: stur            d0, [x1, #0xb]
    // 0x65f660: ldur            x16, [fp, #-0x38]
    // 0x65f664: stp             x1, x16, [SP, #-0x10]!
    // 0x65f668: r0 = maskFilter=()
    //     0x65f668: bl              #0x65fbb8  ; [dart:ui] Paint::maskFilter=
    // 0x65f66c: add             SP, SP, #0x10
    // 0x65f670: ldur            x16, [fp, #-0x18]
    // 0x65f674: SaveReg r16
    //     0x65f674: str             x16, [SP, #-8]!
    // 0x65f678: r0 = _getValue32()
    //     0x65f678: bl              #0x65faf8  ; [dart:ui] RRect::_getValue32
    // 0x65f67c: add             SP, SP, #8
    // 0x65f680: mov             x1, x0
    // 0x65f684: ldur            x0, [fp, #-0x38]
    // 0x65f688: LoadField: r2 = r0->field_b
    //     0x65f688: ldur            w2, [x0, #0xb]
    // 0x65f68c: DecompressPointer r2
    //     0x65f68c: add             x2, x2, HEAP, lsl #32
    // 0x65f690: ldr             x16, [fp, #0x18]
    // 0x65f694: stp             x1, x16, [SP, #-0x10]!
    // 0x65f698: ldur            x16, [fp, #-0x20]
    // 0x65f69c: stp             x16, x2, [SP, #-0x10]!
    // 0x65f6a0: r0 = _drawRRect()
    //     0x65f6a0: bl              #0x65f7b8  ; [dart:ui] Canvas::_drawRRect
    // 0x65f6a4: add             SP, SP, #0x20
    // 0x65f6a8: ldur            x2, [fp, #-0x28]
    // 0x65f6ac: ldur            x4, [fp, #-0x30]
    // 0x65f6b0: r3 = const [Instance of 'BoxShadow', Instance of 'BoxShadow', Instance of 'BoxShadow']
    //     0x65f6b0: add             x3, PP, #0x57, lsl #12  ; [pp+0x57518] List<BoxShadow>(3)
    //     0x65f6b4: ldr             x3, [x3, #0x518]
    // 0x65f6b8: b               #0x65f404
    // 0x65f6bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65f6bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65f6c0: b               #0x65f398
    // 0x65f6c4: r0 = StackOverflowSharedWithFPURegs()
    //     0x65f6c4: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65f6c8: b               #0x65f414
    // 0x65f6cc: r0 = RangeErrorSharedWithFPURegs()
    //     0x65f6cc: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
  }
}

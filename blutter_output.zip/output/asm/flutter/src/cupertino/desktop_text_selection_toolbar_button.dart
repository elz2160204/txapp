// lib: , url: package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart

// class id: 1049086, size: 0x8
class :: {
}

// class id: 3356, size: 0x18, field offset: 0x14
class _CupertinoDesktopTextSelectionToolbarButtonState extends State<CupertinoDesktopTextSelectionToolbarButton> {

  _ build(/* No info */) {
    // ** addr: 0x840cb4, size: 0x22c
    // 0x840cb4: EnterFrame
    //     0x840cb4: stp             fp, lr, [SP, #-0x10]!
    //     0x840cb8: mov             fp, SP
    // 0x840cbc: AllocStack(0x30)
    //     0x840cbc: sub             SP, SP, #0x30
    // 0x840cc0: CheckStackOverflow
    //     0x840cc0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840cc4: cmp             SP, x16
    //     0x840cc8: b.ls            #0x840ed0
    // 0x840ccc: ldr             x0, [fp, #0x18]
    // 0x840cd0: LoadField: r1 = r0->field_b
    //     0x840cd0: ldur            w1, [x0, #0xb]
    // 0x840cd4: DecompressPointer r1
    //     0x840cd4: add             x1, x1, HEAP, lsl #32
    // 0x840cd8: cmp             w1, NULL
    // 0x840cdc: b.eq            #0x840ed8
    // 0x840ce0: LoadField: r2 = r1->field_f
    //     0x840ce0: ldur            w2, [x1, #0xf]
    // 0x840ce4: DecompressPointer r2
    //     0x840ce4: add             x2, x2, HEAP, lsl #32
    // 0x840ce8: stur            x2, [fp, #-8]
    // 0x840cec: r1 = 1
    //     0x840cec: mov             x1, #1
    // 0x840cf0: r0 = AllocateContext()
    //     0x840cf0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x840cf4: mov             x1, x0
    // 0x840cf8: ldr             x0, [fp, #0x18]
    // 0x840cfc: stur            x1, [fp, #-0x10]
    // 0x840d00: StoreField: r1->field_f = r0
    //     0x840d00: stur            w0, [x1, #0xf]
    // 0x840d04: r1 = 1
    //     0x840d04: mov             x1, #1
    // 0x840d08: r0 = AllocateContext()
    //     0x840d08: bl              #0xd68aa4  ; AllocateContextStub
    // 0x840d0c: mov             x1, x0
    // 0x840d10: ldr             x0, [fp, #0x18]
    // 0x840d14: stur            x1, [fp, #-0x18]
    // 0x840d18: StoreField: r1->field_f = r0
    //     0x840d18: stur            w0, [x1, #0xf]
    // 0x840d1c: LoadField: r2 = r0->field_13
    //     0x840d1c: ldur            w2, [x0, #0x13]
    // 0x840d20: DecompressPointer r2
    //     0x840d20: add             x2, x2, HEAP, lsl #32
    // 0x840d24: tbnz            w2, #4, #0x840dc0
    // 0x840d28: ldr             x16, [fp, #0x10]
    // 0x840d2c: SaveReg r16
    //     0x840d2c: str             x16, [SP, #-8]!
    // 0x840d30: r0 = of()
    //     0x840d30: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x840d34: add             SP, SP, #8
    // 0x840d38: r1 = LoadClassIdInstr(r0)
    //     0x840d38: ldur            x1, [x0, #-1]
    //     0x840d3c: ubfx            x1, x1, #0xc, #0x14
    // 0x840d40: lsl             x1, x1, #1
    // 0x840d44: r17 = 5322
    //     0x840d44: mov             x17, #0x14ca
    // 0x840d48: cmp             w1, w17
    // 0x840d4c: b.ne            #0x840d7c
    // 0x840d50: LoadField: r1 = r0->field_b
    //     0x840d50: ldur            w1, [x0, #0xb]
    // 0x840d54: DecompressPointer r1
    //     0x840d54: add             x1, x1, HEAP, lsl #32
    // 0x840d58: cmp             w1, NULL
    // 0x840d5c: b.ne            #0x840d74
    // 0x840d60: LoadField: r1 = r0->field_1f
    //     0x840d60: ldur            w1, [x0, #0x1f]
    // 0x840d64: DecompressPointer r1
    //     0x840d64: add             x1, x1, HEAP, lsl #32
    // 0x840d68: LoadField: r0 = r1->field_b
    //     0x840d68: ldur            w0, [x1, #0xb]
    // 0x840d6c: DecompressPointer r0
    //     0x840d6c: add             x0, x0, HEAP, lsl #32
    // 0x840d70: b               #0x840db8
    // 0x840d74: mov             x0, x1
    // 0x840d78: b               #0x840db8
    // 0x840d7c: LoadField: r1 = r0->field_27
    //     0x840d7c: ldur            w1, [x0, #0x27]
    // 0x840d80: DecompressPointer r1
    //     0x840d80: add             x1, x1, HEAP, lsl #32
    // 0x840d84: LoadField: r2 = r1->field_b
    //     0x840d84: ldur            w2, [x1, #0xb]
    // 0x840d88: DecompressPointer r2
    //     0x840d88: add             x2, x2, HEAP, lsl #32
    // 0x840d8c: cmp             w2, NULL
    // 0x840d90: b.ne            #0x840db4
    // 0x840d94: LoadField: r1 = r0->field_23
    //     0x840d94: ldur            w1, [x0, #0x23]
    // 0x840d98: DecompressPointer r1
    //     0x840d98: add             x1, x1, HEAP, lsl #32
    // 0x840d9c: LoadField: r0 = r1->field_3f
    //     0x840d9c: ldur            w0, [x1, #0x3f]
    // 0x840da0: DecompressPointer r0
    //     0x840da0: add             x0, x0, HEAP, lsl #32
    // 0x840da4: LoadField: r1 = r0->field_b
    //     0x840da4: ldur            w1, [x0, #0xb]
    // 0x840da8: DecompressPointer r1
    //     0x840da8: add             x1, x1, HEAP, lsl #32
    // 0x840dac: mov             x0, x1
    // 0x840db0: b               #0x840db8
    // 0x840db4: mov             x0, x2
    // 0x840db8: mov             x2, x0
    // 0x840dbc: b               #0x840dc4
    // 0x840dc0: r2 = Null
    //     0x840dc0: mov             x2, NULL
    // 0x840dc4: ldr             x0, [fp, #0x18]
    // 0x840dc8: ldur            x1, [fp, #-8]
    // 0x840dcc: stur            x2, [fp, #-0x28]
    // 0x840dd0: LoadField: r3 = r0->field_b
    //     0x840dd0: ldur            w3, [x0, #0xb]
    // 0x840dd4: DecompressPointer r3
    //     0x840dd4: add             x3, x3, HEAP, lsl #32
    // 0x840dd8: cmp             w3, NULL
    // 0x840ddc: b.eq            #0x840edc
    // 0x840de0: LoadField: r0 = r3->field_b
    //     0x840de0: ldur            w0, [x3, #0xb]
    // 0x840de4: DecompressPointer r0
    //     0x840de4: add             x0, x0, HEAP, lsl #32
    // 0x840de8: stur            x0, [fp, #-0x20]
    // 0x840dec: r0 = CupertinoButton()
    //     0x840dec: bl              #0x840ee0  ; AllocateCupertinoButtonStub -> CupertinoButton (size=0x3c)
    // 0x840df0: mov             x3, x0
    // 0x840df4: ldur            x0, [fp, #-8]
    // 0x840df8: stur            x3, [fp, #-0x30]
    // 0x840dfc: StoreField: r3->field_b = r0
    //     0x840dfc: stur            w0, [x3, #0xb]
    // 0x840e00: r0 = Instance_EdgeInsets
    //     0x840e00: add             x0, PP, #0x2e, lsl #12  ; [pp+0x2e598] Obj!EdgeInsets@b35c91
    //     0x840e04: ldr             x0, [x0, #0x598]
    // 0x840e08: StoreField: r3->field_f = r0
    //     0x840e08: stur            w0, [x3, #0xf]
    // 0x840e0c: ldur            x0, [fp, #-0x28]
    // 0x840e10: StoreField: r3->field_13 = r0
    //     0x840e10: stur            w0, [x3, #0x13]
    // 0x840e14: r0 = Instance_CupertinoDynamicColor
    //     0x840e14: add             x0, PP, #0x37, lsl #12  ; [pp+0x37cd0] Obj!CupertinoDynamicColor@b5e6f1
    //     0x840e18: ldr             x0, [x0, #0xcd0]
    // 0x840e1c: StoreField: r3->field_17 = r0
    //     0x840e1c: stur            w0, [x3, #0x17]
    // 0x840e20: d0 = 0.000000
    //     0x840e20: eor             v0.16b, v0.16b, v0.16b
    // 0x840e24: StoreField: r3->field_1f = d0
    //     0x840e24: stur            d0, [x3, #0x1f]
    // 0x840e28: d0 = 0.700000
    //     0x840e28: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c2f0] IMM: double(0.7) from 0x3fe6666666666666
    //     0x840e2c: ldr             d0, [x17, #0x2f0]
    // 0x840e30: StoreField: r3->field_27 = d0
    //     0x840e30: stur            d0, [x3, #0x27]
    // 0x840e34: r0 = Instance_Alignment
    //     0x840e34: add             x0, PP, #0x26, lsl #12  ; [pp+0x26fb8] Obj!Alignment@b37b51
    //     0x840e38: ldr             x0, [x0, #0xfb8]
    // 0x840e3c: StoreField: r3->field_33 = r0
    //     0x840e3c: stur            w0, [x3, #0x33]
    // 0x840e40: ldur            x0, [fp, #-0x20]
    // 0x840e44: StoreField: r3->field_1b = r0
    //     0x840e44: stur            w0, [x3, #0x1b]
    // 0x840e48: r0 = false
    //     0x840e48: add             x0, NULL, #0x30  ; false
    // 0x840e4c: StoreField: r3->field_37 = r0
    //     0x840e4c: stur            w0, [x3, #0x37]
    // 0x840e50: ldur            x2, [fp, #-0x10]
    // 0x840e54: r1 = Function '_onEnter@594085015':.
    //     0x840e54: add             x1, PP, #0x37, lsl #12  ; [pp+0x37cd8] AnonymousClosure: (0x840fbc), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onEnter (0x841008)
    //     0x840e58: ldr             x1, [x1, #0xcd8]
    // 0x840e5c: r0 = AllocateClosure()
    //     0x840e5c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x840e60: stur            x0, [fp, #-8]
    // 0x840e64: r0 = MouseRegion()
    //     0x840e64: bl              #0x834678  ; AllocateMouseRegionStub -> MouseRegion (size=0x28)
    // 0x840e68: mov             x3, x0
    // 0x840e6c: ldur            x0, [fp, #-8]
    // 0x840e70: stur            x3, [fp, #-0x10]
    // 0x840e74: StoreField: r3->field_f = r0
    //     0x840e74: stur            w0, [x3, #0xf]
    // 0x840e78: ldur            x2, [fp, #-0x18]
    // 0x840e7c: r1 = Function '_onExit@594085015':.
    //     0x840e7c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ce0] AnonymousClosure: (0x840eec), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onExit (0x840f38)
    //     0x840e80: ldr             x1, [x1, #0xce0]
    // 0x840e84: r0 = AllocateClosure()
    //     0x840e84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x840e88: mov             x1, x0
    // 0x840e8c: ldur            x0, [fp, #-0x10]
    // 0x840e90: StoreField: r0->field_17 = r1
    //     0x840e90: stur            w1, [x0, #0x17]
    // 0x840e94: r1 = Instance__DeferringMouseCursor
    //     0x840e94: ldr             x1, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x840e98: StoreField: r0->field_1b = r1
    //     0x840e98: stur            w1, [x0, #0x1b]
    // 0x840e9c: r1 = true
    //     0x840e9c: add             x1, NULL, #0x20  ; true
    // 0x840ea0: StoreField: r0->field_1f = r1
    //     0x840ea0: stur            w1, [x0, #0x1f]
    // 0x840ea4: ldur            x1, [fp, #-0x30]
    // 0x840ea8: StoreField: r0->field_b = r1
    //     0x840ea8: stur            w1, [x0, #0xb]
    // 0x840eac: r0 = SizedBox()
    //     0x840eac: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x840eb0: r1 = inf
    //     0x840eb0: add             x1, PP, #0xf, lsl #12  ; [pp+0xf218] inf
    //     0x840eb4: ldr             x1, [x1, #0x218]
    // 0x840eb8: StoreField: r0->field_f = r1
    //     0x840eb8: stur            w1, [x0, #0xf]
    // 0x840ebc: ldur            x1, [fp, #-0x10]
    // 0x840ec0: StoreField: r0->field_b = r1
    //     0x840ec0: stur            w1, [x0, #0xb]
    // 0x840ec4: LeaveFrame
    //     0x840ec4: mov             SP, fp
    //     0x840ec8: ldp             fp, lr, [SP], #0x10
    // 0x840ecc: ret
    //     0x840ecc: ret             
    // 0x840ed0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840ed0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840ed4: b               #0x840ccc
    // 0x840ed8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840ed8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840edc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840edc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onExit(dynamic, PointerExitEvent) {
    // ** addr: 0x840eec, size: 0x4c
    // 0x840eec: EnterFrame
    //     0x840eec: stp             fp, lr, [SP, #-0x10]!
    //     0x840ef0: mov             fp, SP
    // 0x840ef4: ldr             x0, [fp, #0x18]
    // 0x840ef8: LoadField: r1 = r0->field_17
    //     0x840ef8: ldur            w1, [x0, #0x17]
    // 0x840efc: DecompressPointer r1
    //     0x840efc: add             x1, x1, HEAP, lsl #32
    // 0x840f00: CheckStackOverflow
    //     0x840f00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840f04: cmp             SP, x16
    //     0x840f08: b.ls            #0x840f30
    // 0x840f0c: LoadField: r0 = r1->field_f
    //     0x840f0c: ldur            w0, [x1, #0xf]
    // 0x840f10: DecompressPointer r0
    //     0x840f10: add             x0, x0, HEAP, lsl #32
    // 0x840f14: ldr             x16, [fp, #0x10]
    // 0x840f18: stp             x16, x0, [SP, #-0x10]!
    // 0x840f1c: r0 = _onExit()
    //     0x840f1c: bl              #0x840f38  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onExit
    // 0x840f20: add             SP, SP, #0x10
    // 0x840f24: LeaveFrame
    //     0x840f24: mov             SP, fp
    //     0x840f28: ldp             fp, lr, [SP], #0x10
    // 0x840f2c: ret
    //     0x840f2c: ret             
    // 0x840f30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840f30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840f34: b               #0x840f0c
  }
  _ _onExit(/* No info */) {
    // ** addr: 0x840f38, size: 0x60
    // 0x840f38: EnterFrame
    //     0x840f38: stp             fp, lr, [SP, #-0x10]!
    //     0x840f3c: mov             fp, SP
    // 0x840f40: CheckStackOverflow
    //     0x840f40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840f44: cmp             SP, x16
    //     0x840f48: b.ls            #0x840f90
    // 0x840f4c: r1 = 1
    //     0x840f4c: mov             x1, #1
    // 0x840f50: r0 = AllocateContext()
    //     0x840f50: bl              #0xd68aa4  ; AllocateContextStub
    // 0x840f54: mov             x1, x0
    // 0x840f58: ldr             x0, [fp, #0x18]
    // 0x840f5c: StoreField: r1->field_f = r0
    //     0x840f5c: stur            w0, [x1, #0xf]
    // 0x840f60: mov             x2, x1
    // 0x840f64: r1 = Function '<anonymous closure>':.
    //     0x840f64: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ce8] AnonymousClosure: (0x840f98), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onExit (0x840f38)
    //     0x840f68: ldr             x1, [x1, #0xce8]
    // 0x840f6c: r0 = AllocateClosure()
    //     0x840f6c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x840f70: ldr             x16, [fp, #0x18]
    // 0x840f74: stp             x0, x16, [SP, #-0x10]!
    // 0x840f78: r0 = setState()
    //     0x840f78: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x840f7c: add             SP, SP, #0x10
    // 0x840f80: r0 = Null
    //     0x840f80: mov             x0, NULL
    // 0x840f84: LeaveFrame
    //     0x840f84: mov             SP, fp
    //     0x840f88: ldp             fp, lr, [SP], #0x10
    // 0x840f8c: ret
    //     0x840f8c: ret             
    // 0x840f90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840f90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840f94: b               #0x840f4c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x840f98, size: 0x24
    // 0x840f98: r1 = false
    //     0x840f98: add             x1, NULL, #0x30  ; false
    // 0x840f9c: ldr             x2, [SP]
    // 0x840fa0: LoadField: r3 = r2->field_17
    //     0x840fa0: ldur            w3, [x2, #0x17]
    // 0x840fa4: DecompressPointer r3
    //     0x840fa4: add             x3, x3, HEAP, lsl #32
    // 0x840fa8: LoadField: r2 = r3->field_f
    //     0x840fa8: ldur            w2, [x3, #0xf]
    // 0x840fac: DecompressPointer r2
    //     0x840fac: add             x2, x2, HEAP, lsl #32
    // 0x840fb0: StoreField: r2->field_13 = r1
    //     0x840fb0: stur            w1, [x2, #0x13]
    // 0x840fb4: r0 = Null
    //     0x840fb4: mov             x0, NULL
    // 0x840fb8: ret
    //     0x840fb8: ret             
  }
  [closure] void _onEnter(dynamic, PointerEnterEvent) {
    // ** addr: 0x840fbc, size: 0x4c
    // 0x840fbc: EnterFrame
    //     0x840fbc: stp             fp, lr, [SP, #-0x10]!
    //     0x840fc0: mov             fp, SP
    // 0x840fc4: ldr             x0, [fp, #0x18]
    // 0x840fc8: LoadField: r1 = r0->field_17
    //     0x840fc8: ldur            w1, [x0, #0x17]
    // 0x840fcc: DecompressPointer r1
    //     0x840fcc: add             x1, x1, HEAP, lsl #32
    // 0x840fd0: CheckStackOverflow
    //     0x840fd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840fd4: cmp             SP, x16
    //     0x840fd8: b.ls            #0x841000
    // 0x840fdc: LoadField: r0 = r1->field_f
    //     0x840fdc: ldur            w0, [x1, #0xf]
    // 0x840fe0: DecompressPointer r0
    //     0x840fe0: add             x0, x0, HEAP, lsl #32
    // 0x840fe4: ldr             x16, [fp, #0x10]
    // 0x840fe8: stp             x16, x0, [SP, #-0x10]!
    // 0x840fec: r0 = _onEnter()
    //     0x840fec: bl              #0x841008  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onEnter
    // 0x840ff0: add             SP, SP, #0x10
    // 0x840ff4: LeaveFrame
    //     0x840ff4: mov             SP, fp
    //     0x840ff8: ldp             fp, lr, [SP], #0x10
    // 0x840ffc: ret
    //     0x840ffc: ret             
    // 0x841000: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x841000: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841004: b               #0x840fdc
  }
  _ _onEnter(/* No info */) {
    // ** addr: 0x841008, size: 0x60
    // 0x841008: EnterFrame
    //     0x841008: stp             fp, lr, [SP, #-0x10]!
    //     0x84100c: mov             fp, SP
    // 0x841010: CheckStackOverflow
    //     0x841010: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x841014: cmp             SP, x16
    //     0x841018: b.ls            #0x841060
    // 0x84101c: r1 = 1
    //     0x84101c: mov             x1, #1
    // 0x841020: r0 = AllocateContext()
    //     0x841020: bl              #0xd68aa4  ; AllocateContextStub
    // 0x841024: mov             x1, x0
    // 0x841028: ldr             x0, [fp, #0x18]
    // 0x84102c: StoreField: r1->field_f = r0
    //     0x84102c: stur            w0, [x1, #0xf]
    // 0x841030: mov             x2, x1
    // 0x841034: r1 = Function '<anonymous closure>':.
    //     0x841034: add             x1, PP, #0x37, lsl #12  ; [pp+0x37cf0] AnonymousClosure: (0x841068), in [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] _CupertinoDesktopTextSelectionToolbarButtonState::_onEnter (0x841008)
    //     0x841038: ldr             x1, [x1, #0xcf0]
    // 0x84103c: r0 = AllocateClosure()
    //     0x84103c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x841040: ldr             x16, [fp, #0x18]
    // 0x841044: stp             x0, x16, [SP, #-0x10]!
    // 0x841048: r0 = setState()
    //     0x841048: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x84104c: add             SP, SP, #0x10
    // 0x841050: r0 = Null
    //     0x841050: mov             x0, NULL
    // 0x841054: LeaveFrame
    //     0x841054: mov             SP, fp
    //     0x841058: ldp             fp, lr, [SP], #0x10
    // 0x84105c: ret
    //     0x84105c: ret             
    // 0x841060: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x841060: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x841064: b               #0x84101c
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x841068, size: 0x24
    // 0x841068: r1 = true
    //     0x841068: add             x1, NULL, #0x20  ; true
    // 0x84106c: ldr             x2, [SP]
    // 0x841070: LoadField: r3 = r2->field_17
    //     0x841070: ldur            w3, [x2, #0x17]
    // 0x841074: DecompressPointer r3
    //     0x841074: add             x3, x3, HEAP, lsl #32
    // 0x841078: LoadField: r2 = r3->field_f
    //     0x841078: ldur            w2, [x3, #0xf]
    // 0x84107c: DecompressPointer r2
    //     0x84107c: add             x2, x2, HEAP, lsl #32
    // 0x841080: StoreField: r2->field_13 = r1
    //     0x841080: stur            w1, [x2, #0x13]
    // 0x841084: r0 = Null
    //     0x841084: mov             x0, NULL
    // 0x841088: ret
    //     0x841088: ret             
  }
}

// class id: 4181, size: 0x18, field offset: 0xc
//   const constructor, 
class CupertinoDesktopTextSelectionToolbarButton extends StatefulWidget {

  _ CupertinoDesktopTextSelectionToolbarButton.text(/* No info */) {
    // ** addr: 0x840b38, size: 0xcc
    // 0x840b38: EnterFrame
    //     0x840b38: stp             fp, lr, [SP, #-0x10]!
    //     0x840b3c: mov             fp, SP
    // 0x840b40: AllocStack(0x8)
    //     0x840b40: sub             SP, SP, #8
    // 0x840b44: CheckStackOverflow
    //     0x840b44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840b48: cmp             SP, x16
    //     0x840b4c: b.ls            #0x840bfc
    // 0x840b50: ldr             x0, [fp, #0x18]
    // 0x840b54: ldr             x1, [fp, #0x28]
    // 0x840b58: StoreField: r1->field_b = r0
    //     0x840b58: stur            w0, [x1, #0xb]
    //     0x840b5c: ldurb           w16, [x1, #-1]
    //     0x840b60: ldurb           w17, [x0, #-1]
    //     0x840b64: and             x16, x17, x16, lsr #2
    //     0x840b68: tst             x16, HEAP, lsr #32
    //     0x840b6c: b.eq            #0x840b74
    //     0x840b70: bl              #0xd6826c
    // 0x840b74: r16 = Instance_CupertinoDynamicColor
    //     0x840b74: add             x16, PP, #0x28, lsl #12  ; [pp+0x28db0] Obj!CupertinoDynamicColor@b5e6b1
    //     0x840b78: ldr             x16, [x16, #0xdb0]
    // 0x840b7c: ldr             lr, [fp, #0x20]
    // 0x840b80: stp             lr, x16, [SP, #-0x10]!
    // 0x840b84: r0 = resolveFrom()
    //     0x840b84: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x840b88: add             SP, SP, #0x10
    // 0x840b8c: r16 = Instance_TextStyle
    //     0x840b8c: add             x16, PP, #0x28, lsl #12  ; [pp+0x28da8] Obj!TextStyle@b43b41
    //     0x840b90: ldr             x16, [x16, #0xda8]
    // 0x840b94: stp             x0, x16, [SP, #-0x10]!
    // 0x840b98: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x840b98: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x840b9c: ldr             x4, [x4, #0x168]
    // 0x840ba0: r0 = copyWith()
    //     0x840ba0: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x840ba4: add             SP, SP, #0x10
    // 0x840ba8: stur            x0, [fp, #-8]
    // 0x840bac: r0 = Text()
    //     0x840bac: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0x840bb0: ldr             x1, [fp, #0x10]
    // 0x840bb4: StoreField: r0->field_b = r1
    //     0x840bb4: stur            w1, [x0, #0xb]
    // 0x840bb8: ldur            x1, [fp, #-8]
    // 0x840bbc: StoreField: r0->field_13 = r1
    //     0x840bbc: stur            w1, [x0, #0x13]
    // 0x840bc0: r1 = Instance_TextOverflow
    //     0x840bc0: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x840bc4: ldr             x1, [x1, #0x428]
    // 0x840bc8: StoreField: r0->field_2b = r1
    //     0x840bc8: stur            w1, [x0, #0x2b]
    // 0x840bcc: ldr             x1, [fp, #0x28]
    // 0x840bd0: StoreField: r1->field_f = r0
    //     0x840bd0: stur            w0, [x1, #0xf]
    //     0x840bd4: ldurb           w16, [x1, #-1]
    //     0x840bd8: ldurb           w17, [x0, #-1]
    //     0x840bdc: and             x16, x17, x16, lsr #2
    //     0x840be0: tst             x16, HEAP, lsr #32
    //     0x840be4: b.eq            #0x840bec
    //     0x840be8: bl              #0xd6826c
    // 0x840bec: r0 = Null
    //     0x840bec: mov             x0, NULL
    // 0x840bf0: LeaveFrame
    //     0x840bf0: mov             SP, fp
    //     0x840bf4: ldp             fp, lr, [SP], #0x10
    // 0x840bf8: ret
    //     0x840bf8: ret             
    // 0x840bfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840bfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840c00: b               #0x840b50
  }
  _ createState(/* No info */) {
    // ** addr: 0xa3fd74, size: 0x28
    // 0xa3fd74: EnterFrame
    //     0xa3fd74: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fd78: mov             fp, SP
    // 0xa3fd7c: r1 = <CupertinoDesktopTextSelectionToolbarButton>
    //     0xa3fd7c: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2eb90] TypeArguments: <CupertinoDesktopTextSelectionToolbarButton>
    //     0xa3fd80: ldr             x1, [x1, #0xb90]
    // 0xa3fd84: r0 = _CupertinoDesktopTextSelectionToolbarButtonState()
    //     0xa3fd84: bl              #0xa3fd9c  ; Allocate_CupertinoDesktopTextSelectionToolbarButtonStateStub -> _CupertinoDesktopTextSelectionToolbarButtonState (size=0x18)
    // 0xa3fd88: r1 = false
    //     0xa3fd88: add             x1, NULL, #0x30  ; false
    // 0xa3fd8c: StoreField: r0->field_13 = r1
    //     0xa3fd8c: stur            w1, [x0, #0x13]
    // 0xa3fd90: LeaveFrame
    //     0xa3fd90: mov             SP, fp
    //     0xa3fd94: ldp             fp, lr, [SP], #0x10
    // 0xa3fd98: ret
    //     0xa3fd98: ret             
  }
}

// lib: , url: package:flutter/src/cupertino/text_selection.dart

// class id: 1049112, size: 0x8
class :: {

  static late final TextSelectionControls cupertinoTextSelectionHandleControls; // offset: 0xce4
  static late final TextSelectionControls cupertinoTextSelectionControls; // offset: 0xce8

  static TextSelectionControls cupertinoTextSelectionControls() {
    // ** addr: 0x83ec70, size: 0x18
    // 0x83ec70: EnterFrame
    //     0x83ec70: stp             fp, lr, [SP, #-0x10]!
    //     0x83ec74: mov             fp, SP
    // 0x83ec78: r0 = CupertinoTextSelectionControls()
    //     0x83ec78: bl              #0x83ec88  ; AllocateCupertinoTextSelectionControlsStub -> CupertinoTextSelectionControls (size=0x8)
    // 0x83ec7c: LeaveFrame
    //     0x83ec7c: mov             SP, fp
    //     0x83ec80: ldp             fp, lr, [SP], #0x10
    // 0x83ec84: ret
    //     0x83ec84: ret             
  }
  static TextSelectionControls cupertinoTextSelectionHandleControls() {
    // ** addr: 0x872df4, size: 0x18
    // 0x872df4: EnterFrame
    //     0x872df4: stp             fp, lr, [SP, #-0x10]!
    //     0x872df8: mov             fp, SP
    // 0x872dfc: r0 = CupertinoTextSelectionHandleControls()
    //     0x872dfc: bl              #0x872e0c  ; AllocateCupertinoTextSelectionHandleControlsStub -> CupertinoTextSelectionHandleControls (size=0x8)
    // 0x872e00: LeaveFrame
    //     0x872e00: mov             SP, fp
    //     0x872e04: ldp             fp, lr, [SP], #0x10
    // 0x872e08: ret
    //     0x872e08: ret             
  }
}

// class id: 3346, size: 0x14, field offset: 0x14
class _CupertinoTextSelectionControlsToolbarState extends State<_CupertinoTextSelectionControlsToolbar> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7afc68, size: 0x17c
    // 0x7afc68: EnterFrame
    //     0x7afc68: stp             fp, lr, [SP, #-0x10]!
    //     0x7afc6c: mov             fp, SP
    // 0x7afc70: AllocStack(0x8)
    //     0x7afc70: sub             SP, SP, #8
    // 0x7afc74: CheckStackOverflow
    //     0x7afc74: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7afc78: cmp             SP, x16
    //     0x7afc7c: b.ls            #0x7afdd4
    // 0x7afc80: ldr             x0, [fp, #0x10]
    // 0x7afc84: r2 = Null
    //     0x7afc84: mov             x2, NULL
    // 0x7afc88: r1 = Null
    //     0x7afc88: mov             x1, NULL
    // 0x7afc8c: r4 = 59
    //     0x7afc8c: mov             x4, #0x3b
    // 0x7afc90: branchIfSmi(r0, 0x7afc9c)
    //     0x7afc90: tbz             w0, #0, #0x7afc9c
    // 0x7afc94: r4 = LoadClassIdInstr(r0)
    //     0x7afc94: ldur            x4, [x0, #-1]
    //     0x7afc98: ubfx            x4, x4, #0xc, #0x14
    // 0x7afc9c: r17 = 4174
    //     0x7afc9c: mov             x17, #0x104e
    // 0x7afca0: cmp             x4, x17
    // 0x7afca4: b.eq            #0x7afcbc
    // 0x7afca8: r8 = _CupertinoTextSelectionControlsToolbar
    //     0x7afca8: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4ba90] Type: _CupertinoTextSelectionControlsToolbar
    //     0x7afcac: ldr             x8, [x8, #0xa90]
    // 0x7afcb0: r3 = Null
    //     0x7afcb0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4ba98] Null
    //     0x7afcb4: ldr             x3, [x3, #0xa98]
    // 0x7afcb8: r0 = _CupertinoTextSelectionControlsToolbar()
    //     0x7afcb8: bl              #0x7afde4  ; IsType__CupertinoTextSelectionControlsToolbar_Stub
    // 0x7afcbc: ldr             x3, [fp, #0x18]
    // 0x7afcc0: LoadField: r2 = r3->field_7
    //     0x7afcc0: ldur            w2, [x3, #7]
    // 0x7afcc4: DecompressPointer r2
    //     0x7afcc4: add             x2, x2, HEAP, lsl #32
    // 0x7afcc8: ldr             x0, [fp, #0x10]
    // 0x7afccc: r1 = Null
    //     0x7afccc: mov             x1, NULL
    // 0x7afcd0: cmp             w2, NULL
    // 0x7afcd4: b.eq            #0x7afcf8
    // 0x7afcd8: LoadField: r4 = r2->field_17
    //     0x7afcd8: ldur            w4, [x2, #0x17]
    // 0x7afcdc: DecompressPointer r4
    //     0x7afcdc: add             x4, x4, HEAP, lsl #32
    // 0x7afce0: r8 = X0 bound StatefulWidget
    //     0x7afce0: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7afce4: ldr             x8, [x8, #0x858]
    // 0x7afce8: LoadField: r9 = r4->field_7
    //     0x7afce8: ldur            x9, [x4, #7]
    // 0x7afcec: r3 = Null
    //     0x7afcec: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4baa8] Null
    //     0x7afcf0: ldr             x3, [x3, #0xaa8]
    // 0x7afcf4: blr             x9
    // 0x7afcf8: ldr             x0, [fp, #0x10]
    // 0x7afcfc: LoadField: r1 = r0->field_b
    //     0x7afcfc: ldur            w1, [x0, #0xb]
    // 0x7afd00: DecompressPointer r1
    //     0x7afd00: add             x1, x1, HEAP, lsl #32
    // 0x7afd04: ldr             x0, [fp, #0x18]
    // 0x7afd08: stur            x1, [fp, #-8]
    // 0x7afd0c: LoadField: r2 = r0->field_b
    //     0x7afd0c: ldur            w2, [x0, #0xb]
    // 0x7afd10: DecompressPointer r2
    //     0x7afd10: add             x2, x2, HEAP, lsl #32
    // 0x7afd14: cmp             w2, NULL
    // 0x7afd18: b.eq            #0x7afddc
    // 0x7afd1c: LoadField: r3 = r2->field_b
    //     0x7afd1c: ldur            w3, [x2, #0xb]
    // 0x7afd20: DecompressPointer r3
    //     0x7afd20: add             x3, x3, HEAP, lsl #32
    // 0x7afd24: cmp             w1, w3
    // 0x7afd28: b.eq            #0x7afdc4
    // 0x7afd2c: cmp             w1, NULL
    // 0x7afd30: b.eq            #0x7afd6c
    // 0x7afd34: r1 = 1
    //     0x7afd34: mov             x1, #1
    // 0x7afd38: r0 = AllocateContext()
    //     0x7afd38: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7afd3c: mov             x1, x0
    // 0x7afd40: ldr             x0, [fp, #0x18]
    // 0x7afd44: StoreField: r1->field_f = r0
    //     0x7afd44: stur            w0, [x1, #0xf]
    // 0x7afd48: mov             x2, x1
    // 0x7afd4c: r1 = Function '_onChangedClipboardStatus@620300207':.
    //     0x7afd4c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba80] AnonymousClosure: (0x7afe08), in [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7afe50)
    //     0x7afd50: ldr             x1, [x1, #0xa80]
    // 0x7afd54: r0 = AllocateClosure()
    //     0x7afd54: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7afd58: ldur            x16, [fp, #-8]
    // 0x7afd5c: stp             x0, x16, [SP, #-0x10]!
    // 0x7afd60: r0 = removeListener()
    //     0x7afd60: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0x7afd64: add             SP, SP, #0x10
    // 0x7afd68: ldr             x0, [fp, #0x18]
    // 0x7afd6c: LoadField: r1 = r0->field_b
    //     0x7afd6c: ldur            w1, [x0, #0xb]
    // 0x7afd70: DecompressPointer r1
    //     0x7afd70: add             x1, x1, HEAP, lsl #32
    // 0x7afd74: cmp             w1, NULL
    // 0x7afd78: b.eq            #0x7afde0
    // 0x7afd7c: LoadField: r2 = r1->field_b
    //     0x7afd7c: ldur            w2, [x1, #0xb]
    // 0x7afd80: DecompressPointer r2
    //     0x7afd80: add             x2, x2, HEAP, lsl #32
    // 0x7afd84: stur            x2, [fp, #-8]
    // 0x7afd88: cmp             w2, NULL
    // 0x7afd8c: b.eq            #0x7afdc4
    // 0x7afd90: r1 = 1
    //     0x7afd90: mov             x1, #1
    // 0x7afd94: r0 = AllocateContext()
    //     0x7afd94: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7afd98: mov             x1, x0
    // 0x7afd9c: ldr             x0, [fp, #0x18]
    // 0x7afda0: StoreField: r1->field_f = r0
    //     0x7afda0: stur            w0, [x1, #0xf]
    // 0x7afda4: mov             x2, x1
    // 0x7afda8: r1 = Function '_onChangedClipboardStatus@620300207':.
    //     0x7afda8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba80] AnonymousClosure: (0x7afe08), in [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7afe50)
    //     0x7afdac: ldr             x1, [x1, #0xa80]
    // 0x7afdb0: r0 = AllocateClosure()
    //     0x7afdb0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7afdb4: ldur            x16, [fp, #-8]
    // 0x7afdb8: stp             x0, x16, [SP, #-0x10]!
    // 0x7afdbc: r0 = addListener()
    //     0x7afdbc: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x7afdc0: add             SP, SP, #0x10
    // 0x7afdc4: r0 = Null
    //     0x7afdc4: mov             x0, NULL
    // 0x7afdc8: LeaveFrame
    //     0x7afdc8: mov             SP, fp
    //     0x7afdcc: ldp             fp, lr, [SP], #0x10
    // 0x7afdd0: ret
    //     0x7afdd0: ret             
    // 0x7afdd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7afdd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7afdd8: b               #0x7afc80
    // 0x7afddc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7afddc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7afde0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7afde0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onChangedClipboardStatus(dynamic) {
    // ** addr: 0x7afe08, size: 0x48
    // 0x7afe08: EnterFrame
    //     0x7afe08: stp             fp, lr, [SP, #-0x10]!
    //     0x7afe0c: mov             fp, SP
    // 0x7afe10: ldr             x0, [fp, #0x10]
    // 0x7afe14: LoadField: r1 = r0->field_17
    //     0x7afe14: ldur            w1, [x0, #0x17]
    // 0x7afe18: DecompressPointer r1
    //     0x7afe18: add             x1, x1, HEAP, lsl #32
    // 0x7afe1c: CheckStackOverflow
    //     0x7afe1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7afe20: cmp             SP, x16
    //     0x7afe24: b.ls            #0x7afe48
    // 0x7afe28: LoadField: r0 = r1->field_f
    //     0x7afe28: ldur            w0, [x1, #0xf]
    // 0x7afe2c: DecompressPointer r0
    //     0x7afe2c: add             x0, x0, HEAP, lsl #32
    // 0x7afe30: SaveReg r0
    //     0x7afe30: str             x0, [SP, #-8]!
    // 0x7afe34: r0 = _onChangedClipboardStatus()
    //     0x7afe34: bl              #0x7afe50  ; [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::_onChangedClipboardStatus
    // 0x7afe38: add             SP, SP, #8
    // 0x7afe3c: LeaveFrame
    //     0x7afe3c: mov             SP, fp
    //     0x7afe40: ldp             fp, lr, [SP], #0x10
    // 0x7afe44: ret
    //     0x7afe44: ret             
    // 0x7afe48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7afe48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7afe4c: b               #0x7afe28
  }
  _ _onChangedClipboardStatus(/* No info */) {
    // ** addr: 0x7afe50, size: 0x4c
    // 0x7afe50: EnterFrame
    //     0x7afe50: stp             fp, lr, [SP, #-0x10]!
    //     0x7afe54: mov             fp, SP
    // 0x7afe58: CheckStackOverflow
    //     0x7afe58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7afe5c: cmp             SP, x16
    //     0x7afe60: b.ls            #0x7afe94
    // 0x7afe64: r1 = Function '<anonymous closure>':.
    //     0x7afe64: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba88] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7afe68: ldr             x1, [x1, #0xa88]
    // 0x7afe6c: r2 = Null
    //     0x7afe6c: mov             x2, NULL
    // 0x7afe70: r0 = AllocateClosure()
    //     0x7afe70: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7afe74: ldr             x16, [fp, #0x10]
    // 0x7afe78: stp             x0, x16, [SP, #-0x10]!
    // 0x7afe7c: r0 = setState()
    //     0x7afe7c: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7afe80: add             SP, SP, #0x10
    // 0x7afe84: r0 = Null
    //     0x7afe84: mov             x0, NULL
    // 0x7afe88: LeaveFrame
    //     0x7afe88: mov             SP, fp
    //     0x7afe8c: ldp             fp, lr, [SP], #0x10
    // 0x7afe90: ret
    //     0x7afe90: ret             
    // 0x7afe94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7afe94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7afe98: b               #0x7afe64
  }
  _ build(/* No info */) {
    // ** addr: 0x8442c0, size: 0xaac
    // 0x8442c0: EnterFrame
    //     0x8442c0: stp             fp, lr, [SP, #-0x10]!
    //     0x8442c4: mov             fp, SP
    // 0x8442c8: AllocStack(0x40)
    //     0x8442c8: sub             SP, SP, #0x40
    // 0x8442cc: CheckStackOverflow
    //     0x8442cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8442d0: cmp             SP, x16
    //     0x8442d4: b.ls            #0x844cb8
    // 0x8442d8: ldr             x0, [fp, #0x18]
    // 0x8442dc: LoadField: r1 = r0->field_b
    //     0x8442dc: ldur            w1, [x0, #0xb]
    // 0x8442e0: DecompressPointer r1
    //     0x8442e0: add             x1, x1, HEAP, lsl #32
    // 0x8442e4: cmp             w1, NULL
    // 0x8442e8: b.eq            #0x844cc0
    // 0x8442ec: LoadField: r2 = r1->field_1f
    //     0x8442ec: ldur            w2, [x1, #0x1f]
    // 0x8442f0: DecompressPointer r2
    //     0x8442f0: add             x2, x2, HEAP, lsl #32
    // 0x8442f4: cmp             w2, NULL
    // 0x8442f8: b.eq            #0x844338
    // 0x8442fc: LoadField: r2 = r1->field_b
    //     0x8442fc: ldur            w2, [x1, #0xb]
    // 0x844300: DecompressPointer r2
    //     0x844300: add             x2, x2, HEAP, lsl #32
    // 0x844304: cmp             w2, NULL
    // 0x844308: b.eq            #0x844338
    // 0x84430c: LoadField: r1 = r2->field_27
    //     0x84430c: ldur            w1, [x2, #0x27]
    // 0x844310: DecompressPointer r1
    //     0x844310: add             x1, x1, HEAP, lsl #32
    // 0x844314: r16 = Instance_ClipboardStatus
    //     0x844314: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc88] Obj!ClipboardStatus@b63451
    //     0x844318: ldr             x16, [x16, #0xc88]
    // 0x84431c: cmp             w1, w16
    // 0x844320: b.ne            #0x844338
    // 0x844324: r0 = Instance_SizedBox
    //     0x844324: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x844328: ldr             x0, [x0, #0x738]
    // 0x84432c: LeaveFrame
    //     0x84432c: mov             SP, fp
    //     0x844330: ldp             fp, lr, [SP], #0x10
    // 0x844334: ret
    //     0x844334: ret             
    // 0x844338: ldr             x16, [fp, #0x10]
    // 0x84433c: SaveReg r16
    //     0x84433c: str             x16, [SP, #-8]!
    // 0x844340: r0 = of()
    //     0x844340: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x844344: add             SP, SP, #8
    // 0x844348: ldr             x1, [fp, #0x18]
    // 0x84434c: LoadField: r2 = r1->field_b
    //     0x84434c: ldur            w2, [x1, #0xb]
    // 0x844350: DecompressPointer r2
    //     0x844350: add             x2, x2, HEAP, lsl #32
    // 0x844354: cmp             w2, NULL
    // 0x844358: b.eq            #0x844cc4
    // 0x84435c: LoadField: r3 = r2->field_27
    //     0x84435c: ldur            w3, [x2, #0x27]
    // 0x844360: DecompressPointer r3
    //     0x844360: add             x3, x3, HEAP, lsl #32
    // 0x844364: LoadField: d0 = r3->field_7
    //     0x844364: ldur            d0, [x3, #7]
    // 0x844368: LoadField: r3 = r2->field_13
    //     0x844368: ldur            w3, [x2, #0x13]
    // 0x84436c: DecompressPointer r3
    //     0x84436c: add             x3, x3, HEAP, lsl #32
    // 0x844370: LoadField: d1 = r3->field_7
    //     0x844370: ldur            d1, [x3, #7]
    // 0x844374: fadd            d2, d0, d1
    // 0x844378: LoadField: r3 = r0->field_23
    //     0x844378: ldur            w3, [x0, #0x23]
    // 0x84437c: DecompressPointer r3
    //     0x84437c: add             x3, x3, HEAP, lsl #32
    // 0x844380: LoadField: d0 = r3->field_7
    //     0x844380: ldur            d0, [x3, #7]
    // 0x844384: d1 = 26.000000
    //     0x844384: fmov            d1, #26.00000000
    // 0x844388: fadd            d3, d1, d0
    // 0x84438c: LoadField: r4 = r0->field_7
    //     0x84438c: ldur            w4, [x0, #7]
    // 0x844390: DecompressPointer r4
    //     0x844390: add             x4, x4, HEAP, lsl #32
    // 0x844394: LoadField: d0 = r4->field_7
    //     0x844394: ldur            d0, [x4, #7]
    // 0x844398: LoadField: d4 = r3->field_17
    //     0x844398: ldur            d4, [x3, #0x17]
    // 0x84439c: fsub            d5, d0, d4
    // 0x8443a0: fsub            d0, d5, d1
    // 0x8443a4: fcmp            d2, d3
    // 0x8443a8: b.vs            #0x8443b8
    // 0x8443ac: b.ge            #0x8443b8
    // 0x8443b0: mov             v0.16b, v3.16b
    // 0x8443b4: b               #0x8443d0
    // 0x8443b8: fcmp            d2, d0
    // 0x8443bc: b.vs            #0x8443c4
    // 0x8443c0: b.gt            #0x8443d0
    // 0x8443c4: fcmp            d2, d2
    // 0x8443c8: b.vs            #0x8443d0
    // 0x8443cc: mov             v0.16b, v2.16b
    // 0x8443d0: stur            d0, [fp, #-0x38]
    // 0x8443d4: LoadField: r0 = r2->field_f
    //     0x8443d4: ldur            w0, [x2, #0xf]
    // 0x8443d8: DecompressPointer r0
    //     0x8443d8: add             x0, x0, HEAP, lsl #32
    // 0x8443dc: r2 = LoadClassIdInstr(r0)
    //     0x8443dc: ldur            x2, [x0, #-1]
    //     0x8443e0: ubfx            x2, x2, #0xc, #0x14
    // 0x8443e4: SaveReg r0
    //     0x8443e4: str             x0, [SP, #-8]!
    // 0x8443e8: mov             x0, x2
    // 0x8443ec: r0 = GDT[cid_x0 + 0xcaae]()
    //     0x8443ec: mov             x17, #0xcaae
    //     0x8443f0: add             lr, x0, x17
    //     0x8443f4: ldr             lr, [x21, lr, lsl #3]
    //     0x8443f8: blr             lr
    // 0x8443fc: add             SP, SP, #8
    // 0x844400: LoadField: r1 = r0->field_7
    //     0x844400: ldur            w1, [x0, #7]
    // 0x844404: DecompressPointer r1
    //     0x844404: add             x1, x1, HEAP, lsl #32
    // 0x844408: LoadField: d0 = r1->field_f
    //     0x844408: ldur            d0, [x1, #0xf]
    // 0x84440c: ldr             x0, [fp, #0x18]
    // 0x844410: LoadField: r1 = r0->field_b
    //     0x844410: ldur            w1, [x0, #0xb]
    // 0x844414: DecompressPointer r1
    //     0x844414: add             x1, x1, HEAP, lsl #32
    // 0x844418: cmp             w1, NULL
    // 0x84441c: b.eq            #0x844cc8
    // 0x844420: LoadField: d1 = r1->field_2b
    //     0x844420: ldur            d1, [x1, #0x2b]
    // 0x844424: fsub            d2, d0, d1
    // 0x844428: d0 = 0.000000
    //     0x844428: eor             v0.16b, v0.16b, v0.16b
    // 0x84442c: fcmp            d2, d0
    // 0x844430: b.vs            #0x844470
    // 0x844434: b.le            #0x844470
    // 0x844438: r1 = inline_Allocate_Double()
    //     0x844438: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84443c: add             x1, x1, #0x10
    //     0x844440: cmp             x2, x1
    //     0x844444: b.ls            #0x844ccc
    //     0x844448: str             x1, [THR, #0x60]  ; THR::top
    //     0x84444c: sub             x1, x1, #0xf
    //     0x844450: mov             x2, #0xd108
    //     0x844454: movk            x2, #3, lsl #16
    //     0x844458: stur            x2, [x1, #-1]
    // 0x84445c: StoreField: r1->field_7 = d2
    //     0x84445c: stur            d2, [x1, #7]
    // 0x844460: mov             x16, x0
    // 0x844464: mov             x0, x1
    // 0x844468: mov             x1, x16
    // 0x84446c: b               #0x8444d8
    // 0x844470: fcmp            d2, d0
    // 0x844474: b.vs            #0x844488
    // 0x844478: b.ge            #0x844488
    // 0x84447c: mov             x1, x0
    // 0x844480: r0 = 0
    //     0x844480: mov             x0, #0
    // 0x844484: b               #0x8444d8
    // 0x844488: r1 = inline_Allocate_Double()
    //     0x844488: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x84448c: add             x1, x1, #0x10
    //     0x844490: cmp             x2, x1
    //     0x844494: b.ls            #0x844ce8
    //     0x844498: str             x1, [THR, #0x60]  ; THR::top
    //     0x84449c: sub             x1, x1, #0xf
    //     0x8444a0: mov             x2, #0xd108
    //     0x8444a4: movk            x2, #3, lsl #16
    //     0x8444a8: stur            x2, [x1, #-1]
    // 0x8444ac: StoreField: r1->field_7 = d2
    //     0x8444ac: stur            d2, [x1, #7]
    // 0x8444b0: stur            x1, [fp, #-8]
    // 0x8444b4: SaveReg r1
    //     0x8444b4: str             x1, [SP, #-8]!
    // 0x8444b8: r0 = isNegative()
    //     0x8444b8: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x8444bc: add             SP, SP, #8
    // 0x8444c0: tbnz            w0, #4, #0x8444d0
    // 0x8444c4: ldr             x1, [fp, #0x18]
    // 0x8444c8: r0 = 0
    //     0x8444c8: mov             x0, #0
    // 0x8444cc: b               #0x8444d8
    // 0x8444d0: ldur            x0, [fp, #-8]
    // 0x8444d4: ldr             x1, [fp, #0x18]
    // 0x8444d8: ldur            d0, [fp, #-0x38]
    // 0x8444dc: LoadField: r2 = r1->field_b
    //     0x8444dc: ldur            w2, [x1, #0xb]
    // 0x8444e0: DecompressPointer r2
    //     0x8444e0: add             x2, x2, HEAP, lsl #32
    // 0x8444e4: cmp             w2, NULL
    // 0x8444e8: b.eq            #0x844d04
    // 0x8444ec: LoadField: r3 = r2->field_13
    //     0x8444ec: ldur            w3, [x2, #0x13]
    // 0x8444f0: DecompressPointer r3
    //     0x8444f0: add             x3, x3, HEAP, lsl #32
    // 0x8444f4: LoadField: d1 = r3->field_f
    //     0x8444f4: ldur            d1, [x3, #0xf]
    // 0x8444f8: r2 = inline_Allocate_Double()
    //     0x8444f8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8444fc: add             x2, x2, #0x10
    //     0x844500: cmp             x3, x2
    //     0x844504: b.ls            #0x844d08
    //     0x844508: str             x2, [THR, #0x60]  ; THR::top
    //     0x84450c: sub             x2, x2, #0xf
    //     0x844510: mov             x3, #0xd108
    //     0x844514: movk            x3, #3, lsl #16
    //     0x844518: stur            x3, [x2, #-1]
    // 0x84451c: StoreField: r2->field_7 = d1
    //     0x84451c: stur            d1, [x2, #7]
    // 0x844520: r3 = 59
    //     0x844520: mov             x3, #0x3b
    // 0x844524: branchIfSmi(r0, 0x844530)
    //     0x844524: tbz             w0, #0, #0x844530
    // 0x844528: r3 = LoadClassIdInstr(r0)
    //     0x844528: ldur            x3, [x0, #-1]
    //     0x84452c: ubfx            x3, x3, #0xc, #0x14
    // 0x844530: stp             x2, x0, [SP, #-0x10]!
    // 0x844534: mov             x0, x3
    // 0x844538: r0 = GDT[cid_x0 + -0xff3]()
    //     0x844538: sub             lr, x0, #0xff3
    //     0x84453c: ldr             lr, [x21, lr, lsl #3]
    //     0x844540: blr             lr
    // 0x844544: add             SP, SP, #0x10
    // 0x844548: stur            x0, [fp, #-8]
    // 0x84454c: r0 = Offset()
    //     0x84454c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x844550: mov             x1, x0
    // 0x844554: ldur            d0, [fp, #-0x38]
    // 0x844558: stur            x1, [fp, #-0x10]
    // 0x84455c: StoreField: r1->field_7 = d0
    //     0x84455c: stur            d0, [x1, #7]
    // 0x844560: ldur            x0, [fp, #-8]
    // 0x844564: LoadField: d1 = r0->field_7
    //     0x844564: ldur            d1, [x0, #7]
    // 0x844568: StoreField: r1->field_f = d1
    //     0x844568: stur            d1, [x1, #0xf]
    // 0x84456c: ldr             x2, [fp, #0x18]
    // 0x844570: LoadField: r0 = r2->field_b
    //     0x844570: ldur            w0, [x2, #0xb]
    // 0x844574: DecompressPointer r0
    //     0x844574: add             x0, x0, HEAP, lsl #32
    // 0x844578: cmp             w0, NULL
    // 0x84457c: b.eq            #0x844d24
    // 0x844580: LoadField: r3 = r0->field_f
    //     0x844580: ldur            w3, [x0, #0xf]
    // 0x844584: DecompressPointer r3
    //     0x844584: add             x3, x3, HEAP, lsl #32
    // 0x844588: r0 = LoadClassIdInstr(r3)
    //     0x844588: ldur            x0, [x3, #-1]
    //     0x84458c: ubfx            x0, x0, #0xc, #0x14
    // 0x844590: SaveReg r3
    //     0x844590: str             x3, [SP, #-8]!
    // 0x844594: r0 = GDT[cid_x0 + 0xfe03]()
    //     0x844594: mov             x17, #0xfe03
    //     0x844598: add             lr, x0, x17
    //     0x84459c: ldr             lr, [x21, lr, lsl #3]
    //     0x8445a0: blr             lr
    // 0x8445a4: add             SP, SP, #8
    // 0x8445a8: LoadField: r1 = r0->field_7
    //     0x8445a8: ldur            w1, [x0, #7]
    // 0x8445ac: DecompressPointer r1
    //     0x8445ac: add             x1, x1, HEAP, lsl #32
    // 0x8445b0: LoadField: d0 = r1->field_f
    //     0x8445b0: ldur            d0, [x1, #0xf]
    // 0x8445b4: ldr             x0, [fp, #0x18]
    // 0x8445b8: LoadField: r1 = r0->field_b
    //     0x8445b8: ldur            w1, [x0, #0xb]
    // 0x8445bc: DecompressPointer r1
    //     0x8445bc: add             x1, x1, HEAP, lsl #32
    // 0x8445c0: cmp             w1, NULL
    // 0x8445c4: b.eq            #0x844d28
    // 0x8445c8: LoadField: r2 = r1->field_13
    //     0x8445c8: ldur            w2, [x1, #0x13]
    // 0x8445cc: DecompressPointer r2
    //     0x8445cc: add             x2, x2, HEAP, lsl #32
    // 0x8445d0: LoadField: d1 = r2->field_f
    //     0x8445d0: ldur            d1, [x2, #0xf]
    // 0x8445d4: fadd            d2, d0, d1
    // 0x8445d8: stur            d2, [fp, #-0x40]
    // 0x8445dc: r0 = Offset()
    //     0x8445dc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x8445e0: ldur            d0, [fp, #-0x38]
    // 0x8445e4: stur            x0, [fp, #-8]
    // 0x8445e8: StoreField: r0->field_7 = d0
    //     0x8445e8: stur            d0, [x0, #7]
    // 0x8445ec: ldur            d0, [fp, #-0x40]
    // 0x8445f0: StoreField: r0->field_f = d0
    //     0x8445f0: stur            d0, [x0, #0xf]
    // 0x8445f4: r16 = <Widget>
    //     0x8445f4: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x8445f8: ldr             x16, [x16, #0xea8]
    // 0x8445fc: stp             xzr, x16, [SP, #-0x10]!
    // 0x844600: r0 = _GrowableList()
    //     0x844600: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x844604: add             SP, SP, #0x10
    // 0x844608: stur            x0, [fp, #-0x18]
    // 0x84460c: ldr             x16, [fp, #0x10]
    // 0x844610: SaveReg r16
    //     0x844610: str             x16, [SP, #-8]!
    // 0x844614: r0 = of()
    //     0x844614: bl              #0x840c34  ; [package:flutter/src/cupertino/localizations.dart] CupertinoLocalizations::of
    // 0x844618: add             SP, SP, #8
    // 0x84461c: ldr             x16, [fp, #0x10]
    // 0x844620: SaveReg r16
    //     0x844620: str             x16, [SP, #-8]!
    // 0x844624: r0 = of()
    //     0x844624: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x844628: add             SP, SP, #8
    // 0x84462c: LoadField: d0 = r0->field_b
    //     0x84462c: ldur            d0, [x0, #0xb]
    // 0x844630: d1 = 1.000000
    //     0x844630: fmov            d1, #1.00000000
    // 0x844634: fdiv            d2, d1, d0
    // 0x844638: r0 = inline_Allocate_Double()
    //     0x844638: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x84463c: add             x0, x0, #0x10
    //     0x844640: cmp             x1, x0
    //     0x844644: b.ls            #0x844d2c
    //     0x844648: str             x0, [THR, #0x60]  ; THR::top
    //     0x84464c: sub             x0, x0, #0xf
    //     0x844650: mov             x1, #0xd108
    //     0x844654: movk            x1, #3, lsl #16
    //     0x844658: stur            x1, [x0, #-1]
    // 0x84465c: StoreField: r0->field_7 = d2
    //     0x84465c: stur            d2, [x0, #7]
    // 0x844660: stur            x0, [fp, #-0x20]
    // 0x844664: r0 = SizedBox()
    //     0x844664: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x844668: mov             x1, x0
    // 0x84466c: ldur            x0, [fp, #-0x20]
    // 0x844670: stur            x1, [fp, #-0x30]
    // 0x844674: StoreField: r1->field_f = r0
    //     0x844674: stur            w0, [x1, #0xf]
    // 0x844678: ldr             x0, [fp, #0x18]
    // 0x84467c: LoadField: r2 = r0->field_b
    //     0x84467c: ldur            w2, [x0, #0xb]
    // 0x844680: DecompressPointer r2
    //     0x844680: add             x2, x2, HEAP, lsl #32
    // 0x844684: cmp             w2, NULL
    // 0x844688: b.eq            #0x844d3c
    // 0x84468c: LoadField: r3 = r2->field_1b
    //     0x84468c: ldur            w3, [x2, #0x1b]
    // 0x844690: DecompressPointer r3
    //     0x844690: add             x3, x3, HEAP, lsl #32
    // 0x844694: stur            x3, [fp, #-0x28]
    // 0x844698: cmp             w3, NULL
    // 0x84469c: b.eq            #0x8447ec
    // 0x8446a0: ldur            x2, [fp, #-0x18]
    // 0x8446a4: LoadField: r4 = r2->field_b
    //     0x8446a4: ldur            w4, [x2, #0xb]
    // 0x8446a8: DecompressPointer r4
    //     0x8446a8: add             x4, x4, HEAP, lsl #32
    // 0x8446ac: stur            x4, [fp, #-0x20]
    // 0x8446b0: cbz             w4, #0x844730
    // 0x8446b4: LoadField: r5 = r2->field_f
    //     0x8446b4: ldur            w5, [x2, #0xf]
    // 0x8446b8: DecompressPointer r5
    //     0x8446b8: add             x5, x5, HEAP, lsl #32
    // 0x8446bc: LoadField: r6 = r5->field_b
    //     0x8446bc: ldur            w6, [x5, #0xb]
    // 0x8446c0: DecompressPointer r6
    //     0x8446c0: add             x6, x6, HEAP, lsl #32
    // 0x8446c4: cmp             w4, w6
    // 0x8446c8: b.ne            #0x8446d8
    // 0x8446cc: SaveReg r2
    //     0x8446cc: str             x2, [SP, #-8]!
    // 0x8446d0: r0 = _growToNextCapacity()
    //     0x8446d0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8446d4: add             SP, SP, #8
    // 0x8446d8: ldur            x2, [fp, #-0x18]
    // 0x8446dc: ldur            x0, [fp, #-0x20]
    // 0x8446e0: r3 = LoadInt32Instr(r0)
    //     0x8446e0: sbfx            x3, x0, #1, #0x1f
    // 0x8446e4: add             x0, x3, #1
    // 0x8446e8: lsl             x1, x0, #1
    // 0x8446ec: StoreField: r2->field_b = r1
    //     0x8446ec: stur            w1, [x2, #0xb]
    // 0x8446f0: mov             x1, x3
    // 0x8446f4: cmp             x1, x0
    // 0x8446f8: b.hs            #0x844d40
    // 0x8446fc: LoadField: r1 = r2->field_f
    //     0x8446fc: ldur            w1, [x2, #0xf]
    // 0x844700: DecompressPointer r1
    //     0x844700: add             x1, x1, HEAP, lsl #32
    // 0x844704: ldur            x0, [fp, #-0x30]
    // 0x844708: ArrayStore: r1[r3] = r0  ; List_4
    //     0x844708: add             x25, x1, x3, lsl #2
    //     0x84470c: add             x25, x25, #0xf
    //     0x844710: str             w0, [x25]
    //     0x844714: tbz             w0, #0, #0x844730
    //     0x844718: ldurb           w16, [x1, #-1]
    //     0x84471c: ldurb           w17, [x0, #-1]
    //     0x844720: and             x16, x17, x16, lsr #2
    //     0x844724: tst             x16, HEAP, lsr #32
    //     0x844728: b.eq            #0x844730
    //     0x84472c: bl              #0xd67e5c
    // 0x844730: r0 = CupertinoTextSelectionToolbarButton()
    //     0x844730: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x844734: stur            x0, [fp, #-0x20]
    // 0x844738: r16 = "Cut"
    //     0x844738: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Cut"
    //     0x84473c: ldr             x16, [x16, #0xdd0]
    // 0x844740: stp             x16, x0, [SP, #-0x10]!
    // 0x844744: ldur            x16, [fp, #-0x28]
    // 0x844748: SaveReg r16
    //     0x844748: str             x16, [SP, #-8]!
    // 0x84474c: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0x84474c: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0x844750: ldr             x4, [x4, #0xdb8]
    // 0x844754: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x844754: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x844758: add             SP, SP, #0x18
    // 0x84475c: ldur            x0, [fp, #-0x18]
    // 0x844760: LoadField: r1 = r0->field_b
    //     0x844760: ldur            w1, [x0, #0xb]
    // 0x844764: DecompressPointer r1
    //     0x844764: add             x1, x1, HEAP, lsl #32
    // 0x844768: stur            x1, [fp, #-0x28]
    // 0x84476c: LoadField: r2 = r0->field_f
    //     0x84476c: ldur            w2, [x0, #0xf]
    // 0x844770: DecompressPointer r2
    //     0x844770: add             x2, x2, HEAP, lsl #32
    // 0x844774: LoadField: r3 = r2->field_b
    //     0x844774: ldur            w3, [x2, #0xb]
    // 0x844778: DecompressPointer r3
    //     0x844778: add             x3, x3, HEAP, lsl #32
    // 0x84477c: cmp             w1, w3
    // 0x844780: b.ne            #0x844790
    // 0x844784: SaveReg r0
    //     0x844784: str             x0, [SP, #-8]!
    // 0x844788: r0 = _growToNextCapacity()
    //     0x844788: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84478c: add             SP, SP, #8
    // 0x844790: ldur            x2, [fp, #-0x18]
    // 0x844794: ldur            x0, [fp, #-0x28]
    // 0x844798: r3 = LoadInt32Instr(r0)
    //     0x844798: sbfx            x3, x0, #1, #0x1f
    // 0x84479c: add             x0, x3, #1
    // 0x8447a0: lsl             x1, x0, #1
    // 0x8447a4: StoreField: r2->field_b = r1
    //     0x8447a4: stur            w1, [x2, #0xb]
    // 0x8447a8: mov             x1, x3
    // 0x8447ac: cmp             x1, x0
    // 0x8447b0: b.hs            #0x844d44
    // 0x8447b4: LoadField: r1 = r2->field_f
    //     0x8447b4: ldur            w1, [x2, #0xf]
    // 0x8447b8: DecompressPointer r1
    //     0x8447b8: add             x1, x1, HEAP, lsl #32
    // 0x8447bc: ldur            x0, [fp, #-0x20]
    // 0x8447c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8447c0: add             x25, x1, x3, lsl #2
    //     0x8447c4: add             x25, x25, #0xf
    //     0x8447c8: str             w0, [x25]
    //     0x8447cc: tbz             w0, #0, #0x8447e8
    //     0x8447d0: ldurb           w16, [x1, #-1]
    //     0x8447d4: ldurb           w17, [x0, #-1]
    //     0x8447d8: and             x16, x17, x16, lsr #2
    //     0x8447dc: tst             x16, HEAP, lsr #32
    //     0x8447e0: b.eq            #0x8447e8
    //     0x8447e4: bl              #0xd67e5c
    // 0x8447e8: b               #0x8447f0
    // 0x8447ec: ldur            x2, [fp, #-0x18]
    // 0x8447f0: ldr             x0, [fp, #0x18]
    // 0x8447f4: LoadField: r1 = r0->field_b
    //     0x8447f4: ldur            w1, [x0, #0xb]
    // 0x8447f8: DecompressPointer r1
    //     0x8447f8: add             x1, x1, HEAP, lsl #32
    // 0x8447fc: cmp             w1, NULL
    // 0x844800: b.eq            #0x844d48
    // 0x844804: LoadField: r3 = r1->field_17
    //     0x844804: ldur            w3, [x1, #0x17]
    // 0x844808: DecompressPointer r3
    //     0x844808: add             x3, x3, HEAP, lsl #32
    // 0x84480c: stur            x3, [fp, #-0x28]
    // 0x844810: cmp             w3, NULL
    // 0x844814: b.eq            #0x84495c
    // 0x844818: LoadField: r1 = r2->field_b
    //     0x844818: ldur            w1, [x2, #0xb]
    // 0x84481c: DecompressPointer r1
    //     0x84481c: add             x1, x1, HEAP, lsl #32
    // 0x844820: stur            x1, [fp, #-0x20]
    // 0x844824: cbz             w1, #0x8448a4
    // 0x844828: LoadField: r4 = r2->field_f
    //     0x844828: ldur            w4, [x2, #0xf]
    // 0x84482c: DecompressPointer r4
    //     0x84482c: add             x4, x4, HEAP, lsl #32
    // 0x844830: LoadField: r5 = r4->field_b
    //     0x844830: ldur            w5, [x4, #0xb]
    // 0x844834: DecompressPointer r5
    //     0x844834: add             x5, x5, HEAP, lsl #32
    // 0x844838: cmp             w1, w5
    // 0x84483c: b.ne            #0x84484c
    // 0x844840: SaveReg r2
    //     0x844840: str             x2, [SP, #-8]!
    // 0x844844: r0 = _growToNextCapacity()
    //     0x844844: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x844848: add             SP, SP, #8
    // 0x84484c: ldur            x2, [fp, #-0x18]
    // 0x844850: ldur            x0, [fp, #-0x20]
    // 0x844854: r3 = LoadInt32Instr(r0)
    //     0x844854: sbfx            x3, x0, #1, #0x1f
    // 0x844858: add             x0, x3, #1
    // 0x84485c: lsl             x1, x0, #1
    // 0x844860: StoreField: r2->field_b = r1
    //     0x844860: stur            w1, [x2, #0xb]
    // 0x844864: mov             x1, x3
    // 0x844868: cmp             x1, x0
    // 0x84486c: b.hs            #0x844d4c
    // 0x844870: LoadField: r1 = r2->field_f
    //     0x844870: ldur            w1, [x2, #0xf]
    // 0x844874: DecompressPointer r1
    //     0x844874: add             x1, x1, HEAP, lsl #32
    // 0x844878: ldur            x0, [fp, #-0x30]
    // 0x84487c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84487c: add             x25, x1, x3, lsl #2
    //     0x844880: add             x25, x25, #0xf
    //     0x844884: str             w0, [x25]
    //     0x844888: tbz             w0, #0, #0x8448a4
    //     0x84488c: ldurb           w16, [x1, #-1]
    //     0x844890: ldurb           w17, [x0, #-1]
    //     0x844894: and             x16, x17, x16, lsr #2
    //     0x844898: tst             x16, HEAP, lsr #32
    //     0x84489c: b.eq            #0x8448a4
    //     0x8448a0: bl              #0xd67e5c
    // 0x8448a4: r0 = CupertinoTextSelectionToolbarButton()
    //     0x8448a4: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x8448a8: stur            x0, [fp, #-0x20]
    // 0x8448ac: r16 = "Copy"
    //     0x8448ac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Copy"
    //     0x8448b0: ldr             x16, [x16, #0xdd8]
    // 0x8448b4: stp             x16, x0, [SP, #-0x10]!
    // 0x8448b8: ldur            x16, [fp, #-0x28]
    // 0x8448bc: SaveReg r16
    //     0x8448bc: str             x16, [SP, #-8]!
    // 0x8448c0: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0x8448c0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0x8448c4: ldr             x4, [x4, #0xdb8]
    // 0x8448c8: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x8448c8: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x8448cc: add             SP, SP, #0x18
    // 0x8448d0: ldur            x0, [fp, #-0x18]
    // 0x8448d4: LoadField: r1 = r0->field_b
    //     0x8448d4: ldur            w1, [x0, #0xb]
    // 0x8448d8: DecompressPointer r1
    //     0x8448d8: add             x1, x1, HEAP, lsl #32
    // 0x8448dc: stur            x1, [fp, #-0x28]
    // 0x8448e0: LoadField: r2 = r0->field_f
    //     0x8448e0: ldur            w2, [x0, #0xf]
    // 0x8448e4: DecompressPointer r2
    //     0x8448e4: add             x2, x2, HEAP, lsl #32
    // 0x8448e8: LoadField: r3 = r2->field_b
    //     0x8448e8: ldur            w3, [x2, #0xb]
    // 0x8448ec: DecompressPointer r3
    //     0x8448ec: add             x3, x3, HEAP, lsl #32
    // 0x8448f0: cmp             w1, w3
    // 0x8448f4: b.ne            #0x844904
    // 0x8448f8: SaveReg r0
    //     0x8448f8: str             x0, [SP, #-8]!
    // 0x8448fc: r0 = _growToNextCapacity()
    //     0x8448fc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x844900: add             SP, SP, #8
    // 0x844904: ldur            x2, [fp, #-0x18]
    // 0x844908: ldur            x0, [fp, #-0x28]
    // 0x84490c: r3 = LoadInt32Instr(r0)
    //     0x84490c: sbfx            x3, x0, #1, #0x1f
    // 0x844910: add             x0, x3, #1
    // 0x844914: lsl             x1, x0, #1
    // 0x844918: StoreField: r2->field_b = r1
    //     0x844918: stur            w1, [x2, #0xb]
    // 0x84491c: mov             x1, x3
    // 0x844920: cmp             x1, x0
    // 0x844924: b.hs            #0x844d50
    // 0x844928: LoadField: r1 = r2->field_f
    //     0x844928: ldur            w1, [x2, #0xf]
    // 0x84492c: DecompressPointer r1
    //     0x84492c: add             x1, x1, HEAP, lsl #32
    // 0x844930: ldur            x0, [fp, #-0x20]
    // 0x844934: ArrayStore: r1[r3] = r0  ; List_4
    //     0x844934: add             x25, x1, x3, lsl #2
    //     0x844938: add             x25, x25, #0xf
    //     0x84493c: str             w0, [x25]
    //     0x844940: tbz             w0, #0, #0x84495c
    //     0x844944: ldurb           w16, [x1, #-1]
    //     0x844948: ldurb           w17, [x0, #-1]
    //     0x84494c: and             x16, x17, x16, lsr #2
    //     0x844950: tst             x16, HEAP, lsr #32
    //     0x844954: b.eq            #0x84495c
    //     0x844958: bl              #0xd67e5c
    // 0x84495c: ldr             x0, [fp, #0x18]
    // 0x844960: LoadField: r1 = r0->field_b
    //     0x844960: ldur            w1, [x0, #0xb]
    // 0x844964: DecompressPointer r1
    //     0x844964: add             x1, x1, HEAP, lsl #32
    // 0x844968: cmp             w1, NULL
    // 0x84496c: b.eq            #0x844d54
    // 0x844970: LoadField: r3 = r1->field_1f
    //     0x844970: ldur            w3, [x1, #0x1f]
    // 0x844974: DecompressPointer r3
    //     0x844974: add             x3, x3, HEAP, lsl #32
    // 0x844978: stur            x3, [fp, #-0x28]
    // 0x84497c: cmp             w3, NULL
    // 0x844980: b.eq            #0x844af0
    // 0x844984: LoadField: r4 = r1->field_b
    //     0x844984: ldur            w4, [x1, #0xb]
    // 0x844988: DecompressPointer r4
    //     0x844988: add             x4, x4, HEAP, lsl #32
    // 0x84498c: cmp             w4, NULL
    // 0x844990: b.eq            #0x844af0
    // 0x844994: LoadField: r1 = r4->field_27
    //     0x844994: ldur            w1, [x4, #0x27]
    // 0x844998: DecompressPointer r1
    //     0x844998: add             x1, x1, HEAP, lsl #32
    // 0x84499c: r16 = Instance_ClipboardStatus
    //     0x84499c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc68] Obj!ClipboardStatus@b63491
    //     0x8449a0: ldr             x16, [x16, #0xc68]
    // 0x8449a4: cmp             w1, w16
    // 0x8449a8: b.ne            #0x844af0
    // 0x8449ac: LoadField: r1 = r2->field_b
    //     0x8449ac: ldur            w1, [x2, #0xb]
    // 0x8449b0: DecompressPointer r1
    //     0x8449b0: add             x1, x1, HEAP, lsl #32
    // 0x8449b4: stur            x1, [fp, #-0x20]
    // 0x8449b8: cbz             w1, #0x844a38
    // 0x8449bc: LoadField: r4 = r2->field_f
    //     0x8449bc: ldur            w4, [x2, #0xf]
    // 0x8449c0: DecompressPointer r4
    //     0x8449c0: add             x4, x4, HEAP, lsl #32
    // 0x8449c4: LoadField: r5 = r4->field_b
    //     0x8449c4: ldur            w5, [x4, #0xb]
    // 0x8449c8: DecompressPointer r5
    //     0x8449c8: add             x5, x5, HEAP, lsl #32
    // 0x8449cc: cmp             w1, w5
    // 0x8449d0: b.ne            #0x8449e0
    // 0x8449d4: SaveReg r2
    //     0x8449d4: str             x2, [SP, #-8]!
    // 0x8449d8: r0 = _growToNextCapacity()
    //     0x8449d8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8449dc: add             SP, SP, #8
    // 0x8449e0: ldur            x2, [fp, #-0x18]
    // 0x8449e4: ldur            x0, [fp, #-0x20]
    // 0x8449e8: r3 = LoadInt32Instr(r0)
    //     0x8449e8: sbfx            x3, x0, #1, #0x1f
    // 0x8449ec: add             x0, x3, #1
    // 0x8449f0: lsl             x1, x0, #1
    // 0x8449f4: StoreField: r2->field_b = r1
    //     0x8449f4: stur            w1, [x2, #0xb]
    // 0x8449f8: mov             x1, x3
    // 0x8449fc: cmp             x1, x0
    // 0x844a00: b.hs            #0x844d58
    // 0x844a04: LoadField: r1 = r2->field_f
    //     0x844a04: ldur            w1, [x2, #0xf]
    // 0x844a08: DecompressPointer r1
    //     0x844a08: add             x1, x1, HEAP, lsl #32
    // 0x844a0c: ldur            x0, [fp, #-0x30]
    // 0x844a10: ArrayStore: r1[r3] = r0  ; List_4
    //     0x844a10: add             x25, x1, x3, lsl #2
    //     0x844a14: add             x25, x25, #0xf
    //     0x844a18: str             w0, [x25]
    //     0x844a1c: tbz             w0, #0, #0x844a38
    //     0x844a20: ldurb           w16, [x1, #-1]
    //     0x844a24: ldurb           w17, [x0, #-1]
    //     0x844a28: and             x16, x17, x16, lsr #2
    //     0x844a2c: tst             x16, HEAP, lsr #32
    //     0x844a30: b.eq            #0x844a38
    //     0x844a34: bl              #0xd67e5c
    // 0x844a38: r0 = CupertinoTextSelectionToolbarButton()
    //     0x844a38: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x844a3c: stur            x0, [fp, #-0x20]
    // 0x844a40: r16 = "Paste"
    //     0x844a40: add             x16, PP, #0x28, lsl #12  ; [pp+0x28de0] "Paste"
    //     0x844a44: ldr             x16, [x16, #0xde0]
    // 0x844a48: stp             x16, x0, [SP, #-0x10]!
    // 0x844a4c: ldur            x16, [fp, #-0x28]
    // 0x844a50: SaveReg r16
    //     0x844a50: str             x16, [SP, #-8]!
    // 0x844a54: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0x844a54: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0x844a58: ldr             x4, [x4, #0xdb8]
    // 0x844a5c: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x844a5c: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x844a60: add             SP, SP, #0x18
    // 0x844a64: ldur            x0, [fp, #-0x18]
    // 0x844a68: LoadField: r1 = r0->field_b
    //     0x844a68: ldur            w1, [x0, #0xb]
    // 0x844a6c: DecompressPointer r1
    //     0x844a6c: add             x1, x1, HEAP, lsl #32
    // 0x844a70: stur            x1, [fp, #-0x28]
    // 0x844a74: LoadField: r2 = r0->field_f
    //     0x844a74: ldur            w2, [x0, #0xf]
    // 0x844a78: DecompressPointer r2
    //     0x844a78: add             x2, x2, HEAP, lsl #32
    // 0x844a7c: LoadField: r3 = r2->field_b
    //     0x844a7c: ldur            w3, [x2, #0xb]
    // 0x844a80: DecompressPointer r3
    //     0x844a80: add             x3, x3, HEAP, lsl #32
    // 0x844a84: cmp             w1, w3
    // 0x844a88: b.ne            #0x844a98
    // 0x844a8c: SaveReg r0
    //     0x844a8c: str             x0, [SP, #-8]!
    // 0x844a90: r0 = _growToNextCapacity()
    //     0x844a90: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x844a94: add             SP, SP, #8
    // 0x844a98: ldur            x2, [fp, #-0x18]
    // 0x844a9c: ldur            x0, [fp, #-0x28]
    // 0x844aa0: r3 = LoadInt32Instr(r0)
    //     0x844aa0: sbfx            x3, x0, #1, #0x1f
    // 0x844aa4: add             x0, x3, #1
    // 0x844aa8: lsl             x1, x0, #1
    // 0x844aac: StoreField: r2->field_b = r1
    //     0x844aac: stur            w1, [x2, #0xb]
    // 0x844ab0: mov             x1, x3
    // 0x844ab4: cmp             x1, x0
    // 0x844ab8: b.hs            #0x844d5c
    // 0x844abc: LoadField: r1 = r2->field_f
    //     0x844abc: ldur            w1, [x2, #0xf]
    // 0x844ac0: DecompressPointer r1
    //     0x844ac0: add             x1, x1, HEAP, lsl #32
    // 0x844ac4: ldur            x0, [fp, #-0x20]
    // 0x844ac8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x844ac8: add             x25, x1, x3, lsl #2
    //     0x844acc: add             x25, x25, #0xf
    //     0x844ad0: str             w0, [x25]
    //     0x844ad4: tbz             w0, #0, #0x844af0
    //     0x844ad8: ldurb           w16, [x1, #-1]
    //     0x844adc: ldurb           w17, [x0, #-1]
    //     0x844ae0: and             x16, x17, x16, lsr #2
    //     0x844ae4: tst             x16, HEAP, lsr #32
    //     0x844ae8: b.eq            #0x844af0
    //     0x844aec: bl              #0xd67e5c
    // 0x844af0: ldr             x0, [fp, #0x18]
    // 0x844af4: LoadField: r1 = r0->field_b
    //     0x844af4: ldur            w1, [x0, #0xb]
    // 0x844af8: DecompressPointer r1
    //     0x844af8: add             x1, x1, HEAP, lsl #32
    // 0x844afc: cmp             w1, NULL
    // 0x844b00: b.eq            #0x844d60
    // 0x844b04: LoadField: r0 = r1->field_23
    //     0x844b04: ldur            w0, [x1, #0x23]
    // 0x844b08: DecompressPointer r0
    //     0x844b08: add             x0, x0, HEAP, lsl #32
    // 0x844b0c: stur            x0, [fp, #-0x28]
    // 0x844b10: cmp             w0, NULL
    // 0x844b14: b.eq            #0x844c5c
    // 0x844b18: LoadField: r1 = r2->field_b
    //     0x844b18: ldur            w1, [x2, #0xb]
    // 0x844b1c: DecompressPointer r1
    //     0x844b1c: add             x1, x1, HEAP, lsl #32
    // 0x844b20: stur            x1, [fp, #-0x20]
    // 0x844b24: cbz             w1, #0x844ba4
    // 0x844b28: LoadField: r3 = r2->field_f
    //     0x844b28: ldur            w3, [x2, #0xf]
    // 0x844b2c: DecompressPointer r3
    //     0x844b2c: add             x3, x3, HEAP, lsl #32
    // 0x844b30: LoadField: r4 = r3->field_b
    //     0x844b30: ldur            w4, [x3, #0xb]
    // 0x844b34: DecompressPointer r4
    //     0x844b34: add             x4, x4, HEAP, lsl #32
    // 0x844b38: cmp             w1, w4
    // 0x844b3c: b.ne            #0x844b4c
    // 0x844b40: SaveReg r2
    //     0x844b40: str             x2, [SP, #-8]!
    // 0x844b44: r0 = _growToNextCapacity()
    //     0x844b44: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x844b48: add             SP, SP, #8
    // 0x844b4c: ldur            x2, [fp, #-0x18]
    // 0x844b50: ldur            x0, [fp, #-0x20]
    // 0x844b54: r3 = LoadInt32Instr(r0)
    //     0x844b54: sbfx            x3, x0, #1, #0x1f
    // 0x844b58: add             x0, x3, #1
    // 0x844b5c: lsl             x1, x0, #1
    // 0x844b60: StoreField: r2->field_b = r1
    //     0x844b60: stur            w1, [x2, #0xb]
    // 0x844b64: mov             x1, x3
    // 0x844b68: cmp             x1, x0
    // 0x844b6c: b.hs            #0x844d64
    // 0x844b70: LoadField: r1 = r2->field_f
    //     0x844b70: ldur            w1, [x2, #0xf]
    // 0x844b74: DecompressPointer r1
    //     0x844b74: add             x1, x1, HEAP, lsl #32
    // 0x844b78: ldur            x0, [fp, #-0x30]
    // 0x844b7c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x844b7c: add             x25, x1, x3, lsl #2
    //     0x844b80: add             x25, x25, #0xf
    //     0x844b84: str             w0, [x25]
    //     0x844b88: tbz             w0, #0, #0x844ba4
    //     0x844b8c: ldurb           w16, [x1, #-1]
    //     0x844b90: ldurb           w17, [x0, #-1]
    //     0x844b94: and             x16, x17, x16, lsr #2
    //     0x844b98: tst             x16, HEAP, lsr #32
    //     0x844b9c: b.eq            #0x844ba4
    //     0x844ba0: bl              #0xd67e5c
    // 0x844ba4: r0 = CupertinoTextSelectionToolbarButton()
    //     0x844ba4: bl              #0x844ea0  ; AllocateCupertinoTextSelectionToolbarButtonStub -> CupertinoTextSelectionToolbarButton (size=0x18)
    // 0x844ba8: stur            x0, [fp, #-0x20]
    // 0x844bac: r16 = "Select All"
    //     0x844bac: add             x16, PP, #0x28, lsl #12  ; [pp+0x28df0] "Select All"
    //     0x844bb0: ldr             x16, [x16, #0xdf0]
    // 0x844bb4: stp             x16, x0, [SP, #-0x10]!
    // 0x844bb8: ldur            x16, [fp, #-0x28]
    // 0x844bbc: SaveReg r16
    //     0x844bbc: str             x16, [SP, #-8]!
    // 0x844bc0: r4 = const [0, 0x3, 0x3, 0x2, onPressed, 0x2, null]
    //     0x844bc0: add             x4, PP, #0x28, lsl #12  ; [pp+0x28db8] List(7) [0, 0x3, 0x3, 0x2, "onPressed", 0x2, Null]
    //     0x844bc4: ldr             x4, [x4, #0xdb8]
    // 0x844bc8: r0 = CupertinoTextSelectionToolbarButton.text()
    //     0x844bc8: bl              #0x844d78  ; [package:flutter/src/cupertino/text_selection_toolbar_button.dart] CupertinoTextSelectionToolbarButton::CupertinoTextSelectionToolbarButton.text
    // 0x844bcc: add             SP, SP, #0x18
    // 0x844bd0: ldur            x0, [fp, #-0x18]
    // 0x844bd4: LoadField: r1 = r0->field_b
    //     0x844bd4: ldur            w1, [x0, #0xb]
    // 0x844bd8: DecompressPointer r1
    //     0x844bd8: add             x1, x1, HEAP, lsl #32
    // 0x844bdc: stur            x1, [fp, #-0x28]
    // 0x844be0: LoadField: r2 = r0->field_f
    //     0x844be0: ldur            w2, [x0, #0xf]
    // 0x844be4: DecompressPointer r2
    //     0x844be4: add             x2, x2, HEAP, lsl #32
    // 0x844be8: LoadField: r3 = r2->field_b
    //     0x844be8: ldur            w3, [x2, #0xb]
    // 0x844bec: DecompressPointer r3
    //     0x844bec: add             x3, x3, HEAP, lsl #32
    // 0x844bf0: cmp             w1, w3
    // 0x844bf4: b.ne            #0x844c04
    // 0x844bf8: SaveReg r0
    //     0x844bf8: str             x0, [SP, #-8]!
    // 0x844bfc: r0 = _growToNextCapacity()
    //     0x844bfc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x844c00: add             SP, SP, #8
    // 0x844c04: ldur            x2, [fp, #-0x18]
    // 0x844c08: ldur            x0, [fp, #-0x28]
    // 0x844c0c: r3 = LoadInt32Instr(r0)
    //     0x844c0c: sbfx            x3, x0, #1, #0x1f
    // 0x844c10: add             x0, x3, #1
    // 0x844c14: lsl             x1, x0, #1
    // 0x844c18: StoreField: r2->field_b = r1
    //     0x844c18: stur            w1, [x2, #0xb]
    // 0x844c1c: mov             x1, x3
    // 0x844c20: cmp             x1, x0
    // 0x844c24: b.hs            #0x844d68
    // 0x844c28: LoadField: r1 = r2->field_f
    //     0x844c28: ldur            w1, [x2, #0xf]
    // 0x844c2c: DecompressPointer r1
    //     0x844c2c: add             x1, x1, HEAP, lsl #32
    // 0x844c30: ldur            x0, [fp, #-0x20]
    // 0x844c34: ArrayStore: r1[r3] = r0  ; List_4
    //     0x844c34: add             x25, x1, x3, lsl #2
    //     0x844c38: add             x25, x25, #0xf
    //     0x844c3c: str             w0, [x25]
    //     0x844c40: tbz             w0, #0, #0x844c5c
    //     0x844c44: ldurb           w16, [x1, #-1]
    //     0x844c48: ldurb           w17, [x0, #-1]
    //     0x844c4c: and             x16, x17, x16, lsr #2
    //     0x844c50: tst             x16, HEAP, lsr #32
    //     0x844c54: b.eq            #0x844c5c
    //     0x844c58: bl              #0xd67e5c
    // 0x844c5c: LoadField: r0 = r2->field_b
    //     0x844c5c: ldur            w0, [x2, #0xb]
    // 0x844c60: DecompressPointer r0
    //     0x844c60: add             x0, x0, HEAP, lsl #32
    // 0x844c64: cbnz            w0, #0x844c7c
    // 0x844c68: r0 = Instance_SizedBox
    //     0x844c68: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x844c6c: ldr             x0, [x0, #0x738]
    // 0x844c70: LeaveFrame
    //     0x844c70: mov             SP, fp
    //     0x844c74: ldp             fp, lr, [SP], #0x10
    // 0x844c78: ret
    //     0x844c78: ret             
    // 0x844c7c: ldur            x1, [fp, #-0x10]
    // 0x844c80: ldur            x0, [fp, #-8]
    // 0x844c84: r0 = CupertinoTextSelectionToolbar()
    //     0x844c84: bl              #0x844d6c  ; AllocateCupertinoTextSelectionToolbarStub -> CupertinoTextSelectionToolbar (size=0x1c)
    // 0x844c88: ldur            x1, [fp, #-0x10]
    // 0x844c8c: StoreField: r0->field_b = r1
    //     0x844c8c: stur            w1, [x0, #0xb]
    // 0x844c90: ldur            x1, [fp, #-8]
    // 0x844c94: StoreField: r0->field_f = r1
    //     0x844c94: stur            w1, [x0, #0xf]
    // 0x844c98: ldur            x1, [fp, #-0x18]
    // 0x844c9c: StoreField: r0->field_13 = r1
    //     0x844c9c: stur            w1, [x0, #0x13]
    // 0x844ca0: r1 = Closure: (BuildContext, Offset, bool, Widget) => Widget from Function '_defaultToolbarBuilder@621408280': static.
    //     0x844ca0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28d58] Closure: (BuildContext, Offset, bool, Widget) => Widget from Function '_defaultToolbarBuilder@621408280': static. (0x7fe6e2044eac)
    //     0x844ca4: ldr             x1, [x1, #0xd58]
    // 0x844ca8: StoreField: r0->field_17 = r1
    //     0x844ca8: stur            w1, [x0, #0x17]
    // 0x844cac: LeaveFrame
    //     0x844cac: mov             SP, fp
    //     0x844cb0: ldp             fp, lr, [SP], #0x10
    // 0x844cb4: ret
    //     0x844cb4: ret             
    // 0x844cb8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844cb8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844cbc: b               #0x8442d8
    // 0x844cc0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844cc0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844cc4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844cc4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844cc8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x844cc8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x844ccc: SaveReg d2
    //     0x844ccc: str             q2, [SP, #-0x10]!
    // 0x844cd0: SaveReg r0
    //     0x844cd0: str             x0, [SP, #-8]!
    // 0x844cd4: r0 = AllocateDouble()
    //     0x844cd4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x844cd8: mov             x1, x0
    // 0x844cdc: RestoreReg r0
    //     0x844cdc: ldr             x0, [SP], #8
    // 0x844ce0: RestoreReg d2
    //     0x844ce0: ldr             q2, [SP], #0x10
    // 0x844ce4: b               #0x84445c
    // 0x844ce8: SaveReg d2
    //     0x844ce8: str             q2, [SP, #-0x10]!
    // 0x844cec: SaveReg r0
    //     0x844cec: str             x0, [SP, #-8]!
    // 0x844cf0: r0 = AllocateDouble()
    //     0x844cf0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x844cf4: mov             x1, x0
    // 0x844cf8: RestoreReg r0
    //     0x844cf8: ldr             x0, [SP], #8
    // 0x844cfc: RestoreReg d2
    //     0x844cfc: ldr             q2, [SP], #0x10
    // 0x844d00: b               #0x8444ac
    // 0x844d04: r0 = NullCastErrorSharedWithFPURegs()
    //     0x844d04: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x844d08: stp             q0, q1, [SP, #-0x20]!
    // 0x844d0c: stp             x0, x1, [SP, #-0x10]!
    // 0x844d10: r0 = AllocateDouble()
    //     0x844d10: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x844d14: mov             x2, x0
    // 0x844d18: ldp             x0, x1, [SP], #0x10
    // 0x844d1c: ldp             q0, q1, [SP], #0x20
    // 0x844d20: b               #0x84451c
    // 0x844d24: r0 = NullCastErrorSharedWithFPURegs()
    //     0x844d24: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x844d28: r0 = NullCastErrorSharedWithFPURegs()
    //     0x844d28: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x844d2c: SaveReg d2
    //     0x844d2c: str             q2, [SP, #-0x10]!
    // 0x844d30: r0 = AllocateDouble()
    //     0x844d30: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x844d34: RestoreReg d2
    //     0x844d34: ldr             q2, [SP], #0x10
    // 0x844d38: b               #0x84465c
    // 0x844d3c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844d3c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844d40: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d40: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d44: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d44: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844d48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844d4c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d4c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d50: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d50: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d54: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844d54: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844d58: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d58: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d5c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d5c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844d60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x844d64: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d64: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x844d68: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x844d68: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d9130, size: 0x90
    // 0x9d9130: EnterFrame
    //     0x9d9130: stp             fp, lr, [SP, #-0x10]!
    //     0x9d9134: mov             fp, SP
    // 0x9d9138: AllocStack(0x8)
    //     0x9d9138: sub             SP, SP, #8
    // 0x9d913c: CheckStackOverflow
    //     0x9d913c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d9140: cmp             SP, x16
    //     0x9d9144: b.ls            #0x9d91b4
    // 0x9d9148: ldr             x0, [fp, #0x10]
    // 0x9d914c: LoadField: r1 = r0->field_b
    //     0x9d914c: ldur            w1, [x0, #0xb]
    // 0x9d9150: DecompressPointer r1
    //     0x9d9150: add             x1, x1, HEAP, lsl #32
    // 0x9d9154: cmp             w1, NULL
    // 0x9d9158: b.eq            #0x9d91bc
    // 0x9d915c: LoadField: r2 = r1->field_b
    //     0x9d915c: ldur            w2, [x1, #0xb]
    // 0x9d9160: DecompressPointer r2
    //     0x9d9160: add             x2, x2, HEAP, lsl #32
    // 0x9d9164: stur            x2, [fp, #-8]
    // 0x9d9168: cmp             w2, NULL
    // 0x9d916c: b.eq            #0x9d91a4
    // 0x9d9170: r1 = 1
    //     0x9d9170: mov             x1, #1
    // 0x9d9174: r0 = AllocateContext()
    //     0x9d9174: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d9178: mov             x1, x0
    // 0x9d917c: ldr             x0, [fp, #0x10]
    // 0x9d9180: StoreField: r1->field_f = r0
    //     0x9d9180: stur            w0, [x1, #0xf]
    // 0x9d9184: mov             x2, x1
    // 0x9d9188: r1 = Function '_onChangedClipboardStatus@620300207':.
    //     0x9d9188: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba80] AnonymousClosure: (0x7afe08), in [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7afe50)
    //     0x9d918c: ldr             x1, [x1, #0xa80]
    // 0x9d9190: r0 = AllocateClosure()
    //     0x9d9190: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d9194: ldur            x16, [fp, #-8]
    // 0x9d9198: stp             x0, x16, [SP, #-0x10]!
    // 0x9d919c: r0 = addListener()
    //     0x9d919c: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x9d91a0: add             SP, SP, #0x10
    // 0x9d91a4: r0 = Null
    //     0x9d91a4: mov             x0, NULL
    // 0x9d91a8: LeaveFrame
    //     0x9d91a8: mov             SP, fp
    //     0x9d91ac: ldp             fp, lr, [SP], #0x10
    // 0x9d91b0: ret
    //     0x9d91b0: ret             
    // 0x9d91b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d91b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d91b8: b               #0x9d9148
    // 0x9d91bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d91bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a8e8, size: 0x18
    // 0xa4a8e8: r4 = 7
    //     0xa4a8e8: mov             x4, #7
    // 0xa4a8ec: r1 = Function 'dispose':.
    //     0xa4a8ec: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4ba78] AnonymousClosure: (0xa4a900), in [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::dispose (0xa50a2c)
    //     0xa4a8f0: ldr             x1, [x17, #0xa78]
    // 0xa4a8f4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a8f4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a8f8: LoadField: r0 = r24->field_17
    //     0xa4a8f8: ldur            x0, [x24, #0x17]
    // 0xa4a8fc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a900, size: 0x48
    // 0xa4a900: EnterFrame
    //     0xa4a900: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a904: mov             fp, SP
    // 0xa4a908: ldr             x0, [fp, #0x10]
    // 0xa4a90c: LoadField: r1 = r0->field_17
    //     0xa4a90c: ldur            w1, [x0, #0x17]
    // 0xa4a910: DecompressPointer r1
    //     0xa4a910: add             x1, x1, HEAP, lsl #32
    // 0xa4a914: CheckStackOverflow
    //     0xa4a914: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a918: cmp             SP, x16
    //     0xa4a91c: b.ls            #0xa4a940
    // 0xa4a920: LoadField: r0 = r1->field_f
    //     0xa4a920: ldur            w0, [x1, #0xf]
    // 0xa4a924: DecompressPointer r0
    //     0xa4a924: add             x0, x0, HEAP, lsl #32
    // 0xa4a928: SaveReg r0
    //     0xa4a928: str             x0, [SP, #-8]!
    // 0xa4a92c: r0 = dispose()
    //     0xa4a92c: bl              #0xa50a2c  ; [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::dispose
    // 0xa4a930: add             SP, SP, #8
    // 0xa4a934: LeaveFrame
    //     0xa4a934: mov             SP, fp
    //     0xa4a938: ldp             fp, lr, [SP], #0x10
    // 0xa4a93c: ret
    //     0xa4a93c: ret             
    // 0xa4a940: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a940: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a944: b               #0xa4a920
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50a2c, size: 0x90
    // 0xa50a2c: EnterFrame
    //     0xa50a2c: stp             fp, lr, [SP, #-0x10]!
    //     0xa50a30: mov             fp, SP
    // 0xa50a34: AllocStack(0x8)
    //     0xa50a34: sub             SP, SP, #8
    // 0xa50a38: CheckStackOverflow
    //     0xa50a38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50a3c: cmp             SP, x16
    //     0xa50a40: b.ls            #0xa50ab0
    // 0xa50a44: ldr             x0, [fp, #0x10]
    // 0xa50a48: LoadField: r1 = r0->field_b
    //     0xa50a48: ldur            w1, [x0, #0xb]
    // 0xa50a4c: DecompressPointer r1
    //     0xa50a4c: add             x1, x1, HEAP, lsl #32
    // 0xa50a50: cmp             w1, NULL
    // 0xa50a54: b.eq            #0xa50ab8
    // 0xa50a58: LoadField: r2 = r1->field_b
    //     0xa50a58: ldur            w2, [x1, #0xb]
    // 0xa50a5c: DecompressPointer r2
    //     0xa50a5c: add             x2, x2, HEAP, lsl #32
    // 0xa50a60: stur            x2, [fp, #-8]
    // 0xa50a64: cmp             w2, NULL
    // 0xa50a68: b.eq            #0xa50aa0
    // 0xa50a6c: r1 = 1
    //     0xa50a6c: mov             x1, #1
    // 0xa50a70: r0 = AllocateContext()
    //     0xa50a70: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50a74: mov             x1, x0
    // 0xa50a78: ldr             x0, [fp, #0x10]
    // 0xa50a7c: StoreField: r1->field_f = r0
    //     0xa50a7c: stur            w0, [x1, #0xf]
    // 0xa50a80: mov             x2, x1
    // 0xa50a84: r1 = Function '_onChangedClipboardStatus@620300207':.
    //     0xa50a84: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4ba80] AnonymousClosure: (0x7afe08), in [package:flutter/src/cupertino/text_selection.dart] _CupertinoTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7afe50)
    //     0xa50a88: ldr             x1, [x1, #0xa80]
    // 0xa50a8c: r0 = AllocateClosure()
    //     0xa50a8c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa50a90: ldur            x16, [fp, #-8]
    // 0xa50a94: stp             x0, x16, [SP, #-0x10]!
    // 0xa50a98: r0 = removeListener()
    //     0xa50a98: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0xa50a9c: add             SP, SP, #0x10
    // 0xa50aa0: r0 = Null
    //     0xa50aa0: mov             x0, NULL
    // 0xa50aa4: LeaveFrame
    //     0xa50aa4: mov             SP, fp
    //     0xa50aa8: ldp             fp, lr, [SP], #0x10
    // 0xa50aac: ret
    //     0xa50aac: ret             
    // 0xa50ab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50ab0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50ab4: b               #0xa50a44
    // 0xa50ab8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa50ab8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4174, size: 0x34, field offset: 0xc
//   const constructor, 
class _CupertinoTextSelectionControlsToolbar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa4006c, size: 0x20
    // 0xa4006c: EnterFrame
    //     0xa4006c: stp             fp, lr, [SP, #-0x10]!
    //     0xa40070: mov             fp, SP
    // 0xa40074: r1 = <_CupertinoTextSelectionControlsToolbar>
    //     0xa40074: add             x1, PP, #0x40, lsl #12  ; [pp+0x403d8] TypeArguments: <_CupertinoTextSelectionControlsToolbar>
    //     0xa40078: ldr             x1, [x1, #0x3d8]
    // 0xa4007c: r0 = _CupertinoTextSelectionControlsToolbarState()
    //     0xa4007c: bl              #0xa4008c  ; Allocate_CupertinoTextSelectionControlsToolbarStateStub -> _CupertinoTextSelectionControlsToolbarState (size=0x14)
    // 0xa40080: LeaveFrame
    //     0xa40080: mov             SP, fp
    //     0xa40084: ldp             fp, lr, [SP], #0x10
    // 0xa40088: ret
    //     0xa40088: ret             
  }
}

// class id: 4244, size: 0x8, field offset: 0x8
class CupertinoTextSelectionControls extends TextSelectionControls {

  _ buildHandle(/* No info */) {
    // ** addr: 0xc36dd4, size: 0x420
    // 0xc36dd4: EnterFrame
    //     0xc36dd4: stp             fp, lr, [SP, #-0x10]!
    //     0xc36dd8: mov             fp, SP
    // 0xc36ddc: AllocStack(0x30)
    //     0xc36ddc: sub             SP, SP, #0x30
    // 0xc36de0: CheckStackOverflow
    //     0xc36de0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc36de4: cmp             SP, x16
    //     0xc36de8: b.ls            #0xc37154
    // 0xc36dec: ldr             x16, [fp, #0x28]
    // 0xc36df0: SaveReg r16
    //     0xc36df0: str             x16, [SP, #-8]!
    // 0xc36df4: r0 = of()
    //     0xc36df4: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0xc36df8: add             SP, SP, #8
    // 0xc36dfc: r1 = LoadClassIdInstr(r0)
    //     0xc36dfc: ldur            x1, [x0, #-1]
    //     0xc36e00: ubfx            x1, x1, #0xc, #0x14
    // 0xc36e04: lsl             x1, x1, #1
    // 0xc36e08: r17 = 5322
    //     0xc36e08: mov             x17, #0x14ca
    // 0xc36e0c: cmp             w1, w17
    // 0xc36e10: b.ne            #0xc36e44
    // 0xc36e14: LoadField: r1 = r0->field_b
    //     0xc36e14: ldur            w1, [x0, #0xb]
    // 0xc36e18: DecompressPointer r1
    //     0xc36e18: add             x1, x1, HEAP, lsl #32
    // 0xc36e1c: cmp             w1, NULL
    // 0xc36e20: b.ne            #0xc36e38
    // 0xc36e24: LoadField: r1 = r0->field_1f
    //     0xc36e24: ldur            w1, [x0, #0x1f]
    // 0xc36e28: DecompressPointer r1
    //     0xc36e28: add             x1, x1, HEAP, lsl #32
    // 0xc36e2c: LoadField: r0 = r1->field_b
    //     0xc36e2c: ldur            w0, [x1, #0xb]
    // 0xc36e30: DecompressPointer r0
    //     0xc36e30: add             x0, x0, HEAP, lsl #32
    // 0xc36e34: b               #0xc36e3c
    // 0xc36e38: mov             x0, x1
    // 0xc36e3c: mov             x1, x0
    // 0xc36e40: b               #0xc36e84
    // 0xc36e44: LoadField: r1 = r0->field_27
    //     0xc36e44: ldur            w1, [x0, #0x27]
    // 0xc36e48: DecompressPointer r1
    //     0xc36e48: add             x1, x1, HEAP, lsl #32
    // 0xc36e4c: LoadField: r2 = r1->field_b
    //     0xc36e4c: ldur            w2, [x1, #0xb]
    // 0xc36e50: DecompressPointer r2
    //     0xc36e50: add             x2, x2, HEAP, lsl #32
    // 0xc36e54: cmp             w2, NULL
    // 0xc36e58: b.ne            #0xc36e7c
    // 0xc36e5c: LoadField: r1 = r0->field_23
    //     0xc36e5c: ldur            w1, [x0, #0x23]
    // 0xc36e60: DecompressPointer r1
    //     0xc36e60: add             x1, x1, HEAP, lsl #32
    // 0xc36e64: LoadField: r0 = r1->field_3f
    //     0xc36e64: ldur            w0, [x1, #0x3f]
    // 0xc36e68: DecompressPointer r0
    //     0xc36e68: add             x0, x0, HEAP, lsl #32
    // 0xc36e6c: LoadField: r1 = r0->field_b
    //     0xc36e6c: ldur            w1, [x0, #0xb]
    // 0xc36e70: DecompressPointer r1
    //     0xc36e70: add             x1, x1, HEAP, lsl #32
    // 0xc36e74: mov             x0, x1
    // 0xc36e78: b               #0xc36e80
    // 0xc36e7c: mov             x0, x2
    // 0xc36e80: mov             x1, x0
    // 0xc36e84: ldr             x0, [fp, #0x20]
    // 0xc36e88: stur            x1, [fp, #-8]
    // 0xc36e8c: r0 = _TextSelectionHandlePainter()
    //     0xc36e8c: bl              #0xc371f4  ; Allocate_TextSelectionHandlePainterStub -> _TextSelectionHandlePainter (size=0x10)
    // 0xc36e90: mov             x1, x0
    // 0xc36e94: ldur            x0, [fp, #-8]
    // 0xc36e98: stur            x1, [fp, #-0x10]
    // 0xc36e9c: StoreField: r1->field_b = r0
    //     0xc36e9c: stur            w0, [x1, #0xb]
    // 0xc36ea0: r0 = CustomPaint()
    //     0xc36ea0: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0xc36ea4: mov             x1, x0
    // 0xc36ea8: ldur            x0, [fp, #-0x10]
    // 0xc36eac: stur            x1, [fp, #-8]
    // 0xc36eb0: StoreField: r1->field_f = r0
    //     0xc36eb0: stur            w0, [x1, #0xf]
    // 0xc36eb4: r0 = Instance_Size
    //     0xc36eb4: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0xc36eb8: StoreField: r1->field_17 = r0
    //     0xc36eb8: stur            w0, [x1, #0x17]
    // 0xc36ebc: r0 = false
    //     0xc36ebc: add             x0, NULL, #0x30  ; false
    // 0xc36ec0: StoreField: r1->field_1b = r0
    //     0xc36ec0: stur            w0, [x1, #0x1b]
    // 0xc36ec4: StoreField: r1->field_1f = r0
    //     0xc36ec4: stur            w0, [x1, #0x1f]
    // 0xc36ec8: ldr             x0, [fp, #0x20]
    // 0xc36ecc: LoadField: r2 = r0->field_7
    //     0xc36ecc: ldur            x2, [x0, #7]
    // 0xc36ed0: cmp             x2, #1
    // 0xc36ed4: b.gt            #0xc37140
    // 0xc36ed8: cmp             x2, #0
    // 0xc36edc: b.gt            #0xc36f88
    // 0xc36ee0: ldr             d0, [fp, #0x18]
    // 0xc36ee4: ldr             x16, [fp, #0x30]
    // 0xc36ee8: SaveReg r16
    //     0xc36ee8: str             x16, [SP, #-8]!
    // 0xc36eec: SaveReg d0
    //     0xc36eec: str             d0, [SP, #-8]!
    // 0xc36ef0: r0 = getHandleSize()
    //     0xc36ef0: bl              #0xcbab1c  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0xc36ef4: add             SP, SP, #0x10
    // 0xc36ef8: stur            x0, [fp, #-0x18]
    // 0xc36efc: LoadField: d0 = r0->field_7
    //     0xc36efc: ldur            d0, [x0, #7]
    // 0xc36f00: r1 = inline_Allocate_Double()
    //     0xc36f00: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc36f04: add             x1, x1, #0x10
    //     0xc36f08: cmp             x2, x1
    //     0xc36f0c: b.ls            #0xc3715c
    //     0xc36f10: str             x1, [THR, #0x60]  ; THR::top
    //     0xc36f14: sub             x1, x1, #0xf
    //     0xc36f18: mov             x2, #0xd108
    //     0xc36f1c: movk            x2, #3, lsl #16
    //     0xc36f20: stur            x2, [x1, #-1]
    // 0xc36f24: StoreField: r1->field_7 = d0
    //     0xc36f24: stur            d0, [x1, #7]
    // 0xc36f28: stur            x1, [fp, #-0x10]
    // 0xc36f2c: r0 = SizedBox()
    //     0xc36f2c: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xc36f30: mov             x1, x0
    // 0xc36f34: ldur            x0, [fp, #-0x10]
    // 0xc36f38: StoreField: r1->field_f = r0
    //     0xc36f38: stur            w0, [x1, #0xf]
    // 0xc36f3c: ldur            x0, [fp, #-0x18]
    // 0xc36f40: LoadField: d0 = r0->field_f
    //     0xc36f40: ldur            d0, [x0, #0xf]
    // 0xc36f44: r0 = inline_Allocate_Double()
    //     0xc36f44: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xc36f48: add             x0, x0, #0x10
    //     0xc36f4c: cmp             x2, x0
    //     0xc36f50: b.ls            #0xc37178
    //     0xc36f54: str             x0, [THR, #0x60]  ; THR::top
    //     0xc36f58: sub             x0, x0, #0xf
    //     0xc36f5c: mov             x2, #0xd108
    //     0xc36f60: movk            x2, #3, lsl #16
    //     0xc36f64: stur            x2, [x0, #-1]
    // 0xc36f68: StoreField: r0->field_7 = d0
    //     0xc36f68: stur            d0, [x0, #7]
    // 0xc36f6c: StoreField: r1->field_13 = r0
    //     0xc36f6c: stur            w0, [x1, #0x13]
    // 0xc36f70: ldur            x0, [fp, #-8]
    // 0xc36f74: StoreField: r1->field_b = r0
    //     0xc36f74: stur            w0, [x1, #0xb]
    // 0xc36f78: mov             x0, x1
    // 0xc36f7c: LeaveFrame
    //     0xc36f7c: mov             SP, fp
    //     0xc36f80: ldp             fp, lr, [SP], #0x10
    // 0xc36f84: ret
    //     0xc36f84: ret             
    // 0xc36f88: ldr             d0, [fp, #0x18]
    // 0xc36f8c: mov             x0, x1
    // 0xc36f90: ldr             x16, [fp, #0x30]
    // 0xc36f94: SaveReg r16
    //     0xc36f94: str             x16, [SP, #-8]!
    // 0xc36f98: SaveReg d0
    //     0xc36f98: str             d0, [SP, #-8]!
    // 0xc36f9c: r0 = getHandleSize()
    //     0xc36f9c: bl              #0xcbab1c  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0xc36fa0: add             SP, SP, #0x10
    // 0xc36fa4: stur            x0, [fp, #-0x18]
    // 0xc36fa8: LoadField: d0 = r0->field_7
    //     0xc36fa8: ldur            d0, [x0, #7]
    // 0xc36fac: stur            d0, [fp, #-0x28]
    // 0xc36fb0: r1 = inline_Allocate_Double()
    //     0xc36fb0: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc36fb4: add             x1, x1, #0x10
    //     0xc36fb8: cmp             x2, x1
    //     0xc36fbc: b.ls            #0xc37190
    //     0xc36fc0: str             x1, [THR, #0x60]  ; THR::top
    //     0xc36fc4: sub             x1, x1, #0xf
    //     0xc36fc8: mov             x2, #0xd108
    //     0xc36fcc: movk            x2, #3, lsl #16
    //     0xc36fd0: stur            x2, [x1, #-1]
    // 0xc36fd4: StoreField: r1->field_7 = d0
    //     0xc36fd4: stur            d0, [x1, #7]
    // 0xc36fd8: stur            x1, [fp, #-0x10]
    // 0xc36fdc: r0 = SizedBox()
    //     0xc36fdc: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0xc36fe0: mov             x1, x0
    // 0xc36fe4: ldur            x0, [fp, #-0x10]
    // 0xc36fe8: stur            x1, [fp, #-0x20]
    // 0xc36fec: StoreField: r1->field_f = r0
    //     0xc36fec: stur            w0, [x1, #0xf]
    // 0xc36ff0: ldur            x0, [fp, #-0x18]
    // 0xc36ff4: LoadField: d0 = r0->field_f
    //     0xc36ff4: ldur            d0, [x0, #0xf]
    // 0xc36ff8: stur            d0, [fp, #-0x30]
    // 0xc36ffc: r0 = inline_Allocate_Double()
    //     0xc36ffc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xc37000: add             x0, x0, #0x10
    //     0xc37004: cmp             x2, x0
    //     0xc37008: b.ls            #0xc371ac
    //     0xc3700c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc37010: sub             x0, x0, #0xf
    //     0xc37014: mov             x2, #0xd108
    //     0xc37018: movk            x2, #3, lsl #16
    //     0xc3701c: stur            x2, [x0, #-1]
    // 0xc37020: StoreField: r0->field_7 = d0
    //     0xc37020: stur            d0, [x0, #7]
    // 0xc37024: StoreField: r1->field_13 = r0
    //     0xc37024: stur            w0, [x1, #0x13]
    // 0xc37028: ldur            x0, [fp, #-8]
    // 0xc3702c: StoreField: r1->field_b = r0
    //     0xc3702c: stur            w0, [x1, #0xb]
    // 0xc37030: r0 = Matrix4()
    //     0xc37030: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0xc37034: r4 = 32
    //     0xc37034: mov             x4, #0x20
    // 0xc37038: stur            x0, [fp, #-8]
    // 0xc3703c: r0 = AllocateFloat64Array()
    //     0xc3703c: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0xc37040: mov             x1, x0
    // 0xc37044: ldur            x0, [fp, #-8]
    // 0xc37048: StoreField: r0->field_7 = r1
    //     0xc37048: stur            w1, [x0, #7]
    // 0xc3704c: SaveReg r0
    //     0xc3704c: str             x0, [SP, #-8]!
    // 0xc37050: r0 = setIdentity()
    //     0xc37050: bl              #0x50f090  ; [package:vector_math/vector_math_64.dart] Matrix4::setIdentity
    // 0xc37054: add             SP, SP, #8
    // 0xc37058: ldur            d0, [fp, #-0x28]
    // 0xc3705c: d1 = 2.000000
    //     0xc3705c: fmov            d1, #2.00000000
    // 0xc37060: fdiv            d2, d0, d1
    // 0xc37064: ldur            d3, [fp, #-0x30]
    // 0xc37068: fdiv            d4, d3, d1
    // 0xc3706c: r0 = inline_Allocate_Double()
    //     0xc3706c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc37070: add             x0, x0, #0x10
    //     0xc37074: cmp             x1, x0
    //     0xc37078: b.ls            #0xc371c4
    //     0xc3707c: str             x0, [THR, #0x60]  ; THR::top
    //     0xc37080: sub             x0, x0, #0xf
    //     0xc37084: mov             x1, #0xd108
    //     0xc37088: movk            x1, #3, lsl #16
    //     0xc3708c: stur            x1, [x0, #-1]
    // 0xc37090: StoreField: r0->field_7 = d2
    //     0xc37090: stur            d2, [x0, #7]
    // 0xc37094: ldur            x16, [fp, #-8]
    // 0xc37098: stp             x0, x16, [SP, #-0x10]!
    // 0xc3709c: SaveReg d4
    //     0xc3709c: str             d4, [SP, #-8]!
    // 0xc370a0: r0 = translate()
    //     0xc370a0: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0xc370a4: add             SP, SP, #0x18
    // 0xc370a8: ldur            x16, [fp, #-8]
    // 0xc370ac: SaveReg r16
    //     0xc370ac: str             x16, [SP, #-8]!
    // 0xc370b0: d0 = 3.141593
    //     0xc370b0: ldr             d0, [PP, #0x47c0]  ; [pp+0x47c0] IMM: double(3.141592653589793) from 0x400921fb54442d18
    // 0xc370b4: SaveReg d0
    //     0xc370b4: str             d0, [SP, #-8]!
    // 0xc370b8: r0 = rotateZ()
    //     0xc370b8: bl              #0x6939e4  ; [package:vector_math/vector_math_64.dart] Matrix4::rotateZ
    // 0xc370bc: add             SP, SP, #0x10
    // 0xc370c0: ldur            d0, [fp, #-0x28]
    // 0xc370c4: fneg            d1, d0
    // 0xc370c8: d0 = 2.000000
    //     0xc370c8: fmov            d0, #2.00000000
    // 0xc370cc: fdiv            d2, d1, d0
    // 0xc370d0: ldur            d1, [fp, #-0x30]
    // 0xc370d4: fneg            d3, d1
    // 0xc370d8: fdiv            d1, d3, d0
    // 0xc370dc: r0 = inline_Allocate_Double()
    //     0xc370dc: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc370e0: add             x0, x0, #0x10
    //     0xc370e4: cmp             x1, x0
    //     0xc370e8: b.ls            #0xc371e4
    //     0xc370ec: str             x0, [THR, #0x60]  ; THR::top
    //     0xc370f0: sub             x0, x0, #0xf
    //     0xc370f4: mov             x1, #0xd108
    //     0xc370f8: movk            x1, #3, lsl #16
    //     0xc370fc: stur            x1, [x0, #-1]
    // 0xc37100: StoreField: r0->field_7 = d2
    //     0xc37100: stur            d2, [x0, #7]
    // 0xc37104: ldur            x16, [fp, #-8]
    // 0xc37108: stp             x0, x16, [SP, #-0x10]!
    // 0xc3710c: SaveReg d1
    //     0xc3710c: str             d1, [SP, #-8]!
    // 0xc37110: r0 = translate()
    //     0xc37110: bl              #0x6261d4  ; [package:vector_math/vector_math_64.dart] Matrix4::translate
    // 0xc37114: add             SP, SP, #0x18
    // 0xc37118: r0 = Transform()
    //     0xc37118: bl              #0x8636cc  ; AllocateTransformStub -> Transform (size=0x24)
    // 0xc3711c: ldur            x1, [fp, #-8]
    // 0xc37120: StoreField: r0->field_f = r1
    //     0xc37120: stur            w1, [x0, #0xf]
    // 0xc37124: r1 = true
    //     0xc37124: add             x1, NULL, #0x20  ; true
    // 0xc37128: StoreField: r0->field_1b = r1
    //     0xc37128: stur            w1, [x0, #0x1b]
    // 0xc3712c: ldur            x1, [fp, #-0x20]
    // 0xc37130: StoreField: r0->field_b = r1
    //     0xc37130: stur            w1, [x0, #0xb]
    // 0xc37134: LeaveFrame
    //     0xc37134: mov             SP, fp
    //     0xc37138: ldp             fp, lr, [SP], #0x10
    // 0xc3713c: ret
    //     0xc3713c: ret             
    // 0xc37140: r0 = Instance_SizedBox
    //     0xc37140: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0xc37144: ldr             x0, [x0, #0x738]
    // 0xc37148: LeaveFrame
    //     0xc37148: mov             SP, fp
    //     0xc3714c: ldp             fp, lr, [SP], #0x10
    // 0xc37150: ret
    //     0xc37150: ret             
    // 0xc37154: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc37154: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc37158: b               #0xc36dec
    // 0xc3715c: SaveReg d0
    //     0xc3715c: str             q0, [SP, #-0x10]!
    // 0xc37160: SaveReg r0
    //     0xc37160: str             x0, [SP, #-8]!
    // 0xc37164: r0 = AllocateDouble()
    //     0xc37164: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc37168: mov             x1, x0
    // 0xc3716c: RestoreReg r0
    //     0xc3716c: ldr             x0, [SP], #8
    // 0xc37170: RestoreReg d0
    //     0xc37170: ldr             q0, [SP], #0x10
    // 0xc37174: b               #0xc36f24
    // 0xc37178: SaveReg d0
    //     0xc37178: str             q0, [SP, #-0x10]!
    // 0xc3717c: SaveReg r1
    //     0xc3717c: str             x1, [SP, #-8]!
    // 0xc37180: r0 = AllocateDouble()
    //     0xc37180: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc37184: RestoreReg r1
    //     0xc37184: ldr             x1, [SP], #8
    // 0xc37188: RestoreReg d0
    //     0xc37188: ldr             q0, [SP], #0x10
    // 0xc3718c: b               #0xc36f68
    // 0xc37190: SaveReg d0
    //     0xc37190: str             q0, [SP, #-0x10]!
    // 0xc37194: SaveReg r0
    //     0xc37194: str             x0, [SP, #-8]!
    // 0xc37198: r0 = AllocateDouble()
    //     0xc37198: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc3719c: mov             x1, x0
    // 0xc371a0: RestoreReg r0
    //     0xc371a0: ldr             x0, [SP], #8
    // 0xc371a4: RestoreReg d0
    //     0xc371a4: ldr             q0, [SP], #0x10
    // 0xc371a8: b               #0xc36fd4
    // 0xc371ac: SaveReg d0
    //     0xc371ac: str             q0, [SP, #-0x10]!
    // 0xc371b0: SaveReg r1
    //     0xc371b0: str             x1, [SP, #-8]!
    // 0xc371b4: r0 = AllocateDouble()
    //     0xc371b4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc371b8: RestoreReg r1
    //     0xc371b8: ldr             x1, [SP], #8
    // 0xc371bc: RestoreReg d0
    //     0xc371bc: ldr             q0, [SP], #0x10
    // 0xc371c0: b               #0xc37020
    // 0xc371c4: stp             q3, q4, [SP, #-0x20]!
    // 0xc371c8: stp             q1, q2, [SP, #-0x20]!
    // 0xc371cc: SaveReg d0
    //     0xc371cc: str             q0, [SP, #-0x10]!
    // 0xc371d0: r0 = AllocateDouble()
    //     0xc371d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc371d4: RestoreReg d0
    //     0xc371d4: ldr             q0, [SP], #0x10
    // 0xc371d8: ldp             q1, q2, [SP], #0x20
    // 0xc371dc: ldp             q3, q4, [SP], #0x20
    // 0xc371e0: b               #0xc37090
    // 0xc371e4: stp             q1, q2, [SP, #-0x20]!
    // 0xc371e8: r0 = AllocateDouble()
    //     0xc371e8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc371ec: ldp             q1, q2, [SP], #0x20
    // 0xc371f0: b               #0xc37100
  }
  _ buildToolbar(/* No info */) {
    // ** addr: 0xc392bc, size: 0x198
    // 0xc392bc: EnterFrame
    //     0xc392bc: stp             fp, lr, [SP, #-0x10]!
    //     0xc392c0: mov             fp, SP
    // 0xc392c4: AllocStack(0x20)
    //     0xc392c4: sub             SP, SP, #0x20
    // 0xc392c8: CheckStackOverflow
    //     0xc392c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc392cc: cmp             SP, x16
    //     0xc392d0: b.ls            #0xc3944c
    // 0xc392d4: r1 = 2
    //     0xc392d4: mov             x1, #2
    // 0xc392d8: r0 = AllocateContext()
    //     0xc392d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc392dc: mov             x1, x0
    // 0xc392e0: ldr             x0, [fp, #0x48]
    // 0xc392e4: stur            x1, [fp, #-8]
    // 0xc392e8: StoreField: r1->field_f = r0
    //     0xc392e8: stur            w0, [x1, #0xf]
    // 0xc392ec: ldr             x2, [fp, #0x20]
    // 0xc392f0: StoreField: r1->field_13 = r2
    //     0xc392f0: stur            w2, [x1, #0x13]
    // 0xc392f4: stp             x2, x0, [SP, #-0x10]!
    // 0xc392f8: r0 = canCut()
    //     0xc392f8: bl              #0xc0a7ac  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCut
    // 0xc392fc: add             SP, SP, #0x10
    // 0xc39300: tbnz            w0, #4, #0xc39318
    // 0xc39304: ldur            x2, [fp, #-8]
    // 0xc39308: r1 = Function '<anonymous closure>':.
    //     0xc39308: add             x1, PP, #0x37, lsl #12  ; [pp+0x37c90] AnonymousClosure: (0xc39268), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc3930c: ldr             x1, [x1, #0xc90]
    // 0xc39310: r0 = AllocateClosure()
    //     0xc39310: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39314: b               #0xc3931c
    // 0xc39318: r0 = Null
    //     0xc39318: mov             x0, NULL
    // 0xc3931c: ldur            x2, [fp, #-8]
    // 0xc39320: stur            x0, [fp, #-0x10]
    // 0xc39324: LoadField: r1 = r2->field_13
    //     0xc39324: ldur            w1, [x2, #0x13]
    // 0xc39328: DecompressPointer r1
    //     0xc39328: add             x1, x1, HEAP, lsl #32
    // 0xc3932c: ldr             x16, [fp, #0x48]
    // 0xc39330: stp             x1, x16, [SP, #-0x10]!
    // 0xc39334: r0 = canCopy()
    //     0xc39334: bl              #0xc035f0  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCopy
    // 0xc39338: add             SP, SP, #0x10
    // 0xc3933c: tbnz            w0, #4, #0xc39354
    // 0xc39340: ldur            x2, [fp, #-8]
    // 0xc39344: r1 = Function '<anonymous closure>':.
    //     0xc39344: add             x1, PP, #0x37, lsl #12  ; [pp+0x37c98] AnonymousClosure: (0xc39214), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39348: ldr             x1, [x1, #0xc98]
    // 0xc3934c: r0 = AllocateClosure()
    //     0xc3934c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39350: b               #0xc39358
    // 0xc39354: r0 = Null
    //     0xc39354: mov             x0, NULL
    // 0xc39358: ldur            x2, [fp, #-8]
    // 0xc3935c: stur            x0, [fp, #-0x18]
    // 0xc39360: LoadField: r1 = r2->field_13
    //     0xc39360: ldur            w1, [x2, #0x13]
    // 0xc39364: DecompressPointer r1
    //     0xc39364: add             x1, x1, HEAP, lsl #32
    // 0xc39368: SaveReg r1
    //     0xc39368: str             x1, [SP, #-8]!
    // 0xc3936c: r0 = pasteEnabled()
    //     0xc3936c: bl              #0x7a2b88  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::pasteEnabled
    // 0xc39370: add             SP, SP, #8
    // 0xc39374: tbnz            w0, #4, #0xc3938c
    // 0xc39378: ldur            x2, [fp, #-8]
    // 0xc3937c: r1 = Function '<anonymous closure>':.
    //     0xc3937c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ca0] AnonymousClosure: (0xc391c4), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc39380: ldr             x1, [x1, #0xca0]
    // 0xc39384: r0 = AllocateClosure()
    //     0xc39384: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc39388: b               #0xc39390
    // 0xc3938c: r0 = Null
    //     0xc3938c: mov             x0, NULL
    // 0xc39390: ldur            x2, [fp, #-8]
    // 0xc39394: stur            x0, [fp, #-0x20]
    // 0xc39398: LoadField: r1 = r2->field_13
    //     0xc39398: ldur            w1, [x2, #0x13]
    // 0xc3939c: DecompressPointer r1
    //     0xc3939c: add             x1, x1, HEAP, lsl #32
    // 0xc393a0: ldr             x16, [fp, #0x48]
    // 0xc393a4: stp             x1, x16, [SP, #-0x10]!
    // 0xc393a8: r0 = canSelectAll()
    //     0xc393a8: bl              #0xc38f14  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canSelectAll
    // 0xc393ac: add             SP, SP, #0x10
    // 0xc393b0: tbnz            w0, #4, #0xc393cc
    // 0xc393b4: ldur            x2, [fp, #-8]
    // 0xc393b8: r1 = Function '<anonymous closure>':.
    //     0xc393b8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37ca8] AnonymousClosure: (0xc39460), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc393bc: ldr             x1, [x1, #0xca8]
    // 0xc393c0: r0 = AllocateClosure()
    //     0xc393c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc393c4: mov             x7, x0
    // 0xc393c8: b               #0xc393d0
    // 0xc393cc: r7 = Null
    //     0xc393cc: mov             x7, NULL
    // 0xc393d0: ldr             x6, [fp, #0x40]
    // 0xc393d4: ldr             d0, [fp, #0x38]
    // 0xc393d8: ldr             x5, [fp, #0x30]
    // 0xc393dc: ldr             x4, [fp, #0x28]
    // 0xc393e0: ldr             x3, [fp, #0x18]
    // 0xc393e4: ldur            x2, [fp, #-0x10]
    // 0xc393e8: ldur            x1, [fp, #-0x18]
    // 0xc393ec: ldur            x0, [fp, #-0x20]
    // 0xc393f0: stur            x7, [fp, #-8]
    // 0xc393f4: r0 = _CupertinoTextSelectionControlsToolbar()
    //     0xc393f4: bl              #0xc39454  ; Allocate_CupertinoTextSelectionControlsToolbarStub -> _CupertinoTextSelectionControlsToolbar (size=0x34)
    // 0xc393f8: ldr             x1, [fp, #0x18]
    // 0xc393fc: StoreField: r0->field_b = r1
    //     0xc393fc: stur            w1, [x0, #0xb]
    // 0xc39400: ldr             x1, [fp, #0x28]
    // 0xc39404: StoreField: r0->field_f = r1
    //     0xc39404: stur            w1, [x0, #0xf]
    // 0xc39408: ldr             x1, [fp, #0x40]
    // 0xc3940c: StoreField: r0->field_13 = r1
    //     0xc3940c: stur            w1, [x0, #0x13]
    // 0xc39410: ldur            x1, [fp, #-0x18]
    // 0xc39414: StoreField: r0->field_17 = r1
    //     0xc39414: stur            w1, [x0, #0x17]
    // 0xc39418: ldur            x1, [fp, #-0x10]
    // 0xc3941c: StoreField: r0->field_1b = r1
    //     0xc3941c: stur            w1, [x0, #0x1b]
    // 0xc39420: ldur            x1, [fp, #-0x20]
    // 0xc39424: StoreField: r0->field_1f = r1
    //     0xc39424: stur            w1, [x0, #0x1f]
    // 0xc39428: ldur            x1, [fp, #-8]
    // 0xc3942c: StoreField: r0->field_23 = r1
    //     0xc3942c: stur            w1, [x0, #0x23]
    // 0xc39430: ldr             x1, [fp, #0x30]
    // 0xc39434: StoreField: r0->field_27 = r1
    //     0xc39434: stur            w1, [x0, #0x27]
    // 0xc39438: ldr             d0, [fp, #0x38]
    // 0xc3943c: StoreField: r0->field_2b = d0
    //     0xc3943c: stur            d0, [x0, #0x2b]
    // 0xc39440: LeaveFrame
    //     0xc39440: mov             SP, fp
    //     0xc39444: ldp             fp, lr, [SP], #0x10
    // 0xc39448: ret
    //     0xc39448: ret             
    // 0xc3944c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc3944c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc39450: b               #0xc392d4
  }
  _ getHandleAnchor(/* No info */) {
    // ** addr: 0xc52694, size: 0x150
    // 0xc52694: EnterFrame
    //     0xc52694: stp             fp, lr, [SP, #-0x10]!
    //     0xc52698: mov             fp, SP
    // 0xc5269c: AllocStack(0x10)
    //     0xc5269c: sub             SP, SP, #0x10
    // 0xc526a0: CheckStackOverflow
    //     0xc526a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc526a4: cmp             SP, x16
    //     0xc526a8: b.ls            #0xc527dc
    // 0xc526ac: ldr             x0, [fp, #0x18]
    // 0xc526b0: LoadField: r1 = r0->field_7
    //     0xc526b0: ldur            x1, [x0, #7]
    // 0xc526b4: cmp             x1, #1
    // 0xc526b8: b.gt            #0xc52778
    // 0xc526bc: cmp             x1, #0
    // 0xc526c0: b.gt            #0xc52714
    // 0xc526c4: ldr             d0, [fp, #0x10]
    // 0xc526c8: ldr             x16, [fp, #0x20]
    // 0xc526cc: SaveReg r16
    //     0xc526cc: str             x16, [SP, #-8]!
    // 0xc526d0: SaveReg d0
    //     0xc526d0: str             d0, [SP, #-8]!
    // 0xc526d4: r0 = getHandleSize()
    //     0xc526d4: bl              #0xcbab1c  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0xc526d8: add             SP, SP, #0x10
    // 0xc526dc: LoadField: d0 = r0->field_7
    //     0xc526dc: ldur            d0, [x0, #7]
    // 0xc526e0: d1 = 2.000000
    //     0xc526e0: fmov            d1, #2.00000000
    // 0xc526e4: fdiv            d2, d0, d1
    // 0xc526e8: stur            d2, [fp, #-0x10]
    // 0xc526ec: LoadField: d0 = r0->field_f
    //     0xc526ec: ldur            d0, [x0, #0xf]
    // 0xc526f0: stur            d0, [fp, #-8]
    // 0xc526f4: r0 = Offset()
    //     0xc526f4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc526f8: ldur            d0, [fp, #-0x10]
    // 0xc526fc: StoreField: r0->field_7 = d0
    //     0xc526fc: stur            d0, [x0, #7]
    // 0xc52700: ldur            d0, [fp, #-8]
    // 0xc52704: StoreField: r0->field_f = d0
    //     0xc52704: stur            d0, [x0, #0xf]
    // 0xc52708: LeaveFrame
    //     0xc52708: mov             SP, fp
    //     0xc5270c: ldp             fp, lr, [SP], #0x10
    // 0xc52710: ret
    //     0xc52710: ret             
    // 0xc52714: ldr             d0, [fp, #0x10]
    // 0xc52718: d1 = 2.000000
    //     0xc52718: fmov            d1, #2.00000000
    // 0xc5271c: ldr             x16, [fp, #0x20]
    // 0xc52720: SaveReg r16
    //     0xc52720: str             x16, [SP, #-8]!
    // 0xc52724: SaveReg d0
    //     0xc52724: str             d0, [SP, #-8]!
    // 0xc52728: r0 = getHandleSize()
    //     0xc52728: bl              #0xcbab1c  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0xc5272c: add             SP, SP, #0x10
    // 0xc52730: LoadField: d0 = r0->field_7
    //     0xc52730: ldur            d0, [x0, #7]
    // 0xc52734: d1 = 2.000000
    //     0xc52734: fmov            d1, #2.00000000
    // 0xc52738: fdiv            d2, d0, d1
    // 0xc5273c: stur            d2, [fp, #-0x10]
    // 0xc52740: LoadField: d0 = r0->field_f
    //     0xc52740: ldur            d0, [x0, #0xf]
    // 0xc52744: d1 = 12.000000
    //     0xc52744: fmov            d1, #12.00000000
    // 0xc52748: fsub            d3, d0, d1
    // 0xc5274c: d0 = 1.500000
    //     0xc5274c: fmov            d0, #1.50000000
    // 0xc52750: fadd            d1, d3, d0
    // 0xc52754: stur            d1, [fp, #-8]
    // 0xc52758: r0 = Offset()
    //     0xc52758: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc5275c: ldur            d0, [fp, #-0x10]
    // 0xc52760: StoreField: r0->field_7 = d0
    //     0xc52760: stur            d0, [x0, #7]
    // 0xc52764: ldur            d0, [fp, #-8]
    // 0xc52768: StoreField: r0->field_f = d0
    //     0xc52768: stur            d0, [x0, #0xf]
    // 0xc5276c: LeaveFrame
    //     0xc5276c: mov             SP, fp
    //     0xc52770: ldp             fp, lr, [SP], #0x10
    // 0xc52774: ret
    //     0xc52774: ret             
    // 0xc52778: ldr             d0, [fp, #0x10]
    // 0xc5277c: d1 = 2.000000
    //     0xc5277c: fmov            d1, #2.00000000
    // 0xc52780: ldr             x16, [fp, #0x20]
    // 0xc52784: SaveReg r16
    //     0xc52784: str             x16, [SP, #-8]!
    // 0xc52788: SaveReg d0
    //     0xc52788: str             d0, [SP, #-8]!
    // 0xc5278c: r0 = getHandleSize()
    //     0xc5278c: bl              #0xcbab1c  ; [package:flutter/src/cupertino/text_selection.dart] CupertinoTextSelectionControls::getHandleSize
    // 0xc52790: add             SP, SP, #0x10
    // 0xc52794: LoadField: d0 = r0->field_7
    //     0xc52794: ldur            d0, [x0, #7]
    // 0xc52798: d1 = 2.000000
    //     0xc52798: fmov            d1, #2.00000000
    // 0xc5279c: fdiv            d2, d0, d1
    // 0xc527a0: stur            d2, [fp, #-0x10]
    // 0xc527a4: LoadField: d0 = r0->field_f
    //     0xc527a4: ldur            d0, [x0, #0xf]
    // 0xc527a8: ldr             d3, [fp, #0x10]
    // 0xc527ac: fsub            d4, d0, d3
    // 0xc527b0: fdiv            d0, d4, d1
    // 0xc527b4: fadd            d1, d3, d0
    // 0xc527b8: stur            d1, [fp, #-8]
    // 0xc527bc: r0 = Offset()
    //     0xc527bc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xc527c0: ldur            d0, [fp, #-0x10]
    // 0xc527c4: StoreField: r0->field_7 = d0
    //     0xc527c4: stur            d0, [x0, #7]
    // 0xc527c8: ldur            d0, [fp, #-8]
    // 0xc527cc: StoreField: r0->field_f = d0
    //     0xc527cc: stur            d0, [x0, #0xf]
    // 0xc527d0: LeaveFrame
    //     0xc527d0: mov             SP, fp
    //     0xc527d4: ldp             fp, lr, [SP], #0x10
    // 0xc527d8: ret
    //     0xc527d8: ret             
    // 0xc527dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc527dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc527e0: b               #0xc526ac
  }
  _ getHandleSize(/* No info */) {
    // ** addr: 0xcbab1c, size: 0x44
    // 0xcbab1c: EnterFrame
    //     0xcbab1c: stp             fp, lr, [SP, #-0x10]!
    //     0xcbab20: mov             fp, SP
    // 0xcbab24: AllocStack(0x8)
    //     0xcbab24: sub             SP, SP, #8
    // 0xcbab28: d1 = 12.000000
    //     0xcbab28: fmov            d1, #12.00000000
    // 0xcbab2c: d0 = 1.500000
    //     0xcbab2c: fmov            d0, #1.50000000
    // 0xcbab30: ldr             d2, [fp, #0x10]
    // 0xcbab34: fadd            d3, d2, d1
    // 0xcbab38: fsub            d2, d3, d0
    // 0xcbab3c: stur            d2, [fp, #-8]
    // 0xcbab40: r0 = Size()
    //     0xcbab40: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0xcbab44: d0 = 12.000000
    //     0xcbab44: fmov            d0, #12.00000000
    // 0xcbab48: StoreField: r0->field_7 = d0
    //     0xcbab48: stur            d0, [x0, #7]
    // 0xcbab4c: ldur            d0, [fp, #-8]
    // 0xcbab50: StoreField: r0->field_f = d0
    //     0xcbab50: stur            d0, [x0, #0xf]
    // 0xcbab54: LeaveFrame
    //     0xcbab54: mov             SP, fp
    //     0xcbab58: ldp             fp, lr, [SP], #0x10
    // 0xcbab5c: ret
    //     0xcbab5c: ret             
  }
}

// class id: 4245, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class _CupertinoTextSelectionHandleControls&CupertinoTextSelectionControls&TextSelectionHandleControls extends CupertinoTextSelectionControls
     with TextSelectionHandleControls {
}

// class id: 4246, size: 0x8, field offset: 0x8
class CupertinoTextSelectionHandleControls extends _CupertinoTextSelectionHandleControls&CupertinoTextSelectionControls&TextSelectionHandleControls {
}

// class id: 4378, size: 0x10, field offset: 0xc
//   const constructor, 
class _TextSelectionHandlePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa6ec40, size: 0x1a4
    // 0xa6ec40: EnterFrame
    //     0xa6ec40: stp             fp, lr, [SP, #-0x10]!
    //     0xa6ec44: mov             fp, SP
    // 0xa6ec48: AllocStack(0x28)
    //     0xa6ec48: sub             SP, SP, #0x28
    // 0xa6ec4c: CheckStackOverflow
    //     0xa6ec4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6ec50: cmp             SP, x16
    //     0xa6ec54: b.ls            #0xa6eddc
    // 0xa6ec58: r16 = 112
    //     0xa6ec58: mov             x16, #0x70
    // 0xa6ec5c: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6ec60: r0 = ByteData()
    //     0xa6ec60: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6ec64: add             SP, SP, #0x10
    // 0xa6ec68: stur            x0, [fp, #-8]
    // 0xa6ec6c: r0 = Paint()
    //     0xa6ec6c: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6ec70: mov             x1, x0
    // 0xa6ec74: ldur            x0, [fp, #-8]
    // 0xa6ec78: stur            x1, [fp, #-0x10]
    // 0xa6ec7c: StoreField: r1->field_7 = r0
    //     0xa6ec7c: stur            w0, [x1, #7]
    // 0xa6ec80: ldr             x2, [fp, #0x20]
    // 0xa6ec84: LoadField: r3 = r2->field_b
    //     0xa6ec84: ldur            w3, [x2, #0xb]
    // 0xa6ec88: DecompressPointer r3
    //     0xa6ec88: add             x3, x3, HEAP, lsl #32
    // 0xa6ec8c: r2 = LoadClassIdInstr(r3)
    //     0xa6ec8c: ldur            x2, [x3, #-1]
    //     0xa6ec90: ubfx            x2, x2, #0xc, #0x14
    // 0xa6ec94: lsl             x2, x2, #1
    // 0xa6ec98: r17 = 10124
    //     0xa6ec98: mov             x17, #0x278c
    // 0xa6ec9c: cmp             w2, w17
    // 0xa6eca0: b.gt            #0xa6ecb0
    // 0xa6eca4: r17 = 10122
    //     0xa6eca4: mov             x17, #0x278a
    // 0xa6eca8: cmp             w2, w17
    // 0xa6ecac: b.ge            #0xa6ecc8
    // 0xa6ecb0: r17 = 10114
    //     0xa6ecb0: mov             x17, #0x2782
    // 0xa6ecb4: cmp             w2, w17
    // 0xa6ecb8: b.eq            #0xa6ecc8
    // 0xa6ecbc: r17 = 10118
    //     0xa6ecbc: mov             x17, #0x2786
    // 0xa6ecc0: cmp             w2, w17
    // 0xa6ecc4: b.ne            #0xa6ecd4
    // 0xa6ecc8: LoadField: r2 = r3->field_7
    //     0xa6ecc8: ldur            x2, [x3, #7]
    // 0xa6eccc: mov             x3, x2
    // 0xa6ecd0: b               #0xa6ece0
    // 0xa6ecd4: LoadField: r2 = r3->field_f
    //     0xa6ecd4: ldur            w2, [x3, #0xf]
    // 0xa6ecd8: DecompressPointer r2
    //     0xa6ecd8: add             x2, x2, HEAP, lsl #32
    // 0xa6ecdc: LoadField: r3 = r2->field_7
    //     0xa6ecdc: ldur            x3, [x2, #7]
    // 0xa6ece0: ldr             x2, [fp, #0x10]
    // 0xa6ece4: eor             x4, x3, #0xff000000
    // 0xa6ece8: LoadField: r3 = r0->field_17
    //     0xa6ece8: ldur            w3, [x0, #0x17]
    // 0xa6ecec: DecompressPointer r3
    //     0xa6ecec: add             x3, x3, HEAP, lsl #32
    // 0xa6ecf0: sxtw            x4, w4
    // 0xa6ecf4: LoadField: r0 = r3->field_7
    //     0xa6ecf4: ldur            x0, [x3, #7]
    // 0xa6ecf8: str             w4, [x0, #4]
    // 0xa6ecfc: r0 = Rect()
    //     0xa6ecfc: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa6ed00: stur            x0, [fp, #-8]
    // 0xa6ed04: r16 = Instance_Offset
    //     0xa6ed04: add             x16, PP, #0x40, lsl #12  ; [pp+0x403f8] Obj!Offset@b5f251
    //     0xa6ed08: ldr             x16, [x16, #0x3f8]
    // 0xa6ed0c: stp             x16, x0, [SP, #-0x10]!
    // 0xa6ed10: r16 = 12.000000
    //     0xa6ed10: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fd90] 12
    //     0xa6ed14: ldr             x16, [x16, #0xd90]
    // 0xa6ed18: SaveReg r16
    //     0xa6ed18: str             x16, [SP, #-8]!
    // 0xa6ed1c: d0 = 12.000000
    //     0xa6ed1c: fmov            d0, #12.00000000
    // 0xa6ed20: SaveReg d0
    //     0xa6ed20: str             d0, [SP, #-8]!
    // 0xa6ed24: r0 = Rect.fromCenter()
    //     0xa6ed24: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0xa6ed28: add             SP, SP, #0x20
    // 0xa6ed2c: ldr             x0, [fp, #0x10]
    // 0xa6ed30: LoadField: d0 = r0->field_f
    //     0xa6ed30: ldur            d0, [x0, #0xf]
    // 0xa6ed34: stur            d0, [fp, #-0x28]
    // 0xa6ed38: r0 = Offset()
    //     0xa6ed38: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6ed3c: d0 = 7.000000
    //     0xa6ed3c: fmov            d0, #7.00000000
    // 0xa6ed40: stur            x0, [fp, #-0x18]
    // 0xa6ed44: StoreField: r0->field_7 = d0
    //     0xa6ed44: stur            d0, [x0, #7]
    // 0xa6ed48: ldur            d0, [fp, #-0x28]
    // 0xa6ed4c: StoreField: r0->field_f = d0
    //     0xa6ed4c: stur            d0, [x0, #0xf]
    // 0xa6ed50: r0 = Rect()
    //     0xa6ed50: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xa6ed54: stur            x0, [fp, #-0x20]
    // 0xa6ed58: r16 = Instance_Offset
    //     0xa6ed58: add             x16, PP, #0x40, lsl #12  ; [pp+0x40400] Obj!Offset@b5f231
    //     0xa6ed5c: ldr             x16, [x16, #0x400]
    // 0xa6ed60: stp             x16, x0, [SP, #-0x10]!
    // 0xa6ed64: ldur            x16, [fp, #-0x18]
    // 0xa6ed68: SaveReg r16
    //     0xa6ed68: str             x16, [SP, #-8]!
    // 0xa6ed6c: r0 = Rect.fromPoints()
    //     0xa6ed6c: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0xa6ed70: add             SP, SP, #0x18
    // 0xa6ed74: r0 = Path()
    //     0xa6ed74: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6ed78: stur            x0, [fp, #-0x18]
    // 0xa6ed7c: SaveReg r0
    //     0xa6ed7c: str             x0, [SP, #-8]!
    // 0xa6ed80: r0 = _constructor()
    //     0xa6ed80: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6ed84: add             SP, SP, #8
    // 0xa6ed88: ldur            x16, [fp, #-0x18]
    // 0xa6ed8c: ldur            lr, [fp, #-8]
    // 0xa6ed90: stp             lr, x16, [SP, #-0x10]!
    // 0xa6ed94: r0 = addOval()
    //     0xa6ed94: bl              #0x6633ac  ; [dart:ui] Path::addOval
    // 0xa6ed98: add             SP, SP, #0x10
    // 0xa6ed9c: ldur            x16, [fp, #-0x18]
    // 0xa6eda0: ldur            lr, [fp, #-0x20]
    // 0xa6eda4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6eda8: r0 = addRect()
    //     0xa6eda8: bl              #0x71a7b0  ; [dart:ui] Path::addRect
    // 0xa6edac: add             SP, SP, #0x10
    // 0xa6edb0: ldr             x16, [fp, #0x18]
    // 0xa6edb4: ldur            lr, [fp, #-0x18]
    // 0xa6edb8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6edbc: ldur            x16, [fp, #-0x10]
    // 0xa6edc0: SaveReg r16
    //     0xa6edc0: str             x16, [SP, #-8]!
    // 0xa6edc4: r0 = drawPath()
    //     0xa6edc4: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6edc8: add             SP, SP, #0x18
    // 0xa6edcc: r0 = Null
    //     0xa6edcc: mov             x0, NULL
    // 0xa6edd0: LeaveFrame
    //     0xa6edd0: mov             SP, fp
    //     0xa6edd4: ldp             fp, lr, [SP], #0x10
    // 0xa6edd8: ret
    //     0xa6edd8: ret             
    // 0xa6eddc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6eddc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6ede0: b               #0xa6ec58
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa799c8, size: 0x1cc
    // 0xa799c8: EnterFrame
    //     0xa799c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa799cc: mov             fp, SP
    // 0xa799d0: AllocStack(0x18)
    //     0xa799d0: sub             SP, SP, #0x18
    // 0xa799d4: CheckStackOverflow
    //     0xa799d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa799d8: cmp             SP, x16
    //     0xa799dc: b.ls            #0xa79b8c
    // 0xa799e0: ldr             x0, [fp, #0x10]
    // 0xa799e4: r2 = Null
    //     0xa799e4: mov             x2, NULL
    // 0xa799e8: r1 = Null
    //     0xa799e8: mov             x1, NULL
    // 0xa799ec: r4 = 59
    //     0xa799ec: mov             x4, #0x3b
    // 0xa799f0: branchIfSmi(r0, 0xa799fc)
    //     0xa799f0: tbz             w0, #0, #0xa799fc
    // 0xa799f4: r4 = LoadClassIdInstr(r0)
    //     0xa799f4: ldur            x4, [x0, #-1]
    //     0xa799f8: ubfx            x4, x4, #0xc, #0x14
    // 0xa799fc: r17 = 4378
    //     0xa799fc: mov             x17, #0x111a
    // 0xa79a00: cmp             x4, x17
    // 0xa79a04: b.eq            #0xa79a1c
    // 0xa79a08: r8 = _TextSelectionHandlePainter
    //     0xa79a08: add             x8, PP, #0x40, lsl #12  ; [pp+0x403e0] Type: _TextSelectionHandlePainter
    //     0xa79a0c: ldr             x8, [x8, #0x3e0]
    // 0xa79a10: r3 = Null
    //     0xa79a10: add             x3, PP, #0x40, lsl #12  ; [pp+0x403e8] Null
    //     0xa79a14: ldr             x3, [x3, #0x3e8]
    // 0xa79a18: r0 = DefaultTypeTest()
    //     0xa79a18: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa79a1c: ldr             x0, [fp, #0x18]
    // 0xa79a20: LoadField: r1 = r0->field_b
    //     0xa79a20: ldur            w1, [x0, #0xb]
    // 0xa79a24: DecompressPointer r1
    //     0xa79a24: add             x1, x1, HEAP, lsl #32
    // 0xa79a28: ldr             x0, [fp, #0x10]
    // 0xa79a2c: stur            x1, [fp, #-0x18]
    // 0xa79a30: LoadField: r2 = r0->field_b
    //     0xa79a30: ldur            w2, [x0, #0xb]
    // 0xa79a34: DecompressPointer r2
    //     0xa79a34: add             x2, x2, HEAP, lsl #32
    // 0xa79a38: stur            x2, [fp, #-0x10]
    // 0xa79a3c: r0 = LoadClassIdInstr(r1)
    //     0xa79a3c: ldur            x0, [x1, #-1]
    //     0xa79a40: ubfx            x0, x0, #0xc, #0x14
    // 0xa79a44: lsl             x0, x0, #1
    // 0xa79a48: stur            x0, [fp, #-8]
    // 0xa79a4c: r17 = 10114
    //     0xa79a4c: mov             x17, #0x2782
    // 0xa79a50: cmp             w0, w17
    // 0xa79a54: b.eq            #0xa79a64
    // 0xa79a58: r17 = 10118
    //     0xa79a58: mov             x17, #0x2786
    // 0xa79a5c: cmp             w0, w17
    // 0xa79a60: b.ne            #0xa79b50
    // 0xa79a64: cmp             w1, w2
    // 0xa79a68: b.ne            #0xa79a74
    // 0xa79a6c: r1 = true
    //     0xa79a6c: add             x1, NULL, #0x20  ; true
    // 0xa79a70: b               #0xa79b7c
    // 0xa79a74: stp             x1, x2, [SP, #-0x10]!
    // 0xa79a78: r0 = _haveSameRuntimeType()
    //     0xa79a78: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa79a7c: add             SP, SP, #0x10
    // 0xa79a80: tbz             w0, #4, #0xa79a8c
    // 0xa79a84: r1 = false
    //     0xa79a84: add             x1, NULL, #0x30  ; false
    // 0xa79a88: b               #0xa79b7c
    // 0xa79a8c: ldur            x0, [fp, #-0x10]
    // 0xa79a90: r1 = LoadClassIdInstr(r0)
    //     0xa79a90: ldur            x1, [x0, #-1]
    //     0xa79a94: ubfx            x1, x1, #0xc, #0x14
    // 0xa79a98: lsl             x1, x1, #1
    // 0xa79a9c: r17 = 10124
    //     0xa79a9c: mov             x17, #0x278c
    // 0xa79aa0: cmp             w1, w17
    // 0xa79aa4: b.gt            #0xa79ab4
    // 0xa79aa8: r17 = 10122
    //     0xa79aa8: mov             x17, #0x278a
    // 0xa79aac: cmp             w1, w17
    // 0xa79ab0: b.ge            #0xa79acc
    // 0xa79ab4: r17 = 10114
    //     0xa79ab4: mov             x17, #0x2782
    // 0xa79ab8: cmp             w1, w17
    // 0xa79abc: b.eq            #0xa79acc
    // 0xa79ac0: r17 = 10118
    //     0xa79ac0: mov             x17, #0x2786
    // 0xa79ac4: cmp             w1, w17
    // 0xa79ac8: b.ne            #0xa79ad4
    // 0xa79acc: LoadField: r1 = r0->field_7
    //     0xa79acc: ldur            x1, [x0, #7]
    // 0xa79ad0: b               #0xa79ae4
    // 0xa79ad4: LoadField: r1 = r0->field_f
    //     0xa79ad4: ldur            w1, [x0, #0xf]
    // 0xa79ad8: DecompressPointer r1
    //     0xa79ad8: add             x1, x1, HEAP, lsl #32
    // 0xa79adc: LoadField: r0 = r1->field_7
    //     0xa79adc: ldur            x0, [x1, #7]
    // 0xa79ae0: mov             x1, x0
    // 0xa79ae4: ldur            x0, [fp, #-8]
    // 0xa79ae8: r17 = 10124
    //     0xa79ae8: mov             x17, #0x278c
    // 0xa79aec: cmp             w0, w17
    // 0xa79af0: b.gt            #0xa79b00
    // 0xa79af4: r17 = 10122
    //     0xa79af4: mov             x17, #0x278a
    // 0xa79af8: cmp             w0, w17
    // 0xa79afc: b.ge            #0xa79b18
    // 0xa79b00: r17 = 10114
    //     0xa79b00: mov             x17, #0x2782
    // 0xa79b04: cmp             w0, w17
    // 0xa79b08: b.eq            #0xa79b18
    // 0xa79b0c: r17 = 10118
    //     0xa79b0c: mov             x17, #0x2786
    // 0xa79b10: cmp             w0, w17
    // 0xa79b14: b.ne            #0xa79b24
    // 0xa79b18: ldur            x2, [fp, #-0x18]
    // 0xa79b1c: LoadField: r0 = r2->field_7
    //     0xa79b1c: ldur            x0, [x2, #7]
    // 0xa79b20: b               #0xa79b38
    // 0xa79b24: ldur            x2, [fp, #-0x18]
    // 0xa79b28: LoadField: r0 = r2->field_f
    //     0xa79b28: ldur            w0, [x2, #0xf]
    // 0xa79b2c: DecompressPointer r0
    //     0xa79b2c: add             x0, x0, HEAP, lsl #32
    // 0xa79b30: LoadField: r2 = r0->field_7
    //     0xa79b30: ldur            x2, [x0, #7]
    // 0xa79b34: mov             x0, x2
    // 0xa79b38: cmp             x1, x0
    // 0xa79b3c: r16 = true
    //     0xa79b3c: add             x16, NULL, #0x20  ; true
    // 0xa79b40: r17 = false
    //     0xa79b40: add             x17, NULL, #0x30  ; false
    // 0xa79b44: csel            x2, x16, x17, eq
    // 0xa79b48: mov             x1, x2
    // 0xa79b4c: b               #0xa79b7c
    // 0xa79b50: mov             x0, x2
    // 0xa79b54: mov             x2, x1
    // 0xa79b58: r1 = LoadClassIdInstr(r2)
    //     0xa79b58: ldur            x1, [x2, #-1]
    //     0xa79b5c: ubfx            x1, x1, #0xc, #0x14
    // 0xa79b60: stp             x0, x2, [SP, #-0x10]!
    // 0xa79b64: mov             x0, x1
    // 0xa79b68: mov             lr, x0
    // 0xa79b6c: ldr             lr, [x21, lr, lsl #3]
    // 0xa79b70: blr             lr
    // 0xa79b74: add             SP, SP, #0x10
    // 0xa79b78: mov             x1, x0
    // 0xa79b7c: eor             x0, x1, #0x10
    // 0xa79b80: LeaveFrame
    //     0xa79b80: mov             SP, fp
    //     0xa79b84: ldp             fp, lr, [SP], #0x10
    // 0xa79b88: ret
    //     0xa79b88: ret             
    // 0xa79b8c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa79b8c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa79b90: b               #0xa799e0
  }
}

// lib: , url: package:flutter/src/cupertino/localizations.dart

// class id: 1049095, size: 0x8
class :: {
}

// class id: 4230, size: 0x8, field offset: 0x8
//   const constructor, 
class DefaultCupertinoLocalizations extends Object
    implements CupertinoLocalizations {

  static _ load(/* No info */) {
    // ** addr: 0xcbaba0, size: 0x2c
    // 0xcbaba0: EnterFrame
    //     0xcbaba0: stp             fp, lr, [SP, #-0x10]!
    //     0xcbaba4: mov             fp, SP
    // 0xcbaba8: r1 = <CupertinoLocalizations>
    //     0xcbaba8: add             x1, PP, #0x28, lsl #12  ; [pp+0x28df8] TypeArguments: <CupertinoLocalizations>
    //     0xcbabac: ldr             x1, [x1, #0xdf8]
    // 0xcbabb0: r0 = SynchronousFuture()
    //     0xcbabb0: bl              #0x7d1294  ; AllocateSynchronousFutureStub -> SynchronousFuture<X0> (size=0x10)
    // 0xcbabb4: r1 = Instance_DefaultCupertinoLocalizations
    //     0xcbabb4: add             x1, PP, #0x40, lsl #12  ; [pp+0x404c8] Obj!DefaultCupertinoLocalizations@b4f251
    //     0xcbabb8: ldr             x1, [x1, #0x4c8]
    // 0xcbabbc: StoreField: r0->field_b = r1
    //     0xcbabbc: stur            w1, [x0, #0xb]
    // 0xcbabc0: LeaveFrame
    //     0xcbabc0: mov             SP, fp
    //     0xcbabc4: ldp             fp, lr, [SP], #0x10
    // 0xcbabc8: ret
    //     0xcbabc8: ret             
  }
}

// class id: 4234, size: 0xc, field offset: 0xc
//   const constructor, 
class _CupertinoLocalizationsDelegate extends LocalizationsDelegate<CupertinoLocalizations> {

  _ toString(/* No info */) {
    // ** addr: 0xad755c, size: 0xc
    // 0xad755c: r0 = "DefaultCupertinoLocalizations.delegate(en_US)"
    //     0xad755c: add             x0, PP, #0x22, lsl #12  ; [pp+0x22130] "DefaultCupertinoLocalizations.delegate(en_US)"
    //     0xad7560: ldr             x0, [x0, #0x130]
    // 0xad7564: ret
    //     0xad7564: ret             
  }
  _ shouldReload(/* No info */) {
    // ** addr: 0xcb2df4, size: 0x54
    // 0xcb2df4: EnterFrame
    //     0xcb2df4: stp             fp, lr, [SP, #-0x10]!
    //     0xcb2df8: mov             fp, SP
    // 0xcb2dfc: ldr             x0, [fp, #0x10]
    // 0xcb2e00: r2 = Null
    //     0xcb2e00: mov             x2, NULL
    // 0xcb2e04: r1 = Null
    //     0xcb2e04: mov             x1, NULL
    // 0xcb2e08: r4 = 59
    //     0xcb2e08: mov             x4, #0x3b
    // 0xcb2e0c: branchIfSmi(r0, 0xcb2e18)
    //     0xcb2e0c: tbz             w0, #0, #0xcb2e18
    // 0xcb2e10: r4 = LoadClassIdInstr(r0)
    //     0xcb2e10: ldur            x4, [x0, #-1]
    //     0xcb2e14: ubfx            x4, x4, #0xc, #0x14
    // 0xcb2e18: r17 = 4234
    //     0xcb2e18: mov             x17, #0x108a
    // 0xcb2e1c: cmp             x4, x17
    // 0xcb2e20: b.eq            #0xcb2e38
    // 0xcb2e24: r8 = _CupertinoLocalizationsDelegate<CupertinoLocalizations>
    //     0xcb2e24: add             x8, PP, #0x40, lsl #12  ; [pp+0x404b0] Type: _CupertinoLocalizationsDelegate<CupertinoLocalizations>
    //     0xcb2e28: ldr             x8, [x8, #0x4b0]
    // 0xcb2e2c: r3 = Null
    //     0xcb2e2c: add             x3, PP, #0x40, lsl #12  ; [pp+0x404b8] Null
    //     0xcb2e30: ldr             x3, [x3, #0x4b8]
    // 0xcb2e34: r0 = DefaultTypeTest()
    //     0xcb2e34: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcb2e38: r0 = false
    //     0xcb2e38: add             x0, NULL, #0x30  ; false
    // 0xcb2e3c: LeaveFrame
    //     0xcb2e3c: mov             SP, fp
    //     0xcb2e40: ldp             fp, lr, [SP], #0x10
    // 0xcb2e44: ret
    //     0xcb2e44: ret             
  }
  _ load(/* No info */) {
    // ** addr: 0xcbab74, size: 0x2c
    // 0xcbab74: EnterFrame
    //     0xcbab74: stp             fp, lr, [SP, #-0x10]!
    //     0xcbab78: mov             fp, SP
    // 0xcbab7c: CheckStackOverflow
    //     0xcbab7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcbab80: cmp             SP, x16
    //     0xcbab84: b.ls            #0xcbab98
    // 0xcbab88: r0 = load()
    //     0xcbab88: bl              #0xcbaba0  ; [package:flutter/src/cupertino/localizations.dart] DefaultCupertinoLocalizations::load
    // 0xcbab8c: LeaveFrame
    //     0xcbab8c: mov             SP, fp
    //     0xcbab90: ldp             fp, lr, [SP], #0x10
    // 0xcbab94: ret
    //     0xcbab94: ret             
    // 0xcbab98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcbab98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcbab9c: b               #0xcbab88
  }
}

// class id: 4235, size: 0x8, field offset: 0x8
abstract class CupertinoLocalizations extends Object {

  static _ of(/* No info */) {
    // ** addr: 0x840c34, size: 0x5c
    // 0x840c34: EnterFrame
    //     0x840c34: stp             fp, lr, [SP, #-0x10]!
    //     0x840c38: mov             fp, SP
    // 0x840c3c: CheckStackOverflow
    //     0x840c3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x840c40: cmp             SP, x16
    //     0x840c44: b.ls            #0x840c84
    // 0x840c48: r16 = <CupertinoLocalizations>
    //     0x840c48: add             x16, PP, #0x28, lsl #12  ; [pp+0x28df8] TypeArguments: <CupertinoLocalizations>
    //     0x840c4c: ldr             x16, [x16, #0xdf8]
    // 0x840c50: ldr             lr, [fp, #0x10]
    // 0x840c54: stp             lr, x16, [SP, #-0x10]!
    // 0x840c58: r16 = CupertinoLocalizations
    //     0x840c58: add             x16, PP, #0x28, lsl #12  ; [pp+0x28e00] Type: CupertinoLocalizations
    //     0x840c5c: ldr             x16, [x16, #0xe00]
    // 0x840c60: SaveReg r16
    //     0x840c60: str             x16, [SP, #-8]!
    // 0x840c64: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x840c64: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x840c68: r0 = of()
    //     0x840c68: bl              #0x6ced68  ; [package:flutter/src/widgets/localizations.dart] Localizations::of
    // 0x840c6c: add             SP, SP, #0x18
    // 0x840c70: cmp             w0, NULL
    // 0x840c74: b.eq            #0x840c8c
    // 0x840c78: LeaveFrame
    //     0x840c78: mov             SP, fp
    //     0x840c7c: ldp             fp, lr, [SP], #0x10
    // 0x840c80: ret
    //     0x840c80: ret             
    // 0x840c84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840c84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840c88: b               #0x840c48
    // 0x840c8c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840c8c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:flutter/src/cupertino/activity_indicator.dart

// class id: 1049073, size: 0x8
class :: {
}

// class id: 3360, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CupertinoActivityIndicatorState&State&SingleTickerProviderStateMixin extends State<CupertinoActivityIndicator>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x614b38, size: 0x98
    // 0x614b38: EnterFrame
    //     0x614b38: stp             fp, lr, [SP, #-0x10]!
    //     0x614b3c: mov             fp, SP
    // 0x614b40: CheckStackOverflow
    //     0x614b40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614b44: cmp             SP, x16
    //     0x614b48: b.ls            #0x614bc4
    // 0x614b4c: r0 = Ticker()
    //     0x614b4c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x614b50: mov             x1, x0
    // 0x614b54: r0 = false
    //     0x614b54: add             x0, NULL, #0x30  ; false
    // 0x614b58: StoreField: r1->field_b = r0
    //     0x614b58: stur            w0, [x1, #0xb]
    // 0x614b5c: ldr             x0, [fp, #0x10]
    // 0x614b60: StoreField: r1->field_13 = r0
    //     0x614b60: stur            w0, [x1, #0x13]
    // 0x614b64: mov             x0, x1
    // 0x614b68: ldr             x1, [fp, #0x18]
    // 0x614b6c: StoreField: r1->field_13 = r0
    //     0x614b6c: stur            w0, [x1, #0x13]
    //     0x614b70: ldurb           w16, [x1, #-1]
    //     0x614b74: ldurb           w17, [x0, #-1]
    //     0x614b78: and             x16, x17, x16, lsr #2
    //     0x614b7c: tst             x16, HEAP, lsr #32
    //     0x614b80: b.eq            #0x614b88
    //     0x614b84: bl              #0xd6826c
    // 0x614b88: SaveReg r1
    //     0x614b88: str             x1, [SP, #-8]!
    // 0x614b8c: r0 = _updateTickerModeNotifier()
    //     0x614b8c: bl              #0x614bf4  ; [package:flutter/src/cupertino/activity_indicator.dart] __CupertinoActivityIndicatorState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x614b90: add             SP, SP, #8
    // 0x614b94: ldr             x16, [fp, #0x18]
    // 0x614b98: SaveReg r16
    //     0x614b98: str             x16, [SP, #-8]!
    // 0x614b9c: r0 = _updateTicker()
    //     0x614b9c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614ba0: add             SP, SP, #8
    // 0x614ba4: ldr             x1, [fp, #0x18]
    // 0x614ba8: LoadField: r0 = r1->field_13
    //     0x614ba8: ldur            w0, [x1, #0x13]
    // 0x614bac: DecompressPointer r0
    //     0x614bac: add             x0, x0, HEAP, lsl #32
    // 0x614bb0: cmp             w0, NULL
    // 0x614bb4: b.eq            #0x614bcc
    // 0x614bb8: LeaveFrame
    //     0x614bb8: mov             SP, fp
    //     0x614bbc: ldp             fp, lr, [SP], #0x10
    // 0x614bc0: ret
    //     0x614bc0: ret             
    // 0x614bc4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614bc4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614bc8: b               #0x614b4c
    // 0x614bcc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x614bcc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x614bf4, size: 0x11c
    // 0x614bf4: EnterFrame
    //     0x614bf4: stp             fp, lr, [SP, #-0x10]!
    //     0x614bf8: mov             fp, SP
    // 0x614bfc: AllocStack(0x10)
    //     0x614bfc: sub             SP, SP, #0x10
    // 0x614c00: CheckStackOverflow
    //     0x614c00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614c04: cmp             SP, x16
    //     0x614c08: b.ls            #0x614d04
    // 0x614c0c: ldr             x0, [fp, #0x10]
    // 0x614c10: LoadField: r1 = r0->field_f
    //     0x614c10: ldur            w1, [x0, #0xf]
    // 0x614c14: DecompressPointer r1
    //     0x614c14: add             x1, x1, HEAP, lsl #32
    // 0x614c18: cmp             w1, NULL
    // 0x614c1c: b.eq            #0x614d0c
    // 0x614c20: SaveReg r1
    //     0x614c20: str             x1, [SP, #-8]!
    // 0x614c24: r0 = getNotifier()
    //     0x614c24: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x614c28: add             SP, SP, #8
    // 0x614c2c: mov             x1, x0
    // 0x614c30: ldr             x0, [fp, #0x10]
    // 0x614c34: stur            x1, [fp, #-0x10]
    // 0x614c38: LoadField: r2 = r0->field_17
    //     0x614c38: ldur            w2, [x0, #0x17]
    // 0x614c3c: DecompressPointer r2
    //     0x614c3c: add             x2, x2, HEAP, lsl #32
    // 0x614c40: stur            x2, [fp, #-8]
    // 0x614c44: cmp             w1, w2
    // 0x614c48: b.ne            #0x614c5c
    // 0x614c4c: r0 = Null
    //     0x614c4c: mov             x0, NULL
    // 0x614c50: LeaveFrame
    //     0x614c50: mov             SP, fp
    //     0x614c54: ldp             fp, lr, [SP], #0x10
    // 0x614c58: ret
    //     0x614c58: ret             
    // 0x614c5c: cmp             w2, NULL
    // 0x614c60: b.eq            #0x614c9c
    // 0x614c64: r1 = 1
    //     0x614c64: mov             x1, #1
    // 0x614c68: r0 = AllocateContext()
    //     0x614c68: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614c6c: mov             x1, x0
    // 0x614c70: ldr             x0, [fp, #0x10]
    // 0x614c74: StoreField: r1->field_f = r0
    //     0x614c74: stur            w0, [x1, #0xf]
    // 0x614c78: mov             x2, x1
    // 0x614c7c: r1 = Function '_updateTicker@156311458':.
    //     0x614c7c: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f88] AnonymousClosure: (0x614d10), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614c80: ldr             x1, [x1, #0xf88]
    // 0x614c84: r0 = AllocateClosure()
    //     0x614c84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614c88: ldur            x16, [fp, #-8]
    // 0x614c8c: stp             x0, x16, [SP, #-0x10]!
    // 0x614c90: r0 = removeListener()
    //     0x614c90: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x614c94: add             SP, SP, #0x10
    // 0x614c98: ldr             x0, [fp, #0x10]
    // 0x614c9c: r1 = 1
    //     0x614c9c: mov             x1, #1
    // 0x614ca0: r0 = AllocateContext()
    //     0x614ca0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614ca4: mov             x1, x0
    // 0x614ca8: ldr             x0, [fp, #0x10]
    // 0x614cac: StoreField: r1->field_f = r0
    //     0x614cac: stur            w0, [x1, #0xf]
    // 0x614cb0: mov             x2, x1
    // 0x614cb4: r1 = Function '_updateTicker@156311458':.
    //     0x614cb4: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f88] AnonymousClosure: (0x614d10), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614cb8: ldr             x1, [x1, #0xf88]
    // 0x614cbc: r0 = AllocateClosure()
    //     0x614cbc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614cc0: ldur            x16, [fp, #-0x10]
    // 0x614cc4: stp             x0, x16, [SP, #-0x10]!
    // 0x614cc8: r0 = addListener()
    //     0x614cc8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x614ccc: add             SP, SP, #0x10
    // 0x614cd0: ldur            x0, [fp, #-0x10]
    // 0x614cd4: ldr             x1, [fp, #0x10]
    // 0x614cd8: StoreField: r1->field_17 = r0
    //     0x614cd8: stur            w0, [x1, #0x17]
    //     0x614cdc: ldurb           w16, [x1, #-1]
    //     0x614ce0: ldurb           w17, [x0, #-1]
    //     0x614ce4: and             x16, x17, x16, lsr #2
    //     0x614ce8: tst             x16, HEAP, lsr #32
    //     0x614cec: b.eq            #0x614cf4
    //     0x614cf0: bl              #0xd6826c
    // 0x614cf4: r0 = Null
    //     0x614cf4: mov             x0, NULL
    // 0x614cf8: LeaveFrame
    //     0x614cf8: mov             SP, fp
    //     0x614cfc: ldp             fp, lr, [SP], #0x10
    // 0x614d00: ret
    //     0x614d00: ret             
    // 0x614d04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614d04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614d08: b               #0x614c0c
    // 0x614d0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x614d0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x614d10, size: 0x48
    // 0x614d10: EnterFrame
    //     0x614d10: stp             fp, lr, [SP, #-0x10]!
    //     0x614d14: mov             fp, SP
    // 0x614d18: ldr             x0, [fp, #0x10]
    // 0x614d1c: LoadField: r1 = r0->field_17
    //     0x614d1c: ldur            w1, [x0, #0x17]
    // 0x614d20: DecompressPointer r1
    //     0x614d20: add             x1, x1, HEAP, lsl #32
    // 0x614d24: CheckStackOverflow
    //     0x614d24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614d28: cmp             SP, x16
    //     0x614d2c: b.ls            #0x614d50
    // 0x614d30: LoadField: r0 = r1->field_f
    //     0x614d30: ldur            w0, [x1, #0xf]
    // 0x614d34: DecompressPointer r0
    //     0x614d34: add             x0, x0, HEAP, lsl #32
    // 0x614d38: SaveReg r0
    //     0x614d38: str             x0, [SP, #-8]!
    // 0x614d3c: r0 = _updateTicker()
    //     0x614d3c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614d40: add             SP, SP, #8
    // 0x614d44: LeaveFrame
    //     0x614d44: mov             SP, fp
    //     0x614d48: ldp             fp, lr, [SP], #0x10
    // 0x614d4c: ret
    //     0x614d4c: ret             
    // 0x614d50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614d50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614d54: b               #0x614d30
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f0cc, size: 0x4c
    // 0x81f0cc: EnterFrame
    //     0x81f0cc: stp             fp, lr, [SP, #-0x10]!
    //     0x81f0d0: mov             fp, SP
    // 0x81f0d4: CheckStackOverflow
    //     0x81f0d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f0d8: cmp             SP, x16
    //     0x81f0dc: b.ls            #0x81f110
    // 0x81f0e0: ldr             x16, [fp, #0x10]
    // 0x81f0e4: SaveReg r16
    //     0x81f0e4: str             x16, [SP, #-8]!
    // 0x81f0e8: r0 = _updateTickerModeNotifier()
    //     0x81f0e8: bl              #0x614bf4  ; [package:flutter/src/cupertino/activity_indicator.dart] __CupertinoActivityIndicatorState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f0ec: add             SP, SP, #8
    // 0x81f0f0: ldr             x16, [fp, #0x10]
    // 0x81f0f4: SaveReg r16
    //     0x81f0f4: str             x16, [SP, #-8]!
    // 0x81f0f8: r0 = _updateTicker()
    //     0x81f0f8: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f0fc: add             SP, SP, #8
    // 0x81f100: r0 = Null
    //     0x81f100: mov             x0, NULL
    // 0x81f104: LeaveFrame
    //     0x81f104: mov             SP, fp
    //     0x81f108: ldp             fp, lr, [SP], #0x10
    // 0x81f10c: ret
    //     0x81f10c: ret             
    // 0x81f110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f114: b               #0x81f0e0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50260, size: 0x8c
    // 0xa50260: EnterFrame
    //     0xa50260: stp             fp, lr, [SP, #-0x10]!
    //     0xa50264: mov             fp, SP
    // 0xa50268: AllocStack(0x8)
    //     0xa50268: sub             SP, SP, #8
    // 0xa5026c: CheckStackOverflow
    //     0xa5026c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50270: cmp             SP, x16
    //     0xa50274: b.ls            #0xa502e4
    // 0xa50278: ldr             x0, [fp, #0x10]
    // 0xa5027c: LoadField: r1 = r0->field_17
    //     0xa5027c: ldur            w1, [x0, #0x17]
    // 0xa50280: DecompressPointer r1
    //     0xa50280: add             x1, x1, HEAP, lsl #32
    // 0xa50284: stur            x1, [fp, #-8]
    // 0xa50288: cmp             w1, NULL
    // 0xa5028c: b.ne            #0xa50298
    // 0xa50290: mov             x1, x0
    // 0xa50294: b               #0xa502d0
    // 0xa50298: r1 = 1
    //     0xa50298: mov             x1, #1
    // 0xa5029c: r0 = AllocateContext()
    //     0xa5029c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa502a0: mov             x1, x0
    // 0xa502a4: ldr             x0, [fp, #0x10]
    // 0xa502a8: StoreField: r1->field_f = r0
    //     0xa502a8: stur            w0, [x1, #0xf]
    // 0xa502ac: mov             x2, x1
    // 0xa502b0: r1 = Function '_updateTicker@156311458':.
    //     0xa502b0: add             x1, PP, #0x28, lsl #12  ; [pp+0x28f88] AnonymousClosure: (0x614d10), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa502b4: ldr             x1, [x1, #0xf88]
    // 0xa502b8: r0 = AllocateClosure()
    //     0xa502b8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa502bc: ldur            x16, [fp, #-8]
    // 0xa502c0: stp             x0, x16, [SP, #-0x10]!
    // 0xa502c4: r0 = removeListener()
    //     0xa502c4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa502c8: add             SP, SP, #0x10
    // 0xa502cc: ldr             x1, [fp, #0x10]
    // 0xa502d0: StoreField: r1->field_17 = rNULL
    //     0xa502d0: stur            NULL, [x1, #0x17]
    // 0xa502d4: r0 = Null
    //     0xa502d4: mov             x0, NULL
    // 0xa502d8: LeaveFrame
    //     0xa502d8: mov             SP, fp
    //     0xa502dc: ldp             fp, lr, [SP], #0x10
    // 0xa502e0: ret
    //     0xa502e0: ret             
    // 0xa502e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa502e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa502e8: b               #0xa50278
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa502ec, size: 0x48
    // 0xa502ec: EnterFrame
    //     0xa502ec: stp             fp, lr, [SP, #-0x10]!
    //     0xa502f0: mov             fp, SP
    // 0xa502f4: ldr             x0, [fp, #0x10]
    // 0xa502f8: LoadField: r1 = r0->field_17
    //     0xa502f8: ldur            w1, [x0, #0x17]
    // 0xa502fc: DecompressPointer r1
    //     0xa502fc: add             x1, x1, HEAP, lsl #32
    // 0xa50300: CheckStackOverflow
    //     0xa50300: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50304: cmp             SP, x16
    //     0xa50308: b.ls            #0xa5032c
    // 0xa5030c: LoadField: r0 = r1->field_f
    //     0xa5030c: ldur            w0, [x1, #0xf]
    // 0xa50310: DecompressPointer r0
    //     0xa50310: add             x0, x0, HEAP, lsl #32
    // 0xa50314: SaveReg r0
    //     0xa50314: str             x0, [SP, #-8]!
    // 0xa50318: r0 = dispose()
    //     0xa50318: bl              #0xa50260  ; [package:flutter/src/cupertino/activity_indicator.dart] __CupertinoActivityIndicatorState&State&SingleTickerProviderStateMixin::dispose
    // 0xa5031c: add             SP, SP, #8
    // 0xa50320: LeaveFrame
    //     0xa50320: mov             SP, fp
    //     0xa50324: ldp             fp, lr, [SP], #0x10
    // 0xa50328: ret
    //     0xa50328: ret             
    // 0xa5032c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5032c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50330: b               #0xa5030c
  }
}

// class id: 3361, size: 0x20, field offset: 0x1c
class _CupertinoActivityIndicatorState extends __CupertinoActivityIndicatorState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7aec54, size: 0xa8
    // 0x7aec54: EnterFrame
    //     0x7aec54: stp             fp, lr, [SP, #-0x10]!
    //     0x7aec58: mov             fp, SP
    // 0x7aec5c: ldr             x0, [fp, #0x10]
    // 0x7aec60: r2 = Null
    //     0x7aec60: mov             x2, NULL
    // 0x7aec64: r1 = Null
    //     0x7aec64: mov             x1, NULL
    // 0x7aec68: r4 = 59
    //     0x7aec68: mov             x4, #0x3b
    // 0x7aec6c: branchIfSmi(r0, 0x7aec78)
    //     0x7aec6c: tbz             w0, #0, #0x7aec78
    // 0x7aec70: r4 = LoadClassIdInstr(r0)
    //     0x7aec70: ldur            x4, [x0, #-1]
    //     0x7aec74: ubfx            x4, x4, #0xc, #0x14
    // 0x7aec78: r17 = 4184
    //     0x7aec78: mov             x17, #0x1058
    // 0x7aec7c: cmp             x4, x17
    // 0x7aec80: b.eq            #0x7aec98
    // 0x7aec84: r8 = CupertinoActivityIndicator
    //     0x7aec84: add             x8, PP, #0x28, lsl #12  ; [pp+0x28fa0] Type: CupertinoActivityIndicator
    //     0x7aec88: ldr             x8, [x8, #0xfa0]
    // 0x7aec8c: r3 = Null
    //     0x7aec8c: add             x3, PP, #0x28, lsl #12  ; [pp+0x28fa8] Null
    //     0x7aec90: ldr             x3, [x3, #0xfa8]
    // 0x7aec94: r0 = CupertinoActivityIndicator()
    //     0x7aec94: bl              #0x614bd0  ; IsType_CupertinoActivityIndicator_Stub
    // 0x7aec98: ldr             x3, [fp, #0x18]
    // 0x7aec9c: LoadField: r2 = r3->field_7
    //     0x7aec9c: ldur            w2, [x3, #7]
    // 0x7aeca0: DecompressPointer r2
    //     0x7aeca0: add             x2, x2, HEAP, lsl #32
    // 0x7aeca4: ldr             x0, [fp, #0x10]
    // 0x7aeca8: r1 = Null
    //     0x7aeca8: mov             x1, NULL
    // 0x7aecac: cmp             w2, NULL
    // 0x7aecb0: b.eq            #0x7aecd4
    // 0x7aecb4: LoadField: r4 = r2->field_17
    //     0x7aecb4: ldur            w4, [x2, #0x17]
    // 0x7aecb8: DecompressPointer r4
    //     0x7aecb8: add             x4, x4, HEAP, lsl #32
    // 0x7aecbc: r8 = X0 bound StatefulWidget
    //     0x7aecbc: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7aecc0: ldr             x8, [x8, #0x858]
    // 0x7aecc4: LoadField: r9 = r4->field_7
    //     0x7aecc4: ldur            x9, [x4, #7]
    // 0x7aecc8: r3 = Null
    //     0x7aecc8: add             x3, PP, #0x28, lsl #12  ; [pp+0x28fb8] Null
    //     0x7aeccc: ldr             x3, [x3, #0xfb8]
    // 0x7aecd0: blr             x9
    // 0x7aecd4: ldr             x1, [fp, #0x18]
    // 0x7aecd8: LoadField: r2 = r1->field_b
    //     0x7aecd8: ldur            w2, [x1, #0xb]
    // 0x7aecdc: DecompressPointer r2
    //     0x7aecdc: add             x2, x2, HEAP, lsl #32
    // 0x7aece0: cmp             w2, NULL
    // 0x7aece4: b.eq            #0x7aecf8
    // 0x7aece8: r0 = Null
    //     0x7aece8: mov             x0, NULL
    // 0x7aecec: LeaveFrame
    //     0x7aecec: mov             SP, fp
    //     0x7aecf0: ldp             fp, lr, [SP], #0x10
    // 0x7aecf4: ret
    //     0x7aecf4: ret             
    // 0x7aecf8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7aecf8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x83f488, size: 0x184
    // 0x83f488: EnterFrame
    //     0x83f488: stp             fp, lr, [SP, #-0x10]!
    //     0x83f48c: mov             fp, SP
    // 0x83f490: AllocStack(0x28)
    //     0x83f490: sub             SP, SP, #0x28
    // 0x83f494: d0 = 2.000000
    //     0x83f494: fmov            d0, #2.00000000
    // 0x83f498: CheckStackOverflow
    //     0x83f498: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83f49c: cmp             SP, x16
    //     0x83f4a0: b.ls            #0x83f5d8
    // 0x83f4a4: ldr             x0, [fp, #0x18]
    // 0x83f4a8: LoadField: r1 = r0->field_b
    //     0x83f4a8: ldur            w1, [x0, #0xb]
    // 0x83f4ac: DecompressPointer r1
    //     0x83f4ac: add             x1, x1, HEAP, lsl #32
    // 0x83f4b0: cmp             w1, NULL
    // 0x83f4b4: b.eq            #0x83f5e0
    // 0x83f4b8: LoadField: d1 = r1->field_13
    //     0x83f4b8: ldur            d1, [x1, #0x13]
    // 0x83f4bc: fmul            d2, d1, d0
    // 0x83f4c0: stur            d2, [fp, #-0x20]
    // 0x83f4c4: LoadField: r2 = r0->field_1b
    //     0x83f4c4: ldur            w2, [x0, #0x1b]
    // 0x83f4c8: DecompressPointer r2
    //     0x83f4c8: add             x2, x2, HEAP, lsl #32
    // 0x83f4cc: r16 = Sentinel
    //     0x83f4cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x83f4d0: cmp             w2, w16
    // 0x83f4d4: b.eq            #0x83f5e4
    // 0x83f4d8: stur            x2, [fp, #-8]
    // 0x83f4dc: LoadField: r3 = r1->field_b
    //     0x83f4dc: ldur            w3, [x1, #0xb]
    // 0x83f4e0: DecompressPointer r3
    //     0x83f4e0: add             x3, x3, HEAP, lsl #32
    // 0x83f4e4: cmp             w3, NULL
    // 0x83f4e8: b.ne            #0x83f50c
    // 0x83f4ec: r16 = Instance_CupertinoDynamicColor
    //     0x83f4ec: add             x16, PP, #0x28, lsl #12  ; [pp+0x28f90] Obj!CupertinoDynamicColor@b5e631
    //     0x83f4f0: ldr             x16, [x16, #0xf90]
    // 0x83f4f4: ldr             lr, [fp, #0x10]
    // 0x83f4f8: stp             lr, x16, [SP, #-0x10]!
    // 0x83f4fc: r0 = resolveFrom()
    //     0x83f4fc: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x83f500: add             SP, SP, #0x10
    // 0x83f504: mov             x1, x0
    // 0x83f508: b               #0x83f510
    // 0x83f50c: mov             x1, x3
    // 0x83f510: ldr             x0, [fp, #0x18]
    // 0x83f514: ldur            d0, [fp, #-0x20]
    // 0x83f518: stur            x1, [fp, #-0x10]
    // 0x83f51c: LoadField: r2 = r0->field_b
    //     0x83f51c: ldur            w2, [x0, #0xb]
    // 0x83f520: DecompressPointer r2
    //     0x83f520: add             x2, x2, HEAP, lsl #32
    // 0x83f524: cmp             w2, NULL
    // 0x83f528: b.eq            #0x83f5f0
    // 0x83f52c: LoadField: d1 = r2->field_13
    //     0x83f52c: ldur            d1, [x2, #0x13]
    // 0x83f530: stur            d1, [fp, #-0x28]
    // 0x83f534: r0 = _CupertinoActivityIndicatorPainter()
    //     0x83f534: bl              #0x83f724  ; Allocate_CupertinoActivityIndicatorPainterStub -> _CupertinoActivityIndicatorPainter (size=0x20)
    // 0x83f538: stur            x0, [fp, #-0x18]
    // 0x83f53c: ldur            x16, [fp, #-0x10]
    // 0x83f540: stp             x16, x0, [SP, #-0x10]!
    // 0x83f544: ldur            x16, [fp, #-8]
    // 0x83f548: SaveReg r16
    //     0x83f548: str             x16, [SP, #-8]!
    // 0x83f54c: ldur            d0, [fp, #-0x28]
    // 0x83f550: SaveReg d0
    //     0x83f550: str             d0, [SP, #-8]!
    // 0x83f554: r0 = _CupertinoActivityIndicatorPainter()
    //     0x83f554: bl              #0x83f60c  ; [package:flutter/src/cupertino/activity_indicator.dart] _CupertinoActivityIndicatorPainter::_CupertinoActivityIndicatorPainter
    // 0x83f558: add             SP, SP, #0x20
    // 0x83f55c: r0 = CustomPaint()
    //     0x83f55c: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x83f560: mov             x1, x0
    // 0x83f564: ldur            x0, [fp, #-0x18]
    // 0x83f568: stur            x1, [fp, #-0x10]
    // 0x83f56c: StoreField: r1->field_f = r0
    //     0x83f56c: stur            w0, [x1, #0xf]
    // 0x83f570: r0 = Instance_Size
    //     0x83f570: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x83f574: StoreField: r1->field_17 = r0
    //     0x83f574: stur            w0, [x1, #0x17]
    // 0x83f578: r0 = false
    //     0x83f578: add             x0, NULL, #0x30  ; false
    // 0x83f57c: StoreField: r1->field_1b = r0
    //     0x83f57c: stur            w0, [x1, #0x1b]
    // 0x83f580: StoreField: r1->field_1f = r0
    //     0x83f580: stur            w0, [x1, #0x1f]
    // 0x83f584: ldur            d0, [fp, #-0x20]
    // 0x83f588: r0 = inline_Allocate_Double()
    //     0x83f588: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x83f58c: add             x0, x0, #0x10
    //     0x83f590: cmp             x2, x0
    //     0x83f594: b.ls            #0x83f5f4
    //     0x83f598: str             x0, [THR, #0x60]  ; THR::top
    //     0x83f59c: sub             x0, x0, #0xf
    //     0x83f5a0: mov             x2, #0xd108
    //     0x83f5a4: movk            x2, #3, lsl #16
    //     0x83f5a8: stur            x2, [x0, #-1]
    // 0x83f5ac: StoreField: r0->field_7 = d0
    //     0x83f5ac: stur            d0, [x0, #7]
    // 0x83f5b0: stur            x0, [fp, #-8]
    // 0x83f5b4: r0 = SizedBox()
    //     0x83f5b4: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x83f5b8: ldur            x1, [fp, #-8]
    // 0x83f5bc: StoreField: r0->field_f = r1
    //     0x83f5bc: stur            w1, [x0, #0xf]
    // 0x83f5c0: StoreField: r0->field_13 = r1
    //     0x83f5c0: stur            w1, [x0, #0x13]
    // 0x83f5c4: ldur            x1, [fp, #-0x10]
    // 0x83f5c8: StoreField: r0->field_b = r1
    //     0x83f5c8: stur            w1, [x0, #0xb]
    // 0x83f5cc: LeaveFrame
    //     0x83f5cc: mov             SP, fp
    //     0x83f5d0: ldp             fp, lr, [SP], #0x10
    // 0x83f5d4: ret
    //     0x83f5d4: ret             
    // 0x83f5d8: r0 = StackOverflowSharedWithFPURegs()
    //     0x83f5d8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x83f5dc: b               #0x83f4a4
    // 0x83f5e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x83f5e0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x83f5e4: r9 = _controller
    //     0x83f5e4: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f98] Field <_CupertinoActivityIndicatorState@581022161._controller@581022161>: late (offset: 0x1c)
    //     0x83f5e8: ldr             x9, [x9, #0xf98]
    // 0x83f5ec: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x83f5ec: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x83f5f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x83f5f0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x83f5f4: SaveReg d0
    //     0x83f5f4: str             q0, [SP, #-0x10]!
    // 0x83f5f8: SaveReg r1
    //     0x83f5f8: str             x1, [SP, #-8]!
    // 0x83f5fc: r0 = AllocateDouble()
    //     0x83f5fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x83f600: RestoreReg r1
    //     0x83f600: ldr             x1, [SP], #8
    // 0x83f604: RestoreReg d0
    //     0x83f604: ldr             q0, [SP], #0x10
    // 0x83f608: b               #0x83f5ac
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d7494, size: 0xa8
    // 0x9d7494: EnterFrame
    //     0x9d7494: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7498: mov             fp, SP
    // 0x9d749c: AllocStack(0x8)
    //     0x9d749c: sub             SP, SP, #8
    // 0x9d74a0: CheckStackOverflow
    //     0x9d74a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d74a4: cmp             SP, x16
    //     0x9d74a8: b.ls            #0x9d7530
    // 0x9d74ac: r1 = <double>
    //     0x9d74ac: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d74b0: r0 = AnimationController()
    //     0x9d74b0: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d74b4: stur            x0, [fp, #-8]
    // 0x9d74b8: ldr             x16, [fp, #0x10]
    // 0x9d74bc: stp             x16, x0, [SP, #-0x10]!
    // 0x9d74c0: r16 = Instance_Duration
    //     0x9d74c0: ldr             x16, [PP, #0x1788]  ; [pp+0x1788] Obj!Duration@b67a21
    // 0x9d74c4: SaveReg r16
    //     0x9d74c4: str             x16, [SP, #-8]!
    // 0x9d74c8: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d74c8: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d74cc: ldr             x4, [x4, #0xa0]
    // 0x9d74d0: r0 = AnimationController()
    //     0x9d74d0: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d74d4: add             SP, SP, #0x18
    // 0x9d74d8: ldur            x0, [fp, #-8]
    // 0x9d74dc: ldr             x1, [fp, #0x10]
    // 0x9d74e0: StoreField: r1->field_1b = r0
    //     0x9d74e0: stur            w0, [x1, #0x1b]
    //     0x9d74e4: ldurb           w16, [x1, #-1]
    //     0x9d74e8: ldurb           w17, [x0, #-1]
    //     0x9d74ec: and             x16, x17, x16, lsr #2
    //     0x9d74f0: tst             x16, HEAP, lsr #32
    //     0x9d74f4: b.eq            #0x9d74fc
    //     0x9d74f8: bl              #0xd6826c
    // 0x9d74fc: LoadField: r0 = r1->field_b
    //     0x9d74fc: ldur            w0, [x1, #0xb]
    // 0x9d7500: DecompressPointer r0
    //     0x9d7500: add             x0, x0, HEAP, lsl #32
    // 0x9d7504: cmp             w0, NULL
    // 0x9d7508: b.eq            #0x9d7538
    // 0x9d750c: ldur            x16, [fp, #-8]
    // 0x9d7510: SaveReg r16
    //     0x9d7510: str             x16, [SP, #-8]!
    // 0x9d7514: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d7514: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d7518: r0 = repeat()
    //     0x9d7518: bl              #0x7b8ecc  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::repeat
    // 0x9d751c: add             SP, SP, #8
    // 0x9d7520: r0 = Null
    //     0x9d7520: mov             x0, NULL
    // 0x9d7524: LeaveFrame
    //     0x9d7524: mov             SP, fp
    //     0x9d7528: ldp             fp, lr, [SP], #0x10
    // 0x9d752c: ret
    //     0x9d752c: ret             
    // 0x9d7530: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7530: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d7534: b               #0x9d74ac
    // 0x9d7538: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7538: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a588, size: 0x18
    // 0xa4a588: r4 = 7
    //     0xa4a588: mov             x4, #7
    // 0xa4a58c: r1 = Function 'dispose':.
    //     0xa4a58c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bb78] AnonymousClosure: (0xa4a5a0), in [package:flutter/src/cupertino/activity_indicator.dart] _CupertinoActivityIndicatorState::dispose (0xa501f4)
    //     0xa4a590: ldr             x1, [x17, #0xb78]
    // 0xa4a594: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a594: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a598: LoadField: r0 = r24->field_17
    //     0xa4a598: ldur            x0, [x24, #0x17]
    // 0xa4a59c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a5a0, size: 0x48
    // 0xa4a5a0: EnterFrame
    //     0xa4a5a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a5a4: mov             fp, SP
    // 0xa4a5a8: ldr             x0, [fp, #0x10]
    // 0xa4a5ac: LoadField: r1 = r0->field_17
    //     0xa4a5ac: ldur            w1, [x0, #0x17]
    // 0xa4a5b0: DecompressPointer r1
    //     0xa4a5b0: add             x1, x1, HEAP, lsl #32
    // 0xa4a5b4: CheckStackOverflow
    //     0xa4a5b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a5b8: cmp             SP, x16
    //     0xa4a5bc: b.ls            #0xa4a5e0
    // 0xa4a5c0: LoadField: r0 = r1->field_f
    //     0xa4a5c0: ldur            w0, [x1, #0xf]
    // 0xa4a5c4: DecompressPointer r0
    //     0xa4a5c4: add             x0, x0, HEAP, lsl #32
    // 0xa4a5c8: SaveReg r0
    //     0xa4a5c8: str             x0, [SP, #-8]!
    // 0xa4a5cc: r0 = dispose()
    //     0xa4a5cc: bl              #0xa501f4  ; [package:flutter/src/cupertino/activity_indicator.dart] _CupertinoActivityIndicatorState::dispose
    // 0xa4a5d0: add             SP, SP, #8
    // 0xa4a5d4: LeaveFrame
    //     0xa4a5d4: mov             SP, fp
    //     0xa4a5d8: ldp             fp, lr, [SP], #0x10
    // 0xa4a5dc: ret
    //     0xa4a5dc: ret             
    // 0xa4a5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a5e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a5e4: b               #0xa4a5c0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa501f4, size: 0x6c
    // 0xa501f4: EnterFrame
    //     0xa501f4: stp             fp, lr, [SP, #-0x10]!
    //     0xa501f8: mov             fp, SP
    // 0xa501fc: CheckStackOverflow
    //     0xa501fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50200: cmp             SP, x16
    //     0xa50204: b.ls            #0xa5024c
    // 0xa50208: ldr             x0, [fp, #0x10]
    // 0xa5020c: LoadField: r1 = r0->field_1b
    //     0xa5020c: ldur            w1, [x0, #0x1b]
    // 0xa50210: DecompressPointer r1
    //     0xa50210: add             x1, x1, HEAP, lsl #32
    // 0xa50214: r16 = Sentinel
    //     0xa50214: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa50218: cmp             w1, w16
    // 0xa5021c: b.eq            #0xa50254
    // 0xa50220: SaveReg r1
    //     0xa50220: str             x1, [SP, #-8]!
    // 0xa50224: r0 = dispose()
    //     0xa50224: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa50228: add             SP, SP, #8
    // 0xa5022c: ldr             x16, [fp, #0x10]
    // 0xa50230: SaveReg r16
    //     0xa50230: str             x16, [SP, #-8]!
    // 0xa50234: r0 = dispose()
    //     0xa50234: bl              #0xa50260  ; [package:flutter/src/cupertino/activity_indicator.dart] __CupertinoActivityIndicatorState&State&SingleTickerProviderStateMixin::dispose
    // 0xa50238: add             SP, SP, #8
    // 0xa5023c: r0 = Null
    //     0xa5023c: mov             x0, NULL
    // 0xa50240: LeaveFrame
    //     0xa50240: mov             SP, fp
    //     0xa50244: ldp             fp, lr, [SP], #0x10
    // 0xa50248: ret
    //     0xa50248: ret             
    // 0xa5024c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa5024c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50250: b               #0xa50208
    // 0xa50254: r9 = _controller
    //     0xa50254: add             x9, PP, #0x28, lsl #12  ; [pp+0x28f98] Field <_CupertinoActivityIndicatorState@581022161._controller@581022161>: late (offset: 0x1c)
    //     0xa50258: ldr             x9, [x9, #0xf98]
    // 0xa5025c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5025c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4184, size: 0x24, field offset: 0xc
//   const constructor, 
class CupertinoActivityIndicator extends StatefulWidget {

  bool field_10;
  _Double field_14;
  _Double field_1c;

  _ createState(/* No info */) {
    // ** addr: 0xa3fcac, size: 0x28
    // 0xa3fcac: EnterFrame
    //     0xa3fcac: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fcb0: mov             fp, SP
    // 0xa3fcb4: r1 = <CupertinoActivityIndicator>
    //     0xa3fcb4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22138] TypeArguments: <CupertinoActivityIndicator>
    //     0xa3fcb8: ldr             x1, [x1, #0x138]
    // 0xa3fcbc: r0 = _CupertinoActivityIndicatorState()
    //     0xa3fcbc: bl              #0xa3fcd4  ; Allocate_CupertinoActivityIndicatorStateStub -> _CupertinoActivityIndicatorState (size=0x20)
    // 0xa3fcc0: r1 = Sentinel
    //     0xa3fcc0: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fcc4: StoreField: r0->field_1b = r1
    //     0xa3fcc4: stur            w1, [x0, #0x1b]
    // 0xa3fcc8: LeaveFrame
    //     0xa3fcc8: mov             SP, fp
    //     0xa3fccc: ldp             fp, lr, [SP], #0x10
    // 0xa3fcd0: ret
    //     0xa3fcd0: ret             
  }
}

// class id: 4379, size: 0x20, field offset: 0xc
class _CupertinoActivityIndicatorPainter extends CustomPainter {

  _ _CupertinoActivityIndicatorPainter(/* No info */) {
    // ** addr: 0x83f60c, size: 0x118
    // 0x83f60c: EnterFrame
    //     0x83f60c: stp             fp, lr, [SP, #-0x10]!
    //     0x83f610: mov             fp, SP
    // 0x83f614: AllocStack(0x20)
    //     0x83f614: sub             SP, SP, #0x20
    // 0x83f618: d2 = 1.000000
    //     0x83f618: fmov            d2, #1.00000000
    // 0x83f61c: d1 = 10.000000
    //     0x83f61c: fmov            d1, #10.00000000
    // 0x83f620: d0 = 3.000000
    //     0x83f620: fmov            d0, #3.00000000
    // 0x83f624: ldr             x0, [fp, #0x18]
    // 0x83f628: ldr             x1, [fp, #0x28]
    // 0x83f62c: StoreField: r1->field_b = r0
    //     0x83f62c: stur            w0, [x1, #0xb]
    //     0x83f630: ldurb           w16, [x1, #-1]
    //     0x83f634: ldurb           w17, [x0, #-1]
    //     0x83f638: and             x16, x17, x16, lsr #2
    //     0x83f63c: tst             x16, HEAP, lsr #32
    //     0x83f640: b.eq            #0x83f648
    //     0x83f644: bl              #0xd6826c
    // 0x83f648: ldr             x0, [fp, #0x20]
    // 0x83f64c: StoreField: r1->field_f = r0
    //     0x83f64c: stur            w0, [x1, #0xf]
    //     0x83f650: ldurb           w16, [x1, #-1]
    //     0x83f654: ldurb           w17, [x0, #-1]
    //     0x83f658: and             x16, x17, x16, lsr #2
    //     0x83f65c: tst             x16, HEAP, lsr #32
    //     0x83f660: b.eq            #0x83f668
    //     0x83f664: bl              #0xd6826c
    // 0x83f668: StoreField: r1->field_13 = d2
    //     0x83f668: stur            d2, [x1, #0x13]
    // 0x83f66c: ldr             d2, [fp, #0x10]
    // 0x83f670: fneg            d3, d2
    // 0x83f674: stur            d3, [fp, #-0x20]
    // 0x83f678: fdiv            d4, d3, d1
    // 0x83f67c: stur            d4, [fp, #-0x18]
    // 0x83f680: fdiv            d5, d3, d0
    // 0x83f684: stur            d5, [fp, #-0x10]
    // 0x83f688: fdiv            d0, d2, d1
    // 0x83f68c: stur            d0, [fp, #-8]
    // 0x83f690: r0 = RRect()
    //     0x83f690: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x83f694: ldur            d0, [fp, #-0x18]
    // 0x83f698: StoreField: r0->field_7 = d0
    //     0x83f698: stur            d0, [x0, #7]
    // 0x83f69c: ldur            d0, [fp, #-0x10]
    // 0x83f6a0: StoreField: r0->field_f = d0
    //     0x83f6a0: stur            d0, [x0, #0xf]
    // 0x83f6a4: ldur            d0, [fp, #-8]
    // 0x83f6a8: StoreField: r0->field_17 = d0
    //     0x83f6a8: stur            d0, [x0, #0x17]
    // 0x83f6ac: ldur            d1, [fp, #-0x20]
    // 0x83f6b0: StoreField: r0->field_1f = d1
    //     0x83f6b0: stur            d1, [x0, #0x1f]
    // 0x83f6b4: StoreField: r0->field_27 = d0
    //     0x83f6b4: stur            d0, [x0, #0x27]
    // 0x83f6b8: StoreField: r0->field_2f = d0
    //     0x83f6b8: stur            d0, [x0, #0x2f]
    // 0x83f6bc: StoreField: r0->field_37 = d0
    //     0x83f6bc: stur            d0, [x0, #0x37]
    // 0x83f6c0: StoreField: r0->field_3f = d0
    //     0x83f6c0: stur            d0, [x0, #0x3f]
    // 0x83f6c4: StoreField: r0->field_47 = d0
    //     0x83f6c4: stur            d0, [x0, #0x47]
    // 0x83f6c8: StoreField: r0->field_4f = d0
    //     0x83f6c8: stur            d0, [x0, #0x4f]
    // 0x83f6cc: StoreField: r0->field_57 = d0
    //     0x83f6cc: stur            d0, [x0, #0x57]
    // 0x83f6d0: StoreField: r0->field_5f = d0
    //     0x83f6d0: stur            d0, [x0, #0x5f]
    // 0x83f6d4: ldr             x1, [fp, #0x28]
    // 0x83f6d8: StoreField: r1->field_1b = r0
    //     0x83f6d8: stur            w0, [x1, #0x1b]
    //     0x83f6dc: ldurb           w16, [x1, #-1]
    //     0x83f6e0: ldurb           w17, [x0, #-1]
    //     0x83f6e4: and             x16, x17, x16, lsr #2
    //     0x83f6e8: tst             x16, HEAP, lsr #32
    //     0x83f6ec: b.eq            #0x83f6f4
    //     0x83f6f0: bl              #0xd6826c
    // 0x83f6f4: ldr             x0, [fp, #0x18]
    // 0x83f6f8: StoreField: r1->field_7 = r0
    //     0x83f6f8: stur            w0, [x1, #7]
    //     0x83f6fc: ldurb           w16, [x1, #-1]
    //     0x83f700: ldurb           w17, [x0, #-1]
    //     0x83f704: and             x16, x17, x16, lsr #2
    //     0x83f708: tst             x16, HEAP, lsr #32
    //     0x83f70c: b.eq            #0x83f714
    //     0x83f710: bl              #0xd6826c
    // 0x83f714: r0 = Null
    //     0x83f714: mov             x0, NULL
    // 0x83f718: LeaveFrame
    //     0x83f718: mov             SP, fp
    //     0x83f71c: ldp             fp, lr, [SP], #0x10
    // 0x83f720: ret
    //     0x83f720: ret             
  }
  _ paint(/* No info */) {
    // ** addr: 0xa6e6e0, size: 0x390
    // 0xa6e6e0: EnterFrame
    //     0xa6e6e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa6e6e4: mov             fp, SP
    // 0xa6e6e8: AllocStack(0x50)
    //     0xa6e6e8: sub             SP, SP, #0x50
    // 0xa6e6ec: CheckStackOverflow
    //     0xa6e6ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6e6f0: cmp             SP, x16
    //     0xa6e6f4: b.ls            #0xa6ea0c
    // 0xa6e6f8: r16 = 112
    //     0xa6e6f8: mov             x16, #0x70
    // 0xa6e6fc: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6e700: r0 = ByteData()
    //     0xa6e700: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6e704: add             SP, SP, #0x10
    // 0xa6e708: stur            x0, [fp, #-8]
    // 0xa6e70c: ldr             x16, [fp, #0x18]
    // 0xa6e710: SaveReg r16
    //     0xa6e710: str             x16, [SP, #-8]!
    // 0xa6e714: r0 = save()
    //     0xa6e714: bl              #0x6595b0  ; [dart:ui] Canvas::save
    // 0xa6e718: add             SP, SP, #8
    // 0xa6e71c: ldr             x0, [fp, #0x10]
    // 0xa6e720: LoadField: d0 = r0->field_7
    //     0xa6e720: ldur            d0, [x0, #7]
    // 0xa6e724: d1 = 2.000000
    //     0xa6e724: fmov            d1, #2.00000000
    // 0xa6e728: fdiv            d2, d0, d1
    // 0xa6e72c: LoadField: d0 = r0->field_f
    //     0xa6e72c: ldur            d0, [x0, #0xf]
    // 0xa6e730: fdiv            d3, d0, d1
    // 0xa6e734: r0 = inline_Allocate_Double()
    //     0xa6e734: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6e738: add             x0, x0, #0x10
    //     0xa6e73c: cmp             x1, x0
    //     0xa6e740: b.ls            #0xa6ea14
    //     0xa6e744: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6e748: sub             x0, x0, #0xf
    //     0xa6e74c: mov             x1, #0xd108
    //     0xa6e750: movk            x1, #3, lsl #16
    //     0xa6e754: stur            x1, [x0, #-1]
    // 0xa6e758: StoreField: r0->field_7 = d2
    //     0xa6e758: stur            d2, [x0, #7]
    // 0xa6e75c: ldr             x16, [fp, #0x18]
    // 0xa6e760: stp             x0, x16, [SP, #-0x10]!
    // 0xa6e764: SaveReg d3
    //     0xa6e764: str             d3, [SP, #-8]!
    // 0xa6e768: r0 = translate()
    //     0xa6e768: bl              #0x6566d0  ; [dart:ui] Canvas::translate
    // 0xa6e76c: add             SP, SP, #0x18
    // 0xa6e770: ldr             x0, [fp, #0x20]
    // 0xa6e774: LoadField: r1 = r0->field_b
    //     0xa6e774: ldur            w1, [x0, #0xb]
    // 0xa6e778: DecompressPointer r1
    //     0xa6e778: add             x1, x1, HEAP, lsl #32
    // 0xa6e77c: LoadField: r2 = r1->field_37
    //     0xa6e77c: ldur            w2, [x1, #0x37]
    // 0xa6e780: DecompressPointer r2
    //     0xa6e780: add             x2, x2, HEAP, lsl #32
    // 0xa6e784: r16 = Sentinel
    //     0xa6e784: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa6e788: cmp             w2, w16
    // 0xa6e78c: b.eq            #0xa6ea24
    // 0xa6e790: LoadField: d0 = r2->field_7
    //     0xa6e790: ldur            d0, [x2, #7]
    // 0xa6e794: d1 = 8.000000
    //     0xa6e794: fmov            d1, #8.00000000
    // 0xa6e798: fmul            d2, d1, d0
    // 0xa6e79c: fcmp            d2, d2
    // 0xa6e7a0: b.vs            #0xa6ea30
    // 0xa6e7a4: fcvtms          x1, d2
    // 0xa6e7a8: asr             x16, x1, #0x1e
    // 0xa6e7ac: cmp             x16, x1, asr #63
    // 0xa6e7b0: b.ne            #0xa6ea30
    // 0xa6e7b4: lsl             x1, x1, #1
    // 0xa6e7b8: r2 = LoadInt32Instr(r1)
    //     0xa6e7b8: sbfx            x2, x1, #1, #0x1f
    //     0xa6e7bc: tbz             w1, #0, #0xa6e7c4
    //     0xa6e7c0: ldur            x2, [x1, #7]
    // 0xa6e7c4: stur            x2, [fp, #-0x38]
    // 0xa6e7c8: LoadField: r1 = r0->field_f
    //     0xa6e7c8: ldur            w1, [x0, #0xf]
    // 0xa6e7cc: DecompressPointer r1
    //     0xa6e7cc: add             x1, x1, HEAP, lsl #32
    // 0xa6e7d0: ldur            x3, [fp, #-8]
    // 0xa6e7d4: stur            x1, [fp, #-0x30]
    // 0xa6e7d8: LoadField: r4 = r3->field_17
    //     0xa6e7d8: ldur            w4, [x3, #0x17]
    // 0xa6e7dc: DecompressPointer r4
    //     0xa6e7dc: add             x4, x4, HEAP, lsl #32
    // 0xa6e7e0: stur            x4, [fp, #-0x28]
    // 0xa6e7e4: LoadField: r5 = r0->field_1b
    //     0xa6e7e4: ldur            w5, [x0, #0x1b]
    // 0xa6e7e8: DecompressPointer r5
    //     0xa6e7e8: add             x5, x5, HEAP, lsl #32
    // 0xa6e7ec: stur            x5, [fp, #-0x20]
    // 0xa6e7f0: r8 = 0
    //     0xa6e7f0: mov             x8, #0
    // 0xa6e7f4: ldr             x7, [fp, #0x18]
    // 0xa6e7f8: r6 = const [0x2f, 0x2f, 0x2f, 0x2f, 0x48, 0x61, 0x7a, 0x93]
    //     0xa6e7f8: add             x6, PP, #0x2e, lsl #12  ; [pp+0x2ec28] List<int>(8)
    //     0xa6e7fc: ldr             x6, [x6, #0xc28]
    // 0xa6e800: d0 = 1.000000
    //     0xa6e800: fmov            d0, #1.00000000
    // 0xa6e804: r0 = 8
    //     0xa6e804: mov             x0, #8
    // 0xa6e808: stur            x8, [fp, #-0x18]
    // 0xa6e80c: CheckStackOverflow
    //     0xa6e80c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6e810: cmp             SP, x16
    //     0xa6e814: b.ls            #0xa6ea5c
    // 0xa6e818: scvtf           d2, x8
    // 0xa6e81c: fcmp            d2, d1
    // 0xa6e820: b.vs            #0xa6e9ec
    // 0xa6e824: b.ge            #0xa6e9ec
    // 0xa6e828: sub             x9, x8, x2
    // 0xa6e82c: sdiv            x11, x9, x0
    // 0xa6e830: msub            x10, x11, x0, x9
    // 0xa6e834: cmp             x10, xzr
    // 0xa6e838: b.lt            #0xa6ea64
    // 0xa6e83c: fcmp            d0, d0
    // 0xa6e840: b.vs            #0xa6e850
    // 0xa6e844: b.ge            #0xa6e850
    // 0xa6e848: r9 = 147
    //     0xa6e848: mov             x9, #0x93
    // 0xa6e84c: b               #0xa6e86c
    // 0xa6e850: ArrayLoad: r9 = r6[r10]  ; Unknown_4
    //     0xa6e850: add             x16, x6, x10, lsl #2
    //     0xa6e854: ldur            w9, [x16, #0xf]
    // 0xa6e858: DecompressPointer r9
    //     0xa6e858: add             x9, x9, HEAP, lsl #32
    // 0xa6e85c: r10 = LoadInt32Instr(r9)
    //     0xa6e85c: sbfx            x10, x9, #1, #0x1f
    //     0xa6e860: tbz             w9, #0, #0xa6e868
    //     0xa6e864: ldur            x10, [x9, #7]
    // 0xa6e868: mov             x9, x10
    // 0xa6e86c: stur            x9, [fp, #-0x10]
    // 0xa6e870: SaveReg r1
    //     0xa6e870: str             x1, [SP, #-8]!
    // 0xa6e874: r0 = red()
    //     0xa6e874: bl              #0x595684  ; [dart:ui] Color::red
    // 0xa6e878: add             SP, SP, #8
    // 0xa6e87c: stur            x0, [fp, #-0x40]
    // 0xa6e880: ldur            x16, [fp, #-0x30]
    // 0xa6e884: SaveReg r16
    //     0xa6e884: str             x16, [SP, #-8]!
    // 0xa6e888: r0 = green()
    //     0xa6e888: bl              #0x595604  ; [dart:ui] Color::green
    // 0xa6e88c: add             SP, SP, #8
    // 0xa6e890: stur            x0, [fp, #-0x48]
    // 0xa6e894: ldur            x16, [fp, #-0x30]
    // 0xa6e898: SaveReg r16
    //     0xa6e898: str             x16, [SP, #-8]!
    // 0xa6e89c: r0 = blue()
    //     0xa6e89c: bl              #0x595594  ; [dart:ui] Color::blue
    // 0xa6e8a0: add             SP, SP, #8
    // 0xa6e8a4: ldur            x1, [fp, #-0x10]
    // 0xa6e8a8: ubfx            x1, x1, #0, #0x20
    // 0xa6e8ac: r2 = 255
    //     0xa6e8ac: mov             x2, #0xff
    // 0xa6e8b0: and             x3, x1, x2
    // 0xa6e8b4: lsl             w1, w3, #0x18
    // 0xa6e8b8: ldur            x3, [fp, #-0x40]
    // 0xa6e8bc: ubfx            x3, x3, #0, #0x20
    // 0xa6e8c0: and             x4, x3, x2
    // 0xa6e8c4: lsl             w3, w4, #0x10
    // 0xa6e8c8: orr             x4, x1, x3
    // 0xa6e8cc: ldur            x1, [fp, #-0x48]
    // 0xa6e8d0: ubfx            x1, x1, #0, #0x20
    // 0xa6e8d4: and             x3, x1, x2
    // 0xa6e8d8: lsl             w1, w3, #8
    // 0xa6e8dc: orr             x3, x4, x1
    // 0xa6e8e0: ubfx            x0, x0, #0, #0x20
    // 0xa6e8e4: and             x1, x0, x2
    // 0xa6e8e8: orr             x0, x3, x1
    // 0xa6e8ec: ubfx            x0, x0, #0, #0x20
    // 0xa6e8f0: eor             x1, x0, #0xff000000
    // 0xa6e8f4: sxtw            x1, w1
    // 0xa6e8f8: ldur            x0, [fp, #-0x28]
    // 0xa6e8fc: LoadField: r3 = r0->field_7
    //     0xa6e8fc: ldur            x3, [x0, #7]
    // 0xa6e900: str             w1, [x3, #4]
    // 0xa6e904: ldur            x16, [fp, #-0x20]
    // 0xa6e908: SaveReg r16
    //     0xa6e908: str             x16, [SP, #-8]!
    // 0xa6e90c: r0 = _getValue32()
    //     0xa6e90c: bl              #0x65faf8  ; [dart:ui] RRect::_getValue32
    // 0xa6e910: add             SP, SP, #8
    // 0xa6e914: ldr             x16, [fp, #0x18]
    // 0xa6e918: stp             x0, x16, [SP, #-0x10]!
    // 0xa6e91c: ldur            x16, [fp, #-8]
    // 0xa6e920: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6e924: r0 = _drawRRect()
    //     0xa6e924: bl              #0x65f7b8  ; [dart:ui] Canvas::_drawRRect
    // 0xa6e928: add             SP, SP, #0x20
    // 0xa6e92c: r0 = InitLateStaticField(0x878) // [dart:ui] Canvas::_rotate$Method$FfiNative$Ptr
    //     0xa6e92c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xa6e930: ldr             x0, [x0, #0x10f0]
    //     0xa6e934: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xa6e938: cmp             w0, w16
    //     0xa6e93c: b.ne            #0xa6e94c
    //     0xa6e940: add             x2, PP, #0x2e, lsl #12  ; [pp+0x2ec30] Field <Canvas._rotate$Method$FfiNative$Ptr@15065589>: static late final (offset: 0x878)
    //     0xa6e944: ldr             x2, [x2, #0xc30]
    //     0xa6e948: bl              #0xd67cdc
    // 0xa6e94c: mov             x1, x0
    // 0xa6e950: ldr             x0, [fp, #0x18]
    // 0xa6e954: stur            x1, [fp, #-0x50]
    // 0xa6e958: LoadField: r2 = r0->field_7
    //     0xa6e958: ldur            w2, [x0, #7]
    // 0xa6e95c: DecompressPointer r2
    //     0xa6e95c: add             x2, x2, HEAP, lsl #32
    // 0xa6e960: cmp             w2, NULL
    // 0xa6e964: b.eq            #0xa6ea6c
    // 0xa6e968: LoadField: r3 = r2->field_17
    //     0xa6e968: ldur            x3, [x2, #0x17]
    // 0xa6e96c: stur            x3, [fp, #-0x10]
    // 0xa6e970: cbnz            x3, #0xa6e984
    // 0xa6e974: r16 = "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    //     0xa6e974: ldr             x16, [PP, #0x2448]  ; [pp+0x2448] "A Dart object attempted to access a native peer, but the native peer has been collected (nullptr). This is usually the result of calling methods on a native-backed object when the native resources have already been disposed."
    // 0xa6e978: SaveReg r16
    //     0xa6e978: str             x16, [SP, #-8]!
    // 0xa6e97c: r0 = _throwNew()
    //     0xa6e97c: bl              #0x4b5570  ; [dart:core] StateError::_throwNew
    // 0xa6e980: add             SP, SP, #8
    // 0xa6e984: ldur            x2, [fp, #-0x18]
    // 0xa6e988: ldur            x0, [fp, #-0x10]
    // 0xa6e98c: r1 = <Never>
    //     0xa6e98c: ldr             x1, [PP, #0x1ce8]  ; [pp+0x1ce8] TypeArguments: <Never>
    // 0xa6e990: r0 = Pointer()
    //     0xa6e990: bl              #0x4ba128  ; AllocatePointerStub -> Pointer<X0 bound NativeType> (size=-0x8)
    // 0xa6e994: mov             x1, x0
    // 0xa6e998: ldur            x0, [fp, #-0x10]
    // 0xa6e99c: StoreField: r1->field_7 = r0
    //     0xa6e99c: stur            x0, [x1, #7]
    // 0xa6e9a0: ldur            x16, [fp, #-0x50]
    // 0xa6e9a4: stp             x1, x16, [SP, #-0x10]!
    // 0xa6e9a8: r16 = 0.785398
    //     0xa6e9a8: add             x16, PP, #0x2e, lsl #12  ; [pp+0x2ec38] 0.7853981633974483
    //     0xa6e9ac: ldr             x16, [x16, #0xc38]
    // 0xa6e9b0: SaveReg r16
    //     0xa6e9b0: str             x16, [SP, #-8]!
    // 0xa6e9b4: ldur            x0, [fp, #-0x50]
    // 0xa6e9b8: ClosureCall
    //     0xa6e9b8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0xa6e9bc: ldur            x2, [x0, #0x1f]
    //     0xa6e9c0: blr             x2
    // 0xa6e9c4: add             SP, SP, #0x18
    // 0xa6e9c8: ldur            x0, [fp, #-0x18]
    // 0xa6e9cc: add             x8, x0, #1
    // 0xa6e9d0: ldur            x1, [fp, #-0x30]
    // 0xa6e9d4: ldur            x5, [fp, #-0x20]
    // 0xa6e9d8: ldur            x3, [fp, #-8]
    // 0xa6e9dc: ldur            x4, [fp, #-0x28]
    // 0xa6e9e0: ldur            x2, [fp, #-0x38]
    // 0xa6e9e4: d1 = 8.000000
    //     0xa6e9e4: fmov            d1, #8.00000000
    // 0xa6e9e8: b               #0xa6e7f4
    // 0xa6e9ec: ldr             x16, [fp, #0x18]
    // 0xa6e9f0: SaveReg r16
    //     0xa6e9f0: str             x16, [SP, #-8]!
    // 0xa6e9f4: r0 = restore()
    //     0xa6e9f4: bl              #0x65586c  ; [dart:ui] Canvas::restore
    // 0xa6e9f8: add             SP, SP, #8
    // 0xa6e9fc: r0 = Null
    //     0xa6e9fc: mov             x0, NULL
    // 0xa6ea00: LeaveFrame
    //     0xa6ea00: mov             SP, fp
    //     0xa6ea04: ldp             fp, lr, [SP], #0x10
    // 0xa6ea08: ret
    //     0xa6ea08: ret             
    // 0xa6ea0c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6ea0c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6ea10: b               #0xa6e6f8
    // 0xa6ea14: stp             q2, q3, [SP, #-0x20]!
    // 0xa6ea18: r0 = AllocateDouble()
    //     0xa6ea18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6ea1c: ldp             q2, q3, [SP], #0x20
    // 0xa6ea20: b               #0xa6e758
    // 0xa6ea24: r9 = _value
    //     0xa6ea24: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0xa6ea28: ldr             x9, [x9, #0xbb0]
    // 0xa6ea2c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa6ea2c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa6ea30: stp             q1, q2, [SP, #-0x20]!
    // 0xa6ea34: SaveReg r0
    //     0xa6ea34: str             x0, [SP, #-8]!
    // 0xa6ea38: d0 = 0.000000
    //     0xa6ea38: fmov            d0, d2
    // 0xa6ea3c: r0 = 212
    //     0xa6ea3c: mov             x0, #0xd4
    // 0xa6ea40: r24 = DoubleToIntegerStub
    //     0xa6ea40: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0xa6ea44: LoadField: r30 = r24->field_7
    //     0xa6ea44: ldur            lr, [x24, #7]
    // 0xa6ea48: blr             lr
    // 0xa6ea4c: mov             x1, x0
    // 0xa6ea50: RestoreReg r0
    //     0xa6ea50: ldr             x0, [SP], #8
    // 0xa6ea54: ldp             q1, q2, [SP], #0x20
    // 0xa6ea58: b               #0xa6e7b8
    // 0xa6ea5c: r0 = StackOverflowSharedWithFPURegs()
    //     0xa6ea5c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xa6ea60: b               #0xa6e818
    // 0xa6ea64: add             x10, x10, x0
    // 0xa6ea68: b               #0xa6e83c
    // 0xa6ea6c: r0 = NullErrorSharedWithoutFPURegs()
    //     0xa6ea6c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xa797e8, size: 0x1e0
    // 0xa797e8: EnterFrame
    //     0xa797e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa797ec: mov             fp, SP
    // 0xa797f0: AllocStack(0x18)
    //     0xa797f0: sub             SP, SP, #0x18
    // 0xa797f4: CheckStackOverflow
    //     0xa797f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa797f8: cmp             SP, x16
    //     0xa797fc: b.ls            #0xa799c0
    // 0xa79800: ldr             x0, [fp, #0x10]
    // 0xa79804: r2 = Null
    //     0xa79804: mov             x2, NULL
    // 0xa79808: r1 = Null
    //     0xa79808: mov             x1, NULL
    // 0xa7980c: r4 = 59
    //     0xa7980c: mov             x4, #0x3b
    // 0xa79810: branchIfSmi(r0, 0xa7981c)
    //     0xa79810: tbz             w0, #0, #0xa7981c
    // 0xa79814: r4 = LoadClassIdInstr(r0)
    //     0xa79814: ldur            x4, [x0, #-1]
    //     0xa79818: ubfx            x4, x4, #0xc, #0x14
    // 0xa7981c: r17 = 4379
    //     0xa7981c: mov             x17, #0x111b
    // 0xa79820: cmp             x4, x17
    // 0xa79824: b.eq            #0xa7983c
    // 0xa79828: r8 = _CupertinoActivityIndicatorPainter
    //     0xa79828: add             x8, PP, #0x2e, lsl #12  ; [pp+0x2ec10] Type: _CupertinoActivityIndicatorPainter
    //     0xa7982c: ldr             x8, [x8, #0xc10]
    // 0xa79830: r3 = Null
    //     0xa79830: add             x3, PP, #0x2e, lsl #12  ; [pp+0x2ec18] Null
    //     0xa79834: ldr             x3, [x3, #0xc18]
    // 0xa79838: r0 = DefaultTypeTest()
    //     0xa79838: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa7983c: ldr             x0, [fp, #0x10]
    // 0xa79840: LoadField: r1 = r0->field_b
    //     0xa79840: ldur            w1, [x0, #0xb]
    // 0xa79844: DecompressPointer r1
    //     0xa79844: add             x1, x1, HEAP, lsl #32
    // 0xa79848: ldr             x2, [fp, #0x18]
    // 0xa7984c: LoadField: r3 = r2->field_b
    //     0xa7984c: ldur            w3, [x2, #0xb]
    // 0xa79850: DecompressPointer r3
    //     0xa79850: add             x3, x3, HEAP, lsl #32
    // 0xa79854: cmp             w1, w3
    // 0xa79858: b.ne            #0xa79994
    // 0xa7985c: LoadField: r1 = r0->field_f
    //     0xa7985c: ldur            w1, [x0, #0xf]
    // 0xa79860: DecompressPointer r1
    //     0xa79860: add             x1, x1, HEAP, lsl #32
    // 0xa79864: stur            x1, [fp, #-0x18]
    // 0xa79868: LoadField: r0 = r2->field_f
    //     0xa79868: ldur            w0, [x2, #0xf]
    // 0xa7986c: DecompressPointer r0
    //     0xa7986c: add             x0, x0, HEAP, lsl #32
    // 0xa79870: stur            x0, [fp, #-0x10]
    // 0xa79874: r2 = LoadClassIdInstr(r1)
    //     0xa79874: ldur            x2, [x1, #-1]
    //     0xa79878: ubfx            x2, x2, #0xc, #0x14
    // 0xa7987c: lsl             x2, x2, #1
    // 0xa79880: stur            x2, [fp, #-8]
    // 0xa79884: r17 = 10114
    //     0xa79884: mov             x17, #0x2782
    // 0xa79888: cmp             w2, w17
    // 0xa7988c: b.eq            #0xa7989c
    // 0xa79890: r17 = 10118
    //     0xa79890: mov             x17, #0x2786
    // 0xa79894: cmp             w2, w17
    // 0xa79898: b.ne            #0xa7996c
    // 0xa7989c: cmp             w1, w0
    // 0xa798a0: b.eq            #0xa7999c
    // 0xa798a4: stp             x1, x0, [SP, #-0x10]!
    // 0xa798a8: r0 = _haveSameRuntimeType()
    //     0xa798a8: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xa798ac: add             SP, SP, #0x10
    // 0xa798b0: tbnz            w0, #4, #0xa79994
    // 0xa798b4: ldur            x0, [fp, #-0x10]
    // 0xa798b8: r1 = LoadClassIdInstr(r0)
    //     0xa798b8: ldur            x1, [x0, #-1]
    //     0xa798bc: ubfx            x1, x1, #0xc, #0x14
    // 0xa798c0: lsl             x1, x1, #1
    // 0xa798c4: r17 = 10124
    //     0xa798c4: mov             x17, #0x278c
    // 0xa798c8: cmp             w1, w17
    // 0xa798cc: b.gt            #0xa798dc
    // 0xa798d0: r17 = 10122
    //     0xa798d0: mov             x17, #0x278a
    // 0xa798d4: cmp             w1, w17
    // 0xa798d8: b.ge            #0xa798f4
    // 0xa798dc: r17 = 10114
    //     0xa798dc: mov             x17, #0x2782
    // 0xa798e0: cmp             w1, w17
    // 0xa798e4: b.eq            #0xa798f4
    // 0xa798e8: r17 = 10118
    //     0xa798e8: mov             x17, #0x2786
    // 0xa798ec: cmp             w1, w17
    // 0xa798f0: b.ne            #0xa798fc
    // 0xa798f4: LoadField: r1 = r0->field_7
    //     0xa798f4: ldur            x1, [x0, #7]
    // 0xa798f8: b               #0xa7990c
    // 0xa798fc: LoadField: r1 = r0->field_f
    //     0xa798fc: ldur            w1, [x0, #0xf]
    // 0xa79900: DecompressPointer r1
    //     0xa79900: add             x1, x1, HEAP, lsl #32
    // 0xa79904: LoadField: r0 = r1->field_7
    //     0xa79904: ldur            x0, [x1, #7]
    // 0xa79908: mov             x1, x0
    // 0xa7990c: ldur            x0, [fp, #-8]
    // 0xa79910: r17 = 10124
    //     0xa79910: mov             x17, #0x278c
    // 0xa79914: cmp             w0, w17
    // 0xa79918: b.gt            #0xa79928
    // 0xa7991c: r17 = 10122
    //     0xa7991c: mov             x17, #0x278a
    // 0xa79920: cmp             w0, w17
    // 0xa79924: b.ge            #0xa79940
    // 0xa79928: r17 = 10114
    //     0xa79928: mov             x17, #0x2782
    // 0xa7992c: cmp             w0, w17
    // 0xa79930: b.eq            #0xa79940
    // 0xa79934: r17 = 10118
    //     0xa79934: mov             x17, #0x2786
    // 0xa79938: cmp             w0, w17
    // 0xa7993c: b.ne            #0xa7994c
    // 0xa79940: ldur            x2, [fp, #-0x18]
    // 0xa79944: LoadField: r0 = r2->field_7
    //     0xa79944: ldur            x0, [x2, #7]
    // 0xa79948: b               #0xa79960
    // 0xa7994c: ldur            x2, [fp, #-0x18]
    // 0xa79950: LoadField: r0 = r2->field_f
    //     0xa79950: ldur            w0, [x2, #0xf]
    // 0xa79954: DecompressPointer r0
    //     0xa79954: add             x0, x0, HEAP, lsl #32
    // 0xa79958: LoadField: r2 = r0->field_7
    //     0xa79958: ldur            x2, [x0, #7]
    // 0xa7995c: mov             x0, x2
    // 0xa79960: cmp             x1, x0
    // 0xa79964: b.eq            #0xa7999c
    // 0xa79968: b               #0xa79994
    // 0xa7996c: mov             x2, x1
    // 0xa79970: r1 = LoadClassIdInstr(r2)
    //     0xa79970: ldur            x1, [x2, #-1]
    //     0xa79974: ubfx            x1, x1, #0xc, #0x14
    // 0xa79978: stp             x0, x2, [SP, #-0x10]!
    // 0xa7997c: mov             x0, x1
    // 0xa79980: mov             lr, x0
    // 0xa79984: ldr             lr, [x21, lr, lsl #3]
    // 0xa79988: blr             lr
    // 0xa7998c: add             SP, SP, #0x10
    // 0xa79990: tbz             w0, #4, #0xa7999c
    // 0xa79994: r0 = true
    //     0xa79994: add             x0, NULL, #0x20  ; true
    // 0xa79998: b               #0xa799b4
    // 0xa7999c: d0 = 1.000000
    //     0xa7999c: fmov            d0, #1.00000000
    // 0xa799a0: fcmp            d0, d0
    // 0xa799a4: r16 = true
    //     0xa799a4: add             x16, NULL, #0x20  ; true
    // 0xa799a8: r17 = false
    //     0xa799a8: add             x17, NULL, #0x30  ; false
    // 0xa799ac: csel            x1, x16, x17, ne
    // 0xa799b0: mov             x0, x1
    // 0xa799b4: LeaveFrame
    //     0xa799b4: mov             SP, fp
    //     0xa799b8: ldp             fp, lr, [SP], #0x10
    // 0xa799bc: ret
    //     0xa799bc: ret             
    // 0xa799c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa799c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa799c4: b               #0xa79800
  }
}

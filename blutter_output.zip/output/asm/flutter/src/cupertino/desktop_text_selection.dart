// lib: , url: package:flutter/src/cupertino/desktop_text_selection.dart

// class id: 1049084, size: 0x8
class :: {

  static late final TextSelectionControls cupertinoDesktopTextSelectionHandleControls; // offset: 0xcc8
  static late final TextSelectionControls cupertinoDesktopTextSelectionControls; // offset: 0xccc

  static TextSelectionControls cupertinoDesktopTextSelectionControls() {
    // ** addr: 0x83ec28, size: 0x18
    // 0x83ec28: EnterFrame
    //     0x83ec28: stp             fp, lr, [SP, #-0x10]!
    //     0x83ec2c: mov             fp, SP
    // 0x83ec30: r0 = CupertinoDesktopTextSelectionControls()
    //     0x83ec30: bl              #0x83ec40  ; AllocateCupertinoDesktopTextSelectionControlsStub -> CupertinoDesktopTextSelectionControls (size=0x8)
    // 0x83ec34: LeaveFrame
    //     0x83ec34: mov             SP, fp
    //     0x83ec38: ldp             fp, lr, [SP], #0x10
    // 0x83ec3c: ret
    //     0x83ec3c: ret             
  }
  static TextSelectionControls cupertinoDesktopTextSelectionHandleControls() {
    // ** addr: 0x872dac, size: 0x18
    // 0x872dac: EnterFrame
    //     0x872dac: stp             fp, lr, [SP, #-0x10]!
    //     0x872db0: mov             fp, SP
    // 0x872db4: r0 = _CupertinoDesktopTextSelectionHandleControls()
    //     0x872db4: bl              #0x872dc4  ; Allocate_CupertinoDesktopTextSelectionHandleControlsStub -> _CupertinoDesktopTextSelectionHandleControls (size=0x8)
    // 0x872db8: LeaveFrame
    //     0x872db8: mov             SP, fp
    //     0x872dbc: ldp             fp, lr, [SP], #0x10
    // 0x872dc0: ret
    //     0x872dc0: ret             
  }
}

// class id: 3357, size: 0x14, field offset: 0x14
class _CupertinoDesktopTextSelectionControlsToolbarState extends State<_CupertinoDesktopTextSelectionControlsToolbar> {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7aee9c, size: 0x17c
    // 0x7aee9c: EnterFrame
    //     0x7aee9c: stp             fp, lr, [SP, #-0x10]!
    //     0x7aeea0: mov             fp, SP
    // 0x7aeea4: AllocStack(0x8)
    //     0x7aeea4: sub             SP, SP, #8
    // 0x7aeea8: CheckStackOverflow
    //     0x7aeea8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aeeac: cmp             SP, x16
    //     0x7aeeb0: b.ls            #0x7af008
    // 0x7aeeb4: ldr             x0, [fp, #0x10]
    // 0x7aeeb8: r2 = Null
    //     0x7aeeb8: mov             x2, NULL
    // 0x7aeebc: r1 = Null
    //     0x7aeebc: mov             x1, NULL
    // 0x7aeec0: r4 = 59
    //     0x7aeec0: mov             x4, #0x3b
    // 0x7aeec4: branchIfSmi(r0, 0x7aeed0)
    //     0x7aeec4: tbz             w0, #0, #0x7aeed0
    // 0x7aeec8: r4 = LoadClassIdInstr(r0)
    //     0x7aeec8: ldur            x4, [x0, #-1]
    //     0x7aeecc: ubfx            x4, x4, #0xc, #0x14
    // 0x7aeed0: r17 = 4182
    //     0x7aeed0: mov             x17, #0x1056
    // 0x7aeed4: cmp             x4, x17
    // 0x7aeed8: b.eq            #0x7aeef0
    // 0x7aeedc: r8 = _CupertinoDesktopTextSelectionControlsToolbar
    //     0x7aeedc: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4bb38] Type: _CupertinoDesktopTextSelectionControlsToolbar
    //     0x7aeee0: ldr             x8, [x8, #0xb38]
    // 0x7aeee4: r3 = Null
    //     0x7aeee4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bb40] Null
    //     0x7aeee8: ldr             x3, [x3, #0xb40]
    // 0x7aeeec: r0 = _CupertinoDesktopTextSelectionControlsToolbar()
    //     0x7aeeec: bl              #0x7af018  ; IsType__CupertinoDesktopTextSelectionControlsToolbar_Stub
    // 0x7aeef0: ldr             x3, [fp, #0x18]
    // 0x7aeef4: LoadField: r2 = r3->field_7
    //     0x7aeef4: ldur            w2, [x3, #7]
    // 0x7aeef8: DecompressPointer r2
    //     0x7aeef8: add             x2, x2, HEAP, lsl #32
    // 0x7aeefc: ldr             x0, [fp, #0x10]
    // 0x7aef00: r1 = Null
    //     0x7aef00: mov             x1, NULL
    // 0x7aef04: cmp             w2, NULL
    // 0x7aef08: b.eq            #0x7aef2c
    // 0x7aef0c: LoadField: r4 = r2->field_17
    //     0x7aef0c: ldur            w4, [x2, #0x17]
    // 0x7aef10: DecompressPointer r4
    //     0x7aef10: add             x4, x4, HEAP, lsl #32
    // 0x7aef14: r8 = X0 bound StatefulWidget
    //     0x7aef14: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7aef18: ldr             x8, [x8, #0x858]
    // 0x7aef1c: LoadField: r9 = r4->field_7
    //     0x7aef1c: ldur            x9, [x4, #7]
    // 0x7aef20: r3 = Null
    //     0x7aef20: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bb50] Null
    //     0x7aef24: ldr             x3, [x3, #0xb50]
    // 0x7aef28: blr             x9
    // 0x7aef2c: ldr             x0, [fp, #0x10]
    // 0x7aef30: LoadField: r1 = r0->field_b
    //     0x7aef30: ldur            w1, [x0, #0xb]
    // 0x7aef34: DecompressPointer r1
    //     0x7aef34: add             x1, x1, HEAP, lsl #32
    // 0x7aef38: ldr             x0, [fp, #0x18]
    // 0x7aef3c: stur            x1, [fp, #-8]
    // 0x7aef40: LoadField: r2 = r0->field_b
    //     0x7aef40: ldur            w2, [x0, #0xb]
    // 0x7aef44: DecompressPointer r2
    //     0x7aef44: add             x2, x2, HEAP, lsl #32
    // 0x7aef48: cmp             w2, NULL
    // 0x7aef4c: b.eq            #0x7af010
    // 0x7aef50: LoadField: r3 = r2->field_b
    //     0x7aef50: ldur            w3, [x2, #0xb]
    // 0x7aef54: DecompressPointer r3
    //     0x7aef54: add             x3, x3, HEAP, lsl #32
    // 0x7aef58: cmp             w1, w3
    // 0x7aef5c: b.eq            #0x7aeff8
    // 0x7aef60: cmp             w1, NULL
    // 0x7aef64: b.eq            #0x7aefa0
    // 0x7aef68: r1 = 1
    //     0x7aef68: mov             x1, #1
    // 0x7aef6c: r0 = AllocateContext()
    //     0x7aef6c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7aef70: mov             x1, x0
    // 0x7aef74: ldr             x0, [fp, #0x18]
    // 0x7aef78: StoreField: r1->field_f = r0
    //     0x7aef78: stur            w0, [x1, #0xf]
    // 0x7aef7c: mov             x2, x1
    // 0x7aef80: r1 = Function '_onChangedClipboardStatus@592392285':.
    //     0x7aef80: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb28] AnonymousClosure: (0x7af03c), in [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7af084)
    //     0x7aef84: ldr             x1, [x1, #0xb28]
    // 0x7aef88: r0 = AllocateClosure()
    //     0x7aef88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7aef8c: ldur            x16, [fp, #-8]
    // 0x7aef90: stp             x0, x16, [SP, #-0x10]!
    // 0x7aef94: r0 = removeListener()
    //     0x7aef94: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0x7aef98: add             SP, SP, #0x10
    // 0x7aef9c: ldr             x0, [fp, #0x18]
    // 0x7aefa0: LoadField: r1 = r0->field_b
    //     0x7aefa0: ldur            w1, [x0, #0xb]
    // 0x7aefa4: DecompressPointer r1
    //     0x7aefa4: add             x1, x1, HEAP, lsl #32
    // 0x7aefa8: cmp             w1, NULL
    // 0x7aefac: b.eq            #0x7af014
    // 0x7aefb0: LoadField: r2 = r1->field_b
    //     0x7aefb0: ldur            w2, [x1, #0xb]
    // 0x7aefb4: DecompressPointer r2
    //     0x7aefb4: add             x2, x2, HEAP, lsl #32
    // 0x7aefb8: stur            x2, [fp, #-8]
    // 0x7aefbc: cmp             w2, NULL
    // 0x7aefc0: b.eq            #0x7aeff8
    // 0x7aefc4: r1 = 1
    //     0x7aefc4: mov             x1, #1
    // 0x7aefc8: r0 = AllocateContext()
    //     0x7aefc8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7aefcc: mov             x1, x0
    // 0x7aefd0: ldr             x0, [fp, #0x18]
    // 0x7aefd4: StoreField: r1->field_f = r0
    //     0x7aefd4: stur            w0, [x1, #0xf]
    // 0x7aefd8: mov             x2, x1
    // 0x7aefdc: r1 = Function '_onChangedClipboardStatus@592392285':.
    //     0x7aefdc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb28] AnonymousClosure: (0x7af03c), in [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7af084)
    //     0x7aefe0: ldr             x1, [x1, #0xb28]
    // 0x7aefe4: r0 = AllocateClosure()
    //     0x7aefe4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7aefe8: ldur            x16, [fp, #-8]
    // 0x7aefec: stp             x0, x16, [SP, #-0x10]!
    // 0x7aeff0: r0 = addListener()
    //     0x7aeff0: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x7aeff4: add             SP, SP, #0x10
    // 0x7aeff8: r0 = Null
    //     0x7aeff8: mov             x0, NULL
    // 0x7aeffc: LeaveFrame
    //     0x7aeffc: mov             SP, fp
    //     0x7af000: ldp             fp, lr, [SP], #0x10
    // 0x7af004: ret
    //     0x7af004: ret             
    // 0x7af008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7af008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7af00c: b               #0x7aeeb4
    // 0x7af010: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af010: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7af014: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7af014: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onChangedClipboardStatus(dynamic) {
    // ** addr: 0x7af03c, size: 0x48
    // 0x7af03c: EnterFrame
    //     0x7af03c: stp             fp, lr, [SP, #-0x10]!
    //     0x7af040: mov             fp, SP
    // 0x7af044: ldr             x0, [fp, #0x10]
    // 0x7af048: LoadField: r1 = r0->field_17
    //     0x7af048: ldur            w1, [x0, #0x17]
    // 0x7af04c: DecompressPointer r1
    //     0x7af04c: add             x1, x1, HEAP, lsl #32
    // 0x7af050: CheckStackOverflow
    //     0x7af050: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7af054: cmp             SP, x16
    //     0x7af058: b.ls            #0x7af07c
    // 0x7af05c: LoadField: r0 = r1->field_f
    //     0x7af05c: ldur            w0, [x1, #0xf]
    // 0x7af060: DecompressPointer r0
    //     0x7af060: add             x0, x0, HEAP, lsl #32
    // 0x7af064: SaveReg r0
    //     0x7af064: str             x0, [SP, #-8]!
    // 0x7af068: r0 = _onChangedClipboardStatus()
    //     0x7af068: bl              #0x7af084  ; [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus
    // 0x7af06c: add             SP, SP, #8
    // 0x7af070: LeaveFrame
    //     0x7af070: mov             SP, fp
    //     0x7af074: ldp             fp, lr, [SP], #0x10
    // 0x7af078: ret
    //     0x7af078: ret             
    // 0x7af07c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7af07c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7af080: b               #0x7af05c
  }
  _ _onChangedClipboardStatus(/* No info */) {
    // ** addr: 0x7af084, size: 0x4c
    // 0x7af084: EnterFrame
    //     0x7af084: stp             fp, lr, [SP, #-0x10]!
    //     0x7af088: mov             fp, SP
    // 0x7af08c: CheckStackOverflow
    //     0x7af08c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7af090: cmp             SP, x16
    //     0x7af094: b.ls            #0x7af0c8
    // 0x7af098: r1 = Function '<anonymous closure>':.
    //     0x7af098: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb30] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x7af09c: ldr             x1, [x1, #0xb30]
    // 0x7af0a0: r2 = Null
    //     0x7af0a0: mov             x2, NULL
    // 0x7af0a4: r0 = AllocateClosure()
    //     0x7af0a4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7af0a8: ldr             x16, [fp, #0x10]
    // 0x7af0ac: stp             x0, x16, [SP, #-0x10]!
    // 0x7af0b0: r0 = setState()
    //     0x7af0b0: bl              #0x507a60  ; [package:flutter/src/widgets/framework.dart] State::setState
    // 0x7af0b4: add             SP, SP, #0x10
    // 0x7af0b8: r0 = Null
    //     0x7af0b8: mov             x0, NULL
    // 0x7af0bc: LeaveFrame
    //     0x7af0bc: mov             SP, fp
    //     0x7af0c0: ldp             fp, lr, [SP], #0x10
    // 0x7af0c4: ret
    //     0x7af0c4: ret             
    // 0x7af0c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7af0c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7af0cc: b               #0x7af098
  }
  _ build(/* No info */) {
    // ** addr: 0x8402d8, size: 0x854
    // 0x8402d8: EnterFrame
    //     0x8402d8: stp             fp, lr, [SP, #-0x10]!
    //     0x8402dc: mov             fp, SP
    // 0x8402e0: AllocStack(0x38)
    //     0x8402e0: sub             SP, SP, #0x38
    // 0x8402e4: CheckStackOverflow
    //     0x8402e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8402e8: cmp             SP, x16
    //     0x8402ec: b.ls            #0x840ad8
    // 0x8402f0: ldr             x0, [fp, #0x18]
    // 0x8402f4: LoadField: r1 = r0->field_b
    //     0x8402f4: ldur            w1, [x0, #0xb]
    // 0x8402f8: DecompressPointer r1
    //     0x8402f8: add             x1, x1, HEAP, lsl #32
    // 0x8402fc: cmp             w1, NULL
    // 0x840300: b.eq            #0x840ae0
    // 0x840304: LoadField: r2 = r1->field_1b
    //     0x840304: ldur            w2, [x1, #0x1b]
    // 0x840308: DecompressPointer r2
    //     0x840308: add             x2, x2, HEAP, lsl #32
    // 0x84030c: cmp             w2, NULL
    // 0x840310: b.eq            #0x840350
    // 0x840314: LoadField: r2 = r1->field_b
    //     0x840314: ldur            w2, [x1, #0xb]
    // 0x840318: DecompressPointer r2
    //     0x840318: add             x2, x2, HEAP, lsl #32
    // 0x84031c: cmp             w2, NULL
    // 0x840320: b.eq            #0x840350
    // 0x840324: LoadField: r1 = r2->field_27
    //     0x840324: ldur            w1, [x2, #0x27]
    // 0x840328: DecompressPointer r1
    //     0x840328: add             x1, x1, HEAP, lsl #32
    // 0x84032c: r16 = Instance_ClipboardStatus
    //     0x84032c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc88] Obj!ClipboardStatus@b63451
    //     0x840330: ldr             x16, [x16, #0xc88]
    // 0x840334: cmp             w1, w16
    // 0x840338: b.ne            #0x840350
    // 0x84033c: r0 = Instance_SizedBox
    //     0x84033c: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x840340: ldr             x0, [x0, #0x738]
    // 0x840344: LeaveFrame
    //     0x840344: mov             SP, fp
    //     0x840348: ldp             fp, lr, [SP], #0x10
    // 0x84034c: ret
    //     0x84034c: ret             
    // 0x840350: ldr             x16, [fp, #0x10]
    // 0x840354: SaveReg r16
    //     0x840354: str             x16, [SP, #-8]!
    // 0x840358: r0 = of()
    //     0x840358: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x84035c: add             SP, SP, #8
    // 0x840360: mov             x1, x0
    // 0x840364: ldr             x0, [fp, #0x18]
    // 0x840368: LoadField: r2 = r0->field_b
    //     0x840368: ldur            w2, [x0, #0xb]
    // 0x84036c: DecompressPointer r2
    //     0x84036c: add             x2, x2, HEAP, lsl #32
    // 0x840370: cmp             w2, NULL
    // 0x840374: b.eq            #0x840ae4
    // 0x840378: LoadField: r3 = r2->field_27
    //     0x840378: ldur            w3, [x2, #0x27]
    // 0x84037c: DecompressPointer r3
    //     0x84037c: add             x3, x3, HEAP, lsl #32
    // 0x840380: LoadField: d0 = r3->field_7
    //     0x840380: ldur            d0, [x3, #7]
    // 0x840384: LoadField: r4 = r2->field_f
    //     0x840384: ldur            w4, [x2, #0xf]
    // 0x840388: DecompressPointer r4
    //     0x840388: add             x4, x4, HEAP, lsl #32
    // 0x84038c: LoadField: d1 = r4->field_7
    //     0x84038c: ldur            d1, [x4, #7]
    // 0x840390: fsub            d2, d0, d1
    // 0x840394: LoadField: r2 = r1->field_23
    //     0x840394: ldur            w2, [x1, #0x23]
    // 0x840398: DecompressPointer r2
    //     0x840398: add             x2, x2, HEAP, lsl #32
    // 0x84039c: LoadField: d0 = r2->field_7
    //     0x84039c: ldur            d0, [x2, #7]
    // 0x8403a0: LoadField: r5 = r1->field_7
    //     0x8403a0: ldur            w5, [x1, #7]
    // 0x8403a4: DecompressPointer r5
    //     0x8403a4: add             x5, x5, HEAP, lsl #32
    // 0x8403a8: LoadField: d1 = r5->field_7
    //     0x8403a8: ldur            d1, [x5, #7]
    // 0x8403ac: LoadField: d3 = r2->field_17
    //     0x8403ac: ldur            d3, [x2, #0x17]
    // 0x8403b0: fsub            d4, d1, d3
    // 0x8403b4: fcmp            d2, d0
    // 0x8403b8: b.vs            #0x8403c0
    // 0x8403bc: b.lt            #0x8403e8
    // 0x8403c0: fcmp            d2, d4
    // 0x8403c4: b.vs            #0x8403d4
    // 0x8403c8: b.le            #0x8403d4
    // 0x8403cc: mov             v0.16b, v4.16b
    // 0x8403d0: b               #0x8403e8
    // 0x8403d4: fcmp            d2, d2
    // 0x8403d8: b.vc            #0x8403e4
    // 0x8403dc: mov             v0.16b, v4.16b
    // 0x8403e0: b               #0x8403e8
    // 0x8403e4: mov             v0.16b, v2.16b
    // 0x8403e8: stur            d0, [fp, #-0x38]
    // 0x8403ec: LoadField: d1 = r3->field_f
    //     0x8403ec: ldur            d1, [x3, #0xf]
    // 0x8403f0: LoadField: d2 = r4->field_f
    //     0x8403f0: ldur            d2, [x4, #0xf]
    // 0x8403f4: fsub            d3, d1, d2
    // 0x8403f8: stur            d3, [fp, #-0x30]
    // 0x8403fc: r0 = Offset()
    //     0x8403fc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x840400: ldur            d0, [fp, #-0x38]
    // 0x840404: stur            x0, [fp, #-8]
    // 0x840408: StoreField: r0->field_7 = d0
    //     0x840408: stur            d0, [x0, #7]
    // 0x84040c: ldur            d0, [fp, #-0x30]
    // 0x840410: StoreField: r0->field_f = d0
    //     0x840410: stur            d0, [x0, #0xf]
    // 0x840414: r16 = <Widget>
    //     0x840414: add             x16, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x840418: ldr             x16, [x16, #0xea8]
    // 0x84041c: stp             xzr, x16, [SP, #-0x10]!
    // 0x840420: r0 = _GrowableList()
    //     0x840420: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x840424: add             SP, SP, #0x10
    // 0x840428: stur            x0, [fp, #-0x10]
    // 0x84042c: ldr             x16, [fp, #0x10]
    // 0x840430: SaveReg r16
    //     0x840430: str             x16, [SP, #-8]!
    // 0x840434: r0 = of()
    //     0x840434: bl              #0x840c34  ; [package:flutter/src/cupertino/localizations.dart] CupertinoLocalizations::of
    // 0x840438: add             SP, SP, #8
    // 0x84043c: ldr             x16, [fp, #0x10]
    // 0x840440: SaveReg r16
    //     0x840440: str             x16, [SP, #-8]!
    // 0x840444: r0 = of()
    //     0x840444: bl              #0x5ac93c  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::of
    // 0x840448: add             SP, SP, #8
    // 0x84044c: LoadField: d0 = r0->field_b
    //     0x84044c: ldur            d0, [x0, #0xb]
    // 0x840450: d1 = 1.000000
    //     0x840450: fmov            d1, #1.00000000
    // 0x840454: fdiv            d2, d1, d0
    // 0x840458: r0 = inline_Allocate_Double()
    //     0x840458: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x84045c: add             x0, x0, #0x10
    //     0x840460: cmp             x1, x0
    //     0x840464: b.ls            #0x840ae8
    //     0x840468: str             x0, [THR, #0x60]  ; THR::top
    //     0x84046c: sub             x0, x0, #0xf
    //     0x840470: mov             x1, #0xd108
    //     0x840474: movk            x1, #3, lsl #16
    //     0x840478: stur            x1, [x0, #-1]
    // 0x84047c: StoreField: r0->field_7 = d2
    //     0x84047c: stur            d2, [x0, #7]
    // 0x840480: stur            x0, [fp, #-0x18]
    // 0x840484: r0 = SizedBox()
    //     0x840484: bl              #0x82559c  ; AllocateSizedBoxStub -> SizedBox (size=0x18)
    // 0x840488: mov             x1, x0
    // 0x84048c: ldur            x0, [fp, #-0x18]
    // 0x840490: stur            x1, [fp, #-0x28]
    // 0x840494: StoreField: r1->field_f = r0
    //     0x840494: stur            w0, [x1, #0xf]
    // 0x840498: ldr             x0, [fp, #0x18]
    // 0x84049c: LoadField: r2 = r0->field_b
    //     0x84049c: ldur            w2, [x0, #0xb]
    // 0x8404a0: DecompressPointer r2
    //     0x8404a0: add             x2, x2, HEAP, lsl #32
    // 0x8404a4: cmp             w2, NULL
    // 0x8404a8: b.eq            #0x840af8
    // 0x8404ac: LoadField: r3 = r2->field_17
    //     0x8404ac: ldur            w3, [x2, #0x17]
    // 0x8404b0: DecompressPointer r3
    //     0x8404b0: add             x3, x3, HEAP, lsl #32
    // 0x8404b4: stur            x3, [fp, #-0x20]
    // 0x8404b8: cmp             w3, NULL
    // 0x8404bc: b.eq            #0x840608
    // 0x8404c0: ldur            x2, [fp, #-0x10]
    // 0x8404c4: LoadField: r4 = r2->field_b
    //     0x8404c4: ldur            w4, [x2, #0xb]
    // 0x8404c8: DecompressPointer r4
    //     0x8404c8: add             x4, x4, HEAP, lsl #32
    // 0x8404cc: stur            x4, [fp, #-0x18]
    // 0x8404d0: cbz             w4, #0x840550
    // 0x8404d4: LoadField: r5 = r2->field_f
    //     0x8404d4: ldur            w5, [x2, #0xf]
    // 0x8404d8: DecompressPointer r5
    //     0x8404d8: add             x5, x5, HEAP, lsl #32
    // 0x8404dc: LoadField: r6 = r5->field_b
    //     0x8404dc: ldur            w6, [x5, #0xb]
    // 0x8404e0: DecompressPointer r6
    //     0x8404e0: add             x6, x6, HEAP, lsl #32
    // 0x8404e4: cmp             w4, w6
    // 0x8404e8: b.ne            #0x8404f8
    // 0x8404ec: SaveReg r2
    //     0x8404ec: str             x2, [SP, #-8]!
    // 0x8404f0: r0 = _growToNextCapacity()
    //     0x8404f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8404f4: add             SP, SP, #8
    // 0x8404f8: ldur            x2, [fp, #-0x10]
    // 0x8404fc: ldur            x0, [fp, #-0x18]
    // 0x840500: r3 = LoadInt32Instr(r0)
    //     0x840500: sbfx            x3, x0, #1, #0x1f
    // 0x840504: add             x0, x3, #1
    // 0x840508: lsl             x1, x0, #1
    // 0x84050c: StoreField: r2->field_b = r1
    //     0x84050c: stur            w1, [x2, #0xb]
    // 0x840510: mov             x1, x3
    // 0x840514: cmp             x1, x0
    // 0x840518: b.hs            #0x840afc
    // 0x84051c: LoadField: r1 = r2->field_f
    //     0x84051c: ldur            w1, [x2, #0xf]
    // 0x840520: DecompressPointer r1
    //     0x840520: add             x1, x1, HEAP, lsl #32
    // 0x840524: ldur            x0, [fp, #-0x28]
    // 0x840528: ArrayStore: r1[r3] = r0  ; List_4
    //     0x840528: add             x25, x1, x3, lsl #2
    //     0x84052c: add             x25, x25, #0xf
    //     0x840530: str             w0, [x25]
    //     0x840534: tbz             w0, #0, #0x840550
    //     0x840538: ldurb           w16, [x1, #-1]
    //     0x84053c: ldurb           w17, [x0, #-1]
    //     0x840540: and             x16, x17, x16, lsr #2
    //     0x840544: tst             x16, HEAP, lsr #32
    //     0x840548: b.eq            #0x840550
    //     0x84054c: bl              #0xd67e5c
    // 0x840550: r0 = CupertinoDesktopTextSelectionToolbarButton()
    //     0x840550: bl              #0x840c28  ; AllocateCupertinoDesktopTextSelectionToolbarButtonStub -> CupertinoDesktopTextSelectionToolbarButton (size=0x18)
    // 0x840554: stur            x0, [fp, #-0x18]
    // 0x840558: ldr             x16, [fp, #0x10]
    // 0x84055c: stp             x16, x0, [SP, #-0x10]!
    // 0x840560: ldur            x16, [fp, #-0x20]
    // 0x840564: r30 = "Cut"
    //     0x840564: add             lr, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Cut"
    //     0x840568: ldr             lr, [lr, #0xdd0]
    // 0x84056c: stp             lr, x16, [SP, #-0x10]!
    // 0x840570: r0 = CupertinoDesktopTextSelectionToolbarButton.text()
    //     0x840570: bl              #0x840b38  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] CupertinoDesktopTextSelectionToolbarButton::CupertinoDesktopTextSelectionToolbarButton.text
    // 0x840574: add             SP, SP, #0x20
    // 0x840578: ldur            x0, [fp, #-0x10]
    // 0x84057c: LoadField: r1 = r0->field_b
    //     0x84057c: ldur            w1, [x0, #0xb]
    // 0x840580: DecompressPointer r1
    //     0x840580: add             x1, x1, HEAP, lsl #32
    // 0x840584: stur            x1, [fp, #-0x20]
    // 0x840588: LoadField: r2 = r0->field_f
    //     0x840588: ldur            w2, [x0, #0xf]
    // 0x84058c: DecompressPointer r2
    //     0x84058c: add             x2, x2, HEAP, lsl #32
    // 0x840590: LoadField: r3 = r2->field_b
    //     0x840590: ldur            w3, [x2, #0xb]
    // 0x840594: DecompressPointer r3
    //     0x840594: add             x3, x3, HEAP, lsl #32
    // 0x840598: cmp             w1, w3
    // 0x84059c: b.ne            #0x8405ac
    // 0x8405a0: SaveReg r0
    //     0x8405a0: str             x0, [SP, #-8]!
    // 0x8405a4: r0 = _growToNextCapacity()
    //     0x8405a4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8405a8: add             SP, SP, #8
    // 0x8405ac: ldur            x2, [fp, #-0x10]
    // 0x8405b0: ldur            x0, [fp, #-0x20]
    // 0x8405b4: r3 = LoadInt32Instr(r0)
    //     0x8405b4: sbfx            x3, x0, #1, #0x1f
    // 0x8405b8: add             x0, x3, #1
    // 0x8405bc: lsl             x1, x0, #1
    // 0x8405c0: StoreField: r2->field_b = r1
    //     0x8405c0: stur            w1, [x2, #0xb]
    // 0x8405c4: mov             x1, x3
    // 0x8405c8: cmp             x1, x0
    // 0x8405cc: b.hs            #0x840b00
    // 0x8405d0: LoadField: r1 = r2->field_f
    //     0x8405d0: ldur            w1, [x2, #0xf]
    // 0x8405d4: DecompressPointer r1
    //     0x8405d4: add             x1, x1, HEAP, lsl #32
    // 0x8405d8: ldur            x0, [fp, #-0x18]
    // 0x8405dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8405dc: add             x25, x1, x3, lsl #2
    //     0x8405e0: add             x25, x25, #0xf
    //     0x8405e4: str             w0, [x25]
    //     0x8405e8: tbz             w0, #0, #0x840604
    //     0x8405ec: ldurb           w16, [x1, #-1]
    //     0x8405f0: ldurb           w17, [x0, #-1]
    //     0x8405f4: and             x16, x17, x16, lsr #2
    //     0x8405f8: tst             x16, HEAP, lsr #32
    //     0x8405fc: b.eq            #0x840604
    //     0x840600: bl              #0xd67e5c
    // 0x840604: b               #0x84060c
    // 0x840608: ldur            x2, [fp, #-0x10]
    // 0x84060c: ldr             x0, [fp, #0x18]
    // 0x840610: LoadField: r1 = r0->field_b
    //     0x840610: ldur            w1, [x0, #0xb]
    // 0x840614: DecompressPointer r1
    //     0x840614: add             x1, x1, HEAP, lsl #32
    // 0x840618: cmp             w1, NULL
    // 0x84061c: b.eq            #0x840b04
    // 0x840620: LoadField: r3 = r1->field_13
    //     0x840620: ldur            w3, [x1, #0x13]
    // 0x840624: DecompressPointer r3
    //     0x840624: add             x3, x3, HEAP, lsl #32
    // 0x840628: stur            x3, [fp, #-0x20]
    // 0x84062c: cmp             w3, NULL
    // 0x840630: b.eq            #0x840774
    // 0x840634: LoadField: r1 = r2->field_b
    //     0x840634: ldur            w1, [x2, #0xb]
    // 0x840638: DecompressPointer r1
    //     0x840638: add             x1, x1, HEAP, lsl #32
    // 0x84063c: stur            x1, [fp, #-0x18]
    // 0x840640: cbz             w1, #0x8406c0
    // 0x840644: LoadField: r4 = r2->field_f
    //     0x840644: ldur            w4, [x2, #0xf]
    // 0x840648: DecompressPointer r4
    //     0x840648: add             x4, x4, HEAP, lsl #32
    // 0x84064c: LoadField: r5 = r4->field_b
    //     0x84064c: ldur            w5, [x4, #0xb]
    // 0x840650: DecompressPointer r5
    //     0x840650: add             x5, x5, HEAP, lsl #32
    // 0x840654: cmp             w1, w5
    // 0x840658: b.ne            #0x840668
    // 0x84065c: SaveReg r2
    //     0x84065c: str             x2, [SP, #-8]!
    // 0x840660: r0 = _growToNextCapacity()
    //     0x840660: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x840664: add             SP, SP, #8
    // 0x840668: ldur            x2, [fp, #-0x10]
    // 0x84066c: ldur            x0, [fp, #-0x18]
    // 0x840670: r3 = LoadInt32Instr(r0)
    //     0x840670: sbfx            x3, x0, #1, #0x1f
    // 0x840674: add             x0, x3, #1
    // 0x840678: lsl             x1, x0, #1
    // 0x84067c: StoreField: r2->field_b = r1
    //     0x84067c: stur            w1, [x2, #0xb]
    // 0x840680: mov             x1, x3
    // 0x840684: cmp             x1, x0
    // 0x840688: b.hs            #0x840b08
    // 0x84068c: LoadField: r1 = r2->field_f
    //     0x84068c: ldur            w1, [x2, #0xf]
    // 0x840690: DecompressPointer r1
    //     0x840690: add             x1, x1, HEAP, lsl #32
    // 0x840694: ldur            x0, [fp, #-0x28]
    // 0x840698: ArrayStore: r1[r3] = r0  ; List_4
    //     0x840698: add             x25, x1, x3, lsl #2
    //     0x84069c: add             x25, x25, #0xf
    //     0x8406a0: str             w0, [x25]
    //     0x8406a4: tbz             w0, #0, #0x8406c0
    //     0x8406a8: ldurb           w16, [x1, #-1]
    //     0x8406ac: ldurb           w17, [x0, #-1]
    //     0x8406b0: and             x16, x17, x16, lsr #2
    //     0x8406b4: tst             x16, HEAP, lsr #32
    //     0x8406b8: b.eq            #0x8406c0
    //     0x8406bc: bl              #0xd67e5c
    // 0x8406c0: r0 = CupertinoDesktopTextSelectionToolbarButton()
    //     0x8406c0: bl              #0x840c28  ; AllocateCupertinoDesktopTextSelectionToolbarButtonStub -> CupertinoDesktopTextSelectionToolbarButton (size=0x18)
    // 0x8406c4: stur            x0, [fp, #-0x18]
    // 0x8406c8: ldr             x16, [fp, #0x10]
    // 0x8406cc: stp             x16, x0, [SP, #-0x10]!
    // 0x8406d0: ldur            x16, [fp, #-0x20]
    // 0x8406d4: r30 = "Copy"
    //     0x8406d4: add             lr, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Copy"
    //     0x8406d8: ldr             lr, [lr, #0xdd8]
    // 0x8406dc: stp             lr, x16, [SP, #-0x10]!
    // 0x8406e0: r0 = CupertinoDesktopTextSelectionToolbarButton.text()
    //     0x8406e0: bl              #0x840b38  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] CupertinoDesktopTextSelectionToolbarButton::CupertinoDesktopTextSelectionToolbarButton.text
    // 0x8406e4: add             SP, SP, #0x20
    // 0x8406e8: ldur            x0, [fp, #-0x10]
    // 0x8406ec: LoadField: r1 = r0->field_b
    //     0x8406ec: ldur            w1, [x0, #0xb]
    // 0x8406f0: DecompressPointer r1
    //     0x8406f0: add             x1, x1, HEAP, lsl #32
    // 0x8406f4: stur            x1, [fp, #-0x20]
    // 0x8406f8: LoadField: r2 = r0->field_f
    //     0x8406f8: ldur            w2, [x0, #0xf]
    // 0x8406fc: DecompressPointer r2
    //     0x8406fc: add             x2, x2, HEAP, lsl #32
    // 0x840700: LoadField: r3 = r2->field_b
    //     0x840700: ldur            w3, [x2, #0xb]
    // 0x840704: DecompressPointer r3
    //     0x840704: add             x3, x3, HEAP, lsl #32
    // 0x840708: cmp             w1, w3
    // 0x84070c: b.ne            #0x84071c
    // 0x840710: SaveReg r0
    //     0x840710: str             x0, [SP, #-8]!
    // 0x840714: r0 = _growToNextCapacity()
    //     0x840714: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x840718: add             SP, SP, #8
    // 0x84071c: ldur            x2, [fp, #-0x10]
    // 0x840720: ldur            x0, [fp, #-0x20]
    // 0x840724: r3 = LoadInt32Instr(r0)
    //     0x840724: sbfx            x3, x0, #1, #0x1f
    // 0x840728: add             x0, x3, #1
    // 0x84072c: lsl             x1, x0, #1
    // 0x840730: StoreField: r2->field_b = r1
    //     0x840730: stur            w1, [x2, #0xb]
    // 0x840734: mov             x1, x3
    // 0x840738: cmp             x1, x0
    // 0x84073c: b.hs            #0x840b0c
    // 0x840740: LoadField: r1 = r2->field_f
    //     0x840740: ldur            w1, [x2, #0xf]
    // 0x840744: DecompressPointer r1
    //     0x840744: add             x1, x1, HEAP, lsl #32
    // 0x840748: ldur            x0, [fp, #-0x18]
    // 0x84074c: ArrayStore: r1[r3] = r0  ; List_4
    //     0x84074c: add             x25, x1, x3, lsl #2
    //     0x840750: add             x25, x25, #0xf
    //     0x840754: str             w0, [x25]
    //     0x840758: tbz             w0, #0, #0x840774
    //     0x84075c: ldurb           w16, [x1, #-1]
    //     0x840760: ldurb           w17, [x0, #-1]
    //     0x840764: and             x16, x17, x16, lsr #2
    //     0x840768: tst             x16, HEAP, lsr #32
    //     0x84076c: b.eq            #0x840774
    //     0x840770: bl              #0xd67e5c
    // 0x840774: ldr             x0, [fp, #0x18]
    // 0x840778: LoadField: r1 = r0->field_b
    //     0x840778: ldur            w1, [x0, #0xb]
    // 0x84077c: DecompressPointer r1
    //     0x84077c: add             x1, x1, HEAP, lsl #32
    // 0x840780: cmp             w1, NULL
    // 0x840784: b.eq            #0x840b10
    // 0x840788: LoadField: r3 = r1->field_1b
    //     0x840788: ldur            w3, [x1, #0x1b]
    // 0x84078c: DecompressPointer r3
    //     0x84078c: add             x3, x3, HEAP, lsl #32
    // 0x840790: stur            x3, [fp, #-0x20]
    // 0x840794: cmp             w3, NULL
    // 0x840798: b.eq            #0x840904
    // 0x84079c: LoadField: r4 = r1->field_b
    //     0x84079c: ldur            w4, [x1, #0xb]
    // 0x8407a0: DecompressPointer r4
    //     0x8407a0: add             x4, x4, HEAP, lsl #32
    // 0x8407a4: cmp             w4, NULL
    // 0x8407a8: b.eq            #0x840904
    // 0x8407ac: LoadField: r1 = r4->field_27
    //     0x8407ac: ldur            w1, [x4, #0x27]
    // 0x8407b0: DecompressPointer r1
    //     0x8407b0: add             x1, x1, HEAP, lsl #32
    // 0x8407b4: r16 = Instance_ClipboardStatus
    //     0x8407b4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1fc68] Obj!ClipboardStatus@b63491
    //     0x8407b8: ldr             x16, [x16, #0xc68]
    // 0x8407bc: cmp             w1, w16
    // 0x8407c0: b.ne            #0x840904
    // 0x8407c4: LoadField: r1 = r2->field_b
    //     0x8407c4: ldur            w1, [x2, #0xb]
    // 0x8407c8: DecompressPointer r1
    //     0x8407c8: add             x1, x1, HEAP, lsl #32
    // 0x8407cc: stur            x1, [fp, #-0x18]
    // 0x8407d0: cbz             w1, #0x840850
    // 0x8407d4: LoadField: r4 = r2->field_f
    //     0x8407d4: ldur            w4, [x2, #0xf]
    // 0x8407d8: DecompressPointer r4
    //     0x8407d8: add             x4, x4, HEAP, lsl #32
    // 0x8407dc: LoadField: r5 = r4->field_b
    //     0x8407dc: ldur            w5, [x4, #0xb]
    // 0x8407e0: DecompressPointer r5
    //     0x8407e0: add             x5, x5, HEAP, lsl #32
    // 0x8407e4: cmp             w1, w5
    // 0x8407e8: b.ne            #0x8407f8
    // 0x8407ec: SaveReg r2
    //     0x8407ec: str             x2, [SP, #-8]!
    // 0x8407f0: r0 = _growToNextCapacity()
    //     0x8407f0: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8407f4: add             SP, SP, #8
    // 0x8407f8: ldur            x2, [fp, #-0x10]
    // 0x8407fc: ldur            x0, [fp, #-0x18]
    // 0x840800: r3 = LoadInt32Instr(r0)
    //     0x840800: sbfx            x3, x0, #1, #0x1f
    // 0x840804: add             x0, x3, #1
    // 0x840808: lsl             x1, x0, #1
    // 0x84080c: StoreField: r2->field_b = r1
    //     0x84080c: stur            w1, [x2, #0xb]
    // 0x840810: mov             x1, x3
    // 0x840814: cmp             x1, x0
    // 0x840818: b.hs            #0x840b14
    // 0x84081c: LoadField: r1 = r2->field_f
    //     0x84081c: ldur            w1, [x2, #0xf]
    // 0x840820: DecompressPointer r1
    //     0x840820: add             x1, x1, HEAP, lsl #32
    // 0x840824: ldur            x0, [fp, #-0x28]
    // 0x840828: ArrayStore: r1[r3] = r0  ; List_4
    //     0x840828: add             x25, x1, x3, lsl #2
    //     0x84082c: add             x25, x25, #0xf
    //     0x840830: str             w0, [x25]
    //     0x840834: tbz             w0, #0, #0x840850
    //     0x840838: ldurb           w16, [x1, #-1]
    //     0x84083c: ldurb           w17, [x0, #-1]
    //     0x840840: and             x16, x17, x16, lsr #2
    //     0x840844: tst             x16, HEAP, lsr #32
    //     0x840848: b.eq            #0x840850
    //     0x84084c: bl              #0xd67e5c
    // 0x840850: r0 = CupertinoDesktopTextSelectionToolbarButton()
    //     0x840850: bl              #0x840c28  ; AllocateCupertinoDesktopTextSelectionToolbarButtonStub -> CupertinoDesktopTextSelectionToolbarButton (size=0x18)
    // 0x840854: stur            x0, [fp, #-0x18]
    // 0x840858: ldr             x16, [fp, #0x10]
    // 0x84085c: stp             x16, x0, [SP, #-0x10]!
    // 0x840860: ldur            x16, [fp, #-0x20]
    // 0x840864: r30 = "Paste"
    //     0x840864: add             lr, PP, #0x28, lsl #12  ; [pp+0x28de0] "Paste"
    //     0x840868: ldr             lr, [lr, #0xde0]
    // 0x84086c: stp             lr, x16, [SP, #-0x10]!
    // 0x840870: r0 = CupertinoDesktopTextSelectionToolbarButton.text()
    //     0x840870: bl              #0x840b38  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] CupertinoDesktopTextSelectionToolbarButton::CupertinoDesktopTextSelectionToolbarButton.text
    // 0x840874: add             SP, SP, #0x20
    // 0x840878: ldur            x0, [fp, #-0x10]
    // 0x84087c: LoadField: r1 = r0->field_b
    //     0x84087c: ldur            w1, [x0, #0xb]
    // 0x840880: DecompressPointer r1
    //     0x840880: add             x1, x1, HEAP, lsl #32
    // 0x840884: stur            x1, [fp, #-0x20]
    // 0x840888: LoadField: r2 = r0->field_f
    //     0x840888: ldur            w2, [x0, #0xf]
    // 0x84088c: DecompressPointer r2
    //     0x84088c: add             x2, x2, HEAP, lsl #32
    // 0x840890: LoadField: r3 = r2->field_b
    //     0x840890: ldur            w3, [x2, #0xb]
    // 0x840894: DecompressPointer r3
    //     0x840894: add             x3, x3, HEAP, lsl #32
    // 0x840898: cmp             w1, w3
    // 0x84089c: b.ne            #0x8408ac
    // 0x8408a0: SaveReg r0
    //     0x8408a0: str             x0, [SP, #-8]!
    // 0x8408a4: r0 = _growToNextCapacity()
    //     0x8408a4: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x8408a8: add             SP, SP, #8
    // 0x8408ac: ldur            x2, [fp, #-0x10]
    // 0x8408b0: ldur            x0, [fp, #-0x20]
    // 0x8408b4: r3 = LoadInt32Instr(r0)
    //     0x8408b4: sbfx            x3, x0, #1, #0x1f
    // 0x8408b8: add             x0, x3, #1
    // 0x8408bc: lsl             x1, x0, #1
    // 0x8408c0: StoreField: r2->field_b = r1
    //     0x8408c0: stur            w1, [x2, #0xb]
    // 0x8408c4: mov             x1, x3
    // 0x8408c8: cmp             x1, x0
    // 0x8408cc: b.hs            #0x840b18
    // 0x8408d0: LoadField: r1 = r2->field_f
    //     0x8408d0: ldur            w1, [x2, #0xf]
    // 0x8408d4: DecompressPointer r1
    //     0x8408d4: add             x1, x1, HEAP, lsl #32
    // 0x8408d8: ldur            x0, [fp, #-0x18]
    // 0x8408dc: ArrayStore: r1[r3] = r0  ; List_4
    //     0x8408dc: add             x25, x1, x3, lsl #2
    //     0x8408e0: add             x25, x25, #0xf
    //     0x8408e4: str             w0, [x25]
    //     0x8408e8: tbz             w0, #0, #0x840904
    //     0x8408ec: ldurb           w16, [x1, #-1]
    //     0x8408f0: ldurb           w17, [x0, #-1]
    //     0x8408f4: and             x16, x17, x16, lsr #2
    //     0x8408f8: tst             x16, HEAP, lsr #32
    //     0x8408fc: b.eq            #0x840904
    //     0x840900: bl              #0xd67e5c
    // 0x840904: ldr             x0, [fp, #0x18]
    // 0x840908: LoadField: r1 = r0->field_b
    //     0x840908: ldur            w1, [x0, #0xb]
    // 0x84090c: DecompressPointer r1
    //     0x84090c: add             x1, x1, HEAP, lsl #32
    // 0x840910: cmp             w1, NULL
    // 0x840914: b.eq            #0x840b1c
    // 0x840918: LoadField: r3 = r1->field_1f
    //     0x840918: ldur            w3, [x1, #0x1f]
    // 0x84091c: DecompressPointer r3
    //     0x84091c: add             x3, x3, HEAP, lsl #32
    // 0x840920: stur            x3, [fp, #-0x20]
    // 0x840924: cmp             w3, NULL
    // 0x840928: b.eq            #0x840a6c
    // 0x84092c: LoadField: r1 = r2->field_b
    //     0x84092c: ldur            w1, [x2, #0xb]
    // 0x840930: DecompressPointer r1
    //     0x840930: add             x1, x1, HEAP, lsl #32
    // 0x840934: stur            x1, [fp, #-0x18]
    // 0x840938: cbz             w1, #0x8409b8
    // 0x84093c: LoadField: r4 = r2->field_f
    //     0x84093c: ldur            w4, [x2, #0xf]
    // 0x840940: DecompressPointer r4
    //     0x840940: add             x4, x4, HEAP, lsl #32
    // 0x840944: LoadField: r5 = r4->field_b
    //     0x840944: ldur            w5, [x4, #0xb]
    // 0x840948: DecompressPointer r5
    //     0x840948: add             x5, x5, HEAP, lsl #32
    // 0x84094c: cmp             w1, w5
    // 0x840950: b.ne            #0x840960
    // 0x840954: SaveReg r2
    //     0x840954: str             x2, [SP, #-8]!
    // 0x840958: r0 = _growToNextCapacity()
    //     0x840958: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x84095c: add             SP, SP, #8
    // 0x840960: ldur            x2, [fp, #-0x10]
    // 0x840964: ldur            x0, [fp, #-0x18]
    // 0x840968: r3 = LoadInt32Instr(r0)
    //     0x840968: sbfx            x3, x0, #1, #0x1f
    // 0x84096c: add             x0, x3, #1
    // 0x840970: lsl             x1, x0, #1
    // 0x840974: StoreField: r2->field_b = r1
    //     0x840974: stur            w1, [x2, #0xb]
    // 0x840978: mov             x1, x3
    // 0x84097c: cmp             x1, x0
    // 0x840980: b.hs            #0x840b20
    // 0x840984: LoadField: r1 = r2->field_f
    //     0x840984: ldur            w1, [x2, #0xf]
    // 0x840988: DecompressPointer r1
    //     0x840988: add             x1, x1, HEAP, lsl #32
    // 0x84098c: ldur            x0, [fp, #-0x28]
    // 0x840990: ArrayStore: r1[r3] = r0  ; List_4
    //     0x840990: add             x25, x1, x3, lsl #2
    //     0x840994: add             x25, x25, #0xf
    //     0x840998: str             w0, [x25]
    //     0x84099c: tbz             w0, #0, #0x8409b8
    //     0x8409a0: ldurb           w16, [x1, #-1]
    //     0x8409a4: ldurb           w17, [x0, #-1]
    //     0x8409a8: and             x16, x17, x16, lsr #2
    //     0x8409ac: tst             x16, HEAP, lsr #32
    //     0x8409b0: b.eq            #0x8409b8
    //     0x8409b4: bl              #0xd67e5c
    // 0x8409b8: r0 = CupertinoDesktopTextSelectionToolbarButton()
    //     0x8409b8: bl              #0x840c28  ; AllocateCupertinoDesktopTextSelectionToolbarButtonStub -> CupertinoDesktopTextSelectionToolbarButton (size=0x18)
    // 0x8409bc: stur            x0, [fp, #-0x18]
    // 0x8409c0: ldr             x16, [fp, #0x10]
    // 0x8409c4: stp             x16, x0, [SP, #-0x10]!
    // 0x8409c8: ldur            x16, [fp, #-0x20]
    // 0x8409cc: r30 = "Select All"
    //     0x8409cc: add             lr, PP, #0x28, lsl #12  ; [pp+0x28df0] "Select All"
    //     0x8409d0: ldr             lr, [lr, #0xdf0]
    // 0x8409d4: stp             lr, x16, [SP, #-0x10]!
    // 0x8409d8: r0 = CupertinoDesktopTextSelectionToolbarButton.text()
    //     0x8409d8: bl              #0x840b38  ; [package:flutter/src/cupertino/desktop_text_selection_toolbar_button.dart] CupertinoDesktopTextSelectionToolbarButton::CupertinoDesktopTextSelectionToolbarButton.text
    // 0x8409dc: add             SP, SP, #0x20
    // 0x8409e0: ldur            x0, [fp, #-0x10]
    // 0x8409e4: LoadField: r1 = r0->field_b
    //     0x8409e4: ldur            w1, [x0, #0xb]
    // 0x8409e8: DecompressPointer r1
    //     0x8409e8: add             x1, x1, HEAP, lsl #32
    // 0x8409ec: stur            x1, [fp, #-0x20]
    // 0x8409f0: LoadField: r2 = r0->field_f
    //     0x8409f0: ldur            w2, [x0, #0xf]
    // 0x8409f4: DecompressPointer r2
    //     0x8409f4: add             x2, x2, HEAP, lsl #32
    // 0x8409f8: LoadField: r3 = r2->field_b
    //     0x8409f8: ldur            w3, [x2, #0xb]
    // 0x8409fc: DecompressPointer r3
    //     0x8409fc: add             x3, x3, HEAP, lsl #32
    // 0x840a00: cmp             w1, w3
    // 0x840a04: b.ne            #0x840a14
    // 0x840a08: SaveReg r0
    //     0x840a08: str             x0, [SP, #-8]!
    // 0x840a0c: r0 = _growToNextCapacity()
    //     0x840a0c: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x840a10: add             SP, SP, #8
    // 0x840a14: ldur            x2, [fp, #-0x10]
    // 0x840a18: ldur            x0, [fp, #-0x20]
    // 0x840a1c: r3 = LoadInt32Instr(r0)
    //     0x840a1c: sbfx            x3, x0, #1, #0x1f
    // 0x840a20: add             x0, x3, #1
    // 0x840a24: lsl             x1, x0, #1
    // 0x840a28: StoreField: r2->field_b = r1
    //     0x840a28: stur            w1, [x2, #0xb]
    // 0x840a2c: mov             x1, x3
    // 0x840a30: cmp             x1, x0
    // 0x840a34: b.hs            #0x840b24
    // 0x840a38: LoadField: r1 = r2->field_f
    //     0x840a38: ldur            w1, [x2, #0xf]
    // 0x840a3c: DecompressPointer r1
    //     0x840a3c: add             x1, x1, HEAP, lsl #32
    // 0x840a40: ldur            x0, [fp, #-0x18]
    // 0x840a44: ArrayStore: r1[r3] = r0  ; List_4
    //     0x840a44: add             x25, x1, x3, lsl #2
    //     0x840a48: add             x25, x25, #0xf
    //     0x840a4c: str             w0, [x25]
    //     0x840a50: tbz             w0, #0, #0x840a6c
    //     0x840a54: ldurb           w16, [x1, #-1]
    //     0x840a58: ldurb           w17, [x0, #-1]
    //     0x840a5c: and             x16, x17, x16, lsr #2
    //     0x840a60: tst             x16, HEAP, lsr #32
    //     0x840a64: b.eq            #0x840a6c
    //     0x840a68: bl              #0xd67e5c
    // 0x840a6c: LoadField: r0 = r2->field_b
    //     0x840a6c: ldur            w0, [x2, #0xb]
    // 0x840a70: DecompressPointer r0
    //     0x840a70: add             x0, x0, HEAP, lsl #32
    // 0x840a74: cbnz            w0, #0x840a8c
    // 0x840a78: r0 = Instance_SizedBox
    //     0x840a78: add             x0, PP, #0xe, lsl #12  ; [pp+0xe738] Obj!SizedBox@b49b71
    //     0x840a7c: ldr             x0, [x0, #0x738]
    // 0x840a80: LeaveFrame
    //     0x840a80: mov             SP, fp
    //     0x840a84: ldp             fp, lr, [SP], #0x10
    // 0x840a88: ret
    //     0x840a88: ret             
    // 0x840a8c: ldr             x0, [fp, #0x18]
    // 0x840a90: LoadField: r1 = r0->field_b
    //     0x840a90: ldur            w1, [x0, #0xb]
    // 0x840a94: DecompressPointer r1
    //     0x840a94: add             x1, x1, HEAP, lsl #32
    // 0x840a98: cmp             w1, NULL
    // 0x840a9c: b.eq            #0x840b28
    // 0x840aa0: LoadField: r0 = r1->field_23
    //     0x840aa0: ldur            w0, [x1, #0x23]
    // 0x840aa4: DecompressPointer r0
    //     0x840aa4: add             x0, x0, HEAP, lsl #32
    // 0x840aa8: cmp             w0, NULL
    // 0x840aac: b.ne            #0x840ab4
    // 0x840ab0: ldur            x0, [fp, #-8]
    // 0x840ab4: stur            x0, [fp, #-8]
    // 0x840ab8: r0 = CupertinoDesktopTextSelectionToolbar()
    //     0x840ab8: bl              #0x840b2c  ; AllocateCupertinoDesktopTextSelectionToolbarStub -> CupertinoDesktopTextSelectionToolbar (size=0x14)
    // 0x840abc: ldur            x1, [fp, #-8]
    // 0x840ac0: StoreField: r0->field_b = r1
    //     0x840ac0: stur            w1, [x0, #0xb]
    // 0x840ac4: ldur            x1, [fp, #-0x10]
    // 0x840ac8: StoreField: r0->field_f = r1
    //     0x840ac8: stur            w1, [x0, #0xf]
    // 0x840acc: LeaveFrame
    //     0x840acc: mov             SP, fp
    //     0x840ad0: ldp             fp, lr, [SP], #0x10
    // 0x840ad4: ret
    //     0x840ad4: ret             
    // 0x840ad8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x840ad8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x840adc: b               #0x8402f0
    // 0x840ae0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840ae0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840ae4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840ae4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840ae8: SaveReg d2
    //     0x840ae8: str             q2, [SP, #-0x10]!
    // 0x840aec: r0 = AllocateDouble()
    //     0x840aec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x840af0: RestoreReg d2
    //     0x840af0: ldr             q2, [SP], #0x10
    // 0x840af4: b               #0x84047c
    // 0x840af8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840af8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840afc: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840afc: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b00: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b00: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840b04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840b08: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b08: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b0c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b0c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840b10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840b14: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b14: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b18: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b18: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840b1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x840b20: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b20: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b24: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x840b24: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x840b28: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x840b28: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d7664, size: 0x90
    // 0x9d7664: EnterFrame
    //     0x9d7664: stp             fp, lr, [SP, #-0x10]!
    //     0x9d7668: mov             fp, SP
    // 0x9d766c: AllocStack(0x8)
    //     0x9d766c: sub             SP, SP, #8
    // 0x9d7670: CheckStackOverflow
    //     0x9d7670: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d7674: cmp             SP, x16
    //     0x9d7678: b.ls            #0x9d76e8
    // 0x9d767c: ldr             x0, [fp, #0x10]
    // 0x9d7680: LoadField: r1 = r0->field_b
    //     0x9d7680: ldur            w1, [x0, #0xb]
    // 0x9d7684: DecompressPointer r1
    //     0x9d7684: add             x1, x1, HEAP, lsl #32
    // 0x9d7688: cmp             w1, NULL
    // 0x9d768c: b.eq            #0x9d76f0
    // 0x9d7690: LoadField: r2 = r1->field_b
    //     0x9d7690: ldur            w2, [x1, #0xb]
    // 0x9d7694: DecompressPointer r2
    //     0x9d7694: add             x2, x2, HEAP, lsl #32
    // 0x9d7698: stur            x2, [fp, #-8]
    // 0x9d769c: cmp             w2, NULL
    // 0x9d76a0: b.eq            #0x9d76d8
    // 0x9d76a4: r1 = 1
    //     0x9d76a4: mov             x1, #1
    // 0x9d76a8: r0 = AllocateContext()
    //     0x9d76a8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d76ac: mov             x1, x0
    // 0x9d76b0: ldr             x0, [fp, #0x10]
    // 0x9d76b4: StoreField: r1->field_f = r0
    //     0x9d76b4: stur            w0, [x1, #0xf]
    // 0x9d76b8: mov             x2, x1
    // 0x9d76bc: r1 = Function '_onChangedClipboardStatus@592392285':.
    //     0x9d76bc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb28] AnonymousClosure: (0x7af03c), in [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7af084)
    //     0x9d76c0: ldr             x1, [x1, #0xb28]
    // 0x9d76c4: r0 = AllocateClosure()
    //     0x9d76c4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d76c8: ldur            x16, [fp, #-8]
    // 0x9d76cc: stp             x0, x16, [SP, #-0x10]!
    // 0x9d76d0: r0 = addListener()
    //     0x9d76d0: bl              #0x6e7588  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::addListener
    // 0x9d76d4: add             SP, SP, #0x10
    // 0x9d76d8: r0 = Null
    //     0x9d76d8: mov             x0, NULL
    // 0x9d76dc: LeaveFrame
    //     0x9d76dc: mov             SP, fp
    //     0x9d76e0: ldp             fp, lr, [SP], #0x10
    // 0x9d76e4: ret
    //     0x9d76e4: ret             
    // 0x9d76e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d76e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d76ec: b               #0x9d767c
    // 0x9d76f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d76f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a648, size: 0x18
    // 0xa4a648: r4 = 7
    //     0xa4a648: mov             x4, #7
    // 0xa4a64c: r1 = Function 'dispose':.
    //     0xa4a64c: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bb20] AnonymousClosure: (0xa4a660), in [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::dispose (0xa50474)
    //     0xa4a650: ldr             x1, [x17, #0xb20]
    // 0xa4a654: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a654: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a658: LoadField: r0 = r24->field_17
    //     0xa4a658: ldur            x0, [x24, #0x17]
    // 0xa4a65c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a660, size: 0x48
    // 0xa4a660: EnterFrame
    //     0xa4a660: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a664: mov             fp, SP
    // 0xa4a668: ldr             x0, [fp, #0x10]
    // 0xa4a66c: LoadField: r1 = r0->field_17
    //     0xa4a66c: ldur            w1, [x0, #0x17]
    // 0xa4a670: DecompressPointer r1
    //     0xa4a670: add             x1, x1, HEAP, lsl #32
    // 0xa4a674: CheckStackOverflow
    //     0xa4a674: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a678: cmp             SP, x16
    //     0xa4a67c: b.ls            #0xa4a6a0
    // 0xa4a680: LoadField: r0 = r1->field_f
    //     0xa4a680: ldur            w0, [x1, #0xf]
    // 0xa4a684: DecompressPointer r0
    //     0xa4a684: add             x0, x0, HEAP, lsl #32
    // 0xa4a688: SaveReg r0
    //     0xa4a688: str             x0, [SP, #-8]!
    // 0xa4a68c: r0 = dispose()
    //     0xa4a68c: bl              #0xa50474  ; [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::dispose
    // 0xa4a690: add             SP, SP, #8
    // 0xa4a694: LeaveFrame
    //     0xa4a694: mov             SP, fp
    //     0xa4a698: ldp             fp, lr, [SP], #0x10
    // 0xa4a69c: ret
    //     0xa4a69c: ret             
    // 0xa4a6a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a6a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a6a4: b               #0xa4a680
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50474, size: 0x90
    // 0xa50474: EnterFrame
    //     0xa50474: stp             fp, lr, [SP, #-0x10]!
    //     0xa50478: mov             fp, SP
    // 0xa5047c: AllocStack(0x8)
    //     0xa5047c: sub             SP, SP, #8
    // 0xa50480: CheckStackOverflow
    //     0xa50480: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50484: cmp             SP, x16
    //     0xa50488: b.ls            #0xa504f8
    // 0xa5048c: ldr             x0, [fp, #0x10]
    // 0xa50490: LoadField: r1 = r0->field_b
    //     0xa50490: ldur            w1, [x0, #0xb]
    // 0xa50494: DecompressPointer r1
    //     0xa50494: add             x1, x1, HEAP, lsl #32
    // 0xa50498: cmp             w1, NULL
    // 0xa5049c: b.eq            #0xa50500
    // 0xa504a0: LoadField: r2 = r1->field_b
    //     0xa504a0: ldur            w2, [x1, #0xb]
    // 0xa504a4: DecompressPointer r2
    //     0xa504a4: add             x2, x2, HEAP, lsl #32
    // 0xa504a8: stur            x2, [fp, #-8]
    // 0xa504ac: cmp             w2, NULL
    // 0xa504b0: b.eq            #0xa504e8
    // 0xa504b4: r1 = 1
    //     0xa504b4: mov             x1, #1
    // 0xa504b8: r0 = AllocateContext()
    //     0xa504b8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa504bc: mov             x1, x0
    // 0xa504c0: ldr             x0, [fp, #0x10]
    // 0xa504c4: StoreField: r1->field_f = r0
    //     0xa504c4: stur            w0, [x1, #0xf]
    // 0xa504c8: mov             x2, x1
    // 0xa504cc: r1 = Function '_onChangedClipboardStatus@592392285':.
    //     0xa504cc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bb28] AnonymousClosure: (0x7af03c), in [package:flutter/src/cupertino/desktop_text_selection.dart] _CupertinoDesktopTextSelectionControlsToolbarState::_onChangedClipboardStatus (0x7af084)
    //     0xa504d0: ldr             x1, [x1, #0xb28]
    // 0xa504d4: r0 = AllocateClosure()
    //     0xa504d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa504d8: ldur            x16, [fp, #-8]
    // 0xa504dc: stp             x0, x16, [SP, #-0x10]!
    // 0xa504e0: r0 = removeListener()
    //     0xa504e0: bl              #0x6e7eac  ; [package:flutter/src/widgets/text_selection.dart] ClipboardStatusNotifier::removeListener
    // 0xa504e4: add             SP, SP, #0x10
    // 0xa504e8: r0 = Null
    //     0xa504e8: mov             x0, NULL
    // 0xa504ec: LeaveFrame
    //     0xa504ec: mov             SP, fp
    //     0xa504f0: ldp             fp, lr, [SP], #0x10
    // 0xa504f4: ret
    //     0xa504f4: ret             
    // 0xa504f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa504f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa504fc: b               #0xa5048c
    // 0xa50500: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa50500: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4182, size: 0x2c, field offset: 0xc
//   const constructor, 
class _CupertinoDesktopTextSelectionControlsToolbar extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fd48, size: 0x20
    // 0xa3fd48: EnterFrame
    //     0xa3fd48: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fd4c: mov             fp, SP
    // 0xa3fd50: r1 = <_CupertinoDesktopTextSelectionControlsToolbar>
    //     0xa3fd50: add             x1, PP, #0x40, lsl #12  ; [pp+0x404d0] TypeArguments: <_CupertinoDesktopTextSelectionControlsToolbar>
    //     0xa3fd54: ldr             x1, [x1, #0x4d0]
    // 0xa3fd58: r0 = _CupertinoDesktopTextSelectionControlsToolbarState()
    //     0xa3fd58: bl              #0xa3fd68  ; Allocate_CupertinoDesktopTextSelectionControlsToolbarStateStub -> _CupertinoDesktopTextSelectionControlsToolbarState (size=0x14)
    // 0xa3fd5c: LeaveFrame
    //     0xa3fd5c: mov             SP, fp
    //     0xa3fd60: ldp             fp, lr, [SP], #0x10
    // 0xa3fd64: ret
    //     0xa3fd64: ret             
  }
}

// class id: 4248, size: 0x8, field offset: 0x8
class CupertinoDesktopTextSelectionControls extends TextSelectionControls {

  _ buildToolbar(/* No info */) {
    // ** addr: 0xc38d7c, size: 0x18c
    // 0xc38d7c: EnterFrame
    //     0xc38d7c: stp             fp, lr, [SP, #-0x10]!
    //     0xc38d80: mov             fp, SP
    // 0xc38d84: AllocStack(0x20)
    //     0xc38d84: sub             SP, SP, #0x20
    // 0xc38d88: CheckStackOverflow
    //     0xc38d88: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc38d8c: cmp             SP, x16
    //     0xc38d90: b.ls            #0xc38f00
    // 0xc38d94: r1 = 2
    //     0xc38d94: mov             x1, #2
    // 0xc38d98: r0 = AllocateContext()
    //     0xc38d98: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc38d9c: mov             x1, x0
    // 0xc38da0: ldr             x0, [fp, #0x48]
    // 0xc38da4: stur            x1, [fp, #-8]
    // 0xc38da8: StoreField: r1->field_f = r0
    //     0xc38da8: stur            w0, [x1, #0xf]
    // 0xc38dac: ldr             x2, [fp, #0x20]
    // 0xc38db0: StoreField: r1->field_13 = r2
    //     0xc38db0: stur            w2, [x1, #0x13]
    // 0xc38db4: stp             x2, x0, [SP, #-0x10]!
    // 0xc38db8: r0 = canCut()
    //     0xc38db8: bl              #0xc0a7ac  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCut
    // 0xc38dbc: add             SP, SP, #0x10
    // 0xc38dc0: tbnz            w0, #4, #0xc38dd8
    // 0xc38dc4: ldur            x2, [fp, #-8]
    // 0xc38dc8: r1 = Function '<anonymous closure>':.
    //     0xc38dc8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37cf8] AnonymousClosure: (0xc39268), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc38dcc: ldr             x1, [x1, #0xcf8]
    // 0xc38dd0: r0 = AllocateClosure()
    //     0xc38dd0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc38dd4: b               #0xc38ddc
    // 0xc38dd8: r0 = Null
    //     0xc38dd8: mov             x0, NULL
    // 0xc38ddc: ldur            x2, [fp, #-8]
    // 0xc38de0: stur            x0, [fp, #-0x10]
    // 0xc38de4: LoadField: r1 = r2->field_13
    //     0xc38de4: ldur            w1, [x2, #0x13]
    // 0xc38de8: DecompressPointer r1
    //     0xc38de8: add             x1, x1, HEAP, lsl #32
    // 0xc38dec: ldr             x16, [fp, #0x48]
    // 0xc38df0: stp             x1, x16, [SP, #-0x10]!
    // 0xc38df4: r0 = canCopy()
    //     0xc38df4: bl              #0xc035f0  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canCopy
    // 0xc38df8: add             SP, SP, #0x10
    // 0xc38dfc: tbnz            w0, #4, #0xc38e14
    // 0xc38e00: ldur            x2, [fp, #-8]
    // 0xc38e04: r1 = Function '<anonymous closure>':.
    //     0xc38e04: add             x1, PP, #0x37, lsl #12  ; [pp+0x37d00] AnonymousClosure: (0xc39214), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc38e08: ldr             x1, [x1, #0xd00]
    // 0xc38e0c: r0 = AllocateClosure()
    //     0xc38e0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc38e10: b               #0xc38e18
    // 0xc38e14: r0 = Null
    //     0xc38e14: mov             x0, NULL
    // 0xc38e18: ldur            x2, [fp, #-8]
    // 0xc38e1c: stur            x0, [fp, #-0x18]
    // 0xc38e20: LoadField: r1 = r2->field_13
    //     0xc38e20: ldur            w1, [x2, #0x13]
    // 0xc38e24: DecompressPointer r1
    //     0xc38e24: add             x1, x1, HEAP, lsl #32
    // 0xc38e28: SaveReg r1
    //     0xc38e28: str             x1, [SP, #-8]!
    // 0xc38e2c: r0 = pasteEnabled()
    //     0xc38e2c: bl              #0x7a2b88  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::pasteEnabled
    // 0xc38e30: add             SP, SP, #8
    // 0xc38e34: tbnz            w0, #4, #0xc38e4c
    // 0xc38e38: ldur            x2, [fp, #-8]
    // 0xc38e3c: r1 = Function '<anonymous closure>':.
    //     0xc38e3c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37d08] AnonymousClosure: (0xc391c4), in [package:flutter/src/material/text_selection.dart] MaterialTextSelectionControls::buildToolbar (0xc39748)
    //     0xc38e40: ldr             x1, [x1, #0xd08]
    // 0xc38e44: r0 = AllocateClosure()
    //     0xc38e44: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc38e48: b               #0xc38e50
    // 0xc38e4c: r0 = Null
    //     0xc38e4c: mov             x0, NULL
    // 0xc38e50: ldur            x2, [fp, #-8]
    // 0xc38e54: stur            x0, [fp, #-0x20]
    // 0xc38e58: LoadField: r1 = r2->field_13
    //     0xc38e58: ldur            w1, [x2, #0x13]
    // 0xc38e5c: DecompressPointer r1
    //     0xc38e5c: add             x1, x1, HEAP, lsl #32
    // 0xc38e60: ldr             x16, [fp, #0x48]
    // 0xc38e64: stp             x1, x16, [SP, #-0x10]!
    // 0xc38e68: r0 = canSelectAll()
    //     0xc38e68: bl              #0xc38f14  ; [package:flutter/src/widgets/text_selection.dart] TextSelectionControls::canSelectAll
    // 0xc38e6c: add             SP, SP, #0x10
    // 0xc38e70: tbnz            w0, #4, #0xc38e8c
    // 0xc38e74: ldur            x2, [fp, #-8]
    // 0xc38e78: r1 = Function '<anonymous closure>':.
    //     0xc38e78: add             x1, PP, #0x37, lsl #12  ; [pp+0x37d10] AnonymousClosure: (0xc38fe0), in [package:flutter/src/cupertino/desktop_text_selection.dart] CupertinoDesktopTextSelectionControls::buildToolbar (0xc38d7c)
    //     0xc38e7c: ldr             x1, [x1, #0xd10]
    // 0xc38e80: r0 = AllocateClosure()
    //     0xc38e80: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc38e84: mov             x7, x0
    // 0xc38e88: b               #0xc38e90
    // 0xc38e8c: r7 = Null
    //     0xc38e8c: mov             x7, NULL
    // 0xc38e90: ldr             x6, [fp, #0x40]
    // 0xc38e94: ldr             x5, [fp, #0x30]
    // 0xc38e98: ldr             x4, [fp, #0x18]
    // 0xc38e9c: ldr             x3, [fp, #0x10]
    // 0xc38ea0: ldur            x2, [fp, #-0x10]
    // 0xc38ea4: ldur            x1, [fp, #-0x18]
    // 0xc38ea8: ldur            x0, [fp, #-0x20]
    // 0xc38eac: stur            x7, [fp, #-8]
    // 0xc38eb0: r0 = _CupertinoDesktopTextSelectionControlsToolbar()
    //     0xc38eb0: bl              #0xc38f08  ; Allocate_CupertinoDesktopTextSelectionControlsToolbarStub -> _CupertinoDesktopTextSelectionControlsToolbar (size=0x2c)
    // 0xc38eb4: ldr             x1, [fp, #0x18]
    // 0xc38eb8: StoreField: r0->field_b = r1
    //     0xc38eb8: stur            w1, [x0, #0xb]
    // 0xc38ebc: ldr             x1, [fp, #0x40]
    // 0xc38ec0: StoreField: r0->field_f = r1
    //     0xc38ec0: stur            w1, [x0, #0xf]
    // 0xc38ec4: ldur            x1, [fp, #-0x18]
    // 0xc38ec8: StoreField: r0->field_13 = r1
    //     0xc38ec8: stur            w1, [x0, #0x13]
    // 0xc38ecc: ldur            x1, [fp, #-0x10]
    // 0xc38ed0: StoreField: r0->field_17 = r1
    //     0xc38ed0: stur            w1, [x0, #0x17]
    // 0xc38ed4: ldur            x1, [fp, #-0x20]
    // 0xc38ed8: StoreField: r0->field_1b = r1
    //     0xc38ed8: stur            w1, [x0, #0x1b]
    // 0xc38edc: ldur            x1, [fp, #-8]
    // 0xc38ee0: StoreField: r0->field_1f = r1
    //     0xc38ee0: stur            w1, [x0, #0x1f]
    // 0xc38ee4: ldr             x1, [fp, #0x30]
    // 0xc38ee8: StoreField: r0->field_27 = r1
    //     0xc38ee8: stur            w1, [x0, #0x27]
    // 0xc38eec: ldr             x1, [fp, #0x10]
    // 0xc38ef0: StoreField: r0->field_23 = r1
    //     0xc38ef0: stur            w1, [x0, #0x23]
    // 0xc38ef4: LeaveFrame
    //     0xc38ef4: mov             SP, fp
    //     0xc38ef8: ldp             fp, lr, [SP], #0x10
    // 0xc38efc: ret
    //     0xc38efc: ret             
    // 0xc38f00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc38f00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc38f04: b               #0xc38d94
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0xc38fe0, size: 0x50
    // 0xc38fe0: EnterFrame
    //     0xc38fe0: stp             fp, lr, [SP, #-0x10]!
    //     0xc38fe4: mov             fp, SP
    // 0xc38fe8: ldr             x0, [fp, #0x10]
    // 0xc38fec: LoadField: r1 = r0->field_17
    //     0xc38fec: ldur            w1, [x0, #0x17]
    // 0xc38ff0: DecompressPointer r1
    //     0xc38ff0: add             x1, x1, HEAP, lsl #32
    // 0xc38ff4: CheckStackOverflow
    //     0xc38ff4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc38ff8: cmp             SP, x16
    //     0xc38ffc: b.ls            #0xc39028
    // 0xc39000: LoadField: r0 = r1->field_f
    //     0xc39000: ldur            w0, [x1, #0xf]
    // 0xc39004: DecompressPointer r0
    //     0xc39004: add             x0, x0, HEAP, lsl #32
    // 0xc39008: LoadField: r2 = r1->field_13
    //     0xc39008: ldur            w2, [x1, #0x13]
    // 0xc3900c: DecompressPointer r2
    //     0xc3900c: add             x2, x2, HEAP, lsl #32
    // 0xc39010: stp             x2, x0, [SP, #-0x10]!
    // 0xc39014: r0 = handleSelectAll()
    //     0xc39014: bl              #0xc39030  ; [package:flutter/src/cupertino/desktop_text_selection.dart] CupertinoDesktopTextSelectionControls::handleSelectAll
    // 0xc39018: add             SP, SP, #0x10
    // 0xc3901c: LeaveFrame
    //     0xc3901c: mov             SP, fp
    //     0xc39020: ldp             fp, lr, [SP], #0x10
    // 0xc39024: ret
    //     0xc39024: ret             
    // 0xc39028: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc39028: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc3902c: b               #0xc39000
  }
  _ handleSelectAll(/* No info */) {
    // ** addr: 0xc39030, size: 0x58
    // 0xc39030: EnterFrame
    //     0xc39030: stp             fp, lr, [SP, #-0x10]!
    //     0xc39034: mov             fp, SP
    // 0xc39038: CheckStackOverflow
    //     0xc39038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc3903c: cmp             SP, x16
    //     0xc39040: b.ls            #0xc39080
    // 0xc39044: ldr             x16, [fp, #0x10]
    // 0xc39048: r30 = Instance_SelectionChangedCause
    //     0xc39048: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f638] Obj!SelectionChangedCause@b63f51
    //     0xc3904c: ldr             lr, [lr, #0x638]
    // 0xc39050: stp             lr, x16, [SP, #-0x10]!
    // 0xc39054: r0 = selectAll()
    //     0xc39054: bl              #0xc39088  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::selectAll
    // 0xc39058: add             SP, SP, #0x10
    // 0xc3905c: ldr             x16, [fp, #0x10]
    // 0xc39060: SaveReg r16
    //     0xc39060: str             x16, [SP, #-8]!
    // 0xc39064: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc39064: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc39068: r0 = hideToolbar()
    //     0xc39068: bl              #0x836434  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::hideToolbar
    // 0xc3906c: add             SP, SP, #8
    // 0xc39070: r0 = Null
    //     0xc39070: mov             x0, NULL
    // 0xc39074: LeaveFrame
    //     0xc39074: mov             SP, fp
    //     0xc39078: ldp             fp, lr, [SP], #0x10
    // 0xc3907c: ret
    //     0xc3907c: ret             
    // 0xc39080: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc39080: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc39084: b               #0xc39044
  }
}

// class id: 4249, size: 0x8, field offset: 0x8
//   transformed mixin,
abstract class __CupertinoDesktopTextSelectionHandleControls&CupertinoDesktopTextSelectionControls&TextSelectionHandleControls extends CupertinoDesktopTextSelectionControls
     with TextSelectionHandleControls {
}

// class id: 4250, size: 0x8, field offset: 0x8
class _CupertinoDesktopTextSelectionHandleControls extends __CupertinoDesktopTextSelectionHandleControls&CupertinoDesktopTextSelectionControls&TextSelectionHandleControls {
}

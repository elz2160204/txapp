// lib: , url: package:flutter/src/cupertino/theme.dart

// class id: 1049116, size: 0x8
class :: {
}

// class id: 2657, size: 0x10, field offset: 0x8
//   const constructor, 
class _CupertinoTextThemeDefaults extends Object {

  CupertinoDynamicColor field_8;
  CupertinoDynamicColor field_c;

  _ createDefaults(/* No info */) {
    // ** addr: 0x83fea8, size: 0x40
    // 0x83fea8: EnterFrame
    //     0x83fea8: stp             fp, lr, [SP, #-0x10]!
    //     0x83feac: mov             fp, SP
    // 0x83feb0: AllocStack(0x8)
    //     0x83feb0: sub             SP, SP, #8
    // 0x83feb4: ldr             x0, [fp, #0x10]
    // 0x83feb8: LoadField: r1 = r0->field_7
    //     0x83feb8: ldur            w1, [x0, #7]
    // 0x83febc: DecompressPointer r1
    //     0x83febc: add             x1, x1, HEAP, lsl #32
    // 0x83fec0: stur            x1, [fp, #-8]
    // 0x83fec4: r0 = _DefaultCupertinoTextThemeData()
    //     0x83fec4: bl              #0x83fee8  ; Allocate_DefaultCupertinoTextThemeDataStub -> _DefaultCupertinoTextThemeData (size=0x14)
    // 0x83fec8: ldur            x1, [fp, #-8]
    // 0x83fecc: StoreField: r0->field_f = r1
    //     0x83fecc: stur            w1, [x0, #0xf]
    // 0x83fed0: r1 = Instance__TextThemeDefaultsBuilder
    //     0x83fed0: add             x1, PP, #0x40, lsl #12  ; [pp+0x40550] Obj!_TextThemeDefaultsBuilder@b38861
    //     0x83fed4: ldr             x1, [x1, #0x550]
    // 0x83fed8: StoreField: r0->field_7 = r1
    //     0x83fed8: stur            w1, [x0, #7]
    // 0x83fedc: LeaveFrame
    //     0x83fedc: mov             SP, fp
    //     0x83fee0: ldp             fp, lr, [SP], #0x10
    // 0x83fee4: ret
    //     0x83fee4: ret             
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0xcccbe8, size: 0x84
    // 0xcccbe8: EnterFrame
    //     0xcccbe8: stp             fp, lr, [SP, #-0x10]!
    //     0xcccbec: mov             fp, SP
    // 0xcccbf0: AllocStack(0x10)
    //     0xcccbf0: sub             SP, SP, #0x10
    // 0xcccbf4: CheckStackOverflow
    //     0xcccbf4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcccbf8: cmp             SP, x16
    //     0xcccbfc: b.ls            #0xcccc64
    // 0xcccc00: ldr             x0, [fp, #0x18]
    // 0xcccc04: LoadField: r1 = r0->field_7
    //     0xcccc04: ldur            w1, [x0, #7]
    // 0xcccc08: DecompressPointer r1
    //     0xcccc08: add             x1, x1, HEAP, lsl #32
    // 0xcccc0c: ldr             x16, [fp, #0x10]
    // 0xcccc10: stp             x16, x1, [SP, #-0x10]!
    // 0xcccc14: r0 = resolveFrom()
    //     0xcccc14: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xcccc18: add             SP, SP, #0x10
    // 0xcccc1c: mov             x1, x0
    // 0xcccc20: ldr             x0, [fp, #0x18]
    // 0xcccc24: stur            x1, [fp, #-8]
    // 0xcccc28: LoadField: r2 = r0->field_b
    //     0xcccc28: ldur            w2, [x0, #0xb]
    // 0xcccc2c: DecompressPointer r2
    //     0xcccc2c: add             x2, x2, HEAP, lsl #32
    // 0xcccc30: ldr             x16, [fp, #0x10]
    // 0xcccc34: stp             x16, x2, [SP, #-0x10]!
    // 0xcccc38: r0 = resolveFrom()
    //     0xcccc38: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0xcccc3c: add             SP, SP, #0x10
    // 0xcccc40: stur            x0, [fp, #-0x10]
    // 0xcccc44: r0 = _CupertinoTextThemeDefaults()
    //     0xcccc44: bl              #0xcccc6c  ; Allocate_CupertinoTextThemeDefaultsStub -> _CupertinoTextThemeDefaults (size=0x10)
    // 0xcccc48: ldur            x1, [fp, #-8]
    // 0xcccc4c: StoreField: r0->field_7 = r1
    //     0xcccc4c: stur            w1, [x0, #7]
    // 0xcccc50: ldur            x1, [fp, #-0x10]
    // 0xcccc54: StoreField: r0->field_b = r1
    //     0xcccc54: stur            w1, [x0, #0xb]
    // 0xcccc58: LeaveFrame
    //     0xcccc58: mov             SP, fp
    //     0xcccc5c: ldp             fp, lr, [SP], #0x10
    // 0xcccc60: ret
    //     0xcccc60: ret             
    // 0xcccc64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcccc64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcccc68: b               #0xcccc00
  }
}

// class id: 2658, size: 0x20, field offset: 0x8
//   const constructor, 
class _CupertinoThemeDefaults extends Object {

  CupertinoDynamicColor field_c;
  CupertinoDynamicColor field_10;
  CupertinoDynamicColor field_14;
  CupertinoDynamicColor field_18;
  _CupertinoTextThemeDefaults field_1c;

  _ resolveFrom(/* No info */) {
    // ** addr: 0xcccaa4, size: 0x138
    // 0xcccaa4: EnterFrame
    //     0xcccaa4: stp             fp, lr, [SP, #-0x10]!
    //     0xcccaa8: mov             fp, SP
    // 0xcccaac: AllocStack(0x28)
    //     0xcccaac: sub             SP, SP, #0x28
    // 0xcccab0: CheckStackOverflow
    //     0xcccab0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcccab4: cmp             SP, x16
    //     0xcccab8: b.ls            #0xcccbd4
    // 0xcccabc: ldr             x0, [fp, #0x20]
    // 0xcccac0: LoadField: r1 = r0->field_b
    //     0xcccac0: ldur            w1, [x0, #0xb]
    // 0xcccac4: DecompressPointer r1
    //     0xcccac4: add             x1, x1, HEAP, lsl #32
    // 0xcccac8: ldr             x16, [fp, #0x18]
    // 0xcccacc: stp             x16, x1, [SP, #-0x10]!
    // 0xcccad0: r0 = resolve()
    //     0xcccad0: bl              #0x6ca720  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xcccad4: add             SP, SP, #0x10
    // 0xcccad8: mov             x1, x0
    // 0xcccadc: ldr             x0, [fp, #0x20]
    // 0xcccae0: stur            x1, [fp, #-8]
    // 0xcccae4: LoadField: r2 = r0->field_f
    //     0xcccae4: ldur            w2, [x0, #0xf]
    // 0xcccae8: DecompressPointer r2
    //     0xcccae8: add             x2, x2, HEAP, lsl #32
    // 0xcccaec: ldr             x16, [fp, #0x18]
    // 0xcccaf0: stp             x16, x2, [SP, #-0x10]!
    // 0xcccaf4: r0 = resolve()
    //     0xcccaf4: bl              #0x6ca720  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xcccaf8: add             SP, SP, #0x10
    // 0xcccafc: mov             x1, x0
    // 0xcccb00: ldr             x0, [fp, #0x20]
    // 0xcccb04: stur            x1, [fp, #-0x10]
    // 0xcccb08: LoadField: r2 = r0->field_13
    //     0xcccb08: ldur            w2, [x0, #0x13]
    // 0xcccb0c: DecompressPointer r2
    //     0xcccb0c: add             x2, x2, HEAP, lsl #32
    // 0xcccb10: ldr             x16, [fp, #0x18]
    // 0xcccb14: stp             x16, x2, [SP, #-0x10]!
    // 0xcccb18: r0 = resolve()
    //     0xcccb18: bl              #0x6ca720  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xcccb1c: add             SP, SP, #0x10
    // 0xcccb20: mov             x1, x0
    // 0xcccb24: ldr             x0, [fp, #0x20]
    // 0xcccb28: stur            x1, [fp, #-0x18]
    // 0xcccb2c: LoadField: r2 = r0->field_17
    //     0xcccb2c: ldur            w2, [x0, #0x17]
    // 0xcccb30: DecompressPointer r2
    //     0xcccb30: add             x2, x2, HEAP, lsl #32
    // 0xcccb34: ldr             x16, [fp, #0x18]
    // 0xcccb38: stp             x16, x2, [SP, #-0x10]!
    // 0xcccb3c: r0 = resolve()
    //     0xcccb3c: bl              #0x6ca720  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0xcccb40: add             SP, SP, #0x10
    // 0xcccb44: mov             x1, x0
    // 0xcccb48: ldr             x0, [fp, #0x10]
    // 0xcccb4c: stur            x1, [fp, #-0x20]
    // 0xcccb50: tbnz            w0, #4, #0xcccb78
    // 0xcccb54: ldr             x0, [fp, #0x20]
    // 0xcccb58: LoadField: r2 = r0->field_1b
    //     0xcccb58: ldur            w2, [x0, #0x1b]
    // 0xcccb5c: DecompressPointer r2
    //     0xcccb5c: add             x2, x2, HEAP, lsl #32
    // 0xcccb60: ldr             x16, [fp, #0x18]
    // 0xcccb64: stp             x16, x2, [SP, #-0x10]!
    // 0xcccb68: r0 = resolveFrom()
    //     0xcccb68: bl              #0xcccbe8  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::resolveFrom
    // 0xcccb6c: add             SP, SP, #0x10
    // 0xcccb70: mov             x4, x0
    // 0xcccb74: b               #0xcccb88
    // 0xcccb78: ldr             x0, [fp, #0x20]
    // 0xcccb7c: LoadField: r1 = r0->field_1b
    //     0xcccb7c: ldur            w1, [x0, #0x1b]
    // 0xcccb80: DecompressPointer r1
    //     0xcccb80: add             x1, x1, HEAP, lsl #32
    // 0xcccb84: mov             x4, x1
    // 0xcccb88: ldur            x3, [fp, #-8]
    // 0xcccb8c: ldur            x2, [fp, #-0x10]
    // 0xcccb90: ldur            x1, [fp, #-0x18]
    // 0xcccb94: ldur            x0, [fp, #-0x20]
    // 0xcccb98: stur            x4, [fp, #-0x28]
    // 0xcccb9c: r0 = _CupertinoThemeDefaults()
    //     0xcccb9c: bl              #0xcccbdc  ; Allocate_CupertinoThemeDefaultsStub -> _CupertinoThemeDefaults (size=0x20)
    // 0xcccba0: ldur            x1, [fp, #-8]
    // 0xcccba4: StoreField: r0->field_b = r1
    //     0xcccba4: stur            w1, [x0, #0xb]
    // 0xcccba8: ldur            x1, [fp, #-0x10]
    // 0xcccbac: StoreField: r0->field_f = r1
    //     0xcccbac: stur            w1, [x0, #0xf]
    // 0xcccbb0: ldur            x1, [fp, #-0x18]
    // 0xcccbb4: StoreField: r0->field_13 = r1
    //     0xcccbb4: stur            w1, [x0, #0x13]
    // 0xcccbb8: ldur            x1, [fp, #-0x20]
    // 0xcccbbc: StoreField: r0->field_17 = r1
    //     0xcccbbc: stur            w1, [x0, #0x17]
    // 0xcccbc0: ldur            x1, [fp, #-0x28]
    // 0xcccbc4: StoreField: r0->field_1b = r1
    //     0xcccbc4: stur            w1, [x0, #0x1b]
    // 0xcccbc8: LeaveFrame
    //     0xcccbc8: mov             SP, fp
    //     0xcccbcc: ldp             fp, lr, [SP], #0x10
    // 0xcccbd0: ret
    //     0xcccbd0: ret             
    // 0xcccbd4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcccbd4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcccbd8: b               #0xcccabc
  }
}

// class id: 2659, size: 0x20, field offset: 0x8
//   const constructor, 
class NoDefaultCupertinoThemeData extends Object {

  _ resolveFrom(/* No info */) {
    // ** addr: 0xcccc78, size: 0xf0
    // 0xcccc78: EnterFrame
    //     0xcccc78: stp             fp, lr, [SP, #-0x10]!
    //     0xcccc7c: mov             fp, SP
    // 0xcccc80: AllocStack(0x28)
    //     0xcccc80: sub             SP, SP, #0x28
    // 0xcccc84: CheckStackOverflow
    //     0xcccc84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcccc88: cmp             SP, x16
    //     0xcccc8c: b.ls            #0xcccd60
    // 0xcccc90: ldr             x0, [fp, #0x18]
    // 0xcccc94: LoadField: r1 = r0->field_7
    //     0xcccc94: ldur            w1, [x0, #7]
    // 0xcccc98: DecompressPointer r1
    //     0xcccc98: add             x1, x1, HEAP, lsl #32
    // 0xcccc9c: stur            x1, [fp, #-8]
    // 0xcccca0: LoadField: r2 = r0->field_b
    //     0xcccca0: ldur            w2, [x0, #0xb]
    // 0xcccca4: DecompressPointer r2
    //     0xcccca4: add             x2, x2, HEAP, lsl #32
    // 0xcccca8: ldr             x16, [fp, #0x10]
    // 0xccccac: stp             x16, x2, [SP, #-0x10]!
    // 0xccccb0: r0 = maybeResolve()
    //     0xccccb0: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccccb4: add             SP, SP, #0x10
    // 0xccccb8: mov             x1, x0
    // 0xccccbc: ldr             x0, [fp, #0x18]
    // 0xccccc0: stur            x1, [fp, #-0x10]
    // 0xccccc4: LoadField: r2 = r0->field_f
    //     0xccccc4: ldur            w2, [x0, #0xf]
    // 0xccccc8: DecompressPointer r2
    //     0xccccc8: add             x2, x2, HEAP, lsl #32
    // 0xcccccc: ldr             x16, [fp, #0x10]
    // 0xccccd0: stp             x16, x2, [SP, #-0x10]!
    // 0xccccd4: r0 = maybeResolve()
    //     0xccccd4: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccccd8: add             SP, SP, #0x10
    // 0xccccdc: mov             x1, x0
    // 0xcccce0: ldr             x0, [fp, #0x18]
    // 0xcccce4: stur            x1, [fp, #-0x18]
    // 0xcccce8: LoadField: r2 = r0->field_17
    //     0xcccce8: ldur            w2, [x0, #0x17]
    // 0xccccec: DecompressPointer r2
    //     0xccccec: add             x2, x2, HEAP, lsl #32
    // 0xccccf0: ldr             x16, [fp, #0x10]
    // 0xccccf4: stp             x16, x2, [SP, #-0x10]!
    // 0xccccf8: r0 = maybeResolve()
    //     0xccccf8: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccccfc: add             SP, SP, #0x10
    // 0xcccd00: mov             x1, x0
    // 0xcccd04: ldr             x0, [fp, #0x18]
    // 0xcccd08: stur            x1, [fp, #-0x20]
    // 0xcccd0c: LoadField: r2 = r0->field_1b
    //     0xcccd0c: ldur            w2, [x0, #0x1b]
    // 0xcccd10: DecompressPointer r2
    //     0xcccd10: add             x2, x2, HEAP, lsl #32
    // 0xcccd14: ldr             x16, [fp, #0x10]
    // 0xcccd18: stp             x16, x2, [SP, #-0x10]!
    // 0xcccd1c: r0 = maybeResolve()
    //     0xcccd1c: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xcccd20: add             SP, SP, #0x10
    // 0xcccd24: stur            x0, [fp, #-0x28]
    // 0xcccd28: r0 = NoDefaultCupertinoThemeData()
    //     0xcccd28: bl              #0xb24a50  ; AllocateNoDefaultCupertinoThemeDataStub -> NoDefaultCupertinoThemeData (size=0x20)
    // 0xcccd2c: ldur            x1, [fp, #-8]
    // 0xcccd30: StoreField: r0->field_7 = r1
    //     0xcccd30: stur            w1, [x0, #7]
    // 0xcccd34: ldur            x1, [fp, #-0x10]
    // 0xcccd38: StoreField: r0->field_b = r1
    //     0xcccd38: stur            w1, [x0, #0xb]
    // 0xcccd3c: ldur            x1, [fp, #-0x18]
    // 0xcccd40: StoreField: r0->field_f = r1
    //     0xcccd40: stur            w1, [x0, #0xf]
    // 0xcccd44: ldur            x1, [fp, #-0x20]
    // 0xcccd48: StoreField: r0->field_17 = r1
    //     0xcccd48: stur            w1, [x0, #0x17]
    // 0xcccd4c: ldur            x1, [fp, #-0x28]
    // 0xcccd50: StoreField: r0->field_1b = r1
    //     0xcccd50: stur            w1, [x0, #0x1b]
    // 0xcccd54: LeaveFrame
    //     0xcccd54: mov             SP, fp
    //     0xcccd58: ldp             fp, lr, [SP], #0x10
    // 0xcccd5c: ret
    //     0xcccd5c: ret             
    // 0xcccd60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcccd60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcccd64: b               #0xcccc90
  }
}

// class id: 2660, size: 0x20, field offset: 0x20
//   const constructor, transformed mixin,
abstract class _CupertinoThemeData&NoDefaultCupertinoThemeData&Diagnosticable extends NoDefaultCupertinoThemeData
     with Diagnosticable {
}

// class id: 2661, size: 0x24, field offset: 0x20
//   const constructor, 
class CupertinoThemeData extends _CupertinoThemeData&NoDefaultCupertinoThemeData&Diagnosticable {

  _CupertinoThemeDefaults field_20;

  get _ textTheme(/* No info */) {
    // ** addr: 0x83fe48, size: 0x60
    // 0x83fe48: EnterFrame
    //     0x83fe48: stp             fp, lr, [SP, #-0x10]!
    //     0x83fe4c: mov             fp, SP
    // 0x83fe50: CheckStackOverflow
    //     0x83fe50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83fe54: cmp             SP, x16
    //     0x83fe58: b.ls            #0x83fea0
    // 0x83fe5c: ldr             x0, [fp, #0x10]
    // 0x83fe60: LoadField: r1 = r0->field_1f
    //     0x83fe60: ldur            w1, [x0, #0x1f]
    // 0x83fe64: DecompressPointer r1
    //     0x83fe64: add             x1, x1, HEAP, lsl #32
    // 0x83fe68: LoadField: r2 = r1->field_1b
    //     0x83fe68: ldur            w2, [x1, #0x1b]
    // 0x83fe6c: DecompressPointer r2
    //     0x83fe6c: add             x2, x2, HEAP, lsl #32
    // 0x83fe70: r1 = LoadClassIdInstr(r0)
    //     0x83fe70: ldur            x1, [x0, #-1]
    //     0x83fe74: ubfx            x1, x1, #0xc, #0x14
    // 0x83fe78: lsl             x1, x1, #1
    // 0x83fe7c: r17 = 5322
    //     0x83fe7c: mov             x17, #0x14ca
    // 0x83fe80: cmp             w1, w17
    // 0x83fe84: b.eq            #0x83fe88
    // 0x83fe88: SaveReg r2
    //     0x83fe88: str             x2, [SP, #-8]!
    // 0x83fe8c: r0 = createDefaults()
    //     0x83fe8c: bl              #0x83fea8  ; [package:flutter/src/cupertino/theme.dart] _CupertinoTextThemeDefaults::createDefaults
    // 0x83fe90: add             SP, SP, #8
    // 0x83fe94: LeaveFrame
    //     0x83fe94: mov             SP, fp
    //     0x83fe98: ldp             fp, lr, [SP], #0x10
    // 0x83fe9c: ret
    //     0x83fe9c: ret             
    // 0x83fea0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83fea0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83fea4: b               #0x83fe5c
  }
  _ noDefault(/* No info */) {
    // ** addr: 0xb249cc, size: 0x84
    // 0xb249cc: EnterFrame
    //     0xb249cc: stp             fp, lr, [SP, #-0x10]!
    //     0xb249d0: mov             fp, SP
    // 0xb249d4: AllocStack(0x28)
    //     0xb249d4: sub             SP, SP, #0x28
    // 0xb249d8: ldr             x0, [fp, #0x10]
    // 0xb249dc: LoadField: r1 = r0->field_7
    //     0xb249dc: ldur            w1, [x0, #7]
    // 0xb249e0: DecompressPointer r1
    //     0xb249e0: add             x1, x1, HEAP, lsl #32
    // 0xb249e4: stur            x1, [fp, #-0x28]
    // 0xb249e8: LoadField: r2 = r0->field_b
    //     0xb249e8: ldur            w2, [x0, #0xb]
    // 0xb249ec: DecompressPointer r2
    //     0xb249ec: add             x2, x2, HEAP, lsl #32
    // 0xb249f0: stur            x2, [fp, #-0x20]
    // 0xb249f4: LoadField: r3 = r0->field_f
    //     0xb249f4: ldur            w3, [x0, #0xf]
    // 0xb249f8: DecompressPointer r3
    //     0xb249f8: add             x3, x3, HEAP, lsl #32
    // 0xb249fc: stur            x3, [fp, #-0x18]
    // 0xb24a00: LoadField: r4 = r0->field_17
    //     0xb24a00: ldur            w4, [x0, #0x17]
    // 0xb24a04: DecompressPointer r4
    //     0xb24a04: add             x4, x4, HEAP, lsl #32
    // 0xb24a08: stur            x4, [fp, #-0x10]
    // 0xb24a0c: LoadField: r5 = r0->field_1b
    //     0xb24a0c: ldur            w5, [x0, #0x1b]
    // 0xb24a10: DecompressPointer r5
    //     0xb24a10: add             x5, x5, HEAP, lsl #32
    // 0xb24a14: stur            x5, [fp, #-8]
    // 0xb24a18: r0 = NoDefaultCupertinoThemeData()
    //     0xb24a18: bl              #0xb24a50  ; AllocateNoDefaultCupertinoThemeDataStub -> NoDefaultCupertinoThemeData (size=0x20)
    // 0xb24a1c: ldur            x1, [fp, #-0x28]
    // 0xb24a20: StoreField: r0->field_7 = r1
    //     0xb24a20: stur            w1, [x0, #7]
    // 0xb24a24: ldur            x1, [fp, #-0x20]
    // 0xb24a28: StoreField: r0->field_b = r1
    //     0xb24a28: stur            w1, [x0, #0xb]
    // 0xb24a2c: ldur            x1, [fp, #-0x18]
    // 0xb24a30: StoreField: r0->field_f = r1
    //     0xb24a30: stur            w1, [x0, #0xf]
    // 0xb24a34: ldur            x1, [fp, #-0x10]
    // 0xb24a38: StoreField: r0->field_17 = r1
    //     0xb24a38: stur            w1, [x0, #0x17]
    // 0xb24a3c: ldur            x1, [fp, #-8]
    // 0xb24a40: StoreField: r0->field_1b = r1
    //     0xb24a40: stur            w1, [x0, #0x1b]
    // 0xb24a44: LeaveFrame
    //     0xb24a44: mov             SP, fp
    //     0xb24a48: ldp             fp, lr, [SP], #0x10
    // 0xb24a4c: ret
    //     0xb24a4c: ret             
  }
  _ resolveFrom(/* No info */) {
    // ** addr: 0xccc980, size: 0x124
    // 0xccc980: EnterFrame
    //     0xccc980: stp             fp, lr, [SP, #-0x10]!
    //     0xccc984: mov             fp, SP
    // 0xccc988: AllocStack(0x30)
    //     0xccc988: sub             SP, SP, #0x30
    // 0xccc98c: CheckStackOverflow
    //     0xccc98c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccc990: cmp             SP, x16
    //     0xccc994: b.ls            #0xccca9c
    // 0xccc998: ldr             x0, [fp, #0x18]
    // 0xccc99c: LoadField: r1 = r0->field_7
    //     0xccc99c: ldur            w1, [x0, #7]
    // 0xccc9a0: DecompressPointer r1
    //     0xccc9a0: add             x1, x1, HEAP, lsl #32
    // 0xccc9a4: stur            x1, [fp, #-8]
    // 0xccc9a8: LoadField: r2 = r0->field_b
    //     0xccc9a8: ldur            w2, [x0, #0xb]
    // 0xccc9ac: DecompressPointer r2
    //     0xccc9ac: add             x2, x2, HEAP, lsl #32
    // 0xccc9b0: ldr             x16, [fp, #0x10]
    // 0xccc9b4: stp             x16, x2, [SP, #-0x10]!
    // 0xccc9b8: r0 = maybeResolve()
    //     0xccc9b8: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccc9bc: add             SP, SP, #0x10
    // 0xccc9c0: mov             x1, x0
    // 0xccc9c4: ldr             x0, [fp, #0x18]
    // 0xccc9c8: stur            x1, [fp, #-0x10]
    // 0xccc9cc: LoadField: r2 = r0->field_f
    //     0xccc9cc: ldur            w2, [x0, #0xf]
    // 0xccc9d0: DecompressPointer r2
    //     0xccc9d0: add             x2, x2, HEAP, lsl #32
    // 0xccc9d4: ldr             x16, [fp, #0x10]
    // 0xccc9d8: stp             x16, x2, [SP, #-0x10]!
    // 0xccc9dc: r0 = maybeResolve()
    //     0xccc9dc: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccc9e0: add             SP, SP, #0x10
    // 0xccc9e4: mov             x1, x0
    // 0xccc9e8: ldr             x0, [fp, #0x18]
    // 0xccc9ec: stur            x1, [fp, #-0x18]
    // 0xccc9f0: LoadField: r2 = r0->field_17
    //     0xccc9f0: ldur            w2, [x0, #0x17]
    // 0xccc9f4: DecompressPointer r2
    //     0xccc9f4: add             x2, x2, HEAP, lsl #32
    // 0xccc9f8: ldr             x16, [fp, #0x10]
    // 0xccc9fc: stp             x16, x2, [SP, #-0x10]!
    // 0xccca00: r0 = maybeResolve()
    //     0xccca00: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccca04: add             SP, SP, #0x10
    // 0xccca08: mov             x1, x0
    // 0xccca0c: ldr             x0, [fp, #0x18]
    // 0xccca10: stur            x1, [fp, #-0x20]
    // 0xccca14: LoadField: r2 = r0->field_1b
    //     0xccca14: ldur            w2, [x0, #0x1b]
    // 0xccca18: DecompressPointer r2
    //     0xccca18: add             x2, x2, HEAP, lsl #32
    // 0xccca1c: ldr             x16, [fp, #0x10]
    // 0xccca20: stp             x16, x2, [SP, #-0x10]!
    // 0xccca24: r0 = maybeResolve()
    //     0xccca24: bl              #0x83fef4  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::maybeResolve
    // 0xccca28: add             SP, SP, #0x10
    // 0xccca2c: mov             x1, x0
    // 0xccca30: ldr             x0, [fp, #0x18]
    // 0xccca34: stur            x1, [fp, #-0x28]
    // 0xccca38: LoadField: r2 = r0->field_1f
    //     0xccca38: ldur            w2, [x0, #0x1f]
    // 0xccca3c: DecompressPointer r2
    //     0xccca3c: add             x2, x2, HEAP, lsl #32
    // 0xccca40: ldr             x16, [fp, #0x10]
    // 0xccca44: stp             x16, x2, [SP, #-0x10]!
    // 0xccca48: r16 = true
    //     0xccca48: add             x16, NULL, #0x20  ; true
    // 0xccca4c: SaveReg r16
    //     0xccca4c: str             x16, [SP, #-8]!
    // 0xccca50: r0 = resolveFrom()
    //     0xccca50: bl              #0xcccaa4  ; [package:flutter/src/cupertino/theme.dart] _CupertinoThemeDefaults::resolveFrom
    // 0xccca54: add             SP, SP, #0x18
    // 0xccca58: stur            x0, [fp, #-0x30]
    // 0xccca5c: r0 = CupertinoThemeData()
    //     0xccca5c: bl              #0xb7fe38  ; AllocateCupertinoThemeDataStub -> CupertinoThemeData (size=0x24)
    // 0xccca60: ldur            x1, [fp, #-0x30]
    // 0xccca64: StoreField: r0->field_1f = r1
    //     0xccca64: stur            w1, [x0, #0x1f]
    // 0xccca68: ldur            x1, [fp, #-8]
    // 0xccca6c: StoreField: r0->field_7 = r1
    //     0xccca6c: stur            w1, [x0, #7]
    // 0xccca70: ldur            x1, [fp, #-0x10]
    // 0xccca74: StoreField: r0->field_b = r1
    //     0xccca74: stur            w1, [x0, #0xb]
    // 0xccca78: ldur            x1, [fp, #-0x18]
    // 0xccca7c: StoreField: r0->field_f = r1
    //     0xccca7c: stur            w1, [x0, #0xf]
    // 0xccca80: ldur            x1, [fp, #-0x20]
    // 0xccca84: StoreField: r0->field_17 = r1
    //     0xccca84: stur            w1, [x0, #0x17]
    // 0xccca88: ldur            x1, [fp, #-0x28]
    // 0xccca8c: StoreField: r0->field_1b = r1
    //     0xccca8c: stur            w1, [x0, #0x1b]
    // 0xccca90: LeaveFrame
    //     0xccca90: mov             SP, fp
    //     0xccca94: ldp             fp, lr, [SP], #0x10
    // 0xccca98: ret
    //     0xccca98: ret             
    // 0xccca9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccca9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcccaa0: b               #0xccc998
  }
}

// class id: 2897, size: 0x14, field offset: 0x10
//   const constructor, 
class _DefaultCupertinoTextThemeData extends CupertinoTextThemeData {

  get _ textStyle(/* No info */) {
    // ** addr: 0x83fd48, size: 0x5c
    // 0x83fd48: EnterFrame
    //     0x83fd48: stp             fp, lr, [SP, #-0x10]!
    //     0x83fd4c: mov             fp, SP
    // 0x83fd50: CheckStackOverflow
    //     0x83fd50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83fd54: cmp             SP, x16
    //     0x83fd58: b.ls            #0x83fd9c
    // 0x83fd5c: ldr             x16, [fp, #0x10]
    // 0x83fd60: SaveReg r16
    //     0x83fd60: str             x16, [SP, #-8]!
    // 0x83fd64: r0 = textStyle()
    //     0x83fd64: bl              #0x83fda4  ; [package:flutter/src/cupertino/text_theme.dart] CupertinoTextThemeData::textStyle
    // 0x83fd68: add             SP, SP, #8
    // 0x83fd6c: mov             x1, x0
    // 0x83fd70: ldr             x0, [fp, #0x10]
    // 0x83fd74: LoadField: r2 = r0->field_f
    //     0x83fd74: ldur            w2, [x0, #0xf]
    // 0x83fd78: DecompressPointer r2
    //     0x83fd78: add             x2, x2, HEAP, lsl #32
    // 0x83fd7c: stp             x2, x1, [SP, #-0x10]!
    // 0x83fd80: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x83fd80: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x83fd84: ldr             x4, [x4, #0x168]
    // 0x83fd88: r0 = copyWith()
    //     0x83fd88: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x83fd8c: add             SP, SP, #0x10
    // 0x83fd90: LeaveFrame
    //     0x83fd90: mov             SP, fp
    //     0x83fd94: ldp             fp, lr, [SP], #0x10
    // 0x83fd98: ret
    //     0x83fd98: ret             
    // 0x83fd9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83fd9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83fda0: b               #0x83fd5c
  }
}

// class id: 3551, size: 0x14, field offset: 0x10
//   const constructor, 
class _InheritedCupertinoTheme extends InheritedWidget {

  _ updateShouldNotify(/* No info */) {
    // ** addr: 0xa87708, size: 0x84
    // 0xa87708: EnterFrame
    //     0xa87708: stp             fp, lr, [SP, #-0x10]!
    //     0xa8770c: mov             fp, SP
    // 0xa87710: ldr             x0, [fp, #0x10]
    // 0xa87714: r2 = Null
    //     0xa87714: mov             x2, NULL
    // 0xa87718: r1 = Null
    //     0xa87718: mov             x1, NULL
    // 0xa8771c: r4 = 59
    //     0xa8771c: mov             x4, #0x3b
    // 0xa87720: branchIfSmi(r0, 0xa8772c)
    //     0xa87720: tbz             w0, #0, #0xa8772c
    // 0xa87724: r4 = LoadClassIdInstr(r0)
    //     0xa87724: ldur            x4, [x0, #-1]
    //     0xa87728: ubfx            x4, x4, #0xc, #0x14
    // 0xa8772c: cmp             x4, #0xddf
    // 0xa87730: b.eq            #0xa87748
    // 0xa87734: r8 = _InheritedCupertinoTheme
    //     0xa87734: add             x8, PP, #0x40, lsl #12  ; [pp+0x40358] Type: _InheritedCupertinoTheme
    //     0xa87738: ldr             x8, [x8, #0x358]
    // 0xa8773c: r3 = Null
    //     0xa8773c: add             x3, PP, #0x40, lsl #12  ; [pp+0x40360] Null
    //     0xa87740: ldr             x3, [x3, #0x360]
    // 0xa87744: r0 = DefaultTypeTest()
    //     0xa87744: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xa87748: ldr             x1, [fp, #0x18]
    // 0xa8774c: LoadField: r2 = r1->field_f
    //     0xa8774c: ldur            w2, [x1, #0xf]
    // 0xa87750: DecompressPointer r2
    //     0xa87750: add             x2, x2, HEAP, lsl #32
    // 0xa87754: LoadField: r1 = r2->field_b
    //     0xa87754: ldur            w1, [x2, #0xb]
    // 0xa87758: DecompressPointer r1
    //     0xa87758: add             x1, x1, HEAP, lsl #32
    // 0xa8775c: ldr             x2, [fp, #0x10]
    // 0xa87760: LoadField: r3 = r2->field_f
    //     0xa87760: ldur            w3, [x2, #0xf]
    // 0xa87764: DecompressPointer r3
    //     0xa87764: add             x3, x3, HEAP, lsl #32
    // 0xa87768: LoadField: r2 = r3->field_b
    //     0xa87768: ldur            w2, [x3, #0xb]
    // 0xa8776c: DecompressPointer r2
    //     0xa8776c: add             x2, x2, HEAP, lsl #32
    // 0xa87770: cmp             w1, w2
    // 0xa87774: r16 = true
    //     0xa87774: add             x16, NULL, #0x20  ; true
    // 0xa87778: r17 = false
    //     0xa87778: add             x17, NULL, #0x30  ; false
    // 0xa8777c: csel            x0, x16, x17, ne
    // 0xa87780: LeaveFrame
    //     0xa87780: mov             SP, fp
    //     0xa87784: ldp             fp, lr, [SP], #0x10
    // 0xa87788: ret
    //     0xa87788: ret             
  }
}

// class id: 3866, size: 0x14, field offset: 0xc
//   const constructor, 
class CupertinoTheme extends StatelessWidget {

  static _ maybeBrightnessOf(/* No info */) {
    // ** addr: 0x6caf58, size: 0xfc
    // 0x6caf58: EnterFrame
    //     0x6caf58: stp             fp, lr, [SP, #-0x10]!
    //     0x6caf5c: mov             fp, SP
    // 0x6caf60: CheckStackOverflow
    //     0x6caf60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6caf64: cmp             SP, x16
    //     0x6caf68: b.ls            #0x6cb04c
    // 0x6caf6c: r16 = <_InheritedCupertinoTheme>
    //     0x6caf6c: add             x16, PP, #0x27, lsl #12  ; [pp+0x27dc8] TypeArguments: <_InheritedCupertinoTheme>
    //     0x6caf70: ldr             x16, [x16, #0xdc8]
    // 0x6caf74: ldr             lr, [fp, #0x10]
    // 0x6caf78: stp             lr, x16, [SP, #-0x10]!
    // 0x6caf7c: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x6caf7c: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x6caf80: r0 = dependOnInheritedWidgetOfExactType()
    //     0x6caf80: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x6caf84: add             SP, SP, #0x10
    // 0x6caf88: cmp             w0, NULL
    // 0x6caf8c: b.ne            #0x6caf98
    // 0x6caf90: r0 = Null
    //     0x6caf90: mov             x0, NULL
    // 0x6caf94: b               #0x6cb00c
    // 0x6caf98: LoadField: r1 = r0->field_f
    //     0x6caf98: ldur            w1, [x0, #0xf]
    // 0x6caf9c: DecompressPointer r1
    //     0x6caf9c: add             x1, x1, HEAP, lsl #32
    // 0x6cafa0: LoadField: r0 = r1->field_b
    //     0x6cafa0: ldur            w0, [x1, #0xb]
    // 0x6cafa4: DecompressPointer r0
    //     0x6cafa4: add             x0, x0, HEAP, lsl #32
    // 0x6cafa8: r1 = LoadClassIdInstr(r0)
    //     0x6cafa8: ldur            x1, [x0, #-1]
    //     0x6cafac: ubfx            x1, x1, #0xc, #0x14
    // 0x6cafb0: lsl             x1, x1, #1
    // 0x6cafb4: r17 = 5322
    //     0x6cafb4: mov             x17, #0x14ca
    // 0x6cafb8: cmp             w1, w17
    // 0x6cafbc: b.ne            #0x6cafd0
    // 0x6cafc0: LoadField: r1 = r0->field_7
    //     0x6cafc0: ldur            w1, [x0, #7]
    // 0x6cafc4: DecompressPointer r1
    //     0x6cafc4: add             x1, x1, HEAP, lsl #32
    // 0x6cafc8: mov             x0, x1
    // 0x6cafcc: b               #0x6cb00c
    // 0x6cafd0: LoadField: r1 = r0->field_27
    //     0x6cafd0: ldur            w1, [x0, #0x27]
    // 0x6cafd4: DecompressPointer r1
    //     0x6cafd4: add             x1, x1, HEAP, lsl #32
    // 0x6cafd8: LoadField: r2 = r1->field_7
    //     0x6cafd8: ldur            w2, [x1, #7]
    // 0x6cafdc: DecompressPointer r2
    //     0x6cafdc: add             x2, x2, HEAP, lsl #32
    // 0x6cafe0: cmp             w2, NULL
    // 0x6cafe4: b.ne            #0x6cb008
    // 0x6cafe8: LoadField: r1 = r0->field_23
    //     0x6cafe8: ldur            w1, [x0, #0x23]
    // 0x6cafec: DecompressPointer r1
    //     0x6cafec: add             x1, x1, HEAP, lsl #32
    // 0x6caff0: LoadField: r0 = r1->field_3f
    //     0x6caff0: ldur            w0, [x1, #0x3f]
    // 0x6caff4: DecompressPointer r0
    //     0x6caff4: add             x0, x0, HEAP, lsl #32
    // 0x6caff8: LoadField: r1 = r0->field_7
    //     0x6caff8: ldur            w1, [x0, #7]
    // 0x6caffc: DecompressPointer r1
    //     0x6caffc: add             x1, x1, HEAP, lsl #32
    // 0x6cb000: mov             x0, x1
    // 0x6cb004: b               #0x6cb00c
    // 0x6cb008: mov             x0, x2
    // 0x6cb00c: cmp             w0, NULL
    // 0x6cb010: b.ne            #0x6cb040
    // 0x6cb014: ldr             x16, [fp, #0x10]
    // 0x6cb018: SaveReg r16
    //     0x6cb018: str             x16, [SP, #-8]!
    // 0x6cb01c: r0 = maybeOf()
    //     0x6cb01c: bl              #0x5178bc  ; [package:flutter/src/widgets/media_query.dart] MediaQuery::maybeOf
    // 0x6cb020: add             SP, SP, #8
    // 0x6cb024: cmp             w0, NULL
    // 0x6cb028: b.ne            #0x6cb034
    // 0x6cb02c: r1 = Null
    //     0x6cb02c: mov             x1, NULL
    // 0x6cb030: b               #0x6cb03c
    // 0x6cb034: LoadField: r1 = r0->field_1b
    //     0x6cb034: ldur            w1, [x0, #0x1b]
    // 0x6cb038: DecompressPointer r1
    //     0x6cb038: add             x1, x1, HEAP, lsl #32
    // 0x6cb03c: mov             x0, x1
    // 0x6cb040: LeaveFrame
    //     0x6cb040: mov             SP, fp
    //     0x6cb044: ldp             fp, lr, [SP], #0x10
    // 0x6cb048: ret
    //     0x6cb048: ret             
    // 0x6cb04c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb04c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb050: b               #0x6caf6c
  }
  static _ of(/* No info */) {
    // ** addr: 0x83d26c, size: 0x104
    // 0x83d26c: EnterFrame
    //     0x83d26c: stp             fp, lr, [SP, #-0x10]!
    //     0x83d270: mov             fp, SP
    // 0x83d274: AllocStack(0x18)
    //     0x83d274: sub             SP, SP, #0x18
    // 0x83d278: CheckStackOverflow
    //     0x83d278: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83d27c: cmp             SP, x16
    //     0x83d280: b.ls            #0x83d368
    // 0x83d284: r16 = <_InheritedCupertinoTheme>
    //     0x83d284: add             x16, PP, #0x27, lsl #12  ; [pp+0x27dc8] TypeArguments: <_InheritedCupertinoTheme>
    //     0x83d288: ldr             x16, [x16, #0xdc8]
    // 0x83d28c: ldr             lr, [fp, #0x10]
    // 0x83d290: stp             lr, x16, [SP, #-0x10]!
    // 0x83d294: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x83d294: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x83d298: r0 = dependOnInheritedWidgetOfExactType()
    //     0x83d298: bl              #0x51791c  ; [package:flutter/src/widgets/framework.dart] Element::dependOnInheritedWidgetOfExactType
    // 0x83d29c: add             SP, SP, #0x10
    // 0x83d2a0: cmp             w0, NULL
    // 0x83d2a4: b.ne            #0x83d2b0
    // 0x83d2a8: r0 = Null
    //     0x83d2a8: mov             x0, NULL
    // 0x83d2ac: b               #0x83d2c0
    // 0x83d2b0: LoadField: r1 = r0->field_f
    //     0x83d2b0: ldur            w1, [x0, #0xf]
    // 0x83d2b4: DecompressPointer r1
    //     0x83d2b4: add             x1, x1, HEAP, lsl #32
    // 0x83d2b8: LoadField: r0 = r1->field_b
    //     0x83d2b8: ldur            w0, [x1, #0xb]
    // 0x83d2bc: DecompressPointer r0
    //     0x83d2bc: add             x0, x0, HEAP, lsl #32
    // 0x83d2c0: cmp             w0, NULL
    // 0x83d2c4: b.ne            #0x83d2d0
    // 0x83d2c8: r0 = Instance_CupertinoThemeData
    //     0x83d2c8: add             x0, PP, #0x2d, lsl #12  ; [pp+0x2db68] Obj!CupertinoThemeData@b38831
    //     0x83d2cc: ldr             x0, [x0, #0xb68]
    // 0x83d2d0: r1 = LoadClassIdInstr(r0)
    //     0x83d2d0: ldur            x1, [x0, #-1]
    //     0x83d2d4: ubfx            x1, x1, #0xc, #0x14
    // 0x83d2d8: lsl             x1, x1, #1
    // 0x83d2dc: r17 = 5324
    //     0x83d2dc: mov             x17, #0x14cc
    // 0x83d2e0: cmp             w1, w17
    // 0x83d2e4: b.ne            #0x83d338
    // 0x83d2e8: LoadField: r1 = r0->field_23
    //     0x83d2e8: ldur            w1, [x0, #0x23]
    // 0x83d2ec: DecompressPointer r1
    //     0x83d2ec: add             x1, x1, HEAP, lsl #32
    // 0x83d2f0: stur            x1, [fp, #-8]
    // 0x83d2f4: LoadField: r2 = r0->field_27
    //     0x83d2f4: ldur            w2, [x0, #0x27]
    // 0x83d2f8: DecompressPointer r2
    //     0x83d2f8: add             x2, x2, HEAP, lsl #32
    // 0x83d2fc: ldr             x16, [fp, #0x10]
    // 0x83d300: stp             x16, x2, [SP, #-0x10]!
    // 0x83d304: r0 = resolveFrom()
    //     0x83d304: bl              #0xcccc78  ; [package:flutter/src/cupertino/theme.dart] NoDefaultCupertinoThemeData::resolveFrom
    // 0x83d308: add             SP, SP, #0x10
    // 0x83d30c: stur            x0, [fp, #-0x10]
    // 0x83d310: r0 = MaterialBasedCupertinoThemeData()
    //     0x83d310: bl              #0x83d4a0  ; AllocateMaterialBasedCupertinoThemeDataStub -> MaterialBasedCupertinoThemeData (size=0x2c)
    // 0x83d314: stur            x0, [fp, #-0x18]
    // 0x83d318: ldur            x16, [fp, #-8]
    // 0x83d31c: stp             x16, x0, [SP, #-0x10]!
    // 0x83d320: ldur            x16, [fp, #-0x10]
    // 0x83d324: SaveReg r16
    //     0x83d324: str             x16, [SP, #-8]!
    // 0x83d328: r0 = MaterialBasedCupertinoThemeData._()
    //     0x83d328: bl              #0x83d370  ; [package:flutter/src/material/theme_data.dart] MaterialBasedCupertinoThemeData::MaterialBasedCupertinoThemeData._
    // 0x83d32c: add             SP, SP, #0x18
    // 0x83d330: ldur            x0, [fp, #-0x18]
    // 0x83d334: b               #0x83d35c
    // 0x83d338: r1 = LoadClassIdInstr(r0)
    //     0x83d338: ldur            x1, [x0, #-1]
    //     0x83d33c: ubfx            x1, x1, #0xc, #0x14
    // 0x83d340: ldr             x16, [fp, #0x10]
    // 0x83d344: stp             x16, x0, [SP, #-0x10]!
    // 0x83d348: mov             x0, x1
    // 0x83d34c: r0 = GDT[cid_x0 + -0xb04]()
    //     0x83d34c: sub             lr, x0, #0xb04
    //     0x83d350: ldr             lr, [x21, lr, lsl #3]
    //     0x83d354: blr             lr
    // 0x83d358: add             SP, SP, #0x10
    // 0x83d35c: LeaveFrame
    //     0x83d35c: mov             SP, fp
    //     0x83d360: ldp             fp, lr, [SP], #0x10
    // 0x83d364: ret
    //     0x83d364: ret             
    // 0x83d368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83d368: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83d36c: b               #0x83d284
  }
  _ build(/* No info */) {
    // ** addr: 0xb1d60c, size: 0xfc
    // 0xb1d60c: EnterFrame
    //     0xb1d60c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d610: mov             fp, SP
    // 0xb1d614: AllocStack(0x18)
    //     0xb1d614: sub             SP, SP, #0x18
    // 0xb1d618: ldr             x0, [fp, #0x18]
    // 0xb1d61c: LoadField: r1 = r0->field_b
    //     0xb1d61c: ldur            w1, [x0, #0xb]
    // 0xb1d620: DecompressPointer r1
    //     0xb1d620: add             x1, x1, HEAP, lsl #32
    // 0xb1d624: r2 = LoadClassIdInstr(r1)
    //     0xb1d624: ldur            x2, [x1, #-1]
    //     0xb1d628: ubfx            x2, x2, #0xc, #0x14
    // 0xb1d62c: lsl             x2, x2, #1
    // 0xb1d630: r17 = 5322
    //     0xb1d630: mov             x17, #0x14ca
    // 0xb1d634: cmp             w2, w17
    // 0xb1d638: b.ne            #0xb1d668
    // 0xb1d63c: LoadField: r2 = r1->field_b
    //     0xb1d63c: ldur            w2, [x1, #0xb]
    // 0xb1d640: DecompressPointer r2
    //     0xb1d640: add             x2, x2, HEAP, lsl #32
    // 0xb1d644: cmp             w2, NULL
    // 0xb1d648: b.ne            #0xb1d660
    // 0xb1d64c: LoadField: r2 = r1->field_1f
    //     0xb1d64c: ldur            w2, [x1, #0x1f]
    // 0xb1d650: DecompressPointer r2
    //     0xb1d650: add             x2, x2, HEAP, lsl #32
    // 0xb1d654: LoadField: r1 = r2->field_b
    //     0xb1d654: ldur            w1, [x2, #0xb]
    // 0xb1d658: DecompressPointer r1
    //     0xb1d658: add             x1, x1, HEAP, lsl #32
    // 0xb1d65c: b               #0xb1d6a4
    // 0xb1d660: mov             x1, x2
    // 0xb1d664: b               #0xb1d6a4
    // 0xb1d668: LoadField: r2 = r1->field_27
    //     0xb1d668: ldur            w2, [x1, #0x27]
    // 0xb1d66c: DecompressPointer r2
    //     0xb1d66c: add             x2, x2, HEAP, lsl #32
    // 0xb1d670: LoadField: r3 = r2->field_b
    //     0xb1d670: ldur            w3, [x2, #0xb]
    // 0xb1d674: DecompressPointer r3
    //     0xb1d674: add             x3, x3, HEAP, lsl #32
    // 0xb1d678: cmp             w3, NULL
    // 0xb1d67c: b.ne            #0xb1d6a0
    // 0xb1d680: LoadField: r2 = r1->field_23
    //     0xb1d680: ldur            w2, [x1, #0x23]
    // 0xb1d684: DecompressPointer r2
    //     0xb1d684: add             x2, x2, HEAP, lsl #32
    // 0xb1d688: LoadField: r1 = r2->field_3f
    //     0xb1d688: ldur            w1, [x2, #0x3f]
    // 0xb1d68c: DecompressPointer r1
    //     0xb1d68c: add             x1, x1, HEAP, lsl #32
    // 0xb1d690: LoadField: r2 = r1->field_b
    //     0xb1d690: ldur            w2, [x1, #0xb]
    // 0xb1d694: DecompressPointer r2
    //     0xb1d694: add             x2, x2, HEAP, lsl #32
    // 0xb1d698: mov             x1, x2
    // 0xb1d69c: b               #0xb1d6a4
    // 0xb1d6a0: mov             x1, x3
    // 0xb1d6a4: stur            x1, [fp, #-8]
    // 0xb1d6a8: r0 = CupertinoIconThemeData()
    //     0xb1d6a8: bl              #0xb1d714  ; AllocateCupertinoIconThemeDataStub -> CupertinoIconThemeData (size=0x28)
    // 0xb1d6ac: mov             x1, x0
    // 0xb1d6b0: ldur            x0, [fp, #-8]
    // 0xb1d6b4: stur            x1, [fp, #-0x10]
    // 0xb1d6b8: StoreField: r1->field_1b = r0
    //     0xb1d6b8: stur            w0, [x1, #0x1b]
    // 0xb1d6bc: ldr             x0, [fp, #0x18]
    // 0xb1d6c0: LoadField: r2 = r0->field_f
    //     0xb1d6c0: ldur            w2, [x0, #0xf]
    // 0xb1d6c4: DecompressPointer r2
    //     0xb1d6c4: add             x2, x2, HEAP, lsl #32
    // 0xb1d6c8: stur            x2, [fp, #-8]
    // 0xb1d6cc: r0 = IconTheme()
    //     0xb1d6cc: bl              #0x83fd30  ; AllocateIconThemeStub -> IconTheme (size=0x14)
    // 0xb1d6d0: mov             x1, x0
    // 0xb1d6d4: ldur            x0, [fp, #-0x10]
    // 0xb1d6d8: stur            x1, [fp, #-0x18]
    // 0xb1d6dc: StoreField: r1->field_f = r0
    //     0xb1d6dc: stur            w0, [x1, #0xf]
    // 0xb1d6e0: ldur            x0, [fp, #-8]
    // 0xb1d6e4: StoreField: r1->field_b = r0
    //     0xb1d6e4: stur            w0, [x1, #0xb]
    // 0xb1d6e8: r0 = _InheritedCupertinoTheme()
    //     0xb1d6e8: bl              #0xb1d708  ; Allocate_InheritedCupertinoThemeStub -> _InheritedCupertinoTheme (size=0x14)
    // 0xb1d6ec: ldr             x1, [fp, #0x18]
    // 0xb1d6f0: StoreField: r0->field_f = r1
    //     0xb1d6f0: stur            w1, [x0, #0xf]
    // 0xb1d6f4: ldur            x1, [fp, #-0x18]
    // 0xb1d6f8: StoreField: r0->field_b = r1
    //     0xb1d6f8: stur            w1, [x0, #0xb]
    // 0xb1d6fc: LeaveFrame
    //     0xb1d6fc: mov             SP, fp
    //     0xb1d700: ldp             fp, lr, [SP], #0x10
    // 0xb1d704: ret
    //     0xb1d704: ret             
  }
}

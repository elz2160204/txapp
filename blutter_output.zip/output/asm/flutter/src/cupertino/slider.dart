// lib: , url: package:flutter/src/cupertino/slider.dart

// class id: 1049105, size: 0x8
class :: {
}

// class id: 2526, size: 0xac, field offset: 0x68
class _RenderCupertinoSlider extends RenderConstrainedBox
    implements MouseTrackerAnnotation {

  late AnimationController _position; // offset: 0x90
  late HorizontalDragGestureRecognizer _drag; // offset: 0x94

  _ hitTestSelf(/* No info */) {
    // ** addr: 0x62b3fc, size: 0xa4
    // 0x62b3fc: EnterFrame
    //     0x62b3fc: stp             fp, lr, [SP, #-0x10]!
    //     0x62b400: mov             fp, SP
    // 0x62b404: AllocStack(0x8)
    //     0x62b404: sub             SP, SP, #8
    // 0x62b408: CheckStackOverflow
    //     0x62b408: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b40c: cmp             SP, x16
    //     0x62b410: b.ls            #0x62b498
    // 0x62b414: ldr             x0, [fp, #0x10]
    // 0x62b418: LoadField: d0 = r0->field_7
    //     0x62b418: ldur            d0, [x0, #7]
    // 0x62b41c: stur            d0, [fp, #-8]
    // 0x62b420: ldr             x16, [fp, #0x18]
    // 0x62b424: SaveReg r16
    //     0x62b424: str             x16, [SP, #-8]!
    // 0x62b428: r0 = _thumbCenter()
    //     0x62b428: bl              #0x62b4a0  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_thumbCenter
    // 0x62b42c: add             SP, SP, #8
    // 0x62b430: mov             v1.16b, v0.16b
    // 0x62b434: ldur            d0, [fp, #-8]
    // 0x62b438: fsub            d2, d0, d1
    // 0x62b43c: d0 = 0.000000
    //     0x62b43c: eor             v0.16b, v0.16b, v0.16b
    // 0x62b440: fcmp            d2, d0
    // 0x62b444: b.vs            #0x62b454
    // 0x62b448: b.ne            #0x62b454
    // 0x62b44c: d1 = 0.000000
    //     0x62b44c: eor             v1.16b, v1.16b, v1.16b
    // 0x62b450: b               #0x62b470
    // 0x62b454: fcmp            d2, d0
    // 0x62b458: b.vs            #0x62b468
    // 0x62b45c: b.ge            #0x62b468
    // 0x62b460: fneg            d0, d2
    // 0x62b464: b               #0x62b46c
    // 0x62b468: mov             v0.16b, v2.16b
    // 0x62b46c: mov             v1.16b, v0.16b
    // 0x62b470: d0 = 22.000000
    //     0x62b470: fmov            d0, #22.00000000
    // 0x62b474: fcmp            d1, d0
    // 0x62b478: b.vs            #0x62b480
    // 0x62b47c: b.lt            #0x62b488
    // 0x62b480: r0 = false
    //     0x62b480: add             x0, NULL, #0x30  ; false
    // 0x62b484: b               #0x62b48c
    // 0x62b488: r0 = true
    //     0x62b488: add             x0, NULL, #0x20  ; true
    // 0x62b48c: LeaveFrame
    //     0x62b48c: mov             SP, fp
    //     0x62b490: ldp             fp, lr, [SP], #0x10
    // 0x62b494: ret
    //     0x62b494: ret             
    // 0x62b498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62b498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62b49c: b               #0x62b414
  }
  get _ _thumbCenter(/* No info */) {
    // ** addr: 0x62b4a0, size: 0x124
    // 0x62b4a0: EnterFrame
    //     0x62b4a0: stp             fp, lr, [SP, #-0x10]!
    //     0x62b4a4: mov             fp, SP
    // 0x62b4a8: CheckStackOverflow
    //     0x62b4a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62b4ac: cmp             SP, x16
    //     0x62b4b0: b.ls            #0x62b588
    // 0x62b4b4: ldr             x0, [fp, #0x10]
    // 0x62b4b8: LoadField: r1 = r0->field_8b
    //     0x62b4b8: ldur            w1, [x0, #0x8b]
    // 0x62b4bc: DecompressPointer r1
    //     0x62b4bc: add             x1, x1, HEAP, lsl #32
    // 0x62b4c0: LoadField: r2 = r1->field_7
    //     0x62b4c0: ldur            x2, [x1, #7]
    // 0x62b4c4: cmp             x2, #0
    // 0x62b4c8: b.gt            #0x62b4dc
    // 0x62b4cc: d0 = 1.000000
    //     0x62b4cc: fmov            d0, #1.00000000
    // 0x62b4d0: LoadField: d1 = r0->field_67
    //     0x62b4d0: ldur            d1, [x0, #0x67]
    // 0x62b4d4: fsub            d2, d0, d1
    // 0x62b4d8: b               #0x62b4e4
    // 0x62b4dc: LoadField: d0 = r0->field_67
    //     0x62b4dc: ldur            d0, [x0, #0x67]
    // 0x62b4e0: mov             v2.16b, v0.16b
    // 0x62b4e4: d1 = 8.000000
    //     0x62b4e4: fmov            d1, #8.00000000
    // 0x62b4e8: d0 = 14.000000
    //     0x62b4e8: fmov            d0, #14.00000000
    // 0x62b4ec: LoadField: r1 = r0->field_57
    //     0x62b4ec: ldur            w1, [x0, #0x57]
    // 0x62b4f0: DecompressPointer r1
    //     0x62b4f0: add             x1, x1, HEAP, lsl #32
    // 0x62b4f4: cmp             w1, NULL
    // 0x62b4f8: b.eq            #0x62b590
    // 0x62b4fc: LoadField: d3 = r1->field_7
    //     0x62b4fc: ldur            d3, [x1, #7]
    // 0x62b500: fsub            d4, d3, d1
    // 0x62b504: fsub            d1, d4, d0
    // 0x62b508: r0 = inline_Allocate_Double()
    //     0x62b508: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62b50c: add             x0, x0, #0x10
    //     0x62b510: cmp             x1, x0
    //     0x62b514: b.ls            #0x62b594
    //     0x62b518: str             x0, [THR, #0x60]  ; THR::top
    //     0x62b51c: sub             x0, x0, #0xf
    //     0x62b520: mov             x1, #0xd108
    //     0x62b524: movk            x1, #3, lsl #16
    //     0x62b528: stur            x1, [x0, #-1]
    // 0x62b52c: StoreField: r0->field_7 = d2
    //     0x62b52c: stur            d2, [x0, #7]
    // 0x62b530: r1 = inline_Allocate_Double()
    //     0x62b530: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x62b534: add             x1, x1, #0x10
    //     0x62b538: cmp             x2, x1
    //     0x62b53c: b.ls            #0x62b5a4
    //     0x62b540: str             x1, [THR, #0x60]  ; THR::top
    //     0x62b544: sub             x1, x1, #0xf
    //     0x62b548: mov             x2, #0xd108
    //     0x62b54c: movk            x2, #3, lsl #16
    //     0x62b550: stur            x2, [x1, #-1]
    // 0x62b554: StoreField: r1->field_7 = d1
    //     0x62b554: stur            d1, [x1, #7]
    // 0x62b558: r16 = 22.000000
    //     0x62b558: add             x16, PP, #0x30, lsl #12  ; [pp+0x30590] 22
    //     0x62b55c: ldr             x16, [x16, #0x590]
    // 0x62b560: stp             x1, x16, [SP, #-0x10]!
    // 0x62b564: SaveReg r0
    //     0x62b564: str             x0, [SP, #-8]!
    // 0x62b568: r0 = lerpDouble()
    //     0x62b568: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x62b56c: add             SP, SP, #0x18
    // 0x62b570: cmp             w0, NULL
    // 0x62b574: b.eq            #0x62b5c0
    // 0x62b578: LoadField: d0 = r0->field_7
    //     0x62b578: ldur            d0, [x0, #7]
    // 0x62b57c: LeaveFrame
    //     0x62b57c: mov             SP, fp
    //     0x62b580: ldp             fp, lr, [SP], #0x10
    // 0x62b584: ret
    //     0x62b584: ret             
    // 0x62b588: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62b588: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62b58c: b               #0x62b4b4
    // 0x62b590: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62b590: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x62b594: stp             q1, q2, [SP, #-0x20]!
    // 0x62b598: r0 = AllocateDouble()
    //     0x62b598: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62b59c: ldp             q1, q2, [SP], #0x20
    // 0x62b5a0: b               #0x62b52c
    // 0x62b5a4: SaveReg d1
    //     0x62b5a4: str             q1, [SP, #-0x10]!
    // 0x62b5a8: SaveReg r0
    //     0x62b5a8: str             x0, [SP, #-8]!
    // 0x62b5ac: r0 = AllocateDouble()
    //     0x62b5ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62b5b0: mov             x1, x0
    // 0x62b5b4: RestoreReg r0
    //     0x62b5b4: ldr             x0, [SP], #8
    // 0x62b5b8: RestoreReg d1
    //     0x62b5b8: ldr             q1, [SP], #0x10
    // 0x62b5bc: b               #0x62b554
    // 0x62b5c0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62b5c0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _trackRight(/* No info */) {
    // ** addr: 0x62b5c4, size: 0x38
    // 0x62b5c4: EnterFrame
    //     0x62b5c4: stp             fp, lr, [SP, #-0x10]!
    //     0x62b5c8: mov             fp, SP
    // 0x62b5cc: d1 = 8.000000
    //     0x62b5cc: fmov            d1, #8.00000000
    // 0x62b5d0: ldr             x0, [fp, #0x10]
    // 0x62b5d4: LoadField: r1 = r0->field_57
    //     0x62b5d4: ldur            w1, [x0, #0x57]
    // 0x62b5d8: DecompressPointer r1
    //     0x62b5d8: add             x1, x1, HEAP, lsl #32
    // 0x62b5dc: cmp             w1, NULL
    // 0x62b5e0: b.eq            #0x62b5f8
    // 0x62b5e4: LoadField: d2 = r1->field_7
    //     0x62b5e4: ldur            d2, [x1, #7]
    // 0x62b5e8: fsub            d0, d2, d1
    // 0x62b5ec: LeaveFrame
    //     0x62b5ec: mov             SP, fp
    //     0x62b5f0: ldp             fp, lr, [SP], #0x10
    // 0x62b5f4: ret
    //     0x62b5f4: ret             
    // 0x62b5f8: r0 = NullCastErrorSharedWithFPURegs()
    //     0x62b5f8: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  _ describeSemanticsConfiguration(/* No info */) {
    // ** addr: 0x64da5c, size: 0x4bc
    // 0x64da5c: EnterFrame
    //     0x64da5c: stp             fp, lr, [SP, #-0x10]!
    //     0x64da60: mov             fp, SP
    // 0x64da64: AllocStack(0x8)
    //     0x64da64: sub             SP, SP, #8
    // 0x64da68: CheckStackOverflow
    //     0x64da68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64da6c: cmp             SP, x16
    //     0x64da70: b.ls            #0x64debc
    // 0x64da74: ldr             x0, [fp, #0x18]
    // 0x64da78: LoadField: r1 = r0->field_7f
    //     0x64da78: ldur            w1, [x0, #0x7f]
    // 0x64da7c: DecompressPointer r1
    //     0x64da7c: add             x1, x1, HEAP, lsl #32
    // 0x64da80: cmp             w1, NULL
    // 0x64da84: r16 = true
    //     0x64da84: add             x16, NULL, #0x20  ; true
    // 0x64da88: r17 = false
    //     0x64da88: add             x17, NULL, #0x30  ; false
    // 0x64da8c: csel            x2, x16, x17, ne
    // 0x64da90: ldr             x1, [fp, #0x10]
    // 0x64da94: StoreField: r1->field_7 = r2
    //     0x64da94: stur            w2, [x1, #7]
    // 0x64da98: r16 = Instance_SemanticsFlag
    //     0x64da98: add             x16, PP, #0x21, lsl #12  ; [pp+0x21c10] Obj!SemanticsFlag@b5cbc1
    //     0x64da9c: ldr             x16, [x16, #0xc10]
    // 0x64daa0: stp             x16, x1, [SP, #-0x10]!
    // 0x64daa4: r16 = true
    //     0x64daa4: add             x16, NULL, #0x20  ; true
    // 0x64daa8: SaveReg r16
    //     0x64daa8: str             x16, [SP, #-8]!
    // 0x64daac: r0 = _setFlag()
    //     0x64daac: bl              #0x646790  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_setFlag
    // 0x64dab0: add             SP, SP, #0x18
    // 0x64dab4: ldr             x1, [fp, #0x18]
    // 0x64dab8: LoadField: r0 = r1->field_7f
    //     0x64dab8: ldur            w0, [x1, #0x7f]
    // 0x64dabc: DecompressPointer r0
    //     0x64dabc: add             x0, x0, HEAP, lsl #32
    // 0x64dac0: cmp             w0, NULL
    // 0x64dac4: b.eq            #0x64deac
    // 0x64dac8: ldr             x2, [fp, #0x10]
    // 0x64dacc: r3 = true
    //     0x64dacc: add             x3, NULL, #0x20  ; true
    // 0x64dad0: LoadField: r0 = r1->field_8b
    //     0x64dad0: ldur            w0, [x1, #0x8b]
    // 0x64dad4: DecompressPointer r0
    //     0x64dad4: add             x0, x0, HEAP, lsl #32
    // 0x64dad8: StoreField: r2->field_73 = r0
    //     0x64dad8: stur            w0, [x2, #0x73]
    //     0x64dadc: ldurb           w16, [x2, #-1]
    //     0x64dae0: ldurb           w17, [x0, #-1]
    //     0x64dae4: and             x16, x17, x16, lsr #2
    //     0x64dae8: tst             x16, HEAP, lsr #32
    //     0x64daec: b.eq            #0x64daf4
    //     0x64daf0: bl              #0xd6828c
    // 0x64daf4: StoreField: r2->field_13 = r3
    //     0x64daf4: stur            w3, [x2, #0x13]
    // 0x64daf8: r1 = 1
    //     0x64daf8: mov             x1, #1
    // 0x64dafc: r0 = AllocateContext()
    //     0x64dafc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64db00: mov             x1, x0
    // 0x64db04: ldr             x0, [fp, #0x18]
    // 0x64db08: StoreField: r1->field_f = r0
    //     0x64db08: stur            w0, [x1, #0xf]
    // 0x64db0c: mov             x2, x1
    // 0x64db10: r1 = Function '_increaseAction@613348729':.
    //     0x64db10: add             x1, PP, #0x57, lsl #12  ; [pp+0x57508] AnonymousClosure: (0x64e190), in [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_increaseAction (0x64e1d8)
    //     0x64db14: ldr             x1, [x1, #0x508]
    // 0x64db18: r0 = AllocateClosure()
    //     0x64db18: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64db1c: ldr             x16, [fp, #0x10]
    // 0x64db20: r30 = Instance_SemanticsAction
    //     0x64db20: add             lr, PP, #0x56, lsl #12  ; [pp+0x560b8] Obj!SemanticsAction@b5cda1
    //     0x64db24: ldr             lr, [lr, #0xb8]
    // 0x64db28: stp             lr, x16, [SP, #-0x10]!
    // 0x64db2c: SaveReg r0
    //     0x64db2c: str             x0, [SP, #-8]!
    // 0x64db30: r0 = _addArgumentlessAction()
    //     0x64db30: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64db34: add             SP, SP, #0x18
    // 0x64db38: r1 = 1
    //     0x64db38: mov             x1, #1
    // 0x64db3c: r0 = AllocateContext()
    //     0x64db3c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x64db40: mov             x1, x0
    // 0x64db44: ldr             x0, [fp, #0x18]
    // 0x64db48: StoreField: r1->field_f = r0
    //     0x64db48: stur            w0, [x1, #0xf]
    // 0x64db4c: mov             x2, x1
    // 0x64db50: r1 = Function '_decreaseAction@613348729':.
    //     0x64db50: add             x1, PP, #0x57, lsl #12  ; [pp+0x57510] AnonymousClosure: (0x64e060), in [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_decreaseAction (0x64e0a8)
    //     0x64db54: ldr             x1, [x1, #0x510]
    // 0x64db58: r0 = AllocateClosure()
    //     0x64db58: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x64db5c: ldr             x16, [fp, #0x10]
    // 0x64db60: r30 = Instance_SemanticsAction
    //     0x64db60: add             lr, PP, #0x56, lsl #12  ; [pp+0x560c8] Obj!SemanticsAction@b5cd91
    //     0x64db64: ldr             lr, [lr, #0xc8]
    // 0x64db68: stp             lr, x16, [SP, #-0x10]!
    // 0x64db6c: SaveReg r0
    //     0x64db6c: str             x0, [SP, #-8]!
    // 0x64db70: r0 = _addArgumentlessAction()
    //     0x64db70: bl              #0x6467e0  ; [package:flutter/src/semantics/semantics.dart] SemanticsConfiguration::_addArgumentlessAction
    // 0x64db74: add             SP, SP, #0x18
    // 0x64db78: ldr             x0, [fp, #0x18]
    // 0x64db7c: LoadField: d0 = r0->field_67
    //     0x64db7c: ldur            d0, [x0, #0x67]
    // 0x64db80: d1 = 100.000000
    //     0x64db80: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x64db84: ldr             d1, [x17, #0x308]
    // 0x64db88: fmul            d2, d0, d1
    // 0x64db8c: mov             v0.16b, v2.16b
    // 0x64db90: stp             fp, lr, [SP, #-0x10]!
    // 0x64db94: mov             fp, SP
    // 0x64db98: CallRuntime_LibcRound(double) -> double
    //     0x64db98: and             SP, SP, #0xfffffffffffffff0
    //     0x64db9c: mov             sp, SP
    //     0x64dba0: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x64dba4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x64dba8: blr             x16
    //     0x64dbac: mov             x16, #8
    //     0x64dbb0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x64dbb4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x64dbb8: sub             sp, x16, #1, lsl #12
    //     0x64dbbc: mov             SP, fp
    //     0x64dbc0: ldp             fp, lr, [SP], #0x10
    // 0x64dbc4: fcmp            d0, d0
    // 0x64dbc8: b.vs            #0x64dec4
    // 0x64dbcc: fcvtzs          x0, d0
    // 0x64dbd0: asr             x16, x0, #0x1e
    // 0x64dbd4: cmp             x16, x0, asr #63
    // 0x64dbd8: b.ne            #0x64dec4
    // 0x64dbdc: lsl             x0, x0, #1
    // 0x64dbe0: stur            x0, [fp, #-8]
    // 0x64dbe4: r1 = Null
    //     0x64dbe4: mov             x1, NULL
    // 0x64dbe8: r2 = 4
    //     0x64dbe8: mov             x2, #4
    // 0x64dbec: r0 = AllocateArray()
    //     0x64dbec: bl              #0xd6987c  ; AllocateArrayStub
    // 0x64dbf0: mov             x1, x0
    // 0x64dbf4: ldur            x0, [fp, #-8]
    // 0x64dbf8: StoreField: r1->field_f = r0
    //     0x64dbf8: stur            w0, [x1, #0xf]
    // 0x64dbfc: r17 = "%"
    //     0x64dbfc: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x64dc00: StoreField: r1->field_13 = r17
    //     0x64dc00: stur            w17, [x1, #0x13]
    // 0x64dc04: SaveReg r1
    //     0x64dc04: str             x1, [SP, #-8]!
    // 0x64dc08: r0 = _interpolate()
    //     0x64dc08: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x64dc0c: add             SP, SP, #8
    // 0x64dc10: stur            x0, [fp, #-8]
    // 0x64dc14: r0 = AttributedString()
    //     0x64dc14: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x64dc18: mov             x1, x0
    // 0x64dc1c: ldur            x0, [fp, #-8]
    // 0x64dc20: StoreField: r1->field_7 = r0
    //     0x64dc20: stur            w0, [x1, #7]
    // 0x64dc24: r2 = const []
    //     0x64dc24: ldr             x2, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x64dc28: StoreField: r1->field_b = r2
    //     0x64dc28: stur            w2, [x1, #0xb]
    // 0x64dc2c: mov             x0, x1
    // 0x64dc30: ldr             x1, [fp, #0x10]
    // 0x64dc34: StoreField: r1->field_4b = r0
    //     0x64dc34: stur            w0, [x1, #0x4b]
    //     0x64dc38: ldurb           w16, [x1, #-1]
    //     0x64dc3c: ldurb           w17, [x0, #-1]
    //     0x64dc40: and             x16, x17, x16, lsr #2
    //     0x64dc44: tst             x16, HEAP, lsr #32
    //     0x64dc48: b.eq            #0x64dc50
    //     0x64dc4c: bl              #0xd6826c
    // 0x64dc50: r0 = true
    //     0x64dc50: add             x0, NULL, #0x20  ; true
    // 0x64dc54: StoreField: r1->field_13 = r0
    //     0x64dc54: stur            w0, [x1, #0x13]
    // 0x64dc58: ldr             x3, [fp, #0x18]
    // 0x64dc5c: LoadField: d0 = r3->field_67
    //     0x64dc5c: ldur            d0, [x3, #0x67]
    // 0x64dc60: d1 = 0.100000
    //     0x64dc60: ldr             d1, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0x64dc64: fadd            d2, d0, d1
    // 0x64dc68: d3 = 0.000000
    //     0x64dc68: eor             v3.16b, v3.16b, v3.16b
    // 0x64dc6c: fcmp            d2, d3
    // 0x64dc70: b.vs            #0x64dc84
    // 0x64dc74: b.ge            #0x64dc84
    // 0x64dc78: d0 = 0.000000
    //     0x64dc78: eor             v0.16b, v0.16b, v0.16b
    // 0x64dc7c: d4 = 1.000000
    //     0x64dc7c: fmov            d4, #1.00000000
    // 0x64dc80: b               #0x64dcb0
    // 0x64dc84: d4 = 1.000000
    //     0x64dc84: fmov            d4, #1.00000000
    // 0x64dc88: fcmp            d2, d4
    // 0x64dc8c: b.vs            #0x64dc9c
    // 0x64dc90: b.le            #0x64dc9c
    // 0x64dc94: d0 = 1.000000
    //     0x64dc94: fmov            d0, #1.00000000
    // 0x64dc98: b               #0x64dcb0
    // 0x64dc9c: fcmp            d2, d2
    // 0x64dca0: b.vc            #0x64dcac
    // 0x64dca4: d0 = 1.000000
    //     0x64dca4: fmov            d0, #1.00000000
    // 0x64dca8: b               #0x64dcb0
    // 0x64dcac: mov             v0.16b, v2.16b
    // 0x64dcb0: d2 = 100.000000
    //     0x64dcb0: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x64dcb4: ldr             d2, [x17, #0x308]
    // 0x64dcb8: fmul            d5, d0, d2
    // 0x64dcbc: mov             v0.16b, v5.16b
    // 0x64dcc0: stp             fp, lr, [SP, #-0x10]!
    // 0x64dcc4: mov             fp, SP
    // 0x64dcc8: CallRuntime_LibcRound(double) -> double
    //     0x64dcc8: and             SP, SP, #0xfffffffffffffff0
    //     0x64dccc: mov             sp, SP
    //     0x64dcd0: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x64dcd4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x64dcd8: blr             x16
    //     0x64dcdc: mov             x16, #8
    //     0x64dce0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x64dce4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x64dce8: sub             sp, x16, #1, lsl #12
    //     0x64dcec: mov             SP, fp
    //     0x64dcf0: ldp             fp, lr, [SP], #0x10
    // 0x64dcf4: fcmp            d0, d0
    // 0x64dcf8: b.vs            #0x64dee0
    // 0x64dcfc: fcvtzs          x0, d0
    // 0x64dd00: asr             x16, x0, #0x1e
    // 0x64dd04: cmp             x16, x0, asr #63
    // 0x64dd08: b.ne            #0x64dee0
    // 0x64dd0c: lsl             x0, x0, #1
    // 0x64dd10: stur            x0, [fp, #-8]
    // 0x64dd14: r1 = Null
    //     0x64dd14: mov             x1, NULL
    // 0x64dd18: r2 = 4
    //     0x64dd18: mov             x2, #4
    // 0x64dd1c: r0 = AllocateArray()
    //     0x64dd1c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x64dd20: mov             x1, x0
    // 0x64dd24: ldur            x0, [fp, #-8]
    // 0x64dd28: StoreField: r1->field_f = r0
    //     0x64dd28: stur            w0, [x1, #0xf]
    // 0x64dd2c: r17 = "%"
    //     0x64dd2c: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x64dd30: StoreField: r1->field_13 = r17
    //     0x64dd30: stur            w17, [x1, #0x13]
    // 0x64dd34: SaveReg r1
    //     0x64dd34: str             x1, [SP, #-8]!
    // 0x64dd38: r0 = _interpolate()
    //     0x64dd38: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x64dd3c: add             SP, SP, #8
    // 0x64dd40: stur            x0, [fp, #-8]
    // 0x64dd44: r0 = AttributedString()
    //     0x64dd44: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x64dd48: mov             x1, x0
    // 0x64dd4c: ldur            x0, [fp, #-8]
    // 0x64dd50: StoreField: r1->field_7 = r0
    //     0x64dd50: stur            w0, [x1, #7]
    // 0x64dd54: r2 = const []
    //     0x64dd54: ldr             x2, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x64dd58: StoreField: r1->field_b = r2
    //     0x64dd58: stur            w2, [x1, #0xb]
    // 0x64dd5c: mov             x0, x1
    // 0x64dd60: ldr             x1, [fp, #0x10]
    // 0x64dd64: StoreField: r1->field_4f = r0
    //     0x64dd64: stur            w0, [x1, #0x4f]
    //     0x64dd68: ldurb           w16, [x1, #-1]
    //     0x64dd6c: ldurb           w17, [x0, #-1]
    //     0x64dd70: and             x16, x17, x16, lsr #2
    //     0x64dd74: tst             x16, HEAP, lsr #32
    //     0x64dd78: b.eq            #0x64dd80
    //     0x64dd7c: bl              #0xd6826c
    // 0x64dd80: r0 = true
    //     0x64dd80: add             x0, NULL, #0x20  ; true
    // 0x64dd84: StoreField: r1->field_13 = r0
    //     0x64dd84: stur            w0, [x1, #0x13]
    // 0x64dd88: ldr             x3, [fp, #0x18]
    // 0x64dd8c: LoadField: d0 = r3->field_67
    //     0x64dd8c: ldur            d0, [x3, #0x67]
    // 0x64dd90: d1 = 0.100000
    //     0x64dd90: ldr             d1, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0x64dd94: fsub            d2, d0, d1
    // 0x64dd98: d0 = 0.000000
    //     0x64dd98: eor             v0.16b, v0.16b, v0.16b
    // 0x64dd9c: fcmp            d2, d0
    // 0x64dda0: b.vs            #0x64ddb0
    // 0x64dda4: b.ge            #0x64ddb0
    // 0x64dda8: d1 = 0.000000
    //     0x64dda8: eor             v1.16b, v1.16b, v1.16b
    // 0x64ddac: b               #0x64dddc
    // 0x64ddb0: d0 = 1.000000
    //     0x64ddb0: fmov            d0, #1.00000000
    // 0x64ddb4: fcmp            d2, d0
    // 0x64ddb8: b.vs            #0x64ddc8
    // 0x64ddbc: b.le            #0x64ddc8
    // 0x64ddc0: d1 = 1.000000
    //     0x64ddc0: fmov            d1, #1.00000000
    // 0x64ddc4: b               #0x64dddc
    // 0x64ddc8: fcmp            d2, d2
    // 0x64ddcc: b.vc            #0x64ddd8
    // 0x64ddd0: d1 = 1.000000
    //     0x64ddd0: fmov            d1, #1.00000000
    // 0x64ddd4: b               #0x64dddc
    // 0x64ddd8: mov             v1.16b, v2.16b
    // 0x64dddc: d0 = 100.000000
    //     0x64dddc: add             x17, PP, #0x15, lsl #12  ; [pp+0x15308] IMM: double(100) from 0x4059000000000000
    //     0x64dde0: ldr             d0, [x17, #0x308]
    // 0x64dde4: fmul            d2, d1, d0
    // 0x64dde8: mov             v0.16b, v2.16b
    // 0x64ddec: stp             fp, lr, [SP, #-0x10]!
    // 0x64ddf0: mov             fp, SP
    // 0x64ddf4: CallRuntime_LibcRound(double) -> double
    //     0x64ddf4: and             SP, SP, #0xfffffffffffffff0
    //     0x64ddf8: mov             sp, SP
    //     0x64ddfc: ldr             x16, [THR, #0x578]  ; THR::LibcRound
    //     0x64de00: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x64de04: blr             x16
    //     0x64de08: mov             x16, #8
    //     0x64de0c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x64de10: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x64de14: sub             sp, x16, #1, lsl #12
    //     0x64de18: mov             SP, fp
    //     0x64de1c: ldp             fp, lr, [SP], #0x10
    // 0x64de20: fcmp            d0, d0
    // 0x64de24: b.vs            #0x64defc
    // 0x64de28: fcvtzs          x0, d0
    // 0x64de2c: asr             x16, x0, #0x1e
    // 0x64de30: cmp             x16, x0, asr #63
    // 0x64de34: b.ne            #0x64defc
    // 0x64de38: lsl             x0, x0, #1
    // 0x64de3c: stur            x0, [fp, #-8]
    // 0x64de40: r1 = Null
    //     0x64de40: mov             x1, NULL
    // 0x64de44: r2 = 4
    //     0x64de44: mov             x2, #4
    // 0x64de48: r0 = AllocateArray()
    //     0x64de48: bl              #0xd6987c  ; AllocateArrayStub
    // 0x64de4c: mov             x1, x0
    // 0x64de50: ldur            x0, [fp, #-8]
    // 0x64de54: StoreField: r1->field_f = r0
    //     0x64de54: stur            w0, [x1, #0xf]
    // 0x64de58: r17 = "%"
    //     0x64de58: ldr             x17, [PP, #0x12b8]  ; [pp+0x12b8] "%"
    // 0x64de5c: StoreField: r1->field_13 = r17
    //     0x64de5c: stur            w17, [x1, #0x13]
    // 0x64de60: SaveReg r1
    //     0x64de60: str             x1, [SP, #-8]!
    // 0x64de64: r0 = _interpolate()
    //     0x64de64: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x64de68: add             SP, SP, #8
    // 0x64de6c: stur            x0, [fp, #-8]
    // 0x64de70: r0 = AttributedString()
    //     0x64de70: bl              #0x50ffbc  ; AllocateAttributedStringStub -> AttributedString (size=0x10)
    // 0x64de74: ldur            x1, [fp, #-8]
    // 0x64de78: StoreField: r0->field_7 = r1
    //     0x64de78: stur            w1, [x0, #7]
    // 0x64de7c: r1 = const []
    //     0x64de7c: ldr             x1, [PP, #0x4888]  ; [pp+0x4888] List<StringAttribute>(0)
    // 0x64de80: StoreField: r0->field_b = r1
    //     0x64de80: stur            w1, [x0, #0xb]
    // 0x64de84: ldr             x1, [fp, #0x10]
    // 0x64de88: StoreField: r1->field_53 = r0
    //     0x64de88: stur            w0, [x1, #0x53]
    //     0x64de8c: ldurb           w16, [x1, #-1]
    //     0x64de90: ldurb           w17, [x0, #-1]
    //     0x64de94: and             x16, x17, x16, lsr #2
    //     0x64de98: tst             x16, HEAP, lsr #32
    //     0x64de9c: b.eq            #0x64dea4
    //     0x64dea0: bl              #0xd6826c
    // 0x64dea4: r2 = true
    //     0x64dea4: add             x2, NULL, #0x20  ; true
    // 0x64dea8: StoreField: r1->field_13 = r2
    //     0x64dea8: stur            w2, [x1, #0x13]
    // 0x64deac: r0 = Null
    //     0x64deac: mov             x0, NULL
    // 0x64deb0: LeaveFrame
    //     0x64deb0: mov             SP, fp
    //     0x64deb4: ldp             fp, lr, [SP], #0x10
    // 0x64deb8: ret
    //     0x64deb8: ret             
    // 0x64debc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64debc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64dec0: b               #0x64da74
    // 0x64dec4: SaveReg d0
    //     0x64dec4: str             q0, [SP, #-0x10]!
    // 0x64dec8: r0 = 218
    //     0x64dec8: mov             x0, #0xda
    // 0x64decc: r24 = DoubleToIntegerStub
    //     0x64decc: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x64ded0: LoadField: r30 = r24->field_7
    //     0x64ded0: ldur            lr, [x24, #7]
    // 0x64ded4: blr             lr
    // 0x64ded8: RestoreReg d0
    //     0x64ded8: ldr             q0, [SP], #0x10
    // 0x64dedc: b               #0x64dbe0
    // 0x64dee0: SaveReg d0
    //     0x64dee0: str             q0, [SP, #-0x10]!
    // 0x64dee4: r0 = 218
    //     0x64dee4: mov             x0, #0xda
    // 0x64dee8: r24 = DoubleToIntegerStub
    //     0x64dee8: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x64deec: LoadField: r30 = r24->field_7
    //     0x64deec: ldur            lr, [x24, #7]
    // 0x64def0: blr             lr
    // 0x64def4: RestoreReg d0
    //     0x64def4: ldr             q0, [SP], #0x10
    // 0x64def8: b               #0x64dd10
    // 0x64defc: SaveReg d0
    //     0x64defc: str             q0, [SP, #-0x10]!
    // 0x64df00: r0 = 218
    //     0x64df00: mov             x0, #0xda
    // 0x64df04: r24 = DoubleToIntegerStub
    //     0x64df04: ldr             x24, [PP, #0x37e0]  ; [pp+0x37e0] Stub: DoubleToInteger (0x4ad5cc)
    // 0x64df08: LoadField: r30 = r24->field_7
    //     0x64df08: ldur            lr, [x24, #7]
    // 0x64df0c: blr             lr
    // 0x64df10: RestoreReg d0
    //     0x64df10: ldr             q0, [SP], #0x10
    // 0x64df14: b               #0x64de3c
  }
  [closure] void _decreaseAction(dynamic) {
    // ** addr: 0x64e060, size: 0x48
    // 0x64e060: EnterFrame
    //     0x64e060: stp             fp, lr, [SP, #-0x10]!
    //     0x64e064: mov             fp, SP
    // 0x64e068: ldr             x0, [fp, #0x10]
    // 0x64e06c: LoadField: r1 = r0->field_17
    //     0x64e06c: ldur            w1, [x0, #0x17]
    // 0x64e070: DecompressPointer r1
    //     0x64e070: add             x1, x1, HEAP, lsl #32
    // 0x64e074: CheckStackOverflow
    //     0x64e074: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e078: cmp             SP, x16
    //     0x64e07c: b.ls            #0x64e0a0
    // 0x64e080: LoadField: r0 = r1->field_f
    //     0x64e080: ldur            w0, [x1, #0xf]
    // 0x64e084: DecompressPointer r0
    //     0x64e084: add             x0, x0, HEAP, lsl #32
    // 0x64e088: SaveReg r0
    //     0x64e088: str             x0, [SP, #-8]!
    // 0x64e08c: r0 = _decreaseAction()
    //     0x64e08c: bl              #0x64e0a8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_decreaseAction
    // 0x64e090: add             SP, SP, #8
    // 0x64e094: LeaveFrame
    //     0x64e094: mov             SP, fp
    //     0x64e098: ldp             fp, lr, [SP], #0x10
    // 0x64e09c: ret
    //     0x64e09c: ret             
    // 0x64e0a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e0a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e0a4: b               #0x64e080
  }
  _ _decreaseAction(/* No info */) {
    // ** addr: 0x64e0a8, size: 0xe8
    // 0x64e0a8: EnterFrame
    //     0x64e0a8: stp             fp, lr, [SP, #-0x10]!
    //     0x64e0ac: mov             fp, SP
    // 0x64e0b0: CheckStackOverflow
    //     0x64e0b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e0b4: cmp             SP, x16
    //     0x64e0b8: b.ls            #0x64e170
    // 0x64e0bc: ldr             x0, [fp, #0x10]
    // 0x64e0c0: LoadField: r1 = r0->field_7f
    //     0x64e0c0: ldur            w1, [x0, #0x7f]
    // 0x64e0c4: DecompressPointer r1
    //     0x64e0c4: add             x1, x1, HEAP, lsl #32
    // 0x64e0c8: cmp             w1, NULL
    // 0x64e0cc: b.eq            #0x64e160
    // 0x64e0d0: d1 = 0.100000
    //     0x64e0d0: ldr             d1, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0x64e0d4: d0 = 0.000000
    //     0x64e0d4: eor             v0.16b, v0.16b, v0.16b
    // 0x64e0d8: LoadField: d2 = r0->field_67
    //     0x64e0d8: ldur            d2, [x0, #0x67]
    // 0x64e0dc: fsub            d3, d2, d1
    // 0x64e0e0: fcmp            d3, d0
    // 0x64e0e4: b.vs            #0x64e0f4
    // 0x64e0e8: b.ge            #0x64e0f4
    // 0x64e0ec: d0 = 0.000000
    //     0x64e0ec: eor             v0.16b, v0.16b, v0.16b
    // 0x64e0f0: b               #0x64e120
    // 0x64e0f4: d0 = 1.000000
    //     0x64e0f4: fmov            d0, #1.00000000
    // 0x64e0f8: fcmp            d3, d0
    // 0x64e0fc: b.vs            #0x64e10c
    // 0x64e100: b.le            #0x64e10c
    // 0x64e104: d0 = 1.000000
    //     0x64e104: fmov            d0, #1.00000000
    // 0x64e108: b               #0x64e120
    // 0x64e10c: fcmp            d3, d3
    // 0x64e110: b.vc            #0x64e11c
    // 0x64e114: d0 = 1.000000
    //     0x64e114: fmov            d0, #1.00000000
    // 0x64e118: b               #0x64e120
    // 0x64e11c: mov             v0.16b, v3.16b
    // 0x64e120: r0 = inline_Allocate_Double()
    //     0x64e120: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64e124: add             x0, x0, #0x10
    //     0x64e128: cmp             x2, x0
    //     0x64e12c: b.ls            #0x64e178
    //     0x64e130: str             x0, [THR, #0x60]  ; THR::top
    //     0x64e134: sub             x0, x0, #0xf
    //     0x64e138: mov             x2, #0xd108
    //     0x64e13c: movk            x2, #3, lsl #16
    //     0x64e140: stur            x2, [x0, #-1]
    // 0x64e144: StoreField: r0->field_7 = d0
    //     0x64e144: stur            d0, [x0, #7]
    // 0x64e148: stp             x0, x1, [SP, #-0x10]!
    // 0x64e14c: mov             x0, x1
    // 0x64e150: ClosureCall
    //     0x64e150: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x64e154: ldur            x2, [x0, #0x1f]
    //     0x64e158: blr             x2
    // 0x64e15c: add             SP, SP, #0x10
    // 0x64e160: r0 = Null
    //     0x64e160: mov             x0, NULL
    // 0x64e164: LeaveFrame
    //     0x64e164: mov             SP, fp
    //     0x64e168: ldp             fp, lr, [SP], #0x10
    // 0x64e16c: ret
    //     0x64e16c: ret             
    // 0x64e170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e170: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e174: b               #0x64e0bc
    // 0x64e178: SaveReg d0
    //     0x64e178: str             q0, [SP, #-0x10]!
    // 0x64e17c: SaveReg r1
    //     0x64e17c: str             x1, [SP, #-8]!
    // 0x64e180: r0 = AllocateDouble()
    //     0x64e180: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64e184: RestoreReg r1
    //     0x64e184: ldr             x1, [SP], #8
    // 0x64e188: RestoreReg d0
    //     0x64e188: ldr             q0, [SP], #0x10
    // 0x64e18c: b               #0x64e144
  }
  [closure] void _increaseAction(dynamic) {
    // ** addr: 0x64e190, size: 0x48
    // 0x64e190: EnterFrame
    //     0x64e190: stp             fp, lr, [SP, #-0x10]!
    //     0x64e194: mov             fp, SP
    // 0x64e198: ldr             x0, [fp, #0x10]
    // 0x64e19c: LoadField: r1 = r0->field_17
    //     0x64e19c: ldur            w1, [x0, #0x17]
    // 0x64e1a0: DecompressPointer r1
    //     0x64e1a0: add             x1, x1, HEAP, lsl #32
    // 0x64e1a4: CheckStackOverflow
    //     0x64e1a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e1a8: cmp             SP, x16
    //     0x64e1ac: b.ls            #0x64e1d0
    // 0x64e1b0: LoadField: r0 = r1->field_f
    //     0x64e1b0: ldur            w0, [x1, #0xf]
    // 0x64e1b4: DecompressPointer r0
    //     0x64e1b4: add             x0, x0, HEAP, lsl #32
    // 0x64e1b8: SaveReg r0
    //     0x64e1b8: str             x0, [SP, #-8]!
    // 0x64e1bc: r0 = _increaseAction()
    //     0x64e1bc: bl              #0x64e1d8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_increaseAction
    // 0x64e1c0: add             SP, SP, #8
    // 0x64e1c4: LeaveFrame
    //     0x64e1c4: mov             SP, fp
    //     0x64e1c8: ldp             fp, lr, [SP], #0x10
    // 0x64e1cc: ret
    //     0x64e1cc: ret             
    // 0x64e1d0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e1d0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e1d4: b               #0x64e1b0
  }
  _ _increaseAction(/* No info */) {
    // ** addr: 0x64e1d8, size: 0xe8
    // 0x64e1d8: EnterFrame
    //     0x64e1d8: stp             fp, lr, [SP, #-0x10]!
    //     0x64e1dc: mov             fp, SP
    // 0x64e1e0: CheckStackOverflow
    //     0x64e1e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x64e1e4: cmp             SP, x16
    //     0x64e1e8: b.ls            #0x64e2a0
    // 0x64e1ec: ldr             x0, [fp, #0x10]
    // 0x64e1f0: LoadField: r1 = r0->field_7f
    //     0x64e1f0: ldur            w1, [x0, #0x7f]
    // 0x64e1f4: DecompressPointer r1
    //     0x64e1f4: add             x1, x1, HEAP, lsl #32
    // 0x64e1f8: cmp             w1, NULL
    // 0x64e1fc: b.eq            #0x64e290
    // 0x64e200: d1 = 0.100000
    //     0x64e200: ldr             d1, [PP, #0x4750]  ; [pp+0x4750] IMM: double(0.1) from 0x3fb999999999999a
    // 0x64e204: d0 = 0.000000
    //     0x64e204: eor             v0.16b, v0.16b, v0.16b
    // 0x64e208: LoadField: d2 = r0->field_67
    //     0x64e208: ldur            d2, [x0, #0x67]
    // 0x64e20c: fadd            d3, d2, d1
    // 0x64e210: fcmp            d3, d0
    // 0x64e214: b.vs            #0x64e224
    // 0x64e218: b.ge            #0x64e224
    // 0x64e21c: d0 = 0.000000
    //     0x64e21c: eor             v0.16b, v0.16b, v0.16b
    // 0x64e220: b               #0x64e250
    // 0x64e224: d0 = 1.000000
    //     0x64e224: fmov            d0, #1.00000000
    // 0x64e228: fcmp            d3, d0
    // 0x64e22c: b.vs            #0x64e23c
    // 0x64e230: b.le            #0x64e23c
    // 0x64e234: d0 = 1.000000
    //     0x64e234: fmov            d0, #1.00000000
    // 0x64e238: b               #0x64e250
    // 0x64e23c: fcmp            d3, d3
    // 0x64e240: b.vc            #0x64e24c
    // 0x64e244: d0 = 1.000000
    //     0x64e244: fmov            d0, #1.00000000
    // 0x64e248: b               #0x64e250
    // 0x64e24c: mov             v0.16b, v3.16b
    // 0x64e250: r0 = inline_Allocate_Double()
    //     0x64e250: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x64e254: add             x0, x0, #0x10
    //     0x64e258: cmp             x2, x0
    //     0x64e25c: b.ls            #0x64e2a8
    //     0x64e260: str             x0, [THR, #0x60]  ; THR::top
    //     0x64e264: sub             x0, x0, #0xf
    //     0x64e268: mov             x2, #0xd108
    //     0x64e26c: movk            x2, #3, lsl #16
    //     0x64e270: stur            x2, [x0, #-1]
    // 0x64e274: StoreField: r0->field_7 = d0
    //     0x64e274: stur            d0, [x0, #7]
    // 0x64e278: stp             x0, x1, [SP, #-0x10]!
    // 0x64e27c: mov             x0, x1
    // 0x64e280: ClosureCall
    //     0x64e280: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x64e284: ldur            x2, [x0, #0x1f]
    //     0x64e288: blr             x2
    // 0x64e28c: add             SP, SP, #0x10
    // 0x64e290: r0 = Null
    //     0x64e290: mov             x0, NULL
    // 0x64e294: LeaveFrame
    //     0x64e294: mov             SP, fp
    //     0x64e298: ldp             fp, lr, [SP], #0x10
    // 0x64e29c: ret
    //     0x64e29c: ret             
    // 0x64e2a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x64e2a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x64e2a4: b               #0x64e1ec
    // 0x64e2a8: SaveReg d0
    //     0x64e2a8: str             q0, [SP, #-0x10]!
    // 0x64e2ac: SaveReg r1
    //     0x64e2ac: str             x1, [SP, #-8]!
    // 0x64e2b0: r0 = AllocateDouble()
    //     0x64e2b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x64e2b4: RestoreReg r1
    //     0x64e2b4: ldr             x1, [SP], #8
    // 0x64e2b8: RestoreReg d0
    //     0x64e2b8: ldr             q0, [SP], #0x10
    // 0x64e2bc: b               #0x64e274
  }
  _ paint(/* No info */) {
    // ** addr: 0x65ef50, size: 0x430
    // 0x65ef50: EnterFrame
    //     0x65ef50: stp             fp, lr, [SP, #-0x10]!
    //     0x65ef54: mov             fp, SP
    // 0x65ef58: AllocStack(0x68)
    //     0x65ef58: sub             SP, SP, #0x68
    // 0x65ef5c: CheckStackOverflow
    //     0x65ef5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65ef60: cmp             SP, x16
    //     0x65ef64: b.ls            #0x65f344
    // 0x65ef68: ldr             x0, [fp, #0x20]
    // 0x65ef6c: LoadField: r1 = r0->field_8b
    //     0x65ef6c: ldur            w1, [x0, #0x8b]
    // 0x65ef70: DecompressPointer r1
    //     0x65ef70: add             x1, x1, HEAP, lsl #32
    // 0x65ef74: LoadField: r2 = r1->field_7
    //     0x65ef74: ldur            x2, [x1, #7]
    // 0x65ef78: cmp             x2, #0
    // 0x65ef7c: b.gt            #0x65efd0
    // 0x65ef80: d0 = 1.000000
    //     0x65ef80: fmov            d0, #1.00000000
    // 0x65ef84: LoadField: r1 = r0->field_8f
    //     0x65ef84: ldur            w1, [x0, #0x8f]
    // 0x65ef88: DecompressPointer r1
    //     0x65ef88: add             x1, x1, HEAP, lsl #32
    // 0x65ef8c: r16 = Sentinel
    //     0x65ef8c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65ef90: cmp             w1, w16
    // 0x65ef94: b.eq            #0x65f34c
    // 0x65ef98: LoadField: r2 = r1->field_37
    //     0x65ef98: ldur            w2, [x1, #0x37]
    // 0x65ef9c: DecompressPointer r2
    //     0x65ef9c: add             x2, x2, HEAP, lsl #32
    // 0x65efa0: r16 = Sentinel
    //     0x65efa0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65efa4: cmp             w2, w16
    // 0x65efa8: b.eq            #0x65f358
    // 0x65efac: LoadField: d1 = r2->field_7
    //     0x65efac: ldur            d1, [x2, #7]
    // 0x65efb0: fsub            d2, d0, d1
    // 0x65efb4: LoadField: r1 = r0->field_73
    //     0x65efb4: ldur            w1, [x0, #0x73]
    // 0x65efb8: DecompressPointer r1
    //     0x65efb8: add             x1, x1, HEAP, lsl #32
    // 0x65efbc: LoadField: r2 = r0->field_7b
    //     0x65efbc: ldur            w2, [x0, #0x7b]
    // 0x65efc0: DecompressPointer r2
    //     0x65efc0: add             x2, x2, HEAP, lsl #32
    // 0x65efc4: mov             v3.16b, v2.16b
    // 0x65efc8: mov             x3, x1
    // 0x65efcc: b               #0x65f01c
    // 0x65efd0: d0 = 1.000000
    //     0x65efd0: fmov            d0, #1.00000000
    // 0x65efd4: LoadField: r1 = r0->field_8f
    //     0x65efd4: ldur            w1, [x0, #0x8f]
    // 0x65efd8: DecompressPointer r1
    //     0x65efd8: add             x1, x1, HEAP, lsl #32
    // 0x65efdc: r16 = Sentinel
    //     0x65efdc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65efe0: cmp             w1, w16
    // 0x65efe4: b.eq            #0x65f364
    // 0x65efe8: LoadField: r2 = r1->field_37
    //     0x65efe8: ldur            w2, [x1, #0x37]
    // 0x65efec: DecompressPointer r2
    //     0x65efec: add             x2, x2, HEAP, lsl #32
    // 0x65eff0: r16 = Sentinel
    //     0x65eff0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65eff4: cmp             w2, w16
    // 0x65eff8: b.eq            #0x65f370
    // 0x65effc: LoadField: r1 = r0->field_7b
    //     0x65effc: ldur            w1, [x0, #0x7b]
    // 0x65f000: DecompressPointer r1
    //     0x65f000: add             x1, x1, HEAP, lsl #32
    // 0x65f004: LoadField: r3 = r0->field_73
    //     0x65f004: ldur            w3, [x0, #0x73]
    // 0x65f008: DecompressPointer r3
    //     0x65f008: add             x3, x3, HEAP, lsl #32
    // 0x65f00c: LoadField: d1 = r2->field_7
    //     0x65f00c: ldur            d1, [x2, #7]
    // 0x65f010: mov             v3.16b, v1.16b
    // 0x65f014: mov             x2, x3
    // 0x65f018: mov             x3, x1
    // 0x65f01c: ldr             x1, [fp, #0x10]
    // 0x65f020: d2 = 2.000000
    //     0x65f020: fmov            d2, #2.00000000
    // 0x65f024: d1 = 8.000000
    //     0x65f024: fmov            d1, #8.00000000
    // 0x65f028: stur            x3, [fp, #-8]
    // 0x65f02c: stur            x2, [fp, #-0x10]
    // 0x65f030: stur            d3, [fp, #-0x58]
    // 0x65f034: LoadField: d4 = r1->field_f
    //     0x65f034: ldur            d4, [x1, #0xf]
    // 0x65f038: LoadField: r4 = r0->field_57
    //     0x65f038: ldur            w4, [x0, #0x57]
    // 0x65f03c: DecompressPointer r4
    //     0x65f03c: add             x4, x4, HEAP, lsl #32
    // 0x65f040: cmp             w4, NULL
    // 0x65f044: b.eq            #0x65f37c
    // 0x65f048: LoadField: d5 = r4->field_f
    //     0x65f048: ldur            d5, [x4, #0xf]
    // 0x65f04c: fdiv            d6, d5, d2
    // 0x65f050: fadd            d2, d4, d6
    // 0x65f054: stur            d2, [fp, #-0x50]
    // 0x65f058: LoadField: d4 = r1->field_7
    //     0x65f058: ldur            d4, [x1, #7]
    // 0x65f05c: stur            d4, [fp, #-0x48]
    // 0x65f060: fadd            d5, d4, d1
    // 0x65f064: stur            d5, [fp, #-0x40]
    // 0x65f068: fsub            d1, d2, d0
    // 0x65f06c: stur            d1, [fp, #-0x38]
    // 0x65f070: fadd            d6, d2, d0
    // 0x65f074: stur            d6, [fp, #-0x30]
    // 0x65f078: SaveReg r0
    //     0x65f078: str             x0, [SP, #-8]!
    // 0x65f07c: r0 = _trackRight()
    //     0x65f07c: bl              #0x62b5c4  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_trackRight
    // 0x65f080: add             SP, SP, #8
    // 0x65f084: mov             v1.16b, v0.16b
    // 0x65f088: ldur            d0, [fp, #-0x48]
    // 0x65f08c: fadd            d2, d0, d1
    // 0x65f090: stur            d2, [fp, #-0x60]
    // 0x65f094: ldr             x16, [fp, #0x20]
    // 0x65f098: SaveReg r16
    //     0x65f098: str             x16, [SP, #-8]!
    // 0x65f09c: r0 = _thumbCenter()
    //     0x65f09c: bl              #0x62b4a0  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_thumbCenter
    // 0x65f0a0: add             SP, SP, #8
    // 0x65f0a4: mov             v1.16b, v0.16b
    // 0x65f0a8: ldur            d0, [fp, #-0x48]
    // 0x65f0ac: fadd            d2, d0, d1
    // 0x65f0b0: stur            d2, [fp, #-0x68]
    // 0x65f0b4: ldr             x16, [fp, #0x18]
    // 0x65f0b8: SaveReg r16
    //     0x65f0b8: str             x16, [SP, #-8]!
    // 0x65f0bc: r0 = canvas()
    //     0x65f0bc: bl              #0x65aee4  ; [package:flutter/src/rendering/object.dart] PaintingContext::canvas
    // 0x65f0c0: add             SP, SP, #8
    // 0x65f0c4: ldur            d1, [fp, #-0x58]
    // 0x65f0c8: d0 = 0.000000
    //     0x65f0c8: eor             v0.16b, v0.16b, v0.16b
    // 0x65f0cc: stur            x0, [fp, #-0x18]
    // 0x65f0d0: fcmp            d1, d0
    // 0x65f0d4: b.vs            #0x65f1b8
    // 0x65f0d8: b.le            #0x65f1b8
    // 0x65f0dc: ldur            x1, [fp, #-0x10]
    // 0x65f0e0: ldur            d2, [fp, #-0x40]
    // 0x65f0e4: ldur            d3, [fp, #-0x38]
    // 0x65f0e8: ldur            d4, [fp, #-0x30]
    // 0x65f0ec: ldur            d0, [fp, #-0x68]
    // 0x65f0f0: r16 = 112
    //     0x65f0f0: mov             x16, #0x70
    // 0x65f0f4: stp             x16, NULL, [SP, #-0x10]!
    // 0x65f0f8: r0 = ByteData()
    //     0x65f0f8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65f0fc: add             SP, SP, #0x10
    // 0x65f100: stur            x0, [fp, #-0x20]
    // 0x65f104: r0 = Paint()
    //     0x65f104: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65f108: mov             x2, x0
    // 0x65f10c: ldur            x1, [fp, #-0x20]
    // 0x65f110: stur            x2, [fp, #-0x28]
    // 0x65f114: StoreField: r2->field_7 = r1
    //     0x65f114: stur            w1, [x2, #7]
    // 0x65f118: ldur            x0, [fp, #-0x10]
    // 0x65f11c: r3 = LoadClassIdInstr(r0)
    //     0x65f11c: ldur            x3, [x0, #-1]
    //     0x65f120: ubfx            x3, x3, #0xc, #0x14
    // 0x65f124: SaveReg r0
    //     0x65f124: str             x0, [SP, #-8]!
    // 0x65f128: mov             x0, x3
    // 0x65f12c: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x65f12c: sub             lr, x0, #0xf7e
    //     0x65f130: ldr             lr, [x21, lr, lsl #3]
    //     0x65f134: blr             lr
    // 0x65f138: add             SP, SP, #8
    // 0x65f13c: eor             x1, x0, #0xff000000
    // 0x65f140: ldur            x0, [fp, #-0x20]
    // 0x65f144: LoadField: r2 = r0->field_17
    //     0x65f144: ldur            w2, [x0, #0x17]
    // 0x65f148: DecompressPointer r2
    //     0x65f148: add             x2, x2, HEAP, lsl #32
    // 0x65f14c: sxtw            x1, w1
    // 0x65f150: LoadField: r0 = r2->field_7
    //     0x65f150: ldur            x0, [x2, #7]
    // 0x65f154: str             w1, [x0, #4]
    // 0x65f158: r0 = RRect()
    //     0x65f158: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x65f15c: ldur            d0, [fp, #-0x40]
    // 0x65f160: StoreField: r0->field_7 = d0
    //     0x65f160: stur            d0, [x0, #7]
    // 0x65f164: ldur            d0, [fp, #-0x38]
    // 0x65f168: StoreField: r0->field_f = d0
    //     0x65f168: stur            d0, [x0, #0xf]
    // 0x65f16c: ldur            d1, [fp, #-0x68]
    // 0x65f170: StoreField: r0->field_17 = d1
    //     0x65f170: stur            d1, [x0, #0x17]
    // 0x65f174: ldur            d2, [fp, #-0x30]
    // 0x65f178: StoreField: r0->field_1f = d2
    //     0x65f178: stur            d2, [x0, #0x1f]
    // 0x65f17c: d3 = 1.000000
    //     0x65f17c: fmov            d3, #1.00000000
    // 0x65f180: StoreField: r0->field_27 = d3
    //     0x65f180: stur            d3, [x0, #0x27]
    // 0x65f184: StoreField: r0->field_2f = d3
    //     0x65f184: stur            d3, [x0, #0x2f]
    // 0x65f188: StoreField: r0->field_37 = d3
    //     0x65f188: stur            d3, [x0, #0x37]
    // 0x65f18c: StoreField: r0->field_3f = d3
    //     0x65f18c: stur            d3, [x0, #0x3f]
    // 0x65f190: StoreField: r0->field_47 = d3
    //     0x65f190: stur            d3, [x0, #0x47]
    // 0x65f194: StoreField: r0->field_4f = d3
    //     0x65f194: stur            d3, [x0, #0x4f]
    // 0x65f198: StoreField: r0->field_57 = d3
    //     0x65f198: stur            d3, [x0, #0x57]
    // 0x65f19c: StoreField: r0->field_5f = d3
    //     0x65f19c: stur            d3, [x0, #0x5f]
    // 0x65f1a0: ldur            x16, [fp, #-0x18]
    // 0x65f1a4: stp             x0, x16, [SP, #-0x10]!
    // 0x65f1a8: ldur            x16, [fp, #-0x28]
    // 0x65f1ac: SaveReg r16
    //     0x65f1ac: str             x16, [SP, #-8]!
    // 0x65f1b0: r0 = drawRRect()
    //     0x65f1b0: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x65f1b4: add             SP, SP, #0x18
    // 0x65f1b8: ldur            d1, [fp, #-0x58]
    // 0x65f1bc: d0 = 1.000000
    //     0x65f1bc: fmov            d0, #1.00000000
    // 0x65f1c0: fcmp            d1, d0
    // 0x65f1c4: b.vs            #0x65f2a8
    // 0x65f1c8: b.ge            #0x65f2a8
    // 0x65f1cc: ldur            x0, [fp, #-8]
    // 0x65f1d0: ldur            d1, [fp, #-0x38]
    // 0x65f1d4: ldur            d3, [fp, #-0x30]
    // 0x65f1d8: ldur            d4, [fp, #-0x60]
    // 0x65f1dc: ldur            d2, [fp, #-0x68]
    // 0x65f1e0: r16 = 112
    //     0x65f1e0: mov             x16, #0x70
    // 0x65f1e4: stp             x16, NULL, [SP, #-0x10]!
    // 0x65f1e8: r0 = ByteData()
    //     0x65f1e8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x65f1ec: add             SP, SP, #0x10
    // 0x65f1f0: stur            x0, [fp, #-0x10]
    // 0x65f1f4: r0 = Paint()
    //     0x65f1f4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x65f1f8: mov             x2, x0
    // 0x65f1fc: ldur            x1, [fp, #-0x10]
    // 0x65f200: stur            x2, [fp, #-0x20]
    // 0x65f204: StoreField: r2->field_7 = r1
    //     0x65f204: stur            w1, [x2, #7]
    // 0x65f208: ldur            x0, [fp, #-8]
    // 0x65f20c: r3 = LoadClassIdInstr(r0)
    //     0x65f20c: ldur            x3, [x0, #-1]
    //     0x65f210: ubfx            x3, x3, #0xc, #0x14
    // 0x65f214: SaveReg r0
    //     0x65f214: str             x0, [SP, #-8]!
    // 0x65f218: mov             x0, x3
    // 0x65f21c: r0 = GDT[cid_x0 + -0xf7e]()
    //     0x65f21c: sub             lr, x0, #0xf7e
    //     0x65f220: ldr             lr, [x21, lr, lsl #3]
    //     0x65f224: blr             lr
    // 0x65f228: add             SP, SP, #8
    // 0x65f22c: eor             x1, x0, #0xff000000
    // 0x65f230: ldur            x0, [fp, #-0x10]
    // 0x65f234: LoadField: r2 = r0->field_17
    //     0x65f234: ldur            w2, [x0, #0x17]
    // 0x65f238: DecompressPointer r2
    //     0x65f238: add             x2, x2, HEAP, lsl #32
    // 0x65f23c: sxtw            x1, w1
    // 0x65f240: LoadField: r0 = r2->field_7
    //     0x65f240: ldur            x0, [x2, #7]
    // 0x65f244: str             w1, [x0, #4]
    // 0x65f248: r0 = RRect()
    //     0x65f248: bl              #0x640078  ; AllocateRRectStub -> RRect (size=0x68)
    // 0x65f24c: ldur            d0, [fp, #-0x68]
    // 0x65f250: StoreField: r0->field_7 = d0
    //     0x65f250: stur            d0, [x0, #7]
    // 0x65f254: ldur            d1, [fp, #-0x38]
    // 0x65f258: StoreField: r0->field_f = d1
    //     0x65f258: stur            d1, [x0, #0xf]
    // 0x65f25c: ldur            d1, [fp, #-0x60]
    // 0x65f260: StoreField: r0->field_17 = d1
    //     0x65f260: stur            d1, [x0, #0x17]
    // 0x65f264: ldur            d1, [fp, #-0x30]
    // 0x65f268: StoreField: r0->field_1f = d1
    //     0x65f268: stur            d1, [x0, #0x1f]
    // 0x65f26c: d1 = 1.000000
    //     0x65f26c: fmov            d1, #1.00000000
    // 0x65f270: StoreField: r0->field_27 = d1
    //     0x65f270: stur            d1, [x0, #0x27]
    // 0x65f274: StoreField: r0->field_2f = d1
    //     0x65f274: stur            d1, [x0, #0x2f]
    // 0x65f278: StoreField: r0->field_37 = d1
    //     0x65f278: stur            d1, [x0, #0x37]
    // 0x65f27c: StoreField: r0->field_3f = d1
    //     0x65f27c: stur            d1, [x0, #0x3f]
    // 0x65f280: StoreField: r0->field_47 = d1
    //     0x65f280: stur            d1, [x0, #0x47]
    // 0x65f284: StoreField: r0->field_4f = d1
    //     0x65f284: stur            d1, [x0, #0x4f]
    // 0x65f288: StoreField: r0->field_57 = d1
    //     0x65f288: stur            d1, [x0, #0x57]
    // 0x65f28c: StoreField: r0->field_5f = d1
    //     0x65f28c: stur            d1, [x0, #0x5f]
    // 0x65f290: ldur            x16, [fp, #-0x18]
    // 0x65f294: stp             x0, x16, [SP, #-0x10]!
    // 0x65f298: ldur            x16, [fp, #-0x20]
    // 0x65f29c: SaveReg r16
    //     0x65f29c: str             x16, [SP, #-8]!
    // 0x65f2a0: r0 = drawRRect()
    //     0x65f2a0: bl              #0x660554  ; [dart:ui] Canvas::drawRRect
    // 0x65f2a4: add             SP, SP, #0x18
    // 0x65f2a8: ldur            d1, [fp, #-0x50]
    // 0x65f2ac: ldur            d0, [fp, #-0x68]
    // 0x65f2b0: r0 = Offset()
    //     0x65f2b0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65f2b4: ldur            d0, [fp, #-0x68]
    // 0x65f2b8: stur            x0, [fp, #-8]
    // 0x65f2bc: StoreField: r0->field_7 = d0
    //     0x65f2bc: stur            d0, [x0, #7]
    // 0x65f2c0: ldur            d0, [fp, #-0x50]
    // 0x65f2c4: StoreField: r0->field_f = d0
    //     0x65f2c4: stur            d0, [x0, #0xf]
    // 0x65f2c8: r0 = CupertinoThumbPainter()
    //     0x65f2c8: bl              #0x660548  ; AllocateCupertinoThumbPainterStub -> CupertinoThumbPainter (size=0x10)
    // 0x65f2cc: mov             x1, x0
    // 0x65f2d0: r0 = Instance_Color
    //     0x65f2d0: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x65f2d4: ldr             x0, [x0, #0xbe8]
    // 0x65f2d8: stur            x1, [fp, #-0x10]
    // 0x65f2dc: StoreField: r1->field_7 = r0
    //     0x65f2dc: stur            w0, [x1, #7]
    // 0x65f2e0: r0 = const [Instance of 'BoxShadow', Instance of 'BoxShadow', Instance of 'BoxShadow']
    //     0x65f2e0: add             x0, PP, #0x57, lsl #12  ; [pp+0x57518] List<BoxShadow>(3)
    //     0x65f2e4: ldr             x0, [x0, #0x518]
    // 0x65f2e8: StoreField: r1->field_b = r0
    //     0x65f2e8: stur            w0, [x1, #0xb]
    // 0x65f2ec: r0 = Rect()
    //     0x65f2ec: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x65f2f0: stur            x0, [fp, #-0x20]
    // 0x65f2f4: ldur            x16, [fp, #-8]
    // 0x65f2f8: stp             x16, x0, [SP, #-0x10]!
    // 0x65f2fc: r16 = 28.000000
    //     0x65f2fc: add             x16, PP, #0x30, lsl #12  ; [pp+0x30460] 28
    //     0x65f300: ldr             x16, [x16, #0x460]
    // 0x65f304: SaveReg r16
    //     0x65f304: str             x16, [SP, #-8]!
    // 0x65f308: d0 = 28.000000
    //     0x65f308: fmov            d0, #28.00000000
    // 0x65f30c: SaveReg d0
    //     0x65f30c: str             d0, [SP, #-8]!
    // 0x65f310: r0 = Rect.fromCenter()
    //     0x65f310: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x65f314: add             SP, SP, #0x20
    // 0x65f318: ldur            x16, [fp, #-0x10]
    // 0x65f31c: ldur            lr, [fp, #-0x18]
    // 0x65f320: stp             lr, x16, [SP, #-0x10]!
    // 0x65f324: ldur            x16, [fp, #-0x20]
    // 0x65f328: SaveReg r16
    //     0x65f328: str             x16, [SP, #-8]!
    // 0x65f32c: r0 = paint()
    //     0x65f32c: bl              #0x65f380  ; [package:flutter/src/cupertino/thumb_painter.dart] CupertinoThumbPainter::paint
    // 0x65f330: add             SP, SP, #0x18
    // 0x65f334: r0 = Null
    //     0x65f334: mov             x0, NULL
    // 0x65f338: LeaveFrame
    //     0x65f338: mov             SP, fp
    //     0x65f33c: ldp             fp, lr, [SP], #0x10
    // 0x65f340: ret
    //     0x65f340: ret             
    // 0x65f344: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65f344: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65f348: b               #0x65ef68
    // 0x65f34c: r9 = _position
    //     0x65f34c: add             x9, PP, #0x57, lsl #12  ; [pp+0x57368] Field <_RenderCupertinoSlider@613348729._position@613348729>: late (offset: 0x90)
    //     0x65f350: ldr             x9, [x9, #0x368]
    // 0x65f354: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x65f354: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x65f358: r9 = _value
    //     0x65f358: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x65f35c: ldr             x9, [x9, #0xbb0]
    // 0x65f360: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x65f360: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x65f364: r9 = _position
    //     0x65f364: add             x9, PP, #0x57, lsl #12  ; [pp+0x57368] Field <_RenderCupertinoSlider@613348729._position@613348729>: late (offset: 0x90)
    //     0x65f368: ldr             x9, [x9, #0x368]
    // 0x65f36c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x65f36c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x65f370: r9 = _value
    //     0x65f370: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x65f374: ldr             x9, [x9, #0xbb0]
    // 0x65f378: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x65f378: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x65f37c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65f37c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
  }
  set _ textDirection=(/* No info */) {
    // ** addr: 0x6ca774, size: 0x80
    // 0x6ca774: EnterFrame
    //     0x6ca774: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca778: mov             fp, SP
    // 0x6ca77c: CheckStackOverflow
    //     0x6ca77c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca780: cmp             SP, x16
    //     0x6ca784: b.ls            #0x6ca7ec
    // 0x6ca788: ldr             x1, [fp, #0x18]
    // 0x6ca78c: LoadField: r0 = r1->field_8b
    //     0x6ca78c: ldur            w0, [x1, #0x8b]
    // 0x6ca790: DecompressPointer r0
    //     0x6ca790: add             x0, x0, HEAP, lsl #32
    // 0x6ca794: ldr             x2, [fp, #0x10]
    // 0x6ca798: cmp             w0, w2
    // 0x6ca79c: b.ne            #0x6ca7b0
    // 0x6ca7a0: r0 = Null
    //     0x6ca7a0: mov             x0, NULL
    // 0x6ca7a4: LeaveFrame
    //     0x6ca7a4: mov             SP, fp
    //     0x6ca7a8: ldp             fp, lr, [SP], #0x10
    // 0x6ca7ac: ret
    //     0x6ca7ac: ret             
    // 0x6ca7b0: mov             x0, x2
    // 0x6ca7b4: StoreField: r1->field_8b = r0
    //     0x6ca7b4: stur            w0, [x1, #0x8b]
    //     0x6ca7b8: ldurb           w16, [x1, #-1]
    //     0x6ca7bc: ldurb           w17, [x0, #-1]
    //     0x6ca7c0: and             x16, x17, x16, lsr #2
    //     0x6ca7c4: tst             x16, HEAP, lsr #32
    //     0x6ca7c8: b.eq            #0x6ca7d0
    //     0x6ca7cc: bl              #0xd6826c
    // 0x6ca7d0: SaveReg r1
    //     0x6ca7d0: str             x1, [SP, #-8]!
    // 0x6ca7d4: r0 = markNeedsPaint()
    //     0x6ca7d4: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6ca7d8: add             SP, SP, #8
    // 0x6ca7dc: r0 = Null
    //     0x6ca7dc: mov             x0, NULL
    // 0x6ca7e0: LeaveFrame
    //     0x6ca7e0: mov             SP, fp
    //     0x6ca7e4: ldp             fp, lr, [SP], #0x10
    // 0x6ca7e8: ret
    //     0x6ca7e8: ret             
    // 0x6ca7ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca7ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca7f0: b               #0x6ca788
  }
  set _ onChanged=(/* No info */) {
    // ** addr: 0x6ca7f4, size: 0xd4
    // 0x6ca7f4: EnterFrame
    //     0x6ca7f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca7f8: mov             fp, SP
    // 0x6ca7fc: CheckStackOverflow
    //     0x6ca7fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca800: cmp             SP, x16
    //     0x6ca804: b.ls            #0x6ca8c0
    // 0x6ca808: ldr             x1, [fp, #0x18]
    // 0x6ca80c: LoadField: r0 = r1->field_7f
    //     0x6ca80c: ldur            w0, [x1, #0x7f]
    // 0x6ca810: DecompressPointer r0
    //     0x6ca810: add             x0, x0, HEAP, lsl #32
    // 0x6ca814: ldr             x2, [fp, #0x10]
    // 0x6ca818: r3 = LoadClassIdInstr(r2)
    //     0x6ca818: ldur            x3, [x2, #-1]
    //     0x6ca81c: ubfx            x3, x3, #0xc, #0x14
    // 0x6ca820: stp             x0, x2, [SP, #-0x10]!
    // 0x6ca824: mov             x0, x3
    // 0x6ca828: mov             lr, x0
    // 0x6ca82c: ldr             lr, [x21, lr, lsl #3]
    // 0x6ca830: blr             lr
    // 0x6ca834: add             SP, SP, #0x10
    // 0x6ca838: tbnz            w0, #4, #0x6ca84c
    // 0x6ca83c: r0 = Null
    //     0x6ca83c: mov             x0, NULL
    // 0x6ca840: LeaveFrame
    //     0x6ca840: mov             SP, fp
    //     0x6ca844: ldp             fp, lr, [SP], #0x10
    // 0x6ca848: ret
    //     0x6ca848: ret             
    // 0x6ca84c: ldr             x0, [fp, #0x18]
    // 0x6ca850: ldr             x1, [fp, #0x10]
    // 0x6ca854: SaveReg r0
    //     0x6ca854: str             x0, [SP, #-8]!
    // 0x6ca858: r0 = isInteractive()
    //     0x6ca858: bl              #0x6ca8c8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::isInteractive
    // 0x6ca85c: add             SP, SP, #8
    // 0x6ca860: mov             x2, x0
    // 0x6ca864: ldr             x0, [fp, #0x10]
    // 0x6ca868: ldr             x1, [fp, #0x18]
    // 0x6ca86c: StoreField: r1->field_7f = r0
    //     0x6ca86c: stur            w0, [x1, #0x7f]
    //     0x6ca870: ldurb           w16, [x1, #-1]
    //     0x6ca874: ldurb           w17, [x0, #-1]
    //     0x6ca878: and             x16, x17, x16, lsr #2
    //     0x6ca87c: tst             x16, HEAP, lsr #32
    //     0x6ca880: b.eq            #0x6ca888
    //     0x6ca884: bl              #0xd6826c
    // 0x6ca888: ldr             x0, [fp, #0x10]
    // 0x6ca88c: cmp             w0, NULL
    // 0x6ca890: r16 = true
    //     0x6ca890: add             x16, NULL, #0x20  ; true
    // 0x6ca894: r17 = false
    //     0x6ca894: add             x17, NULL, #0x30  ; false
    // 0x6ca898: csel            x3, x16, x17, ne
    // 0x6ca89c: cmp             w2, w3
    // 0x6ca8a0: b.eq            #0x6ca8b0
    // 0x6ca8a4: SaveReg r1
    //     0x6ca8a4: str             x1, [SP, #-8]!
    // 0x6ca8a8: r0 = markNeedsSemanticsUpdate()
    //     0x6ca8a8: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6ca8ac: add             SP, SP, #8
    // 0x6ca8b0: r0 = Null
    //     0x6ca8b0: mov             x0, NULL
    // 0x6ca8b4: LeaveFrame
    //     0x6ca8b4: mov             SP, fp
    //     0x6ca8b8: ldp             fp, lr, [SP], #0x10
    // 0x6ca8bc: ret
    //     0x6ca8bc: ret             
    // 0x6ca8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca8c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca8c4: b               #0x6ca808
  }
  get _ isInteractive(/* No info */) {
    // ** addr: 0x6ca8c8, size: 0x20
    // 0x6ca8c8: ldr             x1, [SP]
    // 0x6ca8cc: LoadField: r2 = r1->field_7f
    //     0x6ca8cc: ldur            w2, [x1, #0x7f]
    // 0x6ca8d0: DecompressPointer r2
    //     0x6ca8d0: add             x2, x2, HEAP, lsl #32
    // 0x6ca8d4: cmp             w2, NULL
    // 0x6ca8d8: r16 = true
    //     0x6ca8d8: add             x16, NULL, #0x20  ; true
    // 0x6ca8dc: r17 = false
    //     0x6ca8dc: add             x17, NULL, #0x30  ; false
    // 0x6ca8e0: csel            x0, x16, x17, ne
    // 0x6ca8e4: ret
    //     0x6ca8e4: ret             
  }
  set _ trackColor=(/* No info */) {
    // ** addr: 0x6ca8e8, size: 0x8c
    // 0x6ca8e8: EnterFrame
    //     0x6ca8e8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca8ec: mov             fp, SP
    // 0x6ca8f0: CheckStackOverflow
    //     0x6ca8f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca8f4: cmp             SP, x16
    //     0x6ca8f8: b.ls            #0x6ca96c
    // 0x6ca8fc: ldr             x0, [fp, #0x18]
    // 0x6ca900: LoadField: r1 = r0->field_7b
    //     0x6ca900: ldur            w1, [x0, #0x7b]
    // 0x6ca904: DecompressPointer r1
    //     0x6ca904: add             x1, x1, HEAP, lsl #32
    // 0x6ca908: ldr             x16, [fp, #0x10]
    // 0x6ca90c: stp             x1, x16, [SP, #-0x10]!
    // 0x6ca910: r0 = ==()
    //     0x6ca910: bl              #0xc664cc  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::==
    // 0x6ca914: add             SP, SP, #0x10
    // 0x6ca918: tbnz            w0, #4, #0x6ca92c
    // 0x6ca91c: r0 = Null
    //     0x6ca91c: mov             x0, NULL
    // 0x6ca920: LeaveFrame
    //     0x6ca920: mov             SP, fp
    //     0x6ca924: ldp             fp, lr, [SP], #0x10
    // 0x6ca928: ret
    //     0x6ca928: ret             
    // 0x6ca92c: ldr             x1, [fp, #0x18]
    // 0x6ca930: ldr             x0, [fp, #0x10]
    // 0x6ca934: StoreField: r1->field_7b = r0
    //     0x6ca934: stur            w0, [x1, #0x7b]
    //     0x6ca938: ldurb           w16, [x1, #-1]
    //     0x6ca93c: ldurb           w17, [x0, #-1]
    //     0x6ca940: and             x16, x17, x16, lsr #2
    //     0x6ca944: tst             x16, HEAP, lsr #32
    //     0x6ca948: b.eq            #0x6ca950
    //     0x6ca94c: bl              #0xd6826c
    // 0x6ca950: SaveReg r1
    //     0x6ca950: str             x1, [SP, #-8]!
    // 0x6ca954: r0 = markNeedsPaint()
    //     0x6ca954: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6ca958: add             SP, SP, #8
    // 0x6ca95c: r0 = Null
    //     0x6ca95c: mov             x0, NULL
    // 0x6ca960: LeaveFrame
    //     0x6ca960: mov             SP, fp
    //     0x6ca964: ldp             fp, lr, [SP], #0x10
    // 0x6ca968: ret
    //     0x6ca968: ret             
    // 0x6ca96c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca96c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca970: b               #0x6ca8fc
  }
  set _ activeColor=(/* No info */) {
    // ** addr: 0x6cb218, size: 0x1a4
    // 0x6cb218: EnterFrame
    //     0x6cb218: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb21c: mov             fp, SP
    // 0x6cb220: AllocStack(0x10)
    //     0x6cb220: sub             SP, SP, #0x10
    // 0x6cb224: CheckStackOverflow
    //     0x6cb224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb228: cmp             SP, x16
    //     0x6cb22c: b.ls            #0x6cb3b4
    // 0x6cb230: ldr             x0, [fp, #0x18]
    // 0x6cb234: LoadField: r1 = r0->field_73
    //     0x6cb234: ldur            w1, [x0, #0x73]
    // 0x6cb238: DecompressPointer r1
    //     0x6cb238: add             x1, x1, HEAP, lsl #32
    // 0x6cb23c: ldr             x2, [fp, #0x10]
    // 0x6cb240: stur            x1, [fp, #-0x10]
    // 0x6cb244: r3 = LoadClassIdInstr(r2)
    //     0x6cb244: ldur            x3, [x2, #-1]
    //     0x6cb248: ubfx            x3, x3, #0xc, #0x14
    // 0x6cb24c: lsl             x3, x3, #1
    // 0x6cb250: stur            x3, [fp, #-8]
    // 0x6cb254: r17 = 10114
    //     0x6cb254: mov             x17, #0x2782
    // 0x6cb258: cmp             w3, w17
    // 0x6cb25c: b.eq            #0x6cb26c
    // 0x6cb260: r17 = 10118
    //     0x6cb260: mov             x17, #0x2786
    // 0x6cb264: cmp             w3, w17
    // 0x6cb268: b.ne            #0x6cb33c
    // 0x6cb26c: cmp             w2, w1
    // 0x6cb270: b.eq            #0x6cb364
    // 0x6cb274: stp             x2, x1, [SP, #-0x10]!
    // 0x6cb278: r0 = _haveSameRuntimeType()
    //     0x6cb278: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0x6cb27c: add             SP, SP, #0x10
    // 0x6cb280: tbnz            w0, #4, #0x6cb374
    // 0x6cb284: ldur            x0, [fp, #-0x10]
    // 0x6cb288: r1 = LoadClassIdInstr(r0)
    //     0x6cb288: ldur            x1, [x0, #-1]
    //     0x6cb28c: ubfx            x1, x1, #0xc, #0x14
    // 0x6cb290: lsl             x1, x1, #1
    // 0x6cb294: r17 = 10124
    //     0x6cb294: mov             x17, #0x278c
    // 0x6cb298: cmp             w1, w17
    // 0x6cb29c: b.gt            #0x6cb2ac
    // 0x6cb2a0: r17 = 10122
    //     0x6cb2a0: mov             x17, #0x278a
    // 0x6cb2a4: cmp             w1, w17
    // 0x6cb2a8: b.ge            #0x6cb2c4
    // 0x6cb2ac: r17 = 10114
    //     0x6cb2ac: mov             x17, #0x2782
    // 0x6cb2b0: cmp             w1, w17
    // 0x6cb2b4: b.eq            #0x6cb2c4
    // 0x6cb2b8: r17 = 10118
    //     0x6cb2b8: mov             x17, #0x2786
    // 0x6cb2bc: cmp             w1, w17
    // 0x6cb2c0: b.ne            #0x6cb2cc
    // 0x6cb2c4: LoadField: r1 = r0->field_7
    //     0x6cb2c4: ldur            x1, [x0, #7]
    // 0x6cb2c8: b               #0x6cb2dc
    // 0x6cb2cc: LoadField: r1 = r0->field_f
    //     0x6cb2cc: ldur            w1, [x0, #0xf]
    // 0x6cb2d0: DecompressPointer r1
    //     0x6cb2d0: add             x1, x1, HEAP, lsl #32
    // 0x6cb2d4: LoadField: r0 = r1->field_7
    //     0x6cb2d4: ldur            x0, [x1, #7]
    // 0x6cb2d8: mov             x1, x0
    // 0x6cb2dc: ldur            x0, [fp, #-8]
    // 0x6cb2e0: r17 = 10124
    //     0x6cb2e0: mov             x17, #0x278c
    // 0x6cb2e4: cmp             w0, w17
    // 0x6cb2e8: b.gt            #0x6cb2f8
    // 0x6cb2ec: r17 = 10122
    //     0x6cb2ec: mov             x17, #0x278a
    // 0x6cb2f0: cmp             w0, w17
    // 0x6cb2f4: b.ge            #0x6cb310
    // 0x6cb2f8: r17 = 10114
    //     0x6cb2f8: mov             x17, #0x2782
    // 0x6cb2fc: cmp             w0, w17
    // 0x6cb300: b.eq            #0x6cb310
    // 0x6cb304: r17 = 10118
    //     0x6cb304: mov             x17, #0x2786
    // 0x6cb308: cmp             w0, w17
    // 0x6cb30c: b.ne            #0x6cb31c
    // 0x6cb310: ldr             x2, [fp, #0x10]
    // 0x6cb314: LoadField: r0 = r2->field_7
    //     0x6cb314: ldur            x0, [x2, #7]
    // 0x6cb318: b               #0x6cb330
    // 0x6cb31c: ldr             x2, [fp, #0x10]
    // 0x6cb320: LoadField: r0 = r2->field_f
    //     0x6cb320: ldur            w0, [x2, #0xf]
    // 0x6cb324: DecompressPointer r0
    //     0x6cb324: add             x0, x0, HEAP, lsl #32
    // 0x6cb328: LoadField: r3 = r0->field_7
    //     0x6cb328: ldur            x3, [x0, #7]
    // 0x6cb32c: mov             x0, x3
    // 0x6cb330: cmp             x1, x0
    // 0x6cb334: b.ne            #0x6cb374
    // 0x6cb338: b               #0x6cb364
    // 0x6cb33c: mov             x0, x1
    // 0x6cb340: r1 = LoadClassIdInstr(r2)
    //     0x6cb340: ldur            x1, [x2, #-1]
    //     0x6cb344: ubfx            x1, x1, #0xc, #0x14
    // 0x6cb348: stp             x0, x2, [SP, #-0x10]!
    // 0x6cb34c: mov             x0, x1
    // 0x6cb350: mov             lr, x0
    // 0x6cb354: ldr             lr, [x21, lr, lsl #3]
    // 0x6cb358: blr             lr
    // 0x6cb35c: add             SP, SP, #0x10
    // 0x6cb360: tbnz            w0, #4, #0x6cb374
    // 0x6cb364: r0 = Null
    //     0x6cb364: mov             x0, NULL
    // 0x6cb368: LeaveFrame
    //     0x6cb368: mov             SP, fp
    //     0x6cb36c: ldp             fp, lr, [SP], #0x10
    // 0x6cb370: ret
    //     0x6cb370: ret             
    // 0x6cb374: ldr             x1, [fp, #0x18]
    // 0x6cb378: ldr             x0, [fp, #0x10]
    // 0x6cb37c: StoreField: r1->field_73 = r0
    //     0x6cb37c: stur            w0, [x1, #0x73]
    //     0x6cb380: ldurb           w16, [x1, #-1]
    //     0x6cb384: ldurb           w17, [x0, #-1]
    //     0x6cb388: and             x16, x17, x16, lsr #2
    //     0x6cb38c: tst             x16, HEAP, lsr #32
    //     0x6cb390: b.eq            #0x6cb398
    //     0x6cb394: bl              #0xd6826c
    // 0x6cb398: SaveReg r1
    //     0x6cb398: str             x1, [SP, #-8]!
    // 0x6cb39c: r0 = markNeedsPaint()
    //     0x6cb39c: bl              #0x6bf200  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint
    // 0x6cb3a0: add             SP, SP, #8
    // 0x6cb3a4: r0 = Null
    //     0x6cb3a4: mov             x0, NULL
    // 0x6cb3a8: LeaveFrame
    //     0x6cb3a8: mov             SP, fp
    //     0x6cb3ac: ldp             fp, lr, [SP], #0x10
    // 0x6cb3b0: ret
    //     0x6cb3b0: ret             
    // 0x6cb3b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb3b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb3b8: b               #0x6cb230
  }
  set _ value=(/* No info */) {
    // ** addr: 0x6cb3bc, size: 0x98
    // 0x6cb3bc: EnterFrame
    //     0x6cb3bc: stp             fp, lr, [SP, #-0x10]!
    //     0x6cb3c0: mov             fp, SP
    // 0x6cb3c4: CheckStackOverflow
    //     0x6cb3c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6cb3c8: cmp             SP, x16
    //     0x6cb3cc: b.ls            #0x6cb440
    // 0x6cb3d0: ldr             x0, [fp, #0x18]
    // 0x6cb3d4: LoadField: d0 = r0->field_67
    //     0x6cb3d4: ldur            d0, [x0, #0x67]
    // 0x6cb3d8: ldr             d1, [fp, #0x10]
    // 0x6cb3dc: fcmp            d1, d0
    // 0x6cb3e0: b.vs            #0x6cb3f8
    // 0x6cb3e4: b.ne            #0x6cb3f8
    // 0x6cb3e8: r0 = Null
    //     0x6cb3e8: mov             x0, NULL
    // 0x6cb3ec: LeaveFrame
    //     0x6cb3ec: mov             SP, fp
    //     0x6cb3f0: ldp             fp, lr, [SP], #0x10
    // 0x6cb3f4: ret
    //     0x6cb3f4: ret             
    // 0x6cb3f8: StoreField: r0->field_67 = d1
    //     0x6cb3f8: stur            d1, [x0, #0x67]
    // 0x6cb3fc: LoadField: r1 = r0->field_8f
    //     0x6cb3fc: ldur            w1, [x0, #0x8f]
    // 0x6cb400: DecompressPointer r1
    //     0x6cb400: add             x1, x1, HEAP, lsl #32
    // 0x6cb404: r16 = Sentinel
    //     0x6cb404: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6cb408: cmp             w1, w16
    // 0x6cb40c: b.eq            #0x6cb448
    // 0x6cb410: SaveReg r1
    //     0x6cb410: str             x1, [SP, #-8]!
    // 0x6cb414: SaveReg d1
    //     0x6cb414: str             d1, [SP, #-8]!
    // 0x6cb418: r0 = value=()
    //     0x6cb418: bl              #0x5937d8  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::value=
    // 0x6cb41c: add             SP, SP, #0x10
    // 0x6cb420: ldr             x16, [fp, #0x18]
    // 0x6cb424: SaveReg r16
    //     0x6cb424: str             x16, [SP, #-8]!
    // 0x6cb428: r0 = markNeedsSemanticsUpdate()
    //     0x6cb428: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6cb42c: add             SP, SP, #8
    // 0x6cb430: r0 = Null
    //     0x6cb430: mov             x0, NULL
    // 0x6cb434: LeaveFrame
    //     0x6cb434: mov             SP, fp
    //     0x6cb438: ldp             fp, lr, [SP], #0x10
    // 0x6cb43c: ret
    //     0x6cb43c: ret             
    // 0x6cb440: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6cb440: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6cb444: b               #0x6cb3d0
    // 0x6cb448: r9 = _position
    //     0x6cb448: add             x9, PP, #0x57, lsl #12  ; [pp+0x57368] Field <_RenderCupertinoSlider@613348729._position@613348729>: late (offset: 0x90)
    //     0x6cb44c: ldr             x9, [x9, #0x368]
    // 0x6cb450: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x6cb450: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
  }
  _ _RenderCupertinoSlider(/* No info */) {
    // ** addr: 0x6edf54, size: 0x324
    // 0x6edf54: EnterFrame
    //     0x6edf54: stp             fp, lr, [SP, #-0x10]!
    //     0x6edf58: mov             fp, SP
    // 0x6edf5c: AllocStack(0x10)
    //     0x6edf5c: sub             SP, SP, #0x10
    // 0x6edf60: r0 = Sentinel
    //     0x6edf60: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6edf64: r3 = Instance__DeferringMouseCursor
    //     0x6edf64: ldr             x3, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x6edf68: r2 = Instance_Color
    //     0x6edf68: add             x2, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6edf6c: ldr             x2, [x2, #0xbe8]
    // 0x6edf70: r1 = Instance_BoxConstraints
    //     0x6edf70: add             x1, PP, #0x57, lsl #12  ; [pp+0x57370] Obj!BoxConstraints@b353b1
    //     0x6edf74: ldr             x1, [x1, #0x370]
    // 0x6edf78: d0 = 0.000000
    //     0x6edf78: eor             v0.16b, v0.16b, v0.16b
    // 0x6edf7c: CheckStackOverflow
    //     0x6edf7c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6edf80: cmp             SP, x16
    //     0x6edf84: b.ls            #0x6ee258
    // 0x6edf88: ldr             x4, [fp, #0x50]
    // 0x6edf8c: StoreField: r4->field_8f = r0
    //     0x6edf8c: stur            w0, [x4, #0x8f]
    // 0x6edf90: StoreField: r4->field_93 = r0
    //     0x6edf90: stur            w0, [x4, #0x93]
    // 0x6edf94: StoreField: r4->field_97 = d0
    //     0x6edf94: stur            d0, [x4, #0x97]
    // 0x6edf98: ldr             x0, [fp, #0x38]
    // 0x6edf9c: StoreField: r4->field_83 = r0
    //     0x6edf9c: stur            w0, [x4, #0x83]
    //     0x6edfa0: ldurb           w16, [x4, #-1]
    //     0x6edfa4: ldurb           w17, [x0, #-1]
    //     0x6edfa8: and             x16, x17, x16, lsr #2
    //     0x6edfac: tst             x16, HEAP, lsr #32
    //     0x6edfb0: b.eq            #0x6edfb8
    //     0x6edfb4: bl              #0xd682cc
    // 0x6edfb8: ldr             x0, [fp, #0x40]
    // 0x6edfbc: StoreField: r4->field_87 = r0
    //     0x6edfbc: stur            w0, [x4, #0x87]
    //     0x6edfc0: ldurb           w16, [x4, #-1]
    //     0x6edfc4: ldurb           w17, [x0, #-1]
    //     0x6edfc8: and             x16, x17, x16, lsr #2
    //     0x6edfcc: tst             x16, HEAP, lsr #32
    //     0x6edfd0: b.eq            #0x6edfd8
    //     0x6edfd4: bl              #0xd682cc
    // 0x6edfd8: StoreField: r4->field_9f = r3
    //     0x6edfd8: stur            w3, [x4, #0x9f]
    // 0x6edfdc: ldr             d0, [fp, #0x18]
    // 0x6edfe0: StoreField: r4->field_67 = d0
    //     0x6edfe0: stur            d0, [x4, #0x67]
    // 0x6edfe4: ldr             x0, [fp, #0x48]
    // 0x6edfe8: StoreField: r4->field_73 = r0
    //     0x6edfe8: stur            w0, [x4, #0x73]
    //     0x6edfec: ldurb           w16, [x4, #-1]
    //     0x6edff0: ldurb           w17, [x0, #-1]
    //     0x6edff4: and             x16, x17, x16, lsr #2
    //     0x6edff8: tst             x16, HEAP, lsr #32
    //     0x6edffc: b.eq            #0x6ee004
    //     0x6ee000: bl              #0xd682cc
    // 0x6ee004: StoreField: r4->field_77 = r2
    //     0x6ee004: stur            w2, [x4, #0x77]
    // 0x6ee008: ldr             x0, [fp, #0x20]
    // 0x6ee00c: StoreField: r4->field_7b = r0
    //     0x6ee00c: stur            w0, [x4, #0x7b]
    //     0x6ee010: ldurb           w16, [x4, #-1]
    //     0x6ee014: ldurb           w17, [x0, #-1]
    //     0x6ee018: and             x16, x17, x16, lsr #2
    //     0x6ee01c: tst             x16, HEAP, lsr #32
    //     0x6ee020: b.eq            #0x6ee028
    //     0x6ee024: bl              #0xd682cc
    // 0x6ee028: ldr             x0, [fp, #0x30]
    // 0x6ee02c: StoreField: r4->field_7f = r0
    //     0x6ee02c: stur            w0, [x4, #0x7f]
    //     0x6ee030: ldurb           w16, [x4, #-1]
    //     0x6ee034: ldurb           w17, [x0, #-1]
    //     0x6ee038: and             x16, x17, x16, lsr #2
    //     0x6ee03c: tst             x16, HEAP, lsr #32
    //     0x6ee040: b.eq            #0x6ee048
    //     0x6ee044: bl              #0xd682cc
    // 0x6ee048: ldr             x0, [fp, #0x28]
    // 0x6ee04c: StoreField: r4->field_8b = r0
    //     0x6ee04c: stur            w0, [x4, #0x8b]
    //     0x6ee050: ldurb           w16, [x4, #-1]
    //     0x6ee054: ldurb           w17, [x0, #-1]
    //     0x6ee058: and             x16, x17, x16, lsr #2
    //     0x6ee05c: tst             x16, HEAP, lsr #32
    //     0x6ee060: b.eq            #0x6ee068
    //     0x6ee064: bl              #0xd682cc
    // 0x6ee068: StoreField: r4->field_63 = r1
    //     0x6ee068: stur            w1, [x4, #0x63]
    // 0x6ee06c: SaveReg r4
    //     0x6ee06c: str             x4, [SP, #-8]!
    // 0x6ee070: r0 = RenderObject()
    //     0x6ee070: bl              #0x5bc2f8  ; [package:flutter/src/rendering/object.dart] RenderObject::RenderObject
    // 0x6ee074: add             SP, SP, #8
    // 0x6ee078: ldr             x16, [fp, #0x50]
    // 0x6ee07c: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ee080: r0 = child=()
    //     0x6ee080: bl              #0x6e7da0  ; [package:flutter/src/rendering/shifted_box.dart] _RenderShiftedBox&RenderBox&RenderObjectWithChildMixin::child=
    // 0x6ee084: add             SP, SP, #0x10
    // 0x6ee088: r0 = HorizontalDragGestureRecognizer()
    //     0x6ee088: bl              #0x6ee4e8  ; AllocateHorizontalDragGestureRecognizerStub -> HorizontalDragGestureRecognizer (size=0x6c)
    // 0x6ee08c: stur            x0, [fp, #-8]
    // 0x6ee090: stp             NULL, x0, [SP, #-0x10]!
    // 0x6ee094: r0 = DragGestureRecognizer()
    //     0x6ee094: bl              #0x6ee278  ; [package:flutter/src/gestures/monodrag.dart] DragGestureRecognizer::DragGestureRecognizer
    // 0x6ee098: add             SP, SP, #0x10
    // 0x6ee09c: r1 = 1
    //     0x6ee09c: mov             x1, #1
    // 0x6ee0a0: r0 = AllocateContext()
    //     0x6ee0a0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ee0a4: mov             x1, x0
    // 0x6ee0a8: ldr             x0, [fp, #0x50]
    // 0x6ee0ac: StoreField: r1->field_f = r0
    //     0x6ee0ac: stur            w0, [x1, #0xf]
    // 0x6ee0b0: mov             x2, x1
    // 0x6ee0b4: r1 = Function '_handleDragStart@613348729':.
    //     0x6ee0b4: add             x1, PP, #0x57, lsl #12  ; [pp+0x57378] AnonymousClosure: (0x6ee848), of [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider
    //     0x6ee0b8: ldr             x1, [x1, #0x378]
    // 0x6ee0bc: r0 = AllocateClosure()
    //     0x6ee0bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ee0c0: ldur            x1, [fp, #-8]
    // 0x6ee0c4: StoreField: r1->field_27 = r0
    //     0x6ee0c4: stur            w0, [x1, #0x27]
    //     0x6ee0c8: ldurb           w16, [x1, #-1]
    //     0x6ee0cc: ldurb           w17, [x0, #-1]
    //     0x6ee0d0: and             x16, x17, x16, lsr #2
    //     0x6ee0d4: tst             x16, HEAP, lsr #32
    //     0x6ee0d8: b.eq            #0x6ee0e0
    //     0x6ee0dc: bl              #0xd6826c
    // 0x6ee0e0: r1 = 1
    //     0x6ee0e0: mov             x1, #1
    // 0x6ee0e4: r0 = AllocateContext()
    //     0x6ee0e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ee0e8: mov             x1, x0
    // 0x6ee0ec: ldr             x0, [fp, #0x50]
    // 0x6ee0f0: StoreField: r1->field_f = r0
    //     0x6ee0f0: stur            w0, [x1, #0xf]
    // 0x6ee0f4: mov             x2, x1
    // 0x6ee0f8: r1 = Function '_handleDragUpdate@613348729':.
    //     0x6ee0f8: add             x1, PP, #0x57, lsl #12  ; [pp+0x57380] AnonymousClosure: (0x6ee64c), in [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_handleDragUpdate (0x6ee698)
    //     0x6ee0fc: ldr             x1, [x1, #0x380]
    // 0x6ee100: r0 = AllocateClosure()
    //     0x6ee100: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ee104: ldur            x1, [fp, #-8]
    // 0x6ee108: StoreField: r1->field_2b = r0
    //     0x6ee108: stur            w0, [x1, #0x2b]
    //     0x6ee10c: ldurb           w16, [x1, #-1]
    //     0x6ee110: ldurb           w17, [x0, #-1]
    //     0x6ee114: and             x16, x17, x16, lsr #2
    //     0x6ee118: tst             x16, HEAP, lsr #32
    //     0x6ee11c: b.eq            #0x6ee124
    //     0x6ee120: bl              #0xd6826c
    // 0x6ee124: r1 = 1
    //     0x6ee124: mov             x1, #1
    // 0x6ee128: r0 = AllocateContext()
    //     0x6ee128: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ee12c: mov             x1, x0
    // 0x6ee130: ldr             x0, [fp, #0x50]
    // 0x6ee134: StoreField: r1->field_f = r0
    //     0x6ee134: stur            w0, [x1, #0xf]
    // 0x6ee138: mov             x2, x1
    // 0x6ee13c: r1 = Function '_handleDragEnd@613348729':.
    //     0x6ee13c: add             x1, PP, #0x57, lsl #12  ; [pp+0x57388] AnonymousClosure: (0x6ee4f4), of [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider
    //     0x6ee140: ldr             x1, [x1, #0x388]
    // 0x6ee144: r0 = AllocateClosure()
    //     0x6ee144: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ee148: ldur            x1, [fp, #-8]
    // 0x6ee14c: StoreField: r1->field_2f = r0
    //     0x6ee14c: stur            w0, [x1, #0x2f]
    //     0x6ee150: ldurb           w16, [x1, #-1]
    //     0x6ee154: ldurb           w17, [x0, #-1]
    //     0x6ee158: and             x16, x17, x16, lsr #2
    //     0x6ee15c: tst             x16, HEAP, lsr #32
    //     0x6ee160: b.eq            #0x6ee168
    //     0x6ee164: bl              #0xd6826c
    // 0x6ee168: mov             x0, x1
    // 0x6ee16c: ldr             x2, [fp, #0x50]
    // 0x6ee170: StoreField: r2->field_93 = r0
    //     0x6ee170: stur            w0, [x2, #0x93]
    //     0x6ee174: ldurb           w16, [x2, #-1]
    //     0x6ee178: ldurb           w17, [x0, #-1]
    //     0x6ee17c: and             x16, x17, x16, lsr #2
    //     0x6ee180: tst             x16, HEAP, lsr #32
    //     0x6ee184: b.eq            #0x6ee18c
    //     0x6ee188: bl              #0xd6828c
    // 0x6ee18c: ldr             d0, [fp, #0x18]
    // 0x6ee190: r0 = inline_Allocate_Double()
    //     0x6ee190: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6ee194: add             x0, x0, #0x10
    //     0x6ee198: cmp             x1, x0
    //     0x6ee19c: b.ls            #0x6ee260
    //     0x6ee1a0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ee1a4: sub             x0, x0, #0xf
    //     0x6ee1a8: mov             x1, #0xd108
    //     0x6ee1ac: movk            x1, #3, lsl #16
    //     0x6ee1b0: stur            x1, [x0, #-1]
    // 0x6ee1b4: StoreField: r0->field_7 = d0
    //     0x6ee1b4: stur            d0, [x0, #7]
    // 0x6ee1b8: stur            x0, [fp, #-8]
    // 0x6ee1bc: r1 = <double>
    //     0x6ee1bc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x6ee1c0: r0 = AnimationController()
    //     0x6ee1c0: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x6ee1c4: stur            x0, [fp, #-0x10]
    // 0x6ee1c8: ldr             x16, [fp, #0x10]
    // 0x6ee1cc: stp             x16, x0, [SP, #-0x10]!
    // 0x6ee1d0: ldur            x16, [fp, #-8]
    // 0x6ee1d4: r30 = Instance_Duration
    //     0x6ee1d4: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x6ee1d8: ldr             lr, [lr, #0x718]
    // 0x6ee1dc: stp             lr, x16, [SP, #-0x10]!
    // 0x6ee1e0: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x3, value, 0x2, null]
    //     0x6ee1e0: add             x4, PP, #0x21, lsl #12  ; [pp+0x21ff8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x3, "value", 0x2, Null]
    //     0x6ee1e4: ldr             x4, [x4, #0xff8]
    // 0x6ee1e8: r0 = AnimationController()
    //     0x6ee1e8: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x6ee1ec: add             SP, SP, #0x20
    // 0x6ee1f0: r1 = 1
    //     0x6ee1f0: mov             x1, #1
    // 0x6ee1f4: r0 = AllocateContext()
    //     0x6ee1f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6ee1f8: mov             x1, x0
    // 0x6ee1fc: ldr             x0, [fp, #0x50]
    // 0x6ee200: StoreField: r1->field_f = r0
    //     0x6ee200: stur            w0, [x1, #0xf]
    // 0x6ee204: mov             x2, x1
    // 0x6ee208: r1 = Function 'markNeedsPaint':.
    //     0x6ee208: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1cf60] AnonymousClosure: (0x652ca8), in [package:flutter/src/rendering/object.dart] RenderObject::markNeedsPaint (0x6bf200)
    //     0x6ee20c: ldr             x1, [x1, #0xf60]
    // 0x6ee210: r0 = AllocateClosure()
    //     0x6ee210: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6ee214: ldur            x16, [fp, #-0x10]
    // 0x6ee218: stp             x0, x16, [SP, #-0x10]!
    // 0x6ee21c: r0 = addActionListener()
    //     0x6ee21c: bl              #0xa82eac  ; [package:flutter/src/widgets/actions.dart] Action::addActionListener
    // 0x6ee220: add             SP, SP, #0x10
    // 0x6ee224: ldur            x0, [fp, #-0x10]
    // 0x6ee228: ldr             x1, [fp, #0x50]
    // 0x6ee22c: StoreField: r1->field_8f = r0
    //     0x6ee22c: stur            w0, [x1, #0x8f]
    //     0x6ee230: ldurb           w16, [x1, #-1]
    //     0x6ee234: ldurb           w17, [x0, #-1]
    //     0x6ee238: and             x16, x17, x16, lsr #2
    //     0x6ee23c: tst             x16, HEAP, lsr #32
    //     0x6ee240: b.eq            #0x6ee248
    //     0x6ee244: bl              #0xd6826c
    // 0x6ee248: r0 = Null
    //     0x6ee248: mov             x0, NULL
    // 0x6ee24c: LeaveFrame
    //     0x6ee24c: mov             SP, fp
    //     0x6ee250: ldp             fp, lr, [SP], #0x10
    // 0x6ee254: ret
    //     0x6ee254: ret             
    // 0x6ee258: r0 = StackOverflowSharedWithFPURegs()
    //     0x6ee258: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x6ee25c: b               #0x6edf88
    // 0x6ee260: SaveReg d0
    //     0x6ee260: str             q0, [SP, #-0x10]!
    // 0x6ee264: SaveReg r2
    //     0x6ee264: str             x2, [SP, #-8]!
    // 0x6ee268: r0 = AllocateDouble()
    //     0x6ee268: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6ee26c: RestoreReg r2
    //     0x6ee26c: ldr             x2, [SP], #8
    // 0x6ee270: RestoreReg d0
    //     0x6ee270: ldr             q0, [SP], #0x10
    // 0x6ee274: b               #0x6ee1b4
  }
  [closure] void _handleDragEnd(dynamic, DragEndDetails) {
    // ** addr: 0x6ee4f4, size: 0x4c
    // 0x6ee4f4: EnterFrame
    //     0x6ee4f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee4f8: mov             fp, SP
    // 0x6ee4fc: ldr             x0, [fp, #0x18]
    // 0x6ee500: LoadField: r1 = r0->field_17
    //     0x6ee500: ldur            w1, [x0, #0x17]
    // 0x6ee504: DecompressPointer r1
    //     0x6ee504: add             x1, x1, HEAP, lsl #32
    // 0x6ee508: CheckStackOverflow
    //     0x6ee508: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee50c: cmp             SP, x16
    //     0x6ee510: b.ls            #0x6ee538
    // 0x6ee514: LoadField: r0 = r1->field_f
    //     0x6ee514: ldur            w0, [x1, #0xf]
    // 0x6ee518: DecompressPointer r0
    //     0x6ee518: add             x0, x0, HEAP, lsl #32
    // 0x6ee51c: SaveReg r0
    //     0x6ee51c: str             x0, [SP, #-8]!
    // 0x6ee520: r0 = _endInteraction()
    //     0x6ee520: bl              #0x6ee540  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_endInteraction
    // 0x6ee524: add             SP, SP, #8
    // 0x6ee528: r0 = Null
    //     0x6ee528: mov             x0, NULL
    // 0x6ee52c: LeaveFrame
    //     0x6ee52c: mov             SP, fp
    //     0x6ee530: ldp             fp, lr, [SP], #0x10
    // 0x6ee534: ret
    //     0x6ee534: ret             
    // 0x6ee538: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee538: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee53c: b               #0x6ee514
  }
  _ _endInteraction(/* No info */) {
    // ** addr: 0x6ee540, size: 0xbc
    // 0x6ee540: EnterFrame
    //     0x6ee540: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee544: mov             fp, SP
    // 0x6ee548: AllocStack(0x8)
    //     0x6ee548: sub             SP, SP, #8
    // 0x6ee54c: CheckStackOverflow
    //     0x6ee54c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee550: cmp             SP, x16
    //     0x6ee554: b.ls            #0x6ee5e4
    // 0x6ee558: ldr             x0, [fp, #0x10]
    // 0x6ee55c: LoadField: r1 = r0->field_87
    //     0x6ee55c: ldur            w1, [x0, #0x87]
    // 0x6ee560: DecompressPointer r1
    //     0x6ee560: add             x1, x1, HEAP, lsl #32
    // 0x6ee564: stur            x1, [fp, #-8]
    // 0x6ee568: cmp             w1, NULL
    // 0x6ee56c: b.ne            #0x6ee578
    // 0x6ee570: mov             x1, x0
    // 0x6ee574: b               #0x6ee5cc
    // 0x6ee578: SaveReg r0
    //     0x6ee578: str             x0, [SP, #-8]!
    // 0x6ee57c: r0 = _discretizedCurrentDragValue()
    //     0x6ee57c: bl              #0x6ee5fc  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_discretizedCurrentDragValue
    // 0x6ee580: add             SP, SP, #8
    // 0x6ee584: r0 = inline_Allocate_Double()
    //     0x6ee584: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x6ee588: add             x0, x0, #0x10
    //     0x6ee58c: cmp             x1, x0
    //     0x6ee590: b.ls            #0x6ee5ec
    //     0x6ee594: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ee598: sub             x0, x0, #0xf
    //     0x6ee59c: mov             x1, #0xd108
    //     0x6ee5a0: movk            x1, #3, lsl #16
    //     0x6ee5a4: stur            x1, [x0, #-1]
    // 0x6ee5a8: StoreField: r0->field_7 = d0
    //     0x6ee5a8: stur            d0, [x0, #7]
    // 0x6ee5ac: ldur            x16, [fp, #-8]
    // 0x6ee5b0: stp             x0, x16, [SP, #-0x10]!
    // 0x6ee5b4: ldur            x0, [fp, #-8]
    // 0x6ee5b8: ClosureCall
    //     0x6ee5b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ee5bc: ldur            x2, [x0, #0x1f]
    //     0x6ee5c0: blr             x2
    // 0x6ee5c4: add             SP, SP, #0x10
    // 0x6ee5c8: ldr             x1, [fp, #0x10]
    // 0x6ee5cc: d0 = 0.000000
    //     0x6ee5cc: eor             v0.16b, v0.16b, v0.16b
    // 0x6ee5d0: StoreField: r1->field_97 = d0
    //     0x6ee5d0: stur            d0, [x1, #0x97]
    // 0x6ee5d4: r0 = Null
    //     0x6ee5d4: mov             x0, NULL
    // 0x6ee5d8: LeaveFrame
    //     0x6ee5d8: mov             SP, fp
    //     0x6ee5dc: ldp             fp, lr, [SP], #0x10
    // 0x6ee5e0: ret
    //     0x6ee5e0: ret             
    // 0x6ee5e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee5e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee5e8: b               #0x6ee558
    // 0x6ee5ec: SaveReg d0
    //     0x6ee5ec: str             q0, [SP, #-0x10]!
    // 0x6ee5f0: r0 = AllocateDouble()
    //     0x6ee5f0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6ee5f4: RestoreReg d0
    //     0x6ee5f4: ldr             q0, [SP], #0x10
    // 0x6ee5f8: b               #0x6ee5a8
  }
  get _ _discretizedCurrentDragValue(/* No info */) {
    // ** addr: 0x6ee5fc, size: 0x50
    // 0x6ee5fc: d1 = 0.000000
    //     0x6ee5fc: eor             v1.16b, v1.16b, v1.16b
    // 0x6ee600: ldr             x0, [SP]
    // 0x6ee604: LoadField: d2 = r0->field_97
    //     0x6ee604: ldur            d2, [x0, #0x97]
    // 0x6ee608: fcmp            d2, d1
    // 0x6ee60c: b.vs            #0x6ee61c
    // 0x6ee610: b.ge            #0x6ee61c
    // 0x6ee614: d0 = 0.000000
    //     0x6ee614: eor             v0.16b, v0.16b, v0.16b
    // 0x6ee618: b               #0x6ee648
    // 0x6ee61c: d1 = 1.000000
    //     0x6ee61c: fmov            d1, #1.00000000
    // 0x6ee620: fcmp            d2, d1
    // 0x6ee624: b.vs            #0x6ee634
    // 0x6ee628: b.le            #0x6ee634
    // 0x6ee62c: d0 = 1.000000
    //     0x6ee62c: fmov            d0, #1.00000000
    // 0x6ee630: b               #0x6ee648
    // 0x6ee634: fcmp            d2, d2
    // 0x6ee638: b.vc            #0x6ee644
    // 0x6ee63c: d0 = 1.000000
    //     0x6ee63c: fmov            d0, #1.00000000
    // 0x6ee640: b               #0x6ee648
    // 0x6ee644: mov             v0.16b, v2.16b
    // 0x6ee648: ret
    //     0x6ee648: ret             
  }
  [closure] void _handleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x6ee64c, size: 0x4c
    // 0x6ee64c: EnterFrame
    //     0x6ee64c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee650: mov             fp, SP
    // 0x6ee654: ldr             x0, [fp, #0x18]
    // 0x6ee658: LoadField: r1 = r0->field_17
    //     0x6ee658: ldur            w1, [x0, #0x17]
    // 0x6ee65c: DecompressPointer r1
    //     0x6ee65c: add             x1, x1, HEAP, lsl #32
    // 0x6ee660: CheckStackOverflow
    //     0x6ee660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee664: cmp             SP, x16
    //     0x6ee668: b.ls            #0x6ee690
    // 0x6ee66c: LoadField: r0 = r1->field_f
    //     0x6ee66c: ldur            w0, [x1, #0xf]
    // 0x6ee670: DecompressPointer r0
    //     0x6ee670: add             x0, x0, HEAP, lsl #32
    // 0x6ee674: ldr             x16, [fp, #0x10]
    // 0x6ee678: stp             x16, x0, [SP, #-0x10]!
    // 0x6ee67c: r0 = _handleDragUpdate()
    //     0x6ee67c: bl              #0x6ee698  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_handleDragUpdate
    // 0x6ee680: add             SP, SP, #0x10
    // 0x6ee684: LeaveFrame
    //     0x6ee684: mov             SP, fp
    //     0x6ee688: ldp             fp, lr, [SP], #0x10
    // 0x6ee68c: ret
    //     0x6ee68c: ret             
    // 0x6ee690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee694: b               #0x6ee66c
  }
  _ _handleDragUpdate(/* No info */) {
    // ** addr: 0x6ee698, size: 0x1b0
    // 0x6ee698: EnterFrame
    //     0x6ee698: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee69c: mov             fp, SP
    // 0x6ee6a0: CheckStackOverflow
    //     0x6ee6a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee6a4: cmp             SP, x16
    //     0x6ee6a8: b.ls            #0x6ee820
    // 0x6ee6ac: ldr             x0, [fp, #0x18]
    // 0x6ee6b0: LoadField: r1 = r0->field_7f
    //     0x6ee6b0: ldur            w1, [x0, #0x7f]
    // 0x6ee6b4: DecompressPointer r1
    //     0x6ee6b4: add             x1, x1, HEAP, lsl #32
    // 0x6ee6b8: cmp             w1, NULL
    // 0x6ee6bc: b.eq            #0x6ee810
    // 0x6ee6c0: d1 = 44.000000
    //     0x6ee6c0: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dc30] IMM: double(44) from 0x4046000000000000
    //     0x6ee6c4: ldr             d1, [x17, #0xc30]
    // 0x6ee6c8: d0 = 8.000000
    //     0x6ee6c8: fmov            d0, #8.00000000
    // 0x6ee6cc: LoadField: r2 = r0->field_57
    //     0x6ee6cc: ldur            w2, [x0, #0x57]
    // 0x6ee6d0: DecompressPointer r2
    //     0x6ee6d0: add             x2, x2, HEAP, lsl #32
    // 0x6ee6d4: cmp             w2, NULL
    // 0x6ee6d8: b.eq            #0x6ee828
    // 0x6ee6dc: LoadField: d2 = r2->field_7
    //     0x6ee6dc: ldur            d2, [x2, #7]
    // 0x6ee6e0: fsub            d3, d2, d1
    // 0x6ee6e4: fcmp            d0, d3
    // 0x6ee6e8: b.vs            #0x6ee6fc
    // 0x6ee6ec: b.le            #0x6ee6fc
    // 0x6ee6f0: d0 = 8.000000
    //     0x6ee6f0: fmov            d0, #8.00000000
    // 0x6ee6f4: d1 = 0.000000
    //     0x6ee6f4: eor             v1.16b, v1.16b, v1.16b
    // 0x6ee6f8: b               #0x6ee744
    // 0x6ee6fc: fcmp            d0, d3
    // 0x6ee700: b.vs            #0x6ee714
    // 0x6ee704: b.ge            #0x6ee714
    // 0x6ee708: mov             v0.16b, v3.16b
    // 0x6ee70c: d1 = 0.000000
    //     0x6ee70c: eor             v1.16b, v1.16b, v1.16b
    // 0x6ee710: b               #0x6ee744
    // 0x6ee714: d1 = 0.000000
    //     0x6ee714: eor             v1.16b, v1.16b, v1.16b
    // 0x6ee718: fcmp            d0, d1
    // 0x6ee71c: b.vs            #0x6ee730
    // 0x6ee720: b.ne            #0x6ee730
    // 0x6ee724: fadd            d2, d0, d3
    // 0x6ee728: mov             v0.16b, v2.16b
    // 0x6ee72c: b               #0x6ee744
    // 0x6ee730: fcmp            d3, d3
    // 0x6ee734: b.vc            #0x6ee740
    // 0x6ee738: mov             v0.16b, v3.16b
    // 0x6ee73c: b               #0x6ee744
    // 0x6ee740: d0 = 8.000000
    //     0x6ee740: fmov            d0, #8.00000000
    // 0x6ee744: ldr             x2, [fp, #0x10]
    // 0x6ee748: LoadField: r3 = r2->field_f
    //     0x6ee748: ldur            w3, [x2, #0xf]
    // 0x6ee74c: DecompressPointer r3
    //     0x6ee74c: add             x3, x3, HEAP, lsl #32
    // 0x6ee750: cmp             w3, NULL
    // 0x6ee754: b.eq            #0x6ee82c
    // 0x6ee758: LoadField: d2 = r3->field_7
    //     0x6ee758: ldur            d2, [x3, #7]
    // 0x6ee75c: fdiv            d3, d2, d0
    // 0x6ee760: LoadField: r2 = r0->field_8b
    //     0x6ee760: ldur            w2, [x0, #0x8b]
    // 0x6ee764: DecompressPointer r2
    //     0x6ee764: add             x2, x2, HEAP, lsl #32
    // 0x6ee768: LoadField: r3 = r2->field_7
    //     0x6ee768: ldur            x3, [x2, #7]
    // 0x6ee76c: cmp             x3, #0
    // 0x6ee770: b.gt            #0x6ee788
    // 0x6ee774: LoadField: d0 = r0->field_97
    //     0x6ee774: ldur            d0, [x0, #0x97]
    // 0x6ee778: fsub            d2, d0, d3
    // 0x6ee77c: StoreField: r0->field_97 = d2
    //     0x6ee77c: stur            d2, [x0, #0x97]
    // 0x6ee780: mov             v0.16b, v2.16b
    // 0x6ee784: b               #0x6ee798
    // 0x6ee788: LoadField: d0 = r0->field_97
    //     0x6ee788: ldur            d0, [x0, #0x97]
    // 0x6ee78c: fadd            d2, d0, d3
    // 0x6ee790: StoreField: r0->field_97 = d2
    //     0x6ee790: stur            d2, [x0, #0x97]
    // 0x6ee794: mov             v0.16b, v2.16b
    // 0x6ee798: fcmp            d0, d1
    // 0x6ee79c: b.vs            #0x6ee7ac
    // 0x6ee7a0: b.ge            #0x6ee7ac
    // 0x6ee7a4: d0 = 0.000000
    //     0x6ee7a4: eor             v0.16b, v0.16b, v0.16b
    // 0x6ee7a8: b               #0x6ee7d0
    // 0x6ee7ac: d1 = 1.000000
    //     0x6ee7ac: fmov            d1, #1.00000000
    // 0x6ee7b0: fcmp            d0, d1
    // 0x6ee7b4: b.vs            #0x6ee7c4
    // 0x6ee7b8: b.le            #0x6ee7c4
    // 0x6ee7bc: d0 = 1.000000
    //     0x6ee7bc: fmov            d0, #1.00000000
    // 0x6ee7c0: b               #0x6ee7d0
    // 0x6ee7c4: fcmp            d0, d0
    // 0x6ee7c8: b.vc            #0x6ee7d0
    // 0x6ee7cc: d0 = 1.000000
    //     0x6ee7cc: fmov            d0, #1.00000000
    // 0x6ee7d0: r0 = inline_Allocate_Double()
    //     0x6ee7d0: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6ee7d4: add             x0, x0, #0x10
    //     0x6ee7d8: cmp             x2, x0
    //     0x6ee7dc: b.ls            #0x6ee830
    //     0x6ee7e0: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ee7e4: sub             x0, x0, #0xf
    //     0x6ee7e8: mov             x2, #0xd108
    //     0x6ee7ec: movk            x2, #3, lsl #16
    //     0x6ee7f0: stur            x2, [x0, #-1]
    // 0x6ee7f4: StoreField: r0->field_7 = d0
    //     0x6ee7f4: stur            d0, [x0, #7]
    // 0x6ee7f8: stp             x0, x1, [SP, #-0x10]!
    // 0x6ee7fc: mov             x0, x1
    // 0x6ee800: ClosureCall
    //     0x6ee800: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ee804: ldur            x2, [x0, #0x1f]
    //     0x6ee808: blr             x2
    // 0x6ee80c: add             SP, SP, #0x10
    // 0x6ee810: r0 = Null
    //     0x6ee810: mov             x0, NULL
    // 0x6ee814: LeaveFrame
    //     0x6ee814: mov             SP, fp
    //     0x6ee818: ldp             fp, lr, [SP], #0x10
    // 0x6ee81c: ret
    //     0x6ee81c: ret             
    // 0x6ee820: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee820: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee824: b               #0x6ee6ac
    // 0x6ee828: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6ee828: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6ee82c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6ee82c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6ee830: SaveReg d0
    //     0x6ee830: str             q0, [SP, #-0x10]!
    // 0x6ee834: SaveReg r1
    //     0x6ee834: str             x1, [SP, #-8]!
    // 0x6ee838: r0 = AllocateDouble()
    //     0x6ee838: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6ee83c: RestoreReg r1
    //     0x6ee83c: ldr             x1, [SP], #8
    // 0x6ee840: RestoreReg d0
    //     0x6ee840: ldr             q0, [SP], #0x10
    // 0x6ee844: b               #0x6ee7f4
  }
  [closure] void _handleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x6ee848, size: 0x4c
    // 0x6ee848: EnterFrame
    //     0x6ee848: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee84c: mov             fp, SP
    // 0x6ee850: ldr             x0, [fp, #0x18]
    // 0x6ee854: LoadField: r1 = r0->field_17
    //     0x6ee854: ldur            w1, [x0, #0x17]
    // 0x6ee858: DecompressPointer r1
    //     0x6ee858: add             x1, x1, HEAP, lsl #32
    // 0x6ee85c: CheckStackOverflow
    //     0x6ee85c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee860: cmp             SP, x16
    //     0x6ee864: b.ls            #0x6ee88c
    // 0x6ee868: LoadField: r0 = r1->field_f
    //     0x6ee868: ldur            w0, [x1, #0xf]
    // 0x6ee86c: DecompressPointer r0
    //     0x6ee86c: add             x0, x0, HEAP, lsl #32
    // 0x6ee870: SaveReg r0
    //     0x6ee870: str             x0, [SP, #-8]!
    // 0x6ee874: r0 = _startInteraction()
    //     0x6ee874: bl              #0x6ee894  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_startInteraction
    // 0x6ee878: add             SP, SP, #8
    // 0x6ee87c: r0 = Null
    //     0x6ee87c: mov             x0, NULL
    // 0x6ee880: LeaveFrame
    //     0x6ee880: mov             SP, fp
    //     0x6ee884: ldp             fp, lr, [SP], #0x10
    // 0x6ee888: ret
    //     0x6ee888: ret             
    // 0x6ee88c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ee88c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ee890: b               #0x6ee868
  }
  _ _startInteraction(/* No info */) {
    // ** addr: 0x6ee894, size: 0x1b8
    // 0x6ee894: EnterFrame
    //     0x6ee894: stp             fp, lr, [SP, #-0x10]!
    //     0x6ee898: mov             fp, SP
    // 0x6ee89c: CheckStackOverflow
    //     0x6ee89c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ee8a0: cmp             SP, x16
    //     0x6ee8a4: b.ls            #0x6eea04
    // 0x6ee8a8: ldr             x1, [fp, #0x10]
    // 0x6ee8ac: LoadField: r0 = r1->field_7f
    //     0x6ee8ac: ldur            w0, [x1, #0x7f]
    // 0x6ee8b0: DecompressPointer r0
    //     0x6ee8b0: add             x0, x0, HEAP, lsl #32
    // 0x6ee8b4: cmp             w0, NULL
    // 0x6ee8b8: b.eq            #0x6ee9f4
    // 0x6ee8bc: LoadField: r0 = r1->field_83
    //     0x6ee8bc: ldur            w0, [x1, #0x83]
    // 0x6ee8c0: DecompressPointer r0
    //     0x6ee8c0: add             x0, x0, HEAP, lsl #32
    // 0x6ee8c4: cmp             w0, NULL
    // 0x6ee8c8: b.ne            #0x6ee8d4
    // 0x6ee8cc: mov             x0, x1
    // 0x6ee8d0: b               #0x6ee958
    // 0x6ee8d4: d0 = 0.000000
    //     0x6ee8d4: eor             v0.16b, v0.16b, v0.16b
    // 0x6ee8d8: LoadField: d1 = r1->field_97
    //     0x6ee8d8: ldur            d1, [x1, #0x97]
    // 0x6ee8dc: fcmp            d1, d0
    // 0x6ee8e0: b.vs            #0x6ee8f4
    // 0x6ee8e4: b.ge            #0x6ee8f4
    // 0x6ee8e8: d1 = 0.000000
    //     0x6ee8e8: eor             v1.16b, v1.16b, v1.16b
    // 0x6ee8ec: d2 = 1.000000
    //     0x6ee8ec: fmov            d2, #1.00000000
    // 0x6ee8f0: b               #0x6ee918
    // 0x6ee8f4: d2 = 1.000000
    //     0x6ee8f4: fmov            d2, #1.00000000
    // 0x6ee8f8: fcmp            d1, d2
    // 0x6ee8fc: b.vs            #0x6ee90c
    // 0x6ee900: b.le            #0x6ee90c
    // 0x6ee904: d1 = 1.000000
    //     0x6ee904: fmov            d1, #1.00000000
    // 0x6ee908: b               #0x6ee918
    // 0x6ee90c: fcmp            d1, d1
    // 0x6ee910: b.vc            #0x6ee918
    // 0x6ee914: d1 = 1.000000
    //     0x6ee914: fmov            d1, #1.00000000
    // 0x6ee918: r2 = inline_Allocate_Double()
    //     0x6ee918: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x6ee91c: add             x2, x2, #0x10
    //     0x6ee920: cmp             x3, x2
    //     0x6ee924: b.ls            #0x6eea0c
    //     0x6ee928: str             x2, [THR, #0x60]  ; THR::top
    //     0x6ee92c: sub             x2, x2, #0xf
    //     0x6ee930: mov             x3, #0xd108
    //     0x6ee934: movk            x3, #3, lsl #16
    //     0x6ee938: stur            x3, [x2, #-1]
    // 0x6ee93c: StoreField: r2->field_7 = d1
    //     0x6ee93c: stur            d1, [x2, #7]
    // 0x6ee940: stp             x2, x0, [SP, #-0x10]!
    // 0x6ee944: ClosureCall
    //     0x6ee944: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ee948: ldur            x2, [x0, #0x1f]
    //     0x6ee94c: blr             x2
    // 0x6ee950: add             SP, SP, #0x10
    // 0x6ee954: ldr             x0, [fp, #0x10]
    // 0x6ee958: d0 = 0.000000
    //     0x6ee958: eor             v0.16b, v0.16b, v0.16b
    // 0x6ee95c: LoadField: d1 = r0->field_67
    //     0x6ee95c: ldur            d1, [x0, #0x67]
    // 0x6ee960: StoreField: r0->field_97 = d1
    //     0x6ee960: stur            d1, [x0, #0x97]
    // 0x6ee964: LoadField: r1 = r0->field_7f
    //     0x6ee964: ldur            w1, [x0, #0x7f]
    // 0x6ee968: DecompressPointer r1
    //     0x6ee968: add             x1, x1, HEAP, lsl #32
    // 0x6ee96c: cmp             w1, NULL
    // 0x6ee970: b.eq            #0x6eea30
    // 0x6ee974: fcmp            d1, d0
    // 0x6ee978: b.vs            #0x6ee988
    // 0x6ee97c: b.ge            #0x6ee988
    // 0x6ee980: d0 = 0.000000
    //     0x6ee980: eor             v0.16b, v0.16b, v0.16b
    // 0x6ee984: b               #0x6ee9b4
    // 0x6ee988: d0 = 1.000000
    //     0x6ee988: fmov            d0, #1.00000000
    // 0x6ee98c: fcmp            d1, d0
    // 0x6ee990: b.vs            #0x6ee9a0
    // 0x6ee994: b.le            #0x6ee9a0
    // 0x6ee998: d0 = 1.000000
    //     0x6ee998: fmov            d0, #1.00000000
    // 0x6ee99c: b               #0x6ee9b4
    // 0x6ee9a0: fcmp            d1, d1
    // 0x6ee9a4: b.vc            #0x6ee9b0
    // 0x6ee9a8: d0 = 1.000000
    //     0x6ee9a8: fmov            d0, #1.00000000
    // 0x6ee9ac: b               #0x6ee9b4
    // 0x6ee9b0: mov             v0.16b, v1.16b
    // 0x6ee9b4: r0 = inline_Allocate_Double()
    //     0x6ee9b4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x6ee9b8: add             x0, x0, #0x10
    //     0x6ee9bc: cmp             x2, x0
    //     0x6ee9c0: b.ls            #0x6eea34
    //     0x6ee9c4: str             x0, [THR, #0x60]  ; THR::top
    //     0x6ee9c8: sub             x0, x0, #0xf
    //     0x6ee9cc: mov             x2, #0xd108
    //     0x6ee9d0: movk            x2, #3, lsl #16
    //     0x6ee9d4: stur            x2, [x0, #-1]
    // 0x6ee9d8: StoreField: r0->field_7 = d0
    //     0x6ee9d8: stur            d0, [x0, #7]
    // 0x6ee9dc: stp             x0, x1, [SP, #-0x10]!
    // 0x6ee9e0: mov             x0, x1
    // 0x6ee9e4: ClosureCall
    //     0x6ee9e4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x6ee9e8: ldur            x2, [x0, #0x1f]
    //     0x6ee9ec: blr             x2
    // 0x6ee9f0: add             SP, SP, #0x10
    // 0x6ee9f4: r0 = Null
    //     0x6ee9f4: mov             x0, NULL
    // 0x6ee9f8: LeaveFrame
    //     0x6ee9f8: mov             SP, fp
    //     0x6ee9fc: ldp             fp, lr, [SP], #0x10
    // 0x6eea00: ret
    //     0x6eea00: ret             
    // 0x6eea04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6eea04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6eea08: b               #0x6ee8a8
    // 0x6eea0c: stp             q1, q2, [SP, #-0x20]!
    // 0x6eea10: SaveReg d0
    //     0x6eea10: str             q0, [SP, #-0x10]!
    // 0x6eea14: stp             x0, x1, [SP, #-0x10]!
    // 0x6eea18: r0 = AllocateDouble()
    //     0x6eea18: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6eea1c: mov             x2, x0
    // 0x6eea20: ldp             x0, x1, [SP], #0x10
    // 0x6eea24: RestoreReg d0
    //     0x6eea24: ldr             q0, [SP], #0x10
    // 0x6eea28: ldp             q1, q2, [SP], #0x20
    // 0x6eea2c: b               #0x6ee93c
    // 0x6eea30: r0 = NullCastErrorSharedWithFPURegs()
    //     0x6eea30: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x6eea34: SaveReg d0
    //     0x6eea34: str             q0, [SP, #-0x10]!
    // 0x6eea38: SaveReg r1
    //     0x6eea38: str             x1, [SP, #-8]!
    // 0x6eea3c: r0 = AllocateDouble()
    //     0x6eea3c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x6eea40: RestoreReg r1
    //     0x6eea40: ldr             x1, [SP], #8
    // 0x6eea44: RestoreReg d0
    //     0x6eea44: ldr             q0, [SP], #0x10
    // 0x6eea48: b               #0x6ee9d8
  }
  _ handleEvent(/* No info */) {
    // ** addr: 0x715a34, size: 0xe8
    // 0x715a34: EnterFrame
    //     0x715a34: stp             fp, lr, [SP, #-0x10]!
    //     0x715a38: mov             fp, SP
    // 0x715a3c: CheckStackOverflow
    //     0x715a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x715a40: cmp             SP, x16
    //     0x715a44: b.ls            #0x715b08
    // 0x715a48: ldr             x0, [fp, #0x10]
    // 0x715a4c: r2 = Null
    //     0x715a4c: mov             x2, NULL
    // 0x715a50: r1 = Null
    //     0x715a50: mov             x1, NULL
    // 0x715a54: r4 = 59
    //     0x715a54: mov             x4, #0x3b
    // 0x715a58: branchIfSmi(r0, 0x715a64)
    //     0x715a58: tbz             w0, #0, #0x715a64
    // 0x715a5c: r4 = LoadClassIdInstr(r0)
    //     0x715a5c: ldur            x4, [x0, #-1]
    //     0x715a60: ubfx            x4, x4, #0xc, #0x14
    // 0x715a64: cmp             x4, #0x8f0
    // 0x715a68: b.eq            #0x715a80
    // 0x715a6c: r8 = BoxHitTestEntry<RenderBox>
    //     0x715a6c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb198] Type: BoxHitTestEntry<RenderBox>
    //     0x715a70: ldr             x8, [x8, #0x198]
    // 0x715a74: r3 = Null
    //     0x715a74: add             x3, PP, #0x57, lsl #12  ; [pp+0x57538] Null
    //     0x715a78: ldr             x3, [x3, #0x538]
    // 0x715a7c: r0 = DefaultTypeTest()
    //     0x715a7c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x715a80: ldr             x0, [fp, #0x18]
    // 0x715a84: r2 = Null
    //     0x715a84: mov             x2, NULL
    // 0x715a88: r1 = Null
    //     0x715a88: mov             x1, NULL
    // 0x715a8c: cmp             w0, NULL
    // 0x715a90: b.eq            #0x715ab0
    // 0x715a94: branchIfSmi(r0, 0x715ab0)
    //     0x715a94: tbz             w0, #0, #0x715ab0
    // 0x715a98: r3 = LoadClassIdInstr(r0)
    //     0x715a98: ldur            x3, [x0, #-1]
    //     0x715a9c: ubfx            x3, x3, #0xc, #0x14
    // 0x715aa0: cmp             x3, #0x90a
    // 0x715aa4: b.eq            #0x715ab8
    // 0x715aa8: cmp             x3, #0xb41
    // 0x715aac: b.eq            #0x715ab8
    // 0x715ab0: r0 = false
    //     0x715ab0: add             x0, NULL, #0x30  ; false
    // 0x715ab4: b               #0x715abc
    // 0x715ab8: r0 = true
    //     0x715ab8: add             x0, NULL, #0x20  ; true
    // 0x715abc: tbnz            w0, #4, #0x715af8
    // 0x715ac0: ldr             x0, [fp, #0x20]
    // 0x715ac4: LoadField: r1 = r0->field_7f
    //     0x715ac4: ldur            w1, [x0, #0x7f]
    // 0x715ac8: DecompressPointer r1
    //     0x715ac8: add             x1, x1, HEAP, lsl #32
    // 0x715acc: cmp             w1, NULL
    // 0x715ad0: b.eq            #0x715af8
    // 0x715ad4: LoadField: r1 = r0->field_93
    //     0x715ad4: ldur            w1, [x0, #0x93]
    // 0x715ad8: DecompressPointer r1
    //     0x715ad8: add             x1, x1, HEAP, lsl #32
    // 0x715adc: r16 = Sentinel
    //     0x715adc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x715ae0: cmp             w1, w16
    // 0x715ae4: b.eq            #0x715b10
    // 0x715ae8: ldr             x16, [fp, #0x18]
    // 0x715aec: stp             x16, x1, [SP, #-0x10]!
    // 0x715af0: r0 = addPointer()
    //     0x715af0: bl              #0x6fd9cc  ; [package:flutter/src/gestures/recognizer.dart] GestureRecognizer::addPointer
    // 0x715af4: add             SP, SP, #0x10
    // 0x715af8: r0 = Null
    //     0x715af8: mov             x0, NULL
    // 0x715afc: LeaveFrame
    //     0x715afc: mov             SP, fp
    //     0x715b00: ldp             fp, lr, [SP], #0x10
    // 0x715b04: ret
    //     0x715b04: ret             
    // 0x715b08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x715b08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x715b0c: b               #0x715a48
    // 0x715b10: r9 = _drag
    //     0x715b10: add             x9, PP, #0x57, lsl #12  ; [pp+0x57548] Field <_RenderCupertinoSlider@613348729._drag@613348729>: late (offset: 0x94)
    //     0x715b14: ldr             x9, [x9, #0x548]
    // 0x715b18: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x715b18: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ cursor(/* No info */) {
    // ** addr: 0xafb1c0, size: 0x8
    // 0xafb1c0: r0 = Instance__DeferringMouseCursor
    //     0xafb1c0: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0xafb1c4: ret
    //     0xafb1c4: ret             
  }
  get _ onExit(/* No info */) {
    // ** addr: 0xc54480, size: 0x10
    // 0xc54480: ldr             x1, [SP]
    // 0xc54484: LoadField: r0 = r1->field_a7
    //     0xc54484: ldur            w0, [x1, #0xa7]
    // 0xc54488: DecompressPointer r0
    //     0xc54488: add             x0, x0, HEAP, lsl #32
    // 0xc5448c: ret
    //     0xc5448c: ret             
  }
}

// class id: 3347, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __CupertinoSliderState&State&TickerProviderStateMixin extends State<CupertinoSlider>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x6155ec, size: 0x178
    // 0x6155ec: EnterFrame
    //     0x6155ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6155f0: mov             fp, SP
    // 0x6155f4: AllocStack(0x10)
    //     0x6155f4: sub             SP, SP, #0x10
    // 0x6155f8: CheckStackOverflow
    //     0x6155f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6155fc: cmp             SP, x16
    //     0x615600: b.ls            #0x615754
    // 0x615604: ldr             x0, [fp, #0x18]
    // 0x615608: LoadField: r1 = r0->field_17
    //     0x615608: ldur            w1, [x0, #0x17]
    // 0x61560c: DecompressPointer r1
    //     0x61560c: add             x1, x1, HEAP, lsl #32
    // 0x615610: cmp             w1, NULL
    // 0x615614: b.ne            #0x615624
    // 0x615618: SaveReg r0
    //     0x615618: str             x0, [SP, #-8]!
    // 0x61561c: r0 = _updateTickerModeNotifier()
    //     0x61561c: bl              #0x615788  ; [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x615620: add             SP, SP, #8
    // 0x615624: ldr             x0, [fp, #0x18]
    // 0x615628: LoadField: r1 = r0->field_13
    //     0x615628: ldur            w1, [x0, #0x13]
    // 0x61562c: DecompressPointer r1
    //     0x61562c: add             x1, x1, HEAP, lsl #32
    // 0x615630: cmp             w1, NULL
    // 0x615634: b.ne            #0x6156cc
    // 0x615638: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x615638: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x61563c: ldr             x0, [x0, #0x598]
    //     0x615640: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x615644: cmp             w0, w16
    //     0x615648: b.ne            #0x615654
    //     0x61564c: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x615650: bl              #0xd67cdc
    // 0x615654: r1 = <_WidgetTicker>
    //     0x615654: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x615658: ldr             x1, [x1, #0x210]
    // 0x61565c: stur            x0, [fp, #-8]
    // 0x615660: r0 = _Set()
    //     0x615660: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x615664: mov             x1, x0
    // 0x615668: ldur            x0, [fp, #-8]
    // 0x61566c: stur            x1, [fp, #-0x10]
    // 0x615670: StoreField: r1->field_1b = r0
    //     0x615670: stur            w0, [x1, #0x1b]
    // 0x615674: StoreField: r1->field_b = rZR
    //     0x615674: stur            wzr, [x1, #0xb]
    // 0x615678: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x615678: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x61567c: ldr             x0, [x0, #0x5a0]
    //     0x615680: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x615684: cmp             w0, w16
    //     0x615688: b.ne            #0x615694
    //     0x61568c: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x615690: bl              #0xd67cdc
    // 0x615694: mov             x1, x0
    // 0x615698: ldur            x0, [fp, #-0x10]
    // 0x61569c: StoreField: r0->field_f = r1
    //     0x61569c: stur            w1, [x0, #0xf]
    // 0x6156a0: StoreField: r0->field_13 = rZR
    //     0x6156a0: stur            wzr, [x0, #0x13]
    // 0x6156a4: StoreField: r0->field_17 = rZR
    //     0x6156a4: stur            wzr, [x0, #0x17]
    // 0x6156a8: ldr             x1, [fp, #0x18]
    // 0x6156ac: StoreField: r1->field_13 = r0
    //     0x6156ac: stur            w0, [x1, #0x13]
    //     0x6156b0: ldurb           w16, [x1, #-1]
    //     0x6156b4: ldurb           w17, [x0, #-1]
    //     0x6156b8: and             x16, x17, x16, lsr #2
    //     0x6156bc: tst             x16, HEAP, lsr #32
    //     0x6156c0: b.eq            #0x6156c8
    //     0x6156c4: bl              #0xd6826c
    // 0x6156c8: b               #0x6156d0
    // 0x6156cc: mov             x1, x0
    // 0x6156d0: ldr             x0, [fp, #0x10]
    // 0x6156d4: r0 = _WidgetTicker()
    //     0x6156d4: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x6156d8: mov             x1, x0
    // 0x6156dc: ldr             x0, [fp, #0x18]
    // 0x6156e0: stur            x1, [fp, #-8]
    // 0x6156e4: StoreField: r1->field_1b = r0
    //     0x6156e4: stur            w0, [x1, #0x1b]
    // 0x6156e8: r2 = false
    //     0x6156e8: add             x2, NULL, #0x30  ; false
    // 0x6156ec: StoreField: r1->field_b = r2
    //     0x6156ec: stur            w2, [x1, #0xb]
    // 0x6156f0: ldr             x2, [fp, #0x10]
    // 0x6156f4: StoreField: r1->field_13 = r2
    //     0x6156f4: stur            w2, [x1, #0x13]
    // 0x6156f8: LoadField: r2 = r0->field_17
    //     0x6156f8: ldur            w2, [x0, #0x17]
    // 0x6156fc: DecompressPointer r2
    //     0x6156fc: add             x2, x2, HEAP, lsl #32
    // 0x615700: cmp             w2, NULL
    // 0x615704: b.eq            #0x61575c
    // 0x615708: LoadField: r3 = r2->field_27
    //     0x615708: ldur            w3, [x2, #0x27]
    // 0x61570c: DecompressPointer r3
    //     0x61570c: add             x3, x3, HEAP, lsl #32
    // 0x615710: eor             x2, x3, #0x10
    // 0x615714: stp             x2, x1, [SP, #-0x10]!
    // 0x615718: r0 = muted=()
    //     0x615718: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x61571c: add             SP, SP, #0x10
    // 0x615720: ldr             x0, [fp, #0x18]
    // 0x615724: LoadField: r1 = r0->field_13
    //     0x615724: ldur            w1, [x0, #0x13]
    // 0x615728: DecompressPointer r1
    //     0x615728: add             x1, x1, HEAP, lsl #32
    // 0x61572c: cmp             w1, NULL
    // 0x615730: b.eq            #0x615760
    // 0x615734: ldur            x16, [fp, #-8]
    // 0x615738: stp             x16, x1, [SP, #-0x10]!
    // 0x61573c: r0 = add()
    //     0x61573c: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x615740: add             SP, SP, #0x10
    // 0x615744: ldur            x0, [fp, #-8]
    // 0x615748: LeaveFrame
    //     0x615748: mov             SP, fp
    //     0x61574c: ldp             fp, lr, [SP], #0x10
    // 0x615750: ret
    //     0x615750: ret             
    // 0x615754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615758: b               #0x615604
    // 0x61575c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61575c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x615760: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615760: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x615788, size: 0x11c
    // 0x615788: EnterFrame
    //     0x615788: stp             fp, lr, [SP, #-0x10]!
    //     0x61578c: mov             fp, SP
    // 0x615790: AllocStack(0x10)
    //     0x615790: sub             SP, SP, #0x10
    // 0x615794: CheckStackOverflow
    //     0x615794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x615798: cmp             SP, x16
    //     0x61579c: b.ls            #0x615898
    // 0x6157a0: ldr             x0, [fp, #0x10]
    // 0x6157a4: LoadField: r1 = r0->field_f
    //     0x6157a4: ldur            w1, [x0, #0xf]
    // 0x6157a8: DecompressPointer r1
    //     0x6157a8: add             x1, x1, HEAP, lsl #32
    // 0x6157ac: cmp             w1, NULL
    // 0x6157b0: b.eq            #0x6158a0
    // 0x6157b4: SaveReg r1
    //     0x6157b4: str             x1, [SP, #-8]!
    // 0x6157b8: r0 = getNotifier()
    //     0x6157b8: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6157bc: add             SP, SP, #8
    // 0x6157c0: mov             x1, x0
    // 0x6157c4: ldr             x0, [fp, #0x10]
    // 0x6157c8: stur            x1, [fp, #-0x10]
    // 0x6157cc: LoadField: r2 = r0->field_17
    //     0x6157cc: ldur            w2, [x0, #0x17]
    // 0x6157d0: DecompressPointer r2
    //     0x6157d0: add             x2, x2, HEAP, lsl #32
    // 0x6157d4: stur            x2, [fp, #-8]
    // 0x6157d8: cmp             w1, w2
    // 0x6157dc: b.ne            #0x6157f0
    // 0x6157e0: r0 = Null
    //     0x6157e0: mov             x0, NULL
    // 0x6157e4: LeaveFrame
    //     0x6157e4: mov             SP, fp
    //     0x6157e8: ldp             fp, lr, [SP], #0x10
    // 0x6157ec: ret
    //     0x6157ec: ret             
    // 0x6157f0: cmp             w2, NULL
    // 0x6157f4: b.eq            #0x615830
    // 0x6157f8: r1 = 1
    //     0x6157f8: mov             x1, #1
    // 0x6157fc: r0 = AllocateContext()
    //     0x6157fc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x615800: mov             x1, x0
    // 0x615804: ldr             x0, [fp, #0x10]
    // 0x615808: StoreField: r1->field_f = r0
    //     0x615808: stur            w0, [x1, #0xf]
    // 0x61580c: mov             x2, x1
    // 0x615810: r1 = Function '_updateTickers@156311458':.
    //     0x615810: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e38] AnonymousClosure: (0x6158a4), in [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickers (0x6158ec)
    //     0x615814: ldr             x1, [x1, #0xe38]
    // 0x615818: r0 = AllocateClosure()
    //     0x615818: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x61581c: ldur            x16, [fp, #-8]
    // 0x615820: stp             x0, x16, [SP, #-0x10]!
    // 0x615824: r0 = removeListener()
    //     0x615824: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x615828: add             SP, SP, #0x10
    // 0x61582c: ldr             x0, [fp, #0x10]
    // 0x615830: r1 = 1
    //     0x615830: mov             x1, #1
    // 0x615834: r0 = AllocateContext()
    //     0x615834: bl              #0xd68aa4  ; AllocateContextStub
    // 0x615838: mov             x1, x0
    // 0x61583c: ldr             x0, [fp, #0x10]
    // 0x615840: StoreField: r1->field_f = r0
    //     0x615840: stur            w0, [x1, #0xf]
    // 0x615844: mov             x2, x1
    // 0x615848: r1 = Function '_updateTickers@156311458':.
    //     0x615848: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e38] AnonymousClosure: (0x6158a4), in [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickers (0x6158ec)
    //     0x61584c: ldr             x1, [x1, #0xe38]
    // 0x615850: r0 = AllocateClosure()
    //     0x615850: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x615854: ldur            x16, [fp, #-0x10]
    // 0x615858: stp             x0, x16, [SP, #-0x10]!
    // 0x61585c: r0 = addListener()
    //     0x61585c: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x615860: add             SP, SP, #0x10
    // 0x615864: ldur            x0, [fp, #-0x10]
    // 0x615868: ldr             x1, [fp, #0x10]
    // 0x61586c: StoreField: r1->field_17 = r0
    //     0x61586c: stur            w0, [x1, #0x17]
    //     0x615870: ldurb           w16, [x1, #-1]
    //     0x615874: ldurb           w17, [x0, #-1]
    //     0x615878: and             x16, x17, x16, lsr #2
    //     0x61587c: tst             x16, HEAP, lsr #32
    //     0x615880: b.eq            #0x615888
    //     0x615884: bl              #0xd6826c
    // 0x615888: r0 = Null
    //     0x615888: mov             x0, NULL
    // 0x61588c: LeaveFrame
    //     0x61588c: mov             SP, fp
    //     0x615890: ldp             fp, lr, [SP], #0x10
    // 0x615894: ret
    //     0x615894: ret             
    // 0x615898: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615898: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61589c: b               #0x6157a0
    // 0x6158a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6158a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x6158a4, size: 0x48
    // 0x6158a4: EnterFrame
    //     0x6158a4: stp             fp, lr, [SP, #-0x10]!
    //     0x6158a8: mov             fp, SP
    // 0x6158ac: ldr             x0, [fp, #0x10]
    // 0x6158b0: LoadField: r1 = r0->field_17
    //     0x6158b0: ldur            w1, [x0, #0x17]
    // 0x6158b4: DecompressPointer r1
    //     0x6158b4: add             x1, x1, HEAP, lsl #32
    // 0x6158b8: CheckStackOverflow
    //     0x6158b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6158bc: cmp             SP, x16
    //     0x6158c0: b.ls            #0x6158e4
    // 0x6158c4: LoadField: r0 = r1->field_f
    //     0x6158c4: ldur            w0, [x1, #0xf]
    // 0x6158c8: DecompressPointer r0
    //     0x6158c8: add             x0, x0, HEAP, lsl #32
    // 0x6158cc: SaveReg r0
    //     0x6158cc: str             x0, [SP, #-8]!
    // 0x6158d0: r0 = _updateTickers()
    //     0x6158d0: bl              #0x6158ec  ; [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickers
    // 0x6158d4: add             SP, SP, #8
    // 0x6158d8: LeaveFrame
    //     0x6158d8: mov             SP, fp
    //     0x6158dc: ldp             fp, lr, [SP], #0x10
    // 0x6158e0: ret
    //     0x6158e0: ret             
    // 0x6158e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6158e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6158e8: b               #0x6158c4
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x6158ec, size: 0x150
    // 0x6158ec: EnterFrame
    //     0x6158ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6158f0: mov             fp, SP
    // 0x6158f4: AllocStack(0x20)
    //     0x6158f4: sub             SP, SP, #0x20
    // 0x6158f8: CheckStackOverflow
    //     0x6158f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6158fc: cmp             SP, x16
    //     0x615900: b.ls            #0x615a28
    // 0x615904: ldr             x0, [fp, #0x10]
    // 0x615908: LoadField: r1 = r0->field_13
    //     0x615908: ldur            w1, [x0, #0x13]
    // 0x61590c: DecompressPointer r1
    //     0x61590c: add             x1, x1, HEAP, lsl #32
    // 0x615910: cmp             w1, NULL
    // 0x615914: b.eq            #0x615a18
    // 0x615918: LoadField: r2 = r0->field_17
    //     0x615918: ldur            w2, [x0, #0x17]
    // 0x61591c: DecompressPointer r2
    //     0x61591c: add             x2, x2, HEAP, lsl #32
    // 0x615920: cmp             w2, NULL
    // 0x615924: b.eq            #0x615a30
    // 0x615928: LoadField: r0 = r2->field_27
    //     0x615928: ldur            w0, [x2, #0x27]
    // 0x61592c: DecompressPointer r0
    //     0x61592c: add             x0, x0, HEAP, lsl #32
    // 0x615930: eor             x2, x0, #0x10
    // 0x615934: stur            x2, [fp, #-8]
    // 0x615938: SaveReg r1
    //     0x615938: str             x1, [SP, #-8]!
    // 0x61593c: r0 = iterator()
    //     0x61593c: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x615940: add             SP, SP, #8
    // 0x615944: stur            x0, [fp, #-0x18]
    // 0x615948: LoadField: r2 = r0->field_7
    //     0x615948: ldur            w2, [x0, #7]
    // 0x61594c: DecompressPointer r2
    //     0x61594c: add             x2, x2, HEAP, lsl #32
    // 0x615950: stur            x2, [fp, #-0x10]
    // 0x615954: ldur            x1, [fp, #-8]
    // 0x615958: CheckStackOverflow
    //     0x615958: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x61595c: cmp             SP, x16
    //     0x615960: b.ls            #0x615a34
    // 0x615964: SaveReg r0
    //     0x615964: str             x0, [SP, #-8]!
    // 0x615968: r0 = moveNext()
    //     0x615968: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x61596c: add             SP, SP, #8
    // 0x615970: tbnz            w0, #4, #0x615a18
    // 0x615974: ldur            x3, [fp, #-0x18]
    // 0x615978: LoadField: r4 = r3->field_33
    //     0x615978: ldur            w4, [x3, #0x33]
    // 0x61597c: DecompressPointer r4
    //     0x61597c: add             x4, x4, HEAP, lsl #32
    // 0x615980: stur            x4, [fp, #-0x20]
    // 0x615984: cmp             w4, NULL
    // 0x615988: b.ne            #0x6159bc
    // 0x61598c: mov             x0, x4
    // 0x615990: ldur            x2, [fp, #-0x10]
    // 0x615994: r1 = Null
    //     0x615994: mov             x1, NULL
    // 0x615998: cmp             w2, NULL
    // 0x61599c: b.eq            #0x6159bc
    // 0x6159a0: LoadField: r4 = r2->field_17
    //     0x6159a0: ldur            w4, [x2, #0x17]
    // 0x6159a4: DecompressPointer r4
    //     0x6159a4: add             x4, x4, HEAP, lsl #32
    // 0x6159a8: r8 = X0
    //     0x6159a8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6159ac: LoadField: r9 = r4->field_7
    //     0x6159ac: ldur            x9, [x4, #7]
    // 0x6159b0: r3 = Null
    //     0x6159b0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56e40] Null
    //     0x6159b4: ldr             x3, [x3, #0xe40]
    // 0x6159b8: blr             x9
    // 0x6159bc: ldur            x1, [fp, #-8]
    // 0x6159c0: ldur            x0, [fp, #-0x20]
    // 0x6159c4: LoadField: r2 = r0->field_b
    //     0x6159c4: ldur            w2, [x0, #0xb]
    // 0x6159c8: DecompressPointer r2
    //     0x6159c8: add             x2, x2, HEAP, lsl #32
    // 0x6159cc: cmp             w1, w2
    // 0x6159d0: b.eq            #0x615a0c
    // 0x6159d4: StoreField: r0->field_b = r1
    //     0x6159d4: stur            w1, [x0, #0xb]
    // 0x6159d8: tbnz            w1, #4, #0x6159ec
    // 0x6159dc: SaveReg r0
    //     0x6159dc: str             x0, [SP, #-8]!
    // 0x6159e0: r0 = unscheduleTick()
    //     0x6159e0: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x6159e4: add             SP, SP, #8
    // 0x6159e8: b               #0x615a0c
    // 0x6159ec: SaveReg r0
    //     0x6159ec: str             x0, [SP, #-8]!
    // 0x6159f0: r0 = shouldScheduleTick()
    //     0x6159f0: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x6159f4: add             SP, SP, #8
    // 0x6159f8: tbnz            w0, #4, #0x615a0c
    // 0x6159fc: ldur            x16, [fp, #-0x20]
    // 0x615a00: SaveReg r16
    //     0x615a00: str             x16, [SP, #-8]!
    // 0x615a04: r0 = scheduleTick()
    //     0x615a04: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x615a08: add             SP, SP, #8
    // 0x615a0c: ldur            x0, [fp, #-0x18]
    // 0x615a10: ldur            x2, [fp, #-0x10]
    // 0x615a14: b               #0x615954
    // 0x615a18: r0 = Null
    //     0x615a18: mov             x0, NULL
    // 0x615a1c: LeaveFrame
    //     0x615a1c: mov             SP, fp
    //     0x615a20: ldp             fp, lr, [SP], #0x10
    // 0x615a24: ret
    //     0x615a24: ret             
    // 0x615a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615a2c: b               #0x615904
    // 0x615a30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x615a30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x615a34: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x615a34: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x615a38: b               #0x615964
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f1fc, size: 0x4c
    // 0x81f1fc: EnterFrame
    //     0x81f1fc: stp             fp, lr, [SP, #-0x10]!
    //     0x81f200: mov             fp, SP
    // 0x81f204: CheckStackOverflow
    //     0x81f204: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f208: cmp             SP, x16
    //     0x81f20c: b.ls            #0x81f240
    // 0x81f210: ldr             x16, [fp, #0x10]
    // 0x81f214: SaveReg r16
    //     0x81f214: str             x16, [SP, #-8]!
    // 0x81f218: r0 = _updateTickerModeNotifier()
    //     0x81f218: bl              #0x615788  ; [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f21c: add             SP, SP, #8
    // 0x81f220: ldr             x16, [fp, #0x10]
    // 0x81f224: SaveReg r16
    //     0x81f224: str             x16, [SP, #-8]!
    // 0x81f228: r0 = _updateTickers()
    //     0x81f228: bl              #0x6158ec  ; [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickers
    // 0x81f22c: add             SP, SP, #8
    // 0x81f230: r0 = Null
    //     0x81f230: mov             x0, NULL
    // 0x81f234: LeaveFrame
    //     0x81f234: mov             SP, fp
    //     0x81f238: ldp             fp, lr, [SP], #0x10
    // 0x81f23c: ret
    //     0x81f23c: ret             
    // 0x81f240: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f240: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f244: b               #0x81f210
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a888, size: 0x18
    // 0xa4a888: r4 = 7
    //     0xa4a888: mov             x4, #7
    // 0xa4a88c: r1 = Function 'dispose':.
    //     0xa4a88c: add             x17, PP, #0x56, lsl #12  ; [pp+0x56e30] AnonymousClosure: (0xa4a8a0), in [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::dispose (0xa509a0)
    //     0xa4a890: ldr             x1, [x17, #0xe30]
    // 0xa4a894: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a894: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a898: LoadField: r0 = r24->field_17
    //     0xa4a898: ldur            x0, [x24, #0x17]
    // 0xa4a89c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a8a0, size: 0x48
    // 0xa4a8a0: EnterFrame
    //     0xa4a8a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a8a4: mov             fp, SP
    // 0xa4a8a8: ldr             x0, [fp, #0x10]
    // 0xa4a8ac: LoadField: r1 = r0->field_17
    //     0xa4a8ac: ldur            w1, [x0, #0x17]
    // 0xa4a8b0: DecompressPointer r1
    //     0xa4a8b0: add             x1, x1, HEAP, lsl #32
    // 0xa4a8b4: CheckStackOverflow
    //     0xa4a8b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a8b8: cmp             SP, x16
    //     0xa4a8bc: b.ls            #0xa4a8e0
    // 0xa4a8c0: LoadField: r0 = r1->field_f
    //     0xa4a8c0: ldur            w0, [x1, #0xf]
    // 0xa4a8c4: DecompressPointer r0
    //     0xa4a8c4: add             x0, x0, HEAP, lsl #32
    // 0xa4a8c8: SaveReg r0
    //     0xa4a8c8: str             x0, [SP, #-8]!
    // 0xa4a8cc: r0 = dispose()
    //     0xa4a8cc: bl              #0xa509a0  ; [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::dispose
    // 0xa4a8d0: add             SP, SP, #8
    // 0xa4a8d4: LeaveFrame
    //     0xa4a8d4: mov             SP, fp
    //     0xa4a8d8: ldp             fp, lr, [SP], #0x10
    // 0xa4a8dc: ret
    //     0xa4a8dc: ret             
    // 0xa4a8e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a8e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a8e4: b               #0xa4a8c0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa509a0, size: 0x8c
    // 0xa509a0: EnterFrame
    //     0xa509a0: stp             fp, lr, [SP, #-0x10]!
    //     0xa509a4: mov             fp, SP
    // 0xa509a8: AllocStack(0x8)
    //     0xa509a8: sub             SP, SP, #8
    // 0xa509ac: CheckStackOverflow
    //     0xa509ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa509b0: cmp             SP, x16
    //     0xa509b4: b.ls            #0xa50a24
    // 0xa509b8: ldr             x0, [fp, #0x10]
    // 0xa509bc: LoadField: r1 = r0->field_17
    //     0xa509bc: ldur            w1, [x0, #0x17]
    // 0xa509c0: DecompressPointer r1
    //     0xa509c0: add             x1, x1, HEAP, lsl #32
    // 0xa509c4: stur            x1, [fp, #-8]
    // 0xa509c8: cmp             w1, NULL
    // 0xa509cc: b.ne            #0xa509d8
    // 0xa509d0: mov             x1, x0
    // 0xa509d4: b               #0xa50a10
    // 0xa509d8: r1 = 1
    //     0xa509d8: mov             x1, #1
    // 0xa509dc: r0 = AllocateContext()
    //     0xa509dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa509e0: mov             x1, x0
    // 0xa509e4: ldr             x0, [fp, #0x10]
    // 0xa509e8: StoreField: r1->field_f = r0
    //     0xa509e8: stur            w0, [x1, #0xf]
    // 0xa509ec: mov             x2, x1
    // 0xa509f0: r1 = Function '_updateTickers@156311458':.
    //     0xa509f0: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e38] AnonymousClosure: (0x6158a4), in [package:flutter/src/cupertino/slider.dart] __CupertinoSliderState&State&TickerProviderStateMixin::_updateTickers (0x6158ec)
    //     0xa509f4: ldr             x1, [x1, #0xe38]
    // 0xa509f8: r0 = AllocateClosure()
    //     0xa509f8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa509fc: ldur            x16, [fp, #-8]
    // 0xa50a00: stp             x0, x16, [SP, #-0x10]!
    // 0xa50a04: r0 = removeListener()
    //     0xa50a04: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa50a08: add             SP, SP, #0x10
    // 0xa50a0c: ldr             x1, [fp, #0x10]
    // 0xa50a10: StoreField: r1->field_17 = rNULL
    //     0xa50a10: stur            NULL, [x1, #0x17]
    // 0xa50a14: r0 = Null
    //     0xa50a14: mov             x0, NULL
    // 0xa50a18: LeaveFrame
    //     0xa50a18: mov             SP, fp
    //     0xa50a1c: ldp             fp, lr, [SP], #0x10
    // 0xa50a20: ret
    //     0xa50a20: ret             
    // 0xa50a24: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50a24: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50a28: b               #0xa509b8
  }
}

// class id: 3348, size: 0x1c, field offset: 0x1c
class _CupertinoSliderState extends __CupertinoSliderState&State&TickerProviderStateMixin {

  _ build(/* No info */) {
    // ** addr: 0x843f74, size: 0x1ac
    // 0x843f74: EnterFrame
    //     0x843f74: stp             fp, lr, [SP, #-0x10]!
    //     0x843f78: mov             fp, SP
    // 0x843f7c: AllocStack(0x18)
    //     0x843f7c: sub             SP, SP, #0x18
    // 0x843f80: CheckStackOverflow
    //     0x843f80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x843f84: cmp             SP, x16
    //     0x843f88: b.ls            #0x844110
    // 0x843f8c: ldr             x0, [fp, #0x18]
    // 0x843f90: LoadField: r1 = r0->field_b
    //     0x843f90: ldur            w1, [x0, #0xb]
    // 0x843f94: DecompressPointer r1
    //     0x843f94: add             x1, x1, HEAP, lsl #32
    // 0x843f98: cmp             w1, NULL
    // 0x843f9c: b.eq            #0x844118
    // 0x843fa0: LoadField: d0 = r1->field_b
    //     0x843fa0: ldur            d0, [x1, #0xb]
    // 0x843fa4: LoadField: d1 = r1->field_1f
    //     0x843fa4: ldur            d1, [x1, #0x1f]
    // 0x843fa8: fsub            d2, d0, d1
    // 0x843fac: LoadField: d0 = r1->field_27
    //     0x843fac: ldur            d0, [x1, #0x27]
    // 0x843fb0: fsub            d3, d0, d1
    // 0x843fb4: fdiv            d0, d2, d3
    // 0x843fb8: stur            d0, [fp, #-0x18]
    // 0x843fbc: ldr             x16, [fp, #0x10]
    // 0x843fc0: SaveReg r16
    //     0x843fc0: str             x16, [SP, #-8]!
    // 0x843fc4: r0 = of()
    //     0x843fc4: bl              #0x83d26c  ; [package:flutter/src/cupertino/theme.dart] CupertinoTheme::of
    // 0x843fc8: add             SP, SP, #8
    // 0x843fcc: r1 = LoadClassIdInstr(r0)
    //     0x843fcc: ldur            x1, [x0, #-1]
    //     0x843fd0: ubfx            x1, x1, #0xc, #0x14
    // 0x843fd4: lsl             x1, x1, #1
    // 0x843fd8: r17 = 5322
    //     0x843fd8: mov             x17, #0x14ca
    // 0x843fdc: cmp             w1, w17
    // 0x843fe0: b.ne            #0x844014
    // 0x843fe4: LoadField: r1 = r0->field_b
    //     0x843fe4: ldur            w1, [x0, #0xb]
    // 0x843fe8: DecompressPointer r1
    //     0x843fe8: add             x1, x1, HEAP, lsl #32
    // 0x843fec: cmp             w1, NULL
    // 0x843ff0: b.ne            #0x844008
    // 0x843ff4: LoadField: r1 = r0->field_1f
    //     0x843ff4: ldur            w1, [x0, #0x1f]
    // 0x843ff8: DecompressPointer r1
    //     0x843ff8: add             x1, x1, HEAP, lsl #32
    // 0x843ffc: LoadField: r0 = r1->field_b
    //     0x843ffc: ldur            w0, [x1, #0xb]
    // 0x844000: DecompressPointer r0
    //     0x844000: add             x0, x0, HEAP, lsl #32
    // 0x844004: b               #0x84400c
    // 0x844008: mov             x0, x1
    // 0x84400c: mov             x1, x0
    // 0x844010: b               #0x844054
    // 0x844014: LoadField: r1 = r0->field_27
    //     0x844014: ldur            w1, [x0, #0x27]
    // 0x844018: DecompressPointer r1
    //     0x844018: add             x1, x1, HEAP, lsl #32
    // 0x84401c: LoadField: r2 = r1->field_b
    //     0x84401c: ldur            w2, [x1, #0xb]
    // 0x844020: DecompressPointer r2
    //     0x844020: add             x2, x2, HEAP, lsl #32
    // 0x844024: cmp             w2, NULL
    // 0x844028: b.ne            #0x84404c
    // 0x84402c: LoadField: r1 = r0->field_23
    //     0x84402c: ldur            w1, [x0, #0x23]
    // 0x844030: DecompressPointer r1
    //     0x844030: add             x1, x1, HEAP, lsl #32
    // 0x844034: LoadField: r0 = r1->field_3f
    //     0x844034: ldur            w0, [x1, #0x3f]
    // 0x844038: DecompressPointer r0
    //     0x844038: add             x0, x0, HEAP, lsl #32
    // 0x84403c: LoadField: r1 = r0->field_b
    //     0x84403c: ldur            w1, [x0, #0xb]
    // 0x844040: DecompressPointer r1
    //     0x844040: add             x1, x1, HEAP, lsl #32
    // 0x844044: mov             x0, x1
    // 0x844048: b               #0x844050
    // 0x84404c: mov             x0, x2
    // 0x844050: mov             x1, x0
    // 0x844054: ldr             x0, [fp, #0x18]
    // 0x844058: ldr             x16, [fp, #0x10]
    // 0x84405c: stp             x16, x1, [SP, #-0x10]!
    // 0x844060: r0 = resolve()
    //     0x844060: bl              #0x6ca720  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolve
    // 0x844064: add             SP, SP, #0x10
    // 0x844068: mov             x1, x0
    // 0x84406c: ldr             x0, [fp, #0x18]
    // 0x844070: stur            x1, [fp, #-8]
    // 0x844074: LoadField: r2 = r0->field_b
    //     0x844074: ldur            w2, [x0, #0xb]
    // 0x844078: DecompressPointer r2
    //     0x844078: add             x2, x2, HEAP, lsl #32
    // 0x84407c: cmp             w2, NULL
    // 0x844080: b.eq            #0x84411c
    // 0x844084: LoadField: r3 = r2->field_13
    //     0x844084: ldur            w3, [x2, #0x13]
    // 0x844088: DecompressPointer r3
    //     0x844088: add             x3, x3, HEAP, lsl #32
    // 0x84408c: cmp             w3, NULL
    // 0x844090: b.eq            #0x8440c0
    // 0x844094: r1 = 1
    //     0x844094: mov             x1, #1
    // 0x844098: r0 = AllocateContext()
    //     0x844098: bl              #0xd68aa4  ; AllocateContextStub
    // 0x84409c: mov             x1, x0
    // 0x8440a0: ldr             x0, [fp, #0x18]
    // 0x8440a4: StoreField: r1->field_f = r0
    //     0x8440a4: stur            w0, [x1, #0xf]
    // 0x8440a8: mov             x2, x1
    // 0x8440ac: r1 = Function '_handleChanged@613348729':.
    //     0x8440ac: add             x1, PP, #0x56, lsl #12  ; [pp+0x56e50] AnonymousClosure: (0x84412c), in [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged (0x844178)
    //     0x8440b0: ldr             x1, [x1, #0xe50]
    // 0x8440b4: r0 = AllocateClosure()
    //     0x8440b4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8440b8: mov             x2, x0
    // 0x8440bc: b               #0x8440c4
    // 0x8440c0: r2 = Null
    //     0x8440c0: mov             x2, NULL
    // 0x8440c4: ldr             x0, [fp, #0x18]
    // 0x8440c8: ldur            d0, [fp, #-0x18]
    // 0x8440cc: ldur            x1, [fp, #-8]
    // 0x8440d0: stur            x2, [fp, #-0x10]
    // 0x8440d4: r0 = _CupertinoSliderRenderObjectWidget()
    //     0x8440d4: bl              #0x844120  ; Allocate_CupertinoSliderRenderObjectWidgetStub -> _CupertinoSliderRenderObjectWidget (size=0x30)
    // 0x8440d8: ldur            d0, [fp, #-0x18]
    // 0x8440dc: StoreField: r0->field_b = d0
    //     0x8440dc: stur            d0, [x0, #0xb]
    // 0x8440e0: ldur            x1, [fp, #-8]
    // 0x8440e4: StoreField: r0->field_17 = r1
    //     0x8440e4: stur            w1, [x0, #0x17]
    // 0x8440e8: r1 = Instance_Color
    //     0x8440e8: add             x1, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x8440ec: ldr             x1, [x1, #0xbe8]
    // 0x8440f0: StoreField: r0->field_1b = r1
    //     0x8440f0: stur            w1, [x0, #0x1b]
    // 0x8440f4: ldur            x1, [fp, #-0x10]
    // 0x8440f8: StoreField: r0->field_1f = r1
    //     0x8440f8: stur            w1, [x0, #0x1f]
    // 0x8440fc: ldr             x1, [fp, #0x18]
    // 0x844100: StoreField: r0->field_2b = r1
    //     0x844100: stur            w1, [x0, #0x2b]
    // 0x844104: LeaveFrame
    //     0x844104: mov             SP, fp
    //     0x844108: ldp             fp, lr, [SP], #0x10
    // 0x84410c: ret
    //     0x84410c: ret             
    // 0x844110: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844110: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844114: b               #0x843f8c
    // 0x844118: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844118: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84411c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x84411c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleChanged(dynamic, double) {
    // ** addr: 0x84412c, size: 0x4c
    // 0x84412c: EnterFrame
    //     0x84412c: stp             fp, lr, [SP, #-0x10]!
    //     0x844130: mov             fp, SP
    // 0x844134: ldr             x0, [fp, #0x18]
    // 0x844138: LoadField: r1 = r0->field_17
    //     0x844138: ldur            w1, [x0, #0x17]
    // 0x84413c: DecompressPointer r1
    //     0x84413c: add             x1, x1, HEAP, lsl #32
    // 0x844140: CheckStackOverflow
    //     0x844140: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x844144: cmp             SP, x16
    //     0x844148: b.ls            #0x844170
    // 0x84414c: LoadField: r0 = r1->field_f
    //     0x84414c: ldur            w0, [x1, #0xf]
    // 0x844150: DecompressPointer r0
    //     0x844150: add             x0, x0, HEAP, lsl #32
    // 0x844154: ldr             x16, [fp, #0x10]
    // 0x844158: stp             x16, x0, [SP, #-0x10]!
    // 0x84415c: r0 = _handleChanged()
    //     0x84415c: bl              #0x844178  ; [package:flutter/src/cupertino/slider.dart] _CupertinoSliderState::_handleChanged
    // 0x844160: add             SP, SP, #0x10
    // 0x844164: LeaveFrame
    //     0x844164: mov             SP, fp
    //     0x844168: ldp             fp, lr, [SP], #0x10
    // 0x84416c: ret
    //     0x84416c: ret             
    // 0x844170: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844170: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844174: b               #0x84414c
  }
  _ _handleChanged(/* No info */) {
    // ** addr: 0x844178, size: 0x148
    // 0x844178: EnterFrame
    //     0x844178: stp             fp, lr, [SP, #-0x10]!
    //     0x84417c: mov             fp, SP
    // 0x844180: CheckStackOverflow
    //     0x844180: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x844184: cmp             SP, x16
    //     0x844188: b.ls            #0x844270
    // 0x84418c: ldr             x0, [fp, #0x18]
    // 0x844190: LoadField: r1 = r0->field_b
    //     0x844190: ldur            w1, [x0, #0xb]
    // 0x844194: DecompressPointer r1
    //     0x844194: add             x1, x1, HEAP, lsl #32
    // 0x844198: cmp             w1, NULL
    // 0x84419c: b.eq            #0x844278
    // 0x8441a0: LoadField: d0 = r1->field_1f
    //     0x8441a0: ldur            d0, [x1, #0x1f]
    // 0x8441a4: LoadField: d1 = r1->field_27
    //     0x8441a4: ldur            d1, [x1, #0x27]
    // 0x8441a8: r1 = inline_Allocate_Double()
    //     0x8441a8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x8441ac: add             x1, x1, #0x10
    //     0x8441b0: cmp             x2, x1
    //     0x8441b4: b.ls            #0x84427c
    //     0x8441b8: str             x1, [THR, #0x60]  ; THR::top
    //     0x8441bc: sub             x1, x1, #0xf
    //     0x8441c0: mov             x2, #0xd108
    //     0x8441c4: movk            x2, #3, lsl #16
    //     0x8441c8: stur            x2, [x1, #-1]
    // 0x8441cc: StoreField: r1->field_7 = d0
    //     0x8441cc: stur            d0, [x1, #7]
    // 0x8441d0: r2 = inline_Allocate_Double()
    //     0x8441d0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x8441d4: add             x2, x2, #0x10
    //     0x8441d8: cmp             x3, x2
    //     0x8441dc: b.ls            #0x844298
    //     0x8441e0: str             x2, [THR, #0x60]  ; THR::top
    //     0x8441e4: sub             x2, x2, #0xf
    //     0x8441e8: mov             x3, #0xd108
    //     0x8441ec: movk            x3, #3, lsl #16
    //     0x8441f0: stur            x3, [x2, #-1]
    // 0x8441f4: StoreField: r2->field_7 = d1
    //     0x8441f4: stur            d1, [x2, #7]
    // 0x8441f8: stp             x2, x1, [SP, #-0x10]!
    // 0x8441fc: ldr             x16, [fp, #0x10]
    // 0x844200: SaveReg r16
    //     0x844200: str             x16, [SP, #-8]!
    // 0x844204: r0 = lerpDouble()
    //     0x844204: bl              #0x5b5314  ; [dart:ui] ::lerpDouble
    // 0x844208: add             SP, SP, #0x18
    // 0x84420c: cmp             w0, NULL
    // 0x844210: b.eq            #0x8442b4
    // 0x844214: ldr             x1, [fp, #0x18]
    // 0x844218: LoadField: r2 = r1->field_b
    //     0x844218: ldur            w2, [x1, #0xb]
    // 0x84421c: DecompressPointer r2
    //     0x84421c: add             x2, x2, HEAP, lsl #32
    // 0x844220: cmp             w2, NULL
    // 0x844224: b.eq            #0x8442b8
    // 0x844228: LoadField: d0 = r2->field_b
    //     0x844228: ldur            d0, [x2, #0xb]
    // 0x84422c: LoadField: d1 = r0->field_7
    //     0x84422c: ldur            d1, [x0, #7]
    // 0x844230: fcmp            d1, d0
    // 0x844234: b.eq            #0x844260
    // 0x844238: LoadField: r1 = r2->field_13
    //     0x844238: ldur            w1, [x2, #0x13]
    // 0x84423c: DecompressPointer r1
    //     0x84423c: add             x1, x1, HEAP, lsl #32
    // 0x844240: cmp             w1, NULL
    // 0x844244: b.eq            #0x8442bc
    // 0x844248: stp             x0, x1, [SP, #-0x10]!
    // 0x84424c: mov             x0, x1
    // 0x844250: ClosureCall
    //     0x844250: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x844254: ldur            x2, [x0, #0x1f]
    //     0x844258: blr             x2
    // 0x84425c: add             SP, SP, #0x10
    // 0x844260: r0 = Null
    //     0x844260: mov             x0, NULL
    // 0x844264: LeaveFrame
    //     0x844264: mov             SP, fp
    //     0x844268: ldp             fp, lr, [SP], #0x10
    // 0x84426c: ret
    //     0x84426c: ret             
    // 0x844270: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844270: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844274: b               #0x84418c
    // 0x844278: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x844278: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x84427c: stp             q0, q1, [SP, #-0x20]!
    // 0x844280: SaveReg r0
    //     0x844280: str             x0, [SP, #-8]!
    // 0x844284: r0 = AllocateDouble()
    //     0x844284: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x844288: mov             x1, x0
    // 0x84428c: RestoreReg r0
    //     0x84428c: ldr             x0, [SP], #8
    // 0x844290: ldp             q0, q1, [SP], #0x20
    // 0x844294: b               #0x8441cc
    // 0x844298: SaveReg d1
    //     0x844298: str             q1, [SP, #-0x10]!
    // 0x84429c: stp             x0, x1, [SP, #-0x10]!
    // 0x8442a0: r0 = AllocateDouble()
    //     0x8442a0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x8442a4: mov             x2, x0
    // 0x8442a8: ldp             x0, x1, [SP], #0x10
    // 0x8442ac: RestoreReg d1
    //     0x8442ac: ldr             q1, [SP], #0x10
    // 0x8442b0: b               #0x8441f4
    // 0x8442b4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8442b4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8442b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8442b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x8442bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x8442bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3604, size: 0x30, field offset: 0xc
//   const constructor, 
class _CupertinoSliderRenderObjectWidget extends LeafRenderObjectWidget {

  _ updateRenderObject(/* No info */) {
    // ** addr: 0x6ca5a8, size: 0x178
    // 0x6ca5a8: EnterFrame
    //     0x6ca5a8: stp             fp, lr, [SP, #-0x10]!
    //     0x6ca5ac: mov             fp, SP
    // 0x6ca5b0: CheckStackOverflow
    //     0x6ca5b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ca5b4: cmp             SP, x16
    //     0x6ca5b8: b.ls            #0x6ca718
    // 0x6ca5bc: ldr             x0, [fp, #0x10]
    // 0x6ca5c0: r2 = Null
    //     0x6ca5c0: mov             x2, NULL
    // 0x6ca5c4: r1 = Null
    //     0x6ca5c4: mov             x1, NULL
    // 0x6ca5c8: r4 = 59
    //     0x6ca5c8: mov             x4, #0x3b
    // 0x6ca5cc: branchIfSmi(r0, 0x6ca5d8)
    //     0x6ca5cc: tbz             w0, #0, #0x6ca5d8
    // 0x6ca5d0: r4 = LoadClassIdInstr(r0)
    //     0x6ca5d0: ldur            x4, [x0, #-1]
    //     0x6ca5d4: ubfx            x4, x4, #0xc, #0x14
    // 0x6ca5d8: cmp             x4, #0x9de
    // 0x6ca5dc: b.eq            #0x6ca5f4
    // 0x6ca5e0: r8 = _RenderCupertinoSlider
    //     0x6ca5e0: add             x8, PP, #0x57, lsl #12  ; [pp+0x57348] Type: _RenderCupertinoSlider
    //     0x6ca5e4: ldr             x8, [x8, #0x348]
    // 0x6ca5e8: r3 = Null
    //     0x6ca5e8: add             x3, PP, #0x57, lsl #12  ; [pp+0x57350] Null
    //     0x6ca5ec: ldr             x3, [x3, #0x350]
    // 0x6ca5f0: r0 = DefaultTypeTest()
    //     0x6ca5f0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x6ca5f4: ldr             x0, [fp, #0x20]
    // 0x6ca5f8: LoadField: d0 = r0->field_b
    //     0x6ca5f8: ldur            d0, [x0, #0xb]
    // 0x6ca5fc: ldr             x16, [fp, #0x10]
    // 0x6ca600: SaveReg r16
    //     0x6ca600: str             x16, [SP, #-8]!
    // 0x6ca604: SaveReg d0
    //     0x6ca604: str             d0, [SP, #-8]!
    // 0x6ca608: r0 = value=()
    //     0x6ca608: bl              #0x6cb3bc  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::value=
    // 0x6ca60c: add             SP, SP, #0x10
    // 0x6ca610: ldr             x16, [fp, #0x10]
    // 0x6ca614: stp             NULL, x16, [SP, #-0x10]!
    // 0x6ca618: r0 = Shader._()
    //     0x6ca618: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6ca61c: add             SP, SP, #0x10
    // 0x6ca620: ldr             x0, [fp, #0x20]
    // 0x6ca624: LoadField: r1 = r0->field_17
    //     0x6ca624: ldur            w1, [x0, #0x17]
    // 0x6ca628: DecompressPointer r1
    //     0x6ca628: add             x1, x1, HEAP, lsl #32
    // 0x6ca62c: ldr             x16, [fp, #0x10]
    // 0x6ca630: stp             x1, x16, [SP, #-0x10]!
    // 0x6ca634: r0 = activeColor=()
    //     0x6ca634: bl              #0x6cb218  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::activeColor=
    // 0x6ca638: add             SP, SP, #0x10
    // 0x6ca63c: ldr             x16, [fp, #0x10]
    // 0x6ca640: r30 = Instance_Color
    //     0x6ca640: add             lr, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x6ca644: ldr             lr, [lr, #0xbe8]
    // 0x6ca648: stp             lr, x16, [SP, #-0x10]!
    // 0x6ca64c: r0 = Shader._()
    //     0x6ca64c: bl              #0xd614dc  ; [dart:ui] Shader::Shader._
    // 0x6ca650: add             SP, SP, #0x10
    // 0x6ca654: r16 = Instance_CupertinoDynamicColor
    //     0x6ca654: add             x16, PP, #0x57, lsl #12  ; [pp+0x57360] Obj!CupertinoDynamicColor@b5e4b1
    //     0x6ca658: ldr             x16, [x16, #0x360]
    // 0x6ca65c: ldr             lr, [fp, #0x18]
    // 0x6ca660: stp             lr, x16, [SP, #-0x10]!
    // 0x6ca664: r0 = resolveFrom()
    //     0x6ca664: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x6ca668: add             SP, SP, #0x10
    // 0x6ca66c: ldr             x16, [fp, #0x10]
    // 0x6ca670: stp             x0, x16, [SP, #-0x10]!
    // 0x6ca674: r0 = trackColor=()
    //     0x6ca674: bl              #0x6ca8e8  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::trackColor=
    // 0x6ca678: add             SP, SP, #0x10
    // 0x6ca67c: ldr             x0, [fp, #0x20]
    // 0x6ca680: LoadField: r1 = r0->field_1f
    //     0x6ca680: ldur            w1, [x0, #0x1f]
    // 0x6ca684: DecompressPointer r1
    //     0x6ca684: add             x1, x1, HEAP, lsl #32
    // 0x6ca688: ldr             x16, [fp, #0x10]
    // 0x6ca68c: stp             x1, x16, [SP, #-0x10]!
    // 0x6ca690: r0 = onChanged=()
    //     0x6ca690: bl              #0x6ca7f4  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::onChanged=
    // 0x6ca694: add             SP, SP, #0x10
    // 0x6ca698: ldr             x1, [fp, #0x20]
    // 0x6ca69c: LoadField: r0 = r1->field_23
    //     0x6ca69c: ldur            w0, [x1, #0x23]
    // 0x6ca6a0: DecompressPointer r0
    //     0x6ca6a0: add             x0, x0, HEAP, lsl #32
    // 0x6ca6a4: ldr             x2, [fp, #0x10]
    // 0x6ca6a8: StoreField: r2->field_83 = r0
    //     0x6ca6a8: stur            w0, [x2, #0x83]
    //     0x6ca6ac: ldurb           w16, [x2, #-1]
    //     0x6ca6b0: ldurb           w17, [x0, #-1]
    //     0x6ca6b4: and             x16, x17, x16, lsr #2
    //     0x6ca6b8: tst             x16, HEAP, lsr #32
    //     0x6ca6bc: b.eq            #0x6ca6c4
    //     0x6ca6c0: bl              #0xd6828c
    // 0x6ca6c4: LoadField: r0 = r1->field_27
    //     0x6ca6c4: ldur            w0, [x1, #0x27]
    // 0x6ca6c8: DecompressPointer r0
    //     0x6ca6c8: add             x0, x0, HEAP, lsl #32
    // 0x6ca6cc: StoreField: r2->field_87 = r0
    //     0x6ca6cc: stur            w0, [x2, #0x87]
    //     0x6ca6d0: ldurb           w16, [x2, #-1]
    //     0x6ca6d4: ldurb           w17, [x0, #-1]
    //     0x6ca6d8: and             x16, x17, x16, lsr #2
    //     0x6ca6dc: tst             x16, HEAP, lsr #32
    //     0x6ca6e0: b.eq            #0x6ca6e8
    //     0x6ca6e4: bl              #0xd6828c
    // 0x6ca6e8: ldr             x16, [fp, #0x18]
    // 0x6ca6ec: SaveReg r16
    //     0x6ca6ec: str             x16, [SP, #-8]!
    // 0x6ca6f0: r0 = of()
    //     0x6ca6f0: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6ca6f4: add             SP, SP, #8
    // 0x6ca6f8: ldr             x16, [fp, #0x10]
    // 0x6ca6fc: stp             x0, x16, [SP, #-0x10]!
    // 0x6ca700: r0 = textDirection=()
    //     0x6ca700: bl              #0x6ca774  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::textDirection=
    // 0x6ca704: add             SP, SP, #0x10
    // 0x6ca708: r0 = Null
    //     0x6ca708: mov             x0, NULL
    // 0x6ca70c: LeaveFrame
    //     0x6ca70c: mov             SP, fp
    //     0x6ca710: ldp             fp, lr, [SP], #0x10
    // 0x6ca714: ret
    //     0x6ca714: ret             
    // 0x6ca718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6ca718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6ca71c: b               #0x6ca5bc
  }
  _ createRenderObject(/* No info */) {
    // ** addr: 0x6ede5c, size: 0xf8
    // 0x6ede5c: EnterFrame
    //     0x6ede5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6ede60: mov             fp, SP
    // 0x6ede64: AllocStack(0x48)
    //     0x6ede64: sub             SP, SP, #0x48
    // 0x6ede68: CheckStackOverflow
    //     0x6ede68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6ede6c: cmp             SP, x16
    //     0x6ede70: b.ls            #0x6edf4c
    // 0x6ede74: ldr             x0, [fp, #0x18]
    // 0x6ede78: LoadField: d0 = r0->field_b
    //     0x6ede78: ldur            d0, [x0, #0xb]
    // 0x6ede7c: stur            d0, [fp, #-0x48]
    // 0x6ede80: LoadField: r1 = r0->field_17
    //     0x6ede80: ldur            w1, [x0, #0x17]
    // 0x6ede84: DecompressPointer r1
    //     0x6ede84: add             x1, x1, HEAP, lsl #32
    // 0x6ede88: stur            x1, [fp, #-8]
    // 0x6ede8c: r16 = Instance_CupertinoDynamicColor
    //     0x6ede8c: add             x16, PP, #0x57, lsl #12  ; [pp+0x57360] Obj!CupertinoDynamicColor@b5e4b1
    //     0x6ede90: ldr             x16, [x16, #0x360]
    // 0x6ede94: ldr             lr, [fp, #0x10]
    // 0x6ede98: stp             lr, x16, [SP, #-0x10]!
    // 0x6ede9c: r0 = resolveFrom()
    //     0x6ede9c: bl              #0x6ca974  ; [package:flutter/src/cupertino/colors.dart] CupertinoDynamicColor::resolveFrom
    // 0x6edea0: add             SP, SP, #0x10
    // 0x6edea4: mov             x1, x0
    // 0x6edea8: ldr             x0, [fp, #0x18]
    // 0x6edeac: stur            x1, [fp, #-0x30]
    // 0x6edeb0: LoadField: r2 = r0->field_1f
    //     0x6edeb0: ldur            w2, [x0, #0x1f]
    // 0x6edeb4: DecompressPointer r2
    //     0x6edeb4: add             x2, x2, HEAP, lsl #32
    // 0x6edeb8: stur            x2, [fp, #-0x28]
    // 0x6edebc: LoadField: r3 = r0->field_23
    //     0x6edebc: ldur            w3, [x0, #0x23]
    // 0x6edec0: DecompressPointer r3
    //     0x6edec0: add             x3, x3, HEAP, lsl #32
    // 0x6edec4: stur            x3, [fp, #-0x20]
    // 0x6edec8: LoadField: r4 = r0->field_27
    //     0x6edec8: ldur            w4, [x0, #0x27]
    // 0x6edecc: DecompressPointer r4
    //     0x6edecc: add             x4, x4, HEAP, lsl #32
    // 0x6eded0: stur            x4, [fp, #-0x18]
    // 0x6eded4: LoadField: r5 = r0->field_2b
    //     0x6eded4: ldur            w5, [x0, #0x2b]
    // 0x6eded8: DecompressPointer r5
    //     0x6eded8: add             x5, x5, HEAP, lsl #32
    // 0x6ededc: stur            x5, [fp, #-0x10]
    // 0x6edee0: ldr             x16, [fp, #0x10]
    // 0x6edee4: SaveReg r16
    //     0x6edee4: str             x16, [SP, #-8]!
    // 0x6edee8: r0 = of()
    //     0x6edee8: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0x6edeec: add             SP, SP, #8
    // 0x6edef0: stur            x0, [fp, #-0x38]
    // 0x6edef4: r0 = _RenderCupertinoSlider()
    //     0x6edef4: bl              #0x6eea4c  ; Allocate_RenderCupertinoSliderStub -> _RenderCupertinoSlider (size=0xac)
    // 0x6edef8: stur            x0, [fp, #-0x40]
    // 0x6edefc: ldur            x16, [fp, #-8]
    // 0x6edf00: stp             x16, x0, [SP, #-0x10]!
    // 0x6edf04: ldur            x16, [fp, #-0x18]
    // 0x6edf08: ldur            lr, [fp, #-0x20]
    // 0x6edf0c: stp             lr, x16, [SP, #-0x10]!
    // 0x6edf10: ldur            x16, [fp, #-0x28]
    // 0x6edf14: ldur            lr, [fp, #-0x38]
    // 0x6edf18: stp             lr, x16, [SP, #-0x10]!
    // 0x6edf1c: ldur            x16, [fp, #-0x30]
    // 0x6edf20: SaveReg r16
    //     0x6edf20: str             x16, [SP, #-8]!
    // 0x6edf24: ldur            d0, [fp, #-0x48]
    // 0x6edf28: SaveReg d0
    //     0x6edf28: str             d0, [SP, #-8]!
    // 0x6edf2c: ldur            x16, [fp, #-0x10]
    // 0x6edf30: SaveReg r16
    //     0x6edf30: str             x16, [SP, #-8]!
    // 0x6edf34: r0 = _RenderCupertinoSlider()
    //     0x6edf34: bl              #0x6edf54  ; [package:flutter/src/cupertino/slider.dart] _RenderCupertinoSlider::_RenderCupertinoSlider
    // 0x6edf38: add             SP, SP, #0x48
    // 0x6edf3c: ldur            x0, [fp, #-0x40]
    // 0x6edf40: LeaveFrame
    //     0x6edf40: mov             SP, fp
    //     0x6edf44: ldp             fp, lr, [SP], #0x10
    // 0x6edf48: ret
    //     0x6edf48: ret             
    // 0x6edf4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6edf4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6edf50: b               #0x6ede74
  }
}

// class id: 4175, size: 0x3c, field offset: 0xc
//   const constructor, 
class CupertinoSlider extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa40040, size: 0x20
    // 0xa40040: EnterFrame
    //     0xa40040: stp             fp, lr, [SP, #-0x10]!
    //     0xa40044: mov             fp, SP
    // 0xa40048: r1 = <CupertinoSlider>
    //     0xa40048: add             x1, PP, #0x56, lsl #12  ; [pp+0x56630] TypeArguments: <CupertinoSlider>
    //     0xa4004c: ldr             x1, [x1, #0x630]
    // 0xa40050: r0 = _CupertinoSliderState()
    //     0xa40050: bl              #0xa40060  ; Allocate_CupertinoSliderStateStub -> _CupertinoSliderState (size=0x1c)
    // 0xa40054: LeaveFrame
    //     0xa40054: mov             SP, fp
    //     0xa40058: ldp             fp, lr, [SP], #0x10
    // 0xa4005c: ret
    //     0xa4005c: ret             
  }
}

// lib: , url: package:flutter/src/cupertino/text_selection_toolbar_button.dart

// class id: 1049114, size: 0x8
class :: {
}

// class id: 3867, size: 0x18, field offset: 0xc
//   const constructor, 
class CupertinoTextSelectionToolbarButton extends StatelessWidget {

  _ CupertinoTextSelectionToolbarButton.text(/* No info */) {
    // ** addr: 0x844d78, size: 0x128
    // 0x844d78: EnterFrame
    //     0x844d78: stp             fp, lr, [SP, #-0x10]!
    //     0x844d7c: mov             fp, SP
    // 0x844d80: AllocStack(0x18)
    //     0x844d80: sub             SP, SP, #0x18
    // 0x844d84: SetupParameters(CupertinoTextSelectionToolbarButton this /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */, {dynamic onPressed = Null /* r1 */})
    //     0x844d84: mov             x0, x4
    //     0x844d88: ldur            w1, [x0, #0x13]
    //     0x844d8c: add             x1, x1, HEAP, lsl #32
    //     0x844d90: sub             x2, x1, #4
    //     0x844d94: add             x3, fp, w2, sxtw #2
    //     0x844d98: ldr             x3, [x3, #0x18]
    //     0x844d9c: stur            x3, [fp, #-0x10]
    //     0x844da0: add             x4, fp, w2, sxtw #2
    //     0x844da4: ldr             x4, [x4, #0x10]
    //     0x844da8: stur            x4, [fp, #-8]
    //     0x844dac: ldur            w2, [x0, #0x1f]
    //     0x844db0: add             x2, x2, HEAP, lsl #32
    //     0x844db4: add             x16, PP, #0x28, lsl #12  ; [pp+0x28dc0] "onPressed"
    //     0x844db8: ldr             x16, [x16, #0xdc0]
    //     0x844dbc: cmp             w2, w16
    //     0x844dc0: b.ne            #0x844ddc
    //     0x844dc4: ldur            w2, [x0, #0x23]
    //     0x844dc8: add             x2, x2, HEAP, lsl #32
    //     0x844dcc: sub             w0, w1, w2
    //     0x844dd0: add             x1, fp, w0, sxtw #2
    //     0x844dd4: ldr             x1, [x1, #8]
    //     0x844dd8: b               #0x844de0
    //     0x844ddc: mov             x1, NULL
    // 0x844de0: CheckStackOverflow
    //     0x844de0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x844de4: cmp             SP, x16
    //     0x844de8: b.ls            #0x844e98
    // 0x844dec: mov             x0, x1
    // 0x844df0: StoreField: r3->field_f = r0
    //     0x844df0: stur            w0, [x3, #0xf]
    //     0x844df4: ldurb           w16, [x3, #-1]
    //     0x844df8: ldurb           w17, [x0, #-1]
    //     0x844dfc: and             x16, x17, x16, lsr #2
    //     0x844e00: tst             x16, HEAP, lsr #32
    //     0x844e04: b.eq            #0x844e0c
    //     0x844e08: bl              #0xd682ac
    // 0x844e0c: cmp             w1, NULL
    // 0x844e10: b.eq            #0x844e20
    // 0x844e14: r0 = Instance_Color
    //     0x844e14: add             x0, PP, #0xc, lsl #12  ; [pp+0xcbe8] Obj!Color@b5d091
    //     0x844e18: ldr             x0, [x0, #0xbe8]
    // 0x844e1c: b               #0x844e28
    // 0x844e20: r0 = Instance_CupertinoDynamicColor
    //     0x844e20: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dc8] Obj!CupertinoDynamicColor@b5e4f1
    //     0x844e24: ldr             x0, [x0, #0xdc8]
    // 0x844e28: r16 = Instance_TextStyle
    //     0x844e28: add             x16, PP, #0x28, lsl #12  ; [pp+0x28da8] Obj!TextStyle@b43b41
    //     0x844e2c: ldr             x16, [x16, #0xda8]
    // 0x844e30: stp             x0, x16, [SP, #-0x10]!
    // 0x844e34: r4 = const [0, 0x2, 0x2, 0x1, color, 0x1, null]
    //     0x844e34: add             x4, PP, #0xe, lsl #12  ; [pp+0xe168] List(7) [0, 0x2, 0x2, 0x1, "color", 0x1, Null]
    //     0x844e38: ldr             x4, [x4, #0x168]
    // 0x844e3c: r0 = copyWith()
    //     0x844e3c: bl              #0x6ce14c  ; [package:flutter/src/painting/text_style.dart] TextStyle::copyWith
    // 0x844e40: add             SP, SP, #0x10
    // 0x844e44: stur            x0, [fp, #-0x18]
    // 0x844e48: r0 = Text()
    //     0x844e48: bl              #0x596214  ; AllocateTextStub -> Text (size=0x48)
    // 0x844e4c: ldur            x1, [fp, #-8]
    // 0x844e50: StoreField: r0->field_b = r1
    //     0x844e50: stur            w1, [x0, #0xb]
    // 0x844e54: ldur            x1, [fp, #-0x18]
    // 0x844e58: StoreField: r0->field_13 = r1
    //     0x844e58: stur            w1, [x0, #0x13]
    // 0x844e5c: r1 = Instance_TextOverflow
    //     0x844e5c: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d428] Obj!TextOverflow@b64d51
    //     0x844e60: ldr             x1, [x1, #0x428]
    // 0x844e64: StoreField: r0->field_2b = r1
    //     0x844e64: stur            w1, [x0, #0x2b]
    // 0x844e68: ldur            x1, [fp, #-0x10]
    // 0x844e6c: StoreField: r1->field_b = r0
    //     0x844e6c: stur            w0, [x1, #0xb]
    //     0x844e70: ldurb           w16, [x1, #-1]
    //     0x844e74: ldurb           w17, [x0, #-1]
    //     0x844e78: and             x16, x17, x16, lsr #2
    //     0x844e7c: tst             x16, HEAP, lsr #32
    //     0x844e80: b.eq            #0x844e88
    //     0x844e84: bl              #0xd6826c
    // 0x844e88: r0 = Null
    //     0x844e88: mov             x0, NULL
    // 0x844e8c: LeaveFrame
    //     0x844e8c: mov             SP, fp
    //     0x844e90: ldp             fp, lr, [SP], #0x10
    // 0x844e94: ret
    //     0x844e94: ret             
    // 0x844e98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x844e98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x844e9c: b               #0x844dec
  }
  _ build(/* No info */) {
    // ** addr: 0xb1d564, size: 0xa8
    // 0xb1d564: EnterFrame
    //     0xb1d564: stp             fp, lr, [SP, #-0x10]!
    //     0xb1d568: mov             fp, SP
    // 0xb1d56c: AllocStack(0x18)
    //     0xb1d56c: sub             SP, SP, #0x18
    // 0xb1d570: ldr             x0, [fp, #0x18]
    // 0xb1d574: LoadField: r1 = r0->field_b
    //     0xb1d574: ldur            w1, [x0, #0xb]
    // 0xb1d578: DecompressPointer r1
    //     0xb1d578: add             x1, x1, HEAP, lsl #32
    // 0xb1d57c: stur            x1, [fp, #-0x10]
    // 0xb1d580: LoadField: r2 = r0->field_f
    //     0xb1d580: ldur            w2, [x0, #0xf]
    // 0xb1d584: DecompressPointer r2
    //     0xb1d584: add             x2, x2, HEAP, lsl #32
    // 0xb1d588: stur            x2, [fp, #-8]
    // 0xb1d58c: cmp             w2, NULL
    // 0xb1d590: b.ne            #0xb1d59c
    // 0xb1d594: d0 = 1.000000
    //     0xb1d594: fmov            d0, #1.00000000
    // 0xb1d598: b               #0xb1d5a4
    // 0xb1d59c: d0 = 0.700000
    //     0xb1d59c: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c2f0] IMM: double(0.7) from 0x3fe6666666666666
    //     0xb1d5a0: ldr             d0, [x17, #0x2f0]
    // 0xb1d5a4: stur            d0, [fp, #-0x18]
    // 0xb1d5a8: r0 = CupertinoButton()
    //     0xb1d5a8: bl              #0x840ee0  ; AllocateCupertinoButtonStub -> CupertinoButton (size=0x3c)
    // 0xb1d5ac: ldur            x1, [fp, #-0x10]
    // 0xb1d5b0: StoreField: r0->field_b = r1
    //     0xb1d5b0: stur            w1, [x0, #0xb]
    // 0xb1d5b4: r1 = Instance_EdgeInsets
    //     0xb1d5b4: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e998] Obj!EdgeInsets@b37071
    //     0xb1d5b8: ldr             x1, [x1, #0x998]
    // 0xb1d5bc: StoreField: r0->field_f = r1
    //     0xb1d5bc: stur            w1, [x0, #0xf]
    // 0xb1d5c0: r1 = Instance_Color
    //     0xb1d5c0: add             x1, PP, #0x2e, lsl #12  ; [pp+0x2e9a0] Obj!Color@b5e0d1
    //     0xb1d5c4: ldr             x1, [x1, #0x9a0]
    // 0xb1d5c8: StoreField: r0->field_13 = r1
    //     0xb1d5c8: stur            w1, [x0, #0x13]
    // 0xb1d5cc: StoreField: r0->field_17 = r1
    //     0xb1d5cc: stur            w1, [x0, #0x17]
    // 0xb1d5d0: d0 = 44.000000
    //     0xb1d5d0: add             x17, PP, #0x2d, lsl #12  ; [pp+0x2dc30] IMM: double(44) from 0x4046000000000000
    //     0xb1d5d4: ldr             d0, [x17, #0xc30]
    // 0xb1d5d8: StoreField: r0->field_1f = d0
    //     0xb1d5d8: stur            d0, [x0, #0x1f]
    // 0xb1d5dc: ldur            d0, [fp, #-0x18]
    // 0xb1d5e0: StoreField: r0->field_27 = d0
    //     0xb1d5e0: stur            d0, [x0, #0x27]
    // 0xb1d5e4: r1 = Instance_Alignment
    //     0xb1d5e4: add             x1, PP, #0xd, lsl #12  ; [pp+0xdc70] Obj!Alignment@b37ab1
    //     0xb1d5e8: ldr             x1, [x1, #0xc70]
    // 0xb1d5ec: StoreField: r0->field_33 = r1
    //     0xb1d5ec: stur            w1, [x0, #0x33]
    // 0xb1d5f0: ldur            x1, [fp, #-8]
    // 0xb1d5f4: StoreField: r0->field_1b = r1
    //     0xb1d5f4: stur            w1, [x0, #0x1b]
    // 0xb1d5f8: r1 = false
    //     0xb1d5f8: add             x1, NULL, #0x30  ; false
    // 0xb1d5fc: StoreField: r0->field_37 = r1
    //     0xb1d5fc: stur            w1, [x0, #0x37]
    // 0xb1d600: LeaveFrame
    //     0xb1d600: mov             SP, fp
    //     0xb1d604: ldp             fp, lr, [SP], #0x10
    // 0xb1d608: ret
    //     0xb1d608: ret             
  }
  static _ getButtonLabel(/* No info */) {
    // ** addr: 0xb1de00, size: 0xbc
    // 0xb1de00: EnterFrame
    //     0xb1de00: stp             fp, lr, [SP, #-0x10]!
    //     0xb1de04: mov             fp, SP
    // 0xb1de08: CheckStackOverflow
    //     0xb1de08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb1de0c: cmp             SP, x16
    //     0xb1de10: b.ls            #0xb1deb4
    // 0xb1de14: ldr             x16, [fp, #0x18]
    // 0xb1de18: SaveReg r16
    //     0xb1de18: str             x16, [SP, #-8]!
    // 0xb1de1c: r0 = of()
    //     0xb1de1c: bl              #0x840c34  ; [package:flutter/src/cupertino/localizations.dart] CupertinoLocalizations::of
    // 0xb1de20: add             SP, SP, #8
    // 0xb1de24: ldr             x1, [fp, #0x10]
    // 0xb1de28: LoadField: r2 = r1->field_b
    //     0xb1de28: ldur            w2, [x1, #0xb]
    // 0xb1de2c: DecompressPointer r2
    //     0xb1de2c: add             x2, x2, HEAP, lsl #32
    // 0xb1de30: LoadField: r1 = r2->field_7
    //     0xb1de30: ldur            x1, [x2, #7]
    // 0xb1de34: cmp             x1, #2
    // 0xb1de38: b.gt            #0xb1de88
    // 0xb1de3c: cmp             x1, #1
    // 0xb1de40: b.gt            #0xb1de74
    // 0xb1de44: cmp             x1, #0
    // 0xb1de48: b.gt            #0xb1de60
    // 0xb1de4c: r0 = "Cut"
    //     0xb1de4c: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dd0] "Cut"
    //     0xb1de50: ldr             x0, [x0, #0xdd0]
    // 0xb1de54: LeaveFrame
    //     0xb1de54: mov             SP, fp
    //     0xb1de58: ldp             fp, lr, [SP], #0x10
    // 0xb1de5c: ret
    //     0xb1de5c: ret             
    // 0xb1de60: r0 = "Copy"
    //     0xb1de60: add             x0, PP, #0x28, lsl #12  ; [pp+0x28dd8] "Copy"
    //     0xb1de64: ldr             x0, [x0, #0xdd8]
    // 0xb1de68: LeaveFrame
    //     0xb1de68: mov             SP, fp
    //     0xb1de6c: ldp             fp, lr, [SP], #0x10
    // 0xb1de70: ret
    //     0xb1de70: ret             
    // 0xb1de74: r0 = "Paste"
    //     0xb1de74: add             x0, PP, #0x28, lsl #12  ; [pp+0x28de0] "Paste"
    //     0xb1de78: ldr             x0, [x0, #0xde0]
    // 0xb1de7c: LeaveFrame
    //     0xb1de7c: mov             SP, fp
    //     0xb1de80: ldp             fp, lr, [SP], #0x10
    // 0xb1de84: ret
    //     0xb1de84: ret             
    // 0xb1de88: cmp             x1, #3
    // 0xb1de8c: b.gt            #0xb1dea4
    // 0xb1de90: r0 = "Select All"
    //     0xb1de90: add             x0, PP, #0x28, lsl #12  ; [pp+0x28df0] "Select All"
    //     0xb1de94: ldr             x0, [x0, #0xdf0]
    // 0xb1de98: LeaveFrame
    //     0xb1de98: mov             SP, fp
    //     0xb1de9c: ldp             fp, lr, [SP], #0x10
    // 0xb1dea0: ret
    //     0xb1dea0: ret             
    // 0xb1dea4: r0 = ""
    //     0xb1dea4: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0xb1dea8: LeaveFrame
    //     0xb1dea8: mov             SP, fp
    //     0xb1deac: ldp             fp, lr, [SP], #0x10
    // 0xb1deb0: ret
    //     0xb1deb0: ret             
    // 0xb1deb4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1deb4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb1deb8: b               #0xb1de14
  }
}

// lib: , url: package:camera_platform_interface/src/method_channel/method_channel_camera.dart

// class id: 1048715, size: 0x8
class :: {
}

// class id: 4957, size: 0x1c, field offset: 0x8
class MethodChannelCamera extends CameraPlatform {

  _ MethodChannelCamera(/* No info */) {
    // ** addr: 0x5a8340, size: 0x160
    // 0x5a8340: EnterFrame
    //     0x5a8340: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8344: mov             fp, SP
    // 0x5a8348: AllocStack(0x10)
    //     0x5a8348: sub             SP, SP, #0x10
    // 0x5a834c: CheckStackOverflow
    //     0x5a834c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8350: cmp             SP, x16
    //     0x5a8354: b.ls            #0x5a8498
    // 0x5a8358: r1 = 1
    //     0x5a8358: mov             x1, #1
    // 0x5a835c: r0 = AllocateContext()
    //     0x5a835c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5a8360: mov             x1, x0
    // 0x5a8364: ldr             x0, [fp, #0x10]
    // 0x5a8368: stur            x1, [fp, #-8]
    // 0x5a836c: StoreField: r1->field_f = r0
    //     0x5a836c: stur            w0, [x1, #0xf]
    // 0x5a8370: r16 = <int, MethodChannel>
    //     0x5a8370: ldr             x16, [PP, #0xdb0]  ; [pp+0xdb0] TypeArguments: <int, MethodChannel>
    // 0x5a8374: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x5a8378: stp             lr, x16, [SP, #-0x10]!
    // 0x5a837c: r0 = Map._fromLiteral()
    //     0x5a837c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5a8380: add             SP, SP, #0x10
    // 0x5a8384: ldr             x1, [fp, #0x10]
    // 0x5a8388: StoreField: r1->field_7 = r0
    //     0x5a8388: stur            w0, [x1, #7]
    //     0x5a838c: tbz             w0, #0, #0x5a83a8
    //     0x5a8390: ldurb           w16, [x1, #-1]
    //     0x5a8394: ldurb           w17, [x0, #-1]
    //     0x5a8398: and             x16, x17, x16, lsr #2
    //     0x5a839c: tst             x16, HEAP, lsr #32
    //     0x5a83a0: b.eq            #0x5a83a8
    //     0x5a83a4: bl              #0xd6826c
    // 0x5a83a8: r16 = <CameraEvent>
    //     0x5a83a8: ldr             x16, [PP, #0xdb8]  ; [pp+0xdb8] TypeArguments: <CameraEvent>
    // 0x5a83ac: SaveReg r16
    //     0x5a83ac: str             x16, [SP, #-8]!
    // 0x5a83b0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5a83b0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5a83b4: r0 = StreamController.broadcast()
    //     0x5a83b4: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0x5a83b8: add             SP, SP, #8
    // 0x5a83bc: ldr             x1, [fp, #0x10]
    // 0x5a83c0: StoreField: r1->field_b = r0
    //     0x5a83c0: stur            w0, [x1, #0xb]
    //     0x5a83c4: tbz             w0, #0, #0x5a83e0
    //     0x5a83c8: ldurb           w16, [x1, #-1]
    //     0x5a83cc: ldurb           w17, [x0, #-1]
    //     0x5a83d0: and             x16, x17, x16, lsr #2
    //     0x5a83d4: tst             x16, HEAP, lsr #32
    //     0x5a83d8: b.eq            #0x5a83e0
    //     0x5a83dc: bl              #0xd6826c
    // 0x5a83e0: r16 = <DeviceEvent>
    //     0x5a83e0: ldr             x16, [PP, #0xdc0]  ; [pp+0xdc0] TypeArguments: <DeviceEvent>
    // 0x5a83e4: SaveReg r16
    //     0x5a83e4: str             x16, [SP, #-8]!
    // 0x5a83e8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x5a83e8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x5a83ec: r0 = StreamController.broadcast()
    //     0x5a83ec: bl              #0x5a25d4  ; [dart:async] StreamController::StreamController.broadcast
    // 0x5a83f0: add             SP, SP, #8
    // 0x5a83f4: ldr             x1, [fp, #0x10]
    // 0x5a83f8: StoreField: r1->field_f = r0
    //     0x5a83f8: stur            w0, [x1, #0xf]
    //     0x5a83fc: tbz             w0, #0, #0x5a8418
    //     0x5a8400: ldurb           w16, [x1, #-1]
    //     0x5a8404: ldurb           w17, [x0, #-1]
    //     0x5a8408: and             x16, x17, x16, lsr #2
    //     0x5a840c: tst             x16, HEAP, lsr #32
    //     0x5a8410: b.eq            #0x5a8418
    //     0x5a8414: bl              #0xd6826c
    // 0x5a8418: r0 = InitLateStaticField(0xac4) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_token
    //     0x5a8418: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a841c: ldr             x0, [x0, #0x1588]
    //     0x5a8420: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8424: cmp             w0, w16
    //     0x5a8428: b.ne            #0x5a8434
    //     0x5a842c: ldr             x2, [PP, #0xda8]  ; [pp+0xda8] Field <CameraPlatform._token@176219459>: static late final (offset: 0xac4)
    //     0x5a8430: bl              #0xd67cdc
    // 0x5a8434: stur            x0, [fp, #-0x10]
    // 0x5a8438: r0 = InitLateStaticField(0xa64) // [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::_instanceTokens
    //     0x5a8438: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x5a843c: ldr             x0, [x0, #0x14c8]
    //     0x5a8440: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x5a8444: cmp             w0, w16
    //     0x5a8448: b.ne            #0x5a8454
    //     0x5a844c: ldr             x2, [PP, #0x170]  ; [pp+0x170] Field <PlatformInterface._instanceTokens@187304592>: static late final (offset: 0xa64)
    //     0x5a8450: bl              #0xd67cdc
    // 0x5a8454: ldr             x16, [fp, #0x10]
    // 0x5a8458: stp             x16, x0, [SP, #-0x10]!
    // 0x5a845c: ldur            x16, [fp, #-0x10]
    // 0x5a8460: SaveReg r16
    //     0x5a8460: str             x16, [SP, #-8]!
    // 0x5a8464: r0 = []=()
    //     0x5a8464: bl              #0x4b97f8  ; [dart:core] Expando::[]=
    // 0x5a8468: add             SP, SP, #0x18
    // 0x5a846c: ldur            x2, [fp, #-8]
    // 0x5a8470: r1 = Function '<anonymous closure>':.
    //     0x5a8470: ldr             x1, [PP, #0xdc8]  ; [pp+0xdc8] AnonymousClosure: (0x5a8768), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::MethodChannelCamera (0x5a8340)
    // 0x5a8474: r0 = AllocateClosure()
    //     0x5a8474: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5a8478: r16 = Instance_MethodChannel
    //     0x5a8478: ldr             x16, [PP, #0xdd0]  ; [pp+0xdd0] Obj!MethodChannel@b34b51
    // 0x5a847c: stp             x0, x16, [SP, #-0x10]!
    // 0x5a8480: r0 = setMethodCallHandler()
    //     0x5a8480: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0x5a8484: add             SP, SP, #0x10
    // 0x5a8488: r0 = Null
    //     0x5a8488: mov             x0, NULL
    // 0x5a848c: LeaveFrame
    //     0x5a848c: mov             SP, fp
    //     0x5a8490: ldp             fp, lr, [SP], #0x10
    // 0x5a8494: ret
    //     0x5a8494: ret             
    // 0x5a8498: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8498: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a849c: b               #0x5a8358
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MethodCall) {
    // ** addr: 0x5a8768, size: 0x4c
    // 0x5a8768: EnterFrame
    //     0x5a8768: stp             fp, lr, [SP, #-0x10]!
    //     0x5a876c: mov             fp, SP
    // 0x5a8770: ldr             x0, [fp, #0x18]
    // 0x5a8774: LoadField: r1 = r0->field_17
    //     0x5a8774: ldur            w1, [x0, #0x17]
    // 0x5a8778: DecompressPointer r1
    //     0x5a8778: add             x1, x1, HEAP, lsl #32
    // 0x5a877c: CheckStackOverflow
    //     0x5a877c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8780: cmp             SP, x16
    //     0x5a8784: b.ls            #0x5a87ac
    // 0x5a8788: LoadField: r0 = r1->field_f
    //     0x5a8788: ldur            w0, [x1, #0xf]
    // 0x5a878c: DecompressPointer r0
    //     0x5a878c: add             x0, x0, HEAP, lsl #32
    // 0x5a8790: ldr             x16, [fp, #0x10]
    // 0x5a8794: stp             x16, x0, [SP, #-0x10]!
    // 0x5a8798: r0 = handleDeviceMethodCall()
    //     0x5a8798: bl              #0x5a87b4  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::handleDeviceMethodCall
    // 0x5a879c: add             SP, SP, #0x10
    // 0x5a87a0: LeaveFrame
    //     0x5a87a0: mov             SP, fp
    //     0x5a87a4: ldp             fp, lr, [SP], #0x10
    // 0x5a87a8: ret
    //     0x5a87a8: ret             
    // 0x5a87ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a87ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a87b0: b               #0x5a8788
  }
  _ handleDeviceMethodCall(/* No info */) async {
    // ** addr: 0x5a87b4, size: 0x140
    // 0x5a87b4: EnterFrame
    //     0x5a87b4: stp             fp, lr, [SP, #-0x10]!
    //     0x5a87b8: mov             fp, SP
    // 0x5a87bc: AllocStack(0x18)
    //     0x5a87bc: sub             SP, SP, #0x18
    // 0x5a87c0: SetupParameters(MethodChannelCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x5a87c0: stur            NULL, [fp, #-8]
    //     0x5a87c4: mov             x0, #0
    //     0x5a87c8: add             x1, fp, w0, sxtw #2
    //     0x5a87cc: ldr             x1, [x1, #0x18]
    //     0x5a87d0: stur            x1, [fp, #-0x18]
    //     0x5a87d4: add             x2, fp, w0, sxtw #2
    //     0x5a87d8: ldr             x2, [x2, #0x10]
    //     0x5a87dc: stur            x2, [fp, #-0x10]
    // 0x5a87e0: CheckStackOverflow
    //     0x5a87e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a87e4: cmp             SP, x16
    //     0x5a87e8: b.ls            #0x5a88e8
    // 0x5a87ec: InitAsync() -> Future
    //     0x5a87ec: mov             x0, NULL
    //     0x5a87f0: bl              #0x4b92e4
    // 0x5a87f4: ldur            x0, [fp, #-0x10]
    // 0x5a87f8: LoadField: r1 = r0->field_7
    //     0x5a87f8: ldur            w1, [x0, #7]
    // 0x5a87fc: DecompressPointer r1
    //     0x5a87fc: add             x1, x1, HEAP, lsl #32
    // 0x5a8800: r16 = "orientation_changed"
    //     0x5a8800: ldr             x16, [PP, #0xdd8]  ; [pp+0xdd8] "orientation_changed"
    // 0x5a8804: stp             x1, x16, [SP, #-0x10]!
    // 0x5a8808: r0 = ==()
    //     0x5a8808: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0x5a880c: add             SP, SP, #0x10
    // 0x5a8810: tbnz            w0, #4, #0x5a88dc
    // 0x5a8814: ldur            x0, [fp, #-0x18]
    // 0x5a8818: ldur            x16, [fp, #-0x10]
    // 0x5a881c: stp             x16, x0, [SP, #-0x10]!
    // 0x5a8820: r0 = _getArgumentDictionary()
    //     0x5a8820: bl              #0x5a8b10  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_getArgumentDictionary
    // 0x5a8824: add             SP, SP, #0x10
    // 0x5a8828: mov             x1, x0
    // 0x5a882c: ldur            x0, [fp, #-0x18]
    // 0x5a8830: LoadField: r2 = r0->field_f
    //     0x5a8830: ldur            w2, [x0, #0xf]
    // 0x5a8834: DecompressPointer r2
    //     0x5a8834: add             x2, x2, HEAP, lsl #32
    // 0x5a8838: stur            x2, [fp, #-0x10]
    // 0x5a883c: r0 = LoadClassIdInstr(r1)
    //     0x5a883c: ldur            x0, [x1, #-1]
    //     0x5a8840: ubfx            x0, x0, #0xc, #0x14
    // 0x5a8844: r16 = "orientation"
    //     0x5a8844: ldr             x16, [PP, #0xde0]  ; [pp+0xde0] "orientation"
    // 0x5a8848: stp             x16, x1, [SP, #-0x10]!
    // 0x5a884c: r0 = GDT[cid_x0 + -0xef]()
    //     0x5a884c: sub             lr, x0, #0xef
    //     0x5a8850: ldr             lr, [x21, lr, lsl #3]
    //     0x5a8854: blr             lr
    // 0x5a8858: add             SP, SP, #0x10
    // 0x5a885c: mov             x3, x0
    // 0x5a8860: stur            x3, [fp, #-0x18]
    // 0x5a8864: cmp             w3, NULL
    // 0x5a8868: b.eq            #0x5a88f0
    // 0x5a886c: mov             x0, x3
    // 0x5a8870: r2 = Null
    //     0x5a8870: mov             x2, NULL
    // 0x5a8874: r1 = Null
    //     0x5a8874: mov             x1, NULL
    // 0x5a8878: r4 = 59
    //     0x5a8878: mov             x4, #0x3b
    // 0x5a887c: branchIfSmi(r0, 0x5a8888)
    //     0x5a887c: tbz             w0, #0, #0x5a8888
    // 0x5a8880: r4 = LoadClassIdInstr(r0)
    //     0x5a8880: ldur            x4, [x0, #-1]
    //     0x5a8884: ubfx            x4, x4, #0xc, #0x14
    // 0x5a8888: sub             x4, x4, #0x5d
    // 0x5a888c: cmp             x4, #3
    // 0x5a8890: b.ls            #0x5a88a0
    // 0x5a8894: r8 = String
    //     0x5a8894: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x5a8898: r3 = Null
    //     0x5a8898: ldr             x3, [PP, #0xde8]  ; [pp+0xde8] Null
    // 0x5a889c: r0 = String()
    //     0x5a889c: bl              #0xd72afc  ; IsType_String_Stub
    // 0x5a88a0: ldur            x16, [fp, #-0x18]
    // 0x5a88a4: SaveReg r16
    //     0x5a88a4: str             x16, [SP, #-8]!
    // 0x5a88a8: r0 = deserializeDeviceOrientation()
    //     0x5a88a8: bl              #0x5a89d0  ; [package:camera_android/src/utils.dart] ::deserializeDeviceOrientation
    // 0x5a88ac: add             SP, SP, #8
    // 0x5a88b0: stur            x0, [fp, #-0x18]
    // 0x5a88b4: r0 = DeviceOrientationChangedEvent()
    //     0x5a88b4: bl              #0x5a88f4  ; AllocateDeviceOrientationChangedEventStub -> DeviceOrientationChangedEvent (size=0xc)
    // 0x5a88b8: mov             x1, x0
    // 0x5a88bc: ldur            x0, [fp, #-0x18]
    // 0x5a88c0: StoreField: r1->field_7 = r0
    //     0x5a88c0: stur            w0, [x1, #7]
    // 0x5a88c4: ldur            x16, [fp, #-0x10]
    // 0x5a88c8: stp             x1, x16, [SP, #-0x10]!
    // 0x5a88cc: r0 = add()
    //     0x5a88cc: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0x5a88d0: add             SP, SP, #0x10
    // 0x5a88d4: r0 = Null
    //     0x5a88d4: mov             x0, NULL
    // 0x5a88d8: r0 = ReturnAsyncNotFuture()
    //     0x5a88d8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5a88dc: r0 = MissingPluginException()
    //     0x5a88dc: bl              #0x501aa4  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0x5a88e0: r0 = Throw()
    //     0x5a88e0: bl              #0xd67e38  ; ThrowStub
    // 0x5a88e4: brk             #0
    // 0x5a88e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a88e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a88ec: b               #0x5a87ec
    // 0x5a88f0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x5a88f0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getArgumentDictionary(/* No info */) {
    // ** addr: 0x5a8b10, size: 0x80
    // 0x5a8b10: EnterFrame
    //     0x5a8b10: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8b14: mov             fp, SP
    // 0x5a8b18: AllocStack(0x8)
    //     0x5a8b18: sub             SP, SP, #8
    // 0x5a8b1c: CheckStackOverflow
    //     0x5a8b1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8b20: cmp             SP, x16
    //     0x5a8b24: b.ls            #0x5a8b88
    // 0x5a8b28: ldr             x0, [fp, #0x10]
    // 0x5a8b2c: LoadField: r3 = r0->field_b
    //     0x5a8b2c: ldur            w3, [x0, #0xb]
    // 0x5a8b30: DecompressPointer r3
    //     0x5a8b30: add             x3, x3, HEAP, lsl #32
    // 0x5a8b34: mov             x0, x3
    // 0x5a8b38: stur            x3, [fp, #-8]
    // 0x5a8b3c: r2 = Null
    //     0x5a8b3c: mov             x2, NULL
    // 0x5a8b40: r1 = Null
    //     0x5a8b40: mov             x1, NULL
    // 0x5a8b44: r8 = Map<Object?, Object?>
    //     0x5a8b44: ldr             x8, [PP, #0xe70]  ; [pp+0xe70] Type: Map<Object?, Object?>
    // 0x5a8b48: r3 = Null
    //     0x5a8b48: ldr             x3, [PP, #0xe78]  ; [pp+0xe78] Null
    // 0x5a8b4c: r0 = Map<Object?, Object?>()
    //     0x5a8b4c: bl              #0x5a8b90  ; IsType_Map<Object?, Object?>_Stub
    // 0x5a8b50: ldur            x0, [fp, #-8]
    // 0x5a8b54: r1 = LoadClassIdInstr(r0)
    //     0x5a8b54: ldur            x1, [x0, #-1]
    //     0x5a8b58: ubfx            x1, x1, #0xc, #0x14
    // 0x5a8b5c: r16 = <String, Object?>
    //     0x5a8b5c: ldr             x16, [PP, #0xe88]  ; [pp+0xe88] TypeArguments: <String, Object?>
    // 0x5a8b60: stp             x0, x16, [SP, #-0x10]!
    // 0x5a8b64: mov             x0, x1
    // 0x5a8b68: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0x5a8b68: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0x5a8b6c: r0 = GDT[cid_x0 + 0x375]()
    //     0x5a8b6c: add             lr, x0, #0x375
    //     0x5a8b70: ldr             lr, [x21, lr, lsl #3]
    //     0x5a8b74: blr             lr
    // 0x5a8b78: add             SP, SP, #0x10
    // 0x5a8b7c: LeaveFrame
    //     0x5a8b7c: mov             SP, fp
    //     0x5a8b80: ldp             fp, lr, [SP], #0x10
    // 0x5a8b84: ret
    //     0x5a8b84: ret             
    // 0x5a8b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8b88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a8b8c: b               #0x5a8b28
  }
  _ _cameraEvents(/* No info */) {
    // ** addr: 0x5aa890, size: 0xac
    // 0x5aa890: EnterFrame
    //     0x5aa890: stp             fp, lr, [SP, #-0x10]!
    //     0x5aa894: mov             fp, SP
    // 0x5aa898: AllocStack(0x18)
    //     0x5aa898: sub             SP, SP, #0x18
    // 0x5aa89c: CheckStackOverflow
    //     0x5aa89c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5aa8a0: cmp             SP, x16
    //     0x5aa8a4: b.ls            #0x5aa934
    // 0x5aa8a8: ldr             x2, [fp, #0x10]
    // 0x5aa8ac: r0 = BoxInt64Instr(r2)
    //     0x5aa8ac: sbfiz           x0, x2, #1, #0x1f
    //     0x5aa8b0: cmp             x2, x0, asr #1
    //     0x5aa8b4: b.eq            #0x5aa8c0
    //     0x5aa8b8: bl              #0xd69bb8
    //     0x5aa8bc: stur            x2, [x0, #7]
    // 0x5aa8c0: stur            x0, [fp, #-8]
    // 0x5aa8c4: r1 = 1
    //     0x5aa8c4: mov             x1, #1
    // 0x5aa8c8: r0 = AllocateContext()
    //     0x5aa8c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x5aa8cc: mov             x2, x0
    // 0x5aa8d0: ldur            x0, [fp, #-8]
    // 0x5aa8d4: stur            x2, [fp, #-0x10]
    // 0x5aa8d8: StoreField: r2->field_f = r0
    //     0x5aa8d8: stur            w0, [x2, #0xf]
    // 0x5aa8dc: ldr             x0, [fp, #0x18]
    // 0x5aa8e0: LoadField: r3 = r0->field_b
    //     0x5aa8e0: ldur            w3, [x0, #0xb]
    // 0x5aa8e4: DecompressPointer r3
    //     0x5aa8e4: add             x3, x3, HEAP, lsl #32
    // 0x5aa8e8: stur            x3, [fp, #-8]
    // 0x5aa8ec: LoadField: r1 = r3->field_7
    //     0x5aa8ec: ldur            w1, [x3, #7]
    // 0x5aa8f0: DecompressPointer r1
    //     0x5aa8f0: add             x1, x1, HEAP, lsl #32
    // 0x5aa8f4: r0 = _BroadcastStream()
    //     0x5aa8f4: bl              #0x5a25c8  ; Allocate_BroadcastStreamStub -> _BroadcastStream<X0> (size=0x14)
    // 0x5aa8f8: mov             x3, x0
    // 0x5aa8fc: ldur            x0, [fp, #-8]
    // 0x5aa900: stur            x3, [fp, #-0x18]
    // 0x5aa904: StoreField: r3->field_f = r0
    //     0x5aa904: stur            w0, [x3, #0xf]
    // 0x5aa908: ldur            x2, [fp, #-0x10]
    // 0x5aa90c: r1 = Function '<anonymous closure>':.
    //     0x5aa90c: add             x1, PP, #0x4d, lsl #12  ; [pp+0x4d4f0] AnonymousClosure: (0x5aa750), in [package:camera_android/src/android_camera.dart] AndroidCamera::_cameraEvents (0x5aa63c)
    //     0x5aa910: ldr             x1, [x1, #0x4f0]
    // 0x5aa914: r0 = AllocateClosure()
    //     0x5aa914: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5aa918: ldur            x16, [fp, #-0x18]
    // 0x5aa91c: stp             x0, x16, [SP, #-0x10]!
    // 0x5aa920: r0 = where()
    //     0x5aa920: bl              #0x5aa6e8  ; [dart:async] Stream::where
    // 0x5aa924: add             SP, SP, #0x10
    // 0x5aa928: LeaveFrame
    //     0x5aa928: mov             SP, fp
    //     0x5aa92c: ldp             fp, lr, [SP], #0x10
    // 0x5aa930: ret
    //     0x5aa930: ret             
    // 0x5aa934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5aa934: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5aa938: b               #0x5aa8a8
  }
  _ resumePreview(/* No info */) async {
    // ** addr: 0xc5f398, size: 0xc0
    // 0xc5f398: EnterFrame
    //     0xc5f398: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f39c: mov             fp, SP
    // 0xc5f3a0: AllocStack(0x18)
    //     0xc5f3a0: sub             SP, SP, #0x18
    // 0xc5f3a4: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc5f3a4: stur            NULL, [fp, #-8]
    //     0xc5f3a8: mov             x0, #0
    //     0xc5f3ac: add             x1, fp, w0, sxtw #2
    //     0xc5f3b0: ldr             x1, [x1, #0x10]
    //     0xc5f3b4: stur            x1, [fp, #-0x10]
    // 0xc5f3b8: CheckStackOverflow
    //     0xc5f3b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f3bc: cmp             SP, x16
    //     0xc5f3c0: b.ls            #0xc5f450
    // 0xc5f3c4: InitAsync() -> Future<void?>
    //     0xc5f3c4: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f3c8: bl              #0x4b92e4
    // 0xc5f3cc: r1 = Null
    //     0xc5f3cc: mov             x1, NULL
    // 0xc5f3d0: r2 = 4
    //     0xc5f3d0: mov             x2, #4
    // 0xc5f3d4: r0 = AllocateArray()
    //     0xc5f3d4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f3d8: mov             x2, x0
    // 0xc5f3dc: r17 = "cameraId"
    //     0xc5f3dc: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f3e0: ldr             x17, [x17, #0x890]
    // 0xc5f3e4: StoreField: r2->field_f = r17
    //     0xc5f3e4: stur            w17, [x2, #0xf]
    // 0xc5f3e8: ldur            x3, [fp, #-0x10]
    // 0xc5f3ec: r0 = BoxInt64Instr(r3)
    //     0xc5f3ec: sbfiz           x0, x3, #1, #0x1f
    //     0xc5f3f0: cmp             x3, x0, asr #1
    //     0xc5f3f4: b.eq            #0xc5f400
    //     0xc5f3f8: bl              #0xd69bb8
    //     0xc5f3fc: stur            x3, [x0, #7]
    // 0xc5f400: StoreField: r2->field_13 = r0
    //     0xc5f400: stur            w0, [x2, #0x13]
    // 0xc5f404: r16 = <String, dynamic>
    //     0xc5f404: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f408: stp             x2, x16, [SP, #-0x10]!
    // 0xc5f40c: r0 = Map._fromLiteral()
    //     0xc5f40c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f410: add             SP, SP, #0x10
    // 0xc5f414: r16 = <double>
    //     0xc5f414: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f418: r30 = Instance_MethodChannel
    //     0xc5f418: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc5f41c: ldr             lr, [lr, #0x360]
    // 0xc5f420: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f424: r16 = "resumePreview"
    //     0xc5f424: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ac8] "resumePreview"
    //     0xc5f428: ldr             x16, [x16, #0xac8]
    // 0xc5f42c: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f430: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f430: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f434: r0 = invokeMethod()
    //     0xc5f434: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f438: add             SP, SP, #0x20
    // 0xc5f43c: mov             x1, x0
    // 0xc5f440: stur            x1, [fp, #-0x18]
    // 0xc5f444: r0 = Await()
    //     0xc5f444: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f448: r0 = Null
    //     0xc5f448: mov             x0, NULL
    // 0xc5f44c: r0 = ReturnAsyncNotFuture()
    //     0xc5f44c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f450: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5f450: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5f454: b               #0xc5f3c4
  }
  _ pausePreview(/* No info */) async {
    // ** addr: 0xc5f5d8, size: 0xc0
    // 0xc5f5d8: EnterFrame
    //     0xc5f5d8: stp             fp, lr, [SP, #-0x10]!
    //     0xc5f5dc: mov             fp, SP
    // 0xc5f5e0: AllocStack(0x18)
    //     0xc5f5e0: sub             SP, SP, #0x18
    // 0xc5f5e4: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc5f5e4: stur            NULL, [fp, #-8]
    //     0xc5f5e8: mov             x0, #0
    //     0xc5f5ec: add             x1, fp, w0, sxtw #2
    //     0xc5f5f0: ldr             x1, [x1, #0x10]
    //     0xc5f5f4: stur            x1, [fp, #-0x10]
    // 0xc5f5f8: CheckStackOverflow
    //     0xc5f5f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5f5fc: cmp             SP, x16
    //     0xc5f600: b.ls            #0xc5f690
    // 0xc5f604: InitAsync() -> Future<void?>
    //     0xc5f604: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5f608: bl              #0x4b92e4
    // 0xc5f60c: r1 = Null
    //     0xc5f60c: mov             x1, NULL
    // 0xc5f610: r2 = 4
    //     0xc5f610: mov             x2, #4
    // 0xc5f614: r0 = AllocateArray()
    //     0xc5f614: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5f618: mov             x2, x0
    // 0xc5f61c: r17 = "cameraId"
    //     0xc5f61c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5f620: ldr             x17, [x17, #0x890]
    // 0xc5f624: StoreField: r2->field_f = r17
    //     0xc5f624: stur            w17, [x2, #0xf]
    // 0xc5f628: ldur            x3, [fp, #-0x10]
    // 0xc5f62c: r0 = BoxInt64Instr(r3)
    //     0xc5f62c: sbfiz           x0, x3, #1, #0x1f
    //     0xc5f630: cmp             x3, x0, asr #1
    //     0xc5f634: b.eq            #0xc5f640
    //     0xc5f638: bl              #0xd69bb8
    //     0xc5f63c: stur            x3, [x0, #7]
    // 0xc5f640: StoreField: r2->field_13 = r0
    //     0xc5f640: stur            w0, [x2, #0x13]
    // 0xc5f644: r16 = <String, dynamic>
    //     0xc5f644: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5f648: stp             x2, x16, [SP, #-0x10]!
    // 0xc5f64c: r0 = Map._fromLiteral()
    //     0xc5f64c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5f650: add             SP, SP, #0x10
    // 0xc5f654: r16 = <double>
    //     0xc5f654: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5f658: r30 = Instance_MethodChannel
    //     0xc5f658: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc5f65c: ldr             lr, [lr, #0x360]
    // 0xc5f660: stp             lr, x16, [SP, #-0x10]!
    // 0xc5f664: r16 = "pausePreview"
    //     0xc5f664: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ad0] "pausePreview"
    //     0xc5f668: ldr             x16, [x16, #0xad0]
    // 0xc5f66c: stp             x0, x16, [SP, #-0x10]!
    // 0xc5f670: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5f670: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5f674: r0 = invokeMethod()
    //     0xc5f674: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5f678: add             SP, SP, #0x20
    // 0xc5f67c: mov             x1, x0
    // 0xc5f680: stur            x1, [fp, #-0x18]
    // 0xc5f684: r0 = Await()
    //     0xc5f684: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5f688: r0 = Null
    //     0xc5f688: mov             x0, NULL
    // 0xc5f68c: r0 = ReturnAsyncNotFuture()
    //     0xc5f68c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5f690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5f690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5f694: b               #0xc5f604
  }
  _ setZoomLevel(/* No info */) async {
    // ** addr: 0xc5fa08, size: 0x184
    // 0xc5fa08: EnterFrame
    //     0xc5fa08: stp             fp, lr, [SP, #-0x10]!
    //     0xc5fa0c: mov             fp, SP
    // 0xc5fa10: AllocStack(0x68)
    //     0xc5fa10: sub             SP, SP, #0x68
    // 0xc5fa14: SetupParameters(MethodChannelCamera this /* r1, fp-0x60 */, dynamic _ /* r2, fp-0x58 */, dynamic _ /* d0, fp-0x68 */)
    //     0xc5fa14: stur            NULL, [fp, #-8]
    //     0xc5fa18: mov             x0, #0
    //     0xc5fa1c: add             x1, fp, w0, sxtw #2
    //     0xc5fa20: ldr             x1, [x1, #0x20]
    //     0xc5fa24: stur            x1, [fp, #-0x60]
    //     0xc5fa28: add             x2, fp, w0, sxtw #2
    //     0xc5fa2c: ldr             x2, [x2, #0x18]
    //     0xc5fa30: stur            x2, [fp, #-0x58]
    //     0xc5fa34: add             x3, fp, w0, sxtw #2
    //     0xc5fa38: ldr             d0, [x3, #0x10]
    //     0xc5fa3c: stur            d0, [fp, #-0x68]
    // 0xc5fa40: CheckStackOverflow
    //     0xc5fa40: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5fa44: cmp             SP, x16
    //     0xc5fa48: b.ls            #0xc5fb68
    // 0xc5fa4c: InitAsync() -> Future<void?>
    //     0xc5fa4c: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc5fa50: bl              #0x4b92e4
    // 0xc5fa54: ldur            x0, [fp, #-0x58]
    // 0xc5fa58: ldur            d0, [fp, #-0x68]
    // 0xc5fa5c: r1 = Null
    //     0xc5fa5c: mov             x1, NULL
    // 0xc5fa60: r2 = 8
    //     0xc5fa60: mov             x2, #8
    // 0xc5fa64: r0 = AllocateArray()
    //     0xc5fa64: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5fa68: r17 = "cameraId"
    //     0xc5fa68: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5fa6c: ldr             x17, [x17, #0x890]
    // 0xc5fa70: StoreField: r0->field_f = r17
    //     0xc5fa70: stur            w17, [x0, #0xf]
    // 0xc5fa74: ldur            x1, [fp, #-0x58]
    // 0xc5fa78: StoreField: r0->field_13 = r1
    //     0xc5fa78: stur            w1, [x0, #0x13]
    // 0xc5fa7c: r17 = "zoom"
    //     0xc5fa7c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ad8] "zoom"
    //     0xc5fa80: ldr             x17, [x17, #0xad8]
    // 0xc5fa84: StoreField: r0->field_17 = r17
    //     0xc5fa84: stur            w17, [x0, #0x17]
    // 0xc5fa88: ldur            d0, [fp, #-0x68]
    // 0xc5fa8c: r1 = inline_Allocate_Double()
    //     0xc5fa8c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc5fa90: add             x1, x1, #0x10
    //     0xc5fa94: cmp             x2, x1
    //     0xc5fa98: b.ls            #0xc5fb70
    //     0xc5fa9c: str             x1, [THR, #0x60]  ; THR::top
    //     0xc5faa0: sub             x1, x1, #0xf
    //     0xc5faa4: mov             x2, #0xd108
    //     0xc5faa8: movk            x2, #3, lsl #16
    //     0xc5faac: stur            x2, [x1, #-1]
    // 0xc5fab0: StoreField: r1->field_7 = d0
    //     0xc5fab0: stur            d0, [x1, #7]
    // 0xc5fab4: StoreField: r0->field_1b = r1
    //     0xc5fab4: stur            w1, [x0, #0x1b]
    // 0xc5fab8: r16 = <String, dynamic>
    //     0xc5fab8: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5fabc: stp             x0, x16, [SP, #-0x10]!
    // 0xc5fac0: r0 = Map._fromLiteral()
    //     0xc5fac0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5fac4: add             SP, SP, #0x10
    // 0xc5fac8: r16 = <double>
    //     0xc5fac8: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5facc: r30 = Instance_MethodChannel
    //     0xc5facc: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc5fad0: ldr             lr, [lr, #0x360]
    // 0xc5fad4: stp             lr, x16, [SP, #-0x10]!
    // 0xc5fad8: r16 = "setZoomLevel"
    //     0xc5fad8: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d268] "setZoomLevel"
    //     0xc5fadc: ldr             x16, [x16, #0x268]
    // 0xc5fae0: stp             x0, x16, [SP, #-0x10]!
    // 0xc5fae4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5fae4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5fae8: r0 = invokeMethod()
    //     0xc5fae8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5faec: add             SP, SP, #0x20
    // 0xc5faf0: mov             x1, x0
    // 0xc5faf4: stur            x1, [fp, #-0x58]
    // 0xc5faf8: r0 = Await()
    //     0xc5faf8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5fafc: r0 = Null
    //     0xc5fafc: mov             x0, NULL
    // 0xc5fb00: r0 = ReturnAsyncNotFuture()
    //     0xc5fb00: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc5fb04: sub             SP, fp, #0x68
    // 0xc5fb08: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc5fb08: mov             x2, #0x76
    //     0xc5fb0c: tbz             w0, #0, #0xc5fb1c
    //     0xc5fb10: ldur            x2, [x0, #-1]
    //     0xc5fb14: ubfx            x2, x2, #0xc, #0x14
    //     0xc5fb18: lsl             x2, x2, #1
    // 0xc5fb1c: cmp             w2, #0xf28
    // 0xc5fb20: b.ne            #0xc5fb60
    // 0xc5fb24: LoadField: r1 = r0->field_7
    //     0xc5fb24: ldur            w1, [x0, #7]
    // 0xc5fb28: DecompressPointer r1
    //     0xc5fb28: add             x1, x1, HEAP, lsl #32
    // 0xc5fb2c: stur            x1, [fp, #-0x60]
    // 0xc5fb30: LoadField: r2 = r0->field_b
    //     0xc5fb30: ldur            w2, [x0, #0xb]
    // 0xc5fb34: DecompressPointer r2
    //     0xc5fb34: add             x2, x2, HEAP, lsl #32
    // 0xc5fb38: stur            x2, [fp, #-0x58]
    // 0xc5fb3c: r0 = CameraException()
    //     0xc5fb3c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc5fb40: mov             x1, x0
    // 0xc5fb44: ldur            x0, [fp, #-0x60]
    // 0xc5fb48: StoreField: r1->field_7 = r0
    //     0xc5fb48: stur            w0, [x1, #7]
    // 0xc5fb4c: ldur            x0, [fp, #-0x58]
    // 0xc5fb50: StoreField: r1->field_b = r0
    //     0xc5fb50: stur            w0, [x1, #0xb]
    // 0xc5fb54: mov             x0, x1
    // 0xc5fb58: r0 = Throw()
    //     0xc5fb58: bl              #0xd67e38  ; ThrowStub
    // 0xc5fb5c: brk             #0
    // 0xc5fb60: r0 = ReThrow()
    //     0xc5fb60: bl              #0xd67e14  ; ReThrowStub
    // 0xc5fb64: brk             #0
    // 0xc5fb68: r0 = StackOverflowSharedWithFPURegs()
    //     0xc5fb68: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc5fb6c: b               #0xc5fa4c
    // 0xc5fb70: SaveReg d0
    //     0xc5fb70: str             q0, [SP, #-0x10]!
    // 0xc5fb74: SaveReg r0
    //     0xc5fb74: str             x0, [SP, #-8]!
    // 0xc5fb78: r0 = AllocateDouble()
    //     0xc5fb78: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc5fb7c: mov             x1, x0
    // 0xc5fb80: RestoreReg r0
    //     0xc5fb80: ldr             x0, [SP], #8
    // 0xc5fb84: RestoreReg d0
    //     0xc5fb84: ldr             q0, [SP], #0x10
    // 0xc5fb88: b               #0xc5fab0
  }
  _ getMinZoomLevel(/* No info */) async {
    // ** addr: 0xc5fdb8, size: 0xc8
    // 0xc5fdb8: EnterFrame
    //     0xc5fdb8: stp             fp, lr, [SP, #-0x10]!
    //     0xc5fdbc: mov             fp, SP
    // 0xc5fdc0: AllocStack(0x18)
    //     0xc5fdc0: sub             SP, SP, #0x18
    // 0xc5fdc4: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc5fdc4: stur            NULL, [fp, #-8]
    //     0xc5fdc8: mov             x0, #0
    //     0xc5fdcc: add             x1, fp, w0, sxtw #2
    //     0xc5fdd0: ldr             x1, [x1, #0x10]
    //     0xc5fdd4: stur            x1, [fp, #-0x10]
    // 0xc5fdd8: CheckStackOverflow
    //     0xc5fdd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc5fddc: cmp             SP, x16
    //     0xc5fde0: b.ls            #0xc5fe74
    // 0xc5fde4: InitAsync() -> Future<double>
    //     0xc5fde4: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc5fde8: bl              #0x4b92e4
    // 0xc5fdec: r1 = Null
    //     0xc5fdec: mov             x1, NULL
    // 0xc5fdf0: r2 = 4
    //     0xc5fdf0: mov             x2, #4
    // 0xc5fdf4: r0 = AllocateArray()
    //     0xc5fdf4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc5fdf8: mov             x2, x0
    // 0xc5fdfc: r17 = "cameraId"
    //     0xc5fdfc: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc5fe00: ldr             x17, [x17, #0x890]
    // 0xc5fe04: StoreField: r2->field_f = r17
    //     0xc5fe04: stur            w17, [x2, #0xf]
    // 0xc5fe08: ldur            x3, [fp, #-0x10]
    // 0xc5fe0c: r0 = BoxInt64Instr(r3)
    //     0xc5fe0c: sbfiz           x0, x3, #1, #0x1f
    //     0xc5fe10: cmp             x3, x0, asr #1
    //     0xc5fe14: b.eq            #0xc5fe20
    //     0xc5fe18: bl              #0xd69bb8
    //     0xc5fe1c: stur            x3, [x0, #7]
    // 0xc5fe20: StoreField: r2->field_13 = r0
    //     0xc5fe20: stur            w0, [x2, #0x13]
    // 0xc5fe24: r16 = <String, dynamic>
    //     0xc5fe24: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc5fe28: stp             x2, x16, [SP, #-0x10]!
    // 0xc5fe2c: r0 = Map._fromLiteral()
    //     0xc5fe2c: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc5fe30: add             SP, SP, #0x10
    // 0xc5fe34: r16 = <double>
    //     0xc5fe34: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc5fe38: r30 = Instance_MethodChannel
    //     0xc5fe38: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc5fe3c: ldr             lr, [lr, #0x360]
    // 0xc5fe40: stp             lr, x16, [SP, #-0x10]!
    // 0xc5fe44: r16 = "getMinZoomLevel"
    //     0xc5fe44: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d338] "getMinZoomLevel"
    //     0xc5fe48: ldr             x16, [x16, #0x338]
    // 0xc5fe4c: stp             x0, x16, [SP, #-0x10]!
    // 0xc5fe50: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc5fe50: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc5fe54: r0 = invokeMethod()
    //     0xc5fe54: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc5fe58: add             SP, SP, #0x20
    // 0xc5fe5c: mov             x1, x0
    // 0xc5fe60: stur            x1, [fp, #-0x18]
    // 0xc5fe64: r0 = Await()
    //     0xc5fe64: bl              #0x4b8e6c  ; AwaitStub
    // 0xc5fe68: cmp             w0, NULL
    // 0xc5fe6c: b.eq            #0xc5fe7c
    // 0xc5fe70: r0 = ReturnAsync()
    //     0xc5fe70: b               #0x501858  ; ReturnAsyncStub
    // 0xc5fe74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc5fe74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc5fe78: b               #0xc5fde4
    // 0xc5fe7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc5fe7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxZoomLevel(/* No info */) async {
    // ** addr: 0xc60338, size: 0xc8
    // 0xc60338: EnterFrame
    //     0xc60338: stp             fp, lr, [SP, #-0x10]!
    //     0xc6033c: mov             fp, SP
    // 0xc60340: AllocStack(0x18)
    //     0xc60340: sub             SP, SP, #0x18
    // 0xc60344: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc60344: stur            NULL, [fp, #-8]
    //     0xc60348: mov             x0, #0
    //     0xc6034c: add             x1, fp, w0, sxtw #2
    //     0xc60350: ldr             x1, [x1, #0x10]
    //     0xc60354: stur            x1, [fp, #-0x10]
    // 0xc60358: CheckStackOverflow
    //     0xc60358: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6035c: cmp             SP, x16
    //     0xc60360: b.ls            #0xc603f4
    // 0xc60364: InitAsync() -> Future<double>
    //     0xc60364: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc60368: bl              #0x4b92e4
    // 0xc6036c: r1 = Null
    //     0xc6036c: mov             x1, NULL
    // 0xc60370: r2 = 4
    //     0xc60370: mov             x2, #4
    // 0xc60374: r0 = AllocateArray()
    //     0xc60374: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc60378: mov             x2, x0
    // 0xc6037c: r17 = "cameraId"
    //     0xc6037c: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc60380: ldr             x17, [x17, #0x890]
    // 0xc60384: StoreField: r2->field_f = r17
    //     0xc60384: stur            w17, [x2, #0xf]
    // 0xc60388: ldur            x3, [fp, #-0x10]
    // 0xc6038c: r0 = BoxInt64Instr(r3)
    //     0xc6038c: sbfiz           x0, x3, #1, #0x1f
    //     0xc60390: cmp             x3, x0, asr #1
    //     0xc60394: b.eq            #0xc603a0
    //     0xc60398: bl              #0xd69bb8
    //     0xc6039c: stur            x3, [x0, #7]
    // 0xc603a0: StoreField: r2->field_13 = r0
    //     0xc603a0: stur            w0, [x2, #0x13]
    // 0xc603a4: r16 = <String, dynamic>
    //     0xc603a4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc603a8: stp             x2, x16, [SP, #-0x10]!
    // 0xc603ac: r0 = Map._fromLiteral()
    //     0xc603ac: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc603b0: add             SP, SP, #0x10
    // 0xc603b4: r16 = <double>
    //     0xc603b4: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc603b8: r30 = Instance_MethodChannel
    //     0xc603b8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc603bc: ldr             lr, [lr, #0x360]
    // 0xc603c0: stp             lr, x16, [SP, #-0x10]!
    // 0xc603c4: r16 = "getMaxZoomLevel"
    //     0xc603c4: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d340] "getMaxZoomLevel"
    //     0xc603c8: ldr             x16, [x16, #0x340]
    // 0xc603cc: stp             x0, x16, [SP, #-0x10]!
    // 0xc603d0: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc603d0: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc603d4: r0 = invokeMethod()
    //     0xc603d4: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc603d8: add             SP, SP, #0x20
    // 0xc603dc: mov             x1, x0
    // 0xc603e0: stur            x1, [fp, #-0x18]
    // 0xc603e4: r0 = Await()
    //     0xc603e4: bl              #0x4b8e6c  ; AwaitStub
    // 0xc603e8: cmp             w0, NULL
    // 0xc603ec: b.eq            #0xc603fc
    // 0xc603f0: r0 = ReturnAsync()
    //     0xc603f0: b               #0x501858  ; ReturnAsyncStub
    // 0xc603f4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc603f4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc603f8: b               #0xc60364
    // 0xc603fc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc603fc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setFocusPoint(/* No info */) {
    // ** addr: 0xc6082c, size: 0x180
    // 0xc6082c: EnterFrame
    //     0xc6082c: stp             fp, lr, [SP, #-0x10]!
    //     0xc60830: mov             fp, SP
    // 0xc60834: CheckStackOverflow
    //     0xc60834: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc60838: cmp             SP, x16
    //     0xc6083c: b.ls            #0xc60970
    // 0xc60840: r1 = Null
    //     0xc60840: mov             x1, NULL
    // 0xc60844: r2 = 16
    //     0xc60844: mov             x2, #0x10
    // 0xc60848: r0 = AllocateArray()
    //     0xc60848: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6084c: mov             x2, x0
    // 0xc60850: r17 = "cameraId"
    //     0xc60850: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc60854: ldr             x17, [x17, #0x890]
    // 0xc60858: StoreField: r2->field_f = r17
    //     0xc60858: stur            w17, [x2, #0xf]
    // 0xc6085c: ldr             x3, [fp, #0x18]
    // 0xc60860: r0 = BoxInt64Instr(r3)
    //     0xc60860: sbfiz           x0, x3, #1, #0x1f
    //     0xc60864: cmp             x3, x0, asr #1
    //     0xc60868: b.eq            #0xc60874
    //     0xc6086c: bl              #0xd69bb8
    //     0xc60870: stur            x3, [x0, #7]
    // 0xc60874: StoreField: r2->field_13 = r0
    //     0xc60874: stur            w0, [x2, #0x13]
    // 0xc60878: r17 = "reset"
    //     0xc60878: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ae0] "reset"
    //     0xc6087c: ldr             x17, [x17, #0xae0]
    // 0xc60880: StoreField: r2->field_17 = r17
    //     0xc60880: stur            w17, [x2, #0x17]
    // 0xc60884: ldr             x0, [fp, #0x10]
    // 0xc60888: cmp             w0, NULL
    // 0xc6088c: r16 = true
    //     0xc6088c: add             x16, NULL, #0x20  ; true
    // 0xc60890: r17 = false
    //     0xc60890: add             x17, NULL, #0x30  ; false
    // 0xc60894: csel            x1, x16, x17, eq
    // 0xc60898: StoreField: r2->field_1b = r1
    //     0xc60898: stur            w1, [x2, #0x1b]
    // 0xc6089c: r17 = "x"
    //     0xc6089c: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc608a0: StoreField: r2->field_1f = r17
    //     0xc608a0: stur            w17, [x2, #0x1f]
    // 0xc608a4: cmp             w0, NULL
    // 0xc608a8: b.ne            #0xc608b4
    // 0xc608ac: r1 = Null
    //     0xc608ac: mov             x1, NULL
    // 0xc608b0: b               #0xc608e0
    // 0xc608b4: LoadField: d0 = r0->field_b
    //     0xc608b4: ldur            d0, [x0, #0xb]
    // 0xc608b8: r1 = inline_Allocate_Double()
    //     0xc608b8: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xc608bc: add             x1, x1, #0x10
    //     0xc608c0: cmp             x3, x1
    //     0xc608c4: b.ls            #0xc60978
    //     0xc608c8: str             x1, [THR, #0x60]  ; THR::top
    //     0xc608cc: sub             x1, x1, #0xf
    //     0xc608d0: mov             x3, #0xd108
    //     0xc608d4: movk            x3, #3, lsl #16
    //     0xc608d8: stur            x3, [x1, #-1]
    // 0xc608dc: StoreField: r1->field_7 = d0
    //     0xc608dc: stur            d0, [x1, #7]
    // 0xc608e0: StoreField: r2->field_23 = r1
    //     0xc608e0: stur            w1, [x2, #0x23]
    // 0xc608e4: r17 = "y"
    //     0xc608e4: ldr             x17, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc608e8: StoreField: r2->field_27 = r17
    //     0xc608e8: stur            w17, [x2, #0x27]
    // 0xc608ec: cmp             w0, NULL
    // 0xc608f0: b.ne            #0xc608fc
    // 0xc608f4: r0 = Null
    //     0xc608f4: mov             x0, NULL
    // 0xc608f8: b               #0xc60928
    // 0xc608fc: LoadField: d0 = r0->field_13
    //     0xc608fc: ldur            d0, [x0, #0x13]
    // 0xc60900: r0 = inline_Allocate_Double()
    //     0xc60900: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc60904: add             x0, x0, #0x10
    //     0xc60908: cmp             x1, x0
    //     0xc6090c: b.ls            #0xc60994
    //     0xc60910: str             x0, [THR, #0x60]  ; THR::top
    //     0xc60914: sub             x0, x0, #0xf
    //     0xc60918: mov             x1, #0xd108
    //     0xc6091c: movk            x1, #3, lsl #16
    //     0xc60920: stur            x1, [x0, #-1]
    // 0xc60924: StoreField: r0->field_7 = d0
    //     0xc60924: stur            d0, [x0, #7]
    // 0xc60928: StoreField: r2->field_2b = r0
    //     0xc60928: stur            w0, [x2, #0x2b]
    // 0xc6092c: r16 = <String, dynamic>
    //     0xc6092c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc60930: stp             x2, x16, [SP, #-0x10]!
    // 0xc60934: r0 = Map._fromLiteral()
    //     0xc60934: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc60938: add             SP, SP, #0x10
    // 0xc6093c: r16 = <void?>
    //     0xc6093c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc60940: r30 = Instance_MethodChannel
    //     0xc60940: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc60944: ldr             lr, [lr, #0x360]
    // 0xc60948: stp             lr, x16, [SP, #-0x10]!
    // 0xc6094c: r16 = "setFocusPoint"
    //     0xc6094c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53ae8] "setFocusPoint"
    //     0xc60950: ldr             x16, [x16, #0xae8]
    // 0xc60954: stp             x0, x16, [SP, #-0x10]!
    // 0xc60958: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc60958: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6095c: r0 = invokeMethod()
    //     0xc6095c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc60960: add             SP, SP, #0x20
    // 0xc60964: LeaveFrame
    //     0xc60964: mov             SP, fp
    //     0xc60968: ldp             fp, lr, [SP], #0x10
    // 0xc6096c: ret
    //     0xc6096c: ret             
    // 0xc60970: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc60970: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc60974: b               #0xc60840
    // 0xc60978: SaveReg d0
    //     0xc60978: str             q0, [SP, #-0x10]!
    // 0xc6097c: stp             x0, x2, [SP, #-0x10]!
    // 0xc60980: r0 = AllocateDouble()
    //     0xc60980: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc60984: mov             x1, x0
    // 0xc60988: ldp             x0, x2, [SP], #0x10
    // 0xc6098c: RestoreReg d0
    //     0xc6098c: ldr             q0, [SP], #0x10
    // 0xc60990: b               #0xc608dc
    // 0xc60994: SaveReg d0
    //     0xc60994: str             q0, [SP, #-0x10]!
    // 0xc60998: SaveReg r2
    //     0xc60998: str             x2, [SP, #-8]!
    // 0xc6099c: r0 = AllocateDouble()
    //     0xc6099c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc609a0: RestoreReg r2
    //     0xc609a0: ldr             x2, [SP], #8
    // 0xc609a4: RestoreReg d0
    //     0xc609a4: ldr             q0, [SP], #0x10
    // 0xc609a8: b               #0xc60924
  }
  _ setExposureOffset(/* No info */) async {
    // ** addr: 0xc642dc, size: 0x114
    // 0xc642dc: EnterFrame
    //     0xc642dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc642e0: mov             fp, SP
    // 0xc642e4: AllocStack(0x18)
    //     0xc642e4: sub             SP, SP, #0x18
    // 0xc642e8: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */, dynamic _ /* d0, fp-0x18 */)
    //     0xc642e8: stur            NULL, [fp, #-8]
    //     0xc642ec: mov             x0, #0
    //     0xc642f0: add             x1, fp, w0, sxtw #2
    //     0xc642f4: ldr             x1, [x1, #0x18]
    //     0xc642f8: stur            x1, [fp, #-0x10]
    //     0xc642fc: add             x2, fp, w0, sxtw #2
    //     0xc64300: ldr             d0, [x2, #0x10]
    //     0xc64304: stur            d0, [fp, #-0x18]
    // 0xc64308: CheckStackOverflow
    //     0xc64308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6430c: cmp             SP, x16
    //     0xc64310: b.ls            #0xc643c8
    // 0xc64314: InitAsync() -> Future<double>
    //     0xc64314: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc64318: bl              #0x4b92e4
    // 0xc6431c: r1 = Null
    //     0xc6431c: mov             x1, NULL
    // 0xc64320: r2 = 8
    //     0xc64320: mov             x2, #8
    // 0xc64324: r0 = AllocateArray()
    //     0xc64324: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64328: r17 = "cameraId"
    //     0xc64328: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6432c: ldr             x17, [x17, #0x890]
    // 0xc64330: StoreField: r0->field_f = r17
    //     0xc64330: stur            w17, [x0, #0xf]
    // 0xc64334: ldur            x1, [fp, #-0x10]
    // 0xc64338: StoreField: r0->field_13 = r1
    //     0xc64338: stur            w1, [x0, #0x13]
    // 0xc6433c: r17 = "offset"
    //     0xc6433c: add             x17, PP, #0x35, lsl #12  ; [pp+0x35530] "offset"
    //     0xc64340: ldr             x17, [x17, #0x530]
    // 0xc64344: StoreField: r0->field_17 = r17
    //     0xc64344: stur            w17, [x0, #0x17]
    // 0xc64348: ldur            d0, [fp, #-0x18]
    // 0xc6434c: r1 = inline_Allocate_Double()
    //     0xc6434c: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0xc64350: add             x1, x1, #0x10
    //     0xc64354: cmp             x2, x1
    //     0xc64358: b.ls            #0xc643d0
    //     0xc6435c: str             x1, [THR, #0x60]  ; THR::top
    //     0xc64360: sub             x1, x1, #0xf
    //     0xc64364: mov             x2, #0xd108
    //     0xc64368: movk            x2, #3, lsl #16
    //     0xc6436c: stur            x2, [x1, #-1]
    // 0xc64370: StoreField: r1->field_7 = d0
    //     0xc64370: stur            d0, [x1, #7]
    // 0xc64374: StoreField: r0->field_1b = r1
    //     0xc64374: stur            w1, [x0, #0x1b]
    // 0xc64378: r16 = <String, dynamic>
    //     0xc64378: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6437c: stp             x0, x16, [SP, #-0x10]!
    // 0xc64380: r0 = Map._fromLiteral()
    //     0xc64380: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64384: add             SP, SP, #0x10
    // 0xc64388: r16 = <double>
    //     0xc64388: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc6438c: r30 = Instance_MethodChannel
    //     0xc6438c: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc64390: ldr             lr, [lr, #0x360]
    // 0xc64394: stp             lr, x16, [SP, #-0x10]!
    // 0xc64398: r16 = "setExposureOffset"
    //     0xc64398: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cc8] "setExposureOffset"
    //     0xc6439c: ldr             x16, [x16, #0xcc8]
    // 0xc643a0: stp             x0, x16, [SP, #-0x10]!
    // 0xc643a4: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc643a4: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc643a8: r0 = invokeMethod()
    //     0xc643a8: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc643ac: add             SP, SP, #0x20
    // 0xc643b0: mov             x1, x0
    // 0xc643b4: stur            x1, [fp, #-0x10]
    // 0xc643b8: r0 = Await()
    //     0xc643b8: bl              #0x4b8e6c  ; AwaitStub
    // 0xc643bc: cmp             w0, NULL
    // 0xc643c0: b.eq            #0xc643ec
    // 0xc643c4: r0 = ReturnAsync()
    //     0xc643c4: b               #0x501858  ; ReturnAsyncStub
    // 0xc643c8: r0 = StackOverflowSharedWithFPURegs()
    //     0xc643c8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0xc643cc: b               #0xc64314
    // 0xc643d0: SaveReg d0
    //     0xc643d0: str             q0, [SP, #-0x10]!
    // 0xc643d4: SaveReg r0
    //     0xc643d4: str             x0, [SP, #-8]!
    // 0xc643d8: r0 = AllocateDouble()
    //     0xc643d8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc643dc: mov             x1, x0
    // 0xc643e0: RestoreReg r0
    //     0xc643e0: ldr             x0, [SP], #8
    // 0xc643e4: RestoreReg d0
    //     0xc643e4: ldr             q0, [SP], #0x10
    // 0xc643e8: b               #0xc64370
    // 0xc643ec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc643ec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getExposureOffsetStepSize(/* No info */) async {
    // ** addr: 0xc64680, size: 0xc8
    // 0xc64680: EnterFrame
    //     0xc64680: stp             fp, lr, [SP, #-0x10]!
    //     0xc64684: mov             fp, SP
    // 0xc64688: AllocStack(0x18)
    //     0xc64688: sub             SP, SP, #0x18
    // 0xc6468c: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc6468c: stur            NULL, [fp, #-8]
    //     0xc64690: mov             x0, #0
    //     0xc64694: add             x1, fp, w0, sxtw #2
    //     0xc64698: ldr             x1, [x1, #0x10]
    //     0xc6469c: stur            x1, [fp, #-0x10]
    // 0xc646a0: CheckStackOverflow
    //     0xc646a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc646a4: cmp             SP, x16
    //     0xc646a8: b.ls            #0xc6473c
    // 0xc646ac: InitAsync() -> Future<double>
    //     0xc646ac: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc646b0: bl              #0x4b92e4
    // 0xc646b4: r1 = Null
    //     0xc646b4: mov             x1, NULL
    // 0xc646b8: r2 = 4
    //     0xc646b8: mov             x2, #4
    // 0xc646bc: r0 = AllocateArray()
    //     0xc646bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc646c0: mov             x2, x0
    // 0xc646c4: r17 = "cameraId"
    //     0xc646c4: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc646c8: ldr             x17, [x17, #0x890]
    // 0xc646cc: StoreField: r2->field_f = r17
    //     0xc646cc: stur            w17, [x2, #0xf]
    // 0xc646d0: ldur            x3, [fp, #-0x10]
    // 0xc646d4: r0 = BoxInt64Instr(r3)
    //     0xc646d4: sbfiz           x0, x3, #1, #0x1f
    //     0xc646d8: cmp             x3, x0, asr #1
    //     0xc646dc: b.eq            #0xc646e8
    //     0xc646e0: bl              #0xd69bb8
    //     0xc646e4: stur            x3, [x0, #7]
    // 0xc646e8: StoreField: r2->field_13 = r0
    //     0xc646e8: stur            w0, [x2, #0x13]
    // 0xc646ec: r16 = <String, dynamic>
    //     0xc646ec: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc646f0: stp             x2, x16, [SP, #-0x10]!
    // 0xc646f4: r0 = Map._fromLiteral()
    //     0xc646f4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc646f8: add             SP, SP, #0x10
    // 0xc646fc: r16 = <double>
    //     0xc646fc: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64700: r30 = Instance_MethodChannel
    //     0xc64700: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc64704: ldr             lr, [lr, #0x360]
    // 0xc64708: stp             lr, x16, [SP, #-0x10]!
    // 0xc6470c: r16 = "getExposureOffsetStepSize"
    //     0xc6470c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d358] "getExposureOffsetStepSize"
    //     0xc64710: ldr             x16, [x16, #0x358]
    // 0xc64714: stp             x0, x16, [SP, #-0x10]!
    // 0xc64718: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64718: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6471c: r0 = invokeMethod()
    //     0xc6471c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64720: add             SP, SP, #0x20
    // 0xc64724: mov             x1, x0
    // 0xc64728: stur            x1, [fp, #-0x18]
    // 0xc6472c: r0 = Await()
    //     0xc6472c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc64730: cmp             w0, NULL
    // 0xc64734: b.eq            #0xc64744
    // 0xc64738: r0 = ReturnAsync()
    //     0xc64738: b               #0x501858  ; ReturnAsyncStub
    // 0xc6473c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6473c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64740: b               #0xc646ac
    // 0xc64744: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc64744: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMaxExposureOffset(/* No info */) async {
    // ** addr: 0xc64ce4, size: 0xc8
    // 0xc64ce4: EnterFrame
    //     0xc64ce4: stp             fp, lr, [SP, #-0x10]!
    //     0xc64ce8: mov             fp, SP
    // 0xc64cec: AllocStack(0x18)
    //     0xc64cec: sub             SP, SP, #0x18
    // 0xc64cf0: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc64cf0: stur            NULL, [fp, #-8]
    //     0xc64cf4: mov             x0, #0
    //     0xc64cf8: add             x1, fp, w0, sxtw #2
    //     0xc64cfc: ldr             x1, [x1, #0x10]
    //     0xc64d00: stur            x1, [fp, #-0x10]
    // 0xc64d04: CheckStackOverflow
    //     0xc64d04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc64d08: cmp             SP, x16
    //     0xc64d0c: b.ls            #0xc64da0
    // 0xc64d10: InitAsync() -> Future<double>
    //     0xc64d10: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc64d14: bl              #0x4b92e4
    // 0xc64d18: r1 = Null
    //     0xc64d18: mov             x1, NULL
    // 0xc64d1c: r2 = 4
    //     0xc64d1c: mov             x2, #4
    // 0xc64d20: r0 = AllocateArray()
    //     0xc64d20: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc64d24: mov             x2, x0
    // 0xc64d28: r17 = "cameraId"
    //     0xc64d28: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc64d2c: ldr             x17, [x17, #0x890]
    // 0xc64d30: StoreField: r2->field_f = r17
    //     0xc64d30: stur            w17, [x2, #0xf]
    // 0xc64d34: ldur            x3, [fp, #-0x10]
    // 0xc64d38: r0 = BoxInt64Instr(r3)
    //     0xc64d38: sbfiz           x0, x3, #1, #0x1f
    //     0xc64d3c: cmp             x3, x0, asr #1
    //     0xc64d40: b.eq            #0xc64d4c
    //     0xc64d44: bl              #0xd69bb8
    //     0xc64d48: stur            x3, [x0, #7]
    // 0xc64d4c: StoreField: r2->field_13 = r0
    //     0xc64d4c: stur            w0, [x2, #0x13]
    // 0xc64d50: r16 = <String, dynamic>
    //     0xc64d50: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc64d54: stp             x2, x16, [SP, #-0x10]!
    // 0xc64d58: r0 = Map._fromLiteral()
    //     0xc64d58: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc64d5c: add             SP, SP, #0x10
    // 0xc64d60: r16 = <double>
    //     0xc64d60: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc64d64: r30 = Instance_MethodChannel
    //     0xc64d64: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc64d68: ldr             lr, [lr, #0x360]
    // 0xc64d6c: stp             lr, x16, [SP, #-0x10]!
    // 0xc64d70: r16 = "getMaxExposureOffset"
    //     0xc64d70: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d350] "getMaxExposureOffset"
    //     0xc64d74: ldr             x16, [x16, #0x350]
    // 0xc64d78: stp             x0, x16, [SP, #-0x10]!
    // 0xc64d7c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc64d7c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc64d80: r0 = invokeMethod()
    //     0xc64d80: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc64d84: add             SP, SP, #0x20
    // 0xc64d88: mov             x1, x0
    // 0xc64d8c: stur            x1, [fp, #-0x18]
    // 0xc64d90: r0 = Await()
    //     0xc64d90: bl              #0x4b8e6c  ; AwaitStub
    // 0xc64d94: cmp             w0, NULL
    // 0xc64d98: b.eq            #0xc64da8
    // 0xc64d9c: r0 = ReturnAsync()
    //     0xc64d9c: b               #0x501858  ; ReturnAsyncStub
    // 0xc64da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc64da0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc64da4: b               #0xc64d10
    // 0xc64da8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc64da8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ getMinExposureOffset(/* No info */) async {
    // ** addr: 0xc654b4, size: 0xc8
    // 0xc654b4: EnterFrame
    //     0xc654b4: stp             fp, lr, [SP, #-0x10]!
    //     0xc654b8: mov             fp, SP
    // 0xc654bc: AllocStack(0x18)
    //     0xc654bc: sub             SP, SP, #0x18
    // 0xc654c0: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc654c0: stur            NULL, [fp, #-8]
    //     0xc654c4: mov             x0, #0
    //     0xc654c8: add             x1, fp, w0, sxtw #2
    //     0xc654cc: ldr             x1, [x1, #0x10]
    //     0xc654d0: stur            x1, [fp, #-0x10]
    // 0xc654d4: CheckStackOverflow
    //     0xc654d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc654d8: cmp             SP, x16
    //     0xc654dc: b.ls            #0xc65570
    // 0xc654e0: InitAsync() -> Future<double>
    //     0xc654e0: ldr             x0, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    //     0xc654e4: bl              #0x4b92e4
    // 0xc654e8: r1 = Null
    //     0xc654e8: mov             x1, NULL
    // 0xc654ec: r2 = 4
    //     0xc654ec: mov             x2, #4
    // 0xc654f0: r0 = AllocateArray()
    //     0xc654f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc654f4: mov             x2, x0
    // 0xc654f8: r17 = "cameraId"
    //     0xc654f8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc654fc: ldr             x17, [x17, #0x890]
    // 0xc65500: StoreField: r2->field_f = r17
    //     0xc65500: stur            w17, [x2, #0xf]
    // 0xc65504: ldur            x3, [fp, #-0x10]
    // 0xc65508: r0 = BoxInt64Instr(r3)
    //     0xc65508: sbfiz           x0, x3, #1, #0x1f
    //     0xc6550c: cmp             x3, x0, asr #1
    //     0xc65510: b.eq            #0xc6551c
    //     0xc65514: bl              #0xd69bb8
    //     0xc65518: stur            x3, [x0, #7]
    // 0xc6551c: StoreField: r2->field_13 = r0
    //     0xc6551c: stur            w0, [x2, #0x13]
    // 0xc65520: r16 = <String, dynamic>
    //     0xc65520: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc65524: stp             x2, x16, [SP, #-0x10]!
    // 0xc65528: r0 = Map._fromLiteral()
    //     0xc65528: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6552c: add             SP, SP, #0x10
    // 0xc65530: r16 = <double>
    //     0xc65530: ldr             x16, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0xc65534: r30 = Instance_MethodChannel
    //     0xc65534: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc65538: ldr             lr, [lr, #0x360]
    // 0xc6553c: stp             lr, x16, [SP, #-0x10]!
    // 0xc65540: r16 = "getMinExposureOffset"
    //     0xc65540: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d348] "getMinExposureOffset"
    //     0xc65544: ldr             x16, [x16, #0x348]
    // 0xc65548: stp             x0, x16, [SP, #-0x10]!
    // 0xc6554c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6554c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc65550: r0 = invokeMethod()
    //     0xc65550: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc65554: add             SP, SP, #0x20
    // 0xc65558: mov             x1, x0
    // 0xc6555c: stur            x1, [fp, #-0x18]
    // 0xc65560: r0 = Await()
    //     0xc65560: bl              #0x4b8e6c  ; AwaitStub
    // 0xc65564: cmp             w0, NULL
    // 0xc65568: b.eq            #0xc65578
    // 0xc6556c: r0 = ReturnAsync()
    //     0xc6556c: b               #0x501858  ; ReturnAsyncStub
    // 0xc65570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc65570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc65574: b               #0xc654e0
    // 0xc65578: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc65578: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setExposurePoint(/* No info */) {
    // ** addr: 0xc6587c, size: 0x180
    // 0xc6587c: EnterFrame
    //     0xc6587c: stp             fp, lr, [SP, #-0x10]!
    //     0xc65880: mov             fp, SP
    // 0xc65884: CheckStackOverflow
    //     0xc65884: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc65888: cmp             SP, x16
    //     0xc6588c: b.ls            #0xc659c0
    // 0xc65890: r1 = Null
    //     0xc65890: mov             x1, NULL
    // 0xc65894: r2 = 16
    //     0xc65894: mov             x2, #0x10
    // 0xc65898: r0 = AllocateArray()
    //     0xc65898: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6589c: mov             x2, x0
    // 0xc658a0: r17 = "cameraId"
    //     0xc658a0: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc658a4: ldr             x17, [x17, #0x890]
    // 0xc658a8: StoreField: r2->field_f = r17
    //     0xc658a8: stur            w17, [x2, #0xf]
    // 0xc658ac: ldr             x3, [fp, #0x18]
    // 0xc658b0: r0 = BoxInt64Instr(r3)
    //     0xc658b0: sbfiz           x0, x3, #1, #0x1f
    //     0xc658b4: cmp             x3, x0, asr #1
    //     0xc658b8: b.eq            #0xc658c4
    //     0xc658bc: bl              #0xd69bb8
    //     0xc658c0: stur            x3, [x0, #7]
    // 0xc658c4: StoreField: r2->field_13 = r0
    //     0xc658c4: stur            w0, [x2, #0x13]
    // 0xc658c8: r17 = "reset"
    //     0xc658c8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ae0] "reset"
    //     0xc658cc: ldr             x17, [x17, #0xae0]
    // 0xc658d0: StoreField: r2->field_17 = r17
    //     0xc658d0: stur            w17, [x2, #0x17]
    // 0xc658d4: ldr             x0, [fp, #0x10]
    // 0xc658d8: cmp             w0, NULL
    // 0xc658dc: r16 = true
    //     0xc658dc: add             x16, NULL, #0x20  ; true
    // 0xc658e0: r17 = false
    //     0xc658e0: add             x17, NULL, #0x30  ; false
    // 0xc658e4: csel            x1, x16, x17, eq
    // 0xc658e8: StoreField: r2->field_1b = r1
    //     0xc658e8: stur            w1, [x2, #0x1b]
    // 0xc658ec: r17 = "x"
    //     0xc658ec: ldr             x17, [PP, #0x71c8]  ; [pp+0x71c8] "x"
    // 0xc658f0: StoreField: r2->field_1f = r17
    //     0xc658f0: stur            w17, [x2, #0x1f]
    // 0xc658f4: cmp             w0, NULL
    // 0xc658f8: b.ne            #0xc65904
    // 0xc658fc: r1 = Null
    //     0xc658fc: mov             x1, NULL
    // 0xc65900: b               #0xc65930
    // 0xc65904: LoadField: d0 = r0->field_b
    //     0xc65904: ldur            d0, [x0, #0xb]
    // 0xc65908: r1 = inline_Allocate_Double()
    //     0xc65908: ldp             x1, x3, [THR, #0x60]  ; THR::top
    //     0xc6590c: add             x1, x1, #0x10
    //     0xc65910: cmp             x3, x1
    //     0xc65914: b.ls            #0xc659c8
    //     0xc65918: str             x1, [THR, #0x60]  ; THR::top
    //     0xc6591c: sub             x1, x1, #0xf
    //     0xc65920: mov             x3, #0xd108
    //     0xc65924: movk            x3, #3, lsl #16
    //     0xc65928: stur            x3, [x1, #-1]
    // 0xc6592c: StoreField: r1->field_7 = d0
    //     0xc6592c: stur            d0, [x1, #7]
    // 0xc65930: StoreField: r2->field_23 = r1
    //     0xc65930: stur            w1, [x2, #0x23]
    // 0xc65934: r17 = "y"
    //     0xc65934: ldr             x17, [PP, #0x78d0]  ; [pp+0x78d0] "y"
    // 0xc65938: StoreField: r2->field_27 = r17
    //     0xc65938: stur            w17, [x2, #0x27]
    // 0xc6593c: cmp             w0, NULL
    // 0xc65940: b.ne            #0xc6594c
    // 0xc65944: r0 = Null
    //     0xc65944: mov             x0, NULL
    // 0xc65948: b               #0xc65978
    // 0xc6594c: LoadField: d0 = r0->field_13
    //     0xc6594c: ldur            d0, [x0, #0x13]
    // 0xc65950: r0 = inline_Allocate_Double()
    //     0xc65950: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xc65954: add             x0, x0, #0x10
    //     0xc65958: cmp             x1, x0
    //     0xc6595c: b.ls            #0xc659e4
    //     0xc65960: str             x0, [THR, #0x60]  ; THR::top
    //     0xc65964: sub             x0, x0, #0xf
    //     0xc65968: mov             x1, #0xd108
    //     0xc6596c: movk            x1, #3, lsl #16
    //     0xc65970: stur            x1, [x0, #-1]
    // 0xc65974: StoreField: r0->field_7 = d0
    //     0xc65974: stur            d0, [x0, #7]
    // 0xc65978: StoreField: r2->field_2b = r0
    //     0xc65978: stur            w0, [x2, #0x2b]
    // 0xc6597c: r16 = <String, dynamic>
    //     0xc6597c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc65980: stp             x2, x16, [SP, #-0x10]!
    // 0xc65984: r0 = Map._fromLiteral()
    //     0xc65984: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc65988: add             SP, SP, #0x10
    // 0xc6598c: r16 = <void?>
    //     0xc6598c: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc65990: r30 = Instance_MethodChannel
    //     0xc65990: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc65994: ldr             lr, [lr, #0x360]
    // 0xc65998: stp             lr, x16, [SP, #-0x10]!
    // 0xc6599c: r16 = "setExposurePoint"
    //     0xc6599c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53af0] "setExposurePoint"
    //     0xc659a0: ldr             x16, [x16, #0xaf0]
    // 0xc659a4: stp             x0, x16, [SP, #-0x10]!
    // 0xc659a8: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc659a8: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc659ac: r0 = invokeMethod()
    //     0xc659ac: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc659b0: add             SP, SP, #0x20
    // 0xc659b4: LeaveFrame
    //     0xc659b4: mov             SP, fp
    //     0xc659b8: ldp             fp, lr, [SP], #0x10
    // 0xc659bc: ret
    //     0xc659bc: ret             
    // 0xc659c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc659c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc659c4: b               #0xc65890
    // 0xc659c8: SaveReg d0
    //     0xc659c8: str             q0, [SP, #-0x10]!
    // 0xc659cc: stp             x0, x2, [SP, #-0x10]!
    // 0xc659d0: r0 = AllocateDouble()
    //     0xc659d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc659d4: mov             x1, x0
    // 0xc659d8: ldp             x0, x2, [SP], #0x10
    // 0xc659dc: RestoreReg d0
    //     0xc659dc: ldr             q0, [SP], #0x10
    // 0xc659e0: b               #0xc6592c
    // 0xc659e4: SaveReg d0
    //     0xc659e4: str             q0, [SP, #-0x10]!
    // 0xc659e8: SaveReg r2
    //     0xc659e8: str             x2, [SP, #-8]!
    // 0xc659ec: r0 = AllocateDouble()
    //     0xc659ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc659f0: RestoreReg r2
    //     0xc659f0: ldr             x2, [SP], #8
    // 0xc659f4: RestoreReg d0
    //     0xc659f4: ldr             q0, [SP], #0x10
    // 0xc659f8: b               #0xc65974
  }
  _ stopVideoRecording(/* No info */) async {
    // ** addr: 0xc6a6ec, size: 0x1e0
    // 0xc6a6ec: EnterFrame
    //     0xc6a6ec: stp             fp, lr, [SP, #-0x10]!
    //     0xc6a6f0: mov             fp, SP
    // 0xc6a6f4: AllocStack(0x20)
    //     0xc6a6f4: sub             SP, SP, #0x20
    // 0xc6a6f8: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc6a6f8: stur            NULL, [fp, #-8]
    //     0xc6a6fc: mov             x0, #0
    //     0xc6a700: add             x1, fp, w0, sxtw #2
    //     0xc6a704: ldr             x1, [x1, #0x10]
    //     0xc6a708: stur            x1, [fp, #-0x10]
    // 0xc6a70c: CheckStackOverflow
    //     0xc6a70c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6a710: cmp             SP, x16
    //     0xc6a714: b.ls            #0xc6a8c4
    // 0xc6a718: InitAsync() -> Future<XFile>
    //     0xc6a718: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0xc6a71c: ldr             x0, [x0, #0x698]
    //     0xc6a720: bl              #0x4b92e4
    // 0xc6a724: r1 = Null
    //     0xc6a724: mov             x1, NULL
    // 0xc6a728: r2 = 4
    //     0xc6a728: mov             x2, #4
    // 0xc6a72c: r0 = AllocateArray()
    //     0xc6a72c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6a730: mov             x2, x0
    // 0xc6a734: r17 = "cameraId"
    //     0xc6a734: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6a738: ldr             x17, [x17, #0x890]
    // 0xc6a73c: StoreField: r2->field_f = r17
    //     0xc6a73c: stur            w17, [x2, #0xf]
    // 0xc6a740: ldur            x3, [fp, #-0x10]
    // 0xc6a744: r0 = BoxInt64Instr(r3)
    //     0xc6a744: sbfiz           x0, x3, #1, #0x1f
    //     0xc6a748: cmp             x3, x0, asr #1
    //     0xc6a74c: b.eq            #0xc6a758
    //     0xc6a750: bl              #0xd69bb8
    //     0xc6a754: stur            x3, [x0, #7]
    // 0xc6a758: StoreField: r2->field_13 = r0
    //     0xc6a758: stur            w0, [x2, #0x13]
    // 0xc6a75c: r16 = <String, dynamic>
    //     0xc6a75c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6a760: stp             x2, x16, [SP, #-0x10]!
    // 0xc6a764: r0 = Map._fromLiteral()
    //     0xc6a764: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6a768: add             SP, SP, #0x10
    // 0xc6a76c: r16 = <String>
    //     0xc6a76c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc6a770: r30 = Instance_MethodChannel
    //     0xc6a770: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc6a774: ldr             lr, [lr, #0x360]
    // 0xc6a778: stp             lr, x16, [SP, #-0x10]!
    // 0xc6a77c: r16 = "stopVideoRecording"
    //     0xc6a77c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d6a0] "stopVideoRecording"
    //     0xc6a780: ldr             x16, [x16, #0x6a0]
    // 0xc6a784: stp             x0, x16, [SP, #-0x10]!
    // 0xc6a788: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6a788: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6a78c: r0 = invokeMethod()
    //     0xc6a78c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6a790: add             SP, SP, #0x20
    // 0xc6a794: mov             x1, x0
    // 0xc6a798: stur            x1, [fp, #-0x18]
    // 0xc6a79c: r0 = Await()
    //     0xc6a79c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6a7a0: stur            x0, [fp, #-0x20]
    // 0xc6a7a4: cmp             w0, NULL
    // 0xc6a7a8: b.eq            #0xc6a834
    // 0xc6a7ac: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc6a7ac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc6a7b0: ldr             x0, [x0, #0xb58]
    //     0xc6a7b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc6a7b8: cmp             w0, w16
    //     0xc6a7bc: b.ne            #0xc6a7c8
    //     0xc6a7c0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc6a7c4: bl              #0xd67d44
    // 0xc6a7c8: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc6a7c8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc6a7cc: ldr             x0, [x0, #0xdd8]
    //     0xc6a7d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc6a7d4: cmp             w0, w16
    //     0xc6a7d8: b.ne            #0xc6a7e4
    //     0xc6a7dc: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc6a7e0: bl              #0xd67cdc
    // 0xc6a7e4: r0 = _File()
    //     0xc6a7e4: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc6a7e8: mov             x1, x0
    // 0xc6a7ec: ldur            x0, [fp, #-0x20]
    // 0xc6a7f0: stur            x1, [fp, #-0x18]
    // 0xc6a7f4: StoreField: r1->field_7 = r0
    //     0xc6a7f4: stur            w0, [x1, #7]
    // 0xc6a7f8: SaveReg r0
    //     0xc6a7f8: str             x0, [SP, #-8]!
    // 0xc6a7fc: r0 = _toUtf8Array()
    //     0xc6a7fc: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc6a800: add             SP, SP, #8
    // 0xc6a804: ldur            x1, [fp, #-0x18]
    // 0xc6a808: StoreField: r1->field_b = r0
    //     0xc6a808: stur            w0, [x1, #0xb]
    //     0xc6a80c: ldurb           w16, [x1, #-1]
    //     0xc6a810: ldurb           w17, [x0, #-1]
    //     0xc6a814: and             x16, x17, x16, lsr #2
    //     0xc6a818: tst             x16, HEAP, lsr #32
    //     0xc6a81c: b.eq            #0xc6a824
    //     0xc6a820: bl              #0xd6826c
    // 0xc6a824: r0 = XFile()
    //     0xc6a824: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc6a828: ldur            x1, [fp, #-0x18]
    // 0xc6a82c: StoreField: r0->field_7 = r1
    //     0xc6a82c: stur            w1, [x0, #7]
    // 0xc6a830: r0 = ReturnAsyncNotFuture()
    //     0xc6a830: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6a834: r1 = Null
    //     0xc6a834: mov             x1, NULL
    // 0xc6a838: r2 = 6
    //     0xc6a838: mov             x2, #6
    // 0xc6a83c: r0 = AllocateArray()
    //     0xc6a83c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6a840: stur            x0, [fp, #-0x18]
    // 0xc6a844: r17 = "The platform \""
    //     0xc6a844: add             x17, PP, #0x53, lsl #12  ; [pp+0x53af8] "The platform \""
    //     0xc6a848: ldr             x17, [x17, #0xaf8]
    // 0xc6a84c: StoreField: r0->field_f = r17
    //     0xc6a84c: stur            w17, [x0, #0xf]
    // 0xc6a850: r0 = defaultTargetPlatform()
    //     0xc6a850: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc6a854: ldur            x1, [fp, #-0x18]
    // 0xc6a858: ArrayStore: r1[1] = r0  ; List_4
    //     0xc6a858: add             x25, x1, #0x13
    //     0xc6a85c: str             w0, [x25]
    //     0xc6a860: tbz             w0, #0, #0xc6a87c
    //     0xc6a864: ldurb           w16, [x1, #-1]
    //     0xc6a868: ldurb           w17, [x0, #-1]
    //     0xc6a86c: and             x16, x17, x16, lsr #2
    //     0xc6a870: tst             x16, HEAP, lsr #32
    //     0xc6a874: b.eq            #0xc6a87c
    //     0xc6a878: bl              #0xd67e5c
    // 0xc6a87c: ldur            x0, [fp, #-0x18]
    // 0xc6a880: r17 = "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc6a880: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b00] "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc6a884: ldr             x17, [x17, #0xb00]
    // 0xc6a888: StoreField: r0->field_17 = r17
    //     0xc6a888: stur            w17, [x0, #0x17]
    // 0xc6a88c: SaveReg r0
    //     0xc6a88c: str             x0, [SP, #-8]!
    // 0xc6a890: r0 = _interpolate()
    //     0xc6a890: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc6a894: add             SP, SP, #8
    // 0xc6a898: stur            x0, [fp, #-0x18]
    // 0xc6a89c: r0 = CameraException()
    //     0xc6a89c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc6a8a0: mov             x1, x0
    // 0xc6a8a4: r0 = "INVALID_PATH"
    //     0xc6a8a4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53b08] "INVALID_PATH"
    //     0xc6a8a8: ldr             x0, [x0, #0xb08]
    // 0xc6a8ac: StoreField: r1->field_7 = r0
    //     0xc6a8ac: stur            w0, [x1, #7]
    // 0xc6a8b0: ldur            x0, [fp, #-0x18]
    // 0xc6a8b4: StoreField: r1->field_b = r0
    //     0xc6a8b4: stur            w0, [x1, #0xb]
    // 0xc6a8b8: mov             x0, x1
    // 0xc6a8bc: r0 = Throw()
    //     0xc6a8bc: bl              #0xd67e38  ; ThrowStub
    // 0xc6a8c0: brk             #0
    // 0xc6a8c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6a8c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6a8c8: b               #0xc6a718
  }
  _ startVideoCapturing(/* No info */) async {
    // ** addr: 0xc6c358, size: 0x168
    // 0xc6c358: EnterFrame
    //     0xc6c358: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c35c: mov             fp, SP
    // 0xc6c360: AllocStack(0x28)
    //     0xc6c360: sub             SP, SP, #0x28
    // 0xc6c364: SetupParameters(MethodChannelCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc6c364: stur            NULL, [fp, #-8]
    //     0xc6c368: mov             x0, #0
    //     0xc6c36c: add             x1, fp, w0, sxtw #2
    //     0xc6c370: ldr             x1, [x1, #0x18]
    //     0xc6c374: stur            x1, [fp, #-0x18]
    //     0xc6c378: add             x2, fp, w0, sxtw #2
    //     0xc6c37c: ldr             x2, [x2, #0x10]
    //     0xc6c380: stur            x2, [fp, #-0x10]
    // 0xc6c384: CheckStackOverflow
    //     0xc6c384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c388: cmp             SP, x16
    //     0xc6c38c: b.ls            #0xc6c4b8
    // 0xc6c390: InitAsync() -> Future<void?>
    //     0xc6c390: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc6c394: bl              #0x4b92e4
    // 0xc6c398: r1 = Null
    //     0xc6c398: mov             x1, NULL
    // 0xc6c39c: r2 = 12
    //     0xc6c39c: mov             x2, #0xc
    // 0xc6c3a0: r0 = AllocateArray()
    //     0xc6c3a0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc6c3a4: mov             x2, x0
    // 0xc6c3a8: r17 = "cameraId"
    //     0xc6c3a8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6c3ac: ldr             x17, [x17, #0x890]
    // 0xc6c3b0: StoreField: r2->field_f = r17
    //     0xc6c3b0: stur            w17, [x2, #0xf]
    // 0xc6c3b4: ldur            x3, [fp, #-0x10]
    // 0xc6c3b8: LoadField: r4 = r3->field_7
    //     0xc6c3b8: ldur            x4, [x3, #7]
    // 0xc6c3bc: r0 = BoxInt64Instr(r4)
    //     0xc6c3bc: sbfiz           x0, x4, #1, #0x1f
    //     0xc6c3c0: cmp             x4, x0, asr #1
    //     0xc6c3c4: b.eq            #0xc6c3d0
    //     0xc6c3c8: bl              #0xd69bb8
    //     0xc6c3cc: stur            x4, [x0, #7]
    // 0xc6c3d0: StoreField: r2->field_13 = r0
    //     0xc6c3d0: stur            w0, [x2, #0x13]
    // 0xc6c3d4: r17 = "maxVideoDuration"
    //     0xc6c3d4: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc6c3d8: ldr             x17, [x17, #0xb10]
    // 0xc6c3dc: StoreField: r2->field_17 = r17
    //     0xc6c3dc: stur            w17, [x2, #0x17]
    // 0xc6c3e0: StoreField: r2->field_1b = rNULL
    //     0xc6c3e0: stur            NULL, [x2, #0x1b]
    // 0xc6c3e4: r17 = "enableStream"
    //     0xc6c3e4: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b18] "enableStream"
    //     0xc6c3e8: ldr             x17, [x17, #0xb18]
    // 0xc6c3ec: StoreField: r2->field_1f = r17
    //     0xc6c3ec: stur            w17, [x2, #0x1f]
    // 0xc6c3f0: LoadField: r0 = r3->field_13
    //     0xc6c3f0: ldur            w0, [x3, #0x13]
    // 0xc6c3f4: DecompressPointer r0
    //     0xc6c3f4: add             x0, x0, HEAP, lsl #32
    // 0xc6c3f8: stur            x0, [fp, #-0x20]
    // 0xc6c3fc: cmp             w0, NULL
    // 0xc6c400: r16 = true
    //     0xc6c400: add             x16, NULL, #0x20  ; true
    // 0xc6c404: r17 = false
    //     0xc6c404: add             x17, NULL, #0x30  ; false
    // 0xc6c408: csel            x1, x16, x17, ne
    // 0xc6c40c: StoreField: r2->field_23 = r1
    //     0xc6c40c: stur            w1, [x2, #0x23]
    // 0xc6c410: r16 = <String, dynamic>
    //     0xc6c410: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc6c414: stp             x2, x16, [SP, #-0x10]!
    // 0xc6c418: r0 = Map._fromLiteral()
    //     0xc6c418: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc6c41c: add             SP, SP, #0x10
    // 0xc6c420: r16 = <void?>
    //     0xc6c420: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6c424: r30 = Instance_MethodChannel
    //     0xc6c424: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc6c428: ldr             lr, [lr, #0x360]
    // 0xc6c42c: stp             lr, x16, [SP, #-0x10]!
    // 0xc6c430: r16 = "startVideoRecording"
    //     0xc6c430: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d730] "startVideoRecording"
    //     0xc6c434: ldr             x16, [x16, #0x730]
    // 0xc6c438: stp             x0, x16, [SP, #-0x10]!
    // 0xc6c43c: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc6c43c: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc6c440: r0 = invokeMethod()
    //     0xc6c440: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6c444: add             SP, SP, #0x20
    // 0xc6c448: mov             x1, x0
    // 0xc6c44c: stur            x1, [fp, #-0x28]
    // 0xc6c450: r0 = Await()
    //     0xc6c450: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6c454: ldur            x0, [fp, #-0x20]
    // 0xc6c458: cmp             w0, NULL
    // 0xc6c45c: b.eq            #0xc6c4b0
    // 0xc6c460: ldur            x16, [fp, #-0x18]
    // 0xc6c464: SaveReg r16
    //     0xc6c464: str             x16, [SP, #-8]!
    // 0xc6c468: r0 = _installStreamController()
    //     0xc6c468: bl              #0xc6ce48  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_installStreamController
    // 0xc6c46c: add             SP, SP, #8
    // 0xc6c470: stur            x0, [fp, #-0x10]
    // 0xc6c474: LoadField: r1 = r0->field_7
    //     0xc6c474: ldur            w1, [x0, #7]
    // 0xc6c478: DecompressPointer r1
    //     0xc6c478: add             x1, x1, HEAP, lsl #32
    // 0xc6c47c: r0 = _ControllerStream()
    //     0xc6c47c: bl              #0x534e34  ; Allocate_ControllerStreamStub -> _ControllerStream<X0> (size=0x14)
    // 0xc6c480: mov             x1, x0
    // 0xc6c484: ldur            x0, [fp, #-0x10]
    // 0xc6c488: StoreField: r1->field_f = r0
    //     0xc6c488: stur            w0, [x1, #0xf]
    // 0xc6c48c: ldur            x16, [fp, #-0x20]
    // 0xc6c490: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c494: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc6c494: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc6c498: r0 = listen()
    //     0xc6c498: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc6c49c: add             SP, SP, #0x10
    // 0xc6c4a0: ldur            x16, [fp, #-0x18]
    // 0xc6c4a4: SaveReg r16
    //     0xc6c4a4: str             x16, [SP, #-8]!
    // 0xc6c4a8: r0 = _startStreamListener()
    //     0xc6c4a8: bl              #0xc6c4c0  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_startStreamListener
    // 0xc6c4ac: add             SP, SP, #8
    // 0xc6c4b0: r0 = Null
    //     0xc6c4b0: mov             x0, NULL
    // 0xc6c4b4: r0 = ReturnAsyncNotFuture()
    //     0xc6c4b4: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6c4b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c4b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c4bc: b               #0xc6c390
  }
  _ _startStreamListener(/* No info */) {
    // ** addr: 0xc6c4c0, size: 0xa8
    // 0xc6c4c0: EnterFrame
    //     0xc6c4c0: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c4c4: mov             fp, SP
    // 0xc6c4c8: AllocStack(0x8)
    //     0xc6c4c8: sub             SP, SP, #8
    // 0xc6c4cc: CheckStackOverflow
    //     0xc6c4cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c4d0: cmp             SP, x16
    //     0xc6c4d4: b.ls            #0xc6c560
    // 0xc6c4d8: r1 = 1
    //     0xc6c4d8: mov             x1, #1
    // 0xc6c4dc: r0 = AllocateContext()
    //     0xc6c4dc: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6c4e0: mov             x1, x0
    // 0xc6c4e4: ldr             x0, [fp, #0x10]
    // 0xc6c4e8: stur            x1, [fp, #-8]
    // 0xc6c4ec: StoreField: r1->field_f = r0
    //     0xc6c4ec: stur            w0, [x1, #0xf]
    // 0xc6c4f0: r16 = Instance_EventChannel
    //     0xc6c4f0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b20] Obj!EventChannel@b34ad1
    //     0xc6c4f4: ldr             x16, [x16, #0xb20]
    // 0xc6c4f8: SaveReg r16
    //     0xc6c4f8: str             x16, [SP, #-8]!
    // 0xc6c4fc: r0 = receiveBroadcastStream()
    //     0xc6c4fc: bl              #0x5a24c0  ; [package:flutter/src/services/platform_channel.dart] EventChannel::receiveBroadcastStream
    // 0xc6c500: add             SP, SP, #8
    // 0xc6c504: ldur            x2, [fp, #-8]
    // 0xc6c508: r1 = Function '<anonymous closure>':.
    //     0xc6c508: add             x1, PP, #0x53, lsl #12  ; [pp+0x53b28] AnonymousClosure: (0xc6c568), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_startStreamListener (0xc6c4c0)
    //     0xc6c50c: ldr             x1, [x1, #0xb28]
    // 0xc6c510: stur            x0, [fp, #-8]
    // 0xc6c514: r0 = AllocateClosure()
    //     0xc6c514: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6c518: ldur            x16, [fp, #-8]
    // 0xc6c51c: stp             x0, x16, [SP, #-0x10]!
    // 0xc6c520: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc6c520: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc6c524: r0 = listen()
    //     0xc6c524: bl              #0xc5694c  ; [dart:async] _StreamImpl::listen
    // 0xc6c528: add             SP, SP, #0x10
    // 0xc6c52c: ldr             x1, [fp, #0x10]
    // 0xc6c530: StoreField: r1->field_13 = r0
    //     0xc6c530: stur            w0, [x1, #0x13]
    //     0xc6c534: tbz             w0, #0, #0xc6c550
    //     0xc6c538: ldurb           w16, [x1, #-1]
    //     0xc6c53c: ldurb           w17, [x0, #-1]
    //     0xc6c540: and             x16, x17, x16, lsr #2
    //     0xc6c544: tst             x16, HEAP, lsr #32
    //     0xc6c548: b.eq            #0xc6c550
    //     0xc6c54c: bl              #0xd6826c
    // 0xc6c550: r0 = Null
    //     0xc6c550: mov             x0, NULL
    // 0xc6c554: LeaveFrame
    //     0xc6c554: mov             SP, fp
    //     0xc6c558: ldp             fp, lr, [SP], #0x10
    // 0xc6c55c: ret
    //     0xc6c55c: ret             
    // 0xc6c560: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c560: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c564: b               #0xc6c4d8
  }
  [closure] void <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xc6c568, size: 0x13c
    // 0xc6c568: EnterFrame
    //     0xc6c568: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c56c: mov             fp, SP
    // 0xc6c570: AllocStack(0x40)
    //     0xc6c570: sub             SP, SP, #0x40
    // 0xc6c574: SetupParameters()
    //     0xc6c574: ldr             x0, [fp, #0x18]
    //     0xc6c578: ldur            w1, [x0, #0x17]
    //     0xc6c57c: add             x1, x1, HEAP, lsl #32
    //     0xc6c580: stur            x1, [fp, #-0x38]
    // 0xc6c584: CheckStackOverflow
    //     0xc6c584: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c588: cmp             SP, x16
    //     0xc6c58c: b.ls            #0xc6c698
    // 0xc6c590: r0 = defaultTargetPlatform()
    //     0xc6c590: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc6c594: r16 = Instance_TargetPlatform
    //     0xc6c594: ldr             x16, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0xc6c598: cmp             w0, w16
    // 0xc6c59c: b.ne            #0xc6c5c8
    // 0xc6c5a0: r16 = <void?>
    //     0xc6c5a0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6c5a4: r30 = Instance_MethodChannel
    //     0xc6c5a4: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc6c5a8: ldr             lr, [lr, #0x360]
    // 0xc6c5ac: stp             lr, x16, [SP, #-0x10]!
    // 0xc6c5b0: r16 = "receivedImageStreamData"
    //     0xc6c5b0: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b30] "receivedImageStreamData"
    //     0xc6c5b4: ldr             x16, [x16, #0xb30]
    // 0xc6c5b8: SaveReg r16
    //     0xc6c5b8: str             x16, [SP, #-8]!
    // 0xc6c5bc: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6c5bc: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6c5c0: r0 = invokeMethod()
    //     0xc6c5c0: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6c5c4: add             SP, SP, #0x18
    // 0xc6c5c8: ldur            x0, [fp, #-0x38]
    // 0xc6c5cc: LoadField: r1 = r0->field_f
    //     0xc6c5cc: ldur            w1, [x0, #0xf]
    // 0xc6c5d0: DecompressPointer r1
    //     0xc6c5d0: add             x1, x1, HEAP, lsl #32
    // 0xc6c5d4: LoadField: r3 = r1->field_17
    //     0xc6c5d4: ldur            w3, [x1, #0x17]
    // 0xc6c5d8: DecompressPointer r3
    //     0xc6c5d8: add             x3, x3, HEAP, lsl #32
    // 0xc6c5dc: stur            x3, [fp, #-0x38]
    // 0xc6c5e0: cmp             w3, NULL
    // 0xc6c5e4: b.eq            #0xc6c6a0
    // 0xc6c5e8: ldr             x0, [fp, #0x10]
    // 0xc6c5ec: r2 = Null
    //     0xc6c5ec: mov             x2, NULL
    // 0xc6c5f0: r1 = Null
    //     0xc6c5f0: mov             x1, NULL
    // 0xc6c5f4: r8 = Map
    //     0xc6c5f4: ldr             x8, [PP, #0x2338]  ; [pp+0x2338] Type: Map
    // 0xc6c5f8: r3 = Null
    //     0xc6c5f8: add             x3, PP, #0x53, lsl #12  ; [pp+0x53b38] Null
    //     0xc6c5fc: ldr             x3, [x3, #0xb38]
    // 0xc6c600: r0 = Map()
    //     0xc6c600: bl              #0xd747e8  ; IsType_Map_Stub
    // 0xc6c604: ldr             x16, [fp, #0x10]
    // 0xc6c608: SaveReg r16
    //     0xc6c608: str             x16, [SP, #-8]!
    // 0xc6c60c: r0 = cameraImageFromPlatformData()
    //     0xc6c60c: bl              #0xc6c6a4  ; [package:camera_platform_interface/src/method_channel/type_conversion.dart] ::cameraImageFromPlatformData
    // 0xc6c610: add             SP, SP, #8
    // 0xc6c614: ldur            x16, [fp, #-0x38]
    // 0xc6c618: stp             x0, x16, [SP, #-0x10]!
    // 0xc6c61c: r0 = add()
    //     0xc6c61c: bl              #0xc23290  ; [dart:async] _StreamController::add
    // 0xc6c620: add             SP, SP, #0x10
    // 0xc6c624: r0 = Null
    //     0xc6c624: mov             x0, NULL
    // 0xc6c628: LeaveFrame
    //     0xc6c628: mov             SP, fp
    //     0xc6c62c: ldp             fp, lr, [SP], #0x10
    // 0xc6c630: ret
    //     0xc6c630: ret             
    // 0xc6c634: sub             SP, fp, #0x40
    // 0xc6c638: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6c638: mov             x2, #0x76
    //     0xc6c63c: tbz             w0, #0, #0xc6c64c
    //     0xc6c640: ldur            x2, [x0, #-1]
    //     0xc6c644: ubfx            x2, x2, #0xc, #0x14
    //     0xc6c648: lsl             x2, x2, #1
    // 0xc6c64c: cmp             w2, #0xf28
    // 0xc6c650: b.ne            #0xc6c690
    // 0xc6c654: LoadField: r1 = r0->field_7
    //     0xc6c654: ldur            w1, [x0, #7]
    // 0xc6c658: DecompressPointer r1
    //     0xc6c658: add             x1, x1, HEAP, lsl #32
    // 0xc6c65c: stur            x1, [fp, #-0x40]
    // 0xc6c660: LoadField: r2 = r0->field_b
    //     0xc6c660: ldur            w2, [x0, #0xb]
    // 0xc6c664: DecompressPointer r2
    //     0xc6c664: add             x2, x2, HEAP, lsl #32
    // 0xc6c668: stur            x2, [fp, #-0x38]
    // 0xc6c66c: r0 = CameraException()
    //     0xc6c66c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc6c670: mov             x1, x0
    // 0xc6c674: ldur            x0, [fp, #-0x40]
    // 0xc6c678: StoreField: r1->field_7 = r0
    //     0xc6c678: stur            w0, [x1, #7]
    // 0xc6c67c: ldur            x0, [fp, #-0x38]
    // 0xc6c680: StoreField: r1->field_b = r0
    //     0xc6c680: stur            w0, [x1, #0xb]
    // 0xc6c684: mov             x0, x1
    // 0xc6c688: r0 = Throw()
    //     0xc6c688: bl              #0xd67e38  ; ThrowStub
    // 0xc6c68c: brk             #0
    // 0xc6c690: r0 = ReThrow()
    //     0xc6c690: bl              #0xd67e14  ; ReThrowStub
    // 0xc6c694: brk             #0
    // 0xc6c698: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6c698: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6c69c: b               #0xc6c590
    // 0xc6c6a0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6c6a0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _installStreamController(/* No info */) {
    // ** addr: 0xc6ce48, size: 0x128
    // 0xc6ce48: EnterFrame
    //     0xc6ce48: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ce4c: mov             fp, SP
    // 0xc6ce50: AllocStack(0x18)
    //     0xc6ce50: sub             SP, SP, #0x18
    // 0xc6ce54: CheckStackOverflow
    //     0xc6ce54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ce58: cmp             SP, x16
    //     0xc6ce5c: b.ls            #0xc6cf64
    // 0xc6ce60: r1 = 1
    //     0xc6ce60: mov             x1, #1
    // 0xc6ce64: r0 = AllocateContext()
    //     0xc6ce64: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6ce68: mov             x1, x0
    // 0xc6ce6c: ldr             x0, [fp, #0x10]
    // 0xc6ce70: stur            x1, [fp, #-8]
    // 0xc6ce74: StoreField: r1->field_f = r0
    //     0xc6ce74: stur            w0, [x1, #0xf]
    // 0xc6ce78: r1 = 1
    //     0xc6ce78: mov             x1, #1
    // 0xc6ce7c: r0 = AllocateContext()
    //     0xc6ce7c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6ce80: mov             x1, x0
    // 0xc6ce84: ldr             x0, [fp, #0x10]
    // 0xc6ce88: stur            x1, [fp, #-0x10]
    // 0xc6ce8c: StoreField: r1->field_f = r0
    //     0xc6ce8c: stur            w0, [x1, #0xf]
    // 0xc6ce90: r1 = 1
    //     0xc6ce90: mov             x1, #1
    // 0xc6ce94: r0 = AllocateContext()
    //     0xc6ce94: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc6ce98: mov             x3, x0
    // 0xc6ce9c: ldr             x0, [fp, #0x10]
    // 0xc6cea0: stur            x3, [fp, #-0x18]
    // 0xc6cea4: StoreField: r3->field_f = r0
    //     0xc6cea4: stur            w0, [x3, #0xf]
    // 0xc6cea8: r1 = Function '<anonymous closure>':.
    //     0xc6cea8: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c68] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0xc6ceac: ldr             x1, [x1, #0xc68]
    // 0xc6ceb0: r2 = Null
    //     0xc6ceb0: mov             x2, NULL
    // 0xc6ceb4: r0 = AllocateClosure()
    //     0xc6ceb4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6ceb8: ldur            x2, [fp, #-8]
    // 0xc6cebc: r1 = Function '_onFrameStreamPauseResume@185124294':.
    //     0xc6cebc: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c70] AnonymousClosure: (0xc6d08c), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume (0xc6b6a0)
    //     0xc6cec0: ldr             x1, [x1, #0xc70]
    // 0xc6cec4: stur            x0, [fp, #-8]
    // 0xc6cec8: r0 = AllocateClosure()
    //     0xc6cec8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6cecc: ldur            x2, [fp, #-0x10]
    // 0xc6ced0: r1 = Function '_onFrameStreamPauseResume@185124294':.
    //     0xc6ced0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c70] AnonymousClosure: (0xc6d08c), in [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume (0xc6b6a0)
    //     0xc6ced4: ldr             x1, [x1, #0xc70]
    // 0xc6ced8: stur            x0, [fp, #-0x10]
    // 0xc6cedc: r0 = AllocateClosure()
    //     0xc6cedc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6cee0: ldur            x2, [fp, #-0x18]
    // 0xc6cee4: r1 = Function '_onFrameStreamCancel@185124294':.
    //     0xc6cee4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53c78] AnonymousClosure: (0xc6cf70), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_onFrameStreamCancel (0xc6cfb8)
    //     0xc6cee8: ldr             x1, [x1, #0xc78]
    // 0xc6ceec: stur            x0, [fp, #-0x18]
    // 0xc6cef0: r0 = AllocateClosure()
    //     0xc6cef0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6cef4: r16 = <CameraImageData>
    //     0xc6cef4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c80] TypeArguments: <CameraImageData>
    //     0xc6cef8: ldr             x16, [x16, #0xc80]
    // 0xc6cefc: ldur            lr, [fp, #-8]
    // 0xc6cf00: stp             lr, x16, [SP, #-0x10]!
    // 0xc6cf04: ldur            x16, [fp, #-0x10]
    // 0xc6cf08: ldur            lr, [fp, #-0x18]
    // 0xc6cf0c: stp             lr, x16, [SP, #-0x10]!
    // 0xc6cf10: SaveReg r0
    //     0xc6cf10: str             x0, [SP, #-8]!
    // 0xc6cf14: r4 = const [0, 0x5, 0x5, 0x1, onCancel, 0x4, onListen, 0x1, onPause, 0x2, onResume, 0x3, null]
    //     0xc6cf14: add             x4, PP, #0x53, lsl #12  ; [pp+0x53c88] List(13) [0, 0x5, 0x5, 0x1, "onCancel", 0x4, "onListen", 0x1, "onPause", 0x2, "onResume", 0x3, Null]
    //     0xc6cf18: ldr             x4, [x4, #0xc88]
    // 0xc6cf1c: r0 = StreamController()
    //     0xc6cf1c: bl              #0x534f54  ; [dart:async] StreamController::StreamController
    // 0xc6cf20: add             SP, SP, #0x28
    // 0xc6cf24: mov             x2, x0
    // 0xc6cf28: ldr             x1, [fp, #0x10]
    // 0xc6cf2c: StoreField: r1->field_17 = r0
    //     0xc6cf2c: stur            w0, [x1, #0x17]
    //     0xc6cf30: tbz             w0, #0, #0xc6cf4c
    //     0xc6cf34: ldurb           w16, [x1, #-1]
    //     0xc6cf38: ldurb           w17, [x0, #-1]
    //     0xc6cf3c: and             x16, x17, x16, lsr #2
    //     0xc6cf40: tst             x16, HEAP, lsr #32
    //     0xc6cf44: b.eq            #0xc6cf4c
    //     0xc6cf48: bl              #0xd6826c
    // 0xc6cf4c: cmp             w2, NULL
    // 0xc6cf50: b.eq            #0xc6cf6c
    // 0xc6cf54: mov             x0, x2
    // 0xc6cf58: LeaveFrame
    //     0xc6cf58: mov             SP, fp
    //     0xc6cf5c: ldp             fp, lr, [SP], #0x10
    // 0xc6cf60: ret
    //     0xc6cf60: ret             
    // 0xc6cf64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6cf64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6cf68: b               #0xc6ce60
    // 0xc6cf6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc6cf6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _onFrameStreamCancel(dynamic) {
    // ** addr: 0xc6cf70, size: 0x48
    // 0xc6cf70: EnterFrame
    //     0xc6cf70: stp             fp, lr, [SP, #-0x10]!
    //     0xc6cf74: mov             fp, SP
    // 0xc6cf78: ldr             x0, [fp, #0x10]
    // 0xc6cf7c: LoadField: r1 = r0->field_17
    //     0xc6cf7c: ldur            w1, [x0, #0x17]
    // 0xc6cf80: DecompressPointer r1
    //     0xc6cf80: add             x1, x1, HEAP, lsl #32
    // 0xc6cf84: CheckStackOverflow
    //     0xc6cf84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6cf88: cmp             SP, x16
    //     0xc6cf8c: b.ls            #0xc6cfb0
    // 0xc6cf90: LoadField: r0 = r1->field_f
    //     0xc6cf90: ldur            w0, [x1, #0xf]
    // 0xc6cf94: DecompressPointer r0
    //     0xc6cf94: add             x0, x0, HEAP, lsl #32
    // 0xc6cf98: SaveReg r0
    //     0xc6cf98: str             x0, [SP, #-8]!
    // 0xc6cf9c: r0 = _onFrameStreamCancel()
    //     0xc6cf9c: bl              #0xc6cfb8  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_onFrameStreamCancel
    // 0xc6cfa0: add             SP, SP, #8
    // 0xc6cfa4: LeaveFrame
    //     0xc6cfa4: mov             SP, fp
    //     0xc6cfa8: ldp             fp, lr, [SP], #0x10
    // 0xc6cfac: ret
    //     0xc6cfac: ret             
    // 0xc6cfb0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6cfb0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6cfb4: b               #0xc6cf90
  }
  _ _onFrameStreamCancel(/* No info */) async {
    // ** addr: 0xc6cfb8, size: 0xd4
    // 0xc6cfb8: EnterFrame
    //     0xc6cfb8: stp             fp, lr, [SP, #-0x10]!
    //     0xc6cfbc: mov             fp, SP
    // 0xc6cfc0: AllocStack(0x18)
    //     0xc6cfc0: sub             SP, SP, #0x18
    // 0xc6cfc4: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc6cfc4: stur            NULL, [fp, #-8]
    //     0xc6cfc8: mov             x0, #0
    //     0xc6cfcc: add             x1, fp, w0, sxtw #2
    //     0xc6cfd0: ldr             x1, [x1, #0x10]
    //     0xc6cfd4: stur            x1, [fp, #-0x10]
    // 0xc6cfd8: CheckStackOverflow
    //     0xc6cfd8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6cfdc: cmp             SP, x16
    //     0xc6cfe0: b.ls            #0xc6d084
    // 0xc6cfe4: InitAsync() -> Future
    //     0xc6cfe4: mov             x0, NULL
    //     0xc6cfe8: bl              #0x4b92e4
    // 0xc6cfec: r16 = <void?>
    //     0xc6cfec: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc6cff0: r30 = Instance_MethodChannel
    //     0xc6cff0: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc6cff4: ldr             lr, [lr, #0x360]
    // 0xc6cff8: stp             lr, x16, [SP, #-0x10]!
    // 0xc6cffc: r16 = "stopImageStream"
    //     0xc6cffc: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d6c0] "stopImageStream"
    //     0xc6d000: ldr             x16, [x16, #0x6c0]
    // 0xc6d004: SaveReg r16
    //     0xc6d004: str             x16, [SP, #-8]!
    // 0xc6d008: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6d008: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6d00c: r0 = invokeMethod()
    //     0xc6d00c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc6d010: add             SP, SP, #0x18
    // 0xc6d014: mov             x1, x0
    // 0xc6d018: stur            x1, [fp, #-0x18]
    // 0xc6d01c: r0 = Await()
    //     0xc6d01c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6d020: ldur            x1, [fp, #-0x10]
    // 0xc6d024: LoadField: r0 = r1->field_13
    //     0xc6d024: ldur            w0, [x1, #0x13]
    // 0xc6d028: DecompressPointer r0
    //     0xc6d028: add             x0, x0, HEAP, lsl #32
    // 0xc6d02c: cmp             w0, NULL
    // 0xc6d030: b.ne            #0xc6d03c
    // 0xc6d034: r2 = Null
    //     0xc6d034: mov             x2, NULL
    // 0xc6d038: b               #0xc6d064
    // 0xc6d03c: r2 = LoadClassIdInstr(r0)
    //     0xc6d03c: ldur            x2, [x0, #-1]
    //     0xc6d040: ubfx            x2, x2, #0xc, #0x14
    // 0xc6d044: SaveReg r0
    //     0xc6d044: str             x0, [SP, #-8]!
    // 0xc6d048: mov             x0, x2
    // 0xc6d04c: r0 = GDT[cid_x0 + 0x307]()
    //     0xc6d04c: add             lr, x0, #0x307
    //     0xc6d050: ldr             lr, [x21, lr, lsl #3]
    //     0xc6d054: blr             lr
    // 0xc6d058: add             SP, SP, #8
    // 0xc6d05c: mov             x2, x0
    // 0xc6d060: ldur            x1, [fp, #-0x10]
    // 0xc6d064: mov             x0, x2
    // 0xc6d068: stur            x2, [fp, #-0x18]
    // 0xc6d06c: r0 = Await()
    //     0xc6d06c: bl              #0x4b8e6c  ; AwaitStub
    // 0xc6d070: ldur            x1, [fp, #-0x10]
    // 0xc6d074: StoreField: r1->field_13 = rNULL
    //     0xc6d074: stur            NULL, [x1, #0x13]
    // 0xc6d078: StoreField: r1->field_17 = rNULL
    //     0xc6d078: stur            NULL, [x1, #0x17]
    // 0xc6d07c: r0 = Null
    //     0xc6d07c: mov             x0, NULL
    // 0xc6d080: r0 = ReturnAsyncNotFuture()
    //     0xc6d080: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc6d084: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6d084: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6d088: b               #0xc6cfe4
  }
  [closure] void _onFrameStreamPauseResume(dynamic) {
    // ** addr: 0xc6d08c, size: 0x48
    // 0xc6d08c: EnterFrame
    //     0xc6d08c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6d090: mov             fp, SP
    // 0xc6d094: ldr             x0, [fp, #0x10]
    // 0xc6d098: LoadField: r1 = r0->field_17
    //     0xc6d098: ldur            w1, [x0, #0x17]
    // 0xc6d09c: DecompressPointer r1
    //     0xc6d09c: add             x1, x1, HEAP, lsl #32
    // 0xc6d0a0: CheckStackOverflow
    //     0xc6d0a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6d0a4: cmp             SP, x16
    //     0xc6d0a8: b.ls            #0xc6d0cc
    // 0xc6d0ac: LoadField: r0 = r1->field_f
    //     0xc6d0ac: ldur            w0, [x1, #0xf]
    // 0xc6d0b0: DecompressPointer r0
    //     0xc6d0b0: add             x0, x0, HEAP, lsl #32
    // 0xc6d0b4: SaveReg r0
    //     0xc6d0b4: str             x0, [SP, #-8]!
    // 0xc6d0b8: r0 = _onFrameStreamPauseResume()
    //     0xc6d0b8: bl              #0xc6b6a0  ; [package:camera_android/src/android_camera.dart] AndroidCamera::_onFrameStreamPauseResume
    // 0xc6d0bc: add             SP, SP, #8
    // 0xc6d0c0: LeaveFrame
    //     0xc6d0c0: mov             SP, fp
    //     0xc6d0c4: ldp             fp, lr, [SP], #0x10
    // 0xc6d0c8: ret
    //     0xc6d0c8: ret             
    // 0xc6d0cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6d0cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6d0d0: b               #0xc6d0ac
  }
  _ takePicture(/* No info */) async {
    // ** addr: 0xc730fc, size: 0x1e0
    // 0xc730fc: EnterFrame
    //     0xc730fc: stp             fp, lr, [SP, #-0x10]!
    //     0xc73100: mov             fp, SP
    // 0xc73104: AllocStack(0x20)
    //     0xc73104: sub             SP, SP, #0x20
    // 0xc73108: SetupParameters(MethodChannelCamera this /* r1, fp-0x10 */)
    //     0xc73108: stur            NULL, [fp, #-8]
    //     0xc7310c: mov             x0, #0
    //     0xc73110: add             x1, fp, w0, sxtw #2
    //     0xc73114: ldr             x1, [x1, #0x10]
    //     0xc73118: stur            x1, [fp, #-0x10]
    // 0xc7311c: CheckStackOverflow
    //     0xc7311c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc73120: cmp             SP, x16
    //     0xc73124: b.ls            #0xc732d4
    // 0xc73128: InitAsync() -> Future<XFile>
    //     0xc73128: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d698] TypeArguments: <XFile>
    //     0xc7312c: ldr             x0, [x0, #0x698]
    //     0xc73130: bl              #0x4b92e4
    // 0xc73134: r1 = Null
    //     0xc73134: mov             x1, NULL
    // 0xc73138: r2 = 4
    //     0xc73138: mov             x2, #4
    // 0xc7313c: r0 = AllocateArray()
    //     0xc7313c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc73140: mov             x2, x0
    // 0xc73144: r17 = "cameraId"
    //     0xc73144: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc73148: ldr             x17, [x17, #0x890]
    // 0xc7314c: StoreField: r2->field_f = r17
    //     0xc7314c: stur            w17, [x2, #0xf]
    // 0xc73150: ldur            x3, [fp, #-0x10]
    // 0xc73154: r0 = BoxInt64Instr(r3)
    //     0xc73154: sbfiz           x0, x3, #1, #0x1f
    //     0xc73158: cmp             x3, x0, asr #1
    //     0xc7315c: b.eq            #0xc73168
    //     0xc73160: bl              #0xd69bb8
    //     0xc73164: stur            x3, [x0, #7]
    // 0xc73168: StoreField: r2->field_13 = r0
    //     0xc73168: stur            w0, [x2, #0x13]
    // 0xc7316c: r16 = <String, dynamic>
    //     0xc7316c: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc73170: stp             x2, x16, [SP, #-0x10]!
    // 0xc73174: r0 = Map._fromLiteral()
    //     0xc73174: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc73178: add             SP, SP, #0x10
    // 0xc7317c: r16 = <String>
    //     0xc7317c: ldr             x16, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0xc73180: r30 = Instance_MethodChannel
    //     0xc73180: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc73184: ldr             lr, [lr, #0x360]
    // 0xc73188: stp             lr, x16, [SP, #-0x10]!
    // 0xc7318c: r16 = "takePicture"
    //     0xc7318c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d788] "takePicture"
    //     0xc73190: ldr             x16, [x16, #0x788]
    // 0xc73194: stp             x0, x16, [SP, #-0x10]!
    // 0xc73198: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc73198: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc7319c: r0 = invokeMethod()
    //     0xc7319c: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc731a0: add             SP, SP, #0x20
    // 0xc731a4: mov             x1, x0
    // 0xc731a8: stur            x1, [fp, #-0x18]
    // 0xc731ac: r0 = Await()
    //     0xc731ac: bl              #0x4b8e6c  ; AwaitStub
    // 0xc731b0: stur            x0, [fp, #-0x20]
    // 0xc731b4: cmp             w0, NULL
    // 0xc731b8: b.eq            #0xc73244
    // 0xc731bc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc731bc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc731c0: ldr             x0, [x0, #0xb58]
    //     0xc731c4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc731c8: cmp             w0, w16
    //     0xc731cc: b.ne            #0xc731d8
    //     0xc731d0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc731d4: bl              #0xd67d44
    // 0xc731d8: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc731d8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc731dc: ldr             x0, [x0, #0xdd8]
    //     0xc731e0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc731e4: cmp             w0, w16
    //     0xc731e8: b.ne            #0xc731f4
    //     0xc731ec: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc731f0: bl              #0xd67cdc
    // 0xc731f4: r0 = _File()
    //     0xc731f4: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc731f8: mov             x1, x0
    // 0xc731fc: ldur            x0, [fp, #-0x20]
    // 0xc73200: stur            x1, [fp, #-0x18]
    // 0xc73204: StoreField: r1->field_7 = r0
    //     0xc73204: stur            w0, [x1, #7]
    // 0xc73208: SaveReg r0
    //     0xc73208: str             x0, [SP, #-8]!
    // 0xc7320c: r0 = _toUtf8Array()
    //     0xc7320c: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc73210: add             SP, SP, #8
    // 0xc73214: ldur            x1, [fp, #-0x18]
    // 0xc73218: StoreField: r1->field_b = r0
    //     0xc73218: stur            w0, [x1, #0xb]
    //     0xc7321c: ldurb           w16, [x1, #-1]
    //     0xc73220: ldurb           w17, [x0, #-1]
    //     0xc73224: and             x16, x17, x16, lsr #2
    //     0xc73228: tst             x16, HEAP, lsr #32
    //     0xc7322c: b.eq            #0xc73234
    //     0xc73230: bl              #0xd6826c
    // 0xc73234: r0 = XFile()
    //     0xc73234: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc73238: ldur            x1, [fp, #-0x18]
    // 0xc7323c: StoreField: r0->field_7 = r1
    //     0xc7323c: stur            w1, [x0, #7]
    // 0xc73240: r0 = ReturnAsyncNotFuture()
    //     0xc73240: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc73244: r1 = Null
    //     0xc73244: mov             x1, NULL
    // 0xc73248: r2 = 6
    //     0xc73248: mov             x2, #6
    // 0xc7324c: r0 = AllocateArray()
    //     0xc7324c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc73250: stur            x0, [fp, #-0x18]
    // 0xc73254: r17 = "The platform \""
    //     0xc73254: add             x17, PP, #0x53, lsl #12  ; [pp+0x53af8] "The platform \""
    //     0xc73258: ldr             x17, [x17, #0xaf8]
    // 0xc7325c: StoreField: r0->field_f = r17
    //     0xc7325c: stur            w17, [x0, #0xf]
    // 0xc73260: r0 = defaultTargetPlatform()
    //     0xc73260: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc73264: ldur            x1, [fp, #-0x18]
    // 0xc73268: ArrayStore: r1[1] = r0  ; List_4
    //     0xc73268: add             x25, x1, #0x13
    //     0xc7326c: str             w0, [x25]
    //     0xc73270: tbz             w0, #0, #0xc7328c
    //     0xc73274: ldurb           w16, [x1, #-1]
    //     0xc73278: ldurb           w17, [x0, #-1]
    //     0xc7327c: and             x16, x17, x16, lsr #2
    //     0xc73280: tst             x16, HEAP, lsr #32
    //     0xc73284: b.eq            #0xc7328c
    //     0xc73288: bl              #0xd67e5c
    // 0xc7328c: ldur            x0, [fp, #-0x18]
    // 0xc73290: r17 = "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc73290: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b00] "\" did not return a path while reporting success. The platform should always return a valid path or report an error."
    //     0xc73294: ldr             x17, [x17, #0xb00]
    // 0xc73298: StoreField: r0->field_17 = r17
    //     0xc73298: stur            w17, [x0, #0x17]
    // 0xc7329c: SaveReg r0
    //     0xc7329c: str             x0, [SP, #-8]!
    // 0xc732a0: r0 = _interpolate()
    //     0xc732a0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc732a4: add             SP, SP, #8
    // 0xc732a8: stur            x0, [fp, #-0x18]
    // 0xc732ac: r0 = CameraException()
    //     0xc732ac: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc732b0: mov             x1, x0
    // 0xc732b4: r0 = "INVALID_PATH"
    //     0xc732b4: add             x0, PP, #0x53, lsl #12  ; [pp+0x53b08] "INVALID_PATH"
    //     0xc732b8: ldr             x0, [x0, #0xb08]
    // 0xc732bc: StoreField: r1->field_7 = r0
    //     0xc732bc: stur            w0, [x1, #7]
    // 0xc732c0: ldur            x0, [fp, #-0x18]
    // 0xc732c4: StoreField: r1->field_b = r0
    //     0xc732c4: stur            w0, [x1, #0xb]
    // 0xc732c8: mov             x0, x1
    // 0xc732cc: r0 = Throw()
    //     0xc732cc: bl              #0xd67e38  ; ThrowStub
    // 0xc732d0: brk             #0
    // 0xc732d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc732d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc732d8: b               #0xc73128
  }
  _ onCameraInitialized(/* No info */) {
    // ** addr: 0xc7595c, size: 0x58
    // 0xc7595c: EnterFrame
    //     0xc7595c: stp             fp, lr, [SP, #-0x10]!
    //     0xc75960: mov             fp, SP
    // 0xc75964: CheckStackOverflow
    //     0xc75964: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc75968: cmp             SP, x16
    //     0xc7596c: b.ls            #0xc759ac
    // 0xc75970: ldr             x16, [fp, #0x18]
    // 0xc75974: SaveReg r16
    //     0xc75974: str             x16, [SP, #-8]!
    // 0xc75978: ldr             x0, [fp, #0x10]
    // 0xc7597c: SaveReg r0
    //     0xc7597c: str             x0, [SP, #-8]!
    // 0xc75980: r0 = _cameraEvents()
    //     0xc75980: bl              #0x5aa890  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_cameraEvents
    // 0xc75984: add             SP, SP, #0x10
    // 0xc75988: r16 = <CameraEvent, CameraInitializedEvent>
    //     0xc75988: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d3a8] TypeArguments: <CameraEvent, CameraInitializedEvent>
    //     0xc7598c: ldr             x16, [x16, #0x3a8]
    // 0xc75990: stp             x0, x16, [SP, #-0x10]!
    // 0xc75994: r4 = const [0x2, 0x1, 0x1, 0x1, null]
    //     0xc75994: ldr             x4, [PP, #0xe90]  ; [pp+0xe90] List(5) [0x2, 0x1, 0x1, 0x1, Null]
    // 0xc75998: r0 = Where.whereType()
    //     0xc75998: bl              #0x5aa93c  ; [package:stream_transform/src/where.dart] ::Where.whereType
    // 0xc7599c: add             SP, SP, #0x10
    // 0xc759a0: LeaveFrame
    //     0xc759a0: mov             SP, fp
    //     0xc759a4: ldp             fp, lr, [SP], #0x10
    // 0xc759a8: ret
    //     0xc759a8: ret             
    // 0xc759ac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc759ac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc759b0: b               #0xc75970
  }
  _ dispose(/* No info */) async {
    // ** addr: 0xc765dc, size: 0x14c
    // 0xc765dc: EnterFrame
    //     0xc765dc: stp             fp, lr, [SP, #-0x10]!
    //     0xc765e0: mov             fp, SP
    // 0xc765e4: AllocStack(0x20)
    //     0xc765e4: sub             SP, SP, #0x20
    // 0xc765e8: SetupParameters(MethodChannelCamera this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0xc765e8: stur            NULL, [fp, #-8]
    //     0xc765ec: mov             x0, #0
    //     0xc765f0: add             x1, fp, w0, sxtw #2
    //     0xc765f4: ldr             x1, [x1, #0x18]
    //     0xc765f8: stur            x1, [fp, #-0x18]
    //     0xc765fc: add             x2, fp, w0, sxtw #2
    //     0xc76600: ldr             x2, [x2, #0x10]
    //     0xc76604: stur            x2, [fp, #-0x10]
    // 0xc76608: CheckStackOverflow
    //     0xc76608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7660c: cmp             SP, x16
    //     0xc76610: b.ls            #0xc76720
    // 0xc76614: InitAsync() -> Future<void?>
    //     0xc76614: ldr             x0, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    //     0xc76618: bl              #0x4b92e4
    // 0xc7661c: ldur            x0, [fp, #-0x18]
    // 0xc76620: LoadField: r2 = r0->field_7
    //     0xc76620: ldur            w2, [x0, #7]
    // 0xc76624: DecompressPointer r2
    //     0xc76624: add             x2, x2, HEAP, lsl #32
    // 0xc76628: ldur            x3, [fp, #-0x10]
    // 0xc7662c: stur            x2, [fp, #-0x20]
    // 0xc76630: r0 = BoxInt64Instr(r3)
    //     0xc76630: sbfiz           x0, x3, #1, #0x1f
    //     0xc76634: cmp             x3, x0, asr #1
    //     0xc76638: b.eq            #0xc76644
    //     0xc7663c: bl              #0xd69bb8
    //     0xc76640: stur            x3, [x0, #7]
    // 0xc76644: stur            x0, [fp, #-0x18]
    // 0xc76648: stp             x0, x2, [SP, #-0x10]!
    // 0xc7664c: r0 = containsKey()
    //     0xc7664c: bl              #0xca679c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::containsKey
    // 0xc76650: add             SP, SP, #0x10
    // 0xc76654: tbnz            w0, #4, #0xc766b0
    // 0xc76658: ldur            x0, [fp, #-0x20]
    // 0xc7665c: ldur            x16, [fp, #-0x18]
    // 0xc76660: stp             x16, x0, [SP, #-0x10]!
    // 0xc76664: r0 = _getValueOrData()
    //     0xc76664: bl              #0x4b9040  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::_getValueOrData
    // 0xc76668: add             SP, SP, #0x10
    // 0xc7666c: mov             x1, x0
    // 0xc76670: ldur            x0, [fp, #-0x20]
    // 0xc76674: LoadField: r2 = r0->field_f
    //     0xc76674: ldur            w2, [x0, #0xf]
    // 0xc76678: DecompressPointer r2
    //     0xc76678: add             x2, x2, HEAP, lsl #32
    // 0xc7667c: cmp             w2, w1
    // 0xc76680: b.ne            #0xc76688
    // 0xc76684: r1 = Null
    //     0xc76684: mov             x1, NULL
    // 0xc76688: cmp             w1, NULL
    // 0xc7668c: b.eq            #0xc7669c
    // 0xc76690: stp             NULL, x1, [SP, #-0x10]!
    // 0xc76694: r0 = setMethodCallHandler()
    //     0xc76694: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xc76698: add             SP, SP, #0x10
    // 0xc7669c: ldur            x16, [fp, #-0x20]
    // 0xc766a0: ldur            lr, [fp, #-0x18]
    // 0xc766a4: stp             lr, x16, [SP, #-0x10]!
    // 0xc766a8: r0 = remove()
    //     0xc766a8: bl              #0xca17c8  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::remove
    // 0xc766ac: add             SP, SP, #0x10
    // 0xc766b0: ldur            x0, [fp, #-0x18]
    // 0xc766b4: r1 = Null
    //     0xc766b4: mov             x1, NULL
    // 0xc766b8: r2 = 4
    //     0xc766b8: mov             x2, #4
    // 0xc766bc: r0 = AllocateArray()
    //     0xc766bc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc766c0: r17 = "cameraId"
    //     0xc766c0: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc766c4: ldr             x17, [x17, #0x890]
    // 0xc766c8: StoreField: r0->field_f = r17
    //     0xc766c8: stur            w17, [x0, #0xf]
    // 0xc766cc: ldur            x1, [fp, #-0x18]
    // 0xc766d0: StoreField: r0->field_13 = r1
    //     0xc766d0: stur            w1, [x0, #0x13]
    // 0xc766d4: r16 = <String, dynamic>
    //     0xc766d4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc766d8: stp             x0, x16, [SP, #-0x10]!
    // 0xc766dc: r0 = Map._fromLiteral()
    //     0xc766dc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc766e0: add             SP, SP, #0x10
    // 0xc766e4: r16 = <void?>
    //     0xc766e4: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc766e8: r30 = Instance_MethodChannel
    //     0xc766e8: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc766ec: ldr             lr, [lr, #0x360]
    // 0xc766f0: stp             lr, x16, [SP, #-0x10]!
    // 0xc766f4: r16 = "dispose"
    //     0xc766f4: add             x16, PP, #0x3f, lsl #12  ; [pp+0x3f010] "dispose"
    //     0xc766f8: ldr             x16, [x16, #0x10]
    // 0xc766fc: stp             x0, x16, [SP, #-0x10]!
    // 0xc76700: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0xc76700: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0xc76704: r0 = invokeMethod()
    //     0xc76704: bl              #0x5a1850  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMethod
    // 0xc76708: add             SP, SP, #0x20
    // 0xc7670c: mov             x1, x0
    // 0xc76710: stur            x1, [fp, #-0x18]
    // 0xc76714: r0 = Await()
    //     0xc76714: bl              #0x4b8e6c  ; AwaitStub
    // 0xc76718: r0 = Null
    //     0xc76718: mov             x0, NULL
    // 0xc7671c: r0 = ReturnAsyncNotFuture()
    //     0xc7671c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc76720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76720: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc76724: b               #0xc76614
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0xc76a40, size: 0xbc
    // 0xc76a40: EnterFrame
    //     0xc76a40: stp             fp, lr, [SP, #-0x10]!
    //     0xc76a44: mov             fp, SP
    // 0xc76a48: AllocStack(0x18)
    //     0xc76a48: sub             SP, SP, #0x18
    // 0xc76a4c: SetupParameters()
    //     0xc76a4c: ldr             x0, [fp, #0x20]
    //     0xc76a50: ldur            w1, [x0, #0x17]
    //     0xc76a54: add             x1, x1, HEAP, lsl #32
    // 0xc76a58: CheckStackOverflow
    //     0xc76a58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc76a5c: cmp             SP, x16
    //     0xc76a60: b.ls            #0xc76af4
    // 0xc76a64: ldr             x0, [fp, #0x18]
    // 0xc76a68: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc76a68: mov             x2, #0x76
    //     0xc76a6c: tbz             w0, #0, #0xc76a7c
    //     0xc76a70: ldur            x2, [x0, #-1]
    //     0xc76a74: ubfx            x2, x2, #0xc, #0x14
    //     0xc76a78: lsl             x2, x2, #1
    // 0xc76a7c: cmp             w2, #0xf28
    // 0xc76a80: b.ne            #0xc76aec
    // 0xc76a84: LoadField: r2 = r1->field_17
    //     0xc76a84: ldur            w2, [x1, #0x17]
    // 0xc76a88: DecompressPointer r2
    //     0xc76a88: add             x2, x2, HEAP, lsl #32
    // 0xc76a8c: stur            x2, [fp, #-0x18]
    // 0xc76a90: LoadField: r1 = r0->field_7
    //     0xc76a90: ldur            w1, [x0, #7]
    // 0xc76a94: DecompressPointer r1
    //     0xc76a94: add             x1, x1, HEAP, lsl #32
    // 0xc76a98: stur            x1, [fp, #-0x10]
    // 0xc76a9c: LoadField: r3 = r0->field_b
    //     0xc76a9c: ldur            w3, [x0, #0xb]
    // 0xc76aa0: DecompressPointer r3
    //     0xc76aa0: add             x3, x3, HEAP, lsl #32
    // 0xc76aa4: stur            x3, [fp, #-8]
    // 0xc76aa8: r0 = CameraException()
    //     0xc76aa8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc76aac: mov             x1, x0
    // 0xc76ab0: ldur            x0, [fp, #-0x10]
    // 0xc76ab4: StoreField: r1->field_7 = r0
    //     0xc76ab4: stur            w0, [x1, #7]
    // 0xc76ab8: ldur            x0, [fp, #-8]
    // 0xc76abc: StoreField: r1->field_b = r0
    //     0xc76abc: stur            w0, [x1, #0xb]
    // 0xc76ac0: ldur            x16, [fp, #-0x18]
    // 0xc76ac4: stp             x1, x16, [SP, #-0x10]!
    // 0xc76ac8: ldr             x16, [fp, #0x10]
    // 0xc76acc: SaveReg r16
    //     0xc76acc: str             x16, [SP, #-8]!
    // 0xc76ad0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xc76ad0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xc76ad4: r0 = completeError()
    //     0xc76ad4: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0xc76ad8: add             SP, SP, #0x18
    // 0xc76adc: r0 = Null
    //     0xc76adc: mov             x0, NULL
    // 0xc76ae0: LeaveFrame
    //     0xc76ae0: mov             SP, fp
    //     0xc76ae4: ldp             fp, lr, [SP], #0x10
    // 0xc76ae8: ret
    //     0xc76ae8: ret             
    // 0xc76aec: r0 = Throw()
    //     0xc76aec: bl              #0xd67e38  ; ThrowStub
    // 0xc76af0: brk             #0
    // 0xc76af4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc76af4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc76af8: b               #0xc76a64
  }
  _ initializeCamera(/* No info */) {
    // ** addr: 0xc78354, size: 0x20c
    // 0xc78354: EnterFrame
    //     0xc78354: stp             fp, lr, [SP, #-0x10]!
    //     0xc78358: mov             fp, SP
    // 0xc7835c: AllocStack(0x18)
    //     0xc7835c: sub             SP, SP, #0x18
    // 0xc78360: CheckStackOverflow
    //     0xc78360: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc78364: cmp             SP, x16
    //     0xc78368: b.ls            #0xc78558
    // 0xc7836c: r1 = 3
    //     0xc7836c: mov             x1, #3
    // 0xc78370: r0 = AllocateContext()
    //     0xc78370: bl              #0xd68aa4  ; AllocateContextStub
    // 0xc78374: mov             x4, x0
    // 0xc78378: ldr             x3, [fp, #0x20]
    // 0xc7837c: stur            x4, [fp, #-0x18]
    // 0xc78380: StoreField: r4->field_f = r3
    //     0xc78380: stur            w3, [x4, #0xf]
    // 0xc78384: ldr             x2, [fp, #0x18]
    // 0xc78388: r0 = BoxInt64Instr(r2)
    //     0xc78388: sbfiz           x0, x2, #1, #0x1f
    //     0xc7838c: cmp             x2, x0, asr #1
    //     0xc78390: b.eq            #0xc7839c
    //     0xc78394: bl              #0xd69bb8
    //     0xc78398: stur            x2, [x0, #7]
    // 0xc7839c: stur            x0, [fp, #-0x10]
    // 0xc783a0: StoreField: r4->field_13 = r0
    //     0xc783a0: stur            w0, [x4, #0x13]
    // 0xc783a4: LoadField: r5 = r3->field_7
    //     0xc783a4: ldur            w5, [x3, #7]
    // 0xc783a8: DecompressPointer r5
    //     0xc783a8: add             x5, x5, HEAP, lsl #32
    // 0xc783ac: mov             x2, x4
    // 0xc783b0: stur            x5, [fp, #-8]
    // 0xc783b4: r1 = Function '<anonymous closure>':.
    //     0xc783b4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53ca0] AnonymousClosure: (0xc78560), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::initializeCamera (0xc78354)
    //     0xc783b8: ldr             x1, [x1, #0xca0]
    // 0xc783bc: r0 = AllocateClosure()
    //     0xc783bc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc783c0: ldur            x16, [fp, #-8]
    // 0xc783c4: ldur            lr, [fp, #-0x10]
    // 0xc783c8: stp             lr, x16, [SP, #-0x10]!
    // 0xc783cc: SaveReg r0
    //     0xc783cc: str             x0, [SP, #-8]!
    // 0xc783d0: r0 = putIfAbsent()
    //     0xc783d0: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0xc783d4: add             SP, SP, #0x18
    // 0xc783d8: r1 = <void?>
    //     0xc783d8: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc783dc: r0 = _Future()
    //     0xc783dc: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0xc783e0: mov             x1, x0
    // 0xc783e4: r0 = 0
    //     0xc783e4: mov             x0, #0
    // 0xc783e8: stur            x1, [fp, #-8]
    // 0xc783ec: StoreField: r1->field_b = r0
    //     0xc783ec: stur            x0, [x1, #0xb]
    // 0xc783f0: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc783f0: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc783f4: ldr             x0, [x0, #0xb58]
    //     0xc783f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc783fc: cmp             w0, w16
    //     0xc78400: b.ne            #0xc7840c
    //     0xc78404: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc78408: bl              #0xd67d44
    // 0xc7840c: mov             x1, x0
    // 0xc78410: ldur            x0, [fp, #-8]
    // 0xc78414: StoreField: r0->field_13 = r1
    //     0xc78414: stur            w1, [x0, #0x13]
    // 0xc78418: r1 = <void?>
    //     0xc78418: ldr             x1, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0xc7841c: r0 = _AsyncCompleter()
    //     0xc7841c: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0xc78420: ldur            x1, [fp, #-8]
    // 0xc78424: StoreField: r0->field_b = r1
    //     0xc78424: stur            w1, [x0, #0xb]
    // 0xc78428: ldur            x2, [fp, #-0x18]
    // 0xc7842c: StoreField: r2->field_17 = r0
    //     0xc7842c: stur            w0, [x2, #0x17]
    //     0xc78430: ldurb           w16, [x2, #-1]
    //     0xc78434: ldurb           w17, [x0, #-1]
    //     0xc78438: and             x16, x17, x16, lsr #2
    //     0xc7843c: tst             x16, HEAP, lsr #32
    //     0xc78440: b.eq            #0xc78448
    //     0xc78444: bl              #0xd6828c
    // 0xc78448: LoadField: r0 = r2->field_13
    //     0xc78448: ldur            w0, [x2, #0x13]
    // 0xc7844c: DecompressPointer r0
    //     0xc7844c: add             x0, x0, HEAP, lsl #32
    // 0xc78450: r3 = LoadInt32Instr(r0)
    //     0xc78450: sbfx            x3, x0, #1, #0x1f
    //     0xc78454: tbz             w0, #0, #0xc7845c
    //     0xc78458: ldur            x3, [x0, #7]
    // 0xc7845c: ldr             x16, [fp, #0x20]
    // 0xc78460: stp             x3, x16, [SP, #-0x10]!
    // 0xc78464: r0 = onCameraInitialized()
    //     0xc78464: bl              #0xc7595c  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::onCameraInitialized
    // 0xc78468: add             SP, SP, #0x10
    // 0xc7846c: SaveReg r0
    //     0xc7846c: str             x0, [SP, #-8]!
    // 0xc78470: r0 = first()
    //     0xc78470: bl              #0x5aa0d4  ; [dart:async] Stream::first
    // 0xc78474: add             SP, SP, #8
    // 0xc78478: ldur            x2, [fp, #-0x18]
    // 0xc7847c: r1 = Function '<anonymous closure>':.
    //     0xc7847c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53ca8] AnonymousClosure: (0x9ec1e4), in [package:flutter3_frame/modules/chat/chat_user_logic.dart] ChatUserLogic::getUserFromServer (0x9ebfe8)
    //     0xc78480: ldr             x1, [x1, #0xca8]
    // 0xc78484: stur            x0, [fp, #-0x10]
    // 0xc78488: r0 = AllocateClosure()
    //     0xc78488: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7848c: r16 = <Null?>
    //     0xc7848c: ldr             x16, [PP, #0x348]  ; [pp+0x348] TypeArguments: <Null?>
    // 0xc78490: ldur            lr, [fp, #-0x10]
    // 0xc78494: stp             lr, x16, [SP, #-0x10]!
    // 0xc78498: SaveReg r0
    //     0xc78498: str             x0, [SP, #-8]!
    // 0xc7849c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7849c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc784a0: r0 = then()
    //     0xc784a0: bl              #0xca6124  ; [dart:async] _Future::then
    // 0xc784a4: add             SP, SP, #0x18
    // 0xc784a8: r1 = Null
    //     0xc784a8: mov             x1, NULL
    // 0xc784ac: r2 = 8
    //     0xc784ac: mov             x2, #8
    // 0xc784b0: r0 = AllocateArray()
    //     0xc784b0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc784b4: r17 = "cameraId"
    //     0xc784b4: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc784b8: ldr             x17, [x17, #0x890]
    // 0xc784bc: StoreField: r0->field_f = r17
    //     0xc784bc: stur            w17, [x0, #0xf]
    // 0xc784c0: ldur            x2, [fp, #-0x18]
    // 0xc784c4: LoadField: r1 = r2->field_13
    //     0xc784c4: ldur            w1, [x2, #0x13]
    // 0xc784c8: DecompressPointer r1
    //     0xc784c8: add             x1, x1, HEAP, lsl #32
    // 0xc784cc: StoreField: r0->field_13 = r1
    //     0xc784cc: stur            w1, [x0, #0x13]
    // 0xc784d0: r17 = "imageFormatGroup"
    //     0xc784d0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53cb0] "imageFormatGroup"
    //     0xc784d4: ldr             x17, [x17, #0xcb0]
    // 0xc784d8: StoreField: r0->field_17 = r17
    //     0xc784d8: stur            w17, [x0, #0x17]
    // 0xc784dc: r17 = "unknown"
    //     0xc784dc: add             x17, PP, #0x14, lsl #12  ; [pp+0x14af8] "unknown"
    //     0xc784e0: ldr             x17, [x17, #0xaf8]
    // 0xc784e4: StoreField: r0->field_1b = r17
    //     0xc784e4: stur            w17, [x0, #0x1b]
    // 0xc784e8: r16 = <String, dynamic>
    //     0xc784e8: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc784ec: stp             x0, x16, [SP, #-0x10]!
    // 0xc784f0: r0 = Map._fromLiteral()
    //     0xc784f0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc784f4: add             SP, SP, #0x10
    // 0xc784f8: r16 = <String, dynamic>
    //     0xc784f8: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc784fc: r30 = Instance_MethodChannel
    //     0xc784fc: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc78500: ldr             lr, [lr, #0x360]
    // 0xc78504: stp             lr, x16, [SP, #-0x10]!
    // 0xc78508: r16 = "initialize"
    //     0xc78508: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cb8] "initialize"
    //     0xc7850c: ldr             x16, [x16, #0xcb8]
    // 0xc78510: stp             x0, x16, [SP, #-0x10]!
    // 0xc78514: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0xc78514: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0xc78518: r0 = invokeMapMethod()
    //     0xc78518: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xc7851c: add             SP, SP, #0x20
    // 0xc78520: ldur            x2, [fp, #-0x18]
    // 0xc78524: r1 = Function '<anonymous closure>':.
    //     0xc78524: add             x1, PP, #0x53, lsl #12  ; [pp+0x53cc0] AnonymousClosure: (0xc76a40), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::initializeCamera (0xc78354)
    //     0xc78528: ldr             x1, [x1, #0xcc0]
    // 0xc7852c: stur            x0, [fp, #-0x10]
    // 0xc78530: r0 = AllocateClosure()
    //     0xc78530: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc78534: ldur            x16, [fp, #-0x10]
    // 0xc78538: stp             x0, x16, [SP, #-0x10]!
    // 0xc7853c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xc7853c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xc78540: r0 = catchError()
    //     0xc78540: bl              #0xca5bb8  ; [dart:async] _Future::catchError
    // 0xc78544: add             SP, SP, #0x10
    // 0xc78548: ldur            x0, [fp, #-8]
    // 0xc7854c: LeaveFrame
    //     0xc7854c: mov             SP, fp
    //     0xc78550: ldp             fp, lr, [SP], #0x10
    // 0xc78554: ret
    //     0xc78554: ret             
    // 0xc78558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc78558: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7855c: b               #0xc7836c
  }
  [closure] MethodChannel <anonymous closure>(dynamic) {
    // ** addr: 0xc78560, size: 0xb8
    // 0xc78560: EnterFrame
    //     0xc78560: stp             fp, lr, [SP, #-0x10]!
    //     0xc78564: mov             fp, SP
    // 0xc78568: AllocStack(0x18)
    //     0xc78568: sub             SP, SP, #0x18
    // 0xc7856c: SetupParameters()
    //     0xc7856c: ldr             x0, [fp, #0x10]
    //     0xc78570: ldur            w3, [x0, #0x17]
    //     0xc78574: add             x3, x3, HEAP, lsl #32
    //     0xc78578: stur            x3, [fp, #-8]
    // 0xc7857c: CheckStackOverflow
    //     0xc7857c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc78580: cmp             SP, x16
    //     0xc78584: b.ls            #0xc78610
    // 0xc78588: r1 = Null
    //     0xc78588: mov             x1, NULL
    // 0xc7858c: r2 = 4
    //     0xc7858c: mov             x2, #4
    // 0xc78590: r0 = AllocateArray()
    //     0xc78590: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc78594: r17 = "flutter.io/cameraPlugin/camera"
    //     0xc78594: add             x17, PP, #0x53, lsl #12  ; [pp+0x53cc8] "flutter.io/cameraPlugin/camera"
    //     0xc78598: ldr             x17, [x17, #0xcc8]
    // 0xc7859c: StoreField: r0->field_f = r17
    //     0xc7859c: stur            w17, [x0, #0xf]
    // 0xc785a0: ldur            x2, [fp, #-8]
    // 0xc785a4: LoadField: r1 = r2->field_13
    //     0xc785a4: ldur            w1, [x2, #0x13]
    // 0xc785a8: DecompressPointer r1
    //     0xc785a8: add             x1, x1, HEAP, lsl #32
    // 0xc785ac: StoreField: r0->field_13 = r1
    //     0xc785ac: stur            w1, [x0, #0x13]
    // 0xc785b0: SaveReg r0
    //     0xc785b0: str             x0, [SP, #-8]!
    // 0xc785b4: r0 = _interpolate()
    //     0xc785b4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc785b8: add             SP, SP, #8
    // 0xc785bc: stur            x0, [fp, #-0x10]
    // 0xc785c0: r0 = MethodChannel()
    //     0xc785c0: bl              #0x5a2760  ; AllocateMethodChannelStub -> MethodChannel (size=0x14)
    // 0xc785c4: mov             x3, x0
    // 0xc785c8: ldur            x0, [fp, #-0x10]
    // 0xc785cc: stur            x3, [fp, #-0x18]
    // 0xc785d0: StoreField: r3->field_7 = r0
    //     0xc785d0: stur            w0, [x3, #7]
    // 0xc785d4: r0 = Instance_StandardMethodCodec
    //     0xc785d4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14cc0] Obj!StandardMethodCodec@b35011
    //     0xc785d8: ldr             x0, [x0, #0xcc0]
    // 0xc785dc: StoreField: r3->field_b = r0
    //     0xc785dc: stur            w0, [x3, #0xb]
    // 0xc785e0: ldur            x2, [fp, #-8]
    // 0xc785e4: r1 = Function '<anonymous closure>':.
    //     0xc785e4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53cd0] AnonymousClosure: (0xc78618), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::initializeCamera (0xc78354)
    //     0xc785e8: ldr             x1, [x1, #0xcd0]
    // 0xc785ec: r0 = AllocateClosure()
    //     0xc785ec: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc785f0: ldur            x16, [fp, #-0x18]
    // 0xc785f4: stp             x0, x16, [SP, #-0x10]!
    // 0xc785f8: r0 = setMethodCallHandler()
    //     0xc785f8: bl              #0x5a84a0  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::setMethodCallHandler
    // 0xc785fc: add             SP, SP, #0x10
    // 0xc78600: ldur            x0, [fp, #-0x18]
    // 0xc78604: LeaveFrame
    //     0xc78604: mov             SP, fp
    //     0xc78608: ldp             fp, lr, [SP], #0x10
    // 0xc7860c: ret
    //     0xc7860c: ret             
    // 0xc78610: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc78610: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc78614: b               #0xc78588
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic, MethodCall) {
    // ** addr: 0xc78618, size: 0x64
    // 0xc78618: EnterFrame
    //     0xc78618: stp             fp, lr, [SP, #-0x10]!
    //     0xc7861c: mov             fp, SP
    // 0xc78620: ldr             x0, [fp, #0x18]
    // 0xc78624: LoadField: r1 = r0->field_17
    //     0xc78624: ldur            w1, [x0, #0x17]
    // 0xc78628: DecompressPointer r1
    //     0xc78628: add             x1, x1, HEAP, lsl #32
    // 0xc7862c: CheckStackOverflow
    //     0xc7862c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc78630: cmp             SP, x16
    //     0xc78634: b.ls            #0xc78674
    // 0xc78638: LoadField: r0 = r1->field_f
    //     0xc78638: ldur            w0, [x1, #0xf]
    // 0xc7863c: DecompressPointer r0
    //     0xc7863c: add             x0, x0, HEAP, lsl #32
    // 0xc78640: LoadField: r2 = r1->field_13
    //     0xc78640: ldur            w2, [x1, #0x13]
    // 0xc78644: DecompressPointer r2
    //     0xc78644: add             x2, x2, HEAP, lsl #32
    // 0xc78648: r1 = LoadInt32Instr(r2)
    //     0xc78648: sbfx            x1, x2, #1, #0x1f
    //     0xc7864c: tbz             w2, #0, #0xc78654
    //     0xc78650: ldur            x1, [x2, #7]
    // 0xc78654: ldr             x16, [fp, #0x10]
    // 0xc78658: stp             x16, x0, [SP, #-0x10]!
    // 0xc7865c: SaveReg r1
    //     0xc7865c: str             x1, [SP, #-8]!
    // 0xc78660: r0 = handleCameraMethodCall()
    //     0xc78660: bl              #0xc7867c  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::handleCameraMethodCall
    // 0xc78664: add             SP, SP, #0x18
    // 0xc78668: LeaveFrame
    //     0xc78668: mov             SP, fp
    //     0xc7866c: ldp             fp, lr, [SP], #0x10
    // 0xc78670: ret
    //     0xc78670: ret             
    // 0xc78674: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc78674: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc78678: b               #0xc78638
  }
  _ handleCameraMethodCall(/* No info */) async {
    // ** addr: 0xc7867c, size: 0x90c
    // 0xc7867c: EnterFrame
    //     0xc7867c: stp             fp, lr, [SP, #-0x10]!
    //     0xc78680: mov             fp, SP
    // 0xc78684: AllocStack(0x70)
    //     0xc78684: sub             SP, SP, #0x70
    // 0xc78688: SetupParameters(MethodChannelCamera this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0xc78688: stur            NULL, [fp, #-8]
    //     0xc7868c: mov             x0, #0
    //     0xc78690: add             x1, fp, w0, sxtw #2
    //     0xc78694: ldr             x1, [x1, #0x20]
    //     0xc78698: stur            x1, [fp, #-0x20]
    //     0xc7869c: add             x2, fp, w0, sxtw #2
    //     0xc786a0: ldr             x2, [x2, #0x18]
    //     0xc786a4: stur            x2, [fp, #-0x18]
    //     0xc786a8: add             x3, fp, w0, sxtw #2
    //     0xc786ac: ldr             x3, [x3, #0x10]
    //     0xc786b0: stur            x3, [fp, #-0x10]
    // 0xc786b4: CheckStackOverflow
    //     0xc786b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc786b8: cmp             SP, x16
    //     0xc786bc: b.ls            #0xc78f54
    // 0xc786c0: InitAsync() -> Future
    //     0xc786c0: mov             x0, NULL
    //     0xc786c4: bl              #0x4b92e4
    // 0xc786c8: ldur            x0, [fp, #-0x18]
    // 0xc786cc: LoadField: r1 = r0->field_7
    //     0xc786cc: ldur            w1, [x0, #7]
    // 0xc786d0: DecompressPointer r1
    //     0xc786d0: add             x1, x1, HEAP, lsl #32
    // 0xc786d4: stur            x1, [fp, #-0x28]
    // 0xc786d8: r16 = "initialized"
    //     0xc786d8: add             x16, PP, #0x49, lsl #12  ; [pp+0x49548] "initialized"
    //     0xc786dc: ldr             x16, [x16, #0x548]
    // 0xc786e0: stp             x1, x16, [SP, #-0x10]!
    // 0xc786e4: r0 = ==()
    //     0xc786e4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc786e8: add             SP, SP, #0x10
    // 0xc786ec: tbnz            w0, #4, #0xc78a40
    // 0xc786f0: ldur            x0, [fp, #-0x20]
    // 0xc786f4: ldur            x1, [fp, #-0x10]
    // 0xc786f8: ldur            x16, [fp, #-0x18]
    // 0xc786fc: stp             x16, x0, [SP, #-0x10]!
    // 0xc78700: r0 = _getArgumentDictionary()
    //     0xc78700: bl              #0x5a8b10  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_getArgumentDictionary
    // 0xc78704: add             SP, SP, #0x10
    // 0xc78708: mov             x1, x0
    // 0xc7870c: ldur            x0, [fp, #-0x20]
    // 0xc78710: stur            x1, [fp, #-0x38]
    // 0xc78714: LoadField: r2 = r0->field_b
    //     0xc78714: ldur            w2, [x0, #0xb]
    // 0xc78718: DecompressPointer r2
    //     0xc78718: add             x2, x2, HEAP, lsl #32
    // 0xc7871c: stur            x2, [fp, #-0x30]
    // 0xc78720: r0 = LoadClassIdInstr(r1)
    //     0xc78720: ldur            x0, [x1, #-1]
    //     0xc78724: ubfx            x0, x0, #0xc, #0x14
    // 0xc78728: r16 = "previewWidth"
    //     0xc78728: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cd8] "previewWidth"
    //     0xc7872c: ldr             x16, [x16, #0xcd8]
    // 0xc78730: stp             x16, x1, [SP, #-0x10]!
    // 0xc78734: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78734: sub             lr, x0, #0xef
    //     0xc78738: ldr             lr, [x21, lr, lsl #3]
    //     0xc7873c: blr             lr
    // 0xc78740: add             SP, SP, #0x10
    // 0xc78744: mov             x3, x0
    // 0xc78748: stur            x3, [fp, #-0x40]
    // 0xc7874c: cmp             w3, NULL
    // 0xc78750: b.eq            #0xc78f5c
    // 0xc78754: mov             x0, x3
    // 0xc78758: r2 = Null
    //     0xc78758: mov             x2, NULL
    // 0xc7875c: r1 = Null
    //     0xc7875c: mov             x1, NULL
    // 0xc78760: r4 = 59
    //     0xc78760: mov             x4, #0x3b
    // 0xc78764: branchIfSmi(r0, 0xc78770)
    //     0xc78764: tbz             w0, #0, #0xc78770
    // 0xc78768: r4 = LoadClassIdInstr(r0)
    //     0xc78768: ldur            x4, [x0, #-1]
    //     0xc7876c: ubfx            x4, x4, #0xc, #0x14
    // 0xc78770: cmp             x4, #0x3d
    // 0xc78774: b.eq            #0xc78788
    // 0xc78778: r8 = double
    //     0xc78778: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc7877c: r3 = Null
    //     0xc7877c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ce0] Null
    //     0xc78780: ldr             x3, [x3, #0xce0]
    // 0xc78784: r0 = double()
    //     0xc78784: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc78788: ldur            x1, [fp, #-0x38]
    // 0xc7878c: r0 = LoadClassIdInstr(r1)
    //     0xc7878c: ldur            x0, [x1, #-1]
    //     0xc78790: ubfx            x0, x0, #0xc, #0x14
    // 0xc78794: r16 = "previewHeight"
    //     0xc78794: add             x16, PP, #0x53, lsl #12  ; [pp+0x53cf0] "previewHeight"
    //     0xc78798: ldr             x16, [x16, #0xcf0]
    // 0xc7879c: stp             x16, x1, [SP, #-0x10]!
    // 0xc787a0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc787a0: sub             lr, x0, #0xef
    //     0xc787a4: ldr             lr, [x21, lr, lsl #3]
    //     0xc787a8: blr             lr
    // 0xc787ac: add             SP, SP, #0x10
    // 0xc787b0: mov             x3, x0
    // 0xc787b4: stur            x3, [fp, #-0x48]
    // 0xc787b8: cmp             w3, NULL
    // 0xc787bc: b.eq            #0xc78f60
    // 0xc787c0: mov             x0, x3
    // 0xc787c4: r2 = Null
    //     0xc787c4: mov             x2, NULL
    // 0xc787c8: r1 = Null
    //     0xc787c8: mov             x1, NULL
    // 0xc787cc: r4 = 59
    //     0xc787cc: mov             x4, #0x3b
    // 0xc787d0: branchIfSmi(r0, 0xc787dc)
    //     0xc787d0: tbz             w0, #0, #0xc787dc
    // 0xc787d4: r4 = LoadClassIdInstr(r0)
    //     0xc787d4: ldur            x4, [x0, #-1]
    //     0xc787d8: ubfx            x4, x4, #0xc, #0x14
    // 0xc787dc: cmp             x4, #0x3d
    // 0xc787e0: b.eq            #0xc787f4
    // 0xc787e4: r8 = double
    //     0xc787e4: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc787e8: r3 = Null
    //     0xc787e8: add             x3, PP, #0x53, lsl #12  ; [pp+0x53cf8] Null
    //     0xc787ec: ldr             x3, [x3, #0xcf8]
    // 0xc787f0: r0 = double()
    //     0xc787f0: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc787f4: ldur            x1, [fp, #-0x38]
    // 0xc787f8: r0 = LoadClassIdInstr(r1)
    //     0xc787f8: ldur            x0, [x1, #-1]
    //     0xc787fc: ubfx            x0, x0, #0xc, #0x14
    // 0xc78800: r16 = "exposureMode"
    //     0xc78800: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d478] "exposureMode"
    //     0xc78804: ldr             x16, [x16, #0x478]
    // 0xc78808: stp             x16, x1, [SP, #-0x10]!
    // 0xc7880c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7880c: sub             lr, x0, #0xef
    //     0xc78810: ldr             lr, [x21, lr, lsl #3]
    //     0xc78814: blr             lr
    // 0xc78818: add             SP, SP, #0x10
    // 0xc7881c: mov             x3, x0
    // 0xc78820: stur            x3, [fp, #-0x50]
    // 0xc78824: cmp             w3, NULL
    // 0xc78828: b.eq            #0xc78f64
    // 0xc7882c: mov             x0, x3
    // 0xc78830: r2 = Null
    //     0xc78830: mov             x2, NULL
    // 0xc78834: r1 = Null
    //     0xc78834: mov             x1, NULL
    // 0xc78838: r4 = 59
    //     0xc78838: mov             x4, #0x3b
    // 0xc7883c: branchIfSmi(r0, 0xc78848)
    //     0xc7883c: tbz             w0, #0, #0xc78848
    // 0xc78840: r4 = LoadClassIdInstr(r0)
    //     0xc78840: ldur            x4, [x0, #-1]
    //     0xc78844: ubfx            x4, x4, #0xc, #0x14
    // 0xc78848: sub             x4, x4, #0x5d
    // 0xc7884c: cmp             x4, #3
    // 0xc78850: b.ls            #0xc78864
    // 0xc78854: r8 = String
    //     0xc78854: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc78858: r3 = Null
    //     0xc78858: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d08] Null
    //     0xc7885c: ldr             x3, [x3, #0xd08]
    // 0xc78860: r0 = String()
    //     0xc78860: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc78864: ldur            x16, [fp, #-0x50]
    // 0xc78868: SaveReg r16
    //     0xc78868: str             x16, [SP, #-8]!
    // 0xc7886c: r0 = deserializeExposureMode()
    //     0xc7886c: bl              #0xc77640  ; [package:camera_platform_interface/src/types/exposure_mode.dart] ::deserializeExposureMode
    // 0xc78870: add             SP, SP, #8
    // 0xc78874: mov             x2, x0
    // 0xc78878: ldur            x1, [fp, #-0x38]
    // 0xc7887c: stur            x2, [fp, #-0x50]
    // 0xc78880: r0 = LoadClassIdInstr(r1)
    //     0xc78880: ldur            x0, [x1, #-1]
    //     0xc78884: ubfx            x0, x0, #0xc, #0x14
    // 0xc78888: r16 = "exposurePointSupported"
    //     0xc78888: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d480] "exposurePointSupported"
    //     0xc7888c: ldr             x16, [x16, #0x480]
    // 0xc78890: stp             x16, x1, [SP, #-0x10]!
    // 0xc78894: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78894: sub             lr, x0, #0xef
    //     0xc78898: ldr             lr, [x21, lr, lsl #3]
    //     0xc7889c: blr             lr
    // 0xc788a0: add             SP, SP, #0x10
    // 0xc788a4: mov             x3, x0
    // 0xc788a8: stur            x3, [fp, #-0x58]
    // 0xc788ac: cmp             w3, NULL
    // 0xc788b0: b.eq            #0xc78f68
    // 0xc788b4: mov             x0, x3
    // 0xc788b8: r2 = Null
    //     0xc788b8: mov             x2, NULL
    // 0xc788bc: r1 = Null
    //     0xc788bc: mov             x1, NULL
    // 0xc788c0: r4 = 59
    //     0xc788c0: mov             x4, #0x3b
    // 0xc788c4: branchIfSmi(r0, 0xc788d0)
    //     0xc788c4: tbz             w0, #0, #0xc788d0
    // 0xc788c8: r4 = LoadClassIdInstr(r0)
    //     0xc788c8: ldur            x4, [x0, #-1]
    //     0xc788cc: ubfx            x4, x4, #0xc, #0x14
    // 0xc788d0: cmp             x4, #0x3e
    // 0xc788d4: b.eq            #0xc788e8
    // 0xc788d8: r8 = bool
    //     0xc788d8: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xc788dc: r3 = Null
    //     0xc788dc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d18] Null
    //     0xc788e0: ldr             x3, [x3, #0xd18]
    // 0xc788e4: r0 = bool()
    //     0xc788e4: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xc788e8: ldur            x1, [fp, #-0x38]
    // 0xc788ec: r0 = LoadClassIdInstr(r1)
    //     0xc788ec: ldur            x0, [x1, #-1]
    //     0xc788f0: ubfx            x0, x0, #0xc, #0x14
    // 0xc788f4: r16 = "focusMode"
    //     0xc788f4: add             x16, PP, #0x45, lsl #12  ; [pp+0x45988] "focusMode"
    //     0xc788f8: ldr             x16, [x16, #0x988]
    // 0xc788fc: stp             x16, x1, [SP, #-0x10]!
    // 0xc78900: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78900: sub             lr, x0, #0xef
    //     0xc78904: ldr             lr, [x21, lr, lsl #3]
    //     0xc78908: blr             lr
    // 0xc7890c: add             SP, SP, #0x10
    // 0xc78910: mov             x3, x0
    // 0xc78914: stur            x3, [fp, #-0x60]
    // 0xc78918: cmp             w3, NULL
    // 0xc7891c: b.eq            #0xc78f6c
    // 0xc78920: mov             x0, x3
    // 0xc78924: r2 = Null
    //     0xc78924: mov             x2, NULL
    // 0xc78928: r1 = Null
    //     0xc78928: mov             x1, NULL
    // 0xc7892c: r4 = 59
    //     0xc7892c: mov             x4, #0x3b
    // 0xc78930: branchIfSmi(r0, 0xc7893c)
    //     0xc78930: tbz             w0, #0, #0xc7893c
    // 0xc78934: r4 = LoadClassIdInstr(r0)
    //     0xc78934: ldur            x4, [x0, #-1]
    //     0xc78938: ubfx            x4, x4, #0xc, #0x14
    // 0xc7893c: sub             x4, x4, #0x5d
    // 0xc78940: cmp             x4, #3
    // 0xc78944: b.ls            #0xc78958
    // 0xc78948: r8 = String
    //     0xc78948: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7894c: r3 = Null
    //     0xc7894c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d28] Null
    //     0xc78950: ldr             x3, [x3, #0xd28]
    // 0xc78954: r0 = String()
    //     0xc78954: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc78958: ldur            x16, [fp, #-0x60]
    // 0xc7895c: SaveReg r16
    //     0xc7895c: str             x16, [SP, #-8]!
    // 0xc78960: r0 = deserializeFocusMode()
    //     0xc78960: bl              #0xc77560  ; [package:camera_platform_interface/src/types/focus_mode.dart] ::deserializeFocusMode
    // 0xc78964: add             SP, SP, #8
    // 0xc78968: mov             x1, x0
    // 0xc7896c: ldur            x0, [fp, #-0x38]
    // 0xc78970: stur            x1, [fp, #-0x60]
    // 0xc78974: r2 = LoadClassIdInstr(r0)
    //     0xc78974: ldur            x2, [x0, #-1]
    //     0xc78978: ubfx            x2, x2, #0xc, #0x14
    // 0xc7897c: r16 = "focusPointSupported"
    //     0xc7897c: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d490] "focusPointSupported"
    //     0xc78980: ldr             x16, [x16, #0x490]
    // 0xc78984: stp             x16, x0, [SP, #-0x10]!
    // 0xc78988: mov             x0, x2
    // 0xc7898c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7898c: sub             lr, x0, #0xef
    //     0xc78990: ldr             lr, [x21, lr, lsl #3]
    //     0xc78994: blr             lr
    // 0xc78998: add             SP, SP, #0x10
    // 0xc7899c: mov             x3, x0
    // 0xc789a0: stur            x3, [fp, #-0x38]
    // 0xc789a4: cmp             w3, NULL
    // 0xc789a8: b.eq            #0xc78f70
    // 0xc789ac: mov             x0, x3
    // 0xc789b0: r2 = Null
    //     0xc789b0: mov             x2, NULL
    // 0xc789b4: r1 = Null
    //     0xc789b4: mov             x1, NULL
    // 0xc789b8: r4 = 59
    //     0xc789b8: mov             x4, #0x3b
    // 0xc789bc: branchIfSmi(r0, 0xc789c8)
    //     0xc789bc: tbz             w0, #0, #0xc789c8
    // 0xc789c0: r4 = LoadClassIdInstr(r0)
    //     0xc789c0: ldur            x4, [x0, #-1]
    //     0xc789c4: ubfx            x4, x4, #0xc, #0x14
    // 0xc789c8: cmp             x4, #0x3e
    // 0xc789cc: b.eq            #0xc789e0
    // 0xc789d0: r8 = bool
    //     0xc789d0: ldr             x8, [PP, #0x13e0]  ; [pp+0x13e0] Type: bool
    // 0xc789d4: r3 = Null
    //     0xc789d4: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d38] Null
    //     0xc789d8: ldr             x3, [x3, #0xd38]
    // 0xc789dc: r0 = bool()
    //     0xc789dc: bl              #0xd72a3c  ; IsType_bool_Stub
    // 0xc789e0: ldur            x0, [fp, #-0x40]
    // 0xc789e4: LoadField: d0 = r0->field_7
    //     0xc789e4: ldur            d0, [x0, #7]
    // 0xc789e8: stur            d0, [fp, #-0x70]
    // 0xc789ec: r0 = CameraInitializedEvent()
    //     0xc789ec: bl              #0xc77554  ; AllocateCameraInitializedEventStub -> CameraInitializedEvent (size=0x30)
    // 0xc789f0: ldur            d0, [fp, #-0x70]
    // 0xc789f4: StoreField: r0->field_f = d0
    //     0xc789f4: stur            d0, [x0, #0xf]
    // 0xc789f8: ldur            x1, [fp, #-0x48]
    // 0xc789fc: LoadField: d0 = r1->field_7
    //     0xc789fc: ldur            d0, [x1, #7]
    // 0xc78a00: StoreField: r0->field_17 = d0
    //     0xc78a00: stur            d0, [x0, #0x17]
    // 0xc78a04: ldur            x1, [fp, #-0x50]
    // 0xc78a08: StoreField: r0->field_1f = r1
    //     0xc78a08: stur            w1, [x0, #0x1f]
    // 0xc78a0c: ldur            x1, [fp, #-0x58]
    // 0xc78a10: StoreField: r0->field_27 = r1
    //     0xc78a10: stur            w1, [x0, #0x27]
    // 0xc78a14: ldur            x1, [fp, #-0x60]
    // 0xc78a18: StoreField: r0->field_23 = r1
    //     0xc78a18: stur            w1, [x0, #0x23]
    // 0xc78a1c: ldur            x1, [fp, #-0x38]
    // 0xc78a20: StoreField: r0->field_2b = r1
    //     0xc78a20: stur            w1, [x0, #0x2b]
    // 0xc78a24: ldur            x1, [fp, #-0x10]
    // 0xc78a28: StoreField: r0->field_7 = r1
    //     0xc78a28: stur            x1, [x0, #7]
    // 0xc78a2c: ldur            x16, [fp, #-0x30]
    // 0xc78a30: stp             x0, x16, [SP, #-0x10]!
    // 0xc78a34: r0 = add()
    //     0xc78a34: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78a38: add             SP, SP, #0x10
    // 0xc78a3c: b               #0xc78f40
    // 0xc78a40: ldur            x0, [fp, #-0x20]
    // 0xc78a44: ldur            x1, [fp, #-0x10]
    // 0xc78a48: r16 = "resolution_changed"
    //     0xc78a48: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d48] "resolution_changed"
    //     0xc78a4c: ldr             x16, [x16, #0xd48]
    // 0xc78a50: ldur            lr, [fp, #-0x28]
    // 0xc78a54: stp             lr, x16, [SP, #-0x10]!
    // 0xc78a58: r0 = ==()
    //     0xc78a58: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc78a5c: add             SP, SP, #0x10
    // 0xc78a60: tbnz            w0, #4, #0xc78bac
    // 0xc78a64: ldur            x0, [fp, #-0x20]
    // 0xc78a68: ldur            x1, [fp, #-0x10]
    // 0xc78a6c: ldur            x16, [fp, #-0x18]
    // 0xc78a70: stp             x16, x0, [SP, #-0x10]!
    // 0xc78a74: r0 = _getArgumentDictionary()
    //     0xc78a74: bl              #0x5a8b10  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_getArgumentDictionary
    // 0xc78a78: add             SP, SP, #0x10
    // 0xc78a7c: mov             x1, x0
    // 0xc78a80: ldur            x0, [fp, #-0x20]
    // 0xc78a84: stur            x1, [fp, #-0x38]
    // 0xc78a88: LoadField: r2 = r0->field_b
    //     0xc78a88: ldur            w2, [x0, #0xb]
    // 0xc78a8c: DecompressPointer r2
    //     0xc78a8c: add             x2, x2, HEAP, lsl #32
    // 0xc78a90: stur            x2, [fp, #-0x30]
    // 0xc78a94: r0 = LoadClassIdInstr(r1)
    //     0xc78a94: ldur            x0, [x1, #-1]
    //     0xc78a98: ubfx            x0, x0, #0xc, #0x14
    // 0xc78a9c: r16 = "captureWidth"
    //     0xc78a9c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d50] "captureWidth"
    //     0xc78aa0: ldr             x16, [x16, #0xd50]
    // 0xc78aa4: stp             x16, x1, [SP, #-0x10]!
    // 0xc78aa8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78aa8: sub             lr, x0, #0xef
    //     0xc78aac: ldr             lr, [x21, lr, lsl #3]
    //     0xc78ab0: blr             lr
    // 0xc78ab4: add             SP, SP, #0x10
    // 0xc78ab8: mov             x3, x0
    // 0xc78abc: stur            x3, [fp, #-0x40]
    // 0xc78ac0: cmp             w3, NULL
    // 0xc78ac4: b.eq            #0xc78f74
    // 0xc78ac8: mov             x0, x3
    // 0xc78acc: r2 = Null
    //     0xc78acc: mov             x2, NULL
    // 0xc78ad0: r1 = Null
    //     0xc78ad0: mov             x1, NULL
    // 0xc78ad4: r4 = 59
    //     0xc78ad4: mov             x4, #0x3b
    // 0xc78ad8: branchIfSmi(r0, 0xc78ae4)
    //     0xc78ad8: tbz             w0, #0, #0xc78ae4
    // 0xc78adc: r4 = LoadClassIdInstr(r0)
    //     0xc78adc: ldur            x4, [x0, #-1]
    //     0xc78ae0: ubfx            x4, x4, #0xc, #0x14
    // 0xc78ae4: cmp             x4, #0x3d
    // 0xc78ae8: b.eq            #0xc78afc
    // 0xc78aec: r8 = double
    //     0xc78aec: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc78af0: r3 = Null
    //     0xc78af0: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d58] Null
    //     0xc78af4: ldr             x3, [x3, #0xd58]
    // 0xc78af8: r0 = double()
    //     0xc78af8: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc78afc: ldur            x0, [fp, #-0x38]
    // 0xc78b00: r1 = LoadClassIdInstr(r0)
    //     0xc78b00: ldur            x1, [x0, #-1]
    //     0xc78b04: ubfx            x1, x1, #0xc, #0x14
    // 0xc78b08: r16 = "captureHeight"
    //     0xc78b08: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d68] "captureHeight"
    //     0xc78b0c: ldr             x16, [x16, #0xd68]
    // 0xc78b10: stp             x16, x0, [SP, #-0x10]!
    // 0xc78b14: mov             x0, x1
    // 0xc78b18: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78b18: sub             lr, x0, #0xef
    //     0xc78b1c: ldr             lr, [x21, lr, lsl #3]
    //     0xc78b20: blr             lr
    // 0xc78b24: add             SP, SP, #0x10
    // 0xc78b28: mov             x3, x0
    // 0xc78b2c: stur            x3, [fp, #-0x38]
    // 0xc78b30: cmp             w3, NULL
    // 0xc78b34: b.eq            #0xc78f78
    // 0xc78b38: mov             x0, x3
    // 0xc78b3c: r2 = Null
    //     0xc78b3c: mov             x2, NULL
    // 0xc78b40: r1 = Null
    //     0xc78b40: mov             x1, NULL
    // 0xc78b44: r4 = 59
    //     0xc78b44: mov             x4, #0x3b
    // 0xc78b48: branchIfSmi(r0, 0xc78b54)
    //     0xc78b48: tbz             w0, #0, #0xc78b54
    // 0xc78b4c: r4 = LoadClassIdInstr(r0)
    //     0xc78b4c: ldur            x4, [x0, #-1]
    //     0xc78b50: ubfx            x4, x4, #0xc, #0x14
    // 0xc78b54: cmp             x4, #0x3d
    // 0xc78b58: b.eq            #0xc78b6c
    // 0xc78b5c: r8 = double
    //     0xc78b5c: ldr             x8, [PP, #0x22e8]  ; [pp+0x22e8] Type: double
    // 0xc78b60: r3 = Null
    //     0xc78b60: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d70] Null
    //     0xc78b64: ldr             x3, [x3, #0xd70]
    // 0xc78b68: r0 = double()
    //     0xc78b68: bl              #0xd72bac  ; IsType_double_Stub
    // 0xc78b6c: ldur            x0, [fp, #-0x40]
    // 0xc78b70: LoadField: d0 = r0->field_7
    //     0xc78b70: ldur            d0, [x0, #7]
    // 0xc78b74: stur            d0, [fp, #-0x70]
    // 0xc78b78: r0 = CameraResolutionChangedEvent()
    //     0xc78b78: bl              #0xc77548  ; AllocateCameraResolutionChangedEventStub -> CameraResolutionChangedEvent (size=0x20)
    // 0xc78b7c: ldur            d0, [fp, #-0x70]
    // 0xc78b80: StoreField: r0->field_f = d0
    //     0xc78b80: stur            d0, [x0, #0xf]
    // 0xc78b84: ldur            x1, [fp, #-0x38]
    // 0xc78b88: LoadField: d0 = r1->field_7
    //     0xc78b88: ldur            d0, [x1, #7]
    // 0xc78b8c: StoreField: r0->field_17 = d0
    //     0xc78b8c: stur            d0, [x0, #0x17]
    // 0xc78b90: ldur            x1, [fp, #-0x10]
    // 0xc78b94: StoreField: r0->field_7 = r1
    //     0xc78b94: stur            x1, [x0, #7]
    // 0xc78b98: ldur            x16, [fp, #-0x30]
    // 0xc78b9c: stp             x0, x16, [SP, #-0x10]!
    // 0xc78ba0: r0 = add()
    //     0xc78ba0: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78ba4: add             SP, SP, #0x10
    // 0xc78ba8: b               #0xc78f40
    // 0xc78bac: ldur            x0, [fp, #-0x20]
    // 0xc78bb0: ldur            x1, [fp, #-0x10]
    // 0xc78bb4: r16 = "camera_closing"
    //     0xc78bb4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d80] "camera_closing"
    //     0xc78bb8: ldr             x16, [x16, #0xd80]
    // 0xc78bbc: ldur            lr, [fp, #-0x28]
    // 0xc78bc0: stp             lr, x16, [SP, #-0x10]!
    // 0xc78bc4: r0 = ==()
    //     0xc78bc4: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc78bc8: add             SP, SP, #0x10
    // 0xc78bcc: tbnz            w0, #4, #0xc78c04
    // 0xc78bd0: ldur            x0, [fp, #-0x20]
    // 0xc78bd4: ldur            x1, [fp, #-0x10]
    // 0xc78bd8: LoadField: r2 = r0->field_b
    //     0xc78bd8: ldur            w2, [x0, #0xb]
    // 0xc78bdc: DecompressPointer r2
    //     0xc78bdc: add             x2, x2, HEAP, lsl #32
    // 0xc78be0: stur            x2, [fp, #-0x30]
    // 0xc78be4: r0 = CameraClosingEvent()
    //     0xc78be4: bl              #0xc7753c  ; AllocateCameraClosingEventStub -> CameraClosingEvent (size=0x10)
    // 0xc78be8: ldur            x1, [fp, #-0x10]
    // 0xc78bec: StoreField: r0->field_7 = r1
    //     0xc78bec: stur            x1, [x0, #7]
    // 0xc78bf0: ldur            x16, [fp, #-0x30]
    // 0xc78bf4: stp             x0, x16, [SP, #-0x10]!
    // 0xc78bf8: r0 = add()
    //     0xc78bf8: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78bfc: add             SP, SP, #0x10
    // 0xc78c00: b               #0xc78f40
    // 0xc78c04: ldur            x0, [fp, #-0x20]
    // 0xc78c08: ldur            x1, [fp, #-0x10]
    // 0xc78c0c: r16 = "video_recorded"
    //     0xc78c0c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53d88] "video_recorded"
    //     0xc78c10: ldr             x16, [x16, #0xd88]
    // 0xc78c14: ldur            lr, [fp, #-0x28]
    // 0xc78c18: stp             lr, x16, [SP, #-0x10]!
    // 0xc78c1c: r0 = ==()
    //     0xc78c1c: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc78c20: add             SP, SP, #0x10
    // 0xc78c24: tbnz            w0, #4, #0xc78e60
    // 0xc78c28: ldur            x0, [fp, #-0x20]
    // 0xc78c2c: ldur            x16, [fp, #-0x18]
    // 0xc78c30: stp             x16, x0, [SP, #-0x10]!
    // 0xc78c34: r0 = _getArgumentDictionary()
    //     0xc78c34: bl              #0x5a8b10  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_getArgumentDictionary
    // 0xc78c38: add             SP, SP, #0x10
    // 0xc78c3c: mov             x1, x0
    // 0xc78c40: ldur            x0, [fp, #-0x20]
    // 0xc78c44: stur            x1, [fp, #-0x38]
    // 0xc78c48: LoadField: r2 = r0->field_b
    //     0xc78c48: ldur            w2, [x0, #0xb]
    // 0xc78c4c: DecompressPointer r2
    //     0xc78c4c: add             x2, x2, HEAP, lsl #32
    // 0xc78c50: stur            x2, [fp, #-0x30]
    // 0xc78c54: r0 = LoadClassIdInstr(r1)
    //     0xc78c54: ldur            x0, [x1, #-1]
    //     0xc78c58: ubfx            x0, x0, #0xc, #0x14
    // 0xc78c5c: r16 = "path"
    //     0xc78c5c: ldr             x16, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xc78c60: stp             x16, x1, [SP, #-0x10]!
    // 0xc78c64: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78c64: sub             lr, x0, #0xef
    //     0xc78c68: ldr             lr, [x21, lr, lsl #3]
    //     0xc78c6c: blr             lr
    // 0xc78c70: add             SP, SP, #0x10
    // 0xc78c74: mov             x3, x0
    // 0xc78c78: stur            x3, [fp, #-0x40]
    // 0xc78c7c: cmp             w3, NULL
    // 0xc78c80: b.eq            #0xc78f7c
    // 0xc78c84: mov             x0, x3
    // 0xc78c88: r2 = Null
    //     0xc78c88: mov             x2, NULL
    // 0xc78c8c: r1 = Null
    //     0xc78c8c: mov             x1, NULL
    // 0xc78c90: r4 = 59
    //     0xc78c90: mov             x4, #0x3b
    // 0xc78c94: branchIfSmi(r0, 0xc78ca0)
    //     0xc78c94: tbz             w0, #0, #0xc78ca0
    // 0xc78c98: r4 = LoadClassIdInstr(r0)
    //     0xc78c98: ldur            x4, [x0, #-1]
    //     0xc78c9c: ubfx            x4, x4, #0xc, #0x14
    // 0xc78ca0: sub             x4, x4, #0x5d
    // 0xc78ca4: cmp             x4, #3
    // 0xc78ca8: b.ls            #0xc78cbc
    // 0xc78cac: r8 = String
    //     0xc78cac: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc78cb0: r3 = Null
    //     0xc78cb0: add             x3, PP, #0x53, lsl #12  ; [pp+0x53d90] Null
    //     0xc78cb4: ldr             x3, [x3, #0xd90]
    // 0xc78cb8: r0 = String()
    //     0xc78cb8: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc78cbc: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0xc78cbc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc78cc0: ldr             x0, [x0, #0xb58]
    //     0xc78cc4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc78cc8: cmp             w0, w16
    //     0xc78ccc: b.ne            #0xc78cd8
    //     0xc78cd0: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0xc78cd4: bl              #0xd67d44
    // 0xc78cd8: r0 = InitLateStaticField(0x6ec) // [dart:io] ::_ioOverridesToken
    //     0xc78cd8: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xc78cdc: ldr             x0, [x0, #0xdd8]
    //     0xc78ce0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xc78ce4: cmp             w0, w16
    //     0xc78ce8: b.ne            #0xc78cf4
    //     0xc78cec: ldr             x2, [PP, #0x2820]  ; [pp+0x2820] Field <::._ioOverridesToken@14069316>: static late final (offset: 0x6ec)
    //     0xc78cf0: bl              #0xd67cdc
    // 0xc78cf4: r0 = _File()
    //     0xc78cf4: bl              #0x4eac10  ; Allocate_FileStub -> _File (size=0x10)
    // 0xc78cf8: mov             x1, x0
    // 0xc78cfc: ldur            x0, [fp, #-0x40]
    // 0xc78d00: stur            x1, [fp, #-0x48]
    // 0xc78d04: StoreField: r1->field_7 = r0
    //     0xc78d04: stur            w0, [x1, #7]
    // 0xc78d08: SaveReg r0
    //     0xc78d08: str             x0, [SP, #-8]!
    // 0xc78d0c: r0 = _toUtf8Array()
    //     0xc78d0c: bl              #0x4e1fa0  ; [dart:io] FileSystemEntity::_toUtf8Array
    // 0xc78d10: add             SP, SP, #8
    // 0xc78d14: ldur            x1, [fp, #-0x48]
    // 0xc78d18: StoreField: r1->field_b = r0
    //     0xc78d18: stur            w0, [x1, #0xb]
    //     0xc78d1c: ldurb           w16, [x1, #-1]
    //     0xc78d20: ldurb           w17, [x0, #-1]
    //     0xc78d24: and             x16, x17, x16, lsr #2
    //     0xc78d28: tst             x16, HEAP, lsr #32
    //     0xc78d2c: b.eq            #0xc78d34
    //     0xc78d30: bl              #0xd6826c
    // 0xc78d34: r0 = XFile()
    //     0xc78d34: bl              #0xc6a500  ; AllocateXFileStub -> XFile (size=0x10)
    // 0xc78d38: mov             x1, x0
    // 0xc78d3c: ldur            x0, [fp, #-0x48]
    // 0xc78d40: stur            x1, [fp, #-0x40]
    // 0xc78d44: StoreField: r1->field_7 = r0
    //     0xc78d44: stur            w0, [x1, #7]
    // 0xc78d48: ldur            x2, [fp, #-0x38]
    // 0xc78d4c: r0 = LoadClassIdInstr(r2)
    //     0xc78d4c: ldur            x0, [x2, #-1]
    //     0xc78d50: ubfx            x0, x0, #0xc, #0x14
    // 0xc78d54: r16 = "maxVideoDuration"
    //     0xc78d54: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc78d58: ldr             x16, [x16, #0xb10]
    // 0xc78d5c: stp             x16, x2, [SP, #-0x10]!
    // 0xc78d60: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78d60: sub             lr, x0, #0xef
    //     0xc78d64: ldr             lr, [x21, lr, lsl #3]
    //     0xc78d68: blr             lr
    // 0xc78d6c: add             SP, SP, #0x10
    // 0xc78d70: cmp             w0, NULL
    // 0xc78d74: b.eq            #0xc78e1c
    // 0xc78d78: ldur            x0, [fp, #-0x38]
    // 0xc78d7c: r1 = LoadClassIdInstr(r0)
    //     0xc78d7c: ldur            x1, [x0, #-1]
    //     0xc78d80: ubfx            x1, x1, #0xc, #0x14
    // 0xc78d84: r16 = "maxVideoDuration"
    //     0xc78d84: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xc78d88: ldr             x16, [x16, #0xb10]
    // 0xc78d8c: stp             x16, x0, [SP, #-0x10]!
    // 0xc78d90: mov             x0, x1
    // 0xc78d94: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78d94: sub             lr, x0, #0xef
    //     0xc78d98: ldr             lr, [x21, lr, lsl #3]
    //     0xc78d9c: blr             lr
    // 0xc78da0: add             SP, SP, #0x10
    // 0xc78da4: mov             x3, x0
    // 0xc78da8: stur            x3, [fp, #-0x38]
    // 0xc78dac: cmp             w3, NULL
    // 0xc78db0: b.eq            #0xc78f80
    // 0xc78db4: r3 as int
    //     0xc78db4: mov             x0, x3
    //     0xc78db8: mov             x2, NULL
    //     0xc78dbc: mov             x1, NULL
    //     0xc78dc0: tbz             w0, #0, #0xc78de8
    //     0xc78dc4: ldur            x4, [x0, #-1]
    //     0xc78dc8: ubfx            x4, x4, #0xc, #0x14
    //     0xc78dcc: sub             x4, x4, #0x3b
    //     0xc78dd0: cmp             x4, #1
    //     0xc78dd4: b.ls            #0xc78de8
    //     0xc78dd8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc78ddc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53da0] Null
    //     0xc78de0: ldr             x3, [x3, #0xda0]
    //     0xc78de4: bl              #0xd73714
    // 0xc78de8: ldur            x0, [fp, #-0x38]
    // 0xc78dec: r1 = LoadInt32Instr(r0)
    //     0xc78dec: sbfx            x1, x0, #1, #0x1f
    //     0xc78df0: tbz             w0, #0, #0xc78df8
    //     0xc78df4: ldur            x1, [x0, #7]
    // 0xc78df8: r16 = 1000
    //     0xc78df8: mov             x16, #0x3e8
    // 0xc78dfc: mul             x0, x1, x16
    // 0xc78e00: stur            x0, [fp, #-0x68]
    // 0xc78e04: r0 = Duration()
    //     0xc78e04: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0xc78e08: mov             x1, x0
    // 0xc78e0c: ldur            x0, [fp, #-0x68]
    // 0xc78e10: StoreField: r1->field_7 = r0
    //     0xc78e10: stur            x0, [x1, #7]
    // 0xc78e14: mov             x2, x1
    // 0xc78e18: b               #0xc78e20
    // 0xc78e1c: r2 = Null
    //     0xc78e1c: mov             x2, NULL
    // 0xc78e20: ldur            x1, [fp, #-0x10]
    // 0xc78e24: ldur            x0, [fp, #-0x40]
    // 0xc78e28: stur            x2, [fp, #-0x38]
    // 0xc78e2c: r0 = VideoRecordedEvent()
    //     0xc78e2c: bl              #0xc77530  ; AllocateVideoRecordedEventStub -> VideoRecordedEvent (size=0x18)
    // 0xc78e30: mov             x1, x0
    // 0xc78e34: ldur            x0, [fp, #-0x40]
    // 0xc78e38: StoreField: r1->field_f = r0
    //     0xc78e38: stur            w0, [x1, #0xf]
    // 0xc78e3c: ldur            x0, [fp, #-0x38]
    // 0xc78e40: StoreField: r1->field_13 = r0
    //     0xc78e40: stur            w0, [x1, #0x13]
    // 0xc78e44: ldur            x2, [fp, #-0x10]
    // 0xc78e48: StoreField: r1->field_7 = r2
    //     0xc78e48: stur            x2, [x1, #7]
    // 0xc78e4c: ldur            x16, [fp, #-0x30]
    // 0xc78e50: stp             x1, x16, [SP, #-0x10]!
    // 0xc78e54: r0 = add()
    //     0xc78e54: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78e58: add             SP, SP, #0x10
    // 0xc78e5c: b               #0xc78f40
    // 0xc78e60: ldur            x0, [fp, #-0x20]
    // 0xc78e64: ldur            x2, [fp, #-0x10]
    // 0xc78e68: r16 = "error"
    //     0xc78e68: ldr             x16, [PP, #0xeb8]  ; [pp+0xeb8] "error"
    // 0xc78e6c: ldur            lr, [fp, #-0x28]
    // 0xc78e70: stp             lr, x16, [SP, #-0x10]!
    // 0xc78e74: r0 = ==()
    //     0xc78e74: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc78e78: add             SP, SP, #0x10
    // 0xc78e7c: tbnz            w0, #4, #0xc78f48
    // 0xc78e80: ldur            x0, [fp, #-0x20]
    // 0xc78e84: ldur            x1, [fp, #-0x10]
    // 0xc78e88: ldur            x16, [fp, #-0x18]
    // 0xc78e8c: stp             x16, x0, [SP, #-0x10]!
    // 0xc78e90: r0 = _getArgumentDictionary()
    //     0xc78e90: bl              #0x5a8b10  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::_getArgumentDictionary
    // 0xc78e94: add             SP, SP, #0x10
    // 0xc78e98: mov             x1, x0
    // 0xc78e9c: ldur            x0, [fp, #-0x20]
    // 0xc78ea0: LoadField: r2 = r0->field_b
    //     0xc78ea0: ldur            w2, [x0, #0xb]
    // 0xc78ea4: DecompressPointer r2
    //     0xc78ea4: add             x2, x2, HEAP, lsl #32
    // 0xc78ea8: stur            x2, [fp, #-0x18]
    // 0xc78eac: r0 = LoadClassIdInstr(r1)
    //     0xc78eac: ldur            x0, [x1, #-1]
    //     0xc78eb0: ubfx            x0, x0, #0xc, #0x14
    // 0xc78eb4: r16 = "description"
    //     0xc78eb4: add             x16, PP, #0x12, lsl #12  ; [pp+0x12b70] "description"
    //     0xc78eb8: ldr             x16, [x16, #0xb70]
    // 0xc78ebc: stp             x16, x1, [SP, #-0x10]!
    // 0xc78ec0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc78ec0: sub             lr, x0, #0xef
    //     0xc78ec4: ldr             lr, [x21, lr, lsl #3]
    //     0xc78ec8: blr             lr
    // 0xc78ecc: add             SP, SP, #0x10
    // 0xc78ed0: mov             x3, x0
    // 0xc78ed4: stur            x3, [fp, #-0x20]
    // 0xc78ed8: cmp             w3, NULL
    // 0xc78edc: b.eq            #0xc78f84
    // 0xc78ee0: mov             x0, x3
    // 0xc78ee4: r2 = Null
    //     0xc78ee4: mov             x2, NULL
    // 0xc78ee8: r1 = Null
    //     0xc78ee8: mov             x1, NULL
    // 0xc78eec: r4 = 59
    //     0xc78eec: mov             x4, #0x3b
    // 0xc78ef0: branchIfSmi(r0, 0xc78efc)
    //     0xc78ef0: tbz             w0, #0, #0xc78efc
    // 0xc78ef4: r4 = LoadClassIdInstr(r0)
    //     0xc78ef4: ldur            x4, [x0, #-1]
    //     0xc78ef8: ubfx            x4, x4, #0xc, #0x14
    // 0xc78efc: sub             x4, x4, #0x5d
    // 0xc78f00: cmp             x4, #3
    // 0xc78f04: b.ls            #0xc78f18
    // 0xc78f08: r8 = String
    //     0xc78f08: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc78f0c: r3 = Null
    //     0xc78f0c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53db0] Null
    //     0xc78f10: ldr             x3, [x3, #0xdb0]
    // 0xc78f14: r0 = String()
    //     0xc78f14: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc78f18: r0 = CameraErrorEvent()
    //     0xc78f18: bl              #0xc77524  ; AllocateCameraErrorEventStub -> CameraErrorEvent (size=0x14)
    // 0xc78f1c: mov             x1, x0
    // 0xc78f20: ldur            x0, [fp, #-0x20]
    // 0xc78f24: StoreField: r1->field_f = r0
    //     0xc78f24: stur            w0, [x1, #0xf]
    // 0xc78f28: ldur            x0, [fp, #-0x10]
    // 0xc78f2c: StoreField: r1->field_7 = r0
    //     0xc78f2c: stur            x0, [x1, #7]
    // 0xc78f30: ldur            x16, [fp, #-0x18]
    // 0xc78f34: stp             x1, x16, [SP, #-0x10]!
    // 0xc78f38: r0 = add()
    //     0xc78f38: bl              #0xc13698  ; [dart:async] _BroadcastStreamController::add
    // 0xc78f3c: add             SP, SP, #0x10
    // 0xc78f40: r0 = Null
    //     0xc78f40: mov             x0, NULL
    // 0xc78f44: r0 = ReturnAsyncNotFuture()
    //     0xc78f44: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc78f48: r0 = MissingPluginException()
    //     0xc78f48: bl              #0x501aa4  ; AllocateMissingPluginExceptionStub -> MissingPluginException (size=0xc)
    // 0xc78f4c: r0 = Throw()
    //     0xc78f4c: bl              #0xd67e38  ; ThrowStub
    // 0xc78f50: brk             #0
    // 0xc78f54: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc78f54: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc78f58: b               #0xc786c0
    // 0xc78f5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f60: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f60: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f64: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f64: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f68: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f68: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f70: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f70: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f80: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f80: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc78f84: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc78f84: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ createCamera(/* No info */) async {
    // ** addr: 0xc7a3b0, size: 0x274
    // 0xc7a3b0: EnterFrame
    //     0xc7a3b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc7a3b4: mov             fp, SP
    // 0xc7a3b8: AllocStack(0x78)
    //     0xc7a3b8: sub             SP, SP, #0x78
    // 0xc7a3bc: SetupParameters(MethodChannelCamera this /* r1, fp-0x78 */, dynamic _ /* r2, fp-0x70 */, dynamic _ /* r3, fp-0x68 */, dynamic _ /* r4, fp-0x60 */)
    //     0xc7a3bc: stur            NULL, [fp, #-8]
    //     0xc7a3c0: mov             x0, #0
    //     0xc7a3c4: add             x1, fp, w0, sxtw #2
    //     0xc7a3c8: ldr             x1, [x1, #0x28]
    //     0xc7a3cc: stur            x1, [fp, #-0x78]
    //     0xc7a3d0: add             x2, fp, w0, sxtw #2
    //     0xc7a3d4: ldr             x2, [x2, #0x20]
    //     0xc7a3d8: stur            x2, [fp, #-0x70]
    //     0xc7a3dc: add             x3, fp, w0, sxtw #2
    //     0xc7a3e0: ldr             x3, [x3, #0x18]
    //     0xc7a3e4: stur            x3, [fp, #-0x68]
    //     0xc7a3e8: add             x4, fp, w0, sxtw #2
    //     0xc7a3ec: ldr             x4, [x4, #0x10]
    //     0xc7a3f0: stur            x4, [fp, #-0x60]
    // 0xc7a3f4: CheckStackOverflow
    //     0xc7a3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7a3f8: cmp             SP, x16
    //     0xc7a3fc: b.ls            #0xc7a614
    // 0xc7a400: InitAsync() -> Future<int>
    //     0xc7a400: ldr             x0, [PP, #0xa38]  ; [pp+0xa38] TypeArguments: <int>
    //     0xc7a404: bl              #0x4b92e4
    // 0xc7a408: ldur            x0, [fp, #-0x70]
    // 0xc7a40c: ldur            x3, [fp, #-0x68]
    // 0xc7a410: r1 = Null
    //     0xc7a410: mov             x1, NULL
    // 0xc7a414: r2 = 12
    //     0xc7a414: mov             x2, #0xc
    // 0xc7a418: r0 = AllocateArray()
    //     0xc7a418: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc7a41c: r17 = "cameraName"
    //     0xc7a41c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53dd8] "cameraName"
    //     0xc7a420: ldr             x17, [x17, #0xdd8]
    // 0xc7a424: StoreField: r0->field_f = r17
    //     0xc7a424: stur            w17, [x0, #0xf]
    // 0xc7a428: ldur            x1, [fp, #-0x70]
    // 0xc7a42c: LoadField: r2 = r1->field_7
    //     0xc7a42c: ldur            w2, [x1, #7]
    // 0xc7a430: DecompressPointer r2
    //     0xc7a430: add             x2, x2, HEAP, lsl #32
    // 0xc7a434: StoreField: r0->field_13 = r2
    //     0xc7a434: stur            w2, [x0, #0x13]
    // 0xc7a438: r17 = "resolutionPreset"
    //     0xc7a438: add             x17, PP, #0x53, lsl #12  ; [pp+0x53de0] "resolutionPreset"
    //     0xc7a43c: ldr             x17, [x17, #0xde0]
    // 0xc7a440: StoreField: r0->field_17 = r17
    //     0xc7a440: stur            w17, [x0, #0x17]
    // 0xc7a444: ldur            x1, [fp, #-0x68]
    // 0xc7a448: r2 = LoadClassIdInstr(r1)
    //     0xc7a448: ldur            x2, [x1, #-1]
    //     0xc7a44c: ubfx            x2, x2, #0xc, #0x14
    // 0xc7a450: lsl             x2, x2, #1
    // 0xc7a454: r17 = 12036
    //     0xc7a454: mov             x17, #0x2f04
    // 0xc7a458: cmp             w2, w17
    // 0xc7a45c: b.ne            #0xc7a4d4
    // 0xc7a460: LoadField: r2 = r1->field_7
    //     0xc7a460: ldur            x2, [x1, #7]
    // 0xc7a464: cmp             x2, #2
    // 0xc7a468: b.gt            #0xc7a4a0
    // 0xc7a46c: cmp             x2, #1
    // 0xc7a470: b.gt            #0xc7a494
    // 0xc7a474: cmp             x2, #0
    // 0xc7a478: b.gt            #0xc7a488
    // 0xc7a47c: r2 = "low"
    //     0xc7a47c: add             x2, PP, #0x53, lsl #12  ; [pp+0x53de8] "low"
    //     0xc7a480: ldr             x2, [x2, #0xde8]
    // 0xc7a484: b               #0xc7a4d8
    // 0xc7a488: r2 = "medium"
    //     0xc7a488: add             x2, PP, #0x3c, lsl #12  ; [pp+0x3c7e0] "medium"
    //     0xc7a48c: ldr             x2, [x2, #0x7e0]
    // 0xc7a490: b               #0xc7a4d8
    // 0xc7a494: r2 = "high"
    //     0xc7a494: add             x2, PP, #0x53, lsl #12  ; [pp+0x53df0] "high"
    //     0xc7a498: ldr             x2, [x2, #0xdf0]
    // 0xc7a49c: b               #0xc7a4d8
    // 0xc7a4a0: cmp             x2, #4
    // 0xc7a4a4: b.gt            #0xc7a4c8
    // 0xc7a4a8: cmp             x2, #3
    // 0xc7a4ac: b.gt            #0xc7a4bc
    // 0xc7a4b0: r2 = "veryHigh"
    //     0xc7a4b0: add             x2, PP, #0x53, lsl #12  ; [pp+0x53df8] "veryHigh"
    //     0xc7a4b4: ldr             x2, [x2, #0xdf8]
    // 0xc7a4b8: b               #0xc7a4d8
    // 0xc7a4bc: r2 = "ultraHigh"
    //     0xc7a4bc: add             x2, PP, #0x53, lsl #12  ; [pp+0x53e00] "ultraHigh"
    //     0xc7a4c0: ldr             x2, [x2, #0xe00]
    // 0xc7a4c4: b               #0xc7a4d8
    // 0xc7a4c8: r2 = "max"
    //     0xc7a4c8: add             x2, PP, #0x14, lsl #12  ; [pp+0x148e0] "max"
    //     0xc7a4cc: ldr             x2, [x2, #0x8e0]
    // 0xc7a4d0: b               #0xc7a4d8
    // 0xc7a4d4: r2 = Null
    //     0xc7a4d4: mov             x2, NULL
    // 0xc7a4d8: ldur            x1, [fp, #-0x60]
    // 0xc7a4dc: StoreField: r0->field_1b = r2
    //     0xc7a4dc: stur            w2, [x0, #0x1b]
    // 0xc7a4e0: r17 = "enableAudio"
    //     0xc7a4e0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53e08] "enableAudio"
    //     0xc7a4e4: ldr             x17, [x17, #0xe08]
    // 0xc7a4e8: StoreField: r0->field_1f = r17
    //     0xc7a4e8: stur            w17, [x0, #0x1f]
    // 0xc7a4ec: StoreField: r0->field_23 = r1
    //     0xc7a4ec: stur            w1, [x0, #0x23]
    // 0xc7a4f0: r16 = <String, dynamic>
    //     0xc7a4f0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7a4f4: stp             x0, x16, [SP, #-0x10]!
    // 0xc7a4f8: r0 = Map._fromLiteral()
    //     0xc7a4f8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc7a4fc: add             SP, SP, #0x10
    // 0xc7a500: r16 = <String, dynamic>
    //     0xc7a500: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0xc7a504: r30 = Instance_MethodChannel
    //     0xc7a504: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc7a508: ldr             lr, [lr, #0x360]
    // 0xc7a50c: stp             lr, x16, [SP, #-0x10]!
    // 0xc7a510: r16 = "create"
    //     0xc7a510: add             x16, PP, #0x36, lsl #12  ; [pp+0x36fe8] "create"
    //     0xc7a514: ldr             x16, [x16, #0xfe8]
    // 0xc7a518: stp             x0, x16, [SP, #-0x10]!
    // 0xc7a51c: r4 = const [0x2, 0x3, 0x3, 0x3, null]
    //     0xc7a51c: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    // 0xc7a520: r0 = invokeMapMethod()
    //     0xc7a520: bl              #0x5a21c4  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeMapMethod
    // 0xc7a524: add             SP, SP, #0x20
    // 0xc7a528: mov             x1, x0
    // 0xc7a52c: stur            x1, [fp, #-0x60]
    // 0xc7a530: r0 = Await()
    //     0xc7a530: bl              #0x4b8e6c  ; AwaitStub
    // 0xc7a534: cmp             w0, NULL
    // 0xc7a538: b.eq            #0xc7a61c
    // 0xc7a53c: r1 = LoadClassIdInstr(r0)
    //     0xc7a53c: ldur            x1, [x0, #-1]
    //     0xc7a540: ubfx            x1, x1, #0xc, #0x14
    // 0xc7a544: r16 = "cameraId"
    //     0xc7a544: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc7a548: ldr             x16, [x16, #0x890]
    // 0xc7a54c: stp             x16, x0, [SP, #-0x10]!
    // 0xc7a550: mov             x0, x1
    // 0xc7a554: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7a554: sub             lr, x0, #0xef
    //     0xc7a558: ldr             lr, [x21, lr, lsl #3]
    //     0xc7a55c: blr             lr
    // 0xc7a560: add             SP, SP, #0x10
    // 0xc7a564: mov             x3, x0
    // 0xc7a568: stur            x3, [fp, #-0x60]
    // 0xc7a56c: cmp             w3, NULL
    // 0xc7a570: b.eq            #0xc7a620
    // 0xc7a574: r3 as int
    //     0xc7a574: mov             x0, x3
    //     0xc7a578: mov             x2, NULL
    //     0xc7a57c: mov             x1, NULL
    //     0xc7a580: tbz             w0, #0, #0xc7a5a8
    //     0xc7a584: ldur            x4, [x0, #-1]
    //     0xc7a588: ubfx            x4, x4, #0xc, #0x14
    //     0xc7a58c: sub             x4, x4, #0x3b
    //     0xc7a590: cmp             x4, #1
    //     0xc7a594: b.ls            #0xc7a5a8
    //     0xc7a598: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc7a59c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53e10] Null
    //     0xc7a5a0: ldr             x3, [x3, #0xe10]
    //     0xc7a5a4: bl              #0xd73714
    // 0xc7a5a8: ldur            x0, [fp, #-0x60]
    // 0xc7a5ac: r0 = ReturnAsyncNotFuture()
    //     0xc7a5ac: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc7a5b0: sub             SP, fp, #0x78
    // 0xc7a5b4: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc7a5b4: mov             x2, #0x76
    //     0xc7a5b8: tbz             w0, #0, #0xc7a5c8
    //     0xc7a5bc: ldur            x2, [x0, #-1]
    //     0xc7a5c0: ubfx            x2, x2, #0xc, #0x14
    //     0xc7a5c4: lsl             x2, x2, #1
    // 0xc7a5c8: cmp             w2, #0xf28
    // 0xc7a5cc: b.ne            #0xc7a60c
    // 0xc7a5d0: LoadField: r1 = r0->field_7
    //     0xc7a5d0: ldur            w1, [x0, #7]
    // 0xc7a5d4: DecompressPointer r1
    //     0xc7a5d4: add             x1, x1, HEAP, lsl #32
    // 0xc7a5d8: stur            x1, [fp, #-0x68]
    // 0xc7a5dc: LoadField: r2 = r0->field_b
    //     0xc7a5dc: ldur            w2, [x0, #0xb]
    // 0xc7a5e0: DecompressPointer r2
    //     0xc7a5e0: add             x2, x2, HEAP, lsl #32
    // 0xc7a5e4: stur            x2, [fp, #-0x60]
    // 0xc7a5e8: r0 = CameraException()
    //     0xc7a5e8: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc7a5ec: mov             x1, x0
    // 0xc7a5f0: ldur            x0, [fp, #-0x68]
    // 0xc7a5f4: StoreField: r1->field_7 = r0
    //     0xc7a5f4: stur            w0, [x1, #7]
    // 0xc7a5f8: ldur            x0, [fp, #-0x60]
    // 0xc7a5fc: StoreField: r1->field_b = r0
    //     0xc7a5fc: stur            w0, [x1, #0xb]
    // 0xc7a600: mov             x0, x1
    // 0xc7a604: r0 = Throw()
    //     0xc7a604: bl              #0xd67e38  ; ThrowStub
    // 0xc7a608: brk             #0
    // 0xc7a60c: r0 = ReThrow()
    //     0xc7a60c: bl              #0xd67e14  ; ReThrowStub
    // 0xc7a610: brk             #0
    // 0xc7a614: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7a614: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7a618: b               #0xc7a400
    // 0xc7a61c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a61c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7a620: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7a620: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ availableCameras(/* No info */) async {
    // ** addr: 0xc7ba18, size: 0x178
    // 0xc7ba18: EnterFrame
    //     0xc7ba18: stp             fp, lr, [SP, #-0x10]!
    //     0xc7ba1c: mov             fp, SP
    // 0xc7ba20: AllocStack(0x50)
    //     0xc7ba20: sub             SP, SP, #0x50
    // 0xc7ba24: SetupParameters(MethodChannelCamera this /* r1, fp-0x48 */)
    //     0xc7ba24: stur            NULL, [fp, #-8]
    //     0xc7ba28: mov             x0, #0
    //     0xc7ba2c: add             x1, fp, w0, sxtw #2
    //     0xc7ba30: ldr             x1, [x1, #0x10]
    //     0xc7ba34: stur            x1, [fp, #-0x48]
    // 0xc7ba38: CheckStackOverflow
    //     0xc7ba38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7ba3c: cmp             SP, x16
    //     0xc7ba40: b.ls            #0xc7bb88
    // 0xc7ba44: InitAsync() -> Future<List<CameraDescription>>
    //     0xc7ba44: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d590] TypeArguments: <List<CameraDescription>>
    //     0xc7ba48: ldr             x0, [x0, #0x590]
    //     0xc7ba4c: bl              #0x4b92e4
    // 0xc7ba50: r16 = <Map>
    //     0xc7ba50: add             x16, PP, #0x14, lsl #12  ; [pp+0x14cb0] TypeArguments: <Map>
    //     0xc7ba54: ldr             x16, [x16, #0xcb0]
    // 0xc7ba58: r30 = Instance_MethodChannel
    //     0xc7ba58: add             lr, PP, #0x4d, lsl #12  ; [pp+0x4d360] Obj!MethodChannel@b34bb1
    //     0xc7ba5c: ldr             lr, [lr, #0x360]
    // 0xc7ba60: stp             lr, x16, [SP, #-0x10]!
    // 0xc7ba64: r16 = "availableCameras"
    //     0xc7ba64: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e20] "availableCameras"
    //     0xc7ba68: ldr             x16, [x16, #0xe20]
    // 0xc7ba6c: SaveReg r16
    //     0xc7ba6c: str             x16, [SP, #-8]!
    // 0xc7ba70: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7ba70: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7ba74: r0 = invokeListMethod()
    //     0xc7ba74: bl              #0x799418  ; [package:flutter/src/services/platform_channel.dart] MethodChannel::invokeListMethod
    // 0xc7ba78: add             SP, SP, #0x18
    // 0xc7ba7c: mov             x1, x0
    // 0xc7ba80: stur            x1, [fp, #-0x48]
    // 0xc7ba84: r0 = Await()
    //     0xc7ba84: bl              #0x4b8e6c  ; AwaitStub
    // 0xc7ba88: stur            x0, [fp, #-0x48]
    // 0xc7ba8c: cmp             w0, NULL
    // 0xc7ba90: b.ne            #0xc7baac
    // 0xc7ba94: r16 = <CameraDescription>
    //     0xc7ba94: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e28] TypeArguments: <CameraDescription>
    //     0xc7ba98: ldr             x16, [x16, #0xe28]
    // 0xc7ba9c: stp             xzr, x16, [SP, #-0x10]!
    // 0xc7baa0: r0 = _GrowableList()
    //     0xc7baa0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0xc7baa4: add             SP, SP, #0x10
    // 0xc7baa8: r0 = ReturnAsyncNotFuture()
    //     0xc7baa8: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0xc7baac: r1 = Function '<anonymous closure>':.
    //     0xc7baac: add             x1, PP, #0x53, lsl #12  ; [pp+0x53e30] AnonymousClosure: (0xc7bb90), in [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::availableCameras (0xc7ba18)
    //     0xc7bab0: ldr             x1, [x1, #0xe30]
    // 0xc7bab4: r2 = Null
    //     0xc7bab4: mov             x2, NULL
    // 0xc7bab8: r0 = AllocateClosure()
    //     0xc7bab8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc7babc: mov             x1, x0
    // 0xc7bac0: ldur            x0, [fp, #-0x48]
    // 0xc7bac4: r2 = LoadClassIdInstr(r0)
    //     0xc7bac4: ldur            x2, [x0, #-1]
    //     0xc7bac8: ubfx            x2, x2, #0xc, #0x14
    // 0xc7bacc: r16 = <CameraDescription>
    //     0xc7bacc: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e28] TypeArguments: <CameraDescription>
    //     0xc7bad0: ldr             x16, [x16, #0xe28]
    // 0xc7bad4: stp             x0, x16, [SP, #-0x10]!
    // 0xc7bad8: SaveReg r1
    //     0xc7bad8: str             x1, [SP, #-8]!
    // 0xc7badc: mov             x0, x2
    // 0xc7bae0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc7bae0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc7bae4: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc7bae4: mov             x17, #0xc934
    //     0xc7bae8: add             lr, x0, x17
    //     0xc7baec: ldr             lr, [x21, lr, lsl #3]
    //     0xc7baf0: blr             lr
    // 0xc7baf4: add             SP, SP, #0x18
    // 0xc7baf8: r1 = LoadClassIdInstr(r0)
    //     0xc7baf8: ldur            x1, [x0, #-1]
    //     0xc7bafc: ubfx            x1, x1, #0xc, #0x14
    // 0xc7bb00: SaveReg r0
    //     0xc7bb00: str             x0, [SP, #-8]!
    // 0xc7bb04: mov             x0, x1
    // 0xc7bb08: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xc7bb08: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xc7bb0c: r0 = GDT[cid_x0 + 0xc8a1]()
    //     0xc7bb0c: mov             x17, #0xc8a1
    //     0xc7bb10: add             lr, x0, x17
    //     0xc7bb14: ldr             lr, [x21, lr, lsl #3]
    //     0xc7bb18: blr             lr
    // 0xc7bb1c: add             SP, SP, #8
    // 0xc7bb20: r0 = ReturnAsync()
    //     0xc7bb20: b               #0x501858  ; ReturnAsyncStub
    // 0xc7bb24: sub             SP, fp, #0x50
    // 0xc7bb28: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc7bb28: mov             x2, #0x76
    //     0xc7bb2c: tbz             w0, #0, #0xc7bb3c
    //     0xc7bb30: ldur            x2, [x0, #-1]
    //     0xc7bb34: ubfx            x2, x2, #0xc, #0x14
    //     0xc7bb38: lsl             x2, x2, #1
    // 0xc7bb3c: cmp             w2, #0xf28
    // 0xc7bb40: b.ne            #0xc7bb80
    // 0xc7bb44: LoadField: r1 = r0->field_7
    //     0xc7bb44: ldur            w1, [x0, #7]
    // 0xc7bb48: DecompressPointer r1
    //     0xc7bb48: add             x1, x1, HEAP, lsl #32
    // 0xc7bb4c: stur            x1, [fp, #-0x50]
    // 0xc7bb50: LoadField: r2 = r0->field_b
    //     0xc7bb50: ldur            w2, [x0, #0xb]
    // 0xc7bb54: DecompressPointer r2
    //     0xc7bb54: add             x2, x2, HEAP, lsl #32
    // 0xc7bb58: stur            x2, [fp, #-0x48]
    // 0xc7bb5c: r0 = CameraException()
    //     0xc7bb5c: bl              #0x5a80ec  ; AllocateCameraExceptionStub -> CameraException (size=0x10)
    // 0xc7bb60: mov             x1, x0
    // 0xc7bb64: ldur            x0, [fp, #-0x50]
    // 0xc7bb68: StoreField: r1->field_7 = r0
    //     0xc7bb68: stur            w0, [x1, #7]
    // 0xc7bb6c: ldur            x0, [fp, #-0x48]
    // 0xc7bb70: StoreField: r1->field_b = r0
    //     0xc7bb70: stur            w0, [x1, #0xb]
    // 0xc7bb74: mov             x0, x1
    // 0xc7bb78: r0 = Throw()
    //     0xc7bb78: bl              #0xd67e38  ; ThrowStub
    // 0xc7bb7c: brk             #0
    // 0xc7bb80: r0 = ReThrow()
    //     0xc7bb80: bl              #0xd67e14  ; ReThrowStub
    // 0xc7bb84: brk             #0
    // 0xc7bb88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7bb88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7bb8c: b               #0xc7ba44
  }
  [closure] CameraDescription <anonymous closure>(dynamic, Map<dynamic, dynamic>) {
    // ** addr: 0xc7bb90, size: 0x1c4
    // 0xc7bb90: EnterFrame
    //     0xc7bb90: stp             fp, lr, [SP, #-0x10]!
    //     0xc7bb94: mov             fp, SP
    // 0xc7bb98: AllocStack(0x18)
    //     0xc7bb98: sub             SP, SP, #0x18
    // 0xc7bb9c: CheckStackOverflow
    //     0xc7bb9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc7bba0: cmp             SP, x16
    //     0xc7bba4: b.ls            #0xc7bd40
    // 0xc7bba8: ldr             x1, [fp, #0x10]
    // 0xc7bbac: r0 = LoadClassIdInstr(r1)
    //     0xc7bbac: ldur            x0, [x1, #-1]
    //     0xc7bbb0: ubfx            x0, x0, #0xc, #0x14
    // 0xc7bbb4: r16 = "name"
    //     0xc7bbb4: ldr             x16, [PP, #0x510]  ; [pp+0x510] "name"
    // 0xc7bbb8: stp             x16, x1, [SP, #-0x10]!
    // 0xc7bbbc: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7bbbc: sub             lr, x0, #0xef
    //     0xc7bbc0: ldr             lr, [x21, lr, lsl #3]
    //     0xc7bbc4: blr             lr
    // 0xc7bbc8: add             SP, SP, #0x10
    // 0xc7bbcc: mov             x3, x0
    // 0xc7bbd0: stur            x3, [fp, #-8]
    // 0xc7bbd4: cmp             w3, NULL
    // 0xc7bbd8: b.eq            #0xc7bd48
    // 0xc7bbdc: mov             x0, x3
    // 0xc7bbe0: r2 = Null
    //     0xc7bbe0: mov             x2, NULL
    // 0xc7bbe4: r1 = Null
    //     0xc7bbe4: mov             x1, NULL
    // 0xc7bbe8: r4 = 59
    //     0xc7bbe8: mov             x4, #0x3b
    // 0xc7bbec: branchIfSmi(r0, 0xc7bbf8)
    //     0xc7bbec: tbz             w0, #0, #0xc7bbf8
    // 0xc7bbf0: r4 = LoadClassIdInstr(r0)
    //     0xc7bbf0: ldur            x4, [x0, #-1]
    //     0xc7bbf4: ubfx            x4, x4, #0xc, #0x14
    // 0xc7bbf8: sub             x4, x4, #0x5d
    // 0xc7bbfc: cmp             x4, #3
    // 0xc7bc00: b.ls            #0xc7bc14
    // 0xc7bc04: r8 = String
    //     0xc7bc04: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7bc08: r3 = Null
    //     0xc7bc08: add             x3, PP, #0x53, lsl #12  ; [pp+0x53e38] Null
    //     0xc7bc0c: ldr             x3, [x3, #0xe38]
    // 0xc7bc10: r0 = String()
    //     0xc7bc10: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc7bc14: ldr             x1, [fp, #0x10]
    // 0xc7bc18: r0 = LoadClassIdInstr(r1)
    //     0xc7bc18: ldur            x0, [x1, #-1]
    //     0xc7bc1c: ubfx            x0, x0, #0xc, #0x14
    // 0xc7bc20: r16 = "lensFacing"
    //     0xc7bc20: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e48] "lensFacing"
    //     0xc7bc24: ldr             x16, [x16, #0xe48]
    // 0xc7bc28: stp             x16, x1, [SP, #-0x10]!
    // 0xc7bc2c: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7bc2c: sub             lr, x0, #0xef
    //     0xc7bc30: ldr             lr, [x21, lr, lsl #3]
    //     0xc7bc34: blr             lr
    // 0xc7bc38: add             SP, SP, #0x10
    // 0xc7bc3c: mov             x3, x0
    // 0xc7bc40: stur            x3, [fp, #-0x10]
    // 0xc7bc44: cmp             w3, NULL
    // 0xc7bc48: b.eq            #0xc7bd4c
    // 0xc7bc4c: mov             x0, x3
    // 0xc7bc50: r2 = Null
    //     0xc7bc50: mov             x2, NULL
    // 0xc7bc54: r1 = Null
    //     0xc7bc54: mov             x1, NULL
    // 0xc7bc58: r4 = 59
    //     0xc7bc58: mov             x4, #0x3b
    // 0xc7bc5c: branchIfSmi(r0, 0xc7bc68)
    //     0xc7bc5c: tbz             w0, #0, #0xc7bc68
    // 0xc7bc60: r4 = LoadClassIdInstr(r0)
    //     0xc7bc60: ldur            x4, [x0, #-1]
    //     0xc7bc64: ubfx            x4, x4, #0xc, #0x14
    // 0xc7bc68: sub             x4, x4, #0x5d
    // 0xc7bc6c: cmp             x4, #3
    // 0xc7bc70: b.ls            #0xc7bc84
    // 0xc7bc74: r8 = String
    //     0xc7bc74: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0xc7bc78: r3 = Null
    //     0xc7bc78: add             x3, PP, #0x53, lsl #12  ; [pp+0x53e50] Null
    //     0xc7bc7c: ldr             x3, [x3, #0xe50]
    // 0xc7bc80: r0 = String()
    //     0xc7bc80: bl              #0xd72afc  ; IsType_String_Stub
    // 0xc7bc84: ldur            x16, [fp, #-0x10]
    // 0xc7bc88: SaveReg r16
    //     0xc7bc88: str             x16, [SP, #-8]!
    // 0xc7bc8c: r0 = parseCameraLensDirection()
    //     0xc7bc8c: bl              #0xc7b608  ; [package:camera_android/src/utils.dart] ::parseCameraLensDirection
    // 0xc7bc90: add             SP, SP, #8
    // 0xc7bc94: mov             x1, x0
    // 0xc7bc98: ldr             x0, [fp, #0x10]
    // 0xc7bc9c: stur            x1, [fp, #-0x10]
    // 0xc7bca0: r2 = LoadClassIdInstr(r0)
    //     0xc7bca0: ldur            x2, [x0, #-1]
    //     0xc7bca4: ubfx            x2, x2, #0xc, #0x14
    // 0xc7bca8: r16 = "sensorOrientation"
    //     0xc7bca8: add             x16, PP, #0x53, lsl #12  ; [pp+0x53e60] "sensorOrientation"
    //     0xc7bcac: ldr             x16, [x16, #0xe60]
    // 0xc7bcb0: stp             x16, x0, [SP, #-0x10]!
    // 0xc7bcb4: mov             x0, x2
    // 0xc7bcb8: r0 = GDT[cid_x0 + -0xef]()
    //     0xc7bcb8: sub             lr, x0, #0xef
    //     0xc7bcbc: ldr             lr, [x21, lr, lsl #3]
    //     0xc7bcc0: blr             lr
    // 0xc7bcc4: add             SP, SP, #0x10
    // 0xc7bcc8: mov             x3, x0
    // 0xc7bccc: stur            x3, [fp, #-0x18]
    // 0xc7bcd0: cmp             w3, NULL
    // 0xc7bcd4: b.eq            #0xc7bd50
    // 0xc7bcd8: r3 as int
    //     0xc7bcd8: mov             x0, x3
    //     0xc7bcdc: mov             x2, NULL
    //     0xc7bce0: mov             x1, NULL
    //     0xc7bce4: tbz             w0, #0, #0xc7bd0c
    //     0xc7bce8: ldur            x4, [x0, #-1]
    //     0xc7bcec: ubfx            x4, x4, #0xc, #0x14
    //     0xc7bcf0: sub             x4, x4, #0x3b
    //     0xc7bcf4: cmp             x4, #1
    //     0xc7bcf8: b.ls            #0xc7bd0c
    //     0xc7bcfc: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    //     0xc7bd00: add             x3, PP, #0x53, lsl #12  ; [pp+0x53e68] Null
    //     0xc7bd04: ldr             x3, [x3, #0xe68]
    //     0xc7bd08: bl              #0xd73714
    // 0xc7bd0c: r0 = CameraDescription()
    //     0xc7bd0c: bl              #0xc7b5fc  ; AllocateCameraDescriptionStub -> CameraDescription (size=0x18)
    // 0xc7bd10: ldur            x1, [fp, #-8]
    // 0xc7bd14: StoreField: r0->field_7 = r1
    //     0xc7bd14: stur            w1, [x0, #7]
    // 0xc7bd18: ldur            x1, [fp, #-0x10]
    // 0xc7bd1c: StoreField: r0->field_b = r1
    //     0xc7bd1c: stur            w1, [x0, #0xb]
    // 0xc7bd20: ldur            x1, [fp, #-0x18]
    // 0xc7bd24: r2 = LoadInt32Instr(r1)
    //     0xc7bd24: sbfx            x2, x1, #1, #0x1f
    //     0xc7bd28: tbz             w1, #0, #0xc7bd30
    //     0xc7bd2c: ldur            x2, [x1, #7]
    // 0xc7bd30: StoreField: r0->field_f = r2
    //     0xc7bd30: stur            x2, [x0, #0xf]
    // 0xc7bd34: LeaveFrame
    //     0xc7bd34: mov             SP, fp
    //     0xc7bd38: ldp             fp, lr, [SP], #0x10
    // 0xc7bd3c: ret
    //     0xc7bd3c: ret             
    // 0xc7bd40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc7bd40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7bd44: b               #0xc7bba8
    // 0xc7bd48: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7bd48: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7bd4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7bd4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc7bd50: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc7bd50: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:camera_platform_interface/src/method_channel/type_conversion.dart

// class id: 1048716, size: 0x8
class :: {

  static _ cameraImageFromPlatformData(/* No info */) {
    // ** addr: 0xc6c6a4, size: 0x38c
    // 0xc6c6a4: EnterFrame
    //     0xc6c6a4: stp             fp, lr, [SP, #-0x10]!
    //     0xc6c6a8: mov             fp, SP
    // 0xc6c6ac: AllocStack(0x38)
    //     0xc6c6ac: sub             SP, SP, #0x38
    // 0xc6c6b0: CheckStackOverflow
    //     0xc6c6b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6c6b4: cmp             SP, x16
    //     0xc6c6b8: b.ls            #0xc6ca28
    // 0xc6c6bc: ldr             x1, [fp, #0x10]
    // 0xc6c6c0: r0 = LoadClassIdInstr(r1)
    //     0xc6c6c0: ldur            x0, [x1, #-1]
    //     0xc6c6c4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c6c8: r16 = "format"
    //     0xc6c6c8: add             x16, PP, #0x25, lsl #12  ; [pp+0x25d08] "format"
    //     0xc6c6cc: ldr             x16, [x16, #0xd08]
    // 0xc6c6d0: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c6d4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c6d4: sub             lr, x0, #0xef
    //     0xc6c6d8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c6dc: blr             lr
    // 0xc6c6e0: add             SP, SP, #0x10
    // 0xc6c6e4: SaveReg r0
    //     0xc6c6e4: str             x0, [SP, #-8]!
    // 0xc6c6e8: r0 = _cameraImageFormatFromPlatformData()
    //     0xc6c6e8: bl              #0xc6ca30  ; [package:camera_platform_interface/src/method_channel/type_conversion.dart] ::_cameraImageFormatFromPlatformData
    // 0xc6c6ec: add             SP, SP, #8
    // 0xc6c6f0: mov             x2, x0
    // 0xc6c6f4: ldr             x1, [fp, #0x10]
    // 0xc6c6f8: stur            x2, [fp, #-8]
    // 0xc6c6fc: r0 = LoadClassIdInstr(r1)
    //     0xc6c6fc: ldur            x0, [x1, #-1]
    //     0xc6c700: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c704: r16 = "height"
    //     0xc6c704: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0xc6c708: ldr             x16, [x16, #0xb08]
    // 0xc6c70c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c710: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c710: sub             lr, x0, #0xef
    //     0xc6c714: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c718: blr             lr
    // 0xc6c71c: add             SP, SP, #0x10
    // 0xc6c720: mov             x3, x0
    // 0xc6c724: r2 = Null
    //     0xc6c724: mov             x2, NULL
    // 0xc6c728: r1 = Null
    //     0xc6c728: mov             x1, NULL
    // 0xc6c72c: stur            x3, [fp, #-0x10]
    // 0xc6c730: branchIfSmi(r0, 0xc6c758)
    //     0xc6c730: tbz             w0, #0, #0xc6c758
    // 0xc6c734: r4 = LoadClassIdInstr(r0)
    //     0xc6c734: ldur            x4, [x0, #-1]
    //     0xc6c738: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c73c: sub             x4, x4, #0x3b
    // 0xc6c740: cmp             x4, #1
    // 0xc6c744: b.ls            #0xc6c758
    // 0xc6c748: r8 = int
    //     0xc6c748: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6c74c: r3 = Null
    //     0xc6c74c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53b48] Null
    //     0xc6c750: ldr             x3, [x3, #0xb48]
    // 0xc6c754: r0 = int()
    //     0xc6c754: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6c758: ldr             x1, [fp, #0x10]
    // 0xc6c75c: r0 = LoadClassIdInstr(r1)
    //     0xc6c75c: ldur            x0, [x1, #-1]
    //     0xc6c760: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c764: r16 = "width"
    //     0xc6c764: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0xc6c768: ldr             x16, [x16, #0xb30]
    // 0xc6c76c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c770: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c770: sub             lr, x0, #0xef
    //     0xc6c774: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c778: blr             lr
    // 0xc6c77c: add             SP, SP, #0x10
    // 0xc6c780: mov             x3, x0
    // 0xc6c784: r2 = Null
    //     0xc6c784: mov             x2, NULL
    // 0xc6c788: r1 = Null
    //     0xc6c788: mov             x1, NULL
    // 0xc6c78c: stur            x3, [fp, #-0x18]
    // 0xc6c790: branchIfSmi(r0, 0xc6c7b8)
    //     0xc6c790: tbz             w0, #0, #0xc6c7b8
    // 0xc6c794: r4 = LoadClassIdInstr(r0)
    //     0xc6c794: ldur            x4, [x0, #-1]
    //     0xc6c798: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c79c: sub             x4, x4, #0x3b
    // 0xc6c7a0: cmp             x4, #1
    // 0xc6c7a4: b.ls            #0xc6c7b8
    // 0xc6c7a8: r8 = int
    //     0xc6c7a8: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6c7ac: r3 = Null
    //     0xc6c7ac: add             x3, PP, #0x53, lsl #12  ; [pp+0x53b58] Null
    //     0xc6c7b0: ldr             x3, [x3, #0xb58]
    // 0xc6c7b4: r0 = int()
    //     0xc6c7b4: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6c7b8: ldr             x1, [fp, #0x10]
    // 0xc6c7bc: r0 = LoadClassIdInstr(r1)
    //     0xc6c7bc: ldur            x0, [x1, #-1]
    //     0xc6c7c0: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c7c4: r16 = "lensAperture"
    //     0xc6c7c4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b68] "lensAperture"
    //     0xc6c7c8: ldr             x16, [x16, #0xb68]
    // 0xc6c7cc: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c7d0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c7d0: sub             lr, x0, #0xef
    //     0xc6c7d4: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c7d8: blr             lr
    // 0xc6c7dc: add             SP, SP, #0x10
    // 0xc6c7e0: mov             x3, x0
    // 0xc6c7e4: r2 = Null
    //     0xc6c7e4: mov             x2, NULL
    // 0xc6c7e8: r1 = Null
    //     0xc6c7e8: mov             x1, NULL
    // 0xc6c7ec: stur            x3, [fp, #-0x20]
    // 0xc6c7f0: r4 = 59
    //     0xc6c7f0: mov             x4, #0x3b
    // 0xc6c7f4: branchIfSmi(r0, 0xc6c800)
    //     0xc6c7f4: tbz             w0, #0, #0xc6c800
    // 0xc6c7f8: r4 = LoadClassIdInstr(r0)
    //     0xc6c7f8: ldur            x4, [x0, #-1]
    //     0xc6c7fc: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c800: cmp             x4, #0x3d
    // 0xc6c804: b.eq            #0xc6c818
    // 0xc6c808: r8 = double?
    //     0xc6c808: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc6c80c: r3 = Null
    //     0xc6c80c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53b70] Null
    //     0xc6c810: ldr             x3, [x3, #0xb70]
    // 0xc6c814: r0 = double?()
    //     0xc6c814: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc6c818: ldr             x1, [fp, #0x10]
    // 0xc6c81c: r0 = LoadClassIdInstr(r1)
    //     0xc6c81c: ldur            x0, [x1, #-1]
    //     0xc6c820: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c824: r16 = "sensorExposureTime"
    //     0xc6c824: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b80] "sensorExposureTime"
    //     0xc6c828: ldr             x16, [x16, #0xb80]
    // 0xc6c82c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c830: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c830: sub             lr, x0, #0xef
    //     0xc6c834: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c838: blr             lr
    // 0xc6c83c: add             SP, SP, #0x10
    // 0xc6c840: mov             x3, x0
    // 0xc6c844: r2 = Null
    //     0xc6c844: mov             x2, NULL
    // 0xc6c848: r1 = Null
    //     0xc6c848: mov             x1, NULL
    // 0xc6c84c: stur            x3, [fp, #-0x28]
    // 0xc6c850: branchIfSmi(r0, 0xc6c878)
    //     0xc6c850: tbz             w0, #0, #0xc6c878
    // 0xc6c854: r4 = LoadClassIdInstr(r0)
    //     0xc6c854: ldur            x4, [x0, #-1]
    //     0xc6c858: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c85c: sub             x4, x4, #0x3b
    // 0xc6c860: cmp             x4, #1
    // 0xc6c864: b.ls            #0xc6c878
    // 0xc6c868: r8 = int?
    //     0xc6c868: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6c86c: r3 = Null
    //     0xc6c86c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53b88] Null
    //     0xc6c870: ldr             x3, [x3, #0xb88]
    // 0xc6c874: r0 = int?()
    //     0xc6c874: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6c878: ldr             x1, [fp, #0x10]
    // 0xc6c87c: r0 = LoadClassIdInstr(r1)
    //     0xc6c87c: ldur            x0, [x1, #-1]
    //     0xc6c880: ubfx            x0, x0, #0xc, #0x14
    // 0xc6c884: r16 = "sensorSensitivity"
    //     0xc6c884: add             x16, PP, #0x53, lsl #12  ; [pp+0x53b98] "sensorSensitivity"
    //     0xc6c888: ldr             x16, [x16, #0xb98]
    // 0xc6c88c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6c890: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c890: sub             lr, x0, #0xef
    //     0xc6c894: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c898: blr             lr
    // 0xc6c89c: add             SP, SP, #0x10
    // 0xc6c8a0: mov             x3, x0
    // 0xc6c8a4: r2 = Null
    //     0xc6c8a4: mov             x2, NULL
    // 0xc6c8a8: r1 = Null
    //     0xc6c8a8: mov             x1, NULL
    // 0xc6c8ac: stur            x3, [fp, #-0x30]
    // 0xc6c8b0: r4 = 59
    //     0xc6c8b0: mov             x4, #0x3b
    // 0xc6c8b4: branchIfSmi(r0, 0xc6c8c0)
    //     0xc6c8b4: tbz             w0, #0, #0xc6c8c0
    // 0xc6c8b8: r4 = LoadClassIdInstr(r0)
    //     0xc6c8b8: ldur            x4, [x0, #-1]
    //     0xc6c8bc: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c8c0: cmp             x4, #0x3d
    // 0xc6c8c4: b.eq            #0xc6c8d8
    // 0xc6c8c8: r8 = double?
    //     0xc6c8c8: ldr             x8, [PP, #0x21e0]  ; [pp+0x21e0] Type: double?
    // 0xc6c8cc: r3 = Null
    //     0xc6c8cc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53ba0] Null
    //     0xc6c8d0: ldr             x3, [x3, #0xba0]
    // 0xc6c8d4: r0 = double?()
    //     0xc6c8d4: bl              #0xd72b80  ; IsType_double?_Stub
    // 0xc6c8d8: ldr             x0, [fp, #0x10]
    // 0xc6c8dc: r1 = LoadClassIdInstr(r0)
    //     0xc6c8dc: ldur            x1, [x0, #-1]
    //     0xc6c8e0: ubfx            x1, x1, #0xc, #0x14
    // 0xc6c8e4: r16 = "planes"
    //     0xc6c8e4: add             x16, PP, #0x42, lsl #12  ; [pp+0x42f30] "planes"
    //     0xc6c8e8: ldr             x16, [x16, #0xf30]
    // 0xc6c8ec: stp             x16, x0, [SP, #-0x10]!
    // 0xc6c8f0: mov             x0, x1
    // 0xc6c8f4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6c8f4: sub             lr, x0, #0xef
    //     0xc6c8f8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c8fc: blr             lr
    // 0xc6c900: add             SP, SP, #0x10
    // 0xc6c904: mov             x3, x0
    // 0xc6c908: r2 = Null
    //     0xc6c908: mov             x2, NULL
    // 0xc6c90c: r1 = Null
    //     0xc6c90c: mov             x1, NULL
    // 0xc6c910: stur            x3, [fp, #-0x38]
    // 0xc6c914: r4 = 59
    //     0xc6c914: mov             x4, #0x3b
    // 0xc6c918: branchIfSmi(r0, 0xc6c924)
    //     0xc6c918: tbz             w0, #0, #0xc6c924
    // 0xc6c91c: r4 = LoadClassIdInstr(r0)
    //     0xc6c91c: ldur            x4, [x0, #-1]
    //     0xc6c920: ubfx            x4, x4, #0xc, #0x14
    // 0xc6c924: sub             x4, x4, #0x59
    // 0xc6c928: cmp             x4, #2
    // 0xc6c92c: b.ls            #0xc6c940
    // 0xc6c930: r8 = List
    //     0xc6c930: ldr             x8, [PP, #0x2248]  ; [pp+0x2248] Type: List
    // 0xc6c934: r3 = Null
    //     0xc6c934: add             x3, PP, #0x53, lsl #12  ; [pp+0x53bb0] Null
    //     0xc6c938: ldr             x3, [x3, #0xbb0]
    // 0xc6c93c: r0 = List()
    //     0xc6c93c: bl              #0xd74840  ; IsType_List_Stub
    // 0xc6c940: r1 = Function '<anonymous closure>': static.
    //     0xc6c940: add             x1, PP, #0x53, lsl #12  ; [pp+0x53bc0] AnonymousClosure: static (0xc6cba4), in [package:camera_platform_interface/src/method_channel/type_conversion.dart] ::cameraImageFromPlatformData (0xc6c6a4)
    //     0xc6c944: ldr             x1, [x1, #0xbc0]
    // 0xc6c948: r2 = Null
    //     0xc6c948: mov             x2, NULL
    // 0xc6c94c: r0 = AllocateClosure()
    //     0xc6c94c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xc6c950: mov             x1, x0
    // 0xc6c954: ldur            x0, [fp, #-0x38]
    // 0xc6c958: r2 = LoadClassIdInstr(r0)
    //     0xc6c958: ldur            x2, [x0, #-1]
    //     0xc6c95c: ubfx            x2, x2, #0xc, #0x14
    // 0xc6c960: r16 = <CameraImagePlane>
    //     0xc6c960: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6c964: ldr             x16, [x16, #0xbc8]
    // 0xc6c968: stp             x0, x16, [SP, #-0x10]!
    // 0xc6c96c: SaveReg r1
    //     0xc6c96c: str             x1, [SP, #-8]!
    // 0xc6c970: mov             x0, x2
    // 0xc6c974: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0xc6c974: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0xc6c978: r0 = GDT[cid_x0 + 0xc934]()
    //     0xc6c978: mov             x17, #0xc934
    //     0xc6c97c: add             lr, x0, x17
    //     0xc6c980: ldr             lr, [x21, lr, lsl #3]
    //     0xc6c984: blr             lr
    // 0xc6c988: add             SP, SP, #0x18
    // 0xc6c98c: r16 = <CameraImagePlane>
    //     0xc6c98c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6c990: ldr             x16, [x16, #0xbc8]
    // 0xc6c994: stp             x0, x16, [SP, #-0x10]!
    // 0xc6c998: r16 = false
    //     0xc6c998: add             x16, NULL, #0x30  ; false
    // 0xc6c99c: SaveReg r16
    //     0xc6c99c: str             x16, [SP, #-8]!
    // 0xc6c9a0: r4 = const [0, 0x3, 0x3, 0x2, growable, 0x2, null]
    //     0xc6c9a0: ldr             x4, [PP, #0xc20]  ; [pp+0xc20] List(7) [0, 0x3, 0x3, 0x2, "growable", 0x2, Null]
    // 0xc6c9a4: r0 = List.from()
    //     0xc6c9a4: bl              #0x4c85f8  ; [dart:core] List::List.from
    // 0xc6c9a8: add             SP, SP, #0x18
    // 0xc6c9ac: r16 = <CameraImagePlane>
    //     0xc6c9ac: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bc8] TypeArguments: <CameraImagePlane>
    //     0xc6c9b0: ldr             x16, [x16, #0xbc8]
    // 0xc6c9b4: stp             x0, x16, [SP, #-0x10]!
    // 0xc6c9b8: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0xc6c9b8: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0xc6c9bc: r0 = makeFixedListUnmodifiable()
    //     0xc6c9bc: bl              #0x5a58e4  ; [dart:_internal] ::makeFixedListUnmodifiable
    // 0xc6c9c0: add             SP, SP, #0x10
    // 0xc6c9c4: stur            x0, [fp, #-0x38]
    // 0xc6c9c8: r0 = CameraImageData()
    //     0xc6c9c8: bl              #0xc6b054  ; AllocateCameraImageDataStub -> CameraImageData (size=0x2c)
    // 0xc6c9cc: ldur            x1, [fp, #-8]
    // 0xc6c9d0: StoreField: r0->field_7 = r1
    //     0xc6c9d0: stur            w1, [x0, #7]
    // 0xc6c9d4: ldur            x1, [fp, #-0x38]
    // 0xc6c9d8: StoreField: r0->field_1b = r1
    //     0xc6c9d8: stur            w1, [x0, #0x1b]
    // 0xc6c9dc: ldur            x1, [fp, #-0x10]
    // 0xc6c9e0: r2 = LoadInt32Instr(r1)
    //     0xc6c9e0: sbfx            x2, x1, #1, #0x1f
    //     0xc6c9e4: tbz             w1, #0, #0xc6c9ec
    //     0xc6c9e8: ldur            x2, [x1, #7]
    // 0xc6c9ec: StoreField: r0->field_b = r2
    //     0xc6c9ec: stur            x2, [x0, #0xb]
    // 0xc6c9f0: ldur            x1, [fp, #-0x18]
    // 0xc6c9f4: r2 = LoadInt32Instr(r1)
    //     0xc6c9f4: sbfx            x2, x1, #1, #0x1f
    //     0xc6c9f8: tbz             w1, #0, #0xc6ca00
    //     0xc6c9fc: ldur            x2, [x1, #7]
    // 0xc6ca00: StoreField: r0->field_13 = r2
    //     0xc6ca00: stur            x2, [x0, #0x13]
    // 0xc6ca04: ldur            x1, [fp, #-0x20]
    // 0xc6ca08: StoreField: r0->field_1f = r1
    //     0xc6ca08: stur            w1, [x0, #0x1f]
    // 0xc6ca0c: ldur            x1, [fp, #-0x28]
    // 0xc6ca10: StoreField: r0->field_23 = r1
    //     0xc6ca10: stur            w1, [x0, #0x23]
    // 0xc6ca14: ldur            x1, [fp, #-0x30]
    // 0xc6ca18: StoreField: r0->field_27 = r1
    //     0xc6ca18: stur            w1, [x0, #0x27]
    // 0xc6ca1c: LeaveFrame
    //     0xc6ca1c: mov             SP, fp
    //     0xc6ca20: ldp             fp, lr, [SP], #0x10
    // 0xc6ca24: ret
    //     0xc6ca24: ret             
    // 0xc6ca28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ca28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ca2c: b               #0xc6c6bc
  }
  static _ _cameraImageFormatFromPlatformData(/* No info */) {
    // ** addr: 0xc6ca30, size: 0x54
    // 0xc6ca30: EnterFrame
    //     0xc6ca30: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ca34: mov             fp, SP
    // 0xc6ca38: AllocStack(0x8)
    //     0xc6ca38: sub             SP, SP, #8
    // 0xc6ca3c: CheckStackOverflow
    //     0xc6ca3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ca40: cmp             SP, x16
    //     0xc6ca44: b.ls            #0xc6ca7c
    // 0xc6ca48: ldr             x16, [fp, #0x10]
    // 0xc6ca4c: SaveReg r16
    //     0xc6ca4c: str             x16, [SP, #-8]!
    // 0xc6ca50: r0 = _imageFormatGroupFromPlatformData()
    //     0xc6ca50: bl              #0xc6ca84  ; [package:camera_platform_interface/src/method_channel/type_conversion.dart] ::_imageFormatGroupFromPlatformData
    // 0xc6ca54: add             SP, SP, #8
    // 0xc6ca58: stur            x0, [fp, #-8]
    // 0xc6ca5c: r0 = CameraImageFormat()
    //     0xc6ca5c: bl              #0xc6b134  ; AllocateCameraImageFormatStub -> CameraImageFormat (size=0x10)
    // 0xc6ca60: ldur            x1, [fp, #-8]
    // 0xc6ca64: StoreField: r0->field_7 = r1
    //     0xc6ca64: stur            w1, [x0, #7]
    // 0xc6ca68: ldr             x1, [fp, #0x10]
    // 0xc6ca6c: StoreField: r0->field_b = r1
    //     0xc6ca6c: stur            w1, [x0, #0xb]
    // 0xc6ca70: LeaveFrame
    //     0xc6ca70: mov             SP, fp
    //     0xc6ca74: ldp             fp, lr, [SP], #0x10
    // 0xc6ca78: ret
    //     0xc6ca78: ret             
    // 0xc6ca7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ca7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ca80: b               #0xc6ca48
  }
  static _ _imageFormatGroupFromPlatformData(/* No info */) {
    // ** addr: 0xc6ca84, size: 0x120
    // 0xc6ca84: EnterFrame
    //     0xc6ca84: stp             fp, lr, [SP, #-0x10]!
    //     0xc6ca88: mov             fp, SP
    // 0xc6ca8c: CheckStackOverflow
    //     0xc6ca8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6ca90: cmp             SP, x16
    //     0xc6ca94: b.ls            #0xc6cb9c
    // 0xc6ca98: r0 = defaultTargetPlatform()
    //     0xc6ca98: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc6ca9c: r16 = Instance_TargetPlatform
    //     0xc6ca9c: ldr             x16, [PP, #0x43a8]  ; [pp+0x43a8] Obj!TargetPlatform@b65d71
    // 0xc6caa0: cmp             w0, w16
    // 0xc6caa4: b.ne            #0xc6cb14
    // 0xc6caa8: ldr             x0, [fp, #0x10]
    // 0xc6caac: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6caac: mov             x1, #0x76
    //     0xc6cab0: tbz             w0, #0, #0xc6cac0
    //     0xc6cab4: ldur            x1, [x0, #-1]
    //     0xc6cab8: ubfx            x1, x1, #0xc, #0x14
    //     0xc6cabc: lsl             x1, x1, #1
    // 0xc6cac0: cmp             w1, #0x76
    // 0xc6cac4: b.ne            #0xc6cb18
    // 0xc6cac8: r1 = LoadInt32Instr(r0)
    //     0xc6cac8: sbfx            x1, x0, #1, #0x1f
    // 0xc6cacc: cmp             x1, #0x23
    // 0xc6cad0: b.gt            #0xc6caf0
    // 0xc6cad4: cmp             w0, #0x46
    // 0xc6cad8: b.ne            #0xc6cb18
    // 0xc6cadc: r0 = Instance_ImageFormatGroup
    //     0xc6cadc: add             x0, PP, #0x53, lsl #12  ; [pp+0x53c48] Obj!ImageFormatGroup@b66a91
    //     0xc6cae0: ldr             x0, [x0, #0xc48]
    // 0xc6cae4: LeaveFrame
    //     0xc6cae4: mov             SP, fp
    //     0xc6cae8: ldp             fp, lr, [SP], #0x10
    // 0xc6caec: ret
    //     0xc6caec: ret             
    // 0xc6caf0: cmp             x1, #0x100
    // 0xc6caf4: b.lt            #0xc6cb18
    // 0xc6caf8: cmp             w0, #0x200
    // 0xc6cafc: b.ne            #0xc6cb18
    // 0xc6cb00: r0 = Instance_ImageFormatGroup
    //     0xc6cb00: add             x0, PP, #0x53, lsl #12  ; [pp+0x53c50] Obj!ImageFormatGroup@b66a71
    //     0xc6cb04: ldr             x0, [x0, #0xc50]
    // 0xc6cb08: LeaveFrame
    //     0xc6cb08: mov             SP, fp
    //     0xc6cb0c: ldp             fp, lr, [SP], #0x10
    // 0xc6cb10: ret
    //     0xc6cb10: ret             
    // 0xc6cb14: ldr             x0, [fp, #0x10]
    // 0xc6cb18: r0 = defaultTargetPlatform()
    //     0xc6cb18: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0xc6cb1c: r16 = Instance_TargetPlatform
    //     0xc6cb1c: ldr             x16, [PP, #0x43b0]  ; [pp+0x43b0] Obj!TargetPlatform@b65d51
    // 0xc6cb20: cmp             w0, w16
    // 0xc6cb24: b.ne            #0xc6cb88
    // 0xc6cb28: r16 = 1751408876
    //     0xc6cb28: mov             x16, #0x60ec
    //     0xc6cb2c: movk            x16, #0x6864, lsl #16
    // 0xc6cb30: ldr             lr, [fp, #0x10]
    // 0xc6cb34: stp             lr, x16, [SP, #-0x10]!
    // 0xc6cb38: r0 = ==()
    //     0xc6cb38: bl              #0xcbbc60  ; [dart:core] _IntegerImplementation::==
    // 0xc6cb3c: add             SP, SP, #0x10
    // 0xc6cb40: tbnz            w0, #4, #0xc6cb58
    // 0xc6cb44: r0 = Instance_ImageFormatGroup
    //     0xc6cb44: add             x0, PP, #0x53, lsl #12  ; [pp+0x53c48] Obj!ImageFormatGroup@b66a91
    //     0xc6cb48: ldr             x0, [x0, #0xc48]
    // 0xc6cb4c: LeaveFrame
    //     0xc6cb4c: mov             SP, fp
    //     0xc6cb50: ldp             fp, lr, [SP], #0x10
    // 0xc6cb54: ret
    //     0xc6cb54: ret             
    // 0xc6cb58: r16 = 1111970369
    //     0xc6cb58: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c58] 0x42475241
    //     0xc6cb5c: ldr             x16, [x16, #0xc58]
    // 0xc6cb60: ldr             lr, [fp, #0x10]
    // 0xc6cb64: stp             lr, x16, [SP, #-0x10]!
    // 0xc6cb68: r0 = ==()
    //     0xc6cb68: bl              #0xcbbc60  ; [dart:core] _IntegerImplementation::==
    // 0xc6cb6c: add             SP, SP, #0x10
    // 0xc6cb70: tbnz            w0, #4, #0xc6cb88
    // 0xc6cb74: r0 = Instance_ImageFormatGroup
    //     0xc6cb74: add             x0, PP, #0x53, lsl #12  ; [pp+0x53c60] Obj!ImageFormatGroup@b66ab1
    //     0xc6cb78: ldr             x0, [x0, #0xc60]
    // 0xc6cb7c: LeaveFrame
    //     0xc6cb7c: mov             SP, fp
    //     0xc6cb80: ldp             fp, lr, [SP], #0x10
    // 0xc6cb84: ret
    //     0xc6cb84: ret             
    // 0xc6cb88: r0 = Instance_ImageFormatGroup
    //     0xc6cb88: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d3b8] Obj!ImageFormatGroup@b66a31
    //     0xc6cb8c: ldr             x0, [x0, #0x3b8]
    // 0xc6cb90: LeaveFrame
    //     0xc6cb90: mov             SP, fp
    //     0xc6cb94: ldp             fp, lr, [SP], #0x10
    // 0xc6cb98: ret
    //     0xc6cb98: ret             
    // 0xc6cb9c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6cb9c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6cba0: b               #0xc6ca98
  }
  [closure] static CameraImagePlane <anonymous closure>(dynamic, dynamic) {
    // ** addr: 0xc6cba4, size: 0x54
    // 0xc6cba4: EnterFrame
    //     0xc6cba4: stp             fp, lr, [SP, #-0x10]!
    //     0xc6cba8: mov             fp, SP
    // 0xc6cbac: CheckStackOverflow
    //     0xc6cbac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6cbb0: cmp             SP, x16
    //     0xc6cbb4: b.ls            #0xc6cbf0
    // 0xc6cbb8: ldr             x0, [fp, #0x10]
    // 0xc6cbbc: r2 = Null
    //     0xc6cbbc: mov             x2, NULL
    // 0xc6cbc0: r1 = Null
    //     0xc6cbc0: mov             x1, NULL
    // 0xc6cbc4: r8 = Map
    //     0xc6cbc4: ldr             x8, [PP, #0x2338]  ; [pp+0x2338] Type: Map
    // 0xc6cbc8: r3 = Null
    //     0xc6cbc8: add             x3, PP, #0x53, lsl #12  ; [pp+0x53bd0] Null
    //     0xc6cbcc: ldr             x3, [x3, #0xbd0]
    // 0xc6cbd0: r0 = Map()
    //     0xc6cbd0: bl              #0xd747e8  ; IsType_Map_Stub
    // 0xc6cbd4: ldr             x16, [fp, #0x10]
    // 0xc6cbd8: SaveReg r16
    //     0xc6cbd8: str             x16, [SP, #-8]!
    // 0xc6cbdc: r0 = _cameraImagePlaneFromPlatformData()
    //     0xc6cbdc: bl              #0xc6cbf8  ; [package:camera_platform_interface/src/method_channel/type_conversion.dart] ::_cameraImagePlaneFromPlatformData
    // 0xc6cbe0: add             SP, SP, #8
    // 0xc6cbe4: LeaveFrame
    //     0xc6cbe4: mov             SP, fp
    //     0xc6cbe8: ldp             fp, lr, [SP], #0x10
    // 0xc6cbec: ret
    //     0xc6cbec: ret             
    // 0xc6cbf0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6cbf0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6cbf4: b               #0xc6cbb8
  }
  static _ _cameraImagePlaneFromPlatformData(/* No info */) {
    // ** addr: 0xc6cbf8, size: 0x250
    // 0xc6cbf8: EnterFrame
    //     0xc6cbf8: stp             fp, lr, [SP, #-0x10]!
    //     0xc6cbfc: mov             fp, SP
    // 0xc6cc00: AllocStack(0x28)
    //     0xc6cc00: sub             SP, SP, #0x28
    // 0xc6cc04: CheckStackOverflow
    //     0xc6cc04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6cc08: cmp             SP, x16
    //     0xc6cc0c: b.ls            #0xc6ce40
    // 0xc6cc10: ldr             x1, [fp, #0x10]
    // 0xc6cc14: r0 = LoadClassIdInstr(r1)
    //     0xc6cc14: ldur            x0, [x1, #-1]
    //     0xc6cc18: ubfx            x0, x0, #0xc, #0x14
    // 0xc6cc1c: r16 = "bytes"
    //     0xc6cc1c: add             x16, PP, #0x53, lsl #12  ; [pp+0x53be0] "bytes"
    //     0xc6cc20: ldr             x16, [x16, #0xbe0]
    // 0xc6cc24: stp             x16, x1, [SP, #-0x10]!
    // 0xc6cc28: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6cc28: sub             lr, x0, #0xef
    //     0xc6cc2c: ldr             lr, [x21, lr, lsl #3]
    //     0xc6cc30: blr             lr
    // 0xc6cc34: add             SP, SP, #0x10
    // 0xc6cc38: mov             x3, x0
    // 0xc6cc3c: r2 = Null
    //     0xc6cc3c: mov             x2, NULL
    // 0xc6cc40: r1 = Null
    //     0xc6cc40: mov             x1, NULL
    // 0xc6cc44: stur            x3, [fp, #-8]
    // 0xc6cc48: r4 = 59
    //     0xc6cc48: mov             x4, #0x3b
    // 0xc6cc4c: branchIfSmi(r0, 0xc6cc58)
    //     0xc6cc4c: tbz             w0, #0, #0xc6cc58
    // 0xc6cc50: r4 = LoadClassIdInstr(r0)
    //     0xc6cc50: ldur            x4, [x0, #-1]
    //     0xc6cc54: ubfx            x4, x4, #0xc, #0x14
    // 0xc6cc58: sub             x4, x4, #0x75
    // 0xc6cc5c: cmp             x4, #3
    // 0xc6cc60: b.ls            #0xc6cc78
    // 0xc6cc64: r8 = Uint8List
    //     0xc6cc64: add             x8, PP, #8, lsl #12  ; [pp+0x8760] Type: Uint8List
    //     0xc6cc68: ldr             x8, [x8, #0x760]
    // 0xc6cc6c: r3 = Null
    //     0xc6cc6c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53be8] Null
    //     0xc6cc70: ldr             x3, [x3, #0xbe8]
    // 0xc6cc74: r0 = Uint8List()
    //     0xc6cc74: bl              #0x4b2828  ; IsType_Uint8List_Stub
    // 0xc6cc78: ldr             x1, [fp, #0x10]
    // 0xc6cc7c: r0 = LoadClassIdInstr(r1)
    //     0xc6cc7c: ldur            x0, [x1, #-1]
    //     0xc6cc80: ubfx            x0, x0, #0xc, #0x14
    // 0xc6cc84: r16 = "bytesPerPixel"
    //     0xc6cc84: add             x16, PP, #0x53, lsl #12  ; [pp+0x53bf8] "bytesPerPixel"
    //     0xc6cc88: ldr             x16, [x16, #0xbf8]
    // 0xc6cc8c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6cc90: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6cc90: sub             lr, x0, #0xef
    //     0xc6cc94: ldr             lr, [x21, lr, lsl #3]
    //     0xc6cc98: blr             lr
    // 0xc6cc9c: add             SP, SP, #0x10
    // 0xc6cca0: mov             x3, x0
    // 0xc6cca4: r2 = Null
    //     0xc6cca4: mov             x2, NULL
    // 0xc6cca8: r1 = Null
    //     0xc6cca8: mov             x1, NULL
    // 0xc6ccac: stur            x3, [fp, #-0x10]
    // 0xc6ccb0: branchIfSmi(r0, 0xc6ccd8)
    //     0xc6ccb0: tbz             w0, #0, #0xc6ccd8
    // 0xc6ccb4: r4 = LoadClassIdInstr(r0)
    //     0xc6ccb4: ldur            x4, [x0, #-1]
    //     0xc6ccb8: ubfx            x4, x4, #0xc, #0x14
    // 0xc6ccbc: sub             x4, x4, #0x3b
    // 0xc6ccc0: cmp             x4, #1
    // 0xc6ccc4: b.ls            #0xc6ccd8
    // 0xc6ccc8: r8 = int?
    //     0xc6ccc8: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6cccc: r3 = Null
    //     0xc6cccc: add             x3, PP, #0x53, lsl #12  ; [pp+0x53c00] Null
    //     0xc6ccd0: ldr             x3, [x3, #0xc00]
    // 0xc6ccd4: r0 = int?()
    //     0xc6ccd4: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6ccd8: ldr             x1, [fp, #0x10]
    // 0xc6ccdc: r0 = LoadClassIdInstr(r1)
    //     0xc6ccdc: ldur            x0, [x1, #-1]
    //     0xc6cce0: ubfx            x0, x0, #0xc, #0x14
    // 0xc6cce4: r16 = "bytesPerRow"
    //     0xc6cce4: add             x16, PP, #0x53, lsl #12  ; [pp+0x53c10] "bytesPerRow"
    //     0xc6cce8: ldr             x16, [x16, #0xc10]
    // 0xc6ccec: stp             x16, x1, [SP, #-0x10]!
    // 0xc6ccf0: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6ccf0: sub             lr, x0, #0xef
    //     0xc6ccf4: ldr             lr, [x21, lr, lsl #3]
    //     0xc6ccf8: blr             lr
    // 0xc6ccfc: add             SP, SP, #0x10
    // 0xc6cd00: mov             x3, x0
    // 0xc6cd04: r2 = Null
    //     0xc6cd04: mov             x2, NULL
    // 0xc6cd08: r1 = Null
    //     0xc6cd08: mov             x1, NULL
    // 0xc6cd0c: stur            x3, [fp, #-0x18]
    // 0xc6cd10: branchIfSmi(r0, 0xc6cd38)
    //     0xc6cd10: tbz             w0, #0, #0xc6cd38
    // 0xc6cd14: r4 = LoadClassIdInstr(r0)
    //     0xc6cd14: ldur            x4, [x0, #-1]
    //     0xc6cd18: ubfx            x4, x4, #0xc, #0x14
    // 0xc6cd1c: sub             x4, x4, #0x3b
    // 0xc6cd20: cmp             x4, #1
    // 0xc6cd24: b.ls            #0xc6cd38
    // 0xc6cd28: r8 = int
    //     0xc6cd28: ldr             x8, [PP, #0x4a0]  ; [pp+0x4a0] Type: int
    // 0xc6cd2c: r3 = Null
    //     0xc6cd2c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53c18] Null
    //     0xc6cd30: ldr             x3, [x3, #0xc18]
    // 0xc6cd34: r0 = int()
    //     0xc6cd34: bl              #0xd73714  ; IsType_int_Stub
    // 0xc6cd38: ldr             x1, [fp, #0x10]
    // 0xc6cd3c: r0 = LoadClassIdInstr(r1)
    //     0xc6cd3c: ldur            x0, [x1, #-1]
    //     0xc6cd40: ubfx            x0, x0, #0xc, #0x14
    // 0xc6cd44: r16 = "height"
    //     0xc6cd44: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb08] "height"
    //     0xc6cd48: ldr             x16, [x16, #0xb08]
    // 0xc6cd4c: stp             x16, x1, [SP, #-0x10]!
    // 0xc6cd50: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6cd50: sub             lr, x0, #0xef
    //     0xc6cd54: ldr             lr, [x21, lr, lsl #3]
    //     0xc6cd58: blr             lr
    // 0xc6cd5c: add             SP, SP, #0x10
    // 0xc6cd60: mov             x3, x0
    // 0xc6cd64: r2 = Null
    //     0xc6cd64: mov             x2, NULL
    // 0xc6cd68: r1 = Null
    //     0xc6cd68: mov             x1, NULL
    // 0xc6cd6c: stur            x3, [fp, #-0x20]
    // 0xc6cd70: branchIfSmi(r0, 0xc6cd98)
    //     0xc6cd70: tbz             w0, #0, #0xc6cd98
    // 0xc6cd74: r4 = LoadClassIdInstr(r0)
    //     0xc6cd74: ldur            x4, [x0, #-1]
    //     0xc6cd78: ubfx            x4, x4, #0xc, #0x14
    // 0xc6cd7c: sub             x4, x4, #0x3b
    // 0xc6cd80: cmp             x4, #1
    // 0xc6cd84: b.ls            #0xc6cd98
    // 0xc6cd88: r8 = int?
    //     0xc6cd88: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6cd8c: r3 = Null
    //     0xc6cd8c: add             x3, PP, #0x53, lsl #12  ; [pp+0x53c28] Null
    //     0xc6cd90: ldr             x3, [x3, #0xc28]
    // 0xc6cd94: r0 = int?()
    //     0xc6cd94: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6cd98: ldr             x0, [fp, #0x10]
    // 0xc6cd9c: r1 = LoadClassIdInstr(r0)
    //     0xc6cd9c: ldur            x1, [x0, #-1]
    //     0xc6cda0: ubfx            x1, x1, #0xc, #0x14
    // 0xc6cda4: r16 = "width"
    //     0xc6cda4: add             x16, PP, #0xd, lsl #12  ; [pp+0xdb30] "width"
    //     0xc6cda8: ldr             x16, [x16, #0xb30]
    // 0xc6cdac: stp             x16, x0, [SP, #-0x10]!
    // 0xc6cdb0: mov             x0, x1
    // 0xc6cdb4: r0 = GDT[cid_x0 + -0xef]()
    //     0xc6cdb4: sub             lr, x0, #0xef
    //     0xc6cdb8: ldr             lr, [x21, lr, lsl #3]
    //     0xc6cdbc: blr             lr
    // 0xc6cdc0: add             SP, SP, #0x10
    // 0xc6cdc4: mov             x3, x0
    // 0xc6cdc8: r2 = Null
    //     0xc6cdc8: mov             x2, NULL
    // 0xc6cdcc: r1 = Null
    //     0xc6cdcc: mov             x1, NULL
    // 0xc6cdd0: stur            x3, [fp, #-0x28]
    // 0xc6cdd4: branchIfSmi(r0, 0xc6cdfc)
    //     0xc6cdd4: tbz             w0, #0, #0xc6cdfc
    // 0xc6cdd8: r4 = LoadClassIdInstr(r0)
    //     0xc6cdd8: ldur            x4, [x0, #-1]
    //     0xc6cddc: ubfx            x4, x4, #0xc, #0x14
    // 0xc6cde0: sub             x4, x4, #0x3b
    // 0xc6cde4: cmp             x4, #1
    // 0xc6cde8: b.ls            #0xc6cdfc
    // 0xc6cdec: r8 = int?
    //     0xc6cdec: ldr             x8, [PP, #0x5648]  ; [pp+0x5648] Type: int?
    // 0xc6cdf0: r3 = Null
    //     0xc6cdf0: add             x3, PP, #0x53, lsl #12  ; [pp+0x53c38] Null
    //     0xc6cdf4: ldr             x3, [x3, #0xc38]
    // 0xc6cdf8: r0 = int?()
    //     0xc6cdf8: bl              #0xd736d8  ; IsType_int?_Stub
    // 0xc6cdfc: r0 = CameraImagePlane()
    //     0xc6cdfc: bl              #0xc6b3e4  ; AllocateCameraImagePlaneStub -> CameraImagePlane (size=0x20)
    // 0xc6ce00: ldur            x1, [fp, #-8]
    // 0xc6ce04: StoreField: r0->field_7 = r1
    //     0xc6ce04: stur            w1, [x0, #7]
    // 0xc6ce08: ldur            x1, [fp, #-0x18]
    // 0xc6ce0c: r2 = LoadInt32Instr(r1)
    //     0xc6ce0c: sbfx            x2, x1, #1, #0x1f
    //     0xc6ce10: tbz             w1, #0, #0xc6ce18
    //     0xc6ce14: ldur            x2, [x1, #7]
    // 0xc6ce18: StoreField: r0->field_b = r2
    //     0xc6ce18: stur            x2, [x0, #0xb]
    // 0xc6ce1c: ldur            x1, [fp, #-0x10]
    // 0xc6ce20: StoreField: r0->field_13 = r1
    //     0xc6ce20: stur            w1, [x0, #0x13]
    // 0xc6ce24: ldur            x1, [fp, #-0x20]
    // 0xc6ce28: StoreField: r0->field_17 = r1
    //     0xc6ce28: stur            w1, [x0, #0x17]
    // 0xc6ce2c: ldur            x1, [fp, #-0x28]
    // 0xc6ce30: StoreField: r0->field_1b = r1
    //     0xc6ce30: stur            w1, [x0, #0x1b]
    // 0xc6ce34: LeaveFrame
    //     0xc6ce34: mov             SP, fp
    //     0xc6ce38: ldp             fp, lr, [SP], #0x10
    // 0xc6ce3c: ret
    //     0xc6ce3c: ret             
    // 0xc6ce40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6ce40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6ce44: b               #0xc6cc10
  }
}

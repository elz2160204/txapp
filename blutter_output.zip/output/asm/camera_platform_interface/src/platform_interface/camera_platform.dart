// lib: , url: package:camera_platform_interface/src/platform_interface/camera_platform.dart

// class id: 1048717, size: 0x8
class :: {
}

// class id: 4956, size: 0x8, field offset: 0x8
abstract class CameraPlatform extends PlatformInterface {

  static late final Object _token; // offset: 0xac4
  static late CameraPlatform _instance; // offset: 0xac8

  static CameraPlatform _instance() {
    // ** addr: 0x5a82fc, size: 0x44
    // 0x5a82fc: EnterFrame
    //     0x5a82fc: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8300: mov             fp, SP
    // 0x5a8304: AllocStack(0x8)
    //     0x5a8304: sub             SP, SP, #8
    // 0x5a8308: CheckStackOverflow
    //     0x5a8308: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a830c: cmp             SP, x16
    //     0x5a8310: b.ls            #0x5a8338
    // 0x5a8314: r0 = MethodChannelCamera()
    //     0x5a8314: bl              #0x5a8c10  ; AllocateMethodChannelCameraStub -> MethodChannelCamera (size=0x1c)
    // 0x5a8318: stur            x0, [fp, #-8]
    // 0x5a831c: SaveReg r0
    //     0x5a831c: str             x0, [SP, #-8]!
    // 0x5a8320: r0 = MethodChannelCamera()
    //     0x5a8320: bl              #0x5a8340  ; [package:camera_platform_interface/src/method_channel/method_channel_camera.dart] MethodChannelCamera::MethodChannelCamera
    // 0x5a8324: add             SP, SP, #8
    // 0x5a8328: ldur            x0, [fp, #-8]
    // 0x5a832c: LeaveFrame
    //     0x5a832c: mov             SP, fp
    //     0x5a8330: ldp             fp, lr, [SP], #0x10
    // 0x5a8334: ret
    //     0x5a8334: ret             
    // 0x5a8338: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a8338: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a833c: b               #0x5a8314
  }
  set _ instance=(/* No info */) {
    // ** addr: 0xd70010, size: 0x64
    // 0xd70010: EnterFrame
    //     0xd70010: stp             fp, lr, [SP, #-0x10]!
    //     0xd70014: mov             fp, SP
    // 0xd70018: CheckStackOverflow
    //     0xd70018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xd7001c: cmp             SP, x16
    //     0xd70020: b.ls            #0xd7006c
    // 0xd70024: r0 = InitLateStaticField(0xac4) // [package:camera_platform_interface/src/platform_interface/camera_platform.dart] CameraPlatform::_token
    //     0xd70024: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xd70028: ldr             x0, [x0, #0x1588]
    //     0xd7002c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0xd70030: cmp             w0, w16
    //     0xd70034: b.ne            #0xd70040
    //     0xd70038: ldr             x2, [PP, #0xda8]  ; [pp+0xda8] Field <CameraPlatform._token@176219459>: static late final (offset: 0xac4)
    //     0xd7003c: bl              #0xd67cdc
    // 0xd70040: ldr             x16, [fp, #0x10]
    // 0xd70044: stp             x0, x16, [SP, #-0x10]!
    // 0xd70048: r0 = verify()
    //     0xd70048: bl              #0x942d7c  ; [package:plugin_platform_interface/plugin_platform_interface.dart] PlatformInterface::verify
    // 0xd7004c: add             SP, SP, #0x10
    // 0xd70050: ldr             x1, [fp, #0x10]
    // 0xd70054: StoreStaticField(0xac8, r1)
    //     0xd70054: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xd70058: str             x1, [x2, #0x1590]
    // 0xd7005c: r0 = Null
    //     0xd7005c: mov             x0, NULL
    // 0xd70060: LeaveFrame
    //     0xd70060: mov             SP, fp
    //     0xd70064: ldp             fp, lr, [SP], #0x10
    // 0xd70068: ret
    //     0xd70068: ret             
    // 0xd7006c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xd7006c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xd70070: b               #0xd70024
  }
}

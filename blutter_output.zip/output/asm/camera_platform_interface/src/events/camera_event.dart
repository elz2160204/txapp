// lib: , url: package:camera_platform_interface/src/events/camera_event.dart

// class id: 1048713, size: 0x8
class :: {
}

// class id: 4962, size: 0x10, field offset: 0x8
//   const constructor, 
abstract class CameraEvent extends Object {

  _ ==(/* No info */) {
    // ** addr: 0xc69480, size: 0xac
    // 0xc69480: EnterFrame
    //     0xc69480: stp             fp, lr, [SP, #-0x10]!
    //     0xc69484: mov             fp, SP
    // 0xc69488: CheckStackOverflow
    //     0xc69488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6948c: cmp             SP, x16
    //     0xc69490: b.ls            #0xc69524
    // 0xc69494: ldr             x1, [fp, #0x18]
    // 0xc69498: ldr             x0, [fp, #0x10]
    // 0xc6949c: cmp             w1, w0
    // 0xc694a0: b.ne            #0xc694ac
    // 0xc694a4: r0 = true
    //     0xc694a4: add             x0, NULL, #0x20  ; true
    // 0xc694a8: b               #0xc69518
    // 0xc694ac: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc694ac: mov             x2, #0x76
    //     0xc694b0: tbz             w0, #0, #0xc694c0
    //     0xc694b4: ldur            x2, [x0, #-1]
    //     0xc694b8: ubfx            x2, x2, #0xc, #0x14
    //     0xc694bc: lsl             x2, x2, #1
    // 0xc694c0: r3 = LoadInt32Instr(r2)
    //     0xc694c0: sbfx            x3, x2, #1, #0x1f
    // 0xc694c4: r17 = 4963
    //     0xc694c4: mov             x17, #0x1363
    // 0xc694c8: cmp             x3, x17
    // 0xc694cc: b.lt            #0xc69514
    // 0xc694d0: r17 = 4967
    //     0xc694d0: mov             x17, #0x1367
    // 0xc694d4: cmp             x3, x17
    // 0xc694d8: b.gt            #0xc69514
    // 0xc694dc: stp             x0, x1, [SP, #-0x10]!
    // 0xc694e0: r0 = _haveSameRuntimeType()
    //     0xc694e0: bl              #0x6ac730  ; [dart:core] Object::_haveSameRuntimeType
    // 0xc694e4: add             SP, SP, #0x10
    // 0xc694e8: tbnz            w0, #4, #0xc69514
    // 0xc694ec: ldr             x2, [fp, #0x18]
    // 0xc694f0: ldr             x1, [fp, #0x10]
    // 0xc694f4: LoadField: r3 = r2->field_7
    //     0xc694f4: ldur            x3, [x2, #7]
    // 0xc694f8: LoadField: r2 = r1->field_7
    //     0xc694f8: ldur            x2, [x1, #7]
    // 0xc694fc: cmp             x3, x2
    // 0xc69500: r16 = true
    //     0xc69500: add             x16, NULL, #0x20  ; true
    // 0xc69504: r17 = false
    //     0xc69504: add             x17, NULL, #0x30  ; false
    // 0xc69508: csel            x1, x16, x17, eq
    // 0xc6950c: mov             x0, x1
    // 0xc69510: b               #0xc69518
    // 0xc69514: r0 = false
    //     0xc69514: add             x0, NULL, #0x30  ; false
    // 0xc69518: LeaveFrame
    //     0xc69518: mov             SP, fp
    //     0xc6951c: ldp             fp, lr, [SP], #0x10
    // 0xc69520: ret
    //     0xc69520: ret             
    // 0xc69524: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69524: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc69528: b               #0xc69494
  }
}

// class id: 4963, size: 0x18, field offset: 0x10
//   const constructor, 
class VideoRecordedEvent extends CameraEvent {

  Map<String, dynamic> toJson(VideoRecordedEvent) {
    // ** addr: 0xafa30c, size: 0xf8
    // 0xafa30c: EnterFrame
    //     0xafa30c: stp             fp, lr, [SP, #-0x10]!
    //     0xafa310: mov             fp, SP
    // 0xafa314: CheckStackOverflow
    //     0xafa314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa318: cmp             SP, x16
    //     0xafa31c: b.ls            #0xafa3e4
    // 0xafa320: r1 = Null
    //     0xafa320: mov             x1, NULL
    // 0xafa324: r2 = 12
    //     0xafa324: mov             x2, #0xc
    // 0xafa328: r0 = AllocateArray()
    //     0xafa328: bl              #0xd6987c  ; AllocateArrayStub
    // 0xafa32c: mov             x2, x0
    // 0xafa330: r17 = "cameraId"
    //     0xafa330: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xafa334: ldr             x17, [x17, #0x890]
    // 0xafa338: StoreField: r2->field_f = r17
    //     0xafa338: stur            w17, [x2, #0xf]
    // 0xafa33c: ldr             x3, [fp, #0x10]
    // 0xafa340: LoadField: r4 = r3->field_7
    //     0xafa340: ldur            x4, [x3, #7]
    // 0xafa344: r0 = BoxInt64Instr(r4)
    //     0xafa344: sbfiz           x0, x4, #1, #0x1f
    //     0xafa348: cmp             x4, x0, asr #1
    //     0xafa34c: b.eq            #0xafa358
    //     0xafa350: bl              #0xd69bb8
    //     0xafa354: stur            x4, [x0, #7]
    // 0xafa358: StoreField: r2->field_13 = r0
    //     0xafa358: stur            w0, [x2, #0x13]
    // 0xafa35c: r17 = "path"
    //     0xafa35c: ldr             x17, [PP, #0x518]  ; [pp+0x518] "path"
    // 0xafa360: StoreField: r2->field_17 = r17
    //     0xafa360: stur            w17, [x2, #0x17]
    // 0xafa364: LoadField: r0 = r3->field_f
    //     0xafa364: ldur            w0, [x3, #0xf]
    // 0xafa368: DecompressPointer r0
    //     0xafa368: add             x0, x0, HEAP, lsl #32
    // 0xafa36c: LoadField: r1 = r0->field_7
    //     0xafa36c: ldur            w1, [x0, #7]
    // 0xafa370: DecompressPointer r1
    //     0xafa370: add             x1, x1, HEAP, lsl #32
    // 0xafa374: LoadField: r0 = r1->field_7
    //     0xafa374: ldur            w0, [x1, #7]
    // 0xafa378: DecompressPointer r0
    //     0xafa378: add             x0, x0, HEAP, lsl #32
    // 0xafa37c: StoreField: r2->field_1b = r0
    //     0xafa37c: stur            w0, [x2, #0x1b]
    // 0xafa380: r17 = "maxVideoDuration"
    //     0xafa380: add             x17, PP, #0x53, lsl #12  ; [pp+0x53b10] "maxVideoDuration"
    //     0xafa384: ldr             x17, [x17, #0xb10]
    // 0xafa388: StoreField: r2->field_1f = r17
    //     0xafa388: stur            w17, [x2, #0x1f]
    // 0xafa38c: LoadField: r0 = r3->field_13
    //     0xafa38c: ldur            w0, [x3, #0x13]
    // 0xafa390: DecompressPointer r0
    //     0xafa390: add             x0, x0, HEAP, lsl #32
    // 0xafa394: cmp             w0, NULL
    // 0xafa398: b.ne            #0xafa3a4
    // 0xafa39c: r0 = Null
    //     0xafa39c: mov             x0, NULL
    // 0xafa3a0: b               #0xafa3c4
    // 0xafa3a4: r1 = 1000
    //     0xafa3a4: mov             x1, #0x3e8
    // 0xafa3a8: LoadField: r3 = r0->field_7
    //     0xafa3a8: ldur            x3, [x0, #7]
    // 0xafa3ac: sdiv            x4, x3, x1
    // 0xafa3b0: r0 = BoxInt64Instr(r4)
    //     0xafa3b0: sbfiz           x0, x4, #1, #0x1f
    //     0xafa3b4: cmp             x4, x0, asr #1
    //     0xafa3b8: b.eq            #0xafa3c4
    //     0xafa3bc: bl              #0xd69bb8
    //     0xafa3c0: stur            x4, [x0, #7]
    // 0xafa3c4: StoreField: r2->field_23 = r0
    //     0xafa3c4: stur            w0, [x2, #0x23]
    // 0xafa3c8: r16 = <String, Object?>
    //     0xafa3c8: ldr             x16, [PP, #0xe88]  ; [pp+0xe88] TypeArguments: <String, Object?>
    // 0xafa3cc: stp             x2, x16, [SP, #-0x10]!
    // 0xafa3d0: r0 = Map._fromLiteral()
    //     0xafa3d0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xafa3d4: add             SP, SP, #0x10
    // 0xafa3d8: LeaveFrame
    //     0xafa3d8: mov             SP, fp
    //     0xafa3dc: ldp             fp, lr, [SP], #0x10
    // 0xafa3e0: ret
    //     0xafa3e0: ret             
    // 0xafa3e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa3e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa3e8: b               #0xafa320
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa240, size: 0xb4
    // 0xafa240: EnterFrame
    //     0xafa240: stp             fp, lr, [SP, #-0x10]!
    //     0xafa244: mov             fp, SP
    // 0xafa248: CheckStackOverflow
    //     0xafa248: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa24c: cmp             SP, x16
    //     0xafa250: b.ls            #0xafa2ec
    // 0xafa254: ldr             x2, [fp, #0x10]
    // 0xafa258: LoadField: r3 = r2->field_7
    //     0xafa258: ldur            x3, [x2, #7]
    // 0xafa25c: r0 = BoxInt64Instr(r3)
    //     0xafa25c: sbfiz           x0, x3, #1, #0x1f
    //     0xafa260: cmp             x3, x0, asr #1
    //     0xafa264: b.eq            #0xafa270
    //     0xafa268: bl              #0xd69bb8
    //     0xafa26c: stur            x3, [x0, #7]
    // 0xafa270: r1 = 59
    //     0xafa270: mov             x1, #0x3b
    // 0xafa274: branchIfSmi(r0, 0xafa280)
    //     0xafa274: tbz             w0, #0, #0xafa280
    // 0xafa278: r1 = LoadClassIdInstr(r0)
    //     0xafa278: ldur            x1, [x0, #-1]
    //     0xafa27c: ubfx            x1, x1, #0xc, #0x14
    // 0xafa280: SaveReg r0
    //     0xafa280: str             x0, [SP, #-8]!
    // 0xafa284: mov             x0, x1
    // 0xafa288: r0 = GDT[cid_x0 + 0x2721]()
    //     0xafa288: mov             x17, #0x2721
    //     0xafa28c: add             lr, x0, x17
    //     0xafa290: ldr             lr, [x21, lr, lsl #3]
    //     0xafa294: blr             lr
    // 0xafa298: add             SP, SP, #8
    // 0xafa29c: mov             x1, x0
    // 0xafa2a0: ldr             x0, [fp, #0x10]
    // 0xafa2a4: LoadField: r2 = r0->field_f
    //     0xafa2a4: ldur            w2, [x0, #0xf]
    // 0xafa2a8: DecompressPointer r2
    //     0xafa2a8: add             x2, x2, HEAP, lsl #32
    // 0xafa2ac: LoadField: r3 = r0->field_13
    //     0xafa2ac: ldur            w3, [x0, #0x13]
    // 0xafa2b0: DecompressPointer r3
    //     0xafa2b0: add             x3, x3, HEAP, lsl #32
    // 0xafa2b4: stp             x2, x1, [SP, #-0x10]!
    // 0xafa2b8: SaveReg r3
    //     0xafa2b8: str             x3, [SP, #-8]!
    // 0xafa2bc: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xafa2bc: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xafa2c0: r0 = hash()
    //     0xafa2c0: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafa2c4: add             SP, SP, #0x18
    // 0xafa2c8: mov             x2, x0
    // 0xafa2cc: r0 = BoxInt64Instr(r2)
    //     0xafa2cc: sbfiz           x0, x2, #1, #0x1f
    //     0xafa2d0: cmp             x2, x0, asr #1
    //     0xafa2d4: b.eq            #0xafa2e0
    //     0xafa2d8: bl              #0xd69bb8
    //     0xafa2dc: stur            x2, [x0, #7]
    // 0xafa2e0: LeaveFrame
    //     0xafa2e0: mov             SP, fp
    //     0xafa2e4: ldp             fp, lr, [SP], #0x10
    // 0xafa2e8: ret
    //     0xafa2e8: ret             
    // 0xafa2ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa2ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa2f0: b               #0xafa254
  }
  _ ==(/* No info */) {
    // ** addr: 0xc69930, size: 0x148
    // 0xc69930: EnterFrame
    //     0xc69930: stp             fp, lr, [SP, #-0x10]!
    //     0xc69934: mov             fp, SP
    // 0xc69938: CheckStackOverflow
    //     0xc69938: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6993c: cmp             SP, x16
    //     0xc69940: b.ls            #0xc69a70
    // 0xc69944: ldr             x0, [fp, #0x10]
    // 0xc69948: cmp             w0, NULL
    // 0xc6994c: b.ne            #0xc69960
    // 0xc69950: r0 = false
    //     0xc69950: add             x0, NULL, #0x30  ; false
    // 0xc69954: LeaveFrame
    //     0xc69954: mov             SP, fp
    //     0xc69958: ldp             fp, lr, [SP], #0x10
    // 0xc6995c: ret
    //     0xc6995c: ret             
    // 0xc69960: ldr             x1, [fp, #0x18]
    // 0xc69964: cmp             w1, w0
    // 0xc69968: b.ne            #0xc69974
    // 0xc6996c: r0 = true
    //     0xc6996c: add             x0, NULL, #0x20  ; true
    // 0xc69970: b               #0xc69a64
    // 0xc69974: cmp             w1, w0
    // 0xc69978: b.eq            #0xc699e8
    // 0xc6997c: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6997c: mov             x2, #0x76
    //     0xc69980: tbz             w0, #0, #0xc69990
    //     0xc69984: ldur            x2, [x0, #-1]
    //     0xc69988: ubfx            x2, x2, #0xc, #0x14
    //     0xc6998c: lsl             x2, x2, #1
    // 0xc69990: r3 = LoadInt32Instr(r2)
    //     0xc69990: sbfx            x3, x2, #1, #0x1f
    // 0xc69994: r17 = 4963
    //     0xc69994: mov             x17, #0x1363
    // 0xc69998: cmp             x3, x17
    // 0xc6999c: b.lt            #0xc69a60
    // 0xc699a0: r17 = 4967
    //     0xc699a0: mov             x17, #0x1367
    // 0xc699a4: cmp             x3, x17
    // 0xc699a8: b.gt            #0xc69a60
    // 0xc699ac: SaveReg r0
    //     0xc699ac: str             x0, [SP, #-8]!
    // 0xc699b0: r0 = runtimeType()
    //     0xc699b0: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc699b4: add             SP, SP, #8
    // 0xc699b8: r16 = VideoRecordedEvent
    //     0xc699b8: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cd8] Type: VideoRecordedEvent
    //     0xc699bc: ldr             x16, [x16, #0xcd8]
    // 0xc699c0: stp             x0, x16, [SP, #-0x10]!
    // 0xc699c4: r0 = ==()
    //     0xc699c4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc699c8: add             SP, SP, #0x10
    // 0xc699cc: tbnz            w0, #4, #0xc69a60
    // 0xc699d0: ldr             x1, [fp, #0x18]
    // 0xc699d4: ldr             x0, [fp, #0x10]
    // 0xc699d8: LoadField: r2 = r1->field_7
    //     0xc699d8: ldur            x2, [x1, #7]
    // 0xc699dc: LoadField: r3 = r0->field_7
    //     0xc699dc: ldur            x3, [x0, #7]
    // 0xc699e0: cmp             x2, x3
    // 0xc699e4: b.ne            #0xc69a60
    // 0xc699e8: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc699e8: mov             x2, #0x76
    //     0xc699ec: tbz             w0, #0, #0xc699fc
    //     0xc699f0: ldur            x2, [x0, #-1]
    //     0xc699f4: ubfx            x2, x2, #0xc, #0x14
    //     0xc699f8: lsl             x2, x2, #1
    // 0xc699fc: r17 = 9926
    //     0xc699fc: mov             x17, #0x26c6
    // 0xc69a00: cmp             w2, w17
    // 0xc69a04: b.ne            #0xc69a60
    // 0xc69a08: r16 = VideoRecordedEvent
    //     0xc69a08: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cd8] Type: VideoRecordedEvent
    //     0xc69a0c: ldr             x16, [x16, #0xcd8]
    // 0xc69a10: r30 = VideoRecordedEvent
    //     0xc69a10: add             lr, PP, #0x55, lsl #12  ; [pp+0x55cd8] Type: VideoRecordedEvent
    //     0xc69a14: ldr             lr, [lr, #0xcd8]
    // 0xc69a18: stp             lr, x16, [SP, #-0x10]!
    // 0xc69a1c: r0 = ==()
    //     0xc69a1c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc69a20: add             SP, SP, #0x10
    // 0xc69a24: tbnz            w0, #4, #0xc69a60
    // 0xc69a28: ldr             x1, [fp, #0x18]
    // 0xc69a2c: ldr             x0, [fp, #0x10]
    // 0xc69a30: LoadField: r2 = r1->field_13
    //     0xc69a30: ldur            w2, [x1, #0x13]
    // 0xc69a34: DecompressPointer r2
    //     0xc69a34: add             x2, x2, HEAP, lsl #32
    // 0xc69a38: LoadField: r1 = r0->field_13
    //     0xc69a38: ldur            w1, [x0, #0x13]
    // 0xc69a3c: DecompressPointer r1
    //     0xc69a3c: add             x1, x1, HEAP, lsl #32
    // 0xc69a40: r0 = LoadClassIdInstr(r2)
    //     0xc69a40: ldur            x0, [x2, #-1]
    //     0xc69a44: ubfx            x0, x0, #0xc, #0x14
    // 0xc69a48: stp             x1, x2, [SP, #-0x10]!
    // 0xc69a4c: mov             lr, x0
    // 0xc69a50: ldr             lr, [x21, lr, lsl #3]
    // 0xc69a54: blr             lr
    // 0xc69a58: add             SP, SP, #0x10
    // 0xc69a5c: b               #0xc69a64
    // 0xc69a60: r0 = false
    //     0xc69a60: add             x0, NULL, #0x30  ; false
    // 0xc69a64: LeaveFrame
    //     0xc69a64: mov             SP, fp
    //     0xc69a68: ldp             fp, lr, [SP], #0x10
    // 0xc69a6c: ret
    //     0xc69a6c: ret             
    // 0xc69a70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69a70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc69a74: b               #0xc69944
  }
}

// class id: 4964, size: 0x14, field offset: 0x10
//   const constructor, 
class CameraErrorEvent extends CameraEvent {

  Map<String, dynamic> toJson(CameraErrorEvent) {
    // ** addr: 0xafa1b4, size: 0xa4
    // 0xafa1b4: EnterFrame
    //     0xafa1b4: stp             fp, lr, [SP, #-0x10]!
    //     0xafa1b8: mov             fp, SP
    // 0xafa1bc: CheckStackOverflow
    //     0xafa1bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa1c0: cmp             SP, x16
    //     0xafa1c4: b.ls            #0xafa238
    // 0xafa1c8: r1 = Null
    //     0xafa1c8: mov             x1, NULL
    // 0xafa1cc: r2 = 8
    //     0xafa1cc: mov             x2, #8
    // 0xafa1d0: r0 = AllocateArray()
    //     0xafa1d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xafa1d4: mov             x2, x0
    // 0xafa1d8: r17 = "cameraId"
    //     0xafa1d8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xafa1dc: ldr             x17, [x17, #0x890]
    // 0xafa1e0: StoreField: r2->field_f = r17
    //     0xafa1e0: stur            w17, [x2, #0xf]
    // 0xafa1e4: ldr             x3, [fp, #0x10]
    // 0xafa1e8: LoadField: r4 = r3->field_7
    //     0xafa1e8: ldur            x4, [x3, #7]
    // 0xafa1ec: r0 = BoxInt64Instr(r4)
    //     0xafa1ec: sbfiz           x0, x4, #1, #0x1f
    //     0xafa1f0: cmp             x4, x0, asr #1
    //     0xafa1f4: b.eq            #0xafa200
    //     0xafa1f8: bl              #0xd69bb8
    //     0xafa1fc: stur            x4, [x0, #7]
    // 0xafa200: StoreField: r2->field_13 = r0
    //     0xafa200: stur            w0, [x2, #0x13]
    // 0xafa204: r17 = "description"
    //     0xafa204: add             x17, PP, #0x12, lsl #12  ; [pp+0x12b70] "description"
    //     0xafa208: ldr             x17, [x17, #0xb70]
    // 0xafa20c: StoreField: r2->field_17 = r17
    //     0xafa20c: stur            w17, [x2, #0x17]
    // 0xafa210: LoadField: r0 = r3->field_f
    //     0xafa210: ldur            w0, [x3, #0xf]
    // 0xafa214: DecompressPointer r0
    //     0xafa214: add             x0, x0, HEAP, lsl #32
    // 0xafa218: StoreField: r2->field_1b = r0
    //     0xafa218: stur            w0, [x2, #0x1b]
    // 0xafa21c: r16 = <String, Object>
    //     0xafa21c: ldr             x16, [PP, #0x28e8]  ; [pp+0x28e8] TypeArguments: <String, Object>
    // 0xafa220: stp             x2, x16, [SP, #-0x10]!
    // 0xafa224: r0 = Map._fromLiteral()
    //     0xafa224: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xafa228: add             SP, SP, #0x10
    // 0xafa22c: LeaveFrame
    //     0xafa22c: mov             SP, fp
    //     0xafa230: ldp             fp, lr, [SP], #0x10
    // 0xafa234: ret
    //     0xafa234: ret             
    // 0xafa238: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa238: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa23c: b               #0xafa1c8
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafa0f4, size: 0xa8
    // 0xafa0f4: EnterFrame
    //     0xafa0f4: stp             fp, lr, [SP, #-0x10]!
    //     0xafa0f8: mov             fp, SP
    // 0xafa0fc: CheckStackOverflow
    //     0xafa0fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa100: cmp             SP, x16
    //     0xafa104: b.ls            #0xafa194
    // 0xafa108: ldr             x2, [fp, #0x10]
    // 0xafa10c: LoadField: r3 = r2->field_7
    //     0xafa10c: ldur            x3, [x2, #7]
    // 0xafa110: r0 = BoxInt64Instr(r3)
    //     0xafa110: sbfiz           x0, x3, #1, #0x1f
    //     0xafa114: cmp             x3, x0, asr #1
    //     0xafa118: b.eq            #0xafa124
    //     0xafa11c: bl              #0xd69bb8
    //     0xafa120: stur            x3, [x0, #7]
    // 0xafa124: r1 = 59
    //     0xafa124: mov             x1, #0x3b
    // 0xafa128: branchIfSmi(r0, 0xafa134)
    //     0xafa128: tbz             w0, #0, #0xafa134
    // 0xafa12c: r1 = LoadClassIdInstr(r0)
    //     0xafa12c: ldur            x1, [x0, #-1]
    //     0xafa130: ubfx            x1, x1, #0xc, #0x14
    // 0xafa134: SaveReg r0
    //     0xafa134: str             x0, [SP, #-8]!
    // 0xafa138: mov             x0, x1
    // 0xafa13c: r0 = GDT[cid_x0 + 0x2721]()
    //     0xafa13c: mov             x17, #0x2721
    //     0xafa140: add             lr, x0, x17
    //     0xafa144: ldr             lr, [x21, lr, lsl #3]
    //     0xafa148: blr             lr
    // 0xafa14c: add             SP, SP, #8
    // 0xafa150: mov             x1, x0
    // 0xafa154: ldr             x0, [fp, #0x10]
    // 0xafa158: LoadField: r2 = r0->field_f
    //     0xafa158: ldur            w2, [x0, #0xf]
    // 0xafa15c: DecompressPointer r2
    //     0xafa15c: add             x2, x2, HEAP, lsl #32
    // 0xafa160: stp             x2, x1, [SP, #-0x10]!
    // 0xafa164: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xafa164: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xafa168: r0 = hash()
    //     0xafa168: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafa16c: add             SP, SP, #0x10
    // 0xafa170: mov             x2, x0
    // 0xafa174: r0 = BoxInt64Instr(r2)
    //     0xafa174: sbfiz           x0, x2, #1, #0x1f
    //     0xafa178: cmp             x2, x0, asr #1
    //     0xafa17c: b.eq            #0xafa188
    //     0xafa180: bl              #0xd69bb8
    //     0xafa184: stur            x2, [x0, #7]
    // 0xafa188: LeaveFrame
    //     0xafa188: mov             SP, fp
    //     0xafa18c: ldp             fp, lr, [SP], #0x10
    // 0xafa190: ret
    //     0xafa190: ret             
    // 0xafa194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa198: b               #0xafa108
  }
  _ ==(/* No info */) {
    // ** addr: 0xc697e8, size: 0x148
    // 0xc697e8: EnterFrame
    //     0xc697e8: stp             fp, lr, [SP, #-0x10]!
    //     0xc697ec: mov             fp, SP
    // 0xc697f0: CheckStackOverflow
    //     0xc697f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc697f4: cmp             SP, x16
    //     0xc697f8: b.ls            #0xc69928
    // 0xc697fc: ldr             x0, [fp, #0x10]
    // 0xc69800: cmp             w0, NULL
    // 0xc69804: b.ne            #0xc69818
    // 0xc69808: r0 = false
    //     0xc69808: add             x0, NULL, #0x30  ; false
    // 0xc6980c: LeaveFrame
    //     0xc6980c: mov             SP, fp
    //     0xc69810: ldp             fp, lr, [SP], #0x10
    // 0xc69814: ret
    //     0xc69814: ret             
    // 0xc69818: ldr             x1, [fp, #0x18]
    // 0xc6981c: cmp             w1, w0
    // 0xc69820: b.ne            #0xc6982c
    // 0xc69824: r0 = true
    //     0xc69824: add             x0, NULL, #0x20  ; true
    // 0xc69828: b               #0xc6991c
    // 0xc6982c: cmp             w1, w0
    // 0xc69830: b.eq            #0xc698a0
    // 0xc69834: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc69834: mov             x2, #0x76
    //     0xc69838: tbz             w0, #0, #0xc69848
    //     0xc6983c: ldur            x2, [x0, #-1]
    //     0xc69840: ubfx            x2, x2, #0xc, #0x14
    //     0xc69844: lsl             x2, x2, #1
    // 0xc69848: r3 = LoadInt32Instr(r2)
    //     0xc69848: sbfx            x3, x2, #1, #0x1f
    // 0xc6984c: r17 = 4963
    //     0xc6984c: mov             x17, #0x1363
    // 0xc69850: cmp             x3, x17
    // 0xc69854: b.lt            #0xc69918
    // 0xc69858: r17 = 4967
    //     0xc69858: mov             x17, #0x1367
    // 0xc6985c: cmp             x3, x17
    // 0xc69860: b.gt            #0xc69918
    // 0xc69864: SaveReg r0
    //     0xc69864: str             x0, [SP, #-8]!
    // 0xc69868: r0 = runtimeType()
    //     0xc69868: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc6986c: add             SP, SP, #8
    // 0xc69870: r16 = CameraErrorEvent
    //     0xc69870: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cf0] Type: CameraErrorEvent
    //     0xc69874: ldr             x16, [x16, #0xcf0]
    // 0xc69878: stp             x0, x16, [SP, #-0x10]!
    // 0xc6987c: r0 = ==()
    //     0xc6987c: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc69880: add             SP, SP, #0x10
    // 0xc69884: tbnz            w0, #4, #0xc69918
    // 0xc69888: ldr             x1, [fp, #0x18]
    // 0xc6988c: ldr             x0, [fp, #0x10]
    // 0xc69890: LoadField: r2 = r1->field_7
    //     0xc69890: ldur            x2, [x1, #7]
    // 0xc69894: LoadField: r3 = r0->field_7
    //     0xc69894: ldur            x3, [x0, #7]
    // 0xc69898: cmp             x2, x3
    // 0xc6989c: b.ne            #0xc69918
    // 0xc698a0: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc698a0: mov             x2, #0x76
    //     0xc698a4: tbz             w0, #0, #0xc698b4
    //     0xc698a8: ldur            x2, [x0, #-1]
    //     0xc698ac: ubfx            x2, x2, #0xc, #0x14
    //     0xc698b0: lsl             x2, x2, #1
    // 0xc698b4: r17 = 9928
    //     0xc698b4: mov             x17, #0x26c8
    // 0xc698b8: cmp             w2, w17
    // 0xc698bc: b.ne            #0xc69918
    // 0xc698c0: r16 = CameraErrorEvent
    //     0xc698c0: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cf0] Type: CameraErrorEvent
    //     0xc698c4: ldr             x16, [x16, #0xcf0]
    // 0xc698c8: r30 = CameraErrorEvent
    //     0xc698c8: add             lr, PP, #0x55, lsl #12  ; [pp+0x55cf0] Type: CameraErrorEvent
    //     0xc698cc: ldr             lr, [lr, #0xcf0]
    // 0xc698d0: stp             lr, x16, [SP, #-0x10]!
    // 0xc698d4: r0 = ==()
    //     0xc698d4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc698d8: add             SP, SP, #0x10
    // 0xc698dc: tbnz            w0, #4, #0xc69918
    // 0xc698e0: ldr             x1, [fp, #0x18]
    // 0xc698e4: ldr             x0, [fp, #0x10]
    // 0xc698e8: LoadField: r2 = r1->field_f
    //     0xc698e8: ldur            w2, [x1, #0xf]
    // 0xc698ec: DecompressPointer r2
    //     0xc698ec: add             x2, x2, HEAP, lsl #32
    // 0xc698f0: LoadField: r1 = r0->field_f
    //     0xc698f0: ldur            w1, [x0, #0xf]
    // 0xc698f4: DecompressPointer r1
    //     0xc698f4: add             x1, x1, HEAP, lsl #32
    // 0xc698f8: r0 = LoadClassIdInstr(r2)
    //     0xc698f8: ldur            x0, [x2, #-1]
    //     0xc698fc: ubfx            x0, x0, #0xc, #0x14
    // 0xc69900: stp             x1, x2, [SP, #-0x10]!
    // 0xc69904: mov             lr, x0
    // 0xc69908: ldr             lr, [x21, lr, lsl #3]
    // 0xc6990c: blr             lr
    // 0xc69910: add             SP, SP, #0x10
    // 0xc69914: b               #0xc6991c
    // 0xc69918: r0 = false
    //     0xc69918: add             x0, NULL, #0x30  ; false
    // 0xc6991c: LeaveFrame
    //     0xc6991c: mov             SP, fp
    //     0xc69920: ldp             fp, lr, [SP], #0x10
    // 0xc69924: ret
    //     0xc69924: ret             
    // 0xc69928: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69928: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6992c: b               #0xc697fc
  }
}

// class id: 4965, size: 0x10, field offset: 0x10
//   const constructor, 
class CameraClosingEvent extends CameraEvent {

  Map<String, dynamic> toJson(CameraClosingEvent) {
    // ** addr: 0xc69774, size: 0x8c
    // 0xc69774: EnterFrame
    //     0xc69774: stp             fp, lr, [SP, #-0x10]!
    //     0xc69778: mov             fp, SP
    // 0xc6977c: CheckStackOverflow
    //     0xc6977c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc69780: cmp             SP, x16
    //     0xc69784: b.ls            #0xc697e0
    // 0xc69788: r1 = Null
    //     0xc69788: mov             x1, NULL
    // 0xc6978c: r2 = 4
    //     0xc6978c: mov             x2, #4
    // 0xc69790: r0 = AllocateArray()
    //     0xc69790: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc69794: mov             x2, x0
    // 0xc69798: r17 = "cameraId"
    //     0xc69798: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xc6979c: ldr             x17, [x17, #0x890]
    // 0xc697a0: StoreField: r2->field_f = r17
    //     0xc697a0: stur            w17, [x2, #0xf]
    // 0xc697a4: ldr             x0, [fp, #0x10]
    // 0xc697a8: LoadField: r3 = r0->field_7
    //     0xc697a8: ldur            x3, [x0, #7]
    // 0xc697ac: r0 = BoxInt64Instr(r3)
    //     0xc697ac: sbfiz           x0, x3, #1, #0x1f
    //     0xc697b0: cmp             x3, x0, asr #1
    //     0xc697b4: b.eq            #0xc697c0
    //     0xc697b8: bl              #0xd69bb8
    //     0xc697bc: stur            x3, [x0, #7]
    // 0xc697c0: StoreField: r2->field_13 = r0
    //     0xc697c0: stur            w0, [x2, #0x13]
    // 0xc697c4: r16 = <String, Object>
    //     0xc697c4: ldr             x16, [PP, #0x28e8]  ; [pp+0x28e8] TypeArguments: <String, Object>
    // 0xc697c8: stp             x2, x16, [SP, #-0x10]!
    // 0xc697cc: r0 = Map._fromLiteral()
    //     0xc697cc: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xc697d0: add             SP, SP, #0x10
    // 0xc697d4: LeaveFrame
    //     0xc697d4: mov             SP, fp
    //     0xc697d8: ldp             fp, lr, [SP], #0x10
    // 0xc697dc: ret
    //     0xc697dc: ret             
    // 0xc697e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc697e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc697e4: b               #0xc69788
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6964c, size: 0x110
    // 0xc6964c: EnterFrame
    //     0xc6964c: stp             fp, lr, [SP, #-0x10]!
    //     0xc69650: mov             fp, SP
    // 0xc69654: CheckStackOverflow
    //     0xc69654: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc69658: cmp             SP, x16
    //     0xc6965c: b.ls            #0xc69754
    // 0xc69660: ldr             x0, [fp, #0x10]
    // 0xc69664: cmp             w0, NULL
    // 0xc69668: b.ne            #0xc6967c
    // 0xc6966c: r0 = false
    //     0xc6966c: add             x0, NULL, #0x30  ; false
    // 0xc69670: LeaveFrame
    //     0xc69670: mov             SP, fp
    //     0xc69674: ldp             fp, lr, [SP], #0x10
    // 0xc69678: ret
    //     0xc69678: ret             
    // 0xc6967c: ldr             x1, [fp, #0x18]
    // 0xc69680: cmp             w1, w0
    // 0xc69684: b.ne            #0xc69690
    // 0xc69688: r0 = true
    //     0xc69688: add             x0, NULL, #0x20  ; true
    // 0xc6968c: b               #0xc69748
    // 0xc69690: cmp             w1, w0
    // 0xc69694: b.eq            #0xc69704
    // 0xc69698: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc69698: mov             x2, #0x76
    //     0xc6969c: tbz             w0, #0, #0xc696ac
    //     0xc696a0: ldur            x2, [x0, #-1]
    //     0xc696a4: ubfx            x2, x2, #0xc, #0x14
    //     0xc696a8: lsl             x2, x2, #1
    // 0xc696ac: r3 = LoadInt32Instr(r2)
    //     0xc696ac: sbfx            x3, x2, #1, #0x1f
    // 0xc696b0: r17 = 4963
    //     0xc696b0: mov             x17, #0x1363
    // 0xc696b4: cmp             x3, x17
    // 0xc696b8: b.lt            #0xc69744
    // 0xc696bc: r17 = 4967
    //     0xc696bc: mov             x17, #0x1367
    // 0xc696c0: cmp             x3, x17
    // 0xc696c4: b.gt            #0xc69744
    // 0xc696c8: SaveReg r0
    //     0xc696c8: str             x0, [SP, #-8]!
    // 0xc696cc: r0 = runtimeType()
    //     0xc696cc: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc696d0: add             SP, SP, #8
    // 0xc696d4: r16 = CameraClosingEvent
    //     0xc696d4: add             x16, PP, #0x55, lsl #12  ; [pp+0x55ce0] Type: CameraClosingEvent
    //     0xc696d8: ldr             x16, [x16, #0xce0]
    // 0xc696dc: stp             x0, x16, [SP, #-0x10]!
    // 0xc696e0: r0 = ==()
    //     0xc696e0: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc696e4: add             SP, SP, #0x10
    // 0xc696e8: tbnz            w0, #4, #0xc69744
    // 0xc696ec: ldr             x1, [fp, #0x18]
    // 0xc696f0: ldr             x0, [fp, #0x10]
    // 0xc696f4: LoadField: r2 = r1->field_7
    //     0xc696f4: ldur            x2, [x1, #7]
    // 0xc696f8: LoadField: r1 = r0->field_7
    //     0xc696f8: ldur            x1, [x0, #7]
    // 0xc696fc: cmp             x2, x1
    // 0xc69700: b.ne            #0xc69744
    // 0xc69704: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc69704: mov             x1, #0x76
    //     0xc69708: tbz             w0, #0, #0xc69718
    //     0xc6970c: ldur            x1, [x0, #-1]
    //     0xc69710: ubfx            x1, x1, #0xc, #0x14
    //     0xc69714: lsl             x1, x1, #1
    // 0xc69718: r17 = 9930
    //     0xc69718: mov             x17, #0x26ca
    // 0xc6971c: cmp             w1, w17
    // 0xc69720: b.ne            #0xc69744
    // 0xc69724: r16 = CameraClosingEvent
    //     0xc69724: add             x16, PP, #0x55, lsl #12  ; [pp+0x55ce0] Type: CameraClosingEvent
    //     0xc69728: ldr             x16, [x16, #0xce0]
    // 0xc6972c: r30 = CameraClosingEvent
    //     0xc6972c: add             lr, PP, #0x55, lsl #12  ; [pp+0x55ce0] Type: CameraClosingEvent
    //     0xc69730: ldr             lr, [lr, #0xce0]
    // 0xc69734: stp             lr, x16, [SP, #-0x10]!
    // 0xc69738: r0 = ==()
    //     0xc69738: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc6973c: add             SP, SP, #0x10
    // 0xc69740: b               #0xc69748
    // 0xc69744: r0 = false
    //     0xc69744: add             x0, NULL, #0x30  ; false
    // 0xc69748: LeaveFrame
    //     0xc69748: mov             SP, fp
    //     0xc6974c: ldp             fp, lr, [SP], #0x10
    // 0xc69750: ret
    //     0xc69750: ret             
    // 0xc69754: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69754: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc69758: b               #0xc69660
  }
}

// class id: 4966, size: 0x20, field offset: 0x10
//   const constructor, 
class CameraResolutionChangedEvent extends CameraEvent {

  Map<String, dynamic> toJson(CameraResolutionChangedEvent) {
    // ** addr: 0xaf9fd8, size: 0x134
    // 0xaf9fd8: EnterFrame
    //     0xaf9fd8: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9fdc: mov             fp, SP
    // 0xaf9fe0: CheckStackOverflow
    //     0xaf9fe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaf9fe4: cmp             SP, x16
    //     0xaf9fe8: b.ls            #0xafa0bc
    // 0xaf9fec: r1 = Null
    //     0xaf9fec: mov             x1, NULL
    // 0xaf9ff0: r2 = 12
    //     0xaf9ff0: mov             x2, #0xc
    // 0xaf9ff4: r0 = AllocateArray()
    //     0xaf9ff4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xaf9ff8: mov             x2, x0
    // 0xaf9ffc: r17 = "cameraId"
    //     0xaf9ffc: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0xafa000: ldr             x17, [x17, #0x890]
    // 0xafa004: StoreField: r2->field_f = r17
    //     0xafa004: stur            w17, [x2, #0xf]
    // 0xafa008: ldr             x3, [fp, #0x10]
    // 0xafa00c: LoadField: r4 = r3->field_7
    //     0xafa00c: ldur            x4, [x3, #7]
    // 0xafa010: r0 = BoxInt64Instr(r4)
    //     0xafa010: sbfiz           x0, x4, #1, #0x1f
    //     0xafa014: cmp             x4, x0, asr #1
    //     0xafa018: b.eq            #0xafa024
    //     0xafa01c: bl              #0xd69bb8
    //     0xafa020: stur            x4, [x0, #7]
    // 0xafa024: StoreField: r2->field_13 = r0
    //     0xafa024: stur            w0, [x2, #0x13]
    // 0xafa028: r17 = "captureWidth"
    //     0xafa028: add             x17, PP, #0x53, lsl #12  ; [pp+0x53d50] "captureWidth"
    //     0xafa02c: ldr             x17, [x17, #0xd50]
    // 0xafa030: StoreField: r2->field_17 = r17
    //     0xafa030: stur            w17, [x2, #0x17]
    // 0xafa034: LoadField: d0 = r3->field_f
    //     0xafa034: ldur            d0, [x3, #0xf]
    // 0xafa038: r0 = inline_Allocate_Double()
    //     0xafa038: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xafa03c: add             x0, x0, #0x10
    //     0xafa040: cmp             x1, x0
    //     0xafa044: b.ls            #0xafa0c4
    //     0xafa048: str             x0, [THR, #0x60]  ; THR::top
    //     0xafa04c: sub             x0, x0, #0xf
    //     0xafa050: mov             x1, #0xd108
    //     0xafa054: movk            x1, #3, lsl #16
    //     0xafa058: stur            x1, [x0, #-1]
    // 0xafa05c: StoreField: r0->field_7 = d0
    //     0xafa05c: stur            d0, [x0, #7]
    // 0xafa060: StoreField: r2->field_1b = r0
    //     0xafa060: stur            w0, [x2, #0x1b]
    // 0xafa064: r17 = "captureHeight"
    //     0xafa064: add             x17, PP, #0x53, lsl #12  ; [pp+0x53d68] "captureHeight"
    //     0xafa068: ldr             x17, [x17, #0xd68]
    // 0xafa06c: StoreField: r2->field_1f = r17
    //     0xafa06c: stur            w17, [x2, #0x1f]
    // 0xafa070: LoadField: d0 = r3->field_17
    //     0xafa070: ldur            d0, [x3, #0x17]
    // 0xafa074: r0 = inline_Allocate_Double()
    //     0xafa074: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xafa078: add             x0, x0, #0x10
    //     0xafa07c: cmp             x1, x0
    //     0xafa080: b.ls            #0xafa0dc
    //     0xafa084: str             x0, [THR, #0x60]  ; THR::top
    //     0xafa088: sub             x0, x0, #0xf
    //     0xafa08c: mov             x1, #0xd108
    //     0xafa090: movk            x1, #3, lsl #16
    //     0xafa094: stur            x1, [x0, #-1]
    // 0xafa098: StoreField: r0->field_7 = d0
    //     0xafa098: stur            d0, [x0, #7]
    // 0xafa09c: StoreField: r2->field_23 = r0
    //     0xafa09c: stur            w0, [x2, #0x23]
    // 0xafa0a0: r16 = <String, Object>
    //     0xafa0a0: ldr             x16, [PP, #0x28e8]  ; [pp+0x28e8] TypeArguments: <String, Object>
    // 0xafa0a4: stp             x2, x16, [SP, #-0x10]!
    // 0xafa0a8: r0 = Map._fromLiteral()
    //     0xafa0a8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0xafa0ac: add             SP, SP, #0x10
    // 0xafa0b0: LeaveFrame
    //     0xafa0b0: mov             SP, fp
    //     0xafa0b4: ldp             fp, lr, [SP], #0x10
    // 0xafa0b8: ret
    //     0xafa0b8: ret             
    // 0xafa0bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa0bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa0c0: b               #0xaf9fec
    // 0xafa0c4: SaveReg d0
    //     0xafa0c4: str             q0, [SP, #-0x10]!
    // 0xafa0c8: stp             x2, x3, [SP, #-0x10]!
    // 0xafa0cc: r0 = AllocateDouble()
    //     0xafa0cc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xafa0d0: ldp             x2, x3, [SP], #0x10
    // 0xafa0d4: RestoreReg d0
    //     0xafa0d4: ldr             q0, [SP], #0x10
    // 0xafa0d8: b               #0xafa05c
    // 0xafa0dc: SaveReg d0
    //     0xafa0dc: str             q0, [SP, #-0x10]!
    // 0xafa0e0: SaveReg r2
    //     0xafa0e0: str             x2, [SP, #-8]!
    // 0xafa0e4: r0 = AllocateDouble()
    //     0xafa0e4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xafa0e8: RestoreReg r2
    //     0xafa0e8: ldr             x2, [SP], #8
    // 0xafa0ec: RestoreReg d0
    //     0xafa0ec: ldr             q0, [SP], #0x10
    // 0xafa0f0: b               #0xafa098
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xaf9ec8, size: 0xf8
    // 0xaf9ec8: EnterFrame
    //     0xaf9ec8: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9ecc: mov             fp, SP
    // 0xaf9ed0: CheckStackOverflow
    //     0xaf9ed0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaf9ed4: cmp             SP, x16
    //     0xaf9ed8: b.ls            #0xaf9f84
    // 0xaf9edc: ldr             x16, [fp, #0x10]
    // 0xaf9ee0: SaveReg r16
    //     0xaf9ee0: str             x16, [SP, #-8]!
    // 0xaf9ee4: r0 = hashCode()
    //     0xaf9ee4: bl              #0xb05dc8  ; [package:flutter/src/services/keyboard_key.g.dart] PhysicalKeyboardKey::hashCode
    // 0xaf9ee8: add             SP, SP, #8
    // 0xaf9eec: mov             x1, x0
    // 0xaf9ef0: ldr             x0, [fp, #0x10]
    // 0xaf9ef4: LoadField: d0 = r0->field_f
    //     0xaf9ef4: ldur            d0, [x0, #0xf]
    // 0xaf9ef8: LoadField: d1 = r0->field_17
    //     0xaf9ef8: ldur            d1, [x0, #0x17]
    // 0xaf9efc: r0 = inline_Allocate_Double()
    //     0xaf9efc: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xaf9f00: add             x0, x0, #0x10
    //     0xaf9f04: cmp             x2, x0
    //     0xaf9f08: b.ls            #0xaf9f8c
    //     0xaf9f0c: str             x0, [THR, #0x60]  ; THR::top
    //     0xaf9f10: sub             x0, x0, #0xf
    //     0xaf9f14: mov             x2, #0xd108
    //     0xaf9f18: movk            x2, #3, lsl #16
    //     0xaf9f1c: stur            x2, [x0, #-1]
    // 0xaf9f20: StoreField: r0->field_7 = d0
    //     0xaf9f20: stur            d0, [x0, #7]
    // 0xaf9f24: r2 = inline_Allocate_Double()
    //     0xaf9f24: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xaf9f28: add             x2, x2, #0x10
    //     0xaf9f2c: cmp             x3, x2
    //     0xaf9f30: b.ls            #0xaf9fa4
    //     0xaf9f34: str             x2, [THR, #0x60]  ; THR::top
    //     0xaf9f38: sub             x2, x2, #0xf
    //     0xaf9f3c: mov             x3, #0xd108
    //     0xaf9f40: movk            x3, #3, lsl #16
    //     0xaf9f44: stur            x3, [x2, #-1]
    // 0xaf9f48: StoreField: r2->field_7 = d1
    //     0xaf9f48: stur            d1, [x2, #7]
    // 0xaf9f4c: stp             x0, x1, [SP, #-0x10]!
    // 0xaf9f50: SaveReg r2
    //     0xaf9f50: str             x2, [SP, #-8]!
    // 0xaf9f54: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xaf9f54: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xaf9f58: r0 = hash()
    //     0xaf9f58: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaf9f5c: add             SP, SP, #0x18
    // 0xaf9f60: mov             x2, x0
    // 0xaf9f64: r0 = BoxInt64Instr(r2)
    //     0xaf9f64: sbfiz           x0, x2, #1, #0x1f
    //     0xaf9f68: cmp             x2, x0, asr #1
    //     0xaf9f6c: b.eq            #0xaf9f78
    //     0xaf9f70: bl              #0xd69bb8
    //     0xaf9f74: stur            x2, [x0, #7]
    // 0xaf9f78: LeaveFrame
    //     0xaf9f78: mov             SP, fp
    //     0xaf9f7c: ldp             fp, lr, [SP], #0x10
    // 0xaf9f80: ret
    //     0xaf9f80: ret             
    // 0xaf9f84: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9f84: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9f88: b               #0xaf9edc
    // 0xaf9f8c: stp             q0, q1, [SP, #-0x20]!
    // 0xaf9f90: SaveReg r1
    //     0xaf9f90: str             x1, [SP, #-8]!
    // 0xaf9f94: r0 = AllocateDouble()
    //     0xaf9f94: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaf9f98: RestoreReg r1
    //     0xaf9f98: ldr             x1, [SP], #8
    // 0xaf9f9c: ldp             q0, q1, [SP], #0x20
    // 0xaf9fa0: b               #0xaf9f20
    // 0xaf9fa4: SaveReg d1
    //     0xaf9fa4: str             q1, [SP, #-0x10]!
    // 0xaf9fa8: stp             x0, x1, [SP, #-0x10]!
    // 0xaf9fac: r0 = AllocateDouble()
    //     0xaf9fac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaf9fb0: mov             x2, x0
    // 0xaf9fb4: ldp             x0, x1, [SP], #0x10
    // 0xaf9fb8: RestoreReg d1
    //     0xaf9fb8: ldr             q1, [SP], #0x10
    // 0xaf9fbc: b               #0xaf9f48
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6952c, size: 0x120
    // 0xc6952c: EnterFrame
    //     0xc6952c: stp             fp, lr, [SP, #-0x10]!
    //     0xc69530: mov             fp, SP
    // 0xc69534: CheckStackOverflow
    //     0xc69534: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc69538: cmp             SP, x16
    //     0xc6953c: b.ls            #0xc69644
    // 0xc69540: ldr             x0, [fp, #0x10]
    // 0xc69544: cmp             w0, NULL
    // 0xc69548: b.ne            #0xc6955c
    // 0xc6954c: r0 = false
    //     0xc6954c: add             x0, NULL, #0x30  ; false
    // 0xc69550: LeaveFrame
    //     0xc69550: mov             SP, fp
    //     0xc69554: ldp             fp, lr, [SP], #0x10
    // 0xc69558: ret
    //     0xc69558: ret             
    // 0xc6955c: ldr             x1, [fp, #0x18]
    // 0xc69560: cmp             w1, w0
    // 0xc69564: b.ne            #0xc69570
    // 0xc69568: r0 = true
    //     0xc69568: add             x0, NULL, #0x20  ; true
    // 0xc6956c: b               #0xc69638
    // 0xc69570: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc69570: mov             x2, #0x76
    //     0xc69574: tbz             w0, #0, #0xc69584
    //     0xc69578: ldur            x2, [x0, #-1]
    //     0xc6957c: ubfx            x2, x2, #0xc, #0x14
    //     0xc69580: lsl             x2, x2, #1
    // 0xc69584: r17 = 9932
    //     0xc69584: mov             x17, #0x26cc
    // 0xc69588: cmp             w2, w17
    // 0xc6958c: b.ne            #0xc69634
    // 0xc69590: cmp             w1, w0
    // 0xc69594: b.eq            #0xc695d0
    // 0xc69598: r16 = CameraResolutionChangedEvent
    //     0xc69598: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cd0] Type: CameraResolutionChangedEvent
    //     0xc6959c: ldr             x16, [x16, #0xcd0]
    // 0xc695a0: r30 = CameraResolutionChangedEvent
    //     0xc695a0: add             lr, PP, #0x55, lsl #12  ; [pp+0x55cd0] Type: CameraResolutionChangedEvent
    //     0xc695a4: ldr             lr, [lr, #0xcd0]
    // 0xc695a8: stp             lr, x16, [SP, #-0x10]!
    // 0xc695ac: r0 = ==()
    //     0xc695ac: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc695b0: add             SP, SP, #0x10
    // 0xc695b4: tbnz            w0, #4, #0xc69634
    // 0xc695b8: ldr             x1, [fp, #0x18]
    // 0xc695bc: ldr             x0, [fp, #0x10]
    // 0xc695c0: LoadField: r2 = r1->field_7
    //     0xc695c0: ldur            x2, [x1, #7]
    // 0xc695c4: LoadField: r3 = r0->field_7
    //     0xc695c4: ldur            x3, [x0, #7]
    // 0xc695c8: cmp             x2, x3
    // 0xc695cc: b.ne            #0xc69634
    // 0xc695d0: r16 = CameraResolutionChangedEvent
    //     0xc695d0: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cd0] Type: CameraResolutionChangedEvent
    //     0xc695d4: ldr             x16, [x16, #0xcd0]
    // 0xc695d8: r30 = CameraResolutionChangedEvent
    //     0xc695d8: add             lr, PP, #0x55, lsl #12  ; [pp+0x55cd0] Type: CameraResolutionChangedEvent
    //     0xc695dc: ldr             lr, [lr, #0xcd0]
    // 0xc695e0: stp             lr, x16, [SP, #-0x10]!
    // 0xc695e4: r0 = ==()
    //     0xc695e4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc695e8: add             SP, SP, #0x10
    // 0xc695ec: tbnz            w0, #4, #0xc69634
    // 0xc695f0: ldr             x2, [fp, #0x18]
    // 0xc695f4: ldr             x1, [fp, #0x10]
    // 0xc695f8: LoadField: d0 = r2->field_f
    //     0xc695f8: ldur            d0, [x2, #0xf]
    // 0xc695fc: LoadField: d1 = r1->field_f
    //     0xc695fc: ldur            d1, [x1, #0xf]
    // 0xc69600: fcmp            d0, d1
    // 0xc69604: b.vs            #0xc69634
    // 0xc69608: b.ne            #0xc69634
    // 0xc6960c: LoadField: d0 = r2->field_17
    //     0xc6960c: ldur            d0, [x2, #0x17]
    // 0xc69610: LoadField: d1 = r1->field_17
    //     0xc69610: ldur            d1, [x1, #0x17]
    // 0xc69614: fcmp            d0, d1
    // 0xc69618: b.vs            #0xc69620
    // 0xc6961c: b.eq            #0xc69628
    // 0xc69620: r1 = false
    //     0xc69620: add             x1, NULL, #0x30  ; false
    // 0xc69624: b               #0xc6962c
    // 0xc69628: r1 = true
    //     0xc69628: add             x1, NULL, #0x20  ; true
    // 0xc6962c: mov             x0, x1
    // 0xc69630: b               #0xc69638
    // 0xc69634: r0 = false
    //     0xc69634: add             x0, NULL, #0x30  ; false
    // 0xc69638: LeaveFrame
    //     0xc69638: mov             SP, fp
    //     0xc6963c: ldp             fp, lr, [SP], #0x10
    // 0xc69640: ret
    //     0xc69640: ret             
    // 0xc69644: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69644: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc69648: b               #0xc69540
  }
}

// class id: 4967, size: 0x30, field offset: 0x10
//   const constructor, 
class CameraInitializedEvent extends CameraEvent {

  Map<String, dynamic> toJson(CameraInitializedEvent) {
    // ** addr: 0x5ab4b4, size: 0x288
    // 0x5ab4b4: EnterFrame
    //     0x5ab4b4: stp             fp, lr, [SP, #-0x10]!
    //     0x5ab4b8: mov             fp, SP
    // 0x5ab4bc: CheckStackOverflow
    //     0x5ab4bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5ab4c0: cmp             SP, x16
    //     0x5ab4c4: b.ls            #0x5ab6ec
    // 0x5ab4c8: r1 = Null
    //     0x5ab4c8: mov             x1, NULL
    // 0x5ab4cc: r2 = 28
    //     0x5ab4cc: mov             x2, #0x1c
    // 0x5ab4d0: r0 = AllocateArray()
    //     0x5ab4d0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5ab4d4: mov             x2, x0
    // 0x5ab4d8: r17 = "cameraId"
    //     0x5ab4d8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d890] "cameraId"
    //     0x5ab4dc: ldr             x17, [x17, #0x890]
    // 0x5ab4e0: StoreField: r2->field_f = r17
    //     0x5ab4e0: stur            w17, [x2, #0xf]
    // 0x5ab4e4: ldr             x3, [fp, #0x10]
    // 0x5ab4e8: LoadField: r4 = r3->field_7
    //     0x5ab4e8: ldur            x4, [x3, #7]
    // 0x5ab4ec: r0 = BoxInt64Instr(r4)
    //     0x5ab4ec: sbfiz           x0, x4, #1, #0x1f
    //     0x5ab4f0: cmp             x4, x0, asr #1
    //     0x5ab4f4: b.eq            #0x5ab500
    //     0x5ab4f8: bl              #0xd69bb8
    //     0x5ab4fc: stur            x4, [x0, #7]
    // 0x5ab500: mov             x1, x2
    // 0x5ab504: ArrayStore: r1[1] = r0  ; List_4
    //     0x5ab504: add             x25, x1, #0x13
    //     0x5ab508: str             w0, [x25]
    //     0x5ab50c: tbz             w0, #0, #0x5ab528
    //     0x5ab510: ldurb           w16, [x1, #-1]
    //     0x5ab514: ldurb           w17, [x0, #-1]
    //     0x5ab518: and             x16, x17, x16, lsr #2
    //     0x5ab51c: tst             x16, HEAP, lsr #32
    //     0x5ab520: b.eq            #0x5ab528
    //     0x5ab524: bl              #0xd67e5c
    // 0x5ab528: r17 = "previewWidth"
    //     0x5ab528: add             x17, PP, #0x53, lsl #12  ; [pp+0x53cd8] "previewWidth"
    //     0x5ab52c: ldr             x17, [x17, #0xcd8]
    // 0x5ab530: StoreField: r2->field_17 = r17
    //     0x5ab530: stur            w17, [x2, #0x17]
    // 0x5ab534: LoadField: d0 = r3->field_f
    //     0x5ab534: ldur            d0, [x3, #0xf]
    // 0x5ab538: r0 = inline_Allocate_Double()
    //     0x5ab538: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5ab53c: add             x0, x0, #0x10
    //     0x5ab540: cmp             x1, x0
    //     0x5ab544: b.ls            #0x5ab6f4
    //     0x5ab548: str             x0, [THR, #0x60]  ; THR::top
    //     0x5ab54c: sub             x0, x0, #0xf
    //     0x5ab550: mov             x1, #0xd108
    //     0x5ab554: movk            x1, #3, lsl #16
    //     0x5ab558: stur            x1, [x0, #-1]
    // 0x5ab55c: StoreField: r0->field_7 = d0
    //     0x5ab55c: stur            d0, [x0, #7]
    // 0x5ab560: mov             x1, x2
    // 0x5ab564: ArrayStore: r1[3] = r0  ; List_4
    //     0x5ab564: add             x25, x1, #0x1b
    //     0x5ab568: str             w0, [x25]
    //     0x5ab56c: tbz             w0, #0, #0x5ab588
    //     0x5ab570: ldurb           w16, [x1, #-1]
    //     0x5ab574: ldurb           w17, [x0, #-1]
    //     0x5ab578: and             x16, x17, x16, lsr #2
    //     0x5ab57c: tst             x16, HEAP, lsr #32
    //     0x5ab580: b.eq            #0x5ab588
    //     0x5ab584: bl              #0xd67e5c
    // 0x5ab588: r17 = "previewHeight"
    //     0x5ab588: add             x17, PP, #0x53, lsl #12  ; [pp+0x53cf0] "previewHeight"
    //     0x5ab58c: ldr             x17, [x17, #0xcf0]
    // 0x5ab590: StoreField: r2->field_1f = r17
    //     0x5ab590: stur            w17, [x2, #0x1f]
    // 0x5ab594: LoadField: d0 = r3->field_17
    //     0x5ab594: ldur            d0, [x3, #0x17]
    // 0x5ab598: r0 = inline_Allocate_Double()
    //     0x5ab598: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5ab59c: add             x0, x0, #0x10
    //     0x5ab5a0: cmp             x1, x0
    //     0x5ab5a4: b.ls            #0x5ab70c
    //     0x5ab5a8: str             x0, [THR, #0x60]  ; THR::top
    //     0x5ab5ac: sub             x0, x0, #0xf
    //     0x5ab5b0: mov             x1, #0xd108
    //     0x5ab5b4: movk            x1, #3, lsl #16
    //     0x5ab5b8: stur            x1, [x0, #-1]
    // 0x5ab5bc: StoreField: r0->field_7 = d0
    //     0x5ab5bc: stur            d0, [x0, #7]
    // 0x5ab5c0: mov             x1, x2
    // 0x5ab5c4: ArrayStore: r1[5] = r0  ; List_4
    //     0x5ab5c4: add             x25, x1, #0x23
    //     0x5ab5c8: str             w0, [x25]
    //     0x5ab5cc: tbz             w0, #0, #0x5ab5e8
    //     0x5ab5d0: ldurb           w16, [x1, #-1]
    //     0x5ab5d4: ldurb           w17, [x0, #-1]
    //     0x5ab5d8: and             x16, x17, x16, lsr #2
    //     0x5ab5dc: tst             x16, HEAP, lsr #32
    //     0x5ab5e0: b.eq            #0x5ab5e8
    //     0x5ab5e4: bl              #0xd67e5c
    // 0x5ab5e8: r17 = "exposureMode"
    //     0x5ab5e8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d478] "exposureMode"
    //     0x5ab5ec: ldr             x17, [x17, #0x478]
    // 0x5ab5f0: StoreField: r2->field_27 = r17
    //     0x5ab5f0: stur            w17, [x2, #0x27]
    // 0x5ab5f4: LoadField: r0 = r3->field_1f
    //     0x5ab5f4: ldur            w0, [x3, #0x1f]
    // 0x5ab5f8: DecompressPointer r0
    //     0x5ab5f8: add             x0, x0, HEAP, lsl #32
    // 0x5ab5fc: LoadField: r1 = r0->field_7
    //     0x5ab5fc: ldur            x1, [x0, #7]
    // 0x5ab600: cmp             x1, #0
    // 0x5ab604: b.gt            #0x5ab614
    // 0x5ab608: r0 = "auto"
    //     0x5ab608: add             x0, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x5ab60c: ldr             x0, [x0, #0x7d0]
    // 0x5ab610: b               #0x5ab61c
    // 0x5ab614: r0 = "locked"
    //     0x5ab614: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0x5ab618: ldr             x0, [x0, #0x978]
    // 0x5ab61c: mov             x1, x2
    // 0x5ab620: ArrayStore: r1[7] = r0  ; List_4
    //     0x5ab620: add             x25, x1, #0x2b
    //     0x5ab624: str             w0, [x25]
    //     0x5ab628: tbz             w0, #0, #0x5ab644
    //     0x5ab62c: ldurb           w16, [x1, #-1]
    //     0x5ab630: ldurb           w17, [x0, #-1]
    //     0x5ab634: and             x16, x17, x16, lsr #2
    //     0x5ab638: tst             x16, HEAP, lsr #32
    //     0x5ab63c: b.eq            #0x5ab644
    //     0x5ab640: bl              #0xd67e5c
    // 0x5ab644: r17 = "exposurePointSupported"
    //     0x5ab644: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d480] "exposurePointSupported"
    //     0x5ab648: ldr             x17, [x17, #0x480]
    // 0x5ab64c: StoreField: r2->field_2f = r17
    //     0x5ab64c: stur            w17, [x2, #0x2f]
    // 0x5ab650: LoadField: r0 = r3->field_27
    //     0x5ab650: ldur            w0, [x3, #0x27]
    // 0x5ab654: DecompressPointer r0
    //     0x5ab654: add             x0, x0, HEAP, lsl #32
    // 0x5ab658: StoreField: r2->field_33 = r0
    //     0x5ab658: stur            w0, [x2, #0x33]
    // 0x5ab65c: r17 = "focusMode"
    //     0x5ab65c: add             x17, PP, #0x45, lsl #12  ; [pp+0x45988] "focusMode"
    //     0x5ab660: ldr             x17, [x17, #0x988]
    // 0x5ab664: StoreField: r2->field_37 = r17
    //     0x5ab664: stur            w17, [x2, #0x37]
    // 0x5ab668: LoadField: r0 = r3->field_23
    //     0x5ab668: ldur            w0, [x3, #0x23]
    // 0x5ab66c: DecompressPointer r0
    //     0x5ab66c: add             x0, x0, HEAP, lsl #32
    // 0x5ab670: LoadField: r1 = r0->field_7
    //     0x5ab670: ldur            x1, [x0, #7]
    // 0x5ab674: cmp             x1, #0
    // 0x5ab678: b.gt            #0x5ab688
    // 0x5ab67c: r0 = "auto"
    //     0x5ab67c: add             x0, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0x5ab680: ldr             x0, [x0, #0x7d0]
    // 0x5ab684: b               #0x5ab690
    // 0x5ab688: r0 = "locked"
    //     0x5ab688: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0x5ab68c: ldr             x0, [x0, #0x978]
    // 0x5ab690: mov             x1, x2
    // 0x5ab694: ArrayStore: r1[11] = r0  ; List_4
    //     0x5ab694: add             x25, x1, #0x3b
    //     0x5ab698: str             w0, [x25]
    //     0x5ab69c: tbz             w0, #0, #0x5ab6b8
    //     0x5ab6a0: ldurb           w16, [x1, #-1]
    //     0x5ab6a4: ldurb           w17, [x0, #-1]
    //     0x5ab6a8: and             x16, x17, x16, lsr #2
    //     0x5ab6ac: tst             x16, HEAP, lsr #32
    //     0x5ab6b0: b.eq            #0x5ab6b8
    //     0x5ab6b4: bl              #0xd67e5c
    // 0x5ab6b8: r17 = "focusPointSupported"
    //     0x5ab6b8: add             x17, PP, #0x4d, lsl #12  ; [pp+0x4d490] "focusPointSupported"
    //     0x5ab6bc: ldr             x17, [x17, #0x490]
    // 0x5ab6c0: StoreField: r2->field_3f = r17
    //     0x5ab6c0: stur            w17, [x2, #0x3f]
    // 0x5ab6c4: LoadField: r0 = r3->field_2b
    //     0x5ab6c4: ldur            w0, [x3, #0x2b]
    // 0x5ab6c8: DecompressPointer r0
    //     0x5ab6c8: add             x0, x0, HEAP, lsl #32
    // 0x5ab6cc: StoreField: r2->field_43 = r0
    //     0x5ab6cc: stur            w0, [x2, #0x43]
    // 0x5ab6d0: r16 = <String, Object>
    //     0x5ab6d0: ldr             x16, [PP, #0x28e8]  ; [pp+0x28e8] TypeArguments: <String, Object>
    // 0x5ab6d4: stp             x2, x16, [SP, #-0x10]!
    // 0x5ab6d8: r0 = Map._fromLiteral()
    //     0x5ab6d8: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5ab6dc: add             SP, SP, #0x10
    // 0x5ab6e0: LeaveFrame
    //     0x5ab6e0: mov             SP, fp
    //     0x5ab6e4: ldp             fp, lr, [SP], #0x10
    // 0x5ab6e8: ret
    //     0x5ab6e8: ret             
    // 0x5ab6ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5ab6ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5ab6f0: b               #0x5ab4c8
    // 0x5ab6f4: SaveReg d0
    //     0x5ab6f4: str             q0, [SP, #-0x10]!
    // 0x5ab6f8: stp             x2, x3, [SP, #-0x10]!
    // 0x5ab6fc: r0 = AllocateDouble()
    //     0x5ab6fc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5ab700: ldp             x2, x3, [SP], #0x10
    // 0x5ab704: RestoreReg d0
    //     0x5ab704: ldr             q0, [SP], #0x10
    // 0x5ab708: b               #0x5ab55c
    // 0x5ab70c: SaveReg d0
    //     0x5ab70c: str             q0, [SP, #-0x10]!
    // 0x5ab710: stp             x2, x3, [SP, #-0x10]!
    // 0x5ab714: r0 = AllocateDouble()
    //     0x5ab714: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5ab718: ldp             x2, x3, [SP], #0x10
    // 0x5ab71c: RestoreReg d0
    //     0x5ab71c: ldr             q0, [SP], #0x10
    // 0x5ab720: b               #0x5ab5bc
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xaf9d50, size: 0x178
    // 0xaf9d50: EnterFrame
    //     0xaf9d50: stp             fp, lr, [SP, #-0x10]!
    //     0xaf9d54: mov             fp, SP
    // 0xaf9d58: CheckStackOverflow
    //     0xaf9d58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xaf9d5c: cmp             SP, x16
    //     0xaf9d60: b.ls            #0xaf9e6c
    // 0xaf9d64: ldr             x2, [fp, #0x10]
    // 0xaf9d68: LoadField: r3 = r2->field_7
    //     0xaf9d68: ldur            x3, [x2, #7]
    // 0xaf9d6c: r0 = BoxInt64Instr(r3)
    //     0xaf9d6c: sbfiz           x0, x3, #1, #0x1f
    //     0xaf9d70: cmp             x3, x0, asr #1
    //     0xaf9d74: b.eq            #0xaf9d80
    //     0xaf9d78: bl              #0xd69bb8
    //     0xaf9d7c: stur            x3, [x0, #7]
    // 0xaf9d80: r1 = 59
    //     0xaf9d80: mov             x1, #0x3b
    // 0xaf9d84: branchIfSmi(r0, 0xaf9d90)
    //     0xaf9d84: tbz             w0, #0, #0xaf9d90
    // 0xaf9d88: r1 = LoadClassIdInstr(r0)
    //     0xaf9d88: ldur            x1, [x0, #-1]
    //     0xaf9d8c: ubfx            x1, x1, #0xc, #0x14
    // 0xaf9d90: SaveReg r0
    //     0xaf9d90: str             x0, [SP, #-8]!
    // 0xaf9d94: mov             x0, x1
    // 0xaf9d98: r0 = GDT[cid_x0 + 0x2721]()
    //     0xaf9d98: mov             x17, #0x2721
    //     0xaf9d9c: add             lr, x0, x17
    //     0xaf9da0: ldr             lr, [x21, lr, lsl #3]
    //     0xaf9da4: blr             lr
    // 0xaf9da8: add             SP, SP, #8
    // 0xaf9dac: mov             x1, x0
    // 0xaf9db0: ldr             x0, [fp, #0x10]
    // 0xaf9db4: LoadField: d0 = r0->field_f
    //     0xaf9db4: ldur            d0, [x0, #0xf]
    // 0xaf9db8: LoadField: d1 = r0->field_17
    //     0xaf9db8: ldur            d1, [x0, #0x17]
    // 0xaf9dbc: LoadField: r2 = r0->field_1f
    //     0xaf9dbc: ldur            w2, [x0, #0x1f]
    // 0xaf9dc0: DecompressPointer r2
    //     0xaf9dc0: add             x2, x2, HEAP, lsl #32
    // 0xaf9dc4: LoadField: r3 = r0->field_27
    //     0xaf9dc4: ldur            w3, [x0, #0x27]
    // 0xaf9dc8: DecompressPointer r3
    //     0xaf9dc8: add             x3, x3, HEAP, lsl #32
    // 0xaf9dcc: LoadField: r4 = r0->field_23
    //     0xaf9dcc: ldur            w4, [x0, #0x23]
    // 0xaf9dd0: DecompressPointer r4
    //     0xaf9dd0: add             x4, x4, HEAP, lsl #32
    // 0xaf9dd4: LoadField: r5 = r0->field_2b
    //     0xaf9dd4: ldur            w5, [x0, #0x2b]
    // 0xaf9dd8: DecompressPointer r5
    //     0xaf9dd8: add             x5, x5, HEAP, lsl #32
    // 0xaf9ddc: r0 = inline_Allocate_Double()
    //     0xaf9ddc: ldp             x0, x6, [THR, #0x60]  ; THR::top
    //     0xaf9de0: add             x0, x0, #0x10
    //     0xaf9de4: cmp             x6, x0
    //     0xaf9de8: b.ls            #0xaf9e74
    //     0xaf9dec: str             x0, [THR, #0x60]  ; THR::top
    //     0xaf9df0: sub             x0, x0, #0xf
    //     0xaf9df4: mov             x6, #0xd108
    //     0xaf9df8: movk            x6, #3, lsl #16
    //     0xaf9dfc: stur            x6, [x0, #-1]
    // 0xaf9e00: StoreField: r0->field_7 = d0
    //     0xaf9e00: stur            d0, [x0, #7]
    // 0xaf9e04: r6 = inline_Allocate_Double()
    //     0xaf9e04: ldp             x6, x7, [THR, #0x60]  ; THR::top
    //     0xaf9e08: add             x6, x6, #0x10
    //     0xaf9e0c: cmp             x7, x6
    //     0xaf9e10: b.ls            #0xaf9e9c
    //     0xaf9e14: str             x6, [THR, #0x60]  ; THR::top
    //     0xaf9e18: sub             x6, x6, #0xf
    //     0xaf9e1c: mov             x7, #0xd108
    //     0xaf9e20: movk            x7, #3, lsl #16
    //     0xaf9e24: stur            x7, [x6, #-1]
    // 0xaf9e28: StoreField: r6->field_7 = d1
    //     0xaf9e28: stur            d1, [x6, #7]
    // 0xaf9e2c: stp             x0, x1, [SP, #-0x10]!
    // 0xaf9e30: stp             x2, x6, [SP, #-0x10]!
    // 0xaf9e34: stp             x4, x3, [SP, #-0x10]!
    // 0xaf9e38: SaveReg r5
    //     0xaf9e38: str             x5, [SP, #-8]!
    // 0xaf9e3c: r4 = const [0, 0x7, 0x7, 0x7, null]
    //     0xaf9e3c: ldr             x4, [PP, #0x2450]  ; [pp+0x2450] List(5) [0, 0x7, 0x7, 0x7, Null]
    // 0xaf9e40: r0 = hash()
    //     0xaf9e40: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xaf9e44: add             SP, SP, #0x38
    // 0xaf9e48: mov             x2, x0
    // 0xaf9e4c: r0 = BoxInt64Instr(r2)
    //     0xaf9e4c: sbfiz           x0, x2, #1, #0x1f
    //     0xaf9e50: cmp             x2, x0, asr #1
    //     0xaf9e54: b.eq            #0xaf9e60
    //     0xaf9e58: bl              #0xd69bb8
    //     0xaf9e5c: stur            x2, [x0, #7]
    // 0xaf9e60: LeaveFrame
    //     0xaf9e60: mov             SP, fp
    //     0xaf9e64: ldp             fp, lr, [SP], #0x10
    // 0xaf9e68: ret
    //     0xaf9e68: ret             
    // 0xaf9e6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xaf9e6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xaf9e70: b               #0xaf9d64
    // 0xaf9e74: stp             q0, q1, [SP, #-0x20]!
    // 0xaf9e78: stp             x4, x5, [SP, #-0x10]!
    // 0xaf9e7c: stp             x2, x3, [SP, #-0x10]!
    // 0xaf9e80: SaveReg r1
    //     0xaf9e80: str             x1, [SP, #-8]!
    // 0xaf9e84: r0 = AllocateDouble()
    //     0xaf9e84: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaf9e88: RestoreReg r1
    //     0xaf9e88: ldr             x1, [SP], #8
    // 0xaf9e8c: ldp             x2, x3, [SP], #0x10
    // 0xaf9e90: ldp             x4, x5, [SP], #0x10
    // 0xaf9e94: ldp             q0, q1, [SP], #0x20
    // 0xaf9e98: b               #0xaf9e00
    // 0xaf9e9c: SaveReg d1
    //     0xaf9e9c: str             q1, [SP, #-0x10]!
    // 0xaf9ea0: stp             x4, x5, [SP, #-0x10]!
    // 0xaf9ea4: stp             x2, x3, [SP, #-0x10]!
    // 0xaf9ea8: stp             x0, x1, [SP, #-0x10]!
    // 0xaf9eac: r0 = AllocateDouble()
    //     0xaf9eac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xaf9eb0: mov             x6, x0
    // 0xaf9eb4: ldp             x0, x1, [SP], #0x10
    // 0xaf9eb8: ldp             x2, x3, [SP], #0x10
    // 0xaf9ebc: ldp             x4, x5, [SP], #0x10
    // 0xaf9ec0: RestoreReg d1
    //     0xaf9ec0: ldr             q1, [SP], #0x10
    // 0xaf9ec4: b               #0xaf9e28
  }
  _ ==(/* No info */) {
    // ** addr: 0xc692d0, size: 0x1b0
    // 0xc692d0: EnterFrame
    //     0xc692d0: stp             fp, lr, [SP, #-0x10]!
    //     0xc692d4: mov             fp, SP
    // 0xc692d8: CheckStackOverflow
    //     0xc692d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc692dc: cmp             SP, x16
    //     0xc692e0: b.ls            #0xc69478
    // 0xc692e4: ldr             x0, [fp, #0x10]
    // 0xc692e8: cmp             w0, NULL
    // 0xc692ec: b.ne            #0xc69300
    // 0xc692f0: r0 = false
    //     0xc692f0: add             x0, NULL, #0x30  ; false
    // 0xc692f4: LeaveFrame
    //     0xc692f4: mov             SP, fp
    //     0xc692f8: ldp             fp, lr, [SP], #0x10
    // 0xc692fc: ret
    //     0xc692fc: ret             
    // 0xc69300: ldr             x1, [fp, #0x18]
    // 0xc69304: cmp             w1, w0
    // 0xc69308: b.ne            #0xc69314
    // 0xc6930c: r0 = true
    //     0xc6930c: add             x0, NULL, #0x20  ; true
    // 0xc69310: b               #0xc6946c
    // 0xc69314: cmp             w1, w0
    // 0xc69318: b.eq            #0xc69388
    // 0xc6931c: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6931c: mov             x2, #0x76
    //     0xc69320: tbz             w0, #0, #0xc69330
    //     0xc69324: ldur            x2, [x0, #-1]
    //     0xc69328: ubfx            x2, x2, #0xc, #0x14
    //     0xc6932c: lsl             x2, x2, #1
    // 0xc69330: r3 = LoadInt32Instr(r2)
    //     0xc69330: sbfx            x3, x2, #1, #0x1f
    // 0xc69334: r17 = 4963
    //     0xc69334: mov             x17, #0x1363
    // 0xc69338: cmp             x3, x17
    // 0xc6933c: b.lt            #0xc69468
    // 0xc69340: r17 = 4967
    //     0xc69340: mov             x17, #0x1367
    // 0xc69344: cmp             x3, x17
    // 0xc69348: b.gt            #0xc69468
    // 0xc6934c: SaveReg r0
    //     0xc6934c: str             x0, [SP, #-8]!
    // 0xc69350: r0 = runtimeType()
    //     0xc69350: bl              #0xab3eb0  ; [dart:core] Object::runtimeType
    // 0xc69354: add             SP, SP, #8
    // 0xc69358: r16 = CameraInitializedEvent
    //     0xc69358: add             x16, PP, #0x55, lsl #12  ; [pp+0x55ce8] Type: CameraInitializedEvent
    //     0xc6935c: ldr             x16, [x16, #0xce8]
    // 0xc69360: stp             x0, x16, [SP, #-0x10]!
    // 0xc69364: r0 = ==()
    //     0xc69364: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc69368: add             SP, SP, #0x10
    // 0xc6936c: tbnz            w0, #4, #0xc69468
    // 0xc69370: ldr             x1, [fp, #0x18]
    // 0xc69374: ldr             x0, [fp, #0x10]
    // 0xc69378: LoadField: r2 = r1->field_7
    //     0xc69378: ldur            x2, [x1, #7]
    // 0xc6937c: LoadField: r3 = r0->field_7
    //     0xc6937c: ldur            x3, [x0, #7]
    // 0xc69380: cmp             x2, x3
    // 0xc69384: b.ne            #0xc69468
    // 0xc69388: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc69388: mov             x2, #0x76
    //     0xc6938c: tbz             w0, #0, #0xc6939c
    //     0xc69390: ldur            x2, [x0, #-1]
    //     0xc69394: ubfx            x2, x2, #0xc, #0x14
    //     0xc69398: lsl             x2, x2, #1
    // 0xc6939c: r17 = 9934
    //     0xc6939c: mov             x17, #0x26ce
    // 0xc693a0: cmp             w2, w17
    // 0xc693a4: b.ne            #0xc69468
    // 0xc693a8: r16 = CameraInitializedEvent
    //     0xc693a8: add             x16, PP, #0x55, lsl #12  ; [pp+0x55ce8] Type: CameraInitializedEvent
    //     0xc693ac: ldr             x16, [x16, #0xce8]
    // 0xc693b0: r30 = CameraInitializedEvent
    //     0xc693b0: add             lr, PP, #0x55, lsl #12  ; [pp+0x55ce8] Type: CameraInitializedEvent
    //     0xc693b4: ldr             lr, [lr, #0xce8]
    // 0xc693b8: stp             lr, x16, [SP, #-0x10]!
    // 0xc693bc: r0 = ==()
    //     0xc693bc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc693c0: add             SP, SP, #0x10
    // 0xc693c4: tbnz            w0, #4, #0xc69468
    // 0xc693c8: ldr             x2, [fp, #0x18]
    // 0xc693cc: ldr             x1, [fp, #0x10]
    // 0xc693d0: LoadField: d0 = r2->field_f
    //     0xc693d0: ldur            d0, [x2, #0xf]
    // 0xc693d4: LoadField: d1 = r1->field_f
    //     0xc693d4: ldur            d1, [x1, #0xf]
    // 0xc693d8: fcmp            d0, d1
    // 0xc693dc: b.vs            #0xc69468
    // 0xc693e0: b.ne            #0xc69468
    // 0xc693e4: LoadField: d0 = r2->field_17
    //     0xc693e4: ldur            d0, [x2, #0x17]
    // 0xc693e8: LoadField: d1 = r1->field_17
    //     0xc693e8: ldur            d1, [x1, #0x17]
    // 0xc693ec: fcmp            d0, d1
    // 0xc693f0: b.vs            #0xc69468
    // 0xc693f4: b.ne            #0xc69468
    // 0xc693f8: LoadField: r3 = r2->field_1f
    //     0xc693f8: ldur            w3, [x2, #0x1f]
    // 0xc693fc: DecompressPointer r3
    //     0xc693fc: add             x3, x3, HEAP, lsl #32
    // 0xc69400: LoadField: r4 = r1->field_1f
    //     0xc69400: ldur            w4, [x1, #0x1f]
    // 0xc69404: DecompressPointer r4
    //     0xc69404: add             x4, x4, HEAP, lsl #32
    // 0xc69408: cmp             w3, w4
    // 0xc6940c: b.ne            #0xc69468
    // 0xc69410: LoadField: r3 = r2->field_27
    //     0xc69410: ldur            w3, [x2, #0x27]
    // 0xc69414: DecompressPointer r3
    //     0xc69414: add             x3, x3, HEAP, lsl #32
    // 0xc69418: LoadField: r4 = r1->field_27
    //     0xc69418: ldur            w4, [x1, #0x27]
    // 0xc6941c: DecompressPointer r4
    //     0xc6941c: add             x4, x4, HEAP, lsl #32
    // 0xc69420: cmp             w3, w4
    // 0xc69424: b.ne            #0xc69468
    // 0xc69428: LoadField: r3 = r2->field_23
    //     0xc69428: ldur            w3, [x2, #0x23]
    // 0xc6942c: DecompressPointer r3
    //     0xc6942c: add             x3, x3, HEAP, lsl #32
    // 0xc69430: LoadField: r4 = r1->field_23
    //     0xc69430: ldur            w4, [x1, #0x23]
    // 0xc69434: DecompressPointer r4
    //     0xc69434: add             x4, x4, HEAP, lsl #32
    // 0xc69438: cmp             w3, w4
    // 0xc6943c: b.ne            #0xc69468
    // 0xc69440: LoadField: r3 = r2->field_2b
    //     0xc69440: ldur            w3, [x2, #0x2b]
    // 0xc69444: DecompressPointer r3
    //     0xc69444: add             x3, x3, HEAP, lsl #32
    // 0xc69448: LoadField: r2 = r1->field_2b
    //     0xc69448: ldur            w2, [x1, #0x2b]
    // 0xc6944c: DecompressPointer r2
    //     0xc6944c: add             x2, x2, HEAP, lsl #32
    // 0xc69450: cmp             w3, w2
    // 0xc69454: r16 = true
    //     0xc69454: add             x16, NULL, #0x20  ; true
    // 0xc69458: r17 = false
    //     0xc69458: add             x17, NULL, #0x30  ; false
    // 0xc6945c: csel            x1, x16, x17, eq
    // 0xc69460: mov             x0, x1
    // 0xc69464: b               #0xc6946c
    // 0xc69468: r0 = false
    //     0xc69468: add             x0, NULL, #0x30  ; false
    // 0xc6946c: LeaveFrame
    //     0xc6946c: mov             SP, fp
    //     0xc69470: ldp             fp, lr, [SP], #0x10
    // 0xc69474: ret
    //     0xc69474: ret             
    // 0xc69478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6947c: b               #0xc692e4
  }
}

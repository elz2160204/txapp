// lib: , url: package:camera_platform_interface/src/events/device_event.dart

// class id: 1048714, size: 0x8
class :: {
}

// class id: 4960, size: 0x8, field offset: 0x8
//   const constructor, 
abstract class DeviceEvent extends Object {
}

// class id: 4961, size: 0xc, field offset: 0x8
//   const constructor, 
class DeviceOrientationChangedEvent extends DeviceEvent {

  Map<String, dynamic> toJson(DeviceOrientationChangedEvent) {
    // ** addr: 0x5a893c, size: 0xac
    // 0x5a893c: EnterFrame
    //     0x5a893c: stp             fp, lr, [SP, #-0x10]!
    //     0x5a8940: mov             fp, SP
    // 0x5a8944: CheckStackOverflow
    //     0x5a8944: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5a8948: cmp             SP, x16
    //     0x5a894c: b.ls            #0x5a89c8
    // 0x5a8950: r1 = Null
    //     0x5a8950: mov             x1, NULL
    // 0x5a8954: r2 = 4
    //     0x5a8954: mov             x2, #4
    // 0x5a8958: r0 = AllocateArray()
    //     0x5a8958: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5a895c: r17 = "orientation"
    //     0x5a895c: ldr             x17, [PP, #0xde0]  ; [pp+0xde0] "orientation"
    // 0x5a8960: StoreField: r0->field_f = r17
    //     0x5a8960: stur            w17, [x0, #0xf]
    // 0x5a8964: ldr             x1, [fp, #0x10]
    // 0x5a8968: LoadField: r2 = r1->field_7
    //     0x5a8968: ldur            w2, [x1, #7]
    // 0x5a896c: DecompressPointer r2
    //     0x5a896c: add             x2, x2, HEAP, lsl #32
    // 0x5a8970: LoadField: r1 = r2->field_7
    //     0x5a8970: ldur            x1, [x2, #7]
    // 0x5a8974: cmp             x1, #1
    // 0x5a8978: b.gt            #0x5a8994
    // 0x5a897c: cmp             x1, #0
    // 0x5a8980: b.gt            #0x5a898c
    // 0x5a8984: r1 = "portraitUp"
    //     0x5a8984: ldr             x1, [PP, #0xe20]  ; [pp+0xe20] "portraitUp"
    // 0x5a8988: b               #0x5a89a8
    // 0x5a898c: r1 = "landscapeLeft"
    //     0x5a898c: ldr             x1, [PP, #0xe50]  ; [pp+0xe50] "landscapeLeft"
    // 0x5a8990: b               #0x5a89a8
    // 0x5a8994: cmp             x1, #2
    // 0x5a8998: b.gt            #0x5a89a4
    // 0x5a899c: r1 = "portraitDown"
    //     0x5a899c: ldr             x1, [PP, #0xe30]  ; [pp+0xe30] "portraitDown"
    // 0x5a89a0: b               #0x5a89a8
    // 0x5a89a4: r1 = "landscapeRight"
    //     0x5a89a4: ldr             x1, [PP, #0xe40]  ; [pp+0xe40] "landscapeRight"
    // 0x5a89a8: StoreField: r0->field_13 = r1
    //     0x5a89a8: stur            w1, [x0, #0x13]
    // 0x5a89ac: r16 = <String, Object>
    //     0x5a89ac: ldr             x16, [PP, #0x28e8]  ; [pp+0x28e8] TypeArguments: <String, Object>
    // 0x5a89b0: stp             x0, x16, [SP, #-0x10]!
    // 0x5a89b4: r0 = Map._fromLiteral()
    //     0x5a89b4: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x5a89b8: add             SP, SP, #0x10
    // 0x5a89bc: LeaveFrame
    //     0x5a89bc: mov             SP, fp
    //     0x5a89c0: ldp             fp, lr, [SP], #0x10
    // 0x5a89c4: ret
    //     0x5a89c4: ret             
    // 0x5a89c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5a89c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5a89cc: b               #0x5a8950
  }
  _ ==(/* No info */) {
    // ** addr: 0xc69a78, size: 0xcc
    // 0xc69a78: EnterFrame
    //     0xc69a78: stp             fp, lr, [SP, #-0x10]!
    //     0xc69a7c: mov             fp, SP
    // 0xc69a80: CheckStackOverflow
    //     0xc69a80: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc69a84: cmp             SP, x16
    //     0xc69a88: b.ls            #0xc69b3c
    // 0xc69a8c: ldr             x0, [fp, #0x10]
    // 0xc69a90: cmp             w0, NULL
    // 0xc69a94: b.ne            #0xc69aa8
    // 0xc69a98: r0 = false
    //     0xc69a98: add             x0, NULL, #0x30  ; false
    // 0xc69a9c: LeaveFrame
    //     0xc69a9c: mov             SP, fp
    //     0xc69aa0: ldp             fp, lr, [SP], #0x10
    // 0xc69aa4: ret
    //     0xc69aa4: ret             
    // 0xc69aa8: ldr             x1, [fp, #0x18]
    // 0xc69aac: cmp             w1, w0
    // 0xc69ab0: b.ne            #0xc69abc
    // 0xc69ab4: r0 = true
    //     0xc69ab4: add             x0, NULL, #0x20  ; true
    // 0xc69ab8: b               #0xc69b30
    // 0xc69abc: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc69abc: mov             x2, #0x76
    //     0xc69ac0: tbz             w0, #0, #0xc69ad0
    //     0xc69ac4: ldur            x2, [x0, #-1]
    //     0xc69ac8: ubfx            x2, x2, #0xc, #0x14
    //     0xc69acc: lsl             x2, x2, #1
    // 0xc69ad0: r17 = 9922
    //     0xc69ad0: mov             x17, #0x26c2
    // 0xc69ad4: cmp             w2, w17
    // 0xc69ad8: b.ne            #0xc69b2c
    // 0xc69adc: r16 = DeviceOrientationChangedEvent
    //     0xc69adc: add             x16, PP, #8, lsl #12  ; [pp+0x8860] Type: DeviceOrientationChangedEvent
    //     0xc69ae0: ldr             x16, [x16, #0x860]
    // 0xc69ae4: r30 = DeviceOrientationChangedEvent
    //     0xc69ae4: add             lr, PP, #8, lsl #12  ; [pp+0x8860] Type: DeviceOrientationChangedEvent
    //     0xc69ae8: ldr             lr, [lr, #0x860]
    // 0xc69aec: stp             lr, x16, [SP, #-0x10]!
    // 0xc69af0: r0 = ==()
    //     0xc69af0: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc69af4: add             SP, SP, #0x10
    // 0xc69af8: tbnz            w0, #4, #0xc69b2c
    // 0xc69afc: ldr             x2, [fp, #0x18]
    // 0xc69b00: ldr             x1, [fp, #0x10]
    // 0xc69b04: LoadField: r3 = r2->field_7
    //     0xc69b04: ldur            w3, [x2, #7]
    // 0xc69b08: DecompressPointer r3
    //     0xc69b08: add             x3, x3, HEAP, lsl #32
    // 0xc69b0c: LoadField: r2 = r1->field_7
    //     0xc69b0c: ldur            w2, [x1, #7]
    // 0xc69b10: DecompressPointer r2
    //     0xc69b10: add             x2, x2, HEAP, lsl #32
    // 0xc69b14: cmp             w3, w2
    // 0xc69b18: r16 = true
    //     0xc69b18: add             x16, NULL, #0x20  ; true
    // 0xc69b1c: r17 = false
    //     0xc69b1c: add             x17, NULL, #0x30  ; false
    // 0xc69b20: csel            x1, x16, x17, eq
    // 0xc69b24: mov             x0, x1
    // 0xc69b28: b               #0xc69b30
    // 0xc69b2c: r0 = false
    //     0xc69b2c: add             x0, NULL, #0x30  ; false
    // 0xc69b30: LeaveFrame
    //     0xc69b30: mov             SP, fp
    //     0xc69b34: ldp             fp, lr, [SP], #0x10
    // 0xc69b38: ret
    //     0xc69b38: ret             
    // 0xc69b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc69b3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc69b40: b               #0xc69a8c
  }
}

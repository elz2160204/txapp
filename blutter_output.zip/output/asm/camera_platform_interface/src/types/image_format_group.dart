// lib: , url: package:camera_platform_interface/src/types/image_format_group.dart

// class id: 1048724, size: 0x8
class :: {
}

// class id: 6019, size: 0x14, field offset: 0x14
enum ImageFormatGroup extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb1510c, size: 0x5c
    // 0xb1510c: EnterFrame
    //     0xb1510c: stp             fp, lr, [SP, #-0x10]!
    //     0xb15110: mov             fp, SP
    // 0xb15114: CheckStackOverflow
    //     0xb15114: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15118: cmp             SP, x16
    //     0xb1511c: b.ls            #0xb15160
    // 0xb15120: r1 = Null
    //     0xb15120: mov             x1, NULL
    // 0xb15124: r2 = 4
    //     0xb15124: mov             x2, #4
    // 0xb15128: r0 = AllocateArray()
    //     0xb15128: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb1512c: r17 = "ImageFormatGroup."
    //     0xb1512c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca70] "ImageFormatGroup."
    //     0xb15130: ldr             x17, [x17, #0xa70]
    // 0xb15134: StoreField: r0->field_f = r17
    //     0xb15134: stur            w17, [x0, #0xf]
    // 0xb15138: ldr             x1, [fp, #0x10]
    // 0xb1513c: LoadField: r2 = r1->field_f
    //     0xb1513c: ldur            w2, [x1, #0xf]
    // 0xb15140: DecompressPointer r2
    //     0xb15140: add             x2, x2, HEAP, lsl #32
    // 0xb15144: StoreField: r0->field_13 = r2
    //     0xb15144: stur            w2, [x0, #0x13]
    // 0xb15148: SaveReg r0
    //     0xb15148: str             x0, [SP, #-8]!
    // 0xb1514c: r0 = _interpolate()
    //     0xb1514c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15150: add             SP, SP, #8
    // 0xb15154: LeaveFrame
    //     0xb15154: mov             SP, fp
    //     0xb15158: ldp             fp, lr, [SP], #0x10
    // 0xb1515c: ret
    //     0xb1515c: ret             
    // 0xb15160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15164: b               #0xb15120
  }
}

// lib: , url: package:camera_platform_interface/src/types/focus_mode.dart

// class id: 1048723, size: 0x8
class :: {

  static _ deserializeFocusMode(/* No info */) {
    // ** addr: 0xc77560, size: 0xe0
    // 0xc77560: EnterFrame
    //     0xc77560: stp             fp, lr, [SP, #-0x10]!
    //     0xc77564: mov             fp, SP
    // 0xc77568: AllocStack(0x8)
    //     0xc77568: sub             SP, SP, #8
    // 0xc7756c: CheckStackOverflow
    //     0xc7756c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc77570: cmp             SP, x16
    //     0xc77574: b.ls            #0xc77638
    // 0xc77578: r16 = "locked"
    //     0xc77578: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0xc7757c: ldr             x16, [x16, #0x978]
    // 0xc77580: ldr             lr, [fp, #0x10]
    // 0xc77584: stp             lr, x16, [SP, #-0x10]!
    // 0xc77588: r0 = ==()
    //     0xc77588: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc7758c: add             SP, SP, #0x10
    // 0xc77590: tbnz            w0, #4, #0xc775a8
    // 0xc77594: r0 = Instance_FocusMode
    //     0xc77594: add             x0, PP, #0x53, lsl #12  ; [pp+0x53dc0] Obj!FocusMode@b66af1
    //     0xc77598: ldr             x0, [x0, #0xdc0]
    // 0xc7759c: LeaveFrame
    //     0xc7759c: mov             SP, fp
    //     0xc775a0: ldp             fp, lr, [SP], #0x10
    // 0xc775a4: ret
    //     0xc775a4: ret             
    // 0xc775a8: r16 = "auto"
    //     0xc775a8: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0xc775ac: ldr             x16, [x16, #0x7d0]
    // 0xc775b0: ldr             lr, [fp, #0x10]
    // 0xc775b4: stp             lr, x16, [SP, #-0x10]!
    // 0xc775b8: r0 = ==()
    //     0xc775b8: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc775bc: add             SP, SP, #0x10
    // 0xc775c0: tbnz            w0, #4, #0xc775d8
    // 0xc775c4: r0 = Instance_FocusMode
    //     0xc775c4: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d568] Obj!FocusMode@b66ad1
    //     0xc775c8: ldr             x0, [x0, #0x568]
    // 0xc775cc: LeaveFrame
    //     0xc775cc: mov             SP, fp
    //     0xc775d0: ldp             fp, lr, [SP], #0x10
    // 0xc775d4: ret
    //     0xc775d4: ret             
    // 0xc775d8: ldr             x0, [fp, #0x10]
    // 0xc775dc: r1 = Null
    //     0xc775dc: mov             x1, NULL
    // 0xc775e0: r2 = 6
    //     0xc775e0: mov             x2, #6
    // 0xc775e4: r0 = AllocateArray()
    //     0xc775e4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc775e8: r17 = "\""
    //     0xc775e8: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0xc775ec: StoreField: r0->field_f = r17
    //     0xc775ec: stur            w17, [x0, #0xf]
    // 0xc775f0: ldr             x1, [fp, #0x10]
    // 0xc775f4: StoreField: r0->field_13 = r1
    //     0xc775f4: stur            w1, [x0, #0x13]
    // 0xc775f8: r17 = "\" is not a valid FocusMode value"
    //     0xc775f8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53dc8] "\" is not a valid FocusMode value"
    //     0xc775fc: ldr             x17, [x17, #0xdc8]
    // 0xc77600: StoreField: r0->field_17 = r17
    //     0xc77600: stur            w17, [x0, #0x17]
    // 0xc77604: SaveReg r0
    //     0xc77604: str             x0, [SP, #-8]!
    // 0xc77608: r0 = _interpolate()
    //     0xc77608: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc7760c: add             SP, SP, #8
    // 0xc77610: stur            x0, [fp, #-8]
    // 0xc77614: r0 = ArgumentError()
    //     0xc77614: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xc77618: mov             x1, x0
    // 0xc7761c: ldur            x0, [fp, #-8]
    // 0xc77620: StoreField: r1->field_17 = r0
    //     0xc77620: stur            w0, [x1, #0x17]
    // 0xc77624: r0 = false
    //     0xc77624: add             x0, NULL, #0x30  ; false
    // 0xc77628: StoreField: r1->field_b = r0
    //     0xc77628: stur            w0, [x1, #0xb]
    // 0xc7762c: mov             x0, x1
    // 0xc77630: r0 = Throw()
    //     0xc77630: bl              #0xd67e38  ; ThrowStub
    // 0xc77634: brk             #0
    // 0xc77638: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc77638: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7763c: b               #0xc77578
  }
}

// class id: 6020, size: 0x14, field offset: 0x14
enum FocusMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb150b0, size: 0x5c
    // 0xb150b0: EnterFrame
    //     0xb150b0: stp             fp, lr, [SP, #-0x10]!
    //     0xb150b4: mov             fp, SP
    // 0xb150b8: CheckStackOverflow
    //     0xb150b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb150bc: cmp             SP, x16
    //     0xb150c0: b.ls            #0xb15104
    // 0xb150c4: r1 = Null
    //     0xb150c4: mov             x1, NULL
    // 0xb150c8: r2 = 4
    //     0xb150c8: mov             x2, #4
    // 0xb150cc: r0 = AllocateArray()
    //     0xb150cc: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb150d0: r17 = "FocusMode."
    //     0xb150d0: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ab0] "FocusMode."
    //     0xb150d4: ldr             x17, [x17, #0xab0]
    // 0xb150d8: StoreField: r0->field_f = r17
    //     0xb150d8: stur            w17, [x0, #0xf]
    // 0xb150dc: ldr             x1, [fp, #0x10]
    // 0xb150e0: LoadField: r2 = r1->field_f
    //     0xb150e0: ldur            w2, [x1, #0xf]
    // 0xb150e4: DecompressPointer r2
    //     0xb150e4: add             x2, x2, HEAP, lsl #32
    // 0xb150e8: StoreField: r0->field_13 = r2
    //     0xb150e8: stur            w2, [x0, #0x13]
    // 0xb150ec: SaveReg r0
    //     0xb150ec: str             x0, [SP, #-8]!
    // 0xb150f0: r0 = _interpolate()
    //     0xb150f0: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb150f4: add             SP, SP, #8
    // 0xb150f8: LeaveFrame
    //     0xb150f8: mov             SP, fp
    //     0xb150fc: ldp             fp, lr, [SP], #0x10
    // 0xb15100: ret
    //     0xb15100: ret             
    // 0xb15104: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb15104: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15108: b               #0xb150c4
  }
}

// lib: , url: package:camera_platform_interface/src/types/camera_exception.dart

// class id: 1048719, size: 0x8
class :: {
}

// class id: 4896, size: 0x10, field offset: 0x8
class CameraException extends Object
    implements Exception {

  _ toString(/* No info */) {
    // ** addr: 0xac419c, size: 0x78
    // 0xac419c: EnterFrame
    //     0xac419c: stp             fp, lr, [SP, #-0x10]!
    //     0xac41a0: mov             fp, SP
    // 0xac41a4: CheckStackOverflow
    //     0xac41a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac41a8: cmp             SP, x16
    //     0xac41ac: b.ls            #0xac420c
    // 0xac41b0: r1 = Null
    //     0xac41b0: mov             x1, NULL
    // 0xac41b4: r2 = 10
    //     0xac41b4: mov             x2, #0xa
    // 0xac41b8: r0 = AllocateArray()
    //     0xac41b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xac41bc: r17 = "CameraException("
    //     0xac41bc: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ac0] "CameraException("
    //     0xac41c0: ldr             x17, [x17, #0xac0]
    // 0xac41c4: StoreField: r0->field_f = r17
    //     0xac41c4: stur            w17, [x0, #0xf]
    // 0xac41c8: ldr             x1, [fp, #0x10]
    // 0xac41cc: LoadField: r2 = r1->field_7
    //     0xac41cc: ldur            w2, [x1, #7]
    // 0xac41d0: DecompressPointer r2
    //     0xac41d0: add             x2, x2, HEAP, lsl #32
    // 0xac41d4: StoreField: r0->field_13 = r2
    //     0xac41d4: stur            w2, [x0, #0x13]
    // 0xac41d8: r17 = ", "
    //     0xac41d8: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac41dc: StoreField: r0->field_17 = r17
    //     0xac41dc: stur            w17, [x0, #0x17]
    // 0xac41e0: LoadField: r2 = r1->field_b
    //     0xac41e0: ldur            w2, [x1, #0xb]
    // 0xac41e4: DecompressPointer r2
    //     0xac41e4: add             x2, x2, HEAP, lsl #32
    // 0xac41e8: StoreField: r0->field_1b = r2
    //     0xac41e8: stur            w2, [x0, #0x1b]
    // 0xac41ec: r17 = ")"
    //     0xac41ec: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xac41f0: StoreField: r0->field_1f = r17
    //     0xac41f0: stur            w17, [x0, #0x1f]
    // 0xac41f4: SaveReg r0
    //     0xac41f4: str             x0, [SP, #-8]!
    // 0xac41f8: r0 = _interpolate()
    //     0xac41f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xac41fc: add             SP, SP, #8
    // 0xac4200: LeaveFrame
    //     0xac4200: mov             SP, fp
    //     0xac4204: ldp             fp, lr, [SP], #0x10
    // 0xac4208: ret
    //     0xac4208: ret             
    // 0xac420c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac420c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4210: b               #0xac41b0
  }
}

// lib: , url: package:camera_platform_interface/src/types/camera_image_data.dart

// class id: 1048720, size: 0x8
class :: {
}

// class id: 4892, size: 0x2c, field offset: 0x8
//   const constructor, 
class CameraImageData extends Object {
}

// class id: 4893, size: 0x10, field offset: 0x8
//   const constructor, 
class CameraImageFormat extends Object {
}

// class id: 4894, size: 0x20, field offset: 0x8
//   const constructor, 
class CameraImagePlane extends Object {
}

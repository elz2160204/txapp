// lib: , url: package:camera_platform_interface/src/types/video_capture_options.dart

// class id: 1048727, size: 0x8
class :: {
}

// class id: 4891, size: 0x1c, field offset: 0x8
//   const constructor, 
class VideoCaptureOptions extends Object {

  get _ hashCode(/* No info */) {
    // ** addr: 0xafa3ec, size: 0x78
    // 0xafa3ec: EnterFrame
    //     0xafa3ec: stp             fp, lr, [SP, #-0x10]!
    //     0xafa3f0: mov             fp, SP
    // 0xafa3f4: CheckStackOverflow
    //     0xafa3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafa3f8: cmp             SP, x16
    //     0xafa3fc: b.ls            #0xafa45c
    // 0xafa400: ldr             x0, [fp, #0x10]
    // 0xafa404: LoadField: r2 = r0->field_7
    //     0xafa404: ldur            x2, [x0, #7]
    // 0xafa408: LoadField: r3 = r0->field_13
    //     0xafa408: ldur            w3, [x0, #0x13]
    // 0xafa40c: DecompressPointer r3
    //     0xafa40c: add             x3, x3, HEAP, lsl #32
    // 0xafa410: r0 = BoxInt64Instr(r2)
    //     0xafa410: sbfiz           x0, x2, #1, #0x1f
    //     0xafa414: cmp             x2, x0, asr #1
    //     0xafa418: b.eq            #0xafa424
    //     0xafa41c: bl              #0xd69bb8
    //     0xafa420: stur            x2, [x0, #7]
    // 0xafa424: stp             NULL, x0, [SP, #-0x10]!
    // 0xafa428: stp             NULL, x3, [SP, #-0x10]!
    // 0xafa42c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0xafa42c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0xafa430: r0 = hash()
    //     0xafa430: bl              #0x5d35e8  ; [dart:core] Object::hash
    // 0xafa434: add             SP, SP, #0x20
    // 0xafa438: mov             x2, x0
    // 0xafa43c: r0 = BoxInt64Instr(r2)
    //     0xafa43c: sbfiz           x0, x2, #1, #0x1f
    //     0xafa440: cmp             x2, x0, asr #1
    //     0xafa444: b.eq            #0xafa450
    //     0xafa448: bl              #0xd69bb8
    //     0xafa44c: stur            x2, [x0, #7]
    // 0xafa450: LeaveFrame
    //     0xafa450: mov             SP, fp
    //     0xafa454: ldp             fp, lr, [SP], #0x10
    // 0xafa458: ret
    //     0xafa458: ret             
    // 0xafa45c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafa45c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafa460: b               #0xafa400
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6a234, size: 0xec
    // 0xc6a234: EnterFrame
    //     0xc6a234: stp             fp, lr, [SP, #-0x10]!
    //     0xc6a238: mov             fp, SP
    // 0xc6a23c: CheckStackOverflow
    //     0xc6a23c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6a240: cmp             SP, x16
    //     0xc6a244: b.ls            #0xc6a318
    // 0xc6a248: ldr             x0, [fp, #0x10]
    // 0xc6a24c: cmp             w0, NULL
    // 0xc6a250: b.ne            #0xc6a264
    // 0xc6a254: r0 = false
    //     0xc6a254: add             x0, NULL, #0x30  ; false
    // 0xc6a258: LeaveFrame
    //     0xc6a258: mov             SP, fp
    //     0xc6a25c: ldp             fp, lr, [SP], #0x10
    // 0xc6a260: ret
    //     0xc6a260: ret             
    // 0xc6a264: ldr             x1, [fp, #0x18]
    // 0xc6a268: cmp             w1, w0
    // 0xc6a26c: b.ne            #0xc6a278
    // 0xc6a270: r0 = true
    //     0xc6a270: add             x0, NULL, #0x20  ; true
    // 0xc6a274: b               #0xc6a30c
    // 0xc6a278: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6a278: mov             x2, #0x76
    //     0xc6a27c: tbz             w0, #0, #0xc6a28c
    //     0xc6a280: ldur            x2, [x0, #-1]
    //     0xc6a284: ubfx            x2, x2, #0xc, #0x14
    //     0xc6a288: lsl             x2, x2, #1
    // 0xc6a28c: r17 = 9782
    //     0xc6a28c: mov             x17, #0x2636
    // 0xc6a290: cmp             w2, w17
    // 0xc6a294: b.ne            #0xc6a308
    // 0xc6a298: r16 = VideoCaptureOptions
    //     0xc6a298: add             x16, PP, #0x53, lsl #12  ; [pp+0x53aa8] Type: VideoCaptureOptions
    //     0xc6a29c: ldr             x16, [x16, #0xaa8]
    // 0xc6a2a0: r30 = VideoCaptureOptions
    //     0xc6a2a0: add             lr, PP, #0x53, lsl #12  ; [pp+0x53aa8] Type: VideoCaptureOptions
    //     0xc6a2a4: ldr             lr, [lr, #0xaa8]
    // 0xc6a2a8: stp             lr, x16, [SP, #-0x10]!
    // 0xc6a2ac: r0 = ==()
    //     0xc6a2ac: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc6a2b0: add             SP, SP, #0x10
    // 0xc6a2b4: tbnz            w0, #4, #0xc6a308
    // 0xc6a2b8: ldr             x1, [fp, #0x18]
    // 0xc6a2bc: ldr             x0, [fp, #0x10]
    // 0xc6a2c0: LoadField: r2 = r1->field_7
    //     0xc6a2c0: ldur            x2, [x1, #7]
    // 0xc6a2c4: LoadField: r3 = r0->field_7
    //     0xc6a2c4: ldur            x3, [x0, #7]
    // 0xc6a2c8: cmp             x2, x3
    // 0xc6a2cc: b.ne            #0xc6a308
    // 0xc6a2d0: LoadField: r2 = r1->field_13
    //     0xc6a2d0: ldur            w2, [x1, #0x13]
    // 0xc6a2d4: DecompressPointer r2
    //     0xc6a2d4: add             x2, x2, HEAP, lsl #32
    // 0xc6a2d8: LoadField: r1 = r0->field_13
    //     0xc6a2d8: ldur            w1, [x0, #0x13]
    // 0xc6a2dc: DecompressPointer r1
    //     0xc6a2dc: add             x1, x1, HEAP, lsl #32
    // 0xc6a2e0: r0 = LoadClassIdInstr(r2)
    //     0xc6a2e0: ldur            x0, [x2, #-1]
    //     0xc6a2e4: ubfx            x0, x0, #0xc, #0x14
    // 0xc6a2e8: stp             x1, x2, [SP, #-0x10]!
    // 0xc6a2ec: mov             lr, x0
    // 0xc6a2f0: ldr             lr, [x21, lr, lsl #3]
    // 0xc6a2f4: blr             lr
    // 0xc6a2f8: add             SP, SP, #0x10
    // 0xc6a2fc: tbnz            w0, #4, #0xc6a308
    // 0xc6a300: r0 = true
    //     0xc6a300: add             x0, NULL, #0x20  ; true
    // 0xc6a304: b               #0xc6a30c
    // 0xc6a308: r0 = false
    //     0xc6a308: add             x0, NULL, #0x30  ; false
    // 0xc6a30c: LeaveFrame
    //     0xc6a30c: mov             SP, fp
    //     0xc6a310: ldp             fp, lr, [SP], #0x10
    // 0xc6a314: ret
    //     0xc6a314: ret             
    // 0xc6a318: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6a318: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6a31c: b               #0xc6a248
  }
}

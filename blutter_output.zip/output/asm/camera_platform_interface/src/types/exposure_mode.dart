// lib: , url: package:camera_platform_interface/src/types/exposure_mode.dart

// class id: 1048721, size: 0x8
class :: {

  static _ deserializeExposureMode(/* No info */) {
    // ** addr: 0xc77640, size: 0xe0
    // 0xc77640: EnterFrame
    //     0xc77640: stp             fp, lr, [SP, #-0x10]!
    //     0xc77644: mov             fp, SP
    // 0xc77648: AllocStack(0x8)
    //     0xc77648: sub             SP, SP, #8
    // 0xc7764c: CheckStackOverflow
    //     0xc7764c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc77650: cmp             SP, x16
    //     0xc77654: b.ls            #0xc77718
    // 0xc77658: r16 = "locked"
    //     0xc77658: add             x16, PP, #0x4d, lsl #12  ; [pp+0x4d978] "locked"
    //     0xc7765c: ldr             x16, [x16, #0x978]
    // 0xc77660: ldr             lr, [fp, #0x10]
    // 0xc77664: stp             lr, x16, [SP, #-0x10]!
    // 0xc77668: r0 = ==()
    //     0xc77668: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc7766c: add             SP, SP, #0x10
    // 0xc77670: tbnz            w0, #4, #0xc77688
    // 0xc77674: r0 = Instance_ExposureMode
    //     0xc77674: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d1e8] Obj!ExposureMode@b66bb1
    //     0xc77678: ldr             x0, [x0, #0x1e8]
    // 0xc7767c: LeaveFrame
    //     0xc7767c: mov             SP, fp
    //     0xc77680: ldp             fp, lr, [SP], #0x10
    // 0xc77684: ret
    //     0xc77684: ret             
    // 0xc77688: r16 = "auto"
    //     0xc77688: add             x16, PP, #0x3c, lsl #12  ; [pp+0x3c7d0] "auto"
    //     0xc7768c: ldr             x16, [x16, #0x7d0]
    // 0xc77690: ldr             lr, [fp, #0x10]
    // 0xc77694: stp             lr, x16, [SP, #-0x10]!
    // 0xc77698: r0 = ==()
    //     0xc77698: bl              #0xcbb394  ; [dart:core] _OneByteString::==
    // 0xc7769c: add             SP, SP, #0x10
    // 0xc776a0: tbnz            w0, #4, #0xc776b8
    // 0xc776a4: r0 = Instance_ExposureMode
    //     0xc776a4: add             x0, PP, #0x4d, lsl #12  ; [pp+0x4d560] Obj!ExposureMode@b66b91
    //     0xc776a8: ldr             x0, [x0, #0x560]
    // 0xc776ac: LeaveFrame
    //     0xc776ac: mov             SP, fp
    //     0xc776b0: ldp             fp, lr, [SP], #0x10
    // 0xc776b4: ret
    //     0xc776b4: ret             
    // 0xc776b8: ldr             x0, [fp, #0x10]
    // 0xc776bc: r1 = Null
    //     0xc776bc: mov             x1, NULL
    // 0xc776c0: r2 = 6
    //     0xc776c0: mov             x2, #6
    // 0xc776c4: r0 = AllocateArray()
    //     0xc776c4: bl              #0xd6987c  ; AllocateArrayStub
    // 0xc776c8: r17 = "\""
    //     0xc776c8: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0xc776cc: StoreField: r0->field_f = r17
    //     0xc776cc: stur            w17, [x0, #0xf]
    // 0xc776d0: ldr             x1, [fp, #0x10]
    // 0xc776d4: StoreField: r0->field_13 = r1
    //     0xc776d4: stur            w1, [x0, #0x13]
    // 0xc776d8: r17 = "\" is not a valid ExposureMode value"
    //     0xc776d8: add             x17, PP, #0x53, lsl #12  ; [pp+0x53dd0] "\" is not a valid ExposureMode value"
    //     0xc776dc: ldr             x17, [x17, #0xdd0]
    // 0xc776e0: StoreField: r0->field_17 = r17
    //     0xc776e0: stur            w17, [x0, #0x17]
    // 0xc776e4: SaveReg r0
    //     0xc776e4: str             x0, [SP, #-8]!
    // 0xc776e8: r0 = _interpolate()
    //     0xc776e8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xc776ec: add             SP, SP, #8
    // 0xc776f0: stur            x0, [fp, #-8]
    // 0xc776f4: r0 = ArgumentError()
    //     0xc776f4: bl              #0x4b8160  ; AllocateArgumentErrorStub -> ArgumentError (size=0x1c)
    // 0xc776f8: mov             x1, x0
    // 0xc776fc: ldur            x0, [fp, #-8]
    // 0xc77700: StoreField: r1->field_17 = r0
    //     0xc77700: stur            w0, [x1, #0x17]
    // 0xc77704: r0 = false
    //     0xc77704: add             x0, NULL, #0x30  ; false
    // 0xc77708: StoreField: r1->field_b = r0
    //     0xc77708: stur            w0, [x1, #0xb]
    // 0xc7770c: mov             x0, x1
    // 0xc77710: r0 = Throw()
    //     0xc77710: bl              #0xd67e38  ; ThrowStub
    // 0xc77714: brk             #0
    // 0xc77718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc77718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc7771c: b               #0xc77658
  }
}

// class id: 6022, size: 0x14, field offset: 0x14
enum ExposureMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb14ff8, size: 0x5c
    // 0xb14ff8: EnterFrame
    //     0xb14ff8: stp             fp, lr, [SP, #-0x10]!
    //     0xb14ffc: mov             fp, SP
    // 0xb15000: CheckStackOverflow
    //     0xb15000: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15004: cmp             SP, x16
    //     0xb15008: b.ls            #0xb1504c
    // 0xb1500c: r1 = Null
    //     0xb1500c: mov             x1, NULL
    // 0xb15010: r2 = 4
    //     0xb15010: mov             x2, #4
    // 0xb15014: r0 = AllocateArray()
    //     0xb15014: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15018: r17 = "ExposureMode."
    //     0xb15018: add             x17, PP, #0x53, lsl #12  ; [pp+0x53ab8] "ExposureMode."
    //     0xb1501c: ldr             x17, [x17, #0xab8]
    // 0xb15020: StoreField: r0->field_f = r17
    //     0xb15020: stur            w17, [x0, #0xf]
    // 0xb15024: ldr             x1, [fp, #0x10]
    // 0xb15028: LoadField: r2 = r1->field_f
    //     0xb15028: ldur            w2, [x1, #0xf]
    // 0xb1502c: DecompressPointer r2
    //     0xb1502c: add             x2, x2, HEAP, lsl #32
    // 0xb15030: StoreField: r0->field_13 = r2
    //     0xb15030: stur            w2, [x0, #0x13]
    // 0xb15034: SaveReg r0
    //     0xb15034: str             x0, [SP, #-8]!
    // 0xb15038: r0 = _interpolate()
    //     0xb15038: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb1503c: add             SP, SP, #8
    // 0xb15040: LeaveFrame
    //     0xb15040: mov             SP, fp
    //     0xb15044: ldp             fp, lr, [SP], #0x10
    // 0xb15048: ret
    //     0xb15048: ret             
    // 0xb1504c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb1504c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb15050: b               #0xb1500c
  }
}

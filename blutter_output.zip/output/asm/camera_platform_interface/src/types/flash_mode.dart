// lib: , url: package:camera_platform_interface/src/types/flash_mode.dart

// class id: 1048722, size: 0x8
class :: {
}

// class id: 6021, size: 0x14, field offset: 0x14
enum FlashMode extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15054, size: 0x5c
    // 0xb15054: EnterFrame
    //     0xb15054: stp             fp, lr, [SP, #-0x10]!
    //     0xb15058: mov             fp, SP
    // 0xb1505c: CheckStackOverflow
    //     0xb1505c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15060: cmp             SP, x16
    //     0xb15064: b.ls            #0xb150a8
    // 0xb15068: r1 = Null
    //     0xb15068: mov             x1, NULL
    // 0xb1506c: r2 = 4
    //     0xb1506c: mov             x2, #4
    // 0xb15070: r0 = AllocateArray()
    //     0xb15070: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15074: r17 = "FlashMode."
    //     0xb15074: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca78] "FlashMode."
    //     0xb15078: ldr             x17, [x17, #0xa78]
    // 0xb1507c: StoreField: r0->field_f = r17
    //     0xb1507c: stur            w17, [x0, #0xf]
    // 0xb15080: ldr             x1, [fp, #0x10]
    // 0xb15084: LoadField: r2 = r1->field_f
    //     0xb15084: ldur            w2, [x1, #0xf]
    // 0xb15088: DecompressPointer r2
    //     0xb15088: add             x2, x2, HEAP, lsl #32
    // 0xb1508c: StoreField: r0->field_13 = r2
    //     0xb1508c: stur            w2, [x0, #0x13]
    // 0xb15090: SaveReg r0
    //     0xb15090: str             x0, [SP, #-8]!
    // 0xb15094: r0 = _interpolate()
    //     0xb15094: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb15098: add             SP, SP, #8
    // 0xb1509c: LeaveFrame
    //     0xb1509c: mov             SP, fp
    //     0xb150a0: ldp             fp, lr, [SP], #0x10
    // 0xb150a4: ret
    //     0xb150a4: ret             
    // 0xb150a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb150a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb150ac: b               #0xb15068
  }
}

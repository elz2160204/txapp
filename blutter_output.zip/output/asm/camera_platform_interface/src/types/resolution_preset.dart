// lib: , url: package:camera_platform_interface/src/types/resolution_preset.dart

// class id: 1048725, size: 0x8
class :: {
}

// class id: 6018, size: 0x14, field offset: 0x14
enum ResolutionPreset extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb15168, size: 0x5c
    // 0xb15168: EnterFrame
    //     0xb15168: stp             fp, lr, [SP, #-0x10]!
    //     0xb1516c: mov             fp, SP
    // 0xb15170: CheckStackOverflow
    //     0xb15170: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb15174: cmp             SP, x16
    //     0xb15178: b.ls            #0xb151bc
    // 0xb1517c: r1 = Null
    //     0xb1517c: mov             x1, NULL
    // 0xb15180: r2 = 4
    //     0xb15180: mov             x2, #4
    // 0xb15184: r0 = AllocateArray()
    //     0xb15184: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb15188: r17 = "ResolutionPreset."
    //     0xb15188: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca68] "ResolutionPreset."
    //     0xb1518c: ldr             x17, [x17, #0xa68]
    // 0xb15190: StoreField: r0->field_f = r17
    //     0xb15190: stur            w17, [x0, #0xf]
    // 0xb15194: ldr             x1, [fp, #0x10]
    // 0xb15198: LoadField: r2 = r1->field_f
    //     0xb15198: ldur            w2, [x1, #0xf]
    // 0xb1519c: DecompressPointer r2
    //     0xb1519c: add             x2, x2, HEAP, lsl #32
    // 0xb151a0: StoreField: r0->field_13 = r2
    //     0xb151a0: stur            w2, [x0, #0x13]
    // 0xb151a4: SaveReg r0
    //     0xb151a4: str             x0, [SP, #-8]!
    // 0xb151a8: r0 = _interpolate()
    //     0xb151a8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb151ac: add             SP, SP, #8
    // 0xb151b0: LeaveFrame
    //     0xb151b0: mov             SP, fp
    //     0xb151b4: ldp             fp, lr, [SP], #0x10
    // 0xb151b8: ret
    //     0xb151b8: ret             
    // 0xb151bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb151bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb151c0: b               #0xb1517c
  }
}

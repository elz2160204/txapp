// lib: , url: package:camera_platform_interface/src/types/camera_description.dart

// class id: 1048718, size: 0x8
class :: {
}

// class id: 4897, size: 0x18, field offset: 0x8
//   const constructor, 
class CameraDescription extends Object {

  _ toString(/* No info */) {
    // ** addr: 0xac40f4, size: 0xa8
    // 0xac40f4: EnterFrame
    //     0xac40f4: stp             fp, lr, [SP, #-0x10]!
    //     0xac40f8: mov             fp, SP
    // 0xac40fc: CheckStackOverflow
    //     0xac40fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xac4100: cmp             SP, x16
    //     0xac4104: b.ls            #0xac4194
    // 0xac4108: r1 = Null
    //     0xac4108: mov             x1, NULL
    // 0xac410c: r2 = 16
    //     0xac410c: mov             x2, #0x10
    // 0xac4110: r0 = AllocateArray()
    //     0xac4110: bl              #0xd6987c  ; AllocateArrayStub
    // 0xac4114: mov             x2, x0
    // 0xac4118: r17 = "CameraDescription"
    //     0xac4118: add             x17, PP, #0x55, lsl #12  ; [pp+0x55cb8] "CameraDescription"
    //     0xac411c: ldr             x17, [x17, #0xcb8]
    // 0xac4120: StoreField: r2->field_f = r17
    //     0xac4120: stur            w17, [x2, #0xf]
    // 0xac4124: r17 = "("
    //     0xac4124: ldr             x17, [PP, #0x418]  ; [pp+0x418] "("
    // 0xac4128: StoreField: r2->field_13 = r17
    //     0xac4128: stur            w17, [x2, #0x13]
    // 0xac412c: ldr             x0, [fp, #0x10]
    // 0xac4130: LoadField: r1 = r0->field_7
    //     0xac4130: ldur            w1, [x0, #7]
    // 0xac4134: DecompressPointer r1
    //     0xac4134: add             x1, x1, HEAP, lsl #32
    // 0xac4138: StoreField: r2->field_17 = r1
    //     0xac4138: stur            w1, [x2, #0x17]
    // 0xac413c: r17 = ", "
    //     0xac413c: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac4140: StoreField: r2->field_1b = r17
    //     0xac4140: stur            w17, [x2, #0x1b]
    // 0xac4144: LoadField: r1 = r0->field_b
    //     0xac4144: ldur            w1, [x0, #0xb]
    // 0xac4148: DecompressPointer r1
    //     0xac4148: add             x1, x1, HEAP, lsl #32
    // 0xac414c: StoreField: r2->field_1f = r1
    //     0xac414c: stur            w1, [x2, #0x1f]
    // 0xac4150: r17 = ", "
    //     0xac4150: ldr             x17, [PP, #0x1090]  ; [pp+0x1090] ", "
    // 0xac4154: StoreField: r2->field_23 = r17
    //     0xac4154: stur            w17, [x2, #0x23]
    // 0xac4158: LoadField: r3 = r0->field_f
    //     0xac4158: ldur            x3, [x0, #0xf]
    // 0xac415c: r0 = BoxInt64Instr(r3)
    //     0xac415c: sbfiz           x0, x3, #1, #0x1f
    //     0xac4160: cmp             x3, x0, asr #1
    //     0xac4164: b.eq            #0xac4170
    //     0xac4168: bl              #0xd69bb8
    //     0xac416c: stur            x3, [x0, #7]
    // 0xac4170: StoreField: r2->field_27 = r0
    //     0xac4170: stur            w0, [x2, #0x27]
    // 0xac4174: r17 = ")"
    //     0xac4174: ldr             x17, [PP, #0x420]  ; [pp+0x420] ")"
    // 0xac4178: StoreField: r2->field_2b = r17
    //     0xac4178: stur            w17, [x2, #0x2b]
    // 0xac417c: SaveReg r2
    //     0xac417c: str             x2, [SP, #-8]!
    // 0xac4180: r0 = _interpolate()
    //     0xac4180: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xac4184: add             SP, SP, #8
    // 0xac4188: LeaveFrame
    //     0xac4188: mov             SP, fp
    //     0xac418c: ldp             fp, lr, [SP], #0x10
    // 0xac4190: ret
    //     0xac4190: ret             
    // 0xac4194: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xac4194: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xac4198: b               #0xac4108
  }
  _ ==(/* No info */) {
    // ** addr: 0xc6a12c, size: 0x108
    // 0xc6a12c: EnterFrame
    //     0xc6a12c: stp             fp, lr, [SP, #-0x10]!
    //     0xc6a130: mov             fp, SP
    // 0xc6a134: CheckStackOverflow
    //     0xc6a134: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc6a138: cmp             SP, x16
    //     0xc6a13c: b.ls            #0xc6a22c
    // 0xc6a140: ldr             x0, [fp, #0x10]
    // 0xc6a144: cmp             w0, NULL
    // 0xc6a148: b.ne            #0xc6a15c
    // 0xc6a14c: r0 = false
    //     0xc6a14c: add             x0, NULL, #0x30  ; false
    // 0xc6a150: LeaveFrame
    //     0xc6a150: mov             SP, fp
    //     0xc6a154: ldp             fp, lr, [SP], #0x10
    // 0xc6a158: ret
    //     0xc6a158: ret             
    // 0xc6a15c: ldr             x1, [fp, #0x18]
    // 0xc6a160: cmp             w1, w0
    // 0xc6a164: b.ne            #0xc6a170
    // 0xc6a168: r0 = true
    //     0xc6a168: add             x0, NULL, #0x20  ; true
    // 0xc6a16c: b               #0xc6a220
    // 0xc6a170: r2 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc6a170: mov             x2, #0x76
    //     0xc6a174: tbz             w0, #0, #0xc6a184
    //     0xc6a178: ldur            x2, [x0, #-1]
    //     0xc6a17c: ubfx            x2, x2, #0xc, #0x14
    //     0xc6a180: lsl             x2, x2, #1
    // 0xc6a184: r17 = 9794
    //     0xc6a184: mov             x17, #0x2642
    // 0xc6a188: cmp             w2, w17
    // 0xc6a18c: b.ne            #0xc6a21c
    // 0xc6a190: r16 = CameraDescription
    //     0xc6a190: add             x16, PP, #0x55, lsl #12  ; [pp+0x55cc0] Type: CameraDescription
    //     0xc6a194: ldr             x16, [x16, #0xcc0]
    // 0xc6a198: r30 = CameraDescription
    //     0xc6a198: add             lr, PP, #0x55, lsl #12  ; [pp+0x55cc0] Type: CameraDescription
    //     0xc6a19c: ldr             lr, [lr, #0xcc0]
    // 0xc6a1a0: stp             lr, x16, [SP, #-0x10]!
    // 0xc6a1a4: r0 = ==()
    //     0xc6a1a4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xc6a1a8: add             SP, SP, #0x10
    // 0xc6a1ac: tbnz            w0, #4, #0xc6a21c
    // 0xc6a1b0: ldr             x2, [fp, #0x18]
    // 0xc6a1b4: ldr             x1, [fp, #0x10]
    // 0xc6a1b8: LoadField: r0 = r2->field_7
    //     0xc6a1b8: ldur            w0, [x2, #7]
    // 0xc6a1bc: DecompressPointer r0
    //     0xc6a1bc: add             x0, x0, HEAP, lsl #32
    // 0xc6a1c0: LoadField: r3 = r1->field_7
    //     0xc6a1c0: ldur            w3, [x1, #7]
    // 0xc6a1c4: DecompressPointer r3
    //     0xc6a1c4: add             x3, x3, HEAP, lsl #32
    // 0xc6a1c8: r4 = LoadClassIdInstr(r0)
    //     0xc6a1c8: ldur            x4, [x0, #-1]
    //     0xc6a1cc: ubfx            x4, x4, #0xc, #0x14
    // 0xc6a1d0: stp             x3, x0, [SP, #-0x10]!
    // 0xc6a1d4: mov             x0, x4
    // 0xc6a1d8: mov             lr, x0
    // 0xc6a1dc: ldr             lr, [x21, lr, lsl #3]
    // 0xc6a1e0: blr             lr
    // 0xc6a1e4: add             SP, SP, #0x10
    // 0xc6a1e8: tbnz            w0, #4, #0xc6a21c
    // 0xc6a1ec: ldr             x2, [fp, #0x18]
    // 0xc6a1f0: ldr             x1, [fp, #0x10]
    // 0xc6a1f4: LoadField: r3 = r2->field_b
    //     0xc6a1f4: ldur            w3, [x2, #0xb]
    // 0xc6a1f8: DecompressPointer r3
    //     0xc6a1f8: add             x3, x3, HEAP, lsl #32
    // 0xc6a1fc: LoadField: r2 = r1->field_b
    //     0xc6a1fc: ldur            w2, [x1, #0xb]
    // 0xc6a200: DecompressPointer r2
    //     0xc6a200: add             x2, x2, HEAP, lsl #32
    // 0xc6a204: cmp             w3, w2
    // 0xc6a208: r16 = true
    //     0xc6a208: add             x16, NULL, #0x20  ; true
    // 0xc6a20c: r17 = false
    //     0xc6a20c: add             x17, NULL, #0x30  ; false
    // 0xc6a210: csel            x1, x16, x17, eq
    // 0xc6a214: mov             x0, x1
    // 0xc6a218: b               #0xc6a220
    // 0xc6a21c: r0 = false
    //     0xc6a21c: add             x0, NULL, #0x30  ; false
    // 0xc6a220: LeaveFrame
    //     0xc6a220: mov             SP, fp
    //     0xc6a224: ldp             fp, lr, [SP], #0x10
    // 0xc6a228: ret
    //     0xc6a228: ret             
    // 0xc6a22c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc6a22c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc6a230: b               #0xc6a140
  }
}

// class id: 6023, size: 0x14, field offset: 0x14
enum CameraLensDirection extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb14f9c, size: 0x5c
    // 0xb14f9c: EnterFrame
    //     0xb14f9c: stp             fp, lr, [SP, #-0x10]!
    //     0xb14fa0: mov             fp, SP
    // 0xb14fa4: CheckStackOverflow
    //     0xb14fa4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb14fa8: cmp             SP, x16
    //     0xb14fac: b.ls            #0xb14ff0
    // 0xb14fb0: r1 = Null
    //     0xb14fb0: mov             x1, NULL
    // 0xb14fb4: r2 = 4
    //     0xb14fb4: mov             x2, #4
    // 0xb14fb8: r0 = AllocateArray()
    //     0xb14fb8: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb14fbc: r17 = "CameraLensDirection."
    //     0xb14fbc: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca80] "CameraLensDirection."
    //     0xb14fc0: ldr             x17, [x17, #0xa80]
    // 0xb14fc4: StoreField: r0->field_f = r17
    //     0xb14fc4: stur            w17, [x0, #0xf]
    // 0xb14fc8: ldr             x1, [fp, #0x10]
    // 0xb14fcc: LoadField: r2 = r1->field_f
    //     0xb14fcc: ldur            w2, [x1, #0xf]
    // 0xb14fd0: DecompressPointer r2
    //     0xb14fd0: add             x2, x2, HEAP, lsl #32
    // 0xb14fd4: StoreField: r0->field_13 = r2
    //     0xb14fd4: stur            w2, [x0, #0x13]
    // 0xb14fd8: SaveReg r0
    //     0xb14fd8: str             x0, [SP, #-8]!
    // 0xb14fdc: r0 = _interpolate()
    //     0xb14fdc: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb14fe0: add             SP, SP, #8
    // 0xb14fe4: LeaveFrame
    //     0xb14fe4: mov             SP, fp
    //     0xb14fe8: ldp             fp, lr, [SP], #0x10
    // 0xb14fec: ret
    //     0xb14fec: ret             
    // 0xb14ff0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb14ff0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb14ff4: b               #0xb14fb0
  }
}

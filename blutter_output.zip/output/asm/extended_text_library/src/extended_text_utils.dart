// lib: , url: package:extended_text_library/src/extended_text_utils.dart

// class id: 1048977, size: 0x8
class :: {

  static _ convertTextInputSelectionToTextPainterSelection(/* No info */) {
    // ** addr: 0x522478, size: 0x2e0
    // 0x522478: EnterFrame
    //     0x522478: stp             fp, lr, [SP, #-0x10]!
    //     0x52247c: mov             fp, SP
    // 0x522480: AllocStack(0x18)
    //     0x522480: sub             SP, SP, #0x18
    // 0x522484: CheckStackOverflow
    //     0x522484: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522488: cmp             SP, x16
    //     0x52248c: b.ls            #0x522750
    // 0x522490: ldr             x0, [fp, #0x10]
    // 0x522494: LoadField: r1 = r0->field_7
    //     0x522494: ldur            x1, [x0, #7]
    // 0x522498: tbnz            x1, #0x3f, #0x52273c
    // 0x52249c: LoadField: r2 = r0->field_f
    //     0x52249c: ldur            x2, [x0, #0xf]
    // 0x5224a0: tbnz            x2, #0x3f, #0x522734
    // 0x5224a4: cmp             x1, x2
    // 0x5224a8: b.ne            #0x52258c
    // 0x5224ac: SaveReg r0
    //     0x5224ac: str             x0, [SP, #-8]!
    // 0x5224b0: r0 = extent()
    //     0x5224b0: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x5224b4: add             SP, SP, #8
    // 0x5224b8: ldr             x16, [fp, #0x18]
    // 0x5224bc: stp             x0, x16, [SP, #-0x10]!
    // 0x5224c0: r0 = convertTextInputPostionToTextPainterPostion()
    //     0x5224c0: bl              #0x522a08  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextInputPostionToTextPainterPostion
    // 0x5224c4: add             SP, SP, #0x10
    // 0x5224c8: stur            x0, [fp, #-8]
    // 0x5224cc: ldr             x16, [fp, #0x10]
    // 0x5224d0: SaveReg r16
    //     0x5224d0: str             x16, [SP, #-8]!
    // 0x5224d4: r0 = extent()
    //     0x5224d4: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x5224d8: add             SP, SP, #8
    // 0x5224dc: stur            x0, [fp, #-0x10]
    // 0x5224e0: r16 = TextPosition
    //     0x5224e0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x5224e4: ldr             x16, [x16, #0x540]
    // 0x5224e8: r30 = TextPosition
    //     0x5224e8: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x5224ec: ldr             lr, [lr, #0x540]
    // 0x5224f0: stp             lr, x16, [SP, #-0x10]!
    // 0x5224f4: r0 = ==()
    //     0x5224f4: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x5224f8: add             SP, SP, #0x10
    // 0x5224fc: tbz             w0, #4, #0x522508
    // 0x522500: ldur            x1, [fp, #-8]
    // 0x522504: b               #0x522538
    // 0x522508: ldur            x1, [fp, #-8]
    // 0x52250c: ldur            x0, [fp, #-0x10]
    // 0x522510: LoadField: r2 = r1->field_7
    //     0x522510: ldur            x2, [x1, #7]
    // 0x522514: LoadField: r3 = r0->field_7
    //     0x522514: ldur            x3, [x0, #7]
    // 0x522518: cmp             x2, x3
    // 0x52251c: b.ne            #0x522538
    // 0x522520: LoadField: r2 = r1->field_f
    //     0x522520: ldur            w2, [x1, #0xf]
    // 0x522524: DecompressPointer r2
    //     0x522524: add             x2, x2, HEAP, lsl #32
    // 0x522528: LoadField: r3 = r0->field_f
    //     0x522528: ldur            w3, [x0, #0xf]
    // 0x52252c: DecompressPointer r3
    //     0x52252c: add             x3, x3, HEAP, lsl #32
    // 0x522530: cmp             w2, w3
    // 0x522534: b.eq            #0x5226b4
    // 0x522538: ldr             x2, [fp, #0x10]
    // 0x52253c: LoadField: r3 = r1->field_7
    //     0x52253c: ldur            x3, [x1, #7]
    // 0x522540: LoadField: r4 = r2->field_27
    //     0x522540: ldur            w4, [x2, #0x27]
    // 0x522544: DecompressPointer r4
    //     0x522544: add             x4, x4, HEAP, lsl #32
    // 0x522548: LoadField: r5 = r2->field_2b
    //     0x522548: ldur            w5, [x2, #0x2b]
    // 0x52254c: DecompressPointer r5
    //     0x52254c: add             x5, x5, HEAP, lsl #32
    // 0x522550: r0 = BoxInt64Instr(r3)
    //     0x522550: sbfiz           x0, x3, #1, #0x1f
    //     0x522554: cmp             x3, x0, asr #1
    //     0x522558: b.eq            #0x522564
    //     0x52255c: bl              #0xd69bb8
    //     0x522560: stur            x3, [x0, #7]
    // 0x522564: stp             x0, x2, [SP, #-0x10]!
    // 0x522568: stp             x4, x0, [SP, #-0x10]!
    // 0x52256c: SaveReg r5
    //     0x52256c: str             x5, [SP, #-8]!
    // 0x522570: r4 = const [0, 0x5, 0x5, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, isDirectional, 0x4, null]
    //     0x522570: add             x4, PP, #0x37, lsl #12  ; [pp+0x37428] List(13) [0, 0x5, 0x5, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, "isDirectional", 0x4, Null]
    //     0x522574: ldr             x4, [x4, #0x428]
    // 0x522578: r0 = copyWith()
    //     0x522578: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x52257c: add             SP, SP, #0x28
    // 0x522580: LeaveFrame
    //     0x522580: mov             SP, fp
    //     0x522584: ldp             fp, lr, [SP], #0x10
    // 0x522588: ret
    //     0x522588: ret             
    // 0x52258c: mov             x2, x0
    // 0x522590: SaveReg r2
    //     0x522590: str             x2, [SP, #-8]!
    // 0x522594: r0 = extent()
    //     0x522594: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x522598: add             SP, SP, #8
    // 0x52259c: ldr             x16, [fp, #0x18]
    // 0x5225a0: stp             x0, x16, [SP, #-0x10]!
    // 0x5225a4: r0 = convertTextInputPostionToTextPainterPostion()
    //     0x5225a4: bl              #0x522a08  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextInputPostionToTextPainterPostion
    // 0x5225a8: add             SP, SP, #0x10
    // 0x5225ac: stur            x0, [fp, #-8]
    // 0x5225b0: ldr             x16, [fp, #0x10]
    // 0x5225b4: SaveReg r16
    //     0x5225b4: str             x16, [SP, #-8]!
    // 0x5225b8: r0 = base()
    //     0x5225b8: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x5225bc: add             SP, SP, #8
    // 0x5225c0: ldr             x16, [fp, #0x18]
    // 0x5225c4: stp             x0, x16, [SP, #-0x10]!
    // 0x5225c8: r0 = convertTextInputPostionToTextPainterPostion()
    //     0x5225c8: bl              #0x522a08  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextInputPostionToTextPainterPostion
    // 0x5225cc: add             SP, SP, #0x10
    // 0x5225d0: stur            x0, [fp, #-0x10]
    // 0x5225d4: ldr             x16, [fp, #0x10]
    // 0x5225d8: SaveReg r16
    //     0x5225d8: str             x16, [SP, #-8]!
    // 0x5225dc: r0 = extent()
    //     0x5225dc: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x5225e0: add             SP, SP, #8
    // 0x5225e4: stur            x0, [fp, #-0x18]
    // 0x5225e8: r16 = TextPosition
    //     0x5225e8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x5225ec: ldr             x16, [x16, #0x540]
    // 0x5225f0: r30 = TextPosition
    //     0x5225f0: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x5225f4: ldr             lr, [lr, #0x540]
    // 0x5225f8: stp             lr, x16, [SP, #-0x10]!
    // 0x5225fc: r0 = ==()
    //     0x5225fc: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x522600: add             SP, SP, #0x10
    // 0x522604: tbz             w0, #4, #0x522610
    // 0x522608: ldur            x1, [fp, #-0x10]
    // 0x52260c: b               #0x5226c0
    // 0x522610: ldur            x1, [fp, #-8]
    // 0x522614: ldur            x0, [fp, #-0x18]
    // 0x522618: LoadField: r2 = r1->field_7
    //     0x522618: ldur            x2, [x1, #7]
    // 0x52261c: LoadField: r3 = r0->field_7
    //     0x52261c: ldur            x3, [x0, #7]
    // 0x522620: cmp             x2, x3
    // 0x522624: b.ne            #0x5226bc
    // 0x522628: LoadField: r2 = r1->field_f
    //     0x522628: ldur            w2, [x1, #0xf]
    // 0x52262c: DecompressPointer r2
    //     0x52262c: add             x2, x2, HEAP, lsl #32
    // 0x522630: LoadField: r3 = r0->field_f
    //     0x522630: ldur            w3, [x0, #0xf]
    // 0x522634: DecompressPointer r3
    //     0x522634: add             x3, x3, HEAP, lsl #32
    // 0x522638: cmp             w2, w3
    // 0x52263c: b.eq            #0x522648
    // 0x522640: ldur            x1, [fp, #-0x10]
    // 0x522644: b               #0x5226c0
    // 0x522648: ldr             x16, [fp, #0x10]
    // 0x52264c: SaveReg r16
    //     0x52264c: str             x16, [SP, #-8]!
    // 0x522650: r0 = base()
    //     0x522650: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x522654: add             SP, SP, #8
    // 0x522658: stur            x0, [fp, #-0x18]
    // 0x52265c: r16 = TextPosition
    //     0x52265c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x522660: ldr             x16, [x16, #0x540]
    // 0x522664: r30 = TextPosition
    //     0x522664: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x522668: ldr             lr, [lr, #0x540]
    // 0x52266c: stp             lr, x16, [SP, #-0x10]!
    // 0x522670: r0 = ==()
    //     0x522670: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x522674: add             SP, SP, #0x10
    // 0x522678: tbz             w0, #4, #0x522684
    // 0x52267c: ldur            x1, [fp, #-0x10]
    // 0x522680: b               #0x5226c0
    // 0x522684: ldur            x1, [fp, #-0x10]
    // 0x522688: ldur            x0, [fp, #-0x18]
    // 0x52268c: LoadField: r2 = r1->field_7
    //     0x52268c: ldur            x2, [x1, #7]
    // 0x522690: LoadField: r3 = r0->field_7
    //     0x522690: ldur            x3, [x0, #7]
    // 0x522694: cmp             x2, x3
    // 0x522698: b.ne            #0x5226c0
    // 0x52269c: LoadField: r2 = r1->field_f
    //     0x52269c: ldur            w2, [x1, #0xf]
    // 0x5226a0: DecompressPointer r2
    //     0x5226a0: add             x2, x2, HEAP, lsl #32
    // 0x5226a4: LoadField: r3 = r0->field_f
    //     0x5226a4: ldur            w3, [x0, #0xf]
    // 0x5226a8: DecompressPointer r3
    //     0x5226a8: add             x3, x3, HEAP, lsl #32
    // 0x5226ac: cmp             w2, w3
    // 0x5226b0: b.ne            #0x5226c0
    // 0x5226b4: ldr             x2, [fp, #0x10]
    // 0x5226b8: b               #0x522740
    // 0x5226bc: ldur            x1, [fp, #-0x10]
    // 0x5226c0: ldr             x2, [fp, #0x10]
    // 0x5226c4: ldur            x0, [fp, #-8]
    // 0x5226c8: LoadField: r3 = r1->field_7
    //     0x5226c8: ldur            x3, [x1, #7]
    // 0x5226cc: LoadField: r4 = r0->field_7
    //     0x5226cc: ldur            x4, [x0, #7]
    // 0x5226d0: LoadField: r5 = r2->field_27
    //     0x5226d0: ldur            w5, [x2, #0x27]
    // 0x5226d4: DecompressPointer r5
    //     0x5226d4: add             x5, x5, HEAP, lsl #32
    // 0x5226d8: LoadField: r6 = r2->field_2b
    //     0x5226d8: ldur            w6, [x2, #0x2b]
    // 0x5226dc: DecompressPointer r6
    //     0x5226dc: add             x6, x6, HEAP, lsl #32
    // 0x5226e0: r0 = BoxInt64Instr(r3)
    //     0x5226e0: sbfiz           x0, x3, #1, #0x1f
    //     0x5226e4: cmp             x3, x0, asr #1
    //     0x5226e8: b.eq            #0x5226f4
    //     0x5226ec: bl              #0xd69bb8
    //     0x5226f0: stur            x3, [x0, #7]
    // 0x5226f4: mov             x3, x0
    // 0x5226f8: r0 = BoxInt64Instr(r4)
    //     0x5226f8: sbfiz           x0, x4, #1, #0x1f
    //     0x5226fc: cmp             x4, x0, asr #1
    //     0x522700: b.eq            #0x52270c
    //     0x522704: bl              #0xd69bb8
    //     0x522708: stur            x4, [x0, #7]
    // 0x52270c: stp             x3, x2, [SP, #-0x10]!
    // 0x522710: stp             x5, x0, [SP, #-0x10]!
    // 0x522714: SaveReg r6
    //     0x522714: str             x6, [SP, #-8]!
    // 0x522718: r4 = const [0, 0x5, 0x5, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, isDirectional, 0x4, null]
    //     0x522718: add             x4, PP, #0x37, lsl #12  ; [pp+0x37428] List(13) [0, 0x5, 0x5, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, "isDirectional", 0x4, Null]
    //     0x52271c: ldr             x4, [x4, #0x428]
    // 0x522720: r0 = copyWith()
    //     0x522720: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x522724: add             SP, SP, #0x28
    // 0x522728: LeaveFrame
    //     0x522728: mov             SP, fp
    //     0x52272c: ldp             fp, lr, [SP], #0x10
    // 0x522730: ret
    //     0x522730: ret             
    // 0x522734: mov             x2, x0
    // 0x522738: b               #0x522740
    // 0x52273c: mov             x2, x0
    // 0x522740: mov             x0, x2
    // 0x522744: LeaveFrame
    //     0x522744: mov             SP, fp
    //     0x522748: ldp             fp, lr, [SP], #0x10
    // 0x52274c: ret
    //     0x52274c: ret             
    // 0x522750: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x522750: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x522754: b               #0x522490
  }
  static _ convertTextInputPostionToTextPainterPostion(/* No info */) {
    // ** addr: 0x522a08, size: 0x1f8
    // 0x522a08: EnterFrame
    //     0x522a08: stp             fp, lr, [SP, #-0x10]!
    //     0x522a0c: mov             fp, SP
    // 0x522a10: AllocStack(0x10)
    //     0x522a10: sub             SP, SP, #0x10
    // 0x522a14: CheckStackOverflow
    //     0x522a14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522a18: cmp             SP, x16
    //     0x522a1c: b.ls            #0x522bf4
    // 0x522a20: r1 = 3
    //     0x522a20: mov             x1, #3
    // 0x522a24: r0 = AllocateContext()
    //     0x522a24: bl              #0xd68aa4  ; AllocateContextStub
    // 0x522a28: mov             x3, x0
    // 0x522a2c: ldr             x0, [fp, #0x10]
    // 0x522a30: stur            x3, [fp, #-8]
    // 0x522a34: StoreField: r3->field_f = r0
    //     0x522a34: stur            w0, [x3, #0xf]
    // 0x522a38: LoadField: r2 = r0->field_7
    //     0x522a38: ldur            x2, [x0, #7]
    // 0x522a3c: r0 = BoxInt64Instr(r2)
    //     0x522a3c: sbfiz           x0, x2, #1, #0x1f
    //     0x522a40: cmp             x2, x0, asr #1
    //     0x522a44: b.eq            #0x522a50
    //     0x522a48: bl              #0xd69bb8
    //     0x522a4c: stur            x2, [x0, #7]
    // 0x522a50: StoreField: r3->field_13 = r0
    //     0x522a50: stur            w0, [x3, #0x13]
    // 0x522a54: StoreField: r3->field_17 = rZR
    //     0x522a54: stur            wzr, [x3, #0x17]
    // 0x522a58: mov             x2, x3
    // 0x522a5c: r1 = Function '<anonymous closure>': static.
    //     0x522a5c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37398] AnonymousClosure: static (0x522c00), in [package:extended_text_library/src/extended_text_utils.dart] ::convertTextInputPostionToTextPainterPostion (0x522a08)
    //     0x522a60: ldr             x1, [x1, #0x398]
    // 0x522a64: r0 = AllocateClosure()
    //     0x522a64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x522a68: mov             x1, x0
    // 0x522a6c: ldr             x0, [fp, #0x18]
    // 0x522a70: r2 = LoadClassIdInstr(r0)
    //     0x522a70: ldur            x2, [x0, #-1]
    //     0x522a74: ubfx            x2, x2, #0xc, #0x14
    // 0x522a78: lsl             x2, x2, #1
    // 0x522a7c: r17 = 6958
    //     0x522a7c: mov             x17, #0x1b2e
    // 0x522a80: cmp             w2, w17
    // 0x522a84: b.gt            #0x522ab0
    // 0x522a88: r17 = 6954
    //     0x522a88: mov             x17, #0x1b2a
    // 0x522a8c: cmp             w2, w17
    // 0x522a90: b.lt            #0x522ab0
    // 0x522a94: stp             x0, x1, [SP, #-0x10]!
    // 0x522a98: mov             x0, x1
    // 0x522a9c: ClosureCall
    //     0x522a9c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x522aa0: ldur            x2, [x0, #0x1f]
    //     0x522aa4: blr             x2
    // 0x522aa8: add             SP, SP, #0x10
    // 0x522aac: b               #0x522ad0
    // 0x522ab0: r2 = LoadClassIdInstr(r0)
    //     0x522ab0: ldur            x2, [x0, #-1]
    //     0x522ab4: ubfx            x2, x2, #0xc, #0x14
    // 0x522ab8: stp             x1, x0, [SP, #-0x10]!
    // 0x522abc: mov             x0, x2
    // 0x522ac0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x522ac0: sub             lr, x0, #1, lsl #12
    //     0x522ac4: ldr             lr, [x21, lr, lsl #3]
    //     0x522ac8: blr             lr
    // 0x522acc: add             SP, SP, #0x10
    // 0x522ad0: ldur            x0, [fp, #-8]
    // 0x522ad4: LoadField: r2 = r0->field_13
    //     0x522ad4: ldur            w2, [x0, #0x13]
    // 0x522ad8: DecompressPointer r2
    //     0x522ad8: add             x2, x2, HEAP, lsl #32
    // 0x522adc: LoadField: r3 = r0->field_f
    //     0x522adc: ldur            w3, [x0, #0xf]
    // 0x522ae0: DecompressPointer r3
    //     0x522ae0: add             x3, x3, HEAP, lsl #32
    // 0x522ae4: LoadField: r4 = r3->field_7
    //     0x522ae4: ldur            x4, [x3, #7]
    // 0x522ae8: r0 = BoxInt64Instr(r4)
    //     0x522ae8: sbfiz           x0, x4, #1, #0x1f
    //     0x522aec: cmp             x4, x0, asr #1
    //     0x522af0: b.eq            #0x522afc
    //     0x522af4: bl              #0xd69bb8
    //     0x522af8: stur            x4, [x0, #7]
    // 0x522afc: cmp             w2, w0
    // 0x522b00: b.eq            #0x522be4
    // 0x522b04: and             w16, w2, w0
    // 0x522b08: branchIfSmi(r16, 0x522b3c)
    //     0x522b08: tbz             w16, #0, #0x522b3c
    // 0x522b0c: r16 = LoadClassIdInstr(r2)
    //     0x522b0c: ldur            x16, [x2, #-1]
    //     0x522b10: ubfx            x16, x16, #0xc, #0x14
    // 0x522b14: cmp             x16, #0x3c
    // 0x522b18: b.ne            #0x522b3c
    // 0x522b1c: r16 = LoadClassIdInstr(r0)
    //     0x522b1c: ldur            x16, [x0, #-1]
    //     0x522b20: ubfx            x16, x16, #0xc, #0x14
    // 0x522b24: cmp             x16, #0x3c
    // 0x522b28: b.ne            #0x522b3c
    // 0x522b2c: LoadField: r16 = r2->field_7
    //     0x522b2c: ldur            x16, [x2, #7]
    // 0x522b30: LoadField: r17 = r0->field_7
    //     0x522b30: ldur            x17, [x0, #7]
    // 0x522b34: cmp             x16, x17
    // 0x522b38: b.eq            #0x522be4
    // 0x522b3c: cmp             w2, NULL
    // 0x522b40: b.eq            #0x522bfc
    // 0x522b44: r0 = LoadInt32Instr(r2)
    //     0x522b44: sbfx            x0, x2, #1, #0x1f
    //     0x522b48: tbz             w2, #0, #0x522b50
    //     0x522b4c: ldur            x0, [x2, #7]
    // 0x522b50: tbz             x0, #0x3f, #0x522b5c
    // 0x522b54: r0 = 0
    //     0x522b54: mov             x0, #0
    // 0x522b58: b               #0x522ba8
    // 0x522b5c: cmp             x0, #0
    // 0x522b60: b.le            #0x522b6c
    // 0x522b64: mov             x0, x2
    // 0x522b68: b               #0x522ba8
    // 0x522b6c: r0 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0x522b6c: mov             x0, #0x76
    //     0x522b70: tbz             w2, #0, #0x522b80
    //     0x522b74: ldur            x0, [x2, #-1]
    //     0x522b78: ubfx            x0, x0, #0xc, #0x14
    //     0x522b7c: lsl             x0, x0, #1
    // 0x522b80: cmp             w0, #0x7a
    // 0x522b84: b.ne            #0x522ba4
    // 0x522b88: LoadField: d0 = r2->field_7
    //     0x522b88: ldur            d0, [x2, #7]
    // 0x522b8c: fcmp            d0, d0
    // 0x522b90: b.vc            #0x522b9c
    // 0x522b94: mov             x0, x2
    // 0x522b98: b               #0x522ba8
    // 0x522b9c: r0 = 0
    //     0x522b9c: mov             x0, #0
    // 0x522ba0: b               #0x522ba8
    // 0x522ba4: r0 = 0
    //     0x522ba4: mov             x0, #0
    // 0x522ba8: LoadField: r1 = r3->field_f
    //     0x522ba8: ldur            w1, [x3, #0xf]
    // 0x522bac: DecompressPointer r1
    //     0x522bac: add             x1, x1, HEAP, lsl #32
    // 0x522bb0: stur            x1, [fp, #-8]
    // 0x522bb4: r2 = LoadInt32Instr(r0)
    //     0x522bb4: sbfx            x2, x0, #1, #0x1f
    //     0x522bb8: tbz             w0, #0, #0x522bc0
    //     0x522bbc: ldur            x2, [x0, #7]
    // 0x522bc0: stur            x2, [fp, #-0x10]
    // 0x522bc4: r0 = TextPosition()
    //     0x522bc4: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x522bc8: ldur            x1, [fp, #-0x10]
    // 0x522bcc: StoreField: r0->field_7 = r1
    //     0x522bcc: stur            x1, [x0, #7]
    // 0x522bd0: ldur            x1, [fp, #-8]
    // 0x522bd4: StoreField: r0->field_f = r1
    //     0x522bd4: stur            w1, [x0, #0xf]
    // 0x522bd8: LeaveFrame
    //     0x522bd8: mov             SP, fp
    //     0x522bdc: ldp             fp, lr, [SP], #0x10
    // 0x522be0: ret
    //     0x522be0: ret             
    // 0x522be4: mov             x0, x3
    // 0x522be8: LeaveFrame
    //     0x522be8: mov             SP, fp
    //     0x522bec: ldp             fp, lr, [SP], #0x10
    // 0x522bf0: ret
    //     0x522bf0: ret             
    // 0x522bf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x522bf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x522bf8: b               #0x522a20
    // 0x522bfc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x522bfc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x522c00, size: 0x208
    // 0x522c00: EnterFrame
    //     0x522c00: stp             fp, lr, [SP, #-0x10]!
    //     0x522c04: mov             fp, SP
    // 0x522c08: ldr             x2, [fp, #0x18]
    // 0x522c0c: LoadField: r3 = r2->field_17
    //     0x522c0c: ldur            w3, [x2, #0x17]
    // 0x522c10: DecompressPointer r3
    //     0x522c10: add             x3, x3, HEAP, lsl #32
    // 0x522c14: ldr             x2, [fp, #0x10]
    // 0x522c18: r4 = LoadClassIdInstr(r2)
    //     0x522c18: ldur            x4, [x2, #-1]
    //     0x522c1c: ubfx            x4, x4, #0xc, #0x14
    // 0x522c20: lsl             x4, x4, #1
    // 0x522c24: r17 = 6950
    //     0x522c24: mov             x17, #0x1b26
    // 0x522c28: cmp             w4, w17
    // 0x522c2c: b.ne            #0x522d1c
    // 0x522c30: LoadField: r5 = r2->field_2f
    //     0x522c30: ldur            w5, [x2, #0x2f]
    // 0x522c34: DecompressPointer r5
    //     0x522c34: add             x5, x5, HEAP, lsl #32
    // 0x522c38: LoadField: r6 = r5->field_7
    //     0x522c38: ldur            w6, [x5, #7]
    // 0x522c3c: DecompressPointer r6
    //     0x522c3c: add             x6, x6, HEAP, lsl #32
    // 0x522c40: LoadField: r5 = r3->field_13
    //     0x522c40: ldur            w5, [x3, #0x13]
    // 0x522c44: DecompressPointer r5
    //     0x522c44: add             x5, x5, HEAP, lsl #32
    // 0x522c48: LoadField: r7 = r2->field_b
    //     0x522c48: ldur            w7, [x2, #0xb]
    // 0x522c4c: DecompressPointer r7
    //     0x522c4c: add             x7, x7, HEAP, lsl #32
    // 0x522c50: cmp             w7, NULL
    // 0x522c54: b.eq            #0x522c68
    // 0x522c58: LoadField: r8 = r7->field_7
    //     0x522c58: ldur            w8, [x7, #7]
    // 0x522c5c: DecompressPointer r8
    //     0x522c5c: add             x8, x8, HEAP, lsl #32
    // 0x522c60: r7 = LoadInt32Instr(r8)
    //     0x522c60: sbfx            x7, x8, #1, #0x1f
    // 0x522c64: b               #0x522c6c
    // 0x522c68: r7 = 0
    //     0x522c68: mov             x7, #0
    // 0x522c6c: r8 = LoadInt32Instr(r6)
    //     0x522c6c: sbfx            x8, x6, #1, #0x1f
    // 0x522c70: sub             x6, x8, x7
    // 0x522c74: cmp             w5, NULL
    // 0x522c78: b.eq            #0x522dfc
    // 0x522c7c: r7 = LoadInt32Instr(r5)
    //     0x522c7c: sbfx            x7, x5, #1, #0x1f
    //     0x522c80: tbz             w5, #0, #0x522c88
    //     0x522c84: ldur            x7, [x5, #7]
    // 0x522c88: sub             x5, x7, x6
    // 0x522c8c: r0 = BoxInt64Instr(r5)
    //     0x522c8c: sbfiz           x0, x5, #1, #0x1f
    //     0x522c90: cmp             x5, x0, asr #1
    //     0x522c94: b.eq            #0x522ca0
    //     0x522c98: bl              #0xd69bb8
    //     0x522c9c: stur            x5, [x0, #7]
    // 0x522ca0: StoreField: r3->field_13 = r0
    //     0x522ca0: stur            w0, [x3, #0x13]
    //     0x522ca4: tbz             w0, #0, #0x522cc0
    //     0x522ca8: ldurb           w16, [x3, #-1]
    //     0x522cac: ldurb           w17, [x0, #-1]
    //     0x522cb0: and             x16, x17, x16, lsr #2
    //     0x522cb4: tst             x16, HEAP, lsr #32
    //     0x522cb8: b.eq            #0x522cc0
    //     0x522cbc: bl              #0xd682ac
    // 0x522cc0: LoadField: r5 = r3->field_17
    //     0x522cc0: ldur            w5, [x3, #0x17]
    // 0x522cc4: DecompressPointer r5
    //     0x522cc4: add             x5, x5, HEAP, lsl #32
    // 0x522cc8: cmp             w5, NULL
    // 0x522ccc: b.eq            #0x522e00
    // 0x522cd0: r6 = LoadInt32Instr(r5)
    //     0x522cd0: sbfx            x6, x5, #1, #0x1f
    //     0x522cd4: tbz             w5, #0, #0x522cdc
    //     0x522cd8: ldur            x6, [x5, #7]
    // 0x522cdc: add             x5, x6, x8
    // 0x522ce0: r0 = BoxInt64Instr(r5)
    //     0x522ce0: sbfiz           x0, x5, #1, #0x1f
    //     0x522ce4: cmp             x5, x0, asr #1
    //     0x522ce8: b.eq            #0x522cf4
    //     0x522cec: bl              #0xd69bb8
    //     0x522cf0: stur            x5, [x0, #7]
    // 0x522cf4: StoreField: r3->field_17 = r0
    //     0x522cf4: stur            w0, [x3, #0x17]
    //     0x522cf8: tbz             w0, #0, #0x522d14
    //     0x522cfc: ldurb           w16, [x3, #-1]
    //     0x522d00: ldurb           w17, [x0, #-1]
    //     0x522d04: and             x16, x17, x16, lsr #2
    //     0x522d08: tst             x16, HEAP, lsr #32
    //     0x522d0c: b.eq            #0x522d14
    //     0x522d10: bl              #0xd682ac
    // 0x522d14: mov             x1, x5
    // 0x522d18: b               #0x522dc8
    // 0x522d1c: LoadField: r5 = r3->field_17
    //     0x522d1c: ldur            w5, [x3, #0x17]
    // 0x522d20: DecompressPointer r5
    //     0x522d20: add             x5, x5, HEAP, lsl #32
    // 0x522d24: r6 = LoadInt32Instr(r4)
    //     0x522d24: sbfx            x6, x4, #1, #0x1f
    // 0x522d28: cmp             x6, #0xd91
    // 0x522d2c: b.lt            #0x522d5c
    // 0x522d30: cmp             x6, #0xd93
    // 0x522d34: b.gt            #0x522d5c
    // 0x522d38: LoadField: r4 = r2->field_b
    //     0x522d38: ldur            w4, [x2, #0xb]
    // 0x522d3c: DecompressPointer r4
    //     0x522d3c: add             x4, x4, HEAP, lsl #32
    // 0x522d40: cmp             w4, NULL
    // 0x522d44: b.eq            #0x522d5c
    // 0x522d48: LoadField: r2 = r4->field_7
    //     0x522d48: ldur            w2, [x4, #7]
    // 0x522d4c: DecompressPointer r2
    //     0x522d4c: add             x2, x2, HEAP, lsl #32
    // 0x522d50: r4 = LoadInt32Instr(r2)
    //     0x522d50: sbfx            x4, x2, #1, #0x1f
    // 0x522d54: mov             x2, x4
    // 0x522d58: b               #0x522d78
    // 0x522d5c: cmp             x6, #0xd95
    // 0x522d60: b.lt            #0x522d74
    // 0x522d64: cmp             x6, #0xd97
    // 0x522d68: b.gt            #0x522d74
    // 0x522d6c: r2 = 1
    //     0x522d6c: mov             x2, #1
    // 0x522d70: b               #0x522d78
    // 0x522d74: r2 = 0
    //     0x522d74: mov             x2, #0
    // 0x522d78: cmp             w5, NULL
    // 0x522d7c: b.eq            #0x522e04
    // 0x522d80: r4 = LoadInt32Instr(r5)
    //     0x522d80: sbfx            x4, x5, #1, #0x1f
    //     0x522d84: tbz             w5, #0, #0x522d8c
    //     0x522d88: ldur            x4, [x5, #7]
    // 0x522d8c: add             x5, x4, x2
    // 0x522d90: r0 = BoxInt64Instr(r5)
    //     0x522d90: sbfiz           x0, x5, #1, #0x1f
    //     0x522d94: cmp             x5, x0, asr #1
    //     0x522d98: b.eq            #0x522da4
    //     0x522d9c: bl              #0xd69bb8
    //     0x522da0: stur            x5, [x0, #7]
    // 0x522da4: StoreField: r3->field_17 = r0
    //     0x522da4: stur            w0, [x3, #0x17]
    //     0x522da8: tbz             w0, #0, #0x522dc4
    //     0x522dac: ldurb           w16, [x3, #-1]
    //     0x522db0: ldurb           w17, [x0, #-1]
    //     0x522db4: and             x16, x17, x16, lsr #2
    //     0x522db8: tst             x16, HEAP, lsr #32
    //     0x522dbc: b.eq            #0x522dc4
    //     0x522dc0: bl              #0xd682ac
    // 0x522dc4: mov             x1, x5
    // 0x522dc8: LoadField: r2 = r3->field_f
    //     0x522dc8: ldur            w2, [x3, #0xf]
    // 0x522dcc: DecompressPointer r2
    //     0x522dcc: add             x2, x2, HEAP, lsl #32
    // 0x522dd0: LoadField: r3 = r2->field_7
    //     0x522dd0: ldur            x3, [x2, #7]
    // 0x522dd4: cmp             x1, x3
    // 0x522dd8: b.lt            #0x522dec
    // 0x522ddc: r0 = false
    //     0x522ddc: add             x0, NULL, #0x30  ; false
    // 0x522de0: LeaveFrame
    //     0x522de0: mov             SP, fp
    //     0x522de4: ldp             fp, lr, [SP], #0x10
    // 0x522de8: ret
    //     0x522de8: ret             
    // 0x522dec: r0 = true
    //     0x522dec: add             x0, NULL, #0x20  ; true
    // 0x522df0: LeaveFrame
    //     0x522df0: mov             SP, fp
    //     0x522df4: ldp             fp, lr, [SP], #0x10
    // 0x522df8: ret
    //     0x522df8: ret             
    // 0x522dfc: r0 = NullErrorSharedWithoutFPURegs()
    //     0x522dfc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x522e00: r0 = NullErrorSharedWithoutFPURegs()
    //     0x522e00: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x522e04: r0 = NullErrorSharedWithoutFPURegs()
    //     0x522e04: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ textSpanToActualText(/* No info */) {
    // ** addr: 0x68be50, size: 0x104
    // 0x68be50: EnterFrame
    //     0x68be50: stp             fp, lr, [SP, #-0x10]!
    //     0x68be54: mov             fp, SP
    // 0x68be58: AllocStack(0x8)
    //     0x68be58: sub             SP, SP, #8
    // 0x68be5c: CheckStackOverflow
    //     0x68be5c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68be60: cmp             SP, x16
    //     0x68be64: b.ls            #0x68bf4c
    // 0x68be68: r0 = StringBuffer()
    //     0x68be68: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x68be6c: stur            x0, [fp, #-8]
    // 0x68be70: SaveReg r0
    //     0x68be70: str             x0, [SP, #-8]!
    // 0x68be74: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x68be74: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x68be78: r0 = StringBuffer()
    //     0x68be78: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x68be7c: add             SP, SP, #8
    // 0x68be80: r1 = 1
    //     0x68be80: mov             x1, #1
    // 0x68be84: r0 = AllocateContext()
    //     0x68be84: bl              #0xd68aa4  ; AllocateContextStub
    // 0x68be88: mov             x1, x0
    // 0x68be8c: ldur            x0, [fp, #-8]
    // 0x68be90: StoreField: r1->field_f = r0
    //     0x68be90: stur            w0, [x1, #0xf]
    // 0x68be94: ldr             x3, [fp, #0x10]
    // 0x68be98: r2 = LoadClassIdInstr(r3)
    //     0x68be98: ldur            x2, [x3, #-1]
    //     0x68be9c: ubfx            x2, x2, #0xc, #0x14
    // 0x68bea0: lsl             x2, x2, #1
    // 0x68bea4: r17 = 6958
    //     0x68bea4: mov             x17, #0x1b2e
    // 0x68bea8: cmp             w2, w17
    // 0x68beac: b.gt            #0x68bef8
    // 0x68beb0: r17 = 6954
    //     0x68beb0: mov             x17, #0x1b2a
    // 0x68beb4: cmp             w2, w17
    // 0x68beb8: b.lt            #0x68bef8
    // 0x68bebc: r17 = 6950
    //     0x68bebc: mov             x17, #0x1b26
    // 0x68bec0: cmp             w2, w17
    // 0x68bec4: b.ne            #0x68bee0
    // 0x68bec8: LoadField: r1 = r3->field_2f
    //     0x68bec8: ldur            w1, [x3, #0x2f]
    // 0x68becc: DecompressPointer r1
    //     0x68becc: add             x1, x1, HEAP, lsl #32
    // 0x68bed0: stp             x1, x0, [SP, #-0x10]!
    // 0x68bed4: r0 = write()
    //     0x68bed4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0x68bed8: add             SP, SP, #0x10
    // 0x68bedc: b               #0x68bf30
    // 0x68bee0: ldur            x16, [fp, #-8]
    // 0x68bee4: r30 = 131064
    //     0x68bee4: mov             lr, #0x1fff8
    // 0x68bee8: stp             lr, x16, [SP, #-0x10]!
    // 0x68beec: r0 = writeCharCode()
    //     0x68beec: bl              #0x4d3a84  ; [dart:core] StringBuffer::writeCharCode
    // 0x68bef0: add             SP, SP, #0x10
    // 0x68bef4: b               #0x68bf30
    // 0x68bef8: mov             x2, x1
    // 0x68befc: r1 = Function '<anonymous closure>': static.
    //     0x68befc: add             x1, PP, #0x37, lsl #12  ; [pp+0x37658] AnonymousClosure: static (0x68bf54), in [package:extended_text_library/src/extended_text_utils.dart] ::textSpanToActualText (0x68be50)
    //     0x68bf00: ldr             x1, [x1, #0x658]
    // 0x68bf04: r0 = AllocateClosure()
    //     0x68bf04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x68bf08: mov             x1, x0
    // 0x68bf0c: ldr             x0, [fp, #0x10]
    // 0x68bf10: r2 = LoadClassIdInstr(r0)
    //     0x68bf10: ldur            x2, [x0, #-1]
    //     0x68bf14: ubfx            x2, x2, #0xc, #0x14
    // 0x68bf18: stp             x1, x0, [SP, #-0x10]!
    // 0x68bf1c: mov             x0, x2
    // 0x68bf20: r0 = GDT[cid_x0 + -0x1000]()
    //     0x68bf20: sub             lr, x0, #1, lsl #12
    //     0x68bf24: ldr             lr, [x21, lr, lsl #3]
    //     0x68bf28: blr             lr
    // 0x68bf2c: add             SP, SP, #0x10
    // 0x68bf30: ldur            x16, [fp, #-8]
    // 0x68bf34: SaveReg r16
    //     0x68bf34: str             x16, [SP, #-8]!
    // 0x68bf38: r0 = toString()
    //     0x68bf38: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x68bf3c: add             SP, SP, #8
    // 0x68bf40: LeaveFrame
    //     0x68bf40: mov             SP, fp
    //     0x68bf44: ldp             fp, lr, [SP], #0x10
    // 0x68bf48: ret
    //     0x68bf48: ret             
    // 0x68bf4c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68bf4c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68bf50: b               #0x68be68
  }
  [closure] static bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x68bf54, size: 0xcc
    // 0x68bf54: EnterFrame
    //     0x68bf54: stp             fp, lr, [SP, #-0x10]!
    //     0x68bf58: mov             fp, SP
    // 0x68bf5c: ldr             x0, [fp, #0x18]
    // 0x68bf60: LoadField: r1 = r0->field_17
    //     0x68bf60: ldur            w1, [x0, #0x17]
    // 0x68bf64: DecompressPointer r1
    //     0x68bf64: add             x1, x1, HEAP, lsl #32
    // 0x68bf68: CheckStackOverflow
    //     0x68bf68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68bf6c: cmp             SP, x16
    //     0x68bf70: b.ls            #0x68c018
    // 0x68bf74: ldr             x0, [fp, #0x10]
    // 0x68bf78: r2 = LoadClassIdInstr(r0)
    //     0x68bf78: ldur            x2, [x0, #-1]
    //     0x68bf7c: ubfx            x2, x2, #0xc, #0x14
    // 0x68bf80: lsl             x2, x2, #1
    // 0x68bf84: r17 = 6950
    //     0x68bf84: mov             x17, #0x1b26
    // 0x68bf88: cmp             w2, w17
    // 0x68bf8c: b.ne            #0x68bfb0
    // 0x68bf90: LoadField: r2 = r1->field_f
    //     0x68bf90: ldur            w2, [x1, #0xf]
    // 0x68bf94: DecompressPointer r2
    //     0x68bf94: add             x2, x2, HEAP, lsl #32
    // 0x68bf98: LoadField: r1 = r0->field_2f
    //     0x68bf98: ldur            w1, [x0, #0x2f]
    // 0x68bf9c: DecompressPointer r1
    //     0x68bf9c: add             x1, x1, HEAP, lsl #32
    // 0x68bfa0: stp             x1, x2, [SP, #-0x10]!
    // 0x68bfa4: r0 = write()
    //     0x68bfa4: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0x68bfa8: add             SP, SP, #0x10
    // 0x68bfac: b               #0x68c008
    // 0x68bfb0: LoadField: r3 = r1->field_f
    //     0x68bfb0: ldur            w3, [x1, #0xf]
    // 0x68bfb4: DecompressPointer r3
    //     0x68bfb4: add             x3, x3, HEAP, lsl #32
    // 0x68bfb8: r17 = 6958
    //     0x68bfb8: mov             x17, #0x1b2e
    // 0x68bfbc: cmp             w2, w17
    // 0x68bfc0: b.gt            #0x68bfe4
    // 0x68bfc4: r17 = 6954
    //     0x68bfc4: mov             x17, #0x1b2a
    // 0x68bfc8: cmp             w2, w17
    // 0x68bfcc: b.lt            #0x68bfe4
    // 0x68bfd0: r16 = 131064
    //     0x68bfd0: mov             x16, #0x1fff8
    // 0x68bfd4: stp             x16, x3, [SP, #-0x10]!
    // 0x68bfd8: r0 = writeCharCode()
    //     0x68bfd8: bl              #0x4d3a84  ; [dart:core] StringBuffer::writeCharCode
    // 0x68bfdc: add             SP, SP, #0x10
    // 0x68bfe0: b               #0x68c008
    // 0x68bfe4: r1 = LoadClassIdInstr(r0)
    //     0x68bfe4: ldur            x1, [x0, #-1]
    //     0x68bfe8: ubfx            x1, x1, #0xc, #0x14
    // 0x68bfec: stp             x3, x0, [SP, #-0x10]!
    // 0x68bff0: mov             x0, x1
    // 0x68bff4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x68bff4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x68bff8: r0 = GDT[cid_x0 + -0xec2]()
    //     0x68bff8: sub             lr, x0, #0xec2
    //     0x68bffc: ldr             lr, [x21, lr, lsl #3]
    //     0x68c000: blr             lr
    // 0x68c004: add             SP, SP, #0x10
    // 0x68c008: r0 = true
    //     0x68c008: add             x0, NULL, #0x20  ; true
    // 0x68c00c: LeaveFrame
    //     0x68c00c: mov             SP, fp
    //     0x68c010: ldp             fp, lr, [SP], #0x10
    // 0x68c014: ret
    //     0x68c014: ret             
    // 0x68c018: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68c018: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68c01c: b               #0x68bf74
  }
  static _ correctCaretOffset(/* No info */) {
    // ** addr: 0x7aa7bc, size: 0x16c
    // 0x7aa7bc: EnterFrame
    //     0x7aa7bc: stp             fp, lr, [SP, #-0x10]!
    //     0x7aa7c0: mov             fp, SP
    // 0x7aa7c4: AllocStack(0x18)
    //     0x7aa7c4: sub             SP, SP, #0x18
    // 0x7aa7c8: CheckStackOverflow
    //     0x7aa7c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aa7cc: cmp             SP, x16
    //     0x7aa7d0: b.ls            #0x7aa920
    // 0x7aa7d4: ldr             x2, [fp, #0x20]
    // 0x7aa7d8: LoadField: r3 = r2->field_b
    //     0x7aa7d8: ldur            w3, [x2, #0xb]
    // 0x7aa7dc: DecompressPointer r3
    //     0x7aa7dc: add             x3, x3, HEAP, lsl #32
    // 0x7aa7e0: stur            x3, [fp, #-0x10]
    // 0x7aa7e4: LoadField: r0 = r3->field_7
    //     0x7aa7e4: ldur            x0, [x3, #7]
    // 0x7aa7e8: tbnz            x0, #0x3f, #0x7aa910
    // 0x7aa7ec: LoadField: r1 = r3->field_f
    //     0x7aa7ec: ldur            x1, [x3, #0xf]
    // 0x7aa7f0: tbnz            x1, #0x3f, #0x7aa910
    // 0x7aa7f4: cmp             x0, x1
    // 0x7aa7f8: b.ne            #0x7aa910
    // 0x7aa7fc: LoadField: r4 = r3->field_1f
    //     0x7aa7fc: ldur            x4, [x3, #0x1f]
    // 0x7aa800: r0 = BoxInt64Instr(r4)
    //     0x7aa800: sbfiz           x0, x4, #1, #0x1f
    //     0x7aa804: cmp             x4, x0, asr #1
    //     0x7aa808: b.eq            #0x7aa814
    //     0x7aa80c: bl              #0xd69bb8
    //     0x7aa810: stur            x4, [x0, #7]
    // 0x7aa814: stur            x0, [fp, #-8]
    // 0x7aa818: r1 = 1
    //     0x7aa818: mov             x1, #1
    // 0x7aa81c: r0 = AllocateContext()
    //     0x7aa81c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7aa820: mov             x3, x0
    // 0x7aa824: ldur            x0, [fp, #-8]
    // 0x7aa828: stur            x3, [fp, #-0x18]
    // 0x7aa82c: StoreField: r3->field_f = r0
    //     0x7aa82c: stur            w0, [x3, #0xf]
    // 0x7aa830: mov             x2, x3
    // 0x7aa834: r1 = Function '<anonymous closure>': static.
    //     0x7aa834: add             x1, PP, #0x37, lsl #12  ; [pp+0x37698] AnonymousClosure: static (0x7aa928), in [package:extended_text_library/src/extended_text_utils.dart] ::correctCaretOffset (0x7aa7bc)
    //     0x7aa838: ldr             x1, [x1, #0x698]
    // 0x7aa83c: r0 = AllocateClosure()
    //     0x7aa83c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7aa840: ldr             x16, [fp, #0x18]
    // 0x7aa844: stp             x0, x16, [SP, #-0x10]!
    // 0x7aa848: r0 = visitChildren()
    //     0x7aa848: bl              #0xcdf548  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x7aa84c: add             SP, SP, #0x10
    // 0x7aa850: ldur            x0, [fp, #-0x18]
    // 0x7aa854: LoadField: r2 = r0->field_f
    //     0x7aa854: ldur            w2, [x0, #0xf]
    // 0x7aa858: DecompressPointer r2
    //     0x7aa858: add             x2, x2, HEAP, lsl #32
    // 0x7aa85c: ldur            x3, [fp, #-0x10]
    // 0x7aa860: LoadField: r4 = r3->field_17
    //     0x7aa860: ldur            x4, [x3, #0x17]
    // 0x7aa864: r0 = BoxInt64Instr(r4)
    //     0x7aa864: sbfiz           x0, x4, #1, #0x1f
    //     0x7aa868: cmp             x4, x0, asr #1
    //     0x7aa86c: b.eq            #0x7aa878
    //     0x7aa870: bl              #0xd69bb8
    //     0x7aa874: stur            x4, [x0, #7]
    // 0x7aa878: cmp             w2, w0
    // 0x7aa87c: b.eq            #0x7aa904
    // 0x7aa880: and             w16, w2, w0
    // 0x7aa884: branchIfSmi(r16, 0x7aa8b8)
    //     0x7aa884: tbz             w16, #0, #0x7aa8b8
    // 0x7aa888: r16 = LoadClassIdInstr(r2)
    //     0x7aa888: ldur            x16, [x2, #-1]
    //     0x7aa88c: ubfx            x16, x16, #0xc, #0x14
    // 0x7aa890: cmp             x16, #0x3c
    // 0x7aa894: b.ne            #0x7aa8b8
    // 0x7aa898: r16 = LoadClassIdInstr(r0)
    //     0x7aa898: ldur            x16, [x0, #-1]
    //     0x7aa89c: ubfx            x16, x16, #0xc, #0x14
    // 0x7aa8a0: cmp             x16, #0x3c
    // 0x7aa8a4: b.ne            #0x7aa8b8
    // 0x7aa8a8: LoadField: r16 = r2->field_7
    //     0x7aa8a8: ldur            x16, [x2, #7]
    // 0x7aa8ac: LoadField: r17 = r0->field_7
    //     0x7aa8ac: ldur            x17, [x0, #7]
    // 0x7aa8b0: cmp             x16, x17
    // 0x7aa8b4: b.eq            #0x7aa904
    // 0x7aa8b8: stp             x2, x3, [SP, #-0x10]!
    // 0x7aa8bc: SaveReg r2
    //     0x7aa8bc: str             x2, [SP, #-8]!
    // 0x7aa8c0: r4 = const [0, 0x3, 0x3, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0x7aa8c0: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2de50] List(9) [0, 0x3, 0x3, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    //     0x7aa8c4: ldr             x4, [x4, #0xe50]
    // 0x7aa8c8: r0 = copyWith()
    //     0x7aa8c8: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x7aa8cc: add             SP, SP, #0x18
    // 0x7aa8d0: ldr             x16, [fp, #0x20]
    // 0x7aa8d4: stp             x0, x16, [SP, #-0x10]!
    // 0x7aa8d8: r4 = const [0, 0x2, 0x2, 0x1, selection, 0x1, null]
    //     0x7aa8d8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f640] List(7) [0, 0x2, 0x2, 0x1, "selection", 0x1, Null]
    //     0x7aa8dc: ldr             x4, [x4, #0x640]
    // 0x7aa8e0: r0 = copyWith()
    //     0x7aa8e0: bl              #0x79a550  ; [package:flutter/src/services/text_input.dart] TextEditingValue::copyWith
    // 0x7aa8e4: add             SP, SP, #0x10
    // 0x7aa8e8: stur            x0, [fp, #-8]
    // 0x7aa8ec: ldr             x16, [fp, #0x10]
    // 0x7aa8f0: stp             x0, x16, [SP, #-0x10]!
    // 0x7aa8f4: r0 = setEditingState()
    //     0x7aa8f4: bl              #0x7a34c4  ; [package:flutter/src/services/text_input.dart] TextInputConnection::setEditingState
    // 0x7aa8f8: add             SP, SP, #0x10
    // 0x7aa8fc: ldur            x1, [fp, #-8]
    // 0x7aa900: b               #0x7aa908
    // 0x7aa904: ldr             x1, [fp, #0x20]
    // 0x7aa908: mov             x0, x1
    // 0x7aa90c: b               #0x7aa914
    // 0x7aa910: ldr             x0, [fp, #0x20]
    // 0x7aa914: LeaveFrame
    //     0x7aa914: mov             SP, fp
    //     0x7aa918: ldp             fp, lr, [SP], #0x10
    // 0x7aa91c: ret
    //     0x7aa91c: ret             
    // 0x7aa920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aa920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aa924: b               #0x7aa7d4
  }
  [closure] static bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x7aa928, size: 0x124
    // 0x7aa928: EnterFrame
    //     0x7aa928: stp             fp, lr, [SP, #-0x10]!
    //     0x7aa92c: mov             fp, SP
    // 0x7aa930: ldr             x2, [fp, #0x18]
    // 0x7aa934: LoadField: r3 = r2->field_17
    //     0x7aa934: ldur            w3, [x2, #0x17]
    // 0x7aa938: DecompressPointer r3
    //     0x7aa938: add             x3, x3, HEAP, lsl #32
    // 0x7aa93c: ldr             x2, [fp, #0x10]
    // 0x7aa940: r4 = LoadClassIdInstr(r2)
    //     0x7aa940: ldur            x4, [x2, #-1]
    //     0x7aa944: ubfx            x4, x4, #0xc, #0x14
    // 0x7aa948: lsl             x4, x4, #1
    // 0x7aa94c: r17 = 6950
    //     0x7aa94c: mov             x17, #0x1b26
    // 0x7aa950: cmp             w4, w17
    // 0x7aa954: b.ne            #0x7aaa38
    // 0x7aa958: LoadField: r4 = r3->field_f
    //     0x7aa958: ldur            w4, [x3, #0xf]
    // 0x7aa95c: DecompressPointer r4
    //     0x7aa95c: add             x4, x4, HEAP, lsl #32
    // 0x7aa960: LoadField: r5 = r2->field_37
    //     0x7aa960: ldur            w5, [x2, #0x37]
    // 0x7aa964: DecompressPointer r5
    //     0x7aa964: add             x5, x5, HEAP, lsl #32
    // 0x7aa968: LoadField: r2 = r5->field_7
    //     0x7aa968: ldur            x2, [x5, #7]
    // 0x7aa96c: cmp             w4, NULL
    // 0x7aa970: b.eq            #0x7aaa48
    // 0x7aa974: r6 = LoadInt32Instr(r4)
    //     0x7aa974: sbfx            x6, x4, #1, #0x1f
    //     0x7aa978: tbz             w4, #0, #0x7aa980
    //     0x7aa97c: ldur            x6, [x4, #7]
    // 0x7aa980: cmp             x6, x2
    // 0x7aa984: b.lt            #0x7aaa38
    // 0x7aa988: LoadField: r4 = r5->field_f
    //     0x7aa988: ldur            x4, [x5, #0xf]
    // 0x7aa98c: cmp             x6, x4
    // 0x7aa990: b.gt            #0x7aaa38
    // 0x7aa994: d0 = 2.000000
    //     0x7aa994: fmov            d0, #2.00000000
    // 0x7aa998: sub             x5, x4, x2
    // 0x7aa99c: scvtf           d1, x5
    // 0x7aa9a0: fdiv            d2, d1, d0
    // 0x7aa9a4: scvtf           d0, x2
    // 0x7aa9a8: fadd            d1, d2, d0
    // 0x7aa9ac: scvtf           d0, x6
    // 0x7aa9b0: fcmp            d0, d1
    // 0x7aa9b4: b.vs            #0x7aa9f4
    // 0x7aa9b8: b.le            #0x7aa9f4
    // 0x7aa9bc: r0 = BoxInt64Instr(r4)
    //     0x7aa9bc: sbfiz           x0, x4, #1, #0x1f
    //     0x7aa9c0: cmp             x4, x0, asr #1
    //     0x7aa9c4: b.eq            #0x7aa9d0
    //     0x7aa9c8: bl              #0xd69bb8
    //     0x7aa9cc: stur            x4, [x0, #7]
    // 0x7aa9d0: StoreField: r3->field_f = r0
    //     0x7aa9d0: stur            w0, [x3, #0xf]
    //     0x7aa9d4: tbz             w0, #0, #0x7aa9f0
    //     0x7aa9d8: ldurb           w16, [x3, #-1]
    //     0x7aa9dc: ldurb           w17, [x0, #-1]
    //     0x7aa9e0: and             x16, x17, x16, lsr #2
    //     0x7aa9e4: tst             x16, HEAP, lsr #32
    //     0x7aa9e8: b.eq            #0x7aa9f0
    //     0x7aa9ec: bl              #0xd682ac
    // 0x7aa9f0: b               #0x7aaa28
    // 0x7aa9f4: r0 = BoxInt64Instr(r2)
    //     0x7aa9f4: sbfiz           x0, x2, #1, #0x1f
    //     0x7aa9f8: cmp             x2, x0, asr #1
    //     0x7aa9fc: b.eq            #0x7aaa08
    //     0x7aaa00: bl              #0xd69bb8
    //     0x7aaa04: stur            x2, [x0, #7]
    // 0x7aaa08: StoreField: r3->field_f = r0
    //     0x7aaa08: stur            w0, [x3, #0xf]
    //     0x7aaa0c: tbz             w0, #0, #0x7aaa28
    //     0x7aaa10: ldurb           w16, [x3, #-1]
    //     0x7aaa14: ldurb           w17, [x0, #-1]
    //     0x7aaa18: and             x16, x17, x16, lsr #2
    //     0x7aaa1c: tst             x16, HEAP, lsr #32
    //     0x7aaa20: b.eq            #0x7aaa28
    //     0x7aaa24: bl              #0xd682ac
    // 0x7aaa28: r0 = false
    //     0x7aaa28: add             x0, NULL, #0x30  ; false
    // 0x7aaa2c: LeaveFrame
    //     0x7aaa2c: mov             SP, fp
    //     0x7aaa30: ldp             fp, lr, [SP], #0x10
    // 0x7aaa34: ret
    //     0x7aaa34: ret             
    // 0x7aaa38: r0 = true
    //     0x7aaa38: add             x0, NULL, #0x20  ; true
    // 0x7aaa3c: LeaveFrame
    //     0x7aaa3c: mov             SP, fp
    //     0x7aaa40: ldp             fp, lr, [SP], #0x10
    // 0x7aaa44: ret
    //     0x7aaa44: ret             
    // 0x7aaa48: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7aaa48: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ handleSpecialTextSpanDelete(/* No info */) {
    // ** addr: 0x7aaa4c, size: 0x1b8
    // 0x7aaa4c: EnterFrame
    //     0x7aaa4c: stp             fp, lr, [SP, #-0x10]!
    //     0x7aaa50: mov             fp, SP
    // 0x7aaa54: AllocStack(0x18)
    //     0x7aaa54: sub             SP, SP, #0x18
    // 0x7aaa58: CheckStackOverflow
    //     0x7aaa58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aaa5c: cmp             SP, x16
    //     0x7aaa60: b.ls            #0x7aabfc
    // 0x7aaa64: ldr             x0, [fp, #0x20]
    // 0x7aaa68: LoadField: r1 = r0->field_7
    //     0x7aaa68: ldur            w1, [x0, #7]
    // 0x7aaa6c: DecompressPointer r1
    //     0x7aaa6c: add             x1, x1, HEAP, lsl #32
    // 0x7aaa70: ldr             x0, [fp, #0x28]
    // 0x7aaa74: stur            x1, [fp, #-0x10]
    // 0x7aaa78: LoadField: r2 = r0->field_7
    //     0x7aaa78: ldur            w2, [x0, #7]
    // 0x7aaa7c: DecompressPointer r2
    //     0x7aaa7c: add             x2, x2, HEAP, lsl #32
    // 0x7aaa80: stur            x2, [fp, #-8]
    // 0x7aaa84: r1 = 3
    //     0x7aaa84: mov             x1, #3
    // 0x7aaa88: r0 = AllocateContext()
    //     0x7aaa88: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7aaa8c: mov             x4, x0
    // 0x7aaa90: ldur            x3, [fp, #-8]
    // 0x7aaa94: stur            x4, [fp, #-0x18]
    // 0x7aaa98: StoreField: r4->field_f = r3
    //     0x7aaa98: stur            w3, [x4, #0xf]
    // 0x7aaa9c: ldur            x0, [fp, #-0x10]
    // 0x7aaaa0: LoadField: r1 = r0->field_7
    //     0x7aaaa0: ldur            w1, [x0, #7]
    // 0x7aaaa4: DecompressPointer r1
    //     0x7aaaa4: add             x1, x1, HEAP, lsl #32
    // 0x7aaaa8: LoadField: r0 = r3->field_7
    //     0x7aaaa8: ldur            w0, [x3, #7]
    // 0x7aaaac: DecompressPointer r0
    //     0x7aaaac: add             x0, x0, HEAP, lsl #32
    // 0x7aaab0: r2 = LoadInt32Instr(r1)
    //     0x7aaab0: sbfx            x2, x1, #1, #0x1f
    // 0x7aaab4: r1 = LoadInt32Instr(r0)
    //     0x7aaab4: sbfx            x1, x0, #1, #0x1f
    // 0x7aaab8: cmp             x2, x1
    // 0x7aaabc: b.le            #0x7aabec
    // 0x7aaac0: ldr             x5, [fp, #0x28]
    // 0x7aaac4: LoadField: r6 = r5->field_b
    //     0x7aaac4: ldur            w6, [x5, #0xb]
    // 0x7aaac8: DecompressPointer r6
    //     0x7aaac8: add             x6, x6, HEAP, lsl #32
    // 0x7aaacc: stur            x6, [fp, #-0x10]
    // 0x7aaad0: LoadField: r2 = r6->field_1f
    //     0x7aaad0: ldur            x2, [x6, #0x1f]
    // 0x7aaad4: r0 = BoxInt64Instr(r2)
    //     0x7aaad4: sbfiz           x0, x2, #1, #0x1f
    //     0x7aaad8: cmp             x2, x0, asr #1
    //     0x7aaadc: b.eq            #0x7aaae8
    //     0x7aaae0: bl              #0xd69bb8
    //     0x7aaae4: stur            x2, [x0, #7]
    // 0x7aaae8: StoreField: r4->field_13 = r0
    //     0x7aaae8: stur            w0, [x4, #0x13]
    // 0x7aaaec: StoreField: r4->field_17 = r0
    //     0x7aaaec: stur            w0, [x4, #0x17]
    // 0x7aaaf0: cmp             x2, #0
    // 0x7aaaf4: b.le            #0x7aabe0
    // 0x7aaaf8: mov             x2, x4
    // 0x7aaafc: r1 = Function '<anonymous closure>': static.
    //     0x7aaafc: add             x1, PP, #0x37, lsl #12  ; [pp+0x376a0] AnonymousClosure: static (0x7aac04), in [package:extended_text_library/src/extended_text_utils.dart] ::handleSpecialTextSpanDelete (0x7aaa4c)
    //     0x7aab00: ldr             x1, [x1, #0x6a0]
    // 0x7aab04: r0 = AllocateClosure()
    //     0x7aab04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7aab08: ldr             x16, [fp, #0x18]
    // 0x7aab0c: stp             x0, x16, [SP, #-0x10]!
    // 0x7aab10: r0 = visitChildren()
    //     0x7aab10: bl              #0xcdf548  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x7aab14: add             SP, SP, #0x10
    // 0x7aab18: ldur            x1, [fp, #-0x18]
    // 0x7aab1c: LoadField: r0 = r1->field_f
    //     0x7aab1c: ldur            w0, [x1, #0xf]
    // 0x7aab20: DecompressPointer r0
    //     0x7aab20: add             x0, x0, HEAP, lsl #32
    // 0x7aab24: r2 = LoadClassIdInstr(r0)
    //     0x7aab24: ldur            x2, [x0, #-1]
    //     0x7aab28: ubfx            x2, x2, #0xc, #0x14
    // 0x7aab2c: ldur            x16, [fp, #-8]
    // 0x7aab30: stp             x16, x0, [SP, #-0x10]!
    // 0x7aab34: mov             x0, x2
    // 0x7aab38: mov             lr, x0
    // 0x7aab3c: ldr             lr, [x21, lr, lsl #3]
    // 0x7aab40: blr             lr
    // 0x7aab44: add             SP, SP, #0x10
    // 0x7aab48: tbz             w0, #4, #0x7aabd8
    // 0x7aab4c: ldur            x0, [fp, #-0x18]
    // 0x7aab50: ldur            x1, [fp, #-0x10]
    // 0x7aab54: LoadField: r2 = r0->field_f
    //     0x7aab54: ldur            w2, [x0, #0xf]
    // 0x7aab58: DecompressPointer r2
    //     0x7aab58: add             x2, x2, HEAP, lsl #32
    // 0x7aab5c: stur            x2, [fp, #-8]
    // 0x7aab60: LoadField: r3 = r0->field_17
    //     0x7aab60: ldur            w3, [x0, #0x17]
    // 0x7aab64: DecompressPointer r3
    //     0x7aab64: add             x3, x3, HEAP, lsl #32
    // 0x7aab68: LoadField: r0 = r1->field_27
    //     0x7aab68: ldur            w0, [x1, #0x27]
    // 0x7aab6c: DecompressPointer r0
    //     0x7aab6c: add             x0, x0, HEAP, lsl #32
    // 0x7aab70: LoadField: r4 = r1->field_2b
    //     0x7aab70: ldur            w4, [x1, #0x2b]
    // 0x7aab74: DecompressPointer r4
    //     0x7aab74: add             x4, x4, HEAP, lsl #32
    // 0x7aab78: stp             x3, x1, [SP, #-0x10]!
    // 0x7aab7c: stp             x0, x3, [SP, #-0x10]!
    // 0x7aab80: SaveReg r4
    //     0x7aab80: str             x4, [SP, #-8]!
    // 0x7aab84: r4 = const [0, 0x5, 0x5, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, isDirectional, 0x4, null]
    //     0x7aab84: add             x4, PP, #0x37, lsl #12  ; [pp+0x37428] List(13) [0, 0x5, 0x5, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, "isDirectional", 0x4, Null]
    //     0x7aab88: ldr             x4, [x4, #0x428]
    // 0x7aab8c: r0 = copyWith()
    //     0x7aab8c: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x7aab90: add             SP, SP, #0x28
    // 0x7aab94: stur            x0, [fp, #-0x10]
    // 0x7aab98: r0 = TextEditingValue()
    //     0x7aab98: bl              #0x5cb3f0  ; AllocateTextEditingValueStub -> TextEditingValue (size=0x14)
    // 0x7aab9c: mov             x1, x0
    // 0x7aaba0: ldur            x0, [fp, #-8]
    // 0x7aaba4: stur            x1, [fp, #-0x18]
    // 0x7aaba8: StoreField: r1->field_7 = r0
    //     0x7aaba8: stur            w0, [x1, #7]
    // 0x7aabac: ldur            x0, [fp, #-0x10]
    // 0x7aabb0: StoreField: r1->field_b = r0
    //     0x7aabb0: stur            w0, [x1, #0xb]
    // 0x7aabb4: r0 = Instance_TextRange
    //     0x7aabb4: add             x0, PP, #0x1c, lsl #12  ; [pp+0x1c2e0] Obj!TextRange@b5c921
    //     0x7aabb8: ldr             x0, [x0, #0x2e0]
    // 0x7aabbc: StoreField: r1->field_f = r0
    //     0x7aabbc: stur            w0, [x1, #0xf]
    // 0x7aabc0: ldr             x16, [fp, #0x10]
    // 0x7aabc4: stp             x1, x16, [SP, #-0x10]!
    // 0x7aabc8: r0 = setEditingState()
    //     0x7aabc8: bl              #0x7a34c4  ; [package:flutter/src/services/text_input.dart] TextInputConnection::setEditingState
    // 0x7aabcc: add             SP, SP, #0x10
    // 0x7aabd0: ldur            x1, [fp, #-0x18]
    // 0x7aabd4: b               #0x7aabe4
    // 0x7aabd8: ldr             x1, [fp, #0x28]
    // 0x7aabdc: b               #0x7aabe4
    // 0x7aabe0: ldr             x1, [fp, #0x28]
    // 0x7aabe4: mov             x0, x1
    // 0x7aabe8: b               #0x7aabf0
    // 0x7aabec: ldr             x0, [fp, #0x28]
    // 0x7aabf0: LeaveFrame
    //     0x7aabf0: mov             SP, fp
    //     0x7aabf4: ldp             fp, lr, [SP], #0x10
    // 0x7aabf8: ret
    //     0x7aabf8: ret             
    // 0x7aabfc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aabfc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aac00: b               #0x7aaa64
  }
  [closure] static bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x7aac04, size: 0x154
    // 0x7aac04: EnterFrame
    //     0x7aac04: stp             fp, lr, [SP, #-0x10]!
    //     0x7aac08: mov             fp, SP
    // 0x7aac0c: AllocStack(0x18)
    //     0x7aac0c: sub             SP, SP, #0x18
    // 0x7aac10: SetupParameters()
    //     0x7aac10: ldr             x0, [fp, #0x18]
    //     0x7aac14: ldur            w1, [x0, #0x17]
    //     0x7aac18: add             x1, x1, HEAP, lsl #32
    //     0x7aac1c: stur            x1, [fp, #-0x18]
    // 0x7aac20: CheckStackOverflow
    //     0x7aac20: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aac24: cmp             SP, x16
    //     0x7aac28: b.ls            #0x7aad48
    // 0x7aac2c: ldr             x0, [fp, #0x10]
    // 0x7aac30: r2 = LoadClassIdInstr(r0)
    //     0x7aac30: ldur            x2, [x0, #-1]
    //     0x7aac34: ubfx            x2, x2, #0xc, #0x14
    // 0x7aac38: lsl             x2, x2, #1
    // 0x7aac3c: r17 = 6950
    //     0x7aac3c: mov             x17, #0x1b26
    // 0x7aac40: cmp             w2, w17
    // 0x7aac44: b.ne            #0x7aad38
    // 0x7aac48: LoadField: r2 = r1->field_13
    //     0x7aac48: ldur            w2, [x1, #0x13]
    // 0x7aac4c: DecompressPointer r2
    //     0x7aac4c: add             x2, x2, HEAP, lsl #32
    // 0x7aac50: LoadField: r3 = r0->field_37
    //     0x7aac50: ldur            w3, [x0, #0x37]
    // 0x7aac54: DecompressPointer r3
    //     0x7aac54: add             x3, x3, HEAP, lsl #32
    // 0x7aac58: LoadField: r0 = r3->field_7
    //     0x7aac58: ldur            x0, [x3, #7]
    // 0x7aac5c: stur            x0, [fp, #-0x10]
    // 0x7aac60: cmp             w2, NULL
    // 0x7aac64: b.eq            #0x7aad50
    // 0x7aac68: r4 = LoadInt32Instr(r2)
    //     0x7aac68: sbfx            x4, x2, #1, #0x1f
    //     0x7aac6c: tbz             w2, #0, #0x7aac74
    //     0x7aac70: ldur            x4, [x2, #7]
    // 0x7aac74: stur            x4, [fp, #-8]
    // 0x7aac78: cmp             x4, x0
    // 0x7aac7c: b.le            #0x7aad38
    // 0x7aac80: LoadField: r5 = r3->field_f
    //     0x7aac80: ldur            x5, [x3, #0xf]
    // 0x7aac84: cmp             x4, x5
    // 0x7aac88: b.ge            #0x7aad38
    // 0x7aac8c: LoadField: r3 = r1->field_f
    //     0x7aac8c: ldur            w3, [x1, #0xf]
    // 0x7aac90: DecompressPointer r3
    //     0x7aac90: add             x3, x3, HEAP, lsl #32
    // 0x7aac94: stp             x0, x3, [SP, #-0x10]!
    // 0x7aac98: r16 = ""
    //     0x7aac98: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x7aac9c: stp             x16, x2, [SP, #-0x10]!
    // 0x7aaca0: r0 = replaceRange()
    //     0x7aaca0: bl              #0x4d9f60  ; [dart:core] _StringBase::replaceRange
    // 0x7aaca4: add             SP, SP, #0x20
    // 0x7aaca8: ldur            x2, [fp, #-0x18]
    // 0x7aacac: StoreField: r2->field_f = r0
    //     0x7aacac: stur            w0, [x2, #0xf]
    //     0x7aacb0: ldurb           w16, [x2, #-1]
    //     0x7aacb4: ldurb           w17, [x0, #-1]
    //     0x7aacb8: and             x16, x17, x16, lsr #2
    //     0x7aacbc: tst             x16, HEAP, lsr #32
    //     0x7aacc0: b.eq            #0x7aacc8
    //     0x7aacc4: bl              #0xd6828c
    // 0x7aacc8: LoadField: r3 = r2->field_17
    //     0x7aacc8: ldur            w3, [x2, #0x17]
    // 0x7aaccc: DecompressPointer r3
    //     0x7aaccc: add             x3, x3, HEAP, lsl #32
    // 0x7aacd0: ldur            x4, [fp, #-0x10]
    // 0x7aacd4: ldur            x5, [fp, #-8]
    // 0x7aacd8: sub             x6, x5, x4
    // 0x7aacdc: cmp             w3, NULL
    // 0x7aace0: b.eq            #0x7aad54
    // 0x7aace4: r4 = LoadInt32Instr(r3)
    //     0x7aace4: sbfx            x4, x3, #1, #0x1f
    //     0x7aace8: tbz             w3, #0, #0x7aacf0
    //     0x7aacec: ldur            x4, [x3, #7]
    // 0x7aacf0: sub             x3, x4, x6
    // 0x7aacf4: r0 = BoxInt64Instr(r3)
    //     0x7aacf4: sbfiz           x0, x3, #1, #0x1f
    //     0x7aacf8: cmp             x3, x0, asr #1
    //     0x7aacfc: b.eq            #0x7aad08
    //     0x7aad00: bl              #0xd69bb8
    //     0x7aad04: stur            x3, [x0, #7]
    // 0x7aad08: StoreField: r2->field_17 = r0
    //     0x7aad08: stur            w0, [x2, #0x17]
    //     0x7aad0c: tbz             w0, #0, #0x7aad28
    //     0x7aad10: ldurb           w16, [x2, #-1]
    //     0x7aad14: ldurb           w17, [x0, #-1]
    //     0x7aad18: and             x16, x17, x16, lsr #2
    //     0x7aad1c: tst             x16, HEAP, lsr #32
    //     0x7aad20: b.eq            #0x7aad28
    //     0x7aad24: bl              #0xd6828c
    // 0x7aad28: r0 = false
    //     0x7aad28: add             x0, NULL, #0x30  ; false
    // 0x7aad2c: LeaveFrame
    //     0x7aad2c: mov             SP, fp
    //     0x7aad30: ldp             fp, lr, [SP], #0x10
    // 0x7aad34: ret
    //     0x7aad34: ret             
    // 0x7aad38: r0 = true
    //     0x7aad38: add             x0, NULL, #0x20  ; true
    // 0x7aad3c: LeaveFrame
    //     0x7aad3c: mov             SP, fp
    //     0x7aad40: ldp             fp, lr, [SP], #0x10
    // 0x7aad44: ret
    //     0x7aad44: ret             
    // 0x7aad48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aad48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aad4c: b               #0x7aac2c
    // 0x7aad50: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7aad50: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x7aad54: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7aad54: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ convertTextPainterPostionToTextInputPostion(/* No info */) {
    // ** addr: 0x7ab5a4, size: 0x228
    // 0x7ab5a4: EnterFrame
    //     0x7ab5a4: stp             fp, lr, [SP, #-0x10]!
    //     0x7ab5a8: mov             fp, SP
    // 0x7ab5ac: AllocStack(0x28)
    //     0x7ab5ac: sub             SP, SP, #0x28
    // 0x7ab5b0: SetupParameters(dynamic _ /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic end = Null /* r0, fp-0x8 */})
    //     0x7ab5b0: mov             x0, x4
    //     0x7ab5b4: ldur            w1, [x0, #0x13]
    //     0x7ab5b8: add             x1, x1, HEAP, lsl #32
    //     0x7ab5bc: sub             x2, x1, #4
    //     0x7ab5c0: add             x3, fp, w2, sxtw #2
    //     0x7ab5c4: ldr             x3, [x3, #0x18]
    //     0x7ab5c8: stur            x3, [fp, #-0x18]
    //     0x7ab5cc: add             x4, fp, w2, sxtw #2
    //     0x7ab5d0: ldr             x4, [x4, #0x10]
    //     0x7ab5d4: stur            x4, [fp, #-0x10]
    //     0x7ab5d8: ldur            w2, [x0, #0x1f]
    //     0x7ab5dc: add             x2, x2, HEAP, lsl #32
    //     0x7ab5e0: ldr             x16, [PP, #0x310]  ; [pp+0x310] "end"
    //     0x7ab5e4: cmp             w2, w16
    //     0x7ab5e8: b.ne            #0x7ab608
    //     0x7ab5ec: ldur            w2, [x0, #0x23]
    //     0x7ab5f0: add             x2, x2, HEAP, lsl #32
    //     0x7ab5f4: sub             w0, w1, w2
    //     0x7ab5f8: add             x1, fp, w0, sxtw #2
    //     0x7ab5fc: ldr             x1, [x1, #8]
    //     0x7ab600: mov             x0, x1
    //     0x7ab604: b               #0x7ab60c
    //     0x7ab608: mov             x0, NULL
    //     0x7ab60c: stur            x0, [fp, #-8]
    // 0x7ab610: CheckStackOverflow
    //     0x7ab610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ab614: cmp             SP, x16
    //     0x7ab618: b.ls            #0x7ab7c0
    // 0x7ab61c: r1 = 4
    //     0x7ab61c: mov             x1, #4
    // 0x7ab620: r0 = AllocateContext()
    //     0x7ab620: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ab624: mov             x3, x0
    // 0x7ab628: ldur            x2, [fp, #-0x10]
    // 0x7ab62c: stur            x3, [fp, #-0x20]
    // 0x7ab630: StoreField: r3->field_f = r2
    //     0x7ab630: stur            w2, [x3, #0xf]
    // 0x7ab634: ldur            x0, [fp, #-8]
    // 0x7ab638: StoreField: r3->field_13 = r0
    //     0x7ab638: stur            w0, [x3, #0x13]
    // 0x7ab63c: cmp             w2, NULL
    // 0x7ab640: b.eq            #0x7ab7b0
    // 0x7ab644: LoadField: r4 = r2->field_7
    //     0x7ab644: ldur            x4, [x2, #7]
    // 0x7ab648: r0 = BoxInt64Instr(r4)
    //     0x7ab648: sbfiz           x0, x4, #1, #0x1f
    //     0x7ab64c: cmp             x4, x0, asr #1
    //     0x7ab650: b.eq            #0x7ab65c
    //     0x7ab654: bl              #0xd69bb8
    //     0x7ab658: stur            x4, [x0, #7]
    // 0x7ab65c: StoreField: r3->field_17 = r0
    //     0x7ab65c: stur            w0, [x3, #0x17]
    // 0x7ab660: cmp             x4, #0
    // 0x7ab664: b.gt            #0x7ab678
    // 0x7ab668: mov             x0, x2
    // 0x7ab66c: LeaveFrame
    //     0x7ab66c: mov             SP, fp
    //     0x7ab670: ldp             fp, lr, [SP], #0x10
    // 0x7ab674: ret
    //     0x7ab674: ret             
    // 0x7ab678: ldur            x0, [fp, #-0x18]
    // 0x7ab67c: StoreField: r3->field_1b = rZR
    //     0x7ab67c: stur            wzr, [x3, #0x1b]
    // 0x7ab680: mov             x2, x3
    // 0x7ab684: r1 = Function '<anonymous closure>': static.
    //     0x7ab684: add             x1, PP, #0x37, lsl #12  ; [pp+0x37480] AnonymousClosure: static (0x7ab7cc), in [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion (0x7ab5a4)
    //     0x7ab688: ldr             x1, [x1, #0x480]
    // 0x7ab68c: r0 = AllocateClosure()
    //     0x7ab68c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ab690: mov             x1, x0
    // 0x7ab694: ldur            x0, [fp, #-0x18]
    // 0x7ab698: r2 = LoadClassIdInstr(r0)
    //     0x7ab698: ldur            x2, [x0, #-1]
    //     0x7ab69c: ubfx            x2, x2, #0xc, #0x14
    // 0x7ab6a0: lsl             x2, x2, #1
    // 0x7ab6a4: r17 = 6958
    //     0x7ab6a4: mov             x17, #0x1b2e
    // 0x7ab6a8: cmp             w2, w17
    // 0x7ab6ac: b.gt            #0x7ab6d8
    // 0x7ab6b0: r17 = 6954
    //     0x7ab6b0: mov             x17, #0x1b2a
    // 0x7ab6b4: cmp             w2, w17
    // 0x7ab6b8: b.lt            #0x7ab6d8
    // 0x7ab6bc: stp             x0, x1, [SP, #-0x10]!
    // 0x7ab6c0: mov             x0, x1
    // 0x7ab6c4: ClosureCall
    //     0x7ab6c4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x7ab6c8: ldur            x2, [x0, #0x1f]
    //     0x7ab6cc: blr             x2
    // 0x7ab6d0: add             SP, SP, #0x10
    // 0x7ab6d4: b               #0x7ab6f8
    // 0x7ab6d8: r2 = LoadClassIdInstr(r0)
    //     0x7ab6d8: ldur            x2, [x0, #-1]
    //     0x7ab6dc: ubfx            x2, x2, #0xc, #0x14
    // 0x7ab6e0: stp             x1, x0, [SP, #-0x10]!
    // 0x7ab6e4: mov             x0, x2
    // 0x7ab6e8: r0 = GDT[cid_x0 + -0x1000]()
    //     0x7ab6e8: sub             lr, x0, #1, lsl #12
    //     0x7ab6ec: ldr             lr, [x21, lr, lsl #3]
    //     0x7ab6f0: blr             lr
    // 0x7ab6f4: add             SP, SP, #0x10
    // 0x7ab6f8: ldur            x0, [fp, #-0x20]
    // 0x7ab6fc: LoadField: r2 = r0->field_17
    //     0x7ab6fc: ldur            w2, [x0, #0x17]
    // 0x7ab700: DecompressPointer r2
    //     0x7ab700: add             x2, x2, HEAP, lsl #32
    // 0x7ab704: LoadField: r3 = r0->field_f
    //     0x7ab704: ldur            w3, [x0, #0xf]
    // 0x7ab708: DecompressPointer r3
    //     0x7ab708: add             x3, x3, HEAP, lsl #32
    // 0x7ab70c: cmp             w3, NULL
    // 0x7ab710: b.eq            #0x7ab7c8
    // 0x7ab714: LoadField: r4 = r3->field_7
    //     0x7ab714: ldur            x4, [x3, #7]
    // 0x7ab718: r0 = BoxInt64Instr(r4)
    //     0x7ab718: sbfiz           x0, x4, #1, #0x1f
    //     0x7ab71c: cmp             x4, x0, asr #1
    //     0x7ab720: b.eq            #0x7ab72c
    //     0x7ab724: bl              #0xd69bb8
    //     0x7ab728: stur            x4, [x0, #7]
    // 0x7ab72c: cmp             w2, w0
    // 0x7ab730: b.eq            #0x7ab7a8
    // 0x7ab734: and             w16, w2, w0
    // 0x7ab738: branchIfSmi(r16, 0x7ab76c)
    //     0x7ab738: tbz             w16, #0, #0x7ab76c
    // 0x7ab73c: r16 = LoadClassIdInstr(r2)
    //     0x7ab73c: ldur            x16, [x2, #-1]
    //     0x7ab740: ubfx            x16, x16, #0xc, #0x14
    // 0x7ab744: cmp             x16, #0x3c
    // 0x7ab748: b.ne            #0x7ab76c
    // 0x7ab74c: r16 = LoadClassIdInstr(r0)
    //     0x7ab74c: ldur            x16, [x0, #-1]
    //     0x7ab750: ubfx            x16, x16, #0xc, #0x14
    // 0x7ab754: cmp             x16, #0x3c
    // 0x7ab758: b.ne            #0x7ab76c
    // 0x7ab75c: LoadField: r16 = r2->field_7
    //     0x7ab75c: ldur            x16, [x2, #7]
    // 0x7ab760: LoadField: r17 = r0->field_7
    //     0x7ab760: ldur            x17, [x0, #7]
    // 0x7ab764: cmp             x16, x17
    // 0x7ab768: b.eq            #0x7ab7a8
    // 0x7ab76c: LoadField: r0 = r3->field_f
    //     0x7ab76c: ldur            w0, [x3, #0xf]
    // 0x7ab770: DecompressPointer r0
    //     0x7ab770: add             x0, x0, HEAP, lsl #32
    // 0x7ab774: stur            x0, [fp, #-8]
    // 0x7ab778: r1 = LoadInt32Instr(r2)
    //     0x7ab778: sbfx            x1, x2, #1, #0x1f
    //     0x7ab77c: tbz             w2, #0, #0x7ab784
    //     0x7ab780: ldur            x1, [x2, #7]
    // 0x7ab784: stur            x1, [fp, #-0x28]
    // 0x7ab788: r0 = TextPosition()
    //     0x7ab788: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0x7ab78c: ldur            x1, [fp, #-0x28]
    // 0x7ab790: StoreField: r0->field_7 = r1
    //     0x7ab790: stur            x1, [x0, #7]
    // 0x7ab794: ldur            x1, [fp, #-8]
    // 0x7ab798: StoreField: r0->field_f = r1
    //     0x7ab798: stur            w1, [x0, #0xf]
    // 0x7ab79c: LeaveFrame
    //     0x7ab79c: mov             SP, fp
    //     0x7ab7a0: ldp             fp, lr, [SP], #0x10
    // 0x7ab7a4: ret
    //     0x7ab7a4: ret             
    // 0x7ab7a8: mov             x0, x3
    // 0x7ab7ac: b               #0x7ab7b4
    // 0x7ab7b0: mov             x0, x2
    // 0x7ab7b4: LeaveFrame
    //     0x7ab7b4: mov             SP, fp
    //     0x7ab7b8: ldp             fp, lr, [SP], #0x10
    // 0x7ab7bc: ret
    //     0x7ab7bc: ret             
    // 0x7ab7c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ab7c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ab7c4: b               #0x7ab61c
    // 0x7ab7c8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7ab7c8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] static bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x7ab7cc, size: 0x2cc
    // 0x7ab7cc: EnterFrame
    //     0x7ab7cc: stp             fp, lr, [SP, #-0x10]!
    //     0x7ab7d0: mov             fp, SP
    // 0x7ab7d4: ldr             x2, [fp, #0x18]
    // 0x7ab7d8: LoadField: r3 = r2->field_17
    //     0x7ab7d8: ldur            w3, [x2, #0x17]
    // 0x7ab7dc: DecompressPointer r3
    //     0x7ab7dc: add             x3, x3, HEAP, lsl #32
    // 0x7ab7e0: ldr             x2, [fp, #0x10]
    // 0x7ab7e4: r4 = LoadClassIdInstr(r2)
    //     0x7ab7e4: ldur            x4, [x2, #-1]
    //     0x7ab7e8: ubfx            x4, x4, #0xc, #0x14
    // 0x7ab7ec: lsl             x4, x4, #1
    // 0x7ab7f0: r17 = 6950
    //     0x7ab7f0: mov             x17, #0x1b26
    // 0x7ab7f4: cmp             w4, w17
    // 0x7ab7f8: b.ne            #0x7ab9a8
    // 0x7ab7fc: LoadField: r5 = r2->field_2f
    //     0x7ab7fc: ldur            w5, [x2, #0x2f]
    // 0x7ab800: DecompressPointer r5
    //     0x7ab800: add             x5, x5, HEAP, lsl #32
    // 0x7ab804: LoadField: r6 = r5->field_7
    //     0x7ab804: ldur            w6, [x5, #7]
    // 0x7ab808: DecompressPointer r6
    //     0x7ab808: add             x6, x6, HEAP, lsl #32
    // 0x7ab80c: LoadField: r5 = r3->field_17
    //     0x7ab80c: ldur            w5, [x3, #0x17]
    // 0x7ab810: DecompressPointer r5
    //     0x7ab810: add             x5, x5, HEAP, lsl #32
    // 0x7ab814: LoadField: r7 = r2->field_b
    //     0x7ab814: ldur            w7, [x2, #0xb]
    // 0x7ab818: DecompressPointer r7
    //     0x7ab818: add             x7, x7, HEAP, lsl #32
    // 0x7ab81c: cmp             w7, NULL
    // 0x7ab820: b.eq            #0x7ab834
    // 0x7ab824: LoadField: r8 = r7->field_7
    //     0x7ab824: ldur            w8, [x7, #7]
    // 0x7ab828: DecompressPointer r8
    //     0x7ab828: add             x8, x8, HEAP, lsl #32
    // 0x7ab82c: r7 = LoadInt32Instr(r8)
    //     0x7ab82c: sbfx            x7, x8, #1, #0x1f
    // 0x7ab830: b               #0x7ab838
    // 0x7ab834: r7 = 0
    //     0x7ab834: mov             x7, #0
    // 0x7ab838: r8 = LoadInt32Instr(r6)
    //     0x7ab838: sbfx            x8, x6, #1, #0x1f
    // 0x7ab83c: sub             x6, x8, x7
    // 0x7ab840: cmp             w5, NULL
    // 0x7ab844: b.eq            #0x7aba8c
    // 0x7ab848: r7 = LoadInt32Instr(r5)
    //     0x7ab848: sbfx            x7, x5, #1, #0x1f
    //     0x7ab84c: tbz             w5, #0, #0x7ab854
    //     0x7ab850: ldur            x7, [x5, #7]
    // 0x7ab854: add             x5, x7, x6
    // 0x7ab858: r0 = BoxInt64Instr(r5)
    //     0x7ab858: sbfiz           x0, x5, #1, #0x1f
    //     0x7ab85c: cmp             x5, x0, asr #1
    //     0x7ab860: b.eq            #0x7ab86c
    //     0x7ab864: bl              #0xd69bb8
    //     0x7ab868: stur            x5, [x0, #7]
    // 0x7ab86c: StoreField: r3->field_17 = r0
    //     0x7ab86c: stur            w0, [x3, #0x17]
    //     0x7ab870: tbz             w0, #0, #0x7ab88c
    //     0x7ab874: ldurb           w16, [x3, #-1]
    //     0x7ab878: ldurb           w17, [x0, #-1]
    //     0x7ab87c: and             x16, x17, x16, lsr #2
    //     0x7ab880: tst             x16, HEAP, lsr #32
    //     0x7ab884: b.eq            #0x7ab88c
    //     0x7ab888: bl              #0xd682ac
    // 0x7ab88c: LoadField: r6 = r2->field_37
    //     0x7ab88c: ldur            w6, [x2, #0x37]
    // 0x7ab890: DecompressPointer r6
    //     0x7ab890: add             x6, x6, HEAP, lsl #32
    // 0x7ab894: LoadField: r7 = r6->field_7
    //     0x7ab894: ldur            x7, [x6, #7]
    // 0x7ab898: cmp             x5, x7
    // 0x7ab89c: b.lt            #0x7ab9a8
    // 0x7ab8a0: LoadField: r8 = r6->field_f
    //     0x7ab8a0: ldur            x8, [x6, #0xf]
    // 0x7ab8a4: cmp             x5, x8
    // 0x7ab8a8: b.gt            #0x7ab9a8
    // 0x7ab8ac: LoadField: r6 = r3->field_13
    //     0x7ab8ac: ldur            w6, [x3, #0x13]
    // 0x7ab8b0: DecompressPointer r6
    //     0x7ab8b0: add             x6, x6, HEAP, lsl #32
    // 0x7ab8b4: cmp             w6, NULL
    // 0x7ab8b8: b.eq            #0x7ab904
    // 0x7ab8bc: tbnz            w6, #4, #0x7ab8c8
    // 0x7ab8c0: mov             x6, x8
    // 0x7ab8c4: b               #0x7ab8cc
    // 0x7ab8c8: mov             x6, x7
    // 0x7ab8cc: r0 = BoxInt64Instr(r6)
    //     0x7ab8cc: sbfiz           x0, x6, #1, #0x1f
    //     0x7ab8d0: cmp             x6, x0, asr #1
    //     0x7ab8d4: b.eq            #0x7ab8e0
    //     0x7ab8d8: bl              #0xd69bb8
    //     0x7ab8dc: stur            x6, [x0, #7]
    // 0x7ab8e0: StoreField: r3->field_17 = r0
    //     0x7ab8e0: stur            w0, [x3, #0x17]
    //     0x7ab8e4: tbz             w0, #0, #0x7ab900
    //     0x7ab8e8: ldurb           w16, [x3, #-1]
    //     0x7ab8ec: ldurb           w17, [x0, #-1]
    //     0x7ab8f0: and             x16, x17, x16, lsr #2
    //     0x7ab8f4: tst             x16, HEAP, lsr #32
    //     0x7ab8f8: b.eq            #0x7ab900
    //     0x7ab8fc: bl              #0xd682ac
    // 0x7ab900: b               #0x7ab998
    // 0x7ab904: d0 = 2.000000
    //     0x7ab904: fmov            d0, #2.00000000
    // 0x7ab908: sub             x6, x8, x7
    // 0x7ab90c: scvtf           d1, x6
    // 0x7ab910: fdiv            d2, d1, d0
    // 0x7ab914: scvtf           d0, x7
    // 0x7ab918: fadd            d1, d2, d0
    // 0x7ab91c: scvtf           d0, x5
    // 0x7ab920: fcmp            d0, d1
    // 0x7ab924: b.vs            #0x7ab964
    // 0x7ab928: b.le            #0x7ab964
    // 0x7ab92c: r0 = BoxInt64Instr(r8)
    //     0x7ab92c: sbfiz           x0, x8, #1, #0x1f
    //     0x7ab930: cmp             x8, x0, asr #1
    //     0x7ab934: b.eq            #0x7ab940
    //     0x7ab938: bl              #0xd69bb8
    //     0x7ab93c: stur            x8, [x0, #7]
    // 0x7ab940: StoreField: r3->field_17 = r0
    //     0x7ab940: stur            w0, [x3, #0x17]
    //     0x7ab944: tbz             w0, #0, #0x7ab960
    //     0x7ab948: ldurb           w16, [x3, #-1]
    //     0x7ab94c: ldurb           w17, [x0, #-1]
    //     0x7ab950: and             x16, x17, x16, lsr #2
    //     0x7ab954: tst             x16, HEAP, lsr #32
    //     0x7ab958: b.eq            #0x7ab960
    //     0x7ab95c: bl              #0xd682ac
    // 0x7ab960: b               #0x7ab998
    // 0x7ab964: r0 = BoxInt64Instr(r7)
    //     0x7ab964: sbfiz           x0, x7, #1, #0x1f
    //     0x7ab968: cmp             x7, x0, asr #1
    //     0x7ab96c: b.eq            #0x7ab978
    //     0x7ab970: bl              #0xd69bb8
    //     0x7ab974: stur            x7, [x0, #7]
    // 0x7ab978: StoreField: r3->field_17 = r0
    //     0x7ab978: stur            w0, [x3, #0x17]
    //     0x7ab97c: tbz             w0, #0, #0x7ab998
    //     0x7ab980: ldurb           w16, [x3, #-1]
    //     0x7ab984: ldurb           w17, [x0, #-1]
    //     0x7ab988: and             x16, x17, x16, lsr #2
    //     0x7ab98c: tst             x16, HEAP, lsr #32
    //     0x7ab990: b.eq            #0x7ab998
    //     0x7ab994: bl              #0xd682ac
    // 0x7ab998: r0 = false
    //     0x7ab998: add             x0, NULL, #0x30  ; false
    // 0x7ab99c: LeaveFrame
    //     0x7ab99c: mov             SP, fp
    //     0x7ab9a0: ldp             fp, lr, [SP], #0x10
    // 0x7ab9a4: ret
    //     0x7ab9a4: ret             
    // 0x7ab9a8: LoadField: r5 = r3->field_1b
    //     0x7ab9a8: ldur            w5, [x3, #0x1b]
    // 0x7ab9ac: DecompressPointer r5
    //     0x7ab9ac: add             x5, x5, HEAP, lsl #32
    // 0x7ab9b0: r6 = LoadInt32Instr(r4)
    //     0x7ab9b0: sbfx            x6, x4, #1, #0x1f
    // 0x7ab9b4: cmp             x6, #0xd91
    // 0x7ab9b8: b.lt            #0x7ab9e8
    // 0x7ab9bc: cmp             x6, #0xd93
    // 0x7ab9c0: b.gt            #0x7ab9e8
    // 0x7ab9c4: LoadField: r4 = r2->field_b
    //     0x7ab9c4: ldur            w4, [x2, #0xb]
    // 0x7ab9c8: DecompressPointer r4
    //     0x7ab9c8: add             x4, x4, HEAP, lsl #32
    // 0x7ab9cc: cmp             w4, NULL
    // 0x7ab9d0: b.eq            #0x7ab9e8
    // 0x7ab9d4: LoadField: r2 = r4->field_7
    //     0x7ab9d4: ldur            w2, [x4, #7]
    // 0x7ab9d8: DecompressPointer r2
    //     0x7ab9d8: add             x2, x2, HEAP, lsl #32
    // 0x7ab9dc: r4 = LoadInt32Instr(r2)
    //     0x7ab9dc: sbfx            x4, x2, #1, #0x1f
    // 0x7ab9e0: mov             x2, x4
    // 0x7ab9e4: b               #0x7aba04
    // 0x7ab9e8: cmp             x6, #0xd95
    // 0x7ab9ec: b.lt            #0x7aba00
    // 0x7ab9f0: cmp             x6, #0xd97
    // 0x7ab9f4: b.gt            #0x7aba00
    // 0x7ab9f8: r2 = 1
    //     0x7ab9f8: mov             x2, #1
    // 0x7ab9fc: b               #0x7aba04
    // 0x7aba00: r2 = 0
    //     0x7aba00: mov             x2, #0
    // 0x7aba04: cmp             w5, NULL
    // 0x7aba08: b.eq            #0x7aba90
    // 0x7aba0c: r4 = LoadInt32Instr(r5)
    //     0x7aba0c: sbfx            x4, x5, #1, #0x1f
    //     0x7aba10: tbz             w5, #0, #0x7aba18
    //     0x7aba14: ldur            x4, [x5, #7]
    // 0x7aba18: add             x5, x4, x2
    // 0x7aba1c: r0 = BoxInt64Instr(r5)
    //     0x7aba1c: sbfiz           x0, x5, #1, #0x1f
    //     0x7aba20: cmp             x5, x0, asr #1
    //     0x7aba24: b.eq            #0x7aba30
    //     0x7aba28: bl              #0xd69bb8
    //     0x7aba2c: stur            x5, [x0, #7]
    // 0x7aba30: StoreField: r3->field_1b = r0
    //     0x7aba30: stur            w0, [x3, #0x1b]
    //     0x7aba34: tbz             w0, #0, #0x7aba50
    //     0x7aba38: ldurb           w16, [x3, #-1]
    //     0x7aba3c: ldurb           w17, [x0, #-1]
    //     0x7aba40: and             x16, x17, x16, lsr #2
    //     0x7aba44: tst             x16, HEAP, lsr #32
    //     0x7aba48: b.eq            #0x7aba50
    //     0x7aba4c: bl              #0xd682ac
    // 0x7aba50: LoadField: r1 = r3->field_f
    //     0x7aba50: ldur            w1, [x3, #0xf]
    // 0x7aba54: DecompressPointer r1
    //     0x7aba54: add             x1, x1, HEAP, lsl #32
    // 0x7aba58: cmp             w1, NULL
    // 0x7aba5c: b.eq            #0x7aba94
    // 0x7aba60: LoadField: r2 = r1->field_7
    //     0x7aba60: ldur            x2, [x1, #7]
    // 0x7aba64: cmp             x5, x2
    // 0x7aba68: b.lt            #0x7aba7c
    // 0x7aba6c: r0 = false
    //     0x7aba6c: add             x0, NULL, #0x30  ; false
    // 0x7aba70: LeaveFrame
    //     0x7aba70: mov             SP, fp
    //     0x7aba74: ldp             fp, lr, [SP], #0x10
    // 0x7aba78: ret
    //     0x7aba78: ret             
    // 0x7aba7c: r0 = true
    //     0x7aba7c: add             x0, NULL, #0x20  ; true
    // 0x7aba80: LeaveFrame
    //     0x7aba80: mov             SP, fp
    //     0x7aba84: ldp             fp, lr, [SP], #0x10
    // 0x7aba88: ret
    //     0x7aba88: ret             
    // 0x7aba8c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7aba8c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x7aba90: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7aba90: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x7aba94: r0 = NullErrorSharedWithoutFPURegs()
    //     0x7aba94: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  static _ convertTextPainterSelectionToTextInputSelection(/* No info */) {
    // ** addr: 0x83a654, size: 0x38c
    // 0x83a654: EnterFrame
    //     0x83a654: stp             fp, lr, [SP, #-0x10]!
    //     0x83a658: mov             fp, SP
    // 0x83a65c: AllocStack(0x28)
    //     0x83a65c: sub             SP, SP, #0x28
    // 0x83a660: SetupParameters(dynamic _ /* r3, fp-0x10 */, dynamic _ /* r4, fp-0x8 */, {dynamic selectWord = false /* r0, fp-0x28 */})
    //     0x83a660: mov             x0, x4
    //     0x83a664: ldur            w1, [x0, #0x13]
    //     0x83a668: add             x1, x1, HEAP, lsl #32
    //     0x83a66c: sub             x2, x1, #4
    //     0x83a670: add             x3, fp, w2, sxtw #2
    //     0x83a674: ldr             x3, [x3, #0x18]
    //     0x83a678: stur            x3, [fp, #-0x10]
    //     0x83a67c: add             x4, fp, w2, sxtw #2
    //     0x83a680: ldr             x4, [x4, #0x10]
    //     0x83a684: stur            x4, [fp, #-8]
    //     0x83a688: ldur            w2, [x0, #0x1f]
    //     0x83a68c: add             x2, x2, HEAP, lsl #32
    //     0x83a690: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be00] "selectWord"
    //     0x83a694: ldr             x16, [x16, #0xe00]
    //     0x83a698: cmp             w2, w16
    //     0x83a69c: b.ne            #0x83a6bc
    //     0x83a6a0: ldur            w2, [x0, #0x23]
    //     0x83a6a4: add             x2, x2, HEAP, lsl #32
    //     0x83a6a8: sub             w0, w1, w2
    //     0x83a6ac: add             x1, fp, w0, sxtw #2
    //     0x83a6b0: ldr             x1, [x1, #8]
    //     0x83a6b4: mov             x0, x1
    //     0x83a6b8: b               #0x83a6c0
    //     0x83a6bc: add             x0, NULL, #0x30  ; false
    //     0x83a6c0: stur            x0, [fp, #-0x28]
    // 0x83a6c4: CheckStackOverflow
    //     0x83a6c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a6c8: cmp             SP, x16
    //     0x83a6cc: b.ls            #0x83a9d8
    // 0x83a6d0: LoadField: r1 = r4->field_7
    //     0x83a6d0: ldur            x1, [x4, #7]
    // 0x83a6d4: tbnz            x1, #0x3f, #0x83a9c4
    // 0x83a6d8: LoadField: r2 = r4->field_f
    //     0x83a6d8: ldur            x2, [x4, #0xf]
    // 0x83a6dc: tbnz            x2, #0x3f, #0x83a9bc
    // 0x83a6e0: cmp             x1, x2
    // 0x83a6e4: b.ne            #0x83a7cc
    // 0x83a6e8: SaveReg r4
    //     0x83a6e8: str             x4, [SP, #-8]!
    // 0x83a6ec: r0 = extent()
    //     0x83a6ec: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83a6f0: add             SP, SP, #8
    // 0x83a6f4: ldur            x16, [fp, #-0x10]
    // 0x83a6f8: stp             x0, x16, [SP, #-0x10]!
    // 0x83a6fc: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x83a6fc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x83a700: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x83a700: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x83a704: add             SP, SP, #0x10
    // 0x83a708: stur            x0, [fp, #-0x18]
    // 0x83a70c: ldur            x16, [fp, #-8]
    // 0x83a710: SaveReg r16
    //     0x83a710: str             x16, [SP, #-8]!
    // 0x83a714: r0 = extent()
    //     0x83a714: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83a718: add             SP, SP, #8
    // 0x83a71c: stur            x0, [fp, #-0x20]
    // 0x83a720: r16 = TextPosition
    //     0x83a720: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x83a724: ldr             x16, [x16, #0x540]
    // 0x83a728: r30 = TextPosition
    //     0x83a728: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x83a72c: ldr             lr, [lr, #0x540]
    // 0x83a730: stp             lr, x16, [SP, #-0x10]!
    // 0x83a734: r0 = ==()
    //     0x83a734: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x83a738: add             SP, SP, #0x10
    // 0x83a73c: tbz             w0, #4, #0x83a748
    // 0x83a740: ldur            x1, [fp, #-0x18]
    // 0x83a744: b               #0x83a778
    // 0x83a748: ldur            x1, [fp, #-0x18]
    // 0x83a74c: ldur            x0, [fp, #-0x20]
    // 0x83a750: LoadField: r2 = r1->field_7
    //     0x83a750: ldur            x2, [x1, #7]
    // 0x83a754: LoadField: r3 = r0->field_7
    //     0x83a754: ldur            x3, [x0, #7]
    // 0x83a758: cmp             x2, x3
    // 0x83a75c: b.ne            #0x83a778
    // 0x83a760: LoadField: r2 = r1->field_f
    //     0x83a760: ldur            w2, [x1, #0xf]
    // 0x83a764: DecompressPointer r2
    //     0x83a764: add             x2, x2, HEAP, lsl #32
    // 0x83a768: LoadField: r3 = r0->field_f
    //     0x83a768: ldur            w3, [x0, #0xf]
    // 0x83a76c: DecompressPointer r3
    //     0x83a76c: add             x3, x3, HEAP, lsl #32
    // 0x83a770: cmp             w2, w3
    // 0x83a774: b.eq            #0x83a93c
    // 0x83a778: ldur            x2, [fp, #-8]
    // 0x83a77c: LoadField: r3 = r1->field_7
    //     0x83a77c: ldur            x3, [x1, #7]
    // 0x83a780: LoadField: r4 = r2->field_27
    //     0x83a780: ldur            w4, [x2, #0x27]
    // 0x83a784: DecompressPointer r4
    //     0x83a784: add             x4, x4, HEAP, lsl #32
    // 0x83a788: LoadField: r5 = r2->field_2b
    //     0x83a788: ldur            w5, [x2, #0x2b]
    // 0x83a78c: DecompressPointer r5
    //     0x83a78c: add             x5, x5, HEAP, lsl #32
    // 0x83a790: r0 = BoxInt64Instr(r3)
    //     0x83a790: sbfiz           x0, x3, #1, #0x1f
    //     0x83a794: cmp             x3, x0, asr #1
    //     0x83a798: b.eq            #0x83a7a4
    //     0x83a79c: bl              #0xd69bb8
    //     0x83a7a0: stur            x3, [x0, #7]
    // 0x83a7a4: stp             x0, x2, [SP, #-0x10]!
    // 0x83a7a8: stp             x4, x0, [SP, #-0x10]!
    // 0x83a7ac: SaveReg r5
    //     0x83a7ac: str             x5, [SP, #-8]!
    // 0x83a7b0: r4 = const [0, 0x5, 0x5, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, isDirectional, 0x4, null]
    //     0x83a7b0: add             x4, PP, #0x37, lsl #12  ; [pp+0x37428] List(13) [0, 0x5, 0x5, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, "isDirectional", 0x4, Null]
    //     0x83a7b4: ldr             x4, [x4, #0x428]
    // 0x83a7b8: r0 = copyWith()
    //     0x83a7b8: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x83a7bc: add             SP, SP, #0x28
    // 0x83a7c0: LeaveFrame
    //     0x83a7c0: mov             SP, fp
    //     0x83a7c4: ldp             fp, lr, [SP], #0x10
    // 0x83a7c8: ret
    //     0x83a7c8: ret             
    // 0x83a7cc: mov             x2, x4
    // 0x83a7d0: SaveReg r2
    //     0x83a7d0: str             x2, [SP, #-8]!
    // 0x83a7d4: r0 = extent()
    //     0x83a7d4: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83a7d8: add             SP, SP, #8
    // 0x83a7dc: mov             x1, x0
    // 0x83a7e0: ldur            x0, [fp, #-0x28]
    // 0x83a7e4: tbnz            w0, #4, #0x83a7f0
    // 0x83a7e8: r2 = true
    //     0x83a7e8: add             x2, NULL, #0x20  ; true
    // 0x83a7ec: b               #0x83a7f4
    // 0x83a7f0: r2 = Null
    //     0x83a7f0: mov             x2, NULL
    // 0x83a7f4: ldur            x16, [fp, #-0x10]
    // 0x83a7f8: stp             x1, x16, [SP, #-0x10]!
    // 0x83a7fc: SaveReg r2
    //     0x83a7fc: str             x2, [SP, #-8]!
    // 0x83a800: r4 = const [0, 0x3, 0x3, 0x2, end, 0x2, null]
    //     0x83a800: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4be08] List(7) [0, 0x3, 0x3, 0x2, "end", 0x2, Null]
    //     0x83a804: ldr             x4, [x4, #0xe08]
    // 0x83a808: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x83a808: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x83a80c: add             SP, SP, #0x18
    // 0x83a810: stur            x0, [fp, #-0x18]
    // 0x83a814: ldur            x16, [fp, #-8]
    // 0x83a818: SaveReg r16
    //     0x83a818: str             x16, [SP, #-8]!
    // 0x83a81c: r0 = base()
    //     0x83a81c: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x83a820: add             SP, SP, #8
    // 0x83a824: mov             x1, x0
    // 0x83a828: ldur            x0, [fp, #-0x28]
    // 0x83a82c: tbnz            w0, #4, #0x83a838
    // 0x83a830: r0 = false
    //     0x83a830: add             x0, NULL, #0x30  ; false
    // 0x83a834: b               #0x83a83c
    // 0x83a838: r0 = Null
    //     0x83a838: mov             x0, NULL
    // 0x83a83c: ldur            x16, [fp, #-0x10]
    // 0x83a840: stp             x1, x16, [SP, #-0x10]!
    // 0x83a844: SaveReg r0
    //     0x83a844: str             x0, [SP, #-8]!
    // 0x83a848: r4 = const [0, 0x3, 0x3, 0x2, end, 0x2, null]
    //     0x83a848: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4be08] List(7) [0, 0x3, 0x3, 0x2, "end", 0x2, Null]
    //     0x83a84c: ldr             x4, [x4, #0xe08]
    // 0x83a850: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x83a850: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x83a854: add             SP, SP, #0x18
    // 0x83a858: stur            x0, [fp, #-0x10]
    // 0x83a85c: ldur            x16, [fp, #-8]
    // 0x83a860: SaveReg r16
    //     0x83a860: str             x16, [SP, #-8]!
    // 0x83a864: r0 = extent()
    //     0x83a864: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83a868: add             SP, SP, #8
    // 0x83a86c: stur            x0, [fp, #-0x20]
    // 0x83a870: r16 = TextPosition
    //     0x83a870: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x83a874: ldr             x16, [x16, #0x540]
    // 0x83a878: r30 = TextPosition
    //     0x83a878: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x83a87c: ldr             lr, [lr, #0x540]
    // 0x83a880: stp             lr, x16, [SP, #-0x10]!
    // 0x83a884: r0 = ==()
    //     0x83a884: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x83a888: add             SP, SP, #0x10
    // 0x83a88c: tbz             w0, #4, #0x83a898
    // 0x83a890: ldur            x1, [fp, #-0x10]
    // 0x83a894: b               #0x83a948
    // 0x83a898: ldur            x1, [fp, #-0x18]
    // 0x83a89c: ldur            x0, [fp, #-0x20]
    // 0x83a8a0: LoadField: r2 = r1->field_7
    //     0x83a8a0: ldur            x2, [x1, #7]
    // 0x83a8a4: LoadField: r3 = r0->field_7
    //     0x83a8a4: ldur            x3, [x0, #7]
    // 0x83a8a8: cmp             x2, x3
    // 0x83a8ac: b.ne            #0x83a944
    // 0x83a8b0: LoadField: r2 = r1->field_f
    //     0x83a8b0: ldur            w2, [x1, #0xf]
    // 0x83a8b4: DecompressPointer r2
    //     0x83a8b4: add             x2, x2, HEAP, lsl #32
    // 0x83a8b8: LoadField: r3 = r0->field_f
    //     0x83a8b8: ldur            w3, [x0, #0xf]
    // 0x83a8bc: DecompressPointer r3
    //     0x83a8bc: add             x3, x3, HEAP, lsl #32
    // 0x83a8c0: cmp             w2, w3
    // 0x83a8c4: b.eq            #0x83a8d0
    // 0x83a8c8: ldur            x1, [fp, #-0x10]
    // 0x83a8cc: b               #0x83a948
    // 0x83a8d0: ldur            x16, [fp, #-8]
    // 0x83a8d4: SaveReg r16
    //     0x83a8d4: str             x16, [SP, #-8]!
    // 0x83a8d8: r0 = base()
    //     0x83a8d8: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x83a8dc: add             SP, SP, #8
    // 0x83a8e0: stur            x0, [fp, #-0x20]
    // 0x83a8e4: r16 = TextPosition
    //     0x83a8e4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x83a8e8: ldr             x16, [x16, #0x540]
    // 0x83a8ec: r30 = TextPosition
    //     0x83a8ec: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f540] Type: TextPosition
    //     0x83a8f0: ldr             lr, [lr, #0x540]
    // 0x83a8f4: stp             lr, x16, [SP, #-0x10]!
    // 0x83a8f8: r0 = ==()
    //     0x83a8f8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0x83a8fc: add             SP, SP, #0x10
    // 0x83a900: tbz             w0, #4, #0x83a90c
    // 0x83a904: ldur            x1, [fp, #-0x10]
    // 0x83a908: b               #0x83a948
    // 0x83a90c: ldur            x1, [fp, #-0x10]
    // 0x83a910: ldur            x0, [fp, #-0x20]
    // 0x83a914: LoadField: r2 = r1->field_7
    //     0x83a914: ldur            x2, [x1, #7]
    // 0x83a918: LoadField: r3 = r0->field_7
    //     0x83a918: ldur            x3, [x0, #7]
    // 0x83a91c: cmp             x2, x3
    // 0x83a920: b.ne            #0x83a948
    // 0x83a924: LoadField: r2 = r1->field_f
    //     0x83a924: ldur            w2, [x1, #0xf]
    // 0x83a928: DecompressPointer r2
    //     0x83a928: add             x2, x2, HEAP, lsl #32
    // 0x83a92c: LoadField: r3 = r0->field_f
    //     0x83a92c: ldur            w3, [x0, #0xf]
    // 0x83a930: DecompressPointer r3
    //     0x83a930: add             x3, x3, HEAP, lsl #32
    // 0x83a934: cmp             w2, w3
    // 0x83a938: b.ne            #0x83a948
    // 0x83a93c: ldur            x2, [fp, #-8]
    // 0x83a940: b               #0x83a9c8
    // 0x83a944: ldur            x1, [fp, #-0x10]
    // 0x83a948: ldur            x2, [fp, #-8]
    // 0x83a94c: ldur            x0, [fp, #-0x18]
    // 0x83a950: LoadField: r3 = r1->field_7
    //     0x83a950: ldur            x3, [x1, #7]
    // 0x83a954: LoadField: r4 = r0->field_7
    //     0x83a954: ldur            x4, [x0, #7]
    // 0x83a958: LoadField: r5 = r2->field_27
    //     0x83a958: ldur            w5, [x2, #0x27]
    // 0x83a95c: DecompressPointer r5
    //     0x83a95c: add             x5, x5, HEAP, lsl #32
    // 0x83a960: LoadField: r6 = r2->field_2b
    //     0x83a960: ldur            w6, [x2, #0x2b]
    // 0x83a964: DecompressPointer r6
    //     0x83a964: add             x6, x6, HEAP, lsl #32
    // 0x83a968: r0 = BoxInt64Instr(r3)
    //     0x83a968: sbfiz           x0, x3, #1, #0x1f
    //     0x83a96c: cmp             x3, x0, asr #1
    //     0x83a970: b.eq            #0x83a97c
    //     0x83a974: bl              #0xd69bb8
    //     0x83a978: stur            x3, [x0, #7]
    // 0x83a97c: mov             x3, x0
    // 0x83a980: r0 = BoxInt64Instr(r4)
    //     0x83a980: sbfiz           x0, x4, #1, #0x1f
    //     0x83a984: cmp             x4, x0, asr #1
    //     0x83a988: b.eq            #0x83a994
    //     0x83a98c: bl              #0xd69bb8
    //     0x83a990: stur            x4, [x0, #7]
    // 0x83a994: stp             x3, x2, [SP, #-0x10]!
    // 0x83a998: stp             x5, x0, [SP, #-0x10]!
    // 0x83a99c: SaveReg r6
    //     0x83a99c: str             x6, [SP, #-8]!
    // 0x83a9a0: r4 = const [0, 0x5, 0x5, 0x1, affinity, 0x3, baseOffset, 0x1, extentOffset, 0x2, isDirectional, 0x4, null]
    //     0x83a9a0: add             x4, PP, #0x37, lsl #12  ; [pp+0x37428] List(13) [0, 0x5, 0x5, 0x1, "affinity", 0x3, "baseOffset", 0x1, "extentOffset", 0x2, "isDirectional", 0x4, Null]
    //     0x83a9a4: ldr             x4, [x4, #0x428]
    // 0x83a9a8: r0 = copyWith()
    //     0x83a9a8: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x83a9ac: add             SP, SP, #0x28
    // 0x83a9b0: LeaveFrame
    //     0x83a9b0: mov             SP, fp
    //     0x83a9b4: ldp             fp, lr, [SP], #0x10
    // 0x83a9b8: ret
    //     0x83a9b8: ret             
    // 0x83a9bc: mov             x2, x4
    // 0x83a9c0: b               #0x83a9c8
    // 0x83a9c4: mov             x2, x4
    // 0x83a9c8: mov             x0, x2
    // 0x83a9cc: LeaveFrame
    //     0x83a9cc: mov             SP, fp
    //     0x83a9d0: ldp             fp, lr, [SP], #0x10
    // 0x83a9d4: ret
    //     0x83a9d4: ret             
    // 0x83a9d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a9d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a9dc: b               #0x83a6d0
  }
  static _ makeSureCaretNotInSpecialText(/* No info */) {
    // ** addr: 0xcd0e2c, size: 0x1a4
    // 0xcd0e2c: EnterFrame
    //     0xcd0e2c: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0e30: mov             fp, SP
    // 0xcd0e34: AllocStack(0x10)
    //     0xcd0e34: sub             SP, SP, #0x10
    // 0xcd0e38: CheckStackOverflow
    //     0xcd0e38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcd0e3c: cmp             SP, x16
    //     0xcd0e40: b.ls            #0xcd0fc8
    // 0xcd0e44: r1 = 3
    //     0xcd0e44: mov             x1, #3
    // 0xcd0e48: r0 = AllocateContext()
    //     0xcd0e48: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcd0e4c: mov             x3, x0
    // 0xcd0e50: ldr             x2, [fp, #0x10]
    // 0xcd0e54: stur            x3, [fp, #-8]
    // 0xcd0e58: StoreField: r3->field_f = r2
    //     0xcd0e58: stur            w2, [x3, #0xf]
    // 0xcd0e5c: LoadField: r4 = r2->field_7
    //     0xcd0e5c: ldur            x4, [x2, #7]
    // 0xcd0e60: r0 = BoxInt64Instr(r4)
    //     0xcd0e60: sbfiz           x0, x4, #1, #0x1f
    //     0xcd0e64: cmp             x4, x0, asr #1
    //     0xcd0e68: b.eq            #0xcd0e74
    //     0xcd0e6c: bl              #0xd69bb8
    //     0xcd0e70: stur            x4, [x0, #7]
    // 0xcd0e74: StoreField: r3->field_13 = r0
    //     0xcd0e74: stur            w0, [x3, #0x13]
    // 0xcd0e78: cmp             x4, #0
    // 0xcd0e7c: b.gt            #0xcd0e90
    // 0xcd0e80: mov             x0, x2
    // 0xcd0e84: LeaveFrame
    //     0xcd0e84: mov             SP, fp
    //     0xcd0e88: ldp             fp, lr, [SP], #0x10
    // 0xcd0e8c: ret
    //     0xcd0e8c: ret             
    // 0xcd0e90: ldr             x0, [fp, #0x18]
    // 0xcd0e94: StoreField: r3->field_17 = rZR
    //     0xcd0e94: stur            wzr, [x3, #0x17]
    // 0xcd0e98: mov             x2, x3
    // 0xcd0e9c: r1 = Function '<anonymous closure>': static.
    //     0xcd0e9c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53550] AnonymousClosure: static (0xcd0fd0), in [package:extended_text_library/src/extended_text_utils.dart] ::makeSureCaretNotInSpecialText (0xcd0e2c)
    //     0xcd0ea0: ldr             x1, [x1, #0x550]
    // 0xcd0ea4: r0 = AllocateClosure()
    //     0xcd0ea4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcd0ea8: mov             x1, x0
    // 0xcd0eac: ldr             x0, [fp, #0x18]
    // 0xcd0eb0: r2 = LoadClassIdInstr(r0)
    //     0xcd0eb0: ldur            x2, [x0, #-1]
    //     0xcd0eb4: ubfx            x2, x2, #0xc, #0x14
    // 0xcd0eb8: lsl             x2, x2, #1
    // 0xcd0ebc: r17 = 6958
    //     0xcd0ebc: mov             x17, #0x1b2e
    // 0xcd0ec0: cmp             w2, w17
    // 0xcd0ec4: b.gt            #0xcd0ef0
    // 0xcd0ec8: r17 = 6954
    //     0xcd0ec8: mov             x17, #0x1b2a
    // 0xcd0ecc: cmp             w2, w17
    // 0xcd0ed0: b.lt            #0xcd0ef0
    // 0xcd0ed4: stp             x0, x1, [SP, #-0x10]!
    // 0xcd0ed8: mov             x0, x1
    // 0xcd0edc: ClosureCall
    //     0xcd0edc: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0xcd0ee0: ldur            x2, [x0, #0x1f]
    //     0xcd0ee4: blr             x2
    // 0xcd0ee8: add             SP, SP, #0x10
    // 0xcd0eec: b               #0xcd0f10
    // 0xcd0ef0: r2 = LoadClassIdInstr(r0)
    //     0xcd0ef0: ldur            x2, [x0, #-1]
    //     0xcd0ef4: ubfx            x2, x2, #0xc, #0x14
    // 0xcd0ef8: stp             x1, x0, [SP, #-0x10]!
    // 0xcd0efc: mov             x0, x2
    // 0xcd0f00: r0 = GDT[cid_x0 + -0x1000]()
    //     0xcd0f00: sub             lr, x0, #1, lsl #12
    //     0xcd0f04: ldr             lr, [x21, lr, lsl #3]
    //     0xcd0f08: blr             lr
    // 0xcd0f0c: add             SP, SP, #0x10
    // 0xcd0f10: ldur            x0, [fp, #-8]
    // 0xcd0f14: LoadField: r2 = r0->field_13
    //     0xcd0f14: ldur            w2, [x0, #0x13]
    // 0xcd0f18: DecompressPointer r2
    //     0xcd0f18: add             x2, x2, HEAP, lsl #32
    // 0xcd0f1c: LoadField: r3 = r0->field_f
    //     0xcd0f1c: ldur            w3, [x0, #0xf]
    // 0xcd0f20: DecompressPointer r3
    //     0xcd0f20: add             x3, x3, HEAP, lsl #32
    // 0xcd0f24: LoadField: r4 = r3->field_7
    //     0xcd0f24: ldur            x4, [x3, #7]
    // 0xcd0f28: r0 = BoxInt64Instr(r4)
    //     0xcd0f28: sbfiz           x0, x4, #1, #0x1f
    //     0xcd0f2c: cmp             x4, x0, asr #1
    //     0xcd0f30: b.eq            #0xcd0f3c
    //     0xcd0f34: bl              #0xd69bb8
    //     0xcd0f38: stur            x4, [x0, #7]
    // 0xcd0f3c: cmp             w2, w0
    // 0xcd0f40: b.eq            #0xcd0fb8
    // 0xcd0f44: and             w16, w2, w0
    // 0xcd0f48: branchIfSmi(r16, 0xcd0f7c)
    //     0xcd0f48: tbz             w16, #0, #0xcd0f7c
    // 0xcd0f4c: r16 = LoadClassIdInstr(r2)
    //     0xcd0f4c: ldur            x16, [x2, #-1]
    //     0xcd0f50: ubfx            x16, x16, #0xc, #0x14
    // 0xcd0f54: cmp             x16, #0x3c
    // 0xcd0f58: b.ne            #0xcd0f7c
    // 0xcd0f5c: r16 = LoadClassIdInstr(r0)
    //     0xcd0f5c: ldur            x16, [x0, #-1]
    //     0xcd0f60: ubfx            x16, x16, #0xc, #0x14
    // 0xcd0f64: cmp             x16, #0x3c
    // 0xcd0f68: b.ne            #0xcd0f7c
    // 0xcd0f6c: LoadField: r16 = r2->field_7
    //     0xcd0f6c: ldur            x16, [x2, #7]
    // 0xcd0f70: LoadField: r17 = r0->field_7
    //     0xcd0f70: ldur            x17, [x0, #7]
    // 0xcd0f74: cmp             x16, x17
    // 0xcd0f78: b.eq            #0xcd0fb8
    // 0xcd0f7c: LoadField: r0 = r3->field_f
    //     0xcd0f7c: ldur            w0, [x3, #0xf]
    // 0xcd0f80: DecompressPointer r0
    //     0xcd0f80: add             x0, x0, HEAP, lsl #32
    // 0xcd0f84: stur            x0, [fp, #-8]
    // 0xcd0f88: r1 = LoadInt32Instr(r2)
    //     0xcd0f88: sbfx            x1, x2, #1, #0x1f
    //     0xcd0f8c: tbz             w2, #0, #0xcd0f94
    //     0xcd0f90: ldur            x1, [x2, #7]
    // 0xcd0f94: stur            x1, [fp, #-0x10]
    // 0xcd0f98: r0 = TextPosition()
    //     0xcd0f98: bl              #0x5223f0  ; AllocateTextPositionStub -> TextPosition (size=0x14)
    // 0xcd0f9c: ldur            x1, [fp, #-0x10]
    // 0xcd0fa0: StoreField: r0->field_7 = r1
    //     0xcd0fa0: stur            x1, [x0, #7]
    // 0xcd0fa4: ldur            x1, [fp, #-8]
    // 0xcd0fa8: StoreField: r0->field_f = r1
    //     0xcd0fa8: stur            w1, [x0, #0xf]
    // 0xcd0fac: LeaveFrame
    //     0xcd0fac: mov             SP, fp
    //     0xcd0fb0: ldp             fp, lr, [SP], #0x10
    // 0xcd0fb4: ret
    //     0xcd0fb4: ret             
    // 0xcd0fb8: mov             x0, x3
    // 0xcd0fbc: LeaveFrame
    //     0xcd0fbc: mov             SP, fp
    //     0xcd0fc0: ldp             fp, lr, [SP], #0x10
    // 0xcd0fc4: ret
    //     0xcd0fc4: ret             
    // 0xcd0fc8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcd0fc8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcd0fcc: b               #0xcd0e44
  }
  [closure] static bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0xcd0fd0, size: 0x1f4
    // 0xcd0fd0: EnterFrame
    //     0xcd0fd0: stp             fp, lr, [SP, #-0x10]!
    //     0xcd0fd4: mov             fp, SP
    // 0xcd0fd8: ldr             x2, [fp, #0x18]
    // 0xcd0fdc: LoadField: r3 = r2->field_17
    //     0xcd0fdc: ldur            w3, [x2, #0x17]
    // 0xcd0fe0: DecompressPointer r3
    //     0xcd0fe0: add             x3, x3, HEAP, lsl #32
    // 0xcd0fe4: ldr             x2, [fp, #0x10]
    // 0xcd0fe8: r4 = LoadClassIdInstr(r2)
    //     0xcd0fe8: ldur            x4, [x2, #-1]
    //     0xcd0fec: ubfx            x4, x4, #0xc, #0x14
    // 0xcd0ff0: lsl             x4, x4, #1
    // 0xcd0ff4: r17 = 6950
    //     0xcd0ff4: mov             x17, #0x1b26
    // 0xcd0ff8: cmp             w4, w17
    // 0xcd0ffc: b.ne            #0xcd10e0
    // 0xcd1000: LoadField: r5 = r3->field_13
    //     0xcd1000: ldur            w5, [x3, #0x13]
    // 0xcd1004: DecompressPointer r5
    //     0xcd1004: add             x5, x5, HEAP, lsl #32
    // 0xcd1008: LoadField: r6 = r2->field_37
    //     0xcd1008: ldur            w6, [x2, #0x37]
    // 0xcd100c: DecompressPointer r6
    //     0xcd100c: add             x6, x6, HEAP, lsl #32
    // 0xcd1010: LoadField: r7 = r6->field_7
    //     0xcd1010: ldur            x7, [x6, #7]
    // 0xcd1014: cmp             w5, NULL
    // 0xcd1018: b.eq            #0xcd11bc
    // 0xcd101c: r8 = LoadInt32Instr(r5)
    //     0xcd101c: sbfx            x8, x5, #1, #0x1f
    //     0xcd1020: tbz             w5, #0, #0xcd1028
    //     0xcd1024: ldur            x8, [x5, #7]
    // 0xcd1028: cmp             x8, x7
    // 0xcd102c: b.lt            #0xcd10e0
    // 0xcd1030: LoadField: r5 = r6->field_f
    //     0xcd1030: ldur            x5, [x6, #0xf]
    // 0xcd1034: cmp             x8, x5
    // 0xcd1038: b.gt            #0xcd10e0
    // 0xcd103c: d0 = 2.000000
    //     0xcd103c: fmov            d0, #2.00000000
    // 0xcd1040: sub             x6, x5, x7
    // 0xcd1044: scvtf           d1, x6
    // 0xcd1048: fdiv            d2, d1, d0
    // 0xcd104c: scvtf           d0, x7
    // 0xcd1050: fadd            d1, d2, d0
    // 0xcd1054: scvtf           d0, x8
    // 0xcd1058: fcmp            d0, d1
    // 0xcd105c: b.vs            #0xcd109c
    // 0xcd1060: b.le            #0xcd109c
    // 0xcd1064: r0 = BoxInt64Instr(r5)
    //     0xcd1064: sbfiz           x0, x5, #1, #0x1f
    //     0xcd1068: cmp             x5, x0, asr #1
    //     0xcd106c: b.eq            #0xcd1078
    //     0xcd1070: bl              #0xd69bb8
    //     0xcd1074: stur            x5, [x0, #7]
    // 0xcd1078: StoreField: r3->field_13 = r0
    //     0xcd1078: stur            w0, [x3, #0x13]
    //     0xcd107c: tbz             w0, #0, #0xcd1098
    //     0xcd1080: ldurb           w16, [x3, #-1]
    //     0xcd1084: ldurb           w17, [x0, #-1]
    //     0xcd1088: and             x16, x17, x16, lsr #2
    //     0xcd108c: tst             x16, HEAP, lsr #32
    //     0xcd1090: b.eq            #0xcd1098
    //     0xcd1094: bl              #0xd682ac
    // 0xcd1098: b               #0xcd10d0
    // 0xcd109c: r0 = BoxInt64Instr(r7)
    //     0xcd109c: sbfiz           x0, x7, #1, #0x1f
    //     0xcd10a0: cmp             x7, x0, asr #1
    //     0xcd10a4: b.eq            #0xcd10b0
    //     0xcd10a8: bl              #0xd69bb8
    //     0xcd10ac: stur            x7, [x0, #7]
    // 0xcd10b0: StoreField: r3->field_13 = r0
    //     0xcd10b0: stur            w0, [x3, #0x13]
    //     0xcd10b4: tbz             w0, #0, #0xcd10d0
    //     0xcd10b8: ldurb           w16, [x3, #-1]
    //     0xcd10bc: ldurb           w17, [x0, #-1]
    //     0xcd10c0: and             x16, x17, x16, lsr #2
    //     0xcd10c4: tst             x16, HEAP, lsr #32
    //     0xcd10c8: b.eq            #0xcd10d0
    //     0xcd10cc: bl              #0xd682ac
    // 0xcd10d0: r0 = false
    //     0xcd10d0: add             x0, NULL, #0x30  ; false
    // 0xcd10d4: LeaveFrame
    //     0xcd10d4: mov             SP, fp
    //     0xcd10d8: ldp             fp, lr, [SP], #0x10
    // 0xcd10dc: ret
    //     0xcd10dc: ret             
    // 0xcd10e0: LoadField: r5 = r3->field_17
    //     0xcd10e0: ldur            w5, [x3, #0x17]
    // 0xcd10e4: DecompressPointer r5
    //     0xcd10e4: add             x5, x5, HEAP, lsl #32
    // 0xcd10e8: r6 = LoadInt32Instr(r4)
    //     0xcd10e8: sbfx            x6, x4, #1, #0x1f
    // 0xcd10ec: cmp             x6, #0xd91
    // 0xcd10f0: b.lt            #0xcd1120
    // 0xcd10f4: cmp             x6, #0xd93
    // 0xcd10f8: b.gt            #0xcd1120
    // 0xcd10fc: LoadField: r4 = r2->field_b
    //     0xcd10fc: ldur            w4, [x2, #0xb]
    // 0xcd1100: DecompressPointer r4
    //     0xcd1100: add             x4, x4, HEAP, lsl #32
    // 0xcd1104: cmp             w4, NULL
    // 0xcd1108: b.eq            #0xcd1120
    // 0xcd110c: LoadField: r2 = r4->field_7
    //     0xcd110c: ldur            w2, [x4, #7]
    // 0xcd1110: DecompressPointer r2
    //     0xcd1110: add             x2, x2, HEAP, lsl #32
    // 0xcd1114: r4 = LoadInt32Instr(r2)
    //     0xcd1114: sbfx            x4, x2, #1, #0x1f
    // 0xcd1118: mov             x2, x4
    // 0xcd111c: b               #0xcd113c
    // 0xcd1120: cmp             x6, #0xd95
    // 0xcd1124: b.lt            #0xcd1138
    // 0xcd1128: cmp             x6, #0xd97
    // 0xcd112c: b.gt            #0xcd1138
    // 0xcd1130: r2 = 1
    //     0xcd1130: mov             x2, #1
    // 0xcd1134: b               #0xcd113c
    // 0xcd1138: r2 = 0
    //     0xcd1138: mov             x2, #0
    // 0xcd113c: cmp             w5, NULL
    // 0xcd1140: b.eq            #0xcd11c0
    // 0xcd1144: r4 = LoadInt32Instr(r5)
    //     0xcd1144: sbfx            x4, x5, #1, #0x1f
    //     0xcd1148: tbz             w5, #0, #0xcd1150
    //     0xcd114c: ldur            x4, [x5, #7]
    // 0xcd1150: add             x5, x4, x2
    // 0xcd1154: r0 = BoxInt64Instr(r5)
    //     0xcd1154: sbfiz           x0, x5, #1, #0x1f
    //     0xcd1158: cmp             x5, x0, asr #1
    //     0xcd115c: b.eq            #0xcd1168
    //     0xcd1160: bl              #0xd69bb8
    //     0xcd1164: stur            x5, [x0, #7]
    // 0xcd1168: StoreField: r3->field_17 = r0
    //     0xcd1168: stur            w0, [x3, #0x17]
    //     0xcd116c: tbz             w0, #0, #0xcd1188
    //     0xcd1170: ldurb           w16, [x3, #-1]
    //     0xcd1174: ldurb           w17, [x0, #-1]
    //     0xcd1178: and             x16, x17, x16, lsr #2
    //     0xcd117c: tst             x16, HEAP, lsr #32
    //     0xcd1180: b.eq            #0xcd1188
    //     0xcd1184: bl              #0xd682ac
    // 0xcd1188: LoadField: r1 = r3->field_f
    //     0xcd1188: ldur            w1, [x3, #0xf]
    // 0xcd118c: DecompressPointer r1
    //     0xcd118c: add             x1, x1, HEAP, lsl #32
    // 0xcd1190: LoadField: r2 = r1->field_7
    //     0xcd1190: ldur            x2, [x1, #7]
    // 0xcd1194: cmp             x5, x2
    // 0xcd1198: b.lt            #0xcd11ac
    // 0xcd119c: r0 = false
    //     0xcd119c: add             x0, NULL, #0x30  ; false
    // 0xcd11a0: LeaveFrame
    //     0xcd11a0: mov             SP, fp
    //     0xcd11a4: ldp             fp, lr, [SP], #0x10
    // 0xcd11a8: ret
    //     0xcd11a8: ret             
    // 0xcd11ac: r0 = true
    //     0xcd11ac: add             x0, NULL, #0x20  ; true
    // 0xcd11b0: LeaveFrame
    //     0xcd11b0: mov             SP, fp
    //     0xcd11b4: ldp             fp, lr, [SP], #0x10
    // 0xcd11b8: ret
    //     0xcd11b8: ret             
    // 0xcd11bc: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcd11bc: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0xcd11c0: r0 = NullErrorSharedWithoutFPURegs()
    //     0xcd11c0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}

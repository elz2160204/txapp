// lib: , url: package:extended_text_library/src/special_inline_span_base.dart

// class id: 1048988, size: 0x8
class :: {
}

// class id: 4429, size: 0x8, field offset: 0x8
abstract class SpecialInlineSpanBase extends Object {
}

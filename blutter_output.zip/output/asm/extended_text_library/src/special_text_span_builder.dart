// lib: , url: package:extended_text_library/src/special_text_span_builder.dart

// class id: 1048990, size: 0x8
class :: {
}

// class id: 4425, size: 0x14, field offset: 0x8
abstract class SpecialText extends Object {

  _ getContent(/* No info */) {
    // ** addr: 0x7ab438, size: 0x90
    // 0x7ab438: EnterFrame
    //     0x7ab438: stp             fp, lr, [SP, #-0x10]!
    //     0x7ab43c: mov             fp, SP
    // 0x7ab440: AllocStack(0x8)
    //     0x7ab440: sub             SP, SP, #8
    // 0x7ab444: CheckStackOverflow
    //     0x7ab444: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ab448: cmp             SP, x16
    //     0x7ab44c: b.ls            #0x7ab4c0
    // 0x7ab450: ldr             x0, [fp, #0x10]
    // 0x7ab454: LoadField: r1 = r0->field_7
    //     0x7ab454: ldur            w1, [x0, #7]
    // 0x7ab458: DecompressPointer r1
    //     0x7ab458: add             x1, x1, HEAP, lsl #32
    // 0x7ab45c: SaveReg r1
    //     0x7ab45c: str             x1, [SP, #-8]!
    // 0x7ab460: r0 = toString()
    //     0x7ab460: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0x7ab464: add             SP, SP, #8
    // 0x7ab468: stur            x0, [fp, #-8]
    // 0x7ab46c: r16 = " "
    //     0x7ab46c: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x7ab470: stp             x16, x0, [SP, #-0x10]!
    // 0x7ab474: r0 = endsWith()
    //     0x7ab474: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0x7ab478: add             SP, SP, #0x10
    // 0x7ab47c: tbnz            w0, #4, #0x7ab4b0
    // 0x7ab480: ldur            x0, [fp, #-8]
    // 0x7ab484: LoadField: r1 = r0->field_7
    //     0x7ab484: ldur            w1, [x0, #7]
    // 0x7ab488: DecompressPointer r1
    //     0x7ab488: add             x1, x1, HEAP, lsl #32
    // 0x7ab48c: r2 = LoadInt32Instr(r1)
    //     0x7ab48c: sbfx            x2, x1, #1, #0x1f
    // 0x7ab490: sub             x1, x2, #1
    // 0x7ab494: lsl             x2, x1, #1
    // 0x7ab498: stp             xzr, x0, [SP, #-0x10]!
    // 0x7ab49c: SaveReg r2
    //     0x7ab49c: str             x2, [SP, #-8]!
    // 0x7ab4a0: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7ab4a0: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7ab4a4: r0 = substring()
    //     0x7ab4a4: bl              #0x4d09f4  ; [dart:core] _StringBase::substring
    // 0x7ab4a8: add             SP, SP, #0x18
    // 0x7ab4ac: b               #0x7ab4b4
    // 0x7ab4b0: ldur            x0, [fp, #-8]
    // 0x7ab4b4: LeaveFrame
    //     0x7ab4b4: mov             SP, fp
    //     0x7ab4b8: ldp             fp, lr, [SP], #0x10
    // 0x7ab4bc: ret
    //     0x7ab4bc: ret             
    // 0x7ab4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ab4c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ab4c4: b               #0x7ab450
  }
  _ toString(/* No info */) {
    // ** addr: 0xad4164, size: 0x58
    // 0xad4164: EnterFrame
    //     0xad4164: stp             fp, lr, [SP, #-0x10]!
    //     0xad4168: mov             fp, SP
    // 0xad416c: CheckStackOverflow
    //     0xad416c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad4170: cmp             SP, x16
    //     0xad4174: b.ls            #0xad41b4
    // 0xad4178: ldr             x16, [fp, #0x10]
    // 0xad417c: SaveReg r16
    //     0xad417c: str             x16, [SP, #-8]!
    // 0xad4180: r0 = getContent()
    //     0xad4180: bl              #0x7ab438  ; [package:extended_text_library/src/special_text_span_builder.dart] SpecialText::getContent
    // 0xad4184: add             SP, SP, #8
    // 0xad4188: r16 = "@"
    //     0xad4188: ldr             x16, [PP, #0x1568]  ; [pp+0x1568] "@"
    // 0xad418c: stp             x0, x16, [SP, #-0x10]!
    // 0xad4190: r0 = +()
    //     0xad4190: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xad4194: add             SP, SP, #0x10
    // 0xad4198: r16 = " "
    //     0xad4198: ldr             x16, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0xad419c: stp             x16, x0, [SP, #-0x10]!
    // 0xad41a0: r0 = +()
    //     0xad41a0: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xad41a4: add             SP, SP, #0x10
    // 0xad41a8: LeaveFrame
    //     0xad41a8: mov             SP, fp
    //     0xad41ac: ldp             fp, lr, [SP], #0x10
    // 0xad41b0: ret
    //     0xad41b0: ret             
    // 0xad41b4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad41b4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad41b8: b               #0xad4178
  }
}

// class id: 4427, size: 0x8, field offset: 0x8
abstract class SpecialTextSpanBuilder extends Object {

  _ build(/* No info */) {
    // ** addr: 0x7aad58, size: 0x6e0
    // 0x7aad58: EnterFrame
    //     0x7aad58: stp             fp, lr, [SP, #-0x10]!
    //     0x7aad5c: mov             fp, SP
    // 0x7aad60: AllocStack(0x50)
    //     0x7aad60: sub             SP, SP, #0x50
    // 0x7aad64: CheckStackOverflow
    //     0x7aad64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aad68: cmp             SP, x16
    //     0x7aad6c: b.ls            #0x7ab414
    // 0x7aad70: ldr             x1, [fp, #0x18]
    // 0x7aad74: r0 = LoadClassIdInstr(r1)
    //     0x7aad74: ldur            x0, [x1, #-1]
    //     0x7aad78: ubfx            x0, x0, #0xc, #0x14
    // 0x7aad7c: r16 = ""
    //     0x7aad7c: ldr             x16, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x7aad80: stp             x16, x1, [SP, #-0x10]!
    // 0x7aad84: mov             lr, x0
    // 0x7aad88: ldr             lr, [x21, lr, lsl #3]
    // 0x7aad8c: blr             lr
    // 0x7aad90: add             SP, SP, #0x10
    // 0x7aad94: tbnz            w0, #4, #0x7aadac
    // 0x7aad98: r0 = Instance_TextSpan
    //     0x7aad98: add             x0, PP, #0x37, lsl #12  ; [pp+0x376a8] Obj!TextSpan@b49721
    //     0x7aad9c: ldr             x0, [x0, #0x6a8]
    // 0x7aada0: LeaveFrame
    //     0x7aada0: mov             SP, fp
    //     0x7aada4: ldp             fp, lr, [SP], #0x10
    // 0x7aada8: ret
    //     0x7aada8: ret             
    // 0x7aadac: ldr             x0, [fp, #0x18]
    // 0x7aadb0: r16 = <InlineSpan>
    //     0x7aadb0: add             x16, PP, #0x14, lsl #12  ; [pp+0x14ff8] TypeArguments: <InlineSpan>
    //     0x7aadb4: ldr             x16, [x16, #0xff8]
    // 0x7aadb8: stp             xzr, x16, [SP, #-0x10]!
    // 0x7aadbc: r0 = _GrowableList()
    //     0x7aadbc: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x7aadc0: add             SP, SP, #0x10
    // 0x7aadc4: mov             x3, x0
    // 0x7aadc8: ldr             x2, [fp, #0x18]
    // 0x7aadcc: stur            x3, [fp, #-0x30]
    // 0x7aadd0: LoadField: r0 = r2->field_7
    //     0x7aadd0: ldur            w0, [x2, #7]
    // 0x7aadd4: DecompressPointer r0
    //     0x7aadd4: add             x0, x0, HEAP, lsl #32
    // 0x7aadd8: cbz             w0, #0x7ab32c
    // 0x7aaddc: ldr             x1, [fp, #0x20]
    // 0x7aade0: r4 = LoadInt32Instr(r0)
    //     0x7aade0: sbfx            x4, x0, #1, #0x1f
    // 0x7aade4: stur            x4, [fp, #-0x28]
    // 0x7aade8: LoadField: r5 = r1->field_7
    //     0x7aade8: ldur            x5, [x1, #7]
    // 0x7aadec: stur            x5, [fp, #-0x20]
    // 0x7aadf0: r9 = Null
    //     0x7aadf0: mov             x9, NULL
    // 0x7aadf4: r8 = ""
    //     0x7aadf4: ldr             x8, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x7aadf8: r7 = 0
    //     0x7aadf8: mov             x7, #0
    // 0x7aadfc: ldr             x6, [fp, #0x10]
    // 0x7aae00: stur            x9, [fp, #-8]
    // 0x7aae04: stur            x8, [fp, #-0x10]
    // 0x7aae08: stur            x7, [fp, #-0x18]
    // 0x7aae0c: CheckStackOverflow
    //     0x7aae0c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aae10: cmp             SP, x16
    //     0x7aae14: b.ls            #0x7ab41c
    // 0x7aae18: cmp             x7, x4
    // 0x7aae1c: b.ge            #0x7ab17c
    // 0x7aae20: r0 = BoxInt64Instr(r7)
    //     0x7aae20: sbfiz           x0, x7, #1, #0x1f
    //     0x7aae24: cmp             x7, x0, asr #1
    //     0x7aae28: b.eq            #0x7aae34
    //     0x7aae2c: bl              #0xd69bb8
    //     0x7aae30: stur            x7, [x0, #7]
    // 0x7aae34: stp             x0, x2, [SP, #-0x10]!
    // 0x7aae38: r0 = []()
    //     0x7aae38: bl              #0x4bdc9c  ; [dart:core] _StringBase::[]
    // 0x7aae3c: add             SP, SP, #0x10
    // 0x7aae40: stur            x0, [fp, #-0x38]
    // 0x7aae44: ldur            x16, [fp, #-0x10]
    // 0x7aae48: stp             x0, x16, [SP, #-0x10]!
    // 0x7aae4c: r0 = +()
    //     0x7aae4c: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x7aae50: add             SP, SP, #0x10
    // 0x7aae54: mov             x1, x0
    // 0x7aae58: ldur            x0, [fp, #-8]
    // 0x7aae5c: stur            x1, [fp, #-0x40]
    // 0x7aae60: cmp             w0, NULL
    // 0x7aae64: b.eq            #0x7aaf80
    // 0x7aae68: LoadField: r2 = r0->field_7
    //     0x7aae68: ldur            w2, [x0, #7]
    // 0x7aae6c: DecompressPointer r2
    //     0x7aae6c: add             x2, x2, HEAP, lsl #32
    // 0x7aae70: ldur            x16, [fp, #-0x38]
    // 0x7aae74: stp             x16, x2, [SP, #-0x10]!
    // 0x7aae78: r0 = write()
    //     0x7aae78: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0x7aae7c: add             SP, SP, #0x10
    // 0x7aae80: ldur            x16, [fp, #-0x40]
    // 0x7aae84: r30 = " "
    //     0x7aae84: ldr             lr, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x7aae88: stp             lr, x16, [SP, #-0x10]!
    // 0x7aae8c: r0 = endsWith()
    //     0x7aae8c: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0x7aae90: add             SP, SP, #0x10
    // 0x7aae94: tbnz            w0, #4, #0x7aaf68
    // 0x7aae98: ldur            x0, [fp, #-0x30]
    // 0x7aae9c: ldur            x16, [fp, #-8]
    // 0x7aaea0: SaveReg r16
    //     0x7aaea0: str             x16, [SP, #-8]!
    // 0x7aaea4: r0 = toString()
    //     0x7aaea4: bl              #0xad4164  ; [package:extended_text_library/src/special_text_span_builder.dart] SpecialText::toString
    // 0x7aaea8: add             SP, SP, #8
    // 0x7aaeac: stur            x0, [fp, #-0x38]
    // 0x7aaeb0: r0 = SpecialTextSpan()
    //     0x7aaeb0: bl              #0x7ab598  ; AllocateSpecialTextSpanStub -> SpecialTextSpan (size=0x3c)
    // 0x7aaeb4: stur            x0, [fp, #-0x48]
    // 0x7aaeb8: ldur            x16, [fp, #-0x38]
    // 0x7aaebc: stp             x16, x0, [SP, #-0x10]!
    // 0x7aaec0: ldur            x16, [fp, #-0x38]
    // 0x7aaec4: SaveReg r16
    //     0x7aaec4: str             x16, [SP, #-8]!
    // 0x7aaec8: r0 = SpecialTextSpan()
    //     0x7aaec8: bl              #0x7ab4d4  ; [package:extended_text_library/src/special_text_span.dart] SpecialTextSpan::SpecialTextSpan
    // 0x7aaecc: add             SP, SP, #0x18
    // 0x7aaed0: ldur            x0, [fp, #-0x30]
    // 0x7aaed4: LoadField: r1 = r0->field_b
    //     0x7aaed4: ldur            w1, [x0, #0xb]
    // 0x7aaed8: DecompressPointer r1
    //     0x7aaed8: add             x1, x1, HEAP, lsl #32
    // 0x7aaedc: stur            x1, [fp, #-0x38]
    // 0x7aaee0: LoadField: r2 = r0->field_f
    //     0x7aaee0: ldur            w2, [x0, #0xf]
    // 0x7aaee4: DecompressPointer r2
    //     0x7aaee4: add             x2, x2, HEAP, lsl #32
    // 0x7aaee8: LoadField: r3 = r2->field_b
    //     0x7aaee8: ldur            w3, [x2, #0xb]
    // 0x7aaeec: DecompressPointer r3
    //     0x7aaeec: add             x3, x3, HEAP, lsl #32
    // 0x7aaef0: cmp             w1, w3
    // 0x7aaef4: b.ne            #0x7aaf04
    // 0x7aaef8: SaveReg r0
    //     0x7aaef8: str             x0, [SP, #-8]!
    // 0x7aaefc: r0 = _growToNextCapacity()
    //     0x7aaefc: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7aaf00: add             SP, SP, #8
    // 0x7aaf04: ldur            x2, [fp, #-0x30]
    // 0x7aaf08: ldur            x0, [fp, #-0x38]
    // 0x7aaf0c: r3 = LoadInt32Instr(r0)
    //     0x7aaf0c: sbfx            x3, x0, #1, #0x1f
    // 0x7aaf10: add             x0, x3, #1
    // 0x7aaf14: lsl             x1, x0, #1
    // 0x7aaf18: StoreField: r2->field_b = r1
    //     0x7aaf18: stur            w1, [x2, #0xb]
    // 0x7aaf1c: mov             x1, x3
    // 0x7aaf20: cmp             x1, x0
    // 0x7aaf24: b.hs            #0x7ab424
    // 0x7aaf28: LoadField: r1 = r2->field_f
    //     0x7aaf28: ldur            w1, [x2, #0xf]
    // 0x7aaf2c: DecompressPointer r1
    //     0x7aaf2c: add             x1, x1, HEAP, lsl #32
    // 0x7aaf30: ldur            x0, [fp, #-0x48]
    // 0x7aaf34: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7aaf34: add             x25, x1, x3, lsl #2
    //     0x7aaf38: add             x25, x25, #0xf
    //     0x7aaf3c: str             w0, [x25]
    //     0x7aaf40: tbz             w0, #0, #0x7aaf5c
    //     0x7aaf44: ldurb           w16, [x1, #-1]
    //     0x7aaf48: ldurb           w17, [x0, #-1]
    //     0x7aaf4c: and             x16, x17, x16, lsr #2
    //     0x7aaf50: tst             x16, HEAP, lsr #32
    //     0x7aaf54: b.eq            #0x7aaf5c
    //     0x7aaf58: bl              #0xd67e5c
    // 0x7aaf5c: r1 = Null
    //     0x7aaf5c: mov             x1, NULL
    // 0x7aaf60: r0 = ""
    //     0x7aaf60: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x7aaf64: b               #0x7aaf74
    // 0x7aaf68: ldur            x2, [fp, #-0x30]
    // 0x7aaf6c: ldur            x1, [fp, #-8]
    // 0x7aaf70: ldur            x0, [fp, #-0x40]
    // 0x7aaf74: mov             x9, x1
    // 0x7aaf78: mov             x8, x0
    // 0x7aaf7c: b               #0x7ab160
    // 0x7aaf80: ldur            x2, [fp, #-0x30]
    // 0x7aaf84: r0 = LoadClassIdInstr(r1)
    //     0x7aaf84: ldur            x0, [x1, #-1]
    //     0x7aaf88: ubfx            x0, x0, #0xc, #0x14
    // 0x7aaf8c: r16 = "@"
    //     0x7aaf8c: ldr             x16, [PP, #0x1568]  ; [pp+0x1568] "@"
    // 0x7aaf90: stp             x16, x1, [SP, #-0x10]!
    // 0x7aaf94: mov             lr, x0
    // 0x7aaf98: ldr             lr, [x21, lr, lsl #3]
    // 0x7aaf9c: blr             lr
    // 0x7aafa0: add             SP, SP, #0x10
    // 0x7aafa4: tbnz            w0, #4, #0x7ab01c
    // 0x7aafa8: ldur            x0, [fp, #-0x18]
    // 0x7aafac: cbnz            x0, #0x7ab01c
    // 0x7aafb0: ldur            x1, [fp, #-0x20]
    // 0x7aafb4: cmp             x1, #0
    // 0x7aafb8: b.le            #0x7ab01c
    // 0x7aafbc: r0 = _MentionText()
    //     0x7aafbc: bl              #0x7ab4c8  ; Allocate_MentionTextStub -> _MentionText (size=0x14)
    // 0x7aafc0: mov             x1, x0
    // 0x7aafc4: r0 = "@"
    //     0x7aafc4: ldr             x0, [PP, #0x1568]  ; [pp+0x1568] "@"
    // 0x7aafc8: stur            x1, [fp, #-0x38]
    // 0x7aafcc: StoreField: r1->field_b = r0
    //     0x7aafcc: stur            w0, [x1, #0xb]
    // 0x7aafd0: r2 = " "
    //     0x7aafd0: ldr             x2, [PP, #0x1098]  ; [pp+0x1098] " "
    // 0x7aafd4: StoreField: r1->field_f = r2
    //     0x7aafd4: stur            w2, [x1, #0xf]
    // 0x7aafd8: r0 = StringBuffer()
    //     0x7aafd8: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0x7aafdc: stur            x0, [fp, #-0x48]
    // 0x7aafe0: SaveReg r0
    //     0x7aafe0: str             x0, [SP, #-8]!
    // 0x7aafe4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7aafe4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7aafe8: r0 = StringBuffer()
    //     0x7aafe8: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0x7aafec: add             SP, SP, #8
    // 0x7aaff0: ldur            x0, [fp, #-0x48]
    // 0x7aaff4: ldur            x1, [fp, #-0x38]
    // 0x7aaff8: StoreField: r1->field_7 = r0
    //     0x7aaff8: stur            w0, [x1, #7]
    //     0x7aaffc: ldurb           w16, [x1, #-1]
    //     0x7ab000: ldurb           w17, [x0, #-1]
    //     0x7ab004: and             x16, x17, x16, lsr #2
    //     0x7ab008: tst             x16, HEAP, lsr #32
    //     0x7ab00c: b.eq            #0x7ab014
    //     0x7ab010: bl              #0xd6826c
    // 0x7ab014: mov             x0, x1
    // 0x7ab018: b               #0x7ab020
    // 0x7ab01c: r0 = Null
    //     0x7ab01c: mov             x0, NULL
    // 0x7ab020: stur            x0, [fp, #-0x38]
    // 0x7ab024: cmp             w0, NULL
    // 0x7ab028: b.eq            #0x7ab150
    // 0x7ab02c: ldur            x1, [fp, #-0x40]
    // 0x7ab030: LoadField: r2 = r1->field_7
    //     0x7ab030: ldur            w2, [x1, #7]
    // 0x7ab034: DecompressPointer r2
    //     0x7ab034: add             x2, x2, HEAP, lsl #32
    // 0x7ab038: r3 = LoadInt32Instr(r2)
    //     0x7ab038: sbfx            x3, x2, #1, #0x1f
    // 0x7ab03c: sub             x2, x3, #1
    // 0x7ab040: tbnz            x2, #0x3f, #0x7ab144
    // 0x7ab044: lsl             x4, x2, #1
    // 0x7ab048: stp             x4, xzr, [SP, #-0x10]!
    // 0x7ab04c: SaveReg r3
    //     0x7ab04c: str             x3, [SP, #-8]!
    // 0x7ab050: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x7ab050: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x7ab054: r0 = checkValidRange()
    //     0x7ab054: bl              #0x4c2754  ; [dart:core] RangeError::checkValidRange
    // 0x7ab058: add             SP, SP, #0x18
    // 0x7ab05c: ldur            x16, [fp, #-0x40]
    // 0x7ab060: stp             xzr, x16, [SP, #-0x10]!
    // 0x7ab064: SaveReg r0
    //     0x7ab064: str             x0, [SP, #-8]!
    // 0x7ab068: r0 = _substringUnchecked()
    //     0x7ab068: bl              #0x4d0ab0  ; [dart:core] _StringBase::_substringUnchecked
    // 0x7ab06c: add             SP, SP, #0x18
    // 0x7ab070: stur            x0, [fp, #-0x48]
    // 0x7ab074: LoadField: r1 = r0->field_7
    //     0x7ab074: ldur            w1, [x0, #7]
    // 0x7ab078: DecompressPointer r1
    //     0x7ab078: add             x1, x1, HEAP, lsl #32
    // 0x7ab07c: cbz             w1, #0x7ab13c
    // 0x7ab080: ldr             x2, [fp, #0x10]
    // 0x7ab084: ldur            x1, [fp, #-0x30]
    // 0x7ab088: r0 = TextSpan()
    //     0x7ab088: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x7ab08c: mov             x1, x0
    // 0x7ab090: ldur            x0, [fp, #-0x48]
    // 0x7ab094: stur            x1, [fp, #-0x50]
    // 0x7ab098: StoreField: r1->field_b = r0
    //     0x7ab098: stur            w0, [x1, #0xb]
    // 0x7ab09c: r0 = Instance__DeferringMouseCursor
    //     0x7ab09c: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x7ab0a0: StoreField: r1->field_17 = r0
    //     0x7ab0a0: stur            w0, [x1, #0x17]
    // 0x7ab0a4: ldr             x2, [fp, #0x10]
    // 0x7ab0a8: StoreField: r1->field_7 = r2
    //     0x7ab0a8: stur            w2, [x1, #7]
    // 0x7ab0ac: ldur            x3, [fp, #-0x30]
    // 0x7ab0b0: LoadField: r4 = r3->field_b
    //     0x7ab0b0: ldur            w4, [x3, #0xb]
    // 0x7ab0b4: DecompressPointer r4
    //     0x7ab0b4: add             x4, x4, HEAP, lsl #32
    // 0x7ab0b8: stur            x4, [fp, #-0x48]
    // 0x7ab0bc: LoadField: r5 = r3->field_f
    //     0x7ab0bc: ldur            w5, [x3, #0xf]
    // 0x7ab0c0: DecompressPointer r5
    //     0x7ab0c0: add             x5, x5, HEAP, lsl #32
    // 0x7ab0c4: LoadField: r6 = r5->field_b
    //     0x7ab0c4: ldur            w6, [x5, #0xb]
    // 0x7ab0c8: DecompressPointer r6
    //     0x7ab0c8: add             x6, x6, HEAP, lsl #32
    // 0x7ab0cc: cmp             w4, w6
    // 0x7ab0d0: b.ne            #0x7ab0e0
    // 0x7ab0d4: SaveReg r3
    //     0x7ab0d4: str             x3, [SP, #-8]!
    // 0x7ab0d8: r0 = _growToNextCapacity()
    //     0x7ab0d8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7ab0dc: add             SP, SP, #8
    // 0x7ab0e0: ldur            x2, [fp, #-0x30]
    // 0x7ab0e4: ldur            x0, [fp, #-0x48]
    // 0x7ab0e8: r3 = LoadInt32Instr(r0)
    //     0x7ab0e8: sbfx            x3, x0, #1, #0x1f
    // 0x7ab0ec: add             x0, x3, #1
    // 0x7ab0f0: lsl             x1, x0, #1
    // 0x7ab0f4: StoreField: r2->field_b = r1
    //     0x7ab0f4: stur            w1, [x2, #0xb]
    // 0x7ab0f8: mov             x1, x3
    // 0x7ab0fc: cmp             x1, x0
    // 0x7ab100: b.hs            #0x7ab428
    // 0x7ab104: LoadField: r1 = r2->field_f
    //     0x7ab104: ldur            w1, [x2, #0xf]
    // 0x7ab108: DecompressPointer r1
    //     0x7ab108: add             x1, x1, HEAP, lsl #32
    // 0x7ab10c: ldur            x0, [fp, #-0x50]
    // 0x7ab110: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7ab110: add             x25, x1, x3, lsl #2
    //     0x7ab114: add             x25, x25, #0xf
    //     0x7ab118: str             w0, [x25]
    //     0x7ab11c: tbz             w0, #0, #0x7ab138
    //     0x7ab120: ldurb           w16, [x1, #-1]
    //     0x7ab124: ldurb           w17, [x0, #-1]
    //     0x7ab128: and             x16, x17, x16, lsr #2
    //     0x7ab12c: tst             x16, HEAP, lsr #32
    //     0x7ab130: b.eq            #0x7ab138
    //     0x7ab134: bl              #0xd67e5c
    // 0x7ab138: b               #0x7ab148
    // 0x7ab13c: ldur            x2, [fp, #-0x30]
    // 0x7ab140: b               #0x7ab148
    // 0x7ab144: ldur            x2, [fp, #-0x30]
    // 0x7ab148: r0 = ""
    //     0x7ab148: ldr             x0, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x7ab14c: b               #0x7ab158
    // 0x7ab150: ldur            x2, [fp, #-0x30]
    // 0x7ab154: ldur            x0, [fp, #-0x40]
    // 0x7ab158: ldur            x9, [fp, #-0x38]
    // 0x7ab15c: mov             x8, x0
    // 0x7ab160: ldur            x0, [fp, #-0x18]
    // 0x7ab164: add             x7, x0, #1
    // 0x7ab168: mov             x3, x2
    // 0x7ab16c: ldr             x2, [fp, #0x18]
    // 0x7ab170: ldur            x5, [fp, #-0x20]
    // 0x7ab174: ldur            x4, [fp, #-0x28]
    // 0x7ab178: b               #0x7aadfc
    // 0x7ab17c: mov             x2, x3
    // 0x7ab180: mov             x0, x9
    // 0x7ab184: cmp             w0, NULL
    // 0x7ab188: b.eq            #0x7ab264
    // 0x7ab18c: ldr             x1, [fp, #0x10]
    // 0x7ab190: SaveReg r0
    //     0x7ab190: str             x0, [SP, #-8]!
    // 0x7ab194: r0 = getContent()
    //     0x7ab194: bl              #0x7ab438  ; [package:extended_text_library/src/special_text_span_builder.dart] SpecialText::getContent
    // 0x7ab198: add             SP, SP, #8
    // 0x7ab19c: r16 = "@"
    //     0x7ab19c: ldr             x16, [PP, #0x1568]  ; [pp+0x1568] "@"
    // 0x7ab1a0: stp             x0, x16, [SP, #-0x10]!
    // 0x7ab1a4: r0 = +()
    //     0x7ab1a4: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0x7ab1a8: add             SP, SP, #0x10
    // 0x7ab1ac: stur            x0, [fp, #-8]
    // 0x7ab1b0: r0 = TextSpan()
    //     0x7ab1b0: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x7ab1b4: mov             x1, x0
    // 0x7ab1b8: ldur            x0, [fp, #-8]
    // 0x7ab1bc: stur            x1, [fp, #-0x38]
    // 0x7ab1c0: StoreField: r1->field_b = r0
    //     0x7ab1c0: stur            w0, [x1, #0xb]
    // 0x7ab1c4: r0 = Instance__DeferringMouseCursor
    //     0x7ab1c4: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x7ab1c8: StoreField: r1->field_17 = r0
    //     0x7ab1c8: stur            w0, [x1, #0x17]
    // 0x7ab1cc: ldr             x2, [fp, #0x10]
    // 0x7ab1d0: StoreField: r1->field_7 = r2
    //     0x7ab1d0: stur            w2, [x1, #7]
    // 0x7ab1d4: ldur            x3, [fp, #-0x30]
    // 0x7ab1d8: LoadField: r4 = r3->field_b
    //     0x7ab1d8: ldur            w4, [x3, #0xb]
    // 0x7ab1dc: DecompressPointer r4
    //     0x7ab1dc: add             x4, x4, HEAP, lsl #32
    // 0x7ab1e0: stur            x4, [fp, #-8]
    // 0x7ab1e4: LoadField: r5 = r3->field_f
    //     0x7ab1e4: ldur            w5, [x3, #0xf]
    // 0x7ab1e8: DecompressPointer r5
    //     0x7ab1e8: add             x5, x5, HEAP, lsl #32
    // 0x7ab1ec: LoadField: r6 = r5->field_b
    //     0x7ab1ec: ldur            w6, [x5, #0xb]
    // 0x7ab1f0: DecompressPointer r6
    //     0x7ab1f0: add             x6, x6, HEAP, lsl #32
    // 0x7ab1f4: cmp             w4, w6
    // 0x7ab1f8: b.ne            #0x7ab208
    // 0x7ab1fc: SaveReg r3
    //     0x7ab1fc: str             x3, [SP, #-8]!
    // 0x7ab200: r0 = _growToNextCapacity()
    //     0x7ab200: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7ab204: add             SP, SP, #8
    // 0x7ab208: ldur            x2, [fp, #-0x30]
    // 0x7ab20c: ldur            x0, [fp, #-8]
    // 0x7ab210: r3 = LoadInt32Instr(r0)
    //     0x7ab210: sbfx            x3, x0, #1, #0x1f
    // 0x7ab214: add             x0, x3, #1
    // 0x7ab218: lsl             x1, x0, #1
    // 0x7ab21c: StoreField: r2->field_b = r1
    //     0x7ab21c: stur            w1, [x2, #0xb]
    // 0x7ab220: mov             x1, x3
    // 0x7ab224: cmp             x1, x0
    // 0x7ab228: b.hs            #0x7ab42c
    // 0x7ab22c: LoadField: r1 = r2->field_f
    //     0x7ab22c: ldur            w1, [x2, #0xf]
    // 0x7ab230: DecompressPointer r1
    //     0x7ab230: add             x1, x1, HEAP, lsl #32
    // 0x7ab234: ldur            x0, [fp, #-0x38]
    // 0x7ab238: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7ab238: add             x25, x1, x3, lsl #2
    //     0x7ab23c: add             x25, x25, #0xf
    //     0x7ab240: str             w0, [x25]
    //     0x7ab244: tbz             w0, #0, #0x7ab260
    //     0x7ab248: ldurb           w16, [x1, #-1]
    //     0x7ab24c: ldurb           w17, [x0, #-1]
    //     0x7ab250: and             x16, x17, x16, lsr #2
    //     0x7ab254: tst             x16, HEAP, lsr #32
    //     0x7ab258: b.eq            #0x7ab260
    //     0x7ab25c: bl              #0xd67e5c
    // 0x7ab260: b               #0x7ab3e8
    // 0x7ab264: ldur            x0, [fp, #-0x10]
    // 0x7ab268: LoadField: r1 = r0->field_7
    //     0x7ab268: ldur            w1, [x0, #7]
    // 0x7ab26c: DecompressPointer r1
    //     0x7ab26c: add             x1, x1, HEAP, lsl #32
    // 0x7ab270: cbz             w1, #0x7ab3e8
    // 0x7ab274: ldr             x1, [fp, #0x10]
    // 0x7ab278: r0 = TextSpan()
    //     0x7ab278: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x7ab27c: mov             x1, x0
    // 0x7ab280: ldur            x0, [fp, #-0x10]
    // 0x7ab284: stur            x1, [fp, #-0x38]
    // 0x7ab288: StoreField: r1->field_b = r0
    //     0x7ab288: stur            w0, [x1, #0xb]
    // 0x7ab28c: r0 = Instance__DeferringMouseCursor
    //     0x7ab28c: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x7ab290: StoreField: r1->field_17 = r0
    //     0x7ab290: stur            w0, [x1, #0x17]
    // 0x7ab294: ldr             x2, [fp, #0x10]
    // 0x7ab298: StoreField: r1->field_7 = r2
    //     0x7ab298: stur            w2, [x1, #7]
    // 0x7ab29c: ldur            x3, [fp, #-0x30]
    // 0x7ab2a0: LoadField: r4 = r3->field_b
    //     0x7ab2a0: ldur            w4, [x3, #0xb]
    // 0x7ab2a4: DecompressPointer r4
    //     0x7ab2a4: add             x4, x4, HEAP, lsl #32
    // 0x7ab2a8: stur            x4, [fp, #-8]
    // 0x7ab2ac: LoadField: r5 = r3->field_f
    //     0x7ab2ac: ldur            w5, [x3, #0xf]
    // 0x7ab2b0: DecompressPointer r5
    //     0x7ab2b0: add             x5, x5, HEAP, lsl #32
    // 0x7ab2b4: LoadField: r6 = r5->field_b
    //     0x7ab2b4: ldur            w6, [x5, #0xb]
    // 0x7ab2b8: DecompressPointer r6
    //     0x7ab2b8: add             x6, x6, HEAP, lsl #32
    // 0x7ab2bc: cmp             w4, w6
    // 0x7ab2c0: b.ne            #0x7ab2d0
    // 0x7ab2c4: SaveReg r3
    //     0x7ab2c4: str             x3, [SP, #-8]!
    // 0x7ab2c8: r0 = _growToNextCapacity()
    //     0x7ab2c8: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7ab2cc: add             SP, SP, #8
    // 0x7ab2d0: ldur            x2, [fp, #-0x30]
    // 0x7ab2d4: ldur            x0, [fp, #-8]
    // 0x7ab2d8: r3 = LoadInt32Instr(r0)
    //     0x7ab2d8: sbfx            x3, x0, #1, #0x1f
    // 0x7ab2dc: add             x0, x3, #1
    // 0x7ab2e0: lsl             x1, x0, #1
    // 0x7ab2e4: StoreField: r2->field_b = r1
    //     0x7ab2e4: stur            w1, [x2, #0xb]
    // 0x7ab2e8: mov             x1, x3
    // 0x7ab2ec: cmp             x1, x0
    // 0x7ab2f0: b.hs            #0x7ab430
    // 0x7ab2f4: LoadField: r1 = r2->field_f
    //     0x7ab2f4: ldur            w1, [x2, #0xf]
    // 0x7ab2f8: DecompressPointer r1
    //     0x7ab2f8: add             x1, x1, HEAP, lsl #32
    // 0x7ab2fc: ldur            x0, [fp, #-0x38]
    // 0x7ab300: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7ab300: add             x25, x1, x3, lsl #2
    //     0x7ab304: add             x25, x25, #0xf
    //     0x7ab308: str             w0, [x25]
    //     0x7ab30c: tbz             w0, #0, #0x7ab328
    //     0x7ab310: ldurb           w16, [x1, #-1]
    //     0x7ab314: ldurb           w17, [x0, #-1]
    //     0x7ab318: and             x16, x17, x16, lsr #2
    //     0x7ab31c: tst             x16, HEAP, lsr #32
    //     0x7ab320: b.eq            #0x7ab328
    //     0x7ab324: bl              #0xd67e5c
    // 0x7ab328: b               #0x7ab3e8
    // 0x7ab32c: mov             x1, x2
    // 0x7ab330: ldr             x0, [fp, #0x10]
    // 0x7ab334: mov             x2, x3
    // 0x7ab338: r0 = TextSpan()
    //     0x7ab338: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x7ab33c: mov             x1, x0
    // 0x7ab340: ldr             x0, [fp, #0x18]
    // 0x7ab344: stur            x1, [fp, #-0x10]
    // 0x7ab348: StoreField: r1->field_b = r0
    //     0x7ab348: stur            w0, [x1, #0xb]
    // 0x7ab34c: r0 = Instance__DeferringMouseCursor
    //     0x7ab34c: ldr             x0, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x7ab350: StoreField: r1->field_17 = r0
    //     0x7ab350: stur            w0, [x1, #0x17]
    // 0x7ab354: ldr             x2, [fp, #0x10]
    // 0x7ab358: StoreField: r1->field_7 = r2
    //     0x7ab358: stur            w2, [x1, #7]
    // 0x7ab35c: ldur            x3, [fp, #-0x30]
    // 0x7ab360: LoadField: r4 = r3->field_b
    //     0x7ab360: ldur            w4, [x3, #0xb]
    // 0x7ab364: DecompressPointer r4
    //     0x7ab364: add             x4, x4, HEAP, lsl #32
    // 0x7ab368: stur            x4, [fp, #-8]
    // 0x7ab36c: LoadField: r5 = r3->field_f
    //     0x7ab36c: ldur            w5, [x3, #0xf]
    // 0x7ab370: DecompressPointer r5
    //     0x7ab370: add             x5, x5, HEAP, lsl #32
    // 0x7ab374: LoadField: r6 = r5->field_b
    //     0x7ab374: ldur            w6, [x5, #0xb]
    // 0x7ab378: DecompressPointer r6
    //     0x7ab378: add             x6, x6, HEAP, lsl #32
    // 0x7ab37c: cmp             w4, w6
    // 0x7ab380: b.ne            #0x7ab390
    // 0x7ab384: SaveReg r3
    //     0x7ab384: str             x3, [SP, #-8]!
    // 0x7ab388: r0 = _growToNextCapacity()
    //     0x7ab388: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x7ab38c: add             SP, SP, #8
    // 0x7ab390: ldur            x2, [fp, #-0x30]
    // 0x7ab394: ldur            x0, [fp, #-8]
    // 0x7ab398: r3 = LoadInt32Instr(r0)
    //     0x7ab398: sbfx            x3, x0, #1, #0x1f
    // 0x7ab39c: add             x0, x3, #1
    // 0x7ab3a0: lsl             x1, x0, #1
    // 0x7ab3a4: StoreField: r2->field_b = r1
    //     0x7ab3a4: stur            w1, [x2, #0xb]
    // 0x7ab3a8: mov             x1, x3
    // 0x7ab3ac: cmp             x1, x0
    // 0x7ab3b0: b.hs            #0x7ab434
    // 0x7ab3b4: LoadField: r1 = r2->field_f
    //     0x7ab3b4: ldur            w1, [x2, #0xf]
    // 0x7ab3b8: DecompressPointer r1
    //     0x7ab3b8: add             x1, x1, HEAP, lsl #32
    // 0x7ab3bc: ldur            x0, [fp, #-0x10]
    // 0x7ab3c0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x7ab3c0: add             x25, x1, x3, lsl #2
    //     0x7ab3c4: add             x25, x25, #0xf
    //     0x7ab3c8: str             w0, [x25]
    //     0x7ab3cc: tbz             w0, #0, #0x7ab3e8
    //     0x7ab3d0: ldurb           w16, [x1, #-1]
    //     0x7ab3d4: ldurb           w17, [x0, #-1]
    //     0x7ab3d8: and             x16, x17, x16, lsr #2
    //     0x7ab3dc: tst             x16, HEAP, lsr #32
    //     0x7ab3e0: b.eq            #0x7ab3e8
    //     0x7ab3e4: bl              #0xd67e5c
    // 0x7ab3e8: ldr             x0, [fp, #0x10]
    // 0x7ab3ec: r0 = TextSpan()
    //     0x7ab3ec: bl              #0x673780  ; AllocateTextSpanStub -> TextSpan (size=0x30)
    // 0x7ab3f0: ldur            x1, [fp, #-0x30]
    // 0x7ab3f4: StoreField: r0->field_f = r1
    //     0x7ab3f4: stur            w1, [x0, #0xf]
    // 0x7ab3f8: r1 = Instance__DeferringMouseCursor
    //     0x7ab3f8: ldr             x1, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x7ab3fc: StoreField: r0->field_17 = r1
    //     0x7ab3fc: stur            w1, [x0, #0x17]
    // 0x7ab400: ldr             x1, [fp, #0x10]
    // 0x7ab404: StoreField: r0->field_7 = r1
    //     0x7ab404: stur            w1, [x0, #7]
    // 0x7ab408: LeaveFrame
    //     0x7ab408: mov             SP, fp
    //     0x7ab40c: ldp             fp, lr, [SP], #0x10
    // 0x7ab410: ret
    //     0x7ab410: ret             
    // 0x7ab414: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ab414: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ab418: b               #0x7aad70
    // 0x7ab41c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ab41c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ab420: b               #0x7aae18
    // 0x7ab424: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ab424: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7ab428: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ab428: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7ab42c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ab42c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7ab430: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ab430: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7ab434: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ab434: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
}

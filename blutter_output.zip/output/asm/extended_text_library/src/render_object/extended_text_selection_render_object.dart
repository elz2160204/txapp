// lib: , url: package:extended_text_library/src/render_object/extended_text_selection_render_object.dart

// class id: 1048982, size: 0x8
class :: {
}

// class id: 2536, size: 0x98, field offset: 0x84
abstract class ExtendedTextSelectionRenderObject extends ExtendedTextRenderBox
    implements TextLayoutMetrics {

  late TapGestureRecognizer _tap; // offset: 0x84
  late LongPressGestureRecognizer _longPress; // offset: 0x88

  _ getRectForComposingRange(/* No info */) {
    // ** addr: 0x524670, size: 0x148
    // 0x524670: EnterFrame
    //     0x524670: stp             fp, lr, [SP, #-0x10]!
    //     0x524674: mov             fp, SP
    // 0x524678: AllocStack(0x18)
    //     0x524678: sub             SP, SP, #0x18
    // 0x52467c: CheckStackOverflow
    //     0x52467c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x524680: cmp             SP, x16
    //     0x524684: b.ls            #0x5247b0
    // 0x524688: ldr             x0, [fp, #0x10]
    // 0x52468c: LoadField: r1 = r0->field_7
    //     0x52468c: ldur            x1, [x0, #7]
    // 0x524690: stur            x1, [fp, #-0x10]
    // 0x524694: tbnz            x1, #0x3f, #0x5247a0
    // 0x524698: LoadField: r2 = r0->field_f
    //     0x524698: ldur            x2, [x0, #0xf]
    // 0x52469c: stur            x2, [fp, #-8]
    // 0x5246a0: tbnz            x2, #0x3f, #0x5247a0
    // 0x5246a4: cmp             x1, x2
    // 0x5246a8: b.eq            #0x5247a0
    // 0x5246ac: ldr             x0, [fp, #0x18]
    // 0x5246b0: SaveReg r0
    //     0x5246b0: str             x0, [SP, #-8]!
    // 0x5246b4: r0 = _computeTextMetricsIfNeeded()
    //     0x5246b4: bl              #0x52491c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_computeTextMetricsIfNeeded
    // 0x5246b8: add             SP, SP, #8
    // 0x5246bc: ldr             x0, [fp, #0x18]
    // 0x5246c0: LoadField: r1 = r0->field_eb
    //     0x5246c0: ldur            w1, [x0, #0xeb]
    // 0x5246c4: DecompressPointer r1
    //     0x5246c4: add             x1, x1, HEAP, lsl #32
    // 0x5246c8: stur            x1, [fp, #-0x18]
    // 0x5246cc: r0 = TextSelection()
    //     0x5246cc: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x5246d0: mov             x1, x0
    // 0x5246d4: ldur            x0, [fp, #-0x10]
    // 0x5246d8: StoreField: r1->field_17 = r0
    //     0x5246d8: stur            x0, [x1, #0x17]
    // 0x5246dc: ldur            x2, [fp, #-8]
    // 0x5246e0: StoreField: r1->field_1f = r2
    //     0x5246e0: stur            x2, [x1, #0x1f]
    // 0x5246e4: r3 = Instance_TextAffinity
    //     0x5246e4: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x5246e8: StoreField: r1->field_27 = r3
    //     0x5246e8: stur            w3, [x1, #0x27]
    // 0x5246ec: r3 = false
    //     0x5246ec: add             x3, NULL, #0x30  ; false
    // 0x5246f0: StoreField: r1->field_2b = r3
    //     0x5246f0: stur            w3, [x1, #0x2b]
    // 0x5246f4: cmp             x0, x2
    // 0x5246f8: b.ge            #0x524704
    // 0x5246fc: mov             x3, x0
    // 0x524700: b               #0x524708
    // 0x524704: mov             x3, x2
    // 0x524708: cmp             x0, x2
    // 0x52470c: b.ge            #0x524714
    // 0x524710: mov             x0, x2
    // 0x524714: StoreField: r1->field_7 = r3
    //     0x524714: stur            x3, [x1, #7]
    // 0x524718: StoreField: r1->field_f = r0
    //     0x524718: stur            x0, [x1, #0xf]
    // 0x52471c: ldur            x16, [fp, #-0x18]
    // 0x524720: stp             x1, x16, [SP, #-0x10]!
    // 0x524724: r0 = getBoxesForSelection()
    //     0x524724: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x524728: add             SP, SP, #0x10
    // 0x52472c: r1 = Function '<anonymous closure>':.
    //     0x52472c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37430] AnonymousClosure: (0x524a5c), in [package:flutter/src/rendering/editable.dart] RenderEditable::getRectForComposingRange (0x524ad0)
    //     0x524730: ldr             x1, [x1, #0x430]
    // 0x524734: r2 = Null
    //     0x524734: mov             x2, NULL
    // 0x524738: stur            x0, [fp, #-0x18]
    // 0x52473c: r0 = AllocateClosure()
    //     0x52473c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x524740: r16 = <Rect?>
    //     0x524740: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1ca20] TypeArguments: <Rect?>
    //     0x524744: ldr             x16, [x16, #0xa20]
    // 0x524748: ldur            lr, [fp, #-0x18]
    // 0x52474c: stp             lr, x16, [SP, #-0x10]!
    // 0x524750: stp             x0, NULL, [SP, #-0x10]!
    // 0x524754: r4 = const [0x1, 0x3, 0x3, 0x3, null]
    //     0x524754: ldr             x4, [PP, #0x4d0]  ; [pp+0x4d0] List(5) [0x1, 0x3, 0x3, 0x3, Null]
    // 0x524758: r0 = fold()
    //     0x524758: bl              #0x5247b8  ; [dart:collection] _ListBase&Object&ListMixin::fold
    // 0x52475c: add             SP, SP, #0x20
    // 0x524760: stur            x0, [fp, #-0x18]
    // 0x524764: cmp             w0, NULL
    // 0x524768: b.ne            #0x524774
    // 0x52476c: r0 = Null
    //     0x52476c: mov             x0, NULL
    // 0x524770: b               #0x524794
    // 0x524774: ldr             x16, [fp, #0x18]
    // 0x524778: SaveReg r16
    //     0x524778: str             x16, [SP, #-8]!
    // 0x52477c: r0 = paintOffset()
    //     0x52477c: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x524780: add             SP, SP, #8
    // 0x524784: ldur            x16, [fp, #-0x18]
    // 0x524788: stp             x0, x16, [SP, #-0x10]!
    // 0x52478c: r0 = shift()
    //     0x52478c: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x524790: add             SP, SP, #0x10
    // 0x524794: LeaveFrame
    //     0x524794: mov             SP, fp
    //     0x524798: ldp             fp, lr, [SP], #0x10
    // 0x52479c: ret
    //     0x52479c: ret             
    // 0x5247a0: r0 = Null
    //     0x5247a0: mov             x0, NULL
    // 0x5247a4: LeaveFrame
    //     0x5247a4: mov             SP, fp
    //     0x5247a8: ldp             fp, lr, [SP], #0x10
    // 0x5247ac: ret
    //     0x5247ac: ret             
    // 0x5247b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5247b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5247b4: b               #0x524688
  }
  _ _computeTextMetricsIfNeeded(/* No info */) {
    // ** addr: 0x52491c, size: 0x140
    // 0x52491c: EnterFrame
    //     0x52491c: stp             fp, lr, [SP, #-0x10]!
    //     0x524920: mov             fp, SP
    // 0x524924: AllocStack(0x8)
    //     0x524924: sub             SP, SP, #8
    // 0x524928: CheckStackOverflow
    //     0x524928: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52492c: cmp             SP, x16
    //     0x524930: b.ls            #0x524a28
    // 0x524934: ldr             x3, [fp, #0x10]
    // 0x524938: LoadField: r4 = r3->field_27
    //     0x524938: ldur            w4, [x3, #0x27]
    // 0x52493c: DecompressPointer r4
    //     0x52493c: add             x4, x4, HEAP, lsl #32
    // 0x524940: stur            x4, [fp, #-8]
    // 0x524944: cmp             w4, NULL
    // 0x524948: b.eq            #0x524a08
    // 0x52494c: mov             x0, x4
    // 0x524950: r2 = Null
    //     0x524950: mov             x2, NULL
    // 0x524954: r1 = Null
    //     0x524954: mov             x1, NULL
    // 0x524958: r4 = LoadClassIdInstr(r0)
    //     0x524958: ldur            x4, [x0, #-1]
    //     0x52495c: ubfx            x4, x4, #0xc, #0x14
    // 0x524960: sub             x4, x4, #0x80d
    // 0x524964: cmp             x4, #1
    // 0x524968: b.ls            #0x524980
    // 0x52496c: r8 = BoxConstraints
    //     0x52496c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x524970: ldr             x8, [x8, #0x1d0]
    // 0x524974: r3 = Null
    //     0x524974: add             x3, PP, #0x37, lsl #12  ; [pp+0x37438] Null
    //     0x524978: ldr             x3, [x3, #0x438]
    // 0x52497c: r0 = BoxConstraints()
    //     0x52497c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x524980: ldur            x0, [fp, #-8]
    // 0x524984: LoadField: d0 = r0->field_7
    //     0x524984: ldur            d0, [x0, #7]
    // 0x524988: LoadField: d1 = r0->field_f
    //     0x524988: ldur            d1, [x0, #0xf]
    // 0x52498c: r0 = inline_Allocate_Double()
    //     0x52498c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x524990: add             x0, x0, #0x10
    //     0x524994: cmp             x1, x0
    //     0x524998: b.ls            #0x524a30
    //     0x52499c: str             x0, [THR, #0x60]  ; THR::top
    //     0x5249a0: sub             x0, x0, #0xf
    //     0x5249a4: mov             x1, #0xd108
    //     0x5249a8: movk            x1, #3, lsl #16
    //     0x5249ac: stur            x1, [x0, #-1]
    // 0x5249b0: StoreField: r0->field_7 = d0
    //     0x5249b0: stur            d0, [x0, #7]
    // 0x5249b4: r1 = inline_Allocate_Double()
    //     0x5249b4: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x5249b8: add             x1, x1, #0x10
    //     0x5249bc: cmp             x2, x1
    //     0x5249c0: b.ls            #0x524a40
    //     0x5249c4: str             x1, [THR, #0x60]  ; THR::top
    //     0x5249c8: sub             x1, x1, #0xf
    //     0x5249cc: mov             x2, #0xd108
    //     0x5249d0: movk            x2, #3, lsl #16
    //     0x5249d4: stur            x2, [x1, #-1]
    // 0x5249d8: StoreField: r1->field_7 = d1
    //     0x5249d8: stur            d1, [x1, #7]
    // 0x5249dc: ldr             x16, [fp, #0x10]
    // 0x5249e0: stp             x0, x16, [SP, #-0x10]!
    // 0x5249e4: SaveReg r1
    //     0x5249e4: str             x1, [SP, #-8]!
    // 0x5249e8: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x5249e8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x5249ec: ldr             x4, [x4, #0x588]
    // 0x5249f0: r0 = layoutText()
    //     0x5249f0: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x5249f4: add             SP, SP, #0x18
    // 0x5249f8: r0 = Null
    //     0x5249f8: mov             x0, NULL
    // 0x5249fc: LeaveFrame
    //     0x5249fc: mov             SP, fp
    //     0x524a00: ldp             fp, lr, [SP], #0x10
    // 0x524a04: ret
    //     0x524a04: ret             
    // 0x524a08: r0 = StateError()
    //     0x524a08: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x524a0c: mov             x1, x0
    // 0x524a10: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x524a10: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x524a14: ldr             x0, [x0, #0x1e8]
    // 0x524a18: StoreField: r1->field_b = r0
    //     0x524a18: stur            w0, [x1, #0xb]
    // 0x524a1c: mov             x0, x1
    // 0x524a20: r0 = Throw()
    //     0x524a20: bl              #0xd67e38  ; ThrowStub
    // 0x524a24: brk             #0
    // 0x524a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x524a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x524a2c: b               #0x524934
    // 0x524a30: stp             q0, q1, [SP, #-0x20]!
    // 0x524a34: r0 = AllocateDouble()
    //     0x524a34: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x524a38: ldp             q0, q1, [SP], #0x20
    // 0x524a3c: b               #0x5249b0
    // 0x524a40: SaveReg d1
    //     0x524a40: str             q1, [SP, #-0x10]!
    // 0x524a44: SaveReg r0
    //     0x524a44: str             x0, [SP, #-8]!
    // 0x524a48: r0 = AllocateDouble()
    //     0x524a48: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x524a4c: mov             x1, x0
    // 0x524a50: RestoreReg r0
    //     0x524a50: ldr             x0, [SP], #8
    // 0x524a54: RestoreReg d1
    //     0x524a54: ldr             q1, [SP], #0x10
    // 0x524a58: b               #0x5249d8
  }
  _ paintHandleLayers(/* No info */) {
    // ** addr: 0x65c274, size: 0x53c
    // 0x65c274: EnterFrame
    //     0x65c274: stp             fp, lr, [SP, #-0x10]!
    //     0x65c278: mov             fp, SP
    // 0x65c27c: AllocStack(0x28)
    //     0x65c27c: sub             SP, SP, #0x28
    // 0x65c280: CheckStackOverflow
    //     0x65c280: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65c284: cmp             SP, x16
    //     0x65c288: b.ls            #0x65c688
    // 0x65c28c: ldr             x0, [fp, #0x20]
    // 0x65c290: r17 = 271
    //     0x65c290: mov             x17, #0x10f
    // 0x65c294: ldr             w1, [x0, x17]
    // 0x65c298: DecompressPointer r1
    //     0x65c298: add             x1, x1, HEAP, lsl #32
    // 0x65c29c: stp             x1, x0, [SP, #-0x10]!
    // 0x65c2a0: r0 = getEndpointsForSelection()
    //     0x65c2a0: bl              #0x51f684  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::getEndpointsForSelection
    // 0x65c2a4: add             SP, SP, #0x10
    // 0x65c2a8: mov             x2, x0
    // 0x65c2ac: stur            x2, [fp, #-0x10]
    // 0x65c2b0: LoadField: r0 = r2->field_b
    //     0x65c2b0: ldur            w0, [x2, #0xb]
    // 0x65c2b4: DecompressPointer r0
    //     0x65c2b4: add             x0, x0, HEAP, lsl #32
    // 0x65c2b8: cbnz            w0, #0x65c2cc
    // 0x65c2bc: r0 = Null
    //     0x65c2bc: mov             x0, NULL
    // 0x65c2c0: LeaveFrame
    //     0x65c2c0: mov             SP, fp
    //     0x65c2c4: ldp             fp, lr, [SP], #0x10
    // 0x65c2c8: ret
    //     0x65c2c8: ret             
    // 0x65c2cc: ldr             x3, [fp, #0x20]
    // 0x65c2d0: r1 = LoadInt32Instr(r0)
    //     0x65c2d0: sbfx            x1, x0, #1, #0x1f
    // 0x65c2d4: mov             x0, x1
    // 0x65c2d8: r1 = 0
    //     0x65c2d8: mov             x1, #0
    // 0x65c2dc: cmp             x1, x0
    // 0x65c2e0: b.hs            #0x65c690
    // 0x65c2e4: LoadField: r0 = r2->field_f
    //     0x65c2e4: ldur            w0, [x2, #0xf]
    // 0x65c2e8: DecompressPointer r0
    //     0x65c2e8: add             x0, x0, HEAP, lsl #32
    // 0x65c2ec: LoadField: r1 = r0->field_f
    //     0x65c2ec: ldur            w1, [x0, #0xf]
    // 0x65c2f0: DecompressPointer r1
    //     0x65c2f0: add             x1, x1, HEAP, lsl #32
    // 0x65c2f4: LoadField: r0 = r1->field_7
    //     0x65c2f4: ldur            w0, [x1, #7]
    // 0x65c2f8: DecompressPointer r0
    //     0x65c2f8: add             x0, x0, HEAP, lsl #32
    // 0x65c2fc: stur            x0, [fp, #-8]
    // 0x65c300: LoadField: d0 = r0->field_7
    //     0x65c300: ldur            d0, [x0, #7]
    // 0x65c304: LoadField: r1 = r3->field_57
    //     0x65c304: ldur            w1, [x3, #0x57]
    // 0x65c308: DecompressPointer r1
    //     0x65c308: add             x1, x1, HEAP, lsl #32
    // 0x65c30c: cmp             w1, NULL
    // 0x65c310: b.eq            #0x65c694
    // 0x65c314: LoadField: d1 = r1->field_7
    //     0x65c314: ldur            d1, [x1, #7]
    // 0x65c318: r1 = inline_Allocate_Double()
    //     0x65c318: ldp             x1, x4, [THR, #0x60]  ; THR::top
    //     0x65c31c: add             x1, x1, #0x10
    //     0x65c320: cmp             x4, x1
    //     0x65c324: b.ls            #0x65c698
    //     0x65c328: str             x1, [THR, #0x60]  ; THR::top
    //     0x65c32c: sub             x1, x1, #0xf
    //     0x65c330: mov             x4, #0xd108
    //     0x65c334: movk            x4, #3, lsl #16
    //     0x65c338: stur            x4, [x1, #-1]
    // 0x65c33c: StoreField: r1->field_7 = d0
    //     0x65c33c: stur            d0, [x1, #7]
    // 0x65c340: r4 = inline_Allocate_Double()
    //     0x65c340: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0x65c344: add             x4, x4, #0x10
    //     0x65c348: cmp             x5, x4
    //     0x65c34c: b.ls            #0x65c6bc
    //     0x65c350: str             x4, [THR, #0x60]  ; THR::top
    //     0x65c354: sub             x4, x4, #0xf
    //     0x65c358: mov             x5, #0xd108
    //     0x65c35c: movk            x5, #3, lsl #16
    //     0x65c360: stur            x5, [x4, #-1]
    // 0x65c364: StoreField: r4->field_7 = d1
    //     0x65c364: stur            d1, [x4, #7]
    // 0x65c368: r16 = 0.000000
    //     0x65c368: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x65c36c: stp             x16, x1, [SP, #-0x10]!
    // 0x65c370: SaveReg r4
    //     0x65c370: str             x4, [SP, #-8]!
    // 0x65c374: r0 = clamp()
    //     0x65c374: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x65c378: add             SP, SP, #0x18
    // 0x65c37c: mov             x1, x0
    // 0x65c380: ldur            x0, [fp, #-8]
    // 0x65c384: stur            x1, [fp, #-0x18]
    // 0x65c388: LoadField: d0 = r0->field_f
    //     0x65c388: ldur            d0, [x0, #0xf]
    // 0x65c38c: ldr             x0, [fp, #0x20]
    // 0x65c390: LoadField: r2 = r0->field_57
    //     0x65c390: ldur            w2, [x0, #0x57]
    // 0x65c394: DecompressPointer r2
    //     0x65c394: add             x2, x2, HEAP, lsl #32
    // 0x65c398: cmp             w2, NULL
    // 0x65c39c: b.eq            #0x65c6e0
    // 0x65c3a0: LoadField: d1 = r2->field_f
    //     0x65c3a0: ldur            d1, [x2, #0xf]
    // 0x65c3a4: r2 = inline_Allocate_Double()
    //     0x65c3a4: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x65c3a8: add             x2, x2, #0x10
    //     0x65c3ac: cmp             x3, x2
    //     0x65c3b0: b.ls            #0x65c6e4
    //     0x65c3b4: str             x2, [THR, #0x60]  ; THR::top
    //     0x65c3b8: sub             x2, x2, #0xf
    //     0x65c3bc: mov             x3, #0xd108
    //     0x65c3c0: movk            x3, #3, lsl #16
    //     0x65c3c4: stur            x3, [x2, #-1]
    // 0x65c3c8: StoreField: r2->field_7 = d0
    //     0x65c3c8: stur            d0, [x2, #7]
    // 0x65c3cc: r3 = inline_Allocate_Double()
    //     0x65c3cc: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x65c3d0: add             x3, x3, #0x10
    //     0x65c3d4: cmp             x4, x3
    //     0x65c3d8: b.ls            #0x65c700
    //     0x65c3dc: str             x3, [THR, #0x60]  ; THR::top
    //     0x65c3e0: sub             x3, x3, #0xf
    //     0x65c3e4: mov             x4, #0xd108
    //     0x65c3e8: movk            x4, #3, lsl #16
    //     0x65c3ec: stur            x4, [x3, #-1]
    // 0x65c3f0: StoreField: r3->field_7 = d1
    //     0x65c3f0: stur            d1, [x3, #7]
    // 0x65c3f4: r16 = 0.000000
    //     0x65c3f4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x65c3f8: stp             x16, x2, [SP, #-0x10]!
    // 0x65c3fc: SaveReg r3
    //     0x65c3fc: str             x3, [SP, #-8]!
    // 0x65c400: r0 = clamp()
    //     0x65c400: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x65c404: add             SP, SP, #0x18
    // 0x65c408: mov             x1, x0
    // 0x65c40c: ldur            x0, [fp, #-0x18]
    // 0x65c410: stur            x1, [fp, #-8]
    // 0x65c414: LoadField: d0 = r0->field_7
    //     0x65c414: ldur            d0, [x0, #7]
    // 0x65c418: stur            d0, [fp, #-0x28]
    // 0x65c41c: r0 = Offset()
    //     0x65c41c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65c420: ldur            d0, [fp, #-0x28]
    // 0x65c424: stur            x0, [fp, #-0x18]
    // 0x65c428: StoreField: r0->field_7 = d0
    //     0x65c428: stur            d0, [x0, #7]
    // 0x65c42c: ldur            x1, [fp, #-8]
    // 0x65c430: LoadField: d0 = r1->field_7
    //     0x65c430: ldur            d0, [x1, #7]
    // 0x65c434: StoreField: r0->field_f = d0
    //     0x65c434: stur            d0, [x0, #0xf]
    // 0x65c438: ldr             x1, [fp, #0x20]
    // 0x65c43c: r17 = 291
    //     0x65c43c: mov             x17, #0x123
    // 0x65c440: ldr             w2, [x1, x17]
    // 0x65c444: DecompressPointer r2
    //     0x65c444: add             x2, x2, HEAP, lsl #32
    // 0x65c448: stur            x2, [fp, #-8]
    // 0x65c44c: r0 = LeaderLayer()
    //     0x65c44c: bl              #0x65c7b0  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0x65c450: mov             x1, x0
    // 0x65c454: ldur            x0, [fp, #-8]
    // 0x65c458: stur            x1, [fp, #-0x20]
    // 0x65c45c: StoreField: r1->field_47 = r0
    //     0x65c45c: stur            w0, [x1, #0x47]
    // 0x65c460: ldur            x0, [fp, #-0x18]
    // 0x65c464: StoreField: r1->field_4b = r0
    //     0x65c464: stur            w0, [x1, #0x4b]
    // 0x65c468: SaveReg r1
    //     0x65c468: str             x1, [SP, #-8]!
    // 0x65c46c: r0 = Layer()
    //     0x65c46c: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x65c470: add             SP, SP, #8
    // 0x65c474: ldr             x16, [fp, #0x18]
    // 0x65c478: ldur            lr, [fp, #-0x20]
    // 0x65c47c: stp             lr, x16, [SP, #-0x10]!
    // 0x65c480: ldr             x16, [fp, #0x10]
    // 0x65c484: r30 = Instance_Offset
    //     0x65c484: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65c488: stp             lr, x16, [SP, #-0x10]!
    // 0x65c48c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x65c48c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x65c490: r0 = pushLayer()
    //     0x65c490: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x65c494: add             SP, SP, #0x20
    // 0x65c498: ldur            x2, [fp, #-0x10]
    // 0x65c49c: LoadField: r0 = r2->field_b
    //     0x65c49c: ldur            w0, [x2, #0xb]
    // 0x65c4a0: DecompressPointer r0
    //     0x65c4a0: add             x0, x0, HEAP, lsl #32
    // 0x65c4a4: cmp             w0, #4
    // 0x65c4a8: b.ne            #0x65c678
    // 0x65c4ac: ldr             x3, [fp, #0x20]
    // 0x65c4b0: r1 = LoadInt32Instr(r0)
    //     0x65c4b0: sbfx            x1, x0, #1, #0x1f
    // 0x65c4b4: mov             x0, x1
    // 0x65c4b8: r1 = 1
    //     0x65c4b8: mov             x1, #1
    // 0x65c4bc: cmp             x1, x0
    // 0x65c4c0: b.hs            #0x65c724
    // 0x65c4c4: LoadField: r0 = r2->field_f
    //     0x65c4c4: ldur            w0, [x2, #0xf]
    // 0x65c4c8: DecompressPointer r0
    //     0x65c4c8: add             x0, x0, HEAP, lsl #32
    // 0x65c4cc: LoadField: r1 = r0->field_13
    //     0x65c4cc: ldur            w1, [x0, #0x13]
    // 0x65c4d0: DecompressPointer r1
    //     0x65c4d0: add             x1, x1, HEAP, lsl #32
    // 0x65c4d4: LoadField: r0 = r1->field_7
    //     0x65c4d4: ldur            w0, [x1, #7]
    // 0x65c4d8: DecompressPointer r0
    //     0x65c4d8: add             x0, x0, HEAP, lsl #32
    // 0x65c4dc: stur            x0, [fp, #-8]
    // 0x65c4e0: LoadField: d0 = r0->field_7
    //     0x65c4e0: ldur            d0, [x0, #7]
    // 0x65c4e4: LoadField: r1 = r3->field_57
    //     0x65c4e4: ldur            w1, [x3, #0x57]
    // 0x65c4e8: DecompressPointer r1
    //     0x65c4e8: add             x1, x1, HEAP, lsl #32
    // 0x65c4ec: cmp             w1, NULL
    // 0x65c4f0: b.eq            #0x65c728
    // 0x65c4f4: LoadField: d1 = r1->field_7
    //     0x65c4f4: ldur            d1, [x1, #7]
    // 0x65c4f8: r1 = inline_Allocate_Double()
    //     0x65c4f8: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x65c4fc: add             x1, x1, #0x10
    //     0x65c500: cmp             x2, x1
    //     0x65c504: b.ls            #0x65c72c
    //     0x65c508: str             x1, [THR, #0x60]  ; THR::top
    //     0x65c50c: sub             x1, x1, #0xf
    //     0x65c510: mov             x2, #0xd108
    //     0x65c514: movk            x2, #3, lsl #16
    //     0x65c518: stur            x2, [x1, #-1]
    // 0x65c51c: StoreField: r1->field_7 = d0
    //     0x65c51c: stur            d0, [x1, #7]
    // 0x65c520: r2 = inline_Allocate_Double()
    //     0x65c520: ldp             x2, x4, [THR, #0x60]  ; THR::top
    //     0x65c524: add             x2, x2, #0x10
    //     0x65c528: cmp             x4, x2
    //     0x65c52c: b.ls            #0x65c748
    //     0x65c530: str             x2, [THR, #0x60]  ; THR::top
    //     0x65c534: sub             x2, x2, #0xf
    //     0x65c538: mov             x4, #0xd108
    //     0x65c53c: movk            x4, #3, lsl #16
    //     0x65c540: stur            x4, [x2, #-1]
    // 0x65c544: StoreField: r2->field_7 = d1
    //     0x65c544: stur            d1, [x2, #7]
    // 0x65c548: r16 = 0.000000
    //     0x65c548: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x65c54c: stp             x16, x1, [SP, #-0x10]!
    // 0x65c550: SaveReg r2
    //     0x65c550: str             x2, [SP, #-8]!
    // 0x65c554: r0 = clamp()
    //     0x65c554: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x65c558: add             SP, SP, #0x18
    // 0x65c55c: mov             x1, x0
    // 0x65c560: ldur            x0, [fp, #-8]
    // 0x65c564: stur            x1, [fp, #-0x10]
    // 0x65c568: LoadField: d0 = r0->field_f
    //     0x65c568: ldur            d0, [x0, #0xf]
    // 0x65c56c: ldr             x0, [fp, #0x20]
    // 0x65c570: LoadField: r2 = r0->field_57
    //     0x65c570: ldur            w2, [x0, #0x57]
    // 0x65c574: DecompressPointer r2
    //     0x65c574: add             x2, x2, HEAP, lsl #32
    // 0x65c578: cmp             w2, NULL
    // 0x65c57c: b.eq            #0x65c76c
    // 0x65c580: LoadField: d1 = r2->field_f
    //     0x65c580: ldur            d1, [x2, #0xf]
    // 0x65c584: r2 = inline_Allocate_Double()
    //     0x65c584: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x65c588: add             x2, x2, #0x10
    //     0x65c58c: cmp             x3, x2
    //     0x65c590: b.ls            #0x65c770
    //     0x65c594: str             x2, [THR, #0x60]  ; THR::top
    //     0x65c598: sub             x2, x2, #0xf
    //     0x65c59c: mov             x3, #0xd108
    //     0x65c5a0: movk            x3, #3, lsl #16
    //     0x65c5a4: stur            x3, [x2, #-1]
    // 0x65c5a8: StoreField: r2->field_7 = d0
    //     0x65c5a8: stur            d0, [x2, #7]
    // 0x65c5ac: r3 = inline_Allocate_Double()
    //     0x65c5ac: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x65c5b0: add             x3, x3, #0x10
    //     0x65c5b4: cmp             x4, x3
    //     0x65c5b8: b.ls            #0x65c78c
    //     0x65c5bc: str             x3, [THR, #0x60]  ; THR::top
    //     0x65c5c0: sub             x3, x3, #0xf
    //     0x65c5c4: mov             x4, #0xd108
    //     0x65c5c8: movk            x4, #3, lsl #16
    //     0x65c5cc: stur            x4, [x3, #-1]
    // 0x65c5d0: StoreField: r3->field_7 = d1
    //     0x65c5d0: stur            d1, [x3, #7]
    // 0x65c5d4: r16 = 0.000000
    //     0x65c5d4: ldr             x16, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x65c5d8: stp             x16, x2, [SP, #-0x10]!
    // 0x65c5dc: SaveReg r3
    //     0x65c5dc: str             x3, [SP, #-8]!
    // 0x65c5e0: r0 = clamp()
    //     0x65c5e0: bl              #0xd66c00  ; [dart:core] _Double::clamp
    // 0x65c5e4: add             SP, SP, #0x18
    // 0x65c5e8: mov             x1, x0
    // 0x65c5ec: ldur            x0, [fp, #-0x10]
    // 0x65c5f0: stur            x1, [fp, #-8]
    // 0x65c5f4: LoadField: d0 = r0->field_7
    //     0x65c5f4: ldur            d0, [x0, #7]
    // 0x65c5f8: stur            d0, [fp, #-0x28]
    // 0x65c5fc: r0 = Offset()
    //     0x65c5fc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65c600: ldur            d0, [fp, #-0x28]
    // 0x65c604: stur            x0, [fp, #-0x10]
    // 0x65c608: StoreField: r0->field_7 = d0
    //     0x65c608: stur            d0, [x0, #7]
    // 0x65c60c: ldur            x1, [fp, #-8]
    // 0x65c610: LoadField: d0 = r1->field_7
    //     0x65c610: ldur            d0, [x1, #7]
    // 0x65c614: StoreField: r0->field_f = d0
    //     0x65c614: stur            d0, [x0, #0xf]
    // 0x65c618: ldr             x1, [fp, #0x20]
    // 0x65c61c: r17 = 295
    //     0x65c61c: mov             x17, #0x127
    // 0x65c620: ldr             w2, [x1, x17]
    // 0x65c624: DecompressPointer r2
    //     0x65c624: add             x2, x2, HEAP, lsl #32
    // 0x65c628: stur            x2, [fp, #-8]
    // 0x65c62c: r0 = LeaderLayer()
    //     0x65c62c: bl              #0x65c7b0  ; AllocateLeaderLayerStub -> LeaderLayer (size=0x50)
    // 0x65c630: mov             x1, x0
    // 0x65c634: ldur            x0, [fp, #-8]
    // 0x65c638: stur            x1, [fp, #-0x18]
    // 0x65c63c: StoreField: r1->field_47 = r0
    //     0x65c63c: stur            w0, [x1, #0x47]
    // 0x65c640: ldur            x0, [fp, #-0x10]
    // 0x65c644: StoreField: r1->field_4b = r0
    //     0x65c644: stur            w0, [x1, #0x4b]
    // 0x65c648: SaveReg r1
    //     0x65c648: str             x1, [SP, #-8]!
    // 0x65c64c: r0 = Layer()
    //     0x65c64c: bl              #0x5bbe7c  ; [package:flutter/src/rendering/layer.dart] Layer::Layer
    // 0x65c650: add             SP, SP, #8
    // 0x65c654: ldr             x16, [fp, #0x18]
    // 0x65c658: ldur            lr, [fp, #-0x18]
    // 0x65c65c: stp             lr, x16, [SP, #-0x10]!
    // 0x65c660: ldr             x16, [fp, #0x10]
    // 0x65c664: r30 = Instance_Offset
    //     0x65c664: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x65c668: stp             lr, x16, [SP, #-0x10]!
    // 0x65c66c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x65c66c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x65c670: r0 = pushLayer()
    //     0x65c670: bl              #0x65bbc8  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushLayer
    // 0x65c674: add             SP, SP, #0x20
    // 0x65c678: r0 = Null
    //     0x65c678: mov             x0, NULL
    // 0x65c67c: LeaveFrame
    //     0x65c67c: mov             SP, fp
    //     0x65c680: ldp             fp, lr, [SP], #0x10
    // 0x65c684: ret
    //     0x65c684: ret             
    // 0x65c688: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65c688: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65c68c: b               #0x65c28c
    // 0x65c690: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x65c690: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x65c694: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65c694: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65c698: stp             q0, q1, [SP, #-0x20]!
    // 0x65c69c: stp             x2, x3, [SP, #-0x10]!
    // 0x65c6a0: SaveReg r0
    //     0x65c6a0: str             x0, [SP, #-8]!
    // 0x65c6a4: r0 = AllocateDouble()
    //     0x65c6a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c6a8: mov             x1, x0
    // 0x65c6ac: RestoreReg r0
    //     0x65c6ac: ldr             x0, [SP], #8
    // 0x65c6b0: ldp             x2, x3, [SP], #0x10
    // 0x65c6b4: ldp             q0, q1, [SP], #0x20
    // 0x65c6b8: b               #0x65c33c
    // 0x65c6bc: SaveReg d1
    //     0x65c6bc: str             q1, [SP, #-0x10]!
    // 0x65c6c0: stp             x2, x3, [SP, #-0x10]!
    // 0x65c6c4: stp             x0, x1, [SP, #-0x10]!
    // 0x65c6c8: r0 = AllocateDouble()
    //     0x65c6c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c6cc: mov             x4, x0
    // 0x65c6d0: ldp             x0, x1, [SP], #0x10
    // 0x65c6d4: ldp             x2, x3, [SP], #0x10
    // 0x65c6d8: RestoreReg d1
    //     0x65c6d8: ldr             q1, [SP], #0x10
    // 0x65c6dc: b               #0x65c364
    // 0x65c6e0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65c6e0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65c6e4: stp             q0, q1, [SP, #-0x20]!
    // 0x65c6e8: stp             x0, x1, [SP, #-0x10]!
    // 0x65c6ec: r0 = AllocateDouble()
    //     0x65c6ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c6f0: mov             x2, x0
    // 0x65c6f4: ldp             x0, x1, [SP], #0x10
    // 0x65c6f8: ldp             q0, q1, [SP], #0x20
    // 0x65c6fc: b               #0x65c3c8
    // 0x65c700: SaveReg d1
    //     0x65c700: str             q1, [SP, #-0x10]!
    // 0x65c704: stp             x1, x2, [SP, #-0x10]!
    // 0x65c708: SaveReg r0
    //     0x65c708: str             x0, [SP, #-8]!
    // 0x65c70c: r0 = AllocateDouble()
    //     0x65c70c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c710: mov             x3, x0
    // 0x65c714: RestoreReg r0
    //     0x65c714: ldr             x0, [SP], #8
    // 0x65c718: ldp             x1, x2, [SP], #0x10
    // 0x65c71c: RestoreReg d1
    //     0x65c71c: ldr             q1, [SP], #0x10
    // 0x65c720: b               #0x65c3f0
    // 0x65c724: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x65c724: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x65c728: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65c728: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65c72c: stp             q0, q1, [SP, #-0x20]!
    // 0x65c730: stp             x0, x3, [SP, #-0x10]!
    // 0x65c734: r0 = AllocateDouble()
    //     0x65c734: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c738: mov             x1, x0
    // 0x65c73c: ldp             x0, x3, [SP], #0x10
    // 0x65c740: ldp             q0, q1, [SP], #0x20
    // 0x65c744: b               #0x65c51c
    // 0x65c748: SaveReg d1
    //     0x65c748: str             q1, [SP, #-0x10]!
    // 0x65c74c: stp             x1, x3, [SP, #-0x10]!
    // 0x65c750: SaveReg r0
    //     0x65c750: str             x0, [SP, #-8]!
    // 0x65c754: r0 = AllocateDouble()
    //     0x65c754: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c758: mov             x2, x0
    // 0x65c75c: RestoreReg r0
    //     0x65c75c: ldr             x0, [SP], #8
    // 0x65c760: ldp             x1, x3, [SP], #0x10
    // 0x65c764: RestoreReg d1
    //     0x65c764: ldr             q1, [SP], #0x10
    // 0x65c768: b               #0x65c544
    // 0x65c76c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65c76c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65c770: stp             q0, q1, [SP, #-0x20]!
    // 0x65c774: stp             x0, x1, [SP, #-0x10]!
    // 0x65c778: r0 = AllocateDouble()
    //     0x65c778: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c77c: mov             x2, x0
    // 0x65c780: ldp             x0, x1, [SP], #0x10
    // 0x65c784: ldp             q0, q1, [SP], #0x20
    // 0x65c788: b               #0x65c5a8
    // 0x65c78c: SaveReg d1
    //     0x65c78c: str             q1, [SP, #-0x10]!
    // 0x65c790: stp             x1, x2, [SP, #-0x10]!
    // 0x65c794: SaveReg r0
    //     0x65c794: str             x0, [SP, #-8]!
    // 0x65c798: r0 = AllocateDouble()
    //     0x65c798: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x65c79c: mov             x3, x0
    // 0x65c7a0: RestoreReg r0
    //     0x65c7a0: ldr             x0, [SP], #8
    // 0x65c7a4: ldp             x1, x2, [SP], #0x10
    // 0x65c7a8: RestoreReg d1
    //     0x65c7a8: ldr             q1, [SP], #0x10
    // 0x65c7ac: b               #0x65c5d0
  }
  _ getActualSelection(/* No info */) {
    // ** addr: 0x6de46c, size: 0x140
    // 0x6de46c: EnterFrame
    //     0x6de46c: stp             fp, lr, [SP, #-0x10]!
    //     0x6de470: mov             fp, SP
    // 0x6de474: AllocStack(0x18)
    //     0x6de474: sub             SP, SP, #0x18
    // 0x6de478: SetupParameters(ExtendedTextSelectionRenderObject this /* r3, fp-0x18 */, {dynamic newRange = Null /* r0 */})
    //     0x6de478: mov             x0, x4
    //     0x6de47c: ldur            w1, [x0, #0x13]
    //     0x6de480: add             x1, x1, HEAP, lsl #32
    //     0x6de484: sub             x2, x1, #2
    //     0x6de488: add             x3, fp, w2, sxtw #2
    //     0x6de48c: ldr             x3, [x3, #0x10]
    //     0x6de490: stur            x3, [fp, #-0x18]
    //     0x6de494: ldur            w2, [x0, #0x1f]
    //     0x6de498: add             x2, x2, HEAP, lsl #32
    //     0x6de49c: add             x16, PP, #0x55, lsl #12  ; [pp+0x55af8] "newRange"
    //     0x6de4a0: ldr             x16, [x16, #0xaf8]
    //     0x6de4a4: cmp             w2, w16
    //     0x6de4a8: b.ne            #0x6de4c8
    //     0x6de4ac: ldur            w2, [x0, #0x23]
    //     0x6de4b0: add             x2, x2, HEAP, lsl #32
    //     0x6de4b4: sub             w0, w1, w2
    //     0x6de4b8: add             x1, fp, w0, sxtw #2
    //     0x6de4bc: ldr             x1, [x1, #8]
    //     0x6de4c0: mov             x0, x1
    //     0x6de4c4: b               #0x6de4cc
    //     0x6de4c8: mov             x0, NULL
    // 0x6de4cc: CheckStackOverflow
    //     0x6de4cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de4d0: cmp             SP, x16
    //     0x6de4d4: b.ls            #0x6de5a0
    // 0x6de4d8: r17 = 271
    //     0x6de4d8: mov             x17, #0x10f
    // 0x6de4dc: ldr             w1, [x3, x17]
    // 0x6de4e0: DecompressPointer r1
    //     0x6de4e0: add             x1, x1, HEAP, lsl #32
    // 0x6de4e4: cmp             w0, NULL
    // 0x6de4e8: b.eq            #0x6de54c
    // 0x6de4ec: LoadField: r1 = r0->field_7
    //     0x6de4ec: ldur            x1, [x0, #7]
    // 0x6de4f0: stur            x1, [fp, #-0x10]
    // 0x6de4f4: LoadField: r2 = r0->field_f
    //     0x6de4f4: ldur            x2, [x0, #0xf]
    // 0x6de4f8: stur            x2, [fp, #-8]
    // 0x6de4fc: r0 = TextSelection()
    //     0x6de4fc: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x6de500: mov             x1, x0
    // 0x6de504: ldur            x0, [fp, #-0x10]
    // 0x6de508: StoreField: r1->field_17 = r0
    //     0x6de508: stur            x0, [x1, #0x17]
    // 0x6de50c: ldur            x2, [fp, #-8]
    // 0x6de510: StoreField: r1->field_1f = r2
    //     0x6de510: stur            x2, [x1, #0x1f]
    // 0x6de514: r3 = Instance_TextAffinity
    //     0x6de514: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x6de518: StoreField: r1->field_27 = r3
    //     0x6de518: stur            w3, [x1, #0x27]
    // 0x6de51c: r3 = false
    //     0x6de51c: add             x3, NULL, #0x30  ; false
    // 0x6de520: StoreField: r1->field_2b = r3
    //     0x6de520: stur            w3, [x1, #0x2b]
    // 0x6de524: cmp             x0, x2
    // 0x6de528: b.ge            #0x6de534
    // 0x6de52c: mov             x3, x0
    // 0x6de530: b               #0x6de538
    // 0x6de534: mov             x3, x2
    // 0x6de538: cmp             x0, x2
    // 0x6de53c: b.ge            #0x6de544
    // 0x6de540: mov             x0, x2
    // 0x6de544: StoreField: r1->field_7 = r3
    //     0x6de544: stur            x3, [x1, #7]
    // 0x6de548: StoreField: r1->field_f = r0
    //     0x6de548: stur            x0, [x1, #0xf]
    // 0x6de54c: ldur            x0, [fp, #-0x18]
    // 0x6de550: LoadField: r2 = r0->field_97
    //     0x6de550: ldur            w2, [x0, #0x97]
    // 0x6de554: DecompressPointer r2
    //     0x6de554: add             x2, x2, HEAP, lsl #32
    // 0x6de558: tbnz            w2, #4, #0x6de590
    // 0x6de55c: LoadField: r2 = r0->field_77
    //     0x6de55c: ldur            w2, [x0, #0x77]
    // 0x6de560: DecompressPointer r2
    //     0x6de560: add             x2, x2, HEAP, lsl #32
    // 0x6de564: tbnz            w2, #4, #0x6de590
    // 0x6de568: LoadField: r2 = r0->field_eb
    //     0x6de568: ldur            w2, [x0, #0xeb]
    // 0x6de56c: DecompressPointer r2
    //     0x6de56c: add             x2, x2, HEAP, lsl #32
    // 0x6de570: LoadField: r0 = r2->field_f
    //     0x6de570: ldur            w0, [x2, #0xf]
    // 0x6de574: DecompressPointer r0
    //     0x6de574: add             x0, x0, HEAP, lsl #32
    // 0x6de578: cmp             w0, NULL
    // 0x6de57c: b.eq            #0x6de5a8
    // 0x6de580: stp             x1, x0, [SP, #-0x10]!
    // 0x6de584: r0 = convertTextInputSelectionToTextPainterSelection()
    //     0x6de584: bl              #0x522478  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextInputSelectionToTextPainterSelection
    // 0x6de588: add             SP, SP, #0x10
    // 0x6de58c: b               #0x6de594
    // 0x6de590: mov             x0, x1
    // 0x6de594: LeaveFrame
    //     0x6de594: mov             SP, fp
    //     0x6de598: ldp             fp, lr, [SP], #0x10
    // 0x6de59c: ret
    //     0x6de59c: ret             
    // 0x6de5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de5a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de5a4: b               #0x6de4d8
    // 0x6de5a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6de5a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  set _ hasFocus=(/* No info */) {
    // ** addr: 0x6df984, size: 0x64
    // 0x6df984: EnterFrame
    //     0x6df984: stp             fp, lr, [SP, #-0x10]!
    //     0x6df988: mov             fp, SP
    // 0x6df98c: CheckStackOverflow
    //     0x6df98c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df990: cmp             SP, x16
    //     0x6df994: b.ls            #0x6df9e0
    // 0x6df998: ldr             x0, [fp, #0x18]
    // 0x6df99c: LoadField: r1 = r0->field_93
    //     0x6df99c: ldur            w1, [x0, #0x93]
    // 0x6df9a0: DecompressPointer r1
    //     0x6df9a0: add             x1, x1, HEAP, lsl #32
    // 0x6df9a4: ldr             x2, [fp, #0x10]
    // 0x6df9a8: cmp             w1, w2
    // 0x6df9ac: b.ne            #0x6df9c0
    // 0x6df9b0: r0 = Null
    //     0x6df9b0: mov             x0, NULL
    // 0x6df9b4: LeaveFrame
    //     0x6df9b4: mov             SP, fp
    //     0x6df9b8: ldp             fp, lr, [SP], #0x10
    // 0x6df9bc: ret
    //     0x6df9bc: ret             
    // 0x6df9c0: StoreField: r0->field_93 = r2
    //     0x6df9c0: stur            w2, [x0, #0x93]
    // 0x6df9c4: SaveReg r0
    //     0x6df9c4: str             x0, [SP, #-8]!
    // 0x6df9c8: r0 = markNeedsSemanticsUpdate()
    //     0x6df9c8: bl              #0x50f8f4  ; [package:flutter/src/rendering/object.dart] RenderObject::markNeedsSemanticsUpdate
    // 0x6df9cc: add             SP, SP, #8
    // 0x6df9d0: r0 = Null
    //     0x6df9d0: mov             x0, NULL
    // 0x6df9d4: LeaveFrame
    //     0x6df9d4: mov             SP, fp
    //     0x6df9d8: ldp             fp, lr, [SP], #0x10
    // 0x6df9dc: ret
    //     0x6df9dc: ret             
    // 0x6df9e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df9e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df9e4: b               #0x6df998
  }
  _ getBoxesForSelectionRects(/* No info */) {
    // ** addr: 0x7a5824, size: 0xb0
    // 0x7a5824: EnterFrame
    //     0x7a5824: stp             fp, lr, [SP, #-0x10]!
    //     0x7a5828: mov             fp, SP
    // 0x7a582c: AllocStack(0x8)
    //     0x7a582c: sub             SP, SP, #8
    // 0x7a5830: CheckStackOverflow
    //     0x7a5830: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a5834: cmp             SP, x16
    //     0x7a5838: b.ls            #0x7a58cc
    // 0x7a583c: r1 = 1
    //     0x7a583c: mov             x1, #1
    // 0x7a5840: r0 = AllocateContext()
    //     0x7a5840: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a5844: mov             x1, x0
    // 0x7a5848: ldr             x0, [fp, #0x18]
    // 0x7a584c: stur            x1, [fp, #-8]
    // 0x7a5850: StoreField: r1->field_f = r0
    //     0x7a5850: stur            w0, [x1, #0xf]
    // 0x7a5854: SaveReg r0
    //     0x7a5854: str             x0, [SP, #-8]!
    // 0x7a5858: r0 = _computeTextMetricsIfNeeded()
    //     0x7a5858: bl              #0x52491c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_computeTextMetricsIfNeeded
    // 0x7a585c: add             SP, SP, #8
    // 0x7a5860: ldr             x0, [fp, #0x18]
    // 0x7a5864: LoadField: r1 = r0->field_eb
    //     0x7a5864: ldur            w1, [x0, #0xeb]
    // 0x7a5868: DecompressPointer r1
    //     0x7a5868: add             x1, x1, HEAP, lsl #32
    // 0x7a586c: ldr             x16, [fp, #0x10]
    // 0x7a5870: stp             x16, x1, [SP, #-0x10]!
    // 0x7a5874: r0 = getBoxesForSelection()
    //     0x7a5874: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x7a5878: add             SP, SP, #0x10
    // 0x7a587c: ldur            x2, [fp, #-8]
    // 0x7a5880: r1 = Function '<anonymous closure>':.
    //     0x7a5880: add             x1, PP, #0x37, lsl #12  ; [pp+0x37650] AnonymousClosure: (0x7a58d4), in [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::getBoxesForSelectionRects (0x7a5824)
    //     0x7a5884: ldr             x1, [x1, #0x650]
    // 0x7a5888: stur            x0, [fp, #-8]
    // 0x7a588c: r0 = AllocateClosure()
    //     0x7a588c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a5890: r16 = <Rect>
    //     0x7a5890: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f8e8] TypeArguments: <Rect>
    //     0x7a5894: ldr             x16, [x16, #0x8e8]
    // 0x7a5898: ldur            lr, [fp, #-8]
    // 0x7a589c: stp             lr, x16, [SP, #-0x10]!
    // 0x7a58a0: SaveReg r0
    //     0x7a58a0: str             x0, [SP, #-8]!
    // 0x7a58a4: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x7a58a4: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x7a58a8: r0 = map()
    //     0x7a58a8: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x7a58ac: add             SP, SP, #0x18
    // 0x7a58b0: SaveReg r0
    //     0x7a58b0: str             x0, [SP, #-8]!
    // 0x7a58b4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7a58b4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7a58b8: r0 = toList()
    //     0x7a58b8: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x7a58bc: add             SP, SP, #8
    // 0x7a58c0: LeaveFrame
    //     0x7a58c0: mov             SP, fp
    //     0x7a58c4: ldp             fp, lr, [SP], #0x10
    // 0x7a58c8: ret
    //     0x7a58c8: ret             
    // 0x7a58cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a58cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a58d0: b               #0x7a583c
  }
  [closure] Rect <anonymous closure>(dynamic, TextBox) {
    // ** addr: 0x7a58d4, size: 0x7c
    // 0x7a58d4: EnterFrame
    //     0x7a58d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7a58d8: mov             fp, SP
    // 0x7a58dc: AllocStack(0x10)
    //     0x7a58dc: sub             SP, SP, #0x10
    // 0x7a58e0: SetupParameters()
    //     0x7a58e0: ldr             x0, [fp, #0x18]
    //     0x7a58e4: ldur            w1, [x0, #0x17]
    //     0x7a58e8: add             x1, x1, HEAP, lsl #32
    //     0x7a58ec: stur            x1, [fp, #-8]
    // 0x7a58f0: CheckStackOverflow
    //     0x7a58f0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a58f4: cmp             SP, x16
    //     0x7a58f8: b.ls            #0x7a5948
    // 0x7a58fc: ldr             x16, [fp, #0x10]
    // 0x7a5900: SaveReg r16
    //     0x7a5900: str             x16, [SP, #-8]!
    // 0x7a5904: r0 = toRect()
    //     0x7a5904: bl              #0x52231c  ; [dart:ui] TextBox::toRect
    // 0x7a5908: add             SP, SP, #8
    // 0x7a590c: mov             x1, x0
    // 0x7a5910: ldur            x0, [fp, #-8]
    // 0x7a5914: stur            x1, [fp, #-0x10]
    // 0x7a5918: LoadField: r2 = r0->field_f
    //     0x7a5918: ldur            w2, [x0, #0xf]
    // 0x7a591c: DecompressPointer r2
    //     0x7a591c: add             x2, x2, HEAP, lsl #32
    // 0x7a5920: SaveReg r2
    //     0x7a5920: str             x2, [SP, #-8]!
    // 0x7a5924: r0 = paintOffset()
    //     0x7a5924: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x7a5928: add             SP, SP, #8
    // 0x7a592c: ldur            x16, [fp, #-0x10]
    // 0x7a5930: stp             x0, x16, [SP, #-0x10]!
    // 0x7a5934: r0 = shift()
    //     0x7a5934: bl              #0x51a0bc  ; [dart:ui] Rect::shift
    // 0x7a5938: add             SP, SP, #0x10
    // 0x7a593c: LeaveFrame
    //     0x7a593c: mov             SP, fp
    //     0x7a5940: ldp             fp, lr, [SP], #0x10
    // 0x7a5944: ret
    //     0x7a5944: ret             
    // 0x7a5948: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a5948: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a594c: b               #0x7a58fc
  }
  _ selectPositionAt(/* No info */) {
    // ** addr: 0x839a30, size: 0x3b8
    // 0x839a30: EnterFrame
    //     0x839a30: stp             fp, lr, [SP, #-0x10]!
    //     0x839a34: mov             fp, SP
    // 0x839a38: AllocStack(0x40)
    //     0x839a38: sub             SP, SP, #0x40
    // 0x839a3c: SetupParameters(ExtendedTextSelectionRenderObject this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, {dynamic to = Null /* r6, fp-0x10 */})
    //     0x839a3c: mov             x0, x4
    //     0x839a40: ldur            w1, [x0, #0x13]
    //     0x839a44: add             x1, x1, HEAP, lsl #32
    //     0x839a48: sub             x2, x1, #6
    //     0x839a4c: add             x3, fp, w2, sxtw #2
    //     0x839a50: ldr             x3, [x3, #0x20]
    //     0x839a54: stur            x3, [fp, #-0x28]
    //     0x839a58: add             x4, fp, w2, sxtw #2
    //     0x839a5c: ldr             x4, [x4, #0x18]
    //     0x839a60: stur            x4, [fp, #-0x20]
    //     0x839a64: add             x5, fp, w2, sxtw #2
    //     0x839a68: ldr             x5, [x5, #0x10]
    //     0x839a6c: stur            x5, [fp, #-0x18]
    //     0x839a70: ldur            w2, [x0, #0x1f]
    //     0x839a74: add             x2, x2, HEAP, lsl #32
    //     0x839a78: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c688] "to"
    //     0x839a7c: ldr             x16, [x16, #0x688]
    //     0x839a80: cmp             w2, w16
    //     0x839a84: b.ne            #0x839aa4
    //     0x839a88: ldur            w2, [x0, #0x23]
    //     0x839a8c: add             x2, x2, HEAP, lsl #32
    //     0x839a90: sub             w0, w1, w2
    //     0x839a94: add             x1, fp, w0, sxtw #2
    //     0x839a98: ldr             x1, [x1, #8]
    //     0x839a9c: mov             x6, x1
    //     0x839aa0: b               #0x839aa8
    //     0x839aa4: mov             x6, NULL
    //     0x839aa8: stur            x6, [fp, #-0x10]
    // 0x839aac: CheckStackOverflow
    //     0x839aac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x839ab0: cmp             SP, x16
    //     0x839ab4: b.ls            #0x839dac
    // 0x839ab8: LoadField: r7 = r3->field_27
    //     0x839ab8: ldur            w7, [x3, #0x27]
    // 0x839abc: DecompressPointer r7
    //     0x839abc: add             x7, x7, HEAP, lsl #32
    // 0x839ac0: stur            x7, [fp, #-8]
    // 0x839ac4: cmp             w7, NULL
    // 0x839ac8: b.eq            #0x839d8c
    // 0x839acc: mov             x0, x7
    // 0x839ad0: r2 = Null
    //     0x839ad0: mov             x2, NULL
    // 0x839ad4: r1 = Null
    //     0x839ad4: mov             x1, NULL
    // 0x839ad8: r4 = LoadClassIdInstr(r0)
    //     0x839ad8: ldur            x4, [x0, #-1]
    //     0x839adc: ubfx            x4, x4, #0xc, #0x14
    // 0x839ae0: sub             x4, x4, #0x80d
    // 0x839ae4: cmp             x4, #1
    // 0x839ae8: b.ls            #0x839b00
    // 0x839aec: r8 = BoxConstraints
    //     0x839aec: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x839af0: ldr             x8, [x8, #0x1d0]
    // 0x839af4: r3 = Null
    //     0x839af4: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bdc0] Null
    //     0x839af8: ldr             x3, [x3, #0xdc0]
    // 0x839afc: r0 = BoxConstraints()
    //     0x839afc: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x839b00: ldur            x0, [fp, #-8]
    // 0x839b04: LoadField: d0 = r0->field_7
    //     0x839b04: ldur            d0, [x0, #7]
    // 0x839b08: LoadField: d1 = r0->field_f
    //     0x839b08: ldur            d1, [x0, #0xf]
    // 0x839b0c: r0 = inline_Allocate_Double()
    //     0x839b0c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x839b10: add             x0, x0, #0x10
    //     0x839b14: cmp             x1, x0
    //     0x839b18: b.ls            #0x839db4
    //     0x839b1c: str             x0, [THR, #0x60]  ; THR::top
    //     0x839b20: sub             x0, x0, #0xf
    //     0x839b24: mov             x1, #0xd108
    //     0x839b28: movk            x1, #3, lsl #16
    //     0x839b2c: stur            x1, [x0, #-1]
    // 0x839b30: StoreField: r0->field_7 = d0
    //     0x839b30: stur            d0, [x0, #7]
    // 0x839b34: r1 = inline_Allocate_Double()
    //     0x839b34: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x839b38: add             x1, x1, #0x10
    //     0x839b3c: cmp             x2, x1
    //     0x839b40: b.ls            #0x839dc4
    //     0x839b44: str             x1, [THR, #0x60]  ; THR::top
    //     0x839b48: sub             x1, x1, #0xf
    //     0x839b4c: mov             x2, #0xd108
    //     0x839b50: movk            x2, #3, lsl #16
    //     0x839b54: stur            x2, [x1, #-1]
    // 0x839b58: StoreField: r1->field_7 = d1
    //     0x839b58: stur            d1, [x1, #7]
    // 0x839b5c: ldur            x16, [fp, #-0x28]
    // 0x839b60: stp             x0, x16, [SP, #-0x10]!
    // 0x839b64: SaveReg r1
    //     0x839b64: str             x1, [SP, #-8]!
    // 0x839b68: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x839b68: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x839b6c: ldr             x4, [x4, #0x588]
    // 0x839b70: r0 = layoutText()
    //     0x839b70: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x839b74: add             SP, SP, #0x18
    // 0x839b78: ldur            x0, [fp, #-0x28]
    // 0x839b7c: LoadField: r1 = r0->field_eb
    //     0x839b7c: ldur            w1, [x0, #0xeb]
    // 0x839b80: DecompressPointer r1
    //     0x839b80: add             x1, x1, HEAP, lsl #32
    // 0x839b84: stur            x1, [fp, #-8]
    // 0x839b88: SaveReg r0
    //     0x839b88: str             x0, [SP, #-8]!
    // 0x839b8c: r0 = paintOffset()
    //     0x839b8c: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x839b90: add             SP, SP, #8
    // 0x839b94: ldur            x16, [fp, #-0x18]
    // 0x839b98: stp             x0, x16, [SP, #-0x10]!
    // 0x839b9c: r0 = -()
    //     0x839b9c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x839ba0: add             SP, SP, #0x10
    // 0x839ba4: ldur            x16, [fp, #-0x28]
    // 0x839ba8: stp             x0, x16, [SP, #-0x10]!
    // 0x839bac: r0 = globalToLocal()
    //     0x839bac: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x839bb0: add             SP, SP, #0x10
    // 0x839bb4: ldur            x16, [fp, #-8]
    // 0x839bb8: stp             x0, x16, [SP, #-0x10]!
    // 0x839bbc: r0 = getPositionForOffset()
    //     0x839bbc: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x839bc0: add             SP, SP, #0x10
    // 0x839bc4: mov             x1, x0
    // 0x839bc8: ldur            x0, [fp, #-0x10]
    // 0x839bcc: stur            x1, [fp, #-0x18]
    // 0x839bd0: cmp             w0, NULL
    // 0x839bd4: b.ne            #0x839be0
    // 0x839bd8: r1 = Null
    //     0x839bd8: mov             x1, NULL
    // 0x839bdc: b               #0x839c24
    // 0x839be0: ldur            x16, [fp, #-0x28]
    // 0x839be4: SaveReg r16
    //     0x839be4: str             x16, [SP, #-8]!
    // 0x839be8: r0 = paintOffset()
    //     0x839be8: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x839bec: add             SP, SP, #8
    // 0x839bf0: ldur            x16, [fp, #-0x10]
    // 0x839bf4: stp             x0, x16, [SP, #-0x10]!
    // 0x839bf8: r0 = -()
    //     0x839bf8: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x839bfc: add             SP, SP, #0x10
    // 0x839c00: ldur            x16, [fp, #-0x28]
    // 0x839c04: stp             x0, x16, [SP, #-0x10]!
    // 0x839c08: r0 = globalToLocal()
    //     0x839c08: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x839c0c: add             SP, SP, #0x10
    // 0x839c10: ldur            x16, [fp, #-8]
    // 0x839c14: stp             x0, x16, [SP, #-0x10]!
    // 0x839c18: r0 = getPositionForOffset()
    //     0x839c18: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x839c1c: add             SP, SP, #0x10
    // 0x839c20: mov             x1, x0
    // 0x839c24: ldur            x0, [fp, #-0x28]
    // 0x839c28: stur            x1, [fp, #-0x10]
    // 0x839c2c: LoadField: r2 = r0->field_97
    //     0x839c2c: ldur            w2, [x0, #0x97]
    // 0x839c30: DecompressPointer r2
    //     0x839c30: add             x2, x2, HEAP, lsl #32
    // 0x839c34: tbnz            w2, #4, #0x839ca4
    // 0x839c38: LoadField: r2 = r0->field_77
    //     0x839c38: ldur            w2, [x0, #0x77]
    // 0x839c3c: DecompressPointer r2
    //     0x839c3c: add             x2, x2, HEAP, lsl #32
    // 0x839c40: tbnz            w2, #4, #0x839ca4
    // 0x839c44: ldur            x2, [fp, #-8]
    // 0x839c48: LoadField: r3 = r2->field_f
    //     0x839c48: ldur            w3, [x2, #0xf]
    // 0x839c4c: DecompressPointer r3
    //     0x839c4c: add             x3, x3, HEAP, lsl #32
    // 0x839c50: cmp             w3, NULL
    // 0x839c54: b.eq            #0x839de0
    // 0x839c58: ldur            x16, [fp, #-0x18]
    // 0x839c5c: stp             x16, x3, [SP, #-0x10]!
    // 0x839c60: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x839c60: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x839c64: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x839c64: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x839c68: add             SP, SP, #0x10
    // 0x839c6c: mov             x1, x0
    // 0x839c70: ldur            x0, [fp, #-8]
    // 0x839c74: stur            x1, [fp, #-0x30]
    // 0x839c78: LoadField: r2 = r0->field_f
    //     0x839c78: ldur            w2, [x0, #0xf]
    // 0x839c7c: DecompressPointer r2
    //     0x839c7c: add             x2, x2, HEAP, lsl #32
    // 0x839c80: cmp             w2, NULL
    // 0x839c84: b.eq            #0x839de4
    // 0x839c88: ldur            x16, [fp, #-0x10]
    // 0x839c8c: stp             x16, x2, [SP, #-0x10]!
    // 0x839c90: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x839c90: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x839c94: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x839c94: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x839c98: add             SP, SP, #0x10
    // 0x839c9c: ldur            x2, [fp, #-0x30]
    // 0x839ca0: b               #0x839cac
    // 0x839ca4: ldur            x2, [fp, #-0x18]
    // 0x839ca8: ldur            x0, [fp, #-0x10]
    // 0x839cac: LoadField: r3 = r2->field_7
    //     0x839cac: ldur            x3, [x2, #7]
    // 0x839cb0: stur            x3, [fp, #-0x40]
    // 0x839cb4: cmp             w0, NULL
    // 0x839cb8: b.ne            #0x839cc4
    // 0x839cbc: r0 = Null
    //     0x839cbc: mov             x0, NULL
    // 0x839cc0: b               #0x839cdc
    // 0x839cc4: LoadField: r4 = r0->field_7
    //     0x839cc4: ldur            x4, [x0, #7]
    // 0x839cc8: r0 = BoxInt64Instr(r4)
    //     0x839cc8: sbfiz           x0, x4, #1, #0x1f
    //     0x839ccc: cmp             x4, x0, asr #1
    //     0x839cd0: b.eq            #0x839cdc
    //     0x839cd4: bl              #0xd69bb8
    //     0x839cd8: stur            x4, [x0, #7]
    // 0x839cdc: cmp             w0, NULL
    // 0x839ce0: b.ne            #0x839cec
    // 0x839ce4: mov             x0, x3
    // 0x839ce8: b               #0x839cfc
    // 0x839cec: r1 = LoadInt32Instr(r0)
    //     0x839cec: sbfx            x1, x0, #1, #0x1f
    //     0x839cf0: tbz             w0, #0, #0x839cf8
    //     0x839cf4: ldur            x1, [x0, #7]
    // 0x839cf8: mov             x0, x1
    // 0x839cfc: stur            x0, [fp, #-0x38]
    // 0x839d00: LoadField: r1 = r2->field_f
    //     0x839d00: ldur            w1, [x2, #0xf]
    // 0x839d04: DecompressPointer r1
    //     0x839d04: add             x1, x1, HEAP, lsl #32
    // 0x839d08: stur            x1, [fp, #-8]
    // 0x839d0c: r0 = TextSelection()
    //     0x839d0c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x839d10: mov             x1, x0
    // 0x839d14: ldur            x0, [fp, #-0x40]
    // 0x839d18: StoreField: r1->field_17 = r0
    //     0x839d18: stur            x0, [x1, #0x17]
    // 0x839d1c: ldur            x2, [fp, #-0x38]
    // 0x839d20: StoreField: r1->field_1f = r2
    //     0x839d20: stur            x2, [x1, #0x1f]
    // 0x839d24: ldur            x3, [fp, #-8]
    // 0x839d28: StoreField: r1->field_27 = r3
    //     0x839d28: stur            w3, [x1, #0x27]
    // 0x839d2c: r3 = false
    //     0x839d2c: add             x3, NULL, #0x30  ; false
    // 0x839d30: StoreField: r1->field_2b = r3
    //     0x839d30: stur            w3, [x1, #0x2b]
    // 0x839d34: cmp             x0, x2
    // 0x839d38: r16 = true
    //     0x839d38: add             x16, NULL, #0x20  ; true
    // 0x839d3c: r17 = false
    //     0x839d3c: add             x17, NULL, #0x30  ; false
    // 0x839d40: csel            x3, x16, x17, lt
    // 0x839d44: tbnz            w3, #4, #0x839d50
    // 0x839d48: mov             x4, x0
    // 0x839d4c: b               #0x839d54
    // 0x839d50: mov             x4, x2
    // 0x839d54: tbnz            w3, #4, #0x839d5c
    // 0x839d58: mov             x0, x2
    // 0x839d5c: StoreField: r1->field_7 = r4
    //     0x839d5c: stur            x4, [x1, #7]
    // 0x839d60: StoreField: r1->field_f = r0
    //     0x839d60: stur            x0, [x1, #0xf]
    // 0x839d64: ldur            x16, [fp, #-0x28]
    // 0x839d68: stp             x1, x16, [SP, #-0x10]!
    // 0x839d6c: ldur            x16, [fp, #-0x20]
    // 0x839d70: SaveReg r16
    //     0x839d70: str             x16, [SP, #-8]!
    // 0x839d74: r0 = setSelection()
    //     0x839d74: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0x839d78: add             SP, SP, #0x18
    // 0x839d7c: r0 = Null
    //     0x839d7c: mov             x0, NULL
    // 0x839d80: LeaveFrame
    //     0x839d80: mov             SP, fp
    //     0x839d84: ldp             fp, lr, [SP], #0x10
    // 0x839d88: ret
    //     0x839d88: ret             
    // 0x839d8c: r0 = StateError()
    //     0x839d8c: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x839d90: mov             x1, x0
    // 0x839d94: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x839d94: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x839d98: ldr             x0, [x0, #0x1e8]
    // 0x839d9c: StoreField: r1->field_b = r0
    //     0x839d9c: stur            w0, [x1, #0xb]
    // 0x839da0: mov             x0, x1
    // 0x839da4: r0 = Throw()
    //     0x839da4: bl              #0xd67e38  ; ThrowStub
    // 0x839da8: brk             #0
    // 0x839dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839dac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839db0: b               #0x839ab8
    // 0x839db4: stp             q0, q1, [SP, #-0x20]!
    // 0x839db8: r0 = AllocateDouble()
    //     0x839db8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x839dbc: ldp             q0, q1, [SP], #0x20
    // 0x839dc0: b               #0x839b30
    // 0x839dc4: SaveReg d1
    //     0x839dc4: str             q1, [SP, #-0x10]!
    // 0x839dc8: SaveReg r0
    //     0x839dc8: str             x0, [SP, #-8]!
    // 0x839dcc: r0 = AllocateDouble()
    //     0x839dcc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x839dd0: mov             x1, x0
    // 0x839dd4: RestoreReg r0
    //     0x839dd4: ldr             x0, [SP], #8
    // 0x839dd8: RestoreReg d1
    //     0x839dd8: ldr             q1, [SP], #0x10
    // 0x839ddc: b               #0x839b58
    // 0x839de0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839de0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839de4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839de4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setSelection(/* No info */) {
    // ** addr: 0x839de8, size: 0x178
    // 0x839de8: EnterFrame
    //     0x839de8: stp             fp, lr, [SP, #-0x10]!
    //     0x839dec: mov             fp, SP
    // 0x839df0: CheckStackOverflow
    //     0x839df0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x839df4: cmp             SP, x16
    //     0x839df8: b.ls            #0x839f50
    // 0x839dfc: ldr             x2, [fp, #0x18]
    // 0x839e00: LoadField: r0 = r2->field_7
    //     0x839e00: ldur            x0, [x2, #7]
    // 0x839e04: tbnz            x0, #0x3f, #0x839ee4
    // 0x839e08: LoadField: r0 = r2->field_f
    //     0x839e08: ldur            x0, [x2, #0xf]
    // 0x839e0c: tbnz            x0, #0x3f, #0x839ee4
    // 0x839e10: ldr             x3, [fp, #0x20]
    // 0x839e14: LoadField: r0 = r3->field_db
    //     0x839e14: ldur            w0, [x3, #0xdb]
    // 0x839e18: DecompressPointer r0
    //     0x839e18: add             x0, x0, HEAP, lsl #32
    // 0x839e1c: LoadField: r1 = r0->field_b
    //     0x839e1c: ldur            w1, [x0, #0xb]
    // 0x839e20: DecompressPointer r1
    //     0x839e20: add             x1, x1, HEAP, lsl #32
    // 0x839e24: cmp             w1, NULL
    // 0x839e28: b.eq            #0x839f58
    // 0x839e2c: LoadField: r0 = r1->field_13
    //     0x839e2c: ldur            w0, [x1, #0x13]
    // 0x839e30: DecompressPointer r0
    //     0x839e30: add             x0, x0, HEAP, lsl #32
    // 0x839e34: LoadField: r1 = r0->field_27
    //     0x839e34: ldur            w1, [x0, #0x27]
    // 0x839e38: DecompressPointer r1
    //     0x839e38: add             x1, x1, HEAP, lsl #32
    // 0x839e3c: LoadField: r0 = r1->field_7
    //     0x839e3c: ldur            w0, [x1, #7]
    // 0x839e40: DecompressPointer r0
    //     0x839e40: add             x0, x0, HEAP, lsl #32
    // 0x839e44: LoadField: r1 = r0->field_7
    //     0x839e44: ldur            w1, [x0, #7]
    // 0x839e48: DecompressPointer r1
    //     0x839e48: add             x1, x1, HEAP, lsl #32
    // 0x839e4c: LoadField: r0 = r2->field_17
    //     0x839e4c: ldur            x0, [x2, #0x17]
    // 0x839e50: r4 = LoadInt32Instr(r1)
    //     0x839e50: sbfx            x4, x1, #1, #0x1f
    // 0x839e54: cmp             x0, x4
    // 0x839e58: b.le            #0x839e64
    // 0x839e5c: mov             x5, x4
    // 0x839e60: b               #0x839e78
    // 0x839e64: cmp             x0, x4
    // 0x839e68: b.ge            #0x839e74
    // 0x839e6c: mov             x5, x0
    // 0x839e70: b               #0x839e78
    // 0x839e74: mov             x5, x0
    // 0x839e78: LoadField: r0 = r2->field_1f
    //     0x839e78: ldur            x0, [x2, #0x1f]
    // 0x839e7c: cmp             x0, x4
    // 0x839e80: b.gt            #0x839e98
    // 0x839e84: cmp             x0, x4
    // 0x839e88: b.ge            #0x839e94
    // 0x839e8c: mov             x4, x0
    // 0x839e90: b               #0x839e98
    // 0x839e94: mov             x4, x0
    // 0x839e98: r0 = BoxInt64Instr(r5)
    //     0x839e98: sbfiz           x0, x5, #1, #0x1f
    //     0x839e9c: cmp             x5, x0, asr #1
    //     0x839ea0: b.eq            #0x839eac
    //     0x839ea4: bl              #0xd69bb8
    //     0x839ea8: stur            x5, [x0, #7]
    // 0x839eac: mov             x5, x0
    // 0x839eb0: r0 = BoxInt64Instr(r4)
    //     0x839eb0: sbfiz           x0, x4, #1, #0x1f
    //     0x839eb4: cmp             x4, x0, asr #1
    //     0x839eb8: b.eq            #0x839ec4
    //     0x839ebc: bl              #0xd69bb8
    //     0x839ec0: stur            x4, [x0, #7]
    // 0x839ec4: stp             x5, x2, [SP, #-0x10]!
    // 0x839ec8: SaveReg r0
    //     0x839ec8: str             x0, [SP, #-8]!
    // 0x839ecc: r4 = const [0, 0x3, 0x3, 0x1, baseOffset, 0x1, extentOffset, 0x2, null]
    //     0x839ecc: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2de50] List(9) [0, 0x3, 0x3, 0x1, "baseOffset", 0x1, "extentOffset", 0x2, Null]
    //     0x839ed0: ldr             x4, [x4, #0xe50]
    // 0x839ed4: r0 = copyWith()
    //     0x839ed4: bl              #0x5227d4  ; [package:flutter/src/services/text_editing.dart] TextSelection::copyWith
    // 0x839ed8: add             SP, SP, #0x18
    // 0x839edc: mov             x1, x0
    // 0x839ee0: b               #0x839ee8
    // 0x839ee4: mov             x1, x2
    // 0x839ee8: ldr             x0, [fp, #0x20]
    // 0x839eec: LoadField: r2 = r0->field_db
    //     0x839eec: ldur            w2, [x0, #0xdb]
    // 0x839ef0: DecompressPointer r2
    //     0x839ef0: add             x2, x2, HEAP, lsl #32
    // 0x839ef4: LoadField: r3 = r2->field_b
    //     0x839ef4: ldur            w3, [x2, #0xb]
    // 0x839ef8: DecompressPointer r3
    //     0x839ef8: add             x3, x3, HEAP, lsl #32
    // 0x839efc: cmp             w3, NULL
    // 0x839f00: b.eq            #0x839f5c
    // 0x839f04: LoadField: r2 = r3->field_13
    //     0x839f04: ldur            w2, [x3, #0x13]
    // 0x839f08: DecompressPointer r2
    //     0x839f08: add             x2, x2, HEAP, lsl #32
    // 0x839f0c: LoadField: r3 = r2->field_27
    //     0x839f0c: ldur            w3, [x2, #0x27]
    // 0x839f10: DecompressPointer r3
    //     0x839f10: add             x3, x3, HEAP, lsl #32
    // 0x839f14: stp             x1, x3, [SP, #-0x10]!
    // 0x839f18: r4 = const [0, 0x2, 0x2, 0x1, selection, 0x1, null]
    //     0x839f18: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f640] List(7) [0, 0x2, 0x2, 0x1, "selection", 0x1, Null]
    //     0x839f1c: ldr             x4, [x4, #0x640]
    // 0x839f20: r0 = copyWith()
    //     0x839f20: bl              #0x79a550  ; [package:flutter/src/services/text_input.dart] TextEditingValue::copyWith
    // 0x839f24: add             SP, SP, #0x10
    // 0x839f28: ldr             x16, [fp, #0x20]
    // 0x839f2c: stp             x0, x16, [SP, #-0x10]!
    // 0x839f30: ldr             x16, [fp, #0x10]
    // 0x839f34: SaveReg r16
    //     0x839f34: str             x16, [SP, #-8]!
    // 0x839f38: r0 = _setTextEditingValue()
    //     0x839f38: bl              #0x839f60  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_setTextEditingValue
    // 0x839f3c: add             SP, SP, #0x18
    // 0x839f40: r0 = Null
    //     0x839f40: mov             x0, NULL
    // 0x839f44: LeaveFrame
    //     0x839f44: mov             SP, fp
    //     0x839f48: ldp             fp, lr, [SP], #0x10
    // 0x839f4c: ret
    //     0x839f4c: ret             
    // 0x839f50: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839f50: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839f54: b               #0x839dfc
    // 0x839f58: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839f58: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x839f5c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x839f5c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _setTextEditingValue(/* No info */) {
    // ** addr: 0x839f60, size: 0x50
    // 0x839f60: EnterFrame
    //     0x839f60: stp             fp, lr, [SP, #-0x10]!
    //     0x839f64: mov             fp, SP
    // 0x839f68: CheckStackOverflow
    //     0x839f68: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x839f6c: cmp             SP, x16
    //     0x839f70: b.ls            #0x839fa8
    // 0x839f74: ldr             x0, [fp, #0x20]
    // 0x839f78: LoadField: r1 = r0->field_db
    //     0x839f78: ldur            w1, [x0, #0xdb]
    // 0x839f7c: DecompressPointer r1
    //     0x839f7c: add             x1, x1, HEAP, lsl #32
    // 0x839f80: ldr             x16, [fp, #0x18]
    // 0x839f84: stp             x16, x1, [SP, #-0x10]!
    // 0x839f88: ldr             x16, [fp, #0x10]
    // 0x839f8c: SaveReg r16
    //     0x839f8c: str             x16, [SP, #-8]!
    // 0x839f90: r0 = userUpdateTextEditingValue()
    //     0x839f90: bl              #0x7a9d78  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::userUpdateTextEditingValue
    // 0x839f94: add             SP, SP, #0x18
    // 0x839f98: r0 = Null
    //     0x839f98: mov             x0, NULL
    // 0x839f9c: LeaveFrame
    //     0x839f9c: mov             SP, fp
    //     0x839fa0: ldp             fp, lr, [SP], #0x10
    // 0x839fa4: ret
    //     0x839fa4: ret             
    // 0x839fa8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839fa8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839fac: b               #0x839f74
  }
  _ selectWord(/* No info */) {
    // ** addr: 0x83a30c, size: 0x5c
    // 0x83a30c: EnterFrame
    //     0x83a30c: stp             fp, lr, [SP, #-0x10]!
    //     0x83a310: mov             fp, SP
    // 0x83a314: CheckStackOverflow
    //     0x83a314: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a318: cmp             SP, x16
    //     0x83a31c: b.ls            #0x83a35c
    // 0x83a320: ldr             x0, [fp, #0x18]
    // 0x83a324: LoadField: r1 = r0->field_8b
    //     0x83a324: ldur            w1, [x0, #0x8b]
    // 0x83a328: DecompressPointer r1
    //     0x83a328: add             x1, x1, HEAP, lsl #32
    // 0x83a32c: cmp             w1, NULL
    // 0x83a330: b.eq            #0x83a364
    // 0x83a334: ldr             x16, [fp, #0x10]
    // 0x83a338: stp             x16, x0, [SP, #-0x10]!
    // 0x83a33c: SaveReg r1
    //     0x83a33c: str             x1, [SP, #-8]!
    // 0x83a340: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x83a340: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x83a344: r0 = selectWordsInRange()
    //     0x83a344: bl              #0x83a368  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWordsInRange
    // 0x83a348: add             SP, SP, #0x18
    // 0x83a34c: r0 = Null
    //     0x83a34c: mov             x0, NULL
    // 0x83a350: LeaveFrame
    //     0x83a350: mov             SP, fp
    //     0x83a354: ldp             fp, lr, [SP], #0x10
    // 0x83a358: ret
    //     0x83a358: ret             
    // 0x83a35c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a35c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a360: b               #0x83a320
    // 0x83a364: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a364: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ selectWordsInRange(/* No info */) {
    // ** addr: 0x83a368, size: 0x224
    // 0x83a368: EnterFrame
    //     0x83a368: stp             fp, lr, [SP, #-0x10]!
    //     0x83a36c: mov             fp, SP
    // 0x83a370: AllocStack(0x38)
    //     0x83a370: sub             SP, SP, #0x38
    // 0x83a374: SetupParameters(ExtendedTextSelectionRenderObject this /* r3, fp-0x20 */, dynamic _ /* r4, fp-0x18 */, dynamic _ /* r5, fp-0x10 */, {dynamic to = Null /* r0, fp-0x8 */})
    //     0x83a374: mov             x0, x4
    //     0x83a378: ldur            w1, [x0, #0x13]
    //     0x83a37c: add             x1, x1, HEAP, lsl #32
    //     0x83a380: sub             x2, x1, #6
    //     0x83a384: add             x3, fp, w2, sxtw #2
    //     0x83a388: ldr             x3, [x3, #0x20]
    //     0x83a38c: stur            x3, [fp, #-0x20]
    //     0x83a390: add             x4, fp, w2, sxtw #2
    //     0x83a394: ldr             x4, [x4, #0x18]
    //     0x83a398: stur            x4, [fp, #-0x18]
    //     0x83a39c: add             x5, fp, w2, sxtw #2
    //     0x83a3a0: ldr             x5, [x5, #0x10]
    //     0x83a3a4: stur            x5, [fp, #-0x10]
    //     0x83a3a8: ldur            w2, [x0, #0x1f]
    //     0x83a3ac: add             x2, x2, HEAP, lsl #32
    //     0x83a3b0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1c688] "to"
    //     0x83a3b4: ldr             x16, [x16, #0x688]
    //     0x83a3b8: cmp             w2, w16
    //     0x83a3bc: b.ne            #0x83a3dc
    //     0x83a3c0: ldur            w2, [x0, #0x23]
    //     0x83a3c4: add             x2, x2, HEAP, lsl #32
    //     0x83a3c8: sub             w0, w1, w2
    //     0x83a3cc: add             x1, fp, w0, sxtw #2
    //     0x83a3d0: ldr             x1, [x1, #8]
    //     0x83a3d4: mov             x0, x1
    //     0x83a3d8: b               #0x83a3e0
    //     0x83a3dc: mov             x0, NULL
    //     0x83a3e0: stur            x0, [fp, #-8]
    // 0x83a3e4: CheckStackOverflow
    //     0x83a3e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a3e8: cmp             SP, x16
    //     0x83a3ec: b.ls            #0x83a584
    // 0x83a3f0: SaveReg r3
    //     0x83a3f0: str             x3, [SP, #-8]!
    // 0x83a3f4: r0 = _computeTextMetricsIfNeeded()
    //     0x83a3f4: bl              #0x52491c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_computeTextMetricsIfNeeded
    // 0x83a3f8: add             SP, SP, #8
    // 0x83a3fc: ldur            x0, [fp, #-0x20]
    // 0x83a400: LoadField: r1 = r0->field_eb
    //     0x83a400: ldur            w1, [x0, #0xeb]
    // 0x83a404: DecompressPointer r1
    //     0x83a404: add             x1, x1, HEAP, lsl #32
    // 0x83a408: stur            x1, [fp, #-0x28]
    // 0x83a40c: SaveReg r0
    //     0x83a40c: str             x0, [SP, #-8]!
    // 0x83a410: r0 = paintOffset()
    //     0x83a410: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x83a414: add             SP, SP, #8
    // 0x83a418: ldur            x16, [fp, #-0x10]
    // 0x83a41c: stp             x0, x16, [SP, #-0x10]!
    // 0x83a420: r0 = -()
    //     0x83a420: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x83a424: add             SP, SP, #0x10
    // 0x83a428: ldur            x16, [fp, #-0x20]
    // 0x83a42c: stp             x0, x16, [SP, #-0x10]!
    // 0x83a430: r0 = globalToLocal()
    //     0x83a430: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x83a434: add             SP, SP, #0x10
    // 0x83a438: ldur            x16, [fp, #-0x28]
    // 0x83a43c: stp             x0, x16, [SP, #-0x10]!
    // 0x83a440: r0 = getPositionForOffset()
    //     0x83a440: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x83a444: add             SP, SP, #0x10
    // 0x83a448: ldur            x16, [fp, #-0x20]
    // 0x83a44c: stp             x0, x16, [SP, #-0x10]!
    // 0x83a450: r0 = _getWordAtOffset()
    //     0x83a450: bl              #0x83a58c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_getWordAtOffset
    // 0x83a454: add             SP, SP, #0x10
    // 0x83a458: mov             x1, x0
    // 0x83a45c: ldur            x0, [fp, #-8]
    // 0x83a460: stur            x1, [fp, #-0x10]
    // 0x83a464: cmp             w0, NULL
    // 0x83a468: b.ne            #0x83a474
    // 0x83a46c: mov             x0, x1
    // 0x83a470: b               #0x83a4cc
    // 0x83a474: ldur            x16, [fp, #-0x20]
    // 0x83a478: SaveReg r16
    //     0x83a478: str             x16, [SP, #-8]!
    // 0x83a47c: r0 = paintOffset()
    //     0x83a47c: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x83a480: add             SP, SP, #8
    // 0x83a484: ldur            x16, [fp, #-8]
    // 0x83a488: stp             x0, x16, [SP, #-0x10]!
    // 0x83a48c: r0 = -()
    //     0x83a48c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x83a490: add             SP, SP, #0x10
    // 0x83a494: ldur            x16, [fp, #-0x20]
    // 0x83a498: stp             x0, x16, [SP, #-0x10]!
    // 0x83a49c: r0 = globalToLocal()
    //     0x83a49c: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x83a4a0: add             SP, SP, #0x10
    // 0x83a4a4: ldur            x16, [fp, #-0x28]
    // 0x83a4a8: stp             x0, x16, [SP, #-0x10]!
    // 0x83a4ac: r0 = getPositionForOffset()
    //     0x83a4ac: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x83a4b0: add             SP, SP, #0x10
    // 0x83a4b4: ldur            x16, [fp, #-0x20]
    // 0x83a4b8: stp             x0, x16, [SP, #-0x10]!
    // 0x83a4bc: r0 = _getWordAtOffset()
    //     0x83a4bc: bl              #0x83a58c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_getWordAtOffset
    // 0x83a4c0: add             SP, SP, #0x10
    // 0x83a4c4: mov             x1, x0
    // 0x83a4c8: ldur            x0, [fp, #-0x10]
    // 0x83a4cc: stur            x1, [fp, #-8]
    // 0x83a4d0: SaveReg r0
    //     0x83a4d0: str             x0, [SP, #-8]!
    // 0x83a4d4: r0 = base()
    //     0x83a4d4: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x83a4d8: add             SP, SP, #8
    // 0x83a4dc: LoadField: r1 = r0->field_7
    //     0x83a4dc: ldur            x1, [x0, #7]
    // 0x83a4e0: stur            x1, [fp, #-0x30]
    // 0x83a4e4: ldur            x16, [fp, #-8]
    // 0x83a4e8: SaveReg r16
    //     0x83a4e8: str             x16, [SP, #-8]!
    // 0x83a4ec: r0 = extent()
    //     0x83a4ec: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83a4f0: add             SP, SP, #8
    // 0x83a4f4: LoadField: r1 = r0->field_7
    //     0x83a4f4: ldur            x1, [x0, #7]
    // 0x83a4f8: ldur            x0, [fp, #-0x10]
    // 0x83a4fc: stur            x1, [fp, #-0x38]
    // 0x83a500: LoadField: r2 = r0->field_27
    //     0x83a500: ldur            w2, [x0, #0x27]
    // 0x83a504: DecompressPointer r2
    //     0x83a504: add             x2, x2, HEAP, lsl #32
    // 0x83a508: stur            x2, [fp, #-8]
    // 0x83a50c: r0 = TextSelection()
    //     0x83a50c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83a510: mov             x1, x0
    // 0x83a514: ldur            x0, [fp, #-0x30]
    // 0x83a518: StoreField: r1->field_17 = r0
    //     0x83a518: stur            x0, [x1, #0x17]
    // 0x83a51c: ldur            x2, [fp, #-0x38]
    // 0x83a520: StoreField: r1->field_1f = r2
    //     0x83a520: stur            x2, [x1, #0x1f]
    // 0x83a524: ldur            x3, [fp, #-8]
    // 0x83a528: StoreField: r1->field_27 = r3
    //     0x83a528: stur            w3, [x1, #0x27]
    // 0x83a52c: r3 = false
    //     0x83a52c: add             x3, NULL, #0x30  ; false
    // 0x83a530: StoreField: r1->field_2b = r3
    //     0x83a530: stur            w3, [x1, #0x2b]
    // 0x83a534: cmp             x0, x2
    // 0x83a538: b.ge            #0x83a544
    // 0x83a53c: mov             x3, x0
    // 0x83a540: b               #0x83a548
    // 0x83a544: mov             x3, x2
    // 0x83a548: cmp             x0, x2
    // 0x83a54c: b.ge            #0x83a554
    // 0x83a550: mov             x0, x2
    // 0x83a554: StoreField: r1->field_7 = r3
    //     0x83a554: stur            x3, [x1, #7]
    // 0x83a558: StoreField: r1->field_f = r0
    //     0x83a558: stur            x0, [x1, #0xf]
    // 0x83a55c: ldur            x16, [fp, #-0x20]
    // 0x83a560: stp             x1, x16, [SP, #-0x10]!
    // 0x83a564: ldur            x16, [fp, #-0x18]
    // 0x83a568: SaveReg r16
    //     0x83a568: str             x16, [SP, #-8]!
    // 0x83a56c: r0 = setSelection()
    //     0x83a56c: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0x83a570: add             SP, SP, #0x18
    // 0x83a574: r0 = Null
    //     0x83a574: mov             x0, NULL
    // 0x83a578: LeaveFrame
    //     0x83a578: mov             SP, fp
    //     0x83a57c: ldp             fp, lr, [SP], #0x10
    // 0x83a580: ret
    //     0x83a580: ret             
    // 0x83a584: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a584: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a588: b               #0x83a3f0
  }
  _ _getWordAtOffset(/* No info */) {
    // ** addr: 0x83a58c, size: 0xc8
    // 0x83a58c: EnterFrame
    //     0x83a58c: stp             fp, lr, [SP, #-0x10]!
    //     0x83a590: mov             fp, SP
    // 0x83a594: CheckStackOverflow
    //     0x83a594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a598: cmp             SP, x16
    //     0x83a59c: b.ls            #0x83a648
    // 0x83a5a0: r1 = 2
    //     0x83a5a0: mov             x1, #2
    // 0x83a5a4: r0 = AllocateContext()
    //     0x83a5a4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83a5a8: mov             x1, x0
    // 0x83a5ac: ldr             x0, [fp, #0x18]
    // 0x83a5b0: StoreField: r1->field_f = r0
    //     0x83a5b0: stur            w0, [x1, #0xf]
    // 0x83a5b4: ldr             x2, [fp, #0x10]
    // 0x83a5b8: StoreField: r1->field_13 = r2
    //     0x83a5b8: stur            w2, [x1, #0x13]
    // 0x83a5bc: mov             x2, x1
    // 0x83a5c0: r1 = Function '<anonymous closure>':.
    //     0x83a5c0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bdf0] AnonymousClosure: (0x83a9e0), in [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_getWordAtOffset (0x83a58c)
    //     0x83a5c4: ldr             x1, [x1, #0xdf0]
    // 0x83a5c8: r0 = AllocateClosure()
    //     0x83a5c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83a5cc: SaveReg r0
    //     0x83a5cc: str             x0, [SP, #-8]!
    // 0x83a5d0: ClosureCall
    //     0x83a5d0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0x83a5d4: ldur            x2, [x0, #0x1f]
    //     0x83a5d8: blr             x2
    // 0x83a5dc: add             SP, SP, #8
    // 0x83a5e0: mov             x1, x0
    // 0x83a5e4: ldr             x0, [fp, #0x18]
    // 0x83a5e8: LoadField: r2 = r0->field_97
    //     0x83a5e8: ldur            w2, [x0, #0x97]
    // 0x83a5ec: DecompressPointer r2
    //     0x83a5ec: add             x2, x2, HEAP, lsl #32
    // 0x83a5f0: tbnz            w2, #4, #0x83a638
    // 0x83a5f4: LoadField: r2 = r0->field_77
    //     0x83a5f4: ldur            w2, [x0, #0x77]
    // 0x83a5f8: DecompressPointer r2
    //     0x83a5f8: add             x2, x2, HEAP, lsl #32
    // 0x83a5fc: tbnz            w2, #4, #0x83a638
    // 0x83a600: LoadField: r2 = r0->field_eb
    //     0x83a600: ldur            w2, [x0, #0xeb]
    // 0x83a604: DecompressPointer r2
    //     0x83a604: add             x2, x2, HEAP, lsl #32
    // 0x83a608: LoadField: r0 = r2->field_f
    //     0x83a608: ldur            w0, [x2, #0xf]
    // 0x83a60c: DecompressPointer r0
    //     0x83a60c: add             x0, x0, HEAP, lsl #32
    // 0x83a610: cmp             w0, NULL
    // 0x83a614: b.eq            #0x83a650
    // 0x83a618: stp             x1, x0, [SP, #-0x10]!
    // 0x83a61c: r16 = true
    //     0x83a61c: add             x16, NULL, #0x20  ; true
    // 0x83a620: SaveReg r16
    //     0x83a620: str             x16, [SP, #-8]!
    // 0x83a624: r4 = const [0, 0x3, 0x3, 0x2, selectWord, 0x2, null]
    //     0x83a624: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4bdf8] List(7) [0, 0x3, 0x3, 0x2, "selectWord", 0x2, Null]
    //     0x83a628: ldr             x4, [x4, #0xdf8]
    // 0x83a62c: r0 = convertTextPainterSelectionToTextInputSelection()
    //     0x83a62c: bl              #0x83a654  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterSelectionToTextInputSelection
    // 0x83a630: add             SP, SP, #0x18
    // 0x83a634: b               #0x83a63c
    // 0x83a638: mov             x0, x1
    // 0x83a63c: LeaveFrame
    //     0x83a63c: mov             SP, fp
    //     0x83a640: ldp             fp, lr, [SP], #0x10
    // 0x83a644: ret
    //     0x83a644: ret             
    // 0x83a648: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a648: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a64c: b               #0x83a5a0
    // 0x83a650: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a650: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] TextSelection <anonymous closure>(dynamic) {
    // ** addr: 0x83a9e0, size: 0x4d4
    // 0x83a9e0: EnterFrame
    //     0x83a9e0: stp             fp, lr, [SP, #-0x10]!
    //     0x83a9e4: mov             fp, SP
    // 0x83a9e8: AllocStack(0x38)
    //     0x83a9e8: sub             SP, SP, #0x38
    // 0x83a9ec: SetupParameters()
    //     0x83a9ec: ldr             x0, [fp, #0x10]
    //     0x83a9f0: ldur            w1, [x0, #0x17]
    //     0x83a9f4: add             x1, x1, HEAP, lsl #32
    //     0x83a9f8: stur            x1, [fp, #-8]
    // 0x83a9fc: CheckStackOverflow
    //     0x83a9fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83aa00: cmp             SP, x16
    //     0x83aa04: b.ls            #0x83aeac
    // 0x83aa08: LoadField: r0 = r1->field_f
    //     0x83aa08: ldur            w0, [x1, #0xf]
    // 0x83aa0c: DecompressPointer r0
    //     0x83aa0c: add             x0, x0, HEAP, lsl #32
    // 0x83aa10: LoadField: r2 = r0->field_eb
    //     0x83aa10: ldur            w2, [x0, #0xeb]
    // 0x83aa14: DecompressPointer r2
    //     0x83aa14: add             x2, x2, HEAP, lsl #32
    // 0x83aa18: LoadField: r0 = r1->field_13
    //     0x83aa18: ldur            w0, [x1, #0x13]
    // 0x83aa1c: DecompressPointer r0
    //     0x83aa1c: add             x0, x0, HEAP, lsl #32
    // 0x83aa20: stp             x0, x2, [SP, #-0x10]!
    // 0x83aa24: r0 = getWordBoundary()
    //     0x83aa24: bl              #0x83bafc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0x83aa28: add             SP, SP, #0x10
    // 0x83aa2c: mov             x1, x0
    // 0x83aa30: ldur            x0, [fp, #-8]
    // 0x83aa34: stur            x1, [fp, #-0x28]
    // 0x83aa38: LoadField: r2 = r0->field_13
    //     0x83aa38: ldur            w2, [x0, #0x13]
    // 0x83aa3c: DecompressPointer r2
    //     0x83aa3c: add             x2, x2, HEAP, lsl #32
    // 0x83aa40: stur            x2, [fp, #-0x18]
    // 0x83aa44: LoadField: r3 = r2->field_7
    //     0x83aa44: ldur            x3, [x2, #7]
    // 0x83aa48: stur            x3, [fp, #-0x10]
    // 0x83aa4c: LoadField: r4 = r1->field_f
    //     0x83aa4c: ldur            x4, [x1, #0xf]
    // 0x83aa50: stur            x4, [fp, #-0x20]
    // 0x83aa54: cmp             x3, x4
    // 0x83aa58: b.lt            #0x83aaa0
    // 0x83aa5c: r0 = TextSelection()
    //     0x83aa5c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83aa60: mov             x1, x0
    // 0x83aa64: ldur            x0, [fp, #-0x10]
    // 0x83aa68: StoreField: r1->field_17 = r0
    //     0x83aa68: stur            x0, [x1, #0x17]
    // 0x83aa6c: StoreField: r1->field_1f = r0
    //     0x83aa6c: stur            x0, [x1, #0x1f]
    // 0x83aa70: ldur            x2, [fp, #-0x18]
    // 0x83aa74: LoadField: r3 = r2->field_f
    //     0x83aa74: ldur            w3, [x2, #0xf]
    // 0x83aa78: DecompressPointer r3
    //     0x83aa78: add             x3, x3, HEAP, lsl #32
    // 0x83aa7c: StoreField: r1->field_27 = r3
    //     0x83aa7c: stur            w3, [x1, #0x27]
    // 0x83aa80: r2 = false
    //     0x83aa80: add             x2, NULL, #0x30  ; false
    // 0x83aa84: StoreField: r1->field_2b = r2
    //     0x83aa84: stur            w2, [x1, #0x2b]
    // 0x83aa88: StoreField: r1->field_7 = r0
    //     0x83aa88: stur            x0, [x1, #7]
    // 0x83aa8c: StoreField: r1->field_f = r0
    //     0x83aa8c: stur            x0, [x1, #0xf]
    // 0x83aa90: mov             x0, x1
    // 0x83aa94: LeaveFrame
    //     0x83aa94: mov             SP, fp
    //     0x83aa98: ldp             fp, lr, [SP], #0x10
    // 0x83aa9c: ret
    //     0x83aa9c: ret             
    // 0x83aaa0: r2 = false
    //     0x83aaa0: add             x2, NULL, #0x30  ; false
    // 0x83aaa4: LoadField: r3 = r0->field_f
    //     0x83aaa4: ldur            w3, [x0, #0xf]
    // 0x83aaa8: DecompressPointer r3
    //     0x83aaa8: add             x3, x3, HEAP, lsl #32
    // 0x83aaac: SaveReg r3
    //     0x83aaac: str             x3, [SP, #-8]!
    // 0x83aab0: r0 = plainText()
    //     0x83aab0: bl              #0x68bdbc  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::plainText
    // 0x83aab4: add             SP, SP, #8
    // 0x83aab8: mov             x3, x0
    // 0x83aabc: ldur            x2, [fp, #-8]
    // 0x83aac0: LoadField: r0 = r2->field_13
    //     0x83aac0: ldur            w0, [x2, #0x13]
    // 0x83aac4: DecompressPointer r0
    //     0x83aac4: add             x0, x0, HEAP, lsl #32
    // 0x83aac8: LoadField: r4 = r0->field_7
    //     0x83aac8: ldur            x4, [x0, #7]
    // 0x83aacc: r0 = BoxInt64Instr(r4)
    //     0x83aacc: sbfiz           x0, x4, #1, #0x1f
    //     0x83aad0: cmp             x4, x0, asr #1
    //     0x83aad4: b.eq            #0x83aae0
    //     0x83aad8: bl              #0xd69bb8
    //     0x83aadc: stur            x4, [x0, #7]
    // 0x83aae0: r1 = LoadClassIdInstr(r3)
    //     0x83aae0: ldur            x1, [x3, #-1]
    //     0x83aae4: ubfx            x1, x1, #0xc, #0x14
    // 0x83aae8: stp             x0, x3, [SP, #-0x10]!
    // 0x83aaec: mov             x0, x1
    // 0x83aaf0: r0 = GDT[cid_x0 + -0x1000]()
    //     0x83aaf0: sub             lr, x0, #1, lsl #12
    //     0x83aaf4: ldr             lr, [x21, lr, lsl #3]
    //     0x83aaf8: blr             lr
    // 0x83aafc: add             SP, SP, #0x10
    // 0x83ab00: r1 = LoadInt32Instr(r0)
    //     0x83ab00: sbfx            x1, x0, #1, #0x1f
    // 0x83ab04: SaveReg r1
    //     0x83ab04: str             x1, [SP, #-8]!
    // 0x83ab08: r0 = isWhitespace()
    //     0x83ab08: bl              #0x83b9f4  ; [package:flutter/src/services/text_layout_metrics.dart] TextLayoutMetrics::isWhitespace
    // 0x83ab0c: add             SP, SP, #8
    // 0x83ab10: tbnz            w0, #4, #0x83ae3c
    // 0x83ab14: ldur            x0, [fp, #-8]
    // 0x83ab18: LoadField: r1 = r0->field_13
    //     0x83ab18: ldur            w1, [x0, #0x13]
    // 0x83ab1c: DecompressPointer r1
    //     0x83ab1c: add             x1, x1, HEAP, lsl #32
    // 0x83ab20: LoadField: r2 = r1->field_7
    //     0x83ab20: ldur            x2, [x1, #7]
    // 0x83ab24: cmp             x2, #0
    // 0x83ab28: b.le            #0x83ae30
    // 0x83ab2c: ldur            x1, [fp, #-0x28]
    // 0x83ab30: LoadField: r2 = r0->field_f
    //     0x83ab30: ldur            w2, [x0, #0xf]
    // 0x83ab34: DecompressPointer r2
    //     0x83ab34: add             x2, x2, HEAP, lsl #32
    // 0x83ab38: LoadField: r3 = r1->field_7
    //     0x83ab38: ldur            x3, [x1, #7]
    // 0x83ab3c: stur            x3, [fp, #-0x10]
    // 0x83ab40: stp             x3, x2, [SP, #-0x10]!
    // 0x83ab44: r0 = _getPreviousWord()
    //     0x83ab44: bl              #0x83b6a4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_getPreviousWord
    // 0x83ab48: add             SP, SP, #0x10
    // 0x83ab4c: stur            x0, [fp, #-0x18]
    // 0x83ab50: r0 = defaultTargetPlatform()
    //     0x83ab50: bl              #0x59ed88  ; [package:flutter/src/foundation/_platform_io.dart] ::defaultTargetPlatform
    // 0x83ab54: LoadField: r1 = r0->field_7
    //     0x83ab54: ldur            x1, [x0, #7]
    // 0x83ab58: cmp             x1, #2
    // 0x83ab5c: b.gt            #0x83ae24
    // 0x83ab60: cmp             x1, #1
    // 0x83ab64: b.gt            #0x83aca4
    // 0x83ab68: cmp             x1, #0
    // 0x83ab6c: b.gt            #0x83ac98
    // 0x83ab70: ldur            x0, [fp, #-8]
    // 0x83ab74: LoadField: r1 = r0->field_f
    //     0x83ab74: ldur            w1, [x0, #0xf]
    // 0x83ab78: DecompressPointer r1
    //     0x83ab78: add             x1, x1, HEAP, lsl #32
    // 0x83ab7c: LoadField: r2 = r1->field_ff
    //     0x83ab7c: ldur            w2, [x1, #0xff]
    // 0x83ab80: DecompressPointer r2
    //     0x83ab80: add             x2, x2, HEAP, lsl #32
    // 0x83ab84: tbnz            w2, #4, #0x83ac8c
    // 0x83ab88: ldur            x1, [fp, #-0x18]
    // 0x83ab8c: cmp             w1, NULL
    // 0x83ab90: b.ne            #0x83ac0c
    // 0x83ab94: LoadField: r1 = r0->field_13
    //     0x83ab94: ldur            w1, [x0, #0x13]
    // 0x83ab98: DecompressPointer r1
    //     0x83ab98: add             x1, x1, HEAP, lsl #32
    // 0x83ab9c: LoadField: r0 = r1->field_7
    //     0x83ab9c: ldur            x0, [x1, #7]
    // 0x83aba0: stur            x0, [fp, #-0x38]
    // 0x83aba4: add             x1, x0, #1
    // 0x83aba8: stur            x1, [fp, #-0x30]
    // 0x83abac: r0 = TextSelection()
    //     0x83abac: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83abb0: mov             x1, x0
    // 0x83abb4: ldur            x0, [fp, #-0x38]
    // 0x83abb8: StoreField: r1->field_17 = r0
    //     0x83abb8: stur            x0, [x1, #0x17]
    // 0x83abbc: ldur            x2, [fp, #-0x30]
    // 0x83abc0: StoreField: r1->field_1f = r2
    //     0x83abc0: stur            x2, [x1, #0x1f]
    // 0x83abc4: r3 = Instance_TextAffinity
    //     0x83abc4: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83abc8: StoreField: r1->field_27 = r3
    //     0x83abc8: stur            w3, [x1, #0x27]
    // 0x83abcc: r4 = false
    //     0x83abcc: add             x4, NULL, #0x30  ; false
    // 0x83abd0: StoreField: r1->field_2b = r4
    //     0x83abd0: stur            w4, [x1, #0x2b]
    // 0x83abd4: cmp             x0, x2
    // 0x83abd8: b.ge            #0x83abe4
    // 0x83abdc: mov             x3, x0
    // 0x83abe0: b               #0x83abe8
    // 0x83abe4: mov             x3, x2
    // 0x83abe8: cmp             x0, x2
    // 0x83abec: b.ge            #0x83abf4
    // 0x83abf0: mov             x0, x2
    // 0x83abf4: StoreField: r1->field_7 = r3
    //     0x83abf4: stur            x3, [x1, #7]
    // 0x83abf8: StoreField: r1->field_f = r0
    //     0x83abf8: stur            x0, [x1, #0xf]
    // 0x83abfc: mov             x0, x1
    // 0x83ac00: LeaveFrame
    //     0x83ac00: mov             SP, fp
    //     0x83ac04: ldp             fp, lr, [SP], #0x10
    // 0x83ac08: ret
    //     0x83ac08: ret             
    // 0x83ac0c: r4 = false
    //     0x83ac0c: add             x4, NULL, #0x30  ; false
    // 0x83ac10: r3 = Instance_TextAffinity
    //     0x83ac10: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ac14: LoadField: r2 = r1->field_7
    //     0x83ac14: ldur            x2, [x1, #7]
    // 0x83ac18: stur            x2, [fp, #-0x38]
    // 0x83ac1c: LoadField: r1 = r0->field_13
    //     0x83ac1c: ldur            w1, [x0, #0x13]
    // 0x83ac20: DecompressPointer r1
    //     0x83ac20: add             x1, x1, HEAP, lsl #32
    // 0x83ac24: LoadField: r0 = r1->field_7
    //     0x83ac24: ldur            x0, [x1, #7]
    // 0x83ac28: stur            x0, [fp, #-0x30]
    // 0x83ac2c: r0 = TextSelection()
    //     0x83ac2c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83ac30: mov             x1, x0
    // 0x83ac34: ldur            x0, [fp, #-0x38]
    // 0x83ac38: StoreField: r1->field_17 = r0
    //     0x83ac38: stur            x0, [x1, #0x17]
    // 0x83ac3c: ldur            x2, [fp, #-0x30]
    // 0x83ac40: StoreField: r1->field_1f = r2
    //     0x83ac40: stur            x2, [x1, #0x1f]
    // 0x83ac44: r3 = Instance_TextAffinity
    //     0x83ac44: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ac48: StoreField: r1->field_27 = r3
    //     0x83ac48: stur            w3, [x1, #0x27]
    // 0x83ac4c: r4 = false
    //     0x83ac4c: add             x4, NULL, #0x30  ; false
    // 0x83ac50: StoreField: r1->field_2b = r4
    //     0x83ac50: stur            w4, [x1, #0x2b]
    // 0x83ac54: cmp             x0, x2
    // 0x83ac58: b.ge            #0x83ac64
    // 0x83ac5c: mov             x3, x0
    // 0x83ac60: b               #0x83ac68
    // 0x83ac64: mov             x3, x2
    // 0x83ac68: cmp             x0, x2
    // 0x83ac6c: b.ge            #0x83ac74
    // 0x83ac70: mov             x0, x2
    // 0x83ac74: StoreField: r1->field_7 = r3
    //     0x83ac74: stur            x3, [x1, #7]
    // 0x83ac78: StoreField: r1->field_f = r0
    //     0x83ac78: stur            x0, [x1, #0xf]
    // 0x83ac7c: mov             x0, x1
    // 0x83ac80: LeaveFrame
    //     0x83ac80: mov             SP, fp
    //     0x83ac84: ldp             fp, lr, [SP], #0x10
    // 0x83ac88: ret
    //     0x83ac88: ret             
    // 0x83ac8c: r4 = false
    //     0x83ac8c: add             x4, NULL, #0x30  ; false
    // 0x83ac90: r3 = Instance_TextAffinity
    //     0x83ac90: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ac94: b               #0x83ae44
    // 0x83ac98: r4 = false
    //     0x83ac98: add             x4, NULL, #0x30  ; false
    // 0x83ac9c: r3 = Instance_TextAffinity
    //     0x83ac9c: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83aca0: b               #0x83ae44
    // 0x83aca4: ldur            x0, [fp, #-8]
    // 0x83aca8: ldur            x1, [fp, #-0x18]
    // 0x83acac: r4 = false
    //     0x83acac: add             x4, NULL, #0x30  ; false
    // 0x83acb0: r3 = Instance_TextAffinity
    //     0x83acb0: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83acb4: cmp             w1, NULL
    // 0x83acb8: b.ne            #0x83ada8
    // 0x83acbc: ldur            x1, [fp, #-0x10]
    // 0x83acc0: LoadField: r2 = r0->field_f
    //     0x83acc0: ldur            w2, [x0, #0xf]
    // 0x83acc4: DecompressPointer r2
    //     0x83acc4: add             x2, x2, HEAP, lsl #32
    // 0x83acc8: stp             x1, x2, [SP, #-0x10]!
    // 0x83accc: r0 = _getNextWord()
    //     0x83accc: bl              #0x83aeb4  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_getNextWord
    // 0x83acd0: add             SP, SP, #0x10
    // 0x83acd4: cmp             w0, NULL
    // 0x83acd8: b.ne            #0x83ad24
    // 0x83acdc: ldur            x2, [fp, #-8]
    // 0x83ace0: LoadField: r0 = r2->field_13
    //     0x83ace0: ldur            w0, [x2, #0x13]
    // 0x83ace4: DecompressPointer r0
    //     0x83ace4: add             x0, x0, HEAP, lsl #32
    // 0x83ace8: LoadField: r1 = r0->field_7
    //     0x83ace8: ldur            x1, [x0, #7]
    // 0x83acec: stur            x1, [fp, #-0x10]
    // 0x83acf0: r0 = TextSelection()
    //     0x83acf0: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83acf4: r1 = Instance_TextAffinity
    //     0x83acf4: ldr             x1, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83acf8: StoreField: r0->field_27 = r1
    //     0x83acf8: stur            w1, [x0, #0x27]
    // 0x83acfc: ldur            x1, [fp, #-0x10]
    // 0x83ad00: StoreField: r0->field_17 = r1
    //     0x83ad00: stur            x1, [x0, #0x17]
    // 0x83ad04: StoreField: r0->field_1f = r1
    //     0x83ad04: stur            x1, [x0, #0x1f]
    // 0x83ad08: r3 = false
    //     0x83ad08: add             x3, NULL, #0x30  ; false
    // 0x83ad0c: StoreField: r0->field_2b = r3
    //     0x83ad0c: stur            w3, [x0, #0x2b]
    // 0x83ad10: StoreField: r0->field_7 = r1
    //     0x83ad10: stur            x1, [x0, #7]
    // 0x83ad14: StoreField: r0->field_f = r1
    //     0x83ad14: stur            x1, [x0, #0xf]
    // 0x83ad18: LeaveFrame
    //     0x83ad18: mov             SP, fp
    //     0x83ad1c: ldp             fp, lr, [SP], #0x10
    // 0x83ad20: ret
    //     0x83ad20: ret             
    // 0x83ad24: ldur            x2, [fp, #-8]
    // 0x83ad28: r3 = false
    //     0x83ad28: add             x3, NULL, #0x30  ; false
    // 0x83ad2c: r1 = Instance_TextAffinity
    //     0x83ad2c: ldr             x1, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ad30: LoadField: r4 = r2->field_13
    //     0x83ad30: ldur            w4, [x2, #0x13]
    // 0x83ad34: DecompressPointer r4
    //     0x83ad34: add             x4, x4, HEAP, lsl #32
    // 0x83ad38: LoadField: r2 = r4->field_7
    //     0x83ad38: ldur            x2, [x4, #7]
    // 0x83ad3c: stur            x2, [fp, #-0x30]
    // 0x83ad40: LoadField: r4 = r0->field_f
    //     0x83ad40: ldur            x4, [x0, #0xf]
    // 0x83ad44: stur            x4, [fp, #-0x10]
    // 0x83ad48: r0 = TextSelection()
    //     0x83ad48: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83ad4c: mov             x1, x0
    // 0x83ad50: ldur            x0, [fp, #-0x30]
    // 0x83ad54: StoreField: r1->field_17 = r0
    //     0x83ad54: stur            x0, [x1, #0x17]
    // 0x83ad58: ldur            x2, [fp, #-0x10]
    // 0x83ad5c: StoreField: r1->field_1f = r2
    //     0x83ad5c: stur            x2, [x1, #0x1f]
    // 0x83ad60: r3 = Instance_TextAffinity
    //     0x83ad60: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ad64: StoreField: r1->field_27 = r3
    //     0x83ad64: stur            w3, [x1, #0x27]
    // 0x83ad68: r4 = false
    //     0x83ad68: add             x4, NULL, #0x30  ; false
    // 0x83ad6c: StoreField: r1->field_2b = r4
    //     0x83ad6c: stur            w4, [x1, #0x2b]
    // 0x83ad70: cmp             x0, x2
    // 0x83ad74: b.ge            #0x83ad80
    // 0x83ad78: mov             x3, x0
    // 0x83ad7c: b               #0x83ad84
    // 0x83ad80: mov             x3, x2
    // 0x83ad84: cmp             x0, x2
    // 0x83ad88: b.ge            #0x83ad90
    // 0x83ad8c: mov             x0, x2
    // 0x83ad90: StoreField: r1->field_7 = r3
    //     0x83ad90: stur            x3, [x1, #7]
    // 0x83ad94: StoreField: r1->field_f = r0
    //     0x83ad94: stur            x0, [x1, #0xf]
    // 0x83ad98: mov             x0, x1
    // 0x83ad9c: LeaveFrame
    //     0x83ad9c: mov             SP, fp
    //     0x83ada0: ldp             fp, lr, [SP], #0x10
    // 0x83ada4: ret
    //     0x83ada4: ret             
    // 0x83ada8: mov             x2, x0
    // 0x83adac: LoadField: r0 = r1->field_7
    //     0x83adac: ldur            x0, [x1, #7]
    // 0x83adb0: stur            x0, [fp, #-0x30]
    // 0x83adb4: LoadField: r1 = r2->field_13
    //     0x83adb4: ldur            w1, [x2, #0x13]
    // 0x83adb8: DecompressPointer r1
    //     0x83adb8: add             x1, x1, HEAP, lsl #32
    // 0x83adbc: LoadField: r2 = r1->field_7
    //     0x83adbc: ldur            x2, [x1, #7]
    // 0x83adc0: stur            x2, [fp, #-0x10]
    // 0x83adc4: r0 = TextSelection()
    //     0x83adc4: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83adc8: mov             x1, x0
    // 0x83adcc: ldur            x0, [fp, #-0x30]
    // 0x83add0: StoreField: r1->field_17 = r0
    //     0x83add0: stur            x0, [x1, #0x17]
    // 0x83add4: ldur            x2, [fp, #-0x10]
    // 0x83add8: StoreField: r1->field_1f = r2
    //     0x83add8: stur            x2, [x1, #0x1f]
    // 0x83addc: r3 = Instance_TextAffinity
    //     0x83addc: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ade0: StoreField: r1->field_27 = r3
    //     0x83ade0: stur            w3, [x1, #0x27]
    // 0x83ade4: r4 = false
    //     0x83ade4: add             x4, NULL, #0x30  ; false
    // 0x83ade8: StoreField: r1->field_2b = r4
    //     0x83ade8: stur            w4, [x1, #0x2b]
    // 0x83adec: cmp             x0, x2
    // 0x83adf0: b.ge            #0x83adfc
    // 0x83adf4: mov             x3, x0
    // 0x83adf8: b               #0x83ae00
    // 0x83adfc: mov             x3, x2
    // 0x83ae00: cmp             x0, x2
    // 0x83ae04: b.ge            #0x83ae0c
    // 0x83ae08: mov             x0, x2
    // 0x83ae0c: StoreField: r1->field_7 = r3
    //     0x83ae0c: stur            x3, [x1, #7]
    // 0x83ae10: StoreField: r1->field_f = r0
    //     0x83ae10: stur            x0, [x1, #0xf]
    // 0x83ae14: mov             x0, x1
    // 0x83ae18: LeaveFrame
    //     0x83ae18: mov             SP, fp
    //     0x83ae1c: ldp             fp, lr, [SP], #0x10
    // 0x83ae20: ret
    //     0x83ae20: ret             
    // 0x83ae24: r4 = false
    //     0x83ae24: add             x4, NULL, #0x30  ; false
    // 0x83ae28: r3 = Instance_TextAffinity
    //     0x83ae28: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ae2c: b               #0x83ae44
    // 0x83ae30: r4 = false
    //     0x83ae30: add             x4, NULL, #0x30  ; false
    // 0x83ae34: r3 = Instance_TextAffinity
    //     0x83ae34: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ae38: b               #0x83ae44
    // 0x83ae3c: r4 = false
    //     0x83ae3c: add             x4, NULL, #0x30  ; false
    // 0x83ae40: r3 = Instance_TextAffinity
    //     0x83ae40: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ae44: ldur            x0, [fp, #-0x28]
    // 0x83ae48: ldur            x1, [fp, #-0x20]
    // 0x83ae4c: LoadField: r2 = r0->field_7
    //     0x83ae4c: ldur            x2, [x0, #7]
    // 0x83ae50: stur            x2, [fp, #-0x10]
    // 0x83ae54: r0 = TextSelection()
    //     0x83ae54: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83ae58: ldur            x1, [fp, #-0x10]
    // 0x83ae5c: StoreField: r0->field_17 = r1
    //     0x83ae5c: stur            x1, [x0, #0x17]
    // 0x83ae60: ldur            x2, [fp, #-0x20]
    // 0x83ae64: StoreField: r0->field_1f = r2
    //     0x83ae64: stur            x2, [x0, #0x1f]
    // 0x83ae68: r3 = Instance_TextAffinity
    //     0x83ae68: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83ae6c: StoreField: r0->field_27 = r3
    //     0x83ae6c: stur            w3, [x0, #0x27]
    // 0x83ae70: r3 = false
    //     0x83ae70: add             x3, NULL, #0x30  ; false
    // 0x83ae74: StoreField: r0->field_2b = r3
    //     0x83ae74: stur            w3, [x0, #0x2b]
    // 0x83ae78: cmp             x1, x2
    // 0x83ae7c: b.ge            #0x83ae88
    // 0x83ae80: mov             x3, x1
    // 0x83ae84: b               #0x83ae8c
    // 0x83ae88: mov             x3, x2
    // 0x83ae8c: cmp             x1, x2
    // 0x83ae90: b.ge            #0x83ae98
    // 0x83ae94: mov             x1, x2
    // 0x83ae98: StoreField: r0->field_7 = r3
    //     0x83ae98: stur            x3, [x0, #7]
    // 0x83ae9c: StoreField: r0->field_f = r1
    //     0x83ae9c: stur            x1, [x0, #0xf]
    // 0x83aea0: LeaveFrame
    //     0x83aea0: mov             SP, fp
    //     0x83aea4: ldp             fp, lr, [SP], #0x10
    // 0x83aea8: ret
    //     0x83aea8: ret             
    // 0x83aeac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83aeac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83aeb0: b               #0x83aa08
  }
  _ selectWordEdge(/* No info */) {
    // ** addr: 0x83c3e8, size: 0x1a4
    // 0x83c3e8: EnterFrame
    //     0x83c3e8: stp             fp, lr, [SP, #-0x10]!
    //     0x83c3ec: mov             fp, SP
    // 0x83c3f0: AllocStack(0x18)
    //     0x83c3f0: sub             SP, SP, #0x18
    // 0x83c3f4: CheckStackOverflow
    //     0x83c3f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c3f8: cmp             SP, x16
    //     0x83c3fc: b.ls            #0x83c57c
    // 0x83c400: ldr             x16, [fp, #0x10]
    // 0x83c404: SaveReg r16
    //     0x83c404: str             x16, [SP, #-8]!
    // 0x83c408: r0 = _computeTextMetricsIfNeeded()
    //     0x83c408: bl              #0x52491c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::_computeTextMetricsIfNeeded
    // 0x83c40c: add             SP, SP, #8
    // 0x83c410: ldr             x0, [fp, #0x10]
    // 0x83c414: LoadField: r1 = r0->field_eb
    //     0x83c414: ldur            w1, [x0, #0xeb]
    // 0x83c418: DecompressPointer r1
    //     0x83c418: add             x1, x1, HEAP, lsl #32
    // 0x83c41c: stur            x1, [fp, #-0x10]
    // 0x83c420: LoadField: r2 = r0->field_8b
    //     0x83c420: ldur            w2, [x0, #0x8b]
    // 0x83c424: DecompressPointer r2
    //     0x83c424: add             x2, x2, HEAP, lsl #32
    // 0x83c428: stur            x2, [fp, #-8]
    // 0x83c42c: cmp             w2, NULL
    // 0x83c430: b.eq            #0x83c584
    // 0x83c434: SaveReg r0
    //     0x83c434: str             x0, [SP, #-8]!
    // 0x83c438: r0 = paintOffset()
    //     0x83c438: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x83c43c: add             SP, SP, #8
    // 0x83c440: ldur            x16, [fp, #-8]
    // 0x83c444: stp             x0, x16, [SP, #-0x10]!
    // 0x83c448: r0 = -()
    //     0x83c448: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x83c44c: add             SP, SP, #0x10
    // 0x83c450: ldr             x16, [fp, #0x10]
    // 0x83c454: stp             x0, x16, [SP, #-0x10]!
    // 0x83c458: r0 = globalToLocal()
    //     0x83c458: bl              #0x669450  ; [package:flutter/src/rendering/box.dart] RenderBox::globalToLocal
    // 0x83c45c: add             SP, SP, #0x10
    // 0x83c460: ldur            x16, [fp, #-0x10]
    // 0x83c464: stp             x0, x16, [SP, #-0x10]!
    // 0x83c468: r0 = getPositionForOffset()
    //     0x83c468: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x83c46c: add             SP, SP, #0x10
    // 0x83c470: stur            x0, [fp, #-8]
    // 0x83c474: ldur            x16, [fp, #-0x10]
    // 0x83c478: stp             x0, x16, [SP, #-0x10]!
    // 0x83c47c: r0 = getWordBoundary()
    //     0x83c47c: bl              #0x83bafc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0x83c480: add             SP, SP, #0x10
    // 0x83c484: mov             x1, x0
    // 0x83c488: ldur            x0, [fp, #-8]
    // 0x83c48c: LoadField: r2 = r0->field_7
    //     0x83c48c: ldur            x2, [x0, #7]
    // 0x83c490: LoadField: r0 = r1->field_7
    //     0x83c490: ldur            x0, [x1, #7]
    // 0x83c494: stur            x0, [fp, #-0x18]
    // 0x83c498: cmp             x2, x0
    // 0x83c49c: b.gt            #0x83c4d0
    // 0x83c4a0: r0 = TextSelection()
    //     0x83c4a0: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83c4a4: mov             x1, x0
    // 0x83c4a8: r0 = Instance_TextAffinity
    //     0x83c4a8: ldr             x0, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x83c4ac: StoreField: r1->field_27 = r0
    //     0x83c4ac: stur            w0, [x1, #0x27]
    // 0x83c4b0: ldur            x0, [fp, #-0x18]
    // 0x83c4b4: StoreField: r1->field_17 = r0
    //     0x83c4b4: stur            x0, [x1, #0x17]
    // 0x83c4b8: StoreField: r1->field_1f = r0
    //     0x83c4b8: stur            x0, [x1, #0x1f]
    // 0x83c4bc: r2 = false
    //     0x83c4bc: add             x2, NULL, #0x30  ; false
    // 0x83c4c0: StoreField: r1->field_2b = r2
    //     0x83c4c0: stur            w2, [x1, #0x2b]
    // 0x83c4c4: StoreField: r1->field_7 = r0
    //     0x83c4c4: stur            x0, [x1, #7]
    // 0x83c4c8: StoreField: r1->field_f = r0
    //     0x83c4c8: stur            x0, [x1, #0xf]
    // 0x83c4cc: b               #0x83c508
    // 0x83c4d0: r2 = false
    //     0x83c4d0: add             x2, NULL, #0x30  ; false
    // 0x83c4d4: LoadField: r0 = r1->field_f
    //     0x83c4d4: ldur            x0, [x1, #0xf]
    // 0x83c4d8: stur            x0, [fp, #-0x18]
    // 0x83c4dc: r0 = TextSelection()
    //     0x83c4dc: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x83c4e0: mov             x1, x0
    // 0x83c4e4: r0 = Instance_TextAffinity
    //     0x83c4e4: ldr             x0, [PP, #0x6098]  ; [pp+0x6098] Obj!TextAffinity@b66df1
    // 0x83c4e8: StoreField: r1->field_27 = r0
    //     0x83c4e8: stur            w0, [x1, #0x27]
    // 0x83c4ec: ldur            x0, [fp, #-0x18]
    // 0x83c4f0: StoreField: r1->field_17 = r0
    //     0x83c4f0: stur            x0, [x1, #0x17]
    // 0x83c4f4: StoreField: r1->field_1f = r0
    //     0x83c4f4: stur            x0, [x1, #0x1f]
    // 0x83c4f8: r2 = false
    //     0x83c4f8: add             x2, NULL, #0x30  ; false
    // 0x83c4fc: StoreField: r1->field_2b = r2
    //     0x83c4fc: stur            w2, [x1, #0x2b]
    // 0x83c500: StoreField: r1->field_7 = r0
    //     0x83c500: stur            x0, [x1, #7]
    // 0x83c504: StoreField: r1->field_f = r0
    //     0x83c504: stur            x0, [x1, #0xf]
    // 0x83c508: ldr             x0, [fp, #0x10]
    // 0x83c50c: LoadField: r2 = r0->field_97
    //     0x83c50c: ldur            w2, [x0, #0x97]
    // 0x83c510: DecompressPointer r2
    //     0x83c510: add             x2, x2, HEAP, lsl #32
    // 0x83c514: tbnz            w2, #4, #0x83c54c
    // 0x83c518: LoadField: r2 = r0->field_77
    //     0x83c518: ldur            w2, [x0, #0x77]
    // 0x83c51c: DecompressPointer r2
    //     0x83c51c: add             x2, x2, HEAP, lsl #32
    // 0x83c520: tbnz            w2, #4, #0x83c54c
    // 0x83c524: ldur            x2, [fp, #-0x10]
    // 0x83c528: LoadField: r3 = r2->field_f
    //     0x83c528: ldur            w3, [x2, #0xf]
    // 0x83c52c: DecompressPointer r3
    //     0x83c52c: add             x3, x3, HEAP, lsl #32
    // 0x83c530: cmp             w3, NULL
    // 0x83c534: b.eq            #0x83c588
    // 0x83c538: stp             x1, x3, [SP, #-0x10]!
    // 0x83c53c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x83c53c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x83c540: r0 = convertTextPainterSelectionToTextInputSelection()
    //     0x83c540: bl              #0x83a654  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterSelectionToTextInputSelection
    // 0x83c544: add             SP, SP, #0x10
    // 0x83c548: b               #0x83c550
    // 0x83c54c: mov             x0, x1
    // 0x83c550: ldr             x16, [fp, #0x10]
    // 0x83c554: stp             x0, x16, [SP, #-0x10]!
    // 0x83c558: r16 = Instance_SelectionChangedCause
    //     0x83c558: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6e8] Obj!SelectionChangedCause@b63ed1
    //     0x83c55c: ldr             x16, [x16, #0x6e8]
    // 0x83c560: SaveReg r16
    //     0x83c560: str             x16, [SP, #-8]!
    // 0x83c564: r0 = setSelection()
    //     0x83c564: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0x83c568: add             SP, SP, #0x18
    // 0x83c56c: r0 = Null
    //     0x83c56c: mov             x0, NULL
    // 0x83c570: LeaveFrame
    //     0x83c570: mov             SP, fp
    //     0x83c574: ldp             fp, lr, [SP], #0x10
    // 0x83c578: ret
    //     0x83c578: ret             
    // 0x83c57c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c57c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c580: b               #0x83c400
    // 0x83c584: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c584: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83c588: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c588: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ selectPosition(/* No info */) {
    // ** addr: 0x83c58c, size: 0x60
    // 0x83c58c: EnterFrame
    //     0x83c58c: stp             fp, lr, [SP, #-0x10]!
    //     0x83c590: mov             fp, SP
    // 0x83c594: CheckStackOverflow
    //     0x83c594: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c598: cmp             SP, x16
    //     0x83c59c: b.ls            #0x83c5e0
    // 0x83c5a0: ldr             x0, [fp, #0x10]
    // 0x83c5a4: LoadField: r1 = r0->field_8b
    //     0x83c5a4: ldur            w1, [x0, #0x8b]
    // 0x83c5a8: DecompressPointer r1
    //     0x83c5a8: add             x1, x1, HEAP, lsl #32
    // 0x83c5ac: cmp             w1, NULL
    // 0x83c5b0: b.eq            #0x83c5e8
    // 0x83c5b4: r16 = Instance_SelectionChangedCause
    //     0x83c5b4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6e8] Obj!SelectionChangedCause@b63ed1
    //     0x83c5b8: ldr             x16, [x16, #0x6e8]
    // 0x83c5bc: stp             x16, x0, [SP, #-0x10]!
    // 0x83c5c0: SaveReg r1
    //     0x83c5c0: str             x1, [SP, #-8]!
    // 0x83c5c4: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x83c5c4: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x83c5c8: r0 = selectPositionAt()
    //     0x83c5c8: bl              #0x839a30  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPositionAt
    // 0x83c5cc: add             SP, SP, #0x18
    // 0x83c5d0: r0 = Null
    //     0x83c5d0: mov             x0, NULL
    // 0x83c5d4: LeaveFrame
    //     0x83c5d4: mov             SP, fp
    //     0x83c5d8: ldp             fp, lr, [SP], #0x10
    // 0x83c5dc: ret
    //     0x83c5dc: ret             
    // 0x83c5e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c5e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c5e4: b               #0x83c5a0
    // 0x83c5e8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c5e8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ handleSecondaryTapDown(/* No info */) {
    // ** addr: 0x83c698, size: 0x68
    // 0x83c698: EnterFrame
    //     0x83c698: stp             fp, lr, [SP, #-0x10]!
    //     0x83c69c: mov             fp, SP
    // 0x83c6a0: ldr             x1, [fp, #0x10]
    // 0x83c6a4: LoadField: r2 = r1->field_7
    //     0x83c6a4: ldur            w2, [x1, #7]
    // 0x83c6a8: DecompressPointer r2
    //     0x83c6a8: add             x2, x2, HEAP, lsl #32
    // 0x83c6ac: mov             x0, x2
    // 0x83c6b0: ldr             x1, [fp, #0x18]
    // 0x83c6b4: StoreField: r1->field_8b = r0
    //     0x83c6b4: stur            w0, [x1, #0x8b]
    //     0x83c6b8: ldurb           w16, [x1, #-1]
    //     0x83c6bc: ldurb           w17, [x0, #-1]
    //     0x83c6c0: and             x16, x17, x16, lsr #2
    //     0x83c6c4: tst             x16, HEAP, lsr #32
    //     0x83c6c8: b.eq            #0x83c6d0
    //     0x83c6cc: bl              #0xd6826c
    // 0x83c6d0: mov             x0, x2
    // 0x83c6d4: StoreField: r1->field_8f = r0
    //     0x83c6d4: stur            w0, [x1, #0x8f]
    //     0x83c6d8: ldurb           w16, [x1, #-1]
    //     0x83c6dc: ldurb           w17, [x0, #-1]
    //     0x83c6e0: and             x16, x17, x16, lsr #2
    //     0x83c6e4: tst             x16, HEAP, lsr #32
    //     0x83c6e8: b.eq            #0x83c6f0
    //     0x83c6ec: bl              #0xd6826c
    // 0x83c6f0: r0 = Null
    //     0x83c6f0: mov             x0, NULL
    // 0x83c6f4: LeaveFrame
    //     0x83c6f4: mov             SP, fp
    //     0x83c6f8: ldp             fp, lr, [SP], #0x10
    // 0x83c6fc: ret
    //     0x83c6fc: ret             
  }
  _ handleTapDown(/* No info */) {
    // ** addr: 0x83ca50, size: 0x3c
    // 0x83ca50: ldr             x1, [SP]
    // 0x83ca54: LoadField: r0 = r1->field_7
    //     0x83ca54: ldur            w0, [x1, #7]
    // 0x83ca58: DecompressPointer r0
    //     0x83ca58: add             x0, x0, HEAP, lsl #32
    // 0x83ca5c: ldr             x1, [SP, #8]
    // 0x83ca60: StoreField: r1->field_8b = r0
    //     0x83ca60: stur            w0, [x1, #0x8b]
    //     0x83ca64: ldurb           w16, [x1, #-1]
    //     0x83ca68: ldurb           w17, [x0, #-1]
    //     0x83ca6c: and             x16, x17, x16, lsr #2
    //     0x83ca70: tst             x16, HEAP, lsr #32
    //     0x83ca74: b.eq            #0x83ca84
    //     0x83ca78: str             lr, [SP, #-8]!
    //     0x83ca7c: bl              #0xd6826c
    //     0x83ca80: ldr             lr, [SP], #8
    // 0x83ca84: r0 = Null
    //     0x83ca84: mov             x0, NULL
    // 0x83ca88: ret
    //     0x83ca88: ret             
  }
  _ attach(/* No info */) {
    // ** addr: 0x9bc6c0, size: 0x1a0
    // 0x9bc6c0: EnterFrame
    //     0x9bc6c0: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc6c4: mov             fp, SP
    // 0x9bc6c8: AllocStack(0x8)
    //     0x9bc6c8: sub             SP, SP, #8
    // 0x9bc6cc: CheckStackOverflow
    //     0x9bc6cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc6d0: cmp             SP, x16
    //     0x9bc6d4: b.ls            #0x9bc858
    // 0x9bc6d8: ldr             x16, [fp, #0x18]
    // 0x9bc6dc: ldr             lr, [fp, #0x10]
    // 0x9bc6e0: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc6e4: r0 = attach()
    //     0x9bc6e4: bl              #0x9bc98c  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin::attach
    // 0x9bc6e8: add             SP, SP, #0x10
    // 0x9bc6ec: r0 = TapGestureRecognizer()
    //     0x9bc6ec: bl              #0x6ef3bc  ; AllocateTapGestureRecognizerStub -> TapGestureRecognizer (size=0x80)
    // 0x9bc6f0: mov             x1, x0
    // 0x9bc6f4: r0 = false
    //     0x9bc6f4: add             x0, NULL, #0x30  ; false
    // 0x9bc6f8: stur            x1, [fp, #-8]
    // 0x9bc6fc: StoreField: r1->field_43 = r0
    //     0x9bc6fc: stur            w0, [x1, #0x43]
    // 0x9bc700: StoreField: r1->field_47 = r0
    //     0x9bc700: stur            w0, [x1, #0x47]
    // 0x9bc704: r16 = Instance_Duration
    //     0x9bc704: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9f0] Obj!Duration@b67a41
    //     0x9bc708: ldr             x16, [x16, #0x9f0]
    // 0x9bc70c: stp             x16, x1, [SP, #-0x10]!
    // 0x9bc710: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x9bc710: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x9bc714: r0 = PrimaryPointerGestureRecognizer()
    //     0x9bc714: bl              #0x6ef26c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::PrimaryPointerGestureRecognizer
    // 0x9bc718: add             SP, SP, #0x10
    // 0x9bc71c: r1 = 1
    //     0x9bc71c: mov             x1, #1
    // 0x9bc720: r0 = AllocateContext()
    //     0x9bc720: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bc724: mov             x1, x0
    // 0x9bc728: ldr             x0, [fp, #0x18]
    // 0x9bc72c: StoreField: r1->field_f = r0
    //     0x9bc72c: stur            w0, [x1, #0xf]
    // 0x9bc730: mov             x2, x1
    // 0x9bc734: r1 = Function '_handleTapDown@489320628':.
    //     0x9bc734: add             x1, PP, #0x56, lsl #12  ; [pp+0x56728] AnonymousClosure: (0x9bc93c), of [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject
    //     0x9bc738: ldr             x1, [x1, #0x728]
    // 0x9bc73c: r0 = AllocateClosure()
    //     0x9bc73c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bc740: ldur            x1, [fp, #-8]
    // 0x9bc744: StoreField: r1->field_53 = r0
    //     0x9bc744: stur            w0, [x1, #0x53]
    //     0x9bc748: ldurb           w16, [x1, #-1]
    //     0x9bc74c: ldurb           w17, [x0, #-1]
    //     0x9bc750: and             x16, x17, x16, lsr #2
    //     0x9bc754: tst             x16, HEAP, lsr #32
    //     0x9bc758: b.eq            #0x9bc760
    //     0x9bc75c: bl              #0xd6826c
    // 0x9bc760: r1 = 1
    //     0x9bc760: mov             x1, #1
    // 0x9bc764: r0 = AllocateContext()
    //     0x9bc764: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bc768: mov             x1, x0
    // 0x9bc76c: ldr             x0, [fp, #0x18]
    // 0x9bc770: StoreField: r1->field_f = r0
    //     0x9bc770: stur            w0, [x1, #0xf]
    // 0x9bc774: mov             x2, x1
    // 0x9bc778: r1 = Function '_handleTap@489320628':.
    //     0x9bc778: add             x1, PP, #0x56, lsl #12  ; [pp+0x56730] AnonymousClosure: (0x9bc8f0), of [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject
    //     0x9bc77c: ldr             x1, [x1, #0x730]
    // 0x9bc780: r0 = AllocateClosure()
    //     0x9bc780: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bc784: ldur            x1, [fp, #-8]
    // 0x9bc788: StoreField: r1->field_5b = r0
    //     0x9bc788: stur            w0, [x1, #0x5b]
    //     0x9bc78c: ldurb           w16, [x1, #-1]
    //     0x9bc790: ldurb           w17, [x0, #-1]
    //     0x9bc794: and             x16, x17, x16, lsr #2
    //     0x9bc798: tst             x16, HEAP, lsr #32
    //     0x9bc79c: b.eq            #0x9bc7a4
    //     0x9bc7a0: bl              #0xd6826c
    // 0x9bc7a4: mov             x0, x1
    // 0x9bc7a8: ldr             x1, [fp, #0x18]
    // 0x9bc7ac: StoreField: r1->field_83 = r0
    //     0x9bc7ac: stur            w0, [x1, #0x83]
    //     0x9bc7b0: ldurb           w16, [x1, #-1]
    //     0x9bc7b4: ldurb           w17, [x0, #-1]
    //     0x9bc7b8: and             x16, x17, x16, lsr #2
    //     0x9bc7bc: tst             x16, HEAP, lsr #32
    //     0x9bc7c0: b.eq            #0x9bc7c8
    //     0x9bc7c4: bl              #0xd6826c
    // 0x9bc7c8: r0 = LongPressGestureRecognizer()
    //     0x9bc7c8: bl              #0x888964  ; AllocateLongPressGestureRecognizerStub -> LongPressGestureRecognizer (size=0xa8)
    // 0x9bc7cc: stur            x0, [fp, #-8]
    // 0x9bc7d0: SaveReg r0
    //     0x9bc7d0: str             x0, [SP, #-8]!
    // 0x9bc7d4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9bc7d4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9bc7d8: r0 = LongPressGestureRecognizer()
    //     0x9bc7d8: bl              #0x8426d4  ; [package:flutter/src/gestures/long_press.dart] LongPressGestureRecognizer::LongPressGestureRecognizer
    // 0x9bc7dc: add             SP, SP, #8
    // 0x9bc7e0: r1 = 1
    //     0x9bc7e0: mov             x1, #1
    // 0x9bc7e4: r0 = AllocateContext()
    //     0x9bc7e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9bc7e8: mov             x1, x0
    // 0x9bc7ec: ldr             x0, [fp, #0x18]
    // 0x9bc7f0: StoreField: r1->field_f = r0
    //     0x9bc7f0: stur            w0, [x1, #0xf]
    // 0x9bc7f4: mov             x2, x1
    // 0x9bc7f8: r1 = Function '_handleLongPress@489320628':.
    //     0x9bc7f8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56738] AnonymousClosure: (0x9bc860), of [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject
    //     0x9bc7fc: ldr             x1, [x1, #0x738]
    // 0x9bc800: r0 = AllocateClosure()
    //     0x9bc800: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9bc804: ldur            x1, [fp, #-8]
    // 0x9bc808: StoreField: r1->field_57 = r0
    //     0x9bc808: stur            w0, [x1, #0x57]
    //     0x9bc80c: ldurb           w16, [x1, #-1]
    //     0x9bc810: ldurb           w17, [x0, #-1]
    //     0x9bc814: and             x16, x17, x16, lsr #2
    //     0x9bc818: tst             x16, HEAP, lsr #32
    //     0x9bc81c: b.eq            #0x9bc824
    //     0x9bc820: bl              #0xd6826c
    // 0x9bc824: mov             x0, x1
    // 0x9bc828: ldr             x1, [fp, #0x18]
    // 0x9bc82c: StoreField: r1->field_87 = r0
    //     0x9bc82c: stur            w0, [x1, #0x87]
    //     0x9bc830: ldurb           w16, [x1, #-1]
    //     0x9bc834: ldurb           w17, [x0, #-1]
    //     0x9bc838: and             x16, x17, x16, lsr #2
    //     0x9bc83c: tst             x16, HEAP, lsr #32
    //     0x9bc840: b.eq            #0x9bc848
    //     0x9bc844: bl              #0xd6826c
    // 0x9bc848: r0 = Null
    //     0x9bc848: mov             x0, NULL
    // 0x9bc84c: LeaveFrame
    //     0x9bc84c: mov             SP, fp
    //     0x9bc850: ldp             fp, lr, [SP], #0x10
    // 0x9bc854: ret
    //     0x9bc854: ret             
    // 0x9bc858: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc858: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc85c: b               #0x9bc6d8
  }
  [closure] void _handleLongPress(dynamic) {
    // ** addr: 0x9bc860, size: 0x4c
    // 0x9bc860: EnterFrame
    //     0x9bc860: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc864: mov             fp, SP
    // 0x9bc868: ldr             x0, [fp, #0x10]
    // 0x9bc86c: LoadField: r1 = r0->field_17
    //     0x9bc86c: ldur            w1, [x0, #0x17]
    // 0x9bc870: DecompressPointer r1
    //     0x9bc870: add             x1, x1, HEAP, lsl #32
    // 0x9bc874: CheckStackOverflow
    //     0x9bc874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc878: cmp             SP, x16
    //     0x9bc87c: b.ls            #0x9bc8a4
    // 0x9bc880: LoadField: r0 = r1->field_f
    //     0x9bc880: ldur            w0, [x1, #0xf]
    // 0x9bc884: DecompressPointer r0
    //     0x9bc884: add             x0, x0, HEAP, lsl #32
    // 0x9bc888: SaveReg r0
    //     0x9bc888: str             x0, [SP, #-8]!
    // 0x9bc88c: r0 = handleLongPress()
    //     0x9bc88c: bl              #0x9bc8ac  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleLongPress
    // 0x9bc890: add             SP, SP, #8
    // 0x9bc894: r0 = Null
    //     0x9bc894: mov             x0, NULL
    // 0x9bc898: LeaveFrame
    //     0x9bc898: mov             SP, fp
    //     0x9bc89c: ldp             fp, lr, [SP], #0x10
    // 0x9bc8a0: ret
    //     0x9bc8a0: ret             
    // 0x9bc8a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc8a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc8a8: b               #0x9bc880
  }
  _ handleLongPress(/* No info */) {
    // ** addr: 0x9bc8ac, size: 0x44
    // 0x9bc8ac: EnterFrame
    //     0x9bc8ac: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc8b0: mov             fp, SP
    // 0x9bc8b4: CheckStackOverflow
    //     0x9bc8b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc8b8: cmp             SP, x16
    //     0x9bc8bc: b.ls            #0x9bc8e8
    // 0x9bc8c0: ldr             x16, [fp, #0x10]
    // 0x9bc8c4: r30 = Instance_SelectionChangedCause
    //     0x9bc8c4: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x9bc8c8: ldr             lr, [lr, #0x6b0]
    // 0x9bc8cc: stp             lr, x16, [SP, #-0x10]!
    // 0x9bc8d0: r0 = selectWord()
    //     0x9bc8d0: bl              #0x83a30c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWord
    // 0x9bc8d4: add             SP, SP, #0x10
    // 0x9bc8d8: r0 = Null
    //     0x9bc8d8: mov             x0, NULL
    // 0x9bc8dc: LeaveFrame
    //     0x9bc8dc: mov             SP, fp
    //     0x9bc8e0: ldp             fp, lr, [SP], #0x10
    // 0x9bc8e4: ret
    //     0x9bc8e4: ret             
    // 0x9bc8e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc8e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc8ec: b               #0x9bc8c0
  }
  [closure] void _handleTap(dynamic) {
    // ** addr: 0x9bc8f0, size: 0x4c
    // 0x9bc8f0: EnterFrame
    //     0x9bc8f0: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc8f4: mov             fp, SP
    // 0x9bc8f8: ldr             x0, [fp, #0x10]
    // 0x9bc8fc: LoadField: r1 = r0->field_17
    //     0x9bc8fc: ldur            w1, [x0, #0x17]
    // 0x9bc900: DecompressPointer r1
    //     0x9bc900: add             x1, x1, HEAP, lsl #32
    // 0x9bc904: CheckStackOverflow
    //     0x9bc904: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc908: cmp             SP, x16
    //     0x9bc90c: b.ls            #0x9bc934
    // 0x9bc910: LoadField: r0 = r1->field_f
    //     0x9bc910: ldur            w0, [x1, #0xf]
    // 0x9bc914: DecompressPointer r0
    //     0x9bc914: add             x0, x0, HEAP, lsl #32
    // 0x9bc918: SaveReg r0
    //     0x9bc918: str             x0, [SP, #-8]!
    // 0x9bc91c: r0 = selectPosition()
    //     0x9bc91c: bl              #0x83c58c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPosition
    // 0x9bc920: add             SP, SP, #8
    // 0x9bc924: r0 = Null
    //     0x9bc924: mov             x0, NULL
    // 0x9bc928: LeaveFrame
    //     0x9bc928: mov             SP, fp
    //     0x9bc92c: ldp             fp, lr, [SP], #0x10
    // 0x9bc930: ret
    //     0x9bc930: ret             
    // 0x9bc934: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc934: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc938: b               #0x9bc910
  }
  [closure] void _handleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x9bc93c, size: 0x50
    // 0x9bc93c: EnterFrame
    //     0x9bc93c: stp             fp, lr, [SP, #-0x10]!
    //     0x9bc940: mov             fp, SP
    // 0x9bc944: ldr             x0, [fp, #0x18]
    // 0x9bc948: LoadField: r1 = r0->field_17
    //     0x9bc948: ldur            w1, [x0, #0x17]
    // 0x9bc94c: DecompressPointer r1
    //     0x9bc94c: add             x1, x1, HEAP, lsl #32
    // 0x9bc950: CheckStackOverflow
    //     0x9bc950: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bc954: cmp             SP, x16
    //     0x9bc958: b.ls            #0x9bc984
    // 0x9bc95c: LoadField: r0 = r1->field_f
    //     0x9bc95c: ldur            w0, [x1, #0xf]
    // 0x9bc960: DecompressPointer r0
    //     0x9bc960: add             x0, x0, HEAP, lsl #32
    // 0x9bc964: ldr             x16, [fp, #0x10]
    // 0x9bc968: stp             x16, x0, [SP, #-0x10]!
    // 0x9bc96c: r0 = handleTapDown()
    //     0x9bc96c: bl              #0x83ca50  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleTapDown
    // 0x9bc970: add             SP, SP, #0x10
    // 0x9bc974: r0 = Null
    //     0x9bc974: mov             x0, NULL
    // 0x9bc978: LeaveFrame
    //     0x9bc978: mov             SP, fp
    //     0x9bc97c: ldp             fp, lr, [SP], #0x10
    // 0x9bc980: ret
    //     0x9bc980: ret             
    // 0x9bc984: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bc984: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bc988: b               #0x9bc95c
  }
  _ detach(/* No info */) {
    // ** addr: 0xa68b14, size: 0x9c
    // 0xa68b14: EnterFrame
    //     0xa68b14: stp             fp, lr, [SP, #-0x10]!
    //     0xa68b18: mov             fp, SP
    // 0xa68b1c: CheckStackOverflow
    //     0xa68b1c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa68b20: cmp             SP, x16
    //     0xa68b24: b.ls            #0xa68b90
    // 0xa68b28: ldr             x0, [fp, #0x10]
    // 0xa68b2c: LoadField: r1 = r0->field_83
    //     0xa68b2c: ldur            w1, [x0, #0x83]
    // 0xa68b30: DecompressPointer r1
    //     0xa68b30: add             x1, x1, HEAP, lsl #32
    // 0xa68b34: r16 = Sentinel
    //     0xa68b34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa68b38: cmp             w1, w16
    // 0xa68b3c: b.eq            #0xa68b98
    // 0xa68b40: SaveReg r1
    //     0xa68b40: str             x1, [SP, #-8]!
    // 0xa68b44: r0 = dispose()
    //     0xa68b44: bl              #0xbd924c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::dispose
    // 0xa68b48: add             SP, SP, #8
    // 0xa68b4c: ldr             x0, [fp, #0x10]
    // 0xa68b50: LoadField: r1 = r0->field_87
    //     0xa68b50: ldur            w1, [x0, #0x87]
    // 0xa68b54: DecompressPointer r1
    //     0xa68b54: add             x1, x1, HEAP, lsl #32
    // 0xa68b58: r16 = Sentinel
    //     0xa68b58: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa68b5c: cmp             w1, w16
    // 0xa68b60: b.eq            #0xa68ba4
    // 0xa68b64: SaveReg r1
    //     0xa68b64: str             x1, [SP, #-8]!
    // 0xa68b68: r0 = dispose()
    //     0xa68b68: bl              #0xbd924c  ; [package:flutter/src/gestures/recognizer.dart] PrimaryPointerGestureRecognizer::dispose
    // 0xa68b6c: add             SP, SP, #8
    // 0xa68b70: ldr             x16, [fp, #0x10]
    // 0xa68b74: SaveReg r16
    //     0xa68b74: str             x16, [SP, #-8]!
    // 0xa68b78: r0 = detach()
    //     0xa68b78: bl              #0xa68bb0  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin::detach
    // 0xa68b7c: add             SP, SP, #8
    // 0xa68b80: r0 = Null
    //     0xa68b80: mov             x0, NULL
    // 0xa68b84: LeaveFrame
    //     0xa68b84: mov             SP, fp
    //     0xa68b88: ldp             fp, lr, [SP], #0x10
    // 0xa68b8c: ret
    //     0xa68b8c: ret             
    // 0xa68b90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa68b90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa68b94: b               #0xa68b28
    // 0xa68b98: r9 = _tap
    //     0xa68b98: add             x9, PP, #0x56, lsl #12  ; [pp+0x56718] Field <ExtendedTextSelectionRenderObject._tap@489320628>: late (offset: 0x84)
    //     0xa68b9c: ldr             x9, [x9, #0x718]
    // 0xa68ba0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa68ba0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa68ba4: r9 = _longPress
    //     0xa68ba4: add             x9, PP, #0x56, lsl #12  ; [pp+0x56720] Field <ExtendedTextSelectionRenderObject._longPress@489320628>: late (offset: 0x88)
    //     0xa68ba8: ldr             x9, [x9, #0x720]
    // 0xa68bac: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa68bac: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ getWordBoundary(/* No info */) {
    // ** addr: 0xc535ac, size: 0x44
    // 0xc535ac: EnterFrame
    //     0xc535ac: stp             fp, lr, [SP, #-0x10]!
    //     0xc535b0: mov             fp, SP
    // 0xc535b4: CheckStackOverflow
    //     0xc535b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc535b8: cmp             SP, x16
    //     0xc535bc: b.ls            #0xc535e8
    // 0xc535c0: ldr             x0, [fp, #0x18]
    // 0xc535c4: LoadField: r1 = r0->field_eb
    //     0xc535c4: ldur            w1, [x0, #0xeb]
    // 0xc535c8: DecompressPointer r1
    //     0xc535c8: add             x1, x1, HEAP, lsl #32
    // 0xc535cc: ldr             x16, [fp, #0x10]
    // 0xc535d0: stp             x16, x1, [SP, #-0x10]!
    // 0xc535d4: r0 = getWordBoundary()
    //     0xc535d4: bl              #0x83bafc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getWordBoundary
    // 0xc535d8: add             SP, SP, #0x10
    // 0xc535dc: LeaveFrame
    //     0xc535dc: mov             SP, fp
    //     0xc535e0: ldp             fp, lr, [SP], #0x10
    // 0xc535e4: ret
    //     0xc535e4: ret             
    // 0xc535e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc535e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc535ec: b               #0xc535c0
  }
  _ getLineAtOffset(/* No info */) {
    // ** addr: 0xc53654, size: 0xa4
    // 0xc53654: EnterFrame
    //     0xc53654: stp             fp, lr, [SP, #-0x10]!
    //     0xc53658: mov             fp, SP
    // 0xc5365c: AllocStack(0x10)
    //     0xc5365c: sub             SP, SP, #0x10
    // 0xc53660: CheckStackOverflow
    //     0xc53660: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc53664: cmp             SP, x16
    //     0xc53668: b.ls            #0xc536f0
    // 0xc5366c: ldr             x0, [fp, #0x18]
    // 0xc53670: LoadField: r1 = r0->field_eb
    //     0xc53670: ldur            w1, [x0, #0xeb]
    // 0xc53674: DecompressPointer r1
    //     0xc53674: add             x1, x1, HEAP, lsl #32
    // 0xc53678: ldr             x16, [fp, #0x10]
    // 0xc5367c: stp             x16, x1, [SP, #-0x10]!
    // 0xc53680: r0 = getLineBoundary()
    //     0xc53680: bl              #0x7cb748  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getLineBoundary
    // 0xc53684: add             SP, SP, #0x10
    // 0xc53688: LoadField: r1 = r0->field_7
    //     0xc53688: ldur            x1, [x0, #7]
    // 0xc5368c: stur            x1, [fp, #-0x10]
    // 0xc53690: LoadField: r2 = r0->field_f
    //     0xc53690: ldur            x2, [x0, #0xf]
    // 0xc53694: stur            x2, [fp, #-8]
    // 0xc53698: r0 = TextSelection()
    //     0xc53698: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xc5369c: ldur            x1, [fp, #-0x10]
    // 0xc536a0: StoreField: r0->field_17 = r1
    //     0xc536a0: stur            x1, [x0, #0x17]
    // 0xc536a4: ldur            x2, [fp, #-8]
    // 0xc536a8: StoreField: r0->field_1f = r2
    //     0xc536a8: stur            x2, [x0, #0x1f]
    // 0xc536ac: r3 = Instance_TextAffinity
    //     0xc536ac: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xc536b0: StoreField: r0->field_27 = r3
    //     0xc536b0: stur            w3, [x0, #0x27]
    // 0xc536b4: r3 = false
    //     0xc536b4: add             x3, NULL, #0x30  ; false
    // 0xc536b8: StoreField: r0->field_2b = r3
    //     0xc536b8: stur            w3, [x0, #0x2b]
    // 0xc536bc: cmp             x1, x2
    // 0xc536c0: b.ge            #0xc536cc
    // 0xc536c4: mov             x3, x1
    // 0xc536c8: b               #0xc536d0
    // 0xc536cc: mov             x3, x2
    // 0xc536d0: cmp             x1, x2
    // 0xc536d4: b.ge            #0xc536dc
    // 0xc536d8: mov             x1, x2
    // 0xc536dc: StoreField: r0->field_7 = r3
    //     0xc536dc: stur            x3, [x0, #7]
    // 0xc536e0: StoreField: r0->field_f = r1
    //     0xc536e0: stur            x1, [x0, #0xf]
    // 0xc536e4: LeaveFrame
    //     0xc536e4: mov             SP, fp
    //     0xc536e8: ldp             fp, lr, [SP], #0x10
    // 0xc536ec: ret
    //     0xc536ec: ret             
    // 0xc536f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc536f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc536f4: b               #0xc5366c
  }
  dynamic handleSetSelection(dynamic) {
    // ** addr: 0xcf06d8, size: 0x18
    // 0xcf06d8: r4 = 0
    //     0xcf06d8: mov             x4, #0
    // 0xcf06dc: r1 = Function 'handleSetSelection':.
    //     0xcf06dc: add             x17, PP, #0x56, lsl #12  ; [pp+0x56900] AnonymousClosure: (0xcf06f0), in [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleSetSelection (0xcf073c)
    //     0xcf06e0: ldr             x1, [x17, #0x900]
    // 0xcf06e4: r24 = BuildNonGenericMethodExtractorStub
    //     0xcf06e4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xcf06e8: LoadField: r0 = r24->field_17
    //     0xcf06e8: ldur            x0, [x24, #0x17]
    // 0xcf06ec: br              x0
  }
  [closure] void handleSetSelection(dynamic, TextSelection) {
    // ** addr: 0xcf06f0, size: 0x4c
    // 0xcf06f0: EnterFrame
    //     0xcf06f0: stp             fp, lr, [SP, #-0x10]!
    //     0xcf06f4: mov             fp, SP
    // 0xcf06f8: ldr             x0, [fp, #0x18]
    // 0xcf06fc: LoadField: r1 = r0->field_17
    //     0xcf06fc: ldur            w1, [x0, #0x17]
    // 0xcf0700: DecompressPointer r1
    //     0xcf0700: add             x1, x1, HEAP, lsl #32
    // 0xcf0704: CheckStackOverflow
    //     0xcf0704: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0708: cmp             SP, x16
    //     0xcf070c: b.ls            #0xcf0734
    // 0xcf0710: LoadField: r0 = r1->field_f
    //     0xcf0710: ldur            w0, [x1, #0xf]
    // 0xcf0714: DecompressPointer r0
    //     0xcf0714: add             x0, x0, HEAP, lsl #32
    // 0xcf0718: ldr             x16, [fp, #0x10]
    // 0xcf071c: stp             x16, x0, [SP, #-0x10]!
    // 0xcf0720: r0 = handleSetSelection()
    //     0xcf0720: bl              #0xcf073c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleSetSelection
    // 0xcf0724: add             SP, SP, #0x10
    // 0xcf0728: LeaveFrame
    //     0xcf0728: mov             SP, fp
    //     0xcf072c: ldp             fp, lr, [SP], #0x10
    // 0xcf0730: ret
    //     0xcf0730: ret             
    // 0xcf0734: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0734: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0738: b               #0xcf0710
  }
  _ handleSetSelection(/* No info */) {
    // ** addr: 0xcf073c, size: 0x4c
    // 0xcf073c: EnterFrame
    //     0xcf073c: stp             fp, lr, [SP, #-0x10]!
    //     0xcf0740: mov             fp, SP
    // 0xcf0744: CheckStackOverflow
    //     0xcf0744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcf0748: cmp             SP, x16
    //     0xcf074c: b.ls            #0xcf0780
    // 0xcf0750: ldr             x16, [fp, #0x18]
    // 0xcf0754: ldr             lr, [fp, #0x10]
    // 0xcf0758: stp             lr, x16, [SP, #-0x10]!
    // 0xcf075c: r16 = Instance_SelectionChangedCause
    //     0xcf075c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b8] Obj!SelectionChangedCause@b63e71
    //     0xcf0760: ldr             x16, [x16, #0x6b8]
    // 0xcf0764: SaveReg r16
    //     0xcf0764: str             x16, [SP, #-8]!
    // 0xcf0768: r0 = setSelection()
    //     0xcf0768: bl              #0x839de8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::setSelection
    // 0xcf076c: add             SP, SP, #0x18
    // 0xcf0770: r0 = Null
    //     0xcf0770: mov             x0, NULL
    // 0xcf0774: LeaveFrame
    //     0xcf0774: mov             SP, fp
    //     0xcf0778: ldp             fp, lr, [SP], #0x10
    // 0xcf077c: ret
    //     0xcf077c: ret             
    // 0xcf0780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcf0780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcf0784: b               #0xcf0750
  }
}

// lib: , url: package:extended_text_library/src/render_object/extended_text_render_box.dart

// class id: 1048981, size: 0x8
class :: {
}

// class id: 2535, size: 0x84, field offset: 0x70
abstract class ExtendedTextRenderBox extends _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin {

  late List<PlaceholderSpan> _placeholderSpans; // offset: 0x7c

  _ getCaretOffset(/* No info */) {
    // ** addr: 0x5202b0, size: 0x510
    // 0x5202b0: EnterFrame
    //     0x5202b0: stp             fp, lr, [SP, #-0x10]!
    //     0x5202b4: mov             fp, SP
    // 0x5202b8: AllocStack(0x60)
    //     0x5202b8: sub             SP, SP, #0x60
    // 0x5202bc: SetupParameters(ExtendedTextRenderBox this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, dynamic _ /* r5, fp-0x18 */, {dynamic caretHeightCallBack = Null /* r6, fp-0x10 */, dynamic effectiveOffset = Null /* r0 */})
    //     0x5202bc: mov             x0, x4
    //     0x5202c0: ldur            w1, [x0, #0x13]
    //     0x5202c4: add             x1, x1, HEAP, lsl #32
    //     0x5202c8: sub             x2, x1, #6
    //     0x5202cc: add             x3, fp, w2, sxtw #2
    //     0x5202d0: ldr             x3, [x3, #0x20]
    //     0x5202d4: stur            x3, [fp, #-0x28]
    //     0x5202d8: add             x4, fp, w2, sxtw #2
    //     0x5202dc: ldr             x4, [x4, #0x18]
    //     0x5202e0: stur            x4, [fp, #-0x20]
    //     0x5202e4: add             x5, fp, w2, sxtw #2
    //     0x5202e8: ldr             x5, [x5, #0x10]
    //     0x5202ec: stur            x5, [fp, #-0x18]
    //     0x5202f0: ldur            w2, [x0, #0x1f]
    //     0x5202f4: add             x2, x2, HEAP, lsl #32
    //     0x5202f8: add             x16, PP, #0x37, lsl #12  ; [pp+0x37358] "caretHeightCallBack"
    //     0x5202fc: ldr             x16, [x16, #0x358]
    //     0x520300: cmp             w2, w16
    //     0x520304: b.ne            #0x520328
    //     0x520308: ldur            w2, [x0, #0x23]
    //     0x52030c: add             x2, x2, HEAP, lsl #32
    //     0x520310: sub             w6, w1, w2
    //     0x520314: add             x2, fp, w6, sxtw #2
    //     0x520318: ldr             x2, [x2, #8]
    //     0x52031c: mov             x6, x2
    //     0x520320: mov             x2, #1
    //     0x520324: b               #0x520330
    //     0x520328: mov             x6, NULL
    //     0x52032c: mov             x2, #0
    //     0x520330: stur            x6, [fp, #-0x10]
    //     0x520334: lsl             x7, x2, #1
    //     0x520338: lsl             w2, w7, #1
    //     0x52033c: add             w7, w2, #8
    //     0x520340: add             x16, x0, w7, sxtw #1
    //     0x520344: ldur            w8, [x16, #0xf]
    //     0x520348: add             x8, x8, HEAP, lsl #32
    //     0x52034c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37360] "effectiveOffset"
    //     0x520350: ldr             x16, [x16, #0x360]
    //     0x520354: cmp             w8, w16
    //     0x520358: b.ne            #0x520380
    //     0x52035c: add             w7, w2, #0xa
    //     0x520360: add             x16, x0, w7, sxtw #1
    //     0x520364: ldur            w2, [x16, #0xf]
    //     0x520368: add             x2, x2, HEAP, lsl #32
    //     0x52036c: sub             w0, w1, w2
    //     0x520370: add             x1, fp, w0, sxtw #2
    //     0x520374: ldr             x1, [x1, #8]
    //     0x520378: mov             x0, x1
    //     0x52037c: b               #0x520384
    //     0x520380: mov             x0, NULL
    // 0x520384: CheckStackOverflow
    //     0x520384: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x520388: cmp             SP, x16
    //     0x52038c: b.ls            #0x520780
    // 0x520390: cmp             w0, NULL
    // 0x520394: b.ne            #0x52039c
    // 0x520398: r0 = Instance_Offset
    //     0x520398: ldr             x0, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x52039c: stur            x0, [fp, #-8]
    // 0x5203a0: SaveReg r3
    //     0x5203a0: str             x3, [SP, #-8]!
    // 0x5203a4: r0 = hasPlaceholderSpan()
    //     0x5203a4: bl              #0x5223a0  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::hasPlaceholderSpan
    // 0x5203a8: add             SP, SP, #8
    // 0x5203ac: tbnz            w0, #4, #0x520740
    // 0x5203b0: ldur            x0, [fp, #-0x28]
    // 0x5203b4: ldur            x1, [fp, #-0x20]
    // 0x5203b8: LoadField: r2 = r1->field_7
    //     0x5203b8: ldur            x2, [x1, #7]
    // 0x5203bc: stur            x2, [fp, #-0x48]
    // 0x5203c0: LoadField: r3 = r0->field_eb
    //     0x5203c0: ldur            w3, [x0, #0xeb]
    // 0x5203c4: DecompressPointer r3
    //     0x5203c4: add             x3, x3, HEAP, lsl #32
    // 0x5203c8: stur            x3, [fp, #-0x40]
    // 0x5203cc: add             x4, x2, #1
    // 0x5203d0: stur            x4, [fp, #-0x38]
    // 0x5203d4: LoadField: r5 = r1->field_f
    //     0x5203d4: ldur            w5, [x1, #0xf]
    // 0x5203d8: DecompressPointer r5
    //     0x5203d8: add             x5, x5, HEAP, lsl #32
    // 0x5203dc: stur            x5, [fp, #-0x30]
    // 0x5203e0: r0 = TextSelection()
    //     0x5203e0: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x5203e4: mov             x1, x0
    // 0x5203e8: ldur            x0, [fp, #-0x48]
    // 0x5203ec: stur            x1, [fp, #-0x50]
    // 0x5203f0: StoreField: r1->field_17 = r0
    //     0x5203f0: stur            x0, [x1, #0x17]
    // 0x5203f4: ldur            x2, [fp, #-0x38]
    // 0x5203f8: StoreField: r1->field_1f = r2
    //     0x5203f8: stur            x2, [x1, #0x1f]
    // 0x5203fc: ldur            x3, [fp, #-0x30]
    // 0x520400: StoreField: r1->field_27 = r3
    //     0x520400: stur            w3, [x1, #0x27]
    // 0x520404: r4 = false
    //     0x520404: add             x4, NULL, #0x30  ; false
    // 0x520408: StoreField: r1->field_2b = r4
    //     0x520408: stur            w4, [x1, #0x2b]
    // 0x52040c: cmp             x0, x2
    // 0x520410: b.ge            #0x52041c
    // 0x520414: mov             x5, x0
    // 0x520418: b               #0x520420
    // 0x52041c: mov             x5, x2
    // 0x520420: cmp             x0, x2
    // 0x520424: b.lt            #0x52042c
    // 0x520428: mov             x2, x0
    // 0x52042c: StoreField: r1->field_7 = r5
    //     0x52042c: stur            x5, [x1, #7]
    // 0x520430: StoreField: r1->field_f = r2
    //     0x520430: stur            x2, [x1, #0xf]
    // 0x520434: ldur            x16, [fp, #-0x28]
    // 0x520438: SaveReg r16
    //     0x520438: str             x16, [SP, #-8]!
    // 0x52043c: r0 = selectionWidthStyle()
    //     0x52043c: bl              #0x522388  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::selectionWidthStyle
    // 0x520440: add             SP, SP, #8
    // 0x520444: ldur            x16, [fp, #-0x28]
    // 0x520448: SaveReg r16
    //     0x520448: str             x16, [SP, #-8]!
    // 0x52044c: r0 = selectionHeightStyle()
    //     0x52044c: bl              #0x52237c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::selectionHeightStyle
    // 0x520450: add             SP, SP, #8
    // 0x520454: ldur            x16, [fp, #-0x40]
    // 0x520458: ldur            lr, [fp, #-0x50]
    // 0x52045c: stp             lr, x16, [SP, #-0x10]!
    // 0x520460: r0 = getBoxesForSelection()
    //     0x520460: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x520464: add             SP, SP, #0x10
    // 0x520468: LoadField: r1 = r0->field_b
    //     0x520468: ldur            w1, [x0, #0xb]
    // 0x52046c: DecompressPointer r1
    //     0x52046c: add             x1, x1, HEAP, lsl #32
    // 0x520470: cbz             w1, #0x520560
    // 0x520474: ldur            x1, [fp, #-0x10]
    // 0x520478: SaveReg r0
    //     0x520478: str             x0, [SP, #-8]!
    // 0x52047c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x52047c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x520480: r0 = toList()
    //     0x520480: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0x520484: add             SP, SP, #8
    // 0x520488: r1 = LoadClassIdInstr(r0)
    //     0x520488: ldur            x1, [x0, #-1]
    //     0x52048c: ubfx            x1, x1, #0xc, #0x14
    // 0x520490: SaveReg r0
    //     0x520490: str             x0, [SP, #-8]!
    // 0x520494: mov             x0, x1
    // 0x520498: r0 = GDT[cid_x0 + 0xfe03]()
    //     0x520498: mov             x17, #0xfe03
    //     0x52049c: add             lr, x0, x17
    //     0x5204a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5204a4: blr             lr
    // 0x5204a8: add             SP, SP, #8
    // 0x5204ac: SaveReg r0
    //     0x5204ac: str             x0, [SP, #-8]!
    // 0x5204b0: r0 = toRect()
    //     0x5204b0: bl              #0x52231c  ; [dart:ui] TextBox::toRect
    // 0x5204b4: add             SP, SP, #8
    // 0x5204b8: mov             x1, x0
    // 0x5204bc: ldur            x0, [fp, #-0x10]
    // 0x5204c0: stur            x1, [fp, #-0x50]
    // 0x5204c4: cmp             w0, NULL
    // 0x5204c8: b.ne            #0x5204d4
    // 0x5204cc: mov             x0, x1
    // 0x5204d0: b               #0x520520
    // 0x5204d4: LoadField: d0 = r1->field_1f
    //     0x5204d4: ldur            d0, [x1, #0x1f]
    // 0x5204d8: LoadField: d1 = r1->field_f
    //     0x5204d8: ldur            d1, [x1, #0xf]
    // 0x5204dc: fsub            d2, d0, d1
    // 0x5204e0: r2 = inline_Allocate_Double()
    //     0x5204e0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x5204e4: add             x2, x2, #0x10
    //     0x5204e8: cmp             x3, x2
    //     0x5204ec: b.ls            #0x520788
    //     0x5204f0: str             x2, [THR, #0x60]  ; THR::top
    //     0x5204f4: sub             x2, x2, #0xf
    //     0x5204f8: mov             x3, #0xd108
    //     0x5204fc: movk            x3, #3, lsl #16
    //     0x520500: stur            x3, [x2, #-1]
    // 0x520504: StoreField: r2->field_7 = d2
    //     0x520504: stur            d2, [x2, #7]
    // 0x520508: stp             x2, x0, [SP, #-0x10]!
    // 0x52050c: ClosureCall
    //     0x52050c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x520510: ldur            x2, [x0, #0x1f]
    //     0x520514: blr             x2
    // 0x520518: add             SP, SP, #0x10
    // 0x52051c: ldur            x0, [fp, #-0x50]
    // 0x520520: LoadField: d0 = r0->field_7
    //     0x520520: ldur            d0, [x0, #7]
    // 0x520524: stur            d0, [fp, #-0x60]
    // 0x520528: LoadField: d1 = r0->field_f
    //     0x520528: ldur            d1, [x0, #0xf]
    // 0x52052c: stur            d1, [fp, #-0x58]
    // 0x520530: r0 = Offset()
    //     0x520530: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520534: ldur            d0, [fp, #-0x60]
    // 0x520538: StoreField: r0->field_7 = d0
    //     0x520538: stur            d0, [x0, #7]
    // 0x52053c: ldur            d0, [fp, #-0x58]
    // 0x520540: StoreField: r0->field_f = d0
    //     0x520540: stur            d0, [x0, #0xf]
    // 0x520544: ldur            x16, [fp, #-8]
    // 0x520548: stp             x16, x0, [SP, #-0x10]!
    // 0x52054c: r0 = +()
    //     0x52054c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x520550: add             SP, SP, #0x10
    // 0x520554: LeaveFrame
    //     0x520554: mov             SP, fp
    //     0x520558: ldp             fp, lr, [SP], #0x10
    // 0x52055c: ret
    //     0x52055c: ret             
    // 0x520560: ldur            x0, [fp, #-0x10]
    // 0x520564: ldur            x1, [fp, #-0x48]
    // 0x520568: cmp             x1, #0
    // 0x52056c: r16 = true
    //     0x52056c: add             x16, NULL, #0x20  ; true
    // 0x520570: r17 = false
    //     0x520570: add             x17, NULL, #0x30  ; false
    // 0x520574: csel            x2, x16, x17, le
    // 0x520578: stur            x2, [fp, #-0x50]
    // 0x52057c: tbnz            w2, #4, #0x520588
    // 0x520580: r3 = 1
    //     0x520580: mov             x3, #1
    // 0x520584: b               #0x52058c
    // 0x520588: mov             x3, x1
    // 0x52058c: ldur            x1, [fp, #-0x30]
    // 0x520590: stur            x3, [fp, #-0x48]
    // 0x520594: sub             x4, x3, #1
    // 0x520598: stur            x4, [fp, #-0x38]
    // 0x52059c: r0 = TextSelection()
    //     0x52059c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x5205a0: mov             x1, x0
    // 0x5205a4: ldur            x0, [fp, #-0x38]
    // 0x5205a8: StoreField: r1->field_17 = r0
    //     0x5205a8: stur            x0, [x1, #0x17]
    // 0x5205ac: ldur            x2, [fp, #-0x48]
    // 0x5205b0: StoreField: r1->field_1f = r2
    //     0x5205b0: stur            x2, [x1, #0x1f]
    // 0x5205b4: ldur            x3, [fp, #-0x30]
    // 0x5205b8: StoreField: r1->field_27 = r3
    //     0x5205b8: stur            w3, [x1, #0x27]
    // 0x5205bc: r3 = false
    //     0x5205bc: add             x3, NULL, #0x30  ; false
    // 0x5205c0: StoreField: r1->field_2b = r3
    //     0x5205c0: stur            w3, [x1, #0x2b]
    // 0x5205c4: cmp             x0, x2
    // 0x5205c8: r16 = true
    //     0x5205c8: add             x16, NULL, #0x20  ; true
    // 0x5205cc: r17 = false
    //     0x5205cc: add             x17, NULL, #0x30  ; false
    // 0x5205d0: csel            x3, x16, x17, lt
    // 0x5205d4: tbnz            w3, #4, #0x5205e0
    // 0x5205d8: mov             x4, x0
    // 0x5205dc: b               #0x5205e4
    // 0x5205e0: mov             x4, x2
    // 0x5205e4: tbnz            w3, #4, #0x5205ec
    // 0x5205e8: mov             x0, x2
    // 0x5205ec: StoreField: r1->field_7 = r4
    //     0x5205ec: stur            x4, [x1, #7]
    // 0x5205f0: StoreField: r1->field_f = r0
    //     0x5205f0: stur            x0, [x1, #0xf]
    // 0x5205f4: ldur            x16, [fp, #-0x40]
    // 0x5205f8: stp             x1, x16, [SP, #-0x10]!
    // 0x5205fc: r0 = getBoxesForSelection()
    //     0x5205fc: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0x520600: add             SP, SP, #0x10
    // 0x520604: LoadField: r1 = r0->field_b
    //     0x520604: ldur            w1, [x0, #0xb]
    // 0x520608: DecompressPointer r1
    //     0x520608: add             x1, x1, HEAP, lsl #32
    // 0x52060c: cbz             w1, #0x520740
    // 0x520610: ldur            x1, [fp, #-0x10]
    // 0x520614: SaveReg r0
    //     0x520614: str             x0, [SP, #-8]!
    // 0x520618: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x520618: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x52061c: r0 = toList()
    //     0x52061c: bl              #0x791df4  ; [dart:core] _GrowableList::toList
    // 0x520620: add             SP, SP, #8
    // 0x520624: r1 = LoadClassIdInstr(r0)
    //     0x520624: ldur            x1, [x0, #-1]
    //     0x520628: ubfx            x1, x1, #0xc, #0x14
    // 0x52062c: SaveReg r0
    //     0x52062c: str             x0, [SP, #-8]!
    // 0x520630: mov             x0, x1
    // 0x520634: r0 = GDT[cid_x0 + 0xfe03]()
    //     0x520634: mov             x17, #0xfe03
    //     0x520638: add             lr, x0, x17
    //     0x52063c: ldr             lr, [x21, lr, lsl #3]
    //     0x520640: blr             lr
    // 0x520644: add             SP, SP, #8
    // 0x520648: SaveReg r0
    //     0x520648: str             x0, [SP, #-8]!
    // 0x52064c: r0 = toRect()
    //     0x52064c: bl              #0x52231c  ; [dart:ui] TextBox::toRect
    // 0x520650: add             SP, SP, #8
    // 0x520654: mov             x1, x0
    // 0x520658: ldur            x0, [fp, #-0x10]
    // 0x52065c: stur            x1, [fp, #-0x30]
    // 0x520660: cmp             w0, NULL
    // 0x520664: b.eq            #0x5206b0
    // 0x520668: LoadField: d0 = r1->field_1f
    //     0x520668: ldur            d0, [x1, #0x1f]
    // 0x52066c: LoadField: d1 = r1->field_f
    //     0x52066c: ldur            d1, [x1, #0xf]
    // 0x520670: fsub            d2, d0, d1
    // 0x520674: r2 = inline_Allocate_Double()
    //     0x520674: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x520678: add             x2, x2, #0x10
    //     0x52067c: cmp             x3, x2
    //     0x520680: b.ls            #0x5207a4
    //     0x520684: str             x2, [THR, #0x60]  ; THR::top
    //     0x520688: sub             x2, x2, #0xf
    //     0x52068c: mov             x3, #0xd108
    //     0x520690: movk            x3, #3, lsl #16
    //     0x520694: stur            x3, [x2, #-1]
    // 0x520698: StoreField: r2->field_7 = d2
    //     0x520698: stur            d2, [x2, #7]
    // 0x52069c: stp             x2, x0, [SP, #-0x10]!
    // 0x5206a0: ClosureCall
    //     0x5206a0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x5206a4: ldur            x2, [x0, #0x1f]
    //     0x5206a8: blr             x2
    // 0x5206ac: add             SP, SP, #0x10
    // 0x5206b0: ldur            x0, [fp, #-0x50]
    // 0x5206b4: tbnz            w0, #4, #0x5206fc
    // 0x5206b8: ldur            x0, [fp, #-0x30]
    // 0x5206bc: LoadField: d0 = r0->field_7
    //     0x5206bc: ldur            d0, [x0, #7]
    // 0x5206c0: stur            d0, [fp, #-0x60]
    // 0x5206c4: LoadField: d1 = r0->field_f
    //     0x5206c4: ldur            d1, [x0, #0xf]
    // 0x5206c8: stur            d1, [fp, #-0x58]
    // 0x5206cc: r0 = Offset()
    //     0x5206cc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x5206d0: ldur            d0, [fp, #-0x60]
    // 0x5206d4: StoreField: r0->field_7 = d0
    //     0x5206d4: stur            d0, [x0, #7]
    // 0x5206d8: ldur            d0, [fp, #-0x58]
    // 0x5206dc: StoreField: r0->field_f = d0
    //     0x5206dc: stur            d0, [x0, #0xf]
    // 0x5206e0: ldur            x16, [fp, #-8]
    // 0x5206e4: stp             x16, x0, [SP, #-0x10]!
    // 0x5206e8: r0 = +()
    //     0x5206e8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x5206ec: add             SP, SP, #0x10
    // 0x5206f0: LeaveFrame
    //     0x5206f0: mov             SP, fp
    //     0x5206f4: ldp             fp, lr, [SP], #0x10
    // 0x5206f8: ret
    //     0x5206f8: ret             
    // 0x5206fc: ldur            x0, [fp, #-0x30]
    // 0x520700: LoadField: d0 = r0->field_17
    //     0x520700: ldur            d0, [x0, #0x17]
    // 0x520704: stur            d0, [fp, #-0x60]
    // 0x520708: LoadField: d1 = r0->field_f
    //     0x520708: ldur            d1, [x0, #0xf]
    // 0x52070c: stur            d1, [fp, #-0x58]
    // 0x520710: r0 = Offset()
    //     0x520710: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x520714: ldur            d0, [fp, #-0x60]
    // 0x520718: StoreField: r0->field_7 = d0
    //     0x520718: stur            d0, [x0, #7]
    // 0x52071c: ldur            d0, [fp, #-0x58]
    // 0x520720: StoreField: r0->field_f = d0
    //     0x520720: stur            d0, [x0, #0xf]
    // 0x520724: ldur            x16, [fp, #-8]
    // 0x520728: stp             x16, x0, [SP, #-0x10]!
    // 0x52072c: r0 = +()
    //     0x52072c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x520730: add             SP, SP, #0x10
    // 0x520734: LeaveFrame
    //     0x520734: mov             SP, fp
    //     0x520738: ldp             fp, lr, [SP], #0x10
    // 0x52073c: ret
    //     0x52073c: ret             
    // 0x520740: ldur            x0, [fp, #-0x28]
    // 0x520744: LoadField: r1 = r0->field_eb
    //     0x520744: ldur            w1, [x0, #0xeb]
    // 0x520748: DecompressPointer r1
    //     0x520748: add             x1, x1, HEAP, lsl #32
    // 0x52074c: ldur            x16, [fp, #-0x20]
    // 0x520750: stp             x16, x1, [SP, #-0x10]!
    // 0x520754: ldur            x16, [fp, #-0x18]
    // 0x520758: SaveReg r16
    //     0x520758: str             x16, [SP, #-8]!
    // 0x52075c: r0 = getOffsetForCaret()
    //     0x52075c: bl              #0x520800  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getOffsetForCaret
    // 0x520760: add             SP, SP, #0x18
    // 0x520764: ldur            x16, [fp, #-8]
    // 0x520768: stp             x16, x0, [SP, #-0x10]!
    // 0x52076c: r0 = +()
    //     0x52076c: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x520770: add             SP, SP, #0x10
    // 0x520774: LeaveFrame
    //     0x520774: mov             SP, fp
    //     0x520778: ldp             fp, lr, [SP], #0x10
    // 0x52077c: ret
    //     0x52077c: ret             
    // 0x520780: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x520780: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x520784: b               #0x520390
    // 0x520788: SaveReg d2
    //     0x520788: str             q2, [SP, #-0x10]!
    // 0x52078c: stp             x0, x1, [SP, #-0x10]!
    // 0x520790: r0 = AllocateDouble()
    //     0x520790: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x520794: mov             x2, x0
    // 0x520798: ldp             x0, x1, [SP], #0x10
    // 0x52079c: RestoreReg d2
    //     0x52079c: ldr             q2, [SP], #0x10
    // 0x5207a0: b               #0x520504
    // 0x5207a4: SaveReg d2
    //     0x5207a4: str             q2, [SP, #-0x10]!
    // 0x5207a8: stp             x0, x1, [SP, #-0x10]!
    // 0x5207ac: r0 = AllocateDouble()
    //     0x5207ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5207b0: mov             x2, x0
    // 0x5207b4: ldp             x0, x1, [SP], #0x10
    // 0x5207b8: RestoreReg d2
    //     0x5207b8: ldr             q2, [SP], #0x10
    // 0x5207bc: b               #0x520698
  }
  get _ hasPlaceholderSpan(/* No info */) {
    // ** addr: 0x5223a0, size: 0x50
    // 0x5223a0: EnterFrame
    //     0x5223a0: stp             fp, lr, [SP, #-0x10]!
    //     0x5223a4: mov             fp, SP
    // 0x5223a8: ldr             x1, [fp, #0x10]
    // 0x5223ac: LoadField: r2 = r1->field_7b
    //     0x5223ac: ldur            w2, [x1, #0x7b]
    // 0x5223b0: DecompressPointer r2
    //     0x5223b0: add             x2, x2, HEAP, lsl #32
    // 0x5223b4: r16 = Sentinel
    //     0x5223b4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5223b8: cmp             w2, w16
    // 0x5223bc: b.eq            #0x5223e4
    // 0x5223c0: LoadField: r1 = r2->field_b
    //     0x5223c0: ldur            w1, [x2, #0xb]
    // 0x5223c4: DecompressPointer r1
    //     0x5223c4: add             x1, x1, HEAP, lsl #32
    // 0x5223c8: cbnz            w1, #0x5223d4
    // 0x5223cc: r0 = false
    //     0x5223cc: add             x0, NULL, #0x30  ; false
    // 0x5223d0: b               #0x5223d8
    // 0x5223d4: r0 = true
    //     0x5223d4: add             x0, NULL, #0x20  ; true
    // 0x5223d8: LeaveFrame
    //     0x5223d8: mov             SP, fp
    //     0x5223dc: ldp             fp, lr, [SP], #0x10
    // 0x5223e0: ret
    //     0x5223e0: ret             
    // 0x5223e4: r9 = _placeholderSpans
    //     0x5223e4: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x5223e8: ldr             x9, [x9, #0x368]
    // 0x5223ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5223ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ computeTextMetricsIfNeeded(/* No info */) {
    // ** addr: 0x522fec, size: 0x140
    // 0x522fec: EnterFrame
    //     0x522fec: stp             fp, lr, [SP, #-0x10]!
    //     0x522ff0: mov             fp, SP
    // 0x522ff4: AllocStack(0x8)
    //     0x522ff4: sub             SP, SP, #8
    // 0x522ff8: CheckStackOverflow
    //     0x522ff8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x522ffc: cmp             SP, x16
    //     0x523000: b.ls            #0x5230f8
    // 0x523004: ldr             x3, [fp, #0x10]
    // 0x523008: LoadField: r4 = r3->field_27
    //     0x523008: ldur            w4, [x3, #0x27]
    // 0x52300c: DecompressPointer r4
    //     0x52300c: add             x4, x4, HEAP, lsl #32
    // 0x523010: stur            x4, [fp, #-8]
    // 0x523014: cmp             w4, NULL
    // 0x523018: b.eq            #0x5230d8
    // 0x52301c: mov             x0, x4
    // 0x523020: r2 = Null
    //     0x523020: mov             x2, NULL
    // 0x523024: r1 = Null
    //     0x523024: mov             x1, NULL
    // 0x523028: r4 = LoadClassIdInstr(r0)
    //     0x523028: ldur            x4, [x0, #-1]
    //     0x52302c: ubfx            x4, x4, #0xc, #0x14
    // 0x523030: sub             x4, x4, #0x80d
    // 0x523034: cmp             x4, #1
    // 0x523038: b.ls            #0x523050
    // 0x52303c: r8 = BoxConstraints
    //     0x52303c: add             x8, PP, #0xb, lsl #12  ; [pp+0xb1d0] Type: BoxConstraints
    //     0x523040: ldr             x8, [x8, #0x1d0]
    // 0x523044: r3 = Null
    //     0x523044: add             x3, PP, #0x37, lsl #12  ; [pp+0x37370] Null
    //     0x523048: ldr             x3, [x3, #0x370]
    // 0x52304c: r0 = BoxConstraints()
    //     0x52304c: bl              #0x5243b8  ; IsType_BoxConstraints_Stub
    // 0x523050: ldur            x0, [fp, #-8]
    // 0x523054: LoadField: d0 = r0->field_7
    //     0x523054: ldur            d0, [x0, #7]
    // 0x523058: LoadField: d1 = r0->field_f
    //     0x523058: ldur            d1, [x0, #0xf]
    // 0x52305c: r0 = inline_Allocate_Double()
    //     0x52305c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x523060: add             x0, x0, #0x10
    //     0x523064: cmp             x1, x0
    //     0x523068: b.ls            #0x523100
    //     0x52306c: str             x0, [THR, #0x60]  ; THR::top
    //     0x523070: sub             x0, x0, #0xf
    //     0x523074: mov             x1, #0xd108
    //     0x523078: movk            x1, #3, lsl #16
    //     0x52307c: stur            x1, [x0, #-1]
    // 0x523080: StoreField: r0->field_7 = d0
    //     0x523080: stur            d0, [x0, #7]
    // 0x523084: r1 = inline_Allocate_Double()
    //     0x523084: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x523088: add             x1, x1, #0x10
    //     0x52308c: cmp             x2, x1
    //     0x523090: b.ls            #0x523110
    //     0x523094: str             x1, [THR, #0x60]  ; THR::top
    //     0x523098: sub             x1, x1, #0xf
    //     0x52309c: mov             x2, #0xd108
    //     0x5230a0: movk            x2, #3, lsl #16
    //     0x5230a4: stur            x2, [x1, #-1]
    // 0x5230a8: StoreField: r1->field_7 = d1
    //     0x5230a8: stur            d1, [x1, #7]
    // 0x5230ac: ldr             x16, [fp, #0x10]
    // 0x5230b0: stp             x0, x16, [SP, #-0x10]!
    // 0x5230b4: SaveReg r1
    //     0x5230b4: str             x1, [SP, #-8]!
    // 0x5230b8: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x5230b8: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x5230bc: ldr             x4, [x4, #0x588]
    // 0x5230c0: r0 = layoutText()
    //     0x5230c0: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x5230c4: add             SP, SP, #0x18
    // 0x5230c8: r0 = Null
    //     0x5230c8: mov             x0, NULL
    // 0x5230cc: LeaveFrame
    //     0x5230cc: mov             SP, fp
    //     0x5230d0: ldp             fp, lr, [SP], #0x10
    // 0x5230d4: ret
    //     0x5230d4: ret             
    // 0x5230d8: r0 = StateError()
    //     0x5230d8: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x5230dc: mov             x1, x0
    // 0x5230e0: r0 = "A RenderObject does not have any constraints before it has been laid out."
    //     0x5230e0: add             x0, PP, #0xb, lsl #12  ; [pp+0xb1e8] "A RenderObject does not have any constraints before it has been laid out."
    //     0x5230e4: ldr             x0, [x0, #0x1e8]
    // 0x5230e8: StoreField: r1->field_b = r0
    //     0x5230e8: stur            w0, [x1, #0xb]
    // 0x5230ec: mov             x0, x1
    // 0x5230f0: r0 = Throw()
    //     0x5230f0: bl              #0xd67e38  ; ThrowStub
    // 0x5230f4: brk             #0
    // 0x5230f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5230f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5230fc: b               #0x523004
    // 0x523100: stp             q0, q1, [SP, #-0x20]!
    // 0x523104: r0 = AllocateDouble()
    //     0x523104: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x523108: ldp             q0, q1, [SP], #0x20
    // 0x52310c: b               #0x523080
    // 0x523110: SaveReg d1
    //     0x523110: str             q1, [SP, #-0x10]!
    // 0x523114: SaveReg r0
    //     0x523114: str             x0, [SP, #-8]!
    // 0x523118: r0 = AllocateDouble()
    //     0x523118: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x52311c: mov             x1, x0
    // 0x523120: RestoreReg r0
    //     0x523120: ldr             x0, [SP], #8
    // 0x523124: RestoreReg d1
    //     0x523124: ldr             q1, [SP], #0x10
    // 0x523128: b               #0x5230a8
  }
  _ layoutText(/* No info */) {
    // ** addr: 0x52312c, size: 0x500
    // 0x52312c: EnterFrame
    //     0x52312c: stp             fp, lr, [SP, #-0x10]!
    //     0x523130: mov             fp, SP
    // 0x523134: AllocStack(0x28)
    //     0x523134: sub             SP, SP, #0x28
    // 0x523138: SetupParameters(ExtendedTextRenderBox this /* r3, fp-0x18 */, {dynamic forceLayout = false /* r4, fp-0x10 */, _Double maxWidth = inf /* d0, fp-0x28 */, _Double minWidth = 0.000000 /* d1, fp-0x20 */})
    //     0x523138: mov             x0, x4
    //     0x52313c: ldur            w1, [x0, #0x13]
    //     0x523140: add             x1, x1, HEAP, lsl #32
    //     0x523144: sub             x2, x1, #2
    //     0x523148: add             x3, fp, w2, sxtw #2
    //     0x52314c: ldr             x3, [x3, #0x10]
    //     0x523150: stur            x3, [fp, #-0x18]
    //     0x523154: ldur            w2, [x0, #0x1f]
    //     0x523158: add             x2, x2, HEAP, lsl #32
    //     0x52315c: add             x16, PP, #0x37, lsl #12  ; [pp+0x37380] "forceLayout"
    //     0x523160: ldr             x16, [x16, #0x380]
    //     0x523164: cmp             w2, w16
    //     0x523168: b.ne            #0x52318c
    //     0x52316c: ldur            w2, [x0, #0x23]
    //     0x523170: add             x2, x2, HEAP, lsl #32
    //     0x523174: sub             w4, w1, w2
    //     0x523178: add             x2, fp, w4, sxtw #2
    //     0x52317c: ldr             x2, [x2, #8]
    //     0x523180: mov             x4, x2
    //     0x523184: mov             x2, #1
    //     0x523188: b               #0x523194
    //     0x52318c: add             x4, NULL, #0x30  ; false
    //     0x523190: mov             x2, #0
    //     0x523194: stur            x4, [fp, #-0x10]
    //     0x523198: lsl             x5, x2, #1
    //     0x52319c: lsl             w6, w5, #1
    //     0x5231a0: add             w7, w6, #8
    //     0x5231a4: add             x16, x0, w7, sxtw #1
    //     0x5231a8: ldur            w8, [x16, #0xf]
    //     0x5231ac: add             x8, x8, HEAP, lsl #32
    //     0x5231b0: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f590] "maxWidth"
    //     0x5231b4: ldr             x16, [x16, #0x590]
    //     0x5231b8: cmp             w8, w16
    //     0x5231bc: b.ne            #0x5231f0
    //     0x5231c0: add             w2, w6, #0xa
    //     0x5231c4: add             x16, x0, w2, sxtw #1
    //     0x5231c8: ldur            w6, [x16, #0xf]
    //     0x5231cc: add             x6, x6, HEAP, lsl #32
    //     0x5231d0: sub             w2, w1, w6
    //     0x5231d4: add             x6, fp, w2, sxtw #2
    //     0x5231d8: ldr             x6, [x6, #8]
    //     0x5231dc: add             w2, w5, #2
    //     0x5231e0: ldur            d0, [x6, #7]
    //     0x5231e4: sbfx            x5, x2, #1, #0x1f
    //     0x5231e8: mov             x2, x5
    //     0x5231ec: b               #0x5231f4
    //     0x5231f0: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    //     0x5231f4: stur            d0, [fp, #-0x28]
    //     0x5231f8: lsl             x5, x2, #1
    //     0x5231fc: lsl             w2, w5, #1
    //     0x523200: add             w5, w2, #8
    //     0x523204: add             x16, x0, w5, sxtw #1
    //     0x523208: ldur            w6, [x16, #0xf]
    //     0x52320c: add             x6, x6, HEAP, lsl #32
    //     0x523210: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f598] "minWidth"
    //     0x523214: ldr             x16, [x16, #0x598]
    //     0x523218: cmp             w6, w16
    //     0x52321c: b.ne            #0x523244
    //     0x523220: add             w5, w2, #0xa
    //     0x523224: add             x16, x0, w5, sxtw #1
    //     0x523228: ldur            w2, [x16, #0xf]
    //     0x52322c: add             x2, x2, HEAP, lsl #32
    //     0x523230: sub             w0, w1, w2
    //     0x523234: add             x1, fp, w0, sxtw #2
    //     0x523238: ldr             x1, [x1, #8]
    //     0x52323c: ldur            d1, [x1, #7]
    //     0x523240: b               #0x523248
    //     0x523244: eor             v1.16b, v1.16b, v1.16b
    //     0x523248: stur            d1, [fp, #-0x20]
    // 0x52324c: CheckStackOverflow
    //     0x52324c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x523250: cmp             SP, x16
    //     0x523254: b.ls            #0x52357c
    // 0x523258: LoadField: r0 = r3->field_6f
    //     0x523258: ldur            w0, [x3, #0x6f]
    // 0x52325c: DecompressPointer r0
    //     0x52325c: add             x0, x0, HEAP, lsl #32
    // 0x523260: r1 = inline_Allocate_Double()
    //     0x523260: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x523264: add             x1, x1, #0x10
    //     0x523268: cmp             x2, x1
    //     0x52326c: b.ls            #0x523584
    //     0x523270: str             x1, [THR, #0x60]  ; THR::top
    //     0x523274: sub             x1, x1, #0xf
    //     0x523278: mov             x2, #0xd108
    //     0x52327c: movk            x2, #3, lsl #16
    //     0x523280: stur            x2, [x1, #-1]
    // 0x523284: StoreField: r1->field_7 = d0
    //     0x523284: stur            d0, [x1, #7]
    // 0x523288: stur            x1, [fp, #-8]
    // 0x52328c: r2 = LoadClassIdInstr(r0)
    //     0x52328c: ldur            x2, [x0, #-1]
    //     0x523290: ubfx            x2, x2, #0xc, #0x14
    // 0x523294: stp             x1, x0, [SP, #-0x10]!
    // 0x523298: mov             x0, x2
    // 0x52329c: mov             lr, x0
    // 0x5232a0: ldr             lr, [x21, lr, lsl #3]
    // 0x5232a4: blr             lr
    // 0x5232a8: add             SP, SP, #0x10
    // 0x5232ac: tbnz            w0, #4, #0x523324
    // 0x5232b0: ldur            x1, [fp, #-0x18]
    // 0x5232b4: ldur            d0, [fp, #-0x20]
    // 0x5232b8: LoadField: r0 = r1->field_73
    //     0x5232b8: ldur            w0, [x1, #0x73]
    // 0x5232bc: DecompressPointer r0
    //     0x5232bc: add             x0, x0, HEAP, lsl #32
    // 0x5232c0: r2 = inline_Allocate_Double()
    //     0x5232c0: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x5232c4: add             x2, x2, #0x10
    //     0x5232c8: cmp             x3, x2
    //     0x5232cc: b.ls            #0x5235a8
    //     0x5232d0: str             x2, [THR, #0x60]  ; THR::top
    //     0x5232d4: sub             x2, x2, #0xf
    //     0x5232d8: mov             x3, #0xd108
    //     0x5232dc: movk            x3, #3, lsl #16
    //     0x5232e0: stur            x3, [x2, #-1]
    // 0x5232e4: StoreField: r2->field_7 = d0
    //     0x5232e4: stur            d0, [x2, #7]
    // 0x5232e8: r3 = LoadClassIdInstr(r0)
    //     0x5232e8: ldur            x3, [x0, #-1]
    //     0x5232ec: ubfx            x3, x3, #0xc, #0x14
    // 0x5232f0: stp             x2, x0, [SP, #-0x10]!
    // 0x5232f4: mov             x0, x3
    // 0x5232f8: mov             lr, x0
    // 0x5232fc: ldr             lr, [x21, lr, lsl #3]
    // 0x523300: blr             lr
    // 0x523304: add             SP, SP, #0x10
    // 0x523308: tbnz            w0, #4, #0x523324
    // 0x52330c: ldur            x0, [fp, #-0x10]
    // 0x523310: tbz             w0, #4, #0x523324
    // 0x523314: r0 = Null
    //     0x523314: mov             x0, NULL
    // 0x523318: LeaveFrame
    //     0x523318: mov             SP, fp
    //     0x52331c: ldp             fp, lr, [SP], #0x10
    // 0x523320: ret
    //     0x523320: ret             
    // 0x523324: ldur            d0, [fp, #-0x28]
    // 0x523328: ldur            x16, [fp, #-0x18]
    // 0x52332c: SaveReg r16
    //     0x52332c: str             x16, [SP, #-8]!
    // 0x523330: r0 = _isMultiline()
    //     0x523330: bl              #0x522fc8  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_isMultiline
    // 0x523334: add             SP, SP, #8
    // 0x523338: stur            x0, [fp, #-0x10]
    // 0x52333c: ldur            x16, [fp, #-0x18]
    // 0x523340: SaveReg r16
    //     0x523340: str             x16, [SP, #-8]!
    // 0x523344: r0 = _caretMargin()
    //     0x523344: bl              #0x52418c  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_caretMargin
    // 0x523348: add             SP, SP, #8
    // 0x52334c: mov             v1.16b, v0.16b
    // 0x523350: ldur            d0, [fp, #-0x28]
    // 0x523354: fsub            d2, d0, d1
    // 0x523358: d0 = 0.000000
    //     0x523358: eor             v0.16b, v0.16b, v0.16b
    // 0x52335c: fcmp            d0, d2
    // 0x523360: b.vs            #0x523370
    // 0x523364: b.le            #0x523370
    // 0x523368: d2 = 0.000000
    //     0x523368: eor             v2.16b, v2.16b, v2.16b
    // 0x52336c: b               #0x5233a0
    // 0x523370: fcmp            d0, d2
    // 0x523374: b.vs            #0x52337c
    // 0x523378: b.lt            #0x5233a0
    // 0x52337c: fcmp            d0, d0
    // 0x523380: b.vs            #0x523394
    // 0x523384: b.ne            #0x523394
    // 0x523388: fadd            d1, d0, d2
    // 0x52338c: mov             v2.16b, v1.16b
    // 0x523390: b               #0x5233a0
    // 0x523394: fcmp            d2, d2
    // 0x523398: b.vs            #0x5233a0
    // 0x52339c: d2 = 0.000000
    //     0x52339c: eor             v2.16b, v2.16b, v2.16b
    // 0x5233a0: ldur            d1, [fp, #-0x20]
    // 0x5233a4: stur            d2, [fp, #-0x28]
    // 0x5233a8: fcmp            d1, d2
    // 0x5233ac: b.vs            #0x5233c0
    // 0x5233b0: b.le            #0x5233c0
    // 0x5233b4: mov             v1.16b, v2.16b
    // 0x5233b8: mov             v0.16b, v2.16b
    // 0x5233bc: b               #0x523464
    // 0x5233c0: fcmp            d1, d2
    // 0x5233c4: b.vs            #0x5233d4
    // 0x5233c8: b.ge            #0x5233d4
    // 0x5233cc: mov             v0.16b, v2.16b
    // 0x5233d0: b               #0x523464
    // 0x5233d4: fcmp            d1, d0
    // 0x5233d8: b.vs            #0x5233e0
    // 0x5233dc: b.eq            #0x5233e8
    // 0x5233e0: r0 = false
    //     0x5233e0: add             x0, NULL, #0x30  ; false
    // 0x5233e4: b               #0x5233ec
    // 0x5233e8: r0 = true
    //     0x5233e8: add             x0, NULL, #0x20  ; true
    // 0x5233ec: tbnz            w0, #4, #0x523408
    // 0x5233f0: fadd            d0, d1, d2
    // 0x5233f4: fmul            d3, d0, d1
    // 0x5233f8: fmul            d0, d3, d2
    // 0x5233fc: mov             v1.16b, v0.16b
    // 0x523400: mov             v0.16b, v2.16b
    // 0x523404: b               #0x523464
    // 0x523408: tbnz            w0, #4, #0x52344c
    // 0x52340c: r0 = inline_Allocate_Double()
    //     0x52340c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x523410: add             x0, x0, #0x10
    //     0x523414: cmp             x1, x0
    //     0x523418: b.ls            #0x5235c4
    //     0x52341c: str             x0, [THR, #0x60]  ; THR::top
    //     0x523420: sub             x0, x0, #0xf
    //     0x523424: mov             x1, #0xd108
    //     0x523428: movk            x1, #3, lsl #16
    //     0x52342c: stur            x1, [x0, #-1]
    // 0x523430: StoreField: r0->field_7 = d2
    //     0x523430: stur            d2, [x0, #7]
    // 0x523434: SaveReg r0
    //     0x523434: str             x0, [SP, #-8]!
    // 0x523438: r0 = isNegative()
    //     0x523438: bl              #0xd64e98  ; [dart:core] _Double::isNegative
    // 0x52343c: add             SP, SP, #8
    // 0x523440: tbnz            w0, #4, #0x52344c
    // 0x523444: ldur            d0, [fp, #-0x28]
    // 0x523448: b               #0x523458
    // 0x52344c: ldur            d0, [fp, #-0x28]
    // 0x523450: fcmp            d0, d0
    // 0x523454: b.vc            #0x523460
    // 0x523458: mov             v1.16b, v0.16b
    // 0x52345c: b               #0x523464
    // 0x523460: ldur            d1, [fp, #-0x20]
    // 0x523464: ldur            x0, [fp, #-0x10]
    // 0x523468: tbnz            w0, #4, #0x523474
    // 0x52346c: mov             v2.16b, v0.16b
    // 0x523470: b               #0x523478
    // 0x523474: d2 = inf
    //     0x523474: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x523478: ldur            x0, [fp, #-0x18]
    // 0x52347c: LoadField: r1 = r0->field_fb
    //     0x52347c: ldur            w1, [x0, #0xfb]
    // 0x523480: DecompressPointer r1
    //     0x523480: add             x1, x1, HEAP, lsl #32
    // 0x523484: tbnz            w1, #4, #0x52348c
    // 0x523488: mov             v1.16b, v0.16b
    // 0x52348c: ldur            d0, [fp, #-0x20]
    // 0x523490: LoadField: r1 = r0->field_eb
    //     0x523490: ldur            w1, [x0, #0xeb]
    // 0x523494: DecompressPointer r1
    //     0x523494: add             x1, x1, HEAP, lsl #32
    // 0x523498: r2 = inline_Allocate_Double()
    //     0x523498: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0x52349c: add             x2, x2, #0x10
    //     0x5234a0: cmp             x3, x2
    //     0x5234a4: b.ls            #0x5235d4
    //     0x5234a8: str             x2, [THR, #0x60]  ; THR::top
    //     0x5234ac: sub             x2, x2, #0xf
    //     0x5234b0: mov             x3, #0xd108
    //     0x5234b4: movk            x3, #3, lsl #16
    //     0x5234b8: stur            x3, [x2, #-1]
    // 0x5234bc: StoreField: r2->field_7 = d2
    //     0x5234bc: stur            d2, [x2, #7]
    // 0x5234c0: r3 = inline_Allocate_Double()
    //     0x5234c0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x5234c4: add             x3, x3, #0x10
    //     0x5234c8: cmp             x4, x3
    //     0x5234cc: b.ls            #0x5235f8
    //     0x5234d0: str             x3, [THR, #0x60]  ; THR::top
    //     0x5234d4: sub             x3, x3, #0xf
    //     0x5234d8: mov             x4, #0xd108
    //     0x5234dc: movk            x4, #3, lsl #16
    //     0x5234e0: stur            x4, [x3, #-1]
    // 0x5234e4: StoreField: r3->field_7 = d1
    //     0x5234e4: stur            d1, [x3, #7]
    // 0x5234e8: stp             x3, x1, [SP, #-0x10]!
    // 0x5234ec: SaveReg r2
    //     0x5234ec: str             x2, [SP, #-8]!
    // 0x5234f0: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x5234f0: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x5234f4: ldr             x4, [x4, #0x588]
    // 0x5234f8: r0 = layout()
    //     0x5234f8: bl              #0x52362c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::layout
    // 0x5234fc: add             SP, SP, #0x18
    // 0x523500: ldur            d0, [fp, #-0x20]
    // 0x523504: r0 = inline_Allocate_Double()
    //     0x523504: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x523508: add             x0, x0, #0x10
    //     0x52350c: cmp             x1, x0
    //     0x523510: b.ls            #0x52361c
    //     0x523514: str             x0, [THR, #0x60]  ; THR::top
    //     0x523518: sub             x0, x0, #0xf
    //     0x52351c: mov             x1, #0xd108
    //     0x523520: movk            x1, #3, lsl #16
    //     0x523524: stur            x1, [x0, #-1]
    // 0x523528: StoreField: r0->field_7 = d0
    //     0x523528: stur            d0, [x0, #7]
    // 0x52352c: ldur            x1, [fp, #-0x18]
    // 0x523530: StoreField: r1->field_73 = r0
    //     0x523530: stur            w0, [x1, #0x73]
    //     0x523534: ldurb           w16, [x1, #-1]
    //     0x523538: ldurb           w17, [x0, #-1]
    //     0x52353c: and             x16, x17, x16, lsr #2
    //     0x523540: tst             x16, HEAP, lsr #32
    //     0x523544: b.eq            #0x52354c
    //     0x523548: bl              #0xd6826c
    // 0x52354c: ldur            x0, [fp, #-8]
    // 0x523550: StoreField: r1->field_6f = r0
    //     0x523550: stur            w0, [x1, #0x6f]
    //     0x523554: ldurb           w16, [x1, #-1]
    //     0x523558: ldurb           w17, [x0, #-1]
    //     0x52355c: and             x16, x17, x16, lsr #2
    //     0x523560: tst             x16, HEAP, lsr #32
    //     0x523564: b.eq            #0x52356c
    //     0x523568: bl              #0xd6826c
    // 0x52356c: r0 = Null
    //     0x52356c: mov             x0, NULL
    // 0x523570: LeaveFrame
    //     0x523570: mov             SP, fp
    //     0x523574: ldp             fp, lr, [SP], #0x10
    // 0x523578: ret
    //     0x523578: ret             
    // 0x52357c: r0 = StackOverflowSharedWithFPURegs()
    //     0x52357c: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x523580: b               #0x523258
    // 0x523584: stp             q0, q1, [SP, #-0x20]!
    // 0x523588: stp             x3, x4, [SP, #-0x10]!
    // 0x52358c: SaveReg r0
    //     0x52358c: str             x0, [SP, #-8]!
    // 0x523590: r0 = AllocateDouble()
    //     0x523590: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x523594: mov             x1, x0
    // 0x523598: RestoreReg r0
    //     0x523598: ldr             x0, [SP], #8
    // 0x52359c: ldp             x3, x4, [SP], #0x10
    // 0x5235a0: ldp             q0, q1, [SP], #0x20
    // 0x5235a4: b               #0x523284
    // 0x5235a8: SaveReg d0
    //     0x5235a8: str             q0, [SP, #-0x10]!
    // 0x5235ac: stp             x0, x1, [SP, #-0x10]!
    // 0x5235b0: r0 = AllocateDouble()
    //     0x5235b0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5235b4: mov             x2, x0
    // 0x5235b8: ldp             x0, x1, [SP], #0x10
    // 0x5235bc: RestoreReg d0
    //     0x5235bc: ldr             q0, [SP], #0x10
    // 0x5235c0: b               #0x5232e4
    // 0x5235c4: stp             q1, q2, [SP, #-0x20]!
    // 0x5235c8: r0 = AllocateDouble()
    //     0x5235c8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5235cc: ldp             q1, q2, [SP], #0x20
    // 0x5235d0: b               #0x523430
    // 0x5235d4: stp             q1, q2, [SP, #-0x20]!
    // 0x5235d8: SaveReg d0
    //     0x5235d8: str             q0, [SP, #-0x10]!
    // 0x5235dc: stp             x0, x1, [SP, #-0x10]!
    // 0x5235e0: r0 = AllocateDouble()
    //     0x5235e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x5235e4: mov             x2, x0
    // 0x5235e8: ldp             x0, x1, [SP], #0x10
    // 0x5235ec: RestoreReg d0
    //     0x5235ec: ldr             q0, [SP], #0x10
    // 0x5235f0: ldp             q1, q2, [SP], #0x20
    // 0x5235f4: b               #0x5234bc
    // 0x5235f8: stp             q0, q1, [SP, #-0x20]!
    // 0x5235fc: stp             x1, x2, [SP, #-0x10]!
    // 0x523600: SaveReg r0
    //     0x523600: str             x0, [SP, #-8]!
    // 0x523604: r0 = AllocateDouble()
    //     0x523604: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x523608: mov             x3, x0
    // 0x52360c: RestoreReg r0
    //     0x52360c: ldr             x0, [SP], #8
    // 0x523610: ldp             x1, x2, [SP], #0x10
    // 0x523614: ldp             q0, q1, [SP], #0x20
    // 0x523618: b               #0x5234e4
    // 0x52361c: SaveReg d0
    //     0x52361c: str             q0, [SP, #-0x10]!
    // 0x523620: r0 = AllocateDouble()
    //     0x523620: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x523624: RestoreReg d0
    //     0x523624: ldr             q0, [SP], #0x10
    // 0x523628: b               #0x523528
  }
  _ hitTestChildren(/* No info */) {
    // ** addr: 0x622ad0, size: 0x2b0
    // 0x622ad0: EnterFrame
    //     0x622ad0: stp             fp, lr, [SP, #-0x10]!
    //     0x622ad4: mov             fp, SP
    // 0x622ad8: AllocStack(0x28)
    //     0x622ad8: sub             SP, SP, #0x28
    // 0x622adc: CheckStackOverflow
    //     0x622adc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622ae0: cmp             SP, x16
    //     0x622ae4: b.ls            #0x622d64
    // 0x622ae8: ldr             x0, [fp, #0x20]
    // 0x622aec: LoadField: r1 = r0->field_eb
    //     0x622aec: ldur            w1, [x0, #0xeb]
    // 0x622af0: DecompressPointer r1
    //     0x622af0: add             x1, x1, HEAP, lsl #32
    // 0x622af4: stur            x1, [fp, #-8]
    // 0x622af8: SaveReg r0
    //     0x622af8: str             x0, [SP, #-8]!
    // 0x622afc: r0 = paintOffset()
    //     0x622afc: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0x622b00: add             SP, SP, #8
    // 0x622b04: ldr             x16, [fp, #0x10]
    // 0x622b08: stp             x0, x16, [SP, #-0x10]!
    // 0x622b0c: r0 = -()
    //     0x622b0c: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x622b10: add             SP, SP, #0x10
    // 0x622b14: ldur            x16, [fp, #-8]
    // 0x622b18: stp             x0, x16, [SP, #-0x10]!
    // 0x622b1c: r0 = getPositionForOffset()
    //     0x622b1c: bl              #0x6246bc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getPositionForOffset
    // 0x622b20: add             SP, SP, #0x10
    // 0x622b24: mov             x1, x0
    // 0x622b28: ldur            x0, [fp, #-8]
    // 0x622b2c: stur            x1, [fp, #-0x18]
    // 0x622b30: LoadField: r2 = r0->field_f
    //     0x622b30: ldur            w2, [x0, #0xf]
    // 0x622b34: DecompressPointer r2
    //     0x622b34: add             x2, x2, HEAP, lsl #32
    // 0x622b38: stur            x2, [fp, #-0x10]
    // 0x622b3c: cmp             w2, NULL
    // 0x622b40: b.eq            #0x622d6c
    // 0x622b44: r3 = LoadClassIdInstr(r2)
    //     0x622b44: ldur            x3, [x2, #-1]
    //     0x622b48: ubfx            x3, x3, #0xc, #0x14
    // 0x622b4c: lsl             x3, x3, #1
    // 0x622b50: r17 = 6958
    //     0x622b50: mov             x17, #0x1b2e
    // 0x622b54: cmp             w3, w17
    // 0x622b58: b.gt            #0x622b70
    // 0x622b5c: r17 = 6954
    //     0x622b5c: mov             x17, #0x1b2a
    // 0x622b60: cmp             w3, w17
    // 0x622b64: b.lt            #0x622b70
    // 0x622b68: r3 = Null
    //     0x622b68: mov             x3, NULL
    // 0x622b6c: b               #0x622bd0
    // 0x622b70: r1 = 3
    //     0x622b70: mov             x1, #3
    // 0x622b74: r0 = AllocateContext()
    //     0x622b74: bl              #0xd68aa4  ; AllocateContextStub
    // 0x622b78: mov             x1, x0
    // 0x622b7c: ldur            x0, [fp, #-0x18]
    // 0x622b80: stur            x1, [fp, #-0x20]
    // 0x622b84: StoreField: r1->field_f = r0
    //     0x622b84: stur            w0, [x1, #0xf]
    // 0x622b88: r0 = Accumulator()
    //     0x622b88: bl              #0x522218  ; AllocateAccumulatorStub -> Accumulator (size=0x10)
    // 0x622b8c: mov             x1, x0
    // 0x622b90: r0 = 0
    //     0x622b90: mov             x0, #0
    // 0x622b94: StoreField: r1->field_7 = r0
    //     0x622b94: stur            x0, [x1, #7]
    // 0x622b98: ldur            x0, [fp, #-0x20]
    // 0x622b9c: StoreField: r0->field_13 = r1
    //     0x622b9c: stur            w1, [x0, #0x13]
    // 0x622ba0: mov             x2, x0
    // 0x622ba4: r1 = Function '<anonymous closure>':.
    //     0x622ba4: add             x1, PP, #0x22, lsl #12  ; [pp+0x22488] AnonymousClosure: (0x624c1c), of [package:flutter/src/painting/inline_span.dart] InlineSpan
    //     0x622ba8: ldr             x1, [x1, #0x488]
    // 0x622bac: r0 = AllocateClosure()
    //     0x622bac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x622bb0: ldur            x16, [fp, #-0x10]
    // 0x622bb4: stp             x0, x16, [SP, #-0x10]!
    // 0x622bb8: r0 = visitChildren()
    //     0x622bb8: bl              #0xcdf548  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x622bbc: add             SP, SP, #0x10
    // 0x622bc0: ldur            x0, [fp, #-0x20]
    // 0x622bc4: LoadField: r1 = r0->field_17
    //     0x622bc4: ldur            w1, [x0, #0x17]
    // 0x622bc8: DecompressPointer r1
    //     0x622bc8: add             x1, x1, HEAP, lsl #32
    // 0x622bcc: mov             x3, x1
    // 0x622bd0: stur            x3, [fp, #-0x10]
    // 0x622bd4: cmp             w3, NULL
    // 0x622bd8: b.eq            #0x622c5c
    // 0x622bdc: mov             x0, x3
    // 0x622be0: r2 = Null
    //     0x622be0: mov             x2, NULL
    // 0x622be4: r1 = Null
    //     0x622be4: mov             x1, NULL
    // 0x622be8: cmp             w0, NULL
    // 0x622bec: b.eq            #0x622c1c
    // 0x622bf0: branchIfSmi(r0, 0x622c1c)
    //     0x622bf0: tbz             w0, #0, #0x622c1c
    // 0x622bf4: r3 = LoadClassIdInstr(r0)
    //     0x622bf4: ldur            x3, [x0, #-1]
    //     0x622bf8: ubfx            x3, x3, #0xc, #0x14
    // 0x622bfc: sub             x3, x3, #0x961
    // 0x622c00: cmp             x3, #0xbe
    // 0x622c04: b.ls            #0x622c24
    // 0x622c08: cmp             x3, #0xf8
    // 0x622c0c: b.eq            #0x622c24
    // 0x622c10: sub             x3, x3, #0x430
    // 0x622c14: cmp             x3, #2
    // 0x622c18: b.ls            #0x622c24
    // 0x622c1c: r0 = false
    //     0x622c1c: add             x0, NULL, #0x30  ; false
    // 0x622c20: b               #0x622c28
    // 0x622c24: r0 = true
    //     0x622c24: add             x0, NULL, #0x20  ; true
    // 0x622c28: tbnz            w0, #4, #0x622c5c
    // 0x622c2c: ldur            x0, [fp, #-0x10]
    // 0x622c30: r1 = <HitTestTarget>
    //     0x622c30: ldr             x1, [PP, #0x38d0]  ; [pp+0x38d0] TypeArguments: <HitTestTarget>
    // 0x622c34: r0 = HitTestEntry()
    //     0x622c34: bl              #0x50edf8  ; AllocateHitTestEntryStub -> HitTestEntry<X0 bound HitTestTarget> (size=0x14)
    // 0x622c38: mov             x1, x0
    // 0x622c3c: ldur            x0, [fp, #-0x10]
    // 0x622c40: StoreField: r1->field_b = r0
    //     0x622c40: stur            w0, [x1, #0xb]
    // 0x622c44: ldr             x16, [fp, #0x18]
    // 0x622c48: stp             x1, x16, [SP, #-0x10]!
    // 0x622c4c: r0 = add()
    //     0x622c4c: bl              #0x50ea24  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::add
    // 0x622c50: add             SP, SP, #0x10
    // 0x622c54: r1 = true
    //     0x622c54: add             x1, NULL, #0x20  ; true
    // 0x622c58: b               #0x622c60
    // 0x622c5c: r1 = false
    //     0x622c5c: add             x1, NULL, #0x30  ; false
    // 0x622c60: ldr             x0, [fp, #0x20]
    // 0x622c64: stur            x1, [fp, #-0x18]
    // 0x622c68: LoadField: r2 = r0->field_67
    //     0x622c68: ldur            w2, [x0, #0x67]
    // 0x622c6c: DecompressPointer r2
    //     0x622c6c: add             x2, x2, HEAP, lsl #32
    // 0x622c70: mov             x4, x2
    // 0x622c74: r3 = 0
    //     0x622c74: mov             x3, #0
    // 0x622c78: ldur            x2, [fp, #-8]
    // 0x622c7c: stur            x4, [fp, #-0x10]
    // 0x622c80: stur            x3, [fp, #-0x28]
    // 0x622c84: CheckStackOverflow
    //     0x622c84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622c88: cmp             SP, x16
    //     0x622c8c: b.ls            #0x622d70
    // 0x622c90: cmp             w4, NULL
    // 0x622c94: b.eq            #0x622d54
    // 0x622c98: LoadField: r5 = r2->field_3f
    //     0x622c98: ldur            w5, [x2, #0x3f]
    // 0x622c9c: DecompressPointer r5
    //     0x622c9c: add             x5, x5, HEAP, lsl #32
    // 0x622ca0: cmp             w5, NULL
    // 0x622ca4: b.eq            #0x622d78
    // 0x622ca8: LoadField: r6 = r5->field_b
    //     0x622ca8: ldur            w6, [x5, #0xb]
    // 0x622cac: DecompressPointer r6
    //     0x622cac: add             x6, x6, HEAP, lsl #32
    // 0x622cb0: r5 = LoadInt32Instr(r6)
    //     0x622cb0: sbfx            x5, x6, #1, #0x1f
    // 0x622cb4: cmp             x3, x5
    // 0x622cb8: b.ge            #0x622d54
    // 0x622cbc: ldr             x16, [fp, #0x18]
    // 0x622cc0: stp             x16, x0, [SP, #-0x10]!
    // 0x622cc4: ldr             x16, [fp, #0x10]
    // 0x622cc8: stp             x16, x4, [SP, #-0x10]!
    // 0x622ccc: r0 = hitTestChild()
    //     0x622ccc: bl              #0x622d80  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::hitTestChild
    // 0x622cd0: add             SP, SP, #0x20
    // 0x622cd4: tbnz            w0, #4, #0x622ce8
    // 0x622cd8: r0 = true
    //     0x622cd8: add             x0, NULL, #0x20  ; true
    // 0x622cdc: LeaveFrame
    //     0x622cdc: mov             SP, fp
    //     0x622ce0: ldp             fp, lr, [SP], #0x10
    // 0x622ce4: ret
    //     0x622ce4: ret             
    // 0x622ce8: ldur            x0, [fp, #-0x10]
    // 0x622cec: ldur            x3, [fp, #-0x28]
    // 0x622cf0: LoadField: r4 = r0->field_17
    //     0x622cf0: ldur            w4, [x0, #0x17]
    // 0x622cf4: DecompressPointer r4
    //     0x622cf4: add             x4, x4, HEAP, lsl #32
    // 0x622cf8: stur            x4, [fp, #-0x20]
    // 0x622cfc: cmp             w4, NULL
    // 0x622d00: b.eq            #0x622d7c
    // 0x622d04: mov             x0, x4
    // 0x622d08: r2 = Null
    //     0x622d08: mov             x2, NULL
    // 0x622d0c: r1 = Null
    //     0x622d0c: mov             x1, NULL
    // 0x622d10: r4 = LoadClassIdInstr(r0)
    //     0x622d10: ldur            x4, [x0, #-1]
    //     0x622d14: ubfx            x4, x4, #0xc, #0x14
    // 0x622d18: cmp             x4, #0x808
    // 0x622d1c: b.eq            #0x622d34
    // 0x622d20: r8 = TextParentData<RenderBox>
    //     0x622d20: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x622d24: ldr             x8, [x8, #0x298]
    // 0x622d28: r3 = Null
    //     0x622d28: add             x3, PP, #0x56, lsl #12  ; [pp+0x566f0] Null
    //     0x622d2c: ldr             x3, [x3, #0x6f0]
    // 0x622d30: r0 = DefaultTypeTest()
    //     0x622d30: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x622d34: ldur            x1, [fp, #-0x20]
    // 0x622d38: LoadField: r4 = r1->field_13
    //     0x622d38: ldur            w4, [x1, #0x13]
    // 0x622d3c: DecompressPointer r4
    //     0x622d3c: add             x4, x4, HEAP, lsl #32
    // 0x622d40: ldur            x1, [fp, #-0x28]
    // 0x622d44: add             x3, x1, #1
    // 0x622d48: ldr             x0, [fp, #0x20]
    // 0x622d4c: ldur            x1, [fp, #-0x18]
    // 0x622d50: b               #0x622c78
    // 0x622d54: ldur            x0, [fp, #-0x18]
    // 0x622d58: LeaveFrame
    //     0x622d58: mov             SP, fp
    //     0x622d5c: ldp             fp, lr, [SP], #0x10
    // 0x622d60: ret
    //     0x622d60: ret             
    // 0x622d64: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622d64: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622d68: b               #0x622ae8
    // 0x622d6c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x622d6c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x622d70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622d70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622d74: b               #0x622c90
    // 0x622d78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x622d78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x622d7c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x622d7c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ hitTestChild(/* No info */) {
    // ** addr: 0x622d80, size: 0x184
    // 0x622d80: EnterFrame
    //     0x622d80: stp             fp, lr, [SP, #-0x10]!
    //     0x622d84: mov             fp, SP
    // 0x622d88: AllocStack(0x28)
    //     0x622d88: sub             SP, SP, #0x28
    // 0x622d8c: CheckStackOverflow
    //     0x622d8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x622d90: cmp             SP, x16
    //     0x622d94: b.ls            #0x622eec
    // 0x622d98: r1 = 1
    //     0x622d98: mov             x1, #1
    // 0x622d9c: r0 = AllocateContext()
    //     0x622d9c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x622da0: mov             x3, x0
    // 0x622da4: ldr             x0, [fp, #0x18]
    // 0x622da8: stur            x3, [fp, #-0x10]
    // 0x622dac: StoreField: r3->field_f = r0
    //     0x622dac: stur            w0, [x3, #0xf]
    // 0x622db0: LoadField: r4 = r0->field_17
    //     0x622db0: ldur            w4, [x0, #0x17]
    // 0x622db4: DecompressPointer r4
    //     0x622db4: add             x4, x4, HEAP, lsl #32
    // 0x622db8: mov             x0, x4
    // 0x622dbc: stur            x4, [fp, #-8]
    // 0x622dc0: r2 = Null
    //     0x622dc0: mov             x2, NULL
    // 0x622dc4: r1 = Null
    //     0x622dc4: mov             x1, NULL
    // 0x622dc8: r4 = LoadClassIdInstr(r0)
    //     0x622dc8: ldur            x4, [x0, #-1]
    //     0x622dcc: ubfx            x4, x4, #0xc, #0x14
    // 0x622dd0: cmp             x4, #0x808
    // 0x622dd4: b.eq            #0x622dec
    // 0x622dd8: r8 = TextParentData<RenderBox>
    //     0x622dd8: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x622ddc: ldr             x8, [x8, #0x298]
    // 0x622de0: r3 = Null
    //     0x622de0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56700] Null
    //     0x622de4: ldr             x3, [x3, #0x700]
    // 0x622de8: r0 = DefaultTypeTest()
    //     0x622de8: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x622dec: ldur            x0, [fp, #-8]
    // 0x622df0: LoadField: r1 = r0->field_7
    //     0x622df0: ldur            w1, [x0, #7]
    // 0x622df4: DecompressPointer r1
    //     0x622df4: add             x1, x1, HEAP, lsl #32
    // 0x622df8: LoadField: d0 = r1->field_7
    //     0x622df8: ldur            d0, [x1, #7]
    // 0x622dfc: stur            d0, [fp, #-0x20]
    // 0x622e00: ldr             x16, [fp, #0x28]
    // 0x622e04: SaveReg r16
    //     0x622e04: str             x16, [SP, #-8]!
    // 0x622e08: r0 = _effectiveOffset()
    //     0x622e08: bl              #0x522e30  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_effectiveOffset
    // 0x622e0c: add             SP, SP, #8
    // 0x622e10: LoadField: d0 = r0->field_7
    //     0x622e10: ldur            d0, [x0, #7]
    // 0x622e14: ldur            d1, [fp, #-0x20]
    // 0x622e18: fadd            d2, d1, d0
    // 0x622e1c: ldur            x0, [fp, #-8]
    // 0x622e20: stur            d2, [fp, #-0x28]
    // 0x622e24: LoadField: r1 = r0->field_7
    //     0x622e24: ldur            w1, [x0, #7]
    // 0x622e28: DecompressPointer r1
    //     0x622e28: add             x1, x1, HEAP, lsl #32
    // 0x622e2c: LoadField: d0 = r1->field_f
    //     0x622e2c: ldur            d0, [x1, #0xf]
    // 0x622e30: stur            d0, [fp, #-0x20]
    // 0x622e34: ldr             x16, [fp, #0x28]
    // 0x622e38: SaveReg r16
    //     0x622e38: str             x16, [SP, #-8]!
    // 0x622e3c: r0 = _effectiveOffset()
    //     0x622e3c: bl              #0x522e30  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::_effectiveOffset
    // 0x622e40: add             SP, SP, #8
    // 0x622e44: LoadField: d0 = r0->field_f
    //     0x622e44: ldur            d0, [x0, #0xf]
    // 0x622e48: ldur            d1, [fp, #-0x20]
    // 0x622e4c: fadd            d2, d1, d0
    // 0x622e50: ldur            d0, [fp, #-0x28]
    // 0x622e54: r0 = inline_Allocate_Double()
    //     0x622e54: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x622e58: add             x0, x0, #0x10
    //     0x622e5c: cmp             x1, x0
    //     0x622e60: b.ls            #0x622ef4
    //     0x622e64: str             x0, [THR, #0x60]  ; THR::top
    //     0x622e68: sub             x0, x0, #0xf
    //     0x622e6c: mov             x1, #0xd108
    //     0x622e70: movk            x1, #3, lsl #16
    //     0x622e74: stur            x1, [x0, #-1]
    // 0x622e78: StoreField: r0->field_7 = d0
    //     0x622e78: stur            d0, [x0, #7]
    // 0x622e7c: stp             x0, NULL, [SP, #-0x10]!
    // 0x622e80: SaveReg d2
    //     0x622e80: str             d2, [SP, #-8]!
    // 0x622e84: r0 = Matrix4.translationValues()
    //     0x622e84: bl              #0x6245d8  ; [package:vector_math/vector_math_64.dart] Matrix4::Matrix4.translationValues
    // 0x622e88: add             SP, SP, #0x18
    // 0x622e8c: mov             x1, x0
    // 0x622e90: ldur            x0, [fp, #-8]
    // 0x622e94: stur            x1, [fp, #-0x18]
    // 0x622e98: LoadField: r2 = r0->field_17
    //     0x622e98: ldur            w2, [x0, #0x17]
    // 0x622e9c: DecompressPointer r2
    //     0x622e9c: add             x2, x2, HEAP, lsl #32
    // 0x622ea0: stp             x2, x1, [SP, #-0x10]!
    // 0x622ea4: stp             x2, x2, [SP, #-0x10]!
    // 0x622ea8: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x622ea8: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x622eac: r0 = scale()
    //     0x622eac: bl              #0x50b298  ; [package:vector_math/vector_math_64.dart] Matrix4::scale
    // 0x622eb0: add             SP, SP, #0x20
    // 0x622eb4: ldur            x2, [fp, #-0x10]
    // 0x622eb8: r1 = Function '<anonymous closure>':.
    //     0x622eb8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56710] AnonymousClosure: (0x624650), in [package:flutter/src/rendering/shifted_box.dart] RenderShiftedBox::hitTestChildren (0x6275b4)
    //     0x622ebc: ldr             x1, [x1, #0x710]
    // 0x622ec0: r0 = AllocateClosure()
    //     0x622ec0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x622ec4: ldr             x16, [fp, #0x20]
    // 0x622ec8: stp             x0, x16, [SP, #-0x10]!
    // 0x622ecc: ldr             x16, [fp, #0x10]
    // 0x622ed0: ldur            lr, [fp, #-0x18]
    // 0x622ed4: stp             lr, x16, [SP, #-0x10]!
    // 0x622ed8: r0 = addWithPaintTransform()
    //     0x622ed8: bl              #0x622f04  ; [package:flutter/src/rendering/box.dart] BoxHitTestResult::addWithPaintTransform
    // 0x622edc: add             SP, SP, #0x20
    // 0x622ee0: LeaveFrame
    //     0x622ee0: mov             SP, fp
    //     0x622ee4: ldp             fp, lr, [SP], #0x10
    // 0x622ee8: ret
    //     0x622ee8: ret             
    // 0x622eec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x622eec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x622ef0: b               #0x622d98
    // 0x622ef4: stp             q0, q2, [SP, #-0x20]!
    // 0x622ef8: r0 = AllocateDouble()
    //     0x622ef8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x622efc: ldp             q0, q2, [SP], #0x20
    // 0x622f00: b               #0x622e78
  }
  dynamic computeMaxIntrinsicHeight(dynamic) {
    // ** addr: 0x62ce6c, size: 0x18
    // 0x62ce6c: r4 = 0
    //     0x62ce6c: mov             x4, #0
    // 0x62ce70: r1 = Function 'computeMaxIntrinsicHeight':.
    //     0x62ce70: add             x17, PP, #0x56, lsl #12  ; [pp+0x566d0] AnonymousClosure: (0x62ce84), of [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox
    //     0x62ce74: ldr             x1, [x17, #0x6d0]
    // 0x62ce78: r24 = BuildNonGenericMethodExtractorStub
    //     0x62ce78: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x62ce7c: LoadField: r0 = r24->field_17
    //     0x62ce7c: ldur            x0, [x24, #0x17]
    // 0x62ce80: br              x0
  }
  [closure] double computeMaxIntrinsicHeight(dynamic, double) {
    // ** addr: 0x62ce84, size: 0x8c
    // 0x62ce84: EnterFrame
    //     0x62ce84: stp             fp, lr, [SP, #-0x10]!
    //     0x62ce88: mov             fp, SP
    // 0x62ce8c: ldr             x0, [fp, #0x18]
    // 0x62ce90: LoadField: r1 = r0->field_17
    //     0x62ce90: ldur            w1, [x0, #0x17]
    // 0x62ce94: DecompressPointer r1
    //     0x62ce94: add             x1, x1, HEAP, lsl #32
    // 0x62ce98: CheckStackOverflow
    //     0x62ce98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62ce9c: cmp             SP, x16
    //     0x62cea0: b.ls            #0x62cef8
    // 0x62cea4: LoadField: r0 = r1->field_f
    //     0x62cea4: ldur            w0, [x1, #0xf]
    // 0x62cea8: DecompressPointer r0
    //     0x62cea8: add             x0, x0, HEAP, lsl #32
    // 0x62ceac: ldr             x1, [fp, #0x10]
    // 0x62ceb0: LoadField: d0 = r1->field_7
    //     0x62ceb0: ldur            d0, [x1, #7]
    // 0x62ceb4: SaveReg r0
    //     0x62ceb4: str             x0, [SP, #-8]!
    // 0x62ceb8: SaveReg d0
    //     0x62ceb8: str             d0, [SP, #-8]!
    // 0x62cebc: r0 = _computeIntrinsicHeight()
    //     0x62cebc: bl              #0x62cf10  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_computeIntrinsicHeight
    // 0x62cec0: add             SP, SP, #0x10
    // 0x62cec4: r0 = inline_Allocate_Double()
    //     0x62cec4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62cec8: add             x0, x0, #0x10
    //     0x62cecc: cmp             x1, x0
    //     0x62ced0: b.ls            #0x62cf00
    //     0x62ced4: str             x0, [THR, #0x60]  ; THR::top
    //     0x62ced8: sub             x0, x0, #0xf
    //     0x62cedc: mov             x1, #0xd108
    //     0x62cee0: movk            x1, #3, lsl #16
    //     0x62cee4: stur            x1, [x0, #-1]
    // 0x62cee8: StoreField: r0->field_7 = d0
    //     0x62cee8: stur            d0, [x0, #7]
    // 0x62ceec: LeaveFrame
    //     0x62ceec: mov             SP, fp
    //     0x62cef0: ldp             fp, lr, [SP], #0x10
    // 0x62cef4: ret
    //     0x62cef4: ret             
    // 0x62cef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62cef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62cefc: b               #0x62cea4
    // 0x62cf00: SaveReg d0
    //     0x62cf00: str             q0, [SP, #-0x10]!
    // 0x62cf04: r0 = AllocateDouble()
    //     0x62cf04: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62cf08: RestoreReg d0
    //     0x62cf08: ldr             q0, [SP], #0x10
    // 0x62cf0c: b               #0x62cee8
  }
  _ _computeIntrinsicHeight(/* No info */) {
    // ** addr: 0x62cf10, size: 0x11c
    // 0x62cf10: EnterFrame
    //     0x62cf10: stp             fp, lr, [SP, #-0x10]!
    //     0x62cf14: mov             fp, SP
    // 0x62cf18: CheckStackOverflow
    //     0x62cf18: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62cf1c: cmp             SP, x16
    //     0x62cf20: b.ls            #0x62d010
    // 0x62cf24: ldr             x16, [fp, #0x18]
    // 0x62cf28: SaveReg r16
    //     0x62cf28: str             x16, [SP, #-8]!
    // 0x62cf2c: r0 = _canComputeIntrinsics()
    //     0x62cf2c: bl              #0x62d81c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_canComputeIntrinsics
    // 0x62cf30: add             SP, SP, #8
    // 0x62cf34: tbz             w0, #4, #0x62cf48
    // 0x62cf38: d0 = 0.000000
    //     0x62cf38: eor             v0.16b, v0.16b, v0.16b
    // 0x62cf3c: LeaveFrame
    //     0x62cf3c: mov             SP, fp
    //     0x62cf40: ldp             fp, lr, [SP], #0x10
    // 0x62cf44: ret
    //     0x62cf44: ret             
    // 0x62cf48: ldr             x0, [fp, #0x18]
    // 0x62cf4c: ldr             d0, [fp, #0x10]
    // 0x62cf50: SaveReg r0
    //     0x62cf50: str             x0, [SP, #-8]!
    // 0x62cf54: SaveReg d0
    //     0x62cf54: str             d0, [SP, #-8]!
    // 0x62cf58: r0 = _computeChildrenHeightWithMinIntrinsics()
    //     0x62cf58: bl              #0x62d02c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_computeChildrenHeightWithMinIntrinsics
    // 0x62cf5c: add             SP, SP, #0x10
    // 0x62cf60: ldr             d0, [fp, #0x10]
    // 0x62cf64: r0 = inline_Allocate_Double()
    //     0x62cf64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x62cf68: add             x0, x0, #0x10
    //     0x62cf6c: cmp             x1, x0
    //     0x62cf70: b.ls            #0x62d018
    //     0x62cf74: str             x0, [THR, #0x60]  ; THR::top
    //     0x62cf78: sub             x0, x0, #0xf
    //     0x62cf7c: mov             x1, #0xd108
    //     0x62cf80: movk            x1, #3, lsl #16
    //     0x62cf84: stur            x1, [x0, #-1]
    // 0x62cf88: StoreField: r0->field_7 = d0
    //     0x62cf88: stur            d0, [x0, #7]
    // 0x62cf8c: ldr             x16, [fp, #0x18]
    // 0x62cf90: stp             x0, x16, [SP, #-0x10]!
    // 0x62cf94: SaveReg r0
    //     0x62cf94: str             x0, [SP, #-8]!
    // 0x62cf98: r4 = const [0, 0x3, 0x3, 0x1, maxWidth, 0x2, minWidth, 0x1, null]
    //     0x62cf98: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f588] List(9) [0, 0x3, 0x3, 0x1, "maxWidth", 0x2, "minWidth", 0x1, Null]
    //     0x62cf9c: ldr             x4, [x4, #0x588]
    // 0x62cfa0: r0 = layoutText()
    //     0x62cfa0: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x62cfa4: add             SP, SP, #0x18
    // 0x62cfa8: ldr             x0, [fp, #0x18]
    // 0x62cfac: LoadField: r1 = r0->field_eb
    //     0x62cfac: ldur            w1, [x0, #0xeb]
    // 0x62cfb0: DecompressPointer r1
    //     0x62cfb0: add             x1, x1, HEAP, lsl #32
    // 0x62cfb4: LoadField: r0 = r1->field_7
    //     0x62cfb4: ldur            w0, [x1, #7]
    // 0x62cfb8: DecompressPointer r0
    //     0x62cfb8: add             x0, x0, HEAP, lsl #32
    // 0x62cfbc: cmp             w0, NULL
    // 0x62cfc0: b.eq            #0x62d028
    // 0x62cfc4: SaveReg r0
    //     0x62cfc4: str             x0, [SP, #-8]!
    // 0x62cfc8: r0 = height()
    //     0x62cfc8: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0x62cfcc: add             SP, SP, #8
    // 0x62cfd0: stp             fp, lr, [SP, #-0x10]!
    // 0x62cfd4: mov             fp, SP
    // 0x62cfd8: CallRuntime_LibcCeil(double) -> double
    //     0x62cfd8: and             SP, SP, #0xfffffffffffffff0
    //     0x62cfdc: mov             sp, SP
    //     0x62cfe0: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x62cfe4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x62cfe8: blr             x16
    //     0x62cfec: mov             x16, #8
    //     0x62cff0: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x62cff4: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x62cff8: sub             sp, x16, #1, lsl #12
    //     0x62cffc: mov             SP, fp
    //     0x62d000: ldp             fp, lr, [SP], #0x10
    // 0x62d004: LeaveFrame
    //     0x62d004: mov             SP, fp
    //     0x62d008: ldp             fp, lr, [SP], #0x10
    // 0x62d00c: ret
    //     0x62d00c: ret             
    // 0x62d010: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d010: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d014: b               #0x62cf24
    // 0x62d018: SaveReg d0
    //     0x62d018: str             q0, [SP, #-0x10]!
    // 0x62d01c: r0 = AllocateDouble()
    //     0x62d01c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x62d020: RestoreReg d0
    //     0x62d020: ldr             q0, [SP], #0x10
    // 0x62d024: b               #0x62cf88
    // 0x62d028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62d028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _computeChildrenHeightWithMinIntrinsics(/* No info */) {
    // ** addr: 0x62d02c, size: 0x368
    // 0x62d02c: EnterFrame
    //     0x62d02c: stp             fp, lr, [SP, #-0x10]!
    //     0x62d030: mov             fp, SP
    // 0x62d034: AllocStack(0x40)
    //     0x62d034: sub             SP, SP, #0x40
    // 0x62d038: CheckStackOverflow
    //     0x62d038: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d03c: cmp             SP, x16
    //     0x62d040: b.ls            #0x62d360
    // 0x62d044: ldr             x3, [fp, #0x18]
    // 0x62d048: LoadField: r4 = r3->field_67
    //     0x62d048: ldur            w4, [x3, #0x67]
    // 0x62d04c: DecompressPointer r4
    //     0x62d04c: add             x4, x4, HEAP, lsl #32
    // 0x62d050: stur            x4, [fp, #-0x10]
    // 0x62d054: LoadField: r5 = r3->field_5f
    //     0x62d054: ldur            x5, [x3, #0x5f]
    // 0x62d058: stur            x5, [fp, #-8]
    // 0x62d05c: r0 = BoxInt64Instr(r5)
    //     0x62d05c: sbfiz           x0, x5, #1, #0x1f
    //     0x62d060: cmp             x5, x0, asr #1
    //     0x62d064: b.eq            #0x62d070
    //     0x62d068: bl              #0xd69bb8
    //     0x62d06c: stur            x5, [x0, #7]
    // 0x62d070: mov             x2, x0
    // 0x62d074: r1 = <PlaceholderDimensions>
    //     0x62d074: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x62d078: ldr             x1, [x1, #0x320]
    // 0x62d07c: r0 = AllocateArray()
    //     0x62d07c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x62d080: stur            x0, [fp, #-0x18]
    // 0x62d084: ldur            x1, [fp, #-8]
    // 0x62d088: r2 = 0
    //     0x62d088: mov             x2, #0
    // 0x62d08c: CheckStackOverflow
    //     0x62d08c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d090: cmp             SP, x16
    //     0x62d094: b.ls            #0x62d368
    // 0x62d098: cmp             x2, x1
    // 0x62d09c: b.ge            #0x62d0bc
    // 0x62d0a0: add             x3, x0, x2, lsl #2
    // 0x62d0a4: r17 = Instance_PlaceholderDimensions
    //     0x62d0a4: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x62d0a8: ldr             x17, [x17, #0x458]
    // 0x62d0ac: StoreField: r3->field_f = r17
    //     0x62d0ac: stur            w17, [x3, #0xf]
    // 0x62d0b0: add             x3, x2, #1
    // 0x62d0b4: mov             x2, x3
    // 0x62d0b8: b               #0x62d08c
    // 0x62d0bc: ldr             d0, [fp, #0x10]
    // 0x62d0c0: ldr             x16, [fp, #0x18]
    // 0x62d0c4: SaveReg r16
    //     0x62d0c4: str             x16, [SP, #-8]!
    // 0x62d0c8: r0 = textScaleFactor()
    //     0x62d0c8: bl              #0x62d764  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::textScaleFactor
    // 0x62d0cc: add             SP, SP, #8
    // 0x62d0d0: mov             v1.16b, v0.16b
    // 0x62d0d4: ldr             d0, [fp, #0x10]
    // 0x62d0d8: fdiv            d2, d0, d1
    // 0x62d0dc: stur            d2, [fp, #-0x40]
    // 0x62d0e0: ldur            x2, [fp, #-0x10]
    // 0x62d0e4: r1 = 0
    //     0x62d0e4: mov             x1, #0
    // 0x62d0e8: ldr             x0, [fp, #0x18]
    // 0x62d0ec: stur            x2, [fp, #-0x10]
    // 0x62d0f0: stur            x1, [fp, #-0x20]
    // 0x62d0f4: CheckStackOverflow
    //     0x62d0f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d0f8: cmp             SP, x16
    //     0x62d0fc: b.ls            #0x62d370
    // 0x62d100: cmp             w2, NULL
    // 0x62d104: b.eq            #0x62d334
    // 0x62d108: LoadField: r3 = r0->field_5f
    //     0x62d108: ldur            x3, [x0, #0x5f]
    // 0x62d10c: cmp             x1, x3
    // 0x62d110: b.ge            #0x62d334
    // 0x62d114: r0 = BoxConstraints()
    //     0x62d114: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x62d118: d0 = 0.000000
    //     0x62d118: eor             v0.16b, v0.16b, v0.16b
    // 0x62d11c: stur            x0, [fp, #-0x28]
    // 0x62d120: StoreField: r0->field_7 = d0
    //     0x62d120: stur            d0, [x0, #7]
    // 0x62d124: ldur            d1, [fp, #-0x40]
    // 0x62d128: StoreField: r0->field_f = d1
    //     0x62d128: stur            d1, [x0, #0xf]
    // 0x62d12c: StoreField: r0->field_17 = d0
    //     0x62d12c: stur            d0, [x0, #0x17]
    // 0x62d130: d2 = inf
    //     0x62d130: ldr             d2, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x62d134: StoreField: r0->field_1f = d2
    //     0x62d134: stur            d2, [x0, #0x1f]
    // 0x62d138: r1 = 2
    //     0x62d138: mov             x1, #2
    // 0x62d13c: r0 = AllocateContext()
    //     0x62d13c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x62d140: mov             x1, x0
    // 0x62d144: ldur            x0, [fp, #-0x10]
    // 0x62d148: stur            x1, [fp, #-0x30]
    // 0x62d14c: StoreField: r1->field_f = r0
    //     0x62d14c: stur            w0, [x1, #0xf]
    // 0x62d150: ldur            x2, [fp, #-0x28]
    // 0x62d154: StoreField: r1->field_13 = r2
    //     0x62d154: stur            w2, [x1, #0x13]
    // 0x62d158: LoadField: r3 = r0->field_53
    //     0x62d158: ldur            w3, [x0, #0x53]
    // 0x62d15c: DecompressPointer r3
    //     0x62d15c: add             x3, x3, HEAP, lsl #32
    // 0x62d160: cmp             w3, NULL
    // 0x62d164: b.ne            #0x62d1b0
    // 0x62d168: r16 = <BoxConstraints, Size>
    //     0x62d168: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] TypeArguments: <BoxConstraints, Size>
    //     0x62d16c: ldr             x16, [x16, #0x208]
    // 0x62d170: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x62d174: stp             lr, x16, [SP, #-0x10]!
    // 0x62d178: r0 = Map._fromLiteral()
    //     0x62d178: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x62d17c: add             SP, SP, #0x10
    // 0x62d180: mov             x3, x0
    // 0x62d184: ldur            x4, [fp, #-0x10]
    // 0x62d188: StoreField: r4->field_53 = r0
    //     0x62d188: stur            w0, [x4, #0x53]
    //     0x62d18c: tbz             w0, #0, #0x62d1a8
    //     0x62d190: ldurb           w16, [x4, #-1]
    //     0x62d194: ldurb           w17, [x0, #-1]
    //     0x62d198: and             x16, x17, x16, lsr #2
    //     0x62d19c: tst             x16, HEAP, lsr #32
    //     0x62d1a0: b.eq            #0x62d1a8
    //     0x62d1a4: bl              #0xd682cc
    // 0x62d1a8: mov             x5, x3
    // 0x62d1ac: b               #0x62d1b8
    // 0x62d1b0: mov             x4, x0
    // 0x62d1b4: mov             x5, x3
    // 0x62d1b8: ldr             x0, [fp, #0x18]
    // 0x62d1bc: ldur            x3, [fp, #-0x20]
    // 0x62d1c0: ldur            x2, [fp, #-0x30]
    // 0x62d1c4: stur            x5, [fp, #-0x38]
    // 0x62d1c8: cmp             w5, NULL
    // 0x62d1cc: b.eq            #0x62d378
    // 0x62d1d0: LoadField: r6 = r2->field_13
    //     0x62d1d0: ldur            w6, [x2, #0x13]
    // 0x62d1d4: DecompressPointer r6
    //     0x62d1d4: add             x6, x6, HEAP, lsl #32
    // 0x62d1d8: stur            x6, [fp, #-0x28]
    // 0x62d1dc: r1 = Function '<anonymous closure>':.
    //     0x62d1dc: add             x1, PP, #0x15, lsl #12  ; [pp+0x15210] AnonymousClosure: (0x62d778), in [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout (0x62d394)
    //     0x62d1e0: ldr             x1, [x1, #0x210]
    // 0x62d1e4: r0 = AllocateClosure()
    //     0x62d1e4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x62d1e8: ldur            x16, [fp, #-0x38]
    // 0x62d1ec: ldur            lr, [fp, #-0x28]
    // 0x62d1f0: stp             lr, x16, [SP, #-0x10]!
    // 0x62d1f4: SaveReg r0
    //     0x62d1f4: str             x0, [SP, #-8]!
    // 0x62d1f8: r0 = putIfAbsent()
    //     0x62d1f8: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x62d1fc: add             SP, SP, #0x18
    // 0x62d200: mov             x3, x0
    // 0x62d204: ldr             x2, [fp, #0x18]
    // 0x62d208: stur            x3, [fp, #-0x38]
    // 0x62d20c: LoadField: r4 = r2->field_7b
    //     0x62d20c: ldur            w4, [x2, #0x7b]
    // 0x62d210: DecompressPointer r4
    //     0x62d210: add             x4, x4, HEAP, lsl #32
    // 0x62d214: r16 = Sentinel
    //     0x62d214: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x62d218: cmp             w4, w16
    // 0x62d21c: b.eq            #0x62d37c
    // 0x62d220: LoadField: r0 = r4->field_b
    //     0x62d220: ldur            w0, [x4, #0xb]
    // 0x62d224: DecompressPointer r0
    //     0x62d224: add             x0, x0, HEAP, lsl #32
    // 0x62d228: r1 = LoadInt32Instr(r0)
    //     0x62d228: sbfx            x1, x0, #1, #0x1f
    // 0x62d22c: mov             x0, x1
    // 0x62d230: ldur            x1, [fp, #-0x20]
    // 0x62d234: cmp             x1, x0
    // 0x62d238: b.hs            #0x62d388
    // 0x62d23c: LoadField: r0 = r4->field_f
    //     0x62d23c: ldur            w0, [x4, #0xf]
    // 0x62d240: DecompressPointer r0
    //     0x62d240: add             x0, x0, HEAP, lsl #32
    // 0x62d244: ldur            x1, [fp, #-0x20]
    // 0x62d248: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x62d248: add             x16, x0, x1, lsl #2
    //     0x62d24c: ldur            w4, [x16, #0xf]
    // 0x62d250: DecompressPointer r4
    //     0x62d250: add             x4, x4, HEAP, lsl #32
    // 0x62d254: LoadField: r0 = r4->field_b
    //     0x62d254: ldur            w0, [x4, #0xb]
    // 0x62d258: DecompressPointer r0
    //     0x62d258: add             x0, x0, HEAP, lsl #32
    // 0x62d25c: stur            x0, [fp, #-0x30]
    // 0x62d260: LoadField: r5 = r4->field_f
    //     0x62d260: ldur            w5, [x4, #0xf]
    // 0x62d264: DecompressPointer r5
    //     0x62d264: add             x5, x5, HEAP, lsl #32
    // 0x62d268: stur            x5, [fp, #-0x28]
    // 0x62d26c: r0 = PlaceholderDimensions()
    //     0x62d26c: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x62d270: mov             x2, x0
    // 0x62d274: ldur            x0, [fp, #-0x38]
    // 0x62d278: StoreField: r2->field_7 = r0
    //     0x62d278: stur            w0, [x2, #7]
    // 0x62d27c: ldur            x0, [fp, #-0x30]
    // 0x62d280: StoreField: r2->field_b = r0
    //     0x62d280: stur            w0, [x2, #0xb]
    // 0x62d284: ldur            x0, [fp, #-0x28]
    // 0x62d288: StoreField: r2->field_13 = r0
    //     0x62d288: stur            w0, [x2, #0x13]
    // 0x62d28c: ldur            x0, [fp, #-8]
    // 0x62d290: ldur            x1, [fp, #-0x20]
    // 0x62d294: cmp             x1, x0
    // 0x62d298: b.hs            #0x62d38c
    // 0x62d29c: ldur            x1, [fp, #-0x18]
    // 0x62d2a0: mov             x0, x2
    // 0x62d2a4: ldur            x3, [fp, #-0x20]
    // 0x62d2a8: ArrayStore: r1[r3] = r0  ; List_4
    //     0x62d2a8: add             x25, x1, x3, lsl #2
    //     0x62d2ac: add             x25, x25, #0xf
    //     0x62d2b0: str             w0, [x25]
    //     0x62d2b4: tbz             w0, #0, #0x62d2d0
    //     0x62d2b8: ldurb           w16, [x1, #-1]
    //     0x62d2bc: ldurb           w17, [x0, #-1]
    //     0x62d2c0: and             x16, x17, x16, lsr #2
    //     0x62d2c4: tst             x16, HEAP, lsr #32
    //     0x62d2c8: b.eq            #0x62d2d0
    //     0x62d2cc: bl              #0xd67e5c
    // 0x62d2d0: ldur            x0, [fp, #-0x10]
    // 0x62d2d4: LoadField: r4 = r0->field_17
    //     0x62d2d4: ldur            w4, [x0, #0x17]
    // 0x62d2d8: DecompressPointer r4
    //     0x62d2d8: add             x4, x4, HEAP, lsl #32
    // 0x62d2dc: stur            x4, [fp, #-0x28]
    // 0x62d2e0: cmp             w4, NULL
    // 0x62d2e4: b.eq            #0x62d390
    // 0x62d2e8: mov             x0, x4
    // 0x62d2ec: r2 = Null
    //     0x62d2ec: mov             x2, NULL
    // 0x62d2f0: r1 = Null
    //     0x62d2f0: mov             x1, NULL
    // 0x62d2f4: r4 = LoadClassIdInstr(r0)
    //     0x62d2f4: ldur            x4, [x0, #-1]
    //     0x62d2f8: ubfx            x4, x4, #0xc, #0x14
    // 0x62d2fc: cmp             x4, #0x808
    // 0x62d300: b.eq            #0x62d318
    // 0x62d304: r8 = TextParentData<RenderBox>
    //     0x62d304: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x62d308: ldr             x8, [x8, #0x298]
    // 0x62d30c: r3 = Null
    //     0x62d30c: add             x3, PP, #0x56, lsl #12  ; [pp+0x566d8] Null
    //     0x62d310: ldr             x3, [x3, #0x6d8]
    // 0x62d314: r0 = DefaultTypeTest()
    //     0x62d314: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x62d318: ldur            x0, [fp, #-0x28]
    // 0x62d31c: LoadField: r2 = r0->field_13
    //     0x62d31c: ldur            w2, [x0, #0x13]
    // 0x62d320: DecompressPointer r2
    //     0x62d320: add             x2, x2, HEAP, lsl #32
    // 0x62d324: ldur            x0, [fp, #-0x20]
    // 0x62d328: add             x1, x0, #1
    // 0x62d32c: ldur            d2, [fp, #-0x40]
    // 0x62d330: b               #0x62d0e8
    // 0x62d334: ldr             x0, [fp, #0x18]
    // 0x62d338: LoadField: r1 = r0->field_eb
    //     0x62d338: ldur            w1, [x0, #0xeb]
    // 0x62d33c: DecompressPointer r1
    //     0x62d33c: add             x1, x1, HEAP, lsl #32
    // 0x62d340: ldur            x16, [fp, #-0x18]
    // 0x62d344: stp             x16, x1, [SP, #-0x10]!
    // 0x62d348: r0 = setPlaceholderDimensions()
    //     0x62d348: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x62d34c: add             SP, SP, #0x10
    // 0x62d350: r0 = Null
    //     0x62d350: mov             x0, NULL
    // 0x62d354: LeaveFrame
    //     0x62d354: mov             SP, fp
    //     0x62d358: ldp             fp, lr, [SP], #0x10
    // 0x62d35c: ret
    //     0x62d35c: ret             
    // 0x62d360: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d360: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d364: b               #0x62d044
    // 0x62d368: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d368: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d36c: b               #0x62d098
    // 0x62d370: r0 = StackOverflowSharedWithFPURegs()
    //     0x62d370: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x62d374: b               #0x62d100
    // 0x62d378: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62d378: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x62d37c: r9 = _placeholderSpans
    //     0x62d37c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x62d380: ldr             x9, [x9, #0x368]
    // 0x62d384: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x62d384: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x62d388: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x62d388: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x62d38c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x62d38c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x62d390: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x62d390: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ textScaleFactor(/* No info */) {
    // ** addr: 0x62d764, size: 0x14
    // 0x62d764: ldr             x0, [SP]
    // 0x62d768: LoadField: r1 = r0->field_eb
    //     0x62d768: ldur            w1, [x0, #0xeb]
    // 0x62d76c: DecompressPointer r1
    //     0x62d76c: add             x1, x1, HEAP, lsl #32
    // 0x62d770: LoadField: d0 = r1->field_1f
    //     0x62d770: ldur            d0, [x1, #0x1f]
    // 0x62d774: ret
    //     0x62d774: ret             
  }
  _ _canComputeIntrinsics(/* No info */) {
    // ** addr: 0x62d81c, size: 0x1b0
    // 0x62d81c: EnterFrame
    //     0x62d81c: stp             fp, lr, [SP, #-0x10]!
    //     0x62d820: mov             fp, SP
    // 0x62d824: AllocStack(0x30)
    //     0x62d824: sub             SP, SP, #0x30
    // 0x62d828: CheckStackOverflow
    //     0x62d828: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d82c: cmp             SP, x16
    //     0x62d830: b.ls            #0x62d9b0
    // 0x62d834: ldr             x0, [fp, #0x10]
    // 0x62d838: LoadField: r1 = r0->field_7b
    //     0x62d838: ldur            w1, [x0, #0x7b]
    // 0x62d83c: DecompressPointer r1
    //     0x62d83c: add             x1, x1, HEAP, lsl #32
    // 0x62d840: r16 = Sentinel
    //     0x62d840: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x62d844: cmp             w1, w16
    // 0x62d848: b.eq            #0x62d9b8
    // 0x62d84c: stur            x1, [fp, #-0x20]
    // 0x62d850: LoadField: r2 = r1->field_7
    //     0x62d850: ldur            w2, [x1, #7]
    // 0x62d854: DecompressPointer r2
    //     0x62d854: add             x2, x2, HEAP, lsl #32
    // 0x62d858: stur            x2, [fp, #-0x18]
    // 0x62d85c: LoadField: r0 = r1->field_b
    //     0x62d85c: ldur            w0, [x1, #0xb]
    // 0x62d860: DecompressPointer r0
    //     0x62d860: add             x0, x0, HEAP, lsl #32
    // 0x62d864: r3 = LoadInt32Instr(r0)
    //     0x62d864: sbfx            x3, x0, #1, #0x1f
    // 0x62d868: stur            x3, [fp, #-0x10]
    // 0x62d86c: r4 = 0
    //     0x62d86c: mov             x4, #0
    // 0x62d870: stur            x4, [fp, #-8]
    // 0x62d874: CheckStackOverflow
    //     0x62d874: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x62d878: cmp             SP, x16
    //     0x62d87c: b.ls            #0x62d9c4
    // 0x62d880: r0 = LoadClassIdInstr(r1)
    //     0x62d880: ldur            x0, [x1, #-1]
    //     0x62d884: ubfx            x0, x0, #0xc, #0x14
    // 0x62d888: SaveReg r1
    //     0x62d888: str             x1, [SP, #-8]!
    // 0x62d88c: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x62d88c: mov             x17, #0xb8ea
    //     0x62d890: add             lr, x0, x17
    //     0x62d894: ldr             lr, [x21, lr, lsl #3]
    //     0x62d898: blr             lr
    // 0x62d89c: add             SP, SP, #8
    // 0x62d8a0: r1 = LoadInt32Instr(r0)
    //     0x62d8a0: sbfx            x1, x0, #1, #0x1f
    //     0x62d8a4: tbz             w0, #0, #0x62d8ac
    //     0x62d8a8: ldur            x1, [x0, #7]
    // 0x62d8ac: ldur            x2, [fp, #-0x10]
    // 0x62d8b0: cmp             x2, x1
    // 0x62d8b4: b.ne            #0x62d998
    // 0x62d8b8: ldur            x3, [fp, #-0x20]
    // 0x62d8bc: ldur            x4, [fp, #-8]
    // 0x62d8c0: cmp             x4, x1
    // 0x62d8c4: b.lt            #0x62d8d8
    // 0x62d8c8: r0 = true
    //     0x62d8c8: add             x0, NULL, #0x20  ; true
    // 0x62d8cc: LeaveFrame
    //     0x62d8cc: mov             SP, fp
    //     0x62d8d0: ldp             fp, lr, [SP], #0x10
    // 0x62d8d4: ret
    //     0x62d8d4: ret             
    // 0x62d8d8: r0 = BoxInt64Instr(r4)
    //     0x62d8d8: sbfiz           x0, x4, #1, #0x1f
    //     0x62d8dc: cmp             x4, x0, asr #1
    //     0x62d8e0: b.eq            #0x62d8ec
    //     0x62d8e4: bl              #0xd69bb8
    //     0x62d8e8: stur            x4, [x0, #7]
    // 0x62d8ec: r1 = LoadClassIdInstr(r3)
    //     0x62d8ec: ldur            x1, [x3, #-1]
    //     0x62d8f0: ubfx            x1, x1, #0xc, #0x14
    // 0x62d8f4: stp             x0, x3, [SP, #-0x10]!
    // 0x62d8f8: mov             x0, x1
    // 0x62d8fc: r0 = GDT[cid_x0 + 0xd175]()
    //     0x62d8fc: mov             x17, #0xd175
    //     0x62d900: add             lr, x0, x17
    //     0x62d904: ldr             lr, [x21, lr, lsl #3]
    //     0x62d908: blr             lr
    // 0x62d90c: add             SP, SP, #0x10
    // 0x62d910: mov             x3, x0
    // 0x62d914: ldur            x0, [fp, #-8]
    // 0x62d918: stur            x3, [fp, #-0x30]
    // 0x62d91c: add             x4, x0, #1
    // 0x62d920: stur            x4, [fp, #-0x28]
    // 0x62d924: cmp             w3, NULL
    // 0x62d928: b.ne            #0x62d95c
    // 0x62d92c: mov             x0, x3
    // 0x62d930: ldur            x2, [fp, #-0x18]
    // 0x62d934: r1 = Null
    //     0x62d934: mov             x1, NULL
    // 0x62d938: cmp             w2, NULL
    // 0x62d93c: b.eq            #0x62d95c
    // 0x62d940: LoadField: r4 = r2->field_17
    //     0x62d940: ldur            w4, [x2, #0x17]
    // 0x62d944: DecompressPointer r4
    //     0x62d944: add             x4, x4, HEAP, lsl #32
    // 0x62d948: r8 = X0
    //     0x62d948: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x62d94c: LoadField: r9 = r4->field_7
    //     0x62d94c: ldur            x9, [x4, #7]
    // 0x62d950: r3 = Null
    //     0x62d950: add             x3, PP, #0x56, lsl #12  ; [pp+0x566a8] Null
    //     0x62d954: ldr             x3, [x3, #0x6a8]
    // 0x62d958: blr             x9
    // 0x62d95c: ldur            x1, [fp, #-0x30]
    // 0x62d960: LoadField: r2 = r1->field_b
    //     0x62d960: ldur            w2, [x1, #0xb]
    // 0x62d964: DecompressPointer r2
    //     0x62d964: add             x2, x2, HEAP, lsl #32
    // 0x62d968: LoadField: r1 = r2->field_7
    //     0x62d968: ldur            x1, [x2, #7]
    // 0x62d96c: cmp             x1, #2
    // 0x62d970: b.gt            #0x62d984
    // 0x62d974: r0 = false
    //     0x62d974: add             x0, NULL, #0x30  ; false
    // 0x62d978: LeaveFrame
    //     0x62d978: mov             SP, fp
    //     0x62d97c: ldp             fp, lr, [SP], #0x10
    // 0x62d980: ret
    //     0x62d980: ret             
    // 0x62d984: ldur            x4, [fp, #-0x28]
    // 0x62d988: ldur            x1, [fp, #-0x20]
    // 0x62d98c: ldur            x2, [fp, #-0x18]
    // 0x62d990: ldur            x3, [fp, #-0x10]
    // 0x62d994: b               #0x62d870
    // 0x62d998: ldur            x0, [fp, #-0x20]
    // 0x62d99c: r0 = ConcurrentModificationError()
    //     0x62d99c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x62d9a0: ldur            x3, [fp, #-0x20]
    // 0x62d9a4: StoreField: r0->field_b = r3
    //     0x62d9a4: stur            w3, [x0, #0xb]
    // 0x62d9a8: r0 = Throw()
    //     0x62d9a8: bl              #0xd67e38  ; ThrowStub
    // 0x62d9ac: brk             #0
    // 0x62d9b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d9b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d9b4: b               #0x62d834
    // 0x62d9b8: r9 = _placeholderSpans
    //     0x62d9b8: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x62d9bc: ldr             x9, [x9, #0x368]
    // 0x62d9c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x62d9c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x62d9c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x62d9c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x62d9c8: b               #0x62d880
  }
  dynamic computeMaxIntrinsicWidth(dynamic) {
    // ** addr: 0x63499c, size: 0x18
    // 0x63499c: r4 = 0
    //     0x63499c: mov             x4, #0
    // 0x6349a0: r1 = Function 'computeMaxIntrinsicWidth':.
    //     0x6349a0: add             x17, PP, #0x56, lsl #12  ; [pp+0x56690] AnonymousClosure: (0x6349b4), in [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeMaxIntrinsicWidth (0x634a00)
    //     0x6349a4: ldr             x1, [x17, #0x690]
    // 0x6349a8: r24 = BuildNonGenericMethodExtractorStub
    //     0x6349a8: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x6349ac: LoadField: r0 = r24->field_17
    //     0x6349ac: ldur            x0, [x24, #0x17]
    // 0x6349b0: br              x0
  }
  [closure] double computeMaxIntrinsicWidth(dynamic, double) {
    // ** addr: 0x6349b4, size: 0x4c
    // 0x6349b4: EnterFrame
    //     0x6349b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6349b8: mov             fp, SP
    // 0x6349bc: ldr             x0, [fp, #0x18]
    // 0x6349c0: LoadField: r1 = r0->field_17
    //     0x6349c0: ldur            w1, [x0, #0x17]
    // 0x6349c4: DecompressPointer r1
    //     0x6349c4: add             x1, x1, HEAP, lsl #32
    // 0x6349c8: CheckStackOverflow
    //     0x6349c8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6349cc: cmp             SP, x16
    //     0x6349d0: b.ls            #0x6349f8
    // 0x6349d4: LoadField: r0 = r1->field_f
    //     0x6349d4: ldur            w0, [x1, #0xf]
    // 0x6349d8: DecompressPointer r0
    //     0x6349d8: add             x0, x0, HEAP, lsl #32
    // 0x6349dc: ldr             x16, [fp, #0x10]
    // 0x6349e0: stp             x16, x0, [SP, #-0x10]!
    // 0x6349e4: r0 = computeMaxIntrinsicWidth()
    //     0x6349e4: bl              #0x634a00  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeMaxIntrinsicWidth
    // 0x6349e8: add             SP, SP, #0x10
    // 0x6349ec: LeaveFrame
    //     0x6349ec: mov             SP, fp
    //     0x6349f0: ldp             fp, lr, [SP], #0x10
    // 0x6349f4: ret
    //     0x6349f4: ret             
    // 0x6349f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6349f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6349fc: b               #0x6349d4
  }
  _ computeMaxIntrinsicWidth(/* No info */) {
    // ** addr: 0x634a00, size: 0x108
    // 0x634a00: EnterFrame
    //     0x634a00: stp             fp, lr, [SP, #-0x10]!
    //     0x634a04: mov             fp, SP
    // 0x634a08: CheckStackOverflow
    //     0x634a08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634a0c: cmp             SP, x16
    //     0x634a10: b.ls            #0x634aec
    // 0x634a14: ldr             x16, [fp, #0x18]
    // 0x634a18: SaveReg r16
    //     0x634a18: str             x16, [SP, #-8]!
    // 0x634a1c: r0 = _canComputeIntrinsics()
    //     0x634a1c: bl              #0x62d81c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_canComputeIntrinsics
    // 0x634a20: add             SP, SP, #8
    // 0x634a24: tbz             w0, #4, #0x634a38
    // 0x634a28: r0 = 0.000000
    //     0x634a28: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x634a2c: LeaveFrame
    //     0x634a2c: mov             SP, fp
    //     0x634a30: ldp             fp, lr, [SP], #0x10
    // 0x634a34: ret
    //     0x634a34: ret             
    // 0x634a38: ldr             x0, [fp, #0x18]
    // 0x634a3c: SaveReg r0
    //     0x634a3c: str             x0, [SP, #-8]!
    // 0x634a40: r0 = _computeChildrenWidthWithMaxIntrinsics()
    //     0x634a40: bl              #0x634b08  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_computeChildrenWidthWithMaxIntrinsics
    // 0x634a44: add             SP, SP, #8
    // 0x634a48: ldr             x16, [fp, #0x18]
    // 0x634a4c: SaveReg r16
    //     0x634a4c: str             x16, [SP, #-8]!
    // 0x634a50: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x634a50: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x634a54: r0 = layoutText()
    //     0x634a54: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x634a58: add             SP, SP, #8
    // 0x634a5c: ldr             x0, [fp, #0x18]
    // 0x634a60: LoadField: r1 = r0->field_eb
    //     0x634a60: ldur            w1, [x0, #0xeb]
    // 0x634a64: DecompressPointer r1
    //     0x634a64: add             x1, x1, HEAP, lsl #32
    // 0x634a68: LoadField: r0 = r1->field_7
    //     0x634a68: ldur            w0, [x1, #7]
    // 0x634a6c: DecompressPointer r0
    //     0x634a6c: add             x0, x0, HEAP, lsl #32
    // 0x634a70: cmp             w0, NULL
    // 0x634a74: b.eq            #0x634af4
    // 0x634a78: SaveReg r0
    //     0x634a78: str             x0, [SP, #-8]!
    // 0x634a7c: r0 = maxIntrinsicWidth()
    //     0x634a7c: bl              #0x523ec4  ; [dart:ui] Paragraph::maxIntrinsicWidth
    // 0x634a80: add             SP, SP, #8
    // 0x634a84: stp             fp, lr, [SP, #-0x10]!
    // 0x634a88: mov             fp, SP
    // 0x634a8c: CallRuntime_LibcCeil(double) -> double
    //     0x634a8c: and             SP, SP, #0xfffffffffffffff0
    //     0x634a90: mov             sp, SP
    //     0x634a94: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x634a98: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x634a9c: blr             x16
    //     0x634aa0: mov             x16, #8
    //     0x634aa4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x634aa8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x634aac: sub             sp, x16, #1, lsl #12
    //     0x634ab0: mov             SP, fp
    //     0x634ab4: ldp             fp, lr, [SP], #0x10
    // 0x634ab8: r0 = inline_Allocate_Double()
    //     0x634ab8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x634abc: add             x0, x0, #0x10
    //     0x634ac0: cmp             x1, x0
    //     0x634ac4: b.ls            #0x634af8
    //     0x634ac8: str             x0, [THR, #0x60]  ; THR::top
    //     0x634acc: sub             x0, x0, #0xf
    //     0x634ad0: mov             x1, #0xd108
    //     0x634ad4: movk            x1, #3, lsl #16
    //     0x634ad8: stur            x1, [x0, #-1]
    // 0x634adc: StoreField: r0->field_7 = d0
    //     0x634adc: stur            d0, [x0, #7]
    // 0x634ae0: LeaveFrame
    //     0x634ae0: mov             SP, fp
    //     0x634ae4: ldp             fp, lr, [SP], #0x10
    // 0x634ae8: ret
    //     0x634ae8: ret             
    // 0x634aec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634aec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634af0: b               #0x634a14
    // 0x634af4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x634af4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x634af8: SaveReg d0
    //     0x634af8: str             q0, [SP, #-0x10]!
    // 0x634afc: r0 = AllocateDouble()
    //     0x634afc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x634b00: RestoreReg d0
    //     0x634b00: ldr             q0, [SP], #0x10
    // 0x634b04: b               #0x634adc
  }
  _ _computeChildrenWidthWithMaxIntrinsics(/* No info */) {
    // ** addr: 0x634b08, size: 0x2b8
    // 0x634b08: EnterFrame
    //     0x634b08: stp             fp, lr, [SP, #-0x10]!
    //     0x634b0c: mov             fp, SP
    // 0x634b10: AllocStack(0x40)
    //     0x634b10: sub             SP, SP, #0x40
    // 0x634b14: CheckStackOverflow
    //     0x634b14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634b18: cmp             SP, x16
    //     0x634b1c: b.ls            #0x634d90
    // 0x634b20: ldr             x3, [fp, #0x10]
    // 0x634b24: LoadField: r4 = r3->field_67
    //     0x634b24: ldur            w4, [x3, #0x67]
    // 0x634b28: DecompressPointer r4
    //     0x634b28: add             x4, x4, HEAP, lsl #32
    // 0x634b2c: stur            x4, [fp, #-0x10]
    // 0x634b30: LoadField: r5 = r3->field_5f
    //     0x634b30: ldur            x5, [x3, #0x5f]
    // 0x634b34: stur            x5, [fp, #-8]
    // 0x634b38: r0 = BoxInt64Instr(r5)
    //     0x634b38: sbfiz           x0, x5, #1, #0x1f
    //     0x634b3c: cmp             x5, x0, asr #1
    //     0x634b40: b.eq            #0x634b4c
    //     0x634b44: bl              #0xd69bb8
    //     0x634b48: stur            x5, [x0, #7]
    // 0x634b4c: mov             x2, x0
    // 0x634b50: r1 = <PlaceholderDimensions>
    //     0x634b50: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x634b54: ldr             x1, [x1, #0x320]
    // 0x634b58: r0 = AllocateArray()
    //     0x634b58: bl              #0xd6987c  ; AllocateArrayStub
    // 0x634b5c: mov             x1, x0
    // 0x634b60: stur            x1, [fp, #-0x20]
    // 0x634b64: ldur            x2, [fp, #-8]
    // 0x634b68: r0 = 0
    //     0x634b68: mov             x0, #0
    // 0x634b6c: CheckStackOverflow
    //     0x634b6c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634b70: cmp             SP, x16
    //     0x634b74: b.ls            #0x634d98
    // 0x634b78: cmp             x0, x2
    // 0x634b7c: b.ge            #0x634b9c
    // 0x634b80: add             x3, x1, x0, lsl #2
    // 0x634b84: r17 = Instance_PlaceholderDimensions
    //     0x634b84: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x634b88: ldr             x17, [x17, #0x458]
    // 0x634b8c: StoreField: r3->field_f = r17
    //     0x634b8c: stur            w17, [x3, #0xf]
    // 0x634b90: add             x3, x0, #1
    // 0x634b94: mov             x0, x3
    // 0x634b98: b               #0x634b6c
    // 0x634b9c: ldur            x5, [fp, #-0x10]
    // 0x634ba0: r4 = 0
    //     0x634ba0: mov             x4, #0
    // 0x634ba4: ldr             x3, [fp, #0x10]
    // 0x634ba8: stur            x5, [fp, #-0x10]
    // 0x634bac: stur            x4, [fp, #-0x18]
    // 0x634bb0: CheckStackOverflow
    //     0x634bb0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x634bb4: cmp             SP, x16
    //     0x634bb8: b.ls            #0x634da0
    // 0x634bbc: cmp             w5, NULL
    // 0x634bc0: b.eq            #0x634d64
    // 0x634bc4: LoadField: r0 = r3->field_5f
    //     0x634bc4: ldur            x0, [x3, #0x5f]
    // 0x634bc8: cmp             x4, x0
    // 0x634bcc: b.ge            #0x634d64
    // 0x634bd0: r0 = LoadClassIdInstr(r5)
    //     0x634bd0: ldur            x0, [x5, #-1]
    //     0x634bd4: ubfx            x0, x0, #0xc, #0x14
    // 0x634bd8: SaveReg r5
    //     0x634bd8: str             x5, [SP, #-8]!
    // 0x634bdc: r0 = GDT[cid_x0 + 0xf204]()
    //     0x634bdc: mov             x17, #0xf204
    //     0x634be0: add             lr, x0, x17
    //     0x634be4: ldr             lr, [x21, lr, lsl #3]
    //     0x634be8: blr             lr
    // 0x634bec: add             SP, SP, #8
    // 0x634bf0: ldur            x16, [fp, #-0x10]
    // 0x634bf4: r30 = Instance__IntrinsicDimension
    //     0x634bf4: add             lr, PP, #0x37, lsl #12  ; [pp+0x37080] Obj!_IntrinsicDimension@b64bf1
    //     0x634bf8: ldr             lr, [lr, #0x80]
    // 0x634bfc: stp             lr, x16, [SP, #-0x10]!
    // 0x634c00: d0 = inf
    //     0x634c00: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x634c04: SaveReg d0
    //     0x634c04: str             d0, [SP, #-8]!
    // 0x634c08: SaveReg r0
    //     0x634c08: str             x0, [SP, #-8]!
    // 0x634c0c: r0 = _computeIntrinsicDimension()
    //     0x634c0c: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x634c10: add             SP, SP, #0x20
    // 0x634c14: stur            d0, [fp, #-0x40]
    // 0x634c18: r0 = Size()
    //     0x634c18: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x634c1c: mov             x2, x0
    // 0x634c20: ldur            d0, [fp, #-0x40]
    // 0x634c24: stur            x2, [fp, #-0x38]
    // 0x634c28: StoreField: r2->field_7 = d0
    //     0x634c28: stur            d0, [x2, #7]
    // 0x634c2c: d0 = 0.000000
    //     0x634c2c: eor             v0.16b, v0.16b, v0.16b
    // 0x634c30: StoreField: r2->field_f = d0
    //     0x634c30: stur            d0, [x2, #0xf]
    // 0x634c34: ldr             x3, [fp, #0x10]
    // 0x634c38: LoadField: r4 = r3->field_7b
    //     0x634c38: ldur            w4, [x3, #0x7b]
    // 0x634c3c: DecompressPointer r4
    //     0x634c3c: add             x4, x4, HEAP, lsl #32
    // 0x634c40: r16 = Sentinel
    //     0x634c40: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x634c44: cmp             w4, w16
    // 0x634c48: b.eq            #0x634da8
    // 0x634c4c: LoadField: r0 = r4->field_b
    //     0x634c4c: ldur            w0, [x4, #0xb]
    // 0x634c50: DecompressPointer r0
    //     0x634c50: add             x0, x0, HEAP, lsl #32
    // 0x634c54: r1 = LoadInt32Instr(r0)
    //     0x634c54: sbfx            x1, x0, #1, #0x1f
    // 0x634c58: mov             x0, x1
    // 0x634c5c: ldur            x1, [fp, #-0x18]
    // 0x634c60: cmp             x1, x0
    // 0x634c64: b.hs            #0x634db4
    // 0x634c68: LoadField: r0 = r4->field_f
    //     0x634c68: ldur            w0, [x4, #0xf]
    // 0x634c6c: DecompressPointer r0
    //     0x634c6c: add             x0, x0, HEAP, lsl #32
    // 0x634c70: ldur            x1, [fp, #-0x18]
    // 0x634c74: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x634c74: add             x16, x0, x1, lsl #2
    //     0x634c78: ldur            w4, [x16, #0xf]
    // 0x634c7c: DecompressPointer r4
    //     0x634c7c: add             x4, x4, HEAP, lsl #32
    // 0x634c80: LoadField: r0 = r4->field_b
    //     0x634c80: ldur            w0, [x4, #0xb]
    // 0x634c84: DecompressPointer r0
    //     0x634c84: add             x0, x0, HEAP, lsl #32
    // 0x634c88: stur            x0, [fp, #-0x30]
    // 0x634c8c: LoadField: r5 = r4->field_f
    //     0x634c8c: ldur            w5, [x4, #0xf]
    // 0x634c90: DecompressPointer r5
    //     0x634c90: add             x5, x5, HEAP, lsl #32
    // 0x634c94: stur            x5, [fp, #-0x28]
    // 0x634c98: r0 = PlaceholderDimensions()
    //     0x634c98: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x634c9c: mov             x2, x0
    // 0x634ca0: ldur            x0, [fp, #-0x38]
    // 0x634ca4: StoreField: r2->field_7 = r0
    //     0x634ca4: stur            w0, [x2, #7]
    // 0x634ca8: ldur            x0, [fp, #-0x30]
    // 0x634cac: StoreField: r2->field_b = r0
    //     0x634cac: stur            w0, [x2, #0xb]
    // 0x634cb0: ldur            x0, [fp, #-0x28]
    // 0x634cb4: StoreField: r2->field_13 = r0
    //     0x634cb4: stur            w0, [x2, #0x13]
    // 0x634cb8: ldur            x0, [fp, #-8]
    // 0x634cbc: ldur            x1, [fp, #-0x18]
    // 0x634cc0: cmp             x1, x0
    // 0x634cc4: b.hs            #0x634db8
    // 0x634cc8: ldur            x1, [fp, #-0x20]
    // 0x634ccc: mov             x0, x2
    // 0x634cd0: ldur            x3, [fp, #-0x18]
    // 0x634cd4: ArrayStore: r1[r3] = r0  ; List_4
    //     0x634cd4: add             x25, x1, x3, lsl #2
    //     0x634cd8: add             x25, x25, #0xf
    //     0x634cdc: str             w0, [x25]
    //     0x634ce0: tbz             w0, #0, #0x634cfc
    //     0x634ce4: ldurb           w16, [x1, #-1]
    //     0x634ce8: ldurb           w17, [x0, #-1]
    //     0x634cec: and             x16, x17, x16, lsr #2
    //     0x634cf0: tst             x16, HEAP, lsr #32
    //     0x634cf4: b.eq            #0x634cfc
    //     0x634cf8: bl              #0xd67e5c
    // 0x634cfc: ldur            x0, [fp, #-0x10]
    // 0x634d00: LoadField: r4 = r0->field_17
    //     0x634d00: ldur            w4, [x0, #0x17]
    // 0x634d04: DecompressPointer r4
    //     0x634d04: add             x4, x4, HEAP, lsl #32
    // 0x634d08: stur            x4, [fp, #-0x28]
    // 0x634d0c: cmp             w4, NULL
    // 0x634d10: b.eq            #0x634dbc
    // 0x634d14: mov             x0, x4
    // 0x634d18: r2 = Null
    //     0x634d18: mov             x2, NULL
    // 0x634d1c: r1 = Null
    //     0x634d1c: mov             x1, NULL
    // 0x634d20: r4 = LoadClassIdInstr(r0)
    //     0x634d20: ldur            x4, [x0, #-1]
    //     0x634d24: ubfx            x4, x4, #0xc, #0x14
    // 0x634d28: cmp             x4, #0x808
    // 0x634d2c: b.eq            #0x634d44
    // 0x634d30: r8 = TextParentData<RenderBox>
    //     0x634d30: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x634d34: ldr             x8, [x8, #0x298]
    // 0x634d38: r3 = Null
    //     0x634d38: add             x3, PP, #0x56, lsl #12  ; [pp+0x56698] Null
    //     0x634d3c: ldr             x3, [x3, #0x698]
    // 0x634d40: r0 = DefaultTypeTest()
    //     0x634d40: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x634d44: ldur            x0, [fp, #-0x28]
    // 0x634d48: LoadField: r5 = r0->field_13
    //     0x634d48: ldur            w5, [x0, #0x13]
    // 0x634d4c: DecompressPointer r5
    //     0x634d4c: add             x5, x5, HEAP, lsl #32
    // 0x634d50: ldur            x0, [fp, #-0x18]
    // 0x634d54: add             x4, x0, #1
    // 0x634d58: ldur            x2, [fp, #-8]
    // 0x634d5c: ldur            x1, [fp, #-0x20]
    // 0x634d60: b               #0x634ba4
    // 0x634d64: ldr             x0, [fp, #0x10]
    // 0x634d68: LoadField: r1 = r0->field_eb
    //     0x634d68: ldur            w1, [x0, #0xeb]
    // 0x634d6c: DecompressPointer r1
    //     0x634d6c: add             x1, x1, HEAP, lsl #32
    // 0x634d70: ldur            x16, [fp, #-0x20]
    // 0x634d74: stp             x16, x1, [SP, #-0x10]!
    // 0x634d78: r0 = setPlaceholderDimensions()
    //     0x634d78: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x634d7c: add             SP, SP, #0x10
    // 0x634d80: r0 = Null
    //     0x634d80: mov             x0, NULL
    // 0x634d84: LeaveFrame
    //     0x634d84: mov             SP, fp
    //     0x634d88: ldp             fp, lr, [SP], #0x10
    // 0x634d8c: ret
    //     0x634d8c: ret             
    // 0x634d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634d90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634d94: b               #0x634b20
    // 0x634d98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634d98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634d9c: b               #0x634b78
    // 0x634da0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x634da0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x634da4: b               #0x634bbc
    // 0x634da8: r9 = _placeholderSpans
    //     0x634da8: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x634dac: ldr             x9, [x9, #0x368]
    // 0x634db0: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x634db0: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x634db4: r0 = RangeErrorSharedWithFPURegs()
    //     0x634db4: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x634db8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x634db8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x634dbc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x634dbc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic computeMinIntrinsicHeight(dynamic) {
    // ** addr: 0x638458, size: 0x18
    // 0x638458: r4 = 0
    //     0x638458: mov             x4, #0
    // 0x63845c: r1 = Function 'computeMinIntrinsicHeight':.
    //     0x63845c: add             x17, PP, #0x56, lsl #12  ; [pp+0x566e8] AnonymousClosure: (0x62ce84), of [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox
    //     0x638460: ldr             x1, [x17, #0x6e8]
    // 0x638464: r24 = BuildNonGenericMethodExtractorStub
    //     0x638464: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x638468: LoadField: r0 = r24->field_17
    //     0x638468: ldur            x0, [x24, #0x17]
    // 0x63846c: br              x0
  }
  dynamic computeMinIntrinsicWidth(dynamic) {
    // ** addr: 0x63a770, size: 0x18
    // 0x63a770: r4 = 0
    //     0x63a770: mov             x4, #0
    // 0x63a774: r1 = Function 'computeMinIntrinsicWidth':.
    //     0x63a774: add             x17, PP, #0x56, lsl #12  ; [pp+0x566b8] AnonymousClosure: (0x63a788), in [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeMinIntrinsicWidth (0x63a7d4)
    //     0x63a778: ldr             x1, [x17, #0x6b8]
    // 0x63a77c: r24 = BuildNonGenericMethodExtractorStub
    //     0x63a77c: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0x63a780: LoadField: r0 = r24->field_17
    //     0x63a780: ldur            x0, [x24, #0x17]
    // 0x63a784: br              x0
  }
  [closure] double computeMinIntrinsicWidth(dynamic, double) {
    // ** addr: 0x63a788, size: 0x4c
    // 0x63a788: EnterFrame
    //     0x63a788: stp             fp, lr, [SP, #-0x10]!
    //     0x63a78c: mov             fp, SP
    // 0x63a790: ldr             x0, [fp, #0x18]
    // 0x63a794: LoadField: r1 = r0->field_17
    //     0x63a794: ldur            w1, [x0, #0x17]
    // 0x63a798: DecompressPointer r1
    //     0x63a798: add             x1, x1, HEAP, lsl #32
    // 0x63a79c: CheckStackOverflow
    //     0x63a79c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a7a0: cmp             SP, x16
    //     0x63a7a4: b.ls            #0x63a7cc
    // 0x63a7a8: LoadField: r0 = r1->field_f
    //     0x63a7a8: ldur            w0, [x1, #0xf]
    // 0x63a7ac: DecompressPointer r0
    //     0x63a7ac: add             x0, x0, HEAP, lsl #32
    // 0x63a7b0: ldr             x16, [fp, #0x10]
    // 0x63a7b4: stp             x16, x0, [SP, #-0x10]!
    // 0x63a7b8: r0 = computeMinIntrinsicWidth()
    //     0x63a7b8: bl              #0x63a7d4  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::computeMinIntrinsicWidth
    // 0x63a7bc: add             SP, SP, #0x10
    // 0x63a7c0: LeaveFrame
    //     0x63a7c0: mov             SP, fp
    //     0x63a7c4: ldp             fp, lr, [SP], #0x10
    // 0x63a7c8: ret
    //     0x63a7c8: ret             
    // 0x63a7cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a7cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a7d0: b               #0x63a7a8
  }
  _ computeMinIntrinsicWidth(/* No info */) {
    // ** addr: 0x63a7d4, size: 0x108
    // 0x63a7d4: EnterFrame
    //     0x63a7d4: stp             fp, lr, [SP, #-0x10]!
    //     0x63a7d8: mov             fp, SP
    // 0x63a7dc: CheckStackOverflow
    //     0x63a7dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63a7e0: cmp             SP, x16
    //     0x63a7e4: b.ls            #0x63a8c0
    // 0x63a7e8: ldr             x16, [fp, #0x18]
    // 0x63a7ec: SaveReg r16
    //     0x63a7ec: str             x16, [SP, #-8]!
    // 0x63a7f0: r0 = _canComputeIntrinsics()
    //     0x63a7f0: bl              #0x62d81c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_canComputeIntrinsics
    // 0x63a7f4: add             SP, SP, #8
    // 0x63a7f8: tbz             w0, #4, #0x63a80c
    // 0x63a7fc: r0 = 0.000000
    //     0x63a7fc: ldr             x0, [PP, #0x7440]  ; [pp+0x7440] 0
    // 0x63a800: LeaveFrame
    //     0x63a800: mov             SP, fp
    //     0x63a804: ldp             fp, lr, [SP], #0x10
    // 0x63a808: ret
    //     0x63a808: ret             
    // 0x63a80c: ldr             x0, [fp, #0x18]
    // 0x63a810: SaveReg r0
    //     0x63a810: str             x0, [SP, #-8]!
    // 0x63a814: r0 = _computeChildrenWidthWithMinIntrinsics()
    //     0x63a814: bl              #0x63aae4  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::_computeChildrenWidthWithMinIntrinsics
    // 0x63a818: add             SP, SP, #8
    // 0x63a81c: ldr             x16, [fp, #0x18]
    // 0x63a820: SaveReg r16
    //     0x63a820: str             x16, [SP, #-8]!
    // 0x63a824: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x63a824: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x63a828: r0 = layoutText()
    //     0x63a828: bl              #0x52312c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::layoutText
    // 0x63a82c: add             SP, SP, #8
    // 0x63a830: ldr             x0, [fp, #0x18]
    // 0x63a834: LoadField: r1 = r0->field_eb
    //     0x63a834: ldur            w1, [x0, #0xeb]
    // 0x63a838: DecompressPointer r1
    //     0x63a838: add             x1, x1, HEAP, lsl #32
    // 0x63a83c: LoadField: r0 = r1->field_7
    //     0x63a83c: ldur            w0, [x1, #7]
    // 0x63a840: DecompressPointer r0
    //     0x63a840: add             x0, x0, HEAP, lsl #32
    // 0x63a844: cmp             w0, NULL
    // 0x63a848: b.eq            #0x63a8c8
    // 0x63a84c: SaveReg r0
    //     0x63a84c: str             x0, [SP, #-8]!
    // 0x63a850: r0 = minIntrinsicWidth()
    //     0x63a850: bl              #0x63a95c  ; [dart:ui] Paragraph::minIntrinsicWidth
    // 0x63a854: add             SP, SP, #8
    // 0x63a858: stp             fp, lr, [SP, #-0x10]!
    // 0x63a85c: mov             fp, SP
    // 0x63a860: CallRuntime_LibcCeil(double) -> double
    //     0x63a860: and             SP, SP, #0xfffffffffffffff0
    //     0x63a864: mov             sp, SP
    //     0x63a868: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0x63a86c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x63a870: blr             x16
    //     0x63a874: mov             x16, #8
    //     0x63a878: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0x63a87c: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0x63a880: sub             sp, x16, #1, lsl #12
    //     0x63a884: mov             SP, fp
    //     0x63a888: ldp             fp, lr, [SP], #0x10
    // 0x63a88c: r0 = inline_Allocate_Double()
    //     0x63a88c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x63a890: add             x0, x0, #0x10
    //     0x63a894: cmp             x1, x0
    //     0x63a898: b.ls            #0x63a8cc
    //     0x63a89c: str             x0, [THR, #0x60]  ; THR::top
    //     0x63a8a0: sub             x0, x0, #0xf
    //     0x63a8a4: mov             x1, #0xd108
    //     0x63a8a8: movk            x1, #3, lsl #16
    //     0x63a8ac: stur            x1, [x0, #-1]
    // 0x63a8b0: StoreField: r0->field_7 = d0
    //     0x63a8b0: stur            d0, [x0, #7]
    // 0x63a8b4: LeaveFrame
    //     0x63a8b4: mov             SP, fp
    //     0x63a8b8: ldp             fp, lr, [SP], #0x10
    // 0x63a8bc: ret
    //     0x63a8bc: ret             
    // 0x63a8c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63a8c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63a8c4: b               #0x63a7e8
    // 0x63a8c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63a8c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x63a8cc: SaveReg d0
    //     0x63a8cc: str             q0, [SP, #-0x10]!
    // 0x63a8d0: r0 = AllocateDouble()
    //     0x63a8d0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x63a8d4: RestoreReg d0
    //     0x63a8d4: ldr             q0, [SP], #0x10
    // 0x63a8d8: b               #0x63a8b0
  }
  _ _computeChildrenWidthWithMinIntrinsics(/* No info */) {
    // ** addr: 0x63aae4, size: 0x2b8
    // 0x63aae4: EnterFrame
    //     0x63aae4: stp             fp, lr, [SP, #-0x10]!
    //     0x63aae8: mov             fp, SP
    // 0x63aaec: AllocStack(0x40)
    //     0x63aaec: sub             SP, SP, #0x40
    // 0x63aaf0: CheckStackOverflow
    //     0x63aaf0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63aaf4: cmp             SP, x16
    //     0x63aaf8: b.ls            #0x63ad6c
    // 0x63aafc: ldr             x3, [fp, #0x10]
    // 0x63ab00: LoadField: r4 = r3->field_67
    //     0x63ab00: ldur            w4, [x3, #0x67]
    // 0x63ab04: DecompressPointer r4
    //     0x63ab04: add             x4, x4, HEAP, lsl #32
    // 0x63ab08: stur            x4, [fp, #-0x10]
    // 0x63ab0c: LoadField: r5 = r3->field_5f
    //     0x63ab0c: ldur            x5, [x3, #0x5f]
    // 0x63ab10: stur            x5, [fp, #-8]
    // 0x63ab14: r0 = BoxInt64Instr(r5)
    //     0x63ab14: sbfiz           x0, x5, #1, #0x1f
    //     0x63ab18: cmp             x5, x0, asr #1
    //     0x63ab1c: b.eq            #0x63ab28
    //     0x63ab20: bl              #0xd69bb8
    //     0x63ab24: stur            x5, [x0, #7]
    // 0x63ab28: mov             x2, x0
    // 0x63ab2c: r1 = <PlaceholderDimensions>
    //     0x63ab2c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x63ab30: ldr             x1, [x1, #0x320]
    // 0x63ab34: r0 = AllocateArray()
    //     0x63ab34: bl              #0xd6987c  ; AllocateArrayStub
    // 0x63ab38: mov             x1, x0
    // 0x63ab3c: stur            x1, [fp, #-0x20]
    // 0x63ab40: ldur            x2, [fp, #-8]
    // 0x63ab44: r0 = 0
    //     0x63ab44: mov             x0, #0
    // 0x63ab48: CheckStackOverflow
    //     0x63ab48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63ab4c: cmp             SP, x16
    //     0x63ab50: b.ls            #0x63ad74
    // 0x63ab54: cmp             x0, x2
    // 0x63ab58: b.ge            #0x63ab78
    // 0x63ab5c: add             x3, x1, x0, lsl #2
    // 0x63ab60: r17 = Instance_PlaceholderDimensions
    //     0x63ab60: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x63ab64: ldr             x17, [x17, #0x458]
    // 0x63ab68: StoreField: r3->field_f = r17
    //     0x63ab68: stur            w17, [x3, #0xf]
    // 0x63ab6c: add             x3, x0, #1
    // 0x63ab70: mov             x0, x3
    // 0x63ab74: b               #0x63ab48
    // 0x63ab78: ldur            x5, [fp, #-0x10]
    // 0x63ab7c: r4 = 0
    //     0x63ab7c: mov             x4, #0
    // 0x63ab80: ldr             x3, [fp, #0x10]
    // 0x63ab84: stur            x5, [fp, #-0x10]
    // 0x63ab88: stur            x4, [fp, #-0x18]
    // 0x63ab8c: CheckStackOverflow
    //     0x63ab8c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x63ab90: cmp             SP, x16
    //     0x63ab94: b.ls            #0x63ad7c
    // 0x63ab98: cmp             w5, NULL
    // 0x63ab9c: b.eq            #0x63ad40
    // 0x63aba0: LoadField: r0 = r3->field_5f
    //     0x63aba0: ldur            x0, [x3, #0x5f]
    // 0x63aba4: cmp             x4, x0
    // 0x63aba8: b.ge            #0x63ad40
    // 0x63abac: r0 = LoadClassIdInstr(r5)
    //     0x63abac: ldur            x0, [x5, #-1]
    //     0x63abb0: ubfx            x0, x0, #0xc, #0x14
    // 0x63abb4: SaveReg r5
    //     0x63abb4: str             x5, [SP, #-8]!
    // 0x63abb8: r0 = GDT[cid_x0 + 0xf0dd]()
    //     0x63abb8: mov             x17, #0xf0dd
    //     0x63abbc: add             lr, x0, x17
    //     0x63abc0: ldr             lr, [x21, lr, lsl #3]
    //     0x63abc4: blr             lr
    // 0x63abc8: add             SP, SP, #8
    // 0x63abcc: ldur            x16, [fp, #-0x10]
    // 0x63abd0: r30 = Instance__IntrinsicDimension
    //     0x63abd0: add             lr, PP, #0x49, lsl #12  ; [pp+0x49ac8] Obj!_IntrinsicDimension@b64c31
    //     0x63abd4: ldr             lr, [lr, #0xac8]
    // 0x63abd8: stp             lr, x16, [SP, #-0x10]!
    // 0x63abdc: d0 = inf
    //     0x63abdc: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x63abe0: SaveReg d0
    //     0x63abe0: str             d0, [SP, #-8]!
    // 0x63abe4: SaveReg r0
    //     0x63abe4: str             x0, [SP, #-8]!
    // 0x63abe8: r0 = _computeIntrinsicDimension()
    //     0x63abe8: bl              #0x62cc04  ; [package:flutter/src/rendering/box.dart] RenderBox::_computeIntrinsicDimension
    // 0x63abec: add             SP, SP, #0x20
    // 0x63abf0: stur            d0, [fp, #-0x40]
    // 0x63abf4: r0 = Size()
    //     0x63abf4: bl              #0x50e0e8  ; AllocateSizeStub -> Size (size=0x18)
    // 0x63abf8: mov             x2, x0
    // 0x63abfc: ldur            d0, [fp, #-0x40]
    // 0x63ac00: stur            x2, [fp, #-0x38]
    // 0x63ac04: StoreField: r2->field_7 = d0
    //     0x63ac04: stur            d0, [x2, #7]
    // 0x63ac08: d0 = 0.000000
    //     0x63ac08: eor             v0.16b, v0.16b, v0.16b
    // 0x63ac0c: StoreField: r2->field_f = d0
    //     0x63ac0c: stur            d0, [x2, #0xf]
    // 0x63ac10: ldr             x3, [fp, #0x10]
    // 0x63ac14: LoadField: r4 = r3->field_7b
    //     0x63ac14: ldur            w4, [x3, #0x7b]
    // 0x63ac18: DecompressPointer r4
    //     0x63ac18: add             x4, x4, HEAP, lsl #32
    // 0x63ac1c: r16 = Sentinel
    //     0x63ac1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x63ac20: cmp             w4, w16
    // 0x63ac24: b.eq            #0x63ad84
    // 0x63ac28: LoadField: r0 = r4->field_b
    //     0x63ac28: ldur            w0, [x4, #0xb]
    // 0x63ac2c: DecompressPointer r0
    //     0x63ac2c: add             x0, x0, HEAP, lsl #32
    // 0x63ac30: r1 = LoadInt32Instr(r0)
    //     0x63ac30: sbfx            x1, x0, #1, #0x1f
    // 0x63ac34: mov             x0, x1
    // 0x63ac38: ldur            x1, [fp, #-0x18]
    // 0x63ac3c: cmp             x1, x0
    // 0x63ac40: b.hs            #0x63ad90
    // 0x63ac44: LoadField: r0 = r4->field_f
    //     0x63ac44: ldur            w0, [x4, #0xf]
    // 0x63ac48: DecompressPointer r0
    //     0x63ac48: add             x0, x0, HEAP, lsl #32
    // 0x63ac4c: ldur            x1, [fp, #-0x18]
    // 0x63ac50: ArrayLoad: r4 = r0[r1]  ; Unknown_4
    //     0x63ac50: add             x16, x0, x1, lsl #2
    //     0x63ac54: ldur            w4, [x16, #0xf]
    // 0x63ac58: DecompressPointer r4
    //     0x63ac58: add             x4, x4, HEAP, lsl #32
    // 0x63ac5c: LoadField: r0 = r4->field_b
    //     0x63ac5c: ldur            w0, [x4, #0xb]
    // 0x63ac60: DecompressPointer r0
    //     0x63ac60: add             x0, x0, HEAP, lsl #32
    // 0x63ac64: stur            x0, [fp, #-0x30]
    // 0x63ac68: LoadField: r5 = r4->field_f
    //     0x63ac68: ldur            w5, [x4, #0xf]
    // 0x63ac6c: DecompressPointer r5
    //     0x63ac6c: add             x5, x5, HEAP, lsl #32
    // 0x63ac70: stur            x5, [fp, #-0x28]
    // 0x63ac74: r0 = PlaceholderDimensions()
    //     0x63ac74: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x63ac78: mov             x2, x0
    // 0x63ac7c: ldur            x0, [fp, #-0x38]
    // 0x63ac80: StoreField: r2->field_7 = r0
    //     0x63ac80: stur            w0, [x2, #7]
    // 0x63ac84: ldur            x0, [fp, #-0x30]
    // 0x63ac88: StoreField: r2->field_b = r0
    //     0x63ac88: stur            w0, [x2, #0xb]
    // 0x63ac8c: ldur            x0, [fp, #-0x28]
    // 0x63ac90: StoreField: r2->field_13 = r0
    //     0x63ac90: stur            w0, [x2, #0x13]
    // 0x63ac94: ldur            x0, [fp, #-8]
    // 0x63ac98: ldur            x1, [fp, #-0x18]
    // 0x63ac9c: cmp             x1, x0
    // 0x63aca0: b.hs            #0x63ad94
    // 0x63aca4: ldur            x1, [fp, #-0x20]
    // 0x63aca8: mov             x0, x2
    // 0x63acac: ldur            x3, [fp, #-0x18]
    // 0x63acb0: ArrayStore: r1[r3] = r0  ; List_4
    //     0x63acb0: add             x25, x1, x3, lsl #2
    //     0x63acb4: add             x25, x25, #0xf
    //     0x63acb8: str             w0, [x25]
    //     0x63acbc: tbz             w0, #0, #0x63acd8
    //     0x63acc0: ldurb           w16, [x1, #-1]
    //     0x63acc4: ldurb           w17, [x0, #-1]
    //     0x63acc8: and             x16, x17, x16, lsr #2
    //     0x63accc: tst             x16, HEAP, lsr #32
    //     0x63acd0: b.eq            #0x63acd8
    //     0x63acd4: bl              #0xd67e5c
    // 0x63acd8: ldur            x0, [fp, #-0x10]
    // 0x63acdc: LoadField: r4 = r0->field_17
    //     0x63acdc: ldur            w4, [x0, #0x17]
    // 0x63ace0: DecompressPointer r4
    //     0x63ace0: add             x4, x4, HEAP, lsl #32
    // 0x63ace4: stur            x4, [fp, #-0x28]
    // 0x63ace8: cmp             w4, NULL
    // 0x63acec: b.eq            #0x63ad98
    // 0x63acf0: mov             x0, x4
    // 0x63acf4: r2 = Null
    //     0x63acf4: mov             x2, NULL
    // 0x63acf8: r1 = Null
    //     0x63acf8: mov             x1, NULL
    // 0x63acfc: r4 = LoadClassIdInstr(r0)
    //     0x63acfc: ldur            x4, [x0, #-1]
    //     0x63ad00: ubfx            x4, x4, #0xc, #0x14
    // 0x63ad04: cmp             x4, #0x808
    // 0x63ad08: b.eq            #0x63ad20
    // 0x63ad0c: r8 = TextParentData<RenderBox>
    //     0x63ad0c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x63ad10: ldr             x8, [x8, #0x298]
    // 0x63ad14: r3 = Null
    //     0x63ad14: add             x3, PP, #0x56, lsl #12  ; [pp+0x566c0] Null
    //     0x63ad18: ldr             x3, [x3, #0x6c0]
    // 0x63ad1c: r0 = DefaultTypeTest()
    //     0x63ad1c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x63ad20: ldur            x0, [fp, #-0x28]
    // 0x63ad24: LoadField: r5 = r0->field_13
    //     0x63ad24: ldur            w5, [x0, #0x13]
    // 0x63ad28: DecompressPointer r5
    //     0x63ad28: add             x5, x5, HEAP, lsl #32
    // 0x63ad2c: ldur            x0, [fp, #-0x18]
    // 0x63ad30: add             x4, x0, #1
    // 0x63ad34: ldur            x2, [fp, #-8]
    // 0x63ad38: ldur            x1, [fp, #-0x20]
    // 0x63ad3c: b               #0x63ab80
    // 0x63ad40: ldr             x0, [fp, #0x10]
    // 0x63ad44: LoadField: r1 = r0->field_eb
    //     0x63ad44: ldur            w1, [x0, #0xeb]
    // 0x63ad48: DecompressPointer r1
    //     0x63ad48: add             x1, x1, HEAP, lsl #32
    // 0x63ad4c: ldur            x16, [fp, #-0x20]
    // 0x63ad50: stp             x16, x1, [SP, #-0x10]!
    // 0x63ad54: r0 = setPlaceholderDimensions()
    //     0x63ad54: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x63ad58: add             SP, SP, #0x10
    // 0x63ad5c: r0 = Null
    //     0x63ad5c: mov             x0, NULL
    // 0x63ad60: LeaveFrame
    //     0x63ad60: mov             SP, fp
    //     0x63ad64: ldp             fp, lr, [SP], #0x10
    // 0x63ad68: ret
    //     0x63ad68: ret             
    // 0x63ad6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63ad6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63ad70: b               #0x63aafc
    // 0x63ad74: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63ad74: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63ad78: b               #0x63ab54
    // 0x63ad7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x63ad7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x63ad80: b               #0x63ab98
    // 0x63ad84: r9 = _placeholderSpans
    //     0x63ad84: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x63ad88: ldr             x9, [x9, #0x368]
    // 0x63ad8c: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x63ad8c: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x63ad90: r0 = RangeErrorSharedWithFPURegs()
    //     0x63ad90: bl              #0xd69f10  ; RangeErrorSharedWithFPURegsStub
    // 0x63ad94: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x63ad94: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x63ad98: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x63ad98: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ paintWidgets(/* No info */) {
    // ** addr: 0x65ce48, size: 0x2c0
    // 0x65ce48: EnterFrame
    //     0x65ce48: stp             fp, lr, [SP, #-0x10]!
    //     0x65ce4c: mov             fp, SP
    // 0x65ce50: AllocStack(0x58)
    //     0x65ce50: sub             SP, SP, #0x58
    // 0x65ce54: CheckStackOverflow
    //     0x65ce54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65ce58: cmp             SP, x16
    //     0x65ce5c: b.ls            #0x65d0e0
    // 0x65ce60: ldr             x0, [fp, #0x20]
    // 0x65ce64: LoadField: r1 = r0->field_67
    //     0x65ce64: ldur            w1, [x0, #0x67]
    // 0x65ce68: DecompressPointer r1
    //     0x65ce68: add             x1, x1, HEAP, lsl #32
    // 0x65ce6c: stur            x1, [fp, #-8]
    // 0x65ce70: r1 = 1
    //     0x65ce70: mov             x1, #1
    // 0x65ce74: r0 = AllocateContext()
    //     0x65ce74: bl              #0xd68aa4  ; AllocateContextStub
    // 0x65ce78: mov             x3, x0
    // 0x65ce7c: ldur            x0, [fp, #-8]
    // 0x65ce80: stur            x3, [fp, #-0x28]
    // 0x65ce84: StoreField: r3->field_f = r0
    //     0x65ce84: stur            w0, [x3, #0xf]
    // 0x65ce88: ldr             x4, [fp, #0x20]
    // 0x65ce8c: LoadField: r5 = r4->field_eb
    //     0x65ce8c: ldur            w5, [x4, #0xeb]
    // 0x65ce90: DecompressPointer r5
    //     0x65ce90: add             x5, x5, HEAP, lsl #32
    // 0x65ce94: ldr             x1, [fp, #0x10]
    // 0x65ce98: stur            x5, [fp, #-0x20]
    // 0x65ce9c: LoadField: d0 = r1->field_7
    //     0x65ce9c: ldur            d0, [x1, #7]
    // 0x65cea0: stur            d0, [fp, #-0x48]
    // 0x65cea4: LoadField: d1 = r1->field_f
    //     0x65cea4: ldur            d1, [x1, #0xf]
    // 0x65cea8: stur            d1, [fp, #-0x40]
    // 0x65ceac: mov             x6, x0
    // 0x65ceb0: r7 = 0
    //     0x65ceb0: mov             x7, #0
    // 0x65ceb4: stur            x7, [fp, #-0x10]
    // 0x65ceb8: stur            x6, [fp, #-0x18]
    // 0x65cebc: CheckStackOverflow
    //     0x65cebc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x65cec0: cmp             SP, x16
    //     0x65cec4: b.ls            #0x65d0e8
    // 0x65cec8: cmp             w6, NULL
    // 0x65cecc: b.eq            #0x65d0d0
    // 0x65ced0: LoadField: r0 = r5->field_3f
    //     0x65ced0: ldur            w0, [x5, #0x3f]
    // 0x65ced4: DecompressPointer r0
    //     0x65ced4: add             x0, x0, HEAP, lsl #32
    // 0x65ced8: cmp             w0, NULL
    // 0x65cedc: b.eq            #0x65d0f0
    // 0x65cee0: LoadField: r1 = r0->field_b
    //     0x65cee0: ldur            w1, [x0, #0xb]
    // 0x65cee4: DecompressPointer r1
    //     0x65cee4: add             x1, x1, HEAP, lsl #32
    // 0x65cee8: r0 = LoadInt32Instr(r1)
    //     0x65cee8: sbfx            x0, x1, #1, #0x1f
    // 0x65ceec: cmp             x7, x0
    // 0x65cef0: b.ge            #0x65d0d0
    // 0x65cef4: LoadField: r8 = r6->field_17
    //     0x65cef4: ldur            w8, [x6, #0x17]
    // 0x65cef8: DecompressPointer r8
    //     0x65cef8: add             x8, x8, HEAP, lsl #32
    // 0x65cefc: mov             x0, x8
    // 0x65cf00: stur            x8, [fp, #-8]
    // 0x65cf04: r2 = Null
    //     0x65cf04: mov             x2, NULL
    // 0x65cf08: r1 = Null
    //     0x65cf08: mov             x1, NULL
    // 0x65cf0c: r4 = LoadClassIdInstr(r0)
    //     0x65cf0c: ldur            x4, [x0, #-1]
    //     0x65cf10: ubfx            x4, x4, #0xc, #0x14
    // 0x65cf14: cmp             x4, #0x808
    // 0x65cf18: b.eq            #0x65cf30
    // 0x65cf1c: r8 = TextParentData<RenderBox>
    //     0x65cf1c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x65cf20: ldr             x8, [x8, #0x298]
    // 0x65cf24: r3 = Null
    //     0x65cf24: add             x3, PP, #0x56, lsl #12  ; [pp+0x56788] Null
    //     0x65cf28: ldr             x3, [x3, #0x788]
    // 0x65cf2c: r0 = DefaultTypeTest()
    //     0x65cf2c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65cf30: ldur            x0, [fp, #-8]
    // 0x65cf34: LoadField: r1 = r0->field_17
    //     0x65cf34: ldur            w1, [x0, #0x17]
    // 0x65cf38: DecompressPointer r1
    //     0x65cf38: add             x1, x1, HEAP, lsl #32
    // 0x65cf3c: stur            x1, [fp, #-0x30]
    // 0x65cf40: LoadField: r2 = r0->field_7
    //     0x65cf40: ldur            w2, [x0, #7]
    // 0x65cf44: DecompressPointer r2
    //     0x65cf44: add             x2, x2, HEAP, lsl #32
    // 0x65cf48: LoadField: d0 = r2->field_7
    //     0x65cf48: ldur            d0, [x2, #7]
    // 0x65cf4c: ldur            d1, [fp, #-0x48]
    // 0x65cf50: fadd            d2, d1, d0
    // 0x65cf54: stur            d2, [fp, #-0x58]
    // 0x65cf58: LoadField: d0 = r2->field_f
    //     0x65cf58: ldur            d0, [x2, #0xf]
    // 0x65cf5c: ldur            d3, [fp, #-0x40]
    // 0x65cf60: fadd            d4, d3, d0
    // 0x65cf64: ldur            x0, [fp, #-0x18]
    // 0x65cf68: stur            d4, [fp, #-0x50]
    // 0x65cf6c: LoadField: r2 = r0->field_57
    //     0x65cf6c: ldur            w2, [x0, #0x57]
    // 0x65cf70: DecompressPointer r2
    //     0x65cf70: add             x2, x2, HEAP, lsl #32
    // 0x65cf74: cmp             w2, NULL
    // 0x65cf78: b.eq            #0x65d0f4
    // 0x65cf7c: ldr             x0, [fp, #0x20]
    // 0x65cf80: LoadField: r2 = r0->field_37
    //     0x65cf80: ldur            w2, [x0, #0x37]
    // 0x65cf84: DecompressPointer r2
    //     0x65cf84: add             x2, x2, HEAP, lsl #32
    // 0x65cf88: r16 = Sentinel
    //     0x65cf88: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x65cf8c: cmp             w2, w16
    // 0x65cf90: b.eq            #0x65d0f8
    // 0x65cf94: stur            x2, [fp, #-8]
    // 0x65cf98: r0 = Offset()
    //     0x65cf98: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x65cf9c: ldur            d0, [fp, #-0x58]
    // 0x65cfa0: stur            x0, [fp, #-0x18]
    // 0x65cfa4: StoreField: r0->field_7 = d0
    //     0x65cfa4: stur            d0, [x0, #7]
    // 0x65cfa8: ldur            d0, [fp, #-0x50]
    // 0x65cfac: StoreField: r0->field_f = d0
    //     0x65cfac: stur            d0, [x0, #0xf]
    // 0x65cfb0: ldur            x1, [fp, #-0x30]
    // 0x65cfb4: cmp             w1, NULL
    // 0x65cfb8: b.eq            #0x65d100
    // 0x65cfbc: r0 = Matrix4()
    //     0x65cfbc: bl              #0x50ace8  ; AllocateMatrix4Stub -> Matrix4 (size=0xc)
    // 0x65cfc0: r4 = 32
    //     0x65cfc0: mov             x4, #0x20
    // 0x65cfc4: stur            x0, [fp, #-0x38]
    // 0x65cfc8: r0 = AllocateFloat64Array()
    //     0x65cfc8: bl              #0xd68eb0  ; AllocateFloat64ArrayStub
    // 0x65cfcc: mov             x1, x0
    // 0x65cfd0: ldur            x0, [fp, #-0x38]
    // 0x65cfd4: StoreField: r0->field_7 = r1
    //     0x65cfd4: stur            w1, [x0, #7]
    // 0x65cfd8: d0 = 1.000000
    //     0x65cfd8: fmov            d0, #1.00000000
    // 0x65cfdc: StoreField: r1->field_8f = d0
    //     0x65cfdc: stur            d0, [x1, #0x8f]
    // 0x65cfe0: ldur            x2, [fp, #-0x30]
    // 0x65cfe4: LoadField: d1 = r2->field_7
    //     0x65cfe4: ldur            d1, [x2, #7]
    // 0x65cfe8: StoreField: r1->field_67 = d1
    //     0x65cfe8: stur            d1, [x1, #0x67]
    // 0x65cfec: StoreField: r1->field_3f = d1
    //     0x65cfec: stur            d1, [x1, #0x3f]
    // 0x65cff0: StoreField: r1->field_17 = d1
    //     0x65cff0: stur            d1, [x1, #0x17]
    // 0x65cff4: ldur            x2, [fp, #-0x28]
    // 0x65cff8: r1 = Function '<anonymous closure>':.
    //     0x65cff8: add             x1, PP, #0x56, lsl #12  ; [pp+0x56798] AnonymousClosure: (0x65d7bc), in [package:flutter/src/rendering/paragraph.dart] RenderParagraph::paint (0x65df34)
    //     0x65cffc: ldr             x1, [x1, #0x798]
    // 0x65d000: r0 = AllocateClosure()
    //     0x65d000: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x65d004: ldr             x16, [fp, #0x18]
    // 0x65d008: ldur            lr, [fp, #-8]
    // 0x65d00c: stp             lr, x16, [SP, #-0x10]!
    // 0x65d010: ldur            x16, [fp, #-0x18]
    // 0x65d014: ldur            lr, [fp, #-0x38]
    // 0x65d018: stp             lr, x16, [SP, #-0x10]!
    // 0x65d01c: SaveReg r0
    //     0x65d01c: str             x0, [SP, #-8]!
    // 0x65d020: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0x65d020: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0x65d024: r0 = pushTransform()
    //     0x65d024: bl              #0x65d108  ; [package:flutter/src/rendering/object.dart] PaintingContext::pushTransform
    // 0x65d028: add             SP, SP, #0x28
    // 0x65d02c: ldur            x3, [fp, #-0x28]
    // 0x65d030: LoadField: r0 = r3->field_f
    //     0x65d030: ldur            w0, [x3, #0xf]
    // 0x65d034: DecompressPointer r0
    //     0x65d034: add             x0, x0, HEAP, lsl #32
    // 0x65d038: LoadField: r4 = r0->field_17
    //     0x65d038: ldur            w4, [x0, #0x17]
    // 0x65d03c: DecompressPointer r4
    //     0x65d03c: add             x4, x4, HEAP, lsl #32
    // 0x65d040: stur            x4, [fp, #-8]
    // 0x65d044: cmp             w4, NULL
    // 0x65d048: b.eq            #0x65d104
    // 0x65d04c: mov             x0, x4
    // 0x65d050: r2 = Null
    //     0x65d050: mov             x2, NULL
    // 0x65d054: r1 = Null
    //     0x65d054: mov             x1, NULL
    // 0x65d058: r4 = LoadClassIdInstr(r0)
    //     0x65d058: ldur            x4, [x0, #-1]
    //     0x65d05c: ubfx            x4, x4, #0xc, #0x14
    // 0x65d060: cmp             x4, #0x808
    // 0x65d064: b.eq            #0x65d07c
    // 0x65d068: r8 = TextParentData<RenderBox>
    //     0x65d068: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x65d06c: ldr             x8, [x8, #0x298]
    // 0x65d070: r3 = Null
    //     0x65d070: add             x3, PP, #0x56, lsl #12  ; [pp+0x567a0] Null
    //     0x65d074: ldr             x3, [x3, #0x7a0]
    // 0x65d078: r0 = DefaultTypeTest()
    //     0x65d078: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x65d07c: ldur            x1, [fp, #-8]
    // 0x65d080: LoadField: r2 = r1->field_13
    //     0x65d080: ldur            w2, [x1, #0x13]
    // 0x65d084: DecompressPointer r2
    //     0x65d084: add             x2, x2, HEAP, lsl #32
    // 0x65d088: mov             x0, x2
    // 0x65d08c: ldur            x1, [fp, #-0x28]
    // 0x65d090: StoreField: r1->field_f = r0
    //     0x65d090: stur            w0, [x1, #0xf]
    //     0x65d094: ldurb           w16, [x1, #-1]
    //     0x65d098: ldurb           w17, [x0, #-1]
    //     0x65d09c: and             x16, x17, x16, lsr #2
    //     0x65d0a0: tst             x16, HEAP, lsr #32
    //     0x65d0a4: b.eq            #0x65d0ac
    //     0x65d0a8: bl              #0xd6826c
    // 0x65d0ac: ldur            x3, [fp, #-0x10]
    // 0x65d0b0: add             x7, x3, #1
    // 0x65d0b4: mov             x6, x2
    // 0x65d0b8: ldr             x4, [fp, #0x20]
    // 0x65d0bc: mov             x3, x1
    // 0x65d0c0: ldur            x5, [fp, #-0x20]
    // 0x65d0c4: ldur            d0, [fp, #-0x48]
    // 0x65d0c8: ldur            d1, [fp, #-0x40]
    // 0x65d0cc: b               #0x65ceb4
    // 0x65d0d0: r0 = Null
    //     0x65d0d0: mov             x0, NULL
    // 0x65d0d4: LeaveFrame
    //     0x65d0d4: mov             SP, fp
    //     0x65d0d8: ldp             fp, lr, [SP], #0x10
    // 0x65d0dc: ret
    //     0x65d0dc: ret             
    // 0x65d0e0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x65d0e0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x65d0e4: b               #0x65ce60
    // 0x65d0e8: r0 = StackOverflowSharedWithFPURegs()
    //     0x65d0e8: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x65d0ec: b               #0x65cec8
    // 0x65d0f0: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65d0f0: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65d0f4: r0 = NullCastErrorSharedWithFPURegs()
    //     0x65d0f4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x65d0f8: r9 = _needsCompositing
    //     0x65d0f8: ldr             x9, [PP, #0x4b28]  ; [pp+0x4b28] Field <RenderObject._needsCompositing@904266271>: late (offset: 0x38)
    // 0x65d0fc: r0 = LateInitializationErrorSharedWithFPURegs()
    //     0x65d0fc: bl              #0xd6a2b8  ; LateInitializationErrorSharedWithFPURegsStub
    // 0x65d100: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65d100: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x65d104: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x65d104: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ setParentData(/* No info */) {
    // ** addr: 0x68c1cc, size: 0x1c4
    // 0x68c1cc: EnterFrame
    //     0x68c1cc: stp             fp, lr, [SP, #-0x10]!
    //     0x68c1d0: mov             fp, SP
    // 0x68c1d4: AllocStack(0x38)
    //     0x68c1d4: sub             SP, SP, #0x38
    // 0x68c1d8: ldr             x0, [fp, #0x10]
    // 0x68c1dc: LoadField: r1 = r0->field_67
    //     0x68c1dc: ldur            w1, [x0, #0x67]
    // 0x68c1e0: DecompressPointer r1
    //     0x68c1e0: add             x1, x1, HEAP, lsl #32
    // 0x68c1e4: LoadField: r2 = r0->field_eb
    //     0x68c1e4: ldur            w2, [x0, #0xeb]
    // 0x68c1e8: DecompressPointer r2
    //     0x68c1e8: add             x2, x2, HEAP, lsl #32
    // 0x68c1ec: LoadField: r3 = r2->field_3f
    //     0x68c1ec: ldur            w3, [x2, #0x3f]
    // 0x68c1f0: DecompressPointer r3
    //     0x68c1f0: add             x3, x3, HEAP, lsl #32
    // 0x68c1f4: stur            x3, [fp, #-0x28]
    // 0x68c1f8: LoadField: r4 = r2->field_43
    //     0x68c1f8: ldur            w4, [x2, #0x43]
    // 0x68c1fc: DecompressPointer r4
    //     0x68c1fc: add             x4, x4, HEAP, lsl #32
    // 0x68c200: stur            x4, [fp, #-0x20]
    // 0x68c204: mov             x0, x1
    // 0x68c208: r5 = 0
    //     0x68c208: mov             x5, #0
    // 0x68c20c: stur            x5, [fp, #-0x18]
    // 0x68c210: CheckStackOverflow
    //     0x68c210: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68c214: cmp             SP, x16
    //     0x68c218: b.ls            #0x68c378
    // 0x68c21c: cmp             w0, NULL
    // 0x68c220: b.eq            #0x68c368
    // 0x68c224: cmp             w3, NULL
    // 0x68c228: b.eq            #0x68c380
    // 0x68c22c: LoadField: r6 = r3->field_b
    //     0x68c22c: ldur            w6, [x3, #0xb]
    // 0x68c230: DecompressPointer r6
    //     0x68c230: add             x6, x6, HEAP, lsl #32
    // 0x68c234: stur            x6, [fp, #-0x10]
    // 0x68c238: r1 = LoadInt32Instr(r6)
    //     0x68c238: sbfx            x1, x6, #1, #0x1f
    // 0x68c23c: cmp             x5, x1
    // 0x68c240: b.ge            #0x68c368
    // 0x68c244: LoadField: r7 = r0->field_17
    //     0x68c244: ldur            w7, [x0, #0x17]
    // 0x68c248: DecompressPointer r7
    //     0x68c248: add             x7, x7, HEAP, lsl #32
    // 0x68c24c: mov             x0, x7
    // 0x68c250: stur            x7, [fp, #-8]
    // 0x68c254: r2 = Null
    //     0x68c254: mov             x2, NULL
    // 0x68c258: r1 = Null
    //     0x68c258: mov             x1, NULL
    // 0x68c25c: r4 = LoadClassIdInstr(r0)
    //     0x68c25c: ldur            x4, [x0, #-1]
    //     0x68c260: ubfx            x4, x4, #0xc, #0x14
    // 0x68c264: cmp             x4, #0x808
    // 0x68c268: b.eq            #0x68c280
    // 0x68c26c: r8 = TextParentData<RenderBox>
    //     0x68c26c: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x68c270: ldr             x8, [x8, #0x298]
    // 0x68c274: r3 = Null
    //     0x68c274: add             x3, PP, #0x56, lsl #12  ; [pp+0x56810] Null
    //     0x68c278: ldr             x3, [x3, #0x810]
    // 0x68c27c: r0 = DefaultTypeTest()
    //     0x68c27c: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68c280: ldur            x0, [fp, #-0x10]
    // 0x68c284: r1 = LoadInt32Instr(r0)
    //     0x68c284: sbfx            x1, x0, #1, #0x1f
    // 0x68c288: mov             x0, x1
    // 0x68c28c: ldur            x1, [fp, #-0x18]
    // 0x68c290: cmp             x1, x0
    // 0x68c294: b.hs            #0x68c384
    // 0x68c298: ldur            x0, [fp, #-0x28]
    // 0x68c29c: LoadField: r1 = r0->field_f
    //     0x68c29c: ldur            w1, [x0, #0xf]
    // 0x68c2a0: DecompressPointer r1
    //     0x68c2a0: add             x1, x1, HEAP, lsl #32
    // 0x68c2a4: ldur            x2, [fp, #-0x18]
    // 0x68c2a8: ArrayLoad: r3 = r1[r2]  ; Unknown_4
    //     0x68c2a8: add             x16, x1, x2, lsl #2
    //     0x68c2ac: ldur            w3, [x16, #0xf]
    // 0x68c2b0: DecompressPointer r3
    //     0x68c2b0: add             x3, x3, HEAP, lsl #32
    // 0x68c2b4: LoadField: d0 = r3->field_7
    //     0x68c2b4: ldur            d0, [x3, #7]
    // 0x68c2b8: stur            d0, [fp, #-0x38]
    // 0x68c2bc: LoadField: d1 = r3->field_f
    //     0x68c2bc: ldur            d1, [x3, #0xf]
    // 0x68c2c0: stur            d1, [fp, #-0x30]
    // 0x68c2c4: r0 = Offset()
    //     0x68c2c4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x68c2c8: ldur            d0, [fp, #-0x38]
    // 0x68c2cc: StoreField: r0->field_7 = d0
    //     0x68c2cc: stur            d0, [x0, #7]
    // 0x68c2d0: ldur            d0, [fp, #-0x30]
    // 0x68c2d4: StoreField: r0->field_f = d0
    //     0x68c2d4: stur            d0, [x0, #0xf]
    // 0x68c2d8: ldur            x2, [fp, #-8]
    // 0x68c2dc: StoreField: r2->field_7 = r0
    //     0x68c2dc: stur            w0, [x2, #7]
    //     0x68c2e0: ldurb           w16, [x2, #-1]
    //     0x68c2e4: ldurb           w17, [x0, #-1]
    //     0x68c2e8: and             x16, x17, x16, lsr #2
    //     0x68c2ec: tst             x16, HEAP, lsr #32
    //     0x68c2f0: b.eq            #0x68c2f8
    //     0x68c2f4: bl              #0xd6828c
    // 0x68c2f8: ldur            x3, [fp, #-0x20]
    // 0x68c2fc: cmp             w3, NULL
    // 0x68c300: b.eq            #0x68c388
    // 0x68c304: LoadField: r4 = r3->field_b
    //     0x68c304: ldur            w4, [x3, #0xb]
    // 0x68c308: DecompressPointer r4
    //     0x68c308: add             x4, x4, HEAP, lsl #32
    // 0x68c30c: r0 = LoadInt32Instr(r4)
    //     0x68c30c: sbfx            x0, x4, #1, #0x1f
    // 0x68c310: ldur            x1, [fp, #-0x18]
    // 0x68c314: cmp             x1, x0
    // 0x68c318: b.hs            #0x68c38c
    // 0x68c31c: LoadField: r1 = r3->field_f
    //     0x68c31c: ldur            w1, [x3, #0xf]
    // 0x68c320: DecompressPointer r1
    //     0x68c320: add             x1, x1, HEAP, lsl #32
    // 0x68c324: ldur            x4, [fp, #-0x18]
    // 0x68c328: ArrayLoad: r0 = r1[r4]  ; Unknown_4
    //     0x68c328: add             x16, x1, x4, lsl #2
    //     0x68c32c: ldur            w0, [x16, #0xf]
    // 0x68c330: DecompressPointer r0
    //     0x68c330: add             x0, x0, HEAP, lsl #32
    // 0x68c334: StoreField: r2->field_17 = r0
    //     0x68c334: stur            w0, [x2, #0x17]
    //     0x68c338: ldurb           w16, [x2, #-1]
    //     0x68c33c: ldurb           w17, [x0, #-1]
    //     0x68c340: and             x16, x17, x16, lsr #2
    //     0x68c344: tst             x16, HEAP, lsr #32
    //     0x68c348: b.eq            #0x68c350
    //     0x68c34c: bl              #0xd6828c
    // 0x68c350: LoadField: r0 = r2->field_13
    //     0x68c350: ldur            w0, [x2, #0x13]
    // 0x68c354: DecompressPointer r0
    //     0x68c354: add             x0, x0, HEAP, lsl #32
    // 0x68c358: add             x5, x4, #1
    // 0x68c35c: mov             x4, x3
    // 0x68c360: ldur            x3, [fp, #-0x28]
    // 0x68c364: b               #0x68c20c
    // 0x68c368: r0 = Null
    //     0x68c368: mov             x0, NULL
    // 0x68c36c: LeaveFrame
    //     0x68c36c: mov             SP, fp
    //     0x68c370: ldp             fp, lr, [SP], #0x10
    // 0x68c374: ret
    //     0x68c374: ret             
    // 0x68c378: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68c378: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68c37c: b               #0x68c21c
    // 0x68c380: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c380: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c384: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68c384: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68c388: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c388: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c38c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68c38c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ layoutChildren(/* No info */) {
    // ** addr: 0x68c390, size: 0x61c
    // 0x68c390: EnterFrame
    //     0x68c390: stp             fp, lr, [SP, #-0x10]!
    //     0x68c394: mov             fp, SP
    // 0x68c398: AllocStack(0x60)
    //     0x68c398: sub             SP, SP, #0x60
    // 0x68c39c: SetupParameters(ExtendedTextRenderBox this /* r3, fp-0x28 */, dynamic _ /* r4, fp-0x20 */, {dynamic dry = false /* r5, fp-0x18 */})
    //     0x68c39c: mov             x0, x4
    //     0x68c3a0: ldur            w1, [x0, #0x13]
    //     0x68c3a4: add             x1, x1, HEAP, lsl #32
    //     0x68c3a8: sub             x2, x1, #4
    //     0x68c3ac: add             x3, fp, w2, sxtw #2
    //     0x68c3b0: ldr             x3, [x3, #0x18]
    //     0x68c3b4: stur            x3, [fp, #-0x28]
    //     0x68c3b8: add             x4, fp, w2, sxtw #2
    //     0x68c3bc: ldr             x4, [x4, #0x10]
    //     0x68c3c0: stur            x4, [fp, #-0x20]
    //     0x68c3c4: ldur            w2, [x0, #0x1f]
    //     0x68c3c8: add             x2, x2, HEAP, lsl #32
    //     0x68c3cc: add             x16, PP, #0x22, lsl #12  ; [pp+0x22450] "dry"
    //     0x68c3d0: ldr             x16, [x16, #0x450]
    //     0x68c3d4: cmp             w2, w16
    //     0x68c3d8: b.ne            #0x68c3f8
    //     0x68c3dc: ldur            w2, [x0, #0x23]
    //     0x68c3e0: add             x2, x2, HEAP, lsl #32
    //     0x68c3e4: sub             w0, w1, w2
    //     0x68c3e8: add             x1, fp, w0, sxtw #2
    //     0x68c3ec: ldr             x1, [x1, #8]
    //     0x68c3f0: mov             x5, x1
    //     0x68c3f4: b               #0x68c3fc
    //     0x68c3f8: add             x5, NULL, #0x30  ; false
    //     0x68c3fc: stur            x5, [fp, #-0x18]
    // 0x68c400: CheckStackOverflow
    //     0x68c400: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68c404: cmp             SP, x16
    //     0x68c408: b.ls            #0x68c91c
    // 0x68c40c: LoadField: r6 = r3->field_5f
    //     0x68c40c: ldur            x6, [x3, #0x5f]
    // 0x68c410: stur            x6, [fp, #-0x10]
    // 0x68c414: cbnz            x6, #0x68c428
    // 0x68c418: r0 = Null
    //     0x68c418: mov             x0, NULL
    // 0x68c41c: LeaveFrame
    //     0x68c41c: mov             SP, fp
    //     0x68c420: ldp             fp, lr, [SP], #0x10
    // 0x68c424: ret
    //     0x68c424: ret             
    // 0x68c428: LoadField: r7 = r3->field_67
    //     0x68c428: ldur            w7, [x3, #0x67]
    // 0x68c42c: DecompressPointer r7
    //     0x68c42c: add             x7, x7, HEAP, lsl #32
    // 0x68c430: stur            x7, [fp, #-8]
    // 0x68c434: r0 = BoxInt64Instr(r6)
    //     0x68c434: sbfiz           x0, x6, #1, #0x1f
    //     0x68c438: cmp             x6, x0, asr #1
    //     0x68c43c: b.eq            #0x68c448
    //     0x68c440: bl              #0xd69bb8
    //     0x68c444: stur            x6, [x0, #7]
    // 0x68c448: mov             x2, x0
    // 0x68c44c: r1 = <PlaceholderDimensions>
    //     0x68c44c: add             x1, PP, #0x22, lsl #12  ; [pp+0x22320] TypeArguments: <PlaceholderDimensions>
    //     0x68c450: ldr             x1, [x1, #0x320]
    // 0x68c454: r0 = AllocateArray()
    //     0x68c454: bl              #0xd6987c  ; AllocateArrayStub
    // 0x68c458: ldur            x1, [fp, #-0x10]
    // 0x68c45c: r2 = 0
    //     0x68c45c: mov             x2, #0
    // 0x68c460: CheckStackOverflow
    //     0x68c460: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68c464: cmp             SP, x16
    //     0x68c468: b.ls            #0x68c924
    // 0x68c46c: cmp             x2, x1
    // 0x68c470: b.ge            #0x68c490
    // 0x68c474: add             x3, x0, x2, lsl #2
    // 0x68c478: r17 = Instance_PlaceholderDimensions
    //     0x68c478: add             x17, PP, #0x22, lsl #12  ; [pp+0x22458] Obj!PlaceholderDimensions@b356b1
    //     0x68c47c: ldr             x17, [x17, #0x458]
    // 0x68c480: StoreField: r3->field_f = r17
    //     0x68c480: stur            w17, [x3, #0xf]
    // 0x68c484: add             x3, x2, #1
    // 0x68c488: mov             x2, x3
    // 0x68c48c: b               #0x68c460
    // 0x68c490: ldur            x1, [fp, #-0x28]
    // 0x68c494: ldur            x2, [fp, #-0x20]
    // 0x68c498: StoreField: r1->field_7f = r0
    //     0x68c498: stur            w0, [x1, #0x7f]
    //     0x68c49c: ldurb           w16, [x1, #-1]
    //     0x68c4a0: ldurb           w17, [x0, #-1]
    //     0x68c4a4: and             x16, x17, x16, lsr #2
    //     0x68c4a8: tst             x16, HEAP, lsr #32
    //     0x68c4ac: b.eq            #0x68c4b4
    //     0x68c4b0: bl              #0xd6826c
    // 0x68c4b4: LoadField: d0 = r2->field_f
    //     0x68c4b4: ldur            d0, [x2, #0xf]
    // 0x68c4b8: stur            d0, [fp, #-0x60]
    // 0x68c4bc: r0 = BoxConstraints()
    //     0x68c4bc: bl              #0x5242ac  ; AllocateBoxConstraintsStub -> BoxConstraints (size=0x28)
    // 0x68c4c0: d0 = 0.000000
    //     0x68c4c0: eor             v0.16b, v0.16b, v0.16b
    // 0x68c4c4: StoreField: r0->field_7 = d0
    //     0x68c4c4: stur            d0, [x0, #7]
    // 0x68c4c8: ldur            d1, [fp, #-0x60]
    // 0x68c4cc: StoreField: r0->field_f = d1
    //     0x68c4cc: stur            d1, [x0, #0xf]
    // 0x68c4d0: StoreField: r0->field_17 = d0
    //     0x68c4d0: stur            d0, [x0, #0x17]
    // 0x68c4d4: d0 = inf
    //     0x68c4d4: ldr             d0, [PP, #0x2200]  ; [pp+0x2200] IMM: double(inf) from 0x7ff0000000000000
    // 0x68c4d8: StoreField: r0->field_1f = d0
    //     0x68c4d8: stur            d0, [x0, #0x1f]
    // 0x68c4dc: ldur            x1, [fp, #-0x28]
    // 0x68c4e0: LoadField: r2 = r1->field_eb
    //     0x68c4e0: ldur            w2, [x1, #0xeb]
    // 0x68c4e4: DecompressPointer r2
    //     0x68c4e4: add             x2, x2, HEAP, lsl #32
    // 0x68c4e8: stur            x2, [fp, #-0x20]
    // 0x68c4ec: LoadField: d0 = r2->field_1f
    //     0x68c4ec: ldur            d0, [x2, #0x1f]
    // 0x68c4f0: r3 = inline_Allocate_Double()
    //     0x68c4f0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0x68c4f4: add             x3, x3, #0x10
    //     0x68c4f8: cmp             x4, x3
    //     0x68c4fc: b.ls            #0x68c92c
    //     0x68c500: str             x3, [THR, #0x60]  ; THR::top
    //     0x68c504: sub             x3, x3, #0xf
    //     0x68c508: mov             x4, #0xd108
    //     0x68c50c: movk            x4, #3, lsl #16
    //     0x68c510: stur            x4, [x3, #-1]
    // 0x68c514: StoreField: r3->field_7 = d0
    //     0x68c514: stur            d0, [x3, #7]
    // 0x68c518: stp             x3, x0, [SP, #-0x10]!
    // 0x68c51c: r0 = /()
    //     0x68c51c: bl              #0x524234  ; [package:flutter/src/rendering/box.dart] BoxConstraints::/
    // 0x68c520: add             SP, SP, #0x10
    // 0x68c524: mov             x1, x0
    // 0x68c528: stur            x1, [fp, #-0x30]
    // 0x68c52c: ldur            x5, [fp, #-8]
    // 0x68c530: r4 = 0
    //     0x68c530: mov             x4, #0
    // 0x68c534: ldur            x2, [fp, #-0x28]
    // 0x68c538: ldur            x3, [fp, #-0x18]
    // 0x68c53c: stur            x5, [fp, #-8]
    // 0x68c540: stur            x4, [fp, #-0x10]
    // 0x68c544: CheckStackOverflow
    //     0x68c544: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x68c548: cmp             SP, x16
    //     0x68c54c: b.ls            #0x68c950
    // 0x68c550: cmp             w5, NULL
    // 0x68c554: b.eq            #0x68c8f0
    // 0x68c558: LoadField: r0 = r2->field_5f
    //     0x68c558: ldur            x0, [x2, #0x5f]
    // 0x68c55c: cmp             x4, x0
    // 0x68c560: b.ge            #0x68c8f0
    // 0x68c564: tbz             w3, #4, #0x68c6bc
    // 0x68c568: r0 = LoadClassIdInstr(r5)
    //     0x68c568: ldur            x0, [x5, #-1]
    //     0x68c56c: ubfx            x0, x0, #0xc, #0x14
    // 0x68c570: stp             x1, x5, [SP, #-0x10]!
    // 0x68c574: r16 = true
    //     0x68c574: add             x16, NULL, #0x20  ; true
    // 0x68c578: SaveReg r16
    //     0x68c578: str             x16, [SP, #-8]!
    // 0x68c57c: r4 = const [0, 0x3, 0x3, 0x2, parentUsesSize, 0x2, null]
    //     0x68c57c: add             x4, PP, #0xb, lsl #12  ; [pp+0xb1c8] List(7) [0, 0x3, 0x3, 0x2, "parentUsesSize", 0x2, Null]
    //     0x68c580: ldr             x4, [x4, #0x1c8]
    // 0x68c584: r0 = GDT[cid_x0 + 0xcdfb]()
    //     0x68c584: mov             x17, #0xcdfb
    //     0x68c588: add             lr, x0, x17
    //     0x68c58c: ldr             lr, [x21, lr, lsl #3]
    //     0x68c590: blr             lr
    // 0x68c594: add             SP, SP, #0x18
    // 0x68c598: ldur            x2, [fp, #-8]
    // 0x68c59c: LoadField: r3 = r2->field_57
    //     0x68c59c: ldur            w3, [x2, #0x57]
    // 0x68c5a0: DecompressPointer r3
    //     0x68c5a0: add             x3, x3, HEAP, lsl #32
    // 0x68c5a4: stur            x3, [fp, #-0x38]
    // 0x68c5a8: cmp             w3, NULL
    // 0x68c5ac: b.eq            #0x68c958
    // 0x68c5b0: ldur            x4, [fp, #-0x28]
    // 0x68c5b4: LoadField: r5 = r4->field_7b
    //     0x68c5b4: ldur            w5, [x4, #0x7b]
    // 0x68c5b8: DecompressPointer r5
    //     0x68c5b8: add             x5, x5, HEAP, lsl #32
    // 0x68c5bc: r16 = Sentinel
    //     0x68c5bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x68c5c0: cmp             w5, w16
    // 0x68c5c4: b.eq            #0x68c95c
    // 0x68c5c8: LoadField: r0 = r5->field_b
    //     0x68c5c8: ldur            w0, [x5, #0xb]
    // 0x68c5cc: DecompressPointer r0
    //     0x68c5cc: add             x0, x0, HEAP, lsl #32
    // 0x68c5d0: r1 = LoadInt32Instr(r0)
    //     0x68c5d0: sbfx            x1, x0, #1, #0x1f
    // 0x68c5d4: mov             x0, x1
    // 0x68c5d8: ldur            x1, [fp, #-0x10]
    // 0x68c5dc: cmp             x1, x0
    // 0x68c5e0: b.hs            #0x68c968
    // 0x68c5e4: LoadField: r0 = r5->field_f
    //     0x68c5e4: ldur            w0, [x5, #0xf]
    // 0x68c5e8: DecompressPointer r0
    //     0x68c5e8: add             x0, x0, HEAP, lsl #32
    // 0x68c5ec: ldur            x1, [fp, #-0x10]
    // 0x68c5f0: ArrayLoad: r5 = r0[r1]  ; Unknown_4
    //     0x68c5f0: add             x16, x0, x1, lsl #2
    //     0x68c5f4: ldur            w5, [x16, #0xf]
    // 0x68c5f8: DecompressPointer r5
    //     0x68c5f8: add             x5, x5, HEAP, lsl #32
    // 0x68c5fc: LoadField: r0 = r5->field_b
    //     0x68c5fc: ldur            w0, [x5, #0xb]
    // 0x68c600: DecompressPointer r0
    //     0x68c600: add             x0, x0, HEAP, lsl #32
    // 0x68c604: LoadField: r6 = r0->field_7
    //     0x68c604: ldur            x6, [x0, #7]
    // 0x68c608: cmp             x6, #2
    // 0x68c60c: b.gt            #0x68c6a4
    // 0x68c610: cmp             x6, #1
    // 0x68c614: b.gt            #0x68c69c
    // 0x68c618: cmp             x6, #0
    // 0x68c61c: b.gt            #0x68c694
    // 0x68c620: LoadField: r0 = r5->field_f
    //     0x68c620: ldur            w0, [x5, #0xf]
    // 0x68c624: DecompressPointer r0
    //     0x68c624: add             x0, x0, HEAP, lsl #32
    // 0x68c628: cmp             w0, NULL
    // 0x68c62c: b.eq            #0x68c96c
    // 0x68c630: stp             x0, x2, [SP, #-0x10]!
    // 0x68c634: r0 = getDistanceToActualBaseline()
    //     0x68c634: bl              #0x63d634  ; [package:flutter/src/rendering/box.dart] RenderBox::getDistanceToActualBaseline
    // 0x68c638: add             SP, SP, #0x10
    // 0x68c63c: cmp             w0, NULL
    // 0x68c640: b.ne            #0x68c660
    // 0x68c644: ldur            x1, [fp, #-8]
    // 0x68c648: LoadField: r0 = r1->field_57
    //     0x68c648: ldur            w0, [x1, #0x57]
    // 0x68c64c: DecompressPointer r0
    //     0x68c64c: add             x0, x0, HEAP, lsl #32
    // 0x68c650: cmp             w0, NULL
    // 0x68c654: b.eq            #0x68c970
    // 0x68c658: LoadField: d0 = r0->field_f
    //     0x68c658: ldur            d0, [x0, #0xf]
    // 0x68c65c: b               #0x68c668
    // 0x68c660: ldur            x1, [fp, #-8]
    // 0x68c664: LoadField: d0 = r0->field_7
    //     0x68c664: ldur            d0, [x0, #7]
    // 0x68c668: r0 = inline_Allocate_Double()
    //     0x68c668: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0x68c66c: add             x0, x0, #0x10
    //     0x68c670: cmp             x2, x0
    //     0x68c674: b.ls            #0x68c974
    //     0x68c678: str             x0, [THR, #0x60]  ; THR::top
    //     0x68c67c: sub             x0, x0, #0xf
    //     0x68c680: mov             x2, #0xd108
    //     0x68c684: movk            x2, #3, lsl #16
    //     0x68c688: stur            x2, [x0, #-1]
    // 0x68c68c: StoreField: r0->field_7 = d0
    //     0x68c68c: stur            d0, [x0, #7]
    // 0x68c690: b               #0x68c6ac
    // 0x68c694: mov             x1, x2
    // 0x68c698: b               #0x68c6a8
    // 0x68c69c: mov             x1, x2
    // 0x68c6a0: b               #0x68c6a8
    // 0x68c6a4: mov             x1, x2
    // 0x68c6a8: r0 = Null
    //     0x68c6a8: mov             x0, NULL
    // 0x68c6ac: mov             x6, x0
    // 0x68c6b0: ldur            x5, [fp, #-0x38]
    // 0x68c6b4: mov             x2, x1
    // 0x68c6b8: b               #0x68c790
    // 0x68c6bc: mov             x0, x1
    // 0x68c6c0: mov             x1, x5
    // 0x68c6c4: r1 = 2
    //     0x68c6c4: mov             x1, #2
    // 0x68c6c8: r0 = AllocateContext()
    //     0x68c6c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x68c6cc: mov             x1, x0
    // 0x68c6d0: ldur            x0, [fp, #-8]
    // 0x68c6d4: stur            x1, [fp, #-0x38]
    // 0x68c6d8: StoreField: r1->field_f = r0
    //     0x68c6d8: stur            w0, [x1, #0xf]
    // 0x68c6dc: ldur            x2, [fp, #-0x30]
    // 0x68c6e0: StoreField: r1->field_13 = r2
    //     0x68c6e0: stur            w2, [x1, #0x13]
    // 0x68c6e4: LoadField: r3 = r0->field_53
    //     0x68c6e4: ldur            w3, [x0, #0x53]
    // 0x68c6e8: DecompressPointer r3
    //     0x68c6e8: add             x3, x3, HEAP, lsl #32
    // 0x68c6ec: cmp             w3, NULL
    // 0x68c6f0: b.ne            #0x68c73c
    // 0x68c6f4: r16 = <BoxConstraints, Size>
    //     0x68c6f4: add             x16, PP, #0x15, lsl #12  ; [pp+0x15208] TypeArguments: <BoxConstraints, Size>
    //     0x68c6f8: ldr             x16, [x16, #0x208]
    // 0x68c6fc: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x68c700: stp             lr, x16, [SP, #-0x10]!
    // 0x68c704: r0 = Map._fromLiteral()
    //     0x68c704: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x68c708: add             SP, SP, #0x10
    // 0x68c70c: mov             x1, x0
    // 0x68c710: ldur            x4, [fp, #-8]
    // 0x68c714: StoreField: r4->field_53 = r0
    //     0x68c714: stur            w0, [x4, #0x53]
    //     0x68c718: tbz             w0, #0, #0x68c734
    //     0x68c71c: ldurb           w16, [x4, #-1]
    //     0x68c720: ldurb           w17, [x0, #-1]
    //     0x68c724: and             x16, x17, x16, lsr #2
    //     0x68c728: tst             x16, HEAP, lsr #32
    //     0x68c72c: b.eq            #0x68c734
    //     0x68c730: bl              #0xd682cc
    // 0x68c734: mov             x0, x1
    // 0x68c738: b               #0x68c744
    // 0x68c73c: mov             x4, x0
    // 0x68c740: mov             x0, x3
    // 0x68c744: ldur            x2, [fp, #-0x38]
    // 0x68c748: stur            x0, [fp, #-0x48]
    // 0x68c74c: cmp             w0, NULL
    // 0x68c750: b.eq            #0x68c98c
    // 0x68c754: LoadField: r3 = r2->field_13
    //     0x68c754: ldur            w3, [x2, #0x13]
    // 0x68c758: DecompressPointer r3
    //     0x68c758: add             x3, x3, HEAP, lsl #32
    // 0x68c75c: stur            x3, [fp, #-0x40]
    // 0x68c760: r1 = Function '<anonymous closure>':.
    //     0x68c760: add             x1, PP, #0x15, lsl #12  ; [pp+0x15210] AnonymousClosure: (0x62d778), in [package:flutter/src/rendering/box.dart] RenderBox::getDryLayout (0x62d394)
    //     0x68c764: ldr             x1, [x1, #0x210]
    // 0x68c768: r0 = AllocateClosure()
    //     0x68c768: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x68c76c: ldur            x16, [fp, #-0x48]
    // 0x68c770: ldur            lr, [fp, #-0x40]
    // 0x68c774: stp             lr, x16, [SP, #-0x10]!
    // 0x68c778: SaveReg r0
    //     0x68c778: str             x0, [SP, #-8]!
    // 0x68c77c: r0 = putIfAbsent()
    //     0x68c77c: bl              #0xc7a83c  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::putIfAbsent
    // 0x68c780: add             SP, SP, #0x18
    // 0x68c784: mov             x5, x0
    // 0x68c788: ldur            x2, [fp, #-8]
    // 0x68c78c: r6 = Null
    //     0x68c78c: mov             x6, NULL
    // 0x68c790: ldur            x3, [fp, #-0x28]
    // 0x68c794: ldur            x4, [fp, #-0x10]
    // 0x68c798: stur            x6, [fp, #-0x50]
    // 0x68c79c: stur            x5, [fp, #-0x58]
    // 0x68c7a0: LoadField: r7 = r3->field_7f
    //     0x68c7a0: ldur            w7, [x3, #0x7f]
    // 0x68c7a4: DecompressPointer r7
    //     0x68c7a4: add             x7, x7, HEAP, lsl #32
    // 0x68c7a8: stur            x7, [fp, #-0x48]
    // 0x68c7ac: cmp             w7, NULL
    // 0x68c7b0: b.eq            #0x68c990
    // 0x68c7b4: LoadField: r8 = r3->field_7b
    //     0x68c7b4: ldur            w8, [x3, #0x7b]
    // 0x68c7b8: DecompressPointer r8
    //     0x68c7b8: add             x8, x8, HEAP, lsl #32
    // 0x68c7bc: r16 = Sentinel
    //     0x68c7bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x68c7c0: cmp             w8, w16
    // 0x68c7c4: b.eq            #0x68c994
    // 0x68c7c8: LoadField: r0 = r8->field_b
    //     0x68c7c8: ldur            w0, [x8, #0xb]
    // 0x68c7cc: DecompressPointer r0
    //     0x68c7cc: add             x0, x0, HEAP, lsl #32
    // 0x68c7d0: r1 = LoadInt32Instr(r0)
    //     0x68c7d0: sbfx            x1, x0, #1, #0x1f
    // 0x68c7d4: mov             x0, x1
    // 0x68c7d8: mov             x1, x4
    // 0x68c7dc: cmp             x1, x0
    // 0x68c7e0: b.hs            #0x68c9a0
    // 0x68c7e4: LoadField: r0 = r8->field_f
    //     0x68c7e4: ldur            w0, [x8, #0xf]
    // 0x68c7e8: DecompressPointer r0
    //     0x68c7e8: add             x0, x0, HEAP, lsl #32
    // 0x68c7ec: ArrayLoad: r1 = r0[r4]  ; Unknown_4
    //     0x68c7ec: add             x16, x0, x4, lsl #2
    //     0x68c7f0: ldur            w1, [x16, #0xf]
    // 0x68c7f4: DecompressPointer r1
    //     0x68c7f4: add             x1, x1, HEAP, lsl #32
    // 0x68c7f8: LoadField: r0 = r1->field_b
    //     0x68c7f8: ldur            w0, [x1, #0xb]
    // 0x68c7fc: DecompressPointer r0
    //     0x68c7fc: add             x0, x0, HEAP, lsl #32
    // 0x68c800: stur            x0, [fp, #-0x40]
    // 0x68c804: LoadField: r8 = r1->field_f
    //     0x68c804: ldur            w8, [x1, #0xf]
    // 0x68c808: DecompressPointer r8
    //     0x68c808: add             x8, x8, HEAP, lsl #32
    // 0x68c80c: stur            x8, [fp, #-0x38]
    // 0x68c810: r0 = PlaceholderDimensions()
    //     0x68c810: bl              #0x62d738  ; AllocatePlaceholderDimensionsStub -> PlaceholderDimensions (size=0x18)
    // 0x68c814: mov             x2, x0
    // 0x68c818: ldur            x0, [fp, #-0x58]
    // 0x68c81c: StoreField: r2->field_7 = r0
    //     0x68c81c: stur            w0, [x2, #7]
    // 0x68c820: ldur            x0, [fp, #-0x40]
    // 0x68c824: StoreField: r2->field_b = r0
    //     0x68c824: stur            w0, [x2, #0xb]
    // 0x68c828: ldur            x0, [fp, #-0x38]
    // 0x68c82c: StoreField: r2->field_13 = r0
    //     0x68c82c: stur            w0, [x2, #0x13]
    // 0x68c830: ldur            x0, [fp, #-0x50]
    // 0x68c834: StoreField: r2->field_f = r0
    //     0x68c834: stur            w0, [x2, #0xf]
    // 0x68c838: ldur            x3, [fp, #-0x48]
    // 0x68c83c: LoadField: r0 = r3->field_b
    //     0x68c83c: ldur            w0, [x3, #0xb]
    // 0x68c840: DecompressPointer r0
    //     0x68c840: add             x0, x0, HEAP, lsl #32
    // 0x68c844: r1 = LoadInt32Instr(r0)
    //     0x68c844: sbfx            x1, x0, #1, #0x1f
    // 0x68c848: mov             x0, x1
    // 0x68c84c: ldur            x1, [fp, #-0x10]
    // 0x68c850: cmp             x1, x0
    // 0x68c854: b.hs            #0x68c9a4
    // 0x68c858: mov             x1, x3
    // 0x68c85c: mov             x0, x2
    // 0x68c860: ldur            x3, [fp, #-0x10]
    // 0x68c864: ArrayStore: r1[r3] = r0  ; List_4
    //     0x68c864: add             x25, x1, x3, lsl #2
    //     0x68c868: add             x25, x25, #0xf
    //     0x68c86c: str             w0, [x25]
    //     0x68c870: tbz             w0, #0, #0x68c88c
    //     0x68c874: ldurb           w16, [x1, #-1]
    //     0x68c878: ldurb           w17, [x0, #-1]
    //     0x68c87c: and             x16, x17, x16, lsr #2
    //     0x68c880: tst             x16, HEAP, lsr #32
    //     0x68c884: b.eq            #0x68c88c
    //     0x68c888: bl              #0xd67e5c
    // 0x68c88c: ldur            x0, [fp, #-8]
    // 0x68c890: LoadField: r4 = r0->field_17
    //     0x68c890: ldur            w4, [x0, #0x17]
    // 0x68c894: DecompressPointer r4
    //     0x68c894: add             x4, x4, HEAP, lsl #32
    // 0x68c898: stur            x4, [fp, #-0x38]
    // 0x68c89c: cmp             w4, NULL
    // 0x68c8a0: b.eq            #0x68c9a8
    // 0x68c8a4: mov             x0, x4
    // 0x68c8a8: r2 = Null
    //     0x68c8a8: mov             x2, NULL
    // 0x68c8ac: r1 = Null
    //     0x68c8ac: mov             x1, NULL
    // 0x68c8b0: r4 = LoadClassIdInstr(r0)
    //     0x68c8b0: ldur            x4, [x0, #-1]
    //     0x68c8b4: ubfx            x4, x4, #0xc, #0x14
    // 0x68c8b8: cmp             x4, #0x808
    // 0x68c8bc: b.eq            #0x68c8d4
    // 0x68c8c0: r8 = TextParentData<RenderBox>
    //     0x68c8c0: add             x8, PP, #0x22, lsl #12  ; [pp+0x22298] Type: TextParentData<RenderBox>
    //     0x68c8c4: ldr             x8, [x8, #0x298]
    // 0x68c8c8: r3 = Null
    //     0x68c8c8: add             x3, PP, #0x56, lsl #12  ; [pp+0x56820] Null
    //     0x68c8cc: ldr             x3, [x3, #0x820]
    // 0x68c8d0: r0 = DefaultTypeTest()
    //     0x68c8d0: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x68c8d4: ldur            x0, [fp, #-0x38]
    // 0x68c8d8: LoadField: r5 = r0->field_13
    //     0x68c8d8: ldur            w5, [x0, #0x13]
    // 0x68c8dc: DecompressPointer r5
    //     0x68c8dc: add             x5, x5, HEAP, lsl #32
    // 0x68c8e0: ldur            x0, [fp, #-0x10]
    // 0x68c8e4: add             x4, x0, #1
    // 0x68c8e8: ldur            x1, [fp, #-0x30]
    // 0x68c8ec: b               #0x68c534
    // 0x68c8f0: ldur            x0, [fp, #-0x28]
    // 0x68c8f4: LoadField: r1 = r0->field_7f
    //     0x68c8f4: ldur            w1, [x0, #0x7f]
    // 0x68c8f8: DecompressPointer r1
    //     0x68c8f8: add             x1, x1, HEAP, lsl #32
    // 0x68c8fc: ldur            x16, [fp, #-0x20]
    // 0x68c900: stp             x1, x16, [SP, #-0x10]!
    // 0x68c904: r0 = setPlaceholderDimensions()
    //     0x68c904: bl              #0x62d480  ; [package:flutter/src/painting/text_painter.dart] TextPainter::setPlaceholderDimensions
    // 0x68c908: add             SP, SP, #0x10
    // 0x68c90c: r0 = Null
    //     0x68c90c: mov             x0, NULL
    // 0x68c910: LeaveFrame
    //     0x68c910: mov             SP, fp
    //     0x68c914: ldp             fp, lr, [SP], #0x10
    // 0x68c918: ret
    //     0x68c918: ret             
    // 0x68c91c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68c91c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68c920: b               #0x68c40c
    // 0x68c924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68c924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68c928: b               #0x68c46c
    // 0x68c92c: SaveReg d0
    //     0x68c92c: str             q0, [SP, #-0x10]!
    // 0x68c930: stp             x1, x2, [SP, #-0x10]!
    // 0x68c934: SaveReg r0
    //     0x68c934: str             x0, [SP, #-8]!
    // 0x68c938: r0 = AllocateDouble()
    //     0x68c938: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68c93c: mov             x3, x0
    // 0x68c940: RestoreReg r0
    //     0x68c940: ldr             x0, [SP], #8
    // 0x68c944: ldp             x1, x2, [SP], #0x10
    // 0x68c948: RestoreReg d0
    //     0x68c948: ldr             q0, [SP], #0x10
    // 0x68c94c: b               #0x68c514
    // 0x68c950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x68c950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x68c954: b               #0x68c550
    // 0x68c958: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c958: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c95c: r9 = _placeholderSpans
    //     0x68c95c: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x68c960: ldr             x9, [x9, #0x368]
    // 0x68c964: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x68c964: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x68c968: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68c968: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68c96c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c96c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c970: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c970: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c974: SaveReg d0
    //     0x68c974: str             q0, [SP, #-0x10]!
    // 0x68c978: SaveReg r1
    //     0x68c978: str             x1, [SP, #-8]!
    // 0x68c97c: r0 = AllocateDouble()
    //     0x68c97c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x68c980: RestoreReg r1
    //     0x68c980: ldr             x1, [SP], #8
    // 0x68c984: RestoreReg d0
    //     0x68c984: ldr             q0, [SP], #0x10
    // 0x68c988: b               #0x68c68c
    // 0x68c98c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c98c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c990: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c990: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x68c994: r9 = _placeholderSpans
    //     0x68c994: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x68c998: ldr             x9, [x9, #0x368]
    // 0x68c99c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x68c99c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x68c9a0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68c9a0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68c9a4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x68c9a4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x68c9a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x68c9a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ markNeedsTextLayout(/* No info */) {
    // ** addr: 0x6dee5c, size: 0x44
    // 0x6dee5c: EnterFrame
    //     0x6dee5c: stp             fp, lr, [SP, #-0x10]!
    //     0x6dee60: mov             fp, SP
    // 0x6dee64: CheckStackOverflow
    //     0x6dee64: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dee68: cmp             SP, x16
    //     0x6dee6c: b.ls            #0x6dee98
    // 0x6dee70: ldr             x0, [fp, #0x10]
    // 0x6dee74: StoreField: r0->field_6f = rNULL
    //     0x6dee74: stur            NULL, [x0, #0x6f]
    // 0x6dee78: StoreField: r0->field_73 = rNULL
    //     0x6dee78: stur            NULL, [x0, #0x73]
    // 0x6dee7c: SaveReg r0
    //     0x6dee7c: str             x0, [SP, #-8]!
    // 0x6dee80: r0 = markNeedsLayout()
    //     0x6dee80: bl              #0x6c0e34  ; [package:flutter/src/rendering/box.dart] RenderBox::markNeedsLayout
    // 0x6dee84: add             SP, SP, #8
    // 0x6dee88: r0 = Null
    //     0x6dee88: mov             x0, NULL
    // 0x6dee8c: LeaveFrame
    //     0x6dee8c: mov             SP, fp
    //     0x6dee90: ldp             fp, lr, [SP], #0x10
    // 0x6dee94: ret
    //     0x6dee94: ret             
    // 0x6dee98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6dee98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6dee9c: b               #0x6dee70
  }
  set _ textScaleFactor=(/* No info */) {
    // ** addr: 0x6df67c, size: 0x7c
    // 0x6df67c: EnterFrame
    //     0x6df67c: stp             fp, lr, [SP, #-0x10]!
    //     0x6df680: mov             fp, SP
    // 0x6df684: CheckStackOverflow
    //     0x6df684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6df688: cmp             SP, x16
    //     0x6df68c: b.ls            #0x6df6f0
    // 0x6df690: ldr             x0, [fp, #0x18]
    // 0x6df694: LoadField: r1 = r0->field_eb
    //     0x6df694: ldur            w1, [x0, #0xeb]
    // 0x6df698: DecompressPointer r1
    //     0x6df698: add             x1, x1, HEAP, lsl #32
    // 0x6df69c: LoadField: d0 = r1->field_1f
    //     0x6df69c: ldur            d0, [x1, #0x1f]
    // 0x6df6a0: ldr             d1, [fp, #0x10]
    // 0x6df6a4: fcmp            d0, d1
    // 0x6df6a8: b.vs            #0x6df6c0
    // 0x6df6ac: b.ne            #0x6df6c0
    // 0x6df6b0: r0 = Null
    //     0x6df6b0: mov             x0, NULL
    // 0x6df6b4: LeaveFrame
    //     0x6df6b4: mov             SP, fp
    //     0x6df6b8: ldp             fp, lr, [SP], #0x10
    // 0x6df6bc: ret
    //     0x6df6bc: ret             
    // 0x6df6c0: SaveReg r1
    //     0x6df6c0: str             x1, [SP, #-8]!
    // 0x6df6c4: SaveReg d1
    //     0x6df6c4: str             d1, [SP, #-8]!
    // 0x6df6c8: r0 = textScaleFactor=()
    //     0x6df6c8: bl              #0x6df6f8  ; [package:flutter/src/painting/text_painter.dart] TextPainter::textScaleFactor=
    // 0x6df6cc: add             SP, SP, #0x10
    // 0x6df6d0: ldr             x16, [fp, #0x18]
    // 0x6df6d4: SaveReg r16
    //     0x6df6d4: str             x16, [SP, #-8]!
    // 0x6df6d8: r0 = markNeedsTextLayout()
    //     0x6df6d8: bl              #0x6dee5c  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::markNeedsTextLayout
    // 0x6df6dc: add             SP, SP, #8
    // 0x6df6e0: r0 = Null
    //     0x6df6e0: mov             x0, NULL
    // 0x6df6e4: LeaveFrame
    //     0x6df6e4: mov             SP, fp
    //     0x6df6e8: ldp             fp, lr, [SP], #0x10
    // 0x6df6ec: ret
    //     0x6df6ec: ret             
    // 0x6df6f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6df6f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6df6f4: b               #0x6df690
  }
  _ extractPlaceholderSpans(/* No info */) {
    // ** addr: 0x6dffd4, size: 0x9c
    // 0x6dffd4: EnterFrame
    //     0x6dffd4: stp             fp, lr, [SP, #-0x10]!
    //     0x6dffd8: mov             fp, SP
    // 0x6dffdc: AllocStack(0x8)
    //     0x6dffdc: sub             SP, SP, #8
    // 0x6dffe0: CheckStackOverflow
    //     0x6dffe0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6dffe4: cmp             SP, x16
    //     0x6dffe8: b.ls            #0x6e0068
    // 0x6dffec: r1 = 1
    //     0x6dffec: mov             x1, #1
    // 0x6dfff0: r0 = AllocateContext()
    //     0x6dfff0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x6dfff4: mov             x1, x0
    // 0x6dfff8: ldr             x0, [fp, #0x18]
    // 0x6dfffc: stur            x1, [fp, #-8]
    // 0x6e0000: StoreField: r1->field_f = r0
    //     0x6e0000: stur            w0, [x1, #0xf]
    // 0x6e0004: r16 = <PlaceholderSpan>
    //     0x6e0004: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d458] TypeArguments: <PlaceholderSpan>
    //     0x6e0008: ldr             x16, [x16, #0x458]
    // 0x6e000c: stp             xzr, x16, [SP, #-0x10]!
    // 0x6e0010: r0 = _GrowableList()
    //     0x6e0010: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x6e0014: add             SP, SP, #0x10
    // 0x6e0018: ldr             x1, [fp, #0x18]
    // 0x6e001c: StoreField: r1->field_7b = r0
    //     0x6e001c: stur            w0, [x1, #0x7b]
    //     0x6e0020: ldurb           w16, [x1, #-1]
    //     0x6e0024: ldurb           w17, [x0, #-1]
    //     0x6e0028: and             x16, x17, x16, lsr #2
    //     0x6e002c: tst             x16, HEAP, lsr #32
    //     0x6e0030: b.eq            #0x6e0038
    //     0x6e0034: bl              #0xd6826c
    // 0x6e0038: ldur            x2, [fp, #-8]
    // 0x6e003c: r1 = Function '<anonymous closure>':.
    //     0x6e003c: add             x1, PP, #0x55, lsl #12  ; [pp+0x55b58] AnonymousClosure: (0x6e0070), in [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::extractPlaceholderSpans (0x6dffd4)
    //     0x6e0040: ldr             x1, [x1, #0xb58]
    // 0x6e0044: r0 = AllocateClosure()
    //     0x6e0044: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x6e0048: ldr             x16, [fp, #0x10]
    // 0x6e004c: stp             x0, x16, [SP, #-0x10]!
    // 0x6e0050: r0 = visitChildren()
    //     0x6e0050: bl              #0xcdf548  ; [package:flutter/src/painting/text_span.dart] TextSpan::visitChildren
    // 0x6e0054: add             SP, SP, #0x10
    // 0x6e0058: r0 = Null
    //     0x6e0058: mov             x0, NULL
    // 0x6e005c: LeaveFrame
    //     0x6e005c: mov             SP, fp
    //     0x6e0060: ldp             fp, lr, [SP], #0x10
    // 0x6e0064: ret
    //     0x6e0064: ret             
    // 0x6e0068: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e0068: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e006c: b               #0x6dffec
  }
  [closure] bool <anonymous closure>(dynamic, InlineSpan) {
    // ** addr: 0x6e0070, size: 0x148
    // 0x6e0070: EnterFrame
    //     0x6e0070: stp             fp, lr, [SP, #-0x10]!
    //     0x6e0074: mov             fp, SP
    // 0x6e0078: AllocStack(0x20)
    //     0x6e0078: sub             SP, SP, #0x20
    // 0x6e007c: SetupParameters()
    //     0x6e007c: ldr             x0, [fp, #0x18]
    //     0x6e0080: ldur            w1, [x0, #0x17]
    //     0x6e0084: add             x1, x1, HEAP, lsl #32
    //     0x6e0088: stur            x1, [fp, #-0x20]
    // 0x6e008c: CheckStackOverflow
    //     0x6e008c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6e0090: cmp             SP, x16
    //     0x6e0094: b.ls            #0x6e01a0
    // 0x6e0098: ldr             x0, [fp, #0x10]
    // 0x6e009c: r2 = LoadClassIdInstr(r0)
    //     0x6e009c: ldur            x2, [x0, #-1]
    //     0x6e00a0: ubfx            x2, x2, #0xc, #0x14
    // 0x6e00a4: lsl             x2, x2, #1
    // 0x6e00a8: stur            x2, [fp, #-0x18]
    // 0x6e00ac: r3 = LoadInt32Instr(r2)
    //     0x6e00ac: sbfx            x3, x2, #1, #0x1f
    // 0x6e00b0: cmp             x3, #0xd95
    // 0x6e00b4: b.lt            #0x6e0168
    // 0x6e00b8: cmp             x3, #0xd97
    // 0x6e00bc: b.gt            #0x6e0168
    // 0x6e00c0: LoadField: r3 = r1->field_f
    //     0x6e00c0: ldur            w3, [x1, #0xf]
    // 0x6e00c4: DecompressPointer r3
    //     0x6e00c4: add             x3, x3, HEAP, lsl #32
    // 0x6e00c8: LoadField: r4 = r3->field_7b
    //     0x6e00c8: ldur            w4, [x3, #0x7b]
    // 0x6e00cc: DecompressPointer r4
    //     0x6e00cc: add             x4, x4, HEAP, lsl #32
    // 0x6e00d0: r16 = Sentinel
    //     0x6e00d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x6e00d4: cmp             w4, w16
    // 0x6e00d8: b.eq            #0x6e01a8
    // 0x6e00dc: stur            x4, [fp, #-0x10]
    // 0x6e00e0: LoadField: r3 = r4->field_b
    //     0x6e00e0: ldur            w3, [x4, #0xb]
    // 0x6e00e4: DecompressPointer r3
    //     0x6e00e4: add             x3, x3, HEAP, lsl #32
    // 0x6e00e8: stur            x3, [fp, #-8]
    // 0x6e00ec: LoadField: r5 = r4->field_f
    //     0x6e00ec: ldur            w5, [x4, #0xf]
    // 0x6e00f0: DecompressPointer r5
    //     0x6e00f0: add             x5, x5, HEAP, lsl #32
    // 0x6e00f4: LoadField: r6 = r5->field_b
    //     0x6e00f4: ldur            w6, [x5, #0xb]
    // 0x6e00f8: DecompressPointer r6
    //     0x6e00f8: add             x6, x6, HEAP, lsl #32
    // 0x6e00fc: cmp             w3, w6
    // 0x6e0100: b.ne            #0x6e0110
    // 0x6e0104: SaveReg r4
    //     0x6e0104: str             x4, [SP, #-8]!
    // 0x6e0108: r0 = _growToNextCapacity()
    //     0x6e0108: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x6e010c: add             SP, SP, #8
    // 0x6e0110: ldur            x2, [fp, #-0x10]
    // 0x6e0114: ldur            x3, [fp, #-8]
    // 0x6e0118: r4 = LoadInt32Instr(r3)
    //     0x6e0118: sbfx            x4, x3, #1, #0x1f
    // 0x6e011c: add             x0, x4, #1
    // 0x6e0120: lsl             x3, x0, #1
    // 0x6e0124: StoreField: r2->field_b = r3
    //     0x6e0124: stur            w3, [x2, #0xb]
    // 0x6e0128: mov             x1, x4
    // 0x6e012c: cmp             x1, x0
    // 0x6e0130: b.hs            #0x6e01b4
    // 0x6e0134: LoadField: r1 = r2->field_f
    //     0x6e0134: ldur            w1, [x2, #0xf]
    // 0x6e0138: DecompressPointer r1
    //     0x6e0138: add             x1, x1, HEAP, lsl #32
    // 0x6e013c: ldr             x0, [fp, #0x10]
    // 0x6e0140: ArrayStore: r1[r4] = r0  ; List_4
    //     0x6e0140: add             x25, x1, x4, lsl #2
    //     0x6e0144: add             x25, x25, #0xf
    //     0x6e0148: str             w0, [x25]
    //     0x6e014c: tbz             w0, #0, #0x6e0168
    //     0x6e0150: ldurb           w16, [x1, #-1]
    //     0x6e0154: ldurb           w17, [x0, #-1]
    //     0x6e0158: and             x16, x17, x16, lsr #2
    //     0x6e015c: tst             x16, HEAP, lsr #32
    //     0x6e0160: b.eq            #0x6e0168
    //     0x6e0164: bl              #0xd67e5c
    // 0x6e0168: ldur            x1, [fp, #-0x18]
    // 0x6e016c: r17 = 6950
    //     0x6e016c: mov             x17, #0x1b26
    // 0x6e0170: cmp             w1, w17
    // 0x6e0174: b.ne            #0x6e0190
    // 0x6e0178: ldur            x1, [fp, #-0x20]
    // 0x6e017c: r0 = true
    //     0x6e017c: add             x0, NULL, #0x20  ; true
    // 0x6e0180: LoadField: r2 = r1->field_f
    //     0x6e0180: ldur            w2, [x1, #0xf]
    // 0x6e0184: DecompressPointer r2
    //     0x6e0184: add             x2, x2, HEAP, lsl #32
    // 0x6e0188: StoreField: r2->field_77 = r0
    //     0x6e0188: stur            w0, [x2, #0x77]
    // 0x6e018c: b               #0x6e0194
    // 0x6e0190: r0 = true
    //     0x6e0190: add             x0, NULL, #0x20  ; true
    // 0x6e0194: LeaveFrame
    //     0x6e0194: mov             SP, fp
    //     0x6e0198: ldp             fp, lr, [SP], #0x10
    // 0x6e019c: ret
    //     0x6e019c: ret             
    // 0x6e01a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6e01a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6e01a4: b               #0x6e0098
    // 0x6e01a8: r9 = _placeholderSpans
    //     0x6e01a8: add             x9, PP, #0x37, lsl #12  ; [pp+0x37368] Field <ExtendedTextRenderBox._placeholderSpans@499234319>: late (offset: 0x7c)
    //     0x6e01ac: ldr             x9, [x9, #0x368]
    // 0x6e01b0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x6e01b0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x6e01b4: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x6e01b4: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void systemFontsDidChange(dynamic) {
    // ** addr: 0x9bcbb8, size: 0x48
    // 0x9bcbb8: EnterFrame
    //     0x9bcbb8: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcbbc: mov             fp, SP
    // 0x9bcbc0: ldr             x0, [fp, #0x10]
    // 0x9bcbc4: LoadField: r1 = r0->field_17
    //     0x9bcbc4: ldur            w1, [x0, #0x17]
    // 0x9bcbc8: DecompressPointer r1
    //     0x9bcbc8: add             x1, x1, HEAP, lsl #32
    // 0x9bcbcc: CheckStackOverflow
    //     0x9bcbcc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcbd0: cmp             SP, x16
    //     0x9bcbd4: b.ls            #0x9bcbf8
    // 0x9bcbd8: LoadField: r0 = r1->field_f
    //     0x9bcbd8: ldur            w0, [x1, #0xf]
    // 0x9bcbdc: DecompressPointer r0
    //     0x9bcbdc: add             x0, x0, HEAP, lsl #32
    // 0x9bcbe0: SaveReg r0
    //     0x9bcbe0: str             x0, [SP, #-8]!
    // 0x9bcbe4: r0 = systemFontsDidChange()
    //     0x9bcbe4: bl              #0x9bcc00  ; [package:extended_text_library/src/render_object/extended_text_render_box.dart] ExtendedTextRenderBox::systemFontsDidChange
    // 0x9bcbe8: add             SP, SP, #8
    // 0x9bcbec: LeaveFrame
    //     0x9bcbec: mov             SP, fp
    //     0x9bcbf0: ldp             fp, lr, [SP], #0x10
    // 0x9bcbf4: ret
    //     0x9bcbf4: ret             
    // 0x9bcbf8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcbf8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcbfc: b               #0x9bcbd8
  }
  _ systemFontsDidChange(/* No info */) {
    // ** addr: 0x9bcc00, size: 0x60
    // 0x9bcc00: EnterFrame
    //     0x9bcc00: stp             fp, lr, [SP, #-0x10]!
    //     0x9bcc04: mov             fp, SP
    // 0x9bcc08: CheckStackOverflow
    //     0x9bcc08: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9bcc0c: cmp             SP, x16
    //     0x9bcc10: b.ls            #0x9bcc58
    // 0x9bcc14: ldr             x16, [fp, #0x10]
    // 0x9bcc18: SaveReg r16
    //     0x9bcc18: str             x16, [SP, #-8]!
    // 0x9bcc1c: r0 = systemFontsDidChange()
    //     0x9bcc1c: bl              #0x9bcc60  ; [package:flutter/src/rendering/paragraph.dart] _RenderParagraph&RenderBox&ContainerRenderObjectMixin&RenderBoxContainerDefaultsMixin&RelayoutWhenSystemFontsChangeMixin::systemFontsDidChange
    // 0x9bcc20: add             SP, SP, #8
    // 0x9bcc24: ldr             x0, [fp, #0x10]
    // 0x9bcc28: LoadField: r1 = r0->field_eb
    //     0x9bcc28: ldur            w1, [x0, #0xeb]
    // 0x9bcc2c: DecompressPointer r1
    //     0x9bcc2c: add             x1, x1, HEAP, lsl #32
    // 0x9bcc30: SaveReg r1
    //     0x9bcc30: str             x1, [SP, #-8]!
    // 0x9bcc34: r0 = markNeedsLayout()
    //     0x9bcc34: bl              #0x62d54c  ; [package:flutter/src/painting/text_painter.dart] TextPainter::markNeedsLayout
    // 0x9bcc38: add             SP, SP, #8
    // 0x9bcc3c: ldr             x1, [fp, #0x10]
    // 0x9bcc40: StoreField: r1->field_6f = rNULL
    //     0x9bcc40: stur            NULL, [x1, #0x6f]
    // 0x9bcc44: StoreField: r1->field_73 = rNULL
    //     0x9bcc44: stur            NULL, [x1, #0x73]
    // 0x9bcc48: r0 = Null
    //     0x9bcc48: mov             x0, NULL
    // 0x9bcc4c: LeaveFrame
    //     0x9bcc4c: mov             SP, fp
    //     0x9bcc50: ldp             fp, lr, [SP], #0x10
    // 0x9bcc54: ret
    //     0x9bcc54: ret             
    // 0x9bcc58: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9bcc58: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9bcc5c: b               #0x9bcc14
  }
}

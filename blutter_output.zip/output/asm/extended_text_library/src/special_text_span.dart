// lib: , url: package:extended_text_library/src/special_text_span.dart

// class id: 1048989, size: 0x8
class :: {
}

// class id: 3474, size: 0x30, field offset: 0x30
//   const constructor, transformed mixin,
abstract class _SpecialTextSpan&TextSpan&SpecialInlineSpanBase extends TextSpan
     with SpecialInlineSpanBase {

  _ baseCompareTo(/* No info */) {
    // ** addr: 0x6736c4, size: 0xbc
    // 0x6736c4: EnterFrame
    //     0x6736c4: stp             fp, lr, [SP, #-0x10]!
    //     0x6736c8: mov             fp, SP
    // 0x6736cc: CheckStackOverflow
    //     0x6736cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6736d0: cmp             SP, x16
    //     0x6736d4: b.ls            #0x673778
    // 0x6736d8: ldr             x1, [fp, #0x10]
    // 0x6736dc: LoadField: r0 = r1->field_2f
    //     0x6736dc: ldur            w0, [x1, #0x2f]
    // 0x6736e0: DecompressPointer r0
    //     0x6736e0: add             x0, x0, HEAP, lsl #32
    // 0x6736e4: ldr             x2, [fp, #0x18]
    // 0x6736e8: LoadField: r3 = r2->field_2f
    //     0x6736e8: ldur            w3, [x2, #0x2f]
    // 0x6736ec: DecompressPointer r3
    //     0x6736ec: add             x3, x3, HEAP, lsl #32
    // 0x6736f0: r4 = LoadClassIdInstr(r0)
    //     0x6736f0: ldur            x4, [x0, #-1]
    //     0x6736f4: ubfx            x4, x4, #0xc, #0x14
    // 0x6736f8: stp             x3, x0, [SP, #-0x10]!
    // 0x6736fc: mov             x0, x4
    // 0x673700: mov             lr, x0
    // 0x673704: ldr             lr, [x21, lr, lsl #3]
    // 0x673708: blr             lr
    // 0x67370c: add             SP, SP, #0x10
    // 0x673710: tbz             w0, #4, #0x673728
    // 0x673714: r0 = Instance_RenderComparison
    //     0x673714: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d488] Obj!RenderComparison@b65011
    //     0x673718: ldr             x0, [x0, #0x488]
    // 0x67371c: LeaveFrame
    //     0x67371c: mov             SP, fp
    //     0x673720: ldp             fp, lr, [SP], #0x10
    // 0x673724: ret
    //     0x673724: ret             
    // 0x673728: ldr             x2, [fp, #0x18]
    // 0x67372c: ldr             x1, [fp, #0x10]
    // 0x673730: LoadField: r3 = r1->field_37
    //     0x673730: ldur            w3, [x1, #0x37]
    // 0x673734: DecompressPointer r3
    //     0x673734: add             x3, x3, HEAP, lsl #32
    // 0x673738: LoadField: r1 = r3->field_7
    //     0x673738: ldur            x1, [x3, #7]
    // 0x67373c: LoadField: r3 = r2->field_37
    //     0x67373c: ldur            w3, [x2, #0x37]
    // 0x673740: DecompressPointer r3
    //     0x673740: add             x3, x3, HEAP, lsl #32
    // 0x673744: LoadField: r2 = r3->field_7
    //     0x673744: ldur            x2, [x3, #7]
    // 0x673748: cmp             x1, x2
    // 0x67374c: b.eq            #0x673764
    // 0x673750: r0 = Instance_RenderComparison
    //     0x673750: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d470] Obj!RenderComparison@b65031
    //     0x673754: ldr             x0, [x0, #0x470]
    // 0x673758: LeaveFrame
    //     0x673758: mov             SP, fp
    //     0x67375c: ldp             fp, lr, [SP], #0x10
    // 0x673760: ret
    //     0x673760: ret             
    // 0x673764: r0 = Instance_RenderComparison
    //     0x673764: add             x0, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0x673768: ldr             x0, [x0, #0x438]
    // 0x67376c: LeaveFrame
    //     0x67376c: mov             SP, fp
    //     0x673770: ldp             fp, lr, [SP], #0x10
    // 0x673774: ret
    //     0x673774: ret             
    // 0x673778: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x673778: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67377c: b               #0x6736d8
  }
  get _ baseHashCode(/* No info */) {
    // ** addr: 0xafb9a0, size: 0x58
    // 0xafb9a0: EnterFrame
    //     0xafb9a0: stp             fp, lr, [SP, #-0x10]!
    //     0xafb9a4: mov             fp, SP
    // 0xafb9a8: CheckStackOverflow
    //     0xafb9a8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafb9ac: cmp             SP, x16
    //     0xafb9b0: b.ls            #0xafb9f0
    // 0xafb9b4: ldr             x0, [fp, #0x10]
    // 0xafb9b8: LoadField: r1 = r0->field_2f
    //     0xafb9b8: ldur            w1, [x0, #0x2f]
    // 0xafb9bc: DecompressPointer r1
    //     0xafb9bc: add             x1, x1, HEAP, lsl #32
    // 0xafb9c0: LoadField: r2 = r0->field_37
    //     0xafb9c0: ldur            w2, [x0, #0x37]
    // 0xafb9c4: DecompressPointer r2
    //     0xafb9c4: add             x2, x2, HEAP, lsl #32
    // 0xafb9c8: LoadField: r0 = r2->field_7
    //     0xafb9c8: ldur            x0, [x2, #7]
    // 0xafb9cc: stp             x0, x1, [SP, #-0x10]!
    // 0xafb9d0: r16 = true
    //     0xafb9d0: add             x16, NULL, #0x20  ; true
    // 0xafb9d4: SaveReg r16
    //     0xafb9d4: str             x16, [SP, #-8]!
    // 0xafb9d8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xafb9d8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xafb9dc: r0 = hashValues()
    //     0xafb9dc: bl              #0xafb7e0  ; [dart:ui] ::hashValues
    // 0xafb9e0: add             SP, SP, #0x18
    // 0xafb9e4: LeaveFrame
    //     0xafb9e4: mov             SP, fp
    //     0xafb9e8: ldp             fp, lr, [SP], #0x10
    // 0xafb9ec: ret
    //     0xafb9ec: ret             
    // 0xafb9f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafb9f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafb9f4: b               #0xafb9b4
  }
  _ equal(/* No info */) {
    // ** addr: 0xc75d98, size: 0x88
    // 0xc75d98: EnterFrame
    //     0xc75d98: stp             fp, lr, [SP, #-0x10]!
    //     0xc75d9c: mov             fp, SP
    // 0xc75da0: CheckStackOverflow
    //     0xc75da0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc75da4: cmp             SP, x16
    //     0xc75da8: b.ls            #0xc75e18
    // 0xc75dac: ldr             x0, [fp, #0x10]
    // 0xc75db0: LoadField: r1 = r0->field_37
    //     0xc75db0: ldur            w1, [x0, #0x37]
    // 0xc75db4: DecompressPointer r1
    //     0xc75db4: add             x1, x1, HEAP, lsl #32
    // 0xc75db8: LoadField: r2 = r1->field_7
    //     0xc75db8: ldur            x2, [x1, #7]
    // 0xc75dbc: ldr             x1, [fp, #0x18]
    // 0xc75dc0: LoadField: r3 = r1->field_37
    //     0xc75dc0: ldur            w3, [x1, #0x37]
    // 0xc75dc4: DecompressPointer r3
    //     0xc75dc4: add             x3, x3, HEAP, lsl #32
    // 0xc75dc8: LoadField: r4 = r3->field_7
    //     0xc75dc8: ldur            x4, [x3, #7]
    // 0xc75dcc: cmp             x2, x4
    // 0xc75dd0: b.ne            #0xc75e08
    // 0xc75dd4: LoadField: r2 = r0->field_2f
    //     0xc75dd4: ldur            w2, [x0, #0x2f]
    // 0xc75dd8: DecompressPointer r2
    //     0xc75dd8: add             x2, x2, HEAP, lsl #32
    // 0xc75ddc: LoadField: r0 = r1->field_2f
    //     0xc75ddc: ldur            w0, [x1, #0x2f]
    // 0xc75de0: DecompressPointer r0
    //     0xc75de0: add             x0, x0, HEAP, lsl #32
    // 0xc75de4: r1 = LoadClassIdInstr(r2)
    //     0xc75de4: ldur            x1, [x2, #-1]
    //     0xc75de8: ubfx            x1, x1, #0xc, #0x14
    // 0xc75dec: stp             x0, x2, [SP, #-0x10]!
    // 0xc75df0: mov             x0, x1
    // 0xc75df4: mov             lr, x0
    // 0xc75df8: ldr             lr, [x21, lr, lsl #3]
    // 0xc75dfc: blr             lr
    // 0xc75e00: add             SP, SP, #0x10
    // 0xc75e04: b               #0xc75e0c
    // 0xc75e08: r0 = false
    //     0xc75e08: add             x0, NULL, #0x30  ; false
    // 0xc75e0c: LeaveFrame
    //     0xc75e0c: mov             SP, fp
    //     0xc75e10: ldp             fp, lr, [SP], #0x10
    // 0xc75e14: ret
    //     0xc75e14: ret             
    // 0xc75e18: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75e18: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75e1c: b               #0xc75dac
  }
}

// class id: 3475, size: 0x3c, field offset: 0x30
class SpecialTextSpan extends _SpecialTextSpan&TextSpan&SpecialInlineSpanBase {

  RenderComparison compareTo(SpecialTextSpan, InlineSpan) {
    // ** addr: 0x673598, size: 0x90
    // 0x673598: EnterFrame
    //     0x673598: stp             fp, lr, [SP, #-0x10]!
    //     0x67359c: mov             fp, SP
    // 0x6735a0: CheckStackOverflow
    //     0x6735a0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6735a4: cmp             SP, x16
    //     0x6735a8: b.ls            #0x673608
    // 0x6735ac: ldr             x0, [fp, #0x10]
    // 0x6735b0: r2 = Null
    //     0x6735b0: mov             x2, NULL
    // 0x6735b4: r1 = Null
    //     0x6735b4: mov             x1, NULL
    // 0x6735b8: r4 = 59
    //     0x6735b8: mov             x4, #0x3b
    // 0x6735bc: branchIfSmi(r0, 0x6735c8)
    //     0x6735bc: tbz             w0, #0, #0x6735c8
    // 0x6735c0: r4 = LoadClassIdInstr(r0)
    //     0x6735c0: ldur            x4, [x0, #-1]
    //     0x6735c4: ubfx            x4, x4, #0xc, #0x14
    // 0x6735c8: sub             x4, x4, #0xd91
    // 0x6735cc: cmp             x4, #6
    // 0x6735d0: b.ls            #0x6735e8
    // 0x6735d4: r8 = InlineSpan
    //     0x6735d4: add             x8, PP, #0x29, lsl #12  ; [pp+0x29028] Type: InlineSpan
    //     0x6735d8: ldr             x8, [x8, #0x28]
    // 0x6735dc: r3 = Null
    //     0x6735dc: add             x3, PP, #0x40, lsl #12  ; [pp+0x40a30] Null
    //     0x6735e0: ldr             x3, [x3, #0xa30]
    // 0x6735e4: r0 = InlineSpan()
    //     0x6735e4: bl              #0x521860  ; IsType_InlineSpan_Stub
    // 0x6735e8: ldr             x16, [fp, #0x18]
    // 0x6735ec: ldr             lr, [fp, #0x10]
    // 0x6735f0: stp             lr, x16, [SP, #-0x10]!
    // 0x6735f4: r0 = compareTo()
    //     0x6735f4: bl              #0xcdc780  ; [package:extended_text_library/src/special_text_span.dart] SpecialTextSpan::compareTo
    // 0x6735f8: add             SP, SP, #0x10
    // 0x6735fc: LeaveFrame
    //     0x6735fc: mov             SP, fp
    //     0x673600: ldp             fp, lr, [SP], #0x10
    // 0x673604: ret
    //     0x673604: ret             
    // 0x673608: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x673608: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x67360c: b               #0x6735ac
  }
  _ SpecialTextSpan(/* No info */) {
    // ** addr: 0x7ab4d4, size: 0xc4
    // 0x7ab4d4: EnterFrame
    //     0x7ab4d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7ab4d8: mov             fp, SP
    // 0x7ab4dc: AllocStack(0x8)
    //     0x7ab4dc: sub             SP, SP, #8
    // 0x7ab4e0: r0 = true
    //     0x7ab4e0: add             x0, NULL, #0x20  ; true
    // 0x7ab4e4: ldr             x1, [fp, #0x20]
    // 0x7ab4e8: StoreField: r1->field_33 = r0
    //     0x7ab4e8: stur            w0, [x1, #0x33]
    // 0x7ab4ec: ldr             x0, [fp, #0x18]
    // 0x7ab4f0: StoreField: r1->field_2f = r0
    //     0x7ab4f0: stur            w0, [x1, #0x2f]
    //     0x7ab4f4: ldurb           w16, [x1, #-1]
    //     0x7ab4f8: ldurb           w17, [x0, #-1]
    //     0x7ab4fc: and             x16, x17, x16, lsr #2
    //     0x7ab500: tst             x16, HEAP, lsr #32
    //     0x7ab504: b.eq            #0x7ab50c
    //     0x7ab508: bl              #0xd6826c
    // 0x7ab50c: ldr             x0, [fp, #0x18]
    // 0x7ab510: LoadField: r2 = r0->field_7
    //     0x7ab510: ldur            w2, [x0, #7]
    // 0x7ab514: DecompressPointer r2
    //     0x7ab514: add             x2, x2, HEAP, lsl #32
    // 0x7ab518: r0 = LoadInt32Instr(r2)
    //     0x7ab518: sbfx            x0, x2, #1, #0x1f
    // 0x7ab51c: stur            x0, [fp, #-8]
    // 0x7ab520: r0 = TextRange()
    //     0x7ab520: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x7ab524: r1 = 0
    //     0x7ab524: mov             x1, #0
    // 0x7ab528: StoreField: r0->field_7 = r1
    //     0x7ab528: stur            x1, [x0, #7]
    // 0x7ab52c: ldur            x1, [fp, #-8]
    // 0x7ab530: StoreField: r0->field_f = r1
    //     0x7ab530: stur            x1, [x0, #0xf]
    // 0x7ab534: ldr             x1, [fp, #0x20]
    // 0x7ab538: StoreField: r1->field_37 = r0
    //     0x7ab538: stur            w0, [x1, #0x37]
    //     0x7ab53c: ldurb           w16, [x1, #-1]
    //     0x7ab540: ldurb           w17, [x0, #-1]
    //     0x7ab544: and             x16, x17, x16, lsr #2
    //     0x7ab548: tst             x16, HEAP, lsr #32
    //     0x7ab54c: b.eq            #0x7ab554
    //     0x7ab550: bl              #0xd6826c
    // 0x7ab554: ldr             x0, [fp, #0x10]
    // 0x7ab558: StoreField: r1->field_b = r0
    //     0x7ab558: stur            w0, [x1, #0xb]
    //     0x7ab55c: ldurb           w16, [x1, #-1]
    //     0x7ab560: ldurb           w17, [x0, #-1]
    //     0x7ab564: and             x16, x17, x16, lsr #2
    //     0x7ab568: tst             x16, HEAP, lsr #32
    //     0x7ab56c: b.eq            #0x7ab574
    //     0x7ab570: bl              #0xd6826c
    // 0x7ab574: r2 = Instance__DeferringMouseCursor
    //     0x7ab574: ldr             x2, [PP, #0x39d8]  ; [pp+0x39d8] Obj!_DeferringMouseCursor@b489e1
    // 0x7ab578: StoreField: r1->field_17 = r2
    //     0x7ab578: stur            w2, [x1, #0x17]
    // 0x7ab57c: r2 = Instance_TextStyle
    //     0x7ab57c: add             x2, PP, #0x37, lsl #12  ; [pp+0x376b0] Obj!TextStyle@b439f1
    //     0x7ab580: ldr             x2, [x2, #0x6b0]
    // 0x7ab584: StoreField: r1->field_7 = r2
    //     0x7ab584: stur            w2, [x1, #7]
    // 0x7ab588: r0 = Null
    //     0x7ab588: mov             x0, NULL
    // 0x7ab58c: LeaveFrame
    //     0x7ab58c: mov             SP, fp
    //     0x7ab590: ldp             fp, lr, [SP], #0x10
    // 0x7ab594: ret
    //     0x7ab594: ret             
  }
  get _ hashCode(/* No info */) {
    // ** addr: 0xafb764, size: 0x7c
    // 0xafb764: EnterFrame
    //     0xafb764: stp             fp, lr, [SP, #-0x10]!
    //     0xafb768: mov             fp, SP
    // 0xafb76c: AllocStack(0x8)
    //     0xafb76c: sub             SP, SP, #8
    // 0xafb770: CheckStackOverflow
    //     0xafb770: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xafb774: cmp             SP, x16
    //     0xafb778: b.ls            #0xafb7d8
    // 0xafb77c: ldr             x16, [fp, #0x10]
    // 0xafb780: SaveReg r16
    //     0xafb780: str             x16, [SP, #-8]!
    // 0xafb784: r0 = hashCode()
    //     0xafb784: bl              #0xafb9f8  ; [package:flutter/src/painting/text_span.dart] TextSpan::hashCode
    // 0xafb788: add             SP, SP, #8
    // 0xafb78c: stur            x0, [fp, #-8]
    // 0xafb790: ldr             x16, [fp, #0x10]
    // 0xafb794: SaveReg r16
    //     0xafb794: str             x16, [SP, #-8]!
    // 0xafb798: r0 = baseHashCode()
    //     0xafb798: bl              #0xafb9a0  ; [package:extended_text_library/src/special_text_span.dart] _SpecialTextSpan&TextSpan&SpecialInlineSpanBase::baseHashCode
    // 0xafb79c: add             SP, SP, #8
    // 0xafb7a0: ldur            x16, [fp, #-8]
    // 0xafb7a4: stp             x0, x16, [SP, #-0x10]!
    // 0xafb7a8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xafb7a8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xafb7ac: r0 = hashValues()
    //     0xafb7ac: bl              #0xafb7e0  ; [dart:ui] ::hashValues
    // 0xafb7b0: add             SP, SP, #0x10
    // 0xafb7b4: mov             x2, x0
    // 0xafb7b8: r0 = BoxInt64Instr(r2)
    //     0xafb7b8: sbfiz           x0, x2, #1, #0x1f
    //     0xafb7bc: cmp             x2, x0, asr #1
    //     0xafb7c0: b.eq            #0xafb7cc
    //     0xafb7c4: bl              #0xd69bb8
    //     0xafb7c8: stur            x2, [x0, #7]
    // 0xafb7cc: LeaveFrame
    //     0xafb7cc: mov             SP, fp
    //     0xafb7d0: ldp             fp, lr, [SP], #0x10
    // 0xafb7d4: ret
    //     0xafb7d4: ret             
    // 0xafb7d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xafb7d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xafb7dc: b               #0xafb77c
  }
  _ ==(/* No info */) {
    // ** addr: 0xc75c70, size: 0x128
    // 0xc75c70: EnterFrame
    //     0xc75c70: stp             fp, lr, [SP, #-0x10]!
    //     0xc75c74: mov             fp, SP
    // 0xc75c78: CheckStackOverflow
    //     0xc75c78: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc75c7c: cmp             SP, x16
    //     0xc75c80: b.ls            #0xc75d90
    // 0xc75c84: ldr             x1, [fp, #0x10]
    // 0xc75c88: cmp             w1, NULL
    // 0xc75c8c: b.ne            #0xc75ca0
    // 0xc75c90: r0 = false
    //     0xc75c90: add             x0, NULL, #0x30  ; false
    // 0xc75c94: LeaveFrame
    //     0xc75c94: mov             SP, fp
    //     0xc75c98: ldp             fp, lr, [SP], #0x10
    // 0xc75c9c: ret
    //     0xc75c9c: ret             
    // 0xc75ca0: ldr             x2, [fp, #0x18]
    // 0xc75ca4: cmp             w2, w1
    // 0xc75ca8: b.ne            #0xc75cbc
    // 0xc75cac: r0 = true
    //     0xc75cac: add             x0, NULL, #0x20  ; true
    // 0xc75cb0: LeaveFrame
    //     0xc75cb0: mov             SP, fp
    //     0xc75cb4: ldp             fp, lr, [SP], #0x10
    // 0xc75cb8: ret
    //     0xc75cb8: ret             
    // 0xc75cbc: r0 = 59
    //     0xc75cbc: mov             x0, #0x3b
    // 0xc75cc0: branchIfSmi(r1, 0xc75ccc)
    //     0xc75cc0: tbz             w1, #0, #0xc75ccc
    // 0xc75cc4: r0 = LoadClassIdInstr(r1)
    //     0xc75cc4: ldur            x0, [x1, #-1]
    //     0xc75cc8: ubfx            x0, x0, #0xc, #0x14
    // 0xc75ccc: SaveReg r1
    //     0xc75ccc: str             x1, [SP, #-8]!
    // 0xc75cd0: r0 = GDT[cid_x0 + 0x57c5]()
    //     0xc75cd0: mov             x17, #0x57c5
    //     0xc75cd4: add             lr, x0, x17
    //     0xc75cd8: ldr             lr, [x21, lr, lsl #3]
    //     0xc75cdc: blr             lr
    // 0xc75ce0: add             SP, SP, #8
    // 0xc75ce4: r1 = LoadClassIdInstr(r0)
    //     0xc75ce4: ldur            x1, [x0, #-1]
    //     0xc75ce8: ubfx            x1, x1, #0xc, #0x14
    // 0xc75cec: r16 = SpecialTextSpan
    //     0xc75cec: add             x16, PP, #0x40, lsl #12  ; [pp+0x40a58] Type: SpecialTextSpan
    //     0xc75cf0: ldr             x16, [x16, #0xa58]
    // 0xc75cf4: stp             x16, x0, [SP, #-0x10]!
    // 0xc75cf8: mov             x0, x1
    // 0xc75cfc: mov             lr, x0
    // 0xc75d00: ldr             lr, [x21, lr, lsl #3]
    // 0xc75d04: blr             lr
    // 0xc75d08: add             SP, SP, #0x10
    // 0xc75d0c: tbz             w0, #4, #0xc75d20
    // 0xc75d10: r0 = false
    //     0xc75d10: add             x0, NULL, #0x30  ; false
    // 0xc75d14: LeaveFrame
    //     0xc75d14: mov             SP, fp
    //     0xc75d18: ldp             fp, lr, [SP], #0x10
    // 0xc75d1c: ret
    //     0xc75d1c: ret             
    // 0xc75d20: ldr             x16, [fp, #0x18]
    // 0xc75d24: ldr             lr, [fp, #0x10]
    // 0xc75d28: stp             lr, x16, [SP, #-0x10]!
    // 0xc75d2c: r0 = ==()
    //     0xc75d2c: bl              #0xc75e20  ; [package:flutter/src/painting/text_span.dart] TextSpan::==
    // 0xc75d30: add             SP, SP, #0x10
    // 0xc75d34: tbz             w0, #4, #0xc75d48
    // 0xc75d38: r0 = false
    //     0xc75d38: add             x0, NULL, #0x30  ; false
    // 0xc75d3c: LeaveFrame
    //     0xc75d3c: mov             SP, fp
    //     0xc75d40: ldp             fp, lr, [SP], #0x10
    // 0xc75d44: ret
    //     0xc75d44: ret             
    // 0xc75d48: ldr             x0, [fp, #0x10]
    // 0xc75d4c: r1 = LoadTaggedClassIdMayBeSmiInstr(r0)
    //     0xc75d4c: mov             x1, #0x76
    //     0xc75d50: tbz             w0, #0, #0xc75d60
    //     0xc75d54: ldur            x1, [x0, #-1]
    //     0xc75d58: ubfx            x1, x1, #0xc, #0x14
    //     0xc75d5c: lsl             x1, x1, #1
    // 0xc75d60: r17 = 6950
    //     0xc75d60: mov             x17, #0x1b26
    // 0xc75d64: cmp             w1, w17
    // 0xc75d68: b.ne            #0xc75d80
    // 0xc75d6c: ldr             x16, [fp, #0x18]
    // 0xc75d70: stp             x0, x16, [SP, #-0x10]!
    // 0xc75d74: r0 = equal()
    //     0xc75d74: bl              #0xc75d98  ; [package:extended_text_library/src/special_text_span.dart] _SpecialTextSpan&TextSpan&SpecialInlineSpanBase::equal
    // 0xc75d78: add             SP, SP, #0x10
    // 0xc75d7c: b               #0xc75d84
    // 0xc75d80: r0 = false
    //     0xc75d80: add             x0, NULL, #0x30  ; false
    // 0xc75d84: LeaveFrame
    //     0xc75d84: mov             SP, fp
    //     0xc75d88: ldp             fp, lr, [SP], #0x10
    // 0xc75d8c: ret
    //     0xc75d8c: ret             
    // 0xc75d90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc75d90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc75d94: b               #0xc75c84
  }
  RenderComparison compareTo(SpecialTextSpan, InlineSpan) {
    // ** addr: 0xcdc780, size: 0x90
    // 0xcdc780: EnterFrame
    //     0xcdc780: stp             fp, lr, [SP, #-0x10]!
    //     0xcdc784: mov             fp, SP
    // 0xcdc788: CheckStackOverflow
    //     0xcdc788: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdc78c: cmp             SP, x16
    //     0xcdc790: b.ls            #0xcdc808
    // 0xcdc794: ldr             x16, [fp, #0x18]
    // 0xcdc798: ldr             lr, [fp, #0x10]
    // 0xcdc79c: stp             lr, x16, [SP, #-0x10]!
    // 0xcdc7a0: r0 = compareTo()
    //     0xcdc7a0: bl              #0xcdc8cc  ; [package:flutter/src/painting/text_span.dart] TextSpan::compareTo
    // 0xcdc7a4: add             SP, SP, #0x10
    // 0xcdc7a8: r16 = Instance_RenderComparison
    //     0xcdc7a8: add             x16, PP, #0x1d, lsl #12  ; [pp+0x1d438] Obj!RenderComparison@b65051
    //     0xcdc7ac: ldr             x16, [x16, #0x438]
    // 0xcdc7b0: cmp             w0, w16
    // 0xcdc7b4: b.ne            #0xcdc7fc
    // 0xcdc7b8: ldr             x0, [fp, #0x10]
    // 0xcdc7bc: r2 = Null
    //     0xcdc7bc: mov             x2, NULL
    // 0xcdc7c0: r1 = Null
    //     0xcdc7c0: mov             x1, NULL
    // 0xcdc7c4: r4 = LoadClassIdInstr(r0)
    //     0xcdc7c4: ldur            x4, [x0, #-1]
    //     0xcdc7c8: ubfx            x4, x4, #0xc, #0x14
    // 0xcdc7cc: cmp             x4, #0xd93
    // 0xcdc7d0: b.eq            #0xcdc7e8
    // 0xcdc7d4: r8 = SpecialInlineSpanBase
    //     0xcdc7d4: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d440] Type: SpecialInlineSpanBase
    //     0xcdc7d8: ldr             x8, [x8, #0x440]
    // 0xcdc7dc: r3 = Null
    //     0xcdc7dc: add             x3, PP, #0x40, lsl #12  ; [pp+0x40a40] Null
    //     0xcdc7e0: ldr             x3, [x3, #0xa40]
    // 0xcdc7e4: r0 = DefaultTypeTest()
    //     0xcdc7e4: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0xcdc7e8: ldr             x16, [fp, #0x18]
    // 0xcdc7ec: ldr             lr, [fp, #0x10]
    // 0xcdc7f0: stp             lr, x16, [SP, #-0x10]!
    // 0xcdc7f4: r0 = baseCompareTo()
    //     0xcdc7f4: bl              #0x6736c4  ; [package:extended_text_library/src/special_text_span.dart] _SpecialTextSpan&TextSpan&SpecialInlineSpanBase::baseCompareTo
    // 0xcdc7f8: add             SP, SP, #0x10
    // 0xcdc7fc: LeaveFrame
    //     0xcdc7fc: mov             SP, fp
    //     0xcdc800: ldp             fp, lr, [SP], #0x10
    // 0xcdc804: ret
    //     0xcdc804: ret             
    // 0xcdc808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdc808: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdc80c: b               #0xcdc794
  }
}

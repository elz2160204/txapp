// lib: , url: package:extended_text_library/src/selection/extended_text_selection_overlay.dart

// class id: 1048984, size: 0x8
class :: {
}

// class id: 3363, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __SelectionHandleOverlayState&State&SingleTickerProviderStateMixin extends State<_SelectionHandleOverlay>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x614918, size: 0x98
    // 0x614918: EnterFrame
    //     0x614918: stp             fp, lr, [SP, #-0x10]!
    //     0x61491c: mov             fp, SP
    // 0x614920: CheckStackOverflow
    //     0x614920: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614924: cmp             SP, x16
    //     0x614928: b.ls            #0x6149a4
    // 0x61492c: r0 = Ticker()
    //     0x61492c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x614930: mov             x1, x0
    // 0x614934: r0 = false
    //     0x614934: add             x0, NULL, #0x30  ; false
    // 0x614938: StoreField: r1->field_b = r0
    //     0x614938: stur            w0, [x1, #0xb]
    // 0x61493c: ldr             x0, [fp, #0x10]
    // 0x614940: StoreField: r1->field_13 = r0
    //     0x614940: stur            w0, [x1, #0x13]
    // 0x614944: mov             x0, x1
    // 0x614948: ldr             x1, [fp, #0x18]
    // 0x61494c: StoreField: r1->field_13 = r0
    //     0x61494c: stur            w0, [x1, #0x13]
    //     0x614950: ldurb           w16, [x1, #-1]
    //     0x614954: ldurb           w17, [x0, #-1]
    //     0x614958: and             x16, x17, x16, lsr #2
    //     0x61495c: tst             x16, HEAP, lsr #32
    //     0x614960: b.eq            #0x614968
    //     0x614964: bl              #0xd6826c
    // 0x614968: SaveReg r1
    //     0x614968: str             x1, [SP, #-8]!
    // 0x61496c: r0 = _updateTickerModeNotifier()
    //     0x61496c: bl              #0x6149d4  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionHandleOverlayState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x614970: add             SP, SP, #8
    // 0x614974: ldr             x16, [fp, #0x18]
    // 0x614978: SaveReg r16
    //     0x614978: str             x16, [SP, #-8]!
    // 0x61497c: r0 = _updateTicker()
    //     0x61497c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614980: add             SP, SP, #8
    // 0x614984: ldr             x1, [fp, #0x18]
    // 0x614988: LoadField: r0 = r1->field_13
    //     0x614988: ldur            w0, [x1, #0x13]
    // 0x61498c: DecompressPointer r0
    //     0x61498c: add             x0, x0, HEAP, lsl #32
    // 0x614990: cmp             w0, NULL
    // 0x614994: b.eq            #0x6149ac
    // 0x614998: LeaveFrame
    //     0x614998: mov             SP, fp
    //     0x61499c: ldp             fp, lr, [SP], #0x10
    // 0x6149a0: ret
    //     0x6149a0: ret             
    // 0x6149a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6149a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6149a8: b               #0x61492c
    // 0x6149ac: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6149ac: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6149d4, size: 0x11c
    // 0x6149d4: EnterFrame
    //     0x6149d4: stp             fp, lr, [SP, #-0x10]!
    //     0x6149d8: mov             fp, SP
    // 0x6149dc: AllocStack(0x10)
    //     0x6149dc: sub             SP, SP, #0x10
    // 0x6149e0: CheckStackOverflow
    //     0x6149e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6149e4: cmp             SP, x16
    //     0x6149e8: b.ls            #0x614ae4
    // 0x6149ec: ldr             x0, [fp, #0x10]
    // 0x6149f0: LoadField: r1 = r0->field_f
    //     0x6149f0: ldur            w1, [x0, #0xf]
    // 0x6149f4: DecompressPointer r1
    //     0x6149f4: add             x1, x1, HEAP, lsl #32
    // 0x6149f8: cmp             w1, NULL
    // 0x6149fc: b.eq            #0x614aec
    // 0x614a00: SaveReg r1
    //     0x614a00: str             x1, [SP, #-8]!
    // 0x614a04: r0 = getNotifier()
    //     0x614a04: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x614a08: add             SP, SP, #8
    // 0x614a0c: mov             x1, x0
    // 0x614a10: ldr             x0, [fp, #0x10]
    // 0x614a14: stur            x1, [fp, #-0x10]
    // 0x614a18: LoadField: r2 = r0->field_17
    //     0x614a18: ldur            w2, [x0, #0x17]
    // 0x614a1c: DecompressPointer r2
    //     0x614a1c: add             x2, x2, HEAP, lsl #32
    // 0x614a20: stur            x2, [fp, #-8]
    // 0x614a24: cmp             w1, w2
    // 0x614a28: b.ne            #0x614a3c
    // 0x614a2c: r0 = Null
    //     0x614a2c: mov             x0, NULL
    // 0x614a30: LeaveFrame
    //     0x614a30: mov             SP, fp
    //     0x614a34: ldp             fp, lr, [SP], #0x10
    // 0x614a38: ret
    //     0x614a38: ret             
    // 0x614a3c: cmp             w2, NULL
    // 0x614a40: b.eq            #0x614a7c
    // 0x614a44: r1 = 1
    //     0x614a44: mov             x1, #1
    // 0x614a48: r0 = AllocateContext()
    //     0x614a48: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614a4c: mov             x1, x0
    // 0x614a50: ldr             x0, [fp, #0x10]
    // 0x614a54: StoreField: r1->field_f = r0
    //     0x614a54: stur            w0, [x1, #0xf]
    // 0x614a58: mov             x2, x1
    // 0x614a5c: r1 = Function '_updateTicker@156311458':.
    //     0x614a5c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bc28] AnonymousClosure: (0x614af0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614a60: ldr             x1, [x1, #0xc28]
    // 0x614a64: r0 = AllocateClosure()
    //     0x614a64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614a68: ldur            x16, [fp, #-8]
    // 0x614a6c: stp             x0, x16, [SP, #-0x10]!
    // 0x614a70: r0 = removeListener()
    //     0x614a70: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x614a74: add             SP, SP, #0x10
    // 0x614a78: ldr             x0, [fp, #0x10]
    // 0x614a7c: r1 = 1
    //     0x614a7c: mov             x1, #1
    // 0x614a80: r0 = AllocateContext()
    //     0x614a80: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614a84: mov             x1, x0
    // 0x614a88: ldr             x0, [fp, #0x10]
    // 0x614a8c: StoreField: r1->field_f = r0
    //     0x614a8c: stur            w0, [x1, #0xf]
    // 0x614a90: mov             x2, x1
    // 0x614a94: r1 = Function '_updateTicker@156311458':.
    //     0x614a94: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bc28] AnonymousClosure: (0x614af0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614a98: ldr             x1, [x1, #0xc28]
    // 0x614a9c: r0 = AllocateClosure()
    //     0x614a9c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614aa0: ldur            x16, [fp, #-0x10]
    // 0x614aa4: stp             x0, x16, [SP, #-0x10]!
    // 0x614aa8: r0 = addListener()
    //     0x614aa8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x614aac: add             SP, SP, #0x10
    // 0x614ab0: ldur            x0, [fp, #-0x10]
    // 0x614ab4: ldr             x1, [fp, #0x10]
    // 0x614ab8: StoreField: r1->field_17 = r0
    //     0x614ab8: stur            w0, [x1, #0x17]
    //     0x614abc: ldurb           w16, [x1, #-1]
    //     0x614ac0: ldurb           w17, [x0, #-1]
    //     0x614ac4: and             x16, x17, x16, lsr #2
    //     0x614ac8: tst             x16, HEAP, lsr #32
    //     0x614acc: b.eq            #0x614ad4
    //     0x614ad0: bl              #0xd6826c
    // 0x614ad4: r0 = Null
    //     0x614ad4: mov             x0, NULL
    // 0x614ad8: LeaveFrame
    //     0x614ad8: mov             SP, fp
    //     0x614adc: ldp             fp, lr, [SP], #0x10
    // 0x614ae0: ret
    //     0x614ae0: ret             
    // 0x614ae4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614ae4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614ae8: b               #0x6149ec
    // 0x614aec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x614aec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x614af0, size: 0x48
    // 0x614af0: EnterFrame
    //     0x614af0: stp             fp, lr, [SP, #-0x10]!
    //     0x614af4: mov             fp, SP
    // 0x614af8: ldr             x0, [fp, #0x10]
    // 0x614afc: LoadField: r1 = r0->field_17
    //     0x614afc: ldur            w1, [x0, #0x17]
    // 0x614b00: DecompressPointer r1
    //     0x614b00: add             x1, x1, HEAP, lsl #32
    // 0x614b04: CheckStackOverflow
    //     0x614b04: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614b08: cmp             SP, x16
    //     0x614b0c: b.ls            #0x614b30
    // 0x614b10: LoadField: r0 = r1->field_f
    //     0x614b10: ldur            w0, [x1, #0xf]
    // 0x614b14: DecompressPointer r0
    //     0x614b14: add             x0, x0, HEAP, lsl #32
    // 0x614b18: SaveReg r0
    //     0x614b18: str             x0, [SP, #-8]!
    // 0x614b1c: r0 = _updateTicker()
    //     0x614b1c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614b20: add             SP, SP, #8
    // 0x614b24: LeaveFrame
    //     0x614b24: mov             SP, fp
    //     0x614b28: ldp             fp, lr, [SP], #0x10
    // 0x614b2c: ret
    //     0x614b2c: ret             
    // 0x614b30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614b30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614b34: b               #0x614b10
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f080, size: 0x4c
    // 0x81f080: EnterFrame
    //     0x81f080: stp             fp, lr, [SP, #-0x10]!
    //     0x81f084: mov             fp, SP
    // 0x81f088: CheckStackOverflow
    //     0x81f088: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f08c: cmp             SP, x16
    //     0x81f090: b.ls            #0x81f0c4
    // 0x81f094: ldr             x16, [fp, #0x10]
    // 0x81f098: SaveReg r16
    //     0x81f098: str             x16, [SP, #-8]!
    // 0x81f09c: r0 = _updateTickerModeNotifier()
    //     0x81f09c: bl              #0x6149d4  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionHandleOverlayState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f0a0: add             SP, SP, #8
    // 0x81f0a4: ldr             x16, [fp, #0x10]
    // 0x81f0a8: SaveReg r16
    //     0x81f0a8: str             x16, [SP, #-8]!
    // 0x81f0ac: r0 = _updateTicker()
    //     0x81f0ac: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f0b0: add             SP, SP, #8
    // 0x81f0b4: r0 = Null
    //     0x81f0b4: mov             x0, NULL
    // 0x81f0b8: LeaveFrame
    //     0x81f0b8: mov             SP, fp
    //     0x81f0bc: ldp             fp, lr, [SP], #0x10
    // 0x81f0c0: ret
    //     0x81f0c0: ret             
    // 0x81f0c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f0c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f0c8: b               #0x81f094
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50120, size: 0x8c
    // 0xa50120: EnterFrame
    //     0xa50120: stp             fp, lr, [SP, #-0x10]!
    //     0xa50124: mov             fp, SP
    // 0xa50128: AllocStack(0x8)
    //     0xa50128: sub             SP, SP, #8
    // 0xa5012c: CheckStackOverflow
    //     0xa5012c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50130: cmp             SP, x16
    //     0xa50134: b.ls            #0xa501a4
    // 0xa50138: ldr             x0, [fp, #0x10]
    // 0xa5013c: LoadField: r1 = r0->field_17
    //     0xa5013c: ldur            w1, [x0, #0x17]
    // 0xa50140: DecompressPointer r1
    //     0xa50140: add             x1, x1, HEAP, lsl #32
    // 0xa50144: stur            x1, [fp, #-8]
    // 0xa50148: cmp             w1, NULL
    // 0xa5014c: b.ne            #0xa50158
    // 0xa50150: mov             x1, x0
    // 0xa50154: b               #0xa50190
    // 0xa50158: r1 = 1
    //     0xa50158: mov             x1, #1
    // 0xa5015c: r0 = AllocateContext()
    //     0xa5015c: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50160: mov             x1, x0
    // 0xa50164: ldr             x0, [fp, #0x10]
    // 0xa50168: StoreField: r1->field_f = r0
    //     0xa50168: stur            w0, [x1, #0xf]
    // 0xa5016c: mov             x2, x1
    // 0xa50170: r1 = Function '_updateTicker@156311458':.
    //     0xa50170: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bc28] AnonymousClosure: (0x614af0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa50174: ldr             x1, [x1, #0xc28]
    // 0xa50178: r0 = AllocateClosure()
    //     0xa50178: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa5017c: ldur            x16, [fp, #-8]
    // 0xa50180: stp             x0, x16, [SP, #-0x10]!
    // 0xa50184: r0 = removeListener()
    //     0xa50184: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa50188: add             SP, SP, #0x10
    // 0xa5018c: ldr             x1, [fp, #0x10]
    // 0xa50190: StoreField: r1->field_17 = rNULL
    //     0xa50190: stur            NULL, [x1, #0x17]
    // 0xa50194: r0 = Null
    //     0xa50194: mov             x0, NULL
    // 0xa50198: LeaveFrame
    //     0xa50198: mov             SP, fp
    //     0xa5019c: ldp             fp, lr, [SP], #0x10
    // 0xa501a0: ret
    //     0xa501a0: ret             
    // 0xa501a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa501a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa501a8: b               #0xa50138
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa501ac, size: 0x48
    // 0xa501ac: EnterFrame
    //     0xa501ac: stp             fp, lr, [SP, #-0x10]!
    //     0xa501b0: mov             fp, SP
    // 0xa501b4: ldr             x0, [fp, #0x10]
    // 0xa501b8: LoadField: r1 = r0->field_17
    //     0xa501b8: ldur            w1, [x0, #0x17]
    // 0xa501bc: DecompressPointer r1
    //     0xa501bc: add             x1, x1, HEAP, lsl #32
    // 0xa501c0: CheckStackOverflow
    //     0xa501c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa501c4: cmp             SP, x16
    //     0xa501c8: b.ls            #0xa501ec
    // 0xa501cc: LoadField: r0 = r1->field_f
    //     0xa501cc: ldur            w0, [x1, #0xf]
    // 0xa501d0: DecompressPointer r0
    //     0xa501d0: add             x0, x0, HEAP, lsl #32
    // 0xa501d4: SaveReg r0
    //     0xa501d4: str             x0, [SP, #-8]!
    // 0xa501d8: r0 = dispose()
    //     0xa501d8: bl              #0xa50120  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionHandleOverlayState&State&SingleTickerProviderStateMixin::dispose
    // 0xa501dc: add             SP, SP, #8
    // 0xa501e0: LeaveFrame
    //     0xa501e0: mov             SP, fp
    //     0xa501e4: ldp             fp, lr, [SP], #0x10
    // 0xa501e8: ret
    //     0xa501e8: ret             
    // 0xa501ec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa501ec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa501f0: b               #0xa501cc
  }
}

// class id: 3364, size: 0x20, field offset: 0x1c
class _SelectionHandleOverlayState extends __SelectionHandleOverlayState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7ae928, size: 0x154
    // 0x7ae928: EnterFrame
    //     0x7ae928: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae92c: mov             fp, SP
    // 0x7ae930: AllocStack(0x8)
    //     0x7ae930: sub             SP, SP, #8
    // 0x7ae934: CheckStackOverflow
    //     0x7ae934: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae938: cmp             SP, x16
    //     0x7ae93c: b.ls            #0x7aea70
    // 0x7ae940: ldr             x0, [fp, #0x10]
    // 0x7ae944: r2 = Null
    //     0x7ae944: mov             x2, NULL
    // 0x7ae948: r1 = Null
    //     0x7ae948: mov             x1, NULL
    // 0x7ae94c: r4 = 59
    //     0x7ae94c: mov             x4, #0x3b
    // 0x7ae950: branchIfSmi(r0, 0x7ae95c)
    //     0x7ae950: tbz             w0, #0, #0x7ae95c
    // 0x7ae954: r4 = LoadClassIdInstr(r0)
    //     0x7ae954: ldur            x4, [x0, #-1]
    //     0x7ae958: ubfx            x4, x4, #0xc, #0x14
    // 0x7ae95c: r17 = 4186
    //     0x7ae95c: mov             x17, #0x105a
    // 0x7ae960: cmp             x4, x17
    // 0x7ae964: b.eq            #0x7ae97c
    // 0x7ae968: r8 = _SelectionHandleOverlay
    //     0x7ae968: add             x8, PP, #0x4b, lsl #12  ; [pp+0x4bbf8] Type: _SelectionHandleOverlay
    //     0x7ae96c: ldr             x8, [x8, #0xbf8]
    // 0x7ae970: r3 = Null
    //     0x7ae970: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bc00] Null
    //     0x7ae974: ldr             x3, [x3, #0xc00]
    // 0x7ae978: r0 = _SelectionHandleOverlay()
    //     0x7ae978: bl              #0x6149b0  ; IsType__SelectionHandleOverlay_Stub
    // 0x7ae97c: ldr             x3, [fp, #0x18]
    // 0x7ae980: LoadField: r2 = r3->field_7
    //     0x7ae980: ldur            w2, [x3, #7]
    // 0x7ae984: DecompressPointer r2
    //     0x7ae984: add             x2, x2, HEAP, lsl #32
    // 0x7ae988: ldr             x0, [fp, #0x10]
    // 0x7ae98c: r1 = Null
    //     0x7ae98c: mov             x1, NULL
    // 0x7ae990: cmp             w2, NULL
    // 0x7ae994: b.eq            #0x7ae9b8
    // 0x7ae998: LoadField: r4 = r2->field_17
    //     0x7ae998: ldur            w4, [x2, #0x17]
    // 0x7ae99c: DecompressPointer r4
    //     0x7ae99c: add             x4, x4, HEAP, lsl #32
    // 0x7ae9a0: r8 = X0 bound StatefulWidget
    //     0x7ae9a0: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7ae9a4: ldr             x8, [x8, #0x858]
    // 0x7ae9a8: LoadField: r9 = r4->field_7
    //     0x7ae9a8: ldur            x9, [x4, #7]
    // 0x7ae9ac: r3 = Null
    //     0x7ae9ac: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bc10] Null
    //     0x7ae9b0: ldr             x3, [x3, #0xc10]
    // 0x7ae9b4: blr             x9
    // 0x7ae9b8: ldr             x0, [fp, #0x10]
    // 0x7ae9bc: LoadField: r1 = r0->field_23
    //     0x7ae9bc: ldur            w1, [x0, #0x23]
    // 0x7ae9c0: DecompressPointer r1
    //     0x7ae9c0: add             x1, x1, HEAP, lsl #32
    // 0x7ae9c4: stur            x1, [fp, #-8]
    // 0x7ae9c8: r1 = 1
    //     0x7ae9c8: mov             x1, #1
    // 0x7ae9cc: r0 = AllocateContext()
    //     0x7ae9cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ae9d0: mov             x1, x0
    // 0x7ae9d4: ldr             x0, [fp, #0x18]
    // 0x7ae9d8: StoreField: r1->field_f = r0
    //     0x7ae9d8: stur            w0, [x1, #0xf]
    // 0x7ae9dc: mov             x2, x1
    // 0x7ae9e0: r1 = Function '_handleVisibilityChanged@500251836':.
    //     0x7ae9e0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bbf0] AnonymousClosure: (0x7aeb40), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged (0x7aea7c)
    //     0x7ae9e4: ldr             x1, [x1, #0xbf0]
    // 0x7ae9e8: r0 = AllocateClosure()
    //     0x7ae9e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ae9ec: ldur            x16, [fp, #-8]
    // 0x7ae9f0: stp             x0, x16, [SP, #-0x10]!
    // 0x7ae9f4: r0 = removeListener()
    //     0x7ae9f4: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7ae9f8: add             SP, SP, #0x10
    // 0x7ae9fc: ldr             x16, [fp, #0x18]
    // 0x7aea00: SaveReg r16
    //     0x7aea00: str             x16, [SP, #-8]!
    // 0x7aea04: r0 = _handleVisibilityChanged()
    //     0x7aea04: bl              #0x7aea7c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged
    // 0x7aea08: add             SP, SP, #8
    // 0x7aea0c: ldr             x0, [fp, #0x18]
    // 0x7aea10: LoadField: r1 = r0->field_b
    //     0x7aea10: ldur            w1, [x0, #0xb]
    // 0x7aea14: DecompressPointer r1
    //     0x7aea14: add             x1, x1, HEAP, lsl #32
    // 0x7aea18: cmp             w1, NULL
    // 0x7aea1c: b.eq            #0x7aea78
    // 0x7aea20: LoadField: r2 = r1->field_23
    //     0x7aea20: ldur            w2, [x1, #0x23]
    // 0x7aea24: DecompressPointer r2
    //     0x7aea24: add             x2, x2, HEAP, lsl #32
    // 0x7aea28: stur            x2, [fp, #-8]
    // 0x7aea2c: r1 = 1
    //     0x7aea2c: mov             x1, #1
    // 0x7aea30: r0 = AllocateContext()
    //     0x7aea30: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7aea34: mov             x1, x0
    // 0x7aea38: ldr             x0, [fp, #0x18]
    // 0x7aea3c: StoreField: r1->field_f = r0
    //     0x7aea3c: stur            w0, [x1, #0xf]
    // 0x7aea40: mov             x2, x1
    // 0x7aea44: r1 = Function '_handleVisibilityChanged@500251836':.
    //     0x7aea44: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bbf0] AnonymousClosure: (0x7aeb40), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged (0x7aea7c)
    //     0x7aea48: ldr             x1, [x1, #0xbf0]
    // 0x7aea4c: r0 = AllocateClosure()
    //     0x7aea4c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7aea50: ldur            x16, [fp, #-8]
    // 0x7aea54: stp             x0, x16, [SP, #-0x10]!
    // 0x7aea58: r0 = addListener()
    //     0x7aea58: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7aea5c: add             SP, SP, #0x10
    // 0x7aea60: r0 = Null
    //     0x7aea60: mov             x0, NULL
    // 0x7aea64: LeaveFrame
    //     0x7aea64: mov             SP, fp
    //     0x7aea68: ldp             fp, lr, [SP], #0x10
    // 0x7aea6c: ret
    //     0x7aea6c: ret             
    // 0x7aea70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aea70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aea74: b               #0x7ae940
    // 0x7aea78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7aea78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleVisibilityChanged(/* No info */) {
    // ** addr: 0x7aea7c, size: 0xc4
    // 0x7aea7c: EnterFrame
    //     0x7aea7c: stp             fp, lr, [SP, #-0x10]!
    //     0x7aea80: mov             fp, SP
    // 0x7aea84: CheckStackOverflow
    //     0x7aea84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aea88: cmp             SP, x16
    //     0x7aea8c: b.ls            #0x7aeb1c
    // 0x7aea90: ldr             x0, [fp, #0x10]
    // 0x7aea94: LoadField: r1 = r0->field_b
    //     0x7aea94: ldur            w1, [x0, #0xb]
    // 0x7aea98: DecompressPointer r1
    //     0x7aea98: add             x1, x1, HEAP, lsl #32
    // 0x7aea9c: cmp             w1, NULL
    // 0x7aeaa0: b.eq            #0x7aeb24
    // 0x7aeaa4: LoadField: r2 = r1->field_23
    //     0x7aeaa4: ldur            w2, [x1, #0x23]
    // 0x7aeaa8: DecompressPointer r2
    //     0x7aeaa8: add             x2, x2, HEAP, lsl #32
    // 0x7aeaac: LoadField: r1 = r2->field_27
    //     0x7aeaac: ldur            w1, [x2, #0x27]
    // 0x7aeab0: DecompressPointer r1
    //     0x7aeab0: add             x1, x1, HEAP, lsl #32
    // 0x7aeab4: r16 = true
    //     0x7aeab4: add             x16, NULL, #0x20  ; true
    // 0x7aeab8: cmp             w1, w16
    // 0x7aeabc: b.ne            #0x7aeae8
    // 0x7aeac0: LoadField: r1 = r0->field_1b
    //     0x7aeac0: ldur            w1, [x0, #0x1b]
    // 0x7aeac4: DecompressPointer r1
    //     0x7aeac4: add             x1, x1, HEAP, lsl #32
    // 0x7aeac8: r16 = Sentinel
    //     0x7aeac8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7aeacc: cmp             w1, w16
    // 0x7aead0: b.eq            #0x7aeb28
    // 0x7aead4: SaveReg r1
    //     0x7aead4: str             x1, [SP, #-8]!
    // 0x7aead8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7aead8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7aeadc: r0 = forward()
    //     0x7aeadc: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7aeae0: add             SP, SP, #8
    // 0x7aeae4: b               #0x7aeb0c
    // 0x7aeae8: LoadField: r1 = r0->field_1b
    //     0x7aeae8: ldur            w1, [x0, #0x1b]
    // 0x7aeaec: DecompressPointer r1
    //     0x7aeaec: add             x1, x1, HEAP, lsl #32
    // 0x7aeaf0: r16 = Sentinel
    //     0x7aeaf0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7aeaf4: cmp             w1, w16
    // 0x7aeaf8: b.eq            #0x7aeb34
    // 0x7aeafc: SaveReg r1
    //     0x7aeafc: str             x1, [SP, #-8]!
    // 0x7aeb00: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7aeb00: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7aeb04: r0 = reverse()
    //     0x7aeb04: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x7aeb08: add             SP, SP, #8
    // 0x7aeb0c: r0 = Null
    //     0x7aeb0c: mov             x0, NULL
    // 0x7aeb10: LeaveFrame
    //     0x7aeb10: mov             SP, fp
    //     0x7aeb14: ldp             fp, lr, [SP], #0x10
    // 0x7aeb18: ret
    //     0x7aeb18: ret             
    // 0x7aeb1c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aeb1c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aeb20: b               #0x7aea90
    // 0x7aeb24: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7aeb24: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7aeb28: r9 = _controller
    //     0x7aeb28: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bbe8] Field <_SelectionHandleOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0x7aeb2c: ldr             x9, [x9, #0xbe8]
    // 0x7aeb30: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7aeb30: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7aeb34: r9 = _controller
    //     0x7aeb34: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bbe8] Field <_SelectionHandleOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0x7aeb38: ldr             x9, [x9, #0xbe8]
    // 0x7aeb3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7aeb3c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleVisibilityChanged(dynamic) {
    // ** addr: 0x7aeb40, size: 0x48
    // 0x7aeb40: EnterFrame
    //     0x7aeb40: stp             fp, lr, [SP, #-0x10]!
    //     0x7aeb44: mov             fp, SP
    // 0x7aeb48: ldr             x0, [fp, #0x10]
    // 0x7aeb4c: LoadField: r1 = r0->field_17
    //     0x7aeb4c: ldur            w1, [x0, #0x17]
    // 0x7aeb50: DecompressPointer r1
    //     0x7aeb50: add             x1, x1, HEAP, lsl #32
    // 0x7aeb54: CheckStackOverflow
    //     0x7aeb54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7aeb58: cmp             SP, x16
    //     0x7aeb5c: b.ls            #0x7aeb80
    // 0x7aeb60: LoadField: r0 = r1->field_f
    //     0x7aeb60: ldur            w0, [x1, #0xf]
    // 0x7aeb64: DecompressPointer r0
    //     0x7aeb64: add             x0, x0, HEAP, lsl #32
    // 0x7aeb68: SaveReg r0
    //     0x7aeb68: str             x0, [SP, #-8]!
    // 0x7aeb6c: r0 = _handleVisibilityChanged()
    //     0x7aeb6c: bl              #0x7aea7c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged
    // 0x7aeb70: add             SP, SP, #8
    // 0x7aeb74: LeaveFrame
    //     0x7aeb74: mov             SP, fp
    //     0x7aeb78: ldp             fp, lr, [SP], #0x10
    // 0x7aeb7c: ret
    //     0x7aeb7c: ret             
    // 0x7aeb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7aeb80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7aeb84: b               #0x7aeb60
  }
  _ build(/* No info */) {
    // ** addr: 0x83eef0, size: 0x560
    // 0x83eef0: EnterFrame
    //     0x83eef0: stp             fp, lr, [SP, #-0x10]!
    //     0x83eef4: mov             fp, SP
    // 0x83eef8: AllocStack(0x80)
    //     0x83eef8: sub             SP, SP, #0x80
    // 0x83eefc: CheckStackOverflow
    //     0x83eefc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83ef00: cmp             SP, x16
    //     0x83ef04: b.ls            #0x83f40c
    // 0x83ef08: ldr             x1, [fp, #0x18]
    // 0x83ef0c: LoadField: r0 = r1->field_b
    //     0x83ef0c: ldur            w0, [x1, #0xb]
    // 0x83ef10: DecompressPointer r0
    //     0x83ef10: add             x0, x0, HEAP, lsl #32
    // 0x83ef14: cmp             w0, NULL
    // 0x83ef18: b.eq            #0x83f414
    // 0x83ef1c: LoadField: r2 = r0->field_1f
    //     0x83ef1c: ldur            w2, [x0, #0x1f]
    // 0x83ef20: DecompressPointer r2
    //     0x83ef20: add             x2, x2, HEAP, lsl #32
    // 0x83ef24: LoadField: r3 = r0->field_2f
    //     0x83ef24: ldur            w3, [x0, #0x2f]
    // 0x83ef28: DecompressPointer r3
    //     0x83ef28: add             x3, x3, HEAP, lsl #32
    // 0x83ef2c: LoadField: d0 = r0->field_27
    //     0x83ef2c: ldur            d0, [x0, #0x27]
    // 0x83ef30: r0 = LoadClassIdInstr(r2)
    //     0x83ef30: ldur            x0, [x2, #-1]
    //     0x83ef34: ubfx            x0, x0, #0xc, #0x14
    // 0x83ef38: stp             x3, x2, [SP, #-0x10]!
    // 0x83ef3c: SaveReg d0
    //     0x83ef3c: str             d0, [SP, #-8]!
    // 0x83ef40: r0 = GDT[cid_x0 + 0x886]()
    //     0x83ef40: add             lr, x0, #0x886
    //     0x83ef44: ldr             lr, [x21, lr, lsl #3]
    //     0x83ef48: blr             lr
    // 0x83ef4c: add             SP, SP, #0x18
    // 0x83ef50: mov             x2, x0
    // 0x83ef54: ldr             x1, [fp, #0x18]
    // 0x83ef58: stur            x2, [fp, #-8]
    // 0x83ef5c: LoadField: r0 = r1->field_b
    //     0x83ef5c: ldur            w0, [x1, #0xb]
    // 0x83ef60: DecompressPointer r0
    //     0x83ef60: add             x0, x0, HEAP, lsl #32
    // 0x83ef64: cmp             w0, NULL
    // 0x83ef68: b.eq            #0x83f418
    // 0x83ef6c: LoadField: r3 = r0->field_1f
    //     0x83ef6c: ldur            w3, [x0, #0x1f]
    // 0x83ef70: DecompressPointer r3
    //     0x83ef70: add             x3, x3, HEAP, lsl #32
    // 0x83ef74: LoadField: d0 = r0->field_27
    //     0x83ef74: ldur            d0, [x0, #0x27]
    // 0x83ef78: r0 = LoadClassIdInstr(r3)
    //     0x83ef78: ldur            x0, [x3, #-1]
    //     0x83ef7c: ubfx            x0, x0, #0xc, #0x14
    // 0x83ef80: SaveReg r3
    //     0x83ef80: str             x3, [SP, #-8]!
    // 0x83ef84: SaveReg d0
    //     0x83ef84: str             d0, [SP, #-8]!
    // 0x83ef88: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x83ef88: sub             lr, x0, #0xfd3
    //     0x83ef8c: ldr             lr, [x21, lr, lsl #3]
    //     0x83ef90: blr             lr
    // 0x83ef94: add             SP, SP, #0x10
    // 0x83ef98: mov             x1, x0
    // 0x83ef9c: ldur            x0, [fp, #-8]
    // 0x83efa0: LoadField: d0 = r0->field_7
    //     0x83efa0: ldur            d0, [x0, #7]
    // 0x83efa4: fneg            d1, d0
    // 0x83efa8: stur            d1, [fp, #-0x60]
    // 0x83efac: LoadField: d0 = r0->field_f
    //     0x83efac: ldur            d0, [x0, #0xf]
    // 0x83efb0: fneg            d2, d0
    // 0x83efb4: stur            d2, [fp, #-0x58]
    // 0x83efb8: LoadField: d0 = r1->field_7
    //     0x83efb8: ldur            d0, [x1, #7]
    // 0x83efbc: LoadField: d3 = r1->field_f
    //     0x83efbc: ldur            d3, [x1, #0xf]
    // 0x83efc0: fadd            d4, d1, d0
    // 0x83efc4: stur            d4, [fp, #-0x50]
    // 0x83efc8: fadd            d0, d2, d3
    // 0x83efcc: stur            d0, [fp, #-0x48]
    // 0x83efd0: r0 = Rect()
    //     0x83efd0: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x83efd4: ldur            d0, [fp, #-0x60]
    // 0x83efd8: stur            x0, [fp, #-8]
    // 0x83efdc: StoreField: r0->field_7 = d0
    //     0x83efdc: stur            d0, [x0, #7]
    // 0x83efe0: ldur            d1, [fp, #-0x58]
    // 0x83efe4: StoreField: r0->field_f = d1
    //     0x83efe4: stur            d1, [x0, #0xf]
    // 0x83efe8: ldur            d2, [fp, #-0x50]
    // 0x83efec: StoreField: r0->field_17 = d2
    //     0x83efec: stur            d2, [x0, #0x17]
    // 0x83eff0: ldur            d3, [fp, #-0x48]
    // 0x83eff4: StoreField: r0->field_1f = d3
    //     0x83eff4: stur            d3, [x0, #0x1f]
    // 0x83eff8: SaveReg r0
    //     0x83eff8: str             x0, [SP, #-8]!
    // 0x83effc: r0 = center()
    //     0x83effc: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0x83f000: add             SP, SP, #8
    // 0x83f004: stur            x0, [fp, #-0x10]
    // 0x83f008: r0 = Rect()
    //     0x83f008: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0x83f00c: stur            x0, [fp, #-0x18]
    // 0x83f010: ldur            x16, [fp, #-0x10]
    // 0x83f014: stp             x16, x0, [SP, #-0x10]!
    // 0x83f018: r16 = 48.000000
    //     0x83f018: add             x16, PP, #0x26, lsl #12  ; [pp+0x268e8] 48
    //     0x83f01c: ldr             x16, [x16, #0x8e8]
    // 0x83f020: SaveReg r16
    //     0x83f020: str             x16, [SP, #-8]!
    // 0x83f024: d0 = 48.000000
    //     0x83f024: add             x17, PP, #0x1f, lsl #12  ; [pp+0x1fbd0] IMM: double(48) from 0x4048000000000000
    //     0x83f028: ldr             d0, [x17, #0xbd0]
    // 0x83f02c: SaveReg d0
    //     0x83f02c: str             d0, [SP, #-8]!
    // 0x83f030: r0 = Rect.fromCenter()
    //     0x83f030: bl              #0x51a138  ; [dart:ui] Rect::Rect.fromCenter
    // 0x83f034: add             SP, SP, #0x20
    // 0x83f038: ldur            x16, [fp, #-8]
    // 0x83f03c: ldur            lr, [fp, #-0x18]
    // 0x83f040: stp             lr, x16, [SP, #-0x10]!
    // 0x83f044: r0 = expandToInclude()
    //     0x83f044: bl              #0x5251a0  ; [dart:ui] Rect::expandToInclude
    // 0x83f048: add             SP, SP, #0x10
    // 0x83f04c: LoadField: d0 = r0->field_17
    //     0x83f04c: ldur            d0, [x0, #0x17]
    // 0x83f050: LoadField: d1 = r0->field_7
    //     0x83f050: ldur            d1, [x0, #7]
    // 0x83f054: stur            d1, [fp, #-0x80]
    // 0x83f058: fsub            d2, d0, d1
    // 0x83f05c: ldur            d0, [fp, #-0x60]
    // 0x83f060: ldur            d3, [fp, #-0x50]
    // 0x83f064: stur            d2, [fp, #-0x78]
    // 0x83f068: fsub            d4, d3, d0
    // 0x83f06c: fsub            d0, d2, d4
    // 0x83f070: d3 = 2.000000
    //     0x83f070: fmov            d3, #2.00000000
    // 0x83f074: fdiv            d4, d0, d3
    // 0x83f078: d0 = 0.000000
    //     0x83f078: eor             v0.16b, v0.16b, v0.16b
    // 0x83f07c: fcmp            d4, d0
    // 0x83f080: b.vs            #0x83f088
    // 0x83f084: b.gt            #0x83f090
    // 0x83f088: r1 = false
    //     0x83f088: add             x1, NULL, #0x30  ; false
    // 0x83f08c: b               #0x83f094
    // 0x83f090: r1 = true
    //     0x83f090: add             x1, NULL, #0x20  ; true
    // 0x83f094: tbnz            w1, #4, #0x83f0a0
    // 0x83f098: mov             v7.16b, v4.16b
    // 0x83f09c: b               #0x83f0d0
    // 0x83f0a0: fcmp            d4, d0
    // 0x83f0a4: b.vs            #0x83f0b4
    // 0x83f0a8: b.ge            #0x83f0b4
    // 0x83f0ac: d7 = 0.000000
    //     0x83f0ac: eor             v7.16b, v7.16b, v7.16b
    // 0x83f0b0: b               #0x83f0d0
    // 0x83f0b4: fcmp            d4, d0
    // 0x83f0b8: b.vs            #0x83f0cc
    // 0x83f0bc: b.ne            #0x83f0cc
    // 0x83f0c0: fadd            d5, d4, d0
    // 0x83f0c4: mov             v7.16b, v5.16b
    // 0x83f0c8: b               #0x83f0d0
    // 0x83f0cc: mov             v7.16b, v4.16b
    // 0x83f0d0: ldur            d5, [fp, #-0x58]
    // 0x83f0d4: ldur            d6, [fp, #-0x48]
    // 0x83f0d8: stur            d7, [fp, #-0x70]
    // 0x83f0dc: LoadField: d8 = r0->field_1f
    //     0x83f0dc: ldur            d8, [x0, #0x1f]
    // 0x83f0e0: LoadField: d9 = r0->field_f
    //     0x83f0e0: ldur            d9, [x0, #0xf]
    // 0x83f0e4: stur            d9, [fp, #-0x68]
    // 0x83f0e8: fsub            d10, d8, d9
    // 0x83f0ec: stur            d10, [fp, #-0x60]
    // 0x83f0f0: fsub            d8, d6, d5
    // 0x83f0f4: fsub            d5, d10, d8
    // 0x83f0f8: fdiv            d6, d5, d3
    // 0x83f0fc: fcmp            d6, d0
    // 0x83f100: b.vs            #0x83f108
    // 0x83f104: b.gt            #0x83f110
    // 0x83f108: r0 = false
    //     0x83f108: add             x0, NULL, #0x30  ; false
    // 0x83f10c: b               #0x83f114
    // 0x83f110: r0 = true
    //     0x83f110: add             x0, NULL, #0x20  ; true
    // 0x83f114: tbnz            w0, #4, #0x83f120
    // 0x83f118: mov             v3.16b, v6.16b
    // 0x83f11c: b               #0x83f14c
    // 0x83f120: fcmp            d6, d0
    // 0x83f124: b.vs            #0x83f134
    // 0x83f128: b.ge            #0x83f134
    // 0x83f12c: d3 = 0.000000
    //     0x83f12c: eor             v3.16b, v3.16b, v3.16b
    // 0x83f130: b               #0x83f14c
    // 0x83f134: fcmp            d6, d0
    // 0x83f138: b.vs            #0x83f148
    // 0x83f13c: b.ne            #0x83f148
    // 0x83f140: fadd            d3, d6, d0
    // 0x83f144: b               #0x83f14c
    // 0x83f148: mov             v3.16b, v6.16b
    // 0x83f14c: stur            d3, [fp, #-0x58]
    // 0x83f150: tbz             w1, #4, #0x83f17c
    // 0x83f154: fcmp            d4, d0
    // 0x83f158: b.vs            #0x83f168
    // 0x83f15c: b.ge            #0x83f168
    // 0x83f160: d4 = 0.000000
    //     0x83f160: eor             v4.16b, v4.16b, v4.16b
    // 0x83f164: b               #0x83f17c
    // 0x83f168: fcmp            d4, d0
    // 0x83f16c: b.vs            #0x83f17c
    // 0x83f170: b.ne            #0x83f17c
    // 0x83f174: fadd            d5, d4, d0
    // 0x83f178: mov             v4.16b, v5.16b
    // 0x83f17c: stur            d4, [fp, #-0x50]
    // 0x83f180: tbnz            w0, #4, #0x83f18c
    // 0x83f184: mov             v0.16b, v6.16b
    // 0x83f188: b               #0x83f1bc
    // 0x83f18c: fcmp            d6, d0
    // 0x83f190: b.vs            #0x83f1a0
    // 0x83f194: b.ge            #0x83f1a0
    // 0x83f198: d0 = 0.000000
    //     0x83f198: eor             v0.16b, v0.16b, v0.16b
    // 0x83f19c: b               #0x83f1bc
    // 0x83f1a0: fcmp            d6, d0
    // 0x83f1a4: b.vs            #0x83f1b8
    // 0x83f1a8: b.ne            #0x83f1b8
    // 0x83f1ac: fadd            d5, d6, d0
    // 0x83f1b0: mov             v0.16b, v5.16b
    // 0x83f1b4: b               #0x83f1bc
    // 0x83f1b8: mov             v0.16b, v6.16b
    // 0x83f1bc: ldr             x0, [fp, #0x18]
    // 0x83f1c0: stur            d0, [fp, #-0x48]
    // 0x83f1c4: LoadField: r1 = r0->field_b
    //     0x83f1c4: ldur            w1, [x0, #0xb]
    // 0x83f1c8: DecompressPointer r1
    //     0x83f1c8: add             x1, x1, HEAP, lsl #32
    // 0x83f1cc: cmp             w1, NULL
    // 0x83f1d0: b.eq            #0x83f41c
    // 0x83f1d4: LoadField: r2 = r1->field_b
    //     0x83f1d4: ldur            w2, [x1, #0xb]
    // 0x83f1d8: DecompressPointer r2
    //     0x83f1d8: add             x2, x2, HEAP, lsl #32
    // 0x83f1dc: stur            x2, [fp, #-8]
    // 0x83f1e0: r0 = Offset()
    //     0x83f1e0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x83f1e4: ldur            d0, [fp, #-0x80]
    // 0x83f1e8: stur            x0, [fp, #-0x10]
    // 0x83f1ec: StoreField: r0->field_7 = d0
    //     0x83f1ec: stur            d0, [x0, #7]
    // 0x83f1f0: ldur            d0, [fp, #-0x68]
    // 0x83f1f4: StoreField: r0->field_f = d0
    //     0x83f1f4: stur            d0, [x0, #0xf]
    // 0x83f1f8: ldr             x16, [fp, #0x18]
    // 0x83f1fc: SaveReg r16
    //     0x83f1fc: str             x16, [SP, #-8]!
    // 0x83f200: r0 = _opacity()
    //     0x83f200: bl              #0x83f450  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_opacity
    // 0x83f204: add             SP, SP, #8
    // 0x83f208: mov             x1, x0
    // 0x83f20c: ldr             x0, [fp, #0x18]
    // 0x83f210: stur            x1, [fp, #-0x30]
    // 0x83f214: LoadField: r2 = r0->field_b
    //     0x83f214: ldur            w2, [x0, #0xb]
    // 0x83f218: DecompressPointer r2
    //     0x83f218: add             x2, x2, HEAP, lsl #32
    // 0x83f21c: stur            x2, [fp, #-0x28]
    // 0x83f220: cmp             w2, NULL
    // 0x83f224: b.eq            #0x83f420
    // 0x83f228: LoadField: r0 = r2->field_13
    //     0x83f228: ldur            w0, [x2, #0x13]
    // 0x83f22c: DecompressPointer r0
    //     0x83f22c: add             x0, x0, HEAP, lsl #32
    // 0x83f230: stur            x0, [fp, #-0x20]
    // 0x83f234: LoadField: r3 = r2->field_17
    //     0x83f234: ldur            w3, [x2, #0x17]
    // 0x83f238: DecompressPointer r3
    //     0x83f238: add             x3, x3, HEAP, lsl #32
    // 0x83f23c: stur            x3, [fp, #-0x18]
    // 0x83f240: r0 = EdgeInsets()
    //     0x83f240: bl              #0x5189e8  ; AllocateEdgeInsetsStub -> EdgeInsets (size=0x28)
    // 0x83f244: mov             x1, x0
    // 0x83f248: ldur            d0, [fp, #-0x70]
    // 0x83f24c: stur            x1, [fp, #-0x38]
    // 0x83f250: StoreField: r1->field_7 = d0
    //     0x83f250: stur            d0, [x1, #7]
    // 0x83f254: ldur            d0, [fp, #-0x58]
    // 0x83f258: StoreField: r1->field_f = d0
    //     0x83f258: stur            d0, [x1, #0xf]
    // 0x83f25c: ldur            d0, [fp, #-0x50]
    // 0x83f260: StoreField: r1->field_17 = d0
    //     0x83f260: stur            d0, [x1, #0x17]
    // 0x83f264: ldur            d0, [fp, #-0x48]
    // 0x83f268: StoreField: r1->field_1f = d0
    //     0x83f268: stur            d0, [x1, #0x1f]
    // 0x83f26c: ldur            x0, [fp, #-0x28]
    // 0x83f270: LoadField: r2 = r0->field_1f
    //     0x83f270: ldur            w2, [x0, #0x1f]
    // 0x83f274: DecompressPointer r2
    //     0x83f274: add             x2, x2, HEAP, lsl #32
    // 0x83f278: LoadField: r3 = r0->field_2f
    //     0x83f278: ldur            w3, [x0, #0x2f]
    // 0x83f27c: DecompressPointer r3
    //     0x83f27c: add             x3, x3, HEAP, lsl #32
    // 0x83f280: LoadField: d0 = r0->field_27
    //     0x83f280: ldur            d0, [x0, #0x27]
    // 0x83f284: LoadField: r4 = r0->field_f
    //     0x83f284: ldur            w4, [x0, #0xf]
    // 0x83f288: DecompressPointer r4
    //     0x83f288: add             x4, x4, HEAP, lsl #32
    // 0x83f28c: r0 = LoadClassIdInstr(r2)
    //     0x83f28c: ldur            x0, [x2, #-1]
    //     0x83f290: ubfx            x0, x0, #0xc, #0x14
    // 0x83f294: ldr             x16, [fp, #0x10]
    // 0x83f298: stp             x16, x2, [SP, #-0x10]!
    // 0x83f29c: SaveReg r3
    //     0x83f29c: str             x3, [SP, #-8]!
    // 0x83f2a0: SaveReg d0
    //     0x83f2a0: str             d0, [SP, #-8]!
    // 0x83f2a4: SaveReg r4
    //     0x83f2a4: str             x4, [SP, #-8]!
    // 0x83f2a8: r0 = GDT[cid_x0 + 0xb1f]()
    //     0x83f2a8: add             lr, x0, #0xb1f
    //     0x83f2ac: ldr             lr, [x21, lr, lsl #3]
    //     0x83f2b0: blr             lr
    // 0x83f2b4: add             SP, SP, #0x28
    // 0x83f2b8: stur            x0, [fp, #-0x28]
    // 0x83f2bc: r0 = Padding()
    //     0x83f2bc: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x83f2c0: mov             x1, x0
    // 0x83f2c4: ldur            x0, [fp, #-0x38]
    // 0x83f2c8: stur            x1, [fp, #-0x40]
    // 0x83f2cc: StoreField: r1->field_f = r0
    //     0x83f2cc: stur            w0, [x1, #0xf]
    // 0x83f2d0: ldur            x0, [fp, #-0x28]
    // 0x83f2d4: StoreField: r1->field_b = r0
    //     0x83f2d4: stur            w0, [x1, #0xb]
    // 0x83f2d8: r0 = GestureDetector()
    //     0x83f2d8: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x83f2dc: stur            x0, [fp, #-0x28]
    // 0x83f2e0: r16 = Instance_HitTestBehavior
    //     0x83f2e0: add             x16, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x83f2e4: ldr             x16, [x16, #0xed0]
    // 0x83f2e8: stp             x16, x0, [SP, #-0x10]!
    // 0x83f2ec: ldur            x16, [fp, #-0x20]
    // 0x83f2f0: ldur            lr, [fp, #-0x18]
    // 0x83f2f4: stp             lr, x16, [SP, #-0x10]!
    // 0x83f2f8: ldur            x16, [fp, #-0x40]
    // 0x83f2fc: stp             x16, NULL, [SP, #-0x10]!
    // 0x83f300: r4 = const [0, 0x6, 0x6, 0x1, behavior, 0x1, child, 0x5, onPanEnd, 0x4, onPanStart, 0x2, onPanUpdate, 0x3, null]
    //     0x83f300: add             x4, PP, #0x4b, lsl #12  ; [pp+0x4bbe0] List(15) [0, 0x6, 0x6, 0x1, "behavior", 0x1, "child", 0x5, "onPanEnd", 0x4, "onPanStart", 0x2, "onPanUpdate", 0x3, Null]
    //     0x83f304: ldr             x4, [x4, #0xbe0]
    // 0x83f308: r0 = GestureDetector()
    //     0x83f308: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x83f30c: add             SP, SP, #0x30
    // 0x83f310: ldur            d0, [fp, #-0x78]
    // 0x83f314: r0 = inline_Allocate_Double()
    //     0x83f314: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x83f318: add             x0, x0, #0x10
    //     0x83f31c: cmp             x1, x0
    //     0x83f320: b.ls            #0x83f424
    //     0x83f324: str             x0, [THR, #0x60]  ; THR::top
    //     0x83f328: sub             x0, x0, #0xf
    //     0x83f32c: mov             x1, #0xd108
    //     0x83f330: movk            x1, #3, lsl #16
    //     0x83f334: stur            x1, [x0, #-1]
    // 0x83f338: StoreField: r0->field_7 = d0
    //     0x83f338: stur            d0, [x0, #7]
    // 0x83f33c: ldur            d0, [fp, #-0x60]
    // 0x83f340: stur            x0, [fp, #-0x20]
    // 0x83f344: r1 = inline_Allocate_Double()
    //     0x83f344: ldp             x1, x2, [THR, #0x60]  ; THR::top
    //     0x83f348: add             x1, x1, #0x10
    //     0x83f34c: cmp             x2, x1
    //     0x83f350: b.ls            #0x83f434
    //     0x83f354: str             x1, [THR, #0x60]  ; THR::top
    //     0x83f358: sub             x1, x1, #0xf
    //     0x83f35c: mov             x2, #0xd108
    //     0x83f360: movk            x2, #3, lsl #16
    //     0x83f364: stur            x2, [x1, #-1]
    // 0x83f368: StoreField: r1->field_7 = d0
    //     0x83f368: stur            d0, [x1, #7]
    // 0x83f36c: stur            x1, [fp, #-0x18]
    // 0x83f370: r0 = Container()
    //     0x83f370: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x83f374: stur            x0, [fp, #-0x38]
    // 0x83f378: r16 = Instance_Alignment
    //     0x83f378: add             x16, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x83f37c: ldr             x16, [x16, #0xbd0]
    // 0x83f380: stp             x16, x0, [SP, #-0x10]!
    // 0x83f384: ldur            x16, [fp, #-0x20]
    // 0x83f388: ldur            lr, [fp, #-0x18]
    // 0x83f38c: stp             lr, x16, [SP, #-0x10]!
    // 0x83f390: ldur            x16, [fp, #-0x28]
    // 0x83f394: SaveReg r16
    //     0x83f394: str             x16, [SP, #-8]!
    // 0x83f398: r4 = const [0, 0x5, 0x5, 0x1, alignment, 0x1, child, 0x4, height, 0x3, width, 0x2, null]
    //     0x83f398: add             x4, PP, #0x23, lsl #12  ; [pp+0x238d8] List(13) [0, 0x5, 0x5, 0x1, "alignment", 0x1, "child", 0x4, "height", 0x3, "width", 0x2, Null]
    //     0x83f39c: ldr             x4, [x4, #0x8d8]
    // 0x83f3a0: r0 = Container()
    //     0x83f3a0: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x83f3a4: add             SP, SP, #0x28
    // 0x83f3a8: r0 = FadeTransition()
    //     0x83f3a8: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x83f3ac: mov             x1, x0
    // 0x83f3b0: ldur            x0, [fp, #-0x30]
    // 0x83f3b4: stur            x1, [fp, #-0x18]
    // 0x83f3b8: StoreField: r1->field_f = r0
    //     0x83f3b8: stur            w0, [x1, #0xf]
    // 0x83f3bc: r0 = false
    //     0x83f3bc: add             x0, NULL, #0x30  ; false
    // 0x83f3c0: StoreField: r1->field_13 = r0
    //     0x83f3c0: stur            w0, [x1, #0x13]
    // 0x83f3c4: ldur            x2, [fp, #-0x38]
    // 0x83f3c8: StoreField: r1->field_b = r2
    //     0x83f3c8: stur            w2, [x1, #0xb]
    // 0x83f3cc: r0 = CompositedTransformFollower()
    //     0x83f3cc: bl              #0x6efd60  ; AllocateCompositedTransformFollowerStub -> CompositedTransformFollower (size=0x24)
    // 0x83f3d0: ldur            x1, [fp, #-8]
    // 0x83f3d4: StoreField: r0->field_f = r1
    //     0x83f3d4: stur            w1, [x0, #0xf]
    // 0x83f3d8: r1 = false
    //     0x83f3d8: add             x1, NULL, #0x30  ; false
    // 0x83f3dc: StoreField: r0->field_13 = r1
    //     0x83f3dc: stur            w1, [x0, #0x13]
    // 0x83f3e0: ldur            x1, [fp, #-0x10]
    // 0x83f3e4: StoreField: r0->field_1f = r1
    //     0x83f3e4: stur            w1, [x0, #0x1f]
    // 0x83f3e8: r1 = Instance_Alignment
    //     0x83f3e8: add             x1, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x83f3ec: ldr             x1, [x1, #0xbd0]
    // 0x83f3f0: StoreField: r0->field_17 = r1
    //     0x83f3f0: stur            w1, [x0, #0x17]
    // 0x83f3f4: StoreField: r0->field_1b = r1
    //     0x83f3f4: stur            w1, [x0, #0x1b]
    // 0x83f3f8: ldur            x1, [fp, #-0x18]
    // 0x83f3fc: StoreField: r0->field_b = r1
    //     0x83f3fc: stur            w1, [x0, #0xb]
    // 0x83f400: LeaveFrame
    //     0x83f400: mov             SP, fp
    //     0x83f404: ldp             fp, lr, [SP], #0x10
    // 0x83f408: ret
    //     0x83f408: ret             
    // 0x83f40c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83f40c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83f410: b               #0x83ef08
    // 0x83f414: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83f414: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83f418: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83f418: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83f41c: r0 = NullCastErrorSharedWithFPURegs()
    //     0x83f41c: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0x83f420: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83f420: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83f424: SaveReg d0
    //     0x83f424: str             q0, [SP, #-0x10]!
    // 0x83f428: r0 = AllocateDouble()
    //     0x83f428: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x83f42c: RestoreReg d0
    //     0x83f42c: ldr             q0, [SP], #0x10
    // 0x83f430: b               #0x83f338
    // 0x83f434: SaveReg d0
    //     0x83f434: str             q0, [SP, #-0x10]!
    // 0x83f438: SaveReg r0
    //     0x83f438: str             x0, [SP, #-8]!
    // 0x83f43c: r0 = AllocateDouble()
    //     0x83f43c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x83f440: mov             x1, x0
    // 0x83f444: RestoreReg r0
    //     0x83f444: ldr             x0, [SP], #8
    // 0x83f448: RestoreReg d0
    //     0x83f448: ldr             q0, [SP], #0x10
    // 0x83f44c: b               #0x83f368
  }
  get _ _opacity(/* No info */) {
    // ** addr: 0x83f450, size: 0x38
    // 0x83f450: EnterFrame
    //     0x83f450: stp             fp, lr, [SP, #-0x10]!
    //     0x83f454: mov             fp, SP
    // 0x83f458: ldr             x1, [fp, #0x10]
    // 0x83f45c: LoadField: r0 = r1->field_1b
    //     0x83f45c: ldur            w0, [x1, #0x1b]
    // 0x83f460: DecompressPointer r0
    //     0x83f460: add             x0, x0, HEAP, lsl #32
    // 0x83f464: r16 = Sentinel
    //     0x83f464: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x83f468: cmp             w0, w16
    // 0x83f46c: b.eq            #0x83f47c
    // 0x83f470: LeaveFrame
    //     0x83f470: mov             SP, fp
    //     0x83f474: ldp             fp, lr, [SP], #0x10
    // 0x83f478: ret
    //     0x83f478: ret             
    // 0x83f47c: r9 = _controller
    //     0x83f47c: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bbe8] Field <_SelectionHandleOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0x83f480: ldr             x9, [x9, #0xbe8]
    // 0x83f484: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83f484: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d73ac, size: 0xe8
    // 0x9d73ac: EnterFrame
    //     0x9d73ac: stp             fp, lr, [SP, #-0x10]!
    //     0x9d73b0: mov             fp, SP
    // 0x9d73b4: AllocStack(0x8)
    //     0x9d73b4: sub             SP, SP, #8
    // 0x9d73b8: CheckStackOverflow
    //     0x9d73b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d73bc: cmp             SP, x16
    //     0x9d73c0: b.ls            #0x9d7488
    // 0x9d73c4: r1 = <double>
    //     0x9d73c4: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d73c8: r0 = AnimationController()
    //     0x9d73c8: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d73cc: stur            x0, [fp, #-8]
    // 0x9d73d0: ldr             x16, [fp, #0x10]
    // 0x9d73d4: stp             x16, x0, [SP, #-0x10]!
    // 0x9d73d8: r16 = Instance_Duration
    //     0x9d73d8: add             x16, PP, #0x20, lsl #12  ; [pp+0x20968] Obj!Duration@b67b41
    //     0x9d73dc: ldr             x16, [x16, #0x968]
    // 0x9d73e0: SaveReg r16
    //     0x9d73e0: str             x16, [SP, #-8]!
    // 0x9d73e4: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d73e4: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d73e8: ldr             x4, [x4, #0xa0]
    // 0x9d73ec: r0 = AnimationController()
    //     0x9d73ec: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d73f0: add             SP, SP, #0x18
    // 0x9d73f4: ldur            x0, [fp, #-8]
    // 0x9d73f8: ldr             x1, [fp, #0x10]
    // 0x9d73fc: StoreField: r1->field_1b = r0
    //     0x9d73fc: stur            w0, [x1, #0x1b]
    //     0x9d7400: ldurb           w16, [x1, #-1]
    //     0x9d7404: ldurb           w17, [x0, #-1]
    //     0x9d7408: and             x16, x17, x16, lsr #2
    //     0x9d740c: tst             x16, HEAP, lsr #32
    //     0x9d7410: b.eq            #0x9d7418
    //     0x9d7414: bl              #0xd6826c
    // 0x9d7418: SaveReg r1
    //     0x9d7418: str             x1, [SP, #-8]!
    // 0x9d741c: r0 = _handleVisibilityChanged()
    //     0x9d741c: bl              #0x7aea7c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged
    // 0x9d7420: add             SP, SP, #8
    // 0x9d7424: ldr             x0, [fp, #0x10]
    // 0x9d7428: LoadField: r1 = r0->field_b
    //     0x9d7428: ldur            w1, [x0, #0xb]
    // 0x9d742c: DecompressPointer r1
    //     0x9d742c: add             x1, x1, HEAP, lsl #32
    // 0x9d7430: cmp             w1, NULL
    // 0x9d7434: b.eq            #0x9d7490
    // 0x9d7438: LoadField: r2 = r1->field_23
    //     0x9d7438: ldur            w2, [x1, #0x23]
    // 0x9d743c: DecompressPointer r2
    //     0x9d743c: add             x2, x2, HEAP, lsl #32
    // 0x9d7440: stur            x2, [fp, #-8]
    // 0x9d7444: r1 = 1
    //     0x9d7444: mov             x1, #1
    // 0x9d7448: r0 = AllocateContext()
    //     0x9d7448: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d744c: mov             x1, x0
    // 0x9d7450: ldr             x0, [fp, #0x10]
    // 0x9d7454: StoreField: r1->field_f = r0
    //     0x9d7454: stur            w0, [x1, #0xf]
    // 0x9d7458: mov             x2, x1
    // 0x9d745c: r1 = Function '_handleVisibilityChanged@500251836':.
    //     0x9d745c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bbf0] AnonymousClosure: (0x7aeb40), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged (0x7aea7c)
    //     0x9d7460: ldr             x1, [x1, #0xbf0]
    // 0x9d7464: r0 = AllocateClosure()
    //     0x9d7464: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7468: ldur            x16, [fp, #-8]
    // 0x9d746c: stp             x0, x16, [SP, #-0x10]!
    // 0x9d7470: r0 = addListener()
    //     0x9d7470: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9d7474: add             SP, SP, #0x10
    // 0x9d7478: r0 = Null
    //     0x9d7478: mov             x0, NULL
    // 0x9d747c: LeaveFrame
    //     0x9d747c: mov             SP, fp
    //     0x9d7480: ldp             fp, lr, [SP], #0x10
    // 0x9d7484: ret
    //     0x9d7484: ret             
    // 0x9d7488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d7488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d748c: b               #0x9d73c4
    // 0x9d7490: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d7490: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a4c8, size: 0x18
    // 0xa4a4c8: r4 = 7
    //     0xa4a4c8: mov             x4, #7
    // 0xa4a4cc: r1 = Function 'dispose':.
    //     0xa4a4cc: add             x17, PP, #0x4b, lsl #12  ; [pp+0x4bbd8] AnonymousClosure: (0xa4a4e0), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::dispose (0xa50058)
    //     0xa4a4d0: ldr             x1, [x17, #0xbd8]
    // 0xa4a4d4: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a4d4: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a4d8: LoadField: r0 = r24->field_17
    //     0xa4a4d8: ldur            x0, [x24, #0x17]
    // 0xa4a4dc: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a4e0, size: 0x48
    // 0xa4a4e0: EnterFrame
    //     0xa4a4e0: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a4e4: mov             fp, SP
    // 0xa4a4e8: ldr             x0, [fp, #0x10]
    // 0xa4a4ec: LoadField: r1 = r0->field_17
    //     0xa4a4ec: ldur            w1, [x0, #0x17]
    // 0xa4a4f0: DecompressPointer r1
    //     0xa4a4f0: add             x1, x1, HEAP, lsl #32
    // 0xa4a4f4: CheckStackOverflow
    //     0xa4a4f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a4f8: cmp             SP, x16
    //     0xa4a4fc: b.ls            #0xa4a520
    // 0xa4a500: LoadField: r0 = r1->field_f
    //     0xa4a500: ldur            w0, [x1, #0xf]
    // 0xa4a504: DecompressPointer r0
    //     0xa4a504: add             x0, x0, HEAP, lsl #32
    // 0xa4a508: SaveReg r0
    //     0xa4a508: str             x0, [SP, #-8]!
    // 0xa4a50c: r0 = dispose()
    //     0xa4a50c: bl              #0xa50058  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::dispose
    // 0xa4a510: add             SP, SP, #8
    // 0xa4a514: LeaveFrame
    //     0xa4a514: mov             SP, fp
    //     0xa4a518: ldp             fp, lr, [SP], #0x10
    // 0xa4a51c: ret
    //     0xa4a51c: ret             
    // 0xa4a520: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a520: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a524: b               #0xa4a500
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa50058, size: 0xc8
    // 0xa50058: EnterFrame
    //     0xa50058: stp             fp, lr, [SP, #-0x10]!
    //     0xa5005c: mov             fp, SP
    // 0xa50060: AllocStack(0x8)
    //     0xa50060: sub             SP, SP, #8
    // 0xa50064: CheckStackOverflow
    //     0xa50064: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50068: cmp             SP, x16
    //     0xa5006c: b.ls            #0xa50108
    // 0xa50070: ldr             x0, [fp, #0x10]
    // 0xa50074: LoadField: r1 = r0->field_b
    //     0xa50074: ldur            w1, [x0, #0xb]
    // 0xa50078: DecompressPointer r1
    //     0xa50078: add             x1, x1, HEAP, lsl #32
    // 0xa5007c: cmp             w1, NULL
    // 0xa50080: b.eq            #0xa50110
    // 0xa50084: LoadField: r2 = r1->field_23
    //     0xa50084: ldur            w2, [x1, #0x23]
    // 0xa50088: DecompressPointer r2
    //     0xa50088: add             x2, x2, HEAP, lsl #32
    // 0xa5008c: stur            x2, [fp, #-8]
    // 0xa50090: r1 = 1
    //     0xa50090: mov             x1, #1
    // 0xa50094: r0 = AllocateContext()
    //     0xa50094: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa50098: mov             x1, x0
    // 0xa5009c: ldr             x0, [fp, #0x10]
    // 0xa500a0: StoreField: r1->field_f = r0
    //     0xa500a0: stur            w0, [x1, #0xf]
    // 0xa500a4: mov             x2, x1
    // 0xa500a8: r1 = Function '_handleVisibilityChanged@500251836':.
    //     0xa500a8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bbf0] AnonymousClosure: (0x7aeb40), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionHandleOverlayState::_handleVisibilityChanged (0x7aea7c)
    //     0xa500ac: ldr             x1, [x1, #0xbf0]
    // 0xa500b0: r0 = AllocateClosure()
    //     0xa500b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa500b4: ldur            x16, [fp, #-8]
    // 0xa500b8: stp             x0, x16, [SP, #-0x10]!
    // 0xa500bc: r0 = removeListener()
    //     0xa500bc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa500c0: add             SP, SP, #0x10
    // 0xa500c4: ldr             x0, [fp, #0x10]
    // 0xa500c8: LoadField: r1 = r0->field_1b
    //     0xa500c8: ldur            w1, [x0, #0x1b]
    // 0xa500cc: DecompressPointer r1
    //     0xa500cc: add             x1, x1, HEAP, lsl #32
    // 0xa500d0: r16 = Sentinel
    //     0xa500d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa500d4: cmp             w1, w16
    // 0xa500d8: b.eq            #0xa50114
    // 0xa500dc: SaveReg r1
    //     0xa500dc: str             x1, [SP, #-8]!
    // 0xa500e0: r0 = dispose()
    //     0xa500e0: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa500e4: add             SP, SP, #8
    // 0xa500e8: ldr             x16, [fp, #0x10]
    // 0xa500ec: SaveReg r16
    //     0xa500ec: str             x16, [SP, #-8]!
    // 0xa500f0: r0 = dispose()
    //     0xa500f0: bl              #0xa50120  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionHandleOverlayState&State&SingleTickerProviderStateMixin::dispose
    // 0xa500f4: add             SP, SP, #8
    // 0xa500f8: r0 = Null
    //     0xa500f8: mov             x0, NULL
    // 0xa500fc: LeaveFrame
    //     0xa500fc: mov             SP, fp
    //     0xa50100: ldp             fp, lr, [SP], #0x10
    // 0xa50104: ret
    //     0xa50104: ret             
    // 0xa50108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5010c: b               #0xa50070
    // 0xa50110: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa50110: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa50114: r9 = _controller
    //     0xa50114: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bbe8] Field <_SelectionHandleOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0xa50118: ldr             x9, [x9, #0xbe8]
    // 0xa5011c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa5011c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 3365, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class __SelectionToolbarOverlayState&State&SingleTickerProviderStateMixin extends State<_SelectionToolbarOverlay>
     with SingleTickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x6146f8, size: 0x98
    // 0x6146f8: EnterFrame
    //     0x6146f8: stp             fp, lr, [SP, #-0x10]!
    //     0x6146fc: mov             fp, SP
    // 0x614700: CheckStackOverflow
    //     0x614700: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x614704: cmp             SP, x16
    //     0x614708: b.ls            #0x614784
    // 0x61470c: r0 = Ticker()
    //     0x61470c: bl              #0x6135dc  ; AllocateTickerStub -> Ticker (size=0x1c)
    // 0x614710: mov             x1, x0
    // 0x614714: r0 = false
    //     0x614714: add             x0, NULL, #0x30  ; false
    // 0x614718: StoreField: r1->field_b = r0
    //     0x614718: stur            w0, [x1, #0xb]
    // 0x61471c: ldr             x0, [fp, #0x10]
    // 0x614720: StoreField: r1->field_13 = r0
    //     0x614720: stur            w0, [x1, #0x13]
    // 0x614724: mov             x0, x1
    // 0x614728: ldr             x1, [fp, #0x18]
    // 0x61472c: StoreField: r1->field_13 = r0
    //     0x61472c: stur            w0, [x1, #0x13]
    //     0x614730: ldurb           w16, [x1, #-1]
    //     0x614734: ldurb           w17, [x0, #-1]
    //     0x614738: and             x16, x17, x16, lsr #2
    //     0x61473c: tst             x16, HEAP, lsr #32
    //     0x614740: b.eq            #0x614748
    //     0x614744: bl              #0xd6826c
    // 0x614748: SaveReg r1
    //     0x614748: str             x1, [SP, #-8]!
    // 0x61474c: r0 = _updateTickerModeNotifier()
    //     0x61474c: bl              #0x6147b4  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionToolbarOverlayState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x614750: add             SP, SP, #8
    // 0x614754: ldr             x16, [fp, #0x18]
    // 0x614758: SaveReg r16
    //     0x614758: str             x16, [SP, #-8]!
    // 0x61475c: r0 = _updateTicker()
    //     0x61475c: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614760: add             SP, SP, #8
    // 0x614764: ldr             x1, [fp, #0x18]
    // 0x614768: LoadField: r0 = r1->field_13
    //     0x614768: ldur            w0, [x1, #0x13]
    // 0x61476c: DecompressPointer r0
    //     0x61476c: add             x0, x0, HEAP, lsl #32
    // 0x614770: cmp             w0, NULL
    // 0x614774: b.eq            #0x61478c
    // 0x614778: LeaveFrame
    //     0x614778: mov             SP, fp
    //     0x61477c: ldp             fp, lr, [SP], #0x10
    // 0x614780: ret
    //     0x614780: ret             
    // 0x614784: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614784: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614788: b               #0x61470c
    // 0x61478c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x61478c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x6147b4, size: 0x11c
    // 0x6147b4: EnterFrame
    //     0x6147b4: stp             fp, lr, [SP, #-0x10]!
    //     0x6147b8: mov             fp, SP
    // 0x6147bc: AllocStack(0x10)
    //     0x6147bc: sub             SP, SP, #0x10
    // 0x6147c0: CheckStackOverflow
    //     0x6147c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6147c4: cmp             SP, x16
    //     0x6147c8: b.ls            #0x6148c4
    // 0x6147cc: ldr             x0, [fp, #0x10]
    // 0x6147d0: LoadField: r1 = r0->field_f
    //     0x6147d0: ldur            w1, [x0, #0xf]
    // 0x6147d4: DecompressPointer r1
    //     0x6147d4: add             x1, x1, HEAP, lsl #32
    // 0x6147d8: cmp             w1, NULL
    // 0x6147dc: b.eq            #0x6148cc
    // 0x6147e0: SaveReg r1
    //     0x6147e0: str             x1, [SP, #-8]!
    // 0x6147e4: r0 = getNotifier()
    //     0x6147e4: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x6147e8: add             SP, SP, #8
    // 0x6147ec: mov             x1, x0
    // 0x6147f0: ldr             x0, [fp, #0x10]
    // 0x6147f4: stur            x1, [fp, #-0x10]
    // 0x6147f8: LoadField: r2 = r0->field_17
    //     0x6147f8: ldur            w2, [x0, #0x17]
    // 0x6147fc: DecompressPointer r2
    //     0x6147fc: add             x2, x2, HEAP, lsl #32
    // 0x614800: stur            x2, [fp, #-8]
    // 0x614804: cmp             w1, w2
    // 0x614808: b.ne            #0x61481c
    // 0x61480c: r0 = Null
    //     0x61480c: mov             x0, NULL
    // 0x614810: LeaveFrame
    //     0x614810: mov             SP, fp
    //     0x614814: ldp             fp, lr, [SP], #0x10
    // 0x614818: ret
    //     0x614818: ret             
    // 0x61481c: cmp             w2, NULL
    // 0x614820: b.eq            #0x61485c
    // 0x614824: r1 = 1
    //     0x614824: mov             x1, #1
    // 0x614828: r0 = AllocateContext()
    //     0x614828: bl              #0xd68aa4  ; AllocateContextStub
    // 0x61482c: mov             x1, x0
    // 0x614830: ldr             x0, [fp, #0x10]
    // 0x614834: StoreField: r1->field_f = r0
    //     0x614834: stur            w0, [x1, #0xf]
    // 0x614838: mov             x2, x1
    // 0x61483c: r1 = Function '_updateTicker@156311458':.
    //     0x61483c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53350] AnonymousClosure: (0x6148d0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614840: ldr             x1, [x1, #0x350]
    // 0x614844: r0 = AllocateClosure()
    //     0x614844: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614848: ldur            x16, [fp, #-8]
    // 0x61484c: stp             x0, x16, [SP, #-0x10]!
    // 0x614850: r0 = removeListener()
    //     0x614850: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x614854: add             SP, SP, #0x10
    // 0x614858: ldr             x0, [fp, #0x10]
    // 0x61485c: r1 = 1
    //     0x61485c: mov             x1, #1
    // 0x614860: r0 = AllocateContext()
    //     0x614860: bl              #0xd68aa4  ; AllocateContextStub
    // 0x614864: mov             x1, x0
    // 0x614868: ldr             x0, [fp, #0x10]
    // 0x61486c: StoreField: r1->field_f = r0
    //     0x61486c: stur            w0, [x1, #0xf]
    // 0x614870: mov             x2, x1
    // 0x614874: r1 = Function '_updateTicker@156311458':.
    //     0x614874: add             x1, PP, #0x53, lsl #12  ; [pp+0x53350] AnonymousClosure: (0x6148d0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0x614878: ldr             x1, [x1, #0x350]
    // 0x61487c: r0 = AllocateClosure()
    //     0x61487c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x614880: ldur            x16, [fp, #-0x10]
    // 0x614884: stp             x0, x16, [SP, #-0x10]!
    // 0x614888: r0 = addListener()
    //     0x614888: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x61488c: add             SP, SP, #0x10
    // 0x614890: ldur            x0, [fp, #-0x10]
    // 0x614894: ldr             x1, [fp, #0x10]
    // 0x614898: StoreField: r1->field_17 = r0
    //     0x614898: stur            w0, [x1, #0x17]
    //     0x61489c: ldurb           w16, [x1, #-1]
    //     0x6148a0: ldurb           w17, [x0, #-1]
    //     0x6148a4: and             x16, x17, x16, lsr #2
    //     0x6148a8: tst             x16, HEAP, lsr #32
    //     0x6148ac: b.eq            #0x6148b4
    //     0x6148b0: bl              #0xd6826c
    // 0x6148b4: r0 = Null
    //     0x6148b4: mov             x0, NULL
    // 0x6148b8: LeaveFrame
    //     0x6148b8: mov             SP, fp
    //     0x6148bc: ldp             fp, lr, [SP], #0x10
    // 0x6148c0: ret
    //     0x6148c0: ret             
    // 0x6148c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6148c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6148c8: b               #0x6147cc
    // 0x6148cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x6148cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTicker(dynamic) {
    // ** addr: 0x6148d0, size: 0x48
    // 0x6148d0: EnterFrame
    //     0x6148d0: stp             fp, lr, [SP, #-0x10]!
    //     0x6148d4: mov             fp, SP
    // 0x6148d8: ldr             x0, [fp, #0x10]
    // 0x6148dc: LoadField: r1 = r0->field_17
    //     0x6148dc: ldur            w1, [x0, #0x17]
    // 0x6148e0: DecompressPointer r1
    //     0x6148e0: add             x1, x1, HEAP, lsl #32
    // 0x6148e4: CheckStackOverflow
    //     0x6148e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6148e8: cmp             SP, x16
    //     0x6148ec: b.ls            #0x614910
    // 0x6148f0: LoadField: r0 = r1->field_f
    //     0x6148f0: ldur            w0, [x1, #0xf]
    // 0x6148f4: DecompressPointer r0
    //     0x6148f4: add             x0, x0, HEAP, lsl #32
    // 0x6148f8: SaveReg r0
    //     0x6148f8: str             x0, [SP, #-8]!
    // 0x6148fc: r0 = _updateTicker()
    //     0x6148fc: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x614900: add             SP, SP, #8
    // 0x614904: LeaveFrame
    //     0x614904: mov             SP, fp
    //     0x614908: ldp             fp, lr, [SP], #0x10
    // 0x61490c: ret
    //     0x61490c: ret             
    // 0x614910: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x614910: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x614914: b               #0x6148f0
  }
  _ activate(/* No info */) {
    // ** addr: 0x81f034, size: 0x4c
    // 0x81f034: EnterFrame
    //     0x81f034: stp             fp, lr, [SP, #-0x10]!
    //     0x81f038: mov             fp, SP
    // 0x81f03c: CheckStackOverflow
    //     0x81f03c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81f040: cmp             SP, x16
    //     0x81f044: b.ls            #0x81f078
    // 0x81f048: ldr             x16, [fp, #0x10]
    // 0x81f04c: SaveReg r16
    //     0x81f04c: str             x16, [SP, #-8]!
    // 0x81f050: r0 = _updateTickerModeNotifier()
    //     0x81f050: bl              #0x6147b4  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionToolbarOverlayState&State&SingleTickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81f054: add             SP, SP, #8
    // 0x81f058: ldr             x16, [fp, #0x10]
    // 0x81f05c: SaveReg r16
    //     0x81f05c: str             x16, [SP, #-8]!
    // 0x81f060: r0 = _updateTicker()
    //     0x81f060: bl              #0x61340c  ; [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker
    // 0x81f064: add             SP, SP, #8
    // 0x81f068: r0 = Null
    //     0x81f068: mov             x0, NULL
    // 0x81f06c: LeaveFrame
    //     0x81f06c: mov             SP, fp
    //     0x81f070: ldp             fp, lr, [SP], #0x10
    // 0x81f074: ret
    //     0x81f074: ret             
    // 0x81f078: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81f078: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81f07c: b               #0x81f048
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4ff84, size: 0x8c
    // 0xa4ff84: EnterFrame
    //     0xa4ff84: stp             fp, lr, [SP, #-0x10]!
    //     0xa4ff88: mov             fp, SP
    // 0xa4ff8c: AllocStack(0x8)
    //     0xa4ff8c: sub             SP, SP, #8
    // 0xa4ff90: CheckStackOverflow
    //     0xa4ff90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4ff94: cmp             SP, x16
    //     0xa4ff98: b.ls            #0xa50008
    // 0xa4ff9c: ldr             x0, [fp, #0x10]
    // 0xa4ffa0: LoadField: r1 = r0->field_17
    //     0xa4ffa0: ldur            w1, [x0, #0x17]
    // 0xa4ffa4: DecompressPointer r1
    //     0xa4ffa4: add             x1, x1, HEAP, lsl #32
    // 0xa4ffa8: stur            x1, [fp, #-8]
    // 0xa4ffac: cmp             w1, NULL
    // 0xa4ffb0: b.ne            #0xa4ffbc
    // 0xa4ffb4: mov             x1, x0
    // 0xa4ffb8: b               #0xa4fff4
    // 0xa4ffbc: r1 = 1
    //     0xa4ffbc: mov             x1, #1
    // 0xa4ffc0: r0 = AllocateContext()
    //     0xa4ffc0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4ffc4: mov             x1, x0
    // 0xa4ffc8: ldr             x0, [fp, #0x10]
    // 0xa4ffcc: StoreField: r1->field_f = r0
    //     0xa4ffcc: stur            w0, [x1, #0xf]
    // 0xa4ffd0: mov             x2, x1
    // 0xa4ffd4: r1 = Function '_updateTicker@156311458':.
    //     0xa4ffd4: add             x1, PP, #0x53, lsl #12  ; [pp+0x53350] AnonymousClosure: (0x6148d0), in [package:emoji_picker_flutter/src/default_emoji_picker_view.dart] __DefaultEmojiPickerViewState&State&SingleTickerProviderStateMixin::_updateTicker (0x61340c)
    //     0xa4ffd8: ldr             x1, [x1, #0x350]
    // 0xa4ffdc: r0 = AllocateClosure()
    //     0xa4ffdc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4ffe0: ldur            x16, [fp, #-8]
    // 0xa4ffe4: stp             x0, x16, [SP, #-0x10]!
    // 0xa4ffe8: r0 = removeListener()
    //     0xa4ffe8: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4ffec: add             SP, SP, #0x10
    // 0xa4fff0: ldr             x1, [fp, #0x10]
    // 0xa4fff4: StoreField: r1->field_17 = rNULL
    //     0xa4fff4: stur            NULL, [x1, #0x17]
    // 0xa4fff8: r0 = Null
    //     0xa4fff8: mov             x0, NULL
    // 0xa4fffc: LeaveFrame
    //     0xa4fffc: mov             SP, fp
    //     0xa50000: ldp             fp, lr, [SP], #0x10
    // 0xa50004: ret
    //     0xa50004: ret             
    // 0xa50008: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50008: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5000c: b               #0xa4ff9c
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa50010, size: 0x48
    // 0xa50010: EnterFrame
    //     0xa50010: stp             fp, lr, [SP, #-0x10]!
    //     0xa50014: mov             fp, SP
    // 0xa50018: ldr             x0, [fp, #0x10]
    // 0xa5001c: LoadField: r1 = r0->field_17
    //     0xa5001c: ldur            w1, [x0, #0x17]
    // 0xa50020: DecompressPointer r1
    //     0xa50020: add             x1, x1, HEAP, lsl #32
    // 0xa50024: CheckStackOverflow
    //     0xa50024: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa50028: cmp             SP, x16
    //     0xa5002c: b.ls            #0xa50050
    // 0xa50030: LoadField: r0 = r1->field_f
    //     0xa50030: ldur            w0, [x1, #0xf]
    // 0xa50034: DecompressPointer r0
    //     0xa50034: add             x0, x0, HEAP, lsl #32
    // 0xa50038: SaveReg r0
    //     0xa50038: str             x0, [SP, #-8]!
    // 0xa5003c: r0 = dispose()
    //     0xa5003c: bl              #0xa4ff84  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionToolbarOverlayState&State&SingleTickerProviderStateMixin::dispose
    // 0xa50040: add             SP, SP, #8
    // 0xa50044: LeaveFrame
    //     0xa50044: mov             SP, fp
    //     0xa50048: ldp             fp, lr, [SP], #0x10
    // 0xa5004c: ret
    //     0xa5004c: ret             
    // 0xa50050: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa50050: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa50054: b               #0xa50030
  }
}

// class id: 3366, size: 0x20, field offset: 0x1c
class _SelectionToolbarOverlayState extends __SelectionToolbarOverlayState&State&SingleTickerProviderStateMixin {

  late AnimationController _controller; // offset: 0x1c

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7ae690, size: 0x18c
    // 0x7ae690: EnterFrame
    //     0x7ae690: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae694: mov             fp, SP
    // 0x7ae698: AllocStack(0x8)
    //     0x7ae698: sub             SP, SP, #8
    // 0x7ae69c: CheckStackOverflow
    //     0x7ae69c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae6a0: cmp             SP, x16
    //     0x7ae6a4: b.ls            #0x7ae80c
    // 0x7ae6a8: ldr             x0, [fp, #0x10]
    // 0x7ae6ac: r2 = Null
    //     0x7ae6ac: mov             x2, NULL
    // 0x7ae6b0: r1 = Null
    //     0x7ae6b0: mov             x1, NULL
    // 0x7ae6b4: r4 = 59
    //     0x7ae6b4: mov             x4, #0x3b
    // 0x7ae6b8: branchIfSmi(r0, 0x7ae6c4)
    //     0x7ae6b8: tbz             w0, #0, #0x7ae6c4
    // 0x7ae6bc: r4 = LoadClassIdInstr(r0)
    //     0x7ae6bc: ldur            x4, [x0, #-1]
    //     0x7ae6c0: ubfx            x4, x4, #0xc, #0x14
    // 0x7ae6c4: r17 = 4187
    //     0x7ae6c4: mov             x17, #0x105b
    // 0x7ae6c8: cmp             x4, x17
    // 0x7ae6cc: b.eq            #0x7ae6e4
    // 0x7ae6d0: r8 = _SelectionToolbarOverlay
    //     0x7ae6d0: add             x8, PP, #0x53, lsl #12  ; [pp+0x53320] Type: _SelectionToolbarOverlay
    //     0x7ae6d4: ldr             x8, [x8, #0x320]
    // 0x7ae6d8: r3 = Null
    //     0x7ae6d8: add             x3, PP, #0x53, lsl #12  ; [pp+0x53328] Null
    //     0x7ae6dc: ldr             x3, [x3, #0x328]
    // 0x7ae6e0: r0 = _SelectionToolbarOverlay()
    //     0x7ae6e0: bl              #0x614790  ; IsType__SelectionToolbarOverlay_Stub
    // 0x7ae6e4: ldr             x3, [fp, #0x18]
    // 0x7ae6e8: LoadField: r2 = r3->field_7
    //     0x7ae6e8: ldur            w2, [x3, #7]
    // 0x7ae6ec: DecompressPointer r2
    //     0x7ae6ec: add             x2, x2, HEAP, lsl #32
    // 0x7ae6f0: ldr             x0, [fp, #0x10]
    // 0x7ae6f4: r1 = Null
    //     0x7ae6f4: mov             x1, NULL
    // 0x7ae6f8: cmp             w2, NULL
    // 0x7ae6fc: b.eq            #0x7ae720
    // 0x7ae700: LoadField: r4 = r2->field_17
    //     0x7ae700: ldur            w4, [x2, #0x17]
    // 0x7ae704: DecompressPointer r4
    //     0x7ae704: add             x4, x4, HEAP, lsl #32
    // 0x7ae708: r8 = X0 bound StatefulWidget
    //     0x7ae708: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7ae70c: ldr             x8, [x8, #0x858]
    // 0x7ae710: LoadField: r9 = r4->field_7
    //     0x7ae710: ldur            x9, [x4, #7]
    // 0x7ae714: r3 = Null
    //     0x7ae714: add             x3, PP, #0x53, lsl #12  ; [pp+0x53338] Null
    //     0x7ae718: ldr             x3, [x3, #0x338]
    // 0x7ae71c: blr             x9
    // 0x7ae720: ldr             x0, [fp, #0x10]
    // 0x7ae724: LoadField: r1 = r0->field_23
    //     0x7ae724: ldur            w1, [x0, #0x23]
    // 0x7ae728: DecompressPointer r1
    //     0x7ae728: add             x1, x1, HEAP, lsl #32
    // 0x7ae72c: ldr             x0, [fp, #0x18]
    // 0x7ae730: stur            x1, [fp, #-8]
    // 0x7ae734: LoadField: r2 = r0->field_b
    //     0x7ae734: ldur            w2, [x0, #0xb]
    // 0x7ae738: DecompressPointer r2
    //     0x7ae738: add             x2, x2, HEAP, lsl #32
    // 0x7ae73c: cmp             w2, NULL
    // 0x7ae740: b.eq            #0x7ae814
    // 0x7ae744: LoadField: r3 = r2->field_23
    //     0x7ae744: ldur            w3, [x2, #0x23]
    // 0x7ae748: DecompressPointer r3
    //     0x7ae748: add             x3, x3, HEAP, lsl #32
    // 0x7ae74c: cmp             w1, w3
    // 0x7ae750: b.ne            #0x7ae764
    // 0x7ae754: r0 = Null
    //     0x7ae754: mov             x0, NULL
    // 0x7ae758: LeaveFrame
    //     0x7ae758: mov             SP, fp
    //     0x7ae75c: ldp             fp, lr, [SP], #0x10
    // 0x7ae760: ret
    //     0x7ae760: ret             
    // 0x7ae764: r1 = 1
    //     0x7ae764: mov             x1, #1
    // 0x7ae768: r0 = AllocateContext()
    //     0x7ae768: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ae76c: mov             x1, x0
    // 0x7ae770: ldr             x0, [fp, #0x18]
    // 0x7ae774: StoreField: r1->field_f = r0
    //     0x7ae774: stur            w0, [x1, #0xf]
    // 0x7ae778: mov             x2, x1
    // 0x7ae77c: r1 = Function '_toolbarVisibilityChanged@500251836':.
    //     0x7ae77c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53318] AnonymousClosure: (0x7ae8e0), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged (0x7ae81c)
    //     0x7ae780: ldr             x1, [x1, #0x318]
    // 0x7ae784: r0 = AllocateClosure()
    //     0x7ae784: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ae788: ldur            x16, [fp, #-8]
    // 0x7ae78c: stp             x0, x16, [SP, #-0x10]!
    // 0x7ae790: r0 = removeListener()
    //     0x7ae790: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7ae794: add             SP, SP, #0x10
    // 0x7ae798: ldr             x16, [fp, #0x18]
    // 0x7ae79c: SaveReg r16
    //     0x7ae79c: str             x16, [SP, #-8]!
    // 0x7ae7a0: r0 = _toolbarVisibilityChanged()
    //     0x7ae7a0: bl              #0x7ae81c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged
    // 0x7ae7a4: add             SP, SP, #8
    // 0x7ae7a8: ldr             x0, [fp, #0x18]
    // 0x7ae7ac: LoadField: r1 = r0->field_b
    //     0x7ae7ac: ldur            w1, [x0, #0xb]
    // 0x7ae7b0: DecompressPointer r1
    //     0x7ae7b0: add             x1, x1, HEAP, lsl #32
    // 0x7ae7b4: cmp             w1, NULL
    // 0x7ae7b8: b.eq            #0x7ae818
    // 0x7ae7bc: LoadField: r2 = r1->field_23
    //     0x7ae7bc: ldur            w2, [x1, #0x23]
    // 0x7ae7c0: DecompressPointer r2
    //     0x7ae7c0: add             x2, x2, HEAP, lsl #32
    // 0x7ae7c4: stur            x2, [fp, #-8]
    // 0x7ae7c8: r1 = 1
    //     0x7ae7c8: mov             x1, #1
    // 0x7ae7cc: r0 = AllocateContext()
    //     0x7ae7cc: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ae7d0: mov             x1, x0
    // 0x7ae7d4: ldr             x0, [fp, #0x18]
    // 0x7ae7d8: StoreField: r1->field_f = r0
    //     0x7ae7d8: stur            w0, [x1, #0xf]
    // 0x7ae7dc: mov             x2, x1
    // 0x7ae7e0: r1 = Function '_toolbarVisibilityChanged@500251836':.
    //     0x7ae7e0: add             x1, PP, #0x53, lsl #12  ; [pp+0x53318] AnonymousClosure: (0x7ae8e0), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged (0x7ae81c)
    //     0x7ae7e4: ldr             x1, [x1, #0x318]
    // 0x7ae7e8: r0 = AllocateClosure()
    //     0x7ae7e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ae7ec: ldur            x16, [fp, #-8]
    // 0x7ae7f0: stp             x0, x16, [SP, #-0x10]!
    // 0x7ae7f4: r0 = addListener()
    //     0x7ae7f4: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7ae7f8: add             SP, SP, #0x10
    // 0x7ae7fc: r0 = Null
    //     0x7ae7fc: mov             x0, NULL
    // 0x7ae800: LeaveFrame
    //     0x7ae800: mov             SP, fp
    //     0x7ae804: ldp             fp, lr, [SP], #0x10
    // 0x7ae808: ret
    //     0x7ae808: ret             
    // 0x7ae80c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae80c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae810: b               #0x7ae6a8
    // 0x7ae814: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae814: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7ae818: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae818: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _toolbarVisibilityChanged(/* No info */) {
    // ** addr: 0x7ae81c, size: 0xc4
    // 0x7ae81c: EnterFrame
    //     0x7ae81c: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae820: mov             fp, SP
    // 0x7ae824: CheckStackOverflow
    //     0x7ae824: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae828: cmp             SP, x16
    //     0x7ae82c: b.ls            #0x7ae8bc
    // 0x7ae830: ldr             x0, [fp, #0x10]
    // 0x7ae834: LoadField: r1 = r0->field_b
    //     0x7ae834: ldur            w1, [x0, #0xb]
    // 0x7ae838: DecompressPointer r1
    //     0x7ae838: add             x1, x1, HEAP, lsl #32
    // 0x7ae83c: cmp             w1, NULL
    // 0x7ae840: b.eq            #0x7ae8c4
    // 0x7ae844: LoadField: r2 = r1->field_23
    //     0x7ae844: ldur            w2, [x1, #0x23]
    // 0x7ae848: DecompressPointer r2
    //     0x7ae848: add             x2, x2, HEAP, lsl #32
    // 0x7ae84c: LoadField: r1 = r2->field_27
    //     0x7ae84c: ldur            w1, [x2, #0x27]
    // 0x7ae850: DecompressPointer r1
    //     0x7ae850: add             x1, x1, HEAP, lsl #32
    // 0x7ae854: r16 = true
    //     0x7ae854: add             x16, NULL, #0x20  ; true
    // 0x7ae858: cmp             w1, w16
    // 0x7ae85c: b.ne            #0x7ae888
    // 0x7ae860: LoadField: r1 = r0->field_1b
    //     0x7ae860: ldur            w1, [x0, #0x1b]
    // 0x7ae864: DecompressPointer r1
    //     0x7ae864: add             x1, x1, HEAP, lsl #32
    // 0x7ae868: r16 = Sentinel
    //     0x7ae868: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7ae86c: cmp             w1, w16
    // 0x7ae870: b.eq            #0x7ae8c8
    // 0x7ae874: SaveReg r1
    //     0x7ae874: str             x1, [SP, #-8]!
    // 0x7ae878: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ae878: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ae87c: r0 = forward()
    //     0x7ae87c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7ae880: add             SP, SP, #8
    // 0x7ae884: b               #0x7ae8ac
    // 0x7ae888: LoadField: r1 = r0->field_1b
    //     0x7ae888: ldur            w1, [x0, #0x1b]
    // 0x7ae88c: DecompressPointer r1
    //     0x7ae88c: add             x1, x1, HEAP, lsl #32
    // 0x7ae890: r16 = Sentinel
    //     0x7ae890: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7ae894: cmp             w1, w16
    // 0x7ae898: b.eq            #0x7ae8d4
    // 0x7ae89c: SaveReg r1
    //     0x7ae89c: str             x1, [SP, #-8]!
    // 0x7ae8a0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7ae8a0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7ae8a4: r0 = reverse()
    //     0x7ae8a4: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x7ae8a8: add             SP, SP, #8
    // 0x7ae8ac: r0 = Null
    //     0x7ae8ac: mov             x0, NULL
    // 0x7ae8b0: LeaveFrame
    //     0x7ae8b0: mov             SP, fp
    //     0x7ae8b4: ldp             fp, lr, [SP], #0x10
    // 0x7ae8b8: ret
    //     0x7ae8b8: ret             
    // 0x7ae8bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae8bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae8c0: b               #0x7ae830
    // 0x7ae8c4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ae8c4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7ae8c8: r9 = _controller
    //     0x7ae8c8: add             x9, PP, #0x53, lsl #12  ; [pp+0x53310] Field <_SelectionToolbarOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0x7ae8cc: ldr             x9, [x9, #0x310]
    // 0x7ae8d0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ae8d0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7ae8d4: r9 = _controller
    //     0x7ae8d4: add             x9, PP, #0x53, lsl #12  ; [pp+0x53310] Field <_SelectionToolbarOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0x7ae8d8: ldr             x9, [x9, #0x310]
    // 0x7ae8dc: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ae8dc: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void _toolbarVisibilityChanged(dynamic) {
    // ** addr: 0x7ae8e0, size: 0x48
    // 0x7ae8e0: EnterFrame
    //     0x7ae8e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7ae8e4: mov             fp, SP
    // 0x7ae8e8: ldr             x0, [fp, #0x10]
    // 0x7ae8ec: LoadField: r1 = r0->field_17
    //     0x7ae8ec: ldur            w1, [x0, #0x17]
    // 0x7ae8f0: DecompressPointer r1
    //     0x7ae8f0: add             x1, x1, HEAP, lsl #32
    // 0x7ae8f4: CheckStackOverflow
    //     0x7ae8f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ae8f8: cmp             SP, x16
    //     0x7ae8fc: b.ls            #0x7ae920
    // 0x7ae900: LoadField: r0 = r1->field_f
    //     0x7ae900: ldur            w0, [x1, #0xf]
    // 0x7ae904: DecompressPointer r0
    //     0x7ae904: add             x0, x0, HEAP, lsl #32
    // 0x7ae908: SaveReg r0
    //     0x7ae908: str             x0, [SP, #-8]!
    // 0x7ae90c: r0 = _toolbarVisibilityChanged()
    //     0x7ae90c: bl              #0x7ae81c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged
    // 0x7ae910: add             SP, SP, #8
    // 0x7ae914: LeaveFrame
    //     0x7ae914: mov             SP, fp
    //     0x7ae918: ldp             fp, lr, [SP], #0x10
    // 0x7ae91c: ret
    //     0x7ae91c: ret             
    // 0x7ae920: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ae920: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ae924: b               #0x7ae900
  }
  _ build(/* No info */) {
    // ** addr: 0x83ecb8, size: 0x138
    // 0x83ecb8: EnterFrame
    //     0x83ecb8: stp             fp, lr, [SP, #-0x10]!
    //     0x83ecbc: mov             fp, SP
    // 0x83ecc0: AllocStack(0x38)
    //     0x83ecc0: sub             SP, SP, #0x38
    // 0x83ecc4: CheckStackOverflow
    //     0x83ecc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83ecc8: cmp             SP, x16
    //     0x83eccc: b.ls            #0x83ede4
    // 0x83ecd0: r1 = 1
    //     0x83ecd0: mov             x1, #1
    // 0x83ecd4: r0 = AllocateContext()
    //     0x83ecd4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83ecd8: mov             x1, x0
    // 0x83ecdc: ldr             x0, [fp, #0x18]
    // 0x83ece0: stur            x1, [fp, #-8]
    // 0x83ece4: StoreField: r1->field_f = r0
    //     0x83ece4: stur            w0, [x1, #0xf]
    // 0x83ece8: SaveReg r0
    //     0x83ece8: str             x0, [SP, #-8]!
    // 0x83ecec: r0 = _opacity()
    //     0x83ecec: bl              #0x83edf0  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_opacity
    // 0x83ecf0: add             SP, SP, #8
    // 0x83ecf4: mov             x1, x0
    // 0x83ecf8: ldr             x0, [fp, #0x18]
    // 0x83ecfc: stur            x1, [fp, #-0x18]
    // 0x83ed00: LoadField: r2 = r0->field_b
    //     0x83ed00: ldur            w2, [x0, #0xb]
    // 0x83ed04: DecompressPointer r2
    //     0x83ed04: add             x2, x2, HEAP, lsl #32
    // 0x83ed08: cmp             w2, NULL
    // 0x83ed0c: b.eq            #0x83edec
    // 0x83ed10: LoadField: r0 = r2->field_17
    //     0x83ed10: ldur            w0, [x2, #0x17]
    // 0x83ed14: DecompressPointer r0
    //     0x83ed14: add             x0, x0, HEAP, lsl #32
    // 0x83ed18: stur            x0, [fp, #-0x10]
    // 0x83ed1c: LoadField: r3 = r2->field_1b
    //     0x83ed1c: ldur            w3, [x2, #0x1b]
    // 0x83ed20: DecompressPointer r3
    //     0x83ed20: add             x3, x3, HEAP, lsl #32
    // 0x83ed24: LoadField: d0 = r3->field_7
    //     0x83ed24: ldur            d0, [x3, #7]
    // 0x83ed28: stur            d0, [fp, #-0x38]
    // 0x83ed2c: LoadField: d1 = r3->field_f
    //     0x83ed2c: ldur            d1, [x3, #0xf]
    // 0x83ed30: stur            d1, [fp, #-0x30]
    // 0x83ed34: r0 = Offset()
    //     0x83ed34: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x83ed38: ldur            d0, [fp, #-0x38]
    // 0x83ed3c: StoreField: r0->field_7 = d0
    //     0x83ed3c: stur            d0, [x0, #7]
    // 0x83ed40: ldur            d0, [fp, #-0x30]
    // 0x83ed44: StoreField: r0->field_f = d0
    //     0x83ed44: stur            d0, [x0, #0xf]
    // 0x83ed48: SaveReg r0
    //     0x83ed48: str             x0, [SP, #-8]!
    // 0x83ed4c: r0 = unary-()
    //     0x83ed4c: bl              #0x622a88  ; [dart:ui] Offset::unary-
    // 0x83ed50: add             SP, SP, #8
    // 0x83ed54: ldur            x2, [fp, #-8]
    // 0x83ed58: r1 = Function '<anonymous closure>':.
    //     0x83ed58: add             x1, PP, #0x53, lsl #12  ; [pp+0x53308] AnonymousClosure: (0x83ee28), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::build (0x83ecb8)
    //     0x83ed5c: ldr             x1, [x1, #0x308]
    // 0x83ed60: stur            x0, [fp, #-8]
    // 0x83ed64: r0 = AllocateClosure()
    //     0x83ed64: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83ed68: stur            x0, [fp, #-0x20]
    // 0x83ed6c: r0 = Builder()
    //     0x83ed6c: bl              #0x830cbc  ; AllocateBuilderStub -> Builder (size=0x10)
    // 0x83ed70: mov             x1, x0
    // 0x83ed74: ldur            x0, [fp, #-0x20]
    // 0x83ed78: stur            x1, [fp, #-0x28]
    // 0x83ed7c: StoreField: r1->field_b = r0
    //     0x83ed7c: stur            w0, [x1, #0xb]
    // 0x83ed80: r0 = CompositedTransformFollower()
    //     0x83ed80: bl              #0x6efd60  ; AllocateCompositedTransformFollowerStub -> CompositedTransformFollower (size=0x24)
    // 0x83ed84: mov             x1, x0
    // 0x83ed88: ldur            x0, [fp, #-0x10]
    // 0x83ed8c: stur            x1, [fp, #-0x20]
    // 0x83ed90: StoreField: r1->field_f = r0
    //     0x83ed90: stur            w0, [x1, #0xf]
    // 0x83ed94: r0 = false
    //     0x83ed94: add             x0, NULL, #0x30  ; false
    // 0x83ed98: StoreField: r1->field_13 = r0
    //     0x83ed98: stur            w0, [x1, #0x13]
    // 0x83ed9c: ldur            x2, [fp, #-8]
    // 0x83eda0: StoreField: r1->field_1f = r2
    //     0x83eda0: stur            w2, [x1, #0x1f]
    // 0x83eda4: r2 = Instance_Alignment
    //     0x83eda4: add             x2, PP, #0x2a, lsl #12  ; [pp+0x2abd0] Obj!Alignment@b37ad1
    //     0x83eda8: ldr             x2, [x2, #0xbd0]
    // 0x83edac: StoreField: r1->field_17 = r2
    //     0x83edac: stur            w2, [x1, #0x17]
    // 0x83edb0: StoreField: r1->field_1b = r2
    //     0x83edb0: stur            w2, [x1, #0x1b]
    // 0x83edb4: ldur            x2, [fp, #-0x28]
    // 0x83edb8: StoreField: r1->field_b = r2
    //     0x83edb8: stur            w2, [x1, #0xb]
    // 0x83edbc: r0 = FadeTransition()
    //     0x83edbc: bl              #0x7b43dc  ; AllocateFadeTransitionStub -> FadeTransition (size=0x18)
    // 0x83edc0: ldur            x1, [fp, #-0x18]
    // 0x83edc4: StoreField: r0->field_f = r1
    //     0x83edc4: stur            w1, [x0, #0xf]
    // 0x83edc8: r1 = false
    //     0x83edc8: add             x1, NULL, #0x30  ; false
    // 0x83edcc: StoreField: r0->field_13 = r1
    //     0x83edcc: stur            w1, [x0, #0x13]
    // 0x83edd0: ldur            x1, [fp, #-0x20]
    // 0x83edd4: StoreField: r0->field_b = r1
    //     0x83edd4: stur            w1, [x0, #0xb]
    // 0x83edd8: LeaveFrame
    //     0x83edd8: mov             SP, fp
    //     0x83eddc: ldp             fp, lr, [SP], #0x10
    // 0x83ede0: ret
    //     0x83ede0: ret             
    // 0x83ede4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ede4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83ede8: b               #0x83ecd0
    // 0x83edec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83edec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _opacity(/* No info */) {
    // ** addr: 0x83edf0, size: 0x38
    // 0x83edf0: EnterFrame
    //     0x83edf0: stp             fp, lr, [SP, #-0x10]!
    //     0x83edf4: mov             fp, SP
    // 0x83edf8: ldr             x1, [fp, #0x10]
    // 0x83edfc: LoadField: r0 = r1->field_1b
    //     0x83edfc: ldur            w0, [x1, #0x1b]
    // 0x83ee00: DecompressPointer r0
    //     0x83ee00: add             x0, x0, HEAP, lsl #32
    // 0x83ee04: r16 = Sentinel
    //     0x83ee04: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x83ee08: cmp             w0, w16
    // 0x83ee0c: b.eq            #0x83ee1c
    // 0x83ee10: LeaveFrame
    //     0x83ee10: mov             SP, fp
    //     0x83ee14: ldp             fp, lr, [SP], #0x10
    // 0x83ee18: ret
    //     0x83ee18: ret             
    // 0x83ee1c: r9 = _controller
    //     0x83ee1c: add             x9, PP, #0x53, lsl #12  ; [pp+0x53310] Field <_SelectionToolbarOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0x83ee20: ldr             x9, [x9, #0x310]
    // 0x83ee24: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x83ee24: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Widget <anonymous closure>(dynamic, BuildContext) {
    // ** addr: 0x83ee28, size: 0xc8
    // 0x83ee28: EnterFrame
    //     0x83ee28: stp             fp, lr, [SP, #-0x10]!
    //     0x83ee2c: mov             fp, SP
    // 0x83ee30: ldr             x0, [fp, #0x18]
    // 0x83ee34: LoadField: r1 = r0->field_17
    //     0x83ee34: ldur            w1, [x0, #0x17]
    // 0x83ee38: DecompressPointer r1
    //     0x83ee38: add             x1, x1, HEAP, lsl #32
    // 0x83ee3c: CheckStackOverflow
    //     0x83ee3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83ee40: cmp             SP, x16
    //     0x83ee44: b.ls            #0x83eee0
    // 0x83ee48: LoadField: r0 = r1->field_f
    //     0x83ee48: ldur            w0, [x1, #0xf]
    // 0x83ee4c: DecompressPointer r0
    //     0x83ee4c: add             x0, x0, HEAP, lsl #32
    // 0x83ee50: LoadField: r1 = r0->field_b
    //     0x83ee50: ldur            w1, [x0, #0xb]
    // 0x83ee54: DecompressPointer r1
    //     0x83ee54: add             x1, x1, HEAP, lsl #32
    // 0x83ee58: cmp             w1, NULL
    // 0x83ee5c: b.eq            #0x83eee8
    // 0x83ee60: LoadField: r0 = r1->field_1f
    //     0x83ee60: ldur            w0, [x1, #0x1f]
    // 0x83ee64: DecompressPointer r0
    //     0x83ee64: add             x0, x0, HEAP, lsl #32
    // 0x83ee68: cmp             w0, NULL
    // 0x83ee6c: b.eq            #0x83eeec
    // 0x83ee70: LoadField: r2 = r1->field_1b
    //     0x83ee70: ldur            w2, [x1, #0x1b]
    // 0x83ee74: DecompressPointer r2
    //     0x83ee74: add             x2, x2, HEAP, lsl #32
    // 0x83ee78: LoadField: d0 = r1->field_b
    //     0x83ee78: ldur            d0, [x1, #0xb]
    // 0x83ee7c: LoadField: r3 = r1->field_27
    //     0x83ee7c: ldur            w3, [x1, #0x27]
    // 0x83ee80: DecompressPointer r3
    //     0x83ee80: add             x3, x3, HEAP, lsl #32
    // 0x83ee84: LoadField: r4 = r1->field_2b
    //     0x83ee84: ldur            w4, [x1, #0x2b]
    // 0x83ee88: DecompressPointer r4
    //     0x83ee88: add             x4, x4, HEAP, lsl #32
    // 0x83ee8c: LoadField: r5 = r1->field_2f
    //     0x83ee8c: ldur            w5, [x1, #0x2f]
    // 0x83ee90: DecompressPointer r5
    //     0x83ee90: add             x5, x5, HEAP, lsl #32
    // 0x83ee94: LoadField: r6 = r1->field_33
    //     0x83ee94: ldur            w6, [x1, #0x33]
    // 0x83ee98: DecompressPointer r6
    //     0x83ee98: add             x6, x6, HEAP, lsl #32
    // 0x83ee9c: LoadField: r7 = r1->field_13
    //     0x83ee9c: ldur            w7, [x1, #0x13]
    // 0x83eea0: DecompressPointer r7
    //     0x83eea0: add             x7, x7, HEAP, lsl #32
    // 0x83eea4: r1 = LoadClassIdInstr(r0)
    //     0x83eea4: ldur            x1, [x0, #-1]
    //     0x83eea8: ubfx            x1, x1, #0xc, #0x14
    // 0x83eeac: stp             x2, x0, [SP, #-0x10]!
    // 0x83eeb0: SaveReg d0
    //     0x83eeb0: str             d0, [SP, #-8]!
    // 0x83eeb4: stp             x4, x3, [SP, #-0x10]!
    // 0x83eeb8: stp             x6, x5, [SP, #-0x10]!
    // 0x83eebc: SaveReg r7
    //     0x83eebc: str             x7, [SP, #-8]!
    // 0x83eec0: mov             x0, x1
    // 0x83eec4: r0 = GDT[cid_x0 + 0xad4]()
    //     0x83eec4: add             lr, x0, #0xad4
    //     0x83eec8: ldr             lr, [x21, lr, lsl #3]
    //     0x83eecc: blr             lr
    // 0x83eed0: add             SP, SP, #0x40
    // 0x83eed4: LeaveFrame
    //     0x83eed4: mov             SP, fp
    //     0x83eed8: ldp             fp, lr, [SP], #0x10
    // 0x83eedc: ret
    //     0x83eedc: ret             
    // 0x83eee0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83eee0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83eee4: b               #0x83ee48
    // 0x83eee8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83eee8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x83eeec: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83eeec: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d72c4, size: 0xe8
    // 0x9d72c4: EnterFrame
    //     0x9d72c4: stp             fp, lr, [SP, #-0x10]!
    //     0x9d72c8: mov             fp, SP
    // 0x9d72cc: AllocStack(0x8)
    //     0x9d72cc: sub             SP, SP, #8
    // 0x9d72d0: CheckStackOverflow
    //     0x9d72d0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d72d4: cmp             SP, x16
    //     0x9d72d8: b.ls            #0x9d73a0
    // 0x9d72dc: r1 = <double>
    //     0x9d72dc: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d72e0: r0 = AnimationController()
    //     0x9d72e0: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d72e4: stur            x0, [fp, #-8]
    // 0x9d72e8: ldr             x16, [fp, #0x10]
    // 0x9d72ec: stp             x16, x0, [SP, #-0x10]!
    // 0x9d72f0: r16 = Instance_Duration
    //     0x9d72f0: add             x16, PP, #0x20, lsl #12  ; [pp+0x20968] Obj!Duration@b67b41
    //     0x9d72f4: ldr             x16, [x16, #0x968]
    // 0x9d72f8: SaveReg r16
    //     0x9d72f8: str             x16, [SP, #-8]!
    // 0x9d72fc: r4 = const [0, 0x3, 0x3, 0x2, duration, 0x2, null]
    //     0x9d72fc: add             x4, PP, #0x1d, lsl #12  ; [pp+0x1d0a0] List(7) [0, 0x3, 0x3, 0x2, "duration", 0x2, Null]
    //     0x9d7300: ldr             x4, [x4, #0xa0]
    // 0x9d7304: r0 = AnimationController()
    //     0x9d7304: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d7308: add             SP, SP, #0x18
    // 0x9d730c: ldur            x0, [fp, #-8]
    // 0x9d7310: ldr             x1, [fp, #0x10]
    // 0x9d7314: StoreField: r1->field_1b = r0
    //     0x9d7314: stur            w0, [x1, #0x1b]
    //     0x9d7318: ldurb           w16, [x1, #-1]
    //     0x9d731c: ldurb           w17, [x0, #-1]
    //     0x9d7320: and             x16, x17, x16, lsr #2
    //     0x9d7324: tst             x16, HEAP, lsr #32
    //     0x9d7328: b.eq            #0x9d7330
    //     0x9d732c: bl              #0xd6826c
    // 0x9d7330: SaveReg r1
    //     0x9d7330: str             x1, [SP, #-8]!
    // 0x9d7334: r0 = _toolbarVisibilityChanged()
    //     0x9d7334: bl              #0x7ae81c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged
    // 0x9d7338: add             SP, SP, #8
    // 0x9d733c: ldr             x0, [fp, #0x10]
    // 0x9d7340: LoadField: r1 = r0->field_b
    //     0x9d7340: ldur            w1, [x0, #0xb]
    // 0x9d7344: DecompressPointer r1
    //     0x9d7344: add             x1, x1, HEAP, lsl #32
    // 0x9d7348: cmp             w1, NULL
    // 0x9d734c: b.eq            #0x9d73a8
    // 0x9d7350: LoadField: r2 = r1->field_23
    //     0x9d7350: ldur            w2, [x1, #0x23]
    // 0x9d7354: DecompressPointer r2
    //     0x9d7354: add             x2, x2, HEAP, lsl #32
    // 0x9d7358: stur            x2, [fp, #-8]
    // 0x9d735c: r1 = 1
    //     0x9d735c: mov             x1, #1
    // 0x9d7360: r0 = AllocateContext()
    //     0x9d7360: bl              #0xd68aa4  ; AllocateContextStub
    // 0x9d7364: mov             x1, x0
    // 0x9d7368: ldr             x0, [fp, #0x10]
    // 0x9d736c: StoreField: r1->field_f = r0
    //     0x9d736c: stur            w0, [x1, #0xf]
    // 0x9d7370: mov             x2, x1
    // 0x9d7374: r1 = Function '_toolbarVisibilityChanged@500251836':.
    //     0x9d7374: add             x1, PP, #0x53, lsl #12  ; [pp+0x53318] AnonymousClosure: (0x7ae8e0), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged (0x7ae81c)
    //     0x9d7378: ldr             x1, [x1, #0x318]
    // 0x9d737c: r0 = AllocateClosure()
    //     0x9d737c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x9d7380: ldur            x16, [fp, #-8]
    // 0x9d7384: stp             x0, x16, [SP, #-0x10]!
    // 0x9d7388: r0 = addListener()
    //     0x9d7388: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x9d738c: add             SP, SP, #0x10
    // 0x9d7390: r0 = Null
    //     0x9d7390: mov             x0, NULL
    // 0x9d7394: LeaveFrame
    //     0x9d7394: mov             SP, fp
    //     0x9d7398: ldp             fp, lr, [SP], #0x10
    // 0x9d739c: ret
    //     0x9d739c: ret             
    // 0x9d73a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d73a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d73a4: b               #0x9d72dc
    // 0x9d73a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d73a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a468, size: 0x18
    // 0xa4a468: r4 = 7
    //     0xa4a468: mov             x4, #7
    // 0xa4a46c: r1 = Function 'dispose':.
    //     0xa4a46c: add             x17, PP, #0x53, lsl #12  ; [pp+0x53300] AnonymousClosure: (0xa4a480), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::dispose (0xa4febc)
    //     0xa4a470: ldr             x1, [x17, #0x300]
    // 0xa4a474: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a474: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a478: LoadField: r0 = r24->field_17
    //     0xa4a478: ldur            x0, [x24, #0x17]
    // 0xa4a47c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a480, size: 0x48
    // 0xa4a480: EnterFrame
    //     0xa4a480: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a484: mov             fp, SP
    // 0xa4a488: ldr             x0, [fp, #0x10]
    // 0xa4a48c: LoadField: r1 = r0->field_17
    //     0xa4a48c: ldur            w1, [x0, #0x17]
    // 0xa4a490: DecompressPointer r1
    //     0xa4a490: add             x1, x1, HEAP, lsl #32
    // 0xa4a494: CheckStackOverflow
    //     0xa4a494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a498: cmp             SP, x16
    //     0xa4a49c: b.ls            #0xa4a4c0
    // 0xa4a4a0: LoadField: r0 = r1->field_f
    //     0xa4a4a0: ldur            w0, [x1, #0xf]
    // 0xa4a4a4: DecompressPointer r0
    //     0xa4a4a4: add             x0, x0, HEAP, lsl #32
    // 0xa4a4a8: SaveReg r0
    //     0xa4a4a8: str             x0, [SP, #-8]!
    // 0xa4a4ac: r0 = dispose()
    //     0xa4a4ac: bl              #0xa4febc  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::dispose
    // 0xa4a4b0: add             SP, SP, #8
    // 0xa4a4b4: LeaveFrame
    //     0xa4a4b4: mov             SP, fp
    //     0xa4a4b8: ldp             fp, lr, [SP], #0x10
    // 0xa4a4bc: ret
    //     0xa4a4bc: ret             
    // 0xa4a4c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a4c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a4c4: b               #0xa4a4a0
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4febc, size: 0xc8
    // 0xa4febc: EnterFrame
    //     0xa4febc: stp             fp, lr, [SP, #-0x10]!
    //     0xa4fec0: mov             fp, SP
    // 0xa4fec4: AllocStack(0x8)
    //     0xa4fec4: sub             SP, SP, #8
    // 0xa4fec8: CheckStackOverflow
    //     0xa4fec8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4fecc: cmp             SP, x16
    //     0xa4fed0: b.ls            #0xa4ff6c
    // 0xa4fed4: ldr             x0, [fp, #0x10]
    // 0xa4fed8: LoadField: r1 = r0->field_b
    //     0xa4fed8: ldur            w1, [x0, #0xb]
    // 0xa4fedc: DecompressPointer r1
    //     0xa4fedc: add             x1, x1, HEAP, lsl #32
    // 0xa4fee0: cmp             w1, NULL
    // 0xa4fee4: b.eq            #0xa4ff74
    // 0xa4fee8: LoadField: r2 = r1->field_23
    //     0xa4fee8: ldur            w2, [x1, #0x23]
    // 0xa4feec: DecompressPointer r2
    //     0xa4feec: add             x2, x2, HEAP, lsl #32
    // 0xa4fef0: stur            x2, [fp, #-8]
    // 0xa4fef4: r1 = 1
    //     0xa4fef4: mov             x1, #1
    // 0xa4fef8: r0 = AllocateContext()
    //     0xa4fef8: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4fefc: mov             x1, x0
    // 0xa4ff00: ldr             x0, [fp, #0x10]
    // 0xa4ff04: StoreField: r1->field_f = r0
    //     0xa4ff04: stur            w0, [x1, #0xf]
    // 0xa4ff08: mov             x2, x1
    // 0xa4ff0c: r1 = Function '_toolbarVisibilityChanged@500251836':.
    //     0xa4ff0c: add             x1, PP, #0x53, lsl #12  ; [pp+0x53318] AnonymousClosure: (0x7ae8e0), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] _SelectionToolbarOverlayState::_toolbarVisibilityChanged (0x7ae81c)
    //     0xa4ff10: ldr             x1, [x1, #0x318]
    // 0xa4ff14: r0 = AllocateClosure()
    //     0xa4ff14: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4ff18: ldur            x16, [fp, #-8]
    // 0xa4ff1c: stp             x0, x16, [SP, #-0x10]!
    // 0xa4ff20: r0 = removeListener()
    //     0xa4ff20: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4ff24: add             SP, SP, #0x10
    // 0xa4ff28: ldr             x0, [fp, #0x10]
    // 0xa4ff2c: LoadField: r1 = r0->field_1b
    //     0xa4ff2c: ldur            w1, [x0, #0x1b]
    // 0xa4ff30: DecompressPointer r1
    //     0xa4ff30: add             x1, x1, HEAP, lsl #32
    // 0xa4ff34: r16 = Sentinel
    //     0xa4ff34: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4ff38: cmp             w1, w16
    // 0xa4ff3c: b.eq            #0xa4ff78
    // 0xa4ff40: SaveReg r1
    //     0xa4ff40: str             x1, [SP, #-8]!
    // 0xa4ff44: r0 = dispose()
    //     0xa4ff44: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa4ff48: add             SP, SP, #8
    // 0xa4ff4c: ldr             x16, [fp, #0x10]
    // 0xa4ff50: SaveReg r16
    //     0xa4ff50: str             x16, [SP, #-8]!
    // 0xa4ff54: r0 = dispose()
    //     0xa4ff54: bl              #0xa4ff84  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] __SelectionToolbarOverlayState&State&SingleTickerProviderStateMixin::dispose
    // 0xa4ff58: add             SP, SP, #8
    // 0xa4ff5c: r0 = Null
    //     0xa4ff5c: mov             x0, NULL
    // 0xa4ff60: LeaveFrame
    //     0xa4ff60: mov             SP, fp
    //     0xa4ff64: ldp             fp, lr, [SP], #0x10
    // 0xa4ff68: ret
    //     0xa4ff68: ret             
    // 0xa4ff6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4ff6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4ff70: b               #0xa4fed4
    // 0xa4ff74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xa4ff74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xa4ff78: r9 = _controller
    //     0xa4ff78: add             x9, PP, #0x53, lsl #12  ; [pp+0x53310] Field <_SelectionToolbarOverlayState@500251836._controller@500251836>: late (offset: 0x1c)
    //     0xa4ff7c: ldr             x9, [x9, #0x310]
    // 0xa4ff80: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4ff80: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4186, size: 0x38, field offset: 0xc
//   const constructor, 
class _SelectionHandleOverlay extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fb74, size: 0x28
    // 0xa3fb74: EnterFrame
    //     0xa3fb74: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fb78: mov             fp, SP
    // 0xa3fb7c: r1 = <_SelectionHandleOverlay>
    //     0xa3fb7c: add             x1, PP, #0x40, lsl #12  ; [pp+0x40a60] TypeArguments: <_SelectionHandleOverlay>
    //     0xa3fb80: ldr             x1, [x1, #0xa60]
    // 0xa3fb84: r0 = _SelectionHandleOverlayState()
    //     0xa3fb84: bl              #0xa3fb9c  ; Allocate_SelectionHandleOverlayStateStub -> _SelectionHandleOverlayState (size=0x20)
    // 0xa3fb88: r1 = Sentinel
    //     0xa3fb88: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fb8c: StoreField: r0->field_1b = r1
    //     0xa3fb8c: stur            w1, [x0, #0x1b]
    // 0xa3fb90: LeaveFrame
    //     0xa3fb90: mov             SP, fp
    //     0xa3fb94: ldp             fp, lr, [SP], #0x10
    // 0xa3fb98: ret
    //     0xa3fb98: ret             
  }
}

// class id: 4187, size: 0x38, field offset: 0xc
//   const constructor, 
class _SelectionToolbarOverlay extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fb40, size: 0x28
    // 0xa3fb40: EnterFrame
    //     0xa3fb40: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fb44: mov             fp, SP
    // 0xa3fb48: r1 = <_SelectionToolbarOverlay>
    //     0xa3fb48: add             x1, PP, #0x51, lsl #12  ; [pp+0x510c0] TypeArguments: <_SelectionToolbarOverlay>
    //     0xa3fb4c: ldr             x1, [x1, #0xc0]
    // 0xa3fb50: r0 = _SelectionToolbarOverlayState()
    //     0xa3fb50: bl              #0xa3fb68  ; Allocate_SelectionToolbarOverlayStateStub -> _SelectionToolbarOverlayState (size=0x20)
    // 0xa3fb54: r1 = Sentinel
    //     0xa3fb54: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3fb58: StoreField: r0->field_1b = r1
    //     0xa3fb58: stur            w1, [x0, #0x1b]
    // 0xa3fb5c: LeaveFrame
    //     0xa3fb5c: mov             SP, fp
    //     0xa3fb60: ldp             fp, lr, [SP], #0x10
    // 0xa3fb64: ret
    //     0xa3fb64: ret             
  }
}

// class id: 4431, size: 0x80, field offset: 0x8
class SelectionOverlay extends Object {

  set _ toolbarLocation=(/* No info */) {
    // ** addr: 0x51f170, size: 0xa0
    // 0x51f170: EnterFrame
    //     0x51f170: stp             fp, lr, [SP, #-0x10]!
    //     0x51f174: mov             fp, SP
    // 0x51f178: CheckStackOverflow
    //     0x51f178: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51f17c: cmp             SP, x16
    //     0x51f180: b.ls            #0x51f208
    // 0x51f184: ldr             x1, [fp, #0x18]
    // 0x51f188: LoadField: r0 = r1->field_6f
    //     0x51f188: ldur            w0, [x1, #0x6f]
    // 0x51f18c: DecompressPointer r0
    //     0x51f18c: add             x0, x0, HEAP, lsl #32
    // 0x51f190: r2 = LoadClassIdInstr(r0)
    //     0x51f190: ldur            x2, [x0, #-1]
    //     0x51f194: ubfx            x2, x2, #0xc, #0x14
    // 0x51f198: ldr             x16, [fp, #0x10]
    // 0x51f19c: stp             x16, x0, [SP, #-0x10]!
    // 0x51f1a0: mov             x0, x2
    // 0x51f1a4: mov             lr, x0
    // 0x51f1a8: ldr             lr, [x21, lr, lsl #3]
    // 0x51f1ac: blr             lr
    // 0x51f1b0: add             SP, SP, #0x10
    // 0x51f1b4: tbnz            w0, #4, #0x51f1c8
    // 0x51f1b8: r0 = Null
    //     0x51f1b8: mov             x0, NULL
    // 0x51f1bc: LeaveFrame
    //     0x51f1bc: mov             SP, fp
    //     0x51f1c0: ldp             fp, lr, [SP], #0x10
    // 0x51f1c4: ret
    //     0x51f1c4: ret             
    // 0x51f1c8: ldr             x1, [fp, #0x18]
    // 0x51f1cc: ldr             x0, [fp, #0x10]
    // 0x51f1d0: StoreField: r1->field_6f = r0
    //     0x51f1d0: stur            w0, [x1, #0x6f]
    //     0x51f1d4: ldurb           w16, [x1, #-1]
    //     0x51f1d8: ldurb           w17, [x0, #-1]
    //     0x51f1dc: and             x16, x17, x16, lsr #2
    //     0x51f1e0: tst             x16, HEAP, lsr #32
    //     0x51f1e4: b.eq            #0x51f1ec
    //     0x51f1e8: bl              #0xd6826c
    // 0x51f1ec: SaveReg r1
    //     0x51f1ec: str             x1, [SP, #-8]!
    // 0x51f1f0: r0 = _markNeedsBuild()
    //     0x51f1f0: bl              #0x51f210  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild
    // 0x51f1f4: add             SP, SP, #8
    // 0x51f1f8: r0 = Null
    //     0x51f1f8: mov             x0, NULL
    // 0x51f1fc: LeaveFrame
    //     0x51f1fc: mov             SP, fp
    //     0x51f200: ldp             fp, lr, [SP], #0x10
    // 0x51f204: ret
    //     0x51f204: ret             
    // 0x51f208: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51f208: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51f20c: b               #0x51f184
  }
  _ _markNeedsBuild(/* No info */) {
    // ** addr: 0x51f210, size: 0x284
    // 0x51f210: EnterFrame
    //     0x51f210: stp             fp, lr, [SP, #-0x10]!
    //     0x51f214: mov             fp, SP
    // 0x51f218: AllocStack(0x18)
    //     0x51f218: sub             SP, SP, #0x18
    // 0x51f21c: CheckStackOverflow
    //     0x51f21c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51f220: cmp             SP, x16
    //     0x51f224: b.ls            #0x51f478
    // 0x51f228: r1 = 1
    //     0x51f228: mov             x1, #1
    // 0x51f22c: r0 = AllocateContext()
    //     0x51f22c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x51f230: ldr             x2, [fp, #0x10]
    // 0x51f234: StoreField: r0->field_f = r2
    //     0x51f234: stur            w2, [x0, #0xf]
    // 0x51f238: LoadField: r3 = r2->field_73
    //     0x51f238: ldur            w3, [x2, #0x73]
    // 0x51f23c: DecompressPointer r3
    //     0x51f23c: add             x3, x3, HEAP, lsl #32
    // 0x51f240: cmp             w3, NULL
    // 0x51f244: b.ne            #0x51f268
    // 0x51f248: LoadField: r1 = r2->field_77
    //     0x51f248: ldur            w1, [x2, #0x77]
    // 0x51f24c: DecompressPointer r1
    //     0x51f24c: add             x1, x1, HEAP, lsl #32
    // 0x51f250: cmp             w1, NULL
    // 0x51f254: b.ne            #0x51f268
    // 0x51f258: r0 = Null
    //     0x51f258: mov             x0, NULL
    // 0x51f25c: LeaveFrame
    //     0x51f25c: mov             SP, fp
    //     0x51f260: ldp             fp, lr, [SP], #0x10
    // 0x51f264: ret
    //     0x51f264: ret             
    // 0x51f268: r1 = LoadStaticField(0xf10)
    //     0x51f268: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0x51f26c: ldr             x1, [x1, #0x1e20]
    // 0x51f270: cmp             w1, NULL
    // 0x51f274: b.eq            #0x51f480
    // 0x51f278: LoadField: r4 = r1->field_63
    //     0x51f278: ldur            w4, [x1, #0x63]
    // 0x51f27c: DecompressPointer r4
    //     0x51f27c: add             x4, x4, HEAP, lsl #32
    // 0x51f280: r16 = Instance_SchedulerPhase
    //     0x51f280: ldr             x16, [PP, #0x3780]  ; [pp+0x3780] Obj!SchedulerPhase@b645b1
    // 0x51f284: cmp             w4, w16
    // 0x51f288: b.ne            #0x51f39c
    // 0x51f28c: LoadField: r3 = r2->field_7b
    //     0x51f28c: ldur            w3, [x2, #0x7b]
    // 0x51f290: DecompressPointer r3
    //     0x51f290: add             x3, x3, HEAP, lsl #32
    // 0x51f294: tbnz            w3, #4, #0x51f2a8
    // 0x51f298: r0 = Null
    //     0x51f298: mov             x0, NULL
    // 0x51f29c: LeaveFrame
    //     0x51f29c: mov             SP, fp
    //     0x51f2a0: ldp             fp, lr, [SP], #0x10
    // 0x51f2a4: ret
    //     0x51f2a4: ret             
    // 0x51f2a8: r3 = true
    //     0x51f2a8: add             x3, NULL, #0x20  ; true
    // 0x51f2ac: StoreField: r2->field_7b = r3
    //     0x51f2ac: stur            w3, [x2, #0x7b]
    // 0x51f2b0: LoadField: r3 = r1->field_57
    //     0x51f2b0: ldur            w3, [x1, #0x57]
    // 0x51f2b4: DecompressPointer r3
    //     0x51f2b4: add             x3, x3, HEAP, lsl #32
    // 0x51f2b8: stur            x3, [fp, #-0x10]
    // 0x51f2bc: LoadField: r4 = r3->field_7
    //     0x51f2bc: ldur            w4, [x3, #7]
    // 0x51f2c0: DecompressPointer r4
    //     0x51f2c0: add             x4, x4, HEAP, lsl #32
    // 0x51f2c4: mov             x2, x0
    // 0x51f2c8: stur            x4, [fp, #-8]
    // 0x51f2cc: r1 = Function '<anonymous closure>':.
    //     0x51f2cc: add             x1, PP, #0x37, lsl #12  ; [pp+0x37400] AnonymousClosure: (0x51f494), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild (0x51f210)
    //     0x51f2d0: ldr             x1, [x1, #0x400]
    // 0x51f2d4: r0 = AllocateClosure()
    //     0x51f2d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x51f2d8: ldur            x2, [fp, #-8]
    // 0x51f2dc: mov             x3, x0
    // 0x51f2e0: r1 = Null
    //     0x51f2e0: mov             x1, NULL
    // 0x51f2e4: stur            x3, [fp, #-8]
    // 0x51f2e8: cmp             w2, NULL
    // 0x51f2ec: b.eq            #0x51f30c
    // 0x51f2f0: LoadField: r4 = r2->field_17
    //     0x51f2f0: ldur            w4, [x2, #0x17]
    // 0x51f2f4: DecompressPointer r4
    //     0x51f2f4: add             x4, x4, HEAP, lsl #32
    // 0x51f2f8: r8 = X0
    //     0x51f2f8: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x51f2fc: LoadField: r9 = r4->field_7
    //     0x51f2fc: ldur            x9, [x4, #7]
    // 0x51f300: r3 = Null
    //     0x51f300: add             x3, PP, #0x37, lsl #12  ; [pp+0x37408] Null
    //     0x51f304: ldr             x3, [x3, #0x408]
    // 0x51f308: blr             x9
    // 0x51f30c: ldur            x0, [fp, #-0x10]
    // 0x51f310: LoadField: r1 = r0->field_b
    //     0x51f310: ldur            w1, [x0, #0xb]
    // 0x51f314: DecompressPointer r1
    //     0x51f314: add             x1, x1, HEAP, lsl #32
    // 0x51f318: stur            x1, [fp, #-0x18]
    // 0x51f31c: LoadField: r2 = r0->field_f
    //     0x51f31c: ldur            w2, [x0, #0xf]
    // 0x51f320: DecompressPointer r2
    //     0x51f320: add             x2, x2, HEAP, lsl #32
    // 0x51f324: LoadField: r3 = r2->field_b
    //     0x51f324: ldur            w3, [x2, #0xb]
    // 0x51f328: DecompressPointer r3
    //     0x51f328: add             x3, x3, HEAP, lsl #32
    // 0x51f32c: cmp             w1, w3
    // 0x51f330: b.ne            #0x51f340
    // 0x51f334: SaveReg r0
    //     0x51f334: str             x0, [SP, #-8]!
    // 0x51f338: r0 = _growToNextCapacity()
    //     0x51f338: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x51f33c: add             SP, SP, #8
    // 0x51f340: ldur            x2, [fp, #-0x10]
    // 0x51f344: ldur            x0, [fp, #-0x18]
    // 0x51f348: r3 = LoadInt32Instr(r0)
    //     0x51f348: sbfx            x3, x0, #1, #0x1f
    // 0x51f34c: add             x0, x3, #1
    // 0x51f350: lsl             x1, x0, #1
    // 0x51f354: StoreField: r2->field_b = r1
    //     0x51f354: stur            w1, [x2, #0xb]
    // 0x51f358: mov             x1, x3
    // 0x51f35c: cmp             x1, x0
    // 0x51f360: b.hs            #0x51f484
    // 0x51f364: LoadField: r1 = r2->field_f
    //     0x51f364: ldur            w1, [x2, #0xf]
    // 0x51f368: DecompressPointer r1
    //     0x51f368: add             x1, x1, HEAP, lsl #32
    // 0x51f36c: ldur            x0, [fp, #-8]
    // 0x51f370: ArrayStore: r1[r3] = r0  ; List_4
    //     0x51f370: add             x25, x1, x3, lsl #2
    //     0x51f374: add             x25, x25, #0xf
    //     0x51f378: str             w0, [x25]
    //     0x51f37c: tbz             w0, #0, #0x51f398
    //     0x51f380: ldurb           w16, [x1, #-1]
    //     0x51f384: ldurb           w17, [x0, #-1]
    //     0x51f388: and             x16, x17, x16, lsr #2
    //     0x51f38c: tst             x16, HEAP, lsr #32
    //     0x51f390: b.eq            #0x51f398
    //     0x51f394: bl              #0xd67e5c
    // 0x51f398: b               #0x51f468
    // 0x51f39c: cmp             w3, NULL
    // 0x51f3a0: b.eq            #0x51f448
    // 0x51f3a4: LoadField: r0 = r3->field_b
    //     0x51f3a4: ldur            w0, [x3, #0xb]
    // 0x51f3a8: DecompressPointer r0
    //     0x51f3a8: add             x0, x0, HEAP, lsl #32
    // 0x51f3ac: r1 = LoadInt32Instr(r0)
    //     0x51f3ac: sbfx            x1, x0, #1, #0x1f
    // 0x51f3b0: mov             x0, x1
    // 0x51f3b4: r1 = 0
    //     0x51f3b4: mov             x1, #0
    // 0x51f3b8: cmp             x1, x0
    // 0x51f3bc: b.hs            #0x51f488
    // 0x51f3c0: LoadField: r0 = r3->field_f
    //     0x51f3c0: ldur            w0, [x3, #0xf]
    // 0x51f3c4: DecompressPointer r0
    //     0x51f3c4: add             x0, x0, HEAP, lsl #32
    // 0x51f3c8: LoadField: r1 = r0->field_f
    //     0x51f3c8: ldur            w1, [x0, #0xf]
    // 0x51f3cc: DecompressPointer r1
    //     0x51f3cc: add             x1, x1, HEAP, lsl #32
    // 0x51f3d0: r0 = LoadClassIdInstr(r1)
    //     0x51f3d0: ldur            x0, [x1, #-1]
    //     0x51f3d4: ubfx            x0, x0, #0xc, #0x14
    // 0x51f3d8: SaveReg r1
    //     0x51f3d8: str             x1, [SP, #-8]!
    // 0x51f3dc: r0 = GDT[cid_x0 + -0x1000]()
    //     0x51f3dc: sub             lr, x0, #1, lsl #12
    //     0x51f3e0: ldr             lr, [x21, lr, lsl #3]
    //     0x51f3e4: blr             lr
    // 0x51f3e8: add             SP, SP, #8
    // 0x51f3ec: ldr             x2, [fp, #0x10]
    // 0x51f3f0: LoadField: r3 = r2->field_73
    //     0x51f3f0: ldur            w3, [x2, #0x73]
    // 0x51f3f4: DecompressPointer r3
    //     0x51f3f4: add             x3, x3, HEAP, lsl #32
    // 0x51f3f8: cmp             w3, NULL
    // 0x51f3fc: b.eq            #0x51f48c
    // 0x51f400: LoadField: r0 = r3->field_b
    //     0x51f400: ldur            w0, [x3, #0xb]
    // 0x51f404: DecompressPointer r0
    //     0x51f404: add             x0, x0, HEAP, lsl #32
    // 0x51f408: r1 = LoadInt32Instr(r0)
    //     0x51f408: sbfx            x1, x0, #1, #0x1f
    // 0x51f40c: mov             x0, x1
    // 0x51f410: r1 = 1
    //     0x51f410: mov             x1, #1
    // 0x51f414: cmp             x1, x0
    // 0x51f418: b.hs            #0x51f490
    // 0x51f41c: LoadField: r0 = r3->field_f
    //     0x51f41c: ldur            w0, [x3, #0xf]
    // 0x51f420: DecompressPointer r0
    //     0x51f420: add             x0, x0, HEAP, lsl #32
    // 0x51f424: LoadField: r1 = r0->field_13
    //     0x51f424: ldur            w1, [x0, #0x13]
    // 0x51f428: DecompressPointer r1
    //     0x51f428: add             x1, x1, HEAP, lsl #32
    // 0x51f42c: r0 = LoadClassIdInstr(r1)
    //     0x51f42c: ldur            x0, [x1, #-1]
    //     0x51f430: ubfx            x0, x0, #0xc, #0x14
    // 0x51f434: SaveReg r1
    //     0x51f434: str             x1, [SP, #-8]!
    // 0x51f438: r0 = GDT[cid_x0 + -0x1000]()
    //     0x51f438: sub             lr, x0, #1, lsl #12
    //     0x51f43c: ldr             lr, [x21, lr, lsl #3]
    //     0x51f440: blr             lr
    // 0x51f444: add             SP, SP, #8
    // 0x51f448: ldr             x0, [fp, #0x10]
    // 0x51f44c: LoadField: r1 = r0->field_77
    //     0x51f44c: ldur            w1, [x0, #0x77]
    // 0x51f450: DecompressPointer r1
    //     0x51f450: add             x1, x1, HEAP, lsl #32
    // 0x51f454: cmp             w1, NULL
    // 0x51f458: b.eq            #0x51f468
    // 0x51f45c: SaveReg r1
    //     0x51f45c: str             x1, [SP, #-8]!
    // 0x51f460: r0 = markNeedsBuild()
    //     0x51f460: bl              #0xd0e494  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::markNeedsBuild
    // 0x51f464: add             SP, SP, #8
    // 0x51f468: r0 = Null
    //     0x51f468: mov             x0, NULL
    // 0x51f46c: LeaveFrame
    //     0x51f46c: mov             SP, fp
    //     0x51f470: ldp             fp, lr, [SP], #0x10
    // 0x51f474: ret
    //     0x51f474: ret             
    // 0x51f478: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51f478: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51f47c: b               #0x51f228
    // 0x51f480: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51f480: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x51f484: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x51f484: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x51f488: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x51f488: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x51f48c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51f48c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x51f490: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x51f490: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Duration) {
    // ** addr: 0x51f494, size: 0x140
    // 0x51f494: EnterFrame
    //     0x51f494: stp             fp, lr, [SP, #-0x10]!
    //     0x51f498: mov             fp, SP
    // 0x51f49c: AllocStack(0x8)
    //     0x51f49c: sub             SP, SP, #8
    // 0x51f4a0: SetupParameters()
    //     0x51f4a0: add             x0, NULL, #0x30  ; false
    //     0x51f4a4: ldr             x1, [fp, #0x18]
    //     0x51f4a8: ldur            w2, [x1, #0x17]
    //     0x51f4ac: add             x2, x2, HEAP, lsl #32
    //     0x51f4b0: stur            x2, [fp, #-8]
    // 0x51f4a0: r0 = false
    // 0x51f4b4: CheckStackOverflow
    //     0x51f4b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51f4b8: cmp             SP, x16
    //     0x51f4bc: b.ls            #0x51f5c0
    // 0x51f4c0: LoadField: r1 = r2->field_f
    //     0x51f4c0: ldur            w1, [x2, #0xf]
    // 0x51f4c4: DecompressPointer r1
    //     0x51f4c4: add             x1, x1, HEAP, lsl #32
    // 0x51f4c8: StoreField: r1->field_7b = r0
    //     0x51f4c8: stur            w0, [x1, #0x7b]
    // 0x51f4cc: LoadField: r3 = r1->field_73
    //     0x51f4cc: ldur            w3, [x1, #0x73]
    // 0x51f4d0: DecompressPointer r3
    //     0x51f4d0: add             x3, x3, HEAP, lsl #32
    // 0x51f4d4: cmp             w3, NULL
    // 0x51f4d8: b.eq            #0x51f588
    // 0x51f4dc: LoadField: r0 = r3->field_b
    //     0x51f4dc: ldur            w0, [x3, #0xb]
    // 0x51f4e0: DecompressPointer r0
    //     0x51f4e0: add             x0, x0, HEAP, lsl #32
    // 0x51f4e4: r1 = LoadInt32Instr(r0)
    //     0x51f4e4: sbfx            x1, x0, #1, #0x1f
    // 0x51f4e8: mov             x0, x1
    // 0x51f4ec: r1 = 0
    //     0x51f4ec: mov             x1, #0
    // 0x51f4f0: cmp             x1, x0
    // 0x51f4f4: b.hs            #0x51f5c8
    // 0x51f4f8: LoadField: r0 = r3->field_f
    //     0x51f4f8: ldur            w0, [x3, #0xf]
    // 0x51f4fc: DecompressPointer r0
    //     0x51f4fc: add             x0, x0, HEAP, lsl #32
    // 0x51f500: LoadField: r1 = r0->field_f
    //     0x51f500: ldur            w1, [x0, #0xf]
    // 0x51f504: DecompressPointer r1
    //     0x51f504: add             x1, x1, HEAP, lsl #32
    // 0x51f508: r0 = LoadClassIdInstr(r1)
    //     0x51f508: ldur            x0, [x1, #-1]
    //     0x51f50c: ubfx            x0, x0, #0xc, #0x14
    // 0x51f510: SaveReg r1
    //     0x51f510: str             x1, [SP, #-8]!
    // 0x51f514: r0 = GDT[cid_x0 + -0x1000]()
    //     0x51f514: sub             lr, x0, #1, lsl #12
    //     0x51f518: ldr             lr, [x21, lr, lsl #3]
    //     0x51f51c: blr             lr
    // 0x51f520: add             SP, SP, #8
    // 0x51f524: ldur            x2, [fp, #-8]
    // 0x51f528: LoadField: r0 = r2->field_f
    //     0x51f528: ldur            w0, [x2, #0xf]
    // 0x51f52c: DecompressPointer r0
    //     0x51f52c: add             x0, x0, HEAP, lsl #32
    // 0x51f530: LoadField: r3 = r0->field_73
    //     0x51f530: ldur            w3, [x0, #0x73]
    // 0x51f534: DecompressPointer r3
    //     0x51f534: add             x3, x3, HEAP, lsl #32
    // 0x51f538: cmp             w3, NULL
    // 0x51f53c: b.eq            #0x51f5cc
    // 0x51f540: LoadField: r0 = r3->field_b
    //     0x51f540: ldur            w0, [x3, #0xb]
    // 0x51f544: DecompressPointer r0
    //     0x51f544: add             x0, x0, HEAP, lsl #32
    // 0x51f548: r1 = LoadInt32Instr(r0)
    //     0x51f548: sbfx            x1, x0, #1, #0x1f
    // 0x51f54c: mov             x0, x1
    // 0x51f550: r1 = 1
    //     0x51f550: mov             x1, #1
    // 0x51f554: cmp             x1, x0
    // 0x51f558: b.hs            #0x51f5d0
    // 0x51f55c: LoadField: r0 = r3->field_f
    //     0x51f55c: ldur            w0, [x3, #0xf]
    // 0x51f560: DecompressPointer r0
    //     0x51f560: add             x0, x0, HEAP, lsl #32
    // 0x51f564: LoadField: r1 = r0->field_13
    //     0x51f564: ldur            w1, [x0, #0x13]
    // 0x51f568: DecompressPointer r1
    //     0x51f568: add             x1, x1, HEAP, lsl #32
    // 0x51f56c: r0 = LoadClassIdInstr(r1)
    //     0x51f56c: ldur            x0, [x1, #-1]
    //     0x51f570: ubfx            x0, x0, #0xc, #0x14
    // 0x51f574: SaveReg r1
    //     0x51f574: str             x1, [SP, #-8]!
    // 0x51f578: r0 = GDT[cid_x0 + -0x1000]()
    //     0x51f578: sub             lr, x0, #1, lsl #12
    //     0x51f57c: ldr             lr, [x21, lr, lsl #3]
    //     0x51f580: blr             lr
    // 0x51f584: add             SP, SP, #8
    // 0x51f588: ldur            x0, [fp, #-8]
    // 0x51f58c: LoadField: r1 = r0->field_f
    //     0x51f58c: ldur            w1, [x0, #0xf]
    // 0x51f590: DecompressPointer r1
    //     0x51f590: add             x1, x1, HEAP, lsl #32
    // 0x51f594: LoadField: r0 = r1->field_77
    //     0x51f594: ldur            w0, [x1, #0x77]
    // 0x51f598: DecompressPointer r0
    //     0x51f598: add             x0, x0, HEAP, lsl #32
    // 0x51f59c: cmp             w0, NULL
    // 0x51f5a0: b.eq            #0x51f5b0
    // 0x51f5a4: SaveReg r0
    //     0x51f5a4: str             x0, [SP, #-8]!
    // 0x51f5a8: r0 = markNeedsBuild()
    //     0x51f5a8: bl              #0xd0e494  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::markNeedsBuild
    // 0x51f5ac: add             SP, SP, #8
    // 0x51f5b0: r0 = Null
    //     0x51f5b0: mov             x0, NULL
    // 0x51f5b4: LeaveFrame
    //     0x51f5b4: mov             SP, fp
    //     0x51f5b8: ldp             fp, lr, [SP], #0x10
    // 0x51f5bc: ret
    //     0x51f5bc: ret             
    // 0x51f5c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51f5c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51f5c4: b               #0x51f4c0
    // 0x51f5c8: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x51f5c8: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x51f5cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51f5cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x51f5d0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x51f5d0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  set _ selectionEndPoints=(/* No info */) {
    // ** addr: 0x51f5d4, size: 0x90
    // 0x51f5d4: EnterFrame
    //     0x51f5d4: stp             fp, lr, [SP, #-0x10]!
    //     0x51f5d8: mov             fp, SP
    // 0x51f5dc: CheckStackOverflow
    //     0x51f5dc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51f5e0: cmp             SP, x16
    //     0x51f5e4: b.ls            #0x51f65c
    // 0x51f5e8: ldr             x0, [fp, #0x18]
    // 0x51f5ec: LoadField: r1 = r0->field_47
    //     0x51f5ec: ldur            w1, [x0, #0x47]
    // 0x51f5f0: DecompressPointer r1
    //     0x51f5f0: add             x1, x1, HEAP, lsl #32
    // 0x51f5f4: r16 = <TextSelectionPoint>
    //     0x51f5f4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f468] TypeArguments: <TextSelectionPoint>
    //     0x51f5f8: ldr             x16, [x16, #0x468]
    // 0x51f5fc: stp             x1, x16, [SP, #-0x10]!
    // 0x51f600: ldr             x16, [fp, #0x10]
    // 0x51f604: SaveReg r16
    //     0x51f604: str             x16, [SP, #-8]!
    // 0x51f608: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x51f608: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x51f60c: r0 = listEquals()
    //     0x51f60c: bl              #0x512fbc  ; [package:flutter/src/foundation/collections.dart] ::listEquals
    // 0x51f610: add             SP, SP, #0x18
    // 0x51f614: tbz             w0, #4, #0x51f628
    // 0x51f618: ldr             x16, [fp, #0x18]
    // 0x51f61c: SaveReg r16
    //     0x51f61c: str             x16, [SP, #-8]!
    // 0x51f620: r0 = _markNeedsBuild()
    //     0x51f620: bl              #0x51f210  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild
    // 0x51f624: add             SP, SP, #8
    // 0x51f628: ldr             x1, [fp, #0x18]
    // 0x51f62c: ldr             x0, [fp, #0x10]
    // 0x51f630: StoreField: r1->field_47 = r0
    //     0x51f630: stur            w0, [x1, #0x47]
    //     0x51f634: ldurb           w16, [x1, #-1]
    //     0x51f638: ldurb           w17, [x0, #-1]
    //     0x51f63c: and             x16, x17, x16, lsr #2
    //     0x51f640: tst             x16, HEAP, lsr #32
    //     0x51f644: b.eq            #0x51f64c
    //     0x51f648: bl              #0xd6826c
    // 0x51f64c: r0 = Null
    //     0x51f64c: mov             x0, NULL
    // 0x51f650: LeaveFrame
    //     0x51f650: mov             SP, fp
    //     0x51f654: ldp             fp, lr, [SP], #0x10
    // 0x51f658: ret
    //     0x51f658: ret             
    // 0x51f65c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51f65c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51f660: b               #0x51f5e8
  }
  set _ lineHeightAtEnd=(/* No info */) {
    // ** addr: 0x524418, size: 0x64
    // 0x524418: EnterFrame
    //     0x524418: stp             fp, lr, [SP, #-0x10]!
    //     0x52441c: mov             fp, SP
    // 0x524420: CheckStackOverflow
    //     0x524420: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x524424: cmp             SP, x16
    //     0x524428: b.ls            #0x524474
    // 0x52442c: ldr             x0, [fp, #0x18]
    // 0x524430: LoadField: d0 = r0->field_2b
    //     0x524430: ldur            d0, [x0, #0x2b]
    // 0x524434: ldr             d1, [fp, #0x10]
    // 0x524438: fcmp            d0, d1
    // 0x52443c: b.vs            #0x524454
    // 0x524440: b.ne            #0x524454
    // 0x524444: r0 = Null
    //     0x524444: mov             x0, NULL
    // 0x524448: LeaveFrame
    //     0x524448: mov             SP, fp
    //     0x52444c: ldp             fp, lr, [SP], #0x10
    // 0x524450: ret
    //     0x524450: ret             
    // 0x524454: StoreField: r0->field_2b = d1
    //     0x524454: stur            d1, [x0, #0x2b]
    // 0x524458: SaveReg r0
    //     0x524458: str             x0, [SP, #-8]!
    // 0x52445c: r0 = _markNeedsBuild()
    //     0x52445c: bl              #0x51f210  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild
    // 0x524460: add             SP, SP, #8
    // 0x524464: r0 = Null
    //     0x524464: mov             x0, NULL
    // 0x524468: LeaveFrame
    //     0x524468: mov             SP, fp
    //     0x52446c: ldp             fp, lr, [SP], #0x10
    // 0x524470: ret
    //     0x524470: ret             
    // 0x524474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x524474: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x524478: b               #0x52442c
  }
  set _ endHandleType=(/* No info */) {
    // ** addr: 0x525588, size: 0x80
    // 0x525588: EnterFrame
    //     0x525588: stp             fp, lr, [SP, #-0x10]!
    //     0x52558c: mov             fp, SP
    // 0x525590: CheckStackOverflow
    //     0x525590: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x525594: cmp             SP, x16
    //     0x525598: b.ls            #0x525600
    // 0x52559c: ldr             x1, [fp, #0x18]
    // 0x5255a0: LoadField: r0 = r1->field_27
    //     0x5255a0: ldur            w0, [x1, #0x27]
    // 0x5255a4: DecompressPointer r0
    //     0x5255a4: add             x0, x0, HEAP, lsl #32
    // 0x5255a8: ldr             x2, [fp, #0x10]
    // 0x5255ac: cmp             w0, w2
    // 0x5255b0: b.ne            #0x5255c4
    // 0x5255b4: r0 = Null
    //     0x5255b4: mov             x0, NULL
    // 0x5255b8: LeaveFrame
    //     0x5255b8: mov             SP, fp
    //     0x5255bc: ldp             fp, lr, [SP], #0x10
    // 0x5255c0: ret
    //     0x5255c0: ret             
    // 0x5255c4: mov             x0, x2
    // 0x5255c8: StoreField: r1->field_27 = r0
    //     0x5255c8: stur            w0, [x1, #0x27]
    //     0x5255cc: ldurb           w16, [x1, #-1]
    //     0x5255d0: ldurb           w17, [x0, #-1]
    //     0x5255d4: and             x16, x17, x16, lsr #2
    //     0x5255d8: tst             x16, HEAP, lsr #32
    //     0x5255dc: b.eq            #0x5255e4
    //     0x5255e0: bl              #0xd6826c
    // 0x5255e4: SaveReg r1
    //     0x5255e4: str             x1, [SP, #-8]!
    // 0x5255e8: r0 = _markNeedsBuild()
    //     0x5255e8: bl              #0x51f210  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild
    // 0x5255ec: add             SP, SP, #8
    // 0x5255f0: r0 = Null
    //     0x5255f0: mov             x0, NULL
    // 0x5255f4: LeaveFrame
    //     0x5255f4: mov             SP, fp
    //     0x5255f8: ldp             fp, lr, [SP], #0x10
    // 0x5255fc: ret
    //     0x5255fc: ret             
    // 0x525600: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x525600: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x525604: b               #0x52559c
  }
  set _ lineHeightAtStart=(/* No info */) {
    // ** addr: 0x525608, size: 0x64
    // 0x525608: EnterFrame
    //     0x525608: stp             fp, lr, [SP, #-0x10]!
    //     0x52560c: mov             fp, SP
    // 0x525610: CheckStackOverflow
    //     0x525610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x525614: cmp             SP, x16
    //     0x525618: b.ls            #0x525664
    // 0x52561c: ldr             x0, [fp, #0x18]
    // 0x525620: LoadField: d0 = r0->field_f
    //     0x525620: ldur            d0, [x0, #0xf]
    // 0x525624: ldr             d1, [fp, #0x10]
    // 0x525628: fcmp            d0, d1
    // 0x52562c: b.vs            #0x525644
    // 0x525630: b.ne            #0x525644
    // 0x525634: r0 = Null
    //     0x525634: mov             x0, NULL
    // 0x525638: LeaveFrame
    //     0x525638: mov             SP, fp
    //     0x52563c: ldp             fp, lr, [SP], #0x10
    // 0x525640: ret
    //     0x525640: ret             
    // 0x525644: StoreField: r0->field_f = d1
    //     0x525644: stur            d1, [x0, #0xf]
    // 0x525648: SaveReg r0
    //     0x525648: str             x0, [SP, #-8]!
    // 0x52564c: r0 = _markNeedsBuild()
    //     0x52564c: bl              #0x51f210  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild
    // 0x525650: add             SP, SP, #8
    // 0x525654: r0 = Null
    //     0x525654: mov             x0, NULL
    // 0x525658: LeaveFrame
    //     0x525658: mov             SP, fp
    //     0x52565c: ldp             fp, lr, [SP], #0x10
    // 0x525660: ret
    //     0x525660: ret             
    // 0x525664: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x525664: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x525668: b               #0x52561c
  }
  set _ startHandleType=(/* No info */) {
    // ** addr: 0x525860, size: 0x80
    // 0x525860: EnterFrame
    //     0x525860: stp             fp, lr, [SP, #-0x10]!
    //     0x525864: mov             fp, SP
    // 0x525868: CheckStackOverflow
    //     0x525868: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52586c: cmp             SP, x16
    //     0x525870: b.ls            #0x5258d8
    // 0x525874: ldr             x1, [fp, #0x18]
    // 0x525878: LoadField: r0 = r1->field_b
    //     0x525878: ldur            w0, [x1, #0xb]
    // 0x52587c: DecompressPointer r0
    //     0x52587c: add             x0, x0, HEAP, lsl #32
    // 0x525880: ldr             x2, [fp, #0x10]
    // 0x525884: cmp             w0, w2
    // 0x525888: b.ne            #0x52589c
    // 0x52588c: r0 = Null
    //     0x52588c: mov             x0, NULL
    // 0x525890: LeaveFrame
    //     0x525890: mov             SP, fp
    //     0x525894: ldp             fp, lr, [SP], #0x10
    // 0x525898: ret
    //     0x525898: ret             
    // 0x52589c: mov             x0, x2
    // 0x5258a0: StoreField: r1->field_b = r0
    //     0x5258a0: stur            w0, [x1, #0xb]
    //     0x5258a4: ldurb           w16, [x1, #-1]
    //     0x5258a8: ldurb           w17, [x0, #-1]
    //     0x5258ac: and             x16, x17, x16, lsr #2
    //     0x5258b0: tst             x16, HEAP, lsr #32
    //     0x5258b4: b.eq            #0x5258bc
    //     0x5258b8: bl              #0xd6826c
    // 0x5258bc: SaveReg r1
    //     0x5258bc: str             x1, [SP, #-8]!
    // 0x5258c0: r0 = _markNeedsBuild()
    //     0x5258c0: bl              #0x51f210  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_markNeedsBuild
    // 0x5258c4: add             SP, SP, #8
    // 0x5258c8: r0 = Null
    //     0x5258c8: mov             x0, NULL
    // 0x5258cc: LeaveFrame
    //     0x5258cc: mov             SP, fp
    //     0x5258d0: ldp             fp, lr, [SP], #0x10
    // 0x5258d4: ret
    //     0x5258d4: ret             
    // 0x5258d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5258d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5258dc: b               #0x525874
  }
  _ showHandles(/* No info */) {
    // ** addr: 0x7a8aa8, size: 0x18c
    // 0x7a8aa8: EnterFrame
    //     0x7a8aa8: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8aac: mov             fp, SP
    // 0x7a8ab0: AllocStack(0x18)
    //     0x7a8ab0: sub             SP, SP, #0x18
    // 0x7a8ab4: CheckStackOverflow
    //     0x7a8ab4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a8ab8: cmp             SP, x16
    //     0x7a8abc: b.ls            #0x7a8c28
    // 0x7a8ac0: ldr             x0, [fp, #0x10]
    // 0x7a8ac4: LoadField: r1 = r0->field_73
    //     0x7a8ac4: ldur            w1, [x0, #0x73]
    // 0x7a8ac8: DecompressPointer r1
    //     0x7a8ac8: add             x1, x1, HEAP, lsl #32
    // 0x7a8acc: cmp             w1, NULL
    // 0x7a8ad0: b.eq            #0x7a8ae4
    // 0x7a8ad4: r0 = Null
    //     0x7a8ad4: mov             x0, NULL
    // 0x7a8ad8: LeaveFrame
    //     0x7a8ad8: mov             SP, fp
    //     0x7a8adc: ldp             fp, lr, [SP], #0x10
    // 0x7a8ae0: ret
    //     0x7a8ae0: ret             
    // 0x7a8ae4: r1 = 1
    //     0x7a8ae4: mov             x1, #1
    // 0x7a8ae8: r0 = AllocateContext()
    //     0x7a8ae8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a8aec: mov             x1, x0
    // 0x7a8af0: ldr             x0, [fp, #0x10]
    // 0x7a8af4: StoreField: r1->field_f = r0
    //     0x7a8af4: stur            w0, [x1, #0xf]
    // 0x7a8af8: mov             x2, x1
    // 0x7a8afc: r1 = Function '_buildStartHandle@500251836':.
    //     0x7a8afc: add             x1, PP, #0x37, lsl #12  ; [pp+0x373f0] AnonymousClosure: (0x7a8fa0), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_buildStartHandle (0x7a8fec)
    //     0x7a8b00: ldr             x1, [x1, #0x3f0]
    // 0x7a8b04: r0 = AllocateClosure()
    //     0x7a8b04: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a8b08: stur            x0, [fp, #-8]
    // 0x7a8b0c: r0 = OverlayEntry()
    //     0x7a8b0c: bl              #0x6efcd0  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x24)
    // 0x7a8b10: stur            x0, [fp, #-0x10]
    // 0x7a8b14: ldur            x16, [fp, #-8]
    // 0x7a8b18: stp             x16, x0, [SP, #-0x10]!
    // 0x7a8b1c: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7a8b1c: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7a8b20: r0 = OverlayEntry()
    //     0x7a8b20: bl              #0x594c98  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0x7a8b24: add             SP, SP, #0x10
    // 0x7a8b28: r1 = 1
    //     0x7a8b28: mov             x1, #1
    // 0x7a8b2c: r0 = AllocateContext()
    //     0x7a8b2c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a8b30: mov             x1, x0
    // 0x7a8b34: ldr             x0, [fp, #0x10]
    // 0x7a8b38: StoreField: r1->field_f = r0
    //     0x7a8b38: stur            w0, [x1, #0xf]
    // 0x7a8b3c: mov             x2, x1
    // 0x7a8b40: r1 = Function '_buildEndHandle@500251836':.
    //     0x7a8b40: add             x1, PP, #0x37, lsl #12  ; [pp+0x373f8] AnonymousClosure: (0x7a8e00), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_buildEndHandle (0x7a8e4c)
    //     0x7a8b44: ldr             x1, [x1, #0x3f8]
    // 0x7a8b48: r0 = AllocateClosure()
    //     0x7a8b48: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a8b4c: stur            x0, [fp, #-8]
    // 0x7a8b50: r0 = OverlayEntry()
    //     0x7a8b50: bl              #0x6efcd0  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x24)
    // 0x7a8b54: stur            x0, [fp, #-0x18]
    // 0x7a8b58: ldur            x16, [fp, #-8]
    // 0x7a8b5c: stp             x16, x0, [SP, #-0x10]!
    // 0x7a8b60: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7a8b60: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7a8b64: r0 = OverlayEntry()
    //     0x7a8b64: bl              #0x594c98  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0x7a8b68: add             SP, SP, #0x10
    // 0x7a8b6c: r1 = Null
    //     0x7a8b6c: mov             x1, NULL
    // 0x7a8b70: r2 = 4
    //     0x7a8b70: mov             x2, #4
    // 0x7a8b74: r0 = AllocateArray()
    //     0x7a8b74: bl              #0xd6987c  ; AllocateArrayStub
    // 0x7a8b78: mov             x2, x0
    // 0x7a8b7c: ldur            x0, [fp, #-0x10]
    // 0x7a8b80: stur            x2, [fp, #-8]
    // 0x7a8b84: StoreField: r2->field_f = r0
    //     0x7a8b84: stur            w0, [x2, #0xf]
    // 0x7a8b88: ldur            x0, [fp, #-0x18]
    // 0x7a8b8c: StoreField: r2->field_13 = r0
    //     0x7a8b8c: stur            w0, [x2, #0x13]
    // 0x7a8b90: r1 = <OverlayEntry>
    //     0x7a8b90: add             x1, PP, #0xe, lsl #12  ; [pp+0xe658] TypeArguments: <OverlayEntry>
    //     0x7a8b94: ldr             x1, [x1, #0x658]
    // 0x7a8b98: r0 = AllocateGrowableArray()
    //     0x7a8b98: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x7a8b9c: mov             x1, x0
    // 0x7a8ba0: ldur            x0, [fp, #-8]
    // 0x7a8ba4: StoreField: r1->field_f = r0
    //     0x7a8ba4: stur            w0, [x1, #0xf]
    // 0x7a8ba8: r0 = 4
    //     0x7a8ba8: mov             x0, #4
    // 0x7a8bac: StoreField: r1->field_b = r0
    //     0x7a8bac: stur            w0, [x1, #0xb]
    // 0x7a8bb0: mov             x0, x1
    // 0x7a8bb4: ldr             x1, [fp, #0x10]
    // 0x7a8bb8: StoreField: r1->field_73 = r0
    //     0x7a8bb8: stur            w0, [x1, #0x73]
    //     0x7a8bbc: ldurb           w16, [x1, #-1]
    //     0x7a8bc0: ldurb           w17, [x0, #-1]
    //     0x7a8bc4: and             x16, x17, x16, lsr #2
    //     0x7a8bc8: tst             x16, HEAP, lsr #32
    //     0x7a8bcc: b.eq            #0x7a8bd4
    //     0x7a8bd0: bl              #0xd6826c
    // 0x7a8bd4: LoadField: r0 = r1->field_7
    //     0x7a8bd4: ldur            w0, [x1, #7]
    // 0x7a8bd8: DecompressPointer r0
    //     0x7a8bd8: add             x0, x0, HEAP, lsl #32
    // 0x7a8bdc: r16 = true
    //     0x7a8bdc: add             x16, NULL, #0x20  ; true
    // 0x7a8be0: stp             x16, x0, [SP, #-0x10]!
    // 0x7a8be4: r4 = const [0, 0x2, 0x2, 0x1, rootOverlay, 0x1, null]
    //     0x7a8be4: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f760] List(7) [0, 0x2, 0x2, 0x1, "rootOverlay", 0x1, Null]
    //     0x7a8be8: ldr             x4, [x4, #0x760]
    // 0x7a8bec: r0 = of()
    //     0x7a8bec: bl              #0x59424c  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x7a8bf0: add             SP, SP, #0x10
    // 0x7a8bf4: mov             x1, x0
    // 0x7a8bf8: ldr             x0, [fp, #0x10]
    // 0x7a8bfc: LoadField: r2 = r0->field_73
    //     0x7a8bfc: ldur            w2, [x0, #0x73]
    // 0x7a8c00: DecompressPointer r2
    //     0x7a8c00: add             x2, x2, HEAP, lsl #32
    // 0x7a8c04: cmp             w2, NULL
    // 0x7a8c08: b.eq            #0x7a8c30
    // 0x7a8c0c: stp             x2, x1, [SP, #-0x10]!
    // 0x7a8c10: r0 = insertAll()
    //     0x7a8c10: bl              #0x7a8c34  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insertAll
    // 0x7a8c14: add             SP, SP, #0x10
    // 0x7a8c18: r0 = Null
    //     0x7a8c18: mov             x0, NULL
    // 0x7a8c1c: LeaveFrame
    //     0x7a8c1c: mov             SP, fp
    //     0x7a8c20: ldp             fp, lr, [SP], #0x10
    // 0x7a8c24: ret
    //     0x7a8c24: ret             
    // 0x7a8c28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a8c28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a8c2c: b               #0x7a8ac0
    // 0x7a8c30: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a8c30: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildEndHandle(dynamic, BuildContext) {
    // ** addr: 0x7a8e00, size: 0x4c
    // 0x7a8e00: EnterFrame
    //     0x7a8e00: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8e04: mov             fp, SP
    // 0x7a8e08: ldr             x0, [fp, #0x18]
    // 0x7a8e0c: LoadField: r1 = r0->field_17
    //     0x7a8e0c: ldur            w1, [x0, #0x17]
    // 0x7a8e10: DecompressPointer r1
    //     0x7a8e10: add             x1, x1, HEAP, lsl #32
    // 0x7a8e14: CheckStackOverflow
    //     0x7a8e14: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a8e18: cmp             SP, x16
    //     0x7a8e1c: b.ls            #0x7a8e44
    // 0x7a8e20: LoadField: r0 = r1->field_f
    //     0x7a8e20: ldur            w0, [x1, #0xf]
    // 0x7a8e24: DecompressPointer r0
    //     0x7a8e24: add             x0, x0, HEAP, lsl #32
    // 0x7a8e28: ldr             x16, [fp, #0x10]
    // 0x7a8e2c: stp             x16, x0, [SP, #-0x10]!
    // 0x7a8e30: r0 = _buildEndHandle()
    //     0x7a8e30: bl              #0x7a8e4c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_buildEndHandle
    // 0x7a8e34: add             SP, SP, #0x10
    // 0x7a8e38: LeaveFrame
    //     0x7a8e38: mov             SP, fp
    //     0x7a8e3c: ldp             fp, lr, [SP], #0x10
    // 0x7a8e40: ret
    //     0x7a8e40: ret             
    // 0x7a8e44: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a8e44: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a8e48: b               #0x7a8e20
  }
  _ _buildEndHandle(/* No info */) {
    // ** addr: 0x7a8e4c, size: 0x13c
    // 0x7a8e4c: EnterFrame
    //     0x7a8e4c: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8e50: mov             fp, SP
    // 0x7a8e54: AllocStack(0x40)
    //     0x7a8e54: sub             SP, SP, #0x40
    // 0x7a8e58: CheckStackOverflow
    //     0x7a8e58: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a8e5c: cmp             SP, x16
    //     0x7a8e60: b.ls            #0x7a8f80
    // 0x7a8e64: ldr             x0, [fp, #0x18]
    // 0x7a8e68: LoadField: r1 = r0->field_5b
    //     0x7a8e68: ldur            w1, [x0, #0x5b]
    // 0x7a8e6c: DecompressPointer r1
    //     0x7a8e6c: add             x1, x1, HEAP, lsl #32
    // 0x7a8e70: stur            x1, [fp, #-0x38]
    // 0x7a8e74: cmp             w1, NULL
    // 0x7a8e78: b.eq            #0x7a8e94
    // 0x7a8e7c: LoadField: r2 = r0->field_b
    //     0x7a8e7c: ldur            w2, [x0, #0xb]
    // 0x7a8e80: DecompressPointer r2
    //     0x7a8e80: add             x2, x2, HEAP, lsl #32
    // 0x7a8e84: r16 = Instance_TextSelectionHandleType
    //     0x7a8e84: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f768] Obj!TextSelectionHandleType@b64811
    //     0x7a8e88: ldr             x16, [x16, #0x768]
    // 0x7a8e8c: cmp             w2, w16
    // 0x7a8e90: b.ne            #0x7a8eb4
    // 0x7a8e94: r0 = Container()
    //     0x7a8e94: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7a8e98: stur            x0, [fp, #-8]
    // 0x7a8e9c: SaveReg r0
    //     0x7a8e9c: str             x0, [SP, #-8]!
    // 0x7a8ea0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7a8ea0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7a8ea4: r0 = Container()
    //     0x7a8ea4: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7a8ea8: add             SP, SP, #8
    // 0x7a8eac: ldur            x0, [fp, #-8]
    // 0x7a8eb0: b               #0x7a8f5c
    // 0x7a8eb4: LoadField: r2 = r0->field_27
    //     0x7a8eb4: ldur            w2, [x0, #0x27]
    // 0x7a8eb8: DecompressPointer r2
    //     0x7a8eb8: add             x2, x2, HEAP, lsl #32
    // 0x7a8ebc: stur            x2, [fp, #-0x30]
    // 0x7a8ec0: LoadField: r3 = r0->field_57
    //     0x7a8ec0: ldur            w3, [x0, #0x57]
    // 0x7a8ec4: DecompressPointer r3
    //     0x7a8ec4: add             x3, x3, HEAP, lsl #32
    // 0x7a8ec8: stur            x3, [fp, #-0x28]
    // 0x7a8ecc: LoadField: r4 = r0->field_67
    //     0x7a8ecc: ldur            w4, [x0, #0x67]
    // 0x7a8ed0: DecompressPointer r4
    //     0x7a8ed0: add             x4, x4, HEAP, lsl #32
    // 0x7a8ed4: stur            x4, [fp, #-0x20]
    // 0x7a8ed8: LoadField: r5 = r0->field_37
    //     0x7a8ed8: ldur            w5, [x0, #0x37]
    // 0x7a8edc: DecompressPointer r5
    //     0x7a8edc: add             x5, x5, HEAP, lsl #32
    // 0x7a8ee0: stur            x5, [fp, #-0x18]
    // 0x7a8ee4: LoadField: r6 = r0->field_3b
    //     0x7a8ee4: ldur            w6, [x0, #0x3b]
    // 0x7a8ee8: DecompressPointer r6
    //     0x7a8ee8: add             x6, x6, HEAP, lsl #32
    // 0x7a8eec: stur            x6, [fp, #-0x10]
    // 0x7a8ef0: LoadField: r7 = r0->field_33
    //     0x7a8ef0: ldur            w7, [x0, #0x33]
    // 0x7a8ef4: DecompressPointer r7
    //     0x7a8ef4: add             x7, x7, HEAP, lsl #32
    // 0x7a8ef8: stur            x7, [fp, #-8]
    // 0x7a8efc: LoadField: d0 = r0->field_2b
    //     0x7a8efc: ldur            d0, [x0, #0x2b]
    // 0x7a8f00: stur            d0, [fp, #-0x40]
    // 0x7a8f04: r0 = _SelectionHandleOverlay()
    //     0x7a8f04: bl              #0x7a8f94  ; Allocate_SelectionHandleOverlayStub -> _SelectionHandleOverlay (size=0x38)
    // 0x7a8f08: mov             x1, x0
    // 0x7a8f0c: ldur            x0, [fp, #-0x30]
    // 0x7a8f10: StoreField: r1->field_2f = r0
    //     0x7a8f10: stur            w0, [x1, #0x2f]
    // 0x7a8f14: ldur            x0, [fp, #-0x28]
    // 0x7a8f18: StoreField: r1->field_b = r0
    //     0x7a8f18: stur            w0, [x1, #0xb]
    // 0x7a8f1c: ldur            x0, [fp, #-0x20]
    // 0x7a8f20: StoreField: r1->field_f = r0
    //     0x7a8f20: stur            w0, [x1, #0xf]
    // 0x7a8f24: ldur            x0, [fp, #-0x18]
    // 0x7a8f28: StoreField: r1->field_13 = r0
    //     0x7a8f28: stur            w0, [x1, #0x13]
    // 0x7a8f2c: ldur            x0, [fp, #-0x10]
    // 0x7a8f30: StoreField: r1->field_17 = r0
    //     0x7a8f30: stur            w0, [x1, #0x17]
    // 0x7a8f34: ldur            x0, [fp, #-0x38]
    // 0x7a8f38: StoreField: r1->field_1f = r0
    //     0x7a8f38: stur            w0, [x1, #0x1f]
    // 0x7a8f3c: ldur            x0, [fp, #-8]
    // 0x7a8f40: StoreField: r1->field_23 = r0
    //     0x7a8f40: stur            w0, [x1, #0x23]
    // 0x7a8f44: ldur            d0, [fp, #-0x40]
    // 0x7a8f48: StoreField: r1->field_27 = d0
    //     0x7a8f48: stur            d0, [x1, #0x27]
    // 0x7a8f4c: r0 = Instance_DragStartBehavior
    //     0x7a8f4c: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x7a8f50: ldr             x0, [x0, #0xf88]
    // 0x7a8f54: StoreField: r1->field_33 = r0
    //     0x7a8f54: stur            w0, [x1, #0x33]
    // 0x7a8f58: mov             x0, x1
    // 0x7a8f5c: stur            x0, [fp, #-8]
    // 0x7a8f60: r0 = ExcludeSemantics()
    //     0x7a8f60: bl              #0x7a8f88  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0x7a8f64: r1 = true
    //     0x7a8f64: add             x1, NULL, #0x20  ; true
    // 0x7a8f68: StoreField: r0->field_f = r1
    //     0x7a8f68: stur            w1, [x0, #0xf]
    // 0x7a8f6c: ldur            x1, [fp, #-8]
    // 0x7a8f70: StoreField: r0->field_b = r1
    //     0x7a8f70: stur            w1, [x0, #0xb]
    // 0x7a8f74: LeaveFrame
    //     0x7a8f74: mov             SP, fp
    //     0x7a8f78: ldp             fp, lr, [SP], #0x10
    // 0x7a8f7c: ret
    //     0x7a8f7c: ret             
    // 0x7a8f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a8f80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a8f84: b               #0x7a8e64
  }
  [closure] Widget _buildStartHandle(dynamic, BuildContext) {
    // ** addr: 0x7a8fa0, size: 0x4c
    // 0x7a8fa0: EnterFrame
    //     0x7a8fa0: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8fa4: mov             fp, SP
    // 0x7a8fa8: ldr             x0, [fp, #0x18]
    // 0x7a8fac: LoadField: r1 = r0->field_17
    //     0x7a8fac: ldur            w1, [x0, #0x17]
    // 0x7a8fb0: DecompressPointer r1
    //     0x7a8fb0: add             x1, x1, HEAP, lsl #32
    // 0x7a8fb4: CheckStackOverflow
    //     0x7a8fb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a8fb8: cmp             SP, x16
    //     0x7a8fbc: b.ls            #0x7a8fe4
    // 0x7a8fc0: LoadField: r0 = r1->field_f
    //     0x7a8fc0: ldur            w0, [x1, #0xf]
    // 0x7a8fc4: DecompressPointer r0
    //     0x7a8fc4: add             x0, x0, HEAP, lsl #32
    // 0x7a8fc8: ldr             x16, [fp, #0x10]
    // 0x7a8fcc: stp             x16, x0, [SP, #-0x10]!
    // 0x7a8fd0: r0 = _buildStartHandle()
    //     0x7a8fd0: bl              #0x7a8fec  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_buildStartHandle
    // 0x7a8fd4: add             SP, SP, #0x10
    // 0x7a8fd8: LeaveFrame
    //     0x7a8fd8: mov             SP, fp
    //     0x7a8fdc: ldp             fp, lr, [SP], #0x10
    // 0x7a8fe0: ret
    //     0x7a8fe0: ret             
    // 0x7a8fe4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a8fe4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a8fe8: b               #0x7a8fc0
  }
  _ _buildStartHandle(/* No info */) {
    // ** addr: 0x7a8fec, size: 0x124
    // 0x7a8fec: EnterFrame
    //     0x7a8fec: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8ff0: mov             fp, SP
    // 0x7a8ff4: AllocStack(0x40)
    //     0x7a8ff4: sub             SP, SP, #0x40
    // 0x7a8ff8: CheckStackOverflow
    //     0x7a8ff8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a8ffc: cmp             SP, x16
    //     0x7a9000: b.ls            #0x7a9108
    // 0x7a9004: ldr             x0, [fp, #0x18]
    // 0x7a9008: LoadField: r1 = r0->field_5b
    //     0x7a9008: ldur            w1, [x0, #0x5b]
    // 0x7a900c: DecompressPointer r1
    //     0x7a900c: add             x1, x1, HEAP, lsl #32
    // 0x7a9010: stur            x1, [fp, #-0x38]
    // 0x7a9014: cmp             w1, NULL
    // 0x7a9018: b.ne            #0x7a903c
    // 0x7a901c: r0 = Container()
    //     0x7a901c: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0x7a9020: stur            x0, [fp, #-8]
    // 0x7a9024: SaveReg r0
    //     0x7a9024: str             x0, [SP, #-8]!
    // 0x7a9028: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7a9028: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7a902c: r0 = Container()
    //     0x7a902c: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0x7a9030: add             SP, SP, #8
    // 0x7a9034: ldur            x0, [fp, #-8]
    // 0x7a9038: b               #0x7a90e4
    // 0x7a903c: LoadField: r2 = r0->field_b
    //     0x7a903c: ldur            w2, [x0, #0xb]
    // 0x7a9040: DecompressPointer r2
    //     0x7a9040: add             x2, x2, HEAP, lsl #32
    // 0x7a9044: stur            x2, [fp, #-0x30]
    // 0x7a9048: LoadField: r3 = r0->field_53
    //     0x7a9048: ldur            w3, [x0, #0x53]
    // 0x7a904c: DecompressPointer r3
    //     0x7a904c: add             x3, x3, HEAP, lsl #32
    // 0x7a9050: stur            x3, [fp, #-0x28]
    // 0x7a9054: LoadField: r4 = r0->field_67
    //     0x7a9054: ldur            w4, [x0, #0x67]
    // 0x7a9058: DecompressPointer r4
    //     0x7a9058: add             x4, x4, HEAP, lsl #32
    // 0x7a905c: stur            x4, [fp, #-0x20]
    // 0x7a9060: LoadField: r5 = r0->field_1b
    //     0x7a9060: ldur            w5, [x0, #0x1b]
    // 0x7a9064: DecompressPointer r5
    //     0x7a9064: add             x5, x5, HEAP, lsl #32
    // 0x7a9068: stur            x5, [fp, #-0x18]
    // 0x7a906c: LoadField: r6 = r0->field_1f
    //     0x7a906c: ldur            w6, [x0, #0x1f]
    // 0x7a9070: DecompressPointer r6
    //     0x7a9070: add             x6, x6, HEAP, lsl #32
    // 0x7a9074: stur            x6, [fp, #-0x10]
    // 0x7a9078: LoadField: r7 = r0->field_17
    //     0x7a9078: ldur            w7, [x0, #0x17]
    // 0x7a907c: DecompressPointer r7
    //     0x7a907c: add             x7, x7, HEAP, lsl #32
    // 0x7a9080: stur            x7, [fp, #-8]
    // 0x7a9084: LoadField: d0 = r0->field_f
    //     0x7a9084: ldur            d0, [x0, #0xf]
    // 0x7a9088: stur            d0, [fp, #-0x40]
    // 0x7a908c: r0 = _SelectionHandleOverlay()
    //     0x7a908c: bl              #0x7a8f94  ; Allocate_SelectionHandleOverlayStub -> _SelectionHandleOverlay (size=0x38)
    // 0x7a9090: mov             x1, x0
    // 0x7a9094: ldur            x0, [fp, #-0x30]
    // 0x7a9098: StoreField: r1->field_2f = r0
    //     0x7a9098: stur            w0, [x1, #0x2f]
    // 0x7a909c: ldur            x0, [fp, #-0x28]
    // 0x7a90a0: StoreField: r1->field_b = r0
    //     0x7a90a0: stur            w0, [x1, #0xb]
    // 0x7a90a4: ldur            x0, [fp, #-0x20]
    // 0x7a90a8: StoreField: r1->field_f = r0
    //     0x7a90a8: stur            w0, [x1, #0xf]
    // 0x7a90ac: ldur            x0, [fp, #-0x18]
    // 0x7a90b0: StoreField: r1->field_13 = r0
    //     0x7a90b0: stur            w0, [x1, #0x13]
    // 0x7a90b4: ldur            x0, [fp, #-0x10]
    // 0x7a90b8: StoreField: r1->field_17 = r0
    //     0x7a90b8: stur            w0, [x1, #0x17]
    // 0x7a90bc: ldur            x0, [fp, #-0x38]
    // 0x7a90c0: StoreField: r1->field_1f = r0
    //     0x7a90c0: stur            w0, [x1, #0x1f]
    // 0x7a90c4: ldur            x0, [fp, #-8]
    // 0x7a90c8: StoreField: r1->field_23 = r0
    //     0x7a90c8: stur            w0, [x1, #0x23]
    // 0x7a90cc: ldur            d0, [fp, #-0x40]
    // 0x7a90d0: StoreField: r1->field_27 = d0
    //     0x7a90d0: stur            d0, [x1, #0x27]
    // 0x7a90d4: r0 = Instance_DragStartBehavior
    //     0x7a90d4: add             x0, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x7a90d8: ldr             x0, [x0, #0xf88]
    // 0x7a90dc: StoreField: r1->field_33 = r0
    //     0x7a90dc: stur            w0, [x1, #0x33]
    // 0x7a90e0: mov             x0, x1
    // 0x7a90e4: stur            x0, [fp, #-8]
    // 0x7a90e8: r0 = ExcludeSemantics()
    //     0x7a90e8: bl              #0x7a8f88  ; AllocateExcludeSemanticsStub -> ExcludeSemantics (size=0x14)
    // 0x7a90ec: r1 = true
    //     0x7a90ec: add             x1, NULL, #0x20  ; true
    // 0x7a90f0: StoreField: r0->field_f = r1
    //     0x7a90f0: stur            w1, [x0, #0xf]
    // 0x7a90f4: ldur            x1, [fp, #-8]
    // 0x7a90f8: StoreField: r0->field_b = r1
    //     0x7a90f8: stur            w1, [x0, #0xb]
    // 0x7a90fc: LeaveFrame
    //     0x7a90fc: mov             SP, fp
    //     0x7a9100: ldp             fp, lr, [SP], #0x10
    // 0x7a9104: ret
    //     0x7a9104: ret             
    // 0x7a9108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a9108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a910c: b               #0x7a9004
  }
  _ SelectionOverlay(/* No info */) {
    // ** addr: 0x7a9520, size: 0x2a8
    // 0x7a9520: EnterFrame
    //     0x7a9520: stp             fp, lr, [SP, #-0x10]!
    //     0x7a9524: mov             fp, SP
    // 0x7a9528: r0 = false
    //     0x7a9528: add             x0, NULL, #0x30  ; false
    // 0x7a952c: r3 = Instance_DragStartBehavior
    //     0x7a952c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14f88] Obj!DragStartBehavior@b65af1
    //     0x7a9530: ldr             x3, [x3, #0xf88]
    // 0x7a9534: r2 = Instance_TextSelectionHandleType
    //     0x7a9534: add             x2, PP, #0x1f, lsl #12  ; [pp+0x1f768] Obj!TextSelectionHandleType@b64811
    //     0x7a9538: ldr             x2, [x2, #0x768]
    // 0x7a953c: r1 = const []
    //     0x7a953c: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1fbb0] List<TextSelectionPoint>(0)
    //     0x7a9540: ldr             x1, [x1, #0xbb0]
    // 0x7a9544: d0 = 0.000000
    //     0x7a9544: eor             v0.16b, v0.16b, v0.16b
    // 0x7a9548: CheckStackOverflow
    //     0x7a9548: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a954c: cmp             SP, x16
    //     0x7a9550: b.ls            #0x7a97c0
    // 0x7a9554: ldr             x4, [fp, #0x98]
    // 0x7a9558: StoreField: r4->field_7b = r0
    //     0x7a9558: stur            w0, [x4, #0x7b]
    // 0x7a955c: ldr             x0, [fp, #0x88]
    // 0x7a9560: StoreField: r4->field_7 = r0
    //     0x7a9560: stur            w0, [x4, #7]
    //     0x7a9564: ldurb           w16, [x4, #-1]
    //     0x7a9568: ldurb           w17, [x0, #-1]
    //     0x7a956c: and             x16, x17, x16, lsr #2
    //     0x7a9570: tst             x16, HEAP, lsr #32
    //     0x7a9574: b.eq            #0x7a957c
    //     0x7a9578: bl              #0xd682cc
    // 0x7a957c: ldr             x0, [fp, #0x80]
    // 0x7a9580: StoreField: r4->field_4b = r0
    //     0x7a9580: stur            w0, [x4, #0x4b]
    //     0x7a9584: ldurb           w16, [x4, #-1]
    //     0x7a9588: ldurb           w17, [x0, #-1]
    //     0x7a958c: and             x16, x17, x16, lsr #2
    //     0x7a9590: tst             x16, HEAP, lsr #32
    //     0x7a9594: b.eq            #0x7a959c
    //     0x7a9598: bl              #0xd682cc
    // 0x7a959c: ldr             x0, [fp, #0x28]
    // 0x7a95a0: StoreField: r4->field_17 = r0
    //     0x7a95a0: stur            w0, [x4, #0x17]
    //     0x7a95a4: ldurb           w16, [x4, #-1]
    //     0x7a95a8: ldurb           w17, [x0, #-1]
    //     0x7a95ac: and             x16, x17, x16, lsr #2
    //     0x7a95b0: tst             x16, HEAP, lsr #32
    //     0x7a95b4: b.eq            #0x7a95bc
    //     0x7a95b8: bl              #0xd682cc
    // 0x7a95bc: ldr             x0, [fp, #0x50]
    // 0x7a95c0: StoreField: r4->field_1b = r0
    //     0x7a95c0: stur            w0, [x4, #0x1b]
    //     0x7a95c4: ldurb           w16, [x4, #-1]
    //     0x7a95c8: ldurb           w17, [x0, #-1]
    //     0x7a95cc: and             x16, x17, x16, lsr #2
    //     0x7a95d0: tst             x16, HEAP, lsr #32
    //     0x7a95d4: b.eq            #0x7a95dc
    //     0x7a95d8: bl              #0xd682cc
    // 0x7a95dc: ldr             x0, [fp, #0x48]
    // 0x7a95e0: StoreField: r4->field_1f = r0
    //     0x7a95e0: stur            w0, [x4, #0x1f]
    //     0x7a95e4: ldurb           w16, [x4, #-1]
    //     0x7a95e8: ldurb           w17, [x0, #-1]
    //     0x7a95ec: and             x16, x17, x16, lsr #2
    //     0x7a95f0: tst             x16, HEAP, lsr #32
    //     0x7a95f4: b.eq            #0x7a95fc
    //     0x7a95f8: bl              #0xd682cc
    // 0x7a95fc: ldr             x0, [fp, #0x70]
    // 0x7a9600: StoreField: r4->field_33 = r0
    //     0x7a9600: stur            w0, [x4, #0x33]
    //     0x7a9604: ldurb           w16, [x4, #-1]
    //     0x7a9608: ldurb           w17, [x0, #-1]
    //     0x7a960c: and             x16, x17, x16, lsr #2
    //     0x7a9610: tst             x16, HEAP, lsr #32
    //     0x7a9614: b.eq            #0x7a961c
    //     0x7a9618: bl              #0xd682cc
    // 0x7a961c: ldr             x0, [fp, #0x68]
    // 0x7a9620: StoreField: r4->field_37 = r0
    //     0x7a9620: stur            w0, [x4, #0x37]
    //     0x7a9624: ldurb           w16, [x4, #-1]
    //     0x7a9628: ldurb           w17, [x0, #-1]
    //     0x7a962c: and             x16, x17, x16, lsr #2
    //     0x7a9630: tst             x16, HEAP, lsr #32
    //     0x7a9634: b.eq            #0x7a963c
    //     0x7a9638: bl              #0xd682cc
    // 0x7a963c: ldr             x0, [fp, #0x60]
    // 0x7a9640: StoreField: r4->field_3b = r0
    //     0x7a9640: stur            w0, [x4, #0x3b]
    //     0x7a9644: ldurb           w16, [x4, #-1]
    //     0x7a9648: ldurb           w17, [x0, #-1]
    //     0x7a964c: and             x16, x17, x16, lsr #2
    //     0x7a9650: tst             x16, HEAP, lsr #32
    //     0x7a9654: b.eq            #0x7a965c
    //     0x7a9658: bl              #0xd682cc
    // 0x7a965c: ldr             x0, [fp, #0x10]
    // 0x7a9660: StoreField: r4->field_43 = r0
    //     0x7a9660: stur            w0, [x4, #0x43]
    //     0x7a9664: ldurb           w16, [x4, #-1]
    //     0x7a9668: ldurb           w17, [x0, #-1]
    //     0x7a966c: and             x16, x17, x16, lsr #2
    //     0x7a9670: tst             x16, HEAP, lsr #32
    //     0x7a9674: b.eq            #0x7a967c
    //     0x7a9678: bl              #0xd682cc
    // 0x7a967c: ldr             x0, [fp, #0x40]
    // 0x7a9680: StoreField: r4->field_5b = r0
    //     0x7a9680: stur            w0, [x4, #0x5b]
    //     0x7a9684: ldurb           w16, [x4, #-1]
    //     0x7a9688: ldurb           w17, [x0, #-1]
    //     0x7a968c: and             x16, x17, x16, lsr #2
    //     0x7a9690: tst             x16, HEAP, lsr #32
    //     0x7a9694: b.eq            #0x7a969c
    //     0x7a9698: bl              #0xd682cc
    // 0x7a969c: ldr             x0, [fp, #0x38]
    // 0x7a96a0: StoreField: r4->field_5f = r0
    //     0x7a96a0: stur            w0, [x4, #0x5f]
    //     0x7a96a4: ldurb           w16, [x4, #-1]
    //     0x7a96a8: ldurb           w17, [x0, #-1]
    //     0x7a96ac: and             x16, x17, x16, lsr #2
    //     0x7a96b0: tst             x16, HEAP, lsr #32
    //     0x7a96b4: b.eq            #0x7a96bc
    //     0x7a96b8: bl              #0xd682cc
    // 0x7a96bc: ldr             x0, [fp, #0x90]
    // 0x7a96c0: StoreField: r4->field_6b = r0
    //     0x7a96c0: stur            w0, [x4, #0x6b]
    //     0x7a96c4: ldurb           w16, [x4, #-1]
    //     0x7a96c8: ldurb           w17, [x0, #-1]
    //     0x7a96cc: and             x16, x17, x16, lsr #2
    //     0x7a96d0: tst             x16, HEAP, lsr #32
    //     0x7a96d4: b.eq            #0x7a96dc
    //     0x7a96d8: bl              #0xd682cc
    // 0x7a96dc: ldr             x0, [fp, #0x30]
    // 0x7a96e0: StoreField: r4->field_53 = r0
    //     0x7a96e0: stur            w0, [x4, #0x53]
    //     0x7a96e4: ldurb           w16, [x4, #-1]
    //     0x7a96e8: ldurb           w17, [x0, #-1]
    //     0x7a96ec: and             x16, x17, x16, lsr #2
    //     0x7a96f0: tst             x16, HEAP, lsr #32
    //     0x7a96f4: b.eq            #0x7a96fc
    //     0x7a96f8: bl              #0xd682cc
    // 0x7a96fc: ldr             x0, [fp, #0x78]
    // 0x7a9700: StoreField: r4->field_57 = r0
    //     0x7a9700: stur            w0, [x4, #0x57]
    //     0x7a9704: ldurb           w16, [x4, #-1]
    //     0x7a9708: ldurb           w17, [x0, #-1]
    //     0x7a970c: and             x16, x17, x16, lsr #2
    //     0x7a9710: tst             x16, HEAP, lsr #32
    //     0x7a9714: b.eq            #0x7a971c
    //     0x7a9718: bl              #0xd682cc
    // 0x7a971c: ldr             x0, [fp, #0x20]
    // 0x7a9720: StoreField: r4->field_4f = r0
    //     0x7a9720: stur            w0, [x4, #0x4f]
    //     0x7a9724: ldurb           w16, [x4, #-1]
    //     0x7a9728: ldurb           w17, [x0, #-1]
    //     0x7a972c: and             x16, x17, x16, lsr #2
    //     0x7a9730: tst             x16, HEAP, lsr #32
    //     0x7a9734: b.eq            #0x7a973c
    //     0x7a9738: bl              #0xd682cc
    // 0x7a973c: StoreField: r4->field_63 = r3
    //     0x7a973c: stur            w3, [x4, #0x63]
    // 0x7a9740: ldr             x0, [fp, #0x58]
    // 0x7a9744: StoreField: r4->field_67 = r0
    //     0x7a9744: stur            w0, [x4, #0x67]
    //     0x7a9748: ldurb           w16, [x4, #-1]
    //     0x7a974c: ldurb           w17, [x0, #-1]
    //     0x7a9750: and             x16, x17, x16, lsr #2
    //     0x7a9754: tst             x16, HEAP, lsr #32
    //     0x7a9758: b.eq            #0x7a9760
    //     0x7a975c: bl              #0xd682cc
    // 0x7a9760: StoreField: r4->field_b = r2
    //     0x7a9760: stur            w2, [x4, #0xb]
    // 0x7a9764: StoreField: r4->field_f = d0
    //     0x7a9764: stur            d0, [x4, #0xf]
    // 0x7a9768: StoreField: r4->field_27 = r2
    //     0x7a9768: stur            w2, [x4, #0x27]
    // 0x7a976c: StoreField: r4->field_2b = d0
    //     0x7a976c: stur            d0, [x4, #0x2b]
    // 0x7a9770: StoreField: r4->field_47 = r1
    //     0x7a9770: stur            w1, [x4, #0x47]
    // 0x7a9774: ldr             x0, [fp, #0x18]
    // 0x7a9778: StoreField: r4->field_6f = r0
    //     0x7a9778: stur            w0, [x4, #0x6f]
    //     0x7a977c: ldurb           w16, [x4, #-1]
    //     0x7a9780: ldurb           w17, [x0, #-1]
    //     0x7a9784: and             x16, x17, x16, lsr #2
    //     0x7a9788: tst             x16, HEAP, lsr #32
    //     0x7a978c: b.eq            #0x7a9794
    //     0x7a9790: bl              #0xd682cc
    // 0x7a9794: ldr             x16, [fp, #0x88]
    // 0x7a9798: r30 = true
    //     0x7a9798: add             lr, NULL, #0x20  ; true
    // 0x7a979c: stp             lr, x16, [SP, #-0x10]!
    // 0x7a97a0: r4 = const [0, 0x2, 0x2, 0x1, rootOverlay, 0x1, null]
    //     0x7a97a0: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f760] List(7) [0, 0x2, 0x2, 0x1, "rootOverlay", 0x1, Null]
    //     0x7a97a4: ldr             x4, [x4, #0x760]
    // 0x7a97a8: r0 = of()
    //     0x7a97a8: bl              #0x59424c  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0x7a97ac: add             SP, SP, #0x10
    // 0x7a97b0: r0 = Null
    //     0x7a97b0: mov             x0, NULL
    // 0x7a97b4: LeaveFrame
    //     0x7a97b4: mov             SP, fp
    //     0x7a97b8: ldp             fp, lr, [SP], #0x10
    // 0x7a97bc: ret
    //     0x7a97bc: ret             
    // 0x7a97c0: r0 = StackOverflowSharedWithFPURegs()
    //     0x7a97c0: bl              #0xd69ab8  ; StackOverflowSharedWithFPURegsStub
    // 0x7a97c4: b               #0x7a9554
  }
  _ hide(/* No info */) {
    // ** addr: 0x7ac174, size: 0xfc
    // 0x7ac174: EnterFrame
    //     0x7ac174: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac178: mov             fp, SP
    // 0x7ac17c: CheckStackOverflow
    //     0x7ac17c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ac180: cmp             SP, x16
    //     0x7ac184: b.ls            #0x7ac25c
    // 0x7ac188: ldr             x2, [fp, #0x10]
    // 0x7ac18c: LoadField: r3 = r2->field_73
    //     0x7ac18c: ldur            w3, [x2, #0x73]
    // 0x7ac190: DecompressPointer r3
    //     0x7ac190: add             x3, x3, HEAP, lsl #32
    // 0x7ac194: cmp             w3, NULL
    // 0x7ac198: b.eq            #0x7ac22c
    // 0x7ac19c: LoadField: r0 = r3->field_b
    //     0x7ac19c: ldur            w0, [x3, #0xb]
    // 0x7ac1a0: DecompressPointer r0
    //     0x7ac1a0: add             x0, x0, HEAP, lsl #32
    // 0x7ac1a4: r1 = LoadInt32Instr(r0)
    //     0x7ac1a4: sbfx            x1, x0, #1, #0x1f
    // 0x7ac1a8: mov             x0, x1
    // 0x7ac1ac: r1 = 0
    //     0x7ac1ac: mov             x1, #0
    // 0x7ac1b0: cmp             x1, x0
    // 0x7ac1b4: b.hs            #0x7ac264
    // 0x7ac1b8: LoadField: r0 = r3->field_f
    //     0x7ac1b8: ldur            w0, [x3, #0xf]
    // 0x7ac1bc: DecompressPointer r0
    //     0x7ac1bc: add             x0, x0, HEAP, lsl #32
    // 0x7ac1c0: LoadField: r1 = r0->field_f
    //     0x7ac1c0: ldur            w1, [x0, #0xf]
    // 0x7ac1c4: DecompressPointer r1
    //     0x7ac1c4: add             x1, x1, HEAP, lsl #32
    // 0x7ac1c8: SaveReg r1
    //     0x7ac1c8: str             x1, [SP, #-8]!
    // 0x7ac1cc: r0 = remove()
    //     0x7ac1cc: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x7ac1d0: add             SP, SP, #8
    // 0x7ac1d4: ldr             x2, [fp, #0x10]
    // 0x7ac1d8: LoadField: r3 = r2->field_73
    //     0x7ac1d8: ldur            w3, [x2, #0x73]
    // 0x7ac1dc: DecompressPointer r3
    //     0x7ac1dc: add             x3, x3, HEAP, lsl #32
    // 0x7ac1e0: cmp             w3, NULL
    // 0x7ac1e4: b.eq            #0x7ac268
    // 0x7ac1e8: LoadField: r0 = r3->field_b
    //     0x7ac1e8: ldur            w0, [x3, #0xb]
    // 0x7ac1ec: DecompressPointer r0
    //     0x7ac1ec: add             x0, x0, HEAP, lsl #32
    // 0x7ac1f0: r1 = LoadInt32Instr(r0)
    //     0x7ac1f0: sbfx            x1, x0, #1, #0x1f
    // 0x7ac1f4: mov             x0, x1
    // 0x7ac1f8: r1 = 1
    //     0x7ac1f8: mov             x1, #1
    // 0x7ac1fc: cmp             x1, x0
    // 0x7ac200: b.hs            #0x7ac26c
    // 0x7ac204: LoadField: r0 = r3->field_f
    //     0x7ac204: ldur            w0, [x3, #0xf]
    // 0x7ac208: DecompressPointer r0
    //     0x7ac208: add             x0, x0, HEAP, lsl #32
    // 0x7ac20c: LoadField: r1 = r0->field_13
    //     0x7ac20c: ldur            w1, [x0, #0x13]
    // 0x7ac210: DecompressPointer r1
    //     0x7ac210: add             x1, x1, HEAP, lsl #32
    // 0x7ac214: SaveReg r1
    //     0x7ac214: str             x1, [SP, #-8]!
    // 0x7ac218: r0 = remove()
    //     0x7ac218: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x7ac21c: add             SP, SP, #8
    // 0x7ac220: ldr             x0, [fp, #0x10]
    // 0x7ac224: StoreField: r0->field_73 = rNULL
    //     0x7ac224: stur            NULL, [x0, #0x73]
    // 0x7ac228: b               #0x7ac230
    // 0x7ac22c: mov             x0, x2
    // 0x7ac230: LoadField: r1 = r0->field_77
    //     0x7ac230: ldur            w1, [x0, #0x77]
    // 0x7ac234: DecompressPointer r1
    //     0x7ac234: add             x1, x1, HEAP, lsl #32
    // 0x7ac238: cmp             w1, NULL
    // 0x7ac23c: b.eq            #0x7ac24c
    // 0x7ac240: SaveReg r0
    //     0x7ac240: str             x0, [SP, #-8]!
    // 0x7ac244: r0 = hideToolbar()
    //     0x7ac244: bl              #0x7ac270  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::hideToolbar
    // 0x7ac248: add             SP, SP, #8
    // 0x7ac24c: r0 = Null
    //     0x7ac24c: mov             x0, NULL
    // 0x7ac250: LeaveFrame
    //     0x7ac250: mov             SP, fp
    //     0x7ac254: ldp             fp, lr, [SP], #0x10
    // 0x7ac258: ret
    //     0x7ac258: ret             
    // 0x7ac25c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac25c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac260: b               #0x7ac188
    // 0x7ac264: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ac264: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
    // 0x7ac268: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ac268: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7ac26c: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x7ac26c: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  _ hideToolbar(/* No info */) {
    // ** addr: 0x7ac270, size: 0x64
    // 0x7ac270: EnterFrame
    //     0x7ac270: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac274: mov             fp, SP
    // 0x7ac278: CheckStackOverflow
    //     0x7ac278: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ac27c: cmp             SP, x16
    //     0x7ac280: b.ls            #0x7ac2cc
    // 0x7ac284: ldr             x0, [fp, #0x10]
    // 0x7ac288: LoadField: r1 = r0->field_77
    //     0x7ac288: ldur            w1, [x0, #0x77]
    // 0x7ac28c: DecompressPointer r1
    //     0x7ac28c: add             x1, x1, HEAP, lsl #32
    // 0x7ac290: cmp             w1, NULL
    // 0x7ac294: b.ne            #0x7ac2a8
    // 0x7ac298: r0 = Null
    //     0x7ac298: mov             x0, NULL
    // 0x7ac29c: LeaveFrame
    //     0x7ac29c: mov             SP, fp
    //     0x7ac2a0: ldp             fp, lr, [SP], #0x10
    // 0x7ac2a4: ret
    //     0x7ac2a4: ret             
    // 0x7ac2a8: SaveReg r1
    //     0x7ac2a8: str             x1, [SP, #-8]!
    // 0x7ac2ac: r0 = remove()
    //     0x7ac2ac: bl              #0x511c50  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::remove
    // 0x7ac2b0: add             SP, SP, #8
    // 0x7ac2b4: ldr             x1, [fp, #0x10]
    // 0x7ac2b8: StoreField: r1->field_77 = rNULL
    //     0x7ac2b8: stur            NULL, [x1, #0x77]
    // 0x7ac2bc: r0 = Null
    //     0x7ac2bc: mov             x0, NULL
    // 0x7ac2c0: LeaveFrame
    //     0x7ac2c0: mov             SP, fp
    //     0x7ac2c4: ldp             fp, lr, [SP], #0x10
    // 0x7ac2c8: ret
    //     0x7ac2c8: ret             
    // 0x7ac2cc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac2cc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac2d0: b               #0x7ac284
  }
  _ showToolbar(/* No info */) {
    // ** addr: 0xcce0a4, size: 0x108
    // 0xcce0a4: EnterFrame
    //     0xcce0a4: stp             fp, lr, [SP, #-0x10]!
    //     0xcce0a8: mov             fp, SP
    // 0xcce0ac: AllocStack(0x10)
    //     0xcce0ac: sub             SP, SP, #0x10
    // 0xcce0b0: CheckStackOverflow
    //     0xcce0b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcce0b4: cmp             SP, x16
    //     0xcce0b8: b.ls            #0xcce1a0
    // 0xcce0bc: ldr             x0, [fp, #0x10]
    // 0xcce0c0: LoadField: r1 = r0->field_77
    //     0xcce0c0: ldur            w1, [x0, #0x77]
    // 0xcce0c4: DecompressPointer r1
    //     0xcce0c4: add             x1, x1, HEAP, lsl #32
    // 0xcce0c8: cmp             w1, NULL
    // 0xcce0cc: b.eq            #0xcce0e0
    // 0xcce0d0: r0 = Null
    //     0xcce0d0: mov             x0, NULL
    // 0xcce0d4: LeaveFrame
    //     0xcce0d4: mov             SP, fp
    //     0xcce0d8: ldp             fp, lr, [SP], #0x10
    // 0xcce0dc: ret
    //     0xcce0dc: ret             
    // 0xcce0e0: r1 = 1
    //     0xcce0e0: mov             x1, #1
    // 0xcce0e4: r0 = AllocateContext()
    //     0xcce0e4: bl              #0xd68aa4  ; AllocateContextStub
    // 0xcce0e8: mov             x1, x0
    // 0xcce0ec: ldr             x0, [fp, #0x10]
    // 0xcce0f0: StoreField: r1->field_f = r0
    //     0xcce0f0: stur            w0, [x1, #0xf]
    // 0xcce0f4: mov             x2, x1
    // 0xcce0f8: r1 = Function '_buildToolbar@500251836':.
    //     0xcce0f8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd28] AnonymousClosure: (0xcce1ac), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_buildToolbar (0xcce1f8)
    //     0xcce0fc: ldr             x1, [x1, #0xd28]
    // 0xcce100: r0 = AllocateClosure()
    //     0xcce100: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xcce104: stur            x0, [fp, #-8]
    // 0xcce108: r0 = OverlayEntry()
    //     0xcce108: bl              #0x6efcd0  ; AllocateOverlayEntryStub -> OverlayEntry (size=0x24)
    // 0xcce10c: stur            x0, [fp, #-0x10]
    // 0xcce110: ldur            x16, [fp, #-8]
    // 0xcce114: stp             x16, x0, [SP, #-0x10]!
    // 0xcce118: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xcce118: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xcce11c: r0 = OverlayEntry()
    //     0xcce11c: bl              #0x594c98  ; [package:flutter/src/widgets/overlay.dart] OverlayEntry::OverlayEntry
    // 0xcce120: add             SP, SP, #0x10
    // 0xcce124: ldur            x0, [fp, #-0x10]
    // 0xcce128: ldr             x1, [fp, #0x10]
    // 0xcce12c: StoreField: r1->field_77 = r0
    //     0xcce12c: stur            w0, [x1, #0x77]
    //     0xcce130: ldurb           w16, [x1, #-1]
    //     0xcce134: ldurb           w17, [x0, #-1]
    //     0xcce138: and             x16, x17, x16, lsr #2
    //     0xcce13c: tst             x16, HEAP, lsr #32
    //     0xcce140: b.eq            #0xcce148
    //     0xcce144: bl              #0xd6826c
    // 0xcce148: LoadField: r0 = r1->field_7
    //     0xcce148: ldur            w0, [x1, #7]
    // 0xcce14c: DecompressPointer r0
    //     0xcce14c: add             x0, x0, HEAP, lsl #32
    // 0xcce150: r16 = true
    //     0xcce150: add             x16, NULL, #0x20  ; true
    // 0xcce154: stp             x16, x0, [SP, #-0x10]!
    // 0xcce158: r4 = const [0, 0x2, 0x2, 0x1, rootOverlay, 0x1, null]
    //     0xcce158: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f760] List(7) [0, 0x2, 0x2, 0x1, "rootOverlay", 0x1, Null]
    //     0xcce15c: ldr             x4, [x4, #0x760]
    // 0xcce160: r0 = of()
    //     0xcce160: bl              #0x59424c  ; [package:flutter/src/widgets/overlay.dart] Overlay::of
    // 0xcce164: add             SP, SP, #0x10
    // 0xcce168: mov             x1, x0
    // 0xcce16c: ldr             x0, [fp, #0x10]
    // 0xcce170: LoadField: r2 = r0->field_77
    //     0xcce170: ldur            w2, [x0, #0x77]
    // 0xcce174: DecompressPointer r2
    //     0xcce174: add             x2, x2, HEAP, lsl #32
    // 0xcce178: cmp             w2, NULL
    // 0xcce17c: b.eq            #0xcce1a8
    // 0xcce180: stp             x2, x1, [SP, #-0x10]!
    // 0xcce184: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xcce184: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xcce188: r0 = insert()
    //     0xcce188: bl              #0x594040  ; [package:flutter/src/widgets/overlay.dart] OverlayState::insert
    // 0xcce18c: add             SP, SP, #0x10
    // 0xcce190: r0 = Null
    //     0xcce190: mov             x0, NULL
    // 0xcce194: LeaveFrame
    //     0xcce194: mov             SP, fp
    //     0xcce198: ldp             fp, lr, [SP], #0x10
    // 0xcce19c: ret
    //     0xcce19c: ret             
    // 0xcce1a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce1a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce1a4: b               #0xcce0bc
    // 0xcce1a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcce1a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] Widget _buildToolbar(dynamic, BuildContext) {
    // ** addr: 0xcce1ac, size: 0x4c
    // 0xcce1ac: EnterFrame
    //     0xcce1ac: stp             fp, lr, [SP, #-0x10]!
    //     0xcce1b0: mov             fp, SP
    // 0xcce1b4: ldr             x0, [fp, #0x18]
    // 0xcce1b8: LoadField: r1 = r0->field_17
    //     0xcce1b8: ldur            w1, [x0, #0x17]
    // 0xcce1bc: DecompressPointer r1
    //     0xcce1bc: add             x1, x1, HEAP, lsl #32
    // 0xcce1c0: CheckStackOverflow
    //     0xcce1c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcce1c4: cmp             SP, x16
    //     0xcce1c8: b.ls            #0xcce1f0
    // 0xcce1cc: LoadField: r0 = r1->field_f
    //     0xcce1cc: ldur            w0, [x1, #0xf]
    // 0xcce1d0: DecompressPointer r0
    //     0xcce1d0: add             x0, x0, HEAP, lsl #32
    // 0xcce1d4: ldr             x16, [fp, #0x10]
    // 0xcce1d8: stp             x16, x0, [SP, #-0x10]!
    // 0xcce1dc: r0 = _buildToolbar()
    //     0xcce1dc: bl              #0xcce1f8  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::_buildToolbar
    // 0xcce1e0: add             SP, SP, #0x10
    // 0xcce1e4: LeaveFrame
    //     0xcce1e4: mov             SP, fp
    //     0xcce1e8: ldp             fp, lr, [SP], #0x10
    // 0xcce1ec: ret
    //     0xcce1ec: ret             
    // 0xcce1f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce1f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce1f4: b               #0xcce1cc
  }
  _ _buildToolbar(/* No info */) {
    // ** addr: 0xcce1f8, size: 0x3d8
    // 0xcce1f8: EnterFrame
    //     0xcce1f8: stp             fp, lr, [SP, #-0x10]!
    //     0xcce1fc: mov             fp, SP
    // 0xcce200: AllocStack(0x68)
    //     0xcce200: sub             SP, SP, #0x68
    // 0xcce204: CheckStackOverflow
    //     0xcce204: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcce208: cmp             SP, x16
    //     0xcce20c: b.ls            #0xcce5c0
    // 0xcce210: ldr             x0, [fp, #0x18]
    // 0xcce214: LoadField: r1 = r0->field_5b
    //     0xcce214: ldur            w1, [x0, #0x5b]
    // 0xcce218: DecompressPointer r1
    //     0xcce218: add             x1, x1, HEAP, lsl #32
    // 0xcce21c: stur            x1, [fp, #-0x10]
    // 0xcce220: cmp             w1, NULL
    // 0xcce224: b.ne            #0xcce250
    // 0xcce228: r0 = Container()
    //     0xcce228: bl              #0x590db8  ; AllocateContainerStub -> Container (size=0x38)
    // 0xcce22c: stur            x0, [fp, #-8]
    // 0xcce230: SaveReg r0
    //     0xcce230: str             x0, [SP, #-8]!
    // 0xcce234: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcce234: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcce238: r0 = Container()
    //     0xcce238: bl              #0x590470  ; [package:flutter/src/widgets/container.dart] Container::Container
    // 0xcce23c: add             SP, SP, #8
    // 0xcce240: ldur            x0, [fp, #-8]
    // 0xcce244: LeaveFrame
    //     0xcce244: mov             SP, fp
    //     0xcce248: ldp             fp, lr, [SP], #0x10
    // 0xcce24c: ret
    //     0xcce24c: ret             
    // 0xcce250: LoadField: r2 = r0->field_7
    //     0xcce250: ldur            w2, [x0, #7]
    // 0xcce254: DecompressPointer r2
    //     0xcce254: add             x2, x2, HEAP, lsl #32
    // 0xcce258: stur            x2, [fp, #-8]
    // 0xcce25c: SaveReg r2
    //     0xcce25c: str             x2, [SP, #-8]!
    // 0xcce260: r0 = findRenderObject()
    //     0xcce260: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xcce264: add             SP, SP, #8
    // 0xcce268: mov             x3, x0
    // 0xcce26c: stur            x3, [fp, #-0x18]
    // 0xcce270: cmp             w3, NULL
    // 0xcce274: b.eq            #0xcce5c8
    // 0xcce278: mov             x0, x3
    // 0xcce27c: r2 = Null
    //     0xcce27c: mov             x2, NULL
    // 0xcce280: r1 = Null
    //     0xcce280: mov             x1, NULL
    // 0xcce284: r4 = LoadClassIdInstr(r0)
    //     0xcce284: ldur            x4, [x0, #-1]
    //     0xcce288: ubfx            x4, x4, #0xc, #0x14
    // 0xcce28c: sub             x4, x4, #0x965
    // 0xcce290: cmp             x4, #0x8b
    // 0xcce294: b.ls            #0xcce2ac
    // 0xcce298: r8 = RenderBox
    //     0xcce298: add             x8, PP, #0xa, lsl #12  ; [pp+0xafa0] Type: RenderBox
    //     0xcce29c: ldr             x8, [x8, #0xfa0]
    // 0xcce2a0: r3 = Null
    //     0xcce2a0: add             x3, PP, #0x4b, lsl #12  ; [pp+0x4bd30] Null
    //     0xcce2a4: ldr             x3, [x3, #0xd30]
    // 0xcce2a8: r0 = RenderBox()
    //     0xcce2a8: bl              #0x50e924  ; IsType_RenderBox_Stub
    // 0xcce2ac: ldur            x16, [fp, #-0x18]
    // 0xcce2b0: r30 = Instance_Offset
    //     0xcce2b0: ldr             lr, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0xcce2b4: stp             lr, x16, [SP, #-0x10]!
    // 0xcce2b8: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xcce2b8: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xcce2bc: r0 = localToGlobal()
    //     0xcce2bc: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xcce2c0: add             SP, SP, #0x10
    // 0xcce2c4: mov             x1, x0
    // 0xcce2c8: ldur            x0, [fp, #-0x18]
    // 0xcce2cc: stur            x1, [fp, #-0x20]
    // 0xcce2d0: LoadField: r2 = r0->field_57
    //     0xcce2d0: ldur            w2, [x0, #0x57]
    // 0xcce2d4: DecompressPointer r2
    //     0xcce2d4: add             x2, x2, HEAP, lsl #32
    // 0xcce2d8: cmp             w2, NULL
    // 0xcce2dc: b.eq            #0xcce5cc
    // 0xcce2e0: SaveReg r2
    //     0xcce2e0: str             x2, [SP, #-8]!
    // 0xcce2e4: r0 = bottomRight()
    //     0xcce2e4: bl              #0x857264  ; [dart:ui] Size::bottomRight
    // 0xcce2e8: add             SP, SP, #8
    // 0xcce2ec: ldur            x16, [fp, #-0x18]
    // 0xcce2f0: stp             x0, x16, [SP, #-0x10]!
    // 0xcce2f4: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xcce2f4: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xcce2f8: r0 = localToGlobal()
    //     0xcce2f8: bl              #0x64e820  ; [package:flutter/src/rendering/box.dart] RenderBox::localToGlobal
    // 0xcce2fc: add             SP, SP, #0x10
    // 0xcce300: stur            x0, [fp, #-0x18]
    // 0xcce304: r0 = Rect()
    //     0xcce304: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xcce308: stur            x0, [fp, #-0x28]
    // 0xcce30c: ldur            x16, [fp, #-0x20]
    // 0xcce310: stp             x16, x0, [SP, #-0x10]!
    // 0xcce314: ldur            x16, [fp, #-0x18]
    // 0xcce318: SaveReg r16
    //     0xcce318: str             x16, [SP, #-8]!
    // 0xcce31c: r0 = Rect.fromPoints()
    //     0xcce31c: bl              #0x656aa4  ; [dart:ui] Rect::Rect.fromPoints
    // 0xcce320: add             SP, SP, #0x18
    // 0xcce324: ldr             x1, [fp, #0x18]
    // 0xcce328: LoadField: r0 = r1->field_47
    //     0xcce328: ldur            w0, [x1, #0x47]
    // 0xcce32c: DecompressPointer r0
    //     0xcce32c: add             x0, x0, HEAP, lsl #32
    // 0xcce330: r2 = LoadClassIdInstr(r0)
    //     0xcce330: ldur            x2, [x0, #-1]
    //     0xcce334: ubfx            x2, x2, #0xc, #0x14
    // 0xcce338: SaveReg r0
    //     0xcce338: str             x0, [SP, #-8]!
    // 0xcce33c: mov             x0, x2
    // 0xcce340: r0 = GDT[cid_x0 + 0xfe03]()
    //     0xcce340: mov             x17, #0xfe03
    //     0xcce344: add             lr, x0, x17
    //     0xcce348: ldr             lr, [x21, lr, lsl #3]
    //     0xcce34c: blr             lr
    // 0xcce350: add             SP, SP, #8
    // 0xcce354: LoadField: r1 = r0->field_7
    //     0xcce354: ldur            w1, [x0, #7]
    // 0xcce358: DecompressPointer r1
    //     0xcce358: add             x1, x1, HEAP, lsl #32
    // 0xcce35c: LoadField: d0 = r1->field_f
    //     0xcce35c: ldur            d0, [x1, #0xf]
    // 0xcce360: ldr             x1, [fp, #0x18]
    // 0xcce364: stur            d0, [fp, #-0x60]
    // 0xcce368: LoadField: r0 = r1->field_47
    //     0xcce368: ldur            w0, [x1, #0x47]
    // 0xcce36c: DecompressPointer r0
    //     0xcce36c: add             x0, x0, HEAP, lsl #32
    // 0xcce370: r2 = LoadClassIdInstr(r0)
    //     0xcce370: ldur            x2, [x0, #-1]
    //     0xcce374: ubfx            x2, x2, #0xc, #0x14
    // 0xcce378: SaveReg r0
    //     0xcce378: str             x0, [SP, #-8]!
    // 0xcce37c: mov             x0, x2
    // 0xcce380: r0 = GDT[cid_x0 + 0xcaae]()
    //     0xcce380: mov             x17, #0xcaae
    //     0xcce384: add             lr, x0, x17
    //     0xcce388: ldr             lr, [x21, lr, lsl #3]
    //     0xcce38c: blr             lr
    // 0xcce390: add             SP, SP, #8
    // 0xcce394: LoadField: r1 = r0->field_7
    //     0xcce394: ldur            w1, [x0, #7]
    // 0xcce398: DecompressPointer r1
    //     0xcce398: add             x1, x1, HEAP, lsl #32
    // 0xcce39c: LoadField: d0 = r1->field_f
    //     0xcce39c: ldur            d0, [x1, #0xf]
    // 0xcce3a0: ldur            d1, [fp, #-0x60]
    // 0xcce3a4: fsub            d2, d1, d0
    // 0xcce3a8: ldr             x1, [fp, #0x18]
    // 0xcce3ac: LoadField: d0 = r1->field_2b
    //     0xcce3ac: ldur            d0, [x1, #0x2b]
    // 0xcce3b0: d1 = 2.000000
    //     0xcce3b0: fmov            d1, #2.00000000
    // 0xcce3b4: fdiv            d3, d0, d1
    // 0xcce3b8: fcmp            d2, d3
    // 0xcce3bc: b.vs            #0xcce3dc
    // 0xcce3c0: b.le            #0xcce3dc
    // 0xcce3c4: ldur            x2, [fp, #-0x28]
    // 0xcce3c8: LoadField: d0 = r2->field_17
    //     0xcce3c8: ldur            d0, [x2, #0x17]
    // 0xcce3cc: LoadField: d2 = r2->field_7
    //     0xcce3cc: ldur            d2, [x2, #7]
    // 0xcce3d0: fsub            d3, d0, d2
    // 0xcce3d4: fdiv            d0, d3, d1
    // 0xcce3d8: b               #0xcce474
    // 0xcce3dc: ldur            x2, [fp, #-0x28]
    // 0xcce3e0: LoadField: r0 = r1->field_47
    //     0xcce3e0: ldur            w0, [x1, #0x47]
    // 0xcce3e4: DecompressPointer r0
    //     0xcce3e4: add             x0, x0, HEAP, lsl #32
    // 0xcce3e8: r3 = LoadClassIdInstr(r0)
    //     0xcce3e8: ldur            x3, [x0, #-1]
    //     0xcce3ec: ubfx            x3, x3, #0xc, #0x14
    // 0xcce3f0: SaveReg r0
    //     0xcce3f0: str             x0, [SP, #-8]!
    // 0xcce3f4: mov             x0, x3
    // 0xcce3f8: r0 = GDT[cid_x0 + 0xcaae]()
    //     0xcce3f8: mov             x17, #0xcaae
    //     0xcce3fc: add             lr, x0, x17
    //     0xcce400: ldr             lr, [x21, lr, lsl #3]
    //     0xcce404: blr             lr
    // 0xcce408: add             SP, SP, #8
    // 0xcce40c: LoadField: r1 = r0->field_7
    //     0xcce40c: ldur            w1, [x0, #7]
    // 0xcce410: DecompressPointer r1
    //     0xcce410: add             x1, x1, HEAP, lsl #32
    // 0xcce414: LoadField: d0 = r1->field_7
    //     0xcce414: ldur            d0, [x1, #7]
    // 0xcce418: ldr             x1, [fp, #0x18]
    // 0xcce41c: stur            d0, [fp, #-0x60]
    // 0xcce420: LoadField: r0 = r1->field_47
    //     0xcce420: ldur            w0, [x1, #0x47]
    // 0xcce424: DecompressPointer r0
    //     0xcce424: add             x0, x0, HEAP, lsl #32
    // 0xcce428: r2 = LoadClassIdInstr(r0)
    //     0xcce428: ldur            x2, [x0, #-1]
    //     0xcce42c: ubfx            x2, x2, #0xc, #0x14
    // 0xcce430: SaveReg r0
    //     0xcce430: str             x0, [SP, #-8]!
    // 0xcce434: mov             x0, x2
    // 0xcce438: r0 = GDT[cid_x0 + 0xfe03]()
    //     0xcce438: mov             x17, #0xfe03
    //     0xcce43c: add             lr, x0, x17
    //     0xcce440: ldr             lr, [x21, lr, lsl #3]
    //     0xcce444: blr             lr
    // 0xcce448: add             SP, SP, #8
    // 0xcce44c: LoadField: r1 = r0->field_7
    //     0xcce44c: ldur            w1, [x0, #7]
    // 0xcce450: DecompressPointer r1
    //     0xcce450: add             x1, x1, HEAP, lsl #32
    // 0xcce454: LoadField: d0 = r1->field_7
    //     0xcce454: ldur            d0, [x1, #7]
    // 0xcce458: ldur            d1, [fp, #-0x60]
    // 0xcce45c: fadd            d2, d1, d0
    // 0xcce460: d0 = 2.000000
    //     0xcce460: fmov            d0, #2.00000000
    // 0xcce464: fdiv            d1, d2, d0
    // 0xcce468: mov             v0.16b, v1.16b
    // 0xcce46c: ldr             x1, [fp, #0x18]
    // 0xcce470: ldur            x2, [fp, #-0x28]
    // 0xcce474: ldur            x3, [fp, #-0x10]
    // 0xcce478: stur            d0, [fp, #-0x60]
    // 0xcce47c: LoadField: r0 = r1->field_47
    //     0xcce47c: ldur            w0, [x1, #0x47]
    // 0xcce480: DecompressPointer r0
    //     0xcce480: add             x0, x0, HEAP, lsl #32
    // 0xcce484: r4 = LoadClassIdInstr(r0)
    //     0xcce484: ldur            x4, [x0, #-1]
    //     0xcce488: ubfx            x4, x4, #0xc, #0x14
    // 0xcce48c: SaveReg r0
    //     0xcce48c: str             x0, [SP, #-8]!
    // 0xcce490: mov             x0, x4
    // 0xcce494: r0 = GDT[cid_x0 + 0xcaae]()
    //     0xcce494: mov             x17, #0xcaae
    //     0xcce498: add             lr, x0, x17
    //     0xcce49c: ldr             lr, [x21, lr, lsl #3]
    //     0xcce4a0: blr             lr
    // 0xcce4a4: add             SP, SP, #8
    // 0xcce4a8: LoadField: r1 = r0->field_7
    //     0xcce4a8: ldur            w1, [x0, #7]
    // 0xcce4ac: DecompressPointer r1
    //     0xcce4ac: add             x1, x1, HEAP, lsl #32
    // 0xcce4b0: LoadField: d0 = r1->field_f
    //     0xcce4b0: ldur            d0, [x1, #0xf]
    // 0xcce4b4: ldr             x0, [fp, #0x18]
    // 0xcce4b8: LoadField: d1 = r0->field_f
    //     0xcce4b8: ldur            d1, [x0, #0xf]
    // 0xcce4bc: fsub            d2, d0, d1
    // 0xcce4c0: stur            d2, [fp, #-0x68]
    // 0xcce4c4: r0 = Offset()
    //     0xcce4c4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xcce4c8: ldur            d0, [fp, #-0x60]
    // 0xcce4cc: stur            x0, [fp, #-0x18]
    // 0xcce4d0: StoreField: r0->field_7 = d0
    //     0xcce4d0: stur            d0, [x0, #7]
    // 0xcce4d4: ldur            d0, [fp, #-0x68]
    // 0xcce4d8: StoreField: r0->field_f = d0
    //     0xcce4d8: stur            d0, [x0, #0xf]
    // 0xcce4dc: ldur            x16, [fp, #-8]
    // 0xcce4e0: SaveReg r16
    //     0xcce4e0: str             x16, [SP, #-8]!
    // 0xcce4e4: r0 = of()
    //     0xcce4e4: bl              #0x6c263c  ; [package:flutter/src/widgets/basic.dart] Directionality::of
    // 0xcce4e8: add             SP, SP, #8
    // 0xcce4ec: mov             x1, x0
    // 0xcce4f0: ldr             x0, [fp, #0x18]
    // 0xcce4f4: stur            x1, [fp, #-0x50]
    // 0xcce4f8: LoadField: d0 = r0->field_f
    //     0xcce4f8: ldur            d0, [x0, #0xf]
    // 0xcce4fc: stur            d0, [fp, #-0x60]
    // 0xcce500: LoadField: r2 = r0->field_6f
    //     0xcce500: ldur            w2, [x0, #0x6f]
    // 0xcce504: DecompressPointer r2
    //     0xcce504: add             x2, x2, HEAP, lsl #32
    // 0xcce508: stur            x2, [fp, #-0x48]
    // 0xcce50c: LoadField: r3 = r0->field_4f
    //     0xcce50c: ldur            w3, [x0, #0x4f]
    // 0xcce510: DecompressPointer r3
    //     0xcce510: add             x3, x3, HEAP, lsl #32
    // 0xcce514: stur            x3, [fp, #-0x40]
    // 0xcce518: LoadField: r4 = r0->field_47
    //     0xcce518: ldur            w4, [x0, #0x47]
    // 0xcce51c: DecompressPointer r4
    //     0xcce51c: add             x4, x4, HEAP, lsl #32
    // 0xcce520: stur            x4, [fp, #-0x38]
    // 0xcce524: LoadField: r5 = r0->field_43
    //     0xcce524: ldur            w5, [x0, #0x43]
    // 0xcce528: DecompressPointer r5
    //     0xcce528: add             x5, x5, HEAP, lsl #32
    // 0xcce52c: stur            x5, [fp, #-0x30]
    // 0xcce530: LoadField: r6 = r0->field_5f
    //     0xcce530: ldur            w6, [x0, #0x5f]
    // 0xcce534: DecompressPointer r6
    //     0xcce534: add             x6, x6, HEAP, lsl #32
    // 0xcce538: stur            x6, [fp, #-0x20]
    // 0xcce53c: LoadField: r7 = r0->field_6b
    //     0xcce53c: ldur            w7, [x0, #0x6b]
    // 0xcce540: DecompressPointer r7
    //     0xcce540: add             x7, x7, HEAP, lsl #32
    // 0xcce544: stur            x7, [fp, #-8]
    // 0xcce548: r0 = _SelectionToolbarOverlay()
    //     0xcce548: bl              #0xcce5d0  ; Allocate_SelectionToolbarOverlayStub -> _SelectionToolbarOverlay (size=0x38)
    // 0xcce54c: ldur            d0, [fp, #-0x60]
    // 0xcce550: stur            x0, [fp, #-0x58]
    // 0xcce554: StoreField: r0->field_b = d0
    //     0xcce554: stur            d0, [x0, #0xb]
    // 0xcce558: ldur            x1, [fp, #-0x48]
    // 0xcce55c: StoreField: r0->field_13 = r1
    //     0xcce55c: stur            w1, [x0, #0x13]
    // 0xcce560: ldur            x1, [fp, #-0x40]
    // 0xcce564: StoreField: r0->field_17 = r1
    //     0xcce564: stur            w1, [x0, #0x17]
    // 0xcce568: ldur            x1, [fp, #-0x28]
    // 0xcce56c: StoreField: r0->field_1b = r1
    //     0xcce56c: stur            w1, [x0, #0x1b]
    // 0xcce570: ldur            x1, [fp, #-0x10]
    // 0xcce574: StoreField: r0->field_1f = r1
    //     0xcce574: stur            w1, [x0, #0x1f]
    // 0xcce578: ldur            x1, [fp, #-0x30]
    // 0xcce57c: StoreField: r0->field_23 = r1
    //     0xcce57c: stur            w1, [x0, #0x23]
    // 0xcce580: ldur            x1, [fp, #-0x18]
    // 0xcce584: StoreField: r0->field_27 = r1
    //     0xcce584: stur            w1, [x0, #0x27]
    // 0xcce588: ldur            x1, [fp, #-0x38]
    // 0xcce58c: StoreField: r0->field_2b = r1
    //     0xcce58c: stur            w1, [x0, #0x2b]
    // 0xcce590: ldur            x1, [fp, #-0x20]
    // 0xcce594: StoreField: r0->field_2f = r1
    //     0xcce594: stur            w1, [x0, #0x2f]
    // 0xcce598: ldur            x1, [fp, #-8]
    // 0xcce59c: StoreField: r0->field_33 = r1
    //     0xcce59c: stur            w1, [x0, #0x33]
    // 0xcce5a0: r0 = Directionality()
    //     0xcce5a0: bl              #0x875144  ; AllocateDirectionalityStub -> Directionality (size=0x14)
    // 0xcce5a4: ldur            x1, [fp, #-0x50]
    // 0xcce5a8: StoreField: r0->field_f = r1
    //     0xcce5a8: stur            w1, [x0, #0xf]
    // 0xcce5ac: ldur            x1, [fp, #-0x58]
    // 0xcce5b0: StoreField: r0->field_b = r1
    //     0xcce5b0: stur            w1, [x0, #0xb]
    // 0xcce5b4: LeaveFrame
    //     0xcce5b4: mov             SP, fp
    //     0xcce5b8: ldp             fp, lr, [SP], #0x10
    // 0xcce5bc: ret
    //     0xcce5bc: ret             
    // 0xcce5c0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce5c0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce5c4: b               #0xcce210
    // 0xcce5c8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcce5c8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcce5cc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcce5cc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4432, size: 0x34, field offset: 0x8
class ExtendedTextSelectionOverlay extends Object {

  late final SelectionOverlay _selectionOverlay; // offset: 0x14
  late Offset _dragEndPosition; // offset: 0x2c
  late Offset _dragStartPosition; // offset: 0x30

  _ _updateSelectionOverlay(/* No info */) {
    // ** addr: 0x51efe0, size: 0x190
    // 0x51efe0: EnterFrame
    //     0x51efe0: stp             fp, lr, [SP, #-0x10]!
    //     0x51efe4: mov             fp, SP
    // 0x51efe8: AllocStack(0x10)
    //     0x51efe8: sub             SP, SP, #0x10
    // 0x51efec: CheckStackOverflow
    //     0x51efec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x51eff0: cmp             SP, x16
    //     0x51eff4: b.ls            #0x51f158
    // 0x51eff8: ldr             x0, [fp, #0x10]
    // 0x51effc: LoadField: r1 = r0->field_13
    //     0x51effc: ldur            w1, [x0, #0x13]
    // 0x51f000: DecompressPointer r1
    //     0x51f000: add             x1, x1, HEAP, lsl #32
    // 0x51f004: r16 = Sentinel
    //     0x51f004: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x51f008: cmp             w1, w16
    // 0x51f00c: b.eq            #0x51f160
    // 0x51f010: stur            x1, [fp, #-0x10]
    // 0x51f014: LoadField: r2 = r0->field_7
    //     0x51f014: ldur            w2, [x0, #7]
    // 0x51f018: DecompressPointer r2
    //     0x51f018: add             x2, x2, HEAP, lsl #32
    // 0x51f01c: stur            x2, [fp, #-8]
    // 0x51f020: SaveReg r2
    //     0x51f020: str             x2, [SP, #-8]!
    // 0x51f024: r0 = textDirection()
    //     0x51f024: bl              #0x525930  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::textDirection
    // 0x51f028: add             SP, SP, #8
    // 0x51f02c: ldr             x16, [fp, #0x10]
    // 0x51f030: stp             x0, x16, [SP, #-0x10]!
    // 0x51f034: r16 = Instance_TextSelectionHandleType
    //     0x51f034: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f7a0] Obj!TextSelectionHandleType@b64851
    //     0x51f038: ldr             x16, [x16, #0x7a0]
    // 0x51f03c: r30 = Instance_TextSelectionHandleType
    //     0x51f03c: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f7a8] Obj!TextSelectionHandleType@b64831
    //     0x51f040: ldr             lr, [lr, #0x7a8]
    // 0x51f044: stp             lr, x16, [SP, #-0x10]!
    // 0x51f048: r0 = _chooseType()
    //     0x51f048: bl              #0x5258e0  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_chooseType
    // 0x51f04c: add             SP, SP, #0x20
    // 0x51f050: ldur            x16, [fp, #-0x10]
    // 0x51f054: stp             x0, x16, [SP, #-0x10]!
    // 0x51f058: r0 = startHandleType=()
    //     0x51f058: bl              #0x525860  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::startHandleType=
    // 0x51f05c: add             SP, SP, #0x10
    // 0x51f060: ldr             x16, [fp, #0x10]
    // 0x51f064: SaveReg r16
    //     0x51f064: str             x16, [SP, #-8]!
    // 0x51f068: r0 = _getStartGlyphHeight()
    //     0x51f068: bl              #0x52566c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_getStartGlyphHeight
    // 0x51f06c: add             SP, SP, #8
    // 0x51f070: ldur            x16, [fp, #-0x10]
    // 0x51f074: SaveReg r16
    //     0x51f074: str             x16, [SP, #-8]!
    // 0x51f078: SaveReg d0
    //     0x51f078: str             d0, [SP, #-8]!
    // 0x51f07c: r0 = lineHeightAtStart=()
    //     0x51f07c: bl              #0x525608  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::lineHeightAtStart=
    // 0x51f080: add             SP, SP, #0x10
    // 0x51f084: ldur            x0, [fp, #-8]
    // 0x51f088: LoadField: r1 = r0->field_eb
    //     0x51f088: ldur            w1, [x0, #0xeb]
    // 0x51f08c: DecompressPointer r1
    //     0x51f08c: add             x1, x1, HEAP, lsl #32
    // 0x51f090: LoadField: r2 = r1->field_1b
    //     0x51f090: ldur            w2, [x1, #0x1b]
    // 0x51f094: DecompressPointer r2
    //     0x51f094: add             x2, x2, HEAP, lsl #32
    // 0x51f098: cmp             w2, NULL
    // 0x51f09c: b.eq            #0x51f16c
    // 0x51f0a0: ldr             x16, [fp, #0x10]
    // 0x51f0a4: stp             x2, x16, [SP, #-0x10]!
    // 0x51f0a8: r16 = Instance_TextSelectionHandleType
    //     0x51f0a8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f7a8] Obj!TextSelectionHandleType@b64831
    //     0x51f0ac: ldr             x16, [x16, #0x7a8]
    // 0x51f0b0: r30 = Instance_TextSelectionHandleType
    //     0x51f0b0: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f7a0] Obj!TextSelectionHandleType@b64851
    //     0x51f0b4: ldr             lr, [lr, #0x7a0]
    // 0x51f0b8: stp             lr, x16, [SP, #-0x10]!
    // 0x51f0bc: r0 = _chooseType()
    //     0x51f0bc: bl              #0x5258e0  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_chooseType
    // 0x51f0c0: add             SP, SP, #0x20
    // 0x51f0c4: ldur            x16, [fp, #-0x10]
    // 0x51f0c8: stp             x0, x16, [SP, #-0x10]!
    // 0x51f0cc: r0 = endHandleType=()
    //     0x51f0cc: bl              #0x525588  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::endHandleType=
    // 0x51f0d0: add             SP, SP, #0x10
    // 0x51f0d4: ldr             x16, [fp, #0x10]
    // 0x51f0d8: SaveReg r16
    //     0x51f0d8: str             x16, [SP, #-8]!
    // 0x51f0dc: r0 = _getEndGlyphHeight()
    //     0x51f0dc: bl              #0x52447c  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_getEndGlyphHeight
    // 0x51f0e0: add             SP, SP, #8
    // 0x51f0e4: ldur            x16, [fp, #-0x10]
    // 0x51f0e8: SaveReg r16
    //     0x51f0e8: str             x16, [SP, #-8]!
    // 0x51f0ec: SaveReg d0
    //     0x51f0ec: str             d0, [SP, #-8]!
    // 0x51f0f0: r0 = lineHeightAtEnd=()
    //     0x51f0f0: bl              #0x524418  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::lineHeightAtEnd=
    // 0x51f0f4: add             SP, SP, #0x10
    // 0x51f0f8: ldr             x0, [fp, #0x10]
    // 0x51f0fc: LoadField: r1 = r0->field_17
    //     0x51f0fc: ldur            w1, [x0, #0x17]
    // 0x51f100: DecompressPointer r1
    //     0x51f100: add             x1, x1, HEAP, lsl #32
    // 0x51f104: LoadField: r0 = r1->field_b
    //     0x51f104: ldur            w0, [x1, #0xb]
    // 0x51f108: DecompressPointer r0
    //     0x51f108: add             x0, x0, HEAP, lsl #32
    // 0x51f10c: ldur            x16, [fp, #-8]
    // 0x51f110: stp             x0, x16, [SP, #-0x10]!
    // 0x51f114: r0 = getEndpointsForSelection()
    //     0x51f114: bl              #0x51f684  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::getEndpointsForSelection
    // 0x51f118: add             SP, SP, #0x10
    // 0x51f11c: ldur            x16, [fp, #-0x10]
    // 0x51f120: stp             x0, x16, [SP, #-0x10]!
    // 0x51f124: r0 = selectionEndPoints=()
    //     0x51f124: bl              #0x51f5d4  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::selectionEndPoints=
    // 0x51f128: add             SP, SP, #0x10
    // 0x51f12c: ldur            x0, [fp, #-8]
    // 0x51f130: LoadField: r1 = r0->field_8f
    //     0x51f130: ldur            w1, [x0, #0x8f]
    // 0x51f134: DecompressPointer r1
    //     0x51f134: add             x1, x1, HEAP, lsl #32
    // 0x51f138: ldur            x16, [fp, #-0x10]
    // 0x51f13c: stp             x1, x16, [SP, #-0x10]!
    // 0x51f140: r0 = toolbarLocation=()
    //     0x51f140: bl              #0x51f170  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::toolbarLocation=
    // 0x51f144: add             SP, SP, #0x10
    // 0x51f148: r0 = Null
    //     0x51f148: mov             x0, NULL
    // 0x51f14c: LeaveFrame
    //     0x51f14c: mov             SP, fp
    //     0x51f150: ldp             fp, lr, [SP], #0x10
    // 0x51f154: ret
    //     0x51f154: ret             
    // 0x51f158: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x51f158: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x51f15c: b               #0x51eff8
    // 0x51f160: r9 = _selectionOverlay
    //     0x51f160: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0x51f164: ldr             x9, [x9, #0x3e8]
    // 0x51f168: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x51f168: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x51f16c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x51f16c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getEndGlyphHeight(/* No info */) {
    // ** addr: 0x52447c, size: 0x1f4
    // 0x52447c: EnterFrame
    //     0x52447c: stp             fp, lr, [SP, #-0x10]!
    //     0x524480: mov             fp, SP
    // 0x524484: AllocStack(0x28)
    //     0x524484: sub             SP, SP, #0x28
    // 0x524488: CheckStackOverflow
    //     0x524488: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52448c: cmp             SP, x16
    //     0x524490: b.ls            #0x524650
    // 0x524494: ldr             x0, [fp, #0x10]
    // 0x524498: LoadField: r1 = r0->field_7
    //     0x524498: ldur            w1, [x0, #7]
    // 0x52449c: DecompressPointer r1
    //     0x52449c: add             x1, x1, HEAP, lsl #32
    // 0x5244a0: stur            x1, [fp, #-0x10]
    // 0x5244a4: LoadField: r2 = r1->field_eb
    //     0x5244a4: ldur            w2, [x1, #0xeb]
    // 0x5244a8: DecompressPointer r2
    //     0x5244a8: add             x2, x2, HEAP, lsl #32
    // 0x5244ac: stur            x2, [fp, #-8]
    // 0x5244b0: LoadField: r3 = r2->field_f
    //     0x5244b0: ldur            w3, [x2, #0xf]
    // 0x5244b4: DecompressPointer r3
    //     0x5244b4: add             x3, x3, HEAP, lsl #32
    // 0x5244b8: cmp             w3, NULL
    // 0x5244bc: b.eq            #0x524658
    // 0x5244c0: SaveReg r3
    //     0x5244c0: str             x3, [SP, #-8]!
    // 0x5244c4: r0 = toPlainText()
    //     0x5244c4: bl              #0x521774  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0x5244c8: add             SP, SP, #8
    // 0x5244cc: ldr             x1, [fp, #0x10]
    // 0x5244d0: LoadField: r2 = r1->field_f
    //     0x5244d0: ldur            w2, [x1, #0xf]
    // 0x5244d4: DecompressPointer r2
    //     0x5244d4: add             x2, x2, HEAP, lsl #32
    // 0x5244d8: LoadField: r3 = r2->field_b
    //     0x5244d8: ldur            w3, [x2, #0xb]
    // 0x5244dc: DecompressPointer r3
    //     0x5244dc: add             x3, x3, HEAP, lsl #32
    // 0x5244e0: cmp             w3, NULL
    // 0x5244e4: b.eq            #0x52465c
    // 0x5244e8: LoadField: r2 = r3->field_13
    //     0x5244e8: ldur            w2, [x3, #0x13]
    // 0x5244ec: DecompressPointer r2
    //     0x5244ec: add             x2, x2, HEAP, lsl #32
    // 0x5244f0: LoadField: r3 = r2->field_27
    //     0x5244f0: ldur            w3, [x2, #0x27]
    // 0x5244f4: DecompressPointer r3
    //     0x5244f4: add             x3, x3, HEAP, lsl #32
    // 0x5244f8: LoadField: r2 = r3->field_7
    //     0x5244f8: ldur            w2, [x3, #7]
    // 0x5244fc: DecompressPointer r2
    //     0x5244fc: add             x2, x2, HEAP, lsl #32
    // 0x524500: stur            x2, [fp, #-0x18]
    // 0x524504: r3 = LoadClassIdInstr(r0)
    //     0x524504: ldur            x3, [x0, #-1]
    //     0x524508: ubfx            x3, x3, #0xc, #0x14
    // 0x52450c: stp             x2, x0, [SP, #-0x10]!
    // 0x524510: mov             x0, x3
    // 0x524514: mov             lr, x0
    // 0x524518: ldr             lr, [x21, lr, lsl #3]
    // 0x52451c: blr             lr
    // 0x524520: add             SP, SP, #0x10
    // 0x524524: tbnz            w0, #4, #0x5245d8
    // 0x524528: ldr             x0, [fp, #0x10]
    // 0x52452c: LoadField: r1 = r0->field_17
    //     0x52452c: ldur            w1, [x0, #0x17]
    // 0x524530: DecompressPointer r1
    //     0x524530: add             x1, x1, HEAP, lsl #32
    // 0x524534: LoadField: r2 = r1->field_b
    //     0x524534: ldur            w2, [x1, #0xb]
    // 0x524538: DecompressPointer r2
    //     0x524538: add             x2, x2, HEAP, lsl #32
    // 0x52453c: LoadField: r1 = r2->field_7
    //     0x52453c: ldur            x1, [x2, #7]
    // 0x524540: tbnz            x1, #0x3f, #0x5245d8
    // 0x524544: LoadField: r3 = r2->field_f
    //     0x524544: ldur            x3, [x2, #0xf]
    // 0x524548: tbnz            x3, #0x3f, #0x5245d8
    // 0x52454c: cmp             x1, x3
    // 0x524550: b.eq            #0x5245d8
    // 0x524554: ldur            x16, [fp, #-0x18]
    // 0x524558: stp             x16, x2, [SP, #-0x10]!
    // 0x52455c: r0 = textInside()
    //     0x52455c: bl              #0x525528  ; [dart:ui] TextRange::textInside
    // 0x524560: add             SP, SP, #0x10
    // 0x524564: SaveReg r0
    //     0x524564: str             x0, [SP, #-8]!
    // 0x524568: r0 = StringCharacters.characters()
    //     0x524568: bl              #0x5254a4  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x52456c: add             SP, SP, #8
    // 0x524570: SaveReg r0
    //     0x524570: str             x0, [SP, #-8]!
    // 0x524574: r0 = last()
    //     0x524574: bl              #0x5054f8  ; [package:characters/src/characters_impl.dart] StringCharacters::last
    // 0x524578: add             SP, SP, #8
    // 0x52457c: LoadField: r1 = r0->field_7
    //     0x52457c: ldur            w1, [x0, #7]
    // 0x524580: DecompressPointer r1
    //     0x524580: add             x1, x1, HEAP, lsl #32
    // 0x524584: ldr             x0, [fp, #0x10]
    // 0x524588: LoadField: r2 = r0->field_17
    //     0x524588: ldur            w2, [x0, #0x17]
    // 0x52458c: DecompressPointer r2
    //     0x52458c: add             x2, x2, HEAP, lsl #32
    // 0x524590: LoadField: r0 = r2->field_b
    //     0x524590: ldur            w0, [x2, #0xb]
    // 0x524594: DecompressPointer r0
    //     0x524594: add             x0, x0, HEAP, lsl #32
    // 0x524598: LoadField: r2 = r0->field_f
    //     0x524598: ldur            x2, [x0, #0xf]
    // 0x52459c: stur            x2, [fp, #-0x28]
    // 0x5245a0: r0 = LoadInt32Instr(r1)
    //     0x5245a0: sbfx            x0, x1, #1, #0x1f
    // 0x5245a4: sub             x1, x2, x0
    // 0x5245a8: stur            x1, [fp, #-0x20]
    // 0x5245ac: r0 = TextRange()
    //     0x5245ac: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x5245b0: mov             x1, x0
    // 0x5245b4: ldur            x0, [fp, #-0x20]
    // 0x5245b8: StoreField: r1->field_7 = r0
    //     0x5245b8: stur            x0, [x1, #7]
    // 0x5245bc: ldur            x0, [fp, #-0x28]
    // 0x5245c0: StoreField: r1->field_f = r0
    //     0x5245c0: stur            x0, [x1, #0xf]
    // 0x5245c4: ldur            x16, [fp, #-0x10]
    // 0x5245c8: stp             x1, x16, [SP, #-0x10]!
    // 0x5245cc: r0 = getRectForComposingRange()
    //     0x5245cc: bl              #0x524670  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::getRectForComposingRange
    // 0x5245d0: add             SP, SP, #0x10
    // 0x5245d4: b               #0x5245dc
    // 0x5245d8: r0 = Null
    //     0x5245d8: mov             x0, NULL
    // 0x5245dc: cmp             w0, NULL
    // 0x5245e0: b.ne            #0x5245ec
    // 0x5245e4: r0 = Null
    //     0x5245e4: mov             x0, NULL
    // 0x5245e8: b               #0x524620
    // 0x5245ec: LoadField: d0 = r0->field_1f
    //     0x5245ec: ldur            d0, [x0, #0x1f]
    // 0x5245f0: LoadField: d1 = r0->field_f
    //     0x5245f0: ldur            d1, [x0, #0xf]
    // 0x5245f4: fsub            d2, d0, d1
    // 0x5245f8: r0 = inline_Allocate_Double()
    //     0x5245f8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5245fc: add             x0, x0, #0x10
    //     0x524600: cmp             x1, x0
    //     0x524604: b.ls            #0x524660
    //     0x524608: str             x0, [THR, #0x60]  ; THR::top
    //     0x52460c: sub             x0, x0, #0xf
    //     0x524610: mov             x1, #0xd108
    //     0x524614: movk            x1, #3, lsl #16
    //     0x524618: stur            x1, [x0, #-1]
    // 0x52461c: StoreField: r0->field_7 = d2
    //     0x52461c: stur            d2, [x0, #7]
    // 0x524620: cmp             w0, NULL
    // 0x524624: b.ne            #0x52463c
    // 0x524628: ldur            x16, [fp, #-8]
    // 0x52462c: SaveReg r16
    //     0x52462c: str             x16, [SP, #-8]!
    // 0x524630: r0 = preferredLineHeight()
    //     0x524630: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x524634: add             SP, SP, #8
    // 0x524638: b               #0x524644
    // 0x52463c: LoadField: d1 = r0->field_7
    //     0x52463c: ldur            d1, [x0, #7]
    // 0x524640: mov             v0.16b, v1.16b
    // 0x524644: LeaveFrame
    //     0x524644: mov             SP, fp
    //     0x524648: ldp             fp, lr, [SP], #0x10
    // 0x52464c: ret
    //     0x52464c: ret             
    // 0x524650: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x524650: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x524654: b               #0x524494
    // 0x524658: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x524658: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x52465c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x52465c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x524660: SaveReg d2
    //     0x524660: str             q2, [SP, #-0x10]!
    // 0x524664: r0 = AllocateDouble()
    //     0x524664: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x524668: RestoreReg d2
    //     0x524668: ldr             q2, [SP], #0x10
    // 0x52466c: b               #0x52461c
  }
  _ _getStartGlyphHeight(/* No info */) {
    // ** addr: 0x52566c, size: 0x1f4
    // 0x52566c: EnterFrame
    //     0x52566c: stp             fp, lr, [SP, #-0x10]!
    //     0x525670: mov             fp, SP
    // 0x525674: AllocStack(0x28)
    //     0x525674: sub             SP, SP, #0x28
    // 0x525678: CheckStackOverflow
    //     0x525678: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52567c: cmp             SP, x16
    //     0x525680: b.ls            #0x525840
    // 0x525684: ldr             x0, [fp, #0x10]
    // 0x525688: LoadField: r1 = r0->field_7
    //     0x525688: ldur            w1, [x0, #7]
    // 0x52568c: DecompressPointer r1
    //     0x52568c: add             x1, x1, HEAP, lsl #32
    // 0x525690: stur            x1, [fp, #-0x10]
    // 0x525694: LoadField: r2 = r1->field_eb
    //     0x525694: ldur            w2, [x1, #0xeb]
    // 0x525698: DecompressPointer r2
    //     0x525698: add             x2, x2, HEAP, lsl #32
    // 0x52569c: stur            x2, [fp, #-8]
    // 0x5256a0: LoadField: r3 = r2->field_f
    //     0x5256a0: ldur            w3, [x2, #0xf]
    // 0x5256a4: DecompressPointer r3
    //     0x5256a4: add             x3, x3, HEAP, lsl #32
    // 0x5256a8: cmp             w3, NULL
    // 0x5256ac: b.eq            #0x525848
    // 0x5256b0: SaveReg r3
    //     0x5256b0: str             x3, [SP, #-8]!
    // 0x5256b4: r0 = toPlainText()
    //     0x5256b4: bl              #0x521774  ; [package:flutter/src/painting/inline_span.dart] InlineSpan::toPlainText
    // 0x5256b8: add             SP, SP, #8
    // 0x5256bc: ldr             x1, [fp, #0x10]
    // 0x5256c0: LoadField: r2 = r1->field_f
    //     0x5256c0: ldur            w2, [x1, #0xf]
    // 0x5256c4: DecompressPointer r2
    //     0x5256c4: add             x2, x2, HEAP, lsl #32
    // 0x5256c8: LoadField: r3 = r2->field_b
    //     0x5256c8: ldur            w3, [x2, #0xb]
    // 0x5256cc: DecompressPointer r3
    //     0x5256cc: add             x3, x3, HEAP, lsl #32
    // 0x5256d0: cmp             w3, NULL
    // 0x5256d4: b.eq            #0x52584c
    // 0x5256d8: LoadField: r2 = r3->field_13
    //     0x5256d8: ldur            w2, [x3, #0x13]
    // 0x5256dc: DecompressPointer r2
    //     0x5256dc: add             x2, x2, HEAP, lsl #32
    // 0x5256e0: LoadField: r3 = r2->field_27
    //     0x5256e0: ldur            w3, [x2, #0x27]
    // 0x5256e4: DecompressPointer r3
    //     0x5256e4: add             x3, x3, HEAP, lsl #32
    // 0x5256e8: LoadField: r2 = r3->field_7
    //     0x5256e8: ldur            w2, [x3, #7]
    // 0x5256ec: DecompressPointer r2
    //     0x5256ec: add             x2, x2, HEAP, lsl #32
    // 0x5256f0: stur            x2, [fp, #-0x18]
    // 0x5256f4: r3 = LoadClassIdInstr(r0)
    //     0x5256f4: ldur            x3, [x0, #-1]
    //     0x5256f8: ubfx            x3, x3, #0xc, #0x14
    // 0x5256fc: stp             x2, x0, [SP, #-0x10]!
    // 0x525700: mov             x0, x3
    // 0x525704: mov             lr, x0
    // 0x525708: ldr             lr, [x21, lr, lsl #3]
    // 0x52570c: blr             lr
    // 0x525710: add             SP, SP, #0x10
    // 0x525714: tbnz            w0, #4, #0x5257c8
    // 0x525718: ldr             x0, [fp, #0x10]
    // 0x52571c: LoadField: r1 = r0->field_17
    //     0x52571c: ldur            w1, [x0, #0x17]
    // 0x525720: DecompressPointer r1
    //     0x525720: add             x1, x1, HEAP, lsl #32
    // 0x525724: LoadField: r2 = r1->field_b
    //     0x525724: ldur            w2, [x1, #0xb]
    // 0x525728: DecompressPointer r2
    //     0x525728: add             x2, x2, HEAP, lsl #32
    // 0x52572c: LoadField: r1 = r2->field_7
    //     0x52572c: ldur            x1, [x2, #7]
    // 0x525730: tbnz            x1, #0x3f, #0x5257c8
    // 0x525734: LoadField: r3 = r2->field_f
    //     0x525734: ldur            x3, [x2, #0xf]
    // 0x525738: tbnz            x3, #0x3f, #0x5257c8
    // 0x52573c: cmp             x1, x3
    // 0x525740: b.eq            #0x5257c8
    // 0x525744: ldur            x16, [fp, #-0x18]
    // 0x525748: stp             x16, x2, [SP, #-0x10]!
    // 0x52574c: r0 = textInside()
    //     0x52574c: bl              #0x525528  ; [dart:ui] TextRange::textInside
    // 0x525750: add             SP, SP, #0x10
    // 0x525754: SaveReg r0
    //     0x525754: str             x0, [SP, #-8]!
    // 0x525758: r0 = StringCharacters.characters()
    //     0x525758: bl              #0x5254a4  ; [package:characters/src/extensions.dart] ::StringCharacters.characters
    // 0x52575c: add             SP, SP, #8
    // 0x525760: SaveReg r0
    //     0x525760: str             x0, [SP, #-8]!
    // 0x525764: r0 = first()
    //     0x525764: bl              #0x6b8138  ; [package:characters/src/characters_impl.dart] StringCharacters::first
    // 0x525768: add             SP, SP, #8
    // 0x52576c: LoadField: r1 = r0->field_7
    //     0x52576c: ldur            w1, [x0, #7]
    // 0x525770: DecompressPointer r1
    //     0x525770: add             x1, x1, HEAP, lsl #32
    // 0x525774: ldr             x0, [fp, #0x10]
    // 0x525778: LoadField: r2 = r0->field_17
    //     0x525778: ldur            w2, [x0, #0x17]
    // 0x52577c: DecompressPointer r2
    //     0x52577c: add             x2, x2, HEAP, lsl #32
    // 0x525780: LoadField: r0 = r2->field_b
    //     0x525780: ldur            w0, [x2, #0xb]
    // 0x525784: DecompressPointer r0
    //     0x525784: add             x0, x0, HEAP, lsl #32
    // 0x525788: LoadField: r2 = r0->field_7
    //     0x525788: ldur            x2, [x0, #7]
    // 0x52578c: stur            x2, [fp, #-0x28]
    // 0x525790: r0 = LoadInt32Instr(r1)
    //     0x525790: sbfx            x0, x1, #1, #0x1f
    // 0x525794: add             x1, x2, x0
    // 0x525798: stur            x1, [fp, #-0x20]
    // 0x52579c: r0 = TextRange()
    //     0x52579c: bl              #0x51026c  ; AllocateTextRangeStub -> TextRange (size=0x18)
    // 0x5257a0: mov             x1, x0
    // 0x5257a4: ldur            x0, [fp, #-0x28]
    // 0x5257a8: StoreField: r1->field_7 = r0
    //     0x5257a8: stur            x0, [x1, #7]
    // 0x5257ac: ldur            x0, [fp, #-0x20]
    // 0x5257b0: StoreField: r1->field_f = r0
    //     0x5257b0: stur            x0, [x1, #0xf]
    // 0x5257b4: ldur            x16, [fp, #-0x10]
    // 0x5257b8: stp             x1, x16, [SP, #-0x10]!
    // 0x5257bc: r0 = getRectForComposingRange()
    //     0x5257bc: bl              #0x524670  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::getRectForComposingRange
    // 0x5257c0: add             SP, SP, #0x10
    // 0x5257c4: b               #0x5257cc
    // 0x5257c8: r0 = Null
    //     0x5257c8: mov             x0, NULL
    // 0x5257cc: cmp             w0, NULL
    // 0x5257d0: b.ne            #0x5257dc
    // 0x5257d4: r0 = Null
    //     0x5257d4: mov             x0, NULL
    // 0x5257d8: b               #0x525810
    // 0x5257dc: LoadField: d0 = r0->field_1f
    //     0x5257dc: ldur            d0, [x0, #0x1f]
    // 0x5257e0: LoadField: d1 = r0->field_f
    //     0x5257e0: ldur            d1, [x0, #0xf]
    // 0x5257e4: fsub            d2, d0, d1
    // 0x5257e8: r0 = inline_Allocate_Double()
    //     0x5257e8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x5257ec: add             x0, x0, #0x10
    //     0x5257f0: cmp             x1, x0
    //     0x5257f4: b.ls            #0x525850
    //     0x5257f8: str             x0, [THR, #0x60]  ; THR::top
    //     0x5257fc: sub             x0, x0, #0xf
    //     0x525800: mov             x1, #0xd108
    //     0x525804: movk            x1, #3, lsl #16
    //     0x525808: stur            x1, [x0, #-1]
    // 0x52580c: StoreField: r0->field_7 = d2
    //     0x52580c: stur            d2, [x0, #7]
    // 0x525810: cmp             w0, NULL
    // 0x525814: b.ne            #0x52582c
    // 0x525818: ldur            x16, [fp, #-8]
    // 0x52581c: SaveReg r16
    //     0x52581c: str             x16, [SP, #-8]!
    // 0x525820: r0 = preferredLineHeight()
    //     0x525820: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x525824: add             SP, SP, #8
    // 0x525828: b               #0x525834
    // 0x52582c: LoadField: d1 = r0->field_7
    //     0x52582c: ldur            d1, [x0, #7]
    // 0x525830: mov             v0.16b, v1.16b
    // 0x525834: LeaveFrame
    //     0x525834: mov             SP, fp
    //     0x525838: ldp             fp, lr, [SP], #0x10
    // 0x52583c: ret
    //     0x52583c: ret             
    // 0x525840: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x525840: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x525844: b               #0x525684
    // 0x525848: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x525848: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x52584c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x52584c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x525850: SaveReg d2
    //     0x525850: str             q2, [SP, #-0x10]!
    // 0x525854: r0 = AllocateDouble()
    //     0x525854: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x525858: RestoreReg d2
    //     0x525858: ldr             q2, [SP], #0x10
    // 0x52585c: b               #0x52580c
  }
  _ _chooseType(/* No info */) {
    // ** addr: 0x5258e0, size: 0x50
    // 0x5258e0: ldr             x1, [SP, #0x18]
    // 0x5258e4: LoadField: r2 = r1->field_17
    //     0x5258e4: ldur            w2, [x1, #0x17]
    // 0x5258e8: DecompressPointer r2
    //     0x5258e8: add             x2, x2, HEAP, lsl #32
    // 0x5258ec: LoadField: r1 = r2->field_b
    //     0x5258ec: ldur            w1, [x2, #0xb]
    // 0x5258f0: DecompressPointer r1
    //     0x5258f0: add             x1, x1, HEAP, lsl #32
    // 0x5258f4: LoadField: r2 = r1->field_7
    //     0x5258f4: ldur            x2, [x1, #7]
    // 0x5258f8: LoadField: r3 = r1->field_f
    //     0x5258f8: ldur            x3, [x1, #0xf]
    // 0x5258fc: cmp             x2, x3
    // 0x525900: b.ne            #0x525910
    // 0x525904: r0 = Instance_TextSelectionHandleType
    //     0x525904: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f768] Obj!TextSelectionHandleType@b64811
    //     0x525908: ldr             x0, [x0, #0x768]
    // 0x52590c: ret
    //     0x52590c: ret             
    // 0x525910: ldr             x1, [SP, #0x10]
    // 0x525914: LoadField: r2 = r1->field_7
    //     0x525914: ldur            x2, [x1, #7]
    // 0x525918: cmp             x2, #0
    // 0x52591c: b.gt            #0x525928
    // 0x525920: ldr             x0, [SP]
    // 0x525924: ret
    //     0x525924: ret             
    // 0x525928: ldr             x0, [SP, #8]
    // 0x52592c: ret
    //     0x52592c: ret             
  }
  set _ handlesVisible=(/* No info */) {
    // ** addr: 0x7a2b24, size: 0x64
    // 0x7a2b24: EnterFrame
    //     0x7a2b24: stp             fp, lr, [SP, #-0x10]!
    //     0x7a2b28: mov             fp, SP
    // 0x7a2b2c: CheckStackOverflow
    //     0x7a2b2c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a2b30: cmp             SP, x16
    //     0x7a2b34: b.ls            #0x7a2b80
    // 0x7a2b38: ldr             x0, [fp, #0x18]
    // 0x7a2b3c: LoadField: r1 = r0->field_27
    //     0x7a2b3c: ldur            w1, [x0, #0x27]
    // 0x7a2b40: DecompressPointer r1
    //     0x7a2b40: add             x1, x1, HEAP, lsl #32
    // 0x7a2b44: ldr             x2, [fp, #0x10]
    // 0x7a2b48: cmp             w1, w2
    // 0x7a2b4c: b.ne            #0x7a2b60
    // 0x7a2b50: r0 = Null
    //     0x7a2b50: mov             x0, NULL
    // 0x7a2b54: LeaveFrame
    //     0x7a2b54: mov             SP, fp
    //     0x7a2b58: ldp             fp, lr, [SP], #0x10
    // 0x7a2b5c: ret
    //     0x7a2b5c: ret             
    // 0x7a2b60: StoreField: r0->field_27 = r2
    //     0x7a2b60: stur            w2, [x0, #0x27]
    // 0x7a2b64: SaveReg r0
    //     0x7a2b64: str             x0, [SP, #-8]!
    // 0x7a2b68: r0 = _updateTextSelectionOverlayVisibilities()
    //     0x7a2b68: bl              #0x7a7294  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities
    // 0x7a2b6c: add             SP, SP, #8
    // 0x7a2b70: r0 = Null
    //     0x7a2b70: mov             x0, NULL
    // 0x7a2b74: LeaveFrame
    //     0x7a2b74: mov             SP, fp
    //     0x7a2b78: ldp             fp, lr, [SP], #0x10
    // 0x7a2b7c: ret
    //     0x7a2b7c: ret             
    // 0x7a2b80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a2b80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a2b84: b               #0x7a2b38
  }
  _ _updateTextSelectionOverlayVisibilities(/* No info */) {
    // ** addr: 0x7a7294, size: 0x104
    // 0x7a7294: EnterFrame
    //     0x7a7294: stp             fp, lr, [SP, #-0x10]!
    //     0x7a7298: mov             fp, SP
    // 0x7a729c: CheckStackOverflow
    //     0x7a729c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a72a0: cmp             SP, x16
    //     0x7a72a4: b.ls            #0x7a7390
    // 0x7a72a8: ldr             x0, [fp, #0x10]
    // 0x7a72ac: LoadField: r1 = r0->field_1b
    //     0x7a72ac: ldur            w1, [x0, #0x1b]
    // 0x7a72b0: DecompressPointer r1
    //     0x7a72b0: add             x1, x1, HEAP, lsl #32
    // 0x7a72b4: LoadField: r2 = r0->field_27
    //     0x7a72b4: ldur            w2, [x0, #0x27]
    // 0x7a72b8: DecompressPointer r2
    //     0x7a72b8: add             x2, x2, HEAP, lsl #32
    // 0x7a72bc: tbnz            w2, #4, #0x7a72dc
    // 0x7a72c0: LoadField: r2 = r0->field_7
    //     0x7a72c0: ldur            w2, [x0, #7]
    // 0x7a72c4: DecompressPointer r2
    //     0x7a72c4: add             x2, x2, HEAP, lsl #32
    // 0x7a72c8: LoadField: r3 = r2->field_df
    //     0x7a72c8: ldur            w3, [x2, #0xdf]
    // 0x7a72cc: DecompressPointer r3
    //     0x7a72cc: add             x3, x3, HEAP, lsl #32
    // 0x7a72d0: LoadField: r2 = r3->field_27
    //     0x7a72d0: ldur            w2, [x3, #0x27]
    // 0x7a72d4: DecompressPointer r2
    //     0x7a72d4: add             x2, x2, HEAP, lsl #32
    // 0x7a72d8: b               #0x7a72e0
    // 0x7a72dc: r2 = false
    //     0x7a72dc: add             x2, NULL, #0x30  ; false
    // 0x7a72e0: stp             x2, x1, [SP, #-0x10]!
    // 0x7a72e4: r0 = value=()
    //     0x7a72e4: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x7a72e8: add             SP, SP, #0x10
    // 0x7a72ec: ldr             x0, [fp, #0x10]
    // 0x7a72f0: LoadField: r1 = r0->field_1f
    //     0x7a72f0: ldur            w1, [x0, #0x1f]
    // 0x7a72f4: DecompressPointer r1
    //     0x7a72f4: add             x1, x1, HEAP, lsl #32
    // 0x7a72f8: LoadField: r2 = r0->field_27
    //     0x7a72f8: ldur            w2, [x0, #0x27]
    // 0x7a72fc: DecompressPointer r2
    //     0x7a72fc: add             x2, x2, HEAP, lsl #32
    // 0x7a7300: tbnz            w2, #4, #0x7a7320
    // 0x7a7304: LoadField: r2 = r0->field_7
    //     0x7a7304: ldur            w2, [x0, #7]
    // 0x7a7308: DecompressPointer r2
    //     0x7a7308: add             x2, x2, HEAP, lsl #32
    // 0x7a730c: LoadField: r3 = r2->field_e3
    //     0x7a730c: ldur            w3, [x2, #0xe3]
    // 0x7a7310: DecompressPointer r3
    //     0x7a7310: add             x3, x3, HEAP, lsl #32
    // 0x7a7314: LoadField: r2 = r3->field_27
    //     0x7a7314: ldur            w2, [x3, #0x27]
    // 0x7a7318: DecompressPointer r2
    //     0x7a7318: add             x2, x2, HEAP, lsl #32
    // 0x7a731c: b               #0x7a7324
    // 0x7a7320: r2 = false
    //     0x7a7320: add             x2, NULL, #0x30  ; false
    // 0x7a7324: stp             x2, x1, [SP, #-0x10]!
    // 0x7a7328: r0 = value=()
    //     0x7a7328: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x7a732c: add             SP, SP, #0x10
    // 0x7a7330: ldr             x0, [fp, #0x10]
    // 0x7a7334: LoadField: r1 = r0->field_23
    //     0x7a7334: ldur            w1, [x0, #0x23]
    // 0x7a7338: DecompressPointer r1
    //     0x7a7338: add             x1, x1, HEAP, lsl #32
    // 0x7a733c: LoadField: r2 = r0->field_7
    //     0x7a733c: ldur            w2, [x0, #7]
    // 0x7a7340: DecompressPointer r2
    //     0x7a7340: add             x2, x2, HEAP, lsl #32
    // 0x7a7344: LoadField: r0 = r2->field_df
    //     0x7a7344: ldur            w0, [x2, #0xdf]
    // 0x7a7348: DecompressPointer r0
    //     0x7a7348: add             x0, x0, HEAP, lsl #32
    // 0x7a734c: LoadField: r3 = r0->field_27
    //     0x7a734c: ldur            w3, [x0, #0x27]
    // 0x7a7350: DecompressPointer r3
    //     0x7a7350: add             x3, x3, HEAP, lsl #32
    // 0x7a7354: tbnz            w3, #4, #0x7a7360
    // 0x7a7358: r0 = true
    //     0x7a7358: add             x0, NULL, #0x20  ; true
    // 0x7a735c: b               #0x7a7374
    // 0x7a7360: LoadField: r0 = r2->field_e3
    //     0x7a7360: ldur            w0, [x2, #0xe3]
    // 0x7a7364: DecompressPointer r0
    //     0x7a7364: add             x0, x0, HEAP, lsl #32
    // 0x7a7368: LoadField: r2 = r0->field_27
    //     0x7a7368: ldur            w2, [x0, #0x27]
    // 0x7a736c: DecompressPointer r2
    //     0x7a736c: add             x2, x2, HEAP, lsl #32
    // 0x7a7370: mov             x0, x2
    // 0x7a7374: stp             x0, x1, [SP, #-0x10]!
    // 0x7a7378: r0 = value=()
    //     0x7a7378: bl              #0x500e7c  ; [package:flutter/src/foundation/change_notifier.dart] ValueNotifier::value=
    // 0x7a737c: add             SP, SP, #0x10
    // 0x7a7380: r0 = Null
    //     0x7a7380: mov             x0, NULL
    // 0x7a7384: LeaveFrame
    //     0x7a7384: mov             SP, fp
    //     0x7a7388: ldp             fp, lr, [SP], #0x10
    // 0x7a738c: ret
    //     0x7a738c: ret             
    // 0x7a7390: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a7390: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a7394: b               #0x7a72a8
  }
  [closure] void _updateTextSelectionOverlayVisibilities(dynamic) {
    // ** addr: 0x7a7398, size: 0x48
    // 0x7a7398: EnterFrame
    //     0x7a7398: stp             fp, lr, [SP, #-0x10]!
    //     0x7a739c: mov             fp, SP
    // 0x7a73a0: ldr             x0, [fp, #0x10]
    // 0x7a73a4: LoadField: r1 = r0->field_17
    //     0x7a73a4: ldur            w1, [x0, #0x17]
    // 0x7a73a8: DecompressPointer r1
    //     0x7a73a8: add             x1, x1, HEAP, lsl #32
    // 0x7a73ac: CheckStackOverflow
    //     0x7a73ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a73b0: cmp             SP, x16
    //     0x7a73b4: b.ls            #0x7a73d8
    // 0x7a73b8: LoadField: r0 = r1->field_f
    //     0x7a73b8: ldur            w0, [x1, #0xf]
    // 0x7a73bc: DecompressPointer r0
    //     0x7a73bc: add             x0, x0, HEAP, lsl #32
    // 0x7a73c0: SaveReg r0
    //     0x7a73c0: str             x0, [SP, #-8]!
    // 0x7a73c4: r0 = _updateTextSelectionOverlayVisibilities()
    //     0x7a73c4: bl              #0x7a7294  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities
    // 0x7a73c8: add             SP, SP, #8
    // 0x7a73cc: LeaveFrame
    //     0x7a73cc: mov             SP, fp
    //     0x7a73d0: ldp             fp, lr, [SP], #0x10
    // 0x7a73d4: ret
    //     0x7a73d4: ret             
    // 0x7a73d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a73d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a73dc: b               #0x7a73b8
  }
  _ update(/* No info */) {
    // ** addr: 0x7a73e0, size: 0x8c
    // 0x7a73e0: EnterFrame
    //     0x7a73e0: stp             fp, lr, [SP, #-0x10]!
    //     0x7a73e4: mov             fp, SP
    // 0x7a73e8: CheckStackOverflow
    //     0x7a73e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a73ec: cmp             SP, x16
    //     0x7a73f0: b.ls            #0x7a7464
    // 0x7a73f4: ldr             x0, [fp, #0x18]
    // 0x7a73f8: LoadField: r1 = r0->field_17
    //     0x7a73f8: ldur            w1, [x0, #0x17]
    // 0x7a73fc: DecompressPointer r1
    //     0x7a73fc: add             x1, x1, HEAP, lsl #32
    // 0x7a7400: ldr             x16, [fp, #0x10]
    // 0x7a7404: stp             x16, x1, [SP, #-0x10]!
    // 0x7a7408: r0 = ==()
    //     0x7a7408: bl              #0xca1270  ; [package:flutter/src/services/text_input.dart] TextEditingValue::==
    // 0x7a740c: add             SP, SP, #0x10
    // 0x7a7410: tbnz            w0, #4, #0x7a7424
    // 0x7a7414: r0 = Null
    //     0x7a7414: mov             x0, NULL
    // 0x7a7418: LeaveFrame
    //     0x7a7418: mov             SP, fp
    //     0x7a741c: ldp             fp, lr, [SP], #0x10
    // 0x7a7420: ret
    //     0x7a7420: ret             
    // 0x7a7424: ldr             x1, [fp, #0x18]
    // 0x7a7428: ldr             x0, [fp, #0x10]
    // 0x7a742c: StoreField: r1->field_17 = r0
    //     0x7a742c: stur            w0, [x1, #0x17]
    //     0x7a7430: ldurb           w16, [x1, #-1]
    //     0x7a7434: ldurb           w17, [x0, #-1]
    //     0x7a7438: and             x16, x17, x16, lsr #2
    //     0x7a743c: tst             x16, HEAP, lsr #32
    //     0x7a7440: b.eq            #0x7a7448
    //     0x7a7444: bl              #0xd6826c
    // 0x7a7448: SaveReg r1
    //     0x7a7448: str             x1, [SP, #-8]!
    // 0x7a744c: r0 = _updateSelectionOverlay()
    //     0x7a744c: bl              #0x51efe0  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateSelectionOverlay
    // 0x7a7450: add             SP, SP, #8
    // 0x7a7454: r0 = Null
    //     0x7a7454: mov             x0, NULL
    // 0x7a7458: LeaveFrame
    //     0x7a7458: mov             SP, fp
    //     0x7a745c: ldp             fp, lr, [SP], #0x10
    // 0x7a7460: ret
    //     0x7a7460: ret             
    // 0x7a7464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a7464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a7468: b               #0x7a73f4
  }
  _ showHandles(/* No info */) {
    // ** addr: 0x7a8a3c, size: 0x6c
    // 0x7a8a3c: EnterFrame
    //     0x7a8a3c: stp             fp, lr, [SP, #-0x10]!
    //     0x7a8a40: mov             fp, SP
    // 0x7a8a44: CheckStackOverflow
    //     0x7a8a44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a8a48: cmp             SP, x16
    //     0x7a8a4c: b.ls            #0x7a8a94
    // 0x7a8a50: ldr             x16, [fp, #0x10]
    // 0x7a8a54: SaveReg r16
    //     0x7a8a54: str             x16, [SP, #-8]!
    // 0x7a8a58: r0 = _updateSelectionOverlay()
    //     0x7a8a58: bl              #0x51efe0  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateSelectionOverlay
    // 0x7a8a5c: add             SP, SP, #8
    // 0x7a8a60: ldr             x0, [fp, #0x10]
    // 0x7a8a64: LoadField: r1 = r0->field_13
    //     0x7a8a64: ldur            w1, [x0, #0x13]
    // 0x7a8a68: DecompressPointer r1
    //     0x7a8a68: add             x1, x1, HEAP, lsl #32
    // 0x7a8a6c: r16 = Sentinel
    //     0x7a8a6c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a8a70: cmp             w1, w16
    // 0x7a8a74: b.eq            #0x7a8a9c
    // 0x7a8a78: SaveReg r1
    //     0x7a8a78: str             x1, [SP, #-8]!
    // 0x7a8a7c: r0 = showHandles()
    //     0x7a8a7c: bl              #0x7a8aa8  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::showHandles
    // 0x7a8a80: add             SP, SP, #8
    // 0x7a8a84: r0 = Null
    //     0x7a8a84: mov             x0, NULL
    // 0x7a8a88: LeaveFrame
    //     0x7a8a88: mov             SP, fp
    //     0x7a8a8c: ldp             fp, lr, [SP], #0x10
    // 0x7a8a90: ret
    //     0x7a8a90: ret             
    // 0x7a8a94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a8a94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a8a98: b               #0x7a8a50
    // 0x7a8a9c: r9 = _selectionOverlay
    //     0x7a8a9c: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0x7a8aa0: ldr             x9, [x9, #0x3e8]
    // 0x7a8aa4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7a8aa4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ ExtendedTextSelectionOverlay(/* No info */) {
    // ** addr: 0x7a9110, size: 0x410
    // 0x7a9110: EnterFrame
    //     0x7a9110: stp             fp, lr, [SP, #-0x10]!
    //     0x7a9114: mov             fp, SP
    // 0x7a9118: AllocStack(0x48)
    //     0x7a9118: sub             SP, SP, #0x48
    // 0x7a911c: r0 = Sentinel
    //     0x7a911c: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a9120: CheckStackOverflow
    //     0x7a9120: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a9124: cmp             SP, x16
    //     0x7a9128: b.ls            #0x7a9518
    // 0x7a912c: ldr             x2, [fp, #0x68]
    // 0x7a9130: StoreField: r2->field_13 = r0
    //     0x7a9130: stur            w0, [x2, #0x13]
    // 0x7a9134: StoreField: r2->field_2b = r0
    //     0x7a9134: stur            w0, [x2, #0x2b]
    // 0x7a9138: StoreField: r2->field_2f = r0
    //     0x7a9138: stur            w0, [x2, #0x2f]
    // 0x7a913c: r1 = <bool>
    //     0x7a913c: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x7a9140: r0 = ValueNotifier()
    //     0x7a9140: bl              #0x515204  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x7a9144: mov             x1, x0
    // 0x7a9148: r0 = false
    //     0x7a9148: add             x0, NULL, #0x30  ; false
    // 0x7a914c: stur            x1, [fp, #-8]
    // 0x7a9150: StoreField: r1->field_27 = r0
    //     0x7a9150: stur            w0, [x1, #0x27]
    // 0x7a9154: r2 = 0
    //     0x7a9154: mov             x2, #0
    // 0x7a9158: StoreField: r1->field_7 = r2
    //     0x7a9158: stur            x2, [x1, #7]
    // 0x7a915c: StoreField: r1->field_13 = r2
    //     0x7a915c: stur            x2, [x1, #0x13]
    // 0x7a9160: StoreField: r1->field_1b = r2
    //     0x7a9160: stur            x2, [x1, #0x1b]
    // 0x7a9164: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x7a9164: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x7a9168: ldr             x0, [x0, #0x1580]
    //     0x7a916c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x7a9170: cmp             w0, w16
    //     0x7a9174: b.ne            #0x7a9180
    //     0x7a9178: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x7a917c: bl              #0xd67cdc
    // 0x7a9180: mov             x3, x0
    // 0x7a9184: ldur            x2, [fp, #-8]
    // 0x7a9188: stur            x3, [fp, #-0x10]
    // 0x7a918c: StoreField: r2->field_f = r3
    //     0x7a918c: stur            w3, [x2, #0xf]
    // 0x7a9190: mov             x0, x2
    // 0x7a9194: ldr             x4, [fp, #0x68]
    // 0x7a9198: StoreField: r4->field_1b = r0
    //     0x7a9198: stur            w0, [x4, #0x1b]
    //     0x7a919c: ldurb           w16, [x4, #-1]
    //     0x7a91a0: ldurb           w17, [x0, #-1]
    //     0x7a91a4: and             x16, x17, x16, lsr #2
    //     0x7a91a8: tst             x16, HEAP, lsr #32
    //     0x7a91ac: b.eq            #0x7a91b4
    //     0x7a91b0: bl              #0xd682cc
    // 0x7a91b4: r1 = <bool>
    //     0x7a91b4: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x7a91b8: r0 = ValueNotifier()
    //     0x7a91b8: bl              #0x515204  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x7a91bc: mov             x3, x0
    // 0x7a91c0: r2 = false
    //     0x7a91c0: add             x2, NULL, #0x30  ; false
    // 0x7a91c4: stur            x3, [fp, #-0x18]
    // 0x7a91c8: StoreField: r3->field_27 = r2
    //     0x7a91c8: stur            w2, [x3, #0x27]
    // 0x7a91cc: r4 = 0
    //     0x7a91cc: mov             x4, #0
    // 0x7a91d0: StoreField: r3->field_7 = r4
    //     0x7a91d0: stur            x4, [x3, #7]
    // 0x7a91d4: StoreField: r3->field_13 = r4
    //     0x7a91d4: stur            x4, [x3, #0x13]
    // 0x7a91d8: StoreField: r3->field_1b = r4
    //     0x7a91d8: stur            x4, [x3, #0x1b]
    // 0x7a91dc: ldur            x5, [fp, #-0x10]
    // 0x7a91e0: StoreField: r3->field_f = r5
    //     0x7a91e0: stur            w5, [x3, #0xf]
    // 0x7a91e4: mov             x0, x3
    // 0x7a91e8: ldr             x6, [fp, #0x68]
    // 0x7a91ec: StoreField: r6->field_1f = r0
    //     0x7a91ec: stur            w0, [x6, #0x1f]
    //     0x7a91f0: ldurb           w16, [x6, #-1]
    //     0x7a91f4: ldurb           w17, [x0, #-1]
    //     0x7a91f8: and             x16, x17, x16, lsr #2
    //     0x7a91fc: tst             x16, HEAP, lsr #32
    //     0x7a9200: b.eq            #0x7a9208
    //     0x7a9204: bl              #0xd6830c
    // 0x7a9208: r1 = <bool>
    //     0x7a9208: ldr             x1, [PP, #0x3d60]  ; [pp+0x3d60] TypeArguments: <bool>
    // 0x7a920c: r0 = ValueNotifier()
    //     0x7a920c: bl              #0x515204  ; AllocateValueNotifierStub -> ValueNotifier<X0> (size=0x2c)
    // 0x7a9210: mov             x2, x0
    // 0x7a9214: r1 = false
    //     0x7a9214: add             x1, NULL, #0x30  ; false
    // 0x7a9218: stur            x2, [fp, #-0x20]
    // 0x7a921c: StoreField: r2->field_27 = r1
    //     0x7a921c: stur            w1, [x2, #0x27]
    // 0x7a9220: r0 = 0
    //     0x7a9220: mov             x0, #0
    // 0x7a9224: StoreField: r2->field_7 = r0
    //     0x7a9224: stur            x0, [x2, #7]
    // 0x7a9228: StoreField: r2->field_13 = r0
    //     0x7a9228: stur            x0, [x2, #0x13]
    // 0x7a922c: StoreField: r2->field_1b = r0
    //     0x7a922c: stur            x0, [x2, #0x1b]
    // 0x7a9230: ldur            x0, [fp, #-0x10]
    // 0x7a9234: StoreField: r2->field_f = r0
    //     0x7a9234: stur            w0, [x2, #0xf]
    // 0x7a9238: mov             x0, x2
    // 0x7a923c: ldr             x3, [fp, #0x68]
    // 0x7a9240: StoreField: r3->field_23 = r0
    //     0x7a9240: stur            w0, [x3, #0x23]
    //     0x7a9244: ldurb           w16, [x3, #-1]
    //     0x7a9248: ldurb           w17, [x0, #-1]
    //     0x7a924c: and             x16, x17, x16, lsr #2
    //     0x7a9250: tst             x16, HEAP, lsr #32
    //     0x7a9254: b.eq            #0x7a925c
    //     0x7a9258: bl              #0xd682ac
    // 0x7a925c: ldr             x0, [fp, #0x38]
    // 0x7a9260: StoreField: r3->field_7 = r0
    //     0x7a9260: stur            w0, [x3, #7]
    //     0x7a9264: ldurb           w16, [x3, #-1]
    //     0x7a9268: ldurb           w17, [x0, #-1]
    //     0x7a926c: and             x16, x17, x16, lsr #2
    //     0x7a9270: tst             x16, HEAP, lsr #32
    //     0x7a9274: b.eq            #0x7a927c
    //     0x7a9278: bl              #0xd682ac
    // 0x7a927c: ldr             x0, [fp, #0x30]
    // 0x7a9280: StoreField: r3->field_b = r0
    //     0x7a9280: stur            w0, [x3, #0xb]
    //     0x7a9284: ldurb           w16, [x3, #-1]
    //     0x7a9288: ldurb           w17, [x0, #-1]
    //     0x7a928c: and             x16, x17, x16, lsr #2
    //     0x7a9290: tst             x16, HEAP, lsr #32
    //     0x7a9294: b.eq            #0x7a929c
    //     0x7a9298: bl              #0xd682ac
    // 0x7a929c: ldr             x0, [fp, #0x28]
    // 0x7a92a0: StoreField: r3->field_f = r0
    //     0x7a92a0: stur            w0, [x3, #0xf]
    //     0x7a92a4: ldurb           w16, [x3, #-1]
    //     0x7a92a8: ldurb           w17, [x0, #-1]
    //     0x7a92ac: and             x16, x17, x16, lsr #2
    //     0x7a92b0: tst             x16, HEAP, lsr #32
    //     0x7a92b4: b.eq            #0x7a92bc
    //     0x7a92b8: bl              #0xd682ac
    // 0x7a92bc: StoreField: r3->field_27 = r1
    //     0x7a92bc: stur            w1, [x3, #0x27]
    // 0x7a92c0: ldr             x0, [fp, #0x10]
    // 0x7a92c4: StoreField: r3->field_17 = r0
    //     0x7a92c4: stur            w0, [x3, #0x17]
    //     0x7a92c8: ldurb           w16, [x3, #-1]
    //     0x7a92cc: ldurb           w17, [x0, #-1]
    //     0x7a92d0: and             x16, x17, x16, lsr #2
    //     0x7a92d4: tst             x16, HEAP, lsr #32
    //     0x7a92d8: b.eq            #0x7a92e0
    //     0x7a92dc: bl              #0xd682ac
    // 0x7a92e0: ldr             x0, [fp, #0x38]
    // 0x7a92e4: LoadField: r1 = r0->field_df
    //     0x7a92e4: ldur            w1, [x0, #0xdf]
    // 0x7a92e8: DecompressPointer r1
    //     0x7a92e8: add             x1, x1, HEAP, lsl #32
    // 0x7a92ec: stur            x1, [fp, #-0x10]
    // 0x7a92f0: r1 = 1
    //     0x7a92f0: mov             x1, #1
    // 0x7a92f4: r0 = AllocateContext()
    //     0x7a92f4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a92f8: mov             x1, x0
    // 0x7a92fc: ldr             x0, [fp, #0x68]
    // 0x7a9300: StoreField: r1->field_f = r0
    //     0x7a9300: stur            w0, [x1, #0xf]
    // 0x7a9304: mov             x2, x1
    // 0x7a9308: r1 = Function '_updateTextSelectionOverlayVisibilities@500251836':.
    //     0x7a9308: add             x1, PP, #0x37, lsl #12  ; [pp+0x37448] AnonymousClosure: (0x7a7398), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities (0x7a7294)
    //     0x7a930c: ldr             x1, [x1, #0x448]
    // 0x7a9310: r0 = AllocateClosure()
    //     0x7a9310: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a9314: ldur            x16, [fp, #-0x10]
    // 0x7a9318: stp             x0, x16, [SP, #-0x10]!
    // 0x7a931c: r0 = addListener()
    //     0x7a931c: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7a9320: add             SP, SP, #0x10
    // 0x7a9324: ldr             x0, [fp, #0x38]
    // 0x7a9328: LoadField: r1 = r0->field_e3
    //     0x7a9328: ldur            w1, [x0, #0xe3]
    // 0x7a932c: DecompressPointer r1
    //     0x7a932c: add             x1, x1, HEAP, lsl #32
    // 0x7a9330: stur            x1, [fp, #-0x10]
    // 0x7a9334: r1 = 1
    //     0x7a9334: mov             x1, #1
    // 0x7a9338: r0 = AllocateContext()
    //     0x7a9338: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a933c: mov             x1, x0
    // 0x7a9340: ldr             x0, [fp, #0x68]
    // 0x7a9344: StoreField: r1->field_f = r0
    //     0x7a9344: stur            w0, [x1, #0xf]
    // 0x7a9348: mov             x2, x1
    // 0x7a934c: r1 = Function '_updateTextSelectionOverlayVisibilities@500251836':.
    //     0x7a934c: add             x1, PP, #0x37, lsl #12  ; [pp+0x37448] AnonymousClosure: (0x7a7398), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities (0x7a7294)
    //     0x7a9350: ldr             x1, [x1, #0x448]
    // 0x7a9354: r0 = AllocateClosure()
    //     0x7a9354: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a9358: ldur            x16, [fp, #-0x10]
    // 0x7a935c: stp             x0, x16, [SP, #-0x10]!
    // 0x7a9360: r0 = addListener()
    //     0x7a9360: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x7a9364: add             SP, SP, #0x10
    // 0x7a9368: ldr             x16, [fp, #0x68]
    // 0x7a936c: SaveReg r16
    //     0x7a936c: str             x16, [SP, #-8]!
    // 0x7a9370: r0 = _updateTextSelectionOverlayVisibilities()
    //     0x7a9370: bl              #0x7a7294  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities
    // 0x7a9374: add             SP, SP, #8
    // 0x7a9378: r1 = 1
    //     0x7a9378: mov             x1, #1
    // 0x7a937c: r0 = AllocateContext()
    //     0x7a937c: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a9380: mov             x1, x0
    // 0x7a9384: ldr             x0, [fp, #0x68]
    // 0x7a9388: stur            x1, [fp, #-0x10]
    // 0x7a938c: StoreField: r1->field_f = r0
    //     0x7a938c: stur            w0, [x1, #0xf]
    // 0x7a9390: r1 = 1
    //     0x7a9390: mov             x1, #1
    // 0x7a9394: r0 = AllocateContext()
    //     0x7a9394: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a9398: mov             x1, x0
    // 0x7a939c: ldr             x0, [fp, #0x68]
    // 0x7a93a0: stur            x1, [fp, #-0x28]
    // 0x7a93a4: StoreField: r1->field_f = r0
    //     0x7a93a4: stur            w0, [x1, #0xf]
    // 0x7a93a8: r1 = 1
    //     0x7a93a8: mov             x1, #1
    // 0x7a93ac: r0 = AllocateContext()
    //     0x7a93ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a93b0: mov             x1, x0
    // 0x7a93b4: ldr             x0, [fp, #0x68]
    // 0x7a93b8: stur            x1, [fp, #-0x30]
    // 0x7a93bc: StoreField: r1->field_f = r0
    //     0x7a93bc: stur            w0, [x1, #0xf]
    // 0x7a93c0: r1 = 1
    //     0x7a93c0: mov             x1, #1
    // 0x7a93c4: r0 = AllocateContext()
    //     0x7a93c4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7a93c8: mov             x3, x0
    // 0x7a93cc: ldr             x0, [fp, #0x68]
    // 0x7a93d0: stur            x3, [fp, #-0x40]
    // 0x7a93d4: StoreField: r3->field_f = r0
    //     0x7a93d4: stur            w0, [x3, #0xf]
    // 0x7a93d8: ldr             x1, [fp, #0x38]
    // 0x7a93dc: LoadField: r4 = r1->field_8f
    //     0x7a93dc: ldur            w4, [x1, #0x8f]
    // 0x7a93e0: DecompressPointer r4
    //     0x7a93e0: add             x4, x4, HEAP, lsl #32
    // 0x7a93e4: ldur            x2, [fp, #-0x10]
    // 0x7a93e8: stur            x4, [fp, #-0x38]
    // 0x7a93ec: r1 = Function '_handleSelectionStartHandleDragStart@500251836':.
    //     0x7a93ec: add             x1, PP, #0x37, lsl #12  ; [pp+0x37450] AnonymousClosure: (0x7abeec), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionStartHandleDragStart (0x7abf38)
    //     0x7a93f0: ldr             x1, [x1, #0x450]
    // 0x7a93f4: r0 = AllocateClosure()
    //     0x7a93f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a93f8: ldur            x2, [fp, #-0x28]
    // 0x7a93fc: r1 = Function '_handleSelectionStartHandleDragUpdate@500251836':.
    //     0x7a93fc: add             x1, PP, #0x37, lsl #12  ; [pp+0x37458] AnonymousClosure: (0x7abc7c), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionStartHandleDragUpdate (0x7abcc8)
    //     0x7a9400: ldr             x1, [x1, #0x458]
    // 0x7a9404: stur            x0, [fp, #-0x10]
    // 0x7a9408: r0 = AllocateClosure()
    //     0x7a9408: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a940c: ldur            x2, [fp, #-0x30]
    // 0x7a9410: r1 = Function '_handleSelectionEndHandleDragStart@500251836':.
    //     0x7a9410: add             x1, PP, #0x37, lsl #12  ; [pp+0x37460] AnonymousClosure: (0x7abb3c), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionEndHandleDragStart (0x7abb88)
    //     0x7a9414: ldr             x1, [x1, #0x460]
    // 0x7a9418: stur            x0, [fp, #-0x28]
    // 0x7a941c: r0 = AllocateClosure()
    //     0x7a941c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a9420: ldur            x2, [fp, #-0x40]
    // 0x7a9424: r1 = Function '_handleSelectionEndHandleDragUpdate@500251836':.
    //     0x7a9424: add             x1, PP, #0x37, lsl #12  ; [pp+0x37468] AnonymousClosure: (0x7a97d4), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionEndHandleDragUpdate (0x7a9820)
    //     0x7a9428: ldr             x1, [x1, #0x468]
    // 0x7a942c: stur            x0, [fp, #-0x30]
    // 0x7a9430: r0 = AllocateClosure()
    //     0x7a9430: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7a9434: stur            x0, [fp, #-0x40]
    // 0x7a9438: r0 = SelectionOverlay()
    //     0x7a9438: bl              #0x7a97c8  ; AllocateSelectionOverlayStub -> SelectionOverlay (size=0x80)
    // 0x7a943c: stur            x0, [fp, #-0x48]
    // 0x7a9440: ldr             x16, [fp, #0x60]
    // 0x7a9444: stp             x16, x0, [SP, #-0x10]!
    // 0x7a9448: ldr             x16, [fp, #0x58]
    // 0x7a944c: ldr             lr, [fp, #0x50]
    // 0x7a9450: stp             lr, x16, [SP, #-0x10]!
    // 0x7a9454: ldr             x16, [fp, #0x48]
    // 0x7a9458: ldur            lr, [fp, #-0x18]
    // 0x7a945c: stp             lr, x16, [SP, #-0x10]!
    // 0x7a9460: ldur            x16, [fp, #-0x30]
    // 0x7a9464: ldur            lr, [fp, #-0x40]
    // 0x7a9468: stp             lr, x16, [SP, #-0x10]!
    // 0x7a946c: ldr             x16, [fp, #0x40]
    // 0x7a9470: ldur            lr, [fp, #-0x10]
    // 0x7a9474: stp             lr, x16, [SP, #-0x10]!
    // 0x7a9478: ldur            x16, [fp, #-0x28]
    // 0x7a947c: ldr             lr, [fp, #0x30]
    // 0x7a9480: stp             lr, x16, [SP, #-0x10]!
    // 0x7a9484: ldr             x16, [fp, #0x28]
    // 0x7a9488: ldr             lr, [fp, #0x20]
    // 0x7a948c: stp             lr, x16, [SP, #-0x10]!
    // 0x7a9490: ldur            x16, [fp, #-8]
    // 0x7a9494: ldr             lr, [fp, #0x18]
    // 0x7a9498: stp             lr, x16, [SP, #-0x10]!
    // 0x7a949c: ldur            x16, [fp, #-0x38]
    // 0x7a94a0: ldur            lr, [fp, #-0x20]
    // 0x7a94a4: stp             lr, x16, [SP, #-0x10]!
    // 0x7a94a8: r0 = SelectionOverlay()
    //     0x7a94a8: bl              #0x7a9520  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::SelectionOverlay
    // 0x7a94ac: add             SP, SP, #0x90
    // 0x7a94b0: ldr             x0, [fp, #0x68]
    // 0x7a94b4: LoadField: r1 = r0->field_13
    //     0x7a94b4: ldur            w1, [x0, #0x13]
    // 0x7a94b8: DecompressPointer r1
    //     0x7a94b8: add             x1, x1, HEAP, lsl #32
    // 0x7a94bc: r16 = Sentinel
    //     0x7a94bc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a94c0: cmp             w1, w16
    // 0x7a94c4: b.ne            #0x7a94d0
    // 0x7a94c8: mov             x1, x0
    // 0x7a94cc: b               #0x7a94e8
    // 0x7a94d0: r16 = "_selectionOverlay@500251836"
    //     0x7a94d0: add             x16, PP, #0x37, lsl #12  ; [pp+0x37470] "_selectionOverlay@500251836"
    //     0x7a94d4: ldr             x16, [x16, #0x470]
    // 0x7a94d8: SaveReg r16
    //     0x7a94d8: str             x16, [SP, #-8]!
    // 0x7a94dc: r0 = _throwFieldAlreadyInitialized()
    //     0x7a94dc: bl              #0x4fb6c8  ; [dart:_internal] LateError::_throwFieldAlreadyInitialized
    // 0x7a94e0: add             SP, SP, #8
    // 0x7a94e4: ldr             x1, [fp, #0x68]
    // 0x7a94e8: ldur            x0, [fp, #-0x48]
    // 0x7a94ec: StoreField: r1->field_13 = r0
    //     0x7a94ec: stur            w0, [x1, #0x13]
    //     0x7a94f0: ldurb           w16, [x1, #-1]
    //     0x7a94f4: ldurb           w17, [x0, #-1]
    //     0x7a94f8: and             x16, x17, x16, lsr #2
    //     0x7a94fc: tst             x16, HEAP, lsr #32
    //     0x7a9500: b.eq            #0x7a9508
    //     0x7a9504: bl              #0xd6826c
    // 0x7a9508: r0 = Null
    //     0x7a9508: mov             x0, NULL
    // 0x7a950c: LeaveFrame
    //     0x7a950c: mov             SP, fp
    //     0x7a9510: ldp             fp, lr, [SP], #0x10
    // 0x7a9514: ret
    //     0x7a9514: ret             
    // 0x7a9518: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a9518: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a951c: b               #0x7a912c
  }
  [closure] void _handleSelectionEndHandleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x7a97d4, size: 0x4c
    // 0x7a97d4: EnterFrame
    //     0x7a97d4: stp             fp, lr, [SP, #-0x10]!
    //     0x7a97d8: mov             fp, SP
    // 0x7a97dc: ldr             x0, [fp, #0x18]
    // 0x7a97e0: LoadField: r1 = r0->field_17
    //     0x7a97e0: ldur            w1, [x0, #0x17]
    // 0x7a97e4: DecompressPointer r1
    //     0x7a97e4: add             x1, x1, HEAP, lsl #32
    // 0x7a97e8: CheckStackOverflow
    //     0x7a97e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a97ec: cmp             SP, x16
    //     0x7a97f0: b.ls            #0x7a9818
    // 0x7a97f4: LoadField: r0 = r1->field_f
    //     0x7a97f4: ldur            w0, [x1, #0xf]
    // 0x7a97f8: DecompressPointer r0
    //     0x7a97f8: add             x0, x0, HEAP, lsl #32
    // 0x7a97fc: ldr             x16, [fp, #0x10]
    // 0x7a9800: stp             x16, x0, [SP, #-0x10]!
    // 0x7a9804: r0 = _handleSelectionEndHandleDragUpdate()
    //     0x7a9804: bl              #0x7a9820  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionEndHandleDragUpdate
    // 0x7a9808: add             SP, SP, #0x10
    // 0x7a980c: LeaveFrame
    //     0x7a980c: mov             SP, fp
    //     0x7a9810: ldp             fp, lr, [SP], #0x10
    // 0x7a9814: ret
    //     0x7a9814: ret             
    // 0x7a9818: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a9818: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a981c: b               #0x7a97f4
  }
  _ _handleSelectionEndHandleDragUpdate(/* No info */) {
    // ** addr: 0x7a9820, size: 0x224
    // 0x7a9820: EnterFrame
    //     0x7a9820: stp             fp, lr, [SP, #-0x10]!
    //     0x7a9824: mov             fp, SP
    // 0x7a9828: AllocStack(0x18)
    //     0x7a9828: sub             SP, SP, #0x18
    // 0x7a982c: CheckStackOverflow
    //     0x7a982c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a9830: cmp             SP, x16
    //     0x7a9834: b.ls            #0x7a9a2c
    // 0x7a9838: ldr             x0, [fp, #0x18]
    // 0x7a983c: LoadField: r1 = r0->field_2b
    //     0x7a983c: ldur            w1, [x0, #0x2b]
    // 0x7a9840: DecompressPointer r1
    //     0x7a9840: add             x1, x1, HEAP, lsl #32
    // 0x7a9844: r16 = Sentinel
    //     0x7a9844: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7a9848: cmp             w1, w16
    // 0x7a984c: b.eq            #0x7a9a34
    // 0x7a9850: ldr             x2, [fp, #0x10]
    // 0x7a9854: LoadField: r3 = r2->field_b
    //     0x7a9854: ldur            w3, [x2, #0xb]
    // 0x7a9858: DecompressPointer r3
    //     0x7a9858: add             x3, x3, HEAP, lsl #32
    // 0x7a985c: stp             x3, x1, [SP, #-0x10]!
    // 0x7a9860: r0 = +()
    //     0x7a9860: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7a9864: add             SP, SP, #0x10
    // 0x7a9868: mov             x2, x0
    // 0x7a986c: ldr             x1, [fp, #0x18]
    // 0x7a9870: StoreField: r1->field_2b = r0
    //     0x7a9870: stur            w0, [x1, #0x2b]
    //     0x7a9874: ldurb           w16, [x1, #-1]
    //     0x7a9878: ldurb           w17, [x0, #-1]
    //     0x7a987c: and             x16, x17, x16, lsr #2
    //     0x7a9880: tst             x16, HEAP, lsr #32
    //     0x7a9884: b.eq            #0x7a988c
    //     0x7a9888: bl              #0xd6826c
    // 0x7a988c: LoadField: r0 = r1->field_7
    //     0x7a988c: ldur            w0, [x1, #7]
    // 0x7a9890: DecompressPointer r0
    //     0x7a9890: add             x0, x0, HEAP, lsl #32
    // 0x7a9894: stur            x0, [fp, #-8]
    // 0x7a9898: stp             x2, x0, [SP, #-0x10]!
    // 0x7a989c: r0 = getPositionForPoint()
    //     0x7a989c: bl              #0x7aba98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::getPositionForPoint
    // 0x7a98a0: add             SP, SP, #0x10
    // 0x7a98a4: mov             x1, x0
    // 0x7a98a8: ldur            x0, [fp, #-8]
    // 0x7a98ac: LoadField: r2 = r0->field_97
    //     0x7a98ac: ldur            w2, [x0, #0x97]
    // 0x7a98b0: DecompressPointer r2
    //     0x7a98b0: add             x2, x2, HEAP, lsl #32
    // 0x7a98b4: tbnz            w2, #4, #0x7a98f0
    // 0x7a98b8: LoadField: r2 = r0->field_77
    //     0x7a98b8: ldur            w2, [x0, #0x77]
    // 0x7a98bc: DecompressPointer r2
    //     0x7a98bc: add             x2, x2, HEAP, lsl #32
    // 0x7a98c0: tbnz            w2, #4, #0x7a98f0
    // 0x7a98c4: LoadField: r2 = r0->field_eb
    //     0x7a98c4: ldur            w2, [x0, #0xeb]
    // 0x7a98c8: DecompressPointer r2
    //     0x7a98c8: add             x2, x2, HEAP, lsl #32
    // 0x7a98cc: LoadField: r0 = r2->field_f
    //     0x7a98cc: ldur            w0, [x2, #0xf]
    // 0x7a98d0: DecompressPointer r0
    //     0x7a98d0: add             x0, x0, HEAP, lsl #32
    // 0x7a98d4: cmp             w0, NULL
    // 0x7a98d8: b.eq            #0x7a9a40
    // 0x7a98dc: stp             x1, x0, [SP, #-0x10]!
    // 0x7a98e0: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7a98e0: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7a98e4: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x7a98e4: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x7a98e8: add             SP, SP, #0x10
    // 0x7a98ec: mov             x1, x0
    // 0x7a98f0: ldr             x0, [fp, #0x18]
    // 0x7a98f4: stur            x1, [fp, #-8]
    // 0x7a98f8: LoadField: r2 = r0->field_17
    //     0x7a98f8: ldur            w2, [x0, #0x17]
    // 0x7a98fc: DecompressPointer r2
    //     0x7a98fc: add             x2, x2, HEAP, lsl #32
    // 0x7a9900: LoadField: r3 = r2->field_b
    //     0x7a9900: ldur            w3, [x2, #0xb]
    // 0x7a9904: DecompressPointer r3
    //     0x7a9904: add             x3, x3, HEAP, lsl #32
    // 0x7a9908: LoadField: r2 = r3->field_7
    //     0x7a9908: ldur            x2, [x3, #7]
    // 0x7a990c: LoadField: r4 = r3->field_f
    //     0x7a990c: ldur            x4, [x3, #0xf]
    // 0x7a9910: cmp             x2, x4
    // 0x7a9914: b.ne            #0x7a997c
    // 0x7a9918: LoadField: r2 = r1->field_7
    //     0x7a9918: ldur            x2, [x1, #7]
    // 0x7a991c: stur            x2, [fp, #-0x10]
    // 0x7a9920: r0 = TextSelection()
    //     0x7a9920: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x7a9924: mov             x1, x0
    // 0x7a9928: ldur            x0, [fp, #-0x10]
    // 0x7a992c: StoreField: r1->field_17 = r0
    //     0x7a992c: stur            x0, [x1, #0x17]
    // 0x7a9930: StoreField: r1->field_1f = r0
    //     0x7a9930: stur            x0, [x1, #0x1f]
    // 0x7a9934: ldur            x2, [fp, #-8]
    // 0x7a9938: LoadField: r3 = r2->field_f
    //     0x7a9938: ldur            w3, [x2, #0xf]
    // 0x7a993c: DecompressPointer r3
    //     0x7a993c: add             x3, x3, HEAP, lsl #32
    // 0x7a9940: StoreField: r1->field_27 = r3
    //     0x7a9940: stur            w3, [x1, #0x27]
    // 0x7a9944: r4 = false
    //     0x7a9944: add             x4, NULL, #0x30  ; false
    // 0x7a9948: StoreField: r1->field_2b = r4
    //     0x7a9948: stur            w4, [x1, #0x2b]
    // 0x7a994c: StoreField: r1->field_7 = r0
    //     0x7a994c: stur            x0, [x1, #7]
    // 0x7a9950: StoreField: r1->field_f = r0
    //     0x7a9950: stur            x0, [x1, #0xf]
    // 0x7a9954: ldr             x16, [fp, #0x18]
    // 0x7a9958: stp             x1, x16, [SP, #-0x10]!
    // 0x7a995c: r16 = true
    //     0x7a995c: add             x16, NULL, #0x20  ; true
    // 0x7a9960: SaveReg r16
    //     0x7a9960: str             x16, [SP, #-8]!
    // 0x7a9964: r0 = _handleSelectionHandleChanged()
    //     0x7a9964: bl              #0x7a9a44  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionHandleChanged
    // 0x7a9968: add             SP, SP, #0x18
    // 0x7a996c: r0 = Null
    //     0x7a996c: mov             x0, NULL
    // 0x7a9970: LeaveFrame
    //     0x7a9970: mov             SP, fp
    //     0x7a9974: ldp             fp, lr, [SP], #0x10
    // 0x7a9978: ret
    //     0x7a9978: ret             
    // 0x7a997c: mov             x2, x1
    // 0x7a9980: r4 = false
    //     0x7a9980: add             x4, NULL, #0x30  ; false
    // 0x7a9984: LoadField: r0 = r3->field_17
    //     0x7a9984: ldur            x0, [x3, #0x17]
    // 0x7a9988: stur            x0, [fp, #-0x18]
    // 0x7a998c: LoadField: r1 = r2->field_7
    //     0x7a998c: ldur            x1, [x2, #7]
    // 0x7a9990: stur            x1, [fp, #-0x10]
    // 0x7a9994: r0 = TextSelection()
    //     0x7a9994: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x7a9998: mov             x1, x0
    // 0x7a999c: ldur            x0, [fp, #-0x18]
    // 0x7a99a0: StoreField: r1->field_17 = r0
    //     0x7a99a0: stur            x0, [x1, #0x17]
    // 0x7a99a4: ldur            x2, [fp, #-0x10]
    // 0x7a99a8: StoreField: r1->field_1f = r2
    //     0x7a99a8: stur            x2, [x1, #0x1f]
    // 0x7a99ac: r3 = Instance_TextAffinity
    //     0x7a99ac: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x7a99b0: StoreField: r1->field_27 = r3
    //     0x7a99b0: stur            w3, [x1, #0x27]
    // 0x7a99b4: r3 = false
    //     0x7a99b4: add             x3, NULL, #0x30  ; false
    // 0x7a99b8: StoreField: r1->field_2b = r3
    //     0x7a99b8: stur            w3, [x1, #0x2b]
    // 0x7a99bc: cmp             x0, x2
    // 0x7a99c0: b.ge            #0x7a99cc
    // 0x7a99c4: mov             x3, x0
    // 0x7a99c8: b               #0x7a99d0
    // 0x7a99cc: mov             x3, x2
    // 0x7a99d0: cmp             x0, x2
    // 0x7a99d4: b.ge            #0x7a99e0
    // 0x7a99d8: mov             x4, x2
    // 0x7a99dc: b               #0x7a99e4
    // 0x7a99e0: mov             x4, x0
    // 0x7a99e4: StoreField: r1->field_7 = r3
    //     0x7a99e4: stur            x3, [x1, #7]
    // 0x7a99e8: StoreField: r1->field_f = r4
    //     0x7a99e8: stur            x4, [x1, #0xf]
    // 0x7a99ec: cmp             x0, x2
    // 0x7a99f0: b.lt            #0x7a9a04
    // 0x7a99f4: r0 = Null
    //     0x7a99f4: mov             x0, NULL
    // 0x7a99f8: LeaveFrame
    //     0x7a99f8: mov             SP, fp
    //     0x7a99fc: ldp             fp, lr, [SP], #0x10
    // 0x7a9a00: ret
    //     0x7a9a00: ret             
    // 0x7a9a04: ldr             x16, [fp, #0x18]
    // 0x7a9a08: stp             x1, x16, [SP, #-0x10]!
    // 0x7a9a0c: r16 = true
    //     0x7a9a0c: add             x16, NULL, #0x20  ; true
    // 0x7a9a10: SaveReg r16
    //     0x7a9a10: str             x16, [SP, #-8]!
    // 0x7a9a14: r0 = _handleSelectionHandleChanged()
    //     0x7a9a14: bl              #0x7a9a44  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionHandleChanged
    // 0x7a9a18: add             SP, SP, #0x18
    // 0x7a9a1c: r0 = Null
    //     0x7a9a1c: mov             x0, NULL
    // 0x7a9a20: LeaveFrame
    //     0x7a9a20: mov             SP, fp
    //     0x7a9a24: ldp             fp, lr, [SP], #0x10
    // 0x7a9a28: ret
    //     0x7a9a28: ret             
    // 0x7a9a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a9a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a9a30: b               #0x7a9838
    // 0x7a9a34: r9 = _dragEndPosition
    //     0x7a9a34: add             x9, PP, #0x37, lsl #12  ; [pp+0x37478] Field <ExtendedTextSelectionOverlay._dragEndPosition@500251836>: late (offset: 0x2c)
    //     0x7a9a38: ldr             x9, [x9, #0x478]
    // 0x7a9a3c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7a9a3c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7a9a40: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7a9a40: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _handleSelectionHandleChanged(/* No info */) {
    // ** addr: 0x7a9a44, size: 0xc8
    // 0x7a9a44: EnterFrame
    //     0x7a9a44: stp             fp, lr, [SP, #-0x10]!
    //     0x7a9a48: mov             fp, SP
    // 0x7a9a4c: AllocStack(0x10)
    //     0x7a9a4c: sub             SP, SP, #0x10
    // 0x7a9a50: CheckStackOverflow
    //     0x7a9a50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7a9a54: cmp             SP, x16
    //     0x7a9a58: b.ls            #0x7a9b04
    // 0x7a9a5c: ldr             x0, [fp, #0x10]
    // 0x7a9a60: tbnz            w0, #4, #0x7a9a7c
    // 0x7a9a64: ldr             x16, [fp, #0x18]
    // 0x7a9a68: SaveReg r16
    //     0x7a9a68: str             x16, [SP, #-8]!
    // 0x7a9a6c: r0 = extent()
    //     0x7a9a6c: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x7a9a70: add             SP, SP, #8
    // 0x7a9a74: mov             x1, x0
    // 0x7a9a78: b               #0x7a9a90
    // 0x7a9a7c: ldr             x16, [fp, #0x18]
    // 0x7a9a80: SaveReg r16
    //     0x7a9a80: str             x16, [SP, #-8]!
    // 0x7a9a84: r0 = base()
    //     0x7a9a84: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x7a9a88: add             SP, SP, #8
    // 0x7a9a8c: mov             x1, x0
    // 0x7a9a90: ldr             x0, [fp, #0x20]
    // 0x7a9a94: stur            x1, [fp, #-0x10]
    // 0x7a9a98: LoadField: r2 = r0->field_f
    //     0x7a9a98: ldur            w2, [x0, #0xf]
    // 0x7a9a9c: DecompressPointer r2
    //     0x7a9a9c: add             x2, x2, HEAP, lsl #32
    // 0x7a9aa0: stur            x2, [fp, #-8]
    // 0x7a9aa4: LoadField: r3 = r0->field_17
    //     0x7a9aa4: ldur            w3, [x0, #0x17]
    // 0x7a9aa8: DecompressPointer r3
    //     0x7a9aa8: add             x3, x3, HEAP, lsl #32
    // 0x7a9aac: ldr             x16, [fp, #0x18]
    // 0x7a9ab0: stp             x16, x3, [SP, #-0x10]!
    // 0x7a9ab4: r4 = const [0, 0x2, 0x2, 0x1, selection, 0x1, null]
    //     0x7a9ab4: add             x4, PP, #0x1f, lsl #12  ; [pp+0x1f640] List(7) [0, 0x2, 0x2, 0x1, "selection", 0x1, Null]
    //     0x7a9ab8: ldr             x4, [x4, #0x640]
    // 0x7a9abc: r0 = copyWith()
    //     0x7a9abc: bl              #0x79a550  ; [package:flutter/src/services/text_input.dart] TextEditingValue::copyWith
    // 0x7a9ac0: add             SP, SP, #0x10
    // 0x7a9ac4: ldur            x16, [fp, #-8]
    // 0x7a9ac8: stp             x0, x16, [SP, #-0x10]!
    // 0x7a9acc: r16 = Instance_SelectionChangedCause
    //     0x7a9acc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x7a9ad0: ldr             x16, [x16, #0x6d0]
    // 0x7a9ad4: SaveReg r16
    //     0x7a9ad4: str             x16, [SP, #-8]!
    // 0x7a9ad8: r0 = userUpdateTextEditingValue()
    //     0x7a9ad8: bl              #0x7a9d78  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::userUpdateTextEditingValue
    // 0x7a9adc: add             SP, SP, #0x18
    // 0x7a9ae0: ldur            x16, [fp, #-8]
    // 0x7a9ae4: ldur            lr, [fp, #-0x10]
    // 0x7a9ae8: stp             lr, x16, [SP, #-0x10]!
    // 0x7a9aec: r0 = bringIntoView()
    //     0x7a9aec: bl              #0x7a9b0c  ; [package:extended_text_field/src/extended_editable_text.dart] ExtendedEditableTextState::bringIntoView
    // 0x7a9af0: add             SP, SP, #0x10
    // 0x7a9af4: r0 = Null
    //     0x7a9af4: mov             x0, NULL
    // 0x7a9af8: LeaveFrame
    //     0x7a9af8: mov             SP, fp
    //     0x7a9afc: ldp             fp, lr, [SP], #0x10
    // 0x7a9b00: ret
    //     0x7a9b00: ret             
    // 0x7a9b04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7a9b04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7a9b08: b               #0x7a9a5c
  }
  [closure] void _handleSelectionEndHandleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x7abb3c, size: 0x4c
    // 0x7abb3c: EnterFrame
    //     0x7abb3c: stp             fp, lr, [SP, #-0x10]!
    //     0x7abb40: mov             fp, SP
    // 0x7abb44: ldr             x0, [fp, #0x18]
    // 0x7abb48: LoadField: r1 = r0->field_17
    //     0x7abb48: ldur            w1, [x0, #0x17]
    // 0x7abb4c: DecompressPointer r1
    //     0x7abb4c: add             x1, x1, HEAP, lsl #32
    // 0x7abb50: CheckStackOverflow
    //     0x7abb50: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abb54: cmp             SP, x16
    //     0x7abb58: b.ls            #0x7abb80
    // 0x7abb5c: LoadField: r0 = r1->field_f
    //     0x7abb5c: ldur            w0, [x1, #0xf]
    // 0x7abb60: DecompressPointer r0
    //     0x7abb60: add             x0, x0, HEAP, lsl #32
    // 0x7abb64: ldr             x16, [fp, #0x10]
    // 0x7abb68: stp             x16, x0, [SP, #-0x10]!
    // 0x7abb6c: r0 = _handleSelectionEndHandleDragStart()
    //     0x7abb6c: bl              #0x7abb88  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionEndHandleDragStart
    // 0x7abb70: add             SP, SP, #0x10
    // 0x7abb74: LeaveFrame
    //     0x7abb74: mov             SP, fp
    //     0x7abb78: ldp             fp, lr, [SP], #0x10
    // 0x7abb7c: ret
    //     0x7abb7c: ret             
    // 0x7abb80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abb80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abb84: b               #0x7abb5c
  }
  _ _handleSelectionEndHandleDragStart(/* No info */) {
    // ** addr: 0x7abb88, size: 0xf4
    // 0x7abb88: EnterFrame
    //     0x7abb88: stp             fp, lr, [SP, #-0x10]!
    //     0x7abb8c: mov             fp, SP
    // 0x7abb90: AllocStack(0x10)
    //     0x7abb90: sub             SP, SP, #0x10
    // 0x7abb94: CheckStackOverflow
    //     0x7abb94: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abb98: cmp             SP, x16
    //     0x7abb9c: b.ls            #0x7abc70
    // 0x7abba0: ldr             x0, [fp, #0x18]
    // 0x7abba4: LoadField: r1 = r0->field_b
    //     0x7abba4: ldur            w1, [x0, #0xb]
    // 0x7abba8: DecompressPointer r1
    //     0x7abba8: add             x1, x1, HEAP, lsl #32
    // 0x7abbac: stur            x1, [fp, #-8]
    // 0x7abbb0: cmp             w1, NULL
    // 0x7abbb4: b.eq            #0x7abc78
    // 0x7abbb8: LoadField: r2 = r0->field_7
    //     0x7abbb8: ldur            w2, [x0, #7]
    // 0x7abbbc: DecompressPointer r2
    //     0x7abbbc: add             x2, x2, HEAP, lsl #32
    // 0x7abbc0: LoadField: r3 = r2->field_eb
    //     0x7abbc0: ldur            w3, [x2, #0xeb]
    // 0x7abbc4: DecompressPointer r3
    //     0x7abbc4: add             x3, x3, HEAP, lsl #32
    // 0x7abbc8: SaveReg r3
    //     0x7abbc8: str             x3, [SP, #-8]!
    // 0x7abbcc: r0 = preferredLineHeight()
    //     0x7abbcc: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x7abbd0: add             SP, SP, #8
    // 0x7abbd4: ldur            x0, [fp, #-8]
    // 0x7abbd8: r1 = LoadClassIdInstr(r0)
    //     0x7abbd8: ldur            x1, [x0, #-1]
    //     0x7abbdc: ubfx            x1, x1, #0xc, #0x14
    // 0x7abbe0: SaveReg r0
    //     0x7abbe0: str             x0, [SP, #-8]!
    // 0x7abbe4: SaveReg d0
    //     0x7abbe4: str             d0, [SP, #-8]!
    // 0x7abbe8: mov             x0, x1
    // 0x7abbec: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x7abbec: sub             lr, x0, #0xfd3
    //     0x7abbf0: ldr             lr, [x21, lr, lsl #3]
    //     0x7abbf4: blr             lr
    // 0x7abbf8: add             SP, SP, #0x10
    // 0x7abbfc: mov             x1, x0
    // 0x7abc00: ldr             x0, [fp, #0x10]
    // 0x7abc04: LoadField: r2 = r0->field_b
    //     0x7abc04: ldur            w2, [x0, #0xb]
    // 0x7abc08: DecompressPointer r2
    //     0x7abc08: add             x2, x2, HEAP, lsl #32
    // 0x7abc0c: stur            x2, [fp, #-8]
    // 0x7abc10: LoadField: d0 = r1->field_f
    //     0x7abc10: ldur            d0, [x1, #0xf]
    // 0x7abc14: fneg            d1, d0
    // 0x7abc18: stur            d1, [fp, #-0x10]
    // 0x7abc1c: r0 = Offset()
    //     0x7abc1c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7abc20: d0 = 0.000000
    //     0x7abc20: eor             v0.16b, v0.16b, v0.16b
    // 0x7abc24: StoreField: r0->field_7 = d0
    //     0x7abc24: stur            d0, [x0, #7]
    // 0x7abc28: ldur            d0, [fp, #-0x10]
    // 0x7abc2c: StoreField: r0->field_f = d0
    //     0x7abc2c: stur            d0, [x0, #0xf]
    // 0x7abc30: ldur            x16, [fp, #-8]
    // 0x7abc34: stp             x0, x16, [SP, #-0x10]!
    // 0x7abc38: r0 = +()
    //     0x7abc38: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7abc3c: add             SP, SP, #0x10
    // 0x7abc40: ldr             x1, [fp, #0x18]
    // 0x7abc44: StoreField: r1->field_2b = r0
    //     0x7abc44: stur            w0, [x1, #0x2b]
    //     0x7abc48: ldurb           w16, [x1, #-1]
    //     0x7abc4c: ldurb           w17, [x0, #-1]
    //     0x7abc50: and             x16, x17, x16, lsr #2
    //     0x7abc54: tst             x16, HEAP, lsr #32
    //     0x7abc58: b.eq            #0x7abc60
    //     0x7abc5c: bl              #0xd6826c
    // 0x7abc60: r0 = Null
    //     0x7abc60: mov             x0, NULL
    // 0x7abc64: LeaveFrame
    //     0x7abc64: mov             SP, fp
    //     0x7abc68: ldp             fp, lr, [SP], #0x10
    // 0x7abc6c: ret
    //     0x7abc6c: ret             
    // 0x7abc70: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abc70: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abc74: b               #0x7abba0
    // 0x7abc78: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7abc78: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionStartHandleDragUpdate(dynamic, DragUpdateDetails) {
    // ** addr: 0x7abc7c, size: 0x4c
    // 0x7abc7c: EnterFrame
    //     0x7abc7c: stp             fp, lr, [SP, #-0x10]!
    //     0x7abc80: mov             fp, SP
    // 0x7abc84: ldr             x0, [fp, #0x18]
    // 0x7abc88: LoadField: r1 = r0->field_17
    //     0x7abc88: ldur            w1, [x0, #0x17]
    // 0x7abc8c: DecompressPointer r1
    //     0x7abc8c: add             x1, x1, HEAP, lsl #32
    // 0x7abc90: CheckStackOverflow
    //     0x7abc90: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abc94: cmp             SP, x16
    //     0x7abc98: b.ls            #0x7abcc0
    // 0x7abc9c: LoadField: r0 = r1->field_f
    //     0x7abc9c: ldur            w0, [x1, #0xf]
    // 0x7abca0: DecompressPointer r0
    //     0x7abca0: add             x0, x0, HEAP, lsl #32
    // 0x7abca4: ldr             x16, [fp, #0x10]
    // 0x7abca8: stp             x16, x0, [SP, #-0x10]!
    // 0x7abcac: r0 = _handleSelectionStartHandleDragUpdate()
    //     0x7abcac: bl              #0x7abcc8  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionStartHandleDragUpdate
    // 0x7abcb0: add             SP, SP, #0x10
    // 0x7abcb4: LeaveFrame
    //     0x7abcb4: mov             SP, fp
    //     0x7abcb8: ldp             fp, lr, [SP], #0x10
    // 0x7abcbc: ret
    //     0x7abcbc: ret             
    // 0x7abcc0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abcc0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abcc4: b               #0x7abc9c
  }
  _ _handleSelectionStartHandleDragUpdate(/* No info */) {
    // ** addr: 0x7abcc8, size: 0x224
    // 0x7abcc8: EnterFrame
    //     0x7abcc8: stp             fp, lr, [SP, #-0x10]!
    //     0x7abccc: mov             fp, SP
    // 0x7abcd0: AllocStack(0x18)
    //     0x7abcd0: sub             SP, SP, #0x18
    // 0x7abcd4: CheckStackOverflow
    //     0x7abcd4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abcd8: cmp             SP, x16
    //     0x7abcdc: b.ls            #0x7abed4
    // 0x7abce0: ldr             x0, [fp, #0x18]
    // 0x7abce4: LoadField: r1 = r0->field_2f
    //     0x7abce4: ldur            w1, [x0, #0x2f]
    // 0x7abce8: DecompressPointer r1
    //     0x7abce8: add             x1, x1, HEAP, lsl #32
    // 0x7abcec: r16 = Sentinel
    //     0x7abcec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7abcf0: cmp             w1, w16
    // 0x7abcf4: b.eq            #0x7abedc
    // 0x7abcf8: ldr             x2, [fp, #0x10]
    // 0x7abcfc: LoadField: r3 = r2->field_b
    //     0x7abcfc: ldur            w3, [x2, #0xb]
    // 0x7abd00: DecompressPointer r3
    //     0x7abd00: add             x3, x3, HEAP, lsl #32
    // 0x7abd04: stp             x3, x1, [SP, #-0x10]!
    // 0x7abd08: r0 = +()
    //     0x7abd08: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7abd0c: add             SP, SP, #0x10
    // 0x7abd10: mov             x2, x0
    // 0x7abd14: ldr             x1, [fp, #0x18]
    // 0x7abd18: StoreField: r1->field_2f = r0
    //     0x7abd18: stur            w0, [x1, #0x2f]
    //     0x7abd1c: ldurb           w16, [x1, #-1]
    //     0x7abd20: ldurb           w17, [x0, #-1]
    //     0x7abd24: and             x16, x17, x16, lsr #2
    //     0x7abd28: tst             x16, HEAP, lsr #32
    //     0x7abd2c: b.eq            #0x7abd34
    //     0x7abd30: bl              #0xd6826c
    // 0x7abd34: LoadField: r0 = r1->field_7
    //     0x7abd34: ldur            w0, [x1, #7]
    // 0x7abd38: DecompressPointer r0
    //     0x7abd38: add             x0, x0, HEAP, lsl #32
    // 0x7abd3c: stur            x0, [fp, #-8]
    // 0x7abd40: stp             x2, x0, [SP, #-0x10]!
    // 0x7abd44: r0 = getPositionForPoint()
    //     0x7abd44: bl              #0x7aba98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::getPositionForPoint
    // 0x7abd48: add             SP, SP, #0x10
    // 0x7abd4c: mov             x1, x0
    // 0x7abd50: ldur            x0, [fp, #-8]
    // 0x7abd54: LoadField: r2 = r0->field_97
    //     0x7abd54: ldur            w2, [x0, #0x97]
    // 0x7abd58: DecompressPointer r2
    //     0x7abd58: add             x2, x2, HEAP, lsl #32
    // 0x7abd5c: tbnz            w2, #4, #0x7abd98
    // 0x7abd60: LoadField: r2 = r0->field_77
    //     0x7abd60: ldur            w2, [x0, #0x77]
    // 0x7abd64: DecompressPointer r2
    //     0x7abd64: add             x2, x2, HEAP, lsl #32
    // 0x7abd68: tbnz            w2, #4, #0x7abd98
    // 0x7abd6c: LoadField: r2 = r0->field_eb
    //     0x7abd6c: ldur            w2, [x0, #0xeb]
    // 0x7abd70: DecompressPointer r2
    //     0x7abd70: add             x2, x2, HEAP, lsl #32
    // 0x7abd74: LoadField: r0 = r2->field_f
    //     0x7abd74: ldur            w0, [x2, #0xf]
    // 0x7abd78: DecompressPointer r0
    //     0x7abd78: add             x0, x0, HEAP, lsl #32
    // 0x7abd7c: cmp             w0, NULL
    // 0x7abd80: b.eq            #0x7abee8
    // 0x7abd84: stp             x1, x0, [SP, #-0x10]!
    // 0x7abd88: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x7abd88: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x7abd8c: r0 = convertTextPainterPostionToTextInputPostion()
    //     0x7abd8c: bl              #0x7ab5a4  ; [package:extended_text_library/src/extended_text_utils.dart] ::convertTextPainterPostionToTextInputPostion
    // 0x7abd90: add             SP, SP, #0x10
    // 0x7abd94: mov             x1, x0
    // 0x7abd98: ldr             x0, [fp, #0x18]
    // 0x7abd9c: stur            x1, [fp, #-8]
    // 0x7abda0: LoadField: r2 = r0->field_17
    //     0x7abda0: ldur            w2, [x0, #0x17]
    // 0x7abda4: DecompressPointer r2
    //     0x7abda4: add             x2, x2, HEAP, lsl #32
    // 0x7abda8: LoadField: r3 = r2->field_b
    //     0x7abda8: ldur            w3, [x2, #0xb]
    // 0x7abdac: DecompressPointer r3
    //     0x7abdac: add             x3, x3, HEAP, lsl #32
    // 0x7abdb0: LoadField: r2 = r3->field_7
    //     0x7abdb0: ldur            x2, [x3, #7]
    // 0x7abdb4: LoadField: r4 = r3->field_f
    //     0x7abdb4: ldur            x4, [x3, #0xf]
    // 0x7abdb8: cmp             x2, x4
    // 0x7abdbc: b.ne            #0x7abe24
    // 0x7abdc0: LoadField: r2 = r1->field_7
    //     0x7abdc0: ldur            x2, [x1, #7]
    // 0x7abdc4: stur            x2, [fp, #-0x10]
    // 0x7abdc8: r0 = TextSelection()
    //     0x7abdc8: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x7abdcc: mov             x1, x0
    // 0x7abdd0: ldur            x0, [fp, #-0x10]
    // 0x7abdd4: StoreField: r1->field_17 = r0
    //     0x7abdd4: stur            x0, [x1, #0x17]
    // 0x7abdd8: StoreField: r1->field_1f = r0
    //     0x7abdd8: stur            x0, [x1, #0x1f]
    // 0x7abddc: ldur            x2, [fp, #-8]
    // 0x7abde0: LoadField: r3 = r2->field_f
    //     0x7abde0: ldur            w3, [x2, #0xf]
    // 0x7abde4: DecompressPointer r3
    //     0x7abde4: add             x3, x3, HEAP, lsl #32
    // 0x7abde8: StoreField: r1->field_27 = r3
    //     0x7abde8: stur            w3, [x1, #0x27]
    // 0x7abdec: r4 = false
    //     0x7abdec: add             x4, NULL, #0x30  ; false
    // 0x7abdf0: StoreField: r1->field_2b = r4
    //     0x7abdf0: stur            w4, [x1, #0x2b]
    // 0x7abdf4: StoreField: r1->field_7 = r0
    //     0x7abdf4: stur            x0, [x1, #7]
    // 0x7abdf8: StoreField: r1->field_f = r0
    //     0x7abdf8: stur            x0, [x1, #0xf]
    // 0x7abdfc: ldr             x16, [fp, #0x18]
    // 0x7abe00: stp             x1, x16, [SP, #-0x10]!
    // 0x7abe04: r16 = false
    //     0x7abe04: add             x16, NULL, #0x30  ; false
    // 0x7abe08: SaveReg r16
    //     0x7abe08: str             x16, [SP, #-8]!
    // 0x7abe0c: r0 = _handleSelectionHandleChanged()
    //     0x7abe0c: bl              #0x7a9a44  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionHandleChanged
    // 0x7abe10: add             SP, SP, #0x18
    // 0x7abe14: r0 = Null
    //     0x7abe14: mov             x0, NULL
    // 0x7abe18: LeaveFrame
    //     0x7abe18: mov             SP, fp
    //     0x7abe1c: ldp             fp, lr, [SP], #0x10
    // 0x7abe20: ret
    //     0x7abe20: ret             
    // 0x7abe24: mov             x2, x1
    // 0x7abe28: r4 = false
    //     0x7abe28: add             x4, NULL, #0x30  ; false
    // 0x7abe2c: LoadField: r0 = r2->field_7
    //     0x7abe2c: ldur            x0, [x2, #7]
    // 0x7abe30: stur            x0, [fp, #-0x18]
    // 0x7abe34: LoadField: r1 = r3->field_1f
    //     0x7abe34: ldur            x1, [x3, #0x1f]
    // 0x7abe38: stur            x1, [fp, #-0x10]
    // 0x7abe3c: r0 = TextSelection()
    //     0x7abe3c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0x7abe40: mov             x1, x0
    // 0x7abe44: ldur            x0, [fp, #-0x18]
    // 0x7abe48: StoreField: r1->field_17 = r0
    //     0x7abe48: stur            x0, [x1, #0x17]
    // 0x7abe4c: ldur            x2, [fp, #-0x10]
    // 0x7abe50: StoreField: r1->field_1f = r2
    //     0x7abe50: stur            x2, [x1, #0x1f]
    // 0x7abe54: r3 = Instance_TextAffinity
    //     0x7abe54: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0x7abe58: StoreField: r1->field_27 = r3
    //     0x7abe58: stur            w3, [x1, #0x27]
    // 0x7abe5c: r3 = false
    //     0x7abe5c: add             x3, NULL, #0x30  ; false
    // 0x7abe60: StoreField: r1->field_2b = r3
    //     0x7abe60: stur            w3, [x1, #0x2b]
    // 0x7abe64: cmp             x0, x2
    // 0x7abe68: b.ge            #0x7abe74
    // 0x7abe6c: mov             x3, x0
    // 0x7abe70: b               #0x7abe78
    // 0x7abe74: mov             x3, x2
    // 0x7abe78: cmp             x0, x2
    // 0x7abe7c: b.ge            #0x7abe88
    // 0x7abe80: mov             x4, x2
    // 0x7abe84: b               #0x7abe8c
    // 0x7abe88: mov             x4, x0
    // 0x7abe8c: StoreField: r1->field_7 = r3
    //     0x7abe8c: stur            x3, [x1, #7]
    // 0x7abe90: StoreField: r1->field_f = r4
    //     0x7abe90: stur            x4, [x1, #0xf]
    // 0x7abe94: cmp             x0, x2
    // 0x7abe98: b.lt            #0x7abeac
    // 0x7abe9c: r0 = Null
    //     0x7abe9c: mov             x0, NULL
    // 0x7abea0: LeaveFrame
    //     0x7abea0: mov             SP, fp
    //     0x7abea4: ldp             fp, lr, [SP], #0x10
    // 0x7abea8: ret
    //     0x7abea8: ret             
    // 0x7abeac: ldr             x16, [fp, #0x18]
    // 0x7abeb0: stp             x1, x16, [SP, #-0x10]!
    // 0x7abeb4: r16 = false
    //     0x7abeb4: add             x16, NULL, #0x30  ; false
    // 0x7abeb8: SaveReg r16
    //     0x7abeb8: str             x16, [SP, #-8]!
    // 0x7abebc: r0 = _handleSelectionHandleChanged()
    //     0x7abebc: bl              #0x7a9a44  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionHandleChanged
    // 0x7abec0: add             SP, SP, #0x18
    // 0x7abec4: r0 = Null
    //     0x7abec4: mov             x0, NULL
    // 0x7abec8: LeaveFrame
    //     0x7abec8: mov             SP, fp
    //     0x7abecc: ldp             fp, lr, [SP], #0x10
    // 0x7abed0: ret
    //     0x7abed0: ret             
    // 0x7abed4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abed4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abed8: b               #0x7abce0
    // 0x7abedc: r9 = _dragStartPosition
    //     0x7abedc: add             x9, PP, #0x37, lsl #12  ; [pp+0x37490] Field <ExtendedTextSelectionOverlay._dragStartPosition@500251836>: late (offset: 0x30)
    //     0x7abee0: ldr             x9, [x9, #0x490]
    // 0x7abee4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7abee4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7abee8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7abee8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _handleSelectionStartHandleDragStart(dynamic, DragStartDetails) {
    // ** addr: 0x7abeec, size: 0x4c
    // 0x7abeec: EnterFrame
    //     0x7abeec: stp             fp, lr, [SP, #-0x10]!
    //     0x7abef0: mov             fp, SP
    // 0x7abef4: ldr             x0, [fp, #0x18]
    // 0x7abef8: LoadField: r1 = r0->field_17
    //     0x7abef8: ldur            w1, [x0, #0x17]
    // 0x7abefc: DecompressPointer r1
    //     0x7abefc: add             x1, x1, HEAP, lsl #32
    // 0x7abf00: CheckStackOverflow
    //     0x7abf00: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abf04: cmp             SP, x16
    //     0x7abf08: b.ls            #0x7abf30
    // 0x7abf0c: LoadField: r0 = r1->field_f
    //     0x7abf0c: ldur            w0, [x1, #0xf]
    // 0x7abf10: DecompressPointer r0
    //     0x7abf10: add             x0, x0, HEAP, lsl #32
    // 0x7abf14: ldr             x16, [fp, #0x10]
    // 0x7abf18: stp             x16, x0, [SP, #-0x10]!
    // 0x7abf1c: r0 = _handleSelectionStartHandleDragStart()
    //     0x7abf1c: bl              #0x7abf38  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_handleSelectionStartHandleDragStart
    // 0x7abf20: add             SP, SP, #0x10
    // 0x7abf24: LeaveFrame
    //     0x7abf24: mov             SP, fp
    //     0x7abf28: ldp             fp, lr, [SP], #0x10
    // 0x7abf2c: ret
    //     0x7abf2c: ret             
    // 0x7abf30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7abf30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7abf34: b               #0x7abf0c
  }
  _ _handleSelectionStartHandleDragStart(/* No info */) {
    // ** addr: 0x7abf38, size: 0xf4
    // 0x7abf38: EnterFrame
    //     0x7abf38: stp             fp, lr, [SP, #-0x10]!
    //     0x7abf3c: mov             fp, SP
    // 0x7abf40: AllocStack(0x10)
    //     0x7abf40: sub             SP, SP, #0x10
    // 0x7abf44: CheckStackOverflow
    //     0x7abf44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7abf48: cmp             SP, x16
    //     0x7abf4c: b.ls            #0x7ac020
    // 0x7abf50: ldr             x0, [fp, #0x18]
    // 0x7abf54: LoadField: r1 = r0->field_b
    //     0x7abf54: ldur            w1, [x0, #0xb]
    // 0x7abf58: DecompressPointer r1
    //     0x7abf58: add             x1, x1, HEAP, lsl #32
    // 0x7abf5c: stur            x1, [fp, #-8]
    // 0x7abf60: cmp             w1, NULL
    // 0x7abf64: b.eq            #0x7ac028
    // 0x7abf68: LoadField: r2 = r0->field_7
    //     0x7abf68: ldur            w2, [x0, #7]
    // 0x7abf6c: DecompressPointer r2
    //     0x7abf6c: add             x2, x2, HEAP, lsl #32
    // 0x7abf70: LoadField: r3 = r2->field_eb
    //     0x7abf70: ldur            w3, [x2, #0xeb]
    // 0x7abf74: DecompressPointer r3
    //     0x7abf74: add             x3, x3, HEAP, lsl #32
    // 0x7abf78: SaveReg r3
    //     0x7abf78: str             x3, [SP, #-8]!
    // 0x7abf7c: r0 = preferredLineHeight()
    //     0x7abf7c: bl              #0x51a438  ; [package:flutter/src/painting/text_painter.dart] TextPainter::preferredLineHeight
    // 0x7abf80: add             SP, SP, #8
    // 0x7abf84: ldur            x0, [fp, #-8]
    // 0x7abf88: r1 = LoadClassIdInstr(r0)
    //     0x7abf88: ldur            x1, [x0, #-1]
    //     0x7abf8c: ubfx            x1, x1, #0xc, #0x14
    // 0x7abf90: SaveReg r0
    //     0x7abf90: str             x0, [SP, #-8]!
    // 0x7abf94: SaveReg d0
    //     0x7abf94: str             d0, [SP, #-8]!
    // 0x7abf98: mov             x0, x1
    // 0x7abf9c: r0 = GDT[cid_x0 + -0xfd3]()
    //     0x7abf9c: sub             lr, x0, #0xfd3
    //     0x7abfa0: ldr             lr, [x21, lr, lsl #3]
    //     0x7abfa4: blr             lr
    // 0x7abfa8: add             SP, SP, #0x10
    // 0x7abfac: mov             x1, x0
    // 0x7abfb0: ldr             x0, [fp, #0x10]
    // 0x7abfb4: LoadField: r2 = r0->field_b
    //     0x7abfb4: ldur            w2, [x0, #0xb]
    // 0x7abfb8: DecompressPointer r2
    //     0x7abfb8: add             x2, x2, HEAP, lsl #32
    // 0x7abfbc: stur            x2, [fp, #-8]
    // 0x7abfc0: LoadField: d0 = r1->field_f
    //     0x7abfc0: ldur            d0, [x1, #0xf]
    // 0x7abfc4: fneg            d1, d0
    // 0x7abfc8: stur            d1, [fp, #-0x10]
    // 0x7abfcc: r0 = Offset()
    //     0x7abfcc: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0x7abfd0: d0 = 0.000000
    //     0x7abfd0: eor             v0.16b, v0.16b, v0.16b
    // 0x7abfd4: StoreField: r0->field_7 = d0
    //     0x7abfd4: stur            d0, [x0, #7]
    // 0x7abfd8: ldur            d0, [fp, #-0x10]
    // 0x7abfdc: StoreField: r0->field_f = d0
    //     0x7abfdc: stur            d0, [x0, #0xf]
    // 0x7abfe0: ldur            x16, [fp, #-8]
    // 0x7abfe4: stp             x0, x16, [SP, #-0x10]!
    // 0x7abfe8: r0 = +()
    //     0x7abfe8: bl              #0x50e70c  ; [dart:ui] Offset::+
    // 0x7abfec: add             SP, SP, #0x10
    // 0x7abff0: ldr             x1, [fp, #0x18]
    // 0x7abff4: StoreField: r1->field_2f = r0
    //     0x7abff4: stur            w0, [x1, #0x2f]
    //     0x7abff8: ldurb           w16, [x1, #-1]
    //     0x7abffc: ldurb           w17, [x0, #-1]
    //     0x7ac000: and             x16, x17, x16, lsr #2
    //     0x7ac004: tst             x16, HEAP, lsr #32
    //     0x7ac008: b.eq            #0x7ac010
    //     0x7ac00c: bl              #0xd6826c
    // 0x7ac010: r0 = Null
    //     0x7ac010: mov             x0, NULL
    // 0x7ac014: LeaveFrame
    //     0x7ac014: mov             SP, fp
    //     0x7ac018: ldp             fp, lr, [SP], #0x10
    // 0x7ac01c: ret
    //     0x7ac01c: ret             
    // 0x7ac020: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac020: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac024: b               #0x7abf50
    // 0x7ac028: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7ac028: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ dispose(/* No info */) {
    // ** addr: 0x7ac038, size: 0x13c
    // 0x7ac038: EnterFrame
    //     0x7ac038: stp             fp, lr, [SP, #-0x10]!
    //     0x7ac03c: mov             fp, SP
    // 0x7ac040: AllocStack(0x10)
    //     0x7ac040: sub             SP, SP, #0x10
    // 0x7ac044: CheckStackOverflow
    //     0x7ac044: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7ac048: cmp             SP, x16
    //     0x7ac04c: b.ls            #0x7ac160
    // 0x7ac050: ldr             x0, [fp, #0x10]
    // 0x7ac054: LoadField: r1 = r0->field_13
    //     0x7ac054: ldur            w1, [x0, #0x13]
    // 0x7ac058: DecompressPointer r1
    //     0x7ac058: add             x1, x1, HEAP, lsl #32
    // 0x7ac05c: r16 = Sentinel
    //     0x7ac05c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7ac060: cmp             w1, w16
    // 0x7ac064: b.eq            #0x7ac168
    // 0x7ac068: SaveReg r1
    //     0x7ac068: str             x1, [SP, #-8]!
    // 0x7ac06c: r0 = hide()
    //     0x7ac06c: bl              #0x7ac174  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::hide
    // 0x7ac070: add             SP, SP, #8
    // 0x7ac074: ldr             x0, [fp, #0x10]
    // 0x7ac078: LoadField: r1 = r0->field_7
    //     0x7ac078: ldur            w1, [x0, #7]
    // 0x7ac07c: DecompressPointer r1
    //     0x7ac07c: add             x1, x1, HEAP, lsl #32
    // 0x7ac080: stur            x1, [fp, #-0x10]
    // 0x7ac084: LoadField: r2 = r1->field_df
    //     0x7ac084: ldur            w2, [x1, #0xdf]
    // 0x7ac088: DecompressPointer r2
    //     0x7ac088: add             x2, x2, HEAP, lsl #32
    // 0x7ac08c: stur            x2, [fp, #-8]
    // 0x7ac090: r1 = 1
    //     0x7ac090: mov             x1, #1
    // 0x7ac094: r0 = AllocateContext()
    //     0x7ac094: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ac098: mov             x1, x0
    // 0x7ac09c: ldr             x0, [fp, #0x10]
    // 0x7ac0a0: StoreField: r1->field_f = r0
    //     0x7ac0a0: stur            w0, [x1, #0xf]
    // 0x7ac0a4: mov             x2, x1
    // 0x7ac0a8: r1 = Function '_updateTextSelectionOverlayVisibilities@500251836':.
    //     0x7ac0a8: add             x1, PP, #0x37, lsl #12  ; [pp+0x37448] AnonymousClosure: (0x7a7398), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities (0x7a7294)
    //     0x7ac0ac: ldr             x1, [x1, #0x448]
    // 0x7ac0b0: r0 = AllocateClosure()
    //     0x7ac0b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ac0b4: ldur            x16, [fp, #-8]
    // 0x7ac0b8: stp             x0, x16, [SP, #-0x10]!
    // 0x7ac0bc: r0 = removeListener()
    //     0x7ac0bc: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7ac0c0: add             SP, SP, #0x10
    // 0x7ac0c4: ldur            x0, [fp, #-0x10]
    // 0x7ac0c8: LoadField: r1 = r0->field_e3
    //     0x7ac0c8: ldur            w1, [x0, #0xe3]
    // 0x7ac0cc: DecompressPointer r1
    //     0x7ac0cc: add             x1, x1, HEAP, lsl #32
    // 0x7ac0d0: stur            x1, [fp, #-8]
    // 0x7ac0d4: r1 = 1
    //     0x7ac0d4: mov             x1, #1
    // 0x7ac0d8: r0 = AllocateContext()
    //     0x7ac0d8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x7ac0dc: mov             x1, x0
    // 0x7ac0e0: ldr             x0, [fp, #0x10]
    // 0x7ac0e4: StoreField: r1->field_f = r0
    //     0x7ac0e4: stur            w0, [x1, #0xf]
    // 0x7ac0e8: mov             x2, x1
    // 0x7ac0ec: r1 = Function '_updateTextSelectionOverlayVisibilities@500251836':.
    //     0x7ac0ec: add             x1, PP, #0x37, lsl #12  ; [pp+0x37448] AnonymousClosure: (0x7a7398), in [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateTextSelectionOverlayVisibilities (0x7a7294)
    //     0x7ac0f0: ldr             x1, [x1, #0x448]
    // 0x7ac0f4: r0 = AllocateClosure()
    //     0x7ac0f4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x7ac0f8: ldur            x16, [fp, #-8]
    // 0x7ac0fc: stp             x0, x16, [SP, #-0x10]!
    // 0x7ac100: r0 = removeListener()
    //     0x7ac100: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x7ac104: add             SP, SP, #0x10
    // 0x7ac108: ldr             x0, [fp, #0x10]
    // 0x7ac10c: LoadField: r1 = r0->field_23
    //     0x7ac10c: ldur            w1, [x0, #0x23]
    // 0x7ac110: DecompressPointer r1
    //     0x7ac110: add             x1, x1, HEAP, lsl #32
    // 0x7ac114: SaveReg r1
    //     0x7ac114: str             x1, [SP, #-8]!
    // 0x7ac118: r0 = dispose()
    //     0x7ac118: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x7ac11c: add             SP, SP, #8
    // 0x7ac120: ldr             x0, [fp, #0x10]
    // 0x7ac124: LoadField: r1 = r0->field_1b
    //     0x7ac124: ldur            w1, [x0, #0x1b]
    // 0x7ac128: DecompressPointer r1
    //     0x7ac128: add             x1, x1, HEAP, lsl #32
    // 0x7ac12c: SaveReg r1
    //     0x7ac12c: str             x1, [SP, #-8]!
    // 0x7ac130: r0 = dispose()
    //     0x7ac130: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x7ac134: add             SP, SP, #8
    // 0x7ac138: ldr             x0, [fp, #0x10]
    // 0x7ac13c: LoadField: r1 = r0->field_1f
    //     0x7ac13c: ldur            w1, [x0, #0x1f]
    // 0x7ac140: DecompressPointer r1
    //     0x7ac140: add             x1, x1, HEAP, lsl #32
    // 0x7ac144: SaveReg r1
    //     0x7ac144: str             x1, [SP, #-8]!
    // 0x7ac148: r0 = dispose()
    //     0x7ac148: bl              #0xa6b240  ; [package:flutter/src/widgets/focus_manager.dart] _FocusNode&Object&DiagnosticableTreeMixin&ChangeNotifier::dispose
    // 0x7ac14c: add             SP, SP, #8
    // 0x7ac150: r0 = Null
    //     0x7ac150: mov             x0, NULL
    // 0x7ac154: LeaveFrame
    //     0x7ac154: mov             SP, fp
    //     0x7ac158: ldp             fp, lr, [SP], #0x10
    // 0x7ac15c: ret
    //     0x7ac15c: ret             
    // 0x7ac160: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x7ac160: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x7ac164: b               #0x7ac050
    // 0x7ac168: r9 = _selectionOverlay
    //     0x7ac168: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0x7ac16c: ldr             x9, [x9, #0x3e8]
    // 0x7ac170: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7ac170: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ hideToolbar(/* No info */) {
    // ** addr: 0x836510, size: 0x5c
    // 0x836510: EnterFrame
    //     0x836510: stp             fp, lr, [SP, #-0x10]!
    //     0x836514: mov             fp, SP
    // 0x836518: CheckStackOverflow
    //     0x836518: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83651c: cmp             SP, x16
    //     0x836520: b.ls            #0x836558
    // 0x836524: ldr             x0, [fp, #0x10]
    // 0x836528: LoadField: r1 = r0->field_13
    //     0x836528: ldur            w1, [x0, #0x13]
    // 0x83652c: DecompressPointer r1
    //     0x83652c: add             x1, x1, HEAP, lsl #32
    // 0x836530: r16 = Sentinel
    //     0x836530: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x836534: cmp             w1, w16
    // 0x836538: b.eq            #0x836560
    // 0x83653c: SaveReg r1
    //     0x83653c: str             x1, [SP, #-8]!
    // 0x836540: r0 = hideToolbar()
    //     0x836540: bl              #0x7ac270  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::hideToolbar
    // 0x836544: add             SP, SP, #8
    // 0x836548: r0 = Null
    //     0x836548: mov             x0, NULL
    // 0x83654c: LeaveFrame
    //     0x83654c: mov             SP, fp
    //     0x836550: ldp             fp, lr, [SP], #0x10
    // 0x836554: ret
    //     0x836554: ret             
    // 0x836558: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836558: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83655c: b               #0x836524
    // 0x836560: r9 = _selectionOverlay
    //     0x836560: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0x836564: ldr             x9, [x9, #0x3e8]
    // 0x836568: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x836568: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  get _ toolbarIsVisible(/* No info */) {
    // ** addr: 0x83656c, size: 0x50
    // 0x83656c: EnterFrame
    //     0x83656c: stp             fp, lr, [SP, #-0x10]!
    //     0x836570: mov             fp, SP
    // 0x836574: ldr             x1, [fp, #0x10]
    // 0x836578: LoadField: r2 = r1->field_13
    //     0x836578: ldur            w2, [x1, #0x13]
    // 0x83657c: DecompressPointer r2
    //     0x83657c: add             x2, x2, HEAP, lsl #32
    // 0x836580: r16 = Sentinel
    //     0x836580: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x836584: cmp             w2, w16
    // 0x836588: b.eq            #0x8365b0
    // 0x83658c: LoadField: r1 = r2->field_77
    //     0x83658c: ldur            w1, [x2, #0x77]
    // 0x836590: DecompressPointer r1
    //     0x836590: add             x1, x1, HEAP, lsl #32
    // 0x836594: cmp             w1, NULL
    // 0x836598: r16 = true
    //     0x836598: add             x16, NULL, #0x20  ; true
    // 0x83659c: r17 = false
    //     0x83659c: add             x17, NULL, #0x30  ; false
    // 0x8365a0: csel            x0, x16, x17, ne
    // 0x8365a4: LeaveFrame
    //     0x8365a4: mov             SP, fp
    //     0x8365a8: ldp             fp, lr, [SP], #0x10
    // 0x8365ac: ret
    //     0x8365ac: ret             
    // 0x8365b0: r9 = _selectionOverlay
    //     0x8365b0: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0x8365b4: ldr             x9, [x9, #0x3e8]
    // 0x8365b8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x8365b8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ hide(/* No info */) {
    // ** addr: 0x8365bc, size: 0x5c
    // 0x8365bc: EnterFrame
    //     0x8365bc: stp             fp, lr, [SP, #-0x10]!
    //     0x8365c0: mov             fp, SP
    // 0x8365c4: CheckStackOverflow
    //     0x8365c4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x8365c8: cmp             SP, x16
    //     0x8365cc: b.ls            #0x836604
    // 0x8365d0: ldr             x0, [fp, #0x10]
    // 0x8365d4: LoadField: r1 = r0->field_13
    //     0x8365d4: ldur            w1, [x0, #0x13]
    // 0x8365d8: DecompressPointer r1
    //     0x8365d8: add             x1, x1, HEAP, lsl #32
    // 0x8365dc: r16 = Sentinel
    //     0x8365dc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8365e0: cmp             w1, w16
    // 0x8365e4: b.eq            #0x83660c
    // 0x8365e8: SaveReg r1
    //     0x8365e8: str             x1, [SP, #-8]!
    // 0x8365ec: r0 = hide()
    //     0x8365ec: bl              #0x7ac174  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::hide
    // 0x8365f0: add             SP, SP, #8
    // 0x8365f4: r0 = Null
    //     0x8365f4: mov             x0, NULL
    // 0x8365f8: LeaveFrame
    //     0x8365f8: mov             SP, fp
    //     0x8365fc: ldp             fp, lr, [SP], #0x10
    // 0x836600: ret
    //     0x836600: ret             
    // 0x836604: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x836604: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x836608: b               #0x8365d0
    // 0x83660c: r9 = _selectionOverlay
    //     0x83660c: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0x836610: ldr             x9, [x9, #0x3e8]
    // 0x836614: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x836614: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ showToolbar(/* No info */) {
    // ** addr: 0xcce038, size: 0x6c
    // 0xcce038: EnterFrame
    //     0xcce038: stp             fp, lr, [SP, #-0x10]!
    //     0xcce03c: mov             fp, SP
    // 0xcce040: CheckStackOverflow
    //     0xcce040: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcce044: cmp             SP, x16
    //     0xcce048: b.ls            #0xcce090
    // 0xcce04c: ldr             x16, [fp, #0x10]
    // 0xcce050: SaveReg r16
    //     0xcce050: str             x16, [SP, #-8]!
    // 0xcce054: r0 = _updateSelectionOverlay()
    //     0xcce054: bl              #0x51efe0  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] ExtendedTextSelectionOverlay::_updateSelectionOverlay
    // 0xcce058: add             SP, SP, #8
    // 0xcce05c: ldr             x0, [fp, #0x10]
    // 0xcce060: LoadField: r1 = r0->field_13
    //     0xcce060: ldur            w1, [x0, #0x13]
    // 0xcce064: DecompressPointer r1
    //     0xcce064: add             x1, x1, HEAP, lsl #32
    // 0xcce068: r16 = Sentinel
    //     0xcce068: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xcce06c: cmp             w1, w16
    // 0xcce070: b.eq            #0xcce098
    // 0xcce074: SaveReg r1
    //     0xcce074: str             x1, [SP, #-8]!
    // 0xcce078: r0 = showToolbar()
    //     0xcce078: bl              #0xcce0a4  ; [package:extended_text_library/src/selection/extended_text_selection_overlay.dart] SelectionOverlay::showToolbar
    // 0xcce07c: add             SP, SP, #8
    // 0xcce080: r0 = Null
    //     0xcce080: mov             x0, NULL
    // 0xcce084: LeaveFrame
    //     0xcce084: mov             SP, fp
    //     0xcce088: ldp             fp, lr, [SP], #0x10
    // 0xcce08c: ret
    //     0xcce08c: ret             
    // 0xcce090: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcce090: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcce094: b               #0xcce04c
    // 0xcce098: r9 = _selectionOverlay
    //     0xcce098: add             x9, PP, #0x37, lsl #12  ; [pp+0x373e8] Field <ExtendedTextSelectionOverlay._selectionOverlay@500251836>: late final (offset: 0x14)
    //     0xcce09c: ldr             x9, [x9, #0x3e8]
    // 0xcce0a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xcce0a0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// lib: , url: package:extended_text_library/src/selection/painter.dart

// class id: 1048985, size: 0x8
class :: {
}

// class id: 4836, size: 0x24, field offset: 0x24
abstract class ExtendedRenderEditablePainter extends ChangeNotifier {
}

// class id: 4837, size: 0x38, field offset: 0x24
class TextHighlightPainter extends ExtendedRenderEditablePainter {

  set _ highlightedRange=(/* No info */) {
    // ** addr: 0x6de3cc, size: 0xa0
    // 0x6de3cc: EnterFrame
    //     0x6de3cc: stp             fp, lr, [SP, #-0x10]!
    //     0x6de3d0: mov             fp, SP
    // 0x6de3d4: CheckStackOverflow
    //     0x6de3d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de3d8: cmp             SP, x16
    //     0x6de3dc: b.ls            #0x6de464
    // 0x6de3e0: ldr             x1, [fp, #0x18]
    // 0x6de3e4: LoadField: r0 = r1->field_2b
    //     0x6de3e4: ldur            w0, [x1, #0x2b]
    // 0x6de3e8: DecompressPointer r0
    //     0x6de3e8: add             x0, x0, HEAP, lsl #32
    // 0x6de3ec: ldr             x2, [fp, #0x10]
    // 0x6de3f0: r3 = LoadClassIdInstr(r2)
    //     0x6de3f0: ldur            x3, [x2, #-1]
    //     0x6de3f4: ubfx            x3, x3, #0xc, #0x14
    // 0x6de3f8: stp             x0, x2, [SP, #-0x10]!
    // 0x6de3fc: mov             x0, x3
    // 0x6de400: mov             lr, x0
    // 0x6de404: ldr             lr, [x21, lr, lsl #3]
    // 0x6de408: blr             lr
    // 0x6de40c: add             SP, SP, #0x10
    // 0x6de410: tbnz            w0, #4, #0x6de424
    // 0x6de414: r0 = Null
    //     0x6de414: mov             x0, NULL
    // 0x6de418: LeaveFrame
    //     0x6de418: mov             SP, fp
    //     0x6de41c: ldp             fp, lr, [SP], #0x10
    // 0x6de420: ret
    //     0x6de420: ret             
    // 0x6de424: ldr             x1, [fp, #0x18]
    // 0x6de428: ldr             x0, [fp, #0x10]
    // 0x6de42c: StoreField: r1->field_2b = r0
    //     0x6de42c: stur            w0, [x1, #0x2b]
    //     0x6de430: ldurb           w16, [x1, #-1]
    //     0x6de434: ldurb           w17, [x0, #-1]
    //     0x6de438: and             x16, x17, x16, lsr #2
    //     0x6de43c: tst             x16, HEAP, lsr #32
    //     0x6de440: b.eq            #0x6de448
    //     0x6de444: bl              #0xd6826c
    // 0x6de448: SaveReg r1
    //     0x6de448: str             x1, [SP, #-8]!
    // 0x6de44c: r0 = notifyListeners()
    //     0x6de44c: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6de450: add             SP, SP, #8
    // 0x6de454: r0 = Null
    //     0x6de454: mov             x0, NULL
    // 0x6de458: LeaveFrame
    //     0x6de458: mov             SP, fp
    //     0x6de45c: ldp             fp, lr, [SP], #0x10
    // 0x6de460: ret
    //     0x6de460: ret             
    // 0x6de464: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de464: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de468: b               #0x6de3e0
  }
  set _ highlightColor=(/* No info */) {
    // ** addr: 0x6de5f4, size: 0xa0
    // 0x6de5f4: EnterFrame
    //     0x6de5f4: stp             fp, lr, [SP, #-0x10]!
    //     0x6de5f8: mov             fp, SP
    // 0x6de5fc: CheckStackOverflow
    //     0x6de5fc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6de600: cmp             SP, x16
    //     0x6de604: b.ls            #0x6de68c
    // 0x6de608: ldr             x1, [fp, #0x18]
    // 0x6de60c: LoadField: r0 = r1->field_27
    //     0x6de60c: ldur            w0, [x1, #0x27]
    // 0x6de610: DecompressPointer r0
    //     0x6de610: add             x0, x0, HEAP, lsl #32
    // 0x6de614: ldr             x2, [fp, #0x10]
    // 0x6de618: r3 = LoadClassIdInstr(r2)
    //     0x6de618: ldur            x3, [x2, #-1]
    //     0x6de61c: ubfx            x3, x3, #0xc, #0x14
    // 0x6de620: stp             x0, x2, [SP, #-0x10]!
    // 0x6de624: mov             x0, x3
    // 0x6de628: mov             lr, x0
    // 0x6de62c: ldr             lr, [x21, lr, lsl #3]
    // 0x6de630: blr             lr
    // 0x6de634: add             SP, SP, #0x10
    // 0x6de638: tbnz            w0, #4, #0x6de64c
    // 0x6de63c: r0 = Null
    //     0x6de63c: mov             x0, NULL
    // 0x6de640: LeaveFrame
    //     0x6de640: mov             SP, fp
    //     0x6de644: ldp             fp, lr, [SP], #0x10
    // 0x6de648: ret
    //     0x6de648: ret             
    // 0x6de64c: ldr             x1, [fp, #0x18]
    // 0x6de650: ldr             x0, [fp, #0x10]
    // 0x6de654: StoreField: r1->field_27 = r0
    //     0x6de654: stur            w0, [x1, #0x27]
    //     0x6de658: ldurb           w16, [x1, #-1]
    //     0x6de65c: ldurb           w17, [x0, #-1]
    //     0x6de660: and             x16, x17, x16, lsr #2
    //     0x6de664: tst             x16, HEAP, lsr #32
    //     0x6de668: b.eq            #0x6de670
    //     0x6de66c: bl              #0xd6826c
    // 0x6de670: SaveReg r1
    //     0x6de670: str             x1, [SP, #-8]!
    // 0x6de674: r0 = notifyListeners()
    //     0x6de674: bl              #0x500f60  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::notifyListeners
    // 0x6de678: add             SP, SP, #8
    // 0x6de67c: r0 = Null
    //     0x6de67c: mov             x0, NULL
    // 0x6de680: LeaveFrame
    //     0x6de680: mov             SP, fp
    //     0x6de684: ldp             fp, lr, [SP], #0x10
    // 0x6de688: ret
    //     0x6de688: ret             
    // 0x6de68c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6de68c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6de690: b               #0x6de608
  }
  _ TextHighlightPainter(/* No info */) {
    // ** addr: 0x6f35ec, size: 0xe0
    // 0x6f35ec: EnterFrame
    //     0x6f35ec: stp             fp, lr, [SP, #-0x10]!
    //     0x6f35f0: mov             fp, SP
    // 0x6f35f4: AllocStack(0x8)
    //     0x6f35f4: sub             SP, SP, #8
    // 0x6f35f8: r1 = Instance_BoxHeightStyle
    //     0x6f35f8: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f280] Obj!BoxHeightStyle@b66db1
    //     0x6f35fc: ldr             x1, [x1, #0x280]
    // 0x6f3600: r0 = Instance_BoxWidthStyle
    //     0x6f3600: add             x0, PP, #0x1f, lsl #12  ; [pp+0x1f288] Obj!BoxWidthStyle@b66d91
    //     0x6f3604: ldr             x0, [x0, #0x288]
    // 0x6f3608: CheckStackOverflow
    //     0x6f3608: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6f360c: cmp             SP, x16
    //     0x6f3610: b.ls            #0x6f36c4
    // 0x6f3614: ldr             x2, [fp, #0x10]
    // 0x6f3618: StoreField: r2->field_2f = r1
    //     0x6f3618: stur            w1, [x2, #0x2f]
    // 0x6f361c: StoreField: r2->field_33 = r0
    //     0x6f361c: stur            w0, [x2, #0x33]
    // 0x6f3620: r16 = 112
    //     0x6f3620: mov             x16, #0x70
    // 0x6f3624: stp             x16, NULL, [SP, #-0x10]!
    // 0x6f3628: r0 = ByteData()
    //     0x6f3628: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0x6f362c: add             SP, SP, #0x10
    // 0x6f3630: stur            x0, [fp, #-8]
    // 0x6f3634: r0 = Paint()
    //     0x6f3634: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0x6f3638: mov             x1, x0
    // 0x6f363c: ldur            x0, [fp, #-8]
    // 0x6f3640: StoreField: r1->field_7 = r0
    //     0x6f3640: stur            w0, [x1, #7]
    // 0x6f3644: mov             x0, x1
    // 0x6f3648: ldr             x1, [fp, #0x10]
    // 0x6f364c: StoreField: r1->field_23 = r0
    //     0x6f364c: stur            w0, [x1, #0x23]
    //     0x6f3650: ldurb           w16, [x1, #-1]
    //     0x6f3654: ldurb           w17, [x0, #-1]
    //     0x6f3658: and             x16, x17, x16, lsr #2
    //     0x6f365c: tst             x16, HEAP, lsr #32
    //     0x6f3660: b.eq            #0x6f3668
    //     0x6f3664: bl              #0xd6826c
    // 0x6f3668: r0 = 0
    //     0x6f3668: mov             x0, #0
    // 0x6f366c: StoreField: r1->field_7 = r0
    //     0x6f366c: stur            x0, [x1, #7]
    // 0x6f3670: StoreField: r1->field_13 = r0
    //     0x6f3670: stur            x0, [x1, #0x13]
    // 0x6f3674: StoreField: r1->field_1b = r0
    //     0x6f3674: stur            x0, [x1, #0x1b]
    // 0x6f3678: r0 = InitLateStaticField(0xac0) // [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::_emptyListeners
    //     0x6f3678: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x6f367c: ldr             x0, [x0, #0x1580]
    //     0x6f3680: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x6f3684: cmp             w0, w16
    //     0x6f3688: b.ne            #0x6f3694
    //     0x6f368c: ldr             x2, [PP, #0x44a0]  ; [pp+0x44a0] Field <ChangeNotifier._emptyListeners@171329750>: static late final (offset: 0xac0)
    //     0x6f3690: bl              #0xd67cdc
    // 0x6f3694: ldr             x1, [fp, #0x10]
    // 0x6f3698: StoreField: r1->field_f = r0
    //     0x6f3698: stur            w0, [x1, #0xf]
    //     0x6f369c: ldurb           w16, [x1, #-1]
    //     0x6f36a0: ldurb           w17, [x0, #-1]
    //     0x6f36a4: and             x16, x17, x16, lsr #2
    //     0x6f36a8: tst             x16, HEAP, lsr #32
    //     0x6f36ac: b.eq            #0x6f36b4
    //     0x6f36b0: bl              #0xd6826c
    // 0x6f36b4: r0 = Null
    //     0x6f36b4: mov             x0, NULL
    // 0x6f36b8: LeaveFrame
    //     0x6f36b8: mov             SP, fp
    //     0x6f36bc: ldp             fp, lr, [SP], #0x10
    // 0x6f36c0: ret
    //     0x6f36c0: ret             
    // 0x6f36c4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6f36c4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6f36c8: b               #0x6f3614
  }
  _ paint(/* No info */) {
    // ** addr: 0xc4f5b0, size: 0x58c
    // 0xc4f5b0: EnterFrame
    //     0xc4f5b0: stp             fp, lr, [SP, #-0x10]!
    //     0xc4f5b4: mov             fp, SP
    // 0xc4f5b8: AllocStack(0x70)
    //     0xc4f5b8: sub             SP, SP, #0x70
    // 0xc4f5bc: CheckStackOverflow
    //     0xc4f5bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f5c0: cmp             SP, x16
    //     0xc4f5c4: b.ls            #0xc4fab0
    // 0xc4f5c8: ldr             x0, [fp, #0x20]
    // 0xc4f5cc: LoadField: r1 = r0->field_2b
    //     0xc4f5cc: ldur            w1, [x0, #0x2b]
    // 0xc4f5d0: DecompressPointer r1
    //     0xc4f5d0: add             x1, x1, HEAP, lsl #32
    // 0xc4f5d4: LoadField: r2 = r0->field_27
    //     0xc4f5d4: ldur            w2, [x0, #0x27]
    // 0xc4f5d8: DecompressPointer r2
    //     0xc4f5d8: add             x2, x2, HEAP, lsl #32
    // 0xc4f5dc: cmp             w1, NULL
    // 0xc4f5e0: b.eq            #0xc4f604
    // 0xc4f5e4: cmp             w2, NULL
    // 0xc4f5e8: b.eq            #0xc4f604
    // 0xc4f5ec: LoadField: r3 = r1->field_7
    //     0xc4f5ec: ldur            x3, [x1, #7]
    // 0xc4f5f0: stur            x3, [fp, #-0x30]
    // 0xc4f5f4: LoadField: r4 = r1->field_f
    //     0xc4f5f4: ldur            x4, [x1, #0xf]
    // 0xc4f5f8: stur            x4, [fp, #-0x28]
    // 0xc4f5fc: cmp             x3, x4
    // 0xc4f600: b.ne            #0xc4f614
    // 0xc4f604: r0 = Null
    //     0xc4f604: mov             x0, NULL
    // 0xc4f608: LeaveFrame
    //     0xc4f608: mov             SP, fp
    //     0xc4f60c: ldp             fp, lr, [SP], #0x10
    // 0xc4f610: ret
    //     0xc4f610: ret             
    // 0xc4f614: LoadField: r1 = r0->field_23
    //     0xc4f614: ldur            w1, [x0, #0x23]
    // 0xc4f618: DecompressPointer r1
    //     0xc4f618: add             x1, x1, HEAP, lsl #32
    // 0xc4f61c: stur            x1, [fp, #-0x20]
    // 0xc4f620: LoadField: r0 = r2->field_7
    //     0xc4f620: ldur            x0, [x2, #7]
    // 0xc4f624: eor             x2, x0, #0xff000000
    // 0xc4f628: LoadField: r0 = r1->field_7
    //     0xc4f628: ldur            w0, [x1, #7]
    // 0xc4f62c: DecompressPointer r0
    //     0xc4f62c: add             x0, x0, HEAP, lsl #32
    // 0xc4f630: stur            x0, [fp, #-0x18]
    // 0xc4f634: LoadField: r5 = r0->field_13
    //     0xc4f634: ldur            w5, [x0, #0x13]
    // 0xc4f638: DecompressPointer r5
    //     0xc4f638: add             x5, x5, HEAP, lsl #32
    // 0xc4f63c: r6 = LoadInt32Instr(r5)
    //     0xc4f63c: sbfx            x6, x5, #1, #0x1f
    // 0xc4f640: cmp             x6, #7
    // 0xc4f644: b.le            #0xc4fa54
    // 0xc4f648: ldr             x5, [fp, #0x10]
    // 0xc4f64c: LoadField: r6 = r0->field_17
    //     0xc4f64c: ldur            w6, [x0, #0x17]
    // 0xc4f650: DecompressPointer r6
    //     0xc4f650: add             x6, x6, HEAP, lsl #32
    // 0xc4f654: LoadField: r7 = r0->field_1b
    //     0xc4f654: ldur            w7, [x0, #0x1b]
    // 0xc4f658: DecompressPointer r7
    //     0xc4f658: add             x7, x7, HEAP, lsl #32
    // 0xc4f65c: r8 = LoadInt32Instr(r7)
    //     0xc4f65c: sbfx            x8, x7, #1, #0x1f
    // 0xc4f660: add             x7, x8, #4
    // 0xc4f664: sxtw            x2, w2
    // 0xc4f668: LoadField: r8 = r6->field_7
    //     0xc4f668: ldur            x8, [x6, #7]
    // 0xc4f66c: str             w2, [x8, x7]
    // 0xc4f670: LoadField: r2 = r5->field_eb
    //     0xc4f670: ldur            w2, [x5, #0xeb]
    // 0xc4f674: DecompressPointer r2
    //     0xc4f674: add             x2, x2, HEAP, lsl #32
    // 0xc4f678: stur            x2, [fp, #-8]
    // 0xc4f67c: r0 = TextSelection()
    //     0xc4f67c: bl              #0x522394  ; AllocateTextSelectionStub -> TextSelection (size=0x30)
    // 0xc4f680: mov             x1, x0
    // 0xc4f684: ldur            x0, [fp, #-0x30]
    // 0xc4f688: StoreField: r1->field_17 = r0
    //     0xc4f688: stur            x0, [x1, #0x17]
    // 0xc4f68c: ldur            x2, [fp, #-0x28]
    // 0xc4f690: StoreField: r1->field_1f = r2
    //     0xc4f690: stur            x2, [x1, #0x1f]
    // 0xc4f694: r3 = Instance_TextAffinity
    //     0xc4f694: ldr             x3, [PP, #0x6088]  ; [pp+0x6088] Obj!TextAffinity@b66dd1
    // 0xc4f698: StoreField: r1->field_27 = r3
    //     0xc4f698: stur            w3, [x1, #0x27]
    // 0xc4f69c: r3 = false
    //     0xc4f69c: add             x3, NULL, #0x30  ; false
    // 0xc4f6a0: StoreField: r1->field_2b = r3
    //     0xc4f6a0: stur            w3, [x1, #0x2b]
    // 0xc4f6a4: cmp             x0, x2
    // 0xc4f6a8: b.ge            #0xc4f6b4
    // 0xc4f6ac: mov             x3, x0
    // 0xc4f6b0: b               #0xc4f6b8
    // 0xc4f6b4: mov             x3, x2
    // 0xc4f6b8: cmp             x0, x2
    // 0xc4f6bc: b.ge            #0xc4f6c4
    // 0xc4f6c0: mov             x0, x2
    // 0xc4f6c4: StoreField: r1->field_7 = r3
    //     0xc4f6c4: stur            x3, [x1, #7]
    // 0xc4f6c8: StoreField: r1->field_f = r0
    //     0xc4f6c8: stur            x0, [x1, #0xf]
    // 0xc4f6cc: ldur            x16, [fp, #-8]
    // 0xc4f6d0: stp             x1, x16, [SP, #-0x10]!
    // 0xc4f6d4: r0 = getBoxesForSelection()
    //     0xc4f6d4: bl              #0x51fabc  ; [package:flutter/src/painting/text_painter.dart] TextPainter::getBoxesForSelection
    // 0xc4f6d8: add             SP, SP, #0x10
    // 0xc4f6dc: mov             x1, x0
    // 0xc4f6e0: stur            x1, [fp, #-0x38]
    // 0xc4f6e4: LoadField: r2 = r1->field_7
    //     0xc4f6e4: ldur            w2, [x1, #7]
    // 0xc4f6e8: DecompressPointer r2
    //     0xc4f6e8: add             x2, x2, HEAP, lsl #32
    // 0xc4f6ec: stur            x2, [fp, #-0x10]
    // 0xc4f6f0: LoadField: r0 = r1->field_b
    //     0xc4f6f0: ldur            w0, [x1, #0xb]
    // 0xc4f6f4: DecompressPointer r0
    //     0xc4f6f4: add             x0, x0, HEAP, lsl #32
    // 0xc4f6f8: r3 = LoadInt32Instr(r0)
    //     0xc4f6f8: sbfx            x3, x0, #1, #0x1f
    // 0xc4f6fc: stur            x3, [fp, #-0x30]
    // 0xc4f700: r6 = 0
    //     0xc4f700: mov             x6, #0
    // 0xc4f704: ldur            x4, [fp, #-0x20]
    // 0xc4f708: ldur            x5, [fp, #-8]
    // 0xc4f70c: stur            x6, [fp, #-0x28]
    // 0xc4f710: CheckStackOverflow
    //     0xc4f710: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc4f714: cmp             SP, x16
    //     0xc4f718: b.ls            #0xc4fab8
    // 0xc4f71c: r0 = LoadClassIdInstr(r1)
    //     0xc4f71c: ldur            x0, [x1, #-1]
    //     0xc4f720: ubfx            x0, x0, #0xc, #0x14
    // 0xc4f724: SaveReg r1
    //     0xc4f724: str             x1, [SP, #-8]!
    // 0xc4f728: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0xc4f728: mov             x17, #0xb8ea
    //     0xc4f72c: add             lr, x0, x17
    //     0xc4f730: ldr             lr, [x21, lr, lsl #3]
    //     0xc4f734: blr             lr
    // 0xc4f738: add             SP, SP, #8
    // 0xc4f73c: r1 = LoadInt32Instr(r0)
    //     0xc4f73c: sbfx            x1, x0, #1, #0x1f
    //     0xc4f740: tbz             w0, #0, #0xc4f748
    //     0xc4f744: ldur            x1, [x0, #7]
    // 0xc4f748: ldur            x2, [fp, #-0x30]
    // 0xc4f74c: cmp             x2, x1
    // 0xc4f750: b.ne            #0xc4fa98
    // 0xc4f754: ldur            x3, [fp, #-0x38]
    // 0xc4f758: ldur            x4, [fp, #-0x28]
    // 0xc4f75c: cmp             x4, x1
    // 0xc4f760: b.lt            #0xc4f774
    // 0xc4f764: r0 = Null
    //     0xc4f764: mov             x0, NULL
    // 0xc4f768: LeaveFrame
    //     0xc4f768: mov             SP, fp
    //     0xc4f76c: ldp             fp, lr, [SP], #0x10
    // 0xc4f770: ret
    //     0xc4f770: ret             
    // 0xc4f774: r0 = BoxInt64Instr(r4)
    //     0xc4f774: sbfiz           x0, x4, #1, #0x1f
    //     0xc4f778: cmp             x4, x0, asr #1
    //     0xc4f77c: b.eq            #0xc4f788
    //     0xc4f780: bl              #0xd69bb8
    //     0xc4f784: stur            x4, [x0, #7]
    // 0xc4f788: r1 = LoadClassIdInstr(r3)
    //     0xc4f788: ldur            x1, [x3, #-1]
    //     0xc4f78c: ubfx            x1, x1, #0xc, #0x14
    // 0xc4f790: stp             x0, x3, [SP, #-0x10]!
    // 0xc4f794: mov             x0, x1
    // 0xc4f798: r0 = GDT[cid_x0 + 0xd175]()
    //     0xc4f798: mov             x17, #0xd175
    //     0xc4f79c: add             lr, x0, x17
    //     0xc4f7a0: ldr             lr, [x21, lr, lsl #3]
    //     0xc4f7a4: blr             lr
    // 0xc4f7a8: add             SP, SP, #0x10
    // 0xc4f7ac: mov             x3, x0
    // 0xc4f7b0: ldur            x0, [fp, #-0x28]
    // 0xc4f7b4: stur            x3, [fp, #-0x48]
    // 0xc4f7b8: add             x6, x0, #1
    // 0xc4f7bc: stur            x6, [fp, #-0x40]
    // 0xc4f7c0: cmp             w3, NULL
    // 0xc4f7c4: b.ne            #0xc4f7f8
    // 0xc4f7c8: mov             x0, x3
    // 0xc4f7cc: ldur            x2, [fp, #-0x10]
    // 0xc4f7d0: r1 = Null
    //     0xc4f7d0: mov             x1, NULL
    // 0xc4f7d4: cmp             w2, NULL
    // 0xc4f7d8: b.eq            #0xc4f7f8
    // 0xc4f7dc: LoadField: r4 = r2->field_17
    //     0xc4f7dc: ldur            w4, [x2, #0x17]
    // 0xc4f7e0: DecompressPointer r4
    //     0xc4f7e0: add             x4, x4, HEAP, lsl #32
    // 0xc4f7e4: r8 = X0
    //     0xc4f7e4: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0xc4f7e8: LoadField: r9 = r4->field_7
    //     0xc4f7e8: ldur            x9, [x4, #7]
    // 0xc4f7ec: r3 = Null
    //     0xc4f7ec: add             x3, PP, #0x56, lsl #12  ; [pp+0x56e58] Null
    //     0xc4f7f0: ldr             x3, [x3, #0xe58]
    // 0xc4f7f4: blr             x9
    // 0xc4f7f8: ldur            x1, [fp, #-0x20]
    // 0xc4f7fc: ldur            x0, [fp, #-0x48]
    // 0xc4f800: ldur            x2, [fp, #-8]
    // 0xc4f804: LoadField: d0 = r0->field_7
    //     0xc4f804: ldur            d0, [x0, #7]
    // 0xc4f808: stur            d0, [fp, #-0x68]
    // 0xc4f80c: LoadField: d1 = r0->field_f
    //     0xc4f80c: ldur            d1, [x0, #0xf]
    // 0xc4f810: stur            d1, [fp, #-0x60]
    // 0xc4f814: LoadField: d2 = r0->field_17
    //     0xc4f814: ldur            d2, [x0, #0x17]
    // 0xc4f818: stur            d2, [fp, #-0x58]
    // 0xc4f81c: LoadField: d3 = r0->field_1f
    //     0xc4f81c: ldur            d3, [x0, #0x1f]
    // 0xc4f820: stur            d3, [fp, #-0x50]
    // 0xc4f824: ldr             x16, [fp, #0x10]
    // 0xc4f828: SaveReg r16
    //     0xc4f828: str             x16, [SP, #-8]!
    // 0xc4f82c: r0 = paintOffset()
    //     0xc4f82c: bl              #0x522e98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::paintOffset
    // 0xc4f830: add             SP, SP, #8
    // 0xc4f834: LoadField: d0 = r0->field_7
    //     0xc4f834: ldur            d0, [x0, #7]
    // 0xc4f838: ldur            d1, [fp, #-0x68]
    // 0xc4f83c: fadd            d2, d1, d0
    // 0xc4f840: stur            d2, [fp, #-0x70]
    // 0xc4f844: LoadField: d1 = r0->field_f
    //     0xc4f844: ldur            d1, [x0, #0xf]
    // 0xc4f848: ldur            d3, [fp, #-0x60]
    // 0xc4f84c: fadd            d4, d3, d1
    // 0xc4f850: ldur            d3, [fp, #-0x58]
    // 0xc4f854: stur            d4, [fp, #-0x68]
    // 0xc4f858: fadd            d5, d3, d0
    // 0xc4f85c: ldur            d0, [fp, #-0x50]
    // 0xc4f860: stur            d5, [fp, #-0x60]
    // 0xc4f864: fadd            d3, d0, d1
    // 0xc4f868: stur            d3, [fp, #-0x58]
    // 0xc4f86c: r0 = Rect()
    //     0xc4f86c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc4f870: ldur            d0, [fp, #-0x70]
    // 0xc4f874: stur            x0, [fp, #-0x48]
    // 0xc4f878: StoreField: r0->field_7 = d0
    //     0xc4f878: stur            d0, [x0, #7]
    // 0xc4f87c: ldur            d0, [fp, #-0x68]
    // 0xc4f880: StoreField: r0->field_f = d0
    //     0xc4f880: stur            d0, [x0, #0xf]
    // 0xc4f884: ldur            d0, [fp, #-0x60]
    // 0xc4f888: StoreField: r0->field_17 = d0
    //     0xc4f888: stur            d0, [x0, #0x17]
    // 0xc4f88c: ldur            d0, [fp, #-0x58]
    // 0xc4f890: StoreField: r0->field_1f = d0
    //     0xc4f890: stur            d0, [x0, #0x1f]
    // 0xc4f894: ldur            x1, [fp, #-8]
    // 0xc4f898: LoadField: r2 = r1->field_7
    //     0xc4f898: ldur            w2, [x1, #7]
    // 0xc4f89c: DecompressPointer r2
    //     0xc4f89c: add             x2, x2, HEAP, lsl #32
    // 0xc4f8a0: cmp             w2, NULL
    // 0xc4f8a4: b.eq            #0xc4fac0
    // 0xc4f8a8: SaveReg r2
    //     0xc4f8a8: str             x2, [SP, #-8]!
    // 0xc4f8ac: r0 = width()
    //     0xc4f8ac: bl              #0x520ee4  ; [dart:ui] Paragraph::width
    // 0xc4f8b0: add             SP, SP, #8
    // 0xc4f8b4: stp             fp, lr, [SP, #-0x10]!
    // 0xc4f8b8: mov             fp, SP
    // 0xc4f8bc: CallRuntime_LibcCeil(double) -> double
    //     0xc4f8bc: and             SP, SP, #0xfffffffffffffff0
    //     0xc4f8c0: mov             sp, SP
    //     0xc4f8c4: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xc4f8c8: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f8cc: blr             x16
    //     0xc4f8d0: mov             x16, #8
    //     0xc4f8d4: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f8d8: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc4f8dc: sub             sp, x16, #1, lsl #12
    //     0xc4f8e0: mov             SP, fp
    //     0xc4f8e4: ldp             fp, lr, [SP], #0x10
    // 0xc4f8e8: ldur            x0, [fp, #-8]
    // 0xc4f8ec: stur            d0, [fp, #-0x50]
    // 0xc4f8f0: LoadField: r1 = r0->field_7
    //     0xc4f8f0: ldur            w1, [x0, #7]
    // 0xc4f8f4: DecompressPointer r1
    //     0xc4f8f4: add             x1, x1, HEAP, lsl #32
    // 0xc4f8f8: cmp             w1, NULL
    // 0xc4f8fc: b.eq            #0xc4fac4
    // 0xc4f900: SaveReg r1
    //     0xc4f900: str             x1, [SP, #-8]!
    // 0xc4f904: r0 = height()
    //     0xc4f904: bl              #0x51a4dc  ; [dart:ui] Paragraph::height
    // 0xc4f908: add             SP, SP, #8
    // 0xc4f90c: stp             fp, lr, [SP, #-0x10]!
    // 0xc4f910: mov             fp, SP
    // 0xc4f914: CallRuntime_LibcCeil(double) -> double
    //     0xc4f914: and             SP, SP, #0xfffffffffffffff0
    //     0xc4f918: mov             sp, SP
    //     0xc4f91c: ldr             x16, [THR, #0x568]  ; THR::LibcCeil
    //     0xc4f920: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f924: blr             x16
    //     0xc4f928: mov             x16, #8
    //     0xc4f92c: str             x16, [THR, #0xb8]  ; THR::vm_tag
    //     0xc4f930: ldr             x16, [THR, #0x78]  ; THR::saved_stack_limit
    //     0xc4f934: sub             sp, x16, #1, lsl #12
    //     0xc4f938: mov             SP, fp
    //     0xc4f93c: ldp             fp, lr, [SP], #0x10
    // 0xc4f940: mov             v2.16b, v0.16b
    // 0xc4f944: ldur            d0, [fp, #-0x50]
    // 0xc4f948: d1 = 0.000000
    //     0xc4f948: eor             v1.16b, v1.16b, v1.16b
    // 0xc4f94c: fadd            d3, d1, d0
    // 0xc4f950: stur            d3, [fp, #-0x58]
    // 0xc4f954: fadd            d0, d1, d2
    // 0xc4f958: stur            d0, [fp, #-0x50]
    // 0xc4f95c: r0 = Rect()
    //     0xc4f95c: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xc4f960: d0 = 0.000000
    //     0xc4f960: eor             v0.16b, v0.16b, v0.16b
    // 0xc4f964: StoreField: r0->field_7 = d0
    //     0xc4f964: stur            d0, [x0, #7]
    // 0xc4f968: StoreField: r0->field_f = d0
    //     0xc4f968: stur            d0, [x0, #0xf]
    // 0xc4f96c: ldur            d1, [fp, #-0x58]
    // 0xc4f970: StoreField: r0->field_17 = d1
    //     0xc4f970: stur            d1, [x0, #0x17]
    // 0xc4f974: ldur            d1, [fp, #-0x50]
    // 0xc4f978: StoreField: r0->field_1f = d1
    //     0xc4f978: stur            d1, [x0, #0x1f]
    // 0xc4f97c: ldur            x16, [fp, #-0x48]
    // 0xc4f980: stp             x0, x16, [SP, #-0x10]!
    // 0xc4f984: r0 = intersect()
    //     0xc4f984: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0xc4f988: add             SP, SP, #0x10
    // 0xc4f98c: LoadField: d0 = r0->field_7
    //     0xc4f98c: ldur            d0, [x0, #7]
    // 0xc4f990: LoadField: d1 = r0->field_f
    //     0xc4f990: ldur            d1, [x0, #0xf]
    // 0xc4f994: LoadField: d2 = r0->field_17
    //     0xc4f994: ldur            d2, [x0, #0x17]
    // 0xc4f998: LoadField: d3 = r0->field_1f
    //     0xc4f998: ldur            d3, [x0, #0x1f]
    // 0xc4f99c: ldur            x0, [fp, #-0x20]
    // 0xc4f9a0: LoadField: r1 = r0->field_b
    //     0xc4f9a0: ldur            w1, [x0, #0xb]
    // 0xc4f9a4: DecompressPointer r1
    //     0xc4f9a4: add             x1, x1, HEAP, lsl #32
    // 0xc4f9a8: r2 = inline_Allocate_Double()
    //     0xc4f9a8: ldp             x2, x3, [THR, #0x60]  ; THR::top
    //     0xc4f9ac: add             x2, x2, #0x10
    //     0xc4f9b0: cmp             x3, x2
    //     0xc4f9b4: b.ls            #0xc4fac8
    //     0xc4f9b8: str             x2, [THR, #0x60]  ; THR::top
    //     0xc4f9bc: sub             x2, x2, #0xf
    //     0xc4f9c0: mov             x3, #0xd108
    //     0xc4f9c4: movk            x3, #3, lsl #16
    //     0xc4f9c8: stur            x3, [x2, #-1]
    // 0xc4f9cc: StoreField: r2->field_7 = d0
    //     0xc4f9cc: stur            d0, [x2, #7]
    // 0xc4f9d0: r3 = inline_Allocate_Double()
    //     0xc4f9d0: ldp             x3, x4, [THR, #0x60]  ; THR::top
    //     0xc4f9d4: add             x3, x3, #0x10
    //     0xc4f9d8: cmp             x4, x3
    //     0xc4f9dc: b.ls            #0xc4faec
    //     0xc4f9e0: str             x3, [THR, #0x60]  ; THR::top
    //     0xc4f9e4: sub             x3, x3, #0xf
    //     0xc4f9e8: mov             x4, #0xd108
    //     0xc4f9ec: movk            x4, #3, lsl #16
    //     0xc4f9f0: stur            x4, [x3, #-1]
    // 0xc4f9f4: StoreField: r3->field_7 = d1
    //     0xc4f9f4: stur            d1, [x3, #7]
    // 0xc4f9f8: r4 = inline_Allocate_Double()
    //     0xc4f9f8: ldp             x4, x5, [THR, #0x60]  ; THR::top
    //     0xc4f9fc: add             x4, x4, #0x10
    //     0xc4fa00: cmp             x5, x4
    //     0xc4fa04: b.ls            #0xc4fb18
    //     0xc4fa08: str             x4, [THR, #0x60]  ; THR::top
    //     0xc4fa0c: sub             x4, x4, #0xf
    //     0xc4fa10: mov             x5, #0xd108
    //     0xc4fa14: movk            x5, #3, lsl #16
    //     0xc4fa18: stur            x5, [x4, #-1]
    // 0xc4fa1c: StoreField: r4->field_7 = d2
    //     0xc4fa1c: stur            d2, [x4, #7]
    // 0xc4fa20: ldr             x16, [fp, #0x18]
    // 0xc4fa24: stp             x2, x16, [SP, #-0x10]!
    // 0xc4fa28: stp             x4, x3, [SP, #-0x10]!
    // 0xc4fa2c: SaveReg d3
    //     0xc4fa2c: str             d3, [SP, #-8]!
    // 0xc4fa30: ldur            x16, [fp, #-0x18]
    // 0xc4fa34: stp             x16, x1, [SP, #-0x10]!
    // 0xc4fa38: r0 = _drawRect()
    //     0xc4fa38: bl              #0x65e768  ; [dart:ui] Canvas::_drawRect
    // 0xc4fa3c: add             SP, SP, #0x38
    // 0xc4fa40: ldur            x6, [fp, #-0x40]
    // 0xc4fa44: ldur            x1, [fp, #-0x38]
    // 0xc4fa48: ldur            x2, [fp, #-0x10]
    // 0xc4fa4c: ldur            x3, [fp, #-0x30]
    // 0xc4fa50: b               #0xc4f704
    // 0xc4fa54: sub             x0, x6, #4
    // 0xc4fa58: lsl             x1, x0, #1
    // 0xc4fa5c: stur            x1, [fp, #-8]
    // 0xc4fa60: r0 = RangeError()
    //     0xc4fa60: bl              #0x4b2ba0  ; AllocateRangeErrorStub -> RangeError (size=0x24)
    // 0xc4fa64: stur            x0, [fp, #-0x10]
    // 0xc4fa68: r16 = 8
    //     0xc4fa68: mov             x16, #8
    // 0xc4fa6c: stp             x16, x0, [SP, #-0x10]!
    // 0xc4fa70: ldur            x16, [fp, #-8]
    // 0xc4fa74: stp             x16, xzr, [SP, #-0x10]!
    // 0xc4fa78: r16 = "byteOffset"
    //     0xc4fa78: ldr             x16, [PP, #0x1f58]  ; [pp+0x1f58] "byteOffset"
    // 0xc4fa7c: SaveReg r16
    //     0xc4fa7c: str             x16, [SP, #-8]!
    // 0xc4fa80: r4 = const [0, 0x5, 0x5, 0x5, null]
    //     0xc4fa80: ldr             x4, [PP, #0xd18]  ; [pp+0xd18] List(5) [0, 0x5, 0x5, 0x5, Null]
    // 0xc4fa84: r0 = RangeError.range()
    //     0xc4fa84: bl              #0x4b284c  ; [dart:core] RangeError::RangeError.range
    // 0xc4fa88: add             SP, SP, #0x28
    // 0xc4fa8c: ldur            x0, [fp, #-0x10]
    // 0xc4fa90: r0 = Throw()
    //     0xc4fa90: bl              #0xd67e38  ; ThrowStub
    // 0xc4fa94: brk             #0
    // 0xc4fa98: ldur            x0, [fp, #-0x38]
    // 0xc4fa9c: r0 = ConcurrentModificationError()
    //     0xc4fa9c: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0xc4faa0: ldur            x3, [fp, #-0x38]
    // 0xc4faa4: StoreField: r0->field_b = r3
    //     0xc4faa4: stur            w3, [x0, #0xb]
    // 0xc4faa8: r0 = Throw()
    //     0xc4faa8: bl              #0xd67e38  ; ThrowStub
    // 0xc4faac: brk             #0
    // 0xc4fab0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4fab0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4fab4: b               #0xc4f5c8
    // 0xc4fab8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc4fab8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc4fabc: b               #0xc4f71c
    // 0xc4fac0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xc4fac0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xc4fac4: r0 = NullCastErrorSharedWithFPURegs()
    //     0xc4fac4: bl              #0xd6a02c  ; NullCastErrorSharedWithFPURegsStub
    // 0xc4fac8: stp             q2, q3, [SP, #-0x20]!
    // 0xc4facc: stp             q0, q1, [SP, #-0x20]!
    // 0xc4fad0: stp             x0, x1, [SP, #-0x10]!
    // 0xc4fad4: r0 = AllocateDouble()
    //     0xc4fad4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc4fad8: mov             x2, x0
    // 0xc4fadc: ldp             x0, x1, [SP], #0x10
    // 0xc4fae0: ldp             q0, q1, [SP], #0x20
    // 0xc4fae4: ldp             q2, q3, [SP], #0x20
    // 0xc4fae8: b               #0xc4f9cc
    // 0xc4faec: stp             q2, q3, [SP, #-0x20]!
    // 0xc4faf0: SaveReg d1
    //     0xc4faf0: str             q1, [SP, #-0x10]!
    // 0xc4faf4: stp             x1, x2, [SP, #-0x10]!
    // 0xc4faf8: SaveReg r0
    //     0xc4faf8: str             x0, [SP, #-8]!
    // 0xc4fafc: r0 = AllocateDouble()
    //     0xc4fafc: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc4fb00: mov             x3, x0
    // 0xc4fb04: RestoreReg r0
    //     0xc4fb04: ldr             x0, [SP], #8
    // 0xc4fb08: ldp             x1, x2, [SP], #0x10
    // 0xc4fb0c: RestoreReg d1
    //     0xc4fb0c: ldr             q1, [SP], #0x10
    // 0xc4fb10: ldp             q2, q3, [SP], #0x20
    // 0xc4fb14: b               #0xc4f9f4
    // 0xc4fb18: stp             q2, q3, [SP, #-0x20]!
    // 0xc4fb1c: stp             x2, x3, [SP, #-0x10]!
    // 0xc4fb20: stp             x0, x1, [SP, #-0x10]!
    // 0xc4fb24: r0 = AllocateDouble()
    //     0xc4fb24: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xc4fb28: mov             x4, x0
    // 0xc4fb2c: ldp             x0, x1, [SP], #0x10
    // 0xc4fb30: ldp             x2, x3, [SP], #0x10
    // 0xc4fb34: ldp             q2, q3, [SP], #0x20
    // 0xc4fb38: b               #0xc4fa1c
  }
  _ shouldRepaint(/* No info */) {
    // ** addr: 0xc50314, size: 0xdc
    // 0xc50314: EnterFrame
    //     0xc50314: stp             fp, lr, [SP, #-0x10]!
    //     0xc50318: mov             fp, SP
    // 0xc5031c: CheckStackOverflow
    //     0xc5031c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xc50320: cmp             SP, x16
    //     0xc50324: b.ls            #0xc503e8
    // 0xc50328: ldr             x2, [fp, #0x18]
    // 0xc5032c: ldr             x1, [fp, #0x10]
    // 0xc50330: cmp             w1, w2
    // 0xc50334: b.ne            #0xc50348
    // 0xc50338: r0 = false
    //     0xc50338: add             x0, NULL, #0x30  ; false
    // 0xc5033c: LeaveFrame
    //     0xc5033c: mov             SP, fp
    //     0xc50340: ldp             fp, lr, [SP], #0x10
    // 0xc50344: ret
    //     0xc50344: ret             
    // 0xc50348: r0 = LoadClassIdInstr(r1)
    //     0xc50348: ldur            x0, [x1, #-1]
    //     0xc5034c: ubfx            x0, x0, #0xc, #0x14
    // 0xc50350: lsl             x0, x0, #1
    // 0xc50354: r17 = 9674
    //     0xc50354: mov             x17, #0x25ca
    // 0xc50358: cmp             w0, w17
    // 0xc5035c: b.ne            #0xc503d0
    // 0xc50360: LoadField: r0 = r1->field_27
    //     0xc50360: ldur            w0, [x1, #0x27]
    // 0xc50364: DecompressPointer r0
    //     0xc50364: add             x0, x0, HEAP, lsl #32
    // 0xc50368: LoadField: r3 = r2->field_27
    //     0xc50368: ldur            w3, [x2, #0x27]
    // 0xc5036c: DecompressPointer r3
    //     0xc5036c: add             x3, x3, HEAP, lsl #32
    // 0xc50370: r4 = LoadClassIdInstr(r0)
    //     0xc50370: ldur            x4, [x0, #-1]
    //     0xc50374: ubfx            x4, x4, #0xc, #0x14
    // 0xc50378: stp             x3, x0, [SP, #-0x10]!
    // 0xc5037c: mov             x0, x4
    // 0xc50380: mov             lr, x0
    // 0xc50384: ldr             lr, [x21, lr, lsl #3]
    // 0xc50388: blr             lr
    // 0xc5038c: add             SP, SP, #0x10
    // 0xc50390: tbnz            w0, #4, #0xc503d0
    // 0xc50394: ldr             x1, [fp, #0x18]
    // 0xc50398: ldr             x0, [fp, #0x10]
    // 0xc5039c: LoadField: r2 = r0->field_2b
    //     0xc5039c: ldur            w2, [x0, #0x2b]
    // 0xc503a0: DecompressPointer r2
    //     0xc503a0: add             x2, x2, HEAP, lsl #32
    // 0xc503a4: LoadField: r0 = r1->field_2b
    //     0xc503a4: ldur            w0, [x1, #0x2b]
    // 0xc503a8: DecompressPointer r0
    //     0xc503a8: add             x0, x0, HEAP, lsl #32
    // 0xc503ac: r1 = LoadClassIdInstr(r2)
    //     0xc503ac: ldur            x1, [x2, #-1]
    //     0xc503b0: ubfx            x1, x1, #0xc, #0x14
    // 0xc503b4: stp             x0, x2, [SP, #-0x10]!
    // 0xc503b8: mov             x0, x1
    // 0xc503bc: mov             lr, x0
    // 0xc503c0: ldr             lr, [x21, lr, lsl #3]
    // 0xc503c4: blr             lr
    // 0xc503c8: add             SP, SP, #0x10
    // 0xc503cc: tbz             w0, #4, #0xc503d8
    // 0xc503d0: r0 = true
    //     0xc503d0: add             x0, NULL, #0x20  ; true
    // 0xc503d4: b               #0xc503dc
    // 0xc503d8: r0 = false
    //     0xc503d8: add             x0, NULL, #0x30  ; false
    // 0xc503dc: LeaveFrame
    //     0xc503dc: mov             SP, fp
    //     0xc503e0: ldp             fp, lr, [SP], #0x10
    // 0xc503e4: ret
    //     0xc503e4: ret             
    // 0xc503e8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xc503e8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xc503ec: b               #0xc50328
  }
}

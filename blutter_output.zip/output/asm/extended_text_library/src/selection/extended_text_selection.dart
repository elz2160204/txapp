// lib: , url: package:extended_text_library/src/selection/extended_text_selection.dart

// class id: 1048983, size: 0x8
class :: {
}

// class id: 4433, size: 0x18, field offset: 0x8
abstract class ExtendedTextSelectionGestureDetectorBuilder extends Object {

  _ buildGestureDetector(/* No info */) {
    // ** addr: 0x83959c, size: 0x368
    // 0x83959c: EnterFrame
    //     0x83959c: stp             fp, lr, [SP, #-0x10]!
    //     0x8395a0: mov             fp, SP
    // 0x8395a4: AllocStack(0x78)
    //     0x8395a4: sub             SP, SP, #0x78
    // 0x8395a8: r1 = 1
    //     0x8395a8: mov             x1, #1
    // 0x8395ac: r0 = AllocateContext()
    //     0x8395ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8395b0: mov             x1, x0
    // 0x8395b4: ldr             x0, [fp, #0x18]
    // 0x8395b8: stur            x1, [fp, #-0x10]
    // 0x8395bc: StoreField: r1->field_f = r0
    //     0x8395bc: stur            w0, [x1, #0xf]
    // 0x8395c0: LoadField: r2 = r0->field_7
    //     0x8395c0: ldur            w2, [x0, #7]
    // 0x8395c4: DecompressPointer r2
    //     0x8395c4: add             x2, x2, HEAP, lsl #32
    // 0x8395c8: LoadField: r3 = r2->field_37
    //     0x8395c8: ldur            w3, [x2, #0x37]
    // 0x8395cc: DecompressPointer r3
    //     0x8395cc: add             x3, x3, HEAP, lsl #32
    // 0x8395d0: r16 = Sentinel
    //     0x8395d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x8395d4: cmp             w3, w16
    // 0x8395d8: b.eq            #0x8398f8
    // 0x8395dc: stur            x3, [fp, #-8]
    // 0x8395e0: tbnz            w3, #4, #0x839610
    // 0x8395e4: r1 = 1
    //     0x8395e4: mov             x1, #1
    // 0x8395e8: r0 = AllocateContext()
    //     0x8395e8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8395ec: mov             x1, x0
    // 0x8395f0: ldr             x0, [fp, #0x18]
    // 0x8395f4: StoreField: r1->field_f = r0
    //     0x8395f4: stur            w0, [x1, #0xf]
    // 0x8395f8: mov             x2, x1
    // 0x8395fc: r1 = Function 'onForcePressStart':.
    //     0x8395fc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd48] AnonymousClosure: (0x83ca8c), in [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onForcePressStart (0x83cad8)
    //     0x839600: ldr             x1, [x1, #0xd48]
    // 0x839604: r0 = AllocateClosure()
    //     0x839604: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839608: mov             x1, x0
    // 0x83960c: b               #0x839614
    // 0x839610: r1 = Null
    //     0x839610: mov             x1, NULL
    // 0x839614: ldur            x0, [fp, #-8]
    // 0x839618: stur            x1, [fp, #-0x18]
    // 0x83961c: tbnz            w0, #4, #0x839650
    // 0x839620: ldr             x0, [fp, #0x18]
    // 0x839624: r1 = 1
    //     0x839624: mov             x1, #1
    // 0x839628: r0 = AllocateContext()
    //     0x839628: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83962c: mov             x1, x0
    // 0x839630: ldr             x0, [fp, #0x18]
    // 0x839634: StoreField: r1->field_f = r0
    //     0x839634: stur            w0, [x1, #0xf]
    // 0x839638: mov             x2, x1
    // 0x83963c: r1 = Function 'onForcePressEnd':.
    //     0x83963c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd50] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x839640: ldr             x1, [x1, #0xd50]
    // 0x839644: r0 = AllocateClosure()
    //     0x839644: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839648: mov             x3, x0
    // 0x83964c: b               #0x839654
    // 0x839650: r3 = Null
    //     0x839650: mov             x3, NULL
    // 0x839654: ldr             x0, [fp, #0x18]
    // 0x839658: ldr             x2, [fp, #0x10]
    // 0x83965c: ldur            x1, [fp, #-0x18]
    // 0x839660: stur            x3, [fp, #-8]
    // 0x839664: r1 = 1
    //     0x839664: mov             x1, #1
    // 0x839668: r0 = AllocateContext()
    //     0x839668: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83966c: mov             x1, x0
    // 0x839670: ldr             x0, [fp, #0x18]
    // 0x839674: stur            x1, [fp, #-0x20]
    // 0x839678: StoreField: r1->field_f = r0
    //     0x839678: stur            w0, [x1, #0xf]
    // 0x83967c: r1 = 1
    //     0x83967c: mov             x1, #1
    // 0x839680: r0 = AllocateContext()
    //     0x839680: bl              #0xd68aa4  ; AllocateContextStub
    // 0x839684: mov             x1, x0
    // 0x839688: ldr             x0, [fp, #0x18]
    // 0x83968c: stur            x1, [fp, #-0x28]
    // 0x839690: StoreField: r1->field_f = r0
    //     0x839690: stur            w0, [x1, #0xf]
    // 0x839694: r1 = 1
    //     0x839694: mov             x1, #1
    // 0x839698: r0 = AllocateContext()
    //     0x839698: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83969c: mov             x1, x0
    // 0x8396a0: ldr             x0, [fp, #0x18]
    // 0x8396a4: stur            x1, [fp, #-0x30]
    // 0x8396a8: StoreField: r1->field_f = r0
    //     0x8396a8: stur            w0, [x1, #0xf]
    // 0x8396ac: r1 = 1
    //     0x8396ac: mov             x1, #1
    // 0x8396b0: r0 = AllocateContext()
    //     0x8396b0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8396b4: mov             x1, x0
    // 0x8396b8: ldr             x0, [fp, #0x18]
    // 0x8396bc: stur            x1, [fp, #-0x38]
    // 0x8396c0: StoreField: r1->field_f = r0
    //     0x8396c0: stur            w0, [x1, #0xf]
    // 0x8396c4: r1 = 1
    //     0x8396c4: mov             x1, #1
    // 0x8396c8: r0 = AllocateContext()
    //     0x8396c8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8396cc: mov             x1, x0
    // 0x8396d0: ldr             x0, [fp, #0x18]
    // 0x8396d4: stur            x1, [fp, #-0x40]
    // 0x8396d8: StoreField: r1->field_f = r0
    //     0x8396d8: stur            w0, [x1, #0xf]
    // 0x8396dc: r1 = 1
    //     0x8396dc: mov             x1, #1
    // 0x8396e0: r0 = AllocateContext()
    //     0x8396e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8396e4: mov             x1, x0
    // 0x8396e8: ldr             x0, [fp, #0x18]
    // 0x8396ec: stur            x1, [fp, #-0x48]
    // 0x8396f0: StoreField: r1->field_f = r0
    //     0x8396f0: stur            w0, [x1, #0xf]
    // 0x8396f4: r1 = 1
    //     0x8396f4: mov             x1, #1
    // 0x8396f8: r0 = AllocateContext()
    //     0x8396f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x8396fc: mov             x1, x0
    // 0x839700: ldr             x0, [fp, #0x18]
    // 0x839704: stur            x1, [fp, #-0x50]
    // 0x839708: StoreField: r1->field_f = r0
    //     0x839708: stur            w0, [x1, #0xf]
    // 0x83970c: r1 = 1
    //     0x83970c: mov             x1, #1
    // 0x839710: r0 = AllocateContext()
    //     0x839710: bl              #0xd68aa4  ; AllocateContextStub
    // 0x839714: mov             x1, x0
    // 0x839718: ldr             x0, [fp, #0x18]
    // 0x83971c: stur            x1, [fp, #-0x58]
    // 0x839720: StoreField: r1->field_f = r0
    //     0x839720: stur            w0, [x1, #0xf]
    // 0x839724: r1 = 1
    //     0x839724: mov             x1, #1
    // 0x839728: r0 = AllocateContext()
    //     0x839728: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83972c: mov             x1, x0
    // 0x839730: ldr             x0, [fp, #0x18]
    // 0x839734: stur            x1, [fp, #-0x60]
    // 0x839738: StoreField: r1->field_f = r0
    //     0x839738: stur            w0, [x1, #0xf]
    // 0x83973c: r1 = 1
    //     0x83973c: mov             x1, #1
    // 0x839740: r0 = AllocateContext()
    //     0x839740: bl              #0xd68aa4  ; AllocateContextStub
    // 0x839744: mov             x1, x0
    // 0x839748: ldr             x0, [fp, #0x18]
    // 0x83974c: stur            x1, [fp, #-0x68]
    // 0x839750: StoreField: r1->field_f = r0
    //     0x839750: stur            w0, [x1, #0xf]
    // 0x839754: r1 = 1
    //     0x839754: mov             x1, #1
    // 0x839758: r0 = AllocateContext()
    //     0x839758: bl              #0xd68aa4  ; AllocateContextStub
    // 0x83975c: mov             x3, x0
    // 0x839760: ldr             x0, [fp, #0x18]
    // 0x839764: stur            x3, [fp, #-0x70]
    // 0x839768: StoreField: r3->field_f = r0
    //     0x839768: stur            w0, [x3, #0xf]
    // 0x83976c: ldur            x2, [fp, #-0x10]
    // 0x839770: r1 = Function 'onTapDown':.
    //     0x839770: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd58] AnonymousClosure: (0x83c960), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onTapDown (0x83c9ac)
    //     0x839774: ldr             x1, [x1, #0xd58]
    // 0x839778: r0 = AllocateClosure()
    //     0x839778: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83977c: stur            x0, [fp, #-0x10]
    // 0x839780: r0 = TextSelectionGestureDetector()
    //     0x839780: bl              #0x839904  ; AllocateTextSelectionGestureDetectorStub -> TextSelectionGestureDetector (size=0x4c)
    // 0x839784: mov             x3, x0
    // 0x839788: ldur            x0, [fp, #-0x10]
    // 0x83978c: stur            x3, [fp, #-0x78]
    // 0x839790: StoreField: r3->field_b = r0
    //     0x839790: stur            w0, [x3, #0xb]
    // 0x839794: ldur            x0, [fp, #-0x18]
    // 0x839798: StoreField: r3->field_f = r0
    //     0x839798: stur            w0, [x3, #0xf]
    // 0x83979c: ldur            x0, [fp, #-8]
    // 0x8397a0: StoreField: r3->field_13 = r0
    //     0x8397a0: stur            w0, [x3, #0x13]
    // 0x8397a4: ldur            x2, [fp, #-0x20]
    // 0x8397a8: r1 = Function 'onSecondaryTap':.
    //     0x8397a8: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd60] AnonymousClosure: (0x83c700), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onSecondaryTap (0x83c748)
    //     0x8397ac: ldr             x1, [x1, #0xd60]
    // 0x8397b0: r0 = AllocateClosure()
    //     0x8397b0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8397b4: mov             x1, x0
    // 0x8397b8: ldur            x0, [fp, #-0x78]
    // 0x8397bc: StoreField: r0->field_17 = r1
    //     0x8397bc: stur            w1, [x0, #0x17]
    // 0x8397c0: ldur            x2, [fp, #-0x28]
    // 0x8397c4: r1 = Function 'onSecondaryTapDown':.
    //     0x8397c4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd68] AnonymousClosure: (0x83c5ec), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onSecondaryTapDown (0x83c638)
    //     0x8397c8: ldr             x1, [x1, #0xd68]
    // 0x8397cc: r0 = AllocateClosure()
    //     0x8397cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8397d0: mov             x1, x0
    // 0x8397d4: ldur            x0, [fp, #-0x78]
    // 0x8397d8: StoreField: r0->field_1b = r1
    //     0x8397d8: stur            w1, [x0, #0x1b]
    // 0x8397dc: ldur            x2, [fp, #-0x30]
    // 0x8397e0: r1 = Function 'onSingleTapUp':.
    //     0x8397e0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd70] AnonymousClosure: (0x83c208), in [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onSingleTapUp (0x83c254)
    //     0x8397e4: ldr             x1, [x1, #0xd70]
    // 0x8397e8: r0 = AllocateClosure()
    //     0x8397e8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8397ec: mov             x1, x0
    // 0x8397f0: ldur            x0, [fp, #-0x78]
    // 0x8397f4: StoreField: r0->field_1f = r1
    //     0x8397f4: stur            w1, [x0, #0x1f]
    // 0x8397f8: ldur            x2, [fp, #-0x38]
    // 0x8397fc: r1 = Function 'onSingleTapCancel':.
    //     0x8397fc: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd78] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x839800: ldr             x1, [x1, #0xd78]
    // 0x839804: r0 = AllocateClosure()
    //     0x839804: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839808: mov             x1, x0
    // 0x83980c: ldur            x0, [fp, #-0x78]
    // 0x839810: StoreField: r0->field_23 = r1
    //     0x839810: stur            w1, [x0, #0x23]
    // 0x839814: ldur            x2, [fp, #-0x40]
    // 0x839818: r1 = Function 'onSingleLongTapStart':.
    //     0x839818: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd80] AnonymousClosure: (0x83bda4), in [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onSingleLongTapStart (0x83bdf0)
    //     0x83981c: ldr             x1, [x1, #0xd80]
    // 0x839820: r0 = AllocateClosure()
    //     0x839820: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839824: mov             x1, x0
    // 0x839828: ldur            x0, [fp, #-0x78]
    // 0x83982c: StoreField: r0->field_27 = r1
    //     0x83982c: stur            w1, [x0, #0x27]
    // 0x839830: ldur            x2, [fp, #-0x48]
    // 0x839834: r1 = Function 'onSingleLongTapMoveUpdate':.
    //     0x839834: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd88] AnonymousClosure: (0x83bbfc), in [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onSingleLongTapMoveUpdate (0x83bc48)
    //     0x839838: ldr             x1, [x1, #0xd88]
    // 0x83983c: r0 = AllocateClosure()
    //     0x83983c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839840: mov             x1, x0
    // 0x839844: ldur            x0, [fp, #-0x78]
    // 0x839848: StoreField: r0->field_2b = r1
    //     0x839848: stur            w1, [x0, #0x2b]
    // 0x83984c: ldur            x2, [fp, #-0x50]
    // 0x839850: r1 = Function 'onSingleLongTapEnd':.
    //     0x839850: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd90] AnonymousClosure: (0x83bb4c), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onSingleLongTapEnd (0x83bb98)
    //     0x839854: ldr             x1, [x1, #0xd90]
    // 0x839858: r0 = AllocateClosure()
    //     0x839858: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x83985c: mov             x1, x0
    // 0x839860: ldur            x0, [fp, #-0x78]
    // 0x839864: StoreField: r0->field_2f = r1
    //     0x839864: stur            w1, [x0, #0x2f]
    // 0x839868: ldur            x2, [fp, #-0x58]
    // 0x83986c: r1 = Function 'onDoubleTapDown':.
    //     0x83986c: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bd98] AnonymousClosure: (0x83a210), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onDoubleTapDown (0x83a25c)
    //     0x839870: ldr             x1, [x1, #0xd98]
    // 0x839874: r0 = AllocateClosure()
    //     0x839874: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839878: mov             x1, x0
    // 0x83987c: ldur            x0, [fp, #-0x78]
    // 0x839880: StoreField: r0->field_33 = r1
    //     0x839880: stur            w1, [x0, #0x33]
    // 0x839884: ldur            x2, [fp, #-0x60]
    // 0x839888: r1 = Function 'onDragSelectionStart':.
    //     0x839888: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bda0] AnonymousClosure: (0x83a0d8), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onDragSelectionStart (0x83a124)
    //     0x83988c: ldr             x1, [x1, #0xda0]
    // 0x839890: r0 = AllocateClosure()
    //     0x839890: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x839894: mov             x1, x0
    // 0x839898: ldur            x0, [fp, #-0x78]
    // 0x83989c: StoreField: r0->field_37 = r1
    //     0x83989c: stur            w1, [x0, #0x37]
    // 0x8398a0: ldur            x2, [fp, #-0x68]
    // 0x8398a4: r1 = Function 'onDragSelectionUpdate':.
    //     0x8398a4: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bda8] AnonymousClosure: (0x839930), in [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onDragSelectionUpdate (0x839984)
    //     0x8398a8: ldr             x1, [x1, #0xda8]
    // 0x8398ac: r0 = AllocateClosure()
    //     0x8398ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8398b0: mov             x1, x0
    // 0x8398b4: ldur            x0, [fp, #-0x78]
    // 0x8398b8: StoreField: r0->field_3b = r1
    //     0x8398b8: stur            w1, [x0, #0x3b]
    // 0x8398bc: ldur            x2, [fp, #-0x70]
    // 0x8398c0: r1 = Function 'onDragSelectionEnd':.
    //     0x8398c0: add             x1, PP, #0x4b, lsl #12  ; [pp+0x4bdb0] Function: [dart:ui] Shader::Shader._ (0xd614dc)
    //     0x8398c4: ldr             x1, [x1, #0xdb0]
    // 0x8398c8: r0 = AllocateClosure()
    //     0x8398c8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8398cc: mov             x1, x0
    // 0x8398d0: ldur            x0, [fp, #-0x78]
    // 0x8398d4: StoreField: r0->field_3f = r1
    //     0x8398d4: stur            w1, [x0, #0x3f]
    // 0x8398d8: r1 = Instance_HitTestBehavior
    //     0x8398d8: add             x1, PP, #0x1c, lsl #12  ; [pp+0x1ced0] Obj!HitTestBehavior@b64911
    //     0x8398dc: ldr             x1, [x1, #0xed0]
    // 0x8398e0: StoreField: r0->field_43 = r1
    //     0x8398e0: stur            w1, [x0, #0x43]
    // 0x8398e4: ldr             x1, [fp, #0x10]
    // 0x8398e8: StoreField: r0->field_47 = r1
    //     0x8398e8: stur            w1, [x0, #0x47]
    // 0x8398ec: LeaveFrame
    //     0x8398ec: mov             SP, fp
    //     0x8398f0: ldp             fp, lr, [SP], #0x10
    // 0x8398f4: ret
    //     0x8398f4: ret             
    // 0x8398f8: r9 = forcePressEnabled
    //     0x8398f8: add             x9, PP, #0x4b, lsl #12  ; [pp+0x4bdb8] Field <ExtendedTextFieldState.forcePressEnabled>: late (offset: 0x38)
    //     0x8398fc: ldr             x9, [x9, #0xdb8]
    // 0x839900: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x839900: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] void onDragSelectionUpdate(dynamic, DragStartDetails, DragUpdateDetails) {
    // ** addr: 0x839930, size: 0x54
    // 0x839930: EnterFrame
    //     0x839930: stp             fp, lr, [SP, #-0x10]!
    //     0x839934: mov             fp, SP
    // 0x839938: ldr             x0, [fp, #0x20]
    // 0x83993c: LoadField: r1 = r0->field_17
    //     0x83993c: ldur            w1, [x0, #0x17]
    // 0x839940: DecompressPointer r1
    //     0x839940: add             x1, x1, HEAP, lsl #32
    // 0x839944: CheckStackOverflow
    //     0x839944: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x839948: cmp             SP, x16
    //     0x83994c: b.ls            #0x83997c
    // 0x839950: LoadField: r0 = r1->field_f
    //     0x839950: ldur            w0, [x1, #0xf]
    // 0x839954: DecompressPointer r0
    //     0x839954: add             x0, x0, HEAP, lsl #32
    // 0x839958: ldr             x16, [fp, #0x18]
    // 0x83995c: stp             x16, x0, [SP, #-0x10]!
    // 0x839960: ldr             x16, [fp, #0x10]
    // 0x839964: SaveReg r16
    //     0x839964: str             x16, [SP, #-8]!
    // 0x839968: r0 = onDragSelectionUpdate()
    //     0x839968: bl              #0x839984  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onDragSelectionUpdate
    // 0x83996c: add             SP, SP, #0x18
    // 0x839970: LeaveFrame
    //     0x839970: mov             SP, fp
    //     0x839974: ldp             fp, lr, [SP], #0x10
    // 0x839978: ret
    //     0x839978: ret             
    // 0x83997c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83997c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839980: b               #0x839950
  }
  _ onDragSelectionUpdate(/* No info */) {
    // ** addr: 0x839984, size: 0xac
    // 0x839984: EnterFrame
    //     0x839984: stp             fp, lr, [SP, #-0x10]!
    //     0x839988: mov             fp, SP
    // 0x83998c: CheckStackOverflow
    //     0x83998c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x839990: cmp             SP, x16
    //     0x839994: b.ls            #0x839a28
    // 0x839998: ldr             x0, [fp, #0x20]
    // 0x83999c: LoadField: r1 = r0->field_7
    //     0x83999c: ldur            w1, [x0, #7]
    // 0x8399a0: DecompressPointer r1
    //     0x8399a0: add             x1, x1, HEAP, lsl #32
    // 0x8399a4: SaveReg r1
    //     0x8399a4: str             x1, [SP, #-8]!
    // 0x8399a8: r0 = selectionEnabled()
    //     0x8399a8: bl              #0x83a0a4  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::selectionEnabled
    // 0x8399ac: add             SP, SP, #8
    // 0x8399b0: tbz             w0, #4, #0x8399c4
    // 0x8399b4: r0 = Null
    //     0x8399b4: mov             x0, NULL
    // 0x8399b8: LeaveFrame
    //     0x8399b8: mov             SP, fp
    //     0x8399bc: ldp             fp, lr, [SP], #0x10
    // 0x8399c0: ret
    //     0x8399c0: ret             
    // 0x8399c4: ldr             x1, [fp, #0x18]
    // 0x8399c8: ldr             x0, [fp, #0x10]
    // 0x8399cc: ldr             x16, [fp, #0x20]
    // 0x8399d0: SaveReg r16
    //     0x8399d0: str             x16, [SP, #-8]!
    // 0x8399d4: r0 = renderEditable()
    //     0x8399d4: bl              #0x839fb0  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::renderEditable
    // 0x8399d8: add             SP, SP, #8
    // 0x8399dc: mov             x1, x0
    // 0x8399e0: ldr             x0, [fp, #0x18]
    // 0x8399e4: LoadField: r2 = r0->field_b
    //     0x8399e4: ldur            w2, [x0, #0xb]
    // 0x8399e8: DecompressPointer r2
    //     0x8399e8: add             x2, x2, HEAP, lsl #32
    // 0x8399ec: ldr             x0, [fp, #0x10]
    // 0x8399f0: LoadField: r3 = r0->field_13
    //     0x8399f0: ldur            w3, [x0, #0x13]
    // 0x8399f4: DecompressPointer r3
    //     0x8399f4: add             x3, x3, HEAP, lsl #32
    // 0x8399f8: r16 = Instance_SelectionChangedCause
    //     0x8399f8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x8399fc: ldr             x16, [x16, #0x6d0]
    // 0x839a00: stp             x16, x1, [SP, #-0x10]!
    // 0x839a04: stp             x3, x2, [SP, #-0x10]!
    // 0x839a08: r4 = const [0, 0x4, 0x4, 0x3, to, 0x3, null]
    //     0x839a08: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2de10] List(7) [0, 0x4, 0x4, 0x3, "to", 0x3, Null]
    //     0x839a0c: ldr             x4, [x4, #0xe10]
    // 0x839a10: r0 = selectPositionAt()
    //     0x839a10: bl              #0x839a30  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPositionAt
    // 0x839a14: add             SP, SP, #0x20
    // 0x839a18: r0 = Null
    //     0x839a18: mov             x0, NULL
    // 0x839a1c: LeaveFrame
    //     0x839a1c: mov             SP, fp
    //     0x839a20: ldp             fp, lr, [SP], #0x10
    // 0x839a24: ret
    //     0x839a24: ret             
    // 0x839a28: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839a28: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839a2c: b               #0x839998
  }
  get _ renderEditable(/* No info */) {
    // ** addr: 0x839fb0, size: 0x40
    // 0x839fb0: EnterFrame
    //     0x839fb0: stp             fp, lr, [SP, #-0x10]!
    //     0x839fb4: mov             fp, SP
    // 0x839fb8: CheckStackOverflow
    //     0x839fb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x839fbc: cmp             SP, x16
    //     0x839fc0: b.ls            #0x839fe8
    // 0x839fc4: ldr             x0, [fp, #0x10]
    // 0x839fc8: LoadField: r1 = r0->field_7
    //     0x839fc8: ldur            w1, [x0, #7]
    // 0x839fcc: DecompressPointer r1
    //     0x839fcc: add             x1, x1, HEAP, lsl #32
    // 0x839fd0: SaveReg r1
    //     0x839fd0: str             x1, [SP, #-8]!
    // 0x839fd4: r0 = renderEditable()
    //     0x839fd4: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x839fd8: add             SP, SP, #8
    // 0x839fdc: LeaveFrame
    //     0x839fdc: mov             SP, fp
    //     0x839fe0: ldp             fp, lr, [SP], #0x10
    // 0x839fe4: ret
    //     0x839fe4: ret             
    // 0x839fe8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x839fe8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x839fec: b               #0x839fc4
  }
  [closure] void onDragSelectionStart(dynamic, DragStartDetails) {
    // ** addr: 0x83a0d8, size: 0x4c
    // 0x83a0d8: EnterFrame
    //     0x83a0d8: stp             fp, lr, [SP, #-0x10]!
    //     0x83a0dc: mov             fp, SP
    // 0x83a0e0: ldr             x0, [fp, #0x18]
    // 0x83a0e4: LoadField: r1 = r0->field_17
    //     0x83a0e4: ldur            w1, [x0, #0x17]
    // 0x83a0e8: DecompressPointer r1
    //     0x83a0e8: add             x1, x1, HEAP, lsl #32
    // 0x83a0ec: CheckStackOverflow
    //     0x83a0ec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a0f0: cmp             SP, x16
    //     0x83a0f4: b.ls            #0x83a11c
    // 0x83a0f8: LoadField: r0 = r1->field_f
    //     0x83a0f8: ldur            w0, [x1, #0xf]
    // 0x83a0fc: DecompressPointer r0
    //     0x83a0fc: add             x0, x0, HEAP, lsl #32
    // 0x83a100: ldr             x16, [fp, #0x10]
    // 0x83a104: stp             x16, x0, [SP, #-0x10]!
    // 0x83a108: r0 = onDragSelectionStart()
    //     0x83a108: bl              #0x83a124  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onDragSelectionStart
    // 0x83a10c: add             SP, SP, #0x10
    // 0x83a110: LeaveFrame
    //     0x83a110: mov             SP, fp
    //     0x83a114: ldp             fp, lr, [SP], #0x10
    // 0x83a118: ret
    //     0x83a118: ret             
    // 0x83a11c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a11c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a120: b               #0x83a0f8
  }
  _ onDragSelectionStart(/* No info */) {
    // ** addr: 0x83a124, size: 0xec
    // 0x83a124: EnterFrame
    //     0x83a124: stp             fp, lr, [SP, #-0x10]!
    //     0x83a128: mov             fp, SP
    // 0x83a12c: CheckStackOverflow
    //     0x83a12c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a130: cmp             SP, x16
    //     0x83a134: b.ls            #0x83a204
    // 0x83a138: ldr             x0, [fp, #0x18]
    // 0x83a13c: LoadField: r1 = r0->field_7
    //     0x83a13c: ldur            w1, [x0, #7]
    // 0x83a140: DecompressPointer r1
    //     0x83a140: add             x1, x1, HEAP, lsl #32
    // 0x83a144: LoadField: r2 = r1->field_b
    //     0x83a144: ldur            w2, [x1, #0xb]
    // 0x83a148: DecompressPointer r2
    //     0x83a148: add             x2, x2, HEAP, lsl #32
    // 0x83a14c: cmp             w2, NULL
    // 0x83a150: b.eq            #0x83a20c
    // 0x83a154: LoadField: r3 = r2->field_bb
    //     0x83a154: ldur            w3, [x2, #0xbb]
    // 0x83a158: DecompressPointer r3
    //     0x83a158: add             x3, x3, HEAP, lsl #32
    // 0x83a15c: tbz             w3, #4, #0x83a170
    // 0x83a160: r0 = Null
    //     0x83a160: mov             x0, NULL
    // 0x83a164: LeaveFrame
    //     0x83a164: mov             SP, fp
    //     0x83a168: ldp             fp, lr, [SP], #0x10
    // 0x83a16c: ret
    //     0x83a16c: ret             
    // 0x83a170: ldr             x2, [fp, #0x10]
    // 0x83a174: LoadField: r3 = r2->field_13
    //     0x83a174: ldur            w3, [x2, #0x13]
    // 0x83a178: DecompressPointer r3
    //     0x83a178: add             x3, x3, HEAP, lsl #32
    // 0x83a17c: cmp             w3, NULL
    // 0x83a180: b.eq            #0x83a194
    // 0x83a184: r16 = Instance_PointerDeviceKind
    //     0x83a184: add             x16, PP, #0xf, lsl #12  ; [pp+0xf610] Obj!PointerDeviceKind@b671b1
    //     0x83a188: ldr             x16, [x16, #0x610]
    // 0x83a18c: cmp             w3, w16
    // 0x83a190: b.ne            #0x83a19c
    // 0x83a194: r3 = true
    //     0x83a194: add             x3, NULL, #0x20  ; true
    // 0x83a198: b               #0x83a1b8
    // 0x83a19c: r16 = Instance_PointerDeviceKind
    //     0x83a19c: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d500] Obj!PointerDeviceKind@b67171
    //     0x83a1a0: ldr             x16, [x16, #0x500]
    // 0x83a1a4: cmp             w3, w16
    // 0x83a1a8: r16 = true
    //     0x83a1a8: add             x16, NULL, #0x20  ; true
    // 0x83a1ac: r17 = false
    //     0x83a1ac: add             x17, NULL, #0x30  ; false
    // 0x83a1b0: csel            x4, x16, x17, eq
    // 0x83a1b4: mov             x3, x4
    // 0x83a1b8: StoreField: r0->field_13 = r3
    //     0x83a1b8: stur            w3, [x0, #0x13]
    // 0x83a1bc: SaveReg r1
    //     0x83a1bc: str             x1, [SP, #-8]!
    // 0x83a1c0: r0 = renderEditable()
    //     0x83a1c0: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83a1c4: add             SP, SP, #8
    // 0x83a1c8: mov             x1, x0
    // 0x83a1cc: ldr             x0, [fp, #0x10]
    // 0x83a1d0: LoadField: r2 = r0->field_b
    //     0x83a1d0: ldur            w2, [x0, #0xb]
    // 0x83a1d4: DecompressPointer r2
    //     0x83a1d4: add             x2, x2, HEAP, lsl #32
    // 0x83a1d8: r16 = Instance_SelectionChangedCause
    //     0x83a1d8: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d0] Obj!SelectionChangedCause@b63eb1
    //     0x83a1dc: ldr             x16, [x16, #0x6d0]
    // 0x83a1e0: stp             x16, x1, [SP, #-0x10]!
    // 0x83a1e4: SaveReg r2
    //     0x83a1e4: str             x2, [SP, #-8]!
    // 0x83a1e8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x83a1e8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x83a1ec: r0 = selectPositionAt()
    //     0x83a1ec: bl              #0x839a30  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPositionAt
    // 0x83a1f0: add             SP, SP, #0x18
    // 0x83a1f4: r0 = Null
    //     0x83a1f4: mov             x0, NULL
    // 0x83a1f8: LeaveFrame
    //     0x83a1f8: mov             SP, fp
    //     0x83a1fc: ldp             fp, lr, [SP], #0x10
    // 0x83a200: ret
    //     0x83a200: ret             
    // 0x83a204: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a204: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a208: b               #0x83a138
    // 0x83a20c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a20c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onDoubleTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x83a210, size: 0x4c
    // 0x83a210: EnterFrame
    //     0x83a210: stp             fp, lr, [SP, #-0x10]!
    //     0x83a214: mov             fp, SP
    // 0x83a218: ldr             x0, [fp, #0x18]
    // 0x83a21c: LoadField: r1 = r0->field_17
    //     0x83a21c: ldur            w1, [x0, #0x17]
    // 0x83a220: DecompressPointer r1
    //     0x83a220: add             x1, x1, HEAP, lsl #32
    // 0x83a224: CheckStackOverflow
    //     0x83a224: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a228: cmp             SP, x16
    //     0x83a22c: b.ls            #0x83a254
    // 0x83a230: LoadField: r0 = r1->field_f
    //     0x83a230: ldur            w0, [x1, #0xf]
    // 0x83a234: DecompressPointer r0
    //     0x83a234: add             x0, x0, HEAP, lsl #32
    // 0x83a238: ldr             x16, [fp, #0x10]
    // 0x83a23c: stp             x16, x0, [SP, #-0x10]!
    // 0x83a240: r0 = onDoubleTapDown()
    //     0x83a240: bl              #0x83a25c  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onDoubleTapDown
    // 0x83a244: add             SP, SP, #0x10
    // 0x83a248: LeaveFrame
    //     0x83a248: mov             SP, fp
    //     0x83a24c: ldp             fp, lr, [SP], #0x10
    // 0x83a250: ret
    //     0x83a250: ret             
    // 0x83a254: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a254: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a258: b               #0x83a230
  }
  _ onDoubleTapDown(/* No info */) {
    // ** addr: 0x83a25c, size: 0xb0
    // 0x83a25c: EnterFrame
    //     0x83a25c: stp             fp, lr, [SP, #-0x10]!
    //     0x83a260: mov             fp, SP
    // 0x83a264: CheckStackOverflow
    //     0x83a264: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83a268: cmp             SP, x16
    //     0x83a26c: b.ls            #0x83a300
    // 0x83a270: ldr             x0, [fp, #0x18]
    // 0x83a274: LoadField: r1 = r0->field_7
    //     0x83a274: ldur            w1, [x0, #7]
    // 0x83a278: DecompressPointer r1
    //     0x83a278: add             x1, x1, HEAP, lsl #32
    // 0x83a27c: LoadField: r2 = r1->field_b
    //     0x83a27c: ldur            w2, [x1, #0xb]
    // 0x83a280: DecompressPointer r2
    //     0x83a280: add             x2, x2, HEAP, lsl #32
    // 0x83a284: cmp             w2, NULL
    // 0x83a288: b.eq            #0x83a308
    // 0x83a28c: LoadField: r3 = r2->field_bb
    //     0x83a28c: ldur            w3, [x2, #0xbb]
    // 0x83a290: DecompressPointer r3
    //     0x83a290: add             x3, x3, HEAP, lsl #32
    // 0x83a294: tbnz            w3, #4, #0x83a2f0
    // 0x83a298: SaveReg r1
    //     0x83a298: str             x1, [SP, #-8]!
    // 0x83a29c: r0 = renderEditable()
    //     0x83a29c: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83a2a0: add             SP, SP, #8
    // 0x83a2a4: r16 = Instance_SelectionChangedCause
    //     0x83a2a4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6e8] Obj!SelectionChangedCause@b63ed1
    //     0x83a2a8: ldr             x16, [x16, #0x6e8]
    // 0x83a2ac: stp             x16, x0, [SP, #-0x10]!
    // 0x83a2b0: r0 = selectWord()
    //     0x83a2b0: bl              #0x83a30c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWord
    // 0x83a2b4: add             SP, SP, #0x10
    // 0x83a2b8: ldr             x0, [fp, #0x18]
    // 0x83a2bc: LoadField: r1 = r0->field_13
    //     0x83a2bc: ldur            w1, [x0, #0x13]
    // 0x83a2c0: DecompressPointer r1
    //     0x83a2c0: add             x1, x1, HEAP, lsl #32
    // 0x83a2c4: tbnz            w1, #4, #0x83a2f0
    // 0x83a2c8: LoadField: r1 = r0->field_b
    //     0x83a2c8: ldur            w1, [x0, #0xb]
    // 0x83a2cc: DecompressPointer r1
    //     0x83a2cc: add             x1, x1, HEAP, lsl #32
    // 0x83a2d0: SaveReg r1
    //     0x83a2d0: str             x1, [SP, #-8]!
    // 0x83a2d4: r4 = 0
    //     0x83a2d4: mov             x4, #0
    // 0x83a2d8: ldr             x0, [SP]
    // 0x83a2dc: r16 = UnlinkedCall_0x4aeefc
    //     0x83a2dc: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4bde0] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83a2e0: add             x16, x16, #0xde0
    // 0x83a2e4: ldp             x5, lr, [x16]
    // 0x83a2e8: blr             lr
    // 0x83a2ec: add             SP, SP, #8
    // 0x83a2f0: r0 = Null
    //     0x83a2f0: mov             x0, NULL
    // 0x83a2f4: LeaveFrame
    //     0x83a2f4: mov             SP, fp
    //     0x83a2f8: ldp             fp, lr, [SP], #0x10
    // 0x83a2fc: ret
    //     0x83a2fc: ret             
    // 0x83a300: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83a300: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83a304: b               #0x83a270
    // 0x83a308: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83a308: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onSingleLongTapEnd(dynamic, LongPressEndDetails) {
    // ** addr: 0x83bb4c, size: 0x4c
    // 0x83bb4c: EnterFrame
    //     0x83bb4c: stp             fp, lr, [SP, #-0x10]!
    //     0x83bb50: mov             fp, SP
    // 0x83bb54: ldr             x0, [fp, #0x18]
    // 0x83bb58: LoadField: r1 = r0->field_17
    //     0x83bb58: ldur            w1, [x0, #0x17]
    // 0x83bb5c: DecompressPointer r1
    //     0x83bb5c: add             x1, x1, HEAP, lsl #32
    // 0x83bb60: CheckStackOverflow
    //     0x83bb60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bb64: cmp             SP, x16
    //     0x83bb68: b.ls            #0x83bb90
    // 0x83bb6c: LoadField: r0 = r1->field_f
    //     0x83bb6c: ldur            w0, [x1, #0xf]
    // 0x83bb70: DecompressPointer r0
    //     0x83bb70: add             x0, x0, HEAP, lsl #32
    // 0x83bb74: ldr             x16, [fp, #0x10]
    // 0x83bb78: stp             x16, x0, [SP, #-0x10]!
    // 0x83bb7c: r0 = onSingleLongTapEnd()
    //     0x83bb7c: bl              #0x83bb98  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onSingleLongTapEnd
    // 0x83bb80: add             SP, SP, #0x10
    // 0x83bb84: LeaveFrame
    //     0x83bb84: mov             SP, fp
    //     0x83bb88: ldp             fp, lr, [SP], #0x10
    // 0x83bb8c: ret
    //     0x83bb8c: ret             
    // 0x83bb90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bb90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bb94: b               #0x83bb6c
  }
  _ onSingleLongTapEnd(/* No info */) {
    // ** addr: 0x83bb98, size: 0x64
    // 0x83bb98: EnterFrame
    //     0x83bb98: stp             fp, lr, [SP, #-0x10]!
    //     0x83bb9c: mov             fp, SP
    // 0x83bba0: CheckStackOverflow
    //     0x83bba0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bba4: cmp             SP, x16
    //     0x83bba8: b.ls            #0x83bbf4
    // 0x83bbac: ldr             x0, [fp, #0x18]
    // 0x83bbb0: LoadField: r1 = r0->field_13
    //     0x83bbb0: ldur            w1, [x0, #0x13]
    // 0x83bbb4: DecompressPointer r1
    //     0x83bbb4: add             x1, x1, HEAP, lsl #32
    // 0x83bbb8: tbnz            w1, #4, #0x83bbe4
    // 0x83bbbc: LoadField: r1 = r0->field_b
    //     0x83bbbc: ldur            w1, [x0, #0xb]
    // 0x83bbc0: DecompressPointer r1
    //     0x83bbc0: add             x1, x1, HEAP, lsl #32
    // 0x83bbc4: SaveReg r1
    //     0x83bbc4: str             x1, [SP, #-8]!
    // 0x83bbc8: r4 = 0
    //     0x83bbc8: mov             x4, #0
    // 0x83bbcc: ldr             x0, [SP]
    // 0x83bbd0: r16 = UnlinkedCall_0x4aeefc
    //     0x83bbd0: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be10] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83bbd4: add             x16, x16, #0xe10
    // 0x83bbd8: ldp             x5, lr, [x16]
    // 0x83bbdc: blr             lr
    // 0x83bbe0: add             SP, SP, #8
    // 0x83bbe4: r0 = Null
    //     0x83bbe4: mov             x0, NULL
    // 0x83bbe8: LeaveFrame
    //     0x83bbe8: mov             SP, fp
    //     0x83bbec: ldp             fp, lr, [SP], #0x10
    // 0x83bbf0: ret
    //     0x83bbf0: ret             
    // 0x83bbf4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bbf4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bbf8: b               #0x83bbac
  }
  [closure] void onSecondaryTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x83c5ec, size: 0x4c
    // 0x83c5ec: EnterFrame
    //     0x83c5ec: stp             fp, lr, [SP, #-0x10]!
    //     0x83c5f0: mov             fp, SP
    // 0x83c5f4: ldr             x0, [fp, #0x18]
    // 0x83c5f8: LoadField: r1 = r0->field_17
    //     0x83c5f8: ldur            w1, [x0, #0x17]
    // 0x83c5fc: DecompressPointer r1
    //     0x83c5fc: add             x1, x1, HEAP, lsl #32
    // 0x83c600: CheckStackOverflow
    //     0x83c600: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c604: cmp             SP, x16
    //     0x83c608: b.ls            #0x83c630
    // 0x83c60c: LoadField: r0 = r1->field_f
    //     0x83c60c: ldur            w0, [x1, #0xf]
    // 0x83c610: DecompressPointer r0
    //     0x83c610: add             x0, x0, HEAP, lsl #32
    // 0x83c614: ldr             x16, [fp, #0x10]
    // 0x83c618: stp             x16, x0, [SP, #-0x10]!
    // 0x83c61c: r0 = onSecondaryTapDown()
    //     0x83c61c: bl              #0x83c638  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onSecondaryTapDown
    // 0x83c620: add             SP, SP, #0x10
    // 0x83c624: LeaveFrame
    //     0x83c624: mov             SP, fp
    //     0x83c628: ldp             fp, lr, [SP], #0x10
    // 0x83c62c: ret
    //     0x83c62c: ret             
    // 0x83c630: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c630: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c634: b               #0x83c60c
  }
  _ onSecondaryTapDown(/* No info */) {
    // ** addr: 0x83c638, size: 0x60
    // 0x83c638: EnterFrame
    //     0x83c638: stp             fp, lr, [SP, #-0x10]!
    //     0x83c63c: mov             fp, SP
    // 0x83c640: CheckStackOverflow
    //     0x83c640: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c644: cmp             SP, x16
    //     0x83c648: b.ls            #0x83c690
    // 0x83c64c: ldr             x0, [fp, #0x18]
    // 0x83c650: LoadField: r1 = r0->field_7
    //     0x83c650: ldur            w1, [x0, #7]
    // 0x83c654: DecompressPointer r1
    //     0x83c654: add             x1, x1, HEAP, lsl #32
    // 0x83c658: SaveReg r1
    //     0x83c658: str             x1, [SP, #-8]!
    // 0x83c65c: r0 = renderEditable()
    //     0x83c65c: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c660: add             SP, SP, #8
    // 0x83c664: ldr             x16, [fp, #0x10]
    // 0x83c668: stp             x16, x0, [SP, #-0x10]!
    // 0x83c66c: r0 = handleSecondaryTapDown()
    //     0x83c66c: bl              #0x83c698  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleSecondaryTapDown
    // 0x83c670: add             SP, SP, #0x10
    // 0x83c674: ldr             x2, [fp, #0x18]
    // 0x83c678: r1 = true
    //     0x83c678: add             x1, NULL, #0x20  ; true
    // 0x83c67c: StoreField: r2->field_13 = r1
    //     0x83c67c: stur            w1, [x2, #0x13]
    // 0x83c680: r0 = Null
    //     0x83c680: mov             x0, NULL
    // 0x83c684: LeaveFrame
    //     0x83c684: mov             SP, fp
    //     0x83c688: ldp             fp, lr, [SP], #0x10
    // 0x83c68c: ret
    //     0x83c68c: ret             
    // 0x83c690: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c690: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c694: b               #0x83c64c
  }
  [closure] void onSecondaryTap(dynamic) {
    // ** addr: 0x83c700, size: 0x48
    // 0x83c700: EnterFrame
    //     0x83c700: stp             fp, lr, [SP, #-0x10]!
    //     0x83c704: mov             fp, SP
    // 0x83c708: ldr             x0, [fp, #0x10]
    // 0x83c70c: LoadField: r1 = r0->field_17
    //     0x83c70c: ldur            w1, [x0, #0x17]
    // 0x83c710: DecompressPointer r1
    //     0x83c710: add             x1, x1, HEAP, lsl #32
    // 0x83c714: CheckStackOverflow
    //     0x83c714: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c718: cmp             SP, x16
    //     0x83c71c: b.ls            #0x83c740
    // 0x83c720: LoadField: r0 = r1->field_f
    //     0x83c720: ldur            w0, [x1, #0xf]
    // 0x83c724: DecompressPointer r0
    //     0x83c724: add             x0, x0, HEAP, lsl #32
    // 0x83c728: SaveReg r0
    //     0x83c728: str             x0, [SP, #-8]!
    // 0x83c72c: r0 = onSecondaryTap()
    //     0x83c72c: bl              #0x83c748  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onSecondaryTap
    // 0x83c730: add             SP, SP, #8
    // 0x83c734: LeaveFrame
    //     0x83c734: mov             SP, fp
    //     0x83c738: ldp             fp, lr, [SP], #0x10
    // 0x83c73c: ret
    //     0x83c73c: ret             
    // 0x83c740: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c740: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c744: b               #0x83c720
  }
  _ onSecondaryTap(/* No info */) {
    // ** addr: 0x83c748, size: 0xf8
    // 0x83c748: EnterFrame
    //     0x83c748: stp             fp, lr, [SP, #-0x10]!
    //     0x83c74c: mov             fp, SP
    // 0x83c750: AllocStack(0x8)
    //     0x83c750: sub             SP, SP, #8
    // 0x83c754: CheckStackOverflow
    //     0x83c754: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c758: cmp             SP, x16
    //     0x83c75c: b.ls            #0x83c834
    // 0x83c760: ldr             x0, [fp, #0x10]
    // 0x83c764: LoadField: r1 = r0->field_7
    //     0x83c764: ldur            w1, [x0, #7]
    // 0x83c768: DecompressPointer r1
    //     0x83c768: add             x1, x1, HEAP, lsl #32
    // 0x83c76c: stur            x1, [fp, #-8]
    // 0x83c770: LoadField: r2 = r1->field_b
    //     0x83c770: ldur            w2, [x1, #0xb]
    // 0x83c774: DecompressPointer r2
    //     0x83c774: add             x2, x2, HEAP, lsl #32
    // 0x83c778: cmp             w2, NULL
    // 0x83c77c: b.eq            #0x83c83c
    // 0x83c780: LoadField: r3 = r2->field_bb
    //     0x83c780: ldur            w3, [x2, #0xbb]
    // 0x83c784: DecompressPointer r3
    //     0x83c784: add             x3, x3, HEAP, lsl #32
    // 0x83c788: tbnz            w3, #4, #0x83c824
    // 0x83c78c: SaveReg r0
    //     0x83c78c: str             x0, [SP, #-8]!
    // 0x83c790: r0 = _lastSecondaryTapWasOnSelection()
    //     0x83c790: bl              #0x83c840  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::_lastSecondaryTapWasOnSelection
    // 0x83c794: add             SP, SP, #8
    // 0x83c798: tbz             w0, #4, #0x83c7c0
    // 0x83c79c: ldur            x16, [fp, #-8]
    // 0x83c7a0: SaveReg r16
    //     0x83c7a0: str             x16, [SP, #-8]!
    // 0x83c7a4: r0 = renderEditable()
    //     0x83c7a4: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c7a8: add             SP, SP, #8
    // 0x83c7ac: r16 = Instance_SelectionChangedCause
    //     0x83c7ac: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6e8] Obj!SelectionChangedCause@b63ed1
    //     0x83c7b0: ldr             x16, [x16, #0x6e8]
    // 0x83c7b4: stp             x16, x0, [SP, #-0x10]!
    // 0x83c7b8: r0 = selectWord()
    //     0x83c7b8: bl              #0x83a30c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWord
    // 0x83c7bc: add             SP, SP, #0x10
    // 0x83c7c0: ldr             x0, [fp, #0x10]
    // 0x83c7c4: LoadField: r1 = r0->field_13
    //     0x83c7c4: ldur            w1, [x0, #0x13]
    // 0x83c7c8: DecompressPointer r1
    //     0x83c7c8: add             x1, x1, HEAP, lsl #32
    // 0x83c7cc: tbnz            w1, #4, #0x83c824
    // 0x83c7d0: LoadField: r1 = r0->field_f
    //     0x83c7d0: ldur            w1, [x0, #0xf]
    // 0x83c7d4: DecompressPointer r1
    //     0x83c7d4: add             x1, x1, HEAP, lsl #32
    // 0x83c7d8: SaveReg r1
    //     0x83c7d8: str             x1, [SP, #-8]!
    // 0x83c7dc: r4 = 0
    //     0x83c7dc: mov             x4, #0
    // 0x83c7e0: ldr             x0, [SP]
    // 0x83c7e4: r16 = UnlinkedCall_0x4aeefc
    //     0x83c7e4: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be40] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83c7e8: add             x16, x16, #0xe40
    // 0x83c7ec: ldp             x5, lr, [x16]
    // 0x83c7f0: blr             lr
    // 0x83c7f4: add             SP, SP, #8
    // 0x83c7f8: ldr             x0, [fp, #0x10]
    // 0x83c7fc: LoadField: r1 = r0->field_b
    //     0x83c7fc: ldur            w1, [x0, #0xb]
    // 0x83c800: DecompressPointer r1
    //     0x83c800: add             x1, x1, HEAP, lsl #32
    // 0x83c804: SaveReg r1
    //     0x83c804: str             x1, [SP, #-8]!
    // 0x83c808: r4 = 0
    //     0x83c808: mov             x4, #0
    // 0x83c80c: ldr             x0, [SP]
    // 0x83c810: r16 = UnlinkedCall_0x4aeefc
    //     0x83c810: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be50] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83c814: add             x16, x16, #0xe50
    // 0x83c818: ldp             x5, lr, [x16]
    // 0x83c81c: blr             lr
    // 0x83c820: add             SP, SP, #8
    // 0x83c824: r0 = Null
    //     0x83c824: mov             x0, NULL
    // 0x83c828: LeaveFrame
    //     0x83c828: mov             SP, fp
    //     0x83c82c: ldp             fp, lr, [SP], #0x10
    // 0x83c830: ret
    //     0x83c830: ret             
    // 0x83c834: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c834: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c838: b               #0x83c760
    // 0x83c83c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c83c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ _lastSecondaryTapWasOnSelection(/* No info */) {
    // ** addr: 0x83c840, size: 0x120
    // 0x83c840: EnterFrame
    //     0x83c840: stp             fp, lr, [SP, #-0x10]!
    //     0x83c844: mov             fp, SP
    // 0x83c848: AllocStack(0x18)
    //     0x83c848: sub             SP, SP, #0x18
    // 0x83c84c: CheckStackOverflow
    //     0x83c84c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c850: cmp             SP, x16
    //     0x83c854: b.ls            #0x83c954
    // 0x83c858: ldr             x0, [fp, #0x10]
    // 0x83c85c: LoadField: r1 = r0->field_7
    //     0x83c85c: ldur            w1, [x0, #7]
    // 0x83c860: DecompressPointer r1
    //     0x83c860: add             x1, x1, HEAP, lsl #32
    // 0x83c864: stur            x1, [fp, #-8]
    // 0x83c868: SaveReg r1
    //     0x83c868: str             x1, [SP, #-8]!
    // 0x83c86c: r0 = renderEditable()
    //     0x83c86c: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c870: add             SP, SP, #8
    // 0x83c874: ldur            x16, [fp, #-8]
    // 0x83c878: SaveReg r16
    //     0x83c878: str             x16, [SP, #-8]!
    // 0x83c87c: r0 = renderEditable()
    //     0x83c87c: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c880: add             SP, SP, #8
    // 0x83c884: stur            x0, [fp, #-0x10]
    // 0x83c888: ldur            x16, [fp, #-8]
    // 0x83c88c: SaveReg r16
    //     0x83c88c: str             x16, [SP, #-8]!
    // 0x83c890: r0 = renderEditable()
    //     0x83c890: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c894: add             SP, SP, #8
    // 0x83c898: LoadField: r1 = r0->field_8f
    //     0x83c898: ldur            w1, [x0, #0x8f]
    // 0x83c89c: DecompressPointer r1
    //     0x83c89c: add             x1, x1, HEAP, lsl #32
    // 0x83c8a0: cmp             w1, NULL
    // 0x83c8a4: b.eq            #0x83c95c
    // 0x83c8a8: ldur            x16, [fp, #-0x10]
    // 0x83c8ac: stp             x1, x16, [SP, #-0x10]!
    // 0x83c8b0: r0 = getPositionForPoint()
    //     0x83c8b0: bl              #0x7aba98  ; [package:extended_text_field/src/extended_render_editable.dart] ExtendedRenderEditable::getPositionForPoint
    // 0x83c8b4: add             SP, SP, #0x10
    // 0x83c8b8: stur            x0, [fp, #-0x10]
    // 0x83c8bc: ldur            x16, [fp, #-8]
    // 0x83c8c0: SaveReg r16
    //     0x83c8c0: str             x16, [SP, #-8]!
    // 0x83c8c4: r0 = renderEditable()
    //     0x83c8c4: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c8c8: add             SP, SP, #8
    // 0x83c8cc: r17 = 271
    //     0x83c8cc: mov             x17, #0x10f
    // 0x83c8d0: ldr             w1, [x0, x17]
    // 0x83c8d4: DecompressPointer r1
    //     0x83c8d4: add             x1, x1, HEAP, lsl #32
    // 0x83c8d8: SaveReg r1
    //     0x83c8d8: str             x1, [SP, #-8]!
    // 0x83c8dc: r0 = base()
    //     0x83c8dc: bl              #0x522758  ; [package:flutter/src/services/text_editing.dart] TextSelection::base
    // 0x83c8e0: add             SP, SP, #8
    // 0x83c8e4: LoadField: r1 = r0->field_7
    //     0x83c8e4: ldur            x1, [x0, #7]
    // 0x83c8e8: ldur            x0, [fp, #-0x10]
    // 0x83c8ec: LoadField: r2 = r0->field_7
    //     0x83c8ec: ldur            x2, [x0, #7]
    // 0x83c8f0: stur            x2, [fp, #-0x18]
    // 0x83c8f4: cmp             x1, x2
    // 0x83c8f8: b.gt            #0x83c944
    // 0x83c8fc: ldur            x16, [fp, #-8]
    // 0x83c900: SaveReg r16
    //     0x83c900: str             x16, [SP, #-8]!
    // 0x83c904: r0 = renderEditable()
    //     0x83c904: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c908: add             SP, SP, #8
    // 0x83c90c: r17 = 271
    //     0x83c90c: mov             x17, #0x10f
    // 0x83c910: ldr             w1, [x0, x17]
    // 0x83c914: DecompressPointer r1
    //     0x83c914: add             x1, x1, HEAP, lsl #32
    // 0x83c918: SaveReg r1
    //     0x83c918: str             x1, [SP, #-8]!
    // 0x83c91c: r0 = extent()
    //     0x83c91c: bl              #0x5223fc  ; [package:flutter/src/services/text_editing.dart] TextSelection::extent
    // 0x83c920: add             SP, SP, #8
    // 0x83c924: LoadField: r1 = r0->field_7
    //     0x83c924: ldur            x1, [x0, #7]
    // 0x83c928: ldur            x2, [fp, #-0x18]
    // 0x83c92c: cmp             x1, x2
    // 0x83c930: r16 = true
    //     0x83c930: add             x16, NULL, #0x20  ; true
    // 0x83c934: r17 = false
    //     0x83c934: add             x17, NULL, #0x30  ; false
    // 0x83c938: csel            x3, x16, x17, ge
    // 0x83c93c: mov             x0, x3
    // 0x83c940: b               #0x83c948
    // 0x83c944: r0 = false
    //     0x83c944: add             x0, NULL, #0x30  ; false
    // 0x83c948: LeaveFrame
    //     0x83c948: mov             SP, fp
    //     0x83c94c: ldp             fp, lr, [SP], #0x10
    // 0x83c950: ret
    //     0x83c950: ret             
    // 0x83c954: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c954: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c958: b               #0x83c858
    // 0x83c95c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c95c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onTapDown(dynamic, TapDownDetails) {
    // ** addr: 0x83c960, size: 0x4c
    // 0x83c960: EnterFrame
    //     0x83c960: stp             fp, lr, [SP, #-0x10]!
    //     0x83c964: mov             fp, SP
    // 0x83c968: ldr             x0, [fp, #0x18]
    // 0x83c96c: LoadField: r1 = r0->field_17
    //     0x83c96c: ldur            w1, [x0, #0x17]
    // 0x83c970: DecompressPointer r1
    //     0x83c970: add             x1, x1, HEAP, lsl #32
    // 0x83c974: CheckStackOverflow
    //     0x83c974: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c978: cmp             SP, x16
    //     0x83c97c: b.ls            #0x83c9a4
    // 0x83c980: LoadField: r0 = r1->field_f
    //     0x83c980: ldur            w0, [x1, #0xf]
    // 0x83c984: DecompressPointer r0
    //     0x83c984: add             x0, x0, HEAP, lsl #32
    // 0x83c988: ldr             x16, [fp, #0x10]
    // 0x83c98c: stp             x16, x0, [SP, #-0x10]!
    // 0x83c990: r0 = onTapDown()
    //     0x83c990: bl              #0x83c9ac  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onTapDown
    // 0x83c994: add             SP, SP, #0x10
    // 0x83c998: LeaveFrame
    //     0x83c998: mov             SP, fp
    //     0x83c99c: ldp             fp, lr, [SP], #0x10
    // 0x83c9a0: ret
    //     0x83c9a0: ret             
    // 0x83c9a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c9a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c9a8: b               #0x83c980
  }
  _ onTapDown(/* No info */) {
    // ** addr: 0x83c9ac, size: 0xa4
    // 0x83c9ac: EnterFrame
    //     0x83c9ac: stp             fp, lr, [SP, #-0x10]!
    //     0x83c9b0: mov             fp, SP
    // 0x83c9b4: CheckStackOverflow
    //     0x83c9b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c9b8: cmp             SP, x16
    //     0x83c9bc: b.ls            #0x83ca48
    // 0x83c9c0: ldr             x0, [fp, #0x18]
    // 0x83c9c4: LoadField: r1 = r0->field_7
    //     0x83c9c4: ldur            w1, [x0, #7]
    // 0x83c9c8: DecompressPointer r1
    //     0x83c9c8: add             x1, x1, HEAP, lsl #32
    // 0x83c9cc: SaveReg r1
    //     0x83c9cc: str             x1, [SP, #-8]!
    // 0x83c9d0: r0 = renderEditable()
    //     0x83c9d0: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c9d4: add             SP, SP, #8
    // 0x83c9d8: ldr             x16, [fp, #0x10]
    // 0x83c9dc: stp             x16, x0, [SP, #-0x10]!
    // 0x83c9e0: r0 = handleTapDown()
    //     0x83c9e0: bl              #0x83ca50  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::handleTapDown
    // 0x83c9e4: add             SP, SP, #0x10
    // 0x83c9e8: ldr             x1, [fp, #0x10]
    // 0x83c9ec: LoadField: r2 = r1->field_b
    //     0x83c9ec: ldur            w2, [x1, #0xb]
    // 0x83c9f0: DecompressPointer r2
    //     0x83c9f0: add             x2, x2, HEAP, lsl #32
    // 0x83c9f4: cmp             w2, NULL
    // 0x83c9f8: b.eq            #0x83ca0c
    // 0x83c9fc: r16 = Instance_PointerDeviceKind
    //     0x83c9fc: add             x16, PP, #0xf, lsl #12  ; [pp+0xf610] Obj!PointerDeviceKind@b671b1
    //     0x83ca00: ldr             x16, [x16, #0x610]
    // 0x83ca04: cmp             w2, w16
    // 0x83ca08: b.ne            #0x83ca14
    // 0x83ca0c: r2 = true
    //     0x83ca0c: add             x2, NULL, #0x20  ; true
    // 0x83ca10: b               #0x83ca30
    // 0x83ca14: r16 = Instance_PointerDeviceKind
    //     0x83ca14: add             x16, PP, #0x2d, lsl #12  ; [pp+0x2d500] Obj!PointerDeviceKind@b67171
    //     0x83ca18: ldr             x16, [x16, #0x500]
    // 0x83ca1c: cmp             w2, w16
    // 0x83ca20: r16 = true
    //     0x83ca20: add             x16, NULL, #0x20  ; true
    // 0x83ca24: r17 = false
    //     0x83ca24: add             x17, NULL, #0x30  ; false
    // 0x83ca28: csel            x1, x16, x17, eq
    // 0x83ca2c: mov             x2, x1
    // 0x83ca30: ldr             x1, [fp, #0x18]
    // 0x83ca34: StoreField: r1->field_13 = r2
    //     0x83ca34: stur            w2, [x1, #0x13]
    // 0x83ca38: r0 = Null
    //     0x83ca38: mov             x0, NULL
    // 0x83ca3c: LeaveFrame
    //     0x83ca3c: mov             SP, fp
    //     0x83ca40: ldp             fp, lr, [SP], #0x10
    // 0x83ca44: ret
    //     0x83ca44: ret             
    // 0x83ca48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83ca48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83ca4c: b               #0x83c9c0
  }
  _ onForcePressStart(/* No info */) {
    // ** addr: 0x83cb78, size: 0x9c
    // 0x83cb78: EnterFrame
    //     0x83cb78: stp             fp, lr, [SP, #-0x10]!
    //     0x83cb7c: mov             fp, SP
    // 0x83cb80: r0 = true
    //     0x83cb80: add             x0, NULL, #0x20  ; true
    // 0x83cb84: CheckStackOverflow
    //     0x83cb84: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83cb88: cmp             SP, x16
    //     0x83cb8c: b.ls            #0x83cc08
    // 0x83cb90: ldr             x1, [fp, #0x18]
    // 0x83cb94: StoreField: r1->field_13 = r0
    //     0x83cb94: stur            w0, [x1, #0x13]
    // 0x83cb98: LoadField: r0 = r1->field_7
    //     0x83cb98: ldur            w0, [x1, #7]
    // 0x83cb9c: DecompressPointer r0
    //     0x83cb9c: add             x0, x0, HEAP, lsl #32
    // 0x83cba0: LoadField: r1 = r0->field_b
    //     0x83cba0: ldur            w1, [x0, #0xb]
    // 0x83cba4: DecompressPointer r1
    //     0x83cba4: add             x1, x1, HEAP, lsl #32
    // 0x83cba8: cmp             w1, NULL
    // 0x83cbac: b.eq            #0x83cc10
    // 0x83cbb0: LoadField: r2 = r1->field_bb
    //     0x83cbb0: ldur            w2, [x1, #0xbb]
    // 0x83cbb4: DecompressPointer r2
    //     0x83cbb4: add             x2, x2, HEAP, lsl #32
    // 0x83cbb8: tbnz            w2, #4, #0x83cbf8
    // 0x83cbbc: ldr             x1, [fp, #0x10]
    // 0x83cbc0: SaveReg r0
    //     0x83cbc0: str             x0, [SP, #-8]!
    // 0x83cbc4: r0 = renderEditable()
    //     0x83cbc4: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83cbc8: add             SP, SP, #8
    // 0x83cbcc: mov             x1, x0
    // 0x83cbd0: ldr             x0, [fp, #0x10]
    // 0x83cbd4: LoadField: r2 = r0->field_7
    //     0x83cbd4: ldur            w2, [x0, #7]
    // 0x83cbd8: DecompressPointer r2
    //     0x83cbd8: add             x2, x2, HEAP, lsl #32
    // 0x83cbdc: r16 = Instance_SelectionChangedCause
    //     0x83cbdc: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6d8] Obj!SelectionChangedCause@b63f11
    //     0x83cbe0: ldr             x16, [x16, #0x6d8]
    // 0x83cbe4: stp             x16, x1, [SP, #-0x10]!
    // 0x83cbe8: SaveReg r2
    //     0x83cbe8: str             x2, [SP, #-8]!
    // 0x83cbec: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x83cbec: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x83cbf0: r0 = selectWordsInRange()
    //     0x83cbf0: bl              #0x83a368  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWordsInRange
    // 0x83cbf4: add             SP, SP, #0x18
    // 0x83cbf8: r0 = Null
    //     0x83cbf8: mov             x0, NULL
    // 0x83cbfc: LeaveFrame
    //     0x83cbfc: mov             SP, fp
    //     0x83cc00: ldp             fp, lr, [SP], #0x10
    // 0x83cc04: ret
    //     0x83cc04: ret             
    // 0x83cc08: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83cc08: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83cc0c: b               #0x83cb90
    // 0x83cc10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83cc10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4434, size: 0x24, field offset: 0x18
class CommonTextSelectionGestureDetectorBuilder extends ExtendedTextSelectionGestureDetectorBuilder {

  [closure] void onSingleLongTapMoveUpdate(dynamic, LongPressMoveUpdateDetails) {
    // ** addr: 0x83bbfc, size: 0x4c
    // 0x83bbfc: EnterFrame
    //     0x83bbfc: stp             fp, lr, [SP, #-0x10]!
    //     0x83bc00: mov             fp, SP
    // 0x83bc04: ldr             x0, [fp, #0x18]
    // 0x83bc08: LoadField: r1 = r0->field_17
    //     0x83bc08: ldur            w1, [x0, #0x17]
    // 0x83bc0c: DecompressPointer r1
    //     0x83bc0c: add             x1, x1, HEAP, lsl #32
    // 0x83bc10: CheckStackOverflow
    //     0x83bc10: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bc14: cmp             SP, x16
    //     0x83bc18: b.ls            #0x83bc40
    // 0x83bc1c: LoadField: r0 = r1->field_f
    //     0x83bc1c: ldur            w0, [x1, #0xf]
    // 0x83bc20: DecompressPointer r0
    //     0x83bc20: add             x0, x0, HEAP, lsl #32
    // 0x83bc24: ldr             x16, [fp, #0x10]
    // 0x83bc28: stp             x16, x0, [SP, #-0x10]!
    // 0x83bc2c: r0 = onSingleLongTapMoveUpdate()
    //     0x83bc2c: bl              #0x83bc48  ; [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onSingleLongTapMoveUpdate
    // 0x83bc30: add             SP, SP, #0x10
    // 0x83bc34: LeaveFrame
    //     0x83bc34: mov             SP, fp
    //     0x83bc38: ldp             fp, lr, [SP], #0x10
    // 0x83bc3c: ret
    //     0x83bc3c: ret             
    // 0x83bc40: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bc40: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bc44: b               #0x83bc1c
  }
  _ onSingleLongTapMoveUpdate(/* No info */) {
    // ** addr: 0x83bc48, size: 0x15c
    // 0x83bc48: EnterFrame
    //     0x83bc48: stp             fp, lr, [SP, #-0x10]!
    //     0x83bc4c: mov             fp, SP
    // 0x83bc50: AllocStack(0x10)
    //     0x83bc50: sub             SP, SP, #0x10
    // 0x83bc54: CheckStackOverflow
    //     0x83bc54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bc58: cmp             SP, x16
    //     0x83bc5c: b.ls            #0x83bd98
    // 0x83bc60: ldr             x0, [fp, #0x18]
    // 0x83bc64: LoadField: r1 = r0->field_7
    //     0x83bc64: ldur            w1, [x0, #7]
    // 0x83bc68: DecompressPointer r1
    //     0x83bc68: add             x1, x1, HEAP, lsl #32
    // 0x83bc6c: stur            x1, [fp, #-8]
    // 0x83bc70: LoadField: r2 = r1->field_b
    //     0x83bc70: ldur            w2, [x1, #0xb]
    // 0x83bc74: DecompressPointer r2
    //     0x83bc74: add             x2, x2, HEAP, lsl #32
    // 0x83bc78: cmp             w2, NULL
    // 0x83bc7c: b.eq            #0x83bda0
    // 0x83bc80: LoadField: r3 = r2->field_bb
    //     0x83bc80: ldur            w3, [x2, #0xbb]
    // 0x83bc84: DecompressPointer r3
    //     0x83bc84: add             x3, x3, HEAP, lsl #32
    // 0x83bc88: tbnz            w3, #4, #0x83bd88
    // 0x83bc8c: LoadField: r2 = r0->field_1b
    //     0x83bc8c: ldur            w2, [x0, #0x1b]
    // 0x83bc90: DecompressPointer r2
    //     0x83bc90: add             x2, x2, HEAP, lsl #32
    // 0x83bc94: SaveReg r2
    //     0x83bc94: str             x2, [SP, #-8]!
    // 0x83bc98: r0 = of()
    //     0x83bc98: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83bc9c: add             SP, SP, #8
    // 0x83bca0: LoadField: r1 = r0->field_1f
    //     0x83bca0: ldur            w1, [x0, #0x1f]
    // 0x83bca4: DecompressPointer r1
    //     0x83bca4: add             x1, x1, HEAP, lsl #32
    // 0x83bca8: LoadField: r0 = r1->field_7
    //     0x83bca8: ldur            x0, [x1, #7]
    // 0x83bcac: cmp             x0, #2
    // 0x83bcb0: b.gt            #0x83bcc4
    // 0x83bcb4: cmp             x0, #1
    // 0x83bcb8: b.gt            #0x83bcdc
    // 0x83bcbc: ldr             x0, [fp, #0x10]
    // 0x83bcc0: b               #0x83bd24
    // 0x83bcc4: cmp             x0, #4
    // 0x83bcc8: b.gt            #0x83bd20
    // 0x83bccc: cmp             x0, #3
    // 0x83bcd0: b.gt            #0x83bcdc
    // 0x83bcd4: ldr             x0, [fp, #0x10]
    // 0x83bcd8: b               #0x83bd24
    // 0x83bcdc: ldr             x0, [fp, #0x10]
    // 0x83bce0: ldur            x16, [fp, #-8]
    // 0x83bce4: SaveReg r16
    //     0x83bce4: str             x16, [SP, #-8]!
    // 0x83bce8: r0 = renderEditable()
    //     0x83bce8: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83bcec: add             SP, SP, #8
    // 0x83bcf0: mov             x1, x0
    // 0x83bcf4: ldr             x0, [fp, #0x10]
    // 0x83bcf8: LoadField: r2 = r0->field_7
    //     0x83bcf8: ldur            w2, [x0, #7]
    // 0x83bcfc: DecompressPointer r2
    //     0x83bcfc: add             x2, x2, HEAP, lsl #32
    // 0x83bd00: r16 = Instance_SelectionChangedCause
    //     0x83bd00: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83bd04: ldr             x16, [x16, #0x6b0]
    // 0x83bd08: stp             x16, x1, [SP, #-0x10]!
    // 0x83bd0c: SaveReg r2
    //     0x83bd0c: str             x2, [SP, #-8]!
    // 0x83bd10: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x83bd10: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x83bd14: r0 = selectPositionAt()
    //     0x83bd14: bl              #0x839a30  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPositionAt
    // 0x83bd18: add             SP, SP, #0x18
    // 0x83bd1c: b               #0x83bd88
    // 0x83bd20: ldr             x0, [fp, #0x10]
    // 0x83bd24: ldur            x16, [fp, #-8]
    // 0x83bd28: SaveReg r16
    //     0x83bd28: str             x16, [SP, #-8]!
    // 0x83bd2c: r0 = renderEditable()
    //     0x83bd2c: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83bd30: add             SP, SP, #8
    // 0x83bd34: mov             x1, x0
    // 0x83bd38: ldr             x0, [fp, #0x10]
    // 0x83bd3c: stur            x1, [fp, #-0x10]
    // 0x83bd40: LoadField: r2 = r0->field_7
    //     0x83bd40: ldur            w2, [x0, #7]
    // 0x83bd44: DecompressPointer r2
    //     0x83bd44: add             x2, x2, HEAP, lsl #32
    // 0x83bd48: stur            x2, [fp, #-8]
    // 0x83bd4c: LoadField: r3 = r0->field_f
    //     0x83bd4c: ldur            w3, [x0, #0xf]
    // 0x83bd50: DecompressPointer r3
    //     0x83bd50: add             x3, x3, HEAP, lsl #32
    // 0x83bd54: stp             x3, x2, [SP, #-0x10]!
    // 0x83bd58: r0 = -()
    //     0x83bd58: bl              #0x50e7f0  ; [dart:ui] Offset::-
    // 0x83bd5c: add             SP, SP, #0x10
    // 0x83bd60: ldur            x16, [fp, #-0x10]
    // 0x83bd64: r30 = Instance_SelectionChangedCause
    //     0x83bd64: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83bd68: ldr             lr, [lr, #0x6b0]
    // 0x83bd6c: stp             lr, x16, [SP, #-0x10]!
    // 0x83bd70: ldur            x16, [fp, #-8]
    // 0x83bd74: stp             x16, x0, [SP, #-0x10]!
    // 0x83bd78: r4 = const [0, 0x4, 0x4, 0x3, to, 0x3, null]
    //     0x83bd78: add             x4, PP, #0x2d, lsl #12  ; [pp+0x2de10] List(7) [0, 0x4, 0x4, 0x3, "to", 0x3, Null]
    //     0x83bd7c: ldr             x4, [x4, #0xe10]
    // 0x83bd80: r0 = selectWordsInRange()
    //     0x83bd80: bl              #0x83a368  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWordsInRange
    // 0x83bd84: add             SP, SP, #0x20
    // 0x83bd88: r0 = Null
    //     0x83bd88: mov             x0, NULL
    // 0x83bd8c: LeaveFrame
    //     0x83bd8c: mov             SP, fp
    //     0x83bd90: ldp             fp, lr, [SP], #0x10
    // 0x83bd94: ret
    //     0x83bd94: ret             
    // 0x83bd98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bd98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bd9c: b               #0x83bc60
    // 0x83bda0: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83bda0: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onSingleLongTapStart(dynamic, LongPressStartDetails) {
    // ** addr: 0x83bda4, size: 0x4c
    // 0x83bda4: EnterFrame
    //     0x83bda4: stp             fp, lr, [SP, #-0x10]!
    //     0x83bda8: mov             fp, SP
    // 0x83bdac: ldr             x0, [fp, #0x18]
    // 0x83bdb0: LoadField: r1 = r0->field_17
    //     0x83bdb0: ldur            w1, [x0, #0x17]
    // 0x83bdb4: DecompressPointer r1
    //     0x83bdb4: add             x1, x1, HEAP, lsl #32
    // 0x83bdb8: CheckStackOverflow
    //     0x83bdb8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83bdbc: cmp             SP, x16
    //     0x83bdc0: b.ls            #0x83bde8
    // 0x83bdc4: LoadField: r0 = r1->field_f
    //     0x83bdc4: ldur            w0, [x1, #0xf]
    // 0x83bdc8: DecompressPointer r0
    //     0x83bdc8: add             x0, x0, HEAP, lsl #32
    // 0x83bdcc: ldr             x16, [fp, #0x10]
    // 0x83bdd0: stp             x16, x0, [SP, #-0x10]!
    // 0x83bdd4: r0 = onSingleLongTapStart()
    //     0x83bdd4: bl              #0x83bdf0  ; [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onSingleLongTapStart
    // 0x83bdd8: add             SP, SP, #0x10
    // 0x83bddc: LeaveFrame
    //     0x83bddc: mov             SP, fp
    //     0x83bde0: ldp             fp, lr, [SP], #0x10
    // 0x83bde4: ret
    //     0x83bde4: ret             
    // 0x83bde8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bde8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83bdec: b               #0x83bdc4
  }
  _ onSingleLongTapStart(/* No info */) {
    // ** addr: 0x83bdf0, size: 0x110
    // 0x83bdf0: EnterFrame
    //     0x83bdf0: stp             fp, lr, [SP, #-0x10]!
    //     0x83bdf4: mov             fp, SP
    // 0x83bdf8: AllocStack(0x8)
    //     0x83bdf8: sub             SP, SP, #8
    // 0x83bdfc: CheckStackOverflow
    //     0x83bdfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83be00: cmp             SP, x16
    //     0x83be04: b.ls            #0x83bef8
    // 0x83be08: ldr             x0, [fp, #0x18]
    // 0x83be0c: LoadField: r1 = r0->field_1b
    //     0x83be0c: ldur            w1, [x0, #0x1b]
    // 0x83be10: DecompressPointer r1
    //     0x83be10: add             x1, x1, HEAP, lsl #32
    // 0x83be14: stur            x1, [fp, #-8]
    // 0x83be18: SaveReg r1
    //     0x83be18: str             x1, [SP, #-8]!
    // 0x83be1c: r0 = of()
    //     0x83be1c: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83be20: add             SP, SP, #8
    // 0x83be24: LoadField: r1 = r0->field_1f
    //     0x83be24: ldur            w1, [x0, #0x1f]
    // 0x83be28: DecompressPointer r1
    //     0x83be28: add             x1, x1, HEAP, lsl #32
    // 0x83be2c: LoadField: r0 = r1->field_7
    //     0x83be2c: ldur            x0, [x1, #7]
    // 0x83be30: cmp             x0, #2
    // 0x83be34: b.gt            #0x83be48
    // 0x83be38: cmp             x0, #1
    // 0x83be3c: b.gt            #0x83be60
    // 0x83be40: ldr             x0, [fp, #0x18]
    // 0x83be44: b               #0x83beb0
    // 0x83be48: cmp             x0, #4
    // 0x83be4c: b.gt            #0x83beac
    // 0x83be50: cmp             x0, #3
    // 0x83be54: b.gt            #0x83be60
    // 0x83be58: ldr             x0, [fp, #0x18]
    // 0x83be5c: b               #0x83beb0
    // 0x83be60: ldr             x0, [fp, #0x18]
    // 0x83be64: ldr             x1, [fp, #0x10]
    // 0x83be68: LoadField: r2 = r0->field_7
    //     0x83be68: ldur            w2, [x0, #7]
    // 0x83be6c: DecompressPointer r2
    //     0x83be6c: add             x2, x2, HEAP, lsl #32
    // 0x83be70: SaveReg r2
    //     0x83be70: str             x2, [SP, #-8]!
    // 0x83be74: r0 = renderEditable()
    //     0x83be74: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83be78: add             SP, SP, #8
    // 0x83be7c: mov             x1, x0
    // 0x83be80: ldr             x0, [fp, #0x10]
    // 0x83be84: LoadField: r2 = r0->field_7
    //     0x83be84: ldur            w2, [x0, #7]
    // 0x83be88: DecompressPointer r2
    //     0x83be88: add             x2, x2, HEAP, lsl #32
    // 0x83be8c: r16 = Instance_SelectionChangedCause
    //     0x83be8c: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83be90: ldr             x16, [x16, #0x6b0]
    // 0x83be94: stp             x16, x1, [SP, #-0x10]!
    // 0x83be98: SaveReg r2
    //     0x83be98: str             x2, [SP, #-8]!
    // 0x83be9c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x83be9c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x83bea0: r0 = selectPositionAt()
    //     0x83bea0: bl              #0x839a30  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPositionAt
    // 0x83bea4: add             SP, SP, #0x18
    // 0x83bea8: b               #0x83bee8
    // 0x83beac: ldr             x0, [fp, #0x18]
    // 0x83beb0: LoadField: r1 = r0->field_7
    //     0x83beb0: ldur            w1, [x0, #7]
    // 0x83beb4: DecompressPointer r1
    //     0x83beb4: add             x1, x1, HEAP, lsl #32
    // 0x83beb8: SaveReg r1
    //     0x83beb8: str             x1, [SP, #-8]!
    // 0x83bebc: r0 = renderEditable()
    //     0x83bebc: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83bec0: add             SP, SP, #8
    // 0x83bec4: r16 = Instance_SelectionChangedCause
    //     0x83bec4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6b0] Obj!SelectionChangedCause@b63e91
    //     0x83bec8: ldr             x16, [x16, #0x6b0]
    // 0x83becc: stp             x16, x0, [SP, #-0x10]!
    // 0x83bed0: r0 = selectWord()
    //     0x83bed0: bl              #0x83a30c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWord
    // 0x83bed4: add             SP, SP, #0x10
    // 0x83bed8: ldur            x16, [fp, #-8]
    // 0x83bedc: SaveReg r16
    //     0x83bedc: str             x16, [SP, #-8]!
    // 0x83bee0: r0 = forLongPress()
    //     0x83bee0: bl              #0x83bf00  ; [package:flutter/src/material/feedback.dart] Feedback::forLongPress
    // 0x83bee4: add             SP, SP, #8
    // 0x83bee8: r0 = Null
    //     0x83bee8: mov             x0, NULL
    // 0x83beec: LeaveFrame
    //     0x83beec: mov             SP, fp
    //     0x83bef0: ldp             fp, lr, [SP], #0x10
    // 0x83bef4: ret
    //     0x83bef4: ret             
    // 0x83bef8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83bef8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83befc: b               #0x83be08
  }
  [closure] void onSingleTapUp(dynamic, TapUpDetails) {
    // ** addr: 0x83c208, size: 0x4c
    // 0x83c208: EnterFrame
    //     0x83c208: stp             fp, lr, [SP, #-0x10]!
    //     0x83c20c: mov             fp, SP
    // 0x83c210: ldr             x0, [fp, #0x18]
    // 0x83c214: LoadField: r1 = r0->field_17
    //     0x83c214: ldur            w1, [x0, #0x17]
    // 0x83c218: DecompressPointer r1
    //     0x83c218: add             x1, x1, HEAP, lsl #32
    // 0x83c21c: CheckStackOverflow
    //     0x83c21c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c220: cmp             SP, x16
    //     0x83c224: b.ls            #0x83c24c
    // 0x83c228: LoadField: r0 = r1->field_f
    //     0x83c228: ldur            w0, [x1, #0xf]
    // 0x83c22c: DecompressPointer r0
    //     0x83c22c: add             x0, x0, HEAP, lsl #32
    // 0x83c230: ldr             x16, [fp, #0x10]
    // 0x83c234: stp             x16, x0, [SP, #-0x10]!
    // 0x83c238: r0 = onSingleTapUp()
    //     0x83c238: bl              #0x83c254  ; [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onSingleTapUp
    // 0x83c23c: add             SP, SP, #0x10
    // 0x83c240: LeaveFrame
    //     0x83c240: mov             SP, fp
    //     0x83c244: ldp             fp, lr, [SP], #0x10
    // 0x83c248: ret
    //     0x83c248: ret             
    // 0x83c24c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c24c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c250: b               #0x83c228
  }
  _ onSingleTapUp(/* No info */) {
    // ** addr: 0x83c254, size: 0x194
    // 0x83c254: EnterFrame
    //     0x83c254: stp             fp, lr, [SP, #-0x10]!
    //     0x83c258: mov             fp, SP
    // 0x83c25c: AllocStack(0x8)
    //     0x83c25c: sub             SP, SP, #8
    // 0x83c260: CheckStackOverflow
    //     0x83c260: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83c264: cmp             SP, x16
    //     0x83c268: b.ls            #0x83c3dc
    // 0x83c26c: ldr             x0, [fp, #0x18]
    // 0x83c270: LoadField: r1 = r0->field_f
    //     0x83c270: ldur            w1, [x0, #0xf]
    // 0x83c274: DecompressPointer r1
    //     0x83c274: add             x1, x1, HEAP, lsl #32
    // 0x83c278: SaveReg r1
    //     0x83c278: str             x1, [SP, #-8]!
    // 0x83c27c: r4 = 0
    //     0x83c27c: mov             x4, #0
    // 0x83c280: ldr             x0, [SP]
    // 0x83c284: r16 = UnlinkedCall_0x4aeefc
    //     0x83c284: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be20] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83c288: add             x16, x16, #0xe20
    // 0x83c28c: ldp             x5, lr, [x16]
    // 0x83c290: blr             lr
    // 0x83c294: add             SP, SP, #8
    // 0x83c298: ldr             x0, [fp, #0x18]
    // 0x83c29c: LoadField: r1 = r0->field_7
    //     0x83c29c: ldur            w1, [x0, #7]
    // 0x83c2a0: DecompressPointer r1
    //     0x83c2a0: add             x1, x1, HEAP, lsl #32
    // 0x83c2a4: stur            x1, [fp, #-8]
    // 0x83c2a8: LoadField: r2 = r1->field_b
    //     0x83c2a8: ldur            w2, [x1, #0xb]
    // 0x83c2ac: DecompressPointer r2
    //     0x83c2ac: add             x2, x2, HEAP, lsl #32
    // 0x83c2b0: cmp             w2, NULL
    // 0x83c2b4: b.eq            #0x83c3e4
    // 0x83c2b8: LoadField: r3 = r2->field_bb
    //     0x83c2b8: ldur            w3, [x2, #0xbb]
    // 0x83c2bc: DecompressPointer r3
    //     0x83c2bc: add             x3, x3, HEAP, lsl #32
    // 0x83c2c0: tbnz            w3, #4, #0x83c398
    // 0x83c2c4: LoadField: r2 = r0->field_1b
    //     0x83c2c4: ldur            w2, [x0, #0x1b]
    // 0x83c2c8: DecompressPointer r2
    //     0x83c2c8: add             x2, x2, HEAP, lsl #32
    // 0x83c2cc: SaveReg r2
    //     0x83c2cc: str             x2, [SP, #-8]!
    // 0x83c2d0: r0 = of()
    //     0x83c2d0: bl              #0x6cbb30  ; [package:flutter/src/material/theme.dart] Theme::of
    // 0x83c2d4: add             SP, SP, #8
    // 0x83c2d8: LoadField: r1 = r0->field_1f
    //     0x83c2d8: ldur            w1, [x0, #0x1f]
    // 0x83c2dc: DecompressPointer r1
    //     0x83c2dc: add             x1, x1, HEAP, lsl #32
    // 0x83c2e0: LoadField: r0 = r1->field_7
    //     0x83c2e0: ldur            x0, [x1, #7]
    // 0x83c2e4: cmp             x0, #2
    // 0x83c2e8: b.gt            #0x83c2f8
    // 0x83c2ec: cmp             x0, #1
    // 0x83c2f0: b.gt            #0x83c308
    // 0x83c2f4: b               #0x83c37c
    // 0x83c2f8: cmp             x0, #4
    // 0x83c2fc: b.gt            #0x83c37c
    // 0x83c300: cmp             x0, #3
    // 0x83c304: b.le            #0x83c37c
    // 0x83c308: ldr             x0, [fp, #0x10]
    // 0x83c30c: LoadField: r1 = r0->field_f
    //     0x83c30c: ldur            w1, [x0, #0xf]
    // 0x83c310: DecompressPointer r1
    //     0x83c310: add             x1, x1, HEAP, lsl #32
    // 0x83c314: LoadField: r0 = r1->field_7
    //     0x83c314: ldur            x0, [x1, #7]
    // 0x83c318: cmp             x0, #2
    // 0x83c31c: b.gt            #0x83c334
    // 0x83c320: cmp             x0, #1
    // 0x83c324: b.gt            #0x83c33c
    // 0x83c328: cmp             x0, #0
    // 0x83c32c: b.gt            #0x83c33c
    // 0x83c330: b               #0x83c35c
    // 0x83c334: cmp             x0, #4
    // 0x83c338: b.gt            #0x83c35c
    // 0x83c33c: ldur            x16, [fp, #-8]
    // 0x83c340: SaveReg r16
    //     0x83c340: str             x16, [SP, #-8]!
    // 0x83c344: r0 = renderEditable()
    //     0x83c344: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c348: add             SP, SP, #8
    // 0x83c34c: SaveReg r0
    //     0x83c34c: str             x0, [SP, #-8]!
    // 0x83c350: r0 = selectPosition()
    //     0x83c350: bl              #0x83c58c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPosition
    // 0x83c354: add             SP, SP, #8
    // 0x83c358: b               #0x83c398
    // 0x83c35c: ldur            x16, [fp, #-8]
    // 0x83c360: SaveReg r16
    //     0x83c360: str             x16, [SP, #-8]!
    // 0x83c364: r0 = renderEditable()
    //     0x83c364: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c368: add             SP, SP, #8
    // 0x83c36c: SaveReg r0
    //     0x83c36c: str             x0, [SP, #-8]!
    // 0x83c370: r0 = selectWordEdge()
    //     0x83c370: bl              #0x83c3e8  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectWordEdge
    // 0x83c374: add             SP, SP, #8
    // 0x83c378: b               #0x83c398
    // 0x83c37c: ldur            x16, [fp, #-8]
    // 0x83c380: SaveReg r16
    //     0x83c380: str             x16, [SP, #-8]!
    // 0x83c384: r0 = renderEditable()
    //     0x83c384: bl              #0x839ff0  ; [package:extended_text_field/src/extended_text_field.dart] ExtendedTextFieldState::renderEditable
    // 0x83c388: add             SP, SP, #8
    // 0x83c38c: SaveReg r0
    //     0x83c38c: str             x0, [SP, #-8]!
    // 0x83c390: r0 = selectPosition()
    //     0x83c390: bl              #0x83c58c  ; [package:extended_text_library/src/render_object/extended_text_selection_render_object.dart] ExtendedTextSelectionRenderObject::selectPosition
    // 0x83c394: add             SP, SP, #8
    // 0x83c398: ldr             x0, [fp, #0x18]
    // 0x83c39c: LoadField: r1 = r0->field_1f
    //     0x83c39c: ldur            w1, [x0, #0x1f]
    // 0x83c3a0: DecompressPointer r1
    //     0x83c3a0: add             x1, x1, HEAP, lsl #32
    // 0x83c3a4: cmp             w1, NULL
    // 0x83c3a8: b.eq            #0x83c3cc
    // 0x83c3ac: SaveReg r1
    //     0x83c3ac: str             x1, [SP, #-8]!
    // 0x83c3b0: r4 = 0
    //     0x83c3b0: mov             x4, #0
    // 0x83c3b4: ldr             x0, [SP]
    // 0x83c3b8: r16 = UnlinkedCall_0x4aeefc
    //     0x83c3b8: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be30] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83c3bc: add             x16, x16, #0xe30
    // 0x83c3c0: ldp             x5, lr, [x16]
    // 0x83c3c4: blr             lr
    // 0x83c3c8: add             SP, SP, #8
    // 0x83c3cc: r0 = Null
    //     0x83c3cc: mov             x0, NULL
    // 0x83c3d0: LeaveFrame
    //     0x83c3d0: mov             SP, fp
    //     0x83c3d4: ldp             fp, lr, [SP], #0x10
    // 0x83c3d8: ret
    //     0x83c3d8: ret             
    // 0x83c3dc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83c3dc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83c3e0: b               #0x83c26c
    // 0x83c3e4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83c3e4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void onForcePressStart(dynamic, ForcePressDetails) {
    // ** addr: 0x83ca8c, size: 0x4c
    // 0x83ca8c: EnterFrame
    //     0x83ca8c: stp             fp, lr, [SP, #-0x10]!
    //     0x83ca90: mov             fp, SP
    // 0x83ca94: ldr             x0, [fp, #0x18]
    // 0x83ca98: LoadField: r1 = r0->field_17
    //     0x83ca98: ldur            w1, [x0, #0x17]
    // 0x83ca9c: DecompressPointer r1
    //     0x83ca9c: add             x1, x1, HEAP, lsl #32
    // 0x83caa0: CheckStackOverflow
    //     0x83caa0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83caa4: cmp             SP, x16
    //     0x83caa8: b.ls            #0x83cad0
    // 0x83caac: LoadField: r0 = r1->field_f
    //     0x83caac: ldur            w0, [x1, #0xf]
    // 0x83cab0: DecompressPointer r0
    //     0x83cab0: add             x0, x0, HEAP, lsl #32
    // 0x83cab4: ldr             x16, [fp, #0x10]
    // 0x83cab8: stp             x16, x0, [SP, #-0x10]!
    // 0x83cabc: r0 = onForcePressStart()
    //     0x83cabc: bl              #0x83cad8  ; [package:extended_text_library/src/selection/extended_text_selection.dart] CommonTextSelectionGestureDetectorBuilder::onForcePressStart
    // 0x83cac0: add             SP, SP, #0x10
    // 0x83cac4: LeaveFrame
    //     0x83cac4: mov             SP, fp
    //     0x83cac8: ldp             fp, lr, [SP], #0x10
    // 0x83cacc: ret
    //     0x83cacc: ret             
    // 0x83cad0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83cad0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83cad4: b               #0x83caac
  }
  _ onForcePressStart(/* No info */) {
    // ** addr: 0x83cad8, size: 0xa0
    // 0x83cad8: EnterFrame
    //     0x83cad8: stp             fp, lr, [SP, #-0x10]!
    //     0x83cadc: mov             fp, SP
    // 0x83cae0: CheckStackOverflow
    //     0x83cae0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x83cae4: cmp             SP, x16
    //     0x83cae8: b.ls            #0x83cb6c
    // 0x83caec: ldr             x16, [fp, #0x18]
    // 0x83caf0: ldr             lr, [fp, #0x10]
    // 0x83caf4: stp             lr, x16, [SP, #-0x10]!
    // 0x83caf8: r0 = onForcePressStart()
    //     0x83caf8: bl              #0x83cb78  ; [package:extended_text_library/src/selection/extended_text_selection.dart] ExtendedTextSelectionGestureDetectorBuilder::onForcePressStart
    // 0x83cafc: add             SP, SP, #0x10
    // 0x83cb00: ldr             x0, [fp, #0x18]
    // 0x83cb04: LoadField: r1 = r0->field_7
    //     0x83cb04: ldur            w1, [x0, #7]
    // 0x83cb08: DecompressPointer r1
    //     0x83cb08: add             x1, x1, HEAP, lsl #32
    // 0x83cb0c: LoadField: r2 = r1->field_b
    //     0x83cb0c: ldur            w2, [x1, #0xb]
    // 0x83cb10: DecompressPointer r2
    //     0x83cb10: add             x2, x2, HEAP, lsl #32
    // 0x83cb14: cmp             w2, NULL
    // 0x83cb18: b.eq            #0x83cb74
    // 0x83cb1c: LoadField: r1 = r2->field_bb
    //     0x83cb1c: ldur            w1, [x2, #0xbb]
    // 0x83cb20: DecompressPointer r1
    //     0x83cb20: add             x1, x1, HEAP, lsl #32
    // 0x83cb24: tbnz            w1, #4, #0x83cb5c
    // 0x83cb28: LoadField: r1 = r0->field_13
    //     0x83cb28: ldur            w1, [x0, #0x13]
    // 0x83cb2c: DecompressPointer r1
    //     0x83cb2c: add             x1, x1, HEAP, lsl #32
    // 0x83cb30: tbnz            w1, #4, #0x83cb5c
    // 0x83cb34: LoadField: r1 = r0->field_b
    //     0x83cb34: ldur            w1, [x0, #0xb]
    // 0x83cb38: DecompressPointer r1
    //     0x83cb38: add             x1, x1, HEAP, lsl #32
    // 0x83cb3c: SaveReg r1
    //     0x83cb3c: str             x1, [SP, #-8]!
    // 0x83cb40: r4 = 0
    //     0x83cb40: mov             x4, #0
    // 0x83cb44: ldr             x0, [SP]
    // 0x83cb48: r16 = UnlinkedCall_0x4aeefc
    //     0x83cb48: add             x16, PP, #0x4b, lsl #12  ; [pp+0x4be60] UnlinkedCall: 0x4aeefc - SwitchableCallMissStub
    //     0x83cb4c: add             x16, x16, #0xe60
    // 0x83cb50: ldp             x5, lr, [x16]
    // 0x83cb54: blr             lr
    // 0x83cb58: add             SP, SP, #8
    // 0x83cb5c: r0 = Null
    //     0x83cb5c: mov             x0, NULL
    // 0x83cb60: LeaveFrame
    //     0x83cb60: mov             SP, fp
    //     0x83cb64: ldp             fp, lr, [SP], #0x10
    // 0x83cb68: ret
    //     0x83cb68: ret             
    // 0x83cb6c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x83cb6c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x83cb70: b               #0x83caec
    // 0x83cb74: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x83cb74: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 4436, size: 0x8, field offset: 0x8
abstract class ExtendedTextSelectionGestureDetectorBuilderDelegate extends Object {
}

// lib: , url: package:extended_text_library/src/selection/scribble_focusable.dart

// class id: 1048986, size: 0x8
class :: {
}

// class id: 3362, size: 0x18, field offset: 0x14
class _ScribbleFocusableState extends State<ScribbleFocusable>
    implements ScribbleClient {

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7aeb88, size: 0xa8
    // 0x7aeb88: EnterFrame
    //     0x7aeb88: stp             fp, lr, [SP, #-0x10]!
    //     0x7aeb8c: mov             fp, SP
    // 0x7aeb90: ldr             x0, [fp, #0x10]
    // 0x7aeb94: r2 = Null
    //     0x7aeb94: mov             x2, NULL
    // 0x7aeb98: r1 = Null
    //     0x7aeb98: mov             x1, NULL
    // 0x7aeb9c: r4 = 59
    //     0x7aeb9c: mov             x4, #0x3b
    // 0x7aeba0: branchIfSmi(r0, 0x7aebac)
    //     0x7aeba0: tbz             w0, #0, #0x7aebac
    // 0x7aeba4: r4 = LoadClassIdInstr(r0)
    //     0x7aeba4: ldur            x4, [x0, #-1]
    //     0x7aeba8: ubfx            x4, x4, #0xc, #0x14
    // 0x7aebac: r17 = 4185
    //     0x7aebac: mov             x17, #0x1059
    // 0x7aebb0: cmp             x4, x17
    // 0x7aebb4: b.eq            #0x7aebcc
    // 0x7aebb8: r8 = ScribbleFocusable
    //     0x7aebb8: add             x8, PP, #0x56, lsl #12  ; [pp+0x56668] Type: ScribbleFocusable
    //     0x7aebbc: ldr             x8, [x8, #0x668]
    // 0x7aebc0: r3 = Null
    //     0x7aebc0: add             x3, PP, #0x56, lsl #12  ; [pp+0x56670] Null
    //     0x7aebc4: ldr             x3, [x3, #0x670]
    // 0x7aebc8: r0 = ScribbleFocusable()
    //     0x7aebc8: bl              #0x7aec30  ; IsType_ScribbleFocusable_Stub
    // 0x7aebcc: ldr             x3, [fp, #0x18]
    // 0x7aebd0: LoadField: r2 = r3->field_7
    //     0x7aebd0: ldur            w2, [x3, #7]
    // 0x7aebd4: DecompressPointer r2
    //     0x7aebd4: add             x2, x2, HEAP, lsl #32
    // 0x7aebd8: ldr             x0, [fp, #0x10]
    // 0x7aebdc: r1 = Null
    //     0x7aebdc: mov             x1, NULL
    // 0x7aebe0: cmp             w2, NULL
    // 0x7aebe4: b.eq            #0x7aec08
    // 0x7aebe8: LoadField: r4 = r2->field_17
    //     0x7aebe8: ldur            w4, [x2, #0x17]
    // 0x7aebec: DecompressPointer r4
    //     0x7aebec: add             x4, x4, HEAP, lsl #32
    // 0x7aebf0: r8 = X0 bound StatefulWidget
    //     0x7aebf0: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x7aebf4: ldr             x8, [x8, #0x858]
    // 0x7aebf8: LoadField: r9 = r4->field_7
    //     0x7aebf8: ldur            x9, [x4, #7]
    // 0x7aebfc: r3 = Null
    //     0x7aebfc: add             x3, PP, #0x56, lsl #12  ; [pp+0x56680] Null
    //     0x7aec00: ldr             x3, [x3, #0x680]
    // 0x7aec04: blr             x9
    // 0x7aec08: ldr             x1, [fp, #0x18]
    // 0x7aec0c: LoadField: r2 = r1->field_b
    //     0x7aec0c: ldur            w2, [x1, #0xb]
    // 0x7aec10: DecompressPointer r2
    //     0x7aec10: add             x2, x2, HEAP, lsl #32
    // 0x7aec14: cmp             w2, NULL
    // 0x7aec18: b.eq            #0x7aec2c
    // 0x7aec1c: r0 = Null
    //     0x7aec1c: mov             x0, NULL
    // 0x7aec20: LeaveFrame
    //     0x7aec20: mov             SP, fp
    //     0x7aec24: ldp             fp, lr, [SP], #0x10
    // 0x7aec28: ret
    //     0x7aec28: ret             
    // 0x7aec2c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7aec2c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _ScribbleFocusableState(/* No info */) {
    // ** addr: 0xa3fbf4, size: 0xac
    // 0xa3fbf4: EnterFrame
    //     0xa3fbf4: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fbf8: mov             fp, SP
    // 0xa3fbfc: CheckStackOverflow
    //     0xa3fbfc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3fc00: cmp             SP, x16
    //     0xa3fc04: b.ls            #0xa3fc98
    // 0xa3fc08: r2 = LoadStaticField(0xc24)
    //     0xa3fc08: ldr             x2, [THR, #0x88]  ; THR::field_table_values
    //     0xa3fc0c: ldr             x2, [x2, #0x1848]
    // 0xa3fc10: r0 = LoadInt32Instr(r2)
    //     0xa3fc10: sbfx            x0, x2, #1, #0x1f
    //     0xa3fc14: tbz             w2, #0, #0xa3fc1c
    //     0xa3fc18: ldur            x0, [x2, #7]
    // 0xa3fc1c: add             x3, x0, #1
    // 0xa3fc20: r0 = BoxInt64Instr(r3)
    //     0xa3fc20: sbfiz           x0, x3, #1, #0x1f
    //     0xa3fc24: cmp             x3, x0, asr #1
    //     0xa3fc28: b.eq            #0xa3fc34
    //     0xa3fc2c: bl              #0xd69bb8
    //     0xa3fc30: stur            x3, [x0, #7]
    // 0xa3fc34: StoreStaticField(0xc24, r0)
    //     0xa3fc34: ldr             x1, [THR, #0x88]  ; THR::field_table_values
    //     0xa3fc38: str             x0, [x1, #0x1848]
    // 0xa3fc3c: r0 = 59
    //     0xa3fc3c: mov             x0, #0x3b
    // 0xa3fc40: branchIfSmi(r2, 0xa3fc4c)
    //     0xa3fc40: tbz             w2, #0, #0xa3fc4c
    // 0xa3fc44: r0 = LoadClassIdInstr(r2)
    //     0xa3fc44: ldur            x0, [x2, #-1]
    //     0xa3fc48: ubfx            x0, x0, #0xc, #0x14
    // 0xa3fc4c: SaveReg r2
    //     0xa3fc4c: str             x2, [SP, #-8]!
    // 0xa3fc50: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xa3fc50: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xa3fc54: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xa3fc54: mov             x17, #0x3f73
    //     0xa3fc58: add             lr, x0, x17
    //     0xa3fc5c: ldr             lr, [x21, lr, lsl #3]
    //     0xa3fc60: blr             lr
    // 0xa3fc64: add             SP, SP, #8
    // 0xa3fc68: ldr             x1, [fp, #0x10]
    // 0xa3fc6c: StoreField: r1->field_13 = r0
    //     0xa3fc6c: stur            w0, [x1, #0x13]
    //     0xa3fc70: ldurb           w16, [x1, #-1]
    //     0xa3fc74: ldurb           w17, [x0, #-1]
    //     0xa3fc78: and             x16, x17, x16, lsr #2
    //     0xa3fc7c: tst             x16, HEAP, lsr #32
    //     0xa3fc80: b.eq            #0xa3fc88
    //     0xa3fc84: bl              #0xd6826c
    // 0xa3fc88: r0 = Null
    //     0xa3fc88: mov             x0, NULL
    // 0xa3fc8c: LeaveFrame
    //     0xa3fc8c: mov             SP, fp
    //     0xa3fc90: ldp             fp, lr, [SP], #0x10
    // 0xa3fc94: ret
    //     0xa3fc94: ret             
    // 0xa3fc98: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3fc98: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3fc9c: b               #0xa3fc08
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa4a528, size: 0x18
    // 0xa4a528: r4 = 7
    //     0xa4a528: mov             x4, #7
    // 0xa4a52c: r1 = Function 'dispose':.
    //     0xa4a52c: add             x17, PP, #0x56, lsl #12  ; [pp+0x56638] AnonymousClosure: (0xa4a540), in [package:flutter/src/widgets/editable_text.dart] _ScribbleFocusableState::dispose (0xa54088)
    //     0xa4a530: ldr             x1, [x17, #0x638]
    // 0xa4a534: r24 = BuildNonGenericMethodExtractorStub
    //     0xa4a534: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa4a538: LoadField: r0 = r24->field_17
    //     0xa4a538: ldur            x0, [x24, #0x17]
    // 0xa4a53c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4a540, size: 0x48
    // 0xa4a540: EnterFrame
    //     0xa4a540: stp             fp, lr, [SP, #-0x10]!
    //     0xa4a544: mov             fp, SP
    // 0xa4a548: ldr             x0, [fp, #0x10]
    // 0xa4a54c: LoadField: r1 = r0->field_17
    //     0xa4a54c: ldur            w1, [x0, #0x17]
    // 0xa4a550: DecompressPointer r1
    //     0xa4a550: add             x1, x1, HEAP, lsl #32
    // 0xa4a554: CheckStackOverflow
    //     0xa4a554: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4a558: cmp             SP, x16
    //     0xa4a55c: b.ls            #0xa4a580
    // 0xa4a560: LoadField: r0 = r1->field_f
    //     0xa4a560: ldur            w0, [x1, #0xf]
    // 0xa4a564: DecompressPointer r0
    //     0xa4a564: add             x0, x0, HEAP, lsl #32
    // 0xa4a568: SaveReg r0
    //     0xa4a568: str             x0, [SP, #-8]!
    // 0xa4a56c: r0 = dispose()
    //     0xa4a56c: bl              #0xa54088  ; [package:flutter/src/widgets/editable_text.dart] _ScribbleFocusableState::dispose
    // 0xa4a570: add             SP, SP, #8
    // 0xa4a574: LeaveFrame
    //     0xa4a574: mov             SP, fp
    //     0xa4a578: ldp             fp, lr, [SP], #0x10
    // 0xa4a57c: ret
    //     0xa4a57c: ret             
    // 0xa4a580: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4a580: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4a584: b               #0xa4a560
  }
  _ isInScribbleRect(/* No info */) {
    // ** addr: 0xccf604, size: 0x22c
    // 0xccf604: EnterFrame
    //     0xccf604: stp             fp, lr, [SP, #-0x10]!
    //     0xccf608: mov             fp, SP
    // 0xccf60c: AllocStack(0x20)
    //     0xccf60c: sub             SP, SP, #0x20
    // 0xccf610: CheckStackOverflow
    //     0xccf610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf614: cmp             SP, x16
    //     0xccf618: b.ls            #0xccf824
    // 0xccf61c: r1 = 1
    //     0xccf61c: mov             x1, #1
    // 0xccf620: r0 = AllocateContext()
    //     0xccf620: bl              #0xd68aa4  ; AllocateContextStub
    // 0xccf624: mov             x1, x0
    // 0xccf628: ldr             x0, [fp, #0x18]
    // 0xccf62c: stur            x1, [fp, #-8]
    // 0xccf630: StoreField: r1->field_f = r0
    //     0xccf630: stur            w0, [x1, #0xf]
    // 0xccf634: SaveReg r0
    //     0xccf634: str             x0, [SP, #-8]!
    // 0xccf638: r0 = bounds()
    //     0xccf638: bl              #0xce2220  ; [package:extended_text_library/src/selection/scribble_focusable.dart] _ScribbleFocusableState::bounds
    // 0xccf63c: add             SP, SP, #8
    // 0xccf640: stur            x0, [fp, #-0x10]
    // 0xccf644: ldr             x16, [fp, #0x18]
    // 0xccf648: SaveReg r16
    //     0xccf648: str             x16, [SP, #-8]!
    // 0xccf64c: r0 = renderEditable()
    //     0xccf64c: bl              #0xccf830  ; [package:extended_text_library/src/selection/scribble_focusable.dart] _ScribbleFocusableState::renderEditable
    // 0xccf650: add             SP, SP, #8
    // 0xccf654: cmp             w0, NULL
    // 0xccf658: b.ne            #0xccf664
    // 0xccf65c: r0 = Null
    //     0xccf65c: mov             x0, NULL
    // 0xccf660: b               #0xccf670
    // 0xccf664: LoadField: r1 = r0->field_d7
    //     0xccf664: ldur            w1, [x0, #0xd7]
    // 0xccf668: DecompressPointer r1
    //     0xccf668: add             x1, x1, HEAP, lsl #32
    // 0xccf66c: mov             x0, x1
    // 0xccf670: cmp             w0, NULL
    // 0xccf674: b.eq            #0xccf68c
    // 0xccf678: tbnz            w0, #4, #0xccf68c
    // 0xccf67c: r0 = false
    //     0xccf67c: add             x0, NULL, #0x30  ; false
    // 0xccf680: LeaveFrame
    //     0xccf680: mov             SP, fp
    //     0xccf684: ldp             fp, lr, [SP], #0x10
    // 0xccf688: ret
    //     0xccf688: ret             
    // 0xccf68c: ldur            x0, [fp, #-0x10]
    // 0xccf690: r16 = Instance_Rect
    //     0xccf690: ldr             x16, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xccf694: cmp             w0, w16
    // 0xccf698: b.eq            #0xccf714
    // 0xccf69c: r16 = Rect
    //     0xccf69c: ldr             x16, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0xccf6a0: r30 = Rect
    //     0xccf6a0: ldr             lr, [PP, #0x5e50]  ; [pp+0x5e50] Type: Rect
    // 0xccf6a4: stp             lr, x16, [SP, #-0x10]!
    // 0xccf6a8: r0 = ==()
    //     0xccf6a8: bl              #0xcbbecc  ; [dart:core] _Type::==
    // 0xccf6ac: add             SP, SP, #0x10
    // 0xccf6b0: tbz             w0, #4, #0xccf6bc
    // 0xccf6b4: ldur            x0, [fp, #-0x10]
    // 0xccf6b8: b               #0xccf724
    // 0xccf6bc: ldur            x0, [fp, #-0x10]
    // 0xccf6c0: r1 = Instance_Rect
    //     0xccf6c0: ldr             x1, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xccf6c4: LoadField: d0 = r1->field_7
    //     0xccf6c4: ldur            d0, [x1, #7]
    // 0xccf6c8: LoadField: d1 = r0->field_7
    //     0xccf6c8: ldur            d1, [x0, #7]
    // 0xccf6cc: fcmp            d0, d1
    // 0xccf6d0: b.vs            #0xccf724
    // 0xccf6d4: b.ne            #0xccf724
    // 0xccf6d8: LoadField: d0 = r1->field_f
    //     0xccf6d8: ldur            d0, [x1, #0xf]
    // 0xccf6dc: LoadField: d1 = r0->field_f
    //     0xccf6dc: ldur            d1, [x0, #0xf]
    // 0xccf6e0: fcmp            d0, d1
    // 0xccf6e4: b.vs            #0xccf724
    // 0xccf6e8: b.ne            #0xccf724
    // 0xccf6ec: LoadField: d0 = r1->field_17
    //     0xccf6ec: ldur            d0, [x1, #0x17]
    // 0xccf6f0: LoadField: d1 = r0->field_17
    //     0xccf6f0: ldur            d1, [x0, #0x17]
    // 0xccf6f4: fcmp            d0, d1
    // 0xccf6f8: b.vs            #0xccf724
    // 0xccf6fc: b.ne            #0xccf724
    // 0xccf700: LoadField: d0 = r1->field_1f
    //     0xccf700: ldur            d0, [x1, #0x1f]
    // 0xccf704: LoadField: d1 = r0->field_1f
    //     0xccf704: ldur            d1, [x0, #0x1f]
    // 0xccf708: fcmp            d0, d1
    // 0xccf70c: b.vs            #0xccf724
    // 0xccf710: b.ne            #0xccf724
    // 0xccf714: r0 = false
    //     0xccf714: add             x0, NULL, #0x30  ; false
    // 0xccf718: LeaveFrame
    //     0xccf718: mov             SP, fp
    //     0xccf71c: ldp             fp, lr, [SP], #0x10
    // 0xccf720: ret
    //     0xccf720: ret             
    // 0xccf724: ldr             x1, [fp, #0x10]
    // 0xccf728: LoadField: d0 = r0->field_17
    //     0xccf728: ldur            d0, [x0, #0x17]
    // 0xccf72c: LoadField: d1 = r1->field_7
    //     0xccf72c: ldur            d1, [x1, #7]
    // 0xccf730: fcmp            d0, d1
    // 0xccf734: b.vs            #0xccf73c
    // 0xccf738: b.le            #0xccf778
    // 0xccf73c: LoadField: d0 = r1->field_17
    //     0xccf73c: ldur            d0, [x1, #0x17]
    // 0xccf740: LoadField: d1 = r0->field_7
    //     0xccf740: ldur            d1, [x0, #7]
    // 0xccf744: fcmp            d0, d1
    // 0xccf748: b.vs            #0xccf750
    // 0xccf74c: b.le            #0xccf778
    // 0xccf750: LoadField: d0 = r0->field_1f
    //     0xccf750: ldur            d0, [x0, #0x1f]
    // 0xccf754: LoadField: d1 = r1->field_f
    //     0xccf754: ldur            d1, [x1, #0xf]
    // 0xccf758: fcmp            d0, d1
    // 0xccf75c: b.vs            #0xccf764
    // 0xccf760: b.le            #0xccf778
    // 0xccf764: LoadField: d0 = r1->field_1f
    //     0xccf764: ldur            d0, [x1, #0x1f]
    // 0xccf768: LoadField: d1 = r0->field_f
    //     0xccf768: ldur            d1, [x0, #0xf]
    // 0xccf76c: fcmp            d0, d1
    // 0xccf770: b.vs            #0xccf788
    // 0xccf774: b.gt            #0xccf788
    // 0xccf778: r0 = false
    //     0xccf778: add             x0, NULL, #0x30  ; false
    // 0xccf77c: LeaveFrame
    //     0xccf77c: mov             SP, fp
    //     0xccf780: ldp             fp, lr, [SP], #0x10
    // 0xccf784: ret
    //     0xccf784: ret             
    // 0xccf788: stp             x1, x0, [SP, #-0x10]!
    // 0xccf78c: r0 = intersect()
    //     0xccf78c: bl              #0x642ca8  ; [dart:ui] Rect::intersect
    // 0xccf790: add             SP, SP, #0x10
    // 0xccf794: stur            x0, [fp, #-0x10]
    // 0xccf798: r0 = HitTestResult()
    //     0xccf798: bl              #0x50f360  ; AllocateHitTestResultStub -> HitTestResult (size=0x14)
    // 0xccf79c: stur            x0, [fp, #-0x18]
    // 0xccf7a0: SaveReg r0
    //     0xccf7a0: str             x0, [SP, #-8]!
    // 0xccf7a4: r0 = HitTestResult()
    //     0xccf7a4: bl              #0x50ef3c  ; [package:flutter/src/gestures/hit_test.dart] HitTestResult::HitTestResult
    // 0xccf7a8: add             SP, SP, #8
    // 0xccf7ac: r0 = LoadStaticField(0xbb8)
    //     0xccf7ac: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0xccf7b0: ldr             x0, [x0, #0x1770]
    // 0xccf7b4: stur            x0, [fp, #-0x20]
    // 0xccf7b8: cmp             w0, NULL
    // 0xccf7bc: b.eq            #0xccf82c
    // 0xccf7c0: ldur            x16, [fp, #-0x10]
    // 0xccf7c4: SaveReg r16
    //     0xccf7c4: str             x16, [SP, #-8]!
    // 0xccf7c8: r0 = center()
    //     0xccf7c8: bl              #0x51a188  ; [dart:ui] Rect::center
    // 0xccf7cc: add             SP, SP, #8
    // 0xccf7d0: ldur            x16, [fp, #-0x20]
    // 0xccf7d4: ldur            lr, [fp, #-0x18]
    // 0xccf7d8: stp             lr, x16, [SP, #-0x10]!
    // 0xccf7dc: SaveReg r0
    //     0xccf7dc: str             x0, [SP, #-8]!
    // 0xccf7e0: r0 = hitTest()
    //     0xccf7e0: bl              #0x50ee58  ; [package:flutter/src/widgets/binding.dart] _WidgetsFlutterBinding&BindingBase&GestureBinding&SchedulerBinding&ServicesBinding&PaintingBinding&SemanticsBinding&RendererBinding::hitTest
    // 0xccf7e4: add             SP, SP, #0x18
    // 0xccf7e8: ldur            x0, [fp, #-0x18]
    // 0xccf7ec: LoadField: r3 = r0->field_7
    //     0xccf7ec: ldur            w3, [x0, #7]
    // 0xccf7f0: DecompressPointer r3
    //     0xccf7f0: add             x3, x3, HEAP, lsl #32
    // 0xccf7f4: ldur            x2, [fp, #-8]
    // 0xccf7f8: stur            x3, [fp, #-0x10]
    // 0xccf7fc: r1 = Function '<anonymous closure>':.
    //     0xccf7fc: add             x1, PP, #0x56, lsl #12  ; [pp+0x56650] AnonymousClosure: (0xccf8e0), in [package:extended_text_library/src/selection/scribble_focusable.dart] _ScribbleFocusableState::isInScribbleRect (0xccf604)
    //     0xccf800: ldr             x1, [x1, #0x650]
    // 0xccf804: r0 = AllocateClosure()
    //     0xccf804: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xccf808: ldur            x16, [fp, #-0x10]
    // 0xccf80c: stp             x0, x16, [SP, #-0x10]!
    // 0xccf810: r0 = any()
    //     0xccf810: bl              #0x6f72b8  ; [dart:collection] _ListBase&Object&ListMixin::any
    // 0xccf814: add             SP, SP, #0x10
    // 0xccf818: LeaveFrame
    //     0xccf818: mov             SP, fp
    //     0xccf81c: ldp             fp, lr, [SP], #0x10
    // 0xccf820: ret
    //     0xccf820: ret             
    // 0xccf824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf828: b               #0xccf61c
    // 0xccf82c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccf82c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ renderEditable(/* No info */) {
    // ** addr: 0xccf830, size: 0xb0
    // 0xccf830: EnterFrame
    //     0xccf830: stp             fp, lr, [SP, #-0x10]!
    //     0xccf834: mov             fp, SP
    // 0xccf838: AllocStack(0x8)
    //     0xccf838: sub             SP, SP, #8
    // 0xccf83c: CheckStackOverflow
    //     0xccf83c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf840: cmp             SP, x16
    //     0xccf844: b.ls            #0xccf8d4
    // 0xccf848: ldr             x0, [fp, #0x10]
    // 0xccf84c: LoadField: r1 = r0->field_b
    //     0xccf84c: ldur            w1, [x0, #0xb]
    // 0xccf850: DecompressPointer r1
    //     0xccf850: add             x1, x1, HEAP, lsl #32
    // 0xccf854: cmp             w1, NULL
    // 0xccf858: b.eq            #0xccf8dc
    // 0xccf85c: LoadField: r0 = r1->field_13
    //     0xccf85c: ldur            w0, [x1, #0x13]
    // 0xccf860: DecompressPointer r0
    //     0xccf860: add             x0, x0, HEAP, lsl #32
    // 0xccf864: SaveReg r0
    //     0xccf864: str             x0, [SP, #-8]!
    // 0xccf868: r0 = _currentElement()
    //     0xccf868: bl              #0x5093d8  ; [package:flutter/src/widgets/framework.dart] GlobalKey::_currentElement
    // 0xccf86c: add             SP, SP, #8
    // 0xccf870: cmp             w0, NULL
    // 0xccf874: b.ne            #0xccf880
    // 0xccf878: r3 = Null
    //     0xccf878: mov             x3, NULL
    // 0xccf87c: b               #0xccf890
    // 0xccf880: SaveReg r0
    //     0xccf880: str             x0, [SP, #-8]!
    // 0xccf884: r0 = findRenderObject()
    //     0xccf884: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xccf888: add             SP, SP, #8
    // 0xccf88c: mov             x3, x0
    // 0xccf890: mov             x0, x3
    // 0xccf894: stur            x3, [fp, #-8]
    // 0xccf898: r2 = Null
    //     0xccf898: mov             x2, NULL
    // 0xccf89c: r1 = Null
    //     0xccf89c: mov             x1, NULL
    // 0xccf8a0: r4 = LoadClassIdInstr(r0)
    //     0xccf8a0: ldur            x4, [x0, #-1]
    //     0xccf8a4: ubfx            x4, x4, #0xc, #0x14
    // 0xccf8a8: cmp             x4, #0x989
    // 0xccf8ac: b.eq            #0xccf8c4
    // 0xccf8b0: r8 = RenderEditable?
    //     0xccf8b0: add             x8, PP, #0x4f, lsl #12  ; [pp+0x4f488] Type: RenderEditable?
    //     0xccf8b4: ldr             x8, [x8, #0x488]
    // 0xccf8b8: r3 = Null
    //     0xccf8b8: add             x3, PP, #0x56, lsl #12  ; [pp+0x56658] Null
    //     0xccf8bc: ldr             x3, [x3, #0x658]
    // 0xccf8c0: r0 = DefaultNullableTypeTest()
    //     0xccf8c0: bl              #0xd67ab0  ; DefaultNullableTypeTestStub
    // 0xccf8c4: ldur            x0, [fp, #-8]
    // 0xccf8c8: LeaveFrame
    //     0xccf8c8: mov             SP, fp
    //     0xccf8cc: ldp             fp, lr, [SP], #0x10
    // 0xccf8d0: ret
    //     0xccf8d0: ret             
    // 0xccf8d4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf8d4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf8d8: b               #0xccf848
    // 0xccf8dc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xccf8dc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] bool <anonymous closure>(dynamic, HitTestEntry<HitTestTarget>) {
    // ** addr: 0xccf8e0, size: 0x84
    // 0xccf8e0: EnterFrame
    //     0xccf8e0: stp             fp, lr, [SP, #-0x10]!
    //     0xccf8e4: mov             fp, SP
    // 0xccf8e8: AllocStack(0x8)
    //     0xccf8e8: sub             SP, SP, #8
    // 0xccf8ec: SetupParameters()
    //     0xccf8ec: ldr             x0, [fp, #0x18]
    //     0xccf8f0: ldur            w1, [x0, #0x17]
    //     0xccf8f4: add             x1, x1, HEAP, lsl #32
    // 0xccf8f8: CheckStackOverflow
    //     0xccf8f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xccf8fc: cmp             SP, x16
    //     0xccf900: b.ls            #0xccf95c
    // 0xccf904: ldr             x0, [fp, #0x10]
    // 0xccf908: LoadField: r2 = r0->field_b
    //     0xccf908: ldur            w2, [x0, #0xb]
    // 0xccf90c: DecompressPointer r2
    //     0xccf90c: add             x2, x2, HEAP, lsl #32
    // 0xccf910: stur            x2, [fp, #-8]
    // 0xccf914: LoadField: r0 = r1->field_f
    //     0xccf914: ldur            w0, [x1, #0xf]
    // 0xccf918: DecompressPointer r0
    //     0xccf918: add             x0, x0, HEAP, lsl #32
    // 0xccf91c: SaveReg r0
    //     0xccf91c: str             x0, [SP, #-8]!
    // 0xccf920: r0 = renderEditable()
    //     0xccf920: bl              #0xccf830  ; [package:extended_text_library/src/selection/scribble_focusable.dart] _ScribbleFocusableState::renderEditable
    // 0xccf924: add             SP, SP, #8
    // 0xccf928: mov             x1, x0
    // 0xccf92c: ldur            x0, [fp, #-8]
    // 0xccf930: r2 = LoadClassIdInstr(r0)
    //     0xccf930: ldur            x2, [x0, #-1]
    //     0xccf934: ubfx            x2, x2, #0xc, #0x14
    // 0xccf938: stp             x1, x0, [SP, #-0x10]!
    // 0xccf93c: mov             x0, x2
    // 0xccf940: mov             lr, x0
    // 0xccf944: ldr             lr, [x21, lr, lsl #3]
    // 0xccf948: blr             lr
    // 0xccf94c: add             SP, SP, #0x10
    // 0xccf950: LeaveFrame
    //     0xccf950: mov             SP, fp
    //     0xccf954: ldp             fp, lr, [SP], #0x10
    // 0xccf958: ret
    //     0xccf958: ret             
    // 0xccf95c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xccf95c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xccf960: b               #0xccf904
  }
  _ onScribbleFocus(/* No info */) {
    // ** addr: 0xcdc15c, size: 0xc8
    // 0xcdc15c: EnterFrame
    //     0xcdc15c: stp             fp, lr, [SP, #-0x10]!
    //     0xcdc160: mov             fp, SP
    // 0xcdc164: CheckStackOverflow
    //     0xcdc164: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xcdc168: cmp             SP, x16
    //     0xcdc16c: b.ls            #0xcdc214
    // 0xcdc170: ldr             x0, [fp, #0x18]
    // 0xcdc174: LoadField: r1 = r0->field_b
    //     0xcdc174: ldur            w1, [x0, #0xb]
    // 0xcdc178: DecompressPointer r1
    //     0xcdc178: add             x1, x1, HEAP, lsl #32
    // 0xcdc17c: cmp             w1, NULL
    // 0xcdc180: b.eq            #0xcdc21c
    // 0xcdc184: LoadField: r2 = r1->field_f
    //     0xcdc184: ldur            w2, [x1, #0xf]
    // 0xcdc188: DecompressPointer r2
    //     0xcdc188: add             x2, x2, HEAP, lsl #32
    // 0xcdc18c: SaveReg r2
    //     0xcdc18c: str             x2, [SP, #-8]!
    // 0xcdc190: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xcdc190: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xcdc194: r0 = requestFocus()
    //     0xcdc194: bl              #0x6fed6c  ; [package:flutter/src/widgets/focus_manager.dart] FocusNode::requestFocus
    // 0xcdc198: add             SP, SP, #8
    // 0xcdc19c: ldr             x16, [fp, #0x18]
    // 0xcdc1a0: SaveReg r16
    //     0xcdc1a0: str             x16, [SP, #-8]!
    // 0xcdc1a4: r0 = renderEditable()
    //     0xcdc1a4: bl              #0xccf830  ; [package:extended_text_library/src/selection/scribble_focusable.dart] _ScribbleFocusableState::renderEditable
    // 0xcdc1a8: add             SP, SP, #8
    // 0xcdc1ac: cmp             w0, NULL
    // 0xcdc1b0: b.eq            #0xcdc1d4
    // 0xcdc1b4: r16 = Instance_SelectionChangedCause
    //     0xcdc1b4: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f6e0] Obj!SelectionChangedCause@b63ef1
    //     0xcdc1b8: ldr             x16, [x16, #0x6e0]
    // 0xcdc1bc: stp             x16, x0, [SP, #-0x10]!
    // 0xcdc1c0: ldr             x16, [fp, #0x10]
    // 0xcdc1c4: SaveReg r16
    //     0xcdc1c4: str             x16, [SP, #-8]!
    // 0xcdc1c8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0xcdc1c8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0xcdc1cc: r0 = selectPositionAt()
    //     0xcdc1cc: bl              #0x86d11c  ; [package:flutter/src/rendering/editable.dart] RenderEditable::selectPositionAt
    // 0xcdc1d0: add             SP, SP, #0x18
    // 0xcdc1d4: ldr             x0, [fp, #0x18]
    // 0xcdc1d8: LoadField: r1 = r0->field_b
    //     0xcdc1d8: ldur            w1, [x0, #0xb]
    // 0xcdc1dc: DecompressPointer r1
    //     0xcdc1dc: add             x1, x1, HEAP, lsl #32
    // 0xcdc1e0: cmp             w1, NULL
    // 0xcdc1e4: b.eq            #0xcdc220
    // 0xcdc1e8: LoadField: r0 = r1->field_17
    //     0xcdc1e8: ldur            w0, [x1, #0x17]
    // 0xcdc1ec: DecompressPointer r0
    //     0xcdc1ec: add             x0, x0, HEAP, lsl #32
    // 0xcdc1f0: SaveReg r0
    //     0xcdc1f0: str             x0, [SP, #-8]!
    // 0xcdc1f4: ClosureCall
    //     0xcdc1f4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    //     0xcdc1f8: ldur            x2, [x0, #0x1f]
    //     0xcdc1fc: blr             x2
    // 0xcdc200: add             SP, SP, #8
    // 0xcdc204: r0 = Null
    //     0xcdc204: mov             x0, NULL
    // 0xcdc208: LeaveFrame
    //     0xcdc208: mov             SP, fp
    //     0xcdc20c: ldp             fp, lr, [SP], #0x10
    // 0xcdc210: ret
    //     0xcdc210: ret             
    // 0xcdc214: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xcdc214: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xcdc218: b               #0xcdc170
    // 0xcdc21c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcdc21c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xcdc220: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xcdc220: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  get _ bounds(/* No info */) {
    // ** addr: 0xce2220, size: 0x13c
    // 0xce2220: EnterFrame
    //     0xce2220: stp             fp, lr, [SP, #-0x10]!
    //     0xce2224: mov             fp, SP
    // 0xce2228: AllocStack(0x20)
    //     0xce2228: sub             SP, SP, #0x20
    // 0xce222c: CheckStackOverflow
    //     0xce222c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xce2230: cmp             SP, x16
    //     0xce2234: b.ls            #0xce234c
    // 0xce2238: ldr             x0, [fp, #0x10]
    // 0xce223c: LoadField: r1 = r0->field_f
    //     0xce223c: ldur            w1, [x0, #0xf]
    // 0xce2240: DecompressPointer r1
    //     0xce2240: add             x1, x1, HEAP, lsl #32
    // 0xce2244: cmp             w1, NULL
    // 0xce2248: b.eq            #0xce2354
    // 0xce224c: SaveReg r1
    //     0xce224c: str             x1, [SP, #-8]!
    // 0xce2250: r0 = findRenderObject()
    //     0xce2250: bl              #0x51ed34  ; [package:flutter/src/widgets/framework.dart] Element::findRenderObject
    // 0xce2254: add             SP, SP, #8
    // 0xce2258: mov             x3, x0
    // 0xce225c: r2 = Null
    //     0xce225c: mov             x2, NULL
    // 0xce2260: r1 = Null
    //     0xce2260: mov             x1, NULL
    // 0xce2264: stur            x3, [fp, #-8]
    // 0xce2268: r4 = LoadClassIdInstr(r0)
    //     0xce2268: ldur            x4, [x0, #-1]
    //     0xce226c: ubfx            x4, x4, #0xc, #0x14
    // 0xce2270: sub             x4, x4, #0x965
    // 0xce2274: cmp             x4, #0x8b
    // 0xce2278: b.ls            #0xce228c
    // 0xce227c: r8 = RenderBox?
    //     0xce227c: ldr             x8, [PP, #0x4de8]  ; [pp+0x4de8] Type: RenderBox?
    // 0xce2280: r3 = Null
    //     0xce2280: add             x3, PP, #0x56, lsl #12  ; [pp+0x56640] Null
    //     0xce2284: ldr             x3, [x3, #0x640]
    // 0xce2288: r0 = RenderBox?()
    //     0xce2288: bl              #0x5ad534  ; IsType_RenderBox?_Stub
    // 0xce228c: ldur            x0, [fp, #-8]
    // 0xce2290: cmp             w0, NULL
    // 0xce2294: b.eq            #0xce22bc
    // 0xce2298: ldr             x1, [fp, #0x10]
    // 0xce229c: LoadField: r2 = r1->field_f
    //     0xce229c: ldur            w2, [x1, #0xf]
    // 0xce22a0: DecompressPointer r2
    //     0xce22a0: add             x2, x2, HEAP, lsl #32
    // 0xce22a4: cmp             w2, NULL
    // 0xce22a8: b.eq            #0xce22bc
    // 0xce22ac: LoadField: r1 = r0->field_f
    //     0xce22ac: ldur            w1, [x0, #0xf]
    // 0xce22b0: DecompressPointer r1
    //     0xce22b0: add             x1, x1, HEAP, lsl #32
    // 0xce22b4: cmp             w1, NULL
    // 0xce22b8: b.ne            #0xce22cc
    // 0xce22bc: r0 = Instance_Rect
    //     0xce22bc: ldr             x0, [PP, #0x5e48]  ; [pp+0x5e48] Obj!Rect@b5ebc1
    // 0xce22c0: LeaveFrame
    //     0xce22c0: mov             SP, fp
    //     0xce22c4: ldp             fp, lr, [SP], #0x10
    // 0xce22c8: ret
    //     0xce22c8: ret             
    // 0xce22cc: stp             NULL, x0, [SP, #-0x10]!
    // 0xce22d0: r0 = getTransformTo()
    //     0xce22d0: bl              #0x643bcc  ; [package:flutter/src/rendering/object.dart] RenderObject::getTransformTo
    // 0xce22d4: add             SP, SP, #0x10
    // 0xce22d8: mov             x1, x0
    // 0xce22dc: ldur            x0, [fp, #-8]
    // 0xce22e0: stur            x1, [fp, #-0x10]
    // 0xce22e4: LoadField: r2 = r0->field_57
    //     0xce22e4: ldur            w2, [x0, #0x57]
    // 0xce22e8: DecompressPointer r2
    //     0xce22e8: add             x2, x2, HEAP, lsl #32
    // 0xce22ec: cmp             w2, NULL
    // 0xce22f0: b.eq            #0xce2358
    // 0xce22f4: LoadField: d0 = r2->field_7
    //     0xce22f4: ldur            d0, [x2, #7]
    // 0xce22f8: LoadField: d1 = r2->field_f
    //     0xce22f8: ldur            d1, [x2, #0xf]
    // 0xce22fc: d2 = 0.000000
    //     0xce22fc: eor             v2.16b, v2.16b, v2.16b
    // 0xce2300: fadd            d3, d2, d0
    // 0xce2304: stur            d3, [fp, #-0x20]
    // 0xce2308: fadd            d0, d2, d1
    // 0xce230c: stur            d0, [fp, #-0x18]
    // 0xce2310: r0 = Rect()
    //     0xce2310: bl              #0x4eed90  ; AllocateRectStub -> Rect (size=0x28)
    // 0xce2314: d0 = 0.000000
    //     0xce2314: eor             v0.16b, v0.16b, v0.16b
    // 0xce2318: StoreField: r0->field_7 = d0
    //     0xce2318: stur            d0, [x0, #7]
    // 0xce231c: StoreField: r0->field_f = d0
    //     0xce231c: stur            d0, [x0, #0xf]
    // 0xce2320: ldur            d0, [fp, #-0x20]
    // 0xce2324: StoreField: r0->field_17 = d0
    //     0xce2324: stur            d0, [x0, #0x17]
    // 0xce2328: ldur            d0, [fp, #-0x18]
    // 0xce232c: StoreField: r0->field_1f = d0
    //     0xce232c: stur            d0, [x0, #0x1f]
    // 0xce2330: ldur            x16, [fp, #-0x10]
    // 0xce2334: stp             x0, x16, [SP, #-0x10]!
    // 0xce2338: r0 = transformRect()
    //     0xce2338: bl              #0x6431fc  ; [package:flutter/src/painting/matrix_utils.dart] MatrixUtils::transformRect
    // 0xce233c: add             SP, SP, #0x10
    // 0xce2340: LeaveFrame
    //     0xce2340: mov             SP, fp
    //     0xce2344: ldp             fp, lr, [SP], #0x10
    // 0xce2348: ret
    //     0xce2348: ret             
    // 0xce234c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xce234c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xce2350: b               #0xce2238
    // 0xce2354: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce2354: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0xce2358: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0xce2358: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
}

// class id: 3479, size: 0x1c, field offset: 0x18
//   const constructor, 
class ScribblePlaceholder extends WidgetSpan {

  PlaceholderAlignment field_c;
  SizedBox field_14;
  Size field_18;
}

// class id: 4185, size: 0x20, field offset: 0xc
//   const constructor, 
class ScribbleFocusable extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3fba8, size: 0x4c
    // 0xa3fba8: EnterFrame
    //     0xa3fba8: stp             fp, lr, [SP, #-0x10]!
    //     0xa3fbac: mov             fp, SP
    // 0xa3fbb0: AllocStack(0x8)
    //     0xa3fbb0: sub             SP, SP, #8
    // 0xa3fbb4: CheckStackOverflow
    //     0xa3fbb4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa3fbb8: cmp             SP, x16
    //     0xa3fbbc: b.ls            #0xa3fbec
    // 0xa3fbc0: r1 = <ScribbleFocusable>
    //     0xa3fbc0: add             x1, PP, #0x55, lsl #12  ; [pp+0x55940] TypeArguments: <ScribbleFocusable>
    //     0xa3fbc4: ldr             x1, [x1, #0x940]
    // 0xa3fbc8: r0 = _ScribbleFocusableState()
    //     0xa3fbc8: bl              #0xa3fca0  ; Allocate_ScribbleFocusableStateStub -> _ScribbleFocusableState (size=0x18)
    // 0xa3fbcc: stur            x0, [fp, #-8]
    // 0xa3fbd0: SaveReg r0
    //     0xa3fbd0: str             x0, [SP, #-8]!
    // 0xa3fbd4: r0 = _ScribbleFocusableState()
    //     0xa3fbd4: bl              #0xa3fbf4  ; [package:extended_text_library/src/selection/scribble_focusable.dart] _ScribbleFocusableState::_ScribbleFocusableState
    // 0xa3fbd8: add             SP, SP, #8
    // 0xa3fbdc: ldur            x0, [fp, #-8]
    // 0xa3fbe0: LeaveFrame
    //     0xa3fbe0: mov             SP, fp
    //     0xa3fbe4: ldp             fp, lr, [SP], #0x10
    // 0xa3fbe8: ret
    //     0xa3fbe8: ret             
    // 0xa3fbec: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa3fbec: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa3fbf0: b               #0xa3fbc0
  }
}

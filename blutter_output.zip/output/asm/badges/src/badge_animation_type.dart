// lib: , url: package:badges/src/badge_animation_type.dart

// class id: 1048687, size: 0x8
class :: {
}

// class id: 6026, size: 0x14, field offset: 0x14
enum BadgeAnimationType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb14ee4, size: 0x5c
    // 0xb14ee4: EnterFrame
    //     0xb14ee4: stp             fp, lr, [SP, #-0x10]!
    //     0xb14ee8: mov             fp, SP
    // 0xb14eec: CheckStackOverflow
    //     0xb14eec: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb14ef0: cmp             SP, x16
    //     0xb14ef4: b.ls            #0xb14f38
    // 0xb14ef8: r1 = Null
    //     0xb14ef8: mov             x1, NULL
    // 0xb14efc: r2 = 4
    //     0xb14efc: mov             x2, #4
    // 0xb14f00: r0 = AllocateArray()
    //     0xb14f00: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb14f04: r17 = "BadgeAnimationType."
    //     0xb14f04: add             x17, PP, #0x38, lsl #12  ; [pp+0x38780] "BadgeAnimationType."
    //     0xb14f08: ldr             x17, [x17, #0x780]
    // 0xb14f0c: StoreField: r0->field_f = r17
    //     0xb14f0c: stur            w17, [x0, #0xf]
    // 0xb14f10: ldr             x1, [fp, #0x10]
    // 0xb14f14: LoadField: r2 = r1->field_f
    //     0xb14f14: ldur            w2, [x1, #0xf]
    // 0xb14f18: DecompressPointer r2
    //     0xb14f18: add             x2, x2, HEAP, lsl #32
    // 0xb14f1c: StoreField: r0->field_13 = r2
    //     0xb14f1c: stur            w2, [x0, #0x13]
    // 0xb14f20: SaveReg r0
    //     0xb14f20: str             x0, [SP, #-8]!
    // 0xb14f24: r0 = _interpolate()
    //     0xb14f24: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb14f28: add             SP, SP, #8
    // 0xb14f2c: LeaveFrame
    //     0xb14f2c: mov             SP, fp
    //     0xb14f30: ldp             fp, lr, [SP], #0x10
    // 0xb14f34: ret
    //     0xb14f34: ret             
    // 0xb14f38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb14f38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb14f3c: b               #0xb14ef8
  }
}

// lib: , url: package:badges/src/painters/instagram_badge_shape_painter.dart

// class id: 1048695, size: 0x8
class :: {
}

// class id: 4391, size: 0x1c, field offset: 0xc
class InstagramBadgeShapePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa6b8dc, size: 0xa84
    // 0xa6b8dc: EnterFrame
    //     0xa6b8dc: stp             fp, lr, [SP, #-0x10]!
    //     0xa6b8e0: mov             fp, SP
    // 0xa6b8e4: AllocStack(0x58)
    //     0xa6b8e4: sub             SP, SP, #0x58
    // 0xa6b8e8: CheckStackOverflow
    //     0xa6b8e8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6b8ec: cmp             SP, x16
    //     0xa6b8f0: b.ls            #0xa6c190
    // 0xa6b8f4: ldr             x0, [fp, #0x10]
    // 0xa6b8f8: LoadField: d0 = r0->field_7
    //     0xa6b8f8: ldur            d0, [x0, #7]
    // 0xa6b8fc: stur            d0, [fp, #-0x40]
    // 0xa6b900: LoadField: d1 = r0->field_f
    //     0xa6b900: ldur            d1, [x0, #0xf]
    // 0xa6b904: stur            d1, [fp, #-0x38]
    // 0xa6b908: r0 = Path()
    //     0xa6b908: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6b90c: stur            x0, [fp, #-8]
    // 0xa6b910: SaveReg r0
    //     0xa6b910: str             x0, [SP, #-8]!
    // 0xa6b914: r0 = _constructor()
    //     0xa6b914: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6b918: add             SP, SP, #8
    // 0xa6b91c: r16 = 112
    //     0xa6b91c: mov             x16, #0x70
    // 0xa6b920: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6b924: r0 = ByteData()
    //     0xa6b924: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6b928: add             SP, SP, #0x10
    // 0xa6b92c: stur            x0, [fp, #-0x10]
    // 0xa6b930: r0 = Paint()
    //     0xa6b930: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6b934: mov             x1, x0
    // 0xa6b938: ldur            x0, [fp, #-0x10]
    // 0xa6b93c: stur            x1, [fp, #-0x18]
    // 0xa6b940: StoreField: r1->field_7 = r0
    //     0xa6b940: stur            w0, [x1, #7]
    // 0xa6b944: r16 = 112
    //     0xa6b944: mov             x16, #0x70
    // 0xa6b948: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6b94c: r0 = ByteData()
    //     0xa6b94c: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6b950: add             SP, SP, #0x10
    // 0xa6b954: stur            x0, [fp, #-0x20]
    // 0xa6b958: r0 = Paint()
    //     0xa6b958: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6b95c: mov             x1, x0
    // 0xa6b960: ldur            x0, [fp, #-0x20]
    // 0xa6b964: stur            x1, [fp, #-0x28]
    // 0xa6b968: StoreField: r1->field_7 = r0
    //     0xa6b968: stur            w0, [x1, #7]
    // 0xa6b96c: LoadField: r2 = r0->field_17
    //     0xa6b96c: ldur            w2, [x0, #0x17]
    // 0xa6b970: DecompressPointer r2
    //     0xa6b970: add             x2, x2, HEAP, lsl #32
    // 0xa6b974: LoadField: r0 = r2->field_7
    //     0xa6b974: ldur            x0, [x2, #7]
    // 0xa6b978: str             wzr, [x0, #4]
    // 0xa6b97c: LoadField: r0 = r2->field_7
    //     0xa6b97c: ldur            x0, [x2, #7]
    // 0xa6b980: r3 = 1
    //     0xa6b980: mov             x3, #1
    // 0xa6b984: str             w3, [x0, #0xc]
    // 0xa6b988: LoadField: r0 = r2->field_7
    //     0xa6b988: ldur            x0, [x2, #7]
    // 0xa6b98c: str             w3, [x0, #0x14]
    // 0xa6b990: r0 = Instance_BorderSide
    //     0xa6b990: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa6b994: ldr             x0, [x0, #0x2f0]
    // 0xa6b998: LoadField: d0 = r0->field_b
    //     0xa6b998: ldur            d0, [x0, #0xb]
    // 0xa6b99c: fcvt            s1, d0
    // 0xa6b9a0: LoadField: r0 = r2->field_7
    //     0xa6b9a0: ldur            x0, [x2, #7]
    // 0xa6b9a4: str             s1, [x0, #0x10]
    // 0xa6b9a8: ldur            d1, [fp, #-0x40]
    // 0xa6b9ac: d0 = 0.140000
    //     0xa6b9ac: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb28] IMM: double(0.14) from 0x3fc1eb851eb851ec
    //     0xa6b9b0: ldr             d0, [x17, #0xb28]
    // 0xa6b9b4: fmul            d2, d1, d0
    // 0xa6b9b8: ldur            d3, [fp, #-0x38]
    // 0xa6b9bc: fmul            d4, d3, d0
    // 0xa6b9c0: stur            d4, [fp, #-0x48]
    // 0xa6b9c4: r0 = inline_Allocate_Double()
    //     0xa6b9c4: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xa6b9c8: add             x0, x0, #0x10
    //     0xa6b9cc: cmp             x2, x0
    //     0xa6b9d0: b.ls            #0xa6c198
    //     0xa6b9d4: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6b9d8: sub             x0, x0, #0xf
    //     0xa6b9dc: mov             x2, #0xd108
    //     0xa6b9e0: movk            x2, #3, lsl #16
    //     0xa6b9e4: stur            x2, [x0, #-1]
    // 0xa6b9e8: StoreField: r0->field_7 = d2
    //     0xa6b9e8: stur            d2, [x0, #7]
    // 0xa6b9ec: stur            x0, [fp, #-0x20]
    // 0xa6b9f0: ldur            x16, [fp, #-8]
    // 0xa6b9f4: stp             x0, x16, [SP, #-0x10]!
    // 0xa6b9f8: SaveReg d4
    //     0xa6b9f8: str             d4, [SP, #-8]!
    // 0xa6b9fc: r0 = moveTo()
    //     0xa6b9fc: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6ba00: add             SP, SP, #0x18
    // 0xa6ba04: ldur            d0, [fp, #-0x40]
    // 0xa6ba08: d1 = 0.300000
    //     0xa6ba08: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c4f8] IMM: double(0.3) from 0x3fd3333333333333
    //     0xa6ba0c: ldr             d1, [x17, #0x4f8]
    // 0xa6ba10: fmul            d2, d0, d1
    // 0xa6ba14: r0 = inline_Allocate_Double()
    //     0xa6ba14: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6ba18: add             x0, x0, #0x10
    //     0xa6ba1c: cmp             x1, x0
    //     0xa6ba20: b.ls            #0xa6c1b8
    //     0xa6ba24: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6ba28: sub             x0, x0, #0xf
    //     0xa6ba2c: mov             x1, #0xd108
    //     0xa6ba30: movk            x1, #3, lsl #16
    //     0xa6ba34: stur            x1, [x0, #-1]
    // 0xa6ba38: StoreField: r0->field_7 = d2
    //     0xa6ba38: stur            d2, [x0, #7]
    // 0xa6ba3c: ldur            x16, [fp, #-8]
    // 0xa6ba40: stp             x0, x16, [SP, #-0x10]!
    // 0xa6ba44: ldur            d2, [fp, #-0x48]
    // 0xa6ba48: SaveReg d2
    //     0xa6ba48: str             d2, [SP, #-8]!
    // 0xa6ba4c: r0 = lineTo()
    //     0xa6ba4c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6ba50: add             SP, SP, #0x18
    // 0xa6ba54: ldur            d0, [fp, #-0x40]
    // 0xa6ba58: d1 = 0.385000
    //     0xa6ba58: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb30] IMM: double(0.385) from 0x3fd8a3d70a3d70a4
    //     0xa6ba5c: ldr             d1, [x17, #0xb30]
    // 0xa6ba60: fmul            d2, d0, d1
    // 0xa6ba64: r0 = inline_Allocate_Double()
    //     0xa6ba64: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6ba68: add             x0, x0, #0x10
    //     0xa6ba6c: cmp             x1, x0
    //     0xa6ba70: b.ls            #0xa6c1d0
    //     0xa6ba74: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6ba78: sub             x0, x0, #0xf
    //     0xa6ba7c: mov             x1, #0xd108
    //     0xa6ba80: movk            x1, #3, lsl #16
    //     0xa6ba84: stur            x1, [x0, #-1]
    // 0xa6ba88: StoreField: r0->field_7 = d2
    //     0xa6ba88: stur            d2, [x0, #7]
    // 0xa6ba8c: ldur            x16, [fp, #-8]
    // 0xa6ba90: stp             x0, x16, [SP, #-0x10]!
    // 0xa6ba94: SaveReg rZR
    //     0xa6ba94: str             xzr, [SP, #-8]!
    // 0xa6ba98: r0 = lineTo()
    //     0xa6ba98: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6ba9c: add             SP, SP, #0x18
    // 0xa6baa0: ldur            d0, [fp, #-0x40]
    // 0xa6baa4: d1 = 0.515000
    //     0xa6baa4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb38] IMM: double(0.515) from 0x3fe07ae147ae147b
    //     0xa6baa8: ldr             d1, [x17, #0xb38]
    // 0xa6baac: fmul            d2, d0, d1
    // 0xa6bab0: ldur            d1, [fp, #-0x38]
    // 0xa6bab4: d3 = 0.080000
    //     0xa6bab4: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xa6bab8: ldr             d3, [x17, #0xf80]
    // 0xa6babc: fmul            d4, d1, d3
    // 0xa6bac0: r0 = inline_Allocate_Double()
    //     0xa6bac0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bac4: add             x0, x0, #0x10
    //     0xa6bac8: cmp             x1, x0
    //     0xa6bacc: b.ls            #0xa6c1e0
    //     0xa6bad0: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bad4: sub             x0, x0, #0xf
    //     0xa6bad8: mov             x1, #0xd108
    //     0xa6badc: movk            x1, #3, lsl #16
    //     0xa6bae0: stur            x1, [x0, #-1]
    // 0xa6bae4: StoreField: r0->field_7 = d2
    //     0xa6bae4: stur            d2, [x0, #7]
    // 0xa6bae8: ldur            x16, [fp, #-8]
    // 0xa6baec: stp             x0, x16, [SP, #-0x10]!
    // 0xa6baf0: SaveReg d4
    //     0xa6baf0: str             d4, [SP, #-8]!
    // 0xa6baf4: r0 = lineTo()
    //     0xa6baf4: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6baf8: add             SP, SP, #0x18
    // 0xa6bafc: ldur            d0, [fp, #-0x40]
    // 0xa6bb00: d1 = 0.627000
    //     0xa6bb00: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb40] IMM: double(0.627) from 0x3fe410624dd2f1aa
    //     0xa6bb04: ldr             d1, [x17, #0xb40]
    // 0xa6bb08: fmul            d2, d0, d1
    // 0xa6bb0c: ldur            d1, [fp, #-0x38]
    // 0xa6bb10: d3 = 0.012000
    //     0xa6bb10: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb48] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0xa6bb14: ldr             d3, [x17, #0xb48]
    // 0xa6bb18: fmul            d4, d1, d3
    // 0xa6bb1c: r0 = inline_Allocate_Double()
    //     0xa6bb1c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bb20: add             x0, x0, #0x10
    //     0xa6bb24: cmp             x1, x0
    //     0xa6bb28: b.ls            #0xa6c200
    //     0xa6bb2c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bb30: sub             x0, x0, #0xf
    //     0xa6bb34: mov             x1, #0xd108
    //     0xa6bb38: movk            x1, #3, lsl #16
    //     0xa6bb3c: stur            x1, [x0, #-1]
    // 0xa6bb40: StoreField: r0->field_7 = d2
    //     0xa6bb40: stur            d2, [x0, #7]
    // 0xa6bb44: ldur            x16, [fp, #-8]
    // 0xa6bb48: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bb4c: SaveReg d4
    //     0xa6bb4c: str             d4, [SP, #-8]!
    // 0xa6bb50: r0 = lineTo()
    //     0xa6bb50: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bb54: add             SP, SP, #0x18
    // 0xa6bb58: ldur            d0, [fp, #-0x40]
    // 0xa6bb5c: d1 = 0.700000
    //     0xa6bb5c: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c2f0] IMM: double(0.7) from 0x3fe6666666666666
    //     0xa6bb60: ldr             d1, [x17, #0x2f0]
    // 0xa6bb64: fmul            d2, d0, d1
    // 0xa6bb68: ldur            d1, [fp, #-0x38]
    // 0xa6bb6c: d3 = 0.134000
    //     0xa6bb6c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb50] IMM: double(0.134) from 0x3fc126e978d4fdf4
    //     0xa6bb70: ldr             d3, [x17, #0xb50]
    // 0xa6bb74: fmul            d4, d1, d3
    // 0xa6bb78: stur            d4, [fp, #-0x50]
    // 0xa6bb7c: r0 = inline_Allocate_Double()
    //     0xa6bb7c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bb80: add             x0, x0, #0x10
    //     0xa6bb84: cmp             x1, x0
    //     0xa6bb88: b.ls            #0xa6c220
    //     0xa6bb8c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bb90: sub             x0, x0, #0xf
    //     0xa6bb94: mov             x1, #0xd108
    //     0xa6bb98: movk            x1, #3, lsl #16
    //     0xa6bb9c: stur            x1, [x0, #-1]
    // 0xa6bba0: StoreField: r0->field_7 = d2
    //     0xa6bba0: stur            d2, [x0, #7]
    // 0xa6bba4: ldur            x16, [fp, #-8]
    // 0xa6bba8: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bbac: SaveReg d4
    //     0xa6bbac: str             d4, [SP, #-8]!
    // 0xa6bbb0: r0 = lineTo()
    //     0xa6bbb0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bbb4: add             SP, SP, #0x18
    // 0xa6bbb8: ldur            d0, [fp, #-0x40]
    // 0xa6bbbc: d1 = 0.867000
    //     0xa6bbbc: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb58] IMM: double(0.867) from 0x3febbe76c8b43958
    //     0xa6bbc0: ldr             d1, [x17, #0xb58]
    // 0xa6bbc4: fmul            d2, d0, d1
    // 0xa6bbc8: r0 = inline_Allocate_Double()
    //     0xa6bbc8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bbcc: add             x0, x0, #0x10
    //     0xa6bbd0: cmp             x1, x0
    //     0xa6bbd4: b.ls            #0xa6c238
    //     0xa6bbd8: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bbdc: sub             x0, x0, #0xf
    //     0xa6bbe0: mov             x1, #0xd108
    //     0xa6bbe4: movk            x1, #3, lsl #16
    //     0xa6bbe8: stur            x1, [x0, #-1]
    // 0xa6bbec: StoreField: r0->field_7 = d2
    //     0xa6bbec: stur            d2, [x0, #7]
    // 0xa6bbf0: stur            x0, [fp, #-0x30]
    // 0xa6bbf4: ldur            x16, [fp, #-8]
    // 0xa6bbf8: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bbfc: ldur            d1, [fp, #-0x50]
    // 0xa6bc00: SaveReg d1
    //     0xa6bc00: str             d1, [SP, #-8]!
    // 0xa6bc04: r0 = lineTo()
    //     0xa6bc04: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bc08: add             SP, SP, #0x18
    // 0xa6bc0c: ldur            d0, [fp, #-0x38]
    // 0xa6bc10: d1 = 0.300000
    //     0xa6bc10: add             x17, PP, #0x1c, lsl #12  ; [pp+0x1c4f8] IMM: double(0.3) from 0x3fd3333333333333
    //     0xa6bc14: ldr             d1, [x17, #0x4f8]
    // 0xa6bc18: fmul            d2, d0, d1
    // 0xa6bc1c: ldur            x16, [fp, #-8]
    // 0xa6bc20: ldur            lr, [fp, #-0x30]
    // 0xa6bc24: stp             lr, x16, [SP, #-0x10]!
    // 0xa6bc28: SaveReg d2
    //     0xa6bc28: str             d2, [SP, #-8]!
    // 0xa6bc2c: r0 = lineTo()
    //     0xa6bc2c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bc30: add             SP, SP, #0x18
    // 0xa6bc34: ldur            d0, [fp, #-0x38]
    // 0xa6bc38: d1 = 0.380000
    //     0xa6bc38: add             x17, PP, #0xe, lsl #12  ; [pp+0xe140] IMM: double(0.38) from 0x3fd851eb851eb852
    //     0xa6bc3c: ldr             d1, [x17, #0x140]
    // 0xa6bc40: fmul            d2, d0, d1
    // 0xa6bc44: ldur            d1, [fp, #-0x40]
    // 0xa6bc48: r0 = inline_Allocate_Double()
    //     0xa6bc48: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bc4c: add             x0, x0, #0x10
    //     0xa6bc50: cmp             x1, x0
    //     0xa6bc54: b.ls            #0xa6c248
    //     0xa6bc58: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bc5c: sub             x0, x0, #0xf
    //     0xa6bc60: mov             x1, #0xd108
    //     0xa6bc64: movk            x1, #3, lsl #16
    //     0xa6bc68: stur            x1, [x0, #-1]
    // 0xa6bc6c: StoreField: r0->field_7 = d1
    //     0xa6bc6c: stur            d1, [x0, #7]
    // 0xa6bc70: ldur            x16, [fp, #-8]
    // 0xa6bc74: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bc78: SaveReg d2
    //     0xa6bc78: str             d2, [SP, #-8]!
    // 0xa6bc7c: r0 = lineTo()
    //     0xa6bc7c: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bc80: add             SP, SP, #0x18
    // 0xa6bc84: ldur            d0, [fp, #-0x40]
    // 0xa6bc88: d1 = 0.922000
    //     0xa6bc88: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb60] IMM: double(0.922) from 0x3fed810624dd2f1b
    //     0xa6bc8c: ldr             d1, [x17, #0xb60]
    // 0xa6bc90: fmul            d2, d0, d1
    // 0xa6bc94: ldur            d1, [fp, #-0x38]
    // 0xa6bc98: d3 = 0.505000
    //     0xa6bc98: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb68] IMM: double(0.505) from 0x3fe028f5c28f5c29
    //     0xa6bc9c: ldr             d3, [x17, #0xb68]
    // 0xa6bca0: fmul            d4, d1, d3
    // 0xa6bca4: r0 = inline_Allocate_Double()
    //     0xa6bca4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bca8: add             x0, x0, #0x10
    //     0xa6bcac: cmp             x1, x0
    //     0xa6bcb0: b.ls            #0xa6c260
    //     0xa6bcb4: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bcb8: sub             x0, x0, #0xf
    //     0xa6bcbc: mov             x1, #0xd108
    //     0xa6bcc0: movk            x1, #3, lsl #16
    //     0xa6bcc4: stur            x1, [x0, #-1]
    // 0xa6bcc8: StoreField: r0->field_7 = d2
    //     0xa6bcc8: stur            d2, [x0, #7]
    // 0xa6bccc: ldur            x16, [fp, #-8]
    // 0xa6bcd0: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bcd4: SaveReg d4
    //     0xa6bcd4: str             d4, [SP, #-8]!
    // 0xa6bcd8: r0 = lineTo()
    //     0xa6bcd8: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bcdc: add             SP, SP, #0x18
    // 0xa6bce0: ldur            d0, [fp, #-0x40]
    // 0xa6bce4: d1 = 0.995000
    //     0xa6bce4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb70] IMM: double(0.995) from 0x3fefd70a3d70a3d7
    //     0xa6bce8: ldr             d1, [x17, #0xb70]
    // 0xa6bcec: fmul            d2, d0, d1
    // 0xa6bcf0: ldur            d1, [fp, #-0x38]
    // 0xa6bcf4: d3 = 0.629000
    //     0xa6bcf4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb78] IMM: double(0.629) from 0x3fe420c49ba5e354
    //     0xa6bcf8: ldr             d3, [x17, #0xb78]
    // 0xa6bcfc: fmul            d4, d1, d3
    // 0xa6bd00: r0 = inline_Allocate_Double()
    //     0xa6bd00: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bd04: add             x0, x0, #0x10
    //     0xa6bd08: cmp             x1, x0
    //     0xa6bd0c: b.ls            #0xa6c278
    //     0xa6bd10: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bd14: sub             x0, x0, #0xf
    //     0xa6bd18: mov             x1, #0xd108
    //     0xa6bd1c: movk            x1, #3, lsl #16
    //     0xa6bd20: stur            x1, [x0, #-1]
    // 0xa6bd24: StoreField: r0->field_7 = d2
    //     0xa6bd24: stur            d2, [x0, #7]
    // 0xa6bd28: ldur            x16, [fp, #-8]
    // 0xa6bd2c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bd30: SaveReg d4
    //     0xa6bd30: str             d4, [SP, #-8]!
    // 0xa6bd34: r0 = lineTo()
    //     0xa6bd34: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bd38: add             SP, SP, #0x18
    // 0xa6bd3c: ldur            d0, [fp, #-0x40]
    // 0xa6bd40: d1 = 0.866000
    //     0xa6bd40: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb80] IMM: double(0.866) from 0x3febb645a1cac083
    //     0xa6bd44: ldr             d1, [x17, #0xb80]
    // 0xa6bd48: fmul            d2, d0, d1
    // 0xa6bd4c: ldur            d1, [fp, #-0x38]
    // 0xa6bd50: d3 = 0.706000
    //     0xa6bd50: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb88] IMM: double(0.706) from 0x3fe6978d4fdf3b64
    //     0xa6bd54: ldr             d3, [x17, #0xb88]
    // 0xa6bd58: fmul            d4, d1, d3
    // 0xa6bd5c: r0 = inline_Allocate_Double()
    //     0xa6bd5c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bd60: add             x0, x0, #0x10
    //     0xa6bd64: cmp             x1, x0
    //     0xa6bd68: b.ls            #0xa6c290
    //     0xa6bd6c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bd70: sub             x0, x0, #0xf
    //     0xa6bd74: mov             x1, #0xd108
    //     0xa6bd78: movk            x1, #3, lsl #16
    //     0xa6bd7c: stur            x1, [x0, #-1]
    // 0xa6bd80: StoreField: r0->field_7 = d2
    //     0xa6bd80: stur            d2, [x0, #7]
    // 0xa6bd84: stur            x0, [fp, #-0x30]
    // 0xa6bd88: ldur            x16, [fp, #-8]
    // 0xa6bd8c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bd90: SaveReg d4
    //     0xa6bd90: str             d4, [SP, #-8]!
    // 0xa6bd94: r0 = lineTo()
    //     0xa6bd94: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bd98: add             SP, SP, #0x18
    // 0xa6bd9c: ldur            d0, [fp, #-0x38]
    // 0xa6bda0: d1 = 0.868000
    //     0xa6bda0: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb90] IMM: double(0.868) from 0x3febc6a7ef9db22d
    //     0xa6bda4: ldr             d1, [x17, #0xb90]
    // 0xa6bda8: fmul            d2, d0, d1
    // 0xa6bdac: stur            d2, [fp, #-0x50]
    // 0xa6bdb0: ldur            x16, [fp, #-8]
    // 0xa6bdb4: ldur            lr, [fp, #-0x30]
    // 0xa6bdb8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6bdbc: SaveReg d2
    //     0xa6bdbc: str             d2, [SP, #-8]!
    // 0xa6bdc0: r0 = lineTo()
    //     0xa6bdc0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bdc4: add             SP, SP, #0x18
    // 0xa6bdc8: ldur            d0, [fp, #-0x40]
    // 0xa6bdcc: d1 = 0.697000
    //     0xa6bdcc: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb98] IMM: double(0.697) from 0x3fe64dd2f1a9fbe7
    //     0xa6bdd0: ldr             d1, [x17, #0xb98]
    // 0xa6bdd4: fmul            d2, d0, d1
    // 0xa6bdd8: r0 = inline_Allocate_Double()
    //     0xa6bdd8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bddc: add             x0, x0, #0x10
    //     0xa6bde0: cmp             x1, x0
    //     0xa6bde4: b.ls            #0xa6c2a8
    //     0xa6bde8: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bdec: sub             x0, x0, #0xf
    //     0xa6bdf0: mov             x1, #0xd108
    //     0xa6bdf4: movk            x1, #3, lsl #16
    //     0xa6bdf8: stur            x1, [x0, #-1]
    // 0xa6bdfc: StoreField: r0->field_7 = d2
    //     0xa6bdfc: stur            d2, [x0, #7]
    // 0xa6be00: ldur            x16, [fp, #-8]
    // 0xa6be04: stp             x0, x16, [SP, #-0x10]!
    // 0xa6be08: ldur            d1, [fp, #-0x50]
    // 0xa6be0c: SaveReg d1
    //     0xa6be0c: str             d1, [SP, #-8]!
    // 0xa6be10: r0 = lineTo()
    //     0xa6be10: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6be14: add             SP, SP, #0x18
    // 0xa6be18: ldur            d0, [fp, #-0x40]
    // 0xa6be1c: d1 = 0.618000
    //     0xa6be1c: add             x17, PP, #0x20, lsl #12  ; [pp+0x207e8] IMM: double(0.618) from 0x3fe3c6a7ef9db22d
    //     0xa6be20: ldr             d1, [x17, #0x7e8]
    // 0xa6be24: fmul            d2, d0, d1
    // 0xa6be28: ldur            d3, [fp, #-0x38]
    // 0xa6be2c: d4 = 0.996000
    //     0xa6be2c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cba0] IMM: double(0.996) from 0x3fefdf3b645a1cac
    //     0xa6be30: ldr             d4, [x17, #0xba0]
    // 0xa6be34: fmul            d5, d3, d4
    // 0xa6be38: stur            d5, [fp, #-0x58]
    // 0xa6be3c: r0 = inline_Allocate_Double()
    //     0xa6be3c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6be40: add             x0, x0, #0x10
    //     0xa6be44: cmp             x1, x0
    //     0xa6be48: b.ls            #0xa6c2b8
    //     0xa6be4c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6be50: sub             x0, x0, #0xf
    //     0xa6be54: mov             x1, #0xd108
    //     0xa6be58: movk            x1, #3, lsl #16
    //     0xa6be5c: stur            x1, [x0, #-1]
    // 0xa6be60: StoreField: r0->field_7 = d2
    //     0xa6be60: stur            d2, [x0, #7]
    // 0xa6be64: ldur            x16, [fp, #-8]
    // 0xa6be68: stp             x0, x16, [SP, #-0x10]!
    // 0xa6be6c: SaveReg d5
    //     0xa6be6c: str             d5, [SP, #-8]!
    // 0xa6be70: r0 = lineTo()
    //     0xa6be70: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6be74: add             SP, SP, #0x18
    // 0xa6be78: ldur            d0, [fp, #-0x40]
    // 0xa6be7c: d1 = 0.500000
    //     0xa6be7c: fmov            d1, #0.50000000
    // 0xa6be80: fmul            d2, d0, d1
    // 0xa6be84: ldur            d1, [fp, #-0x38]
    // 0xa6be88: d3 = 0.924000
    //     0xa6be88: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cba8] IMM: double(0.924) from 0x3fed916872b020c5
    //     0xa6be8c: ldr             d3, [x17, #0xba8]
    // 0xa6be90: fmul            d4, d1, d3
    // 0xa6be94: r0 = inline_Allocate_Double()
    //     0xa6be94: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6be98: add             x0, x0, #0x10
    //     0xa6be9c: cmp             x1, x0
    //     0xa6bea0: b.ls            #0xa6c2d8
    //     0xa6bea4: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bea8: sub             x0, x0, #0xf
    //     0xa6beac: mov             x1, #0xd108
    //     0xa6beb0: movk            x1, #3, lsl #16
    //     0xa6beb4: stur            x1, [x0, #-1]
    // 0xa6beb8: StoreField: r0->field_7 = d2
    //     0xa6beb8: stur            d2, [x0, #7]
    // 0xa6bebc: ldur            x16, [fp, #-8]
    // 0xa6bec0: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bec4: SaveReg d4
    //     0xa6bec4: str             d4, [SP, #-8]!
    // 0xa6bec8: r0 = lineTo()
    //     0xa6bec8: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6becc: add             SP, SP, #0x18
    // 0xa6bed0: ldur            d0, [fp, #-0x40]
    // 0xa6bed4: d1 = 0.379000
    //     0xa6bed4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbb0] IMM: double(0.379) from 0x3fd84189374bc6a8
    //     0xa6bed8: ldr             d1, [x17, #0xbb0]
    // 0xa6bedc: fmul            d2, d0, d1
    // 0xa6bee0: r0 = inline_Allocate_Double()
    //     0xa6bee0: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bee4: add             x0, x0, #0x10
    //     0xa6bee8: cmp             x1, x0
    //     0xa6beec: b.ls            #0xa6c2f0
    //     0xa6bef0: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bef4: sub             x0, x0, #0xf
    //     0xa6bef8: mov             x1, #0xd108
    //     0xa6befc: movk            x1, #3, lsl #16
    //     0xa6bf00: stur            x1, [x0, #-1]
    // 0xa6bf04: StoreField: r0->field_7 = d2
    //     0xa6bf04: stur            d2, [x0, #7]
    // 0xa6bf08: ldur            x16, [fp, #-8]
    // 0xa6bf0c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bf10: ldur            d2, [fp, #-0x58]
    // 0xa6bf14: SaveReg d2
    //     0xa6bf14: str             d2, [SP, #-8]!
    // 0xa6bf18: r0 = lineTo()
    //     0xa6bf18: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bf1c: add             SP, SP, #0x18
    // 0xa6bf20: ldur            d0, [fp, #-0x40]
    // 0xa6bf24: d1 = 0.302000
    //     0xa6bf24: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbb8] IMM: double(0.302) from 0x3fd353f7ced91687
    //     0xa6bf28: ldr             d1, [x17, #0xbb8]
    // 0xa6bf2c: fmul            d2, d0, d1
    // 0xa6bf30: r0 = inline_Allocate_Double()
    //     0xa6bf30: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bf34: add             x0, x0, #0x10
    //     0xa6bf38: cmp             x1, x0
    //     0xa6bf3c: b.ls            #0xa6c308
    //     0xa6bf40: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bf44: sub             x0, x0, #0xf
    //     0xa6bf48: mov             x1, #0xd108
    //     0xa6bf4c: movk            x1, #3, lsl #16
    //     0xa6bf50: stur            x1, [x0, #-1]
    // 0xa6bf54: StoreField: r0->field_7 = d2
    //     0xa6bf54: stur            d2, [x0, #7]
    // 0xa6bf58: ldur            x16, [fp, #-8]
    // 0xa6bf5c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6bf60: ldur            d1, [fp, #-0x50]
    // 0xa6bf64: SaveReg d1
    //     0xa6bf64: str             d1, [SP, #-8]!
    // 0xa6bf68: r0 = lineTo()
    //     0xa6bf68: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bf6c: add             SP, SP, #0x18
    // 0xa6bf70: ldur            x16, [fp, #-8]
    // 0xa6bf74: ldur            lr, [fp, #-0x20]
    // 0xa6bf78: stp             lr, x16, [SP, #-0x10]!
    // 0xa6bf7c: ldur            d0, [fp, #-0x50]
    // 0xa6bf80: SaveReg d0
    //     0xa6bf80: str             d0, [SP, #-8]!
    // 0xa6bf84: r0 = lineTo()
    //     0xa6bf84: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bf88: add             SP, SP, #0x18
    // 0xa6bf8c: ldur            d0, [fp, #-0x38]
    // 0xa6bf90: d1 = 0.702000
    //     0xa6bf90: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbc0] IMM: double(0.702) from 0x3fe676c8b4395810
    //     0xa6bf94: ldr             d1, [x17, #0xbc0]
    // 0xa6bf98: fmul            d2, d0, d1
    // 0xa6bf9c: ldur            x16, [fp, #-8]
    // 0xa6bfa0: ldur            lr, [fp, #-0x20]
    // 0xa6bfa4: stp             lr, x16, [SP, #-0x10]!
    // 0xa6bfa8: SaveReg d2
    //     0xa6bfa8: str             d2, [SP, #-8]!
    // 0xa6bfac: r0 = lineTo()
    //     0xa6bfac: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6bfb0: add             SP, SP, #0x18
    // 0xa6bfb4: ldur            d0, [fp, #-0x40]
    // 0xa6bfb8: d1 = 0.004000
    //     0xa6bfb8: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbc8] IMM: double(0.004) from 0x3f70624dd2f1a9fc
    //     0xa6bfbc: ldr             d1, [x17, #0xbc8]
    // 0xa6bfc0: fmul            d2, d0, d1
    // 0xa6bfc4: ldur            d1, [fp, #-0x38]
    // 0xa6bfc8: d3 = 0.618000
    //     0xa6bfc8: add             x17, PP, #0x20, lsl #12  ; [pp+0x207e8] IMM: double(0.618) from 0x3fe3c6a7ef9db22d
    //     0xa6bfcc: ldr             d3, [x17, #0x7e8]
    // 0xa6bfd0: fmul            d4, d1, d3
    // 0xa6bfd4: r0 = inline_Allocate_Double()
    //     0xa6bfd4: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6bfd8: add             x0, x0, #0x10
    //     0xa6bfdc: cmp             x1, x0
    //     0xa6bfe0: b.ls            #0xa6c318
    //     0xa6bfe4: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6bfe8: sub             x0, x0, #0xf
    //     0xa6bfec: mov             x1, #0xd108
    //     0xa6bff0: movk            x1, #3, lsl #16
    //     0xa6bff4: stur            x1, [x0, #-1]
    // 0xa6bff8: StoreField: r0->field_7 = d2
    //     0xa6bff8: stur            d2, [x0, #7]
    // 0xa6bffc: ldur            x16, [fp, #-8]
    // 0xa6c000: stp             x0, x16, [SP, #-0x10]!
    // 0xa6c004: SaveReg d4
    //     0xa6c004: str             d4, [SP, #-8]!
    // 0xa6c008: r0 = lineTo()
    //     0xa6c008: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6c00c: add             SP, SP, #0x18
    // 0xa6c010: ldur            d0, [fp, #-0x40]
    // 0xa6c014: d1 = 0.080000
    //     0xa6c014: add             x17, PP, #0xd, lsl #12  ; [pp+0xdf80] IMM: double(0.08) from 0x3fb47ae147ae147b
    //     0xa6c018: ldr             d1, [x17, #0xf80]
    // 0xa6c01c: fmul            d2, d0, d1
    // 0xa6c020: ldur            d1, [fp, #-0x38]
    // 0xa6c024: d3 = 0.494000
    //     0xa6c024: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbd0] IMM: double(0.494) from 0x3fdf9db22d0e5604
    //     0xa6c028: ldr             d3, [x17, #0xbd0]
    // 0xa6c02c: fmul            d4, d1, d3
    // 0xa6c030: r0 = inline_Allocate_Double()
    //     0xa6c030: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6c034: add             x0, x0, #0x10
    //     0xa6c038: cmp             x1, x0
    //     0xa6c03c: b.ls            #0xa6c330
    //     0xa6c040: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6c044: sub             x0, x0, #0xf
    //     0xa6c048: mov             x1, #0xd108
    //     0xa6c04c: movk            x1, #3, lsl #16
    //     0xa6c050: stur            x1, [x0, #-1]
    // 0xa6c054: StoreField: r0->field_7 = d2
    //     0xa6c054: stur            d2, [x0, #7]
    // 0xa6c058: ldur            x16, [fp, #-8]
    // 0xa6c05c: stp             x0, x16, [SP, #-0x10]!
    // 0xa6c060: SaveReg d4
    //     0xa6c060: str             d4, [SP, #-8]!
    // 0xa6c064: r0 = lineTo()
    //     0xa6c064: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6c068: add             SP, SP, #0x18
    // 0xa6c06c: ldur            d0, [fp, #-0x40]
    // 0xa6c070: d1 = 0.012000
    //     0xa6c070: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb48] IMM: double(0.012) from 0x3f889374bc6a7efa
    //     0xa6c074: ldr             d1, [x17, #0xb48]
    // 0xa6c078: fmul            d2, d0, d1
    // 0xa6c07c: ldur            d0, [fp, #-0x38]
    // 0xa6c080: d1 = 0.379000
    //     0xa6c080: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbb0] IMM: double(0.379) from 0x3fd84189374bc6a8
    //     0xa6c084: ldr             d1, [x17, #0xbb0]
    // 0xa6c088: fmul            d3, d0, d1
    // 0xa6c08c: r0 = inline_Allocate_Double()
    //     0xa6c08c: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0xa6c090: add             x0, x0, #0x10
    //     0xa6c094: cmp             x1, x0
    //     0xa6c098: b.ls            #0xa6c348
    //     0xa6c09c: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6c0a0: sub             x0, x0, #0xf
    //     0xa6c0a4: mov             x1, #0xd108
    //     0xa6c0a8: movk            x1, #3, lsl #16
    //     0xa6c0ac: stur            x1, [x0, #-1]
    // 0xa6c0b0: StoreField: r0->field_7 = d2
    //     0xa6c0b0: stur            d2, [x0, #7]
    // 0xa6c0b4: ldur            x16, [fp, #-8]
    // 0xa6c0b8: stp             x0, x16, [SP, #-0x10]!
    // 0xa6c0bc: SaveReg d3
    //     0xa6c0bc: str             d3, [SP, #-8]!
    // 0xa6c0c0: r0 = lineTo()
    //     0xa6c0c0: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6c0c4: add             SP, SP, #0x18
    // 0xa6c0c8: ldur            d0, [fp, #-0x38]
    // 0xa6c0cc: d1 = 0.306000
    //     0xa6c0cc: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbd8] IMM: double(0.306) from 0x3fd395810624dd2f
    //     0xa6c0d0: ldr             d1, [x17, #0xbd8]
    // 0xa6c0d4: fmul            d2, d0, d1
    // 0xa6c0d8: ldur            x16, [fp, #-8]
    // 0xa6c0dc: ldur            lr, [fp, #-0x20]
    // 0xa6c0e0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c0e4: SaveReg d2
    //     0xa6c0e4: str             d2, [SP, #-8]!
    // 0xa6c0e8: r0 = lineTo()
    //     0xa6c0e8: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6c0ec: add             SP, SP, #0x18
    // 0xa6c0f0: ldur            x16, [fp, #-8]
    // 0xa6c0f4: ldur            lr, [fp, #-0x20]
    // 0xa6c0f8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c0fc: ldur            d0, [fp, #-0x48]
    // 0xa6c100: SaveReg d0
    //     0xa6c100: str             d0, [SP, #-8]!
    // 0xa6c104: r0 = lineTo()
    //     0xa6c104: bl              #0x668ffc  ; [dart:ui] Path::lineTo
    // 0xa6c108: add             SP, SP, #0x18
    // 0xa6c10c: ldur            x0, [fp, #-0x10]
    // 0xa6c110: LoadField: r1 = r0->field_17
    //     0xa6c110: ldur            w1, [x0, #0x17]
    // 0xa6c114: DecompressPointer r1
    //     0xa6c114: add             x1, x1, HEAP, lsl #32
    // 0xa6c118: LoadField: r0 = r1->field_7
    //     0xa6c118: ldur            x0, [x1, #7]
    // 0xa6c11c: r1 = 16007990
    //     0xa6c11c: mov             x1, #0x4336
    //     0xa6c120: movk            x1, #0xf4, lsl #16
    // 0xa6c124: str             w1, [x0, #4]
    // 0xa6c128: ldr             x16, [fp, #0x18]
    // 0xa6c12c: ldur            lr, [fp, #-8]
    // 0xa6c130: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c134: ldur            x16, [fp, #-0x18]
    // 0xa6c138: SaveReg r16
    //     0xa6c138: str             x16, [SP, #-8]!
    // 0xa6c13c: r0 = drawPath()
    //     0xa6c13c: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6c140: add             SP, SP, #0x18
    // 0xa6c144: r16 = Instance_BorderSide
    //     0xa6c144: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa6c148: ldr             x16, [x16, #0x2f0]
    // 0xa6c14c: r30 = Instance_BorderSide
    //     0xa6c14c: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa6c150: ldr             lr, [lr, #0x2f0]
    // 0xa6c154: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c158: r0 = ==()
    //     0xa6c158: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xa6c15c: add             SP, SP, #0x10
    // 0xa6c160: tbz             w0, #4, #0xa6c180
    // 0xa6c164: ldr             x16, [fp, #0x18]
    // 0xa6c168: ldur            lr, [fp, #-8]
    // 0xa6c16c: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c170: ldur            x16, [fp, #-0x28]
    // 0xa6c174: SaveReg r16
    //     0xa6c174: str             x16, [SP, #-8]!
    // 0xa6c178: r0 = drawPath()
    //     0xa6c178: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6c17c: add             SP, SP, #0x18
    // 0xa6c180: r0 = Null
    //     0xa6c180: mov             x0, NULL
    // 0xa6c184: LeaveFrame
    //     0xa6c184: mov             SP, fp
    //     0xa6c188: ldp             fp, lr, [SP], #0x10
    // 0xa6c18c: ret
    //     0xa6c18c: ret             
    // 0xa6c190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6c190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6c194: b               #0xa6b8f4
    // 0xa6c198: stp             q3, q4, [SP, #-0x20]!
    // 0xa6c19c: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c1a0: SaveReg r1
    //     0xa6c1a0: str             x1, [SP, #-8]!
    // 0xa6c1a4: r0 = AllocateDouble()
    //     0xa6c1a4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c1a8: RestoreReg r1
    //     0xa6c1a8: ldr             x1, [SP], #8
    // 0xa6c1ac: ldp             q1, q2, [SP], #0x20
    // 0xa6c1b0: ldp             q3, q4, [SP], #0x20
    // 0xa6c1b4: b               #0xa6b9e8
    // 0xa6c1b8: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c1bc: SaveReg d0
    //     0xa6c1bc: str             q0, [SP, #-0x10]!
    // 0xa6c1c0: r0 = AllocateDouble()
    //     0xa6c1c0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c1c4: RestoreReg d0
    //     0xa6c1c4: ldr             q0, [SP], #0x10
    // 0xa6c1c8: ldp             q1, q2, [SP], #0x20
    // 0xa6c1cc: b               #0xa6ba38
    // 0xa6c1d0: stp             q0, q2, [SP, #-0x20]!
    // 0xa6c1d4: r0 = AllocateDouble()
    //     0xa6c1d4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c1d8: ldp             q0, q2, [SP], #0x20
    // 0xa6c1dc: b               #0xa6ba88
    // 0xa6c1e0: stp             q3, q4, [SP, #-0x20]!
    // 0xa6c1e4: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c1e8: SaveReg d0
    //     0xa6c1e8: str             q0, [SP, #-0x10]!
    // 0xa6c1ec: r0 = AllocateDouble()
    //     0xa6c1ec: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c1f0: RestoreReg d0
    //     0xa6c1f0: ldr             q0, [SP], #0x10
    // 0xa6c1f4: ldp             q1, q2, [SP], #0x20
    // 0xa6c1f8: ldp             q3, q4, [SP], #0x20
    // 0xa6c1fc: b               #0xa6bae4
    // 0xa6c200: stp             q3, q4, [SP, #-0x20]!
    // 0xa6c204: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c208: SaveReg d0
    //     0xa6c208: str             q0, [SP, #-0x10]!
    // 0xa6c20c: r0 = AllocateDouble()
    //     0xa6c20c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c210: RestoreReg d0
    //     0xa6c210: ldr             q0, [SP], #0x10
    // 0xa6c214: ldp             q1, q2, [SP], #0x20
    // 0xa6c218: ldp             q3, q4, [SP], #0x20
    // 0xa6c21c: b               #0xa6bb40
    // 0xa6c220: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c224: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c228: r0 = AllocateDouble()
    //     0xa6c228: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c22c: ldp             q0, q1, [SP], #0x20
    // 0xa6c230: ldp             q2, q4, [SP], #0x20
    // 0xa6c234: b               #0xa6bba0
    // 0xa6c238: stp             q0, q2, [SP, #-0x20]!
    // 0xa6c23c: r0 = AllocateDouble()
    //     0xa6c23c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c240: ldp             q0, q2, [SP], #0x20
    // 0xa6c244: b               #0xa6bbec
    // 0xa6c248: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c24c: SaveReg d0
    //     0xa6c24c: str             q0, [SP, #-0x10]!
    // 0xa6c250: r0 = AllocateDouble()
    //     0xa6c250: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c254: RestoreReg d0
    //     0xa6c254: ldr             q0, [SP], #0x10
    // 0xa6c258: ldp             q1, q2, [SP], #0x20
    // 0xa6c25c: b               #0xa6bc6c
    // 0xa6c260: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c264: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c268: r0 = AllocateDouble()
    //     0xa6c268: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c26c: ldp             q0, q1, [SP], #0x20
    // 0xa6c270: ldp             q2, q4, [SP], #0x20
    // 0xa6c274: b               #0xa6bcc8
    // 0xa6c278: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c27c: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c280: r0 = AllocateDouble()
    //     0xa6c280: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c284: ldp             q0, q1, [SP], #0x20
    // 0xa6c288: ldp             q2, q4, [SP], #0x20
    // 0xa6c28c: b               #0xa6bd24
    // 0xa6c290: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c294: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c298: r0 = AllocateDouble()
    //     0xa6c298: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c29c: ldp             q0, q1, [SP], #0x20
    // 0xa6c2a0: ldp             q2, q4, [SP], #0x20
    // 0xa6c2a4: b               #0xa6bd80
    // 0xa6c2a8: stp             q0, q2, [SP, #-0x20]!
    // 0xa6c2ac: r0 = AllocateDouble()
    //     0xa6c2ac: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c2b0: ldp             q0, q2, [SP], #0x20
    // 0xa6c2b4: b               #0xa6bdfc
    // 0xa6c2b8: stp             q3, q5, [SP, #-0x20]!
    // 0xa6c2bc: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c2c0: SaveReg d0
    //     0xa6c2c0: str             q0, [SP, #-0x10]!
    // 0xa6c2c4: r0 = AllocateDouble()
    //     0xa6c2c4: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c2c8: RestoreReg d0
    //     0xa6c2c8: ldr             q0, [SP], #0x10
    // 0xa6c2cc: ldp             q1, q2, [SP], #0x20
    // 0xa6c2d0: ldp             q3, q5, [SP], #0x20
    // 0xa6c2d4: b               #0xa6be60
    // 0xa6c2d8: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c2dc: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c2e0: r0 = AllocateDouble()
    //     0xa6c2e0: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c2e4: ldp             q0, q1, [SP], #0x20
    // 0xa6c2e8: ldp             q2, q4, [SP], #0x20
    // 0xa6c2ec: b               #0xa6beb8
    // 0xa6c2f0: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c2f4: SaveReg d0
    //     0xa6c2f4: str             q0, [SP, #-0x10]!
    // 0xa6c2f8: r0 = AllocateDouble()
    //     0xa6c2f8: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c2fc: RestoreReg d0
    //     0xa6c2fc: ldr             q0, [SP], #0x10
    // 0xa6c300: ldp             q1, q2, [SP], #0x20
    // 0xa6c304: b               #0xa6bf04
    // 0xa6c308: stp             q0, q2, [SP, #-0x20]!
    // 0xa6c30c: r0 = AllocateDouble()
    //     0xa6c30c: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c310: ldp             q0, q2, [SP], #0x20
    // 0xa6c314: b               #0xa6bf54
    // 0xa6c318: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c31c: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c320: r0 = AllocateDouble()
    //     0xa6c320: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c324: ldp             q0, q1, [SP], #0x20
    // 0xa6c328: ldp             q2, q4, [SP], #0x20
    // 0xa6c32c: b               #0xa6bff8
    // 0xa6c330: stp             q2, q4, [SP, #-0x20]!
    // 0xa6c334: stp             q0, q1, [SP, #-0x20]!
    // 0xa6c338: r0 = AllocateDouble()
    //     0xa6c338: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c33c: ldp             q0, q1, [SP], #0x20
    // 0xa6c340: ldp             q2, q4, [SP], #0x20
    // 0xa6c344: b               #0xa6c054
    // 0xa6c348: stp             q2, q3, [SP, #-0x20]!
    // 0xa6c34c: SaveReg d0
    //     0xa6c34c: str             q0, [SP, #-0x10]!
    // 0xa6c350: r0 = AllocateDouble()
    //     0xa6c350: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c354: RestoreReg d0
    //     0xa6c354: ldr             q0, [SP], #0x10
    // 0xa6c358: ldp             q2, q3, [SP], #0x20
    // 0xa6c35c: b               #0xa6c0b0
  }
}

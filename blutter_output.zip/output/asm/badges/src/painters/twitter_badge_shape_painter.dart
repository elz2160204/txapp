// lib: , url: package:badges/src/painters/twitter_badge_shape_painter.dart

// class id: 1048696, size: 0x8
class :: {
}

// class id: 4390, size: 0x1c, field offset: 0xc
class TwitterBadgeShapePainter extends CustomPainter {

  _ paint(/* No info */) {
    // ** addr: 0xa6c360, size: 0x4f4
    // 0xa6c360: EnterFrame
    //     0xa6c360: stp             fp, lr, [SP, #-0x10]!
    //     0xa6c364: mov             fp, SP
    // 0xa6c368: AllocStack(0x68)
    //     0xa6c368: sub             SP, SP, #0x68
    // 0xa6c36c: CheckStackOverflow
    //     0xa6c36c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa6c370: cmp             SP, x16
    //     0xa6c374: b.ls            #0xa6c82c
    // 0xa6c378: ldr             x0, [fp, #0x10]
    // 0xa6c37c: LoadField: d0 = r0->field_7
    //     0xa6c37c: ldur            d0, [x0, #7]
    // 0xa6c380: stur            d0, [fp, #-0x38]
    // 0xa6c384: LoadField: d1 = r0->field_f
    //     0xa6c384: ldur            d1, [x0, #0xf]
    // 0xa6c388: stur            d1, [fp, #-0x30]
    // 0xa6c38c: r0 = Path()
    //     0xa6c38c: bl              #0x663220  ; AllocatePathStub -> Path (size=0xc)
    // 0xa6c390: stur            x0, [fp, #-8]
    // 0xa6c394: SaveReg r0
    //     0xa6c394: str             x0, [SP, #-8]!
    // 0xa6c398: r0 = _constructor()
    //     0xa6c398: bl              #0x4f7768  ; [dart:ui] Path::_constructor
    // 0xa6c39c: add             SP, SP, #8
    // 0xa6c3a0: r16 = 112
    //     0xa6c3a0: mov             x16, #0x70
    // 0xa6c3a4: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6c3a8: r0 = ByteData()
    //     0xa6c3a8: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6c3ac: add             SP, SP, #0x10
    // 0xa6c3b0: stur            x0, [fp, #-0x10]
    // 0xa6c3b4: r0 = Paint()
    //     0xa6c3b4: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6c3b8: mov             x1, x0
    // 0xa6c3bc: ldur            x0, [fp, #-0x10]
    // 0xa6c3c0: stur            x1, [fp, #-0x18]
    // 0xa6c3c4: StoreField: r1->field_7 = r0
    //     0xa6c3c4: stur            w0, [x1, #7]
    // 0xa6c3c8: r16 = 112
    //     0xa6c3c8: mov             x16, #0x70
    // 0xa6c3cc: stp             x16, NULL, [SP, #-0x10]!
    // 0xa6c3d0: r0 = ByteData()
    //     0xa6c3d0: bl              #0x4b2458  ; [dart:typed_data] ByteData::ByteData
    // 0xa6c3d4: add             SP, SP, #0x10
    // 0xa6c3d8: stur            x0, [fp, #-0x20]
    // 0xa6c3dc: r0 = Paint()
    //     0xa6c3dc: bl              #0x51db88  ; AllocatePaintStub -> Paint (size=0x10)
    // 0xa6c3e0: mov             x1, x0
    // 0xa6c3e4: ldur            x0, [fp, #-0x20]
    // 0xa6c3e8: stur            x1, [fp, #-0x28]
    // 0xa6c3ec: StoreField: r1->field_7 = r0
    //     0xa6c3ec: stur            w0, [x1, #7]
    // 0xa6c3f0: LoadField: r2 = r0->field_17
    //     0xa6c3f0: ldur            w2, [x0, #0x17]
    // 0xa6c3f4: DecompressPointer r2
    //     0xa6c3f4: add             x2, x2, HEAP, lsl #32
    // 0xa6c3f8: LoadField: r0 = r2->field_7
    //     0xa6c3f8: ldur            x0, [x2, #7]
    // 0xa6c3fc: str             wzr, [x0, #4]
    // 0xa6c400: LoadField: r0 = r2->field_7
    //     0xa6c400: ldur            x0, [x2, #7]
    // 0xa6c404: r3 = 1
    //     0xa6c404: mov             x3, #1
    // 0xa6c408: str             w3, [x0, #0xc]
    // 0xa6c40c: LoadField: r0 = r2->field_7
    //     0xa6c40c: ldur            x0, [x2, #7]
    // 0xa6c410: str             w3, [x0, #0x14]
    // 0xa6c414: r0 = Instance_BorderSide
    //     0xa6c414: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa6c418: ldr             x0, [x0, #0x2f0]
    // 0xa6c41c: LoadField: d0 = r0->field_b
    //     0xa6c41c: ldur            d0, [x0, #0xb]
    // 0xa6c420: fcvt            s1, d0
    // 0xa6c424: LoadField: r0 = r2->field_7
    //     0xa6c424: ldur            x0, [x2, #7]
    // 0xa6c428: str             s1, [x0, #0x10]
    // 0xa6c42c: ldur            d1, [fp, #-0x38]
    // 0xa6c430: d0 = 0.357000
    //     0xa6c430: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca88] IMM: double(0.357) from 0x3fd6d916872b020c
    //     0xa6c434: ldr             d0, [x17, #0xa88]
    // 0xa6c438: fmul            d2, d1, d0
    // 0xa6c43c: ldur            d3, [fp, #-0x30]
    // 0xa6c440: stur            d2, [fp, #-0x48]
    // 0xa6c444: d0 = 0.156000
    //     0xa6c444: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca90] IMM: double(0.156) from 0x3fc3f7ced916872b
    //     0xa6c448: ldr             d0, [x17, #0xa90]
    // 0xa6c44c: fmul            d4, d3, d0
    // 0xa6c450: stur            d4, [fp, #-0x40]
    // 0xa6c454: r0 = inline_Allocate_Double()
    //     0xa6c454: ldp             x0, x2, [THR, #0x60]  ; THR::top
    //     0xa6c458: add             x0, x0, #0x10
    //     0xa6c45c: cmp             x2, x0
    //     0xa6c460: b.ls            #0xa6c834
    //     0xa6c464: str             x0, [THR, #0x60]  ; THR::top
    //     0xa6c468: sub             x0, x0, #0xf
    //     0xa6c46c: mov             x2, #0xd108
    //     0xa6c470: movk            x2, #3, lsl #16
    //     0xa6c474: stur            x2, [x0, #-1]
    // 0xa6c478: StoreField: r0->field_7 = d2
    //     0xa6c478: stur            d2, [x0, #7]
    // 0xa6c47c: ldur            x16, [fp, #-8]
    // 0xa6c480: stp             x0, x16, [SP, #-0x10]!
    // 0xa6c484: SaveReg d4
    //     0xa6c484: str             d4, [SP, #-8]!
    // 0xa6c488: r0 = moveTo()
    //     0xa6c488: bl              #0x66927c  ; [dart:ui] Path::moveTo
    // 0xa6c48c: add             SP, SP, #0x18
    // 0xa6c490: ldur            d0, [fp, #-0x38]
    // 0xa6c494: d1 = 0.643000
    //     0xa6c494: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4ca98] IMM: double(0.643) from 0x3fe49374bc6a7efa
    //     0xa6c498: ldr             d1, [x17, #0xa98]
    // 0xa6c49c: fmul            d2, d0, d1
    // 0xa6c4a0: stur            d2, [fp, #-0x50]
    // 0xa6c4a4: r0 = Offset()
    //     0xa6c4a4: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c4a8: ldur            d0, [fp, #-0x50]
    // 0xa6c4ac: stur            x0, [fp, #-0x20]
    // 0xa6c4b0: StoreField: r0->field_7 = d0
    //     0xa6c4b0: stur            d0, [x0, #7]
    // 0xa6c4b4: ldur            d1, [fp, #-0x40]
    // 0xa6c4b8: StoreField: r0->field_f = d1
    //     0xa6c4b8: stur            d1, [x0, #0xf]
    // 0xa6c4bc: ldur            d2, [fp, #-0x30]
    // 0xa6c4c0: d3 = 0.157000
    //     0xa6c4c0: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4caa0] IMM: double(0.157) from 0x3fc4189374bc6a7f
    //     0xa6c4c4: ldr             d3, [x17, #0xaa0]
    // 0xa6c4c8: fmul            d4, d2, d3
    // 0xa6c4cc: stur            d4, [fp, #-0x58]
    // 0xa6c4d0: r0 = Radius()
    //     0xa6c4d0: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c4d4: ldur            d0, [fp, #-0x58]
    // 0xa6c4d8: StoreField: r0->field_7 = d0
    //     0xa6c4d8: stur            d0, [x0, #7]
    // 0xa6c4dc: StoreField: r0->field_f = d0
    //     0xa6c4dc: stur            d0, [x0, #0xf]
    // 0xa6c4e0: ldur            x16, [fp, #-8]
    // 0xa6c4e4: ldur            lr, [fp, #-0x20]
    // 0xa6c4e8: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c4ec: SaveReg r0
    //     0xa6c4ec: str             x0, [SP, #-8]!
    // 0xa6c4f0: r0 = arcToPoint()
    //     0xa6c4f0: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c4f4: add             SP, SP, #0x18
    // 0xa6c4f8: ldur            d0, [fp, #-0x38]
    // 0xa6c4fc: d1 = 0.847000
    //     0xa6c4fc: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4caa8] IMM: double(0.847) from 0x3feb1a9fbe76c8b4
    //     0xa6c500: ldr             d1, [x17, #0xaa8]
    // 0xa6c504: fmul            d2, d0, d1
    // 0xa6c508: ldur            d1, [fp, #-0x30]
    // 0xa6c50c: stur            d2, [fp, #-0x68]
    // 0xa6c510: d3 = 0.396000
    //     0xa6c510: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cab0] IMM: double(0.396) from 0x3fd95810624dd2f2
    //     0xa6c514: ldr             d3, [x17, #0xab0]
    // 0xa6c518: fmul            d4, d1, d3
    // 0xa6c51c: stur            d4, [fp, #-0x60]
    // 0xa6c520: r0 = Offset()
    //     0xa6c520: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c524: ldur            d0, [fp, #-0x68]
    // 0xa6c528: stur            x0, [fp, #-0x20]
    // 0xa6c52c: StoreField: r0->field_7 = d0
    //     0xa6c52c: stur            d0, [x0, #7]
    // 0xa6c530: ldur            d0, [fp, #-0x60]
    // 0xa6c534: StoreField: r0->field_f = d0
    //     0xa6c534: stur            d0, [x0, #0xf]
    // 0xa6c538: ldur            d0, [fp, #-0x30]
    // 0xa6c53c: d1 = 0.165000
    //     0xa6c53c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cab8] IMM: double(0.165) from 0x3fc51eb851eb851f
    //     0xa6c540: ldr             d1, [x17, #0xab8]
    // 0xa6c544: fmul            d2, d0, d1
    // 0xa6c548: stur            d2, [fp, #-0x60]
    // 0xa6c54c: r0 = Radius()
    //     0xa6c54c: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c550: ldur            d0, [fp, #-0x60]
    // 0xa6c554: StoreField: r0->field_7 = d0
    //     0xa6c554: stur            d0, [x0, #7]
    // 0xa6c558: StoreField: r0->field_f = d0
    //     0xa6c558: stur            d0, [x0, #0xf]
    // 0xa6c55c: ldur            x16, [fp, #-8]
    // 0xa6c560: ldur            lr, [fp, #-0x20]
    // 0xa6c564: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c568: SaveReg r0
    //     0xa6c568: str             x0, [SP, #-8]!
    // 0xa6c56c: r0 = arcToPoint()
    //     0xa6c56c: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c570: add             SP, SP, #0x18
    // 0xa6c574: ldur            d0, [fp, #-0x38]
    // 0xa6c578: d1 = 0.857000
    //     0xa6c578: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cac0] IMM: double(0.857) from 0x3feb6c8b43958106
    //     0xa6c57c: ldr             d1, [x17, #0xac0]
    // 0xa6c580: fmul            d2, d0, d1
    // 0xa6c584: ldur            d1, [fp, #-0x30]
    // 0xa6c588: stur            d2, [fp, #-0x68]
    // 0xa6c58c: d3 = 0.666000
    //     0xa6c58c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cac8] IMM: double(0.666) from 0x3fe54fdf3b645a1d
    //     0xa6c590: ldr             d3, [x17, #0xac8]
    // 0xa6c594: fmul            d4, d1, d3
    // 0xa6c598: stur            d4, [fp, #-0x60]
    // 0xa6c59c: r0 = Offset()
    //     0xa6c59c: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c5a0: ldur            d0, [fp, #-0x68]
    // 0xa6c5a4: stur            x0, [fp, #-0x20]
    // 0xa6c5a8: StoreField: r0->field_7 = d0
    //     0xa6c5a8: stur            d0, [x0, #7]
    // 0xa6c5ac: ldur            d0, [fp, #-0x60]
    // 0xa6c5b0: StoreField: r0->field_f = d0
    //     0xa6c5b0: stur            d0, [x0, #0xf]
    // 0xa6c5b4: ldur            d0, [fp, #-0x30]
    // 0xa6c5b8: d1 = 0.170000
    //     0xa6c5b8: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cad0] IMM: double(0.17) from 0x3fc5c28f5c28f5c3
    //     0xa6c5bc: ldr             d1, [x17, #0xad0]
    // 0xa6c5c0: fmul            d2, d0, d1
    // 0xa6c5c4: stur            d2, [fp, #-0x60]
    // 0xa6c5c8: r0 = Radius()
    //     0xa6c5c8: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c5cc: ldur            d0, [fp, #-0x60]
    // 0xa6c5d0: StoreField: r0->field_7 = d0
    //     0xa6c5d0: stur            d0, [x0, #7]
    // 0xa6c5d4: StoreField: r0->field_f = d0
    //     0xa6c5d4: stur            d0, [x0, #0xf]
    // 0xa6c5d8: ldur            x16, [fp, #-8]
    // 0xa6c5dc: ldur            lr, [fp, #-0x20]
    // 0xa6c5e0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c5e4: SaveReg r0
    //     0xa6c5e4: str             x0, [SP, #-8]!
    // 0xa6c5e8: r0 = arcToPoint()
    //     0xa6c5e8: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c5ec: add             SP, SP, #0x18
    // 0xa6c5f0: ldur            d0, [fp, #-0x30]
    // 0xa6c5f4: d1 = 0.844000
    //     0xa6c5f4: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cad8] IMM: double(0.844) from 0x3feb020c49ba5e35
    //     0xa6c5f8: ldr             d1, [x17, #0xad8]
    // 0xa6c5fc: fmul            d2, d0, d1
    // 0xa6c600: stur            d2, [fp, #-0x68]
    // 0xa6c604: r0 = Offset()
    //     0xa6c604: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c608: ldur            d0, [fp, #-0x50]
    // 0xa6c60c: stur            x0, [fp, #-0x20]
    // 0xa6c610: StoreField: r0->field_7 = d0
    //     0xa6c610: stur            d0, [x0, #7]
    // 0xa6c614: ldur            d0, [fp, #-0x68]
    // 0xa6c618: StoreField: r0->field_f = d0
    //     0xa6c618: stur            d0, [x0, #0xf]
    // 0xa6c61c: ldur            d1, [fp, #-0x30]
    // 0xa6c620: d2 = 0.163000
    //     0xa6c620: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cae0] IMM: double(0.163) from 0x3fc4dd2f1a9fbe77
    //     0xa6c624: ldr             d2, [x17, #0xae0]
    // 0xa6c628: fmul            d3, d1, d2
    // 0xa6c62c: stur            d3, [fp, #-0x50]
    // 0xa6c630: r0 = Radius()
    //     0xa6c630: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c634: ldur            d0, [fp, #-0x50]
    // 0xa6c638: StoreField: r0->field_7 = d0
    //     0xa6c638: stur            d0, [x0, #7]
    // 0xa6c63c: StoreField: r0->field_f = d0
    //     0xa6c63c: stur            d0, [x0, #0xf]
    // 0xa6c640: ldur            x16, [fp, #-8]
    // 0xa6c644: ldur            lr, [fp, #-0x20]
    // 0xa6c648: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c64c: SaveReg r0
    //     0xa6c64c: str             x0, [SP, #-8]!
    // 0xa6c650: r0 = arcToPoint()
    //     0xa6c650: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c654: add             SP, SP, #0x18
    // 0xa6c658: r0 = Offset()
    //     0xa6c658: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c65c: ldur            d0, [fp, #-0x48]
    // 0xa6c660: stur            x0, [fp, #-0x20]
    // 0xa6c664: StoreField: r0->field_7 = d0
    //     0xa6c664: stur            d0, [x0, #7]
    // 0xa6c668: ldur            d1, [fp, #-0x68]
    // 0xa6c66c: StoreField: r0->field_f = d1
    //     0xa6c66c: stur            d1, [x0, #0xf]
    // 0xa6c670: r0 = Radius()
    //     0xa6c670: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c674: ldur            d0, [fp, #-0x58]
    // 0xa6c678: StoreField: r0->field_7 = d0
    //     0xa6c678: stur            d0, [x0, #7]
    // 0xa6c67c: StoreField: r0->field_f = d0
    //     0xa6c67c: stur            d0, [x0, #0xf]
    // 0xa6c680: ldur            x16, [fp, #-8]
    // 0xa6c684: ldur            lr, [fp, #-0x20]
    // 0xa6c688: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c68c: SaveReg r0
    //     0xa6c68c: str             x0, [SP, #-8]!
    // 0xa6c690: r0 = arcToPoint()
    //     0xa6c690: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c694: add             SP, SP, #0x18
    // 0xa6c698: ldur            d0, [fp, #-0x38]
    // 0xa6c69c: d1 = 0.145000
    //     0xa6c69c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cae8] IMM: double(0.145) from 0x3fc28f5c28f5c28f
    //     0xa6c6a0: ldr             d1, [x17, #0xae8]
    // 0xa6c6a4: fmul            d2, d0, d1
    // 0xa6c6a8: ldur            d1, [fp, #-0x30]
    // 0xa6c6ac: stur            d2, [fp, #-0x68]
    // 0xa6c6b0: d3 = 0.665000
    //     0xa6c6b0: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4caf0] IMM: double(0.665) from 0x3fe547ae147ae148
    //     0xa6c6b4: ldr             d3, [x17, #0xaf0]
    // 0xa6c6b8: fmul            d4, d1, d3
    // 0xa6c6bc: stur            d4, [fp, #-0x58]
    // 0xa6c6c0: r0 = Offset()
    //     0xa6c6c0: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c6c4: ldur            d0, [fp, #-0x68]
    // 0xa6c6c8: stur            x0, [fp, #-0x20]
    // 0xa6c6cc: StoreField: r0->field_7 = d0
    //     0xa6c6cc: stur            d0, [x0, #7]
    // 0xa6c6d0: ldur            d0, [fp, #-0x58]
    // 0xa6c6d4: StoreField: r0->field_f = d0
    //     0xa6c6d4: stur            d0, [x0, #0xf]
    // 0xa6c6d8: r0 = Radius()
    //     0xa6c6d8: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c6dc: ldur            d0, [fp, #-0x50]
    // 0xa6c6e0: StoreField: r0->field_7 = d0
    //     0xa6c6e0: stur            d0, [x0, #7]
    // 0xa6c6e4: StoreField: r0->field_f = d0
    //     0xa6c6e4: stur            d0, [x0, #0xf]
    // 0xa6c6e8: ldur            x16, [fp, #-8]
    // 0xa6c6ec: ldur            lr, [fp, #-0x20]
    // 0xa6c6f0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c6f4: SaveReg r0
    //     0xa6c6f4: str             x0, [SP, #-8]!
    // 0xa6c6f8: r0 = arcToPoint()
    //     0xa6c6f8: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c6fc: add             SP, SP, #0x18
    // 0xa6c700: ldur            d0, [fp, #-0x38]
    // 0xa6c704: d1 = 0.154000
    //     0xa6c704: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4caf8] IMM: double(0.154) from 0x3fc3b645a1cac083
    //     0xa6c708: ldr             d1, [x17, #0xaf8]
    // 0xa6c70c: fmul            d2, d0, d1
    // 0xa6c710: ldur            d0, [fp, #-0x30]
    // 0xa6c714: stur            d2, [fp, #-0x58]
    // 0xa6c718: d1 = 0.372000
    //     0xa6c718: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cb00] IMM: double(0.372) from 0x3fd7ced916872b02
    //     0xa6c71c: ldr             d1, [x17, #0xb00]
    // 0xa6c720: fmul            d3, d0, d1
    // 0xa6c724: stur            d3, [fp, #-0x38]
    // 0xa6c728: r0 = Offset()
    //     0xa6c728: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c72c: ldur            d0, [fp, #-0x58]
    // 0xa6c730: stur            x0, [fp, #-0x20]
    // 0xa6c734: StoreField: r0->field_7 = d0
    //     0xa6c734: stur            d0, [x0, #7]
    // 0xa6c738: ldur            d0, [fp, #-0x38]
    // 0xa6c73c: StoreField: r0->field_f = d0
    //     0xa6c73c: stur            d0, [x0, #0xf]
    // 0xa6c740: r0 = Radius()
    //     0xa6c740: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c744: ldur            d0, [fp, #-0x60]
    // 0xa6c748: StoreField: r0->field_7 = d0
    //     0xa6c748: stur            d0, [x0, #7]
    // 0xa6c74c: StoreField: r0->field_f = d0
    //     0xa6c74c: stur            d0, [x0, #0xf]
    // 0xa6c750: ldur            x16, [fp, #-8]
    // 0xa6c754: ldur            lr, [fp, #-0x20]
    // 0xa6c758: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c75c: SaveReg r0
    //     0xa6c75c: str             x0, [SP, #-8]!
    // 0xa6c760: r0 = arcToPoint()
    //     0xa6c760: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c764: add             SP, SP, #0x18
    // 0xa6c768: r0 = Offset()
    //     0xa6c768: bl              #0x50e43c  ; AllocateOffsetStub -> Offset (size=0x18)
    // 0xa6c76c: ldur            d0, [fp, #-0x48]
    // 0xa6c770: stur            x0, [fp, #-0x20]
    // 0xa6c774: StoreField: r0->field_7 = d0
    //     0xa6c774: stur            d0, [x0, #7]
    // 0xa6c778: ldur            d0, [fp, #-0x40]
    // 0xa6c77c: StoreField: r0->field_f = d0
    //     0xa6c77c: stur            d0, [x0, #0xf]
    // 0xa6c780: r0 = Radius()
    //     0xa6c780: bl              #0x59625c  ; AllocateRadiusStub -> Radius (size=0x18)
    // 0xa6c784: ldur            d0, [fp, #-0x50]
    // 0xa6c788: StoreField: r0->field_7 = d0
    //     0xa6c788: stur            d0, [x0, #7]
    // 0xa6c78c: StoreField: r0->field_f = d0
    //     0xa6c78c: stur            d0, [x0, #0xf]
    // 0xa6c790: ldur            x16, [fp, #-8]
    // 0xa6c794: ldur            lr, [fp, #-0x20]
    // 0xa6c798: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c79c: SaveReg r0
    //     0xa6c79c: str             x0, [SP, #-8]!
    // 0xa6c7a0: r0 = arcToPoint()
    //     0xa6c7a0: bl              #0xa6c854  ; [dart:ui] Path::arcToPoint
    // 0xa6c7a4: add             SP, SP, #0x18
    // 0xa6c7a8: ldur            x0, [fp, #-0x10]
    // 0xa6c7ac: LoadField: r1 = r0->field_17
    //     0xa6c7ac: ldur            w1, [x0, #0x17]
    // 0xa6c7b0: DecompressPointer r1
    //     0xa6c7b0: add             x1, x1, HEAP, lsl #32
    // 0xa6c7b4: LoadField: r0 = r1->field_7
    //     0xa6c7b4: ldur            x0, [x1, #7]
    // 0xa6c7b8: r1 = 16007990
    //     0xa6c7b8: mov             x1, #0x4336
    //     0xa6c7bc: movk            x1, #0xf4, lsl #16
    // 0xa6c7c0: str             w1, [x0, #4]
    // 0xa6c7c4: ldr             x16, [fp, #0x18]
    // 0xa6c7c8: ldur            lr, [fp, #-8]
    // 0xa6c7cc: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c7d0: ldur            x16, [fp, #-0x18]
    // 0xa6c7d4: SaveReg r16
    //     0xa6c7d4: str             x16, [SP, #-8]!
    // 0xa6c7d8: r0 = drawPath()
    //     0xa6c7d8: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6c7dc: add             SP, SP, #0x18
    // 0xa6c7e0: r16 = Instance_BorderSide
    //     0xa6c7e0: add             x16, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa6c7e4: ldr             x16, [x16, #0x2f0]
    // 0xa6c7e8: r30 = Instance_BorderSide
    //     0xa6c7e8: add             lr, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0xa6c7ec: ldr             lr, [lr, #0x2f0]
    // 0xa6c7f0: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c7f4: r0 = ==()
    //     0xa6c7f4: bl              #0xc8b318  ; [package:flutter/src/painting/borders.dart] BorderSide::==
    // 0xa6c7f8: add             SP, SP, #0x10
    // 0xa6c7fc: tbz             w0, #4, #0xa6c81c
    // 0xa6c800: ldr             x16, [fp, #0x18]
    // 0xa6c804: ldur            lr, [fp, #-8]
    // 0xa6c808: stp             lr, x16, [SP, #-0x10]!
    // 0xa6c80c: ldur            x16, [fp, #-0x28]
    // 0xa6c810: SaveReg r16
    //     0xa6c810: str             x16, [SP, #-8]!
    // 0xa6c814: r0 = drawPath()
    //     0xa6c814: bl              #0x664e78  ; [dart:ui] Canvas::drawPath
    // 0xa6c818: add             SP, SP, #0x18
    // 0xa6c81c: r0 = Null
    //     0xa6c81c: mov             x0, NULL
    // 0xa6c820: LeaveFrame
    //     0xa6c820: mov             SP, fp
    //     0xa6c824: ldp             fp, lr, [SP], #0x10
    // 0xa6c828: ret
    //     0xa6c828: ret             
    // 0xa6c82c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa6c82c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa6c830: b               #0xa6c378
    // 0xa6c834: stp             q3, q4, [SP, #-0x20]!
    // 0xa6c838: stp             q1, q2, [SP, #-0x20]!
    // 0xa6c83c: SaveReg r1
    //     0xa6c83c: str             x1, [SP, #-8]!
    // 0xa6c840: r0 = AllocateDouble()
    //     0xa6c840: bl              #0xd697d4  ; AllocateDoubleStub
    // 0xa6c844: RestoreReg r1
    //     0xa6c844: ldr             x1, [SP], #8
    // 0xa6c848: ldp             q1, q2, [SP], #0x20
    // 0xa6c84c: ldp             q3, q4, [SP], #0x20
    // 0xa6c850: b               #0xa6c478
  }
}

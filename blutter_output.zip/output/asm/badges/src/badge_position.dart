// lib: , url: package:badges/src/badge_position.dart

// class id: 1048691, size: 0x8
class :: {
}

// class id: 4975, size: 0x1c, field offset: 0x8
//   const constructor, 
class BadgePosition extends Object {

  factory _ BadgePosition.topEnd(/* No info */) {
    // ** addr: 0x90a698, size: 0x74
    // 0x90a698: EnterFrame
    //     0x90a698: stp             fp, lr, [SP, #-0x10]!
    //     0x90a69c: mov             fp, SP
    // 0x90a6a0: AllocStack(0x8)
    //     0x90a6a0: sub             SP, SP, #8
    // 0x90a6a4: ldr             d0, [fp, #0x10]
    // 0x90a6a8: r0 = inline_Allocate_Double()
    //     0x90a6a8: ldp             x0, x1, [THR, #0x60]  ; THR::top
    //     0x90a6ac: add             x0, x0, #0x10
    //     0x90a6b0: cmp             x1, x0
    //     0x90a6b4: b.ls            #0x90a6fc
    //     0x90a6b8: str             x0, [THR, #0x60]  ; THR::top
    //     0x90a6bc: sub             x0, x0, #0xf
    //     0x90a6c0: mov             x1, #0xd108
    //     0x90a6c4: movk            x1, #3, lsl #16
    //     0x90a6c8: stur            x1, [x0, #-1]
    // 0x90a6cc: StoreField: r0->field_7 = d0
    //     0x90a6cc: stur            d0, [x0, #7]
    // 0x90a6d0: stur            x0, [fp, #-8]
    // 0x90a6d4: r0 = BadgePosition()
    //     0x90a6d4: bl              #0x90a70c  ; AllocateBadgePositionStub -> BadgePosition (size=0x1c)
    // 0x90a6d8: ldur            x1, [fp, #-8]
    // 0x90a6dc: StoreField: r0->field_7 = r1
    //     0x90a6dc: stur            w1, [x0, #7]
    // 0x90a6e0: ldr             x1, [fp, #0x18]
    // 0x90a6e4: StoreField: r0->field_b = r1
    //     0x90a6e4: stur            w1, [x0, #0xb]
    // 0x90a6e8: r1 = false
    //     0x90a6e8: add             x1, NULL, #0x30  ; false
    // 0x90a6ec: StoreField: r0->field_17 = r1
    //     0x90a6ec: stur            w1, [x0, #0x17]
    // 0x90a6f0: LeaveFrame
    //     0x90a6f0: mov             SP, fp
    //     0x90a6f4: ldp             fp, lr, [SP], #0x10
    // 0x90a6f8: ret
    //     0x90a6f8: ret             
    // 0x90a6fc: SaveReg d0
    //     0x90a6fc: str             q0, [SP, #-0x10]!
    // 0x90a700: r0 = AllocateDouble()
    //     0x90a700: bl              #0xd697d4  ; AllocateDoubleStub
    // 0x90a704: RestoreReg d0
    //     0x90a704: ldr             q0, [SP], #0x10
    // 0x90a708: b               #0x90a6cc
  }
}

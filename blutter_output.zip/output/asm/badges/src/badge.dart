// lib: , url: package:badges/src/badge.dart

// class id: 1048685, size: 0x8
class :: {
}

// class id: 3419, size: 0x1c, field offset: 0x14
//   transformed mixin,
abstract class _BadgeState&State&TickerProviderStateMixin extends State<Badge>
     with TickerProviderStateMixin<X0 bound StatefulWidget> {

  _ createTicker(/* No info */) {
    // ** addr: 0x612c90, size: 0x178
    // 0x612c90: EnterFrame
    //     0x612c90: stp             fp, lr, [SP, #-0x10]!
    //     0x612c94: mov             fp, SP
    // 0x612c98: AllocStack(0x10)
    //     0x612c98: sub             SP, SP, #0x10
    // 0x612c9c: CheckStackOverflow
    //     0x612c9c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x612ca0: cmp             SP, x16
    //     0x612ca4: b.ls            #0x612df8
    // 0x612ca8: ldr             x0, [fp, #0x18]
    // 0x612cac: LoadField: r1 = r0->field_17
    //     0x612cac: ldur            w1, [x0, #0x17]
    // 0x612cb0: DecompressPointer r1
    //     0x612cb0: add             x1, x1, HEAP, lsl #32
    // 0x612cb4: cmp             w1, NULL
    // 0x612cb8: b.ne            #0x612cc8
    // 0x612cbc: SaveReg r0
    //     0x612cbc: str             x0, [SP, #-8]!
    // 0x612cc0: r0 = _updateTickerModeNotifier()
    //     0x612cc0: bl              #0x612ee4  ; [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x612cc4: add             SP, SP, #8
    // 0x612cc8: ldr             x0, [fp, #0x18]
    // 0x612ccc: LoadField: r1 = r0->field_13
    //     0x612ccc: ldur            w1, [x0, #0x13]
    // 0x612cd0: DecompressPointer r1
    //     0x612cd0: add             x1, x1, HEAP, lsl #32
    // 0x612cd4: cmp             w1, NULL
    // 0x612cd8: b.ne            #0x612d70
    // 0x612cdc: r0 = InitLateStaticField(0x2cc) // [dart:collection] ::_uninitializedIndex
    //     0x612cdc: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x612ce0: ldr             x0, [x0, #0x598]
    //     0x612ce4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x612ce8: cmp             w0, w16
    //     0x612cec: b.ne            #0x612cf8
    //     0x612cf0: ldr             x2, [PP, #0x280]  ; [pp+0x280] Field <::._uninitializedIndex@3220832>: static late final (offset: 0x2cc)
    //     0x612cf4: bl              #0xd67cdc
    // 0x612cf8: r1 = <_WidgetTicker>
    //     0x612cf8: add             x1, PP, #0x1f, lsl #12  ; [pp+0x1f210] TypeArguments: <_WidgetTicker>
    //     0x612cfc: ldr             x1, [x1, #0x210]
    // 0x612d00: stur            x0, [fp, #-8]
    // 0x612d04: r0 = _Set()
    //     0x612d04: bl              #0x4f73d8  ; Allocate_SetStub -> _Set<X0> (size=-0x8)
    // 0x612d08: mov             x1, x0
    // 0x612d0c: ldur            x0, [fp, #-8]
    // 0x612d10: stur            x1, [fp, #-0x10]
    // 0x612d14: StoreField: r1->field_1b = r0
    //     0x612d14: stur            w0, [x1, #0x1b]
    // 0x612d18: StoreField: r1->field_b = rZR
    //     0x612d18: stur            wzr, [x1, #0xb]
    // 0x612d1c: r0 = InitLateStaticField(0x2d0) // [dart:collection] ::_uninitializedData
    //     0x612d1c: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x612d20: ldr             x0, [x0, #0x5a0]
    //     0x612d24: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x612d28: cmp             w0, w16
    //     0x612d2c: b.ne            #0x612d38
    //     0x612d30: ldr             x2, [PP, #0x288]  ; [pp+0x288] Field <::._uninitializedData@3220832>: static late final (offset: 0x2d0)
    //     0x612d34: bl              #0xd67cdc
    // 0x612d38: mov             x1, x0
    // 0x612d3c: ldur            x0, [fp, #-0x10]
    // 0x612d40: StoreField: r0->field_f = r1
    //     0x612d40: stur            w1, [x0, #0xf]
    // 0x612d44: StoreField: r0->field_13 = rZR
    //     0x612d44: stur            wzr, [x0, #0x13]
    // 0x612d48: StoreField: r0->field_17 = rZR
    //     0x612d48: stur            wzr, [x0, #0x17]
    // 0x612d4c: ldr             x1, [fp, #0x18]
    // 0x612d50: StoreField: r1->field_13 = r0
    //     0x612d50: stur            w0, [x1, #0x13]
    //     0x612d54: ldurb           w16, [x1, #-1]
    //     0x612d58: ldurb           w17, [x0, #-1]
    //     0x612d5c: and             x16, x17, x16, lsr #2
    //     0x612d60: tst             x16, HEAP, lsr #32
    //     0x612d64: b.eq            #0x612d6c
    //     0x612d68: bl              #0xd6826c
    // 0x612d6c: b               #0x612d74
    // 0x612d70: mov             x1, x0
    // 0x612d74: ldr             x0, [fp, #0x10]
    // 0x612d78: r0 = _WidgetTicker()
    //     0x612d78: bl              #0x612eb8  ; Allocate_WidgetTickerStub -> _WidgetTicker (size=0x20)
    // 0x612d7c: mov             x1, x0
    // 0x612d80: ldr             x0, [fp, #0x18]
    // 0x612d84: stur            x1, [fp, #-8]
    // 0x612d88: StoreField: r1->field_1b = r0
    //     0x612d88: stur            w0, [x1, #0x1b]
    // 0x612d8c: r2 = false
    //     0x612d8c: add             x2, NULL, #0x30  ; false
    // 0x612d90: StoreField: r1->field_b = r2
    //     0x612d90: stur            w2, [x1, #0xb]
    // 0x612d94: ldr             x2, [fp, #0x10]
    // 0x612d98: StoreField: r1->field_13 = r2
    //     0x612d98: stur            w2, [x1, #0x13]
    // 0x612d9c: LoadField: r2 = r0->field_17
    //     0x612d9c: ldur            w2, [x0, #0x17]
    // 0x612da0: DecompressPointer r2
    //     0x612da0: add             x2, x2, HEAP, lsl #32
    // 0x612da4: cmp             w2, NULL
    // 0x612da8: b.eq            #0x612e00
    // 0x612dac: LoadField: r3 = r2->field_27
    //     0x612dac: ldur            w3, [x2, #0x27]
    // 0x612db0: DecompressPointer r3
    //     0x612db0: add             x3, x3, HEAP, lsl #32
    // 0x612db4: eor             x2, x3, #0x10
    // 0x612db8: stp             x2, x1, [SP, #-0x10]!
    // 0x612dbc: r0 = muted=()
    //     0x612dbc: bl              #0x612e2c  ; [package:flutter/src/scheduler/ticker.dart] Ticker::muted=
    // 0x612dc0: add             SP, SP, #0x10
    // 0x612dc4: ldr             x0, [fp, #0x18]
    // 0x612dc8: LoadField: r1 = r0->field_13
    //     0x612dc8: ldur            w1, [x0, #0x13]
    // 0x612dcc: DecompressPointer r1
    //     0x612dcc: add             x1, x1, HEAP, lsl #32
    // 0x612dd0: cmp             w1, NULL
    // 0x612dd4: b.eq            #0x612e04
    // 0x612dd8: ldur            x16, [fp, #-8]
    // 0x612ddc: stp             x16, x1, [SP, #-0x10]!
    // 0x612de0: r0 = add()
    //     0x612de0: bl              #0xcac190  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::add
    // 0x612de4: add             SP, SP, #0x10
    // 0x612de8: ldur            x0, [fp, #-8]
    // 0x612dec: LeaveFrame
    //     0x612dec: mov             SP, fp
    //     0x612df0: ldp             fp, lr, [SP], #0x10
    // 0x612df4: ret
    //     0x612df4: ret             
    // 0x612df8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x612df8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x612dfc: b               #0x612ca8
    // 0x612e00: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x612e00: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x612e04: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x612e04: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _updateTickerModeNotifier(/* No info */) {
    // ** addr: 0x612ee4, size: 0x11c
    // 0x612ee4: EnterFrame
    //     0x612ee4: stp             fp, lr, [SP, #-0x10]!
    //     0x612ee8: mov             fp, SP
    // 0x612eec: AllocStack(0x10)
    //     0x612eec: sub             SP, SP, #0x10
    // 0x612ef0: CheckStackOverflow
    //     0x612ef0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x612ef4: cmp             SP, x16
    //     0x612ef8: b.ls            #0x612ff4
    // 0x612efc: ldr             x0, [fp, #0x10]
    // 0x612f00: LoadField: r1 = r0->field_f
    //     0x612f00: ldur            w1, [x0, #0xf]
    // 0x612f04: DecompressPointer r1
    //     0x612f04: add             x1, x1, HEAP, lsl #32
    // 0x612f08: cmp             w1, NULL
    // 0x612f0c: b.eq            #0x612ffc
    // 0x612f10: SaveReg r1
    //     0x612f10: str             x1, [SP, #-8]!
    // 0x612f14: r0 = getNotifier()
    //     0x612f14: bl              #0x613000  ; [package:flutter/src/widgets/ticker_provider.dart] TickerMode::getNotifier
    // 0x612f18: add             SP, SP, #8
    // 0x612f1c: mov             x1, x0
    // 0x612f20: ldr             x0, [fp, #0x10]
    // 0x612f24: stur            x1, [fp, #-0x10]
    // 0x612f28: LoadField: r2 = r0->field_17
    //     0x612f28: ldur            w2, [x0, #0x17]
    // 0x612f2c: DecompressPointer r2
    //     0x612f2c: add             x2, x2, HEAP, lsl #32
    // 0x612f30: stur            x2, [fp, #-8]
    // 0x612f34: cmp             w1, w2
    // 0x612f38: b.ne            #0x612f4c
    // 0x612f3c: r0 = Null
    //     0x612f3c: mov             x0, NULL
    // 0x612f40: LeaveFrame
    //     0x612f40: mov             SP, fp
    //     0x612f44: ldp             fp, lr, [SP], #0x10
    // 0x612f48: ret
    //     0x612f48: ret             
    // 0x612f4c: cmp             w2, NULL
    // 0x612f50: b.eq            #0x612f8c
    // 0x612f54: r1 = 1
    //     0x612f54: mov             x1, #1
    // 0x612f58: r0 = AllocateContext()
    //     0x612f58: bl              #0xd68aa4  ; AllocateContextStub
    // 0x612f5c: mov             x1, x0
    // 0x612f60: ldr             x0, [fp, #0x10]
    // 0x612f64: StoreField: r1->field_f = r0
    //     0x612f64: stur            w0, [x1, #0xf]
    // 0x612f68: mov             x2, x1
    // 0x612f6c: r1 = Function '_updateTickers@156311458':.
    //     0x612f6c: add             x1, PP, #0x41, lsl #12  ; [pp+0x41498] AnonymousClosure: (0x6131b8), in [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickers (0x613200)
    //     0x612f70: ldr             x1, [x1, #0x498]
    // 0x612f74: r0 = AllocateClosure()
    //     0x612f74: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x612f78: ldur            x16, [fp, #-8]
    // 0x612f7c: stp             x0, x16, [SP, #-0x10]!
    // 0x612f80: r0 = removeListener()
    //     0x612f80: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0x612f84: add             SP, SP, #0x10
    // 0x612f88: ldr             x0, [fp, #0x10]
    // 0x612f8c: r1 = 1
    //     0x612f8c: mov             x1, #1
    // 0x612f90: r0 = AllocateContext()
    //     0x612f90: bl              #0xd68aa4  ; AllocateContextStub
    // 0x612f94: mov             x1, x0
    // 0x612f98: ldr             x0, [fp, #0x10]
    // 0x612f9c: StoreField: r1->field_f = r0
    //     0x612f9c: stur            w0, [x1, #0xf]
    // 0x612fa0: mov             x2, x1
    // 0x612fa4: r1 = Function '_updateTickers@156311458':.
    //     0x612fa4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41498] AnonymousClosure: (0x6131b8), in [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickers (0x613200)
    //     0x612fa8: ldr             x1, [x1, #0x498]
    // 0x612fac: r0 = AllocateClosure()
    //     0x612fac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x612fb0: ldur            x16, [fp, #-0x10]
    // 0x612fb4: stp             x0, x16, [SP, #-0x10]!
    // 0x612fb8: r0 = addListener()
    //     0x612fb8: bl              #0x6e79e8  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::addListener
    // 0x612fbc: add             SP, SP, #0x10
    // 0x612fc0: ldur            x0, [fp, #-0x10]
    // 0x612fc4: ldr             x1, [fp, #0x10]
    // 0x612fc8: StoreField: r1->field_17 = r0
    //     0x612fc8: stur            w0, [x1, #0x17]
    //     0x612fcc: ldurb           w16, [x1, #-1]
    //     0x612fd0: ldurb           w17, [x0, #-1]
    //     0x612fd4: and             x16, x17, x16, lsr #2
    //     0x612fd8: tst             x16, HEAP, lsr #32
    //     0x612fdc: b.eq            #0x612fe4
    //     0x612fe0: bl              #0xd6826c
    // 0x612fe4: r0 = Null
    //     0x612fe4: mov             x0, NULL
    // 0x612fe8: LeaveFrame
    //     0x612fe8: mov             SP, fp
    //     0x612fec: ldp             fp, lr, [SP], #0x10
    // 0x612ff0: ret
    //     0x612ff0: ret             
    // 0x612ff4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x612ff4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x612ff8: b               #0x612efc
    // 0x612ffc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x612ffc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  [closure] void _updateTickers(dynamic) {
    // ** addr: 0x6131b8, size: 0x48
    // 0x6131b8: EnterFrame
    //     0x6131b8: stp             fp, lr, [SP, #-0x10]!
    //     0x6131bc: mov             fp, SP
    // 0x6131c0: ldr             x0, [fp, #0x10]
    // 0x6131c4: LoadField: r1 = r0->field_17
    //     0x6131c4: ldur            w1, [x0, #0x17]
    // 0x6131c8: DecompressPointer r1
    //     0x6131c8: add             x1, x1, HEAP, lsl #32
    // 0x6131cc: CheckStackOverflow
    //     0x6131cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x6131d0: cmp             SP, x16
    //     0x6131d4: b.ls            #0x6131f8
    // 0x6131d8: LoadField: r0 = r1->field_f
    //     0x6131d8: ldur            w0, [x1, #0xf]
    // 0x6131dc: DecompressPointer r0
    //     0x6131dc: add             x0, x0, HEAP, lsl #32
    // 0x6131e0: SaveReg r0
    //     0x6131e0: str             x0, [SP, #-8]!
    // 0x6131e4: r0 = _updateTickers()
    //     0x6131e4: bl              #0x613200  ; [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickers
    // 0x6131e8: add             SP, SP, #8
    // 0x6131ec: LeaveFrame
    //     0x6131ec: mov             SP, fp
    //     0x6131f0: ldp             fp, lr, [SP], #0x10
    // 0x6131f4: ret
    //     0x6131f4: ret             
    // 0x6131f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x6131f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x6131fc: b               #0x6131d8
  }
  _ _updateTickers(/* No info */) {
    // ** addr: 0x613200, size: 0x150
    // 0x613200: EnterFrame
    //     0x613200: stp             fp, lr, [SP, #-0x10]!
    //     0x613204: mov             fp, SP
    // 0x613208: AllocStack(0x20)
    //     0x613208: sub             SP, SP, #0x20
    // 0x61320c: CheckStackOverflow
    //     0x61320c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613210: cmp             SP, x16
    //     0x613214: b.ls            #0x61333c
    // 0x613218: ldr             x0, [fp, #0x10]
    // 0x61321c: LoadField: r1 = r0->field_13
    //     0x61321c: ldur            w1, [x0, #0x13]
    // 0x613220: DecompressPointer r1
    //     0x613220: add             x1, x1, HEAP, lsl #32
    // 0x613224: cmp             w1, NULL
    // 0x613228: b.eq            #0x61332c
    // 0x61322c: LoadField: r2 = r0->field_17
    //     0x61322c: ldur            w2, [x0, #0x17]
    // 0x613230: DecompressPointer r2
    //     0x613230: add             x2, x2, HEAP, lsl #32
    // 0x613234: cmp             w2, NULL
    // 0x613238: b.eq            #0x613344
    // 0x61323c: LoadField: r0 = r2->field_27
    //     0x61323c: ldur            w0, [x2, #0x27]
    // 0x613240: DecompressPointer r0
    //     0x613240: add             x0, x0, HEAP, lsl #32
    // 0x613244: eor             x2, x0, #0x10
    // 0x613248: stur            x2, [fp, #-8]
    // 0x61324c: SaveReg r1
    //     0x61324c: str             x1, [SP, #-8]!
    // 0x613250: r0 = iterator()
    //     0x613250: bl              #0x9bb174  ; [dart:collection] __Set&_HashVMBase&SetMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashSetMixin::iterator
    // 0x613254: add             SP, SP, #8
    // 0x613258: stur            x0, [fp, #-0x18]
    // 0x61325c: LoadField: r2 = r0->field_7
    //     0x61325c: ldur            w2, [x0, #7]
    // 0x613260: DecompressPointer r2
    //     0x613260: add             x2, x2, HEAP, lsl #32
    // 0x613264: stur            x2, [fp, #-0x10]
    // 0x613268: ldur            x1, [fp, #-8]
    // 0x61326c: CheckStackOverflow
    //     0x61326c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x613270: cmp             SP, x16
    //     0x613274: b.ls            #0x613348
    // 0x613278: SaveReg r0
    //     0x613278: str             x0, [SP, #-8]!
    // 0x61327c: r0 = moveNext()
    //     0x61327c: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x613280: add             SP, SP, #8
    // 0x613284: tbnz            w0, #4, #0x61332c
    // 0x613288: ldur            x3, [fp, #-0x18]
    // 0x61328c: LoadField: r4 = r3->field_33
    //     0x61328c: ldur            w4, [x3, #0x33]
    // 0x613290: DecompressPointer r4
    //     0x613290: add             x4, x4, HEAP, lsl #32
    // 0x613294: stur            x4, [fp, #-0x20]
    // 0x613298: cmp             w4, NULL
    // 0x61329c: b.ne            #0x6132d0
    // 0x6132a0: mov             x0, x4
    // 0x6132a4: ldur            x2, [fp, #-0x10]
    // 0x6132a8: r1 = Null
    //     0x6132a8: mov             x1, NULL
    // 0x6132ac: cmp             w2, NULL
    // 0x6132b0: b.eq            #0x6132d0
    // 0x6132b4: LoadField: r4 = r2->field_17
    //     0x6132b4: ldur            w4, [x2, #0x17]
    // 0x6132b8: DecompressPointer r4
    //     0x6132b8: add             x4, x4, HEAP, lsl #32
    // 0x6132bc: r8 = X0
    //     0x6132bc: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x6132c0: LoadField: r9 = r4->field_7
    //     0x6132c0: ldur            x9, [x4, #7]
    // 0x6132c4: r3 = Null
    //     0x6132c4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41488] Null
    //     0x6132c8: ldr             x3, [x3, #0x488]
    // 0x6132cc: blr             x9
    // 0x6132d0: ldur            x1, [fp, #-8]
    // 0x6132d4: ldur            x0, [fp, #-0x20]
    // 0x6132d8: LoadField: r2 = r0->field_b
    //     0x6132d8: ldur            w2, [x0, #0xb]
    // 0x6132dc: DecompressPointer r2
    //     0x6132dc: add             x2, x2, HEAP, lsl #32
    // 0x6132e0: cmp             w1, w2
    // 0x6132e4: b.eq            #0x613320
    // 0x6132e8: StoreField: r0->field_b = r1
    //     0x6132e8: stur            w1, [x0, #0xb]
    // 0x6132ec: tbnz            w1, #4, #0x613300
    // 0x6132f0: SaveReg r0
    //     0x6132f0: str             x0, [SP, #-8]!
    // 0x6132f4: r0 = unscheduleTick()
    //     0x6132f4: bl              #0x593688  ; [package:flutter/src/scheduler/ticker.dart] Ticker::unscheduleTick
    // 0x6132f8: add             SP, SP, #8
    // 0x6132fc: b               #0x613320
    // 0x613300: SaveReg r0
    //     0x613300: str             x0, [SP, #-8]!
    // 0x613304: r0 = shouldScheduleTick()
    //     0x613304: bl              #0x592cdc  ; [package:flutter/src/scheduler/ticker.dart] Ticker::shouldScheduleTick
    // 0x613308: add             SP, SP, #8
    // 0x61330c: tbnz            w0, #4, #0x613320
    // 0x613310: ldur            x16, [fp, #-0x20]
    // 0x613314: SaveReg r16
    //     0x613314: str             x16, [SP, #-8]!
    // 0x613318: r0 = scheduleTick()
    //     0x613318: bl              #0x591b50  ; [package:flutter/src/scheduler/ticker.dart] Ticker::scheduleTick
    // 0x61331c: add             SP, SP, #8
    // 0x613320: ldur            x0, [fp, #-0x18]
    // 0x613324: ldur            x2, [fp, #-0x10]
    // 0x613328: b               #0x613268
    // 0x61332c: r0 = Null
    //     0x61332c: mov             x0, NULL
    // 0x613330: LeaveFrame
    //     0x613330: mov             SP, fp
    //     0x613334: ldp             fp, lr, [SP], #0x10
    // 0x613338: ret
    //     0x613338: ret             
    // 0x61333c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x61333c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x613340: b               #0x613218
    // 0x613344: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x613344: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x613348: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x613348: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x61334c: b               #0x613278
  }
  _ activate(/* No info */) {
    // ** addr: 0x81ec3c, size: 0x4c
    // 0x81ec3c: EnterFrame
    //     0x81ec3c: stp             fp, lr, [SP, #-0x10]!
    //     0x81ec40: mov             fp, SP
    // 0x81ec44: CheckStackOverflow
    //     0x81ec44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x81ec48: cmp             SP, x16
    //     0x81ec4c: b.ls            #0x81ec80
    // 0x81ec50: ldr             x16, [fp, #0x10]
    // 0x81ec54: SaveReg r16
    //     0x81ec54: str             x16, [SP, #-8]!
    // 0x81ec58: r0 = _updateTickerModeNotifier()
    //     0x81ec58: bl              #0x612ee4  ; [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickerModeNotifier
    // 0x81ec5c: add             SP, SP, #8
    // 0x81ec60: ldr             x16, [fp, #0x10]
    // 0x81ec64: SaveReg r16
    //     0x81ec64: str             x16, [SP, #-8]!
    // 0x81ec68: r0 = _updateTickers()
    //     0x81ec68: bl              #0x613200  ; [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickers
    // 0x81ec6c: add             SP, SP, #8
    // 0x81ec70: r0 = Null
    //     0x81ec70: mov             x0, NULL
    // 0x81ec74: LeaveFrame
    //     0x81ec74: mov             SP, fp
    //     0x81ec78: ldp             fp, lr, [SP], #0x10
    // 0x81ec7c: ret
    //     0x81ec7c: ret             
    // 0x81ec80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x81ec80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x81ec84: b               #0x81ec50
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4e6a4, size: 0x8c
    // 0xa4e6a4: EnterFrame
    //     0xa4e6a4: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e6a8: mov             fp, SP
    // 0xa4e6ac: AllocStack(0x8)
    //     0xa4e6ac: sub             SP, SP, #8
    // 0xa4e6b0: CheckStackOverflow
    //     0xa4e6b0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e6b4: cmp             SP, x16
    //     0xa4e6b8: b.ls            #0xa4e728
    // 0xa4e6bc: ldr             x0, [fp, #0x10]
    // 0xa4e6c0: LoadField: r1 = r0->field_17
    //     0xa4e6c0: ldur            w1, [x0, #0x17]
    // 0xa4e6c4: DecompressPointer r1
    //     0xa4e6c4: add             x1, x1, HEAP, lsl #32
    // 0xa4e6c8: stur            x1, [fp, #-8]
    // 0xa4e6cc: cmp             w1, NULL
    // 0xa4e6d0: b.ne            #0xa4e6dc
    // 0xa4e6d4: mov             x1, x0
    // 0xa4e6d8: b               #0xa4e714
    // 0xa4e6dc: r1 = 1
    //     0xa4e6dc: mov             x1, #1
    // 0xa4e6e0: r0 = AllocateContext()
    //     0xa4e6e0: bl              #0xd68aa4  ; AllocateContextStub
    // 0xa4e6e4: mov             x1, x0
    // 0xa4e6e8: ldr             x0, [fp, #0x10]
    // 0xa4e6ec: StoreField: r1->field_f = r0
    //     0xa4e6ec: stur            w0, [x1, #0xf]
    // 0xa4e6f0: mov             x2, x1
    // 0xa4e6f4: r1 = Function '_updateTickers@156311458':.
    //     0xa4e6f4: add             x1, PP, #0x41, lsl #12  ; [pp+0x41498] AnonymousClosure: (0x6131b8), in [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::_updateTickers (0x613200)
    //     0xa4e6f8: ldr             x1, [x1, #0x498]
    // 0xa4e6fc: r0 = AllocateClosure()
    //     0xa4e6fc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xa4e700: ldur            x16, [fp, #-8]
    // 0xa4e704: stp             x0, x16, [SP, #-0x10]!
    // 0xa4e708: r0 = removeListener()
    //     0xa4e708: bl              #0x6e83ac  ; [package:flutter/src/foundation/change_notifier.dart] ChangeNotifier::removeListener
    // 0xa4e70c: add             SP, SP, #0x10
    // 0xa4e710: ldr             x1, [fp, #0x10]
    // 0xa4e714: StoreField: r1->field_17 = rNULL
    //     0xa4e714: stur            NULL, [x1, #0x17]
    // 0xa4e718: r0 = Null
    //     0xa4e718: mov             x0, NULL
    // 0xa4e71c: LeaveFrame
    //     0xa4e71c: mov             SP, fp
    //     0xa4e720: ldp             fp, lr, [SP], #0x10
    // 0xa4e724: ret
    //     0xa4e724: ret             
    // 0xa4e728: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e728: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e72c: b               #0xa4e6bc
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa4e730, size: 0x48
    // 0xa4e730: EnterFrame
    //     0xa4e730: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e734: mov             fp, SP
    // 0xa4e738: ldr             x0, [fp, #0x10]
    // 0xa4e73c: LoadField: r1 = r0->field_17
    //     0xa4e73c: ldur            w1, [x0, #0x17]
    // 0xa4e740: DecompressPointer r1
    //     0xa4e740: add             x1, x1, HEAP, lsl #32
    // 0xa4e744: CheckStackOverflow
    //     0xa4e744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e748: cmp             SP, x16
    //     0xa4e74c: b.ls            #0xa4e770
    // 0xa4e750: LoadField: r0 = r1->field_f
    //     0xa4e750: ldur            w0, [x1, #0xf]
    // 0xa4e754: DecompressPointer r0
    //     0xa4e754: add             x0, x0, HEAP, lsl #32
    // 0xa4e758: SaveReg r0
    //     0xa4e758: str             x0, [SP, #-8]!
    // 0xa4e75c: r0 = dispose()
    //     0xa4e75c: bl              #0xa4e6a4  ; [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::dispose
    // 0xa4e760: add             SP, SP, #8
    // 0xa4e764: LeaveFrame
    //     0xa4e764: mov             SP, fp
    //     0xa4e768: ldp             fp, lr, [SP], #0x10
    // 0xa4e76c: ret
    //     0xa4e76c: ret             
    // 0xa4e770: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e770: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e774: b               #0xa4e750
  }
}

// class id: 3420, size: 0x2c, field offset: 0x1c
class BadgeState extends _BadgeState&State&TickerProviderStateMixin {

  late AnimationController _animationController; // offset: 0x1c
  late AnimationController _appearanceController; // offset: 0x20
  late Animation<double> _animation; // offset: 0x24

  _ didUpdateWidget(/* No info */) {
    // ** addr: 0x7971b0, size: 0x340
    // 0x7971b0: EnterFrame
    //     0x7971b0: stp             fp, lr, [SP, #-0x10]!
    //     0x7971b4: mov             fp, SP
    // 0x7971b8: CheckStackOverflow
    //     0x7971b8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x7971bc: cmp             SP, x16
    //     0x7971c0: b.ls            #0x797488
    // 0x7971c4: ldr             x0, [fp, #0x10]
    // 0x7971c8: r2 = Null
    //     0x7971c8: mov             x2, NULL
    // 0x7971cc: r1 = Null
    //     0x7971cc: mov             x1, NULL
    // 0x7971d0: r4 = 59
    //     0x7971d0: mov             x4, #0x3b
    // 0x7971d4: branchIfSmi(r0, 0x7971e0)
    //     0x7971d4: tbz             w0, #0, #0x7971e0
    // 0x7971d8: r4 = LoadClassIdInstr(r0)
    //     0x7971d8: ldur            x4, [x0, #-1]
    //     0x7971dc: ubfx            x4, x4, #0xc, #0x14
    // 0x7971e0: r17 = 4227
    //     0x7971e0: mov             x17, #0x1083
    // 0x7971e4: cmp             x4, x17
    // 0x7971e8: b.eq            #0x797200
    // 0x7971ec: r8 = Badge
    //     0x7971ec: add             x8, PP, #0x41, lsl #12  ; [pp+0x41420] Type: Badge
    //     0x7971f0: ldr             x8, [x8, #0x420]
    // 0x7971f4: r3 = Null
    //     0x7971f4: add             x3, PP, #0x41, lsl #12  ; [pp+0x41428] Null
    //     0x7971f8: ldr             x3, [x3, #0x428]
    // 0x7971fc: r0 = Badge()
    //     0x7971fc: bl              #0x612e08  ; IsType_Badge_Stub
    // 0x797200: ldr             x3, [fp, #0x18]
    // 0x797204: LoadField: r2 = r3->field_7
    //     0x797204: ldur            w2, [x3, #7]
    // 0x797208: DecompressPointer r2
    //     0x797208: add             x2, x2, HEAP, lsl #32
    // 0x79720c: ldr             x0, [fp, #0x10]
    // 0x797210: r1 = Null
    //     0x797210: mov             x1, NULL
    // 0x797214: cmp             w2, NULL
    // 0x797218: b.eq            #0x79723c
    // 0x79721c: LoadField: r4 = r2->field_17
    //     0x79721c: ldur            w4, [x2, #0x17]
    // 0x797220: DecompressPointer r4
    //     0x797220: add             x4, x4, HEAP, lsl #32
    // 0x797224: r8 = X0 bound StatefulWidget
    //     0x797224: add             x8, PP, #0xc, lsl #12  ; [pp+0xc858] TypeParameter: X0 bound StatefulWidget
    //     0x797228: ldr             x8, [x8, #0x858]
    // 0x79722c: LoadField: r9 = r4->field_7
    //     0x79722c: ldur            x9, [x4, #7]
    // 0x797230: r3 = Null
    //     0x797230: add             x3, PP, #0x41, lsl #12  ; [pp+0x41438] Null
    //     0x797234: ldr             x3, [x3, #0x438]
    // 0x797238: blr             x9
    // 0x79723c: ldr             x0, [fp, #0x18]
    // 0x797240: LoadField: r1 = r0->field_b
    //     0x797240: ldur            w1, [x0, #0xb]
    // 0x797244: DecompressPointer r1
    //     0x797244: add             x1, x1, HEAP, lsl #32
    // 0x797248: cmp             w1, NULL
    // 0x79724c: b.eq            #0x797490
    // 0x797250: r16 = Instance_MaterialColor
    //     0x797250: add             x16, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x797254: ldr             x16, [x16, #0xf60]
    // 0x797258: r30 = Instance_MaterialColor
    //     0x797258: add             lr, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x79725c: ldr             lr, [lr, #0xf60]
    // 0x797260: stp             lr, x16, [SP, #-0x10]!
    // 0x797264: r0 = ==()
    //     0x797264: bl              #0xc668f8  ; [package:flutter/src/painting/colors.dart] ColorSwatch::==
    // 0x797268: add             SP, SP, #0x10
    // 0x79726c: tbz             w0, #4, #0x7972cc
    // 0x797270: ldr             x0, [fp, #0x18]
    // 0x797274: LoadField: r1 = r0->field_b
    //     0x797274: ldur            w1, [x0, #0xb]
    // 0x797278: DecompressPointer r1
    //     0x797278: add             x1, x1, HEAP, lsl #32
    // 0x79727c: cmp             w1, NULL
    // 0x797280: b.eq            #0x797494
    // 0x797284: LoadField: r2 = r1->field_27
    //     0x797284: ldur            w2, [x1, #0x27]
    // 0x797288: DecompressPointer r2
    //     0x797288: add             x2, x2, HEAP, lsl #32
    // 0x79728c: tbnz            w2, #4, #0x7972cc
    // 0x797290: LoadField: r1 = r0->field_1b
    //     0x797290: ldur            w1, [x0, #0x1b]
    // 0x797294: DecompressPointer r1
    //     0x797294: add             x1, x1, HEAP, lsl #32
    // 0x797298: r16 = Sentinel
    //     0x797298: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x79729c: cmp             w1, w16
    // 0x7972a0: b.eq            #0x797498
    // 0x7972a4: SaveReg r1
    //     0x7972a4: str             x1, [SP, #-8]!
    // 0x7972a8: r0 = reset()
    //     0x7972a8: bl              #0x7974f0  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reset
    // 0x7972ac: add             SP, SP, #8
    // 0x7972b0: ldr             x0, [fp, #0x18]
    // 0x7972b4: LoadField: r1 = r0->field_1b
    //     0x7972b4: ldur            w1, [x0, #0x1b]
    // 0x7972b8: DecompressPointer r1
    //     0x7972b8: add             x1, x1, HEAP, lsl #32
    // 0x7972bc: SaveReg r1
    //     0x7972bc: str             x1, [SP, #-8]!
    // 0x7972c0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7972c0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7972c4: r0 = forward()
    //     0x7972c4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7972c8: add             SP, SP, #8
    // 0x7972cc: ldr             x1, [fp, #0x18]
    // 0x7972d0: ldr             x2, [fp, #0x10]
    // 0x7972d4: LoadField: r0 = r1->field_b
    //     0x7972d4: ldur            w0, [x1, #0xb]
    // 0x7972d8: DecompressPointer r0
    //     0x7972d8: add             x0, x0, HEAP, lsl #32
    // 0x7972dc: cmp             w0, NULL
    // 0x7972e0: b.eq            #0x7974a4
    // 0x7972e4: LoadField: r3 = r0->field_1b
    //     0x7972e4: ldur            w3, [x0, #0x1b]
    // 0x7972e8: DecompressPointer r3
    //     0x7972e8: add             x3, x3, HEAP, lsl #32
    // 0x7972ec: LoadField: r0 = r2->field_1b
    //     0x7972ec: ldur            w0, [x2, #0x1b]
    // 0x7972f0: DecompressPointer r0
    //     0x7972f0: add             x0, x0, HEAP, lsl #32
    // 0x7972f4: LoadField: r4 = r3->field_b
    //     0x7972f4: ldur            w4, [x3, #0xb]
    // 0x7972f8: DecompressPointer r4
    //     0x7972f8: add             x4, x4, HEAP, lsl #32
    // 0x7972fc: LoadField: r3 = r0->field_b
    //     0x7972fc: ldur            w3, [x0, #0xb]
    // 0x797300: DecompressPointer r3
    //     0x797300: add             x3, x3, HEAP, lsl #32
    // 0x797304: r0 = LoadClassIdInstr(r4)
    //     0x797304: ldur            x0, [x4, #-1]
    //     0x797308: ubfx            x0, x0, #0xc, #0x14
    // 0x79730c: stp             x3, x4, [SP, #-0x10]!
    // 0x797310: mov             lr, x0
    // 0x797314: ldr             lr, [x21, lr, lsl #3]
    // 0x797318: blr             lr
    // 0x79731c: add             SP, SP, #0x10
    // 0x797320: tbz             w0, #4, #0x797398
    // 0x797324: ldr             x0, [fp, #0x18]
    // 0x797328: LoadField: r1 = r0->field_b
    //     0x797328: ldur            w1, [x0, #0xb]
    // 0x79732c: DecompressPointer r1
    //     0x79732c: add             x1, x1, HEAP, lsl #32
    // 0x797330: cmp             w1, NULL
    // 0x797334: b.eq            #0x7974a8
    // 0x797338: LoadField: r2 = r1->field_27
    //     0x797338: ldur            w2, [x1, #0x27]
    // 0x79733c: DecompressPointer r2
    //     0x79733c: add             x2, x2, HEAP, lsl #32
    // 0x797340: tbnz            w2, #4, #0x79739c
    // 0x797344: LoadField: r1 = r0->field_1b
    //     0x797344: ldur            w1, [x0, #0x1b]
    // 0x797348: DecompressPointer r1
    //     0x797348: add             x1, x1, HEAP, lsl #32
    // 0x79734c: r16 = Sentinel
    //     0x79734c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x797350: cmp             w1, w16
    // 0x797354: b.eq            #0x7974ac
    // 0x797358: SaveReg r1
    //     0x797358: str             x1, [SP, #-8]!
    // 0x79735c: r0 = reset()
    //     0x79735c: bl              #0x7974f0  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reset
    // 0x797360: add             SP, SP, #8
    // 0x797364: ldr             x0, [fp, #0x18]
    // 0x797368: LoadField: r1 = r0->field_1b
    //     0x797368: ldur            w1, [x0, #0x1b]
    // 0x79736c: DecompressPointer r1
    //     0x79736c: add             x1, x1, HEAP, lsl #32
    // 0x797370: SaveReg r1
    //     0x797370: str             x1, [SP, #-8]!
    // 0x797374: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x797374: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x797378: r0 = forward()
    //     0x797378: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x79737c: add             SP, SP, #8
    // 0x797380: ldr             x0, [fp, #0x18]
    // 0x797384: LoadField: r1 = r0->field_b
    //     0x797384: ldur            w1, [x0, #0xb]
    // 0x797388: DecompressPointer r1
    //     0x797388: add             x1, x1, HEAP, lsl #32
    // 0x79738c: cmp             w1, NULL
    // 0x797390: b.eq            #0x7974b8
    // 0x797394: b               #0x79739c
    // 0x797398: ldr             x0, [fp, #0x18]
    // 0x79739c: LoadField: r1 = r0->field_b
    //     0x79739c: ldur            w1, [x0, #0xb]
    // 0x7973a0: DecompressPointer r1
    //     0x7973a0: add             x1, x1, HEAP, lsl #32
    // 0x7973a4: cmp             w1, NULL
    // 0x7973a8: b.eq            #0x7974bc
    // 0x7973ac: LoadField: r2 = r1->field_27
    //     0x7973ac: ldur            w2, [x1, #0x27]
    // 0x7973b0: DecompressPointer r2
    //     0x7973b0: add             x2, x2, HEAP, lsl #32
    // 0x7973b4: tbnz            w2, #4, #0x797418
    // 0x7973b8: ldr             x1, [fp, #0x10]
    // 0x7973bc: LoadField: r3 = r1->field_27
    //     0x7973bc: ldur            w3, [x1, #0x27]
    // 0x7973c0: DecompressPointer r3
    //     0x7973c0: add             x3, x3, HEAP, lsl #32
    // 0x7973c4: tbz             w3, #4, #0x79741c
    // 0x7973c8: LoadField: r1 = r0->field_1b
    //     0x7973c8: ldur            w1, [x0, #0x1b]
    // 0x7973cc: DecompressPointer r1
    //     0x7973cc: add             x1, x1, HEAP, lsl #32
    // 0x7973d0: r16 = Sentinel
    //     0x7973d0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7973d4: cmp             w1, w16
    // 0x7973d8: b.eq            #0x7974c0
    // 0x7973dc: SaveReg r1
    //     0x7973dc: str             x1, [SP, #-8]!
    // 0x7973e0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x7973e0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x7973e4: r0 = forward()
    //     0x7973e4: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x7973e8: add             SP, SP, #8
    // 0x7973ec: ldr             x0, [fp, #0x18]
    // 0x7973f0: LoadField: r1 = r0->field_1f
    //     0x7973f0: ldur            w1, [x0, #0x1f]
    // 0x7973f4: DecompressPointer r1
    //     0x7973f4: add             x1, x1, HEAP, lsl #32
    // 0x7973f8: r16 = Sentinel
    //     0x7973f8: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x7973fc: cmp             w1, w16
    // 0x797400: b.eq            #0x7974cc
    // 0x797404: SaveReg r1
    //     0x797404: str             x1, [SP, #-8]!
    // 0x797408: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x797408: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x79740c: r0 = forward()
    //     0x79740c: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x797410: add             SP, SP, #8
    // 0x797414: b               #0x797478
    // 0x797418: ldr             x1, [fp, #0x10]
    // 0x79741c: tbz             w2, #4, #0x797478
    // 0x797420: LoadField: r2 = r1->field_27
    //     0x797420: ldur            w2, [x1, #0x27]
    // 0x797424: DecompressPointer r2
    //     0x797424: add             x2, x2, HEAP, lsl #32
    // 0x797428: tbnz            w2, #4, #0x797478
    // 0x79742c: LoadField: r1 = r0->field_1b
    //     0x79742c: ldur            w1, [x0, #0x1b]
    // 0x797430: DecompressPointer r1
    //     0x797430: add             x1, x1, HEAP, lsl #32
    // 0x797434: r16 = Sentinel
    //     0x797434: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x797438: cmp             w1, w16
    // 0x79743c: b.eq            #0x7974d8
    // 0x797440: SaveReg r1
    //     0x797440: str             x1, [SP, #-8]!
    // 0x797444: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x797444: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x797448: r0 = reverse()
    //     0x797448: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x79744c: add             SP, SP, #8
    // 0x797450: ldr             x0, [fp, #0x18]
    // 0x797454: LoadField: r1 = r0->field_1f
    //     0x797454: ldur            w1, [x0, #0x1f]
    // 0x797458: DecompressPointer r1
    //     0x797458: add             x1, x1, HEAP, lsl #32
    // 0x79745c: r16 = Sentinel
    //     0x79745c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x797460: cmp             w1, w16
    // 0x797464: b.eq            #0x7974e4
    // 0x797468: SaveReg r1
    //     0x797468: str             x1, [SP, #-8]!
    // 0x79746c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x79746c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x797470: r0 = reverse()
    //     0x797470: bl              #0x591170  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::reverse
    // 0x797474: add             SP, SP, #8
    // 0x797478: r0 = Null
    //     0x797478: mov             x0, NULL
    // 0x79747c: LeaveFrame
    //     0x79747c: mov             SP, fp
    //     0x797480: ldp             fp, lr, [SP], #0x10
    // 0x797484: ret
    //     0x797484: ret             
    // 0x797488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x797488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x79748c: b               #0x7971c4
    // 0x797490: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x797490: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x797494: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x797494: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x797498: r9 = _animationController
    //     0x797498: add             x9, PP, #0x41, lsl #12  ; [pp+0x41410] Field <BadgeState._animationController@143004262>: late (offset: 0x1c)
    //     0x79749c: ldr             x9, [x9, #0x410]
    // 0x7974a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7974a0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7974a4: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7974a4: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7974a8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7974a8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7974ac: r9 = _animationController
    //     0x7974ac: add             x9, PP, #0x41, lsl #12  ; [pp+0x41410] Field <BadgeState._animationController@143004262>: late (offset: 0x1c)
    //     0x7974b0: ldr             x9, [x9, #0x410]
    // 0x7974b4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7974b4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7974b8: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7974b8: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7974bc: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x7974bc: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x7974c0: r9 = _animationController
    //     0x7974c0: add             x9, PP, #0x41, lsl #12  ; [pp+0x41410] Field <BadgeState._animationController@143004262>: late (offset: 0x1c)
    //     0x7974c4: ldr             x9, [x9, #0x410]
    // 0x7974c8: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7974c8: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7974cc: r9 = _appearanceController
    //     0x7974cc: add             x9, PP, #0x41, lsl #12  ; [pp+0x41418] Field <BadgeState._appearanceController@143004262>: late (offset: 0x20)
    //     0x7974d0: ldr             x9, [x9, #0x418]
    // 0x7974d4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7974d4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7974d8: r9 = _animationController
    //     0x7974d8: add             x9, PP, #0x41, lsl #12  ; [pp+0x41410] Field <BadgeState._animationController@143004262>: late (offset: 0x1c)
    //     0x7974dc: ldr             x9, [x9, #0x410]
    // 0x7974e0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7974e0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x7974e4: r9 = _appearanceController
    //     0x7974e4: add             x9, PP, #0x41, lsl #12  ; [pp+0x41418] Field <BadgeState._appearanceController@143004262>: late (offset: 0x20)
    //     0x7974e8: ldr             x9, [x9, #0x418]
    // 0x7974ec: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x7974ec: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ build(/* No info */) {
    // ** addr: 0x82141c, size: 0x124
    // 0x82141c: EnterFrame
    //     0x82141c: stp             fp, lr, [SP, #-0x10]!
    //     0x821420: mov             fp, SP
    // 0x821424: AllocStack(0x20)
    //     0x821424: sub             SP, SP, #0x20
    // 0x821428: CheckStackOverflow
    //     0x821428: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82142c: cmp             SP, x16
    //     0x821430: b.ls            #0x821534
    // 0x821434: ldr             x0, [fp, #0x18]
    // 0x821438: LoadField: r1 = r0->field_b
    //     0x821438: ldur            w1, [x0, #0xb]
    // 0x82143c: DecompressPointer r1
    //     0x82143c: add             x1, x1, HEAP, lsl #32
    // 0x821440: cmp             w1, NULL
    // 0x821444: b.eq            #0x82153c
    // 0x821448: LoadField: r2 = r1->field_b
    //     0x821448: ldur            w2, [x1, #0xb]
    // 0x82144c: DecompressPointer r2
    //     0x82144c: add             x2, x2, HEAP, lsl #32
    // 0x821450: stur            x2, [fp, #-0x10]
    // 0x821454: LoadField: r3 = r1->field_17
    //     0x821454: ldur            w3, [x1, #0x17]
    // 0x821458: DecompressPointer r3
    //     0x821458: add             x3, x3, HEAP, lsl #32
    // 0x82145c: stur            x3, [fp, #-8]
    // 0x821460: SaveReg r0
    //     0x821460: str             x0, [SP, #-8]!
    // 0x821464: r0 = _getBadge()
    //     0x821464: bl              #0x82212c  ; [package:badges/src/badge.dart] BadgeState::_getBadge
    // 0x821468: add             SP, SP, #8
    // 0x82146c: stur            x0, [fp, #-0x18]
    // 0x821470: r0 = GestureDetector()
    //     0x821470: bl              #0x822118  ; AllocateGestureDetectorStub -> GestureDetector (size=0x104)
    // 0x821474: stur            x0, [fp, #-0x20]
    // 0x821478: stp             NULL, x0, [SP, #-0x10]!
    // 0x82147c: ldur            x16, [fp, #-0x18]
    // 0x821480: SaveReg r16
    //     0x821480: str             x16, [SP, #-8]!
    // 0x821484: r4 = const [0, 0x3, 0x3, 0x1, child, 0x2, onTap, 0x1, null]
    //     0x821484: add             x4, PP, #0x1c, lsl #12  ; [pp+0x1c378] List(9) [0, 0x3, 0x3, 0x1, "child", 0x2, "onTap", 0x1, Null]
    //     0x821488: ldr             x4, [x4, #0x378]
    // 0x82148c: r0 = GestureDetector()
    //     0x82148c: bl              #0x821558  ; [package:flutter/src/widgets/gesture_detector.dart] GestureDetector::GestureDetector
    // 0x821490: add             SP, SP, #0x18
    // 0x821494: r0 = BadgePositioned()
    //     0x821494: bl              #0x82154c  ; AllocateBadgePositionedStub -> BadgePositioned (size=0x14)
    // 0x821498: mov             x3, x0
    // 0x82149c: ldur            x0, [fp, #-8]
    // 0x8214a0: stur            x3, [fp, #-0x18]
    // 0x8214a4: StoreField: r3->field_b = r0
    //     0x8214a4: stur            w0, [x3, #0xb]
    // 0x8214a8: ldur            x0, [fp, #-0x20]
    // 0x8214ac: StoreField: r3->field_f = r0
    //     0x8214ac: stur            w0, [x3, #0xf]
    // 0x8214b0: r1 = Null
    //     0x8214b0: mov             x1, NULL
    // 0x8214b4: r2 = 4
    //     0x8214b4: mov             x2, #4
    // 0x8214b8: r0 = AllocateArray()
    //     0x8214b8: bl              #0xd6987c  ; AllocateArrayStub
    // 0x8214bc: mov             x2, x0
    // 0x8214c0: ldur            x0, [fp, #-0x10]
    // 0x8214c4: stur            x2, [fp, #-8]
    // 0x8214c8: StoreField: r2->field_f = r0
    //     0x8214c8: stur            w0, [x2, #0xf]
    // 0x8214cc: ldur            x0, [fp, #-0x18]
    // 0x8214d0: StoreField: r2->field_13 = r0
    //     0x8214d0: stur            w0, [x2, #0x13]
    // 0x8214d4: r1 = <Widget>
    //     0x8214d4: add             x1, PP, #0xe, lsl #12  ; [pp+0xeea8] TypeArguments: <Widget>
    //     0x8214d8: ldr             x1, [x1, #0xea8]
    // 0x8214dc: r0 = AllocateGrowableArray()
    //     0x8214dc: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x8214e0: mov             x1, x0
    // 0x8214e4: ldur            x0, [fp, #-8]
    // 0x8214e8: stur            x1, [fp, #-0x10]
    // 0x8214ec: StoreField: r1->field_f = r0
    //     0x8214ec: stur            w0, [x1, #0xf]
    // 0x8214f0: r0 = 4
    //     0x8214f0: mov             x0, #4
    // 0x8214f4: StoreField: r1->field_b = r0
    //     0x8214f4: stur            w0, [x1, #0xb]
    // 0x8214f8: r0 = Stack()
    //     0x8214f8: bl              #0x821540  ; AllocateStackStub -> Stack (size=0x20)
    // 0x8214fc: r1 = Instance_AlignmentDirectional
    //     0x8214fc: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f70] Obj!AlignmentDirectional@b37971
    //     0x821500: ldr             x1, [x1, #0xf70]
    // 0x821504: StoreField: r0->field_f = r1
    //     0x821504: stur            w1, [x0, #0xf]
    // 0x821508: r1 = Instance_StackFit
    //     0x821508: add             x1, PP, #0x14, lsl #12  ; [pp+0x14f78] Obj!StackFit@b64771
    //     0x82150c: ldr             x1, [x1, #0xf78]
    // 0x821510: StoreField: r0->field_17 = r1
    //     0x821510: stur            w1, [x0, #0x17]
    // 0x821514: r1 = Instance_Clip
    //     0x821514: add             x1, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x821518: ldr             x1, [x1, #0xb38]
    // 0x82151c: StoreField: r0->field_1b = r1
    //     0x82151c: stur            w1, [x0, #0x1b]
    // 0x821520: ldur            x1, [fp, #-0x10]
    // 0x821524: StoreField: r0->field_b = r1
    //     0x821524: stur            w1, [x0, #0xb]
    // 0x821528: LeaveFrame
    //     0x821528: mov             SP, fp
    //     0x82152c: ldp             fp, lr, [SP], #0x10
    // 0x821530: ret
    //     0x821530: ret             
    // 0x821534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x821534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x821538: b               #0x821434
    // 0x82153c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82153c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getBadge(/* No info */) {
    // ** addr: 0x82212c, size: 0x204
    // 0x82212c: EnterFrame
    //     0x82212c: stp             fp, lr, [SP, #-0x10]!
    //     0x822130: mov             fp, SP
    // 0x822134: AllocStack(0x20)
    //     0x822134: sub             SP, SP, #0x20
    // 0x822138: CheckStackOverflow
    //     0x822138: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x82213c: cmp             SP, x16
    //     0x822140: b.ls            #0x82230c
    // 0x822144: r1 = 4
    //     0x822144: mov             x1, #4
    // 0x822148: r0 = AllocateContext()
    //     0x822148: bl              #0xd68aa4  ; AllocateContextStub
    // 0x82214c: mov             x1, x0
    // 0x822150: ldr             x0, [fp, #0x10]
    // 0x822154: stur            x1, [fp, #-0x10]
    // 0x822158: StoreField: r1->field_f = r0
    //     0x822158: stur            w0, [x1, #0xf]
    // 0x82215c: LoadField: r2 = r0->field_b
    //     0x82215c: ldur            w2, [x0, #0xb]
    // 0x822160: DecompressPointer r2
    //     0x822160: add             x2, x2, HEAP, lsl #32
    // 0x822164: cmp             w2, NULL
    // 0x822168: b.eq            #0x822314
    // 0x82216c: LoadField: r3 = r2->field_f
    //     0x82216c: ldur            w3, [x2, #0xf]
    // 0x822170: DecompressPointer r3
    //     0x822170: add             x3, x3, HEAP, lsl #32
    // 0x822174: LoadField: r2 = r3->field_7
    //     0x822174: ldur            w2, [x3, #7]
    // 0x822178: DecompressPointer r2
    //     0x822178: add             x2, x2, HEAP, lsl #32
    // 0x82217c: stur            x2, [fp, #-8]
    // 0x822180: r16 = Instance_BadgeShape
    //     0x822180: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c730] Obj!BadgeShape@b66c71
    //     0x822184: ldr             x16, [x16, #0x730]
    // 0x822188: cmp             w2, w16
    // 0x82218c: b.ne            #0x8221b0
    // 0x822190: r0 = CircleBorder()
    //     0x822190: bl              #0x70e75c  ; AllocateCircleBorderStub -> CircleBorder (size=0x14)
    // 0x822194: d0 = 0.000000
    //     0x822194: eor             v0.16b, v0.16b, v0.16b
    // 0x822198: StoreField: r0->field_b = d0
    //     0x822198: stur            d0, [x0, #0xb]
    // 0x82219c: r1 = Instance_BorderSide
    //     0x82219c: add             x1, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x8221a0: ldr             x1, [x1, #0x2f0]
    // 0x8221a4: StoreField: r0->field_7 = r1
    //     0x8221a4: stur            w1, [x0, #7]
    // 0x8221a8: mov             x1, x0
    // 0x8221ac: b               #0x8221e0
    // 0x8221b0: r1 = Instance_BorderSide
    //     0x8221b0: add             x1, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x8221b4: ldr             x1, [x1, #0x2f0]
    // 0x8221b8: LoadField: r0 = r3->field_b
    //     0x8221b8: ldur            w0, [x3, #0xb]
    // 0x8221bc: DecompressPointer r0
    //     0x8221bc: add             x0, x0, HEAP, lsl #32
    // 0x8221c0: stur            x0, [fp, #-0x18]
    // 0x8221c4: r0 = RoundedRectangleBorder()
    //     0x8221c4: bl              #0x70e8f4  ; AllocateRoundedRectangleBorderStub -> RoundedRectangleBorder (size=0x10)
    // 0x8221c8: mov             x1, x0
    // 0x8221cc: ldur            x0, [fp, #-0x18]
    // 0x8221d0: StoreField: r1->field_b = r0
    //     0x8221d0: stur            w0, [x1, #0xb]
    // 0x8221d4: r0 = Instance_BorderSide
    //     0x8221d4: add             x0, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x8221d8: ldr             x0, [x0, #0x2f0]
    // 0x8221dc: StoreField: r1->field_7 = r0
    //     0x8221dc: stur            w0, [x1, #7]
    // 0x8221e0: ldur            x2, [fp, #-0x10]
    // 0x8221e4: ldur            x0, [fp, #-8]
    // 0x8221e8: StoreField: r2->field_13 = r1
    //     0x8221e8: stur            w1, [x2, #0x13]
    // 0x8221ec: r16 = Instance_BadgeShape
    //     0x8221ec: add             x16, PP, #0x41, lsl #12  ; [pp+0x41448] Obj!BadgeShape@b66c51
    //     0x8221f0: ldr             x16, [x16, #0x448]
    // 0x8221f4: cmp             w0, w16
    // 0x8221f8: b.ne            #0x822204
    // 0x8221fc: r1 = true
    //     0x8221fc: add             x1, NULL, #0x20  ; true
    // 0x822200: b               #0x82221c
    // 0x822204: r16 = Instance_BadgeShape
    //     0x822204: add             x16, PP, #0x41, lsl #12  ; [pp+0x41450] Obj!BadgeShape@b66c31
    //     0x822208: ldr             x16, [x16, #0x450]
    // 0x82220c: cmp             w0, w16
    // 0x822210: r16 = true
    //     0x822210: add             x16, NULL, #0x20  ; true
    // 0x822214: r17 = false
    //     0x822214: add             x17, NULL, #0x30  ; false
    // 0x822218: csel            x1, x16, x17, eq
    // 0x82221c: ldr             x0, [fp, #0x10]
    // 0x822220: StoreField: r2->field_17 = r1
    //     0x822220: stur            w1, [x2, #0x17]
    // 0x822224: StoreField: r2->field_1b = rNULL
    //     0x822224: stur            NULL, [x2, #0x1b]
    // 0x822228: r16 = Instance_SlideTween
    //     0x822228: add             x16, PP, #0x41, lsl #12  ; [pp+0x41458] Obj!SlideTween@b5c861
    //     0x82222c: ldr             x16, [x16, #0x458]
    // 0x822230: SaveReg r16
    //     0x822230: str             x16, [SP, #-8]!
    // 0x822234: r0 = toTween()
    //     0x822234: bl              #0x82233c  ; [package:badges/src/badge_animation.dart] SlideTween::toTween
    // 0x822238: add             SP, SP, #8
    // 0x82223c: mov             x1, x0
    // 0x822240: ldr             x0, [fp, #0x10]
    // 0x822244: LoadField: r2 = r0->field_23
    //     0x822244: ldur            w2, [x0, #0x23]
    // 0x822248: DecompressPointer r2
    //     0x822248: add             x2, x2, HEAP, lsl #32
    // 0x82224c: r16 = Sentinel
    //     0x82224c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x822250: cmp             w2, w16
    // 0x822254: b.eq            #0x822318
    // 0x822258: stp             x2, x1, [SP, #-0x10]!
    // 0x82225c: r0 = animate()
    //     0x82225c: bl              #0x5a1260  ; [package:flutter/src/animation/tween.dart] Animatable::animate
    // 0x822260: add             SP, SP, #0x10
    // 0x822264: mov             x2, x0
    // 0x822268: ldr             x0, [fp, #0x10]
    // 0x82226c: stur            x2, [fp, #-0x18]
    // 0x822270: LoadField: r3 = r0->field_1f
    //     0x822270: ldur            w3, [x0, #0x1f]
    // 0x822274: DecompressPointer r3
    //     0x822274: add             x3, x3, HEAP, lsl #32
    // 0x822278: r16 = Sentinel
    //     0x822278: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x82227c: cmp             w3, w16
    // 0x822280: b.eq            #0x822324
    // 0x822284: stur            x3, [fp, #-8]
    // 0x822288: r1 = <double>
    //     0x822288: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x82228c: r0 = CurvedAnimation()
    //     0x82228c: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x822290: stur            x0, [fp, #-0x20]
    // 0x822294: r16 = Instance__Linear
    //     0x822294: add             x16, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x822298: ldr             x16, [x16, #0x300]
    // 0x82229c: stp             x16, x0, [SP, #-0x10]!
    // 0x8222a0: ldur            x16, [fp, #-8]
    // 0x8222a4: SaveReg r16
    //     0x8222a4: str             x16, [SP, #-8]!
    // 0x8222a8: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x8222a8: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x8222ac: r0 = CurvedAnimation()
    //     0x8222ac: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x8222b0: add             SP, SP, #0x18
    // 0x8222b4: ldur            x2, [fp, #-0x10]
    // 0x8222b8: r1 = Function '<anonymous closure>':.
    //     0x8222b8: add             x1, PP, #0x41, lsl #12  ; [pp+0x41460] AnonymousClosure: (0x822370), of [package:badges/src/badge.dart] BadgeState
    //     0x8222bc: ldr             x1, [x1, #0x460]
    // 0x8222c0: r0 = AllocateClosure()
    //     0x8222c0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x8222c4: stur            x0, [fp, #-8]
    // 0x8222c8: r0 = AnimatedBuilder()
    //     0x8222c8: bl              #0x822330  ; AllocateAnimatedBuilderStub -> AnimatedBuilder (size=0x18)
    // 0x8222cc: mov             x1, x0
    // 0x8222d0: ldur            x0, [fp, #-8]
    // 0x8222d4: stur            x1, [fp, #-0x10]
    // 0x8222d8: StoreField: r1->field_f = r0
    //     0x8222d8: stur            w0, [x1, #0xf]
    // 0x8222dc: ldur            x0, [fp, #-0x20]
    // 0x8222e0: StoreField: r1->field_b = r0
    //     0x8222e0: stur            w0, [x1, #0xb]
    // 0x8222e4: r0 = SlideTransition()
    //     0x8222e4: bl              #0x5a122c  ; AllocateSlideTransitionStub -> SlideTransition (size=0x1c)
    // 0x8222e8: r1 = true
    //     0x8222e8: add             x1, NULL, #0x20  ; true
    // 0x8222ec: StoreField: r0->field_13 = r1
    //     0x8222ec: stur            w1, [x0, #0x13]
    // 0x8222f0: ldur            x1, [fp, #-0x10]
    // 0x8222f4: StoreField: r0->field_17 = r1
    //     0x8222f4: stur            w1, [x0, #0x17]
    // 0x8222f8: ldur            x1, [fp, #-0x18]
    // 0x8222fc: StoreField: r0->field_b = r1
    //     0x8222fc: stur            w1, [x0, #0xb]
    // 0x822300: LeaveFrame
    //     0x822300: mov             SP, fp
    //     0x822304: ldp             fp, lr, [SP], #0x10
    // 0x822308: ret
    //     0x822308: ret             
    // 0x82230c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x82230c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x822310: b               #0x822144
    // 0x822314: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822314: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x822318: r9 = _animation
    //     0x822318: add             x9, PP, #0x41, lsl #12  ; [pp+0x41468] Field <BadgeState._animation@143004262>: late (offset: 0x24)
    //     0x82231c: ldr             x9, [x9, #0x468]
    // 0x822320: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x822320: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x822324: r9 = _appearanceController
    //     0x822324: add             x9, PP, #0x41, lsl #12  ; [pp+0x41418] Field <BadgeState._appearanceController@143004262>: late (offset: 0x20)
    //     0x822328: ldr             x9, [x9, #0x418]
    // 0x82232c: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x82232c: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Opacity <anonymous closure>(dynamic, BuildContext, Widget?) {
    // ** addr: 0x822370, size: 0x324
    // 0x822370: EnterFrame
    //     0x822370: stp             fp, lr, [SP, #-0x10]!
    //     0x822374: mov             fp, SP
    // 0x822378: AllocStack(0x38)
    //     0x822378: sub             SP, SP, #0x38
    // 0x82237c: SetupParameters()
    //     0x82237c: ldr             x0, [fp, #0x20]
    //     0x822380: ldur            w1, [x0, #0x17]
    //     0x822384: add             x1, x1, HEAP, lsl #32
    //     0x822388: stur            x1, [fp, #-8]
    // 0x82238c: CheckStackOverflow
    //     0x82238c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x822390: cmp             SP, x16
    //     0x822394: b.ls            #0x822680
    // 0x822398: LoadField: r0 = r1->field_f
    //     0x822398: ldur            w0, [x1, #0xf]
    // 0x82239c: DecompressPointer r0
    //     0x82239c: add             x0, x0, HEAP, lsl #32
    // 0x8223a0: SaveReg r0
    //     0x8223a0: str             x0, [SP, #-8]!
    // 0x8223a4: r0 = _getOpacity()
    //     0x8223a4: bl              #0x822cf8  ; [package:badges/src/badge.dart] BadgeState::_getOpacity
    // 0x8223a8: add             SP, SP, #8
    // 0x8223ac: ldur            x1, [fp, #-8]
    // 0x8223b0: stur            d0, [fp, #-0x38]
    // 0x8223b4: LoadField: r2 = r1->field_17
    //     0x8223b4: ldur            w2, [x1, #0x17]
    // 0x8223b8: DecompressPointer r2
    //     0x8223b8: add             x2, x2, HEAP, lsl #32
    // 0x8223bc: mov             x0, x2
    // 0x8223c0: stur            x2, [fp, #-0x10]
    // 0x8223c4: tbnz            w0, #5, #0x8223cc
    // 0x8223c8: r0 = AssertBoolean()
    //     0x8223c8: bl              #0xd67df0  ; AssertBooleanStub
    // 0x8223cc: ldur            x0, [fp, #-0x10]
    // 0x8223d0: tbnz            w0, #4, #0x8224a0
    // 0x8223d4: ldur            x0, [fp, #-8]
    // 0x8223d8: LoadField: r1 = r0->field_f
    //     0x8223d8: ldur            w1, [x0, #0xf]
    // 0x8223dc: DecompressPointer r1
    //     0x8223dc: add             x1, x1, HEAP, lsl #32
    // 0x8223e0: LoadField: r2 = r1->field_b
    //     0x8223e0: ldur            w2, [x1, #0xb]
    // 0x8223e4: DecompressPointer r2
    //     0x8223e4: add             x2, x2, HEAP, lsl #32
    // 0x8223e8: cmp             w2, NULL
    // 0x8223ec: b.eq            #0x822688
    // 0x8223f0: LoadField: r1 = r2->field_f
    //     0x8223f0: ldur            w1, [x2, #0xf]
    // 0x8223f4: DecompressPointer r1
    //     0x8223f4: add             x1, x1, HEAP, lsl #32
    // 0x8223f8: LoadField: r2 = r1->field_7
    //     0x8223f8: ldur            w2, [x1, #7]
    // 0x8223fc: DecompressPointer r2
    //     0x8223fc: add             x2, x2, HEAP, lsl #32
    // 0x822400: SaveReg r2
    //     0x822400: str             x2, [SP, #-8]!
    // 0x822404: r0 = drawBadgeShape()
    //     0x822404: bl              #0x822c48  ; [package:badges/src/utils/drawing_utils.dart] DrawingUtils::drawBadgeShape
    // 0x822408: add             SP, SP, #8
    // 0x82240c: mov             x1, x0
    // 0x822410: ldur            x0, [fp, #-8]
    // 0x822414: stur            x1, [fp, #-0x20]
    // 0x822418: LoadField: r2 = r0->field_f
    //     0x822418: ldur            w2, [x0, #0xf]
    // 0x82241c: DecompressPointer r2
    //     0x82241c: add             x2, x2, HEAP, lsl #32
    // 0x822420: LoadField: r0 = r2->field_b
    //     0x822420: ldur            w0, [x2, #0xb]
    // 0x822424: DecompressPointer r0
    //     0x822424: add             x0, x0, HEAP, lsl #32
    // 0x822428: cmp             w0, NULL
    // 0x82242c: b.eq            #0x82268c
    // 0x822430: LoadField: r2 = r0->field_f
    //     0x822430: ldur            w2, [x0, #0xf]
    // 0x822434: DecompressPointer r2
    //     0x822434: add             x2, x2, HEAP, lsl #32
    // 0x822438: LoadField: r3 = r2->field_27
    //     0x822438: ldur            w3, [x2, #0x27]
    // 0x82243c: DecompressPointer r3
    //     0x82243c: add             x3, x3, HEAP, lsl #32
    // 0x822440: stur            x3, [fp, #-0x18]
    // 0x822444: LoadField: r2 = r0->field_1b
    //     0x822444: ldur            w2, [x0, #0x1b]
    // 0x822448: DecompressPointer r2
    //     0x822448: add             x2, x2, HEAP, lsl #32
    // 0x82244c: stur            x2, [fp, #-0x10]
    // 0x822450: r0 = Padding()
    //     0x822450: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x822454: mov             x1, x0
    // 0x822458: ldur            x0, [fp, #-0x18]
    // 0x82245c: stur            x1, [fp, #-0x28]
    // 0x822460: StoreField: r1->field_f = r0
    //     0x822460: stur            w0, [x1, #0xf]
    // 0x822464: ldur            x0, [fp, #-0x10]
    // 0x822468: StoreField: r1->field_b = r0
    //     0x822468: stur            w0, [x1, #0xb]
    // 0x82246c: r0 = CustomPaint()
    //     0x82246c: bl              #0x822c30  ; AllocateCustomPaintStub -> CustomPaint (size=0x24)
    // 0x822470: mov             x1, x0
    // 0x822474: ldur            x0, [fp, #-0x20]
    // 0x822478: StoreField: r1->field_f = r0
    //     0x822478: stur            w0, [x1, #0xf]
    // 0x82247c: r0 = Instance_Size
    //     0x82247c: ldr             x0, [PP, #0x4de0]  ; [pp+0x4de0] Obj!Size@b5ec51
    // 0x822480: StoreField: r1->field_17 = r0
    //     0x822480: stur            w0, [x1, #0x17]
    // 0x822484: r2 = false
    //     0x822484: add             x2, NULL, #0x30  ; false
    // 0x822488: StoreField: r1->field_1b = r2
    //     0x822488: stur            w2, [x1, #0x1b]
    // 0x82248c: StoreField: r1->field_1f = r2
    //     0x82248c: stur            w2, [x1, #0x1f]
    // 0x822490: ldur            x0, [fp, #-0x28]
    // 0x822494: StoreField: r1->field_b = r0
    //     0x822494: stur            w0, [x1, #0xb]
    // 0x822498: mov             x0, x1
    // 0x82249c: b               #0x822650
    // 0x8224a0: ldur            x0, [fp, #-8]
    // 0x8224a4: r2 = false
    //     0x8224a4: add             x2, NULL, #0x30  ; false
    // 0x8224a8: LoadField: r1 = r0->field_13
    //     0x8224a8: ldur            w1, [x0, #0x13]
    // 0x8224ac: DecompressPointer r1
    //     0x8224ac: add             x1, x1, HEAP, lsl #32
    // 0x8224b0: stur            x1, [fp, #-0x28]
    // 0x8224b4: LoadField: r3 = r0->field_f
    //     0x8224b4: ldur            w3, [x0, #0xf]
    // 0x8224b8: DecompressPointer r3
    //     0x8224b8: add             x3, x3, HEAP, lsl #32
    // 0x8224bc: LoadField: r4 = r3->field_b
    //     0x8224bc: ldur            w4, [x3, #0xb]
    // 0x8224c0: DecompressPointer r4
    //     0x8224c0: add             x4, x4, HEAP, lsl #32
    // 0x8224c4: stur            x4, [fp, #-0x20]
    // 0x8224c8: cmp             w4, NULL
    // 0x8224cc: b.eq            #0x822690
    // 0x8224d0: LoadField: r3 = r4->field_f
    //     0x8224d0: ldur            w3, [x4, #0xf]
    // 0x8224d4: DecompressPointer r3
    //     0x8224d4: add             x3, x3, HEAP, lsl #32
    // 0x8224d8: stur            x3, [fp, #-0x18]
    // 0x8224dc: LoadField: r5 = r3->field_7
    //     0x8224dc: ldur            w5, [x3, #7]
    // 0x8224e0: DecompressPointer r5
    //     0x8224e0: add             x5, x5, HEAP, lsl #32
    // 0x8224e4: r16 = Instance_BadgeShape
    //     0x8224e4: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c730] Obj!BadgeShape@b66c71
    //     0x8224e8: ldr             x16, [x16, #0x730]
    // 0x8224ec: cmp             w5, w16
    // 0x8224f0: b.ne            #0x82252c
    // 0x8224f4: LoadField: r5 = r0->field_1b
    //     0x8224f4: ldur            w5, [x0, #0x1b]
    // 0x8224f8: DecompressPointer r5
    //     0x8224f8: add             x5, x5, HEAP, lsl #32
    // 0x8224fc: stur            x5, [fp, #-0x10]
    // 0x822500: r0 = BoxDecoration()
    //     0x822500: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x822504: r1 = Instance_MaterialColor
    //     0x822504: add             x1, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x822508: ldr             x1, [x1, #0xf60]
    // 0x82250c: StoreField: r0->field_7 = r1
    //     0x82250c: stur            w1, [x0, #7]
    // 0x822510: ldur            x1, [fp, #-0x10]
    // 0x822514: StoreField: r0->field_f = r1
    //     0x822514: stur            w1, [x0, #0xf]
    // 0x822518: r1 = Instance_BoxShape
    //     0x822518: add             x1, PP, #0x32, lsl #12  ; [pp+0x32f70] Obj!BoxShape@b64eb1
    //     0x82251c: ldr             x1, [x1, #0xf70]
    // 0x822520: StoreField: r0->field_23 = r1
    //     0x822520: stur            w1, [x0, #0x23]
    // 0x822524: mov             x3, x0
    // 0x822528: b               #0x822584
    // 0x82252c: mov             x2, x3
    // 0x822530: r1 = Instance_MaterialColor
    //     0x822530: add             x1, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x822534: ldr             x1, [x1, #0xf60]
    // 0x822538: LoadField: r3 = r2->field_b
    //     0x822538: ldur            w3, [x2, #0xb]
    // 0x82253c: DecompressPointer r3
    //     0x82253c: add             x3, x3, HEAP, lsl #32
    // 0x822540: stur            x3, [fp, #-0x30]
    // 0x822544: LoadField: r4 = r0->field_1b
    //     0x822544: ldur            w4, [x0, #0x1b]
    // 0x822548: DecompressPointer r4
    //     0x822548: add             x4, x4, HEAP, lsl #32
    // 0x82254c: stur            x4, [fp, #-0x10]
    // 0x822550: r0 = BoxDecoration()
    //     0x822550: bl              #0x596220  ; AllocateBoxDecorationStub -> BoxDecoration (size=0x28)
    // 0x822554: mov             x1, x0
    // 0x822558: r0 = Instance_MaterialColor
    //     0x822558: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x82255c: ldr             x0, [x0, #0xf60]
    // 0x822560: StoreField: r1->field_7 = r0
    //     0x822560: stur            w0, [x1, #7]
    // 0x822564: ldur            x0, [fp, #-0x10]
    // 0x822568: StoreField: r1->field_f = r0
    //     0x822568: stur            w0, [x1, #0xf]
    // 0x82256c: ldur            x0, [fp, #-0x30]
    // 0x822570: StoreField: r1->field_13 = r0
    //     0x822570: stur            w0, [x1, #0x13]
    // 0x822574: r0 = Instance_BoxShape
    //     0x822574: add             x0, PP, #0xe, lsl #12  ; [pp+0xee68] Obj!BoxShape@b64e91
    //     0x822578: ldr             x0, [x0, #0xe68]
    // 0x82257c: StoreField: r1->field_23 = r0
    //     0x82257c: stur            w0, [x1, #0x23]
    // 0x822580: mov             x3, x1
    // 0x822584: ldur            x1, [fp, #-0x28]
    // 0x822588: ldur            x0, [fp, #-0x18]
    // 0x82258c: ldur            x2, [fp, #-0x20]
    // 0x822590: stur            x3, [fp, #-0x30]
    // 0x822594: LoadField: r4 = r0->field_27
    //     0x822594: ldur            w4, [x0, #0x27]
    // 0x822598: DecompressPointer r4
    //     0x822598: add             x4, x4, HEAP, lsl #32
    // 0x82259c: stur            x4, [fp, #-0x10]
    // 0x8225a0: LoadField: r0 = r2->field_1b
    //     0x8225a0: ldur            w0, [x2, #0x1b]
    // 0x8225a4: DecompressPointer r0
    //     0x8225a4: add             x0, x0, HEAP, lsl #32
    // 0x8225a8: stur            x0, [fp, #-8]
    // 0x8225ac: r0 = Padding()
    //     0x8225ac: bl              #0x822c3c  ; AllocatePaddingStub -> Padding (size=0x14)
    // 0x8225b0: mov             x1, x0
    // 0x8225b4: ldur            x0, [fp, #-0x10]
    // 0x8225b8: stur            x1, [fp, #-0x18]
    // 0x8225bc: StoreField: r1->field_f = r0
    //     0x8225bc: stur            w0, [x1, #0xf]
    // 0x8225c0: ldur            x0, [fp, #-8]
    // 0x8225c4: StoreField: r1->field_b = r0
    //     0x8225c4: stur            w0, [x1, #0xb]
    // 0x8225c8: r0 = AnimatedContainer()
    //     0x8225c8: bl              #0x822c24  ; AllocateAnimatedContainerStub -> AnimatedContainer (size=0x40)
    // 0x8225cc: stur            x0, [fp, #-8]
    // 0x8225d0: r16 = Instance_Duration
    //     0x8225d0: ldr             x16, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x8225d4: stp             x16, x0, [SP, #-0x10]!
    // 0x8225d8: r16 = Instance__Linear
    //     0x8225d8: add             x16, PP, #0xd, lsl #12  ; [pp+0xd300] Obj!_Linear<double>@b4fc81
    //     0x8225dc: ldr             x16, [x16, #0x300]
    // 0x8225e0: ldur            lr, [fp, #-0x30]
    // 0x8225e4: stp             lr, x16, [SP, #-0x10]!
    // 0x8225e8: ldur            x16, [fp, #-0x18]
    // 0x8225ec: SaveReg r16
    //     0x8225ec: str             x16, [SP, #-8]!
    // 0x8225f0: r4 = const [0, 0x5, 0x5, 0x2, child, 0x4, curve, 0x2, decoration, 0x3, null]
    //     0x8225f0: add             x4, PP, #0x41, lsl #12  ; [pp+0x41470] List(11) [0, 0x5, 0x5, 0x2, "child", 0x4, "curve", 0x2, "decoration", 0x3, Null]
    //     0x8225f4: ldr             x4, [x4, #0x470]
    // 0x8225f8: r0 = AnimatedContainer()
    //     0x8225f8: bl              #0x8226ac  ; [package:flutter/src/widgets/implicit_animations.dart] AnimatedContainer::AnimatedContainer
    // 0x8225fc: add             SP, SP, #0x28
    // 0x822600: r0 = Material()
    //     0x822600: bl              #0x8226a0  ; AllocateMaterialStub -> Material (size=0x40)
    // 0x822604: mov             x1, x0
    // 0x822608: r0 = Instance_MaterialType
    //     0x822608: add             x0, PP, #0x15, lsl #12  ; [pp+0x152a8] Obj!MaterialType@b65511
    //     0x82260c: ldr             x0, [x0, #0x2a8]
    // 0x822610: StoreField: r1->field_f = r0
    //     0x822610: stur            w0, [x1, #0xf]
    // 0x822614: d0 = 2.000000
    //     0x822614: fmov            d0, #2.00000000
    // 0x822618: StoreField: r1->field_13 = d0
    //     0x822618: stur            d0, [x1, #0x13]
    // 0x82261c: ldur            x0, [fp, #-0x28]
    // 0x822620: StoreField: r1->field_2b = r0
    //     0x822620: stur            w0, [x1, #0x2b]
    // 0x822624: r0 = true
    //     0x822624: add             x0, NULL, #0x20  ; true
    // 0x822628: StoreField: r1->field_2f = r0
    //     0x822628: stur            w0, [x1, #0x2f]
    // 0x82262c: r0 = Instance_Clip
    //     0x82262c: add             x0, PP, #0xd, lsl #12  ; [pp+0xdb38] Obj!Clip@b67651
    //     0x822630: ldr             x0, [x0, #0xb38]
    // 0x822634: StoreField: r1->field_33 = r0
    //     0x822634: stur            w0, [x1, #0x33]
    // 0x822638: r0 = Instance_Duration
    //     0x822638: add             x0, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x82263c: ldr             x0, [x0, #0x9e0]
    // 0x822640: StoreField: r1->field_37 = r0
    //     0x822640: stur            w0, [x1, #0x37]
    // 0x822644: ldur            x0, [fp, #-8]
    // 0x822648: StoreField: r1->field_b = r0
    //     0x822648: stur            w0, [x1, #0xb]
    // 0x82264c: mov             x0, x1
    // 0x822650: ldur            d0, [fp, #-0x38]
    // 0x822654: stur            x0, [fp, #-8]
    // 0x822658: r0 = Opacity()
    //     0x822658: bl              #0x822694  ; AllocateOpacityStub -> Opacity (size=0x1c)
    // 0x82265c: ldur            d0, [fp, #-0x38]
    // 0x822660: StoreField: r0->field_f = d0
    //     0x822660: stur            d0, [x0, #0xf]
    // 0x822664: r1 = false
    //     0x822664: add             x1, NULL, #0x30  ; false
    // 0x822668: StoreField: r0->field_17 = r1
    //     0x822668: stur            w1, [x0, #0x17]
    // 0x82266c: ldur            x1, [fp, #-8]
    // 0x822670: StoreField: r0->field_b = r1
    //     0x822670: stur            w1, [x0, #0xb]
    // 0x822674: LeaveFrame
    //     0x822674: mov             SP, fp
    //     0x822678: ldp             fp, lr, [SP], #0x10
    // 0x82267c: ret
    //     0x82267c: ret             
    // 0x822680: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x822680: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x822684: b               #0x822398
    // 0x822688: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822688: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x82268c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x82268c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x822690: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822690: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _getOpacity(/* No info */) {
    // ** addr: 0x822cf8, size: 0x70
    // 0x822cf8: EnterFrame
    //     0x822cf8: stp             fp, lr, [SP, #-0x10]!
    //     0x822cfc: mov             fp, SP
    // 0x822d00: ldr             x0, [fp, #0x10]
    // 0x822d04: LoadField: r1 = r0->field_b
    //     0x822d04: ldur            w1, [x0, #0xb]
    // 0x822d08: DecompressPointer r1
    //     0x822d08: add             x1, x1, HEAP, lsl #32
    // 0x822d0c: cmp             w1, NULL
    // 0x822d10: b.eq            #0x822d4c
    // 0x822d14: LoadField: r1 = r0->field_1f
    //     0x822d14: ldur            w1, [x0, #0x1f]
    // 0x822d18: DecompressPointer r1
    //     0x822d18: add             x1, x1, HEAP, lsl #32
    // 0x822d1c: r16 = Sentinel
    //     0x822d1c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x822d20: cmp             w1, w16
    // 0x822d24: b.eq            #0x822d50
    // 0x822d28: LoadField: r0 = r1->field_37
    //     0x822d28: ldur            w0, [x1, #0x37]
    // 0x822d2c: DecompressPointer r0
    //     0x822d2c: add             x0, x0, HEAP, lsl #32
    // 0x822d30: r16 = Sentinel
    //     0x822d30: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x822d34: cmp             w0, w16
    // 0x822d38: b.eq            #0x822d5c
    // 0x822d3c: LoadField: d0 = r0->field_7
    //     0x822d3c: ldur            d0, [x0, #7]
    // 0x822d40: LeaveFrame
    //     0x822d40: mov             SP, fp
    //     0x822d44: ldp             fp, lr, [SP], #0x10
    // 0x822d48: ret
    //     0x822d48: ret             
    // 0x822d4c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x822d4c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x822d50: r9 = _appearanceController
    //     0x822d50: add             x9, PP, #0x41, lsl #12  ; [pp+0x41418] Field <BadgeState._appearanceController@143004262>: late (offset: 0x20)
    //     0x822d54: ldr             x9, [x9, #0x418]
    // 0x822d58: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x822d58: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x822d5c: r9 = _value
    //     0x822d5c: add             x9, PP, #0xd, lsl #12  ; [pp+0xdbb0] Field <AnimationController._value@575066280>: late (offset: 0x38)
    //     0x822d60: ldr             x9, [x9, #0xbb0]
    // 0x822d64: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x822d64: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  _ initState(/* No info */) {
    // ** addr: 0x9d4c28, size: 0x1f8
    // 0x9d4c28: EnterFrame
    //     0x9d4c28: stp             fp, lr, [SP, #-0x10]!
    //     0x9d4c2c: mov             fp, SP
    // 0x9d4c30: AllocStack(0x10)
    //     0x9d4c30: sub             SP, SP, #0x10
    // 0x9d4c34: r0 = true
    //     0x9d4c34: add             x0, NULL, #0x20  ; true
    // 0x9d4c38: CheckStackOverflow
    //     0x9d4c38: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x9d4c3c: cmp             SP, x16
    //     0x9d4c40: b.ls            #0x9d4e04
    // 0x9d4c44: ldr             x2, [fp, #0x10]
    // 0x9d4c48: LoadField: r1 = r2->field_b
    //     0x9d4c48: ldur            w1, [x2, #0xb]
    // 0x9d4c4c: DecompressPointer r1
    //     0x9d4c4c: add             x1, x1, HEAP, lsl #32
    // 0x9d4c50: cmp             w1, NULL
    // 0x9d4c54: b.eq            #0x9d4e0c
    // 0x9d4c58: StoreField: r2->field_27 = r0
    //     0x9d4c58: stur            w0, [x2, #0x27]
    // 0x9d4c5c: r1 = <double>
    //     0x9d4c5c: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d4c60: r0 = AnimationController()
    //     0x9d4c60: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d4c64: stur            x0, [fp, #-8]
    // 0x9d4c68: ldr             x16, [fp, #0x10]
    // 0x9d4c6c: stp             x16, x0, [SP, #-0x10]!
    // 0x9d4c70: r16 = Instance_Duration
    //     0x9d4c70: add             x16, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x9d4c74: ldr             x16, [x16, #0x718]
    // 0x9d4c78: r30 = Instance_Duration
    //     0x9d4c78: add             lr, PP, #0x1f, lsl #12  ; [pp+0x1f718] Obj!Duration@b67b11
    //     0x9d4c7c: ldr             lr, [lr, #0x718]
    // 0x9d4c80: stp             lr, x16, [SP, #-0x10]!
    // 0x9d4c84: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0x9d4c84: add             x4, PP, #0x21, lsl #12  ; [pp+0x218b8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0x9d4c88: ldr             x4, [x4, #0x8b8]
    // 0x9d4c8c: r0 = AnimationController()
    //     0x9d4c8c: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d4c90: add             SP, SP, #0x20
    // 0x9d4c94: ldur            x0, [fp, #-8]
    // 0x9d4c98: ldr             x2, [fp, #0x10]
    // 0x9d4c9c: StoreField: r2->field_1b = r0
    //     0x9d4c9c: stur            w0, [x2, #0x1b]
    //     0x9d4ca0: ldurb           w16, [x2, #-1]
    //     0x9d4ca4: ldurb           w17, [x0, #-1]
    //     0x9d4ca8: and             x16, x17, x16, lsr #2
    //     0x9d4cac: tst             x16, HEAP, lsr #32
    //     0x9d4cb0: b.eq            #0x9d4cb8
    //     0x9d4cb4: bl              #0xd6828c
    // 0x9d4cb8: LoadField: r0 = r2->field_b
    //     0x9d4cb8: ldur            w0, [x2, #0xb]
    // 0x9d4cbc: DecompressPointer r0
    //     0x9d4cbc: add             x0, x0, HEAP, lsl #32
    // 0x9d4cc0: cmp             w0, NULL
    // 0x9d4cc4: b.eq            #0x9d4e10
    // 0x9d4cc8: r1 = <double>
    //     0x9d4cc8: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d4ccc: r0 = AnimationController()
    //     0x9d4ccc: bl              #0x6eaaf8  ; AllocateAnimationControllerStub -> AnimationController (size=0x4c)
    // 0x9d4cd0: stur            x0, [fp, #-8]
    // 0x9d4cd4: ldr             x16, [fp, #0x10]
    // 0x9d4cd8: stp             x16, x0, [SP, #-0x10]!
    // 0x9d4cdc: r16 = Instance_Duration
    //     0x9d4cdc: add             x16, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d4ce0: ldr             x16, [x16, #0x9e0]
    // 0x9d4ce4: r30 = Instance_Duration
    //     0x9d4ce4: add             lr, PP, #0xd, lsl #12  ; [pp+0xd9e0] Obj!Duration@b67ab1
    //     0x9d4ce8: ldr             lr, [lr, #0x9e0]
    // 0x9d4cec: stp             lr, x16, [SP, #-0x10]!
    // 0x9d4cf0: r4 = const [0, 0x4, 0x4, 0x2, duration, 0x2, reverseDuration, 0x3, null]
    //     0x9d4cf0: add             x4, PP, #0x21, lsl #12  ; [pp+0x218b8] List(9) [0, 0x4, 0x4, 0x2, "duration", 0x2, "reverseDuration", 0x3, Null]
    //     0x9d4cf4: ldr             x4, [x4, #0x8b8]
    // 0x9d4cf8: r0 = AnimationController()
    //     0x9d4cf8: bl              #0x6ea76c  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::AnimationController
    // 0x9d4cfc: add             SP, SP, #0x20
    // 0x9d4d00: ldur            x0, [fp, #-8]
    // 0x9d4d04: ldr             x2, [fp, #0x10]
    // 0x9d4d08: StoreField: r2->field_1f = r0
    //     0x9d4d08: stur            w0, [x2, #0x1f]
    //     0x9d4d0c: ldurb           w16, [x2, #-1]
    //     0x9d4d10: ldurb           w17, [x0, #-1]
    //     0x9d4d14: and             x16, x17, x16, lsr #2
    //     0x9d4d18: tst             x16, HEAP, lsr #32
    //     0x9d4d1c: b.eq            #0x9d4d24
    //     0x9d4d20: bl              #0xd6828c
    // 0x9d4d24: LoadField: r0 = r2->field_1b
    //     0x9d4d24: ldur            w0, [x2, #0x1b]
    // 0x9d4d28: DecompressPointer r0
    //     0x9d4d28: add             x0, x0, HEAP, lsl #32
    // 0x9d4d2c: stur            x0, [fp, #-8]
    // 0x9d4d30: LoadField: r1 = r2->field_b
    //     0x9d4d30: ldur            w1, [x2, #0xb]
    // 0x9d4d34: DecompressPointer r1
    //     0x9d4d34: add             x1, x1, HEAP, lsl #32
    // 0x9d4d38: cmp             w1, NULL
    // 0x9d4d3c: b.eq            #0x9d4e14
    // 0x9d4d40: r1 = <double>
    //     0x9d4d40: ldr             x1, [PP, #0x2548]  ; [pp+0x2548] TypeArguments: <double>
    // 0x9d4d44: r0 = CurvedAnimation()
    //     0x9d4d44: bl              #0x5a14dc  ; AllocateCurvedAnimationStub -> CurvedAnimation (size=0x1c)
    // 0x9d4d48: stur            x0, [fp, #-0x10]
    // 0x9d4d4c: r16 = Instance_ElasticOutCurve
    //     0x9d4d4c: add             x16, PP, #0x41, lsl #12  ; [pp+0x41480] Obj!ElasticOutCurve<double>@b4f2b1
    //     0x9d4d50: ldr             x16, [x16, #0x480]
    // 0x9d4d54: stp             x16, x0, [SP, #-0x10]!
    // 0x9d4d58: ldur            x16, [fp, #-8]
    // 0x9d4d5c: SaveReg r16
    //     0x9d4d5c: str             x16, [SP, #-8]!
    // 0x9d4d60: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x9d4d60: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x9d4d64: r0 = CurvedAnimation()
    //     0x9d4d64: bl              #0x5a12a0  ; [package:flutter/src/animation/animations.dart] CurvedAnimation::CurvedAnimation
    // 0x9d4d68: add             SP, SP, #0x18
    // 0x9d4d6c: ldur            x0, [fp, #-0x10]
    // 0x9d4d70: ldr             x1, [fp, #0x10]
    // 0x9d4d74: StoreField: r1->field_23 = r0
    //     0x9d4d74: stur            w0, [x1, #0x23]
    //     0x9d4d78: ldurb           w16, [x1, #-1]
    //     0x9d4d7c: ldurb           w17, [x0, #-1]
    //     0x9d4d80: and             x16, x17, x16, lsr #2
    //     0x9d4d84: tst             x16, HEAP, lsr #32
    //     0x9d4d88: b.eq            #0x9d4d90
    //     0x9d4d8c: bl              #0xd6826c
    // 0x9d4d90: LoadField: r0 = r1->field_b
    //     0x9d4d90: ldur            w0, [x1, #0xb]
    // 0x9d4d94: DecompressPointer r0
    //     0x9d4d94: add             x0, x0, HEAP, lsl #32
    // 0x9d4d98: cmp             w0, NULL
    // 0x9d4d9c: b.eq            #0x9d4e18
    // 0x9d4da0: LoadField: r2 = r0->field_27
    //     0x9d4da0: ldur            w2, [x0, #0x27]
    // 0x9d4da4: DecompressPointer r2
    //     0x9d4da4: add             x2, x2, HEAP, lsl #32
    // 0x9d4da8: tbnz            w2, #4, #0x9d4df4
    // 0x9d4dac: LoadField: r0 = r1->field_1b
    //     0x9d4dac: ldur            w0, [x1, #0x1b]
    // 0x9d4db0: DecompressPointer r0
    //     0x9d4db0: add             x0, x0, HEAP, lsl #32
    // 0x9d4db4: SaveReg r0
    //     0x9d4db4: str             x0, [SP, #-8]!
    // 0x9d4db8: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d4db8: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d4dbc: r0 = forward()
    //     0x9d4dbc: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x9d4dc0: add             SP, SP, #8
    // 0x9d4dc4: ldr             x0, [fp, #0x10]
    // 0x9d4dc8: LoadField: r1 = r0->field_1f
    //     0x9d4dc8: ldur            w1, [x0, #0x1f]
    // 0x9d4dcc: DecompressPointer r1
    //     0x9d4dcc: add             x1, x1, HEAP, lsl #32
    // 0x9d4dd0: SaveReg r1
    //     0x9d4dd0: str             x1, [SP, #-8]!
    // 0x9d4dd4: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x9d4dd4: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x9d4dd8: r0 = forward()
    //     0x9d4dd8: bl              #0x691638  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::forward
    // 0x9d4ddc: add             SP, SP, #8
    // 0x9d4de0: ldr             x1, [fp, #0x10]
    // 0x9d4de4: LoadField: r2 = r1->field_b
    //     0x9d4de4: ldur            w2, [x1, #0xb]
    // 0x9d4de8: DecompressPointer r2
    //     0x9d4de8: add             x2, x2, HEAP, lsl #32
    // 0x9d4dec: cmp             w2, NULL
    // 0x9d4df0: b.eq            #0x9d4e1c
    // 0x9d4df4: r0 = Null
    //     0x9d4df4: mov             x0, NULL
    // 0x9d4df8: LeaveFrame
    //     0x9d4df8: mov             SP, fp
    //     0x9d4dfc: ldp             fp, lr, [SP], #0x10
    // 0x9d4e00: ret
    //     0x9d4e00: ret             
    // 0x9d4e04: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x9d4e04: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x9d4e08: b               #0x9d4c44
    // 0x9d4e0c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4e0c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d4e10: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4e10: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d4e14: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4e14: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d4e18: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4e18: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x9d4e1c: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x9d4e1c: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  dynamic dispose(dynamic) {
    // ** addr: 0xa49f28, size: 0x18
    // 0xa49f28: r4 = 7
    //     0xa49f28: mov             x4, #7
    // 0xa49f2c: r1 = Function 'dispose':.
    //     0xa49f2c: add             x17, PP, #0x4c, lsl #12  ; [pp+0x4cbf0] AnonymousClosure: (0xa49f40), in [package:badges/src/badge.dart] BadgeState::dispose (0xa4e608)
    //     0xa49f30: ldr             x1, [x17, #0xbf0]
    // 0xa49f34: r24 = BuildNonGenericMethodExtractorStub
    //     0xa49f34: ldr             x24, [PP, #0x7080]  ; [pp+0x7080] Stub: BuildNonGenericMethodExtractor (0xd6a36c)
    // 0xa49f38: LoadField: r0 = r24->field_17
    //     0xa49f38: ldur            x0, [x24, #0x17]
    // 0xa49f3c: br              x0
  }
  [closure] void dispose(dynamic) {
    // ** addr: 0xa49f40, size: 0x48
    // 0xa49f40: EnterFrame
    //     0xa49f40: stp             fp, lr, [SP, #-0x10]!
    //     0xa49f44: mov             fp, SP
    // 0xa49f48: ldr             x0, [fp, #0x10]
    // 0xa49f4c: LoadField: r1 = r0->field_17
    //     0xa49f4c: ldur            w1, [x0, #0x17]
    // 0xa49f50: DecompressPointer r1
    //     0xa49f50: add             x1, x1, HEAP, lsl #32
    // 0xa49f54: CheckStackOverflow
    //     0xa49f54: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa49f58: cmp             SP, x16
    //     0xa49f5c: b.ls            #0xa49f80
    // 0xa49f60: LoadField: r0 = r1->field_f
    //     0xa49f60: ldur            w0, [x1, #0xf]
    // 0xa49f64: DecompressPointer r0
    //     0xa49f64: add             x0, x0, HEAP, lsl #32
    // 0xa49f68: SaveReg r0
    //     0xa49f68: str             x0, [SP, #-8]!
    // 0xa49f6c: r0 = dispose()
    //     0xa49f6c: bl              #0xa4e608  ; [package:badges/src/badge.dart] BadgeState::dispose
    // 0xa49f70: add             SP, SP, #8
    // 0xa49f74: LeaveFrame
    //     0xa49f74: mov             SP, fp
    //     0xa49f78: ldp             fp, lr, [SP], #0x10
    // 0xa49f7c: ret
    //     0xa49f7c: ret             
    // 0xa49f80: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa49f80: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa49f84: b               #0xa49f60
  }
  _ dispose(/* No info */) {
    // ** addr: 0xa4e608, size: 0x9c
    // 0xa4e608: EnterFrame
    //     0xa4e608: stp             fp, lr, [SP, #-0x10]!
    //     0xa4e60c: mov             fp, SP
    // 0xa4e610: CheckStackOverflow
    //     0xa4e610: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa4e614: cmp             SP, x16
    //     0xa4e618: b.ls            #0xa4e684
    // 0xa4e61c: ldr             x0, [fp, #0x10]
    // 0xa4e620: LoadField: r1 = r0->field_1b
    //     0xa4e620: ldur            w1, [x0, #0x1b]
    // 0xa4e624: DecompressPointer r1
    //     0xa4e624: add             x1, x1, HEAP, lsl #32
    // 0xa4e628: r16 = Sentinel
    //     0xa4e628: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4e62c: cmp             w1, w16
    // 0xa4e630: b.eq            #0xa4e68c
    // 0xa4e634: SaveReg r1
    //     0xa4e634: str             x1, [SP, #-8]!
    // 0xa4e638: r0 = dispose()
    //     0xa4e638: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa4e63c: add             SP, SP, #8
    // 0xa4e640: ldr             x0, [fp, #0x10]
    // 0xa4e644: LoadField: r1 = r0->field_1f
    //     0xa4e644: ldur            w1, [x0, #0x1f]
    // 0xa4e648: DecompressPointer r1
    //     0xa4e648: add             x1, x1, HEAP, lsl #32
    // 0xa4e64c: r16 = Sentinel
    //     0xa4e64c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa4e650: cmp             w1, w16
    // 0xa4e654: b.eq            #0xa4e698
    // 0xa4e658: SaveReg r1
    //     0xa4e658: str             x1, [SP, #-8]!
    // 0xa4e65c: r0 = dispose()
    //     0xa4e65c: bl              #0x7013ac  ; [package:flutter/src/animation/animation_controller.dart] AnimationController::dispose
    // 0xa4e660: add             SP, SP, #8
    // 0xa4e664: ldr             x16, [fp, #0x10]
    // 0xa4e668: SaveReg r16
    //     0xa4e668: str             x16, [SP, #-8]!
    // 0xa4e66c: r0 = dispose()
    //     0xa4e66c: bl              #0xa4e6a4  ; [package:badges/src/badge.dart] _BadgeState&State&TickerProviderStateMixin::dispose
    // 0xa4e670: add             SP, SP, #8
    // 0xa4e674: r0 = Null
    //     0xa4e674: mov             x0, NULL
    // 0xa4e678: LeaveFrame
    //     0xa4e678: mov             SP, fp
    //     0xa4e67c: ldp             fp, lr, [SP], #0x10
    // 0xa4e680: ret
    //     0xa4e680: ret             
    // 0xa4e684: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa4e684: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa4e688: b               #0xa4e61c
    // 0xa4e68c: r9 = _animationController
    //     0xa4e68c: add             x9, PP, #0x41, lsl #12  ; [pp+0x41410] Field <BadgeState._animationController@143004262>: late (offset: 0x1c)
    //     0xa4e690: ldr             x9, [x9, #0x410]
    // 0xa4e694: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4e694: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0xa4e698: r9 = _appearanceController
    //     0xa4e698: add             x9, PP, #0x41, lsl #12  ; [pp+0x41418] Field <BadgeState._appearanceController@143004262>: late (offset: 0x20)
    //     0xa4e69c: ldr             x9, [x9, #0x418]
    // 0xa4e6a0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0xa4e6a0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

// class id: 4227, size: 0x30, field offset: 0xc
//   const constructor, 
class Badge extends StatefulWidget {

  _ createState(/* No info */) {
    // ** addr: 0xa3ef30, size: 0x38
    // 0xa3ef30: EnterFrame
    //     0xa3ef30: stp             fp, lr, [SP, #-0x10]!
    //     0xa3ef34: mov             fp, SP
    // 0xa3ef38: r1 = <Badge>
    //     0xa3ef38: add             x1, PP, #0x38, lsl #12  ; [pp+0x38788] TypeArguments: <Badge>
    //     0xa3ef3c: ldr             x1, [x1, #0x788]
    // 0xa3ef40: r0 = BadgeState()
    //     0xa3ef40: bl              #0xa3ef68  ; AllocateBadgeStateStub -> BadgeState (size=0x2c)
    // 0xa3ef44: r1 = Sentinel
    //     0xa3ef44: ldr             x1, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0xa3ef48: StoreField: r0->field_1b = r1
    //     0xa3ef48: stur            w1, [x0, #0x1b]
    // 0xa3ef4c: StoreField: r0->field_1f = r1
    //     0xa3ef4c: stur            w1, [x0, #0x1f]
    // 0xa3ef50: StoreField: r0->field_23 = r1
    //     0xa3ef50: stur            w1, [x0, #0x23]
    // 0xa3ef54: r1 = false
    //     0xa3ef54: add             x1, NULL, #0x30  ; false
    // 0xa3ef58: StoreField: r0->field_27 = r1
    //     0xa3ef58: stur            w1, [x0, #0x27]
    // 0xa3ef5c: LeaveFrame
    //     0xa3ef5c: mov             SP, fp
    //     0xa3ef60: ldp             fp, lr, [SP], #0x10
    // 0xa3ef64: ret
    //     0xa3ef64: ret             
  }
}

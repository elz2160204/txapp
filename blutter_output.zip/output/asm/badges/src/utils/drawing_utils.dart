// lib: , url: package:badges/src/utils/drawing_utils.dart

// class id: 1048698, size: 0x8
class :: {
}

// class id: 4972, size: 0x8, field offset: 0x8
abstract class DrawingUtils extends Object {

  static _ drawBadgeShape(/* No info */) {
    // ** addr: 0x822c48, size: 0x98
    // 0x822c48: EnterFrame
    //     0x822c48: stp             fp, lr, [SP, #-0x10]!
    //     0x822c4c: mov             fp, SP
    // 0x822c50: ldr             x0, [fp, #0x10]
    // 0x822c54: LoadField: r1 = r0->field_7
    //     0x822c54: ldur            x1, [x0, #7]
    // 0x822c58: cmp             x1, #1
    // 0x822c5c: b.gt            #0x822c70
    // 0x822c60: r0 = Null
    //     0x822c60: mov             x0, NULL
    // 0x822c64: LeaveFrame
    //     0x822c64: mov             SP, fp
    //     0x822c68: ldp             fp, lr, [SP], #0x10
    // 0x822c6c: ret
    //     0x822c6c: ret             
    // 0x822c70: cmp             x1, #2
    // 0x822c74: b.gt            #0x822ca8
    // 0x822c78: r0 = TwitterBadgeShapePainter()
    //     0x822c78: bl              #0x822cec  ; AllocateTwitterBadgeShapePainterStub -> TwitterBadgeShapePainter (size=0x1c)
    // 0x822c7c: mov             x1, x0
    // 0x822c80: r0 = Instance_MaterialColor
    //     0x822c80: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x822c84: ldr             x0, [x0, #0xf60]
    // 0x822c88: StoreField: r1->field_b = r0
    //     0x822c88: stur            w0, [x1, #0xb]
    // 0x822c8c: r2 = Instance_BorderSide
    //     0x822c8c: add             x2, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x822c90: ldr             x2, [x2, #0x2f0]
    // 0x822c94: StoreField: r1->field_17 = r2
    //     0x822c94: stur            w2, [x1, #0x17]
    // 0x822c98: mov             x0, x1
    // 0x822c9c: LeaveFrame
    //     0x822c9c: mov             SP, fp
    //     0x822ca0: ldp             fp, lr, [SP], #0x10
    // 0x822ca4: ret
    //     0x822ca4: ret             
    // 0x822ca8: r0 = Instance_MaterialColor
    //     0x822ca8: add             x0, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x822cac: ldr             x0, [x0, #0xf60]
    // 0x822cb0: r2 = Instance_BorderSide
    //     0x822cb0: add             x2, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x822cb4: ldr             x2, [x2, #0x2f0]
    // 0x822cb8: r0 = InstagramBadgeShapePainter()
    //     0x822cb8: bl              #0x822ce0  ; AllocateInstagramBadgeShapePainterStub -> InstagramBadgeShapePainter (size=0x1c)
    // 0x822cbc: r1 = Instance_MaterialColor
    //     0x822cbc: add             x1, PP, #0x2b, lsl #12  ; [pp+0x2bf60] Obj!MaterialColor<int>@b5e3b1
    //     0x822cc0: ldr             x1, [x1, #0xf60]
    // 0x822cc4: StoreField: r0->field_b = r1
    //     0x822cc4: stur            w1, [x0, #0xb]
    // 0x822cc8: r1 = Instance_BorderSide
    //     0x822cc8: add             x1, PP, #0x15, lsl #12  ; [pp+0x152f0] Obj!BorderSide@b48451
    //     0x822ccc: ldr             x1, [x1, #0x2f0]
    // 0x822cd0: StoreField: r0->field_17 = r1
    //     0x822cd0: stur            w1, [x0, #0x17]
    // 0x822cd4: LeaveFrame
    //     0x822cd4: mov             SP, fp
    //     0x822cd8: ldp             fp, lr, [SP], #0x10
    // 0x822cdc: ret
    //     0x822cdc: ret             
  }
}

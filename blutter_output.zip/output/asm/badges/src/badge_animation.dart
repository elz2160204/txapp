// lib: , url: package:badges/src/badge_animation.dart

// class id: 1048686, size: 0x8
class :: {
}

// class id: 4977, size: 0x10, field offset: 0x8
//   const constructor, 
class SlideTween extends Object {

  Offset field_8;
  Offset field_c;

  _ toTween(/* No info */) {
    // ** addr: 0x82233c, size: 0x34
    // 0x82233c: EnterFrame
    //     0x82233c: stp             fp, lr, [SP, #-0x10]!
    //     0x822340: mov             fp, SP
    // 0x822344: r1 = <Offset>
    //     0x822344: add             x1, PP, #0x20, lsl #12  ; [pp+0x207f8] TypeArguments: <Offset>
    //     0x822348: ldr             x1, [x1, #0x7f8]
    // 0x82234c: r0 = Tween()
    //     0x82234c: bl              #0x5a14e8  ; AllocateTweenStub -> Tween<X0> (size=0x14)
    // 0x822350: r1 = Instance_Offset
    //     0x822350: add             x1, PP, #0x41, lsl #12  ; [pp+0x41478] Obj!Offset@b5f031
    //     0x822354: ldr             x1, [x1, #0x478]
    // 0x822358: StoreField: r0->field_b = r1
    //     0x822358: stur            w1, [x0, #0xb]
    // 0x82235c: r1 = Instance_Offset
    //     0x82235c: ldr             x1, [PP, #0x3ad0]  ; [pp+0x3ad0] Obj!Offset@b5ef31
    // 0x822360: StoreField: r0->field_f = r1
    //     0x822360: stur            w1, [x0, #0xf]
    // 0x822364: LeaveFrame
    //     0x822364: mov             SP, fp
    //     0x822368: ldp             fp, lr, [SP], #0x10
    // 0x82236c: ret
    //     0x82236c: ret             
  }
}

// class id: 4978, size: 0x38, field offset: 0x8
//   const constructor, 
class BadgeAnimation extends Object {

  bool field_8;
  Duration field_c;
  Duration field_10;
  BadgeAnimationType field_14;
  bool field_18;
  ElasticOutCurve<double> field_1c;
  SlideTween field_28;
  _Linear<double> field_2c;
  Duration field_30;
  bool field_34;
}

// lib: , url: package:badges/src/badge_shape.dart

// class id: 1048693, size: 0x8
class :: {
}

// class id: 6024, size: 0x14, field offset: 0x14
enum BadgeShape extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb14f40, size: 0x5c
    // 0xb14f40: EnterFrame
    //     0xb14f40: stp             fp, lr, [SP, #-0x10]!
    //     0xb14f44: mov             fp, SP
    // 0xb14f48: CheckStackOverflow
    //     0xb14f48: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb14f4c: cmp             SP, x16
    //     0xb14f50: b.ls            #0xb14f94
    // 0xb14f54: r1 = Null
    //     0xb14f54: mov             x1, NULL
    // 0xb14f58: r2 = 4
    //     0xb14f58: mov             x2, #4
    // 0xb14f5c: r0 = AllocateArray()
    //     0xb14f5c: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb14f60: r17 = "BadgeShape."
    //     0xb14f60: add             x17, PP, #0x38, lsl #12  ; [pp+0x38778] "BadgeShape."
    //     0xb14f64: ldr             x17, [x17, #0x778]
    // 0xb14f68: StoreField: r0->field_f = r17
    //     0xb14f68: stur            w17, [x0, #0xf]
    // 0xb14f6c: ldr             x1, [fp, #0x10]
    // 0xb14f70: LoadField: r2 = r1->field_f
    //     0xb14f70: ldur            w2, [x1, #0xf]
    // 0xb14f74: DecompressPointer r2
    //     0xb14f74: add             x2, x2, HEAP, lsl #32
    // 0xb14f78: StoreField: r0->field_13 = r2
    //     0xb14f78: stur            w2, [x0, #0x13]
    // 0xb14f7c: SaveReg r0
    //     0xb14f7c: str             x0, [SP, #-8]!
    // 0xb14f80: r0 = _interpolate()
    //     0xb14f80: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb14f84: add             SP, SP, #8
    // 0xb14f88: LeaveFrame
    //     0xb14f88: mov             SP, fp
    //     0xb14f8c: ldp             fp, lr, [SP], #0x10
    // 0xb14f90: ret
    //     0xb14f90: ret             
    // 0xb14f94: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb14f94: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb14f98: b               #0xb14f54
  }
}

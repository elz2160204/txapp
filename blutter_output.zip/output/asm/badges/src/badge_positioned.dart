// lib: , url: package:badges/src/badge_positioned.dart

// class id: 1048692, size: 0x8
class :: {
}

// class id: 3886, size: 0x14, field offset: 0xc
//   const constructor, 
class BadgePositioned extends StatelessWidget {

  _ build(/* No info */) {
    // ** addr: 0xb1b96c, size: 0x8c
    // 0xb1b96c: EnterFrame
    //     0xb1b96c: stp             fp, lr, [SP, #-0x10]!
    //     0xb1b970: mov             fp, SP
    // 0xb1b974: AllocStack(0x28)
    //     0xb1b974: sub             SP, SP, #0x28
    // 0xb1b978: ldr             x0, [fp, #0x18]
    // 0xb1b97c: LoadField: r1 = r0->field_b
    //     0xb1b97c: ldur            w1, [x0, #0xb]
    // 0xb1b980: DecompressPointer r1
    //     0xb1b980: add             x1, x1, HEAP, lsl #32
    // 0xb1b984: LoadField: r2 = r1->field_7
    //     0xb1b984: ldur            w2, [x1, #7]
    // 0xb1b988: DecompressPointer r2
    //     0xb1b988: add             x2, x2, HEAP, lsl #32
    // 0xb1b98c: stur            x2, [fp, #-0x28]
    // 0xb1b990: LoadField: r3 = r1->field_b
    //     0xb1b990: ldur            w3, [x1, #0xb]
    // 0xb1b994: DecompressPointer r3
    //     0xb1b994: add             x3, x3, HEAP, lsl #32
    // 0xb1b998: stur            x3, [fp, #-0x20]
    // 0xb1b99c: LoadField: r4 = r1->field_13
    //     0xb1b99c: ldur            w4, [x1, #0x13]
    // 0xb1b9a0: DecompressPointer r4
    //     0xb1b9a0: add             x4, x4, HEAP, lsl #32
    // 0xb1b9a4: stur            x4, [fp, #-0x18]
    // 0xb1b9a8: LoadField: r5 = r1->field_f
    //     0xb1b9a8: ldur            w5, [x1, #0xf]
    // 0xb1b9ac: DecompressPointer r5
    //     0xb1b9ac: add             x5, x5, HEAP, lsl #32
    // 0xb1b9b0: stur            x5, [fp, #-0x10]
    // 0xb1b9b4: LoadField: r1 = r0->field_f
    //     0xb1b9b4: ldur            w1, [x0, #0xf]
    // 0xb1b9b8: DecompressPointer r1
    //     0xb1b9b8: add             x1, x1, HEAP, lsl #32
    // 0xb1b9bc: stur            x1, [fp, #-8]
    // 0xb1b9c0: r0 = PositionedDirectional()
    //     0xb1b9c0: bl              #0x841488  ; AllocatePositionedDirectionalStub -> PositionedDirectional (size=0x28)
    // 0xb1b9c4: ldur            x1, [fp, #-0x10]
    // 0xb1b9c8: StoreField: r0->field_b = r1
    //     0xb1b9c8: stur            w1, [x0, #0xb]
    // 0xb1b9cc: ldur            x1, [fp, #-0x28]
    // 0xb1b9d0: StoreField: r0->field_f = r1
    //     0xb1b9d0: stur            w1, [x0, #0xf]
    // 0xb1b9d4: ldur            x1, [fp, #-0x20]
    // 0xb1b9d8: StoreField: r0->field_13 = r1
    //     0xb1b9d8: stur            w1, [x0, #0x13]
    // 0xb1b9dc: ldur            x1, [fp, #-0x18]
    // 0xb1b9e0: StoreField: r0->field_17 = r1
    //     0xb1b9e0: stur            w1, [x0, #0x17]
    // 0xb1b9e4: ldur            x1, [fp, #-8]
    // 0xb1b9e8: StoreField: r0->field_23 = r1
    //     0xb1b9e8: stur            w1, [x0, #0x23]
    // 0xb1b9ec: LeaveFrame
    //     0xb1b9ec: mov             SP, fp
    //     0xb1b9f0: ldp             fp, lr, [SP], #0x10
    // 0xb1b9f4: ret
    //     0xb1b9f4: ret             
  }
}

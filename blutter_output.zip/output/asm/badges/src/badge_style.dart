// lib: , url: package:badges/src/badge_style.dart

// class id: 1048694, size: 0x8
class :: {
}

// class id: 4974, size: 0x2c, field offset: 0x8
//   const constructor, 
class BadgeStyle extends Object {
}

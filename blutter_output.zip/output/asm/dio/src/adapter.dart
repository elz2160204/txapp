// lib: , url: package:dio/src/adapter.dart

// class id: 1048879, size: 0x8
class :: {
}

// class id: 4552, size: 0x28, field offset: 0x8
class ResponseBody extends Object {

  _ ResponseBody(/* No info */) {
    // ** addr: 0x52fa90, size: 0xf4
    // 0x52fa90: EnterFrame
    //     0x52fa90: stp             fp, lr, [SP, #-0x10]!
    //     0x52fa94: mov             fp, SP
    // 0x52fa98: CheckStackOverflow
    //     0x52fa98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52fa9c: cmp             SP, x16
    //     0x52faa0: b.ls            #0x52fb7c
    // 0x52faa4: r16 = <String, dynamic>
    //     0x52faa4: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x52faa8: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x52faac: stp             lr, x16, [SP, #-0x10]!
    // 0x52fab0: r0 = Map._fromLiteral()
    //     0x52fab0: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x52fab4: add             SP, SP, #0x10
    // 0x52fab8: ldr             x1, [fp, #0x40]
    // 0x52fabc: StoreField: r1->field_23 = r0
    //     0x52fabc: stur            w0, [x1, #0x23]
    //     0x52fac0: tbz             w0, #0, #0x52fadc
    //     0x52fac4: ldurb           w16, [x1, #-1]
    //     0x52fac8: ldurb           w17, [x0, #-1]
    //     0x52facc: and             x16, x17, x16, lsr #2
    //     0x52fad0: tst             x16, HEAP, lsr #32
    //     0x52fad4: b.eq            #0x52fadc
    //     0x52fad8: bl              #0xd6826c
    // 0x52fadc: ldr             x0, [fp, #0x38]
    // 0x52fae0: StoreField: r1->field_7 = r0
    //     0x52fae0: stur            w0, [x1, #7]
    //     0x52fae4: ldurb           w16, [x1, #-1]
    //     0x52fae8: ldurb           w17, [x0, #-1]
    //     0x52faec: and             x16, x17, x16, lsr #2
    //     0x52faf0: tst             x16, HEAP, lsr #32
    //     0x52faf4: b.eq            #0x52fafc
    //     0x52faf8: bl              #0xd6826c
    // 0x52fafc: ldr             x2, [fp, #0x30]
    // 0x52fb00: StoreField: r1->field_f = r2
    //     0x52fb00: stur            x2, [x1, #0xf]
    // 0x52fb04: ldr             x0, [fp, #0x28]
    // 0x52fb08: StoreField: r1->field_b = r0
    //     0x52fb08: stur            w0, [x1, #0xb]
    //     0x52fb0c: ldurb           w16, [x1, #-1]
    //     0x52fb10: ldurb           w17, [x0, #-1]
    //     0x52fb14: and             x16, x17, x16, lsr #2
    //     0x52fb18: tst             x16, HEAP, lsr #32
    //     0x52fb1c: b.eq            #0x52fb24
    //     0x52fb20: bl              #0xd6826c
    // 0x52fb24: ldr             x0, [fp, #0x10]
    // 0x52fb28: StoreField: r1->field_17 = r0
    //     0x52fb28: stur            w0, [x1, #0x17]
    //     0x52fb2c: ldurb           w16, [x1, #-1]
    //     0x52fb30: ldurb           w17, [x0, #-1]
    //     0x52fb34: and             x16, x17, x16, lsr #2
    //     0x52fb38: tst             x16, HEAP, lsr #32
    //     0x52fb3c: b.eq            #0x52fb44
    //     0x52fb40: bl              #0xd6826c
    // 0x52fb44: ldr             x2, [fp, #0x20]
    // 0x52fb48: StoreField: r1->field_1b = r2
    //     0x52fb48: stur            w2, [x1, #0x1b]
    // 0x52fb4c: ldr             x0, [fp, #0x18]
    // 0x52fb50: StoreField: r1->field_1f = r0
    //     0x52fb50: stur            w0, [x1, #0x1f]
    //     0x52fb54: ldurb           w16, [x1, #-1]
    //     0x52fb58: ldurb           w17, [x0, #-1]
    //     0x52fb5c: and             x16, x17, x16, lsr #2
    //     0x52fb60: tst             x16, HEAP, lsr #32
    //     0x52fb64: b.eq            #0x52fb6c
    //     0x52fb68: bl              #0xd6826c
    // 0x52fb6c: r0 = Null
    //     0x52fb6c: mov             x0, NULL
    // 0x52fb70: LeaveFrame
    //     0x52fb70: mov             SP, fp
    //     0x52fb74: ldp             fp, lr, [SP], #0x10
    // 0x52fb78: ret
    //     0x52fb78: ret             
    // 0x52fb7c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52fb7c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52fb80: b               #0x52faa4
  }
}

// class id: 4553, size: 0x8, field offset: 0x8
abstract class HttpClientAdapter extends Object {
}

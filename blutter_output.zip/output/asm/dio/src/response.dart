// lib: , url: package:dio/src/response.dart

// class id: 1048898, size: 0x8
class :: {
}

// class id: 4526, size: 0x2c, field offset: 0x8
class Response<X0> extends Object {

  _ Response(/* No info */) {
    // ** addr: 0x52a1d8, size: 0x3d0
    // 0x52a1d8: EnterFrame
    //     0x52a1d8: stp             fp, lr, [SP, #-0x10]!
    //     0x52a1dc: mov             fp, SP
    // 0x52a1e0: AllocStack(0x10)
    //     0x52a1e0: sub             SP, SP, #0x10
    // 0x52a1e4: SetupParameters(Response<X0> this /* r3, fp-0x8 */, dynamic _ /* r4 */, {dynamic data = Null /* r5 */, dynamic extra = _ConstMap len:0 /* r6 */, dynamic headers = Null /* r7 */, dynamic isRedirect = false /* r8 */, dynamic redirects = const [] /* r9 */, dynamic statusCode = Null /* r10 */, dynamic statusMessage = Null /* r1 */})
    //     0x52a1e4: mov             x0, x4
    //     0x52a1e8: ldur            w1, [x0, #0x13]
    //     0x52a1ec: add             x1, x1, HEAP, lsl #32
    //     0x52a1f0: sub             x2, x1, #4
    //     0x52a1f4: add             x3, fp, w2, sxtw #2
    //     0x52a1f8: ldr             x3, [x3, #0x18]
    //     0x52a1fc: stur            x3, [fp, #-8]
    //     0x52a200: add             x4, fp, w2, sxtw #2
    //     0x52a204: ldr             x4, [x4, #0x10]
    //     0x52a208: ldur            w2, [x0, #0x1f]
    //     0x52a20c: add             x2, x2, HEAP, lsl #32
    //     0x52a210: ldr             x16, [PP, #0x1590]  ; [pp+0x1590] "data"
    //     0x52a214: cmp             w2, w16
    //     0x52a218: b.ne            #0x52a23c
    //     0x52a21c: ldur            w2, [x0, #0x23]
    //     0x52a220: add             x2, x2, HEAP, lsl #32
    //     0x52a224: sub             w5, w1, w2
    //     0x52a228: add             x2, fp, w5, sxtw #2
    //     0x52a22c: ldr             x2, [x2, #8]
    //     0x52a230: mov             x5, x2
    //     0x52a234: mov             x2, #1
    //     0x52a238: b               #0x52a244
    //     0x52a23c: mov             x5, NULL
    //     0x52a240: mov             x2, #0
    //     0x52a244: lsl             x6, x2, #1
    //     0x52a248: lsl             w7, w6, #1
    //     0x52a24c: add             w8, w7, #8
    //     0x52a250: add             x16, x0, w8, sxtw #1
    //     0x52a254: ldur            w9, [x16, #0xf]
    //     0x52a258: add             x9, x9, HEAP, lsl #32
    //     0x52a25c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13088] "extra"
    //     0x52a260: ldr             x16, [x16, #0x88]
    //     0x52a264: cmp             w9, w16
    //     0x52a268: b.ne            #0x52a29c
    //     0x52a26c: add             w2, w7, #0xa
    //     0x52a270: add             x16, x0, w2, sxtw #1
    //     0x52a274: ldur            w7, [x16, #0xf]
    //     0x52a278: add             x7, x7, HEAP, lsl #32
    //     0x52a27c: sub             w2, w1, w7
    //     0x52a280: add             x7, fp, w2, sxtw #2
    //     0x52a284: ldr             x7, [x7, #8]
    //     0x52a288: add             w2, w6, #2
    //     0x52a28c: sbfx            x6, x2, #1, #0x1f
    //     0x52a290: mov             x2, x6
    //     0x52a294: mov             x6, x7
    //     0x52a298: b               #0x52a2a4
    //     0x52a29c: add             x6, PP, #0x13, lsl #12  ; [pp+0x13090] Map<String, dynamic>(0)
    //     0x52a2a0: ldr             x6, [x6, #0x90]
    //     0x52a2a4: lsl             x7, x2, #1
    //     0x52a2a8: lsl             w8, w7, #1
    //     0x52a2ac: add             w9, w8, #8
    //     0x52a2b0: add             x16, x0, w9, sxtw #1
    //     0x52a2b4: ldur            w10, [x16, #0xf]
    //     0x52a2b8: add             x10, x10, HEAP, lsl #32
    //     0x52a2bc: add             x16, PP, #0x13, lsl #12  ; [pp+0x13098] "headers"
    //     0x52a2c0: ldr             x16, [x16, #0x98]
    //     0x52a2c4: cmp             w10, w16
    //     0x52a2c8: b.ne            #0x52a2fc
    //     0x52a2cc: add             w2, w8, #0xa
    //     0x52a2d0: add             x16, x0, w2, sxtw #1
    //     0x52a2d4: ldur            w8, [x16, #0xf]
    //     0x52a2d8: add             x8, x8, HEAP, lsl #32
    //     0x52a2dc: sub             w2, w1, w8
    //     0x52a2e0: add             x8, fp, w2, sxtw #2
    //     0x52a2e4: ldr             x8, [x8, #8]
    //     0x52a2e8: add             w2, w7, #2
    //     0x52a2ec: sbfx            x7, x2, #1, #0x1f
    //     0x52a2f0: mov             x2, x7
    //     0x52a2f4: mov             x7, x8
    //     0x52a2f8: b               #0x52a300
    //     0x52a2fc: mov             x7, NULL
    //     0x52a300: lsl             x8, x2, #1
    //     0x52a304: lsl             w9, w8, #1
    //     0x52a308: add             w10, w9, #8
    //     0x52a30c: add             x16, x0, w10, sxtw #1
    //     0x52a310: ldur            w11, [x16, #0xf]
    //     0x52a314: add             x11, x11, HEAP, lsl #32
    //     0x52a318: add             x16, PP, #0x13, lsl #12  ; [pp+0x130a0] "isRedirect"
    //     0x52a31c: ldr             x16, [x16, #0xa0]
    //     0x52a320: cmp             w11, w16
    //     0x52a324: b.ne            #0x52a358
    //     0x52a328: add             w2, w9, #0xa
    //     0x52a32c: add             x16, x0, w2, sxtw #1
    //     0x52a330: ldur            w9, [x16, #0xf]
    //     0x52a334: add             x9, x9, HEAP, lsl #32
    //     0x52a338: sub             w2, w1, w9
    //     0x52a33c: add             x9, fp, w2, sxtw #2
    //     0x52a340: ldr             x9, [x9, #8]
    //     0x52a344: add             w2, w8, #2
    //     0x52a348: sbfx            x8, x2, #1, #0x1f
    //     0x52a34c: mov             x2, x8
    //     0x52a350: mov             x8, x9
    //     0x52a354: b               #0x52a35c
    //     0x52a358: add             x8, NULL, #0x30  ; false
    //     0x52a35c: lsl             x9, x2, #1
    //     0x52a360: lsl             w10, w9, #1
    //     0x52a364: add             w11, w10, #8
    //     0x52a368: add             x16, x0, w11, sxtw #1
    //     0x52a36c: ldur            w12, [x16, #0xf]
    //     0x52a370: add             x12, x12, HEAP, lsl #32
    //     0x52a374: add             x16, PP, #0x13, lsl #12  ; [pp+0x130a8] "redirects"
    //     0x52a378: ldr             x16, [x16, #0xa8]
    //     0x52a37c: cmp             w12, w16
    //     0x52a380: b.ne            #0x52a3b4
    //     0x52a384: add             w2, w10, #0xa
    //     0x52a388: add             x16, x0, w2, sxtw #1
    //     0x52a38c: ldur            w10, [x16, #0xf]
    //     0x52a390: add             x10, x10, HEAP, lsl #32
    //     0x52a394: sub             w2, w1, w10
    //     0x52a398: add             x10, fp, w2, sxtw #2
    //     0x52a39c: ldr             x10, [x10, #8]
    //     0x52a3a0: add             w2, w9, #2
    //     0x52a3a4: sbfx            x9, x2, #1, #0x1f
    //     0x52a3a8: mov             x2, x9
    //     0x52a3ac: mov             x9, x10
    //     0x52a3b0: b               #0x52a3bc
    //     0x52a3b4: add             x9, PP, #0x13, lsl #12  ; [pp+0x130b0] List<RedirectRecord>(0)
    //     0x52a3b8: ldr             x9, [x9, #0xb0]
    //     0x52a3bc: lsl             x10, x2, #1
    //     0x52a3c0: lsl             w11, w10, #1
    //     0x52a3c4: add             w12, w11, #8
    //     0x52a3c8: add             x16, x0, w12, sxtw #1
    //     0x52a3cc: ldur            w13, [x16, #0xf]
    //     0x52a3d0: add             x13, x13, HEAP, lsl #32
    //     0x52a3d4: add             x16, PP, #0x13, lsl #12  ; [pp+0x130b8] "statusCode"
    //     0x52a3d8: ldr             x16, [x16, #0xb8]
    //     0x52a3dc: cmp             w13, w16
    //     0x52a3e0: b.ne            #0x52a414
    //     0x52a3e4: add             w2, w11, #0xa
    //     0x52a3e8: add             x16, x0, w2, sxtw #1
    //     0x52a3ec: ldur            w11, [x16, #0xf]
    //     0x52a3f0: add             x11, x11, HEAP, lsl #32
    //     0x52a3f4: sub             w2, w1, w11
    //     0x52a3f8: add             x11, fp, w2, sxtw #2
    //     0x52a3fc: ldr             x11, [x11, #8]
    //     0x52a400: add             w2, w10, #2
    //     0x52a404: sbfx            x10, x2, #1, #0x1f
    //     0x52a408: mov             x2, x10
    //     0x52a40c: mov             x10, x11
    //     0x52a410: b               #0x52a418
    //     0x52a414: mov             x10, NULL
    //     0x52a418: lsl             x11, x2, #1
    //     0x52a41c: lsl             w2, w11, #1
    //     0x52a420: add             w11, w2, #8
    //     0x52a424: add             x16, x0, w11, sxtw #1
    //     0x52a428: ldur            w12, [x16, #0xf]
    //     0x52a42c: add             x12, x12, HEAP, lsl #32
    //     0x52a430: add             x16, PP, #0x13, lsl #12  ; [pp+0x130c0] "statusMessage"
    //     0x52a434: ldr             x16, [x16, #0xc0]
    //     0x52a438: cmp             w12, w16
    //     0x52a43c: b.ne            #0x52a460
    //     0x52a440: add             w11, w2, #0xa
    //     0x52a444: add             x16, x0, w11, sxtw #1
    //     0x52a448: ldur            w2, [x16, #0xf]
    //     0x52a44c: add             x2, x2, HEAP, lsl #32
    //     0x52a450: sub             w0, w1, w2
    //     0x52a454: add             x1, fp, w0, sxtw #2
    //     0x52a458: ldr             x1, [x1, #8]
    //     0x52a45c: b               #0x52a464
    //     0x52a460: mov             x1, NULL
    // 0x52a464: CheckStackOverflow
    //     0x52a464: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a468: cmp             SP, x16
    //     0x52a46c: b.ls            #0x52a5a0
    // 0x52a470: mov             x0, x5
    // 0x52a474: StoreField: r3->field_b = r0
    //     0x52a474: stur            w0, [x3, #0xb]
    //     0x52a478: tbz             w0, #0, #0x52a494
    //     0x52a47c: ldurb           w16, [x3, #-1]
    //     0x52a480: ldurb           w17, [x0, #-1]
    //     0x52a484: and             x16, x17, x16, lsr #2
    //     0x52a488: tst             x16, HEAP, lsr #32
    //     0x52a48c: b.eq            #0x52a494
    //     0x52a490: bl              #0xd682ac
    // 0x52a494: mov             x0, x4
    // 0x52a498: StoreField: r3->field_f = r0
    //     0x52a498: stur            w0, [x3, #0xf]
    //     0x52a49c: ldurb           w16, [x3, #-1]
    //     0x52a4a0: ldurb           w17, [x0, #-1]
    //     0x52a4a4: and             x16, x17, x16, lsr #2
    //     0x52a4a8: tst             x16, HEAP, lsr #32
    //     0x52a4ac: b.eq            #0x52a4b4
    //     0x52a4b0: bl              #0xd682ac
    // 0x52a4b4: mov             x0, x10
    // 0x52a4b8: StoreField: r3->field_13 = r0
    //     0x52a4b8: stur            w0, [x3, #0x13]
    //     0x52a4bc: tbz             w0, #0, #0x52a4d8
    //     0x52a4c0: ldurb           w16, [x3, #-1]
    //     0x52a4c4: ldurb           w17, [x0, #-1]
    //     0x52a4c8: and             x16, x17, x16, lsr #2
    //     0x52a4cc: tst             x16, HEAP, lsr #32
    //     0x52a4d0: b.eq            #0x52a4d8
    //     0x52a4d4: bl              #0xd682ac
    // 0x52a4d8: mov             x0, x1
    // 0x52a4dc: StoreField: r3->field_17 = r0
    //     0x52a4dc: stur            w0, [x3, #0x17]
    //     0x52a4e0: ldurb           w16, [x3, #-1]
    //     0x52a4e4: ldurb           w17, [x0, #-1]
    //     0x52a4e8: and             x16, x17, x16, lsr #2
    //     0x52a4ec: tst             x16, HEAP, lsr #32
    //     0x52a4f0: b.eq            #0x52a4f8
    //     0x52a4f4: bl              #0xd682ac
    // 0x52a4f8: StoreField: r3->field_1b = r8
    //     0x52a4f8: stur            w8, [x3, #0x1b]
    // 0x52a4fc: mov             x0, x9
    // 0x52a500: StoreField: r3->field_1f = r0
    //     0x52a500: stur            w0, [x3, #0x1f]
    //     0x52a504: ldurb           w16, [x3, #-1]
    //     0x52a508: ldurb           w17, [x0, #-1]
    //     0x52a50c: and             x16, x17, x16, lsr #2
    //     0x52a510: tst             x16, HEAP, lsr #32
    //     0x52a514: b.eq            #0x52a51c
    //     0x52a518: bl              #0xd682ac
    // 0x52a51c: mov             x0, x6
    // 0x52a520: StoreField: r3->field_23 = r0
    //     0x52a520: stur            w0, [x3, #0x23]
    //     0x52a524: ldurb           w16, [x3, #-1]
    //     0x52a528: ldurb           w17, [x0, #-1]
    //     0x52a52c: and             x16, x17, x16, lsr #2
    //     0x52a530: tst             x16, HEAP, lsr #32
    //     0x52a534: b.eq            #0x52a53c
    //     0x52a538: bl              #0xd682ac
    // 0x52a53c: cmp             w7, NULL
    // 0x52a540: b.ne            #0x52a56c
    // 0x52a544: r16 = <List<String>>
    //     0x52a544: ldr             x16, [PP, #0x7f58]  ; [pp+0x7f58] TypeArguments: <List<String>>
    // 0x52a548: SaveReg r16
    //     0x52a548: str             x16, [SP, #-8]!
    // 0x52a54c: r4 = const [0x1, 0, 0, 0, null]
    //     0x52a54c: ldr             x4, [PP, #0x38]  ; [pp+0x38] List(5) [0x1, 0, 0, 0, Null]
    // 0x52a550: r0 = caseInsensitiveKeyMap()
    //     0x52a550: bl              #0x529878  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x52a554: add             SP, SP, #8
    // 0x52a558: stur            x0, [fp, #-0x10]
    // 0x52a55c: r0 = Headers()
    //     0x52a55c: bl              #0x52a1cc  ; AllocateHeadersStub -> Headers (size=0xc)
    // 0x52a560: ldur            x1, [fp, #-0x10]
    // 0x52a564: StoreField: r0->field_7 = r1
    //     0x52a564: stur            w1, [x0, #7]
    // 0x52a568: b               #0x52a570
    // 0x52a56c: mov             x0, x7
    // 0x52a570: ldur            x1, [fp, #-8]
    // 0x52a574: StoreField: r1->field_27 = r0
    //     0x52a574: stur            w0, [x1, #0x27]
    //     0x52a578: ldurb           w16, [x1, #-1]
    //     0x52a57c: ldurb           w17, [x0, #-1]
    //     0x52a580: and             x16, x17, x16, lsr #2
    //     0x52a584: tst             x16, HEAP, lsr #32
    //     0x52a588: b.eq            #0x52a590
    //     0x52a58c: bl              #0xd6826c
    // 0x52a590: r0 = Null
    //     0x52a590: mov             x0, NULL
    // 0x52a594: LeaveFrame
    //     0x52a594: mov             SP, fp
    //     0x52a598: ldp             fp, lr, [SP], #0x10
    // 0x52a59c: ret
    //     0x52a59c: ret             
    // 0x52a5a0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a5a0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a5a4: b               #0x52a470
  }
  get _ realUri(/* No info */) {
    // ** addr: 0x966b90, size: 0xb0
    // 0x966b90: EnterFrame
    //     0x966b90: stp             fp, lr, [SP, #-0x10]!
    //     0x966b94: mov             fp, SP
    // 0x966b98: CheckStackOverflow
    //     0x966b98: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966b9c: cmp             SP, x16
    //     0x966ba0: b.ls            #0x966c38
    // 0x966ba4: ldr             x1, [fp, #0x10]
    // 0x966ba8: LoadField: r0 = r1->field_1f
    //     0x966ba8: ldur            w0, [x1, #0x1f]
    // 0x966bac: DecompressPointer r0
    //     0x966bac: add             x0, x0, HEAP, lsl #32
    // 0x966bb0: r2 = LoadClassIdInstr(r0)
    //     0x966bb0: ldur            x2, [x0, #-1]
    //     0x966bb4: ubfx            x2, x2, #0xc, #0x14
    // 0x966bb8: SaveReg r0
    //     0x966bb8: str             x0, [SP, #-8]!
    // 0x966bbc: mov             x0, x2
    // 0x966bc0: r0 = GDT[cid_x0 + 0xcc6c]()
    //     0x966bc0: mov             x17, #0xcc6c
    //     0x966bc4: add             lr, x0, x17
    //     0x966bc8: ldr             lr, [x21, lr, lsl #3]
    //     0x966bcc: blr             lr
    // 0x966bd0: add             SP, SP, #8
    // 0x966bd4: tbnz            w0, #4, #0x966c14
    // 0x966bd8: ldr             x0, [fp, #0x10]
    // 0x966bdc: LoadField: r1 = r0->field_1f
    //     0x966bdc: ldur            w1, [x0, #0x1f]
    // 0x966be0: DecompressPointer r1
    //     0x966be0: add             x1, x1, HEAP, lsl #32
    // 0x966be4: r0 = LoadClassIdInstr(r1)
    //     0x966be4: ldur            x0, [x1, #-1]
    //     0x966be8: ubfx            x0, x0, #0xc, #0x14
    // 0x966bec: SaveReg r1
    //     0x966bec: str             x1, [SP, #-8]!
    // 0x966bf0: r0 = GDT[cid_x0 + 0xfe03]()
    //     0x966bf0: mov             x17, #0xfe03
    //     0x966bf4: add             lr, x0, x17
    //     0x966bf8: ldr             lr, [x21, lr, lsl #3]
    //     0x966bfc: blr             lr
    // 0x966c00: add             SP, SP, #8
    // 0x966c04: LoadField: r1 = r0->field_7
    //     0x966c04: ldur            w1, [x0, #7]
    // 0x966c08: DecompressPointer r1
    //     0x966c08: add             x1, x1, HEAP, lsl #32
    // 0x966c0c: mov             x0, x1
    // 0x966c10: b               #0x966c2c
    // 0x966c14: ldr             x0, [fp, #0x10]
    // 0x966c18: LoadField: r1 = r0->field_f
    //     0x966c18: ldur            w1, [x0, #0xf]
    // 0x966c1c: DecompressPointer r1
    //     0x966c1c: add             x1, x1, HEAP, lsl #32
    // 0x966c20: SaveReg r1
    //     0x966c20: str             x1, [SP, #-8]!
    // 0x966c24: r0 = uri()
    //     0x966c24: bl              #0x55382c  ; [package:dio/src/options.dart] RequestOptions::uri
    // 0x966c28: add             SP, SP, #8
    // 0x966c2c: LeaveFrame
    //     0x966c2c: mov             SP, fp
    //     0x966c30: ldp             fp, lr, [SP], #0x10
    // 0x966c34: ret
    //     0x966c34: ret             
    // 0x966c38: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x966c38: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x966c3c: b               #0x966ba4
  }
  _ toString(/* No info */) {
    // ** addr: 0xad386c, size: 0x14c
    // 0xad386c: EnterFrame
    //     0xad386c: stp             fp, lr, [SP, #-0x10]!
    //     0xad3870: mov             fp, SP
    // 0xad3874: AllocStack(0x8)
    //     0xad3874: sub             SP, SP, #8
    // 0xad3878: CheckStackOverflow
    //     0xad3878: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad387c: cmp             SP, x16
    //     0xad3880: b.ls            #0xad39b0
    // 0xad3884: ldr             x0, [fp, #0x10]
    // 0xad3888: LoadField: r3 = r0->field_b
    //     0xad3888: ldur            w3, [x0, #0xb]
    // 0xad388c: DecompressPointer r3
    //     0xad388c: add             x3, x3, HEAP, lsl #32
    // 0xad3890: mov             x0, x3
    // 0xad3894: stur            x3, [fp, #-8]
    // 0xad3898: r2 = Null
    //     0xad3898: mov             x2, NULL
    // 0xad389c: r1 = Null
    //     0xad389c: mov             x1, NULL
    // 0xad38a0: cmp             w0, NULL
    // 0xad38a4: b.eq            #0xad393c
    // 0xad38a8: branchIfSmi(r0, 0xad393c)
    //     0xad38a8: tbz             w0, #0, #0xad393c
    // 0xad38ac: r3 = LoadClassIdInstr(r0)
    //     0xad38ac: ldur            x3, [x0, #-1]
    //     0xad38b0: ubfx            x3, x3, #0xc, #0x14
    // 0xad38b4: r17 = 5696
    //     0xad38b4: mov             x17, #0x1640
    // 0xad38b8: cmp             x3, x17
    // 0xad38bc: b.eq            #0xad3944
    // 0xad38c0: r4 = LoadClassIdInstr(r0)
    //     0xad38c0: ldur            x4, [x0, #-1]
    //     0xad38c4: ubfx            x4, x4, #0xc, #0x14
    // 0xad38c8: ldr             x3, [THR, #0x7b8]  ; THR::isolate_group
    // 0xad38cc: ldr             x3, [x3, #0x18]
    // 0xad38d0: ldr             x3, [x3, x4, lsl #3]
    // 0xad38d4: LoadField: r3 = r3->field_2b
    //     0xad38d4: ldur            w3, [x3, #0x2b]
    // 0xad38d8: DecompressPointer r3
    //     0xad38d8: add             x3, x3, HEAP, lsl #32
    // 0xad38dc: cmp             w3, NULL
    // 0xad38e0: b.eq            #0xad393c
    // 0xad38e4: LoadField: r3 = r3->field_f
    //     0xad38e4: ldur            w3, [x3, #0xf]
    // 0xad38e8: lsr             x3, x3, #4
    // 0xad38ec: r17 = 5696
    //     0xad38ec: mov             x17, #0x1640
    // 0xad38f0: cmp             x3, x17
    // 0xad38f4: b.eq            #0xad3944
    // 0xad38f8: r3 = SubtypeTestCache
    //     0xad38f8: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d578] SubtypeTestCache
    //     0xad38fc: ldr             x3, [x3, #0x578]
    // 0xad3900: r24 = Subtype1TestCacheStub
    //     0xad3900: ldr             x24, [PP, #0x258]  ; [pp+0x258] Stub: Subtype1TestCache (0x4ae344)
    // 0xad3904: LoadField: r30 = r24->field_7
    //     0xad3904: ldur            lr, [x24, #7]
    // 0xad3908: blr             lr
    // 0xad390c: cmp             w7, NULL
    // 0xad3910: b.eq            #0xad391c
    // 0xad3914: tbnz            w7, #4, #0xad393c
    // 0xad3918: b               #0xad3944
    // 0xad391c: r8 = Map
    //     0xad391c: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d580] Type: Map
    //     0xad3920: ldr             x8, [x8, #0x580]
    // 0xad3924: r3 = SubtypeTestCache
    //     0xad3924: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d588] SubtypeTestCache
    //     0xad3928: ldr             x3, [x3, #0x588]
    // 0xad392c: r24 = InstanceOfStub
    //     0xad392c: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0xad3930: LoadField: r30 = r24->field_7
    //     0xad3930: ldur            lr, [x24, #7]
    // 0xad3934: blr             lr
    // 0xad3938: b               #0xad3948
    // 0xad393c: r0 = false
    //     0xad393c: add             x0, NULL, #0x30  ; false
    // 0xad3940: b               #0xad3948
    // 0xad3944: r0 = true
    //     0xad3944: add             x0, NULL, #0x20  ; true
    // 0xad3948: tbnz            w0, #4, #0xad3970
    // 0xad394c: r16 = Instance_JsonCodec
    //     0xad394c: ldr             x16, [PP, #0x20a8]  ; [pp+0x20a8] Obj!JsonCodec<Object?, String>@b5f661
    // 0xad3950: ldur            lr, [fp, #-8]
    // 0xad3954: stp             lr, x16, [SP, #-0x10]!
    // 0xad3958: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0xad3958: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0xad395c: r0 = encode()
    //     0xad395c: bl              #0xbfcb48  ; [dart:convert] JsonCodec::encode
    // 0xad3960: add             SP, SP, #0x10
    // 0xad3964: LeaveFrame
    //     0xad3964: mov             SP, fp
    //     0xad3968: ldp             fp, lr, [SP], #0x10
    // 0xad396c: ret
    //     0xad396c: ret             
    // 0xad3970: ldur            x0, [fp, #-8]
    // 0xad3974: r1 = 59
    //     0xad3974: mov             x1, #0x3b
    // 0xad3978: branchIfSmi(r0, 0xad3984)
    //     0xad3978: tbz             w0, #0, #0xad3984
    // 0xad397c: r1 = LoadClassIdInstr(r0)
    //     0xad397c: ldur            x1, [x0, #-1]
    //     0xad3980: ubfx            x1, x1, #0xc, #0x14
    // 0xad3984: SaveReg r0
    //     0xad3984: str             x0, [SP, #-8]!
    // 0xad3988: mov             x0, x1
    // 0xad398c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad398c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad3990: r0 = GDT[cid_x0 + 0x3f73]()
    //     0xad3990: mov             x17, #0x3f73
    //     0xad3994: add             lr, x0, x17
    //     0xad3998: ldr             lr, [x21, lr, lsl #3]
    //     0xad399c: blr             lr
    // 0xad39a0: add             SP, SP, #8
    // 0xad39a4: LeaveFrame
    //     0xad39a4: mov             SP, fp
    //     0xad39a8: ldp             fp, lr, [SP], #0x10
    // 0xad39ac: ret
    //     0xad39ac: ret             
    // 0xad39b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad39b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad39b4: b               #0xad3884
  }
}

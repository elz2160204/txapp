// lib: , url: package:dio/src/dio_exception.dart

// class id: 1048886, size: 0x8
class :: {
}

// class id: 4544, size: 0x1c, field offset: 0x8
class DioException extends Object
    implements Exception {

  const DioExceptionType type(DioException) {
    // ** addr: 0x9bbf34, size: 0x28
    // 0x9bbf34: ldr             x1, [SP]
    // 0x9bbf38: LoadField: r0 = r1->field_b
    //     0x9bbf38: ldur            w0, [x1, #0xb]
    // 0x9bbf3c: DecompressPointer r0
    //     0x9bbf3c: add             x0, x0, HEAP, lsl #32
    // 0x9bbf40: ret
    //     0x9bbf40: ret             
  }
  factory _ DioException.connectionError(/* No info */) {
    // ** addr: 0x5270a8, size: 0x68
    // 0x5270a8: EnterFrame
    //     0x5270a8: stp             fp, lr, [SP, #-0x10]!
    //     0x5270ac: mov             fp, SP
    // 0x5270b0: AllocStack(0x8)
    //     0x5270b0: sub             SP, SP, #8
    // 0x5270b4: CheckStackOverflow
    //     0x5270b4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5270b8: cmp             SP, x16
    //     0x5270bc: b.ls            #0x527108
    // 0x5270c0: r0 = DioException()
    //     0x5270c0: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0x5270c4: stur            x0, [fp, #-8]
    // 0x5270c8: stp             NULL, x0, [SP, #-0x10]!
    // 0x5270cc: ldr             x16, [fp, #0x10]
    // 0x5270d0: r30 = Instance_DioExceptionType
    //     0x5270d0: add             lr, PP, #0x12, lsl #12  ; [pp+0x12dd0] Obj!DioExceptionType@b666d1
    //     0x5270d4: ldr             lr, [lr, #0xdd0]
    // 0x5270d8: stp             lr, x16, [SP, #-0x10]!
    // 0x5270dc: r16 = "The connection errored: Dio can\'t establish a new connection after it was closed."
    //     0x5270dc: add             x16, PP, #0x12, lsl #12  ; [pp+0x12dd8] "The connection errored: Dio can\'t establish a new connection after it was closed."
    //     0x5270e0: ldr             x16, [x16, #0xdd8]
    // 0x5270e4: stp             NULL, x16, [SP, #-0x10]!
    // 0x5270e8: r4 = const [0, 0x6, 0x6, 0x3, message, 0x4, response, 0x5, type, 0x3, null]
    //     0x5270e8: add             x4, PP, #0x12, lsl #12  ; [pp+0x12de0] List(11) [0, 0x6, 0x6, 0x3, "message", 0x4, "response", 0x5, "type", 0x3, Null]
    //     0x5270ec: ldr             x4, [x4, #0xde0]
    // 0x5270f0: r0 = DioException()
    //     0x5270f0: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x5270f4: add             SP, SP, #0x30
    // 0x5270f8: ldur            x0, [fp, #-8]
    // 0x5270fc: LeaveFrame
    //     0x5270fc: mov             SP, fp
    //     0x527100: ldp             fp, lr, [SP], #0x10
    // 0x527104: ret
    //     0x527104: ret             
    // 0x527108: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x527108: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52710c: b               #0x5270c0
  }
  _ DioException(/* No info */) {
    // ** addr: 0x527134, size: 0x290
    // 0x527134: EnterFrame
    //     0x527134: stp             fp, lr, [SP, #-0x10]!
    //     0x527138: mov             fp, SP
    // 0x52713c: AllocStack(0x8)
    //     0x52713c: sub             SP, SP, #8
    // 0x527140: SetupParameters(DioException this /* r3, fp-0x8 */, dynamic _ /* r4 */, dynamic _ /* r5 */, {dynamic message = Null /* r6 */, dynamic response = Null /* r7 */, dynamic stackTrace = Null /* r8 */, dynamic type = Instance_DioExceptionType /* r1 */})
    //     0x527140: mov             x0, x4
    //     0x527144: ldur            w1, [x0, #0x13]
    //     0x527148: add             x1, x1, HEAP, lsl #32
    //     0x52714c: sub             x2, x1, #6
    //     0x527150: add             x3, fp, w2, sxtw #2
    //     0x527154: ldr             x3, [x3, #0x20]
    //     0x527158: stur            x3, [fp, #-8]
    //     0x52715c: add             x4, fp, w2, sxtw #2
    //     0x527160: ldr             x4, [x4, #0x18]
    //     0x527164: add             x5, fp, w2, sxtw #2
    //     0x527168: ldr             x5, [x5, #0x10]
    //     0x52716c: ldur            w2, [x0, #0x1f]
    //     0x527170: add             x2, x2, HEAP, lsl #32
    //     0x527174: ldr             x16, [PP, #0x62c8]  ; [pp+0x62c8] "message"
    //     0x527178: cmp             w2, w16
    //     0x52717c: b.ne            #0x5271a0
    //     0x527180: ldur            w2, [x0, #0x23]
    //     0x527184: add             x2, x2, HEAP, lsl #32
    //     0x527188: sub             w6, w1, w2
    //     0x52718c: add             x2, fp, w6, sxtw #2
    //     0x527190: ldr             x2, [x2, #8]
    //     0x527194: mov             x6, x2
    //     0x527198: mov             x2, #1
    //     0x52719c: b               #0x5271a8
    //     0x5271a0: mov             x6, NULL
    //     0x5271a4: mov             x2, #0
    //     0x5271a8: lsl             x7, x2, #1
    //     0x5271ac: lsl             w8, w7, #1
    //     0x5271b0: add             w9, w8, #8
    //     0x5271b4: add             x16, x0, w9, sxtw #1
    //     0x5271b8: ldur            w10, [x16, #0xf]
    //     0x5271bc: add             x10, x10, HEAP, lsl #32
    //     0x5271c0: ldr             x16, [PP, #0x2af0]  ; [pp+0x2af0] "response"
    //     0x5271c4: cmp             w10, w16
    //     0x5271c8: b.ne            #0x5271fc
    //     0x5271cc: add             w2, w8, #0xa
    //     0x5271d0: add             x16, x0, w2, sxtw #1
    //     0x5271d4: ldur            w8, [x16, #0xf]
    //     0x5271d8: add             x8, x8, HEAP, lsl #32
    //     0x5271dc: sub             w2, w1, w8
    //     0x5271e0: add             x8, fp, w2, sxtw #2
    //     0x5271e4: ldr             x8, [x8, #8]
    //     0x5271e8: add             w2, w7, #2
    //     0x5271ec: sbfx            x7, x2, #1, #0x1f
    //     0x5271f0: mov             x2, x7
    //     0x5271f4: mov             x7, x8
    //     0x5271f8: b               #0x527200
    //     0x5271fc: mov             x7, NULL
    //     0x527200: lsl             x8, x2, #1
    //     0x527204: lsl             w9, w8, #1
    //     0x527208: add             w10, w9, #8
    //     0x52720c: add             x16, x0, w10, sxtw #1
    //     0x527210: ldur            w11, [x16, #0xf]
    //     0x527214: add             x11, x11, HEAP, lsl #32
    //     0x527218: ldr             x16, [PP, #0x4060]  ; [pp+0x4060] "stackTrace"
    //     0x52721c: cmp             w11, w16
    //     0x527220: b.ne            #0x527254
    //     0x527224: add             w2, w9, #0xa
    //     0x527228: add             x16, x0, w2, sxtw #1
    //     0x52722c: ldur            w9, [x16, #0xf]
    //     0x527230: add             x9, x9, HEAP, lsl #32
    //     0x527234: sub             w2, w1, w9
    //     0x527238: add             x9, fp, w2, sxtw #2
    //     0x52723c: ldr             x9, [x9, #8]
    //     0x527240: add             w2, w8, #2
    //     0x527244: sbfx            x8, x2, #1, #0x1f
    //     0x527248: mov             x2, x8
    //     0x52724c: mov             x8, x9
    //     0x527250: b               #0x527258
    //     0x527254: mov             x8, NULL
    //     0x527258: lsl             x9, x2, #1
    //     0x52725c: lsl             w2, w9, #1
    //     0x527260: add             w9, w2, #8
    //     0x527264: add             x16, x0, w9, sxtw #1
    //     0x527268: ldur            w10, [x16, #0xf]
    //     0x52726c: add             x10, x10, HEAP, lsl #32
    //     0x527270: ldr             x16, [PP, #0x1db8]  ; [pp+0x1db8] "type"
    //     0x527274: cmp             w10, w16
    //     0x527278: b.ne            #0x52729c
    //     0x52727c: add             w9, w2, #0xa
    //     0x527280: add             x16, x0, w9, sxtw #1
    //     0x527284: ldur            w2, [x16, #0xf]
    //     0x527288: add             x2, x2, HEAP, lsl #32
    //     0x52728c: sub             w0, w1, w2
    //     0x527290: add             x1, fp, w0, sxtw #2
    //     0x527294: ldr             x1, [x1, #8]
    //     0x527298: b               #0x5272a4
    //     0x52729c: add             x1, PP, #0x12, lsl #12  ; [pp+0x12de8] Obj!DioExceptionType@b666b1
    //     0x5272a0: ldr             x1, [x1, #0xde8]
    // 0x5272a4: CheckStackOverflow
    //     0x5272a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5272a8: cmp             SP, x16
    //     0x5272ac: b.ls            #0x5273bc
    // 0x5272b0: mov             x0, x7
    // 0x5272b4: StoreField: r3->field_7 = r0
    //     0x5272b4: stur            w0, [x3, #7]
    //     0x5272b8: ldurb           w16, [x3, #-1]
    //     0x5272bc: ldurb           w17, [x0, #-1]
    //     0x5272c0: and             x16, x17, x16, lsr #2
    //     0x5272c4: tst             x16, HEAP, lsr #32
    //     0x5272c8: b.eq            #0x5272d0
    //     0x5272cc: bl              #0xd682ac
    // 0x5272d0: mov             x0, x1
    // 0x5272d4: StoreField: r3->field_b = r0
    //     0x5272d4: stur            w0, [x3, #0xb]
    //     0x5272d8: ldurb           w16, [x3, #-1]
    //     0x5272dc: ldurb           w17, [x0, #-1]
    //     0x5272e0: and             x16, x17, x16, lsr #2
    //     0x5272e4: tst             x16, HEAP, lsr #32
    //     0x5272e8: b.eq            #0x5272f0
    //     0x5272ec: bl              #0xd682ac
    // 0x5272f0: mov             x0, x4
    // 0x5272f4: StoreField: r3->field_f = r0
    //     0x5272f4: stur            w0, [x3, #0xf]
    //     0x5272f8: tbz             w0, #0, #0x527314
    //     0x5272fc: ldurb           w16, [x3, #-1]
    //     0x527300: ldurb           w17, [x0, #-1]
    //     0x527304: and             x16, x17, x16, lsr #2
    //     0x527308: tst             x16, HEAP, lsr #32
    //     0x52730c: b.eq            #0x527314
    //     0x527310: bl              #0xd682ac
    // 0x527314: mov             x0, x6
    // 0x527318: StoreField: r3->field_17 = r0
    //     0x527318: stur            w0, [x3, #0x17]
    //     0x52731c: ldurb           w16, [x3, #-1]
    //     0x527320: ldurb           w17, [x0, #-1]
    //     0x527324: and             x16, x17, x16, lsr #2
    //     0x527328: tst             x16, HEAP, lsr #32
    //     0x52732c: b.eq            #0x527334
    //     0x527330: bl              #0xd682ac
    // 0x527334: r16 = Instance__StringStackTrace
    //     0x527334: ldr             x16, [PP, #0x3008]  ; [pp+0x3008] Obj!_StringStackTrace@b5f8d1
    // 0x527338: cmp             w8, w16
    // 0x52733c: b.ne            #0x527358
    // 0x527340: LoadField: r0 = r5->field_4f
    //     0x527340: ldur            w0, [x5, #0x4f]
    // 0x527344: DecompressPointer r0
    //     0x527344: add             x0, x0, HEAP, lsl #32
    // 0x527348: cmp             w0, NULL
    // 0x52734c: b.ne            #0x52738c
    // 0x527350: r0 = current()
    //     0x527350: bl              #0x4ff3d0  ; [dart:core] StackTrace::current
    // 0x527354: b               #0x52738c
    // 0x527358: cmp             w8, NULL
    // 0x52735c: b.ne            #0x52736c
    // 0x527360: LoadField: r0 = r5->field_4f
    //     0x527360: ldur            w0, [x5, #0x4f]
    // 0x527364: DecompressPointer r0
    //     0x527364: add             x0, x0, HEAP, lsl #32
    // 0x527368: b               #0x527370
    // 0x52736c: mov             x0, x8
    // 0x527370: cmp             w0, NULL
    // 0x527374: b.ne            #0x527384
    // 0x527378: r0 = current()
    //     0x527378: bl              #0x4ff3d0  ; [dart:core] StackTrace::current
    // 0x52737c: mov             x1, x0
    // 0x527380: b               #0x527388
    // 0x527384: mov             x1, x0
    // 0x527388: mov             x0, x1
    // 0x52738c: ldur            x1, [fp, #-8]
    // 0x527390: StoreField: r1->field_13 = r0
    //     0x527390: stur            w0, [x1, #0x13]
    //     0x527394: ldurb           w16, [x1, #-1]
    //     0x527398: ldurb           w17, [x0, #-1]
    //     0x52739c: and             x16, x17, x16, lsr #2
    //     0x5273a0: tst             x16, HEAP, lsr #32
    //     0x5273a4: b.eq            #0x5273ac
    //     0x5273a8: bl              #0xd6826c
    // 0x5273ac: r0 = Null
    //     0x5273ac: mov             x0, NULL
    // 0x5273b0: LeaveFrame
    //     0x5273b0: mov             SP, fp
    //     0x5273b4: ldp             fp, lr, [SP], #0x10
    // 0x5273b8: ret
    //     0x5273b8: ret             
    // 0x5273bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5273bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5273c0: b               #0x5272b0
  }
  factory _ DioException.badResponse(/* No info */) {
    // ** addr: 0x52ad28, size: 0xb8
    // 0x52ad28: EnterFrame
    //     0x52ad28: stp             fp, lr, [SP, #-0x10]!
    //     0x52ad2c: mov             fp, SP
    // 0x52ad30: AllocStack(0x10)
    //     0x52ad30: sub             SP, SP, #0x10
    // 0x52ad34: CheckStackOverflow
    //     0x52ad34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52ad38: cmp             SP, x16
    //     0x52ad3c: b.ls            #0x52add8
    // 0x52ad40: r1 = Null
    //     0x52ad40: mov             x1, NULL
    // 0x52ad44: r2 = 6
    //     0x52ad44: mov             x2, #6
    // 0x52ad48: r0 = AllocateArray()
    //     0x52ad48: bl              #0xd6987c  ; AllocateArrayStub
    // 0x52ad4c: mov             x2, x0
    // 0x52ad50: r17 = "The request returned an invalid status code of "
    //     0x52ad50: add             x17, PP, #0x13, lsl #12  ; [pp+0x13148] "The request returned an invalid status code of "
    //     0x52ad54: ldr             x17, [x17, #0x148]
    // 0x52ad58: StoreField: r2->field_f = r17
    //     0x52ad58: stur            w17, [x2, #0xf]
    // 0x52ad5c: ldr             x3, [fp, #0x10]
    // 0x52ad60: r0 = BoxInt64Instr(r3)
    //     0x52ad60: sbfiz           x0, x3, #1, #0x1f
    //     0x52ad64: cmp             x3, x0, asr #1
    //     0x52ad68: b.eq            #0x52ad74
    //     0x52ad6c: bl              #0xd69bb8
    //     0x52ad70: stur            x3, [x0, #7]
    // 0x52ad74: StoreField: r2->field_13 = r0
    //     0x52ad74: stur            w0, [x2, #0x13]
    // 0x52ad78: r17 = "."
    //     0x52ad78: ldr             x17, [PP, #0x6b8]  ; [pp+0x6b8] "."
    // 0x52ad7c: StoreField: r2->field_17 = r17
    //     0x52ad7c: stur            w17, [x2, #0x17]
    // 0x52ad80: SaveReg r2
    //     0x52ad80: str             x2, [SP, #-8]!
    // 0x52ad84: r0 = _interpolate()
    //     0x52ad84: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x52ad88: add             SP, SP, #8
    // 0x52ad8c: stur            x0, [fp, #-8]
    // 0x52ad90: r0 = DioException()
    //     0x52ad90: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0x52ad94: stur            x0, [fp, #-0x10]
    // 0x52ad98: stp             NULL, x0, [SP, #-0x10]!
    // 0x52ad9c: ldr             x16, [fp, #0x20]
    // 0x52ada0: r30 = Instance_DioExceptionType
    //     0x52ada0: add             lr, PP, #0x12, lsl #12  ; [pp+0x12d78] Obj!DioExceptionType@b66691
    //     0x52ada4: ldr             lr, [lr, #0xd78]
    // 0x52ada8: stp             lr, x16, [SP, #-0x10]!
    // 0x52adac: ldur            x16, [fp, #-8]
    // 0x52adb0: ldr             lr, [fp, #0x18]
    // 0x52adb4: stp             lr, x16, [SP, #-0x10]!
    // 0x52adb8: r4 = const [0, 0x6, 0x6, 0x3, message, 0x4, response, 0x5, type, 0x3, null]
    //     0x52adb8: add             x4, PP, #0x12, lsl #12  ; [pp+0x12de0] List(11) [0, 0x6, 0x6, 0x3, "message", 0x4, "response", 0x5, "type", 0x3, Null]
    //     0x52adbc: ldr             x4, [x4, #0xde0]
    // 0x52adc0: r0 = DioException()
    //     0x52adc0: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x52adc4: add             SP, SP, #0x30
    // 0x52adc8: ldur            x0, [fp, #-0x10]
    // 0x52adcc: LeaveFrame
    //     0x52adcc: mov             SP, fp
    //     0x52add0: ldp             fp, lr, [SP], #0x10
    // 0x52add4: ret
    //     0x52add4: ret             
    // 0x52add8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52add8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52addc: b               #0x52ad40
  }
  factory _ DioException.connectionTimeout(/* No info */) {
    // ** addr: 0x52f98c, size: 0x104
    // 0x52f98c: EnterFrame
    //     0x52f98c: stp             fp, lr, [SP, #-0x10]!
    //     0x52f990: mov             fp, SP
    // 0x52f994: AllocStack(0x20)
    //     0x52f994: sub             SP, SP, #0x20
    // 0x52f998: SetupParameters(dynamic _ /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic error = Null /* r0, fp-0x8 */})
    //     0x52f998: mov             x0, x4
    //     0x52f99c: ldur            w1, [x0, #0x13]
    //     0x52f9a0: add             x1, x1, HEAP, lsl #32
    //     0x52f9a4: sub             x2, x1, #6
    //     0x52f9a8: add             x3, fp, w2, sxtw #2
    //     0x52f9ac: ldr             x3, [x3, #0x18]
    //     0x52f9b0: stur            x3, [fp, #-0x18]
    //     0x52f9b4: add             x4, fp, w2, sxtw #2
    //     0x52f9b8: ldr             x4, [x4, #0x10]
    //     0x52f9bc: stur            x4, [fp, #-0x10]
    //     0x52f9c0: ldur            w2, [x0, #0x1f]
    //     0x52f9c4: add             x2, x2, HEAP, lsl #32
    //     0x52f9c8: ldr             x16, [PP, #0xeb8]  ; [pp+0xeb8] "error"
    //     0x52f9cc: cmp             w2, w16
    //     0x52f9d0: b.ne            #0x52f9f0
    //     0x52f9d4: ldur            w2, [x0, #0x23]
    //     0x52f9d8: add             x2, x2, HEAP, lsl #32
    //     0x52f9dc: sub             w0, w1, w2
    //     0x52f9e0: add             x1, fp, w0, sxtw #2
    //     0x52f9e4: ldr             x1, [x1, #8]
    //     0x52f9e8: mov             x0, x1
    //     0x52f9ec: b               #0x52f9f4
    //     0x52f9f0: mov             x0, NULL
    //     0x52f9f4: stur            x0, [fp, #-8]
    // 0x52f9f8: CheckStackOverflow
    //     0x52f9f8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52f9fc: cmp             SP, x16
    //     0x52fa00: b.ls            #0x52fa88
    // 0x52fa04: r1 = Null
    //     0x52fa04: mov             x1, NULL
    // 0x52fa08: r2 = 6
    //     0x52fa08: mov             x2, #6
    // 0x52fa0c: r0 = AllocateArray()
    //     0x52fa0c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x52fa10: r17 = "The request connection took longer than "
    //     0x52fa10: add             x17, PP, #0x13, lsl #12  ; [pp+0x13620] "The request connection took longer than "
    //     0x52fa14: ldr             x17, [x17, #0x620]
    // 0x52fa18: StoreField: r0->field_f = r17
    //     0x52fa18: stur            w17, [x0, #0xf]
    // 0x52fa1c: ldur            x1, [fp, #-0x10]
    // 0x52fa20: StoreField: r0->field_13 = r1
    //     0x52fa20: stur            w1, [x0, #0x13]
    // 0x52fa24: r17 = ". It was aborted."
    //     0x52fa24: add             x17, PP, #0x13, lsl #12  ; [pp+0x13628] ". It was aborted."
    //     0x52fa28: ldr             x17, [x17, #0x628]
    // 0x52fa2c: StoreField: r0->field_17 = r17
    //     0x52fa2c: stur            w17, [x0, #0x17]
    // 0x52fa30: SaveReg r0
    //     0x52fa30: str             x0, [SP, #-8]!
    // 0x52fa34: r0 = _interpolate()
    //     0x52fa34: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x52fa38: add             SP, SP, #8
    // 0x52fa3c: stur            x0, [fp, #-0x10]
    // 0x52fa40: r0 = DioException()
    //     0x52fa40: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0x52fa44: stur            x0, [fp, #-0x20]
    // 0x52fa48: ldur            x16, [fp, #-8]
    // 0x52fa4c: stp             x16, x0, [SP, #-0x10]!
    // 0x52fa50: ldur            x16, [fp, #-0x18]
    // 0x52fa54: r30 = Instance_DioExceptionType
    //     0x52fa54: add             lr, PP, #0x12, lsl #12  ; [pp+0x12d88] Obj!DioExceptionType@b66671
    //     0x52fa58: ldr             lr, [lr, #0xd88]
    // 0x52fa5c: stp             lr, x16, [SP, #-0x10]!
    // 0x52fa60: ldur            x16, [fp, #-0x10]
    // 0x52fa64: stp             NULL, x16, [SP, #-0x10]!
    // 0x52fa68: r4 = const [0, 0x6, 0x6, 0x3, message, 0x4, response, 0x5, type, 0x3, null]
    //     0x52fa68: add             x4, PP, #0x12, lsl #12  ; [pp+0x12de0] List(11) [0, 0x6, 0x6, 0x3, "message", 0x4, "response", 0x5, "type", 0x3, Null]
    //     0x52fa6c: ldr             x4, [x4, #0xde0]
    // 0x52fa70: r0 = DioException()
    //     0x52fa70: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x52fa74: add             SP, SP, #0x30
    // 0x52fa78: ldur            x0, [fp, #-0x20]
    // 0x52fa7c: LeaveFrame
    //     0x52fa7c: mov             SP, fp
    //     0x52fa80: ldp             fp, lr, [SP], #0x10
    // 0x52fa84: ret
    //     0x52fa84: ret             
    // 0x52fa88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52fa88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52fa8c: b               #0x52fa04
  }
  factory _ DioException.receiveTimeout(/* No info */) {
    // ** addr: 0x556c64, size: 0x104
    // 0x556c64: EnterFrame
    //     0x556c64: stp             fp, lr, [SP, #-0x10]!
    //     0x556c68: mov             fp, SP
    // 0x556c6c: AllocStack(0x20)
    //     0x556c6c: sub             SP, SP, #0x20
    // 0x556c70: SetupParameters(dynamic _ /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */, {dynamic error = Null /* r0, fp-0x8 */})
    //     0x556c70: mov             x0, x4
    //     0x556c74: ldur            w1, [x0, #0x13]
    //     0x556c78: add             x1, x1, HEAP, lsl #32
    //     0x556c7c: sub             x2, x1, #6
    //     0x556c80: add             x3, fp, w2, sxtw #2
    //     0x556c84: ldr             x3, [x3, #0x18]
    //     0x556c88: stur            x3, [fp, #-0x18]
    //     0x556c8c: add             x4, fp, w2, sxtw #2
    //     0x556c90: ldr             x4, [x4, #0x10]
    //     0x556c94: stur            x4, [fp, #-0x10]
    //     0x556c98: ldur            w2, [x0, #0x1f]
    //     0x556c9c: add             x2, x2, HEAP, lsl #32
    //     0x556ca0: ldr             x16, [PP, #0xeb8]  ; [pp+0xeb8] "error"
    //     0x556ca4: cmp             w2, w16
    //     0x556ca8: b.ne            #0x556cc8
    //     0x556cac: ldur            w2, [x0, #0x23]
    //     0x556cb0: add             x2, x2, HEAP, lsl #32
    //     0x556cb4: sub             w0, w1, w2
    //     0x556cb8: add             x1, fp, w0, sxtw #2
    //     0x556cbc: ldr             x1, [x1, #8]
    //     0x556cc0: mov             x0, x1
    //     0x556cc4: b               #0x556ccc
    //     0x556cc8: mov             x0, NULL
    //     0x556ccc: stur            x0, [fp, #-8]
    // 0x556cd0: CheckStackOverflow
    //     0x556cd0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x556cd4: cmp             SP, x16
    //     0x556cd8: b.ls            #0x556d60
    // 0x556cdc: r1 = Null
    //     0x556cdc: mov             x1, NULL
    // 0x556ce0: r2 = 6
    //     0x556ce0: mov             x2, #6
    // 0x556ce4: r0 = AllocateArray()
    //     0x556ce4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x556ce8: r17 = "The request took longer than "
    //     0x556ce8: add             x17, PP, #0x13, lsl #12  ; [pp+0x134e0] "The request took longer than "
    //     0x556cec: ldr             x17, [x17, #0x4e0]
    // 0x556cf0: StoreField: r0->field_f = r17
    //     0x556cf0: stur            w17, [x0, #0xf]
    // 0x556cf4: ldur            x1, [fp, #-0x10]
    // 0x556cf8: StoreField: r0->field_13 = r1
    //     0x556cf8: stur            w1, [x0, #0x13]
    // 0x556cfc: r17 = " to receive data. It was aborted."
    //     0x556cfc: add             x17, PP, #0x13, lsl #12  ; [pp+0x134e8] " to receive data. It was aborted."
    //     0x556d00: ldr             x17, [x17, #0x4e8]
    // 0x556d04: StoreField: r0->field_17 = r17
    //     0x556d04: stur            w17, [x0, #0x17]
    // 0x556d08: SaveReg r0
    //     0x556d08: str             x0, [SP, #-8]!
    // 0x556d0c: r0 = _interpolate()
    //     0x556d0c: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x556d10: add             SP, SP, #8
    // 0x556d14: stur            x0, [fp, #-0x10]
    // 0x556d18: r0 = DioException()
    //     0x556d18: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0x556d1c: stur            x0, [fp, #-0x20]
    // 0x556d20: ldur            x16, [fp, #-8]
    // 0x556d24: stp             x16, x0, [SP, #-0x10]!
    // 0x556d28: ldur            x16, [fp, #-0x18]
    // 0x556d2c: r30 = Instance_DioExceptionType
    //     0x556d2c: add             lr, PP, #0x12, lsl #12  ; [pp+0x12d90] Obj!DioExceptionType@b66651
    //     0x556d30: ldr             lr, [lr, #0xd90]
    // 0x556d34: stp             lr, x16, [SP, #-0x10]!
    // 0x556d38: ldur            x16, [fp, #-0x10]
    // 0x556d3c: stp             NULL, x16, [SP, #-0x10]!
    // 0x556d40: r4 = const [0, 0x6, 0x6, 0x3, message, 0x4, response, 0x5, type, 0x3, null]
    //     0x556d40: add             x4, PP, #0x12, lsl #12  ; [pp+0x12de0] List(11) [0, 0x6, 0x6, 0x3, "message", 0x4, "response", 0x5, "type", 0x3, Null]
    //     0x556d44: ldr             x4, [x4, #0xde0]
    // 0x556d48: r0 = DioException()
    //     0x556d48: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x556d4c: add             SP, SP, #0x30
    // 0x556d50: ldur            x0, [fp, #-0x20]
    // 0x556d54: LeaveFrame
    //     0x556d54: mov             SP, fp
    //     0x556d58: ldp             fp, lr, [SP], #0x10
    // 0x556d5c: ret
    //     0x556d5c: ret             
    // 0x556d60: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556d60: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556d64: b               #0x556cdc
  }
  factory _ DioException.sendTimeout(/* No info */) {
    // ** addr: 0x556eb0, size: 0xa0
    // 0x556eb0: EnterFrame
    //     0x556eb0: stp             fp, lr, [SP, #-0x10]!
    //     0x556eb4: mov             fp, SP
    // 0x556eb8: AllocStack(0x10)
    //     0x556eb8: sub             SP, SP, #0x10
    // 0x556ebc: CheckStackOverflow
    //     0x556ebc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x556ec0: cmp             SP, x16
    //     0x556ec4: b.ls            #0x556f48
    // 0x556ec8: r1 = Null
    //     0x556ec8: mov             x1, NULL
    // 0x556ecc: r2 = 6
    //     0x556ecc: mov             x2, #6
    // 0x556ed0: r0 = AllocateArray()
    //     0x556ed0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x556ed4: r17 = "The request took longer than "
    //     0x556ed4: add             x17, PP, #0x13, lsl #12  ; [pp+0x134e0] "The request took longer than "
    //     0x556ed8: ldr             x17, [x17, #0x4e0]
    // 0x556edc: StoreField: r0->field_f = r17
    //     0x556edc: stur            w17, [x0, #0xf]
    // 0x556ee0: ldr             x1, [fp, #0x10]
    // 0x556ee4: StoreField: r0->field_13 = r1
    //     0x556ee4: stur            w1, [x0, #0x13]
    // 0x556ee8: r17 = " to send data. It was aborted."
    //     0x556ee8: add             x17, PP, #0x13, lsl #12  ; [pp+0x134f8] " to send data. It was aborted."
    //     0x556eec: ldr             x17, [x17, #0x4f8]
    // 0x556ef0: StoreField: r0->field_17 = r17
    //     0x556ef0: stur            w17, [x0, #0x17]
    // 0x556ef4: SaveReg r0
    //     0x556ef4: str             x0, [SP, #-8]!
    // 0x556ef8: r0 = _interpolate()
    //     0x556ef8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x556efc: add             SP, SP, #8
    // 0x556f00: stur            x0, [fp, #-8]
    // 0x556f04: r0 = DioException()
    //     0x556f04: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0x556f08: stur            x0, [fp, #-0x10]
    // 0x556f0c: stp             NULL, x0, [SP, #-0x10]!
    // 0x556f10: ldr             x16, [fp, #0x18]
    // 0x556f14: r30 = Instance_DioExceptionType
    //     0x556f14: add             lr, PP, #0x13, lsl #12  ; [pp+0x13500] Obj!DioExceptionType@b666f1
    //     0x556f18: ldr             lr, [lr, #0x500]
    // 0x556f1c: stp             lr, x16, [SP, #-0x10]!
    // 0x556f20: ldur            x16, [fp, #-8]
    // 0x556f24: stp             NULL, x16, [SP, #-0x10]!
    // 0x556f28: r4 = const [0, 0x6, 0x6, 0x3, message, 0x4, response, 0x5, type, 0x3, null]
    //     0x556f28: add             x4, PP, #0x12, lsl #12  ; [pp+0x12de0] List(11) [0, 0x6, 0x6, 0x3, "message", 0x4, "response", 0x5, "type", 0x3, Null]
    //     0x556f2c: ldr             x4, [x4, #0xde0]
    // 0x556f30: r0 = DioException()
    //     0x556f30: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0x556f34: add             SP, SP, #0x30
    // 0x556f38: ldur            x0, [fp, #-0x10]
    // 0x556f3c: LeaveFrame
    //     0x556f3c: mov             SP, fp
    //     0x556f40: ldp             fp, lr, [SP], #0x10
    // 0x556f44: ret
    //     0x556f44: ret             
    // 0x556f48: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556f48: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556f4c: b               #0x556ec8
  }
  factory _ DioException.requestCancelled(/* No info */) {
    // ** addr: 0xa568e8, size: 0x70
    // 0xa568e8: EnterFrame
    //     0xa568e8: stp             fp, lr, [SP, #-0x10]!
    //     0xa568ec: mov             fp, SP
    // 0xa568f0: AllocStack(0x8)
    //     0xa568f0: sub             SP, SP, #8
    // 0xa568f4: CheckStackOverflow
    //     0xa568f4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa568f8: cmp             SP, x16
    //     0xa568fc: b.ls            #0xa56950
    // 0xa56900: r0 = DioException()
    //     0xa56900: bl              #0x5273c4  ; AllocateDioExceptionStub -> DioException (size=0x1c)
    // 0xa56904: stur            x0, [fp, #-8]
    // 0xa56908: stp             NULL, x0, [SP, #-0x10]!
    // 0xa5690c: ldr             x16, [fp, #0x18]
    // 0xa56910: r30 = Instance_DioExceptionType
    //     0xa56910: add             lr, PP, #0x12, lsl #12  ; [pp+0x12da0] Obj!DioExceptionType@b66631
    //     0xa56914: ldr             lr, [lr, #0xda0]
    // 0xa56918: stp             lr, x16, [SP, #-0x10]!
    // 0xa5691c: r16 = "The request was cancelled."
    //     0xa5691c: add             x16, PP, #0x2c, lsl #12  ; [pp+0x2c8f8] "The request was cancelled."
    //     0xa56920: ldr             x16, [x16, #0x8f8]
    // 0xa56924: stp             NULL, x16, [SP, #-0x10]!
    // 0xa56928: ldr             x16, [fp, #0x10]
    // 0xa5692c: SaveReg r16
    //     0xa5692c: str             x16, [SP, #-8]!
    // 0xa56930: r4 = const [0, 0x7, 0x7, 0x3, message, 0x4, response, 0x5, stackTrace, 0x6, type, 0x3, null]
    //     0xa56930: add             x4, PP, #0x2c, lsl #12  ; [pp+0x2c900] List(13) [0, 0x7, 0x7, 0x3, "message", 0x4, "response", 0x5, "stackTrace", 0x6, "type", 0x3, Null]
    //     0xa56934: ldr             x4, [x4, #0x900]
    // 0xa56938: r0 = DioException()
    //     0xa56938: bl              #0x527134  ; [package:dio/src/dio_exception.dart] DioException::DioException
    // 0xa5693c: add             SP, SP, #0x38
    // 0xa56940: ldur            x0, [fp, #-8]
    // 0xa56944: LeaveFrame
    //     0xa56944: mov             SP, fp
    //     0xa56948: ldp             fp, lr, [SP], #0x10
    // 0xa5694c: ret
    //     0xa5694c: ret             
    // 0xa56950: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa56950: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa56954: b               #0xa56900
  }
  _ toString(/* No info */) {
    // ** addr: 0xad3504, size: 0x174
    // 0xad3504: EnterFrame
    //     0xad3504: stp             fp, lr, [SP, #-0x10]!
    //     0xad3508: mov             fp, SP
    // 0xad350c: AllocStack(0x10)
    //     0xad350c: sub             SP, SP, #0x10
    // 0xad3510: CheckStackOverflow
    //     0xad3510: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3514: cmp             SP, x16
    //     0xad3518: b.ls            #0xad3670
    // 0xad351c: r1 = Null
    //     0xad351c: mov             x1, NULL
    // 0xad3520: r2 = 8
    //     0xad3520: mov             x2, #8
    // 0xad3524: r0 = AllocateArray()
    //     0xad3524: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad3528: r17 = "DioException ["
    //     0xad3528: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d638] "DioException ["
    //     0xad352c: ldr             x17, [x17, #0x638]
    // 0xad3530: StoreField: r0->field_f = r17
    //     0xad3530: stur            w17, [x0, #0xf]
    // 0xad3534: ldr             x1, [fp, #0x10]
    // 0xad3538: LoadField: r2 = r1->field_b
    //     0xad3538: ldur            w2, [x1, #0xb]
    // 0xad353c: DecompressPointer r2
    //     0xad353c: add             x2, x2, HEAP, lsl #32
    // 0xad3540: LoadField: r3 = r2->field_7
    //     0xad3540: ldur            x3, [x2, #7]
    // 0xad3544: cmp             x3, #3
    // 0xad3548: b.gt            #0xad3594
    // 0xad354c: cmp             x3, #1
    // 0xad3550: b.gt            #0xad3574
    // 0xad3554: cmp             x3, #0
    // 0xad3558: b.gt            #0xad3568
    // 0xad355c: r2 = "connection timeout"
    //     0xad355c: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d640] "connection timeout"
    //     0xad3560: ldr             x2, [x2, #0x640]
    // 0xad3564: b               #0xad35d8
    // 0xad3568: r2 = "send timeout"
    //     0xad3568: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d648] "send timeout"
    //     0xad356c: ldr             x2, [x2, #0x648]
    // 0xad3570: b               #0xad35d8
    // 0xad3574: cmp             x3, #2
    // 0xad3578: b.gt            #0xad3588
    // 0xad357c: r2 = "receive timeout"
    //     0xad357c: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d650] "receive timeout"
    //     0xad3580: ldr             x2, [x2, #0x650]
    // 0xad3584: b               #0xad35d8
    // 0xad3588: r2 = "bad certificate"
    //     0xad3588: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d658] "bad certificate"
    //     0xad358c: ldr             x2, [x2, #0x658]
    // 0xad3590: b               #0xad35d8
    // 0xad3594: cmp             x3, #5
    // 0xad3598: b.gt            #0xad35bc
    // 0xad359c: cmp             x3, #4
    // 0xad35a0: b.gt            #0xad35b0
    // 0xad35a4: r2 = "bad response"
    //     0xad35a4: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d660] "bad response"
    //     0xad35a8: ldr             x2, [x2, #0x660]
    // 0xad35ac: b               #0xad35d8
    // 0xad35b0: r2 = "request cancelled"
    //     0xad35b0: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d668] "request cancelled"
    //     0xad35b4: ldr             x2, [x2, #0x668]
    // 0xad35b8: b               #0xad35d8
    // 0xad35bc: cmp             x3, #6
    // 0xad35c0: b.gt            #0xad35d0
    // 0xad35c4: r2 = "connection error"
    //     0xad35c4: add             x2, PP, #0x1d, lsl #12  ; [pp+0x1d670] "connection error"
    //     0xad35c8: ldr             x2, [x2, #0x670]
    // 0xad35cc: b               #0xad35d8
    // 0xad35d0: r2 = "unknown"
    //     0xad35d0: add             x2, PP, #0x14, lsl #12  ; [pp+0x14af8] "unknown"
    //     0xad35d4: ldr             x2, [x2, #0xaf8]
    // 0xad35d8: StoreField: r0->field_13 = r2
    //     0xad35d8: stur            w2, [x0, #0x13]
    // 0xad35dc: r17 = "]: "
    //     0xad35dc: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d678] "]: "
    //     0xad35e0: ldr             x17, [x17, #0x678]
    // 0xad35e4: StoreField: r0->field_17 = r17
    //     0xad35e4: stur            w17, [x0, #0x17]
    // 0xad35e8: LoadField: r2 = r1->field_17
    //     0xad35e8: ldur            w2, [x1, #0x17]
    // 0xad35ec: DecompressPointer r2
    //     0xad35ec: add             x2, x2, HEAP, lsl #32
    // 0xad35f0: StoreField: r0->field_1b = r2
    //     0xad35f0: stur            w2, [x0, #0x1b]
    // 0xad35f4: SaveReg r0
    //     0xad35f4: str             x0, [SP, #-8]!
    // 0xad35f8: r0 = _interpolate()
    //     0xad35f8: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad35fc: add             SP, SP, #8
    // 0xad3600: mov             x3, x0
    // 0xad3604: ldr             x0, [fp, #0x10]
    // 0xad3608: stur            x3, [fp, #-0x10]
    // 0xad360c: LoadField: r4 = r0->field_f
    //     0xad360c: ldur            w4, [x0, #0xf]
    // 0xad3610: DecompressPointer r4
    //     0xad3610: add             x4, x4, HEAP, lsl #32
    // 0xad3614: stur            x4, [fp, #-8]
    // 0xad3618: cmp             w4, NULL
    // 0xad361c: b.eq            #0xad3660
    // 0xad3620: r1 = Null
    //     0xad3620: mov             x1, NULL
    // 0xad3624: r2 = 4
    //     0xad3624: mov             x2, #4
    // 0xad3628: r0 = AllocateArray()
    //     0xad3628: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad362c: r17 = "\nError: "
    //     0xad362c: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d680] "\nError: "
    //     0xad3630: ldr             x17, [x17, #0x680]
    // 0xad3634: StoreField: r0->field_f = r17
    //     0xad3634: stur            w17, [x0, #0xf]
    // 0xad3638: ldur            x1, [fp, #-8]
    // 0xad363c: StoreField: r0->field_13 = r1
    //     0xad363c: stur            w1, [x0, #0x13]
    // 0xad3640: SaveReg r0
    //     0xad3640: str             x0, [SP, #-8]!
    // 0xad3644: r0 = _interpolate()
    //     0xad3644: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3648: add             SP, SP, #8
    // 0xad364c: ldur            x16, [fp, #-0x10]
    // 0xad3650: stp             x0, x16, [SP, #-0x10]!
    // 0xad3654: r0 = +()
    //     0xad3654: bl              #0x4bdb18  ; [dart:core] _StringBase::+
    // 0xad3658: add             SP, SP, #0x10
    // 0xad365c: b               #0xad3664
    // 0xad3660: ldur            x0, [fp, #-0x10]
    // 0xad3664: LeaveFrame
    //     0xad3664: mov             SP, fp
    //     0xad3668: ldp             fp, lr, [SP], #0x10
    // 0xad366c: ret
    //     0xad366c: ret             
    // 0xad3670: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3670: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3674: b               #0xad351c
  }
}

// class id: 6009, size: 0x14, field offset: 0x14
enum DioExceptionType extends _Enum {

  _Mint field_8;
  _OneByteString field_10;

  _ _enumToString(/* No info */) {
    // ** addr: 0xb154a4, size: 0x5c
    // 0xb154a4: EnterFrame
    //     0xb154a4: stp             fp, lr, [SP, #-0x10]!
    //     0xb154a8: mov             fp, SP
    // 0xb154ac: CheckStackOverflow
    //     0xb154ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xb154b0: cmp             SP, x16
    //     0xb154b4: b.ls            #0xb154f8
    // 0xb154b8: r1 = Null
    //     0xb154b8: mov             x1, NULL
    // 0xb154bc: r2 = 4
    //     0xb154bc: mov             x2, #4
    // 0xb154c0: r0 = AllocateArray()
    //     0xb154c0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xb154c4: r17 = "DioExceptionType."
    //     0xb154c4: add             x17, PP, #0x1d, lsl #12  ; [pp+0x1d630] "DioExceptionType."
    //     0xb154c8: ldr             x17, [x17, #0x630]
    // 0xb154cc: StoreField: r0->field_f = r17
    //     0xb154cc: stur            w17, [x0, #0xf]
    // 0xb154d0: ldr             x1, [fp, #0x10]
    // 0xb154d4: LoadField: r2 = r1->field_f
    //     0xb154d4: ldur            w2, [x1, #0xf]
    // 0xb154d8: DecompressPointer r2
    //     0xb154d8: add             x2, x2, HEAP, lsl #32
    // 0xb154dc: StoreField: r0->field_13 = r2
    //     0xb154dc: stur            w2, [x0, #0x13]
    // 0xb154e0: SaveReg r0
    //     0xb154e0: str             x0, [SP, #-8]!
    // 0xb154e4: r0 = _interpolate()
    //     0xb154e4: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xb154e8: add             SP, SP, #8
    // 0xb154ec: LeaveFrame
    //     0xb154ec: mov             SP, fp
    //     0xb154f0: ldp             fp, lr, [SP], #0x10
    // 0xb154f4: ret
    //     0xb154f4: ret             
    // 0xb154f8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xb154f8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xb154fc: b               #0xb154b8
  }
}

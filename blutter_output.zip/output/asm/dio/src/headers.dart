// lib: , url: package:dio/src/headers.dart

// class id: 1048889, size: 0x8
class :: {
}

// class id: 4535, size: 0xc, field offset: 0x8
class Headers extends Object {

  Map<String, List<String>> map(Headers) {
    // ** addr: 0xd64bac, size: 0x28
    // 0xd64bac: ldr             x1, [SP]
    // 0xd64bb0: LoadField: r0 = r1->field_7
    //     0xd64bb0: ldur            w0, [x1, #7]
    // 0xd64bb4: DecompressPointer r0
    //     0xd64bb4: add             x0, x0, HEAP, lsl #32
    // 0xd64bb8: ret
    //     0xd64bb8: ret             
  }
  bool isEmpty(Headers) {
    // ** addr: 0x529828, size: 0x68
    // 0x529828: EnterFrame
    //     0x529828: stp             fp, lr, [SP, #-0x10]!
    //     0x52982c: mov             fp, SP
    // 0x529830: CheckStackOverflow
    //     0x529830: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x529834: cmp             SP, x16
    //     0x529838: b.ls            #0x529870
    // 0x52983c: ldr             x0, [fp, #0x10]
    // 0x529840: LoadField: r1 = r0->field_7
    //     0x529840: ldur            w1, [x0, #7]
    // 0x529844: DecompressPointer r1
    //     0x529844: add             x1, x1, HEAP, lsl #32
    // 0x529848: r0 = LoadClassIdInstr(r1)
    //     0x529848: ldur            x0, [x1, #-1]
    //     0x52984c: ubfx            x0, x0, #0xc, #0x14
    // 0x529850: SaveReg r1
    //     0x529850: str             x1, [SP, #-8]!
    // 0x529854: r0 = GDT[cid_x0 + 0x747]()
    //     0x529854: add             lr, x0, #0x747
    //     0x529858: ldr             lr, [x21, lr, lsl #3]
    //     0x52985c: blr             lr
    // 0x529860: add             SP, SP, #8
    // 0x529864: LeaveFrame
    //     0x529864: mov             SP, fp
    //     0x529868: ldp             fp, lr, [SP], #0x10
    // 0x52986c: ret
    //     0x52986c: ret             
    // 0x529870: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529870: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x529874: b               #0x52983c
  }
  _ Headers.fromMap(/* No info */) {
    // ** addr: 0x52948c, size: 0xb0
    // 0x52948c: EnterFrame
    //     0x52948c: stp             fp, lr, [SP, #-0x10]!
    //     0x529490: mov             fp, SP
    // 0x529494: CheckStackOverflow
    //     0x529494: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x529498: cmp             SP, x16
    //     0x52949c: b.ls            #0x529534
    // 0x5294a0: r1 = Function '<anonymous closure>':.
    //     0x5294a0: add             x1, PP, #0x13, lsl #12  ; [pp+0x13008] AnonymousClosure: (0x52a144), in [package:dio/src/headers.dart] Headers::Headers.fromMap (0x52948c)
    //     0x5294a4: ldr             x1, [x1, #8]
    // 0x5294a8: r2 = Null
    //     0x5294a8: mov             x2, NULL
    // 0x5294ac: r0 = AllocateClosure()
    //     0x5294ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5294b0: mov             x1, x0
    // 0x5294b4: ldr             x0, [fp, #0x10]
    // 0x5294b8: r2 = LoadClassIdInstr(r0)
    //     0x5294b8: ldur            x2, [x0, #-1]
    //     0x5294bc: ubfx            x2, x2, #0xc, #0x14
    // 0x5294c0: r16 = <String, List<String>>
    //     0x5294c0: add             x16, PP, #0x13, lsl #12  ; [pp+0x13010] TypeArguments: <String, List<String>>
    //     0x5294c4: ldr             x16, [x16, #0x10]
    // 0x5294c8: stp             x0, x16, [SP, #-0x10]!
    // 0x5294cc: SaveReg r1
    //     0x5294cc: str             x1, [SP, #-8]!
    // 0x5294d0: mov             x0, x2
    // 0x5294d4: r4 = const [0x2, 0x2, 0x2, 0x2, null]
    //     0x5294d4: add             x4, PP, #0xb, lsl #12  ; [pp+0xb4d8] List(5) [0x2, 0x2, 0x2, 0x2, Null]
    //     0x5294d8: ldr             x4, [x4, #0x4d8]
    // 0x5294dc: r0 = GDT[cid_x0 + 0xc7a]()
    //     0x5294dc: add             lr, x0, #0xc7a
    //     0x5294e0: ldr             lr, [x21, lr, lsl #3]
    //     0x5294e4: blr             lr
    // 0x5294e8: add             SP, SP, #0x18
    // 0x5294ec: r16 = <List<String>>
    //     0x5294ec: ldr             x16, [PP, #0x7f58]  ; [pp+0x7f58] TypeArguments: <List<String>>
    // 0x5294f0: stp             x0, x16, [SP, #-0x10]!
    // 0x5294f4: r4 = const [0x1, 0x1, 0x1, 0x1, null]
    //     0x5294f4: ldr             x4, [PP, #0xc30]  ; [pp+0xc30] List(5) [0x1, 0x1, 0x1, 0x1, Null]
    // 0x5294f8: r0 = caseInsensitiveKeyMap()
    //     0x5294f8: bl              #0x529878  ; [package:dio/src/utils.dart] ::caseInsensitiveKeyMap
    // 0x5294fc: add             SP, SP, #0x10
    // 0x529500: ldr             x1, [fp, #0x18]
    // 0x529504: StoreField: r1->field_7 = r0
    //     0x529504: stur            w0, [x1, #7]
    //     0x529508: tbz             w0, #0, #0x529524
    //     0x52950c: ldurb           w16, [x1, #-1]
    //     0x529510: ldurb           w17, [x0, #-1]
    //     0x529514: and             x16, x17, x16, lsr #2
    //     0x529518: tst             x16, HEAP, lsr #32
    //     0x52951c: b.eq            #0x529524
    //     0x529520: bl              #0xd6826c
    // 0x529524: r0 = Null
    //     0x529524: mov             x0, NULL
    // 0x529528: LeaveFrame
    //     0x529528: mov             SP, fp
    //     0x52952c: ldp             fp, lr, [SP], #0x10
    // 0x529530: ret
    //     0x529530: ret             
    // 0x529534: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529534: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x529538: b               #0x5294a0
  }
  void forEach(Headers, (dynamic, String, List<String>) => void) {
    // ** addr: 0x529554, size: 0x74
    // 0x529554: EnterFrame
    //     0x529554: stp             fp, lr, [SP, #-0x10]!
    //     0x529558: mov             fp, SP
    // 0x52955c: CheckStackOverflow
    //     0x52955c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x529560: cmp             SP, x16
    //     0x529564: b.ls            #0x5295a8
    // 0x529568: ldr             x0, [fp, #0x10]
    // 0x52956c: r2 = Null
    //     0x52956c: mov             x2, NULL
    // 0x529570: r1 = Null
    //     0x529570: mov             x1, NULL
    // 0x529574: r8 = (dynamic this, String, List<String>) => void?
    //     0x529574: add             x8, PP, #0x1d, lsl #12  ; [pp+0x1d5a8] FunctionType: (dynamic this, String, List<String>) => void?
    //     0x529578: ldr             x8, [x8, #0x5a8]
    // 0x52957c: r3 = Null
    //     0x52957c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d5b0] Null
    //     0x529580: ldr             x3, [x3, #0x5b0]
    // 0x529584: r0 = DefaultTypeTest()
    //     0x529584: bl              #0xd67ac8  ; DefaultTypeTestStub
    // 0x529588: ldr             x16, [fp, #0x18]
    // 0x52958c: ldr             lr, [fp, #0x10]
    // 0x529590: stp             lr, x16, [SP, #-0x10]!
    // 0x529594: r0 = forEach()
    //     0x529594: bl              #0x5295b0  ; [package:dio/src/headers.dart] Headers::forEach
    // 0x529598: add             SP, SP, #0x10
    // 0x52959c: LeaveFrame
    //     0x52959c: mov             SP, fp
    //     0x5295a0: ldp             fp, lr, [SP], #0x10
    // 0x5295a4: ret
    //     0x5295a4: ret             
    // 0x5295a8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5295a8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5295ac: b               #0x529568
  }
  void forEach(Headers, (dynamic, String, List<String>) => void) {
    // ** addr: 0x5295b0, size: 0x17c
    // 0x5295b0: EnterFrame
    //     0x5295b0: stp             fp, lr, [SP, #-0x10]!
    //     0x5295b4: mov             fp, SP
    // 0x5295b8: AllocStack(0x20)
    //     0x5295b8: sub             SP, SP, #0x20
    // 0x5295bc: CheckStackOverflow
    //     0x5295bc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5295c0: cmp             SP, x16
    //     0x5295c4: b.ls            #0x529718
    // 0x5295c8: ldr             x0, [fp, #0x18]
    // 0x5295cc: LoadField: r1 = r0->field_7
    //     0x5295cc: ldur            w1, [x0, #7]
    // 0x5295d0: DecompressPointer r1
    //     0x5295d0: add             x1, x1, HEAP, lsl #32
    // 0x5295d4: stur            x1, [fp, #-8]
    // 0x5295d8: r0 = LoadClassIdInstr(r1)
    //     0x5295d8: ldur            x0, [x1, #-1]
    //     0x5295dc: ubfx            x0, x0, #0xc, #0x14
    // 0x5295e0: SaveReg r1
    //     0x5295e0: str             x1, [SP, #-8]!
    // 0x5295e4: r0 = GDT[cid_x0 + 0x6d7]()
    //     0x5295e4: add             lr, x0, #0x6d7
    //     0x5295e8: ldr             lr, [x21, lr, lsl #3]
    //     0x5295ec: blr             lr
    // 0x5295f0: add             SP, SP, #8
    // 0x5295f4: SaveReg r0
    //     0x5295f4: str             x0, [SP, #-8]!
    // 0x5295f8: r0 = iterator()
    //     0x5295f8: bl              #0x6fc4a0  ; [dart:collection] _CompactIterable::iterator
    // 0x5295fc: add             SP, SP, #8
    // 0x529600: stur            x0, [fp, #-0x18]
    // 0x529604: LoadField: r2 = r0->field_7
    //     0x529604: ldur            w2, [x0, #7]
    // 0x529608: DecompressPointer r2
    //     0x529608: add             x2, x2, HEAP, lsl #32
    // 0x52960c: stur            x2, [fp, #-0x10]
    // 0x529610: ldur            x1, [fp, #-8]
    // 0x529614: CheckStackOverflow
    //     0x529614: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x529618: cmp             SP, x16
    //     0x52961c: b.ls            #0x529720
    // 0x529620: SaveReg r0
    //     0x529620: str             x0, [SP, #-8]!
    // 0x529624: r0 = moveNext()
    //     0x529624: bl              #0xc3e3e4  ; [dart:collection] _CompactIterator::moveNext
    // 0x529628: add             SP, SP, #8
    // 0x52962c: tbnz            w0, #4, #0x529708
    // 0x529630: ldur            x3, [fp, #-0x18]
    // 0x529634: LoadField: r4 = r3->field_33
    //     0x529634: ldur            w4, [x3, #0x33]
    // 0x529638: DecompressPointer r4
    //     0x529638: add             x4, x4, HEAP, lsl #32
    // 0x52963c: stur            x4, [fp, #-0x20]
    // 0x529640: cmp             w4, NULL
    // 0x529644: b.ne            #0x529678
    // 0x529648: mov             x0, x4
    // 0x52964c: ldur            x2, [fp, #-0x10]
    // 0x529650: r1 = Null
    //     0x529650: mov             x1, NULL
    // 0x529654: cmp             w2, NULL
    // 0x529658: b.eq            #0x529678
    // 0x52965c: LoadField: r4 = r2->field_17
    //     0x52965c: ldur            w4, [x2, #0x17]
    // 0x529660: DecompressPointer r4
    //     0x529660: add             x4, x4, HEAP, lsl #32
    // 0x529664: r8 = X0
    //     0x529664: ldr             x8, [PP, #0x6c0]  ; [pp+0x6c0] TypeParameter: X0
    // 0x529668: LoadField: r9 = r4->field_7
    //     0x529668: ldur            x9, [x4, #7]
    // 0x52966c: r3 = Null
    //     0x52966c: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d5c0] Null
    //     0x529670: ldr             x3, [x3, #0x5c0]
    // 0x529674: blr             x9
    // 0x529678: ldur            x0, [fp, #-8]
    // 0x52967c: ldur            x16, [fp, #-0x20]
    // 0x529680: SaveReg r16
    //     0x529680: str             x16, [SP, #-8]!
    // 0x529684: r0 = trim()
    //     0x529684: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x529688: add             SP, SP, #8
    // 0x52968c: r1 = LoadClassIdInstr(r0)
    //     0x52968c: ldur            x1, [x0, #-1]
    //     0x529690: ubfx            x1, x1, #0xc, #0x14
    // 0x529694: SaveReg r0
    //     0x529694: str             x0, [SP, #-8]!
    // 0x529698: mov             x0, x1
    // 0x52969c: r0 = GDT[cid_x0 + -0xff4]()
    //     0x52969c: sub             lr, x0, #0xff4
    //     0x5296a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5296a4: blr             lr
    // 0x5296a8: add             SP, SP, #8
    // 0x5296ac: ldur            x1, [fp, #-8]
    // 0x5296b0: r2 = LoadClassIdInstr(r1)
    //     0x5296b0: ldur            x2, [x1, #-1]
    //     0x5296b4: ubfx            x2, x2, #0xc, #0x14
    // 0x5296b8: stp             x0, x1, [SP, #-0x10]!
    // 0x5296bc: mov             x0, x2
    // 0x5296c0: r0 = GDT[cid_x0 + -0xef]()
    //     0x5296c0: sub             lr, x0, #0xef
    //     0x5296c4: ldr             lr, [x21, lr, lsl #3]
    //     0x5296c8: blr             lr
    // 0x5296cc: add             SP, SP, #0x10
    // 0x5296d0: cmp             w0, NULL
    // 0x5296d4: b.eq            #0x529728
    // 0x5296d8: ldr             x16, [fp, #0x10]
    // 0x5296dc: ldur            lr, [fp, #-0x20]
    // 0x5296e0: stp             lr, x16, [SP, #-0x10]!
    // 0x5296e4: SaveReg r0
    //     0x5296e4: str             x0, [SP, #-8]!
    // 0x5296e8: ldr             x0, [fp, #0x10]
    // 0x5296ec: ClosureCall
    //     0x5296ec: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    //     0x5296f0: ldur            x2, [x0, #0x1f]
    //     0x5296f4: blr             x2
    // 0x5296f8: add             SP, SP, #0x18
    // 0x5296fc: ldur            x0, [fp, #-0x18]
    // 0x529700: ldur            x2, [fp, #-0x10]
    // 0x529704: b               #0x529610
    // 0x529708: r0 = Null
    //     0x529708: mov             x0, NULL
    // 0x52970c: LeaveFrame
    //     0x52970c: mov             SP, fp
    //     0x529710: ldp             fp, lr, [SP], #0x10
    // 0x529714: ret
    //     0x529714: ret             
    // 0x529718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52971c: b               #0x5295c8
    // 0x529720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529720: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x529724: b               #0x529620
    // 0x529728: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x529728: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  List<String>? [](Headers, String) {
    // ** addr: 0x529744, size: 0xe4
    // 0x529744: EnterFrame
    //     0x529744: stp             fp, lr, [SP, #-0x10]!
    //     0x529748: mov             fp, SP
    // 0x52974c: AllocStack(0x8)
    //     0x52974c: sub             SP, SP, #8
    // 0x529750: CheckStackOverflow
    //     0x529750: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x529754: cmp             SP, x16
    //     0x529758: b.ls            #0x529808
    // 0x52975c: ldr             x0, [fp, #0x10]
    // 0x529760: r2 = Null
    //     0x529760: mov             x2, NULL
    // 0x529764: r1 = Null
    //     0x529764: mov             x1, NULL
    // 0x529768: r4 = 59
    //     0x529768: mov             x4, #0x3b
    // 0x52976c: branchIfSmi(r0, 0x529778)
    //     0x52976c: tbz             w0, #0, #0x529778
    // 0x529770: r4 = LoadClassIdInstr(r0)
    //     0x529770: ldur            x4, [x0, #-1]
    //     0x529774: ubfx            x4, x4, #0xc, #0x14
    // 0x529778: sub             x4, x4, #0x5d
    // 0x52977c: cmp             x4, #3
    // 0x529780: b.ls            #0x529794
    // 0x529784: r8 = String
    //     0x529784: ldr             x8, [PP, #0x290]  ; [pp+0x290] Type: String
    // 0x529788: r3 = Null
    //     0x529788: add             x3, PP, #0x1d, lsl #12  ; [pp+0x1d5d0] Null
    //     0x52978c: ldr             x3, [x3, #0x5d0]
    // 0x529790: r0 = String()
    //     0x529790: bl              #0xd72afc  ; IsType_String_Stub
    // 0x529794: ldr             x0, [fp, #0x18]
    // 0x529798: LoadField: r1 = r0->field_7
    //     0x529798: ldur            w1, [x0, #7]
    // 0x52979c: DecompressPointer r1
    //     0x52979c: add             x1, x1, HEAP, lsl #32
    // 0x5297a0: stur            x1, [fp, #-8]
    // 0x5297a4: ldr             x16, [fp, #0x10]
    // 0x5297a8: SaveReg r16
    //     0x5297a8: str             x16, [SP, #-8]!
    // 0x5297ac: r0 = trim()
    //     0x5297ac: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x5297b0: add             SP, SP, #8
    // 0x5297b4: r1 = LoadClassIdInstr(r0)
    //     0x5297b4: ldur            x1, [x0, #-1]
    //     0x5297b8: ubfx            x1, x1, #0xc, #0x14
    // 0x5297bc: SaveReg r0
    //     0x5297bc: str             x0, [SP, #-8]!
    // 0x5297c0: mov             x0, x1
    // 0x5297c4: r0 = GDT[cid_x0 + -0xff4]()
    //     0x5297c4: sub             lr, x0, #0xff4
    //     0x5297c8: ldr             lr, [x21, lr, lsl #3]
    //     0x5297cc: blr             lr
    // 0x5297d0: add             SP, SP, #8
    // 0x5297d4: mov             x1, x0
    // 0x5297d8: ldur            x0, [fp, #-8]
    // 0x5297dc: r2 = LoadClassIdInstr(r0)
    //     0x5297dc: ldur            x2, [x0, #-1]
    //     0x5297e0: ubfx            x2, x2, #0xc, #0x14
    // 0x5297e4: stp             x1, x0, [SP, #-0x10]!
    // 0x5297e8: mov             x0, x2
    // 0x5297ec: r0 = GDT[cid_x0 + -0xef]()
    //     0x5297ec: sub             lr, x0, #0xef
    //     0x5297f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5297f4: blr             lr
    // 0x5297f8: add             SP, SP, #0x10
    // 0x5297fc: LeaveFrame
    //     0x5297fc: mov             SP, fp
    //     0x529800: ldp             fp, lr, [SP], #0x10
    // 0x529804: ret
    //     0x529804: ret             
    // 0x529808: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x529808: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52980c: b               #0x52975c
  }
  [closure] MapEntry<String, List<String>> <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x52a144, size: 0x7c
    // 0x52a144: EnterFrame
    //     0x52a144: stp             fp, lr, [SP, #-0x10]!
    //     0x52a148: mov             fp, SP
    // 0x52a14c: AllocStack(0x8)
    //     0x52a14c: sub             SP, SP, #8
    // 0x52a150: CheckStackOverflow
    //     0x52a150: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52a154: cmp             SP, x16
    //     0x52a158: b.ls            #0x52a1b8
    // 0x52a15c: ldr             x16, [fp, #0x18]
    // 0x52a160: SaveReg r16
    //     0x52a160: str             x16, [SP, #-8]!
    // 0x52a164: r0 = trim()
    //     0x52a164: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x52a168: add             SP, SP, #8
    // 0x52a16c: r1 = LoadClassIdInstr(r0)
    //     0x52a16c: ldur            x1, [x0, #-1]
    //     0x52a170: ubfx            x1, x1, #0xc, #0x14
    // 0x52a174: SaveReg r0
    //     0x52a174: str             x0, [SP, #-8]!
    // 0x52a178: mov             x0, x1
    // 0x52a17c: r0 = GDT[cid_x0 + -0xff4]()
    //     0x52a17c: sub             lr, x0, #0xff4
    //     0x52a180: ldr             lr, [x21, lr, lsl #3]
    //     0x52a184: blr             lr
    // 0x52a188: add             SP, SP, #8
    // 0x52a18c: r1 = <String, List<String>>
    //     0x52a18c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13010] TypeArguments: <String, List<String>>
    //     0x52a190: ldr             x1, [x1, #0x10]
    // 0x52a194: stur            x0, [fp, #-8]
    // 0x52a198: r0 = MapEntry()
    //     0x52a198: bl              #0x52a1c0  ; AllocateMapEntryStub -> MapEntry<X0, X1> (size=0x14)
    // 0x52a19c: ldur            x1, [fp, #-8]
    // 0x52a1a0: StoreField: r0->field_b = r1
    //     0x52a1a0: stur            w1, [x0, #0xb]
    // 0x52a1a4: ldr             x1, [fp, #0x10]
    // 0x52a1a8: StoreField: r0->field_f = r1
    //     0x52a1a8: stur            w1, [x0, #0xf]
    // 0x52a1ac: LeaveFrame
    //     0x52a1ac: mov             SP, fp
    //     0x52a1b0: ldp             fp, lr, [SP], #0x10
    // 0x52a1b4: ret
    //     0x52a1b4: ret             
    // 0x52a1b8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52a1b8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52a1bc: b               #0x52a15c
  }
  _ value(/* No info */) {
    // ** addr: 0x966a28, size: 0x168
    // 0x966a28: EnterFrame
    //     0x966a28: stp             fp, lr, [SP, #-0x10]!
    //     0x966a2c: mov             fp, SP
    // 0x966a30: AllocStack(0x8)
    //     0x966a30: sub             SP, SP, #8
    // 0x966a34: CheckStackOverflow
    //     0x966a34: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966a38: cmp             SP, x16
    //     0x966a3c: b.ls            #0x966b88
    // 0x966a40: ldr             x0, [fp, #0x18]
    // 0x966a44: LoadField: r1 = r0->field_7
    //     0x966a44: ldur            w1, [x0, #7]
    // 0x966a48: DecompressPointer r1
    //     0x966a48: add             x1, x1, HEAP, lsl #32
    // 0x966a4c: stur            x1, [fp, #-8]
    // 0x966a50: ldr             x16, [fp, #0x10]
    // 0x966a54: SaveReg r16
    //     0x966a54: str             x16, [SP, #-8]!
    // 0x966a58: r0 = trim()
    //     0x966a58: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x966a5c: add             SP, SP, #8
    // 0x966a60: r1 = LoadClassIdInstr(r0)
    //     0x966a60: ldur            x1, [x0, #-1]
    //     0x966a64: ubfx            x1, x1, #0xc, #0x14
    // 0x966a68: SaveReg r0
    //     0x966a68: str             x0, [SP, #-8]!
    // 0x966a6c: mov             x0, x1
    // 0x966a70: r0 = GDT[cid_x0 + -0xff4]()
    //     0x966a70: sub             lr, x0, #0xff4
    //     0x966a74: ldr             lr, [x21, lr, lsl #3]
    //     0x966a78: blr             lr
    // 0x966a7c: add             SP, SP, #8
    // 0x966a80: mov             x1, x0
    // 0x966a84: ldur            x0, [fp, #-8]
    // 0x966a88: r2 = LoadClassIdInstr(r0)
    //     0x966a88: ldur            x2, [x0, #-1]
    //     0x966a8c: ubfx            x2, x2, #0xc, #0x14
    // 0x966a90: stp             x1, x0, [SP, #-0x10]!
    // 0x966a94: mov             x0, x2
    // 0x966a98: r0 = GDT[cid_x0 + -0xef]()
    //     0x966a98: sub             lr, x0, #0xef
    //     0x966a9c: ldr             lr, [x21, lr, lsl #3]
    //     0x966aa0: blr             lr
    // 0x966aa4: add             SP, SP, #0x10
    // 0x966aa8: mov             x1, x0
    // 0x966aac: stur            x1, [fp, #-8]
    // 0x966ab0: cmp             w1, NULL
    // 0x966ab4: b.ne            #0x966ac8
    // 0x966ab8: r0 = Null
    //     0x966ab8: mov             x0, NULL
    // 0x966abc: LeaveFrame
    //     0x966abc: mov             SP, fp
    //     0x966ac0: ldp             fp, lr, [SP], #0x10
    // 0x966ac4: ret
    //     0x966ac4: ret             
    // 0x966ac8: r0 = LoadClassIdInstr(r1)
    //     0x966ac8: ldur            x0, [x1, #-1]
    //     0x966acc: ubfx            x0, x0, #0xc, #0x14
    // 0x966ad0: SaveReg r1
    //     0x966ad0: str             x1, [SP, #-8]!
    // 0x966ad4: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x966ad4: mov             x17, #0xb8ea
    //     0x966ad8: add             lr, x0, x17
    //     0x966adc: ldr             lr, [x21, lr, lsl #3]
    //     0x966ae0: blr             lr
    // 0x966ae4: add             SP, SP, #8
    // 0x966ae8: r1 = LoadInt32Instr(r0)
    //     0x966ae8: sbfx            x1, x0, #1, #0x1f
    //     0x966aec: tbz             w0, #0, #0x966af4
    //     0x966af0: ldur            x1, [x0, #7]
    // 0x966af4: cmp             x1, #1
    // 0x966af8: b.ne            #0x966b30
    // 0x966afc: ldur            x0, [fp, #-8]
    // 0x966b00: r1 = LoadClassIdInstr(r0)
    //     0x966b00: ldur            x1, [x0, #-1]
    //     0x966b04: ubfx            x1, x1, #0xc, #0x14
    // 0x966b08: SaveReg r0
    //     0x966b08: str             x0, [SP, #-8]!
    // 0x966b0c: mov             x0, x1
    // 0x966b10: r0 = GDT[cid_x0 + 0xcaae]()
    //     0x966b10: mov             x17, #0xcaae
    //     0x966b14: add             lr, x0, x17
    //     0x966b18: ldr             lr, [x21, lr, lsl #3]
    //     0x966b1c: blr             lr
    // 0x966b20: add             SP, SP, #8
    // 0x966b24: LeaveFrame
    //     0x966b24: mov             SP, fp
    //     0x966b28: ldp             fp, lr, [SP], #0x10
    // 0x966b2c: ret
    //     0x966b2c: ret             
    // 0x966b30: ldr             x0, [fp, #0x10]
    // 0x966b34: r1 = Null
    //     0x966b34: mov             x1, NULL
    // 0x966b38: r2 = 6
    //     0x966b38: mov             x2, #6
    // 0x966b3c: r0 = AllocateArray()
    //     0x966b3c: bl              #0xd6987c  ; AllocateArrayStub
    // 0x966b40: r17 = "\""
    //     0x966b40: ldr             x17, [PP, #0xe60]  ; [pp+0xe60] "\""
    // 0x966b44: StoreField: r0->field_f = r17
    //     0x966b44: stur            w17, [x0, #0xf]
    // 0x966b48: ldr             x1, [fp, #0x10]
    // 0x966b4c: StoreField: r0->field_13 = r1
    //     0x966b4c: stur            w1, [x0, #0x13]
    // 0x966b50: r17 = "\" header has more than one value, please use Headers[name]"
    //     0x966b50: add             x17, PP, #0x30, lsl #12  ; [pp+0x30180] "\" header has more than one value, please use Headers[name]"
    //     0x966b54: ldr             x17, [x17, #0x180]
    // 0x966b58: StoreField: r0->field_17 = r17
    //     0x966b58: stur            w17, [x0, #0x17]
    // 0x966b5c: SaveReg r0
    //     0x966b5c: str             x0, [SP, #-8]!
    // 0x966b60: r0 = _interpolate()
    //     0x966b60: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x966b64: add             SP, SP, #8
    // 0x966b68: stur            x0, [fp, #-8]
    // 0x966b6c: r0 = _Exception()
    //     0x966b6c: bl              #0x4eda04  ; Allocate_ExceptionStub -> _Exception (size=0xc)
    // 0x966b70: mov             x1, x0
    // 0x966b74: ldur            x0, [fp, #-8]
    // 0x966b78: StoreField: r1->field_7 = r0
    //     0x966b78: stur            w0, [x1, #7]
    // 0x966b7c: mov             x0, x1
    // 0x966b80: r0 = Throw()
    //     0x966b80: bl              #0xd67e38  ; ThrowStub
    // 0x966b84: brk             #0
    // 0x966b88: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x966b88: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x966b8c: b               #0x966a40
  }
  _ add(/* No info */) {
    // ** addr: 0x966c40, size: 0xf8
    // 0x966c40: EnterFrame
    //     0x966c40: stp             fp, lr, [SP, #-0x10]!
    //     0x966c44: mov             fp, SP
    // 0x966c48: AllocStack(0x8)
    //     0x966c48: sub             SP, SP, #8
    // 0x966c4c: CheckStackOverflow
    //     0x966c4c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966c50: cmp             SP, x16
    //     0x966c54: b.ls            #0x966d30
    // 0x966c58: ldr             x0, [fp, #0x20]
    // 0x966c5c: LoadField: r1 = r0->field_7
    //     0x966c5c: ldur            w1, [x0, #7]
    // 0x966c60: DecompressPointer r1
    //     0x966c60: add             x1, x1, HEAP, lsl #32
    // 0x966c64: stur            x1, [fp, #-8]
    // 0x966c68: ldr             x16, [fp, #0x18]
    // 0x966c6c: SaveReg r16
    //     0x966c6c: str             x16, [SP, #-8]!
    // 0x966c70: r0 = trim()
    //     0x966c70: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x966c74: add             SP, SP, #8
    // 0x966c78: r1 = LoadClassIdInstr(r0)
    //     0x966c78: ldur            x1, [x0, #-1]
    //     0x966c7c: ubfx            x1, x1, #0xc, #0x14
    // 0x966c80: SaveReg r0
    //     0x966c80: str             x0, [SP, #-8]!
    // 0x966c84: mov             x0, x1
    // 0x966c88: r0 = GDT[cid_x0 + -0xff4]()
    //     0x966c88: sub             lr, x0, #0xff4
    //     0x966c8c: ldr             lr, [x21, lr, lsl #3]
    //     0x966c90: blr             lr
    // 0x966c94: add             SP, SP, #8
    // 0x966c98: mov             x1, x0
    // 0x966c9c: ldur            x0, [fp, #-8]
    // 0x966ca0: r2 = LoadClassIdInstr(r0)
    //     0x966ca0: ldur            x2, [x0, #-1]
    //     0x966ca4: ubfx            x2, x2, #0xc, #0x14
    // 0x966ca8: stp             x1, x0, [SP, #-0x10]!
    // 0x966cac: mov             x0, x2
    // 0x966cb0: r0 = GDT[cid_x0 + -0xef]()
    //     0x966cb0: sub             lr, x0, #0xef
    //     0x966cb4: ldr             lr, [x21, lr, lsl #3]
    //     0x966cb8: blr             lr
    // 0x966cbc: add             SP, SP, #0x10
    // 0x966cc0: cmp             w0, NULL
    // 0x966cc4: b.ne            #0x966cf4
    // 0x966cc8: ldr             x16, [fp, #0x20]
    // 0x966ccc: ldr             lr, [fp, #0x18]
    // 0x966cd0: stp             lr, x16, [SP, #-0x10]!
    // 0x966cd4: ldr             x16, [fp, #0x10]
    // 0x966cd8: SaveReg r16
    //     0x966cd8: str             x16, [SP, #-8]!
    // 0x966cdc: r0 = set()
    //     0x966cdc: bl              #0x966d38  ; [package:dio/src/headers.dart] Headers::set
    // 0x966ce0: add             SP, SP, #0x18
    // 0x966ce4: r0 = Null
    //     0x966ce4: mov             x0, NULL
    // 0x966ce8: LeaveFrame
    //     0x966ce8: mov             SP, fp
    //     0x966cec: ldp             fp, lr, [SP], #0x10
    // 0x966cf0: ret
    //     0x966cf0: ret             
    // 0x966cf4: r1 = LoadClassIdInstr(r0)
    //     0x966cf4: ldur            x1, [x0, #-1]
    //     0x966cf8: ubfx            x1, x1, #0xc, #0x14
    // 0x966cfc: ldr             x16, [fp, #0x10]
    // 0x966d00: stp             x16, x0, [SP, #-0x10]!
    // 0x966d04: mov             x0, x1
    // 0x966d08: r0 = GDT[cid_x0 + 0x101bb]()
    //     0x966d08: mov             x17, #0x1bb
    //     0x966d0c: movk            x17, #1, lsl #16
    //     0x966d10: add             lr, x0, x17
    //     0x966d14: ldr             lr, [x21, lr, lsl #3]
    //     0x966d18: blr             lr
    // 0x966d1c: add             SP, SP, #0x10
    // 0x966d20: r0 = Null
    //     0x966d20: mov             x0, NULL
    // 0x966d24: LeaveFrame
    //     0x966d24: mov             SP, fp
    //     0x966d28: ldp             fp, lr, [SP], #0x10
    // 0x966d2c: ret
    //     0x966d2c: ret             
    // 0x966d30: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x966d30: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x966d34: b               #0x966c58
  }
  _ set(/* No info */) {
    // ** addr: 0x966d38, size: 0xfc
    // 0x966d38: EnterFrame
    //     0x966d38: stp             fp, lr, [SP, #-0x10]!
    //     0x966d3c: mov             fp, SP
    // 0x966d40: AllocStack(0x20)
    //     0x966d40: sub             SP, SP, #0x20
    // 0x966d44: CheckStackOverflow
    //     0x966d44: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x966d48: cmp             SP, x16
    //     0x966d4c: b.ls            #0x966e2c
    // 0x966d50: ldr             x16, [fp, #0x18]
    // 0x966d54: SaveReg r16
    //     0x966d54: str             x16, [SP, #-8]!
    // 0x966d58: r0 = trim()
    //     0x966d58: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x966d5c: add             SP, SP, #8
    // 0x966d60: r1 = LoadClassIdInstr(r0)
    //     0x966d60: ldur            x1, [x0, #-1]
    //     0x966d64: ubfx            x1, x1, #0xc, #0x14
    // 0x966d68: SaveReg r0
    //     0x966d68: str             x0, [SP, #-8]!
    // 0x966d6c: mov             x0, x1
    // 0x966d70: r0 = GDT[cid_x0 + -0xff4]()
    //     0x966d70: sub             lr, x0, #0xff4
    //     0x966d74: ldr             lr, [x21, lr, lsl #3]
    //     0x966d78: blr             lr
    // 0x966d7c: add             SP, SP, #8
    // 0x966d80: mov             x1, x0
    // 0x966d84: ldr             x0, [fp, #0x20]
    // 0x966d88: stur            x1, [fp, #-0x10]
    // 0x966d8c: LoadField: r2 = r0->field_7
    //     0x966d8c: ldur            w2, [x0, #7]
    // 0x966d90: DecompressPointer r2
    //     0x966d90: add             x2, x2, HEAP, lsl #32
    // 0x966d94: stur            x2, [fp, #-8]
    // 0x966d98: ldr             x16, [fp, #0x10]
    // 0x966d9c: SaveReg r16
    //     0x966d9c: str             x16, [SP, #-8]!
    // 0x966da0: r0 = _interpolateSingle()
    //     0x966da0: bl              #0x4bdd98  ; [dart:core] _StringBase::_interpolateSingle
    // 0x966da4: add             SP, SP, #8
    // 0x966da8: SaveReg r0
    //     0x966da8: str             x0, [SP, #-8]!
    // 0x966dac: r0 = trim()
    //     0x966dac: bl              #0x4f0838  ; [dart:core] _StringBase::trim
    // 0x966db0: add             SP, SP, #8
    // 0x966db4: r1 = Null
    //     0x966db4: mov             x1, NULL
    // 0x966db8: r2 = 2
    //     0x966db8: mov             x2, #2
    // 0x966dbc: stur            x0, [fp, #-0x18]
    // 0x966dc0: r0 = AllocateArray()
    //     0x966dc0: bl              #0xd6987c  ; AllocateArrayStub
    // 0x966dc4: mov             x2, x0
    // 0x966dc8: ldur            x0, [fp, #-0x18]
    // 0x966dcc: stur            x2, [fp, #-0x20]
    // 0x966dd0: StoreField: r2->field_f = r0
    //     0x966dd0: stur            w0, [x2, #0xf]
    // 0x966dd4: r1 = <String>
    //     0x966dd4: ldr             x1, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    // 0x966dd8: r0 = AllocateGrowableArray()
    //     0x966dd8: bl              #0xd68a68  ; AllocateGrowableArrayStub
    // 0x966ddc: mov             x1, x0
    // 0x966de0: ldur            x0, [fp, #-0x20]
    // 0x966de4: StoreField: r1->field_f = r0
    //     0x966de4: stur            w0, [x1, #0xf]
    // 0x966de8: r0 = 2
    //     0x966de8: mov             x0, #2
    // 0x966dec: StoreField: r1->field_b = r0
    //     0x966dec: stur            w0, [x1, #0xb]
    // 0x966df0: ldur            x0, [fp, #-8]
    // 0x966df4: r2 = LoadClassIdInstr(r0)
    //     0x966df4: ldur            x2, [x0, #-1]
    //     0x966df8: ubfx            x2, x2, #0xc, #0x14
    // 0x966dfc: ldur            x16, [fp, #-0x10]
    // 0x966e00: stp             x16, x0, [SP, #-0x10]!
    // 0x966e04: SaveReg r1
    //     0x966e04: str             x1, [SP, #-8]!
    // 0x966e08: mov             x0, x2
    // 0x966e0c: r0 = GDT[cid_x0 + 0x35a]()
    //     0x966e0c: add             lr, x0, #0x35a
    //     0x966e10: ldr             lr, [x21, lr, lsl #3]
    //     0x966e14: blr             lr
    // 0x966e18: add             SP, SP, #0x18
    // 0x966e1c: r0 = Null
    //     0x966e1c: mov             x0, NULL
    // 0x966e20: LeaveFrame
    //     0x966e20: mov             SP, fp
    //     0x966e24: ldp             fp, lr, [SP], #0x10
    // 0x966e28: ret
    //     0x966e28: ret             
    // 0x966e2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x966e2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x966e30: b               #0x966d50
  }
  _ toString(/* No info */) {
    // ** addr: 0xad3678, size: 0xb0
    // 0xad3678: EnterFrame
    //     0xad3678: stp             fp, lr, [SP, #-0x10]!
    //     0xad367c: mov             fp, SP
    // 0xad3680: AllocStack(0x10)
    //     0xad3680: sub             SP, SP, #0x10
    // 0xad3684: CheckStackOverflow
    //     0xad3684: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3688: cmp             SP, x16
    //     0xad368c: b.ls            #0xad3720
    // 0xad3690: r0 = StringBuffer()
    //     0xad3690: bl              #0x4d1e30  ; AllocateStringBufferStub -> StringBuffer (size=0x38)
    // 0xad3694: stur            x0, [fp, #-8]
    // 0xad3698: SaveReg r0
    //     0xad3698: str             x0, [SP, #-8]!
    // 0xad369c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0xad369c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0xad36a0: r0 = StringBuffer()
    //     0xad36a0: bl              #0x4d16e0  ; [dart:core] StringBuffer::StringBuffer
    // 0xad36a4: add             SP, SP, #8
    // 0xad36a8: r1 = 1
    //     0xad36a8: mov             x1, #1
    // 0xad36ac: r0 = AllocateContext()
    //     0xad36ac: bl              #0xd68aa4  ; AllocateContextStub
    // 0xad36b0: mov             x1, x0
    // 0xad36b4: ldur            x0, [fp, #-8]
    // 0xad36b8: StoreField: r1->field_f = r0
    //     0xad36b8: stur            w0, [x1, #0xf]
    // 0xad36bc: ldr             x2, [fp, #0x10]
    // 0xad36c0: LoadField: r3 = r2->field_7
    //     0xad36c0: ldur            w3, [x2, #7]
    // 0xad36c4: DecompressPointer r3
    //     0xad36c4: add             x3, x3, HEAP, lsl #32
    // 0xad36c8: mov             x2, x1
    // 0xad36cc: stur            x3, [fp, #-0x10]
    // 0xad36d0: r1 = Function '<anonymous closure>':.
    //     0xad36d0: add             x1, PP, #0x1d, lsl #12  ; [pp+0x1d5a0] AnonymousClosure: (0xad3728), in [package:dio/src/headers.dart] Headers::toString (0xad3678)
    //     0xad36d4: ldr             x1, [x1, #0x5a0]
    // 0xad36d8: r0 = AllocateClosure()
    //     0xad36d8: bl              #0xd68bbc  ; AllocateClosureStub
    // 0xad36dc: mov             x1, x0
    // 0xad36e0: ldur            x0, [fp, #-0x10]
    // 0xad36e4: r2 = LoadClassIdInstr(r0)
    //     0xad36e4: ldur            x2, [x0, #-1]
    //     0xad36e8: ubfx            x2, x2, #0xc, #0x14
    // 0xad36ec: stp             x1, x0, [SP, #-0x10]!
    // 0xad36f0: mov             x0, x2
    // 0xad36f4: r0 = GDT[cid_x0 + 0x66b]()
    //     0xad36f4: add             lr, x0, #0x66b
    //     0xad36f8: ldr             lr, [x21, lr, lsl #3]
    //     0xad36fc: blr             lr
    // 0xad3700: add             SP, SP, #0x10
    // 0xad3704: ldur            x16, [fp, #-8]
    // 0xad3708: SaveReg r16
    //     0xad3708: str             x16, [SP, #-8]!
    // 0xad370c: r0 = toString()
    //     0xad370c: bl              #0xaba59c  ; [dart:core] StringBuffer::toString
    // 0xad3710: add             SP, SP, #8
    // 0xad3714: LeaveFrame
    //     0xad3714: mov             SP, fp
    //     0xad3718: ldp             fp, lr, [SP], #0x10
    // 0xad371c: ret
    //     0xad371c: ret             
    // 0xad3720: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3720: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3724: b               #0xad3690
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0xad3728, size: 0x144
    // 0xad3728: EnterFrame
    //     0xad3728: stp             fp, lr, [SP, #-0x10]!
    //     0xad372c: mov             fp, SP
    // 0xad3730: AllocStack(0x18)
    //     0xad3730: sub             SP, SP, #0x18
    // 0xad3734: SetupParameters()
    //     0xad3734: ldr             x0, [fp, #0x20]
    //     0xad3738: ldur            w1, [x0, #0x17]
    //     0xad373c: add             x1, x1, HEAP, lsl #32
    //     0xad3740: stur            x1, [fp, #-8]
    // 0xad3744: CheckStackOverflow
    //     0xad3744: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3748: cmp             SP, x16
    //     0xad374c: b.ls            #0xad385c
    // 0xad3750: ldr             x0, [fp, #0x10]
    // 0xad3754: r2 = LoadClassIdInstr(r0)
    //     0xad3754: ldur            x2, [x0, #-1]
    //     0xad3758: ubfx            x2, x2, #0xc, #0x14
    // 0xad375c: SaveReg r0
    //     0xad375c: str             x0, [SP, #-8]!
    // 0xad3760: mov             x0, x2
    // 0xad3764: r0 = GDT[cid_x0 + 0xb940]()
    //     0xad3764: mov             x17, #0xb940
    //     0xad3768: add             lr, x0, x17
    //     0xad376c: ldr             lr, [x21, lr, lsl #3]
    //     0xad3770: blr             lr
    // 0xad3774: add             SP, SP, #8
    // 0xad3778: mov             x1, x0
    // 0xad377c: ldur            x0, [fp, #-8]
    // 0xad3780: stur            x1, [fp, #-0x18]
    // 0xad3784: LoadField: r2 = r0->field_f
    //     0xad3784: ldur            w2, [x0, #0xf]
    // 0xad3788: DecompressPointer r2
    //     0xad3788: add             x2, x2, HEAP, lsl #32
    // 0xad378c: stur            x2, [fp, #-0x10]
    // 0xad3790: ldr             x3, [fp, #0x18]
    // 0xad3794: CheckStackOverflow
    //     0xad3794: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xad3798: cmp             SP, x16
    //     0xad379c: b.ls            #0xad3864
    // 0xad37a0: r0 = LoadClassIdInstr(r1)
    //     0xad37a0: ldur            x0, [x1, #-1]
    //     0xad37a4: ubfx            x0, x0, #0xc, #0x14
    // 0xad37a8: SaveReg r1
    //     0xad37a8: str             x1, [SP, #-8]!
    // 0xad37ac: r0 = GDT[cid_x0 + 0x541]()
    //     0xad37ac: add             lr, x0, #0x541
    //     0xad37b0: ldr             lr, [x21, lr, lsl #3]
    //     0xad37b4: blr             lr
    // 0xad37b8: add             SP, SP, #8
    // 0xad37bc: tbnz            w0, #4, #0xad384c
    // 0xad37c0: ldr             x2, [fp, #0x18]
    // 0xad37c4: ldur            x1, [fp, #-0x18]
    // 0xad37c8: r0 = LoadClassIdInstr(r1)
    //     0xad37c8: ldur            x0, [x1, #-1]
    //     0xad37cc: ubfx            x0, x0, #0xc, #0x14
    // 0xad37d0: SaveReg r1
    //     0xad37d0: str             x1, [SP, #-8]!
    // 0xad37d4: r0 = GDT[cid_x0 + 0x5ca]()
    //     0xad37d4: add             lr, x0, #0x5ca
    //     0xad37d8: ldr             lr, [x21, lr, lsl #3]
    //     0xad37dc: blr             lr
    // 0xad37e0: add             SP, SP, #8
    // 0xad37e4: r1 = Null
    //     0xad37e4: mov             x1, NULL
    // 0xad37e8: r2 = 6
    //     0xad37e8: mov             x2, #6
    // 0xad37ec: stur            x0, [fp, #-8]
    // 0xad37f0: r0 = AllocateArray()
    //     0xad37f0: bl              #0xd6987c  ; AllocateArrayStub
    // 0xad37f4: mov             x1, x0
    // 0xad37f8: ldr             x0, [fp, #0x18]
    // 0xad37fc: StoreField: r1->field_f = r0
    //     0xad37fc: stur            w0, [x1, #0xf]
    // 0xad3800: r17 = ": "
    //     0xad3800: ldr             x17, [PP, #0xf48]  ; [pp+0xf48] ": "
    // 0xad3804: StoreField: r1->field_13 = r17
    //     0xad3804: stur            w17, [x1, #0x13]
    // 0xad3808: ldur            x2, [fp, #-8]
    // 0xad380c: StoreField: r1->field_17 = r2
    //     0xad380c: stur            w2, [x1, #0x17]
    // 0xad3810: SaveReg r1
    //     0xad3810: str             x1, [SP, #-8]!
    // 0xad3814: r0 = _interpolate()
    //     0xad3814: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0xad3818: add             SP, SP, #8
    // 0xad381c: ldur            x16, [fp, #-0x10]
    // 0xad3820: stp             x0, x16, [SP, #-0x10]!
    // 0xad3824: r0 = write()
    //     0xad3824: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad3828: add             SP, SP, #0x10
    // 0xad382c: ldur            x16, [fp, #-0x10]
    // 0xad3830: r30 = "\n"
    //     0xad3830: ldr             lr, [PP, #0xf38]  ; [pp+0xf38] "\n"
    // 0xad3834: stp             lr, x16, [SP, #-0x10]!
    // 0xad3838: r0 = write()
    //     0xad3838: bl              #0xc04ea4  ; [dart:core] StringBuffer::write
    // 0xad383c: add             SP, SP, #0x10
    // 0xad3840: ldur            x1, [fp, #-0x18]
    // 0xad3844: ldur            x2, [fp, #-0x10]
    // 0xad3848: b               #0xad3790
    // 0xad384c: r0 = Null
    //     0xad384c: mov             x0, NULL
    // 0xad3850: LeaveFrame
    //     0xad3850: mov             SP, fp
    //     0xad3854: ldp             fp, lr, [SP], #0x10
    // 0xad3858: ret
    //     0xad3858: ret             
    // 0xad385c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad385c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3860: b               #0xad3750
    // 0xad3864: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xad3864: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xad3868: b               #0xad37a0
  }
}

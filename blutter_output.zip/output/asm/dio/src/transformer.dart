// lib: , url: package:dio/src/transformer.dart

// class id: 1048899, size: 0x8
class :: {
}

// class id: 4523, size: 0x8, field offset: 0x8
abstract class Transformer extends Object {

  static _ isJsonMimeType(/* No info */) {
    // ** addr: 0x52b6c0, size: 0x12c
    // 0x52b6c0: EnterFrame
    //     0x52b6c0: stp             fp, lr, [SP, #-0x10]!
    //     0x52b6c4: mov             fp, SP
    // 0x52b6c8: AllocStack(0x10)
    //     0x52b6c8: sub             SP, SP, #0x10
    // 0x52b6cc: CheckStackOverflow
    //     0x52b6cc: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52b6d0: cmp             SP, x16
    //     0x52b6d4: b.ls            #0x52b7e4
    // 0x52b6d8: ldr             x0, [fp, #0x10]
    // 0x52b6dc: cmp             w0, NULL
    // 0x52b6e0: b.ne            #0x52b6f4
    // 0x52b6e4: r0 = false
    //     0x52b6e4: add             x0, NULL, #0x30  ; false
    // 0x52b6e8: LeaveFrame
    //     0x52b6e8: mov             SP, fp
    //     0x52b6ec: ldp             fp, lr, [SP], #0x10
    // 0x52b6f0: ret
    //     0x52b6f0: ret             
    // 0x52b6f4: stp             x0, NULL, [SP, #-0x10]!
    // 0x52b6f8: r0 = MediaType.parse()
    //     0x52b6f8: bl              #0x52b8c4  ; [package:http_parser/src/media_type.dart] MediaType::MediaType.parse
    // 0x52b6fc: add             SP, SP, #0x10
    // 0x52b700: stur            x0, [fp, #-0x10]
    // 0x52b704: LoadField: r3 = r0->field_7
    //     0x52b704: ldur            w3, [x0, #7]
    // 0x52b708: DecompressPointer r3
    //     0x52b708: add             x3, x3, HEAP, lsl #32
    // 0x52b70c: stur            x3, [fp, #-8]
    // 0x52b710: r1 = Null
    //     0x52b710: mov             x1, NULL
    // 0x52b714: r2 = 6
    //     0x52b714: mov             x2, #6
    // 0x52b718: r0 = AllocateArray()
    //     0x52b718: bl              #0xd6987c  ; AllocateArrayStub
    // 0x52b71c: mov             x1, x0
    // 0x52b720: ldur            x0, [fp, #-8]
    // 0x52b724: StoreField: r1->field_f = r0
    //     0x52b724: stur            w0, [x1, #0xf]
    // 0x52b728: r17 = "/"
    //     0x52b728: ldr             x17, [PP, #0x768]  ; [pp+0x768] "/"
    // 0x52b72c: StoreField: r1->field_13 = r17
    //     0x52b72c: stur            w17, [x1, #0x13]
    // 0x52b730: ldur            x0, [fp, #-0x10]
    // 0x52b734: LoadField: r2 = r0->field_b
    //     0x52b734: ldur            w2, [x0, #0xb]
    // 0x52b738: DecompressPointer r2
    //     0x52b738: add             x2, x2, HEAP, lsl #32
    // 0x52b73c: stur            x2, [fp, #-8]
    // 0x52b740: StoreField: r1->field_17 = r2
    //     0x52b740: stur            w2, [x1, #0x17]
    // 0x52b744: SaveReg r1
    //     0x52b744: str             x1, [SP, #-8]!
    // 0x52b748: r0 = _interpolate()
    //     0x52b748: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x52b74c: add             SP, SP, #8
    // 0x52b750: r1 = LoadClassIdInstr(r0)
    //     0x52b750: ldur            x1, [x0, #-1]
    //     0x52b754: ubfx            x1, x1, #0xc, #0x14
    // 0x52b758: r16 = "application/json"
    //     0x52b758: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ec0] "application/json"
    //     0x52b75c: ldr             x16, [x16, #0xec0]
    // 0x52b760: stp             x16, x0, [SP, #-0x10]!
    // 0x52b764: mov             x0, x1
    // 0x52b768: mov             lr, x0
    // 0x52b76c: ldr             lr, [x21, lr, lsl #3]
    // 0x52b770: blr             lr
    // 0x52b774: add             SP, SP, #0x10
    // 0x52b778: tbz             w0, #4, #0x52b7b8
    // 0x52b77c: ldur            x16, [fp, #-0x10]
    // 0x52b780: SaveReg r16
    //     0x52b780: str             x16, [SP, #-8]!
    // 0x52b784: r0 = mimeType()
    //     0x52b784: bl              #0x52b84c  ; [package:http_parser/src/media_type.dart] MediaType::mimeType
    // 0x52b788: add             SP, SP, #8
    // 0x52b78c: r1 = LoadClassIdInstr(r0)
    //     0x52b78c: ldur            x1, [x0, #-1]
    //     0x52b790: ubfx            x1, x1, #0xc, #0x14
    // 0x52b794: r16 = "text/json"
    //     0x52b794: add             x16, PP, #0x13, lsl #12  ; [pp+0x13198] "text/json"
    //     0x52b798: ldr             x16, [x16, #0x198]
    // 0x52b79c: stp             x16, x0, [SP, #-0x10]!
    // 0x52b7a0: mov             x0, x1
    // 0x52b7a4: mov             lr, x0
    // 0x52b7a8: ldr             lr, [x21, lr, lsl #3]
    // 0x52b7ac: blr             lr
    // 0x52b7b0: add             SP, SP, #0x10
    // 0x52b7b4: tbnz            w0, #4, #0x52b7c0
    // 0x52b7b8: r0 = true
    //     0x52b7b8: add             x0, NULL, #0x20  ; true
    // 0x52b7bc: b               #0x52b7d8
    // 0x52b7c0: ldur            x16, [fp, #-8]
    // 0x52b7c4: r30 = "+json"
    //     0x52b7c4: add             lr, PP, #0x13, lsl #12  ; [pp+0x131a0] "+json"
    //     0x52b7c8: ldr             lr, [lr, #0x1a0]
    // 0x52b7cc: stp             lr, x16, [SP, #-0x10]!
    // 0x52b7d0: r0 = endsWith()
    //     0x52b7d0: bl              #0x52b7ec  ; [dart:core] _StringBase::endsWith
    // 0x52b7d4: add             SP, SP, #0x10
    // 0x52b7d8: LeaveFrame
    //     0x52b7d8: mov             SP, fp
    //     0x52b7dc: ldp             fp, lr, [SP], #0x10
    // 0x52b7e0: ret
    //     0x52b7e0: ret             
    // 0x52b7e4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52b7e4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52b7e8: b               #0x52b6d8
  }
  static _ urlEncodeQueryMap(/* No info */) {
    // ** addr: 0x553aec, size: 0x58
    // 0x553aec: EnterFrame
    //     0x553aec: stp             fp, lr, [SP, #-0x10]!
    //     0x553af0: mov             fp, SP
    // 0x553af4: CheckStackOverflow
    //     0x553af4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x553af8: cmp             SP, x16
    //     0x553afc: b.ls            #0x553b3c
    // 0x553b00: r1 = Function '<anonymous closure>': static.
    //     0x553b00: add             x1, PP, #0x14, lsl #12  ; [pp+0x142f8] AnonymousClosure: static (0x5549b8), in [package:dio/src/transformer.dart] Transformer::urlEncodeQueryMap (0x553aec)
    //     0x553b04: ldr             x1, [x1, #0x2f8]
    // 0x553b08: r2 = Null
    //     0x553b08: mov             x2, NULL
    // 0x553b0c: r0 = AllocateClosure()
    //     0x553b0c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x553b10: ldr             x16, [fp, #0x10]
    // 0x553b14: stp             x0, x16, [SP, #-0x10]!
    // 0x553b18: r16 = true
    //     0x553b18: add             x16, NULL, #0x20  ; true
    // 0x553b1c: SaveReg r16
    //     0x553b1c: str             x16, [SP, #-8]!
    // 0x553b20: r4 = const [0, 0x3, 0x3, 0x2, isQuery, 0x2, null]
    //     0x553b20: add             x4, PP, #0x14, lsl #12  ; [pp+0x14300] List(7) [0, 0x3, 0x3, 0x2, "isQuery", 0x2, Null]
    //     0x553b24: ldr             x4, [x4, #0x300]
    // 0x553b28: r0 = encodeMap()
    //     0x553b28: bl              #0x553b44  ; [package:dio/src/utils.dart] ::encodeMap
    // 0x553b2c: add             SP, SP, #0x18
    // 0x553b30: LeaveFrame
    //     0x553b30: mov             SP, fp
    //     0x553b34: ldp             fp, lr, [SP], #0x10
    // 0x553b38: ret
    //     0x553b38: ret             
    // 0x553b3c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x553b3c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x553b40: b               #0x553b00
  }
  [closure] static String <anonymous closure>(dynamic, String, Object?) {
    // ** addr: 0x5549b8, size: 0x7c
    // 0x5549b8: EnterFrame
    //     0x5549b8: stp             fp, lr, [SP, #-0x10]!
    //     0x5549bc: mov             fp, SP
    // 0x5549c0: CheckStackOverflow
    //     0x5549c0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5549c4: cmp             SP, x16
    //     0x5549c8: b.ls            #0x554a2c
    // 0x5549cc: ldr             x0, [fp, #0x10]
    // 0x5549d0: cmp             w0, NULL
    // 0x5549d4: b.ne            #0x5549e8
    // 0x5549d8: ldr             x0, [fp, #0x18]
    // 0x5549dc: LeaveFrame
    //     0x5549dc: mov             SP, fp
    //     0x5549e0: ldp             fp, lr, [SP], #0x10
    // 0x5549e4: ret
    //     0x5549e4: ret             
    // 0x5549e8: ldr             x3, [fp, #0x18]
    // 0x5549ec: r1 = Null
    //     0x5549ec: mov             x1, NULL
    // 0x5549f0: r2 = 6
    //     0x5549f0: mov             x2, #6
    // 0x5549f4: r0 = AllocateArray()
    //     0x5549f4: bl              #0xd6987c  ; AllocateArrayStub
    // 0x5549f8: mov             x1, x0
    // 0x5549fc: ldr             x0, [fp, #0x18]
    // 0x554a00: StoreField: r1->field_f = r0
    //     0x554a00: stur            w0, [x1, #0xf]
    // 0x554a04: r17 = "="
    //     0x554a04: ldr             x17, [PP, #0x2a8]  ; [pp+0x2a8] "="
    // 0x554a08: StoreField: r1->field_13 = r17
    //     0x554a08: stur            w17, [x1, #0x13]
    // 0x554a0c: ldr             x0, [fp, #0x10]
    // 0x554a10: StoreField: r1->field_17 = r0
    //     0x554a10: stur            w0, [x1, #0x17]
    // 0x554a14: SaveReg r1
    //     0x554a14: str             x1, [SP, #-8]!
    // 0x554a18: r0 = _interpolate()
    //     0x554a18: bl              #0x4bc5a8  ; [dart:core] _StringBase::_interpolate
    // 0x554a1c: add             SP, SP, #8
    // 0x554a20: LeaveFrame
    //     0x554a20: mov             SP, fp
    //     0x554a24: ldp             fp, lr, [SP], #0x10
    // 0x554a28: ret
    //     0x554a28: ret             
    // 0x554a2c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x554a2c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x554a30: b               #0x5549cc
  }
}

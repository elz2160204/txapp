// lib: , url: package:dio/src/adapters/io_adapter.dart

// class id: 1048880, size: 0x8
class :: {
}

// class id: 4551, size: 0x1c, field offset: 0x8
class IOHttpClientAdapter extends Object
    implements HttpClientAdapter {

  _ fetch(/* No info */) async {
    // ** addr: 0x52e810, size: 0x11c
    // 0x52e810: EnterFrame
    //     0x52e810: stp             fp, lr, [SP, #-0x10]!
    //     0x52e814: mov             fp, SP
    // 0x52e818: AllocStack(0x28)
    //     0x52e818: sub             SP, SP, #0x28
    // 0x52e81c: SetupParameters(IOHttpClientAdapter this /* r1, fp-0x28 */, dynamic _ /* r2, fp-0x20 */, dynamic _ /* r3, fp-0x18 */, dynamic _ /* r4, fp-0x10 */)
    //     0x52e81c: stur            NULL, [fp, #-8]
    //     0x52e820: mov             x0, #0
    //     0x52e824: add             x1, fp, w0, sxtw #2
    //     0x52e828: ldr             x1, [x1, #0x28]
    //     0x52e82c: stur            x1, [fp, #-0x28]
    //     0x52e830: add             x2, fp, w0, sxtw #2
    //     0x52e834: ldr             x2, [x2, #0x20]
    //     0x52e838: stur            x2, [fp, #-0x20]
    //     0x52e83c: add             x3, fp, w0, sxtw #2
    //     0x52e840: ldr             x3, [x3, #0x18]
    //     0x52e844: stur            x3, [fp, #-0x18]
    //     0x52e848: add             x4, fp, w0, sxtw #2
    //     0x52e84c: ldr             x4, [x4, #0x10]
    //     0x52e850: stur            x4, [fp, #-0x10]
    // 0x52e854: CheckStackOverflow
    //     0x52e854: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e858: cmp             SP, x16
    //     0x52e85c: b.ls            #0x52e924
    // 0x52e860: InitAsync() -> Future<ResponseBody>
    //     0x52e860: add             x0, PP, #0x13, lsl #12  ; [pp+0x13368] TypeArguments: <ResponseBody>
    //     0x52e864: ldr             x0, [x0, #0x368]
    //     0x52e868: bl              #0x4b92e4
    // 0x52e86c: ldur            x0, [fp, #-0x28]
    // 0x52e870: LoadField: r1 = r0->field_17
    //     0x52e870: ldur            w1, [x0, #0x17]
    // 0x52e874: DecompressPointer r1
    //     0x52e874: add             x1, x1, HEAP, lsl #32
    // 0x52e878: tbz             w1, #4, #0x52e904
    // 0x52e87c: ldur            x1, [fp, #-0x10]
    // 0x52e880: ldur            x16, [fp, #-0x20]
    // 0x52e884: stp             x16, x0, [SP, #-0x10]!
    // 0x52e888: ldur            x16, [fp, #-0x18]
    // 0x52e88c: stp             x1, x16, [SP, #-0x10]!
    // 0x52e890: r0 = _fetch()
    //     0x52e890: bl              #0x52efd4  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch
    // 0x52e894: add             SP, SP, #0x20
    // 0x52e898: r16 = <ResponseBody>
    //     0x52e898: add             x16, PP, #0x13, lsl #12  ; [pp+0x13368] TypeArguments: <ResponseBody>
    //     0x52e89c: ldr             x16, [x16, #0x368]
    // 0x52e8a0: stp             x0, x16, [SP, #-0x10]!
    // 0x52e8a4: r0 = CancelableOperation.fromFuture()
    //     0x52e8a4: bl              #0x52e9d8  ; [package:async/src/cancelable_operation.dart] CancelableOperation::CancelableOperation.fromFuture
    // 0x52e8a8: add             SP, SP, #0x10
    // 0x52e8ac: stur            x0, [fp, #-0x18]
    // 0x52e8b0: r1 = 1
    //     0x52e8b0: mov             x1, #1
    // 0x52e8b4: r0 = AllocateContext()
    //     0x52e8b4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52e8b8: mov             x1, x0
    // 0x52e8bc: ldur            x0, [fp, #-0x18]
    // 0x52e8c0: StoreField: r1->field_f = r0
    //     0x52e8c0: stur            w0, [x1, #0xf]
    // 0x52e8c4: ldur            x3, [fp, #-0x10]
    // 0x52e8c8: cmp             w3, NULL
    // 0x52e8cc: b.eq            #0x52e8f0
    // 0x52e8d0: mov             x2, x1
    // 0x52e8d4: r1 = Function '<anonymous closure>':.
    //     0x52e8d4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13370] AnonymousClosure: (0x557198), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::fetch (0x52e810)
    //     0x52e8d8: ldr             x1, [x1, #0x370]
    // 0x52e8dc: r0 = AllocateClosure()
    //     0x52e8dc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52e8e0: ldur            x16, [fp, #-0x10]
    // 0x52e8e4: stp             x0, x16, [SP, #-0x10]!
    // 0x52e8e8: r0 = whenComplete()
    //     0x52e8e8: bl              #0xca6034  ; [dart:async] _Future::whenComplete
    // 0x52e8ec: add             SP, SP, #0x10
    // 0x52e8f0: ldur            x16, [fp, #-0x18]
    // 0x52e8f4: SaveReg r16
    //     0x52e8f4: str             x16, [SP, #-8]!
    // 0x52e8f8: r0 = value()
    //     0x52e8f8: bl              #0x52e92c  ; [package:async/src/cancelable_operation.dart] CancelableOperation::value
    // 0x52e8fc: add             SP, SP, #8
    // 0x52e900: r0 = ReturnAsync()
    //     0x52e900: b               #0x501858  ; ReturnAsyncStub
    // 0x52e904: r0 = StateError()
    //     0x52e904: bl              #0x4b5564  ; AllocateStateErrorStub -> StateError (size=0x10)
    // 0x52e908: mov             x1, x0
    // 0x52e90c: r0 = "Can\'t establish connection after the adapter was closed!"
    //     0x52e90c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13378] "Can\'t establish connection after the adapter was closed!"
    //     0x52e910: ldr             x0, [x0, #0x378]
    // 0x52e914: StoreField: r1->field_b = r0
    //     0x52e914: stur            w0, [x1, #0xb]
    // 0x52e918: mov             x0, x1
    // 0x52e91c: r0 = Throw()
    //     0x52e91c: bl              #0xd67e38  ; ThrowStub
    // 0x52e920: brk             #0
    // 0x52e924: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e924: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e928: b               #0x52e860
  }
  _ _fetch(/* No info */) async {
    // ** addr: 0x52efd4, size: 0x994
    // 0x52efd4: EnterFrame
    //     0x52efd4: stp             fp, lr, [SP, #-0x10]!
    //     0x52efd8: mov             fp, SP
    // 0x52efdc: AllocStack(0xe8)
    //     0x52efdc: sub             SP, SP, #0xe8
    // 0x52efe0: SetupParameters(IOHttpClientAdapter this /* r1, fp-0xc8 */, dynamic _ /* r2, fp-0xc0 */, dynamic _ /* r3, fp-0xb8 */, dynamic _ /* r4, fp-0xb0 */)
    //     0x52efe0: stur            NULL, [fp, #-8]
    //     0x52efe4: mov             x0, #0
    //     0x52efe8: add             x1, fp, w0, sxtw #2
    //     0x52efec: ldr             x1, [x1, #0x28]
    //     0x52eff0: stur            x1, [fp, #-0xc8]
    //     0x52eff4: add             x2, fp, w0, sxtw #2
    //     0x52eff8: ldr             x2, [x2, #0x20]
    //     0x52effc: stur            x2, [fp, #-0xc0]
    //     0x52f000: add             x3, fp, w0, sxtw #2
    //     0x52f004: ldr             x3, [x3, #0x18]
    //     0x52f008: stur            x3, [fp, #-0xb8]
    //     0x52f00c: add             x4, fp, w0, sxtw #2
    //     0x52f010: ldr             x4, [x4, #0x10]
    //     0x52f014: stur            x4, [fp, #-0xb0]
    // 0x52f018: CheckStackOverflow
    //     0x52f018: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52f01c: cmp             SP, x16
    //     0x52f020: b.ls            #0x52f908
    // 0x52f024: r1 = 8
    //     0x52f024: mov             x1, #8
    // 0x52f028: r0 = AllocateContext()
    //     0x52f028: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52f02c: mov             x1, x0
    // 0x52f030: ldur            x0, [fp, #-0xc0]
    // 0x52f034: stur            x1, [fp, #-0xd0]
    // 0x52f038: StoreField: r1->field_f = r0
    //     0x52f038: stur            w0, [x1, #0xf]
    // 0x52f03c: InitAsync() -> Future<ResponseBody>
    //     0x52f03c: add             x0, PP, #0x13, lsl #12  ; [pp+0x13368] TypeArguments: <ResponseBody>
    //     0x52f040: ldr             x0, [x0, #0x368]
    //     0x52f044: bl              #0x4b92e4
    // 0x52f048: ldur            x2, [fp, #-0xd0]
    // 0x52f04c: LoadField: r0 = r2->field_f
    //     0x52f04c: ldur            w0, [x2, #0xf]
    // 0x52f050: DecompressPointer r0
    //     0x52f050: add             x0, x0, HEAP, lsl #32
    // 0x52f054: LoadField: r1 = r0->field_4b
    //     0x52f054: ldur            w1, [x0, #0x4b]
    // 0x52f058: DecompressPointer r1
    //     0x52f058: add             x1, x1, HEAP, lsl #32
    // 0x52f05c: ldur            x16, [fp, #-0xc8]
    // 0x52f060: stp             x1, x16, [SP, #-0x10]!
    // 0x52f064: r0 = _configHttpClient()
    //     0x52f064: bl              #0x554a34  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_configHttpClient
    // 0x52f068: add             SP, SP, #0x10
    // 0x52f06c: ldur            x2, [fp, #-0xd0]
    // 0x52f070: stur            x0, [fp, #-0xd8]
    // 0x52f074: LoadField: r1 = r2->field_f
    //     0x52f074: ldur            w1, [x2, #0xf]
    // 0x52f078: DecompressPointer r1
    //     0x52f078: add             x1, x1, HEAP, lsl #32
    // 0x52f07c: LoadField: r3 = r1->field_7
    //     0x52f07c: ldur            w3, [x1, #7]
    // 0x52f080: DecompressPointer r3
    //     0x52f080: add             x3, x3, HEAP, lsl #32
    // 0x52f084: r16 = Sentinel
    //     0x52f084: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f088: cmp             w3, w16
    // 0x52f08c: b.eq            #0x52f910
    // 0x52f090: stur            x3, [fp, #-0xc0]
    // 0x52f094: SaveReg r1
    //     0x52f094: str             x1, [SP, #-8]!
    // 0x52f098: r0 = uri()
    //     0x52f098: bl              #0x55382c  ; [package:dio/src/options.dart] RequestOptions::uri
    // 0x52f09c: add             SP, SP, #8
    // 0x52f0a0: ldur            x16, [fp, #-0xd8]
    // 0x52f0a4: ldur            lr, [fp, #-0xc0]
    // 0x52f0a8: stp             lr, x16, [SP, #-0x10]!
    // 0x52f0ac: SaveReg r0
    //     0x52f0ac: str             x0, [SP, #-8]!
    // 0x52f0b0: r0 = _openUrl()
    //     0x52f0b0: bl              #0x533558  ; [dart:_http] _HttpClient::_openUrl
    // 0x52f0b4: add             SP, SP, #0x18
    // 0x52f0b8: mov             x4, x0
    // 0x52f0bc: ldur            x3, [fp, #-0xd0]
    // 0x52f0c0: r0 = Sentinel
    //     0x52f0c0: ldr             x0, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f0c4: stur            x4, [fp, #-0xe0]
    // 0x52f0c8: StoreField: r3->field_13 = r0
    //     0x52f0c8: stur            w0, [x3, #0x13]
    // 0x52f0cc: LoadField: r0 = r3->field_f
    //     0x52f0cc: ldur            w0, [x3, #0xf]
    // 0x52f0d0: DecompressPointer r0
    //     0x52f0d0: add             x0, x0, HEAP, lsl #32
    // 0x52f0d4: LoadField: r5 = r0->field_4b
    //     0x52f0d4: ldur            w5, [x0, #0x4b]
    // 0x52f0d8: DecompressPointer r5
    //     0x52f0d8: add             x5, x5, HEAP, lsl #32
    // 0x52f0dc: mov             x0, x5
    // 0x52f0e0: stur            x5, [fp, #-0xc0]
    // 0x52f0e4: StoreField: r3->field_2b = r0
    //     0x52f0e4: stur            w0, [x3, #0x2b]
    //     0x52f0e8: ldurb           w16, [x3, #-1]
    //     0x52f0ec: ldurb           w17, [x0, #-1]
    //     0x52f0f0: and             x16, x17, x16, lsr #2
    //     0x52f0f4: tst             x16, HEAP, lsr #32
    //     0x52f0f8: b.eq            #0x52f100
    //     0x52f0fc: bl              #0xd682ac
    // 0x52f100: cmp             w5, NULL
    // 0x52f104: b.eq            #0x52f180
    // 0x52f108: mov             x2, x3
    // 0x52f10c: r1 = Function '<anonymous closure>':.
    //     0x52f10c: add             x1, PP, #0x13, lsl #12  ; [pp+0x133f8] AnonymousClosure: (0x557144), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f110: ldr             x1, [x1, #0x3f8]
    // 0x52f114: r0 = AllocateClosure()
    //     0x52f114: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f118: ldur            x1, [fp, #-0xe0]
    // 0x52f11c: r2 = LoadClassIdInstr(r1)
    //     0x52f11c: ldur            x2, [x1, #-1]
    //     0x52f120: ubfx            x2, x2, #0xc, #0x14
    // 0x52f124: ldur            x16, [fp, #-0xc0]
    // 0x52f128: stp             x16, x1, [SP, #-0x10]!
    // 0x52f12c: SaveReg r0
    //     0x52f12c: str             x0, [SP, #-8]!
    // 0x52f130: mov             x0, x2
    // 0x52f134: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0x52f134: ldr             x4, [PP, #0x2df8]  ; [pp+0x2df8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0x52f138: r0 = GDT[cid_x0 + -0xec0]()
    //     0x52f138: sub             lr, x0, #0xec0
    //     0x52f13c: ldr             lr, [x21, lr, lsl #3]
    //     0x52f140: blr             lr
    // 0x52f144: add             SP, SP, #0x18
    // 0x52f148: mov             x1, x0
    // 0x52f14c: stur            x1, [fp, #-0xc0]
    // 0x52f150: r0 = Await()
    //     0x52f150: bl              #0x4b8e6c  ; AwaitStub
    // 0x52f154: ldur            x2, [fp, #-0xd0]
    // 0x52f158: StoreField: r2->field_13 = r0
    //     0x52f158: stur            w0, [x2, #0x13]
    //     0x52f15c: tbz             w0, #0, #0x52f178
    //     0x52f160: ldurb           w16, [x2, #-1]
    //     0x52f164: ldurb           w17, [x0, #-1]
    //     0x52f168: and             x16, x17, x16, lsr #2
    //     0x52f16c: tst             x16, HEAP, lsr #32
    //     0x52f170: b.eq            #0x52f178
    //     0x52f174: bl              #0xd6828c
    // 0x52f178: mov             x3, x2
    // 0x52f17c: b               #0x52f1b4
    // 0x52f180: mov             x2, x3
    // 0x52f184: mov             x1, x4
    // 0x52f188: mov             x0, x1
    // 0x52f18c: r0 = Await()
    //     0x52f18c: bl              #0x4b8e6c  ; AwaitStub
    // 0x52f190: ldur            x3, [fp, #-0xd0]
    // 0x52f194: StoreField: r3->field_13 = r0
    //     0x52f194: stur            w0, [x3, #0x13]
    //     0x52f198: tbz             w0, #0, #0x52f1b4
    //     0x52f19c: ldurb           w16, [x3, #-1]
    //     0x52f1a0: ldurb           w17, [x0, #-1]
    //     0x52f1a4: and             x16, x17, x16, lsr #2
    //     0x52f1a8: tst             x16, HEAP, lsr #32
    //     0x52f1ac: b.eq            #0x52f1b4
    //     0x52f1b0: bl              #0xd682ac
    // 0x52f1b4: ldur            x0, [fp, #-0xb0]
    // 0x52f1b8: cmp             w0, NULL
    // 0x52f1bc: b.eq            #0x52f1e0
    // 0x52f1c0: mov             x2, x3
    // 0x52f1c4: r1 = Function '<anonymous closure>':.
    //     0x52f1c4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13400] AnonymousClosure: (0x5570bc), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f1c8: ldr             x1, [x1, #0x400]
    // 0x52f1cc: r0 = AllocateClosure()
    //     0x52f1cc: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f1d0: ldur            x16, [fp, #-0xb0]
    // 0x52f1d4: stp             x0, x16, [SP, #-0x10]!
    // 0x52f1d8: r0 = whenComplete()
    //     0x52f1d8: bl              #0xca6034  ; [dart:async] _Future::whenComplete
    // 0x52f1dc: add             SP, SP, #0x10
    // 0x52f1e0: ldur            x0, [fp, #-0xd0]
    // 0x52f1e4: LoadField: r1 = r0->field_f
    //     0x52f1e4: ldur            w1, [x0, #0xf]
    // 0x52f1e8: DecompressPointer r1
    //     0x52f1e8: add             x1, x1, HEAP, lsl #32
    // 0x52f1ec: LoadField: r3 = r1->field_b
    //     0x52f1ec: ldur            w3, [x1, #0xb]
    // 0x52f1f0: DecompressPointer r3
    //     0x52f1f0: add             x3, x3, HEAP, lsl #32
    // 0x52f1f4: r16 = Sentinel
    //     0x52f1f4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f1f8: cmp             w3, w16
    // 0x52f1fc: b.eq            #0x52f91c
    // 0x52f200: mov             x2, x0
    // 0x52f204: stur            x3, [fp, #-0xb0]
    // 0x52f208: r1 = Function '<anonymous closure>':.
    //     0x52f208: add             x1, PP, #0x13, lsl #12  ; [pp+0x13408] AnonymousClosure: (0x557014), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f20c: ldr             x1, [x1, #0x408]
    // 0x52f210: r0 = AllocateClosure()
    //     0x52f210: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f214: mov             x1, x0
    // 0x52f218: ldur            x0, [fp, #-0xb0]
    // 0x52f21c: r2 = LoadClassIdInstr(r0)
    //     0x52f21c: ldur            x2, [x0, #-1]
    //     0x52f220: ubfx            x2, x2, #0xc, #0x14
    // 0x52f224: stp             x1, x0, [SP, #-0x10]!
    // 0x52f228: mov             x0, x2
    // 0x52f22c: r0 = GDT[cid_x0 + 0x66b]()
    //     0x52f22c: add             lr, x0, #0x66b
    //     0x52f230: ldr             lr, [x21, lr, lsl #3]
    //     0x52f234: blr             lr
    // 0x52f238: add             SP, SP, #0x10
    // 0x52f23c: ldur            x2, [fp, #-0xd0]
    // 0x52f240: LoadField: r0 = r2->field_13
    //     0x52f240: ldur            w0, [x2, #0x13]
    // 0x52f244: DecompressPointer r0
    //     0x52f244: add             x0, x0, HEAP, lsl #32
    // 0x52f248: r16 = Sentinel
    //     0x52f248: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f24c: cmp             w0, w16
    // 0x52f250: b.ne            #0x52f264
    // 0x52f254: r16 = "request"
    //     0x52f254: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x52f258: SaveReg r16
    //     0x52f258: str             x16, [SP, #-8]!
    // 0x52f25c: r0 = _throwLocalNotInitialized()
    //     0x52f25c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x52f260: add             SP, SP, #8
    // 0x52f264: ldur            x2, [fp, #-0xd0]
    // 0x52f268: LoadField: r0 = r2->field_13
    //     0x52f268: ldur            w0, [x2, #0x13]
    // 0x52f26c: DecompressPointer r0
    //     0x52f26c: add             x0, x0, HEAP, lsl #32
    // 0x52f270: LoadField: r1 = r2->field_f
    //     0x52f270: ldur            w1, [x2, #0xf]
    // 0x52f274: DecompressPointer r1
    //     0x52f274: add             x1, x1, HEAP, lsl #32
    // 0x52f278: LoadField: r3 = r1->field_2b
    //     0x52f278: ldur            w3, [x1, #0x2b]
    // 0x52f27c: DecompressPointer r3
    //     0x52f27c: add             x3, x3, HEAP, lsl #32
    // 0x52f280: r16 = Sentinel
    //     0x52f280: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f284: cmp             w3, w16
    // 0x52f288: b.eq            #0x52f928
    // 0x52f28c: cmp             w0, NULL
    // 0x52f290: b.eq            #0x52f934
    // 0x52f294: r16 = true
    //     0x52f294: add             x16, NULL, #0x20  ; true
    // 0x52f298: stp             x16, x0, [SP, #-0x10]!
    // 0x52f29c: r0 = followRedirects=()
    //     0x52f29c: bl              #0x533500  ; [dart:_http] _HttpClientRequest::followRedirects=
    // 0x52f2a0: add             SP, SP, #0x10
    // 0x52f2a4: ldur            x2, [fp, #-0xd0]
    // 0x52f2a8: LoadField: r0 = r2->field_13
    //     0x52f2a8: ldur            w0, [x2, #0x13]
    // 0x52f2ac: DecompressPointer r0
    //     0x52f2ac: add             x0, x0, HEAP, lsl #32
    // 0x52f2b0: r16 = Sentinel
    //     0x52f2b0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f2b4: cmp             w0, w16
    // 0x52f2b8: b.ne            #0x52f2cc
    // 0x52f2bc: r16 = "request"
    //     0x52f2bc: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x52f2c0: SaveReg r16
    //     0x52f2c0: str             x16, [SP, #-8]!
    // 0x52f2c4: r0 = _throwLocalNotInitialized()
    //     0x52f2c4: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x52f2c8: add             SP, SP, #8
    // 0x52f2cc: ldur            x2, [fp, #-0xd0]
    // 0x52f2d0: r0 = 5
    //     0x52f2d0: mov             x0, #5
    // 0x52f2d4: LoadField: r1 = r2->field_13
    //     0x52f2d4: ldur            w1, [x2, #0x13]
    // 0x52f2d8: DecompressPointer r1
    //     0x52f2d8: add             x1, x1, HEAP, lsl #32
    // 0x52f2dc: LoadField: r3 = r2->field_f
    //     0x52f2dc: ldur            w3, [x2, #0xf]
    // 0x52f2e0: DecompressPointer r3
    //     0x52f2e0: add             x3, x3, HEAP, lsl #32
    // 0x52f2e4: LoadField: r4 = r3->field_2f
    //     0x52f2e4: ldur            w4, [x3, #0x2f]
    // 0x52f2e8: DecompressPointer r4
    //     0x52f2e8: add             x4, x4, HEAP, lsl #32
    // 0x52f2ec: r16 = Sentinel
    //     0x52f2ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f2f0: cmp             w4, w16
    // 0x52f2f4: b.eq            #0x52f938
    // 0x52f2f8: cmp             w1, NULL
    // 0x52f2fc: b.eq            #0x52f944
    // 0x52f300: stp             x0, x1, [SP, #-0x10]!
    // 0x52f304: r0 = maxRedirects=()
    //     0x52f304: bl              #0x533484  ; [dart:_http] _HttpClientRequest::maxRedirects=
    // 0x52f308: add             SP, SP, #0x10
    // 0x52f30c: ldur            x2, [fp, #-0xd0]
    // 0x52f310: LoadField: r0 = r2->field_13
    //     0x52f310: ldur            w0, [x2, #0x13]
    // 0x52f314: DecompressPointer r0
    //     0x52f314: add             x0, x0, HEAP, lsl #32
    // 0x52f318: r16 = Sentinel
    //     0x52f318: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f31c: cmp             w0, w16
    // 0x52f320: b.ne            #0x52f334
    // 0x52f324: r16 = "request"
    //     0x52f324: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x52f328: SaveReg r16
    //     0x52f328: str             x16, [SP, #-8]!
    // 0x52f32c: r0 = _throwLocalNotInitialized()
    //     0x52f32c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x52f330: add             SP, SP, #8
    // 0x52f334: ldur            x0, [fp, #-0xb8]
    // 0x52f338: ldur            x2, [fp, #-0xd0]
    // 0x52f33c: LoadField: r1 = r2->field_13
    //     0x52f33c: ldur            w1, [x2, #0x13]
    // 0x52f340: DecompressPointer r1
    //     0x52f340: add             x1, x1, HEAP, lsl #32
    // 0x52f344: LoadField: r3 = r2->field_f
    //     0x52f344: ldur            w3, [x2, #0xf]
    // 0x52f348: DecompressPointer r3
    //     0x52f348: add             x3, x3, HEAP, lsl #32
    // 0x52f34c: LoadField: r4 = r3->field_33
    //     0x52f34c: ldur            w4, [x3, #0x33]
    // 0x52f350: DecompressPointer r4
    //     0x52f350: add             x4, x4, HEAP, lsl #32
    // 0x52f354: r16 = Sentinel
    //     0x52f354: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f358: cmp             w4, w16
    // 0x52f35c: b.eq            #0x52f948
    // 0x52f360: cmp             w1, NULL
    // 0x52f364: b.eq            #0x52f954
    // 0x52f368: r16 = true
    //     0x52f368: add             x16, NULL, #0x20  ; true
    // 0x52f36c: stp             x16, x1, [SP, #-0x10]!
    // 0x52f370: r0 = persistentConnection=()
    //     0x52f370: bl              #0x5301d4  ; [dart:_http] _HttpOutboundMessage::persistentConnection=
    // 0x52f374: add             SP, SP, #0x10
    // 0x52f378: ldur            x0, [fp, #-0xb8]
    // 0x52f37c: cmp             w0, NULL
    // 0x52f380: b.eq            #0x52f478
    // 0x52f384: ldur            x2, [fp, #-0xd0]
    // 0x52f388: LoadField: r1 = r2->field_13
    //     0x52f388: ldur            w1, [x2, #0x13]
    // 0x52f38c: DecompressPointer r1
    //     0x52f38c: add             x1, x1, HEAP, lsl #32
    // 0x52f390: r16 = Sentinel
    //     0x52f390: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f394: cmp             w1, w16
    // 0x52f398: b.ne            #0x52f3ac
    // 0x52f39c: r16 = "request"
    //     0x52f39c: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x52f3a0: SaveReg r16
    //     0x52f3a0: str             x16, [SP, #-8]!
    // 0x52f3a4: r0 = _throwLocalNotInitialized()
    //     0x52f3a4: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x52f3a8: add             SP, SP, #8
    // 0x52f3ac: ldur            x2, [fp, #-0xd0]
    // 0x52f3b0: LoadField: r0 = r2->field_13
    //     0x52f3b0: ldur            w0, [x2, #0x13]
    // 0x52f3b4: DecompressPointer r0
    //     0x52f3b4: add             x0, x0, HEAP, lsl #32
    // 0x52f3b8: cmp             w0, NULL
    // 0x52f3bc: b.eq            #0x52f958
    // 0x52f3c0: ldur            x16, [fp, #-0xb8]
    // 0x52f3c4: stp             x16, x0, [SP, #-0x10]!
    // 0x52f3c8: r0 = addStream()
    //     0x52f3c8: bl              #0xc47334  ; [dart:_http] _HttpOutboundMessage::addStream
    // 0x52f3cc: add             SP, SP, #0x10
    // 0x52f3d0: mov             x4, x0
    // 0x52f3d4: ldur            x3, [fp, #-0xd0]
    // 0x52f3d8: stur            x4, [fp, #-0xb8]
    // 0x52f3dc: LoadField: r0 = r3->field_f
    //     0x52f3dc: ldur            w0, [x3, #0xf]
    // 0x52f3e0: DecompressPointer r0
    //     0x52f3e0: add             x0, x0, HEAP, lsl #32
    // 0x52f3e4: LoadField: r5 = r0->field_f
    //     0x52f3e4: ldur            w5, [x0, #0xf]
    // 0x52f3e8: DecompressPointer r5
    //     0x52f3e8: add             x5, x5, HEAP, lsl #32
    // 0x52f3ec: mov             x0, x5
    // 0x52f3f0: stur            x5, [fp, #-0xb0]
    // 0x52f3f4: StoreField: r3->field_27 = r0
    //     0x52f3f4: stur            w0, [x3, #0x27]
    //     0x52f3f8: ldurb           w16, [x3, #-1]
    //     0x52f3fc: ldurb           w17, [x0, #-1]
    //     0x52f400: and             x16, x17, x16, lsr #2
    //     0x52f404: tst             x16, HEAP, lsr #32
    //     0x52f408: b.eq            #0x52f410
    //     0x52f40c: bl              #0xd682ac
    // 0x52f410: cmp             w5, NULL
    // 0x52f414: b.eq            #0x52f464
    // 0x52f418: mov             x2, x3
    // 0x52f41c: r1 = Function '<anonymous closure>':.
    //     0x52f41c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13410] AnonymousClosure: (0x556e08), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f420: ldr             x1, [x1, #0x410]
    // 0x52f424: r0 = AllocateClosure()
    //     0x52f424: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f428: mov             x1, x0
    // 0x52f42c: ldur            x0, [fp, #-0xb8]
    // 0x52f430: r2 = LoadClassIdInstr(r0)
    //     0x52f430: ldur            x2, [x0, #-1]
    //     0x52f434: ubfx            x2, x2, #0xc, #0x14
    // 0x52f438: ldur            x16, [fp, #-0xb0]
    // 0x52f43c: stp             x16, x0, [SP, #-0x10]!
    // 0x52f440: SaveReg r1
    //     0x52f440: str             x1, [SP, #-8]!
    // 0x52f444: mov             x0, x2
    // 0x52f448: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0x52f448: ldr             x4, [PP, #0x2df8]  ; [pp+0x2df8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0x52f44c: r0 = GDT[cid_x0 + -0xec0]()
    //     0x52f44c: sub             lr, x0, #0xec0
    //     0x52f450: ldr             lr, [x21, lr, lsl #3]
    //     0x52f454: blr             lr
    // 0x52f458: add             SP, SP, #0x18
    // 0x52f45c: mov             x1, x0
    // 0x52f460: b               #0x52f46c
    // 0x52f464: mov             x0, x4
    // 0x52f468: mov             x1, x0
    // 0x52f46c: mov             x0, x1
    // 0x52f470: stur            x1, [fp, #-0xb0]
    // 0x52f474: r0 = Await()
    //     0x52f474: bl              #0x4b8e6c  ; AwaitStub
    // 0x52f478: ldur            x2, [fp, #-0xd0]
    // 0x52f47c: r0 = Stopwatch()
    //     0x52f47c: bl              #0x4ffefc  ; AllocateStopwatchStub -> Stopwatch (size=0x14)
    // 0x52f480: mov             x1, x0
    // 0x52f484: r0 = 0
    //     0x52f484: mov             x0, #0
    // 0x52f488: stur            x1, [fp, #-0xb0]
    // 0x52f48c: StoreField: r1->field_7 = r0
    //     0x52f48c: stur            x0, [x1, #7]
    // 0x52f490: StoreField: r1->field_f = rZR
    //     0x52f490: stur            wzr, [x1, #0xf]
    // 0x52f494: r0 = InitLateStaticField(0x570) // [dart:core] Stopwatch::_frequency
    //     0x52f494: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x52f498: ldr             x0, [x0, #0xae0]
    //     0x52f49c: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x52f4a0: cmp             w0, w16
    //     0x52f4a4: b.ne            #0x52f4b0
    //     0x52f4a8: ldr             x2, [PP, #0x1b58]  ; [pp+0x1b58] Field <Stopwatch._frequency@0150898>: static late final (offset: 0x570)
    //     0x52f4ac: bl              #0xd67cdc
    // 0x52f4b0: ldur            x16, [fp, #-0xb0]
    // 0x52f4b4: SaveReg r16
    //     0x52f4b4: str             x16, [SP, #-8]!
    // 0x52f4b8: r0 = start()
    //     0x52f4b8: bl              #0x4ff9a0  ; [dart:core] Stopwatch::start
    // 0x52f4bc: add             SP, SP, #8
    // 0x52f4c0: ldur            x0, [fp, #-0xb0]
    // 0x52f4c4: ldur            x2, [fp, #-0xd0]
    // 0x52f4c8: StoreField: r2->field_17 = r0
    //     0x52f4c8: stur            w0, [x2, #0x17]
    //     0x52f4cc: ldurb           w16, [x2, #-1]
    //     0x52f4d0: ldurb           w17, [x0, #-1]
    //     0x52f4d4: and             x16, x17, x16, lsr #2
    //     0x52f4d8: tst             x16, HEAP, lsr #32
    //     0x52f4dc: b.eq            #0x52f4e4
    //     0x52f4e0: bl              #0xd6828c
    // 0x52f4e4: LoadField: r0 = r2->field_13
    //     0x52f4e4: ldur            w0, [x2, #0x13]
    // 0x52f4e8: DecompressPointer r0
    //     0x52f4e8: add             x0, x0, HEAP, lsl #32
    // 0x52f4ec: r16 = Sentinel
    //     0x52f4ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52f4f0: cmp             w0, w16
    // 0x52f4f4: b.ne            #0x52f508
    // 0x52f4f8: r16 = "request"
    //     0x52f4f8: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x52f4fc: SaveReg r16
    //     0x52f4fc: str             x16, [SP, #-8]!
    // 0x52f500: r0 = _throwLocalNotInitialized()
    //     0x52f500: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x52f504: add             SP, SP, #8
    // 0x52f508: ldur            x2, [fp, #-0xd0]
    // 0x52f50c: LoadField: r0 = r2->field_13
    //     0x52f50c: ldur            w0, [x2, #0x13]
    // 0x52f510: DecompressPointer r0
    //     0x52f510: add             x0, x0, HEAP, lsl #32
    // 0x52f514: cmp             w0, NULL
    // 0x52f518: b.eq            #0x52f95c
    // 0x52f51c: SaveReg r0
    //     0x52f51c: str             x0, [SP, #-8]!
    // 0x52f520: r0 = close()
    //     0x52f520: bl              #0xc158b0  ; [dart:_http] _HttpClientRequest::close
    // 0x52f524: add             SP, SP, #8
    // 0x52f528: mov             x4, x0
    // 0x52f52c: ldur            x3, [fp, #-0xd0]
    // 0x52f530: stur            x4, [fp, #-0xb8]
    // 0x52f534: LoadField: r0 = r3->field_f
    //     0x52f534: ldur            w0, [x3, #0xf]
    // 0x52f538: DecompressPointer r0
    //     0x52f538: add             x0, x0, HEAP, lsl #32
    // 0x52f53c: LoadField: r5 = r0->field_13
    //     0x52f53c: ldur            w5, [x0, #0x13]
    // 0x52f540: DecompressPointer r5
    //     0x52f540: add             x5, x5, HEAP, lsl #32
    // 0x52f544: mov             x0, x5
    // 0x52f548: stur            x5, [fp, #-0xb0]
    // 0x52f54c: StoreField: r3->field_1b = r0
    //     0x52f54c: stur            w0, [x3, #0x1b]
    //     0x52f550: ldurb           w16, [x3, #-1]
    //     0x52f554: ldurb           w17, [x0, #-1]
    //     0x52f558: and             x16, x17, x16, lsr #2
    //     0x52f55c: tst             x16, HEAP, lsr #32
    //     0x52f560: b.eq            #0x52f568
    //     0x52f564: bl              #0xd682ac
    // 0x52f568: cmp             w5, NULL
    // 0x52f56c: b.eq            #0x52f5a4
    // 0x52f570: mov             x2, x3
    // 0x52f574: r1 = Function '<anonymous closure>':.
    //     0x52f574: add             x1, PP, #0x13, lsl #12  ; [pp+0x13418] AnonymousClosure: (0x556db4), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f578: ldr             x1, [x1, #0x418]
    // 0x52f57c: r0 = AllocateClosure()
    //     0x52f57c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f580: ldur            x16, [fp, #-0xb8]
    // 0x52f584: ldur            lr, [fp, #-0xb0]
    // 0x52f588: stp             lr, x16, [SP, #-0x10]!
    // 0x52f58c: SaveReg r0
    //     0x52f58c: str             x0, [SP, #-8]!
    // 0x52f590: r4 = const [0, 0x3, 0x3, 0x2, onTimeout, 0x2, null]
    //     0x52f590: ldr             x4, [PP, #0x2df8]  ; [pp+0x2df8] List(7) [0, 0x3, 0x3, 0x2, "onTimeout", 0x2, Null]
    // 0x52f594: r0 = timeout()
    //     0x52f594: bl              #0xca0a98  ; [dart:async] _Future::timeout
    // 0x52f598: add             SP, SP, #0x18
    // 0x52f59c: mov             x1, x0
    // 0x52f5a0: b               #0x52f5a8
    // 0x52f5a4: ldur            x1, [fp, #-0xb8]
    // 0x52f5a8: ldur            x2, [fp, #-0xd0]
    // 0x52f5ac: mov             x0, x1
    // 0x52f5b0: stur            x1, [fp, #-0xb0]
    // 0x52f5b4: r0 = Await()
    //     0x52f5b4: bl              #0x4b8e6c  ; AwaitStub
    // 0x52f5b8: mov             x3, x0
    // 0x52f5bc: ldur            x2, [fp, #-0xd0]
    // 0x52f5c0: stur            x3, [fp, #-0xb0]
    // 0x52f5c4: StoreField: r2->field_1f = r0
    //     0x52f5c4: stur            w0, [x2, #0x1f]
    //     0x52f5c8: tbz             w0, #0, #0x52f5e4
    //     0x52f5cc: ldurb           w16, [x2, #-1]
    //     0x52f5d0: ldurb           w17, [x0, #-1]
    //     0x52f5d4: and             x16, x17, x16, lsr #2
    //     0x52f5d8: tst             x16, HEAP, lsr #32
    //     0x52f5dc: b.eq            #0x52f5e4
    //     0x52f5e0: bl              #0xd6828c
    // 0x52f5e4: r1 = <List<int>, Uint8List>
    //     0x52f5e4: add             x1, PP, #0x13, lsl #12  ; [pp+0x13420] TypeArguments: <List<int>, Uint8List>
    //     0x52f5e8: ldr             x1, [x1, #0x420]
    // 0x52f5ec: r0 = _StreamHandlerTransformer()
    //     0x52f5ec: bl              #0x52e47c  ; Allocate_StreamHandlerTransformerStub -> _StreamHandlerTransformer<X0, X1> (size=0x10)
    // 0x52f5f0: stur            x0, [fp, #-0xb8]
    // 0x52f5f4: r1 = 2
    //     0x52f5f4: mov             x1, #2
    // 0x52f5f8: r0 = AllocateContext()
    //     0x52f5f8: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52f5fc: mov             x3, x0
    // 0x52f600: ldur            x0, [fp, #-0xb8]
    // 0x52f604: stur            x3, [fp, #-0xc0]
    // 0x52f608: StoreField: r3->field_f = r0
    //     0x52f608: stur            w0, [x3, #0xf]
    // 0x52f60c: ldur            x2, [fp, #-0xd0]
    // 0x52f610: r1 = Function '<anonymous closure>':.
    //     0x52f610: add             x1, PP, #0x13, lsl #12  ; [pp+0x13428] AnonymousClosure: (0x5566c4), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f614: ldr             x1, [x1, #0x428]
    // 0x52f618: r0 = AllocateClosure()
    //     0x52f618: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f61c: ldur            x2, [fp, #-0xc0]
    // 0x52f620: StoreField: r2->field_13 = r0
    //     0x52f620: stur            w0, [x2, #0x13]
    // 0x52f624: r1 = Function '<anonymous closure>':.
    //     0x52f624: add             x1, PP, #0x13, lsl #12  ; [pp+0x13160] AnonymousClosure: (0x52e6b4), of [dart:async] _StreamHandlerTransformer<X0, X1>
    //     0x52f628: ldr             x1, [x1, #0x160]
    // 0x52f62c: r0 = AllocateClosure()
    //     0x52f62c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f630: mov             x1, x0
    // 0x52f634: r0 = <List<int>, Uint8List>
    //     0x52f634: add             x0, PP, #0x13, lsl #12  ; [pp+0x13420] TypeArguments: <List<int>, Uint8List>
    //     0x52f638: ldr             x0, [x0, #0x420]
    // 0x52f63c: StoreField: r1->field_7 = r0
    //     0x52f63c: stur            w0, [x1, #7]
    // 0x52f640: ldur            x0, [fp, #-0xb8]
    // 0x52f644: StoreField: r0->field_b = r1
    //     0x52f644: stur            w1, [x0, #0xb]
    // 0x52f648: r16 = <Uint8List>
    //     0x52f648: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0x52f64c: ldur            lr, [fp, #-0xb0]
    // 0x52f650: stp             lr, x16, [SP, #-0x10]!
    // 0x52f654: SaveReg r0
    //     0x52f654: str             x0, [SP, #-8]!
    // 0x52f658: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52f658: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52f65c: r0 = transform()
    //     0x52f65c: bl              #0x52e1e8  ; [dart:async] Stream::transform
    // 0x52f660: add             SP, SP, #0x18
    // 0x52f664: stur            x0, [fp, #-0xb8]
    // 0x52f668: r16 = <String, List<String>>
    //     0x52f668: add             x16, PP, #0x13, lsl #12  ; [pp+0x13010] TypeArguments: <String, List<String>>
    //     0x52f66c: ldr             x16, [x16, #0x10]
    // 0x52f670: ldr             lr, [THR, #0xe8]  ; THR::empty_array
    // 0x52f674: stp             lr, x16, [SP, #-0x10]!
    // 0x52f678: r0 = Map._fromLiteral()
    //     0x52f678: bl              #0x4caab8  ; [dart:core] Map::Map._fromLiteral
    // 0x52f67c: add             SP, SP, #0x10
    // 0x52f680: mov             x3, x0
    // 0x52f684: ldur            x2, [fp, #-0xd0]
    // 0x52f688: stur            x3, [fp, #-0xd8]
    // 0x52f68c: StoreField: r2->field_23 = r0
    //     0x52f68c: stur            w0, [x2, #0x23]
    //     0x52f690: tbz             w0, #0, #0x52f6ac
    //     0x52f694: ldurb           w16, [x2, #-1]
    //     0x52f698: ldurb           w17, [x0, #-1]
    //     0x52f69c: and             x16, x17, x16, lsr #2
    //     0x52f6a0: tst             x16, HEAP, lsr #32
    //     0x52f6a4: b.eq            #0x52f6ac
    //     0x52f6a8: bl              #0xd6828c
    // 0x52f6ac: ldur            x0, [fp, #-0xb0]
    // 0x52f6b0: LoadField: r4 = r0->field_b
    //     0x52f6b0: ldur            w4, [x0, #0xb]
    // 0x52f6b4: DecompressPointer r4
    //     0x52f6b4: add             x4, x4, HEAP, lsl #32
    // 0x52f6b8: stur            x4, [fp, #-0xc8]
    // 0x52f6bc: LoadField: r5 = r4->field_13
    //     0x52f6bc: ldur            w5, [x4, #0x13]
    // 0x52f6c0: DecompressPointer r5
    //     0x52f6c0: add             x5, x5, HEAP, lsl #32
    // 0x52f6c4: stur            x5, [fp, #-0xc0]
    // 0x52f6c8: r1 = Function '<anonymous closure>':.
    //     0x52f6c8: add             x1, PP, #0x13, lsl #12  ; [pp+0x13430] AnonymousClosure: (0x55666c), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f6cc: ldr             x1, [x1, #0x430]
    // 0x52f6d0: r0 = AllocateClosure()
    //     0x52f6d0: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f6d4: ldur            x16, [fp, #-0xc0]
    // 0x52f6d8: stp             x0, x16, [SP, #-0x10]!
    // 0x52f6dc: r0 = forEach()
    //     0x52f6dc: bl              #0x52fd40  ; [dart:_http] _HttpHeaders::forEach
    // 0x52f6e0: add             SP, SP, #0x10
    // 0x52f6e4: ldur            x0, [fp, #-0xc8]
    // 0x52f6e8: LoadField: r1 = r0->field_1b
    //     0x52f6e8: ldur            w1, [x0, #0x1b]
    // 0x52f6ec: DecompressPointer r1
    //     0x52f6ec: add             x1, x1, HEAP, lsl #32
    // 0x52f6f0: stur            x1, [fp, #-0xc0]
    // 0x52f6f4: cmp             w1, NULL
    // 0x52f6f8: b.eq            #0x52f960
    // 0x52f6fc: ldur            x16, [fp, #-0xb0]
    // 0x52f700: SaveReg r16
    //     0x52f700: str             x16, [SP, #-8]!
    // 0x52f704: r0 = isRedirect()
    //     0x52f704: bl              #0x52fbb4  ; [dart:_http] _HttpClientResponse::isRedirect
    // 0x52f708: add             SP, SP, #8
    // 0x52f70c: tbnz            w0, #4, #0x52f71c
    // 0x52f710: ldur            x0, [fp, #-0xb0]
    // 0x52f714: r5 = true
    //     0x52f714: add             x5, NULL, #0x20  ; true
    // 0x52f718: b               #0x52f74c
    // 0x52f71c: ldur            x0, [fp, #-0xb0]
    // 0x52f720: LoadField: r1 = r0->field_17
    //     0x52f720: ldur            w1, [x0, #0x17]
    // 0x52f724: DecompressPointer r1
    //     0x52f724: add             x1, x1, HEAP, lsl #32
    // 0x52f728: LoadField: r2 = r1->field_67
    //     0x52f728: ldur            w2, [x1, #0x67]
    // 0x52f72c: DecompressPointer r2
    //     0x52f72c: add             x2, x2, HEAP, lsl #32
    // 0x52f730: LoadField: r1 = r2->field_b
    //     0x52f730: ldur            w1, [x2, #0xb]
    // 0x52f734: DecompressPointer r1
    //     0x52f734: add             x1, x1, HEAP, lsl #32
    // 0x52f738: cbnz            w1, #0x52f744
    // 0x52f73c: r2 = false
    //     0x52f73c: add             x2, NULL, #0x30  ; false
    // 0x52f740: b               #0x52f748
    // 0x52f744: r2 = true
    //     0x52f744: add             x2, NULL, #0x20  ; true
    // 0x52f748: mov             x5, x2
    // 0x52f74c: ldur            x3, [fp, #-0xc8]
    // 0x52f750: ldur            x4, [fp, #-0xc0]
    // 0x52f754: stur            x5, [fp, #-0xd0]
    // 0x52f758: LoadField: r1 = r0->field_17
    //     0x52f758: ldur            w1, [x0, #0x17]
    // 0x52f75c: DecompressPointer r1
    //     0x52f75c: add             x1, x1, HEAP, lsl #32
    // 0x52f760: LoadField: r0 = r1->field_67
    //     0x52f760: ldur            w0, [x1, #0x67]
    // 0x52f764: DecompressPointer r0
    //     0x52f764: add             x0, x0, HEAP, lsl #32
    // 0x52f768: stur            x0, [fp, #-0xb0]
    // 0x52f76c: r1 = Function '<anonymous closure>':.
    //     0x52f76c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13438] AnonymousClosure: (0x55662c), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x52f770: ldr             x1, [x1, #0x438]
    // 0x52f774: r2 = Null
    //     0x52f774: mov             x2, NULL
    // 0x52f778: r0 = AllocateClosure()
    //     0x52f778: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52f77c: r16 = <RedirectRecord>
    //     0x52f77c: add             x16, PP, #0x13, lsl #12  ; [pp+0x13440] TypeArguments: <RedirectRecord>
    //     0x52f780: ldr             x16, [x16, #0x440]
    // 0x52f784: ldur            lr, [fp, #-0xb0]
    // 0x52f788: stp             lr, x16, [SP, #-0x10]!
    // 0x52f78c: SaveReg r0
    //     0x52f78c: str             x0, [SP, #-8]!
    // 0x52f790: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52f790: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52f794: r0 = map()
    //     0x52f794: bl              #0x78e06c  ; [dart:collection] _ListBase&Object&ListMixin::map
    // 0x52f798: add             SP, SP, #0x18
    // 0x52f79c: SaveReg r0
    //     0x52f79c: str             x0, [SP, #-8]!
    // 0x52f7a0: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x52f7a0: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x52f7a4: r0 = toList()
    //     0x52f7a4: bl              #0x792300  ; [dart:collection] __Set&_HashVMBase&SetMixin::toList
    // 0x52f7a8: add             SP, SP, #8
    // 0x52f7ac: mov             x1, x0
    // 0x52f7b0: ldur            x0, [fp, #-0xc8]
    // 0x52f7b4: stur            x1, [fp, #-0xe0]
    // 0x52f7b8: LoadField: r2 = r0->field_1f
    //     0x52f7b8: ldur            w2, [x0, #0x1f]
    // 0x52f7bc: DecompressPointer r2
    //     0x52f7bc: add             x2, x2, HEAP, lsl #32
    // 0x52f7c0: stur            x2, [fp, #-0xb0]
    // 0x52f7c4: cmp             w2, NULL
    // 0x52f7c8: b.eq            #0x52f964
    // 0x52f7cc: ldur            x0, [fp, #-0xc0]
    // 0x52f7d0: r3 = LoadInt32Instr(r0)
    //     0x52f7d0: sbfx            x3, x0, #1, #0x1f
    //     0x52f7d4: tbz             w0, #0, #0x52f7dc
    //     0x52f7d8: ldur            x3, [x0, #7]
    // 0x52f7dc: stur            x3, [fp, #-0xe8]
    // 0x52f7e0: r0 = ResponseBody()
    //     0x52f7e0: bl              #0x52fba8  ; AllocateResponseBodyStub -> ResponseBody (size=0x28)
    // 0x52f7e4: stur            x0, [fp, #-0xc0]
    // 0x52f7e8: ldur            x16, [fp, #-0xb8]
    // 0x52f7ec: stp             x16, x0, [SP, #-0x10]!
    // 0x52f7f0: ldur            x1, [fp, #-0xe8]
    // 0x52f7f4: ldur            x16, [fp, #-0xd8]
    // 0x52f7f8: stp             x16, x1, [SP, #-0x10]!
    // 0x52f7fc: ldur            x16, [fp, #-0xd0]
    // 0x52f800: ldur            lr, [fp, #-0xe0]
    // 0x52f804: stp             lr, x16, [SP, #-0x10]!
    // 0x52f808: ldur            x16, [fp, #-0xb0]
    // 0x52f80c: SaveReg r16
    //     0x52f80c: str             x16, [SP, #-8]!
    // 0x52f810: r0 = ResponseBody()
    //     0x52f810: bl              #0x52fa90  ; [package:dio/src/adapter.dart] ResponseBody::ResponseBody
    // 0x52f814: add             SP, SP, #0x38
    // 0x52f818: ldur            x0, [fp, #-0xc0]
    // 0x52f81c: r0 = ReturnAsyncNotFuture()
    //     0x52f81c: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x52f820: sub             SP, fp, #0xe8
    // 0x52f824: mov             x2, x0
    // 0x52f828: stur            x0, [fp, #-0xb0]
    // 0x52f82c: stur            x1, [fp, #-0xb8]
    // 0x52f830: r0 = LoadTaggedClassIdMayBeSmiInstr(r2)
    //     0x52f830: mov             x0, #0x76
    //     0x52f834: tbz             w2, #0, #0x52f844
    //     0x52f838: ldur            x0, [x2, #-1]
    //     0x52f83c: ubfx            x0, x0, #0xc, #0x14
    //     0x52f840: lsl             x0, x0, #1
    // 0x52f844: r17 = 10190
    //     0x52f844: mov             x17, #0x27ce
    // 0x52f848: cmp             w0, w17
    // 0x52f84c: b.ne            #0x52f8f8
    // 0x52f850: LoadField: r0 = r2->field_7
    //     0x52f850: ldur            w0, [x2, #7]
    // 0x52f854: DecompressPointer r0
    //     0x52f854: add             x0, x0, HEAP, lsl #32
    // 0x52f858: r3 = LoadClassIdInstr(r0)
    //     0x52f858: ldur            x3, [x0, #-1]
    //     0x52f85c: ubfx            x3, x3, #0xc, #0x14
    // 0x52f860: r16 = "timed out"
    //     0x52f860: add             x16, PP, #0x13, lsl #12  ; [pp+0x13448] "timed out"
    //     0x52f864: ldr             x16, [x16, #0x448]
    // 0x52f868: stp             x16, x0, [SP, #-0x10]!
    // 0x52f86c: mov             x0, x3
    // 0x52f870: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x52f870: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x52f874: r0 = GDT[cid_x0 + -0xffc]()
    //     0x52f874: sub             lr, x0, #0xffc
    //     0x52f878: ldr             lr, [x21, lr, lsl #3]
    //     0x52f87c: blr             lr
    // 0x52f880: add             SP, SP, #0x10
    // 0x52f884: tbnz            w0, #4, #0x52f8c0
    // 0x52f888: ldur            x0, [fp, #-0x38]
    // 0x52f88c: LoadField: r1 = r0->field_f
    //     0x52f88c: ldur            w1, [x0, #0xf]
    // 0x52f890: DecompressPointer r1
    //     0x52f890: add             x1, x1, HEAP, lsl #32
    // 0x52f894: LoadField: r0 = r1->field_4b
    //     0x52f894: ldur            w0, [x1, #0x4b]
    // 0x52f898: DecompressPointer r0
    //     0x52f898: add             x0, x0, HEAP, lsl #32
    // 0x52f89c: cmp             w0, NULL
    // 0x52f8a0: b.ne            #0x52f8b4
    // 0x52f8a4: ldur            x0, [fp, #-0x68]
    // 0x52f8a8: LoadField: r2 = r0->field_3b
    //     0x52f8a8: ldur            w2, [x0, #0x3b]
    // 0x52f8ac: DecompressPointer r2
    //     0x52f8ac: add             x2, x2, HEAP, lsl #32
    // 0x52f8b0: mov             x0, x2
    // 0x52f8b4: cmp             w0, NULL
    // 0x52f8b8: b.ne            #0x52f8d4
    // 0x52f8bc: b               #0x52f8d0
    // 0x52f8c0: ldur            x0, [fp, #-0xb0]
    // 0x52f8c4: ldur            x1, [fp, #-0xb8]
    // 0x52f8c8: r0 = ReThrow()
    //     0x52f8c8: bl              #0xd67e14  ; ReThrowStub
    // 0x52f8cc: brk             #0
    // 0x52f8d0: r0 = Instance_Duration
    //     0x52f8d0: ldr             x0, [PP, #0x33e0]  ; [pp+0x33e0] Obj!Duration@b67a11
    // 0x52f8d4: stp             x1, NULL, [SP, #-0x10]!
    // 0x52f8d8: ldur            x16, [fp, #-0xb0]
    // 0x52f8dc: stp             x16, x0, [SP, #-0x10]!
    // 0x52f8e0: r4 = const [0, 0x4, 0x4, 0x3, error, 0x3, null]
    //     0x52f8e0: add             x4, PP, #0x13, lsl #12  ; [pp+0x13450] List(7) [0, 0x4, 0x4, 0x3, "error", 0x3, Null]
    //     0x52f8e4: ldr             x4, [x4, #0x450]
    // 0x52f8e8: r0 = DioException.connectionTimeout()
    //     0x52f8e8: bl              #0x52f98c  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionTimeout
    // 0x52f8ec: add             SP, SP, #0x20
    // 0x52f8f0: r0 = Throw()
    //     0x52f8f0: bl              #0xd67e38  ; ThrowStub
    // 0x52f8f4: brk             #0
    // 0x52f8f8: ldur            x0, [fp, #-0xb0]
    // 0x52f8fc: ldur            x1, [fp, #-0xb8]
    // 0x52f900: r0 = ReThrow()
    //     0x52f900: bl              #0xd67e14  ; ReThrowStub
    // 0x52f904: brk             #0
    // 0x52f908: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52f908: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52f90c: b               #0x52f024
    // 0x52f910: r9 = method
    //     0x52f910: add             x9, PP, #0x13, lsl #12  ; [pp+0x13458] Field <_RequestConfig@361184022.method>: late (offset: 0x8)
    //     0x52f914: ldr             x9, [x9, #0x458]
    // 0x52f918: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52f918: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52f91c: r9 = _headers
    //     0x52f91c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x52f920: ldr             x9, [x9, #0xee0]
    // 0x52f924: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52f924: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52f928: r9 = followRedirects
    //     0x52f928: add             x9, PP, #0x13, lsl #12  ; [pp+0x13460] Field <_RequestConfig@361184022.followRedirects>: late (offset: 0x2c)
    //     0x52f92c: ldr             x9, [x9, #0x460]
    // 0x52f930: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52f930: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52f934: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52f934: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52f938: r9 = maxRedirects
    //     0x52f938: add             x9, PP, #0x13, lsl #12  ; [pp+0x13470] Field <_RequestConfig@361184022.maxRedirects>: late (offset: 0x30)
    //     0x52f93c: ldr             x9, [x9, #0x470]
    // 0x52f940: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52f940: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52f944: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52f944: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52f948: r9 = persistentConnection
    //     0x52f948: add             x9, PP, #0x13, lsl #12  ; [pp+0x13480] Field <_RequestConfig@361184022.persistentConnection>: late (offset: 0x34)
    //     0x52f94c: ldr             x9, [x9, #0x480]
    // 0x52f950: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52f950: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52f954: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52f954: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52f958: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52f958: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52f95c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52f95c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52f960: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x52f960: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
    // 0x52f964: r0 = NullCastErrorSharedWithoutFPURegs()
    //     0x52f964: bl              #0xd69fe0  ; NullCastErrorSharedWithoutFPURegsStub
  }
  _ _configHttpClient(/* No info */) {
    // ** addr: 0x554a34, size: 0x90
    // 0x554a34: EnterFrame
    //     0x554a34: stp             fp, lr, [SP, #-0x10]!
    //     0x554a38: mov             fp, SP
    // 0x554a3c: CheckStackOverflow
    //     0x554a3c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x554a40: cmp             SP, x16
    //     0x554a44: b.ls            #0x554abc
    // 0x554a48: ldr             x0, [fp, #0x18]
    // 0x554a4c: LoadField: r1 = r0->field_13
    //     0x554a4c: ldur            w1, [x0, #0x13]
    // 0x554a50: DecompressPointer r1
    //     0x554a50: add             x1, x1, HEAP, lsl #32
    // 0x554a54: cmp             w1, NULL
    // 0x554a58: b.ne            #0x554a8c
    // 0x554a5c: SaveReg r0
    //     0x554a5c: str             x0, [SP, #-8]!
    // 0x554a60: r0 = _createHttpClient()
    //     0x554a60: bl              #0x554ac4  ; [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_createHttpClient
    // 0x554a64: add             SP, SP, #8
    // 0x554a68: mov             x1, x0
    // 0x554a6c: ldr             x2, [fp, #0x18]
    // 0x554a70: StoreField: r2->field_13 = r0
    //     0x554a70: stur            w0, [x2, #0x13]
    //     0x554a74: ldurb           w16, [x2, #-1]
    //     0x554a78: ldurb           w17, [x0, #-1]
    //     0x554a7c: and             x16, x17, x16, lsr #2
    //     0x554a80: tst             x16, HEAP, lsr #32
    //     0x554a84: b.eq            #0x554a8c
    //     0x554a88: bl              #0xd6828c
    // 0x554a8c: ldr             x0, [fp, #0x10]
    // 0x554a90: StoreField: r1->field_3b = r0
    //     0x554a90: stur            w0, [x1, #0x3b]
    //     0x554a94: ldurb           w16, [x1, #-1]
    //     0x554a98: ldurb           w17, [x0, #-1]
    //     0x554a9c: and             x16, x17, x16, lsr #2
    //     0x554aa0: tst             x16, HEAP, lsr #32
    //     0x554aa4: b.eq            #0x554aac
    //     0x554aa8: bl              #0xd6826c
    // 0x554aac: mov             x0, x1
    // 0x554ab0: LeaveFrame
    //     0x554ab0: mov             SP, fp
    //     0x554ab4: ldp             fp, lr, [SP], #0x10
    // 0x554ab8: ret
    //     0x554ab8: ret             
    // 0x554abc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x554abc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x554ac0: b               #0x554a48
  }
  _ _createHttpClient(/* No info */) {
    // ** addr: 0x554ac4, size: 0x64
    // 0x554ac4: EnterFrame
    //     0x554ac4: stp             fp, lr, [SP, #-0x10]!
    //     0x554ac8: mov             fp, SP
    // 0x554acc: AllocStack(0x8)
    //     0x554acc: sub             SP, SP, #8
    // 0x554ad0: CheckStackOverflow
    //     0x554ad0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x554ad4: cmp             SP, x16
    //     0x554ad8: b.ls            #0x554b20
    // 0x554adc: SaveReg rNULL
    //     0x554adc: str             NULL, [SP, #-8]!
    // 0x554ae0: r0 = HttpClient()
    //     0x554ae0: bl              #0x554e8c  ; [dart:_http] HttpClient::HttpClient
    // 0x554ae4: add             SP, SP, #8
    // 0x554ae8: stur            x0, [fp, #-8]
    // 0x554aec: r0 = Duration()
    //     0x554aec: bl              #0x4b5364  ; AllocateDurationStub -> Duration (size=0x10)
    // 0x554af0: mov             x1, x0
    // 0x554af4: r0 = 3000000
    //     0x554af4: mov             x0, #0xc6c0
    //     0x554af8: movk            x0, #0x2d, lsl #16
    // 0x554afc: StoreField: r1->field_7 = r0
    //     0x554afc: stur            x0, [x1, #7]
    // 0x554b00: ldur            x16, [fp, #-8]
    // 0x554b04: stp             x1, x16, [SP, #-0x10]!
    // 0x554b08: r0 = idleTimeout=()
    //     0x554b08: bl              #0x554b28  ; [dart:_http] _HttpClient::idleTimeout=
    // 0x554b0c: add             SP, SP, #0x10
    // 0x554b10: ldur            x0, [fp, #-8]
    // 0x554b14: LeaveFrame
    //     0x554b14: mov             SP, fp
    //     0x554b18: ldp             fp, lr, [SP], #0x10
    // 0x554b1c: ret
    //     0x554b1c: ret             
    // 0x554b20: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x554b20: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x554b24: b               #0x554adc
  }
  [closure] RedirectRecord <anonymous closure>(dynamic, RedirectInfo) {
    // ** addr: 0x55662c, size: 0x34
    // 0x55662c: EnterFrame
    //     0x55662c: stp             fp, lr, [SP, #-0x10]!
    //     0x556630: mov             fp, SP
    // 0x556634: AllocStack(0x8)
    //     0x556634: sub             SP, SP, #8
    // 0x556638: ldr             x0, [fp, #0x10]
    // 0x55663c: LoadField: r1 = r0->field_13
    //     0x55663c: ldur            w1, [x0, #0x13]
    // 0x556640: DecompressPointer r1
    //     0x556640: add             x1, x1, HEAP, lsl #32
    // 0x556644: stur            x1, [fp, #-8]
    // 0x556648: r0 = RedirectRecord()
    //     0x556648: bl              #0x556660  ; AllocateRedirectRecordStub -> RedirectRecord (size=0xc)
    // 0x55664c: ldur            x1, [fp, #-8]
    // 0x556650: StoreField: r0->field_7 = r1
    //     0x556650: stur            w1, [x0, #7]
    // 0x556654: LeaveFrame
    //     0x556654: mov             SP, fp
    //     0x556658: ldp             fp, lr, [SP], #0x10
    // 0x55665c: ret
    //     0x55665c: ret             
  }
  [closure] void <anonymous closure>(dynamic, String, List<String>) {
    // ** addr: 0x55666c, size: 0x58
    // 0x55666c: EnterFrame
    //     0x55666c: stp             fp, lr, [SP, #-0x10]!
    //     0x556670: mov             fp, SP
    // 0x556674: ldr             x0, [fp, #0x20]
    // 0x556678: LoadField: r1 = r0->field_17
    //     0x556678: ldur            w1, [x0, #0x17]
    // 0x55667c: DecompressPointer r1
    //     0x55667c: add             x1, x1, HEAP, lsl #32
    // 0x556680: CheckStackOverflow
    //     0x556680: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x556684: cmp             SP, x16
    //     0x556688: b.ls            #0x5566bc
    // 0x55668c: LoadField: r0 = r1->field_23
    //     0x55668c: ldur            w0, [x1, #0x23]
    // 0x556690: DecompressPointer r0
    //     0x556690: add             x0, x0, HEAP, lsl #32
    // 0x556694: ldr             x16, [fp, #0x18]
    // 0x556698: stp             x16, x0, [SP, #-0x10]!
    // 0x55669c: ldr             x16, [fp, #0x10]
    // 0x5566a0: SaveReg r16
    //     0x5566a0: str             x16, [SP, #-8]!
    // 0x5566a4: r0 = []=()
    //     0x5566a4: bl              #0xcae790  ; [dart:collection] __Map&_HashVMBase&MapMixin&_HashBase&_OperatorEqualsAndHashCode&_LinkedHashMapMixin::[]=
    // 0x5566a8: add             SP, SP, #0x18
    // 0x5566ac: r0 = Null
    //     0x5566ac: mov             x0, NULL
    // 0x5566b0: LeaveFrame
    //     0x5566b0: mov             SP, fp
    //     0x5566b4: ldp             fp, lr, [SP], #0x10
    // 0x5566b8: ret
    //     0x5566b8: ret             
    // 0x5566bc: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5566bc: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5566c0: b               #0x55668c
  }
  [closure] void <anonymous closure>(dynamic, List<int>, EventSink<Uint8List>) {
    // ** addr: 0x5566c4, size: 0x168
    // 0x5566c4: EnterFrame
    //     0x5566c4: stp             fp, lr, [SP, #-0x10]!
    //     0x5566c8: mov             fp, SP
    // 0x5566cc: AllocStack(0x10)
    //     0x5566cc: sub             SP, SP, #0x10
    // 0x5566d0: SetupParameters()
    //     0x5566d0: ldr             x0, [fp, #0x20]
    //     0x5566d4: ldur            w1, [x0, #0x17]
    //     0x5566d8: add             x1, x1, HEAP, lsl #32
    //     0x5566dc: stur            x1, [fp, #-0x10]
    // 0x5566e0: CheckStackOverflow
    //     0x5566e0: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5566e4: cmp             SP, x16
    //     0x5566e8: b.ls            #0x556824
    // 0x5566ec: LoadField: r0 = r1->field_17
    //     0x5566ec: ldur            w0, [x1, #0x17]
    // 0x5566f0: DecompressPointer r0
    //     0x5566f0: add             x0, x0, HEAP, lsl #32
    // 0x5566f4: stur            x0, [fp, #-8]
    // 0x5566f8: SaveReg r0
    //     0x5566f8: str             x0, [SP, #-8]!
    // 0x5566fc: r0 = stop()
    //     0x5566fc: bl              #0x4ffb60  ; [dart:core] Stopwatch::stop
    // 0x556700: add             SP, SP, #8
    // 0x556704: ldur            x16, [fp, #-8]
    // 0x556708: SaveReg r16
    //     0x556708: str             x16, [SP, #-8]!
    // 0x55670c: r0 = elapsedMicroseconds()
    //     0x55670c: bl              #0x4ffc14  ; [dart:core] Stopwatch::elapsedMicroseconds
    // 0x556710: add             SP, SP, #8
    // 0x556714: mov             x1, x0
    // 0x556718: ldur            x0, [fp, #-0x10]
    // 0x55671c: LoadField: r2 = r0->field_f
    //     0x55671c: ldur            w2, [x0, #0xf]
    // 0x556720: DecompressPointer r2
    //     0x556720: add             x2, x2, HEAP, lsl #32
    // 0x556724: LoadField: r3 = r2->field_13
    //     0x556724: ldur            w3, [x2, #0x13]
    // 0x556728: DecompressPointer r3
    //     0x556728: add             x3, x3, HEAP, lsl #32
    // 0x55672c: cmp             w3, NULL
    // 0x556730: b.eq            #0x5567d8
    // 0x556734: LoadField: r4 = r3->field_7
    //     0x556734: ldur            x4, [x3, #7]
    // 0x556738: cmp             x1, x4
    // 0x55673c: b.le            #0x5567d0
    // 0x556740: ldr             x1, [fp, #0x10]
    // 0x556744: stp             x2, NULL, [SP, #-0x10]!
    // 0x556748: SaveReg r3
    //     0x556748: str             x3, [SP, #-8]!
    // 0x55674c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x55674c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x556750: r0 = DioException.receiveTimeout()
    //     0x556750: bl              #0x556c64  ; [package:dio/src/dio_exception.dart] DioException::DioException.receiveTimeout
    // 0x556754: add             SP, SP, #0x18
    // 0x556758: mov             x1, x0
    // 0x55675c: ldr             x0, [fp, #0x10]
    // 0x556760: r2 = LoadClassIdInstr(r0)
    //     0x556760: ldur            x2, [x0, #-1]
    //     0x556764: ubfx            x2, x2, #0xc, #0x14
    // 0x556768: stp             x1, x0, [SP, #-0x10]!
    // 0x55676c: mov             x0, x2
    // 0x556770: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x556770: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x556774: r0 = GDT[cid_x0 + 0x7c6]()
    //     0x556774: add             lr, x0, #0x7c6
    //     0x556778: ldr             lr, [x21, lr, lsl #3]
    //     0x55677c: blr             lr
    // 0x556780: add             SP, SP, #0x10
    // 0x556784: ldur            x0, [fp, #-0x10]
    // 0x556788: LoadField: r1 = r0->field_1f
    //     0x556788: ldur            w1, [x0, #0x1f]
    // 0x55678c: DecompressPointer r1
    //     0x55678c: add             x1, x1, HEAP, lsl #32
    // 0x556790: SaveReg r1
    //     0x556790: str             x1, [SP, #-8]!
    // 0x556794: r0 = detachSocket()
    //     0x556794: bl              #0x55682c  ; [dart:_http] _HttpClientResponse::detachSocket
    // 0x556798: add             SP, SP, #8
    // 0x55679c: r1 = Function '<anonymous closure>':.
    //     0x55679c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13498] AnonymousClosure: (0x556d68), in [package:dio/src/adapters/io_adapter.dart] IOHttpClientAdapter::_fetch (0x52efd4)
    //     0x5567a0: ldr             x1, [x1, #0x498]
    // 0x5567a4: r2 = Null
    //     0x5567a4: mov             x2, NULL
    // 0x5567a8: stur            x0, [fp, #-8]
    // 0x5567ac: r0 = AllocateClosure()
    //     0x5567ac: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x5567b0: r16 = <void?>
    //     0x5567b0: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x5567b4: ldur            lr, [fp, #-8]
    // 0x5567b8: stp             lr, x16, [SP, #-0x10]!
    // 0x5567bc: SaveReg r0
    //     0x5567bc: str             x0, [SP, #-8]!
    // 0x5567c0: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x5567c0: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x5567c4: r0 = then()
    //     0x5567c4: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x5567c8: add             SP, SP, #0x18
    // 0x5567cc: b               #0x556814
    // 0x5567d0: ldr             x0, [fp, #0x10]
    // 0x5567d4: b               #0x5567dc
    // 0x5567d8: ldr             x0, [fp, #0x10]
    // 0x5567dc: ldr             x16, [fp, #0x18]
    // 0x5567e0: stp             x16, NULL, [SP, #-0x10]!
    // 0x5567e4: r0 = Uint8List.fromList()
    //     0x5567e4: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x5567e8: add             SP, SP, #0x10
    // 0x5567ec: mov             x1, x0
    // 0x5567f0: ldr             x0, [fp, #0x10]
    // 0x5567f4: r2 = LoadClassIdInstr(r0)
    //     0x5567f4: ldur            x2, [x0, #-1]
    //     0x5567f8: ubfx            x2, x2, #0xc, #0x14
    // 0x5567fc: stp             x1, x0, [SP, #-0x10]!
    // 0x556800: mov             x0, x2
    // 0x556804: r0 = GDT[cid_x0 + 0x6e6]()
    //     0x556804: add             lr, x0, #0x6e6
    //     0x556808: ldr             lr, [x21, lr, lsl #3]
    //     0x55680c: blr             lr
    // 0x556810: add             SP, SP, #0x10
    // 0x556814: r0 = Null
    //     0x556814: mov             x0, NULL
    // 0x556818: LeaveFrame
    //     0x556818: mov             SP, fp
    //     0x55681c: ldp             fp, lr, [SP], #0x10
    // 0x556820: ret
    //     0x556820: ret             
    // 0x556824: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556824: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556828: b               #0x5566ec
  }
  [closure] void <anonymous closure>(dynamic, Socket) {
    // ** addr: 0x556d68, size: 0x4c
    // 0x556d68: EnterFrame
    //     0x556d68: stp             fp, lr, [SP, #-0x10]!
    //     0x556d6c: mov             fp, SP
    // 0x556d70: CheckStackOverflow
    //     0x556d70: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x556d74: cmp             SP, x16
    //     0x556d78: b.ls            #0x556dac
    // 0x556d7c: ldr             x0, [fp, #0x10]
    // 0x556d80: r1 = LoadClassIdInstr(r0)
    //     0x556d80: ldur            x1, [x0, #-1]
    //     0x556d84: ubfx            x1, x1, #0xc, #0x14
    // 0x556d88: SaveReg r0
    //     0x556d88: str             x0, [SP, #-8]!
    // 0x556d8c: mov             x0, x1
    // 0x556d90: r0 = GDT[cid_x0 + -0xfe0]()
    //     0x556d90: sub             lr, x0, #0xfe0
    //     0x556d94: ldr             lr, [x21, lr, lsl #3]
    //     0x556d98: blr             lr
    // 0x556d9c: add             SP, SP, #8
    // 0x556da0: LeaveFrame
    //     0x556da0: mov             SP, fp
    //     0x556da4: ldp             fp, lr, [SP], #0x10
    // 0x556da8: ret
    //     0x556da8: ret             
    // 0x556dac: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556dac: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556db0: b               #0x556d7c
  }
  [closure] Never <anonymous closure>(dynamic) {
    // ** addr: 0x556db4, size: 0x54
    // 0x556db4: EnterFrame
    //     0x556db4: stp             fp, lr, [SP, #-0x10]!
    //     0x556db8: mov             fp, SP
    // 0x556dbc: ldr             x0, [fp, #0x10]
    // 0x556dc0: LoadField: r1 = r0->field_17
    //     0x556dc0: ldur            w1, [x0, #0x17]
    // 0x556dc4: DecompressPointer r1
    //     0x556dc4: add             x1, x1, HEAP, lsl #32
    // 0x556dc8: CheckStackOverflow
    //     0x556dc8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x556dcc: cmp             SP, x16
    //     0x556dd0: b.ls            #0x556e00
    // 0x556dd4: LoadField: r0 = r1->field_f
    //     0x556dd4: ldur            w0, [x1, #0xf]
    // 0x556dd8: DecompressPointer r0
    //     0x556dd8: add             x0, x0, HEAP, lsl #32
    // 0x556ddc: LoadField: r2 = r1->field_1b
    //     0x556ddc: ldur            w2, [x1, #0x1b]
    // 0x556de0: DecompressPointer r2
    //     0x556de0: add             x2, x2, HEAP, lsl #32
    // 0x556de4: stp             x0, NULL, [SP, #-0x10]!
    // 0x556de8: SaveReg r2
    //     0x556de8: str             x2, [SP, #-8]!
    // 0x556dec: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x556dec: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x556df0: r0 = DioException.receiveTimeout()
    //     0x556df0: bl              #0x556c64  ; [package:dio/src/dio_exception.dart] DioException::DioException.receiveTimeout
    // 0x556df4: add             SP, SP, #0x18
    // 0x556df8: r0 = Throw()
    //     0x556df8: bl              #0xd67e38  ; ThrowStub
    // 0x556dfc: brk             #0
    // 0x556e00: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556e00: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556e04: b               #0x556dd4
  }
  [closure] Never <anonymous closure>(dynamic) {
    // ** addr: 0x556e08, size: 0xa8
    // 0x556e08: EnterFrame
    //     0x556e08: stp             fp, lr, [SP, #-0x10]!
    //     0x556e0c: mov             fp, SP
    // 0x556e10: AllocStack(0x8)
    //     0x556e10: sub             SP, SP, #8
    // 0x556e14: SetupParameters()
    //     0x556e14: ldr             x0, [fp, #0x10]
    //     0x556e18: ldur            w1, [x0, #0x17]
    //     0x556e1c: add             x1, x1, HEAP, lsl #32
    //     0x556e20: stur            x1, [fp, #-8]
    // 0x556e24: CheckStackOverflow
    //     0x556e24: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x556e28: cmp             SP, x16
    //     0x556e2c: b.ls            #0x556ea4
    // 0x556e30: LoadField: r0 = r1->field_13
    //     0x556e30: ldur            w0, [x1, #0x13]
    // 0x556e34: DecompressPointer r0
    //     0x556e34: add             x0, x0, HEAP, lsl #32
    // 0x556e38: r16 = Sentinel
    //     0x556e38: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x556e3c: cmp             w0, w16
    // 0x556e40: b.ne            #0x556e54
    // 0x556e44: r16 = "request"
    //     0x556e44: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x556e48: SaveReg r16
    //     0x556e48: str             x16, [SP, #-8]!
    // 0x556e4c: r0 = _throwLocalNotInitialized()
    //     0x556e4c: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x556e50: add             SP, SP, #8
    // 0x556e54: ldur            x0, [fp, #-8]
    // 0x556e58: LoadField: r1 = r0->field_13
    //     0x556e58: ldur            w1, [x0, #0x13]
    // 0x556e5c: DecompressPointer r1
    //     0x556e5c: add             x1, x1, HEAP, lsl #32
    // 0x556e60: cmp             w1, NULL
    // 0x556e64: b.eq            #0x556eac
    // 0x556e68: SaveReg r1
    //     0x556e68: str             x1, [SP, #-8]!
    // 0x556e6c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x556e6c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x556e70: r0 = abort()
    //     0x556e70: bl              #0x556f50  ; [dart:_http] _HttpClientRequest::abort
    // 0x556e74: add             SP, SP, #8
    // 0x556e78: ldur            x0, [fp, #-8]
    // 0x556e7c: LoadField: r1 = r0->field_f
    //     0x556e7c: ldur            w1, [x0, #0xf]
    // 0x556e80: DecompressPointer r1
    //     0x556e80: add             x1, x1, HEAP, lsl #32
    // 0x556e84: LoadField: r2 = r0->field_27
    //     0x556e84: ldur            w2, [x0, #0x27]
    // 0x556e88: DecompressPointer r2
    //     0x556e88: add             x2, x2, HEAP, lsl #32
    // 0x556e8c: stp             x1, NULL, [SP, #-0x10]!
    // 0x556e90: SaveReg r2
    //     0x556e90: str             x2, [SP, #-8]!
    // 0x556e94: r0 = DioException.sendTimeout()
    //     0x556e94: bl              #0x556eb0  ; [package:dio/src/dio_exception.dart] DioException::DioException.sendTimeout
    // 0x556e98: add             SP, SP, #0x18
    // 0x556e9c: r0 = Throw()
    //     0x556e9c: bl              #0xd67e38  ; ThrowStub
    // 0x556ea0: brk             #0
    // 0x556ea4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x556ea4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x556ea8: b               #0x556e30
    // 0x556eac: r0 = NullErrorSharedWithoutFPURegs()
    //     0x556eac: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, String, dynamic) {
    // ** addr: 0x557014, size: 0xa8
    // 0x557014: EnterFrame
    //     0x557014: stp             fp, lr, [SP, #-0x10]!
    //     0x557018: mov             fp, SP
    // 0x55701c: AllocStack(0x8)
    //     0x55701c: sub             SP, SP, #8
    // 0x557020: SetupParameters()
    //     0x557020: ldr             x0, [fp, #0x20]
    //     0x557024: ldur            w1, [x0, #0x17]
    //     0x557028: add             x1, x1, HEAP, lsl #32
    //     0x55702c: stur            x1, [fp, #-8]
    // 0x557030: CheckStackOverflow
    //     0x557030: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x557034: cmp             SP, x16
    //     0x557038: b.ls            #0x5570b0
    // 0x55703c: ldr             x0, [fp, #0x10]
    // 0x557040: cmp             w0, NULL
    // 0x557044: b.eq            #0x5570a0
    // 0x557048: LoadField: r2 = r1->field_13
    //     0x557048: ldur            w2, [x1, #0x13]
    // 0x55704c: DecompressPointer r2
    //     0x55704c: add             x2, x2, HEAP, lsl #32
    // 0x557050: r16 = Sentinel
    //     0x557050: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x557054: cmp             w2, w16
    // 0x557058: b.ne            #0x55706c
    // 0x55705c: r16 = "request"
    //     0x55705c: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x557060: SaveReg r16
    //     0x557060: str             x16, [SP, #-8]!
    // 0x557064: r0 = _throwLocalNotInitialized()
    //     0x557064: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x557068: add             SP, SP, #8
    // 0x55706c: ldur            x0, [fp, #-8]
    // 0x557070: LoadField: r1 = r0->field_13
    //     0x557070: ldur            w1, [x0, #0x13]
    // 0x557074: DecompressPointer r1
    //     0x557074: add             x1, x1, HEAP, lsl #32
    // 0x557078: cmp             w1, NULL
    // 0x55707c: b.eq            #0x5570b8
    // 0x557080: LoadField: r0 = r1->field_37
    //     0x557080: ldur            w0, [x1, #0x37]
    // 0x557084: DecompressPointer r0
    //     0x557084: add             x0, x0, HEAP, lsl #32
    // 0x557088: ldr             x16, [fp, #0x18]
    // 0x55708c: stp             x16, x0, [SP, #-0x10]!
    // 0x557090: ldr             x16, [fp, #0x10]
    // 0x557094: SaveReg r16
    //     0x557094: str             x16, [SP, #-8]!
    // 0x557098: r0 = set()
    //     0x557098: bl              #0x5415dc  ; [dart:_http] _HttpHeaders::set
    // 0x55709c: add             SP, SP, #0x18
    // 0x5570a0: r0 = Null
    //     0x5570a0: mov             x0, NULL
    // 0x5570a4: LeaveFrame
    //     0x5570a4: mov             SP, fp
    //     0x5570a8: ldp             fp, lr, [SP], #0x10
    // 0x5570ac: ret
    //     0x5570ac: ret             
    // 0x5570b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5570b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5570b4: b               #0x55703c
    // 0x5570b8: r0 = NullErrorSharedWithoutFPURegs()
    //     0x5570b8: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x5570bc, size: 0x88
    // 0x5570bc: EnterFrame
    //     0x5570bc: stp             fp, lr, [SP, #-0x10]!
    //     0x5570c0: mov             fp, SP
    // 0x5570c4: AllocStack(0x8)
    //     0x5570c4: sub             SP, SP, #8
    // 0x5570c8: SetupParameters()
    //     0x5570c8: ldr             x0, [fp, #0x10]
    //     0x5570cc: ldur            w1, [x0, #0x17]
    //     0x5570d0: add             x1, x1, HEAP, lsl #32
    //     0x5570d4: stur            x1, [fp, #-8]
    // 0x5570d8: CheckStackOverflow
    //     0x5570d8: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5570dc: cmp             SP, x16
    //     0x5570e0: b.ls            #0x557138
    // 0x5570e4: LoadField: r0 = r1->field_13
    //     0x5570e4: ldur            w0, [x1, #0x13]
    // 0x5570e8: DecompressPointer r0
    //     0x5570e8: add             x0, x0, HEAP, lsl #32
    // 0x5570ec: r16 = Sentinel
    //     0x5570ec: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5570f0: cmp             w0, w16
    // 0x5570f4: b.ne            #0x557108
    // 0x5570f8: r16 = "request"
    //     0x5570f8: ldr             x16, [PP, #0x2ac8]  ; [pp+0x2ac8] "request"
    // 0x5570fc: SaveReg r16
    //     0x5570fc: str             x16, [SP, #-8]!
    // 0x557100: r0 = _throwLocalNotInitialized()
    //     0x557100: bl              #0x4fb888  ; [dart:_internal] LateError::_throwLocalNotInitialized
    // 0x557104: add             SP, SP, #8
    // 0x557108: ldur            x0, [fp, #-8]
    // 0x55710c: LoadField: r1 = r0->field_13
    //     0x55710c: ldur            w1, [x0, #0x13]
    // 0x557110: DecompressPointer r1
    //     0x557110: add             x1, x1, HEAP, lsl #32
    // 0x557114: cmp             w1, NULL
    // 0x557118: b.eq            #0x557140
    // 0x55711c: SaveReg r1
    //     0x55711c: str             x1, [SP, #-8]!
    // 0x557120: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x557120: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x557124: r0 = abort()
    //     0x557124: bl              #0x556f50  ; [dart:_http] _HttpClientRequest::abort
    // 0x557128: add             SP, SP, #8
    // 0x55712c: LeaveFrame
    //     0x55712c: mov             SP, fp
    //     0x557130: ldp             fp, lr, [SP], #0x10
    // 0x557134: ret
    //     0x557134: ret             
    // 0x557138: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557138: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55713c: b               #0x5570e4
    // 0x557140: r0 = NullErrorSharedWithoutFPURegs()
    //     0x557140: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  [closure] Never <anonymous closure>(dynamic) {
    // ** addr: 0x557144, size: 0x54
    // 0x557144: EnterFrame
    //     0x557144: stp             fp, lr, [SP, #-0x10]!
    //     0x557148: mov             fp, SP
    // 0x55714c: ldr             x0, [fp, #0x10]
    // 0x557150: LoadField: r1 = r0->field_17
    //     0x557150: ldur            w1, [x0, #0x17]
    // 0x557154: DecompressPointer r1
    //     0x557154: add             x1, x1, HEAP, lsl #32
    // 0x557158: CheckStackOverflow
    //     0x557158: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55715c: cmp             SP, x16
    //     0x557160: b.ls            #0x557190
    // 0x557164: LoadField: r0 = r1->field_f
    //     0x557164: ldur            w0, [x1, #0xf]
    // 0x557168: DecompressPointer r0
    //     0x557168: add             x0, x0, HEAP, lsl #32
    // 0x55716c: LoadField: r2 = r1->field_2b
    //     0x55716c: ldur            w2, [x1, #0x2b]
    // 0x557170: DecompressPointer r2
    //     0x557170: add             x2, x2, HEAP, lsl #32
    // 0x557174: stp             x0, NULL, [SP, #-0x10]!
    // 0x557178: SaveReg r2
    //     0x557178: str             x2, [SP, #-8]!
    // 0x55717c: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x55717c: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x557180: r0 = DioException.connectionTimeout()
    //     0x557180: bl              #0x52f98c  ; [package:dio/src/dio_exception.dart] DioException::DioException.connectionTimeout
    // 0x557184: add             SP, SP, #0x18
    // 0x557188: r0 = Throw()
    //     0x557188: bl              #0xd67e38  ; ThrowStub
    // 0x55718c: brk             #0
    // 0x557190: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557190: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x557194: b               #0x557164
  }
  [closure] Future<dynamic> <anonymous closure>(dynamic) {
    // ** addr: 0x557198, size: 0x48
    // 0x557198: EnterFrame
    //     0x557198: stp             fp, lr, [SP, #-0x10]!
    //     0x55719c: mov             fp, SP
    // 0x5571a0: ldr             x0, [fp, #0x10]
    // 0x5571a4: LoadField: r1 = r0->field_17
    //     0x5571a4: ldur            w1, [x0, #0x17]
    // 0x5571a8: DecompressPointer r1
    //     0x5571a8: add             x1, x1, HEAP, lsl #32
    // 0x5571ac: CheckStackOverflow
    //     0x5571ac: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5571b0: cmp             SP, x16
    //     0x5571b4: b.ls            #0x5571d8
    // 0x5571b8: LoadField: r0 = r1->field_f
    //     0x5571b8: ldur            w0, [x1, #0xf]
    // 0x5571bc: DecompressPointer r0
    //     0x5571bc: add             x0, x0, HEAP, lsl #32
    // 0x5571c0: SaveReg r0
    //     0x5571c0: str             x0, [SP, #-8]!
    // 0x5571c4: r0 = cancel()
    //     0x5571c4: bl              #0x5571e0  ; [package:async/src/cancelable_operation.dart] CancelableOperation::cancel
    // 0x5571c8: add             SP, SP, #8
    // 0x5571cc: LeaveFrame
    //     0x5571cc: mov             SP, fp
    //     0x5571d0: ldp             fp, lr, [SP], #0x10
    // 0x5571d4: ret
    //     0x5571d4: ret             
    // 0x5571d8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5571d8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5571dc: b               #0x5571b8
  }
  _ close(/* No info */) {
    // ** addr: 0xa576c8, size: 0x58
    // 0xa576c8: EnterFrame
    //     0xa576c8: stp             fp, lr, [SP, #-0x10]!
    //     0xa576cc: mov             fp, SP
    // 0xa576d0: r0 = true
    //     0xa576d0: add             x0, NULL, #0x20  ; true
    // 0xa576d4: CheckStackOverflow
    //     0xa576d4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0xa576d8: cmp             SP, x16
    //     0xa576dc: b.ls            #0xa57718
    // 0xa576e0: ldr             x1, [fp, #0x18]
    // 0xa576e4: StoreField: r1->field_17 = r0
    //     0xa576e4: stur            w0, [x1, #0x17]
    // 0xa576e8: LoadField: r0 = r1->field_13
    //     0xa576e8: ldur            w0, [x1, #0x13]
    // 0xa576ec: DecompressPointer r0
    //     0xa576ec: add             x0, x0, HEAP, lsl #32
    // 0xa576f0: cmp             w0, NULL
    // 0xa576f4: b.eq            #0xa57708
    // 0xa576f8: r16 = false
    //     0xa576f8: add             x16, NULL, #0x30  ; false
    // 0xa576fc: stp             x16, x0, [SP, #-0x10]!
    // 0xa57700: r0 = close()
    //     0xa57700: bl              #0xa57720  ; [dart:_http] _HttpClient::close
    // 0xa57704: add             SP, SP, #0x10
    // 0xa57708: r0 = Null
    //     0xa57708: mov             x0, NULL
    // 0xa5770c: LeaveFrame
    //     0xa5770c: mov             SP, fp
    //     0xa57710: ldp             fp, lr, [SP], #0x10
    // 0xa57714: ret
    //     0xa57714: ret             
    // 0xa57718: r0 = StackOverflowSharedWithoutFPURegs()
    //     0xa57718: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0xa5771c: b               #0xa576e0
  }
}

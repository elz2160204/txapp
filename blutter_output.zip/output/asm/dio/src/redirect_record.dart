// lib: , url: package:dio/src/redirect_record.dart

// class id: 1048897, size: 0x8
class :: {
}

// class id: 4527, size: 0xc, field offset: 0x8
class RedirectRecord extends Object {
}

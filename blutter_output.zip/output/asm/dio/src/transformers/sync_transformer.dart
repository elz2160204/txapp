// lib: , url: package:dio/src/transformers/sync_transformer.dart

// class id: 1048901, size: 0x8
class :: {
}

// class id: 4524, size: 0x10, field offset: 0x8
abstract class SyncTransformer extends Transformer {

  _ transformResponse(/* No info */) async {
    // ** addr: 0x52ae28, size: 0x680
    // 0x52ae28: EnterFrame
    //     0x52ae28: stp             fp, lr, [SP, #-0x10]!
    //     0x52ae2c: mov             fp, SP
    // 0x52ae30: AllocStack(0x68)
    //     0x52ae30: sub             SP, SP, #0x68
    // 0x52ae34: SetupParameters(SyncTransformer this /* r1, fp-0x20 */, dynamic _ /* r2, fp-0x18 */, dynamic _ /* r3, fp-0x10 */)
    //     0x52ae34: stur            NULL, [fp, #-8]
    //     0x52ae38: mov             x0, #0
    //     0x52ae3c: add             x1, fp, w0, sxtw #2
    //     0x52ae40: ldr             x1, [x1, #0x20]
    //     0x52ae44: stur            x1, [fp, #-0x20]
    //     0x52ae48: add             x2, fp, w0, sxtw #2
    //     0x52ae4c: ldr             x2, [x2, #0x18]
    //     0x52ae50: stur            x2, [fp, #-0x18]
    //     0x52ae54: add             x3, fp, w0, sxtw #2
    //     0x52ae58: ldr             x3, [x3, #0x10]
    //     0x52ae5c: stur            x3, [fp, #-0x10]
    // 0x52ae60: CheckStackOverflow
    //     0x52ae60: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52ae64: cmp             SP, x16
    //     0x52ae68: b.ls            #0x52b474
    // 0x52ae6c: r1 = 7
    //     0x52ae6c: mov             x1, #7
    // 0x52ae70: r0 = AllocateContext()
    //     0x52ae70: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52ae74: mov             x1, x0
    // 0x52ae78: ldur            x0, [fp, #-0x18]
    // 0x52ae7c: stur            x1, [fp, #-0x28]
    // 0x52ae80: StoreField: r1->field_f = r0
    //     0x52ae80: stur            w0, [x1, #0xf]
    // 0x52ae84: InitAsync() -> Future
    //     0x52ae84: mov             x0, NULL
    //     0x52ae88: bl              #0x4b92e4
    // 0x52ae8c: ldur            x2, [fp, #-0x28]
    // 0x52ae90: LoadField: r0 = r2->field_f
    //     0x52ae90: ldur            w0, [x2, #0xf]
    // 0x52ae94: DecompressPointer r0
    //     0x52ae94: add             x0, x0, HEAP, lsl #32
    // 0x52ae98: LoadField: r1 = r0->field_1b
    //     0x52ae98: ldur            w1, [x0, #0x1b]
    // 0x52ae9c: DecompressPointer r1
    //     0x52ae9c: add             x1, x1, HEAP, lsl #32
    // 0x52aea0: r16 = Sentinel
    //     0x52aea0: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52aea4: cmp             w1, w16
    // 0x52aea8: b.eq            #0x52b47c
    // 0x52aeac: r16 = Instance_ResponseType
    //     0x52aeac: add             x16, PP, #0x12, lsl #12  ; [pp+0x12df8] Obj!ResponseType@b66571
    //     0x52aeb0: ldr             x16, [x16, #0xdf8]
    // 0x52aeb4: cmp             w1, w16
    // 0x52aeb8: b.ne            #0x52aec4
    // 0x52aebc: ldur            x0, [fp, #-0x10]
    // 0x52aec0: r0 = ReturnAsyncNotFuture()
    //     0x52aec0: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x52aec4: ldur            x0, [fp, #-0x10]
    // 0x52aec8: r1 = false
    //     0x52aec8: add             x1, NULL, #0x30  ; false
    // 0x52aecc: StoreField: r2->field_13 = rZR
    //     0x52aecc: stur            wzr, [x2, #0x13]
    // 0x52aed0: StoreField: r2->field_17 = r1
    //     0x52aed0: stur            w1, [x2, #0x17]
    // 0x52aed4: r1 = Null
    //     0x52aed4: mov             x1, NULL
    // 0x52aed8: r0 = _Future()
    //     0x52aed8: bl              #0x4b9034  ; Allocate_FutureStub -> _Future<X0> (size=0x1c)
    // 0x52aedc: mov             x1, x0
    // 0x52aee0: r0 = 0
    //     0x52aee0: mov             x0, #0
    // 0x52aee4: stur            x1, [fp, #-0x18]
    // 0x52aee8: StoreField: r1->field_b = r0
    //     0x52aee8: stur            x0, [x1, #0xb]
    // 0x52aeec: r0 = InitLateStaticField(0x5ac) // [dart:async] Zone::_current
    //     0x52aeec: ldr             x0, [THR, #0x88]  ; THR::field_table_values
    //     0x52aef0: ldr             x0, [x0, #0xb58]
    //     0x52aef4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    //     0x52aef8: cmp             w0, w16
    //     0x52aefc: b.ne            #0x52af08
    //     0x52af00: ldr             x2, [PP, #0x7d0]  ; [pp+0x7d0] Field <Zone._current@4048458>: static late (offset: 0x5ac)
    //     0x52af04: bl              #0xd67d44
    // 0x52af08: mov             x1, x0
    // 0x52af0c: ldur            x0, [fp, #-0x18]
    // 0x52af10: StoreField: r0->field_13 = r1
    //     0x52af10: stur            w1, [x0, #0x13]
    // 0x52af14: r1 = Null
    //     0x52af14: mov             x1, NULL
    // 0x52af18: r0 = _AsyncCompleter()
    //     0x52af18: bl              #0x4b9028  ; Allocate_AsyncCompleterStub -> _AsyncCompleter<X0> (size=0x10)
    // 0x52af1c: ldur            x2, [fp, #-0x18]
    // 0x52af20: StoreField: r0->field_b = r2
    //     0x52af20: stur            w2, [x0, #0xb]
    // 0x52af24: ldur            x3, [fp, #-0x28]
    // 0x52af28: StoreField: r3->field_1b = r0
    //     0x52af28: stur            w0, [x3, #0x1b]
    //     0x52af2c: ldurb           w16, [x3, #-1]
    //     0x52af30: ldurb           w17, [x0, #-1]
    //     0x52af34: and             x16, x17, x16, lsr #2
    //     0x52af38: tst             x16, HEAP, lsr #32
    //     0x52af3c: b.eq            #0x52af44
    //     0x52af40: bl              #0xd682ac
    // 0x52af44: ldur            x0, [fp, #-0x10]
    // 0x52af48: LoadField: r4 = r0->field_7
    //     0x52af48: ldur            w4, [x0, #7]
    // 0x52af4c: DecompressPointer r4
    //     0x52af4c: add             x4, x4, HEAP, lsl #32
    // 0x52af50: stur            x4, [fp, #-0x30]
    // 0x52af54: r1 = <Uint8List, Uint8List>
    //     0x52af54: add             x1, PP, #0x13, lsl #12  ; [pp+0x13150] TypeArguments: <Uint8List, Uint8List>
    //     0x52af58: ldr             x1, [x1, #0x150]
    // 0x52af5c: r0 = _StreamHandlerTransformer()
    //     0x52af5c: bl              #0x52e47c  ; Allocate_StreamHandlerTransformerStub -> _StreamHandlerTransformer<X0, X1> (size=0x10)
    // 0x52af60: stur            x0, [fp, #-0x38]
    // 0x52af64: r1 = 2
    //     0x52af64: mov             x1, #2
    // 0x52af68: r0 = AllocateContext()
    //     0x52af68: bl              #0xd68aa4  ; AllocateContextStub
    // 0x52af6c: mov             x3, x0
    // 0x52af70: ldur            x0, [fp, #-0x38]
    // 0x52af74: stur            x3, [fp, #-0x40]
    // 0x52af78: StoreField: r3->field_f = r0
    //     0x52af78: stur            w0, [x3, #0xf]
    // 0x52af7c: ldur            x2, [fp, #-0x28]
    // 0x52af80: r1 = Function '<anonymous closure>':.
    //     0x52af80: add             x1, PP, #0x13, lsl #12  ; [pp+0x13158] AnonymousClosure: (0x52e718), in [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse (0x52ae28)
    //     0x52af84: ldr             x1, [x1, #0x158]
    // 0x52af88: r0 = AllocateClosure()
    //     0x52af88: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52af8c: ldur            x2, [fp, #-0x40]
    // 0x52af90: StoreField: r2->field_13 = r0
    //     0x52af90: stur            w0, [x2, #0x13]
    // 0x52af94: r1 = Function '<anonymous closure>':.
    //     0x52af94: add             x1, PP, #0x13, lsl #12  ; [pp+0x13160] AnonymousClosure: (0x52e6b4), of [dart:async] _StreamHandlerTransformer<X0, X1>
    //     0x52af98: ldr             x1, [x1, #0x160]
    // 0x52af9c: r0 = AllocateClosure()
    //     0x52af9c: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52afa0: mov             x1, x0
    // 0x52afa4: r0 = <Uint8List, Uint8List>
    //     0x52afa4: add             x0, PP, #0x13, lsl #12  ; [pp+0x13150] TypeArguments: <Uint8List, Uint8List>
    //     0x52afa8: ldr             x0, [x0, #0x150]
    // 0x52afac: StoreField: r1->field_7 = r0
    //     0x52afac: stur            w0, [x1, #7]
    // 0x52afb0: ldur            x0, [fp, #-0x38]
    // 0x52afb4: StoreField: r0->field_b = r1
    //     0x52afb4: stur            w1, [x0, #0xb]
    // 0x52afb8: r16 = <Uint8List>
    //     0x52afb8: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0x52afbc: ldur            lr, [fp, #-0x30]
    // 0x52afc0: stp             lr, x16, [SP, #-0x10]!
    // 0x52afc4: SaveReg r0
    //     0x52afc4: str             x0, [SP, #-8]!
    // 0x52afc8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52afc8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52afcc: r0 = transform()
    //     0x52afcc: bl              #0x52e1e8  ; [dart:async] Stream::transform
    // 0x52afd0: add             SP, SP, #0x18
    // 0x52afd4: stur            x0, [fp, #-0x30]
    // 0x52afd8: r16 = <Uint8List>
    //     0x52afd8: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0x52afdc: stp             xzr, x16, [SP, #-0x10]!
    // 0x52afe0: r0 = _GrowableList()
    //     0x52afe0: bl              #0x4bd9a0  ; [dart:core] _GrowableList::_GrowableList
    // 0x52afe4: add             SP, SP, #0x10
    // 0x52afe8: mov             x4, x0
    // 0x52afec: ldur            x3, [fp, #-0x28]
    // 0x52aff0: stur            x4, [fp, #-0x38]
    // 0x52aff4: StoreField: r3->field_1f = r0
    //     0x52aff4: stur            w0, [x3, #0x1f]
    //     0x52aff8: ldurb           w16, [x3, #-1]
    //     0x52affc: ldurb           w17, [x0, #-1]
    //     0x52b000: and             x16, x17, x16, lsr #2
    //     0x52b004: tst             x16, HEAP, lsr #32
    //     0x52b008: b.eq            #0x52b010
    //     0x52b00c: bl              #0xd682ac
    // 0x52b010: StoreField: r3->field_23 = rZR
    //     0x52b010: stur            wzr, [x3, #0x23]
    // 0x52b014: mov             x2, x3
    // 0x52b018: r1 = Function '<anonymous closure>':.
    //     0x52b018: add             x1, PP, #0x13, lsl #12  ; [pp+0x13168] AnonymousClosure: (0x52e578), in [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse (0x52ae28)
    //     0x52b01c: ldr             x1, [x1, #0x168]
    // 0x52b020: r0 = AllocateClosure()
    //     0x52b020: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52b024: ldur            x2, [fp, #-0x28]
    // 0x52b028: r1 = Function '<anonymous closure>':.
    //     0x52b028: add             x1, PP, #0x13, lsl #12  ; [pp+0x13170] AnonymousClosure: (0x52e51c), in [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse (0x52ae28)
    //     0x52b02c: ldr             x1, [x1, #0x170]
    // 0x52b030: stur            x0, [fp, #-0x40]
    // 0x52b034: r0 = AllocateClosure()
    //     0x52b034: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52b038: ldur            x2, [fp, #-0x28]
    // 0x52b03c: r1 = Function '<anonymous closure>':.
    //     0x52b03c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13178] AnonymousClosure: (0x52e4d0), in [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse (0x52ae28)
    //     0x52b040: ldr             x1, [x1, #0x178]
    // 0x52b044: stur            x0, [fp, #-0x48]
    // 0x52b048: r0 = AllocateClosure()
    //     0x52b048: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52b04c: ldur            x16, [fp, #-0x30]
    // 0x52b050: ldur            lr, [fp, #-0x40]
    // 0x52b054: stp             lr, x16, [SP, #-0x10]!
    // 0x52b058: ldur            x16, [fp, #-0x48]
    // 0x52b05c: stp             x0, x16, [SP, #-0x10]!
    // 0x52b060: r16 = true
    //     0x52b060: add             x16, NULL, #0x20  ; true
    // 0x52b064: SaveReg r16
    //     0x52b064: str             x16, [SP, #-8]!
    // 0x52b068: r4 = const [0, 0x5, 0x5, 0x2, cancelOnError, 0x4, onDone, 0x3, onError, 0x2, null]
    //     0x52b068: ldr             x4, [PP, #0x6868]  ; [pp+0x6868] List(11) [0, 0x5, 0x5, 0x2, "cancelOnError", 0x4, "onDone", 0x3, "onError", 0x2, Null]
    // 0x52b06c: r0 = listen()
    //     0x52b06c: bl              #0xc572b8  ; [dart:async] _BoundSinkStream::listen
    // 0x52b070: add             SP, SP, #0x28
    // 0x52b074: ldur            x3, [fp, #-0x28]
    // 0x52b078: StoreField: r3->field_27 = r0
    //     0x52b078: stur            w0, [x3, #0x27]
    //     0x52b07c: ldurb           w16, [x3, #-1]
    //     0x52b080: ldurb           w17, [x0, #-1]
    //     0x52b084: and             x16, x17, x16, lsr #2
    //     0x52b088: tst             x16, HEAP, lsr #32
    //     0x52b08c: b.eq            #0x52b094
    //     0x52b090: bl              #0xd682ac
    // 0x52b094: LoadField: r0 = r3->field_f
    //     0x52b094: ldur            w0, [x3, #0xf]
    // 0x52b098: DecompressPointer r0
    //     0x52b098: add             x0, x0, HEAP, lsl #32
    // 0x52b09c: LoadField: r1 = r0->field_5b
    //     0x52b09c: ldur            w1, [x0, #0x5b]
    // 0x52b0a0: DecompressPointer r1
    //     0x52b0a0: add             x1, x1, HEAP, lsl #32
    // 0x52b0a4: cmp             w1, NULL
    // 0x52b0a8: b.ne            #0x52b0b4
    // 0x52b0ac: mov             x1, x3
    // 0x52b0b0: b               #0x52b0f8
    // 0x52b0b4: LoadField: r0 = r1->field_7
    //     0x52b0b4: ldur            w0, [x1, #7]
    // 0x52b0b8: DecompressPointer r0
    //     0x52b0b8: add             x0, x0, HEAP, lsl #32
    // 0x52b0bc: LoadField: r4 = r0->field_b
    //     0x52b0bc: ldur            w4, [x0, #0xb]
    // 0x52b0c0: DecompressPointer r4
    //     0x52b0c0: add             x4, x4, HEAP, lsl #32
    // 0x52b0c4: mov             x2, x3
    // 0x52b0c8: stur            x4, [fp, #-0x30]
    // 0x52b0cc: r1 = Function '<anonymous closure>':.
    //     0x52b0cc: add             x1, PP, #0x13, lsl #12  ; [pp+0x13180] AnonymousClosure: (0x52e488), in [package:dio/src/transformers/sync_transformer.dart] SyncTransformer::transformResponse (0x52ae28)
    //     0x52b0d0: ldr             x1, [x1, #0x180]
    // 0x52b0d4: r0 = AllocateClosure()
    //     0x52b0d4: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x52b0d8: r16 = <void?>
    //     0x52b0d8: ldr             x16, [PP, #0xed0]  ; [pp+0xed0] TypeArguments: <void?>
    // 0x52b0dc: ldur            lr, [fp, #-0x30]
    // 0x52b0e0: stp             lr, x16, [SP, #-0x10]!
    // 0x52b0e4: SaveReg r0
    //     0x52b0e4: str             x0, [SP, #-8]!
    // 0x52b0e8: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x52b0e8: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x52b0ec: r0 = then()
    //     0x52b0ec: bl              #0xca6124  ; [dart:async] _Future::then
    // 0x52b0f0: add             SP, SP, #0x18
    // 0x52b0f4: ldur            x1, [fp, #-0x28]
    // 0x52b0f8: ldur            x2, [fp, #-0x38]
    // 0x52b0fc: ldur            x0, [fp, #-0x18]
    // 0x52b100: r0 = Await()
    //     0x52b100: bl              #0x4b8e6c  ; AwaitStub
    // 0x52b104: ldur            x0, [fp, #-0x28]
    // 0x52b108: LoadField: r1 = r0->field_23
    //     0x52b108: ldur            w1, [x0, #0x23]
    // 0x52b10c: DecompressPointer r1
    //     0x52b10c: add             x1, x1, HEAP, lsl #32
    // 0x52b110: mov             x4, x1
    // 0x52b114: stur            x1, [fp, #-0x18]
    // 0x52b118: r0 = AllocateUint8Array()
    //     0x52b118: bl              #0xd69558  ; AllocateUint8ArrayStub
    // 0x52b11c: mov             x2, x0
    // 0x52b120: ldur            x1, [fp, #-0x38]
    // 0x52b124: stur            x2, [fp, #-0x30]
    // 0x52b128: r0 = LoadClassIdInstr(r1)
    //     0x52b128: ldur            x0, [x1, #-1]
    //     0x52b12c: ubfx            x0, x0, #0xc, #0x14
    // 0x52b130: SaveReg r1
    //     0x52b130: str             x1, [SP, #-8]!
    // 0x52b134: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x52b134: mov             x17, #0xb8ea
    //     0x52b138: add             lr, x0, x17
    //     0x52b13c: ldr             lr, [x21, lr, lsl #3]
    //     0x52b140: blr             lr
    // 0x52b144: add             SP, SP, #8
    // 0x52b148: r1 = LoadInt32Instr(r0)
    //     0x52b148: sbfx            x1, x0, #1, #0x1f
    //     0x52b14c: tbz             w0, #0, #0x52b154
    //     0x52b150: ldur            x1, [x0, #7]
    // 0x52b154: stur            x1, [fp, #-0x60]
    // 0x52b158: r8 = 0
    //     0x52b158: mov             x8, #0
    // 0x52b15c: r7 = 0
    //     0x52b15c: mov             x7, #0
    // 0x52b160: ldur            x6, [fp, #-0x20]
    // 0x52b164: ldur            x5, [fp, #-0x10]
    // 0x52b168: ldur            x3, [fp, #-0x28]
    // 0x52b16c: ldur            x2, [fp, #-0x38]
    // 0x52b170: ldur            x4, [fp, #-0x18]
    // 0x52b174: stur            x8, [fp, #-0x50]
    // 0x52b178: stur            x7, [fp, #-0x58]
    // 0x52b17c: CheckStackOverflow
    //     0x52b17c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52b180: cmp             SP, x16
    //     0x52b184: b.ls            #0x52b488
    // 0x52b188: r0 = LoadClassIdInstr(r2)
    //     0x52b188: ldur            x0, [x2, #-1]
    //     0x52b18c: ubfx            x0, x0, #0xc, #0x14
    // 0x52b190: SaveReg r2
    //     0x52b190: str             x2, [SP, #-8]!
    // 0x52b194: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x52b194: mov             x17, #0xb8ea
    //     0x52b198: add             lr, x0, x17
    //     0x52b19c: ldr             lr, [x21, lr, lsl #3]
    //     0x52b1a0: blr             lr
    // 0x52b1a4: add             SP, SP, #8
    // 0x52b1a8: r1 = LoadInt32Instr(r0)
    //     0x52b1a8: sbfx            x1, x0, #1, #0x1f
    //     0x52b1ac: tbz             w0, #0, #0x52b1b4
    //     0x52b1b0: ldur            x1, [x0, #7]
    // 0x52b1b4: ldur            x2, [fp, #-0x60]
    // 0x52b1b8: cmp             x2, x1
    // 0x52b1bc: b.ne            #0x52b45c
    // 0x52b1c0: ldur            x3, [fp, #-0x38]
    // 0x52b1c4: ldur            x4, [fp, #-0x58]
    // 0x52b1c8: cmp             x4, x1
    // 0x52b1cc: b.lt            #0x52b32c
    // 0x52b1d0: ldur            x0, [fp, #-0x28]
    // 0x52b1d4: LoadField: r1 = r0->field_f
    //     0x52b1d4: ldur            w1, [x0, #0xf]
    // 0x52b1d8: DecompressPointer r1
    //     0x52b1d8: add             x1, x1, HEAP, lsl #32
    // 0x52b1dc: LoadField: r2 = r1->field_1b
    //     0x52b1dc: ldur            w2, [x1, #0x1b]
    // 0x52b1e0: DecompressPointer r2
    //     0x52b1e0: add             x2, x2, HEAP, lsl #32
    // 0x52b1e4: r16 = Sentinel
    //     0x52b1e4: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52b1e8: cmp             w2, w16
    // 0x52b1ec: b.eq            #0x52b490
    // 0x52b1f0: r16 = Instance_ResponseType
    //     0x52b1f0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12df0] Obj!ResponseType@b66591
    //     0x52b1f4: ldr             x16, [x16, #0xdf0]
    // 0x52b1f8: cmp             w2, w16
    // 0x52b1fc: b.ne            #0x52b208
    // 0x52b200: ldur            x0, [fp, #-0x30]
    // 0x52b204: r0 = ReturnAsyncNotFuture()
    //     0x52b204: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x52b208: ldur            x5, [fp, #-0x18]
    // 0x52b20c: cbz             w5, #0x52b238
    // 0x52b210: r16 = Instance_Utf8Codec
    //     0x52b210: ldr             x16, [PP, #0xa30]  ; [pp+0xa30] Obj!Utf8Codec<String, List<int>>@b5f6a1
    // 0x52b214: ldur            lr, [fp, #-0x30]
    // 0x52b218: stp             lr, x16, [SP, #-0x10]!
    // 0x52b21c: r16 = true
    //     0x52b21c: add             x16, NULL, #0x20  ; true
    // 0x52b220: SaveReg r16
    //     0x52b220: str             x16, [SP, #-8]!
    // 0x52b224: r4 = const [0, 0x3, 0x3, 0x2, allowMalformed, 0x2, null]
    //     0x52b224: ldr             x4, [PP, #0x2818]  ; [pp+0x2818] List(7) [0, 0x3, 0x3, 0x2, "allowMalformed", 0x2, Null]
    // 0x52b228: r0 = decode()
    //     0x52b228: bl              #0x4e1c78  ; [dart:convert] Utf8Codec::decode
    // 0x52b22c: add             SP, SP, #0x18
    // 0x52b230: mov             x1, x0
    // 0x52b234: b               #0x52b23c
    // 0x52b238: r1 = Null
    //     0x52b238: mov             x1, NULL
    // 0x52b23c: stur            x1, [fp, #-0x40]
    // 0x52b240: cmp             w1, NULL
    // 0x52b244: b.eq            #0x52b324
    // 0x52b248: LoadField: r0 = r1->field_7
    //     0x52b248: ldur            w0, [x1, #7]
    // 0x52b24c: DecompressPointer r0
    //     0x52b24c: add             x0, x0, HEAP, lsl #32
    // 0x52b250: cbz             w0, #0x52b324
    // 0x52b254: ldur            x6, [fp, #-0x28]
    // 0x52b258: LoadField: r0 = r6->field_f
    //     0x52b258: ldur            w0, [x6, #0xf]
    // 0x52b25c: DecompressPointer r0
    //     0x52b25c: add             x0, x0, HEAP, lsl #32
    // 0x52b260: LoadField: r2 = r0->field_1b
    //     0x52b260: ldur            w2, [x0, #0x1b]
    // 0x52b264: DecompressPointer r2
    //     0x52b264: add             x2, x2, HEAP, lsl #32
    // 0x52b268: r16 = Sentinel
    //     0x52b268: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x52b26c: cmp             w2, w16
    // 0x52b270: b.eq            #0x52b49c
    // 0x52b274: r16 = Instance_ResponseType
    //     0x52b274: add             x16, PP, #0x12, lsl #12  ; [pp+0x12e08] Obj!ResponseType@b66531
    //     0x52b278: ldr             x16, [x16, #0xe08]
    // 0x52b27c: cmp             w2, w16
    // 0x52b280: b.ne            #0x52b324
    // 0x52b284: ldur            x7, [fp, #-0x10]
    // 0x52b288: LoadField: r0 = r7->field_b
    //     0x52b288: ldur            w0, [x7, #0xb]
    // 0x52b28c: DecompressPointer r0
    //     0x52b28c: add             x0, x0, HEAP, lsl #32
    // 0x52b290: r2 = LoadClassIdInstr(r0)
    //     0x52b290: ldur            x2, [x0, #-1]
    //     0x52b294: ubfx            x2, x2, #0xc, #0x14
    // 0x52b298: r16 = "content-type"
    //     0x52b298: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x52b29c: ldr             x16, [x16, #0xed8]
    // 0x52b2a0: stp             x16, x0, [SP, #-0x10]!
    // 0x52b2a4: mov             x0, x2
    // 0x52b2a8: r0 = GDT[cid_x0 + -0xef]()
    //     0x52b2a8: sub             lr, x0, #0xef
    //     0x52b2ac: ldr             lr, [x21, lr, lsl #3]
    //     0x52b2b0: blr             lr
    // 0x52b2b4: add             SP, SP, #0x10
    // 0x52b2b8: cmp             w0, NULL
    // 0x52b2bc: b.ne            #0x52b2c8
    // 0x52b2c0: r0 = Null
    //     0x52b2c0: mov             x0, NULL
    // 0x52b2c4: b               #0x52b2ec
    // 0x52b2c8: r1 = LoadClassIdInstr(r0)
    //     0x52b2c8: ldur            x1, [x0, #-1]
    //     0x52b2cc: ubfx            x1, x1, #0xc, #0x14
    // 0x52b2d0: SaveReg r0
    //     0x52b2d0: str             x0, [SP, #-8]!
    // 0x52b2d4: mov             x0, x1
    // 0x52b2d8: r0 = GDT[cid_x0 + 0xcaae]()
    //     0x52b2d8: mov             x17, #0xcaae
    //     0x52b2dc: add             lr, x0, x17
    //     0x52b2e0: ldr             lr, [x21, lr, lsl #3]
    //     0x52b2e4: blr             lr
    // 0x52b2e8: add             SP, SP, #8
    // 0x52b2ec: SaveReg r0
    //     0x52b2ec: str             x0, [SP, #-8]!
    // 0x52b2f0: r0 = isJsonMimeType()
    //     0x52b2f0: bl              #0x52b6c0  ; [package:dio/src/transformer.dart] Transformer::isJsonMimeType
    // 0x52b2f4: add             SP, SP, #8
    // 0x52b2f8: tbnz            w0, #4, #0x52b324
    // 0x52b2fc: ldur            x8, [fp, #-0x20]
    // 0x52b300: LoadField: r0 = r8->field_7
    //     0x52b300: ldur            w0, [x8, #7]
    // 0x52b304: DecompressPointer r0
    //     0x52b304: add             x0, x0, HEAP, lsl #32
    // 0x52b308: ldur            x16, [fp, #-0x40]
    // 0x52b30c: stp             x16, x0, [SP, #-0x10]!
    // 0x52b310: ClosureCall
    //     0x52b310: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x52b314: ldur            x2, [x0, #0x1f]
    //     0x52b318: blr             x2
    // 0x52b31c: add             SP, SP, #0x10
    // 0x52b320: r0 = ReturnAsync()
    //     0x52b320: b               #0x501858  ; ReturnAsyncStub
    // 0x52b324: ldur            x0, [fp, #-0x40]
    // 0x52b328: r0 = ReturnAsyncNotFuture()
    //     0x52b328: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x52b32c: ldur            x8, [fp, #-0x20]
    // 0x52b330: ldur            x7, [fp, #-0x10]
    // 0x52b334: ldur            x6, [fp, #-0x28]
    // 0x52b338: ldur            x5, [fp, #-0x18]
    // 0x52b33c: r0 = BoxInt64Instr(r4)
    //     0x52b33c: sbfiz           x0, x4, #1, #0x1f
    //     0x52b340: cmp             x4, x0, asr #1
    //     0x52b344: b.eq            #0x52b350
    //     0x52b348: bl              #0xd69bb8
    //     0x52b34c: stur            x4, [x0, #7]
    // 0x52b350: r1 = LoadClassIdInstr(r3)
    //     0x52b350: ldur            x1, [x3, #-1]
    //     0x52b354: ubfx            x1, x1, #0xc, #0x14
    // 0x52b358: stp             x0, x3, [SP, #-0x10]!
    // 0x52b35c: mov             x0, x1
    // 0x52b360: r0 = GDT[cid_x0 + 0xd175]()
    //     0x52b360: mov             x17, #0xd175
    //     0x52b364: add             lr, x0, x17
    //     0x52b368: ldr             lr, [x21, lr, lsl #3]
    //     0x52b36c: blr             lr
    // 0x52b370: add             SP, SP, #0x10
    // 0x52b374: mov             x3, x0
    // 0x52b378: ldur            x0, [fp, #-0x58]
    // 0x52b37c: stur            x3, [fp, #-0x40]
    // 0x52b380: add             x7, x0, #1
    // 0x52b384: stur            x7, [fp, #-0x68]
    // 0x52b388: cmp             w3, NULL
    // 0x52b38c: b.ne            #0x52b3cc
    // 0x52b390: mov             x0, x3
    // 0x52b394: r2 = Null
    //     0x52b394: mov             x2, NULL
    // 0x52b398: r1 = Null
    //     0x52b398: mov             x1, NULL
    // 0x52b39c: r4 = 59
    //     0x52b39c: mov             x4, #0x3b
    // 0x52b3a0: branchIfSmi(r0, 0x52b3ac)
    //     0x52b3a0: tbz             w0, #0, #0x52b3ac
    // 0x52b3a4: r4 = LoadClassIdInstr(r0)
    //     0x52b3a4: ldur            x4, [x0, #-1]
    //     0x52b3a8: ubfx            x4, x4, #0xc, #0x14
    // 0x52b3ac: sub             x4, x4, #0x75
    // 0x52b3b0: cmp             x4, #3
    // 0x52b3b4: b.ls            #0x52b3cc
    // 0x52b3b8: r8 = Uint8List
    //     0x52b3b8: add             x8, PP, #8, lsl #12  ; [pp+0x8760] Type: Uint8List
    //     0x52b3bc: ldr             x8, [x8, #0x760]
    // 0x52b3c0: r3 = Null
    //     0x52b3c0: add             x3, PP, #0x13, lsl #12  ; [pp+0x13188] Null
    //     0x52b3c4: ldr             x3, [x3, #0x188]
    // 0x52b3c8: r0 = Uint8List()
    //     0x52b3c8: bl              #0x4b2828  ; IsType_Uint8List_Stub
    // 0x52b3cc: ldur            x2, [fp, #-0x50]
    // 0x52b3d0: ldur            x1, [fp, #-0x40]
    // 0x52b3d4: r0 = LoadClassIdInstr(r1)
    //     0x52b3d4: ldur            x0, [x1, #-1]
    //     0x52b3d8: ubfx            x0, x0, #0xc, #0x14
    // 0x52b3dc: SaveReg r1
    //     0x52b3dc: str             x1, [SP, #-8]!
    // 0x52b3e0: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x52b3e0: mov             x17, #0xb8ea
    //     0x52b3e4: add             lr, x0, x17
    //     0x52b3e8: ldr             lr, [x21, lr, lsl #3]
    //     0x52b3ec: blr             lr
    // 0x52b3f0: add             SP, SP, #8
    // 0x52b3f4: r1 = LoadInt32Instr(r0)
    //     0x52b3f4: sbfx            x1, x0, #1, #0x1f
    //     0x52b3f8: tbz             w0, #0, #0x52b400
    //     0x52b3fc: ldur            x1, [x0, #7]
    // 0x52b400: ldur            x2, [fp, #-0x50]
    // 0x52b404: add             x3, x1, x2
    // 0x52b408: r0 = BoxInt64Instr(r2)
    //     0x52b408: sbfiz           x0, x2, #1, #0x1f
    //     0x52b40c: cmp             x2, x0, asr #1
    //     0x52b410: b.eq            #0x52b41c
    //     0x52b414: bl              #0xd69bb8
    //     0x52b418: stur            x2, [x0, #7]
    // 0x52b41c: ldur            x16, [fp, #-0x30]
    // 0x52b420: stp             x0, x16, [SP, #-0x10]!
    // 0x52b424: ldur            x16, [fp, #-0x40]
    // 0x52b428: stp             x16, x3, [SP, #-0x10]!
    // 0x52b42c: r4 = const [0, 0x4, 0x4, 0x4, null]
    //     0x52b42c: ldr             x4, [PP, #0x488]  ; [pp+0x488] List(5) [0, 0x4, 0x4, 0x4, Null]
    // 0x52b430: r0 = setRange()
    //     0x52b430: bl              #0x605c8c  ; [dart:typed_data] __Uint8List&_TypedList&_IntListMixin&_TypedIntListMixin::setRange
    // 0x52b434: add             SP, SP, #0x20
    // 0x52b438: ldur            x0, [fp, #-0x40]
    // 0x52b43c: LoadField: r1 = r0->field_13
    //     0x52b43c: ldur            w1, [x0, #0x13]
    // 0x52b440: DecompressPointer r1
    //     0x52b440: add             x1, x1, HEAP, lsl #32
    // 0x52b444: r0 = LoadInt32Instr(r1)
    //     0x52b444: sbfx            x0, x1, #1, #0x1f
    // 0x52b448: ldur            x1, [fp, #-0x50]
    // 0x52b44c: add             x8, x1, x0
    // 0x52b450: ldur            x7, [fp, #-0x68]
    // 0x52b454: ldur            x1, [fp, #-0x60]
    // 0x52b458: b               #0x52b160
    // 0x52b45c: ldur            x0, [fp, #-0x38]
    // 0x52b460: r0 = ConcurrentModificationError()
    //     0x52b460: bl              #0x4bfae4  ; AllocateConcurrentModificationErrorStub -> ConcurrentModificationError (size=0x10)
    // 0x52b464: ldur            x3, [fp, #-0x38]
    // 0x52b468: StoreField: r0->field_b = r3
    //     0x52b468: stur            w3, [x0, #0xb]
    // 0x52b46c: r0 = Throw()
    //     0x52b46c: bl              #0xd67e38  ; ThrowStub
    // 0x52b470: brk             #0
    // 0x52b474: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52b474: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52b478: b               #0x52ae6c
    // 0x52b47c: r9 = responseType
    //     0x52b47c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12e90] Field <_RequestConfig@361184022.responseType>: late (offset: 0x1c)
    //     0x52b480: ldr             x9, [x9, #0xe90]
    // 0x52b484: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52b484: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52b488: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52b488: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52b48c: b               #0x52b188
    // 0x52b490: r9 = responseType
    //     0x52b490: add             x9, PP, #0x12, lsl #12  ; [pp+0x12e90] Field <_RequestConfig@361184022.responseType>: late (offset: 0x1c)
    //     0x52b494: ldr             x9, [x9, #0xe90]
    // 0x52b498: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52b498: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
    // 0x52b49c: r9 = responseType
    //     0x52b49c: add             x9, PP, #0x12, lsl #12  ; [pp+0x12e90] Field <_RequestConfig@361184022.responseType>: late (offset: 0x1c)
    //     0x52b4a0: ldr             x9, [x9, #0xe90]
    // 0x52b4a4: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x52b4a4: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
  [closure] Future<void> <anonymous closure>(dynamic, DioException) {
    // ** addr: 0x52e488, size: 0x48
    // 0x52e488: EnterFrame
    //     0x52e488: stp             fp, lr, [SP, #-0x10]!
    //     0x52e48c: mov             fp, SP
    // 0x52e490: ldr             x0, [fp, #0x18]
    // 0x52e494: LoadField: r1 = r0->field_17
    //     0x52e494: ldur            w1, [x0, #0x17]
    // 0x52e498: DecompressPointer r1
    //     0x52e498: add             x1, x1, HEAP, lsl #32
    // 0x52e49c: CheckStackOverflow
    //     0x52e49c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e4a0: cmp             SP, x16
    //     0x52e4a4: b.ls            #0x52e4c8
    // 0x52e4a8: LoadField: r0 = r1->field_27
    //     0x52e4a8: ldur            w0, [x1, #0x27]
    // 0x52e4ac: DecompressPointer r0
    //     0x52e4ac: add             x0, x0, HEAP, lsl #32
    // 0x52e4b0: SaveReg r0
    //     0x52e4b0: str             x0, [SP, #-8]!
    // 0x52e4b4: r0 = cancel()
    //     0x52e4b4: bl              #0xc54490  ; [dart:async] _BufferingStreamSubscription::cancel
    // 0x52e4b8: add             SP, SP, #8
    // 0x52e4bc: LeaveFrame
    //     0x52e4bc: mov             SP, fp
    //     0x52e4c0: ldp             fp, lr, [SP], #0x10
    // 0x52e4c4: ret
    //     0x52e4c4: ret             
    // 0x52e4c8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e4c8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e4cc: b               #0x52e4a8
  }
  [closure] void <anonymous closure>(dynamic) {
    // ** addr: 0x52e4d0, size: 0x4c
    // 0x52e4d0: EnterFrame
    //     0x52e4d0: stp             fp, lr, [SP, #-0x10]!
    //     0x52e4d4: mov             fp, SP
    // 0x52e4d8: ldr             x0, [fp, #0x10]
    // 0x52e4dc: LoadField: r1 = r0->field_17
    //     0x52e4dc: ldur            w1, [x0, #0x17]
    // 0x52e4e0: DecompressPointer r1
    //     0x52e4e0: add             x1, x1, HEAP, lsl #32
    // 0x52e4e4: CheckStackOverflow
    //     0x52e4e4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e4e8: cmp             SP, x16
    //     0x52e4ec: b.ls            #0x52e514
    // 0x52e4f0: LoadField: r0 = r1->field_1b
    //     0x52e4f0: ldur            w0, [x1, #0x1b]
    // 0x52e4f4: DecompressPointer r0
    //     0x52e4f4: add             x0, x0, HEAP, lsl #32
    // 0x52e4f8: SaveReg r0
    //     0x52e4f8: str             x0, [SP, #-8]!
    // 0x52e4fc: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x52e4fc: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x52e500: r0 = complete()
    //     0x52e500: bl              #0xca3f38  ; [dart:async] _AsyncCompleter::complete
    // 0x52e504: add             SP, SP, #8
    // 0x52e508: LeaveFrame
    //     0x52e508: mov             SP, fp
    //     0x52e50c: ldp             fp, lr, [SP], #0x10
    // 0x52e510: ret
    //     0x52e510: ret             
    // 0x52e514: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e514: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e518: b               #0x52e4f0
  }
  [closure] Null <anonymous closure>(dynamic, Object, StackTrace) {
    // ** addr: 0x52e51c, size: 0x5c
    // 0x52e51c: EnterFrame
    //     0x52e51c: stp             fp, lr, [SP, #-0x10]!
    //     0x52e520: mov             fp, SP
    // 0x52e524: ldr             x0, [fp, #0x20]
    // 0x52e528: LoadField: r1 = r0->field_17
    //     0x52e528: ldur            w1, [x0, #0x17]
    // 0x52e52c: DecompressPointer r1
    //     0x52e52c: add             x1, x1, HEAP, lsl #32
    // 0x52e530: CheckStackOverflow
    //     0x52e530: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e534: cmp             SP, x16
    //     0x52e538: b.ls            #0x52e570
    // 0x52e53c: LoadField: r0 = r1->field_1b
    //     0x52e53c: ldur            w0, [x1, #0x1b]
    // 0x52e540: DecompressPointer r0
    //     0x52e540: add             x0, x0, HEAP, lsl #32
    // 0x52e544: ldr             x16, [fp, #0x18]
    // 0x52e548: stp             x16, x0, [SP, #-0x10]!
    // 0x52e54c: ldr             x16, [fp, #0x10]
    // 0x52e550: SaveReg r16
    //     0x52e550: str             x16, [SP, #-8]!
    // 0x52e554: r4 = const [0, 0x3, 0x3, 0x3, null]
    //     0x52e554: ldr             x4, [PP, #0x2b0]  ; [pp+0x2b0] List(5) [0, 0x3, 0x3, 0x3, Null]
    // 0x52e558: r0 = completeError()
    //     0x52e558: bl              #0x4b4f98  ; [dart:async] _Completer::completeError
    // 0x52e55c: add             SP, SP, #0x18
    // 0x52e560: r0 = Null
    //     0x52e560: mov             x0, NULL
    // 0x52e564: LeaveFrame
    //     0x52e564: mov             SP, fp
    //     0x52e568: ldp             fp, lr, [SP], #0x10
    // 0x52e56c: ret
    //     0x52e56c: ret             
    // 0x52e570: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e570: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e574: b               #0x52e53c
  }
  [closure] void <anonymous closure>(dynamic, Uint8List) {
    // ** addr: 0x52e578, size: 0x13c
    // 0x52e578: EnterFrame
    //     0x52e578: stp             fp, lr, [SP, #-0x10]!
    //     0x52e57c: mov             fp, SP
    // 0x52e580: AllocStack(0x10)
    //     0x52e580: sub             SP, SP, #0x10
    // 0x52e584: SetupParameters()
    //     0x52e584: ldr             x0, [fp, #0x18]
    //     0x52e588: ldur            w2, [x0, #0x17]
    //     0x52e58c: add             x2, x2, HEAP, lsl #32
    // 0x52e590: CheckStackOverflow
    //     0x52e590: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e594: cmp             SP, x16
    //     0x52e598: b.ls            #0x52e6a4
    // 0x52e59c: LoadField: r0 = r2->field_23
    //     0x52e59c: ldur            w0, [x2, #0x23]
    // 0x52e5a0: DecompressPointer r0
    //     0x52e5a0: add             x0, x0, HEAP, lsl #32
    // 0x52e5a4: ldr             x3, [fp, #0x10]
    // 0x52e5a8: LoadField: r1 = r3->field_13
    //     0x52e5a8: ldur            w1, [x3, #0x13]
    // 0x52e5ac: DecompressPointer r1
    //     0x52e5ac: add             x1, x1, HEAP, lsl #32
    // 0x52e5b0: cmp             w0, NULL
    // 0x52e5b4: b.eq            #0x52e6ac
    // 0x52e5b8: r4 = LoadInt32Instr(r1)
    //     0x52e5b8: sbfx            x4, x1, #1, #0x1f
    // 0x52e5bc: r1 = LoadInt32Instr(r0)
    //     0x52e5bc: sbfx            x1, x0, #1, #0x1f
    //     0x52e5c0: tbz             w0, #0, #0x52e5c8
    //     0x52e5c4: ldur            x1, [x0, #7]
    // 0x52e5c8: add             x5, x1, x4
    // 0x52e5cc: r0 = BoxInt64Instr(r5)
    //     0x52e5cc: sbfiz           x0, x5, #1, #0x1f
    //     0x52e5d0: cmp             x5, x0, asr #1
    //     0x52e5d4: b.eq            #0x52e5e0
    //     0x52e5d8: bl              #0xd69bb8
    //     0x52e5dc: stur            x5, [x0, #7]
    // 0x52e5e0: StoreField: r2->field_23 = r0
    //     0x52e5e0: stur            w0, [x2, #0x23]
    //     0x52e5e4: tbz             w0, #0, #0x52e600
    //     0x52e5e8: ldurb           w16, [x2, #-1]
    //     0x52e5ec: ldurb           w17, [x0, #-1]
    //     0x52e5f0: and             x16, x17, x16, lsr #2
    //     0x52e5f4: tst             x16, HEAP, lsr #32
    //     0x52e5f8: b.eq            #0x52e600
    //     0x52e5fc: bl              #0xd6828c
    // 0x52e600: LoadField: r0 = r2->field_1f
    //     0x52e600: ldur            w0, [x2, #0x1f]
    // 0x52e604: DecompressPointer r0
    //     0x52e604: add             x0, x0, HEAP, lsl #32
    // 0x52e608: stur            x0, [fp, #-0x10]
    // 0x52e60c: LoadField: r1 = r0->field_b
    //     0x52e60c: ldur            w1, [x0, #0xb]
    // 0x52e610: DecompressPointer r1
    //     0x52e610: add             x1, x1, HEAP, lsl #32
    // 0x52e614: stur            x1, [fp, #-8]
    // 0x52e618: LoadField: r2 = r0->field_f
    //     0x52e618: ldur            w2, [x0, #0xf]
    // 0x52e61c: DecompressPointer r2
    //     0x52e61c: add             x2, x2, HEAP, lsl #32
    // 0x52e620: LoadField: r4 = r2->field_b
    //     0x52e620: ldur            w4, [x2, #0xb]
    // 0x52e624: DecompressPointer r4
    //     0x52e624: add             x4, x4, HEAP, lsl #32
    // 0x52e628: cmp             w1, w4
    // 0x52e62c: b.ne            #0x52e63c
    // 0x52e630: SaveReg r0
    //     0x52e630: str             x0, [SP, #-8]!
    // 0x52e634: r0 = _growToNextCapacity()
    //     0x52e634: bl              #0x4bd550  ; [dart:core] _GrowableList::_growToNextCapacity
    // 0x52e638: add             SP, SP, #8
    // 0x52e63c: ldur            x2, [fp, #-0x10]
    // 0x52e640: ldur            x3, [fp, #-8]
    // 0x52e644: r4 = LoadInt32Instr(r3)
    //     0x52e644: sbfx            x4, x3, #1, #0x1f
    // 0x52e648: add             x0, x4, #1
    // 0x52e64c: lsl             x3, x0, #1
    // 0x52e650: StoreField: r2->field_b = r3
    //     0x52e650: stur            w3, [x2, #0xb]
    // 0x52e654: mov             x1, x4
    // 0x52e658: cmp             x1, x0
    // 0x52e65c: b.hs            #0x52e6b0
    // 0x52e660: LoadField: r1 = r2->field_f
    //     0x52e660: ldur            w1, [x2, #0xf]
    // 0x52e664: DecompressPointer r1
    //     0x52e664: add             x1, x1, HEAP, lsl #32
    // 0x52e668: ldr             x0, [fp, #0x10]
    // 0x52e66c: ArrayStore: r1[r4] = r0  ; List_4
    //     0x52e66c: add             x25, x1, x4, lsl #2
    //     0x52e670: add             x25, x25, #0xf
    //     0x52e674: str             w0, [x25]
    //     0x52e678: tbz             w0, #0, #0x52e694
    //     0x52e67c: ldurb           w16, [x1, #-1]
    //     0x52e680: ldurb           w17, [x0, #-1]
    //     0x52e684: and             x16, x17, x16, lsr #2
    //     0x52e688: tst             x16, HEAP, lsr #32
    //     0x52e68c: b.eq            #0x52e694
    //     0x52e690: bl              #0xd67e5c
    // 0x52e694: r0 = Null
    //     0x52e694: mov             x0, NULL
    // 0x52e698: LeaveFrame
    //     0x52e698: mov             SP, fp
    //     0x52e69c: ldp             fp, lr, [SP], #0x10
    // 0x52e6a0: ret
    //     0x52e6a0: ret             
    // 0x52e6a4: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e6a4: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e6a8: b               #0x52e59c
    // 0x52e6ac: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52e6ac: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
    // 0x52e6b0: r0 = RangeErrorSharedWithoutFPURegs()
    //     0x52e6b0: bl              #0xd69e80  ; RangeErrorSharedWithoutFPURegsStub
  }
  [closure] void <anonymous closure>(dynamic, Uint8List, EventSink<Uint8List>) {
    // ** addr: 0x52e718, size: 0xf8
    // 0x52e718: EnterFrame
    //     0x52e718: stp             fp, lr, [SP, #-0x10]!
    //     0x52e71c: mov             fp, SP
    // 0x52e720: AllocStack(0x10)
    //     0x52e720: sub             SP, SP, #0x10
    // 0x52e724: SetupParameters()
    //     0x52e724: ldr             x0, [fp, #0x20]
    //     0x52e728: ldur            w1, [x0, #0x17]
    //     0x52e72c: add             x1, x1, HEAP, lsl #32
    //     0x52e730: stur            x1, [fp, #-8]
    // 0x52e734: CheckStackOverflow
    //     0x52e734: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x52e738: cmp             SP, x16
    //     0x52e73c: b.ls            #0x52e804
    // 0x52e740: ldr             x0, [fp, #0x10]
    // 0x52e744: r2 = LoadClassIdInstr(r0)
    //     0x52e744: ldur            x2, [x0, #-1]
    //     0x52e748: ubfx            x2, x2, #0xc, #0x14
    // 0x52e74c: ldr             x16, [fp, #0x18]
    // 0x52e750: stp             x16, x0, [SP, #-0x10]!
    // 0x52e754: mov             x0, x2
    // 0x52e758: r0 = GDT[cid_x0 + 0x6e6]()
    //     0x52e758: add             lr, x0, #0x6e6
    //     0x52e75c: ldr             lr, [x21, lr, lsl #3]
    //     0x52e760: blr             lr
    // 0x52e764: add             SP, SP, #0x10
    // 0x52e768: ldur            x1, [fp, #-8]
    // 0x52e76c: LoadField: r2 = r1->field_17
    //     0x52e76c: ldur            w2, [x1, #0x17]
    // 0x52e770: DecompressPointer r2
    //     0x52e770: add             x2, x2, HEAP, lsl #32
    // 0x52e774: mov             x0, x2
    // 0x52e778: stur            x2, [fp, #-0x10]
    // 0x52e77c: tbnz            w0, #5, #0x52e784
    // 0x52e780: r0 = AssertBoolean()
    //     0x52e780: bl              #0xd67df0  ; AssertBooleanStub
    // 0x52e784: ldur            x2, [fp, #-0x10]
    // 0x52e788: tbnz            w2, #4, #0x52e7f4
    // 0x52e78c: ldr             x3, [fp, #0x18]
    // 0x52e790: ldur            x2, [fp, #-8]
    // 0x52e794: LoadField: r4 = r2->field_13
    //     0x52e794: ldur            w4, [x2, #0x13]
    // 0x52e798: DecompressPointer r4
    //     0x52e798: add             x4, x4, HEAP, lsl #32
    // 0x52e79c: LoadField: r5 = r3->field_13
    //     0x52e79c: ldur            w5, [x3, #0x13]
    // 0x52e7a0: DecompressPointer r5
    //     0x52e7a0: add             x5, x5, HEAP, lsl #32
    // 0x52e7a4: cmp             w4, NULL
    // 0x52e7a8: b.eq            #0x52e80c
    // 0x52e7ac: r3 = LoadInt32Instr(r5)
    //     0x52e7ac: sbfx            x3, x5, #1, #0x1f
    // 0x52e7b0: r5 = LoadInt32Instr(r4)
    //     0x52e7b0: sbfx            x5, x4, #1, #0x1f
    //     0x52e7b4: tbz             w4, #0, #0x52e7bc
    //     0x52e7b8: ldur            x5, [x4, #7]
    // 0x52e7bc: add             x4, x5, x3
    // 0x52e7c0: r0 = BoxInt64Instr(r4)
    //     0x52e7c0: sbfiz           x0, x4, #1, #0x1f
    //     0x52e7c4: cmp             x4, x0, asr #1
    //     0x52e7c8: b.eq            #0x52e7d4
    //     0x52e7cc: bl              #0xd69bb8
    //     0x52e7d0: stur            x4, [x0, #7]
    // 0x52e7d4: StoreField: r2->field_13 = r0
    //     0x52e7d4: stur            w0, [x2, #0x13]
    //     0x52e7d8: tbz             w0, #0, #0x52e7f4
    //     0x52e7dc: ldurb           w16, [x2, #-1]
    //     0x52e7e0: ldurb           w17, [x0, #-1]
    //     0x52e7e4: and             x16, x17, x16, lsr #2
    //     0x52e7e8: tst             x16, HEAP, lsr #32
    //     0x52e7ec: b.eq            #0x52e7f4
    //     0x52e7f0: bl              #0xd6828c
    // 0x52e7f4: r0 = Null
    //     0x52e7f4: mov             x0, NULL
    // 0x52e7f8: LeaveFrame
    //     0x52e7f8: mov             SP, fp
    //     0x52e7fc: ldp             fp, lr, [SP], #0x10
    // 0x52e800: ret
    //     0x52e800: ret             
    // 0x52e804: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x52e804: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x52e808: b               #0x52e740
    // 0x52e80c: r0 = NullErrorSharedWithoutFPURegs()
    //     0x52e80c: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
  _ transformRequest(/* No info */) async {
    // ** addr: 0x558638, size: 0x18c
    // 0x558638: EnterFrame
    //     0x558638: stp             fp, lr, [SP, #-0x10]!
    //     0x55863c: mov             fp, SP
    // 0x558640: AllocStack(0x20)
    //     0x558640: sub             SP, SP, #0x20
    // 0x558644: SetupParameters(SyncTransformer this /* r1, fp-0x18 */, dynamic _ /* r2, fp-0x10 */)
    //     0x558644: stur            NULL, [fp, #-8]
    //     0x558648: mov             x0, #0
    //     0x55864c: add             x1, fp, w0, sxtw #2
    //     0x558650: ldr             x1, [x1, #0x18]
    //     0x558654: stur            x1, [fp, #-0x18]
    //     0x558658: add             x2, fp, w0, sxtw #2
    //     0x55865c: ldr             x2, [x2, #0x10]
    //     0x558660: stur            x2, [fp, #-0x10]
    // 0x558664: CheckStackOverflow
    //     0x558664: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x558668: cmp             SP, x16
    //     0x55866c: b.ls            #0x5587b0
    // 0x558670: InitAsync() -> Future<String>
    //     0x558670: ldr             x0, [PP, #0x7d8]  ; [pp+0x7d8] TypeArguments: <String>
    //     0x558674: bl              #0x4b92e4
    // 0x558678: ldur            x0, [fp, #-0x10]
    // 0x55867c: LoadField: r1 = r0->field_53
    //     0x55867c: ldur            w1, [x0, #0x53]
    // 0x558680: DecompressPointer r1
    //     0x558680: add             x1, x1, HEAP, lsl #32
    // 0x558684: cmp             w1, NULL
    // 0x558688: b.ne            #0x558690
    // 0x55868c: r1 = ""
    //     0x55868c: ldr             x1, [PP, #0x2d8]  ; [pp+0x2d8] ""
    // 0x558690: stur            x1, [fp, #-0x20]
    // 0x558694: r2 = LoadTaggedClassIdMayBeSmiInstr(r1)
    //     0x558694: mov             x2, #0x76
    //     0x558698: tbz             w1, #0, #0x5586a8
    //     0x55869c: ldur            x2, [x1, #-1]
    //     0x5586a0: ubfx            x2, x2, #0xc, #0x14
    //     0x5586a4: lsl             x2, x2, #1
    // 0x5586a8: r3 = LoadInt32Instr(r2)
    //     0x5586a8: sbfx            x3, x2, #1, #0x1f
    // 0x5586ac: cmp             x3, #0x5d
    // 0x5586b0: b.lt            #0x5586c4
    // 0x5586b4: cmp             x3, #0x60
    // 0x5586b8: b.gt            #0x5586c4
    // 0x5586bc: mov             x0, x1
    // 0x5586c0: b               #0x55877c
    // 0x5586c4: LoadField: r2 = r0->field_b
    //     0x5586c4: ldur            w2, [x0, #0xb]
    // 0x5586c8: DecompressPointer r2
    //     0x5586c8: add             x2, x2, HEAP, lsl #32
    // 0x5586cc: r16 = Sentinel
    //     0x5586cc: ldr             x16, [PP, #0x28]  ; [pp+0x28] Sentinel
    // 0x5586d0: cmp             w2, w16
    // 0x5586d4: b.eq            #0x5587b8
    // 0x5586d8: r0 = LoadClassIdInstr(r2)
    //     0x5586d8: ldur            x0, [x2, #-1]
    //     0x5586dc: ubfx            x0, x0, #0xc, #0x14
    // 0x5586e0: r16 = "content-type"
    //     0x5586e0: add             x16, PP, #0x12, lsl #12  ; [pp+0x12ed8] "content-type"
    //     0x5586e4: ldr             x16, [x16, #0xed8]
    // 0x5586e8: stp             x16, x2, [SP, #-0x10]!
    // 0x5586ec: r0 = GDT[cid_x0 + -0xef]()
    //     0x5586ec: sub             lr, x0, #0xef
    //     0x5586f0: ldr             lr, [x21, lr, lsl #3]
    //     0x5586f4: blr             lr
    // 0x5586f8: add             SP, SP, #0x10
    // 0x5586fc: mov             x3, x0
    // 0x558700: r2 = Null
    //     0x558700: mov             x2, NULL
    // 0x558704: r1 = Null
    //     0x558704: mov             x1, NULL
    // 0x558708: stur            x3, [fp, #-0x10]
    // 0x55870c: r4 = 59
    //     0x55870c: mov             x4, #0x3b
    // 0x558710: branchIfSmi(r0, 0x55871c)
    //     0x558710: tbz             w0, #0, #0x55871c
    // 0x558714: r4 = LoadClassIdInstr(r0)
    //     0x558714: ldur            x4, [x0, #-1]
    //     0x558718: ubfx            x4, x4, #0xc, #0x14
    // 0x55871c: sub             x4, x4, #0x5d
    // 0x558720: cmp             x4, #3
    // 0x558724: b.ls            #0x558738
    // 0x558728: r8 = String?
    //     0x558728: ldr             x8, [PP, #0x2148]  ; [pp+0x2148] Type: String?
    // 0x55872c: r3 = Null
    //     0x55872c: add             x3, PP, #0x14, lsl #12  ; [pp+0x14548] Null
    //     0x558730: ldr             x3, [x3, #0x548]
    // 0x558734: r0 = String?()
    //     0x558734: bl              #0x4b2994  ; IsType_String?_Stub
    // 0x558738: ldur            x16, [fp, #-0x10]
    // 0x55873c: SaveReg r16
    //     0x55873c: str             x16, [SP, #-8]!
    // 0x558740: r0 = isJsonMimeType()
    //     0x558740: bl              #0x52b6c0  ; [package:dio/src/transformer.dart] Transformer::isJsonMimeType
    // 0x558744: add             SP, SP, #8
    // 0x558748: tbnz            w0, #4, #0x558778
    // 0x55874c: ldur            x0, [fp, #-0x18]
    // 0x558750: LoadField: r1 = r0->field_b
    //     0x558750: ldur            w1, [x0, #0xb]
    // 0x558754: DecompressPointer r1
    //     0x558754: add             x1, x1, HEAP, lsl #32
    // 0x558758: ldur            x16, [fp, #-0x20]
    // 0x55875c: stp             x16, x1, [SP, #-0x10]!
    // 0x558760: mov             x0, x1
    // 0x558764: ClosureCall
    //     0x558764: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    //     0x558768: ldur            x2, [x0, #0x1f]
    //     0x55876c: blr             x2
    // 0x558770: add             SP, SP, #0x10
    // 0x558774: r0 = ReturnAsync()
    //     0x558774: b               #0x501858  ; ReturnAsyncStub
    // 0x558778: ldur            x0, [fp, #-0x20]
    // 0x55877c: r1 = 59
    //     0x55877c: mov             x1, #0x3b
    // 0x558780: branchIfSmi(r0, 0x55878c)
    //     0x558780: tbz             w0, #0, #0x55878c
    // 0x558784: r1 = LoadClassIdInstr(r0)
    //     0x558784: ldur            x1, [x0, #-1]
    //     0x558788: ubfx            x1, x1, #0xc, #0x14
    // 0x55878c: SaveReg r0
    //     0x55878c: str             x0, [SP, #-8]!
    // 0x558790: mov             x0, x1
    // 0x558794: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x558794: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x558798: r0 = GDT[cid_x0 + 0x3f73]()
    //     0x558798: mov             x17, #0x3f73
    //     0x55879c: add             lr, x0, x17
    //     0x5587a0: ldr             lr, [x21, lr, lsl #3]
    //     0x5587a4: blr             lr
    // 0x5587a8: add             SP, SP, #8
    // 0x5587ac: r0 = ReturnAsyncNotFuture()
    //     0x5587ac: b               #0x4b5758  ; ReturnAsyncNotFutureStub
    // 0x5587b0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x5587b0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x5587b4: b               #0x558670
    // 0x5587b8: r9 = _headers
    //     0x5587b8: add             x9, PP, #0x12, lsl #12  ; [pp+0x12ee0] Field <_RequestConfig@361184022._headers@361184022>: late (offset: 0xc)
    //     0x5587bc: ldr             x9, [x9, #0xee0]
    // 0x5587c0: r0 = LateInitializationErrorSharedWithoutFPURegs()
    //     0x5587c0: bl              #0xd6a268  ; LateInitializationErrorSharedWithoutFPURegsStub
  }
}

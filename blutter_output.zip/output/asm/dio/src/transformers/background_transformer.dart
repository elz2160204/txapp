// lib: , url: package:dio/src/transformers/background_transformer.dart

// class id: 1048900, size: 0x8
class :: {

  [closure] static dynamic _decodeJson(dynamic, String) {
    // ** addr: 0x55c42c, size: 0x38
    // 0x55c42c: EnterFrame
    //     0x55c42c: stp             fp, lr, [SP, #-0x10]!
    //     0x55c430: mov             fp, SP
    // 0x55c434: CheckStackOverflow
    //     0x55c434: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55c438: cmp             SP, x16
    //     0x55c43c: b.ls            #0x55c45c
    // 0x55c440: ldr             x16, [fp, #0x10]
    // 0x55c444: SaveReg r16
    //     0x55c444: str             x16, [SP, #-8]!
    // 0x55c448: r0 = _decodeJson()
    //     0x55c448: bl              #0x55c464  ; [package:dio/src/transformers/background_transformer.dart] ::_decodeJson
    // 0x55c44c: add             SP, SP, #8
    // 0x55c450: LeaveFrame
    //     0x55c450: mov             SP, fp
    //     0x55c454: ldp             fp, lr, [SP], #0x10
    // 0x55c458: ret
    //     0x55c458: ret             
    // 0x55c45c: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c45c: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c460: b               #0x55c440
  }
  static dynamic _decodeJson(String) {
    // ** addr: 0x55c464, size: 0x94
    // 0x55c464: EnterFrame
    //     0x55c464: stp             fp, lr, [SP, #-0x10]!
    //     0x55c468: mov             fp, SP
    // 0x55c46c: CheckStackOverflow
    //     0x55c46c: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x55c470: cmp             SP, x16
    //     0x55c474: b.ls            #0x55c4f0
    // 0x55c478: ldr             x0, [fp, #0x10]
    // 0x55c47c: LoadField: r1 = r0->field_7
    //     0x55c47c: ldur            w1, [x0, #7]
    // 0x55c480: DecompressPointer r1
    //     0x55c480: add             x1, x1, HEAP, lsl #32
    // 0x55c484: r2 = LoadInt32Instr(r1)
    //     0x55c484: sbfx            x2, x1, #1, #0x1f
    // 0x55c488: r17 = 51200
    //     0x55c488: mov             x17, #0xc800
    // 0x55c48c: cmp             x2, x17
    // 0x55c490: b.ge            #0x55c4b0
    // 0x55c494: SaveReg r0
    //     0x55c494: str             x0, [SP, #-8]!
    // 0x55c498: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x55c498: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x55c49c: r0 = jsonDecode()
    //     0x55c49c: bl              #0x55c4f8  ; [dart:convert] ::jsonDecode
    // 0x55c4a0: add             SP, SP, #8
    // 0x55c4a4: LeaveFrame
    //     0x55c4a4: mov             SP, fp
    //     0x55c4a8: ldp             fp, lr, [SP], #0x10
    // 0x55c4ac: ret
    //     0x55c4ac: ret             
    // 0x55c4b0: r16 = <String, dynamic>
    //     0x55c4b0: ldr             x16, [PP, #0x22b0]  ; [pp+0x22b0] TypeArguments: <String, dynamic>
    // 0x55c4b4: r30 = Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) => Future<Y1> from Function 'compute': static.
    //     0x55c4b4: add             lr, PP, #0x14, lsl #12  ; [pp+0x147f0] Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) => Future<Y1> from Function 'compute': static. (0x7fe6e1d5c610)
    //     0x55c4b8: ldr             lr, [lr, #0x7f0]
    // 0x55c4bc: stp             lr, x16, [SP, #-0x10]!
    // 0x55c4c0: r16 = Closure: (String, {((Object?, Object?) => Object?)? reviver}) => dynamic from Function 'jsonDecode': static.
    //     0x55c4c0: add             x16, PP, #0x14, lsl #12  ; [pp+0x147f8] Closure: (String, {((Object?, Object?) => Object?)? reviver}) => dynamic from Function 'jsonDecode': static. (0x7fe6e1d5c588)
    //     0x55c4c4: ldr             x16, [x16, #0x7f8]
    // 0x55c4c8: stp             x0, x16, [SP, #-0x10]!
    // 0x55c4cc: r0 = Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) => Future<Y1> from Function 'compute': static.
    //     0x55c4cc: add             x0, PP, #0x14, lsl #12  ; [pp+0x147f0] Closure: <Y0, Y1>((Y0) => FutureOr<Y1>, Y0, {String? debugLabel}) => Future<Y1> from Function 'compute': static. (0x7fe6e1d5c610)
    //     0x55c4d0: ldr             x0, [x0, #0x7f0]
    // 0x55c4d4: ClosureCall
    //     0x55c4d4: ldr             x4, [PP, #0x8c0]  ; [pp+0x8c0] List(5) [0x2, 0x3, 0x3, 0x3, Null]
    //     0x55c4d8: ldur            x2, [x0, #0x1f]
    //     0x55c4dc: blr             x2
    // 0x55c4e0: add             SP, SP, #0x20
    // 0x55c4e4: LeaveFrame
    //     0x55c4e4: mov             SP, fp
    //     0x55c4e8: ldp             fp, lr, [SP], #0x10
    // 0x55c4ec: ret
    //     0x55c4ec: ret             
    // 0x55c4f0: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x55c4f0: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x55c4f4: b               #0x55c478
  }
}

// class id: 4525, size: 0x10, field offset: 0x10
class BackgroundTransformer extends SyncTransformer {
}

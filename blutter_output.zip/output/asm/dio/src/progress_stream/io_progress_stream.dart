// lib: , url: package:dio/src/progress_stream/io_progress_stream.dart

// class id: 1048896, size: 0x8
class :: {

  static _ addProgress(/* No info */) {
    // ** addr: 0x55799c, size: 0xfc
    // 0x55799c: EnterFrame
    //     0x55799c: stp             fp, lr, [SP, #-0x10]!
    //     0x5579a0: mov             fp, SP
    // 0x5579a4: CheckStackOverflow
    //     0x5579a4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x5579a8: cmp             SP, x16
    //     0x5579ac: b.ls            #0x557a90
    // 0x5579b0: ldr             x0, [fp, #0x20]
    // 0x5579b4: r2 = Null
    //     0x5579b4: mov             x2, NULL
    // 0x5579b8: r1 = Null
    //     0x5579b8: mov             x1, NULL
    // 0x5579bc: cmp             w0, NULL
    // 0x5579c0: b.eq            #0x557a14
    // 0x5579c4: branchIfSmi(r0, 0x557a14)
    //     0x5579c4: tbz             w0, #0, #0x557a14
    // 0x5579c8: r8 = Stream<Uint8List>
    //     0x5579c8: add             x8, PP, #0x14, lsl #12  ; [pp+0x144d0] Type: Stream<Uint8List>
    //     0x5579cc: ldr             x8, [x8, #0x4d0]
    // 0x5579d0: r3 = SubtypeTestCache
    //     0x5579d0: add             x3, PP, #0x14, lsl #12  ; [pp+0x144d8] SubtypeTestCache
    //     0x5579d4: ldr             x3, [x3, #0x4d8]
    // 0x5579d8: r24 = Subtype3TestCacheStub
    //     0x5579d8: ldr             x24, [PP, #0x10]  ; [pp+0x10] Stub: Subtype3TestCache (0x4ae294)
    // 0x5579dc: LoadField: r30 = r24->field_7
    //     0x5579dc: ldur            lr, [x24, #7]
    // 0x5579e0: blr             lr
    // 0x5579e4: cmp             w7, NULL
    // 0x5579e8: b.eq            #0x5579f4
    // 0x5579ec: tbnz            w7, #4, #0x557a14
    // 0x5579f0: b               #0x557a1c
    // 0x5579f4: r8 = Stream<Uint8List>
    //     0x5579f4: add             x8, PP, #0x14, lsl #12  ; [pp+0x144e0] Type: Stream<Uint8List>
    //     0x5579f8: ldr             x8, [x8, #0x4e0]
    // 0x5579fc: r3 = SubtypeTestCache
    //     0x5579fc: add             x3, PP, #0x14, lsl #12  ; [pp+0x144e8] SubtypeTestCache
    //     0x557a00: ldr             x3, [x3, #0x4e8]
    // 0x557a04: r24 = InstanceOfStub
    //     0x557a04: ldr             x24, [PP, #0x1c8]  ; [pp+0x1c8] Stub: InstanceOf (0x4acebc)
    // 0x557a08: LoadField: r30 = r24->field_7
    //     0x557a08: ldur            lr, [x24, #7]
    // 0x557a0c: blr             lr
    // 0x557a10: b               #0x557a20
    // 0x557a14: r0 = false
    //     0x557a14: add             x0, NULL, #0x30  ; false
    // 0x557a18: b               #0x557a20
    // 0x557a1c: r0 = true
    //     0x557a1c: add             x0, NULL, #0x20  ; true
    // 0x557a20: tbnz            w0, #4, #0x557a48
    // 0x557a24: r16 = <Uint8List>
    //     0x557a24: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0x557a28: ldr             lr, [fp, #0x18]
    // 0x557a2c: stp             lr, x16, [SP, #-0x10]!
    // 0x557a30: ldr             x16, [fp, #0x10]
    // 0x557a34: SaveReg r16
    //     0x557a34: str             x16, [SP, #-8]!
    // 0x557a38: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x557a38: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x557a3c: r0 = _transform()
    //     0x557a3c: bl              #0x557a98  ; [package:dio/src/progress_stream/io_progress_stream.dart] ::_transform
    // 0x557a40: add             SP, SP, #0x18
    // 0x557a44: b               #0x557a68
    // 0x557a48: r16 = <List<int>>
    //     0x557a48: ldr             x16, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0x557a4c: ldr             lr, [fp, #0x18]
    // 0x557a50: stp             lr, x16, [SP, #-0x10]!
    // 0x557a54: ldr             x16, [fp, #0x10]
    // 0x557a58: SaveReg r16
    //     0x557a58: str             x16, [SP, #-8]!
    // 0x557a5c: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x557a5c: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x557a60: r0 = _transform()
    //     0x557a60: bl              #0x557a98  ; [package:dio/src/progress_stream/io_progress_stream.dart] ::_transform
    // 0x557a64: add             SP, SP, #0x18
    // 0x557a68: r16 = <Uint8List>
    //     0x557a68: ldr             x16, [PP, #0x1540]  ; [pp+0x1540] TypeArguments: <Uint8List>
    // 0x557a6c: ldr             lr, [fp, #0x20]
    // 0x557a70: stp             lr, x16, [SP, #-0x10]!
    // 0x557a74: SaveReg r0
    //     0x557a74: str             x0, [SP, #-8]!
    // 0x557a78: r4 = const [0x1, 0x2, 0x2, 0x2, null]
    //     0x557a78: ldr             x4, [PP, #0x3b8]  ; [pp+0x3b8] List(5) [0x1, 0x2, 0x2, 0x2, Null]
    // 0x557a7c: r0 = transform()
    //     0x557a7c: bl              #0x52e1e8  ; [dart:async] Stream::transform
    // 0x557a80: add             SP, SP, #0x18
    // 0x557a84: LeaveFrame
    //     0x557a84: mov             SP, fp
    //     0x557a88: ldp             fp, lr, [SP], #0x10
    // 0x557a8c: ret
    //     0x557a8c: ret             
    // 0x557a90: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557a90: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x557a94: b               #0x5579b0
  }
  static _ _transform(/* No info */) {
    // ** addr: 0x557a98, size: 0x110
    // 0x557a98: EnterFrame
    //     0x557a98: stp             fp, lr, [SP, #-0x10]!
    //     0x557a9c: mov             fp, SP
    // 0x557aa0: AllocStack(0x18)
    //     0x557aa0: sub             SP, SP, #0x18
    // 0x557aa4: SetupParameters()
    //     0x557aa4: mov             x0, x4
    //     0x557aa8: ldur            w1, [x0, #0xf]
    //     0x557aac: add             x1, x1, HEAP, lsl #32
    //     0x557ab0: stur            x1, [fp, #-0x10]
    //     0x557ab4: cbnz            w1, #0x557ac0
    //     0x557ab8: mov             x3, NULL
    //     0x557abc: b               #0x557ad4
    //     0x557ac0: ldur            w2, [x0, #0x17]
    //     0x557ac4: add             x2, x2, HEAP, lsl #32
    //     0x557ac8: add             x0, fp, w2, sxtw #2
    //     0x557acc: ldr             x0, [x0, #0x10]
    //     0x557ad0: mov             x3, x0
    // 0x557ad4: ldr             x2, [fp, #0x18]
    // 0x557ad8: ldr             x0, [fp, #0x10]
    // 0x557adc: stur            x3, [fp, #-8]
    // 0x557ae0: r1 = 3
    //     0x557ae0: mov             x1, #3
    // 0x557ae4: r0 = AllocateContext()
    //     0x557ae4: bl              #0xd68aa4  ; AllocateContextStub
    // 0x557ae8: mov             x1, x0
    // 0x557aec: ldr             x0, [fp, #0x18]
    // 0x557af0: StoreField: r1->field_f = r0
    //     0x557af0: stur            w0, [x1, #0xf]
    // 0x557af4: ldr             x0, [fp, #0x10]
    // 0x557af8: StoreField: r1->field_13 = r0
    //     0x557af8: stur            w0, [x1, #0x13]
    // 0x557afc: ldur            x0, [fp, #-0x10]
    // 0x557b00: cbnz            w0, #0x557b0c
    // 0x557b04: r0 = <List<int>>
    //     0x557b04: ldr             x0, [PP, #0x6790]  ; [pp+0x6790] TypeArguments: <List<int>>
    // 0x557b08: b               #0x557b10
    // 0x557b0c: ldur            x0, [fp, #-8]
    // 0x557b10: stur            x0, [fp, #-8]
    // 0x557b14: StoreField: r1->field_17 = rZR
    //     0x557b14: stur            wzr, [x1, #0x17]
    // 0x557b18: mov             x2, x1
    // 0x557b1c: r1 = Function '<anonymous closure>': static.
    //     0x557b1c: add             x1, PP, #0x14, lsl #12  ; [pp+0x144f0] AnonymousClosure: static (0x557ba8), in [package:dio/src/progress_stream/io_progress_stream.dart] ::_transform (0x557a98)
    //     0x557b20: ldr             x1, [x1, #0x4f0]
    // 0x557b24: r0 = AllocateClosure()
    //     0x557b24: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x557b28: ldur            x1, [fp, #-8]
    // 0x557b2c: stur            x0, [fp, #-0x10]
    // 0x557b30: StoreField: r0->field_b = r1
    //     0x557b30: stur            w1, [x0, #0xb]
    // 0x557b34: r2 = Null
    //     0x557b34: mov             x2, NULL
    // 0x557b38: r3 = <Y0 bound List<int>, Uint8List>
    //     0x557b38: add             x3, PP, #0x14, lsl #12  ; [pp+0x144f8] TypeArguments: <Y0 bound List<int>, Uint8List>
    //     0x557b3c: ldr             x3, [x3, #0x4f8]
    // 0x557b40: r24 = InstantiateTypeArgumentsStub
    //     0x557b40: ldr             x24, [PP, #0x500]  ; [pp+0x500] Stub: InstantiateTypeArguments (0x4acb34)
    // 0x557b44: LoadField: r30 = r24->field_7
    //     0x557b44: ldur            lr, [x24, #7]
    // 0x557b48: blr             lr
    // 0x557b4c: mov             x1, x0
    // 0x557b50: stur            x0, [fp, #-8]
    // 0x557b54: r0 = _StreamHandlerTransformer()
    //     0x557b54: bl              #0x52e47c  ; Allocate_StreamHandlerTransformerStub -> _StreamHandlerTransformer<X0, X1> (size=0x10)
    // 0x557b58: stur            x0, [fp, #-0x18]
    // 0x557b5c: r1 = 2
    //     0x557b5c: mov             x1, #2
    // 0x557b60: r0 = AllocateContext()
    //     0x557b60: bl              #0xd68aa4  ; AllocateContextStub
    // 0x557b64: mov             x1, x0
    // 0x557b68: ldur            x0, [fp, #-0x18]
    // 0x557b6c: StoreField: r1->field_f = r0
    //     0x557b6c: stur            w0, [x1, #0xf]
    // 0x557b70: ldur            x2, [fp, #-0x10]
    // 0x557b74: StoreField: r1->field_13 = r2
    //     0x557b74: stur            w2, [x1, #0x13]
    // 0x557b78: mov             x2, x1
    // 0x557b7c: r1 = Function '<anonymous closure>':.
    //     0x557b7c: add             x1, PP, #0x13, lsl #12  ; [pp+0x13160] AnonymousClosure: (0x52e6b4), of [dart:async] _StreamHandlerTransformer<X0, X1>
    //     0x557b80: ldr             x1, [x1, #0x160]
    // 0x557b84: r0 = AllocateClosure()
    //     0x557b84: bl              #0xd68bbc  ; AllocateClosureStub
    // 0x557b88: ldur            x1, [fp, #-8]
    // 0x557b8c: StoreField: r0->field_7 = r1
    //     0x557b8c: stur            w1, [x0, #7]
    // 0x557b90: ldur            x1, [fp, #-0x18]
    // 0x557b94: StoreField: r1->field_b = r0
    //     0x557b94: stur            w0, [x1, #0xb]
    // 0x557b98: mov             x0, x1
    // 0x557b9c: LeaveFrame
    //     0x557b9c: mov             SP, fp
    //     0x557ba0: ldp             fp, lr, [SP], #0x10
    // 0x557ba4: ret
    //     0x557ba4: ret             
  }
  [closure] static void <anonymous closure>(dynamic, Y0, EventSink<Uint8List>) {
    // ** addr: 0x557ba8, size: 0x20c
    // 0x557ba8: EnterFrame
    //     0x557ba8: stp             fp, lr, [SP, #-0x10]!
    //     0x557bac: mov             fp, SP
    // 0x557bb0: AllocStack(0x10)
    //     0x557bb0: sub             SP, SP, #0x10
    // 0x557bb4: SetupParameters()
    //     0x557bb4: ldr             x0, [fp, #0x20]
    //     0x557bb8: ldur            w1, [x0, #0x17]
    //     0x557bbc: add             x1, x1, HEAP, lsl #32
    //     0x557bc0: stur            x1, [fp, #-8]
    // 0x557bc4: CheckStackOverflow
    //     0x557bc4: ldr             x16, [THR, #0x38]  ; THR::stack_limit
    //     0x557bc8: cmp             SP, x16
    //     0x557bcc: b.ls            #0x557da8
    // 0x557bd0: LoadField: r0 = r1->field_13
    //     0x557bd0: ldur            w0, [x1, #0x13]
    // 0x557bd4: DecompressPointer r0
    //     0x557bd4: add             x0, x0, HEAP, lsl #32
    // 0x557bd8: LoadField: r2 = r0->field_5b
    //     0x557bd8: ldur            w2, [x0, #0x5b]
    // 0x557bdc: DecompressPointer r2
    //     0x557bdc: add             x2, x2, HEAP, lsl #32
    // 0x557be0: cmp             w2, NULL
    // 0x557be4: b.eq            #0x557c6c
    // 0x557be8: LoadField: r3 = r2->field_b
    //     0x557be8: ldur            w3, [x2, #0xb]
    // 0x557bec: DecompressPointer r3
    //     0x557bec: add             x3, x3, HEAP, lsl #32
    // 0x557bf0: cmp             w3, NULL
    // 0x557bf4: b.eq            #0x557c64
    // 0x557bf8: ldr             x1, [fp, #0x10]
    // 0x557bfc: StoreField: r2->field_f = r0
    //     0x557bfc: stur            w0, [x2, #0xf]
    //     0x557c00: ldurb           w16, [x2, #-1]
    //     0x557c04: ldurb           w17, [x0, #-1]
    //     0x557c08: and             x16, x17, x16, lsr #2
    //     0x557c0c: tst             x16, HEAP, lsr #32
    //     0x557c10: b.eq            #0x557c18
    //     0x557c14: bl              #0xd6828c
    // 0x557c18: r0 = LoadClassIdInstr(r1)
    //     0x557c18: ldur            x0, [x1, #-1]
    //     0x557c1c: ubfx            x0, x0, #0xc, #0x14
    // 0x557c20: stp             x3, x1, [SP, #-0x10]!
    // 0x557c24: r4 = const [0, 0x2, 0x2, 0x2, null]
    //     0x557c24: ldr             x4, [PP, #0x160]  ; [pp+0x160] List(5) [0, 0x2, 0x2, 0x2, Null]
    // 0x557c28: r0 = GDT[cid_x0 + 0x7c6]()
    //     0x557c28: add             lr, x0, #0x7c6
    //     0x557c2c: ldr             lr, [x21, lr, lsl #3]
    //     0x557c30: blr             lr
    // 0x557c34: add             SP, SP, #0x10
    // 0x557c38: ldr             x0, [fp, #0x10]
    // 0x557c3c: r1 = LoadClassIdInstr(r0)
    //     0x557c3c: ldur            x1, [x0, #-1]
    //     0x557c40: ubfx            x1, x1, #0xc, #0x14
    // 0x557c44: SaveReg r0
    //     0x557c44: str             x0, [SP, #-8]!
    // 0x557c48: mov             x0, x1
    // 0x557c4c: r4 = const [0, 0x1, 0x1, 0x1, null]
    //     0x557c4c: ldr             x4, [PP, #0x378]  ; [pp+0x378] List(5) [0, 0x1, 0x1, 0x1, Null]
    // 0x557c50: r0 = GDT[cid_x0 + 0x8a8]()
    //     0x557c50: add             lr, x0, #0x8a8
    //     0x557c54: ldr             lr, [x21, lr, lsl #3]
    //     0x557c58: blr             lr
    // 0x557c5c: add             SP, SP, #8
    // 0x557c60: b               #0x557d98
    // 0x557c64: ldr             x0, [fp, #0x10]
    // 0x557c68: b               #0x557c70
    // 0x557c6c: ldr             x0, [fp, #0x10]
    // 0x557c70: ldr             x2, [fp, #0x18]
    // 0x557c74: r3 = LoadClassIdInstr(r2)
    //     0x557c74: ldur            x3, [x2, #-1]
    //     0x557c78: ubfx            x3, x3, #0xc, #0x14
    // 0x557c7c: lsl             x3, x3, #1
    // 0x557c80: r4 = LoadInt32Instr(r3)
    //     0x557c80: sbfx            x4, x3, #1, #0x1f
    // 0x557c84: cmp             x4, #0x75
    // 0x557c88: b.lt            #0x557cb8
    // 0x557c8c: cmp             x4, #0x78
    // 0x557c90: b.gt            #0x557cb8
    // 0x557c94: r3 = LoadClassIdInstr(r0)
    //     0x557c94: ldur            x3, [x0, #-1]
    //     0x557c98: ubfx            x3, x3, #0xc, #0x14
    // 0x557c9c: stp             x2, x0, [SP, #-0x10]!
    // 0x557ca0: mov             x0, x3
    // 0x557ca4: r0 = GDT[cid_x0 + 0x6e6]()
    //     0x557ca4: add             lr, x0, #0x6e6
    //     0x557ca8: ldr             lr, [x21, lr, lsl #3]
    //     0x557cac: blr             lr
    // 0x557cb0: add             SP, SP, #0x10
    // 0x557cb4: b               #0x557cf0
    // 0x557cb8: ldr             x16, [fp, #0x18]
    // 0x557cbc: stp             x16, NULL, [SP, #-0x10]!
    // 0x557cc0: r0 = Uint8List.fromList()
    //     0x557cc0: bl              #0x540140  ; [dart:typed_data] Uint8List::Uint8List.fromList
    // 0x557cc4: add             SP, SP, #0x10
    // 0x557cc8: mov             x1, x0
    // 0x557ccc: ldr             x0, [fp, #0x10]
    // 0x557cd0: r2 = LoadClassIdInstr(r0)
    //     0x557cd0: ldur            x2, [x0, #-1]
    //     0x557cd4: ubfx            x2, x2, #0xc, #0x14
    // 0x557cd8: stp             x1, x0, [SP, #-0x10]!
    // 0x557cdc: mov             x0, x2
    // 0x557ce0: r0 = GDT[cid_x0 + 0x6e6]()
    //     0x557ce0: add             lr, x0, #0x6e6
    //     0x557ce4: ldr             lr, [x21, lr, lsl #3]
    //     0x557ce8: blr             lr
    // 0x557cec: add             SP, SP, #0x10
    // 0x557cf0: ldur            x1, [fp, #-8]
    // 0x557cf4: LoadField: r0 = r1->field_f
    //     0x557cf4: ldur            w0, [x1, #0xf]
    // 0x557cf8: DecompressPointer r0
    //     0x557cf8: add             x0, x0, HEAP, lsl #32
    // 0x557cfc: cmp             w0, NULL
    // 0x557d00: b.eq            #0x557d98
    // 0x557d04: ldr             x0, [fp, #0x18]
    // 0x557d08: LoadField: r2 = r1->field_17
    //     0x557d08: ldur            w2, [x1, #0x17]
    // 0x557d0c: DecompressPointer r2
    //     0x557d0c: add             x2, x2, HEAP, lsl #32
    // 0x557d10: stur            x2, [fp, #-0x10]
    // 0x557d14: r3 = LoadClassIdInstr(r0)
    //     0x557d14: ldur            x3, [x0, #-1]
    //     0x557d18: ubfx            x3, x3, #0xc, #0x14
    // 0x557d1c: SaveReg r0
    //     0x557d1c: str             x0, [SP, #-8]!
    // 0x557d20: mov             x0, x3
    // 0x557d24: r0 = GDT[cid_x0 + 0xb8ea]()
    //     0x557d24: mov             x17, #0xb8ea
    //     0x557d28: add             lr, x0, x17
    //     0x557d2c: ldr             lr, [x21, lr, lsl #3]
    //     0x557d30: blr             lr
    // 0x557d34: add             SP, SP, #8
    // 0x557d38: ldur            x2, [fp, #-0x10]
    // 0x557d3c: cmp             w2, NULL
    // 0x557d40: b.eq            #0x557db0
    // 0x557d44: r3 = LoadInt32Instr(r0)
    //     0x557d44: sbfx            x3, x0, #1, #0x1f
    //     0x557d48: tbz             w0, #0, #0x557d50
    //     0x557d4c: ldur            x3, [x0, #7]
    // 0x557d50: r4 = LoadInt32Instr(r2)
    //     0x557d50: sbfx            x4, x2, #1, #0x1f
    //     0x557d54: tbz             w2, #0, #0x557d5c
    //     0x557d58: ldur            x4, [x2, #7]
    // 0x557d5c: add             x2, x4, x3
    // 0x557d60: r0 = BoxInt64Instr(r2)
    //     0x557d60: sbfiz           x0, x2, #1, #0x1f
    //     0x557d64: cmp             x2, x0, asr #1
    //     0x557d68: b.eq            #0x557d74
    //     0x557d6c: bl              #0xd69bb8
    //     0x557d70: stur            x2, [x0, #7]
    // 0x557d74: ldur            x1, [fp, #-8]
    // 0x557d78: StoreField: r1->field_17 = r0
    //     0x557d78: stur            w0, [x1, #0x17]
    //     0x557d7c: tbz             w0, #0, #0x557d98
    //     0x557d80: ldurb           w16, [x1, #-1]
    //     0x557d84: ldurb           w17, [x0, #-1]
    //     0x557d88: and             x16, x17, x16, lsr #2
    //     0x557d8c: tst             x16, HEAP, lsr #32
    //     0x557d90: b.eq            #0x557d98
    //     0x557d94: bl              #0xd6826c
    // 0x557d98: r0 = Null
    //     0x557d98: mov             x0, NULL
    // 0x557d9c: LeaveFrame
    //     0x557d9c: mov             SP, fp
    //     0x557da0: ldp             fp, lr, [SP], #0x10
    // 0x557da4: ret
    //     0x557da4: ret             
    // 0x557da8: r0 = StackOverflowSharedWithoutFPURegs()
    //     0x557da8: bl              #0xd69a38  ; StackOverflowSharedWithoutFPURegsStub
    // 0x557dac: b               #0x557bd0
    // 0x557db0: r0 = NullErrorSharedWithoutFPURegs()
    //     0x557db0: bl              #0xd6a190  ; NullErrorSharedWithoutFPURegsStub
  }
}
